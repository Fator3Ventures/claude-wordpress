# Core 1.80.0 · 10/11/2026

Correção do erro fatal na carga com WP Super Cache, gravação concorrente pelo painel, origem do formulário em subdiretórios e anotação de escrita do contrato administrativo. Consulte RELEASE-1.80.0.md.

# Core 1.79.0 · 10/11/2026

Novo layout da tela de configuração. Coleta do site, Conteúdo e IA e SEO voltam a gravar pela tela; quatro grupos deixam de recusar alteração parcial. Consulta a pacotes acompanhantes ausentes sem aviso no log. Documentação instalada reorganizada, com referência e catálogo de habilidades gerados do registro. Sem mudança de habilidades, options, tabelas ou arquivos públicos. Consulte RELEASE-1.79.0.md e AGENTES-1.79.0.md.

# Core 1.78.0 · 10/11/2026

Autoria de WebPage no Yoast, filtro de caminhos do reaquecimento e HTTP 404 no diretório de atualização. Consulte RELEASE-1.78.0.md e AGENTES-1.78.0.md.

# Core 1.77.0 · 10/11/2026

Alvos por classe no editor, origem de anúncios em contatos sem sessão e formulário em duas etapas. Consulte RELEASE-1.77.0.md e AGENTES-1.77.0.md.

# Core 1.76.0 · 09/11/2026

Transporte CAPI em teste, decisão por PageView e retorno de etapas CRM de formulários nativos. Consulte RELEASE-1.76.0.md e AGENTES-1.76.0.md.

# Core 1.75.1 · 09/11/2026

Pedidos 375–382. Detalhes de operação e padrões em RELEASE-1.75.1.md.

# Core 1.74.0 · 07/11/2026

Pedido 374. O wp-admin exibe a política de Lead e salva as alterações independentes na configuração Meta. Detalhes em RELEASE-1.74.0.md.

# 1.72.1 — 05/11/2026

O submenu Relatórios passa a usar a mesma função registrada pelo menu Medição. Isso elimina a segunda renderização do painel e dos filtros de Web Vitals por versão. Atualização direta da 1.72.0, com contrato administrativo 8.34.0. Consulte RELEASE-1.72.1.md.

# 1.72.0 — 05/11/2026

Cliente público de contatos compilado por destino, filtro de versão de origem das amostras de vitais e perfil PHP sob demanda para os POSTs anônimos de coleta e manutenção de filas após a recriação das tabelas na reativação. Consulte RELEASE-1.72.0.md.

# 1.71.0 — 05/11/2026

Inicialização PHP por contexto, interface de consentimento sob demanda e apresentação da cobertura das amostras em vitais. Contrato administrativo 8.33.0. Consulte MEDICAO-DESEMPENHO.md.

# 1.70.0 — 05/11/2026

Painel por tarefa, busca, guia integrado e prevenção de perda de valores na edição de configurações, navegação e troca de conexão LinkedIn. Contrato administrativo 8.32.0.

# 1.69.0 — 02/11/2026

369(d,f,g,h): consulta pública de campanha com fila limitada, recuperação auditada, união de formulários e recibos canônicos preservados. Contrato 8.32.0, WordPress 7.1.4, PHP 8.3. Sem DDL novo.

# 1.68.0 — 01/11/2026

368: normalização textual, conflitos persistentes sem interromper coleta e códigos no cursor. 369: outbox pública LinkedIn 1.2, seleção automática opt-in, marco correto e adoção do recibo. 370: catálogo Meta por passagem com continuidade. Contrato 8.31.0. Consulta avulsa de nome de campanha ausente depende de extensão do produtor.

# 1.67.0 — 01/11/2026

Reinstalação: arquiva o recibo antes de remover estruturas auxiliares e abre novo ciclo ao reativar na mesma versão.

365: inventário explícito de estados internos. 366: esquema HTTPS do artefato em CLI, recusas diagnosticáveis e motivo vigente consistente. 367: identidade da aquisição no coletor, detalhe local/servidor por event_id e comparação Meta no fuso do produtor. Migração aditiva de event_id; nenhum destino ativado.

# 1.65.0 — 31/10/2026

Executor CLI configurável, atualização urgente, CTA sem processamento repetido, projeção pública e composições defer por fornecedor, bootstrap cedo, atrasos por destino e otimizações sem amostragem. Consulte RELEASE-1.65.0.md e o relatório externo para provas e limitações.

# 1.64.0 — 30/10/2026

Spam por sinal, janela robots, política de e-mails nativos, perfil público, mapas llms/esquema, reparo e zelador cron. Contrato 8.29.0. Leia RELEASE-1.64.0.md.

# 1.63.0 — 30/10/2026

Pedidos 352–356: inicialização antecipada, observação efêmera, persistência IMAP, carga sob demanda e diagnóstico, retomada robots e correspondência manual Meta. Contrato 8.28.0. Leia RELEASE-1.63.0.md.

> Vigente em 1.62.0: contrato 8.27.0; pedidos 348–351 em RELEASE-1.62.0.md e CAMPANHAS-MARCAS-PERFIL-1.62.md. As notas atuais prevalecem nos pontos alterados.

# Core 1.61.0 — 29/10/2026

Conversões 1.1 ambos e falhas claras; credenciais em itens com revisão; contexto de sessão cifrado e filtros; apps/redes revisionados; presença paga nos logs; demanda nativa; regras orgânicas/IA; recibos CRM parciais; e-mails grandes por FETCH parcial. Leia RELEASE-1.61.0.md para limites e pendências.

# 1.60.0 — 29/10/2026

Pedidos 322 e 330–334: prova de e-mail com limpeza UID, parceiros Meta sem revogar concessão, superfícies de marca, saúde com renovação/automação separadas, host canônico de teste e credenciais com avisos de formato. Base 1.59.0; contrato 8.24.0. Veja RELEASE-1.60.0.md e relatório externo.

# 1.59.0 — 28/10/2026

Base direta 1.58.0; contrato administrativo 8.23.0 conservado. Pedido Core 323: incorporação do retorno Google 0.22 com consulta vinculada de recibos comerciais incertos, extensão `site-stage-conversion-reconcile/1.0.0`, intervalo reservado e limite por passagem; sem reingestão. Capacidades Google 0.22/LinkedIn 0.12 substituem o bloqueio estático por versões antigas. Concessões, aquisição, consentimento, bancos e diários existentes preservados.

A consulta mantém referência/ação/evento, revisões e persistência concorrente; prova de envio expirada não equivale a revogação. LinkedIn incerto permanece sem reenvio; limitação da auditoria central MCP 0.34 está registrada no relatório, sem impacto de encerramento. Leia RELEASE-1.59.0.md e RECONCILIACAO-COMERCIAL-1.59.md para comportamento e limites. Os resultados da rodada pertencem ao relatório externo.

# 1.58.0 — 28/10/2026

Base direta 1.57.1; contrato administrativo 8.23.0. Pedidos 314–329: atribuição fiel, desfechos financeiros, Google 1.1, abandono por campo/revisão, vínculo WhatsApp e recorrência, primeira resposta, prontidão/resumo, teste sob demanda com limpeza, qualidade por destino, marcas, provas pós-atualização, SMTP de wp_mail, edição por caminho/hash e avisos técnicos próprios. Consumidor local Meta Ads do impacto Meta 0.13.0 revisão 2 (Meta 20e).

Google/LinkedIn por etapa exigem contrato proposto 1.2 ainda não disponível nos acompanhantes; e-mail/webhook no teste 322 bloqueiam enquanto não houver limpeza individual comprovável. Leia RELEASE-1.58.0.md, guias de domínio e relatório externo para alcance e provas.

# 1.57.1 — 27/10/2026

Consolidação das implementações 312/313: requisição de exclusão Instagram cifrada e repetível, proteção de transações/concorrência; validação estrita, âncora durável, revisita e continuidade do acervo GA4. Base direta canônica 1.57.0, contrato 8.22.1. Leia RELEASE-1.57.1.md.

# 1.57.0

Pedidos 312/313: exclusão coordenada Instagram com recibo e retomada; acervo GA4 diário/retroativo sem expiração padrão, SDK Google, recortes separados, cotas/qualidade, consultas/exportação e fontes separadas no painel. Contrato 8.22.0; 164 abilities. Detalhes em RELEASE-1.57.0.md.

# Histórico de mudanças — Core 1.56.0

Pedidos 307–311: aprovação sem entrega, celular BR de oito dígitos, ponte WhatsApp, histórico instalado e prova SMTP. Consumidor opcional Meta Instagram. Leia RELEASE-1.56.0.md.

- [1.55.0](history/RELEASE-1.55.0.md)
- [1.54.0](history/RELEASE-1.54.0.md)
- [1.53.0](history/RELEASE-1.53.0.md)
- [1.52.1](history/RELEASE-1.52.1.md)
- [1.52.0](history/RELEASE-1.52.0.md)
- [1.51.0](history/RELEASE-1.51.0.md)
- [1.50.0](history/RELEASE-1.50.0.md)
- [1.49.1](history/RELEASE-1.49.1.md)
- [1.49.0](history/RELEASE-1.49.0.md)

# 1.55.0

303–306: sessão administrativa lembrada configurável; verificação DKIM/SPF/DMARC com retomada DNS; namespace/pastas e UID/INTERNALDATE; teste por assunto/remetente; confirmação cron de cache/robots e prova na saúde. Contrato 8.20.0. Detalhes em OPERACAO-1.55.md.

# 1.54.0

Pedido 302: contato externo cifrado, vínculo manual reversível de sessões, consultas/filtros e exclusão em cascata. Gates exatos de e-mail para o MCP 0.32.0.

# 1.53.0 — 25/10/2026

299: comparação do legado por chave, ignorando ativo da raiz. 300: caixa por site e envio explícito, MIME isolado, identidade de mensagem, mesma unidade no CRM. 301 atualizado: quarta isca, política por sinal, supressão auditável e contagens. Contrato 8.18.0; cinco abilities aditivas. Limites de homologação em docs/history/RELEASE-1.55.0.md.

# Mudanças vigentes — 1.53.0

- 296: adaptador de e-mail com dados fixos removido; guarda de migração anterior; limpeza explícita com prévia/revisão; CF7 sem chamador e inferência Elementor removidos; documentação substituída fora do instalador.
- 297: orçamento incremental do catálogo, modo por caminho e diagnóstico/nova tentativa.
- 298: histerese de captação, incidentes com abertura/encerramento condicionados, prioridade das capturas e entregas no executor.

Base direta 1.51.0, contrato 8.18.0. Histórico completo de releases anteriores no fonte, em history/. Contratos atuais, mudanças e limites em RELEASE-1.55.0.md; não considerar histórico como instrução operacional.
