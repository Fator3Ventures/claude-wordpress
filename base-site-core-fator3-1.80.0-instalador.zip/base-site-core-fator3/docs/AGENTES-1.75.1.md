# Operação por agente — Core 1.75.1

Descubra a ability, consulte o schema instalado e leia a opção antes da escrita. Simule com a revisão de origem, aplique e confira o efeito. Os exemplos completos para os pedidos 375 a 382 estão em RELEASE-1.75.1.md. Para o aceite do caminho do lead, preserve a chave de operação e acompanhe o recibo. Para pixels e fotografias de abandono, confira o consentimento, a política de teste e a autorização do dono antes de alterar um site. O acesso aos valores de contatos exige capacidade própria.
