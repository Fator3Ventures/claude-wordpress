# Validação do Core 1.80.0

Este documento diz como conferir, em um WordPress com o Core 1.80.0 instalado, que a documentação e o plugin correspondem à versão. Todas as conferências usam uma conta com `manage_options` e não têm efeito: nenhuma grava, repara ou chama fornecedor. Os resultados da rodada ficam no relatório da entrega, fora do instalador. Provas de rodadas anteriores estão na seção final "Histórico".

## Conferências

| Conferência | Como fazer | O que observar |
| --- | --- | --- |
| Versão instalada | `f3base/documentacao-ler` sem argumentos | `versao` igual a 1.80.0; `indice` igual a `docs/DOCUMENTACAO.md`; `arquivos` lista os documentos instalados. |
| Índice completo | Compare `arquivos` com os `.md` citados em DOCUMENTACAO.md | Cada arquivo `.md` de `docs/` aparece no índice pelo nome. |
| Leitura paginada | `f3base/documentacao-ler` com `arquivo`, `linha` e `limite` (até 200), seguindo `proxima_linha` | `sha256` e `total_linhas` iguais em todas as páginas; a última página traz `proxima_linha` nulo. |
| Recusa de arquivo fora do índice | Peça um `arquivo` que não consta de `arquivos`, por exemplo `../base-site-core-fator3.php` | `ok: false`, `codigo: documento_nao_catalogado`. |
| Recusa sem permissão | Chame a mesma ability com conta sem `manage_options` | `ok: false`, `codigo: sem_permissao`. |
| Contrato administrativo | `f3base/como-usar`, bloco `configuracao` | `contract_version` igual a 8.38.0. |
| Referência de abilities | Conte as abilities `f3base/*` do catálogo MCP | Total igual ao declarado no topo de REFERENCIA-ABILITIES.md. |
| Guarda de recuperação | `f3base/operacao-recuperacao-ler` | `codigo: core_operacional` quando não há pausa. |
| Saúde | `f3base/saude-ler` | Estado, agenda e evidências já existentes; a leitura não executa verificações. |

## Conferências no fonte

O fonte da rodada (fora do instalador) traz a suíte de testes e o gerador da referência de abilities. Os comandos estão em `tests/README.md` e em `README.md` do fonte. O comando `php build/gerar-referencia-abilities.php --check` sai com código 1 quando REFERENCIA-ABILITIES.md diverge do registro.

## Limites

- Existir uma ability não é homologação de fornecedor. Conexões reais com Google, Meta, LinkedIn, Pipedrive, Slack e IMAP dependem de credencial e de aceite do dono do site.
- Teste com fixture, WordPress real e fornecedor real são provas diferentes; o relatório da entrega informa qual delas cada resultado representa.
- A publicação nos sites da frota pertence à frota e ao dono.

## Histórico

Este documento descrevia a validação das versões 1.72.1 (Web Vitals por versão de origem) e 1.60.0 (pedidos 322 e 330 a 334). Esses procedimentos não foram reconferidos contra o código da 1.80.0. As notas dessas versões estão em RELEASE-1.72.1.md e RELEASE-1.60.0.md.
