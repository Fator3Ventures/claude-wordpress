<?php
/** Meta transport is independent of tag scheduling. GA4 remains browser-only. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Meta_Transporte {
    public const ESQUEMA_VERSAO=16700;
    const CATALOGO=array('PageView','Lead','MaterialDownload');
    public static function catalogo_ativo(): array {return F3Base_Conversoes_Conteudo::habilitado('meta')?self::CATALOGO:array('PageView','Lead');}
    public static function config(): array {return (array)F3Base_Options::ler('f3base_meta_transporte');}
    public static function servidor(string $evento): bool {$c=self::config();if($evento==='MaterialDownload'){return F3Base_Conversoes_Conteudo::habilitado('meta')&&in_array($c['modo']??'navegador',array('ambos','servidor'),true); }return in_array($c['modo']??'navegador',array('ambos','servidor'),true)&&in_array($evento,$c['eventos']??self::CATALOGO,true);}
    public static function contexto(): string {
        $parts=array(F3Base_Modulo_Meta_Capi::pixel_id(),F3Base_Options::revisao('f3base_meta_capi_token'),F3Base_Options::ler('f3base_meta_auto_config'),F3Base_Options::ler('f3base_gtm_container_id'),F3Base_Options::ler('f3base_consentimento'),self::config()['eventos']??array('PageView','Lead'),F3Base_Options::ler('f3base_meta_janela'),F3Base_Options::ler('f3base_gtm_evidencia')['sha256']??'');
        if(F3Base_Conversoes_Conteudo::habilitado('meta')){array_unshift($parts,'material-1350');}
        return hash('sha256',wp_json_encode($parts));
    }
    public static function catalogo(array $c): array {
        $c['f3base_meta_capi_pixel_id']=array('rotulo'=>'Pixel/dataset da Meta no servidor','descricao'=>'Destino independente da tag direta. Vazio herda o Pixel direto; preencha quando o Pixel vier do GTM. Trocar destino invalida a homologação e não redireciona a fila antiga.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'texto','padrao'=>'','sanitiza'=>static fn($v)=>is_string($v)?trim($v):'','recusa'=>static fn($v)=>is_string($v)&&preg_match('/^[0-9]{0,32}$/D',$v)?'':'Informe somente dígitos.');
        $c['f3base_meta_transporte']=array('rotulo'=>'Transporte dos eventos Meta','descricao'=>'Navegador usa o Pixel. Ambos acrescenta CAPI com mesmo event_id. Servidor exige homologação por site e desliga o Pixel direto. GA4 continua pela tag.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'grupo','padrao'=>array('modo'=>'navegador','eventos'=>array('PageView','Lead')),'subcampos'=>array('modo'=>array('tipo'=>'enum','rotulo'=>'Como enviar à Meta','opcoes'=>array('navegador'=>'Navegador','ambos'=>'Pixel e servidor','servidor'=>'Somente servidor homologado'),'descricao'=>'A mudança para servidor exige equivalência, sete dias completos e provas externas por evento. Tag em GTM/tema exige conferência própria.'),'eventos'=>array('tipo'=>'multiescolha','opcoes'=>array('PageView'=>'Página vista (PageView)','Lead'=>'Contato (Lead)'),'rotulo'=>'Eventos com rota servidor','descricao'=>'PageView e Lead usam esta seleção. MaterialDownload segue o interruptor Meta em Conversões de material, independentemente desta lista. A atualização não ativa destinos.')),'schema_config'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('modo'=>array('type'=>'string','enum'=>array('navegador','ambos','servidor')),'eventos'=>array('type'=>'array','uniqueItems'=>true,'items'=>array('type'=>'string','enum'=>array('PageView','Lead'))))),'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static function($v){if(!is_array($v)||array_diff(array_keys($v),array('modo','eventos'))||!in_array($v['modo']??'',array('navegador','ambos','servidor'),true)||!is_array($v['eventos']??null)||array_diff($v['eventos'],array('PageView','Lead'))){return 'Transporte Meta inválido.';}if($v['modo']!=='navegador'&&(!F3Base_Modulo_Meta_Capi::token()||!F3Base_Modulo_Meta_Capi::pixel_id())){return 'Cadastre token e Pixel/dataset antes de ativar servidor.';}if($v['modo']==='servidor'){$p=F3Base_Options::ler('f3base_meta_homologacao');if(!empty(F3Base_Options::ler('f3base_meta_auto_config'))||array_diff(array('PageView','Lead'),$v['eventos'])||($p['contexto']??'')!==self::contexto()||empty($p['aprovada'])){return 'Servidor bloqueado: catálogo, autoConfig ou prova de homologação não atendem ao contrato.';}}return '';});
        $c['f3base_meta_homologacao']=array('rotulo'=>'Prova de homologação Meta','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));
        $c['f3base_meta_janela']=array('rotulo'=>'Janelas externas da Meta conferidas','descricao'=>'Conferência operacional das regras oficiais, válida por 90 dias. Sem conferência, a fila mantém 1 hora. Nunca excede sete dias da ocorrência; ambos também respeita deduplicação, com margem de cinco minutos. Alterar não prolonga filas existentes.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'grupo','padrao'=>array('confirmada'=>false,'aceitacao_segundos'=>604800,'deduplicacao_segundos'=>172800,'conferida_em'=>'','fonte'=>'https://developers.facebook.com/documentation/ads-commerce/conversions-api/deduplicate-pixel-and-server-events'),'subcampos'=>array('confirmada'=>array('tipo'=>'booleano','rotulo'=>'Limites conferidos na documentação oficial'),'aceitacao_segundos'=>array('tipo'=>'inteiro','rotulo'=>'Idade máxima aceita, em segundos'),'deduplicacao_segundos'=>array('tipo'=>'inteiro','rotulo'=>'Janela de deduplicação, em segundos'),'conferida_em'=>array('tipo'=>'texto','html_tipo'=>'date','rotulo'=>'Data da conferência'),'fonte'=>array('tipo'=>'texto','rotulo'=>'URL oficial conferida')),'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static function($v){if(!is_array($v)||array_diff(array_keys($v),array('confirmada','aceitacao_segundos','deduplicacao_segundos','conferida_em','fonte'))||!is_bool($v['confirmada']??null)){return 'Conferência inválida.';}foreach(array('aceitacao_segundos','deduplicacao_segundos') as $k){if(!is_int($v[$k]??null)||$v[$k]<600||$v[$k]>604800){return 'Informe limites entre 600 e 604800 segundos.';}}if(!is_string($v['fonte']??null)||wp_parse_url($v['fonte'],PHP_URL_HOST)!=='developers.facebook.com'||wp_parse_url($v['fonte'],PHP_URL_SCHEME)!=='https'){return 'Informe fonte oficial da Meta.';}if($v['confirmada']){$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v['conferida_em']??'',new DateTimeZone('UTC'));if(!$d||$d->format('Y-m-d')!==$v['conferida_em']||$d->getTimestamp()>time()||$d->getTimestamp()<time()-90*DAY_IN_SECONDS){return 'Confira e informe a data vigente.';}}return '';});
        return $c;
    }
    public static function iniciar(): void {
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/meta-eventos',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array(__CLASS__,'receber'))));
        add_action('wp_enqueue_scripts',array(__CLASS__,'enfileirar'),31);
        add_action('wp_abilities_api_init',static function(){
            F3Base_Meta_Lead::registrar();
            F3Base_Servicos::ability('meta-entregas-ler','Eventos Meta por rota e dia; evidência local separada da plataforma',array(__CLASS__,'relatorio'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'modo'=>array('type'=>'string','enum'=>array('resumo','eventos')),'pagina'=>array('type'=>'integer','minimum'=>1)));
            F3Base_Servicos::ability('meta-homologacao-registrar','Registrar evidência externa para avaliar elegibilidade do modo servidor',array(__CLASS__,'homologar'),array('inicio'=>array('type'=>'string','format'=>'date'),'fim'=>array('type'=>'string','format'=>'date'),'evidencia_url'=>array('type'=>'string','maxLength'=>2048),'credencial_validada'=>array('type'=>'boolean'),'catalogo_equivalente'=>array('type'=>'boolean'),'sem_meta_terceiros'=>array('type'=>'boolean'),'eventos'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(self::CATALOGO,array('type'=>'object','required'=>array('elegiveis','pixel','servidor','deduplicados','descartes_inexplicados'),'additionalProperties'=>false,'properties'=>array_fill_keys(array('elegiveis','pixel','servidor','deduplicados','descartes_inexplicados'),array('type'=>'integer','minimum'=>0)))))) ,array('inicio','fim','evidencia_url','credencial_validada','catalogo_equivalente','sem_meta_terceiros','eventos'),false);
        });
    }
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=$wpdb->prefix.'f3base_meta_eventos';dbDelta("CREATE TABLE {$t} (
 evento char(64) NOT NULL,
 event_id varchar(100) NOT NULL DEFAULT '',
 nome varchar(32) NOT NULL,
 pixel_id varchar(40) NOT NULL DEFAULT '',
 criado_em bigint NOT NULL,
 rota varchar(20) NOT NULL,
 navegador_observado tinyint NOT NULL DEFAULT 0,
 classe_trafego varchar(16) NOT NULL,
 atualizado_em bigint NOT NULL,
 PRIMARY KEY  (evento),
 KEY periodo (criado_em,nome,rota)
) ENGINE=InnoDB {$wpdb->get_charset_collate()};");return !$wpdb->last_error;
    }
    public static function prazo(int $quando,string $modo): array {
        $v=F3Base_Options::ler('f3base_meta_janela');$confirmed=!empty($v['confirmada'])&&strtotime($v['conferida_em']??'')>=time()-90*DAY_IN_SECONDS;
        $seconds=$confirmed?min(7*DAY_IN_SECONDS,(int)$v['aceitacao_segundos'],$modo==='servidor'?7*DAY_IN_SECONDS:(int)$v['deduplicacao_segundos'])-300:HOUR_IN_SECONDS;
        return array('expira_em'=>$quando+$seconds,'segundos'=>$seconds,'teto_operacional_segundos'=>7*DAY_IN_SECONDS,'regra'=>$confirmed?'limites_externos_confirmados_com_margem_5min':'conservador_1h_limite_externo_nao_reconfirmado','fonte'=>$v['fonte']??'','conferida_em'=>$v['conferida_em']??'','verificacao'=>$confirmed?'Confirmação registrada pelo operador; prazo contado da ocorrência original.':'Páginas oficiais responderam 429 em 2026-10-01. Reconfirmar limites antes de ampliar.');
    }

    public static function efetivo(): array {$c=self::config();$server=$c['modo']==='servidor';$p=F3Base_Options::ler('f3base_meta_homologacao');if($server&&(($p['contexto']??'')!==self::contexto()||empty($p['aprovada']))){$c['estado']='prova_invalidada';$c['modo']='ambos';}return $c; }
    public static function publico(): array {return self::efetivo()+array('endpoint'=>rest_url(F3BASE_REST_NAMESPACE.'/meta-eventos'),'token'=>F3Base_Modulo_Endpoint_Leads::emitir_token(),'rotaToken'=>rest_url(F3BASE_REST_NAMESPACE.'/comportamento/token'),'pixel'=>F3Base_Modulo_Meta_Capi::pixel_id(),'material'=>F3Base_Conversoes_Conteudo::habilitado('meta'),
        'testeCapi'=>F3Base_Testes::politica('capi','teste')==='marcar'?'marcar':'suprimir',
        'consentimentoLegado'=>F3Base_Modulo_Consentimento::modo_granular()?'nao':'sim');}
    public static function enfileirar(): void {
        if(is_admin()||!wp_script_is('f3base-tracking','enqueued')||!F3Base_Modulo_Meta_Capi::pixel_id()){return;}
        wp_enqueue_script('f3base-meta-transporte',F3BASE_PLUGIN_URL.'assets/f3base-meta-transporte.min.js',array('f3base-tracking'),F3BASE_PLUGIN_VERSAO,array('in_footer'=>true,'strategy'=>'defer'));wp_localize_script('f3base-meta-transporte','f3baseMetaTransporteDados',self::publico());
    }
    public static function observar(string $id,string $nome,int $quando,string $classe,bool $browser): bool {
        if(!preg_match('/^[a-zA-Z0-9_-]{16,100}$/D',$id)||!in_array($nome,self::CATALOGO,true)){return false;}
        global $wpdb;$c=self::config();$route=self::servidor($nome)?self::efetivo()['modo']:'navegador';$key=hash('sha256',$nome.'|'.$id);
        return false!==$wpdb->query($wpdb->prepare('INSERT INTO %i (evento,nome,criado_em,rota,navegador_observado,classe_trafego,atualizado_em,pixel_id,event_id) VALUES (%s,%s,%d,%s,%d,%s,%d,%s,%s) ON DUPLICATE KEY UPDATE event_id=VALUES(event_id),pixel_id=IF(VALUES(navegador_observado)=1,IF(navegador_observado=0,VALUES(pixel_id),IF(pixel_id=VALUES(pixel_id),pixel_id,"")),pixel_id),navegador_observado=GREATEST(navegador_observado,VALUES(navegador_observado)),atualizado_em=VALUES(atualizado_em)',$wpdb->prefix.'f3base_meta_eventos',$key,$nome,$quando,$route,$browser?1:0,$classe,time(),(string)F3Base_Options::ler('f3base_meta_pixel_id'),$id));
    }
    public static function receber(WP_REST_Request $req): WP_REST_Response {
        $fail=static fn($code,$status)=>new WP_REST_Response(array('ok'=>false,'codigo'=>$code),$status);
        if(strlen($req->get_body())>8192){return $fail('corpo_excessivo',413);}$e=$req->get_json_params();
        if(!is_array($e)||array_diff(array_keys($e),array('token','nome','evento','criado_em','caminho','contexto_teste','navegador_observado','fbp','fbc'))||!is_string($e['token']??null)||!F3Base_Modulo_Endpoint_Leads::validar_token($e['token'])){return $fail('token_ou_entrada_invalida',403);}
        if(!F3Base_Modulo_Consentimento::permite_categoria('medicao')||!F3Base_Modulo_Consentimento::permite_categoria('publicidade')){return $fail('consentimento_nao_permite',403);}
        $origin=$req->get_header('origin');if($origin&&wp_parse_url($origin,PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST)){return $fail('origem_invalida',403);}
        if(!in_array($e['nome']??'',self::CATALOGO,true)||!preg_match('/^[a-zA-Z0-9_-]{16,64}$/D',$e['evento']??'')||!is_int($e['criado_em']??null)||$e['criado_em']<time()-HOUR_IN_SECONDS||$e['criado_em']>time()+120){return $fail('evento_invalido',400);}
        $marca=F3Base_Testes::resolver($e,$req);if(empty($marca['ok'])){return $fail('marca_invalida',400);}$classe=$marca['contexto_teste']?'teste':'nao_marcado';if($classe==='teste'&&(!self::servidor($e['nome'])||F3Base_Testes::politica('capi','teste')!=='marcar')){return new WP_REST_Response(array('ok'=>true,'suprimido'=>true),200);}
        $ip=F3Base_Modulo_Endpoint_Leads::origem();if(is_array($ip)){$ip=$ip['valor']??'';}$ip=(string)$ip;
        if(!F3Base_Leads_Repositorio::quota('meta119|'.hash_hmac('sha256',$ip.'|'.floor(time()/600),wp_salt('auth')),300,time()+600)){return $fail('limite_origem',429);}
        $path=F3Base_Analise::caminho((string)($e['caminho']??''));if(!$path||in_array(F3Base_Editorial::base($path)['classe'],array('operacional','varredura','asset','descoberta'),true)){return $fail('caminho_invalido',400);}
        if(in_array($e['nome'],array('Lead','MaterialDownload'),true)){
            $lead=self::lead_do_evento($e['evento'],$classe);if(!$lead){return $fail('lead_aceito_ausente',409);}
            if(F3Base_Conversoes_Conteudo::evento_meta($lead)!==$e['nome']){return $fail('evento_diverge_metodo',409);}
            if($e['nome']==='MaterialDownload'&&!F3Base_Conversoes_Conteudo::habilitado('meta')){return $fail('material_meta_desligado',403);}
        }
        $queuePage=$e['nome']==='PageView'&&self::servidor('PageView');
        if($queuePage){
            $ref=F3Base_Modulo_Consentimento::referencia_confirmada();
            if(!F3Base_Modulo_Consentimento::modo_granular()){
                $proof=$_COOKIE['f3base_capi_ref']??'';
                if(!is_string($proof)||!preg_match('/^[a-f0-9]{64}$/D',$proof)){return $fail('referencia_de_navegacao_ausente',403);}
                $ref=F3Base_Consentimento_Decisoes::referencia_pageview($proof);
            }
        }
        $browser=$classe!=='teste' && ($e['navegador_observado']??false)===true;$ok=self::observar($e['evento'],$e['nome'],$e['criado_em'],$classe,$browser);
        if(!$ok){return $fail('persistencia_indisponivel',503);}
        $enqueued=false;if($queuePage){
            $cookies=array();foreach(array('fbp','fbc') as $k){$v=$e[$k]??'';if(is_string($v)&&preg_match('/^fb\.[0-9]{1,2}\.[0-9]{13}\.[A-Za-z0-9_-]{1,200}$/D',$v)){$cookies[$k]=$v;}}
            $home=wp_parse_url(home_url());$url=$home['scheme'].'://'.$home['host'].(isset($home['port'])?':'.$home['port']:'').$path;
            $payload=F3Base_Modulo_Meta_Capi::montar_payload(array('correlation_id'=>$e['evento'],'atribuicao'=>$cookies),$ip,substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,1024),$url,$e['criado_em']);$payload['data'][0]['event_name']='PageView';$payload['_f3base_contexto_teste']=$classe==='teste';
            $enqueued=F3Base_Capi_Fila::inserir('meta-page-'.$e['evento'],$payload,7*DAY_IN_SECONDS,F3Base_Modulo_Meta_Capi::pixel_id(),$ref);
            if(!$enqueued){return $fail('fila_indisponivel',503);}
        }
        return new WP_REST_Response(array('ok'=>true,'evento'=>$e['evento'],'enfileirado'=>$enqueued,'evidencia'=>'captura_local; não comprova recebimento pelo Pixel'),200);
    }
    /** Resolve only native identities. Never accept arbitrary JSON ids or reserve a new acquisition here. */
    private static function lead_do_evento(string $evento,string $classe): ?array {
        global $wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT record_id FROM %i WHERE (record_id=%s OR correlacao=%s) AND captura IN ('aceito','clique') AND lixeira=0 AND eliminacao_pendente=0 AND classe_trafego=%s LIMIT 3",F3Base_Leads_Repositorio::tabela(),$evento,$evento,$classe));
        foreach($ids as $id){$lead=F3Base_Leads_Repositorio::obter($id);if(!$lead||!hash_equals(F3Base_Aquisicoes::event_id($lead),$evento)){continue;}
            $d=$lead['dados'];$cons=F3Base_Contato_Apresentacao::consentimento($d);
            if(empty($cons['medicao'])||empty($cons['publicidade'])||!empty($d['audiencia_excluida'])||!F3Base_Telefone::converter($lead)||F3Base_Contato_Identidade::bloqueio($lead,'meta')!==''||in_array($d['classificacao_contexto']??'',array('pendente','falha','excluida','saida_sem_classificacao','consentimento_negado'),true)){continue;}
            return $lead;
        }return null;
    }
    /** Erase the exact identity with the contact; anonymous aggregate counts remain. */
    public static function eliminar_identidade(array $lead): bool {
        global $wpdb;$hashes=array();foreach(array_unique(array(F3Base_Aquisicoes::event_id($lead),(string)($lead['correlacao']??''))) as $id){if($id!==''){foreach(array('Lead','MaterialDownload') as $nome){$hashes[]=hash('sha256',$nome.'|'.$id);}}}
        foreach($hashes as $hash){if($wpdb->update($wpdb->prefix.'f3base_meta_eventos',array('event_id'=>''),array('evento'=>$hash))===false){return false;}}return true;
    }
    public static function homologar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $start=strtotime(($e['inicio']??'').' UTC');$end=strtotime(($e['fim']??'').' 23:59:59 UTC');$host=wp_parse_url($e['evidencia_url']??'',PHP_URL_HOST);
        $ok=self::config()['modo']==='ambos'&&!array_diff(array('PageView','Lead'),self::config()['eventos'])&&$start&&$end&&$end-$start>=7*DAY_IN_SECONDS-1&&$end<time()&&in_array($host,array('business.facebook.com','www.facebook.com','developers.facebook.com'),true)&&wp_parse_url($e['evidencia_url'],PHP_URL_SCHEME)==='https'&&!empty($e['credencial_validada'])&&!empty($e['catalogo_equivalente'])&&!empty($e['sem_meta_terceiros'])&&(F3Base_Options::ler('f3base_meta_pixel_id')===''||F3Base_Options::ler('f3base_meta_pixel_id')===F3Base_Modulo_Meta_Capi::pixel_id())&&F3Base_Modulo_Meta_Capi::token()&&!F3Base_Options::ler('f3base_meta_auto_config');$motivos=array();
        foreach(self::catalogo_ativo() as $name){$n=$e['eventos'][$name]??array();$valid=($n['elegiveis']??0)>=100&&($n['pixel']??0)>0&&($n['servidor']??0)>0&&($n['deduplicados']??0)>0&&($n['descartes_inexplicados']??1)===0&&abs(($n['pixel']??0)-($n['servidor']??0))/max(1,$n['elegiveis']??0)<=0.05;if(!$valid){$motivos[]=$name.': amostra, equivalência ou deduplicação insuficiente';}$ok=$ok&&$valid;}
        global $wpdb;if($start&&$end){foreach(self::catalogo_ativo() as $name){
            $t=$wpdb->prefix.'f3base_meta_eventos';$q=F3Base_Capi_Fila::tabela();
            $local=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE nome=%s AND rota='ambos' AND classe_trafego='nao_marcado' AND criado_em>=%d AND criado_em<=%d",$t,$name,$start,$end));
            $unsettled=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i e WHERE e.nome=%s AND e.rota='ambos' AND e.classe_trafego='nao_marcado' AND e.criado_em>=%d AND e.criado_em<=%d AND NOT EXISTS (SELECT 1 FROM %i f WHERE f.evento_hash=e.evento AND f.evento_nome=e.nome AND f.classe_trafego=e.classe_trafego AND f.rota='ambos' AND f.estado='entregue')",$t,$name,$start,$end,$q));
            if($wpdb->last_error||$local<100||$unsettled>0||($e['eventos'][$name]['elegiveis']??0)!==$local){$ok=false;$motivos[]=$name.': evidência local insuficiente, volume divergente ou desfecho não conciliado por evento';}
        }}
        if(!$ok){return array('ok'=>false,'codigo'=>'homologacao_incompleta','motivos'=>$motivos);}
        $p=array('aprovada'=>true,'contexto'=>self::contexto(),'registrada_em'=>time(),'operador'=>get_current_user_id(),'origem'=>'evidencia_externa_declarada_por_operador','dados'=>$e,'verificacao_api_automatica'=>false);
        $r=F3Base_Options::atualizar_estado('f3base_meta_homologacao',static fn()=>$p);return array('ok'=>!empty($r['persisted']),'prova'=>$p,'proximo'=>'Ativar servidor explicitamente e conferir ausência de fbevents.js e resultados por sete dias.');
    }
    /** Compare only observed provider days, in its timezone. Two SQL aggregates per dataset/timezone, no provider I/O. */
    private static function comparar_recebido(array $remote): array {
        global $wpdb;$groups=array();$partial=false;$reasons=array();
        foreach($remote['datasets']??array() as $dataset=>$result){
            $partial=$partial||!empty($result['proximo_cursor']);if(empty($result['ok'])){$reasons[(string)$dataset]=$result['codigo']??'indisponivel';continue;}
            foreach($result['linhas']??array() as $line){$row=$line['row']??array();if(($row['record_kind']??'')!=='event_counts'||!in_array($row['event_name']??'',self::CATALOGO,true)){continue;}
                $day=$line['data_day']??'';$timezone=$line['timezone']??'';
                try{if(!F3Base_Gsc::data_valida($day)||!is_string($timezone)||$timezone===''){continue;}$start=new DateTimeImmutable($day,new DateTimeZone($timezone));$end=$start->modify('+1 day');}catch(Throwable $x){continue;}
                $key=$dataset.'|'.$timezone;$groups[$key]['dataset']=(string)$dataset;$groups[$key]['fuso']=$timezone;
                $groups[$key]['dias'][$day]=array($start->getTimestamp(),$end->getTimestamp());$groups[$key]['linhas'][]=$line;
            }
        }
        $out=array();foreach($groups as $g){$cases=array();$bounds=array();$first=PHP_INT_MAX;$last=0;
            foreach($g['dias'] as $day=>$range){$cases[]='WHEN __TIME__ >= %d AND __TIME__ < %d THEN %s';array_push($bounds,$range[0],$range[1],$day);$first=min($first,$range[0]);$last=max($last,$range[1]);}
            $case='CASE '.implode(' ',$cases).' END';$local=array();
            $sql='SELECT '.str_replace('__TIME__','criado_em',$case).' dia,nome,rota,classe_trafego,COUNT(*) capturados,SUM(navegador_observado) disparados FROM %i WHERE pixel_id=%s AND criado_em>=%d AND criado_em<%d GROUP BY dia,nome,rota,classe_trafego';
            $rows=$wpdb->get_results($wpdb->prepare($sql,array_merge($bounds,array($wpdb->prefix.'f3base_meta_eventos',$g['dataset'],$first,$last))),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_local_indisponivel','linhas'=>array());}
            foreach($rows as $row){if($row['dia']===null){continue;}$key=$row['dia'].'|'.$row['nome'];$group=$row['rota'].'|'.$row['classe_trafego'];$local[$key][$group]=array('rota'=>$row['rota'],'classe_trafego'=>$row['classe_trafego'],'capturados'=>(int)$row['capturados'],'disparados_no_navegador'=>(int)$row['disparados'],'enfileirados'=>0,'aceitos_servidor'=>0);}
            $sql="SELECT ".str_replace('__TIME__','evento_em',$case)." dia,evento_nome,rota,classe_trafego,COUNT(*) enfileirados,SUM(estado='entregue') aceitos FROM %i WHERE pixel_id=%s AND evento_em>=%d AND evento_em<%d GROUP BY dia,evento_nome,rota,classe_trafego";
            $rows=$wpdb->get_results($wpdb->prepare($sql,array_merge($bounds,array(F3Base_Capi_Fila::tabela(),$g['dataset'],$first,$last))),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_local_indisponivel','linhas'=>array());}
            foreach($rows as $row){if($row['dia']===null){continue;}$key=$row['dia'].'|'.$row['evento_nome'];$group=$row['rota'].'|'.$row['classe_trafego'];$local[$key][$group]??=array('rota'=>$row['rota'],'classe_trafego'=>$row['classe_trafego'],'capturados'=>null,'disparados_no_navegador'=>null);$local[$key][$group]['enfileirados']=(int)$row['enfileirados'];$local[$key][$group]['aceitos_servidor']=(int)$row['aceitos'];}
            foreach($g['linhas'] as $line){$row=$line['row'];$day=$line['data_day'];$out[]=array('dataset_id'=>$g['dataset'],'dia'=>$day,'fuso'=>$g['fuso'],'inicio'=>$g['dias'][$day][0],'fim_exclusivo'=>$g['dias'][$day][1],'evento'=>$row['event_name'],
                'local'=>array_values($local[$day.'|'.$row['event_name']]??array()),'recebido_meta'=>array('navegador'=>$row['browser_count']??null,'servidor'=>$row['server_count']??null,'unicos'=>null,'cobertura'=>$row['count_coverage']??null,'classes_locais'=>'nao_discriminadas_pelo_fornecedor'),'observado_em'=>$line['last_seen']??$line['observed_at']??$line['updated_at']??null);}
        }
        return array('ok'=>true,'linhas'=>$out,'parcial'=>$partial,'indisponiveis'=>$reasons,'continuar_em'=>$partial?'f3base/meta-monitoramento-ler':null,'nota'=>'Contagens externas conservam a cobertura do produtor e abrangem o dataset inteiro; não são prova individual de event_id. Local sem linhas significa nenhuma observação registrada, não ausência de contatos elegíveis.');
    }
    public static function relatorio(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}try{$j=F3Base_Relatorios::janela($e);}catch(Throwable $x){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT DATE(DATE_ADD(\'1970-01-01\',INTERVAL criado_em SECOND)) dia_utc,nome,rota,classe_trafego,COUNT(*) capturados,SUM(navegador_observado) disparos_observados FROM %i WHERE criado_em>=%d AND criado_em<%d GROUP BY dia_utc,nome,rota,classe_trafego ORDER BY dia_utc,nome',$wpdb->prefix.'f3base_meta_eventos',$j['inicio'],$j['fim']),ARRAY_A);
        $fila=$wpdb->get_results($wpdb->prepare('SELECT DATE(DATE_ADD(\'1970-01-01\',INTERVAL evento_em SECOND)) dia_utc,evento_nome,rota,classe_trafego,estado,COUNT(*) quantidade FROM %i WHERE evento_em>=%d AND evento_em<%d GROUP BY dia_utc,evento_nome,rota,classe_trafego,estado',F3Base_Capi_Fila::tabela(),$j['inicio'],$j['fim']),ARRAY_A);
        if(!is_array($rows)||!is_array($fila)||$wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}
        $stages=array();foreach($rows as $row){$key=$row['dia_utc'].'|'.$row['nome'].'|'.$row['rota'].'|'.$row['classe_trafego'];$stages[$key]=array('dia_utc'=>$row['dia_utc'],'evento'=>$row['nome'],'rota'=>$row['rota'],'classe_trafego'=>$row['classe_trafego'],'elegiveis_observados'=>(int)$row['capturados'],'elegiveis_totais'=>null,'capturados'=>(int)$row['capturados'],'disparados_no_navegador'=>(int)$row['disparos_observados'],'enfileirados'=>0,'aceitos'=>0,'pendentes'=>0,'rejeitados'=>0,'expirados'=>0,'outros_desfechos'=>0);}foreach($fila as $row){$key=$row['dia_utc'].'|'.$row['evento_nome'].'|'.$row['rota'].'|'.$row['classe_trafego'];if(!isset($stages[$key])){$stages[$key]=array('dia_utc'=>$row['dia_utc'],'evento'=>$row['evento_nome'],'rota'=>$row['rota'],'classe_trafego'=>$row['classe_trafego'],'elegiveis_observados'=>null,'elegiveis_totais'=>null,'capturados'=>null,'disparados_no_navegador'=>null,'enfileirados'=>0,'aceitos'=>0,'pendentes'=>0,'rejeitados'=>0,'expirados'=>0,'outros_desfechos'=>0);}$stages[$key]['enfileirados']+=(int)$row['quantidade'];$bucket=$row['estado']==='entregue'?'aceitos':(in_array($row['estado'],array('pendente','reservado','enviando','suspenso'),true)?'pendentes':($row['estado']==='falhou'?'rejeitados':($row['estado']==='expirado'?'expirados':'outros_desfechos')));$stages[$key][$bucket]+=(int)$row['quantidade'];}
        $details=array();$next=null;if(($e['modo']??'')==='eventos'){
            $page=max(1,(int)($e['pagina']??1));$local=$wpdb->prefix.'f3base_meta_eventos';$queue=F3Base_Capi_Fila::tabela();
            // Keep all existing server receipts, and add local events that have no server receipt.
            $sql="SELECT q.record_id,q.evento_hash,q.evento_nome,q.evento_em,q.rota,q.classe_trafego,q.estado,q.tentativas,q.http,q.expira,q.prazo_regra,q.motivo,q.pixel_id,q.telefone_estado,NULLIF(e.event_id,'') event_id,e.criado_em capturado_em,e.navegador_observado,e.pixel_id pixel_navegador_id,'servidor' origem_recibo
                FROM %i q LEFT JOIN %i e ON e.evento=q.evento_hash AND e.nome=q.evento_nome AND e.classe_trafego=q.classe_trafego
                WHERE q.evento_em>=%d AND q.evento_em<%d
                UNION ALL
                SELECT NULL,e.evento,e.nome,e.criado_em,e.rota,e.classe_trafego,'observado_local',0,NULL,NULL,NULL,NULL,NULL,NULL,NULLIF(e.event_id,''),e.criado_em,e.navegador_observado,e.pixel_id,'local'
                FROM %i e WHERE e.criado_em>=%d AND e.criado_em<%d AND NOT EXISTS(SELECT 1 FROM %i q WHERE q.evento_hash=e.evento AND q.evento_nome=e.nome AND q.classe_trafego=e.classe_trafego)
                ORDER BY evento_em,evento_hash,record_id LIMIT 101 OFFSET %d";
            $details=$wpdb->get_results($wpdb->prepare($sql,$queue,$local,$j['inicio'],$j['fim'],$local,$j['inicio'],$j['fim'],$queue,($page-1)*100),ARRAY_A);
            if($wpdb->last_error||!is_array($details)){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}
            $next=count($details)>100?$page+1:null;$details=array_slice($details,0,100);
            foreach($details as &$detail){$detail['navegador_observado']=$detail['navegador_observado']===null?null:(bool)$detail['navegador_observado'];$detail['identificador_disponivel']=$detail['event_id']!==null;}unset($detail);
        }
        $remote=F3Base_Meta_Monitoramento::qualidade($e);$comparison=self::comparar_recebido($remote);

        return array('agenda'=>F3Base_Capi_Fila::agenda(),'diario'=>array_values($stages),'eventos'=>$details,'proxima_pagina'=>$next,'ok'=>!$wpdb->last_error,'periodo'=>$j,'captura'=>$rows,'fila'=>$fila,'elegiveis_nao_observados'=>null,'recebido_meta'=>$remote,'comparacao_meta'=>$comparison,'fuso_diario'=>'UTC','emq'=>null,'prova'=>F3Base_Options::ler('f3base_meta_homologacao'),'prazo'=>self::prazo(time(),self::config()['modo']??'navegador'),'aviso'=>'Disparo local/beacon não prova entrega. Recusas anteriores à captura não fornecem denominador completo; elegíveis não observados permanecem indisponíveis. Recebimento e EMQ dependem da concessão de monitoramento Meta; snapshots conservam a data de observação. Event_id exato existe nas observações novas; histórico sem identificador ou identidade eliminada retorna null. Comparação usa o dia e fuso do produtor, sem somar browser e servidor como pessoas únicas ou atribuir contagens externas a uma classe local.');
    }
}
