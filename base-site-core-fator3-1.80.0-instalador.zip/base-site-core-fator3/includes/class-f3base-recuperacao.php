<?php
/** Barreira local independente do banco restaurado e dos arquivos do plugin. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Recuperacao {
    public const SO_ATENDIMENTO=array('trava_inacessivel','trava_falhou','protecao_degradada','guarda_sem_permissao');
    private static $trabalho=null;
    private static int $profundidade=0;
    private static bool $modulos=false;
    private static string $entrada='nao_tentada';
    private static string $provisao='';
    private static ?array $leitura=null;
    public static function marcar_modulos(): void { self::$modulos=true; }
    private static function base(): string {return WP_CONTENT_DIR.'/f3-core-state/site-'.get_current_blog_id();}
    public static function ler(): array {
        if(self::$leitura===null){self::$leitura=self::ler_disco();}
        return array_replace(self::$leitura,array('modulos_inicializados'=>self::$modulos,'entrada_requisicao'=>self::$entrada,'provisionamento'=>self::$provisao));
    }
    private static function ler_disco(): array {
        $p=self::base().'.php';$dir=dirname($p);
        if(!is_link($dir)&&is_dir($dir)&&(!is_readable($dir)||!is_executable($dir)||(!is_link($p)&&is_file($p)&&!is_readable($p)))){
            return array('ok'=>false,'pausado'=>true,'estado_da_guarda'=>'desconhecido','codigo'=>'guarda_sem_permissao','modo'=>'atendimento','modulos_inicializados'=>self::$modulos,'captura_pronta'=>F3Base_Leads_Repositorio::pronto(),'tarefas'=>false,'entregas'=>false,'migracao'=>false,'pronto_para_restaurar'=>false,'geracao'=>null,'precondicao'=>self::precondicao(),'acao_disponivel'=>'corrigir_permissoes');
        }
        $pre=self::precondicao();$protecao=self::protecao();
        if($protecao['codigo']==='diretorio_sentinela_link_recusado'){return array('ok'=>false,'pausado'=>true,'codigo'=>$protecao['codigo'],'protecao'=>$protecao,'precondicao'=>$pre,'pronto_para_restaurar'=>false,'geracao'=>0);}
        if(!is_file($p)||is_link($p)){return array('ok'=>false,'pausado'=>true,'codigo'=>is_link($p)?'sentinela_link_recusado':(file_exists($p)?'sentinela_ilegivel':'sentinela_ausente'),'precondicao'=>$pre,'modulos_inicializados'=>false,'acao_disponivel'=>'recriar','geracao'=>0,'pronto_para_restaurar'=>false);}
        $raw=@file_get_contents($p);$s=is_string($raw)&&str_starts_with($raw,"<?php exit; ?>\n")?json_decode(substr($raw,14),true):null;
        if(!is_array($s)||!isset($s['geracao'],$s['pausado'])){return array('ok'=>false,'pausado'=>true,'codigo'=>is_readable($p)?'sentinela_invalida':'sentinela_ilegivel','precondicao'=>$pre,'modulos_inicializados'=>false,'acao_disponivel'=>'recriar','geracao'=>0,'pronto_para_restaurar'=>false);}
        unset($s['ok'],$s['codigo'],$s['modulos_inicializados'],$s['precondicao'],$s['entrada_requisicao'],$s['provisionamento']);
        return array_merge($s,array('ok'=>true,'protecao'=>$protecao,'precondicao'=>$pre,'modulos_inicializados'=>self::$modulos,'entrada_requisicao'=>self::$entrada,'provisionamento'=>self::$provisao,'codigo'=>(!empty($s['pausado'])?'core_pausado':(in_array(self::$entrada,array('trava_inacessivel','trava_ocupada','trava_falhou','protecao_degradada'),true)?self::$entrada:'core_operacional')),'acao_disponivel'=>!empty($s['pausado'])?'preparar_ou_retomar':'preparar','escopo'=>'Somente tarefas e mutações do Site Core. Google e MCP exigem seus próprios procedimentos.'));
    }
    public static function precondicao(): string {
        $p=self::base().'.php';$raw=is_file($p)&&!is_link($p)?@file_get_contents($p):false;
        return hash('sha256',wp_json_encode(array('existe'=>file_exists($p),'link'=>is_link($p),'legivel'=>is_readable($p),'sha256'=>is_string($raw)?hash('sha256',$raw):null)));
    }
    public static function protecao(): array {
        $dir=dirname(self::base());$p=$dir.'/index.php';$codigo='indice_protetor_confirmado';
        if(is_link($dir)){$codigo='diretorio_sentinela_link_recusado';}
        elseif(!is_dir($dir)||!is_readable($dir)){$codigo='diretorio_sentinela_indisponivel';}
        elseif(is_link($p)){$codigo='indice_protetor_link_recusado';}
        elseif(!is_file($p)||!is_readable($p)){$codigo='indice_protetor_indisponivel';}
        elseif(@file_get_contents($p)!=="<?php http_response_code(404); exit;\n"){$codigo='indice_protetor_divergente';}
        return array('confirmada'=>$codigo==='indice_protetor_confirmado','codigo'=>$codigo,'severidade'=>$codigo==='indice_protetor_confirmado'?'ok':'critica','http_verificado'=>false,'acao'=>$codigo==='indice_protetor_confirmado'?'Índice em disco conferido; a proteção HTTP tem prova própria.':'Confira a proteção HTTP do diretório. Conteúdo desconhecido não é sobrescrito automaticamente.');
    }
    private static function indice(): bool {
        $p=dirname(self::base()).'/index.php';if(!file_exists($p)&&!is_link($p)){$f=@fopen($p,'x');if($f){fwrite($f,"<?php http_response_code(404); exit;\n");fclose($f);}}
        return self::protecao()['confirmada'];
    }
    private static function recriar(array $e): array {
        $s=self::ler();if(!empty($s['ok'])&&!in_array($s['entrada_requisicao']??'',array('trava_inacessivel','trava_falhou'),true)){return array('ok'=>false,'codigo'=>($s['entrada_requisicao']??'')==='trava_ocupada'?'aguardando_drenagem':'sentinela_existente','recuperacao'=>$s);}
        if(($e['reconciliacao_confirmada']??null)!==true||!is_bool($e['copia_outro_host']??null)){return array('ok'=>false,'codigo'=>'confirmacao_recriacao_necessaria');}
        $expected=$e['precondicao_esperada']??'';if(!is_string($expected)||!hash_equals(self::precondicao(),$expected)){return array('ok'=>false,'codigo'=>'precondicao_divergente','recuperacao'=>$s);}
        $dir=dirname(self::base());if(is_link($dir)||is_link(self::base().'.php')||(!is_dir($dir)&&!wp_mkdir_p($dir))){return array('ok'=>false,'codigo'=>'diretorio_sentinela_indisponivel');}self::indice();if(is_link($dir.'/index.php')){return array('ok'=>false,'codigo'=>'indice_protetor_link_recusado');}
        if(is_link(self::base().'-state.php')||is_link(self::base().'-workers.php')){return array('ok'=>false,'codigo'=>'trava_link_recusado','acao'=>'Corrija o arquivo de trava na hospedagem; a recriação não segue links simbólicos.');}
        while(self::$trabalho){self::sair();}
        $f=@fopen(self::base().'-state.php','c+');if(!$f||!flock($f,LOCK_EX|LOCK_NB)){if($f){fclose($f);}return array('ok'=>false,'codigo'=>'barreira_ocupada');}
        $w=null;try{
            if(!hash_equals(self::precondicao(),$expected)){return array('ok'=>false,'codigo'=>'precondicao_divergente','recuperacao'=>self::ler());}
            $w=@fopen(self::base().'-workers.php','c+');if(!$w||!flock($w,LOCK_EX|LOCK_NB)){return array('ok'=>false,'codigo'=>'aguardando_drenagem');}
            $state=array('geracao'=>max(1,time()),'pausado'=>true,'pronto_para_restaurar'=>false,'atualizado_em'=>time(),'recriada_em'=>time(),'etapa'=>'suspender_filas');
            if(!self::gravar($state)){return array('ok'=>false,'codigo'=>'sentinela_gravacao_falhou');}
            $invalid=self::invalidar();if(empty($invalid['ok'])){return $invalid+array('recuperacao'=>self::ler());}
            if($e['copia_outro_host']){
                $identity=F3Base_Options::atualizar_estado('f3base_pipedrive_estado',static function($v){$v['instalacao']=wp_generate_uuid4();$v['host_instalacao']=wp_parse_url(home_url('/'),PHP_URL_HOST);$v['estado']='pendente';$v['codigo']='copia_requer_verificacao';unset($v['catalogos']);return $v;});
                if(empty($identity['persisted'])){return array('ok'=>false,'codigo'=>'identidade_nao_persistida','recuperacao'=>self::ler());}
            }
            $state['pausado']=!empty($e['manter_pausado']);$state['etapa']='concluida';$state['reconciliacao_confirmada_em']=time();$ok=self::gravar($state);if($ok&&empty($state['pausado'])){F3Base_Operacao_Intencoes::retomar();}$read=self::ler();
            return array('ok'=>$ok&&!empty($read['ok'])&&$read['pausado']===!empty($e['manter_pausado']),'codigo'=>$ok?'sentinela_recriada':'sentinela_gravacao_falhou','filas_externas'=>'suspensas_ate_reconciliacao','efeitos'=>$invalid['efeitos']??array(),'nova_requisicao_necessaria'=>true,'recuperacao'=>$read);
        }finally{if($w){flock($w,LOCK_UN);fclose($w);}flock($f,LOCK_UN);fclose($f);}
    }
    private static function gravar(array $s): bool {
        self::$leitura=null;clearstatcache(true,self::base().'.php');clearstatcache(true,dirname(self::base()));
        $s=array_intersect_key($s,array_flip(array('geracao','pausado','pronto_para_restaurar','atualizado_em','recriada_em','etapa','reconciliacao_confirmada_em')));
        $p=self::base().'.php';$tmp=$p.'.'.bin2hex(random_bytes(8)).'.php';$raw="<?php exit; ?>\n".wp_json_encode($s);
        if(file_put_contents($tmp,$raw,LOCK_EX)!==strlen($raw)){@unlink($tmp);return false;}@chmod($tmp,0600);$ok=rename($tmp,$p);clearstatcache(true,$p);self::$leitura=null;if(!$ok){@unlink($tmp);}return $ok;
    }
    public static function provisionar(): bool {
        self::$leitura=null;
        $dir=dirname(self::base());if(is_link($dir)||(!is_dir($dir)&&!wp_mkdir_p($dir))){self::$provisao='diretorio_sentinela_indisponivel';return false;}
        self::indice();self::$provisao=self::protecao()['codigo'];if(is_link($dir.'/index.php')){return false;}
        if(is_file(self::base().'.php')){return !empty(self::ler()['ok']);}
        // Never recreate a missing sentinel after a completed 1.20 installation.
        if(F3Base_Instalacao::origem()!=='nova'){return false;}
        $l=@fopen(self::base().'-state.php','c+');if(!$l||!flock($l,LOCK_EX)){return false;}
        try{return is_file(self::base().'.php')||self::gravar(array('geracao'=>1,'pausado'=>false,'pronto_para_restaurar'=>false,'atualizado_em'=>time()));}finally{flock($l,LOCK_UN);fclose($l);}
    }
    public static function entrar(): bool {
        if(self::$trabalho){++self::$profundidade;return true;}
        $s=self::ler();if(empty($s['ok'])||!empty($s['pausado'])){self::$entrada=$s['codigo'];return false;}
        if(in_array($s['protecao']['codigo']??'',array('diretorio_sentinela_indisponivel','indice_protetor_link_recusado'),true)){self::$entrada='protecao_degradada';return false;}
        if(is_link(self::base().'-workers.php')){self::$entrada='trava_inacessivel';return false;}
        $f=@fopen(self::base().'-workers.php','c+')?:@fopen(self::base().'-workers.php','r');if(!$f){self::$entrada='trava_inacessivel';return false;}
        $blocked=0;if(!flock($f,LOCK_SH|LOCK_NB,$blocked)){self::$entrada=$blocked?'trava_ocupada':'trava_falhou';fclose($f);return false;}
        self::$leitura=null;$s=self::ler();if(empty($s['ok'])||!empty($s['pausado'])){flock($f,LOCK_UN);fclose($f);return false;}
        self::$entrada='entrada_confirmada';self::$trabalho=$f;self::$profundidade=1;return true;
    }
    public static function atendimento(): bool {if(self::$trabalho){return true;}if(!in_array(self::$entrada,self::SO_ATENDIMENTO,true)){return false;}$s=self::ler();return ($s['codigo']??'')==='guarda_sem_permissao'||(!empty($s['ok'])&&empty($s['pausado']));}
    public static function sair(): void {if(self::$trabalho&&--self::$profundidade<=0){flock(self::$trabalho,LOCK_UN);fclose(self::$trabalho);self::$trabalho=null;self::$profundidade=0;}}
    public static function executar(callable $callback,...$args){if(!self::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao','recuperacao'=>self::ler());}try{return $callback(...$args);}finally{self::sair();}}
    public static function operar(array $e): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(($e['acao']??'')==='recriar'){return self::recriar($e);}if(!is_int($e['geracao_esperada']??null)){return array('ok'=>false,'codigo'=>'geracao_invalida');}
        if(is_link(self::base().'-state.php')||is_link(self::base().'-workers.php')){return array('ok'=>false,'codigo'=>'trava_link_recusado','acao'=>'Corrija o arquivo de trava na hospedagem; a recriação não segue links simbólicos.');}
        while(self::$trabalho){self::sair();}
        $f=@fopen(self::base().'-state.php','c+');if(!$f||!flock($f,LOCK_EX|LOCK_NB)){if($f){fclose($f);}self::entrar();return array('ok'=>false,'codigo'=>'barreira_ocupada');}
        try{
            $s=self::ler();if(empty($s['ok'])||(int)($e['geracao_esperada']??0)!==(int)$s['geracao']){return array('ok'=>false,'codigo'=>'geracao_divergente','recuperacao'=>$s);}
            $acao=$e['acao']??'';if(!in_array($acao,array('preparar','retomar'),true)){return array('ok'=>false,'codigo'=>'acao_invalida');}
            if($acao==='retomar'&&empty($e['reconciliacao_confirmada'])){return array('ok'=>false,'codigo'=>'reconciliacao_externa_nao_confirmada');}
            if($acao==='preparar'){$s['pausado']=true;$s['pronto_para_restaurar']=false;$s['atualizado_em']=time();if(!self::gravar($s)){return array('ok'=>false,'codigo'=>'barreira_nao_persistida');}}
            $w=@fopen(self::base().'-workers.php','c+');if(!$w||!flock($w,LOCK_EX|LOCK_NB)){if($w){fclose($w);}return array('ok'=>false,'codigo'=>'aguardando_drenagem','recuperacao'=>self::ler());}
            try{
                if($acao==='retomar'){
                    if(empty($s['pausado'])){return array('ok'=>true,'codigo'=>'ja_retomado','recuperacao'=>$s);}
                    $r=self::invalidar();if(empty($r['ok'])){return $r;}
                    ++$s['geracao'];$s['pausado']=false;$s['pronto_para_restaurar']=false;$s['reconciliacao_confirmada_em']=time();
                }else{$s['pronto_para_restaurar']=true;}
                $s['atualizado_em']=time();$ok=self::gravar($s);if($ok&&$acao==='retomar'){F3Base_Operacao_Intencoes::retomar();}return array('ok'=>$ok,'codigo'=>$ok?($acao==='preparar'?'core_drenado':'core_retomado'):'sentinela_gravacao_falhou','recuperacao'=>self::ler(),'efeitos'=>$r['efeitos']??array());
            }finally{flock($w,LOCK_UN);fclose($w);}
        }finally{flock($f,LOCK_UN);fclose($f);if(empty(self::ler()['pausado'])){self::entrar();}}
    }
    private static function invalidar(): array {
        global $wpdb;$defs=array(
            'meta'=>array($wpdb->prefix.'f3base_capi_fila',"estado IN ('pendente','reservado','enviando','cancelando','processando','incerto')"),
            'linkedin'=>array($wpdb->prefix.'f3base_linkedin_webhook',"estado IN ('pendente','criando','incerto')"),
            'qualidade'=>array($wpdb->prefix.'f3base_qualidade_fila',"estado IN ('pendente','enviando','incerto')"),
            'slack_partes'=>array($wpdb->prefix.'f3base_avisos_partes',"estado IN ('pendente','enviando','incerto')"),
            'complementos'=>array($wpdb->prefix.'f3base_complementos',"estado IN ('pendente','enviando','incerto')"),
            'slack'=>array($wpdb->prefix.'f3base_avisos_fila',"estado IN ('pendente','reservado','enviando','incerto')"),
            'pipedrive'=>array($wpdb->prefix.'f3base_pipedrive_fila',"estado IN ('pendente','reservado','enviando','cancelando','processando','incerto')"),
            'avisos'=>array(F3Base_Leads_Repositorio::tabela(),"aviso IN ('pendente','enviando','aguarda_resumo')"),
            'respostas'=>array(F3Base_Leads_Repositorio::tabela(),"resposta IN ('pendente','enviando')"),
            'cursores_ga4'=>array($wpdb->prefix.'f3base_ga4_coletas',"estado IN ('em_curso','aguardando')"),
            'cursores_gsc'=>array($wpdb->prefix.'f3base_gsc_coletas',"estado IN ('em_curso','aguardando')"));
        $effects=array();foreach($defs as $key=>[$table,$where]){if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table){continue;}$n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE $where",$table));if($wpdb->last_error){return array('ok'=>false,'codigo'=>'inventario_recuperacao_falhou','etapa'=>$key,'efeitos'=>$effects);}$effects[$key]=array('selecionados'=>(int)$n,'modificados'=>0,'falhas'=>0,'incertos'=>0);}
        $r=self::invalidar_filas();foreach($effects as $key=>&$effect){[$table,$where]=$defs[$key];$left=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE $where",$table));if($wpdb->last_error){$effect['falhas']=$effect['selecionados'];continue;}$effect['modificados']=max(0,$effect['selecionados']-(int)$left);$effect['falhas']=empty($r['ok'])?(int)$left:0;if(in_array($key,array('avisos','respostas'),true)){$effect['incertos']=$effect['modificados'];}if(in_array($key,array('cursores_gsc','cursores_ga4'),true)){$effect['cursores_invalidados']=$effect['modificados'];}}unset($effect);
        return $r+array('efeitos'=>$effects,'etapa'=>empty($r['ok'])?($r['codigo']??'falha'):'filas_invalidadas');
    }
    private static function invalidar_filas(): array {

        global $wpdb;
        // External queues are deliberately held for explicit reconciliation, never replayed from a restored snapshot.
        foreach(array('capi_fila','pipedrive_fila','avisos_fila','avisos_partes','complementos','qualidade_fila','linkedin_webhook','email_site') as $suffix){$t=$wpdb->prefix.'f3base_'.$suffix;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){continue;}
            $cols=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if(in_array('estado',$cols,true)){$data=array('estado'=>'suspenso');if(in_array('motivo',$cols,true)){$data['motivo']='restauracao_requer_reconciliacao';}if(in_array('codigo',$cols,true)){$data['codigo']='restauracao_requer_reconciliacao';}if(in_array('reserva',$cols,true)){$data['reserva']='';}if(in_array('lease',$cols,true)){$data['lease']='';}if(in_array('lease_ate',$cols,true)){$data['lease_ate']=0;}$sets=array();foreach($data as $k=>$v){$sets[]=$wpdb->prepare('%i=%s',$k,$v);}if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET ".implode(',',$sets)." WHERE estado IN ('pendente','reservado','enviando','cancelando','processando','incerto')",$t))){return array('ok'=>false,'codigo'=>'fila_nao_suspensa');}}
        }
        if(class_exists('F3Base_Email_Site')&&!F3Base_Email_Site::suspender()){return array('ok'=>false,'codigo'=>'email_site_nao_suspenso');}
        $leads=F3Base_Leads_Repositorio::tabela();
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($leads)))===$leads){
            if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET aviso=IF(aviso IN ('pendente','enviando','aguarda_resumo'),'incerto',aviso),resposta=IF(resposta IN ('pendente','enviando'),'incerta',resposta),resposta_erro=IF(resposta IN ('pendente','enviando','incerta'),'restauracao_requer_reconciliacao',resposta_erro)",$leads))){return array('ok'=>false,'codigo'=>'avisos_nao_suspensos');}
            if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET entrega=JSON_SET(entrega,'$.pipedrive.reconciliacao_necessaria',true) WHERE JSON_VALID(entrega) AND JSON_UNQUOTE(JSON_EXTRACT(entrega,'$.pipedrive.solicitado'))='true'",$leads))){return array('ok'=>false,'codigo'=>'intencoes_nao_suspensas');}
        }
        $wpdb->query($wpdb->prepare("UPDATE %i SET dados=JSON_SET(dados,'$.aviso_intencao.reconciliacao_necessaria',true) WHERE JSON_VALID(dados) AND JSON_EXTRACT(dados,'$.aviso_intencao.elegivel')=true",$leads));if($wpdb->last_error){return array('ok'=>false,'codigo'=>'avisos_intencoes_nao_suspensas');}
        $crm=F3Base_Pipedrive_Fila::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($crm)))===$crm){if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET codigo='restauracao_requer_reconciliacao',estado='suspenso' WHERE codigo='eliminacao_remota_pendente'",$crm))){return array('ok'=>false,'codigo'=>'eliminacoes_nao_suspensas');}}
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($crm)))===$crm){
            $after='';do{$rows=$wpdb->get_results($wpdb->prepare("SELECT chave,journal FROM %i WHERE chave>%s AND (JSON_SEARCH(journal,'one','pendente',NULL,'$.avisos.*.estado') IS NOT NULL OR JSON_SEARCH(journal,'one','enviando',NULL,'$.avisos.*.estado') IS NOT NULL) ORDER BY chave LIMIT 100",$crm,$after),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'alertas_nao_suspensos');}
                foreach($rows as $row){$j=json_decode($row['journal'],true);foreach($j['avisos']??array() as $k=>$a){if(in_array($a['estado']??'',array('pendente','enviando'),true)){$j['avisos'][$k]['estado']='incerto';$j['avisos'][$k]['motivo']='restauracao_requer_reconciliacao';}}if(1!==$wpdb->update($crm,array('journal'=>wp_json_encode($j)),array('chave'=>$row['chave'],'journal'=>$row['journal']))){return array('ok'=>false,'codigo'=>'alertas_nao_suspensos');}$after=$row['chave'];}
            }while(count($rows)===100);
        }
        $alert=F3Base_Options::atualizar_estado('f3base_pipedrive_alerta_conta',static function($v){if(in_array($v['estado']??'',array('pendente','enviando'),true)){$v['estado']='incerto';$v['motivo']='restauracao_requer_reconciliacao';}return $v;});if(empty($alert['persisted'])){return array('ok'=>false,'codigo'=>'alerta_conta_nao_suspenso');}
        $ga4=$wpdb->prefix.'f3base_ga4_coletas';if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($ga4)))===$ga4&&false===$wpdb->query($wpdb->prepare("UPDATE %i SET estado='reiniciar',`cursor`='',codigo='restauracao',tentar_em=0 WHERE estado IN ('em_curso','aguardando')",$ga4))){return array('ok'=>false,'codigo'=>'cursor_ga4_nao_invalidado');}
        if(class_exists('F3Base_Gsc')&&!F3Base_Gsc::invalidar_curso('restauracao')){return array('ok'=>false,'codigo'=>'cursor_nao_invalidado');}
        $reset=F3Base_Options::atualizar_estado(F3Base_Operacao::OPTION,static fn()=>array());if(empty($reset['persisted'])){return array('ok'=>false,'codigo'=>'reservas_nao_invalidadas');}
        $intents=F3Base_Operacao_Intencoes::suspender();if(!$intents){return array('ok'=>false,'codigo'=>'intencoes_nao_invalidadas');}return array('ok'=>true);
    }
    private static string $erro_tarefa='reserva_indisponivel';
    private static ?array $dona_tarefa=null;
    public static function dona_tarefa(): ?array {return self::$dona_tarefa;}
    public static function identificar_reserva($f,array $dona): void {if(is_resource($f)){rewind($f);ftruncate($f,0);fwrite($f,'<?php exit; ?>'."\n".wp_json_encode($dona));fflush($f);}}
    public static function erro_tarefa(): string {return self::$erro_tarefa;}
    public static function reserva_arquivo(string $id): ?array {
        if(!isset(F3Base_Operacao::tarefas()[$id])){return null;}
        $path=self::base().'-task-'.$id.'.php';
        if(is_link($path)||!is_file($path)||!($file=@fopen($path,'r'))){return null;}
        try{
            if(flock($file,LOCK_SH|LOCK_NB)){flock($file,LOCK_UN);return null;}
            $raw=stream_get_contents($file,2048);$pos=strpos($raw,"\n");
            $owner=$pos===false?array():json_decode(substr($raw,$pos+1),true);
            return array('dono'=>$owner['run_id']??null,'desde'=>$owner['desde']??null,'ate'=>$owner['ate']??null);
        }finally{fclose($file);}
    }
    public static function reservar_tarefa(string $id,array $dona=array()){
        self::$dona_tarefa=null;
        if(!isset(F3Base_Operacao::tarefas()[$id])){return null;}$path=self::base().'-task-'.$id.'.php';if(is_link($path)){return null;}$f=@fopen($path,'c+');if(!$f){self::$erro_tarefa='trava_arquivo_inacessivel';return null;}$busy=0;if(!flock($f,LOCK_EX|LOCK_NB,$busy)){self::$erro_tarefa=$busy?'reserva_ocupada':'trava_arquivo_falhou';if($busy){rewind($f);$raw=stream_get_contents($f);$owner=json_decode(substr($raw,strpos($raw,"\n")+1),true);if(is_array($owner)&&($owner['ocorrencia']??'')===($dona['ocorrencia']??null)&&!empty($owner['run_id'])&&in_array($owner['origem']??'',array('cli','http_cron','manual'),true)){self::$dona_tarefa=$owner;}}fclose($f);return null;}if($dona){self::identificar_reserva($f,$dona);}return $f;
    }
    public static function liberar_tarefa($f): void {if(is_resource($f)){flock($f,LOCK_UN);fclose($f);}}
    public static function proteger_agenda(): void {
        add_filter('pre_unschedule_event',static function($pre,$at,$hook){return F3Base_Operacao::identificar_hook($hook)&&!empty(self::ler()['pausado'])?false:$pre;},1,3);
        add_filter('pre_reschedule_event',static function($pre,$event){return F3Base_Operacao::identificar_hook($event->hook)&&!empty(self::ler()['pausado'])?true:$pre;},1,2);
    }
    public static function admin_minimo(): void {
        add_action('admin_menu',static function(){add_menu_page('Fator3 Site Core — recuperação','Site Core','manage_options','f3base-recuperacao',static function(){if(!current_user_can('manage_options')){return;}echo '<div class="wrap"><h1>Recuperação do Site Core</h1><p>Consulte o estado abaixo. Ações de recuperação estão disponíveis em f3base/operacao-recuperacao e WP-CLI; exigem confirmação e revisão da guarda.</p><pre>'.esc_html(wp_json_encode(self::ler(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre><p>Documentação instalada: f3base/documentacao-ler.</p></div>';},'dashicons-shield');});
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('operacao-recuperacao-ler','Consultar barreira de recuperação do Core',array(__CLASS__,'ler'));
        F3Base_Servicos::ability('operacao-recuperacao','Pausar/drenar ou retomar o Core após reconciliação',array(__CLASS__,'operar'),array('acao'=>array('type'=>'string','enum'=>array('preparar','retomar','recriar')),'geracao_esperada'=>array('type'=>'integer','minimum'=>1),'reconciliacao_confirmada'=>array('type'=>'boolean'),'precondicao_esperada'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'copia_outro_host'=>array('type'=>'boolean'),'manter_pausado'=>array('type'=>'boolean','default'=>false)),array('acao'),false);
    }
}
