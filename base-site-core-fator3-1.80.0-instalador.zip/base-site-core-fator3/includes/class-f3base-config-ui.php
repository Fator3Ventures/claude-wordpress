<?php
/** Typed configuration editors. Transport values retain their existing revision and validation contract. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/class-f3base-anuncios-selecao.php';
require_once __DIR__.'/class-f3base-textos-contato.php';
final class F3Base_Config_UI {
    public static function rotulo(string $key): string {
        $labels=F3Base_Email_Novo_Lead_UI::rotulos()+F3Base_Pipedrive_Configuracao::rotulos()+array('ga4'=>'Google Analytics 4','google_ads'=>'Google Ads','meta'=>'Meta','linkedin'=>'LinkedIn','clarity'=>'Microsoft Clarity','capi'=>'Conversões da Meta pelo servidor','slack'=>'Slack','webhook'=>'Webhook de avisos','gtm'=>'Google Tag Manager','same_as'=>'Perfis oficiais','area_servida'=>'Área de atendimento','organizacao_mae'=>'Organização controladora','servicos'=>'Serviços','faq_schema'=>'Dados estruturados de perguntas frequentes','conhece_sobre'=>'Áreas de especialidade','ponto_de_contato'=>'Canais de contato','configuracao_completa'=>'Configuração completa','destinatarios_ultima_hora'=>'Destinatários na última hora','ultimo_erro'=>'Último erro','intencoes'=>'Intenções de envio','cota'=>'Cota reservada','revisao'=>'Em revisão','cancelando'=>'Cancelamento em andamento','campos'=>'Campos','formularios'=>'Formulários','campanhas'=>'Campanhas','ativo'=>'Ativar','tipo'=>'Tipo','campo'=>'Campo no CRM','valor'=>'Valor','chave'=>'Origem','nome'=>'Nome','id'=>'Identificador','fuso'=>'Fuso horário','dias'=>'Dias da semana','inicio'=>'Início do atendimento','fim'=>'Fim do atendimento','minutos'=>'Prazo em minutos','retomada'=>'Horário de retomada','email'=>'E-mail','whatsapp'=>'WhatsApp','task'=>'Tarefa','assunto'=>'Assunto','site'=>'Site','servico'=>'Serviço','parceiro'=>'Parceiro','canal'=>'Canal','ponto'=>'Ponto de conversão','campanha'=>'Campanha','anuncio'=>'Anúncio','unidade'=>'Unidade','mapa_campos'=>'Campos comerciais','mapa_pessoa'=>'Campos da pessoa','mapa_respostas'=>'Respostas dos formulários','mapa_servicos'=>'Serviços','mapa_parceiros'=>'Parceiros','mapa_canais'=>'Canais de origem','mapa_pontos'=>'Pontos de conversão','parceiros_plataforma'=>'Parceiro por plataforma','campos_fixos'=>'Valores fixos no CRM','mapa_servicos_formularios'=>'Serviço por formulário','mapa_servicos_campanhas'=>'Serviço por campanha','atividade_canais'=>'Atividade por canal','atividade_janela'=>'Horários do atendimento','alternativas'=>'Alternativas','formato'=>'Formato','moeda'=>'Moeda','ausente'=>'Não configurado','disponivel'=>'Disponível','recadastrar'=>'Cadastre novamente','pendente'=>'Pendente','incerto'=>'Aguardando confirmação','falhou'=>'Falha','recusado'=>'Recusado','entregue'=>'Entregue','enviando'=>'Em envio','cancelado'=>'Cancelado','suspenso'=>'Suspenso','nao_informada'=>'Não informada','selecionados'=>'Somente selecionados','todos_paginas_autorizadas'=>'Todos das páginas autorizadas','tls'=>'TLS (STARTTLS)','ssl'=>'SSL','recusar'=>'Recusar','enviar'=>'Enviar','titulo'=>'Título','explicacao'=>'Explicação','aceitar'=>'Botão permitir','recusar_texto'=>'Botão recusar','fechar'=>'Botão fechar','politica'=>'Texto do link da política','salvar'=>'Botão salvar escolhas','medicao'=>'Categoria de medição','publicidade'=>'Categoria de publicidade','essenciais'=>'Descrição das funções essenciais','controle'=>'Texto do controle no rodapé');
        if(isset($labels[$key])){return $labels[$key];}return mb_convert_case(str_replace('_',' ',preg_replace('/^f3base_/','',$key)),MB_CASE_TITLE,'UTF-8');
    }
    public static function catalogo(array $c): array {
        // Complete base schemas before adding text properties (Implantador 2.11.0 alert).
        $c['f3base_consentimento']['schema_entrada'] = F3Base_Config_Contrato::schema_entrada($c['f3base_consentimento']);
        $c['f3base_consentimento']['schema_config'] = F3Base_Config_Contrato::schema_valor($c['f3base_consentimento']);

        $labels=array('titulo'=>'Título do painel','explicacao'=>'Explicação do painel','aceitar'=>'Botão permitir','recusar'=>'Botão recusar','fechar'=>'Botão fechar','estadoAtivo'=>'Estado: medição ligada','estadoNegado'=>'Estado: medição desligada','aviso'=>'Aviso da primeira visita','avisoOk'=>'Botão do aviso','politica'=>'Texto do link da política','salvar'=>'Botão salvar escolhas','finalidades'=>'Título das finalidades','medicao'=>'Nome da categoria de medição','publicidade'=>'Nome da categoria de publicidade','controle'=>'Texto do controle no rodapé');
        foreach($labels as $key=>$label){$field='texto_'.$key;$c['f3base_consentimento']['padrao'][$field]='';$c['f3base_consentimento']['subcampos'][$field]=array('tipo'=>'texto','rotulo'=>$label,'descricao'=>'Texto exibido ao visitante. Vazio usa o texto padrão da política escolhida.','impacto'=>'Personaliza a apresentação sem alterar as escolhas de privacidade.','exemplo'=>'Use uma frase curta e clara.');foreach(array('schema_config','schema_entrada') as $schema){$c['f3base_consentimento'][$schema]['properties'][$field]=array('type'=>'string','maxLength'=>1500);}}
        return F3Base_Textos_Contato::catalogo($c);
    }
    public static function menu(): void {
        remove_menu_page('f3base-leads');remove_menu_page('f3base-medicao');
        global $submenu,$menu;if(!current_user_can('manage_options')){foreach($menu as &$entry){if(($entry[2]??'')===F3Base_Admin_Tela::SLUG){$entry[1]=current_user_can('f3base_ler_leads')?'f3base_ler_leads':'f3base_gerir_formularios';}}unset($entry);}
        unset($submenu[F3Base_Admin_Tela::SLUG]);
        if(!current_user_can('manage_options')&&(current_user_can('f3base_ler_leads')||current_user_can('f3base_gerir_formularios'))){add_menu_page('Site Core','Site Core',current_user_can('f3base_ler_leads')?'f3base_ler_leads':'f3base_gerir_formularios',F3Base_Admin_Tela::SLUG,current_user_can('f3base_ler_leads')?array(F3Base_Leads_Admin::class,'tela'):array(F3Base_Leads_Admin::class,'formularios'),'dashicons-admin-generic');}
        // Configurações entra primeiro: com o destino do menu principal no primeiro item, o núcleo não cria o atalho "Site Core" para o mesmo endereço (1.79.0, A8).
        add_submenu_page(F3Base_Admin_Tela::SLUG,'Configurações','Configurações','manage_options',F3Base_Admin_Tela::SLUG,array(F3Base_Admin_Tela::class,'render'));
        add_submenu_page(F3Base_Admin_Tela::SLUG,'Contatos','Contatos',current_user_can('manage_options')?'manage_options':'f3base_ler_leads','f3base-leads',array(F3Base_Leads_Admin::class,'tela'));
        add_submenu_page(F3Base_Admin_Tela::SLUG,'Formulários','Formulários',current_user_can('manage_options')?'manage_options':'f3base_gerir_formularios','f3base-formularios',array(F3Base_Leads_Admin::class,'formularios'));
        add_submenu_page(F3Base_Admin_Tela::SLUG,'Relatórios','Relatórios','manage_options','f3base-medicao',array(F3Base_Admin_Medicao::class,'render'));
        add_submenu_page(F3Base_Admin_Tela::SLUG,'Operação','Operação','manage_options','f3base-operacao',static function(){$_GET['aba']='operacao';F3Base_Admin_Tela::render();});
    }
    public static function status(): string {
        if (F3Base_Interface::aba($_GET['secao']??null)!=='conexoes') { return ''; }
        $nome=F3Base_Integracoes::aba_atual($_GET['integracao']??null);
        if (!isset(F3Base_Integracoes::definicoes()[$nome])) { return ''; }
        if ($nome===F3Base_Linkedin::OPCAO) {
            $todas=F3Base_Linkedin_Integracoes::colecao(); $id=$_GET['linkedin_id']??(count($todas)===1?array_key_first($todas):null);
            if (!is_string($id) || !isset($todas[$id])) { return ''; }
            $texto=empty($todas[$id]['ativo'])?'Coleta LinkedIn desativada nesta integração.':'Coleta LinkedIn habilitada nesta integração. Consulte o estado dos formulários abaixo.';
        } else {
            $valor=F3Base_Options::ler($nome);
            if ($nome==='f3base_email_site') {
                $texto='Importação de e-mail '.(!empty($valor['ativo'])?'habilitada':'desativada').' · Envio '.(!empty($valor['envio_ativo'])?'habilitado':'desativado').'.';
            } else { $texto=!empty($valor['ativo'])?'Integração habilitada. Confira a última verificação na área de estado.':'Integração desativada. Confira os dados da conta antes de ativar.'; }
        }
        return '<p class="f3base-config-status">'.esc_html($texto).'</p>';
    }
    public static function centrais(string $area): array {
        if($area==='avisos'){return array('f3base_contato'=>array('email_leads'=>'Destinatários dos avisos por e-mail'));}
        if($area==='medicao-testes'){return array('f3base_pipedrive'=>array('homologacao'=>'Permitir contatos de teste no Pipedrive'),'f3base_email_novo_lead'=>array('homologacao_emails'=>'Caixas autorizadas para teste do e-mail automático'));}
        if($area!=='privacidade'){return array();}$out=array('f3base_retencao_meses'=>array('_valor'=>'Contatos — meses de armazenamento'),F3Base_Formulario_Tentativas::OPTION=>array('capturar_valores'=>'Tentativas e iscas — guardar o valor digitado'));
        foreach(F3Base_Options::catalogo() as $name=>$d){if(!F3Base_Options::operavel($name)){continue;}foreach($d['subcampos']??array() as $key=>$field){if(str_contains($key,'retencao')){$out[$name][$key]=$d['rotulo'].' — '.$field['rotulo'];}}}
        $out['f3base_pipedrive']['retencao_entregas_meses']='Entregas ao Pipedrive — meses do histórico técnico';return $out;
    }
    public static function central_campo(string $option,string $key): bool {
        return isset(self::centrais('avisos')[$option][$key])||isset(self::centrais('medicao-testes')[$option][$key])||isset(self::centrais('privacidade')[$option][$key]);
    }
    public static function central_tela(string $area): void { F3Base_Config_Central::render($area); }
    public static function salvar_central(): void { F3Base_Config_Central::salvar(); }
    public static function complementos(string $area): void {
        if($area==='contato'){F3Base_Textos_Contato::previa();}
        if($area==='medicao-tags'){echo '<section class="f3base-config-grupo"><h2>Conversões pelo servidor</h2>';foreach(array('ga4'=>'GA4','google_ads'=>'Google Ads') as $target=>$name){$c=F3Base_Conversoes_Transporte::capacidade($target);echo '<p><strong>'.esc_html($name).'</strong>: '.($c['ready']?'Destino pronto.':'Falta configurar ou validar o destino no Google.').' <a href="'.esc_url(admin_url('tools.php?page=wp-mcp-google-fator3&section=conversions'.($target==='ga4'?'#mp_secret':''))).'">Abrir credencial e validação do destino</a></p>';}$li=F3Base_Conversoes_Transporte::capacidade('linkedin');echo '<p><strong>LinkedIn</strong>: '.($li['ready']?'Destino pronto para deduplicação com o navegador.':'Envio aguardando o pacote LinkedIn: '.esc_html(str_replace('_',' ',$li['reason'])).'.').' O envio exige conexão autorizada, permissão rw_conversions e fonte Conversions API na mesma regra.</p>';echo '<p>O destino usa os identificadores configurados neste site. A consulta do estado não envia conversões.</p></section>';}
        if($area==='consentimento'){$c=F3Base_Options::ler('f3base_consentimento');echo '<section class="f3base-config-grupo"><h2>Prévia dos textos personalizados</h2><p>Exemplo de apresentação; salvar textos não altera as escolhas do visitante.</p>';foreach($c as $key=>$value){if(str_starts_with($key,'texto_')&&$value!==''){echo '<p><strong>'.esc_html(F3Base_Options::declaracao('f3base_consentimento')['subcampos'][$key]['rotulo']??self::rotulo($key)).':</strong> '.esc_html($value).'</p>';}}echo '</section>';}
    }
    public static function iniciar(): void {F3Base_Anuncios_Selecao::iniciar();add_action('admin_post_f3base_config_central',array(__CLASS__,'salvar_central'));add_action('admin_menu',array(__CLASS__,'menu'),1200);
        add_action('admin_enqueue_scripts',static function(){if(!str_contains((string)($_GET['page']??''),'f3base')&&($_GET['page']??'')!==F3Base_Admin_Tela::SLUG){return;}wp_enqueue_style('f3base-config143',F3BASE_PLUGIN_URL.'admin/assets/f3base-config143.css',array(),F3BASE_PLUGIN_VERSAO);wp_enqueue_style('f3base-painel',F3BASE_PLUGIN_URL.'admin/assets/f3base-painel.css',array(),F3BASE_PLUGIN_VERSAO);wp_enqueue_script('f3base-config143',F3BASE_PLUGIN_URL.'admin/assets/f3base-config143.js',array(),F3BASE_PLUGIN_VERSAO,true);});
    }
    /** Formulários vizinhos repetem os ids do núcleo (_wpnonce, submit): a segunda ocorrência em diante ganha sufixo estável. Com $pre_focavel, todo `pre` (que tem altura máxima e rolagem própria) recebe foco de teclado. */
    public static function ids_unicos(string $html, bool $pre_focavel=false): string {
        $vistos=array();
        $html=(string)preg_replace_callback('~\bid="(_wpnonce|submit|_wp_http_referer)"~',static function($m)use(&$vistos){$n=$vistos[$m[1]]=($vistos[$m[1]]??0)+1;return 1===$n?$m[0]:'id="'.$m[1].'-'.$n.'"';},$html);
        return $pre_focavel?(string)preg_replace('~<pre\b(?![^>]*\btabindex=)~','<pre tabindex="0"',$html):$html;
    }
    public static function capturar(callable $render): void {ob_start();try{$render();$html=(string)ob_get_clean();}catch(Throwable $e){ob_end_clean();throw $e;}echo self::html($html);}
    public static function html(string $html): string {
        // Keep machine transport hidden; structured controls use the same names and server-side schemas.
        $html=preg_replace_callback('~<textarea\b([^>]*)>(.*?)</textarea>~si',static function($m){$value=html_entity_decode($m[2],ENT_QUOTES|ENT_HTML5,'UTF-8');$json=json_decode($value);if(!is_object($json)&&!is_array($json)){return $m[0];}preg_match('~\bid="([^"]+)"~',$m[1],$id);preg_match('~\bname="([^"]+)"~',$m[1],$name);if(empty($name[1])){return $m[0];}$field=html_entity_decode($name[1],ENT_QUOTES,'UTF-8');$id=$id[1]??wp_unique_id('f3base-editor-');$schema=self::schema($field);$key=preg_replace('/.*\[([^\]]+)\]$/','$1',$field);$key=preg_replace('/^f3base-integ-/','',$key);
            $special=in_array($id,array('f3base-integ-mapa_campos','f3base-integ-mapa_pessoa','f3base-integ-mapa_respostas','f3base-definicoes'),true);
            if (!$special && !in_array($schema['type']??'',array('object','array'),true)) { return $m[0]; }
            return '<input type="hidden" id="'.esc_attr($id).'" name="'.esc_attr($field).'" value="'.esc_attr($value).'">'.($special?'':'<div class="f3base-structured" data-input="'.esc_attr($id).'" data-key="'.esc_attr($key).'" data-rotulado-por="'.esc_attr($id.'-rotulo').'" data-schema="'.esc_attr(wp_json_encode($schema)).'"></div><noscript>Ative JavaScript para editar este grupo com os controles da tela.</noscript>');
        },$html);
        // O rótulo de um editor estruturado deixa de ser `label for` de um campo oculto: vira o nome do grupo que o editor desenha, sem repetir o texto num `legend`.
        if(preg_match_all('~<div class="f3base-structured" data-input="([^"]+)"~',$html,$editores)){foreach($editores[1] as $alvo){$html=(string)preg_replace('~<label\b([^>]*)\bfor="'.preg_quote($alvo,'~').'"([^>]*)>([^<]*)</label>~','<span$1id="'.$alvo.'-rotulo"$2>$3</span>',$html,1);}}
        $html=preg_replace_callback('~<pre\b[^>]*>(.*?)</pre>~si',static function($m){$data=json_decode(html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'),true);return is_array($data)?self::estado($data):$m[0];},$html);
        $html=str_replace('<details><summary>Editar mapeamento avançado</summary>','<details open><summary>Editar mapeamento</summary>',$html);
        $html=str_replace(array('Editor avançado JSON','Editar mapeamento avançado','Mapa técnico dos campos','Mapa técnico','Confira o JSON','Use o JSON'),array('Dados do formulário','Editar mapeamento','Campos selecionados','Mapeamento','Confira o mapeamento','Use o editor de mapeamento'),$html);
        $html=preg_replace('~<span class="f3base-origem">.*?</span>~s','',$html);
        $html=preg_replace('~<details class="f3base-ajuda f3base-ajuda-tecnica">.*?</details>~s','',$html);
        if (!preg_match('/(?:class="f3base-structured"|class="f3base-catalog-picker"|id="f3base-(?:integ-mapa_(?:campos|pessoa|respostas)|definicoes)")/',$html)) { return $html; }
        $catalog=get_option('f3base_pipedrive_estado',array())['catalogos']??array();$forms=array_merge(F3Base_Options::ler('f3base_formularios'),F3Base_Anuncios_Catalogo::listar());
        $data=array('catalogo'=>$catalog,'pipedrive'=>F3Base_Options::ler('f3base_pipedrive'),'formularios'=>array_values($forms),'campanhas'=>F3Base_Options::ler('f3base_campanhas_nomes'),'conta'=>get_option('f3base_pipedrive_estado',array())['conta_id']??'','rotulos'=>array());
        foreach(array_merge(array_keys(F3Base_Pipedrive_Comercial::padroes()),array('ga4','google_ads','meta','linkedin','clarity','capi','slack','webhook','gtm','same_as','area_servida','organizacao_mae','servicos','faq_schema','conhece_sobre','ponto_de_contato')) as $key){$data['rotulos'][$key]=self::rotulo($key);}
        return $html.'<script type="application/json" id="f3base-editor-catalogo">'.wp_json_encode($data,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>';
    }
    private static function schema_mapeamento(): array {
        $fields=array('type'=>'object','additionalProperties'=>array('type'=>'string','enum'=>array('nome','email','telefone','empresa','cargo','servicos')));
        return array('type'=>'object','properties'=>array('campos'=>$fields,'campanhas'=>array('type'=>'object','additionalProperties'=>array('type'=>'string')),'formularios'=>array('type'=>'object','additionalProperties'=>array('type'=>'object','properties'=>array('campos'=>$fields,'sem_nome'=>array('type'=>'string','enum'=>array('recusar','enviar')))))));
    }
    private static function schema(string $name): array {
        if(preg_match('/^config\[([^\]]+)\]/',$name,$m)){$n=F3Base_Integracoes::aba_atual($_GET['integracao']??null);$schema=F3Base_Integracoes::definicoes()[$n]['props'][$m[1]]??array();if($m[1]==='mapeamento'){$schema=self::schema_mapeamento();}return $schema;}
        if($name==='mapeamento'){return self::schema_mapeamento();}
        if(preg_match('/^f3base\[(f3base_[^\]]+)\]/',$name,$m)){$d=F3Base_Options::declaracao($m[1]);$schema=$d['schema_config']??array();preg_match_all('/\[([^\]]+)\]/',$name,$parts);foreach(array_slice($parts[1],1) as $part){$schema=$schema['properties'][$part]??($schema['items']??array());}return $schema;}return array();
    }
    public static function estado(array $data,int $depth=0): string {
        if(!$data){return '<p>Sem informações registradas.</p>';}$html='<dl class="f3base-state-list">';foreach($data as $key=>$value){$label=is_numeric($key)?'Item '.((int)$key+1):self::rotulo((string)$key);$html.='<dt>'.esc_html($label).'</dt><dd>';
            if(is_array($value)){$html.=$depth<3?self::estado($value,$depth+1):esc_html(count($value).' registros; consulte Informações técnicas para detalhar.');}else{$html.=esc_html(is_bool($value)?($value?'Sim':'Não'):($value===null||$value===''?'Não informado':(is_string($value)&&preg_match('/^[a-z_]+$/D',$value)?self::rotulo($value):(string)$value)));}$html.='</dd>';}
        return $html.'</dl>';
    }
    public static function segredo(string $name,string $field='credencial',string $remove='apagar',bool $rotulo_visivel=true): void {
        $d=F3Base_Options::declaracao($name);$label=F3Base_Credenciais::definicoes()[$name][0]??($d['rotulo']??self::rotulo($name));if($name==='f3base_email_novo_lead_smtp_senha'){$user=F3Base_Options::ler('f3base_email_novo_lead')['smtp_usuario']??'';$label='Senha SMTP'.($user!==''?' de '.$user:'');}$state=F3Base_Segredos::status($name);$id='f3base-segredo-'.$name;$em=F3Base_Options::carimbo($name);
        echo '<p>Última alteração registrada: '.esc_html($em?wp_date('d/m/Y H:i',$em):'não disponível').'</p>';if($name==='f3base_email_novo_lead_smtp_senha'){echo '<p>Usuário SMTP: '.esc_html(F3Base_Options::ler('f3base_email_novo_lead')['smtp_usuario']?:'não informado').'</p>';}echo '<div class="f3base-secret" id="'.esc_attr($id).'"><p>'.($rotulo_visivel?'<label for="'.esc_attr($id.'-valor').'">'.esc_html($label).'</label>':'').'<input id="'.esc_attr($id.'-valor').'" data-credencial="'.esc_attr($name).'" type="password" name="'.esc_attr($field).'" value="" autocomplete="new-password"></p><p>'.esc_html($state['estado']==='disponivel'?'Credencial salva. Campo vazio mantém o valor.':($state['estado']==='ausente'?'Sem credencial salva. Informe e salve um novo valor.':'Não foi possível abrir a credencial. Cadastre um novo valor.')).'</p><label><input type="checkbox" name="'.esc_attr($remove).'" value="1"> Apagar a credencial salva</label>';F3Base_Credenciais::ajuda($name);echo '</div>';
    }
}
