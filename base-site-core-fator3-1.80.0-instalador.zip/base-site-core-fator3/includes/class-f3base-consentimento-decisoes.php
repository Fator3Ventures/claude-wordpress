<?php
/** Decisões granulares mínimas. Comprovante só existe no navegador; banco guarda seu hash. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Consentimento_Decisoes {
    public const ESQUEMA_VERSAO=16400;
	public const TABELA = 'f3base_consentimento_decisoes';
	public const ROTA   = F3Base_Modulo_Consentimento::ROTA_DECISOES;

    public static function instalar(): void {F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
	public static function instalar_estrutura(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$tabela = $wpdb->prefix . self::TABELA;
		dbDelta(
			"CREATE TABLE {$tabela} (
			ref varchar(64) NOT NULL,
			politica_versao varchar(64) NOT NULL,
			medicao tinyint NOT NULL DEFAULT 0,
			publicidade tinyint NOT NULL DEFAULT 0,
			revogada tinyint NOT NULL DEFAULT 0,
			expira_em bigint NOT NULL,
			PRIMARY KEY  (ref),
			KEY expira_em (expira_em)
		) {$wpdb->get_charset_collate()};"
		);
	}

	public static function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( self::class, 'receber' ),
			)
		);
	}

	public static function referencia( string $comprovante ): string {
		return preg_match( '/^[a-f0-9]{64}$/D', $comprovante ) ? hash( 'sha256', $comprovante ) : '';
	}

	/** Leitura sem cache: revogação confirmada precisa valer na reserva seguinte. */
	public static function permite( string $ref, string $versao, string $categoria ): bool {
		global $wpdb;
		if ( ! in_array( $categoria, array( 'medicao', 'publicidade' ), true ) || ! preg_match( '/^[a-f0-9]{64}$/D', $ref ) ) {
			return false; }
		if ( ! F3Base_Modulo_Consentimento::modo_granular() || F3Base_Modulo_Consentimento::politica_versao() !== $versao ) {
			return false; }
		$tabela   = $wpdb->prefix . self::TABELA;
		$registro = $wpdb->get_row( $wpdb->prepare( 'SELECT politica_versao,medicao,publicidade,revogada,expira_em FROM %i WHERE ref = %s', $tabela, $ref ), ARRAY_A );
		return is_array( $registro ) && $versao === $registro['politica_versao'] && empty( $registro['revogada'] ) && (int) $registro['expira_em'] > time() && 1 === (int) $registro[ $categoria ];
	}

	public static function permite_capi( string $ref, string $versao ): bool {
		if ( '' === $ref ) {
			return ! F3Base_Modulo_Consentimento::modo_granular() && hash_equals( 'legado:' . F3Base_Modulo_Consentimento::politica_versao(), $versao ); }
		return self::permite( $ref, $versao, 'publicidade' );
	}

    /** Só o hash do comprovante primário fica na fila. A origem da permissão acompanha a versão da política. */
    public static function referencia_pageview(string $proof): array {
        $explicit=F3Base_Modulo_Consentimento::decisao_do_visitante()==='granted';
        return array('decisao_ref'=>hash('sha256','pageview|'.$proof),
            'politica_versao'=>($explicit?'aceite:':'legado:').F3Base_Modulo_Consentimento::politica_versao());
    }

    /** Executado na transação que ordena a revogação e o início do HTTP. */
    public static function motivo_pageview(string $ref,string $version): string {
        global $wpdb;
        $legacy=str_starts_with($version,'legado:')||str_starts_with($version,'aceite:');
        if($ref!==''&&!preg_match('/^[a-f0-9]{64}$/D',$ref)){return 'referencia_invalida';}
        $row=null;
        if($ref!==''){
            $row=$wpdb->get_row($wpdb->prepare('SELECT politica_versao,medicao,publicidade,revogada,expira_em FROM %i WHERE ref=%s FOR UPDATE',$wpdb->prefix.self::TABELA,$ref),ARRAY_A);
            if($wpdb->last_error){return 'decisao_leitura_falhou';}
            if($row&&(!empty($row['revogada'])||!$row['publicidade']||!$row['medicao'])){return 'negativa_explicita';}
        }
        $current=F3Base_Modulo_Consentimento::politica_versao();
        if($legacy){
            if(F3Base_Modulo_Consentimento::modo_granular()||substr($version,strpos($version,':')+1)!==$current){return 'politica_alterada';}
            if($ref!==''&&str_starts_with($version,'aceite:')){return '';}
            return F3Base_Publicidade::preautorizada()?'':'decisao_ausente';
        }
        if(!F3Base_Modulo_Consentimento::modo_granular()||$version!==$current){return 'politica_alterada';}
        if(!$row||(int)$row['expira_em']<=time()){return 'decisao_ausente';}
        return $row['politica_versao']===$version?'':'politica_alterada';
    }

    private static function revogar_pageview(array $dados): WP_REST_Response {
        global $wpdb;
        $proof=$dados['comprovante_anterior']??null;
        if(!is_string($proof)||!preg_match('/^[a-f0-9]{64}$/D',$proof)){return self::resposta(400,array('persisted'=>false,'codigo'=>'referencia_invalida'));}
        if(!F3Base_Modulo_Endpoint_Leads::dentro_do_limite_token()){return self::resposta(429,array('persisted'=>false,'codigo'=>'limite_decisoes'));}
        $ref=hash('sha256','pageview|'.$proof);
        // O marcador também cobre uma captura que ainda esteja em trânsito. O worker relê antes do HTTP.
        $ok=$wpdb->query($wpdb->prepare("INSERT INTO %i (ref,politica_versao,medicao,publicidade,revogada,expira_em) VALUES (%s,'revogada:pageview',0,0,1,%d) ON DUPLICATE KEY UPDATE revogada=1,expira_em=GREATEST(expira_em,VALUES(expira_em))",$wpdb->prefix.self::TABELA,$ref,time()+8*DAY_IN_SECONDS));
        return self::resposta($ok===false?503:200,array('persisted'=>$ok!==false,'codigo'=>$ok===false?'revogacao_pendente':'revogacao_confirmada'));
    }

	private static function resposta( int $status, array $dados ): WP_REST_Response {
		return new WP_REST_Response(
			$dados,
			$status,
			array(
				'Cache-Control' => 'no-store, private',
				'Vary'          => 'Origin',
			)
		);
	}

	private static function origem_valida( WP_REST_Request $request ): bool {
		if ( '1' !== $request->get_header( 'x-f3base-consentimento' ) ) {
			return false; }
		$origem = $request->get_header( 'origin' );
		if ( '' === $origem ) {
			$origem = $request->get_header( 'referer' ); }
		$origem = wp_parse_url( $origem );
		$site   = wp_parse_url( home_url( '/' ) );
		return is_array( $origem ) && is_array( $site ) && isset( $origem['host'], $origem['scheme'] ) &&
			strtolower( $origem['host'] ) === strtolower( $site['host'] ) && $origem['scheme'] === $site['scheme'] &&
			( $origem['port'] ?? ( 'https' === $origem['scheme'] ? 443 : 80 ) ) === ( $site['port'] ?? ( 'https' === $site['scheme'] ? 443 : 80 ) );
	}

	public static function receber( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;
		if ( ! self::origem_valida( $request ) ) {
			return self::resposta(
				403,
				array(
					'ok'        => false,
					'persisted' => false,
					'codigo'    => 'origem_recusada',
				)
			); }
		if ( strlen( $request->get_body() ) > 2048 ) {
			return self::resposta(
				413,
				array(
					'ok'        => false,
					'persisted' => false,
					'codigo'    => 'corpo_excedido',
				)
			); }
		$dados = $request->get_json_params();
        if(is_array($dados)&&($dados['operacao']??'')==='revogar_pageview'){return self::revogar_pageview($dados);}
		if ( ! is_array( $dados ) || ! isset( $dados['medicao'], $dados['publicidade'], $dados['politica_versao'] ) ||
			! is_bool( $dados['medicao'] ) || ! is_bool( $dados['publicidade'] ) || ! is_string( $dados['politica_versao'] ) ||
			( isset( $dados['comprovante_anterior'] ) && ! is_string( $dados['comprovante_anterior'] ) ) ) {
			return self::resposta(
				400,
				array(
					'ok'        => false,
					'persisted' => false,
					'codigo'    => 'decisao_invalida',
				)
			);
		}
		$ref       = self::referencia( (string) ( $dados['comprovante_anterior'] ?? '' ) );
		$tabela    = $wpdb->prefix . self::TABELA;
		$revogacao = array(
			'persisted'     => true,
			'cancelados'    => 0,
			'http_iniciado' => 0,
		);
		if ( '' !== $ref ) {
			$persistir = static function () use ( $wpdb, $tabela, $ref ): bool {
				$limite  = time() + DAY_IN_SECONDS;
				$gravado = $wpdb->query( $wpdb->prepare( 'UPDATE %i SET revogada=1,expira_em=CASE WHEN expira_em>%d THEN %d ELSE expira_em END WHERE ref=%s', $tabela, $limite, $limite, $ref ) );
				return false !== $gravado && F3Base_Publicidade::preservar_revogacao($ref);
			};
			$revogacao = class_exists( 'F3Base_Capi_Fila' ) && method_exists( 'F3Base_Capi_Fila', 'revogar_decisao' )
				? F3Base_Capi_Fila::revogar_decisao( $ref, $persistir )
				: array(
					'persisted'     => $persistir(),
					'cancelados'    => 0,
					'http_iniciado' => 0,
				);
			if ( empty( $revogacao['persisted'] ) ) {
				return self::resposta(
					503,
					array(
						'ok'        => false,
						'persisted' => false,
						'codigo'    => 'revogacao_pendente',
					)
				); }
		}
		// Revogar comprovante antigo continua permitido após mudança de versão/modo.
		if ( ! F3Base_Modulo_Consentimento::modo_granular() || F3Base_Modulo_Consentimento::politica_versao() !== $dados['politica_versao'] ) {
			return self::resposta(
				409,
				array(
					'ok'                   => false,
					'persisted'            => false,
					'revogacao_confirmada' => '' !== $ref,
					'codigo'               => 'politica_alterada',
				)
			);
		}
		$comprovante = '';
		{ // Toda escolha explícita recebe recibo, inclusive a negativa de ambas.
			if ( ! F3Base_Modulo_Endpoint_Leads::dentro_do_limite_token() ) {
				return self::resposta(
					429,
					array(
						'ok'                   => false,
						'persisted'            => false,
						'revogacao_confirmada' => '' !== $ref,
						'codigo'               => 'limite_decisoes',
					)
				); }
			$comprovante = bin2hex( random_bytes( 32 ) );
			$config      = F3Base_Options::ler( 'f3base_consentimento' );
			$ttl         = max( 1, min( 3650, (int) ( $config['ttl_dias'] ?? 180 ) ) ) * DAY_IN_SECONDS;
			$gravado     = $wpdb->insert(
				$tabela,
				array(
					'ref'             => self::referencia( $comprovante ),
					'politica_versao' => $dados['politica_versao'],
					'medicao'         => (int) $dados['medicao'],
					'publicidade'     => (int) $dados['publicidade'],
					'revogada'        => 0,
					'expira_em'       => time() + $ttl,
				),
				array( '%s', '%s', '%d', '%d', '%d', '%d' )
			);
			if ( false === $gravado ) {
				return self::resposta(
					503,
					array(
						'ok'        => false,
						'persisted' => false,
						'codigo'    => 'persistencia_falhou',
					)
				); }
		}
		return self::resposta(
			200,
			array(
				'ok'                   => true,
				'persisted'            => true,
				'comprovante'          => $comprovante,
				'politica_versao'      => $dados['politica_versao'],
				'revogacao_confirmada' => '' !== $ref,
				'cancelados'           => (int) ( $revogacao['cancelados'] ?? 0 ),
				'http_iniciado'        => (int) ( $revogacao['http_iniciado'] ?? 0 ),
			)
		);
	}

	/** Marcadores expirados não autorizam filas; excluídos em lotes limitados pelo executor diário. */
    public const MARGEM_EXPURGO=86400;
    public static function expurgar(): int {
        global $wpdb;if(!F3Base_Leads_Consentimento::pronto()||!F3Base_Leads_Consentimento::travar()){return 0;}
        try {$t=$wpdb->prefix.self::TABELA;$leads=F3Base_Leads_Repositorio::tabela();$limite=time()-self::MARGEM_EXPURGO;
            $refs=$wpdb->get_col($wpdb->prepare('SELECT d.ref FROM %i d WHERE d.expira_em<%d AND NOT EXISTS (SELECT 1 FROM %i l WHERE l.decisao_ref=d.ref OR JSON_CONTAINS(COALESCE(JSON_EXTRACT(l.dados,\'$.comunicacao_envio.decisoes_refs\'),\'[]\'),JSON_QUOTE(d.ref))) ORDER BY d.expira_em LIMIT 500',$t,$limite,$leads));
            if($wpdb->last_error){return 0;}$n=0;
            foreach($refs as $ref){$deleted=$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE ref=%s AND expira_em<%d AND NOT EXISTS (SELECT 1 FROM %i l WHERE l.decisao_ref=%s OR JSON_CONTAINS(COALESCE(JSON_EXTRACT(l.dados,\'$.comunicacao_envio.decisoes_refs\'),\'[]\'),JSON_QUOTE(%s)))',$t,$ref,$limite,$leads,$ref,$ref));if($deleted===false){break;}$n+=$deleted;}return $n;
        }finally{F3Base_Leads_Consentimento::liberar();}
    }
}
