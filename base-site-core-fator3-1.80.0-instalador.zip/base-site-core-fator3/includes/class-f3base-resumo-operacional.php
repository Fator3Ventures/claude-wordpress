<?php
/** Bounded local operational overview. Missing evidence remains null, never a guessed expiry. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Resumo_Operacional {
    public static function contagens(string $table): ?array {
        global $wpdb;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table){return null;}
        $r=$wpdb->get_row($wpdb->prepare("SELECT SUM(estado IN ('falhou','recusado','esgotado','revisao')) falhas,SUM(estado IN ('incerto','enviando')) incertos FROM %i",$table),ARRAY_A);
        return $wpdb->last_error?null:array('falhas'=>(int)($r['falhas']??0),'incertos'=>(int)($r['incertos']??0));
    }
    private static function dias($at): ?int {return is_numeric($at)&&(int)$at>0?(int)ceil(((int)$at-time())/DAY_IN_SECONDS):null;}
    public static function credenciais(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$out=array();$coverage=array();
        foreach(F3Base_Credenciais::ler()['itens']??array() as $c){$expiry=$c['identidade']['expira_em']??null;$out[]=array('provedor'=>'core','id'=>$c['nome'],'revisao'=>$c['revisao'],'estado'=>$c['estado'],'dias'=>self::dias($expiry),'expira_em'=>$expiry?:null,'fonte'=>'f3base/credenciais-ler');}
        $li=F3Base_Midia_Prontidao::publica('linkedin/status');$coverage['linkedin']=$li['codigo']??'local';$connections=$li['dados']['access_lifecycle']['connections']??array();foreach($connections as $c){$out[]=array('provedor'=>'linkedin','id'=>$c['connection_id'],'dias'=>self::dias($c['expires_at']??null),'expira_em'=>($c['expires_at']??null)?:null,'fonte'=>'linkedin/status');}if(count($connections)>=100){$coverage['linkedin']='limite_100_consultar_conexoes';}
        $offset=0;$pages=0;do{$meta=F3Base_Midia_Prontidao::publica('meta/list-connections',array('offset'=>$offset));$coverage['meta']=$meta['codigo']??'local';foreach($meta['dados']['connections']??array() as $c){$expiry=$c['identity']['remote_expires_at']??$c['expires_at']??null;$out[]=array('provedor'=>'meta','id'=>$c['id']??$c['connection_id']??'desconhecida','dias'=>self::dias($expiry),'expira_em'=>$expiry?:null,'fonte'=>'meta/list-connections');}$next=$meta['dados']['next_offset']??null;$offset=(int)$next;++$pages;}while($next!==null&&$pages<4);if($next!==null){$coverage['meta']='parcial_consultar_proxima_pagina';}
        $google=F3Base_Midia_Prontidao::publica('google/status',array('compact'=>true,'scope'=>'all_connections'));$coverage['google']=$google['codigo']??'local';foreach($google['dados']['connections']??array() as $c){if(!empty($c['auth']['configured'])){$out[]=array('provedor'=>'google','id'=>$c['connection_id'],'dias'=>null,'expira_em'=>null,'fonte'=>'google/status');}}
        foreach($out as &$item){$item+=array('revisao'=>null);}unset($item);return array('ok'=>true,'itens'=>$out,'credenciais'=>$out,'cobertura'=>$coverage,'limite'=>'null significa validade não informada pelo contrato local; chave Google e token de acesso temporário não têm a mesma duração. Nenhuma credencial foi renovada.');
    }
    private static function cron_pendencias(): array {
        global $wpdb;$now=time();$due=array();$max=0;
        foreach(_get_cron_array()?:array() as $at=>$hooks){if($at>$now){continue;}foreach($hooks as $hook=>$events){if(isset(F3Base_Zelador::tarefas()[$hook])){$due[$hook]=true;$max=max($max,$now-(int)$at);}}}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT codigo,COUNT(*) quantidade,MIN(ocorrencia_em) mais_antiga FROM %i WHERE estado IN ('pendente','esgotada','suspensa') AND ocorrencia_em<=%d GROUP BY codigo ORDER BY quantidade DESC,codigo",F3Base_Operacao_Intencoes::tabela(),$now),ARRAY_A);
        $causes=array();foreach($rows?:array() as $row){$causes[$row['codigo']?:'sem_causa']=(int)$row['quantidade'];$max=max($max,$now-(int)$row['mais_antiga']);}
        return array('hooks_vencidos'=>count($due),'atraso_maximo_segundos'=>$max,'esperas_por_causa'=>$wpdb->last_error?null:array_slice($causes,0,8,true),'causas_omitidas'=>max(0,count($causes)-8),'cli_recente'=>F3Base_Zelador::cli_recente(),'orcamento_cli_segundos'=>max(30,min(600,(int)get_option('f3base_cron_cli_segundos',120))),'detalhe'=>array('f3base/saude-ler','f3base/execucoes-ler'));
    }
    private static function pacotes(): array {
        if(!function_exists('get_plugins')){require_once ABSPATH.'wp-admin/includes/plugin.php';}$r=array();foreach(get_plugins() as $file=>$data){$slug=explode('/',$file)[0];if($slug==='base-site-core-fator3'||str_starts_with($slug,'wp-mcp-')&&str_contains($slug,'fator3')){$r[$slug]=array('v'=>$data['Version'],'ativo'=>is_plugin_active($file));}}ksort($r);return $r;
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        global $wpdb;$cycle=F3Base_Instalacao::resumo();$recovery=F3Base_Recuperacao::ler();$runs=F3Base_Execucoes::resumo();$warnings=F3Base_Configuracao_Medicao::avisos();$profile=F3Base_Config_Perfil::avaliar(array('perfil_id'=>F3Base_Config_Perfil::ID));$mail=F3Base_Email_Site::cfg();$mailHealth=F3Base_Email_Site::saude();$wpMail=F3Base_Wp_Mail::resumo();
        if(F3Base_Modulo_Cadencia_Relatorio::recorrencia_declarada()!==F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada()){$warnings['cadencia_agenda_divergente']=array('codigo'=>'cadencia_agenda_divergente','motivo'=>'Periodicidade configurada diverge do evento WP-Cron.');}
        $warm=F3Base_Options::ler(F3Base_Cache_Reaquecimento::ESTADO)['ultima_execucao']['em']??0;
        if(!empty(F3Base_Options::ler(F3Base_Cache_Reaquecimento::OPTION)['ativo'])&&time()-(int)$warm>7200){$warnings['reaquecimento_atrasado']=array('codigo'=>'reaquecimento_atrasado','ultima_execucao'=>$warm?:null,'motivo'=>'Reaquecimento sem execução observada nas últimas duas horas.');}
        $catalog=F3Base_Options::catalogo_ausentes();if(empty($catalog['ok'])||!empty($catalog['quantidade'])||!empty($catalog['parcial'])){$warnings=array('option_gravada_fora_catalogo'=>$catalog)+$warnings;}
        $media=F3Base_Midia_Prontidao::ler();$readiness=array();foreach($media['plataformas']??array() as $p=>$v){$bad=array_values(array_filter($v['linhas'],static fn($x)=>$x['estado']!=='pronto'));$readiness[$p]=array('estado'=>$v['estado'],'codigo'=>$bad[0]['codigo']??'pronto');}
        $meta=F3Base_Midia_Prontidao::publica('meta/health');$readiness['meta_pacote']=array('estado'=>$meta['dados']['state']??'indeterminado','codigo'=>$meta['dados']['issues'][0]['code']??$meta['codigo']??'observacao_local','agendas_parciais'=>$meta['dados']['partial_schedules']??null,'agendas_falhas'=>$meta['dados']['failed_schedules']??null);
        $credentials=self::credenciais();$creds=array();foreach($credentials['itens'] as $c){$creds[]=array('provedor'=>$c['provedor'],'id'=>$c['id'],'dias'=>$c['dias']);}
        $latest=$wpdb->get_row($wpdb->prepare("SELECT record_id,criado_em FROM %i WHERE captura='aceito' AND classe_trafego='nao_marcado' AND lixeira=0 AND eliminacao_pendente=0 ORDER BY criado_em DESC,id DESC LIMIT 1",F3Base_Leads_Repositorio::tabela()),ARRAY_A);
        $delivered=$wpdb->get_row($wpdb->prepare("SELECT l.record_id,q.concluido_em FROM %i l JOIN %i q ON q.record_id=l.record_id WHERE l.captura='aceito' AND l.classe_trafego='nao_marcado' AND l.lixeira=0 AND l.eliminacao_pendente=0 AND q.estado='entregue' ORDER BY q.concluido_em DESC LIMIT 1",F3Base_Leads_Repositorio::tabela(),F3Base_Pipedrive_Fila::tabela()),ARRAY_A);
        $r=array('ok'=>true,'em'=>time(),'http_fornecedor'=>false,
            'pacotes'=>array('valores'=>self::pacotes(),'contrato_core'=>F3Base_Config_Contrato::VERSAO,'detalhe'=>'plugins/list'),
            'atualizacao'=>array('alvo'=>F3BASE_PLUGIN_VERSAO,'estado'=>$cycle['estado']??'indeterminado','falha'=>$cycle['ultima_falha']['codigo']??null,'confirmada_no_executor_em'=>$cycle['confirmada_no_executor_em']??null,'pos'=>F3Base_Pos_Atualizacao::resumo()['etapas'],'detalhe'=>'f3base/como-usar'),
            'recuperacao'=>array('pausado'=>$recovery['pausado']??null,'codigo'=>$recovery['codigo']??'indeterminado','detalhe'=>'f3base/operacao-recuperacao-ler'),
            'cron_24h'=>array('pendencias'=>self::cron_pendencias(),'origens'=>$runs['passagens_24h']??null,'janela_completa'=>$runs['janela_completa']??false,'detalhe'=>'f3base/execucoes-ler'),
            'avisos'=>array('catalogo'=>$catalog,'quantidade'=>count($warnings),'codigos'=>array_slice(array_keys($warnings),0,5),'detalhe'=>'f3base/como-usar'),
            'perfil'=>array('id'=>F3Base_Config_Perfil::ID,'contagens'=>$profile['contadores']??null,'detalhe'=>'f3base/config-core-perfil-avaliar'),
            'caixa'=>array('importacao'=>(bool)$mail['ativo'],'envio'=>(bool)$mail['envio_ativo'],'wp_mail'=>(bool)$mail['wp_mail_pela_caixa'],'codigo'=>$mailHealth['codigo']??null,'smtp_codigo'=>$wpMail['ultimo']['codigo']??null,'smtp_fase'=>$wpMail['ultimo']['fase']??null,'cedido_smtp'=>$wpMail['cedido_a'],'detalhe'=>'f3base/como-usar'),
            'filas'=>array('avisos'=>self::contagens($wpdb->prefix.'f3base_avisos_fila'),'pipedrive'=>self::contagens(F3Base_Pipedrive_Fila::tabela()),'conversoes'=>self::contagens(F3Base_Conversoes_Servidor::tabela()),'meta'=>self::contagens(F3Base_Capi_Fila::tabela()),'email_site'=>self::contagens(F3Base_Email_Site::tabela()),'email_automatico'=>self::contagens(F3Base_Email_Novo_Lead::tabela()),'wp_mail'=>self::contagens(F3Base_Wp_Mail::tabela()),'detalhe'=>array('f3base/avisos-fila-ler','f3base/pipedrive-fila-ler','f3base/conversoes-fila-ler','f3base/email-wordpress-fila-ler')),
            'prontidao'=>array('plataformas'=>$readiness,'detalhe'=>'f3base/midia-prontidao-ler'),
            'credenciais'=>array('itens'=>$creds,'total_observado'=>count($creds),'cobertura'=>$credentials['cobertura'],'detalhe'=>'f3base/credenciais-resumo-ler'),
            'contatos'=>array('ultimo_aceito'=>$latest?:null,'ultimo_entregue_crm'=>$delivered?:null,'detalhe'=>array('f3base/leads-registros-ler','f3base/pipedrive-fila-ler')),
            'limite'=>'Até 4096 bytes de JSON UTF-8; listas e conteúdo excedentes têm omissão explícita e rota de detalhe. Evidência ausente permanece null.'
        );
        $r=self::limitar($r);
        if(!empty($e['campos'])){$r=array_intersect_key($r,array_flip(array_merge(array('ok','em','http_fornecedor'),$e['campos'])));}
        return $r;
    }
    /** Reserve envelope space and omit whole values, never substrings of JSON or diagnostic codes. */
    private static function limitar(array $r): array {
        while(strlen(wp_json_encode($r))>3900&&$r['credenciais']['itens']){array_pop($r['credenciais']['itens']);$r['credenciais']['omitidos']=($r['credenciais']['omitidos']??0)+1;}
        while(strlen(wp_json_encode($r))>3900&&$r['pacotes']['valores']){array_pop($r['pacotes']['valores']);$r['pacotes']['omitidos']=($r['pacotes']['omitidos']??0)+1;}
        if(strlen(wp_json_encode($r))<=3900){return $r;}
        // Fixed groups can also grow (provider codes, coverage, cron origins or
        // post-update stages). Keep every category and its canonical detail route
        // while explicitly omitting the largest payloads until the budget fits.
        $routes=array(
            'pacotes'=>'plugins/list','atualizacao'=>'f3base/como-usar','recuperacao'=>'f3base/operacao-recuperacao-ler','cron_24h'=>'f3base/execucoes-ler','avisos'=>'f3base/como-usar','perfil'=>'f3base/config-core-perfil-avaliar','caixa'=>'f3base/como-usar',
            'filas'=>array('f3base/avisos-fila-ler','f3base/pipedrive-fila-ler','f3base/conversoes-fila-ler','f3base/email-wordpress-fila-ler'),
            'prontidao'=>'f3base/midia-prontidao-ler','credenciais'=>'f3base/credenciais-resumo-ler','contatos'=>array('f3base/leads-registros-ler','f3base/pipedrive-fila-ler')
        );
        $sizes=array();foreach($routes as $group=>$route){$sizes[$group]=strlen(wp_json_encode($r[$group]));}arsort($sizes);
        foreach($sizes as $group=>$size){
            $omitted=array('conteudo_omitido'=>true,'detalhe'=>$routes[$group]);
            if(strlen(wp_json_encode($omitted))<$size){$r[$group]=$omitted;}
            if(strlen(wp_json_encode($r))<=3900){break;}
        }
        return $r;
    }
    public static function iniciar(): void {add_action('wp_abilities_api_init',static function(){
        F3Base_Servicos::ability('resumo-operacional-ler','Resumo operacional local até 4 KB; validade desconhecida é null e listas excedentes têm detalhe',array(__CLASS__,'ler'),array('campos'=>array('type'=>'array','uniqueItems'=>true,'maxItems'=>12,'items'=>array('type'=>'string','enum'=>array('pacotes','atualizacao','recuperacao','cron_24h','avisos','perfil','caixa','filas','prontidao','credenciais','contatos','limite')))));
        F3Base_Servicos::ability('credenciais-resumo-ler','Validade observada de credenciais Core e pacotes pelos contratos locais, sem valores secretos ou HTTP',array(__CLASS__,'credenciais'));
    });}
}
