<?php
/** Durable inbox. Only bounded parsed text is encrypted; no attachment or raw MIME persists. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Site {
    public const ESQUEMA_VERSAO=16400;
    const HOOK='f3base_email_site_consultar';
    const SEND_CAP='f3base_enviar_email';
    public static function cfg(): array {return F3Base_Options::ler(F3Base_Email_Site_Config::OPTION);}
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_email_site';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;$t=self::tabela();
        require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$t} (\nid bigint unsigned NOT NULL AUTO_INCREMENT,\nchave char(64) NOT NULL,\ncontexto char(64) NOT NULL,\ndirecao varchar(8) NOT NULL,\nuidvalidity bigint unsigned NOT NULL DEFAULT 0,\nuid bigint unsigned NOT NULL DEFAULT 0,\nmessage_hash char(64) NOT NULL,\nremetente_hash char(64) NOT NULL DEFAULT '',\nrecord_id char(32) NOT NULL DEFAULT '',\nclasse varchar(20) NOT NULL DEFAULT '',\nestado varchar(24) NOT NULL,\ncodigo varchar(100) NOT NULL DEFAULT '',\npayload longtext NOT NULL,\nacima_limite tinyint NOT NULL DEFAULT 0,\nbytes_mensagem bigint unsigned NOT NULL DEFAULT 0,\ncriada_em bigint unsigned NOT NULL,\natualizada_em bigint unsigned NOT NULL,\nmovida_em bigint unsigned NOT NULL DEFAULT 0,\ncrm_em bigint unsigned NOT NULL DEFAULT 0,\naviso_em bigint unsigned NOT NULL DEFAULT 0,\nPRIMARY KEY  (chave),\nUNIQUE KEY sequencia (id),\nUNIQUE KEY mensagem (contexto,message_hash),\nKEY contato (record_id,criada_em),\nKEY agenda (direcao,estado,atualizada_em),\nKEY remetente (contexto,remetente_hash)\n) ENGINE=InnoDB {$cc};");
        return $wpdb->get_var($wpdb->prepare('SHOW COLUMNS FROM %i LIKE %s',$t,'id'))==='id';
    }
    public static function h(string $value): string {return hash_hmac('sha256',$value,wp_salt('secure_auth').'|email-site');}
    public static function row(string $key): ?array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$key),ARRAY_A);}
    public static function patch(string $key,array $patch): bool {global $wpdb;$patch['atualizada_em']=time();$n=$wpdb->update(self::tabela(),$patch,array('chave'=>$key));return $n!==false&&($n>0||self::row($key)!==null);}
    public static function iniciar(): void {
        add_action('updated_option',array(F3Base_Email_Site_Config::class,'mudou'),40,3);add_action('added_option',static fn($n,$v)=>F3Base_Email_Site_Config::mudou($n,null,$v),40,2);
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),91);
        add_action(self::HOOK,array(__CLASS__,'cron'));
        add_action(F3Base_Modulo_Retencao_Eliminacao::EVENTO,array(__CLASS__,'podar_pendentes'),20,0);
        add_filter('wp_privacy_personal_data_exporters',static function($list){$list['f3base-email-pendente']=array('exporter_friendly_name'=>'E-mails pendentes de autenticação','callback'=>array(__CLASS__,'exportar_pendentes'));return $list;});
        add_filter('wp_privacy_personal_data_erasers',static function($list){$list['f3base-email-pendente']=array('eraser_friendly_name'=>'E-mails pendentes de autenticação','callback'=>array(__CLASS__,'apagar_pendentes'));return $list;});
        add_action('wp_abilities_api_init',static function(){
            $sim=array('type'=>'boolean','default'=>true);$rev=array('type'=>'string','pattern'=>'^[a-f0-9]{64}$');$uid=array('type'=>'integer','minimum'=>1,'maximum'=>4294967295);$record=array('type'=>'string','pattern'=>'^[a-f0-9]{32}$');
            F3Base_Servicos::ability('email-caixa-verificar','Verificar IMAP/TLS e pastas; simulação padrão, aplicação cria pastas ausentes sem importar ou mover',array(__CLASS__,'verificar'),array('simular'=>$sim),array(),false);
            F3Base_Servicos::ability('email-caixa-consultar','Consultar caixa; simulação padrão sem gravar ou mover',array(__CLASS__,'consultar'),array('simular'=>$sim,'revisao'=>$rev,'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>10)),array(),false,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));
            F3Base_Servicos::ability('email-registros-ler','Ler mensagens cifradas, descartes e resultados por contato',array(__CLASS__,'ler'),array('record_id'=>$record,'pagina'=>array('type'=>'integer','minimum'=>1),'classe'=>array('type'=>'string','enum'=>array('aceito','suspeito','descartado'))),array(),true,'f3base_ler_leads',static fn()=>current_user_can('f3base_ler_leads'));
            F3Base_Servicos::ability('email-reprocessar','Reexaminar UID da INBOX; histórico exige opção explícita e revisão',array(__CLASS__,'reprocessar'),array('uid'=>$uid,'uidvalidity'=>$uid,'importar_historico'=>array('type'=>'boolean','default'=>false),'simular'=>$sim,'revisao'=>$rev),array('uid','uidvalidity'),false,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));
            F3Base_Servicos::ability('email-enviar','Prévia ou envio SMTP a contato deste site, revisão obrigatória no envio',array(F3Base_Email_Envio::class,'executar'),array('record_id'=>$record,'assunto'=>array('type'=>'string','minLength'=>1,'maxLength'=>500),'texto'=>array('type'=>'string','minLength'=>1,'maxLength'=>20000),'simular'=>$sim,'revisao'=>$rev),array('record_id','assunto','texto'),false,self::SEND_CAP,static fn()=>current_user_can(self::SEND_CAP)&&current_user_can('f3base_ler_leads'));
        });
    }
    public static function conectar(): F3Base_Email_Imap {$client=apply_filters('f3base_email_imap_cliente',null);if($client instanceof F3Base_Email_Imap){return $client;}return new F3Base_Email_Imap(self::cfg(),F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET));}
    public static function verificar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        try{$client=self::conectar();try{$box=$client->select();$sim=($e['simular']??true)!==false;$cfg=self::cfg();$folders=$client->pastas(array('importados'=>$cfg['pasta_importados'],'enviados'=>$cfg['pasta_enviados']),!$sim);$missing=array_keys(array_filter($folders['pastas'],static fn($f)=>!$f['disponivel']));return array('ok'=>!$missing,'codigo'=>$missing?'imap_pasta_ausente':'imap_acesso_confirmado','simular'=>$sim,'pastas'=>$folders,'pastas_ausentes'=>$missing,'caixa'=>$box,'importadas'=>0,'saude'=>self::saude());}finally{$client->close();}}
        catch(Throwable $x){return array('ok'=>false,'codigo'=>self::erro($x));}
    }
    public static function erro(Throwable $x): string {return preg_match('/^(?:imap|email)_[a-z0-9_]{1,80}$/D',$x->getMessage())?$x->getMessage():'email_operacao_indisponivel';}
    public static function revisao(): string {return hash('sha256',F3Base_Options::revisao(F3Base_Email_Site_Config::OPTION).'|'.F3Base_Options::revisao(F3Base_Email_Site_Config::SECRET).'|'.wp_json_encode(get_option(F3Base_Email_Site_Config::STATE,array())));}
    public static function cron(): array {try{return self::coletar(array('simular'=>false),true);}finally{if(!empty(self::cfg()['ativo'])){F3Base_Fila::agendar(self::HOOK,time()+300);}}}
    public static function consultar(array $e=array()): array {if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}return self::coletar($e,false);}
    public static function reprocessar(array $e): array {if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}$e['limite']=1;return self::coletar($e,false);}
    private static function coletar(array $e,bool $cron): array {
        $cfg=self::cfg();$sim=($e['simular']??true)!==false;$manual=isset($e['uid']);$revision=self::revisao();
        if(empty($cfg['ativo'])){return array('ok'=>true,'codigo'=>'email_desligado');}
        if(!$sim&&!$cron&&(!isset($e['revisao'])||!hash_equals($revision,$e['revisao']))){return array('ok'=>false,'codigo'=>'conflito','revisao'=>$revision);}
        if(!F3Base_Pipedrive_Fila::travar_linha('email-site-worker')){return array('ok'=>false,'codigo'=>'email_caixa_ocupada');}$client=null;$rows=array();$start=microtime(true);
        try{
            if(!$sim&&!$cron&&!hash_equals(self::revisao(),$revision)){return array('ok'=>false,'codigo'=>'conflito');}
            $state=get_option(F3Base_Email_Site_Config::STATE,array());if(!empty($state['reconciliacao_necessaria'])){throw new RuntimeException('email_restauracao_requer_reconciliacao');}$identity=F3Base_Email_Site_Config::identidade($cfg);
            if(($state['identidade']??'')!==$identity||empty($state['ativado_em'])){throw new RuntimeException('email_ativacao_sem_marco');}
            if(!$sim){self::continuacoes();}
            $client=self::conectar();$box=$client->select('INBOX',$sim);$folders=$client->pastas(array('importados'=>$cfg['pasta_importados'],'enviados'=>$cfg['pasta_enviados']),!$sim);if(!$sim){self::estado(array('pastas'=>$folders,'criterio_ativacao'=>'INTERNALDATE >= ativado_em; UID crescente; sem SINCE por dia'));}
            if(($manual&&(int)$e['uidvalidity']!==$box['uidvalidity'])||(!empty($state['uidvalidity'])&&(int)$state['uidvalidity']!==$box['uidvalidity'])){throw new RuntimeException('email_uidvalidity_alterada');}
            if(!$sim&&empty($state['uidvalidity'])){self::estado(array('uidvalidity'=>$box['uidvalidity']));}
            $ids=$manual?array((int)$e['uid']):$client->search((int)($state['uid']??0),(int)$state['ativado_em']);$limit=(int)($e['limite']??5);$retry=array();$movementError='';
            if(!$manual){global $wpdb;$retry=array_map('intval',$wpdb->get_col($wpdb->prepare("SELECT uid FROM %i WHERE contexto=%s AND uidvalidity=%d AND estado='autenticacao_pendente' ORDER BY atualizada_em LIMIT 2",self::tabela(),$identity,$box['uidvalidity'])));$ids=array_values(array_unique(array_merge($retry,$ids)));}
            foreach(array_slice($ids,0,$limit) as $uid){
                if(microtime(true)-$start>18){break;}
                try{$msg=$client->fetch($uid);}catch(Throwable $x){if(in_array($uid,$retry,true)&&$x->getMessage()==='imap_mensagem_ausente'){$key=self::h($identity.'|'.$box['uidvalidity'].'|'.$uid);if(!$sim){self::patch($key,array('estado'=>'autenticacao_ausente','codigo'=>'imap_mensagem_ausente'));}$rows[]=array('uid'=>$uid,'classe'=>'suspeito','motivo'=>'imap_mensagem_ausente');continue;}throw $x;}$msg['uidvalidity']=$box['uidvalidity'];
                if(isset($msg['raw'])&&F3Base_Caminho_Email::propria($msg['raw'])){$rows[]=array('uid'=>$uid,'classe'=>'teste_caminho','motivo'=>'mensagem_reservada_para_limpeza');continue;}
                if($msg['recebida_em']<(int)$state['ativado_em']&&empty($e['importar_historico'])){$parsed=array('classe'=>'descartado','motivo'=>'anterior_ativacao');}
                else{try{$parsed=F3Base_Email_Mime::parse($msg['raw'],$cfg,isset($msg['parcial'])?($msg['parcial']+array('bytes'=>$msg['bytes'])):null);}catch(Throwable $x){$parsed=!empty($msg['excedida'])&&!in_array('mime_invalido',$cfg['descartes_acima_limite']??array(),true)?F3Base_Email_Excedida::metadados($msg,$cfg):array('classe'=>'descartado','motivo'=>'mime_invalido');}}
                $r=array('uid'=>$uid,'uidvalidity'=>$box['uidvalidity'],'classe'=>$parsed['classe'],'motivo'=>$parsed['motivo']);
                if(!$sim){$saved=self::persistir($msg,$parsed,$identity,$manual);$r+=$saved;if(empty($saved['ok'])){throw new RuntimeException($saved['codigo']??'email_persistencia_falhou');}
                    if(!empty($saved['record_id'])){try{$client->move($uid,$cfg['pasta_importados']);self::patch($saved['chave'],array('movida_em'=>time()));}catch(Throwable $x){$movementError=$r['movimento']=self::erro($x);self::patch($saved['chave'],array('codigo'=>$r['movimento']));}}
                    if(!$manual){self::estado(array('uid'=>max($uid,(int)($state['uid']??0))));$state['uid']=max($uid,(int)($state['uid']??0));}
                }else{$r['previa']=$parsed;}$rows[]=$r;
            }
            if(!$sim){$movementError=self::movimentos($client,$box['uidvalidity'])?:$movementError;self::resultado_leitura($movementError,!$manual&&count($ids)<=count($rows),true);self::continuacoes();F3Base_Email_Alerta::observar();}
            return array('ok'=>true,'simular'=>$sim,'revisao'=>$revision,'linhas'=>$rows,'mais'=>count($ids)>count($rows),'pastas'=>$folders,'criterio_ativacao'=>array('campo'=>'INTERNALDATE','operador'=>'>=','instante'=>(int)$state['ativado_em'],'busca'=>'UID; sem SINCE por dia'),'saude'=>self::saude());
        }catch(Throwable $x){$code=self::erro($x);if(!$sim){$s=get_option(F3Base_Email_Site_Config::STATE,array());self::resultado_leitura($code,false,false);F3Base_Email_Alerta::observar();}return array('ok'=>false,'codigo'=>$code,'linhas'=>$rows,'revisao'=>$revision);}
        finally{if($client){$client->close();}F3Base_Pipedrive_Fila::liberar_linha('email-site-worker');}
    }
    /** Only actual attempts update this bounded, body-free incident history. */
    public static function resultado_leitura(string $code,bool $complete,bool $success): void {
        $now=time();$revision=F3Base_Options::revisao('f3base_avisos_tecnicos');
        $r=F3Base_Options::atualizar_estado(F3Base_Email_Site_Config::STATE,static function($s)use($code,$complete,$success,$now,$revision){
            $old=(string)($s['codigo']??'');$s['ultima_tentativa']=$now;
            $s['falhas']=$code!==''?(int)($s['falhas']??0)+1:0;
            $s['imap_incompletas_consecutivas']=$code==='imap_resposta_incompleta'?(int)($s['imap_incompletas_consecutivas']??0)+1:0;
            $s['codigo']=$code;if($success){$s['ultimo_sucesso']=$now;}if($complete){$s['ultima_leitura_completa']=$now;$s['sequencia_leitura_completa']=(int)($s['sequencia_leitura_completa']??0)+1;}
            if($code!==''||($complete&&($old!==''||!empty($s['incidente_leitura_pendente'])))){
                $history=is_array($s['ocorrencias']??null)?$s['ocorrencias']:array();
                $history[]=array('em'=>$now,'codigo'=>$code!==''?$code:'leitura_completa_recuperada','falhas_consecutivas'=>$s['falhas'],'leitura_completa'=>$complete,'politica_revisao'=>$revision);
                $s['ocorrencias']=array_slice($history,-20);
            }
            if($code!==''){$s['incidente_leitura_pendente']=true;}elseif($complete){$s['incidente_leitura_pendente']=false;}
            return $s;
        });
        if(empty($r['persisted'])){throw new RuntimeException('email_estado_nao_persistido');}
    }
    public static function estado(array $patch): void {$r=F3Base_Options::atualizar_estado(F3Base_Email_Site_Config::STATE,static fn($s)=>array_replace($s,$patch));if(empty($r['persisted'])){throw new RuntimeException('email_estado_nao_persistido');}}
    public static function persistir(array $msg,array $p,string $context,bool $manual=false): array {
        global $wpdb;$key=self::h($context.'|'.$msg['uidvalidity'].'|'.$msg['uid']);$mid=self::h($p['message_id']??$key);if(empty($p['message_id'])){$mid=$key;}
        $row=self::row($key);$duplicate=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE contexto=%s AND message_hash=%s',self::tabela(),$context,$mid),ARRAY_A);
        if(!$row&&$duplicate){return array('ok'=>true,'chave'=>$duplicate['chave'],'record_id'=>$duplicate['record_id'],'duplicado'=>true);}
        if($row&&$row['estado']!=='autenticacao_pendente'&&$row['estado']!=='autenticacao_ausente'&&($row['estado']!=='descartado'||!$manual)){if($row['estado']==='preparado'){return self::materializar($row);}return array('ok'=>true,'chave'=>$key,'record_id'=>$row['record_id'],'duplicado'=>true);}
        $pending=!empty($p['autenticacao']['temporario']);$test=!empty($p['teste'])||!empty(self::cfg()['homologacao']);$p['teste']=$test;$record='';if($p['classe']!=='descartado'&&!$pending){$record=self::contato($p,$context)?:bin2hex(random_bytes(16));}
        if($p['classe']!=='descartado'&&!$pending){$p['crm_intencao']=F3Base_Pipedrive_Fila::intencao(array('metodo'=>'email','nome'=>$p['nome'],'captura'=>$p['classe'],'contexto_teste'=>$test));}
        $payload=$p['classe']==='descartado'&&empty($p['autenticacao'])?'':F3Base_Contato_Comunicacao::cifrar(($p['classe']==='descartado'?array('autenticacao'=>$p['autenticacao']??null,'teste'=>$test):$p)+array('recebida_em'=>$msg['recebida_em']));
        $data=array('chave'=>$key,'contexto'=>$context,'direcao'=>'entrada','uidvalidity'=>$msg['uidvalidity'],'uid'=>$msg['uid'],'message_hash'=>$mid,'remetente_hash'=>isset($p['email'])?self::h(strtolower($p['email'])):'','record_id'=>$record,'classe'=>$p['classe'],'estado'=>$pending?'autenticacao_pendente':($p['classe']==='descartado'?'descartado':'preparado'),'codigo'=>$p['motivo'],'payload'=>$payload,'acima_limite'=>!empty($msg['excedida'])?1:0,'bytes_mensagem'=>(int)($msg['bytes']??strlen($msg['raw']??'')),'criada_em'=>(int)($row['criada_em']??time()),'atualizada_em'=>time());
        $ok=$row?$wpdb->update(self::tabela(),$data,array('chave'=>$key,'estado'=>$row['estado'])):$wpdb->insert(self::tabela(),$data);if($ok===false){return array('ok'=>false,'codigo'=>'email_persistencia_falhou');}
        return $pending||$p['classe']==='descartado'?array('ok'=>true,'chave'=>$key,'record_id'=>''):self::materializar(self::row($key));
    }
    private static function contato(array $p,string $context): string {
        if($p['classe']!=='aceito'){return '';}
        global $wpdb;foreach(array_reverse($p['references']??array()) as $ref){$id=$wpdb->get_var($wpdb->prepare("SELECT record_id FROM %i WHERE contexto=%s AND message_hash=%s AND record_id<>''",self::tabela(),$context,self::h($ref)));if($id){$lead=F3Base_Leads_Repositorio::obter($id);if($lead&&$lead['email']===$p['email']&&!$lead['lixeira']&&!$lead['eliminacao_pendente']&&$lead['captura']==='aceito'&&($lead['classe_trafego']==='teste')===!empty($p['teste'])){return $id;}}}
        // Local contact lookup never chooses an unrelated site or a closed/suspect contact.
        $ids=$wpdb->get_col($wpdb->prepare("SELECT record_id FROM %i WHERE email=%s AND captura='aceito' AND lixeira=0 AND eliminacao_pendente=0 AND classe_trafego=%s AND atendimento NOT IN ('encerrado','perdido') ORDER BY atualizado_em DESC LIMIT 2",F3Base_Leads_Repositorio::tabela(),$p['email'],!empty($p['teste'])?'teste':'nao_marcado'));return count($ids)===1?$ids[0]:'';
    }
    private static function materializar(array $row): array {
        $p=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!$p){return array('ok'=>false,'codigo'=>'email_cifra_indisponivel');}
        $lead=F3Base_Leads_Repositorio::obter($row['record_id']);
        if(!$lead){$d=array('record_id'=>$row['record_id'],'metodo'=>'email','formulario'=>'email-site','origem_nativa'=>array('origem'=>'email'),'nome'=>$p['nome'],'email'=>$p['email'],'empresa'=>'','nome_substituto'=>$p['nome_substituto'],'captura'=>$row['classe'],'suspeita_motivo'=>$p['motivo'],'sinais'=>array_values(array_filter(array('email_'.$row['classe'],$p['descarte_original']??'',!empty($p['remetente_ausente'])?'remetente_ausente':''))),'contexto_teste'=>!empty($p['teste']),'notificar'=>true,'criado_em'=>gmdate('Y-m-d H:i:s',$p['recebida_em']),'email_ultima'=>$row['chave'],'email_mensagem'=>$row['payload'],'payload'=>array('email_chave'=>$row['chave']));
            $r=F3Base_Leads_Repositorio::guardar($d,$row['chave'],'email:'.$row['chave']);if(empty($r['ok'])){return $r;}$lead=F3Base_Leads_Repositorio::obter($row['record_id']);}
        if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||$lead['captura']==='eliminado'){self::patch($row['chave'],array('estado'=>'eliminado','payload'=>''));return array('ok'=>true,'chave'=>$row['chave'],'record_id'=>'');}
        global $wpdb;for($attempt=0;$attempt<3;$attempt++){
            $fresh=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$fresh||$fresh['lixeira']||$fresh['eliminacao_pendente']){return array('ok'=>false,'codigo'=>'email_contato_indisponivel');}
            $raw=$wpdb->get_var($wpdb->prepare('SELECT dados FROM %i WHERE record_id=%s',F3Base_Leads_Repositorio::tabela(),$row['record_id']));$d=json_decode($raw,true);
            if(!is_array($d)){return array('ok'=>false,'codigo'=>'email_contato_indisponivel');}
            if(($d['email_ultima']??'')===$row['chave']){break;}$d['email_ultima']=$row['chave'];$d['email_mensagem']=$row['payload'];$d['email_atualizada_em']=time();
            $n=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'atualizado_em'=>gmdate('Y-m-d H:i:s'),'revisao'=>(int)$fresh['revisao']+1),array('record_id'=>$row['record_id'],'dados'=>$raw,'revisao'=>$fresh['revisao'],'lixeira'=>0,'eliminacao_pendente'=>0));
            if($n===1){break;}if($attempt===2){return array('ok'=>false,'codigo'=>'email_contato_atualizacao_pendente');}
        }
        if(!self::patch($row['chave'],array('estado'=>'registrado'))){return array('ok'=>false,'codigo'=>'email_persistencia_falhou');}
        return array('ok'=>true,'chave'=>$row['chave'],'record_id'=>$lead['record_id'],'duplicado'=>false);
    }
    public static function projetar(array $lead,array $row): array {
        $p=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!$p){throw new RuntimeException('email_cifra_indisponivel');}
        $lead['metodo']='email';$lead['dados']['metodo']='email';$lead['dados']['email_mensagem']=$row['payload'];$lead['dados']['email_ultima']=$row['chave'];$lead['dados']['nome_substituto']=$p['nome_substituto']??false;$lead['dados']['email_novo_lead_intencao']=array('solicitado'=>false);unset($lead['dados']['comunicacao_envio']);
        $lead['criado_em']=gmdate('Y-m-d H:i:s',(int)$row['criada_em']);$lead['dados']['atribuicao']=array();$lead['dados']['origem_nativa']=array('origem'=>'email');return $lead;
    }
    public static function continuacoes(): void {
        global $wpdb;
        $legacy=$wpdb->get_results($wpdb->prepare("SELECT chave,payload FROM %i WHERE estado='cabecalho_excedido' AND record_id='' AND payload<>'' ORDER BY atualizada_em LIMIT 3",self::tabela()),ARRAY_A);
        foreach($legacy as $row){
            $p=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!$p){continue;}
            $from=(string)($p['remetente']??'');$p['nome']=$from?:'Remetente não identificado';
            $p['nome_substituto']=true;$p['remetente_ausente']=$from==='';$p['descarte_original']='cabecalho_excedido';
            $p['motivo']='acima_limite,cabecalho_excedido';$p['leitura_parcial']=true;
            $p['autenticacao']=array('aceito'=>false,'motivo'=>'nao_verificada_leitura_parcial');
            $cipher=F3Base_Contato_Comunicacao::cifrar($p);if(!$cipher){continue;}
            $wpdb->update(self::tabela(),array('estado'=>'preparado','record_id'=>bin2hex(random_bytes(16)),'classe'=>'suspeito','codigo'=>$p['motivo'],'payload'=>$cipher,'aviso_em'=>0),array('chave'=>$row['chave'],'estado'=>'cabecalho_excedido','payload'=>$row['payload']));
        }
        $rows=$wpdb->get_results($wpdb->prepare("SELECT q.* FROM %i q LEFT JOIN %i l ON l.record_id=q.record_id WHERE q.estado IN ('preparado','registrado','enviado','enviado_copia_incerta','enviado_copia_falhou') AND (q.estado='preparado' OR (l.lixeira=0 AND l.eliminacao_pendente=0 AND (q.aviso_em=0 OR (q.crm_em=0 AND l.captura='aceito')))) ORDER BY (q.aviso_em=0) DESC,q.id LIMIT 20",self::tabela(),F3Base_Leads_Repositorio::tabela()),ARRAY_A);
        foreach($rows as $row){if($row['estado']==='preparado'){$r=self::materializar($row);if(empty($r['ok'])){continue;}$row=self::row($row['chave']);}$lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||$lead['captura']==='eliminado'){continue;}
            if(!(int)$row['crm_em']&&$lead['captura']==='aceito'){if(F3Base_Pipedrive_Fila::enfileirar_email($lead,$row)){self::patch($row['chave'],array('crm_em'=>time()));}}
            if(!(int)$row['aviso_em']){if($row['direcao']==='saida'){self::patch($row['chave'],array('aviso_em'=>time()));}elseif(F3Base_Email_Entrega::aviso($lead,$row)){self::patch($row['chave'],array('aviso_em'=>time()));}}
        }
    }
    private static function movimentos(F3Base_Email_Imap $client,int $validity): string {
        global $wpdb;$context=F3Base_Email_Site_Config::identidade(self::cfg());$rows=$wpdb->get_results($wpdb->prepare("SELECT chave,uid FROM %i WHERE contexto=%s AND uidvalidity=%d AND direcao='entrada' AND estado IN ('registrado','cabecalho_excedido') AND movida_em=0 ORDER BY criada_em LIMIT 3",self::tabela(),$context,$validity),ARRAY_A);
        foreach($rows as $row){try{$client->move((int)$row['uid'],self::cfg()['pasta_importados']);self::patch($row['chave'],array('movida_em'=>time(),'codigo'=>'importado'));}catch(Throwable $x){self::patch($row['chave'],array('codigo'=>self::erro($x)));return self::erro($x);}}return '';
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        global $wpdb;$where='1=1';$args=array(self::tabela());foreach(array('record_id','classe') as $k){if(!empty($e[$k])){$where.=" AND $k=%s";$args[]=$e[$k];}}$page=max(1,(int)($e['pagina']??1));$args[]=($page-1)*20;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE $where ORDER BY id DESC LIMIT 21 OFFSET %d",$args),ARRAY_A);$more=count($rows)>20;$rows=array_slice($rows,0,20);
        foreach($rows as &$row){$row['mensagem']=$row['payload']?F3Base_Contato_Comunicacao::abrir($row['payload']):null;unset($row['payload'],$row['remetente_hash']);}unset($row);return array('ok'=>!$wpdb->last_error,'linhas'=>$rows,'pagina'=>$page,'proxima_pagina'=>$more?$page+1:null,'saude'=>self::saude());
    }
    public static function tela(string $record): void {
        $r=self::ler(array('record_id'=>$record));if(empty($r['ok'])||empty($r['linhas'])){return;}
        echo '<h3>Conversa por e-mail</h3><p>Mensagens recebidas e respostas deste site. Anexos conservam somente nome e quantidade. A leitura completa e paginada está em f3base/email-registros-ler.</p>';
        foreach($r['linhas'] as $row){$m=$row['mensagem']??array();echo '<details><summary>'.esc_html(wp_date('d/m/Y H:i:s T',(int)$row['criada_em']).' · '.$row['direcao'].' · '.$row['estado'].' · '.($m['assunto']??'')).'</summary><p>'.esc_html($row['codigo']).'</p><pre style="white-space:pre-wrap">'.esc_html($m['texto']??'').'</pre><p>'.esc_html(implode(', ',$m['anexos_nomes']??array())).'</p></details>';}
    }
    public static function saude(): array {global $wpdb;$counts=$wpdb->get_row("SELECT COALESCE(SUM(acima_limite),0) acima_limite,COALESCE(SUM(estado='cabecalho_excedido' AND payload<>''),0) cabecalhos_pendentes FROM ".self::tabela(),ARRAY_A);$s=get_option(F3Base_Email_Site_Config::STATE,array());$active=!empty(self::cfg()['ativo']);$last=(int)($s['ultima_tentativa']??$s['ativado_em']??time());$limits=F3Base_Options::ler('f3base_avisos_tecnicos');$persistent=F3Base_Email_Alerta::passageira((string)($s['codigo']??''),$limits)?((int)(($s['codigo']??'')==='imap_resposta_incompleta'?($s['imap_incompletas_consecutivas']??0):($s['falhas']??0))>=(int)$limits['imap_falhas_consecutivas']||time()-(int)($s['ultima_leitura_completa']??$s['ativado_em']??time())>=(int)$limits['imap_sem_leitura_minutos']*60):((int)($s['falhas']??0)>=3);$state=!$active?'desligada':($persistent?'falha':(time()-$last>900?'atrasada':'observada'));if($active&&!empty($counts['cabecalhos_pendentes'])&&$state==='observada'){$state='atencao';}return array('mensagens_acima_limite'=>$counts?(int)$counts['acima_limite']:null,'cabecalhos_pendentes'=>$counts?(int)$counts['cabecalhos_pendentes']:null,'estado'=>$state,'ultima_tentativa'=>$s['ultima_tentativa']??null,'ultimo_sucesso'=>$s['ultimo_sucesso']??null,'ultima_leitura_completa'=>$s['ultima_leitura_completa']??null,'falhas_consecutivas'=>(int)($s['falhas']??0),'imap_incompletas_consecutivas'=>(int)($s['imap_incompletas_consecutivas']??0),'ocorrencias'=>$s['ocorrencias']??array(),'politica_alerta'=>F3Base_Alertas_Operacionais::resumo(),'codigo'=>$s['codigo']??'','uid'=>$s['uid']??0,'uidvalidity'=>$s['uidvalidity']??0,'ativado_em'=>$s['ativado_em']??null,'criterio_ativacao'=>'INTERNALDATE >= ativado_em; UID crescente; sem SINCE por dia','pastas'=>$s['pastas']??null,'proxima_execucao'=>wp_next_scheduled(self::HOOK)?:null);}
    /** Pending messages have no contact yet: native privacy and the same retention cover their encrypted text. */
    public static function exportar_pendentes(string $email,int $page=1): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT chave,payload FROM %i WHERE record_id='' AND classe='suspeito' AND payload<>'' AND remetente_hash=%s ORDER BY id LIMIT 100 OFFSET %d",self::tabela(),self::h(strtolower($email)),(max(1,$page)-1)*100),ARRAY_A);$data=array();
        foreach($rows as $row){$p=F3Base_Contato_Comunicacao::abrir($row['payload']);if($p){$data[]=array('group_id'=>'f3base-email-pendente','group_label'=>'E-mails pendentes de autenticação','item_id'=>$row['chave'],'data'=>array(array('name'=>'Mensagem e autenticação','value'=>wp_json_encode($p,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))));}}
        return array('data'=>$data,'done'=>count($rows)<100);
    }
    public static function apagar_pendentes(string $email,int $page=1): array {
        if(!F3Base_Pipedrive_Fila::travar_linha('email-site-worker')){return array('items_removed'=>false,'items_retained'=>true,'messages'=>array('Coleta em curso; tente novamente.'),'done'=>true);}
        try{global $wpdb;$n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='eliminado',payload='',remetente_hash='',codigo='titular_eliminado',atualizada_em=%d WHERE record_id='' AND classe='suspeito' AND payload<>'' AND remetente_hash=%s LIMIT 100",self::tabela(),time(),self::h(strtolower($email))));return array('items_removed'=>$n>0,'items_retained'=>$n===false,'messages'=>$n===false?array('Eliminação não confirmada.'):array(),'done'=>$n===false||$n<100);}
        finally{F3Base_Pipedrive_Fila::liberar_linha('email-site-worker');}
    }
    public static function podar_pendentes(): array {
        if(!F3Base_Pipedrive_Fila::travar_linha('email-site-worker')){return array('ok'=>false,'codigo'=>'email_caixa_ocupada');}
        try{global $wpdb;$cut=strtotime(F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao((int)F3Base_Options::ler('f3base_retencao_meses')).' UTC');$n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='eliminado',payload='',remetente_hash='',codigo='retencao_cumprida',atualizada_em=%d WHERE record_id='' AND classe='suspeito' AND payload<>'' AND criada_em<%d LIMIT 100",self::tabela(),time(),$cut));return array('ok'=>$n!==false,'codigo'=>$n===false?'email_retencao_pendente':'email_retencao_confirmada','eliminados'=>max(0,(int)$n),'parcial'=>$n===100);}
        finally{F3Base_Pipedrive_Fila::liberar_linha('email-site-worker');}
    }
    public static function suspender(): bool {
        global $wpdb;$t=self::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){return true;}
        if($wpdb->query($wpdb->prepare("UPDATE %i SET estado='suspenso',codigo='restauracao_requer_reconciliacao' WHERE estado IN ('preparado','registrado','enviando','incerto','enviado','enviado_copia_incerta','enviado_copia_falhou','autenticacao_pendente','autenticacao_ausente','cabecalho_excedido')",$t))===false){return false;}
        $r=F3Base_Options::atualizar_estado(F3Base_Email_Site_Config::STATE,static function($s){$s['reconciliacao_necessaria']=true;return $s;});return !empty($r['persisted']);
    }
    public static function eliminar(string $record): bool {
        if(!F3Base_Pipedrive_Fila::travar_linha('email-site-worker')){return false;}
        try{global $wpdb;return $wpdb->update(self::tabela(),array('estado'=>'eliminado','payload'=>'','remetente_hash'=>'','record_id'=>'','codigo'=>'titular_eliminado'),array('record_id'=>$record))!==false;}finally{F3Base_Pipedrive_Fila::liberar_linha('email-site-worker');}
    }
    public static function conferir_agenda_1(): void {if(!empty(self::cfg()['ativo'])&&!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+60);}$r=get_role('administrator');if($r&&!$r->has_cap(self::SEND_CAP)){$r->add_cap(self::SEND_CAP);}}
}
