<?php
/** MIME parsing through the scoped upstream parser; no attachment content is retained. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Mime {
    public static function ids(string $value): array {preg_match_all('/<[A-Za-z0-9.!#$%&\x27*+\/=??^_`{|}~@-]{1,240}>/',$value,$m);return array_slice(array_values(array_unique($m[0])),-30);}
    private static function header($m,string $name): string {return (string)$m->getHeaderValue($name,'');}
    private static function raw_header($m,string $name): string {$h=$m->getHeader($name);return $h?(string)$h->getRawValue():'';}
    public static function parse(string $raw,array $cfg,?array $partial=null): array {
        if(strlen($raw)>F3Base_Email_Imap::MAX_MESSAGE){return array('classe'=>'descartado','motivo'=>'mensagem_excedida');}
        require_once dirname(__DIR__).'/vendor-email/autoload.php';
        $parser=new \F3BaseEmailVendor\ZBateson\MailMimeParser\MailMimeParser();$m=$parser->parse($raw,false);
        $addresses=static function($header): array {$out=array();if($header&&method_exists($header,'getAddresses')){foreach($header->getAddresses() as $a){$email=strtolower((string)$a->getEmail());if(is_email($email)){$out[]=$email;}}}return $out;};
        $to=array_merge($addresses($m->getHeader('To')),$addresses($m->getHeader('Cc')));
        foreach(array('Delivered-To','X-Original-To') as $h){$email=strtolower(trim(self::header($m,$h),' <>'));if(is_email($email)){$to[]=$email;}}
        $from=$m->getHeader('From');$froms=$addresses($from);$reply=$addresses($m->getHeader('Reply-To'));
        $sender=$froms[0]??'';$email=count($reply)===1?$reply[0]:$sender;
        $name=$from&&method_exists($from,'getPersonName')?(string)$from->getPersonName():'';$substitute=trim($name)==='';if($substitute){$name=explode('@',$email)[0];}
        $subject=mb_substr(sanitize_text_field(self::header($m,'Subject')),0,500);$text=$m->getTextContent();
        if($text===null){$html=(string)$m->getHtmlContent();$html=preg_replace('~<(?:script|style)\b[^>]*>.*?</(?:script|style)>~is','',$html);$text=html_entity_decode(wp_strip_all_tags(preg_replace('~<br\s*/?>|</(?:p|div|li)>~i',"\n",$html)),ENT_QUOTES|ENT_HTML5,'UTF-8');}
        if($partial!==null){$text=$partial['texto']??'';}
        $text=wp_check_invalid_utf8((string)$text);$text=preg_replace('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/u','',$text);
        $files=array();foreach($m->getAllAttachmentParts() as $part){$files[]=mb_substr(sanitize_file_name((string)($part->getFilename()?:'anexo-sem-nome')),0,180);if(count($files)>=100){break;}}
        if($partial!==null){$files=array_column($partial['anexos']??array(),'nome');}
        $msg=self::ids(self::raw_header($m,'Message-ID'));$refs=array_values(array_unique(array_merge(self::ids(self::raw_header($m,'References')),self::ids(self::raw_header($m,'In-Reply-To')))));
        $out=array('classe'=>'aceito','motivo'=>'aceito','email'=>$email,'remetente'=>$sender,'nome'=>mb_substr(sanitize_text_field($name),0,200),'nome_substituto'=>$substitute,'assunto'=>$subject,'texto'=>mb_substr($text,0,20000),'texto_truncado'=>mb_strlen($text)>20000,'anexos_nomes'=>$files,'anexos_quantidade'=>count($files),'message_id'=>$msg[0]??'','references'=>$refs,'in_reply_to'=>self::ids(self::raw_header($m,'In-Reply-To'))[0]??'');
        if($partial!==null){$out+=array('acima_limite'=>true,'bytes_mensagem'=>$partial['bytes']??null,'leitura_parcial'=>true,'anexos'=>$partial['anexos']??array());$out['texto_truncado']=$out['texto_truncado']||!empty($partial['texto_truncado']);}
        $discard='';
        if(!in_array(strtolower($cfg['endereco']),$to,true)){$discard='destinatario_outro_site';}
        elseif(count($froms)!==1||!is_email($email)||count($reply)>1){$discard='remetente_invalido';}
        else{foreach(array_unique(array($sender,$email)) as $address){$domain=strtolower(substr(strrchr($address,'@'),1));foreach($cfg['dominios_ignorados'] as $ignored){$ignored=strtolower($ignored);if($domain===$ignored||str_ends_with($domain,'.'.$ignored)){$discard='remetente_do_grupo';}}}}
        $auto=strtolower(trim(self::header($m,'Auto-Submitted')));$precedence=strtolower(trim(self::header($m,'Precedence')));$ct=strtolower(self::header($m,'Content-Type').' '.(string)$m->getHeaderParameter('Content-Type','report-type',''));
        if(!$discard&&$auto!==''&&$auto!=='no'){$discard='resposta_automatica';}
        if(!$discard&&(in_array($precedence,array('bulk','list','junk'),true)||self::header($m,'List-Id')!=='')){$discard='mensagem_em_massa';}
        if(!$discard&&(trim(self::raw_header($m,'Return-Path'))==='<>'||preg_match('/^(?:mailer-daemon|postmaster)@/i',$sender)||str_contains($ct,'delivery-status')||str_contains($ct,'disposition-notification'))){$discard='retorno_entrega';}
        if(!$discard&&(preg_match('/(?:report domain:|dmarc aggregate|dmarc report)/i',$subject)||str_contains($ct,'feedback-report')||array_filter($files,static fn($f)=>preg_match('/(?:dmarc|!.*!).*\.(?:xml|gz|zip)$/i',$f)))){$discard='relatorio_dmarc';}
        $authentication=$discard?null:(new F3Base_Email_Auth())->verificar($raw,$cfg,$sender,$partial===null);
        $out['autenticacao']=$authentication;
        $out['teste']=!empty($cfg['homologacao'])||str_starts_with($subject,'[TESTE F3BASE]')||in_array($sender,array_map('strtolower',$cfg['remetentes_teste']??array()),true);
        if(!$discard&&!empty($authentication['descartar'])){$discard='dmarc_fail_'.$authentication['politica'];}
        if(!$discard&&$cfg['homologacao']&&!in_array($email,array_map('strtolower',$cfg['homologacao_emails']),true)){$discard='fora_homologacao';}
        if($partial!==null && !in_array($discard,$cfg['descartes_acima_limite']??array(),true)){
            $out['classe']='suspeito';
            $out['motivo']=implode(',',array_filter(array('acima_limite',!empty($partial['cabecalho_excedido'])?'cabecalho_excedido':'',$discard)));
            $out['descarte_original']=$discard;
            $out['autenticacao']=array('aceito'=>false,'motivo'=>'nao_verificada_leitura_parcial');
            $out['remetente_ausente']=$sender==='';
            if($out['nome']===''){$out['nome']='Remetente não identificado';$out['nome_substituto']=true;}
            return $out;
        }
        if($discard){return array('classe'=>'descartado','motivo'=>$discard,'message_id'=>$out['message_id'],'autenticacao'=>$authentication,'teste'=>$out['teste']);}
        $reasons=array();if(empty($authentication['aceito'])){$reasons[]=!empty($authentication['temporario'])?'autenticacao_dns_pendente':'autenticacao_nao_confirmada';}if(count($reply)===1&&$reply[0]!==$sender){$reasons[]='reply_to_divergente';}
        if(preg_match_all('~https?://~i',$subject."\n".$text)>$cfg['max_links']){$reasons[]='links_excessivos';}
        foreach($cfg['termos_suspeitos'] as $term){if($term!==''&&mb_stripos($subject."\n".$text,$term)!==false){$reasons[]='termo_suspeito';break;}}
        if($reasons){$out['classe']='suspeito';$out['motivo']=implode(',',array_unique($reasons));}
        return $out;
    }
}
