<?php
/** Reservas atômicas por tarefa. Nunca libera a reserva de outro processo. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Trava {
    private static function valida($v): bool {
        return is_array($v) && is_string($v['dono']??null) && $v['dono']!=='' && is_int($v['expira']??null) && $v['expira']>time();
    }
    public static function inspecionar(string $task): ?array {
        global $wpdb;$name='f3base_trava_'.hash('sha256',$task);
        $raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$name));
        if($wpdb->last_error){throw new RuntimeException('trava_leitura_falhou');}if($raw===null){return null;}
        $v=maybe_unserialize($raw);
        return array('dono'=>is_array($v)?($v['dono']??null):null,'desde'=>is_array($v)?($v['desde']??null):null,'ate'=>is_array($v)?($v['expira']??null):null,'vigente'=>self::valida($v),'revisao'=>hash('sha256',$raw));
    }
    public static function remover_orfa(string $task,string $revision): bool{
        global $wpdb;$name='f3base_trava_'.hash('sha256',$task);
        $raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$name));
        if($raw===null||!hash_equals(hash('sha256',$raw),$revision)||self::valida(maybe_unserialize($raw))){return false;}
        $n=$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE option_name=%s AND BINARY option_value=BINARY %s',$wpdb->options,$name,$raw));
        wp_cache_delete($name,'options');return $n===1;
    }
    public static function adquirir(string $tarefa, int $segundos=120): ?array {
        global $wpdb;
        $nome='f3base_trava_'.hash('sha256', $tarefa);
        $antigo=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$nome));
        if ($wpdb->last_error) { return null; }
        $estado=maybe_unserialize($antigo);
        if ($antigo!==null && !self::valida($estado)) {
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND BINARY option_value=BINARY %s",$nome,$antigo));
            wp_cache_delete($nome,'options');
        }
        $valor=array('dono'=>wp_generate_uuid4(),'desde'=>time(),'expira'=>time()+max(15,min(900,$segundos)));
        $ok=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'off')",$nome,maybe_serialize($valor)));
        wp_cache_delete($nome,'options');
        return $ok===1?array('nome'=>$nome,'valor'=>$valor):null;
    }
    /** Renova somente a posse vigente. O chamador conserva o novo valor para liberar. */
    public static function renovar(array &$reserva, int $segundos=120): bool {
        global $wpdb;
        if ((int)($reserva['valor']['expira']??0)<time()) { return false; }
        $novo=$reserva['valor'];$novo['expira']=max((int)$novo['expira']+1,time()+max(15,min(900,$segundos)));
        $n=$wpdb->query($wpdb->prepare('UPDATE %i SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s',$wpdb->options,maybe_serialize($novo),$reserva['nome'],maybe_serialize($reserva['valor'])));
        wp_cache_delete($reserva['nome'],'options');
        if ($n!==1) { return false; }
        $reserva['valor']=$novo;return true;
    }
    public static function liberar(array $reserva): void {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND BINARY option_value=BINARY %s",$reserva['nome'],maybe_serialize($reserva['valor'])));
        wp_cache_delete($reserva['nome'],'options');
    }
}
