<?php
/** Discovery reads only catalog metadata; selecting and saving remain separate operations. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Anuncios_Selecao {
    public static function iniciar(): void {add_action('wp_ajax_f3base_anuncios_catalogo',static function(){check_ajax_referer('f3base-anuncios-catalogo');$e=wp_unslash($_POST);$source=sanitize_key($e['origem']??'');if($source==='f3base_anuncios_linkedin'){$r=F3Base_Linkedin_Integracoes::executar(sanitize_key($e['integracao_id']??''),static fn()=>self::consultar($e));}else{$r=self::consultar($e);}wp_send_json($r);});}
    private static function contexto(string $source): string {
        if($source==='f3base_anuncios_linkedin'){return F3Base_Linkedin_Integracoes::revisao_execucao();}
        $secret=$source==='f3base_anuncios_meta'?'f3base_anuncios_meta_token':'f3base_anuncios_google_chave';return hash('sha256',F3Base_Options::revisao($source).'|'.F3Base_Options::revisao($secret));
    }
    public static function campo(string $source,string $key,array $value,string $name,string $id,bool $editar_ids=false): void {
        $context=self::contexto($source);$rows=get_transient('f3cat_'.hash('sha256',$context.'|'.$source.'|'.$key))?:array();
        if ($editar_ids) {
            echo '<p><label for="'.esc_attr($id).'">IDs dos formulários, um por linha</label><br><textarea id="'.esc_attr($id).'" name="'.esc_attr($name).'" rows="3">'.esc_textarea(implode("\n",$value)).'</textarea></p>';
        } else { echo '<input type="hidden" id="'.esc_attr($id).'" name="'.esc_attr($name).'" value="'.esc_attr(implode("\n",$value)).'">'; }
        echo '<div class="f3base-catalog-picker" data-input="'.esc_attr($id).'" data-source="'.esc_attr($source).'" data-kind="'.esc_attr($key).'" data-context="'.esc_attr($context).'" data-integration="'.esc_attr($source==='f3base_anuncios_linkedin'?F3Base_Linkedin_Integracoes::id():'').'" data-nonce="'.esc_attr(wp_create_nonce('f3base-anuncios-catalogo')).'" data-rows="'.esc_attr(wp_json_encode(array_values($rows))).'"></div><noscript>Ative JavaScript para selecionar os itens do catálogo. Os valores salvos serão preservados.</noscript>';
    }
    public static function consultar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$source=(string)($e['origem']??'');$kind=(string)($e['tipo']??'');if(!in_array($source,array('f3base_anuncios_meta','f3base_anuncios_google','f3base_anuncios_linkedin'),true)||!in_array($kind,array('paginas','formularios','campanhas'),true)){return array('ok'=>false,'codigo'=>'catalogo_invalido');}
        $context=self::contexto($source);if(!hash_equals($context,(string)($e['contexto']??''))){return array('ok'=>false,'codigo'=>'configuracao_alterada');}$cursor=(string)($e['cursor']??'');if(strlen($cursor)>2500){return array('ok'=>false,'codigo'=>'cursor_invalido');}
        if(!F3Base_Leads_Repositorio::quota('catalogo-ui|'.get_current_user_id().'|'.gmdate('YmdHi'),20,time()+120)){return array('ok'=>false,'codigo'=>'aguarde_um_minuto');}
        $rows=array();$next='';$cfg=$source==='f3base_anuncios_linkedin'?F3Base_Linkedin::config():F3Base_Options::ler($source);
        if($source==='f3base_anuncios_meta'){
            F3Base_Meta_Acesso::preparar();try{$q=array('fields'=>'id,name','limit'=>100);$page='';$position=0;$after=$cursor;
                if($kind==='paginas'){$path='me/accounts';}elseif($kind==='campanhas'){if(!preg_match('/^[0-9]+$/D',$cfg['conta_id']??'')){return array('ok'=>false,'codigo'=>'salve_a_conta');}$path='act_'.$cfg['conta_id'].'/campaigns';}else{$c=$cursor!==''?json_decode(base64_decode($cursor,true)?:'',true):array();$position=max(0,(int)($c['page']??0));$after=(string)($c['after']??'');$page=(string)($cfg['paginas'][$position]??'');if($page===''){return array('ok'=>false,'codigo'=>'selecione_e_salve_as_paginas');}$path=$page.'/leadgen_forms';}
                if($after!==''){$q['after']=$after;}$r=F3Base_Meta_Acesso::graph($path,$q,$page);if(empty($r['ok'])){return $r;}
                foreach($r['json']['data']??array() as $v){if(preg_match('/^[0-9]+$/D',(string)($v['id']??''))){$rows[]=array('id'=>(string)$v['id'],'name'=>sanitize_text_field($v['name']??'Item sem nome'));}}
                $after=!empty($r['json']['paging']['next'])?(string)($r['json']['paging']['cursors']['after']??''):'';
                if($kind==='formularios'){$position+=$after===''?1:0;if($after!==''||isset($cfg['paginas'][$position])){$next=base64_encode(wp_json_encode(array('page'=>$position,'after'=>$after)));}}else{$next=$after;}
            }finally{F3Base_Meta_Acesso::limpar();}
        }elseif($source==='f3base_anuncios_google'){
            $ability=function_exists('wp_has_ability')&&function_exists('wp_get_ability')&&wp_has_ability('ads/search')?wp_get_ability('ads/search'):null;if(!$ability){return array('ok'=>false,'codigo'=>'ative_o_mcp_google_com_ads');}$resource=$kind==='campanhas'?'campaign':'asset';if($kind==='paginas'){return array('ok'=>false,'codigo'=>'catalogo_nao_aplicavel');}if($cursor!==''&&!ctype_digit($cursor)){return array('ok'=>false,'codigo'=>'cursor_invalido');}
            $where=$resource==='asset'?"asset.type = 'LEAD_FORM'":'campaign.status != \'REMOVED\'';if($cursor!==''){$where.=' AND '.$resource.'.id > '.$cursor;}
            try{$r=$ability->execute(array('customer_id'=>$cfg['conta_id'],'query'=>'SELECT '.$resource.'.id, '.$resource.'.name FROM '.$resource.' WHERE '.$where.' ORDER BY '.$resource.'.id LIMIT 200','limit'=>200,'format'=>'raw'));}catch(Throwable $e){return F3Base_Abilities_Nativas::falha($e,'google_catalogo_indisponivel','ads/search');}
            if(is_wp_error($r)||!is_array($r)||empty($r['success'])){return F3Base_Abilities_Nativas::falha($r,'google_catalogo_indisponivel','ads/search');}foreach($r['data']['rows']??array() as $v){$item=$v[$resource]??array();$id=(string)($item['id']??$v[$resource.'.id']??'');if(ctype_digit($id)){$rows[]=array('id'=>$id,'name'=>sanitize_text_field($item['name']??$v[$resource.'.name']??'Formulário sem nome'));}}if(count($rows)===200){$next=$rows[199]['id'];}
        }else{
            if(F3Base_Linkedin_Cliente::externo()){
                $r=F3Base_Linkedin_Cliente::catalogo($kind,$cursor);if(empty($r['ok'])){return $r;}$rows=$r['linhas'];$next=$r['cursor'];
            }else{
            if($kind!=='formularios'){return array('ok'=>false,'codigo'=>'catalogo_nao_disponivel_neste_cliente');}
            if(!preg_match('/^[0-9]+$/D',$cfg['conta_id']??'')||($cursor!==''&&!ctype_digit($cursor))){return array('ok'=>false,'codigo'=>'salve_a_conta');}$start=(int)$cursor;
            $r=F3Base_Linkedin_Api::pedir('GET','leadForms',array('q'=>'owner','owner'=>'(sponsoredAccount:urn:li:sponsoredAccount:'.$cfg['conta_id'].')','start'=>$start,'count'=>100));if(empty($r['ok'])){return $r;}foreach($r['data']['elements']??array() as $v){$id=F3Base_Linkedin::form_id((string)($v['id']??''));if($id!==''){$rows[]=array('id'=>$id,'name'=>sanitize_text_field($v['name']??'Formulário sem nome'));}}if(count($r['data']['elements']??array())===100){$next=(string)($start+100);}
        }
        }
        if(!hash_equals($context,self::contexto($source))){return array('ok'=>false,'codigo'=>'configuracao_alterada');}$cache='f3cat_'.hash('sha256',$context.'|'.$source.'|'.$kind);$all=$cursor!==''?(get_transient($cache)?:array()):array();foreach($rows as $row){$all[$row['id']]=$row;}set_transient($cache,array_slice($all,0,5000,true),HOUR_IN_SECONDS);
        return array('ok'=>true,'linhas'=>$rows,'cursor'=>$next,'completo'=>$next==='','em'=>time());
    }
}
