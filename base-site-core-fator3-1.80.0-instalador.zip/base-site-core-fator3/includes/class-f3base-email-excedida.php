<?php
/** Metadados de contingência para importação parcial; transporte Slack usado pelo monitoramento. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Excedida {
    public static function metadados(array $msg,array $cfg): array {
        $raw=(string)($msg['raw']??'');
        $field=static function(string $name)use($raw): string{
            if(!preg_match('/^'.preg_quote($name,'/').':[ \t]*([^\r\n]*(?:\r?\n[ \t]+[^\r\n]*)*)/im',$raw,$m)){return '';}
            return sanitize_text_field(mb_decode_mimeheader(trim(preg_replace('/\r?\n[ \t]+/',' ',$m[1]))));
        };
        $sender=$field('From');$address=static function(string $v): string{
            if(str_contains($v,',')){return '';}
            if(preg_match('/<([^<>]+)>$/',$v,$m)){$v=$m[1];}
            return is_email(trim($v))?strtolower(trim($v)):'';
        };
        $from=$address($sender);$reply=$address($field('Reply-To'));$name=trim(preg_replace('/<[^<>]*>$/','',$sender)," \t\"");$sub=$name===''||$name===$from;
        $subject=mb_substr($field('Subject'),0,500);$files=$msg['parcial']['anexos']??array();
        return array('classe'=>'suspeito','motivo'=>'acima_limite,mime_invalido','descarte_original'=>'mime_invalido','acima_limite'=>true,'leitura_parcial'=>true,'remetente_ausente'=>$from==='','bytes_mensagem'=>(int)$msg['bytes'],'remetente'=>$from,'email'=>$reply?:$from,'nome'=>$sub?($from?:'Remetente não identificado'):mb_substr($name,0,200),'nome_substituto'=>$sub,'assunto'=>$subject,'texto'=>'','anexos'=>$files,'anexos_nomes'=>array_column($files,'nome'),'anexos_quantidade'=>count($files),'teste'=>!empty($cfg['homologacao'])||str_starts_with($subject,'[TESTE F3BASE]'),'autenticacao'=>array('aceito'=>false,'motivo'=>'nao_verificada_leitura_parcial'));
    }
    public static function slack(string $title,string $text,bool $test): array {
        if($test&&F3Base_Testes::politica('slack','teste')==='suprimir'){return array('ok'=>true,'estado'=>'suprimido_teste');}$cfg=F3Base_Options::ler('f3base_avisos');$message=F3Base_Slack::simples(($test?'[TESTE F3BASE] ':'').$title,array('Revisão'=>array('Mensagem'=>$text)),F3Base_Configuracoes_Hub::url('conexoes','f3base_email_site'));
        if(($cfg['slack_transporte']??'webhook')==='app'){$token=F3Base_Segredos::abrir(F3Base_Slack::SEGREDO);$channel=$cfg['slack_canal_id']??'';if(!$token||!preg_match('/^[CG][A-Z0-9]{8,63}$/D',$channel)){return array('ok'=>false,'estado'=>'sem_destino');}$r=F3Base_Slack::api('chat.postMessage',$token,array('channel'=>$channel)+$message);return array('ok'=>!empty($r['ok']),'estado'=>!empty($r['ok'])?'confirmado':'incerto','codigo'=>!empty($r['ok'])?'slack_confirmou':'slack_nao_confirmou');}
        $url=F3Base_Segredos::abrir(F3Base_Avisos::SEGREDO);if(!F3Base_Avisos::url_valida($url)){return array('ok'=>false,'estado'=>'sem_destino');}$r=wp_safe_remote_post($url,array('timeout'=>8,'redirection'=>0,'headers'=>array('Content-Type'=>'application/json'),'body'=>wp_json_encode($message)));$ok=!is_wp_error($r)&&wp_remote_retrieve_response_code($r)===200&&trim(wp_remote_retrieve_body($r))==='ok';return array('ok'=>$ok,'estado'=>$ok?'confirmado':'incerto');
    }
}
