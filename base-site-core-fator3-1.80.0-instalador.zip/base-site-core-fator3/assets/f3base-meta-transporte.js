/*! F3 Base 1.19 — captura Meta no próprio site; confirmação não é entrega externa. GPL-2.0-or-later. */
(function(w,d){
 'use strict';
 var c=w.f3baseMetaTransporteDados;if(!c||!c.pixel){return;}
 var pending=new Map(),timer=0,testPage=null,counts={confirmados:0,rejeitados:0,incertos:0},origin={};
 function allowed(name){
  var p=w.f3baseConsentimento,x=w.f3baseContexto;
  if(!x||!x.pronto()||x.audienciaExcluida||!p||!p.permiteCategoria('medicao')||!p.permiteCategoria('publicidade')){return false;}
  if(!x.teste()){return true;}
  return c.testeCapi==='marcar'&&['ambos','servidor'].includes(c.modo)&&
   (!name||(name==='MaterialDownload'?c.material:(c.eventos||[]).includes(name)));
 }
 function legacyReference(){
  if(c.consentimentoLegado!=='sim'){return true;}
  var values=cookies();
  if(values.f3base_capi_revogar){return false;}
  var proof=/^[a-f0-9]{64}$/.test(values.f3base_capi_ref||'')?values.f3base_capi_ref:uuid()+uuid();
  d.cookie='f3base_capi_ref='+proof+'; Max-Age=691200; Path=/; SameSite=Lax'+(location.protocol==='https:'?'; Secure':'');
  return /^[a-f0-9]{64}$/.test(cookies().f3base_capi_ref||'');
 }
 function uuid(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.from(a,function(v){return ('0'+v.toString(16)).slice(-2);}).join('');}
 function cookies(){var result={};d.cookie.split(';').forEach(function(v){var p=v.trim().split('=');try{result[p[0]]=decodeURIComponent(p.slice(1).join('='));}catch(e){}});return result;}
 function ids(){var v=cookies();if(!v._fbp){var a=new Uint32Array(1);crypto.getRandomValues(a);v._fbp='fb.1.'+Date.now()+'.'+a[0];d.cookie='_fbp='+v._fbp+'; Max-Age=7776000; Path=/; SameSite=Lax'+(location.protocol==='https:'?'; Secure':'');}var click=new URLSearchParams(location.search).get('fbclid');if(click&&/^[A-Za-z0-9_-]{1,200}$/.test(click)&&(!v._fbc||v._fbc.split('.').pop()!==click)){v._fbc='fb.1.'+Date.now()+'.'+click;d.cookie='_fbc='+v._fbc+'; Max-Age=7776000; Path=/; SameSite=Lax'+(location.protocol==='https:'?'; Secure':'');}return {fbp:v._fbp||'',fbc:v._fbc||''};}
 function add(name,id,browser){if((name==='MaterialDownload'&&!c.material)||!allowed(name)||!/^[A-Za-z0-9_-]{16,64}$/.test(id)){return;}var test=!!w.f3baseContexto.teste(),key=name+'|'+id,old=pending.get(key),stamp=origin[key]||(origin[key]=Math.floor(Date.now()/1000));if(old){old.body.navegador_observado=old.body.navegador_observado||browser;return;}pending.set(key,{body:Object.assign({nome:name,evento:id,criado_em:stamp,caminho:w.f3baseTracking&&w.f3baseTracking.caminho?w.f3baseTracking.caminho():location.pathname,contexto_teste:test,navegador_observado:!test&&!!browser},test?{}:ids()),attempts:0,busy:false});flush();}
 function flush(){clearTimeout(timer);if(!allowed()){pending.clear();return;}pending.forEach(function(row,key){if(row.busy||row.next>Date.now()){return;}if(++row.attempts>4||row.body.criado_em< Date.now()/1000-3600){counts.incertos++;pending.delete(key);return;}row.busy=true;var observed=row.body.navegador_observado,control=new AbortController(),abort=setTimeout(function(){control.abort();},10000);var token=w.f3baseContexto?w.f3baseContexto.token(c):Promise.resolve(c.token);
  token.then(function(t){if(pending.get(key)!==row||!allowed(row.body.nome)||row.body.contexto_teste!==!!w.f3baseContexto.teste()){throw new Error('suprimido');}return fetch(c.endpoint,{method:'POST',credentials:'same-origin',keepalive:true,signal:control.signal,headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.assign({},row.body,{token:t}))});}).then(function(r){return r.json().then(function(v){if(r.ok&&v.ok){counts.confirmados++;if(row.body.navegador_observado!==observed){row.attempts=0;row.next=0;}else{pending.delete(key);}}else if(r.status===403&&v.codigo==='token_ou_entrada_invalida'&&w.f3baseContexto){c.token='';row.next=Date.now()+500;}else if([400,403,413].indexOf(r.status)>=0){counts.rejeitados++;pending.delete(key);}else{throw new Error('sem_confirmacao');}});}).catch(function(){row.next=Date.now()+Math.min(30000,Math.pow(2,row.attempts)*500);}).finally(function(){clearTimeout(abort);row.busy=false;if(pending.size&&allowed()){timer=setTimeout(flush,1000);}});
 });}
 function page(){
  if(!allowed('PageView')){return;}
  if(['ambos','servidor'].includes(c.modo)&&(c.eventos||[]).includes('PageView')&&!legacyReference()){return;}
  var test=w.f3baseContexto.teste(),p=test?testPage:w.f3baseMetaPagina;
  if(!p){p={id:uuid(),em:Math.floor(Date.now()/1000)};if(test){testPage=p;}else{w.f3baseMetaPagina=p;}}
  origin['PageView|'+p.id]=p.em;
  if(!p.captura){p.captura=true;add('PageView',p.id,!!p.navegador);}
 }
 d.addEventListener('f3base-meta-pixel',function(e){var v=e.detail||{};if(!w.f3baseContexto||w.f3baseContexto.teste()){return;}
  if(v.nome==='PageView'&&['ambos','servidor'].includes(c.modo)&&(c.eventos||[]).includes('PageView')&&(!allowed('PageView')||!legacyReference())){return;}
  if(['PageView','Lead','MaterialDownload'].indexOf(v.nome)>=0){add(v.nome,v.id,true);}});
 d.addEventListener('f3base-lead-confirmado',function(e){var v=e.detail||{};if(w.f3baseContexto&&!!v.teste===!!w.f3baseContexto.teste()&&v.meta_evento!==''){var name=v.metodo==='conteudo'?(c.material&&v.meta_evento==='MaterialDownload'?'MaterialDownload':''):'Lead';if(name){add(name,v.id,false);}}});
 d.addEventListener('f3base-contexto-pronto',page);
 d.addEventListener('f3base-consentimento',function(){if(!allowed()){pending.clear();clearTimeout(timer);}else{page();}});
 d.addEventListener('f3base-teste-alterado',function(){pending.clear();clearTimeout(timer);page();});
 w.addEventListener('pagehide',flush);d.addEventListener('visibilitychange',function(){if(d.visibilityState==='hidden'){flush();}});w.addEventListener('online',flush);
 w.f3baseMetaTransporte={diagnostico:function(){return {pendentes:pending.size,contagens:Object.assign({},counts),modo:c.modo,evidencia:'captura_local'};}};page();
}(window,document));
