# Fator3 MCP 0.53.0 — confirmação de agenda parada

**Pedidos MCP 90.** O alerta `agenda_parada` passa a exigir duas observações da ausência do marcador `f3_mcp_cron_observed`, em requisições HTTP diferentes. A janela padrão entre elas é de cinco minutos. Durante a execução pelo cron, o WordPress pode retirar momentaneamente o evento da agenda. Essa passagem, inclusive via WP-CLI, fica fora da contagem.

## Como interpretar o alerta

Ao fim de uma requisição elegível, o canal confere a agenda. A primeira ausência confirmada inicia a espera. Repetir a consulta na mesma requisição ou antes de completar a janela preserva a espera. Se o marcador estiver presente quando a requisição terminar, o reagendamento na própria passagem não gera uma amostra de ausência. Quando outra requisição confirma a ausência e o intervalo já transcorreu, o canal abre o incidente para o recurso `marcador-wordpress`. Uma leitura elegível que comprova o marcador ativo cancela a suspeita ou recupera o incidente já aberto.

Consulte `system/maintenance-policy` e abra `incidents.agenda_sample`. A resposta reflete o estado gravado antes da leitura. Como a observação ocorre no encerramento da requisição, confira o resultado em outra chamada.

| `status` da amostra | Interpretação |
|---|---|
| `pending` | O campo `first_missing_at` traz o instante Unix da primeira ausência. A confirmação aguarda a janela `confirmation_seconds`. |
| `confirmed` | Outra requisição confirmou a ausência após a janela. O MCP encaminha a abertura ao Core, preservando o início observado. |
| `interrupted` | A execução ou o reagendamento comprovado do marcador interrompeu a contagem de ausência. |
| `active` | O canal encontrou o marcador ativo e pode confirmar a recuperação. |
| `inconclusive` | A leitura da agenda não comprovou o estado do marcador. Uma nova ausência precisa de outra confirmação. |

Para ver o marcador no diagnóstico completo, consulte `system/health` com `fields:["cron"]`. Em `f3base/incidentes-tecnicos-ler`, procure o pacote `canal` e o código `agenda_parada`. O campo `desde` identifica a primeira ausência comprovada. O Core registra a abertura somente após o MCP confirmar a segunda observação. Para um episódio recuperado, `alterado_em` contém o instante da recuperação.

## Configurar a janela

Em **Ferramentas → Fator3 MCP → Configurar → Arquivos e banco**, abra o cartão **Manutenção automática** e ajuste **Intervalo para confirmar agenda parada (segundos)**. Pelo MCP, uma conta com `manage_options` e uma conexão de Manutenção pode simular uma janela de dez minutos.

```json
{"ability_name":"system/maintenance-configure","parameters":{"dry_run":true,"policy":{"agenda_confirmation_seconds":600}}}
```

O campo aceita segundos inteiros entre 300 e 86400. Para aplicar, repita a política com `dry_run:false` e o `expected_revision` devolvido pela simulação. Releia `policy.agenda_confirmation_seconds` para conferir o valor. Em `revision_conflict`, leia a política atual e refaça a simulação.

## Instalação e aceite de campo

Instalação limpa ou atualização direta da 0.52.0. O pacote requer WordPress 7.1.4 e PHP 8.3 ou superiores. A matriz de referência usa Site Core 1.98.0, Google 0.40.0, Meta 0.30.0, LinkedIn 0.26.0 e Pipedrive 0.12.0. O Core recebe os avisos pelo contrato `incidentes/1` e administra a entrega do e-mail técnico.

O aceite de campo requer sete dias com execução do cron CLI a cada 15 minutos nos 14 sites. Registre as leituras durante a janela, percorrendo as páginas com `proximo` e `apos`. Para cada episódio recuperado, confira a duração entre `desde` e `alterado_em` e confronte os horários com os recibos em `f3base/email-wordpress-fila-ler`. Uma consulta isolada ao final da semana mostra apenas o episódio mais recente por recurso. O ensaio de remoção deliberada da agenda é restrito ao Site-Teste. O relatório da entrega identifica os resultados obtidos.
