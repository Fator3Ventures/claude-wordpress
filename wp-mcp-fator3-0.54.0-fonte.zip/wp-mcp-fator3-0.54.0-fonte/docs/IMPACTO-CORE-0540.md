# Retorno ao Site Core — carência de token_vencendo

**Revisão 3 · 20/11/2026 · retorno de implementação e aceite técnico no Site-Teste.** Origem **Pedidos Core 439**, atendimento **Pedidos MCP 91**. Emissor do retorno: Fator3 MCP 0.54.0. Destinatário: Fator3 Site Core 1.99.0, contrato de configuração 8.47.0. Classificação original `acao-necessaria`. Situação da ação de código do MCP: **encerrada**.

## Contrato incorporado

O leitor `f3base/config-core-ler`, ao receber explicitamente `nome=f3base_avisos_tecnicos`, pode exibir a carência inteira de 0 a 10.080 minutos para o código `token_vencendo`. O mapa apresenta o número. A folha em `/carencia_por_codigo_minutos/token_vencendo` aceita o objeto de duas chaves com `existe=true` e `valor` inteiro na faixa. Na opção completa, a projeção vale exclusivamente em `valor`, `valor_efetivo`, `padrao_declarado` e `valor_bruto`. A classificação genérica de campos sensíveis, as permissões do leitor e a política de gravação continuam vigentes.

O Core já fornecia a duração correta. A correção oficial está em `fontes/wp-mcp-fator3/includes/Release014.php`, nas funções `SafeOutput::error()` e `core_grace_minutes()`. O canal usa o contexto da chamada passado por `ToolsHandler`, compara o caminho de resposta e confere a estrutura e o valor antes de entregar o dado. A regra específica é consultada no ramo que normalmente mascararia o campo. A mesma projeção alimenta o JSON em texto, o conteúdo estruturado e o inventário de redações.

## Provas e identidade

| Ambiente | Resultado |
|---|---|
| Core 1.99.0 com MCP 0.53.0 | Confirmação local e no Site-Teste. O mapa e a folha exibiram `[redigido]`. Em HTTP MCP local, o inventário indicou exatamente as duas posições. |
| ZIP oficial do MCP 0.54.0 com o mesmo Core | Na bancada, 29 verificações de projeção passaram, incluindo os limites, valores fora da faixa, dados de tipo incorreto, campo sensível vizinho, envelope com chave adicional, opção e chamada diferentes. Valores gravados de 0 e 10.080 apareceram nas projeções efetiva e bruta; o padrão declarado permaneceu 30. |
| Site-Teste | A mesma revisão da opção retornou o mapa com 18 códigos e `token_vencendo=30`, e a folha com `{"existe":true,"valor":30}`. A chamada independente apenas da folha confirmou o mesmo resultado. O texto e o conteúdo estruturado coincidiram. O conector não repassa `_meta` ao cliente desta sessão. A contagem e os caminhos do inventário foram conferidos no envelope HTTP MCP autenticado em WordPress local. |

| Instalador | SHA-256 |
|---|---|
| Fator3 Site Core 1.99.0 | `3509e2736dfdedd98c2fa142d99028eb629f112ba1c863138850c3f3ee5e7155` |
| Fator3 MCP 0.53.0, base | `8403d4b5ce901bb3261d00823508b3c7f12507e2283a4d42c5d9822a7463c2a7` |
| Fator3 MCP 0.54.0, oficial | `175b01ba1eeacc6655e739b70b694c2127c7df7e5858b180c773da8630392202` |

## Histórico e responsabilidade

A revisão 1 do Core registrou o falso positivo. A revisão 2 trouxe o contrato, o patch experimental e o ensaio comparativo. A revisão 3 registra a incorporação oficial, a atualização do Site-Teste e a comprovação pela equipe do MCP. A revisão 2 recebida está em `docs/entradas/0540/impacto-recebido-core-439.md`. O relatório e `evidencias/0540/` identificam os arquivos e as leituras da release.

A frota distribui o instalador e confirma o comportamento dos alertas ao longo da semana prevista no pedido Core 439. A prova do MCP acessa a configuração do Core em modo de leitura no Site-Teste. O acompanhamento de entrega de e-mails e a janela de campo do pedido MCP 90 seguem com a frota.
