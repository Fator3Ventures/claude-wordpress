# Retorno ao Site Core — Fator3 MCP 0.52.0

Revisão 1 de entrega, 19/11/2026. Destinatário técnico, mantenedor do Fator3 Site Core. Pedidos MCP 89 e Core 433. O encaminhamento recebido é a revisão 3 do Core 1.97.2. A integração solicitada está incorporada ao instalador oficial do MCP e confirmada no Site-Teste.

O Core 1.97.2 oferece f3base_cron_incidentes_24h_v1. O MCP 0.52.0 consulta o filtro nas leituras administrativas de saúde que incluem incidentes. O resultado aparece em incidents_24h.pacotes_fator3 nas respostas completa e compacta e na seleção por campo. O canal publica exclusivamente episodios, ultimo_em e detalhe. Uma contagem disponível igual a zero vem com ultimo_em nulo. Na ausência de valor, o canal mantém o formato anterior.

| Evidência no Site-Teste | Resultado |
|---|---|
| Referências | Core 1.97.2, instalador SHA-256 2c831351a5f5afc23a90eca5d85f469e906cbb10e65d4e13aec161f65eaaa801. MCP 0.52.0, instalador SHA-256 44e5cfbff907a50cfd50ee4c5d5789055393f4965931d54ae24b09c60c4f8e9f. |
| Antes | 0 episódios, ultimo_em nulo. |
| Recusa controlada em evento de teste da Meta | 1 episódio, ultimo_em 1795106363, detalhe f3base/incidentes-tecnicos-ler. Consulta completa, compacta e por campo coincidiram. O diário registrou o mesmo instante, e o detalhe identificou o gancho sintético e o código could_not_set. |
| Após remoção da simulação | 0 episódios, ultimo_em nulo. Nenhuma linha do gancho no diário. Plugin de ensaio removido. Canal saudável e cron ativo. |

A rota publicada e o índice de incidentes do Core atenderam ao contrato. O mantenedor do Core pode encerrar a dependência de código com o MCP. A observação de agenda na frota e o aceite de 72 horas do pedido Core 433 têm responsável e critério próprios. O fonte do canal traz as evidências em evidencias/0520/site-teste.json e os testes reproduzíveis em tools/release0520.
