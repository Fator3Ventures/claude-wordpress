# Fator3 MCP 0.54.0 — leitura do prazo de aviso de vencimento

**Pedidos MCP 91, origem Core 439.** A política de avisos técnicos do Core possui um prazo de carência para cada código. O nome `token_vencendo` identifica o aviso. Seu valor é uma duração em minutos. Na 0.53.0 a apresentação do canal mascarava esse prazo. A 0.54.0 apresenta o inteiro que o Core devolveu, inclusive quando vale zero.

## Consultar o valor efetivo

Use uma conta administrativa com `manage_options`, serviço do Core ativo e permissão na conexão MCP. Envie a consulta nomeando a opção e os caminhos:

```json
{"ability_name":"f3base/config-core-ler","parameters":{"nome":"f3base_avisos_tecnicos","caminhos":["/carencia_por_codigo_minutos","/carencia_por_codigo_minutos/token_vencendo"]}}
```

Sob `opcoes.f3base_avisos_tecnicos.caminhos`, o mapa traz o número em `/carencia_por_codigo_minutos → valor → token_vencendo`. O ponteiro exato devolve, por exemplo, `{"existe":true,"valor":30}`. O Core pode configurar qualquer inteiro de 0 a 10.080 minutos, inclusive. Leia o valor retornado em cada site. No painel, a configuração correspondente fica em **Fator3 Site Core → Conexões → Avisos técnicos → Token perto do vencimento**.

Na leitura da opção completa, a mesma regra se aplica a `valor`, `valor_efetivo`, `padrao_declarado` e `valor_bruto` quando o respectivo mapa existe. O MCP exige o identificador da operação, o nome explícito da opção, a posição e o tipo previstos. Na folha, exige exatamente `existe` verdadeiro e `valor` inteiro válido. Um formato inválido mantém a indicação `[redigido]`. Outros campos seguem suas regras de apresentação. O envelope MCP apresenta o mesmo resultado em `content` e `structuredContent`. O inventário de posições mascaradas está em `_meta["fator3/redaction"]`.

## Instalação e convivência

Instalação limpa ou atualização direta da 0.53.0. Requisitos mínimos de WordPress 7.1.4 e PHP 8.3. A matriz desta edição inclui Site Core 1.99.0 (configuração 8.47.0), Google 0.41.0, Meta 0.31.0, LinkedIn 0.26.0 e Pipedrive 0.12.0. A correção atua na apresentação da resposta. O Core mantém os prazos, a revisão da configuração e o envio dos avisos. A atualização do canal não requer regravação dos valores. Detalhes do tratamento de campos sensíveis constam de [Redação dos resultados](redacao).
