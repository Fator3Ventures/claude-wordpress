# Carência do aviso de vencimento na leitura administrativa do Fator3 MCP

| Registro | Identificação |
|---|---|
| Data e revisão | 20/11/2026 · revisão 2 · encaminhamento para implementação e entrega do emissor |
| Emissor | Fator3 Site Core, `base-site-core-fator3` 1.98.0 → 1.99.0, contrato de configuração `8.47.0` |
| Destinatário e responsável | Equipe do Fator3 MCP, `wp-mcp-fator3` 0.53.0. A equipe do MCP atribui a próxima versão e o número do seu pedido. |
| Classificação e situação | `acao-necessaria` · aberto. Referência de origem: pedido Core 439. |
| Instalador entregue do Core 1.99.0 | SHA-256 `3509e2736dfdedd98c2fa142d99028eb629f112ba1c863138850c3f3ee5e7155` |
| MCP 0.53.0 oficial usado no ensaio | Instalador SHA-256 `8403d4b5ce901bb3261d00823508b3c7f12507e2283a4d42c5d9822a7463c2a7`. Fonte SHA-256 `7d45bba94249bd0b9ef687a285809b20e81ef5dc1b5a7a8503bb7d5b9c587c84`. |

## Consequência operacional

A nova política de alertas do Core permite configurar a carência individual de 18 códigos. Na consulta autorizada via MCP 0.53.0 do Site-Teste, o valor de `token_vencendo` apareceu como `[redigido]`. Os outros 17 códigos retornaram minutos. Um agente que verifica a configuração por esse canal perde a leitura efetiva de um prazo e deve tratá-lo como indisponível. O painel do WordPress já permite ao administrador consultar o campo **Token perto do vencimento** em **Fator3 Site Core → Conexões → Avisos técnicos**. O valor padrão dessa carência é 30 minutos. O administrador pode escolher de 0 a 10.080, inclusive.

## Contrato e reprodução

O leitor exige `manage_options`, serviço operacional habilitado e autorização no perfil da conexão MCP. Use `f3base/config-core-ler` com a carga abaixo. A consulta lê a opção. O exemplo não contém uma credencial.

```json
{
  "nome": "f3base_avisos_tecnicos",
  "caminhos": [
    "/carencia_por_codigo_minutos",
    "/carencia_por_codigo_minutos/token_vencendo",
    "/carencia_por_codigo_minutos/credencial_recusada",
    "/carencia_por_codigo_minutos/agenda_parada"
  ]
}
```

O Site-Teste retornou a revisão `a84e438fdfb1004c5d1355b8d1f56ecd7b3c930815d65bc3c6e6d79a5c7cd7a2` nas consultas ao mapa e às folhas. No mapa, somente o valor de `token_vencendo` recebeu a máscara. Na leitura exata da folha, o marcador ocupou o trecho inteiro. As duas folhas de controle conservaram os objetos `{"existe":true,"valor":0}` e `{"existe":true,"valor":30}`, respectivamente. A observação nesse site foi exclusivamente de leitura. O valor subjacente do campo mascarado nesse site não foi inferido do seu padrão.

| Forma de leitura do campo na cópia local | Core 1.99.0, antes da apresentação | MCP 0.53.0 oficial | MCP 0.53.0 com o patch experimental |
|---|---|---|---|
| Membro do mapa `carencia_por_codigo_minutos` | `30` | `"[redigido]"` | `30` |
| Ponteiro exato `/carencia_por_codigo_minutos/token_vencendo` | `{"existe":true,"valor":30}` | `"[redigido]"` | `{"existe":true,"valor":30}` |
| Folha vizinha `agenda_parada` | `{"existe":true,"valor":30}` | Mesmo valor e tipo | Mesmo valor e tipo |

## Causa e correção proposta

No Core, `includes/class-f3base-alertas-operacionais.php` declara o schema fechado de `carencia_por_codigo_minutos`. O membro `token_vencendo` é do tipo `integer` na faixa inclusiva de 0 a 10.080. `F3Base_Core_Config_Mcp::ler()` lê a opção e `F3Base_Config_Caminhos::projetar()` devolve o trecho solicitado. Esse contrato está implementado no instalador emitido. O ensaio abaixo exercitou a integração na cópia local da mesma versão.

No MCP, `core/includes/Server/Handlers/Tools/ToolsHandler.php` obtém o contexto da chamada e apresenta o resultado com `Fator3\McpFiles\SafeOutput::presentation()`. Em `includes/Release014.php`, a recursão de `SafeOutput::error()` invoca `DataSafety::sensitive_field()`. O componente `token` no nome da chave aciona a regra existente de `includes/DataSafety.php`. Uma chave que contém o ponteiro completo aciona a mesma regra, antes que seus filhos sejam examinados.

Solicita-se ao responsável pelo MCP integrar uma exceção de apresentação no leitor explícito `f3base/config-core-ler`, com `nome=f3base_avisos_tecnicos`. O patch abaixo verifica o contexto da chamada já resolvida, a localização no resultado, o tipo inteiro e os limites. Na folha projetada, somente o objeto com as duas chaves exatas, existência booleana verdadeira e valor inteiro válido pode atravessar a regra. Na consulta da opção completa, as projeções `valor`, `valor_efetivo`, `padrao_declarado` e `valor_bruto` usam a mesma verificação. Em contextos sem nome explícito, outras opções, chamadas de escrita, SQL e diagnósticos gerais, a proteção vigente continua a classificar o conteúdo. Nenhuma alteração de permissões, migração de banco ou instalação simultânea dos pacotes é necessária.

## Ensaio comparativo e aceite

O ensaio usou WordPress 7.1.4 e PHP 8.4.27 em loopback, com o Core 1.99.0 e uma cópia do MCP 0.53.0. O leitor do Core produziu os dados e o mesmo método de apresentação usado pelo transporte MCP processou o envelope JSON. O teste do patch exerceu a integração dessas duas funções. A autenticação de uma conexão pública foi observada apenas com o MCP oficial no Site-Teste.

Cada fase cumpriu **29 verificações**. A projeção local do mapa e das duas folhas registrou duas redações na fase oficial e zero na fase experimental. A coleção inclui os extremos válidos, números fora da faixa, texto numérico, booleano, nulo, contêiner, campo sensível adjacente, envelope com chave adicional, outro caminho, outro contexto de chamada e outra opção. As consultas de compatibilidade passaram nas duas fases. A cópia de laboratório voltou a coincidir com a oficial após o ensaio.

O fonte contém `reference/1990/mcp-redacao/ensaio.php`, `reference/1990/mcp-redacao/wp-mcp-fator3-0.53.0-carencia.patch` e `evidence/1990/mcp-redacao.json`. SHA-256 do patch: `9eab5a5ecce2d4ea3f2b6dfdbd56ce2a10389bb141ea6c49fa39c13cdb068fef`. Para reproduzir, instale os dois pacotes em WordPress **descartável** de tipo `local`, com URL de loopback, confirme que o Core habilitou o serviço e execute com WP-CLI como administrador. O exemplo toma o diretório raiz do WordPress como diretório atual e o fonte do Core já extraído em `/tmp/core-fonte`.

```sh
referencia=/tmp/core-fonte/reference/1990/mcp-redacao
F3_MCP_FASE=oficial wp --user=1 eval-file "$referencia/ensaio.php" > /tmp/carencia-oficial.json
patch -d wp-content/plugins/wp-mcp-fator3 -p1 < "$referencia/wp-mcp-fator3-0.53.0-carencia.patch"
F3_MCP_FASE=proposta wp --user=1 eval-file "$referencia/ensaio.php" > /tmp/carencia-proposta.json
```

O aceite do destinatário requer incorporar a correção na sua própria versão, verificar seu instalador contra os controles positivos e negativos, e repetir a leitura do mapa e da folha em uma conexão autorizada com o pacote atualizado. Também deve verificar que o texto da resposta e o conteúdo estruturado concordam e que a indicação de redações acompanha os valores mostrados. O patch foi exercitado somente na cópia local. O painel do Core dá acesso administrativo ao valor durante o intervalo entre as releases.

## Histórico e patch experimental

Revisão 1: registro durante a homologação pública do pedido 439 após observar a perda de tipo no mapa. Revisão 2: confirmação na folha exata, identificação do filtro, ensaio nas duas versões da cópia e encaminhamento. O Core está pronto para receber a correção pelo canal existente. A versão e o aceite oficiais do MCP dependem de sua equipe.

```diff
--- a/includes/Release014.php
+++ b/includes/Release014.php
@@ -33,6 +33,7 @@
             }
             elseif(in_array($key,['input_schema','output_schema'],true) && (is_array($value)||$value instanceof \stdClass)) $safe[$key]=self::schema($value,false,$childPath,$context);
             elseif(in_array($key,['confirm_token','confirmation_token'],true) && is_string($value) && preg_match('/^[a-f0-9]{64}$/D',$value)) $safe[$key]=$value;
+            elseif(self::core_grace_minutes($childPath,$context,$value))$safe[$key]=$value;
             elseif(DataSafety::sensitive_field((string)$key,$value)&&$key!=='error_code')$safe[$key]='[redigido]';
             elseif(in_array($key,['message','error','error_description','last_error_message'],true)&&is_string($value))$safe[$key]=DataSafety::diagnostic_text($value);
             else $safe[$key]=self::value($value,$childPath,$context);
@@ -69,6 +70,30 @@
         for($i=0;$i<2 && ($path[0]??null)==='data';++$i)array_shift($path);
         return $path;
     }
+    /** Core 8.47.0: a per-code delay in minutes. Only the explicit reader can return it. */
+    private static function core_grace_minutes(array $path, array $context, $value): bool {
+        $option = 'f3base_avisos_tecnicos';
+        $field = 'carencia_por_codigo_minutos';
+        $code = 'token_vencendo';
+        $last = end($path);
+        if ($last !== $code && $last !== "/$field/$code") return false;
+        if (($context['ability'] ?? '') !== 'f3base/config-core-ler' || ($context['option'] ?? '') !== $option) return false;
+
+        $path = self::domain_path($path);
+        if (array_slice($path, 0, 2) !== ['opcoes', $option]) return false;
+        $tail = array_slice($path, 2);
+        if ($tail === ['caminhos', "/$field/$code"]) {
+            if (!is_array($value) && (!is_object($value) || get_class($value) !== \stdClass::class)) return false;
+            $section = (array)$value;
+            if (count($section) !== 2 || ($section['existe'] ?? null) !== true || !array_key_exists('valor', $section)) return false;
+            $value = $section['valor'];
+        } elseif ($tail !== ['caminhos', "/$field", 'valor', $code]
+            && !(count($tail) === 3 && in_array($tail[0], ['valor', 'padrao_declarado', 'valor_efetivo', 'valor_bruto'], true)
+                && array_slice($tail, 1) === [$field, $code])) {
+            return false;
+        }
+        return is_int($value) && $value >= 0 && $value <= 10080;
+    }
     private static function inherited_keys_path(array $path, array $context): bool {
         $path=self::domain_path($path);
         return ($context['ability']??'')==='f3base/config-core-ler' && count($path)===3 && $path[0]==='opcoes' && preg_match('/^f3base_[a-z0-9_]+$/D',$path[1]) && $path[2]==='chaves_herdadas' && (($context['option']??'')===''||$context['option']===$path[1]);
```
