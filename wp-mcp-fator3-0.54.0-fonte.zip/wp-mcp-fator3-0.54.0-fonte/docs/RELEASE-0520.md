# Fator3 MCP 0.52.0 — incidentes de agenda dos pacotes

Pedidos MCP 89, vinculado ao pedido Core 433. Instalação limpa ou atualização direta da 0.51.0. Requisitos mínimos de execução: WordPress 7.1.4 e PHP 8.3. Acompanhantes de referência: Site Core 1.97.2, Google 0.40.0, Meta 0.30.0, LinkedIn 0.26.0 e Pipedrive 0.12.0.

## Consultar a agenda

Use uma conexão MCP autorizada a executar system/health, vinculada a uma conta com manage_options. Consulte a resposta completa ou envie compact=true para resumir a saúde. Para consultar apenas os incidentes, use fields com incidents_24h. O resumo verifica o limite de 1.850 bytes antes dos metadados de transporte. O histórico retido do marcador do canal continua acessível com fields contendo cron e o modo compacto desligado.

Com o Site Core disponível, incidents_24h.pacotes_fator3 reúne três valores. **episodios** conta as aberturas registradas nas últimas 24 horas. **ultimo_em** é o instante Unix da abertura mais recente, ou null quando a contagem é zero. **detalhe** identifica a operação do Core que contém o histórico, atualmente f3base/incidentes-tecnicos-ler. Abra essa operação para ver o gancho e conferir se já ocorreu recuperação. A recuperação de um worker preserva a abertura na contagem até que ela saia da janela.

O filtro local f3base_cron_incidentes_24h_v1 recebe null. O Core consulta seu diário para os ganchos de pacote que acompanha. O MCP acrescenta o resumo às duas formas de resposta e preserva os campos do próprio marcador, inclusive by_type e counts_complete. Uma contagem zero é um resultado disponível. Se o produtor estiver ausente ou devolver null, o campo opcional é omitido. A ausência do campo deixa a contagem dos pacotes indeterminada. Ler o diagnóstico preserva a agenda e as filas.
