<?php
/** Observations only. Site Core owns destination, queue, mail and deduplication. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ChannelIncidents {
    private static array $agendaObserved = [];
    private static array $markerPass = [];
    private static array $scheduledAt = [];

    public static function init(): void {
        add_action('wp_loaded',static function(): void { self::observe(false); },30);
    }

    public static function initAgenda(): void {
        add_action('shutdown', [self::class, 'observeAgenda'], PHP_INT_MAX);
        add_action(CronMarker::HOOK, static function(): void {
            self::beginMarkerPass();
            self::interruptAgendaSample();
        }, PHP_INT_MIN);
        add_filter('pre_unschedule_event', static function($pre, $timestamp, $hook) {
            if ($hook === CronMarker::HOOK && (self::cliContext() || wp_doing_cron())) self::beginMarkerPass();
            return $pre;
        }, PHP_INT_MIN, 3);
        add_filter('pre_reschedule_event', static function($pre, $event) {
            if ($event->hook === CronMarker::HOOK && (self::cliContext() || wp_doing_cron())) self::beginMarkerPass();
            return $pre;
        }, PHP_INT_MIN, 2);
        add_filter('schedule_event', static function($event) {
            if ($event && $event->hook === CronMarker::HOOK && $event->schedule === 'hourly' && $event->args === []) {
                self::$scheduledAt[get_current_blog_id()][$event->timestamp] = true;
            }
            return $event;
        }, PHP_INT_MAX);
        add_action('update_option_cron', static function($old, $value) { self::markerWritten($value); }, 10, 2);
        add_action('add_option_cron', static function($option, $value) { self::markerWritten($value); }, 10, 2);
    }
    public static function status(): array {
        $sample = StateStore::get('automation','agenda-sample');
        return ['contract'=>'incidentes/1','core_available'=>(bool)has_filter('f3base_incidente_publicar_v1'),
            'last_observation'=>StateStore::get('automation','incidents'),
            'agenda_sample'=>$sample === null ? null : array_intersect_key($sample,
                array_flip(['status','time','first_missing_at','confirmation_seconds','policy_revision'])),
            'delivery_owner'=>'base-site-core-fator3','external_uptime_monitor'=>false];
    }
    private static function publish(string $code,string $resource,bool $open,?int $expires=null,?int $since=null): void {
        $key=hash('sha256',$code.'|'.$resource);
        $state=StateStore::get('channel-incidents',$key)??['queue'=>[]];
        $event=['pacote'=>'canal','codigo'=>$code,'recurso'=>$resource,
            'estado'=>$open?'aberto':'recuperado','acao_humana'=>$open,
            'rota'=>'tools.php?page=wp-mcp-fator3'];
        if ($expires!==null && $expires>0) $event['vence_em']=$expires;
        if (($state['desired']??null)!==$event) {
            $state['desired']=$event;
            $state['queue'][]=$event+['desde'=>$since ?? time()];
            StateStore::put('channel-incidents',$key,$state);
        }
        // Keep transitions if the Core is absent or busy. The Core retains accepted mail retries.
        foreach (array_slice($state['queue'],0,4) as $pending) {
            $r=apply_filters('f3base_incidente_publicar_v1',null,$pending);
            $state['last_attempt']=time();
            $state['last_result']=is_array($r)?array_intersect_key($r,array_flip(['ok','estado','codigo'])):['ok'=>false,'codigo'=>'core_unavailable'];
            if (!is_array($r)||empty($r['ok'])) { StateStore::put('channel-incidents',$key,$state); break; }
            array_shift($state['queue']);StateStore::put('channel-incidents',$key,$state);
        }
    }
    /** Caller has already validated a known grant/client pair; no credentials reach this hook. */
    public static function exchangeObserved(string $grant,bool $success): void {
        if ($grant==='') return;
        try { Locks::run(['channel-incidents'=>LOCK_EX],static function() use($grant,$success) {
            self::publish('renovacao_falhou','concessao:'.$grant,!$success);
            if ($success) self::grant($grant,Persistence::get('oauth-grants',$grant));
        }); } catch (\Throwable $e) { /* OAuth issuance is independent of notification transport. */ }
    }
    private static function grant(string $id,?array $g): void {
        if (!$g || ($g['status']??$g['_storage']['status']??'')!=='active') {
            self::publish('refresh_vencendo','concessao:'.$id,false);
            self::publish('renovacao_falhou','concessao:'.$id,false);
            return;
        }
        $expiry=(int)($g['refresh_expires_at']??0);
        if ($expiry<=0) {
            global $wpdb;$table=Persistence::table('oauth-tokens');
            $expiry=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(expires_at) FROM `$table` WHERE bucket='oauth-tokens' AND kind='rt' AND grant_id=%s",$id));
            if ($wpdb->last_error) throw new \RuntimeException();
        }
        if ($expiry>0) self::publish('refresh_vencendo','concessao:'.$id,$expiry<=time()+AutomaticMaintenance::policy()['refresh_notice_days']*DAY_IN_SECONDS,$expiry);
    }
    private static array $sampledSites = [];

    private static function cliContext(): bool {
        return (defined('WP_CLI') && WP_CLI) || in_array(PHP_SAPI, ['cli', 'phpdbg'], true);
    }

    private static function markerLock(): string {
        return 'agenda-marker-pass:' . get_current_blog_id();
    }

    private static function beginMarkerPass(): void {
        $site = get_current_blog_id();
        if (isset(self::$markerPass[$site])) return;
        self::$markerPass[$site] = true;
        // Several cron runners may coexist. A concurrent HTTP sample needs this same lock exclusively.
        try { Locks::shareForRequest(self::markerLock()); } catch (\Throwable $error) {}
    }

    private static function markerWritten($cron): void {
        $site = get_current_blog_id();
        foreach (self::$scheduledAt[$site] ?? [] as $timestamp => $_) {
            $event = $cron[$timestamp][CronMarker::HOOK][md5(serialize([]))] ?? [];
            if (($event['schedule'] ?? '') === 'hourly' && ($event['interval'] ?? 0) === 3600 && ($event['args'] ?? null) === []) {
                unset(self::$scheduledAt[$site]);
                self::beginMarkerPass();
                self::interruptAgendaSample();
                return;
            }
        }
    }

    /** Actual execution or a successful scheduling write breaks continuity, even between HTTP reads. */
    private static function interruptAgendaSample(): void {
        try {
            Locks::run(['channel-incidents'=>LOCK_EX], static function() {
                $sample = StateStore::get('automation', 'agenda-sample');
                if (!isset($sample['first_missing_at'])) return;
                $sample['first_missing_at'] = null;
                $sample['status'] = 'interrupted';
                $sample['time'] = time();
                StateStore::put('automation', 'agenda-sample', $sample);
            });
        } catch (\Throwable $error) { /* Observation must not interrupt scheduling or dispatch. */ }
    }

    private static function cachedMarkerPresent(): ?bool {
        $cron = get_option('cron');
        if (!is_array($cron) || ($cron['version'] ?? null) !== 2) return null;
        foreach ($cron as $timestamp => $hooks) {
            if ($timestamp === 'version') continue;
            if (!is_array($hooks)) return null;
            if (array_key_exists(CronMarker::HOOK, $hooks)) return true;
        }
        return false;
    }

    private static function sampleDue(array $previous, int $now): bool {
        $status = $previous['status'] ?? '';
        if ($status === 'active' && $previous['time'] > $now - 300) return self::cachedMarkerPresent() !== true;
        if ($status === 'confirmed' && $previous['time'] > $now - 60) return self::cachedMarkerPresent() !== false;
        if ($status === 'pending' && isset($previous['first_missing_at'])) {
            $elapsed = $now - $previous['first_missing_at'];
            if ($elapsed >= 0 && $elapsed < AutomaticMaintenance::policy()['agenda_confirmation_seconds']) {
                return self::cachedMarkerPresent() !== false;
            }
        }
        return true;
    }

    /** Sample the final state, after the application had the opportunity to restore a transient absence. */
    public static function observeAgenda(): void {
        $site = get_current_blog_id();
        if (self::cliContext() || !doing_action('shutdown') || !did_action('wp_loaded')
            || isset(self::$agendaObserved[$site]) || isset(self::$markerPass[$site])) return;
        self::$agendaObserved[$site] = true;
        try {
            if (!self::sampleDue(StateStore::get('automation', 'agenda-sample') ?? [], time())) return;
            Locks::run([self::markerLock()=>LOCK_EX, 'channel-incidents'=>LOCK_EX], static function() {
                $previous = StateStore::get('automation', 'agenda-sample') ?? [];
                $now = time();
                if (!self::sampleDue($previous, $now)) return;
                $state = CronMarker::agendaState();
                $policy = AutomaticMaintenance::policy();
                $window = $policy['agenda_confirmation_seconds'];
                $sample = ['time'=>$now, 'status'=>'inconclusive', 'first_missing_at'=>null,
                    'confirmation_seconds'=>$window, 'policy_revision'=>AutomaticMaintenance::revision($policy)];
                if ($state === 'active') {
                    $sample['status'] = 'active';
                    self::publish('agenda_parada', 'marcador-wordpress', false);
                } elseif ($state === 'missing') {
                    $first = $previous['first_missing_at'] ?? null;
                    $sample['first_missing_at'] = $first !== null && $first <= $now ? $first : $now;
                    $sample['status'] = 'pending';
                    if (($previous['status'] ?? '') === 'confirmed' || $now - $sample['first_missing_at'] >= $window) {
                        $sample['status'] = 'confirmed';
                        self::publish('agenda_parada', 'marcador-wordpress', true, null, $sample['first_missing_at']);
                    }
                }
                StateStore::put('automation', 'agenda-sample', $sample);
            }, 0.0);
        } catch (\Throwable $error) { /* An unreadable sample cannot establish absence or recovery. */ }
    }

    /** One completed HTTP sample per site and request, shared with the optional Core observer. */
    public static function observeRegistration(bool $force = false): void {
        $site = get_current_blog_id();
        if ((defined('WP_CLI') && WP_CLI) || in_array(PHP_SAPI, ['cli', 'phpdbg'], true)
            || isset(self::$sampledSites[$site]) || !did_action('wp_loaded') || doing_action('init')
            || doing_action('rest_api_init') || doing_action('f3_mcp_adapter_init') || doing_action('wp_abilities_api_init')) {
            return;
        }
        try {
            Locks::run(['channel-incidents'=>LOCK_EX], static function() use ($force, $site) {
                $previous = StateStore::get('automation', 'registration-sample') ?? [];
                if (!$force && empty($previous['failures']) && ($previous['time'] ?? 0) > time() - 300) return;
                self::$sampledSites[$site] = true;
                $snapshot = ConnectionStatus::snapshot(true);
                if (in_array('mcp_registry_error', $snapshot['errors'], true)) return;
                if ($snapshot['core_loaded'] && $snapshot['server_enabled'] && !$snapshot['registry_checked']) return;
                $failed = !empty($snapshot['errors']);
                $count = $failed ? min(2, 1 + (int) ($previous['failures'] ?? 0)) : 0;
                // A first failure has no transition. The next independent HTTP observation confirms or clears it.
                if ($count !== 1) self::publish('canal_indisponivel', 'registro-wordpress', $failed);
                StateStore::put('automation', 'registration-sample', ['time'=>time(), 'failures'=>$count]);
            });
        } catch (\Throwable $error) {
            // An unavailable sample supplies no evidence of either failure or recovery.
        }
    }

    public static function observe(bool $force=false): void {
        self::observeRegistration($force);
        try { Locks::run(['channel-incidents'=>LOCK_EX],static function() use($force) {
            $last=StateStore::get('automation','incidents')??[];
            if (!$force && (int)($last['time']??0)>time()-300) return;
            $now=time();$policy=AutomaticMaintenance::policy();
            $next=wp_next_scheduled(AutomaticMaintenance::HOOK);
            $late=$next===false || $next<$now-$policy['cron_late_seconds'];
            self::publish('cron_sem_passagem','manutencao-wordpress',$late);
            $sweep=\Fator3\RecoveryV1\Engine::sweep_status();
            if (($sweep['status']??'not_run')!=='not_run' || Recovery::runtime_refresh_status()==='failed') self::publish('canal_indisponivel','sentinela-recuperacao',($sweep['status']??'')==='degraded' || !empty($sweep['unresolved']) || Recovery::runtime_refresh_status()==='failed');
            $run=StateStore::get('automation','last');
            if ($run) {
                $running = $run['status'] === 'running';
                $stale = $running && $run['started_at'] < $now - 900 - $policy['cron_late_seconds'];
                if (!$running || $stale) {
                    $failed = in_array($run['status'], ['failed','invalid_policy'], true);
                    self::publish('integracao_indisponivel','manutencao-automatica',$failed || $stale || !empty($run['stalled']));
                }
            }
            // Bounded cursor, including revoked grants so an existing warning can be closed.
            global $wpdb;$table=Persistence::table('oauth-grants');$after=(int)($last['grant_after']??0);
            $rows=Persistence::rows($wpdb->prepare("SELECT id,payload FROM `$table` WHERE bucket='oauth-grants' AND id>%d ORDER BY id LIMIT 101",$after));
            foreach (array_slice($rows,0,100) as $r) {
                $g=json_decode($r['payload'],true,512,JSON_THROW_ON_ERROR);
                if (!empty($g['grant_id'])) self::grant($g['grant_id'],$g);
                $after=(int)$r['id'];
            }
            StateStore::put('automation','incidents',['time'=>$now,'status'=>'observed','grant_after'=>count($rows)>100?$after:0,
                'has_more'=>count($rows)>100,'core_available'=>(bool)has_filter('f3base_incidente_publicar_v1')]);
        }); } catch (\Throwable $e) {
            try { StateStore::put('automation','incidents',['time'=>time(),'status'=>'failed','error_code'=>'incident_observation_failed']); } catch (\Throwable $ignored) {}
        }
    }
}
