# Fator3 Site Core1.61.1 — fonte

Base canônica1.61.0; contrato8.26.0. Pedidos337/340/341/342 e343(c), preservando a entrega anterior. Código instalável em `work/plugin/base-site-core-fator3/`; somente o ZIP instalador é instalável.

`build/package-installer.py` verifica PHP e fecha o instalador determinístico. `tests/run-lab.py` executa WordPress/MySQL descartáveis. `tests/native-matrix-1611.py` cobre instalação limpa e atualização nativa da base em WP7.1.3 e7.1.2; forneça a base e runtimes em variáveis F3BASE. Complementos são pacotes separados, conforme build/COMPANIONS.md. Não executar fixtures no banco compartilhado.

Documentação instalada em docs/DOCUMENTACAO.md e ACERVOS-E-EMAIL-1.61.1.md. Provas correntes em evidence/1611; versões anteriores são históricas. Controlador Site-Teste é temporário, confinado a prefixo e diretório próprios; fica fora do instalador. O relatório externo é canônico para os hashes finais.
