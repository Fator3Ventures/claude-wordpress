# Acompanhantes considerados — Core 1.61.1

Base canônica Core 1.61.0. Pacotes acompanhantes fornecidos separadamente e não modificados. A matriz comprova as fronteiras exercitadas, não todas as funções dos produtores.

| Pacote | Versão | Fronteira testada |
| --- | --- | --- |
| wp-mcp-fator3 | 0.37.0 | Autorização, catálogo, documentação, upload com hash e sondas. |
| wp-mcp-google-fator3 | 0.23.0 | google-ads-reader/1.0.0; search-console-reader/1.1.0; preservação do acervo GSC páginas. |
| wp-mcp-meta-fator3 | 0.15.0 | meta-ads-monitoring/1.0.0; regressão meta-ads-reader/1.0.0. |
| wp-mcp-linkedin-fator3 | 0.13.0 | Bootstrap e convivência sem troca do cliente selecionado. |
| wp-mcp-pipedrive-fator3 | 0.4.0 | Bootstrap no PHP 8.3.36 do Site-Teste; não ativado no piso Core PHP 8.3.6. |

Google 0.23.0: instalador 883618 bytes, SHA-256 `8100b62144f4e368349ed1798c5bd9c84da66028010bc2946281853b982faab8`.
Meta 0.15.0: instalador 305286 bytes, SHA-256 `521e8f83a8c6fad12497e7c9f40ec6cf8cb129060c6a56e89955257ca22f81f3`.
As identidades dos anexos novos, fontes e relatórios estão em `inputs/1611/packages.json`; MCP/LinkedIn/Pipedrive permanecem em `inputs/1610/pacotes-reconferidos.json`.

A matriz local usa WordPress 7.1.3/PHP 8.3.6 e os SDKs Google/Meta reais com respostas HTTP sintéticas. A matriz nativa de instalação Core isolado inclui WordPress 7.1.2/PHP 8.3.6. A bancada isolada do Site-Teste usa WordPress 7.1.4/PHP 8.3.36 e os cinco acompanhantes ativos, copiados do site sem alterações.

Nenhum teste de integração sintético pode chamar fornecedor ou enviar mensagem real. O prefixo e diretório da bancada remota são exclusivos, validados antes de qualquer escrita e removidos ao terminar. A rotina pós-atualização já existente do site compartilhado conservou suas verificações próprias; seu recibo não é aceite comercial desta release.

A integração Google usa `f3base_google_ads_acervo`, preservando `f3base_google_ads` para conversão/tag. Não aplicar o patch de consumidor recebido para a base antiga. Concessões Ads, GSC consultas e monitoramento Meta são explícitas e distintas das anteriores. Novos leitores desativados por padrão. Credenciais permanecem nos produtores respectivos.

As instruções da matriz anterior foram preservadas em `history/1610/COMPANIONS.md`. Os binários dos acompanhantes não são redistribuídos dentro deste fonte. Aceites reais de contas e dados dependem do dono/frota e dos responsáveis Google/Meta; Pipedrive real somente nos sites autorizados pelo dono.
