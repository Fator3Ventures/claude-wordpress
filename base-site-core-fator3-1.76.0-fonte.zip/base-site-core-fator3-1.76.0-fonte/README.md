# Fator3 Site Core 1.76.0

O runtime instalável está em work/plugin/base-site-core-fator3. A base de migração é a 1.75.1. Os documentos instalados e as notas dos pedidos 383–385 estão em docs/. A cópia do relatório antecede o fechamento deste fonte.

## Reprodução

Com Python 3, execute a partir da raiz desta árvore, preservando seu nome.

```bash
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.76.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.76.0-fonte.zip
```

Para reproduzir os assets, execute npm ci em build/node. Rode python3 build/assets-1760.py para verificar os 84 JS e o catálogo PHP. Use a opção --output apenas em cópia de trabalho. O Terser do lockfile é 5.44.1. Os testes podem atualizar suas evidências.

## Testes desta rodada

Em um MySQL 8 local descartável, com acesso root local sem senha e porta indicada por F3BASE_LAB_PORT, execute os dois comandos com diretórios novos e o arquivo oficial do WordPress 7.1.4. O PHP CLI precisa de mysqli, mysqlnd, mbstring, sodium e das extensões do WordPress.

```bash
F3BASE_PHASE=fresh python3 tests/run-1760.py --wordpress-archive /caminho/wordpress-7.1.4.zip --lab /tmp/f3-1760-limpo --php /caminho/php
F3BASE_PHASE=upgrade python3 tests/run-1760.py --wordpress-archive /caminho/wordpress-7.1.4.zip --lab /tmp/f3-1760-migracao --php /caminho/php
CHROMIUM=/caminho/chromium-headless-shell python3 tests/browser-1760.py
```

O teste de navegador requer Playwright para Python. Os quatro fluxos usam assets minificados. A bancada PHP intercepta HTTP da Meta e a seleção dos adaptadores comerciais durante a requisição. As provas e seus limites estão em evidence/1760/. Os arquivos em evidence/1750/ e os roteiros com número de versão anterior são históricos.

A bancada temporária do Site-Teste é reproduzida concatenando tests/site-teste-1760.php e tests/crm-1760.php, retirando a segunda tag de abertura PHP. Só o administrador com acesso a contatos, no host de teste e com o Core 1.76.0, pode executar o caso fixo. A instalação desse arquivo faz parte da homologação e a remoção encerra a bancada. O instalador do Core contém somente a árvore de runtime.
