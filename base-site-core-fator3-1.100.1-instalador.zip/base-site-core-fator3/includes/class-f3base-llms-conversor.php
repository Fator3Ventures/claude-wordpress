<?php
/** Conversão editorial de blocos armazenados. Representações editoriais públicas e limitadas. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Llms_Conversor {
	public const MAX_BYTES        = 4194304;
	public const MAX_BLOCOS       = 10000;
	public const MAX_PROFUNDIDADE = 12;
	private int $post_id = 0;
    private array $shortcodes = [];
    private int $bytes_pedido = 0;
    private const MAX_ITENS = 32;
    private const MAX_PEDIDO = 65536;
    private const MAX_RESPOSTA = 1048576;
    private const PRAZO_HTTP = 6;
    private const MAX_SHORTCODE = 262144;
    private int $bytes            = 0;
	private int $blocos           = 0;
	private array $avisos         = array();
	private array $erros          = array();
	private array $referencias    = array();

	public static function converter( string $conteudo, string $base, int $nivel = 2, int $post_id = 0 ): array {
		$c    = new self();
        $c->post_id = $post_id;

		$html = $c->preencher_shortcodes($c->conteudo($conteudo, [], 0));
		try {
			$texto = F3Base_Llms::html_markdown( $html, $base, $nivel );
		} catch ( RuntimeException $erro ) {
			$texto      = '';
			$c->erros[] = $erro->getMessage(); }
		if ( ! class_exists( 'DOMDocument' ) ) {
			$c->avisos[] = 'dom_indisponivel: formato convertido como texto simples'; }
		if ($c->avisos && trim($texto)==='') { $c->erros[]='sem_conteudo_editorial'; }
        if ( strlen( $texto ) > self::MAX_BYTES ) {
			$c->erros[] = 'volume_markdown_excedido'; }
		return array(
			'texto'       => $c->erros ? '' : $texto,
			'completo'    => ! $c->erros,
			'avisos'      => array_values( array_unique( $c->avisos ) ),
			'erros'       => array_values( array_unique( $c->erros ) ),
			'referencias' => array_values( array_unique( $c->referencias ) ),
			'bytes_fonte' => $c->bytes,
			'blocos'      => $c->blocos,
		);
	}
    private function shortcode(string $codigo): string {
        if (!$this->post_id || strlen($codigo) > 8192 ||
            !preg_match('/^' . get_shortcode_regex() . '$/sD', $codigo, $m) ||
            $m[1] !== '' || $m[6] !== '' || !shortcode_exists($m[2])) {
            $this->avisos[] = 'shortcode_indisponivel';
            return '';
        }
        if (count($this->shortcodes) >= self::MAX_ITENS || $this->bytes_pedido + strlen($codigo) > self::MAX_PEDIDO) {
            $this->avisos[] = 'shortcode_limite_documento:' . $m[2];
            return '';
        }
        // O marcador aleatório evita substituir texto idêntico escrito pelo autor.
        $marcador = '<!--' . wp_generate_uuid4() . '-->';
        $this->shortcodes[$marcador] = ['codigo' => $codigo, 'tag' => $m[2]];
        $this->bytes_pedido += strlen($codigo);
        return $marcador;
    }

    private function preencher_shortcodes(string $html): string {
        if (!$this->shortcodes) { return $html; }
        $url = get_permalink($this->post_id);
        $fragmentos = [];
        if ($url && wp_parse_url($url, PHP_URL_HOST) === wp_parse_url(home_url(), PHP_URL_HOST)) {
            $lista = wp_json_encode(array_column($this->shortcodes, 'codigo'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $ate = time() + 15;
            $sig = self::assinatura_lote($this->post_id, $ate, $lista);
            $r = wp_remote_post($url, [
                'timeout' => self::PRAZO_HTTP, 'redirection' => 0, 'cookies' => [],
                'limit_response_size' => self::MAX_RESPOSTA + 1,
                'body' => ['f3base_llms_render' => $sig, 'ate' => $ate, 'lista' => $lista],
            ]);
            $body = wp_remote_retrieve_body($r);
            if (wp_remote_retrieve_response_code($r) === 200 && strlen($body) <= self::MAX_RESPOSTA &&
                hash_equals($sig, (string) wp_remote_retrieve_header($r, 'x-f3base-render'))) {
                $itens = json_decode($body, true);
                if (is_array($itens) && array_is_list($itens) && count($itens) === count($this->shortcodes)) {
                    $fragmentos = $itens;
                }
            }
        }
        $saida = [];
        $i = 0;
        foreach ($this->shortcodes as $marcador => $item) {
            $trecho = $fragmentos[$i++] ?? null;
            $saida[$marcador] = '';
            if (!is_string($trecho) || strlen($trecho) > self::MAX_SHORTCODE) {
                $this->avisos[] = 'shortcode_renderizacao_incompleta:' . $item['tag'];
                continue;
            }
            if ($this->bytes + strlen($trecho) > self::MAX_BYTES) {
                $this->avisos[] = 'shortcode_volume_excedido:' . $item['tag'];
                continue;
            }
            $this->bytes += strlen($trecho);
            $saida[$marcador] = $trecho;
        }
        return strtr($html, $saida);
    }

    private static function assinatura_lote(int $id, int $ate, string $lista): string {
        return hash_hmac('sha256', 'llms-lote|' . $id . '|' . $ate . '|' . $lista, wp_salt('auth'));
    }

    public static function renderizar_publico(): void {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !isset($_POST['f3base_llms_render'])) { return; }
        nocache_headers();
        $id = get_queried_object_id();
        $post = get_post($id);
        $lista = wp_unslash($_POST['lista'] ?? '');
        $ate = (int) ($_POST['ate'] ?? 0);
        $assinatura = $_POST['f3base_llms_render'];
        if (!is_string($assinatura) || !is_string($lista) || strlen($lista) > self::MAX_PEDIDO * 6 + 128 ||
            $ate < time() || $ate > time() + 15 || !hash_equals(self::assinatura_lote($id, $ate, $lista), $assinatura) ||
            is_user_logged_in() || !is_singular() || !$post || !is_post_publicly_viewable($post) ||
            $post->post_password !== '' || !F3Base_Llms::site_publico() || F3Base_Modulo_Noindex_Honrado::post_e_noindex($id)) {
            status_header(403); exit;
        }
        $codigos = json_decode($lista, true);
        if (!is_array($codigos) || !array_is_list($codigos) || count($codigos) > self::MAX_ITENS) { status_header(422); exit; }
        $fim = microtime(true) + self::PRAZO_HTTP - 1;
        $resultado = [];
        $bytes = 2 + count($codigos) * 5;
        foreach ($codigos as $codigo) {
            $trecho = null;
            if (is_string($codigo) && strlen($codigo) <= 8192 && microtime(true) < $fim) {
                ob_start(static fn($buf) => '', 4096);
                try {
                    $valor = do_shortcode($codigo);
                    if (is_string($valor) && strlen($valor) <= self::MAX_SHORTCODE) {
                        $valor = wp_kses_post($valor);
                        $json = wp_json_encode($valor, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                        if ($json !== false && $bytes + strlen($json) <= self::MAX_RESPOSTA) {
                            $bytes += strlen($json);
                            $trecho = $valor;
                        }
                    }
                } catch (Throwable $erro) {
                    $trecho = null;
                } finally {
                    ob_end_clean();
                }
            }
            $resultado[] = $trecho;
        }
        header('X-F3Base-Render: ' . $assinatura);
        wp_send_json($resultado, 200, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
	private function conteudo( string $texto, array $pilha, int $nivel ): string {
		$this->bytes += strlen( $texto );
		if ( $nivel > self::MAX_PROFUNDIDADE || $this->bytes > self::MAX_BYTES ) {
			$this->erros[] = 'limite_de_conversao';
			return ''; }
		if ( ! function_exists( 'parse_blocks' ) ) {
			return $texto; }
		$html = '';
		foreach ( parse_blocks( $texto ) as $bloco ) {
			$html .= $this->bloco( $bloco, $pilha, $nivel ); }
		return $html;
	}
	private function bloco( array $bloco, array $pilha, int $nivel ): string {
		if ( ++$this->blocos > self::MAX_BLOCOS || $nivel > self::MAX_PROFUNDIDADE ) {
			$this->erros[] = 'limite_de_conversao';
			return ''; }
		$nome    = (string) ( $bloco['blockName'] ?? '' );
		$excluir = (array) ( F3Base_Options::ler( 'f3base_llms' )['blocos_interface'] ?? array() );
		if ( in_array($nome,array('f3base/formulario','core/navigation'),true) || in_array( $nome, $excluir, true ) || ( 'core/shortcode' === $nome && preg_match( '/^\s*\[f3base_formulario\s+id=["\'][a-z][a-z0-9_-]*["\']\s*\]\s*$/D', (string) ( $bloco['innerHTML'] ?? '' ) ) ) ) {
			$this->avisos[] = 'interface_referenciada:' . $nome;
			return '<p><em>Formulário interativo: consulte a página original para preencher e enviar.</em></p>';
		}
		if ( 'core/query' === $nome ) {
			$q = $bloco['attrs']['query'] ?? array();
			if ( ! empty( $q['inherit'] ) || isset( $q['taxQuery'] ) || isset( $q['metaQuery'] ) ) {
				$this->avisos[] = 'consulta_nao_suportada';
				return ''; }
			$tipo = (string) ( $q['postType'] ?? 'post' );
			if ( ! is_post_type_viewable( $tipo ) ) {
				$this->avisos[] = 'consulta_tipo_nao_publico';
				return ''; }
			$posts = get_posts(
				array(
					'post_type'        => $tipo,
					'post_status'      => 'publish',
					'has_password'     => false,
					'numberposts'      => max( 1, min( 50, (int) ( $q['perPage'] ?? 10 ) ) ),
					'orderby'          => 'date',
					'order'            => ( 'asc' === strtolower( $q['order'] ?? '' ) ) ? 'ASC' : 'DESC',
					'suppress_filters' => false,
				)
			);
			$html  = '<ul>';
			foreach ( $posts as $post ) {
				if ( ! F3Base_Modulo_Noindex_Honrado::post_e_noindex( $post->ID ) ) {
					$html .= '<li><a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( $post->post_title ) . '</a></li>';
				}
			} return $html . '</ul>';
		}

		if ( 'core/block' === $nome ) {
			$id = (int) ( $bloco['attrs']['ref'] ?? 0 );
			if ( $id < 1 || in_array( $id, $pilha, true ) ) {
				$this->avisos[] = 'referencia_circular_ou_invalida';
				return ''; }
			// wp_block não tem permalink indexável; o noindex implícito do tipo não proíbe a incorporação.
			// Status, senha e uma exclusão noindex explícita continuam sendo restrições de conteúdo.
			$post = get_post( $id );
			if ( ! $post instanceof WP_Post || 'wp_block' !== $post->post_type || 'publish' !== $post->post_status || '' !== $post->post_password || ! F3Base_Llms::site_publico() || '1' === (string) get_post_meta( $id, F3Base_Chaves_Seo::NOINDEX, true ) ) {
				$this->avisos[] = 'referencia_protegida_omitida:' . $id;
				return ''; }
			$this->referencias[] = $id;
			return $this->conteudo( $post->post_content, array_merge( $pilha, array( $id ) ), $nivel + 1 );
		}
		// Um formulário conhecido é interface, não corpo editorial. Não expandir seu shortcode.
		// A nota permanece visível no Markdown; outros shortcodes continuam incompletos.
		if ( 'core/shortcode' === $nome && shortcode_exists( 'contact-form-7' ) ) {
			$texto = trim( (string) ( $bloco['innerHTML'] ?? '' ) );
			if ( preg_match( '/^' . get_shortcode_regex( array( 'contact-form-7' ) ) . '$/sD', $texto, $partes ) && '' === $partes[1] && '' === $partes[6] && empty( $partes[5] ) ) {
				$atributos = shortcode_parse_atts( $partes[3] );
				if ( is_array( $atributos ) && preg_match( '/^[a-zA-Z0-9_-]{1,64}$/D', (string) ( $atributos['id'] ?? '' ) ) ) {
					$this->avisos[] = 'formulario_interativo_referenciado:contact-form-7';
					return '<p><em>Formulário interativo: consulte a página original para preencher e enviar.</em></p>'; }
			}
		}
        if ($nome === 'core/shortcode') { return $this->shortcode(trim($bloco['innerHTML'] ?? '')); }
        if ($nome === 'core/template-part') {
            $slug = $bloco['attrs']['slug'] ?? '';
            $theme = $bloco['attrs']['theme'] ?? get_stylesheet();
            if (!is_string($slug) || !preg_match('/^[a-z0-9_-]{1,200}$/D',$slug) || !in_array($theme,[get_stylesheet(),get_template()],true)) {
                $this->avisos[]='modelo_invalido'; return '';
            }
            $key=$theme.'//'.$slug;
            $part=in_array($key,$pilha,true) ? null : get_block_template($key,'wp_template_part');
            $id=(int)($part->wp_id ?? 0);
            if (!$part || ($part->status ?? 'publish')!=='publish' || ($id && (get_post_field('post_password',$id)!=='' || get_post_meta($id,F3Base_Chaves_Seo::NOINDEX,true)==='1'))) {
                $this->avisos[]='modelo_ausente_protegido_ou_circular:'.$slug; return '';
            }
            if ($id) { $this->referencias[]=$id; }
            return $this->conteudo($part->content, array_merge($pilha,[$key]), $nivel+1);
        }
		// O botão possui HTML editorial salvo mesmo quando o WordPress registra um render_callback.
		// Bindings podem substituir texto/URL em runtime e não são resolvidos por esta conversão.
		if ( 'core/button' === $nome && ! empty( $bloco['attrs']['metadata']['bindings'] ) ) {
			$this->avisos[] = 'bloco_vinculado_nao_convertido:' . $nome;
			return ''; }
		// Estes nomes têm representação editorial persistida. Nenhum callback de renderização é executado.
		$estaticos = array( '', 'core/paragraph', 'core/heading', 'core/list', 'core/list-item', 'core/table', 'core/quote', 'core/pullquote', 'core/code', 'core/preformatted', 'core/verse', 'core/image', 'core/gallery', 'core/group', 'core/columns', 'core/column', 'core/cover', 'core/media-text', 'core/separator', 'core/spacer', 'core/html', 'core/freeform', 'core/details', 'core/more', 'core/nextpage', 'core/buttons', 'core/button' );
		if ( ! in_array( $nome, $estaticos, true ) ) {
			$registrado = class_exists( 'WP_Block_Type_Registry' ) ? WP_Block_Type_Registry::get_instance()->get_registered( $nome ) : null;
			if ( 'core/shortcode' === $nome || ( $registrado && $registrado->is_dynamic() ) ) {
				$this->avisos[] = 'bloco_dinamico_nao_convertido:' . $nome;
				return ''; }
			$this->avisos[] = 'bloco_desconhecido_html_armazenado:' . $nome;
			if ( '' === trim( (string) ( $bloco['innerHTML'] ?? '' ) ) && empty( $bloco['innerBlocks'] ) ) {
				$this->avisos[] = 'bloco_sem_representacao:' . $nome;
				return ''; }
		}
		if ( empty( $bloco['innerBlocks'] ) ) {
			return (string) ( $bloco['innerHTML'] ?? '' ); }
		$html = '';
		$i    = 0;
		foreach ( $bloco['innerContent'] ?? array() as $parte ) {
			$html .= null === $parte ? $this->bloco( (array) ( $bloco['innerBlocks'][ $i++ ] ?? array() ), $pilha, $nivel + 1 ) : (string) $parte;
		}
		return $html;
	}
}
