<?php
/** Diagnóstico administrativo: evidência de falha e ausência de observação são estados distintos. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Medicao_Saude {
    public static function consultar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        global $wpdb;$dias=array();$cols=array();$args=array();
        for($i=6;$i>=0;--$i){$dia=wp_date('Y-m-d',time()-$i*DAY_IN_SECONDS);[$de,$ate]=F3Base_Editorial::janela_dia($dia);$dias[]=$dia;$cols[]='COALESCE(SUM(criado_em>=%d AND criado_em<%d),0) d'.$i;$args[]=$de;$args[]=$ate;}
        [$inicio]=F3Base_Editorial::janela_dia($dias[0]);$seg="classe_trafego<>'teste' AND automacao NOT IN ('declarada','provavel')";
        $pagina=$wpdb->get_row($wpdb->prepare('SELECT MAX(criado_em) ultimo,'.implode(',',$cols).' FROM %i WHERE criado_em>=%d AND tipo=%s AND '.$seg,array_merge($args,array(F3Base_Analise::tabela(),$inicio,'pagina'))),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'diagnostico_indisponivel');}
        $eventos=$wpdb->get_row($wpdb->prepare('SELECT MAX(criado_em) ultimo,'.implode(',',$cols).' FROM %i WHERE criado_em>=%d AND metrica IN (%s,%s) AND '.$seg,array_merge($args,array(F3Base_Modulo_Comportamento::nome_tabela_eventos(),$inicio,F3Base_Modulo_Comportamento::evento_do_gatilho('rolagem'),F3Base_Modulo_Comportamento::evento_do_gatilho('interseccao')))),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'diagnostico_indisponivel');}
        $rows=array();$alertas=array();foreach($dias as $index=>$dia){$k='d'.(6-$index);$n=(int)($pagina[$k]??0);$m=(int)($eventos[$k]??0);$estado=$n===0?'sem_paginas_observadas':($m===0?'sem_sinais_de_consumo':'observado');$rows[]=array('dia'=>$dia,'paginas'=>$n,'eventos_consumo'=>$m,'estado'=>$estado);if($n>=10&&$m===0){$alertas[]=$dia.': '.$n.' páginas vistas sem eventos de rolagem ou seção. Verifique marcação, consentimento e entrega dos scripts; isso não comprova falha.';}}
        $sequencia=array();$sequencias=array();foreach($rows as $row){if($row['dia']<wp_date('Y-m-d')&&$row['estado']==='sem_sinais_de_consumo'){$sequencia[]=$row['dia'];}else{if(count($sequencia)>=2){$sequencias[]=$sequencia;}$sequencia=array();}}if(count($sequencia)>=2){$sequencias[]=$sequencia;}
        foreach($sequencias as $seq){$alertas[]='sem_sinais_de_consumo_consecutivos: '.count($seq).' dias seguidos ('.$seq[0].' a '.end($seq).') com páginas observadas e nenhum sinal de consumo. Verifique scripts, consentimento e automação; ausência de sinal não comprova falha.';}
        $health=F3Base_Options::ler('f3base_analise_saude');$last=$health['ultima_operacional']??array();if(!isset($last['automacao'])||in_array($last['automacao'],array('declarada','provavel'),true)){$last=array();}$ligado=F3Base_Modulo_Comportamento::ligado();$estado=$ligado?'observado':'desligado';
        if($ligado&&(!$pagina['ultimo']||(int)$pagina['ultimo']<time()-2*DAY_IN_SECONDS)){$estado='sem_dados_recentes';$alertas[]='Sem páginas observadas nas últimas 48 horas. Confira tráfego, consentimento, scripts e endpoint. A ausência isolada não identifica a causa.';}
        if($ligado&&($last['classe_trafego']??'')!=='teste'&&($last['codigo']??'confirmado')!=='confirmado'&&($last['em']??0)>time()-DAY_IN_SECONDS){$estado='falha_observada';$alertas[]='O último resultado operacional do endpoint foi '.$last['codigo'].'. Consulte os registros de operação e a recuperação.';}
        $catalogo=F3Base_Options::ler('f3base_editorial_estado');$cron=wp_next_scheduled(F3Base_Editorial::EVENTO);if($cron&&$cron<time()-3600){$alertas[]='Consolidação editorial agendada há mais de uma hora; confira o executor do WordPress.';}
        return array('ok'=>true,'estado'=>$estado,'ligado'=>$ligado,'ultima_pagina'=>(int)($pagina['ultimo']??0),'ultimo_consumo'=>(int)($eventos['ultimo']??0),'endpoint'=>$last,'diagnostico_diario'=>$health['dias']??array(),'contagens_automacao'=>$health['contagens_automacao']??array(),'ultima_automacao'=>$health['ultima_automacao']??null,'falha_500'=>$health['ultima_falha_500']??null,'sequencias_sem_consumo'=>$sequencias,'dias'=>$rows,'alertas'=>$alertas,'proxima_consolidacao'=>$cron?:null,'catalogo_completo'=>!empty($catalogo['catalogo_completo'])&&!empty($catalogo['reparacao_1180_concluida']),'limite'=>'Últimos sete dias no fuso do site, dentro da retenção bruta. Testes e sinais de automação ficam fora desta amostra; anotações não apagam a evidência técnica. Sem eventos não prova ausência de visitantes ou falha. Não executa sondas nem requisições públicas.');
    }
    public static function render(): void {
        $r=self::consultar();echo '<section class="f3-section"><h2>Saúde da coleta</h2>';if(empty($r['ok'])){echo '<p role="alert">Diagnóstico indisponível.</p></section>';return;}
        $estados = ['observado'=>['is-ok','Ativo'],'desligado'=>['','Desligado'],'sem_dados_recentes'=>['is-warn','Sem dados recentes'],'falha_observada'=>['is-error','Falhou']];
        [$classe,$rotulo] = $estados[$r['estado']] ?? ['is-info',str_replace('_',' ',$r['estado'])];
        echo '<p>Estado: <span class="f3-pill '.esc_attr($classe).'">'.esc_html($rotulo).'</span>. '.esc_html($r['limite']).'</p>';
        foreach($r['alertas'] as $a){echo '<p class="f3-callout is-warn">'.esc_html($a).'</p>';}F3Base_Relatorios::tabela($r['dias']);echo '</section>';
    }
}
