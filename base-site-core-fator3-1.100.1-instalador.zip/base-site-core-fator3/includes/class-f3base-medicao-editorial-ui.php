<?php
/** Interface editorial acessível; os mesmos filtros alimentam painel, CSV e ability. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Medicao_Editorial_UI {
    const AREAS=array('geral'=>'Visão geral','conteudo'=>'Conteúdo','sessoes'=>'Sessões','aquisicao'=>'Aquisição','agentes'=>'IA e robôs','conversao'=>'Conversão','ga4'=>'Acervo GA4','clarity'=>'Clarity','tecnico'=>'Técnico');
    public static function iniciar(): void {add_action('admin_post_f3base_editorial_csv',array(__CLASS__,'csv'));add_action('admin_enqueue_scripts',static function(){if(($_GET['page']??'')==='f3base-medicao'){wp_enqueue_script('f3base-medicao-editorial',F3BASE_PLUGIN_URL.'assets/f3base-medicao-editorial.js',array(),F3BASE_PLUGIN_VERSAO,true);}});}
    public static function url(array $args,array $base=array()): string {return add_query_arg(array_merge(array('page'=>'f3base-medicao'),$base,$args),admin_url('admin.php'));}
    private static function link(string $label,array $args,array $base=array(),string $class=''): string {return '<a class="'.esc_attr($class).'" href="'.esc_url(self::url($args,$base)).'">'.esc_html($label).'</a>';}
    public static function filtros(array $raw): array {
        $r=array();foreach(F3Base_Editorial_Relatorios::schema() as $k=>$s){if(!isset($raw[$k])||$raw[$k]===''){continue;}if($s['type']==='integer'){$r[$k]=(int)$raw[$k];}elseif($s['type']==='boolean'){$r[$k]=in_array($raw[$k],array(true,1,'1','true'),true);}elseif(is_string($raw[$k])){$r[$k]=sanitize_text_field(wp_unslash($raw[$k]));}}
        return $r;
    }
    public static function render(): bool {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}
        $pedida = is_string($_GET['area'] ?? null) ? sanitize_key($_GET['area']) : '';
        $area = isset(self::AREAS[$pedida]) ? $pedida : 'geral';
        if (($_GET['aba']??'')==='acessos') { return false; }
        if (in_array($area, ['ga4', 'clarity'], true)) {
            self::abrir($area, self::filtros($_GET));
            echo '<section class="f3-section">';
            if ($area === 'ga4') F3Base_Ga4::render();
            else F3Base_Clarity::render();
            echo '</section></div>';
            return true;
        }
        if(in_array($area,array('conversao','tecnico'),true)||($_GET['area']??'')==='comportamento'){return false;}
        $views = self::analises($area);
        $solicitada = is_string($_GET['visao'] ?? null) ? sanitize_key($_GET['visao']) : '';
        $view = isset($views[$solicitada]) ? $solicitada : array_key_first($views);
        if (($area === 'aquisicao' && $view === 'campanhas') || ($area === 'sessoes' && $view !== 'sessoes')) return false;
        $e=self::filtros($_GET);unset($e['visao']);$e+=array('anotacoes'=>!empty(F3Base_Options::ler('f3base_medicao_editorial')['aplicar_anotacoes']),'de'=>wp_date('Y-m-d',time()-29*DAY_IN_SECONDS),'ate'=>wp_date('Y-m-d'),'segmento'=>F3Base_Testes::segmento(),'automacao'=>!empty(F3Base_Options::ler('f3base_medicao_editorial')['excluir_automacao'])?'audiencia':'todas');if($area==='sessoes'){$e+=array('ordenar'=>'inicio','direcao'=>'desc');}
        $e['visao']=$area==='conteudo'?'conteudo':($area==='sessoes'&&isset($e['sessao'])?'sessao':$view);if($area==='conteudo'){$e['tipo']=$view;}
        $base=array_merge($e,array('area'=>$area,'visao'=>$view));unset($base['pagina'],$base['limite']);if($area==='agentes'&&in_array($view,array('resumo','horas','frequencia'),true)){foreach(F3Base_Agentes::schema() as $k=>$spec){if(in_array($k,array('pagina','visao'),true)||!isset($_GET[$k])||!is_scalar($_GET[$k])){continue;}$base[$k]=$spec['type']==='boolean'?in_array($_GET[$k],array('1','true'),true):($spec['type']==='integer'?(int)$_GET[$k]:sanitize_text_field(wp_unslash($_GET[$k])));}}
        self::abrir($area, $e);
        self::inicio_filtros($area, $view, $base);
        self::form($area, $view, $e, $base);
        echo '</section>';
        $isBots=$area==='agentes'&&in_array($view,array('resumo','horas','frequencia'),true);
        if($isBots){$q=array('de'=>$e['de'],'ate'=>$e['ate'],'visao'=>$view==='resumo'?'conteudo':$view,'pagina'=>$e['pagina']??1);foreach(array('grupo','agente','caminho','classe_caminho','metodo','status','representacao','rede_estado','post_id','assinatura_ua','incluir_tecnico') as $k){if(isset($_GET[$k])&&$_GET[$k]!==''){$q[$k]=in_array($k,array('status','post_id'),true)?(int)$_GET[$k]:($k==='incluir_tecnico'?in_array($_GET[$k],array('1','true'),true):sanitize_text_field(wp_unslash($_GET[$k])));}}$r=F3Base_Agentes::consultar($q);self::bots($r,array_merge($base,$q));echo '</div>';return true;}
        if($view==='gsc'){F3Base_Gsc::render($e);echo '</div>';return true;}
        $r=F3Base_Editorial_Relatorios::consultar($e);if(empty($r['ok'])){echo '<div class="f3-callout is-error" role="alert"><p>Relatório indisponível: '.esc_html($r['codigo']??'consulta_falhou').'. '.esc_html($r['motivo']??'').'</p><pre>'.esc_html(wp_json_encode($r['diagnostico']??array(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></div></div>';return true;}
        if($view==='referencias'){self::referencias($r,$base);echo '</div>';return true;}

        self::status($r);
        if($area==='geral'){echo '<section class="f3-section"><h2>Indicadores do período</h2>';self::cards($r['totais']);echo '</section>';self::ia_resumo($r,$base);self::grafico($r['serie_diaria'],'Visualizações por dia');echo '<section class="f3-section"><h2>Origens observadas</h2>';self::tabela($r['origens'],array('canal'=>'Origem','sessoes'=>'Sessões','visualizacoes'=>'Visualizações','tempo_ativo_ms'=>'Tempo ativo','envios'=>'Envios pareados'),$base);echo '</section>';}
        if($area==='conteudo'&&(!empty($e['post_id'])||!empty($e['caminho']))){echo '<section class="f3-section"><h2>'.esc_html($r['linhas'][0]['titulo']??'Detalhe do conteúdo').'</h2><p>'.self::link('Voltar à lista de conteúdo',array('post_id'=>false,'caminho'=>false),$base).'</p>';self::cards($r['totais']);echo '<p class="f3-actions">'.self::link('Examinar sessões deste conteúdo',array('area'=>'sessoes','visao'=>'sessoes','sessao'=>false),$base,'button').' '.self::link('Ver requisições de IA',array('area'=>'agentes','visao'=>'resumo','tipo'=>false),$base,'button').' '.self::link('Ver referências observadas',array('area'=>'agentes','visao'=>'referencias','tipo'=>false),$base,'button').'</p></section>';self::grafico($r['serie_diaria'],'Visualizações deste conteúdo');}
        if($area==='conteudo'&&(!empty($e['post_id'])||!empty($e['caminho']))){self::detalhe($r,$base);echo '<section class="f3-section"><h2>Requisições de IA neste conteúdo</h2><p>GET 200, HEAD sem corpo e revalidação 304 são medidas distintas. Não comprovam citação, recomendação ou treinamento.</p>';self::tabela($r['ia_por_conteudo']??array(),array('nome_agente'=>'Agente declarado','finalidade'=>'Finalidade','representacao'=>'Formato','rede_estado'=>'Rede','metodo'=>'Método','status'=>'HTTP','resposta'=>'Entrega','requisicoes'=>'Requisições','primeiro_em'=>'Primeiro acesso','ultimo_em'=>'Último acesso'),$base);echo '<details class="f3-collapsible"><summary>Série semanal de IA — semanas parciais e cobertura</summary>';F3Base_Relatorios::tabela($r['ia_serie_semanal']??array());echo '</details></section>';}
        echo '<section class="f3-section">';
        if($e['visao']==='sessao'){echo '<h2>Jornada da sessão</h2><p><code>'.esc_html($e['sessao']).'</code> <button type="button" class="button" data-f3m-copy="'.esc_attr($e['sessao']).'">Copiar ID</button></p><p>Eventos disponíveis na retenção. Conteúdo selecionado é destacado; abas sem vínculo não formam uma transição comprovada.</p>';self::tabela($r['linhas'],array('em'=>'Horário','caminho'=>'Conteúdo','acao'=>'Acontecimento','detalhe'=>'Detalhe','qualidade'=>'Qualidade'),$base);echo '<details class="f3-collapsible"><summary>Web Vitals e dados técnicos</summary>';self::tabela($r['dados_tecnicos'],array('em'=>'Horário','metrica'=>'Métrica','valor'=>'Valor','unidade'=>'Unidade','automacao'=>'Automação'),$base);echo '</details>';}
        elseif($area==='sessoes'){echo '<h2>Sessões observadas</h2>';self::tabela($r['linhas'],array('sessao'=>'Sessão','inicio'=>'Entrada observada','entrada'=>'Página de entrada','canal'=>'Origem','visualizacoes'=>'Visualizações','tempo_ativo_ms'=>'Tempo ativo','envios'=>'Envios'),$base);}
        elseif($area==='aquisicao'||$view==='origem_ia'){echo '<h2>'.($view==='origem_ia'?'Visitas encaminhadas por IA':'Canais de aquisição').'</h2><p>Origem da entrada da sessão. Referenciador ausente permanece direto / desconhecido; identificadores sociais isolados não comprovam mídia paga.</p>';self::tabela($r['linhas'],array('canal'=>'Origem','sessoes'=>'Sessões','visualizacoes'=>'Visualizações','tempo_ativo_ms'=>'Tempo ativo','cliques'=>'Cliques','envios'=>'Envios'),$base);}
        else{echo '<h2>'.($area==='geral'?'Conteúdo observado':$views[$view]).'</h2>';self::tabela($r['linhas'],array('titulo'=>'Conteúdo','visualizacoes'=>'Visualizações','sessoes'=>'Sessões','entradas_organicas'=>'Entradas orgânicas','tempo_ativo_ms'=>'Tempo ativo','ia_html'=>'IA: HTML','ia_markdown'=>'IA: Markdown'),$base);echo '<details class="f3-collapsible"><summary>Consumo e ações por conteúdo</summary>';self::tabela($r['linhas'],array('titulo'=>'Conteúdo','visitantes'=>'Visitantes','rolagem_media_pct'=>'Rolagem média (%)','amostra_rolagem'=>'Navegações com rolagem','cliques'=>'Cliques de contato','form_inicios'=>'Inícios de formulário','envios'=>'Envios aceitos'),$base);echo '</details>';}
        if($area==='conteudo'||$area==='geral'){echo '<details class="f3-collapsible"><summary>Saída, duração e ações de navegação</summary><p>A última saída recebida por navegação fornece duração decorrida, tempo em tela visível e profundidade. Saltos de rolagem são separados dos gestos. Ausência de saída não é duração zero.</p>';self::tabela($r['linhas'],array('titulo'=>'Conteúdo','amostra_saida'=>'Saídas observadas','tempo_visivel_mediana_ms'=>'Tempo visível: mediana','duracao_mediana_ms'=>'Duração: mediana','rolagem_salto_media_pct'=>'Profundidade de saltos (%)','total_cliques_internos'=>'Cliques internos','total_cliques_inertes'=>'Cliques sem ação observada'),$base);echo '</details>';}
        if($area==='sessoes'&&$e['visao']!=='sessao'){echo '<details class="f3-collapsible"><summary>Audiência e duração por sessão</summary>';self::tabela($r['linhas'],array('sessao'=>'Sessão','largura_faixa'=>'Largura da janela','navegador'=>'Navegador','sistema'=>'Sistema','retorno'=>'Novo ou recorrente','aparelho'=>'Aparelho estimado','tempo_visivel_mediana_ms'=>'Tempo visível por página: mediana'),$base);echo '</details>';}
        self::paginar($r,$base);self::csv_form($e);echo '</section>';
        if(in_array($area,array('geral','aquisicao'),true)){echo '<details class="f3-collapsible"><summary>Perfil da audiência por dimensão</summary>';foreach($r['audiencia_por_dimensao']??array() as $dim=>$rows){echo '<h3>'.esc_html(F3Base_Audiencia::rotulos_dimensoes()[$dim]).'</h3>';self::tabela($rows,array('rotulo'=>'Grupo','sessoes'=>'Sessões','visualizacoes'=>'Visualizações','cliques'=>'Cliques de contato','envios'=>'Envios pareados'),$base);}echo '</details><details class="f3-collapsible"><summary>Páginas não encontradas — fora da audiência</summary><p>Estimativa de requisições 404: histórico exato + amostras × 100. Sorteio 1 em 100 antes do acesso à tabela; caminhos raros podem não aparecer. Sem pseudônimos, incluindo robôs. Só respostas executadas pelo WordPress.</p>';self::tabela($r['exclusoes_404']['linhas']??array(),array('caminho'=>'Caminho','historico_exato'=>'Histórico exato','quantidade_amostrada'=>'Amostras 1:100','requisicoes_estimadas'=>'Requisições estimadas','ultimo_observado_em'=>'Último horário amostrado'),$base);echo '</details>';}
        if(isset($r['comparacao'])){echo '<section class="f3-section"><h2>Período anterior</h2><p>'.esc_html($r['comparacao']['de'].' a '.$r['comparacao']['ate']).'</p>';if(!empty($r['comparacao']['ok'])){self::cards($r['comparacao']['totais']??array());}else{echo '<p>'.esc_html($r['comparacao']['motivo']??'Comparação indisponível; não equivale a zero acessos.').'</p><pre>'.esc_html(wp_json_encode($r['comparacao']['diagnostico']??array(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre>';}echo '</section>';}
        echo '<details class="f3-collapsible"><summary>Como funciona, exemplos e cobertura</summary><p>Use sessões e consumo para comparar o conteúdo orgânico. Requisições de robôs são uma unidade diferente e não entram em um percentual de humanos versus IA.</p><ul>';foreach($r['avisos'] as $v){echo '<li>'.esc_html($v).'</li>';}echo '</ul><p>Retenção de eventos individuais: '.(int)$r['cobertura']['retencao_bruta_dias'].' dias. Tempo ativo '.($r['cobertura']['tempo_ativo_habilitado']?'habilitado':'desligado; não é ativado automaticamente nesta atualização').'.</p></details>';
        if($area==='sessoes'){self::anotacoes_form($r['anotacoes']);}echo '<p id="f3m-status" role="status" aria-live="polite"></p></div>';return true;
    }
    public static function analises(string $area): array {
        $editoriais = array('geral'=>array('resumo'=>'Resumo'),'conteudo'=>array('pagina'=>'Páginas','artigo'=>'Artigos','outro'=>'Outros recursos'),'sessoes'=>array('sessoes'=>'Explorar sessões'),'aquisicao'=>array('aquisicao'=>'Canais e entradas','campanhas'=>'Campanhas e anúncios','gsc'=>'Search Console'),'agentes'=>array('resumo'=>'Acessos ao conteúdo','origem_ia'=>'Visitantes de IA','referencias'=>'Referências observadas','horas'=>'Horários','frequencia'=>'Frequência'));
        if ($area === 'sessoes' || $area === 'comportamento') {
            return $editoriais['sessoes'] + F3Base_Medicao_Interface::VISOES['comportamento'];
        }
        return $editoriais[$area] ?? F3Base_Medicao_Interface::VISOES[$area] ?? [];
    }

    public static function abrir(string $area, array $filtros): void {
        echo '<div class="wrap f3-ui f3base-tela f3base-medicao">';
        F3Base_Interface::cabecalho('Fator3 Site Core','Consulte a medição do site, a aquisição e as conversões no período selecionado.');
        self::nav($area, $filtros);
        if (($_GET['salvo'] ?? '') === '1' && in_array($area,['sessoes','agentes'],true)) {
            echo '<div class="f3-result" role="status"><p>Alteração registrada.</p><button type="button" class="button" data-f3-dismiss>Dispensar</button></div>';
        }
    }

    public static function nav(string $area, array $filtros): void {
        $base = array_intersect_key($filtros, array_flip(['de','ate','segmento','automacao']));
        F3Base_Interface::navegacao('medicao', static function () use ($area, $base) {
            F3Base_Interface::navegacao_agrupada('Áreas de medição', [
                'Análises' => ['geral','conteudo','sessoes','aquisicao','conversao'],
                'Fontes e diagnóstico' => ['agentes','ga4','clarity','tecnico'],
            ], self::AREAS, $area === 'comportamento' ? 'sessoes' : $area, static fn($k) => self::url(['area'=>$k],$base), 'f3-subtabs');
        });
    }

    /** Alternador submetido por GET para que cada visão tenha um endereço sem depender de JavaScript. */
    public static function inicio_filtros(string $area, string $visao, array $filtros): void {
        $analises = self::analises($area);
        $area = $area === 'comportamento' ? 'sessoes' : $area;
        echo '<section class="f3-section"><h2>Filtros de medição</h2>';
        if (count($analises) <= 1 || count($analises) > 5) return;
        echo '<form class="f3-switch" aria-label="Análise" method="get" action="'.esc_url(admin_url('admin.php')).'">';
        $consulta = ['page'=>'f3base-medicao','area'=>$area] + array_diff_key($filtros,array_flip(['visao','pagina','limite','cursor','post_id','sessao','caminho']));
        foreach ($consulta as $nome=>$valor) {
            if (is_scalar($valor)) echo '<input type="hidden" name="'.esc_attr($nome).'" value="'.esc_attr((string)$valor).'">';
        }
        foreach ($analises as $id=>$rotulo) {
            echo '<button class="button" type="submit" name="visao" value="'.esc_attr($id).'" aria-pressed="'.($visao === $id ? 'true' : 'false').'">'.esc_html($rotulo).'</button>';
        }
        echo '</form>';
    }

    public static function campo_analise(string $area, string $visao): void {
        $analises = self::analises($area);
        if (count($analises) > 5) self::select('visao','Análise',$analises,$visao);
        else echo '<input type="hidden" name="visao" value="'.esc_attr($visao).'">';
    }

    public static function input(string $nome, string $rotulo, $valor, string $tipo='text', array $atributos=[]): void {
        $id = wp_unique_id('f3-medicao-');
        echo '<div class="f3-field"><label for="'.esc_attr($id).'">'.esc_html($rotulo).'</label><input id="'.esc_attr($id).'" name="'.esc_attr($nome).'" type="'.esc_attr($tipo).'" value="'.esc_attr((string)$valor).'"';
        foreach ($atributos as $k=>$v) {
            if ($v !== false) echo ' '.esc_attr($k).($v === true ? '' : '="'.esc_attr((string)$v).'"');
        }
        echo '></div>';
    }

    public static function select(string $nome, string $rotulo, array $opcoes, $valor): void {
        $id = wp_unique_id('f3-medicao-');
        echo '<div class="f3-field"><label for="'.esc_attr($id).'">'.esc_html($rotulo).'</label><select id="'.esc_attr($id).'" name="'.esc_attr($nome).'">';
        foreach ($opcoes as $k=>$v) echo '<option value="'.esc_attr((string)$k).'" '.selected($valor,(string)$k,false).'>'.esc_html($v).'</option>';
        echo '</select></div>';
    }

    public static function marcar(string $nome, string $rotulo, bool $valor, bool $enviar_desmarcado=false): void {
        $id = wp_unique_id('f3-medicao-');
        if ($enviar_desmarcado) echo '<input type="hidden" name="'.esc_attr($nome).'" value="0">';
        echo '<div class="f3-field"><label class="f3-check" for="'.esc_attr($id).'"><input id="'.esc_attr($id).'" type="checkbox" name="'.esc_attr($nome).'" value="1" '.checked($valor,true,false).'> '.esc_html($rotulo).'</label></div>';
    }
    private static function form(string $area,string $view,array $e,array $base): void {
        if($view==='gsc'){
            global $wpdb;$properties=$wpdb->get_col('SELECT DISTINCT propriedade FROM '.F3Base_Editorial::tabela('gsc_diario').' ORDER BY propriedade LIMIT 100');$current=(string)F3Base_Options::ler('f3base_gsc_property');$properties=array_values(array_unique(array_merge($current?array($current):array(),$properties?:array())));
            echo '<form class="f3-medicao-filtros" method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="aquisicao"><input type="hidden" name="visao" value="gsc"><div class="f3-grid is-wide">';
            foreach (['de'=>'De (dia GSC)','ate'=>'Até (dia GSC)'] as $k=>$label) self::input($k,$label,$e[$k],'date');
            self::select('gsc_propriedade','Propriedade',$properties?array_combine($properties,$properties):array(''=>'Sem propriedade'),$e['gsc_propriedade']??$current);
            self::select('gsc_escopo','Acervo',array('paginas'=>'Páginas por dia','consultas'=>'Consultas por página e dia'),$e['gsc_escopo']??'paginas');
            foreach (['pagina_url'=>'URL completa da página','consulta'=>'Consulta exata'] as $k=>$label) self::input($k,$label,$e[$k]??'');
            self::select('tipo','Conteúdo',[''=>'Todas as URLs','pagina'=>'Páginas','artigo'=>'Artigos'],$e['tipo']??'');
            self::input('post_id','ID do conteúdo',$e['post_id']??'','number',['min'=>0]);
            echo '</div><div class="f3-actions"><button class="button button-primary">Aplicar filtros</button></div></form>';
            return;
        }
        $browser=!($area==='agentes'&&in_array($view,array('resumo','horas','frequencia','referencias'),true));echo '<form class="f3-medicao-filtros" method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="'.esc_attr($area).'"><div class="f3-grid is-wide">';
        self::campo_analise($area, $view);
        foreach (['de'=>'De','ate'=>'Até'] as $k=>$label) self::input($k,$label,$e[$k],'date',['required'=>true]);
        if(!($area==='agentes'&&in_array($view,array('resumo','horas','frequencia','referencias'),true))){self::select('segmento','Tráfego',array('sem_testes'=>'Sem testes marcados','somente_testes'=>'Somente testes','todos'=>'Todos'),$e['segmento']);self::select('automacao','Automação',array('audiencia'=>'Audiência (sem sinais)','todas'=>'Incluir todas','declarada'=>'Somente declarada','provavel'=>'Somente provável'),$e['automacao']);
        if($area==='conteudo'){self::select('recorte','Recorte',array('todos'=>'Todo conteúdo observado','organico'=>'Entradas por busca orgânica','ia'=>'Conteúdos acessados por IA','sem_observacoes'=>'Sem observações no período'),$e['recorte']??'todos');}
        self::select('tipo_atribuicao','Atribuição',array('todas'=>'Todas','observada'=>'Sem vínculo manual','atribuicao_manual'=>'Com vínculo manual'),$e['tipo_atribuicao']??'todas');self::select('canal','Origem',array(''=>'Todas')+F3Base_Audiencia::canais(),$e['canal']??'');}echo '</div><details class="f3-collapsible"><summary>Filtros e opções adicionais</summary><div class="f3-grid is-wide">';
        foreach(($browser?array('caminho'=>'Caminho exato','sessao'=>'ID completo da sessão'):array('caminho'=>'Caminho exato')) as $k=>$label) self::input($k,$label,$e[$k]??'');
        if(isset($e['post_id'])){echo '<input type="hidden" name="post_id" value="'.(int)$e['post_id'].'">';}
        if($area==='agentes'&&$view!=='referencias'&&$view!=='origem_ia'){self::input('assinatura_ua','Assinatura técnica',$base['assinatura_ua']??'');self::marcar('incluir_tecnico','Incluir caminhos técnicos e varreduras',!empty($base['incluir_tecnico']));self::select('grupo','Grupo',array('identificados'=>'Robôs identificados','genericos'=>'Automação genérica','todos'=>'Todos os robôs'),sanitize_key($_GET['grupo']??'identificados'));self::select('agente','Família do robô',array(''=>'Todas','automacao-suspeita'=>'Automação suspeita')+array_combine(array_column(F3Base_Modulo_Acessos_Servidor::robos(),'familia'),array_map(static fn($r)=>F3Base_Agentes::nome($r['familia']),F3Base_Modulo_Acessos_Servidor::robos())),sanitize_key($_GET['agente']??''));self::select('representacao','Representação',array(''=>'Todas','html'=>'HTML','markdown_core'=>'Markdown do plugin','descoberta'=>'Índices de descoberta','nao_resolvida'=>'Não resolvida'),sanitize_key($_GET['representacao']??''));self::select('rede_estado','Origem de rede',array(''=>'Todas','rede_compativel'=>'Faixa oficial compatível','fora_das_faixas'=>'Fora das faixas','sem_fonte_oficial'=>'Sem fonte oficial','fonte_expirada'=>'Lista expirada','ip_nao_confiavel'=>'IP do log não confiável','nao_verificada'=>'Não verificada'),sanitize_key($_GET['rede_estado']??''));self::input('status','Status HTTP',$base['status']??'','number',['min'=>100,'max'=>599]);self::select('metodo','Método',array(''=>'Todos','GET'=>'GET','HEAD'=>'HEAD','POST'=>'POST'),sanitize_text_field($_GET['metodo']??''));}
        if($browser){foreach(F3Base_Audiencia::dimensoes_schema() as $dim=>$spec){if(!isset($spec['enum'])){self::input($dim,F3Base_Audiencia::rotulos_dimensoes()[$dim],$e[$dim]??'','text',['maxlength'=>80]);continue;}$opts=array(''=>'Todos');foreach($spec['enum'] as $v){$opts[$v]=F3Base_Audiencia::rotulo_dimensao($dim,$v);}self::select($dim,F3Base_Audiencia::rotulos_dimensoes()[$dim],$opts,$e[$dim]??'');}self::select('ordenar','Ordenar por',array('visualizacoes'=>'Visualizações','sessoes'=>'Sessões','titulo'=>'Título','inicio'=>'Horário inicial','tempo_ativo_ms'=>'Tempo ativo','requisicoes_ia'=>'Requisições de IA','entradas_organicas'=>'Entradas orgânicas','envios'=>'Envios','cliques'=>'Cliques'),$e['ordenar']??'sessoes');self::select('direcao','Ordem',array('desc'=>'Decrescente','asc'=>'Crescente'),$e['direcao']??'desc');
        self::marcar('comparar','Comparar período anterior',!empty($e['comparar']));
        self::marcar('anotacoes','Aplicar exclusões de períodos anotados',!empty($e['anotacoes']),true);
        }
        echo '</div></details><div class="f3-actions"><button class="button button-primary">Aplicar filtros</button></div></form><div class="f3-actions">';
        foreach(array(7=>'7 dias',30=>'30 dias',90=>'90 dias',395=>'13 meses') as $days=>$label){echo self::link($label,array('de'=>wp_date('Y-m-d',time()-($days-1)*DAY_IN_SECONDS),'ate'=>wp_date('Y-m-d')),$base);}
        echo self::link('Limpar filtros',array('area'=>$area,'visao'=>$view)).' · '.self::link('Configurar coleta',['page'=>'base-site-core-fator3','secao'=>'medicao']);echo '</div><p class="description">Horários no fuso '.esc_html(wp_timezone_string()).' · Atualizado '.esc_html(wp_date('d/m/Y H:i:s')).'</p>';
        $chips=array();foreach(array('post_id','caminho','sessao','canal','origem_ia','largura_faixa','navegador','sistema','retorno','aparelho',...array_keys(F3Base_Perfil_Aparelho::ROTULOS)) as $k){if(!empty($e[$k])){$chips[]='<span class="f3-pill is-info">'.esc_html($k.': '.$e[$k]).'</span>';}}echo '<div class="f3-actions">'.implode(' ',$chips).'</div>';
    }
    private static function status(array $r): void {
        $c=$r['cobertura'];$msgs=$r['saude_coleta']['alertas']??array();if(!empty($c['catalogo']['erro_consolidacao'])){$msgs[]='Consolidação pendente em '.$c['catalogo']['dia_pendente'].': '.$c['catalogo']['erro_consolidacao'].'. Os eventos brutos foram preservados.';}if(!$c['logs_completos']){$msgs[]='Cobertura dos logs incompleta: ausência de requisições de IA não é apresentada como zero.';}if(!$c['coleta_habilitada']){$msgs[]='Coleta de comportamento desligada.';}if(empty($c['catalogo']['catalogo_completo'])){$msgs[]='Catálogo editorial em construção; identidades ainda podem estar indisponíveis.';}if($c['dias_somente_agregados']){$msgs[]='Parte do período tem apenas agregados. Sessões e visitantes distintos estão indisponíveis nesse recorte.';}if($c['historico_sem_regra']){$msgs[]=$c['historico_sem_regra'].' registros históricos sem os novos sinais de qualidade.';}$n=array_sum($r['excluidos']);if($n){$msgs[]=$n.' eventos fora do segmento selecionado (consulte Todos para comparar).';}if($msgs){echo '<section class="f3-section"><h2>Cobertura da medição</h2><p class="f3-callout is-warn" role="status">'.esc_html(implode(' ',$msgs)).'</p></section>';}
    }
    private static function cards(array $t): void {echo '<dl class="f3-stats">';foreach(array('visualizacoes'=>'Visualizações','sessoes'=>'Sessões observadas','visitantes'=>'Visitantes observados','entradas_organicas'=>'Entradas orgânicas','conteudos_ia'=>'Conteúdos acessados por IA') as $k=>$label){echo '<div class="f3-stat"><dt class="f3-stat-label">'.esc_html($label).'</dt><dd class="f3-stat-value">'.esc_html(isset($t[$k])?number_format_i18n($t[$k]):'Indisponível').'</dd></div>';}echo '</dl>';}
    private static function grafico(array $dados,string $title): void {if(!$dados){return;}ksort($dados);$max=max(1,max($dados));echo '<section class="f3-section"><h2>'.esc_html($title).'</h2><div class="f3m-bars" aria-hidden="true">';foreach($dados as $dia=>$v){echo '<span title="'.esc_attr($dia.': '.$v).'" style="--altura:'.max(1,round(100*$v/$max)).'%"></span>';}echo '</div><details class="f3-collapsible"><summary>Ver dados do gráfico (visualizações)</summary>';self::tabela(array_map(static fn($d,$v)=>array('dia'=>$d,'visualizacoes'=>$v),array_keys($dados),array_values($dados)),array('dia'=>'Data','visualizacoes'=>'Visualizações'));echo '</details></section>';}
    private static function tabela(array $rows,array $columns,array $base=array()): void {
        if(!$rows){echo '<p class="f3-empty">Sem observações disponíveis neste recorte. Ausência de dados não significa ausência de acessos.</p>';return;}
        echo '<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Tabela de resultados"><table class="widefat striped"><thead><tr>';foreach($columns as $k=>$label){echo '<th scope="col">'.esc_html($label).'</th>';}echo '</tr></thead><tbody>';
        foreach($rows as $r){echo '<tr'.(!empty($r['destacado'])?' class="f3m-highlight"':'').'>';foreach($columns as $k=>$label){$v=$r[$k]??null;echo is_int($v)||is_float($v)?'<td class="f3-num">':'<td>';
            if($k==='titulo'){echo self::link((string)$v,array('area'=>'conteudo','visao'=>in_array($r['tipo']??'',array('pagina','artigo'),true)?$r['tipo']:'outro','post_id'=>$r['post_id'],'caminho'=>$r['post_id']?false:$r['caminho']),$base).'<small>'.esc_html($r['caminho']).'</small>';}
            elseif($k==='sessao'){echo '<a href="'.esc_url(self::url(array('area'=>'sessoes','visao'=>'sessoes','sessao'=>$v),$base)).'" title="'.esc_attr($v).'">'.esc_html(substr((string)$v,0,10)).'…</a> <button type="button" class="button-link" data-f3m-copy="'.esc_attr($v).'">Copiar</button>';}
            elseif($k==='excluir'){echo !empty($v)?'Sim':'Não';}
            elseif(in_array($k,array('em','inicio','fim','observado_em','primeiro_em','ultimo_em'),true)){if(is_string($v)&&preg_match('/^\d{4}-\d{2}-\d{2}$/D',$v)){echo esc_html(implode('/',array_reverse(explode('-',$v))));echo '</td>';continue;}$stamp=is_numeric($v)?(int)$v:($v?strtotime($v.' UTC'):0);echo $stamp?'<time datetime="'.esc_attr(gmdate('c',$stamp)).'">'.esc_html(wp_date('d/m/Y H:i:s',$stamp)).'</time>':'Indisponível';}
            elseif($k==='hora_utc'){echo $v?esc_html(wp_date('d/m/Y H:i P',strtotime($v.' UTC'))):'Indisponível';}
            elseif(in_array($k,array('tempo_ativo_ms','tempo_visivel_mediana_ms','duracao_mediana_ms','tempo_visivel_medio_ms'),true)){echo esc_html(F3Base_Editorial_Relatorios::duracao($v===null?null:(float)$v));}
            elseif(in_array($k,F3Base_Audiencia::DIMENSOES,true)){echo esc_html(F3Base_Audiencia::rotulo_dimensao($k,(string)$v));}
            elseif($k==='canal'){echo esc_html(F3Base_Audiencia::canais()[$v]??ucfirst((string)$v));}
            else{echo esc_html($v===null?'Indisponível':(is_array($v)?wp_json_encode($v,JSON_UNESCAPED_UNICODE):(is_numeric($v)?number_format_i18n((float)$v,is_float($v)?1:0):(string)$v)));}echo '</td>';}echo '</tr>';}
        echo '</tbody></table></div>';
    }
    private static function paginar(array $r,array $base): void {$page=max(1,(int)($_GET['pagina']??1));echo '<div class="f3-list-tools">';if($page>1){echo self::link('← Anterior',array('pagina'=>$page-1),$base,'button');}echo '<span>Página '.(int)$page.'</span>';if(!empty($r['proxima_pagina'])){echo self::link('Próxima →',array('pagina'=>$r['proxima_pagina']),$base,'button');}echo '</div>';}
    private static function csv_form(array $e,string $type='editorial'): void {echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_editorial_csv"><input type="hidden" name="fonte" value="'.esc_attr($type).'">';wp_nonce_field('f3base-editorial-csv');foreach($e as $k=>$v){if(is_scalar($v)&&$k!=='pagina'){echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr((string)$v).'">';}}echo '<button class="button">Exportar CSV filtrado</button></form>';}
    private static function bots(array $r,array $base): void {
        if(empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']??'Consulta indisponível').'</p>';return;}
        echo '<section class="f3-section"><h2>Conteúdo requisitado por robôs</h2><p>Requisições HTTP; não representam visitantes, citações ou leitura comprovada. MCP, painel, assets e varreduras ficam fora dos totais editoriais.</p>';
        echo '<p>Requisições no recorte: '.esc_html($r['operadores_no_recorte']['requisicoes']??'Indisponível').'. Sem operador identificável: '.esc_html($r['operadores_no_recorte']['sem_operador_identificavel']??'Indisponível').'. Assinaturas de ferramentas não identificam quem as executou.</p>';
        $cols=isset($r['linhas'][0]['hora_utc'])?array('hora_utc'=>'Hora no site','nome_agente'=>'Família','assinatura_ua'=>'Assinatura reduzida','caminho'=>'Conteúdo','representacao'=>'Formato','metodo'=>'Método','status'=>'HTTP','contagem'=>'Requisições'):array('nome_agente'=>'Família','assinatura_ua'=>'Assinatura reduzida','caminho'=>'Conteúdo','representacao'=>'Formato','requisicoes'=>'Requisições','bloqueadas'=>'403 / 429','rede_estado'=>'Rede','ultimo_em'=>'Último acesso');
        if(($r['visao']??'')==='frequencia'){$cols=array('nome_agente'=>'Família','assinatura_ua'=>'Assinatura reduzida','dias_ativos'=>'Dias ativos','primeira_data'=>'Primeira data','ultima_data'=>'Última data','mediana_entre_datas_dias'=>'Mediana entre datas (dias)','intervalo_medio_intradia_segundos'=>'Intervalo médio (s)');}
        self::tabela($r['linhas'],$cols,$base);
        self::paginar($r,$base);self::csv_form(array_replace(array_intersect_key($base,F3Base_Agentes::schema()),array('visao'=>$r['visao'])),'agentes');
        if(!empty($r['alertas'])){echo '<h3>Bloqueios observados</h3>';foreach($r['alertas'] as $a){echo '<p class="f3-callout is-warn">'.esc_html($a).'</p>';}}
        if(!empty($r['hoje_temporario']['linhas'])){echo '<details class="f3-collapsible"><summary>Hoje — fotografia parcial, separada do histórico</summary><p>Atualizado '.esc_html(wp_date('d/m/Y H:i:s',$r['hoje_temporario']['atualizado'])).'. Não somar novamente ao histórico quando o dia fechar. Linhas sem horário individual permanecem sem hora.</p>';self::tabela($r['hoje_temporario']['linhas'],array('agente'=>'Família','caminho'=>'Conteúdo','representacao'=>'Formato','metodo'=>'Método','status'=>'HTTP','contagem'=>'Requisições'));echo '</details>';}
        echo '<details class="f3-collapsible"><summary>Cobertura, origem e limites</summary><p>'.esc_html($r['limites'].' '.$r['testes']).'</p>';self::tabela($r['cobertura'],array('dia'=>'Data','estado'=>'Cobertura','motivo'=>'Explicação'));echo '</details></section>';
    }
    private static function ia_resumo(array $r,array $base): void {
        echo '<section class="f3-section"><h2>Presença em IA</h2><p class="description">Requisições de IA fora do conteúdo: '.(int)($r['ia_fora_conteudo']['descoberta']??0).' a índices de descoberta e '.(int)($r['ia_fora_conteudo']['sem_identidade_editorial']??0).' sem identidade editorial. Consulte IA e robôs para os caminhos.</p>';
        echo '<p>Três medidas independentes, com fontes próprias.</p><dl class="f3-stats">';foreach(array('conteudos_ia'=>'Conteúdos requisitados nos logs','sessoes_ia'=>'Sessões encaminhadas por IA','referencias_ia'=>'Referências conferidas') as $k=>$v){echo '<div class="f3-stat"><dt class="f3-stat-label">'.esc_html($v).'</dt><dd class="f3-stat-value">'.esc_html(isset($r['totais'][$k])?number_format_i18n($r['totais'][$k]):'Indisponível').'</dd></div>';}echo '</dl>'.self::link('Analisar IA e robôs',array('area'=>'agentes','visao'=>'resumo'),$base,'button').'</section>';
        foreach(array('principais_entradas'=>'Páginas de entrada observadas','principais_artigos'=>'Artigos observados') as $k=>$title){echo '<details class="f3-collapsible"><summary>'.esc_html($title).'</summary>';self::tabela($r[$k],array('titulo'=>'Conteúdo','entradas'=>'Entradas cobertas','sessoes'=>'Sessões','visualizacoes'=>'Visualizações'),$base);echo '</details>';}
    }
    private static function detalhe(array $r,array $base): void {
        $p=$r['linhas'][0]??null;if(!$p){return;}echo '<div class="f3-cards"><section class="f3-card"><h2>Alcance e origens</h2><p>'.(int)$p['entradas'].' entradas com início coberto; '.(int)$p['entradas_organicas'].' classificadas como busca orgânica.</p>';
        $orig=array();foreach($p['origens'] as $canal=>$n){$orig[]=array('canal'=>$canal,'visualizacoes'=>$n);}self::tabela($orig,array('canal'=>'Origem da sessão','visualizacoes'=>'Visualizações'));echo '<p>'.self::link('Explorar essas sessões',array('area'=>'sessoes','visao'=>'sessoes'),$base,'button').'</p></section>';
        echo '<section class="f3-card"><h2>Consumo observado</h2><p>Tempo ativo: '.esc_html(F3Base_Editorial_Relatorios::duracao($p['tempo_ativo_ms'])).' · '.(int)$p['amostra_tempo'].' amostras de navegação/dia. Rolagem usa o maior marco por navegação/dia; são '.(int)$p['amostra_rolagem'].' amostras.</p><p>Seções vistas: '.esc_html(implode(', ',$p['secoes_observadas'])?:'Sem nomes de seções disponíveis').'.</p><p>Agregados preservam quantidades; nomes das seções e trajetos dependem do detalhe retido. Nenhum desses sinais comprova leitura.</p></section>';
        echo '<section class="f3-card"><h2>Navegação e cliques de saída</h2>';foreach(array('anteriores'=>'De onde vieram','seguintes'=>'Próxima página ou link externo clicado') as $key=>$title){echo '<h3>'.esc_html($title).'</h3>';$rows=array();foreach($p[$key] as $path=>$n){$rows[]=array('caminho'=>$path,'transicoes'=>$n);}self::tabela($rows,array('caminho'=>'Página','transicoes'=>'Transições vinculadas'));}echo '<p>Abas sem vínculo ficam separadas. A última página observada não prova abandono.</p></section>';
        echo '<section class="f3-card"><h2>Ações pareadas</h2>';self::tabela(array($p),array('cliques'=>'Cliques de contato','form_inicios'=>'Formulários iniciados','form_tentativas'=>'Tentativas','envios'=>'Aceitos'));echo '<p>Somente ações com o mesmo vínculo de sessão, navegação e classe. A associação não comprova causalidade.</p></section></div>';
        echo '<section class="f3-section"><h2>IA neste conteúdo</h2><p>HTML: '.esc_html($p['ia_html']??'Indisponível').' · Markdown do plugin: '.esc_html($p['ia_markdown']??'Indisponível').' · Referências conferidas: '.(int)$p['referencias_ia'].'.</p>';
        $q=array('de'=>$base['de'],'ate'=>$base['ate'],'visao'=>'conteudo');if($p['post_id']){$q['post_id']=(int)$p['post_id'];}else{$q['caminho']=$p['caminho'];}$bots=F3Base_Agentes::consultar($q);self::tabela($bots['linhas']??array(),array('nome_agente'=>'Família','representacao'=>'Formato','metodo'=>'Método','status'=>'HTTP','requisicoes'=>'Requisições','ultimo_em'=>'Último acesso'),$base);echo '<p>'.self::link('Visitas encaminhadas por IA',array('area'=>'agentes','visao'=>'origem_ia','tipo'=>false),$base,'button').' '.self::link('Referências com evidência',array('area'=>'agentes','visao'=>'referencias','tipo'=>false),$base,'button').'</p></section>';
    }
    private static function referencias(array $r,array $base): void {
        echo '<section class="f3-section"><h2>Referências observadas</h2><p>'.esc_html($r['limites']).'</p>';
        self::tabela($r['linhas'],array('provedor'=>'Serviço','observado_em'=>'Observado em','tipo'=>'Tipo','url'=>'Conteúdo','origem'=>'Origem','revisao_estado'=>'Revisão'),$base);
        foreach($r['linhas'] as $line){echo '<p>'.esc_html($line['chave']).' · '.self::link('Editar evidência',array('editar'=>$line['id']),$base).' · '.esc_html($line['evidencia']).'</p>';}
        self::paginar($r,$base);self::csv_form(array_replace(array_intersect_key($base,F3Base_Editorial_Relatorios::schema()),array('visao'=>'referencias')));echo '</section>';
        $edit=null;foreach($r['linhas'] as $line){if((int)($_GET['editar']??0)===(int)$line['id']){$edit=$line;}}
        echo '<details class="f3-collapsible" '.($edit?'open':'').'><summary>'.($edit?'Editar referência':'Registrar referência com evidência').'</summary><p>Informe um link público ou identificador de evidência privada. Não cole conversas privadas. Registrar um teste não o transforma em recomendação espontânea.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_inteligencia_gravar"><input type="hidden" name="operacao" value="referencia">';wp_nonce_field('f3base-inteligencia');
        $rotulos = ['chave'=>'Chave única da observação','provedor'=>'Serviço de IA','observado_em'=>'Data e horário da observação','url'=>'URL do conteúdo no site','topico'=>'Tema ou pergunta (sem dados pessoais)','contexto'=>'Contexto resumido','evidencia'=>'Link ou referência da evidência','evidencia_tipo'=>'Tipo da evidência','origem'=>'Origem da observação','revisao_estado'=>'Estado da revisão','tipo'=>'Tipo da referência'];
        echo '<div class="f3-grid is-wide">';
        foreach (F3Base_Inteligencia::schema_referencia() as $k=>$spec) {
            $valor = $edit[$k] ?? '';
            $nome = 'dados['.$k.']';
            if ($k === 'revisao') {
                if ($edit) echo '<input type="hidden" name="dados[revisao]" value="'.(int)$valor.'">';
            } elseif (isset($spec['enum'])) {
                $opcoes = [];
                foreach ($spec['enum'] as $opcao) $opcoes[$opcao] = str_replace('_',' ',$opcao);
                self::select($nome,$rotulos[$k],$opcoes,$valor);
            } elseif ($k === 'contexto') {
                echo '<div class="f3-field"><label for="f3-ref-contexto">Contexto resumido</label><textarea id="f3-ref-contexto" name="dados[contexto]" maxlength="1000">'.esc_textarea($valor).'</textarea></div>';
            } elseif ($k === 'observado_em') {
                self::input($nome,$rotulos[$k],wp_date('Y-m-d\TH:i',$edit?(int)$valor:time()),'datetime-local',['required'=>true]);
            } else {
                self::input($nome,$rotulos[$k],$valor,'text',['required'=>$k !== 'topico']);
            }
        }
        echo '</div><div class="f3-actions"><button class="button button-primary">Salvar referência</button></div></form>';
        if ($edit) self::exclusao('excluir',$edit,'Excluir referência','A referência será removida da lista de evidências.');
        echo '</details>';
    }

    private static function exclusao(string $operacao, array $item, string $rotulo, string $efeito): void {
        echo '<details class="f3-collapsible f3-danger"><summary>'.esc_html($rotulo).'</summary><p>'.esc_html($efeito).'</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        echo '<input type="hidden" name="action" value="f3base_inteligencia_gravar"><input type="hidden" name="operacao" value="'.esc_attr($operacao).'"><input type="hidden" name="dados[id]" value="'.(int)$item['id'].'"><input type="hidden" name="dados[revisao]" value="'.(int)$item['revisao'].'">';
        wp_nonce_field('f3base-inteligencia');
        $id = wp_unique_id('f3-medicao-excluir-');
        echo '<label class="f3-check" for="'.esc_attr($id).'"><input id="'.esc_attr($id).'" type="checkbox" required name="confirmar_exclusao" value="1"> Confirmar exclusão</label>';
        echo '<div class="f3-actions"><button class="button">'.esc_html($rotulo).'</button></div></form></details>';
    }
    private static function anotacoes_form(array $anotacoes): void {
        $edit=null;echo '<details class="f3-collapsible" '.(isset($_GET['editar_anotacao'])?'open':'').'><summary>Gerenciar períodos de teste conhecidos</summary><p>Marque somente períodos comprovados: cada anotação abrange dias completos no fuso do site, incluindo eventuais visitas reais. A preferência Aplicar exclusões anotadas vem ligada. Dados brutos e contatos são preservados.</p>';
        self::tabela($anotacoes,array('chave'=>'Chave','inicio'=>'De','fim'=>'Até','motivo'=>'Motivo','excluir'=>'Excluir dos relatórios','revisao'=>'Revisão'));
        foreach($anotacoes as $a){if((int)($_GET['editar_anotacao']??0)===(int)$a['id']){$edit=$a;}echo '<p>'.esc_html($a['chave']).' · '.self::link('Editar',array('area'=>'sessoes','editar_anotacao'=>$a['id'],'de'=>$_GET['de']??$a['inicio'],'ate'=>$_GET['ate']??$a['fim'])).'</p>';}
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_inteligencia_gravar"><input type="hidden" name="operacao" value="anotacao">';wp_nonce_field('f3base-inteligencia');
        echo '<div class="f3-grid is-wide">';
        foreach (['chave'=>'Chave única','de'=>'Primeiro dia','ate'=>'Último dia','motivo'=>'Motivo'] as $k=>$label) {
            $key = ['de'=>'inicio','ate'=>'fim'][$k] ?? $k;
            self::input('dados['.$k.']',$label,$edit[$key]??'',in_array($k,['de','ate'],true)?'date':'text',['required'=>true,'readonly'=>$edit && $k==='chave']);
        }
        if ($edit) echo '<input type="hidden" name="dados[revisao]" value="'.(int)$edit['revisao'].'">';
        self::marcar('dados[excluir]','Excluir este período dos relatórios',!empty($edit['excluir']));
        echo '</div><div class="f3-actions"><button class="button button-primary">Salvar anotação</button></div></form>';
        if ($edit) self::exclusao('anotacao_excluir',$edit,'Excluir anotação','O período volta a participar dos relatórios, salvo outra exclusão sobreposta. A auditoria permanece disponível.');
        echo '</details>';
    }
    public static function csv(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-editorial-csv');$bot=($_POST['fonte']??'')==='agentes';$e=self::filtros($_POST);if($bot){$e=array();foreach(F3Base_Agentes::schema() as $k=>$s){if(isset($_POST[$k])&&$_POST[$k]!==''){$e[$k]=$s['type']==='integer'?(int)$_POST[$k]:($s['type']==='boolean'?in_array($_POST[$k],array('1','true'),true):sanitize_text_field(wp_unslash($_POST[$k])));}}}
        $e['pagina']=1;if(!$bot){$e['limite']=200;$e['comparar']=false;}$rows=array();global $wpdb;if(false===$wpdb->query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')||false===$wpdb->query('START TRANSACTION WITH CONSISTENT SNAPSHOT')){wp_die('Não foi possível iniciar uma fotografia consistente para a exportação.',503);}$until=microtime(true)+20;do{$r=$bot?F3Base_Agentes::consultar($e):F3Base_Editorial_Relatorios::consultar($e);if(empty($r['ok'])||count($rows)>20000||microtime(true)>$until){$wpdb->query('ROLLBACK');wp_die('Reduza o período ou corrija os filtros para exportar o conjunto completo.',400);}$batch=$r['linhas'];if(isset($r['paginas'])){foreach($r['paginas'] as $p){$batch[]=array('escopo'=>'pagina')+$p;}}$rows=array_merge($rows,$batch);$e['pagina']=$r['proxima_pagina']??null;}while($e['pagina']);if(count($rows)>20000){$wpdb->query('ROLLBACK');wp_die('A exportação excede 20 mil linhas; reduza o período.',400);}if(false===$wpdb->query('COMMIT')){wp_die('A fotografia da exportação não pôde ser concluída.',503);}
        foreach($rows as &$row){foreach(array('em','inicio','ultimo','observado_em','primeiro_em','ultimo_em','hora_utc') as $k){if(empty($row[$k])){continue;}$stamp=is_numeric($row[$k])?(int)$row[$k]:strtotime($row[$k].' UTC');if($stamp){$row[$k.'_utc']=gmdate('c',$stamp);$row[$k.'_local']=wp_date('d/m/Y H:i:s P',$stamp);}}$row['fuso']=wp_timezone_string();}unset($row);
        nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="f3base-medicao-1.19.csv"');$f=fopen('php://output','w');fwrite($f,"\xEF\xBB\xBF");fputcsv($f,array('Regra',F3Base_Audiencia::REGRA,'Extraído UTC',gmdate('c'),'Fuso',wp_timezone_string()));foreach($e as $k=>$v){fputcsv($f,array($k,F3Base_Acessos_Relatorio::celula_csv((string)$v)));}if($rows){$keys=array_values(array_unique(array_merge(...array_map('array_keys',$rows))));fputcsv($f,$keys);foreach($rows as $row){fputcsv($f,array_map(static fn($k)=>F3Base_Acessos_Relatorio::celula_csv(!isset($row[$k])?'Indisponível':(is_array($row[$k])?wp_json_encode($row[$k],JSON_UNESCAPED_UNICODE):(string)$row[$k])),$keys));}}fclose($f);exit;
    }
}
