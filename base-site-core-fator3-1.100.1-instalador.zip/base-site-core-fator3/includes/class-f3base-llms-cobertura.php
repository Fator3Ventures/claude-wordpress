<?php
/** Bounded, resumable generations. A published generation survives ordinary cache invalidation. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Llms_Cobertura {
    const EVENTO='f3base_llms_converter_lote';
    const ESTADO='f3base_llms_geracoes';
    const PUBLICADA='f3base_llms_geracao_publicada';
    private static bool $executando=false;
    private static bool $salvamento=false;
    public static function iniciar(): void {
        add_action(self::EVENTO,F3Base_Operacao::callback(self::EVENTO,static fn()=>self::executar(5)));
        F3Base_Llms_Mapa::iniciar();
    }
    private static function identidade(array $i): string { return hash('sha256',wp_json_encode(array($i['id']??0,$i['url']??''))); }
    private static function assinatura(): string {
        return hash('sha256',F3Base_Modulo_Cache_Publico::geracao().F3Base_Options::revisao('f3base_llms').F3BASE_PLUGIN_VERSAO);
    }
    private static function id_geracao(array $itens, array $config, string $assinatura): string {
        return hash('sha256', wp_json_encode([$itens, $config, $assinatura, F3BASE_PLUGIN_VERSAO]));
    }
    public static function chave(array $i): string {
        return 'f3base_llms_item_'.hash('sha256',wp_json_encode(array(F3Base_Modulo_Cache_Publico::geracao(),F3BASE_PLUGIN_VERSAO,$i['id']??0,$i['url']??'',$i['conteudo']??'',F3Base_Options::ler('f3base_llms')['blocos_interface']??array())));
    }
    private static function elegivel(array $i): bool {
        $id=(int)($i['id']??0);if(!$id){return true;}$p=get_post($id);
        return $p&&is_post_publicly_viewable($p)&&!$p->post_password&&!F3Base_Modulo_Noindex_Honrado::post_e_noindex($id);
    }
    /** Read only: current public eligibility prevails over the snapshot. */
    public static function publicados(array $atuais): array {
        $c=F3Base_Options::ler('f3base_llms');if(empty($c['markdown'])&&empty($c['full'])){return $atuais;}
        $g=(array)get_option(self::PUBLICADA,array());if(empty($g['itens'])){return array();}
        $permitidos=array();foreach($atuais as $i){if(self::elegivel($i)){$permitidos[self::identidade($i)]=true;}}
        return array_values(array_filter($g['itens'],static fn($i)=>isset($permitidos[self::identidade($i)])&&self::elegivel($i)));
    }
    public static function item(array $i,bool $converter=false): array {
        if(!self::elegivel($i)){return array('completo'=>false,'erros'=>array('conteudo_nao_publico'),'texto'=>'');}
        if(!$converter){
            if(isset($i['_f3base_representacao'])){return $i['_f3base_representacao'];}
            $g=(array)get_option(self::PUBLICADA,array());$ident=self::identidade($i);
            foreach($g['itens']??array() as $antigo){if(self::identidade($antigo)===$ident){return $antigo['_f3base_representacao'];}}
            return array('completo'=>false,'pendente'=>true,'erros'=>array(),'texto'=>'');
        }
        $key=self::chave($i);$r=get_transient($key);if(is_array($r)){return $r;}
        $r=F3Base_Llms_Conversor::converter((string)($i['conteudo']??''),(string)($i['url']??''),3,(int)($i['id']??0));
        $r['revisao']=hash('sha256',$key);$r['em']=time();set_transient($key,$r,DAY_IN_SECONDS);return $r;
    }
    public static function disponiveis(array $itens): array {return array_values(array_filter($itens,static fn($i)=>!empty(self::item($i)['completo'])));}
    public static function resumo(array $itens): array {
        $lista=array();$ok=0;foreach($itens as $i){$r=self::item($i);$ok+=!empty($r['completo'])?1:0;$lista[]=array('id'=>$i['id']??0,'url'=>$i['url']??'','estado'=>!empty($r['completo'])?'disponivel':(!empty($r['pendente'])?'pendente':'incompleta'),'avisos'=>$r['avisos']??array(),'erros'=>$r['erros']??array(),'revisao'=>$r['revisao']??null);}
        $g=(array)get_option(self::PUBLICADA,array());$e=(array)get_option(self::ESTADO,array());
        return array('total'=>count($itens),'disponiveis'=>$ok,'parcial'=>$ok<count($itens),'itens'=>$lista,'geracao_publicada'=>$g['id']??null,'publicada_em'=>$g['em']??null,'idade_segundos'=>isset($g['em'])?max(0,time()-$g['em']):null,'preparo'=>array('id'=>$e['id']??null,'cursor'=>$e['cursor']??0,'total'=>$e['total']??0,'ultimo_avanco'=>$e['avanco']??null,'erro'=>$e['erro']??'','proxima_tentativa'=>wp_next_scheduled(self::EVENTO)?:null,'tentativas'=>$e['tentativas']??0,'falhas'=>$e['falhas']??array(),'itens'=>array_map(static fn($i)=>array('id'=>$i['id']??0,'url'=>$i['url']??'','erros'=>$i['_f3base_representacao']['erros']??array()),$e['itens']??array())));
    }
    private static function agendar_em(int $quando): void {if(!wp_next_scheduled(self::EVENTO)){wp_schedule_single_event($quando,self::EVENTO);}}
    public static function agendar(): void {
        $s=(array)get_option('f3base_llms_assinatura',array());
        if(time()<(int)($s['proxima_verificacao']??0)){return;}
        if(!wp_doing_cron()&&!(defined('WP_CLI')&&WP_CLI)&&F3Base_Zelador::cli_recente()){return;}
        $c=F3Base_Options::ler('f3base_llms');if(empty($c['ligado'])||!F3Base_Llms::site_publico()){return;}
        $assinatura=self::assinatura();
        if(($s['assinatura_publicada']??'')!==$assinatura||!empty($s['pendente'])){self::agendar_em(time()+1);}
        $s['proxima_verificacao']=time()+3600;update_option('f3base_llms_assinatura',$s,true);
    }
    private static function publicacao(array &$e,array $pub,string $assinatura): void {
        $failed=!empty($pub['estado']['pendente']);$e['erro']=$pub['estado']['erro']??'';$e['tentativas']=$failed?((int)($e['tentativas']??0)+1):0;$e['pendente']=$failed&&$e['tentativas']<5;$e['bloqueada_assinatura']=$failed&&!$e['pendente']?$assinatura:'';
        F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$e);wp_clear_scheduled_hook(self::EVENTO);
        if($e['pendente']){self::agendar_em(time()+min(3600,30*(2**$e['tentativas'])));}elseif($failed){wp_clear_scheduled_hook(F3Base_Llms_Arquivo::EVENTO);}
    }
    public static function lote(int $offset=0): void {self::executar(5);}
    public static function executar(int $orcamento=5,bool $forcar=false): array {
        if(self::$executando){return array('ok'=>false,'codigo'=>'geracao_reservada');}
        $c=F3Base_Options::ler('f3base_llms');if(empty($c['ligado'])||!F3Base_Llms::site_publico()){return array('ok'=>true,'codigo'=>'recurso_desligado','restantes'=>0);}
        $l=@fopen(get_temp_dir().'f3base-llms-geracao-'.hash('sha256',ABSPATH).'.lock','c');if(!$l||!flock($l,LOCK_EX|LOCK_NB)){if($l){fclose($l);}return array('ok'=>false,'codigo'=>'geracao_reservada');}
        $lease=wp_generate_uuid4();$reserva=F3Base_Options::atualizar_estado('f3base_llms_trava',static fn($v)=>($v['ate']??0)>time()?null:array('id'=>$lease,'ate'=>time()+60));if(empty($reserva['persisted'])){flock($l,LOCK_UN);fclose($l);return array('ok'=>false,'codigo'=>'geracao_reservada');}
        self::$executando=true;$inicio=microtime(true);$fim=$inicio+max(1,min(10,$orcamento));
        try{
            $itens=F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache($c);$assinatura=self::assinatura();
            $id=self::id_geracao($itens, $c, $assinatura);
            $atual=(array)get_option(self::PUBLICADA,array());$e=(array)get_option(self::ESTADO,array());if(!$forcar&&($e['bloqueada_assinatura']??'')===$assinatura){return array('ok'=>false,'codigo'=>'geracao_aguarda_reprocessamento','restantes'=>0,'parcial'=>true,'erro'=>$e['erro']??'');}
            if(!$forcar&&($atual['id']??'')===$id){
                $atual['assinatura']=$assinatura;F3Base_Options::atualizar_estado(self::PUBLICADA,static fn()=>$atual);
                $pub=F3Base_Llms_Arquivo::gerar();$e['id']=$id;$e['cursor']=count($itens);$e['total']=count($itens);$e['avanco']=time();$e['falhas']=array();foreach($atual['itens']??array() as $i){if(empty($i['_f3base_representacao']['completo'])){$e['falhas'][]=array('id'=>$i['id']??0,'url'=>$i['url']??'','erros'=>$i['_f3base_representacao']['erros']??array());}}
                self::publicacao($e,$pub,$assinatura);F3Base_Llms_Mapa::publicar($atual,!empty($e['pendente']));return array('ok'=>empty($pub['estado']['pendente']),'codigo'=>!empty($pub['estado']['pendente'])?'indice_pendente':'geracao_atual','restantes'=>0,'parcial'=>!empty($pub['estado']['pendente'])||!empty($e['falhas']),'geracao'=>$id);

            }
            $e=(array)get_option(self::ESTADO,array());
            $em_preparo = ($e['id'] ?? '') === $id && !empty($e['pendente'])
                && ($e['cursor'] ?? 0) < count($itens) && empty($e['erro']);
            $reiniciar = $forcar && !$em_preparo;
            if($reiniciar){foreach($itens as $i){delete_transient(self::chave($i));}}
            if($reiniciar||($e['id']??'')!==$id){$e=array('id'=>$id,'cursor'=>0,'total'=>count($itens),'itens'=>array(),'bytes'=>0,'pendente'=>true,'inicio'=>time());}
            while($e['cursor']<count($itens)&&microtime(true)<$fim){
                $i=$itens[$e['cursor']];$r=self::item($i,true);$e['bytes']+=strlen($r['texto']??'');
                if($e['bytes']>F3Base_Llms_Conversor::MAX_BYTES){$e['bytes']-=strlen($r['texto']??'');$r['texto']='';$r['completo']=false;$r['erros'][]='volume_geracao_excedido';}
                $i['_f3base_representacao']=$r;$i['conteudo']=!empty($r['texto'])?'[representacao_publicada]':'';$e['itens'][]=$i;++$e['cursor'];$e['avanco']=time();
                if(!F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$e)['persisted']){throw new RuntimeException('progresso_nao_persistido');}
            }
            $restantes=count($itens)-$e['cursor'];
            if(!$restantes){
                if(self::id_geracao(F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache($c), $c, self::assinatura())!==$id||F3Base_Options::ler('f3base_llms')!==$c){throw new RuntimeException('contexto_alterado');}
                // Cada item foi processado. Falhas isoladas ficam no índice como HTML;
                // somente representações completas entram nas rotas Markdown/full.
                $e['falhas']=array();foreach($e['itens'] as $i){if(empty($i['_f3base_representacao']['completo'])){$e['falhas'][]=array('id'=>$i['id']??0,'url'=>$i['url']??'','erros'=>$i['_f3base_representacao']['erros']??array());}}
                $g=array('id'=>$id,'assinatura'=>$assinatura,'em'=>time(),'itens'=>$e['itens']);
                if(!F3Base_Options::atualizar_estado(self::PUBLICADA,static fn()=>$g)['persisted']){throw new RuntimeException('promocao_nao_persistida');}
                // Representations are available before the physical index switches to their generation.
                $pub=F3Base_Llms_Arquivo::gerar();$e['itens']=array();self::publicacao($e,$pub,$assinatura);F3Base_Llms_Mapa::publicar($g,!empty($e['pendente']));
                return array('ok'=>empty($pub['estado']['pendente']),'codigo'=>!empty($pub['estado']['pendente'])?'indice_pendente':'geracao_publicada','geracao'=>$id,'restantes'=>0,'parcial'=>$e['pendente']||!empty($e['falhas']),'duracao_ms'=>round((microtime(true)-$inicio)*1000),'cobertura'=>self::resumo($g['itens']));
            }
            self::agendar_em(time()+5);return array('ok'=>true,'codigo'=>'preparacao_parcial','geracao'=>$id,'parcial'=>true,'restantes'=>$restantes,'cursor'=>$e['cursor'],'duracao_ms'=>round((microtime(true)-$inicio)*1000));
        }catch(Throwable $erro){
            $codigo=in_array($erro->getMessage(),array('volume_geracao_excedido','progresso_nao_persistido','contexto_alterado','promocao_nao_persistida'),true)?$erro->getMessage():'geracao_falhou';
            $tentativas=(int)($e['tentativas']??0)+1;$retentar=$tentativas<5;
            F3Base_Options::atualizar_estado(self::ESTADO,static function($v)use($codigo,$tentativas,$retentar,$assinatura){$v['erro']=$codigo;$v['tentativas']=$tentativas;$v['pendente']=$retentar;$v['bloqueada_assinatura']=$retentar?'':$assinatura;return $v;});
            wp_clear_scheduled_hook(self::EVENTO);if($retentar){self::agendar_em(time()+min(3600,30*(2**$tentativas)));}
            return array('ok'=>false,'codigo'=>$codigo,'parcial'=>true,'retentativa_agendada'=>$retentar);
        }
        finally{F3Base_Options::atualizar_estado('f3base_llms_trava',static fn($v)=>($v['id']??'')===$lease?array():null);self::$executando=false;flock($l,LOCK_UN);fclose($l);}
    }
}
