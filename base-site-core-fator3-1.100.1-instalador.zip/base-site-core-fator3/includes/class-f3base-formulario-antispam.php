<?php
/** Sinais de captura; conteúdo de iscas cifrado e restrito ao WordPress. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Formulario_Antispam {
    const ISCAS=array('website','ctodesenvolvimentofator3','segmento_atuacao','comentario');
    /** Four independent honeypots; cached pages with three fields remain valid. */
    const OPTION='f3base_formularios_sinais';
    const SINAIS_EMAIL = ['email_aceito','email_suspeito','email_descartado','remetente_ausente','mime_invalido','acima_limite','cabecalho_excedido','destinatario_outro_site','remetente_invalido','remetente_do_grupo','resposta_automatica','mensagem_em_massa','retorno_entrega','relatorio_dmarc','dmarc_fail_reject','dmarc_fail_quarantine','fora_homologacao','autenticacao_dns_pendente','autenticacao_nao_confirmada','reply_to_divergente','links_excessivos','termo_suspeito'];
    public static function sinais_email(array $row, array $msg): array {
        $signals = array_merge(['email_'.$row['classe'], $msg['descarte_original'] ?? '', !empty($msg['remetente_ausente']) ? 'remetente_ausente' : ''], explode(',', $msg['motivo'] ?? ''));
        return array_values(array_unique(array_intersect($signals, self::SINAIS_EMAIL)));
    }
    public static function padroes(): array {
        $active=array('isca_comentario','isca_ctodesenvolvimentofator3','isca_segmento_atuacao','token_assinatura_invalida_ou_ausente','sem_pagina_origem','cota_excedida');$out=array();
        foreach(array_merge(array_map(static fn($n)=>'isca_'.$n,self::ISCAS),array('tempo_curto','token_vencido','token_revisao_anterior','token_assinatura_invalida_ou_ausente','sem_pagina_origem','cota_excedida')) as $signal){$on=in_array($signal,$active,true);$out[$signal]=array('suspeito'=>$on,'aviso'=>$on,'spam'=>false);}
        foreach (self::SINAIS_EMAIL as $signal) {
            $out[$signal]=['suspeito'=>!in_array($signal,['email_aceito','email_descartado'],true),'aviso'=>false,'spam'=>false];
        }
        return $out;
    }
    public static function catalogo(array $c): array {
        $row=array('type'=>'object','additionalProperties'=>false,'required'=>array('suspeito','aviso'),'properties'=>array('suspeito'=>array('type'=>'boolean'),'aviso'=>array('type'=>'boolean'),'spam'=>array('type'=>'boolean','default'=>false)));
        $schema=array('type'=>'object','maxProperties'=>100,'properties'=>array_fill_keys(array_keys(self::padroes()),$row),'additionalProperties'=>$row);
        $c[self::OPTION]=array('rotulo'=>'Sinais de suspeita e avisos de formulários e e-mail','descricao'=>'Uma regra por sinal. Qualquer sinal com suspeito ligado classifica o contato. Um sinal com Marcar spam ligado prevalece sobre todos os avisos e mantém o contato fora da revisão e das entregas. Entre os sinais que marcaram a suspeita, basta um com aviso ligado para avisar. Contato sem nome ou canal válido permanece sem aviso. Sem aviso também não há e-mail de contingência.','operavel'=>true,'secao'=>'conexoes','campo'=>'grupo','autoload'=>false,'padrao'=>self::padroes(),'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>static fn($v,$d)=>array_map(static fn($row)=>array_replace(array('suspeito'=>false,'aviso'=>false,'spam'=>false),$row),is_array($v)?array_replace($d,$v):$d),'recusa'=>static function($v)use($schema){$r=rest_validate_value_from_schema($v,$schema);if(is_wp_error($r)){return $r->get_error_message();}foreach(array_keys($v) as $name){if(!preg_match('/^[a-z0-9_]{1,80}$/D',$name)){return 'Nome de sinal inválido.';}}return '';});return $c;
    }
    public static function avaliar(array $signals): array {
        $rules=F3Base_Options::ler(self::OPTION);$suspect=array();$notice=array();$spam=array();
        foreach(array_unique($signals) as $signal){$rule=$rules[$signal]??array();if(!empty($rule['spam'])){$spam[]=$signal;}if(!empty($rule['suspeito'])||!empty($rule['spam'])){$suspect[]=$signal;if(!empty($rule['aviso'])){$notice[]=$signal;}}}
        return array('suspeito'=>(bool)$suspect,'aviso'=>!$spam&&(bool)$notice,'spam'=>(bool)$spam,'sinais_spam'=>$spam,'sinais_suspeitos'=>$suspect,'sinais_aviso'=>$notice,'aviso_suprimido'=>(bool)$spam||($suspect&&!$notice),'revisao'=>F3Base_Options::revisao(self::OPTION));
    }
    public static function resumo(): array {
        global $wpdb;$counts=array();$spam=array();foreach(array(7,30) as $days){$counts[$days.'_dias']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE captura='suspeito' AND atendimento<>'spam' AND classe_trafego<>'teste' AND lixeira=0 AND eliminacao_pendente=0 AND criado_em>=%s AND JSON_UNQUOTE(JSON_EXTRACT(dados,'$.sinais_politica.aviso_suprimido'))='true'",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',time()-$days*DAY_IN_SECONDS)));$spam[$days.'_dias']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE atendimento='spam' AND classe_trafego<>'teste' AND lixeira=0 AND eliminacao_pendente=0 AND criado_em>=%s AND JSON_UNQUOTE(JSON_EXTRACT(dados,'$.sinais_politica.spam'))='true'",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',time()-$days*DAY_IN_SECONDS)));}
        return array('option'=>self::OPTION,'regras'=>F3Base_Options::ler(self::OPTION),'linhas'=>array_map(static fn($s,$r)=>array('sinal'=>$s)+$r,array_keys(F3Base_Options::ler(self::OPTION)),array_values(F3Base_Options::ler(self::OPTION))),'revisao'=>F3Base_Options::revisao(self::OPTION),'suspeitos_sem_aviso'=>$counts,'spam_por_sinal'=>$spam,'escopo'=>'Registros ainda retidos, excluindo homologação; a decisão registrada na captura não muda retroativamente.');
    }
    public static function iniciar(): void {add_action('admin_post_f3base_sinais_salvar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-sinais');$values=array();$current=F3Base_Options::ler(self::OPTION);foreach(array_keys($current) as $name){$values[$name]=array('suspeito'=>isset($_POST['sinais'][$name]['suspeito']),'aviso'=>isset($_POST['sinais'][$name]['aviso']),'spam'=>isset($_POST['sinais'][$name]['spam']));}$r=F3Base_Options::pelo_canal('admin',static fn()=>F3Base_Options::gravar(self::OPTION,$values,F3Base_Options::ORIGEM_MANUAL,sanitize_text_field($_POST['revisao']??'')));set_transient('f3base_integracao_resultado_'.get_current_user_id(),$r,300);wp_safe_redirect(F3Base_Configuracoes_Hub::url('conexoes','avisos'));exit;});}
    public static function tela(): void {
        if(!current_user_can('manage_options')){return;}$cfg=F3Base_Options::ler(self::OPTION);echo '<h3>Sinais de suspeita e avisos de formulários e e-mail</h3><p>Marcar suspeita conserva o contato no WordPress e exige aprovação para enviá-lo ao Pipedrive. Um sinal com Marcar spam ligado prevalece sobre todos os avisos e mantém o contato fora da revisão e das entregas. Entre os sinais que marcaram a suspeita, um com aviso ligado basta para avisar. Sem aviso também não sai e-mail de contingência. A regra exige nome e e-mail ou telefone válido.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_sinais_salvar"><input type="hidden" name="revisao" value="'.esc_attr(F3Base_Options::revisao(self::OPTION)).'">';wp_nonce_field('f3base-sinais');echo '<div class="f3-table-scroll" role="region" tabindex="0" aria-label="Regras de suspeita e avisos"><table class="widefat striped"><thead><tr><th>Sinal</th><th>Marcar suspeito</th><th>Permitir aviso</th><th>Marcar spam</th></tr></thead><tbody>';
        foreach($cfg as $name=>$rule){echo '<tr><th scope="row">'.esc_html(F3Base_Config_UI::rotulo($name)).'<br><code>'.esc_html($name).'</code></th>';foreach(array('suspeito','aviso','spam') as $key){echo '<td><input type="checkbox" aria-label="'.esc_attr($name.' '.$key).'" name="sinais['.esc_attr($name).']['.$key.']" value="1" '.checked(!empty($rule[$key]),true,false).'></td>';}echo '</tr>';}echo '</tbody></table></div>';submit_button('Salvar regras de suspeita e aviso');echo '</form>';
    }
    public static function html(): string {return F3Base_Formularios::iscas_html();}
    public static function iscas(array $e,array $campos,int $etapa=1): array {
        $meta=array();$values=array();foreach(self::ISCAS as $name){$v=$e[$name]??'';if(!is_string($v)){return array('ok'=>false,'codigo'=>'isca_invalida');}if(strlen($v)>20000){return array('ok'=>false,'codigo'=>'isca_excedida');}$v=wp_check_invalid_utf8($v);if(trim($v)===''){continue;}
            $same=array();foreach($campos as $field=>$value){if(is_scalar($value)&&trim((string)$value)!==''&&trim((string)$value)===trim($v)){$same[]=$field;}}
            $types=array();if(filter_var(trim($v),FILTER_VALIDATE_URL)){$types[]='url';}if($same){$types[]='igual_a_outro_campo';}if(!$types){$types[]='texto_livre';}
            $meta[$name]=array('tipos'=>$types,'campos_iguais'=>$same,'bytes'=>strlen($v),'etapa'=>$etapa);$values[$name]=$v;
        }
        $capture=!empty(F3Base_Options::ler(F3Base_Formulario_Tentativas::OPTION)['capturar_valores']);
        return array('ok'=>true,'suspeito'=>self::avaliar(array_map(static fn($n)=>'isca_'.$n,array_keys($meta)))['suspeito'],'iscas'=>array('em'=>time(),'etapa'=>$etapa,'campos'=>$meta,'valores'=>$capture&&$values?F3Base_Contato_Comunicacao::cifrar($values):null,'captura_valores'=>$capture));
    }
    public static function aviso_barrado(array $lead): bool {return ($lead['atendimento']??'')==='spam'||($lead['captura']??'')==='suspeito'&&!empty($lead['dados']['sinais_politica']['aviso_suprimido']);}
    public static function contato_valido(array $d): bool {return trim((string)($d['nome']??''))!==''&&(is_email($d['email']??'')||F3Base_Pipedrive_Api::telefone((string)($d['telefone']??''))!=='');}
    public static function privado(array $lead): array {
        if(!current_user_can('f3base_ler_leads')){return array();}$out=array();
        foreach($lead['dados']['iscas_privadas']??array() as $row){if((int)($row['em']??0)<F3Base_Retencao_Prazos::corte(F3Base_Formulario_Tentativas::OPTION)){continue;}$values=F3Base_Contato_Comunicacao::abrir((string)($row['valores']??''))??array();unset($row['valores']);foreach($row['campos'] as $name=>&$field){if(array_key_exists($name,$values)){$field['valor']=$values[$name];}}unset($field);$out[]=$row;}return $out;
    }
    public static function projetar(array $lead): array {$lead['iscas']=self::privado($lead);unset($lead['dados']['iscas_privadas']);return $lead;}
    public static function limpar(): void {
        global $wpdb;$cut=F3Base_Retencao_Prazos::corte(F3Base_Formulario_Tentativas::OPTION);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT record_id,dados FROM %i WHERE JSON_CONTAINS_PATH(dados,'one','$.iscas_privadas') AND CAST(JSON_UNQUOTE(JSON_EXTRACT(dados,'$.iscas_privadas[0].em')) AS UNSIGNED)<%d LIMIT 100",F3Base_Leads_Repositorio::tabela(),$cut),ARRAY_A);
        foreach($rows??array() as $r){$d=F3Base_Json_Campo::ler($r['dados'], 'dados');$d['iscas_privadas']=array_values(array_filter($d['iscas_privadas']??array(),static fn($x)=>(int)($x['em']??0)>=$cut));if(!$d['iscas_privadas']){unset($d['iscas_privadas']);}$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d)),array('record_id'=>$r['record_id'],'dados'=>$r['dados']));}
    }
}
