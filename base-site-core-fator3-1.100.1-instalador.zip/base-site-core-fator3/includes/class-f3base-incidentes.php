<?php
/** Contrato local incidentes/1. As observações são do produtor e a entrega é do Core. */
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3Base_Incidentes {
    private const PREFIXO = 'f3base_incidente_v1_';
    public const ROTAS = [
        'meta'=>'tools.php?page=wp-mcp-meta-fator3',
        'linkedin'=>'tools.php?page=wp-mcp-linkedin-fator3',
        'google'=>'tools.php?page=wp-mcp-google-fator3',
        'pipedrive'=>'tools.php?page=wp-mcp-pipedrive-fator3',
        'canal'=>'tools.php?page=wp-mcp-fator3',
        'core'=>'admin.php?page=base-site-core-fator3',
    ];
    public const CODIGOS = [
        'estrutura_ausente','captacao_meta_indisponivel','agenda_parada','autorizacao_recusada','credencial_invalida','credencial_recusada','concessao_revogada','site_fora_do_ar','token_vencendo',
        'refresh_vencendo','prova_vencendo','renovacao_falhou','graph_vencendo',
        'canal_indisponivel','integracao_indisponivel','cron_sem_passagem','could_not_set','destino_tecnico_ausente',
    ];

    public static function iniciar(): void {
        add_filter('f3base_incidente_publicar_v1', static fn($anterior,$e)=>self::publicar($e), 10, 2);
        add_filter('f3base_incidente_acesso_encerrar_v1', static fn($anterior,$e)=>self::encerrar_acesso($e), 10, 2);
        add_action('wp_abilities_api_init', [self::class,'registrar'], 80);
        add_action('admin_init', static function() {
            if (current_user_can('manage_options')) {self::observar();}
        });
        add_action('admin_notices', static function() {
            if (current_user_can('manage_options') && F3Base_Alertas_Operacionais::destinatario()==='') {
                printf('<div class="notice notice-warning"><p>Os avisos técnicos aguardam um endereço de e-mail. <a href="%s">Configurar destino técnico</a>.</p></div>',
                    esc_url(F3Base_Configuracoes_Hub::url('conexoes','f3base_avisos_tecnicos')));
            }
        });
        add_filter('pre_wp_mail',[F3Base_Incidentes_Provedores::class,'email_legado'],5,2);
        add_filter('pre_http_request',[F3Base_Incidentes_Provedores::class,'webhook_legado'],5,3);
    }

    public static function registrar(): void {
        F3Base_Servicos::ability('incidentes-tecnicos-ler','Incidentes técnicos e confirmação do transporte',
            [self::class,'listar'], ['apos'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$']]);
        F3Base_Servicos::ability('incidente-entrega-reconciliar','Registrar o resultado de uma entrega incerta após conferir o transporte',
            [self::class,'reconciliar'], [
                'id'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$'],
                'reserva'=>['type'=>'string','format'=>'uuid'],
                'resultado'=>['type'=>'string','enum'=>['aceito','nao_enviado']],
            ], ['id','reserva','resultado'], false);
    }

    private static function chave(string $pacote,string $codigo,string $ref): string {
        return self::PREFIXO.hash('sha256', $pacote.'|'.$codigo.'|'.$ref);
    }

    /** O canal aplica o quórum uma vez por requisição elegível. */
    public static function observar_registro_canal(): void {
        if (is_callable([\Fator3\McpFiles\ChannelIncidents::class, 'observeRegistration'])) {
            \Fator3\McpFiles\ChannelIncidents::observeRegistration();
        }
    }

    private static function contexto_iam(array $evento): ?array {
        if ($evento['pacote'] !== 'google' || $evento['codigo'] !== 'autorizacao_recusada'
            || !preg_match('~^[a-z][a-z0-9_-]{0,39}/service-account-key-metadata$~D', $evento['recurso'])) {
            return null;
        }
        $iam = $evento['iam'] ?? null;
        if (!is_array($iam) || ($iam['permissao'] ?? null) !== 'iam.serviceAccountKeys.get') {
            return null;
        }
        $projeto = $iam['projeto'] ?? null;
        return [
            'permissao' => 'iam.serviceAccountKeys.get',
            'projeto' => is_string($projeto) && preg_match('/^[a-z0-9][a-z0-9.-]{0,62}$/D', $projeto) ? $projeto : null,
        ];
    }

    /** Fecha somente a identidade de acesso e geração reconhecidas pelo Google. */
    public static function encerrar_acesso(array $e): array {
        $motivo = $e['motivo_encerramento'] ?? '';
        $recurso = $e['recurso'] ?? null;
        $geracao = $e['geracao_acesso'] ?? null;
        if (($e['pacote'] ?? '') !== 'google' || ($e['codigo'] ?? '') !== 'integracao_indisponivel'
            || ($e['estado'] ?? '') !== 'recuperado' || ($e['acao_humana'] ?? true) !== false
            || !in_array($motivo, ['nao_usado','consolidado'], true)
            || !is_string($recurso) || !preg_match('~^[a-z][a-z0-9_-]{0,39}/[a-f0-9]{64}$~D', $recurso)
            || !is_int($geracao) || $geracao < 1) {
            return ['ok'=>false,'codigo'=>'observacao_invalida'];
        }
        $ref = hash_hmac('sha256', $recurso, wp_salt('auth'));
        $key = self::chave('google','integracao_indisponivel',$ref);
        return self::com_trava($key,static function() use ($key,$ref,$motivo,$geracao) {
            $r = self::normalizar(get_option($key,[]));
            if (($r['geracao_acesso'] ?? 0) > $geracao) return ['ok'=>true,'estado'=>'observacao_superada'];
            if (($r['geracao_acesso'] ?? 0) === $geracao && ($r['motivo_encerramento'] ?? null) === $motivo) {
                return ['ok'=>true,'estado'=>'recuperado'];
            }
            $r += ['pacote'=>'google','codigo'=>'integracao_indisponivel','recurso_ref'=>$ref,
                'rota'=>self::ROTAS['google'],'desde'=>time(),'episodio'=>0,'fila'=>[]];
            self::retirar_pendentes($r, true);
            if (($r['agrupamento']['ultimo_episodio'] ?? -1) === $r['episodio']) {
                --$r['agrupamento']['repeticoes'];
                unset($r['agrupamento']['ultimo_episodio']);
            }
            if (($r['agrupamento']['episodio_inicial'] ?? -1) === $r['episodio'] && !$r['agrupamento']['repeticoes']) {
                unset($r['agrupamento']);
            }
            $r['estado'] = 'recuperado';
            $r['acao_humana'] = false;
            $r['alterado_em'] = time();
            $r['duracao_segundos'] = max(0, time() - ($r['observado_em'] ?? time()));
            $r['motivo_encerramento'] = $motivo;
            $r['geracao_acesso'] = $geracao;
            return update_option($key,$r,false) ? ['ok'=>true,'estado'=>'recuperado'] : ['ok'=>false,'codigo'=>'persistencia_falhou'];
        });
    }

    /** Valor original do recurso nunca é guardado. O identificador opaco é estável no site. */
    public static function publicar(array $e): array {
        $p=$e['pacote']??''; $c=$e['codigo']??''; $id=$e['recurso']??''; $estado=$e['estado']??'';
        if (!is_string($p) || !isset(self::ROTAS[$p]) || !in_array($c,self::CODIGOS,true)
            || !is_string($id) || $id==='' || strlen($id)>240 || !in_array($estado,['aberto','recuperado'],true)
            || (isset($e['rota']) && $e['rota']!==self::ROTAS[$p])
            || !is_bool($e['acao_humana']??true)
            || (isset($e['desde']) && (!is_int($e['desde']) || $e['desde']<1 || $e['desde']>time()))
            || (isset($e['vence_em']) && (!is_int($e['vence_em']) || $e['vence_em']<1))) {
            return ['ok'=>false,'codigo'=>'observacao_invalida'];
        }
        // Um produtor que exige silêncio precisa do contrato específico.
        if (array_key_exists('motivo_encerramento',$e)) return ['ok'=>false,'codigo'=>'usar_encerramento_acesso'];
        $geracao = $p === 'google' && $c === 'integracao_indisponivel' ? ($e['geracao_acesso'] ?? null) : null;
        if ($geracao !== null && (!is_int($geracao) || $geracao < 1)) return ['ok'=>false,'codigo'=>'observacao_invalida'];
        $iam = self::contexto_iam($e);
        $qualificador = $p === 'meta' && $c === 'agenda_parada' && $estado === 'aberto'
            ? F3Base_Incidentes_Provedores::carencia_meta($id) : null;
        $ref=hash_hmac('sha256',$id,wp_salt('auth'));
        $key=self::chave($p,$c,$ref);
        return self::com_trava($key, static function() use ($key,$e,$p,$c,$id,$ref,$estado,$iam,$geracao,$qualificador) {
            $antes = get_option($key, []);
            $r = self::normalizar($antes);
            $geracao_atual = $r['geracao_acesso'] ?? null;
            if ($geracao_atual !== null && ($geracao === null || $geracao < $geracao_atual
                || ($geracao === $geracao_atual && (isset($r['motivo_encerramento'])
                    || ($estado === 'aberto' && $r['estado'] === 'recuperado'))))) {
                return ['ok'=>true,'estado'=>'observacao_superada'];
            }
            if (!$r && $estado === 'recuperado' && $geracao === null) return ['ok'=>true,'estado'=>'sem_incidente'];
            if ($geracao !== null) {
                $r['geracao_acesso'] = $geracao;
                if ($geracao !== $geracao_atual) unset($r['motivo_encerramento']);
            }
            if (($r['estado'] ?? '') !== $estado) {
                $r['pacote']=$p; $r['codigo']=$c; $r['recurso_ref']=$ref; $r['rota']=self::ROTAS[$p];
                if ($p==='core' && $c==='could_not_set' && preg_match('/^[a-z0-9_]{1,120}$/D',$e['gancho']??'')) { $r['gancho']=$e['gancho']; }
                $r['estado']=$estado; $r['alterado_em']=time();
                $r['acao_humana']=$e['acao_humana']??true; $r['vence_em']=$e['vence_em']??null;
                $contexto = $iam ?? ($estado === 'recuperado' ? ($r['iam'] ?? null) : null);
                unset($r['iam']);
                if ($contexto !== null) $r['iam'] = $contexto;
                if ($estado === 'aberto') {
                    $r['episodio'] = ($r['episodio'] ?? 0) + 1;
                    $r['desde'] = $e['desde'] ?? time();
                    $r['observado_em'] = time();
                    $r['suprimido_por_carencia'] = false;
                    $r['codigo_carencia'] = $qualificador ?? $c;
                    unset($r['duracao_segundos']);
                    $r['fila'][] = self::aviso($r, 'aberto');
                } elseif (!empty($r['episodio'])) {
                    self::recuperar($r);
                } else {
                    // Marca de geração sem abertura local, inclusive quando chega primeiro o PULL de recuperação.
                    $r['fila'] = [];
                    $r['episodio'] = 0;
                    $r['desde'] = $e['desde'] ?? time();
                }
                if ($p === 'canal' && $c === 'canal_indisponivel' && $id === 'registro-wordpress') {
                    $r['historico_registro'] = self::historico_registro($r, $e);
                }
            } elseif ($estado === 'aberto') {
                if ($qualificador !== null) $r['codigo_carencia'] = $qualificador;
                if ($iam !== null && ($r['iam'] ?? null) !== $iam) {
                    $r['iam'] = $iam;
                    foreach ($r['fila'] as &$aviso) {
                        if ($aviso['episodio'] === $r['episodio'] && $aviso['estado'] === 'aberto' && $aviso['entrega'] === 'pendente') {
                            $aviso['iam'] = $iam;
                        }
                    }
                    unset($aviso);
                }
                if (isset($e['vence_em'])) $r['vence_em'] = $e['vence_em'];
            }
            if ($r !== $antes && !update_option($key, $r, false)) return ['ok'=>false,'codigo'=>'persistencia_falhou'];
            return self::entregar($key,$r);
        });
    }

    /** Rastro circular administrativo, separado da fila de entregas e da identificação do recurso. */
    private static function historico_registro(array $r, array $e): array {
        try {
            $registro = F3Base_Incidentes_Provedores::registro_canal();
        } catch (Throwable $erro) {
            $registro = null;
        }
        $marcos = [];
        foreach (['init','wp_abilities_api_init','rest_api_init','f3_mcp_adapter_init','wp_loaded','admin_init','f3base_zelador_tick'] as $hook) {
            $marcos[$hook] = doing_action($hook) ? 'em_execucao' : (did_action($hook) ? 'concluido' : 'pendente');
        }
        $historico = $r['historico_registro'] ?? [];
        $historico[] = [
            'estado'=>$e['estado'], 'recebido_em'=>time(), 'desde_informado'=>$e['desde'] ?? null,
            'origem'=>'publicador_canal', 'contexto'=>defined('WP_CLI') && WP_CLI ? 'cli' : (wp_doing_cron() ? 'http_cron' : 'web'),
            'versao_core'=>F3BASE_PLUGIN_VERSAO, 'versao_canal'=>defined('F3_MCP_FILES_VERSION') ? F3_MCP_FILES_VERSION : null,
            'marcos'=>$marcos, 'registro_na_recepcao'=>$registro,
        ];
        return array_slice($historico, -12);
    }

    private static function com_trava(string $key, callable $fn): array {
        if (!F3Base_Pipedrive_Fila::travar_linha($key)) {return ['ok'=>false,'codigo'=>'ocupado','repetir'=>true];}
        try {
            // Uma opção não-autoload lida antes da trava pode estar no cache deste processo.
            wp_cache_delete($key,'options'); wp_cache_delete('notoptions','options');
            return $fn();
        } finally {F3Base_Pipedrive_Fila::liberar_linha($key);}
    }

    /** Registros de 1.98.0 só têm o último recibo. Nunca inferir aceitação de uma mera tentativa. */
    private static function normalizar(array $r): array {
        if (!$r) return [];
        $r += ['fila'=>[], 'fases_enviadas'=>[], 'suprimido_por_carencia'=>false];
        if (isset($r['episodio'])) return $r;
        $numero = (($r['fila'][0]['estado'] ?? '') === 'recuperado') ? 1 : 0;
        foreach ($r['fila'] as &$ev) {
            if ($ev['estado'] === 'aberto') ++$numero;
            $ev['episodio'] = max(1, $numero);
            $ev['observado_em'] = $ev['em'] ?? $ev['desde'];
        }
        unset($ev);
        $r['episodio'] = max(1, $numero);
        $r['historico_anterior'] = 'somente_ultimo_recibo_disponivel';
        $r['observado_em'] = $r['alterado_em'] ?? $r['desde'] ?? time();
        foreach ($r['fila'] as $ev) {
            if ($ev['episodio'] === $r['episodio'] && $ev['estado'] === 'aberto') {
                $r['observado_em'] = $ev['observado_em'];
            }
        }
        $recibo = $r['ultimo_envio'] ?? [];
        $reconciliado = $r['reconciliacao'] ?? [];
        if (($reconciliado['resultado'] ?? '') === 'aceito' && ($reconciliado['em'] ?? 0) >= ($recibo['em'] ?? 0)) {
            $recibo = ['fase'=>$reconciliado['fase'], 'em'=>$reconciliado['em'], 'codigo'=>'aceito_reconciliado'];
        }
        if (in_array($recibo['codigo'] ?? '', ['aceito_wp_mail','aceito_reconciliado'], true)) {
            // Se a fila começa por uma abertura, o recibo anterior pertence a outro episódio.
            $episodio_recibo = $r['fila'] ? (($r['fila'][0]['estado'] === 'recuperado') ? 1 : 0) : $r['episodio'];
            $r['fases_enviadas'][] = $recibo + ['episodio'=>$episodio_recibo, 'contagem'=>1, 'legado'=>true];
        }
        return $r;
    }

    private static function aviso(array $r, string $fase): array {
        $ev = ['estado'=>$fase, 'episodio'=>$r['episodio'], 'desde'=>$r['desde'], 'observado_em'=>$r['observado_em'],
            'em'=>time(), 'vence_em'=>$r['vence_em'] ?? null, 'acao_humana'=>$r['acao_humana'], 'entrega'=>'pendente'];
        if (isset($r['iam'])) $ev['iam'] = $r['iam'];
        return $ev;
    }

    private static function abertura_aceita(array $r, int $episodio): bool {
        for ($i = count($r['fases_enviadas'] ?? []) - 1; $i >= 0; --$i) {
            $fase = $r['fases_enviadas'][$i];
            if ($fase['episodio'] === $episodio && $fase['fase'] === 'aberto') return true;
        }
        return false;
    }

    /** Operação sob a trava da referência. Preserva reservas externas até a reconciliação. */
    private static function retirar_pendentes(array &$r, bool $encerramento_silencioso): bool {
        $restantes = []; $abertura_reservada = false;
        foreach ($r['fila'] as $ev) {
            if ($ev['episodio'] === $r['episodio'] && ($ev['estado'] === 'aberto' || ($encerramento_silencioso && $ev['estado'] === 'recuperado'))) {
                if ($ev['entrega'] !== 'reservado') continue;
                $ev['dispensar_retentativa'] = true;
                if ($encerramento_silencioso) $ev['encerramento_silencioso'] = true;
                if ($ev['estado'] === 'aberto') $abertura_reservada = true;
            }
            $restantes[] = $ev;
        }
        $r['fila'] = $restantes;
        return $abertura_reservada;
    }

    private static function recuperar(array &$r): void {
        $aceita = self::abertura_aceita($r, $r['episodio']);
        // Se a coleta de recuperação chegou antes da varredura, o intervalo já observado
        // ainda comprova uma reincidência elegível. Nunca envia abertura de um caso encerrado.
        $carencia = F3Base_Alertas_Operacionais::carencia_minutos($r['codigo_carencia'] ?? $r['codigo']) * MINUTE_IN_SECONDS;
        if (!$aceita) self::absorver_abertura_na_janela($r, $r['alterado_em'], $carencia);
        $reservada = self::retirar_pendentes($r, false);
        $r['duracao_segundos'] = max(0, $r['alterado_em'] - $r['observado_em']);
        $r['suprimido_por_carencia'] = !$aceita && !$reservada
            && $r['duracao_segundos'] < $carencia;
        if ($r['suprimido_por_carencia']) {
            $r['episodios_suprimidos'][] = ['episodio'=>$r['episodio'], 'aberto_em'=>$r['observado_em'],
                'recuperado_em'=>$r['alterado_em'], 'duracao_segundos'=>$r['duracao_segundos'], 'suprimido_por_carencia'=>true];
        }
        if ($aceita || $reservada) $r['fila'][] = self::aviso($r, 'recuperado');
    }

    private static function confirmar_fase(array &$r, array $ev, string $codigo): void {
        $agora = time();
        $r['ultimo_envio'] = ['fase'=>$ev['estado'], 'codigo'=>$codigo, 'em'=>$agora];
        $r['fases_enviadas'][] = $r['ultimo_envio'] + ['episodio'=>$ev['episodio'], 'contagem'=>$ev['contagem'] ?? 1];
        if ($ev['estado'] !== 'aberto' || !empty($ev['encerramento_silencioso'])) return;
        $horas = F3Base_Alertas_Operacionais::janela_agrupamento_horas();
        if ($horas > 0) {
            $r['agrupamento'] = ['inicio_em'=>$agora,'ate'=>$agora + $horas * HOUR_IN_SECONDS,
                'episodio_inicial'=>$ev['episodio'], 'repeticoes'=>0];
        }
    }

    private static function contar_reincidencia(array &$r): void {
        if (($r['agrupamento']['ultimo_episodio'] ?? 0) !== $r['episodio']) {
            ++$r['agrupamento']['repeticoes'];
            $r['agrupamento']['ultimo_episodio'] = $r['episodio'];
        }
    }

    /** A elegibilidade pertence à janela [início, fim), mesmo que o executor só passe depois. */
    private static function absorver_abertura_na_janela(array &$r, int $agora, int $carencia): void {
        $grupo = $r['agrupamento'] ?? null;
        if (!$grupo || $r['episodio'] === $grupo['episodio_inicial']) return;
        $elegivel_em = $r['observado_em'] + $carencia;
        if ($elegivel_em > $agora || $elegivel_em >= $grupo['ate']) return;
        foreach ($r['fila'] as $i => $ev) {
            if ($ev['episodio'] === $r['episodio'] && $ev['estado'] === 'aberto' && $ev['entrega'] === 'pendente') {
                self::contar_reincidencia($r);
                array_splice($r['fila'], $i, 1);
                return;
            }
        }
    }

    /** O resumo de reincidências só fica pronto quando a janela fixa termina e sua contagem é conhecida. */
    private static function fechar_janela(array &$r): void {
        $grupo = $r['agrupamento'] ?? [];
        if (!$grupo || $grupo['ate'] > time()) return;
        if ($r['estado'] === 'aberto') {
            $carencia = F3Base_Alertas_Operacionais::carencia_minutos($r['codigo_carencia'] ?? $r['codigo']) * MINUTE_IN_SECONDS;
            self::absorver_abertura_na_janela($r, time(), $carencia);
            $grupo = $r['agrupamento'];
        }
        if ($grupo['repeticoes'] > 0) {
            $r['fila'][] = ['estado'=>'agrupado','episodio'=>$grupo['episodio_inicial'],'desde'=>$grupo['inicio_em'],
                'em'=>$grupo['ate'],'contagem'=>$grupo['repeticoes'],'acao_humana'=>false,'vence_em'=>null,'entrega'=>'pendente'];
        }
        unset($r['agrupamento']);
    }

    private static function mensagem(array $r, array $ev): array {
        $fase = ['aberto'=>'Incidente técnico','recuperado'=>'Recuperação técnica','agrupado'=>'Reincidências técnicas'][$ev['estado']];
        $titulo = $fase.' · '.$r['pacote'].' · '.$r['codigo'];
        $cabecalho = [$titulo];
        if (isset($r['codigo_carencia']) && $r['codigo_carencia'] !== $r['codigo'] && $ev['estado'] === 'aberto') {
            $cabecalho[] = 'Causa confirmada: '.$r['codigo_carencia'];
        }
        if (isset($ev['iam'])) {
            $titulo = $fase.' · google · validade da chave '.($ev['estado'] === 'aberto' ? 'não consultável' : 'consultável');
            $cabecalho = [$titulo, 'Permissão: '.$ev['iam']['permissao'], 'Projeto: '.($ev['iam']['projeto'] ?? 'não informado')];
        }
        if ($ev['estado'] === 'agrupado') {
            $titulo .= ' · '.$ev['contagem'];
            $cabecalho = [$titulo, 'Reincidências após a primeira abertura avisada: '.$ev['contagem'],
                'Total de episódios com a abertura inicial: '.($ev['contagem'] + 1)];
        }
        $texto = implode("\n",[...$cabecalho,'Site: '.wp_parse_url(home_url(),PHP_URL_HOST),
            'Referência do recurso: '.$r['recurso_ref'],'Desde: '.wp_date('d/m/Y H:i:s T',$ev['desde']),
            'Observação: '.wp_date('d/m/Y H:i:s T',$ev['em']),
            !empty($ev['vence_em'])?'Vencimento: '.wp_date('d/m/Y H:i:s T',$ev['vence_em']):'',
            'Ação de pessoa: '.($ev['estado']==='aberto' && $ev['acao_humana']?'sim':'não'),'Reparo: '.admin_url($r['rota'])]);
        return [$titulo, $texto];
    }

    private static function entregar(string $key,array $r): array {
        if (!$r) return ['ok'=>true, 'estado'=>'sem_incidente'];
        $antes = $r;
        $r = self::normalizar($r);
        self::fechar_janela($r);
        if ($r !== $antes && !update_option($key,$r,false)) return ['ok'=>false,'codigo'=>'persistencia_falhou'];
        while (!empty($r['fila'])) {
            $ev=$r['fila'][0];
            if ($ev['entrega'] === 'reservado') return ['ok'=>false,'estado'=>'entrega_incerta'];
            $descartar = false;
            if ($ev['estado'] === 'aberto') {
                if ($r['estado'] !== 'aberto' || $ev['episodio'] !== $r['episodio']) {
                    $descartar = true;
                } elseif (time() < $r['observado_em'] + F3Base_Alertas_Operacionais::carencia_minutos($r['codigo_carencia'] ?? $r['codigo']) * MINUTE_IN_SECONDS) {
                    return ['ok'=>true,'estado'=>'aguardando_carencia'];
                } elseif (isset($r['agrupamento'])) {
                    self::contar_reincidencia($r);
                    $descartar = true;
                }
            } elseif ($ev['estado'] === 'recuperado') {
                $descartar = !self::abertura_aceita($r, $ev['episodio']);
            }
            if ($descartar) {
                array_shift($r['fila']);
                if (!update_option($key,$r,false)) return ['ok'=>false,'codigo'=>'persistencia_falhou'];
                continue;
            }
            if (F3Base_Alertas_Operacionais::destinatario()==='') return ['ok'=>true,'estado'=>'aguardando_destino'];
            if (($ev['tentar_apos']??0)>time()) return ['ok'=>true,'estado'=>'aguardando_retentativa'];
            $r['fila'][0]['entrega']='reservado';
            $r['fila'][0]['reserva']=wp_generate_uuid4();
            if (!update_option($key,$r,false)) return ['ok'=>false,'codigo'=>'reserva_nao_gravada'];
            [$titulo,$texto] = self::mensagem($r,$ev);
            $envio=F3Base_Alertas_Operacionais::enviar($titulo,$texto);
            if (!empty($envio['ok'])) {
                array_shift($r['fila']);
                self::confirmar_fase($r,$ev,$envio['codigo']);
            } else {
                if (($envio['estado']??'') !== 'incerto') {
                    $r['fila'][0]['entrega']='pendente';
                    $r['fila'][0]['tentar_apos']=time()+300;
                }
                $r['ultimo_envio']=['fase'=>$ev['estado'],'codigo'=>$envio['codigo'],'em'=>time()];
            }
            if (!update_option($key,$r,false)) return ['ok'=>false,'codigo'=>'confirmacao_nao_gravada'];
            if (!$envio['ok']) return ['ok'=>false,'estado'=>$envio['estado']];
        }
        return ['ok'=>true,'estado'=>$r['estado'],'entrega'=>$r['ultimo_envio']??null];
    }

    public static function reconciliar(array $e): array {
        if (!current_user_can('manage_options')) {return ['ok'=>false,'codigo'=>'sem_permissao'];}
        if (!preg_match('/^[a-f0-9]{64}$/D', $e['id']??'') || empty($e['reserva'])
            || !in_array($e['resultado']??'', ['aceito','nao_enviado'], true)) {
            return ['ok'=>false,'codigo'=>'entrada_invalida'];
        }
        $key=self::PREFIXO.$e['id'];
        return self::com_trava($key,static function() use ($key,$e) {
            $r=self::normalizar(get_option($key,[]));
            $ev=$r['fila'][0]??[];
            if (($ev['entrega']??'')!=='reservado' || ($ev['reserva']??null)!==$e['reserva']) {
                return ['ok'=>false,'codigo'=>'reserva_divergente'];
            }
            if ($e['resultado'] === 'aceito') {
                array_shift($r['fila']);
                self::confirmar_fase($r,$ev,'aceito_reconciliado');
            } elseif (!empty($ev['dispensar_retentativa'])) {
                array_shift($r['fila']);
                $r['fila'] = array_values(array_filter($r['fila'], static fn($proximo) => $proximo['episodio'] !== $ev['episodio'] || $proximo['estado'] !== 'recuperado'));
            }
            else {$r['fila'][0]['entrega']='pendente'; unset($r['fila'][0]['tentar_apos']);}
            $r['reconciliacao']=['resultado'=>$e['resultado'],'em'=>time(),'operador'=>get_current_user_id(),'fase'=>$ev['estado']];
            if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
            return ['ok'=>true,'entregas_pendentes'=>count($r['fila'])];
        });
    }

    public static function vencimento(string $pacote,string $codigo,string $id,int $vence): array {
        if ($vence<1) {return ['ok'=>true,'estado'=>'validade_desconhecida'];}
        $dias=(int)(F3Base_Options::ler('f3base_avisos_tecnicos')['antecedencia_dias']??14);
        $limiar=$vence-$dias*DAY_IN_SECONDS;
        return self::publicar(['pacote'=>$pacote,'codigo'=>$codigo,'recurso'=>$id,'vence_em'=>$vence,
            'desde'=>max(1,min(time(),$limiar)),'estado'=>time()>=$limiar?'aberto':'recuperado']);
    }

    public static function listar(array $e=[]): array {
        global $wpdb;
        $apos=$e['apos']??'';
        $linhas=$wpdb->get_results($wpdb->prepare('SELECT option_name, option_value FROM %i WHERE option_name LIKE %s AND option_name>%s ORDER BY option_name LIMIT 51',
            $wpdb->options,$wpdb->esc_like(self::PREFIXO).'%',self::PREFIXO.$apos),ARRAY_A);
        if ($wpdb->last_error) {return ['ok'=>false,'codigo'=>'leitura_indisponivel'];}
        $itens=[]; $next=null;
        foreach (array_slice($linhas,0,50) as $linha) {
            $r=maybe_unserialize($linha['option_value']);
            if (!is_array($r)) {continue;}
            $r = self::normalizar($r);
            $id=substr($linha['option_name'],strlen(self::PREFIXO)); $r['id']=$id;
            $r['entregas_pendentes']=count($r['fila']??[]); $r['proxima_entrega']=$r['fila'][0]['entrega']??null;
            if ($r['proxima_entrega']==='reservado') {$r['reserva']=$r['fila'][0]['reserva']??null;}
            unset($r['fila']); $itens[]=$r; $next=$id;
        }
        return ['ok'=>true,'itens'=>$itens,'proximo'=>count($linhas)>50?$next:null,
            'destino_configurado'=>F3Base_Alertas_Operacionais::destinatario()!==''];
    }

    public static function observar(): void {
        if (wp_installing() || get_transient('f3base_incidentes_revisados')) {return;}
        self::com_trava('f3base_revisar_incidentes',static function() {
            if (get_transient('f3base_incidentes_revisados')) {return [];}
            set_transient('f3base_incidentes_revisados',1,300);
            F3Base_Incidentes_Provedores::observar();
            $apos=''; $abertos=[];
            do {
                $page=self::listar(['apos'=>$apos]); if (!$page['ok']) {return [];}
                foreach ($page['itens'] as $r) {
                    if ($r['entregas_pendentes'] || (isset($r['agrupamento']) && $r['agrupamento']['ate'] <= time())) {
                        $key=self::PREFIXO.$r['id'];
                        self::com_trava($key,static fn()=>self::entregar($key,get_option($key,[])));
                    }
                    if ($r['estado']==='aberto' && self::abertura_aceita($r,$r['episodio'])) {$abertos[$r['id']]=[$r['episodio'],$r['pacote'].' · '.$r['codigo'].' · '.substr($r['recurso_ref'],0,12)];}
                }
                $apos=$page['proximo'];
            } while ($apos);
            $cfg=F3Base_Options::ler('f3base_avisos_tecnicos'); $dia=wp_date('Y-m-d');
            if ($abertos && !empty($cfg['resumo_diario']) && F3Base_Alertas_Operacionais::destinatario()!==''
                && get_option('f3base_incidentes_dia','')!==$dia && update_option('f3base_incidentes_dia',$dia,false)) {
                $envio=F3Base_Alertas_Operacionais::enviar('Resumo diário de incidentes técnicos',implode("\n",array_column($abertos,1)));
                if ($envio['ok']) {
                    foreach ($abertos as $id => [$episodio]) {
                        $key = self::PREFIXO.$id;
                        self::com_trava($key, static function() use ($key,$episodio,$envio) {
                            $r = self::normalizar(get_option($key,[]));
                            if ($r) {
                                self::confirmar_fase($r,['estado'=>'resumo_diario','episodio'=>$episodio],$envio['codigo']);
                                update_option($key,$r,false);
                            }
                            return [];
                        });
                    }
                }
                if (!$envio['ok'] && $envio['estado']!=='incerto') {delete_option('f3base_incidentes_dia');}
            }
            return [];
        });
    }
}
