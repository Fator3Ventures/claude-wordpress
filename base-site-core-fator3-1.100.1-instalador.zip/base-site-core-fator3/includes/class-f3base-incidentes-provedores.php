<?php
/** Adaptadores de leitura local para as versões de provedores anteriores ao contrato 1. */
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3Base_Incidentes_Provedores {
    private const LEGADOS = [
        'Fator3\\Meta\\Worker::notify'=>'meta',
        'Fator3\\LinkedIn\\Credentials::notice'=>'linkedin',
        'Fator3\\McpGoogle\\RenewalNotifications::send_once'=>'google',
        'Fator3\\McpGoogle\\Automation\\Alerts::channel_blocked'=>'google',
        'Fator3\\McpGoogle\\Automation\\Alerts::send'=>'google',
    ];
    private static bool $encaminhando=false;
    /** Reutilizar a leitura operacional apenas durante uma passagem do coletor Meta. */
    private static ?array $carencias_meta_na_coleta = null;

    public static function cron(array $s): void {
        $ultima=max((int)($s['ultima_cli']??0),(int)($s['iniciado_em']??0));
        if (!$ultima) {return;}
        self::situacao('core','cron_sem_passagem','executor-cli',$ultima<time()-HOUR_IN_SECONDS,$ultima+HOUR_IN_SECONDS);
    }
    private static function situacao(string $p,string $c,string $id,bool $falha,int $desde=0): array {
        return F3Base_Incidentes::publicar(['pacote'=>$p,'codigo'=>$c,'recurso'=>$id,
            'desde'=>min(time(),$desde?:time()),'estado'=>$falha?'aberto':'recuperado']);
    }

    public static function observar(): void {
        if (F3Base_Alertas_Operacionais::destinatario()!=='') {
            self::situacao('core','destino_tecnico_ausente','email-wordpress',false);
        }
        foreach (['cron','meta','linkedin','google','pipedrive','canal','graph'] as $origem) {
            try {
                if ($origem==='cron') {self::cron((array)get_option(F3Base_Zelador::ESTADO,[]));}
                else {self::$origem();}
            } catch (Throwable $erro) {
                // Uma falha ao obter diagnóstico não confirma recuperação nem bloqueia os demais.
                do_action('f3base_incidente_leitura_indisponivel',$origem);
            }
        }
    }

    /** A Meta 0.31 agrupa falhas de agenda e preserva a causa apenas no diagnóstico local. */
    public static function carencia_meta(string $recurso): ?string {
        if (!is_callable(['Fator3\\Meta\\Worker','health'])) {
            return null;
        }
        $causas = self::$carencias_meta_na_coleta ?? self::causas_meta();
        return $causas[$recurso] ?? null;
    }

    private static function causas_meta(): array {
        try {
            // A visão operacional acrescenta as causas; esta chamada não agenda nem acessa a Graph.
            $saude = \Fator3\Meta\Worker::health(true);
        } catch (Throwable $erro) {
            return [];
        }
        $conexoes = [];
        $agendas = [];
        $lacunas = [];
        $referencias = [];
        foreach ($saude['issues'] ?? [] as $issue) {
            $tipo = $issue['code'] ?? '';
            if ($tipo === 'schedule_collection_unresolved') {
                $lacunas[$issue['schedule_id']] = $issue['connection_id'];
                continue;
            }
            if (!in_array($tipo, ['connection_authorization_failed','schedule_authorization_failed'], true)) {
                continue;
            }
            $causa = match ($issue['last_code'] ?? '') {
                'grant_revoked','credential_revoked','authorization_revoked' => 'concessao_revogada',
                'token_expired' => 'credencial_recusada',
                'token_rejected','not_authorized' => (($issue['last_error']['auth_scope'] ?? '') === 'connection'
                    && !empty($issue['last_error']['connection_validation'])) ? 'credencial_recusada' : null,
                default => null,
            };
            if ($causa === null) {
                continue;
            }
            if ($tipo === 'connection_authorization_failed') {
                $id = $issue['connection_id'];
                $conexoes[$id] = $causa;
            } else {
                $id = $issue['schedule_id'];
                $agendas[$id] = $causa;
            }
            $referencias[hash('sha256', $tipo.'|'.$id)] = $causa;
        }
        foreach ($lacunas as $agenda => $conexao) {
            // Identidade oficial só depois das 26h de lacuna no produtor.
            $causa = $agendas[$agenda] ?? $conexoes[$conexao] ?? null;
            if ($causa !== null) {
                $referencias[hash('sha256', 'schedule_overdue|'.$agenda)] = $causa;
            }
        }
        return $referencias;
    }

    public static function meta(): void {
        if (!is_callable(['Fator3\\Meta\\Worker','health'])) {return;}
        $key='f3base_incidentes_meta_ativos';
        if (!F3Base_Pipedrive_Fila::travar_linha($key)) {return;}
        try {
            $h=\Fator3\Meta\Worker::health();
            if (!isset($h['issues']) || !is_array($h['issues'])) {return;}
            $ativos=[];
            foreach ($h['issues'] as $i) {
                if (!in_array($i['code'],['connection_authorization_failed','schedule_authorization_failed',
                    'schedule_resource_access_failed','schedule_overdue','schedule_budget_exhausted','worker_missing'],true)) {continue;}
                $id=hash('sha256',$i['code'].'|'.($i['schedule_id']??$i['connection_id']??'worker'));
                $ativos[$id]=true;
                self::$carencias_meta_na_coleta ??= self::causas_meta();
                self::situacao('meta','agenda_parada',$id,true,(int)($i['blocked_since']??$i['last_error']['observed_at']??0));
            }
            wp_cache_delete($key,'options');
            $antes=(array)get_option($key,[]);
            foreach (array_diff_key($antes,$ativos) as $id=>$v) {
                $r=self::situacao('meta','agenda_parada',$id,false);
                if (empty($r['ok'])) {$ativos[$id]=true;}
            }
            if ($antes!==$ativos) {update_option($key,$ativos,false);}
        } finally {
            self::$carencias_meta_na_coleta = null;
            F3Base_Pipedrive_Fila::liberar_linha($key);
        }
    }

    public static function linkedin(): void {
        if (!is_callable(['Fator3\\LinkedIn\\Credentials','status'])) {return;}
        foreach (\Fator3\LinkedIn\Credentials::status()['connections']??[] as $c) {
            if (empty($c['enabled'])) {continue;}
            $id=(string)$c['connection_id'];
            if ($c['token_configured']) {F3Base_Incidentes::vencimento('linkedin','token_vencendo',$id,(int)$c['expires_at']);}
            if ($c['refresh_configured']) {F3Base_Incidentes::vencimento('linkedin','refresh_vencendo',$id,(int)$c['refresh_expires_at']);}
            self::situacao('linkedin','credencial_invalida',$id,!empty($c['incident']) || !empty($c['failures']));
        }
    }

    /** Vigência da prova e momento da renovação vêm da mesma conexão do produtor. */
    private static function observar_prova(string $recurso, array $prova, array $renovacao): void {
        $inicio = $prova['at'] ?? null;
        if (!is_int($inicio) || $inicio < 1 || $inicio > time() || !array_key_exists('expires', $prova)) {
            return;
        }
        $vence = $prova['expires'];
        if ($vence === null) {
            self::situacao('google', 'prova_vencendo', $recurso, false);
            return;
        }
        if (!is_int($vence) || $vence <= $inicio) {
            return;
        }
        $limiar = $vence - intdiv($vence - $inicio, 4);
        $agenda = $renovacao['next_attempt'] ?? null;
        // A próxima retentativa de uma falha não adia o aviso de uma prova vencendo.
        if (($renovacao['result'] ?? '') === 'success' && is_int($agenda) && $agenda > $inicio && $agenda <= $vence) {
            $limiar = max($limiar, $agenda);
        }
        $agora = time();
        F3Base_Incidentes::publicar([
            'pacote'=>'google', 'codigo'=>'prova_vencendo', 'recurso'=>$recurso, 'vence_em'=>$vence,
            'desde'=>min($agora, $limiar), 'estado'=>$agora >= $limiar ? 'aberto' : 'recuperado',
        ]);
    }

    public static function google(): void {
        if (!is_callable(['Fator3\\McpGoogle\\ConversionDelivery','read'])) {return;}
        $conexoes=\Fator3\McpGoogle\Connections::registry_verified();
        if (is_wp_error($conexoes)) {return;}
        foreach (array_keys($conexoes) as $id) {
            \Fator3\McpGoogle\Connections::run($id,static function() use ($id) {
                $c=\Fator3\McpGoogle\ConversionDelivery::read();
                if (is_array($c) && !empty($c['enabled'])) {
                    $provas = is_array($c['verified'] ?? null) ? $c['verified'] : [];
                    $renovacoes = is_array($c['renewal'] ?? null) ? $c['renewal'] : [];
                    foreach (array_keys($provas + $renovacoes) as $alvo) {
                        $recurso = $id.'/'.$alvo;
                        $prova = $provas[$alvo] ?? [];
                        $r = is_array($renovacoes[$alvo] ?? null) ? $renovacoes[$alvo] : [];
                        if (is_array($prova)) {
                            // Uma prova Ads anterior à 0.39 pode conservar a data antiga no banco.
                            if ($alvo === 'google_ads' && isset($prova['expires'])) {
                                $adapter = new \Fator3\McpGoogle\ConversionDelivery($alvo, $id);
                                $cap = $adapter->capabilities();
                                if (array_key_exists('verification_expires_at', $cap)) {
                                    $prova['expires'] = $cap['verification_expires_at'];
                                }
                            }
                            self::observar_prova($recurso, $prova, $r);
                        }
                        if (in_array($r['result']??'',['success','failed'],true)) {
                            self::situacao('google','renovacao_falhou',$recurso,$r['result']==='failed',(int)($r['last_at']??0));
                        }
                    }
                }
                $offset=0;
                do {
                    $page=\Fator3\McpGoogle\Automation\Alerts::state(['limit'=>100,'offset'=>$offset]);
                    if (empty($page['available'])) {return;}
                    foreach ($page['incidents'] as $r) {
                        if (($r['event'] ?? '') === 'key_metadata' && ($r['status'] ?? '') === 'open'
                            && ($r['code'] ?? '') === 'key_metadata_permission_denied'
                            && ($r['resource'] ?? '') === 'service-account-key-metadata') {
                            F3Base_Incidentes::publicar([
                                'pacote'=>'google', 'codigo'=>'autorizacao_recusada',
                                'recurso'=>$id.'/service-account-key-metadata', 'estado'=>'aberto',
                                'desde'=>(int)$r['created_at'], 'acao_humana'=>true,
                                'iam'=>['permissao'=>'iam.serviceAccountKeys.get', 'projeto'=>$r['context']['project_id'] ?? null],
                            ]);
                        }
                        if (($r['event'] ?? '') === 'access' && array_key_exists('generation', $r)) {
                            self::observar_acesso_google($id, $r);
                            continue;
                        }
                        if (in_array($r['event']??'',['channel','access','cron_late','sitemap_error','scheduled_check'],true)
                            && in_array($r['status']??'',['open','resolved'],true)) {
                            self::situacao('google','integracao_indisponivel',$id.'/'.$r['id'],$r['status']==='open',(int)$r['created_at']);
                        }
                    }
                    $offset=$page['next_offset'];
                } while ($offset!==null);
            });
        }
    }

    /** Projeção do registro de acesso da conexão atual, inclusive após atualização do produtor. */
    private static function observar_acesso_google(string $conexao, array $incidente): void {
        $id = $incidente['id'] ?? null;
        $geracao = $incidente['generation'];
        if (!is_string($id) || !preg_match('/^[a-f0-9]{64}$/D', $id) || !is_int($geracao) || $geracao < 1) {
            return;
        }

        $observacao = [
            'pacote'=>'google',
            'codigo'=>'integracao_indisponivel',
            'recurso'=>$conexao.'/'.$id,
            'geracao_acesso'=>$geracao,
        ];
        $estado = $incidente['status'] ?? '';
        if (in_array($estado, ['nao_usado', 'consolidado'], true)) {
            if (($incidente['notify_recovery'] ?? null) === false && ($incidente['resolution_reason'] ?? null) === $estado) {
                F3Base_Incidentes::encerrar_acesso($observacao + [
                    'estado'=>'recuperado',
                    'acao_humana'=>false,
                    'motivo_encerramento'=>$estado,
                ]);
            }
        } elseif (in_array($estado, ['open','resolved'], true)) {
            F3Base_Incidentes::publicar($observacao + [
                'estado'=>$estado === 'open' ? 'aberto' : 'recuperado',
                'desde'=>max(1, min(time(), (int) ($incidente['created_at'] ?? time()))),
            ]);
        }
    }

    public static function pipedrive(): void {
        if (!class_exists('Fator3\\Pipedrive\\CoreClient')) {return;}
        $s=(array)get_option('f3base_pipedrive_estado',[]);
        if (empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])) {return;}
        $falha=in_array($s['codigo']??'',['credencial_ou_permissao_recusada','credencial_recusada','permissao_recusada','conta_divergente'],true);
        if ($falha || F3Base_Integracoes::pipedrive_verificado($s)) {self::situacao('pipedrive','autorizacao_recusada','conta',$falha);}
    }

    public static function canal(): void {
        F3Base_Incidentes::observar_registro_canal();
    }

    /** Observação passiva. Inicializar o REST antes do adaptador CLI perde as rotas desta requisição. */
    public static function registro_canal(): ?array {
        if (!did_action('wp_loaded') || doing_action('init') || doing_action('rest_api_init')
            || doing_action('f3_mcp_adapter_init') || doing_action('wp_abilities_api_init')
            || !is_callable(['Fator3\\McpFiles\\ServerContract', 'status'])) {
            return null;
        }
        $status = \Fator3\McpFiles\ServerContract::status();
        $codigos = ['mcp_core_missing', 'mcp_server_disabled', 'mcp_server_missing',
            'mcp_route_conflict', 'mcp_route_missing', 'mcp_tools_missing'];
        $erros = array_values(array_intersect($codigos, $status['errors'] ?? []));
        $verificado = ($status['registry_checked'] ?? false) === true;
        if (!$verificado) {
            $erros = array_values(array_intersect($erros, ['mcp_core_missing', 'mcp_server_disabled']));
        }
        if (in_array('mcp_registry_error', $status['errors'] ?? [], true)) {return null;}
        if ($verificado && !$erros && (
            ($status['server_registered'] ?? null) !== true || ($status['tools_ready'] ?? null) !== true
        )) {return null;}
        return ['verificado'=>$verificado, 'erros'=>$erros];
    }

    public static function graph(): void {
        $versao=F3Base_Modulo_Meta_Capi::versao_graph();
        if (F3Base_Modulo_Meta_Capi::token()==='' || F3Base_Modulo_Meta_Capi::pixel_id()==='') {return;}
        $prazos=apply_filters('f3base_graph_fim_versoes',['v21.0'=>strtotime('2027-01-21 00:00:00 UTC')]);
        if (isset($prazos[$versao])) {F3Base_Incidentes::vencimento('meta','graph_vencendo','capi',$prazos[$versao]);}
        
    }

    /** Confere classe e método do produtor. Nunca consulta os argumentos da pilha. */
    private static function origem_legada(): string {
        foreach (debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,18) as $f) {
            $nome=($f['class']??'').'::'.$f['function'];
            if (isset(self::LEGADOS[$nome])) {return $nome;}
        }
        return '';
    }

    public static function email_legado($pre,array $mail) {
        if ($pre!==null || self::$encaminhando) {return $pre;}
        $titulo=$mail['subject']??'';
        if (!is_string($titulo)) {return $pre;}
        if (!preg_match('/^(?:Google: |Fator3 MCP Meta: atenção às coletas|Fator3 MCP LinkedIn — atenção à credencial|Fator3 — Verificação de conversões|Fator3 MCP Google — tarefa bloqueada)/u',$titulo)) {return $pre;}
        $origem=self::origem_legada();
        if ($origem==='') {return $pre;}
        self::$encaminhando=true;
        try {$fonte=self::LEGADOS[$origem]; self::$fonte();}
        catch (Throwable $e) {do_action('f3base_incidente_leitura_indisponivel',$fonte);}
        finally {self::$encaminhando=false;}
        // O transporte antigo não enviou este e-mail. A entrega do Core tem recibo próprio.
        return false;
    }

    public static function webhook_legado($pre,array $args,string $url) {
        if ($pre!==false || strtolower((string)wp_parse_url($url,PHP_URL_HOST))!=='hooks.slack.com') {return $pre;}
        return self::origem_legada()==='Fator3\\McpGoogle\\Automation\\Alerts::channel_blocked'
            ? new WP_Error('canal_tecnico_email','O incidente técnico usa o e-mail do Core.') : $pre;
    }
}
