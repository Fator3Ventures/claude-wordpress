<?php
/** Recuperação da captação e alertas operacionais; nunca cria contato ou conversão. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Captacao_Operacao {
    const HOOK='f3base_captacao_monitorar';
    private const RECURSO = 'captacao-meta';
    private static bool $acompanhando = false;
    public static function iniciar(): void {
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),96);
        add_action(self::HOOK,static function(){F3Base_Recuperacao::executar(static function(){self::reavaliar();self::acompanhar();F3Base_Fila::agendar(self::HOOK,time()+300);});});
    }
    private static function identidade(): string {
        return hash('sha256',F3BASE_PLUGIN_VERSAO.'|'.F3Base_Options::revisao('f3base_anuncios_meta').'|'.F3Base_Options::revisao('f3base_anuncios_meta_token'));
    }
    public static function reavaliar(): void {
        if(empty(F3Base_Options::ler('f3base_anuncios_meta')['ativo'])){return;}
        if(!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}
        $s=get_option('f3base_anuncios_estado',array());$key=self::identidade();
        if(($s['meta']['recuperacao_revisao']??'')===$key){return;}
        $lock=F3Base_Trava::adquirir('captacao-reavaliar',15);if(!$lock){return;}
        try {
            global $wpdb;$t=F3Base_Operacao_Intencoes::tabela();
            if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){return;}
            $old=F3Base_Operacao_Intencoes::da_tarefa('anuncios');$changed=array();
            foreach($old as $r){
                if($r['estado']!=='esgotada'||!empty($r['em_execucao'])){continue;}
                // A suspended task is an administrative pause. Only exhausted capture is superseded.
                $e=$r;$e['timestamp']=max(time(),$r['timestamp']+1);unset($e['intencao']);
                if(!F3Base_Operacao_Intencoes::registrar($e,time()+1)){return;}
                $n=$wpdb->update($t,array('estado'=>'concluida','codigo'=>'superada_por_nova_revisao','atualizada_em'=>time()),array('chave'=>$r['intencao'],'estado'=>'esgotada'));
                if($n===false){return;}$changed[]=array('anterior'=>$r['intencao'],'nova'=>F3Base_Operacao_Intencoes::chave($e),'em'=>time(),'release'=>F3BASE_PLUGIN_VERSAO);
            }
            F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($s)use($key,$changed){$s['meta']['recuperacao_revisao']=$key;$s['meta']['recuperacoes']=array_slice(array_merge($s['meta']['recuperacoes']??array(),$changed),-50);return $s;});
            if($changed){F3Base_Operacao_Intencoes::agendar(time()+1);F3Base_Fila::agendar(F3Base_Anuncios::EVENTO,time()+1);}
        } finally {F3Base_Trava::liberar($lock);}
    }
    public static function recuperada(): void {
        global $wpdb;$s=get_option('f3base_anuncios_estado',array())['meta']??array();
        if(!F3Base_Integracoes::revisoes_atuais($s,'f3base_anuncios_meta','f3base_anuncios_meta_token')||($s['estado']??'')!=='verificada'){return;}
        $n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='concluida',codigo='superada_por_consulta_completa',atualizada_em=%d WHERE tarefa='anuncios' AND estado='esgotada' AND reserva_ate<=%d",F3Base_Operacao_Intencoes::tabela(),time(),time()));
        if($n){F3Base_Fila::agendar(F3Base_Anuncios::EVENTO,time()+300);}
        self::observar();
    }
    /** Cadência observada não prova a configuração do crontab. Leitura sem reparos. */
    public static function cadencia(): array {
        global $wpdb;$t=$wpdb->prefix.'f3base_execucoes';$base=array('segundos'=>300,'fonte'=>'cadencia_solicitada_sem_amostra','amostras'=>0,'ultima_cli'=>null);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT inicio FROM %i WHERE origem='cli' AND parent_run_id='' AND core_examinado=1 AND inicio>=%d ORDER BY inicio DESC LIMIT 48",$t,time()-2*DAY_IN_SECONDS),ARRAY_A);
        if($wpdb->last_error){return $base+array('erro'=>'historico_indisponivel');}
        $times=array_values(array_unique(array_map(static fn($x)=>(int)$x['inicio'],$rows?:array())));$gaps=array();for($i=1;$i<count($times);$i++){$d=$times[$i-1]-$times[$i];if($d>=60&&$d<=21600){$gaps[]=$d;}}
        if(count($gaps)<2){return $base;}sort($gaps);$seconds=max(300,$gaps[(int)floor((count($gaps)-1)*0.5)]);return array('segundos'=>$seconds,'fonte'=>'intervalo_mediano_cli_observado','amostras'=>count($gaps),'ultima_cli'=>$times[0]);
    }
    public static function diagnostico(): array {
        $s=get_option('f3base_anuncios_estado',array())['meta']??array();$cfg=F3Base_Options::ler('f3base_anuncios_meta');$blocked=null;
        try{foreach(F3Base_Operacao_Intencoes::da_tarefa('anuncios') as $r){if(in_array($r['estado'],array('esgotada','suspensa'),true)){$blocked=$r;break;}}}catch(Throwable $e){return array('estado'=>'indisponivel','codigo'=>'intencoes_ilegivel');}
        $last=(int)($s['ultimo_sucesso_completo']??0);$scheduled=(int)($s['ultima_execucao_agendada']??0);$since=(int)($s['ativado_em']??time());$age=time()-($last?:$since);$scheduleAge=time()-($scheduled?:$since);$next=wp_next_scheduled(F3Base_Anuncios::EVENTO);
        $cadencia=self::cadencia();$tolerancia=max(300,(int)ceil($cadencia['segundos']*.2));$limiar=2*$cadencia['segundos']+$tolerancia;$transport=($s['codigo']??'')==='graph_transporte_indisponivel';$consecutive=(int)($s['falhas_transporte_consecutivas']??0);$failure=!empty($s['formularios_com_problema'])||(!empty($s['codigo'])&&!in_array($s['codigo'],array('paginando','catalogo_paginando','orcamento_execucao','coleta_em_execucao'),true));
        $failure=$failure&&(!$transport||$consecutive>=3);
        // A recent failed attempt is not a missed scheduled pass. Transport uses its own threshold.
        $delayAge=max($scheduleAge,$transport?0:$age);$delaySince=$transport?($scheduled?:$since):min($last?:$since,$scheduled?:$since);
        $state=empty($cfg['ativo'])?'desligada':($blocked?$blocked['estado']:($failure?'falha':($delayAge>=$limiar?'atrasada':'observada')));
        // O código Graph 190 do diagnóstico desta consulta identifica a recusa do token.
        $graph = $s['diagnostico_graph'] ?? [];
        $credencial_recusada = in_array($s['codigo'] ?? '', ['graph_acesso_recusado', 'formularios_parcialmente_disponiveis'], true)
            && ($graph['codigo'] ?? '') === 'graph_acesso_recusado'
            && ($graph['graph_code'] ?? null) === 190
            && ($graph['em'] ?? 0) > 0 && $graph['em'] >= ($s['ultimo_inicio'] ?? 0);
        return array('estado'=>$state,'codigo_incidente'=>$credencial_recusada ? 'credencial_invalida' : 'captacao_meta_indisponivel','estado_em'=>$state==='atrasada'?$delaySince+$limiar:(int)($s['ultimo_inicio']??time()),'execucoes_esperadas_perdidas'=>max(0,(int)floor(($delayAge-$tolerancia)/$cadencia['segundos'])),'limiar_execucoes_perdidas'=>2,'falhas_transporte_consecutivas'=>$consecutive,'limiar_falhas_transporte'=>3,'tolerancia_segundos'=>$tolerancia,'ultima_execucao_agendada'=>$scheduled?:null,'ultimo_sucesso_completo'=>$last?:null,'proxima_execucao_confirmada'=>$next?:null,'idade_cobertura_segundos'=>max(0,$age),'idade_agendador_segundos'=>max(0,$scheduleAge),'ocorrencia_bloqueadora'=>$blocked,'codigo'=>$blocked['codigo']??($s['codigo']??''),'acao'=>$blocked?'Corrija a configuração/credencial ou reative a ocorrência na Operação.':($state==='atrasada'?'Confira o cron e execute uma consulta completa.':'Acompanhamento automático.'),'cadencia_segundos'=>$cadencia['segundos'],'cadencia'=>$cadencia,'limiar_atraso_segundos'=>$limiar,'formularios_com_problema'=>$s['formularios_com_problema']??array());
    }
    /** A própria coleta e o monitor periódico observam a mesma sequência de transições. */
    public static function observar(): void {
        self::acompanhar();
    }

    private static function observar_reservado(array $d): bool {
        if (($d['estado'] ?? '') === 'indisponivel') {
            return false;
        }
        $problema = in_array($d['estado'], ['esgotada', 'atrasada', 'falha'], true);
        $agora = time();
        $salvo = F3Base_Options::atualizar_estado('f3base_anuncios_estado', static function ($estado) use ($problema, $d, $agora) {
            $alerta = $estado['meta']['alerta'] ?? [];
            $itens = $alerta['incidentes'] ?? [];
            $ativo = $alerta['ativo'] ?? '';
            if (!$itens && !empty($alerta['aberto'])) {
                $ativo = 'anterior-'.(int)($alerta['em'] ?? $agora);
                $itens[$ativo] = [
                    'id'=>$ativo, 'inicio'=>(int)($alerta['em'] ?? $agora), 'fim'=>null,
                    'causa'=>'incidente_anterior', 'estado_abertura'=>'anterior',
                    'abertura'=>['estado'=>'tentada','resultado'=>$alerta['resultado'] ?? ['estado'=>'incerto']],
                    'fechamento'=>['estado'=>'pendente'],
                ];
            }
            $codigo = $d['codigo_incidente'];
            if ($ativo !== '' && isset($itens[$ativo])) {
                $atual = &$itens[$ativo];
                // Migra a pendência anterior à troca antes da primeira tentativa de abertura.
                if (!isset($atual['central']) && ($atual['abertura']['estado'] ?? '') === 'pendente' && $problema) {
                    $atual['central'] = $codigo;
                }
                $mudou = isset($atual['central']) && $atual['central'] !== $codigo;
                if (!$problema || $mudou) {
                    $atual['fim'] = $agora;
                    $atual['duracao_segundos'] = max(0, $agora - $atual['inicio']);
                    $abertura = $atual['abertura'];
                    if ($abertura['estado'] === 'pendente') {
                        $atual['abertura']['estado'] = 'suprimida_recuperada';
                        $atual['fechamento']['estado'] = 'suprimido_sem_abertura_confirmada';
                    } elseif (!isset($atual['central']) && ($abertura['resultado']['estado'] ?? '') !== 'processado') {
                        $atual['fechamento']['estado'] = 'suprimido_sem_abertura_confirmada';
                    }
                    $ativo = '';
                }
                unset($atual);
            }
            if ($problema && $ativo === '') {
                $ativo = wp_generate_uuid4();
                $itens[$ativo] = [
                    'id'=>$ativo, 'inicio'=>max(1, min($agora, (int)($d['estado_em'] ?? $agora))), 'fim'=>null,
                    'causa'=>$d['codigo'] ?: 'passagens_esperadas_perdidas', 'estado_abertura'=>$d['estado'],
                    'central'=>$codigo, 'abertura'=>['estado'=>'pendente'], 'fechamento'=>['estado'=>'pendente'],
                ];
            }
            foreach ($itens as $id => $item) {
                if (count($itens) <= 50) break;
                if ($id !== $ativo && !empty($item['fim'])
                    && !in_array($item['fechamento']['estado'] ?? '', ['pendente','confirmacao_central'], true)) {
                    unset($itens[$id]);
                }
            }
            $estado['meta']['alerta'] = ['schema'=>3,'ativo'=>$ativo,'aberto'=>$ativo!=='','em'=>$agora,'incidentes'=>$itens];
            return $estado;
        });
        return !empty($salvo['persisted']);
    }

    private static function gravar_fase(string $id, string $fase, array $valor): bool {
        $salvo = F3Base_Options::atualizar_estado('f3base_anuncios_estado', static function ($estado) use ($id, $fase, $valor) {
            if (!isset($estado['meta']['alerta']['incidentes'][$id])) return null;
            $estado['meta']['alerta']['incidentes'][$id][$fase] = $valor;
            return $estado;
        });
        return !empty($salvo['persisted']);
    }

    /** Sob a trava estável do produtor. Aceite da observação e aceite de e-mail têm recibos distintos. */
    private static function publicar(array $item, string $fase): bool {
        $id = $item['id'];
        if (!self::gravar_fase($id, $fase, ['estado'=>'confirmacao_central','tentativa_em'=>time()])) return false;
        $resultado = F3Base_Incidentes::publicar([
            'pacote'=>'core', 'codigo'=>$item['central'], 'recurso'=>self::RECURSO,
            'estado'=>$fase === 'abertura' ? 'aberto' : 'recuperado', 'desde'=>$item['inicio'],
        ]);
        if (empty($resultado['ok'])) return false;
        return self::gravar_fase($id, $fase, [
            'estado'=>'registrada', 'registro_em'=>time(), 'resultado'=>array_intersect_key($resultado,array_flip(['ok','estado','codigo'])),
        ]);
    }

    /** Compatibilidade com a abertura aceita pelo remetente antigo, antes de existir registro central. */
    private static function recuperar_legado(array $item): bool {
        if (($item['abertura']['resultado']['estado'] ?? '') !== 'processado') {
            return self::gravar_fase($item['id'],'fechamento',['estado'=>'suprimido_sem_abertura_confirmada']);
        }
        if (($item['fechamento']['tentar_apos'] ?? 0) > time()) return false;
        $agora = time();
        $reserva = ['estado'=>'tentada','envio_em'=>$agora,'resultado'=>['estado'=>'incerto']];
        if (!self::gravar_fase($item['id'],'fechamento',$reserva)) return false;
        $titulo = 'Captação Meta recuperada — '.wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $texto = implode("\n", [
            'Site: '.home_url('/'), 'Incidente: '.$item['id'], 'Início: '.wp_date('d/m/Y H:i:s T',$item['inicio']),
            'Fim: '.wp_date('d/m/Y H:i:s T',$item['fim']), 'Duração em segundos: '.$item['duracao_segundos'],
            'Causa: '.$item['causa'], F3Base_Configuracoes_Hub::url('conexoes','f3base_anuncios_meta'),
        ]);
        $resultado = F3Base_Alertas_Operacionais::enviar($titulo,$texto);
        $reserva['resultado'] = $resultado;
        if (empty($resultado['ok']) && ($resultado['estado'] ?? '') !== 'incerto') {
            $reserva['estado'] = 'pendente';
            $reserva['tentar_apos'] = $agora + 300;
        }
        return self::gravar_fase($item['id'],'fechamento',$reserva) && $reserva['estado'] !== 'pendente';
    }

    public static function acompanhar(): void {
        if (self::$acompanhando || !F3Base_Pipedrive_Fila::travar_linha('captacao-alerta')) return;
        self::$acompanhando = true;
        try {
            if (!self::observar_reservado(self::diagnostico())) return;
            $alerta = get_option('f3base_anuncios_estado',[])['meta']['alerta'] ?? [];
            foreach ($alerta['incidentes'] ?? [] as $item) {
                $fase = empty($item['fim']) ? 'abertura' : 'fechamento';
                if (!in_array($item[$fase]['estado'] ?? '', ['pendente','confirmacao_central'], true)) continue;
                if (isset($item['central'])) {
                    // Acerta o fechamento anterior antes de publicar outra abertura do mesmo recurso.
                    if (!self::publicar($item,$fase)) return;
                } elseif ($fase === 'fechamento') {
                    if (!self::recuperar_legado($item)) return;
                }
            }
        } finally {
            self::$acompanhando = false;
            F3Base_Pipedrive_Fila::liberar_linha('captacao-alerta');
        }
    }
    public static function conferir_agenda_1(): void {F3Base_Recuperacao::executar(static fn()=>self::reavaliar());}
}
