<?php
/** Canal exclusivo de alertas operacionais. A reserva/deduplicação pertence ao chamador. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Alertas_Operacionais {
    const POLITICA='avisos-tecnicos/3';

    private const IMEDIATOS = [
        'autorizacao_recusada', 'credencial_invalida', 'credencial_recusada',
        'concessao_revogada', 'destino_tecnico_ausente', 'site_fora_do_ar',
    ];

    public static function catalogo(array $c): array {
        $rotulos = [
            'estrutura_ausente'=>'Estrutura do banco ausente', 'captacao_meta_indisponivel'=>'Captação da Meta indisponível',
            'agenda_parada'=>'Agenda parada', 'autorizacao_recusada'=>'Autorização recusada',
            'credencial_invalida'=>'Credencial inválida', 'credencial_recusada'=>'Credencial recusada',
            'concessao_revogada'=>'Concessão revogada', 'site_fora_do_ar'=>'Site fora do ar', 'token_vencendo'=>'Token perto do vencimento',
            'refresh_vencendo'=>'Token de renovação perto do vencimento', 'prova_vencendo'=>'Prova de conversão perto do vencimento',
            'renovacao_falhou'=>'Falha na renovação', 'graph_vencendo'=>'Versão da Graph API perto do vencimento',
            'canal_indisponivel'=>'Canal indisponível', 'integracao_indisponivel'=>'Integração indisponível',
            'cron_sem_passagem'=>'Cron sem execução', 'could_not_set'=>'Falha ao agendar evento',
            'destino_tecnico_ausente'=>'Destino técnico ausente',
        ];
        $carencias = [];
        $campos_carencia = [];
        foreach (F3Base_Incidentes::CODIGOS as $codigo) {
            $minutos = in_array($codigo, self::IMEDIATOS, true) ? 0 : 30;
            $carencias[$codigo] = $minutos;
            $campos_carencia[$codigo] = ['type'=>'integer', 'minimum'=>0, 'maximum'=>10080, 'default'=>$minutos, 'title'=>$rotulos[$codigo] ?? $codigo];
        }
        $defaults = [
            'email'=>'', 'antecedencia_dias'=>14, 'resumo_diario'=>false, 'atraso_minutos'=>60,
            'imap_falhas_consecutivas'=>3, 'imap_sem_leitura_minutos'=>20,
            'imap_codigos_passageiros'=>['imap_resposta_incompleta','imap_transporte_indisponivel','imap_tempo_esgotado','imap_tls_interrompido','imap_dns_indisponivel','imap_prazo_excedido','imap_escrita_incompleta','imap_literal_incompleto'],
            'robots_sem_confirmacao_minutos'=>120,
            'carencia_por_codigo_minutos'=>$carencias, 'janela_agrupamento_horas'=>24,
        ];
        $props = [
            'email'=>['type'=>'string','maxLength'=>254,'description'=>'Vazio mantém os novos incidentes aguardando configuração. Destino técnico independente de avisos de contato.'],
            'atraso_minutos'=>['type'=>'integer','minimum'=>60,'maximum'=>1440,'description'=>'Sem erro, aguarda este prazo desde a última leitura completa; padrão 60 minutos.'],
            'antecedencia_dias'=>['type'=>'integer','minimum'=>1,'maximum'=>365,'description'=>'Dias de antecedência para credenciais e Graph API. Provas de conversão usam a duração e a agenda informadas pelo Google.'],
            'resumo_diario'=>['type'=>'boolean','description'=>'Enviar uma vez por dia os incidentes que continuam abertos, no fuso do site.'],
            'imap_falhas_consecutivas'=>['type'=>'integer','minimum'=>1,'maximum'=>100,'description'=>'Falhas IMAP passageiras consecutivas antes do aviso; padrão 3.'],
            'imap_sem_leitura_minutos'=>['type'=>'integer','minimum'=>1,'maximum'=>1440,'description'=>'Minutos sem leitura completa para avisar falhas IMAP passageiras; padrão 20. Basta um dos dois limites.'],
            'imap_codigos_passageiros'=>['type'=>'array','maxItems'=>50,'uniqueItems'=>true,'items'=>['type'=>'string','pattern'=>'^imap_[a-z0-9_]{1,80}$'],'description'=>'Códigos IMAP que aguardam os limites de persistência. Autenticação recusada, pasta ausente e credencial vazia sempre exigem ação imediata.'],
            'robots_sem_confirmacao_minutos'=>['type'=>'integer','minimum'=>15,'maximum'=>1440,'description'=>'Prazo de retomada sem confirmação HTTP antes de avisar; padrão 120 minutos.'],
            'carencia_por_codigo_minutos'=>[
                'type'=>'object','properties'=>$campos_carencia,'additionalProperties'=>false,
                'description'=>'Minutos que o incidente deve permanecer aberto para gerar e-mail. Zero permite a abertura imediata. Cada código omitido recebe seu prazo padrão.',
            ],
            'janela_agrupamento_horas'=>[
                'type'=>'integer','minimum'=>0,'maximum'=>720,'default'=>24,
                'description'=>'Prazo para reunir episódios repetidos do mesmo pacote, código e recurso. O padrão é 24 horas. Zero desativa o agrupamento.',
            ],
        ];
        $validar = static function ($v) use ($props) {
            $r = rest_validate_value_from_schema($v, ['type'=>'object','additionalProperties'=>false,'properties'=>$props]);
            if (is_wp_error($r)) { return $r->get_error_message(); }
            if (isset($v['janela_agrupamento_horas']) && !is_int($v['janela_agrupamento_horas'])) {
                return 'Informe a janela de agrupamento em horas inteiras.';
            }
            if (isset($v['carencia_por_codigo_minutos'])) {
                if (!is_array($v['carencia_por_codigo_minutos'])) { return 'Informe um objeto com um prazo por código.'; }
                foreach ($v['carencia_por_codigo_minutos'] as $minutos) {
                    if (!is_int($minutos)) { return 'Informe a carência de cada código em minutos inteiros.'; }
                }
            }
            return isset($v['email']) && $v['email'] !== '' && !is_email($v['email']) ? 'E-mail técnico inválido.' : '';
        };
        $c['f3base_avisos_tecnicos'] = F3Base_Conversas::catalogo_grupo('f3base_avisos_tecnicos','Avisos técnicos por e-mail',$defaults,$props,$validar);
        $c['f3base_avisos_tecnicos']['sanitiza'] = static function ($valor) use ($defaults,$carencias) {
            $cfg = array_replace($defaults, is_array($valor) ? $valor : []);
            $por_codigo = $cfg['carencia_por_codigo_minutos'];
            $cfg['carencia_por_codigo_minutos'] = array_replace($carencias, is_array($por_codigo) ? array_intersect_key($por_codigo,$carencias) : []);
            return $cfg;
        };
        $c['f3base_avisos_tecnicos']['descricao'] = 'Escolha o destino de e-mail, a carência de abertura por código e a janela de agrupamento dos incidentes técnicos. Recuperações dentro da carência ficam no histórico. IMAP e entrega de robots têm prazos próprios.';
        return $c;
    }

    public static function carencia_minutos(string $codigo): int {
        $cfg = F3Base_Options::ler('f3base_avisos_tecnicos');
        return (int) ($cfg['carencia_por_codigo_minutos'][$codigo] ?? (in_array($codigo,self::IMEDIATOS,true) ? 0 : 30));
    }
    public static function janela_agrupamento_horas(): int {
        return (int) (F3Base_Options::ler('f3base_avisos_tecnicos')['janela_agrupamento_horas'] ?? 24);
    }

    public static function resumo(): array {
        $c=F3Base_Options::ler('f3base_avisos_tecnicos');
        return ['canal'=>'email','destinatario'=>self::destinatario(),'antecedencia_dias'=>$c['antecedencia_dias']??14,
            'resumo_diario'=>$c['resumo_diario']??false, 'contrato_incidentes'=>'incidentes/1','leitura'=>'f3base/incidentes-tecnicos-ler',
            'atraso_minutos'=>$c['atraso_minutos']??60, 'primeiro_erro'=>'carencia_por_codigo',
            'carencia_por_codigo_minutos'=>$c['carencia_por_codigo_minutos'],'janela_agrupamento_horas'=>$c['janela_agrupamento_horas'],
            'robots_sem_confirmacao_minutos'=>$c['robots_sem_confirmacao_minutos'],'imap_falhas_consecutivas'=>$c['imap_falhas_consecutivas'],
            'imap_sem_leitura_minutos'=>$c['imap_sem_leitura_minutos'],'recuperacao'=>'somente_apos_atencao_aceita','origem'=>'f3base/config-core-ler: f3base_avisos_tecnicos'];
    }
    public static function destinatario(): string {
        $c=F3Base_Options::ler('f3base_avisos_tecnicos');$v=$c['email']??'';return is_string($v)&&is_email($v)?$v:'';
    }
    public static function enviar(string $titulo,string $texto,bool $teste=false): array {
        $r=array('politica'=>self::POLITICA,'canal'=>'email','recebimento'=>'nao_comprovado','em'=>time());
        if($teste&&F3Base_Testes::politica('email','teste')==='suprimir'){return $r+array('estado'=>'suprimido_teste','ok'=>true);}
        $to=self::destinatario();if($to===''){return $r+array('estado'=>'sem_destinatarios','codigo'=>'destino_tecnico_ausente','ok'=>false);}
        try{$ok=wp_mail($to,($teste?'[TESTE] ':'').$titulo,$texto,array('Content-Type: text/plain; charset=UTF-8'));
            return $r+array('ok'=>$ok,'estado'=>$ok?'processado':'falhou','codigo'=>$ok?'aceito_wp_mail':'envio_recusado');
        }catch(Throwable $e){return $r+array('ok'=>false,'estado'=>'incerto','codigo'=>'envio_sem_confirmacao');}
    }
}
