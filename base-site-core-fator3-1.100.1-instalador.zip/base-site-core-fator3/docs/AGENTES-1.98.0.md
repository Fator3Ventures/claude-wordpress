# Operação do Site Core 1.98.0

Consulte DOCUMENTACAO.md e RELEASE-1.98.0.md. Em f3base/como-usar, confira a versão e a confirmação da instalação no executor. Para o pedido 438, compare as ofertas em f3base/schema-verificar com os nós Offer no HTML servido do permalink cadastrado. OFERTAS.md descreve a prova por cartão, as causas de pendência e a janela de revalidação.
