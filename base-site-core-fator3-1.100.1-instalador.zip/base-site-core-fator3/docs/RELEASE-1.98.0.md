# Fator3 Site Core 1.98.0

Instalação nova ou atualização direta da 1.97.2. WordPress 7.1.4 ou superior, PHP de 64 bits a partir de 8.3. Contrato de configuração 8.46.0.

## Pedidos core 438 · Publicação das ofertas

A primeira leitura pública verifica, no mesmo cartão, o nome, o preço, a moeda e o período cadastrados. Uma prova válida com o estado `verificacao_pendente` já habilita a emissão. Na renderização seguinte, o Core monta o grafo do Yoast com as provas vigentes e imprime o marcador das ofertas emitidas. Uma nova leitura do HTML verifica o conteúdo visível, o nó completo e a assinatura do Core. Cada oferta confirmada passa a `publicada`, com `emissor_confirmado=true`.

O Core solicita a atualização do cache da página quando a elegibilidade muda e agenda a releitura para cerca de 60 segundos. Se o HTML continuar antigo, uma pendência estável volta a solicitar a limpeza após cinco minutos. O tempo até a confirmação depende do executor WordPress e da atualização do cache de página. O cache interno continua ativo para páginas sem ofertas cadastradas.

Um HTTP 403 na consulta ao LinkedIn afeta o diagnóstico de `sameAs`. A emissão das ofertas usa a prova do cartão e a presença do emissor de schema na página. A verificação global pode continuar inconclusiva depois da publicação das ofertas.

Consulte OFERTAS.md para as regras de validade e conflito. Em `f3base/schema-verificar`, use `acao=consultar` e confira cada item em `ofertas.itens`. Para iniciar uma verificação, use `acao=verificar_publico`, o permalink da página e a revisão vigente de `f3base_seo_entidade`. Confira o HTML servido aos visitantes com `system/probe` em modo `served`.

## Integrações

O MCP 0.52.0 passou a exibir os incidentes de cron dos pacotes em `system/health`, no campo `incidents_24h.pacotes_fator3`. O Core preserva o filtro entregue na 1.97.2. O pedido 438 altera apenas a produção e a verificação do grafo pelo Core.
