# Site Core 1.96.0

Instalação limpa ou migração direta da 1.95.0. Requer WordPress 7.1.4 ou superior e PHP de 64 bits a partir de 8.3. O contrato de configuração é 8.45.0.

## Pedido Core 431 · prova de conversão

O coletor percorre todas as conexões e os destinos de prova informados pelo Google. Para uma prova com prazo, o aviso pode abrir no último quarto da validade. Se a renovação normal foi agendada para mais tarde, o Core espera até esse horário. Em uma prova de 24 horas com renovação após 12 horas, o aviso abre seis horas antes do vencimento se a prova continuar sem renovação. Uma retentativa agendada após falha não adia o alerta. O prazo de credenciais e da Graph API continua seguindo a opção de antecedência em dias.

O Google 0.39.0 mantém a prova Ads até recusa. Uma prova sem vencimento recupera o aviso anterior, inclusive quando uma data antiga ainda está gravada no produtor da prova Ads. A falha de renovação tem incidente próprio. Dados de prova ausentes ou ilegíveis não bastam para concluir que uma falha se resolveu. O aviso de prazo acompanha a data da prova. A prontidão para enviar segue a capacidade declarada pelo fornecedor, inclusive durante uma falha transitória do GA4.

Na primeira coleta aplicável após atualizar, cada aviso indevido passa a recuperado na sua referência original. A transição entra uma vez na fila de e-mail técnico. Destino vazio ou reserva incerta continuam sujeitos à política de entrega do site. Consulte os detalhes em f3base/incidentes-tecnicos-ler. No caso do CTO Office, confira os dois recursos de conversão depois da troca e acompanhe novas transições por 72 horas.

## Pedidos Google 57 e 58 · filas de Ads

Aquisição e etapas comerciais podem reapresentar a mesma transação vinculada quando o adaptador devolve ads_retry_same_transaction. Uma recusa de ação, termos, autorização ou destino precisa trazer confirmação explícita de não entrega. A próxima tentativa revalida elegibilidade, consentimento, idade do clique, prontidão e referência do destino. Nas etapas, também confere ação, etapa e revisão da configuração. Recibos pendentes e resultados incertos sem autorização expressa seguem para consulta do recibo.

Essas tentativas recuperáveis preservam o orçamento da aquisição. Para etapas Ads, a janela é de até 90 dias, sujeita à validade do clique. As etapas LinkedIn mantêm sete dias. O Core aguarda ao menos cinco minutos para reavaliar etapas Ads bloqueadas pelos motivos previstos. Uma linha antiga com limite esgotado e sem código que comprove reenvio seguro continua exigindo análise. Para consultar o resultado de um registro, use f3base/conversoes-entregas-ler.

## Como conferir

Consulte f3base/como-usar com compacto=true e confira versao_alvo 1.96.0, estado concluida, falhas 0 e confirmada_no_executor_em preenchido. Leia esta nota por f3base/documentacao-ler. A capacidade administrativa existente protege a leitura dos incidentes e as ferramentas de operação. O destino técnico fica em Site Core → Avisos técnicos por e-mail. A atualização reutiliza as credenciais configuradas.
