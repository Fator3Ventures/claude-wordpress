# Contratos do Fator3 Site Core

## Contrato 8.47.0

A opção f3base_avisos_tecnicos aceita carência por código e janela de agrupamento. Cada incidente expõe o histórico das fases enviadas. O contrato local f3base_incidente_acesso_encerrar_v1 atende aos estados administrativos do Google 0.41.0. A descrição das transições e da configuração está em RELEASE-1.99.0.md.

## Operação e cron na 1.97.1

A resposta de f3base/como-usar mantém cobertura e acrescenta prefixos_cobertos em agenda_das_filas. A validação da geração Markdown usa a mesma identidade do preparo.

## Contrato 8.46.0

A configuração f3base_formularios_sinais inclui as regras da caixa. O cursor da leitura integrada é opaco, vinculado ao usuário, ao site e aos filtros. Consulte RELEASE-1.97.0.md.

Consulte RELEASE-1.96.0.md para o vencimento das provas de conversão e a retentativa de entregas Ads.

A operação da agenda, do catálogo e da central está documentada em RELEASE-1.93.0.md.

## Catálogo de aparelhos

A revisão `2026-11-17.3` reconhece nomes comerciais ignorando caixa, espaços e parênteses. O detalhe da sessão devolve a ficha em `sessoes[]`.

A base comercial de 17/11/2026 cobre 1.352 códigos. Os preços são referências em reais para a data da pesquisa. A faixa representa a posição do produto na linha do fabricante. O indicador de linha premium segue a família comercial.

Em Site Core, abra a configuração de Conteúdo, audiência e IA e procure **Catálogo local de aparelhos**. Para ajustar a faixa, use uma linha como `Galaxy A07 4G=entrada`. Para acrescentar ou corrigir um aparelho, use `CODIGO-EXEMPLO=Marca|Modelo exemplo|2025|1199.90|intermediário|não`. Cada chave aparece uma vez. A correção por código tem prioridade. Quando a faixa vem de um nome local, ela prevalece sobre o padrão embarcado. Simule a alteração e confira a revisão antes de confirmar.

Em `f3base/como-usar`, confira `catalogo_aparelhos.data`. Com `manage_options`, use `f3base/aparelhos-sem-nome-ler` com limite 1 a 200. Passe `proximo_apos` como `apos` na próxima leitura até ele ser nulo, inclusive se a página não trouxer itens. A leitura agrega os perfis retidos por código. As observações novas guardam a ficha consultada. As antigas são enriquecidas na leitura enquanto o dado bruto estiver retido.

O Slack mostra o nome, o ano, o preço arredondado em reais e a indicação de linha premium quando aplicável. Para um código desconhecido, exibe “nome comercial não identificado”. Tela, DPR e faixa acompanham o modelo. O CSV de sessões e os filtros de medição preservam os dados técnicos e permitem consultar ano, preço e linha premium. O catálogo do pacote funciona inteiramente no servidor.


Contrato administrativo 8.45.0 (`F3Base_Config_Contrato::VERSAO`). Perfil de configuração canônico `piso-padrao-3.6` (`F3Base_Config_Perfil::ID`); o código também aceita os perfis 3.2 a 3.5. Provider `base-site-core-fator3`, prefixo de abilities `f3base/`. Base de atualização vigente: 1.92.0.

## Onde estão os schemas

- Todas as abilities, com schema de entrada e saída: `docs/dados/abilities-*.json` e o catálogo MCP (`get-ability-info`). Lista por domínio, com leitura ou escrita e parâmetros obrigatórios: REFERENCIA-ABILITIES.md.
- Chaves de configuração: `docs/dados/configuracao-schema.json`. Ajuda por campo: `docs/dados/ajuda-opcoes.json`.
- Metadados de dados (retenção, granularidade, vínculos): `docs/dados/contrato.json`. Colunas das tabelas: DICIONARIO-DADOS.md.
- Schemas de conversão e medição: pasta `docs/schemas/`.

## Configuração do Core

- `f3base/config-core-ler` devolve valores operáveis, revisão opaca, origem e schema; segredos saem mascarados.
- `f3base/config-core-escrever` simula por padrão e exige a revisão lida (`revisao_esperada`). `mesclar=true` permite alteração parcial tipada de opções compostas.
- A resposta traz `persisted`, `effect` e `verification` como informações distintas; `ok` existe por compatibilidade.
- Operações por caminho (JSON Pointer, até 50 por chamada, caminho de até 500 caracteres): `definir`, `remover`, `acrescentar` e `remover_de_lista`.
- `f3base/config-core-contrato-v1` devolve o catálogo versionado: tipos, limites, padrões, revisão, dependências e operações permitidas.
- Se o Core recusa uma gravação, a recusa não autoriza escrita direta da opção nem alteração do tema.

## Fronteiras com outros pacotes

Cada contrato abaixo aparece como constante no código do Core. A tabela diz o que o Core declara; a versão do pacote acompanhante e a concessão de cada ação são conferidas no próprio acompanhante.

| Fronteira | Contrato (constante no código) |
| --- | --- |
| MCP | `server-integration/1.0.0` (`F3Base_Companheiros::MCP_CONTRATO`). O Core registra o provider `base-site-core-fator3` com o prefixo `f3base/` quando o MCP compatível está presente. |
| Search Console | `search-console-reader/1.0.0` |
| GA4 | `ga4-reader/1.0.0` |
| Contexto de medição | `site-measurement-context/1.0.0`; ver MEDICAO-SDK-1.33.md |
| Conversões por finalidade | `site-conversion-purposes/1.0.0`; ver CONVERSOES-SDK-1.36.md |
| Conversões pelo servidor | `site-conversion-delivery/1.0.0` (`F3Base_Conversoes_Servidor::CONTRATO`) |
| Conversão Google | `site-conversion-delivery/1.1.0` (`F3Base_Google_Conversoes::CONTRACT`) |
| Retorno de etapa comercial | `site-conversion-delivery/1.2.0` (`F3Base_Qualidade_Destinos::CONTRACT`), consumidor `site-core-quality`, propósito `crm_stage`; ver QUALIDADE-DESTINOS-1.58.md |
| Reconciliação comercial | `site-stage-conversion-reconcile/1.0.0` (`F3Base_Qualidade_Destinos::RECONCILE`), método `reconcileBound`; ver RECONCILIACAO-COMERCIAL-1.59.md |
| Instagram | `instagram-first-message/1.0.0` e `instagram-message-erasure/1.0.0` |
| Meta Ads | `meta-ads-reader/1.0.0`; monitoramento `meta-ads-monitoring/1.0.0` |
| Pipedrive | `pipedrive-api-client/1.0.0`; o Core guarda token, orçamento e limites; ver PIPEDRIVE-OPERACAO.md |

O Core descobre os acompanhantes por contrato registrado (`F3Base_Consumidores::descobrir`), não pelo número de versão.

## Ponte do implantador

`f3base/config-ler` e `f3base/config-escrever` operam os JSONs do implantador (`config/projeto.json` e `config/site.json`) por `F3Base_Implantador_Adaptador`. As respostas trazem `scope: installer_json` e `site_config_applied: false`: a ponte não aplica configuração no site.

## Reenvio e resultado incerto

Abilities de reenvio simulam ou mostram prévia. Quando o resultado anterior é incerto, o reenvio de aviso ou de resposta ao visitante exige aceite explícito de duplicação (`f3base/avisos-reenviar`, `f3base/leads-resposta-reenviar`). Para outras filas, reconcilie antes de repetir (`f3base/pipedrive-reconciliar`, `f3base/avisos-parte-reconciliar`, `f3base/capi-reconciliar`).

## Códigos de recuperação

A guarda usa `wp-content/f3-core-state/`: `site-N.php` é a sentinela, `site-N-state.php` a barreira, `site-N-workers.php` a coordenação de entradas e `site-N-task-<tarefa>.php` a reserva de cada tarefa. Interprete a resposta pelo código, pelo estado e pela precondição atuais. O procedimento está em OPERACAO-E-RECUPERACAO.md.

| Grupo | Código | Significado | Ação |
| --- | --- | --- | --- |
| Estado da guarda | `core_operacional` | Sentinela válida, sem pausa e sem falha de trava | Nenhuma |
| Estado da guarda | `core_pausado` | Sentinela com `pausado: true`; tarefas e mutações paradas | Reconciliar e chamar `retomar` |
| Estado da guarda | `trava_inacessivel` | `site-N-workers.php` é link simbólico ou não abre | Corrigir dono e permissão; se persistir, `recriar` |
| Estado da guarda | `trava_ocupada` | Outra operação segura a trava exclusiva | Aguardar e repetir |
| Estado da guarda | `trava_falhou` | `flock` falhou sem indicar bloqueio | Conferir o sistema de arquivos; depois `recriar` |
| Estado da guarda | `sentinela_ausente` | `site-N.php` não existe | `recriar` com `precondicao_esperada` e as confirmações |
| Estado da guarda | `sentinela_ilegivel` | Não é arquivo regular ou a leitura falhou | Corrigir tipo e permissão; depois `recriar` |
| Estado da guarda | `sentinela_invalida` | Conteúdo sem o cabeçalho ou sem `geracao` e `pausado` | `recriar` |
| Estado da guarda | `sentinela_link_recusado` | `site-N.php` é link simbólico | Remover o link; depois `recriar` |
| Estado da guarda | `diretorio_sentinela_link_recusado` | A pasta é link simbólico | Trocar por pasta real |
| Estado da guarda | `diretorio_sentinela_indisponivel` | Pasta ausente, ilegível ou impossível de criar | Criar a pasta ou corrigir a permissão |
| Estado da guarda | `indice_protetor_link_recusado` | `index.php` da pasta é link simbólico | Remover o link; a provisão recria o índice |
| Proteção em disco | `indice_protetor_confirmado` | `index.php` com o conteúdo esperado | Nenhuma |
| Proteção em disco | `indice_protetor_indisponivel` | `index.php` ausente ou ilegível; não pausa | Corrigir a permissão |
| Proteção em disco | `indice_protetor_divergente` | Conteúdo diferente; não é sobrescrito e não pausa | Repor o conteúdo esperado |
| Entrada da requisição | `nao_tentada` | Nenhuma tarefa protegida tentou entrar | Nenhuma |
| Entrada da requisição | `entrada_confirmada` | Entrada aceita com trava compartilhada | Nenhuma |
| Respostas da operação | `core_em_recuperacao` | Chamada protegida recusada pela guarda | Ler `recuperacao` na resposta |
| Respostas da operação | `sem_permissao` | Sem `manage_options` e fora do WP-CLI | Usar conta administradora |
| Respostas da operação | `geracao_invalida` | `geracao_esperada` ausente ou não inteira | Ler o estado e enviar `geracao` |
| Respostas da operação | `geracao_divergente` | Geração diferente da enviada | Reler e repetir |
| Respostas da operação | `acao_invalida` | `acao` fora de `preparar`, `retomar`, `recriar` | Corrigir a chamada |
| Respostas da operação | `reconciliacao_externa_nao_confirmada` | `retomar` sem `reconciliacao_confirmada` | Reconciliar e confirmar |
| Respostas da operação | `barreira_ocupada` | Outra operação de recuperação em curso | Aguardar e repetir |
| Respostas da operação | `barreira_nao_persistida` | `preparar` não gravou a pausa | Conferir escrita na pasta |
| Respostas da operação | `aguardando_drenagem` | Há trabalho em voo | Repetir a mesma chamada até `core_drenado` |
| Respostas da operação | `core_drenado` | Pausado, sem trabalho em voo | Restaurar preservando a pasta |
| Respostas da operação | `core_retomado` | Geração incrementada, filas invalidadas | Reconciliar os itens suspensos e incertos |
| Respostas da operação | `ja_retomado` | O Core já estava sem pausa | Nenhuma |
| Respostas da operação | `trava_link_recusado` | Arquivo de estado ou de workers é link | Remover o link |
| Respostas da operação | `sentinela_gravacao_falhou` | A sentinela não foi gravada | Conferir escrita e espaço em disco |
| Respostas da operação | `sentinela_existente` | `recriar` recusado: a sentinela é válida | Usar `preparar` ou `retomar` |
| Respostas da operação | `confirmacao_recriacao_necessaria` | Falta `reconciliacao_confirmada` ou `copia_outro_host` | Enviar os dois campos |
| Respostas da operação | `precondicao_divergente` | A sentinela mudou desde a leitura | Reler `precondicao` e repetir |
| Respostas da operação | `identidade_nao_persistida` | Identidade nova do Pipedrive não gravou | Repetir `recriar` |
| Respostas da operação | `sentinela_recriada` | Nova geração gravada; filas suspensas | Reconciliar; com `manter_pausado`, `retomar` depois |
| Invalidação de filas | `inventario_recuperacao_falhou` | Contagem prévia de uma fila falhou | Corrigir o banco e repetir a ação |
| Invalidação de filas | `fila_nao_suspensa` | Fila da Meta ou do Pipedrive não foi suspensa | Idem |
| Invalidação de filas | `avisos_nao_suspensos` | Avisos de contato não foram marcados | Idem |
| Invalidação de filas | `intencoes_nao_suspensas` | Marca das entregas ao Pipedrive não gravou | Idem |
| Invalidação de filas | `eliminacoes_nao_suspensas` | Eliminações remotas não foram suspensas | Idem |
| Invalidação de filas | `alertas_nao_suspensos` | Alertas de entrega não foram marcados | Idem |
| Invalidação de filas | `alerta_conta_nao_suspenso` | Alerta de conta não foi marcado | Idem |
| Invalidação de filas | `cursor_nao_invalidado` | Cursor do Search Console não foi invalidado | Idem |
| Invalidação de filas | `reservas_nao_invalidadas` | Reservas do executor não foram zeradas | Idem |
| Invalidação de filas | `intencoes_nao_invalidadas` | Intenções pendentes não passaram a `suspensa` | Idem |
| Reserva de tarefa | `reserva_indisponivel` | Arquivo de tarefa como link simbólico | Conferir o arquivo de tarefa |
| Reserva de tarefa | `trava_arquivo_inacessivel` | Arquivo de tarefa não abre para escrita | Corrigir a permissão |
| Reserva de tarefa | `reserva_ocupada` | Outra execução da mesma tarefa em curso | Aguardar |
| Reserva de tarefa | `trava_arquivo_falhou` | `flock` do arquivo de tarefa falhou | Conferir o sistema de arquivos |
| Marcas nos dados | `restauracao_requer_reconciliacao` | Item suspenso ou incerto por retomada ou recriação | Reconciliar no módulo dono antes de reenviar |
| Marcas nos dados | `copia_requer_verificacao` | Site copiado de outro host | Verificar a integração |
| Entrada da requisição | `protecao_degradada` | Módulos de atendimento subiram, mas tarefas e gravações protegidas estão bloqueadas | Corrigir dono, permissão e arquivo de coordenação |
| Retirada de URL | `caminho_nao_retirado` | Foi solicitada restauração de um caminho sem retirada prévia; nenhuma escrita ocorreu | Confira a operação desejada e o histórico do caminho |

## Histórico

As seções abaixo vêm da versão anterior deste documento. Descrevem versões de 1.35.0 a 1.59.0 e não foram reconferidas contra o código da 1.80.0. Não use como instrução vigente. Também saíram do texto vigente: a matriz de versões dos pacotes acompanhantes (MCP 0.31 a 0.34, Google 0.19 a 0.22, LinkedIn 0.10 a 0.12, Meta 0.10 a 0.13, Pipedrive 0.3), a interface `linkedin-lead-reader/1.0.0` e o código `service_record_unconfirmed`, que não constam do código do Core. Uma ability de reparo de procedência, citada nas versões anteriores como retirada, não consta do registro.

## Alterações 1.35.0

Leia CONVERSOES-CONTEUDO-1.35.md. Instalação nova ou base 1.34.0; mínimos WP 7.1.2/PHP 8.3.6 64 bits. Contrato administrativo 8.3.0; SDK 1.0.0 fechado sem material. Reserva editorial adaptativa, equivalência Slack por blocos exibidos, rótulos Meta em texto CRM e tela de conexões corrigida. Migração de reservas e suspensão de Lead legado de material; sem reenvio ou correção retroativa.


## Atualização 1.53.0

Pedidos 299–301 e contrato 8.18.0: EMAIL-SITE-1.53.md documenta caixa, cinco abilities, tabela, retenção e restauração; FORMULARIOS-SINAIS-1.53.md documenta a quarta isca e a política de suspeita/aviso. RELEASE-1.57.1.md reúne as mudanças. A configuração de unidade Pipedrive é obrigatória para reutilizar ou criar oportunidade.

## Atualização 1.54.0

Pedido 302, contrato 8.19.0: CONTATOS-EXTERNOS-1.54.md; duas abilities novas, atribuição manual auditada, filtro em conteúdo/canais e índice f3base_contato_sessoes. Capacidades exatas nas abilities de e-mail publicadas ao MCP. Sem novas conversões, avisos ou e-mails automáticos.

## Atualização 1.57.1

Contrato 8.22.1: f3base_sessao_admin_dias, mx_confiaveis e remetentes_teste; email-caixa-verificar aceita simular (padrão true) e aplicação cria pastas; saúde acrescenta prova_publica e motivos. Nenhuma ability nova. Sem mudança no cliente Pipedrive ou no MCP. OPERACAO-1.55.md descreve entrada, estados, limites e recuperação.

## Perfis de aparelho em sessões

Na listagem e no CSV de sessões, `rede_efetiva` conserva a rede informada pelo navegador (por exemplo, `4g`). O campo `rede` continua com a classificação de rede do servidor. O parâmetro de filtro `rede` continua aceitando a rede efetiva.
