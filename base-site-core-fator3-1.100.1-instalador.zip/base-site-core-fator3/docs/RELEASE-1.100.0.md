# Fator3 Site Core 1.100.0

A versão atualiza a administração do Site Core segundo o Guia visual Fator3 de 20/11/2026. Aceita instalação nova ou atualização direta da 1.99.0. Requer WordPress 7.1.4 ou superior e PHP 8.3 ou superior de 64 bits, em instalação única.

## Navegação

| Grupo | Como usar |
|---|---|
| Configurações | Escolha a área sob o cabeçalho. Em **Conexões e entregas**, abra o cartão da integração. Use **Voltar** para retornar ao índice. O nome de cada campo fica junto ao controle e a ajuda vem em seguida. |
| Contatos | Alterne entre Contatos, Formulários e Conteúdo privado. As visões Contatos, Testes e Lixeira ficam no cartão da lista. A busca e a paginação permitem localizar registros, formulários e materiais. |
| Medição | As nove áreas aparecem em dois conjuntos. As análises de uma área ficam no cartão de filtros. Quando há mais de cinco, use o seletor **Análise**. |
| Operação | Consulte Execuções, Entregas ao Pipedrive ou Avisos à equipe. As listas permitem filtrar por referência, tarefa, estado ou código, conforme a fila. O intervalo mostra a posição da página no resultado filtrado. |
| Informações técnicas | Use o índice para localizar uma seção. Expanda o título para consultar os detalhes ou executar a ação identificada. |

Os grupos respeitam as capacidades administrativas de cada página. O menu lateral do WordPress e os endereços salvos continuam disponíveis. Os links das abas funcionam com o JavaScript desativado. O endereço antigo de Operação encaminha para a entrada própria. Nas tabelas largas, a rolagem fica dentro da tabela. A versão acompanha o cabeçalho, e o destaque acompanha o esquema de cores do administrador.

## Configuração, contrato e prontidão

O contrato do Core é 8.47.0 e o perfil é `piso-padrao-3.6`. Esta rodada mantém as opções, as abilities, as permissões e os registros da instalação. As novas buscas no painel de Operação são leituras. O painel não aciona o transporte de e-mail nem executa as filas ao filtrar.

O MCP 0.54.0 entrega o inteiro `token_vencendo` na consulta da opção explicitamente nomeada `f3base_avisos_tecnicos`. Com `f3base/config-core-ler`, informe o caminho `/carencia_por_codigo_minutos/token_vencendo` para ler a duração configurada. O Google 0.42.0 utiliza o contrato de encerramento administrativo de acessos incorporado na 1.99.0 e cuida da paginação de sua própria fila de avisos.

Depois da instalação, consulte `f3base/como-usar` com `compacto=true`. A troca terminou quando `atualizacao.versao_alvo` for `1.100.0`, `estado` for `concluida`, `falhas` for zero e `confirmada_no_executor_em` tiver sido preenchido. O executor conclui o ciclo conforme sua cadência. Consulte `f3base/saude-ler` para a lista de etapas.

## Aparência e ajuda local

A folha compartilhada `assets/f3-ui.css` é a versão 1.0.0 e tem SHA-256 `15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b`. A folha específica do Core é carregada em seguida nas páginas do pacote. Para consultar as instruções pelo MCP, leia `docs/GUIA-PAINEL.md` com `f3base/documentacao-ler`. A operação exige acesso administrativo.
