# Operação do Site Core 1.97.1

Leia DOCUMENTACAO.md e RELEASE-1.97.1.md. Verifique a versão e as etapas em f3base/como-usar. Confira o registro específico em f3base/conversoes-entregas-ler, os trabalhadores em f3base/execucoes-ler e o histórico em f3base/incidentes-tecnicos-ler. Para relatórios com proximo_cursor, repita os filtros e avance até o fim. Para conteúdo público, confira a representação Markdown no permalink e leia os avisos de cada item na cobertura. Revise a política email_suspeito em f3base_formularios_sinais antes de aprovar um contato no painel.
