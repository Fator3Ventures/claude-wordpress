# Operação do Fator3 Site Core 1.100.0

Comece por DOCUMENTACAO.md e RELEASE-1.100.0.md. A rota `f3base/como-usar` e a leitura das etapas em `f3base/saude-ler` identificam a conclusão da atualização. A documentação completa pode ser lida com `f3base/documentacao-ler` passando `arquivo`, `linha` e `limite`. Siga `proxima_linha` e confira o SHA-256 comum a todas as páginas.

No wp-admin, cada grupo identifica a área atual. Em Operação, filtre os registros antes de abrir os detalhes de uma ação. Em Configurações, abra o cartão da conexão para ler a configuração e conferir o resultado. A leitura da política de incidentes também funciona pelo MCP 0.54.0. Use a revisão devolvida em `f3base/config-core-ler` para simular e confirmar alterações pelo contrato 8.47.0. A carência, a janela de agrupamento e a reconciliação mantêm o comportamento descrito em RELEASE-1.99.0.md.
