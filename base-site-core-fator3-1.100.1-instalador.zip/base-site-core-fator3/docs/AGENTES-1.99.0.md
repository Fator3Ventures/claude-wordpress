# Operação do Fator3 Site Core 1.99.0

Leia DOCUMENTACAO.md e RELEASE-1.99.0.md. Em f3base/como-usar, confirme versao_alvo, estado, falhas e confirmada_no_executor_em. A leitura administrativa f3base/incidentes-tecnicos-ler permite verificar os episódios registrados e as fases de entrega. Percorra as páginas usando o cursor devolvido. A fila f3base/email-wordpress-fila-ler documenta a passagem pelo transporte local.

Para ajustar avisos, leia f3base_avisos_tecnicos em f3base/config-core-ler. Use a revisão recebida para simular a alteração em f3base/config-core-escrever, confira os campos afetados e aplique com a mesma revisão. Consulte o histórico de entrega antes de reconciliar uma reserva incerta.

No Google 0.41.0, a leitura das permissões IAM e a perda de uso de uma referência têm causas e procedimentos diferentes. Use o motivo de encerramento e a geração do acesso para interpretar o histórico.
