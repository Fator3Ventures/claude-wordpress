# Fator3 Site Core 1.99.0

Instalação nova ou atualização direta da 1.98.0. WordPress a partir de 7.1.4, PHP a partir de 8.3 de 64 bits e instalação única. Contrato de configuração 8.47.0.

## Pedidos core 439 · E-mail de incidente técnico

Na primeira observação de uma abertura, o Core guarda o instante em `observado_em`. O campo `desde` preserva a data informada pelo produtor. A carência de abertura conta a partir da observação pelo Core. Com a política padrão, uma falha de agenda recuperada em dois minutos gera um registro com a duração e zero e-mails. Se o mesmo incidente continuar aberto ao completar 30 minutos, a próxima passagem do executor pode enviar a abertura. A recuperação só entra no transporte quando existe aceite da abertura daquele episódio.

Os códigos de credencial inválida ou recusada, autorização recusada, concessão revogada, destino técnico ausente e site fora do ar começam com carência zero. A fila aguarda um endereço válido quando o destino técnico está vazio. No painel há um aviso para o administrador configurar esse endereço. Uma falha do canal de administração e uma indisponibilidade comprovada do site têm códigos separados.

A primeira abertura aceita inicia a janela de agrupamento da combinação pacote, código e referência de recurso. A recuperação desse primeiro incidente mantém seu próprio aviso. Outras aberturas que atingem a carência dentro da mesma janela contam como reincidências. Ao terminar a janela, o executor envia um resumo com a contagem das reincidências. O padrão é 24 horas. Episódios que se resolvem durante a carência ficam disponíveis para diagnóstico. O resumo diário opcional considera incidentes abertos cuja abertura já foi aceita.

O reparo automático de tabela e a captação Meta do próprio Core também publicam na central. O reparo que resolve uma falha de estrutura dentro da carência fica registrado sem e-mail. Para captação, o Core mantém os recibos específicos do coletor e reconhece a recuperação de uma abertura aceita na versão anterior.

Com o MCP Meta 0.31.0, uma falha transitória ou restrita a um ativo mantém a carência da agenda. Quando a saúde local do produtor comprova revogação ou recusa da credencial, o Core aplica a política crítica na mesma referência. A consulta não chama a Graph API.

## Configurar pelo painel ou pelo MCP

Em **Site Core → Conexões → Avisos técnicos**, ajuste os minutos de cada código e as horas da janela. A carência admite de 0 a 10.080 minutos. A janela de agrupamento admite de 0 a 720 horas. Zero horas desativa o agrupamento de novas janelas. As preferências prévias, inclusive o destino técnico e os limiares próprios de IMAP e robots.txt, são preservadas na atualização.

Para alterar apenas a carência de agenda, consulte `f3base/config-core-ler` com `nome=f3base_avisos_tecnicos`. Copie a revisão devolvida no campo `revisao_esperada` da operação `f3base/config-core-escrever`. Exemplo de simulação:

```json
{
  "nome": "f3base_avisos_tecnicos",
  "revisao_esperada": "<revisão de 64 caracteres lida no site>",
  "simular": true,
  "operacoes": [
    {"operacao": "definir", "caminho": "/carencia_por_codigo_minutos/agenda_parada", "valor": 45}
  ]
}
```

Confira os campos afetados e repita com `simular=false` para aplicar. O caminho da janela de agrupamento é `/janela_agrupamento_horas`. O prazo de atraso sem erro e a carência de abertura são preferências distintas. O primeiro participa da detecção da falha e a segunda determina quando um incidente detectado gera e-mail.

## Ler as fases de um incidente

Com acesso administrativo, consulte `f3base/incidentes-tecnicos-ler`. Para a próxima página, envie o valor de `proximo` no parâmetro `apos`. Filtre os itens retornados pelo pacote, código e referência opaca do recurso.

| Campo | Uso |
|---|---|
| `estado`, `episodio`, `codigo_carencia` | Identificam o estado atual, o episódio e a política de tempo aplicada. |
| `suprimido_por_carencia`, `duracao_segundos` | Indicam se a abertura foi suprimida e durante quanto tempo o Core observou a falha. O histórico dos episódios breves fica em `episodios_suprimidos`. |
| `fases_enviadas` | Identifica fases aceitas pelo transporte ou confirmadas por reconciliação, com episódio, instante e contagem. `ultimo_envio` conserva o resultado mais recente, inclusive uma tentativa frustrada. |
| `agrupamento` | Identifica a janela fixa ativa e a contagem das reincidências elegíveis. |
| `historico_anterior` | Indica quando só havia o último recibo da versão anterior. A versão aproveita o que esse recibo comprova. |

O aceite do transporte WordPress confirma a entrega ao remetente local. A chegada à caixa postal exige conferência própria. Se houver reserva incerta, confira a fila `f3base/email-wordpress-fila-ler` e o transporte antes de usar `f3base/incidente-entrega-reconciliar`. A reconciliação exige autorização administrativa, a referência e a reserva atuais.

## Google 0.41.0 · Fechamento de acesso

Uma referência declarada `nao_usado` ou `consolidado` pelo Google, com a mesma causa e `notify_recovery=false`, recebe encerramento administrativo silencioso. O Core guarda a causa e a geração da observação. O contrato PHP `f3base_incidente_acesso_encerrar_v1` atende à entrega pela fila do Google e à coleta periódica do Core. Uma abertura pendente que se tornou obsoleta é dispensada. Uma reserva de entrega incerta continua disponível para reconciliação. Observações atrasadas não reabrem a referência encerrada. As recusas IAM e a recuperação genuína de acesso seguem as regras de comunicação do episódio.

No Site-Teste, confira a conclusão do ciclo em `f3base/como-usar`. Para o aceite de frota, confronte os episódios da semana posterior à implantação com os recibos do transporte e com a carência configurada para cada código.
