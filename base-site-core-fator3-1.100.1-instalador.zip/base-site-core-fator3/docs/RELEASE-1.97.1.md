# Fator3 Site Core 1.97.1

Instalação nova ou atualização direta da 1.96.0 ou 1.97.0. WordPress 7.1.4+, PHP 8.3+ de 64 bits. Contrato de configuração 8.46.0.

## Correção de homologação

Em f3base/como-usar, agenda_das_filas.prefixos_cobertos lista cada prefixo atendido. O campo cobertura preserva o identificador f3base_* do contrato público. Na publicação de Markdown, a seleção, a configuração e sua assinatura são conferidas no começo e no fim do lote. Se llms-reprocessar devolver preparacao_parcial, continue a geração. Uma nova chamada retoma o cursor da geração vigente. Quando o lote termina, confira geracao_publicada, a cobertura e o texto da página.

## Conversões com GCLID · 432

Um contato elegível com um único GCLID e sem sessão pode seguir para o destino vinculado com a data de conversão do próprio contato. Quando a conciliação local localizou o clique na mesma conta e revisão, o Core verifica o dia no fuso do acervo. A leitura oficial do Google 0.40.0 tem precisão de dia. A janela é de 90 dias. Os controles de consentimento, identidade do destino e recibo continuam no executor. Um contato sem identidade GA4 recebe o motivo sem_sessao_ga4. O executor corrige até 50 diagnósticos históricos de cancelamento por passagem.

## Cron dos pacotes · 433

O Core aplica alterações pontuais à agenda, compara a versão lida do banco e tenta novamente em caso de concorrência. Na passagem CLI, a verificação chama o método de cada produtor para decidir se há trabalho e rearmar Meta ou LinkedIn. Consulte f3base/execucoes-ler para ver o gancho, a operação e a etapa onde surgiu a recusa. A central registra could_not_set por gancho e dia local, com recuperação após observar o evento novamente.

## Relatórios · 434

Use f3base/relatorios-integrados-ler com visao igual a formularios ou resumo, segmento, de e ate. Quando o volume requer continuação, a resposta identifica dia e periodo_solicitado. Repita os mesmos parâmetros e acrescente o valor de proximo_cursor. Termine quando ele for nulo. Se um dia completo exceder o orçamento, a continuação usa dia_e_pagina e identifica caminho_da_fatia. Use cursor_fatia ao mudar pagina para consultar mais linhas daquele quadro. Uma página isolada ainda acima do orçamento traz fatia_incompleta e totais nulos. O cursor avança para o restante do período. Visitantes e sessões distintos também podem se repetir entre páginas. Em cada dia, pagina e proxima_pagina continuam identificando as linhas do quadro. Cada chamada faz uma leitura dos dados retidos naquele momento. Some contagens por dia uma única vez. Uma pessoa presente em dois dias conta em ambos nos totais diários de visitantes. Para taxas, use a soma dos numeradores e denominadores. O quadro de formulários em continuação calcula os indicadores de formulário e consulta a cobertura editorial do próprio dia.

## Conteúdo público em Markdown · 435

O gerador resolve partes de modelo publicadas pelo tema e converte o HTML dos shortcodes registrados em Markdown. A renderização do shortcode usa a URL pública da página em uma requisição sem login, assinada pelo próprio site. O servidor precisa conseguir acessar seu próprio permalink. O leitor reserva até dois segundos por documento e aceita até 256 KiB por shortcode. Um bloco indisponível aparece em avisos. Os demais blocos com texto publicável continuam no índice. Confira f3base/llms-cobertura-ler e o .md público. O comando f3base/llms-reprocessar solicita nova geração.

## Avisos operacionais · 436

As duas leituras f3base/como-usar e f3base/resumo-operacional-ler compartilham o cálculo dos avisos. As options da central com sufixo SHA-256 integram o inventário interno. As chaves desconhecidas continuam aparecendo na conferência.

## Caixa de e-mail · 437

Em Site Core → Conexões e entregas → Avisos, consulte Sinais de suspeita e avisos de formulários e e-mail. O sinal email_suspeito vem com Permitir aviso desligado. As razões de autenticação, endereço, conteúdo e leitura parcial têm regras individuais. Consulte f3base_formularios_sinais em f3base/config-core-ler. Simule e aplique a alteração pelo contrato de f3base/config-core-escrever com a revisão atual. Na configuração padrão, a mensagem suspeita aguarda aprovação. Uma mensagem aceita volta a ser elegível na fila da caixa, com deduplicação por mensagem e transporte.
