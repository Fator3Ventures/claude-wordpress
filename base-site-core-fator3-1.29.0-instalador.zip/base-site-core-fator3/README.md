# Fator3 Site Core 1.29.0

Configurações reunidas por tarefa; qualidade comercial local com regras próprias por conta, funil, formulário e campanha; retorno de etapas à Meta; formulários e mensagens legíveis; captura independente das tags.

Referência de implantação: WordPress novo ou Core 1.28.0, sem bloqueio por versão. PHP 8.3 / WordPress 7.1.2. Contrato 6.5.0. Matriz exercitada: MCP 0.19.0 e MCP Google 0.8.2. O pacote não altera os companheiros nem o tema.

[Documentação instalada](docs/DOCUMENTACAO.md) · [Release](docs/RELEASE-1.29.0.md) · [Configuração e UX](docs/CONFIGURACOES-1.29.md) · [Qualidade e Meta](docs/QUALIDADE-META-1.29.md) · [Agentes](docs/AGENTES-1.29.0.md) · [Validação](docs/VALIDACAO.md).

Guias, schemas, inventário e dicionário acompanham o ZIP instalado. O canal autenticado `f3base/documentacao-ler` oferece leitura paginada, inclusive em recuperação. Segredos entram pela tela do dono e nunca precisam ser copiados para um agente.
