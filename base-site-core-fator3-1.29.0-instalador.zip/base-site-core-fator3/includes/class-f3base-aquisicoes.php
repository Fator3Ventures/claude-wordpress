<?php
/** Reserva de aquisição anterior aos destinos; GA4 não depende de deduplicação remota. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Aquisicoes {
    public static function limpar(): void {global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE em<%d',self::tabela(),time()-DAY_IN_SECONDS));}
    public static function eliminar(string $id): bool {global $wpdb;return $wpdb->delete(self::tabela(),array('record_id'=>$id))!==false;}
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_aquisicoes';}
    public static function instalar(): bool {global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE {$t} (\nsessao char(32) NOT NULL,\nclasse varchar(16) NOT NULL,\nidentidade char(64) NOT NULL DEFAULT '',\nrecord_id char(32) NOT NULL,\nevent_id varchar(100) NOT NULL,\nem bigint unsigned NOT NULL,\nPRIMARY KEY  (sessao,classe,identidade),\nKEY registro (record_id),\nKEY retencao (em)\n) ENGINE=InnoDB {$wpdb->get_charset_collate()};");return !$wpdb->last_error;}
    public static function catalogo(array $c): array {$c['f3base_conversoes']=array('rotulo'=>'Contagem de conversões','descricao'=>'Uma aquisição por continuidade do contato na sessão evita somar formulário e clique no WhatsApp. Todas as ações permanecem no histórico de comportamento.','operavel'=>true,'secao'=>'medicao','campo'=>'grupo','autoload'=>false,'padrao'=>array('modo'=>'contato_sessao'),'subcampos'=>array('modo'=>array('tipo'=>'select','rotulo'=>'Quando contar nova conversão','opcoes'=>array('contato_sessao'=>'Uma por contato na sessão','por_acao'=>'Cada ação elegível'))),'schema_config'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('modo'=>array('type'=>'string','enum'=>array('contato_sessao','por_acao')))),'schema_entrada'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('modo'=>array('type'=>'string','enum'=>array('contato_sessao','por_acao')))),'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static fn($v)=>is_array($v)&&in_array($v['modo']??'',array('contato_sessao','por_acao'),true)?'':'Escolha uma regra de contagem.');return $c;}
    public static function reservar(array $lead): array {
        $id=$lead['record_id'];$event=!empty($lead['correlacao'])?$lead['correlacao']:$id;$session=$lead['sessao']??'';$class=$lead['classe_trafego'];
        if(!in_array($class,array('nao_marcado','teste'),true)||!in_array($lead['captura'],array('clique','aceito'),true)||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])){return array('elegivel'=>false,'codigo'=>'contato_inelegivel');}
        $cons=F3Base_Contato_Apresentacao::consentimento($lead['dados']);if(empty($cons['medicao'])){return array('elegivel'=>false,'codigo'=>'medicao_nao_permitida');}
        if(($lead['dados']['classificacao_contexto']??'')==='pendente'){return array('elegivel'=>false,'codigo'=>'classificacao_pendente','finalizacao'=>F3Base_Captura_Contexto::prova($lead));}if(in_array($lead['dados']['classificacao_contexto']??'',array('falha','excluida','saida_sem_classificacao','consentimento_negado'),true)){return array('elegivel'=>false,'codigo'=>'classificacao_ou_consentimento_nao_permite');}
        if($session===''||(F3Base_Options::ler('f3base_conversoes')['modo']??'contato_sessao')==='por_acao'){return array('elegivel'=>true,'event_id'=>$event,'codigo'=>$session===''?'sem_sessao_para_vincular':'por_acao');}
        $email=strtolower(trim($lead['email']??''));$phone=F3Base_Pipedrive_Api::telefone($lead['dados']['telefone']??'');$identity=is_email($email)?'email:'.$email:($phone?'telefone:'.$phone:'');$identity=$identity!==''?hash_hmac('sha256',$identity,wp_salt('auth')):'';
        $lock=F3Base_Trava::adquirir('aquisicao-'.$class.'-'.$session,15);if(!$lock){return array('elegivel'=>false,'codigo'=>'reserva_pendente');}global $wpdb;
        try{$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE sessao=%s AND classe=%s ORDER BY em DESC',self::tabela(),$session,$class),ARRAY_A);if($wpdb->last_error){return array('elegivel'=>false,'codigo'=>'reserva_indisponivel');}$found=null;$anon=null;foreach($rows as $r){if($r['identidade']===$identity){$found=$r;break;}if($r['identidade']===''){$anon=$r;}}
            if(!$found&&$identity===''&&$rows){$found=$rows[0];}
            if(!$found&&$anon&&$identity!==''){$found=$anon;if($wpdb->update(self::tabela(),array('identidade'=>$identity),array('sessao'=>$session,'classe'=>$class,'identidade'=>''))===false){return array('elegivel'=>false,'codigo'=>'reserva_indisponivel');}}
            if(!$found){$found=array('sessao'=>$session,'classe'=>$class,'identidade'=>$identity,'record_id'=>$id,'event_id'=>$event,'em'=>time());if($wpdb->insert(self::tabela(),$found)!==1){return array('elegivel'=>false,'codigo'=>'reserva_indisponivel');}}
            return array('elegivel'=>$found['record_id']===$id,'event_id'=>$found['event_id'],'codigo'=>$found['record_id']===$id?'aquisicao':'continuidade_mesma_sessao');
        }finally{F3Base_Trava::liberar($lock);}
    }
}
