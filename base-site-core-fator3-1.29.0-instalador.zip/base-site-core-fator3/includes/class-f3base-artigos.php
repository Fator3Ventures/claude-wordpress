<?php
/** Blocos editoriais dinâmicos, sem SDK ou JavaScript público próprio. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Artigos {
    private static bool $lendo=false;
    public static function iniciar(): void {
        add_action('init',static function(){
            wp_register_script('f3base-artigos-editor',F3BASE_PLUGIN_URL.'assets/f3base-artigos-editor.js',array('wp-blocks','wp-element','wp-block-editor','wp-components','wp-server-side-render'),F3BASE_PLUGIN_VERSAO,true);
            register_block_type('f3base/artigo-indice',array('api_version'=>3,'editor_script'=>'f3base-artigos-editor','attributes'=>array('titulo'=>array('type'=>'string','default'=>'Neste artigo'),'aberto'=>array('type'=>'boolean','default'=>true)),'render_callback'=>array(__CLASS__,'indice')));
            register_block_type('f3base/artigo-compartilhar',array('api_version'=>3,'editor_script'=>'f3base-artigos-editor','render_callback'=>array(__CLASS__,'compartilhar')));
        });
        add_filter('the_content',array(__CLASS__,'marcar'),12);
        add_filter('script_loader_tag',static function($html,$handle){if(!str_starts_with($handle,'f3base')){return $html;}if(class_exists('WP_HTML_Tag_Processor')){$p=new WP_HTML_Tag_Processor($html);while($p->next_tag('SCRIPT')){$p->set_attribute('data-no-optimize','1');}return $p->get_updated_html();}return $html;},20,2);
        add_filter('wp_inline_script_attributes',static function($attrs){if(str_starts_with((string)($attrs['id']??''),'f3base')){$attrs['data-no-optimize']='1';}return $attrs;});
    }
    private static function headings(string $html): array {
        $seen=array();$list=array();$updated=preg_replace_callback('/<(h[2-6])\b([^>]*)>(.*?)<\/\1>/is',static function($m)use(&$seen,&$list){$text=trim(html_entity_decode(wp_strip_all_tags($m[3]),ENT_QUOTES,'UTF-8'));if($text===''){return $m[0];}$attrs=$m[2];preg_match('/\bid=["\']([^"\']+)["\']/i',$attrs,$found);$base=$found[1]??sanitize_title($text);if($base===''){$base='secao';}$id=$base;$n=1;while(isset($seen[$id])){$id=$base.'-'.++$n;}$seen[$id]=true;$list[]=array('id'=>$id,'texto'=>$text,'nivel'=>(int)substr($m[1],1));$attrs=preg_replace('/\s+id=["\'][^"\']*["\']/i','',$attrs);return '<'.$m[1].$attrs.' id="'.esc_attr($id).'">'.$m[3].'</'.$m[1].'>';},$html);return array('html'=>$updated,'itens'=>$list);
    }
    public static function marcar(string $html): string {if(self::$lendo||!is_singular()){return $html;}return self::headings($html)['html'];}
    public static function indice(array $attrs=array()): string {
        if(self::$lendo){return '';}$post=get_post();if(!$post){return '';}
        self::$lendo=true;try{$html=apply_filters('the_content',$post->post_content);$list=self::headings($html)['itens'];}finally{self::$lendo=false;}if(!$list){return '';}
        $title=trim(sanitize_text_field($attrs['titulo']??'Neste artigo'))?:'Neste artigo';$out='<nav class="f3base-artigo-indice f3base-secao-indice" aria-label="'.esc_attr($title).'"><details '.(($attrs['aberto']??true)?'open':'').'><summary>'.esc_html($title).'</summary><ol>';
        foreach($list as $item){$out.='<li class="nivel-'.$item['nivel'].'"><a class="f3base-clique-indice" href="#'.esc_attr($item['id']).'">'.esc_html($item['texto']).'</a></li>';}return $out.'</ol></details></nav>';
    }
    public static function compartilhar(): string {
        $id=get_the_ID();if(!$id){return '';}$url=get_permalink($id);$title=get_the_title($id);$links=array('LinkedIn'=>'https://www.linkedin.com/sharing/share-offsite/?url='.rawurlencode($url),'Facebook'=>'https://www.facebook.com/sharer/sharer.php?u='.rawurlencode($url),'X'=>'https://twitter.com/intent/tweet?url='.rawurlencode($url).'&text='.rawurlencode($title),'E-mail'=>'mailto:?subject='.rawurlencode($title).'&body='.rawurlencode($url));$out='<nav class="f3base-artigo-compartilhar f3base-secao-compartilhar" aria-label="Compartilhar artigo"><p>Compartilhar</p><ul>';foreach($links as $name=>$href){$out.='<li><a href="'.esc_url($href).'" '.($name!=='E-mail'?'target="_blank" rel="noopener noreferrer"':'').'>'.esc_html($name).'</a></li>';}return $out.'</ul></nav>';
    }
}
