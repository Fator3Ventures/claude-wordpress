# Instruções vigentes

Leia [AGENTES-1.29.0.md](AGENTES-1.29.0.md), [DOCUMENTACAO.md](DOCUMENTACAO.md) e [QUALIDADE-META-1.29.md](QUALIDADE-META-1.29.md). Esses documentos prevalecem sobre guias históricos.
