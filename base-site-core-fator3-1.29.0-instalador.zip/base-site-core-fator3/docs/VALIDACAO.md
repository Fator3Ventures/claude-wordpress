# Validação — Core 1.29.0

Ensaios locais com dados sintéticos: WordPress 7.1.2, PHP 8.3, MariaDB e Chromium 138. Não houve envio a contas comerciais reais, mensagens a terceiros ou alteração nos sites da frota. Transportes comerciais foram bloqueados ou substituídos por respostas controladas. Os testes de navegador usam assets minificados e endpoints REST/banco reais por HTTP local.

| Evidência | Asserções | Resultado |
|---|---:|---|
| instalacao-nova.json | 10 | Passou |
| ciclo-instalacao.json | 11 | Passou |
| qualidade.json | 18 | Passou |
| release.json | 29 | Passou |
| contratos-1290.json | 11 | Passou |
| diagnostico-1290.json | 6 | Passou |
| comunicacao.json | 83 | Passou |
| historico.json | 27 | Passou |
| historico-volume.json | 6 | Passou |
| complementos.json | 12 | Passou |
| crm-complemento.json | 8 | Passou |
| slack-app.json | 16 | Passou |
| avisos.json | 30 | Passou |
| webhook.json | 29 | Passou |
| novidades.json | 27 | Passou |
| telas.json | 9 | Passou |
| operacao-1290.json | 16 | Passou |
| operacao.json | 18 | Passou |
| funcional.json | 28 | Passou |
| browser-http.json | 9 | Passou |
| browser-banco.json | 10 | Passou |
| browser-advanced.json | 17 | Passou |
| visual-email.json | 2 | Passou |

193 arquivos PHP e 28 arquivos JavaScript passaram na verificação sintática. Nove assets públicos foram minificados com Terser 5.44.0 e têm manifesto de bytes/hashes. As duas ordens frias de carregamento de MCP 0.19.0/Google 0.8.2 e as guardas independentes passaram; 20 verificações do SDK Google real usaram HTTP simulado. Quantidade de asserções não é percentual de cobertura nem quantidade de pedidos homologados na frota.

## O que foi provado localmente

- Instalação nova e atualização 1.28→1.29 por `plugins/upload-base64` do MCP real. Primeiro GET em menos de 2 s; tags/captura disponíveis antes da finalização; listas vazias, procedência e formulário preservados.
- Tela por tarefa, busca, regras recolhidas, links antigos redirecionados, GTM salvo isoladamente e mapa de campanha salvo por controles visuais. Três abas com tokens de cache renderizam sem fatal.
- Regra de qualidade específica por conta/formulário; recusa de ambiguidade; indicação manual simulada/real; evento atrasado no histórico sem regressão; uma identidade semântica. Webhook autenticado registra antes de responder, rejeita conta divergente e deduplica. 429 mantém ID/payload na repetição; payload CRM sem IP do servidor; autorização e janela são conferidas.
- Consulta de um formulário não consulta os demais nem altera o último sucesso completo da conta. Eliminação com reserva ativa responde pendente; retomada conclui e a simulação posterior descreve a marca nativa, sem identificá-la como legado WordPress.
- Conversão contínua formulário→clique, promoção do vínculo anônimo, pessoa diferente separada. Finalização de contexto exige prova curta vinculada, rejeita origem/prova inválida e atualiza a mesma captura. Diagnóstico anônimo aceita apenas campos fechados e deduplica transições.
- Histórico com 30.368 linhas sintéticas, incluindo 20 mil de outros navegadores: corte de 365 dias, cinco visitas detalhadas, limite de eventos e uso de índices conferidos. Medidas locais/EXPLAIN estão em historico-volume-medidas.json; não são promessa de desempenho da frota.
- Navegador: roda produz 25/50/75/90 no payload/banco/resumo sem fabricar salto; toque CDP confiável e rolagem real; diálogo sem clonar, Escape e foco; 5xx HTML vira mensagem legível e mantém o destino WhatsApp do CTA. Um POST por etapa, complemento no mesmo contato, upload multipart e janela sem opener.
- Mesmas seções canônicas nos transportes; e-mail renderizado em 1.100/390 px sem estouro. Falhas Slack/contingência, 429, timeout, atualização de CRM e idempotência preservadas.
- Clarity faz no máximo uma chamada por passagem e respeita 429/quota. Oferta com mudança comercial invalida imediatamente; edição de texto conserva tolerância fixa, sem prorrogar. Concorrência de cron confirmada é distinguida de falha real. Dois processos do executor não repetem callback.

## O que depende da implantação

1. Pipedrive real: permissões, campos/opções, renderização da nota, webhook v2 e conversão lead→negócio com continuidade comprovada. Meta real: ativo/dataset, autorização, versão Graph e recepção/atribuição dos eventos. GET do dataset não homologa envio.
2. Captação, Clarity e cron na frota por sete dias, incluindo cotas gastas fora do plugin. O laboratório não substitui essa observação.
3. Safari iOS e navegadores internos Instagram/Facebook em aparelhos físicos; limites PHP/proxy e proteção da pasta privada no servidor real.
4. Aplicação dos blocos de artigo e retirada de componentes duplicados pelo tema/implantador. MCP Google mantém responsabilidade sobre seu próprio hook de cron.

As falhas de banco/HTTP injetadas são parte dos cenários controlados. Evidências finais aprovadas acompanham o pacote de fontes; relatórios intermediários de depuração e cookies do laboratório não são distribuídos. Consulte RELEASE-1.29.0.md para limites de leitura/retomada e IMPACTO-1.29.0.md para encaminhamentos.
