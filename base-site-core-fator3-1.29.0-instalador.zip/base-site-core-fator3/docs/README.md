# Documentação

O índice vigente é [DOCUMENTACAO.md](DOCUMENTACAO.md), Core 1.29.0. Guias de releases anteriores são históricos; aplique primeiro as instruções da versão atual.
