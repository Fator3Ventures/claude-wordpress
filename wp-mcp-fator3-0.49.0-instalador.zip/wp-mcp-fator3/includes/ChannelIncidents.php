<?php
/** Observations only. Site Core owns destination, queue, mail and deduplication. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ChannelIncidents {
    public static function init(): void {
        add_action('wp_loaded',static function(): void { self::observe(false); },30);
    }
    public static function status(): array {
        return ['contract'=>'incidentes/1','core_available'=>(bool)has_filter('f3base_incidente_publicar_v1'),
            'last_observation'=>StateStore::get('automation','incidents'),
            'delivery_owner'=>'base-site-core-fator3','external_uptime_monitor'=>false];
    }
    private static function publish(string $code,string $resource,bool $open,?int $expires=null): void {
        $key=hash('sha256',$code.'|'.$resource);
        $state=StateStore::get('channel-incidents',$key)??['queue'=>[]];
        $event=['pacote'=>'canal','codigo'=>$code,'recurso'=>$resource,
            'estado'=>$open?'aberto':'recuperado','acao_humana'=>$open,
            'rota'=>'tools.php?page=wp-mcp-fator3'];
        if ($expires!==null && $expires>0) $event['vence_em']=$expires;
        if (($state['desired']??null)!==$event) {
            $state['desired']=$event;
            $state['queue'][]=$event+['desde'=>time()];
            StateStore::put('channel-incidents',$key,$state);
        }
        // Keep transitions if the Core is absent or busy. The Core retains accepted mail retries.
        foreach (array_slice($state['queue'],0,4) as $pending) {
            $r=apply_filters('f3base_incidente_publicar_v1',null,$pending);
            $state['last_attempt']=time();
            $state['last_result']=is_array($r)?array_intersect_key($r,array_flip(['ok','estado','codigo'])):['ok'=>false,'codigo'=>'core_unavailable'];
            if (!is_array($r)||empty($r['ok'])) { StateStore::put('channel-incidents',$key,$state); break; }
            array_shift($state['queue']);StateStore::put('channel-incidents',$key,$state);
        }
    }
    /** Caller has already validated a known grant/client pair; no credentials reach this hook. */
    public static function exchangeObserved(string $grant,bool $success): void {
        if ($grant==='') return;
        try { Locks::run(['channel-incidents'=>LOCK_EX],static function() use($grant,$success) {
            self::publish('renovacao_falhou','concessao:'.$grant,!$success);
            if ($success) self::grant($grant,Persistence::get('oauth-grants',$grant));
        }); } catch (\Throwable $e) { /* OAuth issuance is independent of notification transport. */ }
    }
    private static function grant(string $id,?array $g): void {
        if (!$g || ($g['status']??$g['_storage']['status']??'')!=='active') {
            self::publish('refresh_vencendo','concessao:'.$id,false);
            self::publish('renovacao_falhou','concessao:'.$id,false);
            return;
        }
        $expiry=(int)($g['refresh_expires_at']??0);
        if ($expiry<=0) {
            global $wpdb;$table=Persistence::table('oauth-tokens');
            $expiry=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(expires_at) FROM `$table` WHERE bucket='oauth-tokens' AND kind='rt' AND grant_id=%s",$id));
            if ($wpdb->last_error) throw new \RuntimeException();
        }
        if ($expiry>0) self::publish('refresh_vencendo','concessao:'.$id,$expiry<=time()+AutomaticMaintenance::policy()['refresh_notice_days']*DAY_IN_SECONDS,$expiry);
    }
    public static function observe(bool $force=false): void {
        try { Locks::run(['channel-incidents'=>LOCK_EX],static function() use($force) {
            $last=StateStore::get('automation','incidents')??[];
            if (!$force && (int)($last['time']??0)>time()-300) return;
            $now=time();$policy=AutomaticMaintenance::policy();
            $next=wp_next_scheduled(AutomaticMaintenance::HOOK);
            $marker=CronMarker::status();
            $late=$next===false || $next<$now-$policy['cron_late_seconds'];
            self::publish('cron_sem_passagem','manutencao-wordpress',$late);
            if (isset($marker['current_state'])) self::publish('agenda_parada','marcador-wordpress',!in_array($marker['current_state'],['active'],true));
            $snapshot=ConnectionStatus::snapshot(true);
            if (!$snapshot['server_enabled'] || $snapshot['registry_checked']) self::publish('canal_indisponivel','registro-wordpress',!empty($snapshot['errors']));
            $sweep=\Fator3\RecoveryV1\Engine::sweep_status();
            if (($sweep['status']??'not_run')!=='not_run' || Recovery::runtime_refresh_status()==='failed') self::publish('canal_indisponivel','sentinela-recuperacao',($sweep['status']??'')==='degraded' || !empty($sweep['unresolved']) || Recovery::runtime_refresh_status()==='failed');
            $run=StateStore::get('automation','last');
            if ($run) {
                $stale=($run['finished_at']??$run['started_at'])<$now-900-$policy['cron_late_seconds'];
                if (($run['status']??'')!=='running' || $stale) self::publish('integracao_indisponivel','manutencao-automatica',$stale || in_array($run['status'],['failed','partial','invalid_policy'],true));
            }
            // Bounded cursor, including revoked grants so an existing warning can be closed.
            global $wpdb;$table=Persistence::table('oauth-grants');$after=(int)($last['grant_after']??0);
            $rows=Persistence::rows($wpdb->prepare("SELECT id,payload FROM `$table` WHERE bucket='oauth-grants' AND id>%d ORDER BY id LIMIT 101",$after));
            foreach (array_slice($rows,0,100) as $r) {
                $g=json_decode($r['payload'],true,512,JSON_THROW_ON_ERROR);
                if (!empty($g['grant_id'])) self::grant($g['grant_id'],$g);
                $after=(int)$r['id'];
            }
            StateStore::put('automation','incidents',['time'=>$now,'status'=>'observed','grant_after'=>count($rows)>100?$after:0,
                'has_more'=>count($rows)>100,'core_available'=>(bool)has_filter('f3base_incidente_publicar_v1')]);
        }); } catch (\Throwable $e) {
            try { StateStore::put('automation','incidents',['time'=>time(),'status'=>'failed','error_code'=>'incident_observation_failed']); } catch (\Throwable $ignored) {}
        }
    }
}
