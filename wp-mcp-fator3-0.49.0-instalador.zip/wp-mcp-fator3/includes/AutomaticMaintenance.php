<?php
/** Site-owned policy and bounded scheduled retention using the existing selections. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class AutomaticMaintenance {
    public const OPTION = 'f3_mcp_automatic_maintenance';
    public const HOOK = 'f3_mcp_automatic_maintenance';
    private static bool $running = false;
    private static ?array $selectionPolicy = null;
    public static function activePolicy(): array { return self::$selectionPolicy ?? self::policy(); }
    public static function automaticSelection(): bool { return self::$selectionPolicy !== null; }
    public const DEFAULTS = [
        'enabled'=>true, 'backups_days'=>1, 'idempotency_days'=>1,
        'oauth_receipts_days'=>30, 'audit_days'=>0, 'refresh_notice_days'=>14,
        'cron_late_seconds'=>3600,
    ];

    public static function init(): void {
        add_filter('cron_schedules', static function(array $s): array {
            $s['f3_mcp_quarter_hour'] = ['interval'=>900, 'display'=>'Fator3 MCP a cada 15 minutos'];
            return $s;
        });
        add_action(self::HOOK, [self::class,'run']);
        add_action('wp_loaded', [self::class,'schedule']);
    }
    public static function running(): bool { return self::$running; }
    public static function scope(): string {
        return self::$running ? 'service:mcp-maintenance:'.get_current_blog_id() : ConnectionContext::key();
    }
    public static function policy(): array {
        $stored=get_option(self::OPTION, []);
        if (!is_array($stored) || !self::valid($stored)) return self::DEFAULTS + ['invalid'=>true];
        return array_replace(self::DEFAULTS, $stored);
    }
    private static function valid(array $p): bool {
        if (array_diff_key($p, self::DEFAULTS)) return false;
        foreach ($p as $key=>$value) {
            if ($key==='enabled') { if (!is_bool($value)) return false; continue; }
            $minimum=$key==='audit_days'?0:1;
            $maximum=$key==='cron_late_seconds'?86400:3650;
            if (!is_int($value) || $value<$minimum || $value>$maximum) return false;
        }
        return true;
    }
    public static function revision(): string {
        return hash('sha256', wp_json_encode(self::policy()));
    }
    public static function schedule(): void {
        // Observation and expiry warnings remain useful while automatic deletion is paused.
        if (wp_next_scheduled(self::HOOK)!==false) return;
        Locks::run(['maintenance-schedule'=>LOCK_EX], static function() {
            if (wp_next_scheduled(self::HOOK)!==false) return;
            $r=wp_schedule_event(time()+60, 'f3_mcp_quarter_hour', self::HOOK, [], true);
            StateStore::put('automation','schedule',['time'=>time(),'success'=>!is_wp_error($r) && $r!==false]);
        });
    }
    public static function register(): void {
        $fields=[];
        foreach (self::DEFAULTS as $name=>$default) {
            $fields[$name]=$name==='enabled'?['type'=>'boolean']:Registry::integer($name==='audit_days'?0:1,$name==='cron_late_seconds'?86400:3650);
        }
        $descriptions=[
            'enabled'=>'Ativa a exclusão automática. Os avisos continuam quando pausada.',
            'backups_days'=>'Idade mínima em dias de cópias e exportações sem dependências pendentes.',
            'idempotency_days'=>'Prazo em dias dos resultados completos; comprovantes mínimos de repetição são preservados.',
            'oauth_receipts_days'=>'Prazo em dias para comprovantes OAuth expirados, sujeito à proteção contra reutilização.',
            'audit_days'=>'Idade mínima da auditoria em dias. Zero preserva o histórico.',
            'refresh_notice_days'=>'Antecedência em dias do aviso de vencimento da concessão OAuth.',
            'cron_late_seconds'=>'Tolerância em segundos de atraso da passagem prevista.',
        ];
        foreach ($fields as $name=>&$field) $field['description']=$descriptions[$name]; unset($field);
        $policy=['type'=>'object','properties'=>$fields,'additionalProperties'=>false,'description'=>'Critérios parciais de manutenção; campos omitidos conservam o valor corrente.'];
        Registry::add('system/maintenance-policy','Lê política, agenda e último resultado da manutenção automática do WordPress.',[],[],[self::class,'status'],'manage_options');
        Registry::add('system/maintenance-configure','Simula a política. dry_run:false grava somente com expected_revision corrente. Dias zero preservam a auditoria. A limpeza usa o próximo WP-Cron.',[
            'policy'=>$policy,'dry_run'=>Registry::boolean(true),'expected_revision'=>array_replace(Registry::string(),['description'=>'Revisão corrente retornada pela leitura ou simulação da política.']),
        ],['policy'],[self::class,'configure'],'manage_options',false);
        Registry::add('system/maintenance-preview','Simula uma passagem com a política corrente ou proposta. Cria seleções privadas, preserva os dados selecionados e apresenta proteções e continuação.',[
            'policy'=>$policy,
        ],[],[self::class,'preview'],'manage_options',false);
    }
    public static function status(): array {
        return Result::ok(['policy'=>self::policy(),'revision'=>self::revision(),
            'next_run'=>wp_next_scheduled(self::HOOK) ?: null, 'hook'=>self::HOOK,
            'last_run'=>self::publicLast(),
            'incidents'=>ChannelIncidents::status()]);
    }
    private static function publicLast(): ?array {
        $row=StateStore::get('automation','last');
        if (!$row) return null;
        $public=array_intersect_key($row,array_flip(['started_at','finished_at','status','revision','continuation_required','error_code']));
        $public['categories']=[];
        foreach ($row['categories']??[] as $category=>$result) $public['categories'][$category==='oauth-tokens'?'oauth':$category]=self::summary($result);
        return $public;
    }
    public static function configure(array $i): array {
        if (!current_user_can('manage_options')) return Result::fail('permission_denied','Exige manage_options.');
        if (!self::valid($i['policy'])) return Result::fail('maintenance_policy_invalid','Política inválida.');
        return Locks::run(['automatic-maintenance'=>LOCK_EX], static function() use ($i) {
            $current=self::policy(); unset($current['invalid']);
            $next=array_replace($current, $i['policy']);
            if ($i['dry_run']??true) return Result::ok(['dry_run'=>true,'policy'=>$next,'expected_revision'=>self::revision()]);
            if (!hash_equals(self::revision(), (string)($i['expected_revision']??''))) return Result::fail('revision_conflict','Releia e simule a política corrente.',['conflict'=>true]);
            foreach (array_keys(self::categories($current)) as $category) {
                if (StateStore::get('automation','pending-'.$category)) return Result::fail('maintenance_in_progress','Um lote anterior aguarda conclusão. Aguarde a próxima passagem antes de mudar os critérios.');
            }
            update_option(self::OPTION,$next,false);
            if (get_option(self::OPTION)!==$next) return Result::fail('maintenance_policy_write_failed','Gravação não confirmada.');
            return Result::ok(['persisted'=>true,'changed'=>$next!==$current,'policy'=>$next,'revision'=>self::revision()]);
        });
    }
    private static function categories(array $p): array {
        $all=['oauth-tokens'=>['category'=>'oauth-tokens'],
            'idempotency'=>['category'=>'idempotency','older_than_days'=>$p['idempotency_days']],
            'backups'=>['older_than_days'=>$p['backups_days'],'min_keep'=>0],
            'sql_artifacts'=>['category'=>'sql_artifacts','older_than_days'=>$p['backups_days'],'min_keep'=>0]];
        if ($p['audit_days']>0) $all['audit']=['category'=>'audit','older_than_days'=>$p['audit_days']];
        return $all;
    }
    private static function call(string $category,array $input): array {
        return match($category) { 'backups'=>Retention::prune($input), 'sql_artifacts'=>SqlArtifacts::prune($input), default=>StateMaintenance::run($input) };
    }
    private static function summary(array $r): array {
        $allowed=['success','error_code','dry_run','selected','selected_bytes','completed','removed',
            'removed_bytes','has_more','inventory_complete','remaining_eligible','eligibility_complete','partial','pending'];
        $out=array_intersect_key($r,array_flip($allowed));
        if (isset($r['blocked'])) $out['protected']=count($r['blocked']);
        return $out;
    }
    public static function preview(array $i): array {
        if (!current_user_can('manage_options')) return Result::fail('permission_denied','Exige manage_options.');
        if (!self::valid($i['policy']??[])) return Result::fail('maintenance_policy_invalid','Política inválida.');
        $policy=array_replace(self::policy(),$i['policy']??[]);
        $results=[];
        self::$selectionPolicy=$policy;
        try { foreach (self::categories($policy) as $category=>$input) $results[$category==='oauth-tokens'?'oauth':$category]=self::summary(self::call($category,$input+['dry_run'=>true])); }
        finally { self::$selectionPolicy=null; }
        return Result::ok(['dry_run'=>true,'policy'=>$policy,'categories'=>$results,'revision'=>self::revision()]);
    }
    public static function run(): void {
        $result=Locks::run(['automatic-maintenance'=>LOCK_EX],static function() {
            $policy=self::policy();$revision=self::revision();
            $result=['started_at'=>time(),'status'=>'running','revision'=>$revision,'categories'=>[]];
            ChannelIncidents::observe(true);
            StateStore::put('automation','last',$result);
            self::$running=true; self::$selectionPolicy=$policy;
            try {
                if (!$policy['enabled'] || !empty($policy['invalid'])) {
                    $result['status']=empty($policy['invalid'])?'paused':'invalid_policy';
                    return $result;
                }
                $limit=(int)ini_get('max_execution_time');
                $deadline=microtime(true)+15;
                if ($limit>0) $deadline=min($deadline,($_SERVER['REQUEST_TIME_FLOAT']??microtime(true))+$limit-5);
                foreach (self::categories($policy) as $category=>$input) {
                    if (microtime(true)>$deadline) { $result['continuation_required']=true; break; }
                    $pending=StateStore::get('automation','pending-'.$category);
                    if ($pending && $pending['revision']!==$revision) { $result['categories'][$category]=['success'=>false,'error_code'=>'maintenance_policy_changed_pending']; continue; }
                    if (!$pending) {
                        $scan=StateStore::get('automation','cursor-'.$category);
                        if (($scan['revision']??null)===$revision && !empty($scan['cursor'])) { if ($category==='backups') $input['cursor']=$scan['cursor']; elseif ($category==='sql_artifacts') $input['_after']=$scan['cursor']; }
                        $r=self::call($category,$input+['dry_run'=>true]);
                        $result['categories'][$category]=self::summary($r);
                        if (in_array($category,['backups','sql_artifacts'],true) && !empty($r['success'])) StateStore::put('automation','cursor-'.$category,['revision'=>$revision,'cursor'=>$r[$category==='backups'?'next_cursor':'auto_next']??null]);
                        if (empty($r['success']) || empty($r['selected'])) continue;
                        $hash=$r['expected_selection_sha256']??$r['selection_sha256']??null;
                        if (!$hash) continue;
                        $pending=['category'=>$category,'revision'=>$revision,'input'=>['dry_run'=>false,'expected_selection_sha256'=>$hash]];
                        if ($category!=='backups') $pending['input']['category']=$category;
                        StateStore::put('automation','pending-'.$category,$pending);
                    }
                    $r=self::call($category,$pending['input']);
                    $result['categories'][$category]=self::summary($r);
                    if (!empty($r['success']) || in_array($r['error_code']??'',[
                        'backup_selection_expired','backup_selection_invalid','maintenance_selection_invalid','maintenance_selection_conflict','backup_selection_conflict',
                    ],true)) StateStore::delete('automation','pending-'.$category);
                }
                $result['status']=!empty($result['continuation_required'])?'partial':'complete';
                foreach ($result['categories'] as $r) if (empty($r['success'])) $result['status']='partial';
            } catch (\Throwable $e) {
                $result['status']='failed';$result['error_code']='automatic_maintenance_failed';
            } finally {
                self::$running=false; self::$selectionPolicy=null;
                $result['finished_at']=time();
                StateStore::put('automation','last',$result);
                Audit::record('system/automatic-maintenance',[],['operation_id'=>'maintenance:'.$result['started_at'],
                    'success'=>in_array($result['status'],['complete','paused'],true),'status'=>$result['status'],'policy_revision'=>$revision],0);
            }
            return $result;
        });
        // Resource contention defers this pass to the next scheduled occurrence.
    }
}
