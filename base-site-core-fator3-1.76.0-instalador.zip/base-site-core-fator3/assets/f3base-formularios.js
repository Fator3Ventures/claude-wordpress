/*! F3 Base — formulários com envio idempotente, contexto e renovação de token. GPL-2.0-or-later. */
(function(){
 'use strict';
 var estados=new WeakMap();
 function mensagem(f,k,padrao){try{var m=JSON.parse(f.dataset.mensagens||'{}');return typeof m[k]==='string'&&m[k].trim()?m[k]:padrao;}catch(e){return padrao;}}
 function conferirArquivos(f){
  var total=0,quantidade=0,post=Number(f.dataset.postMaxBytes)||0,maxUploads=Number(f.dataset.maxFileUploads)||0,valido=true,inputs=Array.from(f.querySelectorAll('input[type="file"]'));
  inputs.forEach(function(el){el.setCustomValidity('');el.removeAttribute('aria-invalid');var files=Array.from(el.files||[]),max=Number(el.dataset.maxBytes)||0,limite=Number(el.dataset.maxFiles)||5;
   quantidade+=files.length;files.forEach(function(file){total+=file.size;});
   if(files.length>limite||files.some(function(file){return max>0&&file.size>max;})){el.setCustomValidity(mensagem(f,'arquivo_limite','Confira o tamanho e a quantidade de arquivos.'));el.setAttribute('aria-invalid','true');valido=false;}
  });
  // Arquivos sozinhos são um limite inferior do multipart. O PHP confere o corpo completo.
  if(inputs.length&&((post>0&&total>post)||(maxUploads>0&&quantidade>maxUploads))){inputs[0].setCustomValidity(mensagem(f,'arquivo_limite','O envio excede o limite total do servidor.'));inputs[0].setAttribute('aria-invalid','true');valido=false;}
  return valido;
 }
 document.addEventListener('change',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(f&&e.target.type==='file'){conferirArquivos(f);}});

 function id(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join('');}
 function preparar(f){if(!f.dataset.f3baseInstancia){f.elements.submissao.value=id();f.elements.token.value='';f.dataset.f3baseInstancia='1';}return f.elements.submissao.value;}
 window.f3baseFormularioInstancia=preparar;
 function estado(f){preparar(f);var s=estados.get(f);if(!s){s={iniciado:false,enviando:false,token:null,aceito:false,carga:null,teste:null};estados.set(f,s);}return s;}
 function evento(f,n,d){f.dispatchEvent(new CustomEvent('f3base-formulario-'+n,{bubbles:true,detail:d||{}}));}

 // Private diagnostics: only blocked snapshots contain values; no CustomEvent or analytics payload.
 var sessaoOperacional='',formulariosRecusados=new Set();
 function sessaoTentativa(){var v=window.f3baseTracking&&window.f3baseTracking.sessao();if(/^[a-f0-9]{32}$/.test(v||'')){return v;}return sessaoOperacional||(sessaoOperacional=id());}
 function motivoTelefone(v,pais){var n=v.trim().replace(/[ ().-]/g,'');if(!/^[+0-9]*$/.test(n)){return 'caracteres_invalidos';}if(n.charAt(0)==='+'){return 'formato_internacional';}if(pais==='BR'){if(n.length===8||n.length===9){return 'sem_ddd';}if(n.length!==10&&n.length!==11){return 'quantidade_digitos';}if(!telefone(n.slice(0,2)+'987654321','BR')){return 'ddd_invalido';}if((n.length===10&&n.charAt(2)==='9')||(n.length===11&&n.charAt(2)!=='9')){return 'quantidade_digitos';}return 'prefixo_invalido';}return 'formato_pais';}
 function camposTentativa(f,comValores,abandono){
  var rows={},pais=f.dataset.paisTelefone||'BR',group=[];try{group=JSON.parse(f.dataset.exigirUmDe||'[]');}catch(ignore){}
  Array.from(f.elements).forEach(function(el){var m=(el.name||'').match(/^campos\[([a-z0-9_-]+)\](?:\[\])?$/);if(!m||el.disabled||el.type==='hidden'||el.type==='password'||!el.validity){return;}if(abandono&&(el.type==='file'||el.closest('.f3base-isca')||/(?:senha|password|token|captcha|honeypot|^website$|^ctodesenvolvimentofator3$|^segmento_atuacao$|^comentario$)/i.test(m[1]))){return;}var name=m[1],row=rows[name]||(rows[name]={nome:name,estado:'vazio',regras:[]}),v=(el.type==='checkbox'||el.type==='radio')?(el.checked?el.value:''):(el.type==='file'?(el.files.length?'arquivo_selecionado':''):el.value||'');
   if(String(v).trim()){row.estado='preenchido';}['valueMissing','typeMismatch','tooShort','tooLong','patternMismatch','rangeUnderflow','rangeOverflow','stepMismatch','badInput'].forEach(function(k){if(el.validity[k]&&row.regras.indexOf(k)<0){row.regras.push(k);}});
   if(el.type==='tel'&&el.dataset.formatoLivre!=='1'&&v.trim()&&!telefone(v,pais)){row.regras.push('telefone_formato');row.motivo=motivoTelefone(v,pais);row.pais=pais;}
   if(el.validity.customError&&el.type==='file'){row.regras.push('arquivo_limite');}
   if(el.validity.customError&&el.type!=='file'&&el.type!=='tel'&&group.indexOf(name)<0){row.regras.push('customError');}
   if(comValores&&(abandono||f.dataset.tentativasValores!=='0')&&el.type!=='file'){row.valor=(row.valor&&v?row.valor+'\n':'')+String(v).slice(0,4000);if(row.valor.length>4000){row.valor=row.valor.slice(0,4000);row.valor_truncado=true;}if(String(v).length>4000){row.valor_truncado=true;}}
  });
  var active=group.filter(function(n){return !!rows[n];});if(active.length&&!active.some(function(n){return rows[n].estado==='preenchido'&&rows[n].regras.length===0;})){active.forEach(function(n){rows[n].regras.push('exigir-um-de');});}
  return Object.keys(rows).map(function(k){var row=rows[k];row.regras=Array.from(new Set(row.regras));if(row.regras.length&&row.estado!=='vazio'){row.estado='invalido';}return row;});
 }
 function diagnostico(f,tipo,campos,extra,saida){
  var s=estado(f),url;try{url=new URL(f.dataset.endpoint+'tentativas',location.href);if(url.origin!==location.origin){return;}}catch(ignore){return;}
  var payload={formulario:f.dataset.f3baseFormulario,instancia:f.elements.submissao.value,sessao:s.sessaoDiagnostico||(s.sessaoDiagnostico=sessaoTentativa()),evento:id(),sequencia:s.seqDiagnostico=(s.seqDiagnostico||0)+1,etapa:s.etapa||1,tipo:tipo,ocorrido_ms:Date.now(),caminho:location.pathname,campos:campos||[]};if(extra){payload.record_id=extra;}
  while(new TextEncoder().encode(JSON.stringify(payload)).length>59000){var longest=payload.campos.filter(function(c){return c.valor&&c.valor.length;}).sort(function(a,b){return b.valor.length-a.valor.length;})[0];if(!longest){return;}longest.valor=longest.valor.slice(0,Math.floor(longest.valor.length/2));longest.valor_truncado=true;}
  if(tipo==='abandono'&&saida&&valido(f.elements.token.value)&&navigator.sendBeacon){
   payload.token=f.elements.token.value;
   if(navigator.sendBeacon(url.href,new Blob([JSON.stringify(payload)],{type:'application/json'}))){return;}
  }
  s.diagnosticos=(s.diagnosticos||Promise.resolve()).catch(function(){}).then(function(){return token(f).then(function(){if(tipo==='abandono'&&!podeFotografar(f)){return;}payload.token=f.elements.token.value;return fetch(url.href,{method:'POST',credentials:'same-origin',cache:'no-store',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});});}).catch(function(){});
 }
 function recusa(f){var s=estado(f);if(s.recusaAgendada){return;}s.recusaAgendada=true;setTimeout(function(){s.recusaAgendada=false;var fields=camposTentativa(f,true);if(!fields.some(function(c){return c.regras.length;})){return;}s.camposRecusados={};fields.forEach(function(c){if(c.regras.length){s.camposRecusados[c.nome]=true;}});s.recusado=true;s.saidaRegistrada=false;formulariosRecusados.add(f);diagnostico(f,'recusado',fields);},0);}
 // Validate group before the native constraint-validation phase, including a first click on an empty form.
 document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button,input[type="submit"]'),f=b&&b.form;if(f&&f.matches('[data-f3base-formulario]')&&(b.type==='submit')){validarGrupo(f);conferirArquivos(f);}},true);
 document.addEventListener('keydown',function(e){var f=e.target.form;if(e.key==='Enter'&&f&&f.matches('[data-f3base-formulario]')&&e.target.tagName!=='TEXTAREA'){validarGrupo(f);conferirArquivos(f);}},true);
 document.addEventListener('change',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(!f){return;}var s=estado(f);if(!s.recusado){return;}validarGrupo(f);var fixed=camposTentativa(f,false).filter(function(c){return s.camposRecusados&&s.camposRecusados[c.nome]&&!c.regras.length;});if(fixed.length){fixed.forEach(function(c){delete s.camposRecusados[c.nome];});diagnostico(f,'correcao',fixed);}});
 function podeFotografar(f){
  var s=estado(f);
  return f.dataset.abandono==='1'&&s.iniciado&&!s.aceito&&!s.primeiraEnviada&&(s.etapa||1)===1&&
   (f.dataset.abandonoMedicao==='0'||(window.f3baseConsentimento&&window.f3baseConsentimento.permiteCategoria('medicao')));
 }
 function fotografar(f,saida){
  if(!podeFotografar(f)){return;}
  var s=estado(f);
  if(!saida&&!s.alterouAbandono){return;}
  s.alterouAbandono=false;
  diagnostico(f,'abandono',camposTentativa(f,true,true),null,saida);
 }
 document.addEventListener('focusout',function(e){var f=e.target.form;if(f&&f.matches('[data-f3base-formulario]')&&e.target.name&&e.target.name.indexOf('campos[')===0){fotografar(f,false);}});
 function saidaTentativa(f){var s=estado(f);fotografar(f,true);if(s.recusado&&!s.aceito&&!s.saidaRegistrada){s.saidaRegistrada=true;diagnostico(f,'saida',[]);}}
 window.addEventListener('pagehide',function(){document.querySelectorAll('[data-f3base-formulario]').forEach(function(f){if(estados.has(f)){saidaTentativa(f);}});});
 document.addEventListener('close',function(e){if(e.target.tagName==='DIALOG'){e.target.querySelectorAll('[data-f3base-formulario]').forEach(saidaTentativa);}},true);

 function valido(v){try{return Number(JSON.parse(atob(v.split('.')[0])).t)+7200>Date.now()/1000+60;}catch(e){return false;}}
 function pedir(url,op){var control=new AbortController(),timer=setTimeout(function(){control.abort();},15000);op.signal=control.signal;return fetch(url,op).finally(function(){clearTimeout(timer);});}
 function resposta(res,f){return res.text().then(function(text){var r=null;try{r=JSON.parse(text);}catch(ignore){}if(res.status===413){var size=new Error(mensagem(f,'arquivo_limite','O envio excedeu o limite permitido.'));size.codigo='limite_servidor';size.rejeitado=true;throw size;}if(res.status>=500||!r||typeof r!=='object'||typeof r.ok!=='boolean'){var err=new Error(mensagem(f,'nao_confirmado','O envio ainda não foi confirmado. Tente novamente.'));err.codigo='envio_nao_confirmado';throw err;}r._http=res.status;if(!res.ok){r.ok=false;}return r;});}
 function dialogo(f,s){if(f.dataset.etapa2Apresentacao!=='dialogo'||f.closest('dialog')||f.dataset.f3baseAdaptador==='1'||!window.HTMLDialogElement)return;var focus=document.activeElement,place=document.createComment('formulario'),box=document.createElement('dialog');box.setAttribute('aria-label','Informações adicionais');box.className='f3base-formulario-dialogo';f.before(place);var close=document.createElement('button');close.type='button';close.textContent='Fechar';close.addEventListener('click',function(){box.close();});box.append(close,f);document.body.appendChild(box);box.addEventListener('close',function(){place.replaceWith(f);box.remove();if(focus&&focus.isConnected)focus.focus();});box.showModal();var first=f.querySelector('[data-etapa="2"] input,[data-etapa="2"] textarea,[data-etapa="2"] select');if(first)first.focus();}
 function token(f,force){var s=estado(f);if(!force&&valido(f.elements.token.value)){return Promise.resolve();}if(s.token){return s.token;}
  s.token=pedir(f.dataset.endpoint+'token',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({formulario:f.dataset.f3baseFormulario,pagina:Number(f.dataset.pagina),submissao:f.elements.submissao.value})}).then(function(r){return resposta(r,f);}).then(function(r){if(!r.ok||!valido(r.token)){throw new Error(mensagem(f,'token_indisponivel','Não foi possível preparar o envio. Tente novamente.'));}f.elements.token.value=r.token;}).finally(function(){s.token=null;});return s.token;
 }
 document.addEventListener('invalid',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(f){estado(f);recusa(f);e.target.setAttribute('aria-invalid','true');var out=f.querySelector('.f3base-formulario-resultado');if(out){out.textContent=mensagem(f,'validacao','Confira os campos destacados.');}evento(f,'erro',{codigo:'validacao_navegador'});}},true);
 document.addEventListener('input',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(!f){return;}if(e.target.validity&&e.target.validity.valid){e.target.removeAttribute('aria-invalid');}var s=estado(f);if(f.dataset.abandono==='1'){s.alterouAbandono=true;}if(!s.iniciado&&!e.target.closest('.f3base-isca')&&String(e.target.value||'').trim()){s.iniciado=true;evento(f,'inicio',{formulario:f.dataset.f3baseFormulario});token(f).catch(function(){});}});
 function contexto(f,d,s){
  if(window.f3baseConsentimento&&window.f3baseConsentimento.permiteCategoria('medicao')){var cookies={};document.cookie.split(';').forEach(function(x){var i=x.indexOf('=');cookies[x.slice(0,i).trim()]=x.slice(i+1);});var client=(cookies._ga||'').match(/^GA\d+\.\d+\.(\d+\.\d+)$/),sid=cookies['_ga_'+(f.dataset.ga4||'').replace(/^G-/,'')]||'',session=sid.match(/^GS1\.\d+\.(\d+)\./)||sid.match(/^GS2\.\d+\.s(\d+)(?:\$|$)/);if(client&&session){d.set('ga4_client_id',client[1]);d.set('ga4_session_id',session[1]);}}
var c=window.f3baseContexto,a=window.f3baseAnalise&&window.f3baseAnalise.contexto();s.teste=c?c.teste():false;
  var oferta=window.f3baseOfertas&&window.f3baseOfertas.contexto(f);if(oferta){d.set('oferta',JSON.stringify(oferta));}
  d.set('largura_janela',String(Math.min(20000,window.innerWidth||0)));d.set('max_touch_points',String(Math.min(20,navigator.maxTouchPoints||0)));
  var aud=c&&c.audiencia&&c.audiencia();if(aud){d.set('retorno',aud.retorno);d.set('visitas',String(aud.visitas));d.set('visitas_minimo',aud.visitas_minimo?'1':'0');d.set('visitas_desde',String(aud.visitas_desde));d.set('largura_janela',String(aud.largura));d.set('max_touch_points',String(aud.max_touch_points));}d.set('classificacao_contexto',c&&c.estado?c.estado():'pendente');d.set('contexto_teste',s.teste?'1':'0');d.set('audiencia_excluida',c&&c.audienciaExcluida?'1':'0');var surfaces=['conteudo','menu','flutuante','elementor','cabecalho','barra_fixa'];var declared=f.getAttribute('data-f3base-superficie');var surface=surfaces.indexOf(declared)>=0?declared:surfaces.find(function(v){return f.classList.contains('f3base-superficie-'+v);});d.set('superficie',surfaces.indexOf(surface)>=0?surface:'conteudo');d.set('atribuicao',JSON.stringify(c?c.atribuicao():{}));
  if(a){d.set('navegacao',a.navegacao);d.set('dispositivo',a.dispositivo);}var sessao=window.f3baseTracking&&window.f3baseTracking.sessao();if(sessao){d.set('sessao',sessao);}var visitante=window.f3baseTracking&&window.f3baseTracking.visitante();if(visitante){d.set('visitante',visitante);}
 }
 // Read the native tag, cross-check the cookie captured for this submission; never refresh an uncertain submission.
 function sessaoGoogle(f,d){
  return new Promise(function(resolve){
   var consent=window.f3baseConsentimento,client=d.get('ga4_client_id'),sid=d.get('ga4_session_id');
   if(!consent||!consent.permiteCategoria('medicao')||typeof window.gtag!=='function'||!client||!sid){resolve();return;}
   var done=false,values={},timer=setTimeout(finish,500);
   function finish(){if(done)return;done=true;clearTimeout(timer);
    var now=Math.floor(Date.now()/1000),start=Number(sid);
    if(consent.permiteCategoria('medicao')&&String(values.client_id)===client&&String(values.session_id)===sid&&Number.isSafeInteger(start)&&start>=1577836800&&start<=now&&now-start<=86400){
     d.set('ga4_session_source','google_tag_native');d.set('ga4_session_started_at',String(start));d.set('ga4_observed_at',String(now));
    }resolve();
   }
   try{['client_id','session_id'].forEach(function(key){window.gtag('get',f.dataset.ga4,key,function(value){if(done)return;values[key]=value;if(Object.keys(values).length===2)finish();});});}catch(e){finish();}
  });
 }
 function telefone(v,pais){v=v.trim().replace(/[ ().-]/g,'');if(/^\+[1-9][0-9]{6,14}$/.test(v)){return true;}if(pais==='BR'){return /^[1-9][0-9](?:[2-5][0-9]{7}|9[0-9]{8})$/.test(v)&&[11,12,13,14,15,16,17,18,19,21,22,24,27,28,31,32,33,34,35,37,38,41,42,43,44,45,46,47,48,49,51,53,54,55,61,62,63,64,65,66,67,68,69,71,73,74,75,77,79,81,82,83,84,85,86,87,88,89,91,92,93,94,95,96,97,98,99].indexOf(Number(v.slice(0,2)))>=0;}return pais==='PT'?/^[2-9][0-9]{8}$/.test(v):(['US','CA'].indexOf(pais)>=0&&/^[2-9][0-9]{9}$/.test(v));}
 function validarGrupo(f){var group=[];try{group=JSON.parse(f.dataset.exigirUmDe||'[]');}catch(e){}var els=group.map(function(n){return f.elements.namedItem('campos['+n+']');}).filter(function(el){return el&&!el.disabled;}),valid=true;
  f.querySelectorAll('input[type="tel"]').forEach(function(el){if(el.disabled){return;}el.setCustomValidity('');if(el.dataset.formatoLivre!=='1'&&el.value.trim()&&!telefone(el.value,f.dataset.paisTelefone||'BR')){el.setCustomValidity('Informe telefone válido com DDD; para outro país, use + e o código do país.');valid=false;}});
  els.forEach(function(el){if(el.type!=='tel'){el.setCustomValidity('');}});
  if(els.length&&!els.some(function(el){return el.value.trim()&&el.validity.valid;})){els[0].setCustomValidity(f.dataset.grupoMensagem||'Informe e-mail ou WhatsApp.');valid=false;}return valid;
 }
 function mostrarEtapa(f,numero){var s=estado(f);s.etapa=numero;f.querySelectorAll('[data-etapa]').forEach(function(el){el.hidden=Number(el.dataset.etapa)!==numero;el.querySelectorAll('input,textarea,select,button').forEach(function(input){input.disabled=el.hidden;input.setCustomValidity&&input.setCustomValidity('');});});var instruction=f.querySelector('.f3base-formulario-grupo');if(instruction){instruction.hidden=numero!==1;}}
 function fecharReserva(s){if(s.janela&&!s.janela.closed){try{s.janela.close();}catch(e){}}s.janela=null;}
 function reservar(f,s){s.bloqueada=false;if(f.dataset.regime!=='whatsapp'||f.dataset.whatsappAutomatico!=='1'||f.dataset.whatsappNovaAba==='0'){return;}
  try{s.janela=window.open('about:blank','_blank');if(s.janela){s.janela.opener=null;s.janela.document.title='Preparando conversa';s.janela.document.body.textContent='Aguarde a confirmação do envio para continuar no WhatsApp.';}else{s.bloqueada=true;}}catch(e){fecharReserva(s);s.bloqueada=true;}
 }
 function continuar(f,s,url,automatico){if(!url){fecharReserva(s);return;}var isWa=false;try{var parsed=new URL(url,location.href);isWa=window.f3baseContexto&&window.f3baseContexto.destino(url)==='whatsapp';}catch(e){return;}if(!isWa){if(!automatico){location.assign(url);}return;}
  if(automatico){if(s.janela&&!s.janela.closed){s.janela.location.replace(url);s.janela=null;}else if(s.bloqueada||f.dataset.whatsappNovaAba==='0'){location.assign(url);}else{return;}}
  else if(f.dataset.whatsappNovaAba!=='0'){var link=document.createElement('a');link.href=url;link.target='_blank';link.rel='noopener noreferrer';link.click();}else{location.assign(url);}evento(f,'conversa-solicitada',{formulario:f.dataset.f3baseFormulario,etapa:s.etapa||1});
 }
 function botaoContinuar(f,s,r,out){if(!r.url){return;}var a=document.createElement('button');a.type='button';a.className='wp-element-button';a.textContent=r.method==='conteudo'?mensagem(f,'baixar_conteudo','Baixar conteúdo'):mensagem(f,'continuar_whatsapp','Continuar no WhatsApp')+(f.dataset.whatsappNovaAba!=='0'?' (nova aba)':'');a.addEventListener('click',function(){continuar(f,s,r.url,false);});out.appendChild(document.createElement('br'));out.appendChild(a);}
 function novoEnvio(f,s,b,out){var again=document.createElement('button');again.type='button';again.className='wp-element-button';again.textContent=mensagem(f,'novo_envio','Novo envio');again.addEventListener('click',function(){fecharReserva(s);s.primeiraEnviada=false;s.alterouAbandono=false;s.sessaoDiagnostico='';s.aceito=false;s.carga=null;s.iniciado=false;s.teste=null;s.token=null;s.continuacao=null;s.cta=null;s.complementoId=null;s.recusado=false;s.camposRecusados={};s.seqDiagnostico=0;s.saidaRegistrada=false;formulariosRecusados.delete(f);f.elements.submissao.value=id();f.elements.token.value='';f.reset();mostrarEtapa(f,1);b.hidden=false;b.textContent=s.botaoInicial;out.textContent='';f.querySelectorAll('[data-f3base-pular]').forEach(function(x){x.remove();});var first=f.querySelector('[data-etapa="1"] input,[data-etapa="1"] textarea');if(first){first.focus();}});out.appendChild(document.createElement('br'));out.appendChild(again);}
 function submeter(f,pular){var s=estado(f),etapa=s.etapa||1;if(s.enviando||s.aceito){return;}if(!s.carga&&!pular){validarGrupo(f);conferirArquivos(f);if(!f.reportValidity()){evento(f,'erro',{codigo:'validacao_navegador'});return;}}
  var b=f.querySelector('[type="submit"]'),out=f.querySelector('.f3base-formulario-resultado');s.botaoInicial=s.botaoInicial||b.textContent;
  var final=etapa===2||!f.querySelector('[data-etapa="2"]');if(final){reservar(f,s);}s.enviando=true;b.disabled=true;f.querySelectorAll('[data-f3base-pular]').forEach(function(x){x.disabled=true;});out.textContent=mensagem(f,'enviando','Enviando…');f.setAttribute('aria-busy','true');evento(f,'tentativa',{etapa:etapa});if(etapa===1){document.dispatchEvent(new CustomEvent('f3base:contato-capturado'));}
  if(!s.carga){if(etapa===2){s.complementoId=s.complementoId||id();s.carga=pular?new FormData():new FormData(f);if(pular){['website','ctodesenvolvimentofator3','segmento_atuacao','comentario'].forEach(function(k){s.carga.set(k,f.elements[k]?f.elements[k].value:'');});}['action','token','submissao'].forEach(function(k){s.carga.delete(k);});s.carga.set('formulario',f.dataset.f3baseFormulario);s.carga.set('continuacao',s.continuacao);s.carga.set('revisao',s.revisao);s.carga.set('submissao',s.complementoId);s.carga.set('pular',pular?'1':'0');}
   else{s.carga=new FormData(f);s.carga.delete('action');contexto(f,s.carga,s);s.ga4Evidence=sessaoGoogle(f,s.carga);if(s.cta){s.carga.set('cta_origem',JSON.stringify(s.cta));s.carga.set('superficie',s.cta.superficie);}}}
  function enviar(renewed){return (etapa===1?Promise.all([token(f,renewed).catch(function(){/* The server classifies missing or stale tokens; valid contact is still saved. */}),s.ga4Evidence]):Promise.resolve()).then(function(){if(etapa===1){s.carga.set('token',f.elements.token.value);}return pedir(f.dataset.endpoint+(etapa===1?'enviar':'complementar'),{method:'POST',credentials:'same-origin',body:s.carga});}).then(function(res){return resposta(res,f);}).then(function(r){if(!r.ok){if(etapa===1&&r.codigo==='token_ou_revisao_invalida'&&!renewed){return enviar(true);}var err=new Error((typeof r.mensagem==='string'?r.mensagem.slice(0,500):'')||mensagem(f,'falha','Não foi possível receber o envio. Tente novamente.'));err.codigo=r.codigo;err.rejeitado=r._http>=400&&r._http<500&&r._http!==409&&r._http!==429;throw err;}return r;});}
  enviar(false).then(function(r){out.textContent=r.mensagem||mensagem(f,'sucesso','Contato registrado.');if(!r.aceito){fecharReserva(s);return;}
   s.primeiraEnviada=true;s.alterouAbandono=false;if(s.recusado){diagnostico(f,'envio',[],r.record_id);s.recusado=false;s.camposRecusados={};formulariosRecusados.delete(f);}
   if(etapa===1){evento(f,'aceito',{formulario:f.dataset.f3baseFormulario,record_id:r.record_id,correlacao:r.correlation_id,linkedin_conversion_id:r.linkedin_conversion_id,transporte:r.transporte,conversao:r.conversao,method:r.method,duplicado:r.duplicado,contexto_teste:s.teste,classe_trafego:r.classe_trafego,superficie:s.carga.get('superficie'),continuacao:r.continuacao,etapas_restantes:r.etapas_restantes||[],url:r.url||'',whatsapp_estado:r.etapa_pendente?'aguarda_complemento':'disponivel'});}
   else{evento(f,'complemento-aceito',{formulario:f.dataset.f3baseFormulario,record_id:r.record_id,revisao:r.revisao_complemento,duplicado:r.duplicado,pulado:r.pulado});if(r.pulado){evento(f,'etapa-pulada',{formulario:f.dataset.f3baseFormulario,etapa:2});}}
   if(etapa===1&&r.etapa_pendente){s.urlConfirmada=r.url||'';s.continuacao=r.continuacao;s.revisao=r.revisao;s.carga=null;s.iniciado=true;mostrarEtapa(f,2);b.textContent=mensagem(f,'concluir','Concluir e continuar');var skip=document.createElement('button');skip.type='button';skip.dataset.f3basePular='1';skip.textContent=mensagem(f,'pular','Pular e continuar');skip.addEventListener('click',function(){submeter(f,true);});if(f.dataset.mostrarPular!=='0'){b.after(skip);}out.textContent='Contato registrado. Você pode acrescentar informações ou pular esta etapa.';dialogo(f,s);out.focus();return;}
   s.aceito=true;b.hidden=true;f.querySelectorAll('[data-f3base-pular]').forEach(function(x){x.remove();});botaoContinuar(f,s,r,out);novoEnvio(f,s,b,out);if(r.method==='whatsapp_formulario'&&f.dataset.whatsappAutomatico==='1'&&r.url){continuar(f,s,r.url,true);}else{fecharReserva(s);}if(r.redirecionar){location.assign(r.redirecionar);}
  }).catch(function(err){if(etapa===2&&s.urlConfirmada&&f.dataset.whatsappAutomatico==='1'){continuar(f,s,s.urlConfirmada,true);}else{fecharReserva(s);}out.textContent=err.name==='AbortError'?mensagem(f,'nao_confirmado','O envio ainda não foi confirmado. Tente novamente.'):(err.name==='TypeError'?mensagem(f,'conexao','Falha de conexão. Tente novamente.'):err.message)||mensagem(f,'conexao','Falha de conexão. Tente novamente.');if(etapa===2){out.textContent=mensagem(f,'complemento_nao_confirmado','Seu contato inicial está salvo. As informações adicionais ainda não foram confirmadas; você pode tentar novamente.');botaoContinuar(f,s,{url:s.urlConfirmada,method:'whatsapp_formulario'},out);}if(err.rejeitado){s.carga=null;}out.focus();evento(f,'erro',{formulario:f.dataset.f3baseFormulario,codigo:/^[a-z0-9_]{1,64}$/.test(err.codigo||'')?err.codigo:'envio_nao_confirmado',etapa:etapa});}).finally(function(){s.enviando=false;b.disabled=false;f.querySelectorAll('[data-f3base-pular]').forEach(function(x){x.disabled=false;});f.removeAttribute('aria-busy');});
 }
 document.addEventListener('input',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(f){validarGrupo(f);}});
 document.addEventListener('submit',function(e){if(e.target.matches('[data-f3base-formulario]')){e.preventDefault();submeter(e.target,false);}});
 var adaptadores={};window.f3baseFormularios={fechar:function(f){if(f&&f.matches('[data-f3base-formulario]')){saidaTentativa(f);evento(f,'fechado',{codigo:'adaptador_fechado'});}},registrarAdaptador:function(nome,abrir){if(typeof abrir==='function'){adaptadores[nome]=abrir;}},etapa:function(f){return estado(f).etapa||1;}};
 window.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-f3base-abrir-formulario]');if(!a||e.defaultPrevented){return;}var nome=a.dataset.f3baseAbrirFormulario,f=Array.from(document.querySelectorAll('[data-f3base-formulario]')).find(function(el){return el.dataset.f3baseFormulario===nome;}),adapt=adaptadores[nome];
  if(!f||!window.f3baseContexto||window.f3baseContexto.destino(a.href)!=='whatsapp'){a.dataset.f3baseDiagnostico='formulario_ou_destino_indisponivel';return;}
  if(f.closest('[hidden]')&&!adapt){a.dataset.f3baseDiagnostico='adaptador_indisponivel';return;}
  if(adapt){f.dataset.f3baseAdaptador='1';}if(adapt&&adapt({formulario:f,gatilho:a})===false){a.dataset.f3baseDiagnostico='adaptador_recusou';return;}
  e.preventDefault();e.f3baseFormularioInterceptado=true;var s=estado(f);s.cta={texto:(a.textContent||'').trim().slice(0,160),destino:a.href,superficie:a.getAttribute('data-f3base-superficie')||'conteudo'};if(!s.etapa){mostrarEtapa(f,1);}if(!adapt){f.scrollIntoView({block:'center',behavior:'smooth'});var input=f.querySelector('.f3base-campo input:not([type="hidden"]):not(:disabled)');if(input){input.focus({preventScroll:true});}}evento(f,'dialogo-aberto',{formulario:nome,superficie:s.cta.superficie});
 },true);
 var seletorFormulario = '[data-f3base-formulario]';
 function iniciarFormulario(form) {
  if (form.isConnected && !estados.has(form) && form.elements && form.elements.submissao && form.elements.token) {
   mostrarEtapa(form, 1);
  }
 }
 function iniciar() {
  document.querySelectorAll(seletorFormulario).forEach(iniciarFormulario);
 }
 if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', iniciar); }
 else { iniciar(); }

 if (window.MutationObserver) {
  new MutationObserver(function (alteracoes) {
   alteracoes.forEach(function (alteracao) {
    if (alteracao.type === 'attributes') {
     if (alteracao.target.matches(seletorFormulario)) { iniciarFormulario(alteracao.target); }
     return;
    }
    // Os inputs obrigatórios também podem chegar depois do próprio form.
    var pai = alteracao.target.closest && alteracao.target.closest(seletorFormulario);
    if (pai && alteracao.addedNodes.length) { iniciarFormulario(pai); }
    alteracao.addedNodes.forEach(function (node) {
     if (node.nodeType !== 1 || !node.isConnected) { return; }
     if (node.matches(seletorFormulario)) { iniciarFormulario(node); }
     if (node.firstElementChild) { node.querySelectorAll(seletorFormulario).forEach(iniciarFormulario); }
    });
   });
  }).observe(document.documentElement, {
   childList: true, subtree: true, attributes: true, attributeFilter: ['data-f3base-formulario']
  });
 }
}());
