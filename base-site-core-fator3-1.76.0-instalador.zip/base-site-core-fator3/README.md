# Fator3 Site Core 1.76.0

Requer WordPress 7.1.4 e PHP 8.3. Atualização direta da 1.75.1. Contrato administrativo 8.37.0. Consulte docs/DOCUMENTACAO.md e docs/RELEASE-1.76.0.md.


