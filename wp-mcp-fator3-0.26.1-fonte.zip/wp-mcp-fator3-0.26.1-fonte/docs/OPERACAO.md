# Fator3 MCP 0.26.1 — manual de operação

> Referência vigente: MCP 0.26.1, base imediata 0.25.0. Leia MUTATION-AUDIT e RELEASE-0261 para antes/depois no Registro. Referências anteriores abaixo são históricas. Matriz recebida: Core 1.46.1, Google 0.17.0, Meta 0.4.1 e LinkedIn 0.5.0. Mínimos: WordPress 7.1.2 / PHP 8.3.6. Evidências executadas no relatório externo.

Este manual descreve o runtime 0.26.1. O relatório externo registra o estado de validação da entrega. O guia/relatório externo registra os testes executados e os limites de cobertura. Os contratos completos são consultados por Get Ability Info ou `system/guide` com `ability`.

## Conexão e descoberta

URL principal: `https://SEU-SITE/wp-json/mcp/wp-mcp-fator3`. A URL `https://SEU-SITE/wp-json/mcp/wp-mcp-ultimate` continua sendo um alias do mesmo serviço. Não é necessário recriar conectores existentes. Em instalações sem permalink, use `?rest_route=/mcp/wp-mcp-fator3`.

O transporte mantém suporte às revisões MCP implementadas na base, inclusive os clientes com sessão e o modo sem sessão. Uma sessão antiga sem prova da versão efetivamente negociada recebe HTTP 404 para o cliente inicializar outra, preservando a credencial. Não são removidas sessões nem o servidor próprio do Elementor.

Comece por `system/capabilities`, Discover Abilities e Get Ability Info. Há três metatools principais: descoberta, informação e execução. O executor de leitura é optativo conforme política. Não há necessidade de expor centenas de tools individuais. Executores que chamam outra habilidade por nome não podem ser alvos, inclusive executores de outros provedores: `ability_executor_forbidden`.

Discovery aceita filtros, paginação e `if_catalog_sha256`; `unchanged:true` significa que o catálogo efetivo daquela conexão não mudou. Permissões dependentes do alvo aparecem como `requires_input`, e serão conferidas com os parâmetros reais. Leia o schema; não deduza o contrato a partir do título ou de uma versão anterior.

## Perfis e credenciais

Manutenção é o perfil administrativo pleno: observa capacidades WordPress, permissões PHP/sistema operacional, constantes de bloqueio e estado geral do canal. Não exige raízes por conexão, flag adicional de SQL ou permissão adicional de exportação. Quem instala código e administra o banco pode acessar dados sensíveis; redação de resposta evita exposição acidental e não isola esse administrador.

A base imediata de atualização é a 0.24.0, além de instalação limpa, sem trava por versão de origem. As políticas atuais explícitas, prazos e revogações são preservados. Identidades novas sem configuração ficam Sem acesso. Não há importação de credenciais de opções, transientes ou pacotes predecessores, congelamento de catálogo antigo ou elevação automática de perfil.

OAuth usa concessões persistidas e tokens vinculados ao site, recurso e escopo. Consentimento e renovação conservam o perfil autorizado; revogar o grant encerra sua família de tokens. Perfis reconhecidos: Leitura, Conteúdo, Manutenção e Personalizado. Valores desconhecidos são recusados.

## Confirmação, conflitos e resultados

Resultados incluem `success`, código estável de erro, identificação da operação quando pertinente e estado observado do efeito. No MCP, falha de tool usa `isError:true` e conteúdo estruturado. `data` de WP_Error é preservada com redação por chave. `applied:null` significa efeito incerto, não autorização para repetir.

Operações em duas fases fornecem uma identidade `phase:…` consultável por `operations/status`, inclusive se a resposta de confirmação se perder. Para operações em duas fases, faça a chamada sem `confirm_token`, examine a prévia e repita os mesmos parâmetros com o token. Ele se vincula à intenção, conexão e pré-imagem, e expira em 600 segundos. SQL, lotes, restauração, mudanças de endereço e autorrestrição continuam em duas fases. `confirm:true` dispensa a segunda chamada apenas em exclusões tipadas admitidas para Manutenção; não dispensa uma revisão/hash fornecida.

`expected_sha256`, `expected_revision` e revisões de política impedem sobrescrever uma pré-imagem diferente. Os locks de arquivo cobrem leitura, comparação, backup e substituição entre operações cooperantes. O tempo padrão `lock_wait_seconds` é 2 segundos; dois agentes no mesmo site devem tratar conflitos e reler antes de decidir. Editores externos que não usam o mesmo lock continuam podendo alterar arquivos.

## Arquivos, busca e transferências

`files/read` conserva bytes binários em base64 também na leitura integral. Use `offset_bytes` para iniciar em um byte arbitrário; o cursor opaco continua disponível. Cursor e offset incompatíveis são recusados. `tail_lines`, `offset`, `grep` e busca por `grep_regex` atendem logs/textos; `files/search` aceita arquivo único ou diretório. Erros de PCRE são identificáveis.

`files/write` recusa conteúdo textual para extensões binárias; use `content_base64`. Arquivos PHP têm validação sintática, pré-imagem, escrita atômica e sondas. Em Manutenção, `probe:false` é uma escolha explícita que pula apenas as sondas de execução; a resposta registra isso, e a operação concluída não é revertida como se estivesse abandonada.

`files/move`, `files/copy`, `files/delete`, `files/rmdir`, patch e restauração preservam seus contratos. Rótulos `label`/`rotulo` identificam backups; aliases conflitantes são recusados. O armazenamento `f3-mcp-private` não é uma pasta comum disponível por files/*: consulte `system/health` e os serviços de backup/exportação.

O limite padrão por arquivo é 16 MiB. `system/settings-update` ajusta `file_bytes` entre 1 MiB e 1 GiB, sujeito aos recursos físicos; a conexão pode ter limite próprio. Isso não aumenta o tamanho máximo de uma resposta nem elimina limites PHP. Para 20 MiB, configure pelo menos 20 MiB e use `files/upload-create`, partes de 256 KiB, `files/upload-part` e `files/upload-finalize`. SHA-256 e tamanho total são conferidos; partes repetidas idênticas são aceitas. Cancelar remove as partes da transferência, sem desfazer um arquivo já concluído.

`files/archive` compacta a origem incluindo seu nome. `files/extract` valida o ZIP e prepara o destino antes de substituir. `overwrite:true` substitui a árvore inteira, sem mesclar. Links, traversal, colisões, CRC inválido e expansão excessiva são recusados. `files/rollback-tree` usa o backup e recusa pós-imagem alterada. Limites adicionais do inventário de recuperação: 20.000 entradas e 256 MiB por árvore.

## Backups e recuperação

Backups e artefatos são privados, com envelope PHP e metadados assinados. A exportação contém valores originais quando destinada a recuperação, inclusive segredos. Base64 não é criptografia. `backups/list` permite rótulo/data. Retenção é explícita, com prévia e seleção congelada; instalar a versão não limpa pendências automaticamente.

A sentinela em mu-plugins preserva a recuperação fora da pasta substituível. Não a remova enquanto houver operação pendente. Rollback de arquivos/plugins/temas verifica a pós-imagem para não apagar mudança posterior. Restauração de arquivos não desfaz migrações arbitrárias realizadas por código de um plugin/tema.

`system/health` apresenta estado e localização do armazenamento, recuperação, cron e sondas. Consulte o código e o estado de erro antes de repetir. Uma operação interrompida pode precisar de recuperação explicitamente confirmada.

## Plugins, temas e atualização do canal

`plugins/upload` e base64 aceitam hash do ZIP, slug esperado, overwrite e ativação explícita. Omissão de `activate` equivale a false. A substituição cria pré-imagem e devolve versões/ativação antes e depois. Plugins que já estavam ativos permanecem ativos ao atualizar, com verificação em requisição nova e sondas anônimas. `plugins/rollback` recupera a árvore anterior. A exclusão verifica ausência e limpa somente a entrada correspondente em auto-update; limpeza de registro de uninstall não executa o callback.

A atualização da 0.25.0 pode usar `plugins/upload` com o instalador 0.26.1, `expected_sha256`, `expected_slug:wp-mcp-fator3` e `overwrite:true`; confira a evidência de self-upload no relatório desta entrega antes da frota. Instalação limpa usa o mesmo instalador no wp-admin. A inicialização por estado substitui os migradores antigos; o schema de dados permanece 2. Diários e sentinelas existentes não são apagados automaticamente.

`plugins/list` permite projeção `fields`/`campos` e filtro `prefixes`/`prefixo`. `themes/upload`, `themes/activate`, `themes/update`, `themes/delete` e `themes/rollback` acrescentam pré-imagem, identidade, requisitos, pai/filho e recuperação. O tema em uso ou seu pai não pode ser excluído; tema com dependentes também é recusado.

O canal aceita fontes HTTPS de manifesto em `system/settings-update.update_channels`. Configurá-las não liga atualização automática. `Update URI: https://fator3.com.br/plugins/wp-mcp-fator3` identifica o pacote no mecanismo de atualização próprio; não é um feed publicado. O manifesto precisa apontar para bytes reais verificáveis por SHA-256. Não substitua Core/Google atuais pelos pacotes antigos usados em testes históricos.

## Leitura SQL e exportação de resultados

Em Manutenção, `db/query` aceita SELECT, WITH terminado em SELECT, JOIN, UNION, views do banco do site, subconsultas, agregações, CASE, janelas, funções JSON/data e leitura pertinente de information_schema. Há uma única instrução, sem escrita nem construções com efeito colateral. O SQL original é preservado; somente o LIMIT externo é limitado para a resposta interativa.

A resposta interativa tem até 2.000 linhas e 16 MiB. `timeout_seconds` é limitado pelo tempo efetivo do processo. Para o resultado completo, use `db/query-export` com `format:jsonl` ou `csv`, `gzip` opcional e `async:true` por padrão. A operação materializa um snapshot de leitura, informa contagem/bytes/SHA-256 e só publica artefato completo. `operations/status` recebe `operation_id`; `db/export-part` lê blocos base64 de até 256 KiB com offset/hash. `db/query-page` pagina JSONL sem gzip por uma chave sequencial criada no snapshot, sem OFFSET sobre tabelas vivas.

Jobs dependem do loopback ou WP-Cron, sem daemon novo. `db/export-cancel` solicita cancelamento cooperativo. Snapshot de worker encerrado não é retomado como se ainda existisse: o estado aponta interrupção e exige nova exportação. Artefatos de consulta expiram em sete dias. Espaço/tempo insuficientes geram falha sem disponibilizar arquivo parcial como concluído.

A redação usa origem da coluna, chave projetada e predicado exato comprovado. Aliases de colunas secretas continuam redigidos. `option_value`/`meta_value` com chave ambígua são redigidos conservadoramente; `redacted` informa célula, razão e origem. Transformações arbitrárias em SQL administrativo não têm garantia de impedir inferência. Respostas binárias preservam encoding explícito.

## Escrita SQL, dump e troca serializada

`db/execute`, `db/batch` e `db/search-replace` usam `selection-guard/2`, descrito integralmente na seção **Contrato da guarda SQL** deste manual. A seleção e suas dependências são verificadas sob locks MySQL, com token de dez minutos, dump privado (integral por padrão) e recibo persistido. A guarda não é uma impressão do banco inteiro. `database_conflict` exige revisão de nova prévia; `sql_guard_unavailable` recusa formas sem prova completa antes de escrever. Tokens SQL pendentes conservados na 0.17.0 continuam válidos até o prazo original e mantêm o escopo integral quando omitido.

DML aplica uma transação InnoDB; DDL é operação separada, com snapshot para recuperação e sem promessa de rollback transacional global. `operations/plan` não inclui SQL.

`db/export` produz SQL gzip privado de tabelas selecionadas ou do banco. Inclui schema, dados, índices, views em ordem de dependência, triggers e manifesto. Bytes binários, NULL e Unicode são preservados. Banco com rotinas/eventos SQL não suportados é recusado como dump completo; nenhum artefato parcial recebe esse rótulo. Dumps de recuperação não expiram automaticamente.

`db/restore` exige artefato íntegro, prévia do destino e confirmação; cria backup anterior e diário fora do banco afetado. O estado MCP corrente é preservado por inventário explícito (`preserved-state/1`), inclusive revogações, senhas de aplicação e sessões WordPress. Options `f3_mcp_google_*` e a tabela Google pertencem à fotografia restaurada. Suspenda e reconcilie executores pelos controles dos seus donos: restauração não desfaz efeitos já enviados a APIs externas. Diários e recibos existentes na 0.17.0 são preservados; novos diários incluem `preserved_state_manifest`. Não é uma transação global. O controlador em mu-plugins mantém wp_options disponível durante a importação e, após abandono do processo, tenta restaurar a pré-imagem na requisição seguinte. Consulte `db/recovery-status` e `operations/status`; falha de recuperação permanece explícita. Backups de mutação com pós-imagem divergente exigem revisão e nova prévia com `allow_changed_destination:true`. Não repita cegamente uma restauração incompleta.

`db/search-replace` faz troca literal em strings, JSON e arrays serializados, com filtros `tables`/`columns`, amostras redigidas e lotes por chave primária dentro de uma transação. Não instancia objetos PHP. Objetos serializados e alterações em chave primária são apontados e preservados; tabela selecionada sem chave primária causa recusa antes da confirmação. Alterações de chave usam SQL explícito. Contagens por tabela/coluna e backup acompanham o resultado. Confira `skipped`, mesmo quando a operação conclui.

`db/schema` com `contar:true` acrescenta `rows_exact`, mantendo distinta a estimativa.

## Conteúdo e mídia

Patch de post/página exige seleção única por padrão, aceita limite também no modo regex e suporta `expected_revision`. Readback inclui SHA-256 e CHAR_LENGTH; transformação observada é indicada por `content_filtered`. As descrições usam `parent`; `parent_id` é alias compatível, com recusa quando diverge.

`content/edit-block` não descarta filhos silenciosamente quando recebe `inner_html`; use `children` para substituir a árvore. `featured_media` e revisão final consideram as gravações pertinentes. Revisões e getters permitem projeção sem trazer conteúdo desnecessário.

`content/delete-post` explicita o comportamento real de lixeira para tipos de post e exclusão permanente. `media/regenerate` e `media/set-site-icon` usam as APIs nativas e verificam metadados/recortes. Não exigem mu-plugin descartável.

## Configuração, cron e cache

Em Manutenção, `options/update` administra options fora do estado interno do canal, com backup e readback. `stylesheet` usa `themes/activate`; `template`/`current_theme` orientam para essa seleção nativa. `active_plugins` orienta para as habilidades de ativação/desativação para preservar hooks. Nomes internos f3_mcp_* orientam para `system/settings-update`. Segredos podem ser gravados, mas não são repetidos em resultado/log. `auto_update_plugins` é administrável; instalar o canal não a habilita automaticamente.

`site/set-admin-email` grava o e-mail autorizado e limpa confirmação pendente; não comprova entrega de e-mail. `site/set-language` instala pacote oficial compatível antes de mudar WPLANG. `roles/list`/`roles/update` usam APIs nativas e confirmação. `site/set-address` faz prévia, exige destino alcançável e permite troca serializada de URLs, com verificação e reversão. Não cria DNS/TLS.

Permalink, category_base e tag_base são regenerados pelo serviço nativo; `rewrite/flush` executa flush soft e devolve comparação de regras. Não é necessário editar rewrite_rules por SQL.

`cron/list` mostra hook/timestamp/argumentos/recorrência e revisão. `cron/run` executa somente evento existente conferido, sob lock cooperativo e contexto cron sem usuário logado; conclusão do callback informa `business_result:unknown`. O resultado inclui `operation_id`; `operations/status` conserva conclusão ou efeito incerto após interrupção. Não é um executor de nomes de funções PHP. `cron/schedule` e `cron/unschedule` verificam a agenda nativa. Dois disparos cooperantes são serializados; callbacks com efeito externo precisam de verificação própria.

`system/delete-transient` remove chave exata e identifica backend. `system/cache-flush` limpa cache de objeto, não cache de página. `system/health.cron` informa wp_cron_desabilitado, eventos_vencidos e ultimo_disparo. Site sem disparo WP-Cron pode acumular agenda vencida.

## Sondas e limites da evidência

`system/probe` faz requisições anônimas ao próprio site, sem cookie, com asserções e informação de cache. Home/REST recebem verificação comum após operações protegidas. Uma medição de TTFB não identifica sozinha o tempo de geração PHP ou cache frio. Só considere `http_protection_tested` quando houver evidência efetiva da sonda.

Os documentos operacionais Markdown e o catálogo JSON bruto ficam no pacote fonte/documentação externa. O instalador fornece esta ajuda por recurso PHP protegido, lido por `system/guide` e wp-admin; não depende de regras manuais de .htaccess para esconder o manual. Atualização substitui a árvore do canal e remove os documentos residuais da distribuição anterior com pré-imagem.


## Contrato de integração do servidor


Contrato canônico L01/L02/I04/I05. Provedor `wp-mcp-fator3`; política de extensão continua `policy_contract:1`.

Identidade constante: `server_id:wp-mcp-ultimate-server`, `route:/mcp/wp-mcp-fator3`, `aliases:[/mcp/wp-mcp-ultimate]`. Slug, Text Domain, Update URI e nomes dos metatools permanecem.

Filtros públicos: `f3_mcp_create_default_server(bool $enabled, array $identity)` e `f3_mcp_default_server_config(array $config, array $identity)`. O primeiro usa true como default e compartilha a decisão entre categoria, habilidades, fábrica e diagnóstico. O kill-switch continua controlando autorização, independentemente do registro do servidor.

O segundo aceita contribuições em `tools`, `resources`, `prompts`; preserva defaults e os três metatools. Nomes novos precisam existir, estar públicos, ter tipo correto e pertencer a provedor aderente. Retornos inválidos preservam defaults e registram códigos sanitizados. ID, endpoints, autenticação e handlers não podem ser substituídos. Contribuições repetidas são deduplicadas. Este SDK é cooperação entre plugins PHP; não é isolamento contra PHP malicioso.

`Fator3\McpFiles\ServerContract::capabilities()` informa contrato, versão, identidade e disponibilidade do hook. `::status()` é observação local, sem HTTP ou montagem recursiva: `core_loaded`, `server_enabled`, `channel_enabled`, `registry_checked`, `server_registered`, `tools_ready`, `endpoints`, `errors`. Antes de registro, desconhecidos são null. `external_connectivity_tested:false` distingue isso de conectividade externa comprovada. A fachada não devolve credenciais ou identidades de conexões.

Filtros `mcp_adapter_*` não controlam o núcleo embutido. O ciclo é `f3_mcp_adapter_init`. O mapa completo está em `server-hook-map.json` no fonte; os demais hooks são internos, sem estabilidade de SDK prometida. Hooks da Abilities API e `f3_mcp_register_providers` continuam compartilhados. O Fator3 não altera `elementor_mcp_enabled`, não desliga o servidor Elementor e continua descobrindo seus recursos públicos com URI em `meta.mcp.uri`.

Google 0.8.2 conserva `google/mcp-read` e `google/mcp-write` por um adaptador do MCP que verifica os metadados públicos e o provedor. Não chama APIs privadas Google. A contribuição Google ao filtro próprio é deduplicada. O executor opcional de leitura do canal também é preservado.

Somente uma chamada direta de ferramenta registrada no servidor Fator3, autenticada por OAuth/senha de aplicação, estabelece contexto interno de entrada. As duas bridges Google têm admissão explícita nesse contexto, verificando perfil e permissão nativa. Leitura não admite a bridge de escrita; Personalizado precisa permitir a bridge e o alvo final. O Google conserva seus gates e confirmações. Qualquer executor usado como alvo retorna `ability_executor_forbidden`, incluindo bridges Google e `mcp-adapter/execute-ability`. Parâmetros do cliente e outra porta MCP não fabricam esse contexto.

A integração PHP Core → Google permanece fora do transporte MCP. Não recebe perfil sintético, não depende de sessão MCP, nem ganha bypass pelo nome do provedor. O catálogo reflete as abilities realmente registradas pelo complemento instalado.


## Contrato da guarda SQL


Guarda preservada de 0.15.0; extensão M38B do escopo de backup. `db/execute`, `db/batch` e `db/search-replace` usam este protocolo. `db/restore` verifica o destino das tabelas presentes no manifesto; o dump integral conserva o alcance global. SQL não é aceito por `operations/plan`.

## Duas fases

Chame sem `confirm_token`. A resposta é prévia, com `applied:false`, token, `operation_id` e validade de 600 segundos. Repita os mesmos parâmetros com o token. A guarda privada está vinculada à intenção, credencial, usuário, site e contrato. Uma confirmação concluída devolve o recibo com `replayed:true`; uma operação iniciada sem recibo final devolve `operation_uncertain` e nunca se reaplica automaticamente. Consulte `operations/status`.

Tokens SQL pendentes conservados na 0.17.0 preservam intenção, identidade, guarda, prazo e escopo integral quando omitido. Recibos concluídos e estados incertos continuam consultáveis. A atualização não captura novamente credenciais históricas.

`guard_contract:selection-guard/2`; `guard_scope:selected_rows_and_dependencies` ou `ddl_objects`; `target_tables`; `selected_rows`; `selection_exact`; `backup_scope:database` ou `selected_tables` em db/execute elegível; `backup_tables`. O antigo inventário global `summary.tables` deixa de ser a guarda de DML. `statement_previews.predicted_affected_rows` vem da simulação sequencial; `affected_rows` na aplicação vem do MySQL real. db/execute apresenta 20 linhas por padrão (`limit_preview`, máximo 200); demais prévias apresentam no máximo 200 linhas; a guarda cobre a seleção integral dentro do orçamento.

## SQL aceito e limites explícitos

| Forma | Cobertura |
|---|---|
| UPDATE/DELETE | Um alvo físico InnoDB, predicados, expressões determinísticas, alteração de chave, NULL, binário, Unicode; chave primária ou única não nula |
| JOIN | INNER JOIN, um alvo de escrita, sem duplicar identidade alvo; todas as linhas participantes influenciam a guarda |
| Subconsultas | Um nível em WHERE: IN e EXISTS; fontes físicas explícitas e predicado; fontes recebem suas próprias leituras bloqueantes |
| ORDER BY/LIMIT | LIMIT requer ORDER BY em colunas diretas contendo a identidade completa, inclusive no INSERT SELECT; seleção sem ordem total é recusada |
| INSERT/REPLACE | Lista explícita de colunas, VALUES; todas as chaves únicas, colisões e ausências; upsert com ON DUPLICATE KEY UPDATE |
| INSERT SELECT | Uma fonte física diferente do destino, projeção determinística e filtros; sem agregação/janela/UNION |
| Lote | Até 100 instruções DML; dependências sequenciais simuladas. Cada instrução tem uma fonte física; JOIN/subconsulta em lote e identidade autoatribuída em lote exigem reescrita explícita |
| DDL | CREATE TABLE, ALTER TABLE, DROP TABLE e TRUNCATE TABLE sobre um objeto. Sem IF EXISTS, RENAME, FK, PARTITION, tablespace, CREATE SELECT/LIKE ou rotinas |
| Search-replace | Seleção literal de linhas/colunas, chave primária; preserva objetos serializados e chaves primárias; valores únicos resultantes participam da guarda. Tabela selecionada sem chave causa recusa antes do token |

Expressões admitem aritmética e funções determinísticas declaradas no planejador, como CONCAT, REPLACE, COALESCE, IFNULL, CAST, CONVERT, HEX, UNHEX e funções JSON de valores. Funções não classificadas, funções temporais aleatórias, variáveis de sessão, views, tabelas sem identidade estável, índices únicos parciais/funcionais, colunas geradas/ON UPDATE, triggers e FKs não modeladas recebem `sql_guard_unavailable`, sem token utilizável e sem escrita. Não há fallback para a impressão do banco inteiro. UPDATE de vários alvos e autorreferência à mesma tabela por outro alias também são recusados. Consulte o erro `reason`; não altere dados para contornar a recusa.

A implementação materializa cópias temporárias das tabelas envolvidas para calcular o efeito sequencial, sem DML de ensaio na base real. Essa materialização é limitada a 100.000 linhas por leitura, 64 MiB acumulados e 30 segundos. O orçamento inclui cópias intermediárias e metadados, portanto uma tabela grande pode esgotá-lo mesmo com seleção pequena. Nesse caso retorna `sql_selection_budget`; a seleção nunca é truncada e assinada como completa. Use operações tipadas ou reduza a operação. O tokenizador admite até 8.192 tokens por instrução. Essa é uma limitação operacional explícita desta implementação.

## Concorrência, backup e resultados

Pré-imagens completas e seleções são assinadas com HMAC privado, preservando tipo estrutural, bytes e NULL. O contador corrente AUTO_INCREMENT não participa da guarda DML; o atributo da coluna permanece. DDL conserva o contador no schema de seu alvo.

A confirmação usa uma conexão MySQL fixa e REPEATABLE READ. Antes de criar a visão consistente, lê com FOR UPDATE as seleções, dependências, identidades e intervalos pertinentes. Os locks impedem alterações externas durante backup e escrita. Conforme índices e plano de execução, o InnoDB pode bloquear vizinhos examinados. Uma mudança fora da seleção entre prévia e confirmação não cria conflito só por pertencer à mesma tabela. Leituras de dependências são conservadoras dentro dos predicados modelados, especialmente fontes de IN/EXISTS.

O dump de recuperação é integral por padrão. db/execute admite selected_tables nas condições descritas em SQL-RETENTION.md. Ambos são privados e contêm valores originais, inclusive segredos. É produzido por leituras consistentes, sem FOR UPDATE em todas as tabelas. Falha de gravação/verificação cancela a aplicação. O volume do dump pode dominar a duração da operação; não equivale ao escopo da guarda. DML falha por rollback da transação, sem restaurar automaticamente o banco inteiro. DDL exige recuperação por snapshot e usa trava do objeto na conferência final. Restauração integral é outra operação explícita.

`database_conflict` inclui `conflict:true`, `applied:false`, `changed:false`, e `conflict_reason` (`target_rows_changed`, `selection_changed`, `dependency_changed`, `schema_changed`, `unique_key_changed`). Faça nova prévia e revise a diferença. Timeout SQL (`database_lock_timeout`), deadlock (`database_deadlock`), orçamento, backup indisponível e expiração são erros separados. A espera de locks SQL é 5 segundos; não é o `lock_wait_seconds` de arquivos.

`changed` depende das instruções efetivamente executadas. Não compara todo o banco após a escrita. O recibo inclui `statement_results`, `backup_id`, `readback`, `atomic` e estado persistido. Perda do recibo depois de commit deixa a operação incerta, com backup e ID para investigação. Não interprete `applied:null` como falha sem efeito.

Redação na prévia evita exposição acidental de tokens e colunas sensíveis. Um administrador com instalação de código e SQL pleno não fica isolado dos dados por essa redação. Guarde os backups com o mesmo cuidado dedicado ao banco original.

## Contratos dos complementos

As ferramentas diretas Google conservam seus parâmetros nativos, inclusive `label`. Os aliases de backup do MCP não reescrevem parâmetros de negócio de outros provedores. O SDK local e a distinção entre ferramenta direta e executor aninhado estão documentados em `SERVER-INTEGRATION.md`.

## Compatibilidade e ciclo do servidor

A 0.25.0 atende instalação limpa e atualização da 0.24.0, sem trava por versão de origem ou por presença, versão ou ordem dos companheiros. Core 1.43.0, Google 0.16.0, LinkedIn 0.4.1 e Meta 0.4.1 formam a matriz de referência; não representam uma lista de versões permitidas. Operações dependentes continuam exigindo suas capacidades e contratos efetivos. Options falsas/vazias, prazos, revogações, recibos e confirmações pendentes da base aceita são preservados.

A primeira entrada REST/CLI conclui o registro público de habilidades após init e antes de compor tools, resources e prompts. Chamadas reentrantes durante registro/configuração não publicam um servidor parcial. ServerContract::status continua observacional. O aquecimento do Google permanece válido, mas não é necessário para corrigir o ciclo do MCP. Um erro de criação é diagnosticado e não marca a inicialização como concluída.

## Retenção dos dumps SQL

`backups/list` e `backups/prune` aceitam category: `backups` (padrão anterior), `sql_mutation` (dumps automáticos comprovados) e `sql_artifacts` (todos os artefatos SQL inventariados). Não use backups/export para ler SQL: use `db/export-part` e `db/restore`. A listagem mostra metadados, nunca as linhas originais. Exige manage_options e perfil Manutenção, além do canal habilitado.

A reconciliação de artefatos privados atuais avança em lotes de até 200 artefatos. Repita backups/list até inventory_complete:true. Origem não comprovada vira unknown; pares incompletos não são restauráveis. Saúde não faz dump, poda ou reconciliação. storage.sql_artifacts mostra contagens e bytes indexados, política e elegibilidade observada; eligibility.complete:false e inventory_complete:false indicam cobertura parcial. A observação de elegibilidade examina no máximo 1000 registros e protege o acervo se o diário de recuperação exceder 1000 registros ou for inválido.

Política inicial: idade maior que 30 dias OU exceder 20 dumps automáticos, preservando ao menos os três mais recentes e todas as referências ativas. Ajuste em Configurações → Retenção dos backups SQL ou system/settings-update.sql_retention (duas fases): older_than_days de 1 a 3650, max_count de 1 a 10000, min_keep de 0 a max_count. A política não executa exclusão automática.

```json
{"ability_name":"backups/prune","parameters":{"category":"sql_mutation","dry_run":true}}
```

Confira selection, blocked, selected_bytes e expected_selection_sha256. Aplique repetindo a categoria e enviando dry_run:false e o hash. Seletores repetidos precisam ser idênticos aos da prévia. Alternativamente, use artifact_ids com IDs completos de 32 caracteres; não misture IDs e política. ID explícito permite selecionar manual_export, restore_preimage e unknown completos, mas não ignora referências ou integridade.

Seleções são privadas, vinculadas ao usuário/conexão/site e válidas por 600 segundos antes do início. Novos arquivos não entram numa seleção existente. Criação, leitura e restore compartilham lock; poda é exclusiva. A espera padrão é 2 segundos. artifact_in_use e backup_selection_conflict não autorizam forçar a remoção. Operações em curso/incertas, diários pendentes e prévias válidas de restore protegem o dump. Recibos concluídos não impedem retenção para sempre.

Quarentena e remoção persistem por componente. backup_prune_partial retorna removed_bytes efetivamente retirados e remaining_count; retome com a mesma categoria/hash. O recibo concluído é reapresentado sem nova seleção. Tombstones preservam o histórico; operations/status.backup informa disponibilidade ou removed sem reaplicar SQL. Bytes retirados não equivalem à variação de espaço livre do volume.

## Backup SQL da tabela alvo

Somente db/execute admite backup_scope:selected_tables: uma instrução DML, uma tabela base InnoDB com identidade estável, sem outras fontes, joins, views, triggers ou chaves estrangeiras não modeladas. A tabela vem da análise SQL. DDL, db/batch e db/search-replace mantêm backup integral. Escopo reduzido inelegível recebe backup_scope_unsupported na prévia, sem escrita. Omitir o campo conserva database, inclusive em confirmações preservadas na 0.17.0.

```json
{"ability_name":"db/execute","parameters":{"sql":"UPDATE wp_exemplo SET valor='novo' WHERE id=1","backup_scope":"selected_tables"}}
```

Substitua wp_exemplo pelo alvo real permitido; o exemplo não deve ser aplicado literalmente. A prévia informa backup_scope e backup_tables, vinculados à confirmação. O dump inclui a tabela inteira, contém valores originais e é produzido/verificado na mesma conexão protegida antes da escrita. Falha de backup impede mutação. A resposta inclui backup_id/artifact_id, backup_bytes e backup_contains_sensitive_values.

O restore escreve apenas as tabelas do manifesto e preserva o estado MCP corrente conforme preserved-state/1. A prévia declara restore_tables e restores_entire_tables:true: alterações posteriores da tabela podem ser perdidas. Atividade fora do manifesto não altera a guarda do destino. O restore cria pré-imagem integral de segurança, classificada restore_preimage; considere esse custo ao estimar economia.

## Excluir e restaurar papéis

roles/delete exige role; roles/restore exige role e backup_id. Ambos exigem manage_options, perfil Manutenção e prévia/confirm_token, nunca exclusão imediata por confirm:true. Recusam exclusão de administrator/editor/author/contributor/subscriber, default_role e papéis atribuídos a qualquer usuário, inclusive usuários com múltiplos papéis. Códigos: role_protected, role_is_default, role_in_use, role_not_found e preimage_conflict.

```json
{"ability_name":"roles/delete","parameters":{"role":"papel_personalizado"}}
```

Após revisar a prévia, repita com confirm_token. A confirmação relê uso/default/capacidades, cria backup do alvo e verifica o estado gravado. O recibo informa role, persisted, changed, backup_id e operation_id. Uma confirmação concluída pode ser repetida sem novo efeito.

roles/restore restaura só o papel escolhido, verifica a pós-imagem esperada e faz backup da alteração atual. Restaurar a criação de um papel significa removê-lo, sujeito às mesmas guardas. Exige o contrato de snapshot atual, com papel, pré-imagem e pós-imagem explícitos. Não atribui usuários.

roles/update calcula a alteração dentro do lock. options/update de user_roles aplica as mesmas recusas antes da primeira escrita; use roles/delete/restore para operações pontuais. As rotas de usuários e alteração de default_role compartilham a coordenação. Escritores externos/SQL administrativo não cooperantes continuam fora do lock MCP; persistência incerta exige investigação. Capacidades humanas não reescrevem concessões do consumidor PHP Google.

## Recuperação conjunta dos provedores

Consulte f3base/operacao-recuperacao-ler e google/recovery-status. Prepare Core com f3base/operacao-recuperacao, acao:preparar e geracao_esperada corrente; prepare Google com google/recovery, action:prepare. Aguarde pronto_para_restaurar:true do Core e ready_for_restore:true do Google. Essas barreiras não suspendem todo o WordPress nem processos externos.

Restaure somente após as duas guardas prontas. Releia ambas depois do restore: os arquivos de pausa fora do banco devem permanecer pausados. Reconcile options, concessões, conexões Google, jobs e contextos com o manifesto restaurado. Restauração de uma tabela de um provedor não comprova coerência de todo o seu estado. Não repita efeitos enviados às APIs.

Retome explicitamente cada provedor com geração atual: Google action:resume/expected_generation/acknowledge_reconciled:true; Core acao:retomar/geracao_esperada/reconciliacao_confirmada:true. Retomar um não retoma o outro. Core pode invalidar cursores/intenções/filas em tabelas não restauradas; registre esses efeitos como ações do provedor. Falha ou reconciliação incompleta mantém a pausa.

Core com sentinela ausente/divergente exige seu procedimento de recriação com precondicao_esperada e manter_pausado:true, seguido de preparar/drenar. O MCP não recria estado privado Core/Google. Use o guia incluído em cada pacote. Não atribua automaticamente f3base_ler_leads ou grants Google, nem fabrique sessão humana para o consumidor PHP.

## Inicialização da release

`ReleaseState` inicializa a persistência e registra `release-state/current`. O schema continua 2; uma instalação vazia o cria sem migradores intermediários. Não recria opções nem checkpoints históricos. Schema desconhecido recebe `mcp_schema_unsupported`; persistência indisponível recebe `mcp_initialization_failed`, contendo o canal com HTTP 503. Veja ATUALIZACAO.md.

## system/probe

`contexto_teste` é booleano e opcional. Se omitido, o cabeçalho opcional `X-F3Base-Teste` determina a classe (`1` = teste; `0` = não marcado). Sem ambos, sai explicitamente `0`, sem herdar cookie ou cabeçalho do solicitante. Se ambos estiverem presentes, devem concordar. Cabeçalhos são comparados sem distinção de maiúsculas/minúsculas.

```json
{"ability_name":"system/probe","parameters":{"contexto_teste":true,"paths":[{"path":"/","assert":{"status":200}},{"path":"/wp-json/","assert":{"status":200}}]}}
```

Resultados e amostras incluem `contexto_teste`, `classe_trafego:teste|nao_marcado` e `traffic_class_scope:outgoing_request`. Isso informa a marca enviada, não prova coleta, consentimento, gravação ou contagem pelo Core. A marca não concede permissões. `success:true` indica execução da ferramenta; confira também `passed`, as asserções e `cache_bypass_verified`.

Códigos de recusa: `probe_test_context_invalid` (tipo/valor inválido), `probe_test_context_conflict` (argumento e cabeçalho discordam), `probe_header_conflict` (duplicatas discordam) e `probe_header_forbidden` (cabeçalho não permitido ou injeção). Cookies e Authorization permanecem recusados. A marca acompanha GET, HEAD, repetições, redirecionamentos da mesma origem e teste de armazenamento privado; sair da origem é recusado.

Sondas internas de troca/recuperação de plugins, temas, arquivos PHP, árvores e endereços usam `contexto_teste:true`. O executor anterior ainda em memória durante um self-upload conserva seu contrato. A política de timeout e reconciliação da seção Verificação de pacotes vale para operações iniciadas pela 0.19.0.

O Core 1.25.0 reconhece o cabeçalho em `F3Base_Testes::resolver`. GET/HEAD da sonda não executa JavaScript nem envia um evento de navegador ao coletor de análise/comportamento. Portanto a ausência de evento nessas leituras não prova perda da marca. O MCP não fabrica métricas nem grava diretamente tabelas de medição do Core. A evidência da release distingue recepção da marca de persistência em métricas; encaminhamento separado ao Core trata essa lacuna do aceite solicitado.

## Recusa anônima MCP

GET sem credencial a `/wp-json/mcp/wp-mcp-fator3` e ao alias `/wp-json/mcp/wp-mcp-ultimate` continua recebendo 401. A recusa esperada não gera erro no error.log. `audit/list` expõe `ability:mcp/access-denied`, alvo da rota, `user:0`, `success:false` e `error_code:mcp_authentication_required`.

As avaliações repetidas de permissão para o mesmo objeto WP_REST_Request produzem uma única entrada. Requisições distintas continuam auditadas. Não são persistidos Authorization, cookies, corpo, query string ou IP nesse registro. Falha de gravação usa o diagnóstico existente de persistência de auditoria; não concede acesso. O tamanho da auditoria continua sujeito à retenção MCP.

Usuário autenticado sem a capacidade exigida é uma recusa diferente (`mcp_permission_denied`) e conserva aviso único. Erros inesperados do servidor continuam no log com diagnóstico sanitizado. Esta mudança não suprime globalmente `error_log` nem altera o servidor MCP próprio do Elementor.

## Diagnósticos Google

O selftest incompleto pode devolver `success:true`, `execution_success:true`, `result_status:incomplete` e `complete:false`, sem `error_code`. Isso não é aprovação de acesso externo nem erro MCP. Falha real conserva `f3_google_selftest_failed`; falha de execução usa `result_status:execution_error`. Não converter o texto “incompleto” em falha nem inferir acesso às APIs a partir do autoteste local. `google/preflight`, gates, grants e confirmações permanecem sujeitos ao contrato Google.

## Inventário e poda de backups

`backups/prune category:backups` reconcilia somente envelopes privados do formato corrente. A varredura avança até 200 entradas por chamada, com orçamento de tempo. `inventory_complete:false`, `has_more:true` e `selected:0` indicam inventário em andamento. Novos arquivos concorrentes podem exigir ciclo posterior. Tombstones impedem reentrada; conteúdo inválido fica preservado e é relatado.

```json
{"ability_name":"backups/prune","parameters":{"category":"backups","max_total_bytes":0,"min_keep":0,"dry_run":true}}
```

A prévia seleciona até 200 backups. Idade, volume e quantidade são alternativas; `min_keep` protege os mais recentes. Confira `remaining_eligible`, `blocked`, `selected_scope:frozen_batch` e `expected_selection_sha256`. Confirme com `dry_run:false` e o hash exato. Repita a mesma confirmação para retomar falha parcial; depois do lote, faça nova prévia sem cursor. `next_cursor` percorre prévias sem remoção, vinculado a critérios, conexão e site.

A poda retira o envelope e exportações selecionados; o índice SQL conserva tombstone. Referências de operações, pré-imagens e conteúdo sem identidade comprovada ficam protegidos. A instalação não apaga acervo. Os leitores/importadores JSON/BAK e as rotas `backups/legacy-status` e `backups/legacy-retire` foram retirados; diretórios anteriores permanecem intactos.

## Tokens OAuth (45)

Uma contagem como 157 linhas não mede conexões ativas nem concede acesso. Access tokens duram 3.600 segundos; refresh tokens duram 2.592.000 segundos. Rotação preserva registros consumidos para detectar reutilização. Instalar a versão não faz poda automática.

```json
{"ability_name":"system/maintenance","parameters":{"category":"oauth-tokens","dry_run":true}}
```

Confirme com `dry_run:false` e `expected_selection_sha256` igual a `selection_sha256` da prévia. Percorra `next_before_id` enquanto `has_more`. Cada janela examina até 100 tokens vencidos, podendo selecionar zero e ainda haver outra janela.

Tokens válidos e expiração desconhecida são preservados. Os vencidos são compactados. Refresh consumido com grant mantém status `consumed` e recebe `retention_kind:replay_guard`: mantém apenas dados mínimos para detectar reutilização e revogar o grant. Comprovantes podem ser excluídos fisicamente quando expiração e compactação tiverem mais de 30 dias. Guards de refresh ligados a grant ativo são conservados; grant inativo também precisa estar sem alteração há mais de 30 dias. Não há redução por volume. `older_than_days`, se informado, aceita somente 30 para esta categoria. Confirmações válidas preparadas pela 0.21.0 mantêm seu contrato e prazo original.

`system/storage` apresenta grupos por tipo/status, expirados, prazo desconhecido, política e última manutenção. Planos/recibos operacionais são separados dos registros de token: a limpeza desta categoria não promete compactação física do arquivo InnoDB nem redução imediata de seu tamanho em disco.

## Exclusão tipada de termo

`content/delete-term` apaga um único termo vazio ou ligado exclusivamente a posts inexistentes. Exige perfil Manutenção, manage_options e, se a taxonomia estiver registrada, a capacidade nativa delete_terms.

Informe `taxonomy` e exatamente um identificador: `term_id` é a identidade em terms; `term_taxonomy_id` é a identidade em term_taxonomy. Os valores “tt 3”, “tt 4” etc. da demanda são term_taxonomy_id, não term_id. Nome e slug não são identificadores de exclusão.

Exemplo de prévia baseado no pedido, a ser conferido novamente no site antes de confirmar:

```json
{"ability_name":"content/delete-term","parameters":{"taxonomy":"elementor_library_type","term_taxonomy_id":3,"allow_unregistered":true,"object_type":"post"}}
```

`allow_unregistered:true` e `object_type:post` são obrigatórios quando o provedor da taxonomia não está registrado. O administrador deve confirmar que se trata de taxonomia de posts. Para taxonomia registrada, tipos de objeto não reconhecidos como post types são recusados. Os IDs relatados em fator3.com.br e korvena.com.br não são embutidos no código nem presumidos como atuais.

A primeira chamada retorna resumo, ambos os IDs, quantidade de relações, órfãos de posts e `confirm_token`, com validade de dez minutos. Metadados privados não aparecem no resumo. Repita **os mesmos argumentos** acrescentando o token. Alteração do termo, metadados ou relações entre as fases invalida a confirmação. Repetir confirmação concluída retorna o recibo, sem novo efeito.

Antes de apagar, salva backup privado com as linhas de terms, term_taxonomy, termmeta e term_relationships. A escrita usa a conexão MySQL original e uma transação InnoDB; conexão perdida não é substituída por outra para continuar a exclusão. Releitura dentro da transação e após commit confirma as quatro ausências. A resposta traz `backup_id` e `readback.term_absent`, `term_taxonomy_absent`, `relationships_absent` e `termmeta_absent`.

O backup pode ser inspecionado/exportado pelas rotas de backups conforme permissão. É pré-imagem para recuperação assistida; esta versão não adiciona uma rota automática de restauração de termos. Não usa `db/execute` nem dump integral para esta operação.

Relações com posts existentes, termo padrão, termo compartilhado entre taxonomias, termo com filhos e tabelas não InnoDB são recusados. Limite: 1.000 relações, 1.000 metadados e 4 MiB de pré-imagem. A existência real do post determina órfão; o campo count do termo não basta.

A exclusão é SQL restrita às quatro tabelas e aos IDs selecionados, seguida de invalidação de cache; não chama hooks de exclusão de provedores. Não realoca posts, não altera outros termos e não faz limpeza global de term_relationships. Uma relação cujo próprio term_taxonomy_id já não exista demanda outra reconciliação: não é incluída silenciosamente. Por isso, as seis linhas órfãs citadas em Korvena só entram se pertencerem ao termo escolhido.

## Verificação de pacotes

`plugins/upload`, `plugins/upload-base64` e `plugins/update` aceitam `probe_timeout_seconds`, inteiro entre 1 e 30, padrão 15. O mesmo limite vale por requisição de ativação e por requisição da sonda posterior. Home e REST compartilham orçamento máximo de `min(45, 2*timeout+2)` segundos; ativação, staging e sonda inicial têm seus próprios tempos. Não é um prazo total da chamada. A sonda inicial permanece em 5 segundos: site já inconclusivo é recusado antes da troca. `system/probe` mantém o contrato geral de 1–10 segundos.

Após instalação completa, timeout, falha de transporte, HTTP 4xx, ausência da marca PHP ou divergência de versão/ativação produzem `package_verification_pending`, `applied:null`, `files_applied:true`, `pending:true`, `retryable:false`, `recovery_status:verification_pending`. Os arquivos candidatos, backup e diário são preservados. HTTP 5xx na sonda posterior ou falha de ativação com conclusão gravada permitem recuperar a pré-imagem. HTTP 5xx do worker sem conclusão é inconclusivo: preserva a candidata e o diário. Corrupção estrutural da instalação continua tendo recuperação própria. Nenhum desses caminhos desfaz migrações de banco ou efeitos externos: `database_effects_reversible:false`.

Use o `package_operation_id` de 32 caracteres devolvido pela troca. Ele identifica o diário e é distinto de `operation_id` do executor/idempotência. `plugins/operation-status` lê apenas operações da mesma conexão; devolve estado, versão/ativação observadas, backup, `file_state`, estado da ativação e última evidência. Essa consulta não faz sondas nem conclui a operação. `success:true` nela indica sucesso da leitura. `plugins/reconcile` verifica hash, ativação e home/REST em nova requisição e conclui o diário apenas com prova efetiva. Possui as mesmas permissões de atualização e exige ativação quando necessária. Perfil personalizado deve conceder as novas habilidades explicitamente.

```json
{"ability_name":"plugins/operation-status","parameters":{"operation_id":"0123456789abcdef0123456789abcdef"}}
```

```json
{"ability_name":"plugins/reconcile","parameters":{"operation_id":"0123456789abcdef0123456789abcdef","probe_timeout_seconds":30}}
```

Uma ativação que ainda roda não é repetida. Somente uma ativação nunca reivindicada e com token expirado, ou ainda não solicitada, pode ser iniciada pela reconciliação. Ativação interrompida em `running` permanece pendente e requer avaliação operacional; não se presume que seus efeitos foram desfeitos. Mudança da pós-imagem bloqueia a reconciliação. Upload do mesmo plugin enquanto há diário não resolvido é recusado. Não reutilize a chave de idempotência do upload para reconciliar: a resposta anterior continua sendo um recibo, não uma nova observação.

A sentinela preserva `verification_pending` mesmo após expirar a lease. Executor abandonado depois de instalar a árvore inteira passa a pendente; interrupção estrutural durante renomeação continua recuperável. `plugins/rollback` permite recuperação explícita de uma troca pendente, com backup da própria conexão e hash da pós-imagem, e não troca arquivos durante ativação em execução. Essa escolha continua sem reversão de banco. Após rollback, a sentinela invalida o cache do PHP servidor durante uma janela de 60 segundos; isso cobre rollback iniciado em CLI, cujo OPcache é separado do FPM.

O diário e o executor possuem identidades separadas. A troca de pacote preserva os recibos atuais da 0.21.0, sem converter operações pendentes. Retorno de arquivos não equivale a retorno do banco ou de efeitos externos.

## Usuários

`users/list` preserva campos e paginação tipados. A remoção exige transferência explícita e confirmação quando aplicável; políticas da conexão continuam limitadas às capacidades WordPress.

## Revisão e SEO

A revisão `content-revision/2` usa a representação persistida de post, todos os metadados e relações de taxonomia, com ordenação determinística e tipos consistentes. Não depende do estado filtrado do cache `WP_Post`. O hash é opaco: faça uma leitura nova antes da escrita. Tokens antigos não são convertidos ou aceitos aproximadamente. Uma alteração real externa continua causando conflito. Hooks que gravem depois do retorno também representam alteração real.

O encadeamento é feito por chamadas independentes: `content/patch-post`, `content/update-post` e equivalentes para páginas retornam a revisão final; envie-a como `expected_revision` de `content/update-seo`. `operations/plan` mantém sua allowlist, sem incluir SEO nem `f3base/*`.

O adaptador Yoast consulta o indexable existente e fornece esse modelo ao builder. Confere quantidade e identidade na releitura; retorno não vazio do builder não é prova suficiente. Metadados têm backup, incluindo presença/ausência e valores brutos dos campos sociais. Indexação desabilitada é recusada antes da escrita. Duplicatas existentes retornam `seo_indexable_duplicates` e exigem reparação explícita. Falha depois da gravação informa os valores efetivos e `backup_id`; não repetir às cegas.

### Imagens sociais

`values.open_graph_image_id` e `values.twitter_image_id` são inteiros não negativos. ID positivo exige anexo de imagem local, arquivo legível e dimensões coerentes com os metadados. ID sozinho deriva URL; URL e ID juntos devem corresponder ao mesmo anexo. URL local usa a associação nativa ou uma correspondência exata com original/tamanhos registrados. Ambiguidade exige ID explícito. Não há busca remota de dimensões ou associação por simples nome de arquivo.

URL externa limpa o ID anterior; URL vazia limpa URL e ID. Mesma URL com ID ausente/incorreto constitui mudança. CDN depende de mapeamento verificável pelas APIs nativas. A resposta `get-seo` contém os IDs armazenados; `rendered_html_verified:false` continua distinguindo metadados de prova pública do HTML.

### Reparação de indexables

`content/deduplicate-seo-indexables` recebe `id` de post/página e, na confirmação, `confirm_token`. Exige Manutenção, administração, edição do post e capacidade SEO. Preserva integralmente o menor ID. Sem duplicatas, retorna `changed:false`.

A prévia identifica o ID preservado, excedentes, relações e hash. A confirmação repete schema/seleção sob transação InnoDB e lock do post. Backup privado inclui schema, versão Yoast, linhas, metadados e dependências, limitado a 1.000 linhas/4 MiB. Remove somente excedentes e hierarquia correspondente. Links ligados aos excedentes, hierarquia externa, chaves estrangeiras externas ou colunas desconhecidas são recusados. O schema verificado é o do Yoast 28.5, inclusive `blog_id` da hierarquia e `updated_at` com `ON UPDATE`. A guarda geral de SQL não foi afrouxada.

```json
{"ability_name":"content/deduplicate-seo-indexables","parameters":{"id":123}}
```

Reenvie os mesmos parâmetros com o token recebido. O token dura 600 segundos, é vinculado à conexão e a repetição concluída retorna o comprovante anterior. O backup auxilia recuperação por administração nativa/SQL em duas fases; não há restauração automática de uma limpeza SEO.

## Atualização de termos

`content/update-term` exige `taxonomy`, `term_id` e pelo menos um de `name`, `slug`, `description`, `parent`. Aceita `expected_revision` e `confirm_token`. Taxonomia deve estar registrada; a exceção de taxonomia ausente continua restrita a `content/delete-term`.

Nome/descrição sem mudança de URL são gravados em uma fase com backup. Mudança efetiva de slug ou pai hierárquico exige prévia e confirmação. `parent:0` remove o pai; descrição vazia limpa. Slug não canônico ou com colisão, pai inválido, ciclo e pai em taxonomia não hierárquica são recusados. O lock global de termos é compartilhado com exclusão. A pré-imagem limitada inclui termo, metadados, relações, descendentes, ascendentes e estado Yoast. Mudança da seleção exige nova prévia.

```json
{"ability_name":"content/update-term","parameters":{"taxonomy":"post_tag","term_id":12,"name":"Nome corrigido"}}
```

A gravação usa `wp_update_term`, hooks e invalidação nativos; com Yoast compatível, reconstrói e verifica o indexable do termo. Retorna IDs de termo e term-taxonomy, revisão, URL, `changed`, `persisted`, `backup_id`. Não faz flush de regras nem cria redirecionamento. URL/HTML públicos devem ser conferidos na operação do site.

## Backup em fluxo e mídia

Envelopes conservam o formato JSON protegido com `content_base64`. Escrita, validação e restauração de binários usam blocos de 192 KiB, SHA-256, leitura completa, verificação da identidade do arquivo e publicação atômica. O parser respeita escapes/ordem JSON, recusa chaves repetidas e limita metadados; não extrai conteúdo por expressão regular. O teto da pré-imagem de anexos continua 64 MiB de arquivos e 16 MiB de metadados.

Antes da exclusão, são preservados original, versão reduzida, tamanhos e backup sizes, junto de post, metadados, termos, revisões, comentários e filhos dentro dos limites. Falha de backup impede a chamada destrutiva. Relações de proteção entre pré-imagem e backups filhos também ficam em registro durável próprio para resistir à reconstrução do índice. Listagem, reconstrução de índice, exportação em partes e seleção de retenção não materializam todo o binário na memória.

`files/restore` restaura cada backup filho. O `backup_id` da pré-imagem de metadados não é um backup de arquivo. Não há `media/restore`. Recuperação assistida completa exige ler a pré-imagem, restaurar os binários pelos IDs filhos e reconstruir o anexo/metadados/relações pela administração nativa ou SQL em duas fases, com backup. Conferir IDs/URLs, hashes e relações. Hooks externos podem ter efeitos não reversíveis. No laboratório a reconstrução foi feita pelas APIs nativas a partir da pré-imagem.

Restauração PHP preserva a barreira de recuperação/sonda existente, com validação limitada a 2 MiB e orçamento de memória; arquivos maiores são recusados antes da escrita. Não há promessa de restaurar PHP arbitrariamente grande pelo caminho binário.

## Diagnóstico do marcador cron


`system/health.cron.scheduling` trata apenas `f3_mcp_cron_observed`. O estado atual não herda sucesso/falha de `last_operation`. Uma ocorrência positiva e estruturalmente válida, com argumentos exatamente vazios, hourly/3600 e igualdade das visões persistida/efetiva confirma a agenda ativa. Ordem de enumeração é normalizada. Evento vencido pode ser agenda válida; isso não prova saúde da execução.

`current_state` distingue active, missing, divergent, unexpected_shape, multiple_occurrences, inactive, unexpected_presence, intent_unknown, intent_conflict e read_failed. `desired_state` e `intent` informam intenção/origem/geração. Em inatividade com ambas as visões vazias, o estado principal é unobserved e `absence.status:confirmed` comprova separadamente a limpeza.

Ativação e desativação explícitas registram intenção. Na atualização, um plugin ativo sem intenção nova usa o contexto atual; recibo antigo de clear não determina inatividade. `init`, diagnóstico e bootstrap não recriam o marcador. Para reagendá-lo explicitamente, use o ciclo administrativo de desativação/reativação, após conferir a causa da ausência. Leitura não chama `_get_cron_array`, que pode migrar/gravar opções legadas.

Operações, callbacks, incidentes e overflow compartilham lock por site e gravação com releitura de recibo. Falha/timeout ficam em `diagnostic_persistence`; prova independente da agenda permanece visível. `history_complete` tem escopo de histórico recuperado e processo atual, não detecta processos externos mortos sem qualquer registro durável. Há até 100 incidentes e contador de excedentes. O erro nativo original permanece mesmo quando sua pós-condição foi comprovada. Nenhum callback é repetido pelo diagnóstico. Não há garantia de serialização de todos os escritores externos do cron.

## Integração e distribuição

Matriz histórica desta seção: Core 1.30.0, Google 0.8.3, WordPress 7.1.2, PHP 8.3.6. A matriz vigente é a indicada na abertura deste manual. Descoberta dinâmica continua usando os schemas reais. Core oferece 123 abilities e Google 282 distribuídas por seus namespaces. Novos contratos Core de Slack/qualidade/publicidade permanecem responsabilidade do Core; schemas de status/manutenção Google e resultados incompletos conservam suas distinções. Não foram enviados avisos Slack nem executadas chamadas externas Google/Pipedrive nos testes MCP.

Atualização Core não está concluída só porque um GET funcionou: a finalização depende do executor após a janela nativa. Recuperação preserva guardas atuais e requer gerações corretas, reconciliação e retomadas separadas (Google primeiro, Core depois). Não substituir `f3-core-state`/`f3-google-state` por sentinelas antigas, não reapresentar ações externas históricas. Não há promessa de downgrade do Core.

Instalador versionado, sem update feed, validação por SHA-256 e fora de `auto_update_plugins`. Aplicar em site piloto por ordem do dono, reler catálogo e revisões, conferir HTTP/SEO e só então executar alterações tipadas autorizadas. A entrega não executa rollout ou limpeza na frota. Monitoramento de sete dias e temas pendentes dos outros projetos não são comprovados por estes testes locais.

## SEO e manutenção


`content/deduplicate-seo-indexables` preserva o menor ID completo. Referências externas ao ID preservado são permitidas. A hierarquia própria das duplicadas é removida, inclusive quando seu ancestral é outro objeto. Uma linha sobrevivente que aponte para ID a remover, ou links não modelados envolvendo duplicadas, bloqueia a operação. A releitura verifica a linha preservada, seus metadados, hierarquia sobrevivente e links.

`content/delete-orphan-seo-indexable` recebe `indexable_id`. A primeira chamada devolve resumo e `confirm_token`; a segunda repete a identidade e o token. Atende indexables Yoast de posts, páginas e termos. Ausência é demonstrada pelas tabelas nativas, não por HTTP 404. Post privado/lixeira e termo existente em taxonomia desregistrada permanecem protegidos. O schema conhecido de Yoast e InnoDB são requisitos; esquema/dependência desconhecidos bloqueiam. Pré-imagem privada limitada a 1.000 linhas e 4 MiB, transação e releitura de ausência do indexable, hierarquia e links. Repetição da confirmação retorna o recibo. Exige perfil Manutenção, manage_options e capacidade SEO.

### Backups — pedido 58

`backups/prune category:backups` admite dois modos: `artifact_ids` (1–200 IDs únicos) ou política de idade/volume/quantidade com `exclude_ids`. Não misture os modos. IDs do formato atual são aceitos; categorias SQL conservam IDs de 32 caracteres e recusam exclusões não suportadas. ID inexistente é bloqueado explicitamente; nunca aciona a política padrão.

A prévia vincula seleção, conexão, critérios e corte de idade. O cursor vincula também as exclusões. Confirmar usa `dry_run:false` e `expected_selection_sha256`. Seletores repetidos devem corresponder à prévia. Novo backup não entra no lote; mudança de componente ou referência bloqueia a aplicação. Pré-imagens referenciadas continuam protegidas. Exclusões por ID não vencem automaticamente: preservar até 18/10 é uma escolha operacional, sem regra de data hardcoded no plugin.

`selected_bytes` mede os componentes selecionados; `removed_bytes` soma os componentes com remoção confirmada no lote congelado, sem contar duas vezes a repetição. `removed_bytes_complete:false` sinaliza componente interrompido cuja remoção ainda não foi comprovada. Não representa espaço livre medido no volume. Inventário incompleto, bloqueios e remanescentes ficam explícitos.

`plugins/rollback` aceita `dry_run:true`: verifica permissão, vínculo do diário/backup, hash da pós-imagem e integridade da pré-imagem, sem restaurar árvore, alterar ativação ou diário. A prévia é pontual; a aplicação revalida sob locks de pacote/backups. `rollback_ready`, `already_restored` e `preimage_verified` distinguem os estados. Omissão de `dry_run` mantém a restauração existente. Não promete desfazer migrações de banco ou efeitos de hooks.

### Tokens — pedido 59

`system/maintenance category:oauth-tokens` aplica o predicado de elegibilidade antes do LIMIT de 100 itens. Recibos compactados recentes não escondem os vencidos restantes. Preserva tokens válidos, expiração desconhecida e a proteção de reutilização de refresh enquanto o grant estiver ativo; purge exige expiração, compactação e alteração do grant antigas o bastante, conforme o contrato de 30 dias.

A prévia informa `remaining_eligible`, `remaining_scope`, `eligible_observed_at`, `eligibility_complete`, `has_more` e `next_before_id`. Após aplicar um lote, faça nova prévia sem cursor para examinar todos os remanescentes. Cursor serve para percorrer sem aplicar e limita o escopo da contagem. Falha de contagem retorna null e evidência incompleta, nunca zero presumido. Aplicação revalida revisões e grant; repetição usa recibo persistido.


### Companheiros atuais

Core 1.33.0 e Google 0.8.5 usam os contratos descritos em SERVER-INTEGRATION.md. Catálogo real e metadados de cada pacote são a autoridade. Google 0.8.5 foi entregue e seu catálogo corrente é usado sem aliases para rotas retiradas.

```json
{"ability_name":"content/delete-orphan-seo-indexable","parameters":{"indexable_id":23}}
```

```json
{"ability_name":"backups/prune","parameters":{"category":"backups","artifact_ids":["0123456789abcdef01234567"]}}
```

```json
{"ability_name":"backups/prune","parameters":{"category":"backups","older_than_days":1,"exclude_ids":["0123456789abcdef01234567"]}}
```

```json
{"ability_name":"plugins/rollback","parameters":{"backup_id":"0123456789abcdef01234567","dry_run":true}}
```

## Manutenção 0.22.0

Instalação e inicialização independem dos companheiros. O canal opcional de atualização trata `requires.plugins` como metadado descritivo, sem bloquear o pacote. Requisitos próprios de WordPress/PHP, origem HTTPS, identidade e hash do ZIP continuam válidos. Veja RELEASE-0211.md para o inventário da limpeza e limites da validação.

## Ativação com prova na 0.22.0

A intenção e o modo de ativação entram no diário assinado antes da troca de arquivos. `native_activation` executa o ciclo nativo WordPress em PHP independente quando o plugin era novo/inativo e activate:true. `silent_reactivation` preserva um plugin que já estava ativo sem repetir seus hooks de primeira ativação. `none` mantém o pacote inativo. Pacote idêntico já no estado desejado é noop; pacote idêntico inativo com activate:true ainda precisa da ativação nativa.

`activation_hook_cycle_completed` somente é true quando o ciclo nativo retornou e o evento activated_plugin foi observado. `active`/`activated` indicam estado ativo, não prova de instalação funcional. `fresh_php_request` e `independent_worker` são evidências do executor. `business_readiness_verified:false` evita confundir ativação, sonda anônima de saúde e prontidão funcional do provedor.

Timeout ou fatal sem recibo de conclusão mantém pending/running; reconciliação não repete hooks. Um ativo inesperado antes da ativação nativa fica `uncertain`. Apenas pending expirado sem entrada ou ativação ainda não solicitada admite token novo. Diários correntes emitidos pela 0.21.0 sem o novo campo preservam sua semântica silenciosa; não se presume que um hook antigo precise rodar. Isso é continuidade de uma operação corrente, sem migração de estado ou pacote intermediário.

Backup/rollback protege arquivos e estado ativo observado. Não desfaz banco, migrações ou efeitos externos. Releia a saúde e os contratos funcionais do provedor após a troca. A sentinela MU é atualizada para novas requisições, incluindo o cache PHP do servidor.

## OAuth/CIMD na 0.22.0

O servidor anuncia e implementa somente `token_endpoint_auth_methods_supported:["none"]`. A fonte comum é `ClientAuthentication::supported`. Clientes públicos continuam usando authorization_code com PKCE S256 e refresh rotativo.

Quando o documento CIMD tem lista plural válida, o método selecionado pertence à interseção com o suporte do servidor. O documento ChatGPT capturado em 15/10/2026 contém singular `private_key_jwt` e plural `["none","private_key_jwt"]`: o método efetivo é `none`.

A lista plural deve ser um array JSON não vazio, com strings de método não vazias, sem espaços, até 32 itens. Objeto com chaves numéricas não é array. Null, string, objeto, lista vazia ou item inválido é recusado sem fallback. O singular, quando presente, também precisa ser string válida. Sem plural, singular `none` é aceito; outros métodos são recusados. **Sem os dois campos, a política local CIMD assume cliente público `none`.** Isso é uma decisão explícita desta implementação, não suporte a autenticação confidencial.

O endpoint de token recusa `client_secret`, `client_assertion`, `client_assertion_type` e cabeçalho de autenticação de cliente, incluindo Basic. Não busca JWKS e não implementa private_key_jwt. O método persistido é verificado na troca/renovação, sem busca de metadados dentro da transação SQL.

Mantêm-se HTTPS público sem credenciais/query/fragmento/dot-segments, proteção SSRF, ausência de redirects na busca, JSON até 64 KiB, identidade exata, redirect URI, issuer, recurso/site, consentimento, perfil, PKCE e uso único. Cache padrão de 300 s, teto de 3600 s; no-cache/no-store exigem revalidação. No-store persiste apenas o vínculo operacional, sem nome/redirects do documento. Falha ao revalidar não usa documento vencido.

## Diagnóstico restrito

Falhas distinguem `client_unavailable`, `metadata_fetch_failed`, `metadata_invalid`, `metadata_unsafe`, `metadata_method_unsupported` e `client_persistence_failed`. A página de autorização e `X-F3-OAuth-Diagnostic` apresentam um identificador opaco de 24 caracteres hexadecimais. O registro privado fica em `f3-mcp-private/oauth-diagnostics`, com guarda PHP, arquivos 0600 e os últimos 128 registros. Cada registro contém ID, categoria, instante, site e HMAC da identidade do cliente. Não recebe tokens, códigos, segredos, state, challenge, corpo do documento ou URL completa da autorização. O arquivo ring.php é uma fila limitada; eventos antigos são substituídos sob lock. Falha do logger não autoriza o cliente nem copia dados para log público; o ID continua na resposta, mas pode não ter registro persistido.

## Atualização e validação

Não há limpeza geral de clientes ou cache na atualização, alteração de grants, extensão de prazos ou reemissão de tokens. Clientes DCR e conexões válidas permanecem. Não é necessária nova autorização para conexões válidas por causa desta release. Uma conexão que nunca concluiu CIMD precisa iniciar novamente a autorização após instalar a candidata; revogações continuam exigindo consentimento novo.

Os testes automatizados usam documento capturado e transporte externo controlado, com HTTP local nativo para autorização/consentimento/token/MCP. Na bancada, DNS externo não estava disponível para PHP; a fixture HTTP troca apenas client_id por uma URL HTTPS de IP público literal, mantendo os campos de negociação e redirect do documento capturado. Essa execução não é uma conexão real ChatGPT.

O protocolo 2025-11-25 foi testado com initialize, sessão, tools/list e tools/call; o protocolo 2026-07-28 foi testado no modo stateless, no qual initialize não existe. Esta evidência automatizada da 0.22.0 foi complementada pela conexão real B22, encerrada no Site-Teste em 21/10/2026; consulte OAUTH-CIMD para as provas e os limites.

Referência oficial consultada: https://developers.openai.com/plugins/build/auth, seção Client registration e negociação plural CIMD. Fixture capturada: https://chatgpt.com/oauth/client.json, em 15/10/2026.

## executor-registration/1.0.0

Produtor: `Fator3\McpFiles\ExecutorRegistry`, MCP 0.22.0. Cooperação PHP entre plugins instalados e confiáveis. Não é uma ferramenta MCP que receba callbacks ou identidade do usuário.

## Assinaturas

```php
ExecutorRegistry::capabilities(): array;
ExecutorRegistry::register(array $descriptor); // true ou WP_Error
ExecutorRegistry::status(): array;
ExecutorRegistry::finalize(): array;
```

`capabilities` e `status` são locais e não inicializam a Abilities API, não fazem HTTP e não concedem acesso. `status` retorna `finalized`, `admitted`, `pending` e `errors`. Antes da finalização, `admitted` é vazio.

Registre o provedor pelo `f3_mcp_register_providers` e `ExtensionContract::register`. Registre as abilities pelo ciclo WordPress. Declare os executores no hook `f3_mcp_register_executors`, que recebe a string do contrato. Ele roda após o término do registro de abilities, quando o servidor compõe seu catálogo. `finalize` precoce ou reentrante somente observa; não força o ciclo. Registro tardio retorna `executor_registry_closed`. Cada request recompõe as declarações, sem privilégios persistidos.

```php
add_action('f3_mcp_register_executors', static function ($contract) {
    if ($contract !== 'executor-registration/1.0.0') return;
    \Fator3\McpFiles\ExecutorRegistry::register([
        'contract' => $contract,
        'ability' => 'meuprovedor/mcp-read',
        'provider' => 'meu-plugin',
        'mode' => 'read',
        'allowed_targets' => ['names' => ['meuprovedor/status'], 'prefixes' => []],
    ]);
});
```

O exemplo pressupõe provedor e abilities já registrados. O descritor não registra uma ability. A ability executora precisa ser pública, aderente à política 1, decorada pelo MCP, ter `meta.fator3.executes_ability:true`, `meta.fator3.mode` igual ao modo declarado e `annotations.readonly` booleano coerente. Provedor e versão vêm do registro efetivo, não de argumentos MCP.

`allowed_targets` exige ambas as listas `names` e `prefixes`. Prefixo é um namespace registrado completo, como `meuprovedor/`, sem curinga. Todas as entradas precisam pertencer ao mesmo provedor. Listas vazias autorizam zero alvos. Campos adicionais, callbacks, modos desconhecidos e identidades conflitantes são recusados. Declarações equivalentes são deduplicadas; conflito bloqueia a identidade durante o request. O schema completo está em `schemas/executor-descriptor.schema.json`.

## Autorização

Somente a chamada raiz de uma ferramenta admitida no servidor Fator3, autenticada por OAuth ou senha de aplicação, abre o contexto interno. O contexto vincula bridge, usuário, conexão e política; alterações desta política invalidam o alvo. O contexto fecha em `finally`, inclusive em exceções. Uma declaração PHP não concede um perfil, capability WordPress, consentimento ou acesso a APIs remotas.

Leitura recusa bridge de escrita, inclusive simulação. Personalizado exige a bridge e o alvo. O alvo é revalidado quanto a provedor, allowlist, efeito, permissão WordPress e perfil. Executor não pode ser alvo, incluindo a própria bridge e metatools. Os gates nativos de serviço, recurso, credencial, revisão, confirmação e idempotência continuam no provedor.

O filtro `f3_mcp_default_server_config` também só admite contribuições executoras validadas por este registro. Não pode contornar uma declaração recusada.

## Google 0.8.5 e próximo consumidor

A adaptação delimitada reconhece os metadados aderentes da versão 0.8.5 entregue e gera descritores para `google/mcp-read` e `google/mcp-write`. Usa os seis prefixos registrados do provedor: `ga/`, `ads/`, `google/`, `gsc/`, `siteverification/` e `gtm/`. Os mesmos validadores e controles genéricos processam esses descritores; não existe exceção nominal no autorizador raiz.

Uma declaração explícita válida tem precedência sobre a adaptação e não duplica a ferramenta. Declaração explícita inválida não recebe fallback. Google 0.8.6 pode declarar suas bridges no hook público, detectando capacidade, sem comparar números de versão MCP. Sua integração real permanece pendente do pacote. Os nomes, schemas e grants atuais Google não são renomeados nem importados.

Códigos públicos incluem `executor_contract_unsupported`, `executor_descriptor_invalid`, `executor_provider_unavailable`, `executor_provider_mismatch`, `executor_targets_invalid`, `executor_target_forbidden`, `executor_conflict`, `executor_ability_invalid`, `executor_registration_failed` e `executor_registry_closed`. Não contêm credenciais nem argumentos da chamada.

## package-distribution/1.0.0

Produtor: `Fator3\McpFiles\PackageDistribution`, MCP 0.22.0. Registro optativo de pacotes e seleção explícita de origem. Não cria dependência de instalação.

```php
PackageDistribution::capabilities(): array;
PackageDistribution::register(array $descriptor); // true ou WP_Error
PackageDistribution::status(): array;
PackageDistribution::selection(string $package): array;
PackageDistribution::manifest(string $package); // documento ou WP_Error; pode fazer HTTP
PackageDistribution::guard(array $snapshot); // true ou WP_Error; leitura local
```

`capabilities`, `status` e `selection` não fazem HTTP. `manifest` é a busca explícita. O registro ocorre no hook `f3_mcp_register_packages`, após o registro de provedores. Descritor estrito: `contract`, `package` (slug), `plugin` (`slug/entrada.php`) e `provider` já registrado. Os três pacotes atuais MCP/Core/Google permanecem predefinidos. Registro equivalente é idempotente; colisão recusa a identidade. Ver `schemas/package-descriptor.schema.json`.

```php
add_action('f3_mcp_register_packages', static function ($contract) {
    if ($contract !== 'package-distribution/1.0.0') return;
    \Fator3\McpFiles\PackageDistribution::register([
        'contract' => $contract,
        'package' => 'meu-plugin',
        'plugin' => 'meu-plugin/meu-plugin.php',
        'provider' => 'meu-plugin',
    ]);
});
```

## Um proprietário por operação

`selection` retorna `available`, `origin` (`mcp` ou `provider`), `revision`, `package`, `plugin`, `provider`, `contract` e `fallback_allowed:false`. Uma URL de canal MCP explicitamente configurada seleciona MCP, mesmo que a origem própria do consumidor também exista. Sem URL MCP, a origem é `provider`: isso não garante que o consumidor tenha uma oferta configurada. Nunca tentar a segunda origem porque a primeira falhou.

O consumidor captura a seleção antes de preparar a oferta e chama `guard` imediatamente antes do efeito. Uma revisão alterada exige nova oferta. Os filtros MCP verificam incidência antes de buscar manifesto. Quando a origem é do provedor, devolvem o resultado anterior; quando MCP é selecionado, falhas de manifesto/hash/origem são erros, sem fallback. As ofertas MCP carregam `f3_distribution_selection`; o download e o pre-install conferem sua revisão. O executor MCP mantém lock compartilhado da configuração enquanto aplica; o formulário de configuração usa lock exclusivo.

O recibo público na option **`f3_mcp_distribution_selection`** é parte deste contrato. Contém apenas contrato e mapa `packages` de seleções, sem URLs dos feeds. O consumidor pode persistir sua própria cópia e deve consultá-la quando a classe MCP não estiver disponível: se a última seleção conhecida era MCP, ausência do plugin não libera automaticamente a origem própria. Reconfiguração deliberada do administrador é necessária. Ausência de recibo/contrato tem diagnóstico próprio; não é uma busca HTTP nem uma autorização de fallback. A option privada `f3_mcp_update_channels` não faz parte da API do consumidor.

## Segurança e instalação manual

Manifesto exige identidade exata, versão, SHA-256, origem pública HTTPS sem redirecionamentos, limites de bytes e requisitos próprios WordPress/PHP. Versões de outros plugins são informativas. `Update URI` não é automaticamente URL de feed.

O upload manual por rota tipada usa ZIP, SHA esperado, staging, validação de caminhos/expansão, backup e prova. Não depende de um feed configurado. Autoatualização nativa do próprio MCP, quando interceptada pelo canal MCP, continua exigindo executor de recuperação. Não remova filtros nem leia configuração privada para forçar uma origem.

Google 0.8.5 conserva o comportamento atual; seu consumo efetivo deste SDK pertence ao GOOGLE-02 da 0.8.6 e não foi declarado homologado apenas pela fixture.

## Core 1.33.0 — medição e transporte

O pacote entregue implementa `site-measurement-context/1.0.0` em `F3Base_Medicao_Contexto::capabilities/snapshot/events`. O SDK PHP local funciona sem identidade MCP e sem conceder acesso a APIs. O MCP não carrega arquivos privados Core, fabrica usuários ou repara configurações.

As abilities administrativas `f3base/medicao-contexto-ler` e `f3base/medicao-eventos-ler` exigem manage_options e perfil/grant MCP compatível. O transporte preserva `ok`, `code`, `contract`, `provider`, `data`, revisões, seis slots (incluindo Clarity), configured/effective, procedência e flags falsas de verificação. Erro mantém `data:null`; não vira configuração vazia ou sucesso.

A paginação de events exige revisão nas continuações. Foram percorridos os 22 eventos reais do pacote Core 1.33.0 e recusada revisão obsoleta. SDK local sem usuário, HTTP autenticado, perfil personalizado insuficiente e editor sem manage_options foram verificados separadamente.

A atualização testada parte diretamente de Core 1.31.0. Core 1.32.0 não é uma etapa. O SDK de consulta Search Console Core → Google continua separado deste SDK e foi exercitado com Google 0.8.5 e respostas remotas simuladas. A adoção nova pelo Google 0.8.6 depende do pacote futuro.


## Histórico — release 0.23.0

Revisão 1, 16/10/2026. Slug/basename: wp-mcp-fator3 / wp-mcp-fator3/wp-mcp-fator3.php. Base: instalação limpa ou atualização direta 0.22.0 → 0.23.0. WordPress mínimo 7.1.2; PHP mínimo 8.3. Não há trava por versão de origem nem dependência obrigatória de acompanhantes. Consulte o relatório externo para os ambientes efetivamente verificados e limitações.

### Escopo

Pedidos MCP 60 (MCP-221-09), M91-01/Core N24 (MCP-221-01), M91-02/Core N25 (MCP-221-02) e documentação MCP-221-08. Preserva server-integration/1.0.0, executor-registration/1.0.0, package-distribution/1.0.0, policy_contract 1 e execução 2.0.0. Nenhum novo bridge por prefixo de fornecedor; nenhuma concessão automática. Core 1.34.0 continua plano sem binário.

### Chave de idempotência e autorização

A origem do campo é capturada em closure antes de acrescentar campos do canal. Schema, required, padrão, limites e valor nativos permanecem intactos; uma chave opcional ausente não é criada. Leitura não recebe cache de escrita. Somente a chave acrescentada pelo MCP é retirada antes do callback. O fingerprint continua excluindo a chave, com isolamento por site, conexão, usuário e ability; ordem de chaves de objeto é normalizada.

O lock revalida permissões do produtor e do canal antes do replay. Para escritas com chave nativa, o produtor é responsável pela idempotência de domínio: após sucesso na 0.23.0, repetição equivalente volta ao callback com a MESMA chave para revalidar seleção/grant e obter seu recibo. O canal não entrega o payload antigo saltando a autorização de domínio. Intenção divergente é recusada antes do callback. Callbacks que declaram idempotency_key devem implementar sua semântica nativa; declaração do campo não autoriza repetição não idempotente de efeitos externos.

Registros antigos não são apagados nem migrados. Falha antiga completa (inclusive invalid_input/rest_property_required) continua retornando a falha; reconcilie job/exportação no produtor e use uma nova chave somente após prova de ausência de efeito. Sucesso antigo com chave nativa, sem marca de encaminhamento, retorna idempotency_revalidation_required, sem expor o recibo nem reabrir a execução. Operações antigas com chave exclusivamente MCP mantêm replay. Running/incerto ou compactado não executam novamente; nunca troque chave para contornar incerteza.

### Diagnósticos e segredos

DataSafety mantém a classificação conservadora para SQL/options/metadados. A apresentação pública preserva checks_passed/all_checks_passed booleanos, passed booleano de sonda ou inteiro não negativo e credential.configured booleano. Também conserva token_configured/secret_configured booleanos e credential_generation/authorization_revision inteiros não negativos dos contratos sociais. Outros tipos nesses nomes e filhos desconhecidos de credential são redigidos. Arrays, objetos JSON, nulos e listas vazias conservam sua forma. Senha, token, segredo e chave privada continuam protegidos. A mesma projeção é usada nas respostas MCP de sucesso e falha, nas representações textual e estruturada.

Tokens opacos de confirmação de 64 hexadecimais (confirm_token/confirmation_token) permanecem disponíveis ao cliente autorizado para concluir duas fases; não são registrados em logs. Schemas de entrada/saída são metadados de descoberta, não credenciais. Logs de falha de tool incluem códigos, sem payload de domínio, mensagem de exceção ou corpo sensível. Auditoria mantém somente seus campos explícitos.

### Normalização de resultados

| Entrada | Envelope comum |
|---|---|
| success booleano explícito | Tem precedência sobre ok; campos nativos não são removidos |
| ok booleano sem success | Preenche success |
| Falha com code=revision_conflict sem error_code | error_code=revision_conflict, conflict=true, retryable=false |
| Falha com error_code=revision_conflict | Corrige conflict/retryable contraditórios para true/false |
| Falha com outro error_code explícito | Preserva código/classificação explícitos |
| Falha com code desconhecido, sem error_code | Conserva code; error_code=operation_failed; conflict=false/retryable=false quando ausentes |
| WP_Error | Conserva seu código em error_code e dados públicos; aplica a mesma regra de revisão |

Não há inferência por mensagem ou substring. data:null permanece null. Normalização é idempotente. Conflito exige releitura e nova intenção/revisão, não retry automático. Um success:true explícito não é convertido em falha por code/ok contraditórios.

### Documentação instalada

system/guide sem parâmetros lista temas e documentos com ID, título, bytes e hash. document contém um ID exato dessa lista; byte_limit é 256–32768 (padrão 8192). A resposta inclui conteúdo UTF-8, offset_bytes, returned_bytes, total_bytes, has_more e next_cursor. Reutilize document, cursor e, opcionalmente, expected_sha256. A revisão é versão:SHA256. Mudança de hash entre páginas produz guide_revision_conflict; reinicie a leitura. O hash refere-se ao documento completo, inclusive ao ler um tema do manual.

O modo legado topic continua disponível; sem paginação explícita retorna o conteúdo inteiro do tema/manual. ability consulta o schema visível e não se combina com documentação. IDs são allowlisted; não aceitam caminhos, URLs ou arquivos externos. Conteúdo compilado vem dos documentos canônicos. Não há HTTP remoto, auditoria de leitura nem persistência pelo leitor. O gate existente edit_posts e a política do canal permanecem; configuração e contas exigem autorização administrativa própria.

### Instalação, limites e validação

Instalar wp-mcp-fator3-0.23.0-instalador.zip. Upload remoto: expected_slug=wp-mcp-fator3 e expected_sha256 calculado dos bytes recebidos; overwrite/activate explícitos. Ativação ocorre em novo processo. Confirmar versão, saúde, journal e inventário após a troca; ativação não comprova prontidão comercial. Fonte e evidências não pertencem ao servidor.

O limite do JSON estruturado permanece 2097152 bytes; corpo HTTP pode ser maior por conter também a representação textual. Limite menor e paginação do produtor prevalecem. Não criar jobs implicitamente para contornar excesso. Google 0.10.0, Meta/LinkedIn 0.2.0 e Core 1.33.0 são as entradas fornecidas desta rodada; instalação da frota depende de publicação separada.

Não há migração nova de banco ou expurgo. Backup prévio do pacote e estado privado deve ser mantido; rollback respeita pós-imagem divergente e não desfaz efeitos de fornecedor. Uma conexão de manutenção existente não prova novo consentimento ChatGPT/CIMD B22. Fornecedores reais, Core 1.34 e Implantador atual têm aceites separados; consultar pendências do relatório da entrega.

## Release corrente 0.24.0

Revisão 1 · 17/10/2026. Base suportada: instalação limpa ou atualização direta 0.23.0 → 0.24.0.

## Correção e contrato
A projeção pública mantém `cache_bypass_verified` quando seu valor é booleano, em cada amostra e no total de `probe_before` e `probe_after` das operações de pacote. A mesma correção vale para `system/probe`, consultas de operação e respostas de sucesso/erro nas representações textual e estruturada.

- `true`: a sonda confirmou a execução PHP nova pelo marcador assinado correspondente à requisição.
- `false`: a sonda não comprovou essa execução; consultar `cache_evidence`, `status` e asserções. Não converter false em sucesso nem repetir instalação por esse indicador isolado.
- String, inteiro, null, array e objeto nesse campo permanecem redigidos. Nenhuma coerção é aplicada.

Exemplo de fragmento: `{"probe_before":{"cache_bypass_verified":true,"samples":[{"cache_bypass_verified":true}]},"probe_after":{"cache_bypass_verified":false,"samples":[{"cache_bypass_verified":false}]}}`.

A execução de Probe, os requisitos de recuperação, DataSafety de SQL/options e a proteção de segredos não mudam. Bypass interno não comprova acesso externo, cache HIT, saúde comercial ou entrega no fornecedor.

## Atualizar e verificar
Conferir hash/slug, preservar a pré-imagem e usar `plugins/upload` com URL HTTPS, `expected_sha256`, `expected_slug:wp-mcp-fator3`, `overwrite:true`, `activate:true`. Homologação direta também aceita `plugins/upload-base64` com os mesmos controles. Consultar schema instalado antes de chamar.

A resposta da própria troca a partir da 0.23.0 pode ainda usar o código antigo carregado: não é a prova final da correção. Em requisição nova, consultar `system/capabilities`, `system/health`, `plugins/operation-status` e `system/probe`; um novo upload processado pela 0.24.0 deve trazer booleanos nas sondas. Não substituir valores já redigidos em registros históricos por true/false inventados. Estados incertos exigem reconciliação antes de repetir.

## Documentação, permissões e dados
Descobrir `system/guide`; sem parâmetros obtém índice. Ler `document:release-0240` ou `operacao`, com `byte_limit` 256–32768, `cursor` e `expected_sha256`. Conferir revisão, bytes, SHA-256 e has_more=false. IDs são allowlisted; leitura não chama fornecedor. Gate documental edit_posts e política de conexão permanecem; manutenção exige perfil e capacidades administrativas existentes.

Não há nova configuração, credencial, tabela, schema, migração, limpeza ou renovação. Atualizar preserva conexões, permissões, opções, jobs, pausas, recibos e backups. Retornar aos arquivos 0.23.0 restaura a redação indevida; não desfaz efeitos externos. Mínimos declarados herdados: WP 7.1.2/PHP 8.3; patches efetivamente ensaiados constam do relatório.

Core 1.35.0, Google 0.11.0 e Meta/LinkedIn 0.2.0 são acompanhantes, sem dependência obrigatória. Não há mudança de seus contratos. Homologação de fornecedores e nova conexão CIMD/ChatGPT B22 permanecem fora do Pedido 61; o relatório separa testes próprios e pendências.

## Auditoria de mutações e B22

Consulte MUTATION-AUDIT para o contrato público, before/after, identidade de origem, retenção e falhas. B22/CIMD foi encerrado no Site-Teste em 21/10/2026 (relatório 0.25.0 revisão 3); leia OAUTH-CIMD para a evidência e os limites. Não é necessária nova autorização para conexões válidas.
