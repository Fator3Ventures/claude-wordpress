# Impacto — Fator3 MCP 0.26.1 → Fator3 MCP LinkedIn 0.5.0

Origem: impacto LinkedIn 0.5.0 → MCP, Pedido LinkedIn 6(c). Estado inicial: em implementação; este documento antecede o código dependente.

O MCP passa a oferecer mutation-audit/1.0.0: registro local de descritor provider/reader/event_contract e recebimento de referência com operation_id, operation, state e hashes de antes/depois. A consulta audit/get-operation chama exclusivamente a habilidade pública declarada, com permissão original, perfil da conexão quando aplicável e principal/ativo do provedor. Referências são metadados; snapshots continuam no diário do LinkedIn.

Compatibilidade inicial usa apenas f3_linkedin_mutation_recorded (linkedin-mutation/1.0.0) e linkedin/get-write-operation da versão 0.5.0. O LinkedIn não precisa ser alterado para este adaptador. Futura adoção nativa pode registrar o descritor no hook público e emitir referência pelo método público. A string histórica central_audit=summary_only_until_mcp_contract da projeção 0.5.0 não é usada como sinal de capacidade do MCP.

Painel não assume concessão MCP: detalhes de operação MCP exigem a conexão original. Operação originada no painel pode ser consultada pelo mesmo administrador, por escopo interno temporário restrito ao leitor registrado; permissão e ativos do provedor permanecem obrigatórios. Não conceder acesso entre administradores. Nenhuma credencial ou snapshot nos eventos/índice central.

Validação e resultado serão preenchidos antes da entrega. Responsável: agente do MCP; nenhuma mudança dependente solicitada ao agente LinkedIn nesta rodada.
