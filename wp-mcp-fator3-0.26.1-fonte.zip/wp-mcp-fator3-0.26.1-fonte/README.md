# Fator3 MCP 0.26.1

Servidor MCP independente para WordPress. Nova versão: referências de operações do LinkedIn 0.5.0 no Registro central e consulta autorizada de antes/depois, inclusive ações do painel. Base imediata 0.25.0; instalação limpa; WordPress 7.1.2 / PHP 8.3.6.

Contrato mutation-audit/1.0.0 em docs/MUTATION-AUDIT.md; operação em docs/OPERACAO.md e docs/RELEASE-0260.md. Guias instalados allowlisted consultáveis por system/guide. Identidade wp-mcp-fator3/wp-mcp-fator3.php. B22 encerrado no Site-Teste conforme OAUTH-CIMD.

Build: python tools/sync_docs.py; python tools/build_packages.py. Testes desta rodada: tools/release0260; evidencias/0260. Evidências anteriores são históricas. Nenhuma publicação automática em GitHub/frota. Sem tokens reais ou bancos privados nos pacotes.
