<?php
/**
 * Orquestrador do plugin.
 *
 * Registra os hooks LENDO O REGISTRO ÚNICO: nenhum `add_action` de módulo é
 * escrito aqui à mão. Módulo inativo não registra nada — é inerte de verdade.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ciclo de vida do site-core.
 */
final class F3Base_Site_Core {

	/**
	 * Prioridade em que os hooks dos módulos são registrados, dentro de `init`.
	 *
	 * Registrar em `init` (e não em `plugins_loaded`) mantém toda leitura de
	 * estado depois do carregamento do text domain: chamar tradução antes de
	 * `init` gera aviso do core desde o WordPress 6.7.
	 */
	public const PRIORIDADE_REGISTRO = 5;

	/**
	 * Liga o plugin.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
        add_action('wp_abilities_api_init',array(F3Base_Configuracao_Atual::class,'registrar_documentacao'));
        add_action('wp_abilities_api_init',array(F3Base_Medicao_Contexto::class,'registrar'));
        add_action('wp_abilities_api_init',array(F3Base_Conversoes_Contexto::class,'registrar'));
        add_action('wp_abilities_api_categories_init',array(__CLASS__,'registrar_categoria_de_habilidades'));
        if (!F3Base_Instalacao::permitida()) {
            add_action('admin_notices', array(F3Base_Instalacao::class, 'aviso'));
            F3Base_Saude::iniciar();
            add_action('wp_abilities_api_init',array(F3Base_Saude::class,'registrar'));
            return;
        }
        F3Base_Recuperacao::provisionar();F3Base_Recuperacao::proteger_agenda();
        foreach(array('F3Base_Recuperacao','F3Base_Execucoes') as $class){add_action('wp_abilities_api_init',array($class,'registrar'));}
        $entrou=F3Base_Recuperacao::entrar();$atende=!$entrou&&F3Base_Recuperacao::atendimento();
        if(!$entrou&&!$atende){
            if(is_admin()){F3Base_Recuperacao::admin_minimo();}
            F3Base_Saude::iniciar();
            add_action('wp_abilities_api_init',array(F3Base_Saude::class,'registrar'));
            add_action('wp_abilities_api_init',array(F3Base_Como_Usar::class,'registrar'));
            F3Base_Cli::registrar();
            add_action('admin_notices',static function(){if(current_user_can('manage_options')){echo '<div class="notice notice-error"><p>Fator3 Site Core: módulos não inicializados — '.esc_html(F3Base_Recuperacao::ler()['codigo']??'barreira indisponível').'. Consulte Saúde do Site e f3base/operacao-recuperacao-ler; a recuperação exige ação administrativa explícita.</p></div>';}});
            return;
        }
        if($atende){add_action('admin_notices',static function(){if(current_user_can('manage_options')){echo '<div class="notice notice-error"><p>Fator3 Site Core: modo de atendimento. Captura depende da estrutura disponível; tarefas, entregas, migração e gravações administrativas paradas. Confira Saúde e corrija a permissão/coordenação de wp-content/f3-core-state/ antes de restaurar.</p></div>';}});}
        register_shutdown_function(static function(){F3Base_Execucoes::encerrar();F3Base_Recuperacao::sair();});
        add_action('f3base_pipedrive_alertas',static function(){F3Base_Pipedrive_Alertas::conta();return F3Base_Pipedrive_Alertas::processar();});
        F3Base_Sessao_Admin::iniciar();F3Base_Formulario_Antispam::iniciar();F3Base_Email_Site::iniciar();F3Base_Contatos_Externos::iniciar();F3Base_Email_Alerta::iniciar();F3Base_Email_Limpeza::iniciar();F3Base_Email_Novo_Lead_UI::iniciar();F3Base_Email_Novo_Lead::iniciar();F3Base_Conversoes_Servidor::iniciar();F3Base_Conversoes_Fila::iniciar();F3Base_Vitais::iniciar();F3Base_Formulario_Tentativas::iniciar();F3Base_Cache_Reaquecimento::iniciar();F3Base_Operacao::iniciar();F3Base_Gsc::iniciar();
        F3Base_Cron_Diagnostico::iniciar();F3Base_Estado_Inventario::iniciar();F3Base_Avisos::iniciar();F3Base_Sessoes::iniciar();F3Base_Formulario_Complementos::iniciar();F3Base_Slack::iniciar();F3Base_Sondas_Http::iniciar();F3Base_Conteudo_Instrumentacao::iniciar();F3Base_Cache_Orcamento::iniciar();
        F3Base_Configuracoes_Hub::iniciar();
        F3Base_Meta_Acesso::iniciar();
        F3Base_Qualidade::iniciar();
        F3Base_Artigos::iniciar();
        add_action('init',array(F3Base_Fila::class,'retomar'),99);
        add_action('f3base_cache_podar',array(F3Base_Cache_Orcamento::class,'limpar'));
        add_action('rest_api_init',array(F3Base_Audiencia::class,'registrar_contexto'));
        add_action('f3base_retencao_limpeza',array(F3Base_Operacao_Intencoes::class,'limpeza'));add_action('f3base_intencoes_podar',array(F3Base_Operacao_Intencoes::class,'limpeza'));
        add_action('admin_notices',static function(){if(current_user_can('manage_options')){$s=F3Base_Instalacao::resumo();if(empty($s['concluido_em'])){echo '<div class="notice notice-warning"><p>Atualização do Site Core pendente: '.esc_html($s['ultima_falha']['etapa']??'inicialização').'. Próxima tentativa: '.esc_html(!empty($s['proxima_tentativa'])?wp_date('d/m/Y H:i:s T',(int)$s['proxima_tentativa']):'na próxima passagem').'. Consulte Saúde e Operação.</p></div>';}}});
		add_action('init', array(F3Base_Instalacao::class, 'observar'), 1);
		F3Base_Core_Config_Mcp::registrar_protecao();
		F3Base_Servicos::iniciar();
		F3Base_Saude::iniciar();
		F3Base_Llms_Arquivo::iniciar();
		F3Base_Schema_Verificacao::iniciar();
		F3Base_Perfil_Desempenho::iniciar();
		add_filter( 'wpseo_meta_author', array( 'F3Base_Autoria', 'metaauthor' ), 999 );
		add_filter( 'wpseo_enhanced_slack_data', array( 'F3Base_Autoria', 'slack' ), 999 );
		add_action( 'add_meta_boxes', array( 'F3Base_Autoria', 'caixas' ) );
		add_action( 'save_post', array( 'F3Base_Autoria', 'salvar' ) );
		F3Base_Cli::registrar();
		add_action( 'init', array( 'F3Base_Atualizacao', 'agendar' ), 40 );


		add_action( F3Base_Atualizacao::EVENTO, F3Base_Operacao::callback( F3Base_Atualizacao::EVENTO, array( 'F3Base_Atualizacao', 'migrar' ) ) );
		add_action( 'init', array( __CLASS__, 'registrar' ), self::PRIORIDADE_REGISTRO );
		add_action( 'rest_api_init', array( __CLASS__, 'registrar_rota_relatorio' ), 10 );

		/*
		 * AS HABILIDADES QUE DIZEM AO AGENTE COMO USAR O PLUGIN, e a grafia do
		 * gancho é a metade que faltava.
		 *
		 * O DEFEITO MEDIDO num WordPress 7.1 real: o gancho era
		 * `abilities_api_init`, SEM o prefixo `wp_`. Esse nome não existe no
		 * núcleo — a Abilities API dispara `wp_abilities_api_init` —, e um
		 * `add_action` num gancho que ninguém dispara não falha, não avisa e não
		 * registra nada. As três habilidades simplesmente não existiam:
		 * `wp_get_abilities()` devolvia só as do núcleo, e o caminho documentado
		 * para um agente ler e gravar a configuração do site não estava no ar.
		 *
		 * A CATEGORIA VEM ANTES, e num gancho próprio. O núcleo recusa habilidade
		 * cuja `category` não esteja registrada, e a janela para registrá-la é
		 * `wp_abilities_api_categories_init`, que dispara antes. Registrar a
		 * categoria dentro do gancho das habilidades chegaria tarde: as três
		 * seriam recusadas com `_doing_it_wrong` e sumiriam de novo.
		 */

		add_action( 'wp_abilities_api_init', array( 'F3Base_Como_Usar', 'registrar' ) );
		add_action( 'wp_abilities_api_init', array( 'F3Base_Config_Mcp', 'registrar' ) );
		add_action( 'wp_abilities_api_init', array( 'F3Base_Core_Config_Mcp', 'registrar' ) );
		add_action( 'wp_abilities_api_init', array( 'F3Base_Acessos_Mcp', 'registrar' ) );

		foreach ( array( 'F3Base_Medicao_Consultas', 'F3Base_Publicacao_Sonda', 'F3Base_Operacao', 'F3Base_Saude', 'F3Base_Schema_Verificacao', 'F3Base_Llms_Arquivo' ) as $classe ) {
			add_action( 'wp_abilities_api_init', array( $classe, 'registrar' ) ); }
		add_action( 'wp_abilities_api_init', array( 'F3Base_Capi_Fila', 'registrar_habilidades' ) );

        F3Base_Recuperacao::marcar_modulos();
        add_action('template_redirect',array(F3Base_Audiencia_Exclusoes::class,'registrar'),999);
        add_action('f3base_retencao_limpeza',array(F3Base_Audiencia_Exclusoes::class,'podar'));
		if ( is_admin() ) {
			F3Base_Admin_Saude::iniciar();
			F3Base_Admin_Acessos::registrar();
			F3Base_Admin_Tela::iniciar();
			/*
			 * A MEDIÇÃO GANHOU CASA PRÓPRIA na 1.1.0. Ela morava no fim da tela
			 * de configuração, depois de trinta campos de formulário: quem abre
			 * aquela tela vai gravar uma option, e quem quer saber o que os
			 * visitantes fizeram tem outra pergunta — que não é sub-item de
			 * configuração nenhuma.
			 */
			F3Base_Admin_Medicao::iniciar();
		}
	}

	/**
	 * A CATEGORIA DAS HABILIDADES DESTE PLUGIN.
	 *
	 * POR QUE ELA EXISTE, e não é formalidade. O núcleo exige `category` em toda
	 * habilidade registrada e RECUSA a que traz uma categoria desconhecida — "The
	 * ability properties must contain a `category` string" foi a recusa medida na
	 * bancada. A categoria é também o que um agente vê antes de escolher: sem uma
	 * própria, as três habilidades deste plugin cairiam numa gaveta genérica ao
	 * lado das do núcleo, e quem procura "por onde mudo a medição deste site" não
	 * teria como saber que elas existem.
	 *
	 * O SLUG É O PREFIXO DO PACOTE, `f3base`, pela mesma razão de todo o resto: é
	 * o nome que este pacote reivindica em option, tabela, evento e namespace
	 * REST, e categoria com nome genérico colide com a de outro plugin.
	 *
	 * @return void
	 */
	public static function registrar_categoria_de_habilidades(): void {
		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		wp_register_ability_category(
			F3BASE_PREFIXO,
			array(
				'label'       => __( 'Fator3 Site Core', 'f3base' ),
				'description' => __( 'Leitura e escrita da configuração deste site pelo plugin persistente do Método F3: o que ele já faz por assunto, a option exata de cada ajuste, e a configuração do implantador para a execução seguinte.', 'f3base' ),
			)
		);
	}

	/**
	 * Registra os hooks declarados pelos módulos do registro único.
	 *
	 * Módulo inativo continua inerte — nenhum asset, nenhum endpoint, nenhuma
	 * tabela —, com UMA exceção declarada por hook: o item marcado `sempre` é
	 * registrado de qualquer jeito. Ele existe para o filtro cuja decisão é POR
	 * OBJETO, e cujo caso mais importante acontece justamente com o módulo
	 * inativo: o bloco do CTA sem número. Antes desta exceção, o filtro que
	 * decidia publicar o botão só era registrado quando a condição dele já não
	 * podia acontecer, e a regra nunca rodava.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		foreach ( F3Base_Registro::modulos() as $modulo ) {
			$ativo = $modulo->deve_registrar();

			foreach ( $modulo->hooks() as $hook ) {
				if ( ! $ativo && empty( $hook['sempre'] ) ) {
					continue;
				}

				$metodo = (string) $hook['metodo'];

				if ( ! method_exists( $modulo, $metodo ) ) {
					continue;
				}

				$callback   = array( $modulo, $metodo );
				$prioridade = (int) $hook['prioridade'];
				$args       = (int) $hook['args'];

				if ( 'filter' === (string) $hook['tipo'] ) {
					add_filter( (string) $hook['hook'], $callback, $prioridade, max( 1, $args ) );
					continue;
				}

				add_action( (string) $hook['hook'], F3Base_Operacao::callback( (string) $hook['hook'], $callback ), $prioridade, $args );
			}
		}
	}

	/**
	 * Rota de leitura do relatório — a mesma estrutura que a tela renderiza.
	 *
	 * @return void
	 */
	public static function registrar_rota_relatorio(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/relatorio',
			array(
				'methods'             => 'GET',
				'callback'            => static function (): WP_REST_Response {
					return new WP_REST_Response( F3Base_Registro::relatorio(), 200 );
				},
				'permission_callback' => static function (): bool {
					return current_user_can( 'manage_options' );
				},
				'args'                => array(),
			)
		);
	}

	/**
	 * Relatório do plugin, para o implantador e para a suíte.
	 *
	 * @return array<string,mixed>
	 */
	public static function relatorio(): array {
		return F3Base_Registro::relatorio();
	}

	/** Instala diretamente ou atualiza a partir da base suportada. */
	public static function ativar( bool $em_rede = false ): void {
		self::recusar_ativacao_em_rede( $em_rede );

		if(F3Base_Instalacao::origem()!=='nova'){F3Base_Atualizacao::agendar();return;}
        $r = F3Base_Instalacao::atualizar();
		if(empty($r['ok'])){F3Base_Atualizacao::agendar();return;}

		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			if ( $modulo->deve_registrar() ) {
				$modulo->instalar();
			}
		}
	}

	/**
	 * MULTISITE NÃO É SUPORTADO NA 1.0.0, e a ativação em rede é recusada.
	 *
	 * O LIMITE MEDIDO, dito por inteiro. Ativado para a rede, este plugin
	 * registraria os hooks em todos os sites, mas TUDO o que ele guarda é do
	 * site corrente e por site: options `f3base_*`, as tabelas
	 * `f3base_comportamento` e `f3base_eventos`, o CPT de contingência e os
	 * agendamentos. A desinstalação, que o WordPress roda UMA vez, limparia o
	 * site corrente e deixaria as tabelas e as options de todos os outros — dado
	 * pessoal pseudonimizado guardado por um plugin que já não existe. Não há
	 * `wpmu_drop_tables`, não há laço por blog, e fingir que há seria pior que
	 * declarar o limite.
	 *
	 * RECUSAR É BARATO E É REVERSÍVEL: quem quer o plugin numa rede o ativa SITE
	 * A SITE, e cada ativação faz exatamente o que faz numa instalação única.
	 * O que a recusa impede é a ativação em rede — a única forma em que a
	 * desinstalação prometeria uma limpeza que ela não sabe fazer.
	 *
	 * @param bool $em_rede Escopo da ativação.
	 * @return void
	 */
	private static function recusar_ativacao_em_rede( bool $em_rede ): void {
		if ( ! $em_rede ) {
			return;
		}

		deactivate_plugins( plugin_basename( F3BASE_PLUGIN_ARQUIVO ), true, true );

		wp_die(
			esc_html__( 'Fator3 Site Core não suporta ativação em rede. Tudo o que ele guarda é do site corrente e por site — options, as tabelas de comportamento e de eventos, o registro de contingência e os agendamentos —, e a desinstalação que o WordPress roda uma única vez limparia só um dos sites, deixando dado pessoal pseudonimizado nos demais. Ative o plugin SITE A SITE pela tela de plugins de cada site: ali ele faz exatamente o que faz numa instalação única.', 'f3base' ),
			esc_html__( 'Ativação em rede recusada', 'f3base' ),
			array( 'back_link' => true )
		);
	}

	/**
	 * Desativação: desfaz agendamentos e a estrutura instalável dos módulos.
	 *
	 * Nenhum dado de lead é tocado aqui: desativar plugin não é pedido de
	 * eliminação, e apagar registro pessoal sem journal é perda sem registro.
	 *
	 * Sem `flush_rewrite_rules()` pela mesma razão da ativação: não há regra de
	 * reescrita deste plugin para retirar da tabela.
	 *
	 * @return void
	 */
	public static function desativar(): void {
        wp_clear_scheduled_hook(F3Base_Cache_Reaquecimento::EVENTO);
        wp_clear_scheduled_hook(F3Base_Clarity::EVENTO);wp_clear_scheduled_hook('f3base_clarity_retomar');
        wp_clear_scheduled_hook(F3Base_Tracking_Diagnostico::EVENTO);wp_clear_scheduled_hook(F3Base_Navegacao::EVENTO);wp_clear_scheduled_hook(F3Base_Navegacao::EVENTO_REPETIR);
		F3Base_Llms_Arquivo::desativar();
		wp_clear_scheduled_hook( F3Base_Schema_Verificacao::EVENTO );
		F3Base_Operacao::desativar();
		F3Base_Atualizacao::desativar();
		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			$modulo->desinstalar();
		}
	}

	/**
	 * Grava o padrão embutido apenas nas options que ainda não existem.
	 *
	 * Option já escrita pelo implantador nunca é sobrescrita na ativação.
	 *
	 * @return void
	 */
	private static function semear_padroes(): void {
		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) {
			if ( F3Base_Options::existe( $nome ) ) {
				continue;
			}

			if ( isset( $declaracao['campo'] ) && 'segredo' === $declaracao['campo'] ) {
				continue;
			}

			F3Base_Options::gravar( $nome, $declaracao['padrao'], F3Base_Options::ORIGEM_PADRAO );
		}
	}
}
