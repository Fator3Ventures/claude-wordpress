# Guia para agentes — Core 1.57.0

1. Descubra f3base/documentacao-ler e leia DOCUMENTACAO.md até proxima_linha=null, verificando versão e SHA-256. Contrato administrativo 8.22.0.
2. Para GA4, leia ACERVO-GA4-1.57.md e ga4-status. Grave f3base_ga4_acervo pelo configurador existente com revisão; conceda ga4-reader/1.0.0 no Google. O diagnóstico local não certifica chamada remota.
3. Colete uma página por chamada. Confira publicado, parcial, proxima_tentativa e auditoria. Em erro não modifique a cota, não apague checkpoint nem use credencial própria. Ausência de Google afeta apenas a coleta; leitura local administrativa continua disponível.
4. Para exportar, guarde revisão e percorra proxima_pagina; mudança de acervo exige reiniciar. CSV inclui cabeçalho em cada parte. Não some usuários únicos entre dias, nem recortes ou fontes.
5. Para eliminar contato Instagram, simule leads-eliminar-registro, depois aplique com revisão. Confira dados_eliminados e copias_externas.meta_instagram_detalhes: somente estado erased com recibo confirma diário Meta local. Em pendência retome a mesma rota; não remova outbox manualmente.
6. Após atualização aguarde instalação concluída e confirmação no executor. Preserve salts, acervo, outbox, tombstones e recibos. Leia OPERACAO-E-RECUPERACAO.md antes de restaurar banco.

Não habilitar envio comercial, converter histórico em evento de anúncios, criar BigQuery, nem alterar pacotes acompanhantes por esta rotina. Normas comuns revisão 5 em NORMA-01 e NORMA-02.
