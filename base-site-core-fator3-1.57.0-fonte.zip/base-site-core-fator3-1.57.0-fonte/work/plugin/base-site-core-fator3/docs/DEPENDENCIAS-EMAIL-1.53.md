# Dependências MIME — Core 1.53.0

Parser maduro `zbateson/mail-mime-parser` 4.0.7. Todos os namespaces PHP recebem `F3BaseEmailVendor` com PHP-Scoper 0.18.20. Autoload PSR-4 próprio, sem registrar namespaces originais. Nenhum pacote é baixado na ativação. PHP 8.3.6, iconv e mbstring nativos substituem polyfills.

O fonte inclui composer.json/composer.lock, autoload, ferramentas travadas e build/mime/build.py; o instalador inclui somente fontes necessárias e licenças. Composer audit na obtenção não identificou avisos de segurança; isso não substitui revisão futura.

```json
[
  {
    "name": "guzzlehttp/psr7",
    "version": "3.2.0",
    "source": {
      "type": "git",
      "url": "https://github.com/guzzle/psr7.git",
      "reference": "cdc139396207a5eba10c242d241fb014cb098390"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "guzzlehttp/psr7/LICENSE"
    ]
  },
  {
    "name": "laravel/serializable-closure",
    "version": "v2.1.0",
    "source": {
      "type": "git",
      "url": "https://github.com/laravel/serializable-closure.git",
      "reference": "2d5869a838bbcf37e0d8b0568fc41914e81374b5"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "laravel/serializable-closure/LICENSE.md"
    ]
  },
  {
    "name": "php-di/invoker",
    "version": "2.3.7",
    "source": {
      "type": "git",
      "url": "https://github.com/PHP-DI/Invoker.git",
      "reference": "3c1ddfdef181431fbc4be83378f6d036d59e81e1"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "php-di/invoker/LICENSE"
    ]
  },
  {
    "name": "php-di/php-di",
    "version": "7.1.1",
    "source": {
      "type": "git",
      "url": "https://github.com/PHP-DI/PHP-DI.git",
      "reference": "f88054cc052e40dbe7b383c8817c19442d480352"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "php-di/php-di/LICENSE"
    ]
  },
  {
    "name": "psr/container",
    "version": "2.0.2",
    "source": {
      "type": "git",
      "url": "https://github.com/php-fig/container.git",
      "reference": "c71ecc56dfe541dbd90c5360474fbc405f8d5963"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "psr/container/LICENSE"
    ]
  },
  {
    "name": "psr/http-factory",
    "version": "1.1.0",
    "source": {
      "type": "git",
      "url": "https://github.com/php-fig/http-factory.git",
      "reference": "2b4765fddfe3b508ac62f829e852b1501d3f6e8a"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "psr/http-factory/LICENSE"
    ]
  },
  {
    "name": "psr/http-message",
    "version": "2.0",
    "source": {
      "type": "git",
      "url": "https://github.com/php-fig/http-message.git",
      "reference": "402d35bcb92c70c026d1a6a9883f06b2ead23d71"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "psr/http-message/LICENSE"
    ]
  },
  {
    "name": "psr/log",
    "version": "3.0.2",
    "source": {
      "type": "git",
      "url": "https://github.com/php-fig/log.git",
      "reference": "f16e1d5863e37f8d8c2a01719f5b34baa2b714d3"
    },
    "license": [
      "MIT"
    ],
    "license_files": [
      "psr/log/LICENSE"
    ]
  },
  {
    "name": "zbateson/mail-mime-parser",
    "version": "4.0.7",
    "source": {
      "type": "git",
      "url": "https://github.com/zbateson/mail-mime-parser.git",
      "reference": "2d592835ca0d7838e5687b140ff7eec1eb9305c7"
    },
    "license": [
      "BSD-2-Clause"
    ],
    "license_files": [
      "zbateson/mail-mime-parser/LICENSE"
    ]
  },
  {
    "name": "zbateson/mb-wrapper",
    "version": "3.0.1",
    "source": {
      "type": "git",
      "url": "https://github.com/zbateson/mb-wrapper.git",
      "reference": "36dd227ed698d9f5fe995ea75dbcc594a2d880bb"
    },
    "license": [
      "BSD-2-Clause"
    ],
    "license_files": [
      "zbateson/mb-wrapper/LICENSE"
    ]
  },
  {
    "name": "zbateson/stream-decorators",
    "version": "3.0.2",
    "source": {
      "type": "git",
      "url": "https://github.com/zbateson/stream-decorators.git",
      "reference": "4776323764ec592de417ef54f3c8fc96fd242849"
    },
    "license": [
      "BSD-2-Clause"
    ],
    "license_files": [
      "zbateson/stream-decorators/LICENSE"
    ]
  }
]
```

O template misto PHP/texto PHP-DI Compiler/Template.php é preservado byte a byte do upstream: não contém namespaces de dependência e a prefixação nele produziria PHP inválido. O build reproduz essa exceção; todas as classes permanecem isoladas.
