# Manutenção de avisos Slack — Core 1.32.0

Complementa SLACK-1.32.md e SLACK-1.32.md. O agente só opera mensagens registradas pelo Core; não é acesso geral ao Slack.

Principal é procurada no histórico; resposta é procurada com `conversations.replies` sob a principal correta, pelo `ts` exato, mesmo sem pedir a thread inteira. Paginação e consulta incompletas não comprovam ausência.

Comparação ignora ordem das chaves de objetos, preserva ordem de listas e considera somente equivalências seguras: escapes Slack `&amp;`, `&lt;`, `&gt;`, `block_id` e defaults pertinentes. Não decodifica entidades HTML arbitrárias nem ignora formatação, links, emoji relevantes ou texto adicional. Mensagens divergentes não são atualizadas automaticamente.

Excluir exige mensagem de teste registrada, autorização e operação explícita. Após `chat.delete` aceito, releitura deve comprovar ausência. Se ainda presente ou leitura falhar, estado é `confirmacao_pendente`; a retomada relê sem repetir delete. Mensagem já ausente é `ausente`, não uma exclusão atribuída ao Core. Marca antiga apagada que contradiz presença observada fica explícita e pode ser corrigida.

Limpeza concluída exige recibo de remoção e ausência, além de cobertura das threads. Respostas humanas e mensagens de terceiros permanecem. Se respostas não puderem ser verificadas, a principal não é apagada. Presença/aceite não comprova leitura humana.
