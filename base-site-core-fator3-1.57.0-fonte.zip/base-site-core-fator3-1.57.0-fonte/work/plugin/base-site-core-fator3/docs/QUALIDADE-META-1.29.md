> Vigente na 1.30.0: contrato 6.6.0. Consulte SLACK-1.32.md, PUBLICIDADE-1.30.md e QUALIDADE-CATALOGO-1.30.md para os comportamentos substituídos.

# Qualidade comercial e retorno à Meta — 1.29

## Configuração por instalação

O pacote vem desligado e sem etapas/regras. Nenhum ID de funil, campo, campanha, dataset ou cliente é padrão. O mapa aprovado para um site pode ser cadastrado naquele site, sem contaminar os demais.

1. Em Conexões e entregas → Pipedrive, cadastre a credencial e verifique a conta. A identidade combina domínio, conta e instalação. O catálogo não é reaproveitado em outra conta.
2. Em Qualidade e Meta, carregue os funis/etapas. Cadastre códigos estáveis de etapas locais, nomes humanos e, opcionalmente, nome de evento Meta. Evento vazio mantém a etapa somente no Core. Alterar o nome humano não cria outra identidade de conversão.
3. Relacione **conta + estado CRM** a uma etapa local. Funil, formulário e campanha restringem a regra. Estados: lead criado, lead arquivado, negócio ganho/perdido ou etapa do funil. Regra específica prevalece; empate de especificidade bloqueia. Conta, funil e etapa precisam corresponder ao catálogo para ativar.
4. Escolha dataset e versão Graph. Use o token já cadastrado para envio Meta quando autorizado ao mesmo ativo, ou marque credencial própria e cole-a na área protegida. Verificar dataset faz GET; confirma leitura, não capacidade de escrita nem atribuição.
5. Para origem nativa Meta, registre a evidência de publicidade por conta/formulário, data inicial UTC e referência do texto/documento. Receber um formulário não basta como autorização. Para origem web, o Core reconfere a decisão disponível e a revogação.
6. Opcionalmente escolha um campo textual do Pipedrive para guardar o ID do lead Meta. O ID permanece string. O plugin não cria campo remoto. A nota conserva o contexto; campos de respostas podem ser mapeados por formulário ou grupo de perguntas compatíveis.
7. Ative acompanhamento e, separadamente, envio à Meta. Registrar webhooks cria assinaturas v2 de lead e negócio para a URL HTTPS deste site; não remove assinaturas de outros sistemas.

A ficha e a ação em lote registram indicação manual com revisão, horário e motivo. A precedência pode ser temporal (empate favorece manual) ou manual até liberação. Correção pode cancelar outras etapas sem tentativa de envio; eventos já aceitos não são desfeitos. Se a conversão do lead em negócio não puder ser comprovada pela nota vinculada, a ficha permite informar o negócio, conferir existência na conta e confirmar explicitamente o vínculo. Não há associação por semelhança de nome/e-mail.

## Recebimento e execução

`POST /wp-json/f3base/v1/pipedrive/qualidade` recebe webhook autenticado com HTTP Basic e segredo gerado no servidor. Exige conta correspondente e ID de lead/negócio já associado ao próprio contato. Corpo até 128 KiB; limite local 120/minuto por conta. Recibo durável vem antes do aceite; repetição do mesmo evento é idempotente. Exclusão no CRM não é interpretada como arquivamento. Polling consulta estado atual a cada cinco minutos em lotes; não inventa etapas intermediárias não observadas.

Atualizar agora opera sem depender do cron: captação Meta, recibos, consulta CRM e retorno. No contato nativo restringe a importação ao formulário da conta atual; no contato web indica não aplicável. Lote de até 20 s e nunca acima do orçamento restante; cursores duráveis permitem nova chamada. Pausa e recuperação continuam valendo. Captação parcial não equivale a sucesso completo da conta.

Mudanças fora de ordem entram no histórico, sem fazer a etapa atual regredir. O histórico guarda origem, autor, horário de acontecimento/recebimento, revisão do mapa, motivo e estado anterior. Motivo de perda fica cifrado localmente, sem texto livre no payload Meta.

## Envio e idempotência

Uma intenção por site + contato + dataset + código de etapa. Retornar à mesma etapa não cria nova conversão. A aquisição web `Lead` continua sendo tratada pela tag/CAPI existente e não é duplicada pelo retorno CRM. Etapas posteriores usam identidade própria e não vão ao GA4 como outra aquisição.

Payload CRM usa `action_source=system_generated`, origem CRM, horário real, `event_id` estável e identificadores elegíveis. Lead Meta é string; e-mail/telefone usam hashes normalizados. Clique web pode usar fbc/fbp quando autorizados e válidos. Nunca usar IP ou user agent do servidor como se fossem do visitante. Evento deve ser posterior à captura e ter no máximo sete dias; vencido não recebe data de hoje.

429 respeita Retry-After e backoff. Timeout é incerto, conserva payload/ID e não prova aceite; fora da janela conservadora de repetição vai para revisão. Erro permanente não repete sem fim. Mudança de configuração/token suspende a intenção: não muda silenciosamente dataset, evento ou credencial de uma fila antiga. Reativação explícita preserva payload, ID, horário e destino. Resultado incerto exige reconciliação.

Estados da fila: pendente, enviando, entregue, incerto, suspenso, falhou, revisão e cancelado. **Entregue significa aceite da API, não atribuição a anúncio, exibição no Gerenciador ou melhora de qualidade.** O acesso ao ativo e a aceitação real de cada evento devem ser conferidos na conta. A verificação disponível não envia evento comercial de teste.

## Dados, relatórios e agentes

| Estrutura | Granularidade e retenção |
|---|---|
| f3base_qualidade_eventos | Ocorrência local por contato; dados auxiliares cifrados; acompanha o contato |
| f3base_qualidade_atual | Estado atual por contato, com revisão e precedência |
| f3base_qualidade_fila | Intenção semântica por contato/dataset/etapa; payload cifrado; terminais entregues/cancelados/falhos perdem payload após 30 dias, identidade permanece |
| f3base_qualidade_recibos | Recibo do webhook; entrada mínima cifrada; processados perdem payload e são limpos após 30 dias |

A eliminação remove o histórico/fila local do contato e respeita travas; não apaga eventos nas plataformas. Backup inclui as quatro tabelas. Restore e uninstall suspendem pendências; não restaurar filas para replay sem reconciliação.

Abilities (prefixo `f3base/`): `contatos-qualidade-ler`, `contato-qualidade-indicar`, `contatos-qualidade-indicar-lote`, `contatos-qualidade-atualizar`, `qualidade-meta-reenviar`, `qualidade-crm-vincular`, `meta-crm-verificar`. Escritas simulam por padrão; revisão esperada é obrigatória nas alterações concorrentes. Catálogo completo em `dados/abilities-*.json`.

`relatorios-integrados-ler`, `visao: comercial`, cruza etapas e campanhas do recorte de contatos. Expõe contatos distintos, atuais, ocorrências, aceitos, pendentes, bloqueados e ausência de envio. Etapas históricas não são aditivas. Período se refere à captura do contato; os estados são os disponíveis agora. Outros relatórios recebem estado de entrega por canal e quantidade de falhas sem contingência.

Fontes técnicas: documentação Pipedrive de Webhooks v2, Pipelines e Stages; contrato CRM Meta indicado na especificação. O transporte foi simulado no laboratório. Não foi feita homologação em conta comercial real nem comprovada atribuição na Meta.
