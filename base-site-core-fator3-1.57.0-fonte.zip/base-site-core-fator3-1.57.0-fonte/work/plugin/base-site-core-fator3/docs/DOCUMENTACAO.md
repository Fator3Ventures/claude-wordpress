> Atualização 1.57.0: pedidos 312/313 em RELEASE-1.57.0.md, ACERVO-GA4-1.57.md e INSTAGRAM-EXCLUSAO-1.57.md. Esses documentos prevalecem sobre limites anteriores de integração Instagram/GA4.

# Documentação vigente — Core 1.57.0

Contrato administrativo 8.22.0. Conteúdo instalado, com leitura administrativa pelo f3base/documentacao-ler. Pedidos 312–313 e convivência com MCP 0.33.0 em RELEASE-1.57.0.md. Notas anteriores relevantes estão instaladas em docs/history e indexadas em como-usar/mudancas.

| Necessidade | Documento |
|---|---|
| Especificação e uso | INSTRUCOES-DO-PLUGIN.md, README.md, LEADS-E-FORMULARIOS.md |
| Configuração e descrições por campo | CONFIGURACAO.md, AJUDA-OPCOES.md, dados/configuracao-schema.json |
| Contratos/schemas | CONTRACTS.md, dados/abilities-*.json, schemas/*.json |
| Agentes e release | AGENTES-1.57.0.md, RELEASE-1.57.0.md |
| Operação/recuperação | OPERACAO-E-RECUPERACAO.md, CRON-DIAGNOSTICO-1.31.md |
| Contatos externos e atribuição manual | CONTATOS-EXTERNOS-1.54.md |
| Sessões, autenticação, IMAP e provas cron | OPERACAO-1.55.md |
| Acervo GA4 e exclusão Instagram | ACERVO-GA4-1.57.md, INSTAGRAM-EXCLUSAO-1.57.md |
| Conversas WhatsApp e Instagram | CONVERSAS-1.56.md |
| Histórico de versões | history/RELEASE-*.md; como-usar incluir mudancas |
| Correio por site | EMAIL-SITE-1.53.md, DEPENDENCIAS-EMAIL-1.53.md |
| Iscas e política de avisos | FORMULARIOS-SINAIS-1.53.md |
| Credenciais | CREDENCIAIS-1.51.md |
| Pipedrive | PIPEDRIVE.md, PIPEDRIVE-1.37.md, PIPEDRIVE-OPERACAO.md, ORCAMENTO-PIPEDRIVE.md |
| Meta e LinkedIn | META-ACESSO-1.28.md, META-TRANSPORTE-1.19.md, LINKEDIN-LEAD-SYNC.md |
| Dados, retenção e consentimento | DICIONARIO-DADOS.md, RETENCAO-1.45.md, FORMULARIOS-TENTATIVAS-1.44.md |
| Provas e limitações | VALIDACAO.md e relatório externo da entrega |

O índice retornado pela ability contém a lista exata disponível, inclusive demais guias de domínio vigentes. Nomes versionados de domínio indicam origem do contrato, não uma instalação anterior. Leia todas as páginas (arquivo, linha, limite até 200, proxima_linha); confira hash e versão. Help estático não testa API, não grava opções e não repara cron.
