# Fator3 Site Core 1.57.0

Comece em DOCUMENTACAO.md e AGENTES-1.57.0.md. Pedidos 312/313 em RELEASE-1.57.0.md, ACERVO-GA4-1.57.md e INSTAGRAM-EXCLUSAO-1.57.md. Pedidos anteriores 307–311 permanecem documentados em history/RELEASE-1.56.0.md e CONVERSAS-1.56.md; contatos externos do pedido 302 em CONTATOS-EXTERNOS-1.54.md. Contrato administrativo 8.22.0, cliente pipedrive-api-client/1.0.0 preservado.
