# Textos alterados — 1.44.0

Revisão das 20 áreas renderizadas: controles, rótulos, descrições, ajuda, formatos de data e instruções de edição. Verificação automatizada de cobertura e inspeção dos textos encontrados por assunto, com alterações abaixo. Textos técnicos necessários a webhooks, cotas UTC e formatos de logs foram preservados. A revisão não altera contratos de dados nem substitui o aceite visual no tema de cada site.

```json
{
  "versao": "1.44.0",
  "descricoes": {
    "f3base_formularios": "Edite os campos, as etapas, as mensagens e os destinatários em Site Core → Formulários. Cada formulário tem uma revisão própria; salve suas alterações antes de editar outro.",
    "f3base_email_novo_lead": "Envia uma resposta automática após a confirmação de um novo lead no Pipedrive. Configure a conta de envio, os textos e a cota por hora. Cada destinatário, inclusive cópias ocultas, consome uma unidade dessa cota.",
    "f3base_meta_janela.conferida_em": "Escolha o dia em que os limites da Meta foram conferidos na documentação oficial. A conferência vale por 90 dias.",
    "f3base_gsc.inicio": "Escolha o primeiro dia da série que deseja importar. Vazio começa nos últimos 30 dias disponíveis. Períodos maiores são preenchidos em passagens sucessivas.",
    "f3base_gsc.ativo": "Coleta dados quando o MCP Google estiver disponível e a propriedade estiver autorizada. Desativar pausa novas consultas e preserva o histórico.",
    "f3base_seo_entidade.endereco": "Preencha logradouro, cidade, estado, CEP e país nas linhas do editor. O endereço é opcional; quando informado sem país, usa Brasil.",
    "f3base_pipedrive.mapa_campos": "Escolha o campo do Pipedrive que receberá cada informação do contato. Selecione Somente na nota para conservar a informação sem preencher um campo comercial.",
    "f3base_pipedrive.mapa_canais": "Associe cada origem de anúncio a uma alternativa do campo Canal. Origem não identificada significa falta de evidência, não visita orgânica comprovada.",
    "f3base_pipedrive.mapa_parceiros": "Associe cada código de parceiro à alternativa da conta. Use as opções de ausência de campanha, fora do padrão e origem não observada quando correspondam ao contato.",
    "f3base_pipedrive.mapa_pontos": "Escolha as alternativas para formulário do site, formulário com WhatsApp e formulário nativo de anúncios. Um clique sem envio não cria uma pessoa no CRM.",
    "f3base_pipedrive.mapa_servicos": "Associe as respostas do formulário às alternativas de Serviço. Respostas conhecidas podem selecionar vários serviços; respostas sem correspondência permanecem na nota.",
    "f3base_pipedrive.mapa_servicos_formularios": "Escolha o serviço associado a cada formulário nativo. Esta regra é usada quando a resposta do contato não determina o serviço. A regra do formulário tem prioridade sobre a da campanha.",
    "f3base_pipedrive.mapa_servicos_campanhas": "Escolha o serviço de cada campanha. Esta regra é usada quando não há serviço definido pela resposta ou pelo formulário. Nenhuma associação deixa o campo sem serviço inferido.",
    "f3base_pipedrive.mapa_respostas": "Selecione formulário, pergunta e campo de destino. Para perguntas com alternativas, relacione cada resposta à alternativa correspondente da conta. Respostas sem mapa permanecem na nota.",
    "f3base_pipedrive.campos_fixos": "Escolha os campos que sempre receberão um valor definido nesta integração. Confira o tipo e as alternativas da conta antes de salvar.",
    "f3base_pipedrive.parceiros_plataforma": "Defina o parceiro a usar para cada plataforma de anúncio quando não houver uma regra mais específica para a campanha.",
    "f3base_pipedrive.mapa_pessoa": "Escolha os campos da pessoa que receberão o perfil LinkedIn e o link de WhatsApp informados pelo contato. O plugin não procura perfis na rede social.",
    "f3base_pipedrive.atividade_canais": "Escolha o tipo e o assunto da primeira atividade para WhatsApp, e-mail e tarefa. Os tipos precisam existir no Pipedrive. Informar telefone não comprova que ele possui WhatsApp.",
    "f3base_pipedrive.atividade_janela": "Defina fuso, dias de atendimento, abertura, fechamento, prazo e horário de retomada. Contatos fora da janela são programados para o próximo horário útil. Feriados não são calculados e atividades existentes não mudam.",
    "f3base_pipedrive.site_alternativa": "Escolha a alternativa que representa este site quando o campo Site for uma seleção. Campos de texto recebem o endereço principal do site automaticamente.",
    "f3base_anuncios_meta.formularios": "Atualize a lista e selecione os formulários administrados por este site. Salve para aplicar. Nenhuma seleção não autoriza a importação de todos os formulários.",
    "f3base_anuncios_meta.mapeamento": "Relacione os campos recebidos aos dados de contato e associe nomes às campanhas. Adicione ou remova linhas no editor; salvar aplica as regras aos próximos contatos.",
    "f3base_anuncios_google.formularios": "Atualize a lista e selecione os formulários administrados por este site. Salve para aplicar. Nenhuma seleção não autoriza a importação de todos os formulários.",
    "f3base_anuncios_google.mapeamento": "Relacione os campos recebidos aos dados de contato e associe nomes às campanhas. Adicione ou remova linhas no editor; salvar aplica as regras aos próximos contatos.",
    "f3base_anuncios_meta.paginas": "Atualize a lista e selecione as páginas autorizadas. Salve a seleção antes de consultar os formulários dessas páginas.",
    "f3base_anuncios_google.campanhas": "Selecione as campanhas autorizadas para contatos conversacionais sem formulário identificado. Sem seleção, esses contatos são recusados. Formulários tradicionais continuam exigindo autorização própria.",
    "f3base_anuncios_linkedin": "Escolha o cliente e a conta para importar contatos do LinkedIn. Com Plugin LinkedIn, as listas usam a conexão desse plugin; a importação ainda exige os formulários e as permissões concedidos ao Site Core.",
    "f3base_pipedrive.unidade": "Selecione a unidade que receberá os novos contatos. A alternativa precisa existir no campo Unidade da conta conectada.",
    "f3base_pipedrive.linkedin_modo": "Escolha onde guardar o perfil profissional informado pelo contato. Apenas na nota conserva o endereço no resumo; Escolher campo usa o campo de pessoa selecionado; Detectar campo exige uma única opção compatível no catálogo. O plugin não procura perfis na rede social.",
    "f3base_consentimento.politica_versao": "Identifique a versão da política publicada. Mudanças nas regras podem exigir nova escolha do visitante; não concedem autorização retroativa.",
    "f3base_llms.entrega": "Arquivo gerado publica o índice para entrega direta pela hospedagem. Dinâmica produz cada resposta pelo WordPress. Escolha Arquivo gerado quando a raiz for gravável e a atualização automática estiver funcionando."
  },
  "outros": [
    "Datas Meta e Search Console sem formato nos rótulos",
    "Datas de qualidade no fuso do WordPress",
    "Títulos de mapeamentos por assunto",
    "Serviços e ofertas, mapeamento da pessoa e das respostas sem referência a JSON",
    "Orientação para ativar JavaScript preservando valores",
    "Simulação de recuperação com motivos por destino",
    "Comparação anterior parcial e definições de sessões",
    "Limites e exclusões da leitura de desempenho",
    "Pipedrive: alternativa do site sem ID no rótulo",
    "Pipedrive: orientação de ativação pelo nome do controle",
    "Consentimento: ajuda da faixa não descreve modal bloqueante",
    "Privacidade: captura de valores e retenção de tentativas, com limites e exclusão"
  ]
}
```
