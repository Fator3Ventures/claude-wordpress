# Contatos externos e sessões atribuídas manualmente

## Registrar

`f3base/contato-externo-registrar` exige manage_options, f3base_ler_leads e f3base_gerir_leads. Entrada: idempotency_key (8–128 caracteres ASCII de letras, números, ponto, hífen, sublinhado e dois-pontos), metodo (whatsapp, telefone, email, presencial, outro), nome, telefone e/ou email, empresa, primeiro_contato_em em RFC3339 com fuso, origem_declarada, pipedrive e contexto_teste. E-mail ou telefone é obrigatório para whatsapp/telefone/email; presencial/outro permite identidade sem endereço. O primeiro contato não pode estar no futuro. Valores pessoais não são aceitos nas sessões nem nos eventos.

origem_declarada usa canal, parceiro, utm_source, utm_medium, utm_campaign, utm_content, utm_term, utm_id e utm_source_platform; link_referencia aceita HTTP/HTTPS sem credenciais. Os valores são declarados pelo operador, não observações do navegador. São cifrados com o contato. Para entrega CRM, canal/parceiro usam as chaves dos mapas comerciais; o conteúdo e a campanha usam as chaves UTM existentes.

simular é true por padrão. A prévia informa campos presentes e efeitos, sem repetir dados pessoais no recibo que o transporte pode guardar. Sem persistência local de contato, sem HTTP e sem filas. A gravação retorna record_id e revisão. Mesmo conteúdo/chave devolve o mesmo contato; conteúdo diferente retorna idempotencia_conflitante; chave de contato eliminado retorna contato_externo_ja_eliminado. O hash interno é HMAC do conteúdo canônico e a chave é armazenada como HMAC. Contato, origem, referência CRM e auditoria ficam em Secretbox no próprio registro; colunas nome/email/pagina e sessao permanecem vazias.

No MCP 0.32.0 o transporte também controla idempotência: **use uma chave para a simulação e outra para a gravação**. Repetição de gravação conserva a segunda chave e todos os parâmetros. Alterar simular usando a mesma chave do transporte é conflito, embora a simulação não tenha criado contato no Core. Não enviar entradas pessoais a planos genéricos persistentes do canal.

pipedrive.acao é nenhuma (padrão), entregar ou vincular_existente. entregar requer ponto, uma chave com valor configurado em mapa_pontos; não aceita lead_id. O contato e sua intenção de entrega são persistidos juntos; a fila durável faz entrega e retentativa pelos contratos existentes. Configuração removida posteriormente leva à revisão. contexto_teste requer homologacao no Pipedrive para entregar.

vincular_existente requer lead_id UUID e não aceita ponto. Na gravação, confirma por GET no domínio/conta verificados, cifra a referência e não cria lead, pessoa, nota, atividade ou fila. A simulação avisa que o GET ocorrerá na gravação. Falha na confirmação não grava contato. Apagar o contato local remove a referência; não apaga o lead preexistente. A semântica normal de exclusão do CRM continua aplicável a uma entrega nova de propriedade do Core.

Slack, webhook, e-mail automático, GA4, Meta, Google Ads e LinkedIn não são acionados por essas rotas. Não existe opção para disparar conversão retroativa.

## Vincular e desfazer

`f3base/contato-sessao-vincular` exige as mesmas três capacidades. Entrada: record_id, sessoes (1–20 hashes distintos), decisor (até 200 caracteres), motivo (até 300), acao vincular/desvincular, simular e revisao. Execute prévia; copie a revisão para a gravação. A revisão é inteira, a mesma do registro de contato. Revisão ausente/antiga retorna conflito com a atual. O servidor registra seu próprio operador_id e timestamp; decisor identifica quem tomou a decisão e não substitui o executor autenticado.

Sessões devem ter eventos retidos e classe de tráfego compatível com o contato. Um hash presente em mais de uma classe é ambíguo. Não se permite atribuir a sessão a dois contatos manualmente. Para corrigir, desfaça o vínculo anterior antes de criar o novo. Cada lote grava os vínculos e auditoria em uma transação; falha reverte o lote. Máximo de 100 sessões ativas e 500 alterações por contato; a auditoria não é descartada silenciosamente para liberar espaço. Desfazer dispensa eventos ainda retidos, para permitir remover vínculos antigos.

A operação não preenche a coluna sessao do contato nem altera origem, consentimento, eventos ou sessões originais. O índice guarda apenas record_id, sessao, classe e vinculado_em. Quem decidiu e motivo ficam cifrados em dados.sessoes_manuais_cifradas. A exclusão normal do contato remove o índice e esse conteúdo. Os dados associados seguem a retenção do contato; eventos seguem sua retenção própria.

## Ler e filtrar

`f3base/lead-jornada-ler` conserva a jornada observada e adiciona contato_externo e atribuicoes_manuais. Esta última contém auditoria, sessões e eventos retidos com origem observada e indicador posterior_ao_contato. Até dez sessões por página (historico_pagina); cada uma traz até 500 eventos de análise e sinal de corte, com detalhamento completo pela consulta de sessão. Eventos com revogação conhecida são omitidos. O vínculo humano não prova consentimento nem causalidade.

`f3base/sessao-detalhar` adiciona contatos_vinculados (record_id, tipo_atribuicao e decisão) a quem tem f3base_ler_leads. Nenhum nome/telefone/e-mail é copiado para a sessão. `f3base/leads-ler` projeta os dados cifrados para leitura autorizada. A listagem administrativa exibe o contato; filtro exato de email usa índice HMAC. Busca parcial por nome ou telefone não abre o acervo cifrado.

`tipo_atribuicao` em conteudos-relatorio e aquisicao-relatorio: todas mantém a cobertura anterior; observada seleciona sessões sem vínculo manual ativo; atribuicao_manual seleciona sessões com vínculo ativo. Os agrupamentos de canal/conteúdo continuam usando fatos observados. Uma sessão não é contada duas vezes; o contato externo não é tratado como formulário enviado. Agregados expirados e robôs sem sessão não podem receber esse filtro, ficando fora do recorte com cobertura explícita. A origem declarada do contato não substitui o canal da sessão.

## Erros e recuperação

Conflitos de revisão, identidade idempotente, sessão desconhecida/ambígua, classes divergentes, vínculo a outro contato, contato excluído ou tabela indisponível falham sem aplicação parcial. Se houver resposta de transporte perdida, repita a chave exata de registro ou releia o contato e a revisão antes de repetir o vínculo. Não presuma falha de gravação a partir de um timeout. Backups devem incluir contato e índice na mesma fotografia; a operação de restore/drain vigente permanece obrigatória.
