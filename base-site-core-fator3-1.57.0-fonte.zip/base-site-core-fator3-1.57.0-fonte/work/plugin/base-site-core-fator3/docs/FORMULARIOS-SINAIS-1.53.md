# Iscas e avisos — 1.53.0, pedido 301 atualizado

A quarta isca tem rótulo Segmento de atuação, nome segmento_atuacao e ID f3base-segmento-N. Texto normal no HTML, ocultação .f3base-isca e aria-hidden=true, tabindex=-1, autocomplete=off, autocapitalize=off, spellcheck=false e data-1p-ignore/data-lpignore/data-bwignore=true. As três anteriores mantêm HTML e significado histórico. Os valores das iscas continuam cifrados, privados no WordPress e excluídos de Slack, e-mail, webhook, CRM e anúncios.

O campo ausente é equivalente a vazio; não há prazo para rejeitar HTML antigo. A nova chave consta das listas aceitas do envio e complemento e da exclusão de campos reais no JavaScript. O filtro sinal de leads-registros-ler aceita isca_segmento_atuacao, os anteriores e nomes de sinais futuros.

## Configuração por site

Tela Site Core → Configurações → Conexões e entregas → Avisos: uma linha por sinal, colunas Marcar suspeito e Permitir aviso. Option f3base_formularios_sinais operável em config-core-escrever, simulação padrão, escrita simular=false com revisao_esperada atual. Leitura em config-core-ler e como-usar (assunto avisos). Como-usar também retorna linhas, uma lista de objetos {sinal,suspeito,aviso}; use-a para releitura completa no MCP 0.31.0, cujo redator trata chaves contendo token como segredos na projeção regras. Nenhum valor de token integra estas regras. Nunca editar tabelas diretamente para mudar esta preferência.

Schema do valor: objeto de até 100 propriedades; chaves [a-z0-9_]{1,80}; cada valor exige duas propriedades booleanas suspeito e aviso, sem propriedades adicionais. Sinais novos podem ser acrescentados; desconhecidos sem regra só registram sinal.

```json
{
  "isca_website": {"suspeito": false, "aviso": false},
  "isca_ctodesenvolvimentofator3": {"suspeito": true, "aviso": true},
  "isca_segmento_atuacao": {"suspeito": true, "aviso": true},
  "isca_comentario": {"suspeito": true, "aviso": true},
  "tempo_curto": {"suspeito": false, "aviso": false},
  "token_vencido": {"suspeito": false, "aviso": false},
  "token_revisao_anterior": {"suspeito": false, "aviso": false},
  "token_assinatura_invalida_ou_ausente": {"suspeito": true, "aviso": true},
  "sem_pagina_origem": {"suspeito": true, "aviso": true},
  "cota_excedida": {"suspeito": true, "aviso": true}
}
```

suspeito=false mantém o sinal e permite contato aceito quando nenhum outro sinal marca suspeita. aviso=true só pesa entre sinais com suspeito=true. Contato suspeito por dois sinais avisa se pelo menos um deles permitir. A condição contato_valido da 1.52.1 permanece: nome e e-mail ou telefone válido. Sem contato válido, aviso não é emitido, mesmo com permissão na regra.

A decisão persiste em dados.sinais_politica: suspeito, aviso, sinais_suspeitos, sinais_aviso, aviso_suprimido e revisao. Supressão pela política usa aviso=suprimido_sinais e impede fila Slack e contingência; contatos continuam aprováveis. O worker verifica a decisão atual antes de emitir avisos anteriores quando a etapa 2 mudou a classificação. Aprovação explícita permite entrega pelas regras normais.

Contagens suspeitos_sem_aviso.7_dias/30_dias contam contatos ainda suspeitos, retidos, fora da lixeira e sem eliminação pendente, excluindo teste, cuja decisão registrada suprime aviso. Aprovar/eliminar tira o contato desta contagem atual; não é um histórico imutável de incidentes. Alterar regras não recalcula contatos antigos.

## Ordem específica CTO Office

Após instalar 1.53.0: ler o valor e sua revisão; manter os demais sinais; definir isca_segmento_atuacao e isca_ctodesenvolvimentofator3 como {suspeito:true,aviso:false}; simular e aplicar, reler. comentario+ctodesenvolvimentofator3 ainda permite aviso por comentario. Nos outros 11 sites, defaults até nova ordem. Conferir os dois formulários da home após limpar o cache autorizado e observar as contagens por 30 dias.

## Autopreenchimento: prova e limite

Os termos pessoais enumerados no pedido não estão no rótulo, name ou ID da quarta isca. Hints de gerenciadores são voluntários e autocomplete=off é a instrução HTML de não preencher. Valores inventados de autocomplete são inválidos e não garantem o comportamento requerido; não foram usados como falsa garantia. O teste estático confere esses atributos e a ocultação, mas a matriz de navegadores reais continua pendente. Documento HTML: https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofilling-form-controls:-the-autocomplete-attribute.
