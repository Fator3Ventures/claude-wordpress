# Prazos de guarda — Core 1.45.0

Todos os campos abaixo usam meses de calendário, faixa de 1 a 120. A tela apresenta nome em palavras e unidade. Padrão aplica-se à instalação nova; reduzir um prazo torna dados vencidos elegíveis para limpeza. Retenção não amplia a janela de envio de um fornecedor nem cria dados históricos ausentes.

| Configuração | Prazo padrão |
|---|---|
| f3base_retencao_meses — contatos | 60 meses |
| f3base_comportamento.retencao_meses / retencao_eventos_meses | 60 / 60 meses |
| f3base_acessos.retencao_meses / retencao_horaria_meses | 60 / 60 meses |
| f3base_medicao_editorial.retencao_meses | 60 meses |
| f3base_pipedrive.retencao_entregas_meses | 60 meses |
| f3base_formulario_tentativas.retencao_meses | 60 meses |
| f3base_clarity.retencao_meses | 60 meses |
| f3base_retencoes_tecnicas: retencao_avisos_meses, retencao_meta_capi_meses, retencao_recusas_meses, retencao_404_meses, retencao_sondas_meses, retencao_diagnostico_meses | 60 meses cada |
| f3base_retencoes_tecnicas.retencao_operacoes_meses | 6 meses |

Os campos legados retencao_dias, retencao_eventos_dias, retencao_horaria_dias e retencao_entregas_dias são convertidos para os correspondentes mensais. O arredondamento sobe até que o corte em meses não encurte o prazo em dias no instante da migração, usando o fuso do WordPress. O fim do mês é limitado ao último dia existente. Clarity 0 (sem expiração) passa a 120 por decisão expressa. Contatos já gravados acima de 120 não são reduzidos silenciosamente; novas gravações acima do limite são recusadas. A procedência da escolha permanece, com nova revisão e evento de migração em config_complementacoes.

Fila e recibos do retorno de qualidade à Meta expiram em até sete dias; o histórico comercial acompanha o contato. A marca contra reaparecimento de tentativa eliminada acompanha a guarda das tentativas com um dia adicional. Permanecem os prazos de consentimento, aquisições, deduplicação, recibos nativos e diários que acompanham o contato. Prazo de transmissão Meta sete dias, GA4 72 horas e Google Ads 90 dias do clique não mudam.

A frota deve ler os valores convertidos após a atualização, conferir revisões e então aplicar 60 meses conforme a decisão do dono. Este instalador não executa essa configuração em massa. Lotes do Implantador devem descobrir o schema 8.10.0 e enviar as novas chaves; não reaproveitar numerais em dias como se fossem meses.
