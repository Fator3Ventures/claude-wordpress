# Fator3 Site Core 1.56.0

Base direta 1.55.0; contrato administrativo 8.21.0. Identidade base-site-core-fator3/base-site-core-fator3.php preservada. Pedidos Core 307–311 e consumidor opcional do SDK Meta 0.11.1. Configurações e dados anteriores permanecem. As entradas novas começam desligadas. Nenhuma atualização publica esta versão na frota automaticamente.

## 307 — aprovação sem entrega

Aprovar com entregar:false registra entrega.pipedrive.motivo=aprovado_sem_entrega, em, versao, operador e operation_id. aprovacao_historico preserva entrega_anterior. O identificador da decisão também sai em aprovacao_operation_id: o MCP usa seu próprio operation_id de transporte e preserva essa referência Core. Uma entrega anteriormente solicitada permanece solicitada: aprovar novamente sem entrega não cancela uma fila existente. Entregar:true mantém o fluxo anterior, sem conversões retroativas.

leads-registros-ler projeta aprovacao_entrega; crm.pipedrive e entregas_por_canal distinguem esse estado. leads-ler e relatorios-integrados-ler trazem aprovados_sem_entrega separado, sem somá-lo às falhas. Registros anteriores são projetados sem escrita quando existe aprovacao/aprovacao_historico ou transição auditável entre dados.captura=suspeito e captura=aceito com revisão maior que 1 e intenção original captura_nao_aceita. A projeção informa a evidência e anterior_regra. Aceite sem essa evidência não vira aprovação presumida.

## 308 — celular brasileiro com oito dígitos

DDD válido seguido por oito dígitos iniciados em 6, 7, 8 ou 9 é celular. O link wa.me e a primeira atividade usam WhatsApp no mesmo expediente/prazo vigente. Não se insere o nono dígito. Prefixos 2–5 continuam fixos; DDD inválido não se torna móvel. Regra br-celular-8-prefixo-6-9 aparece em telefone_normalizacao.classificacao, prévia da atividade e linhas da visão telefones_normalizacao. Leitura reavalia a marca antiga de formato livre desse caso específico; não regrava números nem atividades já criadas.

## 309 — conversas WhatsApp pela ponte Slack

f3base_whatsapp_site contém ativo, canal, numero, bots autorizados, usuarios_equipe, numeros_ignorados, ponto, mapa_codigos e caminhos campos do envelope da ponte. Leia CONVERSAS-1.56.md. whatsapp-conversa-verificar consulta uma amostra sem importar; informa escopos retornados pelo Slack. whatsapp-conversa-consultar simula por padrão; aplicar exige revisao. O cron usa o mesmo coletor, autorização de administrador vigente, trava e estado incremental.

A janela é esgotada antes da criação dos contatos, para preservar a primeira mensagem mesmo entre páginas em ordem inversa. Identidade é telefone com código de país escopado ao número do site. Primeiro contato vira whatsapp_conversa; repetição e tombstone de exclusão impedem novo registro. Dados e trecho de triagem de até 300 caracteres ficam cifrados. Nenhuma sessão é inferida, nenhum evento/conversão de anúncio é criado e não há e-mail automático. [TESTE F3BASE] força contato de teste sem Slack/CRM, mesmo que homologação global esteja habilitada. Números configurados como ignorados e mensagens da equipe não entram.

Avisos comerciais usam a configuração Slack já existente; o ponto é uma chave de mapa_pontos. A criação da alternativa na conta Pipedrive é configuração administrativa externa. O fluxo comercial existente pesquisa telefone e reutiliza oportunidades abertas. A homologação do envelope real Twinia e a conversa real [BIO] dependem do canal, dos campos e das permissões da instalação.

## 310 — histórico instalado

Notas 1.49.0, 1.49.1, 1.50.0, 1.51.0, 1.52.0, 1.52.1, 1.53.0, 1.54.0 e 1.55.0 estão em docs/history, no índice documentacao-ler e em dados/mudancas.json. A nota 1.52.0 é do candidato substituído por 1.52.1, identificado como tal. como-usar com incluir:["mudancas"] e desde_versao:1.48.0 devolve notas. Conteúdo histórico descreve aquela versão; regras atuais prevalecem. Sem nova retenção de eventos ou recontagem retroativa.

## 311 — prova SMTP

Caixas novas usam 587/tls; valores persistidos, inclusive 465/ssl, são preservados. email-smtp-verificar prova CONNECT, TLS e AUTH sem MAIL/RCPT/DATA e grava somente recibo técnico, inclusive em simulação. Pode comparar smtp_porta e smtp_seguranca sem alterar a configuração. Validade de 900 segundos vinculada a host, porta, segurança, usuário, remetente e revisão da senha. Não retorna segredo nem diagnóstico bruto do servidor.

Habilitar envio_ativo ou mudar sua conexão enquanto habilitada exige prova vigente. Uma instalação já habilitada permanece habilitada ao atualizar; a troca não desliga serviço existente. Códigos: smtp_porta_recusada, smtp_porta_sem_resposta, smtp_tls_falhou, smtp_autenticacao_recusada, smtp_protocolo_falhou, smtp_dns_indisponivel e smtp_destino_invalido. Erros de preparação permanecem distintos de incerteza após DATA. A tela E-mail do site mostra a prova e permite executá-la sem enviar mensagem.

## Meta — Instagram primeiro contato disponível

Consumidor site-core, contrato instagram-first-message/1.0.0, registrado no SDK público Meta antes de plugins_loaded/20. Configuração f3base_instagram_conversas optativa por conexão/conta, com autorização própria para Slack/CRM. Persistência cifrada e recibo são atômicos na linha do contato; deduplicação usa a chave estável do Meta. Não chama a rota manual contato-externo-registrar.

Preserva origem comprovada e coverage; unknown continua desconhecida. Não infere nome, telefone, e-mail, sessão ou consentimento. Quando CRM for explicitamente autorizado, pessoa sem nome recebe apenas o rótulo técnico Contato Instagram, sem busca por esse rótulo. instagram-conversa-recibo consulta/reconcilia recibo real pelo SDK, com revisão, sem repetir ingestão. Após exclusão local, tombstone impede reimportação. Meta 0.11.1 não oferece SDK público de eliminação: a leitura de exclusão informa pendente_sdk_exclusao_meta. Pedido separado ao mantenedor Meta; esta versão não declara removida uma cópia externa.

## Operação e compatibilidade

MCP 0.33.0 transporta as novas abilities; não requer código novo para as regras de domínio. Pipedrive usa pipedrive-api-client/1.0.0. Nenhum acompanhante é necessário para documentação local. Operações de conta exigem manage_options, com capacidades de contatos nas rotas correspondentes. Configuração usa revisão otimista; leia o schema instalado antes de aplicar.

Nenhuma tabela nova. Contatos conversacionais usam o acervo de contatos e suas filas cifradas; exclusão elimina dados e pendências e mantém marca de deduplicação. Cursor/autorizações/prova são options próprias. Restaurar arquivos não desfaz contatos ou efeitos externos; preservem-se bancos, cifras e marcadores operacionais. Provas executadas, versões exatas e pendências constam do relatório externo da entrega.
