# Fator3 Site Core 1.52.0

Base direta 1.51.0; contrato administrativo 8.17.0; 146 abilities do Core. Requer WordPress 7.1.2, PHP 8.3.6 de 64 bits, instalação única. Instalador com identidade publicada base-site-core-fator3/base-site-core-fator3.php. Pacotes considerados: MCP 0.30.1, Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1, Pipedrive 0.1.0. Nenhum acompanhante é necessário para a ajuda local.

## Pedido Core 296 — dados pessoais e transições

O adaptador email-legado, o alias integracao=f3base_c0 e a etapa email_novo_lead_migracao foram retirados. E-mail usa exclusivamente f3base_email_novo_lead e os textos configurados no site. A tela é Configurações → Conexões e entregas → E-mail automático ao novo lead, integracao=f3base_email_novo_lead. O importador temporário CF7 sem chamador e os ganchos/inferência Elementor foram retirados. O valor histórico elementor segue aceito na leitura dos registros existentes.

Atualização de instalação existente exige f3base_email_migracao_142=concluida. Sem essa marca, email_migracao_142_pendente bloqueia antes das etapas; confira a instalação-base e conclua sua migração, sem forjar a marca. Instalação nova sem resíduos não depende de migração e registra a condição satisfeita ao materializar padrões. O ciclo tem 17 etapas.

Nova ability administrativa f3base/email-legado-limpar: simular=true fornece revisão e presença dos três resíduos, sem valores secretos. Aplicar com simular=false e revisao exatamente igual. Exige manage_options. Confere conteúdo antigo na configuração corrente, senha decifrada equivalente, quota e linhas de tabela. Dados divergentes/ilegíveis impedem exclusão. Uma tabela antiga não vazia só pode ser eliminada se cada linha, exceto chave técnica, estiver integralmente preservada na tabela corrente. Não migra nem reconstrói configuração.

Alvos exclusivos: f3base_c0, f3base_c0_cota, f3base_c0_smtp_senha e tabela prefixada f3base_c0. Escrita usa trava, releitura sob lock de tabelas e exclusão exata das options; DROP e DELETE não constituem uma transação única. Se houver falha parcial, applied=true informa efeito já ocorrido; reler e simular de novo. Nenhum backup secreto adicional é criado por esta ability. Antes da limpeza, o operador mantém o backup normal do site; voltar arquivos não restaura resíduos apagados. A configuração atual e sua cifra permanecem intactas. Limpeza não é automática na atualização.

Documentos substituídos foram movidos para history/ no fonte. O instalador e f3base/documentacao-ler contêm somente documentos selecionados como vigentes; caminhos históricos removidos deixam de constar no índice. Não dependem de aliases para abrir manuais antigos.

## Pedido Core 297 — catálogo de acessos

A montagem mede memory_get_usage(false) inicial e pico incremental observado por lote de 100 rotas. O teto próprio é o menor entre 32 MiB e metade da memória disponível após reservar 16 MiB do memory_limit efetivo; -1 não cria teto artificial do processo inteiro. Se não couber, usa consultas indexadas por caminho/instante e cache limitado a 128 resoluções. O dia continua sendo processado, sem publicar contribuição parcial como completa.

f3base/como-usar retorna acessos_servidor.catalogo: memoria_inicial_bytes, processo_inicial_alocado_bytes, memory_limit_bytes, teto_incremental_bytes, pico_incremental_bytes, modo, linhas, codigo e em. Pico é amostrado durante a montagem, não o pico global histórico do PHP. Falha de banco/leitura deixa o arquivo pendente; codigo e proxima_tentativa aparecem no mesmo bloco. O diário preserva a contribuição anterior e agenda tentativa posterior; falha de agendamento deixa a próxima tentativa null, não inventa confirmação.

## Pedido Core 298 — incidentes e prioridade

Diagnóstico captacao_meta e anuncios.meta.operacao publica cadência observada, tolerância, passagens perdidas, falhas de transporte e limiares. Atrasada exige duas cadências mais tolerância (máximo entre 300 segundos e 20% da cadência). Transporte exige três falhas consecutivas graph_transporte_indisponivel. Falha de autorização/configuração mantém diagnóstico imediato; uma janela parcial não confirma recuperação.

Incidente tem início, causa, abertura e encerramento. A recuperação cancela abertura ainda pendente. Abertura é tentada uma única vez; encerramento só é enviado se a abertura foi aceita pelo wp_mail. Ambos informam hora do estado e hora do envio; encerramento inclui início, fim e duração. Falha/incerteza de envio não autoriza repetição. O Core não controla atrasos posteriores em servidores ou plugins de e-mail: processado significa aceite pelo wp_mail, não recebimento. A leitura diagnóstica não envia mensagens.

Captação Meta, consulta LinkedIn, entrada LinkedIn e entregas Pipedrive/avisos Slack/e-mail vencidas precedem manutenção no executor, CLI e WP-Cron. Cada um dos seis hooks tem até 30 segundos locais, uma oportunidade por passagem; não consome as três tarefas/30 segundos de manutenção. Preserva pausas administrativas, recuperação, locks, backoff, identidade, quotas de fornecedor e resultados incertos. Não garante prazo quando hospedagem termina PHP, cron não roda, fornecedor recusa ou uma reserva está ocupada. executar-pendentes respeita tarefas selecionadas; limite restringe a manutenção. Respostas trazem prioridade e duracao_ms por tarefa. Não há novas mensagens nem chamadas no carregamento da documentação.

## Integrações e limites

pipedrive-api-client/1.0.0, orçamentos separados e operação desligada por padrão permanecem. credenciais-ler/credenciais-verificar e avisos de token salvo da 1.51.0 permanecem. O relato Implantador 2.11.0 foi recebido para análise do schema; consulte o relatório externo para a evidência efetivamente obtida, sem presumir a validação do pacote alheio. Nenhum contrato de Meta, LinkedIn, Google ou Pipedrive foi renomeado.

Sete dias de observação na frota são aceite posterior. Homologação sintética não comprova entrega comercial ou de correio. Consulte o relatório externo para instalações/testes feitos, hashes e pendências; este manual descreve o software, não registra provas ainda não executadas.


Nota de arquivo da 1.56.0: 1.52.0 foi candidato substituído pela 1.52.1; não é base de atualização desta entrega.
