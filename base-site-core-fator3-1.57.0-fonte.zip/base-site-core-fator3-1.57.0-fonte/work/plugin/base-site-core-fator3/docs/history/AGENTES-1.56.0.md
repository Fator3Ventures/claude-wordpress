# Agentes — Core 1.56.0

Comece por DOCUMENTACAO.md, RELEASE-1.56.0.md, CONVERSAS-1.56.md e os schemas instalados. Contrato 8.21.0; base direta 1.55.0. MCP 0.33.0 preservado. Não instalar a frota nem criar conversas/avisos reais como consequência automática de preparar esta versão.

307: aprovação sem entregar é decisão deliberada, não falha. Leia aprovacao_entrega/evidencia e operation_id. Não regrave registros anteriores para fabricar o motivo novo. Entregar true exige decisão explícita.

308: preserve o telefone digitado. Oito dígitos de celular brasileiro com DDD válido são elegíveis para WhatsApp. Não acrescente 9; a classificação não comprova que a conta WhatsApp existe.

309: canal, bot autorizado e direção da ponte são explícitos. Configure os caminhos reais de campos e prove com whatsapp-conversa-verificar antes de ativar. [TESTE F3BASE] suprime CRM/Slack. Não use nome exibido para identificar telefone. Não avance cursor manualmente. A primeira origem depende da janela completa, não da primeira página devolvida pelo Slack.

310: documentacao-ler agora lista docs/history. Leia páginas até proxima_linha nula e confira SHA-256. como-usar incluir mudancas respeita desde_versao. Nota histórica não substitui a regra corrente.

311: salve a caixa com envio desligado, execute email-smtp-verificar, habilite com revisão atual em até 15 minutos. Prova faz autenticação real, grava recibo e não envia DATA. Não confunda simulação sem mensagem com ausência de chamada ao fornecedor. Troca de porta/segurança invalida a prova. Não publique senha ou erros brutos.

Meta: somente o SDK público instagram-first-message/1.0.0. Habilitação explícita por conta em ambos os pacotes. Reconcilie incerteza com recibo persistido, nunca invente record_id. Eliminação local mantém tombstone; Meta 0.11.1 não oferece eliminação pública, e essa pendência deve permanecer visível.

Contatos externos/vínculo manual do pedido 302 permanecem conforme CONTATOS-EXTERNOS-1.54.md. Não repetir o contato já registrado na frota. Histórico de sessões continua separado da atribuição manual e da origem de conversa; nenhuma conversão retroativa.
