# Fator3 Site Core 1.57.0

Base direta 1.56.0; contrato administrativo 8.22.0. Pedidos 312 e 313. WordPress >=7.1.2; PHP >=8.3.6 de 64 bits.

## 312 — Exclusão coordenada Instagram

Antes de limpar o payload do contato instagram_conversa, o Core guarda o alvo cifrado em f3base_instagram_exclusoes. Concluída a eliminação local em autocommit, chama o SDK público instagram-message-erasure/1.0.0 do Meta 0.12.0. Não confirma transações abertas pelo chamador; o SDK recusa transaction_active. O recibo é conferido, vinculado ao tombstone e os identificadores temporários são removidos. Repetição retorna o mesmo recibo.

Falha, SDK ausente ou permissão insuficiente deixam pendência visível. Retome pela mesma leads-eliminar-registro, simular=false e revisao_esperada do registro. Execução sem administrador não assume outra identidade; a pendência exige retomada administrativa. Registro eliminado antes desta versão sem alvo preservado mostra alvo_anterior_indisponivel; não é possível reconstruir identificadores apagados.

## 313 — Acervo GA4

Novo consumidor ga4-reader/1.0.0 do Google 0.20.0, independente do leitor GSC. Configuração f3base_ga4_acervo, inativa por padrão; concessão explícita no Google. Sete recortes: resumo, páginas, aquisição, dispositivos, países, cidades e eventos. Usuários, sessões, engajamento, eventos e eventos-chave conforme o recorte; valores originais como strings. Não há exportação BigQuery.

Coleta por dia e página com cursor cifrado, quota/backoff e auditoria do Google. A fotografia só substitui a publicada após persistência atômica da última página; falhas e vazios preservam a publicação anterior. Dias vazios continuam lacunas. Reconsulta dos três dias recentes uma vez ao dia e retomada do histórico desde inicio, sem limite de retroatividade local. A API pode não oferecer dados antigos.

Rotas ga4-status, ga4-coletar, ga4-historico, ga4-lacunas-ler, ga4-acervo-ler, ga4-comparar e ga4-exportar. Qualidade por dia/página: amostragem, thresholding, (other), cardinalidade/truncamento, fuso, moeda e cota. Exportação em partes autenticadas, sem arquivo público. Relatórios integrados: visao=ga4, fontes separadas. Não somar usuários entre dias ou recortes; não somar GA4 com comportamento próprio.

Retenção própria retencao_ga4_meses em f3base_retencoes_tecnicas: 0 sem expiração (padrão); 1–120 meses por escolha explícita. Inventário informa tamanho das duas tabelas do acervo. Três tabelas novas no total, incluindo outbox Instagram. Sem migração destrutiva ou habilitação automática.

## Convivência e limites

MCP 0.33.0 preservado; pipedrive-api-client/1.0.0 permanece sem mudança. Meta 0.12.0 e Google 0.20.0 entregam os contratos consumidos; nenhuma alteração nesses pacotes. Callback GSC ignora contratos alheios para não perder seu cliente ao descobrir GA4.

Provas com fornecedor simulado não certificam credenciais reais, App Review ou cobertura real de propriedade. Não há garantia de snapshot imutável da Data API nem de dados finais. Acervo guarda agregados da API; não recria exploração por usuário/evento bruto. Consulte ACERVO-GA4-1.57.md, INSTAGRAM-EXCLUSAO-1.57.md e relatório externo para o estado das homologações.

Painel: Medição → Acervo GA4, com recorte/datas e fontes separadas. A desinstalação explícita remove o acervo analítico, como o GSC; backup é necessário para recuperá-lo. Os recibos e pendências Instagram permanecem junto aos tombstones comerciais.
