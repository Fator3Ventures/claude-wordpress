# Operação, autenticação e sessões — 1.55.0

## 303 — Sessão administrativa

A opção f3base_sessao_admin_dias é inteira de 1 a 365, padrão 365, no catálogo/tela de Privacidade e em config-core-ler/config-core-escrever. Exemplo de leitura: {"nome":"f3base_sessao_admin_dias"}. Para gravar, use {"nome":"f3base_sessao_admin_dias","valor":30,"revisao_esperada":"<revisão retornada>","simular":false}. Confira o schema efetivo do canal. O filtro auth_cookie_expiration recebe os três argumentos e só muda usuários com manage_options e remember=true. Não altera sessões já emitidas, Application Passwords, tokens MCP nem duração de outras contas.

A base já possui f3base_sessao (modo legado ou por perfil). A política nova prevalece apenas nos administradores e não força Lembrar-me no POST nativo deles. Outros usuários conservam a política anterior; na ausência dela recebem os 14 dias nativos. Não se migra silenciosamente um site configurado para 90 dias para 14 dias. Sem Lembrar-me, o cookie administrativo é de navegador (Expires=0), com validade interna nativa de 2 dias. Com Lembrar-me, cookie autenticado e WP_Session_Tokens expiram no mesmo instante calculado; o recipiente HTTP persistente tem a tolerância nativa de 12 horas. Sair invalida o token, e senha/salts continuam invalidando a assinatura.

## 304 — Autenticação própria

Campos aditivos de f3base_email_site: mx_confiaveis (lista de hostnames/padrões *.dominio; padrão ["*.dreamhost.com"]) e remetentes_teste (lista de e-mails; padrão []). authserv_ids continua uma lista explícita de emissores confiáveis de Authentication-Results. Ausência de cabeçalho confiável ativa verificação própria; não autoriza aceitar sem prova.

DKIM verifica o conteúdo bruto antes do parser MIME: canonicalizações simple/relaxed, seleção de cabeçalhos de baixo para cima, assinatura do From obrigatório e SHA-256 do corpo completo. Suporta RSA-SHA256 (1024–8192 bits) e Ed25519-SHA256; rejeita SHA-1, From duplicado, chave revogada, assinatura expirada e assinatura parcial de corpo. Examina até oito assinaturas. Não guarda a mensagem bruta nem anexos binários.

SPF usa exclusivamente Return-Path e o IP público da primeira fronteira da cadeia inicial de Received cujos servidores by correspondem aos MX configurados. Para continuar entre relays internos, exige IP privado e hostname confiável. Nunca pula um topo não confiável. Avalia all, include, redirect, a, mx, ptr, ip4, ip6, exists e macros; no máximo dez consultas SPF e duas respostas vazias. A mesma resolução tem orçamento total de 64 consultas e 8 segundos por mensagem, duas tentativas no resolvedor do host, TTL máximo de 300 segundos e negativo de 30 segundos. Usa /etc/resolv.conf, UDP com fallback TCP para truncamento. Resolução indisponível/temporária nunca comprova ausência de política.

DMARC compara From com DKIM d= ou envelope SPF aprovado. Alinhamento estrito exige igualdade; relaxado usa descoberta organizacional por árvore DNS limitada a oito posições (RFC 9989), sem presumir que as últimas duas partes sejam o domínio organizacional. Aplica p, sp e np; np só após NXDOMAIN confirmado do domínio autor, nunca por ausência de A. Sem DMARC, aceita apenas DKIM/SPF alinhado comprovado. DMARC pass aceita; fail com reject/quarantine descarta; os demais casos ficam suspeitos.

O payload cifrado de email-registros-ler inclui mensagem.autenticacao: metodo (authentication_results ou verificacao_propria), dmarc, politica, dkim, spf, alinhado, temporario e verificado_em. Não registra IP de origem ou cabeçalho bruto no contato/eventos. Descarte conserva método/resultados mínimos cifrados e identidade técnica; perde remetente/assunto/corpo.

DNS temporário grava classe suspeito, estado autenticacao_pendente e mantém a mensagem na INBOX, sem criar contato ou filas comerciais. Cada passagem reconsulta até duas pendências antes das mensagens novas (limite total normal cinco; máximo dez), sem voltar cursor. Resolvida a autenticação, materializa/move uma vez ou descarta. A releitura sempre usa o bruto da INBOX; ausência vira autenticacao_ausente, sem aceitação automática. Exportador e apagador nativos incluem mensagens pendentes sem contato. A retenção usa f3base_retencao_meses; o tombstone impede reimportação do item eliminado. Restaurar suspende pendências e exige reconciliação.

Referências primárias: RFC 6376 (DKIM), RFC 8301 (RSA/SHA-256), RFC 8463 (Ed25519), RFC 7208 (SPF), RFC 9989 (DMARC, maio de 2026). A decisão do Core de descartar quarantine é a política de ingestão solicitada pelo dono; não representa remoção da caixa no provedor.

## 305 — IMAP, ativação e teste

email-caixa-verificar {} é prévia: consulta TLS/INBOX/LIST/NAMESPACE, mostra prefixo, separador, nomes configurados/efetivos, disponibilidade e pastas_ausentes. Se faltar pasta, ok=false e codigo=imap_pasta_ausente. {"simular":false} cria destinos faltantes e confirma com LIST, sem importar/mover mensagens nem mudar cursor. Na coleta aplicada, garante destinos antes de importar. Aceita nomes curtos e completos; NAMESPACE tem precedência, e LIST pode revelar INBOX com delimitador. Sem evidência de prefixo, não o inventa. Se criação falhar, não trata a pasta como disponível. MOVE continua exigido; nunca substitui por DELETE/EXPUNGE.

Critério da coleta: busca por UID acima do cursor, e compara INTERNALDATE >= ativado_em como instantes UTC. SINCE por dia foi retirado porque a data do servidor IMAP pode divergir do dia UTC na virada, excluindo UID 1 válido antes do filtro preciso. Data declarada no cabeçalho Date não governa a ativação. A leitura devolve criterio_ativacao. Histórico anterior exige email-reprocessar com importar_historico explícito. UIDVALIDITY alterada interrompe sem reiniciar cursor.

Assunto com prefixo exato [TESTE F3BASE] ou From em remetentes_teste marca classe_trafego=teste. Reply-To não decide essa marca. O efeito é o mesmo do formulário: fora dos relatórios normais, CRM somente em homologação, política Testes para destinos e aviso elegível em avisos-slack-testes-apagar. Referências e procura por e-mail não unem contato comercial a teste. A marca não enfraquece DKIM/SPF/DMARC nem muda mensagens antigas retroativamente.

## 306 — Prova de manutenção

A agenda de saude-ler e a tela Saúde mostram a última execução/motivo, ultimo_sucesso e prova_publica com horário. Cache exige evidência nova, persistida, perfil ativo, HIT/cabeçalhos, tokens e proteção do artefato confirmados. Robots exige conteúdo público HTTP igual ao gerado e diagnóstico persistido. Último sucesso guarda código da evidência e escopo cache_http_confirmado ou robots_http_confirmado.

Passagem limitada por intervalo/trava ou que falhe não reaproveita sucesso antigo como prova nova. Cache desligado fica executado_sem_confirmacao com motivo explícito, preservando ultimo_sucesso. Provas públicas são observações datadas; não garantem funcionamento futuro. O aceite de menos de 24 horas nos 12 sites depende de publicação e observação posterior pela frota.

## Banco, restauração e compatibilidade

Não há DDL novo nesta rodada. Nova opção e subcampos são complementados preservando preferências, listas vazias, cursor, credenciais e dados. O formato de payload de e-mail ganha autenticação/teste; estados novos ficam na coluna já existente. Downgrade para 1.54 deve desligar a coleta até reconciliar pendências de autenticação, pois a base não as reavalia. Não copie dados/credenciais de laboratório para o site. Backup e restauração seguem OPERACAO-E-RECUPERACAO.md.
