# Telefone em formato livre — Core 1.45.0

No editor de formulários, um campo do tipo tel e papel telefone tem a opção Formato livre, desligada por padrão. A definição é validada no servidor; o cliente não pode ligar a opção pelo corpo do envio. Renderização inclui data-formato-livre=1 somente quando a definição permite. A mesma definição atende formulário na página e diálogo; a segunda etapa continua complementar, com identificação na primeira etapa.

Desligada: navegador e endpoint exigem telefone normalizável segundo f3base_pipedrive.pais_telefone (BR, PT, US, CA; vazio assume BR). No Brasil exige DDD e número completo. Com +, usa código internacional. A recusa mantém telefone_formato e o motivo específico; a mensagem de exigir-um-de pode prevalecer na interface.

Ligada: aceita conteúdo sem barrar por formato, inclusive telefone sem DDD ou incompleto, preservando espaços e texto digitados em UTF-8. Continuam limites de tamanho, obrigatoriedade, regras de outros campos e proteções de envio. No grupo exigir-um-de, conteúdo não vazio após trim satisfaz o campo. Conteúdo vazio não é telefone fornecido.

O registro aceito guarda telefones_normalizacao por campo e telefone_normalizacao do papel: classe valido, sem_ddd, incompleto ou outro; motivo; país; normalizado quando possível; formato_livre; regra telefone-1.45.0. Motivos incluem sem_ddd, ddd_invalido, quantidade_digitos, prefixo_invalido, caracteres_invalidos, formato_internacional e formato_pais. f3base/relatorios-integrados-ler com visao=telefones_normalizacao e a visão Normalização dos telefones na tela contam contatos por classe sem expor valores. O relatório não reclassifica contatos antigos sem marca.

Telefone não normalizado não gera link de WhatsApp nem identificador para busca/criação de telefone de pessoa no Pipedrive. Sem e-mail válido, a primeira atividade é uma tarefa Conferir contato. O valor digitado e a marca aparecem no aviso do contato aceito e na nota do CRM. Isso não muda o isolamento das tentativas barradas: seus valores continuam fora de avisos, CRM, GA4, Meta e Clarity.

Conversões de contato mantêm o comportamento existente, sujeito a consentimento, destino, identificadores e prazos. O registro e os diários recebem a marca telefone_estado. A opção f3base_converter_contato_sem_identificador, em Medição → Tags e carregamento, vem ligada; desligá-la impede novas conversões do caso telefone livre não normalizado sem e-mail válido, nos transportes do Core. Não cancela evento já entregue nem controla tags próprias do site. Número inválido não vira hash de telefone da Meta. Valor livre não é enviado como novo parâmetro analítico.

Não ligar automaticamente no contato-whatsapp de ctooffice: depende da decisão 111 do dono. Aceite usa dados sintéticos e opção temporária no Site-Teste; CRM real só em destino autorizado. Depois da decisão e implantação, a frota verifica ausência de novas recusas telefone_formato para o campo livre.
