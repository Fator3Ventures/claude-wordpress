# Conversas — Core 1.56.0

Dois fluxos independentes: WhatsApp pela ponte no Slack e Instagram pelo SDK público Meta. Começam desligados, não geram conversões Ads nem e-mail automático e não inferem sessões web. São contatos privados; use leads-registros-ler e o acervo de contatos, com capacidades administrativas. Exclusão usa o fluxo normal de leads e preserva tombstones contra reimportação.

## WhatsApp / Twinia

Configure f3base_whatsapp_site por config-core-escrever, após ler revisão/schema. Exemplo ilustrativo parcial (IDs devem ser substituídos por IDs verificados):

```json
{"ativo":false,"canal":"C0000000309","numero":"5511999990309","bots":["B0000000309"],"usuarios_equipe":[],"numeros_ignorados":[],"ponto":"whatsapp_conversa","mapa_codigos":{"BIO":{"canal":"social","parceiro":"interno","utm_campaign":"instagram_bio"}},"campos":{"telefone":"metadata.event_payload.telefone","nome":"metadata.event_payload.nome","texto":"metadata.event_payload.texto","sentido":"metadata.event_payload.sentido"},"sentido_entrada":"entrada"}
```

Os caminhos são configuração do envelope, não uma alegação de que todas as versões Twinia usam esses nomes. Aceitam chaves separadas por ponto e índices de arrays (ex.: attachments.0.text). Não há expressão executável, regex livre ou inferência por nome de pessoa. O telefone precisa estar em campo próprio com código de país. A direção deve corresponder exatamente ao valor de entrada. Autor precisa ser um bot/usuário explicitamente permitido. Envelope desse autor sem direção, telefone ou texto reconhecíveis pausa a passagem, com cursor preservado, até ajustar o mapeamento. Permissão de escrever no canal sem esses campos não constitui prova de uma conversa recebida.

A credencial é f3base_slack_bot_token, já utilizada pelos avisos. O bot deve pertencer ao canal e ter channels:history ou groups:history, conforme a conversa. whatsapp-conversa-verificar com simular:true consulta até 15 mensagens e retorna apenas contagens por motivo e escopos faltantes, sem texto ou dados pessoais. Não chama auth.test nem envia aviso. Confira o envelope real antes de ativar. Threads cujos dados necessários não estejam nas mensagens lidas por conversations.history exigem adequação do envelope da ponte; este coletor não deduz o telefone dos nomes e não percorre replies automaticamente.

Na ativação, o marco inicial é o instante corrente; não importa histórico automaticamente. Desligar pausa e preserva o cursor. Uma passagem lê uma página de 15 mensagens, com teto de 500 identidades pendentes cifradas. Mais páginas mantêm a mesma janela e só depois iniciam a gravação, até 15 contatos por passagem. A agenda normal é 300 segundos. 429 respeita Retry-After e não avança cursor. O estado f3base_whatsapp_site_estado preserva ultimo_ts e pendências; não o edite para forçar avanço.

A mudança de configuração durante uma janela incompleta bloqueia a continuação com whatsapp_janela_configuracao_alterada. Reponha a configuração da janela ou simule whatsapp-conversa-consultar com reler_janela:true e aplique com a revisão vigente para recomeçar seu preparo com os campos atuais. Essa ação mantém o marco, os contatos já gravados e a deduplicação; não muda canal/número. Não apague o cursor. Mudança de canal/número com pendências também exige revisão. O operador que autorizou a coleta deve conservar manage_options e f3base_gerir_leads.

Primeira mensagem elegível por número cria contato. Mensagens seguintes não criam outro. Sem código conhecido, origem WhatsApp sem origem; nenhum UTM é inventado. [TESTE F3BASE] em qualquer posição marca teste e suprime Slack e CRM incondicionalmente. numeros_ignorados descarta números controlados que não devem criar nem contato de teste. O número do próprio site é sempre ignorado.

Prepare avisos Slack e Pipedrive antes do comercial: ponto é chave existente de mapa_pontos; o Core não cria a alternativa remota. A intenção comercial fica junto ao contato e as filas normais retomam a entrega. Falha não deve ser corrigida reinserindo contato. Sem autorização comercial no ambiente de testes, valide com a marca de teste.

## Instagram

Meta 0.11.1 fornece o contrato instagram-first-message/1.0.0. Configure f3base_instagram_conversas:

```json
{"contas":[{"connection_id":"conexao-verificada","account_id":"123456789","ativo":true,"slack":false,"pipedrive":false,"ponto":"instagram_conversa"}]}
```

A conta/conexão deve também estar explicitamente autorizada no Meta, com recepção, contatos, Página e escopos verificados. A habilitação no Core não autoriza o Meta por si só. O Meta verifica webhook assinado e mensagem mais antiga disponível na API antes do callback. Alterações da autorização Meta são revalidadas pelo Meta; alterações da política Core são revalidadas pelo consumidor. Sem comprovação, não há contato aceito.

Retém apenas identificadores mínimos cifrados, origem comprovada e cobertura. Sem texto/anexo fornecido por esse contrato. Não garante primeiro contato de toda a vida; preserva lifetime_first_unverified. SDK ausente ou política desativada não autoriza usar a rota manual como substituto.

instagram-conversa-recibo recebe connection_id, account_id e event_id; simula por padrão. Se o Meta ficou uncertain depois de o Core gravar, consulte o recibo real e aplique com revisao do Meta. Não aceita record_id inventado pelo chamador. Contato eliminado produz suppressed, sem reimportar. O Core não confirma persistência quando a evidência mudou (evidence_changed); mantém revisão pendente. Tombstone permite supressão nesse caso. O SDK atual só reconcilia estados reserved, uncertain ou evidence_changed; não altera recibo já persisted nem elimina metadados Meta. A eliminação externa está pendente do contrato pedido ao mantenedor. Nenhuma limpeza no Core afirma ter apagado cópias Meta, Slack ou Pipedrive.
