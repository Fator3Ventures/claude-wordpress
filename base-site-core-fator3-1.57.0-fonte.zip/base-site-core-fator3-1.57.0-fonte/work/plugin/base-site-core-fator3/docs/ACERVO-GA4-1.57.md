# Acervo GA4 — 1.57.0

## Configuração

Painel: Site Core → Configurações → Medição e anúncios → Acervo GA4. Opção f3base_ga4_acervo: ativo=false, propriedade vazia, inicio vazio (30 dias), horario=06:00 no fuso WordPress, fuso=America/Sao_Paulo (ajuste ao fuso da propriedade), recortes com os sete nomes abaixo. Início explícito define o horizonte retroativo; não há limite histórico local. Metadados retornados registram o fuso efetivo do Google. Hoje não é coletado; os três últimos dias encerrados são reconsultados diariamente, sem promessa de finalização.

O Core registra base-site-core-fator3 no hook f3_mcp_google_register_consumers para ga4-reader/1.0.0. O cliente só vive em memória. Configure leitura GA4 no Google e conceda google/configure-consumer com contract=ga4-reader/1.0.0, consumer_id=base-site-core-fator3, property=properties/123, enabled=true e expected_revision da conexão. Revogação usa enabled=false. Ativar Core sozinho não concede acesso. Nenhuma credencial ou opção privada do Google é lida pelo Core.

## Recortes e semântica

| Nome | Dimensões além de date | Métricas |
|---|---|---|
| resumo | nenhuma | activeUsers, totalUsers, sessions, engagedSessions, userEngagementDuration, eventCount, keyEvents |
| paginas | pagePath | activeUsers, totalUsers, screenPageViews, userEngagementDuration, eventCount, keyEvents |
| aquisicao | sessionSource, sessionMedium, sessionCampaignName | mesmas do resumo |
| dispositivos | deviceCategory | mesmas do resumo |
| paises | country | mesmas do resumo |
| cidades | country, city | mesmas do resumo |
| eventos | eventName | activeUsers, totalUsers, eventCount, keyEvents, userEngagementDuration |

keyEvents é a métrica atual de eventos-chave (conversões). Valores permanecem strings da API, sem perda por conversão de inteiro/decimal. Somar usuários diários não fornece usuários únicos do período; sessões por página não são aditivas. Comparação retorna séries lado a lado. Relatórios integrados visao=ga4 retornam fontes.GA4 e fontes.medicao_propria separadas; filtros próprios de contatos não filtram GA4.

## Coleta e retomada

`f3base/ga4-coletar {"dia":"2026-09-01","recorte":"paginas","reconsultar":true}` executa uma página (até 1.000 linhas e 20 segundos de SDK). `simular:true` não consulta. Sem dia/recorte, escolhe pendências configuradas. A agenda diária e a continuação a partir de 60 segundos usam tarefa ga4 do executor; são independentes de gsc. Retentativa respeita next_eligible_at/retry_after_ms e orçamento do executor. Nenhum retry dentro da chamada.

O SDK deve confirmar success e audit_success, propriedade e revisão. Erros não gravam linhas/cursor. Uma transação local grava a página e checkpoint; somente a última página publica, retirando a fotografia anterior da projeção atual sem eliminá-la. Mudança de contagem, duplicidade de dimensão ou cursor inválido reinicia o recorte. Paginação não garante snapshot imutável do fornecedor.

Vazio gera sem_dados e proxima tentativa após um dia; continua lacuna. Falha posterior não transforma dados anteriores em zero. Sem Google, concessão, armazenamento ou configuração pronta, a operação retorna o motivo; não chama outro cliente como alternativa. A seleção de propriedade é explícita, por site; o acervo de propriedades anteriores permanece consultável por administradores.

## Consultas e exportação

As leituras exigem manage_options. `ga4-status` mostra configuração, contrato, concessão local, cota observada e tamanho. `ga4-historico` lista 50 fotografias/tentativas por página, sem cursor. `ga4-lacunas-ler` calcula inventário por propriedade/recorte entre de/ate, até 366 dias; sem_dados não equivale a zero.

`ga4-acervo-ler {"propriedade":"properties/123","de":"2026-09-01","ate":"2026-09-30","recorte":"paginas","limite":100}` entrega até 100 linhas com qualidade dos dias/páginas correspondentes. Passe pagina e revisao retornadas nas continuações; acervo_alterado_reinicie_paginacao exige recomeçar. Intervalos maiores são percorridos em janelas de até 366 dias. Resposta que ultrapassa o orçamento de bytes pede redução do limite/período, sem truncagem silenciosa.

`ga4-comparar` recebe também anterior_de/anterior_ate; pagina/limite se aplicam aos dois lados. Não calcula total de usuários únicos no período. `ga4-exportar` recebe formato csv/json, entrega conteudo_base64, bytes, sha256, revisão e proxima_pagina. CSV tem cabeçalho em cada parte e neutraliza início de fórmula; JSON preserva proveniência/qualidade. Nenhuma URL pública.

## Qualidade, retenção e recuperação

Metadados originais por página/dia incluem samplingMetadatas, dataLossFromOtherRow, subjectToThresholding, dataTruncationReasons, timeZone e currencyCode. O Core também marca other_row_observed quando recebe essa dimensão. finalization_guaranteed=false e all_rows_guaranteed=false. Revogação interrompe novas consultas; cópias já autorizadas permanecem sob política local.

Tabelas f3base_ga4_coletas e f3base_ga4_linhas, incluindo tentativas/fotografias anteriores, sem expiração padrão. Retenção finita opcional em f3base_retencoes_tecnicas.retencao_ga4_meses=1..120, calculada pela data dos dados; não elimina uma coleta em andamento. Voltar a 0 não recupera expurgos. Configuração não apaga imediatamente. estado-inventario-ler.acervo_ga4 informa bytes e contagens estimadas do banco.

Desabilitar ativo cancela somente agendas GA4, mantendo acervo. Backup inclui tabelas, options e salts para cursores. Antes de restaurar, pause o executor pelo fluxo Core; mudança da geração de recuperação invalida o contexto. Reverter arquivos para 1.56.0 torna esse acervo indisponível nas rotas; não desfaz as três novas tabelas. Não apagar a base para voltar versão.

Fontes primárias: https://developers.google.com/analytics/devguides/reporting/data/v1/api-schema e https://developers.google.com/analytics/devguides/reporting/data/v1/quotas . O acervo é de relatórios agregados, não de eventos brutos ou identidade de usuários. Não recria dados já indisponíveis na API.

Painel: Medição → Acervo GA4, com recorte/datas e fontes separadas. A desinstalação explícita remove o acervo analítico, como o GSC; backup é necessário para recuperá-lo. Os recibos e pendências Instagram permanecem junto aos tombstones comerciais.
