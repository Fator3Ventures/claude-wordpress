# Cliente de operação Pipedrive — Core 1.51.0

Contrato PHP `pipedrive-api-client/1.0.0`; contrato administrativo 8.16.0. O Core guarda token, aplica autorização, coordenação, reserva local, saldo e transporte. Fator3 MCP Pipedrive 0.1.0 mantém rotas de domínio, prévias, confirmações, diário e recibos. O contrato funciona localmente sem MCP; o canal remoto depende do MCP e de suas concessões.

## Configuração administrativa

Option `f3base_pipedrive_operacao`, autoload=false:

```json
{"ativo":false,"consumidores":[],"orcamento_diario":3000}
```

`ativo` precisa ser true e o slug constar em `consumidores`. Orçamento inteiro de 1 a 1000000, padrão 3000; até 20 slugs únicos. Registrar consumidor não autoriza uso. Conta e credencial precisam estar verificadas no Core. O interruptor da entrega de leads é independente.

Ler primeiro `f3base/config-core-ler` com nome f3base_pipedrive_operacao. Usar a revisão retornada para simular `f3base/config-core-escrever`:

```json
{"nome":"f3base_pipedrive_operacao","valor":{"ativo":true,"consumidores":["wp-mcp-pipedrive-fator3"],"orcamento_diario":3000},"revisao_esperada":"<revisao_lida>","simular":true}
```

Aplicar com simular=false somente no site autorizado. A escrita mantém procedência normal do Core. `f3base/pipedrive-verificar` e `f3base/como-usar` incluem operacao_pipedrive com consumidores registrados/autorizados, orçamento e saldo. Não copiar o token para o acompanhante.

## Registro

Hook em plugins_loaded, prioridade 30, após arquivos dos plugins:

```php
add_action('f3base_register_pipedrive_consumers', static function($registry, $contract) {
    if ($contract !== 'pipedrive-api-client/1.0.0') { return; }
    $client = $registry->register_consumer(
        'wp-mcp-pipedrive-fator3', '0.1.0', $contract,
        static fn() => array('ready'=>true,'revision'=>'0.1.0','provider'=>'wp-mcp-pipedrive-fator3')
    );
    // Guardar apenas no processo. WP_Error significa registro recusado.
}, 10, 2);
```

Somente o período do hook aceita registro. Slug duplicado, contrato diferente ou callback inválido recusam. O objeto é vinculado ao registro; instanciar a classe não concede acesso. Callback é consultado novamente, precisa estar pronto e identificar o mesmo provider. Código PHP instalado é confiável; o protocolo não isola plugins maliciosos.

## capabilities e status

capabilities() retorna contract, methods, host, consumer=operacao, max_body_bytes=65536, timeout=20 e automatic_write_retry=false.

status() exige administrador, não faz HTTP nem grava estado. Exemplo ilustrativo:

```json
{"success":true,"code":"ok","message":"Consulta concluída.","data":{"contract":"pipedrive-api-client/1.0.0","autorizado":true,"conta":{"dominio":"empresa.pipedrive.com","conta_id":"123","usuario_id":456},"revisao":"<hash_opaco>","orcamento":{"teto":3000,"consumido":20,"reservado":0},"saldo_conta":{"restante":12000,"lido_em":"2026-10-24T00:00:00Z"}},"remote_dispatched":false}
```

Sem observação, saldo_conta=null. Falhas retornam success=false e código. A revisão cobre configuração/credencial/conta/instalação, autorização, limite, provider/revisão do callback, site e geração de recuperação. Consumo/saldo não alteram a revisão a cada chamada.

## request

Assinatura: request(string $metodo,string $caminho,array $query=[],array $corpo=[],array $contexto=[]).

```php
$result = $client->request('GET','/v1/dealFields',array('limit'=>100),array(),array(
    'provider'=>'wp-mcp-pipedrive-fator3',
    'consumer'=>'operacao',
    'contract'=>'pipedrive-api-client/1.0.0',
    'actor_id'=>get_current_user_id(),
    'revisao_esperada'=>$status['data']['revisao']
));
```

Escritas exigem previa_id não vazio. O Core exige contexto; prova de prévia e confirmação humana pertencem ao consumidor. GET não aceita corpo. PUT/PATCH/POST/DELETE enviam JSON até 64 KiB; query até 16 KiB. Caminho relativo ASCII de segmentos alfanuméricos/hífen/sublinhado, começando em /v1/ ou /api/v2/. Recusa query embutida, URL absoluta, codificação %, ponto/traversal, fragmento e backslash. Qualquer caminho com merge é recusado. Chaves ids, api_token/api-token, access_token/access-token e authorization são recusadas em query/corpo, inclusive aninhadas e com variação de caixa.

Host fixo https://api.pipedrive.com, autenticação somente no Core. TLS obrigatório, redirection=0, timeout=20, resposta até 512 KiB. Reserva atômica e segunda leitura de autorização/revisão/pausa/saldo/barreira precedem o despacho. Trava por instalação é compartilhada com gravar/atualizar_estado das options Pipedrive pertinentes. Ocupada/ilegível recusa sem HTTP. Escrita administrativa concorrente recebe pipedrive_ocupado. SQL direto de outro plugin não participa desse protocolo.

Exemplo após transporte:

```json
{"success":true,"code":"ok","message":"Consulta concluída.","data":{"http_status":200,"body":{"success":true,"data":[]},"saldo_conta":{"restante":11980,"lido_em":"2026-10-24T00:01:00Z"}},"remote_dispatched":true}
```

Erros HTTP omitem body. Chaves/valores que repetem a credencial e campos de token/secret/authorization/cookie/password são removidos antes do retorno de sucesso. Não retornam args, headers ou mensagem livre de exceção. Dados comerciais permanecem administrativos; o consumidor controla seu diário e retenção.

| Código | Significado / ação |
|---|---|
| operacao_nao_autorizada | Administrador, registro ou autorização ausentes; sem despacho. |
| credencial_invalida | Conta/credencial não comprovadas; revalidar no fluxo existente. |
| contexto_alterado | Callback, provider, ator ou contexto inadequados; nova prévia. |
| revisao_conflitante | Revisão mudou; nova leitura e prévia. |
| entrada_invalida | Método/caminho/parâmetro/corpo recusado; sem despacho. |
| saldo_conta_baixo | Último saldo oficial <3000; só operação bloqueada. |
| orcamento_esgotado | Reserva local não confirmada; conferir consumo/persistência. |
| pausa_remota | HTTP 429/burst observado; pausa compartilhada. |
| core_em_recuperacao | Barreira pausada/indisponível; não contornar. |
| core_indisponivel | Estado/trava não confirmados; reler. |
| fornecedor_recusou | HTTP de recusa; corpo omitido. |
| resultado_incerto | Transporte começou, resultado não confirmado; reconciliar sem repetir automaticamente. |
| resposta_excedeu_limite | Resposta >512 KiB; paginação/reconciliação de eventual escrita. |

remote_dispatched=false comprova bloqueio anterior ao transporte. true indica resposta HTTP após despacho. null indica timeout/exceção sem confirmação; a reserva permanece consumida. Erro não torna uma escrita automaticamente segura para repetir.

## Orçamento, saldo e recuperação

Operacao estima GET 20 e escrita 10, por site/conta/dia UTC, isolado de entregas/qualidade/verificacao. Antes do HTTP, cancelamento devolve reserva; após despacho incerto, consome. Reservas interrompidas permanecem comprometidas até a virada UTC. Não são medição oficial.

x-daily-ratelimit-token-remaining é observado nos quatro consumidores e verificações de credencial Core. Guarda restante/UTC por vínculo HMAC site/domínio/credencial, sem guardar token nesse estado; até oito vínculos recentes. Header ausente/inválido preserva observação anterior. Rotação não mistura saldo de outra credencial; virada local não aumenta saldo remoto por suposição.

Abaixo de 3000, entregas/qualidade/verificacao continuam sujeitas aos tetos próprios e à pausa do fornecedor. HTTP 429/burst esgotado pausa a conta para todos, como antes. Verificação existente pode renovar saldo. Não zerar contadores ou aumentar artificialmente saldo.

Novas options: f3base_pipedrive_operacao, f3base_pipedrive_operacao_orcamento e f3base_pipedrive_saldo_conta. Nenhuma tabela Core nova, migração destrutiva ou ligação automática. Preservar options em backup/rollback. A fila de leads independe da presença/ativação do Pipedrive. Preparar recuperação bloqueia operação; retomar muda geração/revisão e invalida prévias antigas.
