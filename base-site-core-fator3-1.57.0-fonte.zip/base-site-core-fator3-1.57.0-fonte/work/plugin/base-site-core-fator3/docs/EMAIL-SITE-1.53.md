> Vigente na 1.55.0: OPERACAO-1.55.md substitui as regras anteriores de autenticação, resolução de pastas, ativação e classificação de teste. Interfaces gerais abaixo permanecem.

# Caixa de contato por site — Core 1.53.0, pedido 300

## Preparação e configuração

Crie caixa exclusiva contato.site@domínio na hospedagem. No Site Core → Configurações → Conexões e entregas → E-mail do site, grave a configuração ainda desligada e cole a senha no campo protegido. A senha é f3base_email_site_senha, cifrada e nunca devolvida nas leituras. Configure f3base_email_site: endereço, usuário, IMAP 993 TLS, SMTP 465/ssl ou 587/tls, pastas Importados/Sent, nome e assinatura, domínios ignorados, termos de suspeita, authserv_ids confiáveis, Cco, Smart Bcc e cota alocada. Todos os campos têm ajuda na tela/schema.

Depois verifique a caixa sem importar, prepare remetentes de homologação e ative explicitamente. Envios são habilitados separadamente em envio_ativo. Padrões: importação/envio desligados, Cco korvena@korvena.net.br configurável, cota local 20 destinatários/hora (máximo 99), alocação não confirmada. A soma entre sites da mesma conta exige alocação operacional; contador do Core é local ao site.

Não confundir a caixa do site com a automação de primeiro contato. Esta usa o remetente/SMTP/assinatura da caixa somente se envio_ativo estiver ligado, conserva seu conteúdo próprio e não é ativada pela caixa. Cco configurável também vale para a automação. Não enviar resposta automática a contatos cuja origem é e-mail.

## Recepção, classificação e persistência

Consulta a cada 5 minutos pelo agendador; até 10 mensagens por chamada, prazo IMAP 20 segundos e lote limitado. UIDVALIDITY e UID guardam o cursor. Primeiro contexto guarda ativado_em; mensagens anteriores ficam descartadas como anterior_ativacao, sem contato. Pausa preserva cursor; troca de caixa inicia outro contexto. UIDVALIDITY diferente bloqueia e exige reconciliação, não reinicia histórico silenciosamente. Reprocessamento manual de UID anterior exige importar_historico=true.

Servidor precisa de UID MOVE. Leitura BODY.PEEK não marca a mensagem como lida. Somente depois de persistir contato/mensagem, move para Importados; falha fica pendente. Não há DELETE/EXPUNGE. Corpo bruto máximo 2 MiB, texto máximo 20.000 caracteres, assunto 500, até 100 nomes de anexos. Binários não persistem. Acima do limite, motivo é registrado; não tenta decodificar conteúdo sem limite.

Destinatário precisa ser o endereço próprio em To, Cc ou cabeçalho de entrega. Descartes: outro site, remetente inválido/do grupo, resposta automática, massa/lista, retorno de entrega, relatório DMARC, dmarc=fail, fora da lista de homologação. Descarte conserva motivo e identidade mínima, sem corpo. DMARC pass de authserv_ids confiável permite aceitação; ausência de confirmação, Reply-To divergente, links em excesso e termos configurados marcam suspeita. Ajuste authserv_ids com o cabeçalho real da hospedagem antes de uso.

Aceito: contato + aviso pelo canal do site + intenção Pipedrive. Suspeito: contato/aviso com motivo, CRM só após aprovação. Nome usa display name; se ausente, parte antes do @ com marca de substituto. Nenhuma empresa é inferida. Replies/references e mesmo e-mail com contato local aberto vinculam a conversa. Cada mensagem tem identidade de aviso/nota independente; não repete a captura antiga. Não produz conversão GA4/Meta/Google Ads/LinkedIn.

A tabela f3base_email_site cifra conteúdo com o Core. Estado, UID, Message-ID em HMAC, cursor e checkpoints sustentam retomada; sequência id resolve mensagens do mesmo segundo. Histórico privado também aparece na tela do contato. Eliminação do contato limpa corpo/remetente/vínculo, cancela intenções e conserva tombstone para não importar novamente. Inclua tabela e chaves do Core no backup. Uninstall/restore suspendem pendências; conferir efeitos externos e reativar com revisão não reenvia linhas já suspensas ou incertas.

## Abilities

- email-caixa-verificar: manage_options, TLS/EXAMINE, sem importar.
- email-caixa-consultar: manage_options + f3base_ler_leads; simular=true padrão. Aplicação exige revisao devolvida e relida sob trava.
- email-registros-ler: f3base_ler_leads; filtros record_id, classe, pagina. Retorna mensagens privadas e motivos; não encaminhar corpos para logs públicos.
- email-reprocessar: manage_options + f3base_ler_leads; uid, uidvalidity, importar_historico e revisão. Trabalha em INBOX; não procura mensagens já movidas em outras pastas.
- email-enviar: f3base_enviar_email + f3base_ler_leads; record_id local aceito, assunto e texto, simulação padrão; revisão obrigatória no envio. Não admite endereço livre.

Schemas executáveis completos em dados/abilities-*.json. Administrador recebe f3base_enviar_email. O perfil MCP deve também autorizar a operação; a capability WordPress continua obrigatória.

## Envio e CRM

Prévia inclui remetente da marca, destinatário local, Cco/Smart Bcc, assunto/texto/assinatura e thread. Todos os destinatários contam na mesma cota deslizante de uma hora da automação. Em teste, To e todas as cópias devem estar na lista. PHPMailer do WordPress e TLS com certificado validado; todos os RCPT são conferidos antes de DATA. Recibo gravado antes de SMTP. Repetir a mesma revisão retorna o recibo, não reenvia. Timeout depois de DATA é incerto e exige conferência humana no servidor.

Após aceite SMTP, APPEND na pasta configurada. Estado enviado_copia_falhou/incerta informa que SMTP foi aceito e a cópia não foi comprovada; nunca repetir SMTP para reparar essa cópia. Links ficam intactos. Mensagem enviada entra no histórico do contato e em nota CRM; não gera primeiro contato automático nem nova atividade de entrada.

Pipedrive: mapa_pontos.email, mapa_canais.nao_identificada e mapa_parceiros.sem_campanha; na conta descrita pelo dono correspondem a 168, 85 e 51. Configure pelos catálogos; IDs não estão no runtime. Campo/unidade precisam estar configurados. Antes de reutilizar oportunidade, leem-se seus campos completos e confirma-se a unidade; outra unidade implica novo lead local. Negócio aberto da mesma unidade recebe nota e tarefa quando a opção atividade estiver ligada. Vale para formulário, nativo e e-mail. Nova leitura antes da nota evita usar unidade alterada entre etapas.

## Saúde e limites

Três falhas consecutivas ou ausência de tentativa por mais de 15 minutos abrem incidente. Uma intenção de abertura e uma de recuperação; checkpoints precedem rede. Slack pelo transporte configurado, contingência e-mail se falha. Não repetir resultado incerto. Alarme informa somente estado/código e link da configuração, sem conteúdo de mensagens. O observador tem gancho próprio de 5 minutos; se cron/PHP estiver completamente parado, não há mecanismo externo capaz de emitir esse alarme.

Caixa real, recebimento, autenticação, MOVE, SMTP, Cco e APPEND precisam de homologação no provedor. Testes de laboratório usam transporte controlado, não comprovam essas entregas. Não usar conta de cliente nem alterar DNS/credenciais para concluir uma prova sintética.
