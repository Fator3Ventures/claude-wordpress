# Fator3 Site Core 1.55.0

Instalação nova ou atualização direta da 1.54.0. Contrato administrativo 8.20.0. Sessão administrativa configurável, autenticação DKIM/SPF/DMARC, namespace IMAP, classificação de e-mail de teste e comprovação cron de cache/robots. Leia docs/DOCUMENTACAO.md, docs/RELEASE-1.55.0.md e docs/AGENTES-1.55.0.md. A documentação é lida integralmente por f3base/documentacao-ler.

Slug e basename preservados. MCP é transporte opcional; o Core e sua documentação local funcionam sem acompanhante. Instale somente o ZIP instalador. Identidade, testes e limites estão no relatório externo da entrega.
