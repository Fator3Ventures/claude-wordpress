<?php
/** Preflight de credenciais candidatas. Metadados sem segredo, confirmação ligada ao valor e à revisão. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Credenciais {
    const OPTION='f3base_credenciais_estado';
    private static array $checks=array();
    private static array $normalizacoes=array();
    public static function normalizacao_escrita(string $n,array $avisos): void {self::$normalizacoes[$n]=$avisos;}
    private static array $rotacoes=array();
    private static array $confirmacoes=array();
    private static array $ultima=array();
    public static function ultima(): array {return self::$ultima;}
    public static function com_confirmacoes(array $v,callable $fn){$old=self::$confirmacoes;self::$confirmacoes=$v;try{return $fn();}finally{self::$confirmacoes=$old;}}
    public static function definicoes(): array {
        return array(
            'f3base_pipedrive_token'=>array('Token de API pessoal do Pipedrive (Your personal API token)','Pipedrive → foto do perfil → Personal preferences → API → Your personal API token → copiar. Use os 40 caracteres hexadecimais. O usuário do token será o proprietário dos objetos criados.'),
            'f3base_slack_bot_token'=>array('Token OAuth do bot (Bot User OAuth Token)','api.slack.com/apps → aplicativo → OAuth & Permissions → OAuth Tokens → Bot User OAuth Token. Começa com xoxb-. Requer chat:write; channels:history ou groups:history para a thread e channels:read ou groups:read para conferir o canal. Convide o bot ao canal.'),
            'f3base_slack_webhook'=>array('URL do webhook de entrada (Incoming Webhook URL)','Aplicativo Slack → Incoming Webhooks → Webhook URL. Copie a URL completa, começando com https://hooks.slack.com/services/. O destino é definido no Slack.'),
            'f3base_clarity_api_token'=>array('Token da API de exportação de dados do Clarity (Data Export API token)','Clarity → projeto → Settings → Data Export → Generate API (administrador). O token é mostrado uma vez: JWT começando com eyJ e três partes separadas por ponto. Salvar verifica somente o formato; Testar token consome a cota de 10 consultas por projeto/dia.'),
            'f3base_anuncios_meta_token'=>array('Token de acesso do usuário do sistema (leads da Meta)','Meta Business Suite → Settings → Users → System users → usuário → Generate Token → aplicativo → Never → permissões leads_retrieval, pages_show_list, pages_read_engagement e pages_manage_ads. Copie o token mostrado uma vez, gerado para esse aplicativo. O tamanho varia; o Core confirma validade e permissões na Meta. Não use a chave secreta do aplicativo.'),
            'f3base_meta_capi_token'=>array('Token de acesso da API de Conversões (Conversions API)','Events Manager → conjunto de dados/Pixel → Settings → Conversions API → Generate Access Token. O tamanho do token varia; a Meta confirma sua validade e permissões; não é a chave secreta do aplicativo.'),
            'f3base_meta_crm_token'=>array('Token de acesso da API de Conversões do retorno de qualidade (credencial própria)','Events Manager → conjunto de dados selecionado para qualidade → Settings → Conversions API → Generate Access Token. O tamanho do token varia; a Meta confirma sua validade e permissões. Use esta credencial quando o retorno de qualidade precisar de acesso próprio.'),
            'f3base_anuncios_linkedin_token'=>array('Token de acesso (Access Token) — Lead Sync','LinkedIn Developers → aplicativo → Auth → OAuth 2.0 tools → gerar Access Token com r_marketing_leadgen_automation (produto Lead Sync aprovado). Cole somente o token completo, sem Bearer, JSON ou URL. O Core confere o token com Client ID e Primary Client Secret.'),
            'f3base_anuncios_linkedin_client_secret'=>array('Chave secreta do aplicativo (Primary Client Secret)','LinkedIn Developers → aplicativo → Auth → Application credentials → Primary Client Secret → exibir/copiar. Use a chave do mesmo aplicativo do Client ID e do token; não cole o Access Token neste campo.'),
            'f3base_anuncios_google_chave'=>array('Chave do webhook do formulário de lead (Google Ads → Key)','Google Ads → Assets → Lead form → Delivery options → Webhook integration → Key. Defina a mesma chave no Google Ads e aqui, sem espaços.'),
            'f3base_email_site_senha'=>array('Senha da caixa do site','Cole a senha da caixa exclusiva deste site. A senha atende IMAP e SMTP e fica cifrada no WordPress.'),
            'f3base_email_novo_lead_smtp_senha'=>array('Senha SMTP','Use a senha do usuário SMTP configurado ou a senha de aplicativo exigida pelo provedor de e-mail. Não use a senha do WordPress.'),
            'f3base_pipedrive_webhook_segredo'=>array('Chave compartilhada do webhook de retorno do Pipedrive','Defina uma chave aleatória privada e use a mesma no receptor do Core e na configuração do webhook que envia os retornos do Pipedrive. Este campo não gera a chave automaticamente e não recebe o token de API pessoal.'),
            'f3base_avisos_webhook_url'=>array('URL HTTPS do receptor dos avisos JSON','O responsável pelo sistema receptor fornece esta URL HTTPS pública. Cole o endereço de recebimento, sem usuário, senha, porta, parâmetros ou fragmento. O Core não cria o receptor.'),
            'f3base_avisos_webhook_chave'=>array('Chave compartilhada para assinar os avisos JSON (HMAC-SHA256)','Combine com o responsável pelo receptor uma chave aleatória de 32 a 256 caracteres (letras, números, hífen ou sublinhado) e configure o mesmo valor nos dois lados. O Core usa a chave para assinar o corpo; este campo não a gera automaticamente.')
        );
    }
    public static function formato(string $n,string $v): string {
        if($v===''){return '';}
        if($n==='f3base_pipedrive_token'&&!preg_match('/^[a-fA-F0-9]{40}$/D',$v)){return 'O token de API pessoal do Pipedrive deve ter exatamente 40 caracteres hexadecimais.';}
        if($n==='f3base_slack_bot_token'){
            if(str_starts_with($v,'xoxp-')){return 'Este é um token de usuário (xoxp-). Use o Bot User OAuth Token, começando com xoxb-.';}
            if(str_starts_with($v,'xapp-')){return 'Este é um token do aplicativo (xapp-). Use o Bot User OAuth Token, começando com xoxb-.';}
            if(!preg_match('/^xoxb-[A-Za-z0-9-]+$/D',$v)){return 'Use o Bot User OAuth Token começando com xoxb-, não a URL de webhook.';}
        }
        if(in_array($n,array('f3base_anuncios_meta_token','f3base_meta_capi_token','f3base_meta_crm_token'),true)){
            if(preg_match('/^[a-fA-F0-9]{32}$/D',$v)){return 'Este valor tem o formato da chave secreta do aplicativo Meta. Use o token de acesso começando com EAA.';}
            if(!preg_match('/^[A-Za-z0-9_.~+\/=|\-]+$/D',$v)){return 'Cole somente o token completo da Meta, sem JSON, URL ou cabeçalho. O tamanho não tem mínimo fixo.';}
        }
        if($n==='f3base_clarity_api_token'&&!preg_match('/^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/D',$v)){return 'Use o Data Export API token do Clarity: JWT começando com eyJ, com três partes separadas por ponto.';}
        if(in_array($n,array(F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET),true)&&(!preg_match('/^[A-Za-z0-9_.~+\/=\-]+$/D',$v))){return 'Cole a credencial LinkedIn completa do campo indicado, sem JSON, espaços, URL ou cabeçalho.';}
        return '';
    }
    public static function catalogo(array $c): array {
        foreach(self::definicoes() as $n=>$d){if(isset($c[$n])){$c[$n]['rotulo']=$d[0];$c[$n]['descricao']=$d[1];}}
        $c[self::OPTION]=array('rotulo'=>'Identidades verificadas das credenciais','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;
    }
    private static function texto($v): string {return is_scalar($v)?mb_substr(sanitize_text_field((string)$v),0,180):'';}
    private static function cfg(string $n): array {
        $map=array('f3base_pipedrive_token'=>'f3base_pipedrive','f3base_slack_bot_token'=>'f3base_avisos','f3base_anuncios_meta_token'=>'f3base_anuncios_meta','f3base_meta_capi_token'=>'f3base_meta_capi','f3base_meta_crm_token'=>'f3base_qualidade');
        if(in_array($n,array(F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET),true)){$all=F3Base_Options::proposta_ou_ler(F3Base_Linkedin::OPCAO);$list=$all['integracoes']??array('principal'=>$all);$ids=array_values(array_unique(array_column(array_filter($list,static fn($c)=>($c['cliente']??'core')==='core'),'client_id')));return array('client_ids'=>$ids);}
        if(isset($map[$n])){$c=(array)F3Base_Options::proposta_ou_ler($map[$n]);return $n==='f3base_pipedrive_token'?array('dominio'=>$c['dominio']??''):($n==='f3base_slack_bot_token'?array('slack_canal_id'=>$c['slack_canal_id']??''):array());}return $n==='f3base_clarity_api_token'?array('projeto'=>F3Base_Options::proposta_ou_ler('f3base_clarity_project_id')):array();
    }
    private static function secreto(string $n): string {$v=F3Base_Options::proposta_ou_ler($n);return is_string($v)&&!str_starts_with($v,F3Base_Segredos::PREFIXO)?$v:F3Base_Segredos::abrir($n,is_string($v)?$v:'');}
    private static function http(string $url,array $args): array {
        try{$r=wp_remote_request($url,$args+array('timeout'=>8,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>65536));}catch(Throwable $e){return array(0,array());}
        if(is_wp_error($r)){return array(0,array());}$host=(string)wp_parse_url($url,PHP_URL_HOST);if(str_ends_with($host,'.pipedrive.com')&&is_string($args['headers']['x-api-token']??null)){F3Base_Pipedrive_Saldo::observar($r,$args['headers']['x-api-token'],$host);}$d=json_decode(wp_remote_retrieve_body($r),true);return array((int)wp_remote_retrieve_response_code($r),is_array($d)?$d:array());
    }
    private static function falha(string $provider,int $http,string $detail=''): array {return array('ok'=>false,'codigo'=>'credencial_recusada','remota'=>true,'http'=>$http,'motivo'=>$provider.($http?' recusou ou não confirmou esta credencial (HTTP '.$http.').':' não respondeu à verificação.').($detail?' '.$detail:'').' A credencial salva continua em uso.');}
    private static function remoto(string $n,string $token,array $cfg): array {
        if($n==='f3base_pipedrive_token'){
            $domain=(string)($cfg['dominio']??'');if(!preg_match('/^[a-z0-9][a-z0-9-]{0,62}\.pipedrive\.com$/D',$domain)){return self::falha('Pipedrive',0,'Defina o domínio da empresa antes de salvar.');}
            [$http,$d]=self::http('https://'.$domain.'/api/v1/users/me',array('method'=>'GET','headers'=>array('x-api-token'=>$token,'Accept'=>'application/json')));$u=$d['data']??array();
            if($http!==200||empty($d['success'])||empty($u['id'])||empty($u['company_id'])){return self::falha('Pipedrive',$http);}
            $identity=array('provedor'=>'pipedrive','usuario_id'=>self::texto($u['id']),'usuario'=>self::texto($u['name']??''),'empresa_id'=>self::texto($u['company_id']),'empresa'=>self::texto($u['company_name']??''),'dominio'=>$domain);
        }elseif($n==='f3base_slack_bot_token'){
            $headers=array('Authorization'=>'Bearer '.$token);[$http,$d]=self::http('https://slack.com/api/auth.test',array('method'=>'POST','headers'=>$headers));
            if($http!==200||empty($d['ok'])||empty($d['team_id'])||empty($d['bot_id'])){return self::falha('Slack',$http,'Confira se o bot está instalado e o token está ativo.');}
            $identity=array('provedor'=>'slack','workspace_id'=>self::texto($d['team_id']),'workspace'=>self::texto($d['team']??''),'bot_id'=>self::texto($d['bot_id']),'bot'=>self::texto($d['user']??''));
            if(!empty($cfg['slack_canal_id'])){[$ch,$body]=self::http('https://slack.com/api/conversations.info?channel='.rawurlencode($cfg['slack_canal_id']),array('method'=>'GET','headers'=>$headers));if($ch!==200||empty($body['ok'])||empty($body['channel']['is_member'])||!empty($body['channel']['is_archived'])){return self::falha('Slack',$ch,'O bot precisa participar do canal salvo e ter permissão para consultá-lo.');}$identity['canal_id']=self::texto($body['channel']['id']??$cfg['slack_canal_id']);$identity['canal']='#'.self::texto($body['channel']['name']??'');}
        }elseif(in_array($n,array('f3base_anuncios_meta_token','f3base_meta_capi_token','f3base_meta_crm_token'),true)){
            // Controles num valor legado nunca entram num cabeçalho HTTP. A Meta recebe o parâmetro codificado para decidir a validade.
            $unsafe=preg_match('/[\x00-\x20\x7f]/',$token);$url='https://graph.facebook.com/v24.0/debug_token?input_token='.rawurlencode($token).($unsafe?'&access_token='.rawurlencode($token):'');
            [$http,$d]=self::http($url,array('method'=>'GET','headers'=>$unsafe?array():array('Authorization'=>'Bearer '.$token)));$d=$d['data']??array();
            $scopes=is_array($d['scopes']??null)?array_values(array_filter($d['scopes'],'is_string')):array();$required=$n==='f3base_anuncios_meta_token'?array('leads_retrieval','pages_show_list','pages_read_engagement','pages_manage_ads'):array('ads_management');
            if($http!==200||empty($d['is_valid'])||empty($d['app_id'])||empty($d['user_id'])||array_diff($required,$scopes)||!empty($d['expires_at'])&&(int)$d['expires_at']<=time()){return self::falha('Meta',$http,'Confira validade e permissões necessárias: '.implode(', ',$required).'.');}
            $identity=array('provedor'=>'meta','usuario_id'=>self::texto($d['user_id']),'tipo'=>self::texto($d['type']??''),'aplicativo_id'=>self::texto($d['app_id']),'aplicativo'=>self::texto($d['application']??''),'expira_em'=>(int)($d['expires_at']??0),'escopos'=>array_map(array(__CLASS__,'texto'),$scopes),'escopos_extras'=>array_values(array_diff($scopes,$required)));
        }elseif(in_array($n,array(F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET),true)){
            $ids=$cfg['client_ids']??array();$secret=$n===F3Base_Linkedin_Api::SECRET?$token:self::secreto(F3Base_Linkedin_Api::SECRET);$access=$n===F3Base_Linkedin_Api::TOKEN?$token:self::secreto(F3Base_Linkedin_Api::TOKEN);
            if(count($ids)!==1||empty($ids[0])||$secret===''||$access===''){return self::falha('LinkedIn',0,'Informe um Client ID único, o Access Token e o Primary Client Secret do mesmo aplicativo.');}
            [$http,$d]=self::http('https://www.linkedin.com/oauth/v2/introspectToken',array('method'=>'POST','headers'=>array('Content-Type'=>'application/x-www-form-urlencoded'),'body'=>array('client_id'=>$ids[0],'client_secret'=>$secret,'token'=>$access)));
            $scopes=preg_split('/[ ,]+/',is_string($d['scope']??null)?trim($d['scope']):'');
            if($http!==200||($d['active']??false)!==true||($d['auth_type']??'')!=='3L'||($d['client_id']??'')!==$ids[0]||!in_array('r_marketing_leadgen_automation',$scopes,true)||isset($d['expires_at'])&&(int)$d['expires_at']<=time()){return self::falha('LinkedIn',$http,$http===401?'O Primary Client Secret foi recusado.':'Confira o par Client ID/Primary Client Secret, token ativo e escopo r_marketing_leadgen_automation.');}
            // Introspecção não informa o membro. Não inventar continuidade de identidade pessoal.
            $identity=array('provedor'=>'linkedin','aplicativo_id'=>self::texto($d['client_id']),'usuario_id'=>self::texto($d['user_id']??$d['sub']??''),'usuario_confirmado'=>!empty($d['user_id'])||!empty($d['sub']),'autorizado_em'=>(int)($d['authorized_at']??0),'expira_em'=>(int)($d['expires_at']??0),'escopos'=>array_values($scopes));
        }else{return array('ok'=>true,'codigo'=>'formato_local_aceito','remota'=>false,'identidade'=>array('provedor'=>'local','projeto'=>self::texto($cfg['projeto']??'')));}
        $identity=map_deep($identity,static fn($v)=>is_string($v)?str_replace($token,'[credencial removida]',$v):$v);return array('ok'=>true,'codigo'=>'credencial_confirmada','remota'=>true,'identidade'=>$identity);
    }
    private static function chave_identidade(array $i): array {
        $keys=array('pipedrive'=>array('usuario_id','empresa_id','dominio'),'slack'=>array('workspace_id'),'meta'=>array('usuario_id','aplicativo_id'),'linkedin'=>array('usuario_id','aplicativo_id','autorizado_em'),'local'=>array('projeto'))[$i['provedor']??'']??array();return array_intersect_key($i,array_flip($keys));
    }
    private static function vinculo(string $n,string $v,array $cfg,string $rev): string {
        $peer=in_array($n,array(F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET),true)?self::secreto($n===F3Base_Linkedin_Api::TOKEN?F3Base_Linkedin_Api::SECRET:F3Base_Linkedin_Api::TOKEN):'';
        return hash_hmac('sha256',wp_json_encode(array($n,$v,$cfg,$rev,$peer,get_current_user_id(),home_url())),wp_salt('auth'));
    }
    private static function meta(string $n): bool {return in_array($n,array('f3base_anuncios_meta_token','f3base_meta_capi_token','f3base_meta_crm_token'),true);}
    public static function avisos_formato(string $n,string $v): array {
        $out=F3Base_Segredos::avisos_normalizacao($v);$v=trim($v);
        if(self::meta($n)&&$v!==''){
            if(!str_starts_with($v,'EAA')){$out[]=array('regra'=>'prefixo_EAA','motivo'=>'O valor não começa com EAA. Esse prefixo é uma referência local; a Meta decide a validade.');}
            if(strlen($v)<100){$out[]=array('regra'=>'minimo_100_legado','motivo'=>'O valor tem menos de 100 caracteres. O mínimo antigo foi retirado: o tamanho dos tokens Meta varia.');}
            if(preg_match('/[\r\n]/',$v)){$out[]=array('regra'=>'quebra_linha_interna','motivo'=>'Há quebra de linha interna; o valor será conferido pela Meta em parâmetro codificado, sem montar cabeçalho com controles.');}
            if(preg_match('/^[a-fA-F0-9]{32}$/D',$v)){$out[]=array('regra'=>'formato_chave_aplicativo','motivo'=>'O formato coincide com chave secreta de aplicativo; confira o tipo após a validação remota.');}
        }return $out;
    }
    public static function verificar(string $n,string $v,string $confirmation='',bool $force=false): array {
        $avisos=array_values(array_unique(array_merge(self::$normalizacoes[$n]??array(),self::avisos_formato($n,$v)),SORT_REGULAR));$r=self::verificar_interno($n,$v,$confirmation,$force);if($avisos){$r['avisos']=$avisos;}if(isset(self::$rotacoes[$n])&&!empty($r['ok'])){self::$rotacoes[$n]['check']=$r;}self::$ultima=$r;return $r;
    }
    private static function verificar_interno(string $n,string $v,string $confirmation='',bool $force=false): array {
        self::$ultima=array();if(!F3Base_Segredos::gerenciado($n)){return self::$ultima=array('ok'=>false,'codigo'=>'credencial_desconhecida');}
        $format=F3Base_Segredos::recusar($n,$v);if($format!==''&&!($force&&self::meta($n)&&strlen(trim($v))<=8192)){return self::$ultima=array('ok'=>false,'codigo'=>'formato_invalido','motivo'=>$format);}
        $v=trim($v);$foto=F3Base_Options::fotografia_bruta($n);if($foto['erro']){return self::$ultima=array('ok'=>false,'codigo'=>'leitura_falhou','motivo'=>'Não foi possível ler a credencial salva.');}
        $old=F3Base_Segredos::abrir($n,is_string($foto['valor'])?$foto['valor']:'');
        if($v===''||!$force&&hash_equals($old,$v)){return self::$ultima=array('ok'=>true,'codigo'=>$v===''?'remocao_solicitada':'credencial_inalterada','remota'=>false);}
        $cfg=self::cfg($n);$bind=self::vinculo($n,$v,$cfg,$foto['revisao']);
        $check=self::$checks[$bind]??self::remoto($n,$v,$cfg);self::$checks[$bind]=$check;
        if(empty($check['ok'])){return self::$ultima=$check;}
        if(!hash_equals($foto['revisao'],F3Base_Options::revisao($n))||!hash_equals($bind,self::vinculo($n,$v,self::cfg($n),$foto['revisao']))){return self::$ultima=array('ok'=>false,'codigo'=>'conflito','motivo'=>'A configuração mudou durante a verificação. Reabra a tela.');}
        $stored=F3Base_Options::ler(self::OPTION)[$n]??array();$previous=($stored['revisao']??'')===$foto['revisao']?($stored['identidade']??array()):array();
        if(!$previous&&$old!==''&&!hash_equals($old,$v)){$oldCheck=self::$checks[$bind.'old']??self::remoto($n,$old,$cfg);self::$checks[$bind.'old']=$oldCheck;$previous=!empty($oldCheck['ok'])?($oldCheck['identidade']??array()):array();}
        $same=$previous&&self::chave_identidade($previous)===self::chave_identidade($check['identidade']);
        if(($check['identidade']['provedor']??'')==='linkedin'&&empty($check['identidade']['usuario_confirmado'])){$same=false;$check['identidade']['limite']='A introspecção confirma aplicativo e escopos, mas não identifica o membro. A troca exige confirmação.';}
        $change=$old!==''&&!hash_equals($old,$v)&&!$same&&!empty($check['remota']);
        $check+=array('anterior'=>$previous,'mesma_identidade'=>(bool)$same,'mudanca_identidade'=>(bool)$change,'verificada_em'=>time());
        $confirmation=$confirmation?:self::confirmacao($n);
        if($change){$parts=explode('.',$confirmation);$valid=count($parts)===2&&ctype_digit($parts[0])&&(int)$parts[0]>=time()&&(int)$parts[0]<=time()+600&&hash_equals(hash_hmac('sha256',$bind.'|'.$parts[0].'|'.wp_json_encode($check['identidade']),wp_salt('auth')),$parts[1]);if(!$valid){$expiry=time()+600;$check['ok']=false;$check['codigo']='confirmacao_identidade_necessaria';$check['motivo']='A identidade verificada mudou ou a identidade anterior não pôde ser comprovada. Confira os dados antes de confirmar a troca.';$check['confirmacao']=$expiry.'.'.hash_hmac('sha256',$bind.'|'.$expiry.'|'.wp_json_encode($check['identidade']),wp_salt('auth'));return self::$ultima=$check;}}
        self::$rotacoes[$n]=array('hash'=>hash_hmac('sha256',$v,wp_salt('auth')),'check'=>$check,'antes'=>$foto['revisao']);return self::$ultima=$check;
    }
    private static function confirmacao(string $n): string {
        if(isset(self::$confirmacoes[$n])){return (string)self::$confirmacoes[$n];}
        // O formulário original continua responsável por capacidade e nonce. Prova HMAC vinculada ao administrador.
        $input=is_admin()&&current_user_can('manage_options')?($_POST['f3base_credencial_confirmacoes']??''):'';$map=is_string($input)?json_decode(wp_unslash($input),true):array();return is_string($map[$n]??null)?$map[$n]:'';
    }
    public static function preserva(string $n): bool {
        $r=self::$rotacoes[$n]??array();return !empty($r['check']['mesma_identidade'])&&hash_equals($r['hash'],hash_hmac('sha256',F3Base_Segredos::abrir($n),wp_salt('auth')));
    }
    public static function registrar(string $n,$before,$after): void {
        if(!F3Base_Segredos::gerenciado($n)||$before===$after){return;}$r=self::$rotacoes[$n]??array();
        if(!$r||!hash_equals($r['hash'],hash_hmac('sha256',F3Base_Segredos::abrir($n),wp_salt('auth')))){return;}
        $metadata=array_intersect_key($r['check'],array_flip(array('identidade','verificada_em','remota','codigo','avisos')));$metadata['revisao']=F3Base_Options::revisao($n);
        F3Base_Options::atualizar_estado(self::OPTION,static function($s)use($n,$metadata){$s[$n]=$metadata;return $s;});
    }
    public static function completar_resultado(string $n,array $r): array {
        if(empty($r['persisted'])||!isset(self::$rotacoes[$n])){return $r;}
        $s=F3Base_Options::ler(self::OPTION)[$n]??array();$confirmed=($s['revisao']??'')===($r['revisao']??'');
        $r['identidade_registrada']=$confirmed;
        if(!$confirmed){$r['ok']=false;$r['codigo']='credencial_salva_identidade_pendente';$r['motivo']='A credencial foi salva e verificada, mas sua identidade não pôde ser registrada. Use Verificar credencial salva; não repita a troca.';$r['verification']=F3Base_Options::resultado_verificacao('pending','runtime','identidade_nao_persistida',$r['motivo']);}
        return $r;
    }
    public static function preservar_estado(string $n): bool {
        if(!self::preserva($n)){return false;}$old=self::$rotacoes[$n]['antes'];$rev=F3Base_Options::revisao($n);
        if($n==='f3base_pipedrive_token'){
            $s=F3Base_Options::ler('f3base_pipedrive_estado');$identity=$s['identidade_conta']??'';
            if(($s['credencial_revisao']??'')!==$old){return false;}
            $newIdentity=F3Base_Integracoes::identidade_pipedrive($s);
            $save=F3Base_Options::atualizar_estado('f3base_pipedrive_estado',static function($v)use($s,$rev,$newIdentity){if($v!==$s){return null;}$v['credencial_revisao']=$rev;if(isset($v['identidade_conta'])){$v['identidade_conta']=$newIdentity;}return $v;});
            if(empty($save['persisted'])){return false;}
            F3Base_Options::atualizar_estado('f3base_qualidade_catalogo',static function($v)use($identity,$newIdentity,$old,$rev){if($identity!==''&&($v['identidade_conta']??'')===$identity){$v['identidade_conta']=$newIdentity;}if(($v['prova']['credencial_revisao']??'')===$old){$v['prova']['credencial_revisao']=$rev;}return $v;});return true;
        }
        if($n==='f3base_anuncios_meta_token'){$save=F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($s)use($old,$rev){if(($s['meta']['credencial_revisao']??'')!==$old){return null;}$s['meta']['credencial_revisao']=$rev;return $s;});return !empty($save['persisted']);}
        return true;
    }
    public static function ajuda(string $n): void {
        $d=self::definicoes()[$n]??null;if(!$d){return;}
        wp_enqueue_script('f3base-credenciais',plugins_url('assets/js/credenciais.js',F3BASE_PLUGIN_DIR.'base-site-core-fator3.php'),array(),F3BASE_PLUGIN_VERSAO,true);
        $data=self::ler(array('nome'=>$n))['credenciais'][0]??array();
        echo '<p class="description">'.esc_html($d[1]).'</p><div class="f3base-credencial-identidade" data-credencial-nome="'.esc_attr($n).'" data-revisao="'.esc_attr(F3Base_Options::revisao($n)).'" data-nonce="'.esc_attr(wp_create_nonce('f3base-credenciais')).'">';
        foreach($data['avisos']??array() as $aviso){echo '<p class="description">'.esc_html($aviso['motivo']).'</p>';}
        if(!empty($data['identidade'])){$display=$data['identidade'];if(array_key_exists('expira_em',$display)){$display['validade']=$display['expira_em']?wp_date('d/m/Y H:i T',(int)$display['expira_em']):'Não expira';unset($display['expira_em']);}if(($display['tipo']??'')==='SYSTEM_USER'){$display['tipo']='Usuário do sistema';}elseif(($display['tipo']??'')==='USER'){$display['tipo']='Usuário';}if(!empty($display['autorizado_em'])){$display['autorizado_em']=wp_date('d/m/Y H:i T',(int)$display['autorizado_em']);}echo '<p><strong>Identidade da credencial salva</strong></p>'.F3Base_Config_UI::estado($display);}else{echo '<p>Identidade ainda não verificada nesta configuração.</p>';}
        if($n==='f3base_clarity_api_token'&&!empty($data['ultimo_teste'])){$display=$data['ultimo_teste'];if(!empty($display['em'])){$display['em']=wp_date('d/m/Y H:i T',(int)$display['em']);}echo '<p>Último teste/coleta registrado</p>'.F3Base_Config_UI::estado($display);}
        if(!empty($data['estado']['presente'])&&in_array($n,array('f3base_pipedrive_token','f3base_slack_bot_token','f3base_anuncios_meta_token','f3base_meta_capi_token','f3base_meta_crm_token',F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET),true)){echo '<button type="button" class="button" data-credencial-verificar-salva>Verificar credencial salva</button>'; }echo '<p role="status" class="f3base-credencial-mensagem"></p></div>';
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$out=array();
        foreach(self::definicoes() as $n=>$def){if(!empty($e['nome'])&&$e['nome']!==$n){continue;}$s=F3Base_Options::ler(self::OPTION)[$n]??array();$out[$n]=array('rotulo'=>$def[0],'ajuda'=>$def[1],'estado'=>F3Base_Segredos::status($n),'identidade'=>($s['revisao']??'')===F3Base_Options::revisao($n)?($s['identidade']??null):null,'verificada_em'=>$s['verificada_em']??null,'avisos'=>($s['revisao']??'')===F3Base_Options::revisao($n)?($s['avisos']??array()):array());if($n==='f3base_clarity_api_token'){$out[$n]['ultimo_teste']=F3Base_Options::ler('f3base_clarity_estado')['ultima_execucao']??null;}}
        // Nomes de options são valores, nunca chaves: o canal redige chaves de segredo.
        $items=array();foreach($out as $name=>$item){$items[]=array('nome'=>$name)+$item;}
        return array('ok'=>true,'credenciais'=>$items);
    }
    public static function previa(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$n=$e['nome']??'';$saved=($e['usar_salva']??false)===true;
        if(!is_string($n)||!F3Base_Segredos::gerenciado($n)||(!$saved&&!is_string($e['credential']??null))){return array('ok'=>false,'codigo'=>'entrada_invalida');}
        $rev=F3Base_Options::revisao($n);if(!hash_equals($rev,(string)($e['revisao_esperada']??''))){return array('ok'=>false,'codigo'=>'conflito');}
        $value=$saved?F3Base_Segredos::abrir($n):$e['credential'];if($saved&&$value===''){return array('ok'=>false,'codigo'=>'credencial_ausente','motivo'=>'Sem credencial salva para verificar.');}
        $normalizacao=$saved?F3Base_Segredos::avisos_leitura($n):array();$result=self::verificar($n,$value,(string)($e['confirmacao']??''),$saved);if($normalizacao){$result['avisos']=array_values(array_unique(array_merge($normalizacao,$result['avisos']??array()),SORT_REGULAR));}
        if($saved&&!empty($result['ok'])&&isset($result['identidade'])){
            $metadata=array_intersect_key($result,array_flip(array('identidade','verificada_em','remota','codigo','avisos')))+array('revisao'=>$rev);
            $write=F3Base_Options::atualizar_estado(self::OPTION,static function($s)use($n,$rev,$metadata){if(!hash_equals($rev,F3Base_Options::revisao($n))){return null;}$s[$n]=$metadata;return $s;});$result['metadados_persistidos']=!empty($write['persisted']);
            if(empty($write['persisted'])){$result['ok']=false;$result['codigo']='identidade_nao_persistida';$result['motivo']='A consulta terminou, mas a identidade não pôde ser registrada. A credencial não foi alterada.';}
        }
        return $result;
    }

    public static function iniciar(): void {
        add_action('updated_option',array(__CLASS__,'registrar'),5,3);add_action('added_option',static fn($n,$v)=>self::registrar($n,null,$v),5,2);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('credenciais-ler','Identidades e ajuda das credenciais; nunca retorna valores secretos',array(__CLASS__,'ler'),array('nome'=>array('type'=>'string','enum'=>F3Base_Segredos::NOMES)));F3Base_Servicos::ability('credenciais-verificar','Verificar candidata sem gravar; mudança de identidade requer confirmação',array(__CLASS__,'previa'),array('nome'=>array('type'=>'string','enum'=>F3Base_Segredos::NOMES),'credential'=>array('type'=>'string','maxLength'=>8192),'revisao_esperada'=>array('type'=>'string'),'confirmacao'=>array('type'=>'string','maxLength'=>100),'usar_salva'=>array('type'=>'boolean','default'=>false)),array('nome','revisao_esperada'),false);});
        add_action('wp_ajax_f3base_credenciais_previa',array(__CLASS__,'ajax'));
    }
    public static function ajax(): void {
        if(!current_user_can('manage_options')){wp_send_json_error(array('motivo'=>'Sem permissão.'),403);}check_ajax_referer('f3base-credenciais','nonce');
        $payload=json_decode(wp_unslash((string)($_POST['payload']??'')),true);if(!is_array($payload)||count($payload)>14){wp_send_json_error(array('motivo'=>'Entrada inválida.'),400);}
        $context=json_decode(wp_unslash((string)($_POST['contexto']??'{}')),true);$proposta=array();
        foreach($payload as $e){if(is_array($e)&&in_array($e['nome']??'',F3Base_Segredos::NOMES,true)&&is_string($e['credential']??null)){$proposta[$e['nome']]=$e['credential'];}}
        if(is_array($context)){
            foreach(array('dominio'=>'f3base_pipedrive','slack_canal_id'=>'f3base_avisos') as $key=>$opt){if(isset($context[$key])&&is_string($context[$key])){$proposta[$opt]=array_replace(F3Base_Options::ler($opt),array($key=>$context[$key]));}}
            if(isset($context['client_id'],$context['integracao_id'])&&is_string($context['client_id'])&&is_string($context['integracao_id'])){$cfg=F3Base_Options::ler(F3Base_Linkedin::OPCAO);if(isset($cfg['integracoes'][$context['integracao_id']])){$cfg['integracoes'][$context['integracao_id']]['client_id']=$context['client_id'];$proposta[F3Base_Linkedin::OPCAO]=$cfg;}}
        }
        $out=F3Base_Options::com_proposta($proposta,static function()use($payload){$out=array();foreach($payload as $e){$r=self::previa(is_array($e)?$e:array());$out[]=$r;if(empty($r['ok'])&&($r['codigo']??'')!=='confirmacao_identidade_necessaria'){return array('erro'=>$r);}}return $out;});
        if(isset($out['erro'])){wp_send_json_error($out['erro'],400);}
        wp_send_json_success($out);
    }
}
