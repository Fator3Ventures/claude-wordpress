<?php
/** Ownership is captured with the accepted record, never inferred from cached HTML. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Conversoes_Transporte {
    public static function catalogo(array $c): array {
        $props=$sub=array();foreach(array('ga4'=>'GA4','google_ads'=>'Google Ads') as $key=>$label){$props[$key]=array('type'=>'string','enum'=>array('navegador','servidor'));$sub[$key]=array('tipo'=>'enum','opcoes'=>array('navegador'=>'Navegador','servidor'=>'Servidor'),'rotulo'=>$label,'descricao'=>'navegador ou servidor. Servidor exige adaptador pronto.','impacto'=>'Aplica-se somente a novos contatos; não transfere entregas anteriores.');}
        $props['linkedin']=array('type'=>'string','enum'=>array('navegador','ambos'));$sub['linkedin']=array('tipo'=>'enum','opcoes'=>array('navegador'=>'Somente navegador','ambos'=>'Navegador e servidor'),'rotulo'=>'LinkedIn','descricao'=>'O servidor usa o mesmo evento do navegador e exige conexão, permissão rw_conversions e regra com fonte API no pacote LinkedIn. Sem isso, a fila informa o bloqueio.','impacto'=>'Aplica-se aos novos contatos aceitos. Testes e spam nunca são enviados.');
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>$props,'required'=>array('ga4','google_ads'));
        $c['f3base_conversoes_transporte']=array('rotulo'=>'Transporte das conversões de contato','descricao'=>'Escolha independente por destino. GA4 e Ads iniciam pelo navegador. LinkedIn usa ambos, com servidor condicionado à autorização do fornecedor.','operavel'=>true,'secao'=>'medicao','campo'=>'grupo','autoload'=>false,'padrao'=>array('ga4'=>'navegador','google_ads'=>'navegador','linkedin'=>'ambos'),'subcampos'=>$sub,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>array(__CLASS__,'validar'));
        return $c;
    }
    public static function capacidade(string $target): array {
        try{$a=F3Base_Conversoes_Servidor::adaptador($target);$v=$a?$a->capabilities():array();}catch(Throwable $e){$v=array();}
        $v=is_array($v)?$v:array();
        $ok=is_array($v)&&($v['contract']??'')===F3Base_Conversoes_Servidor::CONTRATO&&($v['ready']??false)===true&&is_string($v['destination_ref']??null)&&$v['destination_ref']!==''&&strlen($v['destination_ref'])<=191;
        $reason=$ok?'ok':F3Base_Conversoes_Servidor::codigo($v['reason']??null,'adaptador_indisponivel');
        if($target==='linkedin'&&(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id')===''){$ok=false;$reason='regra_ausente';}
        if($ok&&$target==='linkedin'&&($v['conversion_id']??'')!==(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id')){$ok=false;$reason=$v?'regra_linkedin_divergente':'adaptador_indisponivel';}
        if($ok&&!is_callable(array($a,'sendBound'))){$ok=false;$reason='destination_binding_unsupported';}
        return array('ready'=>$ok,'destination_ref'=>is_string($v['destination_ref']??null)&&strlen($v['destination_ref'])<=191?$v['destination_ref']:'','reason'=>$reason);
    }
    public static function validar($v): string {
        if(!is_array($v)||array_diff(array_keys($v),array('ga4','google_ads','linkedin'))){return 'Informe ga4 e google_ads.';}
        if(isset($v['linkedin'])&&!in_array($v['linkedin'],array('navegador','ambos'),true)){return 'LinkedIn aceita navegador ou ambos.';}
        foreach(array('ga4','google_ads') as $t){if(!in_array($v[$t]??'',array('navegador','servidor'),true)){return 'Use navegador ou servidor.';}if($v[$t]==='servidor'&&!self::capacidade($t)['ready']){return 'Servidor indisponível para '.$t.': configure e valide o adaptador Google.';}}return '';
    }
    public static function capturar(): array {
        $v=F3Base_Options::ler('f3base_conversoes_transporte');$out=array();foreach(array('ga4','google_ads') as $t){$out[$t]=($v[$t]??'')==='servidor'?'servidor':'navegador';}
        $out['linkedin']=($v['linkedin']??'ambos')==='ambos'&&(string)F3Base_Options::ler('f3base_linkedin_conversion_id')!==''&&(string)F3Base_Options::ler('f3base_linkedin_partner_id')!==''?'ambos':'navegador';
        $refs=array();foreach($out as $t=>$mode){if(in_array($mode,array('servidor','ambos'),true)){$cap=self::capacidade($t);$refs[$t]=$cap['ready']?$cap['destination_ref']:'';}}
        return array('destinos'=>$out,'referencias'=>$refs,'revisao'=>hash('sha256',(string)wp_json_encode(array($out,$refs))));
    }
    public static function registro(array $lead): array {
        $d=$lead['dados']??array();$stored=$d['conversoes_transporte']['destinos']??array();$out=array();
        foreach(array('ga4','google_ads') as $t){$out[$t]=in_array($stored[$t]??'',array('navegador','servidor'),true)?$stored[$t]:((int)($d['conversoes_servidor_versao']??0)===1?'servidor':'desconhecido');}
        $out['linkedin']=in_array($stored['linkedin']??'',array('navegador','ambos'),true)?$stored['linkedin']:'desconhecido';return $out;
    }
    public static function estado(): array {
        $v=self::capturar();$out=array();foreach($v['destinos'] as $t=>$mode){$cap=in_array($mode,array('servidor','ambos'),true)?self::capacidade($t):array('ready'=>true,'reason'=>'ok');$out[$t]=array('selected'=>$mode,'effective'=>$mode,'ready'=>$cap['ready'],'reason'=>$cap['reason']);}return $out;
    }
}
