<?php
/** Heurística versionada; só observações novas e sessões sem interação observada. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Automacao_Provavel {
    const REGRA='automacao-1.45.0-1';
    public static function evidencia(?string $ua=null,?string $ip=null): array {
        $ua=$ua??(string)($_SERVER['HTTP_USER_AGENT']??'');$family='';$major=0;
        foreach(array('Firefox'=>109,'Chrome'=>119,'Version'=>16) as $name=>$max){if(($name!=='Version'||str_contains($ua,'Safari/'))&&preg_match('~'.preg_quote($name,'~').'/([0-9]+)~',$ua,$m)){$family=$name;$major=(int)$m[1];$old=$major>0&&$major<=$max;break;}}
        if($family===''){return array();}
        $origem=F3Base_Modulo_Endpoint_Leads::origem();$trust=F3Base_Modulo_Endpoint_Leads::cabecalho_confiavel();
        // Legacy forwarding without a proxy range is not sufficient proof for this heuristic.
        $trusted=$ip!==null||($origem['fonte']??'')==='remote_addr'||!empty($trust['redes_confiaveis']);
        $cloud=$trusted?F3Base_Redes_Robos::nuvem($ip??$origem['valor']):array();
        return array('regra'=>self::REGRA,'navegador'=>$family,'versao'=>$major,'desatualizado'=>$old,'corte_versoes'=>'Firefox<=109;Chrome<=119;Safari<=16','nuvem'=>$cloud,'observado_em'=>time());
    }
    public static function motivo(array $ev,bool $interacao,bool $recorrente): string {
        if($interacao){return '';}
        if(!empty($ev['nuvem'])&&!empty($ev['desatualizado'])){return 'nuvem_navegador_antigo_sem_interacao';}
        return $recorrente?'mesmo_caminho_hora_dias_seguidos_sem_interacao':'';
    }
    public static function interagiu(string $sessao,string $classe): ?bool {
        global $wpdb;$a=F3Base_Analise::tabela();$b=F3Base_Modulo_Comportamento::nome_tabela_eventos();
        $n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE sessao=%s AND classe_trafego=%s AND (tipo IN ('form_inicio','form_tentativa','form_aceito','form_complemento','clique_interno'))",$a,$sessao,$classe));if($wpdb->last_error){return null;}
        $m=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE sessao=%s AND classe_trafego=%s AND ((metrica='f3base_tempo_ativo' AND valor>0) OR metrica IN (%s,%s) OR metrica LIKE %s)",$b,$sessao,$classe,F3Base_Modulo_Comportamento::evento_do_gatilho('rolagem'),F3Base_Modulo_Comportamento::evento_do_gatilho('interseccao'),'%clique%'));return $wpdb->last_error?null:($n>0||$m>0);
    }
    public static function executar(): array {
        global $wpdb;$t=F3Base_Analise::tabela();$cursor=(int)(F3Base_Options::ler('f3base_analise_saude')['automacao_cursor']??0);$from=time()-8*DAY_IN_SECONDS;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,sessao,visitante,classe_trafego,caminho,criado_em,automacao,automacao_evidencia FROM %i WHERE id>%d AND criado_em>=%d AND criado_em<=%d AND tipo='pagina' AND automacao_regra=%s AND automacao IN ('nao_identificada','provavel') ORDER BY id LIMIT 100",$t,$cursor,$from,time()-1800,self::REGRA),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'automacao_leitura_falhou');}
        $done=0;$sessions=array();
        foreach($rows as $r){$cursor=(int)$r['id'];$key=$r['sessao'].'|'.$r['classe_trafego'];if(isset($sessions[$key])){continue;}$sessions[$key]=true;$ev=json_decode($r['automacao_evidencia'],true)?:array();if(!$ev){continue;}$interaction=self::interagiu($r['sessao'],$r['classe_trafego']);if($interaction===null){return array('ok'=>false,'codigo'=>'automacao_interacao_indisponivel');}
            $same=$wpdb->get_results($wpdb->prepare("SELECT criado_em,automacao_evidencia,sessao FROM %i WHERE visitante=%s AND classe_trafego=%s AND caminho=%s AND tipo='pagina' AND criado_em>=%d AND criado_em<%d AND automacao_regra=%s LIMIT 100",$t,$r['visitante'],$r['classe_trafego'],$r['caminho'],(int)$r['criado_em']-3*DAY_IN_SECONDS,(int)$r['criado_em'],self::REGRA),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'automacao_repeticao_indisponivel');}
            $repeat=false;$yesterday=(new DateTimeImmutable('@'.$r['criado_em']))->setTimezone(wp_timezone())->modify('-1 day')->format('Y-m-d');
            foreach($same as $prev){$pe=json_decode($prev['automacao_evidencia'],true)?:array();if(wp_date('Y-m-d',(int)$prev['criado_em'])===$yesterday&&wp_date('H',(int)$prev['criado_em'])===wp_date('H',(int)$r['criado_em'])&&($pe['navegador']??'')===($ev['navegador']??'')&&($pe['versao']??0)===($ev['versao']??0)&&self::interagiu($prev['sessao'],$r['classe_trafego'])===false){$repeat=true;break;}}
            $reason=self::motivo($ev,$interaction,$repeat);$state=$reason?'provavel':'nao_identificada';
            // Never overwrite declared automation or observations evaluated by older rules.
            foreach(array($t,F3Base_Modulo_Comportamento::nome_tabela_eventos()) as $table){$days=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT criado_em FROM %i WHERE sessao=%s AND classe_trafego=%s AND automacao_regra=%s',$table,$r['sessao'],$r['classe_trafego'],self::REGRA));if($wpdb->last_error){return array('ok'=>false,'codigo'=>'automacao_dias_indisponiveis');}$changed=$wpdb->query($wpdb->prepare("UPDATE %i SET automacao=%s,automacao_motivos=%s WHERE sessao=%s AND classe_trafego=%s AND automacao_regra=%s AND automacao<>'declarada' AND automacao_motivos NOT LIKE '%%headless_chrome%%' AND automacao_motivos NOT LIKE '%%webdriver_declarado%%' AND (automacao<>%s OR automacao_motivos<>%s)",$table,$state,$reason,$r['sessao'],$r['classe_trafego'],self::REGRA,$state,$reason));if($changed===false){return array('ok'=>false,'codigo'=>'automacao_gravacao_falhou');}if($changed){$marked=array();foreach($days as $stamp){$day=wp_date('Y-m-d',(int)$stamp);if(!isset($marked[$day])){F3Base_Editorial::marcar_dia((int)$stamp);$marked[$day]=true;}}++$done;}}
        }
        F3Base_Options::atualizar_estado('f3base_analise_saude',static function($v)use($cursor,$rows,$done){$v['automacao_cursor']=count($rows)<100?0:$cursor;$v['automacao_ultima']=array('regra'=>self::REGRA,'em'=>time(),'alteracoes'=>$done,'lidas'=>count($rows));return $v;});return array('ok'=>true,'alteracoes'=>$done);
    }
}
