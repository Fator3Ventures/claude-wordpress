<?php
/** RFC 7208 evaluator with a shared lookup/void budget; caller supplies the trusted SMTP boundary. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Spf {
    private F3Base_Email_Dns $dns;
    private string $ip;
    private string $sender;
    private string $helo;
    private int $terms=0;
    private int $voids=0;
    public function __construct(F3Base_Email_Dns $dns,string $ip,string $sender,string $helo){$this->dns=$dns;$this->ip=$ip;$this->sender=$sender;$this->helo=$helo;}
    public function check(string $domain): string {
        try{return $this->evaluate($domain,0);}catch(Throwable $e){return str_starts_with($e->getMessage(),'spf_')?'permerror':'temperror';}
    }
    private function lookup(string $domain,string $type): array {
        if(!F3Base_Email_Dns::domain($domain)){throw new RuntimeException('spf_domain');}$rows=$this->dns->query($domain,$type);if(!$rows&&++$this->voids>2){throw new RuntimeException('spf_void_limit');}return array_column($rows,'value');
    }
    private function term(): void {if(++$this->terms>10){throw new RuntimeException('spf_lookup_limit');}}
    public static function in_net(string $ip,string $network,int $bits): bool {
        $a=@inet_pton($ip);$b=@inet_pton($network);if($a===false||$b===false||strlen($a)!==strlen($b)||$bits<0||$bits>strlen($a)*8){return false;}
        $bytes=intdiv($bits,8);$rest=$bits%8;return substr($a,0,$bytes)===substr($b,0,$bytes)&&(!$rest||((ord($a[$bytes])^ord($b[$bytes]))&(255<<(8-$rest)))===0);
    }
    private function addresses(string $host,int $v4,int $v6,bool $limited=false): bool {
        $six=str_contains($this->ip,':');$addresses=$this->lookup($host,$six?'AAAA':'A');if($limited&&count($addresses)>10){throw new RuntimeException('spf_address_limit');}
        foreach($addresses as $address){if(self::in_net($this->ip,$address,$six?$v6:$v4)){return true;}}return false;
    }
    private function ptr(string $domain): array {
        $packed=@inet_pton($this->ip);if($packed===false){return array();}
        $reverse=strlen($packed)===4?implode('.',array_reverse(explode('.',$this->ip))).'.in-addr.arpa':implode('.',array_reverse(str_split(bin2hex($packed)))).'.ip6.arpa';
        $names=array_slice($this->lookup($reverse,'PTR'),0,10);$valid=array();foreach($names as $name){if($this->addresses($name,32,128,true)){$valid[]=$name;}}
        usort($valid,static fn($a,$b)=>(int)($b===$domain||str_ends_with($b,'.'.$domain))<=>(int)($a===$domain||str_ends_with($a,'.'.$domain)));return $valid;
    }
    private function macro(string $spec,string $domain): string {
        $local=explode('@',$this->sender,2);$origin=$local[1]??$this->helo;$i=str_contains($this->ip,':')?implode('.',str_split(bin2hex(inet_pton($this->ip)))):$this->ip;
        $values=array('s'=>$this->sender,'l'=>$local[0],'o'=>$origin,'d'=>$domain,'i'=>$i,'v'=>str_contains($this->ip,':')?'ip6':'in-addr','h'=>$this->helo);
        if(preg_match('/%(?![%_\-]|\{[slodipvhSLODIPVH][0-9]*r?[.\-+,\/_=]*\})/',$spec)){throw new RuntimeException('spf_macro');}
        $out=preg_replace_callback('/%%|%_|%-|%\{([slodipvhSLODIPVH])([0-9]*)(r?)([.\-+,\/_=]*)\}/',function($m)use($values,$domain){
            if($m[0]==='%%'){return '%';}if($m[0]==='%_'){return ' ';}if($m[0]==='%-'){return '%20';}
            $letter=strtolower($m[1]);$v=$letter==='p'?($this->ptr($domain)[0]??'unknown'):$values[$letter];$parts=preg_split('/['.preg_quote($m[4]?:'.','/').']/',$v);if($m[3]==='r'){$parts=array_reverse($parts);}if($m[2]!==''&&(int)$m[2]>0){$parts=array_slice($parts,-min(128,(int)$m[2]));}$v=implode('.',$parts);return $m[1]!==$letter?rawurlencode($v):$v;
        },$spec);
        $out=strtolower(rtrim($out,'.'));while(strlen($out)>253&&str_contains($out,'.')){$out=substr($out,strpos($out,'.')+1);}if(!F3Base_Email_Dns::domain($out)){throw new RuntimeException('spf_domain');}return $out;
    }
    private function evaluate(string $domain,int $depth): string {
        if($depth>10){throw new RuntimeException('spf_recursion');}
        $records=array_values(array_filter($this->lookup($domain,'TXT'),static fn($x)=>preg_match('/^v=spf1(?: |$)/i',$x)));
        if(!$records){return 'none';}if(count($records)!==1){throw new RuntimeException('spf_records');}
        $tokens=preg_split('/ +/',trim($records[0]));array_shift($tokens);$redirect=null;$seen=array();$mechanisms=array();
        foreach($tokens as $token){
            if(preg_match('/^([a-z][a-z0-9_.-]*)=(.*)$/iD',$token,$m)){$key=strtolower($m[1]);if(isset($seen[$key])){throw new RuntimeException('spf_modifier_duplicate');}$seen[$key]=true;if($key==='redirect'){$redirect=$m[2];if($redirect===''){throw new RuntimeException('spf_redirect');}}continue;}
            if(!preg_match('/^([+?~\-]?)(all|include|a|mx|ptr|ip4|ip6|exists)(.*)$/iD',$token,$m)){throw new RuntimeException('spf_mechanism');}
            $q=$m[1]?:'+';$kind=strtolower($m[2]);$tail=$m[3];
            if($kind==='all'&&$tail!==''||in_array($kind,array('include','exists','ip4','ip6'),true)&&(!str_starts_with($tail,':')||strlen($tail)<2)){throw new RuntimeException('spf_syntax');}
            if($kind==='ptr'&&$tail!==''&&!str_starts_with($tail,':')){throw new RuntimeException('spf_syntax');}
            if(in_array($kind,array('a','mx'),true)&&!preg_match('/^(?::[^\/]+)?(?:\/\d{1,3})?(?:\/\/\d{1,3})?$/D',$tail)){throw new RuntimeException('spf_syntax');}
            if(in_array($kind,array('ip4','ip6'),true)){$net=explode('/',substr($tail,1));$flags=$kind==='ip4'?FILTER_FLAG_IPV4:FILTER_FLAG_IPV6;$max=$kind==='ip4'?32:128;if(count($net)>2||!filter_var($net[0],FILTER_VALIDATE_IP,$flags)||isset($net[1])&&(!ctype_digit($net[1])||(int)$net[1]>$max)){throw new RuntimeException('spf_network');}}
            $mechanisms[]=array($q,$kind,$tail);
        }
        foreach($mechanisms as [$q,$kind,$tail]){
            $match=false;
            if($kind==='all'){$match=true;}
            elseif($kind==='ip4'||$kind==='ip6'){$net=explode('/',substr($tail,1));$match=self::in_net($this->ip,$net[0],isset($net[1])?(int)$net[1]:($kind==='ip4'?32:128));}
            else{
                $this->term();
                if($kind==='include'){$r=$this->evaluate($this->macro(substr($tail,1),$domain),$depth+1);if($r==='none'){throw new RuntimeException('spf_include_none');}$match=$r==='pass';}
                elseif($kind==='exists'){$match=(bool)$this->lookup($this->macro(substr($tail,1),$domain),'A');}
                elseif($kind==='ptr'){$target=$tail===''?$domain:$this->macro(substr($tail,1),$domain);foreach($this->ptr($domain) as $name){if($name===$target||str_ends_with($name,'.'.$target)){$match=true;}}}
                else{
                    preg_match('/^(?::([^\/]+))?(?:\/(\d{1,3}))?(?:\/\/(\d{1,3}))?$/D',$tail,$m);$target=!empty($m[1])?$this->macro($m[1],$domain):$domain;$v4=isset($m[2])&&$m[2]!==''?(int)$m[2]:32;$v6=isset($m[3])&&$m[3]!==''?(int)$m[3]:128;if($v4>32||$v6>128){throw new RuntimeException('spf_cidr');}
                    if($kind==='a'){$match=$this->addresses($target,$v4,$v6);}
                    else{$mx=$this->lookup($target,'MX');if(count($mx)>10){throw new RuntimeException('spf_mx_limit');}foreach($mx as $host){if($this->addresses($host,$v4,$v6,true)){$match=true;break;}}}
                }
            }
            if($match){return array('+'=>'pass','-'=>'fail','~'=>'softfail','?'=>'neutral')[$q];}
        }
        if($redirect!==null){$this->term();$r=$this->evaluate($this->macro($redirect,$domain),$depth+1);if($r==='none'){throw new RuntimeException('spf_redirect_none');}return $r;}
        return 'neutral';
    }
}
