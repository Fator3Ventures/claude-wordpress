<?php
/** Pedido 302. Captura administrativa sem eventos, avisos ou conversões. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Contatos_Externos {
    public static function pode(): bool {
        return current_user_can('manage_options') && current_user_can('f3base_ler_leads') && current_user_can('f3base_gerir_leads');
    }
    public static function propriedades(): array {
        $origem=array();
        foreach(array('canal','parceiro','utm_source','utm_medium','utm_campaign','utm_content','utm_term','utm_id','utm_source_platform') as $k){$origem[$k]=array('type'=>'string','maxLength'=>500);}
        $origem['link_referencia']=array('type'=>'string','format'=>'uri','maxLength'=>2000);
        return array(
            'simular'=>array('type'=>'boolean','default'=>true),
            'idempotency_key'=>array('type'=>'string','minLength'=>8,'maxLength'=>128,'pattern'=>'^[A-Za-z0-9._:-]+$'),
            'metodo'=>array('type'=>'string','enum'=>array('whatsapp','telefone','email','presencial','outro')),
            'nome'=>array('type'=>'string','minLength'=>1,'maxLength'=>250),
            'telefone'=>array('type'=>'string','maxLength'=>40),
            'email'=>array('type'=>'string','maxLength'=>254),
            'empresa'=>array('type'=>'string','maxLength'=>250),
            'primeiro_contato_em'=>array('type'=>'string','format'=>'date-time','description'=>'Data e hora RFC3339 com fuso explícito.'),
            'origem_declarada'=>array('type'=>'object','additionalProperties'=>false,'properties'=>$origem),
            'pipedrive'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array(
                'acao'=>array('type'=>'string','enum'=>array('nenhuma','entregar','vincular_existente'),'default'=>'nenhuma'),
                'ponto'=>array('type'=>'string','maxLength'=>80,'description'=>'Chave já configurada em mapa_pontos; obrigatória para entregar.'),
                'lead_id'=>array('type'=>'string','pattern'=>'^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$'))),
            'contexto_teste'=>array('type'=>'boolean','default'=>false));
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('contato-externo-registrar','Registrar contato externo cifrado; simula por padrão, sem avisos, e-mail ou conversões',array(__CLASS__,'registrar'),self::propriedades(),array('idempotency_key','metodo','nome','primeiro_contato_em'),false,'manage_options',array(__CLASS__,'pode'));
            F3Base_Contatos_Sessoes::registrar_ability();
        });
    }
    private static function hash(string $v): string {return hash_hmac('sha256',$v,wp_salt('secure_auth'));}
    public static function indice_email(string $email): string {return self::hash('externo-email:'.strtolower(trim($email)));}
    public static function email_sql(string $email): string {global $wpdb;return $wpdb->prepare("(email=%s OR (metodo='contato_externo' AND JSON_UNQUOTE(JSON_EXTRACT(dados,'$.contato_externo_email_indice'))=%s))",strtolower(trim($email)),self::indice_email($email));}
    private static function ordenar(array $v): array {ksort($v);foreach($v as &$x){if(is_array($x)){$x=self::ordenar($x);}}unset($x);return $v;}
    public static function externo(array $r): bool {return ($r['metodo']??'')==='contato_externo'||F3Base_Conversas::conversa($r);}
    public static function privado(array $r): ?array {
        return self::externo($r)?F3Base_Contato_Comunicacao::abrir((string)($r['dados']['contato_externo_cifrado']??'')):null;
    }
    /** Projeção transitória. Nunca passar o resultado a persistência ou eventos. */
    public static function projetar(array $r): array {
        if(!self::externo($r)){return $r;}$p=self::privado($r);if(!$p){return $r;}
        $r['nome']=$p['nome'];$r['email']=$p['email'];
        foreach(array('nome','email','telefone','empresa') as $k){$r['dados'][$k]=$p[$k];}
        $r['contato_externo']=$p;return $r;
    }
    public static function registrar(array $e): array {
        if(!self::pode()){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $valid=rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::propriedades(),'required'=>array('idempotency_key','metodo','nome','primeiro_contato_em')));
        if(is_wp_error($valid)){return array('ok'=>false,'codigo'=>'contato_externo_entrada_invalida');}
        foreach(array('nome','telefone','email','empresa') as $k){$e[$k]=trim((string)($e[$k]??''));if(preg_match('/[\x00-\x1f\x7f<>]/u',$e[$k])){return array('ok'=>false,'codigo'=>'contato_externo_entrada_invalida');}}
        if($e['nome']===''||($e['email']!==''&&!is_email($e['email']))||($e['telefone']!==''&&!preg_match('/^\+?[0-9 ().-]{8,40}$/D',$e['telefone']))){return array('ok'=>false,'codigo'=>'contato_externo_identidade_invalida');}
        if($e['email']===''&&$e['telefone']===''&&!in_array($e['metodo'],array('presencial','outro'),true)){return array('ok'=>false,'codigo'=>'contato_externo_telefone_ou_email_obrigatorio');}
        $date=$e['primeiro_contato_em'];
        if(!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/D',$date)){return array('ok'=>false,'codigo'=>'contato_externo_data_invalida');}
        try{$dt=new DateTimeImmutable($date);$errors=DateTimeImmutable::getLastErrors();if(($errors&&($errors['warning_count']||$errors['error_count']))||$dt->getTimestamp()<0||$dt->getTimestamp()>time()+300){throw new RuntimeException();}}catch(Throwable $x){return array('ok'=>false,'codigo'=>'contato_externo_data_invalida');}
        $origin=$e['origem_declarada']??array();
        if(!empty($origin['link_referencia'])){$url=wp_parse_url($origin['link_referencia']);if(!$url||!in_array(strtolower($url['scheme']??''),array('https','http'),true)||empty($url['host'])||isset($url['user'])||isset($url['pass'])){return array('ok'=>false,'codigo'=>'contato_externo_referencia_invalida');}}
        foreach($origin as $v){if(preg_match('/[\x00-\x1f\x7f<>]/u',$v)){return array('ok'=>false,'codigo'=>'contato_externo_origem_invalida');}}
        $crm=$e['pipedrive']??array();$action=$crm['acao']??'nenhuma';$sim=($e['simular']??true)!==false;
        if(($action==='entregar'&&(empty($crm['ponto'])||isset($crm['lead_id'])))||($action==='vincular_existente'&&(empty($crm['lead_id'])||isset($crm['ponto'])))||($action==='nenhuma'&&(isset($crm['ponto'])||isset($crm['lead_id'])))){return array('ok'=>false,'codigo'=>'contato_externo_pipedrive_entrada_invalida');}
        $crm['acao']=$action;$cfg=F3Base_Options::ler('f3base_pipedrive');$state=get_option('f3base_pipedrive_estado',array());
        if($action!=='nenhuma'&&(!F3Base_Integracoes::pipedrive_verificado($state)||($state['dominio']??'')!==($cfg['dominio']??'')||($action==='entregar'&&empty($cfg['ativo'])))){return array('ok'=>false,'codigo'=>'pipedrive_nao_verificado');}
        if($action==='entregar'&&empty($cfg['mapa_pontos'][$crm['ponto']])){return array('ok'=>false,'codigo'=>'pipedrive_ponto_nao_mapeado');}
        if($action==='entregar'&&!empty($e['contexto_teste'])&&empty($cfg['homologacao'])){return array('ok'=>false,'codigo'=>'pipedrive_teste_sem_homologacao');}
        $p=array('metodo'=>$e['metodo'],'nome'=>$e['nome'],'telefone'=>$e['telefone'],'email'=>strtolower($e['email']),'empresa'=>$e['empresa'],'primeiro_contato_em'=>$dt->format('c'),'origem_declarada'=>$origin,'pipedrive'=>$crm,'contexto_teste'=>!empty($e['contexto_teste']));
        $idem=self::hash('contato-externo:'.$e['idempotency_key']);$fingerprint=self::hash(wp_json_encode(self::ordenar($p)));$lock='contato-externo:'.$idem;
        if(!F3Base_Pipedrive_Fila::travar_linha($lock)){return array('ok'=>false,'codigo'=>'contato_externo_ocupado');}
        try{
            global $wpdb;$t=F3Base_Leads_Repositorio::tabela();$existing=$wpdb->get_row($wpdb->prepare('SELECT record_id,payload_hash,captura,eliminacao_pendente,revisao FROM %i WHERE idempotencia=%s',$t,$idem),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'contato_externo_leitura_falhou');}
            if($existing){
                if(in_array($existing['captura'],array('eliminado','eliminando'),true)||$existing['eliminacao_pendente']){return array('ok'=>false,'codigo'=>'contato_externo_ja_eliminado');}
                if(!hash_equals($existing['payload_hash'],$fingerprint)){return array('ok'=>false,'codigo'=>'idempotencia_conflitante');}
                return array('ok'=>true,'simular'=>$sim,'persisted'=>!$sim,'duplicado'=>true,'record_id'=>$existing['record_id'],'revisao'=>(int)$existing['revisao']);
            }
            $effects=array('slack'=>false,'email_automatico'=>false,'conversoes'=>false,'pipedrive'=>$action);
            if($sim){return array('ok'=>true,'simular'=>true,'persisted'=>false,'previa'=>array('metodo'=>$p['metodo'],'primeiro_contato_em'=>$p['primeiro_contato_em'],'campos_informados'=>array_keys(array_filter(array_intersect_key($p,array_flip(array('nome','telefone','email','empresa','origem_declarada')))))),'efeitos'=>$effects,'verificacao_lead_existente'=>$action==='vincular_existente'?'GET na gravação, sem alterar o CRM':'nao_aplicavel');}
            if($action==='vincular_existente'){
                F3Base_Pipedrive_Api::iniciar_lote();$remote=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.strtolower($crm['lead_id']));
                if(empty($remote['ok'])||strtolower((string)($remote['data']['id']??''))!==strtolower($crm['lead_id'])){return array('ok'=>false,'codigo'=>'pipedrive_lead_existente_nao_confirmado');}
                $p['pipedrive']['lead_id']=strtolower($crm['lead_id']);$p['pipedrive']['verificado_em']=gmdate('c');
            }
            if($action!=='nenhuma'){$p['pipedrive']['conta']=$state['dominio'].'|'.$state['conta_id'].'|'.$state['instalacao'];}
            $p['registro']=array('operador_id'=>get_current_user_id(),'em'=>gmdate('c'));
            $cipher=F3Base_Contato_Comunicacao::cifrar($p);$record=bin2hex(random_bytes(16));
            $intent=array('pipedrive'=>array('solicitado'=>$action==='entregar','dominio'=>$action==='entregar'?$cfg['dominio']:'','motivo'=>$action==='entregar'?'contato_externo_solicitado':'contato_externo_sem_entrega','em'=>time(),'versao'=>F3BASE_PLUGIN_VERSAO));
            $data=array('contato_externo_email_indice'=>$p['email']!==''?self::indice_email($p['email']):'','contato_externo_cifrado'=>$cipher,'origem_nativa'=>array('origem'=>'contato_externo'),'contexto_teste'=>$p['contexto_teste'],'email_novo_lead_intencao'=>array('solicitado'=>false),'aviso_intencao'=>array('elegivel'=>false));
            $ok=$wpdb->insert($t,array('record_id'=>$record,'metodo'=>'contato_externo','formulario'=>'','classe_trafego'=>$p['contexto_teste']?'teste':'nao_marcado','criado_em'=>gmdate('Y-m-d H:i:s',$dt->getTimestamp()),'atualizado_em'=>gmdate('Y-m-d H:i:s'),'pagina'=>'','dados'=>wp_json_encode($data),'entrega'=>wp_json_encode($intent),'anexos'=>'[]','idempotencia'=>$idem,'payload_hash'=>$fingerprint,'origem_chave'=>'externo:'.$idem));
            if($ok!==1){return array('ok'=>false,'codigo'=>'contato_externo_persistencia_falhou','persisted'=>false);}
            // The durable intent is atomic with the contact. The regular worker can retry enqueueing.
            $queued=$action==='entregar'?F3Base_Pipedrive_Fila::enfileirar(F3Base_Leads_Repositorio::obter($record)):false;
            return array('ok'=>true,'simular'=>false,'persisted'=>true,'record_id'=>$record,'revisao'=>1,'efeitos'=>$effects,'pipedrive_fila'=>$action==='entregar'?($queued?'pendente':'aguardando_reconciliacao'):'nao_solicitada');
        }finally{F3Base_Pipedrive_Fila::liberar_linha($lock);}
    }
    public static function contexto_crm(array $r): array {
        $p=self::privado($r);if(!$p){throw new RuntimeException('contato_externo_cifra_indisponivel');}
        $r=self::projetar($r);$a=F3Base_Contato_Apresentacao::montar($r,false);
        // Declared origin remains explicitly labelled and does not populate the observed journey.
        $a['contato_externo']=$p;$a['atribuicao']=F3Base_Atribuicao::normalizar($p['origem_declarada']);
        $a['secoes_comunicacao']=F3Base_Contato_Apresentacao::secoes($a);$a['secoes_comunicacao']['Origem declarada do contato externo']=$p['origem_declarada']+array('Método'=>$p['metodo'],'Primeiro contato'=>$p['primeiro_contato_em']);if(F3Base_Conversas::conversa($r)){$a['secoes_comunicacao']['Conversa']=array('Triagem'=>$p['triagem']??'','Código'=>$p['codigo_origem']??'','Origem Instagram'=>wp_json_encode($p['origem_instagram']??array()),'Cobertura'=>$p['instagram']['coverage']??'Primeira mensagem observada após ativação da ponte');}
        return $a;
    }
}
