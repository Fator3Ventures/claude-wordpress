<?php
/** Remoção explícita de resíduos da migração encerrada; nunca recria configuração antiga. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Email_Limpeza {
    const OPCOES=array('f3base_c0'=>'f3base_email_novo_lead','f3base_c0_cota'=>'f3base_email_novo_lead_cota','f3base_c0_smtp_senha'=>'f3base_email_novo_lead_smtp_senha');
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-legado-limpar','Simular ou eliminar resíduos do e-mail antigo após conferir a configuração corrente',array(__CLASS__,'executar'),array('simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$')),array(),false);});
    }
    private static function bruta(string $name): array {
        global $wpdb;$v=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$name));return array('erro'=>$wpdb->last_error!=='','existe'=>$v!==null,'valor'=>$v===null?null:maybe_unserialize($v));
    }
    public static function precondicao(string $origem): string {
        $f=self::bruta('f3base_email_migracao_142');
        if($f['erro']){return 'email_migracao_leitura_indisponivel';}
        if($f['valor']==='concluida'){return '';}
        if($origem==='nova'){
            global $wpdb;
            foreach(self::OPCOES as $old=>$new){$v=self::bruta($old);if($v['erro']){return 'email_migracao_leitura_indisponivel';}if($v['existe']){return 'email_migracao_142_pendente';}}
            $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_c0')));
            if($wpdb->last_error){return 'email_migracao_leitura_indisponivel';}if(!$exists){return '';}
        }
        return 'email_migracao_142_pendente';
    }
    private static function segredo_anterior($cipher): string {
        if(!is_string($cipher)||!str_starts_with($cipher,F3Base_Segredos::PREFIXO)){return '';}
        $bytes=base64_decode(substr($cipher,strlen(F3Base_Segredos::PREFIXO)),true);if(!$bytes||strlen($bytes)<40){return '';}
        try{$v=sodium_crypto_secretbox_open(substr($bytes,24),substr($bytes,0,24),F3Base_Segredos::chave('f3base_c0_smtp_senha'));return is_string($v)?trim($v):'';}catch(Throwable $e){return '';}
    }
    private static function contem($novo,$antigo): bool {
        if(!is_array($antigo)){return F3Base_Options::equivalente($novo,$antigo);}
        if(!is_array($novo)){return false;}
        foreach($antigo as $k=>$v){if(!array_key_exists($k,$novo)||!self::contem($novo[$k],$v)){return false;}}return true;
    }
    /** Names only: activation of the retired writer is not migrated content. */
    private static function divergencias($novo,$antigo,string $path=''): array {
        if(!is_array($antigo)){return F3Base_Options::equivalente($novo,$antigo)?array():array($path?:'conteudo');}
        if(!is_array($novo)){return array($path?:'conteudo');}
        $out=array();foreach($antigo as $key=>$value){if($path===''&&$key==='ativo'){continue;}
            $name=$path.($path!==''?'.':'').substr(sanitize_key((string)$key),0,80);
            $out=array_merge($out,array_key_exists($key,$novo)?self::divergencias($novo[$key],$value,$name):array($name));
        }return array_values(array_unique($out));
    }
    /** Não retorna conteúdo, cifras, e-mail ou senha na prévia. */
    private static function fotografia(): array {
        global $wpdb;$hash=hash_init('sha256');$itens=array();$erros=array();$options=array();
        foreach(self::OPCOES as $old=>$new){
            $a=F3Base_Options::fotografia_bruta($old);$b=F3Base_Options::fotografia_bruta($new);$options[$old]=$a;
            if($a['erro']||$b['erro']){throw new RuntimeException('email_limpeza_leitura_indisponivel');}
            hash_update($hash,serialize(array($old,$a['existe'],$a['valor'],$b['existe'],$b['valor'])));
            $ok=!$a['existe'];$campos=array();
            if($a['existe']&&$b['existe']){
                if($old==='f3base_c0_smtp_senha'){
                    $ok=$a['valor']===''&&$b['valor']==='';
                    if(!$ok){$clear=self::segredo_anterior($a['valor']);$ok=is_string($clear)&&$clear!==''&&hash_equals($clear,F3Base_Segredos::abrir($new));}
                }elseif($old==='f3base_c0'){$campos=self::divergencias($b['valor'],$a['valor']);$ok=!$campos;}else{$ok=self::contem($b['valor'],$a['valor']);}
            }
            if(!$ok){$erros[]=$old.':conteudo_corrente_nao_confirmado';}
            $itens[]=array('option'=>$old,'existe'=>$a['existe'],'conteudo_conferido'=>$ok,'campos_divergentes'=>$ok?array():($campos?:array('conteudo')));
        }
        $old=$wpdb->prefix.'f3base_c0';$new=F3Base_Email_Novo_Lead::tabela();
        $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($old)))===$old;if($wpdb->last_error){throw new RuntimeException('email_limpeza_leitura_indisponivel');}
        hash_update($hash,serialize(array('tabela',$exists)));$n=0;
        if($exists){
            $columns=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$old));if($wpdb->last_error||!in_array('chave',$columns,true)){throw new RuntimeException('email_limpeza_tabela_incompativel');}
            $current=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($new)))===$new;$cursor='';
            do{$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE chave>%s ORDER BY chave LIMIT 200',$old,$cursor),ARRAY_A);if($wpdb->last_error){throw new RuntimeException('email_limpeza_leitura_indisponivel');}
                foreach($rows as $row){$cursor=$row['chave'];$n++;hash_update($hash,serialize($row));$copy=$current?$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE conta=%s AND lead_id=%s LIMIT 1',$new,$row['conta']??'',$row['lead_id']??''),ARRAY_A):null;if($wpdb->last_error){throw new RuntimeException('email_limpeza_leitura_indisponivel');}unset($row['chave'],$copy['chave']);if(!$copy||!self::contem($copy,$row)){$erros[]='tabela:conteudo_corrente_nao_confirmado';}}
            }while(count($rows)===200);
        }
        return array('ok'=>!$erros,'revisao'=>hash_final($hash),'itens'=>$itens,'tabela'=>array('nome'=>$old,'existe'=>$exists,'linhas'=>$n),'erros'=>array_values(array_unique($erros)),'options'=>$options);
    }
    public static function executar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao','applied'=>false);}
        $code=self::precondicao('existente');if($code!==''){return array('ok'=>false,'codigo'=>$code,'applied'=>false);}
        $simulate=($e['simular']??true)!==false;global $wpdb;$lock='f3core:email-limpeza:'.substr(hash('sha256',$wpdb->prefix),0,28);
        if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!==1){return array('ok'=>false,'codigo'=>'email_limpeza_ocupada','applied'=>false);}
        $changed=false;
        try{
            $f=self::fotografia();$out=$f;unset($out['options']);$out+=array('simular'=>$simulate,'applied'=>false,'persisted'=>false);
            if(!$f['ok']){return $out+array('codigo'=>'email_limpeza_conteudo_divergente');}
            if($simulate){return $out+array('codigo'=>'email_limpeza_previa');}
            if(empty($e['revisao'])||!hash_equals($f['revisao'],(string)$e['revisao'])){return array_replace($out,array('ok'=>false,'codigo'=>'conflito'));}
            // The obsolete writer no longer exists. Lock affected tables while checking again,
            // including current options so a concurrent configuration edit cannot invalidate proof.
            $locks=$wpdb->prepare('%i WRITE',$wpdb->options);
            if($f['tabela']['existe']){$locks.=$wpdb->prepare(', %i WRITE, %i READ',$f['tabela']['nome'],F3Base_Email_Novo_Lead::tabela());}
            if($wpdb->query('LOCK TABLES '.$locks)===false){throw new RuntimeException('email_limpeza_trava_indisponivel');}
            try{
                $fresh=self::fotografia();if(!$fresh['ok']||!hash_equals($f['revisao'],$fresh['revisao'])){return array_replace($out,array('ok'=>false,'codigo'=>'conflito'));}
                if($f['tabela']['existe']){if($wpdb->query($wpdb->prepare('DROP TABLE %i',$f['tabela']['nome']))===false){throw new RuntimeException('email_limpeza_tabela_nao_excluida');}$changed=true;}
                foreach($f['options'] as $name=>$v){if(!$v['existe']){continue;}$n=$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE option_name=%s AND option_value=%s',$wpdb->options,$name,maybe_serialize($v['valor'])));if($n!==1){throw new RuntimeException('email_limpeza_option_nao_excluida');}$changed=true;}
            }finally{$wpdb->query('UNLOCK TABLES');foreach(array_keys(self::OPCOES) as $name){wp_cache_delete($name,'options');}wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');}
            $after=self::fotografia();$clean=!array_filter($after['itens'],static fn($i)=>$i['existe'])&&!$after['tabela']['existe'];unset($after['options']);
            return array_replace($out,array('ok'=>$clean,'codigo'=>$clean?'email_limpeza_concluida':'email_limpeza_nao_confirmada','applied'=>$changed,'persisted'=>$clean,'releitura'=>$after));
        }catch(Throwable $x){return array('ok'=>false,'codigo'=>str_starts_with($x->getMessage(),'email_limpeza_')?$x->getMessage():'email_limpeza_indisponivel','applied'=>$changed,'persisted'=>false);}
        finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
}
