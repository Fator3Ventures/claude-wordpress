<?php
/** Public Meta SDK consumer. The Meta plugin alone verifies webhook/API evidence. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Instagram_Conversa {
    const OPTION='f3base_instagram_conversas';const STATE='f3base_instagram_conversas_estado';const CONTRACT='instagram-first-message/1.0.0';
    private static string $sdk='';
    public static function props(): array {$id=array('type'=>'string','minLength'=>1,'maxLength'=>100);return array('contas'=>array('type'=>'array','maxItems'=>30,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('connection_id','account_id','ativo','slack','pipedrive'),'properties'=>array('connection_id'=>$id,'account_id'=>array('type'=>'string','pattern'=>'^[0-9]{1,40}$'),'ativo'=>array('type'=>'boolean'),'slack'=>array('type'=>'boolean'),'pipedrive'=>array('type'=>'boolean'),'ponto'=>array('type'=>'string','maxLength'=>80)))));}
    public static function validar($v): string {$valid=rest_validate_value_from_schema($v,array('type'=>'object','additionalProperties'=>false,'properties'=>self::props()));if(is_wp_error($valid)){return $valid->get_error_message();}$seen=array();foreach($v['contas']??array() as $a){$key=$a['connection_id'].'|'.$a['account_id'];if(isset($seen[$key])){return 'Conta repetida.';}$seen[$key]=true;if(!empty($a['pipedrive'])&&empty($a['ponto'])){return 'Informe uma chave de mapa_pontos para habilitar CRM.';}}return '';}
    public static function contexto(string $c,string $a): string {return hash('sha256',$c.'|'.$a);}
    public static function mudou(string $n,$before,$after): void {
        if($n!==self::OPTION){return;}$old=is_array($before)?$before:array();$states=get_option(self::STATE,array());$new=array();
        foreach($after['contas']??array() as $a){$key=self::contexto($a['connection_id'],$a['account_id']);$previous=null;foreach($old['contas']??array() as $v){if(self::contexto($v['connection_id'],$v['account_id'])===$key){$previous=$v;break;}}$new[$key]=array('operador'=>get_current_user_id(),'ativado_em'=>!empty($previous['ativo'])&&!empty($states[$key]['ativado_em'])?$states[$key]['ativado_em']:time(),'politica'=>hash('sha256',wp_json_encode($a)));}
        F3Base_Options::atualizar_estado(self::STATE,static fn($s)=>$new);
    }
    public static function politica(string $connection,string $account): array {
        $state=get_option(self::STATE,array())[self::contexto($connection,$account)]??array();foreach(F3Base_Options::ler(self::OPTION)['contas']??array() as $p){if($p['connection_id']===$connection&&$p['account_id']===$account&&!empty($p['ativo'])&&!empty($state['operador'])&&user_can($state['operador'],'manage_options')&&user_can($state['operador'],'f3base_gerir_leads')&&hash_equals($state['politica']??'',hash('sha256',wp_json_encode($p)))){return $p+$state;}}return array();
    }
    public static function ingest(array $e): array {
        if(($e['contract']??'')!==self::CONTRACT||($e['coverage']??'')!=='oldest_available_matches_signed_webhook; lifetime_first_unverified'){return array('persisted'=>false,'codigo'=>'instagram_contrato_invalido');}
        foreach(array('connection_id','account_id','sender_id','message_id','event_id','idempotency_key','first_available_message_at','observed_at') as $k){if(!is_string($e[$k]??null)||$e[$k]===''||strlen($e[$k])>1024){return array('persisted'=>false,'codigo'=>'instagram_envelope_invalido');}}
        $key=hash('sha256',$e['connection_id'].'|'.$e['account_id'].'|'.$e['sender_id']);if(!hash_equals($key,$e['idempotency_key'])||!hash_equals($key,$e['event_id'])||!preg_match('/^[0-9]{1,40}$/D',$e['sender_id'])||$e['sender_id']===$e['account_id']){return array('persisted'=>false,'codigo'=>'instagram_identidade_invalida');}
        $p=self::politica($e['connection_id'],$e['account_id']);$stamp=strtotime($e['first_available_message_at']);if(!$p||!$stamp||$stamp<(int)$p['ativado_em']||$stamp>time()+300){return array('persisted'=>false,'codigo'=>'instagram_politica_nao_autorizada');}
        $origin=array_intersect_key(is_array($e['origin']??null)?$e['origin']:array(),array_flip(array('type','story_id','ad_id','source','ref','evidence')));foreach($origin as $k=>$v){if(!is_string($v)||strlen($v)>1024){unset($origin[$k]);}}$origin['type']=$origin['type']??'unknown';
        $private=array('nome'=>'','email'=>'','telefone'=>'','empresa'=>'','primeiro_contato_em'=>gmdate('c',$stamp),'origem_declarada'=>array('canal'=>'Instagram','parceiro'=>'origem_nao_observada'),'instagram'=>array_intersect_key($e,array_flip(array('connection_id','account_id','sender_id','message_id','event_id','coverage','observed_at'))),'origem_instagram'=>$origin,'contexto_teste'=>false);
        return F3Base_Conversas::persistir('instagram_conversa',$key,$private,$p);
    }
    public static function recibo(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}if(self::$sdk===''||!is_callable(array(self::$sdk,'deliveryReceipt'))){return array('ok'=>false,'codigo'=>'meta_sdk_indisponivel');}
        try{$remote=(self::$sdk)::deliveryReceipt($e['connection_id'],$e['account_id'],$e['event_id']);global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT record_id,captura,eliminacao_pendente,metodo FROM %i WHERE idempotencia=%s',F3Base_Leads_Repositorio::tabela(),$e['event_id']),ARRAY_A);if(!$row||$row['metodo']!=='instagram_conversa'){return array('ok'=>false,'codigo'=>'core_sem_recibo_conclusivo','meta'=>$remote);}
            $deleted=in_array($row['captura'],array('eliminado','eliminando'),true)||!empty($row['eliminacao_pendente']);$receipt=array('idempotency_key'=>$e['event_id'],'persisted'=>!$deleted,'suppressed'=>$deleted,'record_id'=>$row['record_id']);
            if(($e['simular']??true)!==false){return array('ok'=>true,'simular'=>true,'meta'=>$remote,'core'=>$receipt,'exclusao_meta_disponivel'=>false);}
            if(($remote['state']??'')==='evidence_changed'&&!$deleted){return array('ok'=>false,'codigo'=>'meta_evidencia_alterada_requer_revisao');}
            if(!current_user_can('f3base_gerir_leads')||(int)($e['revisao']??0)!==(int)$remote['revision']){return array('ok'=>false,'codigo'=>'revisao_ou_permissao_invalida');}
            return array('ok'=>true,'meta'=>(self::$sdk)::reconcileReceipt($e['connection_id'],$e['account_id'],$e['event_id'],(int)$e['revisao'],$receipt),'core'=>$receipt);
        }catch(Throwable $x){return array('ok'=>false,'codigo'=>'meta_recibo_indisponivel_ou_nao_autorizado');}
    }
    public static function iniciar(): void {
        add_filter('f3base_options_catalogo',static function($c){$c[self::OPTION]=F3Base_Conversas::catalogo_grupo(self::OPTION,'Conversas Instagram: autorização por conta',array('contas'=>array()),self::props(),array(__CLASS__,'validar'));$c[self::STATE]=array('rotulo'=>'Autorizações de conversas Instagram','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;});
        add_action('updated_option',array(__CLASS__,'mudou'),40,3);add_action('added_option',static fn($n,$v)=>self::mudou($n,null,$v),40,2);
        add_action('f3_meta_register_messaging_consumers',static function(string $sdk){if(is_callable(array($sdk,'registerConsumer'))&&$sdk::registerConsumer('site-core',self::CONTRACT,array(__CLASS__,'ingest'))){self::$sdk=$sdk;}});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('instagram-conversa-recibo','Consultar prova local/Meta; reconciliar somente recibo persistido ou supressão real, sem repetir ingestão',array(__CLASS__,'recibo'),array('connection_id'=>array('type'=>'string','maxLength'=>100),'account_id'=>array('type'=>'string','pattern'=>'^[0-9]{1,40}$'),'event_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'revisao'=>array('type'=>'integer','minimum'=>1),'simular'=>array('type'=>'boolean','default'=>true)),array('connection_id','account_id','event_id'),false);});
    }
}
