<?php
/** Recuperação da captação e alertas operacionais; nunca cria contato ou conversão. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Captacao_Operacao {
    const HOOK='f3base_captacao_monitorar';
    public static function iniciar(): void {
        add_action('init',static function(){F3Base_Recuperacao::executar(static fn()=>self::reavaliar());},96);
        add_action(self::HOOK,static function(){F3Base_Recuperacao::executar(static function(){self::reavaliar();self::acompanhar();F3Base_Fila::agendar(self::HOOK,time()+300);});});
    }
    private static function identidade(): string {
        return hash('sha256',F3BASE_PLUGIN_VERSAO.'|'.F3Base_Options::revisao('f3base_anuncios_meta').'|'.F3Base_Options::revisao('f3base_anuncios_meta_token'));
    }
    public static function reavaliar(): void {
        if(empty(F3Base_Options::ler('f3base_anuncios_meta')['ativo'])){return;}
        if(!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}
        $s=get_option('f3base_anuncios_estado',array());$key=self::identidade();
        if(($s['meta']['recuperacao_revisao']??'')===$key){return;}
        $lock=F3Base_Trava::adquirir('captacao-reavaliar',15);if(!$lock){return;}
        try {
            global $wpdb;$t=F3Base_Operacao_Intencoes::tabela();
            if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){return;}
            $old=F3Base_Operacao_Intencoes::da_tarefa('anuncios');$changed=array();
            foreach($old as $r){
                if($r['estado']!=='esgotada'||!empty($r['em_execucao'])){continue;}
                // A suspended task is an administrative pause. Only exhausted capture is superseded.
                $e=$r;$e['timestamp']=max(time(),$r['timestamp']+1);unset($e['intencao']);
                if(!F3Base_Operacao_Intencoes::registrar($e,time()+1)){return;}
                $n=$wpdb->update($t,array('estado'=>'concluida','codigo'=>'superada_por_nova_revisao','atualizada_em'=>time()),array('chave'=>$r['intencao'],'estado'=>'esgotada'));
                if($n===false){return;}$changed[]=array('anterior'=>$r['intencao'],'nova'=>F3Base_Operacao_Intencoes::chave($e),'em'=>time(),'release'=>F3BASE_PLUGIN_VERSAO);
            }
            F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($s)use($key,$changed){$s['meta']['recuperacao_revisao']=$key;$s['meta']['recuperacoes']=array_slice(array_merge($s['meta']['recuperacoes']??array(),$changed),-50);return $s;});
            if($changed){F3Base_Operacao_Intencoes::agendar(time()+1);F3Base_Fila::agendar(F3Base_Anuncios::EVENTO,time()+1);}
        } finally {F3Base_Trava::liberar($lock);}
    }
    public static function recuperada(): void {
        global $wpdb;$s=get_option('f3base_anuncios_estado',array())['meta']??array();
        if(!F3Base_Integracoes::revisoes_atuais($s,'f3base_anuncios_meta','f3base_anuncios_meta_token')||($s['estado']??'')!=='verificada'){return;}
        $n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='concluida',codigo='superada_por_consulta_completa',atualizada_em=%d WHERE tarefa='anuncios' AND estado='esgotada' AND reserva_ate<=%d",F3Base_Operacao_Intencoes::tabela(),time(),time()));
        if($n){F3Base_Fila::agendar(F3Base_Anuncios::EVENTO,time()+300);}
        self::observar();
    }
    /** Cadência observada não prova a configuração do crontab. Leitura sem reparos. */
    public static function cadencia(): array {
        global $wpdb;$t=$wpdb->prefix.'f3base_execucoes';$base=array('segundos'=>300,'fonte'=>'cadencia_solicitada_sem_amostra','amostras'=>0,'ultima_cli'=>null);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT inicio FROM %i WHERE origem='cli' AND parent_run_id='' AND core_examinado=1 AND inicio>=%d ORDER BY inicio DESC LIMIT 48",$t,time()-2*DAY_IN_SECONDS),ARRAY_A);
        if($wpdb->last_error){return $base+array('erro'=>'historico_indisponivel');}
        $times=array_values(array_unique(array_map(static fn($x)=>(int)$x['inicio'],$rows?:array())));$gaps=array();for($i=1;$i<count($times);$i++){$d=$times[$i-1]-$times[$i];if($d>=60&&$d<=21600){$gaps[]=$d;}}
        if(count($gaps)<2){return $base;}sort($gaps);$seconds=max(300,$gaps[(int)floor((count($gaps)-1)*0.5)]);return array('segundos'=>$seconds,'fonte'=>'intervalo_mediano_cli_observado','amostras'=>count($gaps),'ultima_cli'=>$times[0]);
    }
    public static function diagnostico(): array {
        $s=get_option('f3base_anuncios_estado',array())['meta']??array();$cfg=F3Base_Options::ler('f3base_anuncios_meta');$blocked=null;
        try{foreach(F3Base_Operacao_Intencoes::da_tarefa('anuncios') as $r){if(in_array($r['estado'],array('esgotada','suspensa'),true)){$blocked=$r;break;}}}catch(Throwable $e){return array('estado'=>'indisponivel','codigo'=>'intencoes_ilegivel');}
        $last=(int)($s['ultimo_sucesso_completo']??0);$scheduled=(int)($s['ultima_execucao_agendada']??0);$since=(int)($s['ativado_em']??time());$age=time()-($last?:$since);$scheduleAge=time()-($scheduled?:$since);$next=wp_next_scheduled(F3Base_Anuncios::EVENTO);
        $cadencia=self::cadencia();$tolerancia=max(300,(int)ceil($cadencia['segundos']*.2));$limiar=2*$cadencia['segundos']+$tolerancia;$transport=($s['codigo']??'')==='graph_transporte_indisponivel';$consecutive=(int)($s['falhas_transporte_consecutivas']??0);$failure=!empty($s['formularios_com_problema'])||(!empty($s['codigo'])&&!in_array($s['codigo'],array('paginando','catalogo_paginando','orcamento_execucao','coleta_em_execucao'),true));
        $failure=$failure&&(!$transport||$consecutive>=3);
        // A recent failed attempt is not a missed scheduled pass. Transport uses its own threshold.
        $delayAge=max($scheduleAge,$transport?0:$age);$delaySince=$transport?($scheduled?:$since):min($last?:$since,$scheduled?:$since);
        $state=empty($cfg['ativo'])?'desligada':($blocked?$blocked['estado']:($failure?'falha':($delayAge>=$limiar?'atrasada':'observada')));
        return array('estado'=>$state,'estado_em'=>$state==='atrasada'?$delaySince+$limiar:(int)($s['ultimo_inicio']??time()),'execucoes_esperadas_perdidas'=>max(0,(int)floor(($delayAge-$tolerancia)/$cadencia['segundos'])),'limiar_execucoes_perdidas'=>2,'falhas_transporte_consecutivas'=>$consecutive,'limiar_falhas_transporte'=>3,'tolerancia_segundos'=>$tolerancia,'ultima_execucao_agendada'=>$scheduled?:null,'ultimo_sucesso_completo'=>$last?:null,'proxima_execucao_confirmada'=>$next?:null,'idade_cobertura_segundos'=>max(0,$age),'idade_agendador_segundos'=>max(0,$scheduleAge),'ocorrencia_bloqueadora'=>$blocked,'codigo'=>$blocked['codigo']??($s['codigo']??''),'acao'=>$blocked?'Corrija a configuração/credencial ou reative a ocorrência na Operação.':($state==='atrasada'?'Confira o cron e execute uma consulta completa.':'Acompanhamento automático.'),'cadencia_segundos'=>$cadencia['segundos'],'cadencia'=>$cadencia,'limiar_atraso_segundos'=>$limiar,'formularios_com_problema'=>$s['formularios_com_problema']??array());
    }
    /** Atualiza incidentes sem enviar: uma coleta recuperada cancela a abertura pendente. */
    public static function observar(): void {
        $lock=F3Base_Trava::adquirir('captacao-alerta',45);if(!$lock){return;}
        try{self::observar_reservado(self::diagnostico());}finally{F3Base_Trava::liberar($lock);}
    }
    private static function observar_reservado(array $d): void {
        if(($d['estado']??'')==='indisponivel'){return;}
        $problem=in_array($d['estado'],array('esgotada','atrasada','falha'),true);$now=time();
        F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($state)use($problem,$d,$now){
            $a=$state['meta']['alerta']??array();$items=$a['incidentes']??array();$active=$a['ativo']??'';
            // Importa somente evidência de um aviso antigo, sem repetir sua abertura.
            if(!$items&&!empty($a['aberto'])){$active='anterior-'.(int)($a['em']??$now);$items[$active]=array('id'=>$active,'inicio'=>(int)($a['em']??$now),'fim'=>null,'causa'=>'incidente_anterior','estado_abertura'=>'anterior','abertura'=>array('estado'=>'tentada','resultado'=>is_array($a['resultado']??null)?$a['resultado']:array('estado'=>'incerto')),'fechamento'=>array('estado'=>'pendente'));}
            if($problem&&$active===''){
                $active=wp_generate_uuid4();$items[$active]=array('id'=>$active,'inicio'=>(int)($d['estado_em']??$now),'fim'=>null,'causa'=>$d['codigo']?:'passagens_esperadas_perdidas','estado_abertura'=>$d['estado'],'abertura'=>array('estado'=>'pendente'),'fechamento'=>array('estado'=>'pendente'));
            }elseif(!$problem&&$active!==''&&isset($items[$active])){
                $i=&$items[$active];$i['fim']=$now;$i['duracao_segundos']=max(0,$now-$i['inicio']);
                if(($i['abertura']['estado']??'')==='pendente'){$i['abertura']['estado']='suprimida_recuperada';}
                if(($i['abertura']['resultado']['estado']??'')!=='processado'){$i['fechamento']['estado']='suprimido_sem_abertura_confirmada';}
                unset($i);$active='';
            }
            // Histórico técnico limitado; itens ainda pendentes não são descartados.
            foreach($items as $id=>$i){if(count($items)<=50){break;}if($id!==$active&&($i['fechamento']['estado']??'')!=='pendente'){unset($items[$id]);}}
            $state['meta']['alerta']=array('schema'=>2,'ativo'=>$active,'aberto'=>$active!=='','em'=>$now,'incidentes'=>$items);return $state;
        });
    }
    public static function acompanhar(): void {
        $lock=F3Base_Trava::adquirir('captacao-alerta',45);if(!$lock){return;}
        try{
            self::observar_reservado(self::diagnostico());
            $a=get_option('f3base_anuncios_estado',array())['meta']['alerta']??array();
            foreach($a['incidentes']??array() as $id=>$i){
                $kind=empty($i['fim'])?'abertura':'fechamento';if(($i[$kind]['estado']??'')!=='pendente'){continue;}
                // Releitura imediatamente antes da reserva/envio. Nunca despacha estado antigo.
                self::observar_reservado(self::diagnostico());$now=time();$reserved=false;
                $save=F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($state)use($id,$kind,$now,&$reserved){
                    $i=$state['meta']['alerta']['incidentes'][$id]??array();
                    if(($i[$kind]['estado']??'')!=='pendente'||($kind==='abertura'&&!empty($i['fim']))||($kind==='fechamento'&&($i['abertura']['resultado']['estado']??'')!=='processado')){return null;}
                    $state['meta']['alerta']['incidentes'][$id][$kind]=array('estado'=>'tentada','envio_em'=>$now,'resultado'=>array('estado'=>'incerto'));$reserved=true;return $state;
                });if(!$reserved||empty($save['persisted'])){continue;}
                $i=get_option('f3base_anuncios_estado',array())['meta']['alerta']['incidentes'][$id];
                if($kind==='abertura'&&!in_array(self::diagnostico()['estado']??'',array('esgotada','atrasada','falha'),true)){
                    F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($state)use($id){$state['meta']['alerta']['incidentes'][$id]['abertura']['estado']='suprimida_recuperada';return $state;});self::observar_reservado(self::diagnostico());continue;
                }
                $title=($kind==='abertura'?'Captação Meta requer atenção':'Captação Meta recuperada').' — '.wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES);
                $body='Site: '.home_url('/')."\n".'Incidente: '.$id."\n".'Hora do estado: '.wp_date('d/m/Y H:i:s T',$kind==='abertura'?$i['inicio']:$i['fim'])."\n".'Hora do envio: '.wp_date('d/m/Y H:i:s T',$now)."\n".'Início: '.wp_date('d/m/Y H:i:s T',$i['inicio'])."\n".'Causa: '.$i['causa']."\n";
                if($kind==='fechamento'){$body.='Fim: '.wp_date('d/m/Y H:i:s T',$i['fim'])."\n".'Duração em segundos: '.$i['duracao_segundos']."\n";}
                $body.=F3Base_Configuracoes_Hub::url('conexoes','f3base_anuncios_meta');$result=self::enviar_alerta($title,$body);
                F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($state)use($id,$kind,$result){if(isset($state['meta']['alerta']['incidentes'][$id][$kind])){$state['meta']['alerta']['incidentes'][$id][$kind]['resultado']=$result;}return $state;});
            }
        }finally{F3Base_Trava::liberar($lock);}
    }
    private static function enviar_alerta(string $title,string $body): array {return F3Base_Alertas_Operacionais::enviar($title,$body);}
}
