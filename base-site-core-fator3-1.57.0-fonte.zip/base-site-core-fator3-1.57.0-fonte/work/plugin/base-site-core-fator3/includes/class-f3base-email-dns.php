<?php
/** Bounded DNS via the host resolver: distinguishes NXDOMAIN/NODATA from temporary failure. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
class F3Base_Email_Dns {
    private float $deadline;
    private int $queries=0;
    private array $memo=array();
    private array $existence=array();
    private bool $lastExists=true;
    public function __construct() {$this->deadline=microtime(true)+8;}
    public static function domain(string $name): bool {
        return strlen($name)<=253 && (bool)preg_match('/^(?:[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?)(?:\.[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?)*$/iD',$name);
    }
    /** Returned rows: value, ttl; NXDOMAIN/NODATA are empty, transient errors throw. */
    public function query(string $name,string $type='TXT',int $depth=0): array {
        $name=strtolower(rtrim($name,'.'));$types=array('A'=>1,'AAAA'=>28,'TXT'=>16,'MX'=>15,'PTR'=>12,'CNAME'=>5);
        if(!self::domain($name)||!isset($types[$type])||$depth>8){throw new RuntimeException('email_dns_consulta_invalida');}
        $key=$type.'|'.$name;if(isset($this->memo[$key])){return $this->memo[$key];}
        if(++$this->queries>64||microtime(true)>$this->deadline){throw new RuntimeException('email_dns_limite');}
        $cache='f3edns2_'.hash('sha256',$key);$cached=get_transient($cache);
        if(is_array($cached)&&isset($cached['rows'])){$this->existence[$name]=(bool)($cached['exists']??true);return $this->memo[$key]=$cached['rows'];}
        $packet=$this->wire($name,$types[$type]);$this->existence[$name]=$this->lastExists;$rows=array();$alias='';
        foreach($packet as $rr){if($rr['name']!==$name){continue;}if($rr['type']===$types[$type]){$rows[]=array('value'=>$rr['value'],'ttl'=>$rr['ttl']);}elseif($rr['type']===5){$alias=$rr['value'];}}
        if(!$rows&&$alias!==''){$rows=$this->query($alias,$type,$depth+1);}
        // Short cache, including negative answers, never cache a timeout/SERVFAIL.
        $ttl=$rows?min(300,min(array_column($rows,'ttl'))):30;
        if($ttl>0){set_transient($cache,array('rows'=>$rows,'exists'=>$this->existence[$name]),$ttl);}
        return $this->memo[$key]=$rows;
    }
    /** NOERROR/NODATA still means an existing domain; only authoritative NXDOMAIN permits np. */
    public function exists(string $name): bool {$name=strtolower(rtrim($name,'.'));$this->query($name,'A');return $this->existence[$name]??true;}
    private function wire(string $name,int $type): array {
        $conf=@file_get_contents('/etc/resolv.conf');preg_match_all('/^\s*nameserver\s+([^\s#]+)/m',(string)$conf,$m);
        $servers=array_slice(array_values(array_filter($m[1]??array(),static fn($x)=>filter_var($x,FILTER_VALIDATE_IP))),0,2);
        if(!$servers){throw new RuntimeException('email_dns_resolvedor_indisponivel');}
        $id=random_int(0,65535);$q='';foreach(explode('.',$name) as $label){$q.=chr(strlen($label)).$label;}$q.="\0".pack('nn',$type,1);
        $request=pack('nnnnnn',$id,0x0100,1,0,0,0).$q;
        foreach($servers as $server){
            if(microtime(true)>$this->deadline){break;}
            $addr=str_contains($server,':')?'['.$server.']':$server;
            $s=@stream_socket_client('udp://'.$addr.':53',$errno,$error,1,STREAM_CLIENT_CONNECT);
            if(!$s){continue;}stream_set_timeout($s,1,0);$data='';try{if(fwrite($s,$request)===strlen($request)){$data=(string)fread($s,65535);}}finally{fclose($s);}
            if(strlen($data)<12){continue;}$h=unpack('nid/nflags/nqd/nan/nns/nar',substr($data,0,12));
            if($h['id']!==$id||!($h['flags']&0x8000)||($h['flags']&0x7800)||$h['qd']!==1){continue;}
            if($h['flags']&0x0200){
                $s=@stream_socket_client('tcp://'.$addr.':53',$errno,$error,1,STREAM_CLIENT_CONNECT);if(!$s){continue;}stream_set_timeout($s,1,0);
                try{$bytes=pack('n',strlen($request)).$request;$off=0;while($off<strlen($bytes)){if(microtime(true)>$this->deadline){throw new RuntimeException('email_dns_limite');}$n=fwrite($s,substr($bytes,$off));if(!$n){throw new RuntimeException('email_dns_transporte');}$off+=$n;}$len=$this->read($s,2);$data=$this->read($s,unpack('n',$len)[1]);}finally{fclose($s);}
            }
            $decoded=self::decode($data,$id,$name,$type);$final=unpack('n',substr($data,2,2))[1];$this->lastExists=($final&15)!==3;return $decoded;
        }
        throw new RuntimeException('email_dns_temporario');
    }
    private function read($stream,int $length): string {
        if($length>65535){throw new RuntimeException('email_dns_resposta_invalida');}$out='';
        while(strlen($out)<$length){if(microtime(true)>$this->deadline){throw new RuntimeException('email_dns_limite');}$b=fread($stream,$length-strlen($out));if($b===false||$b===''){throw new RuntimeException('email_dns_temporario');}$out.=$b;}return $out;
    }
    private static function name(string $packet,int &$offset): string {
        $p=$offset;$jump=false;$labels=array();$seen=array();
        for($i=0;$i<128;$i++){
            if($p>=strlen($packet)||isset($seen[$p])){throw new RuntimeException('email_dns_resposta_invalida');}$seen[$p]=true;$n=ord($packet[$p++]);
            if(($n&0xc0)===0xc0){if($p>=strlen($packet)){throw new RuntimeException('email_dns_resposta_invalida');}$to=(($n&63)<<8)|ord($packet[$p++]);if(!$jump){$offset=$p;}$jump=true;$p=$to;continue;}
            if($n&0xc0||$p+$n>strlen($packet)){throw new RuntimeException('email_dns_resposta_invalida');}
            if($n===0){if(!$jump){$offset=$p;}$v=strtolower(implode('.',$labels));if(strlen($v)>253){throw new RuntimeException('email_dns_resposta_invalida');}return $v;}
            $labels[]=substr($packet,$p,$n);$p+=$n;
        }throw new RuntimeException('email_dns_resposta_invalida');
    }
    public static function decode(string $packet,int $id,string $name,int $type): array {
        if(strlen($packet)<12){throw new RuntimeException('email_dns_resposta_invalida');}$h=unpack('nid/nflags/nqd/nan/nns/nar',substr($packet,0,12));
        if($h['id']!==$id||!($h['flags']&0x8000)||($h['flags']&0x7a00)||$h['qd']!==1){throw new RuntimeException('email_dns_resposta_invalida');}
        $p=12;$question=self::name($packet,$p);if($p+4>strlen($packet)){throw new RuntimeException('email_dns_resposta_invalida');}$q=unpack('ntype/nclass',substr($packet,$p,4));$p+=4;
        if($question!==$name||$q['type']!==$type||$q['class']!==1){throw new RuntimeException('email_dns_resposta_invalida');}
        $rcode=$h['flags']&15;if($rcode===3){return array();}if($rcode!==0){throw new RuntimeException('email_dns_temporario');}
        if($h['an']>256){throw new RuntimeException('email_dns_resposta_excedida');}$out=array();
        for($i=0;$i<$h['an'];$i++){
            $owner=self::name($packet,$p);if($p+10>strlen($packet)){throw new RuntimeException('email_dns_resposta_invalida');}$r=unpack('ntype/nclass/Nttl/nlen',substr($packet,$p,10));$p+=10;$end=$p+$r['len'];if($end>strlen($packet)){throw new RuntimeException('email_dns_resposta_invalida');}$v=null;
            if($r['class']===1){
                if($r['type']===16){$v='';$x=$p;while($x<$end){$n=ord($packet[$x++]);if($x+$n>$end){throw new RuntimeException('email_dns_resposta_invalida');}$v.=substr($packet,$x,$n);$x+=$n;}}
                elseif($r['type']===1&&$r['len']===4||$r['type']===28&&$r['len']===16){$v=inet_ntop(substr($packet,$p,$r['len']));}
                elseif(in_array($r['type'],array(5,12,15),true)){$x=$p+($r['type']===15?2:0);$v=self::name($packet,$x);if($x>$end){throw new RuntimeException('email_dns_resposta_invalida');}}
                if($v!==null){$out[]=array('name'=>$owner,'type'=>$r['type'],'ttl'=>$r['ttl'],'value'=>$v);}
            }$p=$end;
        }return $out;
    }
}
