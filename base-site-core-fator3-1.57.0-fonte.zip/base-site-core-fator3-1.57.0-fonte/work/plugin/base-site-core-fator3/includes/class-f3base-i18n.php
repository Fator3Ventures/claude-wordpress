<?php
/**
 * Proteção contra a carga antecipada de tradução do domínio `f3base`.
 *
 * O DEFEITO MEDIDO (1.48.0, WordPress 7.1.3): com o Fator3 MCP LinkedIn ativo,
 * `plugins_loaded:20` dispara `f3_linkedin_register_consumers`; o registrador do
 * Core lê a coleção LinkedIn, que monta o catálogo de options, e o catálogo
 * chama `__()` dezenas de vezes. Desde a 6.7 o núcleo registra o diretório do
 * plugin como caminho do Text Domain e acusa `_load_textdomain_just_in_time`
 * para toda tradução pedida antes de `after_setup_theme`: o aviso aparecia em
 * TODA requisição (público, REST, painel, cron). Pior: o catálogo montado nesse
 * instante ficava memoizado, e filtros `f3base_options_catalogo` registrados
 * depois (tema, `init`) eram ignorados até o fim da requisição.
 *
 * A SAÍDA: o pacote é monolíngue; antes de `after_setup_theme` a montagem usa
 * uma tradução nula temporária, só para o domínio do pacote, e o resultado não
 * é memoizado como definitivo. Depois do ponto em que o núcleo permite tradução,
 * a montagem normal substitui a antecipada.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Utilitário interno; sem estado persistido. */
final class F3Base_I18n {

	/** Verdadeiro enquanto o núcleo ainda acusaria a carga de tradução do domínio. */
	public static function antes_das_traducoes(): bool {
		return ! did_action( 'after_setup_theme' ) && ! doing_action( 'after_setup_theme' );
	}

	/**
	 * Executa `$fn` sem disparar a carga antecipada de tradução de `f3base`.
	 *
	 * Fora da janela antecipada, apenas executa. Dentro dela, instala uma tradução
	 * nula para o domínio, executa e remove exatamente o objeto instalado — se
	 * algo legítimo carregou o domínio no meio, a carga dele é preservada.
	 *
	 * @template T
	 * @param callable():T $fn Montagem que chama `__()` com o domínio do pacote.
	 * @return T
	 */
	public static function sem_carga_antecipada( callable $fn ) {
		global $l10n;
		if ( ! self::antes_das_traducoes() || ! class_exists( 'NOOP_Translations', false ) ) {
			return $fn();
		}
		$dominio = defined( 'F3BASE_TEXT_DOMAIN' ) ? F3BASE_TEXT_DOMAIN : 'f3base';
		if ( ! is_array( $l10n ) ) {
			$l10n = array();
		}
		if ( isset( $l10n[ $dominio ] ) ) {
			return $fn();
		}
		$nula               = new NOOP_Translations();
		$l10n[ $dominio ] = $nula;
		try {
			return $fn();
		} finally {
			if ( isset( $l10n[ $dominio ] ) && $l10n[ $dominio ] === $nula ) {
				unset( $l10n[ $dominio ] );
			}
		}
	}
}
