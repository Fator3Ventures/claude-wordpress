<?php
/** Atribuições manuais separadas das sessões observadas. Auditoria cifrada no contato. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Contatos_Sessoes {
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_contato_sessoes';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        dbDelta('CREATE TABLE '.self::tabela()." (
            sessao char(32) NOT NULL,
            record_id char(32) NOT NULL,
            classe varchar(16) NOT NULL,
            vinculado_em bigint(20) NOT NULL,
            PRIMARY KEY  (sessao),
            KEY contato (record_id)
        ) ENGINE=InnoDB $cc;");
        return !$wpdb->last_error && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))===self::tabela();
    }
    public static function propriedades(): array {return array(
        'record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),
        'sessoes'=>array('type'=>'array','minItems'=>1,'maxItems'=>20,'uniqueItems'=>true,'items'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),
        'acao'=>array('type'=>'string','enum'=>array('vincular','desvincular'),'default'=>'vincular'),
        'simular'=>array('type'=>'boolean','default'=>true),
        'revisao'=>array('type'=>'integer','minimum'=>1),
        'decisor'=>array('type'=>'string','minLength'=>1,'maxLength'=>200,'description'=>'Quem decidiu a atribuição. O usuário executor é registrado separadamente pelo servidor.'),
        'motivo'=>array('type'=>'string','minLength'=>1,'maxLength'=>300));}
    public static function registrar_ability(): void {
        F3Base_Servicos::ability('contato-sessao-vincular','Vincular ou desfazer atribuição manual; simula por padrão, exige revisão para gravar e não converte',array(__CLASS__,'executar'),self::propriedades(),array('record_id','sessoes','decisor','motivo'),false,'manage_options',array(F3Base_Contatos_Externos::class,'pode'));
    }
    private static function vivo(?array $r): bool {return $r && !$r['lixeira'] && !$r['eliminacao_pendente'] && !in_array($r['captura'],array('eliminado','eliminando'),true);}
    private static function auditoria(array $r): ?array {
        if(empty($r['dados']['sessoes_manuais_cifradas'])){return array('historico'=>array(),'ativas'=>array());}
        return F3Base_Contato_Comunicacao::abrir($r['dados']['sessoes_manuais_cifradas']);
    }
    public static function executar(array $e): array {
        if(!F3Base_Contatos_Externos::pode()){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>self::propriedades(),'required'=>array('record_id','sessoes','decisor','motivo'));
        if(is_wp_error(rest_validate_value_from_schema($e,$schema))){return array('ok'=>false,'codigo'=>'vinculo_entrada_invalida');}
        foreach(array('decisor','motivo') as $k){if(trim($e[$k])===''||preg_match('/[\x00-\x1f\x7f<>]/u',$e[$k])){return array('ok'=>false,'codigo'=>'vinculo_entrada_invalida');}}
        $sim=($e['simular']??true)!==false;$action=$e['acao']??'vincular';$id=$e['record_id'];$transaction=false;$db=null;
        global $wpdb;$t=F3Base_Leads_Repositorio::tabela();
        try{
            if(!$sim){
                $engines=$wpdb->get_col($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN (%s,%s)',$t,self::tabela()));
                if(count($engines)!==2||array_filter($engines,static fn($v)=>strtolower($v)!=='innodb')){throw new RuntimeException('vinculo_transacao_indisponivel');}
                // Use one captured mysqli connection: wpdb must not reconnect/replay a write outside the transaction.
                $db=$wpdb->dbh;if(!($db instanceof mysqli)||!mysqli_begin_transaction($db)){throw new RuntimeException('vinculo_transacao_indisponivel');}$transaction=true;
            }
            $read=static function(string $sql)use($db,$wpdb): array {if(!$db){$rows=$wpdb->get_results($sql,ARRAY_A);if($wpdb->last_error){throw new RuntimeException('vinculo_leitura_falhou');}return $rows;} $result=mysqli_query($db,$sql);if(!($result instanceof mysqli_result)){throw new RuntimeException('vinculo_leitura_falhou');}$rows=mysqli_fetch_all($result,MYSQLI_ASSOC);mysqli_free_result($result);return $rows;};
            $write=static function(string $sql)use($db): int {if(!mysqli_query($db,$sql)){throw new RuntimeException('vinculo_persistencia_falhou');}return mysqli_affected_rows($db);};
            $r=$read($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s'.(!$sim?' FOR UPDATE':''),$t,$id))[0]??null;
            if($r){foreach(array('dados','entrega','anexos') as $k){$r[$k]=json_decode((string)$r[$k],true)?:array();}}if(!self::vivo($r)){throw new RuntimeException('registro_indisponivel');}
            $rev=(int)$r['revisao'];if(!$sim&&($e['revisao']??0)!==$rev){return array('ok'=>false,'codigo'=>'conflito','revisao'=>$rev);}
            $audit=self::auditoria($r);if(!$audit){throw new RuntimeException('vinculo_auditoria_indisponivel');}
            $changes=array();$classes=array();
            foreach($e['sessoes'] as $session){
                $old=$read($wpdb->prepare('SELECT * FROM %i WHERE sessao=%s',self::tabela(),$session))[0]??null;
                if($old&&$old['record_id']!==$id){throw new RuntimeException('sessao_vinculada_a_outro_contato');}
                if($action==='vincular'&&!$old){
                    $found=array_column($read($wpdb->prepare('SELECT DISTINCT classe_trafego FROM %i WHERE sessao=%s LIMIT 3',F3Base_Analise::tabela(),$session)),'classe_trafego');
                    if(count($found)!==1){throw new RuntimeException($found?'vinculo_sessao_ambigua':'vinculo_sessao_sem_eventos_retidos');}
                    if($found[0]!==$r['classe_trafego']){throw new RuntimeException('vinculo_segmento_divergente');}
                    $classes[$session]=$found[0];$changes[]=$session;
                }elseif($action==='desvincular'&&$old){$classes[$session]=$old['classe'];$changes[]=$session;}
            }
            if(count($audit['historico'])>=500&&$changes){throw new RuntimeException('vinculo_limite_auditoria');}
            if($action==='vincular'&&count($audit['ativas'])+count($changes)>100){throw new RuntimeException('vinculo_limite_sessoes');}
            $out=array('ok'=>true,'simular'=>$sim,'persisted'=>false,'record_id'=>$id,'tipo_atribuicao'=>'atribuicao_manual','acao'=>$action,'sessoes'=>$e['sessoes'],'alteracoes'=>$changes,'revisao'=>$rev,'conversoes'=>false);
            if($sim||!$changes){return $out;}
            $at=time();$event=array('acao'=>$action,'sessoes'=>$changes,'operador_id'=>get_current_user_id(),'decisor'=>trim($e['decisor']),'motivo'=>trim($e['motivo']),'em'=>gmdate('c',$at));
            foreach($changes as $session){
                if($action==='vincular'){
                    $n=$write($wpdb->prepare('INSERT INTO %i (sessao,record_id,classe,vinculado_em) VALUES (%s,%s,%s,%d)',self::tabela(),$session,$id,$classes[$session],$at));
                    $audit['ativas'][$session]=$event;
                }else{$n=$write($wpdb->prepare('DELETE FROM %i WHERE sessao=%s AND record_id=%s',self::tabela(),$session,$id));unset($audit['ativas'][$session]);}
                if($n!==1){throw new RuntimeException('vinculo_conflito_concorrente');}
            }
            $audit['historico'][]=$event;$d=$r['dados'];$d['sessoes_manuais_cifradas']=F3Base_Contato_Comunicacao::cifrar($audit);
            if($write($wpdb->prepare('UPDATE %i SET dados=%s,revisao=%d,atualizado_em=%s WHERE record_id=%s AND revisao=%d AND eliminacao_pendente=0 AND lixeira=0',$t,wp_json_encode($d),$rev+1,gmdate('Y-m-d H:i:s'),$id,$rev))!==1){throw new RuntimeException('vinculo_conflito_concorrente');}
            try{$committed=mysqli_commit($db);}catch(Throwable $commitError){throw new RuntimeException('vinculo_commit_indeterminado');}if(!$committed){throw new RuntimeException('vinculo_commit_indeterminado');}$transaction=false;
            $out['persisted']=true;$out['revisao']=$rev+1;$out['auditoria']=array('operador_id'=>$event['operador_id'],'em'=>$event['em'],'consultar'=>'f3base/lead-jornada-ler');return $out;
        }catch(Throwable $x){return array('ok'=>false,'codigo'=>preg_match('/^(vinculo_[a-z_]+|registro_indisponivel|sessao_vinculada_a_outro_contato)$/D',$x->getMessage())?$x->getMessage():'vinculo_indisponivel','persisted'=>$x->getMessage()==='vinculo_commit_indeterminado'?null:false);}
        finally{if($transaction){try{mysqli_rollback($db);}catch(Throwable $rollbackError){/* Original failure is returned; never reconnect. */}}}
    }
    public static function eliminar(string $record): bool {global $wpdb;return $wpdb->delete(self::tabela(),array('record_id'=>$record))!==false;}
    public static function contato(array $r,bool $eventos=false,int $pagina=1): array {
        if(!current_user_can('f3base_ler_leads')||!self::vivo($r)){return array();}
        $a=self::auditoria($r);if(!$a){return array('ok'=>false,'codigo'=>'vinculo_auditoria_indisponivel');}
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT sessao,classe,vinculado_em FROM %i WHERE record_id=%s ORDER BY vinculado_em,sessao',self::tabela(),$r['record_id']),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'vinculo_leitura_falhou');}
        $all=count($rows);$pagina=max(1,$pagina);$rows=array_slice($rows,($pagina-1)*10,10);
        foreach($rows as &$row){$row['tipo_atribuicao']='atribuicao_manual';$row['decisao']=$a['ativas'][$row['sessao']]??null;
            if($eventos){$row['observacoes']=self::eventos($row['sessao'],$row['classe'],strtotime($r['criado_em'].' UTC'));}}
        unset($row);return array('ok'=>true,'tipo_atribuicao'=>'atribuicao_manual','sessoes'=>$rows,'total_sessoes'=>$all,'pagina'=>$pagina,'proxima_pagina'=>$pagina*10<$all?$pagina+1:null,'auditoria'=>$a['historico'],'aviso'=>'Decisão humana; não altera origem observada, consentimento nem conversões. Eventos posteriores ao primeiro contato estão identificados.');
    }
    private static function eventos(string $session,string $class,int $contactAt): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT criado_em,tipo,caminho,navegacao,detalhe,atribuicao,decisao_ref FROM %i WHERE sessao=%s AND classe_trafego=%s ORDER BY criado_em,id LIMIT 501',F3Base_Analise::tabela(),$session,$class),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'vinculo_eventos_indisponiveis');}
        $more=count($rows)>500;$out=array();$omitted=0;
        foreach(array_slice($rows,0,500) as $row){
            // A manual identity does not restore data whose measurement permission was revoked.
            if(!empty($row['decisao_ref'])){$decision=$wpdb->get_row($wpdb->prepare('SELECT medicao,revogada FROM %i WHERE ref=%s',$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA,$row['decisao_ref']),ARRAY_A);if($wpdb->last_error||($decision&&(!$decision['medicao']||$decision['revogada']))){++$omitted;continue;}}
            unset($row['decisao_ref']);$row['atribuicao_observada']=F3Base_Contato_Apresentacao::atribuicao(json_decode($row['atribuicao'],true)?:array(),false);unset($row['atribuicao']);$row['em']=gmdate('c',(int)$row['criado_em']);$row['posterior_ao_contato']=(int)$row['criado_em']>$contactAt;$out[]=$row;
        }
        return array('ok'=>true,'eventos'=>$out,'truncado'=>$more,'omitidos_por_consentimento'=>$omitted,'detalhamento'=>'f3base/sessao-detalhar','retencao'=>'Somente eventos ainda retidos; nenhuma reconstrução retroativa.');
    }
    public static function sessao(string $session): array {
        if(!current_user_can('f3base_ler_leads')){return array();}
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT v.record_id,v.classe,v.vinculado_em FROM %i v INNER JOIN %i l ON l.record_id=v.record_id WHERE v.sessao=%s AND l.lixeira=0 AND l.eliminacao_pendente=0 AND l.captura NOT IN (%s,%s)',self::tabela(),F3Base_Leads_Repositorio::tabela(),$session,'eliminado','eliminando'),ARRAY_A);
        foreach($rows as &$row){$row['tipo_atribuicao']='atribuicao_manual';$r=F3Base_Leads_Repositorio::obter($row['record_id']);$a=$r?self::auditoria($r):null;$row['decisao']=$a['ativas'][$session]??null;}unset($row);return $rows;
    }
    public static function filtro_sql(string $tipo): string {
        if($tipo==='todas'){return '';}
        global $wpdb;return $wpdb->prepare(' AND sessao '.($tipo==='observada'?'NOT ':'').'IN (SELECT v.sessao FROM %i v INNER JOIN %i l ON l.record_id=v.record_id WHERE l.lixeira=0 AND l.eliminacao_pendente=0 AND l.captura NOT IN (%s,%s))',self::tabela(),F3Base_Leads_Repositorio::tabela(),'eliminado','eliminando');
    }
}
