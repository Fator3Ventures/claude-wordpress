<?php
/** Reaquecimento limitado de HTML público recente; não executa JavaScript nem cria audiência. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Cache_Reaquecimento {
 const OPTION='f3base_cache_reaquecimento';const ESTADO='f3base_cache_reaquecimento_estado';const EVENTO='f3base_cache_reaquecer';const UA='F3Base-Reaquecimento/1.46.1';
 public static function catalogo(array $c): array {
  $props=array('ativo'=>array('type'=>'boolean'),'dias_visita'=>array('type'=>'integer','minimum'=>1,'maximum'=>30),'paginas_por_hora'=>array('type'=>'integer','minimum'=>1,'maximum'=>100));
  $c[self::OPTION]=array('rotulo'=>'Reaquecer páginas com visitas recentes','descricao'=>'Após vencer a cópia, solicita novamente páginas públicas visitadas por pessoas. Usa uma requisição anônima, sem cookies nem eventos de medição. Requer WP Super Cache e cron funcionando; não liga o preload nem altera o prazo do cache.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'grupo','padrao'=>array('ativo'=>false,'dias_visita'=>7,'paginas_por_hora'=>20),'subcampos'=>array('ativo'=>array('tipo'=>'booleano','rotulo'=>'Ativar reaquecimento','descricao'=>'Desligado por padrão. Ligado, gera carga limitada no próprio servidor e renova somente cópias vencidas.'),'dias_visita'=>array('tipo'=>'inteiro','rotulo'=>'Considerar visitas dos últimos dias','minimo'=>1,'maximo'=>30,'descricao'=>'De 1 a 30 dias; padrão 7. Exclui testes e automação identificada. Usa somente o histórico disponível e autorizado.'),'paginas_por_hora'=>array('tipo'=>'inteiro','rotulo'=>'Máximo de páginas por hora','minimo'=>1,'maximo'=>100,'descricao'=>'De 1 a 100; padrão 20. Limite em janela móvel de uma hora, incluindo falhas. Cada passagem faz até 3 requisições.')),'schema_config'=>array('type'=>'object','additionalProperties'=>false,'properties'=>$props),'sanitiza'=>array(F3Base_Evolucao::class,'sanitizar'),'recusa'=>static function($v,$d)use($props){$e=F3Base_Evolucao::recusar($v,$d);if($e){return $e;}return is_wp_error(rest_validate_value_from_schema($v,array('type'=>'object','additionalProperties'=>false,'properties'=>$props)))?'Configuração de reaquecimento inválida.':'';});
  $c[self::ESTADO]=array('rotulo'=>'Estado do reaquecimento','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;
 }
 public static function iniciar(): void {
  add_action(self::EVENTO,array(__CLASS__,'processar'));
  add_action('init',static function(){if(!empty(F3Base_Options::ler(self::OPTION)['ativo'])&&!wp_next_scheduled(self::EVENTO)){F3Base_Fila::agendar(self::EVENTO,time()+60);}},60);
  add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('cache-reaquecimento-ler','Ler configuração e resultados do reaquecimento, sem executar requisições',array(__CLASS__,'consultar'),array()));
 }
 public static function consultar(array $e=array()): array {if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}return array('ok'=>true,'configuracao'=>F3Base_Options::ler(self::OPTION),'estado'=>F3Base_Options::ler(self::ESTADO),'proxima_execucao'=>wp_next_scheduled(self::EVENTO)?:null,'somente_leitura'=>true);}
 public static function candidatos(int $dias): array {
  global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT caminho,MAX(post_id) AS post_id,MAX(criado_em) AS visita_em FROM %i WHERE tipo='pagina' AND classe_trafego='nao_marcado' AND automacao='nao_identificada' AND criado_em>=%d GROUP BY caminho ORDER BY visita_em DESC LIMIT 1000",F3Base_Analise::tabela(),time()-max(1,min(30,$dias))*DAY_IN_SECONDS),ARRAY_A);$out=array();
  foreach($rows??array() as $r){$path=$r['caminho'];if(!str_starts_with($path,'/')||str_starts_with($path,'//')||preg_match('~[?#\\]|(?:^|/)\.\.(?:/|$)|%2e|%2f|%5c~i',$path)||F3Base_Audiencia::caminho_tecnico($path)){continue;}
   $post=(int)$r['post_id']?get_post((int)$r['post_id']):null;$home=(string)wp_parse_url(home_url('/'),PHP_URL_PATH);
   if($path!==$home&&(!$post||!is_post_publicly_viewable($post)||$post->post_password!==''||(string)wp_parse_url(get_permalink($post),PHP_URL_PATH)!==$path)){continue;}
   $out[]=array('caminho'=>$path,'visita_em'=>(int)$r['visita_em']);
  }return $out;
 }
 /** Only public anonymous variants of this canonical path, never PHP evaluation. */
 public static function artefatos(string $path): array {
  $base=F3Base_Publicacao_Sonda::base_cache();if(!$base){return array();}
  $home=wp_parse_url(home_url('/'));$origin=$home['scheme'].'://'.$home['host'].(isset($home['port'])?':'.$home['port']:'');
  $relative=str_starts_with($path,$home['path']??'/')?substr($path,strlen($home['path']??'/')):ltrim($path,'/');
  $dir=realpath(function_exists('wpsc_supercache_dir_for_url')?wpsc_supercache_dir_for_url($origin.$path):$base.'/'.trim($relative,'/'));
  if(!$dir||($dir!==$base&&!str_starts_with($dir,$base.DIRECTORY_SEPARATOR))){return array();}$out=array();
  $snapshot=static function(string $file,int $max): array {
   clearstatcache(true,$file);if(is_link($file)||!is_file($file)||!is_readable($file)||filesize($file)>$max){return array();}
   return array('arquivo'=>$file,'mtime'=>(int)filemtime($file),'arquivo_sha256'=>(string)hash_file('sha256',$file));
  };
  $name=($home['scheme']??'')==='https'?'index-https.html':'index.html';$html=$snapshot($dir.'/'.$name,2097152);
  if($html){$html['sha256']=$html['arquivo_sha256'];$html['partes']=array($html);$gzip=$snapshot($dir.'/'.$name.'.gz',2097152);if($gzip){$html['partes'][]=$gzip;}$out[]=$html;}
  $host=$home['host'].(isset($home['port'])?':'.$home['port']:'');$ports=array_unique(array((int)($home['port']??(($home['scheme']??'')==='https'?443:80)),(int)($_SERVER['SERVER_PORT']??0)));$keys=array();
  foreach($ports as $port){if($port>0&&$port<=65535){foreach(array('','gzip') as $encoding){$keys[]=$host.$port.$path.$encoding.'-text/html';}}}
  $seen=0;foreach(new DirectoryIterator($dir) as $entry){if(++$seen>128){break;}$name=$entry->getFilename();
   if(!preg_match('/^wp-cache-[a-f0-9]{32}\.php$/D',$name)){continue;}$body=$snapshot($dir.'/'.$name,2097167);$meta=$snapshot($dir.'/meta-'.$name,65536);if(!$body||!$meta){continue;}
   $text=file_get_contents($meta['arquivo']);if(!str_starts_with($text,'<?php die(); ?>')){continue;}$m=json_decode(substr($text,15),true);
   if(!is_array($m)||($m['uri']??'')!==$host.$path||!in_array($m['key']??null,$keys,true)||$name!=='wp-cache-'.md5($m['key']).'.php'||!empty($m['dynamic'])){continue;}
   $private=false;$encoding='';foreach($m['headers']??array() as $key=>$value){if(!is_string($value)){$private=true;break;}if(preg_match('/^(?:Set-Cookie|Cache-Control:.*(?:private|no-store))/i',$value)){$private=true;break;}if(strtolower((string)$key)==='content-encoding'){$encoding=strtolower(trim(substr($value,strpos($value,':')+1)));}}
   if($private||!in_array($encoding,array('','gzip'),true)){continue;}$payload=file_get_contents($body['arquivo']);if(!str_starts_with($payload,'<?php die(); ?>')){continue;}$payload=substr($payload,15);
   if($encoding==='gzip'){$payload=@gzdecode($payload,2097152);}if(!is_string($payload)||strlen($payload)>2097152){continue;}
   $body['sha256']=hash('sha256',$payload);$body['partes']=array($body,$meta);$body['formato']='wp-cache-cabecalhos';$out[]=$body;
  }
  usort($out,static fn($a,$b)=>$b['mtime']<=>$a['mtime']);return $out;
 }
 public static function artefato(string $path): array {return self::artefatos($path)[0]??array();}
 /** Revalidate each recorded body/metadata pair before removing expired variants. */
 public static function remover_vencidos(array $artefatos,int $ttl,int $now): bool {
  $parts=array();foreach($artefatos as $a){if($a['mtime']+$ttl>=$now){continue;}foreach($a['partes'] as $p){if($p['mtime']+$ttl>=$now){return false;}$parts[$p['arquivo']]=$p;}}
  foreach($parts as $p){clearstatcache(true,$p['arquivo']);if(is_link($p['arquivo'])||!is_file($p['arquivo'])||(int)filemtime($p['arquivo'])!==$p['mtime']||!hash_equals($p['arquivo_sha256'],(string)hash_file('sha256',$p['arquivo']))){return false;}}
  // Metadata first: a partially removed legacy pair must never remain serveable.
  uksort($parts,static fn($a,$b)=>(int)str_starts_with(basename($b),'meta-')<=>(int)str_starts_with(basename($a),'meta-'));
  foreach($parts as $p){if(!@unlink($p['arquivo'])){return false;}}return true;
 }
 public static function processar(): array {
  $cfg=F3Base_Options::ler(self::OPTION);if(empty($cfg['ativo'])){return array('ok'=>true,'codigo'=>'desligado');}
  F3Base_Fila::agendar(self::EVENTO,time()+60);
  if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('cache-reaquecimento',45);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>true,'codigo'=>'reserva_ocupada');}
  try{
   global $cache_max_time;$profile=F3Base_Cache_Pagina::perfil();$ttl=is_numeric($cache_max_time??null)?(int)$cache_max_time:0;
   if(!$profile['ativo']||$profile['provedor']!=='wp-super-cache'||!in_array($profile['modo'],array('simple','expert','wp-cache-cabecalhos'),true)||$ttl<60){F3Base_Options::atualizar_estado(self::ESTADO,static function($s)use($profile){unset($s['ultima_passagem']);$s['ultima_execucao']=array('em'=>time(),'codigo'=>'cache_nao_compativel','modo'=>$profile['modo']);return $s;});return array('ok'=>true,'codigo'=>'cache_nao_compativel');}
   $state=F3Base_Options::ler(self::ESTADO);unset($state['ultima_passagem']);$now=time();$state['reservas']=array_values(array_filter($state['reservas']??array(),static fn($v)=>(int)$v>$now-HOUR_IN_SECONDS));$capacity=max(0,(int)$cfg['paginas_por_hora']-count($state['reservas']));$n=0;$start=microtime(true);
   $candidates=self::candidatos((int)$cfg['dias_visita']);$last=array();foreach($state['resultados']??array() as $v){$last[$v['caminho']]=$v['em'];}usort($candidates,static fn($a,$b)=>($last[$a['caminho']]??0)<=>($last[$b['caminho']]??0));
   foreach($candidates as $row){if($n>=min(3,$capacity)||microtime(true)-$start>=20){break;}$path=$row['caminho'];if(($last[$path]??0)>$now-300){continue;}$beforeAll=self::artefatos($path);$before=$beforeAll[0]??array();if($before&&$before['mtime']+$ttl>=$now){continue;}
    // Reserve budget durably before HTTP; crashes consume the slot, never duplicate the hour budget.
    $state['reservas'][]=time();$saved=F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$state);if(empty($saved['persisted'])){return array('ok'=>false,'codigo'=>'reserva_nao_persistida');}
    $purged=self::remover_vencidos($beforeAll,$ttl,$now);
    $t=microtime(true);$url=home_url('/');$origin=wp_parse_url($url);$url=$origin['scheme'].'://'.$origin['host'].(isset($origin['port'])?':'.$origin['port']:'').$path;
    $r=$purged?wp_safe_remote_get($url,array('timeout'=>8,'redirection'=>0,'cookies'=>array(),'user-agent'=>self::UA,'headers'=>array('Accept'=>'text/html','Accept-Encoding'=>'identity'),'limit_response_size'=>2097152)):new WP_Error('copia_vencida_nao_removida');
    $ms=(int)round((microtime(true)-$t)*1000);$body=is_wp_error($r)?'':wp_remote_retrieve_body($r);$http=is_wp_error($r)?0:wp_remote_retrieve_response_code($r);$after=array();
    foreach(self::artefatos($path) as $candidate){if($candidate['sha256']!==''&&hash_equals($candidate['sha256'],hash('sha256',$body))){$after=$candidate;break;}}$match=(bool)$after;
    $result=$http===200&&$match?($after['mtime']>($before['mtime']??0)?'copia_gerada':'copia_servida'):($http===200?'copia_nao_confirmada':'falha_http');
    $state['resultados'][]=array('caminho'=>$path,'em'=>time(),'http'=>$http,'duracao_ms'=>$ms,'resultado'=>$result,'gerado_em'=>$match?$after['mtime']:null,'anonima'=>true);$state['resultados']=array_slice($state['resultados'],-100);$state['atualizado_em']=time();$state['ttl_observado']=$ttl;
    F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$state);++$n;
   }
   $state['ultima_execucao']=array('em'=>time(),'codigo'=>'reaquecimento_concluido','modo'=>$profile['modo'],'requisicoes'=>$n);F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$state);
   return array('ok'=>true,'codigo'=>'reaquecimento_concluido','requisicoes'=>$n,'limite_hora'=>(int)$cfg['paginas_por_hora']);
  }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
 }
}
