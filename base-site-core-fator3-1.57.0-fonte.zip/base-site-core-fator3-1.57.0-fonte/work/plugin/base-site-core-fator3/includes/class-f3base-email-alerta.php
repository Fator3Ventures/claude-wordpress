<?php
/** One opening and recovery intent per mailbox incident, without message bodies. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Alerta {
    const HOOK='f3base_email_site_saude';
    public static function iniciar(): void {
        add_action('init',static function(){if(!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}},92);
        add_action(self::HOOK,static function(){try{self::observar();F3Base_Email_Site::continuacoes();}finally{F3Base_Fila::agendar(self::HOOK,time()+300);}});
    }
    public static function observar(): void {
        if(!F3Base_Pipedrive_Fila::travar_linha('email-alerta')){return;}
        try{
            $health=F3Base_Email_Site::saude();if($health['estado']==='desligada'){return;}$state=get_option(F3Base_Email_Site_Config::STATE,array());$alarm=$state['alarme']??array();$bad=in_array($health['estado'],array('falha','atrasada'),true);
            if($bad&&!empty($alarm['aberto'])){return;}if(!$bad&&empty($alarm['aberto'])){return;}
            $closing=!$bad;$title=$closing?'Captação de e-mail recuperada':'Captação de e-mail requer atenção';$type=$closing?'recuperacao':'abertura';
            $alarm=$closing?array_replace($alarm,array('aberto'=>false)):array('aberto'=>true,'incidente'=>wp_generate_uuid4(),'inicio'=>time());$alarm[$type]=array('estado'=>'reservado','em'=>time());
            F3Base_Email_Site::estado(array('alarme'=>$alarm)); // Checkpoint precedes any network effect; uncertain results do not retry.
            $test=!empty(F3Base_Email_Site::cfg()['homologacao']);$cfg=F3Base_Options::ler('f3base_avisos');$token=F3Base_Segredos::abrir('f3base_slack_bot_token');$text=($test?'[TESTE] ':'').$title.' — '.get_bloginfo('name')."\nEstado: ".$health['estado']."\nCódigo: ".($health['codigo']?:'sem_erro')."\n".F3Base_Configuracoes_Hub::url('conexoes','f3base_email_site');$result=array('ok'=>false,'estado'=>'sem_slack');
            if($test&&F3Base_Testes::politica('slack','teste')==='suprimir'){$result=array('ok'=>true,'estado'=>'suprimido_teste');}
            elseif(($cfg['slack_transporte']??'webhook')==='webhook'&&F3Base_Avisos::url_valida(F3Base_Segredos::abrir(F3Base_Avisos::SEGREDO))){try{$r=wp_remote_post(F3Base_Segredos::abrir(F3Base_Avisos::SEGREDO),array('timeout'=>8,'redirection'=>0,'sslverify'=>true,'headers'=>array('Content-Type'=>'application/json'),'body'=>wp_json_encode(array('text'=>$text,'unfurl_links'=>false,'unfurl_media'=>false)),'limit_response_size'=>2048));$ok=!is_wp_error($r)&&wp_remote_retrieve_response_code($r)===200&&trim(wp_remote_retrieve_body($r))==='ok';$result=array('ok'=>$ok,'estado'=>$ok?'aceito_slack':'incerto');}catch(Throwable $x){$result=array('ok'=>false,'estado'=>'incerto');}}
            elseif(($cfg['slack_transporte']??'webhook')==='app'&&$token!==''&&!empty($cfg['slack_canal_id'])){try{$r=F3Base_Slack::api('chat.postMessage',$token,array('channel'=>$cfg['slack_canal_id'],'text'=>$text,'unfurl_links'=>false,'unfurl_media'=>false));$result=array('ok'=>!empty($r['ok']),'estado'=>!empty($r['ok'])?'aceito_slack':'falhou','codigo'=>$r['codigo']??'slack_sem_confirmacao');}catch(Throwable $x){$result=array('ok'=>false,'estado'=>'incerto');}}
            if(empty($result['ok'])){$result['contingencia']=F3Base_Alertas_Operacionais::enviar($title,$text,$test);}
            $alarm[$type]=$result+array('em'=>time());F3Base_Email_Site::estado(array('alarme'=>$alarm));
        }finally{F3Base_Pipedrive_Fila::liberar_linha('email-alerta');}
    }
}
