<?php
/** Per-message notification identity, presentation and independently reserved fallback. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Entrega {
    public static function aviso(array $lead,array $row): bool {
        $intent=F3Base_Avisos::intencao(true);
        if(!in_array($intent['canal'],array('slack','ambos','webhook','email_webhook'),true)){return !in_array(self::email($lead,$row),array('reservado','checkpoint_falhou'),true);}
        if(!F3Base_Pipedrive_Fila::travar_linha('email-aviso:'.$lead['record_id'])){return false;}
        try{
            global $wpdb;$key=hash('sha256','email|'.$row['chave'].'|'.$intent['transporte']);
            if($wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE chave=%s',F3Base_Avisos::tabela(),$key))){return true;}
            $cycle=max(100,(int)$wpdb->get_var($wpdb->prepare('SELECT MAX(ciclo)+1 FROM %i WHERE record_id=%s',F3Base_Avisos::tabela(),$lead['record_id'])));
            $projected=F3Base_Email_Site::projetar($lead,$row);$projected['dados']['aviso_intencao']=$intent;$projected['dados']['suspeito_aviso']=F3Base_Formulario_Antispam::contato_valido($projected+$projected['dados']);
            $ok=F3Base_Avisos::enfileirar($projected,$cycle,null,$row);
            // The standard combined channel also requests an administrative email.
            if($ok&&in_array($intent['canal'],array('ambos','email_webhook'),true)){self::email($lead,$row);}
            return $ok;
        }finally{F3Base_Pipedrive_Fila::liberar_linha('email-aviso:'.$lead['record_id']);}
    }
    public static function preparar(array $lead,array $queue): array {
        $meta=F3Base_Avisos::abrir($queue['payload'])??array();
        return isset($meta['email_apresentacao'])?array('ok'=>true,'apresentacao'=>$meta['email_apresentacao']):F3Base_Contato_Comunicacao::preparar($lead);
    }
    public static function contingencia(array $lead,array $queue): string {
        $meta=F3Base_Avisos::abrir($queue['payload'])??array();$row=F3Base_Email_Site::row($meta['email_chave']??'');
        return $row?self::email($lead,$row):'mensagem_indisponivel';
    }
    private static function email(array $lead,array $row): string {
        if(!F3Base_Pipedrive_Fila::travar_linha('email-fallback:'.$row['chave'])){return 'reservado';}
        try{
            $row=F3Base_Email_Site::row($row['chave']);$p=F3Base_Contato_Comunicacao::abrir($row['payload'])??array();
            if(isset($p['aviso_email'])){return $p['aviso_email']['estado']==='reservado'?'incerto':$p['aviso_email']['estado'];}
            if($lead['lixeira']||$lead['eliminacao_pendente']){return 'cancelado';}
            $test=$lead['classe_trafego']==='teste';$state='reservado';
            $to=$test?F3Base_Leads_Notificacoes::destinatarios(F3Base_Testes::config()['email_destinatarios']):F3Base_Leads_Notificacoes::destinatarios_do_contato($lead);
            if($test&&F3Base_Testes::politica('email','teste')==='suprimir'){$state='suprimido_teste';}elseif(!$to){$state='sem_destinatarios';}
            $p['aviso_email']=array('estado'=>$state,'em'=>time());
            if(!F3Base_Email_Site::patch($row['chave'],array('payload'=>F3Base_Contato_Comunicacao::cifrar($p)))){return 'checkpoint_falhou';}
            if($state!=='reservado'){return $state;}
            try{$a=F3Base_Contato_Apresentacao::montar(F3Base_Email_Site::projetar($lead,$row),false);$title=($test?'[TESTE] ':'').($lead['captura']==='suspeito'?'E-mail suspeito':'E-mail recebido').' — '.get_bloginfo('name');$state=F3Base_Email::enviar($to,$title,F3Base_Email::html($a),F3Base_Contato_Apresentacao::texto($a),array())?'processado':'falhou';}catch(Throwable $x){$state='incerto';}
            $p['aviso_email']['estado']=$state;F3Base_Email_Site::patch($row['chave'],array('payload'=>F3Base_Contato_Comunicacao::cifrar($p)));return $state;
        }finally{F3Base_Pipedrive_Fila::liberar_linha('email-fallback:'.$row['chave']);}
    }
}
