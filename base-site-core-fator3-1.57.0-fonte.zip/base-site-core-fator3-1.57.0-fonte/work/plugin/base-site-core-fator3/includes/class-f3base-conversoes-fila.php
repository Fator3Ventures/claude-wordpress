<?php
/**
 * Visão agregada e reavaliação explícita da fila de conversões pelo servidor (1.49.0).
 *
 * POR QUE EXISTE: até a 1.48.0 a fila só era legível por registro
 * (`conversoes-entregas-ler` exige `record_id`). Responder "este site está
 * deixando de mandar conversão e por quê" exigia consultas SQL manuais à tabela
 * `f3base_conversoes_servidor`. A leitura agregada devolve contagens por destino,
 * estado e motivo, atraso da fila e prontidão de cada adaptador, sem dado pessoal
 * e sem chamar fornecedor. A reavaliação antecipa, por ordem explícita e com
 * simulação por padrão, a próxima passagem do worker sobre linhas bloqueadas de
 * um destino — útil depois de corrigir a configuração (ex.: regra LinkedIn de
 * servidor). Ela não envia nada: o worker continua aplicando todas as guardas.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Leitura e agenda locais; nenhuma chamada HTTP. */
final class F3Base_Conversoes_Fila {

	const DESTINOS = array( 'ga4', 'google_ads', 'linkedin' );
	const ESTADOS  = array( 'pendente', 'bloqueado', 'recusado', 'incerto', 'entregue', 'cancelado', 'esgotado' );

	public static function iniciar(): void {
		add_action(
			'wp_abilities_api_init',
			static function (): void {
				$destino = array( 'type' => 'string', 'enum' => self::DESTINOS );
				F3Base_Servicos::ability(
					'conversoes-fila-ler',
					'Resumo da fila de conversões pelo servidor por destino, estado e motivo; sem dados pessoais e sem consultar fornecedores',
					array( __CLASS__, 'ler' ),
					array(
						'dias'    => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 90, 'default' => 30 ),
						'destino' => $destino,
						'amostra' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 20, 'default' => 5 ),
					)
				);
				F3Base_Servicos::ability(
					'conversoes-bloqueadas-reavaliar',
					'Simular ou antecipar a reavaliação de conversões bloqueadas de um destino; o envio continua no worker com todas as guardas',
					array( __CLASS__, 'reavaliar' ),
					array(
						'destino'   => $destino,
						'codigo'    => array( 'type' => 'string', 'pattern' => '^[a-z][a-z0-9_]{0,79}$' ),
						'limite'    => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500, 'default' => 100 ),
						'confirmar' => array( 'type' => 'boolean', 'default' => false ),
					),
					array( 'destino' ),
					false
				);
			}
		);
	}

	/** Explicação do código registrado na fila, sem texto de fornecedor. */
	public static function explicar( string $codigo ): string {
		$mapa = array(
			'regra_ausente'                   => 'Regra LinkedIn de servidor (Conversions API) vazia no registro ou na configuração; preencha a regra própria e confira a concessão no pacote LinkedIn.',
			'regra_linkedin_divergente'       => 'A regra de servidor configurada no Core difere da regra concedida ao consumidor site-core-conversions no pacote LinkedIn.',
			'adaptador_indisponivel'          => 'Nenhum adaptador pronto responde pelo destino (pacote ausente, inativo ou sem concessão).',
			'destino_historico_ausente'       => 'O registro foi aceito sem destino vinculado; use conversoes-recuperar com confirmação de não entrega.',
			'destination_binding_unsupported' => 'O adaptador instalado não oferece envio vinculado ao destino; atualize o pacote fornecedor.',
			'destino_alterado'                => 'O destino atual do fornecedor difere do vinculado ao registro; nada é enviado ao novo destino sem recuperação explícita.',
			'limite_tentativas'               => 'Dez tentativas sem confirmação; nova tentativa só por recuperação explícita.',
			'envio_iniciado'                  => 'Envio iniciado sem confirmação; aguarde a reconciliação, sem reenviar.',
			'registro_eliminado'              => 'O contato foi eliminado; a entrega foi cancelada.',
			'sem_codigo'                      => 'Sem código registrado.',
		);
		if ( isset( $mapa[ $codigo ] ) ) {
			return $mapa[ $codigo ];
		}
		$texto = F3Base_Conversoes_Servidor::motivo( $codigo );
		return str_starts_with( $texto, 'A recuperação foi recusada' ) ? 'Código registrado pela fila: ' . $codigo . '.' : $texto;
	}

	/**
	 * Resumo agregado da fila.
	 *
	 * @param array<string,mixed> $e Entrada da ability.
	 * @return array<string,mixed>
	 */
	public static function ler( array $e = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array( 'ok' => false, 'codigo' => 'sem_permissao' );
		}
		global $wpdb;
		$t       = F3Base_Conversoes_Servidor::tabela();
		$dias    = max( 1, min( 90, (int) ( $e['dias'] ?? 30 ) ) );
		$amostra = max( 0, min( 20, (int) ( $e['amostra'] ?? 5 ) ) );
		$destino = in_array( $e['destino'] ?? '', self::DESTINOS, true ) ? (string) $e['destino'] : '';
		$agora   = time();
		$desde   = $agora - $dias * DAY_IN_SECONDS;
		$filtro  = '' === $destino ? '' : $wpdb->prepare( ' AND destino=%s', $destino );

		$linhas = $wpdb->get_results( $wpdb->prepare( "SELECT destino,estado,codigo,COUNT(*) AS n,MIN(ocorrido_em) AS mais_antigo,MAX(atualizado_em) AS ultima FROM %i WHERE ocorrido_em>=%d{$filtro} GROUP BY destino,estado,codigo", $t, $desde ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $filtro is prepared above.
		if ( $wpdb->last_error ) {
			return array( 'ok' => false, 'codigo' => 'fila_indisponivel' );
		}
		$vencidas = $wpdb->get_results( $wpdb->prepare( "SELECT destino,estado,COUNT(*) AS n,MIN(proxima) AS mais_antiga FROM %i WHERE estado IN ('pendente','recusado','bloqueado','incerto') AND proxima<=%d{$filtro} GROUP BY destino,estado", $t, $agora ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $filtro is prepared above.
		if ( $wpdb->last_error ) {
			return array( 'ok' => false, 'codigo' => 'fila_indisponivel' );
		}

		$destinos = array();
		foreach ( '' === $destino ? self::DESTINOS : array( $destino ) as $d ) {
			$destinos[ $d ] = array( 'total' => 0, 'estados' => array_fill_keys( self::ESTADOS, 0 ), 'motivos' => array(), 'vencidas' => array_fill_keys( array( 'pendente', 'recusado', 'bloqueado', 'incerto' ), 0 ), 'atraso_segundos' => 0, 'mais_antigo_ocorrido_em' => null, 'ultima_atualizacao_em' => null, 'amostra' => array() );
		}
		foreach ( $linhas ?: array() as $l ) {
			$d = (string) $l['destino'];
			if ( ! isset( $destinos[ $d ] ) ) {
				continue;
			}
			$n                     = (int) $l['n'];
			$destinos[ $d ]['total'] += $n;
			$estado                = (string) $l['estado'];
			$destinos[ $d ]['estados'][ $estado ] = ( $destinos[ $d ]['estados'][ $estado ] ?? 0 ) + $n;
			if ( ! in_array( $estado, array( 'pendente', 'entregue' ), true ) ) {
				$codigo = F3Base_Conversoes_Servidor::codigo( $l['codigo'], 'sem_codigo' );
				$chave  = $estado . ':' . $codigo;
				$destinos[ $d ]['motivos'][ $chave ] = array( 'estado' => $estado, 'codigo' => $codigo, 'quantidade' => ( $destinos[ $d ]['motivos'][ $chave ]['quantidade'] ?? 0 ) + $n, 'explicacao' => self::explicar( $codigo ) );
			}
			$antigo = (int) $l['mais_antigo'];
			$ultima = (int) $l['ultima'];
			$destinos[ $d ]['mais_antigo_ocorrido_em'] = null === $destinos[ $d ]['mais_antigo_ocorrido_em'] ? $antigo : min( $destinos[ $d ]['mais_antigo_ocorrido_em'], $antigo );
			$destinos[ $d ]['ultima_atualizacao_em']   = max( (int) $destinos[ $d ]['ultima_atualizacao_em'], $ultima );
		}
		foreach ( $vencidas ?: array() as $v ) {
			$d = (string) $v['destino'];
			if ( ! isset( $destinos[ $d ] ) ) {
				continue;
			}
			$destinos[ $d ]['vencidas'][ (string) $v['estado'] ] = (int) $v['n'];
			if ( in_array( $v['estado'], array( 'pendente', 'recusado' ), true ) ) {
				$destinos[ $d ]['atraso_segundos'] = max( $destinos[ $d ]['atraso_segundos'], max( 0, $agora - (int) $v['mais_antiga'] ) );
			}
		}
		foreach ( $destinos as $d => &$info ) {
			$info['motivos'] = array_values( $info['motivos'] );
			usort( $info['motivos'], static fn( $a, $b ) => $b['quantidade'] <=> $a['quantidade'] ?: strcmp( $a['codigo'], $b['codigo'] ) );
			if ( $amostra > 0 ) {
				$info['amostra'] = array_map(
					static fn( $r ) => array( 'record_id' => (string) $r['record_id'], 'estado' => (string) $r['estado'], 'codigo' => F3Base_Conversoes_Servidor::codigo( $r['codigo'], 'sem_codigo' ), 'atualizado_em' => (int) $r['atualizado_em'] ),
					$wpdb->get_results( $wpdb->prepare( "SELECT record_id,estado,codigo,atualizado_em FROM %i WHERE destino=%s AND estado IN ('bloqueado','incerto','esgotado','recusado') AND ocorrido_em>=%d ORDER BY atualizado_em DESC LIMIT %d", $t, $d, $desde, $amostra ), ARRAY_A ) ?: array()
				);
				if ( $wpdb->last_error ) {
					return array( 'ok' => false, 'codigo' => 'fila_indisponivel' );
				}
			}
		}
		unset( $info );
		$estado_destinos = array();
		try {
			$estado_destinos = F3Base_Conversoes_Transporte::estado();
		} catch ( Throwable $erro ) {
			$estado_destinos = array();
		}
		$linkedin = array(
			'regra_navegador_configurada' => '' !== (string) F3Base_Options::ler( 'f3base_linkedin_conversion_id' ),
			'regra_servidor_configurada'  => '' !== (string) F3Base_Options::ler( 'f3base_linkedin_server_conversion_id' ),
		);
		$proxima = wp_next_scheduled( F3Base_Conversoes_Servidor::HOOK );
		return array(
			'ok'          => true,
			'contrato'    => F3Base_Conversoes_Servidor::CONTRATO,
			'janela_dias' => $dias,
			'gerado_em'   => $agora,
			'destinos'    => $destinos,
			'transporte'  => $estado_destinos,
			'linkedin'    => $linkedin,
			'agenda'      => array( 'proxima_passagem_em' => $proxima ? (int) $proxima : null, 'lote_por_passagem' => 10, 'prioridade' => 'pendente e recusado antes de bloqueado' ),
			'limites'     => 'Contagens locais da tabela de entregas pelo servidor. Entregue comprova a resposta do adaptador, não o processamento no fornecedor. Detalhe por registro: f3base/conversoes-entregas-ler.',
		);
	}

	/**
	 * Antecipa a reavaliação de linhas bloqueadas; simulação por padrão.
	 *
	 * @param array<string,mixed> $e Entrada da ability.
	 * @return array<string,mixed>
	 */
	public static function reavaliar( array $e ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array( 'ok' => false, 'codigo' => 'sem_permissao' );
		}
		$destino = (string) ( $e['destino'] ?? '' );
		if ( ! in_array( $destino, self::DESTINOS, true ) ) {
			return array( 'ok' => false, 'codigo' => 'destino_invalido' );
		}
		$codigo = (string) ( $e['codigo'] ?? '' );
		if ( '' !== $codigo && ! preg_match( '/^[a-z][a-z0-9_]{0,79}$/D', $codigo ) ) {
			return array( 'ok' => false, 'codigo' => 'codigo_invalido' );
		}
		$limite    = max( 1, min( 500, (int) ( $e['limite'] ?? 100 ) ) );
		$confirmar = true === ( $e['confirmar'] ?? false );
		global $wpdb;
		$t     = F3Base_Conversoes_Servidor::tabela();
		$where = $wpdb->prepare( 'estado=%s AND destino=%s', 'bloqueado', $destino ) . ( '' === $codigo ? '' : $wpdb->prepare( ' AND codigo=%s', $codigo ) );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE {$where}", $t ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is prepared above.
		if ( $wpdb->last_error ) {
			return array( 'ok' => false, 'codigo' => 'fila_indisponivel', 'persisted' => false );
		}
		$por_codigo = $wpdb->get_results( $wpdb->prepare( "SELECT codigo,COUNT(*) AS n FROM %i WHERE {$where} GROUP BY codigo ORDER BY n DESC LIMIT 20", $t ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is prepared above.
		if ( $wpdb->last_error ) {
			return array( 'ok' => false, 'codigo' => 'fila_indisponivel', 'persisted' => false );
		}
		$selecao    = min( $total, $limite );
		$capacidade = array();
		try {
			$capacidade = F3Base_Conversoes_Transporte::capacidade( $destino );
		} catch ( Throwable $erro ) {
			$capacidade = array( 'ready' => false, 'reason' => 'adaptador_indisponivel' );
		}
		$resposta = array(
			'ok'                => true,
			'simulado'          => ! $confirmar,
			'destino'           => $destino,
			'codigo'            => '' === $codigo ? null : $codigo,
			'bloqueadas'        => $total,
			'selecionadas'      => $selecao,
			'por_codigo'        => array_map( static fn( $r ) => array( 'codigo' => F3Base_Conversoes_Servidor::codigo( $r['codigo'], 'sem_codigo' ), 'quantidade' => (int) $r['n'], 'explicacao' => self::explicar( F3Base_Conversoes_Servidor::codigo( $r['codigo'], 'sem_codigo' ) ) ), $por_codigo ),
			'adaptador_pronto'  => ! empty( $capacidade['ready'] ),
			'adaptador_motivo'  => (string) ( $capacidade['reason'] ?? 'adaptador_indisponivel' ),
			'efeito'            => 'Antecipa para agora a próxima reavaliação das linhas selecionadas e agenda uma passagem do worker. Nada é enviado por esta operação; linhas que continuarem inelegíveis voltam a bloqueado com o motivo atual.',
		);
		if ( ! $confirmar || 0 === $selecao ) {
			return $resposta + array( 'reagendadas' => 0 );
		}
		$agora = time();
		$n     = $wpdb->query( $wpdb->prepare( "UPDATE %i SET proxima=%d WHERE {$where} ORDER BY proxima LIMIT %d", $t, $agora, $selecao ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is prepared above.
		if ( false === $n ) {
			return array( 'ok' => false, 'codigo' => 'reagendamento_nao_persistido' );
		}
		$agenda = F3Base_Fila::agendar_detalhe( F3Base_Conversoes_Servidor::HOOK, $agora + 30 );
		return array(
			'ok' => ! empty( $agenda['agendado'] ),
			'codigo' => ! empty( $agenda['agendado'] ) ? $resposta['codigo'] : 'agenda_nao_confirmada',
			'simulado' => false, 'persisted' => true, 'reagendadas' => (int) $n,
			'passagem_agendada_em' => $agenda['proxima_execucao'] ?? null,
			'agenda' => $agenda,
		) + $resposta;
	}
}
