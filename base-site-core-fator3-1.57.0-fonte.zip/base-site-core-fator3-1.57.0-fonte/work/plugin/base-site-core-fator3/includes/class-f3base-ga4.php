<?php
/** Consumer of Google's public GA4 reader. Credentials, grants and quotas belong to Google. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Ga4 {
    const OPTION='f3base_ga4_acervo';const STATE='f3base_ga4_estado';const CONTRACT='ga4-reader/1.0.0';
    const HOOK='f3base_ga4_coletar';const CONTINUAR='f3base_ga4_continuar';
    private static $client=null;private static string $registro='sdk_ausente';private static array $caps=array();
    public static function recortes(): array {
        $eng=array('activeUsers','totalUsers','sessions','engagedSessions','userEngagementDuration','eventCount','keyEvents');
        return array(
            'resumo'=>array('dimensions'=>array('date'),'metrics'=>$eng),
            'paginas'=>array('dimensions'=>array('date','pagePath'),'metrics'=>array('activeUsers','totalUsers','screenPageViews','userEngagementDuration','eventCount','keyEvents')),
            'aquisicao'=>array('dimensions'=>array('date','sessionSource','sessionMedium','sessionCampaignName'),'metrics'=>$eng),
            'dispositivos'=>array('dimensions'=>array('date','deviceCategory'),'metrics'=>$eng),
            'paises'=>array('dimensions'=>array('date','country'),'metrics'=>$eng),
            'cidades'=>array('dimensions'=>array('date','country','city'),'metrics'=>$eng),
            'eventos'=>array('dimensions'=>array('date','eventName'),'metrics'=>array('activeUsers','totalUsers','eventCount','keyEvents','userEngagementDuration'))
        );
    }
    public static function props(): array {return array('ativo'=>array('type'=>'boolean'),'propriedade'=>array('type'=>'string','pattern'=>'^(|properties/[1-9][0-9]{0,19})$'),'inicio'=>array('type'=>'string','maxLength'=>10),'horario'=>array('type'=>'string','pattern'=>'^([01][0-9]|2[0-3]):[0-5][0-9]$'),'fuso'=>array('type'=>'string','maxLength'=>80),'recortes'=>array('type'=>'array','minItems'=>1,'maxItems'=>7,'uniqueItems'=>true,'items'=>array('type'=>'string','enum'=>array_keys(self::recortes()))));}
    public static function defaults(): array {return array('ativo'=>false,'propriedade'=>'','inicio'=>'','horario'=>'06:00','fuso'=>'America/Sao_Paulo','recortes'=>array_keys(self::recortes()));}
    public static function opcoes(): array {return array_replace(self::defaults(),(array)F3Base_Options::ler(self::OPTION));}
    public static function validar($v): string {
        $s=array('type'=>'object','properties'=>self::props(),'additionalProperties'=>false);$error=rest_validate_value_from_schema($v,$s);if(is_wp_error($error)){return $error->get_error_message();}$v=array_replace(self::defaults(),$v);
        try{new DateTimeZone($v['fuso']);}catch(Throwable $e){return 'Informe um fuso IANA válido.';}
        if($v['ativo']&&$v['propriedade']===''){return 'Informe a propriedade GA4.';}if($v['inicio']!==''&&(!F3Base_Gsc::data_valida($v['inicio'])||$v['inicio']>(new DateTimeImmutable('today',new DateTimeZone($v['fuso'])))->format('Y-m-d'))){return 'Data inicial inválida.';}return '';
    }
    public static function configuracao(): array {
        $c=self::opcoes();$recovery=F3Base_Recuperacao::ler();return array('property'=>$c['propriedade'],'revision'=>hash('sha256',wp_json_encode(array($c,F3Base_Ga4_Acervo::VERSION,self::recortes(),$recovery['geracao']??0))),'ready'=>$c['ativo']&&$c['propriedade']!==''&&F3Base_Ga4_Acervo::pronta()&&!empty($recovery['ok'])&&empty($recovery['pausado']));
    }
    public static function descobrir($sdk,string $contract): void {
        if($contract!==self::CONTRACT){return;}self::$client=null;self::$registro='contrato_incompativel';
        try{if(!is_object($sdk)||!is_callable(array($sdk,'capabilities'))){return;}$caps=$sdk::capabilities();if(($caps['contract']??'')!==self::CONTRACT||!in_array('ga4.report.read',$caps['capabilities']??array(),true)){return;}
            $client=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,self::CONTRACT,array(__CLASS__,'configuracao'));if(is_wp_error($client)){self::$registro=$client->get_error_code();return;}if(!is_object($client)||!is_callable(array($client,'query'))||!is_callable(array($client,'effective_status'))){return;}self::$client=$client;self::$caps=$caps;self::$registro='registrado';
        }catch(Throwable $e){self::$registro='sdk_incompativel';}
    }
    public static function iniciar(): void {
        add_filter('f3base_options_catalogo',static function($c){$d=F3Base_Conversas::catalogo_grupo(self::OPTION,'Acervo GA4 — coleta diária e retroativa',self::defaults(),self::props(),array(__CLASS__,'validar'));$d['descricao']='Métricas GA4 no banco local, sem prazo por padrão. Exige concessão no MCP Google. Fuso deve corresponder à propriedade. Não ativa conversões.';$d['secao']='medicao-ga4';$d['subcampos']=array('ativo'=>array('tipo'=>'booleano','rotulo'=>'Habilitar coleta'),'propriedade'=>array('tipo'=>'texto','rotulo'=>'Propriedade (properties/123)'),'inicio'=>array('tipo'=>'texto','rotulo'=>'Coletar desde (AAAA-MM-DD; vazio: últimos 30 dias)'),'horario'=>array('tipo'=>'texto','rotulo'=>'Horário no fuso do site'),'fuso'=>array('tipo'=>'texto','rotulo'=>'Fuso da propriedade GA4'),'recortes'=>array('tipo'=>'multiescolha','rotulo'=>'Recortes','opcoes'=>array('resumo'=>'Resumo','paginas'=>'Páginas','aquisicao'=>'Origem, mídia e campanha','dispositivos'=>'Dispositivos','paises'=>'Países','cidades'=>'Países e cidades','eventos'=>'Eventos e eventos-chave')));$c[self::OPTION]=$d;$c[self::STATE]=array('rotulo'=>'Estado da coleta GA4','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;});
        add_action('init',array(__CLASS__,'agendar'),121);add_action(self::HOOK,array(__CLASS__,'coletar'));add_action(self::CONTINUAR,array(__CLASS__,'coletar'));add_action('wp_abilities_api_init',array(__CLASS__,'registrar'));
        add_action('updated_option',static function($name){if($name===self::OPTION){F3Base_Options::atualizar_estado(self::STATE,static fn($s)=>array_merge($s,array('proxima_tentativa'=>0)));wp_clear_scheduled_hook(self::HOOK);wp_clear_scheduled_hook(self::CONTINUAR);self::agendar();}},211,1);
        add_action(F3Base_Modulo_Retencao_Eliminacao::EVENTO,array(F3Base_Ga4_Acervo::class,'limpar'),99);
    }
    public static function agendar(): void {$c=self::opcoes();if(!$c['ativo']){wp_clear_scheduled_hook(self::HOOK);wp_clear_scheduled_hook(self::CONTINUAR);return;}if(!wp_next_scheduled(self::HOOK)){wp_schedule_event(F3Base_Operacao::proximo_horario($c['horario']),'daily',self::HOOK);}}
    private static function continuar(int $at): void {if(!wp_next_scheduled(self::CONTINUAR)){wp_schedule_single_event(max(time()+60,$at),self::CONTINUAR);}}
    public static function status(): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$status=null;if(self::$client){try{$status=self::$client->effective_status();}catch(Throwable $e){$status=array('resolution'=>'unreadable');}}
        return array('ok'=>true,'fonte'=>'GA4','contrato'=>self::CONTRACT,'sdk'=>self::$registro,'configuracao'=>self::configuracao(),'opcoes'=>self::opcoes(),'servico'=>$status,'estado'=>F3Base_Options::ler(self::STATE),'recortes'=>self::recortes(),'acervo'=>F3Base_Ga4_Acervo::tamanho(),'proxima_passagem'=>wp_next_scheduled(self::CONTINUAR)?:wp_next_scheduled(self::HOOK),'acesso_remoto_comprovado'=>false);
    }
    /** One report page per pass, own scheduling and lock; no effect on GSC's quota or hooks. */
    public static function coletar(array $e=array()): array {
        if($e&&!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(!empty($e['simular'])){return array('ok'=>true,'simulado'=>true,'configuracao'=>self::configuracao(),'efeito'=>'Uma página; dados publicados só após paginação completa.');}
        if(!F3Base_Ga4_Acervo::autocommit()){return array('ok'=>false,'codigo'=>'transacao_ativa_ou_indisponivel');}$cfg=self::configuracao();if(!$cfg['ready']||!self::$client){return array('ok'=>false,'codigo'=>!$cfg['ready']?'ga4_configuracao_pendente':self::$registro);}
        $lock=F3Base_Trava::adquirir('ga4-coletor',90);if(!$lock){return array('ok'=>false,'codigo'=>'coleta_ocupada');}
        $own=false;$c=null;
        try{
            $state=F3Base_Options::ler(self::STATE);$wait=(int)($state['proxima_tentativa']??0);if($wait>time()){self::continuar($wait);return array('ok'=>false,'codigo'=>'ga4_aguardando_cota_ou_servico','proxima_tentativa'=>$wait);}
            global $wpdb;$opts=self::opcoes();$to=(new DateTimeImmutable('yesterday',new DateTimeZone($opts['fuso'])))->format('Y-m-d');$from=$opts['inicio']?:((new DateTimeImmutable($to))->modify('-29 days')->format('Y-m-d'));
            if(isset($e['dia'])){if(!F3Base_Gsc::data_valida($e['dia'])||$e['dia']>$to){return array('ok'=>false,'codigo'=>'dia_invalido');}$from=$to=$e['dia'];}
            $slices=isset($e['recorte'])?array($e['recorte']):$opts['recortes'];if(array_diff($slices,array_keys(self::recortes()))){return array('ok'=>false,'codigo'=>'recorte_invalido');}
            $t=F3Base_Ga4_Acervo::tabela();$selection=null;
            // Fresh dates have priority once a day; then unfinished history. Each slice has a separate checkpoint.
            $recent=(new DateTimeImmutable($to))->modify('-2 days')->format('Y-m-d');$ranges=isset($e['dia'])?array(array($from,$to)):array(array(max($from,$recent),$to),array($from,$to));
            foreach($ranges as [$a,$b]){if($a>$b){continue;}$seen=$wpdb->get_results($wpdb->prepare('SELECT c.id,c.dia,c.recorte,c.estado,c.tentar_em,c.atualizado_em FROM %i c JOIN (SELECT MAX(sequencia) seq FROM %i WHERE propriedade=%s AND dia BETWEEN %s AND %s GROUP BY dia,recorte) latest ON c.sequencia=latest.seq',$t,$t,$cfg['property'],$a,$b),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'acervo_indisponivel');}$latest=array();foreach($seen as $r){$k=$r['dia'].'|'.$r['recorte'];if(!isset($latest[$k])){$latest[$k]=$r;}}
                for($d=new DateTimeImmutable($a);$d->format('Y-m-d')<=$b&&!$selection;$d=$d->modify('+1 day')){foreach($slices as $slice){$day=$d->format('Y-m-d');$last=$latest[$day.'|'.$slice]??null;$due=!$last||(($last['estado']!=='concluida'||(!empty($e['reconsultar'])||$day>=$recent))&&(int)$last['tentar_em']<=time()&&($last['estado']!=='concluida'||!empty($e['reconsultar'])||(int)$last['atualizado_em']<=time()-DAY_IN_SECONDS));if(!$due){continue;}$selection=array($day,$slice,$last);break;}}if($selection){break;}
            }
            if(!$selection){return array('ok'=>true,'codigo'=>'ga4_sem_dia_elegivel');}[$day,$slice,$last]=$selection;
            if($last){$last=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',$t,$last['id']),ARRAY_A);}
            if($last&&in_array($last['estado'],array('em_curso','aguardando'),true)&&$last['revision']===$cfg['revision']&&(int)$last['criado_em']>time()-DAY_IN_SECONDS){$c=$last;}else{$c=F3Base_Ga4_Acervo::criar($cfg['property'],$day,$slice,$cfg['revision']);}
            if(!$c){return array('ok'=>false,'codigo'=>'coleta_nao_persistida');}
            if(!F3Base_Execucoes::atual()){$own=F3Base_Execucoes::iniciar('ga4');}$run=F3Base_Execucoes::atual()['run_id']??wp_generate_uuid4();$budget=min(20000,F3Base_Execucoes::restante_ms(2000));if($budget<3000){self::continuar(time()+60);return array('ok'=>false,'codigo'=>'orcamento_insuficiente');}
            $spec=self::recortes()[$slice];$query=array('contract_version'=>'1.0.0','property'=>$cfg['property'],'consumer_revision'=>$cfg['revision'],'start_date'=>$day,'end_date'=>$day,'dimensions'=>$spec['dimensions'],'metrics'=>$spec['metrics'],'limit'=>min(1000,(int)(self::$caps['limit_max']??1000)),'run_id'=>$run,'trigger'=>F3Base_Execucoes::origem(),'budget_ms'=>$budget);
            if($c['cursor']!==''){$cursor=F3Base_Contato_Comunicacao::abrir($c['cursor']);if(empty($cursor['cursor'])){return F3Base_Ga4_Acervo::falhar($c,'cursor_ilegivel',time()+60,true);}$query['cursor']=$cursor['cursor'];}
            $response=self::$client->query($query);if(!is_array($response)){$response=array('success'=>false,'error_code'=>'resposta_sdk_invalida');}
            if(empty($response['success'])||empty($response['audit_success'])){$code=(string)($response['error_code']??'auditoria_nao_confirmada');$next=max(time()+300,(int)($response['next_eligible_at']??0),time()+(int)ceil(($response['retry_after_ms']??0)/1000));$result=F3Base_Ga4_Acervo::falhar($c,$code,$next,(bool)preg_match('/cursor|context|consumer_changed|unauthorized/',$code));$global=(bool)preg_match('/quota|audit|unauthorized|busy|disabled|connector|storage/',$code);}
            elseif(self::configuracao()!==$cfg){$result=F3Base_Ga4_Acervo::falhar($c,'configuracao_alterada',time()+60,true);$global=false;}
            else{$result=F3Base_Ga4_Acervo::receber($c,$response);$global=false;}
            $next=$global?($result['proxima_tentativa']??time()+300):0;
            F3Base_Options::atualizar_estado(self::STATE,static fn($s)=>array_merge($s,array('ultima_tentativa'=>time(),'codigo'=>$result['codigo'],'ultima_coleta'=>$c['id'],'proxima_tentativa'=>$next,'cota'=>$response['quota']??null,'request_id'=>$response['request_id']??null)));
            self::continuar(max(time()+60,$next));return $result;
        }catch(Throwable $x){if($c){$r=F3Base_Ga4_Acervo::falhar($c,'ga4_falha_interna',time()+300,true);self::continuar(time()+300);return $r;}return array('ok'=>false,'codigo'=>'ga4_falha_interna');}
        finally{if($own){F3Base_Execucoes::encerrar();}F3Base_Trava::liberar($lock);}
    }
    public static function render(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}
        $q=array();foreach(array('de','ate','recorte') as $k){if(isset($_GET[$k])&&is_string($_GET[$k])){$q[$k]=sanitize_text_field(wp_unslash($_GET[$k]));}}$q['pagina']=max(1,(int)($_GET['pagina']??1));
        echo '<div class="wrap"><h1>Acervo GA4</h1><p>Dados agregados importados do Google Analytics. A medição própria do site aparece separadamente abaixo.</p><p><a href="'.esc_url(F3Base_Interface::url(self::OPTION)).'">Configurar coleta GA4</a> · <a href="'.esc_url(admin_url('admin.php?page=f3base-medicao')).'">Medição do site</a></p>';
        try{[$p,$from,$to,$slice]=F3Base_Ga4_Acervo::janela($q);}catch(Throwable $e){echo '<p role="status">Configure a propriedade GA4 e escolha um período válido de até 366 dias.</p></div>';return;}
        echo '<form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="ga4">';foreach(array('de'=>$from,'ate'=>$to) as $k=>$v){echo '<label>'.($k==='de'?'De':'Até').' <input type="date" name="'.$k.'" value="'.esc_attr($v).'"></label> ';}echo '<label>Recorte <select name="recorte">';foreach(F3Base_Options::declaracao(self::OPTION)['subcampos']['recortes']['opcoes'] as $k=>$label){echo '<option value="'.esc_attr($k).'" '.selected($slice,$k,false).'>'.esc_html($label).'</option>';}echo '</select></label> <button class="button">Consultar</button></form><h2>Fonte: GA4</h2><p>Propriedade '.esc_html($p).'. Cada linha representa um dia e suas dimensões. Não some usuários distintos entre dias nem métricas de recortes diferentes.</p>';
        $r=F3Base_Ga4_Acervo::consultar($q);if(empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']).'</p></div>';return;}$rows=array();foreach($r['linhas'] as $row){$rows[]=array('fonte'=>'GA4','dia'=>$row['dia'])+$row['dimensoes']+$row['metricas'];}F3Base_Relatorios::tabela($rows);if($r['proxima_pagina']){echo '<a class="button" href="'.esc_url(add_query_arg('pagina',$r['proxima_pagina'])).'">Próxima página</a>';}
        $gaps=F3Base_Ga4_Acervo::lacunas($q);echo '<p>'.count($gaps['lacunas']??array()).' dias com coleta ausente, vazia ou pendente. Ausência de dados não significa zero.</p><details><summary>Qualidade e cobertura das linhas exibidas</summary><pre>'.esc_html(wp_json_encode($r['qualidade_por_dia'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details><h2>Fonte: medição própria do site</h2><p>As contagens permanecem separadas das métricas GA4; as fontes têm regras e cobertura diferentes.</p>';
        $own=F3Base_Relatorios::consultar(array('de'=>$from,'ate'=>$to,'visao'=>'resultados'));if(!empty($own['ok'])){F3Base_Relatorios::tabela($own['linhas']);}else{echo '<p>'.esc_html($own['codigo']??'Medição própria indisponível').'. Para esta fonte, escolha um período de até 90 dias.</p>';}echo '</div>';
    }
    public static function registrar(): void {
        $p=array('propriedade'=>array('type'=>'string','pattern'=>'^properties/[1-9][0-9]{0,19}$'),'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'recorte'=>array('type'=>'string','enum'=>array_keys(self::recortes())),'pagina'=>array('type'=>'integer','minimum'=>1),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>100),'revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'));
        F3Base_Servicos::ability('ga4-status','Estado local do consumidor/acervo GA4; não consulta fornecedor',array(__CLASS__,'status'));
        F3Base_Servicos::ability('ga4-coletar','Coletar uma página GA4 autorizada, incluindo dia retroativo; publicação ao concluir',array(__CLASS__,'coletar'),array('dia'=>array('type'=>'string','format'=>'date'),'recorte'=>$p['recorte'],'reconsultar'=>array('type'=>'boolean'),'simular'=>array('type'=>'boolean','default'=>false)),array(),false);
        F3Base_Servicos::ability('ga4-historico','Fotografias GA4, tentativas, qualidade e cobertura por recorte',array(F3Base_Ga4_Acervo::class,'historico'),$p);
        F3Base_Servicos::ability('ga4-lacunas-ler','Dias não coletados, vazios e falhos do GA4, por recorte',array(F3Base_Ga4_Acervo::class,'lacunas'),$p);
        F3Base_Servicos::ability('ga4-acervo-ler','Séries diárias publicadas GA4; métricas não somadas',array(F3Base_Ga4_Acervo::class,'consultar'),$p);
        F3Base_Servicos::ability('ga4-comparar','Comparação das séries GA4 em dois períodos explícitos',array(F3Base_Ga4_Acervo::class,'comparar'),$p+array('anterior_de'=>$p['de'],'anterior_ate'=>$p['ate']),array('anterior_de','anterior_ate'));
        F3Base_Servicos::ability('ga4-exportar','Exportar parte autenticada CSV/JSON; base64, hash, revisão e continuação',array(F3Base_Ga4_Acervo::class,'exportar'),$p+array('formato'=>array('type'=>'string','enum'=>array('csv','json'))));
    }
}
