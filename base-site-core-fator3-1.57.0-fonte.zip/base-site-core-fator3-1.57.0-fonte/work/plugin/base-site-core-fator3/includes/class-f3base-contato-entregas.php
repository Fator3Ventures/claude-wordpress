<?php
/** Projeção única e em lote. Aceite do transporte nunca significa leitura humana. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Contato_Entregas {
    public static function aprovacao_sql(): string {
        $d="IF(JSON_VALID(dados),dados,'{}')";$e="IF(JSON_VALID(entrega),entrega,'{}')";
        return "captura='aceito' AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT({$e},'$.pipedrive.solicitado')),'false') NOT IN ('true','1') AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT({$d},'$.aprovacao.entrega_solicitada')),'false') NOT IN ('true','1') AND (JSON_UNQUOTE(JSON_EXTRACT({$e},'$.pipedrive.motivo'))='aprovado_sem_entrega' OR COALESCE(JSON_LENGTH(JSON_EXTRACT({$d},'$.aprovacao_historico')),0)>0 OR COALESCE(JSON_LENGTH(JSON_EXTRACT({$d},'$.aprovacao')),0)>0 OR (revisao>1 AND JSON_UNQUOTE(JSON_EXTRACT({$d},'$.captura'))='suspeito' AND JSON_UNQUOTE(JSON_EXTRACT({$e},'$.pipedrive.motivo'))='captura_nao_aceita'))";
    }
    public static function aprovacao(array $r): array {
        $d=is_string($r['dados']??null)?(json_decode($r['dados'],true)?:array()):($r['dados']??array());
        $e=is_string($r['entrega']??null)?(json_decode($r['entrega'],true)?:array()):($r['entrega']??array());$i=$e['pipedrive']??array();
        if(($r['captura']??'')!=='aceito'||!empty($i['solicitado'])||!empty($d['aprovacao']['entrega_solicitada'])){return array();}
        $novo=($i['motivo']??'')==='aprovado_sem_entrega';
        $historico=!empty($d['aprovacao_historico'])||!empty($d['aprovacao']);
        $transicao=($d['captura']??'')==='suspeito'&&(int)($r['revisao']??1)>1&&($i['motivo']??'')==='captura_nao_aceita';
        if(!$novo&&!$historico&&!$transicao){return array();}
        return array('estado'=>'aprovado_sem_entrega','codigo'=>$novo?'aprovado_sem_entrega':'aprovado_sem_entrega_anterior_regra','rotulo'=>$novo?'Aprovado sem entrega':'Aprovado sem entrega (anterior à regra)','anterior_regra'=>!$novo,'evidencia'=>$novo?'decisao_explicita':($historico?'historico_aprovacao':'captura_original_e_revisao'),'decisao'=>$novo?$i:($d['aprovacao']??array()),'projecao_sem_regravar'=>!$novo);
    }
    public static function projetar(array $r): array {
        $a=self::aprovacao($r);if($a){$r['aprovacao_entrega']=$a;$r['entrega']['pipedrive']['leitura']=$a;}return $r;
    }
    public static function lote(array $leads): array {
        if(!$leads){return array();}global $wpdb;$ids=array_values(array_unique(array_column($leads,'record_id')));$in=implode(',',array_fill(0,count($ids),'%s'));$external=array();$crm=array();$quality=array();
        foreach($wpdb->get_results($wpdb->prepare("SELECT record_id,estado,codigo,contingencia,atualizada_em FROM %i WHERE record_id IN ({$in}) ORDER BY ciclo DESC",array_merge(array(F3Base_Avisos::tabela()),$ids)),ARRAY_A)?:array() as $r){$external[$r['record_id']]=$external[$r['record_id']]??$r;}
        foreach($wpdb->get_results($wpdb->prepare("SELECT record_id,estado,codigo,atualizado_em FROM %i WHERE record_id IN ({$in}) ORDER BY atualizado_em DESC",array_merge(array(F3Base_Pipedrive_Fila::tabela()),$ids)),ARRAY_A)?:array() as $r){$crm[$r['record_id']]=$crm[$r['record_id']]??$r;}
        foreach($wpdb->get_results($wpdb->prepare("SELECT record_id,etapa,origem,ocorreu_em FROM %i WHERE record_id IN ({$in})",array_merge(array(F3Base_Qualidade::tabela('atual')),$ids)),ARRAY_A)?:array() as $r){$quality[$r['record_id']]=$r;}
        $out=array();foreach($leads as $l){$id=$l['record_id'];$d=is_string($l['dados']??null)?json_decode($l['dados'],true):($l['dados']??array());$i=$d['aviso_intencao']??array();$channel=$i['canal']??'email';$x=$external[$id]??null;$c=$crm[$id]??null;$ext=in_array($channel,array('slack','ambos'),true)?'slack':(in_array($channel,array('webhook','email_webhook'),true)?'webhook':null);
            $email=in_array($channel,array('email','ambos','email_webhook'),true)?($l['aviso']??'desconhecido'):'nao_solicitado';$channels=array('email'=>array('estado'=>$email,'confirmacao'=>$email==='processado'?'aceito_pelo_transporte_nao_confirma_leitura':null),'visitante'=>array('estado'=>$l['resposta']??'nao_solicitado'),'pipedrive'=>$c?array('estado'=>$c['estado'],'codigo'=>$c['codigo'],'em'=>(int)$c['atualizado_em']):(self::aprovacao($l)?:array('estado'=>'nao_enfileirado')));
            if($ext){$channels[$ext]=$x?array('estado'=>$x['estado'],'codigo'=>$x['codigo'],'em'=>(int)$x['atualizada_em']):array('estado'=>empty($i['elegivel'])?'nao_solicitado':'aguarda_preparo');}
            $fallback=$x['contingencia']??'';$fallbackOK=in_array($fallback,array('processado','enviado','enviada','aceito'),true);$failed=$x&&in_array($x['estado'],array('falhou','incerto','suspenso'),true);$confirmed=in_array($l['aviso']??'',array('processado','resumo_processado'),true)||($x&&$x['estado']==='entregue')||$fallbackOK;
            $out[$id]=array('canais'=>$channels,'contingencia_email'=>$fallback?:'nao_acionada','resumo'=>$failed&&!$confirmed?'Aviso requer atenção':($confirmed?'Aviso aceito pelo transporte':($email==='nao_solicitado'&&!$ext?'Aviso não solicitado':'Aviso pendente ou suprimido')),'falha_sem_contingencia'=>$failed&&!$confirmed,'qualidade'=>$quality[$id]??null,'limite'=>'Entrega confirmada pelo transporte não comprova leitura humana ou venda.');
        }return $out;
    }
    public static function texto(array $r): string {
        $parts=array();foreach($r['canais']??array() as $k=>$v){$parts[]=array('email'=>'E-mail','slack'=>'Slack','webhook'=>'Webhook','pipedrive'=>'Pipedrive','visitante'=>'Resposta ao visitante')[$k].': '.str_replace('_',' ',$v['estado']);}
        if(($r['contingencia_email']??'nao_acionada')!=='nao_acionada'){$parts[]='Contingência por e-mail: '.str_replace('_',' ',$r['contingencia_email']);}return implode("\n",$parts);
    }
}
