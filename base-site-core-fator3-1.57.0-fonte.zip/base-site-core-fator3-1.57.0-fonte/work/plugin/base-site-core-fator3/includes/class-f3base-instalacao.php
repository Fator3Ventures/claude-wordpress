<?php
/** Ciclo próprio de cada release. Instalação nova ou atualização direta da base 1.33.0. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Instalacao {
    const OPTION = 'f3base_instalacao';
    const HISTORICO = 'f3base_instalacao_historico';
    private static ?array $lido = null;
    private static ?array $reserva = null;

    /** Physical reads distinguish absence, SQL failure and malformed state. Never repair here. */
    private static function ler(): array {
        global $wpdb;
        $raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,self::OPTION));
        if ($wpdb->last_error) { return array('ok'=>false,'codigo'=>'leitura_indisponivel'); }
        if ($raw===null) { return array('ok'=>true,'existe'=>false,'estado'=>array()); }
        $s=maybe_unserialize($raw);
        if (!is_array($s) || !is_string($s['versao']??null) || $s['versao']==='' || !is_array($s['etapas']??null)) {
            return array('ok'=>false,'codigo'=>'checkpoint_invalido');
        }
        foreach (array('iniciado_em','concluido_em','finalizacao_em','proxima_tentativa') as $k) {
            if (isset($s[$k]) && (!is_numeric($s[$k]) || (int)$s[$k]<0)) { return array('ok'=>false,'codigo'=>'checkpoint_invalido'); }
        }
        foreach ($s['etapas'] as $etapa) {
            if (!is_array($etapa) || (isset($etapa['concluido_em']) && !is_numeric($etapa['concluido_em']))) { return array('ok'=>false,'codigo'=>'checkpoint_invalido'); }
        }
        return array('ok'=>true,'existe'=>true,'estado'=>$s);
    }
    public static function origem(): string {
        $f=self::ler();
        if (!$f['ok']) { return $f['codigo']; }
        $s=$f['estado'];
        if ($f['existe']) {
            if ($s['versao']!==F3BASE_PLUGIN_VERSAO) { return 'existente'; }
            if (!empty($s['concluido_em'])) { return 'atual'; }
            return ($s['origem']??'existente')==='nova'?'nova':'existente';
        }
        global $wpdb;
        $tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_').'%'));
        if ($wpdb->last_error) { return 'leitura_indisponivel'; }
        $n=$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE option_name IN (%s,%s,%s,%s,%s)',$wpdb->options,'f3base_estrutura','f3base_leads_estrutura','f3base_contato','f3base_servidor','f3base_release_1310'));
        if ($wpdb->last_error) { return 'leitura_indisponivel'; }
        return !$tables && !(int)$n ? 'nova' : 'existente';
    }
    public static function permitida(): bool { return in_array(self::origem(),array('nova','existente','atual'),true) && F3Base_Email_Limpeza::precondicao(self::origem())===''; }
    public static function aviso(): void {
        if (current_user_can('manage_options')) { echo '<div class="notice notice-error"><p>Site Core: instalação bloqueada. Confira a Saúde; email_migracao_142_pendente exige concluir a migração na versão-base antes de atualizar. Nenhum dado foi redefinido.</p></div>'; }
    }
    public static function resumo(): array {
        $f=self::ler();
        $base=array('versao_alvo'=>F3BASE_PLUGIN_VERSAO,'ciclo_atual'=>false,'concluido_em'=>0,'finalizacao_em'=>0,'proxima_tentativa'=>0);
        if (!$f['ok']) { return array_merge($base,array('ok'=>false,'estado'=>'indisponivel','codigo'=>$f['codigo'])); }
        $blocked=F3Base_Email_Limpeza::precondicao(self::origem());if($blocked!==''){return array_merge($base,array('ok'=>false,'estado'=>'bloqueada','codigo'=>$blocked));}
        $s=$f['estado'];$current=($s['versao']??'')===F3BASE_PLUGIN_VERSAO;
        if (!$current) {
            return array_merge($base,array('ok'=>true,'estado'=>'atualizacao_pendente','versao'=>$s['versao']??null,'versao_anterior'=>$s['versao']??null,'etapas'=>array(),'etapa_atual'=>'novo_ciclo','origem'=>self::origem(),'coleta_adicional_desde'=>$s['coleta_adicional_desde']??null));
        }
        return array_merge($base,$s,array('ok'=>true,'ciclo_atual'=>true,'estado'=>!empty($s['finalizacao_em'])?'concluida':(!empty($s['concluido_em'])?'aguardando_confirmacao':(!empty($s['ultima_falha'])?'falha':'em_andamento'))));
    }
    /** A stale worker cannot replace a checkpoint changed by another executor. */
    private static function salvar(array $s): bool {
        if (self::$lido===null || self::$reserva===null || !F3Base_Trava::renovar(self::$reserva,180)) { return false; }
        $expected=self::$lido;
        $r=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($expected,$s){
            return F3Base_Options::equivalente(is_array($v)?$v:array(),$expected)?$s:null;
        },1);
        if (!empty($r['persisted'])) { self::$lido=$s; return true; }
        return false;
    }
    private static function arquivar(array $s,string $fonte): string {
        if (!$s) { return ''; }
        $hash=hash('sha256',serialize($s));
        $r=F3Base_Options::atualizar_estado(self::HISTORICO,static function($v)use($s,$hash,$fonte){
            $v=is_array($v)?$v:array();
            if (isset($v[$hash]) && !F3Base_Options::equivalente($v[$hash]['checkpoint']??null,$s)) { return null; }
            $v[$hash]=$v[$hash]??array('fonte'=>$fonte,'versao'=>$s['versao']??'1.31.0','arquivado_em'=>time(),'sha256'=>$hash,'checkpoint'=>$s);
            return $v;
        });
        if (empty($r['persisted'])) { throw new RuntimeException('historico_nao_persistido'); }
        return $hash;
    }
    private static function abrir(array $anterior,string $origem): array {
        $base=$anterior;$fonte=self::OPTION;
        if (!$base && $origem==='existente') {
            $foto=F3Base_Options::fotografia_bruta('f3base_release_1310');
            if ($foto['erro']) { throw new RuntimeException('base_leitura_indisponivel'); }
            if ($foto['existe'] && !is_array($foto['valor'])) { throw new RuntimeException('base_checkpoint_invalido'); }
            $base=$foto['existe']?$foto['valor']:array();$fonte='f3base_release_1310';
        }
        $ref=self::arquivar($base,$fonte);
        $s=array('versao'=>F3BASE_PLUGIN_VERSAO,'versao_anterior'=>$base['versao']??($base?'1.31.0':null),'ciclo'=>wp_generate_uuid4(),'origem'=>$origem,'iniciado_em'=>time(),'etapas'=>array(),'falhas'=>0,'proxima_tentativa'=>0,'historico_ref'=>$ref,
            'coleta_adicional_desde'=>array_key_exists('coleta_adicional_desde',$base)?$base['coleta_adicional_desde']:($origem==='nova'?time():null),
            'evidencia_instalacao_anterior'=>$base['evidencia_instalacao_anterior']??$base['consolidacao']??null);
        foreach (array('avisos_padroes','servidor_reconciliado_em','servidor_resultado') as $k) { if (array_key_exists($k,$base)) { $s[$k]=$base[$k]; } }
        if (!self::salvar($s)) { throw new RuntimeException('checkpoint_falhou'); }
        return $s;
    }
    public static function atualizar(): array {
        $origem=self::origem();
        if (!in_array($origem,array('nova','existente','atual'),true)) { return array('ok'=>false,'codigo'=>$origem); }
        $pre=F3Base_Email_Limpeza::precondicao($origem);if($pre!==''){return array('ok'=>false,'codigo'=>$pre,'persisted'=>false);}
        if (!F3Base_Recuperacao::provisionar() || !F3Base_Recuperacao::entrar()) { return array('ok'=>false,'codigo'=>'core_em_recuperacao'); }
        $lock=F3Base_Trava::adquirir('atualizacao-atual',180);
        if (!$lock) { F3Base_Recuperacao::sair(); return array('ok'=>false,'codigo'=>'atualizacao_em_execucao'); }
        self::$reserva=$lock;$s=array();$etapa='inicio';$aberto=false;
        try {
            $foto=self::ler();
            if (!$foto['ok']) { return array('ok'=>false,'codigo'=>$foto['codigo']); }
            $s=$foto['estado'];self::$lido=$s;
            if (($s['versao']??'')!==F3BASE_PLUGIN_VERSAO) { $origem=self::origem();$s=self::abrir($s,$origem); }
            $aberto=true;
            if (!empty($s['concluido_em'])) { return self::finalizar($s); }
            if ((int)($s['proxima_tentativa']??0)>time()) { return array('ok'=>true,'codigo'=>'atualizacao_em_recuo','status'=>'aguardando','proxima_tentativa'=>$s['proxima_tentativa']); }
            $origem=$s['origem']==='nova'?'nova':'existente';
            $steps=array(
                'retencoes_mensais'=>static fn()=>F3Base_Retencao_Prazos::migrar(),
                'linkedin_integracoes'=>static fn()=>F3Base_Linkedin_Integracoes::migrar(),
                'identidade_pipedrive'=>static fn()=>F3Base_Integracoes::migrar_identidade_pipedrive(),
                'padroes'=>static function()use($origem,&$s){
                    if($origem==='nova'){
                        if(!update_option('f3base_email_migracao_142','concluida',false)&&get_option('f3base_email_migracao_142')!=='concluida'){return false;}
                        foreach(array(F3Base_Options::OPTION_OPERAVEIS=>array('schema'=>1,'modo'=>'todas','lista'=>array()),'f3base_politica_canal'=>true,'f3base_contato'=>array('email_leads'=>is_email(get_option('admin_email'))?array(get_option('admin_email')):array())) as $n=>$v){if(!F3Base_Options::fotografia_bruta($n)['existe']){$r=F3Base_Options::gravar($n,$v,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao($n));if(empty($r['persisted'])){return false;}}}
                    }
                    $defaults=F3Base_Configuracao_Medicao::materializar_padroes();if(!empty($defaults['preservadas_com_diagnostico'])){$s['avisos_padroes']=$defaults['preservadas_com_diagnostico'];if(!self::salvar($s)){return false;}}return !empty($defaults['ok']);
                },
                'consentimento_capi'=>static function(){F3Base_Consentimento_Decisoes::instalar();F3Base_Modulo_Endpoint_Leads::instalar_recusas();return F3Base_Capi_Fila::instalar()&&F3Base_Atualizacao::verificar_estrutura();},
                'leads_analise'=>static function(){F3Base_Modulo_Comportamento::criar_tabela();F3Base_Vitais::instalar();return F3Base_Vitais::pronta()&&F3Base_Leads_Repositorio::instalar()&&F3Base_Analise::instalar()&&F3Base_Audiencia_Exclusoes::instalar()&&F3Base_Sondas_Http::instalar()&&F3Base_Clarity_Acervo::instalar()&&F3Base_Meta_Transporte::instalar();},
                'formularios_tentativas'=>static fn()=>F3Base_Formulario_Tentativas::instalar(),
                'integracoes'=>static fn()=>F3Base_Captura_Contexto::instalar()&&F3Base_Aquisicoes::instalar()&&F3Base_Conversoes_Servidor::instalar()&&F3Base_Email_Novo_Lead::instalar()&&F3Base_Email_Site::instalar()&&F3Base_Contatos_Sessoes::instalar()&&F3Base_Qualidade::instalar()&&F3Base_Slack::instalar()&&F3Base_Formulario_Complementos::instalar()&&F3Base_Sessoes::instalar()&&F3Base_Avisos::instalar()&&F3Base_Pipedrive_Fila::instalar()&&F3Base_Anuncios::instalar()&&F3Base_Linkedin_Webhook::instalar(),
                'conversoes_conteudo'=>static fn()=>F3Base_Conversoes_Conteudo::migrar(),
                'editorial'=>static function(){F3Base_Acessos_Coleta::instalar();F3Base_Agentes::instalar();return F3Base_Acessos_Legado::instalar()&&F3Base_Editorial::instalar()&&F3Base_Inteligencia::instalar();},
                'acervos'=>static fn()=>F3Base_Execucoes::instalar()&&F3Base_Gsc::instalar()&&F3Base_Ga4_Acervo::instalar()&&F3Base_Instagram_Exclusao::instalar(),
                'intencoes_estrutura'=>static fn()=>F3Base_Operacao_Intencoes::instalar(),
                'diagnosticos_configuracao'=>static fn()=>F3Base_Configuracao_Medicao::importar_avisos(),
                'manutencao_local'=>static function(){F3Base_Leads_Repositorio::retomar_eliminacoes();return !empty(F3Base_Cache_Orcamento::limpar()['ok']);},
                'pasta_privada'=>static fn()=>!empty(F3Base_Arquivos_Privados::provisionar()['ok']),
                'verificacao'=>static fn()=>self::verificar(),
                'agendas'=>static fn()=>self::agendas(),
            );
            $order=array('retencoes_mensais','linkedin_integracoes','identidade_pipedrive','intencoes_estrutura','consentimento_capi','leads_analise','formularios_tentativas','integracoes','conversoes_conteudo','editorial','acervos','padroes','diagnosticos_configuracao','manutencao_local','pasta_privada','verificacao','agendas');$steps=array_replace(array_fill_keys($order,null),$steps);

            foreach ($steps as $etapa=>$callback) {
                if (!empty($s['etapas'][$etapa]['concluido_em'])) { continue; }
                $s['etapa_atual']=$etapa;$s['tentativa_em']=time();
                if (!self::salvar($s)) { throw new RuntimeException('checkpoint_falhou'); }
                $result=$callback();
                if ($result===false || (is_array($result)&&empty($result['ok']))) { throw new RuntimeException(is_array($result)?($result['codigo']??'etapa_nao_confirmada'):'etapa_nao_confirmada'); }
                if (is_array($result)&&isset($result['cursor'])) { $s['cursores'][$etapa]=$result['cursor']; }
                if (is_array($result)&&empty($result['concluido'])) {
                    $s['proxima_tentativa']=time()+5;$s['ultima_falha']=null;
                    if (!self::salvar($s)) { throw new RuntimeException('checkpoint_falhou'); }
                    return array('ok'=>true,'parcial'=>true,'codigo'=>'atualizacao_em_lotes','etapa'=>$etapa,'proxima_tentativa'=>$s['proxima_tentativa']);
                }
                $s['etapas'][$etapa]=array('concluido_em'=>time());$s['ultima_falha']=null;
                if (!self::salvar($s)) { throw new RuntimeException('checkpoint_falhou'); }
            }
            $etapa='conclusao';
            $structure=F3Base_Options::atualizar_estado(F3Base_Atualizacao::OPTION,static fn($v)=>array_merge(is_array($v)?$v:array(),array('versao'=>F3Base_Atualizacao::VERSAO,'confirmada_em'=>time(),'codigo'=>'estrutura_confirmada')));
            if (empty($structure['persisted'])) { throw new RuntimeException('estrutura_nao_persistida'); }
            $s=array_merge($s,array('concluido_em'=>time(),'proxima_tentativa'=>0,'ultima_falha'=>null,'etapa_atual'=>'concluida'));
            if (!self::salvar($s)) { throw new RuntimeException('checkpoint_falhou'); }
            wp_clear_scheduled_hook(F3Base_Atualizacao::EVENTO);F3Base_Fila::agendar(F3Base_Atualizacao::EVENTO,time()+60);
            return array('ok'=>true,'persisted'=>true,'codigo'=>'atualizacao_concluida','versao'=>F3BASE_PLUGIN_VERSAO,'ciclo'=>$s['ciclo']);
        } catch (Throwable $e) {
            $codigo=sanitize_key($e->getMessage());
            if ($aberto && self::$lido!==null) {
                // Never stamp a failed opening into an old version or overwrite another writer.
                $s=self::$lido;$s['falhas']=(int)($s['falhas']??0)+1;
                $s['ultima_falha']=array('etapa'=>$etapa,'codigo'=>$codigo,'em'=>time());
                $s['proxima_tentativa']=time()+min(3600,300*2**min(4,$s['falhas']-1));self::salvar($s);
            }
            return array('ok'=>false,'codigo'=>'atualizacao_pendente','causa'=>$codigo,'etapa'=>$etapa,'proxima_tentativa'=>$aberto?($s['proxima_tentativa']??0):0);
        } finally {
            F3Base_Trava::liberar(self::$reserva??$lock);self::$reserva=null;self::$lido=null;F3Base_Recuperacao::sair();
        }
    }
    public static function observar(): void {
        $r=self::resumo();
        if (!empty($r['ok']) && (empty($r['ciclo_atual']) || empty($r['finalizacao_em']))) { F3Base_Atualizacao::agendar(); }
    }
    private static function finalizar(array $s): array {
        if (($s['versao']??'')!==F3BASE_PLUGIN_VERSAO || empty($s['concluido_em'])) { return array('ok'=>false,'codigo'=>'ciclo_nao_concluido'); }
        if (!empty($s['finalizacao_em'])) { return array('ok'=>true,'codigo'=>'atual','ciclo'=>$s['ciclo']??null); }
        if (time()<(int)$s['concluido_em']+60) { F3Base_Fila::agendar(F3Base_Atualizacao::EVENTO,(int)$s['concluido_em']+60);return array('ok'=>true,'codigo'=>'aguarda_confirmacao_executor'); }
        $s['confirmada_no_executor_em']=time();
        if (!self::salvar($s)) { return array('ok'=>false,'codigo'=>'checkpoint_falhou'); }
        if (empty($s['servidor_reconciliado_em']) && $s['origem']==='nova') {
            $server=F3Base_Servidor::reconciliar_instalacao();$s['servidor_reconciliado_em']=time();
            $s['servidor_resultado']=array('ok'=>!empty($server['ok']),'codigo'=>$server['codigo']??$server['status']??'consultar_servidor','verificacao'=>'Consulte f3base/servidor-aplicar com acao consultar para a prova vigente.');
        }
        $s['finalizacao_em']=time();$ok=self::salvar($s);
        return array('ok'=>$ok,'persisted'=>$ok,'codigo'=>$ok?'finalizacao_concluida':'checkpoint_falhou','ciclo'=>$s['ciclo']??null);
    }
    private static function agendas(): bool {
        foreach(array('f3base_consentimento_indexar','f3base_aparelhos_historico') as $retirado){if(wp_clear_scheduled_hook($retirado,array(),true)===false){return false;}}
        foreach(array(F3Base_Sessoes::EVENTO,F3Base_Formulario_Complementos::EVENTO) as $hook){if(!wp_next_scheduled($hook)){if(!wp_schedule_single_event(time()+60,$hook)){return false;}}if(!wp_next_scheduled($hook)){return false;}}
        F3Base_Navegacao::agendar();F3Base_Editorial::agendar();F3Base_Llms_Cobertura::agendar();foreach(array(F3Base_Navegacao::EVENTO,F3Base_Editorial::EVENTO) as $hook){if(!wp_next_scheduled($hook)){return false;}}return true;
    }
    public static function verificar(): bool {
        global $wpdb;if(!F3Base_Atualizacao::verificar_estrutura()){return false;}
        $required=array('f3base_ga4_coletas'=>array('id','propriedade','recorte','dia','estado','cursor','revision','publicado'),'f3base_ga4_linhas'=>array('coleta_id','chave','dimensoes','metricas'),'f3base_instagram_exclusoes'=>array('record_id','alvo','estado','recibo'),'f3base_contato_sessoes'=>array('sessao','record_id','classe','vinculado_em'),'f3base_email_site'=>array('id','chave','contexto','uidvalidity','uid','payload','movida_em','crm_em','aviso_em'),'f3base_email_novo_lead'=>array('atividade_id','atividade_prova','enviado_em'),'f3base_formulario_tentativas'=>array('evento','sessao','instancia','valores','titulares'),'f3base_vitais'=>array('automacao','automacao_motivos','automacao_regra','atribuicao'),'f3base_anuncios_recibos'=>array('submissao_ms'),'f3base_linkedin_webhook'=>array('chave','tipo','contexto','formulario','resposta','ocorrido_ms','estado','payload'),'f3base_pipedrive_fila'=>array('qualidade_proxima','qualidade_ultima','qualidade_hash','qualidade_confirmada','qualidade_encerrada','qualidade_terminal_contagem','qualidade_contexto'),'f3base_slack_manutencao'=>array('ausencia_em','remocao_aceita_em','id','tipo','teste','site','destino','team_id','bot_id','user_id','ts','payload','revisao'),'f3base_sessoes'=>array('classe','sessao','visitante','inicio','origem'),'f3base_contato_campanhas'=>array('record_id','campanha','sessoes'),'f3base_complementos'=>array('chave','record_id','payload','estado'),'f3base_avisos_partes'=>array('chave','principal','canal','ts','payload'),'f3base_sondas_http'=>array('dia','chave','caminho','metodo','status','classe','quantidade'),'f3base_avisos_fila'=>array('chave','record_id','estado','payload','reserva','reserva_ate','contingencia'),'f3base_audiencia_404'=>array('dia','caminho','contagem','amostras','ultimo_em'),'f3base_operacao_intencoes'=>array('chave','escopo','estado','falhas','quota_adiamentos','tentar_em','reserva','reserva_ate'),'f3base_leads'=>array('decisao_ref'),'f3base_eventos'=>array('recebido_em'),'f3base_gsc_lacunas'=>array('universo','dia','estado'),'f3base_conversoes_servidor'=>array('telefone_estado','http'),'f3base_analise'=>array('automacao_evidencia','publicidade','decisao_ref','clique_rotulo','clique_destino','oferta_id','oferta_tipo','oferta_instancia','largura_faixa','navegador','sistema','retorno','aparelho'),'f3base_execucoes'=>array('run_id','origem','parent_run_id','ocorrencia'),'f3base_gsc_coletas'=>array('id','propriedade','dia','estado','cursor','revision'),'f3base_gsc_linhas'=>array('coleta_id','chave','url'),'f3base_clarity_coletas'=>array('id','estado','recebido_em'),'f3base_clarity'=>array('coleta','metrica'),'f3base_meta_eventos'=>array('evento','rota','classe_trafego'));
        foreach($required as $suffix=>$cols){$t=$wpdb->prefix.$suffix;$actual=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if($wpdb->last_error||array_diff($cols,$actual)){return false;}}return true;
    }
}
