<?php
/** One reversible effective classification, at query time, over original evidence. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Agentes_Classificacao {
    const REGRA='rede-efetiva-2';
    const ASSINATURA_REGRA='produtos-1';
    public static function ia(string $familia): bool {return in_array(F3Base_Modulo_Acessos_Servidor::classe_agente($familia),array('busca-ia','resposta-ia','treino-ia','agente-hospedado','coleta-solicitada'),true);}
    public static function efetiva(array $r): array {
        $original=$r['agente_declarado']??$r['agente'];$r['agente_declarado']=$original;$r['finalidade_declarada']=F3Base_Modulo_Acessos_Servidor::classe_agente($original);
        $suspeita=($r['rede_estado']??'')==='fora_das_faixas';
        $r['agente']=$suspeita?'automacao-suspeita':$original;$r['classificacao_regra']=self::REGRA;$r['classificacao_motivo']=$suspeita?'ip_fora_das_faixas_oficiais':'';return $r;
    }
    public static function assinatura(string $ua): array {
        // Match known product tokens only. No versions, comments, URLs, addresses, hashes or free text.
        $known=array('curl'=>'~(?:^|[\s;(])curl(?:/|\s|$)~i','python-requests'=>'~\bpython-requests(?:/|\s|$)~i','python-urllib'=>'~\bpython-urllib(?:/|\s|$)~i','wget'=>'~\bWget(?:/|\s|$)~i','go-http-client'=>'~\bGo-http-client(?:/|\s|$)~i','okhttp'=>'~\bokhttp(?:/|\s|$)~i','node-fetch'=>'~\bnode-fetch(?:/|\s|$)~i','axios'=>'~\baxios(?:/|\s|$)~i','httpclient'=>'~\b(?:Apache-HttpClient|Java|libwww-perl|GuzzleHttp)(?:/|\s|$)~i','headlesschrome'=>'~\bHeadlessChrome/\d~i','wordpress'=>'~\bWordPress/\d~i','uptimerobot'=>'~\bUptimeRobot/\d~i','pingdom'=>'~\bPingdom(?:\.com)?~i');
        $labels=array();foreach($known as $label=>$regex){if(preg_match($regex,substr($ua,0,4096))){$labels[]=$label;}}
        // A bounded combination of at most three fixed vocabulary products.
        return array('assinatura_ua'=>$labels?implode('+',array_slice($labels,0,3)):'desconhecida','assinatura_regra'=>self::ASSINATURA_REGRA);
    }
    public static function expressao(string $col='agente'): string {
        if(!preg_match('/^[a-z_.]+$/D',$col)){throw new InvalidArgumentException('coluna_invalida');}
        $prefix=str_contains($col,'.')?substr($col,0,strrpos($col,'.')+1):'';
        // fora_das_faixas is emitted only by a published, valid range source.
        return "CASE WHEN {$prefix}rede_estado='fora_das_faixas' THEN 'automacao-suspeita' ELSE {$col} END";
    }
    /** Derived read-only source exposes effective family while preserving the declared one. */
    public static function fonte(string $t,bool $horaria=false): string {
        global $wpdb;$columns=array('dia','classe_caminho','dimensao','post_id','tipo_conteudo','representacao','resolucao','rede_estado','rede_lista','rede_data','rede_versao','assinatura_ua','assinatura_regra','caminho','status','metodo','contagem');
        $columns=array_merge($columns,$horaria?array('hora_utc','status_grupo'):array('primeiro_em','ultimo_em','instantes_validos'));
        return '(SELECT '.implode(',',$columns).',agente AS agente_declarado,'.self::expressao().' AS agente FROM '.$wpdb->prepare('%i',$t).') f3_efetivos';
    }
}
