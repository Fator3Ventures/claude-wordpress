<?php
/**
 * Leitura do motivo quando uma ability de outro pacote, chamada pelo próprio
 * WordPress (sem passar pelo transporte MCP), não executa.
 *
 * O DEFEITO MEDIDO (1.48.0 com Fator3 MCP 0.28.0 ativo): a tela de anúncios chama
 * `linkedin/admin-options` e `ads/search` em processo; o MCP 0.28.0 intercepta a
 * execução nativa sem conexão MCP e devolve `profile_denied`/`permission_denied`.
 * O Core trocava qualquer recusa por `linkedin_catalogo_indisponivel` ou
 * `google_catalogo_indisponivel`, e o administrador não tinha como saber que a
 * consulta nem chegou ao fornecedor.
 *
 * A saída preserva o código genérico para motivos desconhecidos e acrescenta
 * `motivo`, `ability` e `mensagem`; recusas do canal e de permissão ganham
 * código próprio e instrução de ação. Nenhum dado da resposta além do código
 * sanitizado é repassado.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Utilitário sem estado. */
final class F3Base_Abilities_Nativas {

	/** Códigos com que o Fator3 MCP recusa uma execução nativa fora de conexão MCP. */
	const RECUSAS_DO_CANAL = array( 'profile_denied', 'connection_context_required', 'connection_required', 'policy_denied' );

	/** Códigos de permissão recusada (núcleo Abilities API ou envelope do canal). */
	const RECUSAS_DE_PERMISSAO = array( 'ability_invalid_permissions', 'permission_denied', 'rest_forbidden' );

	/** Versão do Fator3 MCP carregado, pela constante pública do pacote; null quando ausente. */
	public static function versao_mcp(): ?string {
		$v = defined( 'F3_MCP_FILES_VERSION' ) ? (string) constant( 'F3_MCP_FILES_VERSION' ) : '';
		return preg_match( '/^[0-9]+\.[0-9]+\.[0-9]+$/D', $v ) ? $v : null;
	}

	/** Motivo sanitizado de uma resposta de ability malsucedida. */
	public static function motivo( $resultado ): string {
		$motivo = '';
		if ( is_wp_error( $resultado ) ) {
			$motivo = (string) $resultado->get_error_code();
		} elseif ( is_array( $resultado ) ) {
			$motivo = (string) ( $resultado['error_code'] ?? $resultado['code'] ?? '' );
		} elseif ( $resultado instanceof Throwable ) {
			$motivo = 'excecao_na_integracao';
		}
		return substr( sanitize_key( $motivo ), 0, 64 );
	}

	/**
	 * Resposta de falha acionável.
	 *
	 * @param mixed  $resultado WP_Error, envelope da ability ou Throwable.
	 * @param string $padrao    Código genérico já publicado pela rota.
	 * @param string $ability   Ability chamada.
	 * @return array<string,mixed>
	 */
	public static function falha( $resultado, string $padrao, string $ability ): array {
		$motivo = self::motivo( $resultado );
		$base   = array(
			'ok'      => false,
			'motivo'  => '' === $motivo ? 'resposta_sem_codigo' : $motivo,
			'ability' => $ability,
		);
		if ( in_array( $motivo, self::RECUSAS_DO_CANAL, true ) ) {
			$mcp = self::versao_mcp();
			/*
			 * A partir do 0.29.0 o canal libera a chamada nativa do administrador
			 * em requisição web administrativa (tela, admin-ajax/admin-post com
			 * nonce, REST com cookie e nonce); linha de comando, cron e tarefa
			 * agendada seguem exigindo conexão MCP. A mensagem distingue os casos.
			 */
			$mensagem = null !== $mcp && version_compare( $mcp, '0.29.0', '>=' )
				? sprintf( 'O Fator3 MCP %3$s recusou a chamada nativa de %1$s (%2$s): fora de uma requisição administrativa web com nonce (linha de comando, cron ou tarefa agendada) o canal exige conexão MCP autorizada. A consulta não chegou ao fornecedor; repita pela tela do WordPress.', $ability, $motivo, $mcp )
				: sprintf( 'O Fator3 MCP instalado recusou a chamada administrativa nativa de %1$s (%2$s); a consulta não chegou ao fornecedor. Atualize o Fator3 MCP para 0.29.0 ou superior.', $ability, $motivo );
			return array(
				'codigo'     => 'mcp_recusou_chamada_nativa',
				'mensagem'   => $mensagem,
				'mcp_versao' => $mcp,
			) + $base;
		}
		if ( in_array( $motivo, self::RECUSAS_DE_PERMISSAO, true ) ) {
			return array(
				'codigo'   => 'permissao_recusada_pela_integracao',
				'mensagem' => sprintf( 'A chamada a %1$s foi recusada por permissão (%2$s). Confira no plugin da integração se o serviço está configurado e autorizado para este administrador. %3$s', $ability, $motivo, null !== self::versao_mcp() && version_compare( (string) self::versao_mcp(), '0.29.0', '>=' ) ? 'Fora de requisição administrativa web com nonce (linha de comando, cron), o Fator3 MCP também recusa a chamada nativa.' : 'Com o Fator3 MCP 0.28.0 ou anterior ativo, a recusa pode vir do canal, corrigida no 0.29.0.' ),
			) + $base;
		}
		return array(
			'codigo'   => $padrao,
			'mensagem' => sprintf( 'A integração não concluiu %1$s (%2$s).', $ability, $base['motivo'] ),
		) + $base;
	}
}
