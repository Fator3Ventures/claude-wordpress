<?php
/** Private conversation contacts. No web events, ad conversions or visitor e-mail. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Conversas {
    public static function conversa(array $r): bool {return in_array($r['metodo']??'',array('whatsapp_conversa','instagram_conversa'),true);}
    public static function persistir(string $method,string $key,array $private,array $policy): array {
        if(!in_array($method,array('whatsapp_conversa','instagram_conversa'),true)||!preg_match('/^[a-f0-9]{64}$/D',$key)){return array('persisted'=>false,'codigo'=>'conversa_identidade_invalida');}
        $lock=F3Base_Trava::adquirir('conversa-'.$key,60);if(!$lock){return array('persisted'=>false,'codigo'=>'conversa_ocupada');}
        try{
            global $wpdb;$t=F3Base_Leads_Repositorio::tabela();$old=$wpdb->get_row($wpdb->prepare('SELECT record_id,captura,eliminacao_pendente FROM %i WHERE idempotencia=%s',$t,$key),ARRAY_A);
            if($wpdb->last_error){return array('persisted'=>false,'codigo'=>'conversa_leitura_falhou');}
            if($old){return array('persisted'=>!$old['eliminacao_pendente']&&!in_array($old['captura'],array('eliminado','eliminando'),true),'suppressed'=>(bool)$old['eliminacao_pendente']||in_array($old['captura'],array('eliminado','eliminando'),true),'record_id'=>$old['record_id'],'idempotency_key'=>$key,'duplicado'=>true);}
            $test=!empty($private['contexto_teste']);$crm=!$test&&!empty($policy['pipedrive']);$notify=!$test&&!empty($policy['slack']);$cfg=F3Base_Options::ler('f3base_pipedrive');
            if($crm&&empty($cfg['mapa_pontos'][$policy['ponto']??''])){return array('persisted'=>false,'codigo'=>'pipedrive_ponto_nao_mapeado');}
            $private+=array('nome'=>'','email'=>'','telefone'=>'','empresa'=>'','origem_declarada'=>array());$private['metodo']=$method;$private['pipedrive']=array('acao'=>$crm?'entregar':'nenhuma','ponto'=>$policy['ponto']??'');
            $private['registro']=array('em'=>gmdate('c'),'operador_id'=>(int)($policy['operador']??0));
            $record=bin2hex(random_bytes(16));$notice=F3Base_Avisos::intencao($notify);$notice['canal']='slack';$notice['sem_email']=true;
            if($notify&&!in_array($notice['transporte'],array('slack','slack_app'),true)){return array('persisted'=>false,'codigo'=>'conversa_aviso_slack_nao_configurado');}
            $data=array('contato_externo_cifrado'=>F3Base_Contato_Comunicacao::cifrar($private),'origem_nativa'=>array('origem'=>$method),'contexto_teste'=>$test,'email_novo_lead_intencao'=>array('solicitado'=>false),'aviso_intencao'=>$notice,'conversoes_bloqueadas'=>true);
            $intent=array('pipedrive'=>array('solicitado'=>$crm,'motivo'=>$crm?'conversa_solicitada':'conversa_sem_entrega','dominio'=>$crm?$cfg['dominio']:'','em'=>time(),'versao'=>F3BASE_PLUGIN_VERSAO));
            $ok=$wpdb->insert($t,array('record_id'=>$record,'metodo'=>$method,'classe_trafego'=>$test?'teste':'nao_marcado','criado_em'=>gmdate('Y-m-d H:i:s',(int)strtotime($private['primeiro_contato_em'])),'atualizado_em'=>gmdate('Y-m-d H:i:s'),'nome'=>'','email'=>'','pagina'=>'','dados'=>wp_json_encode($data),'entrega'=>wp_json_encode($intent),'anexos'=>'[]','idempotencia'=>$key,'payload_hash'=>$key,'origem_chave'=>'conversa:'.$key,'aviso'=>$notify?'slack':'desligado'));
            if($ok!==1){return array('persisted'=>false,'codigo'=>'conversa_persistencia_falhou');}
            $lead=F3Base_Leads_Repositorio::obter($record);if($crm){F3Base_Pipedrive_Fila::enfileirar($lead);}if($notify){F3Base_Avisos::capturado($lead);}
            return array('persisted'=>true,'record_id'=>$record,'idempotency_key'=>$key,'duplicado'=>false,'efeitos'=>array('slack'=>$notify,'pipedrive'=>$crm,'email_automatico'=>false,'conversoes'=>false));
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function catalogo_grupo(string $name,string $label,array $defaults,array $props,callable $validate): array {
        $schema=array('type'=>'object','properties'=>$props,'additionalProperties'=>false);
        return array('rotulo'=>$label,'descricao'=>'Entrada optativa de conversas; configuração administrativa e dados cifrados.','operavel'=>true,'secao'=>'integracoes','campo'=>'grupo','autoload'=>false,'padrao'=>$defaults,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>$validate);
    }
}
