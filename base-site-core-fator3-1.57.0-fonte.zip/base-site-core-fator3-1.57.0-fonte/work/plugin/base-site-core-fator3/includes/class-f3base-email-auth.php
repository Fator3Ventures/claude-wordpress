<?php
/** Local message authentication. No header assertion from an unlisted authserv decides acceptance or rejection. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Auth {
    private F3Base_Email_Dns $dns;
    private array $policies=array();
    public function __construct(?F3Base_Email_Dns $dns=null){$this->dns=$dns??new F3Base_Email_Dns();}
    public static function headers(string $raw): array {
        $parts=explode("\r\n\r\n",$raw,2);if(count($parts)!==2||strlen($parts[0])>262144){throw new RuntimeException('email_cabecalhos_invalidos');}
        $lines=preg_split('/\r\n(?![ \t])/',$parts[0]);$out=array();if(count($lines)>500){throw new RuntimeException('email_cabecalhos_invalidos');}
        foreach($lines as $line){if(!preg_match('/^([!-9;-~]+):(.*)$/sD',$line,$m)){throw new RuntimeException('email_cabecalhos_invalidos');}$out[]=array('name'=>strtolower($m[1]),'raw'=>$line,'value'=>$m[2]);}return array($out,$parts[1]);
    }
    public static function tags(string $v): array {
        $out=array();foreach(explode(';',$v) as $piece){if(trim($piece)===''){continue;}if(!preg_match('/^\s*([a-z][a-z0-9_]*)\s*=\s*(.*?)\s*$/isD',$piece,$m)){throw new RuntimeException('email_tags_invalidas');}$k=strtolower($m[1]);if(isset($out[$k])){throw new RuntimeException('email_tags_duplicadas');}$out[$k]=$m[2];}return $out;
    }
    private static function values(array $headers,string $name): array {return array_values(array_map(static fn($h)=>$h['value'],array_filter($headers,static fn($h)=>$h['name']===$name)));}
    private static function unfolded(string $v): string {return trim(preg_replace('/\r\n[ \t]+/',' ',$v));}
    private static function trusted(string $host,array $patterns): bool {
        $host=strtolower(rtrim($host,'.'));foreach($patterns as $p){$p=strtolower($p);if($host===$p||str_starts_with($p,'*.')&&str_ends_with($host,substr($p,1))){return true;}}return false;
    }
    /** Only the leading trusted Received chain. Stop at the first public boundary; never skip an untrusted top hop. */
    public static function boundary(array $headers,array $patterns): array {
        foreach(self::values($headers,'received') as $raw){
            $v=self::unfolded($raw);if(!preg_match('/\bby\s+([a-z0-9.-]+)(?:\s|[;(])/i',$v,$by)||!self::trusted($by[1],$patterns)){return array();}
            if(!preg_match('/^from\s+([^\s(]+)(.*?)\s+by\s/is',$v,$from)){return array();}
            preg_match_all('/\[(?:IPv6:)?([0-9a-f:.]+)\]/i',$from[2],$matches);$ip='';foreach($matches[1] as $candidate){if(filter_var($candidate,FILTER_VALIDATE_IP)){$ip=$candidate;}}
            // A trusted hostname in HELO is not evidence: only a private relay address may continue inward.
            if($ip!==''&&filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)){return array('ip'=>$ip,'helo'=>strtolower(rtrim($from[1],'.')),'mx'=>strtolower($by[1]));}
            if($ip===''||!self::trusted($from[1],$patterns)){return array();}
        }return array();
    }
    public static function canonical_header(string $raw,string $mode): string {
        if($mode==='simple'){return $raw."\r\n";}
        [$name,$v]=explode(':',$raw,2);$v=preg_replace('/\r\n/','',$v);$v=trim(preg_replace('/[ \t]+/',' ',$v)," \t");return strtolower($name).':'.$v."\r\n";
    }
    public static function canonical_body(string $body,string $mode): string {
        if($mode==='relaxed'){$body=preg_replace('/[ \t]+(?=\r\n|$)/','',$body);$body=preg_replace('/[ \t]+/',' ',$body);}
        $body=preg_replace('/(?:\r\n)*$/D','',$body);return $body===''&&$mode==='relaxed'?'':$body."\r\n";
    }
    private function dkim(array $headers,string $body,int $index): array {
        $h=$headers[$index];$t=self::tags($h['value']);$domain=strtolower($t['d']??'');$out=array('dominio'=>$domain,'resultado'=>'fail');
        foreach(array('v','a','b','bh','d','h','s') as $tag){if(!isset($t[$tag])||$t[$tag]===''){return $out;}}
        if($t['v']!=='1'||!in_array(strtolower($t['a']),array('rsa-sha256','ed25519-sha256'),true)||!F3Base_Email_Dns::domain($domain)||!F3Base_Email_Dns::domain($t['s'])){return $out;}
        if(isset($t['q'])&&!in_array('dns/txt',array_map('trim',explode(':',strtolower($t['q']))),true)){return $out;}
        foreach(array('t','x') as $tag){if(isset($t[$tag])&&(!ctype_digit($t[$tag])||strlen($t[$tag])>12)){return $out;}}
        if(isset($t['x'])&&((int)$t['x']<time()||isset($t['t'])&&(int)$t['x']<=(int)$t['t'])){return $out;}
        $identity=$t['i']??'@'.$domain;$at=strrpos($identity,'@');$idomain=$at===false?'':strtolower(substr($identity,$at+1));if($idomain!==$domain&&!str_ends_with($idomain,'.'.$domain)){return $out;}
        $c=explode('/',strtolower($t['c']??'simple/simple'));if(count($c)>2){return $out;}$cm=$c[0];$cb=$c[1]??'simple';if(!in_array($cm,array('simple','relaxed'),true)||!in_array($cb,array('simple','relaxed'),true)){return $out;}
        $canonical=self::canonical_body($body,$cb);
        // Partial-body signatures are insufficient for this ingestion policy: all delivered text must be authenticated.
        if(isset($t['l'])&&(!ctype_digit($t['l'])||strlen($t['l'])>10||(int)$t['l']!==strlen($canonical))){return $out;}
        $bh=base64_decode(preg_replace('/\s/','',$t['bh']),true);if($bh===false||!hash_equals(hash('sha256',$canonical,true),$bh)){return $out;}
        $signed=array_map('strtolower',array_map('trim',explode(':',self::unfolded($t['h']))));if(!in_array('from',$signed,true)||count($signed)>200){return $out;}$used=array($index=>true);$bytes='';
        foreach($signed as $name){if(!preg_match('/^[!-9;-~]+$/D',$name)){return $out;}for($i=count($headers)-1;$i>=0;$i--){if(!isset($used[$i])&&$headers[$i]['name']===$name){$used[$i]=true;$bytes.=self::canonical_header($headers[$i]['raw'],$cm);break;}}}
        [$hn,$hv]=explode(':',$h['raw'],2);$hv=preg_replace('/(^|;)([ \t\r\n]*b[ \t]*=)[^;]*/i','$1$2',$hv);$bytes.=substr(self::canonical_header($hn.':'.$hv,$cm),0,-2);
        $keys=array_values(array_filter(array_column($this->dns->query($t['s'].'._domainkey.'.$domain),'value'),static fn($v)=>!preg_match('/^\s*v\s*=/i',$v)||preg_match('/^\s*v\s*=\s*DKIM1\s*(?:;|$)/i',$v)));
        if(count($keys)!==1){return $out;}$key=self::tags($keys[0]);if(isset($key['v'])&&$key['v']!=='DKIM1'||!isset($key['p'])||trim($key['p'])===''){return $out;}
        if(isset($key['h'])&&!in_array('sha256',array_map('trim',explode(':',strtolower($key['h']))),true)){return $out;}
        if(isset($key['s'])&&!array_intersect(array('*','email'),array_map('trim',explode(':',strtolower($key['s']))))){return $out;}
        $flags=array_map('trim',explode(':',strtolower($key['t']??'')));if(in_array('s',$flags,true)&&$idomain!==$domain){return $out;}
        $public=base64_decode(preg_replace('/\s/','',$key['p']),true);$signature=base64_decode(preg_replace('/\s/','',$t['b']),true);if($public===false||$signature===false){return $out;}
        if(strtolower($t['a'])==='ed25519-sha256'){
            if(($key['k']??'rsa')!=='ed25519'||strlen($public)!==32||strlen($signature)!==64||!function_exists('sodium_crypto_sign_verify_detached')){return $out;}
            $valid=sodium_crypto_sign_verify_detached($signature,hash('sha256',$bytes,true),$public);
        }else{
            if(($key['k']??'rsa')!=='rsa'){return $out;}$pub=@openssl_pkey_get_public("-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($public),64,"\n")."-----END PUBLIC KEY-----\n");if(!$pub){return $out;}$info=openssl_pkey_get_details($pub);if(($info['type']??-1)!==OPENSSL_KEYTYPE_RSA||$info['bits']<1024||$info['bits']>8192){return $out;}$valid=openssl_verify($bytes,$signature,$pub,OPENSSL_ALGO_SHA256)===1;
        }
        $out['resultado']=$valid?'pass':'fail';return $out;
    }
    private function record(string $domain): ?array {
        if(array_key_exists($domain,$this->policies)){return $this->policies[$domain];}
        $records=array_values(array_filter(array_column($this->dns->query('_dmarc.'.$domain),'value'),static fn($x)=>preg_match('/^v=DMARC1\s*(?:;|$)/D',$x)));
        if(count($records)!==1){return $this->policies[$domain]=null;}
        try{$t=self::tags($records[0]);}catch(Throwable $x){return $this->policies[$domain]=null;}
        foreach(array('p','sp','np') as $k){if(($k==='p'||isset($t[$k]))&&!in_array($t[$k]??'',array('none','quarantine','reject'),true)){if(!empty($t['rua'])&&preg_match('/(?:^|,)\s*mailto:[^\s,@]+@[^\s,]+/',$t['rua'])){$t['p']='none';unset($t['sp'],$t['np']);break;}return $this->policies[$domain]=null;}}
        foreach(array('adkim','aspf') as $k){if(!in_array($t[$k]??'r',array('r','s'),true)){return $this->policies[$domain]=null;}}
        return $this->policies[$domain]=$t;
    }
    /** RFC 9989 bounded DNS tree walk; at most eight positions, no guessed last-two-label suffix. */
    private function tree(string $domain): array {
        $name=$domain;$records=array();for($i=0;$i<8;$i++){
            $t=$this->record($name);if($t){$records[$name]=$t;if(in_array($t['psd']??'',array('n','y'),true)){break;}}
            $labels=explode('.',$name);if(count($labels)<=1){break;}$labels=count($labels)>=8?array_slice($labels,-7):array_slice($labels,1);$name=implode('.',$labels);
        }
        $org=$domain;foreach($records as $name=>$t){$org=$name;if(($t['psd']??'')==='n'){break;}if(($t['psd']??'')==='y'&&$name!==$domain){$labels=explode('.',$domain);$org=implode('.',array_slice($labels,-count(explode('.',$name))-1));break;}}
        return array('org'=>$org,'records'=>$records);
    }
    private function policy(string $domain): array {
        $own=$this->record($domain);if($own){return array('domain'=>$domain,'tags'=>$own,'policy'=>$own['p']);}
        $tree=$this->tree($domain);$records=$tree['records'];if(!$records){return array('domain'=>'','tags'=>array(),'policy'=>'none');}
        $name=isset($records[$tree['org']])?$tree['org']:array_key_last($records);$t=$records[$name];
        // NODATA is not NXDOMAIN: only a confirmed nonexistent author domain selects np.
        $policy=isset($t['np'])&&!$this->dns->exists($domain)?$t['np']:($t['sp']??$t['p']);
        return array('domain'=>$name,'tags'=>$t,'policy'=>$policy);
    }
    private function aligned(string $authenticated,string $from,string $mode): bool {
        if($authenticated===$from){return true;}if($mode==='s'){return false;}return $this->tree($authenticated)['org']===$this->tree($from)['org'];
    }
    public function verificar(string $raw,array $cfg,string $sender): array {
        $out=array('metodo'=>'verificacao_propria','dmarc'=>'none','politica'=>'none','dkim'=>array(),'spf'=>'none','alinhado'=>false,'temporario'=>false,'aceito'=>false,'descartar'=>false,'verificado_em'=>time());
        try{
            [$headers,$body]=self::headers($raw);if(count(self::values($headers,'from'))!==1){$out['motivo']='from_ambiguo';return $out;}
            $domain=strtolower(substr(strrchr($sender,'@')?:'',1));if(!F3Base_Email_Dns::domain($domain)){$out['motivo']='from_invalido';return $out;}
            $trusted=null;foreach(self::values($headers,'authentication-results') as $value){$v=self::unfolded($value);$parts=explode(';',$v,2);$id=strtolower(trim($parts[0]));if(!in_array($id,array_map('strtolower',$cfg['authserv_ids']),true)){continue;}
                if(preg_match('/(?:^|;)\s*dmarc\s*=\s*(pass|fail|temperror|permerror|none)\b([^;]*)/i',$v,$m)){
                    if(preg_match('/\bheader\.from\s*=\s*([^\s;]+)/i',$m[2],$hf)&&strtolower(trim($hf[1],'"'))!==$domain){continue;}$trusted=strtolower($m[1]);break;}
            }
            if($trusted==='pass'){$out['metodo']='authentication_results';$out['dmarc']='pass';$out['alinhado']=true;$out['aceito']=true;return $out;}
            if($trusted!==null){$out['metodo']='authentication_results';$out['dmarc']=$trusted;if($trusted==='temperror'){$out['temporario']=true;return $out;}}
            $policy=$this->policy($domain);$out['politica']=$policy['policy'];$out['dominio_politica']=$policy['domain'];
            if($trusted==='fail'){$out['descartar']=in_array($policy['policy'],array('reject','quarantine'),true);return $out;}
            $out['metodo']='verificacao_propria';$count=0;$temporary=false;
            foreach($headers as $i=>$h){if($h['name']!=='dkim-signature'){continue;}if(++$count>8){break;}try{$result=$this->dkim($headers,$body,$i);}catch(Throwable $e){$temp=str_starts_with($e->getMessage(),'email_dns_');$temporary=$temporary||$temp;$result=array('resultado'=>$temp?'temperror':'fail');}$out['dkim'][]=$result;
                if(($result['resultado']??'')==='pass'&&$this->aligned($result['dominio'],$domain,$policy['tags']['adkim']??'r')){$out['alinhado']=true;}
            }
            $boundary=self::boundary($headers,$cfg['mx_confiaveis']??array('*.dreamhost.com'));$paths=self::values($headers,'return-path');
            if($boundary&&count($paths)===1&&preg_match('/^<([^<>\s]+@([^<>\s@]+))>$/D',self::unfolded($paths[0]),$rp)&&is_email($rp[1])){
                $out['mx_confiavel']=$boundary['mx'];$spf=new F3Base_Email_Spf($this->dns,$boundary['ip'],strtolower($rp[1]),$boundary['helo']);$out['spf']=$spf->check(strtolower($rp[2]));$temporary=$temporary||$out['spf']==='temperror';
                if($out['spf']==='pass'&&$this->aligned(strtolower($rp[2]),$domain,$policy['tags']['aspf']??'r')){$out['alinhado']=true;}
            }else{$out['spf']='sem_envelope_confiavel';}
            if($out['alinhado']){$out['aceito']=true;$out['dmarc']=$policy['domain']!==''?'pass':'none';}
            elseif($temporary){$out['temporario']=true;$out['dmarc']='temperror';}
            else{$out['dmarc']=$policy['domain']!==''?'fail':'none';$out['descartar']=$out['dmarc']==='fail'&&in_array($policy['policy'],array('reject','quarantine'),true);}
        }catch(Throwable $e){$out['temporario']=str_starts_with($e->getMessage(),'email_dns_');$out['dmarc']=$out['temporario']?'temperror':'permerror';$out['motivo']=$out['temporario']?'dns_indisponivel':'autenticacao_invalida';}
        return $out;
    }
}
