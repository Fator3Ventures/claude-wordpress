<?php
/** Temporary Site-Teste fixture; isolated tables and files, closed operations, no providers. */
if(!defined('ABSPATH'))exit;
function f3qa152_bundle(){return json_decode(gzdecode(base64_decode('__LAB_BUNDLE__')),true,512,JSON_THROW_ON_ERROR);}
function f3qa152_valid($m){return isset($m['root'],$m['prefix'])&&preg_match('/^f3qa1521_[a-f0-9]{12}_$/D',$m['prefix'])&&$m['root']===sys_get_temp_dir().'/'.$m['prefix'];}
function f3qa152_copy($from,$to){if(is_dir($from)){if(!is_dir($to))mkdir($to,0700,true);foreach(new DirectoryIterator($from) as $f)if(!$f->isDot())f3qa152_copy($f->getPathname(),$to.'/'.$f->getFilename());}elseif(!copy($from,$to))throw new RuntimeException('fixture_copy_failed');}
function f3qa152_rm($p){if(is_link($p)||is_file($p)){if(!unlink($p))throw new RuntimeException('fixture_unlink_failed');}elseif(is_dir($p)){foreach(new DirectoryIterator($p) as $f)if(!$f->isDot())f3qa152_rm($f->getPathname());if(!rmdir($p))throw new RuntimeException('fixture_rmdir_failed');}}
function f3qa152_exec($m,$script){
 if(!f3qa152_valid($m))throw new RuntimeException('fixture_manifest_invalid');
 $env=['PATH'=>'/usr/bin:/bin','F3BASE_ROOT'=>$m['root'],'F3BASE_SITE'=>$m['root'].'/wordpress/wp-load.php','F3BASE_EVIDENCE_DIR'=>'evidence','F3BASE_SHARED_SITE'=>ABSPATH.'wp-load.php'];
 $p=proc_open(['/usr/local/php83/bin/php','-d','display_errors=stderr','-d','memory_limit=512M',$m['root'].'/tests/'.$script.'.php'],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,$m['root'],$env);
 if(!is_resource($p))throw new RuntimeException('fixture_cli_unavailable');fclose($pipes[0]);stream_set_blocking($pipes[1],false);stream_set_blocking($pipes[2],false);$out='';$err='';$start=microtime(true);$rc=null;
 do{$out.=stream_get_contents($pipes[1]);$err.=stream_get_contents($pipes[2]);$s=proc_get_status($p);if(!$s['running']){$rc=$s['exitcode'];break;}if(microtime(true)-$start>50){proc_terminate($p);$err.='fixture_timeout';$rc=124;break;}usleep(20000);}while(true);
 $out.=stream_get_contents($pipes[1]);$err.=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$closed=proc_close($p);if($rc===null||$rc<0)$rc=$closed;
 foreach([DB_PASSWORD,DB_USER,DB_HOST,DB_NAME,$m['root']] as $secret)if(is_string($secret)&&$secret!==''){$out=str_replace($secret,'[redacted]',$out);$err=str_replace($secret,'[redacted]',$err);}
 return ['exit_code'=>$rc,'stdout'=>substr($out,-30000),'stderr'=>substr($err,-5000),'seconds'=>round(microtime(true)-$start,3)];
}
function f3qa152_run($args){
 if(!current_user_can('manage_options')||parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||F3BASE_PLUGIN_VERSAO!=='1.52.1')return new WP_Error('fixture_wrong_environment');
 $op=$args['operation'];$m=get_option('f3_core_qa1521_lab',[]);
 if($op==='setup'){
  if($m)return new WP_Error('fixture_exists');$prefix='f3qa1521_'.bin2hex(random_bytes(6)).'_';$root=sys_get_temp_dir().'/'.$prefix;$m=['root'=>$root,'prefix'=>$prefix];
  if(!mkdir($root,0700)||!add_option('f3_core_qa1521_lab',$m,'',false))throw new RuntimeException('fixture_setup_failed');mkdir($root.'/evidence',0700);mkdir($root.'/wordpress',0700);
  foreach(['wp-admin','wp-includes'] as $d)if(!symlink(ABSPATH.$d,$root.'/wordpress/'.$d))throw new RuntimeException('fixture_link_failed');foreach(glob(ABSPATH.'*.php') as $p)if(basename($p)!=='wp-config.php')copy($p,$root.'/wordpress/'.basename($p));
  $content=$root.'/wordpress/wp-content';mkdir($content.'/plugins',0700,true);mkdir($content.'/mu-plugins',0700);mkdir($content.'/themes/f3-fixture',0700,true);file_put_contents($content.'/themes/f3-fixture/style.css',"/* Theme Name: Isolated fixture */\n");file_put_contents($content.'/themes/f3-fixture/index.php','<?php echo "fixture";');
  file_put_contents($content.'/mu-plugins/no-external.php','<?php add_filter("pre_http_request",static fn($pre)=>$pre!==false?$pre:new WP_Error("fixture_external_blocked"),PHP_INT_MAX);add_filter("pre_wp_mail",static fn()=>true,PHP_INT_MAX);');
  $config='<?php ';foreach(['DB_NAME','DB_USER','DB_PASSWORD','DB_HOST','DB_CHARSET','DB_COLLATE'] as $k)$config.='define('.var_export($k,true).','.var_export(defined($k)?constant($k):'',true).');';
  foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $k)$config.='define('.var_export($k,true).','.var_export(bin2hex(random_bytes(48)),true).');';
  $config.='$table_prefix='.var_export($prefix,true).';define("DISABLE_WP_CRON",true);define("WP_ENVIRONMENT_TYPE","local");define("WP_HOME","https://example.invalid");define("WP_SITEURL","https://example.invalid");define("WP_DEBUG",true);define("WP_DEBUG_DISPLAY",false);define("WP_DEBUG_LOG",true);define("WP_HTTP_BLOCK_EXTERNAL",true);if(!defined("ABSPATH"))define("ABSPATH",__DIR__."/");require ABSPATH."wp-settings.php";';file_put_contents($root.'/wordpress/wp-config.php',$config);chmod($root.'/wordpress/wp-config.php',0600);unset($config);
  foreach(f3qa152_bundle() as $name=>$bytes){if(str_contains($name,'..')||str_starts_with($name,'/'))throw new RuntimeException('fixture_path');$file=$root.'/'.$name;if(!is_dir(dirname($file)))mkdir(dirname($file),0700,true);file_put_contents($file,base64_decode($bytes,true));}
  f3qa152_copy(WP_PLUGIN_DIR.'/base-site-core-fator3',$content.'/plugins/base-site-core-fator3');return ['install'=>f3qa152_exec($m,'site-1521-install')];
 }
 if(!f3qa152_valid($m))return new WP_Error('fixture_missing');
 if($op==='suite'){
  $name=$args['suite']??'';if(!in_array($name,['request-296','request-297','request-298','docs-1521'],true))return new WP_Error('fixture_suite_invalid');
  $run=f3qa152_exec($m,$name);$p=$m['root'].'/evidence/'.$name.'.json';$ev=is_file($p)?json_decode(file_get_contents($p),true):null;
  if($name==='docs-1521'&&$ev){$ev=['versao'=>$ev['versao'],'checks'=>count($ev['checks']),'documentos'=>$ev['checks']['documentos'],'paginas'=>$ev['checks']['paginas'],'falhas'=>array_keys(array_filter($ev['checks'],static fn($v)=>$v===false))];}
  $r=['run'=>$run,'evidence'=>$ev];foreach(['request-297'=>'catalog-memory','request-298'=>'priority-measures'] as $test=>$file)if($name===$test&&is_file($m['root'].'/evidence/'.$file.'.json'))$r['measures']=json_decode(file_get_contents($m['root'].'/evidence/'.$file.'.json'),true);return $r;
 }
 if($op==='site-read')return f3qa152_exec($m,'site-1521-read');
 if($op==='site-collect')return f3qa152_exec($m,'site-1521-collect');
 if($op==='cleanup'){
  global $wpdb;$tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($m['prefix']).'%'));if($wpdb->last_error)throw new RuntimeException('fixture_table_list_failed');
  foreach($tables as $t){if(!str_starts_with($t,$m['prefix'])||!preg_match('/^[a-zA-Z0-9_]+$/D',$t))throw new RuntimeException('fixture_unsafe_table');if($wpdb->query($wpdb->prepare('DROP TABLE %i',$t))===false)throw new RuntimeException('fixture_drop_failed');}
  $remaining=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($m['prefix']).'%'));f3qa152_rm($m['root']);delete_option('f3_core_qa1521_lab');return ['tables_dropped'=>count($tables),'remaining_tables'=>count($remaining),'directory_removed'=>!file_exists($m['root']),'manifest_removed'=>!get_option('f3_core_qa1521_lab')];
 }
 return new WP_Error('fixture_operation_invalid');
}
add_action('wp_abilities_api_init',static function(){if(class_exists('F3Base_Servicos'))F3Base_Servicos::ability('qa-core-1521','Homologação temporária isolada no Site-Teste','f3qa152_run',['operation'=>['type'=>'string','enum'=>['setup','suite','site-read','site-collect','cleanup']],'suite'=>['type'=>'string','enum'=>['request-296','request-297','request-298','docs-1521']]],['operation'],false);},99);
