<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
if(getenv('F3BASE_DEACTIVATE_MCP')){deactivate_plugins('wp-mcp-fator3/wp-mcp-fator3.php');exit(0);}
$r=activate_plugin('wp-mcp-fator3/wp-mcp-fator3.php');check(!is_wp_error($r),'mcp_activated');echo "MCP activated; next request exercises its real decorator.\n";
