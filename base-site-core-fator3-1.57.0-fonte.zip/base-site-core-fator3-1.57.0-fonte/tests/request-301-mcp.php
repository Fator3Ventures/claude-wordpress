<?php
require __DIR__.'/bootstrap.php';
require_once dirname(__DIR__).'/companions/wp-mcp-fator3/includes/DataSafety.php';
require_once dirname(__DIR__).'/companions/wp-mcp-fator3/includes/Release014.php';
$before=F3Base_Formulario_Antispam::resumo();$safe=\Fator3\McpFiles\SafeOutput::error($before);
check($safe['linhas']===$before['linhas'],'policy_rows_survive_mcp031_redaction');
check($safe['regras']['token_vencido']==='[redigido]','token_key_redaction_documented');
$counts=['passagens'=>3,'passagens_24h'=>6,'contagem_passagens'=>7,'checks_passed'=>true,'all_checks_passed'=>true];
check(\Fator3\McpFiles\SafeOutput::error($counts)===$counts,'prior_mcp_impact_counters_fixed');
$secret=\Fator3\McpFiles\SafeOutput::error(['f3base_email_site_senha'=>'synthetic-only']);check($secret['f3base_email_site_senha']==='[redigido]','new_password_redacted');
evidence('request-301-mcp');
