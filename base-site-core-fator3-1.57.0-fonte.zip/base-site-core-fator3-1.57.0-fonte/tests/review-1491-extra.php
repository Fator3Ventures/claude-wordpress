<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$warnings=[];$notice=static function($f,$m)use(&$warnings){if($f==='rest_validate_value_from_schema')$warnings[]=$m;};add_action('doing_it_wrong_run',$notice,10,2);
$p=F3Base_Config_Perfil::avaliar(['perfil_id'=>'piso-padrao-3.6']);check($p['ok']&&$p['verificacoes']===92,'profile_92_conditions');check(!$warnings,'profile_no_schema_notices');remove_action('doing_it_wrong_run',$notice);
$record=bin2hex(random_bytes(16));$hook=F3Base_Conversoes_Servidor::HOOK;$cron=get_option('cron');$agenda=get_option('f3base_agenda');$lock=null;
try {
 check($wpdb->insert(F3Base_Conversoes_Servidor::tabela(),['record_id'=>$record,'destino'=>'linkedin','estado'=>'bloqueado','codigo'=>'qa1491','destino_ref'=>'qa','ocorrido_em'=>time(),'atualizado_em'=>time(),'proxima'=>time()+86400])===1,'queue_fixture');
 $lock=F3Base_Trava::adquirir('agenda-'.substr(hash('sha256',$hook),0,32),30);check((bool)$lock,'queue_schedule_lock');
 $a=F3Base_Conversoes_Fila::reavaliar(['destino'=>'linkedin','codigo'=>'qa1491','confirmar'=>true]);
 check(!$a['ok']&&$a['codigo']==='agenda_nao_confirmada'&&$a['persisted']&&$a['reagendadas']===1,'queue_partial_effect_not_success');
 check($a['passagem_agendada_em']===(wp_next_scheduled($hook)?:null),'queue_failure_actual_schedule');F3Base_Trava::liberar($lock);$lock=null;
 $b=F3Base_Conversoes_Fila::reavaliar(['destino'=>'linkedin','codigo'=>'qa1491','confirmar'=>true]);check($b['ok']&&$b['codigo']==='qa1491'&&$b['agenda']['agendado'],'queue_success_filter_contract');check($b['passagem_agendada_em']===wp_next_scheduled($hook),'queue_success_actual_schedule');
}finally{if($lock)F3Base_Trava::liberar($lock);$wpdb->delete(F3Base_Conversoes_Servidor::tabela(),['record_id'=>$record]);raw('cron',$cron);raw('f3base_agenda',$agenda);}
wp_set_current_user(0);check(!F3Base_Leads_Admin::ler([])['ok'],'reader_denies_anonymous');check(!F3Base_Conversoes_Fila::ler([])['ok'],'queue_read_denies_anonymous');check(!F3Base_Conversoes_Fila::reavaliar(['destino'=>'linkedin'])['ok'],'queue_write_denies_anonymous');wp_set_current_user(1);
evidence('review-1491-extra');
