<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-linkedin-fator3','wp-mcp-meta-fator3'] as $slug){deactivate_plugins($slug.'/'.$slug.'.php',true);}
echo "Companions disabled in disposable lab only.\n";
