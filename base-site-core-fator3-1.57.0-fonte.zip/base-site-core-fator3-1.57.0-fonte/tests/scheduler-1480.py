from pathlib import Path
import os,subprocess,time,json,uuid
root=Path(__file__).resolve().parents[1];checks={}
def cmd(origin,key,at,mode='normal'):return [str(root/'build/php'),str(root/'tests/scheduler-worker-1480.php'),origin,key,str(at),mode]
def result(p):
 out,err=p.communicate(timeout=40)
 if p.returncode:raise RuntimeError(out+err)
 try:return json.loads(out)
 except:raise RuntimeError(out+err)
for a,b in [('cli','http_cron'),('http_cron','http_cron')]:
 key='qa148-'+uuid.uuid4().hex;at=int(time.time())-10;owner=subprocess.Popen(cmd(a,key,at),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 marker=Path(os.environ.get('F3BASE_LAB_DIR',str(root/'lab')))/f'{key}.entered'
 for i in range(300):
  if marker.exists():break
  if owner.poll() is not None:raise RuntimeError(result(owner))
  time.sleep(.01)
 else:raise RuntimeError('owner did not enter')
 loser=subprocess.Popen(cmd(b,key,at),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 x=result(owner);y=result(loser);assert x['ok'] and x['resultado_modulo_confirmado'],x;assert y['codigo']=='reserva_ocupada' and y['resultado']=='neutro' and y['dona']['run_id']==x['run_id'] and y['dona']['origem']==a,y;assert marker.read_text()=='1';checks[a+'_'+b]=True
 again=result(subprocess.Popen(cmd(b,key,at),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True));assert again['codigo']=='reserva_ocupada' and again['dona']['estado']=='executada',again;checks[a+'_'+b+'_completed_neutral']=True
key='qa148-'+uuid.uuid4().hex
fault=result(subprocess.Popen(cmd('http_cron',key,int(time.time())-10,'fault'),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True));print('fault',json.dumps(fault));assert fault['codigo']=='checkpoint_nao_persistido' and not fault['ok'] and fault['intencao']['falhas']==1,fault;assert not (Path(os.environ.get('F3BASE_LAB_DIR',str(root/'lab')))/f'{key}.entered').exists();checks['fault_is_failure_no_callback']=True
(root/os.environ.get('F3BASE_EVIDENCE_DIR','evidence')/'scheduler-1480.json').write_text(json.dumps({'checks':checks,'fault':fault},ensure_ascii=False,indent=2));print('scheduler:',len(checks),'checks OK')
