<?php
/** Real WP abilities and MCP decorator; isolated users and synthetic receipts only. */
require __DIR__.'/bootstrap.php';
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\StateStore;
require_once ABSPATH.'wp-admin/includes/user.php';wp_get_abilities();
$uid=wp_insert_user(['user_login'=>'qa1550_permissions_'.bin2hex(random_bytes(5)),'user_pass'=>wp_generate_password(32),'role'=>'subscriber']);$record='';$connection='';$app=null;$mcp=class_exists(Persistence::class);
function user1550(int $uid, array $caps): void {global $app;foreach($caps as $cap=>$value){get_user_by('id',$uid)->add_cap($cap,$value);}wp_set_current_user(0);wp_set_current_user($uid);if($app)do_action('application_password_did_authenticate',get_user_by('id',$uid),$app[1]);}
function denied1550($r): bool {return is_wp_error($r)||(($r['success']??true)===false&&!isset($r['mensagem']));}
try {
 user1550($uid,['manage_options'=>true,'f3base_ler_leads'=>true,'f3base_gerir_leads'=>true,'f3base_enviar_email'=>true]);
 if($mcp){$app=WP_Application_Passwords::create_new_application_password($uid,['name'=>'QA1550 temporary']);$connection='app:'.$app[1]['uuid'];Persistence::put('connections',$connection,['connection_id'=>$connection,'user_id'=>$uid,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);user1550($uid,[]);}
 $stored=F3Base_Leads_Repositorio::guardar(['metodo'=>'email','origem_nativa'=>['origem'=>'email'],'nome'=>'QA1550','email'=>'qa1550@example.invalid','captura'=>'aceito','contexto_teste'=>true],null,'qa1550:'.bin2hex(random_bytes(10)));check($stored['ok'],'synthetic_contact');$record=$stored['record_id'];
 $input=['record_id'=>$record,'assunto'=>'QA1550','texto'=>'Synthetic private text1550','simular'=>true];$send=wp_get_ability('f3base/email-enviar');
 foreach(['f3base_enviar_email','f3base_ler_leads'] as $cap){
  $args=$input;if($mcp)$args['idempotency_key']='qa1550-preview-'.$cap.'-'.$record;
  $preview=$send->execute($args);check(!is_wp_error($preview)&&!empty($preview['ok'])&&isset($preview['mensagem']),'authorized_preview_'.$cap);
  user1550($uid,[$cap=>false]);check($send->check_permissions($args)!==true,'producer_gate_'.$cap);$replay=$send->execute($args);check(denied1550($replay),'cached_preview_denied_'.$cap);
  $fresh=$input;if($mcp)$fresh['idempotency_key']='qa1550-fresh-'.$cap.'-'.$record;check(denied1550($send->execute($fresh)),'new_key_denied_'.$cap);
  user1550($uid,[$cap=>true]);
 }
 foreach(['f3base/email-caixa-consultar','f3base/email-reprocessar','f3base/email-registros-ler'] as $name){user1550($uid,['f3base_ler_leads'=>false]);check(wp_get_ability($name)->check_permissions([])!==true,'read_gate_'.$name);user1550($uid,['f3base_ler_leads'=>true]);}
 user1550($uid,['manage_options'=>false]);foreach(['f3base/email-caixa-verificar','f3base/email-caixa-consultar','f3base/email-reprocessar'] as $name)check(wp_get_ability($name)->check_permissions([])!==true,'manage_gate_'.$name);user1550($uid,['manage_options'=>true]);
 foreach(['f3base_ler_leads','f3base_gerir_leads','manage_options'] as $cap){user1550($uid,[$cap=>false]);foreach(['f3base/contato-externo-registrar','f3base/contato-sessao-vincular'] as $name)check(wp_get_ability($name)->check_permissions([])!==true,'new_route_gate_'.$cap.'_'.$name);user1550($uid,[$cap=>true]);}
 if($mcp){
  // A real uncertainty receipt in the producer and cached channel result must stay private.
  $revision=hash('sha256','uncertain1550'.$record);$key='qa1550-uncertain-'.$record;$args=array_replace($input,['simular'=>false,'revisao'=>$revision,'idempotency_key'=>$key]);
  global $wpdb;$wpdb->insert(F3Base_Email_Site::tabela(),['chave'=>$revision,'contexto'=>hash('sha256','qa1550'),'direcao'=>'saida','record_id'=>$record,'message_hash'=>hash('sha256',$key),'estado'=>'incerto','classe'=>'aceito','payload'=>F3Base_Contato_Comunicacao::cifrar(['texto'=>'Synthetic uncertainty1550','email'=>'qa1550@example.invalid']),'criada_em'=>time(),'atualizada_em'=>time()]);
  $receipt=$send->execute($args);check(!is_wp_error($receipt)&&($receipt['estado']??'')==='incerto','uncertain_receipt_before_revocation');
  foreach(['f3base_enviar_email','f3base_ler_leads'] as $cap){user1550($uid,[$cap=>false]);check(denied1550($send->execute($args)),'cached_uncertainty_denied_'.$cap);user1550($uid,[$cap=>true]);}
  $policy=Persistence::get('connections',$connection);$policy['profile']='read';Persistence::put('connections',$connection,$policy);check(denied1550($send->execute($input)),'mcp_read_profile_cannot_write');
  check($send->get_meta()['fator3']['decorated']??false,'actual_mcp_decorator');
 }
} finally {wp_set_current_user(1);if($record)F3Base_Leads_Repositorio::eliminar($record,'teste');if($app)WP_Application_Passwords::delete_application_password($uid,$app[1]['uuid']);if($connection)Persistence::delete('connections',$connection);wp_delete_user($uid);}
evidence($mcp?'permissions-mcp033-1550':'permissions-native-1550');
