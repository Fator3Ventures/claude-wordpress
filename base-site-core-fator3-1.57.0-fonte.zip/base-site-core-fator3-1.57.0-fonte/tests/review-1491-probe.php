<?php
require __DIR__.'/bootstrap.php';
$out=array('version'=>F3BASE_PLUGIN_VERSAO);$warnings=array();$option='';
add_action('doing_it_wrong_run',static function($f,$m)use(&$warnings,&$option){if($f==='rest_validate_value_from_schema'){$warnings[]=array('option'=>$option,'message'=>$m);}},10,2);
foreach(F3Base_Options::catalogo() as $option=>$d){$schema=F3Base_Config_Contrato::schema_entrada($d);F3Base_Config_Mescla::erros_schema($d['padrao']??null,$schema);}
$out['schema_warnings']=$warnings;
$input=array('utm_source'=>'facebook','utm_medium'=>'paid_social','utm_campaign'=>'123456','f3_ads_account_id'=>'123','nome_campanha_origem'=>'mapa_da_origem','nome_anuncio_origem'=>'mapa_da_origem','conta_origem'=>'mapa_da_origem');
$a=F3Base_Atribuicao::normalizar($input);$out['attribution']=$a;$out['note']=F3Base_Contato_Apresentacao::nota(array('atribuicao'=>$a),'qa');
global $wpdb;$f=static fn($sql)=>str_contains($sql,'MIN(proxima) AS mais_antiga')?str_replace('MIN(proxima)','MIN(qa1491_missing)',$sql):$sql;
add_filter('query',$f);$out['queue_due_query_error']=F3Base_Conversoes_Fila::ler(array('amostra'=>0));remove_filter('query',$f);
$f=static fn($sql)=>str_contains($sql,'COUNT(*) FROM')&&str_contains($sql,'f3base_conversoes_servidor')?str_replace('COUNT(*)','COUNT(qa1491_missing)',$sql):$sql;
add_filter('query',$f);$out['queue_recheck_query_error']=F3Base_Conversoes_Fila::reavaliar(array('destino'=>'linkedin'));remove_filter('query',$f);
file_put_contents(getenv('F3BASE_ROOT').'/evidence/review-1491-negative.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode(array('schema_warnings'=>$warnings,'queue_due_ok'=>$out['queue_due_query_error']['ok'],'queue_recheck_ok'=>$out['queue_recheck_query_error']['ok'],'legacy_name'=>$a['nome_campanha_origem']??null),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
