<?php
/** Real Site-Teste IMAP namespace/create and DNS transport; no messages or recipients. */
define('DISABLE_WP_CRON',true);define('WP_DISABLE_FATAL_ERROR_HANDLER',true);$_SERVER['HTTP_HOST']='fator3-teste-mcp-1.dreamhosters.com';$_SERVER['HTTPS']='on';require getenv('F3BASE_SHARED_SITE');
if(parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||F3BASE_PLUGIN_VERSAO!=='1.55.0')throw new RuntimeException('wrong_site');
add_filter('pre_wp_mail',static fn()=>true,PHP_INT_MAX);
set_exception_handler(static function($e){echo wp_json_encode(['error'=>$e->getMessage()]);exit(1);});
function qa155_remove_empty($c,$name){$cmd=new ReflectionMethod(F3Base_Email_Imap::class,'command');$list=$cmd->invoke($c,'LIST "" "'.$name.'"');if(!str_contains(implode('',$list['lines']),'* LIST '))return true;$r=$cmd->invoke($c,'EXAMINE "'.$name.'"');if(!preg_match('/^\\* 0 EXISTS\\r?$/m',implode('',$r['lines'])))throw new RuntimeException('fixture_folder_not_empty');$c->select('INBOX');$cmd->invoke($c,'DELETE "'.$name.'"');$r=$cmd->invoke($c,'LIST "" "'.$name.'"');return !str_contains(implode('',$r['lines']),'* LIST ');}
$before=F3Base_Options::fotografias_brutas(['f3base_email_site','f3base_email_site_estado']);$c=F3Base_Email_Site::conectar();$inbox=$c->select();$previous=qa155_remove_empty($c,'INBOX.F3QA15501bd9aedd4516Sent');$tag='F3QA1550'.bin2hex(random_bytes(6));$names=['importados'=>$tag.'Importados','enviados'=>$tag.'Sent'];$owned=[];$cleanup=[];$out=[];
try{
 $preview=$c->pastas($names,false);foreach($preview['pastas'] as $f){if($f['existia']||$f['disponivel']||!preg_match('/^INBOX\.F3QA1550[a-f0-9]{12}(Importados|Sent)$/D',$f['efetiva']))throw new RuntimeException('unsafe_fixture_folder');$owned[]=$f['efetiva'];}
 $created=$c->pastas($names,true);foreach($created['pastas'] as $f)if(!$f['criada']||!$f['disponivel'])throw new RuntimeException('folder_create_not_confirmed');
 $out=['preview'=>$preview,'created'=>$created];
}finally{
 $c->close();$c=F3Base_Email_Site::conectar();$cmd=new ReflectionMethod(F3Base_Email_Imap::class,'command');
 foreach($owned as $name){$cleanup[$name]=qa155_remove_empty($c,$name);if(!$cleanup[$name])throw new RuntimeException('fixture_folder_cleanup_failed');}
 $out['cleanup']=$cleanup;$out['previous_fixture_cleanup']=$previous;$out['inbox_identity_preserved']=$c->select()===$inbox;$c->close();
}
$dns=new F3Base_Email_Dns();$out['dns']=[];foreach(['_dmarc.gmail.com','gmail.com'] as $name){$rows=$dns->query($name);$out['dns'][$name]=['records'=>count($rows),'resolved'=>count($rows)>0];}
$after=F3Base_Options::fotografias_brutas(['f3base_email_site','f3base_email_site_estado']);$out['configuration_and_cursor_preserved']=array_column($before,'revisao')===array_column($after,'revisao');$out['messages_read_or_sent']=0;
echo wp_json_encode($out,JSON_UNESCAPED_UNICODE);
