<?php
/** Child process for release-1490.php: loads WordPress once with the lab probe enabled and reports. */
$_SERVER['HTTP_HOST'] = '127.0.0.1:8136';
require getenv( 'F3BASE_SITE' );
require_once ABSPATH . 'wp-admin/includes/plugin.php';
$r = $GLOBALS['f3qa_1490'] ?? null;
echo wp_json_encode(
	array(
		'probe'               => null !== $r,
		'versao'              => F3BASE_PLUGIN_VERSAO,
		'antecipadas_f3base'  => $r['antecipadas_f3base'] ?? null,
		'antecipadas_outros'  => array_values( array_unique( $r['antecipadas_outros'] ?? array() ) ),
		'catalogo_antecipado' => $r['catalogo_antecipado'] ?? null,
		'catalogo_final'      => count( F3Base_Options::catalogo() ),
		'filtro_tardio'       => null !== F3Base_Options::declaracao( 'f3base_qa_tardio_1490' ),
		'linkedin_ativo'      => is_plugin_active( 'wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php' ),
	)
);
