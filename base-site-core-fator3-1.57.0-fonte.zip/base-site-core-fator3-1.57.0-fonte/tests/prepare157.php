<?php
require __DIR__.'/bootstrap.php';foreach(['f3base_ler_leads','f3base_gerir_leads'] as $cap)get_role('administrator')->add_cap($cap);wp_set_current_user(0);wp_set_current_user(1);
check(F3Base_Ga4_Acervo::instalar(),'ga4_schema');check(F3Base_Instagram_Exclusao::instalar(),'instagram_schema');$s=get_option(F3Base_Instalacao::OPTION);$s['proxima_tentativa']=0;raw(F3Base_Instalacao::OPTION,$s);$r=F3Base_Instalacao::atualizar();echo wp_json_encode($r)."\n";
require_once ABSPATH.'wp-admin/includes/plugin.php';foreach(['wp-mcp-meta-fator3','wp-mcp-google-fator3'] as $slug){$r=activate_plugin($slug.'/'.$slug.'.php');check(!is_wp_error($r),'activate_'.$slug);}
evidence('prepare157');
