<?php
/** One normal local log collection; only Site-Teste, with deliberate process padding. */
define('DISABLE_WP_CRON',true);$_SERVER['HTTP_HOST']='fator3-teste-mcp-1.dreamhosters.com';require getenv('F3BASE_SHARED_SITE');
if(parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||F3BASE_PLUGIN_VERSAO!=='1.52.1')throw new RuntimeException('wrong_site');wp_set_current_user(1);
add_filter('pre_http_request',static fn()=>new WP_Error('qa_no_provider'),PHP_INT_MAX);add_filter('pre_wp_mail',static fn()=>true,PHP_INT_MAX);
$padding=str_repeat('x',140*1024*1024);$before=memory_get_usage(true);$started=microtime(true);$r=F3Base_Recuperacao::executar(static fn()=>F3Base_Acessos_Coleta::executar());unset($padding);
$guide=F3Base_Como_Usar::responder(['assuntos'=>['acessos-servidor'],'compacto'=>true]);
echo wp_json_encode(['version'=>F3BASE_PLUGIN_VERSAO,'process_before_bytes'=>$before,'seconds'=>round(microtime(true)-$started,3),'result'=>array_intersect_key((array)$r,array_flip(['erro','pendentes','catalogo','proxima_tentativa','tentativa_em'])),'last_sum'=>$r['ultima_soma']??null,'guide_access'=>$guide['acessos_servidor']??null],JSON_UNESCAPED_UNICODE);
