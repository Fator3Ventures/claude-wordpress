<?php
define('WP_INSTALLING',true);$_SERVER['HTTP_HOST']='example.invalid';$_SERVER['REQUEST_URI']='/';require getenv('F3BASE_SITE');
global $wpdb;if(!preg_match('/^f3qa1560_[a-f0-9]{12}_$/D',$wpdb->prefix)||WP_HOME!=='https://example.invalid')throw new RuntimeException('unsafe_fixture:prefix='.(int)preg_match('/^f3qa1560_[a-f0-9]{12}_$/D',$wpdb->prefix).':home='.(int)(WP_HOME==='https://example.invalid'));
require_once ABSPATH.'wp-admin/includes/upgrade.php';if(!is_blog_installed())wp_install('Site de teste isolado','admin','qa@example.invalid',true,'',wp_generate_password(40));
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');if(is_wp_error($r))throw new RuntimeException('activation_failed');
echo wp_json_encode(['wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'version'=>F3BASE_PLUGIN_VERSAO,'cycle'=>F3Base_Instalacao::atualizar(),'ready'=>F3Base_Atualizacao::pronta()]);
