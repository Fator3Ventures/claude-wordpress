<?php
/** Disposable lab database settings (env-driven). Never points to a real site. */
function f3lab_db(): array {
 $host=getenv('F3BASE_DB_HOST')?:'127.0.0.1:33436';$port=null;
 if(str_contains($host,':')){[$host,$port]=explode(':',$host,2);$port=(int)$port;}
 return array('host'=>$host,'port'=>$port?:3306,'user'=>getenv('F3BASE_DB_USER')?:'root','pass'=>getenv('F3BASE_DB_PASSWORD')?:'','name'=>getenv('F3BASE_LAB_DB')?:'core_lab');
}
function f3lab_mysqli(): mysqli {$d=f3lab_db();return new mysqli($d['host'],$d['user'],$d['pass'],null,$d['port']);}
