<?php
/**
 * Core 1.49.0 — melhorias M1 a M7, em WordPress real descartável.
 *
 * Modo normal: falha na primeira verificação que não passar.
 * F3BASE_COLETAR=1: executa cada caso isoladamente e registra passou/falhou
 * (usado para provar contra a base 1.48.0 quais casos falham nela).
 */
require __DIR__ . '/bootstrap.php';
require_once ABSPATH . 'wp-admin/includes/user.php';
global $wpdb;
$GLOBALS['coletar_1490'] = getenv( 'F3BASE_COLETAR' ) === '1';
$GLOBALS['casos_1490']   = array();
function caso( string $nome, callable $fn ): void {
	try {
		$fn();
		$GLOBALS['casos_1490'][ $nome ] = 'passou';
	} catch ( Throwable $e ) {
		$GLOBALS['casos_1490'][ $nome ] = 'falhou: ' . substr( $e->getMessage(), 0, 300 );
		if ( ! $GLOBALS['coletar_1490'] ) {
			throw $e;
		}
	}
}
$http = array();
add_filter(
	'pre_http_request',
	static function ( $pre, $args, $url ) use ( &$http ) {
		$http[] = array( 'url' => $url, 'blocking' => $args['blocking'] ?? true );
		return new WP_Error( 'qa_sem_transporte_externo' );
	},
	1,
	3
);
get_role( 'administrator' )->add_cap( 'f3base_ler_leads' );
$assinante = get_user_by( 'login', 'qa_assinante_1490' );
$assinante = $assinante ? $assinante->ID : wp_insert_user( array( 'user_login' => 'qa_assinante_1490', 'user_pass' => wp_generate_password( 24 ), 'role' => 'subscriber', 'user_email' => 'assinante1490@example.test' ) );

caso(
	'versao_e_contrato',
	static function (): void {
		check( F3BASE_PLUGIN_VERSAO === (getenv('F3BASE_TARGET_VERSION')?:'1.49.0'), 'versao_1490' );
		check( F3Base_Config_Contrato::VERSAO === (getenv('F3BASE_TARGET_CONTRACT')?:'8.14.0'), 'contrato_8140' );
	}
);

/* M1 — carga antecipada de tradução: processo novo, sonda de laboratório ativa. */
caso(
	'm1_traducao_antecipada',
	static function (): void {
		$cmd = escapeshellarg( getenv( 'F3BASE_ROOT' ) . '/build/php' ) . ' ' . escapeshellarg( __DIR__ . '/probe-1490-run.php' );
		$out = shell_exec( 'F3BASE_PROBE_1490=1 ' . $cmd . ' 2>/dev/null' );
		$r   = json_decode( (string) $out, true );
		check( is_array( $r ) && ! empty( $r['probe'] ), 'm1_sonda_carregada' );
		$GLOBALS['m1_resultado'] = $r;
		check( 0 === $r['antecipadas_f3base'], 'm1_sem_aviso_f3base_antes_de_init' );
		check( is_int( $r['catalogo_antecipado'] ) && $r['catalogo_antecipado'] > 50, 'm1_catalogo_disponivel_antes_de_init' );
		check( true === $r['filtro_tardio'], 'm1_filtro_registrado_depois_de_plugins_loaded_honrado' );
		check( $r['catalogo_final'] === $r['catalogo_antecipado'] + 1, 'm1_catalogo_final_inclui_somente_o_filtro' );
	}
);

/* M2 — motivo acionável de ability nativa recusada. */
caso(
	'm2_motivo_ability_nativa',
	static function (): void {
		$a = F3Base_Abilities_Nativas::falha( array( 'success' => false, 'error_code' => 'profile_denied', 'message' => 'x' ), 'linkedin_catalogo_indisponivel', 'linkedin/admin-options' );
		check( 'mcp_recusou_chamada_nativa' === $a['codigo'] && 'profile_denied' === $a['motivo'] && (version_compare($a['mcp_versao']??'0','0.29.0','>=')?str_contains($a['mensagem'],'requisição administrativa web'):str_contains($a['mensagem'],'0.29.0')) && false === $a['ok'], 'm2_profile_denied' );
		$b = F3Base_Abilities_Nativas::falha( new WP_Error( 'ability_invalid_permissions', 'no' ), 'google_catalogo_indisponivel', 'ads/search' );
		check( 'permissao_recusada_pela_integracao' === $b['codigo'], 'm2_permissao' );
		$c = F3Base_Abilities_Nativas::falha( array( 'success' => false, 'error_code' => 'Not Configured!<b>' ), 'linkedin_catalogo_indisponivel', 'linkedin/admin-options' );
		check( 'linkedin_catalogo_indisponivel' === $c['codigo'] && 'notconfiguredb' === $c['motivo'], 'm2_desconhecido_preserva_codigo_publicado_e_sanitiza' );
		$d = F3Base_Abilities_Nativas::falha( new RuntimeException( 'segredo-que-nao-sai' ), 'google_catalogo_indisponivel', 'ads/search' );
		check( 'excecao_na_integracao' === $d['motivo'] && ! str_contains( wp_json_encode( $d ), 'segredo-que-nao-sai' ), 'm2_excecao_sem_texto' );
		$e = F3Base_Abilities_Nativas::falha( array( 'success' => false, 'error_code' => 'connection_context_required' ), 'x', 'linkedin/admin-options' );
		check( 'mcp_recusou_chamada_nativa' === $e['codigo'], 'm2_connection_context_required' );
	}
);

/* M3 — parâmetros de lista nas rotas públicas não geram aviso PHP. */
caso(
	'm3_rotas_publicas_lista',
	static function (): void {
		$avisos = array();
		set_error_handler(
			static function ( $no, $msg ) use ( &$avisos ) {
				$avisos[] = $msg;
				return true;
			},
			E_WARNING | E_NOTICE
		);
		try {
			$r1 = new WP_REST_Request( 'POST', '/f3base/v1/formularios/token' );
			$r1->set_body_params( array( 'formulario' => array( 'a', array( 'b' ) ), 'submissao' => array( 'x' ), 'pagina' => '1' ) );
			$s1 = rest_do_request( $r1 )->get_status();
			$r2 = new WP_REST_Request( 'GET', '/f3base/v1/servidor-sonda' );
			$r2->set_query_params( array( 'eco' => array( '1' ) ) );
			$s2 = rest_do_request( $r2 )->get_status();
		} finally {
			restore_error_handler();
		}
		check( 429 === $s1 && 400 === $s2, 'm3_status_publicados_preservados' );
		check( array() === array_filter( $avisos, static fn( $m ) => str_contains( $m, 'Array to string' ) ), 'm3_sem_array_to_string' );
	}
);

/* Fixtures de conversão (M4–M6). */
$stale = $wpdb->get_col( 'SELECT record_id FROM ' . F3Base_Leads_Repositorio::tabela() . " WHERE correlacao LIKE 'qa149-%'" );
foreach ( $stale as $id ) {
	$wpdb->delete( F3Base_Conversoes_Servidor::tabela(), array( 'record_id' => $id ) );
	$wpdb->delete( F3Base_Leads_Repositorio::tabela(), array( 'record_id' => $id ) );
}
$wpdb->query( $wpdb->prepare( 'DELETE FROM %i', F3Base_Conversoes_Servidor::tabela() ) );
$original = array();
foreach ( array( 'f3base_conversoes_transporte', 'f3base_linkedin_partner_id', 'f3base_linkedin_conversion_id', 'f3base_linkedin_server_conversion_id' ) as $n ) {
	$original[ $n ] = F3Base_Options::ler( $n );
}
save( 'f3base_linkedin_partner_id', '12345' );
save( 'f3base_linkedin_conversion_id', '67890' );
save( 'f3base_linkedin_server_conversion_id', '98765' );
raw( 'f3base_conversoes_transporte', array( 'ga4' => 'navegador', 'google_ads' => 'navegador', 'linkedin' => 'ambos' ) );
$fake = new class() {
	public $calls = array();
	function capabilities() {
		return array( 'contract' => F3Base_Conversoes_Servidor::CONTRATO, 'ready' => true, 'reason' => 'ok', 'destination_ref' => 'synthetic-account-rule-1490', 'conversion_id' => '98765' );
	}
	function send( $p ) {
		throw new RuntimeException( 'Unbound send forbidden' );
	}
	function sendBound( $p, $r ) {
		$this->calls[] = $r;
		return array( 'status' => 'entregue', 'code' => 'linkedin_http_201', 'http' => 201, 'non_delivery_proven' => true, 'retry_after' => 300 );
	}
};
add_filter( 'f3base_conversoes_adaptador', static fn( $a, $target ) => 'linkedin' === $target ? $fake : $a, 10, 2 );
$make = static function () use ( $wpdb ): array {
	$id = bin2hex( random_bytes( 16 ) );
	$d  = array( 'classe_trafego' => 'nao_marcado', 'contexto_teste' => false, 'conversoes_transporte' => F3Base_Conversoes_Transporte::capturar(), 'linkedin_conversao' => F3Base_Linkedin_Conversoes::fotografia() + array( 'valor' => '10.00', 'moeda' => 'BRL', 'event_id' => $id ), 'consentimento_snapshot' => array( 'medicao' => true, 'publicidade' => true, 'politica_versao' => 'legado:pre-aprovado' ), 'atribuicao' => array( 'li_fat_id' => 'synthetic-click-149' ), 'empresa' => 'Empresa QA', 'cargo' => 'Analista', 'campos' => array( 'pais' => 'BR' ) );
	$l  = array( 'record_id' => $id, 'captura' => 'aceito', 'metodo' => 'formulario', 'classe_trafego' => 'nao_marcado', 'nome' => 'Pessoa Exemplo', 'email' => 'pessoa149@example.test', 'sessao' => bin2hex( random_bytes( 16 ) ), 'correlacao' => 'qa149-' . $id, 'criado_em' => gmdate( 'Y-m-d H:i:s' ), 'lixeira' => 0, 'eliminacao_pendente' => 0, 'dados' => $d );
	$wpdb->insert( F3Base_Leads_Repositorio::tabela(), array_replace( $l, array( 'dados' => wp_json_encode( $d ), 'payload_hash' => hash( 'sha256', $id ), 'pagina' => '/qa149/', 'anexos' => '[]', 'revisao' => 1, 'atualizado_em' => gmdate( 'Y-m-d H:i:s' ) ) ) );
	check( ! $wpdb->last_error, 'fixture_contato' );
	return $l;
};
$fila = static function ( string $record, string $estado, string $codigo, string $ref, int $proxima ) use ( $wpdb ): void {
	$wpdb->insert( F3Base_Conversoes_Servidor::tabela(), array( 'record_id' => $record, 'destino' => 'linkedin', 'estado' => $estado, 'codigo' => $codigo, 'destino_ref' => $ref, 'ocorrido_em' => time() - 600, 'atualizado_em' => time() - 600, 'proxima' => $proxima, 'tentativas' => 0 ) );
	check( ! $wpdb->last_error, 'fixture_fila' );
};
$bloqueados = array();
for ( $i = 0; $i < 25; $i++ ) {
	$l = $make();
	$bloqueados[] = $l['record_id'];
	$fila( $l['record_id'], 'bloqueado', 'destino_historico_ausente', '', time() - 7200 + $i );
}
$nova = $make();
$fila( $nova['record_id'], 'pendente', '', 'synthetic-account-rule-1490', time() - 60 );

/* M4 — conversão nova não espera a fila de bloqueios. */
caso(
	'm4_prioridade_da_fila',
	static function () use ( $fake, $nova, $wpdb, &$http ): void {
		$antes = count( $http );
		$r     = F3Base_Conversoes_Servidor::processar();
		check( ! empty( $r['ok'] ), 'm4_passagem_ok' );
		check( array( 'synthetic-account-rule-1490' ) === $fake->calls, 'm4_conversao_nova_enviada_na_primeira_passagem' );
		$estado = $wpdb->get_var( $wpdb->prepare( 'SELECT estado FROM %i WHERE record_id=%s AND destino=%s', F3Base_Conversoes_Servidor::tabela(), $nova['record_id'], 'linkedin' ) );
		check( 'entregue' === $estado, 'm4_entregue_registrado' );
		$reavaliados = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE destino='linkedin' AND estado='bloqueado' AND proxima>%d", F3Base_Conversoes_Servidor::tabela(), time() + 3000 ) );
		check( 9 === $reavaliados, 'm4_bloqueados_ocupam_so_as_vagas_restantes' );
		check( count( $http ) === $antes, 'm4_sem_http' );
	}
);

/* M5 — leitura agregada da fila. */
caso(
	'm5_fila_ler',
	static function () use ( &$http, $assinante ): void {
		$ability = wp_get_ability( 'f3base/conversoes-fila-ler' );
		check( (bool) $ability, 'm5_registrada' );
		check( true === ( $ability->get_meta()['annotations']['readonly'] ?? null ), 'm5_somente_leitura' );
		$antes = count( $http );
		$r     = $ability->execute( array( 'destino' => 'linkedin', 'dias' => 30, 'amostra' => 3 ) );
		check( is_array( $r ) && ! empty( $r['ok'] ), 'm5_ok' );
		$li = $r['destinos']['linkedin'];
		check( 1 === $li['estados']['entregue'] && 25 === $li['estados']['bloqueado'] && 26 === $li['total'], 'm5_contagens_por_estado' );
		$m = array_column( $li['motivos'], null, 'codigo' );
		check( 25 === ( $m['destino_historico_ausente']['quantidade'] ?? 0 ) && '' !== ( $m['destino_historico_ausente']['explicacao'] ?? '' ), 'm5_motivo_explicado' );
		check( 3 === count( $li['amostra'] ) && array( 'record_id', 'estado', 'codigo', 'atualizado_em' ) === array_keys( $li['amostra'][0] ), 'm5_amostra_sem_dado_pessoal' );
		check( ! str_contains( wp_json_encode( $r ), '@example.test' ) && ! str_contains( wp_json_encode( $r ), 'Pessoa Exemplo' ), 'm5_sem_contato' );
		check( isset( $r['transporte']['linkedin'] ) && true === $r['linkedin']['regra_servidor_configurada'], 'm5_transporte_e_regras' );
		check( 16 === $li['vencidas']['bloqueado'] && 0 === $li['vencidas']['pendente'] && 0 === $r['destinos']['linkedin']['atraso_segundos'], 'm5_vencidas' );
		check( count( $http ) === $antes, 'm5_sem_http' );
		wp_set_current_user( $assinante );
		$negado = $ability->execute( array() );
		wp_set_current_user( 1 );
		check( is_wp_error( $negado ), 'm5_assinante_recusado' );
	}
);

/* M6 — reavaliação explícita de bloqueados. */
caso(
	'm6_bloqueadas_reavaliar',
	static function () use ( $wpdb, &$http, $assinante, $bloqueados ): void {
		$ability = wp_get_ability( 'f3base/conversoes-bloqueadas-reavaliar' );
		check( (bool) $ability && false === ( $ability->get_meta()['annotations']['readonly'] ?? null ), 'm6_registrada_como_escrita' );
		$t      = F3Base_Conversoes_Servidor::tabela();
		$antes  = $wpdb->get_col( $wpdb->prepare( "SELECT CONCAT(record_id,':',proxima) FROM %i WHERE destino='linkedin' ORDER BY record_id", $t ) );
		$http0  = count( $http );
		$sim    = $ability->execute( array( 'destino' => 'linkedin', 'codigo' => 'destino_historico_ausente', 'limite' => 5 ) );
		check( ! empty( $sim['ok'] ) && true === $sim['simulado'] && 25 === $sim['bloqueadas'] && 5 === $sim['selecionadas'] && 0 === $sim['reagendadas'], 'm6_simulacao' );
		check( $antes === $wpdb->get_col( $wpdb->prepare( "SELECT CONCAT(record_id,':',proxima) FROM %i WHERE destino='linkedin' ORDER BY record_id", $t ) ), 'm6_simulacao_sem_efeito' );
		$ok = $ability->execute( array( 'destino' => 'linkedin', 'codigo' => 'destino_historico_ausente', 'limite' => 5, 'confirmar' => true ) );
		check( ! empty( $ok['ok'] ) && false === $ok['simulado'] && 5 === $ok['reagendadas'], 'm6_confirmado' );
		$agora = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE destino='linkedin' AND estado='bloqueado' AND proxima<=%d", $t, time() ) );
		check( $agora >= 5, 'm6_proxima_antecipada' );
		check( (bool) wp_next_scheduled( F3Base_Conversoes_Servidor::HOOK ), 'm6_passagem_agendada' );
		check( count( $http ) === $http0, 'm6_sem_http' );
		$invalido = $ability->execute( array( 'destino' => 'linkedin', 'codigo' => 'DROP TABLE' ) );
		check( is_wp_error( $invalido ), 'm6_codigo_invalido_recusado_pelo_schema' );
		wp_set_current_user( $assinante );
		$negado = $ability->execute( array( 'destino' => 'linkedin', 'confirmar' => true ) );
		wp_set_current_user( 1 );
		check( is_wp_error( $negado ), 'm6_assinante_recusado' );
	}
);

/* M7 — guarda: a tela de contatos não faz HTTP bloqueante (o achado era do WP-Cron). */
caso(
	'm7_tela_contatos_sem_http_sincrono',
	static function () use ( &$http ): void {
		require_once ABSPATH . 'wp-admin/includes/admin.php';
		$_GET['page'] = 'f3base-leads';
		set_current_screen( 'toplevel_page_f3base-leads' );
		$antes = count( $http );
		ob_start();
		try {
			F3Base_Leads_Admin::tela();
		} finally {
			$html = ob_get_clean();
		}
		$bloqueantes = array_filter( array_slice( $http, $antes ), static fn( $c ) => false !== $c['blocking'] );
		check( strlen( (string) $html ) > 500, 'm7_tela_renderizada' );
		check( array() === $bloqueantes, 'm7_sem_http_bloqueante' );
	}
);

/* M8 — catálogo LinkedIn pelo plugin externo sem conta/conexão salvas não chama a ability. */
caso(
	'm8_catalogo_linkedin_sem_conta',
	static function () use ( $wpdb ): void {
		$original = $wpdb->get_var( $wpdb->prepare( 'SELECT option_value FROM %i WHERE option_name=%s', $wpdb->options, F3Base_Linkedin::OPCAO ) );
		$execucoes = 0;
		$conta     = static function () use ( &$execucoes ) {
			++$execucoes;
		};
		add_action( 'wp_before_execute_ability', $conta );
		try {
			raw( F3Base_Linkedin::OPCAO, array( 'connection_id' => 'qa-conn-1490', 'conta_id' => '', 'cliente' => 'linkedin_plugin' ) );
			$a = F3Base_Linkedin_Cliente::catalogo( 'campanhas' );
			$b = F3Base_Linkedin_Cliente::catalogo( 'formularios' );
			raw( F3Base_Linkedin::OPCAO, array( 'connection_id' => '', 'conta_id' => '123456789', 'cliente' => 'linkedin_plugin' ) );
			$c = F3Base_Linkedin_Cliente::catalogo( 'campanhas' );
		} finally {
			remove_action( 'wp_before_execute_ability', $conta );
			if ( null === $original ) {
				delete_option( F3Base_Linkedin::OPCAO );
			} else {
				raw( F3Base_Linkedin::OPCAO, maybe_unserialize( $original ) );
			}
		}
		check( false === $a['ok'] && 'salve_a_conta' === $a['codigo'] && 'salve_a_conta' === $b['codigo'], 'm8_conta_vazia_salve_a_conta' );
		check( 'selecione_a_conexao_linkedin' === $c['codigo'] && '' !== ( $c['mensagem'] ?? '' ), 'm8_conexao_vazia' );
		check( 0 === $execucoes, 'm8_ability_nao_executada' );
	}
);

/* M9 — contexto de medição: leitura agrupada, mesmo snapshot, releitura na mesma requisição. */
caso(
	'm9_contexto_medicao_consultas',
	static function () use ( $wpdb ): void {
		F3Base_Medicao_Contexto::snapshot();
		$q0 = $wpdb->num_queries;
		F3Base_Medicao_Contexto::snapshot();
		$GLOBALS['checks']['m9_consultas_medidas_antes_das_verificacoes'] = $wpdb->num_queries - $q0;
		check( method_exists( 'F3Base_Options', 'fotografias_brutas' ), 'm9_leitura_agrupada_existe' );
		$nomes = array_merge( array_keys( F3Base_Options::catalogo() ), array( 'f3base_inexistente_qa_1490', F3Base_Options::OPTION_PROVENIENCIA, 'f3base_meta_capi_token' ) );
		$grupo = F3Base_Options::fotografias_brutas( $nomes );
		$iguais = 0;
		foreach ( $nomes as $n ) {
			$iguais += ( $grupo[ $n ] === F3Base_Options::fotografia_bruta( $n ) ) ? 1 : 0;
		}
		check( count( $nomes ) === $iguais, 'm9_agrupada_igual_a_individual_' . count( $nomes ) );
		F3Base_Medicao_Contexto::snapshot();
		$q  = $wpdb->num_queries;
		$s1 = F3Base_Medicao_Contexto::snapshot();
		$c1 = $wpdb->num_queries - $q;
		$q  = $wpdb->num_queries;
		$ad = F3Base_Medicao_Contexto::administrativo();
		$c2 = $wpdb->num_queries - $q;
		$GLOBALS['checks']['m9_consultas'] = array( 'snapshot' => $c1, 'administrativo' => $c2 );
		check( ! empty( $s1['ok'] ) && ! empty( $ad['ok'] ), 'm9_leituras_ok' );
		check( $c1 <= 4 && $c2 <= 8, 'm9_consultas_reduzidas' );
		$s2 = F3Base_Medicao_Contexto::snapshot();
		check( $s1['data']['revision'] === $s2['data']['revision'], 'm9_revisao_estavel' );
		$original = F3Base_Options::ler( 'f3base_ga4_measurement_id' );
		$r        = save( 'f3base_ga4_measurement_id', 'G-QA1490ABC' );
		check( ! empty( $r['persisted'] ), 'm9_alteracao_persistida' );
		$s3 = F3Base_Medicao_Contexto::snapshot();
		check( 'G-QA1490ABC' === $s3['data']['slots']['ga4']['effective']['fields']['measurement_id'] && $s3['data']['revision'] !== $s1['data']['revision'], 'm9_alteracao_vista_na_mesma_requisicao' );
		save( 'f3base_ga4_measurement_id', $original );
		$s4 = F3Base_Medicao_Contexto::snapshot();
		check( $s4['data']['slots']['ga4']['effective']['fields']['measurement_id'] === $s1['data']['slots']['ga4']['effective']['fields']['measurement_id'], 'm9_restauracao_vista' );
	}
);

/* M10 — estado do cliente LinkedIn externo quando o SDK falha antes de responder: sem aviso PHP. */
caso(
	'm10_estado_linkedin_sem_envelope',
	static function () use ( $wpdb ): void {
		$original = $wpdb->get_var( $wpdb->prepare( 'SELECT option_value FROM %i WHERE option_name=%s', $wpdb->options, F3Base_Linkedin::OPCAO ) );
		$avisos   = array();
		set_error_handler(
			static function ( $no, $msg ) use ( &$avisos ) {
				$avisos[] = $msg;
				return true;
			},
			E_WARNING | E_NOTICE
		);
		try {
			raw( F3Base_Linkedin::OPCAO, array( 'connection_id' => 'qa-conn-1490', 'conta_id' => '123456789', 'cliente' => 'linkedin_plugin' ) );
			$e = F3Base_Linkedin_Cliente::estado();
		} finally {
			restore_error_handler();
			if ( null === $original ) {
				delete_option( F3Base_Linkedin::OPCAO );
			} else {
				raw( F3Base_Linkedin::OPCAO, maybe_unserialize( $original ) );
			}
		}
		check( array() === array_filter( $avisos, static fn( $m ) => str_contains( $m, 'Undefined array key' ) ), 'm10_sem_undefined_array_key' );
		check( false === $e['disponivel'] && array() === $e['autorizacao'] && '' !== (string) $e['codigo'], 'm10_estado_indisponivel_com_codigo' );
	}
);

/* M11 — todo link administrativo do pacote aponta para tela registrada. */
caso(
	'm11_links_admin_registrados',
	static function (): void {
		global $_registered_pages;
		require_once ABSPATH . 'wp-admin/includes/admin.php';
		do_action( 'admin_menu' );
		$registradas = array();
		foreach ( array_keys( (array) $_registered_pages ) as $hook ) {
			if ( preg_match( '/_page_(.+)$/', $hook, $m ) ) {
				$registradas[ $m[1] ] = true;
			}
		}
		$citadas = array();
		$it      = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( F3BASE_PLUGIN_DIR, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( ! preg_match( '/\.(php|js)$/', $f->getFilename() ) ) {
				continue;
			}
			preg_match_all( '/admin\.php\?page=([a-z0-9_-]+)/', (string) file_get_contents( $f->getPathname() ), $m );
			foreach ( $m[1] as $slug ) {
				$citadas[ $slug ] = true;
			}
		}
		$mortas = array_values( array_diff( array_keys( $citadas ), array_keys( $registradas ) ) );
		$GLOBALS['checks']['m11_telas_citadas'] = array_keys( $citadas );
		check( count( $citadas ) >= 5 && array() === $mortas, 'm11_sem_link_para_tela_inexistente_' . implode( '_', $mortas ) );
	}
);

caso(
	'abilities_inventario',
	static function (): void {
		$n = count( array_filter( array_keys( wp_get_abilities() ), static fn( $k ) => str_starts_with( $k, 'f3base/' ) ) );
		check( (int)(getenv('F3BASE_TARGET_ABILITIES')?:143) === $n, 'abilities_143' );
	}
);

/* Limpeza dos dados sintéticos e restauração das opções. */
foreach ( $wpdb->get_col( 'SELECT record_id FROM ' . F3Base_Leads_Repositorio::tabela() . " WHERE correlacao LIKE 'qa149-%'" ) as $id ) {
	$wpdb->delete( F3Base_Conversoes_Servidor::tabela(), array( 'record_id' => $id ) );
	$wpdb->delete( F3Base_Leads_Repositorio::tabela(), array( 'record_id' => $id ) );
}
foreach ( $original as $n => $v ) {
	raw( $n, $v );
}
wp_delete_user( $assinante );
$GLOBALS['checks']['casos'] = $GLOBALS['casos_1490'];
if ( isset( $GLOBALS['m1_resultado'] ) ) {
	$GLOBALS['checks']['m1_processo_novo'] = $GLOBALS['m1_resultado'];
}
evidence( getenv( 'F3BASE_EVIDENCIA_NOME' ) ?: 'release-1490' );
echo wp_json_encode( $GLOBALS['casos_1490'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
if ( in_array( true, array_map( static fn( $v ) => 'passou' !== $v, $GLOBALS['casos_1490'] ), true ) ) {
	exit( $GLOBALS['coletar_1490'] ? 0 : 1 );
}
