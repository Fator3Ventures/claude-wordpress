<?php
/** Production proof orchestration; synthetic PHPMailer boundary, never installed. */
require __DIR__.'/bootstrap.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';
class QA311_Mailer extends PHPMailer\PHPMailer\PHPMailer {
 public static string $mode='ok';public static array $commands=[];
 public function smtpConnect($options=null){self::$commands[]='CONNECT';$s=$this->getSMTPInstance();if(self::$mode==='porta'){$s->fase='porta';$s->falha='smtp_porta_recusada';throw new RuntimeException('private transport text');}self::$commands[]='STARTTLS';if(self::$mode==='tls'){$s->fase='tls';$s->falha='smtp_tls_falhou';throw new RuntimeException('private tls text');}self::$commands[]='AUTH';if(self::$mode==='auth'){$s->fase='autenticacao';$s->falha='smtp_autenticacao_recusada';return false;}$s->fase='autenticacao';return true;}
 public function smtpClose(){self::$commands[]='QUIT';}
 public function send(){throw new RuntimeException('DATA forbidden in proof');}
}
$source=file_get_contents(F3BASE_PLUGIN_DIR.'includes/class-f3base-smtp-prova.php');$start=strpos($source,'final class F3Base_SMTP_Prova');$source='<?php '.substr($source,$start);$source=str_replace(['final class F3Base_SMTP_Prova','new \\PHPMailer\\PHPMailer\\PHPMailer(true)','self::configurar($mail,$cfg,$password);'],['final class QA311_Prova','new QA311_Mailer(true)','$mail->setSMTPInstance(new F3Base_SMTP_Cliente());'],$source);eval(substr($source,5));
$before=[];foreach(['f3base_email_site','f3base_email_site_senha',F3Base_SMTP_Prova::STATE] as $n)$before[$n]=get_option($n,false);
try{
 $cfg=array_replace(F3Base_Email_Site_Config::padroes(),['usuario'=>'synthetic@example.test','endereco'=>'synthetic@example.test']);raw('f3base_email_site',$cfg);raw('f3base_email_site_senha',F3Base_Segredos::cifrar('f3base_email_site_senha','synthetic311'));
 foreach(['porta'=>'smtp_porta_recusada','tls'=>'smtp_tls_falhou','auth'=>'smtp_autenticacao_recusada','ok'=>'smtp_autenticado_sem_envio'] as $mode=>$code){QA311_Mailer::$mode=$mode;QA311_Mailer::$commands=[];$r=QA311_Prova::verificar();check($r['codigo']===$code,'phase_'.$mode);check($r['prova_persistida']&&$r['mensagens_enviadas']===0&&!$r['data_transmitido']&&!in_array('DATA',QA311_Mailer::$commands,true),'no_DATA_'.$mode);check(F3Base_SMTP_Prova::vigente($cfg)===($mode==='ok'),'valid_proof_'.$mode);check(!str_contains(wp_json_encode($r),'private'),'sanitized_'.$mode);}
 $r=QA311_Prova::verificar(['smtp_porta'=>465,'smtp_seguranca'=>'ssl']);check(!F3Base_SMTP_Prova::vigente($cfg),'candidate_proof_not_current_port');
 $mail=new PHPMailer\PHPMailer\PHPMailer(true);try{F3Base_SMTP_Prova::configurar($mail,array_replace($cfg,['smtp_host'=>'127.0.0.1']),'test');check(false,'private_network');}catch(RuntimeException $x){check($x->getMessage()==='smtp_destino_invalido','private_network');}
}finally{foreach($before as $n=>$v){if($v===false)delete_option($n);else raw($n,$v);}}
evidence('request-311-transport');
