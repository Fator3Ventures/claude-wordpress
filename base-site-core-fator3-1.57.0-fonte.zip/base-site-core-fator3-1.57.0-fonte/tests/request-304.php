<?php
require __DIR__.'/bootstrap.php';
class QA304_Dns extends F3Base_Email_Dns {
 public array $records=[];public bool $fail=false;public bool $exists=true;public array $calls=[];
 public function exists(string $name): bool {if($this->fail)throw new RuntimeException('email_dns_temporario');return $this->exists;}
 public function query(string $name,string $type='TXT',int $depth=0): array {$this->calls[]=$type.'|'.$name;if($this->fail)throw new RuntimeException('email_dns_temporario');return array_map(static fn($v)=>['value'=>$v,'ttl'=>60],$this->records[$type.'|'.$name]??[]);}
}
require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';
$key=openssl_pkey_new(['private_key_bits'=>2048]);openssl_pkey_export($key,$private);$pub=openssl_pkey_get_details($key)['key'];$dns=new QA304_Dns();$dns->records['TXT|qa._domainkey.sender.example']=['v=DKIM1; k=rsa; p='.preg_replace('/-----[^-]+-----|\s/','',$pub)];$dns->records['TXT|_dmarc.sender.example']=['v=DMARC1; p=reject; adkim=s; aspf=s'];
$mail=new PHPMailer\PHPMailer\PHPMailer(true);$mail->CharSet='UTF-8';$mail->setFrom('alice@sender.example','Synthetic Sender');$mail->addAddress('box@site.example');$mail->Subject='[TESTE F3BASE] assinatura';$mail->Body="Corpo assinado\nSegunda linha";$mail->DKIM_domain='sender.example';$mail->DKIM_selector='qa';$mail->DKIM_private_string=$private;$mail->DKIM_identity='alice@sender.example';$mail->preSend();$raw=$mail->getSentMIMEMessage();unset($private,$key);
$cfg=array_replace(F3Base_Email_Site_Config::padroes(),['endereco'=>'box@site.example']);
$auth=static function($mime)use($dns,&$cfg){return (new F3Base_Email_Auth($dns))->verificar($mime,$cfg,'alice@sender.example');};
$a=$auth($raw);if(!$a['aceito'])echo wp_json_encode($a)."\n";check($a['aceito']&&$a['dmarc']==='pass'&&$a['dkim'][0]['resultado']==='pass','independent_PHPMailer_DKIM_and_DMARC_pass');
$a=$auth(str_replace('Corpo assinado','Corpo adulterado',$raw));check($a['descartar']&&$a['dmarc']==='fail'&&$a['politica']==='reject','tampered_body_rejected');
$a=$auth(str_replace('Synthetic Sender','Altered Sender',$raw));check($a['descartar'],'signed_header_tampering_rejected');
$a=$auth("Authentication-Results: forged.example; dmarc=fail\r\n".$raw);check($a['aceito'],'untrusted_fail_does_not_discard');
$a=$auth("Authentication-Results: forged.example; dmarc=pass\r\n".str_replace('Corpo assinado','Alterado',$raw));check(!$a['aceito']&&$a['descartar'],'untrusted_pass_does_not_accept');
$dns->fail=true;$a=$auth($raw);check(!$a['descartar']&&!$a['aceito']&&$a['temporario'],'DNS_failure_is_pending_not_discard');$dns->fail=false;
$dns->records['TXT|_dmarc.sender.example']=['v=DMARC1; p=quarantine'];$a=$auth(str_replace('Corpo assinado','Alterado',$raw));check($a['descartar'],'quarantine_rejected');
$dns->records['TXT|_dmarc.sender.example']=['v=DMARC1; p=none'];$a=$auth(str_replace('Corpo assinado','Alterado',$raw));check(!$a['descartar']&&!$a['aceito'],'p_none_suspect');
unset($dns->records['TXT|_dmarc.sender.example']);$a=$auth($raw);check($a['aceito']&&$a['dmarc']==='none','no_DMARC_aligned_DKIM_accepted');
$cfg['authserv_ids']=['mx.provider.example'];$dns->fail=true;$a=$auth("Authentication-Results: mx.provider.example; dmarc=pass header.from=sender.example\r\n".$raw);check($a['aceito']&&$a['metodo']==='authentication_results','trusted_AR_no_DNS_required');$dns->fail=false;$cfg['authserv_ids']=[];
$dns->records['TXT|sender.example']=['v=spf1 ip4:203.0.113.0/24 -all'];$spf=new F3Base_Email_Spf($dns,'203.0.113.9','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='pass','spf_ipv4');
$spf=new F3Base_Email_Spf($dns,'192.0.2.1','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='fail','spf_unauthorized');
$dns->records['TXT|sender.example']=['v=spf1 ip6:2001:db8::/32 -all'];$spf=new F3Base_Email_Spf($dns,'2001:db8::1','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='pass','spf_ipv6');
$dns->records['TXT|sender.example']=['v=spf1 include:include.example -all'];$dns->records['TXT|include.example']=['v=spf1 ip4:203.0.113.9 -all'];$spf=new F3Base_Email_Spf($dns,'203.0.113.9','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='pass','spf_include');
$dns->records['TXT|sender.example']=['v=spf1 redirect=include.example'];$spf=new F3Base_Email_Spf($dns,'203.0.113.9','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='pass','spf_redirect');
$dns->records['TXT|sender.example']=['v=spf1 mx -all'];$dns->records['MX|sender.example']=['mx.sender.example'];$dns->records['A|mx.sender.example']=['203.0.113.9'];$spf=new F3Base_Email_Spf($dns,'203.0.113.9','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='pass','spf_mx');
$dns->records['TXT|sender.example']=['v=spf1 exists:%{i}.check.example -all'];$dns->records['A|203.0.113.9.check.example']=['192.0.2.1'];$spf=new F3Base_Email_Spf($dns,'203.0.113.9','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='pass','spf_macro_exists');
$dns->records['TXT|sender.example']=['v=spf1 include:sender.example -all'];$spf=new F3Base_Email_Spf($dns,'203.0.113.9','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='permerror','spf_recursion_budget');
$dns->records['TXT|sender.example']=['v=spf1 ip4:203.0.113.9 -all','v=spf1 +all'];$spf=new F3Base_Email_Spf($dns,'203.0.113.9','alice@sender.example','mail.sender.example');check($spf->check('sender.example')==='permerror','spf_multiple_records');
$received="Received: from sender.example (sender.example [8.8.8.8]) by mx1.dreamhost.com with ESMTPS; Mon, 26 Oct 2026 00:00:00 +0000\r\nReturn-Path: <alice@sender.example>\r\nFrom: alice@sender.example\r\nTo: box@site.example\r\nSubject: Synthetic\r\n\r\nBody\r\n";
$dns->records['TXT|sender.example']=['v=spf1 ip4:8.8.8.8 -all'];$dns->records['TXT|_dmarc.sender.example']=['v=DMARC1; p=reject'];$a=$auth($received);check($a['aceito']&&$a['spf']==='pass','trusted_received_envelope_spf_alignment');
$a=$auth(str_replace('mx1.dreamhost.com','mx1.dreamhost.com.attacker.example',$received));check(!$a['aceito'],'MX_suffix_confusion_rejected');
$a=$auth("Received: from attacker ([9.9.9.9]) by untrusted.example; now\r\n".$received);check(!$a['aceito'],'forged_lower_received_ignored');
$a=$auth(str_replace('Return-Path: <alice@sender.example>','Return-Path: <alice@other.example>',$received));check(!$a['aceito'],'SPF_uses_envelope_not_From');
$dns->records['TXT|_dmarc.sender.example']=['v=DMARC1; p=reject; adkim=r'];$dns->records['TXT|_dmarc.child.sender.example']=['v=DMARC1; p=none'];
$reflect=new ReflectionMethod(F3Base_Email_Auth::class,'aligned');$checker=new F3Base_Email_Auth($dns);check($reflect->invoke($checker,'child.sender.example','sender.example','r'),'relaxed_org_tree_alignment');check(!$reflect->invoke($checker,'child.sender.example','sender.example','s'),'strict_alignment');check(!$reflect->invoke($checker,'evil.example','sender.example','r'),'unrelated_org_not_aligned');
check(F3Base_Email_Auth::canonical_body("a \t\r\n\r\n",'relaxed')==="a\r\n",'canonical_relaxed_body_vector');check(F3Base_Email_Auth::canonical_body('', 'simple')==="\r\n"&&F3Base_Email_Auth::canonical_body('', 'relaxed')==='','empty_body_vectors');
check(F3Base_Email_Auth::canonical_header("SUBJect:  a\t b \r\n\t c  ",'relaxed')==="subject:a b c\r\n",'canonical_header_vector');
$hdr=pack('nnnnnn',7,0x8183,1,0,0,0)."\x01a\x07example\0".pack('nn',16,1);check(F3Base_Email_Dns::decode($hdr,7,'a.example',16)===[],'DNS_NXDOMAIN_negative');
$bad=substr_replace($hdr,pack('n',0x8182),2,2);try{F3Base_Email_Dns::decode($bad,7,'a.example',16);check(false,'DNS_SERVFAIL');}catch(RuntimeException $e){check($e->getMessage()==='email_dns_temporario','DNS_SERVFAIL_temporary');}
$bad=pack('nnnnnn',7,0x8180,1,0,0,0)."\xc0\x0c".pack('nn',16,1);try{F3Base_Email_Dns::decode($bad,7,'a.example',16);check(false,'DNS_loop');}catch(RuntimeException $e){check(true,'DNS_pointer_loop_refused');}

$policyMethod=new ReflectionMethod(F3Base_Email_Auth::class,'policy');$dns->records['TXT|_dmarc.parent.example']=['v=DMARC1; p=none; sp=quarantine; np=reject'];$dns->exists=false;$p=$policyMethod->invoke(new F3Base_Email_Auth($dns),'missing.parent.example');check($p['policy']==='reject','DMARC_np_only_confirmed_NXDOMAIN');$dns->exists=true;$p=$policyMethod->invoke(new F3Base_Email_Auth($dns),'present.parent.example');check($p['policy']==='quarantine','DMARC_sp_existing_domain');
$a=$auth("From: other@sender.example\r\n".$raw);check(!$a['aceito']&&!$a['descartar']&&$a['motivo']==='from_ambiguo','multiple_From_not_authenticated');
if(function_exists('sodium_crypto_sign_keypair')){
 $kp=sodium_crypto_sign_keypair();$public=sodium_crypto_sign_publickey($kp);$secret=sodium_crypto_sign_secretkey($kp);$edBody="Ed25519 independent simple canonical fixture\r\n";$headers="From: alice@sender.example\r\nTo: box@site.example\r\nSubject: Ed25519\r\n";
 $dkim='DKIM-Signature: v=1; a=ed25519-sha256; c=simple/simple; d=sender.example; s=ed; h=from:to:subject; bh='.base64_encode(hash('sha256',$edBody,true)).'; b=';
 $signature=sodium_crypto_sign_detached(hash('sha256',$headers.$dkim,true),$secret);$signed=$dkim.base64_encode($signature)."\r\n".$headers."\r\n".$edBody;$dns->records['TXT|ed._domainkey.sender.example']=['v=DKIM1; k=ed25519; p='.base64_encode($public)];
 $a=$auth($signed);check($a['aceito']&&$a['dkim'][0]['resultado']==='pass','ed25519_independent_signature');$a=$auth(str_replace('Subject: Ed25519','Subject: Tampered',$signed));check(!$a['aceito'],'ed25519_header_tampering');
 $a=$auth("DKIM-Signature: v=1; a=rsa-sha1; b=bad; bh=bad; d=sender.example; s=bad; h=from\r\n".$signed);check($a['aceito']&&count($a['dkim'])===2&&$a['dkim'][1]['resultado']==='pass','valid_signature_after_invalid_signature');sodium_memzero($secret);sodium_memzero($kp);
}

evidence('request-304');
