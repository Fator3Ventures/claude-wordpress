from pathlib import Path
import os,subprocess,json,shutil,zipfile,hashlib
root=Path(__file__).resolve().parents[1]
# This script is launched inside run-lab.py so MySQL and PHP share a network namespace.
base=Path(os.environ['F3BASE_BASE_ZIP'])
BASE_SHA=os.environ.get('F3BASE_BASE_SHA256','91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de')
BASE_VER=os.environ.get('F3BASE_BASE_VERSION','1.48.0');TARGET_VER=os.environ.get('F3BASE_TARGET_VERSION','1.49.0');CONTRACT=os.environ.get('F3BASE_TARGET_CONTRACT','8.14.0')
assert hashlib.sha256(base.read_bytes()).hexdigest() == BASE_SHA
candidate=Path(os.environ.get('F3BASE_CANDIDATE',str(root/'build/candidate.zip')))
if not os.environ.get('F3BASE_CANDIDATE'):
 with zipfile.ZipFile(candidate,'w',zipfile.ZIP_DEFLATED) as z:
  for f in (root/'work/plugin/base-site-core-fator3').rglob('*'):
   if f.is_file():z.write(f,str(f.relative_to(root/'work/plugin')))
lab=Path(os.environ.get('F3BASE_LAB_DIR',str(root/'lab')))
results={}
for kind in os.environ.get('F3BASE_CYCLE_KINDS','fresh,upgrade').split(','):
 content=lab/f'content-{kind}'
 if content.exists():shutil.rmtree(content)
 content.mkdir();(content/'plugins').mkdir()
 shutil.copytree(lab/'wordpress/wp-content/mu-plugins',content/'mu-plugins');shutil.copytree(lab/'wordpress/wp-content/themes',content/'themes')
 with zipfile.ZipFile(candidate if kind=='fresh' else base) as z:
  z.extractall(content/'plugins')
  for entry in z.infolist():
   if not entry.is_dir():assert (content/'plugins'/entry.filename).read_bytes()==z.read(entry),entry.filename
 env=dict(os.environ,F3BASE_LAB_DB=os.environ.get('F3BASE_LAB_DB','core_lab')+'_'+kind,F3BASE_LAB_CONTENT=str(content))
 def call(mode,*args):
  r=subprocess.run([str(root/'build/php'),str(root/'tests/cycle-1370.php'),mode,*map(str,args)],env=env,capture_output=True,text=True)
  if r.returncode:raise RuntimeError(mode+' '+r.stdout[-1000:]+r.stderr[-1000:])
  try:return json.loads(r.stdout)
  except:raise RuntimeError(mode+' '+r.stdout[-1500:]+r.stderr[-1000:])
 out={'install':call('install')};assert out['install']['ok'],out
 assert out['install']['versao']==(TARGET_VER if kind=='fresh' else BASE_VER),out['install']
 if kind=='upgrade':
  out['seed']=call('seed');out['before']=call('snapshot');out['upload']=call('native-upload',candidate);assert out['upload']['ok'],out['upload']
 out['migrate']=call('migrate');print(json.dumps(out['migrate']),flush=True);assert out['migrate']['ok'],out['migrate'];out['finalize']=call('finalize');out['status']=call('status');assert out['status']['versao']==TARGET_VER and out['status']['structure_ready'],out['status'];assert out['status']['contrato']==CONTRACT;assert out['status']['tentativas_prontas'];assert out['status']['callback_preservada'];assert not out['status']['gtm_agendado'];assert out['status']['ga4_tabelas'] and out['status']['ga4_desligado'] and out['status']['ga4_retencao']==0 and out['status']['instagram_outbox']
 if kind=='upgrade':
  assert out['status']['vital_legado']['automacao']=='legado_desconhecido' and out['status']['vital_legado']['atribuicao'] is None and float(out['status']['vital_legado']['valor'])==13000;assert all(out['status']['conteudo_padrao'].values()),out['status']['conteudo_padrao'];out['email']=call('email-check');out['after']=call('snapshot');(root/os.environ.get('F3BASE_EVIDENCE_DIR','evidence')/'native-cycle-debug.json').write_text(json.dumps(out,indent=2));assert out['before']==out['after'],(out['before'],out['after']);assert out['status']['vazio_preservado'] and out['status']['procedencia_preservada'] and out['status']['textos_acrescentados_corretamente'],out['status'];assert out['status']['cursor']['ate']==1500000123
 out['repeat']=call('migrate');assert out['repeat']['codigo']=='atual',out['repeat'];results[kind]=out
 print(kind, 'OK',flush=True)
results['candidate_sha256']=hashlib.sha256(candidate.read_bytes()).hexdigest();results['clock']='finalization delay accelerated in disposable state; separate fresh requests'
(root/os.environ.get('F3BASE_EVIDENCE_DIR','evidence')/('native-cycles-'+TARGET_VER.replace('.','')+'.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2))
