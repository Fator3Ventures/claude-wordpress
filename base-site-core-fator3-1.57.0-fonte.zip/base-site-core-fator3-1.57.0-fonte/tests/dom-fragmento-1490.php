<?php
/** Gera o fragmento real do seletor de catálogo (Google e LinkedIn) para o teste DOM 1.49.0. */
require __DIR__ . '/bootstrap.php';
ob_start();
F3Base_Anuncios_Selecao::campo( 'f3base_anuncios_google', 'campanhas', array( '111' ), 'qa_google', 'qa-google' );
F3Base_Anuncios_Selecao::campo( 'f3base_anuncios_linkedin', 'formularios', array(), 'qa_linkedin', 'qa-linkedin' );
echo '<p><button type="button" class="button" id="f3base-linkedin-campanhas">Atualizar campanhas da conta</button> <span id="f3base-linkedin-campanhas-estado" role="status"></span></p>';
file_put_contents( getenv( 'F3BASE_DOM_FRAGMENTO' ), ob_get_clean() );
echo "fragmento gerado\n";
