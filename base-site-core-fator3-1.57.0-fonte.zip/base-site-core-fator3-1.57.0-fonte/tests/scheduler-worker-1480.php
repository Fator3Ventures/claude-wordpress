<?php
class WP_CLI {public static function add_command(...$args){} public static function add_hook(...$args){} }
if(($argv[1]??'')==='cli'){define('WP_CLI',true);}else{define('DOING_CRON',true);}
require __DIR__.'/bootstrap.php';global $wpdb;$key=$argv[2];$at=(int)$argv[3];$mode=$argv[4]??'normal';
$e=array('id'=>'anuncios','hook'=>'f3base_anuncios_consultar','args'=>array($key),'timestamp'=>$at,'schedule'=>false);
$cb=static function()use($key){file_put_contents((getenv('F3BASE_LAB_DIR')?:getenv('F3BASE_ROOT').'/lab').'/'.$key.'.entered','1',FILE_APPEND);usleep(700000);return array('ok'=>true);};$property=new ReflectionProperty(F3Base_Operacao::class,'callbacks');$property->setValue(null,array($e['hook']=>array(array('function'=>$cb,'accepted_args'=>0,'priority'=>10))));
F3Base_Execucoes::iniciar('qa148');if($mode==='fault'){$wpdb->suppress_errors(true);add_filter('query',static function($sql)use($wpdb){return str_starts_with($sql,'UPDATE')&&str_contains($sql,"option_name='f3base_operacao_estado'")?'UPDATE '.$wpdb->options." SET qa148_missing_column=1 WHERE option_name='f3base_operacao_estado'":$sql;},999);}
$m=new ReflectionMethod(F3Base_Operacao::class,'executar_evento');$r=$m->invoke(null,$e,true);F3Base_Execucoes::encerrar();$r['intencao']=F3Base_Operacao_Intencoes::obter($e);echo wp_json_encode($r)."\n";
