// Teste DOM 1.49.0 (jsdom): o seletor de catálogo e o botão de campanhas LinkedIn mostram `mensagem`
// quando a rota devolve recusa acionável; sem `mensagem`, mantêm o rótulo do código (comportamento 1.48.0).
// Uso: node dom-1490.cjs <fragmento.html> <f3base-config143.js> <saida.json>
const fs = require('fs');
const { JSDOM } = require(process.env.F3_JSDOM || 'jsdom');
const [frag, js, out] = process.argv.slice(2);
const checks = {};
const ck = (ok, name) => { checks[name] = !!ok; if (!ok) throw new Error('FAIL ' + name); };
async function cenario(resposta) {
  const dom = new JSDOM(`<!doctype html><html><body><form>${fs.readFileSync(frag, 'utf8')}</form></body></html>`, { runScripts: 'outside-only', url: 'http://127.0.0.1/wp-admin/admin.php?page=f3base-medicao' });
  const w = dom.window; w.ajaxurl = '/wp-admin/admin-ajax.php';
  const chamadas = [];
  w.fetch = async (url, init) => { chamadas.push(String(init.body)); return { json: async () => resposta }; };
  w.eval(fs.readFileSync(js, 'utf8'));
  w.document.dispatchEvent(new w.Event('DOMContentLoaded'));
  await new Promise(r => setTimeout(r, 20));
  return { w, chamadas };
}
(async () => {
  const msg = 'O Fator3 MCP instalado recusou a chamada administrativa nativa de ads/search (profile_denied); a consulta não chegou ao fornecedor. Atualize o Fator3 MCP para 0.29.0 ou superior.';
  let { w, chamadas } = await cenario({ ok: false, codigo: 'mcp_recusou_chamada_nativa', mensagem: msg, motivo: 'profile_denied' });
  const picker = w.document.querySelector('.f3base-catalog-picker[data-source="f3base_anuncios_google"]');
  ck(picker, 'picker_renderizado_pelo_php');
  const botao = Array.from(picker.querySelectorAll('button')).find(b => /Atualizar lista/.test(b.textContent));
  ck(botao, 'botao_atualizar');
  botao.click(); await new Promise(r => setTimeout(r, 30));
  const estado = picker.querySelector('[role=status]').textContent;
  ck(estado.includes(msg), 'picker_mostra_mensagem');
  ck(chamadas.length === 1 && chamadas[0].includes('action=f3base_anuncios_catalogo'), 'picker_chamou_rota');
  const li = w.document.getElementById('f3base-linkedin-campanhas');
  li.click(); await new Promise(r => setTimeout(r, 30));
  ck(w.document.getElementById('f3base-linkedin-campanhas-estado').textContent.includes(msg), 'linkedin_campanhas_mostra_mensagem');
  ({ w } = await cenario({ ok: false, codigo: 'google_catalogo_indisponivel' }));
  const p2 = w.document.querySelector('.f3base-catalog-picker[data-source="f3base_anuncios_google"]');
  Array.from(p2.querySelectorAll('button')).find(b => /Atualizar lista/.test(b.textContent)).click(); await new Promise(r => setTimeout(r, 30));
  const e2 = p2.querySelector('[role=status]').textContent;
  ck(/Google catalogo indisponivel|google_catalogo_indisponivel|Google catálogo/i.test(e2) && !e2.includes('undefined'), 'sem_mensagem_mantem_rotulo_do_codigo');
  ck(!/<[a-z]/i.test(estado), 'texto_sem_html');
  fs.writeFileSync(out, JSON.stringify({ ambiente: 'jsdom ' + require(require.resolve('jsdom/package.json', { paths: [process.env.F3_JSDOM ? require('path').dirname(require('path').dirname(process.env.F3_JSDOM)) : __dirname] })).version + ', fragmento gerado pelo PHP do Core no laboratório, JS instalado', checks, exemplo: estado, sem_mensagem: e2 }, null, 2));
  console.log('dom-1490:', Object.keys(checks).length, 'checks OK');
})().catch(e => { console.error(e.message); process.exit(1); });
