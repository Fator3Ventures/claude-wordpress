<?php
$_SERVER['HTTP_HOST']='localhost';
if(!function_exists('add_action')){require_once getenv('F3BASE_SITE')?:__DIR__.'/../../../runtime-1330/wordpress/wp-load.php';}
require_once ABSPATH.'wp-admin/includes/template.php';wp_set_current_user(1);
add_filter('pre_wp_mail',static fn()=>true,10);add_filter('pre_http_request',static fn()=>new WP_Error('teste_sem_transporte_externo'),10,3);
$checks=[];function verificar($test,string $name): void {global $checks;$checks[$name]=(bool)$test;if(!$test){throw new RuntimeException('Falhou: '.$name);}}
function evidencia(string $file): void {global $checks;file_put_contents(__DIR__.'/evidencias/'.$file.'.json',wp_json_encode(['plugin'=>F3BASE_PLUGIN_VERSAO,'ambiente'=>'WordPress local; dados sintéticos; transportes externos simulados','checks'=>$checks],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($checks,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";}
function gravar_teste(string $name,$value): array {return F3Base_Options::pelo_canal('ability',static fn()=>F3Base_Options::gravar($name,$value,F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao($name)));}
function bruto_teste(string $name,$value): void {global $wpdb;if($wpdb->get_var($wpdb->prepare('SELECT option_id FROM %i WHERE option_name=%s',$wpdb->options,$name))===null){$wpdb->insert($wpdb->options,['option_name'=>$name,'option_value'=>maybe_serialize($value),'autoload'=>'no']);}else{$wpdb->update($wpdb->options,['option_value'=>maybe_serialize($value)],['option_name'=>$name]);}wp_cache_delete($name,'options');wp_cache_delete('alloptions','options');}
