<?php
/**
 * Documentação instalada 1.49.0: leitura integral de TODOS os documentos do índice
 * pela ability pública f3base/documentacao-ler, com paginação, SHA-256 e confinamento.
 */
require __DIR__ . '/bootstrap.php';
require_once ABSPATH . 'wp-admin/includes/user.php';
if(class_exists('Fator3\\McpFiles\\Persistence')){
 $app=WP_Application_Passwords::create_new_application_password(1,['name'=>'QA1560 docs temporary']);$connection='app:'.$app[1]['uuid'];\Fator3\McpFiles\Persistence::put('connections',$connection,['connection_id'=>$connection,'user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);do_action('application_password_did_authenticate',get_user_by('id',1),$app[1]);register_shutdown_function(static function()use($app,$connection){WP_Application_Passwords::delete_application_password(1,$app[1]['uuid']);\Fator3\McpFiles\Persistence::delete('connections',$connection);});
}

$http = 0;
add_filter(
	'pre_http_request',
	static function () use ( &$http ) {
		++$http;
		return new WP_Error( 'qa_sem_transporte_externo' );
	},
	1
);
$ability = wp_get_ability( 'f3base/documentacao-ler' );
check( (bool) $ability, 'ability_documentacao' );
$index = $ability->execute( array() );if(is_wp_error($index)||empty($index['ok']))echo wp_json_encode($index)."\n";
check( ! empty( $index['ok'] ) && '1.56.0' === $index['versao'] && 'docs/DOCUMENTACAO.md' === $index['indice'], 'indice_atual' );
$arquivos = $index['arquivos'];
foreach ( array( 'docs/RELEASE-1.56.0.md', 'docs/AGENTES-1.56.0.md', 'docs/dados/contrato.json', 'docs/dados/abilities-1.json' ) as $obrigatorio ) {
	check( in_array( $obrigatorio, $arquivos, true ), 'indice_contem_' . $obrigatorio );
}
$paginas = 0;
foreach ( $arquivos as $file ) {
	$at   = 1;
	$text = array();
	do {
		$r = $ability->execute( array( 'arquivo' => $file, 'linha' => $at, 'limite' => 200 ) );
		check( ! empty( $r['ok'] ) && '1.56.0' === $r['versao'], 'pagina_' . $file . '_' . $at );
		$text[] = $r['texto'];
		$at     = $r['proxima_linha'];
		++$paginas;
	} while ( null !== $at );
	check( $r['sha256'] === hash_file( 'sha256', F3BASE_PLUGIN_DIR . $file ), 'hash_' . $file );
	$original = file( F3BASE_PLUGIN_DIR . $file, FILE_IGNORE_NEW_LINES );
	check( implode( "\n", $text ) === implode( "\n", $original ), 'integral_' . $file );
}
foreach ( $index['aliases'] as $alias => $canonico ) {
	$r = $ability->execute( array( 'arquivo' => $alias, 'linha' => 1, 'limite' => 5 ) );
	check( ! empty( $r['ok'] ) && $r['arquivo_canonico'] === $canonico, 'alias_' . $alias );
}
$release = $ability->execute( array( 'arquivo' => 'docs/RELEASE-1.56.0.md', 'linha' => 1, 'limite' => 200 ) );
foreach ( array( '307', '308', '309', '310', '311', '8.21.0', 'pipedrive-api-client/1.0.0' ) as $termo ) {
	check( str_contains( $release['texto'], $termo ), 'release_cita_' . $termo );
}
foreach ( array( '../../wp-config.php', 'docs/../../../wp-config.php', '/etc/passwd', 'https://example.test/x.md', 'base-site-core-fator3.php' ) as $ruim ) {
	check( empty( $ability->execute( array( 'arquivo' => $ruim ) )['ok'] ), 'confinamento_' . md5( $ruim ) );
}
check( 0 === $http, 'leitura_sem_http' );
$sub = wp_insert_user( array( 'user_login' => 'qa_docs_1560_'.bin2hex(random_bytes(4)), 'user_pass' => wp_generate_password( 24 ), 'role' => 'subscriber', 'user_email' => 'docs1560_'.bin2hex(random_bytes(4)).'@example.test' ) );
check(!is_wp_error($sub),'temporary_subscriber_created');register_shutdown_function(static function()use($sub){wp_delete_user($sub);});wp_set_current_user( $sub );
$denied=$ability->execute(array());check(is_wp_error($denied)||empty($denied['ok'])&&($denied['success']??null)===false&&!isset($denied['texto'],$denied['arquivos']), 'assinante_recusado');
wp_set_current_user( 0 );
$denied=$ability->execute(array());check(is_wp_error($denied)||empty($denied['ok'])&&($denied['success']??null)===false&&!isset($denied['texto'],$denied['arquivos']), 'anonimo_recusado');
wp_set_current_user( 1 );
wp_delete_user( $sub );
$GLOBALS['checks']['documentos'] = count( $arquivos );
$GLOBALS['checks']['paginas']    = $paginas;
evidence( 'docs-1560' );
