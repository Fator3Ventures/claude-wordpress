<?php
/** Lab-only authorization probe: calls every f3base admin_post/wp_ajax handler as a subscriber with nonce checks satisfied. */
// wp_verify_nonce overridden by MU fixture when F3BASE_NONCE_BYPASS=1.
require_once ABSPATH.'wp-admin/includes/user.php';
$u=get_user_by('login','qa_sub_1490'); if(!$u){$id=wp_insert_user(['user_login'=>'qa_sub_1490','user_pass'=>wp_generate_password(),'role'=>'subscriber','user_email'=>'sub1490@example.test']);}else{$id=$u->ID;}
wp_set_current_user($id);
do_action('admin_init');
global $wp_filter;$hooks=[];
foreach(array_keys($wp_filter) as $h){ if(preg_match('/^(wp_ajax|admin_post)_(f3base|f3_base)/',$h)) $hooks[]=$h; }
sort($hooks);
if(!empty(($GLOBALS['argv'][1]??''))){ if(($GLOBALS['argv'][1]??'')==='list'){echo implode("\n",$hooks),"\n";return;} $hooks=[($GLOBALS['argv'][1]??'')]; }
add_filter('wp_die_handler',static fn()=>static function($m,$t='',$a=[]){throw new RuntimeException('DIE:'.(is_array($a)?($a['response']??''):'').':'.wp_strip_all_tags(is_string($m)?$m:(is_wp_error($m)?$m->get_error_message():json_encode($m))));});
add_filter('wp_die_ajax_handler',static fn()=>static function($m,$t='',$a=[]){throw new RuntimeException('DIE:'.(is_array($a)?($a['response']??''):'').':'.wp_strip_all_tags(is_string($m)?$m:(is_wp_error($m)?$m->get_error_message():json_encode($m))));});
add_filter('wp_die_json_handler',static fn()=>static function($m,$t='',$a=[]){throw new RuntimeException('DIE:'.(is_array($a)?($a['response']??''):'').':'.wp_strip_all_tags(is_string($m)?$m:json_encode($m)));});
add_filter('wp_redirect',static function($l){throw new RuntimeException('REDIRECT:'.$l);});
add_filter('wp_doing_ajax',static fn()=>str_starts_with(current_filter()?:'','wp_ajax')?true:false);
$out=[];
foreach($hooks as $h){
  $_POST=$_REQUEST=$_GET=['_wpnonce'=>'x','_ajax_nonce'=>'x','nonce'=>'x','id'=>'1','acao'=>'aplicar','confirmar'=>'1','formulario'=>'x','registro'=>'1'];
  fwrite(STDERR,"CALL $h\n");ob_start();$res="";
  try{ do_action($h); $res='RETURNED'; }catch(Throwable $e){ $res=$e->getMessage(); }
  $o=ob_get_clean();
  $out[$h]=substr(trim($res." | ".$o),0,220); fwrite(STDERR,"  => ".$out[$h]."\n");
}
foreach($out as $h=>$r){ echo str_pad($h,48),' ',$r,"\n"; }
