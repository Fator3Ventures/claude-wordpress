"""Type-confusion probe of public f3base REST routes in a disposable lab. Reports 5xx and new PHP log lines."""
import urllib.parse
import json, sys, urllib.request, urllib.error, os, itertools
base = sys.argv[1]; log = sys.argv[2]
routes = [('POST','/formularios/tentativas'),('POST','/contexto-diagnostico'),('POST','/leads/contexto'),('POST','/pipedrive/qualidade'),('GET','/contexto-publico'),('POST','/anuncios/google'),('POST','/anuncios/linkedin/notificacoes'),('GET','/anuncios/linkedin/notificacoes'),('GET','/servidor-sonda'),('POST','/analise'),('POST','/meta-eventos'),('POST','/formularios/complementar'),('POST','/formularios/token'),('POST','/formularios/enviar'),('GET','/relatorio'),('POST','/lead'),('GET','/token'),('POST','/consentimento'),('GET','/comportamento/token'),('POST','/comportamento'),('POST','/comportamento/esquecer'),('GET','/origem'),('POST','/eliminacao')]
keys = ['token','formulario','formulario_id','campos','nome','email','telefone','pagina','sessao','evento','eventos','contexto','consentimento','categorias','identificador','regime','caminho','corpo','metodo','dados','id','tipo','origem','url','referencia','event_id','lead_id','campanha','utm','valor','tentativa','assinatura','chave','visitante','decisao']
weird = [['a',['b']], {'x':{'y':1}}, 12345678901234567890, -1, None, True, 'x'*9000, '<script>', '../../etc/passwd', '%00', '1e999']
def size(): return os.path.getsize(log) if os.path.exists(log) else 0
findings=[]
for method, r in routes:
    for w in weird:
        body = {k: w for k in keys}
        url = base + '/wp-json/f3base/v1' + r
        data = None
        if method == 'GET':
            qs = '&'.join(f'{k}[]=a' if isinstance(w,list) else f'{k}={urllib.parse.quote(str(w)[:500])}' for k in keys)
            url += '?' + qs
        elif os.environ.get('FUZZ_FORM'):
            data = '&'.join(f'{k}[]=a&{k}[x][]=b' if isinstance(w,list) else f'{k}={urllib.parse.quote(str(w)[:500])}' for k in keys).encode()
        else:
            data = json.dumps(body).encode()
        before = size()
        req = urllib.request.Request(url, data=data, method=method, headers={'Content-Type':'application/x-www-form-urlencoded' if os.environ.get('FUZZ_FORM') else 'application/json','User-Agent':'Mozilla/5.0 lab-fuzz'})
        try:
            with urllib.request.urlopen(req, timeout=30) as resp: code = resp.status; txt = resp.read(300)
        except urllib.error.HTTPError as e: code = e.code; txt = e.read(300)
        except Exception as e: code = 'EXC'; txt = str(e).encode()
        after = size(); new = ''
        if after > before:
            with open(log,'rb') as f: f.seek(before); new = f.read().decode('utf8','replace')
        bad = [l for l in new.splitlines() if ('PHP ' in l and 'LAB_HTTP' not in l)]
        if (isinstance(code,int) and code >= 500) or code=='EXC' or bad:
            findings.append((method, r, repr(w)[:40], code, txt[:200], bad[:3]))
import urllib.parse
seen=set()
for f in findings:
    k=(f[0],f[1],str(f[3]),tuple(x.split('] ',1)[-1][:160] for x in f[5]))
    if k in seen: continue
    seen.add(k); print(f[0], f[1], 'val=',f[2], 'code=',f[3]); print('   body:', f[4]); [print('   log:', x.split('] ',1)[-1][:400]) for x in f[5]]
print('findings', len(findings))
