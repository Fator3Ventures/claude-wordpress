"""Visita (GET) todas as telas administrativas do Core alcançáveis por links a partir do menu, como administrador logado; relata status e linhas novas do debug.log."""
import subprocess,re,sys,os,html,json,time
base,jar,log,out=sys.argv[1:5]
def get(u):
    r=subprocess.run(['curl','-s','-b',jar,'-w','\n%{http_code}',u],capture_output=True,text=True).stdout
    body,_,code=r.rpartition('\n');return code,body
seeds=['admin.php?page=base-site-core-fator3','admin.php?page=f3base-formularios','admin.php?page=f3base-leads','admin.php?page=f3base-medicao','admin.php?page=f3base-relatorios']
seen=set();queue=[base+'/wp-admin/'+s for s in seeds];res={}
while queue and len(seen)<250:
    u=queue.pop(0)
    if u in seen:continue
    seen.add(u);before=os.path.getsize(log) if os.path.exists(log) else 0
    code,body=get(u);time.sleep(0.05)
    new=''
    if os.path.exists(log) and os.path.getsize(log)>before:
        with open(log,'rb') as f:f.seek(before);new=f.read().decode('utf8','replace')
    res[u.replace(base,'')]={'status':code,'php':[l.split('] ',1)[-1][:220] for l in new.splitlines() if 'PHP ' in l and 'wordpress.org' not in l]}
    for h in re.findall(r'href=["\']([^"\']+)["\']',body):
        h=html.unescape(h)
        if h.startswith(base+'/wp-admin/admin.php?page=') and ('f3base' in h or 'base-site-core' in h) and 'action=' not in h and '_wpnonce' not in h and 'baixar' not in h and 'csv' not in h.lower() and 'exportar' not in h:
            if h not in seen:queue.append(h)
bad={k:v for k,v in res.items() if v['status']!='200' or v['php']}
json.dump({'paginas':len(res),'com_problema':bad,'todas':res},open(out,'w'),ensure_ascii=False,indent=1)
print('paginas',len(res),'com problema',len(bad));[print(k,v) for k,v in list(bad.items())[:20]]
