#!/bin/bash
# matrix.sh <nome-do-lab> <versao-wordpress> <banco> : laboratório limpo a partir do instalador em release/ + suíte 1.49.0.
# Acompanhantes: F3BASE_COMPANIONS_DIR (padrão companions/) e F3BASE_COMPANION_VERSIONS.
# Requer: F3BASE_SHARED_MYSQL=1 e F3BASE_DB_HOST/F3BASE_DB_USER/F3BASE_DB_PASSWORD de um MySQL descartável;
# F3BASE_WP_ZIPS com wordpress-<versao>.zip; F3BASE_LABS_DIR para os laboratórios. Nunca aponte para banco real.
set -e
ROOT=$(cd "$(dirname "$0")/../.." && pwd); cd "$ROOT"
LAB=${F3BASE_LABS_DIR:?}/$1; WPV=$2; export F3BASE_LAB_DB=$3 F3BASE_LAB_DIR=$LAB F3BASE_EVIDENCE_DIR=evidence/1490/$1
case "$3" in core_*) ;; *) echo "banco precisa começar por core_"; exit 2;; esac
export F3BASE_WORDPRESS_CORE=${F3BASE_WP_ZIPS:?}/wordpress-$WPV.zip
rm -rf "$LAB"; mkdir -p "$(dirname "$LAB")"
mysql -h"${F3BASE_DB_HOST%%:*}" -u"$F3BASE_DB_USER" -p"$F3BASE_DB_PASSWORD" -e "DROP DATABASE IF EXISTS $3" 2>/dev/null
EX=$(mktemp -d); unzip -q release/base-site-core-fator3-1.49.0-instalador.zip -d "$EX"
F3BASE_PLUGIN_TREE=$EX/base-site-core-fator3 python3 build/setup-lab.py; rm -rf "$EX"
COMP=${F3BASE_COMPANIONS_DIR:-companions}   # pasta com as quatro pastas de plugin; F3BASE_COMPANION_VERSIONS (JSON) informa as versões esperadas
for s in wp-mcp-fator3 wp-mcp-google-fator3 wp-mcp-linkedin-fator3 wp-mcp-meta-fator3; do cp -a "$COMP/$s" "$LAB/wordpress/wp-content/plugins/"; done
: > "$LAB/php-errors.log"
python3 tests/run-lab.py tests/install.php tests/release-1490.php tests/forms-1470.php tests/pipedrive-1470.php tests/linkedin-1480.php tests/slack-1480.php tests/scheduler-setup-1480.php tests/scheduler-1480.py tests/docs-1490.php tests/coexistence-1490.php tests/coexistence-1490.php tests/provider-linkedin-1480.php
echo "== php-errors.log ($1)"; sed 's/^\[[^]]*\] //' "$LAB/php-errors.log" | cut -c1-240 | sort | uniq -c | sort -rn | head -20
