<?php
// Lab-only: when F3BASE_NONCE_BYPASS=1, nonces always verify (authorization probe only).
if(getenv('F3BASE_NONCE_BYPASS')==='1' && !function_exists('wp_verify_nonce')){ function wp_verify_nonce($n,$a=-1){return 1;} }
