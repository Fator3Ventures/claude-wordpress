"""Leitura integral da documentação instalada do Core pelo transporte HTTP do Fator3 MCP real.
Uso: mcp-docs-1490.py <url-mcp> <auth.json> <dir-do-plugin-instalado> <saida.json>
auth.json: {"user":..., "password":...} de senha de aplicação descartável com conexão MCP de teste."""
import json,base64,urllib.request,sys,hashlib,os
url,authf,plugin,out=sys.argv[1:5]
a=json.load(open(authf));auth='Basic '+base64.b64encode(f"{a['user']}:{a['password']}".encode()).decode()
def call(body,sid=None):
    h={'Content-Type':'application/json','Accept':'application/json, text/event-stream','Authorization':auth}
    if sid:h['Mcp-Session-Id']=sid;h['MCP-Protocol-Version']='2025-06-18'
    req=urllib.request.Request(url,data=json.dumps(body).encode(),headers=h,method='POST')
    with urllib.request.urlopen(req,timeout=120) as r:return dict(r.headers),json.loads(r.read().decode())
n=[0]
def rpc(method,params,sid):
    n[0]+=1;h,b=call({'jsonrpc':'2.0','id':n[0],'method':method,'params':params},sid);assert 'error' not in b,b;return b['result']
h,b=call({'jsonrpc':'2.0','id':0,'method':'initialize','params':{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'core1490-docs','version':'1'}}})
sid=h['Mcp-Session-Id'];server=b['result']['serverInfo']
tools=[t['name'] for t in rpc('tools/list',{},sid)['tools']]
def ability(name,params):
    r=rpc('tools/call',{'name':'wp-mcp-ultimate-execute-ability','arguments':{'ability_name':name,'parameters':params}},sid)
    txt=r['content'][0]['text'];d=json.loads(txt)
    return d.get('data',d) if isinstance(d,dict) and 'data' in d and isinstance(d['data'],dict) and 'ok' in d['data'] else d
info=rpc('tools/call',{'name':'wp-mcp-ultimate-get-ability-info','arguments':{'ability_name':'f3base/documentacao-ler'}},sid)
idx=ability('f3base/documentacao-ler',{})
assert idx.get('ok') and idx['versao']=='1.49.0',idx
res={'servidor':server,'ferramentas':tools,'schema_lido':bool(info.get('content')),'versao':idx['versao'],'documentos':[],'paginas':0}
for f in idx['arquivos']:
    at=1;parts=[]
    while True:
        r=ability('f3base/documentacao-ler',{'arquivo':f,'linha':at,'limite':200});assert r.get('ok'),(f,r);parts.append(r['texto']);res['paginas']+=1
        if r['proxima_linha'] is None:break
        at=r['proxima_linha']
    raw=open(os.path.join(plugin,f),'rb').read()
    ok=r['sha256']==hashlib.sha256(raw).hexdigest() and '\n'.join(parts)=='\n'.join(raw.decode('utf-8').split('\n')[:len(raw.decode('utf-8').splitlines())])
    res['documentos'].append({'arquivo':f,'sha256':r['sha256'],'conferido':ok})
bad=ability('f3base/documentacao-ler',{'arquivo':'../../wp-config.php'})
res['traversal_recusado']=not bad.get('ok',False)
res['todos_conferidos']=all(d['conferido'] for d in res['documentos'])
json.dump(res,open(out,'w'),ensure_ascii=False,indent=1)
print(json.dumps({k:res[k] for k in ('servidor','versao','paginas','traversal_recusado','todos_conferidos')},ensure_ascii=False),len(res['documentos']),'documentos')
assert res['todos_conferidos'] and res['traversal_recusado']
