"""Descoberta e execução das duas abilities novas pelo transporte HTTP do Fator3 MCP real. Uso: <url> <auth.json> <saida.json>"""
import json,base64,urllib.request,sys
url,authf,out=sys.argv[1:4]
a=json.load(open(authf));auth='Basic '+base64.b64encode(f"{a['user']}:{a['password']}".encode()).decode()
def call(body,sid=None):
    h={'Content-Type':'application/json','Accept':'application/json, text/event-stream','Authorization':auth}
    if sid:h['Mcp-Session-Id']=sid;h['MCP-Protocol-Version']='2025-06-18'
    req=urllib.request.Request(url,data=json.dumps(body).encode(),headers=h,method='POST')
    with urllib.request.urlopen(req,timeout=60) as r:return dict(r.headers),json.loads(r.read().decode())
h,b=call({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'core1490-qa','version':'1'}}});sid=h['Mcp-Session-Id']
def tool(name,args,i):
    h,b=call({'jsonrpc':'2.0','id':i,'method':'tools/call','params':{'name':name,'arguments':args}},sid);return json.loads(b['result']['content'][0]['text'])
disc=tool('wp-mcp-ultimate-discover-abilities',{'prefix':'f3base/conversoes'},2)
found=[{k:x.get(k) for k in ('name','label','readonly','version','provider')} for x in disc.get('abilities',[])]
fila=tool('wp-mcp-ultimate-execute-ability',{'ability_name':'f3base/conversoes-fila-ler','parameters':{'dias':7}},3)
sim=tool('wp-mcp-ultimate-execute-ability',{'ability_name':'f3base/conversoes-bloqueadas-reavaliar','parameters':{'destino':'linkedin'}},4)
res={'servidor':b['result']['serverInfo'],'descobertas':found,'fila_ler':fila,'reavaliar_simulacao':sim}
json.dump(res,open(out,'w'),ensure_ascii=False,indent=1)
names={x['name'] for x in found}
assert {'f3base/conversoes-fila-ler','f3base/conversoes-bloqueadas-reavaliar'}<=names
assert fila['data']['ok'] and isinstance(fila['data']['destinos']['linkedin']['vencidas'],dict)
assert sim['data']['simulado'] is True and sim['data']['reagendadas']==0
print('mcp abilities OK', sorted(names))
