<?php
require __DIR__.'/bootstrap.php';
use Fator3\McpFiles\Persistence;
foreach(['f3base_ler_leads','f3base_gerir_leads'] as $cap)get_role('administrator')->add_cap($cap);wp_set_current_user(0);wp_set_current_user(1);
$app=WP_Application_Passwords::create_new_application_password(1,['name'=>'QA302 temporary']);$connection='app:'.$app[1]['uuid'];$id='';
try {
 Persistence::put('connections',$connection,['connection_id'=>$connection,'user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);do_action('application_password_did_authenticate',get_user_by('id',1),$app[1]);wp_get_abilities();
 $ability=wp_get_ability('f3base/contato-externo-registrar');check($ability->get_meta()['fator3']['decorated']??false,'new_route_mcp_decorated');
 $key='qa302-mcp-'.bin2hex(random_bytes(8));$e=['idempotency_key'=>$key.'-preview','metodo'=>'email','nome'=>'Synthetic Private302','email'=>'private302@example.invalid','primeiro_contato_em'=>gmdate('c',time()-30)];
 $preview=$ability->execute($e);check(!is_wp_error($preview)&&!empty($preview['ok'])&&!empty($preview['simular']),'mcp_default_simulation');
 $e['idempotency_key']=$key.'-save';$e['simular']=false;$save=$ability->execute($e);check(!is_wp_error($save)&&!empty($save['ok'])&&!empty($save['record_id']),'mcp_registration');$id=$save['record_id'];
 $replay=$ability->execute($e);check($replay['duplicado']&&$replay['record_id']===$id,'mcp_native_key_revalidated');
 foreach([$key.'-preview',$key.'-save'] as $receiptKey){$stored=Persistence::get('idempotency',$connection.':1:f3base/contato-externo-registrar:'.$receiptKey);check($stored&&!str_contains(wp_json_encode($stored),'Synthetic Private302')&&!str_contains(wp_json_encode($stored),'private302@example.invalid'),'mcp_receipt_no_personal_fields_'.$receiptKey);}
 check(F3Base_Leads_Repositorio::eliminar($id,'teste'),'mcp_contact_erased');$after=$ability->execute($e);if(($after['codigo']??'')!=='contato_externo_ja_eliminado')echo wp_json_encode($after);check(($after['codigo']??$after['error_code']??'')==='contato_externo_ja_eliminado'&&empty($after['ok']),'mcp_native_replay_after_erasure_denied');
}finally{if($id)F3Base_Leads_Repositorio::eliminar($id,'teste');WP_Application_Passwords::delete_application_password(1,$app[1]['uuid']);Persistence::delete('connections',$connection);}
evidence('mcp302-1540');
