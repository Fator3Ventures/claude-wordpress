<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$token='f3base_pipedrive_token';$old=[];foreach([$token,'f3base_pipedrive',F3Base_Credenciais::OPTION] as $n)$old[$n]=get_option($n);$calls=0;
$http=static function($pre,$args,$url)use(&$calls){$calls++;return ['response'=>['code'=>200],'body'=>wp_json_encode(['success'=>true,'data'=>['id'=>1,'company_id'=>2,'name'=>'QA','company_name'=>'Company']]),'headers'=>[]];};add_filter('pre_http_request',$http,99,3);
try {
 $value=str_repeat('1',40);raw($token,F3Base_Segredos::cifrar($token,$value));$cfg=F3Base_Options::ler('f3base_pipedrive');$cfg['dominio']='qa.pipedrive.com';raw('f3base_pipedrive',$cfg);raw(F3Base_Credenciais::OPTION,[]);$rev=F3Base_Options::revisao($token);
 $r=F3Base_Credenciais::previa(['nome'=>$token,'usar_salva'=>true,'revisao_esperada'=>$rev]);check($r['ok']&&$r['metadados_persistidos']&&$calls===1,'verify_saved_credential_read_only_provider');check(F3Base_Options::revisao($token)===$rev&&F3Base_Segredos::abrir($token)===$value,'verify_saved_never_rotates_token');
 check(F3Base_Credenciais::ler(['nome'=>$token])['credenciais'][0]['identidade']['empresa_id']==='2','legacy_saved_identity_available');
 if(!class_exists('Fator3\\McpFiles\\SafeOutput')){require_once dirname(__DIR__).'/companions/wp-mcp-fator3/includes/DataSafety.php';require_once dirname(__DIR__).'/companions/wp-mcp-fator3/includes/Release014.php';}
 $safe=\Fator3\McpFiles\SafeOutput::value(F3Base_Credenciais::ler(['nome'=>$token]));
 check($safe['credenciais'][0]['nome']===$token&&$safe['credenciais'][0]['identidade']['empresa_id']==='2','metadata_survives_actual_mcp_redaction');
 check(\Fator3\McpFiles\SafeOutput::value(['credential'=>$value])['credential']==='[redigido]','actual_mcp_redacts_candidate');
 $r=save($token,$value);check($r['persisted']&&F3Base_Options::revisao($token)===$rev&&$calls===1,'unchanged_token_does_not_recipher');
 $schema=wp_get_ability('f3base/credenciais-verificar')->get_input_schema();check(isset($schema['properties']['credential'])&&!isset($schema['properties']['valor']),'new_secret_input_redactable_by_channel');
 check(!str_contains(wp_json_encode(F3Base_Credenciais::ler()),$value),'identity_reader_no_secret');
 $changing=static function($pre,$args,$url)use($token){raw($token,F3Base_Segredos::cifrar($token,str_repeat('2',40)));return $pre;};add_filter('pre_http_request',$changing,100,3);$r=save($token,str_repeat('3',40));remove_filter('pre_http_request',$changing,100);check(!$r['persisted']&&F3Base_Segredos::abrir($token)===str_repeat('2',40),'concurrent_rotation_not_overwritten');
}finally{remove_filter('pre_http_request',$http,99);foreach($old as $n=>$v)raw($n,$v);}
evidence('request-293-extra');
