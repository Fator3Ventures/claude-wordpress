<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$names=array_merge(F3Base_Segredos::NOMES,[F3Base_Credenciais::OPTION]);$old=[];foreach($names as $n)$old[$n]=get_option($n);
$calls=0;$mode='accept';$seen=[];$http=static function($pre,$args,$url)use(&$calls,&$mode,&$seen){if(!str_contains($url,'/debug_token'))return new WP_Error('blocked');$calls++;$seen=['url'=>$url,'args'=>$args];return ['response'=>['code'=>$mode==='reject'?400:200],'headers'=>[],'body'=>wp_json_encode(['data'=>['is_valid'=>$mode!=='reject','app_id'=>'12345','user_id'=>'54321','type'=>'SYSTEM_USER','application'=>'QA 295','expires_at'=>0,'scopes'=>['ads_management','leads_retrieval','pages_show_list','pages_read_engagement','pages_manage_ads']]])];};add_filter('pre_http_request',$http,99,3);
function legacy295($n,$v){$nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);raw($n,F3Base_Segredos::PREFIXO.base64_encode($nonce.sodium_crypto_secretbox($v,$nonce,F3Base_Segredos::chave($n))));}
try{
 raw(F3Base_Credenciais::OPTION,[]);
 foreach(['f3base_anuncios_meta_token','f3base_meta_capi_token','f3base_meta_crm_token'] as $n){
  $v='legacy_295_'.$n;legacy295($n," \r\n".$v."\n ");$cipher=get_option($n);$rev=F3Base_Options::revisao($n);$before=$calls;
  check(F3Base_Segredos::abrir($n)===$v,'trim_read_'.$n);
  $r=F3Base_Credenciais::previa(['nome'=>$n,'usar_salva'=>true,'revisao_esperada'=>$rev]);
  check($r['ok']&&$r['metadados_persistidos']&&$calls===$before+1,'saved_short_non_EAA_verified_'.$n);
  check(get_option($n)===$cipher&&F3Base_Options::revisao($n)===$rev,'saved_cipher_untouched_'.$n);
  $rules=array_column($r['avisos'],'regra');check(!array_diff(['prefixo_EAA','minimo_100_legado','espacos_extremidades','quebra_linha_extremidade'],$rules),'exact_rules_'.$n);
  check(($r['identidade']['usuario_id']??'')==='54321'&&F3Base_Credenciais::ler(['nome'=>$n])['credenciais'][0]['identidade']===$r['identidade'],'identity_visible_'.$n);
  check(!str_contains(wp_json_encode($r),$v)&&!str_contains(wp_json_encode(F3Base_Credenciais::ler(['nome'=>$n])),$v),'no_secret_response_'.$n);
 }
 $n='f3base_anuncios_meta_token';raw($n,'');$r=save($n," \nEAAshort295\r\n ");check($r['persisted']&&F3Base_Segredos::abrir($n)==='EAAshort295'&&!empty($r['avisos']),'new_short_token_remote_accepted_and_trim_warning');
 $before=$calls;$r=F3Base_Credenciais::previa(['nome'=>$n,'usar_salva'=>true,'revisao_esperada'=>'stale']);check(!$r['ok']&&$calls===$before,'saved_stale_revision_no_http');
 legacy295($n,"EAA295\ninternal");$r=F3Base_Credenciais::previa(['nome'=>$n,'usar_salva'=>true,'revisao_esperada'=>F3Base_Options::revisao($n)]);check($r['ok']&&!isset($seen['args']['headers']['Authorization'])&&str_contains($seen['url'],'%0A'),'legacy_controls_not_in_header');check(in_array('quebra_linha_interna',array_column($r['avisos'],'regra'),true),'internal_newline_warning');
 $mode='reject';legacy295($n,'LegacyReject295');$before=get_option($n);$r=F3Base_Credenciais::previa(['nome'=>$n,'usar_salva'=>true,'revisao_esperada'=>F3Base_Options::revisao($n)]);check(!$r['ok']&&$r['codigo']==='credencial_recusada'&&isset($r['avisos'])&&get_option($n)===$before,'remote_refusal_with_warning_preserves');check(F3Base_Credenciais::ler(['nome'=>$n])['credenciais'][0]['identidade']===null,'old_identity_not_reused');
 $before=$calls;wp_set_current_user(0);$r=F3Base_Credenciais::previa(['nome'=>$n,'usar_salva'=>true,'revisao_esperada'=>F3Base_Options::revisao($n)]);check(!$r['ok']&&$calls===$before,'anonymous_no_saved_token_probe');wp_set_current_user(1);
}finally{remove_filter('pre_http_request',$http,99);foreach($old as $n=>$v){if($v===false){$wpdb->delete($wpdb->options,['option_name'=>$n]);wp_cache_delete($n,'options');}else raw($n,$v);}wp_cache_delete('alloptions','options');}
evidence('request-295');
