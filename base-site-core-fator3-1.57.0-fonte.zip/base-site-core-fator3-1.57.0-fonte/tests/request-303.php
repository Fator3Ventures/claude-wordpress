<?php
$_SERVER['REQUEST_METHOD']='GET';require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/user.php';
$old=get_option(F3Base_Sessao_Admin::OPTION);$legacy=get_option('f3base_sessao');raw('f3base_sessao',array_replace(F3Base_Options::ler('f3base_sessao'),['ligado'=>false]));$users=[];$seen=[];
add_filter('send_auth_cookies',static fn()=>false);
add_action('set_logged_in_cookie',function($cookie,$expire,$expiration,$uid,$scheme,$token)use(&$seen){$seen=compact('cookie','expire','expiration','uid','token');},10,6);
try{
 $admin=wp_insert_user(['user_login'=>'qa303_admin_'.bin2hex(random_bytes(4)),'user_pass'=>wp_generate_password(32),'role'=>'administrator']);$users[]=$admin;
 $other=wp_insert_user(['user_login'=>'qa303_sub_'.bin2hex(random_bytes(4)),'user_pass'=>wp_generate_password(32),'role'=>'subscriber']);$users[]=$other;
 raw(F3Base_Sessao_Admin::OPTION,365);$now=time();wp_set_auth_cookie($admin,true);$token=$seen['token'];$cookie=$seen['cookie'];$data=WP_Session_Tokens::get_instance($admin)->get($token);
 check(abs($seen['expiration']-$now-365*DAY_IN_SECONDS)<3,'remembered_admin_365_days');check($data['expiration']===$seen['expiration'],'native_token_same_expiration');check($seen['expire']===$seen['expiration']+12*HOUR_IN_SECONDS,'native_cookie_carrier_12h_grace_preserved');check(wp_validate_auth_cookie($cookie,'logged_in')===$admin,'native_cookie_valid');
 $v=save(F3Base_Sessao_Admin::OPTION,30);check($v['persisted']&&F3Base_Options::ler(F3Base_Sessao_Admin::OPTION)===30,'config_write_30');check(WP_Session_Tokens::get_instance($admin)->get($token)['expiration']===$data['expiration'],'setting_does_not_rewrite_existing_tokens');
 $now=time();wp_set_auth_cookie($admin,true);check(abs($seen['expiration']-$now-30*DAY_IN_SECONDS)<3,'remembered_admin_30_days');
 $now=time();wp_set_auth_cookie($admin,false);check($seen['expire']===0&&abs($seen['expiration']-$now-2*DAY_IN_SECONDS)<3,'admin_without_remember_session_cookie');
 $now=time();wp_set_auth_cookie($other,true);check(abs($seen['expiration']-$now-14*DAY_IN_SECONDS)<3,'subscriber_native_14_days');
 foreach([0,366,1.5,'bad'] as $bad){$v=save(F3Base_Sessao_Admin::OPTION,$bad);check(empty($v['persisted']),'reject_'.str_replace('.','_',strval($bad)));}
 raw('f3base_sessao',array_replace(F3Base_Options::ler('f3base_sessao'),['ligado'=>true,'modo'=>'legado','dias'=>90]));wp_set_auth_cookie($admin,true);check(abs($seen['expiration']-time()-30*DAY_IN_SECONDS)<3,'new_admin_policy_overrides_old_legacy');wp_set_auth_cookie($other,true);check(abs($seen['expiration']-time()-90*DAY_IN_SECONDS)<3,'existing_nonadmin_legacy_preference_preserved');
 check(F3Base_Sessao_Admin::expiracao(123,$other,true)===123&&F3Base_Sessao_Admin::expiracao(456,$admin,false)===456,'unaffected_users_keep_incoming_filter_value');
 wp_set_auth_cookie($admin,false);check($seen['expire']===0&&abs($seen['expiration']-time()-2*DAY_IN_SECONDS)<3,'legacy_does_not_force_admin_persistence');$post=$_POST;$method=$_SERVER['REQUEST_METHOD'];$_SERVER['REQUEST_METHOD']='POST';$_POST=['log'=>get_userdata($admin)->user_login];(new F3Base_Modulo_Sessao_De_Login())->lembrar();check(!isset($_POST['rememberme']),'native_admin_POST_respects_unchecked_remember');$_POST=$post;$_SERVER['REQUEST_METHOD']=$method;
 $entry=F3Base_Options::catalogo()[F3Base_Sessao_Admin::OPTION];check($entry['campo']==='inteiro'&&F3Base_Config_Contrato::schema_valor($entry)['maximum']===365,'typed_UI_and_contract_integer');$read=wp_get_ability('f3base/config-core-ler')->execute(['nome'=>F3Base_Sessao_Admin::OPTION]);check(!is_wp_error($read)&&$read['opcoes'][F3Base_Sessao_Admin::OPTION]['valor']===30,'public_config_read_admin_days');

 WP_Session_Tokens::get_instance($admin)->destroy($token);check(wp_validate_auth_cookie($cookie,'logged_in')===false,'logout_token_revocation');
 wp_set_auth_cookie($admin,true);$cookie=$seen['cookie'];wp_set_password(wp_generate_password(32),$admin);check(wp_validate_auth_cookie($cookie,'logged_in')===false,'password_change_revokes_cookie');
 wp_set_auth_cookie($admin,true);$cookie=$seen['cookie'];$salt=static fn($s)=>$s.'rotated303';add_filter('salt',$salt);check(wp_validate_auth_cookie($cookie,'logged_in')===false,'salt_rotation_revokes_cookie');remove_filter('salt',$salt);
 wp_set_current_user($other);check(wp_get_ability('f3base/config-core-escrever')->check_permissions([])!==true,'non_admin_config_denied');
}finally{wp_set_current_user(1);foreach($users as $id)wp_delete_user($id);if($old===false)delete_option(F3Base_Sessao_Admin::OPTION);else raw(F3Base_Sessao_Admin::OPTION,$old);if($legacy===false)delete_option('f3base_sessao');else raw('f3base_sessao',$legacy);}
evidence('request-303');
