<?php
/**
 * Convivência 1.49.0 com acompanhantes. Versões esperadas em F3BASE_COMPANION_VERSIONS (JSON
 * slug => versão); padrão: as cópias intactas de companions/ (MCP 0.28.0, Google 0.17.0,
 * LinkedIn 0.7.0, Meta 0.6.0). Executar em duas requisições: a primeira ativa; a segunda prova
 * com todos ativos. Também prova M1 com o gatilho real (LinkedIn ativo), M2 conforme a versão
 * do MCP (0.28.0 recusa a chamada nativa; 0.29.0+ deixa chegar ao fornecedor), M8 com o LinkedIn
 * ativo e M9 pelo consumidor real do Google (CoreContext), quando presente.
 */
require __DIR__ . '/bootstrap.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
global $wpdb;
add_filter( 'pre_http_request', static fn() => new WP_Error( 'qa_no_external_transport' ), 999 );
$versions = json_decode( (string) getenv( 'F3BASE_COMPANION_VERSIONS' ), true ) ?: array( 'wp-mcp-fator3' => '0.28.0', 'wp-mcp-google-fator3' => '0.17.0', 'wp-mcp-linkedin-fator3' => '0.7.0', 'wp-mcp-meta-fator3' => '0.6.0' );
$ativou   = false;
foreach ( $versions as $slug => $version ) {
	$p = $slug . '/' . $slug . '.php';
	if ( ! is_plugin_active( $p ) ) {
		$r      = activate_plugin( $p );
		$ativou = true;
		check( ! is_wp_error( $r ), 'coexist_activate_' . $slug );
	}
	check( is_plugin_active( $p ), 'coexist_active_' . $slug );
	check( get_plugin_data( WP_PLUGIN_DIR . '/' . $p )['Version'] === $version, 'coexist_version_' . $slug );
}
if ( $ativou ) {
	echo "Acompanhantes ativados; execute de novo em requisição nova.\n";
	exit( 0 );
}
$GLOBALS['checks']['acompanhantes'] = $versions;
check( F3BASE_PLUGIN_VERSAO === '1.52.1', 'core_version' );
check( F3Base_Config_Contrato::VERSAO === '8.17.0', 'admin_contract' );
foreach ( array( 'f3base/linkedin-conversao-previa', 'f3base/conversoes-fila-ler', 'f3base/conversoes-bloqueadas-reavaliar', 'linkedin/admin-options', 'ads/search' ) as $a ) {
	check( (bool) wp_get_ability( $a ), 'ability_' . $a );
}

/* M1 com LinkedIn ativo: processo novo, sonda de laboratório. */
$cmd = escapeshellarg( getenv( 'F3BASE_ROOT' ) . '/build/php' ) . ' ' . escapeshellarg( __DIR__ . '/probe-1490-run.php' );
$m1  = json_decode( (string) shell_exec( 'F3BASE_PROBE_1490=1 ' . $cmd . ' 2>/dev/null' ), true );
check( is_array( $m1 ) && true === $m1['linkedin_ativo'], 'm1_linkedin_ativo_no_processo' );
check( 0 === $m1['antecipadas_f3base'], 'm1_sem_aviso_f3base_com_linkedin' );
check( true === $m1['filtro_tardio'], 'm1_filtro_tardio_com_linkedin' );
$GLOBALS['checks']['m1_processo'] = $m1;

/* M2 e M8 com o canal e o LinkedIn reais. */
$mcp_versao   = get_plugin_data( WP_PLUGIN_DIR . '/wp-mcp-fator3/wp-mcp-fator3.php' )['Version'];
$mcp_recusa   = version_compare( $mcp_versao, '0.29.0', '<' );
$li_original  = $wpdb->get_var( $wpdb->prepare( 'SELECT option_value FROM %i WHERE option_name=%s', $wpdb->options, F3Base_Linkedin::OPCAO ) );
$exec_li      = 0;
$conta_exec   = static function ( $nome ) use ( &$exec_li ) {
	if ( 'linkedin/admin-options' === $nome ) {
		++$exec_li;
	}
};
add_action( 'wp_before_execute_ability', $conta_exec );
try {
	raw( F3Base_Linkedin::OPCAO, array( 'connection_id' => 'qa-conn-1490', 'conta_id' => '', 'cliente' => 'linkedin_plugin' ) );
	$m8 = F3Base_Linkedin_Cliente::catalogo( 'campanhas' );
	$exec_m8 = $exec_li;
	raw( F3Base_Linkedin::OPCAO, array( 'connection_id' => 'qa-conn-1490', 'conta_id' => '123456789', 'cliente' => 'linkedin_plugin' ) );
	$li = F3Base_Linkedin_Cliente::catalogo( 'campanhas' );
} finally {
	remove_action( 'wp_before_execute_ability', $conta_exec );
	if ( null === $li_original ) {
		delete_option( F3Base_Linkedin::OPCAO );
	} else {
		raw( F3Base_Linkedin::OPCAO, maybe_unserialize( $li_original ) );
	}
}
check( 'salve_a_conta' === $m8['codigo'] && 0 === $exec_m8, 'm8_conta_vazia_sem_chamar_linkedin' );
$GLOBALS['checks']['m8'] = $m8;
if ( $mcp_recusa ) {
	check( false === $li['ok'] && 'mcp_recusou_chamada_nativa' === $li['codigo'] && 'profile_denied' === $li['motivo'] && str_contains( $li['mensagem'], '0.29.0' ), 'm2_linkedin_catalogo_mcp_recusa' );
} else {
	// MCP 0.29.0+: linha de comando continua exigindo conexão MCP (a prova pela tela é HTTP, em mcp-http-1490.py).
	check( 'mcp_recusou_chamada_nativa' === $li['codigo'] && $mcp_versao === $li['mcp_versao'] && str_contains( $li['mensagem'], 'requisição administrativa web' ) && ! str_contains( $li['mensagem'], 'Atualize' ), 'm2_linkedin_cli_mensagem_0290' );
}
$GLOBALS['checks']['m2_linkedin'] = array( 'mcp' => $mcp_versao, 'resultado' => $li );
$ctx = hash( 'sha256', F3Base_Options::revisao( 'f3base_anuncios_google' ) . '|' . F3Base_Options::revisao( 'f3base_anuncios_google_chave' ) );
$go  = F3Base_Anuncios_Selecao::consultar( array( 'origem' => 'f3base_anuncios_google', 'tipo' => 'campanhas', 'contexto' => $ctx ) );
check( false === $go['ok'] && '' !== ( $go['mensagem'] ?? '' ), 'm2_google_ads_search_com_motivo' );
if ( $mcp_recusa ) {
	check( in_array( $go['codigo'], array( 'permissao_recusada_pela_integracao', 'mcp_recusou_chamada_nativa' ), true ), 'm2_google_mcp_recusa' );
} else {
	check( in_array( $go['codigo'], array( 'permissao_recusada_pela_integracao', 'mcp_recusou_chamada_nativa' ), true ) && ! str_contains( $go['mensagem'], '0.28.0 ou anterior' ), 'm2_google_cli_mensagem_0290' );
}
$GLOBALS['checks']['m2_google'] = array( 'mcp' => $mcp_versao, 'resultado' => $go );

/* M9 pelo consumidor real do Google, fora de escopo de leitura: cada chamada relê o Core. */
if ( class_exists( '\Fator3\McpGoogle\CoreContext' ) ) {
	$core = F3Base_Medicao_Contexto::snapshot();
	$q    = $wpdb->num_queries;
	$g1   = \Fator3\McpGoogle\CoreContext::snapshot();
	$cg   = $wpdb->num_queries - $q;
	check( ! empty( $g1['ok'] ), 'm9_google_valida_snapshot_com_schema_proprio' );
	$sem = static function ( array $d ): array {
		unset( $d['observed_at'] );
		return $d;
	};
	check( $sem( $g1['data'] ) === $sem( $core['data'] ), 'm9_google_recebe_snapshot_identico' );
	$original = F3Base_Options::ler( 'f3base_ga4_measurement_id' );
	save( 'f3base_ga4_measurement_id', 'G-QA1490XYZ' );
	$g2 = \Fator3\McpGoogle\CoreContext::snapshot();
	save( 'f3base_ga4_measurement_id', $original );
	$g3 = \Fator3\McpGoogle\CoreContext::snapshot();
	check( 'G-QA1490XYZ' === $g2['data']['slots']['ga4']['effective']['fields']['measurement_id'], 'm9_google_ve_alteracao_na_mesma_requisicao' );
	check( $g3['data']['slots']['ga4']['effective']['fields']['measurement_id'] === $g1['data']['slots']['ga4']['effective']['fields']['measurement_id'], 'm9_google_ve_restauracao' );
	$GLOBALS['checks']['m9_google'] = array( 'versao_google' => get_plugin_data( WP_PLUGIN_DIR . '/wp-mcp-google-fator3/wp-mcp-google-fator3.php' )['Version'], 'consultas_por_leitura_google' => $cg );
}
evidence( 'coexistence-1521' );
