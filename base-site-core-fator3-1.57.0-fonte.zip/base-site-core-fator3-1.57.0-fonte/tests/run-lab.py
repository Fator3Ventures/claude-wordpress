"""Run lab tests in order. Two modes:
- F3BASE_SHARED_MYSQL=1: use an already running disposable MySQL (F3BASE_DB_HOST/USER/PASSWORD).
- otherwise: start a private mysqld from F3BASE_RUNTIME on 127.0.0.1:33436 (original 1.48.0 lab).
Never point these variables at a real site database."""
from pathlib import Path
import os, subprocess, socket, time, sys
root=Path(__file__).resolve().parents[1]
lab=Path(os.environ.get('F3BASE_LAB_DIR',str(root/'lab')))
env=dict(os.environ,F3BASE_SITE=str(lab/'wordpress/wp-load.php'),F3BASE_ROOT=str(root),F3BASE_LAB_DIR=str(lab))
server=None
if os.environ.get('F3BASE_SHARED_MYSQL')!='1':
 runtime=Path(os.environ['F3BASE_RUNTIME'])
 env['LD_LIBRARY_PATH']=str(runtime/'usr/lib/x86_64-linux-gnu')
 data=Path(os.environ.get('F3BASE_MYSQL_DATA',str(lab/'mysql-data')));files=lab/'mysql-files';files.mkdir(exist_ok=True)
 base=[str(runtime/'usr/sbin/mysqld'),'--no-defaults','--user=root','--basedir='+str(runtime/'usr'),'--datadir='+str(data)]
 if not data.exists():
  data.mkdir();subprocess.run(base+['--initialize-insecure'],env=env,check=True,capture_output=True)
 log=open(lab/'mysql-run.log','a')
 server=subprocess.Popen(base+['--port=33436','--bind-address=127.0.0.1','--socket=','--mysqlx=0','--pid-file='+str(lab/'mysql.pid'),'--secure-file-priv='+str(files)],env=env,stdout=log,stderr=log)
 env.setdefault('F3BASE_DB_HOST','127.0.0.1:33436')
host,_,port=env.get('F3BASE_DB_HOST','127.0.0.1:33436').partition(':')
try:
 for i in range(100):
  if server is not None and server.poll() is not None:raise RuntimeError('MySQL failed; see log')
  try:
   with socket.create_connection((host,int(port or 3306)),.2):break
  except OSError:time.sleep(.1)
 else:raise RuntimeError('MySQL startup timeout')
 for test in sys.argv[1:]:
  command=([sys.executable] if test.endswith('.py') else [str(root/'build/php')])+[str(root/test)]
  result=subprocess.run(command,env=env);print('TEST',test,'EXIT',result.returncode,flush=True)
  if result.returncode:sys.exit(result.returncode)
finally:
 if server is not None:
  server.terminate()
  try:server.wait(timeout=15)
  except subprocess.TimeoutExpired:server.kill()
