"""Run tests/release-1490.php in collect mode against the 1.48.0 base installer (separate disposable DB).
Proves which 1.49.0 cases fail on the base. Restores the lab plugin link afterwards.
Env: F3BASE_BASE_ZIP (1.48.0 installer, sha256 fixed below); same DB variables as run-lab.py."""
from pathlib import Path
import os,subprocess,zipfile,hashlib,shutil,json,sys
root=Path(__file__).resolve().parents[1]
base=Path(os.environ['F3BASE_BASE_ZIP'])
assert hashlib.sha256(base.read_bytes()).hexdigest()=='91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de'
lab=Path(os.environ.get('F3BASE_LAB_DIR',str(root/'lab')));tmp=lab/'base-1480';shutil.rmtree(tmp,ignore_errors=True);tmp.mkdir(parents=True)
zipfile.ZipFile(base).extractall(tmp)
link=lab/'wordpress/wp-content/plugins/base-site-core-fator3'
alvo=os.readlink(link) if link.is_symlink() else None
assert alvo,'lab plugin must be a symlink to work/plugin'
env=dict(os.environ,F3BASE_LAB_DB=os.environ.get('F3BASE_LAB_DB','core_lab')+'_base',F3BASE_COLETAR='1',F3BASE_EVIDENCIA_NOME='release-1490-contra-base-1480')
try:
 link.unlink();link.symlink_to(tmp/'base-site-core-fator3')
 r=subprocess.run([sys.executable,str(root/'tests/run-lab.py'),'tests/install.php','tests/release-1490.php'],env=env,cwd=root)
 if r.returncode:sys.exit(r.returncode)
finally:
 link.unlink();link.symlink_to(alvo);shutil.rmtree(tmp,ignore_errors=True)
