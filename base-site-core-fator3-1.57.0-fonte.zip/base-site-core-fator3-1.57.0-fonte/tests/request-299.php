<?php
require __DIR__.'/bootstrap.php';
$names=['f3base_c0','f3base_email_novo_lead'];$old=[];foreach($names as $n)$old[$n]=get_option($n);
try{
 $new=F3Base_Options::ler('f3base_email_novo_lead');$new['ativo']=true;$new['marca']='Marca Sintética 299';$new['homologacao_emails']=['qa@example.test'];$new['textos_servicos']=['89'=>'Texto 89','90'=>'Texto 90'];raw('f3base_email_novo_lead',$new);
 $legacy=['ativo'=>false,'textos_servicos'=>['90'=>'Texto 90','89'=>'Texto 89'],'homologacao_emails'=>['qa@example.test'],'marca'=>'Marca Sintética 299'];raw('f3base_c0',$legacy);
 $r=F3Base_Email_Limpeza::executar();check(!empty($r['ok']),'same_content_order_and_activation_differ');check(get_option('f3base_c0')===$legacy,'simulation_does_not_delete');
 $legacy['textos_servicos']['89']='Private divergent text';raw('f3base_c0',$legacy);$r=F3Base_Email_Limpeza::executar();check(empty($r['ok']),'real_difference_blocks');$item=array_values(array_filter($r['itens'],fn($v)=>$v['option']==='f3base_c0'))[0];check($item['campos_divergentes']===['textos_servicos.89'],'difference_field_only');check(!str_contains(wp_json_encode($r),'Private divergent text')&&!str_contains(wp_json_encode($r),'Marca Sintética'),'no_values_in_report');
}finally{foreach($old as $n=>$v){if($v===false)delete_option($n);else raw($n,$v);}}
evidence('request-299');
