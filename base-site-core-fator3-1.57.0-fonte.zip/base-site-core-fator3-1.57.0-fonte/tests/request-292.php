<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$option=F3Base_Operacao::OPTION;$before=F3Base_Options::ler($option);$tag='qa150-'.bin2hex(random_bytes(5));$runs=[];
$method=new ReflectionMethod(F3Base_Operacao::class,'confirmar_resultado');$method->setAccessible(true);
try {
 raw($option,['llms'=>['teste'=>1]]);
 $r=F3Base_Options::atualizar_estado($option,fn($v)=>$v);
 check($r['persisted']&&$r['persistencia']['linhas_afetadas']===0&&$r['persistencia']['etapa']==='valor_ja_persistido','same_value_update_zero_confirmed');
 $r=F3Base_Options::atualizar_estado($option,static function($v){$v['llms']['teste']=2;return $v;});
 check($r['persisted']&&$r['persistencia']['linhas_afetadas']===1,'actual_update_measured');
 $e=['id'=>'llms','hook'=>'f3base_llms_regenerar','args'=>[],'timestamp'=>time()-10];$task=$tag.'one';
 $result=['ok'=>true,'codigo'=>'lote_concluido','status'=>'concluido','resultado_modulo_confirmado'=>true];
 raw($option,['llms'=>['ultima'=>['run_id'=>$task,'fim'=>time(),'codigo'=>'lote_concluido'],'lease'=>[]]]);
 $saved=$method->invoke(null,$e,$task,$result,['persisted'=>false,'codigo'=>'escrita_sem_confirmacao','persistencia'=>['linhas_afetadas'=>1]]);
 check($saved['ok']&&$saved['confirmado_localmente']&&$saved['codigo']==='checkpoint_confirmado_releitura','other_task_write_does_not_erase_own_success');
 raw($option,['llms'=>['ultima'=>['run_id'=>'other'],'lease'=>[]]]);
 $missing=$method->invoke(null,$e,$task,$result,['persisted'=>true]);
 check(!$missing['ok']&&$missing['codigo']==='checkpoint_nao_persistido'&&$missing['persistencia']['causa']==='lease_divergente_sem_conclusao','unchanged_transform_without_lease_not_success');
 $insert=static function($id,$success,$code,$data,$when)use(&$runs,$wpdb,$tag){$runs[]=$id;$wpdb->insert(F3Base_Execucoes::tabela(),['run_id'=>$id,'parent_run_id'=>$tag.'parent','origem'=>'http_cron','entrada'=>'qa150','tarefa'=>'llms','hook'=>'f3base_llms_regenerar','inicio'=>$when,'fim'=>$when,'sucesso'=>$success,'codigo'=>$code,'dados'=>wp_json_encode($data)]);};
 $old=['ok'=>false,'codigo'=>'checkpoint_nao_persistido','quando'=>$e['timestamp'],'argumentos_sha256'=>hash('sha256',serialize([])),'persistencia'=>['causa'=>'resultado_ausente']];
 $insert($tag.'failed',0,'checkpoint_nao_persistido',$old,time()-9);
 $insert($tag.'different',0,'checkpoint_nao_persistido',array_merge($old,['argumentos_sha256'=>hash('sha256','other')]),time()-9);
 $insert($tag.'legacy',0,'checkpoint_nao_persistido',['resultado_anterior'=>['codigo'=>'checkpoint_nao_persistido']],time()-9);
 $insert($tag.'later',null,'executando',[],time());
 $good=$result+['quando'=>time(),'argumentos_sha256'=>$old['argumentos_sha256']];F3Base_Execucoes::concluir_tarefa($tag.'later',$good);
 $rows=$wpdb->get_results($wpdb->prepare('SELECT run_id,sucesso,codigo,dados FROM %i WHERE parent_run_id=%s',F3Base_Execucoes::tabela(),$tag.'parent'),OBJECT_K);
 check($rows[$tag.'failed']->sucesso===null&&$rows[$tag.'failed']->codigo==='checkpoint_superado','later_completion_reclassifies_failure');
 check(json_decode($rows[$tag.'failed']->dados,true)['reconciliacao']['run_id']===$tag.'later','later_completion_reference_preserved');
 check($rows[$tag.'different']->codigo==='checkpoint_nao_persistido','different_arguments_do_not_hide_failure');
 check($rows[$tag.'legacy']->codigo==='checkpoint_nao_persistido','unprovable_legacy_not_forged');
 $r=$method->invoke(null,$e,$task,$result,['persisted'=>false]);check($r['ok']&&$r['codigo']==='checkpoint_superado'&&$r['resultado']==='neutro','completed_next_occurrence_neutral');
 check(isset(F3Base_Execucoes::resumo()['checkpoints']['por_dia_origem']),'health_separates_checkpoints_by_day_origin');
 $filter=static fn($v)=>['llms'=>['rejected'=>true]];add_filter('pre_update_option_'.$option,$filter);
 $r=F3Base_Options::atualizar_estado($option,fn($v)=>['llms'=>['teste'=>42]],1);remove_filter('pre_update_option_'.$option,$filter);
 check(!$r['persisted']&&$r['persistencia']['etapa']==='filtro_alterou_valor'&&$r['persistencia']['linhas_afetadas']===null,'filtered_write_measured_no_sql');
}finally{raw($option,$before);foreach($runs as $run)$wpdb->delete(F3Base_Execucoes::tabela(),['run_id'=>$run]);}
evidence('request-292');
