<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
$which=getenv('F3BASE_COMPANION')?:'meta';$slug=$which==='mcp'?'wp-mcp-fator3':'wp-mcp-meta-fator3';$r=activate_plugin($slug.'/'.$slug.'.php');check(!is_wp_error($r),'companion_activated');echo $slug." active; validate in the next process.\n";
