<?php
/** Temporary QA fixture; not distributed in the installer. */
if(!defined('ABSPATH'))exit;
function qa1491_check($ok,$name){$GLOBALS['qa1491_checks'][$name]=(bool)$ok;if(!$ok)throw new RuntimeException($name);}
function qa1491_raw($name,$value){$GLOBALS['qa1491_overrides'][$name]=$value;}
function qa1491_option($pre,$name){return array_key_exists($name,$GLOBALS['qa1491_overrides']??[])?$GLOBALS['qa1491_overrides'][$name]:$pre;}
function qa1491_run(){
 if(parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||!current_user_can('manage_options')||!defined('F3BASE_PLUGIN_VERSAO')||F3BASE_PLUGIN_VERSAO!=='1.49.1')return ['ok'=>false,'codigo'=>'ambiente_incorreto'];
 global $wpdb;$GLOBALS['qa1491_checks']=[];$GLOBALS['qa1491_overrides']=[];
 add_filter('pre_option','qa1491_option',PHP_INT_MAX,2);$mail=static fn()=>true;add_filter('pre_wp_mail',$mail,PHP_INT_MAX);
 try {
$warnings=array();$notice=static function($f,$m)use(&$warnings){if($f==='rest_validate_value_from_schema'){$warnings[]=$m;}};add_action('doing_it_wrong_run',$notice,10,2);
foreach(array('f3base_contato','f3base_consentimento') as $key){$d=F3Base_Options::declaracao($key);$s=F3Base_Config_Contrato::schema_entrada($d);qa1491_check(($s['type']??'')==='object','schema_root_'.$key);qa1491_check(F3Base_Config_Mescla::erros_schema($d['padrao'],$s)===array(),'schema_defaults_'.$key);qa1491_check(F3Base_Config_Mescla::erros_schema('invalid',$s)!==array(),'schema_invalid_root_'.$key);$field=$key==='f3base_contato'?'texto_confirmacao_titulo':'texto_titulo';$field=array_key_first(array_filter($s['properties'],static fn($v,$k)=>str_starts_with($k,'texto_'),ARRAY_FILTER_USE_BOTH));qa1491_check(F3Base_Config_Mescla::preparar($d,$d['padrao'],array($field=>'QA'))['ok'],'schema_partial_'.$key);qa1491_check(!F3Base_Config_Mescla::preparar($d,$d['padrao'],array($field=>array('invalid')))['ok'],'schema_partial_invalid_'.$key);}
qa1491_check(!$warnings,'schema_no_notices');remove_action('doing_it_wrong_run',$notice);
$originals=array();foreach(array('f3base_campanhas_nomes','f3base_anuncios_meta','f3base_pipedrive_estado') as $k){$originals[$k]=get_option($k,null);}
$records=array();$http=0;$block=static function()use(&$http){$http++;return new WP_Error('qa1491_no_external');};add_filter('pre_http_request',$block,PHP_INT_MAX);
try{
 qa1491_raw('f3base_campanhas_nomes',array(array('plataforma'=>'meta_ads','conta'=>'123','campanha'=>'456','nome'=>'Campanha QA resolvida')));
 $meta=F3Base_Options::ler('f3base_anuncios_meta');$meta['conta_id']='123';$meta['mapeamento']=array('campanhas'=>array('789'=>'Campanha da origem'),'anuncios'=>array('999'=>'Anúncio da origem'));qa1491_raw('f3base_anuncios_meta',$meta);
 $base=array('utm_source'=>'facebook','utm_medium'=>'paid_social','utm_campaign'=>'456','utm_content'=>'999','f3_ads_account_id'=>'123');
 $a=F3Base_Atribuicao::normalizar($base);qa1491_check($a['utm_campaign']==='Campanha QA resolvida'&&$a['nome_campanha_origem']==='Campanha QA resolvida'&&$a['nome_campanha_fonte']==='mapa_do_site','291_site_map_name_source');qa1491_check($a['utm_campaign_original']==='456'&&$a['campanha_id']==='456','291_original_id_preserved');qa1491_check($a['nome_anuncio_origem']==='Anúncio da origem'&&$a['nome_anuncio_fonte']==='mapa_da_origem','291_ad_name_source');
 $b=F3Base_Atribuicao::normalizar(array_replace($base,array('utm_campaign'=>'789','f3_ads_account_id'=>'')));qa1491_check($b['nome_campanha_origem']==='Campanha da origem'&&$b['nome_campanha_fonte']==='mapa_da_origem'&&$b['conta_origem']===''&&$b['conta_fonte']==='mapa_da_origem'&&$b['conta_id']==='123','291_origin_map_account_source');
 $foreign=F3Base_Atribuicao::normalizar(array_replace($base,array('f3_ads_account_id'=>'other')));qa1491_check($foreign['nome_campanha_origem']===''&&F3Base_Atribuicao::nome_campanha($foreign)==='','291_no_cross_account_name');
 $given=F3Base_Atribuicao::normalizar(array_replace($base,array('utm_campaign'=>'Nome do link','utm_id'=>'456')));qa1491_check($given['utm_campaign']==='Nome do link'&&$given['nome_campanha_origem']==='Nome do link','291_link_name_preserved');
 $legacy=array_replace($a,array('nome_campanha_origem'=>'mapa_do_site','nome_anuncio_origem'=>'mapa_da_origem','conta_origem'=>'mapa_da_origem'));unset($legacy['nome_campanha_fonte'],$legacy['nome_anuncio_fonte'],$legacy['conta_fonte']);$copy=$legacy;$fixed=F3Base_Atribuicao::nomes($legacy);qa1491_check($copy===$legacy&&$fixed['nome_campanha_fonte']==='mapa_do_site'&&$fixed['nome_campanha_origem']==='Campanha QA resolvida','291_legacy_read_only');
 $again=F3Base_Atribuicao::normalizar($a);$keys=array_flip(array('utm_campaign','utm_campaign_original','campanha_id','anuncio_id','conta_id','nome_campanha_origem','nome_anuncio_origem','conta_origem','nome_campanha_fonte','nome_anuncio_fonte','conta_fonte'));qa1491_check(array_intersect_key($again,$keys)==array_intersect_key($a,$keys),'291_names_and_ids_idempotent');qa1491_check(F3Base_Atribuicao::validar($a),'291_attribution_validator');
 $nested=F3Base_Atribuicao::nomes(array('primeiro_toque'=>$legacy));qa1491_check($nested['primeiro_toque']['nome_anuncio_fonte']==='mapa_da_origem','291_nested_legacy');
 $privacy=F3Base_Contato_Apresentacao::atribuicao($legacy,false);qa1491_check(!isset($privacy['nome_anuncio_origem'],$privacy['conta_origem'],$privacy['nome_anuncio_fonte'],$privacy['conta_fonte']),'291_privacy_reduction');
 $cfg=F3Base_Options::ler('f3base_pipedrive');$cfg['mapa_campos']=array('campanha'=>'qa_campaign');qa1491_raw('f3base_pipedrive_estado',array('catalogos'=>array('campos'=>array(array('field_code'=>'qa_campaign','field_type'=>'varchar')))));
 foreach(array('named'=>$legacy,'unnamed'=>array_replace($base,array('utm_campaign'=>'555','nome_campanha_origem'=>'mapa_da_origem','nome_anuncio_origem'=>'mapa_da_origem','f3_ads_ad_name'=>'','utm_content'=>''))) as $case=>$attr){
  $id=bin2hex(random_bytes(16));$records[]=$id;$d=array('atribuicao'=>$attr,'consentimento_snapshot'=>array('medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:qa'),'teste_origem'=>'qa1491');
  qa1491_check($wpdb->insert(F3Base_Leads_Repositorio::tabela(),array('record_id'=>$id,'metodo'=>'formulario','formulario'=>'qa1491','captura'=>'aceito','classe_trafego'=>'teste','nome'=>'Pessoa QA','email'=>'qa1491@example.test','criado_em'=>gmdate('Y-m-d H:i:s',time()-30),'atualizado_em'=>gmdate('Y-m-d H:i:s'),'pagina'=>'/qa1491','dados'=>wp_json_encode($d),'anexos'=>'[]','payload_hash'=>hash('sha256',$id)))===1,'291_insert_'.$case);
  $lead=F3Base_Leads_Repositorio::obter($id);$before=$lead['dados'];$ctx=F3Base_Contato_Apresentacao::montar($lead,false);$note=strip_tags(F3Base_Contato_Apresentacao::nota($ctx,'qa'));$text=F3Base_Contato_Apresentacao::texto($ctx);$fields=F3Base_Pipedrive_Fila::campos($ctx,$cfg);
  qa1491_check(!preg_match('/(?:Campanha(?: de origem)?|Anúncio|Nome da campanha|Nome do anúncio):\s*mapa_/u',$note.' '.$text),'291_no_source_as_name_'.$case);
  $slack=wp_json_encode(F3Base_Slack::mensagens($ctx,'completo'),JSON_UNESCAPED_UNICODE);qa1491_check(!preg_match('/Nome da campanha: mapa_|Nome do anúncio: mapa_|Nome da conta: mapa_/u',$slack),'291_slack_sources_labeled_'.$case);qa1491_check($case!=='named'||str_contains($slack,'Campanha QA resolvida'),'291_slack_name_'.$case);
  qa1491_check($case==='named'?str_contains($note,'Campanha QA resolvida')&&($fields['qa_campaign']??'')==='Campanha QA resolvida':!isset($fields['qa_campaign'])&&!str_contains($note,'Campanha:'),'291_note_and_crm_'.$case);
  $read=F3Base_Leads_Admin::ler(array('record_id'=>$id));qa1491_check($read['registro']['dados']['atribuicao']['nome_campanha_fonte']===($case==='named'?'mapa_do_site':'mapa_da_origem'),'291_private_reader_source_'.$case);
  qa1491_check(F3Base_Leads_Repositorio::obter($id)['dados']===$before,'291_stored_data_unchanged_'.$case);
  // Emulate a frozen pre-patch summary; only the output attribution may change.
  $ctx['atribuicao']=$attr;$ctx['comunicacao']=array('recebimento_ate'=>time()-20,'hash'=>'original');$ctx['secoes_comunicacao']=array('Origem'=>array('Atribuição'=>array('Nome Campanha Origem: mapa_da_origem')),'Comportamento'=>array('Prova'=>array('histórico congelado')));
  $lead['dados']['comunicacao_envio']=array('cifrado'=>F3Base_Contato_Comunicacao::cifrar($ctx));$cipher=$lead['dados']['comunicacao_envio']['cifrado'];$prepared=F3Base_Contato_Comunicacao::preparar($lead,false);
  qa1491_check($prepared['ok']&&($prepared['apresentacao']['atribuicao']['nome_campanha_fonte']??'')===($case==='named'?'mapa_do_site':'mapa_da_origem'),'291_frozen_projection_'.$case);qa1491_check($prepared['apresentacao']['secoes_comunicacao']['Comportamento']===$ctx['secoes_comunicacao']['Comportamento']&&$lead['dados']['comunicacao_envio']['cifrado']===$cipher,'291_frozen_behavior_preserved_'.$case);
 }
 qa1491_check(F3Base_Relatorios::rotulo('nome_campanha_fonte')==='Fonte do nome da campanha','291_report_source_label');
 qa1491_check($http===0,'291_no_network');
}finally{foreach($records as $id){$wpdb->delete(F3Base_Leads_Repositorio::tabela(),array('record_id'=>$id));}foreach($originals as $k=>$v){if($v===null){delete_option($k);}else{qa1491_raw($k,$v);}}remove_filter('pre_http_request',$block,PHP_INT_MAX);}

 return ['ok'=>true,'versao'=>F3BASE_PLUGIN_VERSAO,'checks'=>$GLOBALS['qa1491_checks'],'rede_real'=>false,'configuracao_persistente_alterada'=>false];
 }catch(Throwable $e){return ['ok'=>false,'codigo'=>'teste_falhou','causa'=>$e->getMessage(),'checks'=>$GLOBALS['qa1491_checks']];}
 finally{remove_filter('pre_option','qa1491_option',PHP_INT_MAX);remove_filter('pre_wp_mail',$mail,PHP_INT_MAX);unset($GLOBALS['qa1491_overrides']);}
}
add_action('wp_abilities_api_init',static function(){
 // Package probes may load this file before WordPress abilities are available.
 if(!function_exists('wp_register_ability')||!class_exists('F3Base_Atribuicao'))return;
 wp_register_ability('f3base-qa/revisao-1491',['label'=>'Core: homologação sintética 1.49.1','description'=>'Somente Site-Teste, leitura e resumo de registros sintéticos sem fornecedor.','category'=>'f3base','input_schema'=>['type'=>'object','additionalProperties'=>false,'properties'=>[]],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'qa1491_run','meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false]]]);
},40);
