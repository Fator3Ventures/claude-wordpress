"""Catálogo LinkedIn pela tela real (admin-ajax com nonce), em laboratório HTTP.
Uso: admin-ajax-catalogo-1490.py <base-url> <cookie-jar> <esperado> <saida.json>
esperado: chega_ao_linkedin | mcp_recusa | salve_a_conta. O login (cookie) é feito antes, por quem chama."""
import sys,re,json,subprocess,html
base,jar,esperado,out=sys.argv[1:5]
def curl(args):return subprocess.run(['curl','-s','-b',jar,'-c',jar]+args,capture_output=True,text=True).stdout
page=curl([base+'/wp-admin/admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_anuncios_linkedin'])
m=re.search(r'<div class="f3base-catalog-picker"([^>]*data-source="f3base_anuncios_linkedin"[^>]*)>',page)
assert m,'picker LinkedIn ausente na tela'
attrs={k:html.unescape(v) for k,v in re.findall(r'data-([a-z]+)="([^"]*)"',m.group(1))}
res={'esperado':esperado,'tela':'conexoes/f3base_anuncios_linkedin'}
for tipo in ('campanhas','formularios'):
    r=curl(['-X','POST',base+'/wp-admin/admin-ajax.php','--data-urlencode','action=f3base_anuncios_catalogo','--data-urlencode','_ajax_nonce='+attrs['nonce'],'--data-urlencode','origem=f3base_anuncios_linkedin','--data-urlencode','tipo='+tipo,'--data-urlencode','contexto='+attrs['context'],'--data-urlencode','integracao_id='+attrs['integration'],'--data-urlencode','cursor='])
    d=json.loads(r);res[tipo]=d
    assert d.get('ok') is False,d
    if esperado=='chega_ao_linkedin':assert d['codigo']!='mcp_recusou_chamada_nativa' and d.get('motivo') not in ('profile_denied','connection_context_required','permission_denied'),d
    elif esperado=='mcp_recusa':assert d['codigo']=='mcp_recusou_chamada_nativa' and 'Atualize' in d['mensagem'],d
    elif esperado=='salve_a_conta':assert d['codigo']=='salve_a_conta' and 'motivo' not in d,d
json.dump(res,open(out,'w'),ensure_ascii=False,indent=1)
print('admin-ajax', esperado, {t:(res[t]['codigo'],res[t].get('motivo')) for t in ('campanhas','formularios')})
