<?php
$root=getenv('F3BASE_ROOT');$mu=getenv('F3BASE_LAB_DIR').'/wordpress/wp-content/mu-plugins/qa151-recovery.php';if(!getenv('F3BASE_QA_RECOVERY_CHILD'))file_put_contents($mu,'<?php require '.var_export($root.'/companions/wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php',true).';');
require __DIR__.'/bootstrap.php';if(getenv('F3BASE_QA_RECOVERY_CHILD')){try{\Fator3\Pipedrive\CoreClient::status();exit(2);}catch(\Fator3\Pipedrive\Fault $e){echo $e->reason;exit($e->reason==='core_em_recuperacao'?0:3);}}$calls=0;add_filter('pre_http_request',static function()use(&$calls){$calls++;return new WP_Error('blocked');},999);
$before=F3Base_Recuperacao::ler();$r=F3Base_Recuperacao::operar(['acao'=>'preparar','geracao_esperada'=>$before['geracao']]);check($r['ok']&&$r['codigo']==='core_drenado','recovery_prepared');
try{
 check(\Fator3\Pipedrive\CoreClient::registration()==='registrado','original_client_registered');
 try{\Fator3\Pipedrive\CoreClient::status();check(false,'recovery_code');}catch(\Fator3\Pipedrive\Fault $e){check($e->reason==='core_em_recuperacao'&&$calls===0,'recovery_refused_without_http');}
 $pipes=[];$proc=proc_open([PHP_BINARY,'-c',getenv('F3BASE_LAB_DIR').'/php.ini',__FILE__],[1=>['pipe','w'],2=>['pipe','w']],$pipes,null,array_merge(getenv(),['F3BASE_QA_RECOVERY_CHILD'=>'1']));$stdout=stream_get_contents($pipes[1]);$stderr=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($proc);check($exit===0&&$stdout==='core_em_recuperacao','new_process_registration_survives_paused_bootstrap');
 $s=F3Base_Recuperacao::ler();$r=F3Base_Recuperacao::operar(['acao'=>'retomar','geracao_esperada'=>$s['geracao'],'reconciliacao_confirmada'=>true]);check($r['ok']&&!F3Base_Recuperacao::ler()['pausado'],'recovery_resumed');check(F3Base_Recuperacao::ler()['geracao']>$before['geracao'],'generation_advanced');
}finally{if(F3Base_Recuperacao::ler()['pausado'])F3Base_Recuperacao::operar(['acao'=>'retomar','geracao_esperada'=>F3Base_Recuperacao::ler()['geracao'],'reconciliacao_confirmada'=>true]);if(file_exists($mu))unlink($mu);}
evidence('request-294-recovery');
