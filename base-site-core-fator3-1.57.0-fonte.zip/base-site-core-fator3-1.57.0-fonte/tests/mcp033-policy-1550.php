<?php
require __DIR__.'/bootstrap.php';
if(!class_exists('Fator3\\McpFiles\\DataSafety'))require_once WP_PLUGIN_DIR.'/wp-mcp-fator3/includes/DataSafety.php';
if(!class_exists('Fator3\\McpFiles\\SafeOutput'))require_once WP_PLUGIN_DIR.'/wp-mcp-fator3/includes/Release014.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';check(get_plugin_data(WP_PLUGIN_DIR.'/wp-mcp-fator3/wp-mcp-fator3.php')['Version']==='0.33.0','original_MCP033');
$before=F3Base_Formulario_Antispam::resumo();$safe=\Fator3\McpFiles\SafeOutput::error(['avisos'=>['sinais_formularios'=>$before]])['avisos']['sinais_formularios'];
check($safe['linhas']===$before['linhas'],'policy_rows_survive_mcp033_redaction');
check($safe['regras']['token_vencido']===$before['regras']['token_vencido'],'typed_token_policy_preserved');
$counts=['passagens'=>3,'passagens_24h'=>6,'contagem_passagens'=>7,'checks_passed'=>true,'all_checks_passed'=>true];
check(\Fator3\McpFiles\SafeOutput::error($counts)===$counts,'prior_mcp_impact_counters_fixed');
$secret=\Fator3\McpFiles\SafeOutput::error(['f3base_email_site_senha'=>'synthetic-only']);check($secret['f3base_email_site_senha']==='[redigido]','new_password_redacted');
evidence('mcp033-policy-1550');
