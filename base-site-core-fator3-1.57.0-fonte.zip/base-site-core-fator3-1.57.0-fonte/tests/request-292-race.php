<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$option=F3Base_Operacao::OPTION;$old=F3Base_Options::ler($option);$task=wp_generate_uuid4();$when=time()-3;
$own=['run_id'=>$task,'fim'=>time(),'codigo'=>'lote_concluido'];$ran=false;
$write=static function($name,$before,$after)use($option,&$ran){if($name!==$option||$ran)return;$ran=true;$f=F3Base_Options::fotografia($name);$v=$f['valor'];$v['cache']=['ultima'=>['run_id'=>'other-task','fim'=>time()]];raw($name,$v);};
try {
 raw($option,['llms'=>['lease'=>['token'=>$task]]]);add_action('updated_option',$write,PHP_INT_MAX,3);
 $save=F3Base_Options::atualizar_estado($option,static function($v)use($own){$v['llms']['ultima']=$own;$v['llms']['lease']=[];return $v;});remove_action('updated_option',$write,PHP_INT_MAX);
 check($ran&&!$save['persisted']&&$save['codigo']==='escrita_sem_confirmacao','real_sql_shared_option_race_reproduced');
 check($save['persistencia']['linhas_afetadas']===1&&$save['persistencia']['revisao_esperada']!==$save['persistencia']['revisao_lida'],'race_write_and_revisions_measured');
 $confirm=new ReflectionMethod(F3Base_Operacao::class,'confirmar_resultado');$confirm->setAccessible(true);
 $r=$confirm->invoke(null,['id'=>'llms','hook'=>'f3base_llms_regenerar','args'=>[],'timestamp'=>$when],$task,['ok'=>true,'codigo'=>'lote_concluido','status'=>'concluido','resultado_modulo_confirmado'=>true],$save);
 check($r['ok']&&$r['codigo']==='checkpoint_confirmado_releitura','shared_option_race_not_task_failure');
 $bad=static fn($q)=>str_starts_with($q,'UPDATE '.$wpdb->options.' SET option_value=')&&str_contains($q,"option_name='f3base_operacao_estado'")?str_replace('SET option_value=','SET nonexistent_qa_column=',$q):$q;
 $suppressed=$wpdb->suppress_errors(true);add_filter('query',$bad);
 $failure=F3Base_Options::atualizar_estado($option,static fn($v)=>['llms'=>['new'=>42]],1);remove_filter('query',$bad);$wpdb->suppress_errors($suppressed);
 check(!$failure['persisted']&&$failure['persistencia']['linhas_afetadas']===null&&$failure['persistencia']['erro_banco']==='escrita_sql_falhou','sql_failure_measured');
}finally{remove_action('updated_option',$write,PHP_INT_MAX);raw($option,$old);}
evidence('request-292-race');
