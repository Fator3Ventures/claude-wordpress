# Acompanhantes para reproduzir os testes — Core 1.57.0

Runtimes de terceiros não são republicados no fonte Core. O instalador Core é autônomo.

| Pacote | Versão | Escopo |
|---|---|---|
| wp-mcp-fator3 | 0.33.0 | Decorador original, autorização, documentação e instalação |
| wp-mcp-meta-fator3 | 0.12.0 | SDK real de captura e exclusão Instagram; Graph controlado |
| wp-mcp-google-fator3 | 0.20.0 | SDK real ga4-reader/1.0.0, concessão, cota, paridade sintética e revogação |
| wp-mcp-linkedin-fator3 | 0.11.0 | Convivência no Site-Teste; retenção local não altera o consumidor Core |
| wp-mcp-pipedrive-fator3 | 0.2.0 | Convivência no Site-Teste; cliente Core pipedrive-api-client/1.0.0 preservado |

Forneça os pacotes originais aos plugins do laboratório. Credenciais e arquivos privados não são distribuídos. Meta/Google ativados por prepare157.php; MCP por activate-mcp1540.php, em processo posterior às provas sem decorador. core-only.php desativa acompanhantes no laboratório apenas. Pipedrive exige PHP 8.3.36; não ativar no piso Core PHP 8.3.6. Os testes de CRM Core usam transporte controlado, não certificam acesso real à API.

Identidades dos instaladores recebidos:

- wp-mcp-meta-fator3-0.12.0-instalador(4).zip: 253225 bytes; SHA-256 `b519203886d0964fa531c70cd0a66e2f8e199ff04700f0c3c5fa946d6d83e880`.

- wp-mcp-google-fator3-0.20.0-instalador(1).zip: 822259 bytes; SHA-256 `8c2456de80896dc7078321248a1df01c89745fc7f80a2c6e769ef1b6d543bbfd`.

- wp-mcp-linkedin-fator3-0.11.0-instalador(1).zip: 283053 bytes; SHA-256 `34541afa67c0991e9dc0b5474ab8678dff8cf806eace6ceb1edb47983f9e0308`.

- wp-mcp-pipedrive-fator3-0.2.0-instalador.zip: 48865 bytes; SHA-256 `b7065e4780cbc2166605164e4a822338b76627bef48c5f05a9fb9c3505efbb4a`.

MCP 0.33.0: 888204 bytes; SHA-256 `f16ee3e31e4143ffb42c566ea6da4f2da81d3771a01a0f90b5d34e3d02ac8caa`. Relatório em inputs/1550; demais relatórios/impacto em inputs/1570.
