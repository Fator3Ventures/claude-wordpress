# Fonte Core 1.57.0

Base direta 1.56.0. Runtime em work/plugin/base-site-core-fator3. Pedidos 312/313, pacotes acompanhantes e impactos recebidos em inputs/1570; normas revisão 5 em inputs/1510. Evidências em evidence/1570.

Leia docs/RELEASE-1.57.0.md, ACERVO-GA4-1.57.md e INSTAGRAM-EXCLUSAO-1.57.md dentro do runtime. build/package-installer.py e package-source.py fecham os artefatos. Testes request-312/313 usam os SDKs originais e transportes interceptados; review-1570 cobre persistência, transação, retenção e interface. Credenciais e cobertura reais não são certificadas por fixtures. Reprodução em build/README.md; estado de aceite no relatório externo.
