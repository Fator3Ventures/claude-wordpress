# Operação da 1.49.1

Comece por RELEASE-1.49.1.md. Schema administrativo 8.14.1; SDKs mantidos. As instruções operacionais de AGENTES-1.49.0.md permanecem, com as correções abaixo.

1. Para conferir o pedido 291, leia um contato com `f3base/leads-registros-ler`. Compare `nome_campanha_origem` (nome) e `nome_campanha_fonte` (procedência). Confira separadamente `campanha_id` e `utm_campaign_original`. Não regrave o registro para corrigir sua exibição.
2. Nome de conta ausente é ausência de evidência, não nome igual ao ID nem à fonte do mapa. `conta_fonte` explica a inferência de conta quando existe.
3. Confira a nota e o resumo preparados antes de qualquer teste de fornecedor. O campo comercial Campanha não aceita fallback para ID numérico. A resolução requer a mesma plataforma/conta.
4. Na fila, `fila_indisponivel` indica consulta falha; nunca interprete como zero conversões. `agenda_nao_confirmada` com `persisted=true` indica que as linhas foram antecipadas, porém o cron ainda não foi confirmado. Consulte a agenda e a saúde antes de nova ação.
5. O Implantador pode validar contato e consentimento com o schema integral, sem suprimir avisos do WordPress ou relaxar validação. Perfil piso-padrao-3.6 continua com 92 condições; a avaliação não configura o site.
6. Documentação: `f3base/documentacao-ler` sem entrada lista a allowlist; depois leia cada arquivo com paginação e SHA-256. Acesso administrativo, sem fornecedor.

Homologação com dados sintéticos não autoriza envio a clientes, edição de objetos comerciais existentes nem limpeza das mensagens Slack pendentes do dono. Para uma atualização de frota, use os bytes e o hash do instalador do relatório desta versão.
