# Site Core 1.49.0 — melhorias M1 a M11

Base direta 1.48.0; contrato administrativo 8.14.0 (143 abilities, duas novas). Perfil piso-padrao-3.6 preservado. Sem tabela, coluna, opção ou agenda nova; sem migração. Origem: ordem do dono de 22/10/2026 (melhorias da rodada, sem pedido numerado aberto). Acompanhantes examinados: MCP 0.28.0, Google 0.17.0, LinkedIn 0.7.0 e Meta 0.6.0.

## M1 — tradução antes de `init`

Com o MCP LinkedIn ativo, o registro de consumidores em `plugins_loaded:20` lia o catálogo de opções do Core, que chamava `__()` com o domínio `f3base` antes de `after_setup_theme`. O WordPress 7.1 acusava `_load_textdomain_just_in_time` em toda requisição. Agora o catálogo montado antes desse ponto usa tradução nula temporária, só para o domínio do pacote, e não vira o definitivo: a primeira leitura depois de `after_setup_theme` monta de novo. Efeito adicional corrigido: filtros `f3base_options_catalogo` registrados depois de `plugins_loaded` (tema, `setup_theme`) eram ignorados pelo catálogo memoizado cedo; agora valem. O pacote continua monolíngue; nenhuma string mudou.

## M2 — motivo acionável quando a ability de outro pacote recusa a chamada

A tela de anúncios chama `linkedin/admin-options` e `ads/search` em processo. Com o Fator3 MCP 0.28.0 ativo, essas chamadas nativas são recusadas pelo canal (`profile_denied`/`permission_denied`) antes de chegar ao fornecedor, e o Core devolvia só `linkedin_catalogo_indisponivel`/`google_catalogo_indisponivel`. Agora a resposta inclui `motivo` (código sanitizado), `ability` e `mensagem`:

- `mcp_recusou_chamada_nativa`: o MCP instalado recusou a chamada nativa (`profile_denied`, `connection_context_required`); a consulta não chegou ao fornecedor. Com MCP até 0.28.0, a ação é atualizar o Fator3 MCP para 0.29.0 ou superior. Com 0.29.0 ou superior, a tela (admin-ajax com nonce) chega ao fornecedor; a recusa só ocorre fora de requisição administrativa web (linha de comando, cron), e a mensagem diz isso. A resposta traz `mcp_versao`.
- `permissao_recusada_pela_integracao`: permissão recusada (`ability_invalid_permissions`, `permission_denied`). Ação: conferir serviço e autorização no pacote da integração; com MCP 0.28.0 a recusa pode vir do canal.
- Demais motivos preservam o código já publicado e acrescentam `motivo` e `mensagem`.

A execução de `ads/search` passou a ter `try/catch`; exceção vira `motivo=excecao_na_integracao`, sem texto da exceção. A tela mostra `mensagem` quando presente. O Core funciona com qualquer ordem de troca; a correção do canal é do MCP.

## M3 — rotas públicas com parâmetro em lista

`POST /f3base/v1/formularios/token` (`formulario`, `submissao`) e `GET /f3base/v1/servidor-sonda` (`eco`) faziam `(string)` de lista e gravavam "Array to string conversion" no log a cada robô. Agora lista ou objeto vira texto vazio. Status públicos preservados (429 e 400).

## M4 — prioridade na fila de conversões pelo servidor

Antes, `pendente`, `recusado` e `bloqueado` disputavam as mesmas dez vagas por passagem, ordenadas por `proxima`. Bloqueios de configuração (ex.: regra LinkedIn de servidor ausente em 90 dias de contatos) ocupavam as vagas e atrasavam por horas a conversão nova de outro destino. Agora a passagem seleciona primeiro `pendente` e `recusado` vencidos e só completa as vagas restantes com `bloqueado`. Linhas bloqueadas que mudam de estado passam a registrar `atualizado_em`.

## M5 — `f3base/conversoes-fila-ler` (nova, leitura)

Entrada: `dias` 1–90 (padrão 30), `destino` (`ga4`, `google_ads`, `linkedin`, opcional), `amostra` 0–20 (padrão 5). Saída por destino: total, contagem por estado (`pendente`, `bloqueado`, `recusado`, `incerto`, `entregue`, `cancelado`, `esgotado`), motivos com quantidade e explicação, vencidas por estado, `atraso_segundos` da conversão enviável mais antiga, amostra de `record_id` (estado, código, data) para detalhar com `f3base/conversoes-entregas-ler`. Inclui a prontidão de transporte por destino, presença das regras LinkedIn de navegador e de servidor e a próxima passagem agendada. Sem dado de contato, sem chamada a fornecedor.

## M6 — `f3base/conversoes-bloqueadas-reavaliar` (nova, escrita local)

Entrada: `destino` (obrigatório), `codigo` (opcional, `^[a-z][a-z0-9_]{0,79}$`), `limite` 1–500 (padrão 100), `confirmar` (padrão false). A simulação devolve quantas linhas bloqueadas existem, quantas seriam selecionadas, a distribuição por código e a prontidão atual do adaptador. Confirmada, antecipa `proxima` para agora nas linhas selecionadas e agenda uma passagem em 30 segundos. Não envia nada: o worker aplica consentimento, prazo, regra, concessão e vínculo ao destino; linha ainda inelegível volta a `bloqueado` com o motivo atual. Uso típico: depois de preencher a regra LinkedIn de servidor ou concluir a concessão `rw_conversions`.

## M7 — achado de loopback na tela de contatos

Investigado: a tela `f3base-leads` não faz HTTP síncrono. As requisições a `/`, `/robots.txt` e `/wp-json/f3base/v1/token` observadas em laboratório vêm das verificações agendadas do Core (robots, navegação, rotas de token), executadas pelo WP-Cron em outro processo; a tela só dispara o `spawn_cron` não bloqueante do WordPress. Em servidor PHP de um único processo, o loopback do cron concorre com a página. Nenhuma mudança de código; guarda de regressão nos testes.

## M8 — catálogo LinkedIn do plugin externo sem conta ou conexão

Com o cliente `linkedin_plugin`, `F3Base_Linkedin_Cliente::catalogo('campanhas'|'formularios')` mandava ao LinkedIn uma entrada com conta ou conexão vazia e recebia `ability_invalid_input`, exibido como `linkedin_catalogo_indisponivel`. Agora a mesma guarda do cliente Core vale antes da chamada: conta não numérica devolve `salve_a_conta`; conexão vazia ou fora do formato aceito pelo pacote LinkedIn devolve `selecione_a_conexao_linkedin`. Nenhuma ability é executada nesses casos.

## M9 — custo do contexto de medição

Cada leitura de `site-measurement-context/1.0.0` (`F3Base_Medicao_Contexto::snapshot()`) fotografava 23 opções com 23 consultas, duas vezes (conferência de estabilidade): 46 a 49 consultas por leitura; a leitura administrativa (`f3base/medicao-contexto-ler`) chegava a 92. O Google relê o Core antes de cada envio. Agora cada fotografia lê as 23 opções em uma consulta (`F3Base_Options::fotografias_brutas`), direto do banco e sem cache: 2 consultas por leitura (5 na primeira da requisição) e 4 na administrativa. O snapshot é o mesmo (mesmos valores, revisões e procedência; revisão idêntica medida antes e depois), a dupla leitura de estabilidade foi mantida e uma alteração de configuração feita na mesma requisição aparece na leitura seguinte. Sem mudança de autoload, opção ou dado.

## M10 — estado do cliente LinkedIn externo sem resposta do SDK

Com o cliente `linkedin_plugin` selecionado, as telas de Conexões chamavam `F3Base_Linkedin_Cliente::estado()`; quando o SDK do LinkedIn falhava antes de responder (pacote ausente, consumidor não registrado, contrato ou método indisponível), o retorno não tinha `data` e o PHP gravava "Undefined array key \"data\"" a cada abertura. Agora todo retorno de falha traz `data` vazio e a tela mostra o código. Sem mudança de contrato.

## M11 — link morto para o relatório Search Console

A seção Configurações → Medição → Search Console tinha o link "Abrir relatório Search Console" para `admin.php?page=f3base-gsc`, tela que não existe ("Sorry, you are not allowed to access this page."). O link agora abre a visão Search Console da Medição (`admin.php?page=f3base-medicao&area=aquisicao&visao=gsc`). Um teste confere que todo `admin.php?page=` citado pelo pacote aponta para tela registrada.

## Implantação e limites

Atualização direta de 1.48.0 pelo fluxo nativo; o ciclo de etapas conclui sem migração de dados. Reverter para 1.48.0 só remove as duas abilities e volta ao comportamento anterior; nenhum dado criado por esta versão precisa ser desfeito. A reavaliação confirmada apenas antecipa o horário das linhas: depois de executada pelo worker, envios feitos não se desfazem.
