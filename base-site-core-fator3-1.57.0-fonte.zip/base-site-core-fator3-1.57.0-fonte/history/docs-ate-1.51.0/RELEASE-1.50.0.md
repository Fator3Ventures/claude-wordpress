# Site Core 1.50.0 — pedidos 292 e 293

23/10/2026 · Base 1.49.1 · contrato administrativo 8.15.0. SDKs inalterados. WordPress 7.1.2+, PHP 8.3.6 de 64 bits. Nova opção interna `f3base_credenciais_estado`, sem autoload, contém somente identidades e revisões; nenhum segredo novo fora da cifra existente. Sem nova tabela ou migração destrutiva.

## 292 — confirmação da tarefa e concorrência

A opção de operação é compartilhada entre tarefas. Uma gravação de outra tarefa entre a escrita e sua confirmação podia fazer o gravador recusar a fotografia completa, embora o resultado da tarefa já estivesse salvo. A conclusão agora relê a tarefa específica e confere run_id, fim e código. UPDATE de valor idêntico com zero linhas é distinguido de uma escrita perdida; não há inferência de sucesso apenas por retorno zero.

`dados.persistencia` registra operação, etapa, linhas afetadas, revisões esperada/lida, reconferência, lease esperada/lida e causa. `dados.tentativas_persistencia` conserva o conjunto limitado de tentativas. Erros técnicos usam códigos, sem SQL nem valores de configuração. `checkpoint_confirmado_releitura` indica resultado efetivamente encontrado; `checkpoint_superado` é neutro e aponta a conclusão posterior comprovada do mesmo hook/argumentos e da mesma ocorrência ou seguinte. Uma outra reserva comprovada continua `reserva_ocupada`.

A conclusão posterior reconcilia até 200 falhas de checkpoint da mesma tarefa/hook nos últimos 30 dias, preservando o resultado original e acrescentando `reconciliacao`. Não reclassifica callbacks falhos nem argumentos diferentes. Legado sem quando/hash dos argumentos não é declarado resolvido por aproximação temporal. `checkpoint_nao_persistido` permanece falha quando não há resultado confirmado, reserva ou conclusão posterior comprovada. O acompanhamento por sete dias na produção depende da implantação.

`f3base/execucoes-ler` e saúde incluem `execucoes.checkpoints.por_dia_origem`, com data UTC, origem, código e contagem; os registros conservam hora local e UTC. Isso separa falhas restantes, reconferências, conclusões posteriores e disputas.

## 293 — credenciais

Ajuda e rótulos específicos em todas as telas de credenciais. Formato verificado no servidor e consulta da candidata antes de salvar para Pipedrive, Slack, Meta e LinkedIn. Clarity valida somente formato; seu teste explícito conserva a cota do projeto. Falha preserva o segredo anterior. Troca com identidade diferente ou anterior não comprovada exige confirmação assinada, ligada ao administrador, site, candidata, contexto e revisão, válida por dez minutos. A candidata nunca é persistida para montar a confirmação.

`f3base/credenciais-ler` mostra ajuda, estado e identidade da credencial salva sem valor. `f3base/credenciais-verificar` verifica candidata ou a salva; `usar_salva=true` registra a identidade sem trocar a credencial e sem criar objetos comerciais. O campo da candidata chama-se `credential` para permitir a redação do canal. `f3base/config-core-escrever` aceita `confirmacao_identidade` retornada pela prévia. A confirmação não contorna nova verificação nem conflito de revisão.

Rotação com identidade comprovadamente igual conserva catálogo Pipedrive, canal Slack e cursores Meta/LinkedIn. Clarity conserva a evidência do teste anterior, sem alegar novo teste remoto. A introspecção LinkedIn normalmente não informa o membro; nesse caso a troca exige confirmação e a limitação é mostrada. Consulte CREDENCIAIS-1.50.md para regras, endpoints e limites.

## Compatibilidade e instalação

Pacotes considerados: MCP 0.29.1, Google 0.19.0, Meta 0.8.0 e LinkedIn 0.9.0. Nenhuma mudança em seus códigos ou contratos SDK. Google permanece dono de suas conexões; o Core continua dono dos webhooks de formulários Google Ads. As provas de concorrência dos mantenedores Meta/LinkedIn foram consideradas sem reapresentá-las como prova própria.

Instale o ZIP com slug e SHA-256 do relatório. Espere o ciclo do Core concluir e consulte saúde, execuções e documentação por `f3base/documentacao-ler`, paginando até proxima_linha nula. Reverter arquivos para 1.49.1 mantém a cifra e os metadados adicionais, mas remove as novas validações e reintroduz o diagnóstico antigo. Reversão de arquivo não desfaz consultas nem efeitos comerciais.
