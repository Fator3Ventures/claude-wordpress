# Fator3 Site Core 1.44.0

Base direta: 1.43.0. Contrato administrativo: 8.9.0. Escopo: pedidos 246, 248, 249 e 256, 258–263. Fonte de requisitos: arquivo Fator3 Site Core(20261021-141715).md e pedido 263 recebido no chat em 21/10/2026. A implantação na frota e o aceite com dados de produção são separados da prova local.

## Configuração, integração e leitura

- **246:** datas com controles nativos; horários da qualidade e consentimento interpretados no fuso do WordPress, com recusa de data inválida e de horário inexistente em transição de fuso. Textos de mapeamentos, catálogos, SEO, grupos e operações revisados. A lista efetiva está em TEXTOS-1.44.0.md; a revisão cobriu os controles e textos das 20 áreas renderizadas, com verificação de cobertura e inspeção das instruções por assunto. Documentos históricos não foram reescritos.
- **248:** seções de mapeamento no Pipedrive têm títulos distintos, incluindo pessoa e respostas de formulários. Valores e revisões continuam no contrato existente.
- **249:** com cliente Plugin LinkedIn, a descoberta explícita usa `linkedin/admin-options` do LinkedIn 0.4.1: formulários por canal leads e campanhas por canal ads. Cursor vinculado à revisão da conexão; mudança exige nova consulta. Concessão ads é própria e pode não existir. Escolher/descobrir não salva nem altera o cliente, token ou origem de importação.
- **256:** data da nota inicial do Pipedrive no fuso do WordPress em `d/m/Y H:i:s P`. Não reescreve notas já entregues.
- **258:** comparação editorial explicita `anterior_parcial`, dias retidos e total de dias da janela. Sem nenhuma audiência retida, mantém totais nulos. `sessoes` conta sessões distintas observadas no período; `sessoes_iniciadas` exige início observado nele. Início anterior à janela ou ausente explica divergência possível, mas não comprova a causa de um site específico.
- **259:** recuperação administrativa de captura aceita mesmo com transporte original navegador/ausente, mediante confirmação de não entrega e referência de destino atualmente pronta. Simulação não grava. Confirmação registra autor, data, referência e transporte original, preserva a captura e cria uma entrega por destino. Consentimento, identificador de clique, idade e timestamp continuam obrigatórios. Entregue, incerto, cancelado e esgotado não são reenviados. Recibo incerto do Google usa reconciliação no vínculo original, sem nova ingestão.

## Desempenho 260–262

`f3base/vitais-ler` (manage_options) recebe caminho, período, métrica, dispositivo e segmento. Retorna p75 da última amostra por carregamento, alvos estruturais, fases, origens de scripts e contagens de exclusão. INP informa ponteiro/teclado e fases entrada/processamento/apresentação; atribuição de script usa Long Animation Frames quando disponível. LCP informa imagem/texto, recurso sem query/fragmento/credencial e fases disponíveis. Seletores só contêm tags e posições, sem IDs, classes, texto ou valores. Atribuição é calculada no Core sobre o coletor já existente; não altera o bundle web-vitals nem cria eventos novos com esses detalhes para terceiros.

A automação é gravada na própria amostra, com regra e motivos. Por padrão, `automacao=audiencia` exclui provável/declarada e legado sem classificação; `automacao=todas` permite inspeção explícita. Ausência de sinal não prova pessoa humana. As amostras anteriores não são reclassificadas por aproximação. Eventos históricos capturavam a primeira emissão; o acervo conserva a última por carregamento e usa chave/retensão próprias. Por isso não há cruzamento confiável para corrigir retrospectivamente os 54 INPs citados no pedido 261.

O CSS pequeno dos formulários entra integralmente inline em `wp_head`, pela fila de estilos antes do tema; remove a requisição isolada mantendo a possibilidade de sobrescrita pelo tema. PageSpeed e campo real precisam ser medidos depois da implantação.

## Diagnóstico privado de formulários — 263

Leia FORMULARIOS-TENTATIVAS-1.44.md. Toda tentativa barrada detectada pelo script registra uma fotografia dos campos ativos da etapa, com estados, regras e motivos. Validação nativa e grupo são consolidados em uma tentativa, inclusive antes do primeiro preenchimento. Telefone inválido conserva o motivo específico mesmo quando a mensagem exibida é a do grupo. Correção observada no `change`, aceite confirmado no servidor e saída observada não contêm valores. Instância permanece entre as duas etapas e em diálogo. O endpoint próprio não repassa o corpo a eventos de medição nem às filas comerciais.

## Banco e retorno

Migração aditiva: quatro colunas em `f3base_vitais` (automação, motivos, regra e atribuição) e tabela `f3base_formulario_tentativas`. Configuração nova `f3base_formulario_tentativas`, sem sobrescrever escolhas anteriores. A 1.44.0 cria a tabela em instalação nova e na atualização direta 1.43.0. Restauro de arquivos não desfaz banco nem envios externos; mantenha backup anterior, use o fluxo de recuperação do Core e reconcilie pendências antes de reabrir executores. Retornar à 1.43.0 interrompe o diagnóstico novo e sua limpeza: elimine/arquive com autorização os dados privados antes do retorno ou mantenha a limpeza sob responsabilidade explícita. Desinstalação remove a tabela de tentativas.

Convivência examinada: MCP 0.25.0, Google 0.16.0, Meta 0.4.1 e LinkedIn 0.4.1. Consome interfaces públicas existentes; nenhum pacote complementar foi alterado nesta rodada. Não há novo contrato obrigatório a encaminhar ao Google ou relatório de impacto só para anunciar a versão.
