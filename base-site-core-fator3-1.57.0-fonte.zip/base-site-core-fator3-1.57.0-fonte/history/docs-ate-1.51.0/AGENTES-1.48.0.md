# Operação da 1.48.0

Leia RELEASE-1.48.0.md e os schemas em dados/abilities-*.json. Leitura instalada autenticada: f3base/documentacao-ler, arquivo, linha, limite até 200; percorra proxima_linha até null e confira SHA-256.

Slack: listar → simular apagar → conferir seleção/revisão → executar com chave e motivo. Não use db/query para descobrir IDs quando a nova rota atende. Teste=false exige confirmação específica. Confirmação de presença e recibo histórico são distintos. Nunca amplie a limpeza para mensagens não registradas ou respostas humanas. Se o contato já saiu, use a prova local restante. Para reclassificar teste anterior, leads-marcar-teste com revisão atual.

LinkedIn: configure separadamente Insight Tag e Conversions API. Não copie o ID do navegador para preencher automaticamente o servidor. Confira a concessão no LinkedIn e a prévia do Core. Teste/homologação não são enviados a anúncios. O SDK de medição usado pelo Google permanece 1.0.0; IDs de destino estão na extensão administrativa.

Agendador: reserva_ocupada é neutra e identifica a dona; consulte disputas por dia/origem. Checkpoint sem dona continua falha e requer diagnóstico. Não descarte falhas por coincidência de segundo. Não reenvie entrega incerta.
