# Fator3 Site Core 1.51.0

Base direta 1.50.0. Contrato administrativo 8.16.0. Pedidos 294 e 295. Slug, namespaces e 145 abilities Core preservados.

## 294 — operação Pipedrive

Novo contrato PHP `pipedrive-api-client/1.0.0`, compatível com o consumidor publicado em Fator3 MCP Pipedrive 0.1.0. Registro não autoriza operação. Option f3base_pipedrive_operacao: ativo=false, consumidores=[], orcamento_diario=3000. Configuração administrativa com revisão/procedência; nenhuma credencial copiada para o novo plugin.

GET custa estimativa local de 20 unidades, escritas 10, em reserva atômica independente da fila de entregas, qualidade e verificação. O saldo oficial observado no header x-daily-ratelimit-token-remaining é guardado com horário UTC. Abaixo de 3000, somente operacao é recusada; HTTP 429 continua pausa compartilhada. Saldo desconhecido não é inventado, nem aumentado ao virar o contador UTC.

Host api.pipedrive.com fixo, caminhos /v1/ ou /api/v2/, métodos GET/POST/PUT/PATCH/DELETE, corpo de até 64 KiB, resposta de até 512 KiB, timeout 20 s, zero redirecionamento e retry de escrita. Merge, ids em massa, credenciais na query/corpo e URLs arbitrárias recusados. Recuperação, administrador, provider, revisão e orçamento são conferidos antes do transporte; alterações administrativas pertinentes compartilham a trava. Timeout/exceção após início do transporte têm resultado incerto.

`f3base/pipedrive-verificar` e `f3base/como-usar` mostram configuração de operação, consumidores registrados/autorizados, orçamento e saldo. As rotas livres pertencem ao novo plugin; o Core não publica uma nova ability de HTTP arbitrário. Veja PIPEDRIVE-OPERACAO.md.

## 295 — credencial Meta salva

`f3base/credenciais-verificar` com usar_salva=true confere a credencial existente no fornecedor mesmo quando ela não corresponde à heurística antiga EAA/mínimo 100. O resultado inclui avisos por regra, sem valor. Removido o mínimo arbitrário de tamanho; a Meta confirma validade, identidade e escopos pelo debug_token. Espaços e quebras nas extremidades são removidos no uso/escrita, com aviso; ler não recifra nem troca o segredo.

Identidade confirmada fica vinculada à revisão da credencial salva, visível em `f3base/credenciais-ler` e na tela. Falha remota preserva a credencial. Controles internos de valor Meta legado nunca são interpolados em header; a consulta usa parâmetros codificados. Segredos e mensagens livres de erro do fornecedor não integram respostas ou logs próprios.

## Compatibilidade e implantação

Core conserva WP 7.1.2/PHP 8.3.6 de 64 bits, instalação única. O novo Pipedrive declara WP 7.1.3/PHP 8.3.36. Avaliar o mínimo de cada pacote antes de ativar juntos. Referências: MCP 0.29.1, Google 0.19.0, Meta 0.9.0, LinkedIn 0.10.1, Pipedrive 0.1.0.

Instalar Core antes do Pipedrive. A atualização não habilita operação, não troca credenciais e não envia dados comerciais. Configurar explicitamente o site-porta após homologação. Não há nova tabela Core. Novas options de configuração/orçamento/saldo são aditivas e preservadas em rollback de arquivos. O relatório externo desta entrega descreve testes executados e pendências de fornecedor; esta nota não certifica implantação em produção.
