# Operação da 1.49.0

Leia RELEASE-1.49.0.md e os schemas em dados/abilities-*.json. Leitura instalada autenticada: f3base/documentacao-ler, arquivo, linha, limite até 200; percorra proxima_linha até null e confira SHA-256.

Conversões pelo servidor, diagnóstico em três passos:

1. `f3base/conversoes-fila-ler` com `dias` 7 ou 30: veja por destino o estado, os motivos com quantidade e o atraso da conversão enviável mais antiga. `transporte` mostra o que está pronto; `linkedin` mostra se as duas regras existem.
2. Para um `record_id` da amostra: `f3base/conversoes-entregas-ler` e, se for LinkedIn, `f3base/linkedin-conversao-previa`.
3. Corrija a configuração no lugar certo (regra no Core; concessão e escopos no pacote LinkedIn; adaptador Google no pacote Google). Depois, `f3base/conversoes-bloqueadas-reavaliar` com `destino` e o `codigo` do bloqueio: simule, confira `adaptador_pronto`, e só então repita com `confirmar: true`. Não use para `incerto` (aguarde a reconciliação) nem para `esgotado` (use `conversoes-recuperar`).

Catálogos de anúncios: `salve_a_conta` e `selecione_a_conexao_linkedin` indicam configuração incompleta da integração LinkedIn (nada foi consultado). `mcp_recusou_chamada_nativa` significa que o Fator3 MCP instalado bloqueou a chamada nativa; a correção é atualizar o MCP, não reconfigurar o LinkedIn ou o Google. `permissao_recusada_pela_integracao` aponta autorização/serviço no pacote da integração.

Logs: aviso `_load_textdomain_just_in_time` do domínio `f3base` deixou de ocorrer nesta versão; se reaparecer, registre a cadeia de chamadas e encaminhe.

Contexto de medição: a leitura custa 2 consultas ao banco e reflete alterações feitas na mesma requisição; não há cache a invalidar.
