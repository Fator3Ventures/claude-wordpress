# Site Core 1.47.0 — pedidos 284–287

Base direta 1.46.1. Contrato administrativo 8.12.0. Perfil piso-padrao-3.6 preservado. Nenhum ajuste automático nos formulários ou temas de sites existentes.

## 284 — eliminação no Pipedrive

A resposta de criação da atividade do e-mail automático passa a gerar prova HMAC dos mesmos campos usados na atividade principal. A coluna atividade_prova, sem conteúdo pessoal, acompanha atividade_id no diário de e-mail. A eliminação confere conta, lead e objeto atual; só exclui a atividade inalterada com prova compatível. Registros antigos não recebem prova fabricada. Atividade alterada ou criação incerta permanece para revisão.

O journal traz historico_restante com tipo e id de cada nota/atividade ainda ligada ao lead, sem assunto ou conteúdo. copias_externas.email_smart_bcc informa a cópia de e-mail: o Core não conhece o ID da mensagem; a API oferece exclusão de conversa inteira, cuja exclusividade não está comprovada. Não se apaga uma conversa que pode conter mensagens independentes. Se o Pipedrive ainda indicar mensagens/objetos ligados à pessoa, a revisão explicita essa contagem. concluida confirma os objetos comprovados, não a inexistência dessa cópia de e-mail.

O cancelamento local aguarda o trabalhador de e-mail terminar, antes de iniciar a eliminação remota. Não dispara SMTP nem recria atividade incerta durante a exclusão.

## 285 — LinkedIn pelo servidor

f3base_conversoes_transporte.linkedin aceita navegador ou ambos. O padrão ambos só gera intenção em novos formulários aceitos com partner_id e conversion_id configurados. É necessário um adaptador autorizado do pacote LinkedIn; o 0.5.0 ainda não o oferece. Sem fornecedor pronto, não há envio. Não transfere eventos históricos nem vincula automaticamente uma conta que aparece depois.

Novos formulários aceitos usam o record_id aleatório do servidor como event_id da aquisição; registros anteriores preservam sua identificação. Navegador e servidor usam esse mesmo ID; lintrk recebe conversion_id e event_id. A regra e o instante do aceite em milissegundos ficam congelados no registro. A resposta do formulário informa a regra congelada, inclusive quando o HTML veio de cache. A fila f3base_conversoes_servidor ganha destino linkedin e HTTP numérico; guarda somente identidade local, referência opaca, estados, códigos e datas. O payload é montado no despacho: e-mail normalizado em SHA-256, li_fat_id quando observado, nome/sobrenome, empresa/cargo/país disponíveis. userInfo exige o par nome/sobrenome da API. Não inventa país a partir do IP. Valor/moeda opcionais são definidos no servidor pelo filtro f3base_linkedin_valor_conversao (array valor/moeda, segundo argumento ID do formulário), congelados no aceite; valores arbitrários do visitante não viram receita.

Teste, homologação, spam, eliminação, audiência excluída e falta/revogação de publicidade impedem despacho. Recusa comprovada pode repetir até 10 tentativas; resultado incerto não repete automaticamente. Recuperação usa conversoes-recuperar, confirmação explícita de não entrega e vínculo ao destino atual; a regra original deve coincidir. Prazo: 90 dias. O evento e seu horário não mudam na repetição.

linkedin-conversao-previa recebe record_id, inclusive de teste, exige manage_options e f3base_ler_leads, e não enfileira nem envia. conversoes-entregas-ler lê o diário. medicao-contexto-ler mostra transporte ambos e rota core_server; server_credentials_not_verified mantém o contrato público 1.0.0 e o aviso linkedin_server_<motivo> detalha adaptador_indisponivel, sem_conexao, sem_escopo ou regra_sem_fonte_api. Isso não é prova de entrega externa.

Procedência: gravação de partner_id e conversion_id pelo configurador registra a revisão e o canal atuais. Reafirme os dois valores existentes por config-core-escrever com suas revisões quando o partner_id legado não tem prova. Não atribua autoria histórica. Datas distintas do mesmo canal/origem confirmado não geram mixed_provenance_linkedin; a data agregada fica nula quando não existe um único instante. Procedência ausente, filtrada ou de canais diferentes continua explicitada.

## 286 — campo único de contato

Declare tipo text e papel contato; o nome técnico pode continuar contato. O obrigatório exige presença, sem exigir formato. Pode participar de exigir_um_de (nesse caso, obrigatório individual deve ser false). O Core reconhece e-mail válido; caso contrário tenta telefone no país configurado com formato livre. Guarda campos.<nome> exatamente como digitado, contato_normalizacao e, para telefone, telefone_normalizacao com classe valido, sem_ddd ou invalido. Somente identidade válida preenche email/telefone usados pelas integrações. Texto como abc permanece no registro, sem inventar telefone.

Um contato preenchido é a identidade principal e substitui eventuais cópias ocultas de email/telefone. A migração recomendada remove essas cópias e o JavaScript correspondente apenas depois da atualização do Core. Campos separados e os sites com versões anteriores continuam com seu contrato. Identificação permanece na etapa 1. Não se aplica automaticamente aos formulários nativos das plataformas.

## 287 — confirmação no tema

confirmacao_url interna continua pelo template do WordPress e filtra somente o conteúdo principal da página pública de destino. Renderiza blocos e acrescenta a mensagem uma vez. Mostra um único botão do Core apenas para uma URL HTTPS de WhatsApp permitida; o rótulo é mensagens.continuar_whatsapp. Não remove botões que o próprio autor tenha colocado no conteúdo.

Referência temporária: 10 minutos, caminho vinculado; referência expirada responde 410, destino divergente/indisponível 404. Mantém DONOTCACHEPAGE, Cache-Control private/no-store, noindex/nofollow/noarchive e Referrer-Policy no-referrer. Não cria uma segunda conversão na confirmação.

## Estrutura e operação

Migração aditiva: f3base_email_novo_lead.atividade_prova (longtext anulável) e f3base_conversoes_servidor.http (smallint unsigned, padrão 0). Ciclo mantém 18 etapas. Backup conjunto do banco e arquivos antes da troca; use operacao-recuperacao para preparar/drenar e retomar com a guarda atual. Downgrade de arquivos não desfaz entregas externas nem remove colunas. Não restaurar banco antigo sobre filas vivas sem reconciliação. Sem credenciais novas no Core: rw_conversions, tokens e conexão pertencem ao pacote LinkedIn.

Aceites externos: CTO Office com Pipedrive e e-mail automático; LinkedIn com escopo concedido, fonte API e ordem do dono. Provas sintéticas não substituem a confirmação na conta nem a deduplicação no Campaign Manager.
