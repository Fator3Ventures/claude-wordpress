# Site Core 1.49.1 — revisão e pedido 291

23/10/2026. Base direta 1.49.0; contrato administrativo 8.14.1, com 143 abilities. Perfil piso-padrao-3.6 preservado (92 condições). Também validado o salto de 1.48.0 usado no Site-Teste. Sem tabela, coluna ou opção nova e sem migração destrutiva. As melhorias M1–M11 da 1.49.0 permanecem.

## 291 — nome separado da fonte

`nome_campanha_origem` e `nome_anuncio_origem` passam a conter o nome; `conta_origem` contém nome de conta quando conhecido, ou fica vazio. Os códigos de procedência ficam em `nome_campanha_fonte`, `nome_anuncio_fonte` e `conta_fonte`. Exemplo: nome `Campanha Institucional`, fonte `mapa_do_site`. Conta inferida pelo mapa mantém seu ID, `conta_fonte=mapa_da_origem` e nome vazio: o Core não inventa nome a partir do número.

A resolução continua restrita à plataforma e à conta, preserva nome recebido no link e conserva `utm_campaign_original` e os IDs explícitos. Os mapas não cruzam contas. Nota do Pipedrive, Slack, e-mail de contingência e resumo comum exibem nomes disponíveis e fontes com rótulos próprios. O campo Campanha do Pipedrive usa o nome resolvido ou um `utm_campaign` textual; ID numérico ou macro sem resolução deixa o campo ausente.

Registros antigos com `mapa_da_origem`/`mapa_do_site` no lugar do nome são corrigidos na projeção da leitura (`f3base/leads-registros-ler`) e no preparo de novas entregas. O banco original, a cifra e a janela de comportamento do resumo congelado são preservados. O resumo em memória ganha hash efetivo quando necessário. Não há reenvio automático nem edição de mensagens/objetos externos já entregues. Partes de transporte já serializadas conservam a identidade de sua tentativa; não se reiniciam entregas incertas.

As fontes também constam nas agregações de origens e campanhas dos relatórios. Os novos campos não criam eventos em plataformas de anúncio; as reduções de consentimento continuam aplicadas antes da apresentação.

## R1 — schemas completos de contato e consentimento

Os extensores de textos criavam somente `properties`, sem `type=object`, para `f3base_contato` e `f3base_consentimento`. O validador do WordPress avisava e não validava corretamente a raiz. Agora o schema base é montado antes de acrescentar os textos, tanto na entrada parcial quanto no valor completo. Valores válidos permanecem válidos e tipos incorretos são recusados. Correção coordenada com o impacto do Implantador 2.11.0; nenhum arquivo partilhado foi alterado.

## R2 — falhas da fila não parecem sucesso

`f3base/conversoes-fila-ler` verifica falhas em todas as consultas, incluindo vencidas e amostras. `f3base/conversoes-bloqueadas-reavaliar` verifica contagem e agrupamento antes de modificar linhas. Falha retorna `ok=false`, `codigo=fila_indisponivel`; a reavaliação informa `persisted=false` quando não começou a escrita.

Após antecipar `proxima`, a reavaliação confere o agendamento. Se ele falhar, retorna `ok=false`, `codigo=agenda_nao_confirmada`, `persisted=true`, quantidade efetivamente alterada e detalhe de `agenda`. Não repita cegamente: leia a fila e a agenda. `passagem_agendada_em` é a data efetivamente observada, não apenas a solicitada. No sucesso, o campo `codigo` conserva o filtro da entrada. Nada é enviado por essa operação; o worker mantém todas as guardas existentes.

## Instalação, recuperação e convivência

Use o instalador nativo, confira slug e SHA-256 do relatório, espere o ciclo do Core concluir e leia a saúde. Reverter arquivos para 1.49.0 conserva dados, mas restaura os defeitos acima; fontes novas são aditivas. Reversão não desfaz entregas externas.

Convivência verificada com Fator3 MCP 0.29.1, Google 0.18.1, LinkedIn 0.8.1 e Meta 0.7.1. Os contratos dos SDKs não mudaram. A versão do Core não comprova credenciais nem processamento real de conversões no fornecedor. As pendências de concessão LinkedIn e acompanhamento diário do executor pertencem à homologação da frota.

Leitura documental: `f3base/documentacao-ler`, `arquivo`, `linha`, `limite` até 200; continuar por `proxima_linha` até null e conferir SHA-256. Nenhuma leitura documental chama fornecedor.
