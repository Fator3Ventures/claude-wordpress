# Agentes — Core 1.47.0

Leia RELEASE-1.47.0.md. Base direta 1.46.1; administrativo 8.12.0; perfil piso-padrao-3.6. Pedidos 284–287 apenas. Não repita 274–283.

- Antes da troca: ler versões reais, preparar/drenar o Core, backup privado do banco, retomar pela guarda corrente; instalar ZIP único pelo canal administrativo e conferir ciclo completo.
- Formulário: consultar schema atual de f3base_formularios. Campo text/papel contato, presença obrigatória ou grupo exigir_um_de. Não criar hidden email/telefone nem depender de JavaScript do tema. Não alterar automaticamente formulários da frota.
- LinkedIn: ler medicao-contexto-ler e avisos linkedin_server_*. Prévia linkedin-conversao-previa com registro sintético; nenhum envio em teste. O pacote LinkedIn 0.5.0 não oferece CAPI: implementar adaptador pelo contrato documentado no impacto; não esperar para integrar o consumidor Core. Não ativar concessão, mexer na regra ou enviar conversão real sem ordem correspondente.
- Procedência desconhecida: reapresentar IDs atuais pelo configurador com revisão esperada. Isso registra a reafirmação atual, sem inventar origem passada. Não apagar warning sem evidência.
- Eliminação CRM: ler journal e historico_restante. Prova antiga ausente exige revisão, nunca capturar o estado atual como prova de criação. Cópia SmartBCC restante é explícita e não autoriza apagar conversa inteira.
- Confirmação: verificar template real, blocos, mensagem, rótulo e único botão do Core, headers de privacidade; referência tem validade de 10 minutos.
- Homologação de Pipedrive é em CTO Office/Korvena, com ordem e contato de teste; Site-Teste para prévia e formulários. Não publicar na frota nem transmitir impactos sem autorização de envio.
