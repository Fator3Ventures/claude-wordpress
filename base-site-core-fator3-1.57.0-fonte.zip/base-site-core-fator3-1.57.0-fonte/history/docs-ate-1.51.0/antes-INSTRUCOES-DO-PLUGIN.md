> Versão atual 1.39.0, contrato administrativo 8.4.0. Consulte [RELEASE-1.52.0.md](RELEASE-1.52.0.md) e [AGENTES-1.52.0.md](AGENTES-1.52.0.md) para alterações 230–235 e bloqueios de aceite. Seções anteriores permanecem referência histórica.

# Instruções do plugin

Leia DOCUMENTACAO.md, AGENTES-1.52.0.md e CONVERSOES-SDK-1.36.md. Documentos anteriores são históricos quando houver divergência. Normas comuns revisão 4.
