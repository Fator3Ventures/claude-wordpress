# Credenciais — Core 1.50.0

A ajuda junto a cada campo e o catálogo executável são a referência dos rótulos, caminhos e formatos. Campo vazio mantém a credencial; apagar é explícito. A cifra existente é preservada. Abrir tela ou consultar identidades não chama fornecedores.

| Credencial | Verificação anterior à escrita |
|---|---|
| Pipedrive | 40 caracteres hexadecimais; GET /api/v1/users/me no domínio configurado; usuário, empresa e domínio |
| Slack bot | xoxb-; auth.test; se houver canal, conversations.info confirma participação e canal não arquivado |
| Slack webhook | URL HTTPS exata de hooks.slack.com/services; não envia mensagem no preflight |
| Meta leads | EAA, mínimo 100; debug_token com a própria candidata; is_valid, expiração, aplicativo/usuário e quatro escopos da ajuda |
| Meta CAPI / CRM | EAA, mínimo 100; debug_token, is_valid, expiração, aplicativo/usuário e ads_management; não envia conversão |
| LinkedIn | texto de credencial sem JSON/URL; introspectToken com Client ID e Primary Client Secret; ativo, aplicativo, 3L, validade e r_marketing_leadgen_automation |
| Clarity | JWT começando com eyJ e três partes; sem consulta de exportação ao salvar |
| Google Ads webhook | chave sem espaços, igual ao Key do formulário Google Ads; sem chamada ao MCP Google |
| SMTP / webhooks próprios | formato local e ajuda específica; nenhum envio automático para validar |

A introspecção LinkedIn não publica tamanho/prefixo fixo nem normalmente o membro. Não se exige um tamanho inventado de token; o par é conferido remotamente. Se o membro não vier comprovado, a troca exige confirmação e conserva os cursores sem declarar continuidade de identidade pessoal. Tokens compartilhados Core exigem um Client ID único entre as integrações que usam o cliente Core; conexões do plugin LinkedIn continuam sob seu próprio gravador.

Uma rotação de mesma identidade não renova artificialmente a validade das provas existentes. Metadados possuem revisão exata da cifra salva. Leitura de uma revisão diferente oculta a identidade antiga. Credencial sem metadados pode ser identificada pelo botão Verificar credencial salva; falha dessa consulta não substitui a credencial. Identidade antiga não comprovada exige confirmação em uma troca.

A confirmação contém somente prazo e HMAC; não guarda a candidata, não pode ser transferida a outra credencial e não substitui capacidade administrativa, nonce ou revisão. Requests remotos têm host fixo/validado, TLS, zero redirects, timeout e corpo limitados. Erros não exibem o corpo remoto nem mensagens de exceção. A prévia não cria contatos, mensagens, leads ou conversões.

`f3base/credenciais-ler` devolve `credenciais` como lista; cada item traz `nome`, `rotulo`, `ajuda`, `estado`, `identidade` e `verificada_em`. O nome técnico é um valor, não uma chave da resposta, preservando os metadados sob o filtro de segredos do MCP. A entrada secreta de `credenciais-verificar` continua em `credential`, redigida pelo canal.

Referências oficiais consultadas: https://developers.pipedrive.com/docs/api/v1/Users#getCurrentUser ; https://docs.slack.dev/reference/methods/auth.test/ ; https://docs.slack.dev/reference/methods/conversations.info/ ; https://developers.facebook.com/docs/graph-api/reference/debug_token/ ; https://learn.microsoft.com/en-us/linkedin/shared/authentication/token-introspection . Rotas e respostas devem ser revalidadas na homologação comercial; os testes locais usam respostas sintéticas.
