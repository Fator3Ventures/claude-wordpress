# Agentes — Core 1.46.1

1. Leia RELEASE-1.46.1.md e RELEASE-1.46.0.md. Base direta 1.46.0; contrato 8.11.0. Mantenha backups e compare SHA-256 antes de substituir o pacote.
2. WP Super Cache simple, expert e wp-cache-cabecalhos são reconhecidos. Não desative a preservação de cabeçalhos para contornar o defeito anterior.
3. Configure f3base_cache_reaquecimento com ativo, dias_visita e paginas_por_hora usando a revisão vigente. A instalação mantém o valor atual; padrão desligado. O TTL/preload pertence ao provedor e não é modificado pelo Core.
4. Consulte cache-reaquecimento-ler: configuração, ultima_execucao, reservas e resultados. Exija copia_gerada/copia_servida e carimbo; HTTP 200 sem vínculo de conteúdo não é prova de cache.
5. O piloto decidido pelo dono usa 86400 e reaquecimento no Site-Teste e Korvena.net, seguido de quatorze dias. Testes pontuais não encerram essa observação. Não implante em outro site sem a atribuição correspondente.
6. Não use cookie de homologação na requisição de reaquecimento: a tarefa é anônima e o seu User-Agent é excluído da coleta do Core. Ao testar, confira que os contadores de eventos/sessões não cresceram pela tarefa. Não acrescente eventos sintéticos como audiência real para selecionar uma página.
7. Não apague a árvore de cache nem estados alheios para produzir uma prova. Use página pública elegível e conferência delimitada de seu par vencido; recursos temporários devem ser removidos ao final.
