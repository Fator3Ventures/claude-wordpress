# Fator3 Site Core 1.46.1

Patch da mesma rodada, base direta 1.46.0. Contrato 8.11.0 e perfil piso-padrao-3.6 preservados. Complementa o pedido 281; os pedidos 274–283 permanecem conforme RELEASE-1.46.0.md.

## Correção do reaquecimento

A 1.46.0 restringia a execução aos modos simple/expert. No Site-Teste e no perfil da frota, o WP Super Cache preserva cabeçalhos em arquivos wp-cache-*.php e meta-wp-cache-*.php; a tarefa devolvia cache_nao_compativel. A 1.46.1 aceita também wp-cache-cabecalhos e identifica o corpo e os metadados do par anônimo da página.

O coletor lê arquivos como bytes, sem incluir ou executar PHP. Confere prefixo de proteção, caminho confinado, metadados JSON, URI, chave anônima e nome do arquivo. Variantes com cookie, cabeçalhos privados/Set-Cookie, conteúdo dinâmico, links simbólicos e formatos desconhecidos ficam fora da seleção. A chave é compatível com o formato padrão observado no WP Super Cache 3.1.4; filtros de terceiros que alterem a chave exigem prova própria e não são inferidos como anônimos.

Só remove cópias vencidas da página selecionada. Corpo e metadados são comparados por timestamp e SHA-256 antes da remoção; metadados saem primeiro. Cópias comprimidas anônimas vencidas também são removidas. A consulta de aquecimento pede text/html e Accept-Encoding: identity, sem cookies, parâmetros ou redirecionamento. A leitura reconhece gzip para comparar seu corpo quando disponível.

copia_gerada/copia_servida exige que o corpo HTTP corresponda ao SHA-256 do HTML armazenado, retirando o prefixo PHP e descomprimindo gzip quando necessário. HTTP 200 sozinho continua copia_nao_confirmada. A última passagem registra código, modo e quantidade de requisições na ability cache-reaquecimento-ler.

Mantidos: desligado por padrão; visitas humanas recentes; exclusão de testes e automação; teto móvel por hora incluindo falhas; até três requisições por passagem; cron; TTL do provedor; preload desligado; exclusão da coleta do Core. Sem alteração de tabela ou contrato. A ativação do piloto 86400 é configuração explícita do Site-Teste, não efeito da instalação.

## Instalação e operação

Instalação limpa ou atualização direta da 1.46.0, com backup coerente. Confira saúde, documentação e cache-reaquecimento-ler. O histórico de 1.46.0 permanece instalado; as instruções desta correção prevalecem para o reaquecimento. A implantação da frota e observação de quatorze dias continuam com os responsáveis definidos pelo dono.

Para reverter, desligue o reaquecimento, restaure arquivos e banco coerentes com a versão anterior e reconcilie a guarda operacional. Não há migração estrutural nova. Cache de página é regenerável e não substitui backup do conteúdo.
