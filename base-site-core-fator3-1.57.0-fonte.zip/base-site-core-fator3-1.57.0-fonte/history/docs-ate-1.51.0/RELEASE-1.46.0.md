# Fator3 Site Core 1.46.0

Base direta: 1.45.0. Contrato administrativo: 8.11.0. Pedidos core 274–283, incluindo as decisões posteriores de 21/10 às 18:44. Leia também AGENTES-1.46.0.md. Não há migração estrutural de tabela nesta rodada.

## Perfil e escrita — 274 e 275

O perfil padrão agora é piso-padrao-3.6, revisão 2026-10-22-core-1.46.0, com 92 condições. Preserva as 80 condições anteriores, converte os valores esperados para as chaves mensais e acrescenta retenções técnicas: 60 meses, exceto intenções operacionais concluídas, seis. Os perfis históricos continuam consultáveis. O perfil é uma comparação/aplicação administrativa explícita; a atualização do plugin não aplica seus valores em massa.

Configuração persistida com efeito cache_agendado retorna sucesso; a verificação do cache continua pendente. Falha real de persistência ou agendamento continua falha. Não repita a escrita apenas porque o efeito de cache aguarda o executor. Releia a revisão persistida.

## Formulários e privacidade — 277, 279 e 281

Os formulários na página, diálogo, conteúdo fechado e segunda etapa usam três iscas fora da tela: website, input ctodesenvolvimentofator3 sem label/id/placeholder e textarea comentario, rótulo Comentário. Cada recipiente é aria-hidden; os campos têm tabindex=-1 e autocomplete=off. Esses atributos não comprovam o comportamento do preenchimento automático do Android ou Kwai.

Somente website preenchido é aceito com sinal informativo isca_website. Comentário ou a isca sem significado tornam o contato suspeito. Tempo curto é sinal informativo. Ausência de página de origem, cota de envios excedida e token ausente/adulterado tornam o contato suspeito. Os contatos são gravados quando os campos passam pela validação atual. Nome obrigatório, sintaxe do contato, arquivos, origem cruzada e integridade da entrada mantêm suas validações; não há CAPTCHA.

Token com assinatura válida vencido, inclusive de cópia com 25 horas, é aceito com token_vencido. Revisão antiga aceita os campos válidos na definição atual e marca token_revisao_anterior. Token ausente/adulterado não produz 403 por esse motivo: o servidor salva o suspeito. O tempo é não confiável nesses casos. O JavaScript tenta renovar, mas falha de renovação não impede o servidor de classificar. Sem JavaScript, o POST é recebido diretamente; não há página de reenvio por token vencido. A continuação da etapa 2 mantém a autorização vinculada ao contato e sua validade de 30 minutos; mudança compatível da definição usa a validação atual.

O suspeito vê confirmação de recebimento para análise, sem abrir WhatsApp ou liberar conteúdo fechado. Com nome e e-mail ou telefone válido, nasce intenção de aviso no canal configurado, com marca, motivo e link para a tela do contato. O link abre a tela; a confirmação ocorre em POST autenticado. O executor e as cotas do canal continuam aplicáveis. A meta de até dois minutos exige cron e canal operantes e precisa de homologação remota.

Iscas não são campos comerciais. O valor original é cifrado em dados.iscas_privadas; a classificação distingue URL, igual a outro campo e texto livre. O interruptor capturar_valores de f3base_formulario_tentativas controla também esses valores; desligado conserva apenas os metadados. Retenção segue retencao_meses da mesma opção (padrão 60; a configuração existente é preservada). Leitura privada exige f3base_ler_leads, inclusive para administrador. Disponível na tela e em f3base/leads-registros-ler, propriedade iscas. O filtro sinal permite contar/listar isca_website, isca_comentario, isca_ctodesenvolvimentofator3, token_vencido, token_assinatura_invalida_ou_ausente, token_revisao_anterior, tempo_curto, sem_pagina_origem e cota_excedida. Valores expirados deixam de ser legíveis imediatamente e são removidos pela limpeza agendada em lotes.

Valores das iscas não entram nas seções de aviso, webhook, nota/objeto do Pipedrive, e-mail ou eventos publicitários. A eliminação do contato e o pedido do titular removem os dados privados junto ao contato. Tentativas recusadas do pedido 263 continuam sob seu contrato e exclusão por sessão. A limpeza do valor não desfaz um envio comercial anterior que tenha ocorrido antes de uma segunda etapa suspeita.

### Aprovação com entrega

f3base/leads-atualizar recebe record_id, revisao_esperada, alteracoes.captura=aceito, entregar (booleano, padrão false) e simular (padrão true). Exige permissão de gestão de contatos. Simular mostra a intenção e não muda registro, fila ou agenda. Aplicar usa simular=false e a revisão atual. A tela oferece a caixa de entrega; desmarcar aprova sem entregar.

A primeira entrega aprovada grava intenção durável, operador/data/histórico e chave do registro; enfileira CRM e aviso. O e-mail automático segue o fluxo existente depois da confirmação de novo lead no CRM e depende da configuração ativa. Repetir aprovação não duplica as intenções. Registro previamente aprovado sem entregar pode receber a entrega depois. Fila interrompida por suspeita da segunda etapa é retomada preservando checkpoints e incertezas. Exclusão pelo titular não é revertida pela aprovação.

Não são reenviadas conversões de anúncio históricas na aprovação. Em teste, CRM exige homologacao e e-mail exige a caixa autorizada e f3base/email-novo-lead-homologar depois da confirmação do CRM; aprovar não contorna essas proteções. A caixa real e o envio só são exercitados no destino autorizado.

## Pipedrive — 276, 278 e 280

A exclusão de pessoa/organização relê a lista completa de seguidores pelas rotas v2. Desconsidera apenas IDs iguais ao responsável do objeto ou ao usuário da credencial verificada. Outros seguidores, cobertura divergente, edição material ou vínculos externos preservam o objeto. Falha temporária de leitura aguarda; não autoriza exclusão. Provas novas registram hashes por campo e devolvem nomes dos campos divergentes, contagens impeditivas e contagem de seguidores. Prova antiga não é fabricada retroativamente. Documentação de referência: https://developers.pipedrive.com/docs/api/v1/Persons e https://developers.pipedrive.com/docs/api/v1/Organizations.

A nota de entrada inclui até cinco sessões anteriores, da mais recente para a mais antiga, dentro da retenção e das permissões históricas existentes: data/hora local, primeira página sem query/fragmento e canal/parceiro quando disponível. Sem IP, user agent, pseudônimo ou parâmetros de clique nessa seção. Sem histórico, a seção é omitida. Não muda campos de lead/pessoa.

As projeções da fila substituem identificadores de seleção por presente e hash HMAC-SHA256 (sal do site, domínio pipedrive-selecao, papel e valor). A seleção e a reconciliação conservam os valores somente no banco; o hash serve à comparação técnica, não recupera o identificador.

## Reaquecimento opcional — 281

f3base_cache_reaquecimento: ativo=false, dias_visita=7 (1–30), paginas_por_hora=20 (1–100). Configurável na tela e por config-core-escrever. A janela móvel inclui tentativas que falharam. Cron f3base_cache_reaquecer / tarefa reaquecimento executa até três URLs por passagem e reagenda em um minuto; o cron real define o atraso.

Seleciona até mil caminhos recentes em analise, tipo pagina, classe nao_marcado, sem automação identificada; restringe a páginas/posts públicos canônicos e home, sem senha, query, fragmento, caminho técnico ou travessia. Respeita somente o histórico disponível. Requer WP Super Cache simple/expert e prazo observável. Não ativa preload e não modifica cache_max_time.

Depois do vencimento, remove apenas o arquivo HTML expirado e sua cópia gzip no diretório confinado do próprio site, após conferir o timestamp. Faz GET de mesma origem, sem cookie, sem JavaScript, sem redirecionamento nem parâmetros. User agent F3Base-Reaquecimento/1.46.0 é excluído da coleta de acessos do Core; não produz eventos do navegador. Um acesso pode continuar no log bruto do servidor; não é audiência do Core.

f3base/cache-reaquecimento-ler é leitura administrativa, sem HTTP: configuração, reservas, próxima execução e até cem resultados com caminho, horário, status, duração e geração. copia_gerada/copia_servida exige correspondência entre o corpo e o SHA-256 do artefato; HTTP 200 sozinho é copia_nao_confirmada. O reaquecimento não promete cache em página excluída pelo WP Super Cache. A frota aplicará 86400 somente depois da troca, primeiro no Site-Teste e em korvena.net.br, e observará 14 dias. O instalador deixa essa decisão externa intacta.

## Operações — 282

f3base/executar-pendentes agora assume simular=true. A simulação, inclusive reativar_esgotada=true, devolve previsão/revisao, persisted=false e execucao_realizada=false, sem executar callbacks ou mudar cron/intenções. Execução exige simular=false; reativação exige também revisao da simulação. Cron/CLI/painel de execução declaram explicitamente o modo de aplicação.

Para uma espera, simule com tarefas=[id], intencao=chave, reconciliar_esperas=true, simular=true. Se esgotada e coberta por sucesso posterior do módulo, a previsão oferece fechamento sem executar o módulo; aplique com os mesmos parâmetros, simular=false e revisao retornada. Caso contrário, estado_exige_acao_propria contém acao_necessaria com ability e parâmetros da reativação, ou a orientação para operacao-recuperacao em caso de suspensão. Reativação usa comparação de estado/falhas/prazo; conflito exige nova leitura. Nenhuma espera histórica é removida só para ocultar falha.

## Redes oficiais — 283

A coleta segue até dois redirecionamentos 301/302 HTTPS no mesmo host ou entre os equivalentes declarados www.perplexity.com e www.perplexity.ai. Cada requisição continua sob a validação de URL segura do WordPress, sem cookies; não aceita credenciais, outra porta, downgrade para HTTP, ciclo ou host não declarado. O orçamento total por cadeia é seis segundos. Destino recusado permanece em ultima_tentativa.destino_redirecionamento, com o status e seguido=false na cadeia. As fontes do Perplexity conservam a URL .com para exercer o redirecionamento oficial.

Fontes sem prefixos, expiradas ou com tentativa anterior falha voltam à fila, inclusive quando obtida_em é recente. Fontes saudáveis renovam a cada dia. Cada lote tenta duas fontes, prioriza a tentativa mais antiga e continua em dez segundos; falhas aguardam pelo menos uma hora. Uma continuação futura é antecipada quando há fontes prontas, sem deslocar o evento diário das 02:00 do fuso do site. A cadência efetiva depende do cron. O retorno informa saldo/parcial e falha de agendamento, evitando declarar todas as fontes concluídas após apenas um lote.

ultima_tentativa registra em, resultado (atualizada ou fonte_indisponivel_http_<status>/fonte_indisponivel_transporte_<codigo>), codigo estável, http_status, erro_transporte quando houver, url_final e a cadeia de redirecionamentos. JSON inválido com HTTP 200 fica explícito em erro=conteudo_invalido. A última lista válida permanece preservada até o seu prazo. AWS, Google Cloud e Azure fazem parte da mesma fila; sem_lista com tentativa null significa ainda não tentada, não fonte desativada por desenho. Não há reclassificação retroativa dos acessos.

Depois de atualizar fator3.com.br, conferir em agentes-relatorio as duas fontes atuais com obtida_em/valida_ate após a primeira passagem diária e suas continuações. A prova do Site-Teste não altera a versão desse site da frota.

## Instalação e reversão

Atualização direta de 1.45.0 e instalação limpa; backup coerente do banco e guarda operacional antes da troca. Não há tabela/coluna nova: opções de reaquecimento, dados privados/auditoria no contato e diagnóstico técnico no journal. Preserva configurações existentes. Restaurar só arquivos não remove os novos dados nem desfaz mensagens/CRM. Para voltar, pause, restaure arquivos e banco coerentes, reconcilie efeitos externos antes de retomar. Compatibilidade observada: MCP 0.25.0, Google 0.16.0, Meta/LinkedIn 0.4.1. Implantador precisa conferir o perfil e as cópias compartilhadas; Google não exige mudança nesta rodada.
