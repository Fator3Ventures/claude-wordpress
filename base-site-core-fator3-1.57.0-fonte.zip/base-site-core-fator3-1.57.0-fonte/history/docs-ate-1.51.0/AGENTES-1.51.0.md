# Operação da 1.51.0

Base 1.50.0, contrato 8.16.0. Leia RELEASE-1.51.0.md, PIPEDRIVE-OPERACAO.md e CREDENCIAIS-1.51.md.

1. Instale Core antes de Fator3 MCP Pipedrive 0.1.0. O registro não habilita acesso. Consulte schema e revisão de f3base_pipedrive_operacao; autorize somente o provider aprovado no site-porta. Registro de provider não concede automaticamente permissões à conexão MCP.
2. Consulte pipedrive/status para identidade da conta e orçamento. Leituras/escritas de operação exigem manage_options; confirmação de exclusão/estrutura e prévia/aplicação pertencem ao Pipedrive. Core mantém token e transporte.
3. saldo_conta_baixo bloqueia somente operação. pausa_remota decorre do fornecedor e vale também para entregas. Não aumente limites nem apague contadores para contornar a recusa. Saldo desconhecido não comprova disponibilidade.
4. revisao_conflitante/contexto_alterado exige nova prévia. Resultado incerto, timeout ou resposta incompatível não autoriza repetição de escrita. Consulte estado remoto/diário e reconcilie.
5. Use operacao-recuperacao-ler e fluxo de preparar/retomar do Core para restauração. Não sobreponha sentinela ativa. A geração de recuperação participa da revisão do cliente e invalida prévias anteriores.
6. Para 295, use credenciais-verificar com nome, revisao_esperada e usar_salva=true. Avisos de prefixo/tamanho não demonstram token inválido; o fornecedor decide. Não copie o valor salvo, nem peça rotação apenas por esse aviso. Identidade aparece somente quando aceita e vinculada à revisão corrente.
7. Credenciais são preenchidas pelo dono. A confirmação de troca de identidade continua explícita, vinculada à candidata/revisão e com validade de dez minutos. Nenhum token em chat, relatório ou aviso.
8. Homologação comercial exige a conta autorizada e registros identificados de teste, com limpeza. Provas sintéticas não encerram aceite de produção. Responda impactos recebidos no relatório principal; emita novo impacto somente por consequência técnica própria, conforme norma revisão 5.
