# Agentes — Core 1.44.0

Use RELEASE-1.44.0.md, FORMULARIOS-TENTATIVAS-1.44.md e catálogo 8.9.0. Documentação paginada em f3base/documentacao-ler, sem efeitos de execução.

1. Preserve revisões e escolhas; descoberta não autoriza mudar cliente ou importar contatos. LinkedIn externo usa linkedin/admin-options, com concessões separadas por canal.
2. Conversões: simule f3base/conversoes-recuperar. Só confirme uma entrega do navegador/legado com não entrega explicitamente atestada e destino pronto fixado. Nunca repita ingestão incerta; a reconciliação Google 0.16.0 usa recibo original. O código permite tratar registros 113/125, mas não declara que tenham sido executados em produção.
3. Vitals: compare público selecionado e contagens excluídas; legado_desconhecido não equivale a humano. Não corrigir amostras antigas com correspondência aproximada de eventos. Período de 7 dias só é completo depois de coleta suficiente após a implantação.
4. Comparação editorial parcial não é janela integral. Observe dias retidos e definições de sessão antes de atribuir diferenças a perda de dados.
5. Tentativas barradas: leitura de valores exige f3base_ler_leads. Use filtros e paginação; não copie valores para avisos, CRM ou plataformas. Relate somente a informação necessária ao pedido autorizado. Para eliminar, use o fluxo de contatos e confirme ausência por sessão; para titular sem contato, use o eraser de privacidade do WordPress.
6. Saída observada não é abandono comprovado; correção é mudança de validade, não certeza de intenção. Não reconstrua valores históricos ausentes. Verifique valores_estado e valor_truncado.
7. Instalar na frota/publicar exige a autorização aplicável. Suítes sintéticas e Site-Teste não certificam entrega comercial a provedores.
