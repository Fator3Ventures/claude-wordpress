# Agentes — Core 1.45.0

Leia RELEASE-1.45.0.md, RETENCAO-1.45.md, TELEFONE-1.45.md e o schema 8.10.0. Documentação estática paginada em f3base/documentacao-ler, arquivo/linha/limite até 200, SHA-256 e proxima_linha. Permissão administrativa é validada; leitura não consulta fornecedor nem altera configuração.

1. Atualize somente a base direta 1.44.0; preserve estado e faça backup coerente antes da troca. Confirme prontidão e os valores convertidos. Retenções de 60 meses em sites existentes são uma aplicação explícita posterior da frota.
2. Não promova período sem fontes a completo. Prova de dia processado permanece após rotação. Sete dias de estabilidade em ctooffice e classificação na twinia exigem sete dias reais depois da troca.
3. Automação provável não é identidade comprovada. Confira regra, motivo, interação e cobertura. Não mude o passado para satisfazer um aceite.
4. Clarity: consulte modo=resposta e coleta da nova falha. Nunca copie token ou corpo não saneado para relatório. Resposta histórica descartada não é recuperável.
5. Pipedrive: objetos com prova antiga, edição, compartilhamento ou incerteza permanecem com motivo. Teste de exclusão usa contato novo e sintético, destino em homologação autorizado; nunca apague manualmente objeto de equipe para fazer o teste passar.
6. Telefone livre é por campo, desligado por padrão; ctooffice aguarda decisão 111. Use leitura de contatos para o valor e relatório para contagens. Tentativas recusadas seguem a permissão f3base_ler_leads e exclusão por sessão/titular da 1.44.0.
7. Impacto necessário nesta rodada: Implantador, schema mensal e cópias compartilhadas. Não envie avisos de versão sem consequência técnica. Provas locais e Site-Teste não equivalem ao aceite de produção nem autorizam publicação ou instalação na frota.
