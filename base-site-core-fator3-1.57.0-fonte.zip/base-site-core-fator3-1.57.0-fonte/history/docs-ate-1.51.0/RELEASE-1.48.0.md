# Site Core 1.48.0 — pedidos 288, 289 e 290

Base direta 1.47.0; contrato administrativo 8.13.0. Perfil piso-padrao-3.6 preservado. Acompanhantes examinados: MCP 0.28.0, Google 0.17.0, LinkedIn 0.7.0 e Meta 0.6.0.

## 288 — avisos do Slack

`f3base/avisos-slack-listar` lê apenas o inventário local, sem conteúdo pessoal e sem rede. Filtros: record_id, de/ate (Unix UTC inclusivos), teste, estado e tipo. Tipos: contato, suspeito, captacao, teste_conexao; histórico sem contato sobrevivente pode ser desconhecido. `limite` 1–100, cursor opaco `proximo_cursor`. Repita os mesmos filtros ao avançar. Presença aceita_pela_api é recibo histórico, não confirmação de presença atual; ausente inclui data da verificação.

`f3base/avisos-slack-apagar`: id, ids ou filtro; limite 1–50 (padrão 20). A seleção inclui respostas próprias registradas das principais escolhidas. Se ultrapassar o limite, restrinja a seleção; não há exclusão parcial silenciosa da seleção. Simular é true por padrão. Reutilize a revisão retornada, informe chave_operacao e motivo. Mensagens teste=false exigem confirmar_nao_teste=true. A rota de testes aceita os mesmos filtros, sempre restritos a teste=true. A linha local comprova site, destino, workspace, bot e usuário, mesmo após eliminar o contato. A consulta exata confirma autoria antes de chat.delete; não apaga respostas humanas ou mensagens de outro aplicativo. Confirma ausência após o aceite. Resultados individuais: apagada, ausente_antes, nao_propria ou falhou; falha inclui código Slack. Resultado incerto não é ausência confirmada. Outra chamada exige nova prévia/chave; repetir a chave original devolve o resultado registrado.

Depois de apagar, o payload da manutenção e da parte é esvaziado; ficam somente vínculo, identidade técnica e prova canal/ts/data. `leads-eliminar-registro` aceita apagar_slack: padrão true para teste e false para demais contatos. Tenta o Slack antes da eliminação local; falha externa não impede o direito de eliminar os dados locais, e aparece em copias_externas.slack. Lotes maiores que 50 devem ser limpos pela rota dedicada. `leads-marcar-teste` recebe record_id, revisao_esperada, simular e motivo; marca contato e avisos existentes como teste em transação, sem novo envio. Não altera conversões externas já entregues.

## 289 — duas regras LinkedIn

`f3base_linkedin_conversion_id` permanece a regra Insight Tag do navegador. Nova opção `f3base_linkedin_server_conversion_id` indica a regra Direct API / Conversions API. Ambas são IDs públicos, com catálogo, schema, sanitização, procedência e verificação. Localização: Campaign Manager → Mensuração (Measurement) → Acompanhamento de conversões (Conversion tracking). A tela Medição mostra os dois campos. A concessão do MCP LinkedIn deve selecionar a mesma regra de API. Consentimento, classe de tráfego, concessão e vínculo ao destino continuam obrigatórios.

O aceite congela os dois IDs e o instante; navegador e servidor compartilham event_id. Nunca há fallback da regra do servidor para a do navegador. Registro antigo sem server_conversion_id permanece bloqueado; não se reescreve histórico. Vazio gera linkedin_server_regra_ausente na medição e impede envio. A prévia linkedin-conversao-previa informa destinos.navegador, destinos.servidor e payload, inclusive para contato de teste sem entregar. Materiais continuam somente no navegador, portanto não há nova regra de material pelo servidor.

Compatibilidade: PHP capabilities/snapshot/events preservam o SDK fechado site-measurement-context/1.0.0 usado pelo Google 0.17.0. A ability medicao-contexto-ler acrescenta, fora desse SDK, extensoes.linkedin_conversoes com contrato próprio site-linkedin-destinations/1.0.0, IDs, fontes e procedência do servidor. Seu output_schema declara a extensão. A leitura do SDK permanece validada pelo schema original do Google.

## 290 — disputa de ocorrência

Dono é comprovado pelo diário da mesma tarefa/hook/argumentos/instante ou pela reserva de arquivo adquirida, com identidade de passagem. Um competidor registra reserva_ocupada, resultado neutro e sucesso SQL NULL, com dados.dona (run_id, passagem_run_id, origem, ocorrência e estado). Não altera a intenção da dona, não soma falhas e não dispara alerta de falha. Ocorrência já executada também é neutra. Correlação de horário, isoladamente, não muda diagnóstico.

Checkpoint sem confirmação e sem outra dona continua checkpoint_nao_persistido, preservando a causa interna e erro_banco quando disponível. A confirmação pode reconhecer sua própria reserva mesmo se outra tarefa tiver atualizado o restante da opção compartilhada. execucoes-ler e saude-ler incluem disputas separadas, por dia UTC e origem, na janela de 30 dias. Não reclassifica registros históricos.

## Implantação e limites

Instalação normal preserva opções e acrescenta a coluna aviso_tipo e a opção de servidor vazia. Faça backup de arquivos/banco/salts e use o ciclo nativo. Não desinstale para atualizar. Reversão para 1.47.0 preserva dados aditivos, mas volta ao comportamento antigo de ID único; mantenha LinkedIn em navegador até restabelecer uma versão compatível. Exclusões Slack confirmadas são irreversíveis.

A limpeza dos avisos antigos de CTO Office, a conversão real após concessão rw_conversions e a observação de sete dias na frota dependem da implantação nos respectivos sites. O relatório externo registra o que foi efetivamente homologado, sem confundir transporte simulado com envio comercial.
