# Versão atual: 1.49.1

Consulte [RELEASE-1.52.0.md](RELEASE-1.52.0.md) e [AGENTES-1.52.0.md](AGENTES-1.52.0.md). Base direta: [RELEASE-1.52.0.md](RELEASE-1.52.0.md).
