# Fator3 Site Core 1.45.0

Base direta: 1.44.0. Contrato administrativo: 8.10.0. Pedidos 264–270, 272 e 273 do arquivo Fator3 Site Core(20261021-172554).md. O pedido 263 permanece incorporado da base; seu prazo é atualizado pela decisão posterior 272. A implantação na frota e o aceite de sete dias são posteriores à entrega.

## Logs e audiência — 264–266, 268

A coleta aceita access.log.AAAA-MM-DD.gz e o arquivo sem compressão como a mesma fonte lógica; quando ambos existem, prefere o original. Confere integridade zlib, término e tamanho, rejeitando arquivo truncado, CRC incorreto e membros concatenados. Limites de 96 MiB comprimidos/descomprimidos e prazo de execução mantêm a coleta limitada. A prova diária registra fontes, linhas, offsets, SHA-256 e tamanhos do conteúdo, além da regra e do fuso. Após processamento completo, compressão e remoção não rebaixam a prova; alteração observada do conteúdo invalida a prova anterior. Nunca inventa completude para fontes que já estavam ausentes.

Cobertura: processado_completo; fonte_ausente_desde_inicio; fonte_comprimida_ou_rotacionada_apos_processamento. Evidência antiga sem prova é identificada separadamente. A migração do hash retira somente os parâmetros de retenção, preservando a classificação anterior quando os demais parâmetros coincidem. Mudar o prazo de guarda não invalida a prova de processamento. A exclusão pela retenção continua aplicável.

Linhas editoriais nascidas de acesso de IA preferem o caminho canônico do catálogo, inclusive quando o log conserva /@post-ID. Todo agente com rede fora_das_faixas usa automacao-suspeita sob a regra explícita rede-efetiva-2; a classificação declarada e a evidência bruta continuam disponíveis. Não há regravação silenciosa das observações históricas.

A regra automacao-1.45.0-1 captura evidência mínima da rede publicada AWS/Google Cloud/Azure e família/versão do navegador. Não persiste o IP nessa evidência. Usa origem direta ou proxy previamente configurado e confiável. Faixas vêm de fontes HTTPS oficiais, com validação CIDR, hash, versão e validade; indisponibilidade não é prova de nuvem. Não utiliza DNS reverso. Cortes explícitos desta regra: Firefox até 109, Chrome até 119, Safari até 16.

O executor editorial avalia sessões novas após 30 minutos, até 100 páginas por passagem, nos últimos oito dias. Classifica nuvem + versão antiga + ausência de interação, ou repetição do mesmo caminho e hora em dias consecutivos, pelo mesmo identificador pseudônimo e navegador. Registra o motivo. Nuvem ou navegador antigo isolados não bastam. Interação posterior retira essa inferência; declarações e motivos headless/webdriver são preservados. Não infere identidade entre cookies diferentes. A classificação é provável, não uma prova de robô. Dias alterados são marcados para recomposição editorial.

A rota analise registra exceção/código no log do pacote e última falha 500 na saúde, sem registrar o corpo enviado. Entrada inválida permanece 400. Fatal da requisição registra código e local técnico, sem valores de formulário. medicao-saude-ler alerta sequências de pelo menos dois dias fechados sem_sinais_de_consumo, mesmo com pouco tráfego.

## Clarity — 267

Falha HTTP passa a conservar erro_http no metadado da coleta: corpo saneado até 1.024 bytes UTF-8, indicador de truncamento, Retry-After numérico ou data GMT válida e versão do saneamento. Remove credencial conhecida, chaves sensíveis, Bearer, e-mail e IPv4; não é uma cópia integral da resposta. f3base/clarity-ler com modo=resposta e coleta retorna esse diagnóstico, com manage_options. Falhas anteriores sem corpo não são recuperáveis. A coleta de teste com resposta simulada não comprova a próxima falha do fornecedor real.

## Pipedrive — 269–270

Editor usa as chaves realmente consumidas: canais meta_ads/google_ads/linkedin_ads/openai_ads/meta/nao_identificada; pontos site/whatsapp_formulario/nativo/conteudo; parceiros por plataforma meta_ads/google_ads/linkedin_ads/openai_ads. Títulos e nomes são legíveis. Chave desconhecida salva recebe mensagem própria; novas gravações com chave não consumida são recusadas. Migração de retenção pode preservar uma chave antiga sem autorizá-la para novas gravações.

Prova de autoria versão nova compara campos materiais do objeto e exclui update_time, tolerando as alterações de timestamps provocadas por notas e atividades do próprio Core. Edição material, vínculo externo, ausência de prova ou resultado incerto preservam o objeto com motivo próprio. Organização criada pelo Core só é removida depois dos dependentes e da confirmação de inexistência de outras pessoas, negócios, leads, notas ou atividades. Prova antiga não é promovida retroativamente. Use registro de teste criado após a atualização para o aceite remoto.

## Guarda e telefone — 272–273

Leia RETENCAO-1.45.md e TELEFONE-1.45.md. Retenções operáveis passam a meses, de 1 a 120; padrão de 60 em instalação nova, operações concluídas em seis. Migração mantém autoria e registra a conversão. Não aplica 60 meses em massa aos sites existentes.

## Instalação, banco e recuperação

Migração aditiva: analise.automacao_evidencia e telefone_estado nos diários conversoes_servidor/capi_fila. Estrutura CAPI 4. Configurações novas: f3base_retencoes_tecnicas e f3base_converter_contato_sem_identificador. Renomes mensais e formulário.formato_livre estão no schema 8.10.0. Snapshot de backup deve conter opções, procedência, complementações, todas as tabelas Core e guardas operacionais; não expor seu conteúdo.

Retornar apenas os arquivos à 1.44.0 não desfaz os renomes mensais e pode mudar a interpretação dos prazos. Para reversão, mantenha operações pausadas, restaure o banco anterior coerente com os arquivos e reconcilie efeitos externos antes de retomar. Não reenvie resultado incerto. Uninstall e exclusão de contatos mantêm os contratos existentes; tentativas recusadas continuam cifradas e restritas ao WordPress.

Convivência examinada: MCP 0.25.0, Google 0.16.0, Meta 0.4.1 e LinkedIn 0.4.1. Nenhum desses pacotes foi alterado. Implantador precisa consumir o schema mensal e conferir suas cópias de formulário; o encaminhamento da entrega contém os arquivos e hashes. Não há ação nova requerida do MCP Google.
