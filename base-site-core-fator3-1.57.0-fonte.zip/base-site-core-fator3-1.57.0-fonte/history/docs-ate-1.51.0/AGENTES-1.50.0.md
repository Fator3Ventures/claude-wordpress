# Operação da 1.50.0

Base 1.49.1, contrato 8.15.0. Leia RELEASE-1.50.0.md e CREDENCIAIS-1.50.md.

1. Credenciais são preenchidas pelo dono. Nunca copiar valores para relatório, chat, Slack, webhook, e-mail ou evidências. Para consulta da candidata, `credenciais-verificar` recebe nome, credential e revisao_esperada. Não interpretar uma prévia como gravação.
2. Para identificar a credencial existente sem trocá-la: `credenciais-verificar` com nome, revisao_esperada e usar_salva=true. Faz leitura no fornecedor e salva somente metadados locais. Não usar a verificação como teste de envio ou de catálogo.
3. `confirmacao_identidade_necessaria` traz anterior, identidade e confirmacao. Apresente as identidades ao dono; após confirmação explícita, passe o valor opaco em `config-core-escrever.confirmacao_identidade`, com a mesma candidata e revisão. Não confirmar automaticamente só para vencer a recusa.
4. A confirmação expira em dez minutos e não vale para outro usuário, site, valor ou configuração. Leia novamente em conflito. `credencial_salva_identidade_pendente` significa persisted=true: use a verificação da salva, sem repetir a troca.
5. Para 292, examine dados.persistencia e as contagens por dia/origem. `checkpoint_superado` tem prova vinculada à conclusão posterior; não é uma falha remanescente nem um novo sucesso de callback. Não limpar o histórico para zerar contagens.
6. O aceite de sete dias no CTOoffice é posterior à distribuição. Não declarar aceite de produção com base em fixtures de homologação.
7. Não existe nova exigência de código aos acompanhantes. Não alterar seus relatórios recebidos ou as abas centrais de pedidos.
