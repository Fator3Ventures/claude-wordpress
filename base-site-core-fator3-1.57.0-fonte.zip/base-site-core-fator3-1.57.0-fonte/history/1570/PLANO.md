# Plano Core 1.57.0
Base 1.56.0. Normas revisão 5, 23/10/2026. Pedidos 312 e 313.

312: outbox cifrado antes da remoção local; chamada pública Meta fora de transação; recibo mínimo, retomada administrativa pela exclusão existente; lacuna histórica sem alvo visível.
313: consumidor ga4-reader/1.0.0, configuração explícita, coleta diária e retroativa em recortes separados, armazenamento de fotografias paginadas com publicação atômica, lacunas, reconsulta, qualidade e cota; consultas/exportação/comparação local sem somar usuários entre dias ou fontes; retenção GA4 zero por padrão.

Fronteiras: Meta 0.12.0 e Google 0.20.0 já entregam contratos necessários. Corrigir callback GSC no Core para ignorar contratos alheios. MCP 0.33.0, LinkedIn 0.11.0 e Pipedrive 0.2.0 preservados. Nenhum impacto técnico novo ao acompanhante identificado no planejamento; atendimento dos impactos recebidos ficará no relatório principal, sem reemissão.

Validação: testes WordPress com SDK original e respostas controladas, falhas/retomada/limites/permissões, instalação limpa e upgrade direto, documentação, Site-Teste; dados reais Google dependem da concessão/credencial disponível. Nenhuma implantação na frota.
