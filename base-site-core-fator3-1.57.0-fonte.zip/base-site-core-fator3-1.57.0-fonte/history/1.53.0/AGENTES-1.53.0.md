# Agentes — Core 1.53.0

Leia NORMA-01 e NORMA-02, DOCUMENTACAO.md, RELEASE-1.53.0.md e todo o índice de documentacao-ler com paginação. Contrato 8.18.0 aditivo, 151 abilities. Pacotes considerados e provas ficam no relatório externo.

Para 299, simule email-legado-limpar, examine divergências por nome e aplique somente revisão atual. A diferença de ativo na raiz antiga é esperada. Não forje marcador de migração nem apague conteúdo divergente.

Para 300, siga EMAIL-SITE-1.53.md. O dono prepara caixa e senha pela tela. Não registrar senha/corpos em relatórios públicos. Envio explícito por record_id, revisão e capability f3base_enviar_email; resultado SMTP incerto exige reconciliação, nunca retry cego. Reprocessamento histórico e reativação de restauração são decisões explícitas. Pipedrive comercial real só nos sites autorizados pelo dono; laboratório Site-Teste bloqueia fornecedores.

Para 301, FORMULARIOS-SINAIS-1.53.md é a regra atual: quarta isca, preservadas as três anteriores; opções por site. Em CTO Office, aplicar as duas supressões somente depois da versão que expõe a option e reler; nos demais sites manter defaults. Não confundir inspeção de atributos HTML com teste real de autopreenchimento.

Fonte, instalador e relatório são entrega do pacote; publicação em GitHub/frota depende da decisão do dono. Impactos novos constam nos documentos externos MCP/Pipedrive; o Core não espera resposta para implementar seu lado. Não reabrir como demanda o mascaramento de contadores já corrigido pelo MCP 0.31.0.
