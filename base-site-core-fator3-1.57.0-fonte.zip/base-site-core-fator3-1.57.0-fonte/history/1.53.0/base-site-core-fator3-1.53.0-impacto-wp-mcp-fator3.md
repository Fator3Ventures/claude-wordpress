# Impacto do Core 1.53.0 em wp-mcp-fator3

Revisão 2 · 25/10/2026 · America/Sao_Paulo · etapa: entrega.
Situação: aberto · Classificação: validacao-coordenada, com ação de redação descrita abaixo.
Emissor: base-site-core-fator3, base 1.52.1, alvo entregue 1.53.0; contrato administrativo 8.18.0.
Destinatário examinado: wp-mcp-fator3 0.31.0.
Pedidos vinculados: Core 300 e 301 atualizado. Responsável pelas ações no canal: mantenedor do MCP.

Instalador Core: base-site-core-fator3-1.53.0-instalador.zip, 2574091 bytes, SHA-256 `086adf2530809c73d30d38ccb747b0a8de8c7cd7419543273c2e2c50940d99f1`.
Instalador MCP examinado: 883088 bytes, SHA-256 `2285c633b5d11c9990bed376f17291612b44958b073e0db2489efac20c1ec4ef`.

## 1. Redação indevida da política de sinais

Core publica `f3base_formularios_sinais`, objeto por nome de sinal com dois booleanos obrigatórios: `suspeito` e `aviso`. Em `f3base/como-usar`, assunto `avisos`, a projeção `sinais_formularios.regras` contém `token_vencido`, `token_revisao_anterior` e `token_assinatura_invalida_ou_ausente`. São nomes de regras, sem material de autenticação. O MCP 0.31.0 mascara seus objetos inteiros como `[redigido]` por conterem token na chave.

Consequência: a leitura do objeto canônico não permite conferir todas as regras. Core já entrega a alternativa aditiva `sinais_formularios.linhas:[{sinal,suspeito,aviso}]`; essa lista permanece íntegra no canal atual, junto da revisão e das contagens de 7/30 dias. A escrita continua pelo contrato existente `f3base/config-core-escrever`, com simulação e `revisao_esperada`. Core não espera nova versão do MCP para operar.

Ação pedida: avaliar exceção estreita e tipada para os caminhos dessa política, preservando exclusivamente os objetos de dois booleanos; continuar redigindo strings, tokens reais, objetos com chaves extras e qualquer outro caminho sensível. O mesmo cuidado vale à leitura de configuração e às duas representações da resposta. Não liberar genericamente nomes contendo token.

Aceite: política completa por `regras` e `linhas`, booleanos sem coerção, senha `f3base_email_site_senha` e tokens reais redigidos; formas inválidas não liberadas. A lista alternativa é compatível e deve continuar existindo.

Provas Core: `evidence/1530/request-301-mcp.json` (quatro verificações usando o SafeOutput original); `site1530PolicyRead.json` confirma o comportamento no conector real do Site-Teste. Cenário e schema instalados em `docs/FORMULARIOS-SINAIS-1.53.md` e `docs/dados/`.

## 2. Novas operações de correio e permissões de domínio

O catálogo Core passa a 151 abilities. Novas: `f3base/email-caixa-verificar`, `email-caixa-consultar`, `email-registros-ler`, `email-reprocessar` e `email-enviar`. Consultar os schemas efetivos; consulta/reprocessamento/envio mutáveis usam simulação e revisão. O envio recebe `record_id`, assunto e texto; não admite destinatário livre. Senha só é gravada pela tela do Core e permanece cifrada/redigida.

`email-enviar` exige `f3base_enviar_email` e `f3base_ler_leads`, inclusive quando o usuário possui `manage_options`. Core atribui sua capacidade ao administrador na instalação. O perfil Manutenção do MCP permite a operação no canal, mas não substitui nem concede a capacidade WordPress. A proposta preliminar de “incluir capacidade no perfil” fica esclarecida por esta distinção: não se pede atribuição automática de capacidades pelo MCP.

Validação coordenada pedida: descoberta e execução pelos perfis autorizados, recusa sem capacidade própria, leitura de mensagens somente com capacidade de leads, revisão da simulação preservada e recibo de envio incerto sem repetição automática. Evitar registrar corpos e destinatários em logs públicos. Verificar o encaminhamento do código de domínio, não tratar `success:false` como envio concluído.

Provas Core: suíte `request-300-state` recusa administrador sem a capacidade; Site-Teste transporta a nova ability e uma simulação com identificador inexistente termina `contato_nao_elegivel`, sem SMTP. Prova de envio ao provedor permanece pendente de caixa própria configurada. Não foi alterado o pacote MCP nem sua política de conexões.

## Compatibilidade e sequência

Core 1.53.0 opera com MCP 0.31.0 usando a lista `linhas`; sem dependência global de nova versão. A conta de correio começa desligada. Acompanhantes Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1 e Pipedrive 0.1.0 conservam contratos próprios. Correção no canal deve ser testada sem reduzir os gates do Core nem alterar a redação geral.

Histórico: revisão 1 no planejamento previa validação do correio; revisão 2 documenta as operações reais, esclarece capacidade versus perfil e acrescenta o caso de redação confirmado. O encerramento do impacto anterior de contadores 1.52.1 está no relatório principal da entrega, conforme a norma comum revisão 5; não constitui nova demanda neste documento.
