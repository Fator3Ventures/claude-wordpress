# Fator3 Site Core 1.53.0

Base direta 1.52.1; contrato administrativo 8.18.0, aditivo; 151 abilities. Requer WordPress 7.1.2, PHP 8.3.6 de 64 bits. Identidade base-site-core-fator3/base-site-core-fator3.php. Ciclo preservado em 17 etapas; tabela de correio criada na etapa de integrações. Não há migração de senha nem ativação automática da caixa.

Pacotes examinados: MCP 0.31.0, Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1 e Pipedrive 0.1.0. Contrato pipedrive-api-client/1.0.0 preservado. credenciais-ler e credenciais-verificar incluem o segredo novo sem expor o valor.

## 299 — limpeza do correio legado

email-legado-limpar ignora somente ativo na raiz de f3base_c0 e compara os demais campos por chave, independentemente da ordem. Conteúdo divergente continua impedindo a limpeza; a resposta informa nomes de campos, nunca valores. Simulação, revisão, trava e comparação da tabela antiga continuam obrigatórias. Não apaga resíduos durante a atualização.

## 300 — e-mail por site

Configuração f3base_email_site e segredo cifrado f3base_email_site_senha. Importação e envio começam desligados. IMAP TLS em PHP puro, sem ext-imap; parser zbateson/mail-mime-parser 4.0.7 e dependências sob F3BaseEmailVendor. Leia EMAIL-SITE-1.53.md e DEPENDENCIAS-EMAIL-1.53.md.

Novas abilities: email-caixa-verificar, email-caixa-consultar, email-registros-ler, email-reprocessar e email-enviar. Prévia e envio exigem capacidades próprias e contato local. O envio real exige revisão, reserva de cota compartilhada e recibo durável antes do SMTP. Resultado incerto não é repetido automaticamente; falha da cópia IMAP não repete o envio.

Correio recebido é registrado sem inferir empresa, sem resposta automática e sem conversão de anúncios. Assunto/texto cifrados e limitados, anexos só por nomes. Mensagens da mesma conversa atualizam o contato e têm intenção própria de aviso/nota. Classificação suspeita impede CRM até aprovação. A seleção de lead/negócio aberto confere a unidade do site e relê a oportunidade antes da nota; vale também para formulário e lead nativo. Unidade ausente exige revisão da configuração; oportunidade de outra unidade dá origem a novo lead da unidade correta. IDs 168/85/51 são exemplos da conta, nunca constantes do runtime.

## 301 — quarta isca e política de avisos

Mantidas as três iscas; acrescentada Segmento de atuação, name segmento_atuacao, ID exclusivo f3base-segmento-N e sinal isca_segmento_atuacao. Campo ausente em página em cache não é erro. Formulário, diálogo e etapa 2 compartilham a renderização e aceitam a chave.

Option f3base_formularios_sinais: uma linha por sinal, com suspeito e aviso. Basta um sinal habilitado para suspeita; basta um dos sinais que causou suspeita com aviso ligado para permitir aviso. Nome e e-mail ou telefone válido continuam obrigatórios para avisar um suspeito. Supressão impede Slack e e-mail de contingência e grava a decisão. como-usar assunto avisos apresenta regras, revisão e contagens de 7/30 dias. Detalhes e defaults em FORMULARIOS-SINAIS-1.53.md.

O pacote não aplica a preferência específica de CTO Office aos demais sites. Depois da instalação, a frota grava isca_segmento_atuacao e isca_ctodesenvolvimentofator3 com suspeito=true e aviso=false, simula, aplica com revisão e relê. Os demais sinais ficam no padrão.

## Limites e homologação

Não há valor HTML padronizado que garanta ausência de autopreenchimento em todo navegador. Esta implementação usa autocomplete=off, nomes sem os termos pessoais do pedido e hints de exclusão de gerenciadores. Isso não comprova o aceite de Chrome/Edge desktop e Android, Safari macOS/iOS, Firefox, Samsung Internet, navegadores internos Instagram/Facebook/Kwai e gerenciador de senhas. A matriz real é pendente até execução nos aparelhos correspondentes; não usar testes de atributos como prova de comportamento.

A caixa real requer criação/credencial pelo dono, authserv_ids conferidos e homologação com caixas controladas. Provas com transporte simulado não comprovam recebimento, cópia remota ou entrega comercial. Consulte o relatório externo para testes efetivamente executados e pendências. Documentação é local e não faz chamadas de fornecedor.
