# Site Core 1.48.0 — escopo autorizado
Base direta 1.47.0. Pedidos 288, 289 e 290 do anexo de 22/10/2026.

1. Gestão local dos avisos Slack, remoção somente de mensagens com prova de autoria, simulação e revisão, classificação posterior como teste e integração à eliminação. Preservar respostas humanas.
2. ID LinkedIn próprio para CONVERSIONS_API; nunca reutilizar o ID Insight Tag. Mesmo event_id. Expor IDs e procedência na extensão administrativa, mantendo o SDK site-measurement-context/1.0.0 usado pelo Google. Material continua somente no navegador.
3. Classificar disputa de ocorrência com prova de dono como reserva_ocupada neutra. Falha real de checkpoint continua falha, com diagnóstico do banco. Contagem separada por dia/origem.

Acompanhantes: MCP 0.28.0, Google 0.17.0, LinkedIn 0.7.0 e Meta 0.6.0. Não serão modificados. Testar com transporte externo interceptado, instalação limpa e upgrade direto, e homologação no Site-Teste. Publicação na frota e observação de sete dias ficam fora desta execução.

Encaminhamento pertinente: `base-site-core-fator3-1.48.0-impacto-wp-mcp-linkedin-fator3.md`, aberto no planejamento e atualizado na entrega. Nenhuma ação de código exigida nos outros acompanhantes nas interfaces examinadas.
