# Agentes — Core 1.54.0

Leia DOCUMENTACAO.md, RELEASE-1.54.0.md, CONTATOS-EXTERNOS-1.54.md e os schemas gerados. Descubra as abilities e confira schemas efetivos antes de executar. Contrato administrativo 8.19.0; cliente Pipedrive público preservado.

O registro externo e o vínculo manual pertencem ao Core. Não escreva nas tabelas, não edite eventos nem transforme uma decisão manual em atribuição observada. A simulação é padrão. O registro requer idempotency_key; pelo MCP use chaves diferentes para prévia e gravação, repetindo a chave de gravação apenas com o mesmo conteúdo. A rota de vínculo exige a revisão retornada pela prévia para gravar e registra executor e decisor separadamente.

Nunca confunda o telefone receptor do WhatsApp da empresa com o telefone do contato. Use apenas identidade informada ou confirmada no registro de origem. Vincular lead existente faz GET e guarda a referência; não cria lead, nota ou atividade. Sem Slack, e-mail automático ou conversão. Entrega nova ao CRM requer ação entregar e chave já configurada em mapa_pontos.

lead-jornada-ler separa origem declarada, jornada observada e atribuições manuais. Sessões não são identidades verificadas. A auditoria fica cifrada no contato. Apagar o contato apaga os vínculos e a auditoria; repetição da chave de registro não ressuscita o contato. O vínculo a lead preexistente não autoriza exclusão desse lead remoto.

Capacidades de e-mail são exigidas também pelo permission_callback; manage_options não substitui f3base_ler_leads nem f3base_enviar_email. O perfil da conexão MCP ainda pode restringir ações. Não use operações genéricas de plano para persistir entradas pessoais; execute diretamente as abilities do domínio.

Homologação usa contatos sintéticos em ambiente isolado. Artefatos destinados ao dono não contêm dados pessoais reais nem credenciais. Implantação da frota segue as normas do projeto, com SHA-256 e expected_slug.
