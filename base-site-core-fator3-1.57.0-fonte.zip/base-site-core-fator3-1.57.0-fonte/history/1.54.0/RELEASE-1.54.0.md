# Core 1.54.0 — pedido 302 e permissões MCP

Data da implementação: 26/10/2026 UTC (pedido de 25/10). Base direta 1.53.0; contrato administrativo 8.19.0; pipedrive-api-client/1.0.0 preservado. Slug e basename inalterados. Sem nova dependência de plugin.

- contato-externo-registrar: entrada externa cifrada, simulação padrão e chave idempotente. Entrega ao Pipedrive opcional com mapa_pontos ou referência a lead existente, sem criação duplicada. Nenhum aviso, e-mail automático ou conversão.
- contato-sessao-vincular: lote de até 20 sessões, revisão obrigatória para gravar, atribuição manual auditada e reversível. Separação de testes; rejeita sessão desconhecida e vínculo a outro contato. Índice aditivo f3base_contato_sessoes, sem dados pessoais.
- lead-jornada-ler e sessao-detalhar mostram vínculos manuais separadamente. conteudos-relatorio e aquisicao-relatorio filtram tipo_atribuicao: todas, observada, atribuicao_manual. Preservam os canais e conteúdos observados; não inventam conversões retroativas. Filtro também disponível na tela Medição.
- Exclusão do contato remove índice, payload cifrado e auditoria; tombstone impede recriação pela chave anterior. E-mail exato usa índice HMAC para exportação/exclusão nativas de privacidade. Nome/telefone não são indexados em texto.
- Devolutiva MCP 0.32.0: permission_callback de email-enviar exige f3base_enviar_email e f3base_ler_leads; email-registros-ler exige f3base_ler_leads; email-caixa-consultar e email-reprocessar exigem manage_options e f3base_ler_leads; email-caixa-verificar exige manage_options. Handlers conservam as mesmas guardas. Repetições do canal após revogação não devolvem prévia privada nem recibo incerto.
- Correção anterior do MCP: objetos tipados token_* da política de formulários preservados pelo 0.32.0. Nenhuma alteração no runtime MCP nesta entrega; conclusão no relatório principal.

Documentação: CONTATOS-EXTERNOS-1.54.md, EMAIL-SITE-1.53.md, dados/abilities-*.json e dados/contrato.json. Evidências e status da homologação constam no relatório externo final; os testes não enviam mensagens reais.
