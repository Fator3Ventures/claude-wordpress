# Agentes — Core 1.55.0

Leia DOCUMENTACAO.md, RELEASE-1.55.0.md, OPERACAO-1.55.md e os schemas gerados. Descubra schemas efetivos antes de executar. Contrato administrativo 8.20.0. O MCP 0.33.0 transporta as abilities do Core; não requer alteração própria para estes pedidos.

Use config-core-ler/config-core-escrever com nome, valor e revisão vigente. f3base_sessao_admin_dias altera somente novos logins administrativos lembrados. Não troque a política antiga dos demais usuários para fabricar o aceite de 14 dias. Não converta duração declarada em prova de sessão real: confira cookie e token nativos e a tolerância física de 12 horas.

email-caixa-verificar simula por padrão; simular:false cria pastas IMAP faltantes, sem importar/mover e sem alterar cursor. Nome curto é resolvido pelo namespace; não concatene INBOX duas vezes. email-caixa-consultar requer manage_options e f3base_ler_leads, simula por padrão e exige revisão ao aplicar. Nunca ative importação histórica por acidente. INTERNALDATE é comparada como instante com ativado_em; o cursor UID não volta ao repetir DNS pendente.

Autenticação não é inferida de marca comercial, assunto ou nome do remetente. Confie apenas no authserv configurado ou na verificação criptográfica/envelope. MX é padrão de hostname da cadeia inicial de Received; um cabeçalho inferior forjado não vira origem confiável. DNS temporário deixa a mensagem em autenticacao_pendente, na INBOX, com texto cifrado, sem contato/CRM/aviso até nova verificação. Se sumir da INBOX, autenticacao_ausente exige investigação; não aceite o snapshot sem validar a mensagem bruta.

Teste pelo assunto [TESTE F3BASE] ou remetentes_teste. Isso identifica teste, não autentica a mensagem. As políticas de Testes continuam governando entregas; Slack é suprimido por padrão, marcar usa destino configurado e permite avisos-slack-testes-apagar. Pipedrive de teste depende de homologacao. Não habilite destinos ou envie mensagens comerciais para realizar prova. Provas de Pipedrive reais pertencem aos sites autorizados pelo dono, nunca ao Site-Teste.

Em saude-ler, agenda.cache/robots expõe ultima_execucao.motivo, ultimo_sucesso e prova_publica. Agendado ou executado_sem_confirmacao não é sucesso; uma prova antiga não confirma uma passagem nova. Acompanhe 24 horas na frota somente após publicação autorizada.

Contatos externos e atribuição manual mantêm CONTATOS-EXTERNOS-1.54.md. Não repita o caso Marcela já aceito pela frota. Não escreva nas tabelas nem altere eventos para ligar sessões. Simulação, idempotência, revisão e dados cifrados continuam obrigatórios. Artefatos e relatórios não incluem credenciais ou mensagens privadas reais.
