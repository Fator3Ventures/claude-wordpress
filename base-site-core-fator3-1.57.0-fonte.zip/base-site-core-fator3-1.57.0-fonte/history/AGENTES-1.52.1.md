# Guia de agentes — Core 1.52.1

1. Leia f3base/como-usar e o índice f3base/documentacao-ler {}. Guia atual em docs/RELEASE-1.52.1.md; contrato administrativo 8.17.0.
2. Para cada documento do índice, use arquivo, linha=1, limite até 200. Continue proxima_linha até null; confira o mesmo SHA-256 em todas as páginas. A documentação exige manage_options, não consulta fornecedores e não expõe configuração efetiva. Paths fora da lista, travessias, arquivos arbitrários e symlinks são recusados.
3. Consulte schema real das abilities antes de invocar. f3base/como-usar aceita assuntos como lista, não assunto singular. A leitura distingue configuração local, fila, diagnóstico e prova externa.
4. Mudanças de configuração usam config-core-ler e config-core-escrever com revisão/procedência. Credenciais: credenciais-ler/credenciais-verificar/credenciais-escrever. Não leia segredos para preencher relatórios.
5. Após atualizar 1.51.0, confira atualizacao concluída sem falhas. email_migracao_142_pendente requer resolver migração na base; não force marca, não apague configuração para ativar.
6. Limpeza: email-legado-limpar {simular:true}; conferir presença e conteúdo_confirmado, guardar revisao; aplicar {simular:false,revisao:<retornada>}; conferir releitura sem resíduos. Dados divergentes permanecem. Somente operador administrador; manter backup normal antes da exclusão.
7. Acessos: ler acessos_servidor em como-usar. Modo por_caminho é alternativa normal quando mapa não cabe. Falha mantém fonte pendente e próxima tentativa; não interpretar erro como zero acessos.
8. Captação: captacao_meta mostra duas passagens perdidas/três falhas de transporte. Não reenvie e-mail operacional nem reagende tarefa com resultado incerto. Consulte execucoes-ler e executar-pendentes simulado; prioridade não ignora pausa/quotas.
9. Pipedrive: Core guarda token, orçamento e conta. Plugin Pipedrive recebe cliente registrado, sem autorização automática. Não habilite operação como efeito da atualização; preserve entregas do site.
10. Não encerrar editorialmente pedidos da frota nem publicar pacotes sem atribuição. Fonte tem o histórico fora do instalador; informe limites de teste, fornecedor e observação posterior.
