# Plano — Core 1.56.0

Base final Core 1.55.0 (instalador SHA-256 1d7e54fb86ea4c61de5e58df22e81b5e93aad3018bc5802fb3fd86ff48dd41a0); alvo 1.56.0 ainda não empacotado. Normas revisão 5 preservadas, prevalecendo sobre anexos antigos revisão 4. Meta recebido 0.11.1, MCP 0.33.0; Site-Teste confirma ambos com Core 1.55.0.

307: decisão explícita de aprovação sem entrega, histórico e projeção histórica sem regravação. 308: móvel brasileiro de oito dígitos/DDD válido, sem inserir nono dígito, classificação documentada. 309: ingestão incremental Slack/Twinia opt-in, esquema verificável, política por canal/número, dedupe durável, testes/equipe excluídos, código de origem e trecho mínimo cifrado, sem conversões. 310: notas relevantes instaladas e índice mudancas.json coerente. 311: default SMTP 587/tls, prova sem DATA por fase, vínculo à configuração/credencial atual e guarda na ativação.

Impacto Meta recebido revisão 3: implementar consumidor opcional instagram-first-message/1.0.0, separado da entrada WhatsApp. Core mantém política, dedupe/recibo/tombstone e nenhuma inferência de sessão/UTM/consentimento. Lacuna identificada no SDK: não há exclusão coordenada de metadados já entregues; novo encaminhamento técnico específico ao Meta será preparado. Nenhum código de acompanhante será alterado.

Testes: positivos/negativos, revisão, repetição, interrupção, privacidade, versões mínima/atual, instalação limpa e upgrade direto, contratos MCP/Meta e documentação integral. Site-Teste com prefixo privado e sondas reais disponíveis; envios comerciais/frota não autorizados por esta entrega. Dados de contato reais não entram nas fixtures/artefatos.
