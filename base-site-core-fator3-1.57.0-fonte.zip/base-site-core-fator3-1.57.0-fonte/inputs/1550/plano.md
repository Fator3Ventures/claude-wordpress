# Core 1.55.0 — plano da rodada

Base final 1.54.0; MCP original 0.33.0. Normas revisão 5 (23/10/2026), preservadas da base e confirmadas no relatório MCP; cópias antigas de projeto revisão 4 não as substituem.

Escopo: 303 sessão administrativa de 1–365 dias (365 padrão), somente lembrar-me/manage_options; 304 autenticação própria DKIM/SPF/DMARC com DNS temporariamente indisponível tratado sem descarte e com nova tentativa; 305 namespace/pastas IMAP, coleta por UID e INTERNALDATE, classificação explícita de teste; 306 confirmação dos callbacks de cache/robots, motivo de ausência e prova pública na saúde.

Diagnóstico inicial: wrappers cron de cache e robots descartam o retorno; busca IMAP usa SINCE em data UTC enquanto INTERNALDATE/SINCE são datas do servidor; Authentication-Results ausente não tem fallback e DMARC fail era considerado mesmo em cabeçalho não confiável. Mudanças restritas ao Core, sem novo contrato pedido ao MCP. Integração com MCP 0.33.0 será retestada; sem novo impacto identificado no planejamento.

Validar positivos, adversariais e retomada; autenticação com mensagens assinadas e DNS simulado, protocolos IMAP com servidor controlado, WordPress mínimo/atual, instalação limpa/upgrade 1.54.0, documentação completa e Site-Teste. Contas reais e provas disponíveis serão avaliadas sem revelar mensagens/credenciais e sem publicar a frota.

O documento recebido informa que a frota já implantou a 1.54.0 e executou o caso 302 real. Registrar como aceite recebido, sem repetir o contato. Não alterar a lista central. Entregar instalador, fonte e relatório; somente impacto técnico novo justifica documento adicional.
