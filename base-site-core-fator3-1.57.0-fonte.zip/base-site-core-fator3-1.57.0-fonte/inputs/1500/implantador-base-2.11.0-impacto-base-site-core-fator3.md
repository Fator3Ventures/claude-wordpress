# Impacto de implantador-base 2.11.0 em base-site-core-fator3

Revisão 4 · Etapa: entrega · Data: 23/10/2026 00:00:10 -0300 (America/Sao_Paulo).
Classificação: `validacao-coordenada`. Situação: adaptação do implantador implementada e validada em WordPress local; aceite do destinatário/frota pendente. Pedidos ao implantador 20 e 21(a–h). Nenhum envio externo realizado.

Emissor: implantador-base, base 2.10.0 → 2.11.0; identidade `implantador-base/implantador-base.php`. Destinatário examinado: Core 1.48.0, contrato 8.13.0. Instalador emissor: `implantador-base-2.11.0-instalador.zip`, 508145 bytes, SHA-256 `b37b3777a9571df7a898db1a42ddc23b3c77f411589da41c8646816a7f371007`. Core examinado: SHA-256 `91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de`.

## Mudança e consequência

O implantador descobre o contrato 8.13.0 e usa o perfil canônico piso-padrao-3.6 (92 condições). Propõe retenção mensal 60 e operações concluídas 6, rejeita chaves legadas de dias e protege valores com procedência externa quando não tem base própria. Não escreve implicitamente converter_contato_sem_identificador, cache_reaquecimento nem linkedin_server_conversion_id; não infere ID de servidor pelo ID de navegador.

O padrão novo usa papel contato/text/etapa1 (“Celular ou e-mail”), com alternativa explícita de campos separados. Captura, classificação, três iscas, assinatura, token vencido válido, segundo estágio e botão da confirmação continuam exclusivos do Core. As seis cópias de partilhado são byte a byte iguais às de 1.48.0; nenhuma delas mudou desde a base. Os arquivos de formulário/antispam/options citados nos impactos recebidos não são cópias neste implantador e não foram vendorizados sem chamador.

O tema agora coloca o mesmo formulário em seu diálogo durante o evento de envio aceito, antes de o Core avaliar closest(dialog). A movimentação atrasada da base deixava um diálogo do Core vazio. Não há novo coletor, POST, token ou validação no tema. A página de confirmação deve existir/publicada e resolver a um template normal com post-content; o implantador recusa CTA WhatsApp duplicado e template landing com CTA no conteúdo.

Persistência com cache_agendado e leitura confirmada é sucesso de escrita. O implantador não a repete para esperar efeito público; a prova HTTP continua separada. TTL e intervalo GC já existentes são capturados antes da ativação do WPSC e preservados; sem anterior, TTL 3600. Reaquecimento não é habilitado implicitamente.

## Ação ou decisão do responsável

Implantador concluiu sua adaptação. O responsável Core deve avaliar o aviso nativo `rest_validate_value_from_schema: The "type" schema keyword for  is required`, capturado em `class-f3base-config-mescla.php:50`, chamado por consultas/herança/perfil. Não houve falha no resultado do perfil (92 conformes), mas o aviso impede declarar execução sem diagnósticos. Não alteramos Core nem propomos suprimir o aviso; confirmar o schema passado ao validador.

Dono/frota deve conferir os Pedidos 20/21 num site recém-implantado autorizado e encerrar editorialmente a pendência 20 do estado da frota somente após esse aceite. Não instalar o implantador no Site-Teste ou em site em operação. O responsável da hospedagem verifica proteção do artefato/cache público e LLMS público em ambiente indexável. Não é necessária mudança no contrato para os comportamentos já provados; a resposta do destinatário não foi presumida.

## Compatibilidade e sequência

Ativar o Core compatível antes dos lotes integrados. O implantador pode ser instalado sozinho e fornece sua documentação; operações de contrato indisponível são bloqueadas explicitamente. A atualização do implantador não aplica lotes, migra dias, troca formulários, edita temas existentes nem atualiza a frota. Não há suporte declarado a todos os contratos intermediários 8.10–8.12: a combinação realmente exercitada foi 8.13.0/1.48.0.

## Validação e evidência

WordPress 7.1.2/PHP 8.3.6/MySQL 8.0.36 descartáveis. Evidências no fonte: native-211 (144), profile-211/perfil-211 (92 condições), cache-211 (16), preservation-211 (8), browser-211 (48), forms-211 (20), final-211 (10), partilhado (seis hashes), warnings-211. Telefone livre e estrito foram enviados de página e diálogo; contato classificou e-mail, válido, sem DDD e inválido; cada fluxo de duas etapas teve exatamente dois POSTs, um por etapa, para o mesmo registro. Confirmação exibiu cabeçalho/rodapé e um botão no conteúdo. O link geral do cabeçalho é independente e não conta como botão duplicado na confirmação.

Cache: purga nativa e primeira renderização OK; verificação pública BLOCKED/pending por sem_artefato_elegivel (proteção de acesso direto não comprovada). Não houve homologação de hospedagem ou fornecedor. Metas Yoast e emissor único LLMS foram verificados; publicação pública completa não foi exercitada.

## Evolução e encerramento

- r1, planejamento: impacto emitido antes da mudança; contrato mensal, cópias, cache e formulários delimitados.
- r2, implementação: identificado conflito de duas camadas modais; definida movimentação síncrona somente de apresentação.
- r3, implementação: identificada preservação incompleta de origens ability/migracao/desconhecida; sem base própria, somente ausência/padrao/implantador permitem criação.
- r4, entrega: correções provadas, installer identificado, aviso de schema encaminhado e limites públicos mantidos. Parte do implantador concluída; validação coordenada continua aberta. Sem confirmação atribuída ao Core/frota.
