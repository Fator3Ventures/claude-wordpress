# Impacto de Fator3 MCP LinkedIn 0.7.0 em wp-mcp-fator3

Data: 2026-10-22 · Revisão 3 · Etapa entrega · Situação aberto.
Classificação: acao-necessaria / validacao-coordenada. Natureza: contrato e auditoria de serviço.
Emissor wp-mcp-linkedin-fator3, base 0.6.0 (edfed426b2e0e4fce14a5c5c6241b12bed25186ab1da2102da96b2032a8af45e), alvo entregue 0.7.0; instalador 207524 bytes, SHA-256 85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515.
Destinatário examinado wp-mcp-fator3 0.27.0 (fcf5ad0099b9490abfb8e9ea6ef83c769cad053e2ee75712efce50e219f62bc1). Resposta ao impacto recebido revisão 2; Pedidos MCP LinkedIn 8(d) / Pedidos MCP 65.

## Confirmação e detalhamento proposto

Aceita a separação do principal de serviço, ausência de executor remoto de emissão, concessão explícita, revisão opaca, conferência local e leitura administrativa com gates. Mantidos mutation-audit/1.0.0 e o leitor humano original.

Parte do LinkedIn implementada: função PHP global `f3_linkedin_service_audit_descriptor()` retorna descritor fechado com `contract=mutation-service-audit/1.0.0`, `provider=wp-mcp-linkedin-fator3`, `event_contract=linkedin-service-mutation/1.0.0`, `event_hook=f3_linkedin_service_mutation_recorded`, `reader=linkedin/get-service-write-operation`, `introspector=f3_linkedin_introspect_service_grant`. O introspector é somente PHP local, não ability HTTP; recebe provider, consumer_id, principal_ref, grant_revision e operation_id. O último campo vincula a concessão ao diário persistido e impede aceitar referência de outra operação ou de escrita humana.

As duas referências são HMAC opacas com separação de domínio e site: principal ligado ao consumidor/destino; revisão ligada à revisão vigente da concessão e sua identidade. Não contêm user_id, conexão OAuth, conta, regra, token ou identificador de contato. A identidade é congelada no diário antes do POST; revalidação antes do envio impede gravar sob concessão modificada. O introspector não faz rede nem altera estado; valida existência do diário, serviço, identidade, concessão/revisão, principal concedente ainda autorizado, conexão e seleção, fonte API e escopos localmente comprovados. Ausência de prova local válida falha fechado. Revogação remota só é conhecida após nova introspecção do token; nenhuma leitura do diário chama LinkedIn.

Evento fechado: contract, provider, operation_id, operation, state, before_sha256, after_sha256, consumer_id, principal_ref, grant_revision. Somente snapshots técnicos e hashes; nenhum payload/PII. Leitor recebe a mesma identidade de cinco campos; exige administrador, propriedade vigente da concessão, ativo e perfil MCP. Revogação/alteração bloqueia detalhe sem apagar diário/referência. Replay não emite outro evento nem reenvia conversão. Não importar diários legados automaticamente.

## Contraproposta concreta de registro e recibo

Para evitar acoplamento a classe privada ainda inexistente, o futuro central chama em PHP `do_action('f3_mcp_register_mutation_service_audit', 'mutation-service-audit/1.0.0', $registrar, $consultar)`. Callables só vêm do bootstrap local; não são parâmetros de rede nem campos do descritor. `$registrar($descritor)` devolve contract, provider, registered=true depois de validar origem instalada, função e reader. `$consultar($provider, $identity)` devolve contract, provider, registered e, para identidade completa, recorded e event_sha256. Identidade vazia consulta só registro do provedor. O digest do evento usa JSON canônico recursivamente ordenado; documentar exemplo no contrato instalado.

O LinkedIn emite o hook de domínio após persistir o resultado e só informa central_audit=recorded quando a consulta local confirma o digest exato. Registro de provedor sozinho não prova persistência do evento. Canal ausente preserva service_principal_unsupported. Falha de auditoria não transforma entrega confirmada em autorização para reenviar. Este detalhamento é proposta para o responsável MCP; não afirma implementação no 0.27.0 nem exige mudança no Core.

## Ação, aceite e limites

Responsável LinkedIn entregou suas interfaces, esquema/documentação e testes. Responsável MCP confirma o handshake/recibo ou apresenta adaptação explícita, implementa consumidor e Registro/leitor central com perfil/gates, retenção e identidade estável por site/provider/principal/operação. Conservar referência após revogação e negar detalhes; nenhum usuário humano assumido. Leitor local indisponível, identidade falsa, revisão divergente e registro sem prova são recusados.

Aceite conjunto: adaptador real sob usuário zero e usuário incidental gera referência central de serviço; leitura autorizada mostra antes/depois; revogação/perfil indevido nega, replay conserva identidade, incerto não repete. Teste do consumidor simulado está identificado como prova do contrato de domínio, nunca como implementação do MCP. Até runtime central compatível, o Pedido 8(d) permanece aberto. Não haverá envio deste documento a terceiros sem instrução do dono.

## Revisão 2 — implementação própria
Parte de domínio implementada: descritor/introspector PHP, leitor administrativo, identidade congelada, evento de serviço e conferência de recibo por hash. As assinaturas previstas na revisão 1 foram mantidas. Primeira matriz: 105 verificações isoladas e 139 na atualização integrada com MCP 0.27.0, zero falhas. A prova usa consumidor simulado explicitamente identificado; o pacote MCP real não foi modificado e continua sem o contrato. O handshake/recibo requer confirmação do responsável do canal. Nenhuma mudança obrigatória no Core. Evidências finais e identidade do instalador serão registradas na entrega.


## Revisão 3 — entrega e evidência final

Instalador acima aplicado no Site-Teste, da 0.6.0 para a 0.7.0, pela operação `319535c63509678fa12ba912`, backup `f34fbc0e5945e69f2f079813`; página e REST responderam 200 antes/depois. A versão ficou ativa, com 80 abilities e 21 documentos integralmente lidos em 22 páginas, iguais aos bytes do instalador. O auxiliar de QA foi removido e sua descoberta retornou zero abilities.

O mesmo hash passou por instalação limpa isolada (105 verificações), atualização direta integrada (139), Site-Teste (18 cenários simulados, 3 POST interceptados e zero chamadas reais ao fornecedor) e oito autotestes locais. As contagens têm regressões comuns e não representam casos únicos somáveis. O cenário local inclui o consumidor central simulado `ServiceAuditContractFixture`, exclusivamente no teste: prova o protocolo do domínio, não a implementação do canal. Nenhum simulador de central foi instalado no Site-Teste. O MCP 0.27.0 real conserva `central_registered=false` e `service_principal_unsupported`, de forma deliberada e verificável.

Matriz local: WordPress 7.1.3/PHP 8.3.6, Core 1.47.0, MCP 0.27.0, Google 0.17.0 e Meta 0.4.1. Matriz compartilhada: WordPress 7.1.3/PHP 8.3.36, os mesmos acompanhantes, exceto Meta 0.5.0, cuja atualização por outra atividade foi observada antes desta instalação e preservada. Não houve alteração do MCP ou de outro pacote por esta entrega.

Permanece `aberto`, classificação `acao-necessaria` e `validacao-coordenada`: responsável MCP confirma/adapta o handshake e recibo propostos, implementa seu consumidor real e realiza o aceite conjunto descrito acima. A parte do domínio pode ser instalada antes dele; não depende de nova configuração nem altera concessão já salva. Quando o canal compatível chegar, a validação deve usar novo envio simulado autorizado; não há importação ou reemissão automática dos diários antigos. Pedidos MCP LinkedIn 8(d) e Pedidos MCP 65 não estão encerrados. O relatório principal e `docs/SERVICE-AUDIT.md` delimitam essa diferença.

Histórico: revisão 1, planejamento anterior ao código; revisão 2, implementação própria; revisão 3, identidade final e provas. Não houve aceite do handshake pelo destinatário nesta rodada. Documento preparado para o dono; não enviado a terceiros.
