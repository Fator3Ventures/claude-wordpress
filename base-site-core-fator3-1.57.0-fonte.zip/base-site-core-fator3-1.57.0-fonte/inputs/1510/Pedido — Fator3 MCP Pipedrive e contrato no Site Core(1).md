# Pedido — Fator3 MCP Pipedrive e contrato no Site Core

Oct 23, 2026 · @Fator3

## Objetivo e ordem

Criar o pacote **Fator3 MCP Pipedrive**, instalado só num site-porta, para o agente operar a conta fator3.pipedrive.com pela API sem o token passar pelo chat. O Site Core ganha só um contrato interno que faz a chamada com o token que ele já guarda.

Ordem do dono, 23/10/2026 às 20h03: "Vamos seguir o caminho de criar um plugin separado para o Pipedrive. Faça as modificações necessárias e elabore o documento inicial para realizar o pedido para o desenvolvimento do novo plugin, assim como as mudanças necessárias no Core."

| Parte | Quem |
| --- | --- |
| Este pedido (escopo e aceite) | Orquestrador \| Geral |
| Registro nos Pedidos aos pacotes (aba Core e aba nova do pacote) e aba nova no Padrão de entrega | Orquestrador \| Geral (feito em 23/10/2026: Pedidos core 294, Pedidos MCP Pipedrive 1, aba no Padrão de entrega) |
| Desenvolvimento do contrato no Core e do pacote novo | agente de cada pacote, pelo Padrão de entrega |
| Publicação, prova no Site-Teste, escolha do site-porta e instalação | Orquestrador \| Geral; site-porta com a escolha do dono |
| Instrução do SDR com o conector do site-porta | Orquestrador \| Geral, com ordem do dono depois da entrega |
| Procedimentos da Referência para agentes que hoje dizem "na tela" | SDR \| Pipedrive |

## Contexto lido

O agente não usa o token colado no chat, e o conector Pipedrive não cobre campo personalizado de lead, exclusão nem estrutura; por isso essas ações hoje se fazem na tela. O Site Core já guarda o token da conta, mas suas rotas só servem à entrega de lead. Leituras de 23/10/2026, 19h1x–19h5x, no Site-Teste:

| Fato | Fonte |
| --- | --- |
| Site Core 1.50.0 (troca de 1.49.1 às 19h14), contrato administrativo 8.15.0, 145 rotas `f3base/*` | `f3base/como-usar`, discover-abilities |
| 8 rotas `f3base/pipedrive-*` (verificar, fila-ler, previa, processar, reenviar, reconciliar, atividade-reparar, avisos-ler) e `f3base/qualidade-catalogo-carregar`, todas presas à entrega de lead; nenhuma chamada livre à API | discover-abilities com `query: pipedrive` |
| Conta fator3.pipedrive.com 14725895, usuário 24617815, estado verificado; `f3base_pipedrive_token` cifrado e redigido nas leituras | `f3base/pipedrive-verificar` |
| Orçamento por consumidor e dia UTC: entregas 3.000, qualidade 600, verificação 600; GET/pesquisa 20 unidades, escrita 10; reserva atômica antes da chamada; estimativa local, não o saldo oficial da conta | docs/ORCAMENTO-PIPEDRIVE.md |
| Acompanhantes descobertos por contrato e capacidades (ex.: Google `search-console-reader/1.0.0`, cliente LinkedIn `linkedin-lead-reader/1.1.0`); ausência degrada só a capacidade | docs/CONTRACTS.md |
| Limite da conta: 30.000 tokens por dia, compartilhado com a entrega de leads dos sites; saldo no cabeçalho `x-daily-ratelimit-token-remaining`; abaixo de 3.000, parar o que não é urgente | Regras de operação do Pipedrive, Referência para agentes rev 84 |
| O ambiente do agente alcança api.pipedrive.com (HTTP 401 sem token): o bloqueio é a credencial vinda do chat | teste do Orquestrador, 19h1x |
| Norma: nada de executor irrestrito; mutação exige `manage_options` no servidor; versão nova `0.1.0` pela regra X.(Y+1).0 aplicada a pacote novo | NORMA-02 §2.3, §2.4, §3.1 |

Ações que hoje se fazem na tela e passam a ter rota: gravar Perfil (ICP), Serviço de interesse e campos de origem em lead; excluir lead, pessoa, organização, nota e atividade (limpeza de teste e ordem do dono); criar alternativa, criar ou excluir campo personalizado; criar, alterar ou excluir filtro; criar ou renomear etiqueta de lead; fixar nota.

## Arquitetura

O pacote novo fica num site só e chama a API pelo Core daquele site; a entrega de lead de cada site segue pela fila do próprio Core, sem passar pelo site-porta.

&#91;embedded content: entrega do lead e operação do agente · dois caminhos, uma conta\]

Os dois caminhos só se encontram no limite diário da conta. Cada site conta o próprio consumo; o saldo da conta inteira vem no cabeçalho `x-daily-ratelimit-token-remaining`, e é ele que a guarda C4 lê. Site-porta fora do ar para só a operação do agente.

## Mudanças no Site Core (versão-alvo 1.51.0)

O Core passa a oferecer, por contrato, a chamada à API do Pipedrive com o token que já guarda, cobrada num consumidor de orçamento novo. Nenhuma rota de operação entra no Core, e a entrega de lead não muda.

| # | Mudança | Requisito |
| --- | --- | --- |
| C1 | Contrato `pipedrive-api-client/1.0.0` | O pacote se registra como consumidor por hook (nome sugerido `f3base_register_pipedrive_consumers`, no mesmo molde de `f3_mcp_google_register_consumers`) com o provider `wp-mcp-pipedrive-fator3`. O Core devolve um objeto cliente com `capabilities()`, `status()` e `request(metodo, caminho, query, corpo, contexto)`. Ausência do Core ou contrato divergente desabilita só o pacote. |
| C2 | Guardas do cliente | Host fixo `api.pipedrive.com`; caminho relativo começando por `/v1/` ou `/api/v2/`; métodos GET, POST, PUT, PATCH, DELETE; recusa URL absoluta, `api_token` na query, parâmetro `ids` (exclusão em massa) e caminho com `merge`; corpo até 64 KiB; timeout 20 s; sem retry automático de escrita. O token nunca sai do Core nem aparece em resposta, log ou erro. |
| C3 | Consumidor de orçamento `operacao` | Mesmo mecanismo dos consumidores atuais (reserva atômica antes da chamada, GET 20 e escrita 10 unidades, dia UTC). Teto padrão 3.000 unidades por dia, ajustável por `f3base/config-core-escrever`. Esgotar `operacao` não toca entregas, qualidade nem verificação. |
| C4 | Saldo da conta | Ler `x-daily-ratelimit-token-remaining` em toda resposta do Pipedrive, de qualquer consumidor, e guardar o último valor com o instante. O cliente recusa chamada de `operacao` quando o último saldo lido for menor que 3.000 (código `saldo_conta_baixo`), sem afetar os outros consumidores. `429` e pausa remota seguem compartilhados como hoje. |
| C5 | Autorização por site | Option nova `f3base_pipedrive_operacao` com `ativo` (padrão `false`) e `consumidores` (lista de providers). Sem `ativo: true` e o provider na lista, o cliente responde `operacao_nao_autorizada`. Gravação pelo contrato de configuração, com procedência. |
| C6 | Recuperação | Com a barreira de recuperação pausada, o cliente recusa com `core_em_recuperacao`, como as outras mutações. |
| C7 | Diagnóstico | `f3base/pipedrive-verificar` e `f3base/como-usar` mostram o consumidor `operacao` (teto, consumido, reservado), o último saldo da conta com o instante e os consumidores autorizados. |
| C8 | Entrega | Versão 1.51.0, contrato administrativo 8.16.0; impacto individual para `wp-mcp-pipedrive-fator3` (NORMA-02 §6) com o contrato, os códigos de recusa e as versões testadas. |

Fora do Core: lista fechada de caminhos, duas fases, frase de confirmação e registro de escritas ficam no pacote novo.

## Pacote novo: Fator3 MCP Pipedrive 0.1.0

O pacote expõe cinco rotas `pipedrive/*`, sem token próprio, e só chama a API pelo cliente do Core. Toda escrita passa por prévia e confirmação; mudança de estrutura exige também a frase de confirmação.

### Identidade

| Campo | Valor |
| --- | --- |
| Nome exibido | Fator3 MCP Pipedrive |
| Slug, pasta e arquivo principal | `wp-mcp-pipedrive-fator3`, `wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php` |
| ID de coordenação | `pipedrive` |
| Prefixo de rota | `pipedrive/` |
| Versão inicial | 0.1.0 |
| Text Domain | `wp-mcp-pipedrive-fator3` |
| Update URI | `https://fator3.com.br/plugins/wp-mcp-pipedrive-fator3` |
| Description | "Operação da conta Pipedrive pelo agente, com o token guardado no Fator3 Site Core. Configuração: Ferramentas → Fator3 MCP Pipedrive." |
| Tela | Ferramentas → Fator3 MCP Pipedrive: contrato do Core, autorização do site, conta, orçamento `operacao`, último saldo da conta e registro de escritas; `manage_options` |
| Dependência | Fator3 Site Core com `pipedrive-api-client/1.0.0`; sem ele, as rotas respondem `core_indisponivel` e o site segue normal |

### Rotas

| Rota | Tipo | Faz |
| --- | --- | --- |
| `pipedrive/status` | leitura, sem chamada externa | Versão, contrato do Core, autorização do site, conta (domínio, `conta_id`, `usuario_id`), orçamento `operacao` e último saldo da conta |
| `pipedrive/api-ler` | leitura | GET num caminho da lista de leitura; devolve status HTTP, corpo e saldo |
| `pipedrive/api-previa` | escrita, fase 1, sem efeito externo | Recebe método, caminho e corpo; confere a lista; lê o registro atual por GET quando o caminho tem id; devolve `previa_id` (vale 15 min), estado atual, corpo a enviar, custo estimado, classe (`registro` ou `estrutura`), se se desfaz e, para estrutura, a frase exigida |
| `pipedrive/api-aplicar` | escrita, fase 2 | Recebe `previa_id` e, para estrutura, `confirmacao`; executa uma vez (repetição devolve o mesmo resultado, sem nova chamada); grava no registro; devolve status, corpo e saldo |
| `pipedrive/registro-ler` | leitura local | Escritas aplicadas, paginadas: instante UTC, método, caminho com ids, classe, status, `previa_id`, chaves alteradas, saldo depois |

### Lista de leitura (GET)

- `/v1/leads/{id}`, `/v1/leads` (com `filter_id`, `limit`, `start`), `/v1/leads/archived`
- `/v1/dealFields`, `/v1/personFields`, `/v1/organizationFields`, `/v1/activityFields`, `/v1/noteFields`
- `/v1/filters`, `/v1/filters/{id}`, `/v1/leadLabels`, `/v1/activityTypes`, `/v1/users/me`
- `/v1/notes/{id}`, `/v1/notes` (com `lead_id`, `deal_id`, `person_id` ou `org_id`)
- `/api/v2/deals/{id}`, `/api/v2/persons/{id}`, `/api/v2/organizations/{id}`, `/api/v2/activities/{id}`, `/api/v2/pipelines`, `/api/v2/stages`

### Lista de escrita

| Classe | Método e caminho | Se desfaz |
| --- | --- | --- |
| registro | `PATCH /v1/leads/{id}` (campos nativos e personalizados, `label_ids`, `is_archived` com `archive_reason`) | sim, por nova escrita |
| registro | `PUT /v1/notes/{id}` (conteúdo e `pinned_to_*_flag`) | sim |
| registro | `DELETE /v1/leads/{id}`, `/api/v2/persons/{id}`, `/api/v2/organizations/{id}`, `/api/v2/deals/{id}`, `/v1/notes/{id}`, `/api/v2/activities/{id}` | sim, pela lixeira da conta (Regras comuns, "Exclusão no Pipedrive") |
| estrutura | `POST /v1/dealFields`, `/v1/personFields`, `/v1/organizationFields` | sim, excluindo o campo novo |
| estrutura | `PUT /v1/dealFields/{id}`, `/v1/personFields/{id}`, `/v1/organizationFields/{id}` (nome e opções) | renomear sim; opção retirada apaga o valor nos registros: não |
| estrutura | `DELETE /v1/dealFields/{id}`, `/v1/personFields/{id}`, `/v1/organizationFields/{id}` | não: o valor sai de todos os registros |
| estrutura | `POST`, `PUT`, `DELETE /v1/filters[/{id}]` | sim, exceto filtro excluído |
| estrutura | `POST`, `PATCH`, `DELETE /v1/leadLabels[/{id}]` | sim, exceto etiqueta excluída |

### Regras

1. Caminho, método ou parâmetro fora das listas: recusa `caminho_fora_da_lista`, sem chamada.
2. `PUT` em campo com opções: a prévia compara as opções atuais com as enviadas; opção ausente no corpo é recusada (`opcao_seria_apagada`) a menos que o corpo traga `remover_opcoes` com os ids, listados na prévia.
3. Estrutura: `api-aplicar` exige `confirmacao` com o texto "Confirmo por ordem do dono de \<DD/MM/AAAA>: \<resumo da prévia>", e o resumo tem de ser igual ao devolvido pela prévia. Sem a frase, recusa `confirmacao_ausente` (Referência para agentes, regra fixa 1).
4. Antes de cada chamada, pergunta ao cliente do Core; `saldo_conta_baixo`, `operacao_nao_autorizada`, `core_em_recuperacao` e orçamento esgotado voltam com o código, sem chamada.
5. Registro guarda caminho, ids e chaves alteradas, não os valores de campo de pessoa (nome, e-mail, telefone); guarda nome de campo, opção, filtro e etiqueta, que não são dado pessoal. Retenção padrão 180 dias.
6. Sem cron, sem fila, sem webhook: só chamada sob demanda.
7. `manage_options` no servidor em todas as rotas, por MCP, REST e tela (NORMA-02 §2.4). Mensagens em português.
8. Desinstalar preserva o registro; desativar não chama a API.

## Fora da primeira versão

A primeira versão cobre só as listas acima; o resto da API fica fora por risco, por esforço ou porque o conector já faz.

| Fica fora | Motivo |
| --- | --- |
| Exclusão em massa (`ids=`) e mesclagem de pessoa, organização e negócio | Regra fixa 1 do Pipedrive; mesclagem não se desfaz |
| Escrita em funis, etapas e tipos de atividade | Estrutura do fluxo de negócio; excluir etapa fica bloqueado 30 dias com negócio na lixeira |
| Webhooks | Mandaria eventos da conta a endereço externo |
| Mailbox | Traz o conteúdo dos e-mails dos leads; a conferência atual só precisa da contagem, que o conector devolve |
| Files e foto de pessoa | Envio multipart; o arquivo teria de chegar ao site antes |
| Recents | Varre a conta e consome orçamento |
| Usuários, papéis, permissões, equipes, configurações de usuário, cobrança | Administração da conta, com usuário único |
| Projects, Goals, Call logs, Channels, Meetings, Deal installments, Organization relationships, Lead sources, Currencies, Beta | Não usados na operação |
| Criar e editar lead, pessoa, organização, negócio, atividade, nota e produto; converter; buscar | O conector Pipedrive já faz |

Continua na tela: criar motivos de arquivamento de lead e de perda de negócio (a API v1 não tem endpoint para essas listas; `archive_reason` e `lost_reason` são texto livre, conferido em 23/10/2026), a lista "Aceitar e-mails Cco inteligentes de" e o WhatsApp Web.

## Critérios de aceite

A entrega é aceita quando os itens abaixo passam no Site-Teste com o Core 1.51.0 e o pacote 0.1.0. O Site-Teste está ligado à conta real (14725895): a prova usa só registros "Teste pipedrive-operacao (apagar)" e apaga o que criou no mesmo trabalho (Regras comuns, "Testes no Site-Teste e limpeza de testes").

| # | Prova | Esperado |
| --- | --- | --- |
| A1 | `pipedrive/status` com `f3base_pipedrive_operacao.ativo` falso | `operacao_nao_autorizada`; nenhuma chamada externa |
| A2 | Ligar a option só para `wp-mcp-pipedrive-fator3` e chamar `pipedrive/status` | Contrato 1.0.0, conta 14725895, orçamento `operacao` 3.000 |
| A3 | `pipedrive/api-ler` em `/v1/dealFields` | Lista de campos; saldo da conta devolvido e guardado pelo Core |
| A4 | `api-ler` em `/v1/mailbox/mailThreads` e em URL absoluta | `caminho_fora_da_lista`; nenhuma chamada |
| A5 | Lead de teste criado pelo conector; `api-previa` com `PATCH /v1/leads/{id}` gravando Perfil (ICP) 152 → `api-aplicar` | Prévia mostra o valor atual e o novo; aplicado; `GET` confirma; registro tem a linha sem valor de campo pessoal |
| A6 | Repetir `api-aplicar` com o mesmo `previa_id` | Mesmo resultado, sem nova chamada nem nova linha |
| A7 | `api-aplicar` com `previa_id` de mais de 15 min | `previa_expirada` |
| A8 | Prévia de `POST /v1/leadLabels` (etiqueta de teste) e aplicar sem `confirmacao` | `confirmacao_ausente`; com a frase certa, criada; depois excluída pela mesma rota |
| A9 | Prévia de `PUT /v1/dealFields/{id}` sem uma opção existente | `opcao_seria_apagada`, com a opção listada; nada enviado |
| A10 | `DELETE` com `?ids=1,2` | Recusa no pacote e, chamando o cliente direto, recusa no Core |
| A11 | Teto `operacao` reduzido a 40 unidades e três leituras | Terceira recusada por orçamento; entregas seguem com saldo próprio |
| A12 | Saldo da conta simulado abaixo de 3.000 | `saldo_conta_baixo` só para `operacao` |
| A13 | Barreira de recuperação em `preparar` | `core_em_recuperacao`; depois de `retomar`, volta a responder |
| A14 | Pacote desativado; Core sem o pacote | Site, formulário e entrega de lead normais; `f3base/pipedrive-verificar` sem erro |
| A15 | Busca por token em resposta, log, registro, erro e relatório | Nenhuma ocorrência |
| A16 | Limpeza | Lead, pessoa, organização e etiqueta de teste excluídos; ids na entrega |

O relatório de cada pacote marca cada item pelos estados da NORMA-02 §5 e cita as versões testadas do canal e dos outros pacotes.

## Entrega e passos seguintes

Cada pacote sai com instalador, fonte e relatório pelo Padrão de entrega; o Core troca primeiro, e o pacote novo entra só no site-porta.

1. Feito pelo Orquestrador em 23/10/2026, por ordem do dono das 20h22: Pedidos core 294 (C1 a C8) e Pedidos MCP Pipedrive 1 (aba nova), citando este documento; aba do pacote no Padrão de entrega dos pacotes.
2. Agentes dos pacotes: Core 1.51.0 com impacto para `wp-mcp-pipedrive-fator3`; pacote 0.1.0 com impacto para `base-site-core-fator3`. O agente do pacote novo confere se o canal (Fator3 MCP) expõe rotas de provider novo sem mudança; se não, emite impacto para `wp-mcp-fator3`.
3. Orquestrador: publica no repositório, instala o Core 1.51.0 no Site-Teste, depois o pacote, e roda A1 a A16.
4. Orquestrador: troca o Core na frota pela ordem de sempre e propõe ao dono o site-porta (integração Pipedrive verificada na conta 14725895). Liga `f3base_pipedrive_operacao` só nele e instala o pacote só nele.
5. Orquestrador: com a ordem do dono "17 (b): incluir o conector WP MCP \<site> no alcance do SDR | Pipedrive", grava a instrução do SDR e atualiza `claude/instrucoes-dos-projetos.md`.
6. SDR | Pipedrive: troca, na Referência para agentes, os procedimentos que dizem "na tela" ou "API REST" pela rota, e registra a mudança no Registro de mudanças.

Perguntas em aberto para o desenvolvimento:

- Nome do hook de registro do consumidor: sugerido `f3base_register_pipedrive_consumers`; vale o que o agente do Core definir, se estiver no contrato.
- Endpoints v2 de campos (`/api/v2/*Fields`): se a conta já os oferecer, usar v2 e manter as mesmas classes e regras.
