# Impacto de wp-mcp-pipedrive-fator3 0.1.0 em base-site-core-fator3

Data: 23/10/2026 · Revisão 1 · Etapa: planejamento · Situação: demanda-aberta.
Emissor: wp-mcp-pipedrive-fator3; base nenhuma; alvo previsto 0.1.0; instalador ainda não gerado.
Destinatário: base-site-core-fator3 1.50.0, instalador SHA-256 `7021163d158b1a353e012823e14b611c17cb45d82125d3230784eb84f2b6b8ea`; alvo solicitado 1.51.0.
Natureza: contrato, autorização, orçamento e consistência de escrita.
Classificação: acao-necessaria. Referências: Pedidos core 294 C1–C8 e Pedidos MCP Pipedrive 1.

## Mudança e consequência

Core 1.50.0 não publica o cliente solicitado. Pipedrive 0.1.0 precisa de cliente ligado ao provider `wp-mcp-pipedrive-fator3` e retorna `core_indisponivel` até receber o contrato compatível. Painel, documentação e histórico local continuam utilizáveis.

## Pedido ao mantenedor Core

Implementar C1–C8 e confirmar o formato abaixo, que concretiza as lacunas de assinatura/envelope do pedido. Trata-se de proposta de integração, sem afirmar implementação no Core:

* Hook `f3base_register_pipedrive_consumers($registry, 'pipedrive-api-client/1.0.0')`, disparado em plugins_loaded depois do carregamento dos plugins, no molde Google.
* `$registry->register_consumer($provider, $version, $contract, $configuration)` devolve o cliente ou WP_Error. Callback configuration retorna `ready`, `revision` e provider; registro não concede autorização.
* Cliente expõe `capabilities()` com `contract`, `status()` e `request($metodo,$caminho,$query,$corpo,$contexto)`.
* `status()` sem HTTP: `{success,code,message,data:{contract,autorizado,conta:{dominio,conta_id,usuario_id},revisao,orcamento:{teto,consumido,reservado},saldo_conta:{restante,lido_em}}}`. `revisao` muda ao trocar identidade/credencial ou autorização. Falhas incluem códigos do pedido. A revisão não é um segredo.
* `request` devolve `{success,code,message,data:{http_status,body,saldo_conta},remote_dispatched}` ou WP_Error. `remote_dispatched:false` deve significar comprovadamente nenhuma requisição enviada. Resposta 5xx, timeout ou desconexão após despacho nunca deve ser apresentada como certeza de ausência de efeito.
* Contexto enviado pelo Pipedrive: `provider`, `consumer=operacao`, `contract`, `actor_id`, `revisao_esperada` e, nas escritas, `previa_id`. Validar revisão e autorização imediatamente antes do HTTP, no mesmo trecho crítico da reserva. Isso impede aplicar uma prévia em outra conta após troca de credencial entre status e request.
* Nenhum token, header de autenticação ou URL contendo credencial pode integrar os envelopes, WP_Error, logs ou respostas. Sanitizar também mensagens do fornecedor.
* Aplicar C2–C6 em toda chamada, inclusive GET; manter orçamento e saldo oficiais no Core, sem estimativa duplicada pelo Pipedrive.

Se o Core definir assinatura/envelope diferente, fornecer contrato e exemplos para adaptar o consumidor antes da ativação comercial. Não criar aliases especulativos nem ler suas options privadas.

## Sequência e aceite

Core implementa primeiro; pacote Pipedrive instala somente no site-porta escolhido pela frota. Autorizar apenas esse provider nesse site. Validar A1, A2, A3, A10–A15 em conjunto; comprovar que 429 e saldo baixo preservam consumidores de entrega. Usar testes sintéticos para saldo/limites e registros de homologação identificados para o fornecedor.

Critérios adicionais: troca de revisão entre status/request recusa antes do HTTP; status não chama fornecedor; falha incerta não habilita reenvio; consumidor não registrado ou revogado é recusado. Responsável: mantenedor Core; coordenação de homologação: frota. A evidência disponível é a análise do fonte 1.50.0 e descoberta MCP do Site-Teste, ambos sem o novo contrato. Prova integrada aguarda a entrega do Core.
