# Google 0.20.0 → Site Core — leitor GA4

Revisão 1 · 27/10/2026 · Etapa: planejamento · Situação: demanda-aberta.
Base Google 0.19.0; alvo 0.20.0; destinatário Core 1.56.0. Instalador-alvo ainda não gerado. Natureza: contrato; classificação: ação-necessária. Pedidos Google 38 / Core 313.

## Mudança e consequência

Será oferecido `ga4-reader/1.0.0` no hook `f3_mcp_google_register_consumers`, sem substituir `search-console-reader/1.0.0`. O Core deve filtrar o nome do contrato, registrar `base-site-core-fator3` com versão e callback público `{property, revision, ready}`, guardar apenas o cliente em memória e consultar por `query`. A propriedade será canônica `properties/123`; concessão explícita e revogável por `google/configure-consumer`, com `contract`, `property`, `consumer_id`, `enabled`, `expected_revision` e conexão selecionada. Não ler opções/segredos privados do Google.

A consulta exige versão 1.0.0, propriedade/revisão atuais, período ISO, dimensões, métricas, run_id, trigger e budget_ms; filtros são opcionais. Cada página retorna linhas, cabeçalhos, metadados Google, qualidade, cota observada e cursor vinculado à consulta/concessão/revisões. Não há snapshot imutável nem garantia de dados finais. Cota esgotada, contenção ou falha retornam erro e tempo para nova tentativa, sem repetição automática. Auditoria atribui a consulta ao plugin. Não persistir linha/cursor em caso de falha de auditoria ou revogação.

## Pedido ao Core

Responsável: mantenedor Core, pedido 313. Implementar configuração e coletor/acervo próprio consumindo o SDK; agenda, reconciliação, janelas de reconsulta e histórico pertencem ao Core. Não usar BigQuery. Tratar ausência do Google/contrato/concessão como indisponibilidade explícita; não interferir no coletor GSC. Usar o exemplo e schema entregues para integração, sem depender de respostas adicionais do emissor.

Aceite coordenado: concessão Core por propriedade, consulta de 30 dias pagePath/date comparada a ga/run-report no mesmo recorte, metadados/cota presentes, auditoria com actor plugin/base-site-core-fator3 e recusa após revogação. Confirmar persistência/reconsulta no acervo do Core por testes próprios.

## Compatibilidade e limites

Google implementa o SDK independentemente do coletor Core. Core 1.56.0 continua usando GSC e não consome GA4; a instalação Google não cria acervo Core. Instalar Google compatível antes de habilitar o novo coletor. Testes sintéticos do fornecedor não substituem aceite real; o Site-Teste observado não possui credencial Google. Respostas e fechamento deste encaminhamento ficam no relatório principal, conforme norma revisão 5.
