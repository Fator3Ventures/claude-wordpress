# Impacto de Fator3 MCP 0.32.0 em Fator3 Site Core

Data: 25/10/2026 · Revisão: 1 · Etapa: implementação · Situação: demanda-aberta.
Emissor: wp-mcp-fator3, base 0.31.0, alvo 0.32.0. Destinatário: base-site-core-fator3 1.53.0.
Natureza: autorização de domínio e repetição de recibos. Classificação: **acao-necessaria**.
Vínculo: pedido Core 300 e impacto recebido `base-site-core-fator3-1.53.0-impacto-wp-mcp-fator3.md`, revisão 2. Sem novo número de ticket atribuído.

Identidades examinadas:

- MCP 0.31.0, instalador SHA-256 `2285c633b5d11c9990bed376f17291612b44958b073e0db2489efac20c1ec4ef`.
- Candidato MCP 0.32.0, `wp-mcp-fator3-0.32.0-instalador.zip`, SHA-256 `fd2097055383a26e6ca5b79b655f0b3740c337a42dab6ce2b43b4236c07496b1`.
- Core 1.53.0, instalador SHA-256 `086adf2530809c73d30d38ccb747b0a8de8c7cd7419543273c2e2c50940d99f1`.

## Mudança e consequência

`F3Base_Servicos::ability()` registra `permission_callback` como `manage_options || capacidade`. Para `f3base/email-enviar`, a execução em `F3Base_Email_Envio::executar()` exige, corretamente, **f3base_enviar_email E f3base_ler_leads**. As duas fronteiras discordam.

O MCP revalida o permission_callback do produtor antes de reapresentar um recibo idempotente; não executa novamente uma mutação para decidir se pode mostrar seu resultado. Após uma prévia com chave de idempotência, revogar qualquer uma dessas capacidades de um administrador mantém o permission_callback autorizado. Repetir a mesma chave devolve a prévia privada armazenada, incluindo sua mensagem, embora uma nova intenção seja recusada com `sem_permissao`. Um recibo incerto também pode ser reapresentado após a revogação. **Não houve segundo envio SMTP**; a falha é de acesso ao resultado após a revogação, não uma prova de duplicação de e-mail.

O cenário foi reproduzido com MCP 0.31.0 e 0.32.0 usando exatamente o Core 1.53.0. A exceção tipada para sinais nesta entrega não altera autorização ou idempotência e não introduziu o comportamento.

## Pedido ao mantenedor Core

Alinhar o permission_callback às capacidades efetivamente exigidas por cada operação, preservando as verificações dentro da execução:

| Ability | Gate a declarar também no permission_callback |
|---|---|
| `f3base/email-enviar` | `f3base_enviar_email` E `f3base_ler_leads` |
| `f3base/email-registros-ler` | `f3base_ler_leads` |
| `f3base/email-caixa-consultar` e `f3base/email-reprocessar` | `manage_options` E `f3base_ler_leads` |
| `f3base/email-caixa-verificar` | `manage_options` |

Não usar a capacidade administrativa como alternativa a uma capacidade de domínio obrigatória. O mantenedor decide a implementação local do registro; não é necessário criar novo contrato MCP, transferir a regra comercial ao canal ou reexecutar o envio para autorizar leitura. A análise também encontrou a divergência declarativa nas operações da tabela; a reprodução de resultado privado em cache concentra-se em email-enviar.

Critérios de aceite: prévia autorizada retorna revisão e mensagem; revogar cada capacidade na mesma conexão impede reapresentar prévia/recibo já armazenado; nova chave continua recusada; com capacidades válidas, o recibo incerto é preservado, sem SMTP nem repetição automática; perfil de leitura continua recusando mutações e permite registros apenas com a capacidade própria. Testar também `check_permissions()` diretamente em contexto autorizado.

## Compatibilidade e sequência

A correção pertence ao Core e pode ser entregue independentemente do MCP 0.32.0. As permissões existentes do transporte são mantidas; não foi modificado nem publicado o pacote do destinatário. A correção de sinais Core301 pode avançar. O aceite integral das permissões do correio Core300 fica **pendente** dessa correção e do reteste coordenado.

Enquanto o Core 1.53.0 estiver instalado, para cortar acesso anterior ao resultado, revogar explicitamente a conexão MCP afetada ou retirar a ability do perfil. Não trocar a chave/revisão para forçar envio. Esta entrega não modifica conexões, capacidades ou configurações comerciais automaticamente.

## Validação e evidência

Reprodutor entregável: `tools/release0320/provider-mail-permissions.php`. Laboratório WordPress 7.1.3, PHP 8.3.6, MySQL 8.0.46, contas administrativas e contato sintéticos descartáveis. O teste faz prévias locais, nenhuma tentativa SMTP/IMAP; remove os recursos criados. O texto privado não é gravado nos JSON de evidência.

- Base 0.31.0: 8 verificações, **3 falhas esperadas pelo critério de autorização**, em `evidencias/0320/provider-base0310/provider-mail-permissions.json` e `provider-mail-observations.json`.
- Candidato 0.32.0: o mesmo reprodutor, **as mesmas 3 falhas**, em `evidencias/0320/current/provider-mail-permissions.json` e `provider-mail-observations.json`.
- As falhas são duas reapresentações de prévia após revogação e a resposta permissiva de `check_permissions()` sem capacidade de leitura. As demais 5 verificações confirmam criação isolada, prévias autorizadas e recusa das intenções novas.
- O teste de recibo incerto confirmou preservação do estado, do código `smtp_sem_confirmacao` e `reenvio_automatico=false`; não é prova de entrega no fornecedor.

Esse encaminhamento apresenta um novo defeito concreto a corrigir no destinatário. O atendimento do impacto de sinais recebido e os demais resultados da rodada estão no relatório principal, não constituem encerramento desta demanda.
