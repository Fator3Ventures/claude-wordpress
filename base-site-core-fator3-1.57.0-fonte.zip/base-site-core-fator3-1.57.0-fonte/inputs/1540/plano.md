# Core 1.54.0 — plano da rodada

Base: pacote final 1.53.0. Normas do projeto revisão 5, de 23/10/2026.

Pedido 302: registrar contato externo com simulação e idempotência; guardar os dados pessoais cifrados; entregar ao CRM somente por opção explícita ou registrar referência a lead existente; atribuição manual reversível de sessões com revisão e auditoria; consultas e filtros separados da atribuição observada; exclusão em cascata; nenhum aviso, e-mail automático ou conversão.

Impacto recebido do MCP 0.32.0: publicar verificações exatas de capacidades nas abilities de e-mail, inclusive na repetição idempotente após revogação. A devolutiva será registrada no relatório principal. Neste planejamento não foi identificada mudança nova exigida no plugin MCP.

Validação: WordPress nativo limpo e atualizado da 1.53.0, regressões pertinentes, integração com MCP 0.32.0, replays após revogação de capacidades, cenários positivos e negativos do pedido 302 e homologação isolada no Site-Teste. Evidências somente sintéticas e sem credenciais ou contatos reais.

Entrega: instalador, fonte reproduzível sem ZIPs internos e relatório em português, com hashes finais e limitações observadas. A implantação na frota e o caso real do CTO Office serão distinguidos da validação sintética.
