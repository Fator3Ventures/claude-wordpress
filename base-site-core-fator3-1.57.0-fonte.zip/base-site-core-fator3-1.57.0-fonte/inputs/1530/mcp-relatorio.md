# Entrega — Fator3 MCP 0.31.0

Revisão 1 · 25/10/2026 · America/Sao_Paulo · Implementação do Pedido MCP 67.

**Status: apta no escopo testado; versão corrente 0.31.0.** Instalada e ativa no Site-Teste. Nenhuma falha conhecida pendente nas verificações finais. Isso não afirma ausência de impacto em todos os fornecedores, sites ou extensões possíveis.

Slug/provider/pasta: `wp-mcp-fator3`. Basename: `wp-mcp-fator3/wp-mcp-fator3.php`. Identidades públicas preservadas.

**Relatório externo canônico.** A cópia no fonte é anterior ao fechamento e mantém a identidade do próprio ZIP pendente para evitar circularidade.

## 1. De onde esta versão entra

Base aceita **0.30.1**, sem alteração dos seus ZIPs. Instalador-base: 879690 bytes, SHA-256 `4dbe9ea5e3c9c2bc6ef5aaa574800e482226f0f1406e87a4fd818c68aa7260da`. Fonte-base: 4209674 bytes, SHA-256 `81478d432f54e63979f28234388f7cccb6e7fb6d281f5c3d6999258bd0208ecc`.

Percursos próprios comprovados: instalação limpa e atualização direta **0.30.1 → 0.31.0**. Não é necessária versão intermediária. Mínimos preservados e testados: WordPress 7.1.2, PHP 8.3.6, 64 bits. Laboratório atual: WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46; Site-Teste: WordPress 7.1.3/PHP 8.3.36. Outras combinações não foram homologadas nesta rodada.

Entradas: `Fator3 MCP(8).md`, impacto e pacotes Core 1.52.1, Meta 0.10.1 e demais acompanhantes abaixo. Normas comuns revisão 5, de 23/10/2026; a revisão 4 reanexada não substitui a 5. Plano em `docs/PLANO-0310.md`; pedidos/impactos/identidades em `docs/entradas/0310`. Não se alterou a lista central nem se criou um novo ID de pedido.

## 2. Convivência e impactos

| Pacote | Versão considerada | SHA-256 do instalador | Prova própria nesta rodada |
|---|---|---|---|
| Site Core | 1.52.1 | `b93a2fe56fa857f46dfa1d6acb1ac674555f7d4dac2f1a84db4b197992db6fcb` | Ativação, 406 arquivos íntegros no laboratório, descoberta, diagnósticos reais e contadores no Site-Teste |
| Google | 0.19.0 | `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1` | Ativação, 160 arquivos íntegros, descoberta; versão/atividade preservadas no Site-Teste |
| Meta | 0.10.1 | `f80d934fe1851bc887a0174190b42d73b36a8637f2f4824bdb5cfeb7a674ee95` | Ativação, 45 arquivos íntegros, limites read/maintenance e health; estado ok, issues=[] no Site-Teste |
| LinkedIn | 0.10.1 | `6182ea63bff6788f5d2637467e7ab29d58568e37283d6ece82d3e58ee41c13bc` | Ativação, 62 arquivos íntegros, status/descoberta e autorização nativa; versão/atividade preservadas |
| Pipedrive | 0.1.0 | `3366d83ca8908e407a0736812d30b8fa1506a8c1458a28cfb47eda6fd8f3c54f` | Site-Teste: contrato registrado, recusa administrativa esperada `operacao_nao_autorizada`, chamada_externa=false |

Fontes/instaladores/relatórios atuais foram considerados; identidades completas estão no manifesto de entradas. Não houve mudança em código, configuração ou credencial de acompanhante. Pipedrive não foi ativado abaixo do mínimo PHP declarado por ele; sua prova nesta rodada usa o Site-Teste com PHP 8.3.36. DreamHost Panel Login 1.0.0, WP Super Cache 3.1.4 e Yoast SEO 28.7 também permaneceram ativos.

**Impactos/pedidos novos a outros mantenedores: nenhum.** O metadado de transporte é aditivo, os objetos de negócio e schemas públicos permanecem com seus campos existentes, sem migração ou ordem nova de atualização conjunta. Foram examinadas redação, descoberta, autorização, recibos e diagnósticos nas interfaces acima. Não se declara homologação dos fluxos comerciais completos dos acompanhantes.

**Tratamento de impactos recebidos e aceites anteriores:**

- `base-site-core-fator3-1.52.1-impacto-wp-mcp-fator3.md`, revisão 1, demanda vinculada ao **Pedido MCP 67**: atendida neste MCP, com regras, caminhos e provas abaixo. Responsável técnico: mantenedor MCP. O Core não foi modificado; seus nomes de contadores alternativos continuam válidos. Registro de resposta/aceite neste relatório principal, conforme norma revisão 5; não se reemite impacto apenas para comunicar conclusão.
- **Pedido MCP 66:** o documento central recebido registra MCP 0.30.1 nos 12 sites e aceite em AWN: original 14, novo 67, WebP de 28862 bytes versus 56417, página 28 e srcset conferidos pela frota. Evidência recebida, não execução própria desta rodada. A pendência de AWN da entrega anterior deixa de ser transportada como aberta. Regressão local do fluxo mídia → revisão → conversão → leitura/remoção passou.

## 3. Pedido MCP 67: mudanças e resultado

A 0.30.1 interpretava `pass` dentro de `passagens` como segredo. Reprodução própria no Site-Teste: tanto SELECT sintético com contadores 7/3 quanto `saude.execucoes.passagens_24h` do Core retornavam `[redigido]`.

| Item | Implementação | Evidência |
|---|---|---|
| 67(a): nomes e formatos | Classifica nomes completos/componentes delimitados ou camelCase, com famílias conhecidas de senhas, tokens, cookies, credenciais e chaves. Reconhece valores completos Bearer/Basic, JWT e PEM privado; erros/logs também tratam Bearer/Basic embutidos. | Matriz unitária; HTTP sucesso/erro/serializador; SQL por nome, formato e proveniência de aliases |
| 67(a): diagnóstico visível | Números, booleanos e datas de campos operacionais preservados. Campos com componente secreto exigem nome diagnóstico e tipo reconhecido. `password`/`token` simples continuam ocultos mesmo numéricos/booleanos. | 218 verificações unitárias; Core real com três contadores inteiros; confirmação e hashes preservados |
| 67(b): campos mascarados | `_meta["fator3/redaction"]` no envelope MCP, contrato fator3-redaction/1: paths em JSON Pointer, total, truncated e scope=structuredContent. Não injeta propriedades nos objetos de negócio. | HTTP real de WordPress: sucesso, erro, serializador, paridade texto/structuredContent e caminhos escapados; db/query mantém também redacted por coluna/origem/motivo |
| 67(c): regras/falsos positivos | Documento `redacao` instalado e este relatório; teste explícito de `passagens`, `passagens_24h`, `contagem_passagens`, `bypass`, `checks_passed`, `all_checks_passed`, `cache_bypass_verified`, `secretaria`, `tokenization`, `compass`, `surpassed`. | Leitura integral do documento via MCP e comparação byte a byte |
| Proteção transversal | Resultado e erro após serialização JSON, esquemas com exemplos/defaults secretos mascarados, auditoria persistida e de mutações, logs e leitura SQL. | 30 verificações HTTP dedicadas; guards de segredo mantidos; zero warnings inesperados nos ambientes finais |

Regras diagnósticas precisas: finais configured/present/available/valid/expired/enabled/verified exigem booleano; count/total/generation/revision/age_seconds/expires_in/ttl_seconds exigem número finito não negativo; created_at/updated_at/expires_at/expired_at/issued_at/checked_at exigem string em formato de data ISO. Tipos indevidos não recebem exceção. `credential` continua contêiner fechado, publicando apenas configured booleano. `confirm_token` e `confirmation_token` de 64 dígitos hexadecimais permanecem utilizáveis para o protocolo de confirmação. Guardas de escrita/configuração e SQL não recebem as exceções tipadas da apresentação.

Paths é limitado a 256 posições/16 KiB acumulados; total/truncated indicam omissões. Inclui marcadores integrais e diagnósticos já redigidos pelo provedor (`includes_existing_markers=true`); não atribui ao MCP a origem de todo marcador. Menção literal em manual não conta como campo mascarado. Segmentos de nomes atípicos que aparentem ser credenciais são redigidos; não se publicam valores secretos na lista. Não se usa heurística de entropia para hashes, UUIDs, revisões e cursores. Segredo opaco sob nome e formato desconhecidos não tem detecção universal garantida.

O conector desta sessão exibe structuredContent e não repassa `_meta` ao resultado visível da ferramenta. O contrato completo do envelope foi comprovado por HTTP MCP nativo no laboratório; no Site-Teste foram comprovados os dados e o inventário redacted de SQL. Clientes que descartam metadados precisam consultar o envelope MCP original. A limitação de exibição não foi confundida com prova remota do `_meta`.

Comparação do runtime com 0.30.1: **10 arquivos alterados, nenhum adicionado/removido** — sete arquivos funcionais, dois guias compilados e bootstrap de versão. Nenhuma rota nova, executor PHP genérico, rota de frota, tabela, coluna, migração, tarefa agendada ou formulário de credencial. O mascaramento altera cópias de apresentação, sem alimentar recuperação, comparações, credenciais ou recibos de idempotência.

## 4. Testes e instalação

| Ambiente final | Verificações | Resultado / evidência |
|---|---:|---|
| PHP 8.3.6, matriz de regras | 218 | Todas aprovadas; warnings como exceções. `evidencias/0310/unit/unit.json` |
| WP 7.1.3/PHP 8.3.6/MySQL 8.0.46, integrado | 215 | Redação HTTP 30; acompanhantes 16; incerteza/idempotência 25; mídia 9; OAuth/CIMD 48; descoberta 17; busca 11; autorização nativa 26; documentos 33. `current/` |
| WP 7.1.2/PHP 8.3.6, instalação limpa | 55 | Ativação 3; leitura nova/saúde/inventário 10; mídia 9; documentos 33. `minimum-final/` |
| Atualização direta 0.30.1 → 0.31.0 | 27 | Ativação da base/acompanhantes 5 e preservação 22. `upgrade-final/` |
| Installer final | 453 arquivos PHP | Lint sem erro; 464 arquivos totais, incluindo 56 índices de proteção gerados. `lint.json` |
| Site-Teste WP 7.1.3/PHP 8.3.36 | Aceite real | Versão/saúde, segredo sintético, Core, acompanhantes e 30 documentos completos. `site-acceptance.json`, `site-documents.json` |

São **515 verificações automatizadas finais**, mais lint e aceite remoto; não se somam candidatos anteriores. O cenário de atualização aquece quatro workers PHP-FPM com opcache.validate_timestamps=0 e verifica novas requisições após troca. Mantidos: application password, expiração e renovação OAuth, perfis/grants, confirmação SQL pendente, recibo concluído sem duplicação, recibo incerto, options false/vazias e backup privado. Rollback foi somente pré-visualizado, validando preimagem sem reverter.

Revisão anterior ao fechamento corrigiu regra residual na auditoria, variável no ramo novo de SQL e contagem indevida de menção documental ao marcador; também ajustou a leitura do envelope Core no harness. Casos cobertos e reexecutados no instalador final. Detalhes em `observacoes-da-revisao.md`. Não se ocultam essas falhas preliminares como se a primeira execução tivesse passado.

### Site-Teste

Upload em quatro partes, finalização com tamanho/hash e `plugins/upload` do ZIP do próprio site, esperado slug wp-mcp-fator3 e SHA-256 da seção 7; activate=true, overwrite=true. Operação de pacote **a0fe1c192c4df561284036e7c7c2ec36**, backup **953cde0f0dc0619ae1d60f5e**. Troca 0.30.1 → 0.31.0 ativa, sondas antes/depois aprovadas, reativação silenciosa em worker independente. O recibo não alega execução de novo ciclo de activation hook nem prontidão comercial.

Novas requisições: system/capabilities=0.31.0 e system/health healthy=true. Core 1.52.1 publicou `passagens_24h={"cli":24,"http_cron":271,"manual":0}` — valores da observação, sujeitos a evolução. SELECT sintético retornou passagens_24h="7", contagem_passagens="3" (representação textual do driver SQL), password/access_token=[redigido], com apenas essas duas colunas no inventário de redação. Nenhuma credencial real foi usada na prova.

`system/guide`: índice e todos os **30 documentos, 32 páginas, 212650 bytes UTF-8**, com expected_sha256 e cursor até o fim, comparados aos conteúdos locais e hashes. Manuais de contratos/histórico conservam seus títulos originais; envelope de versão, release-0310 e redacao identificam a entrega corrente. O arquivo ZIP temporário foi removido com guarda de hash; nenhuma rota/arquivo PHP de QA foi criado no Site-Teste. Backups e auditorias normais foram preservados. Cinco laboratórios descartáveis foram removidos após encerrar seus serviços.

## 5. Banco, configuração e volta de versão

Nenhuma migração de schema ou configuração nova. A projeção já existente de auditoria passa pelo saneamento antes de ser persistida; continua sem argumentos/resultados brutos. Auditorias e recibos normais de instalação/teste foram produzidos. Leituras sintéticas no Site-Teste não criaram tabelas nem dados de negócio.

Voltar para 0.30.1 reintroduz o falso positivo de passagens. O backup do uploader cobre arquivos; restauração não desfaz banco, registros de auditoria, tráfego de sondas ou efeitos externos anteriores. O recibo informa corretamente database_effects_reversible=false e business_readiness_verified=false. Não foi executado downgrade no site compartilhado.

## 6. Limites, responsáveis e credenciais

- Não foram executados fluxos comerciais com contas reais Google/Meta/LinkedIn/Pipedrive, entrega de correio ou operações na frota. Responsáveis: donos dos respectivos serviços e mantenedores dos pacotes. Meta terminou sem conexões; Pipedrive permaneceu sem autorização operacional.
- Os 48 casos OAuth/CIMD são regressões nativas com HTTP controlado; não constituem nova homologação de um login interativo de terceiro nem encerramento de pendências históricas desse fluxo.
- Não foram exercitados todos os bancos/runtimes, multisite, todos os clientes MCP ou todos os formatos arbitrários de segredo. Preservação do objeto/schema e mascaramento foram avaliados nos casos declarados. Não se afirma “impacto zero” universal.
- Publicação raw e distribuição aos demais sites não executadas. Responsável pela frota confere os hashes abaixo antes de distribuir. Nenhuma ação comercial ou alteração de outro plugin é exigida por esta entrega.

Não há credencial nova a preencher nem campo novo de configuração. Tela existente: **Ferramentas → Fator3 MCP**. Perfis de conexão e autorizações atuais permanecem. O dono não deve reemitir senhas/tokens para instalar esta atualização.

## 7. Identidade da entrega

| Artefato | Arquivo | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | wp-mcp-fator3-0.31.0-instalador.zip | 883088 | `2285c633b5d11c9990bed376f17291612b44958b073e0db2489efac20c1ec4ef` |
| Fonte | wp-mcp-fator3-0.31.0-fonte.zip | 4330580 | `f8b80acd519a1d9800e97aac52c490e3aba96355b6ed95e81f5c61f88c0242ce` |

Relatório: **wp-mcp-fator3-0.31.0-relatorio.md**. Instalador com uma raiz wp-mcp-fator3; fonte com uma raiz wp-mcp-fator3-0.31.0-fonte, código, build, testes, documentos, entradas e evidências sanitizadas. Nenhum ZIP contém outro ZIP da entrega. Só o instalador é instalável no WordPress. Fonte gerado uma única vez após congelar o instalador e a cópia interna do relatório; seu hash fica no relatório externo, sem circularidade.
