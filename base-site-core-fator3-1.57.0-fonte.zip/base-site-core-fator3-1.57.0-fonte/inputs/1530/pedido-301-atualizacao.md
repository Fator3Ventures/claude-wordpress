# Consolidação da atualização do usuário — 25/10/2026, 17h19

Substitui o item 301 da cópia recebida em pedidos.md. Implementar uma quarta isca sem alterar as três atuais; rótulo Segmento de atuação, name segmento_atuacao sugeridos; chave aceita no envio e no complemento; campo ausente em cache aceito. Sinal próprio e filtro histórico.

Nova option por site: por sinal, suspeito e aviso, operável em config-core-escrever com simulação/revisao_esperada e na tela. Aviso é OR entre sinais que causaram suspeita e mantém contato_valido. Supressão também impede contingência, persiste motivo/marca/contribuidores; CRM só após aprovação. Defaults antigos preservados; nova isca true/true. como-usar assunto avisos com regras e 7/30 dias. CTO Office: nova e ctodesenvolvimento true/false depois da entrega, outros sinais no padrão; demais 11 sites no padrão.

Aceite: campos reais autopreenchidos e isca vazia em Chrome/Edge desktop e Android, Safari macOS/iOS, Firefox, Samsung Internet, Instagram/Facebook/Kwai e gerenciador; casos de política, configuração simulada/gravada/relida, cache antigo aceito e HTML dos dois formulários CTO Office. Observar 30 dias. Evidência adicional fator3.com.br record_id 438090a5b520f901062c06f2ba07fd41 confirma preenchimento da isca sem rótulo; não removê-la.

O relatório deve distinguir teste estático de prova em navegadores e documentar schema/defaults/casos. Não existe garantia universal decorrente de um token HTML; qualquer parte não comprovada fica explicitamente pendente.
