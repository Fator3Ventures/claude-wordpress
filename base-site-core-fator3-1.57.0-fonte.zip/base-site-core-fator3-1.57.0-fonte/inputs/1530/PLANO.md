# Plano da release 1.53.0

Base imutável: Core 1.52.1, contrato 8.17.0. Pedidos Core 299–301; MCP 0.31.0. Nova versão prevista 1.53.0, contrato aditivo 8.18.0. Instalador ainda não gerado.

- 299: ignorar apenas `ativo` da configuração aposentada; comparar conteúdo por chave; nomes de divergências sem valores; revisão e travas preservadas.
- 300: caixa por site, IMAP TLS sem ext-imap e MIME maduro com namespace isolado; ativação explícita com marco UID, outbox durável, descarte auditável, nenhuma conversão ou resposta automática ao contato recebido por e-mail; SMTP PHPMailer, cota compartilhada, confirmação por revisão, cópia IMAP, thread e CRM da mesma unidade. Configuração nova permanece desligada até credencial/caixa preparada.
- 301: Segmento de atuação / segmento_atuacao, rótulo e ID únicos, ocultação preservada, sinal novo; as três iscas atuais preservadas e páginas em cache aceitas. `autocomplete=off` e atributos de exclusão dos gerenciadores, sem alegação de garantia universal. Matriz de navegadores não disponíveis será pendência explícita.

Impactos emitidos: MCP (verificação coordenada da capacidade `f3base_enviar_email` no perfil Manutenção e novas operações de correio). Trabalho Core prossegue usando contratos existentes. Nenhum outro pacote será editado.

O mascaramento de contadores do impacto 1.52.1 foi atendido pelo MCP 0.31.0 segundo seu relatório; será comprovado na integração. A atualização pedida do documento MCP incorpora a nova consequência técnica, sem reabrir a demanda atendida.

Provas: regressões 299/301, protocolo IMAP/SMTP controlado, parsing MIME, descarte/deduplicação/crash/cursor/UIDVALIDITY, envio/revisão/cota/permissão, unidade CRM, instalação limpa e atualização 1.52.1, docs completas e Site-Teste. Fornecedor real exige caixa configurada; não substituir credenciais nem enviar a clientes. Frota/publicação não integra esta rodada.

## Atualização explícita do pedido 301, 25/10 às 17h19

A quarta isca convive com as três atuais. Nova option f3base_formularios_sinais: por sinal, suspeito/aviso. Defaults preservam os atuais e ativam suspeita/aviso da nova isca. Aviso usa OR entre os sinais de suspeita e exige contato válido; supressão exclui contingência e guarda snapshot/contagens. CTO Office deverá receber configuração própria depois de instalar esta release; demais sites permanecem no padrão.

Fechamento do escopo: a seleção por unidade é interna ao Core. O cliente de operação pipedrive-api-client/1.0.0 não mudou; não há demanda nova ao plugin Pipedrive. O rascunho correspondente não é documento de impacto emitido.
