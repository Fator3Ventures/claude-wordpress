# Observações de execução — 1.51.0

As falhas preliminares abaixo foram resolvidas no harness/processo e não contam como testes aprovados.

- A fixture antiga de credenciais esperava rejeição local de EAAshort. O pedido 295 remove esse mínimo arbitrário; a fixture de formato inválido passou a usar JSON colado no campo, e request-295 prova que token curto aceito pela Meta é salvo.
- A fixture antiga do consumidor LinkedIn usava token curto, Client ID com hífen e apenas dois scopes. O LinkedIn 0.10.1 recebido agora valida o cadastro. Atualizados somente os dados sintéticos para token longo, Client ID alfanumérico e scopes de leitura exigidos, preservando rw_conversions. A prova subsequente passou sem alterar o acompanhante ou o Core.
- Um comando de sincronização/documentação usou caminho relativo ao diretório errado. Corrigido o destino, os testes afetados e a geração documental foram reexecutados com o runtime final.
- A leitura em bloco dos nove segmentos base64 do instalador excedeu o limite de saída local. Nenhum segmento havia sido enviado nessa tentativa. A transferência foi feita por segmento, com hash final conferido pelo canal.
- O teste de atualização agora semeia explicitamente duas credenciais sintéticas cifradas no banco descartável, conferindo a abertura antes do snapshot. A base 1.50.0 valida novas credenciais remotamente, portanto a semeadura antiga sem HTTP não demonstrava preservação de cifra. A atualização final preservou os hashes dessas credenciais e os dados comerciais sem alterações.

Não foi identificado achado que exigisse alterar o instalador após sua instalação final no Site-Teste. O arquivo entregue conserva SHA-256 7d6c9b8391e8f3a83a85dacbabea56cf93da6f6b04e7e195fcdceb4774f9f192. Logs locais foram examinados para os marcadores sintéticos de credenciais das suítes 294/295; nenhum marcador apareceu. Nenhum log bruto integra a entrega.
