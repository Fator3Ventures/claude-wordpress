<?php
/** 0.3 regressions: verified storage, truthful diagnostics and resumable workflows. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Ability, Admin, Audit, Connections, Crypto, Gate, Lock, Options, Plugin, Preflight, Records, SelfTest, Setup, SetupAdmin};
use Fator3\McpGoogle\Auth\{Credentials, OAuthFlow};
use Fator3\McpGoogle\Automation\{Jobs, Reports};
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\SearchConsole\Workflow;
use PHPUnit\Framework\TestCase;

/** Storage reads bypass get_option filters, just as the production SQL read does. */
final class VerificationDb extends \F3_Test_Wpdb {
    public string $last_error = '';
    public int $fail_read = 0;
    private int $reads = 0;
    public function get_row( $sql, $format ) {
        preg_match( "/option_name = '([^']+)'/", $sql, $m ); $key = stripslashes( $m[1] );
        $this->last_error = '';
        if ( 0 === strpos( $key, 'f3_mcp_google_enabled' ) && ++$this->reads === $this->fail_read ) { $this->last_error = 'simulated read failure'; return null; }
        return array_key_exists( $key, $GLOBALS['f3_test_options'] ) ? array( 'option_value' => maybe_serialize( $GLOBALS['f3_test_options'][ $key ] ) ) : null;
    }
    public function query( $sql ) {
        if ( 0 === strpos( $sql, 'INSERT IGNORE' ) ) { preg_match( "/VALUES \(('.*')\)$/", $sql, $values ); preg_match_all( "/'((?:[^'\\\\]|\\\\.)*)'/", $values[1], $parts ); $key = stripslashes( $parts[1][0] ); if ( isset( $GLOBALS['f3_test_options'][ $key ] ) ) { return 0; } $GLOBALS['f3_test_options'][ $key ] = maybe_unserialize( stripslashes( $parts[1][1] ) ); return 1; }
        preg_match( "/option_name = '([^']+)' AND option_value = '(.*)'$/", $sql, $m );
        if ( $m ) { $key = stripslashes( $m[1] ); if ( maybe_serialize( $GLOBALS['f3_test_options'][ $key ] ?? null ) === stripslashes( $m[2] ) ) { unset( $GLOBALS['f3_test_options'][ $key ] ); return 1; } }
        return 0;
    }
}
final class UpgradeTest extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = $GLOBALS['f3_test_user_caps'] = array();
        $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1;
        $_POST = $_GET = array(); FakeHttp::reset(); Plugin::register_abilities();
        Options::set( Options::ENABLED, true );
    }
    protected function tearDown(): void { $GLOBALS['f3_test_write_fail'] = $GLOBALS['f3_test_user_caps'] = array(); $_POST = $_GET = array(); FakeHttp::reset(); }
    private function oauth( array $services = array( 'gsc' => 'write' ) ): void {
        Options::batch_verified( array( Options::AUTH_MODE => 'oauth', Options::OAUTH_CLIENT_ID => 'dummy.apps.googleusercontent.com', Connections::SERVICES => $services ), array( Options::OAUTH_CLIENT_SECRET => 'dummy-secret', Options::OAUTH_REFRESH_TOKEN => 'dummy-refresh' ) );
        Options::set( Options::OAUTH_SCOPES, Credentials::scopes_for( 'any' ) );
        foreach ( $services as $service => $level ) { Credentials::remember( Credentials::cache_key( Credentials::scopes_for( $service ), 'dummy.apps.googleusercontent.com' ), 'dummy-access', 3000 ); }
        for ( $i = 0; $i < 10; ++$i ) { FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'dummy-access', 'expires_in' => 3600 ) ); }
        foreach ( array( 'search-console' => 'searchconsole-v1', 'sheets' => 'sheets-v4', 'drive' => 'drive-v3' ) as $api => $file ) { set_transient( Discovery::cache_key( $api ), json_decode( file_get_contents( __DIR__ . '/fixtures/discovery/' . $file . '.json' ), true ), 3000 ); }
    }
    private function execute( string $route, array $input = array() ): array { return wp_get_ability( $route )->execute( $input ); }
    private function api_requests(): array { return array_values( array_filter( FakeHttp::$requests, static fn( $r ) => false === strpos( $r['url'], 'oauth2.googleapis.com/token' ) ) ); }
    public function test_verified_write_and_unchanged_are_successful(): void {
        $first = Options::set( Options::HTTP_TIMEOUT, 25 ); $again = Options::set( Options::HTTP_TIMEOUT, 25 );
        $this->assertTrue( $first['persisted'] ); $this->assertTrue( $first['changed'] ); $this->assertTrue( $again['success'] ); $this->assertFalse( $again['changed'] );
    }
    public function test_refused_storage_does_not_report_success(): void {
        $GLOBALS['f3_test_write_fail'][ Options::ENABLED ] = true;
        $r = Options::set( Options::ENABLED, false );
        $this->assertFalse( $r['persisted'] ); $this->assertSame( 'f3_google_option_persistence', $r['error_code'] ); $this->assertTrue( Options::get( Options::ENABLED ) );
    }
    public function test_direct_confirmation_cannot_be_spoofed_by_read_filter(): void {
        $GLOBALS['wpdb'] = new VerificationDb(); $GLOBALS['f3_test_write_fail'][ Options::ENABLED ] = true;
        $filter = static fn() => false; // WP false means no shortcut; use a truthy string to spoof a different target.
        $filter = static fn() => 'desired'; add_filter( 'pre_option_' . Options::ENABLED, $filter );
        try { $r = Options::set( Options::ENABLED, 'desired' ); $this->assertFalse( $r['success'] ); } finally { remove_filter( 'pre_option_' . Options::ENABLED, $filter ); }
    }
    /** @dataProvider read_failures */
    public function test_read_failures_are_distinct( int $at, string $code ): void {
        $db = new VerificationDb(); $db->fail_read = $at; $GLOBALS['wpdb'] = $db;
        $r = Options::set( Options::ENABLED, false ); $this->assertFalse( $r['persisted'] ); $this->assertSame( $code, $r['error_code'] );
    }
    public function read_failures(): array { return array( array( 1, 'f3_google_option_read' ), array( 2, 'f3_google_option_verify_read' ) ); }
    public function test_secret_write_verifies_cipher_and_hides_values(): void {
        $r = Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'dummy-private' );
        $this->assertTrue( $r['persisted'] ); $this->assertSame( '', get_option( Options::OAUTH_CLIENT_SECRET ) );
        $this->assertSame( 'dummy-private', Options::get_secret( Options::OAUTH_CLIENT_SECRET ) );
        $this->assertStringNotContainsString( 'dummy-private', json_encode( $r ) );
        $this->assertFalse( Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'dummy-private' )['changed'] );
    }
    public function test_crypto_exception_writes_nothing_and_unlocks(): void {
        $filter = static function() { throw new \RuntimeException( 'private exception' ); }; add_filter( 'f3_mcp_google_crypto_backend', $filter );
        try { $r = Options::batch_verified( array( Options::SA_SUBJECT => 'new@example.test' ), array( Options::SA_JSON => 'dummy-key' ) ); $single = Options::set_secret( Options::SA_JSON, 'dummy-key' ); }
        finally { remove_filter( 'f3_mcp_google_crypto_backend', $filter ); }
        $this->assertSame( 'f3_google_crypto_encrypt', $r['error_code'] ); $this->assertSame( 'f3_google_crypto_encrypt', $single['error_code'] );
        $this->assertNull( Options::get( Options::SA_SUBJECT ) ); $this->assertTrue( Options::set_secret( Options::SA_JSON, 'dummy-new' )['success'] );
    }
    public function test_batch_rolls_back_prior_writes_on_failure(): void {
        Options::set( Options::SA_SUBJECT, 'old@example.test' ); $GLOBALS['f3_test_write_fail'][ Options::AUTH_MODE ] = true;
        $r = Options::batch_verified( array( Options::SA_SUBJECT => 'new@example.test', Options::AUTH_MODE => 'oauth' ) );
        $this->assertFalse( $r['success'] ); $this->assertSame( 'old@example.test', Options::get( Options::SA_SUBJECT ) ); $this->assertTrue( $r['rollback'][ Options::SA_SUBJECT ]['success'] );
    }
    public function test_busy_option_is_machine_readable(): void {
        $lock = Lock::acquire( 'option:' . Options::ENABLED );
        try { $this->assertSame( 'f3_google_option_busy', Options::set( Options::ENABLED, false )['error_code'] ); } finally { Lock::release( $lock ); }
    }
    /** @dataProvider switches */
    public function test_admin_switch_never_announces_refused_write( string $handler, string $option, string $success_action ): void {
        $GLOBALS['f3_test_write_fail'][ $option ] = true; $_POST = array( 'enable' => '0' );
        try { Admin::$handler(); $this->fail( 'redirect required' ); } catch ( \F3_Test_Redirect $r ) { $this->assertStringContainsString( 'save_failed', $r->location ); }
        $this->assertNotContains( $success_action, array_column( Audit::recent(), 'action' ) ); $this->assertContains( 'configuration:rejected', array_column( Audit::recent(), 'action' ) );
    }
    public function switches(): array { return array( array( 'handle_toggle', Options::ENABLED, 'channel:disable' ), array( 'handle_toggle_ga', Options::GA_ENABLED, 'ga:disable' ), array( 'handle_toggle_ads', Options::ADS_ENABLED, 'ads:disable' ) ); }
    public function test_local_selftest_and_live_failure_remain_distinct(): void {
        $this->oauth(); FakeHttp::push( '/webmasters/v3/sites', 403, array( 'error' => array( 'message' => 'forbidden', 'code' => 403 ) ) );
        $r = $this->execute( 'google/selftest', array( 'live' => true ) );
        $this->assertFalse( $r['success'] ); $this->assertTrue( $r['execution_success'] ); $this->assertFalse( $r['checks_passed'] );
        $this->assertSame( 'f3_google_selftest_failed', $r['error_code'] ); $this->assertGreaterThan( 0, $r['failed'] );
    }
    public function test_exception_does_not_claim_selftest_execution(): void {
        $method = new \ReflectionMethod( Ability::class, 'run' ); $method->setAccessible( true );
        $r = $method->invoke( null, 'google/selftest', 'any', static function() { throw new \RuntimeException( 'test' ); }, array() );
        $this->assertFalse( $r['execution_success'] ); $this->assertFalse( $r['checks_passed'] );
    }
    public function test_skipped_is_not_counted_as_passed(): void {
        $r = SelfTest::summarize( array( array( 'name' => 'a', 'status' => 'passed', 'ok' => true ), array( 'name' => 'b', 'status' => 'skipped', 'ok' => false ) ) );
        $this->assertSame( 1, $r['passed'] ); $this->assertSame( 1, $r['skipped'] ); $this->assertFalse( $r['all_checks_passed'] ); $this->assertFalse( $r['complete'] );
    }
    public function test_cache_encrypts_and_invalidates_old_plaintext(): void {
        Credentials::remember( 'f3_mcp_google_tok_dummy', 'dummy-access-secret', 300 );
        $this->assertSame( 'dummy-access-secret', Credentials::cached( 'f3_mcp_google_tok_dummy' ) );
        $this->assertStringNotContainsString( 'dummy-access-secret', get_transient( 'f3_mcp_google_tok_dummy' ) );
        set_transient( 'f3_mcp_google_tok_legacy', 'old-plaintext', 300 );
        $this->assertSame( '', Credentials::cached( 'f3_mcp_google_tok_legacy' ) ); $this->assertFalse( get_transient( 'f3_mcp_google_tok_legacy' ) );
    }
    public function test_connection_credentials_cache_and_context_are_isolated(): void {
        $this->oauth(); $default = Credentials::cache_key( array( Credentials::SCOPE_GA ) );
        $this->assertTrue( Connections::create( 'other', 'Outra' )['created'] );
        Connections::run( 'other', function() use ( $default ) { $this->assertSame( '', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) ); $this->assertNotSame( $default, Credentials::cache_key( array( Credentials::SCOPE_GA ) ) ); Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'other-refresh' ); } );
        $this->assertSame( 'default', Connections::id() ); $this->assertSame( 'dummy-refresh', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
        $this->assertSame( '', get_option( 'f3_mcp_google_conn_other_oauth_refresh_token' ) );
        $this->assertFalse( Connections::create( 'other', 'Outra' )['created'] );
    }
    public function test_corrupt_secret_is_not_reported_as_missing(): void {
        $this->oauth(); $GLOBALS['f3_test_options'][ Options::OAUTH_REFRESH_TOKEN ] = 'corrupted';
        $this->assertSame( 'f3_google_crypto_decrypt', Gate::check( 'gsc' )['error_code'] );
    }
    public function test_oauth_local_disconnect_preserves_client_and_never_revokes(): void {
        $this->oauth(); $r = OAuthFlow::disconnect();
        $this->assertTrue( $r['local_disconnected'] ); $this->assertNull( $r['remote_revoked'] ); $this->assertSame( 0, FakeHttp::count() );
        $this->assertSame( 'dummy-secret', Options::get_secret( Options::OAUTH_CLIENT_SECRET ) ); $this->assertSame( '', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
    }
    public function test_revoke_failure_is_separate_from_local_disconnect(): void {
        $this->oauth(); FakeHttp::push( '/revoke', 503, array( 'error' => array( 'code' => 503, 'message' => 'unavailable' ) ) );
        $r = OAuthFlow::disconnect( true ); $this->assertFalse( $r['success'] ); $this->assertTrue( $r['local_disconnected'] ); $this->assertFalse( $r['remote_revoked'] ); $this->assertCount( 1, $this->api_requests() );
    }
    public function test_preflight_checks_exact_property_and_labels_it(): void {
        $this->oauth(); FakeHttp::push( '/sites/https%3A%2F%2Fexample.test%2F', 200, array( 'siteUrl' => 'https://example.test/' ) );
        $r = Preflight::run( array( 'services' => array( 'gsc' ), 'bindings' => array( 'gsc_site_url' => 'https://example.test/' ) ) );
        $this->assertTrue( $r['all_checks_passed'], json_encode( $r ) ); $this->assertTrue( $r['checks'][0]['resource_tested'] ); $this->assertSame( 'https://example.test/', $r['checks'][0]['target'] );
    }
    public function test_retry_after_over_budget_returns_without_retry(): void {
        FakeHttp::push( '/drive/v3/files', 403, array( 'error' => array( 'errors' => array( array( 'reason' => 'userRateLimitExceeded' ) ), 'message' => 'quota' ) ), array( 'retry-after' => '3600' ) );
        $r = GoogleClient::get( GoogleClient::HOST_GOOGLE . '/drive/v3/files', array(), array( 'auth' => false, 'budget_seconds' => 5 ) );
        $this->assertTrue( $r->get_error_data()['retryable'] ); $this->assertSame( 3600, $r->get_error_data()['retry_after'] ); $this->assertSame( 1, FakeHttp::count() );
    }
    public function test_selected_read_profile_prevents_api_write(): void {
        $this->oauth( array( 'gsc' => 'read' ) );
        $r = GoogleClient::request( 'PUT', GoogleClient::HOST_GOOGLE . '/webmasters/v3/sites/x/sitemaps/y', null, array( 'mode' => 'write', 'auth' => false ) );
        $this->assertSame( 'f3_google_service_read_only', $r->get_error_code() ); $this->assertSame( 0, FakeHttp::count() );
    }
    public function test_setup_plan_does_not_write_and_apply_is_repeatable(): void {
        $input = array( 'services' => array( 'gsc' => 'read' ), 'bindings' => array( 'gsc_site_url' => 'https://example.test/' ), 'validate_access' => false );
        $this->assertTrue( Setup::plan( $input )['success'] ); $this->assertNull( Options::get( Connections::SERVICES ) );
        $a = Setup::apply( $input ); $b = Setup::apply( $input ); $this->assertTrue( $a['persisted'] ); $this->assertTrue( $b['persisted'] );
        $this->assertEmpty( array_filter( $b['changes'], static fn( $c ) => $c['changed'] ) ); $this->assertSame( 0, FakeHttp::count() );
    }
    public function test_setup_failed_access_leaves_config_unchanged(): void {
        $this->oauth(); FakeHttp::push( '/webmasters/v3/sites', 403, array( 'error' => array( 'message' => 'no access' ) ) );
        $r = Setup::apply( array( 'bindings' => array( 'gsc_site_url' => 'https://example.test/' ) ) );
        $this->assertFalse( $r['success'] ); $this->assertNull( Options::get( Connections::BINDINGS ) );
    }
    public function test_import_requires_correct_oauth_callback_before_writing(): void {
        $r = SetupAdmin::import( json_encode( array( 'web' => array( 'client_id' => 'dummy', 'client_secret' => 'dummy', 'redirect_uris' => array( 'https://wrong.test/' ) ) ) ) );
        $this->assertSame( 'f3_google_oauth_redirect', $r['error_code'] ); $this->assertNull( Options::get( Options::OAUTH_CLIENT_ID ) );
    }
    public function test_existing_sitemap_is_not_resubmitted(): void {
        $this->oauth(); FakeHttp::push( '/sitemaps/', 200, array( 'isPending' => true ) );
        $r = Workflow::sitemap( array( 'site_url' => 'https://example.test/', 'sitemap_url' => 'https://example.test/wp-sitemap.xml' ) );
        $this->assertTrue( $r['registered'] ); $this->assertFalse( $r['submitted'] ); $this->assertSame( 'pending', $r['processing_state'] ); $this->assertSame( array( 'GET' ), array_column( $this->api_requests(), 'method' ) );
    }
    public function test_sitemap_check_only_never_submits(): void {
        $this->oauth(); FakeHttp::push( '/sitemaps/', 404, array( 'error' => array( 'message' => 'not found' ) ) );
        $r = Workflow::sitemap( array( 'site_url' => 'https://example.test/', 'sitemap_url' => 'https://example.test/wp-sitemap.xml', 'check_only' => true ) );
        $this->assertTrue( $r['submission_required'] ); $this->assertFalse( $r['submitted'] ); $this->assertSame( array( 'GET' ), array_column( $this->api_requests(), 'method' ) );
    }
    public function test_job_creation_idempotency_and_input_conflict(): void {
        $input = array( 'task' => 'preflight', 'parameters' => array( 'services' => array( 'gsc' ) ), 'idempotency_key' => 'same' );
        $a = Jobs::create( $input ); $b = Jobs::create( $input ); $input['parameters'] = array(); $c = Jobs::create( $input );
        $this->assertTrue( $a['created'] ); $this->assertFalse( $b['created'] ); $this->assertSame( $a['job_id'], $b['job_id'] ); $this->assertSame( 'f3_google_job_key_conflict', $c['error_code'] ); $this->assertSame( 0, FakeHttp::count() );
    }
    public function test_jobs_reject_secrets_and_wrong_property_urls(): void {
        $this->assertFalse( Jobs::create( array( 'task' => 'query', 'parameters' => array( 'nested' => array( 'access_token' => 'dummy' ) ) ) )['success'] );
        $this->assertFalse( Jobs::create( array( 'task' => 'inspect-urls', 'parameters' => array( 'site_url' => 'https://example.test/', 'urls' => array( 'https://outside.test/' ) ) ) )['success'] );
    }
    public function test_inspection_job_resumes_one_url_at_a_time_with_cache(): void {
        $this->oauth(); $job = Jobs::create( array( 'task' => 'inspect-urls', 'parameters' => array( 'site_url' => 'https://example.test/', 'urls' => array( 'https://example.test/a', 'https://example.test/b' ) ) ) );
        FakeHttp::push( ':inspect', 200, array( 'inspectionResult' => array( 'indexStatusResult' => array( 'verdict' => 'PASS' ) ) ) );
        $a = Jobs::run( $job['job_id'] ); $this->assertSame( 1, $a['job']['cursor'], json_encode( $a ) ); $this->assertSame( 'pending', $a['job']['status'] );
        $saved = Records::get( 'job', $job['job_id'] ); $saved['run_after'] = 0; Records::put( 'job', $job['job_id'], $saved );
        FakeHttp::push( ':inspect', 403, array( 'error' => array( 'message' => 'forbidden' ) ) ); $b = Jobs::run( $job['job_id'] );
        $this->assertSame( 'completed', $b['job']['status'] ); $this->assertSame( 1, $b['job']['summary']['failed'] ); $this->assertFalse( $b['job']['summary']['all_checks_passed'] );
        $n = FakeHttp::count(); $c = Workflow::inspect( array( 'site_url' => 'https://example.test/', 'inspection_url' => 'https://example.test/a' ) ); $this->assertTrue( $c['cached'] ); $this->assertSame( $n, FakeHttp::count() );
    }
    public function test_interrupted_write_is_never_replayed(): void {
        $a = Jobs::create( array( 'task' => 'export', 'parameters' => array() ) ); $job = Records::get( 'job', $a['job_id'] ); $job['status'] = 'running'; Records::put( 'job', $a['job_id'], $job );
        $r = Jobs::run( $a['job_id'] ); $this->assertSame( 'unknown', $r['job']['status'] ); $this->assertFalse( $r['executed'] ); $this->assertSame( 0, FakeHttp::count() );
    }
    public function test_revoked_creator_stops_job_before_any_http(): void {
        $a = Jobs::create( array( 'task' => 'preflight', 'parameters' => array() ) ); $GLOBALS['f3_test_user_caps'][1] = false;
        $r = Jobs::run( $a['job_id'] ); $this->assertSame( 'f3_google_job_permission', $r['error_code'] ); $this->assertSame( 0, FakeHttp::count() );
    }
    public function test_job_results_are_paginated_and_inputs_opt_in(): void {
        $job = array( 'task' => 'inspect-urls', 'parameters' => array( 'urls' => array() ), 'results' => range( 0, 100 ) );
        $r = Jobs::view( $job, 20, 10 ); $this->assertCount( 10, $r['results'] ); $this->assertSame( 30, $r['page']['next_offset'] ); $this->assertSame( 101, $r['page']['total'] ); $this->assertArrayNotHasKey( 'parameters', $r );
    }
    public function test_schedule_rejects_recurring_writes_and_can_pause(): void {
        $this->assertFalse( Jobs::schedule( array( 'task' => 'export' ) )['success'] );
        $r = Jobs::schedule( array( 'task' => 'preflight', 'parameters' => array(), 'schedule_id' => 'daily', 'enabled' => false ) );
        $this->assertTrue( $r['success'] ); $this->assertFalse( $r['schedule']['enabled'] ); Jobs::tick(); $this->assertCount( 0, Records::list( 'job' ) );
    }
    public function test_retained_records_are_protected_options(): void {
        $a = Jobs::create( array( 'task' => 'preflight', 'parameters' => array() ) );
        $this->assertContains( Records::key( 'job', $a['job_id'] ), Options::all_names() );
    }
    public function test_invalid_service_account_does_not_change_subject(): void {
        Options::set( Options::SA_SUBJECT, 'old@example.test' ); $_POST = array( 'sa_subject' => 'new@example.test', 'sa_json' => '{"type":"invalid"}' );
        try { Admin::handle_save_sa(); $this->fail( 'redirect required' ); } catch ( \F3_Test_Redirect $r ) { $this->assertStringNotContainsString( 'f3_status=saved', $r->location ); }
        $this->assertSame( 'old@example.test', Options::get( Options::SA_SUBJECT ) );
    }
    public function test_sitemap_submission_retains_empty_put_and_confirms_pending(): void {
        $this->oauth(); $site = home_url( '/' ); $sitemap = $site . 'wp-sitemap.xml';
        FakeHttp::push( '/sitemaps/', 404, array( 'error' => array( 'message' => 'missing' ) ) );
        FakeHttp::push( $sitemap, 200, '<?xml version="1.0"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></sitemapindex>' );
        FakeHttp::push( '/sitemaps/', 404, array( 'error' => array( 'message' => 'missing' ) ) );
        FakeHttp::push( '/sitemaps/', 204, '' );
        FakeHttp::push( '/sitemaps/', 200, array( 'isPending' => true ) );
        FakeHttp::push( '/sitemaps/', 200, array( 'isPending' => true ) );
        $r = Workflow::sitemap( array( 'site_url' => $site, 'sitemap_url' => $sitemap ) );
        $this->assertTrue( $r['submitted'], json_encode( $r ) ); $this->assertSame( 'pending', $r['processing_state'] );
        $puts = array_values( array_filter( $this->api_requests(), static fn( $r ) => 'PUT' === $r['method'] ) );
        $this->assertCount( 1, $puts ); $this->assertSame( '0', $puts[0]['headers']['Content-Length'] ); $this->assertSame( '', $puts[0]['body'] );
    }
    public function test_page_drop_report_compares_periods_without_missing_as_zero(): void {
        $this->oauth();
        FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'keys' => array( 'https://example.test/a' ), 'clicks' => 40, 'impressions' => 500, 'ctr' => 0.08, 'position' => 5 ) ) ) );
        FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'keys' => array( 'https://example.test/a' ), 'clicks' => 100, 'impressions' => 1000, 'ctr' => 0.1, 'position' => 3 ), array( 'keys' => array( 'https://example.test/b' ), 'clicks' => 50, 'impressions' => 100, 'ctr' => 0.5, 'position' => 2 ) ) ) );
        $r = Reports::run( array( 'template' => 'organic-page-drops', 'accounts' => array( 'https://example.test/' ) ) );
        $this->assertTrue( $r['success'], json_encode( $r ) ); $this->assertEquals( -60, $r['page_changes'][0]['change_percent'] ); $this->assertNull( $r['page_changes'][1]['current_clicks'] );
    }
    public function test_low_ctr_template_filters_only_returned_rows_and_retains_warning(): void {
        $this->oauth(); FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'keys' => array( 'query a' ), 'clicks' => 1, 'impressions' => 1000, 'ctr' => 0.001, 'position' => 5 ), array( 'keys' => array( 'query b' ), 'clicks' => 10, 'impressions' => 100, 'ctr' => 0.1, 'position' => 3 ) ) ) );
        $r = Reports::run( array( 'template' => 'low-ctr-queries', 'accounts' => array( 'https://example.test/' ) ) );
        $this->assertTrue( $r['success'], json_encode( $r ) ); $this->assertCount( 1, $r['rows'] ); $this->assertNotEmpty( $r['warnings'] );
    }
    public function test_monitor_uses_totals_and_preserves_source_caveats(): void {
        $this->oauth();
        foreach ( array( 4, 4, 100 ) as $clicks ) { FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'keys' => array( 'https://example.test/a' ), 'clicks' => $clicks, 'impressions' => 1000, 'ctr' => $clicks / 1000, 'position' => 5 ) ) ) ); }
        $r = Reports::run( array( 'template' => 'organic-pages', 'accounts' => array( 'https://example.test/' ), 'alert' => array( 'metric' => 'clicks' ) ) );
        $this->assertTrue( $r['monitor']['evaluated'], json_encode( $r ) ); $this->assertTrue( $r['monitor']['triggered'] ); $this->assertNull( $r['monitor']['causal_attribution'] ); $this->assertNotEmpty( $r['monitor']['warnings'] );
    }
    public function test_schedule_dispatch_is_repeatable_and_restores_current_user(): void {
        Jobs::schedule( array( 'task' => 'preflight', 'parameters' => array( 'services' => array( 'gsc' ) ), 'schedule_id' => 'daily' ) );
        $GLOBALS['f3_test_user'] = 2; Jobs::tick(); Jobs::tick();
        $this->assertCount( 1, Records::list( 'job' ) ); $this->assertSame( 2, get_current_user_id() ); $this->assertSame( 'default', Connections::id() );
    }

}
