<?php
/**
 * Compatibilidade com a Abilities API NATIVA do WordPress 6.9+.
 *
 * Todos os outros arquivos de teste rodam contra o polyfill, que aceita
 * qualquer entrada e devolve qualquer saída. O núcleo do 6.9 não: ele valida a
 * entrada contra o `input_schema` ANTES de executar e a saída contra o
 * `output_schema` DEPOIS — e uma saída que não valida vira `WP_Error`, ou seja,
 * o agente recebe um erro no lugar do relatório que a rota produziu
 * corretamente. Um esquema errado, portanto, não falha em nenhum outro teste
 * desta suíte; falha no site do cliente.
 *
 * Este arquivo fecha essa lacuna com `Support/JsonSchema.php`, que reproduz as
 * regras do núcleo para type/properties/required/additionalProperties/items/
 * enum/oneOf, e as aplica às 21 rotas nos dois desfechos: sucesso e falha.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Ads\Abilities as AdsAbilities;
use Fator3\McpGoogle\Analytics\Abilities as AnalyticsAbilities;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Unified\Abilities as UnifiedAbilities;
use Fator3\McpGoogle\Unified\Catalog;
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/Support/JsonSchema.php';

final class SchemaTest extends TestCase {

	private const SA_EMAIL = 'robo-esquema@projeto-teste.iam.gserviceaccount.com';

	private const DEV_TOKEN = 'DEVTOKEN-ESQUEMA-321';

	/** @var array{private:string,public:string}|null */
	private static ?array $keys = null;

	/** @var bool */
	private static bool $registered = false;

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;

		FakeHttp::reset();
		Catalog::flush();

		if ( ! self::$registered ) {
			AnalyticsAbilities::register();
			AdsAbilities::register();
			UnifiedAbilities::register();
			self::$registered = true;
		}

		$this->enable_all();
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	private static function keys(): array {
		if ( null === self::$keys ) {
			$pair = openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			);

			$private = '';
			openssl_pkey_export( $pair, $private );
			$details = openssl_pkey_get_details( $pair );

			self::$keys = array(
				'private' => $private,
				'public'  => (string) $details['key'],
			);
		}

		return self::$keys;
	}

	private function enable_all(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set( Options::GA_DEFAULT_PROPERTY, '123456' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, self::DEV_TOKEN );
		Options::set_secret(
			Options::SA_JSON,
			(string) wp_json_encode(
				array(
					'type'         => 'service_account',
					'project_id'   => 'projeto-teste',
					'private_key'  => self::keys()['private'],
					'client_email' => self::SA_EMAIL,
					'token_uri'    => 'https://oauth2.googleapis.com/token',
				)
			)
		);

		foreach ( array( 'ga', 'ads', 'any' ) as $connector ) {
			Credentials::remember(
				Credentials::cache_key( Credentials::scopes_for( $connector ), self::SA_EMAIL ),
				'tok-de-esquema',
				3600
			);
		}
	}

	/**
	 * Entrada mínima válida de cada uma das 21 rotas, na ordem do registro.
	 *
	 * @return array<string,array>
	 */
	public static function inputs(): array {
		return array(
			'ga/get-account-summaries'      => array(),
			'ga/get-property-details'       => array( 'property_id' => '123456' ),
			'ga/list-google-ads-links'      => array( 'property_id' => 123456 ),
			'ga/list-property-annotations'  => array( 'property_id' => 'properties/123456' ),
			'ga/get-metadata'               => array(
				'custom_only' => false,
				'query'       => 'sess',
			),
			'ga/check-compatibility'        => array(
				'dimensions' => array( 'date' ),
				'metrics'    => array( array( 'name' => 'sessions' ) ),
			),
			'ga/run-report'                 => array(
				'date_ranges' => array(
					array(
						'startDate' => '7daysAgo',
						'endDate'   => 'yesterday',
					),
				),
				'dimensions'  => array( 'date' ),
				'metrics'     => array( 'sessions' ),
				'limit'       => 10,
			),
			'ga/run-realtime-report'        => array(
				'dimensions' => array( 'country' ),
				'metrics'    => array( 'activeUsers' ),
			),
			'ga/run-conversions-report'     => array(
				'date_ranges'     => array(
					array(
						'startDate' => '7daysAgo',
						'endDate'   => 'yesterday',
					),
				),
				'dimensions'      => array( 'campaignName' ),
				'metrics'         => array( 'advertiserAdCost' ),
				'conversion_spec' => array( 'conversion_actions' => array( 'purchase' ) ),
			),
			'ga/run-funnel-report'          => array(
				'funnel_steps' => array(
					array(
						'name'  => 'Início',
						'event' => 'session_start',
					),
				),
			),
			'ads/list-accessible-customers' => array( 'with_details' => false ),
			'ads/get-customer'              => array( 'customer_id' => '123-456-7890' ),
			'ads/search'                    => array(
				'customer_id' => 1234567890,
				'query'       => 'SELECT campaign.id, campaign.name FROM campaign',
				'format'      => 'table',
			),
			'ads/get-resource-metadata'     => array( 'resource_name' => 'campaign' ),
			'ads/list-resources'            => array( 'query' => 'campaign' ),
			'ads/list-customer-clients'     => array(
				'manager_customer_id' => '1234567890',
				'include_hidden'      => true,
				'all_levels'          => false,
			),
			'google/status'                 => array( 'live' => false ),
			'google/selftest'               => array( 'live' => false ),
			'google/list-accounts'          => array( 'connector' => 'all' ),
			'google/list-fields'            => array( 'connector' => 'ga4' ),
			'google/query'                  => array(
				'connector'  => 'ga4',
				'accounts'   => array( 'properties/123456' ),
				'metrics'    => array( 'sessions' ),
				'dimensions' => array( 'date' ),
				'date_range' => 'last_7_days',
				'limit'      => 10,
			),
		);
	}

	/**
	 * @return array<string,array{0:string,1:array}>
	 */
	public static function rotas(): array {
		$rows = array();

		foreach ( self::inputs() as $name => $input ) {
			$rows[ $name ] = array( $name, $input );
		}

		return $rows;
	}

	/**
	 * Uma resposta "vazia mas válida" para qualquer uma das três APIs, e um
	 * erro da Google — o suficiente para exercitar os dois desfechos de todas
	 * as rotas sem depender do corpo real de cada uma.
	 *
	 * @param bool $ok  Sucesso ou erro.
	 * @param int  $how Quantas respostas enfileirar.
	 */
	private function fill_queue( bool $ok, int $how = 60 ): void {
		$success = array(
			'accountSummaries'         => array(),
			'googleAdsLinks'           => array(),
			'reportingDataAnnotations' => array(),
			'dimensionHeaders'         => array(),
			'metricHeaders'            => array(),
			'rows'                     => array(),
			'rowCount'                 => 0,
			'dimensions'               => array(),
			'metrics'                  => array(),
			'results'                  => array(),
			'resourceNames'            => array(),
		);

		$failure = array(
			'error' => array(
				'code'    => 403,
				'status'  => 'PERMISSION_DENIED',
				'message' => 'A credencial não tem acesso a este recurso.',
			),
		);

		for ( $i = 0; $i < $how; $i++ ) {
			$this->push_response( $ok, $success, $failure );
		}
	}

	/**
	 * @param bool  $ok      Sucesso ou erro.
	 * @param array $success Corpo de sucesso.
	 * @param array $failure Corpo de erro.
	 */
	private function push_response( bool $ok, array $success, array $failure ): void {
		if ( $ok ) {
			FakeHttp::push( '*', 200, $success );
			return;
		}

		FakeHttp::push( '*', 403, $failure );
	}

	// =========================================================================
	// (1) input_schema — o que o núcleo do 6.9 exige
	// =========================================================================

	/**
	 * @dataProvider rotas
	 */
	public function test_input_schema_e_bem_formado_para_o_nucleo( string $name, array $input ): void {
		unset( $input );

		$schema = wp_get_ability( $name )->get_input_schema();

		$this->assertSame( 'object', $schema['type'], $name );
		$this->assertFalse( $schema['additionalProperties'], $name );
		$this->assertIsArray( $schema['properties'], $name );

		foreach ( (array) ( $schema['required'] ?? array() ) as $required ) {
			$this->assertArrayHasKey( $required, $schema['properties'], $name . ': required fora de properties' );
		}

		foreach ( $schema['properties'] as $property => $definition ) {
			$label = $name . '.' . $property;

			$this->assertIsArray( $definition, $label );
			$this->assertArrayHasKey(
				'type',
				$definition,
				$label . ': sem "type" o WordPress 6.9 dispara _doing_it_wrong em toda chamada'
			);

			foreach ( (array) $definition['type'] as $type ) {
				$this->assertContains( $type, JsonSchema::TYPES, $label . ': tipo desconhecido' );
			}

			// `oneOf` com dois ramos que a mesma entrada satisfaz é recusa
			// garantida no núcleo ("matches 2 schemas"). Nenhuma propriedade
			// deste plugin pode usá-lo — `type` em lista faz o mesmo trabalho
			// sem a armadilha.
			$this->assertArrayNotHasKey( 'oneOf', $definition, $label . ': use type em lista, não oneOf' );

			if ( array_key_exists( 'default', $definition ) ) {
				$this->assertSame(
					true,
					JsonSchema::validate( $definition['default'], $definition, $label . '.default' ),
					$label . ': o default não passa no próprio type'
				);
			}

			foreach ( (array) ( $definition['enum'] ?? array() ) as $option ) {
				$this->assertSame(
					true,
					JsonSchema::validate( $option, array( 'type' => $definition['type'] ), $label . '.enum' ),
					$label . ': valor de enum fora do type declarado'
				);
			}
		}
	}

	/**
	 * @dataProvider rotas
	 */
	public function test_a_entrada_documentada_de_cada_rota_passa_no_esquema( string $name, array $input ): void {
		$schema = wp_get_ability( $name )->get_input_schema();

		$this->assertSame(
			true,
			JsonSchema::validate( $input, $schema, $name ),
			$name . ': a entrada de exemplo seria recusada pelo WordPress 6.9'
		);
	}

	/**
	 * @dataProvider rotas
	 */
	public function test_chave_nao_declarada_e_recusada_pelo_esquema_fechado( string $name, array $input ): void {
		$schema                  = wp_get_ability( $name )->get_input_schema();
		$input['chave_intrusa']  = 'x';

		$this->assertIsString(
			JsonSchema::validate( $input, $schema, $name ),
			$name . ': additionalProperties=false precisa recusar chave desconhecida'
		);
	}

	/**
	 * A regressão concreta: `property_id` como string numérica.
	 *
	 * Com o `oneOf: [string, integer]` que este esquema já teve, "123456" casava
	 * com os dois ramos e o núcleo recusava a chamada inteira antes de executar
	 * — justamente a forma mais comum de um agente mandar o ID.
	 *
	 * @dataProvider property_ids
	 *
	 * @param mixed $value Valor de property_id.
	 */
	public function test_property_id_aceita_numero_e_string( $value ): void {
		$schema = wp_get_ability( 'ga/run-report' )->get_input_schema();

		$this->assertSame(
			true,
			JsonSchema::validate( $schema['properties']['property_id'], array( 'type' => 'object' ), 'meta' ),
			'esquema de property_id precisa ser um objeto'
		);

		$this->assertSame(
			true,
			JsonSchema::validate( $value, $schema['properties']['property_id'], 'property_id' )
		);
	}

	/**
	 * @return array<string,array{0:mixed}>
	 */
	public static function property_ids(): array {
		return array(
			'string numérica' => array( '123456' ),
			'inteiro'         => array( 123456 ),
			'nome de recurso' => array( 'properties/123456' ),
		);
	}

	/**
	 * @dataProvider customer_ids
	 *
	 * @param mixed $value Valor de customer_id.
	 */
	public function test_customer_id_aceita_numero_hifen_e_recurso( $value ): void {
		$schema = wp_get_ability( 'ads/get-customer' )->get_input_schema();

		$this->assertSame(
			true,
			JsonSchema::validate( $value, $schema['properties']['customer_id'], 'customer_id' )
		);
	}

	/**
	 * @return array<string,array{0:mixed}>
	 */
	public static function customer_ids(): array {
		return array(
			'com hífen'  => array( '123-456-7890' ),
			'só dígitos' => array( '1234567890' ),
			'inteiro'    => array( 1234567890 ),
			'recurso'    => array( 'customers/1234567890' ),
		);
	}

	public function test_sinonimos_documentados_de_google_query_cabem_no_esquema(): void {
		$schema = wp_get_ability( 'google/query' )->get_input_schema();

		// `Query::plan()` aceita account_id e order_bys; com o esquema fechado,
		// aceitar sem declarar seria código morto no WordPress 6.9.
		$entrada = array(
			'connector'  => 'ga4',
			'account_id' => 'properties/123456',
			'metrics'    => array( 'sessions' ),
			'date_range' => 'yesterday',
			'order_bys'  => array( array( 'field' => 'sessions' ) ),
		);

		$this->assertSame( true, JsonSchema::validate( $entrada, $schema, 'google/query' ) );
	}

	public function test_google_query_com_account_id_no_lugar_de_accounts_funciona(): void {
		$this->fill_queue( true );

		$result = wp_get_ability( 'google/query' )->execute(
			array(
				'connector'  => 'ga4',
				'account_id' => 'properties/123456',
				'metrics'    => array( 'sessions' ),
				'date_range' => 'yesterday',
			)
		);

		$this->assertTrue( $result['success'], (string) $result['message'] );
	}

	// =========================================================================
	// (2) output_schema — a saída real das 21 rotas, nos dois desfechos
	// =========================================================================

	/**
	 * @dataProvider rotas
	 */
	public function test_saida_de_sucesso_valida_contra_o_output_schema( string $name, array $input ): void {
		$this->assert_output_valid( $name, $input, true );
	}

	/**
	 * @dataProvider rotas
	 */
	public function test_saida_de_falha_valida_contra_o_output_schema( string $name, array $input ): void {
		$this->assert_output_valid( $name, $input, false );
	}

	/**
	 * @param string $name  Rota.
	 * @param array  $input Entrada.
	 * @param bool   $ok    Fila de sucesso ou de erro.
	 */
	private function assert_output_valid( string $name, array $input, bool $ok ): void {
		$this->fill_queue( $ok );

		$ability = wp_get_ability( $name );
		$result  = $ability->execute( $input );

		$this->assertIsArray( $result, $name );
		$this->assertArrayHasKey( 'success', $result, $name );

		$schema = $ability->get_output_schema();

		$this->assertSame(
			true,
			JsonSchema::validate( $result, $schema, $name ),
			$name . ': a saída real não passa no próprio output_schema — no WordPress 6.9 isso vira WP_Error no lugar da resposta'
		);
	}

	/**
	 * O `output_schema` precisa continuar permissivo.
	 *
	 * `Response::fail()` acrescenta `error_code` e `details`, e cada rota
	 * acrescenta as próprias chaves (`rows`, `columns`, `warnings`, `query`…).
	 * Um `additionalProperties: false` ou um `required` além de `success`
	 * transformaria qualquer uma dessas chaves numa recusa do núcleo.
	 *
	 * @dataProvider rotas
	 */
	public function test_output_schema_nao_pode_ser_fechado( string $name, array $input ): void {
		unset( $input );

		$schema = wp_get_ability( $name )->get_output_schema();

		$this->assertSame( 'object', $schema['type'], $name );
		$this->assertArrayNotHasKey( 'additionalProperties', $schema, $name . ': fecharia a saída' );
		$this->assertEmpty( array_diff( array( 'success', 'message' ), array_keys( $schema['properties'] ) ), $name );
		$this->assertSame( 'boolean', $schema['properties']['success']['type'], $name );
		$this->assertSame( 'string', $schema['properties']['message']['type'], $name );

		$required = (array) ( $schema['required'] ?? array() );
		$this->assertEmpty(
			array_diff( $required, array( 'success' ) ),
			$name . ': required além de success recusaria respostas legítimas'
		);
	}

	/**
	 * `message` é `string` no esquema: nenhuma rota pode devolver null nela.
	 *
	 * @dataProvider rotas
	 */
	public function test_message_e_sempre_string_nos_dois_desfechos( string $name, array $input ): void {
		foreach ( array( true, false ) as $ok ) {
			FakeHttp::reset();
			$this->fill_queue( $ok );

			$result = wp_get_ability( $name )->execute( $input );

			$this->assertIsBool( $result['success'], $name );
			$this->assertIsString( $result['message'] ?? null, $name . ' (ok=' . ( $ok ? '1' : '0' ) . ')' );
		}
	}
}
