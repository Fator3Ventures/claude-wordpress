<?php
/**
 * Testes do módulo Ads: normalização de ID, montador/validador GAQL,
 * achatamento de linha (camelCase → snake_case + derivados de micros),
 * paginação/truncamento, metadados de recurso com cache, e as 6 habilidades
 * `ads/*` registradas com os padrões da casa.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Ads\Abilities as AdsAbilities;
use Fator3\McpGoogle\Ads\AdsApi;
use Fator3\McpGoogle\Ads\CustomerId;
use Fator3\McpGoogle\Ads\Gaql;
use Fator3\McpGoogle\Ads\Resources;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Options;
use PHPUnit\Framework\TestCase;

final class AdsTest extends TestCase {

	private const SA_EMAIL = 'ads-robo@projeto-teste.iam.gserviceaccount.com';

	/** @var array{private:string}|null Par de chaves gerado uma vez por processo. */
	private static ?array $keys = null;

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;

		FakeHttp::reset();

		// Idempotente: registra (ou re-registra) as 6 habilidades antes de
		// cada teste, sem depender do hook `wp_abilities_api_init` disparar.
		AdsAbilities::register();
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	private static function keys(): array {
		if ( null === self::$keys ) {
			$pair    = openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			);
			$private = '';
			openssl_pkey_export( $pair, $private );

			self::$keys = array( 'private' => $private );
		}

		return self::$keys;
	}

	private static function sa_key_array(): array {
		return array(
			'type'         => 'service_account',
			'project_id'   => 'projeto-teste',
			'private_key'  => self::keys()['private'],
			'client_email' => self::SA_EMAIL,
			'token_uri'    => 'https://oauth2.googleapis.com/token',
		);
	}

	/**
	 * Liga o canal, o conector Ads e uma credencial válida, e já deixa um
	 * access token em cache — assim os testes exercitam só as chamadas à
	 * Google Ads API, sem uma troca de JWT por token no meio de cada uma.
	 */
	private function enable_ads(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'dev-token-ads-1234' );
		Options::set_secret( Options::SA_JSON, (string) wp_json_encode( self::sa_key_array() ) );

		$key = Credentials::cache_key( Credentials::scopes_for( 'ads' ) );
		Credentials::remember( $key, 'token-ads-de-teste', 3600 );
	}

	// =========================================================================
	// CustomerId
	// =========================================================================

	public function test_customer_id_normalize_aceita_varios_formatos(): void {
		$this->assertSame( '1234567890', CustomerId::normalize( '123-456-7890' ) );
		$this->assertSame( '1234567890', CustomerId::normalize( ' 123-456-7890 ' ) );
		$this->assertSame( '1234567890', CustomerId::normalize( 'customers/1234567890' ) );
		$this->assertSame( '1234567890', CustomerId::normalize( '1234567890' ) );
		$this->assertSame( '1234567890', CustomerId::normalize( 1234567890 ) );
	}

	public function test_customer_id_normalize_recusa_formatos_invalidos(): void {
		$this->assertTrue( is_wp_error( CustomerId::normalize( '123456789' ) ), '9 dígitos' );
		$this->assertTrue( is_wp_error( CustomerId::normalize( '12345678901' ) ), '11 dígitos' );
		$this->assertTrue( is_wp_error( CustomerId::normalize( 'abc-def-ghij' ) ), 'não numérico' );
		$this->assertTrue( is_wp_error( CustomerId::normalize( '' ) ), 'vazio' );
		$this->assertTrue( is_wp_error( CustomerId::normalize( array() ) ), 'tipo errado' );
	}

	// =========================================================================
	// Gaql
	// =========================================================================

	public function test_gaql_build_sem_partes_opcionais(): void {
		$query = Gaql::build( 'campaign', array( 'campaign.id', 'campaign.name' ) );

		$this->assertSame(
			'SELECT campaign.id, campaign.name FROM campaign PARAMETERS omit_unselected_resource_names=true',
			$query
		);
	}

	public function test_gaql_build_com_conditions_orderings_e_limit(): void {
		$query = Gaql::build(
			'campaign',
			array( 'campaign.id', 'metrics.clicks' ),
			array( 'segments.date DURING LAST_7_DAYS', "campaign.status = 'ENABLED'" ),
			array( 'metrics.clicks DESC' ),
			50
		);

		$this->assertSame(
			'SELECT campaign.id, metrics.clicks FROM campaign'
				. " WHERE segments.date DURING LAST_7_DAYS AND campaign.status = 'ENABLED'"
				. ' ORDER BY metrics.clicks DESC'
				. ' LIMIT 50'
				. ' PARAMETERS omit_unselected_resource_names=true',
			$query
		);

		// PARAMETERS sempre no fim, com ou sem as partes opcionais.
		$this->assertStringEndsWith( 'PARAMETERS omit_unselected_resource_names=true', $query );
	}

	public function test_gaql_validate_aceita_consulta_simples(): void {
		$this->assertTrue( Gaql::validate( 'SELECT campaign.id FROM campaign' ) );
		$this->assertTrue( Gaql::validate( '  select campaign.id from campaign  ' ), 'minúsculo e com espaço nas pontas' );
	}

	public function test_gaql_validate_recusa_update(): void {
		$error = Gaql::validate( "UPDATE campaign SET campaign.status = 'PAUSED' WHERE campaign.id = 1" );
		$this->assertTrue( is_wp_error( $error ) );
		$this->assertSame( 'f3_google_ads_gaql_select', $error->get_error_code() );
	}

	public function test_gaql_validate_recusa_duas_instrucoes(): void {
		$error = Gaql::validate( 'SELECT campaign.id FROM campaign; SELECT ad_group.id FROM ad_group' );
		$this->assertTrue( is_wp_error( $error ) );
		$this->assertSame( 'f3_google_ads_gaql_semicolon', $error->get_error_code() );
	}

	public function test_gaql_validate_recusa_ponto_e_virgula_no_fim(): void {
		$error = Gaql::validate( 'SELECT campaign.id FROM campaign;' );
		$this->assertTrue( is_wp_error( $error ) );
		$this->assertSame( 'f3_google_ads_gaql_semicolon', $error->get_error_code() );
	}

	public function test_gaql_validate_recusa_comentario(): void {
		$this->assertSame(
			'f3_google_ads_gaql_comment',
			Gaql::validate( 'SELECT campaign.id FROM campaign -- tudo' )->get_error_code()
		);
		$this->assertSame(
			'f3_google_ads_gaql_comment',
			Gaql::validate( 'SELECT campaign.id /* comentário */ FROM campaign' )->get_error_code()
		);
	}

	public function test_gaql_validate_recusa_sem_from(): void {
		$error = Gaql::validate( 'SELECT campaign.id' );
		$this->assertTrue( is_wp_error( $error ) );
		$this->assertSame( 'f3_google_ads_gaql_from', $error->get_error_code() );
	}

	public function test_gaql_validate_recusa_vazia_e_grande_demais(): void {
		$this->assertSame( 'f3_google_ads_gaql_empty', Gaql::validate( '   ' )->get_error_code() );

		$grande = 'SELECT ' . str_repeat( 'a', 8300 ) . ' FROM campaign';
		$this->assertSame( 'f3_google_ads_gaql_size', Gaql::validate( $grande )->get_error_code() );
	}

	public function test_gaql_ensure_limit_nao_mexe_quando_ja_tem_limit(): void {
		$query = 'SELECT campaign.id FROM campaign LIMIT 10 PARAMETERS omit_unselected_resource_names=true';
		$this->assertSame( $query, Gaql::ensure_limit( $query, 999 ) );
	}

	public function test_gaql_ensure_limit_acrescenta_no_fim_sem_parameters(): void {
		$this->assertSame(
			'SELECT campaign.id FROM campaign LIMIT 5',
			Gaql::ensure_limit( 'SELECT campaign.id FROM campaign', 5 )
		);
	}

	public function test_gaql_ensure_limit_acrescenta_antes_de_parameters(): void {
		$this->assertSame(
			'SELECT campaign.id FROM campaign LIMIT 5 PARAMETERS omit_unselected_resource_names=true',
			Gaql::ensure_limit( 'SELECT campaign.id FROM campaign PARAMETERS omit_unselected_resource_names=true', 5 )
		);
	}

	public function test_gaql_identifier_ok(): void {
		$this->assertTrue( Gaql::identifier_ok( 'campaign.id' ) );
		$this->assertTrue( Gaql::identifier_ok( 'metrics.cost_micros' ) );
		$this->assertTrue( Gaql::identifier_ok( 'a' ) );

		$this->assertFalse( Gaql::identifier_ok( '' ) );
		$this->assertFalse( Gaql::identifier_ok( 'Campaign.id' ) );
		$this->assertFalse( Gaql::identifier_ok( '1campaign.id' ) );
		$this->assertFalse( Gaql::identifier_ok( 'campaign id' ) );
		$this->assertFalse( Gaql::identifier_ok( 'campaign.id;drop table' ) );
	}

	public function test_gaql_ordering_ok(): void {
		$this->assertTrue( Gaql::ordering_ok( 'metrics.clicks' ) );
		$this->assertTrue( Gaql::ordering_ok( 'metrics.clicks DESC' ) );
		$this->assertTrue( Gaql::ordering_ok( 'metrics.clicks ASC' ) );
		$this->assertTrue( Gaql::ordering_ok( 'metrics.clicks desc' ) );

		$this->assertFalse( Gaql::ordering_ok( 'metrics.clicks SIDEWAYS' ) );
		$this->assertFalse( Gaql::ordering_ok( 'Metrics.Clicks DESC' ) );
		$this->assertFalse( Gaql::ordering_ok( '' ) );
	}

	public function test_gaql_condition_ok(): void {
		$this->assertTrue( Gaql::condition_ok( "campaign.status = 'ENABLED'" ) );
		$this->assertFalse( Gaql::condition_ok( "campaign.status = 'ENABLED'; DROP" ) );
		$this->assertFalse( Gaql::condition_ok( "campaign.status = 'x' -- comentário" ) );
		$this->assertFalse( Gaql::condition_ok( "campaign.status /* c */ = 'x'" ) );
	}

	// =========================================================================
	// AdsApi::flatten_row
	// =========================================================================

	public function test_flatten_row_converte_camel_case_e_deriva_micros(): void {
		$row = array(
			'campaign' => array(
				'id'                     => '111',
				'advertisingChannelType' => 'SEARCH',
			),
			'metrics'  => array(
				'clicks'     => '10',
				'costMicros' => '2500000',
				'averageCpc' => '250000',
			),
			'segments' => array(
				'date' => '2024-01-01',
			),
		);

		$paths = array(
			'campaign.id',
			'campaign.advertising_channel_type',
			'metrics.clicks',
			'metrics.cost_micros',
			'metrics.average_cpc',
			'segments.date',
		);

		$flat = AdsApi::flatten_row( $row, $paths );

		$this->assertSame( '111', $flat['campaign.id'] );
		$this->assertSame( 'SEARCH', $flat['campaign.advertising_channel_type'] );
		$this->assertSame( '10', $flat['metrics.clicks'] );
		$this->assertSame( '2500000', $flat['metrics.cost_micros'] );
		$this->assertSame( 2.5, $flat['metrics.cost'], 'cost_micros também vira "cost" em moeda' );
		$this->assertSame( '250000', $flat['metrics.average_cpc'] );
		$this->assertSame( 0.25, $flat['metrics.average_cpc_currency'], 'average_cpc já é micros; ganha sufixo _currency' );
		$this->assertSame( '2024-01-01', $flat['segments.date'] );
	}

	public function test_flatten_row_campo_ausente_vira_null(): void {
		$flat = AdsApi::flatten_row( array( 'campaign' => array( 'id' => '1' ) ), array( 'campaign.name' ) );

		$this->assertArrayHasKey( 'campaign.name', $flat );
		$this->assertNull( $flat['campaign.name'] );
	}

	// =========================================================================
	// AdsApi::search — paginação, max_rows, truncated, cabeçalhos
	// =========================================================================

	public function test_search_pagina_ate_max_rows_e_marca_truncated(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'results'       => array(
					array( 'campaign' => array( 'id' => '1' ) ),
					array( 'campaign' => array( 'id' => '2' ) ),
				),
				'nextPageToken' => 'pagina-2',
				'fieldMask'     => 'campaign.id',
			)
		);
		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'results' => array(
					array( 'campaign' => array( 'id' => '3' ) ),
					array( 'campaign' => array( 'id' => '4' ) ),
				),
			)
		);

		$result = AdsApi::search( '123-456-7890', 'SELECT campaign.id FROM campaign', array( 'max_rows' => 3 ) );

		$this->assertIsArray( $result );
		$this->assertCount( 3, $result['rows'] );
		$this->assertTrue( $result['truncated'] );
		$this->assertNull( $result['next_page_token'] );
		$this->assertSame( array( 'campaign.id' ), $result['field_mask'] );
		$this->assertSame( 2, FakeHttp::count(), 'duas páginas precisaram ser buscadas para juntar 3 linhas' );
	}

	public function test_search_marca_truncated_na_fronteira_da_pagina_sem_buscar_a_proxima(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'results'       => array(
					array( 'campaign' => array( 'id' => '1' ) ),
					array( 'campaign' => array( 'id' => '2' ) ),
				),
				'nextPageToken' => 'pagina-2',
				'fieldMask'     => 'campaign.id',
			)
		);

		$result = AdsApi::search( '1234567890', 'SELECT campaign.id FROM campaign', array( 'max_rows' => 2 ) );

		$this->assertCount( 2, $result['rows'] );
		$this->assertTrue( $result['truncated'] );
		$this->assertSame( 'pagina-2', $result['next_page_token'] );
		$this->assertSame( 1, FakeHttp::count(), 'a página seguinte não precisa ser buscada só para descobrir que não era necessária' );
	}

	public function test_search_sem_truncamento_quando_tudo_cabe(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'results'   => array( array( 'campaign' => array( 'id' => '1' ) ) ),
				'fieldMask' => 'campaign.id',
			)
		);

		$result = AdsApi::search( '1234567890', 'SELECT campaign.id FROM campaign', array( 'max_rows' => 10 ) );

		$this->assertCount( 1, $result['rows'] );
		$this->assertFalse( $result['truncated'] );
		$this->assertNull( $result['next_page_token'] );
	}

	public function test_headers_trazem_developer_token_e_login_customer_id_da_opcao(): void {
		$this->enable_ads();
		Options::set( Options::ADS_LOGIN_CUSTOMER_ID, '999-888-7777' );

		FakeHttp::push( 'googleAds:search', 200, array( 'results' => array() ) );

		AdsApi::search( '1234567890', 'SELECT campaign.id FROM campaign' );

		$headers = FakeHttp::last()['headers'];
		$this->assertSame( 'dev-token-ads-1234', $headers['developer-token'] );
		$this->assertSame( '9998887777', $headers['login-customer-id'] );
	}

	public function test_login_customer_id_da_chamada_tem_prioridade_sobre_a_opcao(): void {
		$this->enable_ads();
		Options::set( Options::ADS_LOGIN_CUSTOMER_ID, '111-111-1111' );

		FakeHttp::push( 'googleAds:search', 200, array( 'results' => array() ) );

		AdsApi::search(
			'1234567890',
			'SELECT campaign.id FROM campaign',
			array( 'login_customer_id' => '222-222-2222' )
		);

		$this->assertSame( '2222222222', FakeHttp::last()['headers']['login-customer-id'] );
	}

	// =========================================================================
	// ads/list-accessible-customers
	// =========================================================================

	public function test_list_accessible_customers_com_detalhes_e_um_erro_individual(): void {
		$this->enable_ads();

		FakeHttp::push(
			'listAccessibleCustomers',
			200,
			array( 'resourceNames' => array( 'customers/1111111111', 'customers/2222222222' ) )
		);

		FakeHttp::push(
			'customers/1111111111/googleAds:search',
			200,
			array(
				'results'   => array(
					array(
						'customer' => array(
							'id'              => '1111111111',
							'descriptiveName' => 'Conta Um',
							'currencyCode'    => 'BRL',
							'timeZone'        => 'America/Sao_Paulo',
							'manager'         => false,
							'status'          => 'ENABLED',
							'testAccount'     => false,
						),
					),
				),
				'fieldMask' => 'customer.id,customer.descriptive_name,customer.currency_code,customer.time_zone,customer.manager,customer.status,customer.test_account',
			)
		);

		FakeHttp::push(
			'customers/2222222222/googleAds:search',
			403,
			array(
				'error' => array(
					'code'    => 403,
					'message' => 'The caller does not have permission.',
					'status'  => 'PERMISSION_DENIED',
				),
			)
		);

		$result = AdsAbilities::list_accessible_customers( array() );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 2, $result['count'] );
		$this->assertEmpty( $result['warnings'] );

		$this->assertSame( '1111111111', $result['customers'][0]['id'] );
		$this->assertSame( 'Conta Um', $result['customers'][0]['name'] );
		$this->assertSame( 'BRL', $result['customers'][0]['currency'] );
		$this->assertArrayNotHasKey( 'error', $result['customers'][0] );

		$this->assertSame( '2222222222', $result['customers'][1]['id'] );
		$this->assertArrayHasKey( 'error', $result['customers'][1] );
		$this->assertArrayNotHasKey( 'name', $result['customers'][1] );
	}

	public function test_list_accessible_customers_acima_do_teto_nao_busca_detalhe(): void {
		$this->enable_ads();

		$names = array();
		for ( $i = 0; $i < 26; $i++ ) {
			$names[] = sprintf( 'customers/1%09d', $i );
		}

		FakeHttp::push( 'listAccessibleCustomers', 200, array( 'resourceNames' => $names ) );

		$result = AdsAbilities::list_accessible_customers( array( 'with_details' => true ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 26, $result['count'] );
		$this->assertNotEmpty( $result['warnings'] );
		$this->assertArrayNotHasKey( 'name', $result['customers'][0] );
		$this->assertSame( 1, FakeHttp::count(), 'nenhuma chamada de detalhe deveria ter acontecido' );
	}

	public function test_list_accessible_customers_sem_detalhes(): void {
		$this->enable_ads();

		FakeHttp::push( 'listAccessibleCustomers', 200, array( 'resourceNames' => array( 'customers/1234567890' ) ) );

		$result = AdsAbilities::list_accessible_customers( array( 'with_details' => false ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( array( array( 'id' => '1234567890' ) ), $result['customers'] );
		$this->assertSame( 1, FakeHttp::count() );
	}

	// =========================================================================
	// ads/get-customer / ads/list-customer-clients
	// =========================================================================

	public function test_get_customer(): void {
		$this->enable_ads();

		FakeHttp::push(
			'customers/1234567890/googleAds:search',
			200,
			array(
				'results'   => array(
					array(
						'customer' => array(
							'id'              => '1234567890',
							'descriptiveName' => 'Minha Conta',
							'currencyCode'    => 'USD',
							'timeZone'        => 'America/New_York',
							'manager'         => true,
							'status'          => 'ENABLED',
							'testAccount'     => false,
						),
					),
				),
				'fieldMask' => 'customer.id,customer.descriptive_name,customer.currency_code,customer.time_zone,customer.manager,customer.status,customer.test_account',
			)
		);

		$result = AdsAbilities::get_customer( array( 'customer_id' => '123-456-7890' ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 'Minha Conta', $result['customer']['name'] );
		$this->assertTrue( $result['customer']['is_manager'] );
		$this->assertSame( '1234567890', FakeHttp::last()['headers']['login-customer-id'] );
	}

	public function test_list_customer_clients(): void {
		$this->enable_ads();

		FakeHttp::push(
			'customers/9999999999/googleAds:search',
			200,
			array(
				'results'   => array(
					array(
						'customerClient' => array(
							'id'              => '1112223333',
							'descriptiveName' => 'Cliente A',
							'level'           => '1',
							'manager'         => false,
							'status'          => 'ENABLED',
							'currencyCode'    => 'BRL',
							'timeZone'        => 'America/Sao_Paulo',
							'hidden'          => false,
						),
					),
				),
				'fieldMask' => 'customer_client.id,customer_client.descriptive_name,customer_client.level,customer_client.manager,customer_client.status,customer_client.currency_code,customer_client.time_zone,customer_client.hidden',
			)
		);

		$result = AdsAbilities::list_customer_clients( array( 'manager_customer_id' => '999-999-9999' ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 1, $result['count'] );
		$this->assertSame( '1112223333', $result['clients'][0]['id'] );
		$this->assertSame( 'Cliente A', $result['clients'][0]['name'] );
		$this->assertSame( 1, $result['clients'][0]['level'] );
		$this->assertFalse( $result['clients'][0]['is_manager'] );

		$sent = FakeHttp::last();
		$this->assertStringContainsString( 'customer_client.level <= 1', (string) $sent['body'] );
		$this->assertStringContainsString( 'customer_client.hidden = FALSE', (string) $sent['body'] );
		$this->assertSame( '9999999999', $sent['headers']['login-customer-id'] );
	}

	public function test_list_customer_clients_todos_os_niveis_e_ocultos(): void {
		$this->enable_ads();

		FakeHttp::push( 'customers/9999999999/googleAds:search', 200, array( 'results' => array() ) );

		AdsAbilities::list_customer_clients(
			array(
				'manager_customer_id' => '9999999999',
				'all_levels'          => true,
				'include_hidden'      => true,
			)
		);

		$body = (string) FakeHttp::last()['body'];
		$this->assertStringNotContainsString( 'WHERE', $body, 'sem filtro de nível nem de ocultos, não deveria haver WHERE nenhum' );
		$this->assertStringNotContainsString( 'customer_client.hidden = FALSE', $body );
	}

	// =========================================================================
	// ads/get-resource-metadata — duas consultas, união, cache
	// =========================================================================

	public function test_resource_metadata_junta_duas_consultas_e_cacheia(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAdsFields:search',
			200,
			array(
				'results' => array(
					array(
						'name'       => 'campaign.id',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => true,
					),
					array(
						'name'       => 'campaign.name',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => true,
					),
				),
			)
		);
		FakeHttp::push(
			'googleAdsFields:search',
			200,
			array(
				'results' => array(
					array(
						'name'       => 'metrics.clicks',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => false,
					),
					array(
						'name'       => 'segments.date',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => true,
					),
				),
			)
		);

		$meta = AdsApi::resource_metadata( 'campaign' );

		$this->assertIsArray( $meta );
		$this->assertSame( 'campaign', $meta['resource'] );
		$this->assertContains( 'campaign.id', $meta['selectable'] );
		$this->assertContains( 'metrics.clicks', $meta['selectable'] );
		$this->assertContains( 'segments.date', $meta['selectable'] );
		$this->assertContains( 'campaign.id', $meta['sortable'] );
		$this->assertNotContains( 'metrics.clicks', $meta['sortable'] );
		$this->assertFalse( $meta['cached'] );
		$this->assertSame( 2, FakeHttp::count(), 'duas consultas: atributos, depois métricas/segmentos' );

		$chamadas_antes = FakeHttp::count();
		$meta2          = AdsApi::resource_metadata( 'campaign' );

		$this->assertTrue( $meta2['cached'] );
		$this->assertSame( $chamadas_antes, FakeHttp::count(), 'a segunda chamada não pode tocar a rede' );
		$this->assertSame( $meta['selectable'], $meta2['selectable'] );
	}

	public function test_ability_get_resource_metadata_separa_metrics_segments_attributes(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAdsFields:search',
			200,
			array(
				'results' => array(
					array(
						'name'       => 'campaign.id',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => true,
					),
				),
			)
		);
		FakeHttp::push(
			'googleAdsFields:search',
			200,
			array(
				'results' => array(
					array(
						'name'       => 'metrics.clicks',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => false,
					),
					array(
						'name'       => 'segments.date',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => true,
					),
				),
			)
		);

		$result = AdsAbilities::get_resource_metadata( array( 'resource_name' => 'campaign' ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( array( 'campaign.id' ), $result['attributes'] );
		$this->assertSame( array( 'metrics.clicks' ), $result['metrics'] );
		$this->assertSame( array( 'segments.date' ), $result['segments'] );
		$this->assertFalse( $result['cached'] );
	}

	// =========================================================================
	// ads/list-resources
	// =========================================================================

	public function test_resources_all_tem_os_181_recursos(): void {
		$all = Resources::all();

		$this->assertCount( 181, $all );
		$this->assertContains( 'campaign', $all );
		$this->assertContains( 'ad_group', $all );
		$this->assertContains( 'change_event', $all );
	}

	public function test_resources_search_filtra_por_trecho(): void {
		$this->assertSame( array( 'campaign_budget' ), Resources::search( 'campaign_bud' ) );
		$this->assertSame( Resources::all(), Resources::search( '' ) );
		$this->assertSame( array(), Resources::search( 'nao-existe-isso' ) );
	}

	public function test_ability_list_resources(): void {
		$result = AdsAbilities::list_resources( array( 'query' => 'keyword' ) );

		$this->assertTrue( $result['success'] );
		$this->assertGreaterThan( 0, $result['count'] );

		foreach ( $result['resources'] as $resource ) {
			$this->assertStringContainsString( 'keyword', $resource );
		}
	}

	// =========================================================================
	// ads/search — erro estruturado da Google Ads
	// =========================================================================

	public function test_search_bad_field_name_vira_success_false_com_reason(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAds:search',
			400,
			array(
				'error' => array(
					'code'    => 400,
					'message' => 'Request contains an invalid argument.',
					'status'  => 'INVALID_ARGUMENT',
					'details' => array(
						array(
							'errors'    => array(
								array(
									'errorCode' => array( 'queryError' => 'BAD_FIELD_NAME' ),
									'message'   => "Error in query: unexpected field 'campaign.nome'.",
								),
							),
							'requestId' => 'req-1',
						),
					),
				),
			)
		);

		$result = wp_get_ability( 'ads/search' )->execute(
			array(
				'customer_id' => '1234567890',
				'query'       => 'SELECT campaign.nome FROM campaign',
			)
		);

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_http', $result['error_code'] );
		$this->assertSame( 'queryError:BAD_FIELD_NAME', $result['details']['reason'] );
	}

	public function test_search_estruturado_valida_campo_antes_de_chamar_a_api(): void {
		$this->enable_ads();

		$result = wp_get_ability( 'ads/search' )->execute(
			array(
				'customer_id' => '1234567890',
				'resource'    => 'campaign',
				'fields'      => array( 'Campaign.ID' ),
			)
		);

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_ads_bad_field', $result['error_code'] );
		$this->assertSame( 0, FakeHttp::count(), 'um campo inválido não pode gerar chamada de rede' );
	}

	public function test_search_estruturado_monta_query_pagina_e_devolve_tabela(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'results'   => array(
					array(
						'campaign' => array( 'id' => '1', 'name' => 'Campanha 1' ),
						'metrics'  => array( 'clicks' => '5', 'costMicros' => '1000000' ),
					),
				),
				'fieldMask' => 'campaign.id,campaign.name,metrics.clicks,metrics.cost_micros',
			)
		);

		$result = wp_get_ability( 'ads/search' )->execute(
			array(
				'customer_id' => '1234567890',
				'resource'    => 'campaign',
				'fields'      => array( 'campaign.id', 'campaign.name', 'metrics.clicks', 'metrics.cost_micros' ),
				'orderings'   => array( 'metrics.clicks DESC' ),
				'limit'       => 10,
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame(
			array( 'campaign.id', 'campaign.name', 'metrics.clicks', 'metrics.cost_micros', 'metrics.cost' ),
			$result['columns']
		);
		$this->assertSame( array( '1', 'Campanha 1', '5', '1000000', 1.0 ), $result['rows'][0] );
		$this->assertSame( 1, $result['row_count'] );
		$this->assertFalse( $result['truncated'] );
		$this->assertStringContainsString( 'ORDER BY metrics.clicks DESC', $result['query'] );
		$this->assertStringContainsString( 'LIMIT 10', $result['query'] );
	}

	public function test_search_formato_raw(): void {
		$this->enable_ads();

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'results'   => array( array( 'campaign' => array( 'id' => '1' ) ) ),
				'fieldMask' => 'campaign.id',
			)
		);

		$result = wp_get_ability( 'ads/search' )->execute(
			array(
				'customer_id' => '1234567890',
				'query'       => 'SELECT campaign.id FROM campaign',
				'format'      => 'raw',
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame( array( array( 'campaign.id' => '1' ) ), $result['rows'] );
		$this->assertArrayNotHasKey( 'columns', $result );
		$this->assertSame( array( 'campaign.id' ), $result['field_mask'] );
	}

	// =========================================================================
	// Portão: sem developer token, canal fechado, conector desligado
	// =========================================================================

	public function test_recusa_sem_developer_token(): void {
		$this->enable_ads();
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, '' );

		$result = wp_get_ability( 'ads/list-resources' )->execute( array() );

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_ads_no_developer_token', $result['error_code'] );
	}

	public function test_recusa_com_canal_fechado(): void {
		$this->enable_ads();
		Options::set( Options::ENABLED, false );

		$ability = wp_get_ability( 'ads/list-resources' );
		$this->assertFalse( $ability->check_permissions( array() ) );

		$result = $ability->execute( array() );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_disabled', $result['error_code'] );
	}

	public function test_recusa_com_conector_ads_desligado(): void {
		$this->enable_ads();
		Options::set( Options::ADS_ENABLED, false );

		$result = wp_get_ability( 'ads/list-resources' )->execute( array() );

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_connector_off', $result['error_code'] );
	}

	// =========================================================================
	// Registro das 6 habilidades e execução via polyfill
	// =========================================================================

	public function test_as_seis_habilidades_estao_registradas_com_os_padroes_da_casa(): void {
		$names = array(
			'ads/list-accessible-customers',
			'ads/get-customer',
			'ads/search',
			'ads/get-resource-metadata',
			'ads/list-resources',
			'ads/list-customer-clients',
		);

		foreach ( $names as $name ) {
			$ability = wp_get_ability( $name );
			$this->assertNotNull( $ability, $name );

			$meta = $ability->get_meta();
			$this->assertTrue( $meta['mcp']['public'], $name );
			$this->assertSame( 'tool', $meta['mcp']['type'], $name );
			$this->assertTrue( $meta['annotations']['readonly'], $name );
			$this->assertSame( 'google', $ability->get_category(), $name );

			$schema = $ability->get_input_schema();
			$this->assertSame( 'object', $schema['type'], $name );
			$this->assertFalse( $schema['additionalProperties'], $name );

			$properties = $schema['properties'] ?? array();
			foreach ( (array) ( $schema['required'] ?? array() ) as $required_field ) {
				$this->assertArrayHasKey( $required_field, $properties, $name . ' / ' . $required_field );
			}

			$description = $ability->get_description();
			$this->assertNotSame( '', $description, $name );
			$this->assertLessThanOrEqual( 400, mb_strlen( $description ), $name . ' (' . mb_strlen( $description ) . ' chars)' );
		}
	}

	public function test_execucao_via_polyfill_wp_get_ability(): void {
		$this->enable_ads();

		$ability = wp_get_ability( 'ads/list-resources' );
		$this->assertNotNull( $ability );
		$this->assertTrue( $ability->check_permissions( array() ) );

		$result = $ability->execute( array( 'query' => 'campaign' ) );

		$this->assertTrue( $result['success'] );
		$this->assertGreaterThan( 0, $result['count'] );
	}
}
