<?php
/** Integration of named Ads routes with real v25 schemas and simulated HTTP. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Ads\Mutate;
use Fator3\McpGoogle\Ads\WriteAbilities;
use Fator3\McpGoogle\Ads\Conversions;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Unified\Query;
use PHPUnit\Framework\TestCase;

final class AdsWriteTest extends TestCase {
	private const CID = '1234567890';
	private static ?array $key = null;
	private static ?array $discovery = null;
	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = array(); $GLOBALS['f3_test_transients'] = array(); $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1; $GLOBALS['f3_test_user_caps'] = array();
		FakeHttp::reset();
		Options::set( Options::ENABLED, true ); Options::set( Options::ADS_ENABLED, true ); Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'dev-token-fixture-ads' );
		if ( null === self::$key ) {
			$key = openssl_pkey_new( array( 'private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA ) ); $pem = ''; openssl_pkey_export( $key, $pem );
			self::$key = array( 'type' => 'service_account', 'client_email' => 'ads@fixture.iam.gserviceaccount.com', 'project_id' => 'fixture', 'private_key' => $pem, 'token_uri' => 'https://oauth2.googleapis.com/token' );
		}
		Options::set_secret( Options::SA_JSON, (string) wp_json_encode( self::$key ) );
		Credentials::remember( Credentials::cache_key( Credentials::scopes_for( 'ads' ) ), 'ads-test-access-token', 3600 );
		if ( null === self::$discovery ) { self::$discovery = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/discovery/googleads-v25.json' ), true ); }
		set_transient( Discovery::cache_key( 'google-ads' ), self::$discovery, 86400 );
		Mutate::register(); WriteAbilities::register();
	}
	private static function rn( string $collection, string $id = '1' ): string { return 'customers/' . self::CID . '/' . $collection . '/' . $id; }
	private function invoke( string $route, array $input ): array {
		$ability = wp_get_ability( 'ads/' . $route ); $this->assertNotNull( $ability );
		$result = $ability->execute( array_merge( array( 'customer_id' => self::CID ), $input ) );
		if ( is_wp_error( $result ) ) { return array( 'success' => false, 'error_code' => $result->get_error_code(), 'message' => $result->get_error_message() ); }
		return $result;
	}
	private function snapshots( int $count = 4 ): void {
		for ( $i = 0; $i < $count; ++$i ) { FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'campaign.resource_name,campaign.status', 'results' => array( array( 'campaign' => array( 'resourceName' => self::rn( 'campaigns' ), 'status' => 'PAUSED' ) ) ) ) ); }
	}
	public static function named_routes(): array {
		$rows = array();
		$resources = array(
			'campaigns' => array( 'name' => 'Fixture campaign', 'status' => 'PAUSED', 'advertisingChannelType' => 'SEARCH', 'campaignBudget' => self::rn( 'campaignBudgets' ), 'manualCpc' => array() ),
			'campaignBudgets' => array( 'name' => 'Fixture budget', 'amountMicros' => '1000000', 'deliveryMethod' => 'STANDARD' ),
			'adGroups' => array( 'name' => 'Fixture group', 'campaign' => self::rn( 'campaigns' ), 'status' => 'PAUSED', 'cpcBidMicros' => '10000' ),
			'adGroupAds' => array( 'adGroup' => self::rn( 'adGroups' ), 'status' => 'PAUSED', 'ad' => array( 'finalUrls' => array( 'https://example.com/' ), 'responsiveSearchAd' => array( 'headlines' => array( array( 'text' => 'First' ), array( 'text' => 'Second' ), array( 'text' => 'Third' ) ), 'descriptions' => array( array( 'text' => 'One description.' ), array( 'text' => 'Other description.' ) ) ) ) ),
			'adGroupCriteria' => array( 'adGroup' => self::rn( 'adGroups' ), 'keyword' => array( 'text' => 'fixture', 'matchType' => 'EXACT' ) ),
			'conversionActions' => array( 'name' => 'Purchase fixture', 'type' => 'UPLOAD_CLICKS', 'category' => 'PURCHASE' ),
			'assets' => array( 'name' => 'Text fixture', 'textAsset' => array( 'text' => 'Asset fixture' ) ),
			'assetGroups' => array( 'name' => 'PMax fixture', 'campaign' => self::rn( 'campaigns' ), 'status' => 'PAUSED', 'finalUrls' => array( 'https://example.com/' ) ),
			'experiments' => array( 'name' => 'Experiment fixture', 'type' => 'SEARCH_CUSTOM', 'status' => 'SETUP', 'suffix' => 'exp' ),
			'labels' => array( 'name' => 'Label fixture' ),
			'userLists' => array( 'name' => 'User list fixture', 'membershipLifeSpan' => '30', 'crmBasedUserList' => array( 'uploadKeyType' => 'CONTACT_INFO' ) ),
		);
		$map = array( 'campaign' => 'campaigns', 'budget' => 'campaignBudgets', 'ad-group' => 'adGroups', 'conversion-action' => 'conversionActions', 'asset' => 'assets', 'asset-group' => 'assetGroups', 'experiment' => 'experiments', 'user-list' => 'userLists' );
		foreach ( $map as $slug => $collection ) { $rows[ 'create-' . $slug ] = array( 'create-' . $slug, $collection, array( 'resource' => $resources[ $collection ] ), false ); }
		foreach ( array( 'campaign', 'budget', 'ad-group', 'conversion-action' ) as $slug ) { $collection = $map[ $slug ]; $rows[ 'update-' . $slug ] = array( 'update-' . $slug, $collection, array( 'resource' => array( 'resourceName' => self::rn( $collection ), 'name' => 'Updated fixture' ) ), false ); }
		foreach ( array( 'campaign', 'ad-group' ) as $slug ) { $collection = $map[ $slug ]; $rows[ 'remove-' . $slug ] = array( 'remove-' . $slug, $collection, array( 'resource_name' => self::rn( $collection ) ), false ); }
		$rows['create-responsive-search-ad'] = array( 'create-responsive-search-ad', 'adGroupAds', array( 'resource' => $resources['adGroupAds'] ), false );
		$rows['update-ad-status'] = array( 'update-ad-status', 'adGroupAds', array( 'resource' => array( 'resourceName' => self::rn( 'adGroupAds', '1~2' ), 'status' => 'PAUSED' ) ), false );
		$rows['remove-ad'] = array( 'remove-ad', 'adGroupAds', array( 'resource_name' => self::rn( 'adGroupAds', '1~2' ) ), false );
		$rows['add-keywords'] = array( 'add-keywords', 'adGroupCriteria', array( 'resources' => array( $resources['adGroupCriteria'] ) ), false );
		$rows['update-keyword'] = array( 'update-keyword', 'adGroupCriteria', array( 'resource' => array( 'resourceName' => self::rn( 'adGroupCriteria', '1~2' ), 'cpcBidMicros' => '500000' ) ), false );
		$rows['remove-keywords'] = array( 'remove-keywords', 'adGroupCriteria', array( 'resource_names' => array( self::rn( 'adGroupCriteria', '1~2' ) ) ), false );
		$rows['add-negative-keywords'] = array( 'add-negative-keywords', 'campaignCriteria', array( 'level' => 'campaign', 'resources' => array( array( 'campaign' => self::rn( 'campaigns' ), 'keyword' => array( 'text' => 'free', 'matchType' => 'BROAD' ) ) ) ), false );
		$rows['remove-negative-keywords'] = array( 'remove-negative-keywords', 'campaignCriteria', array( 'resource_names' => array( self::rn( 'campaignCriteria', '1~2' ) ) ), false );
		$rows['link-asset'] = array( 'link-asset', 'campaignAssets', array( 'resource' => array( 'campaign' => self::rn( 'campaigns' ), 'asset' => self::rn( 'assets' ), 'fieldType' => 'HEADLINE' ) ), false );
		$rows['add-label'] = array( 'add-label', 'labels', array( 'resource' => $resources['labels'] ), false );
		$rows['apply-label'] = array( 'apply-label', 'campaignLabels', array( 'resource' => array( 'campaign' => self::rn( 'campaigns' ), 'label' => self::rn( 'labels' ) ) ), false );
		$rows['add-audience-to-campaign'] = array( 'add-audience-to-campaign', 'campaignCriteria', array( 'resource' => array( 'campaign' => self::rn( 'campaigns' ), 'userList' => array( 'userList' => self::rn( 'userLists' ) ) ) ), false );
		$rows['invite-user'] = array( 'invite-user', 'customerUserAccessInvitations', array( 'resource' => array( 'emailAddress' => 'user@example.com', 'accessRole' => 'READ_ONLY' ) ), true );
		$rows['update-user-access'] = array( 'update-user-access', 'customerUserAccesses', array( 'resource' => array( 'resourceName' => self::rn( 'customerUserAccesses' ), 'accessRole' => 'READ_ONLY' ) ), true );
		$rows['remove-user'] = array( 'remove-user', 'customerUserAccesses', array( 'resource_name' => self::rn( 'customerUserAccesses' ) ), true );
		$rows['create-billing-setup'] = array( 'create-billing-setup', 'billingSetups', array( 'resource' => array( 'paymentsAccount' => self::rn( 'paymentsAccounts' ), 'startTimeType' => 'NOW' ) ), true );
		return $rows;
	}
	/** @dataProvider named_routes */
	public function test_each_named_write_reaches_its_real_method_and_body( string $route, string $collection, array $input, bool $singular ): void {
		$this->snapshots(); FakeHttp::push( '/' . $collection . ':mutate', 200, array() );
		$result = $this->invoke( $route, $input );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$request = $this->mutation_request(); $this->assertStringContainsString( '/v25/customers/' . self::CID . '/' . $collection . ':mutate', $request['url'] );
		$body = json_decode( $request['body'], true ); $this->assertArrayHasKey( $singular ? 'operation' : 'operations', $body );
		if ( $singular ) { $this->assertArrayNotHasKey( 'validateOnly', $body ); } else { $this->assertFalse( $body['validateOnly'] ); }
		if ( 'add-negative-keywords' === $route ) { $this->assertTrue( $body['operations'][0]['create']['negative'] ); }
		if ( 0 === strpos( $route, 'update-' ) ) { $this->assertNotEmpty( $body[ $singular ? 'operation' : 'operations' ][ $singular ? 'updateMask' : 0 ] ); }
	}
	/** @dataProvider named_routes */
	public function test_each_named_write_dry_run_is_real_or_rejected_without_mutation( string $route, string $collection, array $input, bool $singular ): void {
		$this->snapshots(); FakeHttp::push( '/' . $collection . ':mutate', 200, array() );
		$result = $this->invoke( $route, $input + array( 'dry_run' => true ) );
		if ( $singular ) { $this->assertFalse( $result['success'] ); $this->assertSame( 'f3_google_dry_run_unsupported', $result['error_code'] ); $this->assertCount( 0, FakeHttp::$requests ); }
		else { $this->assertTrue( $result['success'], (string) wp_json_encode( $result ) ); $this->assertTrue( json_decode( $this->mutation_request()['body'], true )['validateOnly'] ); }
	}
	/** @dataProvider named_routes */
	public function test_each_named_write_preserves_google_errors_and_does_not_retry( string $route, string $collection, array $input ): void {
		$this->snapshots(); FakeHttp::push( '/' . $collection . ':mutate', 403, array( 'error' => array( 'code' => 403, 'status' => 'PERMISSION_DENIED', 'message' => 'USER_PERMISSION_DENIED' ) ) );
		$result = $this->invoke( $route, $input ); $this->assertFalse( $result['success'] );
		$this->assertStringContainsString( 'USER_PERMISSION_DENIED', $result['message'] );
		$this->assertCount( 1, array_filter( FakeHttp::$requests, static function ( $r ) { return false !== strpos( $r['url'], ':mutate' ); } ) );
	}
	/** @dataProvider named_routes */
	public function test_every_named_write_obeys_wordpress_capability( string $route, string $collection, array $input ): void {
		$GLOBALS['f3_test_caps'] = false; $result = $this->invoke( $route, $input );
		$this->assertFalse( $result['success'] ); $this->assertCount( 0, FakeHttp::$requests );
	}
	private function mutation_request(): array {
		foreach ( FakeHttp::$requests as $request ) { if ( false !== strpos( $request['url'], ':mutate' ) || false !== strpos( $request['url'], ':uploadClickConversions' ) ) { return $request; } }
		$this->fail( 'No mutation request.' );
	}
	public function test_atomic_asset_group_and_experiment_arms_use_temporary_references(): void {
		foreach ( array( 'create-asset-group' => array( 'assets', 'assetGroupOperation', 'assetGroupAssetOperation', 'assetGroup' ), 'create-experiment' => array( 'arms', 'experimentOperation', 'experimentArmOperation', 'experiment' ) ) as $route => $spec ) {
			FakeHttp::reset(); FakeHttp::push( '/googleAds:mutate', 200, array() );
			$input = self::named_routes()[ $route ][2];
			$input[ $spec[0] ] = 'arms' === $spec[0] ? array( array( 'name' => 'Control', 'control' => true, 'trafficSplit' => '50', 'campaigns' => array( self::rn( 'campaigns' ) ) ), array( 'name' => 'Treatment', 'control' => false, 'trafficSplit' => '50', 'campaigns' => array( self::rn( 'campaigns', '2' ) ) ) ) : array( array( 'asset' => self::rn( 'assets' ), 'fieldType' => 'HEADLINE' ) );
			$result = $this->invoke( $route, $input + array( 'dry_run' => true ) ); $this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
			$body = json_decode( $this->mutation_request()['body'], true );
			$temp = $body['mutateOperations'][0][ $spec[1] ]['create']['resourceName']; $this->assertStringEndsWith( '/-1', $temp );
			$this->assertSame( $temp, $body['mutateOperations'][1][ $spec[2] ]['create'][ $spec[3] ] ); $this->assertFalse( $body['partialFailure'] ); $this->assertTrue( $body['validateOnly'] );
		}
	}
	public function test_click_conversion_route_uses_actual_discovery_id_and_partial_failure(): void {
		FakeHttp::push( ':uploadClickConversions', 200, array() );
		$result = $this->invoke( 'upload-click-conversions', array( 'dry_run' => true, 'partial_failure' => true, 'conversions' => array( array( 'gclid' => 'fixture', 'conversionAction' => self::rn( 'conversionActions' ), 'conversionDateTime' => '2026-09-01 12:00:00+00:00', 'conversionValue' => 15.0, 'currencyCode' => 'BRL' ) ) ) );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$body = json_decode( $this->mutation_request()['body'], true ); $this->assertTrue( $body['validateOnly'] ); $this->assertTrue( $body['partialFailure'] );
	}
	public function test_hashes_google_normalization_and_keeps_identifiers_separate(): void {
		$result = WriteAbilities::normalize_user( array( 'email' => ' Test.User@Gmail.com ', 'phone' => '+55 (11) 99999-9999', 'first_name' => ' João ', 'last_name' => ' Silva ', 'country_code' => 'br', 'postal_code' => '01000-000' ) );
		$this->assertSame( hash( 'sha256', 'testuser@gmail.com' ), $result['userIdentifiers'][0]['hashedEmail'] );
		$this->assertSame( hash( 'sha256', '+5511999999999' ), $result['userIdentifiers'][1]['hashedPhoneNumber'] );
		$this->assertSame( hash( 'sha256', 'joão' ), $result['userIdentifiers'][2]['addressInfo']['hashedFirstName'] );
		$this->assertTrue( is_wp_error( WriteAbilities::normalize_user( array( 'phone' => '11999999999' ) ) ) );
		$this->assertTrue( is_wp_error( WriteAbilities::normalize_user( array( 'userIdentifiers' => array( array( 'hashedEmail' => 'raw@example.com' ) ) ) ) ) );
	}
	public function test_customer_match_creates_uploads_and_starts_job_without_leaking_users_in_audit(): void {
		$job = self::rn( 'offlineUserDataJobs', '5' );
		FakeHttp::push( 'offlineUserDataJobs:create', 200, array( 'resourceName' => $job ) );
		FakeHttp::push( ':addOperations', 200, array() ); FakeHttp::push( ':run', 200, array( 'name' => 'customers/' . self::CID . '/operations/xyz' ) ); $this->snapshots();
		$result = $this->invoke( 'upload-customer-match', array( 'users' => array( array( 'email' => 'Customer.Example@gmail.com' ) ), 'user_list' => self::rn( 'userLists' ), 'consent' => array( 'adUserData' => 'GRANTED', 'adPersonalization' => 'GRANTED' ) ) );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) ); $this->assertTrue( $result['job_started'] ); $this->assertSame( $job, $result['job_resource_name'] );
		$requests = array_values( array_filter( FakeHttp::$requests, static function ( $r ) { return false !== strpos( $r['url'], ':addOperations' ); } ) );
		$body = json_decode( $requests[0]['body'], true ); $this->assertSame( hash( 'sha256', 'customerexample@gmail.com' ), $body['operations'][0]['create']['userIdentifiers'][0]['hashedEmail'] );
		$audit = (string) wp_json_encode( get_option( Options::AUDIT, array() ) ); $this->assertStringNotContainsString( 'Customer.Example', $audit ); $this->assertStringNotContainsString( hash( 'sha256', 'customerexample@gmail.com' ), $audit );
	}
	public function test_customer_match_dry_run_never_creates_a_job(): void {
		$result = $this->invoke( 'upload-customer-match', array( 'dry_run' => true, 'users' => array( array( 'email' => 'user@example.com' ) ), 'user_list' => self::rn( 'userLists' ) ) );
		$this->assertFalse( $result['success'] ); $this->assertCount( 0, FakeHttp::$requests );
		FakeHttp::reset(); $this->snapshots(); FakeHttp::push( ':addOperations', 200, array() ); FakeHttp::push( ':run', 200, array() );
		$result = $this->invoke( 'upload-customer-match', array( 'dry_run' => true, 'job_resource_name' => self::rn( 'offlineUserDataJobs', '5' ), 'users' => array( array( 'email' => 'user@example.com' ) ) ) );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) ); $this->assertFalse( $result['job_started'] );
		foreach ( FakeHttp::$requests as $request ) { $this->assertStringNotContainsString( 'offlineUserDataJobs:create', $request['url'] ); if ( false === strpos( $request['url'], 'googleAds:search' ) ) { $this->assertTrue( json_decode( $request['body'], true )['validateOnly'] ); } }
	}
	public function test_custom_metrics_join_preserves_common_clicks_and_cost_totals(): void {
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'conversion_action.resource_name,conversion_action.name', 'results' => array( array( 'conversionAction' => array( 'resourceName' => self::rn( 'conversionActions' ), 'name' => 'Purchase' ) ), array( 'conversionAction' => array( 'resourceName' => self::rn( 'conversionActions', '2' ), 'name' => 'Lead' ) ) ) ) );
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'segments.date,metrics.clicks,metrics.cost_micros', 'results' => array( array( 'segments' => array( 'date' => '2026-09-01' ), 'metrics' => array( 'clicks' => '100', 'costMicros' => '50000000' ) ) ) ) );
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'segments.date,segments.conversion_action_name,metrics.conversions,metrics.conversions_value', 'results' => array( array( 'segments' => array( 'date' => '2026-09-01', 'conversionActionName' => 'Purchase' ), 'metrics' => array( 'conversions' => 3, 'conversionsValue' => 150 ) ), array( 'segments' => array( 'date' => '2026-09-01', 'conversionActionName' => 'Lead' ), 'metrics' => array( 'conversions' => 7, 'conversionsValue' => 0 ) ) ) ) );
		$result = Query::run( array( 'connector' => 'ads', 'accounts' => array( self::CID ), 'dimensions' => array( 'date' ), 'metrics' => array( 'clicks', 'cost', 'conversions:Purchase', 'conversions:Lead', 'conversions_value:Purchase' ), 'date_range' => array( 'start_date' => '2026-09-01', 'end_date' => '2026-09-01' ) ) );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$this->assertSame( array( '2026-09-01', 100, 50.0, 3.0, 7.0, 150.0 ), $result['rows'][0] );
		$this->assertStringNotContainsString( 'conversion_action_name', json_decode( FakeHttp::$requests[1]['body'], true )['query'] );
		$this->assertStringNotContainsString( 'metrics.clicks', json_decode( FakeHttp::$requests[2]['body'], true )['query'] );
	}
	public static function complementary_reads(): array {
		return array_map( static function ( $route ) { return array( $route ); }, array( 'get-campaign', 'list-conversion-actions', 'list-assets', 'list-audiences', 'list-users', 'list-experiments' ) );
	}
	/** @dataProvider complementary_reads */
	public function test_complementary_reads_use_gaql_and_respect_permission( string $route ): void {
		$input = 'get-campaign' === $route ? array( 'resource_name' => self::rn( 'campaigns' ) ) : array();
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'campaign.id', 'results' => array( array( 'campaign' => array( 'id' => '1' ) ) ) ) );
		$result = $this->invoke( $route, $input ); $this->assertTrue( $result['success'], (string) wp_json_encode( $result ) ); $this->assertSame( 1, $result['row_count'] );
		$this->assertStringStartsWith( 'SELECT ', json_decode( FakeHttp::last()['body'], true )['query'] );
		if ( 'get-campaign' === $route ) { $this->assertStringContainsString( 'campaign.start_date_time', $result['query'] ); $this->assertStringNotContainsString( 'campaign.start_date,', $result['query'] ); }
		FakeHttp::reset(); $GLOBALS['f3_test_caps'] = false; $result = $this->invoke( $route, $input ); $this->assertFalse( $result['success'] ); $this->assertCount( 0, FakeHttp::$requests );
	}
	/** @dataProvider complementary_reads */
	public function test_complementary_reads_do_not_turn_api_errors_into_empty_success( string $route ): void {
		FakeHttp::push( 'googleAds:search', 403, array( 'error' => array( 'status' => 'PERMISSION_DENIED', 'message' => 'USER_PERMISSION_DENIED', 'code' => 403 ) ) );
		$result = $this->invoke( $route, 'get-campaign' === $route ? array( 'resource_name' => self::rn( 'campaigns' ) ) : array() );
		$this->assertFalse( $result['success'] ); $this->assertStringContainsString( 'USER_PERMISSION_DENIED', $result['message'] );
	}
	public function test_schedule_returns_long_running_operation_and_validate_only_is_real(): void {
		$this->snapshots(); FakeHttp::push( ':scheduleExperiment', 200, array( 'name' => 'customers/' . self::CID . '/operations/42' ) );
		$result = $this->invoke( 'schedule-experiment', array( 'resource_name' => self::rn( 'experiments' ), 'dry_run' => true ) );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) ); $this->assertFalse( $result['asynchronous'] );
		$found = false; foreach ( FakeHttp::$requests as $request ) { if ( false !== strpos( $request['url'], ':scheduleExperiment' ) ) { $found = true; $this->assertTrue( json_decode( $request['body'], true )['validateOnly'] ); } } $this->assertTrue( $found );
	}
	public function test_special_routes_are_permission_gated_before_any_network(): void {
		$GLOBALS['f3_test_caps'] = false;
		$fixtures = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/ads-write-inputs.json' ), true );
		foreach ( $fixtures as $fixture ) {
			if ( in_array( $fixture['route'], array( 'ads/mutate', 'ads/schedule-experiment', 'ads/upload-click-conversions', 'ads/upload-customer-match' ), true ) ) {
				$result = $this->invoke( substr( $fixture['route'], 4 ), $fixture['input'] ); $this->assertFalse( $result['success'] );
			}
		}
		$this->assertCount( 0, FakeHttp::$requests );
	}
	public function test_customer_match_partial_failure_returns_retained_job_without_running_it(): void {
		$job = self::rn( 'offlineUserDataJobs', '7' );
		FakeHttp::push( 'offlineUserDataJobs:create', 200, array( 'resourceName' => $job ) );
		FakeHttp::push( ':addOperations', 200, array( 'partialFailureError' => array( 'code' => 3, 'message' => 'One operation invalid.' ) ) );
		$result = $this->invoke( 'upload-customer-match', array( 'users' => array( array( 'email' => 'user@example.com' ) ), 'user_list' => self::rn( 'userLists' ) ) );
		$this->assertFalse( $result['success'] ); $this->assertTrue( $result['partial_failure'] ); $this->assertFalse( $result['job_started'] ); $this->assertSame( $job, $result['job_resource_name'] );
		foreach ( FakeHttp::$requests as $request ) { $this->assertStringNotContainsString( ':run', $request['url'] ); }
	}
	public function test_mutation_audit_keeps_actual_previous_and_resulting_field_values(): void {
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'campaign.resource_name,campaign.name', 'results' => array( array( 'campaign' => array( 'resourceName' => self::rn( 'campaigns' ), 'name' => 'Before' ) ) ) ) );
		FakeHttp::push( '/campaigns:mutate', 200, array( 'results' => array( array( 'resourceName' => self::rn( 'campaigns' ) ) ) ) );
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'campaign.resource_name,campaign.name', 'results' => array( array( 'campaign' => array( 'resourceName' => self::rn( 'campaigns' ), 'name' => 'After' ) ) ) ) );
		$result = $this->invoke( 'update-campaign', array( 'resource' => array( 'resourceName' => self::rn( 'campaigns' ), 'name' => 'After' ) ) );
		$this->assertTrue( $result['success'] );
		$audit = \Fator3\McpGoogle\Audit::recent( 1 )[0]['extra'];
		$this->assertSame( 'Before', $audit['before']['resources'][0]['state']['campaign.name'] );
		$this->assertSame( 'After', $audit['after']['resources'][0]['state']['campaign.name'] );
		$this->assertFalse( $audit['dry_run'] );
		$this->assertStringContainsString( 'campaign.name', json_decode( FakeHttp::$requests[2]['body'], true )['query'] );
	}
	public function test_mixed_google_ads_operations_keep_results_on_partial_failure(): void {
		FakeHttp::push( '/googleAds:mutate', 200, array( 'partialFailureError' => array( 'code' => 3, 'message' => 'One budget invalid.' ), 'mutateOperationResponses' => array( array( 'campaignBudgetResult' => array( 'resourceName' => self::rn( 'campaignBudgets' ) ) ), array() ) ) ); $this->snapshots();
		$result = $this->invoke( 'mutate', array( 'partial_failure' => true, 'operations' => array( array( 'campaignBudgetOperation' => array( 'create' => array( 'name' => 'Fixture', 'amountMicros' => '1000000' ) ) ), array( 'campaignBudgetOperation' => array( 'create' => array( 'name' => 'Invalid' ) ) ) ) ) );
		$this->assertFalse( $result['success'] ); $this->assertTrue( $result['partial_failure'] ); $this->assertCount( 2, $result['result']['mutateOperationResponses'] );
	}
	public function test_writes_do_not_retry_server_errors_that_may_follow_a_committed_mutation(): void {
		FakeHttp::push( '/campaigns:mutate', 503, array( 'error' => array( 'status' => 'UNAVAILABLE', 'message' => 'Backend unavailable', 'code' => 503 ) ) );
		FakeHttp::push( '/campaigns:mutate', 200, array() );
		$result = $this->invoke( 'create-campaign', self::named_routes()['create-campaign'][2] );
		$this->assertFalse( $result['success'] ); $this->assertCount( 1, FakeHttp::$requests );
	}
	public function test_conversion_catalog_is_account_specific_and_does_not_invent_missing_actions(): void {
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'conversion_action.resource_name,conversion_action.name,conversion_action.primary_for_goal', 'results' => array( array( 'conversionAction' => array( 'resourceName' => self::rn( 'conversionActions' ), 'name' => 'Lead', 'primaryForGoal' => true ) ) ) ) );
		$fields = Conversions::fields( self::CID ); $this->assertSame( array( 'conversions:Lead', 'conversions_value:Lead' ), array_column( $fields, 'id' ) );
		$this->assertSame( self::CID, $fields[0]['account_id'] );
		FakeHttp::push( 'googleAds:search', 200, array( 'fieldMask' => 'conversion_action.resource_name,conversion_action.name', 'results' => array() ) );
		$result = Conversions::query( array( 'accounts' => array( self::CID ), 'metrics' => array( 'conversions:Missing' ), 'date_range' => 'last_7_days' ) );
		$this->assertFalse( $result['success'] ); $this->assertStringContainsString( 'Missing', $result['message'] );
	}

}
