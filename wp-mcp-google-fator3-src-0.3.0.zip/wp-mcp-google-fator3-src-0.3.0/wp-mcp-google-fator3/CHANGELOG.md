# Histórico

## 0.3.0 — 2026-09-13

- Corrige selftest: execução, aprovação e verificações puladas têm campos distintos; reprovação não é sobrescrita por Response::ok().
- Adiciona gravações verificadas, confirmação direta no banco, resultados por operação, erros de cifra e compensação de lotes; painel e OAuth conferem persistência.
- Cifra access tokens no cache, invalida cache legado e serializa renovação.
- Separa desconexão local e revogação OAuth explícita; preserva configuração do cliente.
- Adiciona seleção de serviços/perfis, importação de credenciais, configuração assistida e até 20 conexões locais.
- Acrescenta diagnóstico por recurso, telemetria HTTP sem corpos/segredos, Retry-After, classificação de quota e orçamento de tentativas.
- Substitui auditoria em lista única por registros independentes com inserção exclusiva e retenção configurável.
- Acrescenta sitemap acompanhado, inspeção em lote com cache/cota/prioridade, jobs persistentes, agendas e seis modelos de relatório.
- Preserva PUT vazio com Content-Length: 0 e todas as habilidades anteriores. Total: 131 habilidades (46 leituras, 85 escritas).
- Inclui script Cloud Shell revisado e original de referência; projeto explícito, reuso de chaves e rotação opt-in.
- Validação: 805 testes, 8.730 asserções; 20 verificações com funções WordPress/SQLite, três PUTs por HTTP local e nove cenários Cloud Shell simulados.

## 0.2.1 — 2026-09-09

- Corrige HTTP 411 em `gsc/submit-sitemap`: o cliente HTTP envia `Content-Length: 0` em PUT com corpo vazio.
- Aplica a correção também a `gsc/add-site` e a métodos PUT sem corpo executados por `google/execute-action`.
- Preserva corpos JSON, formulários e uploads com conteúdo; mantém o contrato sem corpo da Search Console.
- Inclui testes de regressão e reprodução HTTP local com o transporte Requests/Fsockopen do WordPress.

## 0.2.0 — 2026-09-08

- Preserva as 21 habilidades e configurações da 0.1.0; acrescenta 93 habilidades.
- Adiciona Search Console, Site Verification, GA Admin em escrita, Ads em escrita, Measurement Protocol, blend e exportação para Sheets/Drive.
- Expõe catálogo e executor baseados em nove documentos oficiais, com 521 métodos no conjunto validado.
- Acrescenta anotações de escrita, auditoria before/after redigida, validateOnly Ads, erros acionáveis e diagnóstico de APIs/escopos.
- Resolve contas por nome e wildcard; inclui conversões customizadas Ads, catálogos completos e isolamento de caches por credencial/delegação.
- Corrige colisão de IDs numéricos em fanout, paginação incompleta/cíclica, repetição indevida de gravações e codificação de objetos JSON vazios.
- Conserva integração com as três metatools e URL do servidor WP MCP Fator3.

## 0.1.0 — base recebida

21 habilidades de leitura Analytics/Ads/camada unificada, service account e OAuth de usuário, cifra, configuração administrativa, portão geral e auditoria de metadados.
