<?php
/**
 * Desinstalação: apaga tudo o que o plugin gravou.
 *
 * "Tudo" inclui os segredos. Deixar a chave da service account cifrada na
 * tabela `options` depois de o plugin sair seria guardar credencial de acesso a
 * dados de Analytics e de Ads num site que já não a usa — e ninguém iria lá
 * limpar à mão.
 *
 * Os transients (tokens em cache, state do OAuth, cache de metadados) são
 * apagados por SQL porque não há como enumerá-los pela API do WordPress. As
 * duas linhas por transient (`_transient_x` e `_transient_timeout_x`) precisam
 * das duas cláusulas LIKE.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/Options.php';
require_once __DIR__ . '/includes/Connections.php';
if ( function_exists( 'wp_clear_scheduled_hook' ) ) { wp_clear_scheduled_hook( 'f3_mcp_google_jobs_tick' ); }

global $wpdb;

foreach ( \Fator3\McpGoogle\Options::all_names() as $f3_mcp_google_option ) {
	if ( str_ends_with( $f3_mcp_google_option, 'token_index' ) ) {
		foreach ( (array) get_option( $f3_mcp_google_option, array() ) as $token_key ) { if ( is_string( $token_key ) && 0 === strpos( $token_key, 'f3_mcp_google_tok_' ) ) { delete_transient( $token_key ); } }
	}
	delete_option( $f3_mcp_google_option );
}

unset( $f3_mcp_google_option );

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- não existe API para varrer transients por prefixo.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_f3_mcp_google_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_f3_mcp_google_' ) . '%'
	)
);

// Em multisite os transients de site ficam em sitemeta, com outro prefixo.
if ( is_multisite() ) {
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s OR meta_key LIKE %s",
			$wpdb->esc_like( '_site_transient_f3_mcp_google_' ) . '%',
			$wpdb->esc_like( '_site_transient_timeout_f3_mcp_google_' ) . '%'
		)
	);
}
// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
