<?php
/** Bounded leases acquired with the database's unique option_name constraint. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Lock {
	public static function acquire( string $resource, int $ttl = 180 ): ?array {
		$key = 'f3_mcp_google_lock_' . hash( 'sha256', $resource );
		$lease = array( 'owner' => bin2hex( random_bytes( 16 ) ), 'expires' => time() + $ttl );
		if ( Options::insert_exclusive( $key, $lease ) ) { return array( 'key' => $key, 'lease' => $lease ); }
		$prior = Options::stored( $key );
		if ( $prior['success'] && $prior['exists'] && is_array( $prior['value'] ) && (int) ( $prior['value']['expires'] ?? PHP_INT_MAX ) < time() ) {
			if ( self::delete_if( $key, $prior['value'] ) && Options::insert_exclusive( $key, $lease ) ) { return array( 'key' => $key, 'lease' => $lease ); }
		}
		return null;
	}
	public static function release( array $lock ): void { self::delete_if( $lock['key'], $lock['lease'] ); }
	private static function delete_if( string $key, array $lease ): bool {
		global $wpdb;
		if ( isset( $wpdb ) && is_callable( array( $wpdb, 'get_row' ) ) ) {
			$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $key, maybe_serialize( $lease ) ) );
			if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( $key, 'options' ); }
			return 1 === $deleted;
		}
		if ( get_option( $key ) !== $lease ) { return false; }
		return delete_option( $key );
	}
}
