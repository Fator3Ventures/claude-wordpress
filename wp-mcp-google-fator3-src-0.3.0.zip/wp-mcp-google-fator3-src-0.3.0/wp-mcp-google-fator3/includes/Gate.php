<?php
/**
 * Portão comum a todas as habilidades.
 *
 * A ordem das recusas é a ordem em que elas ajudam quem chamou: primeiro o que
 * um humano precisa destravar na tela (canal fechado), depois o que só um
 * administrador resolve (capacidade), depois o conector específico e, por
 * último, a credencial. Errar essa ordem faz o agente reportar "sem
 * credencial" quando na verdade o canal inteiro está desligado.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

use Fator3\McpGoogle\Auth\Credentials;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gate {

	/**
	 * @param string $connector 'ga' | 'ads' | 'any'.
	 * @return array|null Null libera; array é uma resposta de erro pronta.
	 */
	public static function check( string $connector ): ?array {
		if ( ! Options::is_enabled() ) {
			return Response::fail(
				new \WP_Error(
					'f3_google_disabled',
					__( 'O canal MCP Google está fechado. Reabra em Ferramentas > MCP Google no wp-admin.', 'wp-mcp-google-fator3' )
				)
			);
		}

		if ( ! current_user_can( Options::capability() ) ) {
			return Response::fail(
				new \WP_Error(
					'f3_google_forbidden',
					sprintf(
						/* translators: %s: nome da capacidade exigida. */
						__( 'Permissão insuficiente: é exigida a capacidade %s.', 'wp-mcp-google-fator3' ),
						Options::capability()
					)
				)
			);
		}

		if ( ! self::connector_enabled( $connector ) ) {
			return Response::fail(
				new \WP_Error(
					'f3_google_connector_off',
					'ads' === $connector
						? __( 'O conector Google Ads está desligado. Ligue-o em Ferramentas > MCP Google.', 'wp-mcp-google-fator3' )
						: sprintf( __( 'O conector %s está desligado. Ligue-o em Ferramentas > MCP Google.', 'wp-mcp-google-fator3' ), 'ga' === $connector ? 'Google Analytics' : $connector )
				)
			);
		}

		// 'any' é o portão das rotas de diagnóstico e de despacho (google/status,
		// google/selftest, google/query…). Elas precisam rodar SEM credencial
		// para dizer que ela falta; as que de fato falam com a Google chamam
		// Gate::check( 'ga' ) ou Gate::check( 'ads' ) por dentro, e é aí que a
		// credencial é exigida.
		if ( 'any' === $connector ) {
			return null;
		}

		$credential = Credentials::current();
		if ( is_wp_error( $credential ) && in_array( $credential->get_error_code(), array( 'f3_google_crypto_decrypt', 'f3_google_option_read' ), true ) ) { return Response::fail( $credential ); }
		if ( is_wp_error( $credential ) ) {
			return Response::fail(
				new \WP_Error(
					'f3_google_not_configured',
					__( 'Nenhuma credencial Google configurada. Informe a chave da service account ou conecte uma conta por OAuth em Ferramentas > MCP Google.', 'wp-mcp-google-fator3' )
				)
			);
		}

		if ( 'ads' === $connector && '' === Options::get_secret( Options::ADS_DEVELOPER_TOKEN ) ) {
			return Response::fail(
				new \WP_Error(
					'f3_google_ads_no_developer_token',
					__( 'A Google Ads API exige um developer token. Informe-o em Ferramentas > MCP Google.', 'wp-mcp-google-fator3' )
				)
			);
		}

		return null;
	}

	/**
	 * Versão booleana, para o `permission_callback`.
	 *
	 * Não inclui a checagem de credencial de propósito: sem credencial a
	 * habilidade deve rodar e explicar o que falta (é assim que `google/status`
	 * e `google/selftest` servem para diagnóstico). Se o `permission_callback`
	 * recusasse, o servidor MCP devolveria "permission denied" e o
	 * administrador ficaria sem saber o motivo. A fronteira de segurança —
	 * canal aberto e capacidade — continua inteira aqui.
	 */
	public static function permission( string $connector ): bool {
		if ( ! Options::is_enabled() ) {
			return false;
		}

		if ( ! current_user_can( Options::capability() ) ) {
			return false;
		}

		return self::connector_enabled( $connector );
	}

	/**
	 * 'any' basta um dos dois ligado — são as rotas de diagnóstico e de
	 * catálogo, que servem a quem tiver ao menos um conector em pé.
	 */
	private static function connector_enabled( string $connector ): bool {
		if ( 'any' !== $connector && ! Connections::enabled( $connector ) ) { return false; }
		if ( 'ga' === $connector ) {
			return Options::ga_enabled();
		}

		if ( 'ads' === $connector ) {
			return Options::ads_enabled();
		}

		return in_array( $connector, array( 'any', 'gsc', 'siteverification', 'sheets', 'drive' ), true );
	}
}
