<?php
/**
 * Tela de administração — Ferramentas > MCP Google.
 *
 * É aqui que a credencial entra e o canal se fecha. Duas regras guiam o
 * arquivo inteiro: nenhum segredo volta para o HTML (nem no `value` de um
 * input, nem numa mensagem de erro), e todo POST passa por capacidade + nonce.
 *
 * Campos de segredo em branco significam "não mexer": é o que permite salvar o
 * login customer ID sem ter que colar o developer token de novo. Para apagar,
 * existe uma caixa explícita.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Auth\OAuthFlow;
use Fator3\McpGoogle\Auth\ServiceAccount;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Admin {

	public const SLUG = 'wp-mcp-google-fator3';

	/** Transient onde o resultado do teste de conexão espera o redirecionamento. */
	private const TEST_RESULT = 'f3_mcp_google_last_test';

	public static function init(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );

		$handlers = array(
			'f3_mcp_google_toggle'      => 'handle_toggle',
			'f3_mcp_google_toggle_ga'   => 'handle_toggle_ga',
			'f3_mcp_google_toggle_ads'  => 'handle_toggle_ads',
			'f3_mcp_google_save_mode'   => 'handle_save_mode',
			'f3_mcp_google_save_sa'     => 'handle_save_sa',
			'f3_mcp_google_save_oauth'  => 'handle_save_oauth',
			'f3_mcp_google_save_ads'    => 'handle_save_ads',
			'f3_mcp_google_save_ga'     => 'handle_save_ga',
			'f3_mcp_google_save_limits' => 'handle_save_limits',
			'f3_mcp_google_test'        => 'handle_test',
			'f3_mcp_google_clear_log'   => 'handle_clear_log',
		);

		foreach ( $handlers as $action => $method ) {
			add_action( 'admin_post_' . $action, array( self::class, $method ) );
		}
	}

	public static function menu(): void {
		add_management_page(
			__( 'WP MCP Google Fator3', 'wp-mcp-google-fator3' ),
			__( 'MCP Google', 'wp-mcp-google-fator3' ),
			Options::capability(),
			self::SLUG,
			array( self::class, 'render' )
		);
	}

	/**
	 * URL da própria tela, opcionalmente com um estado.
	 *
	 * @param string $status Código de estado a exibir.
	 */
	public static function url( string $status = '' ): string {
		$args = array( 'page' => self::SLUG, 'connection_id' => Connections::id() );

		if ( '' !== $status ) {
			$args['f3_status'] = $status;
		}

		return add_query_arg( $args, admin_url( 'tools.php' ) );
	}

	// =========================================================================
	// Handlers
	// =========================================================================

	/**
	 * Capacidade + nonce em todo POST. Sem isto, um link forjado numa aba
	 * aberta do administrador reabriria o canal.
	 */
	private static function guard( string $nonce ): void {
		if ( ! current_user_can( Options::capability() ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'wp-mcp-google-fator3' ) );
		}

		check_admin_referer( $nonce );
		$selected = Connections::select( self::posted( 'connection_id' ) ?: 'default' );
		if ( is_wp_error( $selected ) ) { wp_die( esc_html( $selected->get_error_message() ) ); }
	}

	public static function require_saved( array $result ): void {
		if ( ! empty( $result['success'] ) ) { return; }
		Audit::log( 'configuration:rejected', (string) ( $result['option'] ?? '-' ), array( 'status' => 'error', 'error_code' => $result['error_code'] ?? 'f3_google_option_write' ) );
		set_transient( self::TEST_RESULT . '_save_' . get_current_user_id(), array( 'error_code' => $result['error_code'] ?? '', 'message' => $result['message'] ?? 'Falha ao gravar configuração.' ), 120 );
		self::back( 'save_failed' );
	}

	private static function back( string $status ): void {
		wp_safe_redirect( self::url( $status ) );
		exit;
	}

	/**
	 * Lê um campo do POST já limpo.
	 */
	private static function posted( string $field ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- o nonce é conferido em guard(), antes de qualquer chamada a este método.
		if ( ! isset( $_POST[ $field ] ) || ! is_scalar( $_POST[ $field ] ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- idem.
		return trim( sanitize_text_field( wp_unslash( (string) $_POST[ $field ] ) ) );
	}

	/**
	 * Lê o campo do JSON da chave sem passar por sanitize_textarea_field.
	 *
	 * Aquele sanitizador apaga toda sequência `%XX` do texto, o que estragaria
	 * o `client_x509_cert_url` da chave (que traz `%40` no lugar do @). Aqui a
	 * validação é outra e mais forte: o valor precisa ser um JSON de service
	 * account (ver ServiceAccount::validate_key) e o que se grava é a versão
	 * recodificada por wp_json_encode a partir do array decodificado — ou seja,
	 * nunca a string crua do formulário. Este campo também nunca volta para o
	 * HTML.
	 */
	private static function posted_json( string $field ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- o nonce é conferido em guard(), antes de qualquer chamada a este método.
		if ( ! isset( $_POST[ $field ] ) || ! is_string( $_POST[ $field ] ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validado como JSON de service account logo adiante; gravado recodificado.
		$raw = trim( (string) wp_unslash( $_POST[ $field ] ) );

		// Teto de tamanho: uma chave de service account tem ~2,3 KB.
		return strlen( $raw ) > 20000 ? '' : $raw;
	}

	private static function checked_box( string $field ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- o nonce é conferido em guard().
		if ( ! isset( $_POST[ $field ] ) || ! is_scalar( $_POST[ $field ] ) ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- idem.
		return '1' === sanitize_text_field( wp_unslash( (string) $_POST[ $field ] ) );
	}

	public static function handle_toggle(): void {
		self::guard( 'f3_mcp_google_toggle' );

		$enable = self::checked_box( 'enable' );
		self::require_saved( Options::set( Options::ENABLED, $enable ) );
		Audit::log( $enable ? 'channel:enable' : 'channel:disable' );

		self::back( 'saved' );
	}

	public static function handle_toggle_ga(): void {
		self::guard( 'f3_mcp_google_toggle_ga' );

		$enable = self::checked_box( 'enable' );
		self::require_saved( Options::set( Options::GA_ENABLED, $enable ) );
		Audit::log( $enable ? 'ga:enable' : 'ga:disable' );

		self::back( 'saved' );
	}

	public static function handle_toggle_ads(): void {
		self::guard( 'f3_mcp_google_toggle_ads' );

		$enable = self::checked_box( 'enable' );
		self::require_saved( Options::set( Options::ADS_ENABLED, $enable ) );
		Audit::log( $enable ? 'ads:enable' : 'ads:disable' );

		self::back( 'saved' );
	}

	public static function handle_save_mode(): void {
		self::guard( 'f3_mcp_google_save_mode' );

		$mode = 'oauth' === self::posted( 'auth_mode' ) ? 'oauth' : 'service_account';
		self::require_saved( Options::set( Options::AUTH_MODE, $mode ) );
		Credentials::invalidate_cache();
		Audit::log( 'auth:mode', $mode );

		self::back( 'saved' );
	}

	public static function handle_save_sa(): void {
		self::guard( 'f3_mcp_google_save_sa' );

		if ( self::checked_box( 'clear_sa' ) ) {
			self::require_saved( Options::set_secret( Options::SA_JSON, '' ) );
			self::require_saved( Options::delete( Options::SA_SUBJECT ) );
			Credentials::invalidate_cache();
			Audit::log( 'auth:sa-clear' );

			self::back( 'sa_cleared' );
			return;
		}

		$subject = self::posted( 'sa_subject' );
		if ( '' !== $subject && ! is_email( $subject ) ) {
			self::back( 'sa_subject_invalid' );
			return;
		}


		$json = self::posted_json( 'sa_json' );

		// Campo vazio é "não mexer": permite salvar só o e-mail a impersonar
		// sem ter que colar a chave inteira de novo.
		if ( '' === $json ) {
			self::require_saved( Options::set( Options::SA_SUBJECT, $subject ) );
			Credentials::invalidate_cache();
			self::back( 'saved' );
			return;
		}

		if ( ! Crypto::available() ) {
			self::back( 'no_crypto' );
			return;
		}

		$key = ServiceAccount::validate_key( $json );
		if ( is_wp_error( $key ) ) {
			set_transient( self::TEST_RESULT . '_msg', $key->get_error_message(), 120 );
			self::back( 'sa_invalid' );
			return;
		}

		// Grava o JSON recodificado a partir do array já validado, nunca a
		// string crua que veio do formulário.
		self::require_saved( Options::batch_verified( array( Options::SA_SUBJECT => $subject, Options::AUTH_MODE => 'service_account' ), array( Options::SA_JSON => (string) wp_json_encode( $key ) ) ) );
		Credentials::invalidate_cache();
		Audit::log( 'auth:sa-save', (string) ( $key['client_email'] ?? '-' ) );

		self::back( 'sa_saved' );
	}

	public static function handle_save_oauth(): void {
		self::guard( 'f3_mcp_google_save_oauth' );

		if ( self::checked_box( 'clear_oauth' ) ) {
			self::require_saved( Options::delete( Options::OAUTH_CLIENT_ID ) );
			self::require_saved( Options::set_secret( Options::OAUTH_CLIENT_SECRET, '' ) );
			self::require_saved( Options::set_secret( Options::OAUTH_REFRESH_TOKEN, '' ) );
			self::require_saved( Options::delete( Options::OAUTH_EMAIL ) );
			self::require_saved( Options::delete( Options::OAUTH_SCOPES ) );
			Credentials::invalidate_cache();
			Audit::log( 'auth:oauth-clear' );

			self::back( 'saved' );
			return;
		}

		$client_id = self::posted( 'oauth_client_id' );
		$prior_client = Options::get( Options::OAUTH_CLIENT_ID, '' );
		$secrets = array();

		$secret = self::posted( 'oauth_client_secret' );
		if ( '' !== $secret ) {
			if ( ! Crypto::available() ) {
				self::back( 'no_crypto' );
				return;
			}

			$secrets[ Options::OAUTH_CLIENT_SECRET ] = $secret;
		}

		$deletes = $prior_client !== $client_id ? array( Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES ) : array();
		self::require_saved( Options::batch_verified( array( Options::OAUTH_CLIENT_ID => $client_id ), $secrets, $deletes ) );
		Credentials::invalidate_cache();
		Audit::log( 'auth:oauth-save' );

		self::back( 'saved' );
	}

	public static function handle_save_ads(): void {
		self::guard( 'f3_mcp_google_save_ads' );

		if ( self::checked_box( 'clear_developer_token' ) ) {
			self::require_saved( Options::set_secret( Options::ADS_DEVELOPER_TOKEN, '' ) );
		} else {
			$token = self::posted( 'ads_developer_token' );
			if ( '' !== $token ) {
				if ( ! Crypto::available() ) {
					self::back( 'no_crypto' );
					return;
				}

				self::require_saved( Options::set_secret( Options::ADS_DEVELOPER_TOKEN, $token ) );
			}
		}

		$login = preg_replace( '/\D+/', '', self::posted( 'ads_login_customer_id' ) );
		self::require_saved( Options::set( Options::ADS_LOGIN_CUSTOMER_ID, is_string( $login ) ? $login : '' ) );

		$version = strtolower( self::posted( 'ads_api_version' ) );
		if ( preg_match( '/^v\d{1,3}$/', $version ) ) {
			self::require_saved( Options::set( Options::ADS_API_VERSION, $version ) );
		}

		Audit::log( 'ads:config' );

		self::back( 'saved' );
	}

	public static function handle_save_ga(): void {
		self::guard( 'f3_mcp_google_save_ga' );

		$property = preg_replace( '/\D+/', '', self::posted( 'ga_default_property' ) );
		self::require_saved( Options::set( Options::GA_DEFAULT_PROPERTY, is_string( $property ) ? $property : '' ) );
		Audit::log( 'ga:config' );

		self::back( 'saved' );
	}

	public static function handle_save_limits(): void {
		self::guard( 'f3_mcp_google_save_limits' );

		$rows = absint( self::posted( 'max_rows' ) );
		if ( $rows > 0 ) {
			self::require_saved( Options::set( Options::MAX_ROWS, max( 1, min( 10000, $rows ) ) ) );
		}

		$timeout = absint( self::posted( 'http_timeout' ) );
		if ( $timeout > 0 ) {
			self::require_saved( Options::set( Options::HTTP_TIMEOUT, max( 5, min( 120, $timeout ) ) ) );
		}

		self::back( 'saved' );
	}

	public static function handle_test(): void {
		self::guard( 'f3_mcp_google_test' );

		set_transient( self::TEST_RESULT, self::run_test(), 120 );
		Audit::log( 'selftest' );

		self::back( 'tested' );
	}

	public static function handle_clear_log(): void {
		self::guard( 'f3_mcp_google_clear_log' );

		self::require_saved( Audit::clear() );

		self::back( 'log_cleared' );
	}

	/**
	 * Executa o autoteste com chamada real, ou, na falta dele, apenas tenta
	 * obter um access token para os escopos dos conectores ligados.
	 */
	private static function run_test(): array {
		if ( class_exists( __NAMESPACE__ . '\\SelfTest' ) ) {
			return SelfTest::run( array( 'live' => true ) );
		}

		$credentials = Credentials::current();

		if ( is_wp_error( $credentials ) ) {
			return array(
				'success' => false,
				'passed'  => 0,
				'failed'  => 1,
				'checks'  => array(
					array(
						'name'   => 'token',
						'ok'     => false,
						'detail' => $credentials->get_error_message(),
					),
				),
			);
		}

		$token     = $credentials->get_access_token( Credentials::scopes_for( 'any' ) );
		$described = $credentials->describe();
		$ok        = ! is_wp_error( $token );

		return array(
			'success' => $ok,
			'passed'  => $ok ? 1 : 0,
			'failed'  => $ok ? 0 : 1,
			'checks'  => array(
				array(
					'name'   => 'token',
					'ok'     => $ok,
					// Nunca o token: só o resultado e a identidade.
					'detail' => $ok
						? sprintf(
							/* translators: 1: modo de autenticação, 2: identidade. */
							__( 'Access token obtido (%1$s, %2$s).', 'wp-mcp-google-fator3' ),
							(string) ( $described['mode'] ?? '' ),
							(string) ( $described['identity'] ?? '' )
						)
						: $token->get_error_message(),
				),
			),
		);
	}

	// =========================================================================
	// Tela
	// =========================================================================

	/**
	 * Um filtro em código está forçando o kill switch?
	 */
	public static function forced_by_filter(): bool {
		return has_filter( 'f3_mcp_google_enabled' );
	}

	/**
	 * "configurado (••••1234)" — nunca o segredo.
	 */
	private static function mask( string $option ): string {
		$secret = Options::get_secret( $option );

		if ( '' === $secret ) {
			return __( 'não configurado', 'wp-mcp-google-fator3' );
		}

		$tail = strlen( $secret ) >= 4 ? substr( $secret, -4 ) : '';

		return '' !== $tail
			? sprintf(
				/* translators: %s: últimos quatro caracteres do segredo. */
				__( 'configurado (••••%s)', 'wp-mcp-google-fator3' ),
				$tail
			)
			: __( 'configurado', 'wp-mcp-google-fator3' );
	}

	/**
	 * Mensagens de estado. Texto sai daqui, não da query string.
	 */
	private static function notices(): array {
		return array(
			'save_failed' => array( 'error', 'Falha ao persistir configuração. Confira o resultado abaixo.' ),
			'saved'                => array( 'success', __( 'Configuração salva.', 'wp-mcp-google-fator3' ) ),
			'sa_saved'             => array( 'success', __( 'Chave da service account salva e cifrada.', 'wp-mcp-google-fator3' ) ),
			'sa_cleared'           => array( 'success', __( 'Chave da service account removida.', 'wp-mcp-google-fator3' ) ),
			'sa_invalid'           => array( 'error', __( 'A chave não foi aceita.', 'wp-mcp-google-fator3' ) ),
			'sa_subject_invalid'   => array( 'error', __( 'O e-mail a impersonar não é válido.', 'wp-mcp-google-fator3' ) ),
			'no_crypto'            => array( 'error', __( 'Este servidor não tem libsodium nem OpenSSL com AES-256-GCM. Sem cifra, nenhum segredo é gravado.', 'wp-mcp-google-fator3' ) ),
			'tested'               => array( 'info', __( 'Teste de conexão executado.', 'wp-mcp-google-fator3' ) ),
			'log_cleared'          => array( 'success', __( 'Log de auditoria limpo.', 'wp-mcp-google-fator3' ) ),
			'oauth_ok'             => array( 'success', __( 'Conta Google conectada.', 'wp-mcp-google-fator3' ) ),
			'oauth_denied'         => array( 'error', __( 'O consentimento foi recusado na tela da Google.', 'wp-mcp-google-fator3' ) ),
			'oauth_state'          => array( 'error', __( 'O retorno da Google não corresponde a um pedido feito aqui (state inválido ou expirado). Tente conectar de novo.', 'wp-mcp-google-fator3' ) ),
			'oauth_exchange'       => array( 'error', __( 'A troca do código por tokens falhou. Confira o client ID, o client secret e a URI de redirecionamento cadastrada no Google Cloud.', 'wp-mcp-google-fator3' ) ),
			'oauth_no_refresh'     => array( 'error', __( 'A Google não devolveu refresh token. Remova o acesso do site em myaccount.google.com/permissions e conecte de novo.', 'wp-mcp-google-fator3' ) ),
			'oauth_missing_client' => array( 'error', __( 'Informe o client ID e o client secret antes de conectar.', 'wp-mcp-google-fator3' ) ),
			'oauth_revoked' => array( 'success', 'Desconectado localmente; autorização revogada no Google.' ),
			'oauth_revoke_failed' => array( 'error', 'Desconectado localmente; a revogação no Google falhou.' ),
			'oauth_disconnected'   => array( 'success', __( 'Conta Google desconectada.', 'wp-mcp-google-fator3' ) ),
		);
	}

	public static function render(): void {
		if ( ! current_user_can( Options::capability() ) ) {
			return;
		}

		$id = isset( $_GET['connection_id'] ) && is_string( $_GET['connection_id'] ) ? sanitize_key( $_GET['connection_id'] ) : 'default';
		if ( is_wp_error( Connections::select( $id ) ) ) { echo '<p>Conexão inválida.</p>'; return; }

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- leitura de um código de estado para exibir aviso; não altera nada.
		$status = isset( $_GET['f3_status'] ) ? sanitize_key( wp_unslash( $_GET['f3_status'] ) ) : '';

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'WP MCP Google Fator3', 'wp-mcp-google-fator3' ) . '</h1>';
		echo '<p class="description" style="max-width:820px">'
			. esc_html__( 'Expõe Google Analytics, Ads, Search Console, Site Verification, Sheets e Drive como habilidades de leitura e escrita, alcançáveis pelo servidor MCP já instalado. As operações usam as permissões da credencial conectada.', 'wp-mcp-google-fator3' )
			. '</p>';

		self::render_notice( $status );
		if ( 'save_failed' === $status ) {
			$failure = get_transient( self::TEST_RESULT . '_save_' . get_current_user_id() );
			if ( is_array( $failure ) ) { echo '<p><code>' . esc_html( $failure['error_code'] ) . '</code> ' . esc_html( $failure['message'] ) . '</p>'; }
		}
		self::render_status();
		SetupAdmin::render();
		self::render_auth();
		self::render_analytics();
		self::render_ads();
		self::render_test();
		self::render_limits();
		self::render_requirements();
		self::render_audit();

		echo '</div>';
	}

	private static function render_notice( string $status ): void {
		$notices = self::notices();

		if ( '' === $status || ! isset( $notices[ $status ] ) ) {
			return;
		}

		list( $type, $message ) = $notices[ $status ];

		// O detalhe extra existe só para "a chave não foi aceita" — é ali que
		// dizer o motivo ajuda. Colá-lo em qualquer outro aviso faria a
		// mensagem de um salvamento bem-sucedido carregar o erro da tentativa
		// anterior.
		if ( 'sa_invalid' === $status ) {
			$extra = get_transient( self::TEST_RESULT . '_msg' );
			delete_transient( self::TEST_RESULT . '_msg' );

			if ( is_string( $extra ) && '' !== $extra ) {
				$message .= ' ' . $extra;
			}
		}

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $message )
		);
	}

	private static function render_status(): void {
		$enabled = Options::is_enabled();

		echo '<h2>' . esc_html__( 'Estado', 'wp-mcp-google-fator3' ) . '</h2>';
		echo '<p style="font-size:16px">';

		if ( $enabled ) {
			echo '<span style="display:inline-block;padding:4px 10px;background:#00845a;color:#fff;border-radius:3px">'
				. esc_html__( 'ABERTO', 'wp-mcp-google-fator3' ) . '</span> '
				. esc_html(
					sprintf(
						/* translators: %s: capacidade exigida. */
						__( 'As habilidades respondem para contas com %s.', 'wp-mcp-google-fator3' ),
						Options::capability()
					)
				);
		} else {
			echo '<span style="display:inline-block;padding:4px 10px;background:#646970;color:#fff;border-radius:3px">'
				. esc_html__( 'FECHADO', 'wp-mcp-google-fator3' ) . '</span> '
				. esc_html__( 'Todas as habilidades recusam qualquer chamada.', 'wp-mcp-google-fator3' );
		}

		echo '</p>';

		if ( self::forced_by_filter() ) {
			echo '<div class="notice notice-info inline"><p>'
				. esc_html__( 'Há um filtro f3_mcp_google_enabled ativo em código. Ele tem a última palavra e pode sobrepor o botão abaixo.', 'wp-mcp-google-fator3' )
				. '</p></div>';
		}

		self::form_start( 'f3_mcp_google_toggle' );
		echo '<input type="hidden" name="enable" value="' . ( $enabled ? '0' : '1' ) . '">';
		submit_button(
			$enabled ? __( 'Fechar o canal agora', 'wp-mcp-google-fator3' ) : __( 'Reabrir o canal', 'wp-mcp-google-fator3' ),
			$enabled ? 'delete' : 'primary',
			'submit',
			false
		);
		self::form_end();
	}

	private static function render_auth(): void {
		$mode        = Options::auth_mode();
		$credentials = Credentials::current();
		$identity    = is_wp_error( $credentials ) ? '' : (string) ( $credentials->describe()['identity'] ?? '' );

		echo '<h2>' . esc_html__( 'Autenticação', 'wp-mcp-google-fator3' ) . '</h2>';

		if ( ! Crypto::available() ) {
			echo '<div class="notice notice-error inline"><p>'
				. esc_html__( 'Este servidor não tem libsodium nem OpenSSL com AES-256-GCM: nenhum segredo pode ser gravado com segurança e os campos abaixo não salvam.', 'wp-mcp-google-fator3' )
				. '</p></div>';
		}

		echo '<p>' . esc_html__( 'Credencial em uso:', 'wp-mcp-google-fator3' ) . ' ';
		if ( is_wp_error( $credentials ) ) {
			echo '<strong>' . esc_html__( 'nenhuma', 'wp-mcp-google-fator3' ) . '</strong> — '
				. esc_html( $credentials->get_error_message() );
		} else {
			echo '<code>' . esc_html( $identity ) . '</code>';
		}
		echo '</p>';

		// ---- Modo -----------------------------------------------------------
		self::form_start( 'f3_mcp_google_save_mode' );
		echo '<p><label for="f3-auth-mode">' . esc_html__( 'Modo:', 'wp-mcp-google-fator3' ) . '</label> ';
		echo '<select name="auth_mode" id="f3-auth-mode">';
		echo '<option value="service_account"' . selected( $mode, 'service_account', false ) . '>'
			. esc_html__( 'Service account (recomendado)', 'wp-mcp-google-fator3' ) . '</option>';
		echo '<option value="oauth"' . selected( $mode, 'oauth', false ) . '>'
			. esc_html__( 'Conta de usuário (OAuth)', 'wp-mcp-google-fator3' ) . '</option>';
		echo '</select> ';
		submit_button( __( 'Usar este modo', 'wp-mcp-google-fator3' ), 'secondary', 'submit', false );
		echo '</p>';
		self::form_end();

		// ---- Service account -------------------------------------------------
		echo '<h3>' . esc_html__( 'Service account', 'wp-mcp-google-fator3' ) . '</h3>';

		$sa_json  = Options::get_secret( Options::SA_JSON );
		$sa_email = '';

		if ( '' !== $sa_json ) {
			$key = ServiceAccount::validate_key( $sa_json );
			if ( ! is_wp_error( $key ) ) {
				$sa_email = (string) ( $key['client_email'] ?? '' );
			}
		}

		echo '<table class="form-table" role="presentation"><tbody>';
		echo '<tr><th scope="row">' . esc_html__( 'Chave', 'wp-mcp-google-fator3' ) . '</th><td>';

		if ( '' !== $sa_email ) {
			echo '<p><strong>' . esc_html__( 'configurada', 'wp-mcp-google-fator3' ) . '</strong> — '
				. esc_html__( 'adicione este e-mail como usuário:', 'wp-mcp-google-fator3' )
				. ' <code>' . esc_html( $sa_email ) . '</code></p>';
			echo '<p class="description">'
				. esc_html__( 'Compartilhe contas, propriedades e arquivos com o e-mail da credencial. No GA4, use Editor para alterações e Administrador para usuários; no Ads, atribua o papel necessário; na Search Console, Proprietário para gestão/verificação. Leitores continuam podendo consultar.', 'wp-mcp-google-fator3' )
				. '</p>';
		} else {
			echo '<p><strong>' . esc_html__( 'não configurada', 'wp-mcp-google-fator3' ) . '</strong></p>';
		}

		echo '</td></tr>';
		echo '</tbody></table>';

		self::form_start( 'f3_mcp_google_save_sa' );
		echo '<p><label for="f3-sa-json">' . esc_html__( 'Cole o JSON da chave (deixe em branco para não alterar):', 'wp-mcp-google-fator3' ) . '</label></p>';
		echo '<textarea id="f3-sa-json" name="sa_json" rows="6" class="large-text code" spellcheck="false" autocomplete="off" placeholder="{&quot;type&quot;: &quot;service_account&quot;, ...}"></textarea>';
		echo '<p><label for="f3-sa-subject">' . esc_html__( 'E-mail a impersonar (só com delegação de domínio; deixe vazio no uso normal):', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="email" id="f3-sa-subject" name="sa_subject" class="regular-text" value="'
			. esc_attr( (string) Options::get( Options::SA_SUBJECT, '' ) ) . '"></p>';
		echo '<p><label><input type="checkbox" name="clear_sa" value="1"> '
			. esc_html__( 'Remover a chave gravada', 'wp-mcp-google-fator3' ) . '</label></p>';
		submit_button( __( 'Salvar service account', 'wp-mcp-google-fator3' ), 'primary', 'submit', false );
		self::form_end();

		// ---- OAuth -----------------------------------------------------------
		echo '<h3>' . esc_html__( 'Conta de usuário (OAuth)', 'wp-mcp-google-fator3' ) . '</h3>';

		echo '<table class="form-table" role="presentation"><tbody>';
		printf(
			'<tr><th scope="row">%1$s</th><td><code>%2$s</code><br><span class="description">%3$s</span></td></tr>',
			esc_html__( 'URI de redirecionamento', 'wp-mcp-google-fator3' ),
			esc_html( OAuthFlow::redirect_uri() ),
			esc_html__( 'Cadastre exatamente esta URI no cliente OAuth "Aplicativo da Web", em APIs e serviços > Credenciais.', 'wp-mcp-google-fator3' )
		);
		printf(
			'<tr><th scope="row">%1$s</th><td>%2$s</td></tr>',
			esc_html__( 'Client secret', 'wp-mcp-google-fator3' ),
			esc_html( self::mask( Options::OAUTH_CLIENT_SECRET ) )
		);

		$oauth_email = (string) Options::get( Options::OAUTH_EMAIL, '' );
		printf(
			'<tr><th scope="row">%1$s</th><td>%2$s</td></tr>',
			esc_html__( 'Conta conectada', 'wp-mcp-google-fator3' ),
			Options::has_secret( Options::OAUTH_REFRESH_TOKEN )
				? '<code>' . esc_html( '' !== $oauth_email ? $oauth_email : __( 'conectada', 'wp-mcp-google-fator3' ) ) . '</code>'
				: esc_html__( 'nenhuma', 'wp-mcp-google-fator3' )
		);
		echo '</tbody></table>';

		echo '<div class="notice notice-warning inline"><p>'
			. esc_html__( 'Armadilha conhecida: enquanto a tela de consentimento do app estiver em modo "Testing", a Google invalida o refresh token a cada 7 dias e o canal para sozinho. Publique o app ou use uma service account.', 'wp-mcp-google-fator3' )
			. '</p></div>';

		self::form_start( 'f3_mcp_google_save_oauth' );
		echo '<p><label for="f3-oauth-id">' . esc_html__( 'Client ID:', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="text" id="f3-oauth-id" name="oauth_client_id" class="large-text code" autocomplete="off" value="'
			. esc_attr( (string) Options::get( Options::OAUTH_CLIENT_ID, '' ) ) . '"></p>';
		echo '<p><label for="f3-oauth-secret">' . esc_html__( 'Client secret (deixe em branco para não alterar):', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="password" id="f3-oauth-secret" name="oauth_client_secret" class="regular-text" autocomplete="new-password" value=""></p>';
		echo '<p><label><input type="checkbox" name="clear_oauth" value="1"> '
			. esc_html__( 'Remover client ID, secret e conta conectada', 'wp-mcp-google-fator3' ) . '</label></p>';
		submit_button( __( 'Salvar OAuth', 'wp-mcp-google-fator3' ), 'primary', 'submit', false );
		self::form_end();

		if ( Options::has_secret( Options::OAUTH_REFRESH_TOKEN ) ) {
			self::form_start( 'f3_mcp_google_oauth_disconnect' );
			submit_button( __( 'Desconectar conta Google', 'wp-mcp-google-fator3' ), 'delete', 'submit', false );
			echo '<p><label><input type="checkbox" name="revoke" value="1"> Revogar também no Google: afeta as autorizações deste usuário no mesmo projeto, incluindo outros sites.</label></p>';
			self::form_end();
		} else {
			self::form_start( 'f3_mcp_google_oauth_start' );
			submit_button( __( 'Conectar com Google', 'wp-mcp-google-fator3' ), 'secondary', 'submit', false );
			self::form_end();
		}
	}

	private static function render_analytics(): void {
		$enabled = Options::ga_enabled();

		echo '<h2>' . esc_html__( 'Google Analytics 4', 'wp-mcp-google-fator3' ) . '</h2>';
		echo '<p>' . esc_html__( 'Rotas ga/*:', 'wp-mcp-google-fator3' ) . ' '
			. ( $enabled
				? '<strong>' . esc_html__( 'LIGADAS', 'wp-mcp-google-fator3' ) . '</strong>'
				: '<strong>' . esc_html__( 'DESLIGADAS', 'wp-mcp-google-fator3' ) . '</strong>' )
			. '</p>';

		self::form_start( 'f3_mcp_google_toggle_ga' );
		echo '<input type="hidden" name="enable" value="' . ( $enabled ? '0' : '1' ) . '">';
		submit_button(
			$enabled ? __( 'Desligar Analytics', 'wp-mcp-google-fator3' ) : __( 'Ligar Analytics', 'wp-mcp-google-fator3' ),
			$enabled ? 'delete' : 'primary',
			'submit',
			false
		);
		self::form_end();

		self::form_start( 'f3_mcp_google_save_ga' );
		echo '<p><label for="f3-ga-property">' . esc_html__( 'Propriedade padrão (só o número; usada quando a chamada não informa property_id):', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="text" id="f3-ga-property" name="ga_default_property" class="regular-text code" inputmode="numeric" value="'
			. esc_attr( (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' ) ) . '"></p>';
		submit_button( __( 'Salvar', 'wp-mcp-google-fator3' ), 'secondary', 'submit', false );
		self::form_end();
	}

	private static function render_ads(): void {
		$enabled = Options::ads_enabled();

		echo '<h2>' . esc_html__( 'Google Ads', 'wp-mcp-google-fator3' ) . '</h2>';
		echo '<p>' . esc_html__( 'Rotas ads/*:', 'wp-mcp-google-fator3' ) . ' '
			. ( $enabled
				? '<strong>' . esc_html__( 'LIGADAS', 'wp-mcp-google-fator3' ) . '</strong>'
				: '<strong>' . esc_html__( 'DESLIGADAS', 'wp-mcp-google-fator3' ) . '</strong>' )
			. '</p>';

		self::form_start( 'f3_mcp_google_toggle_ads' );
		echo '<input type="hidden" name="enable" value="' . ( $enabled ? '0' : '1' ) . '">';
		submit_button(
			$enabled ? __( 'Desligar Ads', 'wp-mcp-google-fator3' ) : __( 'Ligar Ads', 'wp-mcp-google-fator3' ),
			$enabled ? 'delete' : 'primary',
			'submit',
			false
		);
		self::form_end();

		echo '<table class="form-table" role="presentation"><tbody>';
		printf(
			'<tr><th scope="row">%1$s</th><td>%2$s<br><span class="description">%3$s</span></td></tr>',
			esc_html__( 'Developer token', 'wp-mcp-google-fator3' ),
			esc_html( self::mask( Options::ADS_DEVELOPER_TOKEN ) ),
			esc_html__( 'Obrigatório na Google Ads API. Fica em API Center, na conta gerenciadora (MCC).', 'wp-mcp-google-fator3' )
		);
		echo '</tbody></table>';

		self::form_start( 'f3_mcp_google_save_ads' );
		echo '<p><label for="f3-ads-token">' . esc_html__( 'Developer token (deixe em branco para não alterar):', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="password" id="f3-ads-token" name="ads_developer_token" class="regular-text" autocomplete="new-password" value=""></p>';
		echo '<p><label><input type="checkbox" name="clear_developer_token" value="1"> '
			. esc_html__( 'Remover o developer token gravado', 'wp-mcp-google-fator3' ) . '</label></p>';

		echo '<p><label for="f3-ads-login">' . esc_html__( 'Login customer ID (a MCC, só dígitos; opcional):', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="text" id="f3-ads-login" name="ads_login_customer_id" class="regular-text code" inputmode="numeric" value="'
			. esc_attr( Options::ads_login_customer_id() ) . '"></p>';

		echo '<p><label for="f3-ads-version">' . esc_html__( 'Versão da API:', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="text" id="f3-ads-version" name="ads_api_version" class="small-text code" value="'
			. esc_attr( Options::ads_api_version() ) . '"> ';
		echo '<span class="description">' . esc_html__( 'Formato vNN. O Google encerra versões a cada ~12 meses; trocar aqui evita esperar uma atualização do plugin.', 'wp-mcp-google-fator3' ) . '</span></p>';

		submit_button( __( 'Salvar Google Ads', 'wp-mcp-google-fator3' ), 'primary', 'submit', false );
		self::form_end();
	}

	private static function render_test(): void {
		echo '<h2>' . esc_html__( 'Testar conexão', 'wp-mcp-google-fator3' ) . '</h2>';
		echo '<p class="description" style="max-width:820px">'
			. esc_html__( 'Roda a bateria offline (cifra, assinatura JWT, lista de hosts, portão, configuração) e pede um access token de verdade para os escopos dos conectores ligados. Nenhum segredo aparece no resultado.', 'wp-mcp-google-fator3' )
			. '</p>';

		self::form_start( 'f3_mcp_google_test' );
		submit_button( __( 'Testar conexão agora', 'wp-mcp-google-fator3' ), 'secondary', 'submit', false );
		self::form_end();

		$result = get_transient( self::TEST_RESULT );
		if ( ! is_array( $result ) || empty( $result['checks'] ) ) {
			return;
		}

		printf(
			'<p><strong>%s</strong></p>',
			esc_html(
				sprintf(
					/* translators: 1: número de verificações que passaram, 2: número que falharam. */
					__( '%1$d passaram, %2$d falharam.', 'wp-mcp-google-fator3' ),
					(int) ( $result['passed'] ?? 0 ),
					(int) ( $result['failed'] ?? 0 )
				)
			)
		);

		echo '<table class="widefat striped" style="max-width:980px"><thead><tr>';
		echo '<th style="width:140px">' . esc_html__( 'Verificação', 'wp-mcp-google-fator3' ) . '</th>';
		echo '<th style="width:90px">' . esc_html__( 'Resultado', 'wp-mcp-google-fator3' ) . '</th>';
		echo '<th>' . esc_html__( 'Detalhe', 'wp-mcp-google-fator3' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( (array) $result['checks'] as $check ) {
			if ( ! is_array( $check ) ) {
				continue;
			}

			echo '<tr>';
			echo '<td><code>' . esc_html( (string) ( $check['name'] ?? '' ) ) . '</code></td>';
			echo '<td>' . ( in_array( $check['status'] ?? '', array( 'skipped', 'not_configured' ), true ) ? esc_html( $check['status'] ) : ( ! empty( $check['ok'] )
				? '<span style="color:#00845a">' . esc_html__( 'ok', 'wp-mcp-google-fator3' ) . '</span>'
				: '<strong style="color:#b32d2e">' . esc_html__( 'falhou', 'wp-mcp-google-fator3' ) . '</strong>' ) ) . '</td>';
			echo '<td>' . esc_html( (string) ( $check['detail'] ?? '' ) ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	private static function render_limits(): void {
		echo '<h2>' . esc_html__( 'Limites', 'wp-mcp-google-fator3' ) . '</h2>';

		self::form_start( 'f3_mcp_google_save_limits' );
		echo '<p><label for="f3-max-rows">' . esc_html__( 'Teto de linhas por relatório (1 a 10000):', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="number" id="f3-max-rows" name="max_rows" class="small-text" min="1" max="10000" value="'
			. esc_attr( (string) Options::max_rows() ) . '"></p>';
		echo '<p><label for="f3-timeout">' . esc_html__( 'Tempo limite HTTP em segundos (5 a 120):', 'wp-mcp-google-fator3' ) . '</label><br>';
		echo '<input type="number" id="f3-timeout" name="http_timeout" class="small-text" min="5" max="120" value="'
			. esc_attr( (string) Options::http_timeout() ) . '"></p>';
		submit_button( __( 'Salvar limites', 'wp-mcp-google-fator3' ), 'secondary', 'submit', false );
		self::form_end();
	}

	private static function render_requirements(): void {
		echo '<h2>' . esc_html__( 'Pré-requisitos', 'wp-mcp-google-fator3' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:820px"><tbody>';

		printf(
			'<tr><th style="width:230px">%1$s</th><td>%2$s</td></tr>',
			esc_html__( 'Abilities API', 'wp-mcp-google-fator3' ),
			Plugin::abilities_api_available()
				? esc_html__( 'disponível — as rotas estão registradas', 'wp-mcp-google-fator3' )
				: '<strong style="color:#b32d2e">' . esc_html__( 'AUSENTE — nenhuma rota registrada. Requer WordPress 6.9+ ou um plugin que traga o polyfill.', 'wp-mcp-google-fator3' ) . '</strong>'
		);

		printf(
			'<tr><th>%1$s</th><td>%2$s</td></tr>',
			esc_html__( 'Servidor MCP', 'wp-mcp-google-fator3' ),
			Plugin::mcp_server_detected()
				? esc_html__( 'detectado — as rotas são alcançáveis de fora', 'wp-mcp-google-fator3' )
				: '<strong>' . esc_html__( 'não detectado — as rotas existem no WordPress mas nada as expõe por MCP', 'wp-mcp-google-fator3' ) . '</strong>'
		);

		printf(
			'<tr><th>%1$s</th><td><code>%2$s</code></td></tr>',
			esc_html__( 'Versão do WordPress', 'wp-mcp-google-fator3' ),
			esc_html( get_bloginfo( 'version' ) )
		);

		printf(
			'<tr><th>%1$s</th><td><code>%2$s</code></td></tr>',
			esc_html__( 'Cifra dos segredos', 'wp-mcp-google-fator3' ),
			esc_html( Crypto::backend() )
		);

		printf(
			'<tr><th>%1$s</th><td>%2$s</td></tr>',
			esc_html__( 'OpenSSL (assinatura JWT)', 'wp-mcp-google-fator3' ),
			function_exists( 'openssl_sign' )
				? esc_html__( 'disponível', 'wp-mcp-google-fator3' )
				: '<strong style="color:#b32d2e">' . esc_html__( 'ausente — o modo service account não funciona', 'wp-mcp-google-fator3' ) . '</strong>'
		);

		echo '</tbody></table>';
	}

	private static function render_audit(): void {
		$log = Audit::recent( 30 );

		echo '<h2>' . esc_html__( 'Últimas operações', 'wp-mcp-google-fator3' ) . '</h2>';

		if ( empty( $log ) ) {
			echo '<p>' . esc_html__( 'Nenhuma operação registrada ainda.', 'wp-mcp-google-fator3' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped" style="max-width:980px"><thead><tr>';
		echo '<th>' . esc_html__( 'Quando (UTC)', 'wp-mcp-google-fator3' ) . '</th>';
		echo '<th>' . esc_html__( 'Ação', 'wp-mcp-google-fator3' ) . '</th>';
		echo '<th>' . esc_html__( 'Alvo', 'wp-mcp-google-fator3' ) . '</th>';
		echo '<th>' . esc_html__( 'Usuário', 'wp-mcp-google-fator3' ) . '</th>';
		echo '<th>' . esc_html__( 'Detalhe', 'wp-mcp-google-fator3' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $log as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$user  = get_userdata( (int) ( $row['user'] ?? 0 ) );
			$extra = array();

			foreach ( (array) ( $row['extra'] ?? array() ) as $key => $value ) {
				if ( is_scalar( $value ) ) {
					$extra[] = $key . '=' . (string) $value;
				}
			}

			echo '<tr>';
			echo '<td>' . esc_html( (string) ( $row['time'] ?? '' ) ) . '</td>';
			echo '<td><code>' . esc_html( (string) ( $row['action'] ?? '' ) ) . '</code></td>';
			echo '<td><code>' . esc_html( (string) ( $row['target'] ?? '' ) ) . '</code></td>';
			echo '<td>' . esc_html( $user ? $user->user_login : (string) ( $row['user'] ?? '' ) ) . '</td>';
			echo '<td>' . esc_html( implode( ' ', $extra ) ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';

		self::form_start( 'f3_mcp_google_clear_log' );
		submit_button( __( 'Limpar log', 'wp-mcp-google-fator3' ), 'delete', 'submit', false );
		self::form_end();
	}

	/**
	 * Abre um formulário para admin-post.php com nonce e action.
	 *
	 * O nome do nonce é o mesmo da action de propósito: um handler confere
	 * `check_admin_referer( $action )` e não há como trocar um pelo outro.
	 */
	private static function form_start( string $action ): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( $action );
		echo '<input type="hidden" name="connection_id" value="' . esc_attr( Connections::id() ) . '">';
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
	}

	private static function form_end(): void {
		echo '</form>';
	}
}
