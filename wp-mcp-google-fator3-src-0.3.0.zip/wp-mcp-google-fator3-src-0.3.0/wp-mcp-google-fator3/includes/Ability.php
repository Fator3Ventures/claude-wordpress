<?php
/**
 * Registrador padrão das habilidades.
 *
 * Toda rota `ga/*`, `ads/*` e `google/*` passa por aqui em vez de chamar
 * `wp_register_ability()` direto. O motivo é que quatro coisas precisam ser
 * iguais em todas elas e são exatamente as que se esquece de repetir:
 * `meta.mcp.public` (sem isso o WP MCP Ultimate não expõe a rota),
 * `permission_callback` (sem isso a rota fica aberta a qualquer usuário
 * autenticado), o portão do `Gate` no início da execução e o registro de
 * auditoria no fim. Centralizar também garante que uma exceção vire resposta de
 * erro em vez de HTTP 500 no meio de uma sessão MCP.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Ability {

	/**
	 * Registra uma habilidade com os padrões da casa.
	 *
	 * @param string $name      Ex.: 'ga/run-report'.
	 * @param string $connector 'ga' | 'ads' | 'any' — usado pelo Gate.
	 * @param array  $args      label, description, input_schema, output_schema
	 *                          (opcional), callback, meta (opcional).
	 */
	public static function register( string $name, string $connector, array $args ): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		$mode     = 'write' === ( $args['mode'] ?? 'read' ) ? 'write' : 'read';
		$callback = $args['callback'] ?? null;
		if ( ! is_callable( $callback ) ) {
			return;
		}

		$input_schema = isset( $args['input_schema'] ) && is_array( $args['input_schema'] )
			? $args['input_schema']
			: array();

		// O esquema de entrada é sempre um objeto fechado: o WordPress 6.9+
		// valida a entrada contra ele antes de executar, e `additionalProperties
		// = false` faz um parâmetro com nome errado falhar na hora, em vez de
		// ser silenciosamente ignorado e produzir um relatório errado.
		$input_schema['type'] = 'object';
		if ( ! isset( $input_schema['properties'] ) || ! is_array( $input_schema['properties'] ) ) {
			$input_schema['properties'] = array();
		}
		$input_schema['additionalProperties'] = false;
		$input_schema['properties']['connection_id'] = array( 'type' => 'string', 'description' => 'Conexão Google; omissão usa a conexão padrão, ou a conexão do job em execução.' );

		$output_schema = isset( $args['output_schema'] ) && is_array( $args['output_schema'] )
			? $args['output_schema']
			: array(
				'type'       => 'object',
				'properties' => array(
					'success' => array( 'type' => 'boolean' ),
					'message' => array( 'type' => 'string' ),
				),
			);

		$meta = isset( $args['meta'] ) && is_array( $args['meta'] ) ? $args['meta'] : array();

		$meta['mcp'] = array_merge(
			array(
				'public' => true,
				'type'   => 'tool',
			),
			isset( $meta['mcp'] ) && is_array( $meta['mcp'] ) ? $meta['mcp'] : array()
		);

		// As anotações refletem efeitos possíveis; a confirmação pertence ao agente.
		$meta['annotations'] = array(
			'readonly'    => 'read' === $mode,
			'destructive' => 'write' === $mode,
			'idempotent'  => 'read' === $mode,
		);

		wp_register_ability(
			$name,
			array(
				'label'               => (string) ( $args['label'] ?? $name ),
				'description'         => (string) ( $args['description'] ?? '' ),
				'category'            => 'google',
				'input_schema'        => $input_schema,
				'output_schema'       => $output_schema,
				'permission_callback' => static function ( $input = array() ) use ( $connector ): bool {
					$id = (string) ( self::normalize_input( $input )['connection_id'] ?? Connections::id() );
					$permitted = Connections::run( $id, static fn() => Gate::permission( $connector ) );
					return true === $permitted;
				},
				'execute_callback'    => static function ( $input = array() ) use ( $name, $connector, $callback, $mode ): array {
					return Connections::run( (string) ( self::normalize_input( $input )['connection_id'] ?? Connections::id() ), static fn() => self::run( $name, $connector, $callback, $input, $mode ) );
				},
				'meta'                => $meta,
			)
		);
	}

	/**
	 * Executa a habilidade: normaliza a entrada, aplica o portão, cronometra,
	 * converte exceção em erro e audita.
	 *
	 * @param string   $name      Nome da habilidade.
	 * @param string   $connector Conector para o Gate.
	 * @param callable $callback  Implementação da rota.
	 * @param mixed    $input     Entrada crua vinda do servidor MCP.
	 */
	private static function run( string $name, string $connector, callable $callback, $input, string $mode = 'read' ): array {
		$input   = self::normalize_input( $input );
		$target  = self::target( $input );
		$dry_run = ! empty( $input['dry_run'] ) || ( 'ga/send-event' === $name && ! empty( $input['debug'] ) ) || ( 'google/execute-action' === $name && ( ! empty( $input['body']['validateOnly'] ) || ! empty( $input['query']['validateOnly'] ) ) );

		if ( 'write' === $mode ) {
			Audit::begin();
		}
		$gate = Gate::check( $connector );
		if ( null !== $gate ) {
			Audit::log(
				$name,
				$target,
				array(
					'status'  => 'denied',
					'mode'    => $mode,
					'dry_run' => $dry_run,
				) + ( 'write' === $mode ? Audit::finish() : array() )
			);

			return $gate;
		}

		$started = microtime( true );

		try {
			$result = self::invoke( $name, $mode, $connector, $callback, $input );

			if ( is_wp_error( $result ) ) {
				$result = Response::fail( $result );
			} elseif ( ! is_array( $result ) ) {
				$result = Response::fail(
					new \WP_Error(
						'f3_google_bad_result',
						__( 'A habilidade não devolveu uma resposta válida.', 'wp-mcp-google-fator3' )
					)
				);
			}
		} catch ( \Throwable $e ) {
			// A mensagem da exceção pode ter passado por um trecho que
			// manipulava credencial; passa pelo filtro antes de sair.
			$result = Response::fail(
				new \WP_Error(
					'f3_google_exception',
					sprintf(
						/* translators: %s: mensagem da exceção. */
						__( 'Falha interna ao executar a habilidade: %s', 'wp-mcp-google-fator3' ),
						self::scrub( $e->getMessage() )
					)
				)
			);
		}

		if ( 'google/selftest' === $name && ! array_key_exists( 'execution_success', $result ) ) { $result['execution_success'] = false; $result['checks_passed'] = false; }
		Audit::log(
			$name,
			$target,
			array(
				'ms'      => (int) round( ( microtime( true ) - $started ) * 1000 ),
				'rows'    => self::rows_in( $result ),
				'status'  => ! empty( $result['success'] ) ? 'ok' : 'erro',
				'mode'    => $mode,
				'dry_run' => $dry_run,
			) + ( 'write' === $mode ? Audit::finish() + array(
				'result' => array(
					'success'    => ! empty( $result['success'] ),
					'error_code' => $result['error_code'] ?? null,
				),
			) : array() )
		);

		return $result;
	}

	/** Resolve seletor nomeado antes de chamar a operação; * é fanout explícito. */
	private static function invoke( string $name, string $mode, string $connector, callable $callback, array $input ) {
		$key = array(
			'ga'  => 'property_id',
			'ads' => 'customer_id',
			'gsc' => 'site_url',
		)[ $connector ] ?? '';
		if ( '' === $key || ! isset( $input[ $key ] ) || ! is_scalar( $input[ $key ] ) || '' === trim( (string) $input[ $key ] ) ) {
			return $callback( $input );
		}
		$ids = Unified\Accounts::resolve_many( $connector, array( (string) $input[ $key ] ) );
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}
		if ( '*' !== (string) $input[ $key ] && 1 === count( $ids ) ) {
			$input[ $key ] = $ids[0];
			return $callback( $input );
		}
		$results = array();
		$ok      = true;
		foreach ( $ids as $id ) {
			$item         = $input;
			$item[ $key ] = $id;
			// Cada alvo tem sua auditoria completa, além da entrada de fanout.
			Audit::begin();
			try {
				$result = $callback( $item );
				$result = is_wp_error( $result ) ? Response::fail( $result ) : $result;
			} catch ( \Throwable $e ) {
				$result = Response::fail( self::scrub( $e->getMessage() ) );
			}
			$snapshots = Audit::finish();
			$results[] = array(
				'account_id' => $id,
				'result'     => $result,
			);
			$ok        = $ok && ! empty( $result['success'] );
			Audit::log(
				$name,
				$id,
				array(
					'mode'    => $mode,
					'status'  => ! empty( $result['success'] ) ? 'ok' : 'erro',
					'dry_run' => ! empty( $input['dry_run'] ),
				) + $snapshots
			);
		}
		return array(
			'success' => $ok,
			'message' => count( $results ) . ' alvo(s) executado(s).',
			'results' => $results,
		);
	}

	/**
	 * Vários clientes MCP mandam o objeto de parâmetros como string JSON; o
	 * `execute-ability` do Ultimate já decodifica, mas uma chamada direta à
	 * habilidade (WP-CLI, outro servidor) pode não fazer isso.
	 *
	 * @param mixed $input Entrada crua.
	 */
	private static function normalize_input( $input ): array {
		if ( is_string( $input ) ) {
			$decoded = json_decode( $input, true );
			$input   = is_array( $decoded ) ? $decoded : array();
		}

		return is_array( $input ) ? $input : array();
	}

	/**
	 * Alvo da operação para o log: a propriedade GA ou a conta Ads.
	 */
	private static function target( array $input ): string {
		foreach ( array( 'property_id', 'customer_id', 'site_url', 'spreadsheet_id', 'name', 'resource' ) as $key ) {
			if ( isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ) {
				$value = trim( (string) $input[ $key ] );
				if ( '' !== $value ) {
					return $value;
				}
			}
		}

		return '-';
	}

	/**
	 * Quantas linhas a resposta devolveu, para o log.
	 */
	private static function rows_in( array $result ): int {
		if ( isset( $result['row_count'] ) && is_numeric( $result['row_count'] ) ) {
			return (int) $result['row_count'];
		}

		if ( isset( $result['rows'] ) && is_array( $result['rows'] ) ) {
			return count( $result['rows'] );
		}

		return 0;
	}

	/**
	 * Remove qualquer segredo configurado de um texto antes de ele sair.
	 *
	 * Defesa em profundidade: nenhum caminho conhecido põe credencial numa
	 * mensagem de exceção, mas o custo de garantir é baixo e o de errar é uma
	 * chave privada num transcript de conversa.
	 */
	public static function scrub( string $text ): string {
		if ( '' === $text ) {
			return $text;
		}

		foreach ( Options::secret_names() as $name ) {
			$secret = Options::get_secret( $name );
			if ( Options::SA_JSON === $name ) {
				$key = json_decode( $secret, true );
				if ( is_array( $key ) && ! empty( $key['private_key'] ) ) {
					$text = str_replace( array( (string) $key['private_key'], str_replace( "\n", '\\n', (string) $key['private_key'] ) ), '[redigido]', $text );
				}
			}
			if ( strlen( $secret ) >= 8 && false !== strpos( $text, $secret ) ) {
				$text = str_replace( $secret, '[redigido]', $text );
			}
		}

		foreach ( (array) Options::get( Options::TOKEN_INDEX, array() ) as $key ) {
			if ( ! is_string( $key ) || 0 !== strpos( $key, Auth\Credentials::CACHE_PREFIX ) ) {
				continue; }
			$token = Auth\Credentials::cached( $key );
			if ( is_string( $token ) && strlen( $token ) >= 8 ) {
				$text = str_replace( $token, '[token redigido]', $text ); }
		}

		return $text;
	}
}
