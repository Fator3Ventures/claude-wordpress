<?php
/**
 * Nomes e leitura/gravação das opções do plugin.
 *
 * Toda opção mora aqui por dois motivos. O primeiro é banal: um único lugar
 * para o `uninstall.php` e para o filtro `wp_mcp_ultimate_protected_options`
 * saberem o que existe. O segundo é a razão de o arquivo ser maior do que
 * parece necessário — os segredos.
 *
 * Este site expõe o banco e as opções por MCP (`db/query` do WP MCP Fator3,
 * `options/get` do WP MCP Ultimate). Um agente com essas rotas leria a chave da
 * service account com uma chamada. Por isso a chave, o client secret, o refresh
 * token e o developer token são gravados cifrados (ver `Crypto`) e, além disso,
 * um filtro `pre_option_*` faz `get_option()` devolver vazio para eles: nem o
 * blob cifrado sai daqui. A trava só se abre pelo tempo exato de uma leitura
 * feita pelo próprio plugin, em `get_secret()`.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Options {

	public const ENABLED               = 'f3_mcp_google_enabled';
	public const GA_ENABLED            = 'f3_mcp_google_ga_enabled';
	public const ADS_ENABLED           = 'f3_mcp_google_ads_enabled';
	public const AUTH_MODE             = 'f3_mcp_google_auth_mode';
	public const SA_JSON               = 'f3_mcp_google_sa_json';
	public const SA_SUBJECT            = 'f3_mcp_google_sa_subject';
	public const OAUTH_CLIENT_ID       = 'f3_mcp_google_oauth_client_id';
	public const OAUTH_CLIENT_SECRET   = 'f3_mcp_google_oauth_client_secret';
	public const OAUTH_REFRESH_TOKEN   = 'f3_mcp_google_oauth_refresh_token';
	public const OAUTH_EMAIL           = 'f3_mcp_google_oauth_email';
	public const OAUTH_SCOPES          = 'f3_mcp_google_oauth_scopes';
	public const ADS_DEVELOPER_TOKEN   = 'f3_mcp_google_ads_developer_token';
	public const ADS_LOGIN_CUSTOMER_ID = 'f3_mcp_google_ads_login_customer_id';
	public const ADS_API_VERSION       = 'f3_mcp_google_ads_api_version';
	public const GA_DEFAULT_PROPERTY   = 'f3_mcp_google_ga_default_property';
	public const MAX_ROWS              = 'f3_mcp_google_max_rows';
	public const HTTP_TIMEOUT          = 'f3_mcp_google_http_timeout';
	public const AUDIT                 = 'f3_mcp_google_audit';

	/**
	 * Índice das chaves de transient onde há token em cache.
	 *
	 * Existe porque não dá para enumerar transients sem SQL: quando a
	 * credencial muda, `Credentials::invalidate_cache()` precisa saber quais
	 * apagar, senão um token da credencial antiga continuaria valendo por até
	 * uma hora.
	 */
	public const TOKEN_INDEX = 'f3_mcp_google_token_index';

	/**
	 * A trava dos segredos está aberta?
	 *
	 * Contador, não booleano: `set_secret()` chama `update_option()`, que por
	 * dentro chama `get_option()`, e uma leitura aninhada não pode fechar a
	 * trava que a de fora abriu.
	 */
	private static int $unlocked = 0;
	private static array $write_locks = array();

	/**
	 * Liga o filtro que esconde os segredos de qualquer `get_option()`.
	 */
	public static function init(): void {
		$names = self::secret_names();
		foreach ( Connections::registry() as $id => $meta ) {
			if ( 'default' === $id ) { continue; }
			foreach ( self::secret_names() as $name ) { $names[] = 'f3_mcp_google_conn_' . $id . '_' . substr( $name, strlen( 'f3_mcp_google_' ) ); }
		}
		foreach ( $names as $name ) {
			add_filter( 'pre_option_' . $name, array( self::class, 'hide_secret' ), 10, 3 );
		}
	}

	/**
	 * Filtro `pre_option_*`: devolve string vazia (curto-circuito) enquanto a
	 * trava estiver fechada, e deixa passar quando o próprio plugin está lendo.
	 *
	 * @param mixed  $pre           Valor de curto-circuito atual.
	 * @param string $option        Nome da opção.
	 * @param mixed  $default_value Valor padrão pedido pelo chamador.
	 * @return mixed
	 */
	public static function hide_secret( $pre, $option = '', $default_value = false ) {
		unset( $option, $default_value );
		if ( self::$unlocked > 0 ) {
			return $pre;
		}

		return '';
	}

	/**
	 * Executa uma leitura/gravação com a trava aberta.
	 *
	 * @param callable $callback Trecho que precisa enxergar o valor cifrado.
	 * @return mixed
	 */
	private static function unlocked( callable $callback ) {
		++self::$unlocked;
		try {
			return $callback();
		} finally {
			--self::$unlocked;
		}
	}

	/**
	 * @return string[]
	 */
	public static function all_names(): array {
		$names = array(
			self::ENABLED,
			self::GA_ENABLED,
			self::ADS_ENABLED,
			self::AUTH_MODE,
			self::SA_JSON,
			self::SA_SUBJECT,
			self::OAUTH_CLIENT_ID,
			self::OAUTH_CLIENT_SECRET,
			self::OAUTH_REFRESH_TOKEN,
			self::OAUTH_EMAIL,
			self::OAUTH_SCOPES,
			self::ADS_DEVELOPER_TOKEN,
			self::ADS_LOGIN_CUSTOMER_ID,
			self::ADS_API_VERSION,
			self::GA_DEFAULT_PROPERTY,
			self::MAX_ROWS,
			self::HTTP_TIMEOUT,
			self::AUDIT,
			self::TOKEN_INDEX,
		);
		$names = array_merge( $names, array( 'f3_mcp_google_audit_retention', 'f3_mcp_google_inspection_budget' ) );
		if ( class_exists( Connections::class, false ) ) { $names = array_merge( $names, Connections::protected_names() ); }
		global $wpdb;
		if ( isset( $wpdb ) && is_callable( array( $wpdb, 'get_col' ) ) ) {
			$names = array_merge( $names, (array) $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'f3_mcp_google_' ) . '%' ) ) );
		}
		return array_values( array_unique( $names ) );
	}

	/**
	 * Opções que guardam segredo: cifradas em repouso e invisíveis a
	 * `get_option()`.
	 *
	 * @return string[]
	 */
	public static function secret_names(): array {
		return array(
			self::SA_JSON,
			self::OAUTH_CLIENT_SECRET,
			self::OAUTH_REFRESH_TOKEN,
			self::ADS_DEVELOPER_TOKEN,
		);
	}

	/**
	 * Autoload só para o que é lido em toda requisição.
	 *
	 * O log de auditoria e os segredos ficam de fora: o log é grande e os
	 * segredos não devem entrar no cache `alloptions`.
	 */
	private static function autoload_for( string $name ): bool {
		if ( 0 === strpos( $name, 'f3_mcp_google_record_' ) || 0 === strpos( $name, 'f3_mcp_google_lock_' ) || 0 === strpos( $name, 'f3_mcp_google_quota_' ) || self::AUDIT === $name || self::TOKEN_INDEX === $name || 0 === strpos( $name, 'f3_mcp_google_conn_' ) ) {
			return false;
		}

		return ! in_array( $name, self::secret_names(), true );
	}

	/**
	 * @param string $name    Nome da opção.
	 * @param mixed  $default Valor devolvido quando ausente.
	 * @return mixed
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.defaultFound -- Preserva argumento nomeado público da 0.1.0.
	public static function get( string $name, $default = null ) {
		$preview = class_exists( Connections::class, false ) ? Connections::preview_values() : array();
		return array_key_exists( $name, $preview ) ? $preview[ $name ] : get_option( self::storage_name( $name ), $default );
	}

	/**
	 * @param string $name  Nome da opção.
	 * @param mixed  $value Valor.
	 */
	public static function set( string $name, $value ): array {
		return self::write_verified( $name, $value );
	}

	public static function delete( string $name ): array {
		return self::write_verified( $name, null, false, true );
	}

	/** Read the database directly: cached/filtered reads cannot prove persistence. */
	public static function stored( string $name ): array {
		try { return self::read_stored( $name ); } catch ( \Throwable $error ) { return array( 'success' => false, 'exists' => false, 'value' => null ); }
	}
	private static function read_stored( string $name ): array {
		global $wpdb;
		if ( isset( $wpdb ) && is_callable( array( $wpdb, 'get_row' ) ) ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ), ARRAY_A );
			if ( ! empty( $wpdb->last_error ) ) {
				return array( 'success' => false, 'exists' => false, 'value' => null );
			}
			return array( 'success' => true, 'exists' => null !== $row, 'value' => null !== $row ? maybe_unserialize( $row['option_value'] ) : null );
		}
		$missing = new \stdClass();
		$value = self::unlocked( static fn() => get_option( $name, $missing ) );
		return array( 'success' => true, 'exists' => $missing !== $value, 'value' => $missing !== $value ? $value : null );
	}

	private static function equivalent( $a, $b ): bool {
		if ( is_scalar( $a ) || null === $a ) {
			return ( is_scalar( $b ) || null === $b ) && (string) $a === (string) $b;
		}
		return $a === $b;
	}

	/** Structured outcome never contains the previous/new value or ciphertext. */
	public static function write_verified( string $name, $value, bool $secret = false, bool $delete = false ): array {
		return self::with_write_locks( array( $name ), static fn() => self::write_value( $name, $value, $secret, $delete ) );
	}

	private static function write_value( string $name, $value, bool $secret, bool $delete ): array {
		$original = $name;
		$name = self::storage_name( $name );
		$result = array( 'success' => false, 'persisted' => false, 'changed' => false, 'option' => $original, 'error_code' => null, 'message' => '' );
		$fail = static function ( string $code, string $message ) use ( $result ): array {
			return array_replace( $result, array( 'error_code' => $code, 'message' => $message ) );
		};
		$before = self::stored( $name );
		if ( ! $before['success'] ) {
			return $fail( 'f3_google_option_read', 'Falha ao consultar o valor persistido.' );
		}
		$phase = $secret && ! $delete ? 'crypto' : 'storage';
		try {
			if ( $secret && ! $delete ) {
				$old = $before['exists'] ? Crypto::decrypt( (string) $before['value'] ) : null;
				if ( is_string( $old ) && hash_equals( $old, (string) $value ) ) {
					return array_replace( $result, array( 'success' => true, 'persisted' => true, 'message' => 'Valor já persistido.' ) );
				}
				$plain = (string) $value;
				$value = Crypto::encrypt( $plain );
				if ( '' === $value ) {
					return $fail( 'f3_google_crypto_encrypt', 'Não foi possível cifrar o segredo.' );
				}
				$verified = Crypto::decrypt( $value );
				if ( is_wp_error( $verified ) || ! hash_equals( $plain, (string) $verified ) ) {
					return $fail( 'f3_google_crypto_verify', 'Não foi possível verificar a cifra do segredo.' );
				}
			}
			$phase = 'storage';
			self::unlocked( static function () use ( $name, $value, $delete, $secret ) {
				return $delete ? delete_option( $name ) : update_option( $name, $value, $secret ? false : self::autoload_for( $name ) );
			} );
		} catch ( \Throwable $error ) {
			return $fail( 'crypto' === $phase ? 'f3_google_crypto_encrypt' : 'f3_google_option_write', 'Falha na preparação ou gravação da opção.' );
		}
		$after = self::stored( $name );
		if ( ! $after['success'] ) {
			return $fail( 'f3_google_option_verify_read', 'A leitura de confirmação falhou; persistência não confirmada.' );
		}
		if ( $delete ? $after['exists'] : ( ! $after['exists'] || ! self::equivalent( $value, $after['value'] ) ) ) {
			return $fail( $delete ? 'f3_google_option_delete' : 'f3_google_option_persistence', 'O valor esperado não foi confirmado no armazenamento.' );
		}
		return array_replace( $result, array( 'success' => true, 'persisted' => true, 'changed' => $delete ? $before['exists'] : ( ! $before['exists'] || ! self::equivalent( $before['value'], $after['value'] ) ), 'message' => 'Persistência confirmada.' ) );
	}

	/** Validate/cipher all secrets before any write; compensate confirmed writes on failure. */
	public static function batch_verified( array $values, array $secrets = array(), array $deletes = array() ): array {
		$names = array_unique( array_merge( array_keys( $values ), array_keys( $secrets ), $deletes ) );
		return self::with_write_locks( $names, static fn() => self::write_batch( $values, $secrets, $deletes ) );
	}

	private static function write_batch( array $values, array $secrets, array $deletes ): array {
		$prepared = $values;
		foreach ( $secrets as $name => $plain ) {
			if ( '' === $plain ) { $deletes[] = $name; continue; }
			try { $cipher = Crypto::encrypt( (string) $plain ); } catch ( \Throwable $error ) { $cipher = ''; }
			if ( '' === $cipher ) {
				return array( 'success' => false, 'persisted' => false, 'error_code' => 'f3_google_crypto_encrypt', 'message' => 'Não foi possível cifrar o segredo.', 'option' => $name );
			}
			try { $check = Crypto::decrypt( $cipher ); } catch ( \Throwable $error ) { $check = new \WP_Error( 'f3_google_crypto_verify', 'Falha de cifra.' ); }
			if ( is_wp_error( $check ) || ! hash_equals( (string) $plain, (string) $check ) ) {
				return array( 'success' => false, 'persisted' => false, 'error_code' => 'f3_google_crypto_verify', 'message' => 'Falha na verificação da cifra.', 'option' => $name );
			}
			$prepared[ $name ] = $cipher;
		}
		$snapshots = array(); $out = array();
		foreach ( array_unique( array_merge( array_keys( $prepared ), $deletes ) ) as $name ) {
			$snapshots[ $name ] = self::stored( self::storage_name( $name ) );
			if ( ! $snapshots[ $name ]['success'] ) { return array( 'success' => false, 'persisted' => false, 'error_code' => 'f3_google_option_read', 'message' => 'Falha ao preparar a gravação.' ); }
		}
		foreach ( $snapshots as $name => $before ) {
			$out[ $name ] = self::write_verified( $name, $prepared[ $name ] ?? null, false, in_array( $name, $deletes, true ) );
			if ( ! $out[ $name ]['success'] ) {
				$rollback = array();
				foreach ( array_reverse( array_keys( $out ) ) as $done ) {
					$old = $snapshots[ $done ];
					$current = self::stored( self::storage_name( $done ) );
					$was_deleted = in_array( $done, $deletes, true );
					$matches = $current['success'] && ( $was_deleted ? ! $current['exists'] : ( $current['exists'] && self::equivalent( $current['value'], $prepared[ $done ] ) ) );
					$unchanged = $current['success'] && $current['exists'] === $old['exists'] && self::equivalent( $current['value'], $old['value'] );
					if ( ! $matches && ! $unchanged ) { $rollback[ $done ] = array( 'success' => false, 'persisted' => false, 'error_code' => 'f3_google_rollback_conflict', 'message' => 'Valor alterado externamente; restauração não aplicada.' ); continue; }
					$rollback[ $done ] = self::write_verified( $done, $old['value'], false, ! $old['exists'] );
				}
				return $out[ $name ] + array( 'operations' => $out, 'rollback' => $rollback );
			}
		}
		return array( 'success' => true, 'persisted' => true, 'operations' => $out );
	}

	/** Serialize plugin writes per option; leases are released even after an exception. */
	private static function with_write_locks( array $names, callable $callback ): array {
		$keys = array_unique( array_map( array( self::class, 'storage_name' ), $names ) );
		sort( $keys ); $acquired = array();
		try {
			foreach ( $keys as $key ) {
				if ( isset( self::$write_locks[ $key ] ) ) { continue; }
				$lock = Lock::acquire( 'option:' . $key, 180 );
				if ( null === $lock ) { return array( 'success' => false, 'persisted' => false, 'changed' => false, 'option' => $key, 'error_code' => 'f3_google_option_busy', 'message' => 'Outra gravação está em andamento.' ); }
				self::$write_locks[ $key ] = $lock; $acquired[] = $key;
			}
			return $callback();
		} finally {
			foreach ( array_reverse( $acquired ) as $key ) { Lock::release( self::$write_locks[ $key ] ); unset( self::$write_locks[ $key ] ); }
		}
	}

	/** Internal records/leases require INSERT-only semantics; add_option() can upsert. */
	public static function insert_exclusive( string $name, array $value ): bool {
		global $wpdb;
		if ( isset( $wpdb ) && is_callable( array( $wpdb, 'get_row' ) ) ) {
			$result = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, %s)", $name, maybe_serialize( $value ), 'off' ) );
			if ( 1 !== $result ) { return false; }
			if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( $name, 'options' ); wp_cache_delete( 'notoptions', 'options' ); }
			return true;
		}
		return add_option( $name, $value, '', false );
	}

	public static function storage_name( string $name ): string {
		return class_exists( Connections::class, false ) ? Connections::option_name( $name ) : $name;
	}

	/**
	 * Lê um segredo já decifrado.
	 *
	 * Devolve '' quando ausente ou quando a decifra falha — o que acontece, por
	 * exemplo, se as salts do `wp-config.php` forem trocadas. Falha silenciosa
	 * aqui é proposital: quem chama trata "sem credencial", e a tela de
	 * administração mostra o estado.
	 */
	public static function get_secret( string $name ): string {
		$stored = self::unlocked(
			static function () use ( $name ) {
				return get_option( self::storage_name( $name ), '' );
			}
		);

		if ( ! is_string( $stored ) || '' === $stored ) {
			return '';
		}

		$plain = Crypto::decrypt( $stored );

		return is_wp_error( $plain ) ? '' : (string) $plain;
	}

	/**
	 * Grava um segredo cifrado. String vazia apaga a opção.
	 */
	public static function set_secret( string $name, string $plain ): array {
		return self::write_verified( $name, $plain, true, '' === $plain );
	}

	public static function secret_problem( string $name ): ?\WP_Error {
		$stored = self::stored( self::storage_name( $name ) );
		if ( ! $stored['success'] ) { return new \WP_Error( 'f3_google_option_read', 'Não foi possível ler a credencial persistida.' ); }
		if ( ! $stored['exists'] || '' === $stored['value'] ) { return null; }
		$plain = Crypto::decrypt( (string) $stored['value'] );
		return is_wp_error( $plain ) ? new \WP_Error( 'f3_google_crypto_decrypt', 'A credencial existe, mas não pôde ser decifrada. Confira as salts e o backend de cifra.' ) : null;
	}

	public static function has_secret( string $name ): bool {
		return '' !== self::get_secret( $name );
	}

	/**
	 * Kill switch geral. O filtro tem a última palavra.
	 */
	public static function is_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_google_enabled', (bool) self::get( self::ENABLED, false ) );
	}

	public static function ga_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_google_ga_enabled', (bool) self::get( self::GA_ENABLED, false ) );
	}

	public static function ads_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_google_ads_enabled', (bool) self::get( self::ADS_ENABLED, false ) );
	}

	/**
	 * @return string 'service_account' ou 'oauth'.
	 */
	public static function auth_mode(): string {
		$mode = (string) self::get( self::AUTH_MODE, 'service_account' );
		if ( ! in_array( $mode, array( 'service_account', 'oauth' ), true ) ) {
			$mode = 'service_account';
		}

		$mode = (string) apply_filters( 'f3_mcp_google_auth_mode', $mode );

		return in_array( $mode, array( 'service_account', 'oauth' ), true ) ? $mode : 'service_account';
	}

	/**
	 * Versão da Google Ads API.
	 *
	 * Fica em opção porque o Google encerra versões a cada ~12 meses e o site
	 * não pode depender de uma atualização do plugin para voltar a funcionar.
	 * O formato é validado porque este valor entra na URL.
	 */
	public static function ads_api_version(): string {
		$version = (string) self::get( self::ADS_API_VERSION, 'v25' );
		$version = (string) apply_filters( 'f3_mcp_google_ads_api_version', $version );

		return preg_match( '/^v\d{1,3}$/', $version ) ? $version : 'v25';
	}

	/**
	 * @return string Só dígitos, ou ''.
	 */
	public static function ads_login_customer_id(): string {
		$id = preg_replace( '/\D+/', '', (string) self::get( self::ADS_LOGIN_CUSTOMER_ID, '' ) );

		return is_string( $id ) ? $id : '';
	}

	/**
	 * Teto de linhas por relatório. 10.000 é limite absoluto: acima disso a
	 * resposta estoura a janela de contexto de quem chamou.
	 */
	public static function max_rows(): int {
		$rows = (int) self::get( self::MAX_ROWS, 1000 );
		$rows = (int) apply_filters( 'f3_mcp_google_max_rows', $rows );

		return max( 1, min( 10000, $rows ) );
	}

	public static function http_timeout(): int {
		$timeout = (int) self::get( self::HTTP_TIMEOUT, 30 );
		$timeout = (int) apply_filters( 'f3_mcp_google_http_timeout', $timeout );

		return max( 5, min( 120, $timeout ) );
	}

	/**
	 * Capacidade exigida em toda habilidade.
	 *
	 * `manage_options` por padrão: quem lê Analytics e Ads pelo agente é o
	 * administrador do site, e o mínimo que o WP MCP Ultimate exige
	 * (`edit_posts`) alcançaria qualquer editor.
	 */
	public static function capability(): string {
		$capability = (string) apply_filters( 'f3_mcp_google_capability', 'manage_options' );

		return '' !== $capability ? $capability : 'manage_options';
	}
}
