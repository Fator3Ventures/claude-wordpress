<?php
/** Guided setup reuses verified mutations and the existing OAuth consent route. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class SetupAdmin {
	public static function init(): void {
		foreach ( array( 'save', 'import', 'create' ) as $action ) { add_action( 'admin_post_f3_google_setup_' . $action, static fn() => self::handle( $action ) ); }
	}
	private static function handle( string $action ): void {
		if ( ! current_user_can( Options::capability() ) ) { wp_die( 'Permissão insuficiente.' ); }
		check_admin_referer( 'f3_google_setup_' . $action );
		$id = isset( $_POST['connection_id'] ) && is_string( $_POST['connection_id'] ) ? sanitize_key( $_POST['connection_id'] ) : 'default';
		if ( is_wp_error( Connections::select( $id ) ) ) { wp_die( 'Conexão inválida.' ); }
		if ( 'save' === $action ) {
			$services = array();
			foreach ( (array) ( $_POST['services'] ?? array() ) as $service => $level ) { if ( is_string( $level ) && '' !== $level ) { $services[ $service ] = $level; } }
			$bindings = array();
			foreach ( array( 'ga_property_id', 'ads_customer_id', 'gsc_site_url', 'spreadsheet_id', 'sitemap_url' ) as $key ) { $bindings[ $key ] = isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? trim( wp_unslash( $_POST[ $key ] ) ) : ''; }
			Admin::require_saved( Setup::apply( array( 'services' => $services, 'bindings' => $bindings, 'validate_access' => ! empty( $_POST['validate_access'] ) ) ) );
		} elseif ( 'create' === $action ) {
			$new = isset( $_POST['new_id'] ) && is_string( $_POST['new_id'] ) ? sanitize_key( $_POST['new_id'] ) : '';
			$label = isset( $_POST['label'] ) && is_string( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
			Admin::require_saved( Connections::create( $new, $label ) ); Connections::select( $new );
		} else {
			$file = $_FILES['credential'] ?? array();
			if ( ! is_array( $file ) || ( $file['error'] ?? 1 ) !== UPLOAD_ERR_OK || ! is_string( $file['tmp_name'] ?? null ) || ! is_uploaded_file( $file['tmp_name'] ) || filesize( $file['tmp_name'] ) > 1048576 ) { wp_die( 'Envie um JSON de credenciais de até 1 MiB.' ); }
			$json = file_get_contents( $file['tmp_name'] );
			Admin::require_saved( self::import( is_string( $json ) ? $json : '' ) );
		}
		wp_safe_redirect( Admin::url( 'saved' ) ); exit;
	}
	public static function import( string $json ): array {
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) { return Response::fail( new \WP_Error( 'f3_google_credential_json', 'JSON inválido.' ) ); }
		if ( ( $data['type'] ?? '' ) === 'service_account' ) {
			$key = Auth\ServiceAccount::validate_key( $json );
			if ( is_wp_error( $key ) ) { return Response::fail( $key ); }
			$result = Options::batch_verified( array( Options::AUTH_MODE => 'service_account', Options::SA_SUBJECT => '' ), array( Options::SA_JSON => wp_json_encode( $key ) ) );
		} else {
			$web = $data['web'] ?? null;
			if ( ! is_array( $web ) || ! is_string( $web['client_id'] ?? null ) || ! is_string( $web['client_secret'] ?? null ) || '' === $web['client_id'] || '' === $web['client_secret'] ) { return Response::fail( new \WP_Error( 'f3_google_oauth_client_json', 'Envie o JSON de um cliente OAuth do tipo aplicativo Web.' ) ); }
			if ( ! in_array( Auth\OAuthFlow::redirect_uri(), (array) ( $web['redirect_uris'] ?? array() ), true ) ) { return Response::fail( new \WP_Error( 'f3_google_oauth_redirect', 'Cadastre o callback exibido neste painel no cliente Web e baixe o JSON atualizado.' ) ); }
			$deletes = $web['client_id'] !== Options::get( Options::OAUTH_CLIENT_ID, '' ) ? array( Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES ) : array();
			$result = Options::batch_verified( array( Options::AUTH_MODE => 'oauth', Options::OAUTH_CLIENT_ID => $web['client_id'] ), array( Options::OAUTH_CLIENT_SECRET => $web['client_secret'] ), $deletes );
		}
		if ( $result['success'] ) { Auth\Credentials::invalidate_cache(); Audit::log( 'configuration:import', Connections::id(), array( 'status' => 'ok' ) ); }
		return $result;
	}
	public static function render(): void {
		echo '<h2>Conexões e configuração assistida</h2><form method="get" action="' . esc_url( admin_url( 'tools.php' ) ) . '"><input type="hidden" name="page" value="' . esc_attr( Admin::SLUG ) . '"><label>Conexão <select name="connection_id">';
		foreach ( Connections::registry() as $id => $meta ) { echo '<option value="' . esc_attr( $id ) . '"' . selected( Connections::id(), $id, false ) . '>' . esc_html( $meta['label'] . ' (' . $id . ')' ) . '</option>'; }
		echo '</select></label> <button class="button">Abrir</button></form>';
		self::form( 'create' ); echo '<p><label>ID da nova conexão <input name="new_id" required pattern="[a-z][a-z0-9_-]{0,39}"></label> <label>Nome <input name="label" required></label> <button class="button">Criar conexão</button></p></form>';
		echo '<p>1. Escolha os serviços. 2. Importe as credenciais e conecte o OAuth quando aplicável. 3. Escolha os recursos e execute o teste de acesso.</p>';
		self::form( 'save' ); $services = Options::get( Connections::SERVICES, null );
		echo '<table class="form-table"><tbody>';
		foreach ( self::labels() as $service => $label ) {
			$level = is_array( $services ) ? ( $services[ $service ] ?? '' ) : ( 'ga' === $service ? 'admin' : 'write' );
			echo '<tr><th>' . esc_html( $label ) . '</th><td><select name="services[' . esc_attr( $service ) . ']">';
			foreach ( array_merge( array( '' ), Setup::LEVELS[ $service ] ) as $value ) { echo '<option value="' . esc_attr( $value ) . '"' . selected( $level, $value, false ) . '>' . esc_html( array( '' => 'Desativado', 'read' => 'Leitura', 'write' => 'Leitura e escrita', 'admin' => 'Administração, incluindo usuários' )[ $value ] ) . '</option>'; }
			echo '</select></td></tr>';
		}
		$bindings = (array) Options::get( Connections::BINDINGS, array() );
		foreach ( array( 'ga_property_id' => 'Propriedade GA4', 'ads_customer_id' => 'Conta Google Ads', 'gsc_site_url' => 'Propriedade Search Console', 'spreadsheet_id' => 'Planilha', 'sitemap_url' => 'Sitemap' ) as $key => $label ) { echo '<tr><th><label for="f3-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><input class="regular-text" id="f3-' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $bindings[ $key ] ?? '' ) . '"></td></tr>'; }
		echo '</tbody></table><p><label><input type="checkbox" name="validate_access" value="1"> Testar acesso aos recursos antes de salvar</label></p><button class="button button-primary">Salvar seleção e recursos</button></form>';
		self::form( 'import' ); echo '<p><label>JSON da service account ou do cliente OAuth Web <input type="file" name="credential" accept="application/json,.json" required></label> <button class="button">Importar credenciais</button></p></form>';
		echo '<p>Callback OAuth: <code>' . esc_html( Auth\OAuthFlow::redirect_uri() ) . '</code></p>';
		echo '<p><a class="button" href="' . esc_url( add_query_arg( 'discover', '1', Admin::url() ) ) . '">Consultar recursos acessíveis</a></p>';
		if ( Auth\Credentials::is_configured() && isset( $_GET['discover'] ) && '1' === $_GET['discover'] ) {
			echo '<details><summary>Recursos acessíveis</summary>';
			$accounts = Unified\Query::accounts( array( 'connector' => 'all' ) );
			echo '<pre style="max-height:240px;overflow:auto">' . esc_html( wp_json_encode( $accounts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre></details>';
		}
		echo '<p>Jobs e monitoramento usam WP-Cron. Para execução independente de visitas, configure o cron do servidor para acionar wp-cron.php. Consulte google/list-jobs para acompanhar resultados.</p>';
	}
	private static function form( string $action ): void {
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="f3_google_setup_' . esc_attr( $action ) . '"><input type="hidden" name="connection_id" value="' . esc_attr( Connections::id() ) . '">';
		wp_nonce_field( 'f3_google_setup_' . $action );
	}
	private static function labels(): array { return array( 'ga' => 'Analytics', 'ads' => 'Google Ads', 'gsc' => 'Search Console', 'siteverification' => 'Site Verification', 'sheets' => 'Sheets', 'drive' => 'Drive' ); }
}
