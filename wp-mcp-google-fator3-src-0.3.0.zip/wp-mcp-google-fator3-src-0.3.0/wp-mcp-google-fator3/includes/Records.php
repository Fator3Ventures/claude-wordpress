<?php
/** Independent, non-autoloaded records; unique inserts do not overwrite other writers. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Records {
	public const PREFIX = 'f3_mcp_google_record_';
	public static function key( string $kind, string $id ): string {
		if ( ! preg_match( '/^[a-z]+$/D', $kind ) || ! preg_match( '/^[a-zA-Z0-9_-]{1,100}$/D', $id ) ) { throw new \InvalidArgumentException( 'Identificador de registro inválido.' ); }
		return self::PREFIX . $kind . '_' . $id;
	}
	public static function id(): string { return sprintf( '%020d', (int) floor( microtime( true ) * 1000000 ) ) . '_' . bin2hex( random_bytes( 8 ) ); }
	public static function get( string $kind, string $id ): ?array {
		$value = get_option( self::key( $kind, $id ), null );
		return is_array( $value ) ? $value : null;
	}
	public static function insert( string $kind, string $id, array $record ): bool { return Options::insert_exclusive( self::key( $kind, $id ), $record ); }
	public static function put( string $kind, string $id, array $record ): array { return Options::write_verified( self::key( $kind, $id ), $record ); }
	public static function remove( string $kind, string $id ): array { return Options::delete( self::key( $kind, $id ) ); }
	public static function list( string $kind, int $limit = 1000, bool $newest = true ): array {
		global $wpdb;
		self::key( $kind, 'check' );
		if ( ! isset( $wpdb ) || ! is_callable( array( $wpdb, 'get_col' ) ) ) { return array(); }
		$prefix = self::PREFIX . $kind . '_';
		$direction = $newest ? 'DESC' : 'ASC';
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name $direction LIMIT %d", $wpdb->esc_like( $prefix ) . '%', max( 1, min( 10000, $limit ) ) ) );
		$out = array();
		foreach ( $names as $name ) {
			$value = get_option( $name, null );
			if ( is_array( $value ) ) { $out[ substr( $name, strlen( $prefix ) ) ] = $value; }
		}
		return $out;
	}
}
