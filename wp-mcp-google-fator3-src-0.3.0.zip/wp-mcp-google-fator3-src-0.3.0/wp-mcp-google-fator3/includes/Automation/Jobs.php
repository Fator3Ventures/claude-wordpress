<?php
/** Persistent bounded jobs. Writes interrupted in flight are never replayed automatically. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{Ability, Connections, Gate, Lock, Options, Preflight, Records, Response, SearchConsole\Workflow, Sheets\Export, Unified\Query};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Jobs {
	public const TASKS = array( 'inspect-urls', 'query', 'export', 'sitemap', 'report', 'preflight' );
	public const HOOK = 'f3_mcp_google_jobs_tick';
	public static function init(): void {
		add_action( self::HOOK, array( self::class, 'tick' ) );
		add_filter( 'cron_schedules', static function( array $schedules ): array { $schedules['f3_google_minute'] = array( 'interval' => 60, 'display' => 'MCP Google: um minuto' ); return $schedules; } );
		if ( Records::list( 'job', 1 ) || Records::list( 'schedule', 1 ) ) { self::schedule_tick(); }
	}
	private static function schedule_tick(): void {
		if ( function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( self::HOOK ) ) { wp_schedule_event( time() + 60, 'f3_google_minute', self::HOOK ); }
	}
	public static function create( array $input ): array {
		$task = $input['task'] ?? '';
		$params = $input['parameters'] ?? array();
		if ( ! in_array( $task, self::TASKS, true ) || ! is_array( $params ) || strlen( (string) wp_json_encode( $params ) ) > 262144 ) { return Response::fail( new \WP_Error( 'f3_google_job_input', 'Tarefa ou parâmetros inválidos; máximo 256 KiB.' ) ); }
		if ( 'inspect-urls' === $task ) {
			$urls = $params['urls'] ?? null;
			if ( ! is_array( $urls ) || ! $urls || count( $urls ) > 500 ) { return Response::fail( new \WP_Error( 'f3_google_job_urls', 'Informe entre 1 e 500 URLs.' ) ); }
			$site = (string) ( $params['site_url'] ?? Options::get( Connections::BINDINGS, array() )['gsc_site_url'] ?? '' );
			foreach ( $urls as $url ) { if ( ! is_string( $url ) || ! Workflow::belongs( $url, $site ) ) { return Response::fail( new \WP_Error( 'f3_google_job_urls', 'Todas as URLs devem pertencer à propriedade.' ) ); } }
			$params['site_url'] = $site; $params['urls'] = array_values( array_unique( $urls ) );
		}
		// Credentials are configured only through the panel; queues never retain secrets.
		if ( self::contains_secret( $params ) ) { return Response::fail( new \WP_Error( 'f3_google_job_secret', 'Não envie credenciais em parâmetros de jobs.' ) ); }
		$actor = get_current_user_id();
		$hash = hash( 'sha256', wp_json_encode( array( $task, $params, Connections::id(), $actor ) ) );
		$key = (string) ( $input['idempotency_key'] ?? '' );
		$id = '' !== $key ? 'k_' . hash( 'sha256', Connections::id() . '|' . $actor . '|' . $key ) : Records::id();
		$old = Records::get( 'job', $id );
		if ( null !== $old ) { return $old['input_hash'] === $hash ? Response::ok( array( 'job_id' => $id, 'created' => false, 'status' => $old['status'] ) ) : Response::fail( new \WP_Error( 'f3_google_job_key_conflict', 'Chave de idempotência já usada com parâmetros diferentes.' ) ); }
		if ( count( Records::list( 'job', 1001 ) ) >= 1000 ) { return Response::fail( new \WP_Error( 'f3_google_job_limit', 'Limite de 1.000 jobs retidos. Remova jobs encerrados antes de criar novos.' ) ); }
		$job = array( 'id' => $id, 'task' => $task, 'parameters' => $params, 'connection_id' => Connections::id(), 'user_id' => $actor, 'input_hash' => $hash, 'status' => 'pending', 'cursor' => 0, 'results' => array(), 'attempts' => 0, 'created_at' => time(), 'updated_at' => time(), 'run_after' => time(), 'priority' => max( 0, min( 9, (int) ( $input['priority'] ?? 5 ) ) ), 'write' => in_array( $task, array( 'export', 'sitemap' ), true ) );
		if ( ! Records::insert( 'job', $id, $job ) ) { return Response::fail( new \WP_Error( 'f3_google_job_persistence', 'Não foi possível criar o job; consulte a chave antes de repetir.' ) ); }
		self::schedule_tick();
		return Response::ok( array( 'job_id' => $id, 'created' => true, 'status' => 'pending', 'executor' => 'wp-cron', 'cron_requires_trigger' => true ) );
	}
	public static function run( string $id ): array {
		$lock = Lock::acquire( 'job:' . $id, 3600 );
		if ( null === $lock ) { return Response::fail( new \WP_Error( 'f3_google_job_busy', 'Job em execução.' ) ); }
		try {
			$job = Records::get( 'job', $id );
			if ( null === $job ) { return Response::fail( new \WP_Error( 'f3_google_job_missing', 'Job inexistente.' ) ); }
			if ( in_array( $job['status'], array( 'completed', 'failed', 'cancelled', 'unknown' ), true ) ) { return Response::ok( array( 'job' => self::view( $job ), 'executed' => false ) ); }
			if ( 'running' === $job['status'] && $job['write'] ) { $job['status'] = 'unknown'; $job['message'] = 'Escrita interrompida: confira o destino antes de criar outra operação.'; $saved = Records::put( 'job', $id, $job ); if ( ! $saved['success'] ) { return $saved; } return Response::ok( array( 'job' => self::view( $job ), 'executed' => false ) ); }
			if ( ! user_can( (int) $job['user_id'], Options::capability() ) || ! Options::is_enabled() ) { $job['status'] = 'failed'; $job['error_code'] = 'f3_google_job_permission'; $saved = Records::put( 'job', $id, $job ); if ( ! $saved['success'] ) { return $saved; } return Response::fail( new \WP_Error( 'f3_google_job_permission', 'A autorização do criador ou o canal não estão ativos.' ) ); }
			if ( $job['run_after'] > time() ) { return Response::ok( array( 'job' => self::view( $job ), 'executed' => false ) ); }
			$job['status'] = 'running'; $job['updated_at'] = time(); ++$job['attempts'];
			$saved = Records::put( 'job', $id, $job ); if ( ! $saved['success'] ) { return $saved; }
			$prior_user = get_current_user_id();
			try {
				wp_set_current_user( (int) $job['user_id'] );
				$result = Connections::run( $job['connection_id'], static function() use ( $job ) {
					$gate = Gate::check( 'any' ); if ( null !== $gate ) { return $gate; }
					$p = $job['parameters'];
					switch ( $job['task'] ) {
						case 'inspect-urls': $gate = Gate::check( 'gsc' ); return $gate ?? Workflow::inspect( array( 'site_url' => $p['site_url'], 'inspection_url' => $p['urls'][ $job['cursor'] ], 'refresh' => $p['refresh'] ?? false, 'language_code' => $p['language_code'] ?? 'pt-BR' ) );
						case 'query': return Query::run( $p );
						case 'export': return Export::run( $p );
						case 'sitemap': $gate = Gate::check( 'gsc' ); return $gate ?? Workflow::sitemap( $p );
						case 'report': return Reports::run( $p );
						case 'preflight': return Preflight::run( $p );
					}
					return Response::fail( new \WP_Error( 'f3_google_job_task', 'Tarefa desconhecida.' ) );
				} );
			} catch ( \Throwable $error ) {
				$result = Response::fail( new \WP_Error( 'f3_google_job_exception', 'A execução foi interrompida.', array( 'outcome' => $job['write'] ? 'unknown' : 'failed' ) ) );
			} finally { wp_set_current_user( $prior_user ); }
			$ok = ! empty( $result['success'] );
			$retryable = ! empty( $result['details']['retryable'] );
			if ( ! $ok && ! $job['write'] && $retryable && $job['attempts'] < 4 ) {
				$job['status'] = 'pending'; $job['run_after'] = time() + max( 60, (int) ( $result['details']['retry_after'] ?? 60 ) ); $job['last_error'] = $result;
			} elseif ( 'inspect-urls' === $job['task'] ) {
				$job['results'][] = array( 'url' => $job['parameters']['urls'][ $job['cursor'] ], 'result' => $result ); ++$job['cursor']; $job['attempts'] = 0;
				$job['status'] = $job['cursor'] < count( $job['parameters']['urls'] ) ? 'pending' : 'completed';
				$passed = count( array_filter( $job['results'], static fn( $entry ) => ! empty( $entry['result']['success'] ) ) );
				$job['summary'] = array( 'total' => count( $job['parameters']['urls'] ), 'processed' => $job['cursor'], 'passed' => $passed, 'failed' => $job['cursor'] - $passed, 'all_checks_passed' => 'completed' === $job['status'] && $passed === $job['cursor'] ); $job['run_after'] = time() + 1;
			} else {
				$job['result'] = $result;
				$unknown = 'unknown' === ( $result['details']['outcome'] ?? '' ) || ! empty( $result['uncertain'] ) || ! empty( $result['outcome_uncertain'] );
				$job['status'] = $ok ? 'completed' : ( $job['write'] && $unknown ? 'unknown' : 'failed' );
			}
			$job['updated_at'] = time();
			$stored = Records::put( 'job', $id, $job );
			return $stored['success'] ? Response::ok( array( 'job' => self::view( $job ), 'executed' => true ) ) : $stored + array( 'job_id' => $id, 'operation_result' => $result );
		} finally { Lock::release( $lock ); }
	}
	public static function tick(): void {
		$lock = Lock::acquire( 'jobs-tick', 3600 ); if ( null === $lock ) { return; }
		try {
			self::dispatch_schedules(); $started = microtime( true ); $count = 0;
			$pending = Records::list( 'job', 1000, false );
			uasort( $pending, static fn( $a, $b ) => ( ( $b['priority'] ?? 5 ) <=> ( $a['priority'] ?? 5 ) ) ?: ( $a['created_at'] <=> $b['created_at'] ) );
			foreach ( $pending as $id => $job ) {
				if ( in_array( $job['status'], array( 'pending', 'running' ), true ) && $job['run_after'] <= time() ) { self::run( $id ); if ( ++$count >= 5 || microtime( true ) - $started >= 20 ) { break; } }
			}
		} finally { Lock::release( $lock ); }
	}
	public static function schedule( array $input ): array {
		$task = $input['task'] ?? 'report';
		if ( ! in_array( $task, array( 'report', 'query', 'preflight' ), true ) ) { return Response::fail( new \WP_Error( 'f3_google_schedule_task', 'Agendamentos recorrentes aceitam report, query ou preflight.' ) ); }
		$id = (string) ( $input['schedule_id'] ?? Records::id() );
		if ( ! preg_match( '/^[A-Za-z0-9_-]{1,100}$/D', $id ) ) { return Response::fail( new \WP_Error( 'f3_google_schedule_id', 'schedule_id inválido.' ) ); }
		$params = $input['parameters'] ?? array();
		if ( ! is_array( $params ) || self::contains_secret( $params ) || strlen( wp_json_encode( $params ) ) > 262144 ) { return Response::fail( new \WP_Error( 'f3_google_schedule_input', 'Parâmetros inválidos.' ) ); }
		$lock = Lock::acquire( 'schedules' );
		if ( null === $lock ) { return Response::fail( new \WP_Error( 'f3_google_schedule_busy', 'Agenda em alteração.' ) ); }
		try {
		$old = Records::get( 'schedule', $id );
		if ( null === $old && count( Records::list( 'schedule', 101 ) ) >= 100 ) { return Response::fail( new \WP_Error( 'f3_google_schedule_limit', 'Limite de 100 agendas.' ) ); }
		$interval = max( 3600, min( 2592000, (int) ( $input['interval_seconds'] ?? 86400 ) ) );
		$record = array( 'id' => $id, 'task' => $task, 'parameters' => $params, 'interval_seconds' => $interval, 'next_run' => $old['next_run'] ?? time(), 'enabled' => $input['enabled'] ?? true, 'user_id' => get_current_user_id(), 'connection_id' => Connections::id() );
		$saved = Records::put( 'schedule', $id, $record ); if ( ! $saved['success'] ) { return $saved; }
		self::schedule_tick(); return Response::ok( array( 'schedule' => $record ) );
		} finally { Lock::release( $lock ); }
	}
	private static function dispatch_schedules(): void {
		$lock = Lock::acquire( 'schedules' ); if ( null === $lock ) { return; }
		try {
		foreach ( Records::list( 'schedule', 100 ) as $id => $schedule ) {
			if ( empty( $schedule['enabled'] ) || $schedule['next_run'] > time() || ! user_can( $schedule['user_id'], Options::capability() ) || ! Options::is_enabled() ) { continue; }
			$user = get_current_user_id();
			try { wp_set_current_user( $schedule['user_id'] ); $created = Connections::run( $schedule['connection_id'], static fn() => self::create( array( 'task' => $schedule['task'], 'parameters' => $schedule['parameters'], 'idempotency_key' => 'schedule:' . $id . ':' . $schedule['next_run'] ) ) ); }
			finally { wp_set_current_user( $user ); }
			if ( ! empty( $created['success'] ) ) { $schedule['last_job_id'] = $created['job_id']; $schedule['next_run'] = time() + $schedule['interval_seconds']; Records::put( 'schedule', $id, $schedule ); }
		}
		} finally { Lock::release( $lock ); }
	}

	private static function contains_secret( array $params ): bool {
		foreach ( $params as $key => $value ) {
			if ( preg_match( '/secret|token|private.?key|password|authorization/i', (string) $key ) || ( is_array( $value ) && self::contains_secret( $value ) ) ) { return true; }
		}
		return false;
	}
	/** Keep MCP output bounded; persisted results remain available page by page. */
	public static function view( array $job, int $offset = 0, int $limit = 20, bool $include_input = false ): array {
		$offset = max( 0, $offset ); $limit = max( 1, min( 100, $limit ) );
		if ( ! $include_input ) { unset( $job['parameters'], $job['input_hash'] ); }
		$field = 'inspect-urls' === $job['task'] ? 'results' : 'rows';
		$rows = 'results' === $field ? $job['results'] : ( $job['result']['rows'] ?? array() );
		$total = count( $rows ); $slice = array_slice( $rows, $offset, $limit );
		if ( 'results' === $field ) { $job['results'] = $slice; } elseif ( isset( $job['result']['rows'] ) ) { $job['result']['rows'] = $slice; }
		if ( isset( $job['result']['page_changes'] ) ) { $job['result']['page_changes'] = array_slice( $job['result']['page_changes'], $offset, $limit ); }
		$job['page'] = array( 'offset' => $offset, 'limit' => $limit, 'total' => $total, 'next_offset' => $offset + count( $slice ) < $total ? $offset + count( $slice ) : null );
		return $job;
	}

	public static function register(): void {
		$task_schema = array( 'task' => array( 'type' => 'string', 'enum' => self::TASKS ), 'parameters' => array( 'type' => 'object' ), 'idempotency_key' => array( 'type' => 'string' ), 'priority' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 9 ) );
		Ability::register( 'google/create-job', 'any', array( 'label' => 'Google: criar job', 'description' => 'Enfileira tarefa persistente. Use idempotency_key para repetir o pedido sem duplicar. Escritas interrompidas não são repetidas.', 'mode' => 'write', 'input_schema' => array( 'properties' => $task_schema, 'required' => array( 'task', 'parameters' ) ), 'callback' => array( self::class, 'create' ) ) );
		Ability::register( 'gsc/inspect-urls', 'gsc', array( 'label' => 'Search Console: inspecionar URLs em lote', 'description' => 'Enfileira até 500 URLs da mesma propriedade; usa cache e orçamento local de cota. Retorna job_id.', 'mode' => 'write', 'input_schema' => array( 'properties' => array( 'site_url' => array( 'type' => 'string' ), 'urls' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'minItems' => 1, 'maxItems' => 500 ), 'refresh' => array( 'type' => 'boolean' ), 'language_code' => array( 'type' => 'string' ), 'idempotency_key' => array( 'type' => 'string' ), 'priority' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 9 ) ), 'required' => array( 'urls' ) ), 'callback' => static fn( array $input ) => self::create( array( 'task' => 'inspect-urls', 'parameters' => array_diff_key( $input, array_flip( array( 'connection_id', 'idempotency_key', 'priority' ) ) ), 'priority' => $input['priority'] ?? 5, 'idempotency_key' => $input['idempotency_key'] ?? '' ) ) ) );
		foreach ( array( 'get-job', 'run-job', 'cancel-job', 'delete-job' ) as $route ) {
			Ability::register( 'google/' . $route, 'any', array( 'label' => 'Google: ' . $route, 'description' => 'Consulta, executa uma etapa, cancela ou remove job encerrado. get-job inclui resultados persistidos.', 'mode' => 'get-job' === $route ? 'read' : 'write', 'input_schema' => array( 'properties' => array( 'job_id' => array( 'type' => 'string' ), 'offset' => array( 'type' => 'integer', 'minimum' => 0 ), 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100 ), 'include_input' => array( 'type' => 'boolean' ) ), 'required' => array( 'job_id' ) ), 'callback' => static function( array $input ) use ( $route ): array {
				$id = (string) ( $input['job_id'] ?? '' ); if ( ! preg_match( '/^[A-Za-z0-9_-]{1,100}$/D', $id ) ) { return Response::fail( 'job_id inválido.' ); }
				if ( 'run-job' === $route ) { return self::run( $id ); }
				$job = Records::get( 'job', $id ); if ( null === $job ) { return Response::fail( 'Job inexistente.' ); }
				if ( 'get-job' === $route ) { return Response::ok( array( 'job' => self::view( $job, $input['offset'] ?? 0, $input['limit'] ?? 20, $input['include_input'] ?? false ) ) ); }
				$lock = Lock::acquire( 'job:' . $id ); if ( null === $lock ) { return Response::fail( 'Job em execução.' ); }
				try {
					$job = Records::get( 'job', $id ); if ( null === $job ) { return Response::fail( 'Job inexistente.' ); }
					if ( 'delete-job' === $route ) { return in_array( $job['status'], array( 'completed', 'failed', 'cancelled', 'unknown' ), true ) ? Records::remove( 'job', $id ) : Response::fail( 'Só é possível remover um job encerrado.' ); }
					if ( 'running' === $job['status'] ) { return Response::fail( 'Uma execução interrompida precisa ter seu resultado reconciliado.' ); }
					$job['status'] = 'cancelled'; return Records::put( 'job', $id, $job );
				} finally { Lock::release( $lock ); }
			} ) );
		}
		Ability::register( 'google/list-jobs', 'any', array( 'label' => 'Google: listar jobs', 'description' => 'Lista resumos dos jobs e agendamentos, sem carregar resultados extensos.', 'callback' => static function(): array { $out = array(); foreach ( Records::list( 'job', 1000 ) as $id => $job ) { $out[] = array_intersect_key( $job, array_flip( array( 'id', 'task', 'status', 'cursor', 'connection_id', 'updated_at', 'run_after' ) ) ); } return Response::ok( array( 'jobs' => $out, 'schedules' => array_values( Records::list( 'schedule', 100 ) ) ) ); } ) );
		Ability::register( 'google/schedule-report', 'any', array( 'label' => 'Google: agendar relatório', 'description' => 'Cria ou atualiza agenda de leituras. enabled=false pausa. Resultados ficam em jobs, sem enviar notificações externas.', 'mode' => 'write', 'input_schema' => array( 'properties' => array( 'schedule_id' => array( 'type' => 'string' ), 'task' => array( 'type' => 'string', 'enum' => array( 'report', 'query', 'preflight' ) ), 'parameters' => array( 'type' => 'object' ), 'interval_seconds' => array( 'type' => 'integer', 'minimum' => 3600, 'maximum' => 2592000 ), 'enabled' => array( 'type' => 'boolean' ) ), 'required' => array( 'parameters' ) ), 'callback' => array( self::class, 'schedule' ) ) );
	}
}
