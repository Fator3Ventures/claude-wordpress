<?php
/**
 * Formato único de resposta das habilidades.
 *
 * O WP MCP Ultimate embrulha o retorno em `{success, data, error}` — o que sai
 * daqui é o `data`. Manter `success` e `message` em todas as respostas dá ao
 * agente um lugar fixo para olhar quando algo dá errado, em vez de ter que
 * adivinhar o formato de cada rota.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Response {

	/**
	 * @param array  $data    Carga útil; não pode sobrescrever `success`.
	 * @param string $message Frase curta para o agente.
	 */
	public static function ok( array $data = array(), string $message = '' ): array {
		// Deixa a mensagem vir de dentro de $data quando o chamador não passou
		// uma explícita — assim quem monta a carga não precisa repeti-la.
		if ( '' === $message && isset( $data['message'] ) && is_string( $data['message'] ) ) {
			$message = $data['message'];
		}

		unset( $data['success'], $data['message'] );

		return array(
			'success' => true,
			'message' => $message,
		) + $data;
	}

	/**
	 * @param string|\WP_Error $error Erro a reportar.
	 * @param array            $extra Campos adicionais (ex.: rows vazio).
	 */
	public static function fail( $error, array $extra = array() ): array {
		$code    = 'f3_google_error';
		$details = null;

		if ( is_wp_error( $error ) ) {
			$code    = (string) $error->get_error_code();
			$message = (string) $error->get_error_message();
			$data    = $error->get_error_data();

			if ( is_array( $data ) ) {
				$details = array();

				// Só o que o GoogleClient garante ser seguro: código HTTP,
				// razão da Google, URL sem query e a lista de erros dela.
				if ( isset( $data['status'] ) ) {
					$details['status'] = (int) $data['status'];
				}
				if ( isset( $data['reason'] ) && is_scalar( $data['reason'] ) ) {
					$details['reason'] = (string) $data['reason'];
				}
				if ( isset( $data['url'] ) && is_scalar( $data['url'] ) ) {
					$details['url'] = (string) $data['url'];
				}
				if ( isset( $data['details'] ) && is_array( $data['details'] ) ) {
					$details['errors'] = $data['details'];
				}

				foreach ( array( 'action', 'candidates', 'missing_scopes', 'api', 'retryable', 'retry_after', 'outcome', 'request_id' ) as $key ) {
					if ( isset( $data[ $key ] ) ) {
						$details[ $key ] = Audit::redact( $data[ $key ] );
					}
				}

				if ( empty( $details ) ) {
					$details = null;
				}
			}
		} else {
			$message = (string) $error;
		}

		unset( $extra['success'], $extra['message'], $extra['error_code'], $extra['details'] );

		return array(
			'success'    => false,
			'message'    => $message,
			'error_code' => $code,
			'details'    => $details,
		) + $extra;
	}
}
