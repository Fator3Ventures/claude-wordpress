<?php
/** Connection contexts preserve the legacy default without copying credentials. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Connections {
	public const REGISTRY = 'f3_mcp_google_connections';
	public const SERVICES = 'f3_mcp_google_services';
	public const BINDINGS = 'f3_mcp_google_bindings';
	private static string $active = 'default';
	private static array $preview = array();
	public static function preview_values(): array { return self::$preview; }
	public static function preview( array $values, callable $callback ) {
		$before = self::$preview; self::$preview = $values;
		try { return $callback(); } finally { self::$preview = $before; }
	}
	public static function id(): string { return self::$active; }
	public static function registry(): array {
		$items = get_option( self::REGISTRY, array() );
		return array( 'default' => array( 'label' => 'Padrão' ) ) + ( is_array( $items ) ? $items : array() );
	}
	public static function select( string $id ) {
		if ( ! preg_match( '/^[a-z][a-z0-9_-]{0,39}$/D', $id ) || ! isset( self::registry()[ $id ] ) ) { return new \WP_Error( 'f3_google_connection', 'Conexão inexistente. Consulte google/list-connections.' ); }
		self::$active = $id;
		foreach ( Options::secret_names() as $name ) { add_filter( 'pre_option_' . self::option_name( $name ), array( Options::class, 'hide_secret' ), 10, 3 ); }
		return true;
	}
	public static function run( string $id, callable $callback ) {
		$prior = self::$active;
		$selected = self::select( $id );
		if ( is_wp_error( $selected ) ) { return Response::fail( $selected ); }
		try { return $callback(); } finally { self::$active = $prior; }
	}
	public static function scoped_names(): array {
		return array( Options::AUTH_MODE, Options::SA_JSON, Options::SA_SUBJECT, Options::OAUTH_CLIENT_ID, Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES, Options::ADS_DEVELOPER_TOKEN, Options::ADS_LOGIN_CUSTOMER_ID, Options::ADS_API_VERSION, Options::GA_DEFAULT_PROPERTY, Options::TOKEN_INDEX, Options::GA_ENABLED, Options::ADS_ENABLED, self::SERVICES, self::BINDINGS );
	}
	public static function option_name( string $name ): string {
		return 'default' !== self::$active && in_array( $name, self::scoped_names(), true ) ? 'f3_mcp_google_conn_' . self::$active . '_' . substr( $name, strlen( 'f3_mcp_google_' ) ) : $name;
	}
	public static function protected_names(): array {
		$names = array( self::REGISTRY, self::SERVICES, self::BINDINGS );
		foreach ( self::registry() as $id => $meta ) {
			if ( 'default' === $id ) { continue; }
			foreach ( self::scoped_names() as $name ) { $names[] = 'f3_mcp_google_conn_' . $id . '_' . substr( $name, strlen( 'f3_mcp_google_' ) ); }
		}
		return $names;
	}
	public static function create( string $id, string $label ): array {
		if ( ! current_user_can( Options::capability() ) ) { return Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) ); }
		if ( ! preg_match( '/^[a-z][a-z0-9_-]{0,39}$/D', $id ) || 'default' === $id || '' === trim( $label ) ) { return Response::fail( new \WP_Error( 'f3_google_connection_input', 'Informe connection_id válido e label.' ) ); }
		$lock = Lock::acquire( 'connections-registry' );
		if ( null === $lock ) { return Response::fail( new \WP_Error( 'f3_google_connection_busy', 'Outra conexão está sendo criada.' ) ); }
		try {
		$all = self::registry();
		if ( isset( $all[ $id ] ) ) { return Response::ok( array( 'connection_id' => $id, 'created' => false ) ); }
		if ( count( $all ) >= 20 ) { return Response::fail( new \WP_Error( 'f3_google_connection_limit', 'Limite de 20 conexões por site.' ) ); }
		$all[ $id ] = array( 'label' => substr( sanitize_text_field( $label ), 0, 100 ) );
		unset( $all['default'] );
		$result = Options::set( self::REGISTRY, $all );
		return $result['success'] ? Response::ok( array( 'connection_id' => $id, 'created' => true ) ) : $result;
		} finally { Lock::release( $lock ); }
	}
	/** A missing selection preserves existing installations' service availability. */
	public static function enabled( string $service ): bool {
		$services = Options::get( self::SERVICES, null );
		return ! is_array( $services ) || isset( $services[ $service ] );
	}
	public static function scopes( string $service ): ?array {
		$selected = Options::get( self::SERVICES, null );
		if ( ! is_array( $selected ) ) { return null; }
		$level = $selected[ $service ] ?? '';
		$base = 'https://www.googleapis.com/auth/';
		$map = array( 'ga' => array( 'read' => array( 'analytics.readonly' ), 'write' => array( 'analytics.readonly', 'analytics.edit' ), 'admin' => array( 'analytics.readonly', 'analytics.edit', 'analytics.manage.users' ) ), 'gsc' => array( 'read' => array( 'webmasters.readonly' ), 'write' => array( 'webmasters' ) ), 'ads' => array( 'read' => array( 'adwords' ), 'write' => array( 'adwords' ) ), 'siteverification' => array( 'write' => array( 'siteverification' ) ), 'sheets' => array( 'read' => array( 'spreadsheets.readonly', 'drive.file' ), 'write' => array( 'spreadsheets', 'drive.file' ) ), 'drive' => array( 'write' => array( 'drive.file' ) ) );
		return array_map( static fn( $scope ) => $base . $scope, $map[ $service ][ $level ] ?? array() );
	}
}
