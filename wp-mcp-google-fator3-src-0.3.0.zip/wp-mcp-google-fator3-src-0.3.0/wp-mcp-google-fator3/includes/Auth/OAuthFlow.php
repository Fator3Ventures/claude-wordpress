<?php
/**
 * Fluxo de consentimento OAuth do administrador.
 *
 * Três passos: a tela manda o navegador para a Google com um `state` de uso
 * único; a Google devolve um `code` na rota REST de callback; o plugin troca o
 * `code` por um refresh token e o guarda cifrado.
 *
 * O `state` é o que impede um terceiro de forjar o retorno e plantar a conta
 * Google dele no site: é um valor aleatório gravado em transient por 10
 * minutos, apagado no primeiro uso. A rota de callback é necessariamente
 * pública (quem chega nela é o navegador redirecionado pela Google, sem nonce
 * do WordPress), então o `state` é a única prova de que aquele retorno
 * corresponde a um pedido feito daqui.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Connections;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class OAuthFlow {

	public const NAMESPACE_REST = 'wp-mcp-google-fator3/v1';
	public const ROUTE_CALLBACK = '/oauth/callback';

	/** Prefixo do transient que guarda o state. */
	private const STATE_PREFIX = 'f3_mcp_google_oauth_state_';

	/** Validade do state, em segundos. */
	private const STATE_TTL = 600;

	private const AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';

	public static function init(): void {
		add_action( 'admin_post_f3_mcp_google_oauth_start', array( self::class, 'handle_start' ) );
		add_action( 'admin_post_f3_mcp_google_oauth_disconnect', array( self::class, 'handle_disconnect' ) );
		add_action( 'rest_api_init', array( self::class, 'register_route' ) );
	}

	public static function register_route(): void {
		if ( ! function_exists( 'register_rest_route' ) ) {
			return;
		}

		register_rest_route(
			self::NAMESPACE_REST,
			self::ROUTE_CALLBACK,
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'handle_callback' ),
				// Pública por construção: quem chega aqui é o navegador vindo da
				// Google, sem cookie de REST nem nonce. A autorização real é o
				// `state` de uso único conferido dentro do callback.
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * URI que precisa estar cadastrada no cliente OAuth do Google Cloud.
	 */
	public static function redirect_uri(): string {
		return rest_url( self::NAMESPACE_REST . self::ROUTE_CALLBACK );
	}

	/**
	 * @param string $state  Valor aleatório de uso único.
	 * @param array  $scopes Escopos a pedir.
	 */
	public static function authorize_url( string $state, array $scopes ): string {
		// `openid email` entra sempre para que a tela consiga mostrar QUAL conta
		// foi conectada; o e-mail sai do id_token, sem uma chamada a mais.
		$scopes = array_values( array_unique( array_merge( array( 'openid', 'email' ), $scopes ) ) );

		return add_query_arg(
			array(
				'client_id'              => rawurlencode( (string) Options::get( Options::OAUTH_CLIENT_ID, '' ) ),
				'redirect_uri'           => rawurlencode( self::redirect_uri() ),
				'response_type'          => 'code',
				'scope'                  => rawurlencode( implode( ' ', $scopes ) ),
				// offline + consent é o que faz a Google devolver refresh token;
				// sem `prompt=consent` uma segunda autorização volta sem ele.
				'access_type'            => 'offline',
				'prompt'                 => 'consent',
				'include_granted_scopes' => 'true',
				'state'                  => rawurlencode( $state ),
			),
			self::AUTH_ENDPOINT
		);
	}

	public static function handle_start(): void {
		if ( ! current_user_can( Options::capability() ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'wp-mcp-google-fator3' ) );
		}

		check_admin_referer( 'f3_mcp_google_oauth_start' );
		$selected = Connections::select( self::posted_connection() );
		if ( is_wp_error( $selected ) ) { self::back( 'oauth_state' ); return; }

		$client_id = trim( (string) Options::get( Options::OAUTH_CLIENT_ID, '' ) );
		if ( '' === $client_id || '' === Options::get_secret( Options::OAUTH_CLIENT_SECRET ) ) {
			self::back( 'oauth_missing_client' );
			return;
		}

		$state = bin2hex( random_bytes( 32 ) );
		set_transient( self::STATE_PREFIX . $state, array( 'user' => get_current_user_id(), 'connection_id' => Connections::id(), 'client_id' => $client_id ), self::STATE_TTL );

		$scopes = Credentials::scopes_for( 'any' );

		// wp_redirect e não wp_safe_redirect: o destino é accounts.google.com,
		// que a lista de hosts permitidos do wp_safe_redirect recusaria.
		// phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Origem OAuth fixa accounts.google.com e parâmetros codificados.
		wp_redirect( self::authorize_url( $state, $scopes ) );
		exit;
	}

	/**
	 * Retorno da Google.
	 *
	 * @param \WP_REST_Request $request Requisição REST.
	 * @return void
	 */
	public static function handle_callback( \WP_REST_Request $request ) {
		// Esta rota é pública e sem nonce: tudo o que chega é texto de terceiro.
		// `param()` só devolve string — um `?state[]=x` viraria "Array to string
		// conversion", e um aviso do PHP impresso aqui sairia ANTES do
		// `wp_safe_redirect()`, deixando o navegador na página de erro em vez de
		// voltar para a tela.
		$error = self::param( $request, 'error' );
		if ( '' !== $error ) {
			self::back( 'oauth_denied' );
			return;
		}

		$state = self::param( $request, 'state' );
		$code  = self::param( $request, 'code' );

		if ( '' === $state || '' === $code || ! preg_match( '/^[a-f0-9]{16,128}\z/', $state ) ) {
			self::back( 'oauth_state' );
			return;
		}

		$stored = get_transient( self::STATE_PREFIX . $state );
		if ( false === $stored || null === $stored ) {
			self::back( 'oauth_state' );
			return;
		}

		// Uso único: consumido antes da troca, para que um retorno repetido
		// (recarregar a página, por exemplo) não valha uma segunda vez.
		delete_transient( self::STATE_PREFIX . $state );

		// O `state` guarda quem iniciou o fluxo. O usuário não pode ser
		// conferido contra a sessão atual — uma requisição REST sem nonce chega
		// deslogada por construção —, mas dá para exigir que quem começou ainda
		// tenha a capacidade: um administrador rebaixado (ou removido) entre o
		// clique e o retorno não conecta mais uma conta Google ao site.
		$starter = (int) ( is_array( $stored ) ? $stored['user'] : $stored );
		if ( is_wp_error( Connections::select( is_array( $stored ) ? (string) $stored['connection_id'] : 'default' ) ) ) { self::back( 'oauth_state' ); return; }
		if ( is_array( $stored ) && $stored['client_id'] !== Options::get( Options::OAUTH_CLIENT_ID, '' ) ) { self::back( 'oauth_state' ); return; }
		if ( $starter < 1 || ! user_can( $starter, Options::capability() ) ) {
			self::back( 'oauth_state' );
			return;
		}

		$client_id     = trim( (string) Options::get( Options::OAUTH_CLIENT_ID, '' ) );
		$client_secret = Options::get_secret( Options::OAUTH_CLIENT_SECRET );

		if ( '' === $client_id || '' === $client_secret ) {
			self::back( 'oauth_missing_client' );
			return;
		}

		$response = GoogleClient::post(
			GoogleClient::HOST_TOKEN . '/token',
			array(
				'grant_type'    => 'authorization_code',
				'code'          => $code,
				'client_id'     => $client_id,
				'client_secret' => $client_secret,
				'redirect_uri'  => self::redirect_uri(),
			),
			array(
				'auth' => false,
				'form' => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			self::back( 'oauth_exchange' );
			return;
		}

		$refresh = (string) ( $response['refresh_token'] ?? '' );
		if ( '' === $refresh ) {
			// Acontece quando a conta já havia autorizado o app e a Google
			// devolve só o access token. `prompt=consent` evita, mas se ocorrer
			// é melhor dizer do que gravar metade da credencial.
			self::back( 'oauth_no_refresh' );
			return;
		}

		$granted = trim( (string) ( $response['scope'] ?? '' ) );
		$email = self::email_from_id_token( (string) ( $response['id_token'] ?? '' ) );
		Admin::require_saved( Options::batch_verified(
			array( Options::AUTH_MODE => 'oauth', Options::OAUTH_SCOPES => '' !== $granted ? explode( ' ', $granted ) : array(), Options::OAUTH_EMAIL => $email ),
			array( Options::OAUTH_REFRESH_TOKEN => $refresh )
		) );

		Credentials::invalidate_cache();
		Audit::log( 'oauth:connect', '' !== $email ? $email : '-' );

		self::back( 'oauth_ok' );
	}

	public static function handle_disconnect(): void {
		if ( ! current_user_can( Options::capability() ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'wp-mcp-google-fator3' ) );
		}

		check_admin_referer( 'f3_mcp_google_oauth_disconnect' );

		$selected = Connections::select( self::posted_connection() );
		if ( is_wp_error( $selected ) ) { self::back( 'oauth_state' ); return; }
		$revoke = isset( $_POST['revoke'] ) && '1' === $_POST['revoke'];
		$result = self::disconnect( $revoke );
		if ( empty( $result['success'] ) ) {
			if ( ! empty( $result['local_disconnected'] ) ) { self::back( 'oauth_revoke_failed' ); return; }
			Admin::require_saved( $result );
		}
		self::back( $revoke ? 'oauth_revoked' : 'oauth_disconnected' );
	}

	public static function disconnect( bool $revoke = false ): array {
		if ( ! current_user_can( Options::capability() ) ) { return \Fator3\McpGoogle\Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) ); }
		$refresh = Options::get_secret( Options::OAUTH_REFRESH_TOKEN );
		$remote = null;
		if ( $revoke && '' !== $refresh ) {
			$remote = GoogleClient::post( GoogleClient::HOST_TOKEN . '/revoke', array( 'token' => $refresh ), array( 'auth' => false, 'form' => true, 'retries' => 0, 'mode' => 'write' ) );
		}
		$local = Options::batch_verified( array(), array(), array( Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES ) );
		Credentials::invalidate_cache();
		Audit::log( $revoke ? 'oauth:revoke' : 'oauth:disconnect', Connections::id(), array( 'status' => $local['success'] && ! is_wp_error( $remote ) ? 'ok' : 'error' ) );
		if ( ! $local['success'] ) { return $local + array( 'remote_revoked' => $revoke && null !== $remote && ! is_wp_error( $remote ) ); }
		$state = array( 'local_disconnected' => true, 'remote_revoked' => $revoke ? ( null !== $remote && ! is_wp_error( $remote ) ) : null, 'revocation_requested' => $revoke );
		return is_wp_error( $remote ) ? \Fator3\McpGoogle\Response::fail( $remote, $state ) : \Fator3\McpGoogle\Response::ok( $state, 'Desconexão local concluída.' );
	}

	private static function posted_connection(): string {
		return isset( $_POST['connection_id'] ) && is_string( $_POST['connection_id'] ) ? sanitize_key( $_POST['connection_id'] ) : 'default';
	}

	/**
	 * Um parâmetro da requisição como string, ou '' quando não for escalar.
	 *
	 * @param \WP_REST_Request $request Requisição.
	 * @param string           $key     Nome do parâmetro.
	 */
	private static function param( \WP_REST_Request $request, string $key ): string {
		$value = $request->get_param( $key );

		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	/**
	 * O `id_token` vem pelo canal TLS direto do endpoint de token da Google, em
	 * resposta a uma troca autenticada com o client secret — por isso o payload
	 * pode ser lido sem verificar a assinatura. Só o e-mail é aproveitado, e ele
	 * serve apenas para exibição.
	 */
	private static function email_from_id_token( string $id_token ): string {
		$parts = explode( '.', $id_token );
		if ( 3 !== count( $parts ) ) {
			return '';
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
		$json = base64_decode( strtr( $parts[1], '-_', '+/' ), false );
		if ( ! is_string( $json ) ) {
			return '';
		}

		$claims = json_decode( $json, true );
		if ( ! is_array( $claims ) || empty( $claims['email'] ) ) {
			return '';
		}

		$email = sanitize_email( (string) $claims['email'] );

		return is_email( $email ) ? $email : '';
	}

	/**
	 * Volta para a tela de administração com um código de estado.
	 *
	 * Código, não mensagem: o texto sai da tabela do Admin, para não haver
	 * conteúdo controlado por terceiro na query string.
	 */
	private static function back( string $status ): void {
		// `Admin::url()` é o único lugar que monta esta URL, e `wp_safe_redirect`
		// só aceita destinos do próprio host: não há como um parâmetro do
		// callback virar redirecionamento para fora.
		wp_safe_redirect( Admin::url( $status ) );
		exit;
	}
}
