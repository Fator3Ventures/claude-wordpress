<?php
/**
 * Credencial por service account: JWT assinado trocado por access token.
 *
 * É o modo recomendado. Não depende de ninguém estar logado, não expira em 7
 * dias como um app OAuth em modo "Testing", e a mesma conta serve para GA4 e
 * para Google Ads — no Analytics ela entra como Leitor da propriedade; no Ads,
 * como usuário da conta (Admin > Acesso e segurança > Usuários), sem precisar
 * de delegação de domínio.
 *
 * O fluxo é o "JWT bearer" do OAuth 2.0: monta-se um JWT com os escopos
 * pedidos, assina-se com a chave privada da conta e troca-se por um access
 * token no endpoint de token. Nenhuma biblioteca envolvida — são três
 * base64url e um `openssl_sign`.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ServiceAccount implements CredentialsInterface {

	/** Endpoint de token padrão quando o JSON não traz outro. */
	public const DEFAULT_TOKEN_URI = 'https://oauth2.googleapis.com/token';

	/** Validade do JWT, em segundos. O máximo aceito pela Google é 3600. */
	private const JWT_TTL = 3600;

	/** @var array Chave JSON já decodificada e validada. */
	private array $key;

	/** @var string E-mail a impersonar (delegação de domínio), opcional. */
	private string $subject;

	public function __construct( array $key_json, string $subject = '' ) {
		$this->key     = $key_json;
		$this->subject = $subject;
	}

	/**
	 * @return self|\WP_Error
	 */
	public static function from_options() {
		$json = Options::get_secret( Options::SA_JSON );

		if ( '' === $json ) {
			return new \WP_Error(
				'f3_google_not_configured',
				__( 'Nenhuma chave de service account configurada.', 'wp-mcp-google-fator3' )
			);
		}

		$key = self::validate_key( $json );
		if ( is_wp_error( $key ) ) {
			return $key;
		}

		$subject = trim( (string) Options::get( Options::SA_SUBJECT, '' ) );

		return new self( $key, $subject );
	}

	/**
	 * Valida o JSON da chave e devolve o array decodificado.
	 *
	 * Vale a pena validar cedo: colar o JSON errado (o de um OAuth client, por
	 * exemplo) é o erro mais comum na configuração, e sem esta checagem ele só
	 * apareceria como um 400 sem explicação na primeira chamada.
	 *
	 * @param string $json Conteúdo do arquivo de chave.
	 * @return array|\WP_Error
	 */
	public static function validate_key( string $json ) {
		$data = json_decode( trim( $json ), true );

		if ( ! is_array( $data ) ) {
			return new \WP_Error(
				'f3_google_sa_invalid',
				__( 'O conteúdo colado não é um JSON válido.', 'wp-mcp-google-fator3' )
			);
		}

		if ( 'service_account' !== ( $data['type'] ?? '' ) ) {
			return new \WP_Error(
				'f3_google_sa_invalid',
				__( 'Este JSON não é de uma service account (o campo "type" precisa ser "service_account"). Se você baixou um "OAuth client ID", use o modo OAuth de usuário.', 'wp-mcp-google-fator3' )
			);
		}

		foreach ( array( 'client_email', 'private_key', 'token_uri' ) as $field ) {
			if ( empty( $data[ $field ] ) || ! is_string( $data[ $field ] ) ) {
				return new \WP_Error(
					'f3_google_sa_invalid',
					sprintf(
						/* translators: %s: nome do campo ausente no JSON. */
						__( 'O JSON da chave não tem o campo obrigatório "%s".', 'wp-mcp-google-fator3' ),
						$field
					)
				);
			}
		}

		// O token_uri vem de dentro do JSON colado, ou seja, de entrada do
		// administrador: se apontasse para outro host, a chave privada assinaria
		// um JWT enviado para um servidor de terceiros.
		if ( 0 !== strpos( $data['token_uri'], GoogleClient::HOST_TOKEN . '/' ) ) {
			return new \WP_Error(
				'f3_google_sa_invalid',
				__( 'O campo "token_uri" do JSON não aponta para https://oauth2.googleapis.com/.', 'wp-mcp-google-fator3' )
			);
		}

		if ( function_exists( 'openssl_pkey_get_private' ) ) {
			$pkey = openssl_pkey_get_private( $data['private_key'] );
			if ( ! $pkey ) {
				return new \WP_Error(
					'f3_google_sa_invalid',
					__( 'A chave privada do JSON não pôde ser lida pelo OpenSSL. Cole o arquivo inteiro, sem editar as quebras de linha.', 'wp-mcp-google-fator3' )
				);
			}
		}

		return $data;
	}

	/**
	 * @param array $scopes Escopos pedidos.
	 * @return string|\WP_Error
	 */
	public function get_access_token( array $scopes ) {
		$scopes = array_values( array_unique( array_filter( array_map( 'strval', $scopes ) ) ) );
		sort( $scopes );

		if ( empty( $scopes ) ) {
			return new \WP_Error(
				'f3_google_scopes',
				__( 'Nenhum escopo informado para pedir o token.', 'wp-mcp-google-fator3' )
			);
		}

		$cache_key = Credentials::cache_key( $scopes, $this->identity(), $this->subject );
		$cached    = Credentials::cached( $cache_key );

		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$lock = \Fator3\McpGoogle\Lock::acquire( 'token:' . $cache_key, 180 );
		if ( null === $lock ) { return new \WP_Error( 'f3_google_token_busy', 'Renovação de token em andamento.', array( 'retryable' => true, 'retry_after' => 2 ) ); }
		try {
			$cached = Credentials::cached( $cache_key );
			if ( '' !== $cached ) { return $cached; }

		$now = time();
		$jwt = self::build_jwt( $this->key, $scopes, $now, $this->subject );

		if ( '' === $jwt ) {
			return new \WP_Error(
				'f3_google_sa_sign',
				__( 'Não foi possível assinar o JWT com a chave privada da service account.', 'wp-mcp-google-fator3' )
			);
		}

		$response = GoogleClient::post(
			(string) $this->key['token_uri'],
			array(
				'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
				'assertion'  => $jwt,
			),
			array(
				'auth' => false,
				'form' => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::explain( $response );
		}

		$token = (string) ( $response['access_token'] ?? '' );
		if ( '' === $token ) {
			return new \WP_Error(
				'f3_google_token',
				__( 'A Google não devolveu um access token.', 'wp-mcp-google-fator3' )
			);
		}

		$expires = (int) ( $response['expires_in'] ?? self::JWT_TTL );
		Credentials::remember( $cache_key, $token, max( 1, $expires - 60 ) );

		return $token;
		} finally { \Fator3\McpGoogle\Lock::release( $lock ); }
	}

	/**
	 * @return array{mode:string,identity:string,configured:bool}
	 */
	public function describe(): array {
		return array(
			'mode'       => 'service_account',
			'identity'   => $this->identity(),
			'configured' => '' !== $this->identity(),
		);
	}

	/**
	 * E-mail da service account — o que precisa ser adicionado no GA4 e no Ads.
	 */
	public function identity(): string {
		return (string) ( $this->key['client_email'] ?? '' );
	}

	/**
	 * Monta e assina o JWT.
	 *
	 * Público para poder ser verificado nos testes com `openssl_verify` sem
	 * precisar de rede nem de credencial real.
	 *
	 * @param array  $key     Chave JSON decodificada.
	 * @param array  $scopes  Escopos pedidos.
	 * @param int    $now     Instante de emissão (timestamp UTC).
	 * @param string $subject E-mail a impersonar, ou ''.
	 * @return string JWT completo, ou '' se a assinatura falhar.
	 */
	public static function build_jwt( array $key, array $scopes, int $now, string $subject = '' ): string {
		$header = array(
			'alg' => 'RS256',
			'typ' => 'JWT',
		);

		$claims = array(
			'iss'   => (string) ( $key['client_email'] ?? '' ),
			'scope' => implode( ' ', $scopes ),
			'aud'   => (string) ( $key['token_uri'] ?? self::DEFAULT_TOKEN_URI ),
			'iat'   => $now,
			'exp'   => $now + self::JWT_TTL,
		);

		// `sub` só entra com delegação de domínio; presente e vazio, a Google
		// recusa a troca com "invalid_grant".
		if ( '' !== $subject ) {
			$claims['sub'] = $subject;
		}

		$signing_input = self::base64url( (string) wp_json_encode( $header ) )
			. '.' . self::base64url( (string) wp_json_encode( $claims ) );

		if ( ! function_exists( 'openssl_sign' ) ) {
			return '';
		}

		$private = openssl_pkey_get_private( (string) ( $key['private_key'] ?? '' ) );
		if ( ! $private ) {
			return '';
		}

		$signature = '';
		if ( ! openssl_sign( $signing_input, $signature, $private, OPENSSL_ALGO_SHA256 ) ) {
			return '';
		}

		return $signing_input . '.' . self::base64url( $signature );
	}

	/**
	 * Traduz os erros mais comuns do endpoint de token para algo acionável.
	 *
	 * @param \WP_Error $error Erro devolvido pelo GoogleClient.
	 * @return \WP_Error
	 */
	private static function explain( \WP_Error $error ): \WP_Error {
		$data   = $error->get_error_data();
		$reason = is_array( $data ) ? (string) ( $data['reason'] ?? '' ) : '';

		if ( 'invalid_grant' === $reason ) {
			return new \WP_Error(
				'f3_google_sa_grant',
				__( 'A Google recusou a chave da service account (invalid_grant). Confira se o relógio do servidor está certo, se a chave não foi revogada e, quando houver e-mail a impersonar, se a delegação de domínio está configurada.', 'wp-mcp-google-fator3' ),
				$data
			);
		}

		if ( 'unauthorized_client' === $reason ) {
			return new \WP_Error(
				'f3_google_sa_client',
				__( 'A service account não está autorizada para estes escopos (unauthorized_client). Verifique a delegação de domínio no Google Workspace.', 'wp-mcp-google-fator3' ),
				$data
			);
		}

		return $error;
	}

	private static function base64url( string $raw ): string {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
		return rtrim( strtr( base64_encode( $raw ), '+/', '-_' ), '=' );
	}
}
