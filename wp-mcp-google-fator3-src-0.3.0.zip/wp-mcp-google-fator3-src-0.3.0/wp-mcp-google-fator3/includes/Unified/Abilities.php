<?php
/**
 * As cinco rotas `google/*`.
 *
 * Elas registram com o conector `'any'` porque a escolha entre Analytics e Ads
 * só acontece em tempo de execução, pelo parâmetro `connector`: uma rota que se
 * amarrasse a um conector no registro sumiria da lista quando o outro estivesse
 * ligado. O portão específico (`Gate::check( 'ga' )` ou `Gate::check( 'ads' )`)
 * é aplicado dentro da implementação, depois de saber qual conector foi pedido.
 *
 * As descrições seguem uma regra: a da habilidade é curta (é ela que aparece na
 * lista de ferramentas de todo cliente MCP, e vinte rotas com um parágrafo cada
 * consomem a janela de contexto antes da primeira pergunta); as listas longas —
 * presets de data, operadores, catálogo de campos — ficam nas descrições das
 * propriedades do `input_schema`, que o cliente só lê quando vai chamar a rota.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Unified;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Crypto;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Plugin;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\SelfTest;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Abilities {

	public static function register(): void {
		self::register_status();
		self::register_selftest();
		self::register_list_accounts();
		self::register_list_fields();
		self::register_query();
	}

	// =========================================================================
	// google/status
	// =========================================================================

	private static function register_status(): void {
		Ability::register(
			'google/status',
			'any',
			array(
				'label'        => __( 'Google: estado da configuração', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Diagnóstico da integração Google: canal aberto, conectores ligados, modo de autenticação e identidade da credencial, versão da Ads API, limites e rotas registradas. Nunca devolve segredo. Substitui whoami e list_connectors.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'live' => array(
							'type'        => 'boolean',
							'description' => __( 'Quando true, também pede um access token de verdade a cada conector ligado e informa se ele veio (token_ok). O token em si nunca é devolvido. Padrão: false.', 'wp-mcp-google-fator3' ),
						),
					),
				),
				'callback'     => static function ( array $input ): array {
					return self::status( $input );
				},
			)
		);
	}

	/**
	 * @param array $input 'live' => bool.
	 */
	public static function status( array $input ): array {
		$credentials = Credentials::current();

		$data = array(
			'enabled'                        => Options::is_enabled(),
			'ga_enabled'                     => Options::ga_enabled(),
			'ads_enabled'                    => Options::ads_enabled(),
			'auth'                           => is_wp_error( $credentials )
				? array(
					'mode'       => Options::auth_mode(),
					'configured' => false,
					'reason'     => $credentials->get_error_message(),
					'error_code' => $credentials->get_error_code(),
				)
				: $credentials->describe(),
			'crypto_backend'                 => Crypto::backend(),
			'ads_api_version'                => Options::ads_api_version(),
			'ads_developer_token_configured' => Options::has_secret( Options::ADS_DEVELOPER_TOKEN ),
			'ads_login_customer_id'          => self::mask_customer_id( Options::ads_login_customer_id() ),
			'api_status'                     => \Fator3\McpGoogle\Http\GoogleClient::api_status(),
			'scopes_requested'               => Credentials::scopes_for( 'any' ),
			'scopes_granted'                 => 'oauth' === Options::auth_mode() ? Options::get( Options::OAUTH_SCOPES, array() ) : null,
			'scopes_note'                    => 'OAuth: escopos registrados na última autorização, sujeitos a revogação. Service account: escopos solicitados por método; acesso efetivo depende dos papéis. APIs sem chamada observada aparecem com enabled=null.',
			'ga_default_property'            => (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' ),
			'max_rows'                       => Options::max_rows(),
			'abilities_registered'           => self::count_abilities(),
			'mcp_server_detected'            => Plugin::mcp_server_detected(),
			'wordpress_version'              => (string) get_bloginfo( 'version' ),
			'site_url' => home_url(),
			'cron' => array( 'executor' => 'wp-cron', 'requires_trigger' => true, 'disabled_builtin_trigger' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON, 'next_run' => function_exists( 'wp_next_scheduled' ) ? wp_next_scheduled( \Fator3\McpGoogle\Automation\Jobs::HOOK ) : null ),
			'connection_id' => \Fator3\McpGoogle\Connections::id(),
			'last_http' => get_transient( 'f3_mcp_google_http_' . \Fator3\McpGoogle\Connections::id() ) ?: null,
			'plugin_version'                 => defined( 'F3_MCP_GOOGLE_VERSION' ) ? F3_MCP_GOOGLE_VERSION : '',
		);

		if ( ! empty( $input['live'] ) ) {
			$data['token_ok'] = self::token_probe( $credentials );
		}

		return Response::ok( $data, __( 'Estado da integração Google.', 'wp-mcp-google-fator3' ) );
	}

	/**
	 * Pede um token por conector ligado, sem nunca devolvê-lo.
	 *
	 * @param mixed $credentials CredentialsInterface ou WP_Error.
	 * @return array<string,mixed>
	 */
	private static function token_probe( $credentials ): array {
		$out = array();

		foreach ( array(
			'ga'               => Options::ga_enabled(),
			'ads'              => Options::ads_enabled(),
			'gsc'              => true,
			'siteverification' => true,
			'sheets'           => true,
			'drive'            => true,
		) as $connector => $on ) {
			if ( ! $on ) {
				continue;
			}

			if ( is_wp_error( $credentials ) ) {
				$out[ $connector ] = false;
				continue;
			}

			$token = $credentials->get_access_token( Credentials::scopes_for( $connector ) );

			// Só o veredito: o comprimento do token já seria informação a mais
			// sobre a credencial num transcript de conversa.
			$out[ $connector ] = ! is_wp_error( $token ) && is_string( $token ) && '' !== $token;
		}

		return $out;
	}

	/**
	 * `1234567890` vira `123-***-7890`.
	 *
	 * O ID da gerenciadora não é segredo, mas também não precisa sair inteiro
	 * de um site para uma conversa; o suficiente para conferir se é o certo.
	 */
	private static function mask_customer_id( string $id ): string {
		if ( 10 !== strlen( $id ) ) {
			return '' === $id ? '' : '***';
		}

		return substr( $id, 0, 3 ) . '-***-' . substr( $id, -4 );
	}

	/**
	 * Quantas rotas deste plugin estão registradas, por família.
	 *
	 * @return array<string,int>
	 */
	private static function count_abilities(): array {
		$counts = array(
			'ga'               => 0,
			'ads'              => 0,
			'google'           => 0,
			'gsc'              => 0,
			'siteverification' => 0,
			'total'            => 0,
		);

		if ( ! function_exists( 'wp_get_abilities' ) ) {
			return $counts;
		}

		foreach ( (array) wp_get_abilities() as $name => $ability ) {
			$name = is_string( $name ) ? $name : '';

			foreach ( array( 'ga', 'ads', 'google', 'gsc', 'siteverification' ) as $prefix ) {
				if ( 0 === strpos( $name, $prefix . '/' ) ) {
					++$counts[ $prefix ];
					++$counts['total'];
					break;
				}
			}
		}

		return $counts;
	}

	// =========================================================================
	// google/selftest
	// =========================================================================

	private static function register_selftest(): void {
		Ability::register(
			'google/selftest',
			'any',
			array(
				'label'        => __( 'Google: autoteste', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Roda a bateria de verificação do plugin sem sair para a rede: cifra dos segredos, assinatura JWT, lista de hosts, portão, presets de data, tradução de filtros, catálogo do Ads e montagem das consultas. Devolve passed, failed e o detalhe de cada checagem.', 'wp-mcp-google-fator3' ),
				'output_schema' => array(
					'type' => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'execution_success' => array( 'type' => 'boolean' ),
						'checks_passed' => array( 'type' => 'boolean' ),
						'all_checks_passed' => array( 'type' => 'boolean' ),
						'complete' => array( 'type' => 'boolean' ),
						'passed' => array( 'type' => 'integer' ),
						'failed' => array( 'type' => 'integer' ),
						'skipped' => array( 'type' => 'integer' ),
						'not_configured' => array( 'type' => 'integer' ),
						'checks' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'input_schema' => array(
					'properties' => array(
						'live' => array(
							'type'        => 'boolean',
							'description' => __( 'Quando true, acrescenta as checagens que saem para a rede: leituras reais dos serviços habilitados e dos recursos configurados. Padrão: false.', 'wp-mcp-google-fator3' ),
						),
					),
				),
				'callback'     => static function ( array $input ): array {
					$result = SelfTest::run( array( 'live' => ! empty( $input['live'] ) ) );

					$message = sprintf( 'Autoteste: %d passaram, %d falharam, %d puladas.', $result['passed'], $result['failed'], $result['skipped'] );
					return $result['success']
						? Response::ok( $result, $message )
						: Response::fail( new \WP_Error( 'f3_google_selftest_failed', $message ), $result );
				},
			)
		);
	}

	// =========================================================================
	// google/list-accounts
	// =========================================================================

	private static function register_list_accounts(): void {
		Ability::register(
			'google/list-accounts',
			'any',
			array(
				'label'        => __( 'Google: listar contas', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista, num formato só, as propriedades do GA4 e as contas do Google Ads que a credencial alcança. Use os account_id devolvidos em google/query. Cache de 10 minutos. Substitui o list_accounts do Porter.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'connector'       => array(
							'type'        => 'string',
							'enum'        => array( 'ga4', 'google-ads', 'search-console', 'ga', 'ads', 'gsc', 'all' ),
							'description' => __( 'Qual conector listar. Padrão: all (os dois). Um conector desligado ou sem credencial não derruba a chamada: os outros vêm e o motivo entra em warnings.', 'wp-mcp-google-fator3' ),
						),
						'query'           => array(
							'type'        => 'string',
							'description' => __( 'Filtra por trecho do nome, do id ou da conta-pai. Sem diferenciar maiúsculas nem acentos.', 'wp-mcp-google-fator3' ),
						),
						'expand_managers' => array(
							'type'        => 'boolean',
							'description' => __( 'Só Google Ads: também lista as contas administradas por cada gerenciadora (MCC) acessível. Custa uma chamada por gerenciadora. Padrão: false.', 'wp-mcp-google-fator3' ),
						),
						'refresh'         => array(
							'type'        => 'boolean',
							'description' => __( 'Ignora o cache de 10 minutos e consulta a Google de novo. Use depois de criar ou receber acesso a uma conta. Padrão: false.', 'wp-mcp-google-fator3' ),
						),
					),
				),
				'callback'     => static function ( array $input ): array {
					return Query::accounts( $input );
				},
			)
		);
	}

	// =========================================================================
	// google/list-fields
	// =========================================================================

	private static function register_list_fields(): void {
		Ability::register(
			'google/list-fields',
			'any',
			array(
				'label'        => __( 'Google: listar campos', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Descobre as métricas e dimensões que google/query aceita num conector. No GA4 vem do catálogo da própria API (com as personalizadas da propriedade, se informada); no Google Ads vem do catálogo curado do plugin. Substitui o list_fields do Porter.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'connector'  => array(
							'type'        => 'string',
							'enum'        => array( 'ga4', 'google-ads', 'search-console', 'ga', 'ads', 'gsc' ),
							'description' => __( 'Obrigatório: ga4, google-ads ou search-console. Os dois catálogos são diferentes e não se misturam.', 'wp-mcp-google-fator3' ),
						),
						'field_type' => array(
							'type'        => 'string',
							'enum'        => array( 'metric', 'dimension' ),
							'description' => __( 'Filtra por tipo. Sem ele vêm os dois.', 'wp-mcp-google-fator3' ),
						),
						'query'      => array(
							'type'        => 'string',
							'description' => __( 'Filtra por trecho do id, do nome nativo ou do rótulo (ex.: "conver", "cost", "campanha"). Quando um campo casa exatamente, ele também volta em exact_match.', 'wp-mcp-google-fator3' ),
						),
						'account_id' => array(
							'type'        => 'string',
							'description' => __( 'Só GA4: a propriedade (ex.: "properties/123456") cujas dimensões e métricas personalizadas devem entrar na lista. Sem ela vem o catálogo universal. Ignorado no Google Ads.', 'wp-mcp-google-fator3' ),
						),
						'resource'   => array(
							'type'        => 'string',
							'description' => __( 'Só Google Ads: nome do recurso GAQL (ex.: campaign, ad_group, search_term_view) cujos campos selecionáveis vivos devem ser acrescentados ao catálogo curado. Cache de 24 h.', 'wp-mcp-google-fator3' ),
						),
					),
					'required'   => array( 'connector' ),
				),
				'callback'     => static function ( array $input ): array {
					return Query::fields( $input );
				},
			)
		);
	}

	// =========================================================================
	// google/query
	// =========================================================================

	private static function register_query(): void {
		Ability::register(
			'google/query',
			'any',
			array(
				'label'        => __( 'Google: consultar dados', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Relatório unificado de GA4, Google Ads ou Search Console: métricas por dimensão, num período, com filtros, ordenação e comparação com o período anterior. Devolve colunas e linhas posicionais. Substitui o query_data do Porter.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'search_type'             => array(
							'type'        => 'string',
							'description' => 'Search Console: sinônimo de type.',
						),
						'aggregation_type'        => array(
							'type'        => 'string',
							'description' => 'Search Console: auto, byPage ou byProperty.',
						),
						'offset'                  => array(
							'type'        => 'integer',
							'minimum'     => 0,
							'description' => 'Search Console: sinônimo de start_row.',
						),
						'dimension_filter_groups' => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'object' ),
							'description' => 'Search Console: grupos de filtros dimensionais no formato da API.',
						),
						'type'                    => array(
							'type'        => 'string',
							'description' => 'Search Console: web, image, video, news, discover ou googleNews.',
						),
						'data_state'              => array(
							'type'        => 'string',
							'description' => 'Search Console: final ou all.',
						),
						'start_row'               => array(
							'type'        => 'integer',
							'minimum'     => 0,
							'description' => 'Search Console: índice inicial da página, a partir de zero.',
						),
						'connector'               => array(
							'type'        => 'string',
							'enum'        => array( 'ga4', 'google-ads', 'search-console', 'ga', 'ads', 'gsc' ),
							'description' => __( 'Obrigatório, um por chamada: ga4, google-ads ou search-console. Use google/blend para combinar conectores.', 'wp-mcp-google-fator3' ),
						),
						'accounts'                => array(
							'type'        => array( 'array', 'string' ),
							'items'       => array( 'type' => 'string' ),
							'description' => __( 'Contas a consultar, como vêm de google/list-accounts: "properties/123456" no GA4, "1234567890" ou "123-456-7890" no Google Ads. Com duas ou mais, as linhas ganham as colunas account_id e account_name, o limite vale por conta e uma conta que falhar vira aviso em warnings sem derrubar as outras. IDs ou nomes únicos. O seletor * expande todas as contas do catálogo acessível; seleção explícita mantém teto de 25 com aviso.', 'wp-mcp-google-fator3' ),
						),
						// Sinônimo declarado de propósito: `Ability::register()` fecha o
						// esquema com additionalProperties=false, e o WordPress 6.9+ recusa
						// a chamada inteira quando chega uma chave não declarada. Um
						// sinônimo que o código aceita e o esquema proíbe é código morto.
						'account_id'              => array(
							'type'        => array( 'array', 'string' ),
							'items'       => array( 'type' => 'string' ),
							'description' => __( 'Sinônimo de accounts, para quem vem do vocabulário do Porter. Use um ou outro, não os dois.', 'wp-mcp-google-fator3' ),
						),
						'metrics'                 => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'string' ),
							'description' => __( 'Ao menos uma. GA4: nomes da API (sessions, activeUsers, screenPageViews, totalRevenue…) e os apelidos users, pageviews, revenue, bounce_rate, engagement_rate, avg_session_duration, cost. Google Ads: impressions, clicks, cost, ctr, average_cpc, average_cpm, conversions, conversions_value, cost_per_conversion, conversion_rate, all_conversions, all_conversions_value, search_impression_share, search_top_impression_share, absolute_top_impression_percentage, interactions, interaction_rate, video_views, view_through_conversions, roas — ou o nome nativo (metrics.*). Custo e afins já voltam na moeda da conta, não em micros.', 'wp-mcp-google-fator3' ),
						),
						'dimensions'              => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'string' ),
							'description' => __( 'Opcional. GA4: nomes da API (date, sessionDefaultChannelGroup, country…) e os apelidos channel, source_medium, landing_page, page, device. Google Ads: date, week, month, quarter, year, day_of_week, device, ad_network_type, campaign_id, campaign_name, campaign_status, campaign_type, campaign_bidding_strategy_type, campaign_budget, ad_group_id, ad_group_name, ad_group_status, ad_id, ad_name, ad_type, ad_status, keyword, keyword_match_type, search_term, geo_country, account_id, account_name, currency, conversion_action_name — ou o nome nativo qualificado.', 'wp-mcp-google-fator3' ),
						),
						'date_range'              => array(
							'type'        => array( 'object', 'string' ),
							'description' => __( 'Obrigatório. Preset (string ou {"preset":"..."}): today, yesterday, last_7_days, last_14_days, last_28_days, last_30_days, last_90_days, this_week, last_week, this_month, last_month, this_quarter, last_quarter, this_year, last_year. Ou {"from":"2026-08-01","to":"2026-08-31"}. Os last_N_days terminam ONTEM; os this_* incluem hoje. Resolvido no fuso do site.', 'wp-mcp-google-fator3' ),
						),
						'compare_date_range'      => array(
							'type'        => array( 'object', 'string' ),
							'description' => __( 'Opcional. "previous_period" (mesmo número de dias imediatamente antes), "previous_year" (as mesmas datas um ano antes), um preset, ou {"from","to"}. Com comparação a tabela ganha a primeira coluna date_range_name, com os valores current e previous.', 'wp-mcp-google-fator3' ),
						),
						'filters'                 => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'object' ),
							'description' => __( 'Lista de {"field","operator","value"}, combinados com E. Operadores: eq, neq, gt, gte, lt, lte, contains, ncontains, begins_with, ends_with, in (value é lista), regex, null, notnull. O campo usa os mesmos nomes de metrics/dimensions. No Google Ads, filtrar um campo em moeda usa a moeda (cost > 100 são cem reais, não cem micros).', 'wp-mcp-google-fator3' ),
						),
						'order_by'                => array(
							'type'        => array( 'array', 'object', 'string' ),
							'items'       => array( 'type' => array( 'object', 'string' ) ),
							'description' => __( 'Lista de {"field","direction"} com direction asc ou desc (padrão desc). O campo precisa estar em metrics ou dimensions.', 'wp-mcp-google-fator3' ),
						),
						'order_bys'               => array(
							'type'        => array( 'array', 'object', 'string' ),
							'items'       => array( 'type' => array( 'object', 'string' ) ),
							'description' => __( 'Sinônimo de order_by (é assim que a Data API do GA4 chama o campo). Use um ou outro.', 'wp-mcp-google-fator3' ),
						),
						'limit'                   => array(
							'type'        => 'integer',
							'description' => __( 'Máximo de linhas POR CONTA. Padrão e teto: o limite configurado no site (1000 de fábrica).', 'wp-mcp-google-fator3' ),
						),
						'resource'                => array(
							'type'        => 'string',
							'description' => __( 'Só Google Ads, opcional: força o recurso da cláusula FROM (campaign, ad_group, ad_group_ad, keyword_view, search_term_view, geographic_view, customer). Sem ele o recurso é deduzido das dimensões pedidas.', 'wp-mcp-google-fator3' ),
						),
					),
					// `accounts` fica fora de `required` porque `account_id` é um
					// sinônimo válido e o núcleo não sabe disso; quem recusa a
					// ausência dos dois é `Query::plan()`, com uma mensagem que diz
					// qual formato usar em cada conector.
					'required'   => array( 'connector', 'metrics', 'date_range' ),
				),
				'callback'     => static function ( array $input ): array {
					return Query::run( $input );
				},
			)
		);
	}
}
