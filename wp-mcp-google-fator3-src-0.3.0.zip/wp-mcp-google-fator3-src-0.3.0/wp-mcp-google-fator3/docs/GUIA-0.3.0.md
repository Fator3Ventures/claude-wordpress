# Guia da versão 0.3.0

## Atualização e conexão

Envie o ZIP sem `src` em Plugins → Adicionar plugin → Enviar plugin e substitua a versão anterior. Preserve o plugin instalado e seus dados: a desinstalação apaga as credenciais. O nome da pasta, o callback OAuth e o endpoint MCP continuam iguais. Chamadas antigas usam `connection_id: "default"` implicitamente e conservam a configuração existente.

Em Ferramentas → MCP Google:

1. Escolha a conexão e os serviços. Para novas configurações, habilite apenas os serviços necessários e escolha leitura quando suficiente. A ausência de seleção em instalações antigas conserva o comportamento anterior até salvar uma seleção explícita.
2. Importe o JSON de uma service account ou de um cliente OAuth **Web**. No segundo caso, o JSON deve incluir o callback exato exibido no painel. O importador valida o arquivo antes de gravar.
3. Com OAuth, clique em conectar e conceda os escopos escolhidos. Novos escopos exigem novo consentimento. Com service account, conceda à conta acesso aos recursos Google.
4. Use **Consultar recursos acessíveis**, informe os IDs padrão e teste o acesso. Sheets requer uma planilha concreta para o teste. Uma listagem bem-sucedida não comprova acesso a todos os recursos.
5. Execute `google/preflight` ou `google/selftest` com `live:true`. Atualize a descoberta de habilidades no cliente MCP.

O assistente não cria automaticamente propriedades GA4, contas Ads ou clientes OAuth. A aplicação de configuração usa IDs existentes; criação remota continua nas habilidades administrativas próprias e nas etapas do Google Cloud. Um serviço OAuth central da Fator3 exigiria infraestrutura e operação separadas e não integra este ZIP.

## Contrato do selftest

`Response::ok()` conserva seu contrato geral. O wrapper do selftest escolhe explicitamente uma resposta de erro quando há reprovação, evitando sobrescrever o resultado.

Exemplo de teste executado com verificações reprovadas (campos principais):

```json
{
  "success": false,
  "error_code": "f3_google_selftest_failed",
  "execution_success": true,
  "checks_passed": false,
  "all_checks_passed": false,
  "complete": true,
  "passed": 10,
  "failed": 1,
  "skipped": 0,
  "not_configured": 0
}
```

| Campo | Significado |
|---|---|
| `execution_success` | O teste conseguiu produzir seus resultados. Exceção no executor resulta em `false`. |
| `checks_passed` / `success` | Não há verificações reprovadas nem recursos necessários sem configuração. |
| `all_checks_passed` | Todas as verificações incluídas passaram, sem itens pulados ou não configurados. |
| `complete` | Nenhuma verificação incluída foi pulada ou ficou sem configuração; verificações executadas podem ter falhado. |
| `scope` | `local` ou `local_and_google`. Aprovação local não comprova acesso às APIs. |
| `checks[].status` | `passed`, `failed`, `skipped` ou `not_configured`. Puladas não entram na contagem de aprovadas. |

O agente deve conferir `execution_success`, `checks_passed` e, quando precisa de cobertura integral, `all_checks_passed` e `scope`. Rejeição anterior à execução por permissão/canal permanece um erro de autorização, sem resultados de verificações.

`google/preflight` aceita `services` e `bindings` e faz leituras por serviço. Inclui alvo, `resource_tested`, versão, site, conexão, identificação pública da credencial e horário. A inspeção de uma propriedade GSC usa o identificador exato. O diagnóstico HTTP guarda método, tamanho do corpo, Content-Length, status e identificador da requisição; não guarda corpo ou Authorization.

## Gravação verificada

`Options::set()`, `set_secret()`, `delete()` e `write_verified()` devolvem resultado estruturado. Exemplo:

```json
{
  "success": true,
  "persisted": true,
  "changed": false,
  "option": "f3_mcp_google_enabled",
  "error_code": null,
  "message": "Persistência confirmada."
}
```

A confirmação consulta diretamente o banco de opções do WordPress, sem aceitar cache ou filtro de leitura como prova. O retorno `false` de `update_option()` é compatível com sucesso quando o valor esperado já está persistido. Segredos passam por cifra e conferência da decifra antes da gravação. Valores, segredos e cifras não aparecem no resultado.

| Código | Condição |
|---|---|
| `f3_google_option_busy` | Outra gravação do plugin mantém a trava da opção. |
| `f3_google_option_read` | Falhou a leitura anterior à gravação. |
| `f3_google_option_write` | Exceção na gravação. |
| `f3_google_option_verify_read` | Falhou a leitura de confirmação; o resultado persistido é desconhecido. |
| `f3_google_option_persistence` | O valor esperado não foi confirmado. |
| `f3_google_option_delete` | A exclusão não foi confirmada. |
| `f3_google_crypto_encrypt` | Falha ao cifrar o segredo. |
| `f3_google_crypto_verify` | Falha ao conferir a cifra preparada. |
| `f3_google_crypto_decrypt` | Credencial armazenada existe, mas não pode ser decifrada durante o diagnóstico/uso. |
| `f3_google_rollback_conflict` | Valor mudou externamente durante a compensação; não foi substituído. |

`batch_verified()` prepara todos os segredos antes de escrever, mantém travas por opção e tenta restaurar os valores anteriores quando uma etapa falha. Retorna `operations` e `rollback`; confira cada resultado. É compensação verificável, não uma transação SQL atômica nem garantia contra alterações diretas de outros plugins no banco. Os handlers do painel só anunciam sucesso depois de confirmar; JSON de service account inválido não altera o subject.

## Conexões e configuração por agentes

Até 20 conexões locais, com credenciais, seleção de serviços, recursos e caches de tokens separados. `connection_id` é aceito em todas as habilidades. O canal geral e a capacidade administrativa continuam comuns ao site.

```json
{"id":"marketing","label":"Marketing"}
```

Envie a `google/create-connection`; depois configure essa conexão no painel. `google/list-connections` não expõe segredos.

Para `google/plan-configuration` e depois `google/configure`:

```json
{
  "connection_id": "marketing",
  "services": {"ga":"read","gsc":"write"},
  "bindings": {"ga_property_id":"123456","gsc_site_url":"https://exemplo.com/"},
  "validate_access": true
}
```

O plano não grava. `configure` confirma o acesso aos recursos indicados por padrão; `validate_access:false` permite preparar a configuração antes de conectar. `services` substitui a seleção inteira; `bindings` atualiza os campos informados e preserva os demais. IDs vazios removem o vínculo correspondente. Repetir a configuração não cria recursos Google. Conexões e chaves nunca são criadas implicitamente pelas consultas.

Perfis: GA `read|write|admin`; GSC, Ads e Sheets `read|write`; Site Verification e Drive `write`. A seleção limita escopos e recusa escrita em perfil de leitura; papéis Google continuam necessários. O Ads usa `adwords` mesmo no perfil de leitura, e a restrição de escrita é aplicada pelo plugin. A seleção de Sheets inclui `drive.file` para operações relacionadas a arquivos.

`google/disconnect` remove tokens OAuth desta conexão e preserva o cliente. `revoke:true` também solicita revogação no Google: o alcance é a autorização do usuário no projeto e pode afetar outros sites desse usuário. A resposta distingue `local_disconnected`, `revocation_requested` e `remote_revoked`.

## Sitemap

`gsc/ensure-sitemap` aceita `site_url`, `sitemap_url`, `check_only` e `force`. Usa vínculos configurados ou o sitemap do WordPress/Yoast quando disponível.

- Consulta o registro existente e evita reenvio por padrão.
- Para envio, exige sitemap HTTPS da propriedade e publicado no host deste site; a leitura local tem limite, proteção do WordPress e não segue redirecionamentos.
- `check_only:true` consulta sem enviar. `force:true` permite reenvio explícito.
- Mantém PUT vazio com `Content-Length: 0` e consulta o estado depois da submissão.
- `submitted`, `registered` e `processing_state` são distintos. Falha na confirmação posterior aparece em `verification_error`; não transforma automaticamente a submissão em tentativa a repetir.

Processamento não equivale a indexação. `gsc/submit-sitemap` permanece disponível para a submissão direta, inclusive em outros hosts autorizados.

## Filas e agendamentos

`google/create-job` aceita tarefas `query`, `export`, `sitemap`, `report`, `preflight` e `inspect-urls`, com `parameters`, `idempotency_key` e prioridade opcional de 0 a 9. Prioridades maiores são executadas primeiro. A chave é vinculada à conexão e ao criador; reutilizá-la com entrada diferente gera conflito. A idempotência vale enquanto o registro é retido.

```json
{
  "task":"report",
  "parameters":{"template":"organic-pages","accounts":["https://exemplo.com/"]},
  "idempotency_key":"relatorio-setembro-01"
}
```

Para inspeção em lote, envie a `gsc/inspect-urls`:

```json
{"site_url":"https://exemplo.com/","urls":["https://exemplo.com/a","https://exemplo.com/b"],"idempotency_key":"inspecao-01","priority":7}
```

Retorna `job_id`; criar o job não executa a inspeção imediatamente. Até 500 URLs por job, com avanço persistido por URL, cache por 24 horas e orçamento local móvel de 24 horas. Padrão: 1.800 inspeções por propriedade/24h e teto local de 500/minuto. O orçamento de 24h pode ser ajustado pela opção `f3_mcp_google_inspection_budget`, até 2.000. Ele não conhece consumo feito por outras instalações; erros de quota do Google continuam sendo tratados.

`google/get-job` aceita `job_id`, `offset`, `limit` (padrão 20, máximo 100) e `include_input`. A paginação cobre resultados de inspeção e linhas de relatórios. `google/list-jobs` lista resumos e agendas. `google/run-job` executa uma etapa; `cancel-job` cancela trabalho pendente e `delete-job` remove registros encerrados. Limite de 1.000 jobs retidos; exclua os antigos para liberar espaço.

Estados: `pending`, `running`, `completed`, `failed`, `cancelled`, `unknown`. O `success` da operação de acompanhamento informa se o executor/consulta funcionou; o resultado da tarefa está em `job.status`, `job.result.success` e, para inspeções, `job.summary` e `job.results[].result.success`. Um lote concluído pode conter URLs reprovadas. `unknown` exige verificar o destino de uma escrita interrompida; o plugin não a repete automaticamente. Leituras transitórias podem ser reagendadas até quatro tentativas.

`google/schedule-report` cria ou atualiza por `schedule_id`, com `task: report|query|preflight`, `parameters`, `interval_seconds` (mínimo 3.600) e `enabled`. `enabled:false` pausa. Há limite de 100 agendas. Resultados e alertas numéricos ficam nos jobs; não são enviadas mensagens externas.

O executor é WP-Cron, com intervalo de um minuto. Revalida a capacidade do criador e o canal antes de executar; a conexão e o usuário são restaurados depois. Sem acionamento de cron não há pontualidade garantida. Para independência de visitas, configure o cron do servidor. O orçamento do tick limita o início de novas unidades; uma consulta/exportação individual ainda depende do limite de execução do PHP. Jobs não aumentam os limites já existentes de linhas e exportação.

## Relatórios e auditoria

Modelos em `google/report-templates`: `traffic`, `organic-pages`, `organic-queries`, `organic-page-drops`, `low-ctr-queries` e `campaigns`. Execute com `google/run-report`, informando `accounts` ou usando vínculos padrão, `date_range`, `compare` e, opcionalmente, `alert`.

`organic-page-drops` compara cliques por página com o período anterior e mantém ausência de linha como `null`. `low-ctr-queries` seleciona, da página de dados retornada pela API, consultas com pelo menos 100 impressões e CTR menor que 2%. Não representa todas as consultas do site. Os avisos de cobertura do Search Console são preservados.

Exemplo de monitor: `"alert":{"metric":"clicks","drop_percent":30,"minimum_baseline":10}`. Compara totais aditivos de períodos equivalentes; retorna `evaluated`, `triggered`, valores e variação. Base insuficiente, truncamento e falha de conta impedem a avaliação. Avisos de origem são mantidos. Variação não recebe atribuição causal. Prefira períodos encerrados, como `last_28_days`, para evitar comparar um dia ainda em coleta.

Auditoria usa registros independentes, com inserção exclusiva, conexão, usuário, versão e identificador. Mantém snapshots redigidos. Retenção padrão 1.000, ajustável entre 100 e 5.000 pela opção `f3_mcp_google_audit_retention`. O log legado permanece consultável; a limpeza explícita remove ambos. Não há rollback automático de operações Google.

## Script Cloud Shell

O pacote contém `reference/googlecloudscript.txt` revisado e `reference/googlecloudscript-original.txt` preservado. Copie o revisado ao Cloud Shell e execute:

```bash
PROJETO=seu-projeto bash googlecloudscript.txt site1 site2
```

Projeto e sites são explícitos; `--project` é usado nas chamadas de serviços/contas. O script conserva JSON local válido, recusa criar outra chave quando só a chave remota existe, grava diretório 700/arquivos 600 e produz manifesto sem segredos. `ROTACIONAR_CHAVES=1` cria chave adicional e preserva o arquivo anterior. Não remove automaticamente chaves remotas antigas. Falhas permanentes são exibidas; erros temporários de leitura e de propagação têm tentativas limitadas. Criação com resultado não confirmado exige conferir as chaves remotas antes de repetir.

Habilitar APIs não concede acesso a GA4, Ads, GSC ou arquivos. O script provisiona service accounts; OAuth Web continua sendo configurado no Google Cloud e importado no painel. `SEGUNDO_DONO`, `DIRETORIO_CHAVES`, `ROTACIONAR_CHAVES` e `BAIXAR_CHAVES` são opções explícitas documentadas no próprio script.

## Evidência e limites desta entrega

- 805 testes PHPUnit, 8.730 asserções, sem falhas, em PHP 8.3.6. Incluem os 763 testes anteriores e 42 cenários novos.
- Sintaxe verificada nos 78 PHP do plugin/testes, incluindo 54 PHP de produção.
- 20 verificações usando funções reais de opções, cache e hooks do WordPress 6.9.4, com adaptador SQLite descartável: gravação, recusa, cifra, compensação, cache obsoleto e trava entre processos. Isso não equivale a uma instalação completa com MySQL/MariaDB.
- Três PUTs exercitados por HTTP local com Requests/Fsockopen do WordPress, todos vazios, `Content-Length: 0`, HTTP 204.
- Nove cenários do script Cloud Shell com `gcloud` simulado; nenhum projeto ou chave Google real foi criado.

Não houve implantação em WordPress de produção nem teste com contas Google reais. O pacote-fonte contém código, testes, evidências, manifesto das 131 habilidades e histórico Git. As evidências históricas da 0.2.1 são preservadas separadamente.
