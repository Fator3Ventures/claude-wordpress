# WP MCP Google Fator3 — fontes 0.3.0

Use **wp-mcp-google-fator3-0.3.0.zip** para atualizar pelo painel WordPress. Este pacote `src` contém desenvolvimento, documentação e evidências; não é o ZIP de instalação.

- `wp-mcp-google-fator3/`: plugin, testes e guia em `docs/GUIA-0.3.0.md`.
- `googlecloudscript.txt`: script Cloud Shell revisado. O original está em `reference/googlecloudscript-original.txt`; ambos também acompanham o instalador em `reference/`.
- `abilities-manifest.json` e `CATALOGO-HABILIDADES.md`: 131 habilidades e contratos.
- `evidence/0.3.0/`: resultados desta entrega. `integration/`: runners reproduzíveis.
- `history/0.2.1/`: documentos e evidências anteriores, identificados como históricos.
- `skill/`: orientação legada de agente recebida com a base. Os schemas e o guia 0.3.0 têm o contrato atualizado; essa skill não foi instalada nem modificada.
- `source-history.bundle`: histórico Git local com tag `v0.3.0`. Não houve push nem implantação remota.

## Reprodução

PHP 8.0+ para o plugin; suíte executada em PHP 8.3.6 e PHPUnit 9.6.17. Com dependências de desenvolvimento instaladas:

```bash
cd wp-mcp-google-fator3
composer install
composer test
```

Na raiz do pacote, os runners adicionais são independentes de credenciais Google:

```bash
php integration/native-options.php /caminho/wordpress /caminho/wp-mcp-google-fator3 /tmp/google-options-unico.sqlite
python3 integration/empty-put-wire.py --php /caminho/php --plugin /caminho/wp-mcp-google-fator3 --requests /caminho/wordpress/wp-includes/Requests
python3 integration/cloud-script-test.py googlecloudscript.txt
php integration/export-manifest.php /caminho/wp-mcp-google-fator3
```

`native-options.php` requer PDO SQLite e uma base descartável nova a cada execução. Usa funções reais do WordPress de opções/cache/hooks, não um site instalado. Não substitui ensaio de integração completa com MySQL/MariaDB. O runner HTTP usa Requests real contra localhost; Google é simulado. O runner Cloud Shell substitui gcloud por um dublê local.

Validação 0.3.0: 805 testes, 8.730 asserções; sintaxe dos 78 PHP (54 produção); 20 verificações de persistência/concorrência, três PUTs por HTTP local e nove cenários do script. Nenhuma conta Google real foi acessada.
