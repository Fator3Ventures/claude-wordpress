<?php
require $argv[1] . '/tests/bootstrap.php';
\Fator3\McpGoogle\Plugin::register_abilities();
$items = array(); $counts = array( 'read' => 0, 'write' => 0 );
foreach ( wp_get_abilities() as $ability ) {
    $meta = $ability->get_meta(); $mode = ! empty( $meta['annotations']['readonly'] ) ? 'read' : 'write'; ++$counts[$mode];
    $items[] = array( 'name' => $ability->get_name(), 'label' => $ability->get_label(), 'description' => $ability->get_description(), 'input_schema' => $ability->get_input_schema(), 'output_schema' => $ability->get_output_schema(), 'meta' => $meta );
}
echo json_encode( array( 'plugin_version' => F3_MCP_GOOGLE_VERSION, 'counts' => $counts, 'total' => count( $items ), 'source' => 'Plugin registration with bundled Abilities API polyfill', 'abilities' => $items ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n";
