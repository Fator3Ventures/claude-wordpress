#!/usr/bin/env python3
"""Exercise Cloud Shell setup with a local gcloud double; no Google writes."""
import json, os, pathlib, subprocess, sys, tempfile
script = pathlib.Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix='google-script-') as directory:
    root = pathlib.Path(directory)
    mock = root / 'gcloud'
    mock.write_text('''#!/usr/bin/env python3
import json,os,pathlib,sys
p=pathlib.Path(os.environ['MOCK_STATE']); state=json.loads(p.read_text()) if p.exists() else {'creates':0,'calls':[]}
a=sys.argv[1:];state['calls'].append(a)
def save(): p.write_text(json.dumps(state))
if os.environ.get('MOCK_PROJECT_DENIED') and a[:2]==['projects','describe']:
 save(); print('PERMISSION_DENIED',file=sys.stderr);sys.exit(1)
if a[:4]==['iam','service-accounts','keys','list']:
 print('existing-key' if state['creates'] else '')
if a[:4]==['iam','service-accounts','keys','create']:
 state['creates']+=1
 if os.environ.get('MOCK_KEY_DENIED'):
  save(); print('PERMISSION_DENIED',file=sys.stderr);sys.exit(1)
 email=next(x.split('=',1)[1] for x in a if x.startswith('--iam-account='))
 project=next(x.split('=',1)[1] for x in a if x.startswith('--project='))
 pathlib.Path(a[4]).write_text(json.dumps({'type':'service_account','client_email':email,'project_id':project,'private_key':'dummy-key-'+str(state['creates'])}))
save()
''')
    mock.chmod(0o700)
    env = dict(os.environ, PATH=str(root)+os.pathsep+os.environ['PATH'], PROJETO='dummy-project', DIRETORIO_CHAVES=str(root/'keys'), MOCK_STATE=str(root/'state.json'), ESPERA_PROPAGACAO='0')
    def run(**extra): return subprocess.run(['bash',str(script),'example'],env=dict(env,**extra),capture_output=True,text=True,timeout=10)
    checks={}
    first=run(); assert first.returncode==0,first.stderr
    state=json.loads((root/'state.json').read_text()); assert state['creates']==1
    original=(root/'keys/example.json').read_bytes()
    second=run(); assert second.returncode==0,second.stderr
    assert json.loads((root/'state.json').read_text())['creates']==1
    checks['rerun_reuses_local_key']=True
    rotated=run(ROTACIONAR_CHAVES='1'); assert rotated.returncode==0,rotated.stderr
    assert (root/'keys/example.json').read_bytes()==original
    assert json.loads((root/'state.json').read_text())['creates']==2
    checks['explicit_rotation_preserves_old_key']=True
    assert (root/'keys/example.json').stat().st_mode & 0o777 == 0o600
    assert (root/'keys').stat().st_mode & 0o777 == 0o700
    checks['private_file_permissions']=True
    manifest=json.loads((root/'keys/manifest.json').read_text())
    assert manifest['project_id']=='dummy-project' and 'private_key' not in str(manifest)
    checks['manifest_has_no_private_key']=True
    rejected=run(MOCK_PROJECT_DENIED='1'); assert rejected.returncode!=0 and 'PERMISSION_DENIED' in rejected.stderr
    assert json.loads((root/'state.json').read_text())['creates']==2
    checks['permission_error_does_not_create_project_or_key']=True
    denied=run(MOCK_KEY_DENIED='1',ROTACIONAR_CHAVES='1'); assert denied.returncode!=0
    assert json.loads((root/'state.json').read_text())['creates']==3
    checks['permanent_key_error_not_retried']=True
    (root/'keys/example.json').unlink()
    missing=run(); assert missing.returncode!=0 and 'chave remota' in missing.stderr
    checks['lost_private_key_requires_explicit_rotation']=True
    no_project=env.copy(); no_project.pop('PROJETO')
    assert subprocess.run(['bash',str(script),'example'],env=no_project,capture_output=True).returncode!=0
    checks['project_required']=True
    calls=json.loads((root/'state.json').read_text())['calls']
    assert all('--project=dummy-project' in a for a in calls if a[0] in ('iam','services'))
    checks['google_calls_pin_project']=True
    print(json.dumps({'passed':True,'google_calls':'simulated','checks':checks},indent=2))
