# Receitas de uso

Sequências completas das tarefas principais, com as chamadas, os parâmetros e o que conferir em cada passo. IDs são fictícios (`123456789`, `exemplo.com.br`). Antes de executar, confira o schema da habilidade em `google/ability-catalog` com `include_schemas:true`. Todas exigem administrador autorizado; as que chamam o Google exigem credencial ativa e o serviço ligado.

## 1. Primeira conexão

1. Painel: **Conexão → Identidade**. Prepare a conta de serviço ou o OAuth e ative o método (`GUIA-0.35.0.md`). Credenciais não são aceitas por habilidade.
2. `google/status {"compact":true}`. Conferir: `enabled:true`, `auth.configured:true`, `auth.mode` igual ao método escolhido.
3. `google/list-accounts {"connector":"ga4"}` (ou `search-console`, `google-ads`). Conferir que a conta ou propriedade esperada aparece; lista vazia indica que a identidade não tem acesso.
4. Painel: **Conexão → Serviços e recursos** e **Conexão → Permissões** para ligar serviços, recursos padrão e política. Equivalente por habilidade: `google/plan-configuration` e `google/configure` com `expected_revision` e `expected_plan_hash`.
5. `google/preflight {}`. Conferir cada serviço: `passed` comprova o acesso naquele instante; `failed` traz o recurso e o motivo; `not_configured` indica o que falta.
6. `google/readiness-status {}`. Conferir `state` e seguir `actions[]`.

## 2. Relatório GA4

1. `google/list-fields {"connector":"ga4","account_id":"properties/123456789","field_type":"metric"}` para confirmar nomes de métricas e dimensões.
2. Relatório por modelo: `google/run-report {"template":"traffic","accounts":["properties/123456789"],"date_range":"last_28_days"}`. Modelos: `traffic`, `organic-pages`, `organic-queries`, `organic-page-drops`, `low-ctr-queries`, `campaigns`.
3. Consulta livre: `google/query {"connector":"ga4","accounts":["properties/123456789"],"metrics":["activeUsers","sessions"],"dimensions":["country"],"date_range":{"from":"2026-10-01","to":"2026-10-31"}}`.
4. Conferir `row_count`, `truncated` e, em coleta completa, `collection.complete` e `coverage` (`ANALYTICS.md`). `success:true` com `truncated:true` é resultado parcial.

## 3. Consulta no Search Console

1. `gsc/list-sites {}`: conferir que a propriedade (`sc-domain:exemplo.com.br` ou `https://www.exemplo.com.br/`) aparece com permissão.
2. `gsc/query {"site_url":"sc-domain:exemplo.com.br","start_date":"2026-10-01","end_date":"2026-10-31","dimensions":["query"],"row_limit":1000}`.
3. Para percorrer todas as linhas disponíveis: `google/query {"connector":"search-console","accounts":["sc-domain:exemplo.com.br"],"metrics":["clicks","impressions","ctr","position"],"dimensions":["query"],"date_range":{"from":"2026-10-01","to":"2026-10-31"},"collection":{"mode":"complete"}}`.
4. Conferir: `quality.all_rows_guaranteed` é sempre `false` no Search Console; dias sem dados não viram zero.

## 4. Planejador de palavras-chave

Pré-requisitos: Google Ads ligado, developer token, conta selecionada e nível de acesso registrado (Test só com conta de teste; Explorer e não informado recusam).

1. `google/ability-catalog {"prefix":"ads/keyword-"}`: conferir `available` e `unavailable_reason` das cinco habilidades.
2. `ads/keyword-metrics {"keywords":["consultoria de tecnologia","cto fracionado"]}`. Conferir `archive_id`.
3. `ads/keyword-ideas {"url":"https://www.exemplo.com.br/","page_size":1000}`. Enquanto `complete` for `false`, repita com o `resume_id` recebido.
4. `ads/keyword-archive {"archive_id":"<id>","limit":50,"offset":0}` para ler o arquivo; siga `next_offset`.
5. Junção com Search Console por `google/blend` (exemplo completo em `PLANEJADOR.md`).

## 5. Acervo diário do Google Ads

1. `google/integration-status {"compact":true}`: obter `configuration_revision`.
2. `ads/archive-configure {"account_id":"1234567890","enabled":true,"datasets":["clicks","campaign","changes"],"backfill_days":90,"revisit_days":7,"expected_revision":"<configuration_revision>"}`. A habilidade confere conta, moeda e fuso no Google.
3. `ads/archive-status {}`: conferir progresso e recortes deferidos. Não inicia coleta.
4. A coleta avança pelo executor de minuto. Para avançar manualmente: `ads/archive-collect {"account_id":"1234567890","dataset":"campaign","date":"2026-10-27"}` até sair de `state:"pending"`.
5. Leitor para outro plugin: `ads/archive-consumer-grant` com a revisão atual (`ACERVO-ADS-GSC.md`, `CORE-ACERVOS.md`).

## 6. Agendar relatório

1. `google/schedule-report {"task":"report","parameters":{"template":"traffic","accounts":["properties/123456789"],"date_range":"last_7_days"},"interval_seconds":86400}`. Intervalo de 3.600 a 2.592.000 s. Recursos e parâmetros são congelados na agenda; períodos relativos são resolvidos em cada ocorrência.
2. `google/get-schedule {"schedule_id":"<id>"}`: conferir `enabled`, próximo vencimento e a revisão.
3. Para alterar: `google/schedule-report` com `schedule_id` e `expected_revision` lido no passo 2.
4. Execução: o executor do WP-Cron processa os vencidos. Sem tráfego no site, chame `google/executar-vencidos {}` ou configure no servidor `wp mcp-google run-due --user=<administrador>`.
5. Conferir o resultado em `google/list-jobs {}` e `google/get-job {"job_id":"<id>"}`.

## 7. Exportar para planilha

1. Simulação: `google/export-to-sheet {"query":{"connector":"ga4","accounts":["properties/123456789"],"metrics":["sessions"],"dimensions":["date"],"date_range":"last_28_days"},"title":"Sessões 28 dias","dry_run":true}`.
2. Execução: a mesma chamada sem `dry_run`. Por padrão `completeness_policy:"require_complete"`: fonte incompleta impede criar ou alterar a planilha. Para aceitar parcial, envie `allow_partial` explicitamente.
3. `mode:"append"` em planilha existente exige confirmação: `google/prepare-operation` e repetição com `confirmation_token`.
4. Conferir no recibo `extraction_complete`, `operation_outcome` e `verification`. Em `append`, a verificação declara `complete:false` (a API não devolve o intervalo inserido).

## 8. Entrega de conversões

Pré-requisito: Fator3 Site Core com o contrato de entrega e o destino configurado lá.

1. `google/conversion-delivery-status {}`: conferir o estado por destino e obter `revision`.
2. Painel **Conversões** ou `google/configure-conversion-delivery {"expected_revision":"<revision>","config":{…}}` com o fluxo GA4 ou a ação Google Ads (estrutura em `ability-catalog.json`). O segredo do Measurement Protocol vai no campo próprio `mp_secret`.
3. `google/verify-conversion-delivery {"expected_revision":"<revision atual>","target":"ga4"}` (ou `google_ads`). A verificação não coleta conversão; GA4 usa validação de debug e Ads usa `validateOnly`.
4. Conferir em `google/readiness-status` os checks `conversion_ga4` e `conversion_google_ads`. A prova vale 24 h e é renovada automaticamente (`CONVERSION-DELIVERY-CORE-140.md`, `AVISOS-RENOVACAO.md`).

## 9. Diagnóstico

1. `google/status {"compact":true}`. Se `health` for `idle` ou `due`, `scheduling_active_errors` for 0 e `incidents_open` for 0, a operação local está saudável.
2. `google/readiness-status {}`: seguir `actions[]` na ordem.
3. Se `health:"degraded"`: `google/status {}` e ler `cron.scheduling.active_errors` (`ACOMPANHAMENTO-CRON.md`). Para executar a manutenção agora: `google/maintenance {}`; depois, repetir o passo 1.
4. Acesso a recursos: `google/selftest {"live":true}`. `all_checks_passed:true` é aprovação integral; `complete:false` indica cobertura parcial.
5. Incidentes: `google/alerts {}`. Auditoria: `google/audit` com período e filtros.
