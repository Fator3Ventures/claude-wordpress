# Guia para agentes

Roteiro para um agente que opera o Fator3 MCP Google pelo Fator3 MCP: descobrir → ler → diagnosticar → configurar ou consultar → verificar, com confirmação e retomada. Vale para a release instalada; confira `plugin_version` em `google/status` ou no índice de `google/documentation`.

## Como chamar

O agente vê ferramentas do servidor MCP, não habilidades. O nome da ferramenta é o nome da habilidade com `/` trocado por `-`. Há dois caminhos para executar uma habilidade Google:

| Ferramenta MCP | Habilidade que a registra | Parâmetros da ferramenta | Uso |
|---|---|---|---|
| `wp-mcp-ultimate-discover-abilities` | do Fator3 MCP | filtros de descoberta do Fator3 MCP (por exemplo `query`, `provider`, `include_schemas`) | Listar as habilidades que a conexão MCP pode usar |
| `wp-mcp-ultimate-get-ability-info` | do Fator3 MCP | `ability_name` | Ler os schemas efetivos de uma habilidade |
| `wp-mcp-ultimate-execute-ability` | do Fator3 MCP | `ability_name`, `parameters` | Executar uma habilidade Google pelo nome |
| `google-mcp-read` | `google/mcp-read` | `ability`, `parameters`, `connection_id` | Executar uma habilidade Google de consulta |
| `google-mcp-write` | `google/mcp-write` | `ability`, `parameters`, `confirmation_token`, `idempotency_key`, `connection_id` | Executar uma habilidade Google de mutação |

Nas ferramentas `google-mcp-read` e `google-mcp-write`, `ability` é o nome da habilidade alvo (por exemplo `ga/run-report`) e `parameters` é o objeto de entrada dela. `google-mcp-read` recusa habilidades de escrita antes de executá-las; `google-mcp-write` recusa as de leitura (`f3_google_mcp_mode`). As duas executam só habilidades Google (prefixos `ga/`, `ads/`, `google/`, `gsc/`, `siteverification/`, `gtm/`), nunca outra ponte.

- `connection_id` no nível da ferramenta escolhe a conexão Google. Ele substitui qualquer `connection_id` dentro de `parameters`; omitido, vale a conexão padrão.
- `confirmation_token` de uma escrita sensível vai no nível da ferramenta ou dentro de `parameters`: a ponte o repassa à habilidade alvo, que o valida contra a intenção preparada e o consome uma única vez. Valores diferentes nos dois níveis são recusados com `f3_google_mcp_input`, sem consumir o token.
- `idempotency_key` no nível da ferramenta é a chave de repetição do transporte do Fator3 MCP; a ponte não a repassa à habilidade alvo. A chave de `google/create-job` vai dentro de `parameters`.

`google/mcp-read` e `google/mcp-write` são executores: chamá-las como alvo de `wp-mcp-ultimate-execute-ability` é recusado pelo Fator3 MCP (`ability_executor_forbidden`). Nos exemplos abaixo, `habilidade {parâmetros}` indica o nome da habilidade alvo e o objeto `parameters`.

Toda resposta tem `success` e `message`. Em falha: `success:false`, `error_code`, `message` e `details` (HTTP, motivo do Google e campos seguros, ou `null`). Decida pelo `error_code`, nunca pelo texto de `message`.

## 1. Descobrir

1. `google/ability-catalog {"prefix":"google/","mode":"read","limit":30}`. Pagine por `offset` até `next_offset: null`. Para cada habilidade: `available`, `unavailable_reason`, `metadata.fator3.mode`, `remote_effect`, `local_effect`. Com `include_schemas:true`, o item traz `input_schema` e `output_schema`.
2. `available` avalia somente a configuração local (`availability_scope: "local_configuration_only"`, `resource_access_verified: false`). Acesso ao recurso só é provado pela execução ou pelo diagnóstico.
3. `execution_checks` lembra que canal, ator, conexão, serviço, credencial e política são revalidados na execução.
4. O catálogo do Google conta só as habilidades deste plugin. A descoberta do Fator3 MCP é filtrada pelo perfil da conexão MCP; um total diferente não indica falha.

## 2. Ler

1. `google/documentation {}` devolve o índice (`documents[]` com `document`, `description`, `bytes`, `revision`). O mapa dos documentos lógicos está em `README.md`.
2. Leia com `{"document":"<ID>","offset":0,"limit_bytes":16384,"expected_revision":"<revision>"}` e continue em `next_offset` com o mesmo `expected_revision` até `next_offset: null`.
3. Antes de configurar, leia `ESPECIFICACAO.md` (fronteiras e requisitos) e a seção do `GUIA-0.35.0.md` correspondente.

## 3. Diagnosticar

| Pergunta | Habilidade | Observação |
|---|---|---|
| O plugin está pronto e saudável? | `google/status {"compact":true}` | Local. Traz canal, serviços, autenticação, prontidão de conversões e a saúde local: `health`, `work_health`, `scheduling_active_errors`, `incidents_open` |
| Qual é o próximo passo? | `google/readiness-status {}` | Local, contrato `google-readiness/1.0.0`. `state` = pior estado de `checks[]` (`credential`, `storage`, `recovery`, `executor`, `conversion_ga4`, `conversion_google_ads`, `incidents`, `core`); `actions[]` traz o texto da próxima ação |
| Por que está degradado? | `google/status {}` | Resposta completa e grande: `cron`, `cron.scheduling.active_errors`, `maintenance`, `storage`, `incidents`, `audit_health` |
| A credencial obtém token? | `google/status {"compact":true,"live":true}` | Pede um token por serviço ligado; `auth_probe` traz só verdadeiro/falso por serviço. Não prova acesso a recursos |
| A identidade acessa os recursos? | `google/preflight {}` ou `google/selftest {"live":true}` | Faz leituras reais no Google |

Use o compacto por padrão. Use o completo somente quando `health` for `degraded`, `scheduling_active_errors` ou `incidents_open` forem maiores que zero, ou `incidents_open` for `null` (leitura local falhou).

| `health` | Significado |
|---|---|
| `idle` | Agenda confirmada, sem trabalho vencido |
| `due` | Há agendas vencidas aguardando o executor |
| `blocked` | Todas as agendas vencidas estão bloqueadas |
| `degraded` | Há erro ativo de agenda ou a leitura da agenda falhou; ver `cron.scheduling.active_errors` na resposta completa |

`work_health` usa `idle`, `due`, `blocked` ou `unknown` (leitura da fila falhou).

## 4. Configurar ou consultar

**Configuração.** Leia `google/configuration-schema {"compact":true}` e use somente a operação indicada em `allowed_operations` de cada opção. Escritas de configuração exigem `expected_revision` (revisão atual da configuração). Para serviços: `google/plan-configuration` ou `google/configure {"dry_run":true}`, depois `google/configure` com `expected_revision` e `expected_plan_hash`; reduções de acesso exigem também `confirm_service_reduction:true`. Credenciais não são enviadas por habilidade: são informadas no painel.

**Consulta.** Escolha a conexão (`connection_id`), confira o recurso na política e chame a habilidade de leitura. Para relatórios: `google/run-report` (modelos) ou `google/query` (consulta livre); para leituras longas use `collection.mode:"complete"` (`ANALYTICS.md`).

**Escrita sensível no Google.** Exclusões, remoções, arquivamentos, revogações, permissões e usuários, retenção, Google Signals, operações em lote com mais de um alvo, `append` em planilha e `google/disconnect` com revogação exigem confirmação:

1. Execute a habilidade. Se responder `f3_google_confirmation_required` (`operation_outcome: "not_applied"`), nada foi enviado.
2. `google/prepare-operation {"ability":"<nome>","parameters":{…}}` executa a preparação capturando os pedidos sem enviá-los. Devolve `confirmation_token` (64 caracteres hexadecimais), `expires_at` (600 s), `effects` e `remote_writes_performed:false`. Mostre `effects` ao usuário; a preparação não atesta aprovação humana.
3. Repita a habilidade com os mesmos parâmetros e `confirmation_token`. Token expirado, reutilizado, de outra conexão ou com intenção diferente é recusado sem escrita.

**Idempotência.** `google/create-job` aceita `idempotency_key` (até 200 caracteres): a mesma chave com a mesma intenção devolve a tarefa existente (`created:false`); com intenção diferente, `f3_google_job_key_conflict`. Use uma chave por intenção quando o resultado de uma criação for incerto.

## 5. Verificar

- Depois de configurar, releia `google/configuration-schema` em nova requisição e confira o valor efetivo e a nova revisão.
- Depois de escrever no Google, leia `operation_outcome`: `applied` (confirmado), `not_applied`, `partial` (consultar etapas) ou `unknown` (resultado remoto incerto). Em `partial` e `unknown`, `retryable` é `false`.
- Depois de criar tarefa, acompanhe com `google/get-job {"job_id":"…"}`; admissão não comprova execução.

## Retomada após resultado incerto

| Situação | Ação |
|---|---|
| Escrita com `operation_outcome: "unknown"` | Não repita. Leia o estado do recurso no Google; para tarefas, use `google/get-job` e `google/reconcile-job` com evidência |
| Tarefa criada sem resposta | Repita `google/create-job` com a mesma `idempotency_key` |
| Coleta `google/query` incompleta com `collection.resumable:true` | Reenvie a consulta original com `collection.cursor` igual a `collection.continuation`, em até uma hora |
| Planejador com `complete:false` | Repita `ads/keyword-ideas` com o mesmo `resume_id`, mesma conexão e conta (`PLANEJADOR.md`) |
| Conversão com resultado incerto | Somente reconciliação por recibo; nunca reenvio (`CONVERSION-DELIVERY-CORE-140.md`) |
| `f3_google_configuration_conflict` ou revisão divergente | Releia o estado, refaça o plano e aplique a intenção novamente |

## Códigos de erro comuns

| Código | Causa | Próxima ação |
|---|---|---|
| `f3_google_disabled` | Canal Google fechado | Peça ao administrador para reabrir em Ferramentas → Fator3 MCP Google |
| `f3_google_forbidden` | Usuário sem `manage_options` ou sem a capacidade adicional | Use um administrador autorizado |
| `f3_google_connector_off` | Serviço desligado na conexão | Ligar o serviço em Conexão → Serviços e recursos |
| `f3_google_not_configured` | Nenhuma credencial ativa | Preparar e ativar a identidade em Conexão → Identidade |
| `f3_google_auth_not_active` | Método selecionado sem credencial ativa | Ativar a credencial do método escolhido |
| `f3_google_ads_access_level_required` | Nível de acesso do projeto pendente | Declarar o nível em Conexão → Serviços e recursos |
| `f3_google_keyword_access_level` | Nível do projeto Ads Explorer ou não informado | Registrar o nível aprovado (`PLANEJADOR.md`) |
| `f3_google_policy_denied` | Recurso fora da política | Confirmar com o administrador; não ampliar a política sem pedido |
| `f3_google_confirmation_required` | Escrita sensível sem token válido | Fluxo `google/prepare-operation` |
| `f3_google_configuration_conflict` | Revisão ou contexto mudou | Reler e replanejar |
| `f3_google_preflight_failed` | `google/preflight` encontrou acessos não confirmados | Ler o resultado por serviço e corrigir o acesso indicado |
| `f3_google_document_missing` | Documento fora do índice | Ler o índice e usar ID exato |
| `f3_google_document_revision` | Revisão ausente ou alterada | Reler o índice e recomeçar |
| `f3_google_storage_unavailable` | Tabelas indisponíveis | `google/storage-status`; administrador executa `google/maintenance` |
| `f3_google_recovery_paused` | Recuperação em andamento | `google/recovery-status`; aguardar retomada |
| `ability_invalid_input` | Parâmetros fora do schema de entrada (erro da Abilities API do WordPress) | Ler o schema no catálogo e corrigir |

## Exemplos

Sucesso — `google/status {"compact":true}` (valores ilustrativos, campos encurtados):

```json
{"success":true,"message":"","compact":true,"scope":"selected","plugin_version":"0.34.0","connection_id":"default","enabled":true,"ga_enabled":true,"ads_enabled":false,"auth":{"mode":"service_account","configured":true},"google_checks_performed":false,"health":"idle","work_health":"idle","scheduling_active_errors":0,"incidents_open":0}
```

Vazio — `google/ability-catalog {"prefix":"ads/keyword-","mode":"write"}` (as habilidades do planejador são de leitura):

```json
{"success":true,"message":"","catalog_version":"3.0.0","plugin_version":"0.34.0","abilities":[],"total":0,"next_offset":null,"execution_checks":"Channel, actor, connection, service, credential and resource policy are revalidated at execution."}
```

Erro — `ads/keyword-ideas {"url":"https://www.exemplo.com.br/"}` com Google Ads desligado:

```json
{"success":false,"message":"O conector Google Ads está desligado. Ligue-o em Ferramentas → Fator3 MCP Google.","error_code":"f3_google_connector_off","details":null}
```

Parcial — `google/query` com `collection.mode:"complete"` interrompida pelo orçamento da passagem (campos encurtados):

```json
{"success":true,"message":"Coleta incompleta; consulte a cobertura.","connector":"ga4","row_count":5000,"truncated":true,"collection":{"mode":"complete","complete":false,"resumable":true,"continuation":"<48 hex>","stop_reason":"<motivo>","failed_slices":0}}
```

## O que o transporte MCP mascara

O Fator3 MCP substitui por `[redigido]` o valor de um campo quando o nome, separado em componentes (`camelCase` vira `camel_case`), contém um componente sensível: `pass`, `password`, `secret`, `token`/`tokens`, `credential`, `cookie`, `authorization`, `salt`, `chave` e equivalentes em português, ou `api_key`, `private_key`, `access_key` e semelhantes. A regra olha o nome do campo, não o valor.

**Regra de nomes do plugin.** Os nomes de campo que o próprio plugin emite nas saídas não usam esses componentes. Exceção aceita pelo transporte: booleano terminado em `configured`, `present`, `available`, `valid`, `expired`, `enabled` ou `verified` (por exemplo `ads_developer_token_configured` em `google/status`). Os nomes trocados nesta versão estão na tabela de renomes de `CONTRACTS.md`. Parâmetros de entrada não mudaram, e os dados gravados antes da troca continuam legíveis.

Continuam mascarados pelo transporte, sem segredo envolvido:

1. Em `google/configuration-schema`, as definições das opções cujo ID é nome de segredo: `options.ads_developer_token`, `options.mp_secret`, `options.oauth_client_secret`, `options.oauth_refresh_token`, `options.credential_receipts`. Os IDs fazem parte do contrato de entrada e não mudam. Para ler essas definições, leia o documento `configuration-definitions.json` por `google/documentation`; o conteúdo de documento chega íntegro.
2. Em `google/list-actions`, descritores de parâmetros do Discovery do Google com nome sensível (`access_token`, `oauth_token`, `pageToken`). São nomes do Google e não mudam.
3. Nos relatórios GA4 com `return_property_quota:true`, `property_quota` repassa o objeto `propertyQuota` do Google sem tradução. As chaves `tokensPerDay`, `tokensPerHour` e `tokensPerProjectPerHour` chegam mascaradas. A mesma informação, observada pelo plugin, está em `google/status` → `quota_observations.observations[].observations`, com as chaves `quota_units_per_day`, `quota_units_per_hour` e `quota_units_per_project_per_hour`; `google_field` traz o nome original do Google.

`confirmation_token` com 64 caracteres hexadecimais chega íntegro: o Fator3 MCP abre exceção para esse valor.
