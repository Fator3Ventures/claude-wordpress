# Contratos do Google · 0.35.0

Em 0.35.0, uma conexão Ads recém-configurada retorna `f3_google_ads_access_level_required` até declarar o nível do projeto. O incidente de uma tarefa avulsa expõe `resource`, `created_at`, `action`, `email_state` e `slack_state` em `google/status`.

Contratos da release instalada. Schemas de entrada e saída de cada habilidade estão em `ability-catalog.json`; as opções de configuração em `configuration-definitions.json`. A consulta executável dos schemas prevalece sobre exemplos. Contratos com outros plugins: `CONTRATOS-PUBLICOS.md`, `SDK-PHP.md`, `CONVERSION-DELIVERY-CORE-140.md` e `CONVERSOES.md`.

## Versões de interface

| Interface | Versão | Onde aparece |
|---|---|---|
| Execução | 2.0.0 | `meta.fator3.execution_contract_version` de cada habilidade |
| Catálogo de habilidades | 3.0.0 | `catalog_version` de `google/ability-catalog` |
| Configuração | 4.0.0 | `contract_version` de `google/configuration-schema` (único valor aceito) |
| Manutenção | 2.0.0 | `maintenance_contract_version` |
| Armazenamento | 2.0.0 | `storage_contract_version` em `google/storage-status` |
| Agenda do cron | 2.0.0 | `cron.scheduling.contract_version` |
| Prontidão | `google-readiness/1.0.0` | `contract` de `google/readiness-status` |
| Perfil GA4 | 1.0.0 | `profile-schema.json` |
| Modelo portátil | 1.0.0 | `google/export-template`, `google/plan-template`, `google/apply-template` |
| Manifesto de atualização | 1.0.0 | Origem própria de atualização |

Todas as habilidades declaram `meta.fator3.provider = "wp-mcp-google-fator3"`, `version` igual à versão instalada e `policy_contract: 1`.

## Nomes de campo de saída

Nomes de campo de saída não usam componentes que o transporte MCP mascara: `pass`, `password`, `token`, `secret`, `credential`, `authorization`, `cookie`, `salt`, `chave`, `senha`, `segredo` e variantes. Um campo que precise desse sentido recebe outro nome. Não há aliases: o nome antigo deixou de existir na saída. Não há migração de dados: o que estava gravado continua legível. Parâmetros de entrada não mudaram.

<!-- campos-renomeados -->
| Habilidade | Nome antigo | Nome atual |
|---|---|---|
| `google/executar-vencidos` | `pass` | `run` |
| `google/executar-vencidos` | `maintenance.reused_pass` | `maintenance.reused_run` |
| `google/status` | `cron.last_pass` (também em `connections[].cron`) | `cron.last_run` |
| `google/status` com `live:true` | `token_ok` | `auth_probe` |
| `google/maintenance`, `google/storage-status`, `google/status`, `google/executar-vencidos` | `progress.<família>.examined_in_pass` | `progress.<família>.examined_in_run` |
| `google/readiness-status` (check `executor`, `detail`) | `last_pass_at` | `last_run_at` |
| `google/readiness-status` (check `executor`, `detail`) | `last_pass_age` | `last_run_age_seconds` |
| `google/ability-catalog` | `authorization` | `execution_checks` |
| `google/configuration-schema` | `authorization` | `access_requirements` |
| `google/configuration-schema` | `options.*.secret` | `options.*.confidential` |
| `google/configuration-schema` | `runtime_prerequisites.credentials` | `runtime_prerequisites.authentication` |
| `google/selftest` | `data_manager.credential` | `data_manager.identity_requirement` |
| `google/selftest` | `data_manager.developer_token` | `data_manager.developer_access` |
| `google/export-template` | `secrets_included` | `confidential_included` |
| `google/status` | `telemetry.counters.token_requests` | `telemetry.counters.auth_requests` |
| `google/status` | `quota_observations.observations[].observations.tokensPerDay` | `quota_observations.observations[].observations.quota_units_per_day` |
| `google/status` | `quota_observations.observations[].observations.tokensPerHour` | `quota_observations.observations[].observations.quota_units_per_hour` |
| `google/status` | `quota_observations.observations[].observations.tokensPerProjectPerHour` | `quota_observations.observations[].observations.quota_units_per_project_per_hour` |
| `google/status` | `quota_observations.observations[].observations.concurrentRequests` | `quota_observations.observations[].observations.concurrent_requests` |
| `google/status` | `quota_observations.observations[].observations.serverErrorsPerProjectPerHour` | `quota_observations.observations[].observations.server_errors_per_project_per_hour` |
| `google/status` | `quota_observations.observations[].observations.potentiallyThresholdedRequestsPerHour` | `quota_observations.observations[].observations.potentially_thresholded_requests_per_hour` |
| `ga/send-event` com `debug:true` | `credential_validated` | `access_validated` |
| `ga/send-event` com `debug:false` | `secret_persisted` | `confidential_persisted` |
| `ga/create-mp-secret` | `secret_persisted` | `confidential_persisted` |
| `google/plan-template` | `credentials_promoted` | `confidential_promoted` |
| `google/cleanup-jobs` com `dry_run:true` | `max_records_per_pass` | `max_records_per_run` |
| `ads/search`, `ads/get-campaign`, `ads/list-conversion-actions`, `ads/list-assets`, `ads/list-audiences`, `ads/list-users`, `ads/list-experiments` | `next_page_token` | `next_page` |
| `ga/list-users` | `next_page_token` (texto vazio sem próxima página) | `next_page` (`null` sem próxima página) |
| `ga/get-settings` | `truncated_sections.<seção>.next_page_token` | `truncated_sections.<seção>.next_page` |
| `siteverification/get-token` | `token` (repetido em `data.token`) | `verification_value` (`data` sai sem `token`) |
<!-- /campos-renomeados -->

Nas observações de cota, cada chave nova traz `google_field` com o nome original do Google (`tokensPerDay` etc.). O contador de telemetria lê as horas gravadas antes da troca com o nome novo. Nas listagens do Ads e do GA Admin, o parâmetro de entrada continua `page_token`: envie nele o valor de `next_page`. Aditivo: `google/execute-read` acrescenta `next_page` quando a resposta do Google traz `nextPageToken` no nível superior de `data` (mesmo valor; `data` não muda; para a página seguinte, envie-o em `query.pageToken`).

Campos que continuam mascarados pelo transporte, sem segredo envolvido, estão em `AGENT-GUIDE.md`, seção "O que o transporte MCP mascara".

## Entrada e autorização

Os objetos de entrada são fechados (`additionalProperties:false`). `connection_id` seleciona a conexão; a omissão usa `default` ou a conexão do job em execução. Não há fallback para outra identidade quando um recurso é recusado.

A execução confere canal, capacidade WordPress, conexão, serviço, credencial, escopos e política de recursos. Administradores podem usar os formulários locais permitidos com o canal fechado; essa exceção não reabre chamadas MCP. Credenciais não são gravadas por `options/update` nem devolvidas.

`google/execute-read` admite somente métodos classificados como leitura; relatórios e URL Inspection usam POST de leitura. Métodos do Discovery sem classificação aprovada são recusados. Seletores curinga são recusados em escritas (`f3_google_write_wildcard`). `google/execute-action` segue as mesmas regras.

`mode` e as anotações MCP descrevem a ferramenta. `remote_effect` distingue consulta, mutação remota e operação local; `local_effect` indica mutação local. Cache e auditoria incidental não transformam consulta em mutação. `available` no catálogo avalia configuração local (`resource_access_verified:false`).

## Envelope e resultado

Sucesso: `success:true`, `message` e os campos da habilidade. Falha: `success:false`, `message`, `error_code` e `details` (status HTTP, motivo do Google, URL sem query, erros do Google e campos seguros, ou `null`). Quando presentes em `details`, `operation_outcome`, `retryable` e `request_id` também sobem para o nível superior. O adaptador MCP sinaliza `isError:true`. Não deduza o resultado do texto.

| `operation_outcome` | Interpretação |
|---|---|
| `not_applicable` | Consulta sem mutação remota |
| `not_applied` | Nenhuma mutação desta intenção aplicada |
| `applied` | Efeito confirmado pela resposta ou validação |
| `partial` | Algumas etapas aplicadas; consultar resultados por etapa |
| `unknown` | Resultado remoto incerto; conferir o destino antes de nova intenção |

Em `unknown` e `partial`, `retryable` é `false`. A admissão de um job não comprova aplicação remota: consulte `job_outcomes` ou o resultado da execução. Resposta HTTP bem-sucedida não comprova indexação pelo Google nem entrega de e-mail.

## Autoteste diagnóstico

`google/selftest` sem parâmetros usa `live:false`, sem HTTP Google. `live:true` acrescenta leituras dos serviços e recursos habilitados.

| Resultado | success | execution_success | complete | checks_passed | all_checks_passed | Código |
|---|---|---|---|---|---|---|
| `passed` | true | true | true | true | true | ausente |
| `incomplete`, com não configurada | true | true | false | false | false | ausente |
| `incomplete`, somente puladas/aprovadas | true | true | false | true | false | ausente |
| `failed`, sem puladas/não configuradas | false | true | true | false | false | `f3_google_selftest_failed` |
| `failed`, também com pendências | false | true | false | false | false | `f3_google_selftest_failed` |
| `execution_error` | false | false | false | false | false | causa de execução |

Aprovação integral exige `all_checks_passed:true`; `complete` mede cobertura. Contadores `passed`, `failed`, `skipped`, `not_configured` correspondem ao vetor `checks` (`name`, `status`, `ok`, `detail`). Segredo existente ilegível é reprovação. Para uma nova conexão Ads, declare o nível de acesso do projeto Cloud. `data_manager` descreve os requisitos da entrega de conversões Google Ads: `identity_requirement`, `scope`, `api`, `developer_access`, `action`, `verification`, `core_reconciliation_available`.

## Persistência e configuração

Gravações de opção retornam `success`, `persisted`, `changed`, código e mensagem; a confirmação relê o banco. Valor equivalente já gravado retorna sucesso sem mudança. Segredos são cifrados antes da persistência; falhas de leitura, cifra, escrita, verificação e compensação têm códigos distintos. `expected_revision` recusa formulários e planos obsoletos.

`google/configuration-schema` diferencia valor persistido, efetivo e padrão. Para opções confidenciais (`confidential:true`) informa somente presença e legibilidade; falha de leitura não vira ausência. Opções booleanas devolvem `true`/`false` em `state.effective_value`. `access_requirements` descreve a capacidade exigida, a capacidade adicional e a exigência de canal aberto; `runtime_prerequisites.authentication` descreve os modos de autenticação. Credenciais candidatas têm opções cifradas próprias e só são promovidas depois de validar autenticação e recursos vinculados; falha preserva a ativa.

### Seleção de serviços (configuração 4.0.0)

`google/plan-configuration` e `google/configure {"dry_run":true}` calculam o mesmo plano: `configuration_contract_version`, `configuration_revision`, `plan_hash`, `would_change`, `services_before`, `services_after`, `service_changes`, `confirmation_required`.

| Entrada | Semântica |
|---|---|
| `services` omitido | Preserva seleção e flags |
| `services:{...}` | Substitui a seleção completa; omitidos ficam desligados |
| `services:{...}, merge:true` | Mescla os informados e preserva os demais |
| `services:{}, merge:true` | Sem efeito |
| `services:{}` sem merge | Desativa todos; exige confirmação se houver redução efetiva |
| `services:null`, nível ou serviço desconhecido, booleano textual | Erro, sem conversão |
| `merge:true` sem `services` | Erro de entrada |

Desativações e reduções exigem `confirm_service_reduction:true`, `expected_revision` e `expected_plan_hash`; sem eles a requisição é recusada com `f3_google_service_reduction_confirmation_required`, `persisted:false`, `operation_outcome:not_applied`. Mudança de contexto retorna `f3_google_configuration_conflict`. Este fluxo não usa `confirmation_token`. `google/configure` é habilidade de escrita mesmo em simulação; `dry_run:true` com `persisted:false` não significa aplicação.

## Confirmação de operações sensíveis

`google/prepare-operation {"ability","parameters"}` executa a preparação capturando localmente os pedidos de mutação, sem enviá-los. Devolve `confirmation_token` opaco de uso único, `expires_at` (600 s), `effects` e `remote_writes_performed:false`. Não atesta aprovação humana nem equivale a `validateOnly` remoto.

O token vincula ator, site, conexão, identidade, revisão, habilidade, parâmetros e pedidos capturados. A execução reconsulta o estado, compara a intenção, consome o token sob trava e registra a tentativa antes do transporte. Token ausente, expirado, reutilizado ou de outro contexto: `f3_google_confirmation_required`, sem escrita.

Exigem confirmação: exclusões, remoções, arquivamentos, revogações, alterações de acesso, usuários e proprietários, retenção de dados, Google Signals, lotes com mais de um alvo, `google/export-to-sheet` em `append` e `google/disconnect` com `revoke`. As habilidades do acervo Ads (`ads/archive-*`) não exigem.

Quando uma criação retorna um ID, a continuação fixa os pedidos concretos antes de enviar e restringe a autorização ao recurso criado. Falha posterior retorna as etapas confirmadas e resultado `partial` ou `unknown`, sem rollback remoto.

## Fila, agendas e retenção

Jobs (`google/create-job`, tarefas `inspect-urls`, `query`, `export`, `sitemap`, `report`, `preflight`) congelam recursos, parâmetros e datas na admissão. `idempotency_key` (até 200 caracteres) é vinculada a conexão, ator e intenção: a mesma chave com a mesma intenção devolve o job existente com `created:false`; intenção diferente retorna `f3_google_job_key_conflict`.

O worker compartilha prazo de 20 s, reserva de 2 s para persistência e teto de 25 itens entre MCP, cron e CLI. Resultado e cursor são gravados juntos com proprietário, geração e lease. Leitura abandonada pode retomar; escrita despachada sem resultado fica `unknown` e não é repetida. Não há execução remota exatamente uma vez.

`inspect-urls`: 1–500 URLs; `auto` processa até cinco na chamada quando há orçamento. Exportações entram em `approval_required`: `google/prepare-job` e `google/approve-job` delegam a intenção. `get-job` pagina resultados; cancelamento preserva etapas concluídas; reconciliação exige evidência e não repete a escrita.

Agendas (`google/schedule-report`) aceitam `report`, `query` e `preflight`, intervalo de 3.600 a 2.592.000 s. Atualização exige a revisão de `google/get-schedule`. Ocorrências atrasadas são coalescidas em uma por passagem.

Retenção (`google/configure-local`): `job_detail_days` 0–365, `job_summary_days` 0–730, `audit_retention` 0–5.000 eventos; `0` significa sem prazo e é o padrão. Resumo positivo deve ser maior ou igual ao detalhe positivo. A limpeza tem prévia por padrão, remove até 100 itens por passagem e preserva ativos, resultados desconhecidos e deduplicação necessária.

## Política e portabilidade

Conexões novas começam restritas; defaults não concedem autorização. A política verifica alvos, pais, recursos relacionados e destinatários de compartilhamento. `google/plan-policy` calcula o impacto e devolve revisão e hash; `google/configure-policy` exige ambos. Modelos portáteis exportam serviços, vínculos, limites e política; credenciais, identidades, destinatários e preferências de alerta não são exportados (`confidential_included:false`).

## Auditoria e alertas

Falha de gravação do log não altera um efeito remoto conhecido: a chamada recebe `audit_warning`, o status expõe `audit_health` e a janela de auditoria fica `complete:false`. Gravação de configuração alterada devolve `revision`, `configuration_change_id` e `audit_marker`. `google/audit` aceita filtros (`consumer_id`, `run_id`, `request_id`) e `desde_revisao`; marcador ambíguo retorna `f3_google_audit_revision_ambiguous`; ausente ou expurgado, `f3_google_audit_revision_unavailable`. Exportação JSON/CSV entrega bytes com tamanho e hash; CSV neutraliza fórmulas.

Alertas são opcionais, por conexão, com até dez destinatários e intervalo de 60 a 604.800 s. Eventos: `access`, `cron_late`, `sitemap_error`, `scheduled_check`. Crash depois de iniciar envio deixa estado incerto e não reenvia.

## GTM

`gtm/publicar {path,simular:true}` lê workspace, conflitos e versão publicada sem escrita e devolve `expected_fingerprint`. Aplicar exige `simular:false` e o mesmo fingerprint. `gtm/reverter` usa o mesmo protocolo. O resultado preserva `new_workspace_path`, `previous_version_id`, `new_version_id`, `publication_id` e `operation_outcome`; `unknown` impede reenvio automático. `gtm/get-publication` consulta o diário. A API não oferece troca atômica da versão publicada.

## Cron e executor

`google/status.cron` e `google/executar-vencidos` usam o mesmo diário por conexão. `cron.last_run` é a última passagem do executor; `ultima_cli`, `ultima_http` e `ultima_manual` são independentes por origem. Cada passagem tem `at`, `finished_at`, `run_id`, `origem`, `scope`, `connection_id`, `connection_examined`, `success`, `items`, `jobs`, `schedules`, `alerts`, `state`, `reason_code` e `reason_evidence`.

A origem vem do processo: WP-CLI → `cli`; cron do WordPress → `http_cron`; demais → `manual`. `cron_servidor_ativo` é verdadeiro quando `ultima_cli.at` está nas últimas 7.200 s; então `executor:server-cron`, senão `wp-cron`. Não comprova crontab instalado.

`google/executar-vencidos` publica `run` (passagem desta chamada, com `results` por conexão), `history_status` (`confirmed`, `pending`, `unconfirmed`), `work_success`, `execution_success`, `observability_error`, `maintenance` e `maintenance_success`, `executor_repair` e `executor_schedule_success`. Cessão normal: `state:"yielded"`, `success:true`, zero itens e `connection_examined:false`. Falha de histórico ou manutenção não autoriza repetir trabalho remoto.

`cron.health` é `degraded` quando há erro ativo de agenda ou a leitura da agenda falhou; nos demais casos é igual a `work_health` (`idle`, `due`, `blocked`). O status compacto (`google/status {"compact":true}`) traz `health`, `work_health`, `scheduling_active_errors` (inteiro) e `incidents_open` (inteiro, ou `null` quando a leitura local falhou), sem consulta ao Google.

### Agenda (`cron.scheduling` 2.0.0)

`checks.executor` prova a presença de uma única ocorrência de `f3_mcp_google_jobs_tick`, recorrência `f3_google_minute`, intervalo 60, argumentos vazios: `state` `present`, `missing`, `invalid`, `inactive` ou `unknown`, com `next_run`, `reason_code`, `repair_allowed` e `repair_blocked_by`. Consulta não cria nem repara evento.

Cada observação de agenda tem `state`: `confirmed` (pós-condição comprovada), `failed` ou `unconfirmed`. Recusa `duplicate_event` de evento único com evento equivalente (mesmo gancho e argumentos) dentro da janela de duplicidade de 600 s do WordPress é pós-condição atendida: `confirmed`, `original_code:"duplicate_event"` e `equivalent_at` com o horário do evento equivalente. Erros ativos antigos desse tipo são resolvidos pela manutenção com `resolved_by:"duplicate_event_equivalent"`. Demais falhas permanecem em `active_errors` até prova e mantêm `health:"degraded"`. Detalhes e procedimento: `ACOMPANHAMENTO-CRON.md`.

## Armazenamento e manutenção

Tabelas: `{prefix}f3_google_records` (repositório indexado) e `{prefix}f3_google_cron` (passagens e incidentes; retenção de 8 dias, até 20.000 passagens e 1.000 incidentes por conexão). `google/storage-status.storage` publica `storage_contract_version`, `ready`, `state` (`ready`, `unavailable`), `tables` e `error_code`. Tabelas indisponíveis recusam trabalho com `f3_google_storage_unavailable`. `google/maintenance` pode recriar tabela ausente; estrutura incompatível retorna `f3_google_cron_storage_schema_invalid`.

`f3_mcp_google_maintenance` executa manutenção local horária; lotes pendentes pedem nova passagem em 15 s, exceto quando a próxima ocorrência já está dentro da janela de duplicidade do WordPress. `google/maintenance` avança a manutenção explicitamente.

| Campo de manutenção | Semântica |
|---|---|
| `maintenance_contract_version` | `2.0.0` |
| `state` | `complete`, `pending` ou `failed` da última observação |
| `success` / `execution_success` | Resultado da passagem local; não é resultado remoto |
| `read_success` | A projeção foi lida; falha não vira zero |
| `inventory_complete` / `remaining` | Conclusão exige todas as famílias completas na mesma passagem |
| `progress` | Por família: `cursor`, `connection_id`, `at`, `complete`, `read_success`, `error_code`, `examined_in_run` |
| `pending_counts` | Zero só para família confirmada concluída; `null` se desconhecida |
| `budget` | `row_limit:100`, `time_limit_ms:1000`, `processed`, `duration_ms`, `stop_reason` |
| `observed_at` / `observation_age_seconds` | Instante da consulta e idade da amostra |
| `blocked_by` | Causa corrente da guarda ou bloqueio da última passagem |
| `next_run` / `advance_operation` | Próximo evento observado; operação manual `google/maintenance` |

Famílias: `cron_retention`, `cache_sql`, `cache_files`. A manutenção também reconfere até 20 erros de agenda por passagem.

Cache: SQL até 100.000 bytes serializados; arquivos cifrados em `wp-content/f3-google-cache/` (64 arquivos, 16 MiB cada, 64 MiB por site, validade até 24 h). Cache corrompido ou expirado é ausência.

## Recuperação

`google/recovery-status` é consulta local. `google/recovery {action:"prepare"}` pausa e aguarda drenagem; `ready_for_restore:true` libera a restauração. `action:"resume"` exige `expected_generation` atual e `acknowledge_reconciled:true`. A sentinela fica em `wp-content/f3-google-state/site-{blog_id}.php`; não restaure uma cópia antiga sobre a pausa atual. Procedimento em `MIGRACAO.md`.

## Prontidão (`google-readiness/1.0.0`)

`google/readiness-status` é leitura local. Entrada: `hours_ahead` 1–48 (padrão 6) e `connection_id`. Saída: `contract`, `state` (`ready`, `attention`, `blocked`), `connection_id`, `plugin_version`, `observed_at`, `hours_ahead`, `google_checks_performed:false`, `checks[]`, `actions[]`. Cada check tem `id`, `state` (`ok`, `attention`, `blocked`, `not_configured`), `code`, `action` e `detail` opcional. Ordem: `credential`, `storage`, `recovery`, `executor`, `conversion_ga4`, `conversion_google_ads`, `incidents`, `core`. O check `executor` traz em `detail`: `schedule_state`, `next_run`, `last_run_at`, `last_run_age_seconds`, `server_cron`.

## Integração com o Fator3 MCP

As habilidades-ponte `google/mcp-read` e `google/mcp-write` (ferramentas MCP `google-mcp-read` e `google-mcp-write`) são registradas pelo SDK `server-integration/1.0.0` e pelo contrato `executor-registration/1.0.0` do Fator3 MCP; declaram `executes_ability:true` e não substituem a autorização do alvo. O Fator3 MCP pode acrescentar metadados e campos próprios ao registro; o contrato executável publicado pelo MCP prevalece para esses campos. `mcp_server` em `google/status` informa o registro local (`sdk_unavailable`, `sdk_incompatible`, `disabled`, `not_observed`, `not_ready`, `registered`, `error`), sem provar transporte externo.

## Atualização

O atualizador usa somente origem configurada por administrador (`google/configure-update-origin`). Valida HTTPS em cada salto, hosts autorizados, limite de bytes, SHA-256, estrutura, versão e requisitos. O manifesto próprio usa `schema_version:"1.0.0"` com `plugin`, `version`, `package_url`, `sha256`, `requires_php` e `requires_wordpress`. Quando o Fator3 MCP tem canal de distribuição selecionado, seu manifesto tem precedência. ZIP enviado manualmente continua permitido.

## Anúncio de origem no Google Ads

A extensão opcional `google-ads-origin/1.0.0` é descoberta em `capabilities().extensions.origin_ad`. O consumidor autorizado usa `origin_ad` com o identificador do anúncio ou com GCLID e data da conta. Consulte CORE-ACERVOS.md para autorização, campos, exemplos e limites de atribuição.
