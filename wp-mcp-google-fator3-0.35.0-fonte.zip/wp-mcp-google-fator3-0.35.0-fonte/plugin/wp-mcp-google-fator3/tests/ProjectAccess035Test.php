<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Ads\AdsApi,Ads\PlannerAccess,Automation\Alerts,Connections,Options,Settings};
use PHPUnit\Framework\TestCase;

final class ProjectAccess035Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;
        $GLOBALS['f3_test_user']=1;
        Connections::select('default');
        Options::set(Options::AUTH_MODE,'oauth');
        Options::set(Options::OAUTH_CLIENT_ID,'100-client');
    }

    public function test_project_change_requires_a_new_declaration(): void {
        Options::set(PlannerAccess::OPTION,['scope'=>PlannerAccess::scope(),'level'=>'basic']);
        $this->assertTrue(PlannerAccess::project_access());
        Options::set(Options::OAUTH_CLIENT_ID,'200-client');
        $this->assertFalse(PlannerAccess::project_access());
    }

    public function test_legacy_continuity_does_not_assign_a_planner_tier(): void {
        Options::set(PlannerAccess::OPTION,['scope'=>PlannerAccess::scope(),'level'=>'unknown','legacy_access'=>true]);
        $this->assertTrue(PlannerAccess::project_access());
        $this->assertSame('unknown',PlannerAccess::level());
        Options::set(Options::OAUTH_CLIENT_ID,'200-other');
        $this->assertFalse(PlannerAccess::project_access());
    }

    public function test_saved_legacy_token_does_not_leave_in_headers(): void {
        Options::set_secret(Options::ADS_DEVELOPER_TOKEN,'private-fixture');
        $this->assertSame(['login-customer-id'=>'1234567890'],AdsApi::headers('123-456-7890'));
        $this->assertSame([],AdsApi::headers());
    }

    public function test_webhook_requires_slack_and_a_current_revision(): void {
        $revision=Settings::revision();
        $bad=Alerts::save_slack('https://example.invalid/services/synthetic',false,$revision);
        $this->assertFalse($bad['success']);
        $this->assertSame($revision,Settings::revision());
        $this->assertFalse(Alerts::save_slack('https://hooks.slack.com/services/T/B/X',false,null)['success']);
        $this->assertFalse(Options::has_secret(Options::INCIDENT_WEBHOOK));
    }
}
