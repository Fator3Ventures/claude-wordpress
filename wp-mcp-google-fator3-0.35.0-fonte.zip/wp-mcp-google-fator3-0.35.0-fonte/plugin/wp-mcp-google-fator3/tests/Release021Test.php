<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,ConversionDelivery as D,Configuration,Audit,Records,Plugin};
use Fator3\McpGoogle\Ads\{EnhancedLeads,DataManager};
final class Release021Test extends TestCase {
 protected function setUp():void {
  $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
  $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;$GLOBALS['f3_test_user_caps']=[];FakeHttp::reset();
  foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $p)unlink($p);
  O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ads'=>'write','ga'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],
   [O::OAUTH_CLIENT_SECRET=>'fixture-secret',O::OAUTH_REFRESH_TOKEN=>'fixture-refresh',O::ADS_DEVELOPER_TOKEN=>'fixture-dev']); \Fator3\McpGoogle\Options::set(\Fator3\McpGoogle\Ads\PlannerAccess::OPTION,['scope'=>\Fator3\McpGoogle\Ads\PlannerAccess::scope(),'level'=>'basic']);
  Plugin::register_abilities();
 }
 private function ready(bool $enhanced=true):D {
  $c=array_replace(D::defaults(),['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/123','granted_by_target'=>['google_ads'=>1]]);
  $method=new \ReflectionMethod(D::class,'proof_revision');$method->setAccessible(true);
  $c['verified']['google_ads']=['revision'=>$method->invoke(null,$c,'google_ads'),'by'=>1,'at'=>time()-30,'expires'=>time()+3600,'value'=>0,'currency'=>'BRL','enhanced_leads'=>['customer_id'=>$c['customer_id'],'conversion_action'=>$c['conversion_action'],'ready'=>$enhanced,'accepted_customer_data_terms'=>$enhanced,'enabled'=>$enhanced,'reason'=>$enhanced?'ok':'enhanced_leads_disabled','checked_at'=>time()-30]];
  O::set(D::CONFIG,$c);return new D('google_ads');
 }
 private function payload(array $changes=[]):array {
  return array_replace(['record_id'=>str_repeat('a',32),'event_id'=>str_repeat('a',32),'order_id'=>str_repeat('a',32),'occurred_at'=>gmdate('c',time()-60),'click_ids'=>[],'ad_user_data'=>'GRANTED','user_data'=>['email'=>' First.Last@Gmail.com ','telefone'=>'+55 (11) 99999-9999']],$changes);
 }
 private function sendResponse():void {
  FakeHttp::push('/token',200,['access_token'=>'test-access','expires_in'=>3600]);
  FakeHttp::push('/events:ingest',200,['requestId'=>'test-request']);
 }
 public function test_hashes_and_data_manager_mapping():void {
  $ids=EnhancedLeads::normalize(['email'=>' First.Last@Gmail.com ','telefone'=>'+55 (11) 99999-9999']);
  $this->assertSame([['hashedEmail'=>hash('sha256','firstlast@gmail.com')],['hashedPhoneNumber'=>hash('sha256','+5511999999999')]],$ids);
  $this->assertSame(['userIdentifiers'=>[['emailAddress'=>hash('sha256','firstlast@gmail.com')],['phoneNumber'=>hash('sha256','+5511999999999')]]],EnhancedLeads::data_manager($ids));
 }
 /** @dataProvider invalidUsers */
 public function test_invalid_personal_data_is_refused_without_http($user):void {
  $a=$this->ready();$r=$a->send($this->payload(['user_data'=>$user]));
  $this->assertSame('enhanced_leads_user_data_invalid',$r['code']);$this->assertTrue($r['non_delivery_proven']);$this->assertSame([],FakeHttp::$requests);
 }
 public static function invalidUsers():array{return [[null],[[]],[['email'=>'bad']],[['telefone'=>'11999999999']],[['email'=>[]]],[['email'=>'a@example.test','hash'=>'bad']],[['email'=>str_repeat('a',300)]],[['email'=>'  ','telefone'=>'']]];}
 /** @dataProvider clickVariants */
 public function test_enhanced_send_preserves_receipt_without_persisting_personal_data(array $click):void {
  $a=$this->ready();$this->sendResponse();$p=$this->payload(['click_ids'=>$click]);$r=$a->sendBound($p,$a->capabilities()['destination_ref']);
  $this->assertSame('incerto',$r['status']);$this->assertSame('data_manager_pending',$r['code']);
  $body=json_decode(FakeHttp::last()['body'],true);$this->assertSame('HEX',$body['encoding']);$event=$body['events'][0];
  $this->assertSame(EnhancedLeads::data_manager(EnhancedLeads::normalize($p['user_data'])),$event['userData']);
  $this->assertSame('CONSENT_GRANTED',$event['consent']['adUserData']);$this->assertSame($p['record_id'],$event['transactionId']);
  $this->assertSame($click,$event['adIdentifiers']??[]);
  $stored=wp_json_encode([$GLOBALS['f3_test_options'],Records::list('conversion',100),Audit::recent(100)]);
  foreach(['First.Last','firstlast@gmail.com','5511999999999',hash('sha256','firstlast@gmail.com'),hash('sha256','+5511999999999')] as $s)$this->assertStringNotContainsString($s,$stored);
  $n=count(FakeHttp::$requests);$this->assertSame($r,$a->send($p));$this->assertCount($n,FakeHttp::$requests);
 }
 public static function clickVariants():array{return [[[]],[['gclid'=>'test-click']],[['gbraid'=>'test-braid']],[['wbraid'=>'test-wbraid']]];}
 public function test_not_ready_and_consent_fail_closed():void {
  $a=$this->ready(false);$r=$a->send($this->payload());$this->assertSame('enhanced_leads_not_ready',$r['code']);$this->assertTrue($r['non_delivery_proven']);
  $r=$a->send($this->payload(['ad_user_data'=>'DENIED']));$this->assertSame('ads_payload_invalid',$r['code']);
  $r=$a->send($this->payload(['click_ids'=>['gclid'=>'a','wbraid'=>'b']]));$this->assertSame('ambiguous_click_identifiers',$r['code']);$this->assertSame([],FakeHttp::$requests);
 }
 public function test_legacy_click_and_contract_negotiation_remain_compatible():void {
  $a=$this->ready(false);$p=$this->payload(['click_ids'=>['gclid'=>'test-click']]);unset($p['user_data']);$this->sendResponse();
  $this->assertSame('data_manager_pending',$a->send($p)['code']);$body=json_decode(FakeHttp::last()['body'],true);$this->assertArrayNotHasKey('userData',$body['events'][0]);$this->assertArrayNotHasKey('encoding',$body);
  foreach([D::LEGACY_CONTRACT,D::CONTRACT] as $version){$adapter=D::adapter(null,'google_ads',$version);$this->assertSame($version,$adapter->capabilities()['contract']);$this->assertContains(D::CONTRACT,$adapter->capabilities()['supported_contracts']);}
  $this->assertNull(D::adapter(null,'google_ads','site-conversion-delivery/2.0.0'));
 }
 public function test_capabilities_local_expiry_and_permission():void {
  $a=$this->ready();$this->assertTrue($a->capabilities()['enhanced_leads']['ready']);
  $c=O::get(D::CONFIG);$c['verified']['google_ads']['expires']=time()-1;O::set(D::CONFIG,$c);
  $this->assertFalse($a->capabilities()['enhanced_leads']['ready']);$this->assertSame('verification_required',$a->capabilities()['enhanced_leads']['reason']);
  $a=$this->ready();$GLOBALS['f3_test_user_caps'][1]=false;
  $this->assertFalse($a->capabilities()['enhanced_leads']['ready']);$this->assertSame([],FakeHttp::$requests);
 }
 /** @dataProvider customerFlags */
 public function test_account_readiness_is_fail_closed($terms,$enabled,string $reason):void {
  $this->ready();FakeHttp::push('/token',200,['access_token'=>'test-access','expires_in'=>3600]);
  FakeHttp::push('googleAds:search',200,['results'=>[['customer'=>['id'=>'1234567890','conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>$terms,'enhancedConversionsForLeadsEnabled'=>$enabled]]]]]);
  $r=EnhancedLeads::observe(O::get(D::CONFIG));$this->assertSame($reason,$r['reason']);$this->assertSame($reason==='ok',$r['ready']);
 }
 public static function customerFlags():array{return [[true,true,'ok'],[false,true,'customer_data_terms_not_accepted'],[true,false,'enhanced_leads_disabled'],['true',true,'enhanced_leads_unverified']];}
 public function test_compact_three_fields_match_full_under_two_kilobytes():void {
  O::set(O::AUDIT_RETENTION,0);$full=Configuration::read();$fields=['audit_retention','job_detail_days','job_summary_days'];
  $r=wp_get_ability('google/configuration-schema')->execute(['compact'=>true,'fields'=>$fields]);$this->assertTrue($r['success'],wp_json_encode($r));$this->assertLessThan(2048,strlen(wp_json_encode($r)));
  foreach($fields as $id)$this->assertSame($full['options'][$id]['state']['effective_value'],$r['options'][$id]['value']);
  $this->assertCount(3,$r['options']);$this->assertSame([],FakeHttp::$requests);
  $bad=Configuration::read(['compact'=>true,'fields'=>['unknown']]);$this->assertSame('f3_google_configuration_fields',$bad['error_code']);
 }
 public function test_compact_secrets_and_values_omission():void {
  $r=Configuration::read(['compact'=>true,'fields'=>['oauth_refresh_token']]);$this->assertSame('[redigido]',$r['options']['oauth_refresh_token']['value']);
  $r=Configuration::read(['compact'=>true,'fields'=>['oauth_refresh_token'],'include_values'=>false]);$this->assertArrayNotHasKey('value',$r['options']['oauth_refresh_token']);
  $this->assertStringNotContainsString('fixture-refresh',wp_json_encode($r));
 }
 public function test_identity_is_from_saved_key_only_and_isolated_by_connection():void {
  O::set_secret(O::SA_JSON,wp_json_encode(['type'=>'service_account','client_email'=>'robot@fixture.iam.gserviceaccount.com','project_id'=>'fixture-project','private_key'=>'private-not-to-return','private_key_id'=>str_repeat('f',40)]));
  C::create('other021','Other');
  $list=wp_get_ability('google/list-connections')->execute([]);$this->assertSame('robot@fixture.iam.gserviceaccount.com',$list['connections'][0]['client_email']);$this->assertSame('fixture-project',$list['connections'][0]['project_id']);$this->assertNull($list['connections'][1]['client_email']);
  foreach([false,true] as $compact){$r=wp_get_ability('google/integration-status')->execute(['compact'=>$compact]);$this->assertSame('fixture-project',$r['project_id']);foreach(['private-not-to-return',str_repeat('f',40),'private_key'] as $bad)$this->assertStringNotContainsString($bad,wp_json_encode($r));}
  $this->assertSame([],FakeHttp::$requests);
 }
 public function test_compact_status_and_administrative_gates():void {
  $this->ready();$full=wp_get_ability('google/status')->execute([]);$small=wp_get_ability('google/status')->execute(['compact'=>true]);
  $this->assertTrue($small['success']);$this->assertLessThan(strlen(wp_json_encode($full)),strlen(wp_json_encode($small)));$this->assertTrue($small['conversion_delivery']['google_ads']['enhanced_leads']['ready']);
  $this->assertSame([],FakeHttp::$requests);$GLOBALS['f3_test_caps']=false;
  foreach(['google/status','google/configuration-schema','google/list-connections','google/integration-status'] as $route)$this->assertNotTrue(wp_get_ability($route)->check_permissions([]));
 }
 public function test_diagnostics_remove_personal_data_hashes_and_secrets():void {
  $r=DataManager::verification_error(new \WP_Error('denied','user@example.test +55 11 999999999 api_secret=hidden Bearer hidden '.str_repeat('a',64),['status'=>403,'details'=>['status'=>'PERMISSION_DENIED']]),'stream_unverified','ga4_stream_read');
  $this->assertSame('ga4_stream_read',$r['provider_error']['phase']);$this->assertSame(403,$r['provider_error']['http_status']);$this->assertSame('PERMISSION_DENIED',$r['provider_error']['status']);
  foreach(['user@example.test','999999999','hidden',str_repeat('a',64)] as $s)$this->assertStringNotContainsString($s,wp_json_encode($r));
  $this->assertSame('[redigido]',Audit::redact(['user_data'=>['email'=>'a@example.test']])['user_data']);
 }
}
