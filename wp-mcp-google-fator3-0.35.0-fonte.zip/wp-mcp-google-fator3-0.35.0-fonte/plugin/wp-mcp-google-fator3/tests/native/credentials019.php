<?php
/** Request 36 against native WordPress, MySQL, the current Core and MCP. Supplier HTTP is synthetic. */
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Settings as S,Connections as C,ConversionDelivery as D,Policy,Records,Admin};
use Fator3\McpGoogle\Auth\{Configuration as A,Validation as V,Credentials,ServiceAccount,Candidate};
use Fator3\McpGoogle\Integration\ServiceApi;
wp_get_abilities();
$connection='credential019';$r=C::create($connection,'Credential QA');verifyLab('request36 isolated connection created',$r['success']);
$calls=[];$tokenCode=200;$adsCode=200;$gscCode=200;$during=null;
$fixture=static function($pre,$args,$url)use(&$calls,&$tokenCode,&$adsCode,&$gscCode,&$during){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $calls[]=parse_url($url,PHP_URL_PATH);$code=200;
 if(str_contains($url,'/token')){$code=$tokenCode;$body=$code===200?['access_token'=>'synthetic019','expires_in'=>3600]:['error'=>'invalid_grant'];}
 elseif(str_contains($url,'listAccessibleCustomers')){$code=$adsCode;$body=$code===200?['resourceNames'=>[]]:['error'=>['status'=>'PERMISSION_DENIED']];}
 elseif(str_contains($url,'/webmasters/')){$code=$gscCode;$body=$code===200?['siteUrl'=>'sc-domain:example.test','permissionLevel'=>'siteOwner']:['error'=>['status'=>'PERMISSION_DENIED']];}
 else return new WP_Error('qa_unexpected_http','Unexpected synthetic URL');
 if($during){$f=$during;$during=null;$f();}
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
$key=static function(string $name,string $hex){$rsa=openssl_pkey_new(['private_key_bits'=>2048]);openssl_pkey_export($rsa,$pem);return wp_json_encode(['type'=>'service_account','project_id'=>'synthetic','private_key_id'=>str_repeat($hex,40),'private_key'=>$pem,'client_email'=>$name.'@synthetic.iam.gserviceaccount.com','client_id'=>$name==='robot'?'12345':'67890','token_uri'=>ServiceAccount::DEFAULT_TOKEN_URI]);};
$a=$key('robot','a');$b=$key('robot','b');$other=$key('other','c');
try{C::run($connection,static function()use($a,$b,$other,&$tokenCode,&$adsCode,&$gscCode,&$calls,&$during){
 O::batch_verified([O::ENABLED=>true,O::AUTH_MODE=>'service_account',O::GA_ENABLED=>true,O::ADS_ENABLED=>true,C::SERVICES=>['ga'=>'write','ads'=>'write','gsc'=>'read'],C::BINDINGS=>['gsc_site_url'=>'sc-domain:example.test'],Policy::OPTION=>['mode'=>'identity','services'=>[]]],[O::SA_JSON=>$a,O::ADS_DEVELOPER_TOKEN=>str_repeat('a',22),D::SECRET=>'synthetic019-mp']);
 O::set(\Fator3\McpGoogle\Ads\PlannerAccess::OPTION,['level'=>'basic','scope'=>\Fator3\McpGoogle\Ads\PlannerAccess::scope()]);
 $revision=S::revision();
 foreach(['web','installed'] as $type){$r=A::import(wp_json_encode([$type=>[]]),'service_account',true,$revision);verifyLab('Wrong JSON '.$type.' preserves active key',empty($r['success'])&&O::get_secret(O::SA_JSON)===$a&&S::revision()===$revision&&str_contains($r['message'],'A chave salva continua em uso.'));}
 $count=count($calls);$invalid=json_decode($b,true);$invalid['private_key']='unreadable';$r=A::save_sa(wp_json_encode($invalid),'',true,$revision);verifyLab('Unreadable key never dispatches HTTP',!$r['success']&&count($calls)===$count&&S::revision()===$revision);
 Credentials::current()->get_access_token(Credentials::scopes_for('any'));$tokenCode=400;$count=count($calls);$r=A::save_sa($b,'',true,$revision);
 verifyLab('Revoked key is rechecked despite old cached token',!$r['success']&&str_contains($r['message'],'invalid_grant')&&count($calls)===$count+1);
 verifyLab('Rejected key creates no candidate and preserves ciphertext',O::get_secret(O::SA_JSON)===$a&&Candidate::read('service_account')===null&&S::revision()===$revision);$tokenCode=200;
 $client=ServiceApi::register_consumer('qa-credential019','1.0.0',ServiceApi::CONTRACT,static fn()=>['property'=>'sc-domain:example.test','revision'=>'qa019','ready'=>true]);
 $grant=ServiceApi::configure(['consumer_id'=>'qa-credential019','enabled'=>true,'expected_revision'=>S::revision()]);verifyLab('Consumer grant established through public writer',$grant['success']);
 $consumerBefore=$client->effective_status();verifyLab('Consumer is ready before rotation',($consumerBefore['resolution']??'')==='resolved'&&empty($consumerBefore['reason_codes']),$consumerBefore);
 $c=D::defaults()+['granted_by'=>1];$c['enabled']=true;$c['stream']='properties/123/dataStreams/456';$c['customer_id']='1234567890';$c['conversion_action']='customers/1234567890/conversionActions/789';
 if(class_exists('Fator3\\McpGoogle\\CoreContext')&&defined('F3BASE_PLUGIN_VERSAO'))update_option('f3base_ga4_measurement_id','G-QA019');$c['measurement_id']=D::measurement_id();
 $proof=new ReflectionMethod(D::class,'proof_revision');$proof->setAccessible(true);
 foreach(['ga4','google_ads'] as $target)$c['verified'][$target]=['revision'=>$proof->invoke(null,$c,$target),'at'=>time()-300,'expires'=>time()+3600,'by'=>1,'eligibility_source'=>$target==='ga4'?'admin_api_secret_match_and_debug':'data_manager_validate_only_and_action_read','value'=>0,'currency'=>'BRL'];
 O::set(D::CONFIG,$c);$caps=[];foreach(['ga4','google_ads'] as $target)$caps[$target]=(new D($target))->capabilities();
 Records::put('job','credential019-paused',['id'=>'credential019-paused','connection_id'=>C::id(),'status'=>'blocked','task'=>'preflight','cursor'=>8,'created_at'=>time(),'updated_at'=>time(),'expires_at'=>time()+86400]);
 $job=Records::get('job','credential019-paused');$grantBefore=O::stored(O::storage_name(ServiceApi::GRANTS));$exec=S::execution_revision();$r=A::save_sa($b,'',true,S::revision());
 verifyLab('Validated key rotation succeeds',$r['success']&&$r['rotation'],$r);
 verifyLab('Same principal keeps queued execution revision',$exec===S::execution_revision());
 verifyLab('Grant bytes and grant revision preserved',$grantBefore===O::stored(O::storage_name(ServiceApi::GRANTS)));
 verifyLab('Consumer remains ready without regrant',($client->effective_status()['resolution']??'')==='resolved'&&empty($client->effective_status()['reason_codes']));
 verifyLab('Paused job and cursor remain byte equivalent',$job===Records::get('job','credential019-paused'));
 $after=O::get(D::CONFIG);foreach(['ga4','google_ads'] as $target){$now=(new D($target))->capabilities();verifyLab('Stable destination and readiness '.$target,$now['destination_ref']===$caps[$target]['destination_ref']&&$now['ready']===$caps[$target]['ready']);verifyLab('Proof rebound without extending date or expiry '.$target,$after['verified'][$target]['revision']===$proof->invoke(null,$c,$target)&&$after['verified'][$target]['at']===$c['verified'][$target]['at']&&$after['verified'][$target]['expires']===$c['verified'][$target]['expires']);}
 $summary=V::summary();verifyLab('Saved summary masks key and records rotation',$summary['key_suffix']==='bbbbbbbb'&&$summary['authentication_at']>0&&count($summary['rotation_history'])===1&&!str_contains(wp_json_encode($summary),'PRIVATE KEY'));
 $revision=S::revision();$during=static fn()=>S::save([O::SA_SUBJECT=>'concurrent@example.test']);$r=A::save_sa($a,'',true,$revision);verifyLab('Concurrent configuration wins during key check',($r['error_code']??'')==='f3_google_configuration_conflict'&&O::get_secret(O::SA_JSON)===$b&&O::get(O::SA_SUBJECT)==='concurrent@example.test');O::set(O::SA_SUBJECT,'');
 $revision=S::revision();$adsCode=403;$r=V::save_ads([],[O::ADS_DEVELOPER_TOKEN=>str_repeat('b',22)],[],$revision);verifyLab('Retired token submission keeps the historical value and revision',$r['success']&&S::revision()===$revision&&O::get_secret(O::ADS_DEVELOPER_TOKEN)===str_repeat('a',22));$adsCode=200;
 $r=V::save_ads([O::ADS_LOGIN_CUSTOMER_ID=>'123-456-7890'],[O::ADS_DEVELOPER_TOKEN=>str_repeat('b',22)],[],S::revision());verifyLab('MCC is normalized without issuing a token receipt',$r['success']&&O::get(O::ADS_LOGIN_CUSTOMER_ID)==='1234567890'&&!isset(V::summary()['developer_token_accepted_at']));
 $revision=S::revision();$r=A::save_sa($other,'',true,$revision);verifyLab('Other identity cannot activate through normal save',($r['error_code']??'')==='f3_google_identity_change_required'&&O::get_secret(O::SA_JSON)===$b&&S::revision()===$revision);
 $r=A::save_sa($other,'',false,$revision);verifyLab('Verified other identity prepares only',$r['success']&&$r['identity_change_required']&&O::get_secret(O::SA_JSON)===$b);
 $revision=S::revision();$gscCode=403;$plan=A::plan_identity_change($revision);verifyLab('Simulation lists denied resource without switching',$plan['success']&&!$plan['can_switch']&&$plan['preflight']['checks'][0]['status']==='failed'&&O::get_secret(O::SA_JSON)===$b);$gscCode=200;
 $plan=A::plan_identity_change($revision);verifyLab('Simulation succeeds after resource permission',$plan['success']&&$plan['can_switch']);$selection=[O::get(C::SERVICES),O::get(C::BINDINGS)];
 $r=A::switch_identity($revision,str_repeat('0',64));verifyLab('Forged plan rejected',!$r['success']&&O::get_secret(O::SA_JSON)===$b);
 $r=A::switch_identity($revision,$plan['plan_hash']);verifyLab('Confirmed identity change preserves services and resources',$r['success']&&!$r['rotation']&&[O::get(C::SERVICES),O::get(C::BINDINGS)]===$selection&&V::summary()['identity']==='other@synthetic.iam.gserviceaccount.com');
 verifyLab('Different identity invalidates conversion proof',(new D('ga4'))->capabilities()['ready']===false);
 verifyLab('Resource proof displayed with service',V::summary()['resource_access_at']>0&&in_array('gsc',V::summary()['services'],true));
 $r=C::rename('qa019 · synthetic',S::revision());verifyLab('Rename retains ID',$r['success']&&$r['connection_id']==='credential019'&&C::registry()['credential019']['label']==='qa019 · synthetic');
 $_GET=['section'=>'connection','connection_id'=>C::id(),'method'=>'service_account'];$count=count($calls);ob_start();Admin::render();$html=ob_get_clean();
 verifyLab('Retired credential receipt is absent from identity summary',!str_contains($html,'Token de desenvolvedor:'));
 foreach(['Nome da conexão','conta de serviço · projeto','Chave JSON da conta de serviço (Service account key)','Arquivo .json baixado uma única vez','Último acesso comprovado:','Chave: …cccccccc'] as $text)verifyLab('UI help/summary '.$text,str_contains(html_entity_decode($html),$text));
 verifyLab('Opening connection does no supplier HTTP',count($calls)===$count);verifyLab('Rendered HTML contains no secret',!str_contains($html,'PRIVATE KEY')&&!str_contains($html,'synthetic019-mp')&&!str_contains($html,str_repeat('b',22)));
 $_GET['method']='oauth';ob_start();Admin::render();$html=ob_get_clean();foreach(['ID do cliente OAuth (Client ID)','Chave secreta do cliente (Client secret)','Começa com GOCSPX-','Termina em .apps.googleusercontent.com.'] as $text)verifyLab('OAuth visible help '.$text,str_contains(html_entity_decode($html),$text));
 if(class_exists('Fator3\\McpFiles\\ExecutionCoordinator')){
  $method=new ReflectionMethod('Fator3\\McpFiles\\ExecutionCoordinator','transient');$method->setAccessible(true);
  verifyLab('MCP uncertain credential failure is not automatically retried',!$method->invoke(null,V::failure('f3_google_credential_rejected','synthetic')+['retryable'=>true]));
 }
 Records::remove('job','credential019-paused');
});}finally{remove_filter('pre_http_request',$fixture,1);$_GET=[];}
C::run($connection,static function(){Credentials::invalidate_cache();foreach(C::scoped_names() as $name)O::delete($name);});$registry=C::registry();unset($registry[$connection]);O::set(C::REGISTRY,$registry);
$before=C::registry()['default']['label'];$r=C::rename('default · synthetic',S::revision());verifyLab('Default connection can be renamed without new ID',$r['success']&&C::id()==='default'&&C::registry()['default']['label']==='default · synthetic');C::rename($before,S::revision());
$subscriber=wp_create_user('credential019-sub',bin2hex(random_bytes(12)),'qa019@example.invalid');wp_set_current_user($subscriber);$count=count($calls);
verifyLab('Non administrator cannot save credentials',!A::save_sa($a)['success']);verifyLab('Non administrator cannot rename',!C::rename('forbidden','')['success']);verifyLab('Non administrator cannot access summary',V::summary()===[]);verifyLab('Non administrator makes no Google request',count($calls)===$count);wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($subscriber);
finishLab('credentials019',['supplier'=>'intercepted synthetic responses; no real Google credentials','http_checks'=>count($calls)]);
