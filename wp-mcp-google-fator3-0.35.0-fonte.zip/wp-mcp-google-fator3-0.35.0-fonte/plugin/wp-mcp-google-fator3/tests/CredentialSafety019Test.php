<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options,Settings,Connections,ConversionDelivery,Policy,Admin};
use Fator3\McpGoogle\Auth\{Configuration as Auth,Validation,Credentials,Candidate,ServiceAccount};
final class CredentialSafety019Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=$GLOBALS['f3_test_user_caps']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;$_GET=$_POST=$_FILES=[];FakeHttp::reset();
        Options::batch_verified([Options::ENABLED=>true,Options::AUTH_MODE=>'service_account',Connections::SERVICES=>['gsc'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]]);
    }
    protected function tearDown(): void {FakeHttp::reset();$GLOBALS['f3_test_write_fail']=[];$GLOBALS['f3_test_caps']=true;$_GET=$_POST=[];}
    private function key(string $email='robot@synthetic.iam.gserviceaccount.com',string $id='a'): string {
        static $private=[];if(!isset($private[$id])){$k=openssl_pkey_new(['private_key_bits'=>2048]);openssl_pkey_export($k,$private[$id]);}
        return wp_json_encode(['type'=>'service_account','project_id'=>'synthetic','private_key_id'=>str_repeat($id,40),'private_key'=>$private[$id],'client_email'=>$email,'client_id'=>$email==='robot@synthetic.iam.gserviceaccount.com'?'12345':'67890','token_uri'=>ServiceAccount::DEFAULT_TOKEN_URI]);
    }
    private function token(int $code=200): void {FakeHttp::push('/token',$code,$code===200?['access_token'=>'synthetic-token','expires_in'=>3600]:['error'=>'invalid_grant']);}
    private function active(): string {$json=$this->key();Options::set_secret(Options::SA_JSON,$json);return $json;}
    public function test_wrong_type_format_and_revoked_key_leave_active_and_candidate_untouched(): void {
        $old=$this->active();$before=Settings::revision();
        foreach(['web','installed'] as $type){$r=Auth::import(wp_json_encode([$type=>[]]),'service_account',true,$before);$this->assertFalse($r['success']);$this->assertSame('Este é o JSON de um cliente OAuth, não a chave de uma conta de serviço. A chave salva continua em uso.',$r['message']);}
        foreach(['private_key'=>'-----BEGIN RSA PRIVATE KEY-----','token_uri'=>'https://evil.example/token'] as $field=>$value){$k=json_decode($old,true);$k[$field]=$value;$this->assertFalse(Auth::save_sa(wp_json_encode($k),'',true,$before)['success']);}
        $this->assertCount(0,FakeHttp::$requests);$this->token(400);$r=Auth::save_sa($this->key('robot@synthetic.iam.gserviceaccount.com','b'),'',true,$before);
        $this->assertFalse($r['success']);$this->assertStringContainsString('invalid_grant',$r['message']);$this->assertSame($before,Settings::revision());$this->assertSame($old,Options::get_secret(Options::SA_JSON));$this->assertNull(Candidate::read('service_account'));
    }
    public function test_new_key_check_bypasses_valid_cached_token_and_never_caches_rejected_key(): void {
        $this->active();$this->token();$this->assertSame('synthetic-token',Credentials::current()->get_access_token(Credentials::scopes_for('any')));
        $this->token(400);$r=Auth::save_sa($this->key('robot@synthetic.iam.gserviceaccount.com','b'),'',true,Settings::revision());
        $this->assertFalse($r['success']);$this->assertCount(2,FakeHttp::$requests);
        $this->assertNotSame(FakeHttp::$requests[0]['body']['assertion'],FakeHttp::$requests[1]['body']['assertion']);
    }
    public function test_candidate_must_be_verified_before_persistence_and_rechecked_on_activation(): void {
        $before=Settings::revision();$this->token(400);$r=Auth::save_sa($this->key());$this->assertFalse($r['success']);$this->assertSame($before,Settings::revision());
        $this->token();$r=Auth::save_sa($this->key());$this->assertTrue($r['success']);$this->assertSame('',Options::get_secret(Options::SA_JSON));
        $before=Settings::revision();$this->token(400);$r=Auth::activate('service_account',$before);$this->assertFalse($r['success']);$this->assertSame($before,Settings::revision());
    }
    public function test_stale_revision_before_and_during_validation_cannot_overwrite(): void {
        $this->active();$old=Settings::revision();Settings::save([Options::SA_SUBJECT=>'delegate@example.test']);
        $r=Auth::save_sa($this->key(),' ',true,$old);$this->assertFalse($r['success']);$this->assertCount(0,FakeHttp::$requests);
        $hook=static function($pre){Settings::save([Options::SA_SUBJECT=>'concurrent@example.test']);return $pre;};
        $this->token();add_filter('pre_http_request',$hook,20);
        try{$r=Auth::save_sa($this->key('robot@synthetic.iam.gserviceaccount.com','b'),'',true,Settings::revision());}finally{remove_filter('pre_http_request',$hook,20);}
        $this->assertSame('f3_google_configuration_conflict',$r['error_code']);$this->assertSame('concurrent@example.test',Options::get(Options::SA_SUBJECT));
    }
    public function test_rotation_preserves_grants_execution_destination_and_proof_expiry(): void {
        $this->active();Options::set(\Fator3\McpGoogle\Integration\ServiceApi::GRANTS,['core'=>['enabled'=>true,'revision'=>'same-grant']]);
        $c=ConversionDelivery::defaults()+['granted_by'=>1];$c['verified']=[];
        $proof=new \ReflectionMethod(ConversionDelivery::class,'proof_revision');$proof->setAccessible(true);
        foreach(['ga4','google_ads'] as $t)$c['verified'][$t]=['revision'=>$proof->invoke(null,$c,$t),'expires'=>time()+3600,'at'=>time()-300,'by'=>1];
        Options::set(ConversionDelivery::CONFIG,$c);$exec=Settings::execution_revision();$grants=Options::stored(\Fator3\McpGoogle\Integration\ServiceApi::GRANTS)['value'];
        $this->token();$r=Auth::save_sa($this->key('robot@synthetic.iam.gserviceaccount.com','b'),'',true,Settings::revision());
        $this->assertTrue($r['success'],wp_json_encode($r));$this->assertTrue($r['rotation']);$this->assertSame($exec,Settings::execution_revision());$this->assertSame($grants,Options::stored(\Fator3\McpGoogle\Integration\ServiceApi::GRANTS)['value']);
        $after=Options::get(ConversionDelivery::CONFIG);
        foreach(['ga4','google_ads'] as $t){$this->assertSame($c['verified'][$t]['expires'],$after['verified'][$t]['expires']);$this->assertSame($c['verified'][$t]['at'],$after['verified'][$t]['at']);$this->assertNotSame($c['verified'][$t]['revision'],$after['verified'][$t]['revision']);$this->assertSame($proof->invoke(null,$c,$t),$after['verified'][$t]['revision']);}
        $s=Validation::summary();$this->assertCount(1,$s['rotation_history']);$this->assertSame('bbbbbbbb',$s['key_suffix']);$this->assertNotNull($s['authentication_at']);
        $this->assertStringNotContainsString('PRIVATE KEY',wp_json_encode($s));$this->assertStringNotContainsString('synthetic-token',wp_json_encode($r));
    }
    public function test_failed_atomic_rotation_rolls_back_key_receipts_and_proofs(): void {
        $this->active();$before=Settings::revision();$GLOBALS['f3_test_write_fail'][Validation::RECEIPTS]=true;$this->token();
        $r=Auth::save_sa($this->key('robot@synthetic.iam.gserviceaccount.com','b'),'',true,$before);$this->assertFalse($r['success']);$this->assertSame($before,Settings::revision());$this->assertSame('aaaaaaaa',Validation::summary()['key_suffix']);
    }
    public function test_other_identity_requires_plan_and_explicit_switch_with_resources_preserved(): void {
        $old=$this->active();$json=$this->key('other@synthetic.iam.gserviceaccount.com','b');$revision=Settings::revision();
        $r=Auth::save_sa($json,'',true,$revision);$this->assertSame('f3_google_identity_change_required',$r['error_code']);$this->assertSame($old,Options::get_secret(Options::SA_JSON));
        $this->token();$r=Auth::save_sa($json,'',false,$revision);$this->assertTrue($r['success']);$this->assertTrue($r['identity_change_required']);
        Options::set(Connections::BINDINGS,['gsc_site_url'=>'sc-domain:example.test']);$revision=Settings::revision();
        $this->token();$this->token();FakeHttp::push('/webmasters/',403,['error'=>['status'=>'PERMISSION_DENIED']]);
        $p=Auth::plan_identity_change($revision);$this->assertTrue($p['success']);$this->assertFalse($p['can_switch']);$this->assertSame($old,Options::get_secret(Options::SA_JSON));
        $this->token();FakeHttp::push('/webmasters/',200,['siteUrl'=>'sc-domain:example.test','permissionLevel'=>'siteOwner']);
        $p=Auth::plan_identity_change($revision);$this->assertTrue($p['can_switch'],wp_json_encode($p));
        $this->token();FakeHttp::push('/webmasters/',200,['siteUrl'=>'sc-domain:example.test','permissionLevel'=>'siteOwner']);
        $r=Auth::switch_identity($revision,$p['plan_hash']);$this->assertTrue($r['success'],wp_json_encode($r));$this->assertFalse($r['rotation']);
        $this->assertSame(['gsc'=>'read'],Options::get(Connections::SERVICES));$this->assertSame(['gsc_site_url'=>'sc-domain:example.test'],Options::get(Connections::BINDINGS));$this->assertSame('other@synthetic.iam.gserviceaccount.com',Validation::summary()['identity']);
    }
    public function test_retired_ads_token_never_sends_or_replaces_a_legacy_secret(): void {
        $this->active();
        Options::set_secret(Options::ADS_DEVELOPER_TOKEN,'historical');
        $result=Validation::save_ads([Options::ADS_LOGIN_CUSTOMER_ID=>'123-456-7890'],[Options::ADS_DEVELOPER_TOKEN=>'ignored'],[Options::ADS_DEVELOPER_TOKEN],Settings::revision());
        $this->assertTrue($result['success']);
        $this->assertSame('1234567890',Options::get(Options::ADS_LOGIN_CUSTOMER_ID));
        $this->assertSame('historical',Options::get_secret(Options::ADS_DEVELOPER_TOKEN));
        $this->assertCount(0,FakeHttp::$requests);
        $this->assertArrayNotHasKey('developer_token_accepted_at',Validation::summary());
    }
    public function test_oauth_formats_and_connection_rename_preserve_default_id(): void {
        foreach([['wrong','GOCSPX-good'],['good.apps.googleusercontent.com','good.apps.googleusercontent.com'],['good.apps.googleusercontent.com','{"type":"service_account"}']] as [$id,$secret])$this->assertFalse(Auth::save_oauth($id,$secret)['success']);
        $this->assertTrue(Auth::save_oauth('good.apps.googleusercontent.com','GOCSPX-good')['success']);
        $r=Connections::rename('wp-mcp-fator3 · synthetic',Settings::revision());$this->assertTrue($r['success']);$this->assertSame('default',$r['connection_id']);$this->assertSame('wp-mcp-fator3 · synthetic',Connections::registry_verified()['default']['label']);
        Connections::create('other','Other');$this->assertSame('wp-mcp-fator3 · synthetic',Connections::registry()['default']['label']);
        $GLOBALS['f3_test_caps']=false;$this->assertFalse(Connections::rename('forbidden',Settings::revision())['success']);$this->assertFalse(Auth::save_sa($this->key())['success']);
    }
}
