<?php
/** SQL-facing double for cron unit tests. Native tests exercise the real engine separately. */
trait F3_Test_CronSql {
    public array $prepared=[];
    public function get_charset_collate(){
        return '';
    }
    public function get_results($sql,$format=null){
        $this->last_error='';
        if(str_starts_with($sql,'SHOW TABLES'))return [['table'=>$this->prefix.'f3_google_cron']];
        if(str_contains($sql,'f3_google_records')) return $this->record_rows($sql);
        if(!str_contains($sql,'f3_google_cron')){
            $out=[];
            foreach($this->prepared[$sql]??[] as $name){
                if(method_exists($this,'get_row')){
                    $r=$this->get_row($this->prepare("SELECT option_value FROM {$this->options} WHERE option_name = %s",$name),ARRAY_A);
                    if($this->last_error)return [];
                    if($r)$out[]=['option_name'=>$name]+$r;
                }
                elseif(array_key_exists($name,$GLOBALS['f3_test_options']))$out[]=['option_name'=>$name,'option_value'=>maybe_serialize($GLOBALS['f3_test_options'][$name])];
            }
            return $out;
        }
        if(str_starts_with($sql,'SHOW TABLES'))return [['table'=>$this->prefix.'f3_google_cron']];
        $rows=array_values($GLOBALS['f3_test_cron_rows']??[]);
        if (str_contains($sql,'GROUP BY connection_id,kind')) {
            [$cursor,$cutoff,$passes,$incidents]=$this->prepared[$sql];
            $groups=[];
            foreach ($rows as $row) {
                $key=$row['connection_id'].'/'.$row['kind'];
                if (strcmp($key,$cursor)<=0) { continue; }
                $groups[$key][]=$row;
            }
            ksort($groups);
            foreach ($groups as $group) {
                $first=$group[0];
                if (min(array_column($group,'at'))<$cutoff || count($group)>($first['kind']==='pass'?$passes:$incidents)) {
                    return [array_intersect_key($first,['connection_id'=>true,'kind'=>true])];
                }
            }
            return [];
        }
        if (str_contains($sql,'payload LIKE')) $rows=array_values(array_filter($rows,fn($r)=>(json_decode($r['payload'],true)['history_status']??'')==='pending'));
        foreach(['kind','connection_id','run_id','origin','scope','success']as$field){
            if(preg_match('/(?:WHERE|AND) '.$field."='([^']*)'/",$sql,$m))$rows=array_values(array_filter($rows,fn($r)=>(string)($r[$field]??'')===stripslashes($m[1])));
        }
        if(preg_match('/ AND at>(\d+)/',$sql,$m))$rows=array_values(array_filter($rows,fn($r)=>$r['at']>(int)$m[1]));
        if(preg_match('/ AND at<=(\d+)/',$sql,$m))$rows=array_values(array_filter($rows,fn($r)=>$r['at']<=(int)$m[1]));
        if(preg_match('/ AND at<(\d+)/',$sql,$m))$rows=array_values(array_filter($rows,fn($r)=>$r['at']<(int)$m[1]));
        if(str_contains($sql,'NOT (scope'))$rows=array_values(array_filter($rows,fn($r)=>!in_array($r['scope'],['executor','wp_cli_invocation'],true)||$r['success']!==null||$r['at']<time()-120));
        if(str_contains($sql,'GROUP BY origin')){
            $out=[];
            foreach($rows as$r)$out[$r['origin']]=($out[$r['origin']]??0)+1;
            return array_map(fn($k,$v)=>['origin'=>$k,'total'=>$v],array_keys($out),array_values($out));
        }
        if(str_contains($sql,'COUNT(*)'))return [['total'=>count($rows)]];
        usort($rows,fn($a,$b)=>[$a['at'],$a['run_id']]<=>[$b['at'],$b['run_id']]);
        if(str_contains($sql,'DESC'))$rows=array_reverse($rows);
        if(preg_match('/LIMIT (\d+)/',$sql,$m))$rows=array_slice($rows,0,(int)$m[1]);
        return $rows;
    }
    private function cron_query($sql){
        if(!str_contains($sql,'f3_google_cron'))return null;
        $this->last_error='';
        if(str_starts_with($sql,'CREATE TABLE'))return 0;
        $args=$this->prepared[$sql]??[];
        if(str_starts_with($sql,'INSERT INTO')||str_starts_with($sql,'UPDATE')){
            [$at,$origin,$scope,$payload,$digest,$kind,$cid,$id]=$args;
            $key='f3_mcp_google_cron_'.$kind.'_'.$cid.'_'.$id;
            if(!empty($GLOBALS['f3_test_write_fail'][$key])){
                $this->last_error='test storage refusal';
                return false;
            }
            preg_match('/(?:success=|,)(NULL|0|1)(?: WHERE|\))/', $sql,$m);
            $success=($m[1]??'NULL')==='NULL'?null:(int)$m[1];
            $GLOBALS['f3_test_cron_rows'][$kind.'|'.$cid.'|'.$id]=['kind'=>$kind,'connection_id'=>$cid,'run_id'=>$id,'at'=>(int)$at,'origin'=>$origin,'scope'=>$scope,'success'=>$success,'payload'=>$payload,'digest'=>$digest];
            return 1;
        }
        if(str_starts_with($sql,'DELETE')){
            [$kind,$cid,$id]=$args;
            unset($GLOBALS['f3_test_cron_rows'][$kind.'|'.$cid.'|'.$id]);
            return 1;
        }
        return 0;
    }
}
