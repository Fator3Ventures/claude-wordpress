"""Build a closed, hash-bound test controller and external bundle. Never install in production."""
from pathlib import Path
import argparse,base64,gzip,json,hashlib,subprocess,os
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=Path(__file__).resolve().parents[1]
bundle={}
for root,prefix in [(r/'tests/native','tests/native'),(a.baseline,'baseline/wp-mcp-meta-fator3'),(a.candidate,'candidate/wp-mcp-meta-fator3')]:
 for f in sorted(root.rglob('*')):
  if f.is_file() and (prefix!='tests/native' or '0160' in f.name or f.name in ['seed-connection090.php','environment090.php']):bundle[prefix+'/'+f.relative_to(root).as_posix()]=base64.b64encode(f.read_bytes()).decode()
for f in [(r/'tests/core-hashes0160.json')]:bundle['tests/'+f.name]=base64.b64encode(f.read_bytes()).decode()
payload=gzip.compress(json.dumps(bundle,sort_keys=True).encode(),mtime=0);digest=hashlib.sha256(payload).hexdigest();a.output.parent.mkdir(parents=True,exist_ok=True);a.output.with_name('f3-qa0160.bundle.gz').write_bytes(payload)
a.output.write_text((r/'tests/site/isolated0160-controller.php').read_text().replace('__BUNDLE_SHA256__',digest))
php=os.environ.get('F3_SOCIAL_PHP','php')
for f in [a.output,*sorted((r/'tests/native').glob('*0160*.php'))]:subprocess.run([php,'-n','-l',str(f)],check=True,capture_output=True)
print(json.dumps({'bundle_bytes':len(payload),'bundle_sha256':digest,'controller_bytes':a.output.stat().st_size,'controller_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest()}))
