# Impacto técnico — Meta → Site Core

Emissor: wp-mcp-meta-fator3, base 0.14.0, alvo previsto 0.15.0. Destinatário: base-site-core-fator3, base recebida 1.60.0. Data: 29/10/2026, America/Sao_Paulo. Revisão 1. Etapa: implementação, conforme desenho registrado em planning/RELEASE-0150.md. Situação: acao-necessaria e validacao-coordenada. Instalador final ainda não congelado.

## Consequência e pedidos

Os pedidos MCP Meta 23/24 introduzem `ads_activity` e `dataset_quality`, que não pertencem à concessão de performance `meta-ads-reader/1.0.0`. Core 340/341 devem integrar **meta-ads-monitoring/1.0.0** pelo hook `f3_meta_register_monitoring_consumers`, registrar o consumidor com configuração `ready`, `connection_id`, `account_id` (conta de anúncios), `revision` monotônica, `reports` e `dataset_ids`. O callback deve mudar a revisão quando o acesso for alterado; não reviver configuração antiga após desativação/reativação.

A concessão é nova e explícita. O administrador confirma relatórios/datasets anunciados pelo consumidor em Consumidores de anúncios ou `save-monitoring-grant`. Não migrar nem ampliar silenciosamente concessões de performance. `client.query` lê somente histórico local; para dataset recebe `dataset_id`. Ativos retirados, configuração alterada, concedente revogado ou revisão de acesso alterada invalidam o acesso e os cursores.

Core 340: apresentar atividades por conta, horário, entidade, evento, autor e valores anterior/novo quando fornecidos. A chave é uma impressão digital do conteúdo; eventos indistinguíveis retornados pela origem compartilham chave. Página vazia não comprova recuperação de toda a história remota.

Core 341: consumir registros `event_counts` e `emq_snapshot` separadamente. Contagens de navegador e servidor podem se sobrepor: não somar como conversões únicas. EMQ tem `emq_observed_at` e data da observação; não atribuir essa nota à data passada das contagens. Ausência e recusa ficam desconhecidas. O aviso `dataset_optimized_event_zero` em `meta/health` exige zeros explícitos, cobertura confirmada e evento padrão vinculado a conjunto ativo observado. Implementar o encaminhamento ao canal do site e a deduplicação por `incident_key`; o Meta não envia essa notificação.

## Responsáveis e aceite necessário

Responsável Core: consumidores, configuração, revisão monotônica de acesso, apresentação e canal de notificação dos pedidos 340/341. Responsável Meta: coleta, retenção cifrada sem prazo, contrato, permissões e documentação. Operador/frota: permissões, opt-in para Dataset Quality quando exigido, seleção explícita de datasets, agendas diárias e homologação com os ativos reais.

Validar: negar antes da concessão; conceder somente o recorte confirmado; consultar atividades/contagens/EMQ localmente sem HTTP; retirar ativo ou revogar concessão e negar continuação; preservar o leitor de performance existente. Em korvena, comprovar alteração real de orçamento da conta 1803436740776667. Datasets 1088603200283681 e 1062566196616523: comprovar contagens e EMQ quando a Meta liberar; não fabricar histórico 22–26/10. Instalação em produção e homologação de dados reais não estão autorizadas nesta rodada.

O documento apresenta consequências e pedidos ao Core; resultados de testes do Meta e resposta ao impacto Core330 ficam no relatório principal. Este encaminhamento não declara concluída a implementação de outro pacote.
