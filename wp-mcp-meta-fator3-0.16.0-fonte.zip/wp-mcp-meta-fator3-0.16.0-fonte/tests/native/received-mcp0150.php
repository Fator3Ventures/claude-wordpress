<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';global $wpdb;$root=getenv('F3_LAB_ROOT');if(!preg_match('/^f3qa0150_[a-f0-9]{12}_$/D',$wpdb->prefix)||!str_starts_with(WP_PLUGIN_DIR,$root.'/wordpress/'))throw new RuntimeException('Disposable lab required');
$zip=$root.'/received-mcp0360.zip';if(hash_file('sha256',$zip)!=='97648853e16d7c7fca811c6be22323244c5f2ebc3e296c22564ce7b2739cb98b')throw new RuntimeException('Received archive hash mismatch');
function rm_received_mcp15($p){if(is_dir($p)&&!is_link($p)){foreach(new DirectoryIterator($p) as $f)if(!$f->isDot())rm_received_mcp15($f->getPathname());rmdir($p);}else unlink($p);}
rm_received_mcp15(WP_PLUGIN_DIR.'/wp-mcp-fator3');$z=new ZipArchive();if($z->open($zip)!==true)throw new RuntimeException('Archive read failed');$z->extractTo(WP_PLUGIN_DIR);$z->close();echo wp_json_encode(['received_mcp_installed_in_disposable_lab'=>true,'sha256'=>hash_file('sha256',$zip),'requires_fresh_process'=>true]);
