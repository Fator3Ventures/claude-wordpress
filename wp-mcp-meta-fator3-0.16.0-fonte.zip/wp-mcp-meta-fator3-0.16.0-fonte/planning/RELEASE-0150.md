# Plano — Fator3 MCP Meta 0.15.0

29/10/2026, America/Sao_Paulo. Rodada de implementação a partir da 0.14.0 entregue (instalador SHA-256 43e8947ac0ffaf3da52c62b0515db826e6df266553d64f5561c0d3b87b7eb318). Alvo minor 0.15.0 previsto, instalador ainda não gerado. A instrução de patch aplica-se a correção adicional dentro do mesmo ciclo, não a esta nova rodada de pedidos. Bases novas: Core1.60.0 e MCP0.36.0 anexados; conferir acompanhantes vivos antes de instalar.

## Pedidos e desenho anterior à implementação

22: padrões de token/App ID/App Secret passam a avisos estruturados com campo, código e motivo; conferir sempre no fornecedor quando o candidato cabe nos limites seguros. Aparar espaços ASCII externos com aviso, recusar vazio/controle/mais de16384 bytes e prova indispensável ausente. Preservar semântica de campo vazio que mantém segredo salvo e remoção explícita. Avisos em sucesso/erro, REST/MCP e junto do campo; não incluir valor secreto. Manter CAS, identidade, escopos, ativos, atomicidade e confirmação de troca.

23: ads_activity no canal ads, coleta diária, paginação, revisita/backfill limitado ao que a Meta devolver. Instante/evento/entidade/autor/extra_data e valores antigo/novo quando presentes. Guardar cifrado sem prazo; identidade estável evita duplicar revisitas, mas não inventa valores ausentes. Nenhuma escrita em anúncios.

24: dataset_quality e canal dataset para seleção explícita do ativo, junto da conta de anúncios autorizada que define fuso e a observação de conjuntos ativos. Eventos recebidos separados por navegador/servidor, sem somá-los como eventos únicos. EMQ é snapshot observado, não é reconstruído para data passada nem convertido em zero quando ausente. Dia incompleto/recusa/sem cobertura fica desconhecido; alerta de zero exige evidência de contagem. Health local não chama fornecedor nem envia aviso; canal de notificação pertence ao Core341. Confirmar os endpoints públicos e requisitos do fornecedor antes da implementação.

Contrato adicional previsto meta-ads-monitoring/1.0.0, separado do meta-ads-reader/1.0.0 existente: registro local, cliente status/query, concessão explícita por consumidor/conexão/conta/datasets/relatórios/revisão. Sem HTTP na leitura SDK; revogação e alterações de seleção invalidam cursores. Consumer Core340/341 ainda requer implementação por seu responsável. Ver impacto Core emitido neste planejamento.

## Impactos e preservação

Impacto recebido Core330: revisão de acesso monotônica independente do mapa editorial. Validar com a suíte original Core1.60; não renovar concessão automaticamente nem alterar produção. Documento recebido informa reconcessão em korvena já feita pela frota: informação externa, não ação desta rodada. Resposta e prova no relatório principal.

Novo impacto somente ao Core para os pedidos340/341: contrato e permissões novos são consequência técnica real. Nenhum impacto por aviso de versão, resposta ou encerramento. LinkedIn/Google/Pipedrive não serão alterados. Retenção ampliada preservada; novos acervos sem prazo.

## Provas e fronteiras

Reproduzir recusas locais da0.14; validar avisos e preservação com conferência remota negativa, controles e CAS. Fixtures Graph de atividades/stats/EMQ, fuso, paginação, duplicação, faltas e recusas; cifragem e revisita; grants/cursor/negação/retirada; health somente local e zero real distinto de ausente. Core330 com runtime recebido. Upgrade direto0.14→0.15 e limpa; WP6.4/PHP8.1.2 e runtime corrente Site-Teste. Documentação integral instalada/MCP, hashes e limpeza do laboratório.

Só Site-Teste autorizado para mutações, com prefixo SQL/diretório exclusivo. Não tocar produção, não ler token real, não criar concessão real de cliente ou enviar mensagens/contatos/anúncios. Aceites korvena/CTO e dados reais seguem com operador/frota; não transformar fixture em homologação externa. Instalador congelado antes da instalação; fonte fechado uma vez; relatório externo após hash.
