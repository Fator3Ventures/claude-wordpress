# Meta 0.16.0 — integração documentada com Core 1.61.1

29/10/2026, America/Sao_Paulo. Base: Meta 0.15.0, instalador SHA-256 521e8f83a8c6fad12497e7c9f40ec6cf8cb129060c6a56e89955257ca22f81f3. Alvo previsto: 0.16.0, instalador ainda não gerado. Rodada solicitada de nova versão; incremento minor conforme instruções. O arquivo de impacto Core 1.61.1 revisão 2 informa que não exige mudança no runtime Meta e pede validação coordenada dos pedidos Core 340/341 e Meta 23/24.

## Escopo concreto

Corrigir a documentação operacional instalada que ainda apresenta o consumidor Core como pendente. Documentar a configuração pública, concessão independente, revisões, leitura de atividades/contagens/EMQ e diferença entre incidente do produtor e notificação autorizada no consumidor. Manter 47 operações, meta-ads-reader/1.0.0 e meta-ads-monitoring/1.0.0; nenhuma ativação automática, acesso ou redução de retenção. Novo guia CORE-MONITORING.md, com referências nos guias existentes e nota de versão.

Revisar o código da fronteira e executar o teste original de monitoramento do Core com o produtor Meta real, além da regressão de performance, autorização do transporte, instalação limpa e atualização direta com concessões/novos acervos preservados. Fornecedores e canais de aviso simulados em WordPress isolado. Testar o mínimo próprio sem ativar acompanhantes cujo piso é maior. Conferir ajuda integral por MCP após instalar o ZIP fechado no Site-Teste.

## Impactos

Nenhuma alteração de contrato ou nova ação técnica para outro pacote foi identificada nesta análise. Não emitir impacto de resposta/encerramento ao Core: resultados e aceite técnico do documento recebido pertencem ao relatório principal. O impacto Meta 0.15.0 permanece histórico; a integração declarada no Core será distinguida da prova própria. Aceites com contas reais ficam sob responsabilidade do dono/frota.

As fontes de projeto fornecidas são revisão 4; a instrução explícita do usuário de que impactos não contêm respostas/encerramentos e a revisão 5 preservada na base prevalecem nesses pontos. Não alterar documentos centrais ou pacotes alheios.

## Matriz inicial observada

Site-Teste: Core 1.61.1, MCP 0.37.0, Google 0.23.0, Meta 0.15.0, LinkedIn 0.13.0 e Pipedrive 0.4.0 ativos. Monitoramento Core registrado e consumer_not_ready, sem concessão. Revalidar integridade antes/depois da única troca de plugin. Limpar apenas banco/diretórios/MU-plugins temporários desta rodada. Preservar auditoria e backups normais.

## Resultado da rodada

Implementado e instalado Meta 0.16.0, instalador 315170 bytes, SHA-256 a49f3e8ae9e60814ab55cf1bd4b3277e859a477347d02f664353c1268fda0b6b. 210 asserções finais na matriz, mais oito controles do selftest compartilhado. 47 operações, 27 documentos conferidos integralmente pelo MCP e guia paginado. Lógica/contratos/assets preservados; documentação instalada atualizada. Acompanhantes, dados e configuração compartilhados preservados. Laboratórios e controlador removidos. O relatório registra provas próprias, ajustes da preparação e aceite remoto ainda pendente. Nenhum novo relatório de impacto foi emitido.
