"""Fetch declared PHP 8.1 test dependencies from Ubuntu's official package archive."""
from pathlib import Path
import urllib.request,gzip,hashlib,json,subprocess
root=Path(__file__).resolve().parents[1]/'dependencies';root.mkdir(exist_ok=True);target=root/'php81';target.mkdir(exist_ok=True)
base='https://archive.ubuntu.com/ubuntu/'
needed={'php8.1-cli','php8.1-common','php8.1-mysql','php8.1-xml','php8.1-mbstring','php8.1-curl','php8.1-zip','libicu70','libonig5','libzip4'}
found={}
for dist in ['jammy-updates','jammy']:
 for component in ['main','universe']:
  data=gzip.decompress(urllib.request.urlopen(base+f'dists/{dist}/{component}/binary-amd64/Packages.gz',timeout=40).read()).decode()
  for paragraph in data.split('\n\n'):
   record={}
   for line in paragraph.splitlines():
    if ': ' in line and not line.startswith(' '):k,v=line.split(': ',1);record[k]=v
   name=record.get('Package')
   if name in needed and name not in found:found[name]=record
  print(json.dumps({'index':dist+'/'+component,'found':len(found)}),flush=True)
  if len(found)==len(needed):break
 if len(found)==len(needed):break
if needed-found.keys():raise RuntimeError('Missing '+str(needed-found.keys()))
manifest=[]
for name,record in found.items():
 data=urllib.request.urlopen(base+record['Filename'],timeout=30).read()
 if hashlib.sha256(data).hexdigest()!=record['SHA256']:raise RuntimeError('Hash mismatch')
 path=root/Path(record['Filename']).name;path.write_bytes(data);subprocess.run(['dpkg-deb','-x',str(path),str(target)],check=True)
 manifest.append({'package':name,'version':record['Version'],'url':base+record['Filename'],'sha256':record['SHA256']})
(root/'php81-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'complete':True,'packages':len(manifest)}))
