# Fator3 MCP LinkedIn 0.2.0 — fonte

- `plugin/wp-mcp-linkedin-fator3/`: runtime exato do instalador.
- `build/`: templates, documentação-fonte e build determinístico. Execute `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`; saída em `build/dist/`. PHP 8.1+, Python 3.10+ e extensões do runtime são pré-requisitos de desenvolvimento.
- `tests/native/`: testes em WordPress/MySQL reais, HTTP externo interceptado, sem assinatura real.
- `tools/lab.py`: laboratório isolado, diretório novo, dependências declaradas por SHA-256. Banco temporário próprio e processos encerrados ao finalizar.
- `evidence/`: resultados sanitizados, escopo e limites.
- `wp-mcp-linkedin-fator3-0.2.0-relatorio.md`: cópia anterior ao fechamento do fonte.

Para testar só este pacote, prepare o manifesto a partir de tools/dependencies.example.json, forneça runtime PHP/MySQL, arquivo oficial WordPress e instalador 0.1.0 conforme os hashes. Execute `python3 tools/lab.py --manifest tools/dependencies.json --workdir ./lab-clean --origin clean --order linkedin-only`. Para upgrade use novo diretório e `--origin upgrade`. O laboratório não deve apontar para produção. Testes de convivência/painel requerem os dois instaladores e os acompanhantes explicitamente indicados em manifesto; UI funcional requer Node/jsdom, e o script Playwright exige navegador autorizado pelo host. O navegador real ficou bloqueado nesta execução; consulte a evidência.

Não há ZIP aninhado, credencial real ou dependência de desenvolvimento no instalador. A documentação de operação está no runtime e é lida pela API instalada. Fontes e evidências não foram publicados no repositório público.
