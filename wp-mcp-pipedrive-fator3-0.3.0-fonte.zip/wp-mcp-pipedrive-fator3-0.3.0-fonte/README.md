# Fator3 MCP Pipedrive 0.3.0 — fonte

Runtime em plugin/wp-mcp-pipedrive-fator3; somente o ZIP instalador é instalável. Plano PLANO.md, entradas inputs/, testes tests/, provas evidence/. Python 3 (biblioteca padrão), PHP 8.3 e WordPress 7.1.3. Sem Composer/npm ou dependências externas de build.

Reprodução: `php build/schemas.php > plugin/wp-mcp-pipedrive-fator3/docs/schemas.json`; `python3 build/package.py installer --out /diretorio/saidas`; `python3 build/verify.py --installer /caminho/instalador.zip --php /caminho/php`; depois `python3 build/package.py source --out /diretorio/saidas`. Timestamp ZIP fixo 28/10/2026. Testes nativos descritos em tests/README.md. Não distribuir scripts de laboratório no instalador.
