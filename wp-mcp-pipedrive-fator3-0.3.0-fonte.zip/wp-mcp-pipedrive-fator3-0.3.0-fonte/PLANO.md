# Plano — Fator3 MCP Pipedrive 0.3.0

28/10/2026, America/Sao_Paulo. Implementação de Pedidos MCP Pipedrive 3. Base direta 0.2.0, instalador SHA-256 b7065e4780cbc2166605164e4a822338b76627bef48c5f05a9fb9c3505efbb4a. Alvo previsto 0.3.0; instalador ainda não gerado neste planejamento. Normas revisão 5. Identidades e retenção da base preservadas.

## Solução

Nova leitura administrativa `pipedrive/relatorio`: listas paginadas de leads ativos/arquivados e negócios ativos/arquivados, catálogo de campos, agregação somente em memória. Cliente Core contrato pipedrive-api-client/1.0.0, consumidor operacao. Nenhum token, HTTP, cron, tabela ou configuração novos. GET /api/v2/deals e /api/v2/deals/archived entram na lista estreita de leitura. Página de 100 itens; limites cooperativos de chamadas, duração, registros e grupos. Interrupção devolve parcial explícito e custo; sem repetição automática.

Datas inclusivas em fuso IANA: leads e distribuição de negócios por data de criação, estado atual. Parâmetro permite usar data de arquivamento para leads arquivados, sem inferir essa data por update_time; ausência produz parcial. Ganhos/perdas usam won_time/lost_time. Uso do plano ignora período e inclui leads ativos e negócios open/won/lost não arquivados. Não é fotografia histórica nem snapshot transacional; visibilidade é a do token do Core.

Privacidade: saída construída por allowlist, sem dados individuais, títulos, nomes de pessoas ou metadados livres. Categorias enumeradas saem por IDs, textos livres por HMAC estável de categoria, com possibilidade de mapear valores a códigos numéricos fornecidos pelo chamador. Não emitir strings do fornecedor, inclusive motivos e nomes de funis. Identificadores de lead/negócio são usados apenas para deduplicar em memória. Motivo de ganho requer campo próprio: não há motivo nativo de ganho documentado. Não inventar limite do plano: receber limite conhecido em parâmetro e indicar origem; ausente significa comparação indisponível.

## Fronteiras

Core 1.57.1 conserva cliente 1.0.0 e admite GET fixos usados; cobra 20 unidades de operacao por GET enviado (não é custo tarifário oficial). Não requer alteração do Core. MCP transporta nova ability com readonly e remote_effect read. LinkedIn 0.11.0 não compartilha tabelas, opções ou rotas. Google anexado por engano excluído conforme escolha do dono. Nenhum impacto técnico dirigido a outro pacote identificado; não emitir arquivo sem ação.

## Provas previstas

Fixtures de paginação offset/cursor, período/fuso, motivos, custom fields, duplicatas, teto, tempo, falhas, privacidade e autorização. Regressões da base. WordPress descartável para instalação limpa e atualização 0.2.0 → 0.3.0 preservando dados/opções. Executor MCP e leitura documental. Instalação autorizada no Site-Teste com antes/depois e limpeza apenas dos recursos QA desta rodada. Conferência de 30 dias em korvena.com.br com tela é pendência de homologação real, separada de fixtures. Consulta opcional de metadados em korvena.net.br recusada pela revisão automática por escopo; não será contornada.
