<?php
$mode=$argv[1]??'';
if(!in_array($mode,['install','install-base','seed-upgrade','upgrade','verify-upgrade','upgrade-restart','native','report','retention','integrate','integrated','core','core-report'],true))exit(2);
define('F3_PIPEDRIVE_DISPOSABLE',true);
if(in_array($mode,['install','install-base'],true))define('WP_INSTALLING',true);
define('ABSPATH',__DIR__.'/wordpress/');require ABSPATH.'wp-load.php';
if(!str_starts_with($wpdb->prefix,'f3pipqa_0300'))exit(3);
require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/template.php';
wp_set_current_user(1);$result=[];
try {
 if(in_array($mode,['install','install-base'],true)){
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  if(!is_blog_installed())wp_install('Pipedrive disposable QA','qa_admin','qa@example.test',true,'',wp_generate_password(40));
  wp_set_current_user(1);if(!defined('FS_METHOD'))define('FS_METHOD','direct');require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
  $up=new Plugin_Upgrader(new Automatic_Upgrader_Skin());$r=$up->install(__DIR__.($mode==='install-base'?'/base.zip':'/installer.zip'));
  if($r!==true)throw new RuntimeException('Native install failed');
  $r=activate_plugin('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php');if(is_wp_error($r))throw new RuntimeException($r->get_error_code());
  $result=['installed'=>true,'version'=>get_plugin_data(WP_PLUGIN_DIR.'/wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php',false,false)['Version'],'wp'=>$wp_version,'php'=>PHP_VERSION,'mysql'=>$wpdb->db_version(),'storage'=>get_option('f3_pipedrive_schema')];
 }elseif($mode==='seed-upgrade'){
  if(Fator3\Pipedrive\VERSION!=='0.2.0')throw new RuntimeException('Wrong upgrade base');
  $policy=Fator3\Pipedrive\Retention::read();Fator3\Pipedrive\Retention::configure(['diario_dias'=>730,'revisao_esperada'=>$policy['revisao'],'confirmar_expurgo'=>true]);
  $ops=Fator3\Pipedrive\Store::table('ops');$journal=Fator3\Pipedrive\Store::table('journal');
  foreach(['done','ready','running'] as $state){$id=bin2hex(random_bytes(16));$wpdb->insert($ops,['previa_id'=>$id,'actor_id'=>1,'binding'=>str_repeat('0',64),'state'=>$state,'created'=>time()-400*DAY_IN_SECONDS,'expires'=>time()-1,'retain_until'=>time()+3600,'payload'=>Fator3\Pipedrive\Support::seal(['synthetic'=>'preserve']),'result'=>$state==='done'?Fator3\Pipedrive\Support::seal(['success'=>true,'fixture'=>true]):'']);if($state!=='ready')$wpdb->insert($journal,['previa_id'=>$id,'created'=>time()-400*DAY_IN_SECONDS,'metadata'=>wp_json_encode(['previa_id'=>$id,'metodo'=>'PUT','caminho'=>'/v1/notes/900','classe'=>'registro','status'=>$state,'chaves_alteradas'=>['content'],'saldo_depois'=>null])]);}
  $snapshot=['ops'=>$wpdb->get_results("SELECT * FROM $ops ORDER BY previa_id",ARRAY_A),'journal'=>$wpdb->get_results("SELECT * FROM $journal ORDER BY id",ARRAY_A),'schema'=>get_option('f3_pipedrive_schema'),'retention'=>get_option('f3_pipedrive_retention'),'docs'=>hash_file('sha256',Fator3\Pipedrive\ROOT.'/docs/OPERATIONS.md')];
  file_put_contents(__DIR__.'/upgrade-snapshot.json',wp_json_encode($snapshot));$result=['base_version'=>Fator3\Pipedrive\VERSION,'operations'=>count($snapshot['ops']),'journal'=>count($snapshot['journal']),'snapshot_sha256'=>hash('sha256',wp_json_encode($snapshot))];
 }elseif($mode==='upgrade'){
  if(Fator3\Pipedrive\VERSION!=='0.2.0')throw new RuntimeException('Wrong upgrade source');
  if(!defined('FS_METHOD'))define('FS_METHOD','direct');require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
  $up=new Plugin_Upgrader(new Automatic_Upgrader_Skin());$r=$up->install(__DIR__.'/installer.zip',['overwrite_package'=>true]);
  if($r!==true)throw new RuntimeException('Native overwrite failed');
  $result=['upgraded_files'=>true,'next_process_required'=>true,'current_process'=>Fator3\Pipedrive\VERSION];
 }elseif($mode==='verify-upgrade'){
  $snapshot=json_decode(file_get_contents(__DIR__.'/upgrade-snapshot.json'),true);$ops=Fator3\Pipedrive\Store::table('ops');$journal=Fator3\Pipedrive\Store::table('journal');
  $tests=['version'=>Fator3\Pipedrive\VERSION==='0.3.0','active'=>is_plugin_active('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php'),'operations_byte_equal'=>$snapshot['ops']===$wpdb->get_results("SELECT * FROM $ops ORDER BY previa_id",ARRAY_A),'journal_byte_equal'=>$snapshot['journal']===$wpdb->get_results("SELECT * FROM $journal ORDER BY id",ARRAY_A),'schema_unchanged'=>$snapshot['schema']===get_option('f3_pipedrive_schema'),'retention_preserved'=>get_option('f3_pipedrive_retention')===$snapshot['retention']&&Fator3\Pipedrive\Retention::read()['diario_dias']===730,'docs_updated'=>$snapshot['docs']!==hash_file('sha256',Fator3\Pipedrive\ROOT.'/docs/OPERATIONS.md')];
  Fator3\Pipedrive\Store::install();$tests['activation_preserves_old_journal']=$snapshot['journal']===$wpdb->get_results("SELECT * FROM $journal ORDER BY id",ARRAY_A);
  $r=Fator3\Pipedrive\Api::dispatch('retencao-configurar',['diario_dias'=>730,'revisao_esperada'=>Fator3\Pipedrive\Retention::read()['revisao'],'confirmar_expurgo'=>true]);$tests['finite_choice_saved']=$r['success'];
  $result=['checks'=>$tests,'passed'=>count(array_filter($tests)),'failed'=>count(array_filter($tests,fn($v)=>!$v))];
 }elseif($mode==='upgrade-restart'){
  $p=Fator3\Pipedrive\Retention::read();Fator3\Pipedrive\Store::install();$tests=['choice_after_restart'=>$p['diario_dias']===730,'choice_after_reactivation'=>$p===Fator3\Pipedrive\Retention::read()];$result=['checks'=>$tests,'passed'=>count(array_filter($tests)),'failed'=>count(array_filter($tests,fn($v)=>!$v))];
 }elseif($mode==='integrate'){
  foreach(['wp-mcp-fator3','base-site-core-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3'] as $slug){$r=activate_plugin($slug.'/'.$slug.'.php');if(is_wp_error($r))throw new RuntimeException('Activate '.$slug.': '.$r->get_error_code());}
  $result=['companions_active'=>true];
 }else{$result=require __DIR__.'/tests/'.($mode==='core'?'core-retention':$mode).'.php';}
}catch(Throwable $e){$result=['exception'=>get_class($e),'message'=>$e->getMessage(),'file'=>basename($e->getFile()),'line'=>$e->getLine(),'checks_so_far'=>$checks??[]];}
echo 'F3_QA_RESULT='.json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
