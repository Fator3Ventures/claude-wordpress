<?php
/** Temporary QA controller. No runtime operation or supplier call. Remove after tests. */
defined('ABSPATH') || exit;
add_action('f3_mcp_register_providers',static function($v){if($v===1 && class_exists('Fator3\\McpFiles\\ExtensionContract')){\Fator3\McpFiles\ExtensionContract::register('f3-pipedrive-qa030','0.3.0',['qa-pipedrive030/']);}});
add_action('wp_abilities_api_init',static function(){
 wp_register_ability('qa-pipedrive030/run',['label'=>'Pipedrive isolated QA','description'=>'Temporary fixed laboratory actions. Admin only; no Pipedrive API.','category'=>'site',
 'input_schema'=>['type'=>'object','properties'=>['cenario'=>['type'=>'string','enum'=>['current','upgrade']],'acao'=>['type'=>'string','enum'=>['setup','install','install-base','seed-upgrade','upgrade','verify-upgrade','upgrade-restart','native','report','retention','integrate','integrated','core','core-report','cleanup']]],'required'=>['acao','cenario'],'additionalProperties'=>false],
 'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),
 'execute_callback'=>static function($i){
  if (!current_user_can('manage_options')) { return ['success'=>false]; }
  $root=rtrim(sys_get_temp_dir(),'/').'/f3-pipedrive-qa-0300-d848899a8f83-'.$i['cenario'];
  $prefix='f3pipqa_0300'.($i['cenario']==='current'?'c':'u').'_';$marker='f3-pipedrive-disposable-0300-d848899a8f83';
  if ($i['acao']==='setup') {
   if (file_exists($root) && (!is_file($root.'/marker')||trim(file_get_contents($root.'/marker'))!==$marker)) {return ['success'=>false,'code'=>'directory_conflict'];}
   if (!is_dir($root)) {mkdir($root,0700,true);file_put_contents($root.'/marker',$marker);}
   $zip=new ZipArchive();if ($zip->open(WP_CONTENT_DIR.'/f3-pipedrive-qa-0300.zip')!==true) {return ['success'=>false,'code'=>'zip_missing'];}
   for($n=0;$n<$zip->numFiles;$n++) { $name=$zip->getNameIndex($n);if (str_contains($name,'..')||str_starts_with($name,'/')) {throw new RuntimeException('Invalid package');} }
   $zip->extractTo($root);$zip->close();
   $wp=$root.'/wordpress';if(!is_dir($wp)){mkdir($wp,0700);}
   foreach (glob(ABSPATH.'*.php') as $f) {if (basename($f)==='wp-config.php') {continue;}if(!file_exists($wp.'/'.basename($f))){symlink($f,$wp.'/'.basename($f));}}
   foreach (['wp-admin','wp-includes'] as $dir) {if(!file_exists($wp.'/'.$dir)){symlink(ABSPATH.$dir,$wp.'/'.$dir);}}
   if(!is_dir($wp.'/wp-content/plugins')){mkdir($wp.'/wp-content/plugins',0700,true);}
   if(!is_dir($wp.'/wp-content/mu-plugins')){mkdir($wp.'/wp-content/mu-plugins',0700,true);}
   file_put_contents($wp.'/wp-content/mu-plugins/f3-qa-no-egress.php',"<?php add_filter('pre_http_request',static fn()=>new WP_Error('qa_egress_blocked','External HTTP disabled in disposable lab'),PHP_INT_MIN);add_filter('pre_wp_mail',static fn()=>true,PHP_INT_MIN);");
   foreach(['wp-mcp-fator3','base-site-core-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3'] as $slug){if(!file_exists($wp.'/wp-content/plugins/'.$slug)){symlink(WP_PLUGIN_DIR.'/'.$slug,$wp.'/wp-content/plugins/'.$slug);}}
   // Pipedrive is installed from the final ZIP by Plugin_Upgrader in the isolated runner.
   if(!file_exists($wp.'/wp-config.php')) {
    $cfg="<?php\n";
    foreach(['DB_NAME'=>DB_NAME,'DB_USER'=>DB_USER,'DB_PASSWORD'=>DB_PASSWORD,'DB_HOST'=>DB_HOST,'DB_CHARSET'=>'utf8mb4'] as $k=>$v){$cfg.='define('.var_export($k,true).','.var_export($v,true).");\n";}
    foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $k){$cfg.='define('.var_export($k,true).','.var_export(bin2hex(random_bytes(32)),true).");\n";}
    $cfg.="define('DISABLE_WP_CRON',true);\ndefine('WP_HTTP_BLOCK_EXTERNAL',true);\ndefine('WP_DEBUG',true);\ndefine('WP_DEBUG_LOG',true);\ndefine('WP_DEBUG_DISPLAY',false);\n";
    $cfg.='$table_prefix='.var_export($prefix,true).";\nif(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');\nrequire_once ABSPATH.'wp-settings.php';\n";
    file_put_contents($wp.'/wp-config.php',$cfg);chmod($wp.'/wp-config.php',0600);
   }
   return ['success'=>true,'setup'=>true,'main_plugins_unchanged'=>true];
  }
  if(!is_file($root.'/marker')||trim(file_get_contents($root.'/marker'))!==$marker){return ['success'=>false,'code'=>'marker_missing'];}
  if($i['acao']==='cleanup') {
   global $wpdb;$tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($prefix).'%'));$dropped=[];
   foreach($tables as $t){if(str_starts_with($t,$prefix)&&preg_match('/^[a-zA-Z0-9_]+$/D',$t)){if($wpdb->query('DROP TABLE `'.$t.'`')===false)throw new RuntimeException('Drop failed');$dropped[]=$t;}}
   $delete=static function($dir)use(&$delete){foreach(scandir($dir) as $x){if($x==='.'||$x==='..')continue;$p=$dir.'/'.$x;if(is_link($p)||is_file($p)){unlink($p);}elseif(is_dir($p)){$delete($p);}}rmdir($dir);};$delete($root);
   return ['success'=>true,'tables_remaining'=>count($wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($prefix).'%'))),'tables_removed'=>count($dropped),'directory_removed'=>!file_exists($root)];
  }
  $php=null;foreach([PHP_BINDIR.'/php','/usr/local/php83/bin/php','/usr/bin/php'] as $candidate){if(is_executable($candidate)){$php=$candidate;break;}}
  if(!$php||!function_exists('proc_open')){return ['success'=>false,'code'=>'cli_unavailable'];}
  $cmd=escapeshellarg($php).' '.escapeshellarg($root.'/runner.php').' '.escapeshellarg($i['acao']);
  $pipes=[];$proc=proc_open($cmd,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,$root);
  if(!is_resource($proc))return ['success'=>false,'code'=>'process_failed'];
  fclose($pipes[0]);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$code=proc_close($proc);
  $pos=strrpos($out,'F3_QA_RESULT=');$data=$pos===false?null:json_decode(trim(substr($out,$pos+13)),true);
  return ['success'=>$code===0&&is_array($data),'exit_code'=>$code,'result'=>$data,'stderr_bytes'=>strlen($err),'stderr_hint'=>$err?substr(preg_replace('~/(?:home|tmp)/[^ :\n]+~','[path]',$err),0,1200):null];
 },'meta'=>['fator3'=>['provider'=>'f3-pipedrive-qa030','version'=>'0.3.0','policy_contract'=>1,'mode'=>'write','local_effect'=>'write','remote_effect'=>'none'],'mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>true,'idempotent'=>false]]]);
},40);
