<?php
use Fator3\Pipedrive\{Api,CoreClient};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0300'))throw new RuntimeException('Isolated lab only');
wp_set_current_user(1);$checks=[];$check=static function($n,$v)use(&$checks){$checks[]=['name'=>$n,'passed'=>(bool)$v];};
$before=CoreClient::status()['orcamento']['consumido'];$calls=[];$error=false;
$filter=static function($pre,$args,$url)use(&$calls,&$error){
 $parts=wp_parse_url($url);$path=$parts['path']??'';
 if(($parts['host']??'')!=='api.pipedrive.com'||($args['method']??'GET')!=='GET')return new WP_Error('qa_block','Unexpected request');
 $calls[]=$path;$v2=str_starts_with($path,'/api/v2/');$data=[];
 if($path==='/v1/dealFields')foreach(['Parceiro','Unidade','Canal','Campanha','Ponto de conversão'] as $n=>$name)$data[]=['key'=>str_repeat((string)($n+1),40),'name'=>$name,'field_type'=>'enum','options'=>[]];
 $additional=$v2?['next_cursor'=>null]:['pagination'=>['more_items_in_collection'=>false]];
 return ['response'=>['code'=>$error?429:200],'headers'=>['x-daily-ratelimit-token-remaining'=>'9000'],'body'=>wp_json_encode($error?['success'=>false,'error'=>'PII_CANARY_CORE']:['success'=>true,'data'=>$data,'additional_data'=>$additional])];
};
add_filter('pre_http_request',$filter,100,3);
try{
 $i=['data_inicio'=>'2026-09-28','data_fim'=>'2026-10-27','limite_plano'=>1000];$r=Api::dispatch('relatorio',$i);
 $check('original_core_full_report',$r['success']&&($r['data']['completo']??false));
 $check('all_fixed_sources_reached',$calls===['/v1/dealFields','/v1/leads','/v1/leads/archived','/api/v2/deals','/api/v2/deals/archived']);
 $check('original_core_cost',$r['data']['custo']['gasto']===100&&CoreClient::status()['orcamento']['consumido']===$before+100);
 $check('original_core_usage_empty',$r['data']['uso_plano']['total']===0);
 $error=true;$r=Api::dispatch('relatorio',$i);
 $check('original_core_error_partial',$r['success']&&!$r['data']['completo']&&$r['data']['custo']['gasto']===20&&!str_contains(wp_json_encode($r),'PII_CANARY'));
 $check('original_core_error_debit',CoreClient::status()['orcamento']['consumido']===$before+120);
}finally{remove_filter('pre_http_request',$filter,100);}
return ['checks'=>$checks,'passed'=>count(array_filter($checks,fn($c)=>$c['passed'])),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'core_http_intercepted'=>count($calls),'supplier_http'=>0];
