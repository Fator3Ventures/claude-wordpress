<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
/** Business retention is independent of OAuth, cursor and confirmation lifetimes. */
final class Retention {
    public static function get(): array {
        $r=Store::get('settings','retention');
        return ($r['value']??['audit_mode'=>'unlimited','audit_days'=>30])+['revision'=>$r['revision']??0,'history_mode'=>'unlimited','new_connection_mode'=>'unlimited','legacy_connection_mode'=>'preserve'];
    }
    public static function upgrade(): void {
        if((int)Util::boot(Config::KEY.'_retention0110',0)===1)return;
        Store::lock('retention',static function(){
            if((int)get_option(Config::KEY.'_retention0110',0)===1)return;
            global $wpdb;$policy=self::get();
            if($policy['audit_mode']==='unlimited'&&$wpdb->query($wpdb->prepare('UPDATE %i SET expires_at=0 WHERE bucket=%s',Store::table(),'audit'))===false)throw new Fault('storage_unavailable','Não foi possível preservar a auditoria.');
            update_option(Config::KEY.'_retention0110',1,true);
        });
    }
    public static function auditExpiry(): int {$p=self::get();return $p['audit_mode']==='unlimited'?0:time()+$p['audit_days']*86400;}
    public static function save(array $i): array {
        Access::admin();Schemas::validate('save-retention',$i);self::upgrade();
        return Store::lock('retention',static function()use($i){
            global $wpdb;$old=self::get();if($i['expected_revision']!==$old['revision'])throw new Fault('revision_conflict','A política de retenção mudou. Releia a configuração.');
            $v=['audit_mode'=>$i['audit_mode'],'audit_days'=>$i['audit_days']??$old['audit_days']];
            $eligible=$v['audit_mode']==='finite'?(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE bucket=%s AND updated_at<%d',Store::table(),'audit',time()-$v['audit_days']*86400)):0;
            if($wpdb->last_error)throw new Fault('storage_unavailable','Prévia de retenção indisponível.');
            if($i['dry_run']??true)return ['persisted'=>false,'policy'=>$v,'eligible_for_removal'=>$eligible,'expected_revision'=>$old['revision']];
            return ConnectionChanges::transaction(static function()use($i,$v,$eligible){
                global $wpdb;$expiry=$v['audit_mode']==='unlimited'?'0':'updated_at+'.($v['audit_days']*86400);
                if($wpdb->query($wpdb->prepare('UPDATE %i SET expires_at='.$expiry.' WHERE bucket=%s',Store::table(),'audit'))===false)throw new Fault('storage_unavailable','Política de auditoria não confirmada.');
                Store::put('settings','retention',$v,$i['expected_revision']);
                return ['persisted'=>true,'policy'=>self::get(),'eligible_for_removal'=>$eligible,'removal'=>'subsequent_maintenance'];
            });
        });
    }
    public static function expiry(array $c,int $at): int {return ($c['retention_mode']??'finite')==='unlimited'?0:$at+(int)$c['retention_days']*86400;}
    public static function resultExpired(array $r,array $c): bool {$at=strtotime($r['value']['data']['fetched_at']??'')?:$r['updated_at'];$e=self::expiry($c,$at);return $e>0&&$e<time();}
    public static function terminalExpiry(array $job): int {
        try{return self::expiry(Connections::get($job['query']['connection_id']),time());}
        catch(Fault $e){if(!in_array($e->reason,['not_configured','cipher_unreadable','storage_corrupt'],true))throw $e;return 0;}
    }
    /** Called under the original job lock; preserve the proven unreadable-isolation path. */
    public static function pruneJob(string $key,array $r): int {
        $v=$r['value'];if(!in_array($v['status']??'', ['complete','partial','cancelled'],true))return 0;
        $id=$v['query']['connection_id']??null;if(!is_string($id))return 0;
        return Store::lock('connection:'.$id,static function()use($key,$r,$v,$id){
            try{$c=Connections::get($id);}catch(Fault $e){if(!in_array($e->reason,['not_configured','cipher_unreadable','storage_corrupt'],true))throw $e;return 0;}
            $expires=self::expiry($c,(int)($v['updated_at']??$r['updated_at']));
            if($expires===0||$expires>=time())return 0;Store::remove('job',$key,$r['revision']);return 1;
        });
    }
    /** Bounded keyset sweep also revisits records previously stored with no expiration. */
    public static function prune(): int {
        self::upgrade();return Store::lock('retention',static function(){
            global $wpdb;$removed=0;$p=self::get();
            if($p['audit_mode']==='finite'){
                $n=$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE bucket=%s AND updated_at<%d LIMIT 100',Store::table(),'audit',time()-$p['audit_days']*86400));
                if($n===false)throw new Fault('storage_unavailable','Falha na retenção da auditoria.');$removed+=$n;
            }
            foreach(['result','job'] as $bucket){
                $state=Store::get('retention_scan',$bucket);$after=$state['value']['after']??'';
                $keys=$wpdb->get_col($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s AND record_key>%s AND queue_state<>%s ORDER BY record_key LIMIT 25',Store::table(),$bucket,$after,'unreadable'));
                if($wpdb->last_error)throw new Fault('storage_unavailable','Falha na varredura de retenção.');
                foreach($keys as $key){$after=$key;
                    try{$r=Store::get($bucket,$key);if(!$r)continue;$id=$r['value']['query']['connection_id']??'';
                        $removed+=Store::lock('connection:'.$id,static function()use($bucket,$key,$id){return Store::lock('job:'.explode(':',$key)[0],static function()use($bucket,$key,$id){
                            global $wpdb;$r=Store::get($bucket,$key);if(!$r)return 0;$c=Connections::get($id);$v=$r['value'];
                            if($bucket==='result'&&Store::get('history_hold',$key))return 0;
                            if($bucket==='job'&&!in_array($v['status'],['complete','partial','cancelled'],true))return 0;
                            $at=$bucket==='result'?(strtotime($v['data']['fetched_at']??'')?:$r['updated_at']):(int)($v['updated_at']??$r['updated_at']);$expires=self::expiry($c,$at);
                            if($expires>0&&$expires<time()&&History::migrationComplete()&&$bucket==='result'){Store::remove($bucket,$key,$r['revision']);return 1;}
                            // Metadata-only CAS leaves the business observation time and revision intact.
                            if($wpdb->query($wpdb->prepare('UPDATE %i SET expires_at=%d WHERE bucket=%s AND record_key=%s AND revision=%d',Store::table(),$expires,$bucket,$key,$r['revision']))===false)throw new Fault('storage_unavailable','Prazo de retenção não confirmado.');return 0;
                        });});
                    }catch(Fault $e){if(!in_array($e->reason,['not_configured','cipher_unreadable','storage_corrupt','busy','revision_conflict'],true))throw $e;}
                }
                Store::put('retention_scan',$bucket,['after'=>count($keys)===25?$after:''],$state['revision']??0);
            }return $removed;
        });
    }
}
