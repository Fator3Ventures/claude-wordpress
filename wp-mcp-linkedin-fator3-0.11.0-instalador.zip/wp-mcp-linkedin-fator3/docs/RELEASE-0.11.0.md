# Fator3 MCP LinkedIn 0.11.0

Base aceita 0.10.1; nova rodada do pedido 14. Auditoria configurável (padrão sem prazo), resultados por conexão com modo finite/unlimited e acervo diário sem expiração para Pages e Ads. Nove operações aditivas, total de 90. Schema de registros 2 mantido; tabela histórica própria, schema 1. Leia HISTORY.md antes de migrar ou coletar retroativamente.

Preserva escolhas finitas existentes, identidade/credenciais, agendas e concessões. Mantém os contratos Lead Reader, entregas CAPI e auditoria central. Não exige alteração nem ordem de atualização nos acompanhantes Core 1.56.0, MCP 0.33.0, Google 0.19.0, Meta 0.12.0 e Pipedrive 0.1.0 examinados. A prova e seus limites constam no relatório externo da entrega.

A regressão de desenvolvimento identificou e corrigiu a integração da nova retenção com o isolamento concorrente de jobs ilegíveis. O caminho de Queue::isolateUnreadable e suas proteções de revisão/ciphertext continuam em uso. Os testes do pedido 12 fazem parte da validação desta versão.

Backfill é leitura de fornecedor. Dias ausentes e agregados não viram zeros nem séries inventadas. Testes com respostas interceptadas não homologam credenciais reais. A instalação não cria agendas nem inicia consultas comerciais automaticamente.
