# Autorização e renovação — 0.11.0

Token manual continua sendo padrão. O novo fluxo OAuth pelo navegador é opcional e usa retorno no próprio site: `https://SEU-SITE/wp-admin/admin-post.php?action=f3_linkedin_oauth_callback`. Cadastre exatamente esse endereço no aplicativo do LinkedIn. Sem token inicial, salve a conexão pausada com Client ID e Primary Client Secret; selecione as permissões necessárias e clique Autorizar no LinkedIn. O retorno exige sessão administrativa atual e state aleatório, de uso único, vinculado a usuário, sessão, conexão e revisão, com validade de dez minutos. O endereço público da autorização sai em `consent_url`; os tokens nunca saem na resposta.

O aplicativo só recebe refresh token quando o programa/produto e a aprovação do LinkedIn permitem. O fluxo não promete renovação para aplicativos sem essa habilitação. Troca de código e refresh são POST HTTPS sem redirecionamento. Tokens e segredo são armazenados cifrados; configuração pública informa apenas disponibilidade, validade e geração.

`save-connection` adiciona refresh_token, refresh_expires_at e clear_refresh_token. Campo vazio preserva o segredo salvo; remoção é explícita. Alterar manualmente token, ID ou segredo do app limpa o refresh anterior se não vier novo refresh na mesma gravação, impedindo associação silenciosa à credencial antiga. Salvar somente nome/configuração após renovação mantém o token efetivo novo.

## Renovação e observação

Manutenção horária tenta renovar a partir de três dias antes de expires_at. O cron depende de tráfego ou cron real. `refresh-token` permite tentativa administrativa com expected_revision. Expiração desconhecida (0) não permite agendar aviso/renovação; informe a validade ou autorize pelo fluxo. Conexão pausada não renova. Exige administrador responsável ainda autorizado.

Em sucesso, primeiro confere o novo token por introspecção, incluindo os quatro escopos de leitura, Client ID e validade, e só então guarda token/validade e refresh. Uma identidade legível divergente é recusada. A continuidade sem membro legível decorre do refresh grant vinculado, não de um nome inferido. Usa sobreposição cifrada ligada ao token/app-base: incrementa credential_generation e conserva a revisão de autorização da conexão. Assim permanecem seleções, concessões, cursores, agendas e diário de assinaturas existentes. Nenhuma chamada de criação de assinatura é feita. Prévia de escrita emitida antes da troca de geração deve ser refeita.

Em falha, conserva o token atual e abre incidente local, com código sanitizado, contador e próxima tentativa. Retentativa: 5 minutos em progressão exponencial limitada a um dia; a manutenção horária determina quando de fato ocorre. Envia aviso a admin_email com deduplicação por validade/tipo. Falha de e-mail fica registrada e permite nova tentativa após um dia. Nunca inclui segredo no e-mail.

Sem refresh, o painel mostra dias restantes e disponibilidade; a manutenção avisa admin_email quando entrar nas janelas de 14 e 3 dias, e após vencimento. Se o site ficar sem cron e saltar uma janela, envia o aviso correspondente ao prazo observado, sem inventar envio retroativo.

`linkedin/status.data.access_lifecycle` informa connections (connection_id, days_remaining, expires_at, refresh_configured, refresh_expires_at, credential_generation, last_refresh_at, last_result, failures, next_attempt, incident, notices, scopes), next_maintenance e oauth_callback. `inspect-token` confere os quatro escopos, Client ID e validade, atualiza a prova ligada à tupla vigente e a validade efetiva; status não chama o LinkedIn. Secrets nunca são preenchidos no formulário.

Nova autorização OAuth é conferida e guardada como candidata cifrada por dez minutos, sem substituir a ativa. Reabra a conexão, marque “Usar a autorização OAuth conferida” e salve ou simule a troca. A candidata só pode ser usada pelo administrador que autorizou e na revisão original. Não exporta tokens. A confirmação repete a conferência. O state continua de uso único, inclusive se a conferência falhar.

## Conferência e troca guiada — pedido 13

Credencial nova exige o par Access Token / Client ID / Primary Client Secret completo e introspecção ativa com r_ads, r_ads_reporting, r_organization_admin e r_organization_social. Client ID divergente, validade ausente/expirada, par recusado ou escopo ausente preservam a conexão e os vínculos salvos. A validade digitada é substituída pela validade conferida. Campos de segredo vazios preservam o salvo. Formatos: Access Token com pelo menos cem caracteres e sem espaços; Client ID alfanumérico e não somente numérico; Primary Client Secret com menos de cem caracteres e diferente do token/Client ID; App ID numérico; Refresh Token diferente do Access Token. O mínimo de cem caracteres é a política deste projeto, não uma garantia universal da API.

A introspecção **não retorna nome do aplicativo nem membro**. O nome do aplicativo vem da parte após · no nome da conexão, identificado como informado pelo administrador. Client ID, validade e escopos vêm da introspecção. Quando openid e profile já estiverem autorizados, userinfo fornece o membro; seu subject é comparável somente dentro do mesmo Client ID. Não se acrescentam essas permissões automaticamente. Ausência/falha de userinfo não vira prova de mesma identidade. A tela informa “Membro não informado pelo LinkedIn” e destaca escopos de escrita.

`save-connection` aceita `dry_run=true`. Retorna `persisted=false`, `identity_change_required`, `identity`, `affected` (agendas e concessões) e `confirmation` opaca com validade de dez minutos. Confirme reenviando exatamente a candidata/revisão com `confirmation`, `reconfirm_leads` e `reconfirm_conversions` quando houver concessões ativas. A prova é ligada à candidata, membro/Client ID/escopos conferidos, administrador, revisão e revisões dos vínculos. Alteração de qualquer um exige nova simulação. Não enviar confirmação como chave de idempotência de transporte.

Token de outro membro/aplicativo, ou token novo sem prova de mesma identidade, exige esse caminho. A seleção de ativos, formulários, usuários e versão API é mantida na troca. A tela reconfirma concessões explicitamente; CAPI reconfere papel, escopos e regra ativa CONVERSIONS_API; Lead Sync exige seu escopo e conserva permissões/formulários. Isso não substitui o teste de acesso aos formulários reais. Concessões desativadas não são reativadas. Identidade nova invalida planos em execução e identidades de serviço anteriores; o diário é preservado e pode exigir reconciliação pelo contrato existente. Agendas recebem a revisão nova sem reativação de pausas manuais.

Nome/segredo e token comprovadamente do mesmo membro/aplicativo preservam autorização; geração muda com a tupla. A conexão, agendas vigentes e concessões vigentes são regravadas atomicamente por CAS numa transação InnoDB. Histórico local conserva as últimas vinte alterações, administrador, revisões e agendas regravadas, sem credenciais. Mudança de seleção mantém a exigência de reconfirmar concessões; não recupera concessão já conflitante. Cursores de SDK e operações iniciadas antes de uma gravação manual continuam sujeitos à revisão do contrato e devem ser relidos; não se reescrevem recibos nem trabalhos já iniciados.

Referências oficiais consultadas em 23/10/2026: https://learn.microsoft.com/en-us/linkedin/shared/authentication/token-introspection e https://learn.microsoft.com/en-us/linkedin/consumer/integrations/self-serve/sign-in-with-linkedin-v2 .

## Recuperação

Confira incidente e próxima tentativa, produtos/escopos liberados, segredo do app e validade do refresh. Reautorize quando necessário. Não remova concessões ou diário para sanar timeout. Preserve as salts do WordPress junto do backup cifrado. Voltar a 0.4.1 ignora a sobreposição renovada; pode voltar ao token-base antigo. Antes de rollback, faça backup completo e planeje credencial manual válida/reautorização; consulte MIGRATION.md.

Consulte FIELD-HELP.md para nomes exatos. O escopo rw_conversions foi acrescido ao consentimento opcional; r_ads também é obrigatório para CAPI. Conceder Lead Sync não concede conversões.

## Correção 0.10.1: origem do Refresh Token

Um Refresh Token colado manualmente não comprova vínculo com o Access Token salvo. Na primeira renovação, se não houver prova de mesmo membro, o novo par fica como candidata cifrada por dez minutos; a credencial ativa permanece em uso e a tela exige simulação/confirmação. Somente um par emitido na mesma resposta OAuth/refresh e aceito pelo fluxo passa a fornecer continuidade para renovações seguintes sem membro legível. Trocar manualmente o refresh desfaz esse vínculo. Membro legível divergente sempre exige troca guiada.
