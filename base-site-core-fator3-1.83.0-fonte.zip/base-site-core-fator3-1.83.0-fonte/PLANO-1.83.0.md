# Plano da 1.83.0

Base 1.82.0. Pedidos 396 e 397. Acrescentar o perfil privado da primeira observação, retenção, filtro de audiência e qualidade, ficha do contato e mapeamento de CRM. Centralizar os papéis dos parâmetros, preservar ref, verificar leitura de configuração e purga por site. Rodar instalação limpa, atualização direta, regressões, fronteiras de consentimento e verificação dos ZIPs. O Implantador precisa consumir o contrato vigente do Core e evitar repor a lista antiga.
