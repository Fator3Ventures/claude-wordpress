# Fator3 Site Core 1.82.0 · 13/11/2026

Base oficial 1.81.1. Regras do projeto na revisão 5. Instalação nova e atualização da base em WordPress 7.1.4 e PHP 8.3 de 64 bits. A referência de 13/11 inclui MCP 0.45.0, Google 0.34.0, Meta 0.25.0, LinkedIn 0.22.0 e Pipedrive 0.10.0.

1. Migrar as options do anúncio para o registro do contato, verificar a rota de detalhe, preservação de IDs do CRM, expiração e exclusão (392).
2. Publicar a consulta tardia na thread original, comprovar o compartilhamento por leitura do Slack e resolver o nome inicial da campanha pelos dados locais (394).
3. Incorporar o pedido posterior 395 em substituição ao 393. Testar a entrada, a origem e o prefixo de teste, inclusive a atualização tardia que preserva o corpo e o ts.
4. Exercitar o worker com os SDKs vigentes. Os três pedidos alteram o Core. As concessões e a comprovação visual na conta do dono entram no relatório da rodada.
5. Conferir as árvores, instalar no Site-Teste, validar leitura documental, saúde, versão e matriz de convivência, fechar o fonte e o relatório.
