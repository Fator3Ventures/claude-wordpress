# Fator3 MCP Meta 0.30.0

Atualização direta da 0.29.0. Pedidos MCP Meta 32 — elegibilidade dos insights do Instagram. Edite build/meta, build/common e build/docs/meta. O runtime instalado fica em plugin/wp-mcp-meta-fator3; provas desta edição em evidence/030, anteriores em pastas numeradas. Ver o relatório e tests/README.md.
