# Padrão de entrega — Fator3 MCP Meta (wp-mcp-meta-fator3)

Para o agente responsável pelo Fator3 MCP Meta. Vale a partir da próxima versão; a regra comum aos pacotes está na aba "Regra comum", e o essencial vai repetido aqui. O Fator3 MCP Meta e o Fator3 MCP LinkedIn saem com arquivos e relatórios separados, também quando são entregues juntos.

## Arquivos

| tipo | nome | conteúdo |
| --- | --- | --- |
| instalador | `wp-mcp-meta-fator3-<versão>-instalador.zip` | pasta interna `wp-mcp-meta-fator3/`, arquivo principal `wp-mcp-meta-fator3/wp-mcp-meta-fator3.php` |
| fonte | `wp-mcp-meta-fator3-<versão>-fonte.zip` | pasta interna `wp-mcp-meta-fator3-<versão>-fonte/`: código, build, suíte de testes, evidências, manifesto e uma cópia do relatório |
| relatório | `wp-mcp-meta-fator3-<versão>-relatorio.md` | Markdown, em português, só deste pacote |

Versão `X.Y.Z`, sem sufixo; homologação e sha256 só dentro do relatório.

## Cabeçalho e tela

| campo | valor |
| --- | --- |
| Plugin Name | Fator3 MCP Meta |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | Instagram profissional e Páginas do Facebook pelo Facebook Login: perfil, mídias, Stories, insights, demografia e histórico, com coletas agendadas e exportação em CSV e JSON, pela Abilities API e pelo Fator3 MCP. Meta Ads somente leitura, com histórico diário e SDK local. Pixel, CAPI e contatos ficam no Fator3 Site Core. Configuração em Ferramentas → Fator3 MCP Meta. |
| Requires at least, Requires PHP | os validados pela versão (0.21.0: 7.1.4 e 8.3, 64 bits) |
| Author | Fator3 |
| Author URI | `https://www.fator3.com.br` |
| License | GPL-2.0-or-later |
| Text Domain | `wp-mcp-meta-fator3` |
| Update URI | `https://fator3.com.br/plugins/wp-mcp-meta-fator3` |
| tela | Ferramentas → Fator3 MCP Meta, com `manage_options` |

Se o escopo mudar, a descrição muda junto, no mesmo formato.

**Capacidade.** A tela e as operações que leem dado da conta conectada pedem `manage_options`.

## O que não muda

Slug e pasta `wp-mcp-meta-fator3`, arquivo principal, Text Domain, Update URI, a option `f3_meta`, a tabela `f3_meta_records`, a rota REST `f3-meta/v1`, os nomes das rotas `meta/*` já publicadas e o contrato de `meta/save-connection` (`expected_revision`, ativos `instagram`, `facebook` e `ads`).

## Relatório

Nesta ordem:

1. Título `Entrega — Fator3 MCP Meta <versão>`.
2. De onde a versão entra (WordPress limpo e as versões aceitas direto) e as versões do Fator3 MCP e do Site Core com que foi validada.
3. Escopo: o que o pacote lê e o que fica fora (escrita em anúncios, pixel, CAPI e leads nativos ficam no Site Core).
4. O que mudou, citando cada "Pedidos MCP Meta N" atendido, com a evidência.
5. Prova da troca: `meta/status` e `system/health` do canal com o estado esperado.
6. Conexão: o que o dono cola na tela (só senha e segredo) e o que o agente preenche, escolhe e confirma nela, permissões pedidas à Meta, versão da Graph API; nenhum segredo.
7. O que não foi homologado (conta real, métricas por versão, coleta agendada).
8. Identidade: nome, tamanho e sha256 do instalador e da fonte.

## Conformidade da 0.21.0 (09/11/2026)

Lida no `main` (commit `e3580d3`): instalador `wp-mcp-meta-fator3-0.21.0-instalador.zip` (243.040 bytes, sha256 `9589456a…`) com a pasta `wp-mcp-meta-fator3/` e o arquivo principal; fonte `wp-mcp-meta-fator3-0.21.0-fonte.zip` (672.186 bytes, sha256 `d53c738b…`) com a pasta `wp-mcp-meta-fator3-0.21.0-fonte/`; os dois sha256 no relatório, só deste pacote, iguais aos dos arquivos; nenhum ZIP dentro de outro. Título `Entrega — Fator3 MCP Meta 0.21.0`; cabeçalho, descrição e tela como acima. Nenhum pedido aberto sobre a entrega.
