# Pedidos — Fator3 MCP Meta (wp-mcp-meta-fator3)

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-meta-fator3**. Cite como "Pedidos MCP Meta N". Próximo número: 33; número retirado fica vago.

## wp-mcp-meta-fator3 — pendentes

### 32. Agendas de público do Instagram deixam `meta/health` em `degraded` em conta abaixo do mínimo de seguidores da Meta (aberto em 19/11/2026)

**Visto.** Meta 0.29.0, em 19/11/2026 entre 03:31 e 03:40 −03, `meta/health` e `meta/history-query`.

**Extrato.** Em twinia, engagia, conselar, fator3ventures, fator3grupo, korvena.com.br e ctooffice, as agendas `ig-publico-cidade`, `-genero`, `-idade` e `-pais` falham com `fields_unavailable` / `empty_or_suppressed` (`follower_demographics`, causa indeterminada) e `ig-conta-diario` sai parcial (`follows_and_unfollows`): `state` `degraded`, `failed_schedules` 4. Contas: @conselar.assistente 11 seguidores, @fator3ventures 19, @grupofator3 30. A própria mensagem do pacote cita o limite de 100 seguidores da Meta para dados demográficos, sem confirmar. Com o estado `degraded` permanente, uma falha nova de outra agenda não se distingue na conferência (Para a frota CSL-1911, F3G-1911, F3V-1911).

**Pedido.** (1) Quando a resposta da Meta for vazia ou suprimida por limite de seguidores (contagem lida no perfil abaixo do mínimo), classificar a passagem como `nao_aplicavel` com o motivo e a contagem, sem contar em `failed_schedules` nem degradar `meta/health`. (2) Voltar a tentar sozinho quando a conta passar do mínimo. (3) Separar em `meta/health` o parcial esperado (`follows_and_unfollows` indisponível) do parcial por falha.

**Aceite.** Em conselar e fator3grupo, `meta/health` `ok` com as quatro agendas `nao_aplicavel` e a contagem de seguidores; numa conta acima do mínimo (fator3.com.br), as agendas de público seguem coletando.
