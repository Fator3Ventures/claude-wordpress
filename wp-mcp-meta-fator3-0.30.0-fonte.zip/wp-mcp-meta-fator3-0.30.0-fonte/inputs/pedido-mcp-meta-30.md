# Pedidos — Fator3 MCP Meta (wp-mcp-meta-fator3)

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-meta-fator3**. Cite como "Pedidos MCP Meta N". Próximo número: 31; número retirado fica vago.

## wp-mcp-meta-fator3 — pendentes

**30 (14/11/2026, os 12 sites, P3; dono, 14/11/2026 às 11:03, no chat do Orquestrador | Geral: "Peça esse mesmo padrão visual a todas as telas de todos os plugins"). Conferência de todas as telas do MCP Meta contra o padrão visual das telas.** Padrão: Padrão de entrega dos pacotes Fator3, aba Regra comum, "Padrão visual das telas". As telas do MCP Meta 0.26.0 e do MCP LinkedIn 0.23.0 são a referência desse padrão: mudança visual futura nelas muda o padrão só com ordem do dono. Lidas em fator3.com.br em 14/11 por volta das 11h −03: Configurar → Conexão e Dados → Relatórios, a 1440 e a 750 px, conformes. Pedido: conferir as outras abas (Configurar: Ativos e Consumidores de anúncios; Dados: Coletas, Histórico, Conversas e Arquivo de Stories; Suporte) contra os oito itens do padrão, corrigir o que divergir e entregar capturas de cada aba a 360, 768 e 1440 px. Não mudam slug, capacidade, rotas e dados.
