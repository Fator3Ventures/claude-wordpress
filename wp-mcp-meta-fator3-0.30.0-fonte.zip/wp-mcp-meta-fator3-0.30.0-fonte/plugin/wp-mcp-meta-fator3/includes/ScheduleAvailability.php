<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Eligibility of a collection; never changes the supplier value or the next due date. */
final class ScheduleAvailability {
    private const MIN_FOLLOWERS = 100;
    private const EMPTY_CODES = ['empty_or_suppressed','value_unavailable'];

    public static function emptyMetric(array $error,string $metric): bool {
        return ($error['field']??null)===$metric && in_array($error['code']??null,self::EMPTY_CODES,true);
    }

    /** An empty breakdown envelope is a gap; a bucket or a total equal to zero is useful. */
    public static function emptyBreakdown(mixed $total): bool {
        if($total===null)return true;
        if(!is_array($total))throw new Fault('upstream_invalid','Total de insights inválido.');
        $value=$total['value']??null;$groups=$total['breakdowns']??[];
        if(($value!==null&&!is_numeric($value))||!is_array($groups)||!array_is_list($groups))
            throw new Fault('upstream_invalid','Detalhamento de insights inválido.');
        $hasValue=$value!==null;
        foreach($groups as $group){
            if(!is_array($group)||!is_array($group['results']??null)||!array_is_list($group['results']))
                throw new Fault('upstream_invalid','Detalhamento de insights inválido.');
            foreach($group['results'] as $bucket){
                if(!is_array($bucket)||!is_numeric($bucket['value']??null))throw new Fault('upstream_invalid','Valor de insights inválido.');
                $hasValue=true;
            }
        }
        return !$hasValue;
    }

    /** Probe only after a successful, empty follower-demographics read on the same selected IG account. */
    public static function observeAudience(array $connection,string $account,array &$page): void {
        if(count($page['errors'])!==1 || !self::emptyMetric($page['errors'][0],'follower_demographics')
            || array_filter($page['rows'],[CollectionState::class,'useful']))return;
        $p=Http::request($connection,$account,['fields'=>'id,followers_count'])['body'];
        if((string)($p['id']??'')!==$account)throw new Fault('upstream_invalid','O perfil de conferência não corresponde à conta da consulta.');
        $count=$p['followers_count']??null;
        if(!is_int($count)||$count<0||$count>=self::MIN_FOLLOWERS)return;
        $proof=['kind'=>'nao_aplicavel','reason'=>'below_minimum_followers','followers_count'=>$count,
            'minimum_followers'=>self::MIN_FOLLOWERS,'account_id'=>$account,'observed_at'=>time()];
        $page['errors'][0]['eligibility']=$proof;
        foreach($page['rows'] as &$row){
            $row['diagnostic']['eligibility']=$proof;
            $row['diagnostic']['message']='O perfil tem '.$count.' seguidores; o mínimo para esta consulta é '.self::MIN_FOLLOWERS.'.';
        }
        unset($row);
        $page['errors'][0]['message']=$page['rows'][0]['diagnostic']['message'];
    }

    /** Count every error, including those that do not fit the diagnostic sample. */
    public static function followGaps(array $errors): int {
        return count(array_filter($errors,static fn($e)=>self::emptyMetric($e,'follows_and_unfollows')));
    }

    public static function assessment(array $job,array $coverage): ?array {
        if($job['last_code']!=='fields_unavailable'||empty($coverage['plan_complete'])||$job['query']['channel']!=='instagram')return null;
        $n=(int)($coverage['error_count']??0);
        if($n<1)return null;
        if($job['query']['report']==='audience' && $n===1 && $job['successful_rows']===0){
            $e=$coverage['errors'][0]??[];$p=$e['eligibility']??null;
            if(self::emptyMetric($e,'follower_demographics') && ($p['kind']??null)==='nao_aplicavel'
                && ($p['account_id']??null)===$job['query']['account_id'])return $p;
        }
        if($job['query']['report']==='account_insights' && $job['successful_rows']>0 && ($coverage['follow_gap_count']??null)===$n)
            return ['kind'=>'parcial_esperado','reason'=>'follows_and_unfollows_unavailable','metric'=>'follows_and_unfollows'];
        return null;
    }
}
