<?php
use Fator3\Meta as M;
define('DOING_CRON',true);require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$hook=M\Config::KEY.'_worker';$checks=[];$actual=[];$sensor='WSAL\\WP_Sensors\\WP_System_Sensor';
function ck28($n,$x){global $checks;$checks[]=['name'=>$n,'passed'=>(bool)$x];}
ck28('Sensor real carregado e observador de remoção presente',class_exists($sensor,false) && has_filter('pre_unschedule_event',[$sensor,'removed_cron_job'])===PHP_INT_MAX);
$seed=static function($at,$args=[],$rec=false)use($hook){$cron=_get_cron_array();$cron[$at][$hook][md5(serialize($args))]=['schedule'=>$rec,'args'=>$args]+($rec?['interval'=>3600]:[]);uksort($cron,'strnatcasecmp');_set_cron_array($cron,true);};
$reset=static function()use($hook){$cron=_get_cron_array();foreach($cron as $t=>&$hooks){unset($hooks[$hook]);if(!$hooks)unset($cron[$t]);}unset($hooks);_set_cron_array($cron,true);};
foreach(['normal','exact','absent','other_time','other_args','recurring','veto'] as $case){
 $reset();
 // The real sensor remains registered. Inject a result *after* all observers
 // for the post-write error tests; this does not fake wp_get_scheduled_event().
 $cb=static function($pre,$event)use($case,$seed,$hook){if($event->hook!==$hook||$case==='normal')return $pre;
  if($case!=='absent')$seed($event->timestamp+($case==='other_time'?1:0),$case==='other_args'?['x']:[],$case==='recurring'?'hourly':false);
  return new WP_Error($case==='veto'?'qa_veto':'could_not_set');};
 add_filter('pre_schedule_event',$cb,PHP_INT_MAX,2);
 $r=M\Jobs::scheduleTickResult();remove_filter('pre_schedule_event',$cb,PHP_INT_MAX);
 $v=get_option('f3_meta_worker_schedule_attempt',[]);$actual[$case]=['result'=>$r,'receipt'=>$v];
 $wanted=in_array($case,['normal','exact'],true);
 ck28('Criação '.$case,$r['scheduled']===$wanted && $r['code']===($wanted?'ok':($case==='veto'?'qa_veto':'could_not_set')));
 if($case==='exact')ck28('Recibo distingue retorno nativo e ocorrência exata',($v['native_code']??null)==='could_not_set' && ($v['exact_event']??false)===true);
}
$reset();$before=get_option('f3_meta_last_worker',null);
$deny=static fn($pre,$e)=>$e->hook==='f3_meta_worker'?new WP_Error('qa_veto'): $pre;
add_filter('pre_schedule_event',$deny,5,2);$res=M\Jobs::scheduleTickResult();remove_filter('pre_schedule_event',$deny,5);
ck28('Sensor tardio não apaga veto de criação',$res===['scheduled'=>false,'code'=>'qa_veto'] && !wp_next_scheduled($hook));
$reset();$t=time()+60;$seed($t);$deny=static fn($pre,$ts,$h)=>$h==='f3_meta_worker'?new WP_Error('qa_remove_veto'):$pre;
add_filter('pre_unschedule_event',$deny,5,3);$r=wp_unschedule_event($t,$hook,[],true);remove_filter('pre_unschedule_event',$deny,5);
ck28('Veto de remoção preserva erro e ocorrência',is_wp_error($r)&&$r->get_error_code()==='qa_remove_veto'&&(bool)wp_get_scheduled_event($hook,[],$t));
$reset();$seed($t);
$falseSuccess=static fn($pre,$ts,$h)=>$h==='f3_meta_worker'?true:$pre;
add_filter('pre_unschedule_event',$falseSuccess,5,3);$r=wp_unschedule_event($t,$hook,[],true);remove_filter('pre_unschedule_event',$falseSuccess,5);
ck28('Não confirma uma remoção anunciada sem persistência', is_wp_error($r) && $r->get_error_code()==='could_not_set' && (bool)wp_get_scheduled_event($hook,[],$t));
$reset();$seed($t);$r=M\Jobs::scheduleTickResult();
ck28('Worker presente é reaproveitado sem duplicar',$r['scheduled']&&wp_next_scheduled($hook)===$t);
ck28('Recibo de agenda não inventa passagem do executor',get_option('f3_meta_last_worker',null)===$before);
$reset();$failed=count(array_filter($checks,fn($c)=>!$c['passed']));echo wp_json_encode(compact('checks','actual','failed')+['total'=>count($checks),'version'=>M\Config::VERSION])."\n";exit($failed?1:0);
