<?php
use Fator3\Meta as M;use Fator3\McpFiles\Persistence as P;use Fator3\McpFiles\ConnectionContext as C;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
$s=get_option('lab031');$q=$s['q'];$checks=[];$ck=static function($name,$ok)use(&$checks){if(!$ok)throw new RuntimeException($name);$checks[]=$name;};
$a=['user_id'=>1,'grant_id'=>'current-a','profile'=>'maintenance','status'=>'active','expires'=>time()+3600];P::put('oauth-grants',$a['grant_id'],$a,true);C::oauth($a);wp_set_current_user(1);
$i=['query'=>$q,'idempotency_key'=>'same-key-current'];
$j=M\Jobs::create($i);$day=gmdate('Y-m-d',time()-86400);$spec=['query'=>$q+['date_from'=>$day,'date_to'=>$day],'idempotency_key'=>'same-backfill-current'];$bf=M\History::backfill($spec);
$ex=['query'=>$q,'format'=>'csv','idempotency_key'=>'same-export-current'];$hx=M\HistoryExport::create($ex);
$saved=M\Schedules::save(['schedule_id'=>'current-a','enabled'=>true,'label'=>'Current schedule','interval_minutes'=>60,'expected_revision'=>0,'query'=>$q,'next_at'=>time()-1]);
$before=M\Store::get('schedule','current-a');$a['status']='revoked';P::put('oauth-grants',$a['grant_id'],$a);$after=M\Store::get('schedule','current-a');
$ck('Revoking A changes no schedule bytes/revision',M\Util::same($before,$after));
$ck('Revoked active transport cannot read existing job',M\Result::run(fn()=>M\Jobs::status($j['job_id']))['code']==='not_authorized');
C::oauth($s['b']);wp_set_current_user(1);
$ck('Job creation replay under B returns original site job',M\Jobs::create($i)['job_id']===$j['job_id']);
$ck('Backfill replay under B returns original site job',M\History::backfill($spec)['job_id']===$bf['job_id']);
$ck('Export replay under B returns original site export',M\HistoryExport::create($ex)['export_id']===$hx['export_id']);
add_filter('pre_http_request',static fn()=>['response'=>['code'=>200],'headers'=>[],'body'=>'{"id":"3101","name":"test"}'],1);
C::restore_identity(null,0);M\Jobs::tick();C::oauth($s['b']);wp_set_current_user(1);
$row=array_column(M\Schedules::list(),null,'schedule_id')['current-a'];
$ck('Schedule saved by A executes after B without changing edit revision',$row['revision']===$saved['revision']&&M\Jobs::status($row['last_job'])['status']==='complete');
$ck('Backfill A collects after B',M\Jobs::status($bf['job_id'])['status']==='complete');
C::restore_identity(null,0);$admins=get_users(['capability'=>'manage_options']);foreach($admins as $u)$u->set_role('subscriber');
try{$out=M\Result::run(fn()=>M\SiteOwner::executor(['user_id'=>1,'channel'=>null]));$ck('No administrator fails closed',$out['code']==='not_authorized');}finally{foreach($admins as $u)$u->set_role('administrator');}
echo wp_json_encode(['checks'=>$checks,'total'=>count($checks)])."\n";
