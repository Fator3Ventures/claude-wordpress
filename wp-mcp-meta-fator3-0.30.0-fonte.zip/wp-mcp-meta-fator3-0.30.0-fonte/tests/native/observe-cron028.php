<?php
/* Only installed in the explicitly guarded, disposable WordPress database. */
if(!defined('ABSPATH')||!getenv('F3_LAB_ROOT')||ABSPATH!==getenv('F3_LAB_ROOT').'/wordpress/'||!preg_match('/^f3qa022_[a-f0-9]{12}_$/D',$GLOBALS['table_prefix']??''))return;
if(!defined('DOING_CRON') || !DOING_CRON)return;
add_filter('pre_http_request',static function($pre,$args,$url){
 if(parse_url($url,PHP_URL_HOST)!=='graph.facebook.com'||!str_ends_with((string)parse_url($url,PHP_URL_PATH),'/777028'))return $pre;
 return ['headers'=>[],'response'=>['code'=>200,'message'=>'fixture'],'body'=>'{"id":"777028","name":"Perfil de laboratório"}','cookies'=>[]];
},1,3);
add_filter('pre_unschedule_event',static function($pre,$ts,$hook,$args){
 if($pre!==null||$hook!=='f3_meta_worker'||$args!==[]||(int)$ts!==(int)get_option('f3qa028_at'))return $pre;
 // A preceding scheduler handler persists the native delta and returns its real verdict.
 $cron=_get_cron_array();if(!isset($cron[$ts][$hook][md5(serialize($args))]))return $pre;
 unset($cron[$ts][$hook][md5(serialize($args))]);if(!$cron[$ts][$hook])unset($cron[$ts][$hook]);if(!$cron[$ts])unset($cron[$ts]);
 $r=_set_cron_array($cron,true);update_option('f3qa028_removed',$r===true,false);return $r;
},5,4);
add_action('cron_unschedule_event_error',static function($err,$hook){if($hook==='f3_meta_worker')update_option('f3qa028_error',$err->get_error_code(),false);},10,2);
add_action('f3_meta_worker',static function(){update_option('f3qa028_calls',1+(int)get_option('f3qa028_calls',0),false);},1);
