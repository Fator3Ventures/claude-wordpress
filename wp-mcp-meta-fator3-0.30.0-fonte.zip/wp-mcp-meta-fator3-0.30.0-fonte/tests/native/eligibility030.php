<?php
/** Isolated WordPress, real schedule/queue/storage, simulated Graph responses. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);require __DIR__.'/seed-connection090.php';
$checks=[];$count=11;$aud='empty';$daily='gap';$calls=0;$probes=0;$tickAt=time()-5000;
function ck30(string $name,bool $ok):void{global $checks;$checks[]=['name'=>$name,'passed'=>$ok];if(!$ok)fwrite(STDERR,"Failed: $name\n");}
function h30():array{return M\Api::dispatch('health')['data'];}
function sv30(string $id):array{return M\Store::get('schedule',$id)['value'];}
function run30(string $id):array{global $tickAt;$r=M\Store::get('schedule',$id);$v=$r['value'];$v['next_at']=++$tickAt;M\Schedules::checkpoint(['key'=>$id]+$r,$v);M\Schedules::tick();$key=sv30($id)['last_job'];for($i=0;$i<10;$i++){$r=M\Jobs::run($key,true);if($r['status']!=='queued')return $r;$r=M\Store::get('job',$key);$v=$r['value'];$v['next_at']=time()-1;M\Store::put('job',$key,$v,$r['revision']);}throw new RuntimeException('nonterminal collection');}
$resp=static fn($b,$s=200)=>['headers'=>[],'body'=>wp_json_encode($b),'response'=>['code'=>$s]];
add_filter('pre_http_request',static function($pre,$args,$url)use(&$aud,&$daily,&$count,&$calls,&$probes,$resp){
 ++$calls;$path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);
 if($path==='/v24.0/31030' && ($q['fields']??null)==='id,followers_count'){
  ++$probes;if($aud==='profile_error')return $resp([],503);return $resp(['id'=>$aud==='wrong'?'123':'31030','followers_count'=>$count]);
 }
 if($path!=='/v24.0/31030/insights')return new WP_Error('unexpected_endpoint');
 $rows=[];foreach(explode(',',$q['metric']) as $m){
  if($m==='follower_demographics'){
   if($aud==='reject')return $resp(['error'=>['code'=>100,'message'=>'Unavailable field']],400);
   if($aud==='outage')return $resp([],503);
   if(in_array($aud,['breakdown_empty','available','malformed'],true))$rows[]=['name'=>$m,'total_value'=>['breakdowns'=>[['results'=>match($aud){'available'=>[['dimension_values'=>['example'],'value'=>0]],'malformed'=>[['dimension_values'=>['bad']]],default=>[]}]]]];
  }elseif($m==='follows_and_unfollows'){
   if($daily==='empty_breakdown')$rows[]=['name'=>$m,'total_value'=>['breakdowns'=>[['results'=>[]]]]];
   if($daily==='bad_shape')$rows[]=['name'=>$m,'total_value'=>'bad'];
   if($daily==='reject')return $resp(['error'=>['code'=>100,'message'=>'Invalid metric']],400);
  }elseif($m==='views' && $daily==='mixed'){continue;}
  else $rows[]=['name'=>$m,'total_value'=>['value'=>0]];
 }return $resp(['data'=>$rows]);
},1,3);
lab_seed_connection090(['connection_id'=>'eligible030','expected_revision'=>0,'token'=>'fixture-030','assets'=>['instagram'=>['31030']],'users'=>[1]]);
$q=['connection_id'=>'eligible030','channel'=>'instagram','account_id'=>'31030'];
$cfg=['expected_revision'=>0,'enabled'=>true,'lookback_days'=>1,'interval_minutes'=>60,'next_at'=>time()+3600];
$ids=[];foreach(['city','gender','age','country'] as $b){$id='qa-'.$b;$ids[]=$id;M\Schedules::save($cfg+['schedule_id'=>$id,'query'=>$q+['report'=>'audience','fields'=>['follower_demographics'],'breakdown'=>$b]]);}
$id='qa-daily';M\Schedules::save($cfg+['schedule_id'=>$id,'query'=>$q+['report'=>'account_insights','fields'=>['reach','views','follows_and_unfollows'],'date_from'=>gmdate('Y-m-d',time()-86400),'date_to'=>gmdate('Y-m-d',time()-86400),'granularity'=>'day','limit'=>1]]);
foreach($ids as $k=>$sid){$aud=$k%2?'breakdown_empty':'empty';$j=run30($sid);$v=sv30($sid);
 ck30("$sid retains null and measured count",$j['outcome']==='nao_aplicavel' && $v['availability_assessment']['followers_count']===11 && $v['availability_assessment']['minimum_followers']===100 && $j['successful_rows']===0 && $j['errors'][0]['eligibility']===$v['availability_assessment']);
 ck30("$sid retry remains enabled",$v['enabled']&&$v['next_at']>time());}
$j=run30($id);$h=h30();ck30('Healthy: four ineligible, one expected partial, no failure',$h['state']==='ok'&&$h['not_applicable_schedules']===4&&$h['failed_schedules']===0&&$h['expected_partial_schedules']===1&&$h['unexpected_partial_schedules']===0&&$h['partial_schedules']===1);
ck30('Daily paginated, actual zero rows count as useful, no invented missing value',$j['pages']===3&&$j['successful_rows']===2&&$j['availability_assessment']['kind']==='parcial_esperado');
$n=$calls;$health=M\Worker::observe();$list=M\Schedules::list();ck30('Health, list and status expose local evidence without Graph calls',M\Worker::status()['state']==='ok'&&$n===$calls&&count(array_filter($list,fn($s)=>($s['availability_assessment']['kind']??'')==='nao_aplicavel'))===4);
$count=30;run30('qa-city');ck30('Rechecks profile on next run',sv30('qa-city')['availability_assessment']['followers_count']===30);
$count=100;$aud='empty';$j=run30('qa-city');$h=h30();ck30('At exactly 100 no blanket exemption',$h['state']==='degraded' && $h['failed_schedules']===1 && $h['not_applicable_schedules']===3 && $j['outcome']==='failed' && in_array('schedule_failed',array_column($h['issues'],'code'),true));
$aud='available';$n=$probes;$j=run30('qa-city');ck30('Next scheduled run recovers at 100 with valid zero bucket',$j['outcome']==='complete' && $j['successful_rows']===1 && $probes===$n && h30()['state']==='ok');
$count=180;foreach($ids as $sid)run30($sid);ck30('All four continue collecting above threshold',h30()['not_applicable_schedules']===0&&h30()['state']==='ok'&&$probes===$n);
$count=0;$aud='empty';ck30('Zero is a measured follower count',run30('qa-city')['availability_assessment']['followers_count']===0);
$count=null;ck30('Missing count never becomes zero',run30('qa-city')['outcome']==='failed');$count=99;ck30('99 is below the threshold',run30('qa-city')['outcome']==='nao_aplicavel');
foreach(['reject','outage','wrong','profile_error','malformed'] as $mode){$aud=$mode;$before=$probes;$j=run30('qa-city');ck30("No exemption for $mode",$j['outcome']==='failed' && $j['availability_assessment']===null && h30()['state']==='degraded');if(in_array($mode,['reject','outage','malformed'],true))ck30("$mode does not probe profile",$before===$probes);}
$aud='available';run30('qa-city');$daily='mixed';$j=run30($id);$h=h30();ck30('Unexpected gap on separate page degrades despite expected gap and useful peer',$j['successful_rows']===1 && $h['unexpected_partial_schedules']===1 && !$h['expected_partial_schedules']&&$h['state']==='degraded');
$daily='empty_breakdown';$j=run30($id);ck30('Empty follow_type buckets remain null and expected',$j['availability_assessment']['kind']==='parcial_esperado' && $j['successful_rows']===2);
$daily='bad_shape';$j=run30($id);ck30('Malformed daily total stays a genuine failure',$j['last_code']==='upstream_invalid' && $j['availability_assessment']===null);
$daily='reject';$j=run30($id);ck30('HTTP rejection is not an expected marginal gap',$j['availability_assessment']===null&&h30()['state']==='degraded');
$daily='gap';run30($id);ck30('Normal cadence clears unexpected partial and retains expected one',h30()['state']==='ok' && h30()['expected_partial_schedules']===1);
$only=$cfg+['schedule_id'=>'qa-only','query'=>$q+['report'=>'account_insights','fields'=>['follows_and_unfollows'],'date_from'=>gmdate('Y-m-d',time()-86400),'date_to'=>gmdate('Y-m-d',time()-86400),'granularity'=>'day']];M\Schedules::save($only);$j=run30('qa-only');ck30('Empty daily report without useful peer still fails',$j['outcome']==='failed'&&h30()['failed_schedules']===1);
$job=['query'=>$q+['report'=>'account_insights'],'successful_rows'=>3,'last_code'=>'fields_unavailable'];$cov=['plan_complete'=>true,'error_count'=>51,'follow_gap_count'=>50];ck30('Unseen 51st error cannot be hidden by bounded sample',M\ScheduleAvailability::assessment($job,$cov)===null);
ck30('Page budget or incomplete plan cannot qualify',M\ScheduleAvailability::assessment(array_replace($job,['last_code'=>'page_budget_exhausted']),array_replace($cov,['follow_gap_count'=>51]))===null);
// Leave a representative, healthy demo for the public MCP and browser checks (isolated laboratory).
$only['enabled']=false;$only['expected_revision']=1;M\Schedules::save($only);
$count=11;$aud='empty';foreach($ids as $sid)run30($sid);ck30('Final fixture is healthy with evidence per schedule',h30()['state']==='ok'&&h30()['not_applicable_schedules']===4);
$failed=count(array_filter($checks,fn($x)=>!$x['passed']));echo wp_json_encode(['version'=>M\Config::VERSION,'total'=>count($checks),'failed'=>$failed,'checks'=>$checks,'simulated_graph_calls'=>$calls,'profile_reads'=>$probes])."\n";exit($failed?1:0);
