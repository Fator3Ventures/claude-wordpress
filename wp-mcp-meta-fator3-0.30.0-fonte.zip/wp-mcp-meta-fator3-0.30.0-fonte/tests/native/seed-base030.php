<?php
/** Take the snapshot in the next WP request, after normal outgoing bootstrap. */
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
if(Fator3\Meta\Config::VERSION!==F3QA_BASE||!get_option('f3_meta_site_owner_031'))throw new RuntimeException('Outgoing bootstrap must have finished.');
echo wp_json_encode(require __DIR__.'/migration-seed.php')."\n";
