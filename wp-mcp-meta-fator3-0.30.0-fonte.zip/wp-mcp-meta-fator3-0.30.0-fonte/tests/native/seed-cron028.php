<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);require __DIR__.'/seed-connection090.php';
lab_seed_connection090(['connection_id'=>'lab-028','expected_revision'=>0,'token'=>'synthetic-local','users'=>[1],'assets'=>['instagram'=>['777028']]]);
$q=['connection_id'=>'lab-028','channel'=>'instagram','account_id'=>'777028','report'=>'profile'];
$j=M\Jobs::create(['query'=>$q,'idempotency_key'=>'qa-dispatch-028']);
wp_clear_scheduled_hook('f3_meta_worker');
$repair=null;
if(getenv('F3_QA_RECOVERY')==='1'){
 $before=M\Worker::health();$repair=M\Api::dispatch('status',[])['data']['recovery']??null;
 $t=wp_next_scheduled('f3_meta_worker');$entry=M\Store::get('job',$j['job_id']);
 if(!$before['worker_required']||$before['cron']['next']!==null||!$t||empty($repair['scheduled'])||$entry['value']['pages']!==0||$entry['value']['status']!=='queued')throw new RuntimeException('No verified recovery');
} else {
 $t=time()-10;$r=wp_schedule_single_event($t,'f3_meta_worker',[],true);if($r!==true)throw new RuntimeException('seed schedule');
}
wp_schedule_single_event($t+3600,'f3_meta_worker',['keep'],true);
update_option('f3qa028_id',$j['job_id'],false);update_option('f3qa028_at',$t,false);
echo wp_json_encode(['job_before'=>$j['status'],'page_before'=>$j['pages'],'scheduled_at'=>$t,'repair'=>$repair])."\n";
