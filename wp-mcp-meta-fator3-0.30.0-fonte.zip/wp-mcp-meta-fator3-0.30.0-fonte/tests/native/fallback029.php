<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
$source=wp_insert_user(['user_login'=>'source031restored','user_pass'=>wp_generate_password(),'role'=>'subscriber']);if(is_wp_error($source))throw new RuntimeException('fixture');
$items=[];add_filter('pre_wp_mail',static function($pre,$args)use(&$items){$items[]=$args['to'];return true;},PHP_INT_MAX,2);
$run=M\SiteOwner::executor(['user_id'=>$source,'channel'=>null],true);
M\Worker::notify();M\Worker::notify();
if($run['user_id']===$source || !user_can($run['user_id'],'manage_options') || $items!==['tech-031@example.invalid'])throw new RuntimeException('Fallback incident');
(new WP_User($source))->set_role('administrator');M\Worker::notify();M\Worker::notify();
if($items!==['tech-031@example.invalid','tech-031@example.invalid'])throw new RuntimeException('Fallback recovery');
echo wp_json_encode(['total'=>2,'fallback_notice_once'=>true,'recovery_once'=>true])."\n";
