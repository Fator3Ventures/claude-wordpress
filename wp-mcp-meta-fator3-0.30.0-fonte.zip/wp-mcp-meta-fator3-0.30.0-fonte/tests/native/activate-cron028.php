<?php
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
require_once ABSPATH.'wp-admin/includes/plugin.php';wp_set_current_user(1);
foreach(['base-site-core-fator3','wp-security-audit-log'] as $slug){$file=$slug.'/'.$slug.'.php';$r=activate_plugin($file);if(is_wp_error($r))throw new RuntimeException($r->get_error_code());$versions[$slug]=get_plugin_data(WP_PLUGIN_DIR.'/'.$file,false,false)['Version'];}
if($versions!==['base-site-core-fator3'=>'1.91.0','wp-security-audit-log'=>'5.7.0'])throw new RuntimeException('Unexpected fixtures');
echo wp_json_encode($versions)."\n";
