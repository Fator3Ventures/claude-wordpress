<?php
/** Tests the serialized public result through the shipped MCP dispatcher, including its output filter. */
use WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$r=ExecuteAbilityAbility::execute(['ability_name'=>'meta/health','parameters'=>[]]);$h=$r['data']['data']??[];$checks=[];
$checks['state and full counters']=($h['state']??'')==='ok'&&$h['failed_schedules']===0&&$h['not_applicable_schedules']===4&&$h['expected_partial_schedules']===1&&$h['unexpected_partial_schedules']===0;
foreach(['qa-city','qa-country','qa-age','qa-gender'] as $sid){$s=array_column($h['schedules']??[],null,'schedule_id')[$sid]??[];$p=$s['availability_assessment']??[];$checks[$sid]=($s['last_run_status']??null)==='nao_aplicavel'&&$s['last_error_state']==='expected'&&$p['followers_count']===11&&$p['minimum_followers']===100&&$p['reason']==='below_minimum_followers'&&$p['account_id']==='31030'&&$p['observed_at']>0;}
echo wp_json_encode(['checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x))])."\n";
exit(in_array(false,$checks,true)?1:0);
