<?php
use Fator3\Meta as M;use Fator3\McpFiles\ConnectionContext as C;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
$checks=[];function ck($n,$b){global $checks;if(!$b)throw new RuntimeException('Failed: '.$n);$checks[]=$n;}
$s=get_option('lab031');extract($s);C::oauth($b);wp_set_current_user(1);
ck('Current MCP grant B is active',M\Access::principal()['channel']['connection_id']==='grant:rotation-after');
ck('Old job visible to B',M\Jobs::status($job['job_id'])['rows']===1);
ck('Retained result readable by B',M\Jobs::results(['job_id'=>$job['job_id']])['data']['rows'][0]['id']==='3101');
ck('Old export unchanged',M\Export::read(['export_id'=>$export['export_id']])['sha256']===$export['sha256']);
$history=M\History::query($q);ck('Old organic partition visible',$history['rows'][0]['row']['id']==='3101');
ck('Old history export completes',M\HistoryExport::step(['export_id'=>$hx['export_id']])['state']==='complete');
ck('Historical export bytes returned',strlen(M\HistoryExport::read(['export_id'=>$hx['export_id']])['content_base64'])>0);
$finish=M\HistoryExport::step(['export_id'=>$pending['export_id']]);
ck('Legacy export in flight continues at exact snapshot after rotation',$finish['state']==='complete'&&$finish['parts']===2&&$finish['rows']===2);
$bytes='';for($n=0;$n<2;$n++)$bytes.=base64_decode(M\HistoryExport::read(['export_id'=>$pending['export_id'],'part'=>$n])['content_base64']);
ck('Reassembled legacy export has two distinct rows',count(array_unique(array_column(json_decode($bytes,true)['rows'],'row_id')))===2);
ck('Archived story from old authorization readable',M\StoryArchive::read($scope)['rows'][0]['story_id']==='3111');
ck('Archived thumbnail readable',M\StoryArchive::read($scope+['story_id'=>'3111'],true)['thumbnail']==='synthetic-thumb');
ck('Existing backfill queued automatically',M\Jobs::status($back['job_id'])['status']==='queued');
$list=static fn()=>array_column(M\Schedules::list(),null,'schedule_id');
ck('Existing failed schedule due without edit',$list()['failed']['next_at']<=time()&&$list()['failed']['revision']===$rev);
ck('Disabled schedule stays off',!$list()['off']['enabled']);
ck('Messaging pending during upgrade rearmed',wp_next_scheduled('f3_meta_messages',['lab031','3101'])!==false);
$transient=true;$calls=0;
add_filter('pre_http_request',static function($old,$args,$url)use(&$transient,&$calls,$ts){
 $path=preg_replace('~^/v[0-9.]+/~','',parse_url($url,PHP_URL_PATH));$calls++;
 $out=match($path){
 '3101'=>['id'=>'3101','name'=>'Fixture'],
 '3102'=>['id'=>'3102','access_token'=>'page-fixture','instagram_business_account'=>['id'=>'3101']],
 'debug_token'=>['data'=>['is_valid'=>true,'profile_id'=>'3102','type'=>'PAGE','scopes'=>M\Messaging::SCOPES]],
 '3102/conversations'=>['data'=>[['id'=>'t_031']]],
 't_031/messages'=>['data'=>[['id'=>'m031','created_time'=>gmdate('c',$ts),'from'=>['id'=>'3103']]]],
 default=>['id'=>'fixture']};
 if($path==='3102'&&$transient)return new WP_Error('connection_reset');
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($out)];
},1,3);
$deliveries=0;M\Messaging::registerConsumer('site-core',M\Messaging::CONTRACT,static function($payload)use(&$deliveries){$deliveries++;return ['persisted'=>true,'record_id'=>'test-core-031','idempotency_key'=>$payload['idempotency_key']];});
(new WP_User($id))->set_role('subscriber');C::restore_identity(null,0);
M\Jobs::tick();
C::oauth($b);wp_set_current_user(1);$st=$list()['failed'];$j=M\Jobs::status($st['last_job']);
ck('Background collection after grant revocation and admin demotion',$j['status']==='complete'&&$j['rows']===1);
ck('Legacy edit revision stable on success',$st['revision']===$rev);
ck('Legacy backfill completed',M\Jobs::status($back['job_id'])['status']==='complete');
ck('New observation reuses legacy organic row identity',count(M\History::query($q)['rows'])===1);
ck('Legacy admin fallback recorded',array_key_exists($id,get_option('f3_meta_owner_replacements',[])));
$other=wp_insert_user(['user_login'=>'admin031b','user_pass'=>wp_generate_password(),'role'=>'administrator']);C::restore_identity(null,$other);
ck('Another WP administrator reads old job and export',M\Jobs::status($job['job_id'])['pages']===1&&M\Export::value($export['export_id'])['bytes']>0);
C::restore_identity(null,$id);ck('Demoted user denied',M\Result::run(fn()=>M\Jobs::status($job['job_id']))['code']==='not_authorized');
C::restore_identity(null,0);wp_clear_scheduled_hook('f3_meta_messages',['lab031','3101']);M\Messaging::tick('lab031','3101');
ck('Graph failure scheduled retry',wp_next_scheduled('f3_meta_messages',['lab031','3101'])!==false && $deliveries===0);
$transient=false;do_action('f3_meta_messages','lab031','3101');do_action('f3_meta_messages','lab031','3101');
ck('Message delivered exactly once without administrator session',$deliveries===1&&M\Store::get('message_event',$mk)['value']['delivery']==='persisted');
C::restore_identity(null,1);
$c=M\Connections::get('lab031');M\Connections::save(['connection_id'=>'lab031','expected_revision'=>$c['revision'],'assets'=>['instagram'=>[]]]);
ck('Removed asset denied for job',M\Result::run(fn()=>M\Jobs::status($job['job_id']))['code']==='asset_access_denied');
ck('Removed asset denied for retained story',M\Result::run(fn()=>M\StoryArchive::read($scope))['code']==='asset_access_denied');
ck('Removed asset denied for export',M\Result::run(fn()=>M\Export::value($export['export_id']))['code']==='asset_access_denied');
$row=M\Store::get('schedule','failed');$v=$row['value'];$v['next_at']=time()-1;M\Schedules::checkpoint(['key'=>'failed']+$row,$v);M\Schedules::tick();$failed=$list()['failed'];
ck('Real failed dispatch keeps edit revision',$failed['revision']===$rev && $failed['last_code']==='asset_access_denied');
$c=M\Connections::get('lab031');M\Connections::save(['connection_id'=>'lab031','expected_revision'=>$c['revision'],'assets'=>['instagram'=>['3101']]]);
$res=M\Schedules::save(['schedule_id'=>'failed','expected_revision'=>$rev,'enabled'=>true,'interval_minutes'=>60,'query'=>$q]);
ck('CAS edit succeeds after failure and increments once',$res['revision']===$rev+1);
ck('Stale editor rejected',M\Result::run(fn()=>M\Schedules::save(['schedule_id'=>'failed','expected_revision'=>$rev,'enabled'=>true,'interval_minutes'=>60,'query'=>$q]))['code']==='revision_conflict');
echo wp_json_encode(['total'=>count($checks),'checks'=>$checks,'calls_to_graph_fixture'=>$calls,'consumer_calls'=>$deliveries])."\n";
