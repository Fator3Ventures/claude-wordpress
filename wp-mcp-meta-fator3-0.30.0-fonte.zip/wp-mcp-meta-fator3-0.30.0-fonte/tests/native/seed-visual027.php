<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
if(!getenv('F3_QA_PASSWORD'))exit(1);
wp_set_password(getenv('F3_QA_PASSWORD'),1);update_option('show_avatars',0);
require __DIR__.'/seed-connection090.php';
lab_seed_connection090(['connection_id'=>'demo-painel','expected_revision'=>0,'label'=>'Loja de exemplo','enabled'=>true,'token'=>'qa-local-fixture','users'=>[1],'assets'=>['instagram'=>array_map('strval',range(1001,1025)),'facebook'=>['2001'],'ads'=>['160']]]);

$q=['connection_id'=>'demo-painel','channel'=>'instagram','account_id'=>'1001','report'=>'profile'];
M\Schedules::save(['schedule_id'=>'demo-perfil','label'=>'Perfil da loja','query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>1440,'next_at'=>time()+86400]);
M\Jobs::create(['query'=>$q,'idempotency_key'=>'demo-perfil']);
