import os,pathlib as pl,secrets,shutil,json,sys,subprocess
src=pl.Path(__file__).resolve().parents[2]; base=pl.Path(os.environ['F3_QA_BASE']).resolve();slug='wp-mcp-meta-fator3';php=os.environ.get('F3_SOCIAL_PHP','php')
env=os.environ.copy(); phase=sys.argv[1]; tests=src/'tests/native'; core=pl.Path(os.environ['F3_QA_WP_CORE']).resolve(); ev=src/'evidence/023'
env.setdefault('F3_QA_URL','http://127.0.0.1:34893')
def proc(script,*args,env=env):
 return subprocess.run([php,str(script),*map(str,args)],env=env,stdout=subprocess.PIPE,stderr=sys.stderr,text=True)
def sql(stmt):
 subprocess.run([php,'-r',"""$m=new mysqli('127.0.0.1','root','','',34793);$m->query($argv[1]);""",stmt],check=True)
def testfile(name,script,expect=0):
 x=proc(script); result=json.loads(x.stdout.strip().splitlines()[-1])
 (ev/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(name,x.returncode,result.get('total'),result.get('failed'),[c.get('name') for c in result.get('checks',[]) if c.get('passed')==False],flush=True)
 if x.returncode!=expect:raise RuntimeError(name+' '+str(x.returncode))
def prepare(kind,base):
 prefix='f3qa022_'+secrets.token_hex(6)+'_'; root=pl.Path('/tmp')/prefix; root.mkdir(mode=0o700); site=root/'wordpress';site.mkdir();(root/'evidence').mkdir()
 db=prefix.rstrip('_');sql('CREATE DATABASE '+db+' CHARACTER SET utf8mb4')
 for d in ('wp-admin','wp-includes'):
  if phase.startswith('ui-'):shutil.copytree(core/d,site/d)
  else:(site/d).symlink_to((core/d).resolve(),True)
 for p in core.glob('*.php'):
  if p.name not in ['wp-config.php','wp-config-sample.php'] and (p.name.startswith('wp-') or p.name in ['xmlrpc.php','index.php']): shutil.copyfile(p,site/p.name)
 plugins=site/'wp-content/plugins';plugins.mkdir(parents=True);mu=site/'wp-content/mu-plugins';mu.mkdir()
 (mu/'no-external.php').write_text('<?php add_filter("pre_http_request",static fn($pre)=>$pre!==false?$pre:new WP_Error("lab_external_blocked"),PHP_INT_MAX);add_filter("pre_wp_mail",static fn()=>true,PHP_INT_MAX);')
 (site/'wp-config.php').write_text("""<?php define('DB_NAME','"""+db+"""');define('DB_USER','root');define('DB_PASSWORD','');define('DB_HOST','127.0.0.1:34793');define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');"""+''.join(f"define('{key}','{secrets.token_hex(48)}');" for key in 'AUTH_KEY SECURE_AUTH_KEY LOGGED_IN_KEY NONCE_KEY AUTH_SALT SECURE_AUTH_SALT LOGGED_IN_SALT NONCE_SALT'.split())+"$table_prefix='"+prefix+"';define('WP_HOME','http://127.0.0.1:34893');define('WP_SITEURL',WP_HOME);define('DISABLE_WP_CRON',true);define('WP_HTTP_BLOCK_EXTERNAL',true);define('WP_DEBUG',false);if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require ABSPATH.'wp-settings.php';")
 (root/'baseline').mkdir();shutil.copytree(pl.Path(os.environ['F3_QA_BASE']),root/'baseline'/slug);shutil.copytree(base,plugins/slug);env.update(F3_LAB_ROOT=str(root),F3_LAB_FLAVOR=kind)
 return root,db,plugins/slug
cand=src/'build/dist'/slug
root,db,installed=prepare({'capture':'current','base':'baseline','clean':'current','upgrade':'upgrade','ui-base':'baseline','ui-final':'current','additional':'current','access':'current','regression-base':'baseline','regression':'current','combination':'current','ui-assets':'current'}[phase],base if phase in ['base','upgrade','ui-base','regression-base'] else cand)
try:
 testfile(phase+'-install',tests/'install.php')
 if phase.startswith('ui-'):
  password=secrets.token_urlsafe(25); env['F3_QA_PASSWORD']=password
  seed=proc(src/'tests/visual/seed0221.php');seed.check_returncode()
  if phase=='ui-assets':proc(tests/'seed-assets023.php').check_returncode()
  server=subprocess.Popen([php,'-S','127.0.0.1:34893','-t',str(root/'wordpress')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   subprocess.run([sys.executable,str(src/'tests/visual'/('assets-persist023.py' if phase=='ui-assets' else 'review0221.py')),str(ev/(phase+'.json'))],env=env,check=True)
  finally: server.terminate();server.wait()
 if phase.startswith('regression'):
  testfile(phase,tests/'worker023.php',1 if phase.endswith('-base') else 0)
 if phase=='combination':
  for plugin in sorted(pl.Path(os.environ['F3_QA_COMPANIONS']).iterdir()):
   if plugin.name!=slug:shutil.copytree(plugin,installed.parent/plugin.name)
  testfile('activate-companions',tests/'activate023.php')
  testfile('combination',tests/'combination023.php')
 if phase=='base': testfile('base-reproduction',tests/'release0221.php',1)
 if phase=='capture':
  r=proc(src/'tests/docs/capture-examples.php');r.check_returncode(); data=json.loads(r.stdout);(src/'build/docs/examples/captured.json').write_text(json.dumps(data,ensure_ascii=False,indent=4)+'\n')
 if phase=='access':testfile('access0221',tests/'access0221.php')
 if phase=='upgrade':
  shutil.rmtree(installed);shutil.copytree(cand,installed); testfile('migration',tests/'migrate.php')
 if phase in ('clean','additional'):
  for t in (['export-integrity','dataset'] if phase=='additional' else ['release022','release0221','smoke','configuration','export-integrity','dataset','access0221']):testfile(t,tests/(t+'.php'))
finally:
 sql('DROP DATABASE '+db);shutil.rmtree(root)
