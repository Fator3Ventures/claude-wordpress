"""Navegação e layout reais do wp-admin. Apenas as linhas de consulta são exemplos sintéticos."""
import os,sys,json
from pathlib import Path
from urllib.parse import unquote,urlparse
from playwright.sync_api import sync_playwright
out=Path(sys.argv[1]);base=sys.argv[2]=='ui-matrix-base';url=os.environ['F3_QA_URL'];assert urlparse(url).hostname=='127.0.0.1'
caps=out/('referencia' if base else 'capturas');caps.mkdir(exist_ok=True)
checks=[];errors=[];requests=[];writes=[];gate={"armed":False,"route":None,"data":None}
def ck(width,tab,name,val):
 checks.append(dict(width=width,tab=tab,name=name,passed=bool(val)))
def intercept(route):
 req=route.request;u=unquote(req.url)
 if not u.startswith(url+'/'):return route.abort()
 op=u.split('/')[-1].split('&')[0].split('?')[0]
 if req.method=='POST' and ('save-' in op or op.startswith(('control-','run-','rotate-'))):writes.append(op)
 if req.method=='POST' and op in ('query','history-query','conversations','story-archive'):
  v=req.post_data_json;cur=v.get('cursor');requests.append([op,v.copy()])
  rows=[dict(name=('Ação especial' if n==22 else 'Campanha de exemplo')+' '+str(n),date='2026-11-12',reach=n*109,impressions=n*230,account_id='1001',report='profile',status='complete') for n in (range(26,29) if cur else range(1,26))]
  if op=='story-archive':rows=[dict(story_id='700'+str(n),caption='Visita à loja de exemplo',thumbnail_available=False) for n in range(1,3)]
  d=dict(rows=rows,next_cursor=None if cur else 'qa-lote-2',coverage='Dois Stories de exemplo.' if op=='story-archive' else dict(complete=True),warnings=[],started_per_day_in_page={},migration_complete=True,retention={'mode':'unlimited'})
  if gate['armed']:
   gate.update(armed=False,route=route,data=d);return
  return route.fulfill(json={'success':True,'data':d})
 route.continue_()
tabs='connections assets ads-access reports jobs history messaging archive diagnostics help'.split()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox','--no-zygote'])
 p=b.new_page(viewport={'width':1440,'height':900},locale='pt-BR',timezone_id='UTC');p.set_default_timeout(7000)
 p.route('**/*',intercept);p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto(url+'/wp-login.php');p.locator('#user_login').fill('qa022admin');p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click()
 for w in ([360] if base else [360,768,1440]):
  p.set_viewport_size({'width':w,'height':900})
  for tab in (['connections','reports'] if base else tabs):
   p.goto(url+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab='+tab,wait_until='networkidle');sec=p.locator('#f3-'+tab+'.f3-section');sec.wait_for()
   if tab in ['reports','jobs','history','messaging','archive','diagnostics']:
    sel=p.locator('#f3-context [name=connection_id]')
    if sel.input_value()!='demo-painel':sel.select_option('demo-painel');p.wait_for_load_state('networkidle')
   if tab=='assets':p.locator('#f3-assets-connection').select_option('demo-painel')
   if tab=='reports':
    p.locator('#f3-query .button-primary').click();p.locator('#f3-result table').wait_for()
   title=p.locator('.f3-heading h1').bounding_box();badge=p.locator('.f3-heading .f3-badge').bounding_box()
   ck(w,tab,'Título e versão na primeira linha',badge['x']>title['x'] and abs((badge['y']+badge['height']/2)-(title['y']+title['height']/2))<25)
   ck(w,tab,'Versão instalada',p.locator('.f3-badge').inner_text()=='Versão '+('0.26.0' if base else '0.27.0'))
   ck(w,tab,'Aba do endereço está ativa',p.locator('[data-tab="'+tab+'"][aria-current=page]').is_visible())
   ck(w,tab,'Corpo, grupos e subabas cabem na largura',p.evaluate('''() => document.documentElement.scrollWidth<=innerWidth+1 && [...document.querySelectorAll('.f3-tabs a')].filter(e=>e.offsetWidth).every(e=>e.getBoundingClientRect().right<=innerWidth+1)'''))
   ck(w,tab,'Título da seção visível',sec.locator('h2').first.is_visible())
   p.evaluate('window.scrollTo(0,0)');p.screenshot(path=str(caps/(tab+'-'+str(w)+'.png')),full_page=True,animations='disabled')
   if tab=='reports':
    root=p.locator('#f3-result');bar=root.locator('.f3-browser');wrap=root.locator('.f3-table-scroll')
    ck(w,tab,'Busca e navegação de tabela',bar.count()==1)
    if base:continue
    ck(w,tab,'Tabela isolada e palavras inteiras',wrap.evaluate("(e)=>getComputedStyle(e).overflowX==='auto'&&getComputedStyle(e.querySelector('td')).overflowWrap==='normal'&&e.clientWidth<=innerWidth"))
    if w<782:ck(w,tab,'Tabela larga rola no bloco',wrap.evaluate('(e)=>e.scrollWidth>e.clientWidth'))
    nxt=bar.get_by_role('button',name='Próxima');prv=bar.get_by_role('button',name='Anterior');nxt.click()
    ck(w,tab,'Segundo intervalo',bar.get_by_role('status').inner_text()=='21–25 de 25' and nxt.is_disabled())
    q=bar.locator('input');q.fill('acao especial');ck(w,tab,'Filtro sem acento',root.locator('tbody tr:visible').count()==1 and 'Ação especial' in root.locator('tbody tr:visible').inner_text())
    q.fill('nenhumitem');ck(w,tab,'Zero resultados',root.locator('tbody tr:visible').count()==0 and prv.is_disabled() and nxt.is_disabled());q.fill('')
    nextlot=p.locator('#f3-next');nextlot.click();back=sec.get_by_role('button',name='Voltar ao lote anterior');back.wait_for();back.click()
    p.wait_for_function("document.querySelector('#f3-result tbody tr')?.textContent.includes('exemplo 1')")
    ck(w,tab,'Consulta anterior usa o mesmo filtro',requests[-1][1]==requests[-3][1] and 'cursor' not in requests[-1][1] and requests[-2][1].get('cursor')=='qa-lote-2')
    p.locator('#f3-next').click();back.wait_for();p.locator('#f3-context [name=account_id]').select_option(index=1)
    ck(w,tab,'Mudar de conta limpa os lotes',not back.is_visible() and not nextlot.is_visible() and not root.locator('tr').count())
   if tab=='reports' and not base and w==360:
    gate['armed']=True;p.locator('#f3-query .button-primary').click()
    for _ in range(40):
     if gate['route']:break
     p.wait_for_timeout(25)
    assert gate['route'];sel=p.locator('#f3-context [name=account_id]')
    sel.select_option(index=0);sel.select_option(index=1);gate['route'].fulfill(json={'success':True,'data':gate['data']})
    p.wait_for_load_state('networkidle');ck(w,tab,'Resposta atrasada A→B→A descartada',not root.locator('tr').count() and not nextlot.is_visible())
   if tab in ('history','archive','messaging') and not base:
    first,more,dest,op={'history':('history-query','history-next','history-result','history-query'),'archive':('archive-query','archive-next','archive-result','story-archive'),'messaging':('msg-query','msg-next','msg-result','conversations')}[tab]
    p.locator('#f3-'+first).click();p.locator('#f3-'+more).click()
    prev=sec.get_by_role('button',name='Voltar ao lote anterior');prev.wait_for();prev.click();prev.wait_for(state='hidden');p.wait_for_load_state('networkidle')
    ck(w,tab,'Volta ao primeiro lote da seleção',requests[-1][0]==op and requests[-1][1]==requests[-3][1] and not prev.is_visible())
   if tab in ('jobs','messaging','connections') and not base:
    if tab=='connections':p.locator('.f3-edit-connection').first.click();tag='editor'
    else:
     tag='schedules' if tab=='jobs' else 'setup';sec.locator('button[data-view="'+tag+'"]').click()
    p.wait_for_load_state('networkidle');p.evaluate('window.scrollTo(0,0)');p.screenshot(path=str(caps/(tab+'-'+tag+'-'+str(w)+'.png')),full_page=True,animations='disabled')
    ck(w,tab,'Subview cabe na largura',p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   if tab=='assets' and not base:
    f=sec.locator('fieldset[data-channel=instagram]');q=f.locator('input[type=search]');n=f.locator('input[type=checkbox]').first;n.uncheck()
    f.get_by_role('button',name='Próxima',exact=True).click();f.get_by_role('button',name='Anterior',exact=True).click();ck(w,tab,'Marcação preservada entre páginas',not n.is_checked());n.check()
   if tab=='help' and not base:
    nav=sec.locator('#f3-help-index');nav.locator('input[type=search]').fill('retenção');ck(w,tab,'Busca abre categoria de ajuda',nav.locator('li:visible').count()>0);nav.locator('input[type=search]').fill('')
 b.close()
ck(0,'global','Sem gravações pelo navegador',not writes);ck(0,'global','Sem erros JavaScript',not errors)
data=dict(version='0.26.0' if base else '0.27.0',total=len(checks),failed=sum(not t['passed'] for t in checks),errors=errors,checks=checks)
(out/(sys.argv[2]+'.json')).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
print(sys.argv[2],data['total'],data['failed'],[t for t in checks if not t['passed']],flush=True)
if not base:assert not data['failed']
