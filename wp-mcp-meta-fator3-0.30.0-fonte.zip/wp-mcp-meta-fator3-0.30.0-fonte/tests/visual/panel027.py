import json,os,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-zygote','--no-sandbox'])
 page=b.new_page();page.route('**/*',lambda r:r.fulfill(body=Path(sys.argv[1]).read_text(),content_type='text/html') if r.request.resource_type=='document' else r.abort())
 page.goto('http://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3');page.wait_for_function('document.querySelector("#qa-summary").dataset.result')
 result=page.locator('#qa-summary');items=json.loads(result.get_attribute('data-result'));o={'summary':result.inner_text(),'checks':items,'total':len(items),'failed':sum(not i['passed'] for i in items)}
 Path(sys.argv[2]).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print(o['summary']);b.close();assert not o['failed'] and not o['summary'].startswith('Falha')
