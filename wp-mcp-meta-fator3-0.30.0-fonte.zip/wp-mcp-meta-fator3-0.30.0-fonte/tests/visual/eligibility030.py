"""Inspect the genuine REST health from a seeded isolated WP install, at each mandated width."""
import os,sys,json
from pathlib import Path
from playwright.sync_api import sync_playwright
out=Path(sys.argv[1]);url=os.environ['F3_QA_URL'];assert url=='http://127.0.0.1:18930'
checks=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox','--no-zygote'])
 p=b.new_page(locale='pt-BR');p.route('**/*',lambda r:r.continue_() if r.request.url.startswith(url+'/') else r.abort())
 p.goto(url+'/wp-login.php');p.locator('#user_login').fill('qa022admin');p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click()
 for w in (360,768,1440):
  p.set_viewport_size({'width':w,'height':900});p.goto(url+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab=diagnostics',wait_until='networkidle')
  d=p.locator('#f3-diagnostic-result');d.get_by_text('Disponibilidade na última coleta').wait_for()
  checks.append({'width':w,'passed':d.locator('li').filter(has_text='11 seguidores no perfil; mínimo de 100').count()==4 and d.locator('li').filter(has_text='Parcial esperada:').count()==1 and d.get_by_text('Sem problemas',exact=True).is_visible() and p.evaluate('document.documentElement.scrollWidth<=innerWidth+1')})
  p.screenshot(path=str(out/'capturas'/('diagnostics-eligibility-'+str(w)+'.png')),full_page=True,animations='disabled')
 b.close()
d={'checks':checks,'total':len(checks),'failed':sum(not x['passed'] for x in checks)};(out/'ui-eligibility.json').write_text(json.dumps(d));assert d['failed']==0
