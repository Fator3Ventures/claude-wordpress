<?php
// Disposable runtime only. Authentication is stubbed; real WordPress permissions are tested separately.
declare(strict_types=1);
define('ABSPATH',__DIR__.'/');
function current_user_can($cap){return ($GLOBALS['admin']??true)&&$cap==='manage_options';}
$root=realpath($argv[1]);require $root.'/includes/Config.php';require $root.'/includes/Support.php';require $root.'/includes/Connections.php';require $root.'/includes/Documentation.php';
use Fator3\Meta as M;
$tests=[];function verify($name,$truth){global $tests;$tests[]=['name'=>$name,'passed'=>(bool)$truth];if(!$truth)throw new RuntimeException($name);}
function fault($code,$fn){try{$fn();return false;}catch(M\Fault $e){return $e->reason===$code;}}
$id='ADMINISTRATION.md';$doc=$root.'/docs/'.$id;$original=file_get_contents($doc);$foreign=$root.'/outside.txt';$renamed=$doc.'.saved';
try{
 $idx=M\Documentation::read(['document'=>'index']);$entry=array_values(array_filter($idx['documents'],fn($d)=>$d['document']===$id))[0];
 verify('index preserves bytes and digest',strlen($original)===$entry['bytes']&&hash('sha256',$original)===$entry['sha256']);
 $pos=0;$joined='';$pages=0;do{$page=M\Documentation::read(['document'=>$id,'limit_bytes'=>256,'offset'=>$pos,'expected_revision'=>$entry['sha256']]);$joined.=$page['content'];$pos=$page['next_offset'];$pages++;}while($pos!==null);
 verify('complete UTF-8 pages equal the installed file',$joined===$original&&$pages>1);
 verify('stale revision refused',fault('revision_conflict',fn()=>M\Documentation::read(['document'=>$id,'expected_revision'=>str_repeat('f',64)])));
 $rx=preg_match('/[\x80-\xbf]/',$original,$match,PREG_OFFSET_CAPTURE);verify('UTF-8 continuation byte rejected',$rx&&fault('invalid_input',fn()=>M\Documentation::read(['document'=>$id,'offset'=>$match[0][1],'expected_revision'=>$entry['sha256']])));
 verify('non-indexed path refused',fault('not_found',fn()=>M\Documentation::read(['document'=>'../outside.txt'])));
 file_put_contents($doc,substr_replace($original,'!',0,1));verify('same-sized tamper cannot disclose bytes',fault('revision_conflict',fn()=>M\Documentation::read(['document'=>$id])));
 rename($doc,$renamed);verify('missing file denied',fault('documentation_unavailable',fn()=>M\Documentation::read(['document'=>$id])));
 verify('index independent of missing manual',M\Documentation::read(['document'=>'index'])['documents']===$idx['documents']);
 file_put_contents($foreign,$original);symlink($foreign,$doc);clearstatcache(true);
 verify('external symlink refused even with valid digest',fault('documentation_unavailable',fn()=>M\Documentation::read(['document'=>$id])));
 $GLOBALS['admin']=false;verify('non-admin refused before filesystem lookup',fault('not_authorized',fn()=>M\Documentation::read(['document'=>$id])));$GLOBALS['admin']=true;
}finally{if(is_link($doc))unlink($doc);if(file_exists($renamed))rename($renamed,$doc);file_put_contents($doc,$original);if(file_exists($foreign))unlink($foreign);}
echo json_encode(['total'=>count($tests),'failed'=>count(array_filter($tests,fn($x)=>!$x['passed'])),'checks'=>$tests,'pages'=>$pages,'scope'=>'disposable copy, standalone PHP, capability stub'],JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT),"\n";
