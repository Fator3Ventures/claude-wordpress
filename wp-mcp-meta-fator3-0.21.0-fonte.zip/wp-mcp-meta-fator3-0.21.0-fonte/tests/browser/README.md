# Testes do painel Meta 0.21.0

Após o build, com PHP 8.3 de 64 bits, Node e as dependências do package-lock instaladas em tests/browser, execute a partir da raiz do fonte:

```sh
php tests/browser/render.php plugin/wp-mcp-meta-fator3 identity > /tmp/meta-021-identidade.json
node tests/browser/selection-race.cjs /tmp/meta-021-identidade.json plugin/wp-mcp-meta-fator3/assets/admin.js /tmp/meta-021-selecao.json
```

A suíte usa o HTML produzido pelo renderer administrativo do pacote e seu JavaScript. Em jsdom, o transporte devolve promessas controladas para concluir a chamada de A só depois de selecionar B. Inclui filtros, troca de abas, A→B→A, erros tardios, primeira/próxima página válida, exportação, prévia de coleta, configuração de webhook e agenda de Stories. Não consulta a Meta nem requer uma credencial. Não comprova layout visual ou acesso real ao fornecedor.

Para reproduzir na base, passe ao renderer o diretório wp-mcp-meta-fator3 extraído do instalador 0.20.0; passe o JSON e o assets/admin.js desse mesmo instalador à suíte. Compare os arquivos evidence/selection-race-base.json e evidence/selection-race-candidate.json que registram versão, hash do JS e resultado por cenário.
