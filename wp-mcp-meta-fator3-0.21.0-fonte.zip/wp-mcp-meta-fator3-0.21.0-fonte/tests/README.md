# Testes da versão 0.21.0

As suítes ativas usam PHP 8.3+ e WordPress 7.1.4+. O nome de uma fixture pode conter o número do pedido ou da release que a introduziu. Não representa suporte a versões substituídas.

## Interface

Em tests/browser, instale as dependências do package-lock com npm ci. Use PHP CLI e Node com a versão de jsdom fixada no lock. A renderização da fixture usa o renderer, CSS e JS reais do plugin com helpers de apresentação WordPress simulados e registros sintéticos. As chamadas REST nas suítes DOM são simuladas; não há confirmação de layout por jsdom. O HTML gerado também pode ser aberto pelo mantenedor em um navegador para os casos de interação e conferência de largura.

A partir da raiz do fonte, depois de gerar o runtime:

```sh
php tests/browser/render.php plugin/wp-mcp-meta-fator3 > /tmp/meta-painel.html
php tests/browser/render.php plugin/wp-mcp-meta-fator3 identity > /tmp/meta-identidade.json
node tests/browser/run.cjs /tmp/meta-painel.html /tmp/meta-ui.json
node tests/browser/identity.cjs /tmp/meta-identidade.json build/assets/admin.js /tmp/meta-identidade-resultados.json
node tests/browser/monitoring.cjs /tmp/meta-identidade.json build/assets/admin.js /tmp/meta-monitoramento.json
node tests/browser/messaging.cjs /tmp/meta-identidade.json build/assets/admin.js /tmp/meta-conversas.json
```

Os casos cobrem seleção/limpeza de credenciais, revisão da gravação, retenção explícita, diagnóstico somente leitura, ajuda paginada/corrida, erros e avisos, prévia e confirmação de identidade, consumidores de anúncios, concessões, conversas e Stories. As provas reais de autorização e de configuração estão no WordPress isolado.

## WordPress no Site-Teste

O controlador é temporário, restrito ao Site-Teste e não integra o instalador. Todas as operações usam um lock nomeado dedicado e um prefixo aleatório por laboratório. A bancada injeta fixtures e bloqueia HTTP/e-mail apenas na cópia isolada, nunca globalmente no site compartilhado.

1. Gere a bancada com `python3 tests/site/build.py /caminho/wp-mcp-meta-fator3-0.20.0-instalador.zip /caminho/wp-mcp-meta-fator3-0.21.0-instalador.zip /tmp/meta-ui021-lab`. O build exige a base canônica SHA-256 `2f229301c8dd08357ed9d023edc1d610ac1b78e01114dce45913e1979b95399b`; confere versão dos cabeçalhos, manifests e todos os arquivos de ambos os instaladores. Dados iguais são armazenados uma só vez no bundle.
2. Transfira temporariamente `f3-qaui021.php` e `f3-qaui021.bundle.gz` para `wp-content/mu-plugins/`, com validação dos hashes. O controlador aceita somente operações fixas, administrador, hostname do Site-Teste e raiz/prefixo da própria sessão. Consulte `meta/qa-ui021-state` para o estado antes/depois. Nunca reutilize um laboratório ativo de outra sessão.
3. Use `meta/qa-ui021-lab` com estes parâmetros (uma operação de cada vez):

| Ambiente | Operações, em ordem | Aceite |
|---|---|---|
| Reprodução da base | `setup` com `flavor=baseline`, `export`, `cleanup` | A base 0.20.0 é ativada em estado limpo. O cenário de exportação documenta o comportamento anterior; testes de reprodução não entram na matriz do alvo. |
| Instalação limpa | `setup` com `flavor=current`, `smoke`, `configuration`, `export`, `dataset`, `cleanup` | Meta 0.21.0 sozinho em WordPress 7.1.4+ / PHP 8.3+ de 64 bits; autorização, exportação, documentação e dados coletados passam. |
| Migração direta | `setup` com `flavor=upgrade`, `upgrade`, `cleanup` | A 0.20.0 ativada grava dados sintéticos e digests de origem; em processo novo, a 0.21.0 compara registros, histórico, opções, agenda, pausa, cursor, progresso, concessão e retenção sem divulgar os registros. |

`setup` retorna `data.install.exit_code`; operações de teste retornam `data.exit_code`, e o resumo JSON está em `stdout`. Exigir saída zero e `failed=0` ainda que o transporte MCP tenha retornado sucesso. `lab_busy` significa que outra operação da mesma bancada está em curso. O teste de exportação usa somente ativos sintéticos e valida seu modo conforme a versão efetivamente ativada. A instalação em produção não é necessária para essas provas.

Após cada ambiente, exija zero tabelas e remoção do diretório/manifesto. Remova somente os dois arquivos temporários desta rodada com guardas de SHA e backup e confira `meta/health` e descoberta normal, sem QA. O snapshot de integridade exclui auditoria de transporte e opções técnicas declaradas; ele não suprime a observação de manutenção fora do intervalo entre as duas coletas. A implantação do instalador final no site é uma operação separada.

Em tests/regressions estão cenários do acervo de anúncios, orçamento, diagnósticos e monitoramento derivados da base. Executam em instalação privada com F3_LAB_ROOT e os respectivos acompanhantes quando exigidos. Não entram na contagem da rodada sem evidência de execução. O fonte anterior mantém suas evidências históricas; não contar testes herdados que não tenham sido executados nesta rodada.

## Integridade dos manuais e trocas de seleção

Depois de gerar o runtime com build/build.py, execute:

```sh
python3 tests/docs/check.py /caminho/para/php plugin/wp-mcp-meta-fator3
node tests/browser/selection-race.cjs /tmp/meta-identidade.json build/assets/admin.js /tmp/meta-selecao.json
```

O primeiro comando usa uma cópia temporária, testa bytes UTF-8 e cria nessa cópia um arquivo alterado, um arquivo ausente e um link para fora da pasta. Não altera o instalador nem exige banco; o teste separado em WordPress verifica autorização administrativa real. O segundo comando injeta atrasos nas respostas REST simuladas e verifica controles de conta, relatório, histórico, arquivo, conversas e agenda. Para reproduzir a base, use HTML e JS extraídos do instalador 0.20.0; a evidência de reprodução é separada da matriz final.
