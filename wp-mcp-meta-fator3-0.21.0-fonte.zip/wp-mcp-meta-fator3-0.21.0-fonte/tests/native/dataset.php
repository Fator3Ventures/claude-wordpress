<?php
require __DIR__.'/guard.php';require f3qa021_root().'/wordpress/wp-load.php';f3qa021_guard_db();require __DIR__.'/seed-connection090.php';
use Fator3\Meta as M;
wp_set_current_user(1);$checks=[];$calls=[];$mail=0;$mode='normal';$id='dataset021-'.bin2hex(random_bytes(3));$account='19001';$dataset='19002';$sid=$id;$secret='SYNTHETIC-PRIVATE-TOKEN-0190';
$tz=new DateTimeZone('America/Sao_Paulo');$day=(new DateTimeImmutable('yesterday',$tz))->format('Y-m-d');$q=['connection_id'=>$id,'channel'=>'dataset','account_id'=>$dataset,'ads_account_id'=>$account,'report'=>'dataset_quality','date_from'=>$day,'date_to'=>$day];
function ck190(string $n,bool $ok):void{global $checks;$checks[]=['name'=>$n,'passed'=>$ok];if(!$ok)throw new RuntimeException($n);}
function query190(array $q):array{M\Http::budget(40,25);return M\Api::dispatch('query',$q);}
function rows190(array $r,string $kind):array{return array_values(array_filter($r['data']['rows']??[],static fn($v)=>($v['record_kind']??'')===$kind));}
function job190(array $q,string $sid):array{
 $j=M\Jobs::create(['query'=>$q,'idempotency_key'=>'dataset021-'.wp_generate_uuid4(),'schedule_id'=>$sid]);$r=M\Store::get('schedule',$sid);$v=$r['value'];$v['last_job']=$j['job_id'];M\Store::put('schedule',$sid,$v,$r['revision']);return M\Jobs::run($j['job_id'],true);
}
$fixture=static function($pre,$args,$url)use(&$calls,&$mode,$id,$account,$dataset,$secret){
 if(!str_starts_with($url,'https://graph.facebook.com/'))return new WP_Error('unexpected_host');$path=preg_replace('~^/v[0-9.]+/~','',parse_url($url,PHP_URL_PATH));parse_str(parse_url($url,PHP_URL_QUERY)??'',$x);$calls[]=['path'=>$path,'query'=>$x];
 $resp=static fn($v,$http=200)=>['response'=>['code'=>$http],'headers'=>[],'body'=>wp_json_encode($v)];
 $error=static fn($code=100,$http=400)=>$resp(['error'=>['message'=>'(#100) Invalid parameter event_source for dataset John Smith john@example.invalid 5511999999999 192.0.2.10 https://example.invalid/?token='.$secret.' '.$secret,'error_user_msg'=>'Requires ads_read permission for dataset John Smith','type'=>'OAuthException','fbtrace_id'=>'TraceFixture0190','code'=>$code,'error_subcode'=>7]],$http);
 if($path==='me')return $resp(['id'=>'19000']);
 if($path==='act_'.$account)return $resp(['id'=>'act_'.$account,'account_id'=>$account,'timezone_name'=>'America/Sao_Paulo','currency'=>'BRL']);
 if($path===$dataset.'/adaccounts')return $error(); // Base reproduction: old prerequisite prevents every independent read.
 if($path==='act_'.$account.'/adspixels'){if($mode==='binding_denied')return $error(200,403);return $resp(['data'=>$mode==='unassigned'?[]:[['id'=>$dataset]]]);}
 if($path===$dataset.'/stats'){
  $source=$x['event_source']??'';
  if($mode==='stats_denied'||($mode==='browser_denied'&&$source==='WEB_ONLY')||($mode==='server_denied'&&$source==='SERVER_ONLY'))return $error();
  if($mode==='server_transient'&&$source==='SERVER_ONLY')return $error(2,503);
  if($mode==='server_permission'&&$source==='SERVER_ONLY')return $error(200,403);
  if($mode==='stats_empty')return $resp(['data'=>[]]);
  if($mode==='midbudget'&&$source==='WEB_ONLY')M\Http::budget(0,25);
  if($mode==='revision'&&$source==='WEB_ONLY'){$r=M\Store::get('connection',$id);$v=$r['value'];$v['authorization_revision']++;M\Store::put('connection',$id,$v,$r['revision']);}
  $b=[];for($at=(int)$x['start_time'];$at<(int)$x['end_time'];$at+=3600){$count=in_array($mode,['zero','event_missing'],true)?0:($at===(int)$x['start_time']?($source==='WEB_ONLY'?5:7):0);$values=[['value'=>'Lead','count'=>$count]];if($mode==='event_missing'&&$at>(int)$x['start_time'])$values=[];$b[]=['aggregation'=>'event','start_time'=>$at,'data'=>$values];}
  if($mode==='missing_hour')array_pop($b);if($mode==='duplicate')$b[]=$b[0];if($mode==='outside')$b[0]['start_time']--;if($mode==='negative')$b[0]['data'][0]['count']=-1;
  if($mode==='pages'){if(empty($x['after']))return $resp(['data'=>array_slice($b,0,12),'paging'=>['next'=>'https://evil.invalid/no','cursors'=>['after'=>'page2']]]);$b=array_slice($b,12);}
  return $resp(['data'=>$b]);
 }
 if($path==='act_'.$account.'/adsets'){if($mode==='optimization_denied')return $error();return $resp(['data'=>[['id'=>'19003','account_id'=>$account,'effective_status'=>'ACTIVE','name'=>'QA','promoted_object'=>['pixel_id'=>$dataset,'custom_event_type'=>'LEAD']]]]);}
 if($path==='dataset_quality'){
  if($mode==='emq_empty')return $resp(['web'=>[]]);if($mode==='emq_denied')return $error();if($mode==='emq_permission')return $error(200,403);if($mode==='emq_transient')return $error(2,503);
  $entry=['event_name'=>'Lead','event_match_quality'=>['composite_score'=>6.1,'match_key_feedback'=>[['identifier'=>'email','coverage'=>['percentage'=>90]]],'unrequested_private'=>'never-store']];
  if($mode==='emq_invalid')$entry['event_match_quality']['composite_score']=11;
  return $resp(['web'=>$mode==='emq_mixed'?[$entry,['event_name'=>'Bad','event_match_quality'=>['composite_score'=>11]]]:[$entry]]);
 }
 return new WP_Error('unexpected_path');
};$mf=static function()use(&$mail){$mail++;return true;};add_filter('pre_http_request',$fixture,1,3);add_filter('pre_wp_mail',$mf,1);
try{
 lab_seed_connection090(['connection_id'=>$id,'expected_revision'=>0,'token'=>$secret,'assets'=>['ads'=>[$account],'dataset'=>[$dataset]]]);$r=M\Store::get('connection',$id);$v=$r['value'];$v['token_identity']=['app_verified'=>true,'validated_generation'=>$v['credential_generation'],'scopes'=>['ads_read','ads_management','business_management']];M\Store::put('connection',$id,$v,$r['revision']);
 M\Schedules::save(['schedule_id'=>$sid,'query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>1440]);

  ck190('encoded secret removed before public projection',!str_contains(M\ProviderDiagnostic::from(['error'=>['message'=>'Invalid &#114;ead token']],400,['token'=>'read'])['provider_message'],'read'));
  $r=query190($q);$count=rows190($r,'event_counts')[0]??[];$emq=rows190($r,'emq_snapshot')[0]??[];
  ck190('normal counts and current EMQ coexist',$r['success']&&$count['browser_count']===5&&$count['server_count']===7&&$emq['emq']['composite_score']===6.1&&$r['data']['coverage']['complete']);
  ck190('forward binding and supported source aggregation',!in_array($dataset.'/adaccounts',array_column($calls,'path'),true)&&!array_filter($calls,static fn($v)=>str_ends_with($v['path'],'/stats')&&($v['query']['aggregation']??'')!=='event'));
  ck190('EMQ requests minimal projection and drops unknown fields',end($calls)['query']['fields']==='web{event_name,event_match_quality}'&&!str_contains(wp_json_encode($r),'never-store'));
  foreach(['emq_empty','emq_denied','emq_permission','emq_transient','emq_invalid','emq_mixed','stats_denied','browser_denied','server_denied','server_permission','server_transient','optimization_denied','midbudget','missing_hour','event_missing','duplicate','outside','negative','stats_empty'] as $mode){
   $r=query190($q);ck190('partial query retains independent data: '.$mode,$r['success']&&!$r['data']['coverage']['complete']&&count($r['data']['rows'])>0);
   ck190('partial never invents optimized zero: '.$mode,!in_array(true,array_column($r['data']['rows'],'zero_confirmed'),true));
   $counts=rows190($r,'event_counts');$emqs=rows190($r,'emq_snapshot');
   if(str_starts_with($mode,'emq_'))ck190('counts survive EMQ failure: '.$mode,($counts[0]['browser_count']??null)===5&&($counts[0]['server_count']??null)===7);
   if(in_array($mode,['stats_denied','stats_empty','duplicate','outside','negative'],true))ck190('EMQ survives counts failure: '.$mode,($emqs[0]['emq']['composite_score']??null)===6.1);
  }
  $mode='pages';$r=query190($q);ck190('hourly pagination completes without following remote URL',$r['success']&&$r['data']['coverage']['complete']&&rows190($r,'event_counts')[0]['browser_count']===5);
  $mode='zero';$r=query190($q);ck190('zero requires explicit per-event buckets for every hour',rows190($r,'event_counts')[0]['zero_confirmed']===true);
  foreach(['unassigned','binding_denied'] as $mode){$n=count($calls);$r=query190($q);ck190('binding remains mandatory: '.$mode,!$r['success']&&$r['code']==='asset_access_denied'&&count($calls)===$n+3);}
  $mode='normal';$old=$q;$old['date_from']=$old['date_to']=(new DateTimeImmutable($day,$tz))->modify('-2 days')->format('Y-m-d');$n=count($calls);$r=query190($old);ck190('historical counts do not invent EMQ history',$r['success']&&!rows190($r,'emq_snapshot')&&!in_array('dataset_quality',array_column(array_slice($calls,$n),'path'),true));
  $mode='server_permission';$j=job190($q,$sid);ck190('partial job persists useful rows',$j['status']==='partial'&&$j['successful_rows']>0);
  $err=$j['last_error'];ck190('job retains measured readable diagnostic',($err['request_stage']??'')==='stats_server'&&$err['provider_code']===200&&$err['provider_type']==='OAuthException'&&$err['fbtrace_id']==='TraceFixture0190'&&str_contains($err['provider_message'],'Invalid parameter'));
  $schedule=M\Store::get('schedule',$sid);$health=M\Api::dispatch('health');$ownHealth=array_values(array_filter($health['data']['datasets']['diagnostics']??[],static fn($v)=>($v['schedule_id']??null)===$sid))[0]??[];$last=false;for($offset=0;$offset<10000&&!$last;$offset+=100){$page=M\Store::recent('audit',$offset,100);$found=array_filter($page,static fn($v)=>($v['value']['job_id']??'')===$j['job_id']);if($found)$last=end($found);if(count($page)<100)break;}
  ck190('agenda audit and health retain call diagnostic',($schedule['value']['last_error']['provider_call']??null)===$err['provider_call']&&($last['value']['last_error']['provider_call']??null)===$err['provider_call']&&($ownHealth['last_error']['request_stage']??null)==='stats_server');
  ck190('permission health has actionable attribution guidance',str_contains($ownHealth['action'],'Usar conjunto de dados'));
  $combined=wp_json_encode([$j,$schedule,$health,$last]);foreach([$secret,'John','Smith','john@example.invalid','5511999999999','192.0.2.10','https://example.invalid/?token'] as $private)ck190('diagnostics redact fixture private value '.hash('sha256',$private),!str_contains($combined,$private));
  $n=count($calls);$before=M\Store::get('schedule',$sid);M\Api::dispatch('list-schedules');M\Api::dispatch('health');ck190('diagnostic reads preserve schedule and make no HTTP/mail',$before===M\Store::get('schedule',$sid)&&count($calls)===$n&&$mail===0);
  if(class_exists('Fator3\\McpFiles\\SafeOutput')){
   wp_get_abilities();$wire=wp_get_ability('meta/job-status')->execute(['job_id'=>$j['job_id']]);$wl=wp_get_ability('meta/list-schedules')->execute([]);$wh=wp_get_ability('meta/health')->execute([]);
   ck190('MCP preserves safe message trace and source call',($wire['data']['last_error']['fbtrace_id']??null)==='TraceFixture0190'&&($wire['data']['last_error']['provider_call']??null)===$err['provider_call']);
   ck190('MCP agenda and health expose measured samples',(bool)array_filter($wl['data']['schedules']??[],static fn($v)=>($v['id']??$v['schedule_id']??null)===$sid&&!empty($v['last_errors']))&&!empty($wh['data']['datasets']['diagnostics']));
  }
  $cfg=['ready'=>true,'connection_id'=>$id,'account_id'=>$account,'revision'=>1,'reports'=>['dataset_quality'],'dataset_ids'=>[$dataset]];$client=M\MonitoringReader::register_consumer('qa0190','1.0.0',M\MonitoringReader::CONTRACT,static function()use(&$cfg){return $cfg;});$context=['connection_id'=>$id,'account_id'=>$account];
  ck190('SDK requires explicit grant',$client->query($context+['report'=>'dataset_quality','dataset_id'=>$dataset])['code']==='grant_revoked');
  M\MonitoringReader::save($context+['consumer_id'=>'qa0190','expected_revision'=>0,'enabled'=>true,'reports'=>['dataset_quality'],'dataset_ids'=>[$dataset]]);$n=count($calls);$read=$client->query($context+['report'=>'dataset_quality','dataset_id'=>$dataset]);ck190('partial data reaches local SDK without remote calls',$read['success']&&count($read['data']['rows'])>=2&&count($calls)===$n);
  if(class_exists('F3Base_Meta_Monitoramento')){
   F3Base_Instalacao::atualizar();wp_set_current_user(0);wp_set_current_user(1);$opts=array_replace(F3Base_Meta_Monitoramento::opcoes(),['ativo'=>true,'conexao'=>$id,'conta_id'=>$account,'dataset_ids'=>[$dataset],'revisao'=>F3Base_Meta_Monitoramento::opcoes()['revisao']+1,'avisar'=>false,'canal'=>'email']);
   $saved=F3Base_Options::pelo_canal('ability',static fn()=>F3Base_Options::gravar(F3Base_Meta_Monitoramento::OPTION,$opts,F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao(F3Base_Meta_Monitoramento::OPTION)));ck190('Core config ready for actual partial collector',!empty($saved['persisted']));
   M\MonitoringReader::save($context+['consumer_id'=>'base-site-core-fator3','expected_revision'=>0,'enabled'=>true,'reports'=>['ads_activity','dataset_quality'],'dataset_ids'=>[$dataset]]);
   foreach(['emq_denied','stats_denied'] as $mode){$j=job190($q,$sid);$n=count($calls);$read=F3Base_Meta_Monitoramento::ler(['de'=>$day,'ate'=>(new DateTimeImmutable('today',$tz))->format('Y-m-d'),'report'=>'dataset_quality','dataset_id'=>$dataset]);$rows=array_column($read['linhas']??[],'row');ck190('Core reads actual partial result: '.$mode,($read['ok']??false)&&count($rows)>0&&count($calls)===$n);if($mode==='emq_denied')ck190('Core preserves available counts',in_array(5,array_column($rows,'browser_count'),true));else ck190('Core preserves available EMQ',in_array(6.1,array_column(array_column($rows,'emq'),'composite_score'),true));}
   ck190('partial collection never sends Core mail',$mail===0);
  }
  // Unit-level boundary cases supplement full collector execution: short/long DST days and overflow.
  $parser=new ReflectionMethod(M\Monitoring::class,'counts');
  foreach(['2026-03-08','2026-11-01'] as $date){$a=new DateTimeImmutable($date,new DateTimeZone('America/New_York'));$z=$a->modify('+1 day');$b=[];for($at=$a->getTimestamp();$at<$z->getTimestamp();$at+=3600)$b[]=['aggregation'=>'event','start_time'=>$at,'data'=>[['value'=>'Lead','count'=>0]]];$parsed=$parser->invoke(null,$b,$a->getTimestamp(),$z->getTimestamp());ck190('DST day complete without assuming 24 hours: '.$date,$parsed[1]&&$parsed[2]['Lead']&&$parsed[0]['Lead']===0);}
  $a=1000000000;$b=[['aggregation'=>'event','start_time'=>$a,'data'=>[['value'=>'Lead','count'=>PHP_INT_MAX]]],['aggregation'=>'event','start_time'=>$a+3600,'data'=>[['value'=>'Lead','count'=>1]]]];try{$parser->invoke(null,$b,$a,$a+7200);$overflow=false;}catch(M\Fault $e){$overflow=$e->reason==='upstream_invalid';}ck190('count integer overflow rejected',$overflow);
  $mode='revision';$before=M\Store::get('connection',$id);$r=query190($q);ck190('concurrent grant revision is fatal, not partial',$r['code']==='revision_conflict');$current=M\Store::get('connection',$id);M\Store::put('connection',$id,$before['value'],$current['revision']);
  $u=username_exists('dataset021sub')?:wp_create_user('dataset021sub',wp_generate_password(),'dataset021@example.invalid');(new WP_User($u))->set_role('subscriber');wp_set_current_user($u);$n=count($calls);ck190('subscriber cannot query diagnostics or history',!M\Api::dispatch('query',$q)['success']&&!M\Api::dispatch('health')['success']&&count($calls)===$n);wp_set_current_user(1);
 $out=['version'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>0,'producer_day'=>$day,'producer_timezone'=>$tz->getName(),'synthetic_http_calls'=>count($calls),'real_provider_calls'=>0,'mail_calls'=>$mail];
}catch(Throwable $e){$out=['version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>1,'exception'=>get_class($e),'message'=>$e->getMessage()];}
finally{wp_set_current_user(1);remove_filter('pre_http_request',$fixture,1);remove_filter('pre_wp_mail',$mf,1);$s=M\Store::get('schedule',$sid);if($s)M\Store::remove('schedule',$sid,$s['revision']);$c=M\Store::get('connection',$id);if($c)M\Store::remove('connection',$id,$c['revision']);}
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/dataset021.json',wp_json_encode($out));echo wp_json_encode($out);if($out['failed'])exit(1);
