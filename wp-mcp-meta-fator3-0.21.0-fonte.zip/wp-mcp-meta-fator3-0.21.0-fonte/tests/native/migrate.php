<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';
require f3qa021_root().'/wordpress/wp-load.php';
f3qa021_guard_db();wp_set_current_user(1);
require __DIR__.'/migration-state.php';
require __DIR__.'/migration-consumer.php';
$before=json_decode(file_get_contents(f3qa021_root().'/baseline-state.json'),true,512,JSON_THROW_ON_ERROR);
$after=f3qa021_state();$checks=[];
$ck=static function(string $name,bool $ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>$ok];};
$ck('Base snapshot is from activated Meta 0.20.0',($before['source_version']??null)==='0.20.0');
$ck('New process loads active Meta 0.21.0',M\Config::VERSION==='0.21.0'&&get_option('active_plugins')===['wp-mcp-meta-fator3/wp-mcp-meta-fator3.php']);
foreach(['records','history','options'] as $kind){
    $ck('Direct migration preserves count and digest: '.$kind,$before[$kind]===$after[$kind]);
}
$ck('Unlimited retention, owner and asset are preserved',($c=M\Connections::get('qa-upgrade021'))['retention_mode']==='unlimited'&&$c['users']===[1]&&$c['assets']['instagram']===['777071']);
$ck('Explicit 30-day policy remains finite',($c=M\Connections::get('upgrade-finite021'))['retention_mode']==='finite'&&(int)$c['retention_days']===30);
$ck('Paused job retains cursor and progress',($paused=M\Store::get('job','qa-paused021')['value'])['status']==='paused'&&$paused['cursor']==='synthetic-checkpoint'&&$paused['pages']===2&&$paused['rows']===5);
$ck('Schedule remains enabled',M\Store::get('schedule','qa-upgrade021')['value']['enabled']);
$ck('No automatic erasure; all four message receipts preserved',get_option('f3_meta_message_privacy_key',false)===false&&count(M\Store::list('message_event'))===4);
$ck('Monitoring grant remains ready',f3qa021_consumer()->status(['connection_id'=>'upgrade-monitor021','account_id'=>'160'])['success']);
$h=M\Api::dispatch('health');$s=M\Api::dispatch('list-schedules');
$ck('Local health available and read-only',$h['success']&&($h['data']['repair']??null)==='not_attempted');
$related=static function(array $s){foreach($s as $v)if(($v['id']??$v['schedule_id']??null)==='qa-upgrade021')return $v;return [];};
$ls=$related($s['data']['schedules']??[]);$hs=$related($h['data']['schedules']??[]);
$ck('Prior error stays superseded in schedule and health',($ls['last_error_superseded']??false)&&($ls['last_error_at']??0)===100&&($hs['last_error_state']??null)==='superseded');
$docs=M\Documentation::read(['document'=>'ADMINISTRATION.md']);
$ck('New process serves candidate documentation',$docs['plugin_version']===M\Config::VERSION&&$docs['sha256']===hash_file('sha256',M\Config::DIR.'docs/ADMINISTRATION.md'));
$out=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'version'=>M\Config::VERSION,'base_version'=>$before['source_version'],'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed'])),'records'=>$after['records']['count'],'history_rows'=>$after['history']['count'],'options'=>$after['options']['count']];
echo wp_json_encode($out)."\n";exit($out['failed']?1:0);
