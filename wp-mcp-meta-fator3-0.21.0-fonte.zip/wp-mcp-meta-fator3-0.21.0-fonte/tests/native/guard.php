<?php
/** Prevent tests being accidentally run against the shared WordPress. */
function f3qa021_root(): string {
    $root=getenv('F3_LAB_ROOT');
    if (!is_string($root)||!preg_match('/^f3qaui021_[a-f0-9]{12}_$/D',basename($root))||
        $root!==sys_get_temp_dir().'/'.basename($root)||!is_dir($root)||is_link($root)) {
        throw new RuntimeException('An isolated 0.21.0 lab is required');
    }
    return $root;
}
function f3qa021_guard_db(): void {
    global $wpdb;
    if ($wpdb->prefix!==basename(f3qa021_root())||ABSPATH!==f3qa021_root().'/wordpress/') {
        throw new RuntimeException('Private WP root or table prefix mismatch');
    }
    if (PHP_VERSION_ID<80300||PHP_INT_SIZE!==8||version_compare($GLOBALS['wp_version'],'7.1.4','<')) {
        throw new RuntimeException('Requires WordPress 7.1.4+ and 64-bit PHP 8.3+');
    }
}
