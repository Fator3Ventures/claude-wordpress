<?php
declare(strict_types=1);
/** Run only in the disposable Meta lab. All assets, jobs and rows are synthetic. */
require __DIR__.'/guard.php';
$lab=f3qa021_root();require $lab.'/wordpress/wp-load.php';f3qa021_guard_db();
use Fator3\Meta as M;
wp_set_current_user(1);
$base=M\Config::VERSION==='0.20.0';
$checks=[];$http=0;
$check=static function(string $name,bool $ok)use(&$checks):void{$checks[]=['name'=>$name,'passed'=>$ok];if(!$ok)throw new RuntimeException($name);};
$call=static fn(string $op,array $i)=>M\Api::dispatch($op,$i);
$httpBlock=static function()use(&$http){++$http;return new WP_Error('synthetic_block');};
add_filter('pre_http_request',$httpBlock,1);
try{
    $check('known baseline or candidate',in_array(M\Config::VERSION,['0.20.0','0.21.0'],true));
    $id='qaexport-'.substr(wp_generate_uuid4(),0,8);$dataset='8121';$ads='8122';$ig='8123';
    $assets=['dataset'=>[$dataset],'ads'=>[$ads],'instagram'=>[$ig]];
    M\Connections::save(['connection_id'=>$id,'expected_revision'=>0,'assets'=>$assets]);
    $select=static function(array $change)use($id):void{M\Connections::save(['connection_id'=>$id,'expected_revision'=>M\Connections::get($id)['revision'],'assets'=>$change]);};
    $p=M\Access::principal();$q=['connection_id'=>$id,'channel'=>'dataset','account_id'=>$dataset,'report'=>'dataset_quality','ads_account_id'=>$ads,'limit'=>1];
    $job=hash('sha256',$id.':job');$day=gmdate('Y-m-d',time()-86400);
    $data=$q+['api_version'=>M\Config::API_VERSION,'temporal'=>'daily','fetched_at'=>gmdate('c'),'timezone'=>'America/Sao_Paulo','currency'=>'BRL','selection'=>$q,'coverage'=>['complete'=>false],
        'rows'=>[['id'=>'synthetic-event-a','record_kind'=>'event_counts','date'=>$day,'browser_count'=>3,'server_count'=>null],
                 ['id'=>'synthetic-event-b','record_kind'=>'event_counts','date'=>$day,'browser_count'=>null,'server_count'=>5]]];
    M\History::ingest($data,$p,M\Connections::get($id),$id.':history');
    M\Store::put('job',$job,['principal'=>$p,'query'=>$q,'pages'=>1,'connection_revision'=>M\Connections::get($id)['revision'],'status'=>'complete']);
    M\Store::put('result',$job.':000000',['data'=>$data]);
    $spec=['query'=>$q,'format'=>'json','idempotency_key'=>$id.'-history'];
    $new=$call('history-export',$spec);$check('authorized history receipt queued',($new['data']['state']??null)==='queued');$hist=$new['data']['export_id'];
    $step=static fn($key)=>$call('history-export-step',['export_id'=>$key]);
    $first=$step($hist);$last=$step($hist);$check('two history pages checkpoint once each',($first['data']['parts']??0)===1&&($last['data']['state']??'')==='complete'&&$last['data']['parts']===2&&$last['data']['rows']===2);
    $read=static fn()=> $call('history-export-read',['export_id'=>$hist,'part'=>1,'offset_bytes'=>5,'byte_limit'=>13]);
    $r0=$read();$check('authorized noninitial history byte range readable',$r0['success']&&strlen(base64_decode($r0['data']['content_base64'],true))===13);
    $jobSpec=['job_id'=>$job,'format'=>'json','idempotency_key'=>$id.'-job'];$j=$call('export',$jobSpec);
    $check('authorized job export complete',!empty($j['data']['export_id']));$export=$j['data']['export_id'];
    $readJob=static fn()=> $call('export-read',['export_id'=>$export,'offset_bytes'=>7,'byte_limit'=>11]);
    $page=static fn()=> $call('job-results',['job_id'=>$job,'page'=>0]);
    $j0=$readJob();$check('authorized job page and job byte range readable',$j0['success']&&$page()['success']);
    $pendingSpec=array_replace($spec,['idempotency_key'=>$id.'-waiting']);$waiting=$call('history-export',$pendingSpec)['data']['export_id'];
    $select(['ads'=>[]]);$check('history-query denies removed linked Ads account',($call('history-query',$q)['code']??null)==='asset_access_denied');
    $expect=function(string $name,array $v)use($base,$check):void{
        $check(($base?'base reproduces missing linked-asset check: ':'candidate rejects removed linked asset: ').$name,
               $base ? $v['success'] : (!$v['success']&&$v['code']==='asset_access_denied'&&!isset($v['data']['content_base64'])&&!isset($v['data']['rows'])));
    };
    $expect('part of completed history export',$read());
    $expect('completed history step receipt',$step($hist));
    $expect('idempotent history create replay',$call('history-export',$spec));
    $expect('new history export intent',$call('history-export',array_replace($spec,['idempotency_key'=>$id.'-revoked'])));
    $whileRevoked=$step($waiting);$waitingState=M\Store::get('history_export',$waiting)['value'];
    $check($base?'base permanently fails a previously queued receipt when the Ads asset is removed':'revocation does not advance or fail the existing queued receipt',
           $base?($whileRevoked['success']&&$waitingState['state']==='failed'&&$waitingState['last_code']==='asset_access_denied'):
                 (!$whileRevoked['success']&&$whileRevoked['code']==='asset_access_denied'&&$waitingState['state']==='queued'&&$waitingState['parts']===0));
    $expect('stored job results',$page());
    $expect('download from completed job export',$readJob());
    $expect('create job export after revocation',$call('export',array_replace($jobSpec,['idempotency_key'=>$id.'-job-revoked'])));
    $control=$call('history-query',['connection_id'=>$id,'channel'=>'instagram','account_id'=>$ig,'report'=>'profile']);
    $check('independent Instagram read still authorized without Ads',$control['success']);
    $select(['ads'=>[$ads],'dataset'=>[]]);$check('primary dataset removal still denies both downloads',$read()['code']==='asset_access_denied'&&$readJob()['code']==='asset_access_denied');
    $select(['dataset'=>[$dataset]]);
    if(!$base){$continued=$step($waiting);$check('reauthorized queued export resumes without replacement',$continued['success']&&$continued['data']['state']==='queued'&&$continued['data']['parts']===1);}
    $r1=$read();$j1=$readJob();
    $check('explicit reauthorization restores original retained bytes',$r1['success']&&$j1['success']&&$r0['data']['content_base64']===$r1['data']['content_base64']&&$r0['data']['part_sha256']===$r1['data']['part_sha256']&&$j0['data']['content_base64']===$j1['data']['content_base64']&&$j0['data']['sha256']===$j1['data']['sha256']);
    // Hide exactly the read-back of an inserted part. This leaves the actual encrypted
    // part in place and simulates a write whose confirmation was not visible to Store::put.
    $resume=$call('history-export',array_replace($spec,['idempotency_key'=>$id.'-resume']))['data']['export_id'];$partKey=$resume.':000000';
    $armed=false;$injected=0;
    $fault=static function($sql)use(&$armed,&$injected,$partKey){
        if(str_contains($sql,"'history_export_part'")&&str_contains($sql,$partKey)){
            if(str_starts_with($sql,'INSERT IGNORE INTO '))$armed=true;
            elseif($armed&&str_starts_with($sql,'SELECT * FROM ')){
                ++$injected;$armed=false;return str_replace($partKey,$partKey.'-not-visible',$sql);
            }
        }
        return $sql;
    };
    add_filter('query',$fault);
    try{$uncertain=$step($resume);}finally{remove_filter('query',$fault);}
    $checkpoint=M\Store::get('history_export',$resume)['value'];$part=M\Store::get('history_export_part',$partKey);
    $check('fault injection left confirmed ciphertext but hid its read-back',$injected===1&&is_array($part));
    if($base){
        $check('base reproduces terminal failed receipt despite existing checkpoint',$uncertain['success']&&$checkpoint['state']==='failed'&&$checkpoint['parts']===1&&$checkpoint['last_code']==='persistence_unconfirmed');
        $check('base cannot reconcile that part on retry',$step($resume)['data']['state']==='failed');
    }else{
        $check('uncertain write leaves receipt queued without cursor advancement',!$uncertain['success']&&$uncertain['code']==='persistence_unconfirmed'&&$checkpoint['state']==='queued'&&$checkpoint['parts']===0&&$checkpoint['rows']===0&&$checkpoint['cursor']===null);
        $next=$step($resume);$check('same ID reconciles exactly the persisted first part',$next['success']&&$next['data']['state']==='queued'&&$next['data']['parts']===1&&$next['data']['rows']===1&&M\Store::get('history_export_part',$partKey)['revision']===$part['revision']);
        $done=$step($resume);$check('retry finishes with two rows and two parts',$done['data']['state']==='complete'&&$done['data']['parts']===2&&$done['data']['rows']===2);
        $body='';for($n=0;$n<2;$n++){$v=$call('history-export-read',['export_id'=>$resume,'part'=>$n]);$bytes=base64_decode($v['data']['content_base64'],true);$check('stored digest matches recovered part '.$n,hash('sha256',$bytes)===$v['data']['part_sha256']);$body.=$bytes;}
        $parsed=json_decode($body,true,512,JSON_THROW_ON_ERROR);$ids=array_column(array_column($parsed['rows'],'row'),'id');sort($ids);
        $check('recovered JSON contains both source rows exactly once',$ids===['synthetic-event-a','synthetic-event-b']);
    }
    $check('all export operations are local',$http===0);
}catch(Throwable $e){if(!$checks||end($checks)['passed'])$checks[]=['name'=>'unexpected '.$e::class.': '.$e->getMessage(),'passed'=>false];}
finally{remove_filter('pre_http_request',$httpBlock,1);}
$result=['version'=>M\Config::VERSION,'mode'=>$base?'base-reproduction':'candidate','checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed'])),'real_provider_calls'=>0,'http_requests'=>$http];
echo wp_json_encode($result);exit($result['failed']?1:0);
