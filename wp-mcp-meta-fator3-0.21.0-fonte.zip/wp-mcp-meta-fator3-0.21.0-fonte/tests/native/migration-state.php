<?php
/** Stable business-state digest; exports no row contents to evidence. */
function f3qa021_state(): array {
    global $wpdb;
    $records=Fator3\Meta\Store::table();$history=Fator3\Meta\History::table();
    $queries=[
        'records'=>$wpdb->prepare("SELECT * FROM %i WHERE bucket NOT IN ('audit','migration','history_generation') ORDER BY bucket,record_key",$records),
        'history'=>$wpdb->prepare('SELECT * FROM %i ORDER BY row_key',$history),
        'options'=>$wpdb->prepare("SELECT option_name,option_value FROM %i WHERE option_name LIKE %s AND option_name NOT IN ('f3_meta_schema','f3_meta_history_schema','f3_meta_queue_migration','f3_meta_queue_settled','f3_meta_worker_schedule_attempt','f3_meta_audit_health','f3_meta_retention0110') ORDER BY option_name",$wpdb->options,$wpdb->esc_like('f3_meta_').'%')
    ];
    $state=[];
    foreach ($queries as $kind=>$sql) {
        $rows=$wpdb->get_results($sql,ARRAY_A);
        if ($wpdb->last_error || !is_array($rows) || !$rows)throw new RuntimeException('Missing seeded state for '.$kind);
        $state[$kind]=['count'=>count($rows),'sha256'=>hash('sha256',serialize($rows))];
    }
    return $state;
}
