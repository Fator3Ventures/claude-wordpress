<?php
require __DIR__.'/guard.php';require f3qa021_root().'/wordpress/wp-load.php';f3qa021_guard_db();use Fator3\Meta as M;wp_set_current_user(1);
$checks=[];$ck=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
$http=0;add_filter('pre_http_request',static function($pre)use(&$http){++$http;return new WP_Error('external_blocked');});
$_GET['tab']=['not-a-tab'];$ck('tab array resolves without warning',M\Admin::currentTab()==='connections');$_GET['tab']='connections';
ob_start();M\Admin::screen();$html=ob_get_clean();$ck('real WP renders admin title and four configuration groups',str_contains($html,'Fator3 MCP Meta')&&substr_count($html,'class="f3-form-block"')===3&&str_contains($html,'4. Usuários WordPress associados'));
$ck('rotation fields and primary fields have different labels',str_contains($html,'for="f3-rotate-expires"')&&str_contains($html,'for="f3-connection-expires"'));
$saved=M\Api::dispatch('save-connection',['connection_id'=>'qa-ui021','expected_revision'=>0,'label'=>'QA · Painel','enabled'=>false,'retention_mode'=>'finite','retention_days'=>321,'users'=>[1]]);
$ck('finite retention persisted without credential',($saved['data']['connection']['retention_days']??0)===321);
$rv=$saved['data']['connection']['revision']??0;$edit=M\Api::dispatch('save-connection',['connection_id'=>'qa-ui021','expected_revision'=>$rv,'retention_mode'=>'unlimited']);
$ck('switch to unlimited retains explicit finite duration',$edit['success']&&$edit['data']['connection']['retention_mode']==='unlimited'&&$edit['data']['connection']['retention_days']===321);
$x=M\Api::dispatch('save-connection',['connection_id'=>'qa-ui021','expected_revision'=>$rv,'label'=>'stale']);
$ck('outdated edit cannot overwrite newer retention',$x['code']==='revision_conflict'&&M\Connections::get('qa-ui021')['label']==='QA · Painel');
wp_clear_scheduled_hook(M\Config::KEY.'_worker');$health=M\Api::dispatch('health');
$ck('health does not rearm removed worker',$health['success']&&($health['data']['repair']??'')==='not_attempted'&&!wp_next_scheduled(M\Config::KEY.'_worker'));
$index=M\Documentation::read(['document'=>'index']);$doc='ADMINISTRATION.md';$txt='';$at=0;$pages=0;$rev=null;do{$i=['document'=>$doc,'offset'=>$at,'limit_bytes'=>256];if($rev)$i['expected_revision']=$rev;$v=M\Documentation::read($i);$txt.=$v['content'];$at=$v['next_offset'];$rev=$v['revision'];$pages++;}while($at!==null);
$ck('UTF-8 multipage guide matches installed bytes and index',$pages>1&&hash('sha256',$txt)===$rev&&$txt===file_get_contents(M\Config::DIR.'docs/'.$doc)&&count($index['documents'])===28);
$ck('ordinary document omits index while README retains it',!$v['documents']&&count(M\Documentation::read(['document'=>'README.md'])['documents'])===28);
$ck('wrong page revision rejected',M\Api::dispatch('documentation',['document'=>$doc,'offset'=>256,'expected_revision'=>str_repeat('0',64)])['code']==='revision_conflict');
$ck('path traversal rejected',!M\Api::dispatch('documentation',['document'=>'../wp-config.php'])['success']);
$ck('render, health, docs and local edits made no provider request',$http===0);
$user=wp_create_user('ui021subscriber',wp_generate_password(30),'ui021@example.invalid');wp_set_current_user($user);
foreach(['documentation'=>['document'=>'index'],'get-connection'=>['connection_id'=>'qa-ui021'],'save-connection'=>['connection_id'=>'qa-ui021','expected_revision'=>2,'label'=>'denied']] as $op=>$args){$req=new WP_REST_Request('POST','/f3-meta/v1/'.$op);$req->set_header('Content-Type','application/json');$req->set_body(wp_json_encode($args));$ck('subscriber denied via REST: '.$op,rest_do_request($req)->get_status()===403);}
class QaScreenDenied extends RuntimeException{}
add_filter('wp_die_handler',static fn()=>static function($m,$t,$a){throw new QaScreenDenied('denied',(int)($a['response']??0));});
try{M\Admin::screen();$denied=false;}catch(QaScreenDenied $e){$denied=$e->getCode()===403;}$ck('subscriber denied on admin screen with HTTP 403',$denied);
$o=['checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed'])),'pages'=>$pages,'outside_http'=>$http,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION];echo json_encode($o);exit($o['failed']?1:0);
