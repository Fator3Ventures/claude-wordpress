# Fator3 MCP Meta 0.21.0 — fonte

Base: instalador Meta 0.20.0 com SHA-256 2f229301c8dd08357ed9d023edc1d610ac1b78e01114dce45913e1979b95399b. O diretório plugin/wp-mcp-meta-fator3 contém os bytes do runtime entregue; build contém seus templates, documentos editáveis e assets.

**Build:** Python 3 e PHP CLI 8.3+ de 64 bits com funções de JSON/hash. Execute `python3 build/build.py` (ou informe F3_SOCIAL_PHP com o caminho absoluto do PHP). O resultado é build/dist/wp-mcp-meta-fator3-0.21.0-instalador.zip. O script verifica sintaxe, gera catálogos, compila a ajuda e fixa a ordem dos arquivos e o timestamp do ZIP. Para reproduzir o ZIP desta entrega, usar compressão zlib como no relatório. O fonte não embute o ZIP do instalador.

**Testes:** consulte tests/README.md. Evidências da rodada em evidence/. As reproduções de falhas na base 0.20.0 não entram na contagem de aprovações da candidata. Instruções operacionais e limites de aceite em plugin/wp-mcp-meta-fator3/docs/. Os pacotes acompanhantes mantêm identidade própria; não há componentes de QA no runtime.
