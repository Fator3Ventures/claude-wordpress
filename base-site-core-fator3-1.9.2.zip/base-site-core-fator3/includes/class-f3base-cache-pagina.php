<?php
/** Integração com cache de página: invalidação e evidência HTTP, sem editar o provedor. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class F3Base_Cache_Pagina {
	public const ESTADO = 'f3base_cache_estado';
	public const PROVA = 'f3base_cache_prova';
	public const CRON = 'f3base_cache_verificar';
	public const VALIDADE = 3600;
	public const EXPIRES_PASSADO = 'Wed, 11 Jan 1984 05:00:00 GMT';
	private static bool $marcado = false;
	private static bool $encerrando = false;

	public static function perfil(): array {
		global $cache_enabled, $wp_cache_mod_rewrite, $wpsc_save_headers, $super_cache_enabled;
		$wp = defined( 'WP_CACHE' ) && WP_CACHE;
		$wpsc = function_exists( 'wp_cache_clear_cache' );
		$ativo = $wp && ( $wpsc ? ! empty( $cache_enabled ) : true );
		$modo = ! $ativo ? 'desligado' : ( ! $wpsc ? 'desconhecido' : ( ! empty( $wpsc_save_headers ) || empty( $super_cache_enabled ) ? 'wp-cache-cabecalhos' : ( ! empty( $wp_cache_mod_rewrite ) ? 'expert' : 'simple' ) ) );
		return array( 'ativo' => $ativo, 'provedor' => $wpsc ? 'wp-super-cache' : ( $wp ? 'nao-identificado' : 'nenhum' ), 'modo' => $modo, 'limpeza_disponivel' => $wpsc );
	}

	/** As opções de operação, retenção e segredos não alteram HTML público. */
	public static function afeta( string $nome ): bool {
		return in_array( $nome, array( 'f3base_contato', 'f3base_ga4_measurement_id', 'f3base_gtm_container_id', 'f3base_google_ads', 'f3base_meta_pixel_id', 'f3base_linkedin_partner_id', 'f3base_linkedin_conversion_id', 'f3base_atribuicao', 'f3base_verificacao_google', 'f3base_verificacao_meta', 'f3base_consentimento', 'f3base_comportamento', 'f3base_robots', 'f3base_llms', 'f3base_redirects', 'f3base_seo_entidade', 'f3base_cabecalhos', 'f3base_nav_id' ), true );
	}
	public static function sanitizar( $valor, $padrao ): array {
		$v = is_array( $valor ) ? $valor : array();
		foreach ( array( 'versao', 'geracao', 'solicitado_em', 'limpo_em', 'codigo' ) as $campo ) { if ( ! is_scalar( $v[ $campo ] ?? null ) ) { $v[ $campo ] = ''; } }
		return array_replace( $v, array( 'versao' => substr( (string) $v['versao'], 0, 32 ), 'geracao' => substr( (string) $v['geracao'], 0, 64 ), 'pendente' => ! empty( $v['pendente'] ), 'solicitado_em' => max( 0, (int) $v['solicitado_em'] ), 'limpo_em' => max( 0, (int) $v['limpo_em'] ), 'codigo' => sanitize_key( (string) $v['codigo'] ) ) );
	}
	public static function estado(): array { return (array) F3Base_Options::fotografia( self::ESTADO )['valor']; }

	/** Agrupa alterações do mesmo pedido; outro processo recebe geração própria. */
	public static function solicitar(): bool {
		if ( self::$encerrando ) { return false; }
		if ( self::$marcado && ! empty( self::estado()['pendente'] ) ) { return true; }
		F3Base_Cache_Evidencia::migrar();
		for ( $i = 0; $i < 3; ++$i ) {
			$f = F3Base_Options::fotografia( self::ESTADO ); if ( $f['erro'] ) { return false; }
			$e = $f['valor'];
			$e['geracao'] = wp_generate_uuid4(); $e['pendente'] = true; $e['solicitado_em'] = time(); $e['codigo'] = 'limpeza_agendada';
			$r = F3Base_Options::gravar( self::ESTADO, $e, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
			self::$marcado = ! empty( $r['persisted'] );
			if ( self::$marcado ) { break; }
		}
		return self::$marcado;
	}

	/** Só é chamado depois da leitura de volta confirmada da opção. */
	public static function apos_escrita( string $nome ): ?array {
		if ( ! self::afeta( $nome ) || ! self::perfil()['ativo'] ) { return null; }
		$ok = self::solicitar();
		return array( 'status' => $ok ? 'not_attempted' : 'failed', 'applied' => false, 'codigo' => $ok ? 'cache_agendado' : 'cache_agendamento_falhou', 'motivo' => $ok ? 'Configuração salva. Limpeza do cache agendada para o fim desta operação; entrega pública pendente.' : 'Configuração salva; não foi possível registrar a limpeza do cache.' );
	}

	/** O provedor não devolve confirmação HTTP. A prova pública continua separada. */
	public static function limpar( bool $agendar = true, string $origem = 'atualizar_cache' ): array {
		F3Base_Cache_Evidencia::migrar();
		$foto = F3Base_Options::fotografia( self::ESTADO );
		if ( ! empty( $foto['erro'] ) ) { return array( 'ok' => false, 'codigo' => 'estado_indisponivel' ); }
		$e = $foto['valor']; $p = self::perfil();
		if ( $p['ativo'] && ! $p['limpeza_disponivel'] ) { return self::falha_limpeza( 'provedor_sem_operacao', $origem, $agendar ); }
		try {
			if ( $p['limpeza_disponivel'] ) {
				// Limpa também o cache desligado que será reutilizado se o operador o reativar.
				$r = wp_cache_clear_cache();
				if ( false === $r ) { return self::falha_limpeza( 'provedor_recusou', $origem, $agendar ); }
			}
		} catch ( Throwable $erro ) { return self::falha_limpeza( 'limpeza_falhou', $origem, $agendar ); }
		if ( empty( $e['pendente'] ) ) { $e['geracao'] = wp_generate_uuid4(); }
		$e['pendente'] = false; $e['limpo_em'] = time(); $e['versao'] = F3BASE_PLUGIN_VERSAO; $e['codigo'] = 'limpeza_solicitada_ao_provedor';
		$r = F3Base_Options::gravar( self::ESTADO, $e, F3Base_Options::ORIGEM_PADRAO, $foto['revisao'] );
		// Uma verificação explícita posterior não deve ser apagada novamente no shutdown.
		if ( ! empty( $r['persisted'] ) ) { self::$marcado = false; }
		$ok = ! empty( $r['persisted'] );
		F3Base_Cache_Evidencia::alterar( static function( $v ) use ( $ok, $origem, $e ) { $v['limpeza'] = array( 'em' => time(), 'origem' => $origem, 'geracao' => $e['geracao'], 'codigo' => $ok ? 'limpeza_solicitada_ao_provedor' : 'alteracao_concorrente', 'status' => $ok ? 'applied' : 'pending' ); return $v; } );
		$agenda = $ok && $agendar ? F3Base_Cache_Evidencia::agendar( time() + F3Base_Cache_Evidencia::JANELA, 'apos_limpeza' ) : null;
		return array( 'ok' => $ok, 'persisted' => $ok, 'applied' => true, 'codigo' => $ok ? $e['codigo'] : 'alteracao_concorrente', 'verificacao_pendente' => true, 'agendamento_confirmado' => $agenda );
	}
	private static function falha_limpeza( string $codigo, string $origem, bool $agendar ): array {
		self::$marcado = false;
		$gravou = F3Base_Cache_Evidencia::alterar( static function( $v ) use ( $codigo, $origem ) { $v['limpeza'] = array( 'em' => time(), 'origem' => $origem, 'geracao' => self::estado()['geracao'], 'codigo' => $codigo, 'status' => 'failed' ); return $v; } );
		if ( $agendar ) { F3Base_Cache_Evidencia::agendar( time() + F3Base_Cache_Evidencia::JANELA, 'limpeza_recusada' ); }
		return array( 'ok' => false, 'persisted' => $gravou, 'applied' => false, 'codigo' => $codigo, 'verificacao_pendente' => true );
	}
	public static function concluir(): void {
		if ( self::$marcado && ! empty( self::estado()['pendente'] ) ) { self::limpar( true, 'fim_da_operacao' ); }
	}
	public static function preparar(): void {
		if ( self::$encerrando ) { return; }
		F3Base_Cache_Evidencia::migrar();
		$e = self::estado();
		if ( ( $e['versao'] ?? '' ) !== F3BASE_PLUGIN_VERSAO ) { self::solicitar(); }
		if ( ! wp_next_scheduled( self::CRON ) ) { F3Base_Cache_Evidencia::agendar( time() + F3Base_Cache_Evidencia::JANELA, 'preparacao' ); }
	}
	public static function tarefa(): void {
		self::verificar_publico( 'cron' );
	}
	public static function ativar(): void { self::$encerrando = false; self::preparar(); }
	public static function desativar(): void {
		self::$encerrando = true; self::$marcado = false;
		wp_clear_scheduled_hook( self::CRON );
		self::limpar( false, 'desativacao' );
	}

	/** Requisitos derivados da URL real; o implantador mescla estes caminhos na API do cache. */
	public static function exclusoes(): array {
		$r = wp_parse_url( rest_url( F3BASE_REST_NAMESPACE . '/' ) );
		$codificada = rawurlencode( '/' . F3BASE_REST_NAMESPACE );
		$lista = array( 'rest_route=/' . F3BASE_REST_NAMESPACE, 'rest_route=' . $codificada, 'rest_route=' . str_replace( '%2F', '%2f', $codificada ), 'f3base_markdown=', '/llms.txt', '/llms-full.txt', '\\.md(?:$|[?])' );
		// Com permalinks simples, o caminho REST é a própria home: excluí-lo desliga todo o cache.
		if ( ! str_contains( (string) ( $r['query'] ?? '' ), 'rest_route=' ) ) { array_unshift( $lista, (string) ( $r['path'] ?? '' ) ); }
		return array_values( array_unique( array_filter( $lista ) ) );
	}
	/** Lista explícita da referência WPSC, sem o parâmetro funcional genérico ref. */
	public static function parametros_rastreio(): array {
		return array( 'fbclid', 'gclid', 'fb_source', 'mc_cid', 'mc_eid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_expid', 'mtm_source', 'mtm_medium', 'mtm_campaign', 'mtm_keyword', 'mtm_content', 'mtm_cid', 'mtm_group', 'mtm_placement', 'ysclid', 'srsltid', 'yclid' );
	}
	/** Leitura da configuração carregada do dono. Não grava nem executa suas expressões regulares. */
	public static function requisitos(): array {
		global $cache_rejected_uri, $wpsc_tracking_parameters, $wpsc_ignore_tracking_parameters;
		$p = self::perfil();
		$exclusoes = is_array( $cache_rejected_uri ) ? array_values( array_filter( $cache_rejected_uri, 'is_string' ) ) : array();
		$parametros = is_array( $wpsc_tracking_parameters ) ? array_values( array_filter( $wpsc_tracking_parameters, 'is_string' ) ) : array();
		$faltam_exclusoes = array_values( array_diff( self::exclusoes(), $exclusoes ) );
		$faltam_parametros = array_values( array_diff( self::parametros_rastreio(), $parametros ) );
		$proibidos = array_values( array_intersect( $parametros, array( 'ref' ) ) );
		$ligado = in_array( $wpsc_ignore_tracking_parameters, array( 1, '1', true ), true );
		$aplicavel = $p['ativo'] && 'wp-super-cache' === $p['provedor'];
		$divergencias = $faltam_exclusoes || $faltam_parametros || $proibidos || ! $ligado;
		return array(
			'status' => ! $aplicavel ? 'not_required' : ( $divergencias ? 'failed' : 'verified' ),
			'scope' => 'provider_configuration', 'fonte' => 'configuracao_carregada_do_wp_super_cache',
			'configuracao_requerida' => array( 'wpsc_ignore_tracking_parameters' => 1, 'wpsc_tracking_parameters' => self::parametros_rastreio(), 'cache_rejected_uri' => self::exclusoes() ),
			'exclusoes' => array( 'observadas' => $exclusoes, 'faltantes' => $faltam_exclusoes, 'criterio' => 'presenca_literal' ),
			'rastreamento' => array( 'ativado' => $ligado, 'observados' => $parametros, 'faltantes' => $faltam_parametros, 'proibidos_presentes' => $proibidos, 'adicionais' => array_values( array_diff( $parametros, self::parametros_rastreio(), array( 'ref' ) ) ) ),
			'aplicacao' => 'O administrador ou implantador configura pela API do WP Super Cache, preserva regras próprias, confirma a leitura e solicita atualizar_cache. A lista de rastreamento exige avaliação dos parâmetros adicionais; ref deve permanecer funcional.',
			'limite_da_verificacao' => 'Presença literal das entradas exigidas. Não avalia equivalência de regex nem comprova HIT. O WordPress e o provedor podem ter outras proteções REST.'
		);
	}
	public static function proteger_rota( $resultado, $servidor, $pedido ) {
		if ( is_object( $pedido ) && method_exists( $pedido, 'get_route' ) && str_starts_with( $pedido->get_route(), '/' . F3BASE_REST_NAMESPACE . '/' ) ) {
			if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
		}
		return $resultado;
	}
	public static function proteger_resposta( $resultado, $servidor, $pedido ) {
		if ( is_object( $pedido ) && method_exists( $pedido, 'get_route' ) && str_starts_with( $pedido->get_route(), '/' . F3BASE_REST_NAMESPACE . '/' ) && $resultado instanceof WP_HTTP_Response ) {
			$resultado->header( 'Cache-Control', 'no-store, private' );
			$resultado->header( 'Pragma', 'no-cache' );
			$resultado->header( 'Expires', self::EXPIRES_PASSADO );
		}
		return $resultado;
	}
	public static function contexto(): string {
		return hash( 'sha256', wp_json_encode( array( self::perfil(), self::requisitos(), F3BASE_PLUGIN_VERSAO, home_url( '/' ), rest_url( F3BASE_REST_NAMESPACE . '/token' ), F3Base_Options::fotografia( 'f3base_comportamento' )['valor']['ligado'] ?? false, F3Base_Options::fotografia( 'f3base_cabecalhos' )['valor'], self::estado()['geracao'] ?? '' ) ) );
	}
	public static function prova(): array {
		$p = F3Base_Cache_Evidencia::ler()['ultima_tentativa'] ?? array();
		return empty( self::estado()['pendente'] ) && $p && hash_equals( self::contexto(), (string) ( $p['contexto'] ?? '' ) ) && (int) ( $p['checked_at'] ?? 0 ) + self::VALIDADE > time() ? $p : array();
	}
	public static function verificacao(): array {
		$p = self::prova();
		if ( empty( $p ) ) {
			$v = F3Base_Cache_Evidencia::ler(); $e = self::estado(); $t = $v['ultima_tentativa'] ?? array(); $agenda = F3Base_Cache_Evidencia::agenda();
			$codigo = 'nunca_verificado'; $motivo = 'Ainda não há tentativa pública registrada. O histórico apagado pela versão anterior não pode ser reconstruído.';
			if ( $t ) { $codigo = 'evidencia_expirada'; $motivo = 'A validade da evidência terminou. A última tentativa permanece no histórico.'; }
			if ( $t && ! hash_equals( self::contexto(), (string) ( $t['contexto'] ?? '' ) ) ) { $codigo = 'configuracao_alterada'; $motivo = 'A configuração ou versão mudou. A evidência histórica não valida a geração atual.'; }
			if ( ! empty( $e['limpo_em'] ) && ( $t['geracao'] ?? '' ) !== ( $e['geracao'] ?? '' ) ) { $codigo = 'aguardando_verificacao_apos_limpeza'; $motivo = 'Limpeza solicitada ao provedor; aguardando comprovação pública da geração atual.'; }
			if ( ! empty( $e['pendente'] ) ) { $codigo = 'limpeza_pendente'; $motivo = 'Há limpeza pendente. Configuração gravada não equivale a entrega pública verificada.'; }
			if ( ! empty( $e['pendente'] ) && 'failed' === ( $v['limpeza']['status'] ?? '' ) && ( $v['limpeza']['geracao'] ?? '' ) === ( $e['geracao'] ?? '' ) ) { $codigo = $v['limpeza']['codigo']; $motivo = 'A limpeza falhou: ' . $codigo . '. A configuração e a evidência histórica foram preservadas.'; }
			if ( F3Base_Cache_Evidencia::possui( 'sonda', (string) ( F3Base_Cache_Evidencia::trava( 'sonda' )['id'] ?? '' ) ) ) { $codigo = 'verificacao_em_execucao'; $motivo = 'Uma verificação já está em execução; aguarde sua conclusão.'; }
			elseif ( in_array( $agenda['codigo'], array( 'agendamento_ausente', 'cron_atrasado', 'agendamento_falhou' ), true ) ) { $codigo = $agenda['codigo']; $motivo = 'Sem confirmação pública atual; situação do executor: ' . $codigo . '. Confira o agendador, a última execução e o cron do servidor.'; }
			return F3Base_Options::resultado_verificacao( 'pending', 'public_http', $codigo, $motivo );
		}
		return F3Base_Options::resultado_verificacao( $p['status'], 'public_http', $p['codigo'], $p['motivo'], $p['checked_at'] );
	}
	/** Conserva a multiplicidade de campos HTTP, que a leitura comum do WordPress pode juntar. */
	public static function campos_cache_control( array $resposta ): array {
		$headers = $resposta['headers'] ?? array();
		if ( isset( $resposta['http_response'] ) && is_object( $resposta['http_response'] ) && method_exists( $resposta['http_response'], 'get_response_object' ) ) {
			$original = $resposta['http_response']->get_response_object();
			if ( is_object( $original ) && isset( $original->headers ) ) { $headers = $original->headers; }
		}
		if ( is_object( $headers ) && method_exists( $headers, 'getValues' ) ) { return array_values( (array) $headers->getValues( 'cache-control' ) ); }
		$valor = wp_remote_retrieve_header( $resposta, 'cache-control' );
		return '' === $valor || null === $valor ? array() : array_values( (array) $valor );
	}
	/** Dois GET por rota ativa, sem bypass, cookie ou token no relatório. Executada só na cadência existente. */
	public static function sondar_tokens(): array {
		$rotas = array( 'endpoint-leads' => F3Base_Modulo_Endpoint_Leads::ROTA_TOKEN );
		if ( ! empty( F3Base_Options::ler( 'f3base_comportamento' )['ligado'] ) ) { $rotas['comportamento'] = '/comportamento/token'; }
		$saida = array();
		foreach ( $rotas as $modulo => $rota ) {
			$url = rest_url( F3BASE_REST_NAMESPACE . $rota );
			$item = array( 'status' => 'verified', 'codigo' => 'token_publico_comprovado', 'url' => $url, 'checked_at' => time(), 'problemas' => array(), 'respostas' => array() );
			$hashes = array();
			for ( $i = 0; $i < 2; ++$i ) {
				$r = wp_remote_get( $url, array( 'timeout' => 5, 'redirection' => 0, 'limit_response_size' => 16384, 'cookies' => array(), 'headers' => array( 'Accept' => 'application/json' ) ) );
				if ( is_wp_error( $r ) ) { $item['problemas'][] = 'http_indisponivel'; continue; }
				$status = (int) wp_remote_retrieve_response_code( $r );
				$campos = self::campos_cache_control( $r );
				$cache = implode( ', ', $campos );
				$expires = wp_remote_retrieve_header( $r, 'expires' );
				$expires = is_array( $expires ) ? implode( ', ', $expires ) : (string) $expires;
				$item['respostas'][] = array( 'http_status' => $status, 'cache_control' => $campos, 'expires' => $expires );
				if ( 200 !== $status ) { $item['problemas'][] = 429 === $status ? 'sonda_limitada' : 'http_inesperado'; }
				if ( ! preg_match( '/(?:^|,)\s*no-store\s*(?:,|$)/i', $cache ) ) { $item['problemas'][] = 'no_store_ausente'; }
				if ( count( $campos ) > 1 ) { $item['problemas'][] = 'cache_control_duplicado'; }
				if ( preg_match( '/(?:^|,)\s*(?:public(?:,|$)|s-maxage\s*=|max-age\s*=\s*[1-9])/i', $cache ) ) { $item['problemas'][] = 'cache_control_conflitante'; }
				$data = strtotime( $expires );
				if ( false === $data || $data >= time() ) { $item['problemas'][] = 'expires_nao_expirado'; }
				if ( 200 !== $status ) { continue; }
				$corpo = wp_remote_retrieve_body( $r );
				$hashes[] = hash( 'sha256', $corpo );
				$json = json_decode( $corpo, true );
				if ( ! is_array( $json ) || empty( $json['ok'] ) || ! is_string( $json['token'] ?? null ) || ! F3Base_Modulo_Endpoint_Leads::validar_token( $json['token'] ) ) { $item['problemas'][] = 'token_invalido_na_resposta'; }
			}
			if ( 2 === count( $hashes ) && hash_equals( $hashes[0], $hashes[1] ) ) { $item['problemas'][] = 'corpo_repetido'; }
			$item['problemas'] = array_values( array_unique( $item['problemas'] ) );
			$falhas = array_diff( $item['problemas'], array( 'http_indisponivel', 'sonda_limitada' ) );
			if ( $item['problemas'] ) { $item['status'] = $falhas ? 'failed' : 'pending'; $item['codigo'] = $falhas ? 'token_publico_divergente' : 'token_publico_pendente'; }
			$item['corpos_sha256'] = $hashes;
			$saida[ $modulo ] = $item;
		}
		return $saida;
	}
	public static function verificacao_tokens(): array { return self::prova()['tokens'] ?? array(); }

	/** Prova de HIT por cabeçalho do servidor ou arquivo WPSC correspondente e geração estável. */
	public static function hit_comprovado( array $r, string $corpo ): bool {
		foreach ( array( 'wp-super-cache', 'x-wp-super-cache', 'x-cache', 'cf-cache-status' ) as $h ) {
			$v = (string) wp_remote_retrieve_header( $r, $h );
			if ( preg_match( '/\bHIT\b|served (?:supercache|wpcache)/i', $v ) ) { return true; }
		}
		// Expert não precisa acrescentar um cabeçalho: confirmar o arquivo da home no provedor.
		if ( self::perfil()['provedor'] !== 'wp-super-cache' || ! function_exists( 'get_supercache_dir' ) || ! str_contains( $corpo, 'Cached page generated by WP-Super-Cache' ) ) { return false; }
		$base = get_supercache_dir();
		foreach ( array( 'index.html', 'index-https.html' ) as $nome ) {
			$f = $base . $nome;
			if ( is_file( $f ) && is_readable( $f ) && filesize( $f ) <= 524288 && hash_equals( hash( 'sha256', $corpo ), (string) hash_file( 'sha256', $f ) ) ) { return true; }
		}
		// WP-Cache pode preservar cabeçalhos sem habilitar o cabeçalho opcional de HIT.
		// Ler somente os arquivos limitados da home; nunca executar PHP do cache.
		if ( is_dir( $base ) && is_readable( $base ) && function_exists( 'wp_cache_get_legacy_cache' ) ) {
			$vistos = 0;
			foreach ( new DirectoryIterator( $base ) as $arquivo ) {
				if ( ++$vistos > 128 ) { break; }
				if ( ! $arquivo->isFile() || ! preg_match( '/^wp-cache-[a-f0-9]+\.php$/', $arquivo->getFilename() ) || $arquivo->getSize() > 524303 ) { continue; }
				$conteudo = wp_cache_get_legacy_cache( $arquivo->getPathname() );
				if ( ! is_string( $conteudo ) ) { continue; }
				if ( hash_equals( hash( 'sha256', $corpo ), hash( 'sha256', $conteudo ) ) ) { return true; }
			}
		}
		return false;
	}

	/** Só cron e ações explícitas entram aqui. Lease + CAS também protegem a publicação. */
	public static function verificar_publico( string $origem = 'verificar_publico' ): array {
		if ( ! F3Base_Cache_Evidencia::migrar() ) { return self::pendencia_sonda( 'evidencia_gravacao_falhou', 'Não foi possível preparar o registro durável; nenhuma sonda executada.' ); }
		$id = F3Base_Cache_Evidencia::adquirir( 'sonda' );
		if ( '' === $id ) { $ocupada = (int) ( F3Base_Cache_Evidencia::trava( 'sonda' )['ate'] ?? 0 ) > time(); return self::pendencia_sonda( $ocupada ? 'verificacao_em_execucao' : 'bloqueio_gravacao_falhou', $ocupada ? 'Uma verificação já está em execução; nenhuma sonda duplicada.' : 'Não foi possível persistir o bloqueio; nenhuma sonda executada.' ); }
		try {
			$v = F3Base_Cache_Evidencia::ler(); $anterior = self::prova();
			$nao_antes = max( (int) ( $v['ultima_tentativa']['checked_at'] ?? 0 ) + F3Base_Cache_Evidencia::INTERVALO, (int) ( $v['execucao']['iniciado_em'] ?? 0 ) + F3Base_Cache_Evidencia::INTERVALO );
			if ( ( $v['ultima_tentativa']['contexto'] ?? '' ) === self::contexto() && ! F3Base_Cache_Evidencia::sucesso( $v['ultima_tentativa'] ?? array() ) ) { $nao_antes = max( $nao_antes, (int) ( $v['execucao']['proxima_tentativa'] ?? 0 ) ); }
			if ( time() < $nao_antes ) {
				if ( 'cron' === $origem ) { F3Base_Cache_Evidencia::agendar( $nao_antes, 'intervalo_minimo', false ); }
				return $anterior ?: self::pendencia_sonda( 'intervalo_minimo', 'Aguardando o intervalo entre tentativas; a nova geração permanece pendente.' );
			}
			$inicio = time(); $contexto = self::contexto();
			$iniciou = F3Base_Cache_Evidencia::alterar( static function( $v ) use ( $id, $origem, $inicio, $contexto ) { $falhas = ( $v['ultima_tentativa']['contexto'] ?? '' ) === $contexto ? (int) ( $v['execucao']['falhas'] ?? 0 ) : 0; $v['execucao'] = array( 'id' => $id, 'origem' => $origem, 'iniciado_em' => $inicio, 'concluido_em' => 0, 'contexto' => $contexto, 'geracao' => self::estado()['geracao'], 'status' => 'running', 'codigo' => 'verificacao_em_execucao', 'falhas' => $falhas ); return $v; } );
			if ( ! $iniciou ) { return self::pendencia_sonda( 'evidencia_gravacao_falhou', 'Início não persistido; nenhuma sonda executada.' ); }
			$purga = null;
			if ( 'cron' === $origem ) {
				if ( ( self::estado()['versao'] ?? '' ) !== F3BASE_PLUGIN_VERSAO ) { self::solicitar(); }
				if ( ! empty( self::estado()['pendente'] ) ) { $purga = self::limpar( false, 'cron' ); }
			}
			$contexto = self::contexto(); $geracao = (string) ( self::estado()['geracao'] ?? '' );
			try {
				$p = is_array( $purga ) && empty( $purga['ok'] ) ? self::pendencia_sonda( $purga['codigo'], 'Limpeza recusada. Nenhuma leitura pública executada.' ) : self::sondar_publico();
			} catch ( Throwable $erro ) { $p = self::pendencia_sonda( 'sonda_falhou', 'A verificação foi interrompida; uma nova tentativa respeitará o intervalo.' ); }
			$p = array_replace( $p, array( 'id' => $id, 'origem' => $origem, 'geracao' => $geracao, 'contexto' => $contexto, 'plugin_version' => F3BASE_PLUGIN_VERSAO, 'checked_at' => $inicio, 'iniciado_em' => $inicio, 'concluido_em' => time(), 'persisted' => true ) );
			$gravou = F3Base_Cache_Evidencia::alterar( static function( $v ) use ( &$p, $id, $contexto ) {
				if ( ! F3Base_Cache_Evidencia::possui( 'sonda', $id ) || ( $v['execucao']['id'] ?? '' ) !== $id ) { return null; }
				if ( ! hash_equals( $contexto, self::contexto() ) || ( ! empty( self::estado()['pendente'] ) && ! in_array( $p['codigo'], array( 'provedor_recusou', 'provedor_sem_operacao', 'limpeza_falhou' ), true ) ) ) { $p['status'] = 'pending'; $p['codigo'] = 'configuracao_alterada'; $p['motivo'] = 'A configuração mudou ou a limpeza continua pendente. Esta evidência não valida a geração atual.'; }
				$v['ultima_tentativa'] = $p;
				$sucesso = F3Base_Cache_Evidencia::sucesso( $p );
				if ( $sucesso ) { $v['ultimo_sucesso'] = $p; }
				$falhas = $sucesso ? 0 : min( 10, 1 + (int) ( $v['execucao']['falhas'] ?? 0 ) );
				$intervalo = $sucesso ? self::VALIDADE : min( F3Base_Cache_Evidencia::MAX_RECUO, F3Base_Cache_Evidencia::INTERVALO * ( 2 ** max( 0, $falhas - 1 ) ) );
				$v['execucao'] = array_replace( $v['execucao'], array( 'contexto' => $contexto, 'geracao' => $p['geracao'], 'status' => $p['status'], 'codigo' => $p['codigo'], 'concluido_em' => $p['concluido_em'], 'falhas' => $falhas, 'proxima_tentativa' => time() + $intervalo ) );
				return $v;
			} );
			if ( ! $gravou ) { $p['persisted'] = false; $p['status'] = 'pending'; $p['codigo'] = 'evidencia_gravacao_falhou'; $p['motivo'] = 'A sonda terminou, mas seu resultado não foi confirmado no armazenamento; consulte novamente antes de repetir.'; }
			else {
				$e = F3Base_Cache_Evidencia::ler();
				$proxima = (int) $e['execucao']['proxima_tentativa'];
				if ( ! hash_equals( $contexto, self::contexto() ) ) { $proxima = min( $proxima, time() + F3Base_Cache_Evidencia::JANELA ); }
				F3Base_Cache_Evidencia::agendar( $proxima, $origem, false );
			}
			return F3Base_Cache_Evidencia::prova( $p );
		} finally { F3Base_Cache_Evidencia::liberar( 'sonda', $id ); }
	}
	private static function pendencia_sonda( string $codigo, string $motivo ): array { return array_merge( F3Base_Options::resultado_verificacao( 'pending', 'public_http', $codigo, $motivo ), array( 'persisted' => false ) ); }
	/** Duas leituras anônimas de tamanho e tempo limitados; tokens usam a cota normal. */
	private static function sondar_publico(): array {
		$contexto = self::contexto(); $perfil = self::perfil();
		$prova = array( 'contexto' => $contexto, 'checked_at' => time(), 'status' => 'pending', 'codigo' => 'http_indisponivel', 'motivo' => 'Verificação pública indisponível.', 'url' => home_url( '/' ), 'modo' => $perfil['modo'], 'hit' => false, 'cabecalhos' => array(), 'faltantes' => array() );
		$args = array( 'timeout' => 5, 'redirection' => 0, 'limit_response_size' => 524288, 'cookies' => array(), 'headers' => array( 'Accept' => 'text/html' ) );
		$r = wp_remote_get( $prova['url'], $args );
		if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
			$r2 = wp_remote_get( $prova['url'], $args );
			if ( ! is_wp_error( $r2 ) && 200 === wp_remote_retrieve_response_code( $r2 ) ) {
				$corpo = wp_remote_retrieve_body( $r2 );
				$a = array(); $b = array();
				preg_match( '/F3BASE-CACHE-PROBE:([a-f0-9-]{36})/', wp_remote_retrieve_body( $r ), $a );
				preg_match( '/F3BASE-CACHE-PROBE:([a-f0-9-]{36})/', $corpo, $b );
				$prova['hit'] = ! empty( $a[1] ) && ! empty( $b[1] ) && hash_equals( $a[1], $b[1] ) && self::hit_comprovado( $r2, $corpo );
				$modulo = new F3Base_Modulo_Cabecalhos();
				$esperados = $modulo->lista_de_cabecalhos();
				$c = F3Base_Options::ler( 'f3base_cabecalhos' );
				if ( ! empty( $c['hsts'] ) && 'https' === wp_parse_url( $prova['url'], PHP_URL_SCHEME ) ) { $esperados['Strict-Transport-Security'] = 'max-age=' . (int) $c['hsts_max_age']; }
				foreach ( $esperados as $nome => $esperado ) {
					$valor = wp_remote_retrieve_header( $r2, $nome );
					$valor = is_array( $valor ) ? implode( ', ', $valor ) : (string) $valor;
					$prova['cabecalhos'][ $nome ] = substr( $valor, 0, 2048 );
					$confere = strcasecmp( trim( $valor ), trim( $esperado ) ) === 0;
					if ( in_array( $nome, array( 'Content-Security-Policy', 'Strict-Transport-Security' ), true ) ) { $confere = preg_match( '/(?:^|[,;]\s*)' . preg_quote( $esperado, '/' ) . '(?:\s*;|\s*,|$)/i', $valor ) === 1; }
					if ( ! $confere ) { $prova['faltantes'][] = $nome; }
				}
				$prova['status'] = $prova['faltantes'] ? 'failed' : ( ! $perfil['ativo'] || $prova['hit'] ? 'verified' : 'pending' );
				$prova['codigo'] = $prova['faltantes'] ? 'cabecalhos_divergentes' : ( 'verified' === $prova['status'] ? 'cabecalhos_comprovados' : 'hit_nao_comprovado' );
				$prova['motivo'] = $prova['faltantes'] ? 'Proteções ausentes ou divergentes na resposta pública: ' . implode( ', ', $prova['faltantes'] ) . '.' : ( 'verified' === $prova['status'] ? 'Cabeçalhos conferidos na resposta pública' . ( $prova['hit'] ? ' entregue pelo cache.' : ' sem cache de página detectado.' ) : 'Cabeçalhos presentes, mas não houve comprovação de HIT. Confira o provedor ou a infraestrutura.' );
				$geracao = array(); preg_match( '/F3BASE-CONFIG:([a-f0-9]{64})/', $corpo, $geracao );
				if ( $perfil['ativo'] && ( empty( $geracao[1] ) || ! hash_equals( $contexto, $geracao[1] ) ) ) {
					$prova['status'] = 'failed'; $prova['codigo'] = 'cache_obsoleto'; $prova['motivo'] = 'A resposta pública não corresponde à geração atual do Core. Atualize o cache de página e eventual proxy.';
				}

			}
		}
		$prova['tokens'] = self::sondar_tokens();
		if ( ! hash_equals( $contexto, self::contexto() ) ) { $prova['status'] = 'pending'; $prova['codigo'] = 'contexto_alterado'; $prova['motivo'] = 'A configuração mudou durante a medição; execute outra verificação.'; }
		return $prova;
	}
	public static function resumo(): array {
		$v = F3Base_Cache_Evidencia::ler(); $p = self::prova();
		return array( 'perfil' => self::perfil(), 'requisitos' => self::requisitos(), 'estado' => self::estado(), 'verification' => self::verificacao(), 'tokens' => $p['tokens'] ?? array(), 'evidencia' => $p, 'historico' => array( 'ultima_tentativa' => $v['ultima_tentativa'] ?? array(), 'ultimo_sucesso' => $v['ultimo_sucesso'] ?? array(), 'ultima_verificacao' => (int) ( $v['ultima_tentativa']['checked_at'] ?? 0 ), 'ultima_verificacao_bem_sucedida' => (int) ( $v['ultimo_sucesso']['checked_at'] ?? 0 ), 'valida_geracao_atual' => ! empty( $p ) && F3Base_Cache_Evidencia::sucesso( $p ), 'migracao' => $v['migracao'] ?? array(), 'limpeza' => $v['limpeza'] ?? array() ), 'agendamento' => F3Base_Cache_Evidencia::agenda(), 'exclusoes_requeridas' => self::exclusoes(), 'proxima_verificacao' => (int) wp_next_scheduled( self::CRON ), 'limite_token' => F3Base_Modulo_Endpoint_Leads::limite_token() );
	}
}
