# Plano — Fator3 Site Core 1.63.0

30/10/2026 · revisão 1 · implementação a partir da 1.62.0, contrato 8.27.0. Alvo previsto: 1.63.0, contrato administrativo aditivo 8.28.0. Instalador ainda não gerado.

Base exata: instalador 2948015 bytes, SHA-256 3dcbae9b1e22b915ac32ae3074cec1ed15706d4a475a9cf5d5b9e12663922646. Fonte 5859483 bytes, SHA-256 dd6f4dd466a57ec2cdcbf72492a98678a966dc38e96123c5f8fa1255b61cbe0a. Entradas e hashes dos novos anexos: inputs/1630/packages.json. Instruções e padrão comuns revisão 4 lidos.

## Escopo

1. Pedido 352: scripts essenciais no início da página; PageView Meta antecipado sob consentimento local, exclusão de editor no servidor e teste no navegador; conversões continuam classificadas. Coletores próprios observam em memória desde o início, enviando somente após consentimento/classificação. GA4 conserva suas guardas. Reduzir custo de contexto-publico.
2. Pedido 353: política configurável e simulável de persistência IMAP, padrão 3 falhas ou 20 minutos, histórico limitado com data/código e avisos únicos de abertura/recuperação.
3. Pedido 354: medir a base, reduzir carga desnecessária, preservar os SDKs e hooks públicos. Diagnóstico administrativo de tempo por módulo/contexto, sem instrumentação externa e sem dados privados de visitas.
4. Pedido 355: retomada idempotente do robots na ativação e troca, verificação HTTP, aviso técnico de falha e marcos de suspensão/retomada na saúde.
5. Pedido 356: opção simulável de correspondência manual; hashes SHA-256 normalizados na resposta do contato aceito, sem PII em HTML/storage; init com hashes antes de Lead, eventID preservado e mesmas exclusões do 352.

## Fronteiras e impactos

Meta 0.17.0 mantém os SDKs consumidos; Pipedrive 0.5.0 mantém pipedrive-api-client/1.0.0. Avaliar a descoberta dos consumidores após carregamento sob demanda, usando os pacotes recebidos. Pixel/CAPI são responsabilidade do Core. Nenhuma alteração de contrato dos acompanhantes está prevista; nenhum impacto individual identificado neste planejamento. Caso surja consequência técnica concreta na implementação, emitir o impacto antes da alteração dependente. A validação conjunta anterior do Implantador permanece fora desta rodada.

## Provas previstas

Testes de navegador/DOM com rede interceptada para ordem, consentimento, exclusões, buffering e hashes; WordPress nativo para IMAP/avisos/robots/perfil/permissões; instalação limpa e atualização 1.62.0 direta; regressões das fronteiras afetadas; leitura documental completa por MCP; Site-Teste com estado antes/depois, pacote exato e limpeza de recursos próprios. Medir login e página com três amostras e comparar o menor tempo com/sem Core sem efeitos comerciais. Convivência MCP 0.37.0, Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0, Pipedrive 0.5.0.

## Limites de aceite

As métricas de sete dias na frota e o recebimento de hashes pela Meta exigem observação nos ativos reais pela frota. A prova sintética não encerra esse aceite. O “Lead de teste” do item 356 será interpretado como contato sintético de homologação comercial expressamente autorizado pela frota; a marca técnica f3base_teste continua impedindo envio Meta, conforme 352. Nenhum efeito comercial real será produzido no Site-Teste.

## Revisão 2 — achado da homologação

O pedido 354 não atingiu o limite de 100 ms no Site-Teste. Foi comprovada a inicialização do catálogo de habilidades pelo MCP 0.37.0 em wp_loaded, inclusive no login; há também custo próprio residual de página. Encaminhamento técnico aberto: `base-site-core-fator3-1.63.0-impacto-wp-mcp-fator3.md`, validação coordenada. O MCP não foi alterado e nenhuma implementação depende de presumir sua correção. O relatório final conserva o não aceite do 354.
