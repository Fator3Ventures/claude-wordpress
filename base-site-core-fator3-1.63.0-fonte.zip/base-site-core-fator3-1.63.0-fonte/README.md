# Fonte — Fator3 Site Core 1.63.0

Base 1.62.0; contrato administrativo 8.28.0. Código instalável em work/plugin/base-site-core-fator3. Planejamento em PLANO-1.63.0.md; entrega e limites no relatório. Somente o ZIP instalador deve ser enviado ao WordPress.

Build: build/autoload.py atualiza o mapa; build/bootstrap-methods.php compila registros em WordPress descartável; build/assets.py usa Terser 5.44.1. tests/base-1330/gerar-contratos.php gera contratos/ajuda, sem valores do site. build/package-installer.py confere sintaxe PHP e fecha o instalador; build/package-source.py confere igualdade exata e fecha o fonte. Não reaplicar scripts patch1630-* sobre esta árvore final.

Provas atuais: tests/request-353-355-356.php, request-352-356-dom.cjs, docs-1630.php e ciclos nativos. Evidências desta rodada em evidence/1630 e arquivos explicitamente terminados em 1630; histórico não é evidência reexecutada. Bancos, fornecedores, mensagens e credenciais dos laboratórios não são distribuídos. Consulte build/README.md para variáveis do laboratório; forneça a base canônica pela variável F3BASE_BASE_ZIP e use base 1.62.0/alvo 1.63.0/contrato 8.28.0.
