# Fator3 Site Core 1.44.0

Instalação nova ou atualização direta da base 1.43.0. Contrato administrativo 8.9.0. Leia docs/DOCUMENTACAO.md e docs/RELEASE-1.44.0.md. As evidências e limites de homologação acompanham o relatório externo.
