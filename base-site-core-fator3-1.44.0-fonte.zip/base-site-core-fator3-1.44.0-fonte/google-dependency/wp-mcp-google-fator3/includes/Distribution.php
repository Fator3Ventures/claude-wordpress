<?php
/** Consumer of the MCP package-distribution SDK and its documented local receipt. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if (!defined( 'ABSPATH' )) {
    exit;
}
final class Distribution {
    public const CONTRACT='package-distribution/1.0.0';
    public const PACKAGE='wp-mcp-google-fator3';
    public const RECEIPT='f3_mcp_distribution_selection';
    // Public SDK receipt, never the private channel options.
    public const CONSENT='f3_mcp_google_distribution_consent';
    private const SDK='\\Fator3\\McpFiles\\PackageDistribution';
    public static function available(): bool {
        try {
            foreach(['capabilities','register','selection','manifest','guard'] as $method)if(!is_callable([self::SDK,$method]))return false;
            $c=call_user_func([self::SDK,'capabilities']);
            return is_array($c)&&($c['contract']??null)===self::CONTRACT&&($c['schema_revision']??null)===1&&($c['available']??false)===true&&($c['selection_option']??null)===self::RECEIPT;
        }
        catch(\Throwable $e){
            return false;
        }
    }
    public static function register(string $contract): void {
        if($contract!==self::CONTRACT||!self::available())return;
        call_user_func([self::SDK,'register'],['contract'=>self::CONTRACT,'package'=>self::PACKAGE,'plugin'=>self::PACKAGE.'/'.self::PACKAGE.'.php','provider'=>self::PACKAGE]);
    }
    private static function valid($s): bool {
        return is_array($s)&&($s['contract']??null)===self::CONTRACT&&($s['package']??null)===self::PACKAGE&&($s['provider']??null)===self::PACKAGE&&($s['plugin']??null)===self::PACKAGE.'/'.self::PACKAGE.'.php'&&is_bool($s['available']??null)&&in_array($s['origin']??null,['mcp','provider'],true)&&is_string($s['revision']??null)&&preg_match('/^[a-f0-9]{64}$/D',$s['revision'])&&($s['fallback_allowed']??null)===false;
    }
    public static function selection(): array {
        if(self::available()) {
            try {
                $s=call_user_func([self::SDK,'selection'],self::PACKAGE);
            }
            catch(\Throwable $e){
                $s=null;
            }
            return self::valid($s)?$s:self::unknown('invalid_selection');
        }
        $r=Options::stored(self::RECEIPT);
        if(!$r['success'])return self::unknown('selection_unreadable');
        $s=$r['value']['packages'][self::PACKAGE]??null;
        if(self::valid($s)) {
            if($s['origin']==='mcp')return $s+['reason'=>'selected_provider_unavailable'];
            return $s;
        }
        if($r['exists'])return self::unknown('invalid_selection');
        $origin=Options::stored(Updater::OPTION);
        $consent=Options::stored(self::CONSENT);
        if(!$origin['success']||!$consent['success'])return self::unknown('selection_unreadable');
        $hash=self::origin_hash($origin['value']??[]);
        if($consent['exists']&&$consent['value']===$hash)return ['contract'=>self::CONTRACT,'package'=>self::PACKAGE,'provider'=>self::PACKAGE,'plugin'=>self::PACKAGE.'/'.self::PACKAGE.'.php','origin'=>'provider','available'=>true,'revision'=>$hash,'fallback_allowed'=>false];
        return self::unknown('selection_not_confirmed');
    }
    private static function unknown(string $reason): array {
        return ['contract'=>self::CONTRACT,'package'=>self::PACKAGE,'available'=>false,'origin'=>'unknown','revision'=>null,'fallback_allowed'=>false,'reason'=>$reason];
    }
    public static function origin_hash($origin): string {
        return hash('sha256',serialize($origin));
    }
    public static function guard(array $selection,?string $origin_hash=null) {
        if(self::selection()!==$selection||empty($selection['available']))return new \WP_Error('f3_google_distribution_changed','A seleção de distribuição mudou. Consulte uma nova oferta.');
        if($selection['origin']==='mcp') {
            if(!self::available())return new \WP_Error('f3_google_distribution_unavailable','A origem MCP selecionada está indisponível. A atualização manual por ZIP continua disponível.');
            try {
                $r=call_user_func([self::SDK,'guard'],$selection);
            }
            catch(\Throwable $e){
                $r=false;
            }
            if($r!==true)return new \WP_Error('f3_google_distribution_changed','O MCP não confirmou a seleção de distribuição.');
        }
        if($origin_hash!==null&&self::origin_hash(Options::get(Updater::OPTION,[]))!==$origin_hash)return new \WP_Error('f3_google_distribution_changed','A origem do provedor mudou. Consulte uma nova oferta.');
        return true;
    }
    public static function manifest(array $selection) {
        $guard=self::guard($selection);
        if(is_wp_error($guard))return $guard;
        try {
            $r=call_user_func([self::SDK,'manifest'],self::PACKAGE);
        }
        catch(\Throwable $e){
            return new \WP_Error('f3_google_distribution_manifest','O SDK de distribuição não retornou um manifesto.');
        }
        $guard=self::guard($selection);
        return is_wp_error($guard)?$guard:$r;
    }
}
