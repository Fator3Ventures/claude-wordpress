<?php
/** Public response limits; never applied to internal collection or export data. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Delivery {
    public const VERSION = '1.0.0';
    public const BUDGET = 1048576;
    // Space for the ability outcome, bridge metadata and transport decoration.
    public const JOB_BUDGET = self::BUDGET - 32768;
    public static function schema(): array {
        return array('type'=>'object','properties'=>array(
            'contract_version'=>array('type'=>'string','enum'=>array(self::VERSION)),
            'budget_bytes'=>array('type'=>'integer','maximum'=>self::BUDGET),
            'bytes'=>array('type'=>'integer','description'=>'Bytes JSON do objeto job, incluindo delivery.'),
            'section'=>array('type'=>'string'), 'offset'=>array('type'=>'integer','minimum'=>0),
            'returned'=>array('type'=>'integer','minimum'=>0), 'has_more'=>array('type'=>'boolean'),
            'next_offset'=>array('type'=>array('integer','null')),
            'reason'=>array('type'=>'string'),
            'sections'=>array('type'=>'object','additionalProperties'=>array('type'=>'object','properties'=>array(
                'total'=>array('type'=>'integer'), 'returned'=>array('type'=>'integer'), 'omitted'=>array('type'=>'integer'),
                'read'=>array('type'=>'object','description'=>'Parâmetros para google/get-job; paginação independente por seção.'),
            ))),
        ));
    }
    public static function bytes( array $value ): int {
        $json = wp_json_encode( $value );
        return false === $json ? PHP_INT_MAX : strlen( $json );
    }
    public static function error( string $section = '', int $offset = 0, string $reason = 'response' ): array {
        return Response::fail( new \WP_Error( 'f3_google_result_delivery_limit', 'Resultado excede o limite de entrega. Nenhum dado foi truncado; consulte as instruções de recuperação.' ), array(
            'delivery' => array( 'contract_version' => self::VERSION, 'budget_bytes' => self::BUDGET, 'section' => $section, 'offset' => $offset, 'reason' => $reason, 'has_more' => false, 'next_offset' => null ),
        ) );
    }
    public static function guard( array $result, string $operation ): array {
        if ( self::bytes( $result ) <= self::BUDGET ) { return $result; }
        $error = self::error();
        $error['operation_outcome'] = $result['operation_outcome'] ?? 'unknown';
        $error['retryable'] = false;
        // Execution may have completed. Delivery failure must never suggest replaying a write.
        foreach ( array( 'job_id', 'created', 'status' ) as $key ) {
            if ( isset( $result[$key] ) && is_scalar( $result[$key] ) && strlen( (string) $result[$key] ) <= 200 ) { $error[$key] = $result[$key]; }
        }
        if ( isset( $result['job']['id'] ) ) { $error['job_id'] = $result['job']['id']; }
        if ( in_array( $operation, array( 'google/query', 'google/report' ), true ) ) {
            $error['recovery'] = array( 'action' => 'google/create-job', 'task' => 'google/report' === $operation ? 'report' : 'query', 'parameters' => 'Use os parâmetros da consulta original; crie o job explicitamente e leia google/get-job por seção.', 'automatic_job_created' => false );
        } elseif ( 'google/blend' === $operation ) {
            $error['recovery'] = array( 'action' => 'google/create-job', 'task' => 'query', 'parameters' => 'Crie um job query explícito para cada consulta da composição, leia as páginas e componha os dados no cliente.', 'automatic_job_created' => false );
        } else {
            $error['recovery'] = array( 'action' => isset( $error['job_id'] ) ? 'google/get-job' : 'reduce_requested_page', 'message' => 'Consulte o estado antes de repetir qualquer operação com efeito.' );
        }
        return $error;
    }
}
