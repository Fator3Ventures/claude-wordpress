<?php
/**
 * Append-only operation records with configurable retention and bounded cleanup.
 * Remote outcomes are never replaced by a local audit persistence failure.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Audit {
    private static ?array $last_failure = null;
    private static ?string $last_marker = null;
    /** Teto de campos extras por registro — evita despejar a entrada inteira. */
    private const MAX_EXTRA = 12;
    private static array $contexts = array();
    /**
	 * @param string $action Nome da habilidade ou evento ('channel:disable').
	 * @param string $target Propriedade GA ou conta Ads envolvida.
	 * @param array  $extra  Só escalares curtos: rows, ms, status.
	 */
    public static function log( string $action, string $target = '-', array $extra = array(), ?array $configuration = null ): void {
        $r=Recovery::run(static fn()=>self::log_admitted($action,$target,$extra,$configuration));
        if (is_array($r) && isset($r['error_code']) && empty($r['success'])) {
            // A refused attempt is returned to the caller; it cannot write during restore.
            self::$last_marker=null;
            self::$last_failure=['state'=>'blocked','phase'=>'recovery','error_code'=>$r['error_code'],'at'=>time(),'persisted'=>false];
        }
    }
    private static function log_admitted(string $action,string $target,array $extra,?array $configuration): void {
        self::$last_failure = null;
        self::$last_marker = null;
        $revision = $configuration['revision'] ?? Settings::revision();
        $change = $configuration['change_id'] ?? Options::get( Settings::REVISION, null );
        $known = is_string( $revision ) && preg_match( '/^[a-f0-9]{64}$/D', $revision );
        $id = 'configuration:saved' === $action && $known ? $revision . '_' . bin2hex( random_bytes( 8 ) ) : Records::id();
        $entry = array(
            'created_at' => time(),
            'id' => $id,
            'time' => gmdate( 'Y-m-d H:i:s' ),
            'action' => self::trim( $action, 80 ),
            'target' => '' === $target ? '-' : self::trim( $target, 200 ),
            'user' => get_current_user_id(),
            'connection_id' => Connections::id(),
            'plugin_version' => F3_MCP_GOOGLE_VERSION,
            'configuration_revision' => $known ? $revision : null,
            'configuration_change_id' => is_string( $change ) ? $change : null,
            'configuration_association' => $known ? 'observed_at_append' : 'unavailable',
            'extra' => self::clean_extra( $extra ),
        );
        $context=Integration\Context::current();
        if ($context) {
            foreach (array('actor','run_id','trigger','request_id','property','consumer_revision') as $field) {
                $entry[$field]=$context[$field];
            }
            $entry['initiator_user']=get_current_user_id();
            $entry['user']=0;
        }
        try {
            if ( ! Records::insert( 'audit', $id, $entry ) ) {
                self::failure( 'append' );
                return;
            }
            if ( ( 'configuration:saved' === $action || $context ) && Records::get( 'audit', $id ) !== $entry ) {
                self::failure( 'marker_verification' );
                return;
            }
        }
        catch ( \Throwable $error ) {
            self::failure( 'append' );
            return;
        }
        // The marker identifies this append, independently of repeated configuration hashes.
        self::$last_marker = 'event:' . $id;
        self::recover( $id, $entry );
        // Serialize retention watermarks while keeping concurrent append independent.
        $lock = Lock::acquire( 'audit-retention', 30 );
        if ( null === $lock ) {
            return;
        }
        try {
            $retention = Options::limit( Options::AUDIT_RETENTION );
            $rows = Storage\Repository::select( 'audit', array(), 100, $retention );
            if ( is_wp_error( $rows ) ) {
                self::failure( 'retention_read' );
                return;
            }
            $removed_through = 0;
            foreach ( $rows as $row ) {
                $removed = Storage\Repository::remove( 'audit', $row['record_id'] );
                if ( ! $removed['success'] ) {
                    self::failure( 'retention_delete' );
                    continue;
                }
                $removed_through = max( $removed_through, (int) $row['sequence'] );
            }
            if ( $removed_through ) {
                $old = Options::stored( 'f3_mcp_google_audit_removed_through' );
                $saved = $old['success'] ? Options::set( 'f3_mcp_google_audit_removed_through', max( $removed_through, (int) ( $old['value'] ?? 0 ) ) ) : array( 'success' => false );
                if ( ! $saved['success'] ) {
                    self::failure( 'retention_watermark' );
                }
            }
            return;
        }
        catch ( \Throwable $error ) {
            self::failure( 'retention' );
        }
        finally {
            Lock::release( $lock );
        }
    }
    public static function append(string $action,string $target='-',array $extra=[]): array {
        self::log($action,$target,$extra);
        return ['success'=>self::$last_failure===null && self::$last_marker!==null,'marker'=>self::$last_marker,'error'=>self::$last_failure];
    }
    private static function failure( string $phase ): void {
        $health = array(
            'state' => 'failed',
            'at' => time(),
            'phase' => $phase,
            'error_code' => 'f3_google_audit_persistence',
            'connection_id' => Connections::id(),
            'cause' => 'storage_failure',
            'storage_state' => Storage\State::status()['state'],
            'historical_gap' => true,
        );
        self::$last_failure = $health;
        // Best effort, without recursion into Audit or altering the remote result.
        try {
            \Fator3\McpGoogle\Cache::set( 'f3_mcp_google_audit_health_' . Connections::id(), $health, 30 * 86400 );
            Options::set( 'f3_mcp_google_audit_health_' . Connections::id(), $health );
        }
        catch ( \Throwable $error ) {
            return;
        }
    }
    /** Recovery proves current persistence; a lost event remains a historical gap. */
    private static function recover( string $id, array $entry ): void {
        $health = self::health();
        if ( 'failed' !== ( $health['state'] ?? '' ) || (null !== Storage\State::guard()) ) {
            return;
        }
        $lock = Lock::acquire( 'audit-health:' . Connections::id(), 30 );
        if ( null === $lock ) {
            return;
        }
        try {
            $health = self::health();
            if ( 'failed' !== ( $health['state'] ?? '' ) || Records::get( 'audit', $id ) !== $entry ) {
                return;
            }
            $health['historical_gap'] = true;
            $health['state'] = 'recovered';
            $health['recovered_at'] = time();
            $health['verified_event'] = 'event:' . $id;
            $key = 'f3_mcp_google_audit_health_' . Connections::id();
            $saved = Options::set( $key, $health );
            if ( $saved['success'] ) {
                \Fator3\McpGoogle\Cache::set( $key, $health, 30 * 86400 );
            }
        }
        finally {
            Lock::release( $lock );
        }
    }
    public static function last_marker(): ?string {
        return self::$last_marker;
    }
    public static function last_failure(): ?array {
        return self::$last_failure;
    }
    public static function health(): array {
        $name = 'f3_mcp_google_audit_health_' . Connections::id();
        $cached = \Fator3\McpGoogle\Cache::get( $name );
        $saved = get_option( $name, null );
        return is_array( $cached ) ? $cached : ( is_array( $saved ) ? $saved : array( 'state' => 'no_failure_observed' ) );
    }
    /**
	 * @return array<int,array> Mais recente primeiro.
	 */
    public static function recent( int $limit = 30 ): array {
        $log = array_values( Records::list( 'audit', $limit > 0 ? $limit : 5000 ) );
        return $limit > 0 ? array_slice( $log, 0, $limit ) : $log;
    }
    public static function clear(): array {
        foreach ( Records::list( 'audit', 10000 ) as $id => $record ) {
            $result = Records::remove( 'audit', $id );
            if ( ! $result['success'] ) {
                return $result;
            }
        }
        return ['success'=>true, 'persisted'=>true];
    }
    /** Inicia um contexto isolado, inclusive para execução aninhada. */
    public static function begin(): void {
        self::$contexts[] = array(
            'before' => array(
                'available' => false,
                'reason' => 'Estado anterior não disponível para este método.',
            ),
            'after' => array(
                'available' => false,
                'reason' => 'Estado posterior não disponível para este método.',
            ),
        );
    }
    public static function before( $value ): void {
        if ( self::$contexts ) {
            self::$contexts[ count( self::$contexts ) - 1 ]['before'] = self::snapshot( $value );
        }
    }
    public static function after( $value ): void {
        if ( self::$contexts ) {
            self::$contexts[ count( self::$contexts ) - 1 ]['after'] = self::snapshot( $value );
        }
    }
    public static function finish(): array {
        return self::$contexts ? array_pop( self::$contexts ) : array();
    }
    /** Redação recursiva de segredos e identificadores de Customer Match. */
    public static function redact( $value, int $depth = 0 ) {
        if ( $depth > 8 ) {
            return '[limite de profundidade]';
        }
        if ( is_object( $value ) ) {
            $value = is_wp_error( $value ) ? array( 'error' => $value->get_error_message() ) : (array) $value;
        }
        if ( is_array( $value ) ) {
            $out = array();
            foreach ( $value as $key => $item ) {
                $normalized = strtolower( (string) preg_replace( '/[^a-z0-9]/i', '', (string) $key ) );
                if ( 'token' === $normalized || preg_match( '/secret|password|privatekey|accesstoken|refreshtoken|idtoken|developertoken|authorization|assertion|hashedemail|hashedphone|useridentifiers|addressinfo|clientid|userid/', $normalized ) ) {
                    $out[ $key ] = '[redigido]';
                }
                else {
                    $out[ $key ] = self::redact( $item, $depth + 1 );
                }
            }
            return $out;
        }
        return is_string( $value ) ? Ability::scrub( $value ) : $value;
    }
    /** Limite em bytes sem produzir JSON ou UTF-8 parcial. */
    private static function snapshot( $value ) {
        $clean = self::redact( $value );
        $json = (string) wp_json_encode( $clean );
        if ( strlen( $json ) <= 4096 ) {
            return $clean;
        }
        $out = array(
            'truncated' => true,
            'original_bytes' => strlen( $json ),
            'sha256' => hash( 'sha256', $json ),
            'fields' => array(),
        );
        foreach ( (array) $clean as $key => $item ) {
            $candidate = $out;
            $candidate['fields'][ $key ] = $item;
            if ( strlen( (string) wp_json_encode( $candidate ) ) <= 4096 ) {
                $out = $candidate;
            }
        }
        return $out;
    }
    private static function clean_extra( array $extra ): array {
        $clean = array();
        foreach ( $extra as $key => $value ) {
            if ( count( $clean ) >= self::MAX_EXTRA ) {
                break;
            }
            $name = sanitize_key( (string) $key );
            if ( '' === $name ) {
                continue;
            }
            if ( in_array( $name, array( 'before', 'after', 'result' ), true ) ) {
                $clean[ $name ] = self::snapshot( $value );
            }
            elseif ( is_scalar( $value ) || null === $value ) {
                $clean[ $name ] = is_string( $value ) ? self::trim( Ability::scrub( $value ), 60 ) : $value;
            }
        }
        return $clean;
    }
    private static function trim( string $text, int $max ): string {
        $text = trim( $text );
        return strlen( $text ) > $max ? substr( $text, 0, $max ) : $text;
    }
}
