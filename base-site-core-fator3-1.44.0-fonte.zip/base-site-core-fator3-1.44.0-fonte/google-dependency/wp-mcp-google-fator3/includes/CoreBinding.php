<?php
/**
 * Optional Site Core adapter; the Google plugin also works independently.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class CoreBinding {
    public static function source() {
        $context=CoreContext::snapshot();
        if(!$context['ok'])return CoreContext::error($context);
        return ['measurement_id'=>CoreContext::id($context,'ga4','measurement_id'),
            'gtm_container_id'=>CoreContext::id($context,'gtm','container_id'),
            'state'=>$context['data']['slots']['ga4']['state'],
            'revision'=>$context['data']['revision'],'scope'=>$context['data']['scope'],
            'configured'=>$context['data']['slots']['ga4']['configured'],
            'provenance'=>$context['data']['slots']['ga4']['provenance']];
    }
    public static function resolve() {
        $source = self::source();
        if ( is_wp_error( $source ) ) {
            return $source;
        }
        $id = $source['measurement_id'];
        if(in_array($source['state'],['invalid','disabled'],true))return new \WP_Error('f3_google_core_measurement_'.$source['state'],'O destino GA4 do Core está inválido ou desativado; informe IDs explícitos.');
        if ( '' === $id ) {
            return new \WP_Error( 'f3_google_core_measurement_missing', 'O slot GA4 do Site Core está vazio. Informe propriedade e stream explicitamente; o container GTM não identifica um destino GA4 único.' );
        }
        if ( ! preg_match( '/^G-[A-Z0-9]+$/D', $id ) ) {
            return new \WP_Error( 'f3_google_core_measurement_invalid', 'Corrija o Measurement ID GA4 do Site Core ou informe propriedade e stream explicitamente.' );
        }
        $accounts = Analytics\CatalogReader::list( 'accountSummaries.list', array(), 'accountSummaries' );
        if ( is_wp_error( $accounts ) ) {
            return $accounts;
        }
        $matches = array();
        $properties = array();
        foreach ( $accounts as $account ) {
            foreach ( $account['propertySummaries'] ?? array() as $property ) {
                if ( isset( $property['property'] ) ) {
                    $properties[ $property['property'] ] = true;
                }
            }
        }
        foreach ( array_keys( $properties ) as $property ) {
            $streams = Analytics\CatalogReader::list( 'properties.dataStreams.list', array( 'parent' => $property ), 'dataStreams' );
            if ( is_wp_error( $streams ) ) {
                return $streams;
            }
            foreach ( $streams as $stream ) {
                if ( ( $stream['webStreamData']['measurementId'] ?? null ) === $id ) {
                    $matches[ $stream['name'] ] = array(
                        'ga_property_id' => $property,
                        'ga_stream_id' => $stream['name'],
                        'ga_measurement_id' => $id,
                    );
                }
            }
        }
        if ( 1 !== count( $matches ) ) {
            return new \WP_Error(
                count( $matches ) > 1 ? 'f3_google_core_ambiguous' : 'f3_google_core_not_found',
                'Não foi encontrado um único stream acessível para o measurement ID.',
                array(
                    'matches' => count( $matches ),
                    'complete' => true,
                )
            );
        }
        $now = self::source();
        if ( is_wp_error( $now ) ) {
            return $now;
        }
        if ( $now['revision'] !== $source['revision'] ) {
            return new \WP_Error( 'f3_google_core_changed', 'Os identificadores do Site Core mudaram durante a descoberta.' );
        }
        return array(
            'bindings' => reset( $matches ),
            'source' => array(
                'adapter' => 'site-core',
                'contract' => CoreContext::CONTRACT,
                'slot' => 'ga4',
                'scope' => $source['scope'],
                'configured' => $source['configured'],
                'provenance' => $source['provenance'],
                'measurement_id' => $id,
                'gtm_container_id' => $source['gtm_container_id'],
                'revision' => $source['revision'],
            ),
        );
    }
}
