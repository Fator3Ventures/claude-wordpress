<?php
/** Allowlisted installed documentation. No provider, connection or storage calls. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Documentation {
    public const MAX_BYTES = 65536;
    public static function allowed(): bool { return current_user_can('manage_options'); }
    public static function read( array $input ): array {
        if ( ! self::allowed() ) { return Response::fail(new \WP_Error('f3_google_forbidden','A documentação exige administração do site.')); }
        $documents = require F3_MCP_GOOGLE_DIR . 'includes/Data/Documentation.php';
        $identity = array('slug'=>'wp-mcp-google-fator3','plugin_version'=>F3_MCP_GOOGLE_VERSION,'origin'=>'local','encoding'=>'UTF-8');
        $id = $input['document'] ?? '';
        if ( '' === $id ) {
            $index = array();
            foreach ( Admin::documents() as $name => $label ) { $index[] = array('document'=>$name,'description'=>$label,'bytes'=>strlen($documents[$name]),'revision'=>hash('sha256',$documents[$name])); }
            return Response::ok($identity + array('documents'=>$index,'max_limit_bytes'=>self::MAX_BYTES,'read'=>array('ability'=>'google/documentation','parameters'=>array('document'=>'README.md','offset'=>0,'limit_bytes'=>16384)),'pagination'=>'offset é byte UTF-8; use next_offset e expected_revision em cada continuação. revision é SHA-256 do documento inteiro.'));
        }
        if ( ! is_string($id) || ! isset(Admin::documents()[$id], $documents[$id]) ) { return Response::fail(new \WP_Error('f3_google_document_missing','Documento fora do índice local.')); }
        $content = $documents[$id]; $revision = hash('sha256',$content);
        $offset = $input['offset'] ?? 0; $limit = $input['limit_bytes'] ?? 16384;
        if ( ! is_int($offset) || $offset < 0 || $offset > strlen($content) || ! is_int($limit) || $limit < 256 || $limit > self::MAX_BYTES ) { return Response::fail(new \WP_Error('f3_google_document_range','offset ou limit_bytes inválido.')); }
        if ( ($offset > 0 && ! isset($input['expected_revision'])) || (isset($input['expected_revision']) && (!is_string($input['expected_revision']) || !hash_equals($revision,$input['expected_revision']))) ) { return Response::fail(new \WP_Error('f3_google_document_revision','Revisão ausente ou alterada; reinicie a leitura pelo índice.')); }
        if ( $offset < strlen($content) && (ord($content[$offset]) & 0xc0) === 0x80 ) { return Response::fail(new \WP_Error('f3_google_document_range','offset deve iniciar um caractere UTF-8.')); }
        $end = min(strlen($content),$offset+$limit);
        while ( $end < strlen($content) && (ord($content[$end]) & 0xc0) === 0x80 ) { --$end; }
        $page = substr($content,$offset,$end-$offset);
        return Response::ok($identity + array('document'=>$id,'revision'=>$revision,'sha256'=>$revision,'total_bytes'=>strlen($content),'offset'=>$offset,'returned_bytes'=>strlen($page),'content'=>$page,'has_more'=>$end<strlen($content),'next_offset'=>$end<strlen($content)?$end:null));
    }
    public static function register(): void {
        Ability::register('google/documentation','any',array('label'=>'Google: documentação instalada','description'=>'Índice e leitura integral paginada dos manuais e schemas desta versão. Local, estática, sem credenciais nem chamadas Google. Exige manage_options.',
            'output_schema'=>array('type'=>'object','properties'=>array(
                'success'=>array('type'=>'boolean'),'message'=>array('type'=>'string'),'error_code'=>array('type'=>'string'),
                'slug'=>array('type'=>'string'),'plugin_version'=>array('type'=>'string'),'origin'=>array('type'=>'string','enum'=>array('local')),
                'encoding'=>array('type'=>'string','enum'=>array('UTF-8')),'document'=>array('type'=>'string'),'revision'=>array('type'=>'string'),'sha256'=>array('type'=>'string'),
                'documents'=>array('type'=>'array','items'=>array('type'=>'object')),'content'=>array('type'=>'string'),
                'offset'=>array('type'=>'integer'),'returned_bytes'=>array('type'=>'integer'),'total_bytes'=>array('type'=>'integer'),
                'has_more'=>array('type'=>'boolean'),'next_offset'=>array('type'=>array('integer','null')),
            )),
            'input_schema'=>array('properties'=>array(
                'document'=>array('type'=>'string','description'=>'ID exato do índice; omitir para obter o índice.'),
                'offset'=>array('type'=>'integer','minimum'=>0,'default'=>0),
                'limit_bytes'=>array('type'=>'integer','minimum'=>256,'maximum'=>self::MAX_BYTES,'default'=>16384),
                'expected_revision'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$','description'=>'SHA-256 obrigatório ao continuar offset maior que zero.'),
            )), 'callback'=>array(self::class,'read')));
    }
}
