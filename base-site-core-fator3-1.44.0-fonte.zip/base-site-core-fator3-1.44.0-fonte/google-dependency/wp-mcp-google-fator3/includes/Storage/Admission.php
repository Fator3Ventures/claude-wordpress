<?php
/** Current work admission. Recovery owns the shared fence for the whole operation. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;
use Fator3\McpGoogle\{
    Ability, Recovery, Response
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Admission {
    public static function run(string $name, callable $callback) {
        // Bridges authorize the final target; that target owns its admission guard.
        if (in_array($name, ['google/mcp-read','google/mcp-write'], true) || Ability::local_read($name)
            || in_array($name, ['google/maintenance','google/recovery','google/executar-vencidos'], true)) {
            return $callback();
        }
        return Recovery::run(static function () use ($callback) {
            $error = State::guard();
            return $error ? Response::fail($error) : $callback();
            });
    }
    public static function dispatch_guard(): ?\WP_Error {
        return Recovery::guard() ?? State::guard();
    }
}
