<?php
/** One guarded coordinator, a global budget and durable cursors for every maintenance family. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;
use Fator3\McpGoogle\{
    Options,Lock,Cache,Records,Recovery,Response
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Maintenance {
    public const HOOK='f3_mcp_google_maintenance';
    public const OPTION='f3_mcp_google_maintenance';
    private const FAMILIES=['cron_retention','cache_sql','cache_files'];
    private static array $observed=[];
    public static function init(): void {
        add_action(self::HOOK,[self::class,'once']);
    }
    public static function activate(): void {
        Recovery::run(static function() {
            // No scan/copy on the public request. Schema DDL happens once when absent.
            $r=State::ensure_ready();
            if (is_wp_error($r)) Options::set(self::OPTION,['state'=>'failed','success'=>false,'errors'=>[$r->get_error_code()]]);
            self::schedule(false);
            });
    }
    private static function schedule(bool $pending): array {
        if (!function_exists('wp_next_scheduled')) return ['success'=>true,'next_run'=>null];
        $next=wp_next_scheduled(self::HOOK);
        if (!$next || ($pending && $next>time()+60)) {
            $r=\Fator3\McpGoogle\Automation\Scheduling::schedule(self::HOOK,time()+($pending?15:5),$pending?false:'hourly');
            if (empty($r['success'])) return ['success'=>false,'error_code'=>'f3_google_maintenance_schedule','next_run'=>$next?:null];
            $next=wp_next_scheduled(self::HOOK);
        }
        return ['success'=>true,'next_run'=>$next?:null];
    }
    public static function schema(): array {
        return ['type'=>'object','properties'=>[
                'maintenance_contract_version'=>['type'=>'string','enum'=>['2.0.0']],
                'state'=>['type'=>'string','enum'=>['complete','pending','failed']],
                'success'=>['type'=>['boolean','null']], 'execution_success'=>['type'=>'boolean'],
                'remaining'=>['type'=>'boolean'], 'inventory_complete'=>['type'=>'boolean'], 'read_success'=>['type'=>'boolean'],
                'at'=>['type'=>'integer'], 'finished_at'=>['type'=>'integer'], 'observed_at'=>['type'=>'integer'],
                'observation_age_seconds'=>['type'=>['integer','null']], 'next_run'=>['type'=>['integer','null']],
                'blocked_by'=>['type'=>['string','null']], 'error_code'=>['type'=>['string','null']],
                'scheduling'=>['type'=>'object'],'executor_repair'=>['type'=>'object'],
                'errors'=>['type'=>'array','items'=>['type'=>'string']],
                'cache_migrated'=>['type'=>'integer'],
                'advance_operation'=>['type'=>'string'],
                'pending_counts'=>['type'=>'object','additionalProperties'=>['type'=>['integer','null']]],
                'progress'=>['type'=>'object','additionalProperties'=>['type'=>'object','properties'=>[
                            'cursor'=>['type'=>'string'],'complete'=>['type'=>'boolean'],'examined_in_pass'=>['type'=>'boolean'],'read_success'=>['type'=>'boolean'],
                            'at'=>['type'=>'integer'],'connection_id'=>['type'=>'string'],'error_code'=>['type'=>['string','null']]]]],
                'budget'=>['type'=>'object','properties'=>['row_limit'=>['type'=>'integer'],'time_limit_ms'=>['type'=>'integer'],
                        'processed'=>['type'=>'integer'],'duration_ms'=>['type'=>'integer'],'stop_reason'=>['type'=>['string','null']]]]
            ]];
    }
    public static function status(): array {
        $r=Options::stored(self::OPTION);
        $s=$r['success']&&is_array($r['value'])?$r['value']:['state'=>$r['success']?'pending':'failed','success'=>null,'remaining'=>true,'inventory_complete'=>false];
        $s=array_intersect_key($s,self::schema()['properties']+['cache'=>true]);
        foreach (['progress','pending_counts'] as $key) $s[$key]=array_intersect_key($s[$key]??[],array_flip(self::FAMILIES));
        $s['maintenance_contract_version']='2.0.0';
        $s['read_success']=$r['success'];
        $s['inventory_complete']=$s['inventory_complete']??false;
        if (!$r['success']) $s['error_code']='f3_google_maintenance_read';
        $paused=Recovery::guard();
        $s['blocked_by']=$paused?$paused->get_error_code():($s['blocked_by']??null);
        $s['observed_at']=time();
        $s['observation_age_seconds']=isset($s['at'])?max(0,time()-(int)$s['at']):null;
        $s['next_run']=function_exists('wp_next_scheduled')?(wp_next_scheduled(self::HOOK)?:null):null;
        $s['advance_operation']='google/maintenance';
        return $s;
    }
    /** Automatic entry points share one pass per site/invocation; explicit requests may advance again. */
    public static function once(?Budget $budget=null): array {
        $site=function_exists('get_current_blog_id')?get_current_blog_id():1;
        if (isset(self::$observed[$site])) return self::$observed[$site]+['reused_pass'=>true];
        $r=self::run($budget??Budget::automatic());
        self::$observed[$site]=$r;
        return $r;
    }
    public static function run(?Budget $budget=null): array {
        return Recovery::run(static fn()=>self::work($budget??new Budget()));
    }
    private static function names(string $condition,string $cursor): array {
        global $wpdb;
        $rows=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE ($condition) AND option_name>%s ORDER BY option_name LIMIT 1",$cursor));
        if ($wpdb->last_error||!is_array($rows)) throw new \RuntimeException('f3_google_maintenance_read');
        return $rows;
    }
    private static function condition(string $family): string {
        global $wpdb;
        return $wpdb->prepare('option_name LIKE %s AND (LENGTH(option_value)>%d OR option_name LIKE %s)',$wpdb->esc_like('_transient_f3_mcp_google_').'%',Cache::MAX_DB_BYTES,$wpdb->esc_like('_transient_f3_mcp_google_discovery_').'%');
    }
    private static function unit(string $family,array &$progress,array &$out,Budget $budget,array $lock): array {
        global $wpdb;
        if ($family==='cache_files') {
            $r=Cache::maintain(false,$budget);
            $out['cache']=$r;
            return $r+['complete'=>empty($r['remaining'])];
        }
        if ($family==='cron_retention') {
            // Indexed table also covers connections no longer present in the registry.
            $table=CronStore::table();
            $rows=$wpdb->get_results($wpdb->prepare("SELECT connection_id,kind FROM $table WHERE CONCAT(connection_id,'/',kind)>%s GROUP BY connection_id,kind HAVING MIN(at)<%d OR COUNT(*)>CASE kind WHEN 'pass' THEN %d ELSE %d END ORDER BY connection_id,kind LIMIT 1",$progress['cursor']??'',time()-CronStore::DAYS*86400,CronStore::MAX_PASSES,CronStore::MAX_INCIDENTS),ARRAY_A);
            if ($wpdb->last_error||!is_array($rows)) throw new \RuntimeException('f3_google_cron_storage_read');
            if (!$rows) {
                if (!empty($progress['cursor'])) {
                    $progress['cursor']='';
                    return self::unit($family,$progress,$out,$budget,$lock);
                }
                return ['success'=>true,'complete'=>true];
            }
            $row=$rows[0];
            $progress['connection_id']=$row['connection_id'];
            $connection_lock=Lock::acquire('cron-'.($row['kind']==='pass'?'history':'incident').':'.$row['connection_id'],30);
            if (!$connection_lock) return ['success'=>false,'error_code'=>'f3_google_cron_history_busy','retryable'=>true];
            try {
                $r=CronStore::trim($row['connection_id'],$row['kind'],0,$budget,$connection_lock);
            }
            finally {
                Lock::release($connection_lock);
            }
            // A partially pruned group is revisited next cycle; no false global completion.
            $progress['cursor']=$row['connection_id'].'/'.$row['kind'];
            return is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code()]:['success'=>true];
        }
        $condition=self::condition($family);
        $names=self::names($condition,$progress['cursor']??'');
        if (!$names) {
            $progress['cursor']='';
            $names=self::names($condition,'');
            if (!$names) return ['success'=>true,'complete'=>true];
        }
        $name=$names[0];
        $progress['cursor']=$name;
        $r=Cache::migrate_sql(substr($name,strlen('_transient_')));
        if (!empty($r['success'])) ++$out['cache_migrated'];
        return $r;
    }
    private static function work(Budget $budget): array {
        $lock=Lock::acquire('package-maintenance',60);
        if (!$lock) return ['success'=>false,'state'=>'pending','remaining'=>true,'error_code'=>'f3_google_maintenance_busy','blocked_by'=>'f3_google_maintenance_busy','retryable'=>true];
        $scheduling=\Fator3\McpGoogle\Automation\Scheduling::reconcile();
        $repair=$budget->claim()?\Fator3\McpGoogle\Automation\ExecutorSchedule::ensure('maintenance'):['success'=>false,'state'=>'deferred','error_code'=>'f3_google_maintenance_budget','attempted'=>false];
        $out=['maintenance_contract_version'=>'2.0.0','success'=>true,'execution_success'=>true,'state'=>'pending','at'=>time(),'cache_migrated'=>0,'remaining'=>true,'inventory_complete'=>false,'errors'=>[],'scheduling'=>$scheduling,'executor_repair'=>$repair,'progress'=>[],'pending_counts'=>[],'read_success'=>true,'blocked_by'=>null];
        try {
            $prior=Options::stored(self::OPTION);
            if (!$prior['success']) throw new \RuntimeException('f3_google_maintenance_read');
            $old=is_array($prior['value'])?$prior['value']:[];
            $out['progress']=array_intersect_key($old['progress']??[],array_flip(self::FAMILIES));
            foreach (self::FAMILIES as $family) $out['progress'][$family]=array_replace($out['progress'][$family]??['cursor'=>''],['examined_in_pass'=>false]);
            $next=(int)($old['next_family']??0)%count(self::FAMILIES);
            $finished=[];
            $schema=State::ensure_ready();
            if (is_array($schema)) throw new \RuntimeException($schema['error_code']??'f3_google_storage_unavailable');
            if (is_wp_error($schema)) throw new \RuntimeException($schema->get_error_code());
            while ($budget->available() && count($finished)<count(self::FAMILIES)) {
                $family=self::FAMILIES[$next];
                $next=($next+1)%count(self::FAMILIES);
                if (isset($finished[$family])) continue;
                if (!Lock::owned($lock)) throw new \RuntimeException('f3_google_lock_lost');
                if (!$budget->claim()) break;
                $progress=$out['progress'][$family]??['cursor'=>''];
                try {
                    $r=self::unit($family,$progress,$out,$budget,$lock);
                }
                catch (\Throwable $e) {
                    $code=$e->getMessage();
                    $r=['success'=>false,'error_code'=>preg_match('/^f3_google_[a-z_]+$/D',$code)?$code:'f3_google_maintenance_failed'];
                }
                $progress['examined_in_pass']=true;
                $progress['at']=time();
                $progress['complete']=!empty($r['complete']);
                $progress['error_code']=$r['error_code']??null;
                $progress['read_success']=!str_contains((string)$progress['error_code'],'read');
                $out['progress'][$family]=$progress;
                if (empty($r['success'])) {
                    $out['errors'][]=$r['error_code']??'f3_google_maintenance_failed';
                    if (!empty($r['retryable'])) $out['blocked_by']=$r['error_code'];
                    $finished[$family]=true;
                }
                if (!empty($r['complete'])||!empty($r['cycle_finished'])||$family==='cache_files') $finished[$family]=true;
            }
            $out['next_family']=$next;
            // Completion requires a successful observation of every family in THIS pass.
            $complete=true;
            foreach (self::FAMILIES as $family) {
                $known=isset($finished[$family])&&!empty($out['progress'][$family]['complete'])&&empty($out['progress'][$family]['error_code']);
                $out['pending_counts'][$family]=$known?0:null;
                if (!$known) $complete=false;
            }
            $out['inventory_complete']=$complete;
            $out['remaining']=!$complete;
            $out['state']=$out['errors']?'failed':($complete?'complete':'pending');
            $out['success']=!$out['errors'];
            $schedule=self::schedule(!$complete);
            $out['next_run']=$schedule['next_run'];
            if (!$schedule['success']) {
                $out['errors'][]=$schedule['error_code'];
                $out['success']=false;
                $out['state']='failed';
            }
        }
        catch (\Throwable $e) {
            $code=$e->getMessage();
            $out['errors'][]=preg_match('/^f3_google_[a-z_]+$/D',$code)?$code:'f3_google_maintenance_failed';
            $out['success']=false;
            $out['state']='failed';
            $out['remaining']=true;
        }
        $out['budget']=$budget->result();
        $out['finished_at']=time();
        $out['errors']=array_values(array_unique($out['errors']));
        try {
            if (!Lock::owned($lock)) return Response::fail(new \WP_Error('f3_google_lock_lost','Manutenção interrompida: posse da trava perdida.'),['work_result'=>$out]);
            $saved=Options::set(self::OPTION,$out);
            if (!$saved['success']) return Response::fail(new \WP_Error('f3_google_maintenance_persistence','Manutenção executada, mas o resultado não foi persistido.'),['work_result'=>$out]);
            return $out;
        }
        finally {
            Lock::release($lock);
        }
    }
}
