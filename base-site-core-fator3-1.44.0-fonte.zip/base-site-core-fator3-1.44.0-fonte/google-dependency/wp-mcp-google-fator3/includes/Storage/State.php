<?php
/** Current storage structure. Readiness is observed; no historical marker is consulted. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;
use Fator3\McpGoogle\{
    Ability, Cache, Lock, Recovery, Response
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class State {
    public static function schema(): array {
        return ['type'=>'object','description'=>'Estrutura do site WordPress, comum às conexões. Consultar não instala tabelas.','required'=>['storage_contract_version','ready','state','tables','error_code'],'properties'=>[
            'storage_contract_version'=>['type'=>'string','enum'=>['2.0.0']],
            'ready'=>['type'=>'boolean','description'=>'Colunas correntes acessíveis nas duas tabelas. Não é teste remoto Google.'],
            'state'=>['type'=>'string','enum'=>['ready','unavailable']],
            'tables'=>['type'=>'object','required'=>['records','cron'],'properties'=>['records'=>['type'=>'boolean'],'cron'=>['type'=>'boolean']]],
            'error_code'=>['type'=>['string','null']]],'additionalProperties'=>true];
    }
    public static function status(): array {
        global $wpdb;
        $tables = [
            'records' => [Repository::table(), 'sequence,kind,record_id,connection_id,actor,state,task,target,mode,due_at,priority,created_at,updated_at,expires_at,owner,lease_until,generation,digest,payload'],
            'cron' => [CronStore::table(), 'kind,connection_id,run_id,at,origin,scope,success,payload,digest'],
        ];
        $checks = [];
        $prior = method_exists($wpdb,'suppress_errors') ? $wpdb->suppress_errors(true) : null;
        foreach ($tables as $name => [$table, $columns]) {
            $rows = $wpdb->get_results("SELECT $columns FROM $table LIMIT 0", ARRAY_A);
            $checks[$name] = is_array($rows) && !$wpdb->last_error;
        }
        if ($prior !== null) $wpdb->suppress_errors($prior);
        $ready = !in_array(false, $checks, true);
        return ['storage_contract_version'=>'2.0.0', 'ready'=>$ready, 'state'=>$ready?'ready':'unavailable',
            'tables'=>$checks, 'error_code'=>$ready?null:'f3_google_storage_unavailable'];
    }
    public static function guard(): ?\WP_Error {
        return self::status()['ready'] ? null : new \WP_Error('f3_google_storage_unavailable',
            'A estrutura atual do armazenamento está indisponível. Consulte google/storage-status.',
            ['operation_outcome'=>'not_applied', 'retryable'=>true]);
    }
    public static function ensure_ready() {
        return Recovery::run(static function () {
            if (self::status()['ready']) return true;
            $lock = Lock::acquire('storage-schema', 30);
            if (!$lock) return new \WP_Error('f3_google_storage_busy', 'Preparação do armazenamento em andamento.');
            try {
                $result = Repository::install();
                if (is_wp_error($result)) return $result;
                $result = CronStore::install();
                return is_wp_error($result) ? $result : (self::guard() ?? true);
            }
            finally {
                Lock::release($lock);
            }
            });
    }
    public static function register(): void {
        Ability::register('google/storage-status', 'any', [
                'label'=>'Google: estado do armazenamento',
                'description'=>'Consulta local da estrutura atual e da manutenção, sem criar tabelas nem alterar dados.',
                'output_schema'=>['type'=>'object','properties'=>['success'=>['type'=>'boolean','description'=>'Consulta executada; prontidão vem de storage.ready.'],'message'=>['type'=>'string'],'storage'=>self::schema(),'maintenance'=>Maintenance::schema(),'cache'=>Cache::schema()]],
                'callback'=>static fn()=>Response::ok(['storage'=>self::status(), 'maintenance'=>Maintenance::status(), 'cache'=>Cache::status()]),
            ]);
        Ability::register('google/maintenance', 'any', [
                'label'=>'Google: executar manutenção', 'mode'=>'write',
                'description'=>'Executa uma passagem limitada de retenção, cache e reparação da agenda do próprio Google. Respeita a pausa de recuperação.',
                'output_schema'=>Maintenance::schema(),
                'callback'=>static fn()=>current_user_can('manage_options') ? Maintenance::run() : Response::fail(new \WP_Error('f3_google_forbidden','Permissão administrativa exigida.')),
            ]);
    }
}
