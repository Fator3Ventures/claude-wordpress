<?php
/** Byte and count pagination over immutable persisted sections. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{Delivery, Response};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class JobDelivery {
    public static function view( array $source, int $offset, int $limit, bool $include_input, string $section ): array {
        $job = $source;
        unset( $job['confirmation_record'], $job['collection_state'], $job['context'] );
        if ( ! $include_input ) { unset( $job['parameters'], $job['input_hash'] ); }
        if ( ! empty( $job['details_removal_started'] ) ) {
            unset( $job['result'], $job['results'], $job['result_pages'] );
            $job['details_available'] = false;
            $job['cleanup_pending'] = true;
            return self::bounded_header( $job, $section, $offset );
        }
        $offset = max( 0, $offset );
        $limit = max( 1, min( 100, $limit ) );
        $sections = Results::sections( $source );
        $explicit = '' !== $section;
        if ( ! $explicit ) { $section = isset( $sections['results'] ) ? 'results' : ( isset( $sections['rows'] ) ? 'rows' : (string) array_key_first( $sections ) ); }
        if ( $explicit && ! isset( $sections[$section] ) ) {
            return self::failure( $job, 'f3_google_result_section', 'Seção não disponível neste job.', $section, $offset );
        }
        foreach ( Results::PATHS as $name => $path ) { Results::remove( $job, $name ); }
        unset( $job['results'] );
        $job['delivery'] = array( 'contract_version' => Delivery::VERSION, 'budget_bytes' => Delivery::BUDGET, 'bytes' => 0, 'section' => $section, 'offset' => $offset, 'returned' => 0, 'has_more' => false, 'next_offset' => null, 'sections' => array() );
        foreach ( $sections as $name => $total ) {
            $job['delivery']['sections'][$name] = array( 'total' => $total, 'returned' => 0, 'omitted' => $total, 'read' => array( 'job_id' => $job['id'], 'section' => $name, 'offset' => 0, 'limit' => $limit ) );
        }
        $total = $sections[$section] ?? 0;
        $job['page'] = array( 'offset' => $offset, 'limit' => $limit, 'total' => $total, 'next_offset' => null );
        if ( '' !== $section ) { Results::assign( $job, $section, array() ); }
        if ( self::size( $job ) > Delivery::JOB_BUDGET ) { return self::failure( $source, 'f3_google_result_delivery_limit', 'Cabeçalho ou parâmetros excedem o limite de entrega.', $section, $offset, $include_input ? 'header_or_input' : 'header' ); }
        $accepted = array();
        $values = 'results' === $section ? Results::page( $source['id'], $offset, $limit ) : ( '' !== $section ? Results::rows( $source, $section, $offset, $limit ) : array() );
        foreach ( $values as $value ) {
            $candidate = $job;
            $next = $accepted;
            $next[] = $value;
            Results::assign( $candidate, $section, $next );
            self::progress( $candidate, $section, $offset, count( $next ), $total );
            if ( self::size( $candidate ) > Delivery::JOB_BUDGET ) {
                if ( ! $accepted ) { return self::failure( $source, 'f3_google_result_delivery_limit', 'Um item individual excede o limite de entrega.', $section, $offset, 'item' ); }
                break;
            }
            $accepted = $next;
            $job = $candidate;
        }
        if ( $offset < $total && ! $accepted ) { return self::failure( $source, 'f3_google_result_incomplete', 'Seção persistida incompleta; a leitura não avançou.', $section, $offset ); }
        self::progress( $job, $section, $offset, count( $accepted ), $total );
        // Preserve small, complete metadata in the default view. Omission is always explicit.
        if ( ! $explicit ) {
            foreach ( $sections as $name => $count ) {
                if ( $name === $section || $count > $limit ) { continue; }
                $candidate = $job;
                Results::assign( $candidate, $name, Results::rows( $source, $name, 0, $count ) );
                $candidate['delivery']['sections'][$name]['returned'] = $count;
                $candidate['delivery']['sections'][$name]['omitted'] = 0;
                if ( self::size( $candidate ) <= Delivery::JOB_BUDGET ) { $job = $candidate; }
            }
        }
        self::size( $job );
        return $job;
    }
    private static function progress( array &$job, string $section, int $offset, int $count, int $total ): void {
        $next = $offset + $count < $total ? $offset + $count : null;
        $job['page']['next_offset'] = $next;
        $job['delivery']['returned'] = $count;
        $job['delivery']['has_more'] = null !== $next;
        $job['delivery']['next_offset'] = $next;
        if ( '' !== $section ) {
            $job['delivery']['sections'][$section]['returned'] = $count;
            $job['delivery']['sections'][$section]['omitted'] = max( 0, $total - $count );
        }
    }
    private static function size( array &$job ): int {
        // Decimal byte count itself changes the encoded size: converge before comparing.
        do { $previous = $job['delivery']['bytes']; $job['delivery']['bytes'] = Delivery::bytes( $job ); } while ( $previous !== $job['delivery']['bytes'] );
        return $job['delivery']['bytes'];
    }
    private static function bounded_header( array $job, string $section, int $offset ): array {
        return Delivery::bytes( $job ) <= Delivery::JOB_BUDGET ? $job : self::failure( $job, 'f3_google_result_delivery_limit', 'Cabeçalho excede o limite de entrega.', $section, $offset, 'header' );
    }
    private static function failure( array $job, string $code, string $message, string $section, int $offset, string $reason = 'section' ): array {
        return array( 'id' => $job['id'], 'task' => $job['task'], 'status' => $job['status'], 'delivery_error' => Response::fail( new \WP_Error( $code, $message ), array( 'delivery' => array( 'contract_version' => Delivery::VERSION, 'budget_bytes' => Delivery::BUDGET, 'section' => $section, 'offset' => $offset, 'reason' => $reason, 'has_more' => false, 'next_offset' => null ) ) ) );
    }
}
