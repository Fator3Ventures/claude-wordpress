<?php
/**
 * Job items are independent records: pagination does not load preceding results.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Records, Storage\Repository
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Results {
    public const PATHS = array( 'rows' => array('rows'), 'page_changes' => array('page_changes'), 'coverage' => array('coverage'), 'quality_pages' => array('quality','pages'), 'quality_changes' => array('quality','changes') );
    public static function inline( array $job, string $field ): ?array {
        $value = $job['result'] ?? array();
        foreach ( self::PATHS[$field] ?? array($field) as $key ) {
            if ( ! is_array($value) || ! array_key_exists($key,$value) ) { return null; }
            $value = $value[$key];
        }
        return is_array($value) ? array_values($value) : null;
    }
    public static function assign( array &$job, string $field, array $value ): void {
        if ( 'results' === $field ) { $job['results'] = $value; return; }
        $target =& $job['result'];
        foreach ( self::PATHS[$field] as $key ) { $target =& $target[$key]; }
        $target = $value;
    }
    public static function remove( array &$job, string $field ): void {
        $path = self::PATHS[$field];
        if ( count($path) === 1 ) { unset($job['result'][$path[0]]); }
        else { unset($job['result'][$path[0]][$path[1]]); }
    }
    public static function sections( array $job ): array {
        $sections = array();
        if ( 'inspect-urls' === ($job['task'] ?? '') ) { $sections['results'] = (int)($job['result_count'] ?? 0); }
        foreach ( self::PATHS as $name => $path ) {
            if ( isset($job['result_pages'][$name]) ) { $sections[$name] = (int)$job['result_pages'][$name]['count']; }
            elseif ( null !== ($values = self::inline($job,$name)) ) { $sections[$name] = count($values); }
        }
        return $sections;
    }

    public static function id( string $job, int $index ): string {
        return hash( 'sha256', $job ) . '_' . sprintf( '%06d', $index );
    }
    public static function put( string $job, int $index, array $result ): array {
        return Records::put(
            'item',
            self::id( $job, $index ),
            array(
                'task' => $job,
                'index' => $index,
                'result' => $result,
                'created_at' => time(),
            )
        );
    }
    public static function page( string $job, int $offset, int $limit ): array {
        $out = array();
        for ( $i = $offset;$i < $offset + $limit;++$i ) {
            $record = Records::get( 'item', self::id( $job, $i ) );
            if ( null === $record ) {
                break;
            }
            $out[] = $record['result'];
        }
        return $out;
    }
    public static function chunk_id( string $job, string $field, int $chunk ): string {
        return hash( 'sha256', $job . '|' . $field ) . '_' . sprintf( '%06d', $chunk );
    }
    /** Split table rows before persisting the job. Each chunk is fetched independently. */
    public static function externalize( array &$job ): array {
        $records = array();
        foreach ( array_keys(self::PATHS) as $field ) {
            if ( null === self::inline($job,$field) ) {
                continue;
            }
            $rows = self::inline($job,$field);
            $job['result_pages'][ $field ] = array(
                'count' => count( $rows ),
                'chunk_size' => 100,
            );
            foreach ( array_chunk( $rows, 100 ) as $index => $values ) {
                $records[ self::chunk_id( $job['id'], $field, $index ) ] = array(
                    'task' => $job['id'],
                    'field' => $field,
                    'index' => $index,
                    'rows' => $values,
                    'connection_id' => $job['connection_id'] ?? 'default',
                    'created_at' => $job['updated_at'] ?? $job['created_at'] ?? 0,
                );
            }
            self::remove($job,$field);
        }
        return $records;
    }
    public static function rows( array $job, string $field, int $offset, int $limit ): array {
        $meta = $job['result_pages'][ $field ] ?? null;
        if ( null === $meta ) {
            return array_slice( self::inline($job,$field) ?? array(), $offset, $limit );
        }
        $end = min( $meta['count'], $offset + $limit );
        $out = array();
        for ( $cursor = $offset;$cursor < $end; ) {
            $chunk = (int) floor( $cursor / $meta['chunk_size'] );
            $record = Records::get( 'result', self::chunk_id( $job['id'], $field, $chunk ) );
            if ( null === $record || ! isset( $record['rows'] ) ) {
                throw new \RuntimeException( 'f3_google_result_missing' );
            }
            $within = $cursor % $meta['chunk_size'];
            $take = min( $end - $cursor, $meta['chunk_size'] - $within );
            $slice = array_slice( $record['rows'], $within, $take );
            if ( count( $slice ) !== $take ) {
                throw new \RuntimeException( 'f3_google_result_incomplete' );
            }
            $out = array_merge( $out, $slice );
            $cursor += $take;
        }
        return $out;
    }
}
