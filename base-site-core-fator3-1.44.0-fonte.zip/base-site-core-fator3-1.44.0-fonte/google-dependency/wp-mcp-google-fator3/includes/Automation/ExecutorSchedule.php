<?php
/** Current executor agenda and guarded lifecycle; reads never repair it. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Options,Lock,Recovery
};
use Fator3\McpGoogle\Storage\State;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ExecutorSchedule {
    public const OPTION='f3_mcp_google_cron_executor_intent';
    private static array $generations=[];
    public static function capture(): void {
        $s=self::intent();
        self::$generations[self::site()]=$s['generation'];
    }
    private static function site(): int {
        return function_exists('get_current_blog_id')?get_current_blog_id():1;
    }
    private static function intent(): array {
        $r=Options::stored(self::OPTION);
        if (!$r['success']) return ['desired_state'=>'unknown','generation'=>null,'origin'=>'unreadable','error_code'=>'f3_google_executor_intent_read'];
        if (!$r['exists']) return ['desired_state'=>'active','generation'=>null,'origin'=>'active_runtime','error_code'=>null];
        $v=$r['value'];
        if (!is_array($v)||!in_array($v['desired_state']??'', ['active','inactive'],true)||!is_string($v['generation']??null)||!is_string($v['origin']??null)||!is_int($v['at']??null)||!preg_match('/^[a-f0-9]{32}$/D',$v['generation'])) return ['desired_state'=>'unknown','generation'=>null,'origin'=>'invalid','error_code'=>'f3_google_executor_intent_read'];
        return $v+['error_code'=>null];
    }
    /** Snapshot of both agenda views, independently from stored diagnostics. */
    public static function status(): array {
        $intent=self::intent();
        $blocked=Recovery::guard();
        $read=Scheduling::read_current([Jobs::HOOK]);
        $out=['hook'=>Jobs::HOOK,'desired_state'=>$intent['desired_state'],'generation'=>$intent['generation'],'intent_origin'=>$intent['origin'],
            'expected'=>['recurrence'=>'f3_google_minute','interval'=>60,'args'=>[]], 'state'=>'unknown','reason_code'=>$intent['error_code'],
            'read_success'=>$read['success']&&$intent['error_code']===null,'present'=>null,'next_run'=>null,'occurrences'=>0,'observed_at'=>time(),
            'repair_allowed'=>!$blocked&&!(null !== State::guard())&&$intent['desired_state']==='active',
            'repair_blocked_by'=>$blocked?$blocked->get_error_code():((null !== State::guard())?'f3_google_storage_unavailable':($intent['desired_state']==='inactive'?'executor_inactive':null))];
        if (!$read['success']) {
            $out['reason_code']=$read['code'];
            return $out;
        }
        $rows=[];
        $valid=true;
        foreach ($read['cron'] as $at=>$hooks) {
            if (!is_array($hooks)||!array_key_exists(Jobs::HOOK,$hooks)) continue;
            if (!is_array($hooks[Jobs::HOOK])||!$hooks[Jobs::HOOK]) {
                $valid=false;
                continue;
            }
            foreach($hooks[Jobs::HOOK] as $key=>$row) {
                $rows[]=['at'=>$at,'value'=>$row];
                if (!is_numeric($at)||(int)$at<=0||(string)(int)$at!==(string)$at||!is_array($row)||($row['args']??null)!==[]||($row['schedule']??null)!=='f3_google_minute'||($row['interval']??null)!==60||$key!==md5(serialize([]))) $valid=false;
            }
        }
        $out['occurrences']=count($rows);
        $out['present']=(bool)$rows;
        if ($intent['desired_state']==='unknown') return $out;
        if ($intent['desired_state']==='inactive') {
            $out['state']=!$rows&&$valid?'inactive':'invalid';
            $out['reason_code']=$out['state']==='inactive'?null:'f3_google_executor_event_unexpected';
            return $out;
        }
        if (!$valid||count($rows)>1) {
            $out['state']='invalid';
            $out['reason_code']=count($rows)>1?'f3_google_executor_event_multiple':'f3_google_executor_event_invalid';
            return $out;
        }
        if (!$rows) {
            $out['state']='missing';
            $out['reason_code']='f3_google_executor_event_missing';
            return $out;
        }
        $out['state']='present';
        $out['reason_code']=null;
        $out['next_run']=(int)$rows[0]['at'];
        return $out;
    }
    public static function schema(): array {
        return ['type'=>'object','properties'=>[
                'hook'=>['type'=>'string','enum'=>[Jobs::HOOK]],
                'desired_state'=>['type'=>'string','enum'=>['active','inactive','unknown']],
                'generation'=>['type'=>['string','null']], 'intent_origin'=>['type'=>'string'],
                'state'=>['type'=>'string','enum'=>['present','missing','invalid','inactive','unknown']],
                'reason_code'=>['type'=>['string','null']], 'read_success'=>['type'=>'boolean'],
                'present'=>['type'=>['boolean','null']], 'next_run'=>['type'=>['integer','null']],
                'occurrences'=>['type'=>'integer'],'observed_at'=>['type'=>'integer'],
                'repair_allowed'=>['type'=>'boolean'],'repair_blocked_by'=>['type'=>['string','null']],
                'expected'=>['type'=>'object','properties'=>['recurrence'=>['type'=>'string'],'interval'=>['type'=>'integer'],'args'=>['type'=>'array']]],
            ]];
    }
    public static function ensure(string $origin='executor'): array {
        return Recovery::run(static fn()=>self::locked($origin,null));
    }
    public static function activate(): array {
        return Recovery::run(static fn()=>self::lifecycle(true));
    }
    /** Teardown records an inactive generation even under a recovery pause. */
    public static function deactivate(): array {
        return self::lifecycle(false);
    }
    /** Publish the lifecycle fence before waiting for an in-flight scheduler. */
    private static function lifecycle(bool $active): array {
        $before=self::intent();
        if($before['desired_state']==='unknown') return ['success'=>false,'state'=>'unknown','changed'=>false,'error_code'=>$before['error_code']];
        $origin=$active?'activation':'deactivation';
        $intent=['desired_state'=>$active?'active':'inactive','generation'=>bin2hex(random_bytes(16)),'origin'=>$origin,'at'=>time()];
        $saved=Options::set(self::OPTION,$intent);
        if(!$saved['success']) return ['success'=>false,'state'=>'failed','changed'=>false,'error_code'=>$saved['error_code']??'f3_google_executor_intent_persistence'];
        self::$generations[self::site()]=$intent['generation'];
        return self::locked($origin,$active,$intent['generation']);
    }
    private static function locked(string $origin,?bool $active,?string $expectedGeneration=null): array {
        $lock=Lock::acquire_result('executor-schedule',30);
        if (!$lock['success']) return ['success'=>false,'state'=>CronHistory::busy($lock)?'yielded':'failed','changed'=>false,'error_code'=>$lock['code'],'retryable'=>CronHistory::busy($lock)];
        try {
            $before=self::status();
            if ($active===null && (null !== State::guard())) return ['success'=>false,'state'=>'blocked','changed'=>false,'error_code'=>'f3_google_storage_unavailable','before'=>$before];
            if($active===null&&in_array($before['state'],['unknown','invalid'],true)) return ['success'=>false,'state'=>$before['state'],'changed'=>false,'error_code'=>$before['reason_code'],'before'=>$before];
            $intent=self::intent();
            if($expectedGeneration!==null&&$expectedGeneration!==$intent['generation']) return ['success'=>false,'state'=>'blocked','changed'=>false,'error_code'=>'f3_google_executor_intent_changed','before'=>$before];
            $captured=self::$generations[self::site()]??null;
            if ($active===null && ($intent['desired_state']!=='active'||(array_key_exists(self::site(),self::$generations)&&$captured!==$intent['generation']))) return ['success'=>false,'state'=>'blocked','changed'=>false,'error_code'=>'f3_google_executor_intent_changed','before'=>$before];
            if ($intent['generation']===null) {
                if ($intent['desired_state']==='unknown') return ['success'=>false,'state'=>'unknown','changed'=>false,'error_code'=>$intent['error_code']];
                $intent=['desired_state'=>$active===false?'inactive':'active','generation'=>bin2hex(random_bytes(16)),'origin'=>$origin,'at'=>time()];
                $saved=Options::insert_exclusive_result(self::OPTION,$intent);
                if (!$saved['success']) return ['success'=>false,'state'=>'failed','changed'=>false,'error_code'=>$saved['error_code']??$saved['code']??'f3_google_executor_intent_persistence'];
                if(self::intent()['generation']!==$intent['generation']) return ['success'=>false,'state'=>'blocked','changed'=>false,'error_code'=>'f3_google_executor_intent_changed'];
                self::$generations[self::site()]=$intent['generation'];
            }
            $current=self::status();
            if ($active===false) {
                $native=wp_clear_scheduled_hook(Jobs::HOOK,[],true);
                $after=self::status();
                return ['success'=>$after['state']==='inactive','state'=>$after['state']==='inactive'?'confirmed':'unconfirmed','changed'=>$before['present']===true,'before'=>$before,'after'=>$after,'original_code'=>is_wp_error($native)?$native->get_error_code():null];
            }
            if ($current['state']==='present') return ['success'=>true,'state'=>'confirmed','changed'=>false,'before'=>$before,'after'=>$current];
            if ($current['state']!=='missing') return ['success'=>false,'state'=>$current['state'],'changed'=>false,'error_code'=>$current['reason_code'],'before'=>$before,'after'=>$current];
            if (!Lock::owned($lock['lock'])||self::intent()['generation']!==$intent['generation']) return ['success'=>false,'state'=>'blocked','changed'=>false,'error_code'=>'f3_google_executor_intent_changed'];
            $at=time()+60;
            $r=Scheduling::schedule(Jobs::HOOK,$at,'f3_google_minute');
            $now=self::intent();
            if($now['generation']!==$intent['generation']) {
                // Teardown can invalidate us while WordPress is inside a scheduling filter.
                // Remove only this attempted occurrence, and only while intention is inactive.
                $cleanup=null;
                if($now['desired_state']==='inactive') {
                    $removed=wp_unschedule_event($at,Jobs::HOOK,[],true);
                    $cleanup=['success'=>self::status()['state']==='inactive','native_error'=>is_wp_error($removed)?$removed->get_error_code():null];
                }
                return ['success'=>false,'state'=>'blocked','changed'=>false,'attempted'=>true,'error_code'=>'f3_google_executor_intent_changed','cleanup'=>$cleanup,'after'=>self::status(),'scheduling'=>$r];
            }
            $after=self::status();
            return ['success'=>$after['state']==='present','state'=>$after['state']==='present'?'confirmed':'unconfirmed','changed'=>$after['state']==='present','attempted'=>true,'origin'=>$origin,'before'=>$before,'after'=>$after,'scheduling'=>$r,'error_code'=>$after['reason_code']];
        }
        finally {
            Lock::release($lock['lock']);
        }
    }
}
