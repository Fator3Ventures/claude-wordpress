<?php
/** Bounded, read-only work evidence for an observation interval; never a job executor. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Options,Lock,Storage\Repository
};
if (!defined('ABSPATH')) {
    exit;
}
final class CronCoverage {
    public static function snapshot(string $cid): ?array {
        global $wpdb;
        // Sequence high-water also detects insert+delete between the two snapshots.
        $high=self::high_water();
        if ($high===null) return null;
        $rows=$wpdb->get_results($wpdb->prepare('SELECT sequence,generation,state,due_at,digest,kind FROM '.Repository::table()." WHERE connection_id=%s AND kind IN ('job','schedule') ORDER BY sequence LIMIT 10001",$cid),ARRAY_A);
        if ($wpdb->last_error||!is_array($rows)||count($rows)>10000) return null;
        $after=self::high_water();
        if ($after===null||$after!==$high) return null;
        $next=null;
        foreach ($rows as $r) {
            $active=$r['kind']==='schedule'?in_array($r['state'],['enabled','blocked'],true):!in_array($r['state'],['completed','cancelled','canceled'],true);
            if ($active) $next=$next===null?(int)$r['due_at']:min($next,(int)$r['due_at']);
        }
        return ['at'=>time(),'fingerprint'=>hash('sha256',wp_json_encode([$high,$rows])),'next_due_at'=>$next,'records'=>count($rows),'basis'=>'stable_work_metadata_and_sequence'];
    }
    private static function high_water(): ?string {
        global $wpdb;
        // SHOW CREATE uses the engine's current next sequence, avoiding cached I_S statistics.
        $table=Repository::table();
        if (!preg_match('/^[A-Za-z0-9_]+$/D',$table)) return null;
        $r=$wpdb->get_row('SHOW CREATE TABLE `'.$table.'`',ARRAY_N);
        if ($wpdb->last_error||!is_array($r)) return null;
        return preg_match('/\bAUTO_INCREMENT=([0-9]+)/',$r[1],$m)?$m[1]:'1';
    }
    /** Called by an authorized next pass, never by status. */
    public static function reconcile(string $cid): array {
        $lock=Lock::acquire('cron-gap:'.$cid,30);
        if (!$lock) return ['success'=>true,'deferred'=>true];
        try {
            $key='f3_mcp_google_cron_gap_'.$cid;
            $s=Options::stored($key);
            if (!$s['success']) return ['success'=>false,'code'=>'f3_google_cron_gap_read','cause_code'=>'f3_google_option_read'];
            $gap=$s['value'];
            if (!is_array($gap)||isset($gap['resolved_at'])) return ['success'=>true];
            $before=$gap['work_before']??null;
            $after=self::snapshot($cid);
            if (!is_array($before)||!$after||($before['at']??PHP_INT_MAX)>($gap['at']??0)||!hash_equals((string)($before['fingerprint']??''),$after['fingerprint'])||($after['next_due_at']!==null&&$after['next_due_at']<=$after['at'])) return ['success'=>true,'unresolved'=>'interval_not_proven'];
            // No metadata/sequence changes and no due time reached anywhere in the interval.
            if (!Lock::owned($lock)) return ['success'=>false,'code'=>'f3_google_lock_lost','cause_code'=>'f3_google_lock_changed'];
            $gap['resolved_at']=time();
            $gap['resolved_by']=['basis'=>'no_due_work_in_unchanged_interval','from'=>$before['at'],'through'=>$after['at'],'fingerprint'=>$after['fingerprint']];
            $r=Options::set($key,$gap);
            return $r['success']?['success'=>true,'resolved'=>true]:['success'=>false,'code'=>'f3_google_cron_gap_write','cause_code'=>$r['error_code']??'f3_google_option_write'];
        }
        finally {
            Lock::release($lock);
        }
    }
}
