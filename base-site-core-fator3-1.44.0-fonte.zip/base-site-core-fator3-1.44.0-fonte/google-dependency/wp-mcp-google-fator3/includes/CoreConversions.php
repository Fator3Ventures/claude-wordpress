<?php
/** Optional consumer of the public Core conversion SDK. No storage or network. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if (!defined('ABSPATH')) { exit; }

final class CoreConversions {
    public const CONTRACT = 'site-conversion-purposes/1.0.0';
    private const PROVIDER = 'base-site-core-fator3';
    private const SDK = '\\F3Base_Conversoes_Contexto';

    public static function schema(string $method): array {
        static $schemas;
        if ($schemas === null) { $schemas = require __DIR__.'/Data/CoreConversions.php'; }
        return $schemas[$method] ?? [];
    }

    public static function failure(string $code): array {
        return ['ok'=>false, 'code'=>$code, 'contract'=>self::CONTRACT, 'provider'=>self::PROVIDER, 'data'=>null];
    }

    /** Consumer-local absence is deliberately separate from the producer schema. */
    public static function response_schema(): array {
        $schema = self::schema('snapshot');
        $absent = $schema['oneOf'][1];
        $absent['properties']['code']['enum'] = ['unavailable'];
        $schema['oneOf'][] = $absent;
        return $schema;
    }

    private static function call(string $method, array $input = []): array {
        try {
            $result = $method === 'capabilities'
                ? call_user_func([self::SDK, 'capabilities'])
                : call_user_func([self::SDK, 'snapshot'], $input);
            if (!is_array($result) || !ContractSchema::valid($result, self::schema($method))) {
                return self::failure('unsupported');
            }
            return $result;
        } catch (\Throwable $error) {
            return self::failure('unreadable');
        }
    }

    public static function capabilities(): array {
        if (!class_exists(self::SDK)) { return self::failure('unavailable'); }
        foreach (['capabilities', 'snapshot'] as $method) {
            if (!is_callable([self::SDK, $method])) { return self::failure('unsupported'); }
        }
        $result = self::call('capabilities');
        if ($result['ok'] && array_diff(['capabilities', 'snapshot'], $result['data']['methods'])) {
            return self::failure('unsupported');
        }
        return $result;
    }

    public static function snapshot(array $input = [], ?string &$current_revision = null): array {
        $current_revision = null;
        $request = ['contract'=>self::CONTRACT] + $input;
        if (!ContractSchema::valid($request, self::schema('snapshot-input')) || isset($input['contract'])) {
            return self::failure('invalid_input');
        }
        $capabilities = self::capabilities();
        if (!$capabilities['ok']) { return $capabilities; }
        $result = self::call('snapshot', $request);
        if (!$result['ok']) { return $result; }
        $data = $result['data'];
        // The published schema constrains each item, but cannot enforce unique purposes.
        $purposes = array_column($data['purposes'], 'purpose');
        sort($purposes);
        if ($purposes !== ['contact', 'material']) { return self::failure('unsupported'); }
        // Validate the RFC3339 observation as well as its declared string type.
        $stamp = preg_replace('/Z$/', '+00:00', $data['observed_at']);
        $stamp = preg_replace('/\.[0-9]+(?=\+00:00$)/D', '', $stamp);
        if (!preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\+00:00$/D', $stamp)) { return self::failure('unsupported'); }
        $observed = \DateTimeImmutable::createFromFormat('Y-m-d\TH:i:sP', $stamp);
        if (!$observed || $observed->format('Y-m-d\TH:i:sP') !== $stamp || $observed->getOffset() !== 0) {
            return self::failure('unsupported');
        }
        if (isset($input['expected_revision']) && !hash_equals($input['expected_revision'], $data['revision'])) {
            // Only the already validated snapshot can supply this evidence.
            $current_revision = $data['revision'];
            return self::failure('revision_conflict');
        }
        return $result;
    }

    /** Reject a mixed snapshot after the existing remote GTM read. */
    public static function revalidate(array $conversion, array $measurement): array {
        if (!$conversion['ok']) { return $conversion; }
        if (empty($measurement['ok']) || $conversion['data']['measurement_revision'] !== $measurement['data']['revision']) {
            return self::failure('revision_conflict');
        }
        $current = self::snapshot(['expected_revision'=>$conversion['data']['revision']]);
        if (!$current['ok']) { return $current; }
        if ($current['data']['measurement_revision'] !== $measurement['data']['revision']) {
            return self::failure('revision_conflict');
        }
        return $conversion;
    }
}
