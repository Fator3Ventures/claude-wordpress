<?php
/**
 * Connection setup and repeatable local resource bindings for deployment agents.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Setup {
    public const LEVELS = array(
        'ga' => array( 'read', 'write', 'admin' ),
        'ads' => array( 'read', 'write' ),
        'gsc' => array( 'read', 'write' ),
        'siteverification' => array( 'write' ),
        'sheets' => array( 'read', 'write' ),
        'drive' => array( 'write' ),
        'gtm' => array( 'read', 'write', 'admin' ),
    );
    public const BINDING_RULES = array(
        'gtm_container_path' => array(
            'pattern' => '~^accounts/[0-9]+/containers/[0-9]+$~D',
            'service' => 'gtm',
        ),
        'ga_property_id' => array(
            'pattern' => '~^(properties/)?[0-9]+$~D',
            'service' => 'ga',
        ),
        'ga_stream_id' => array(
            'pattern' => '~^properties/[0-9]+/dataStreams/[0-9]+$~D',
            'service' => 'ga',
        ),
        'ga_measurement_id' => array(
            'pattern' => '/^G-[A-Z0-9]+$/D',
            'service' => 'ga',
        ),
        'ads_customer_id' => array(
            'pattern' => '/^[0-9]{10}$/D',
            'service' => 'ads',
        ),
        'gsc_site_url' => array(
            'validator' => 'SearchConsole\\Api::site',
            'service' => 'gsc',
        ),
        'spreadsheet_id' => array(
            'pattern' => '/^[A-Za-z0-9_-]+$/D',
            'service' => 'sheets',
        ),
        'sitemap_url' => array(
            'validator' => 'https_url_without_credentials_or_fragment',
            'service' => 'gsc',
        ),
    );
    public static function services_schema(): array {
        $properties = array();
        foreach ( self::LEVELS as $service => $levels ) {
            $properties[ $service ] = array(
                'type' => 'string',
                'enum' => $levels,
            );
        }
        return array(
            'type' => 'object',
            'properties' => $properties,
            'additionalProperties' => false,
        );
    }
    public static function bindings_schema(): array {
        $properties = array();
        foreach ( self::BINDING_RULES as $key => $rule ) {
            $schema = array(
                'type' => 'string',
                'description' => 'Identificador existente; string vazia limpa o vínculo.',
            );
            if ( isset( $rule['pattern'] ) ) {
                $schema['anyOf'] = array(
                    array(
                        'type' => 'string',
                        'enum' => array( '' ),
                    ),
                    array(
                        'type' => 'string',
                        'pattern' => substr( $rule['pattern'], 1, strrpos( $rule['pattern'], $rule['pattern'][0] ) - 1 ),
                    ),
                );
            }
            $properties[ $key ] = $schema;
        }
        return array(
            'type' => 'object',
            'properties' => $properties,
            'additionalProperties' => false,
        );
    }
    public static function schema(): array {
        return array(
            'vincular_site_core' => array(
                'type' => 'boolean',
                'default' => false,
                'description' => 'Resolve o Measurement ID explícito do slot GA4 do Site Core, inclusive com GTM, para uma propriedade e stream existentes e únicos. Sem ID direto, informe os vínculos explicitamente.',
            ),
            'expected_revision' => array(
                'type' => 'string',
                'description' => 'Revisão consultada no contrato. Divergência recusa a gravação.',
            ),
            'dry_run' => ['type'=>'boolean','default'=>false,'description'=>'Calcula o plano sem aplicar configuração.'],
            'merge' => ['type'=>'boolean','default'=>false,'description'=>'true preserva serviços omitidos; false substitui a seleção e exige confirmação das reduções.'],
            'confirm_service_reduction' => ['type'=>'boolean','default'=>false,'description'=>'Confirma desativações/reduções do plano indicado por revisão e hash.'],
            'expected_plan_hash' => ['type'=>'string','pattern'=>'^[a-f0-9]{64}$','description'=>'Hash da prévia exata a aplicar.'],
            'services' => self::services_schema()+['description'=>'Seleção completa por padrão; merge:true altera apenas os serviços informados. Omissão preserva.'],
            'bindings' => self::bindings_schema() + array( 'description' => 'IDs existentes; campos omitidos são preservados.' ),
            'discover' => array( 'type' => 'boolean' ),
            'validate_access' => array(
                'type' => 'boolean',
                'description' => 'Padrão true: testa recursos indicados antes de salvar. false permite preparar configuração antes do consentimento.',
            ),
        );
    }
    public static function output_schema(): array {
        $state=['type'=>'object','properties'=>['enabled'=>['type'=>'boolean'],'level'=>['type'=>['string','null']],'source'=>['type'=>'string','enum'=>['inherited','explicit']]]];
        $services=['type'=>'object','properties'=>array_fill_keys(array_keys(self::LEVELS),$state)];
        $diff=['type'=>'object','properties'=>array_fill_keys(['enabled','disabled','upgraded','downgraded','unchanged'],['type'=>'array','items'=>['type'=>'string','enum'=>array_keys(self::LEVELS)]])];
        return ['type'=>'object','properties'=>[
                'success'=>['type'=>'boolean'],'message'=>['type'=>'string'],'error_code'=>['type'=>'string'],
                'configuration_contract_version'=>['type'=>'string','enum'=>['4.0.0']],
                'dry_run'=>['type'=>'boolean'],'persisted'=>['type'=>'boolean'],'changed'=>['type'=>'boolean'],'would_change'=>['type'=>'boolean'],
                'operation_outcome'=>['type'=>'string','enum'=>['applied','not_applied','partial','unknown','not_applicable']],
                'configuration_revision'=>['type'=>['string','null']],'plan_hash'=>['type'=>'string'],
                'services_before'=>$services,'services_after'=>$services,'service_changes'=>$diff,
                'services_stored_before'=>['type'=>['object','null']],'services_stored_after'=>['type'=>['object','null']],
                'services_mode'=>['type'=>'string','enum'=>['preserve','merge','replace']],
                'confirmation_required'=>['type'=>'boolean'],
                'confirmation'=>['type'=>'object','properties'=>['required'=>['type'=>'boolean'],'expected_revision'=>['type'=>'string'],'expected_plan_hash'=>['type'=>'string'],'confirm_service_reduction'=>['type'=>'boolean']]],
                'changes'=>['type'=>'array','items'=>['type'=>'object']], 'values'=>['type'=>'object'],
            ]];
    }
    public static function plan( array $input, ?array $resolvedCore = null ): array {
        $revision=Settings::revision();
        if(is_wp_error($revision)) return Response::fail($revision,['persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied']);
        if(isset($input['expected_revision'])&&$input['expected_revision']!==$revision) return Settings::conflict();
        $selection=ServiceSelection::compile($input);
        if(is_wp_error($selection)) return Response::fail($selection,['persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied']);
        $storedBindings=Options::stored(Options::storage_name(Connections::BINDINGS));
        if(!$storedBindings['success']||($storedBindings['exists']&&!is_array($storedBindings['value']))) return Response::fail(new \WP_Error('f3_google_option_read','Não foi possível ler os vínculos persistidos.'),['persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied']);
        $currentBindings=$storedBindings['exists']?$storedBindings['value']:[];
        $values=$selection['values'];
        if(array_key_exists('bindings',$input)&&!is_array($input['bindings']))return self::invalid('bindings deve ser objeto.');
        $core=null;
        if ( ! empty( $input['vincular_site_core'] ) ) {
            $core = $resolvedCore ?? CoreBinding::resolve();
            if ( is_wp_error( $core ) ) {
                return Response::fail( $core, ['persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied'] );
            }
            foreach ( $core['bindings'] as $key => $value ) {
                if ( isset( $input['bindings'][ $key ] ) && preg_replace( '~^properties/~', '', $input['bindings'][ $key ] ) !== preg_replace( '~^properties/~', '', $value ) ) {
                    return self::invalid( 'Vínculo explícito diverge do Site Core: ' . $key );
                }
            }
            $input['bindings'] = array_merge( $input['bindings'] ?? array(), $core['bindings'] );
        }
        if ( isset( $input['bindings'] ) ) {
            if ( ! is_array( $input['bindings'] ) ) {
                return self::invalid( 'bindings deve ser objeto.' );
            }
            $bindings = array();
            foreach ( $input['bindings'] as $key => $value ) {
                if ( ! is_string( $value ) || ! array_key_exists( $key, self::BINDING_RULES ) ) {
                    return self::invalid( 'Vínculo inválido: ' . (string) $key );
                }
                $value = trim( $value );
                if ( '' !== $value ) {
                    if ( isset( self::BINDING_RULES[ $key ]['pattern'] ) && ! preg_match( self::BINDING_RULES[ $key ]['pattern'], $value ) ) {
                        return self::invalid( $key . ' inválido.' );
                    }
                    if ( 'gsc_site_url' === $key && is_wp_error( SearchConsole\Api::site( $value ) ) ) {
                        return self::invalid( 'gsc_site_url inválido.' );
                    }
                    if ( 'sitemap_url' === $key && ( ! filter_var( $value, FILTER_VALIDATE_URL ) || 'https' !== wp_parse_url( $value, PHP_URL_SCHEME ) || wp_parse_url( $value, PHP_URL_USER ) || wp_parse_url( $value, PHP_URL_FRAGMENT ) ) ) {
                        return self::invalid( 'sitemap_url exige HTTPS sem credenciais ou fragmento.' );
                    }
                }
                $bindings[ $key ] = $value;
            }
            $values[ Connections::BINDINGS ] = array_merge( $currentBindings, $bindings );
            if ( isset( $bindings['ga_property_id'] ) ) {
                $values[ Options::GA_DEFAULT_PROPERTY ] = preg_replace( '~^properties/~', '', $bindings['ga_property_id'] );
            }
        }
        $effective = $values[ Connections::BINDINGS ] ?? $currentBindings;
        if ( ! empty( $effective['ga_stream_id'] ) && ! empty( $effective['ga_property_id'] ) && 0 !== strpos( $effective['ga_stream_id'], 'properties/' . preg_replace( '~^properties/~', '', $effective['ga_property_id'] ) . '/dataStreams/' ) ) {
            return self::invalid( 'Stream e propriedade GA4 devem pertencer ao mesmo recurso.' );
        }
        $changes = array();
        foreach ( $values as $key => $value ) {
            $stored=Options::stored(Options::storage_name($key));
            if(!$stored['success']) return Response::fail(new \WP_Error('f3_google_option_read','Não foi possível ler a configuração persistida.'),['persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied']);
            $old=$stored['exists']?$stored['value']:null;
            $changes[] = array(
                'option' => $key,
                'before' => $old,
                'after' => $value,
                'changed' => $old !== $value && !(is_array($old)&&is_array($value)&&ServiceSelection::hash($old)===ServiceSelection::hash($value)),
            );
        }
        $out = Response::ok(
            array(
                'connection_id' => Connections::id(),
                'changes' => $changes,
                'values' => $values,
                'redirect_uri' => Auth\OAuthFlow::redirect_uri(),
                'resource_creation' => false,
                'access_validated' => false,
                'core_source' => $core['source'] ?? null,
            ),
            'Plano de configuração local; usa IDs de recursos existentes.'
        );
        if ( ! empty( $input['discover'] ) ) {
            $out['discovery'] = Unified\Query::accounts(
                array(
                    'connector' => 'all',
                    'refresh' => true,
                )
            );
        }
        if(Settings::revision()!==$revision) return Settings::conflict();
        $out=array_merge($out,array_diff_key($selection,['values'=>true]),[
                'configuration_contract_version'=>'4.0.0','configuration_revision'=>$revision,'dry_run'=>true,'persisted'=>false,'changed'=>false,
                'would_change'=>(bool)array_filter($changes,static fn($c)=>$c['changed']), 'operation_outcome'=>'not_applied',
            ]);
        $out['plan_hash']=ServiceSelection::hash(['contract'=>'4.0.0','site'=>home_url(),'blog'=>function_exists('get_current_blog_id')?get_current_blog_id():1,
                'actor'=>get_current_user_id(),'connection'=>Connections::id(),'revision'=>$revision,'values'=>$values,'selection'=>$selection,
                'core_source'=>$out['core_source'],'validate_access'=>$input['validate_access']??true]);
        $out['confirmation']=['required'=>$out['confirmation_required'],'expected_revision'=>$revision,'expected_plan_hash'=>$out['plan_hash'],'confirm_service_reduction'=>$out['confirmation_required']];
        return $out;
    }
    public static function apply( array $input ): array {
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) {
            return Response::fail( $revision, ['persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied'] );
        }
        if ( isset( $input['expected_revision'] ) && $input['expected_revision'] !== $revision ) {
            return Settings::conflict();
        }
        $plan = self::plan( $input );
        if ( ! $plan['success'] ) {
            return $plan;
        }
        if(!empty($input['dry_run'])) return $plan;
        if(isset($input['expected_plan_hash'])&&!hash_equals($plan['plan_hash'],(string)$input['expected_plan_hash'])) return Settings::conflict();
        if($plan['confirmation_required'] && (empty($input['confirm_service_reduction'])||!isset($input['expected_revision'],$input['expected_plan_hash']))) {
            return Response::fail(new \WP_Error('f3_google_service_reduction_confirmation_required','Confirme as reduções usando a revisão e o hash desta prévia.'),array_merge($plan,['dry_run'=>false,'success'=>false,'operation_outcome'=>'not_applied']));
        }
        $bindings = $plan['values'][ Connections::BINDINGS ] ?? array();
        $probe = null;
        if ( ! empty( $bindings ) && ( $input['validate_access'] ?? true ) ) {
            $services = array();
            foreach ( array(
                    'ga_property_id' => 'ga',
                    'ads_customer_id' => 'ads',
                    'gsc_site_url' => 'gsc',
                    'spreadsheet_id' => 'sheets',
                ) as $key => $service ) {
                if ( ! empty( $bindings[ $key ] ) ) {
                    $services[] = $service;
                }
            }
            if ( $services ) {
                $probe = Connections::preview(
                    $plan['values'],
                    static fn () => Preflight::run(
                        array(
                            'bindings' => $bindings,
                            'services' => $services,
                        )
                    )
                );
                if ( ! $probe['success'] || ! $probe['all_checks_passed'] ) {
                    return Response::fail( new \WP_Error( 'f3_google_setup_access', 'Acesso aos recursos não confirmado; configuração não aplicada.' ), array( 'preflight' => $probe, 'persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied' ) );
                }
            }
        }
        $guard=null;
        $precondition=static function() use($input,$plan) {
            $resolved=$plan['core_source']===null?null:['source'=>$plan['core_source'],'bindings'=>array_intersect_key($plan['values'][Connections::BINDINGS]??[],array_flip(['ga_property_id','ga_stream_id','ga_measurement_id']))];
            $fresh=self::plan(array_replace($input,['discover'=>false]),$resolved);
            if(empty($fresh['success'])) return new \WP_Error($fresh['error_code']??'f3_google_configuration_conflict','Não foi possível revalidar o plano.');
            return hash_equals($plan['plan_hash'],$fresh['plan_hash'])?null:new \WP_Error('f3_google_configuration_conflict','O plano mudou antes da gravação.');
        };
        if ( null !== $plan['core_source'] ) {
            $source_revision = $plan['core_source']['revision'];
            $guard = static function () use ( $source_revision ) {
                $source = CoreBinding::source();
                return is_wp_error( $source ) ? $source : ( $source_revision === $source['revision'] ? null : new \WP_Error( 'f3_google_core_changed', 'O Site Core mudou antes da gravação dos vínculos.' ) );
            };
        }
        $saved = Settings::save( $plan['values'], array(), array(), $revision, $guard, $precondition );
        if ( ! $saved['success'] ) {
            return $saved;
        }
        return Response::ok(
            array(
                'configuration_contract_version'=>'4.0.0',
                'dry_run' => false,
                'operation_outcome' => 'applied',
                'configuration_revision' => $saved['revision']??null,
                'plan_hash' => $plan['plan_hash'],
                'services_before' => $plan['services_before'],
                'services_after' => $plan['services_after'],
                'services_stored_before' => $plan['services_stored_before'],
                'services_stored_after' => $plan['services_stored_after'],
                'service_changes' => $plan['service_changes'],
                'services_mode' => $plan['services_mode'],
                'confirmation_required' => false,
                'persisted' => true,
                'changed' => $saved['changed'] ?? true,
                'revision' => $saved['revision'] ?? null,
                'changes' => $plan['changes'],
                'access_validated' => null !== $probe && $probe['all_checks_passed'],
                'preflight' => $probe,
                'core_source' => $plan['core_source'],
                'scopes_requested' => Auth\Credentials::scopes_for( 'any' ),
            ),
            'oauth' === Options::auth_mode() ? 'Configuração persistida. Novos escopos exigem autorização da conta Google.' : 'Configuração persistida. Confira os acessos da Service Account aos recursos selecionados.'
        );
    }
    private static function invalid( string $message ): array {
        return Response::fail( new \WP_Error( 'f3_google_setup_input', $message ), ['persisted'=>false,'changed'=>false,'operation_outcome'=>'not_applied'] );
    }
    public static function register(): void {
        foreach ( array(
                'plan-configuration' => 'plan',
                'configure' => 'apply',
            ) as $route => $method ) {
            Ability::register(
                'google/' . $route,
                'any',
                array(
                    'label' => 'Google: ' . $route,
                    'description' => 'Planeja ou aplica configuração local verificada com serviços e recursos existentes; não cria propriedades Google.',
                    'mode' => 'apply' === $method ? 'write' : 'read',
                    'meta'=>['fator3'=>['configuration_contract_version'=>'4.0.0','local_confirmation'=>'service_reduction_revision_plan_hash']],
                    'input_schema' => array( 'properties' => self::schema() ),
                    'output_schema' => self::output_schema(),
                    'callback' => array( self::class, $method ),
                )
            );
        }
        Ability::register(
            'google/preflight',
            'any',
            array(
                'label' => 'Google: testar acessos',
                'description' => 'Leituras reais por serviço e recurso. Distingue passed, failed, skipped e not_configured.',
                'input_schema' => array(
                    'properties' => array(
                        'bindings' => array( 'type' => 'object' ),
                        'services' => array(
                            'type' => 'array',
                            'items' => array(
                                'type' => 'string',
                                'enum' => array_keys( self::LEVELS ),
                            ),
                        ),
                    ),
                ),
                'callback' => static function ( array $input ): array {
            $r = Preflight::run( $input );
            return $r['success'] ? Response::ok( $r ) : Response::fail( new \WP_Error( 'f3_google_preflight_failed', 'Há acessos não confirmados.' ), $r );
                },
            )
        );
        Ability::register(
            'google/list-connections',
            'any',
            array(
                'label' => 'Google: conexões',
                'description' => 'Lista conexões e vínculos sem segredos.',
                'callback' => static function (): array {
            $out = array();
            foreach ( Connections::registry() as $id => $meta ) {
                $out[] = Connections::run(
                    $id,
                    static fn () => array(
                        'connection_id' => $id,
                        'label' => $meta['label'],
                        'configured' => Auth\Credentials::is_configured(),
                        'services' => Options::get( Connections::SERVICES, null ),
                        'bindings' => Options::get( Connections::BINDINGS, array() ),
                    )
                );
            }
            return Response::ok( array( 'connections' => $out ) );
                },
            )
        );
        Ability::register(
            'google/create-connection',
            'any',
            array(
                'label' => 'Google: criar conexão',
                'description' => 'Cria uma conexão local vazia para configuração no painel.',
                'mode' => 'write',
                'input_schema' => array(
                    'properties' => array(
                        'id' => array( 'type' => 'string' ),
                        'label' => array( 'type' => 'string' ),
                    ),
                    'required' => array( 'id', 'label' ),
                ),
                'callback' => static fn ( array $input ) => Connections::create( (string) ( $input['id'] ?? '' ), (string) ( $input['label'] ?? '' ) ),
            )
        );
        Ability::register(
            'google/disconnect',
            'any',
            array(
                'label' => 'Google: desconectar OAuth',
                'description' => 'Remove tokens locais mantendo o cliente. revoke=true revoga também a autorização do usuário no projeto Google, afetando outros sites.',
                'mode' => 'write',
                'input_schema' => array(
                    'properties' => array(
                        'revoke' => array(
                            'type' => 'boolean',
                            'default' => false,
                        ),
                    ),
                ),
                'callback' => static fn ( array $input ) => Auth\OAuthFlow::disconnect( ! empty( $input['revoke'] ) ),
            )
        );
    }
}
