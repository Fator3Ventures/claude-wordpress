<?php
/**
 * Channel SDK integration.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Channel {
    public const PROVIDER = 'wp-mcp-google-fator3';
    public static function init(): void {
        add_action(
            'f3_mcp_register_providers',
            static function ( $version = 1 ): void {
            if ( 1 === $version && class_exists( '\\Fator3\\McpFiles\\ExtensionContract' ) ) {
                \Fator3\McpFiles\ExtensionContract::register( self::PROVIDER, F3_MCP_GOOGLE_VERSION, array( 'ga/', 'ads/', 'google/', 'gsc/', 'siteverification/', 'gtm/' ) );
            }
            }
        );
    }
    /** Stable authenticated grant identity; no token bytes or mutable last-seen timestamps. */
    public static function principal(): ?array {
        $sdk='\\Fator3\\McpFiles\\ConnectionContext';
        if(!is_callable([$sdk,'get']))return null;
        $c=$sdk::get();
        if(!$c||!preg_match('/^(app:|grant:)/',(string)($c['connection_id']??'')))return null;
        $projection=array_intersect_key($c,array_flip(['user_id','connection_id','profile','policy_version','status','expires','abilities']));
        ksort($projection);
        return $projection;
    }
    public static function validate_principal(?array $principal): ?\WP_Error {
        if($principal===null)return null;
        $sdk='\\Fator3\\McpFiles\\ConnectionContext';
        if(!is_callable([$sdk,'policy'])||!is_callable([$sdk,'credential_active']))return new \WP_Error('f3_google_channel_unavailable','A concessão MCP que autorizou a coleta não pode ser revalidada.');
        $id=$principal['connection_id'];
        $user=(int)$principal['user_id'];
        $policy=$sdk::policy($id);
        if(!$sdk::credential_active($id,$user)||!is_array($policy)||($policy['_storage']['status']??'')!=='active'||!empty($policy['expires'])&&$policy['expires']<=time())return new \WP_Error('f3_google_channel_revoked','Concessão MCP revogada ou expirada.');
        $current=array_intersect_key($policy,array_flip(['user_id','connection_id','profile','policy_version','status','expires','abilities']));
        ksort($current);
        ksort($principal);
        return $current===$principal?null:new \WP_Error('f3_google_channel_changed','A política da concessão MCP mudou.');
    }
    /** The final ability is authorized independently from its executor. */
    public static function maintenance(): bool {
        return class_exists( '\\Fator3\\McpFiles\\ConnectionContext' ) && ( \Fator3\McpFiles\ConnectionContext::get()['profile'] ?? '' ) === 'maintenance';
    }
    public static function authorize( string $name, array $input, bool $read ) {
        if ( class_exists( '\\Fator3\\McpFiles\\AuthorizationPolicy' ) ) {
            return \Fator3\McpFiles\AuthorizationPolicy::check( $name, $input, $read );
        }
        return true;
    }
}
