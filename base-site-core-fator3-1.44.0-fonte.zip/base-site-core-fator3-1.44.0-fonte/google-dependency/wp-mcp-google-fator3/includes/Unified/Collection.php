<?php
/** Bounded, resumable collection. Each checkpoint commits rows and cursor together. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Unified;
use Fator3\McpGoogle\{
    Cache, Channel, Connections, ContractSchema, Gate, Lock, Options, Policy, Response
};
use Fator3\McpGoogle\Automation\{
    Context, Execution, FrozenInput
};
if (!defined( 'ABSPATH' )) {
    exit;
}
final class Collection {
    public const TTL=3600;
    private static ?int $response_bytes=null;
    public static function response_limit(): ?int {
        return self::$response_bytes;
    }
    public static function schema(): array {
        return ['type'=>'object','description'=>'Coleta de uma página ou completa com orçamentos explícitos e continuação autorizada.','additionalProperties'=>false,'properties'=>[
                'mode'=>['type'=>'string','enum'=>['page','complete'],'default'=>'page'],
                'page_size'=>['type'=>'integer','minimum'=>1,'maximum'=>25000],
                'max_rows'=>['type'=>'integer','minimum'=>1,'maximum'=>100000,'default'=>50000],
                'max_bytes'=>['type'=>'integer','minimum'=>1024,'maximum'=>8388608,'default'=>8388608],
                'max_pages'=>['type'=>'integer','minimum'=>1,'maximum'=>500,'default'=>100],
                'pages_per_pass'=>['type'=>'integer','minimum'=>1,'maximum'=>50,'default'=>10],
                'seconds_per_pass'=>['type'=>'integer','minimum'=>3,'maximum'=>20,'default'=>20],
                'cursor'=>['type'=>'string','pattern'=>'^[a-f0-9]{48}$','description'=>'Continuação opaca por ator/conexão/plano; expira em uma hora. Reenvie a consulta original.'],
            ]];
    }
    private static function key(string $cursor): string {
        return 'f3_mcp_google_collection_'.$cursor;
    }
    private static function hash(array $input): string {
        unset($input['collection']['cursor']);
        return FrozenInput::hash($input);
    }
    public static function run(array $input): array {
        if(!ContractSchema::valid($input['collection']??[],self::schema()))return Response::fail(new \WP_Error('f3_google_collection_input','Limites da coleta inválidos.'));
        $cursor=$input['collection']['cursor']??bin2hex(random_bytes(24));
        if(!preg_match('/^[a-f0-9]{48}$/D',$cursor))return Response::fail(new \WP_Error('f3_google_collection_cursor','Cursor inválido.'));
        $lock=Lock::acquire('collection:'.$cursor,45);
        if(!$lock)return Response::fail(new \WP_Error('f3_google_collection_busy','Coleta em uso. Repita a continuação.'));
        try {
            $state=isset($input['collection']['cursor'])?Cache::get(self::key($cursor)):null;
            if(isset($input['collection']['cursor'])&&!is_array($state))return Response::fail(new \WP_Error('f3_google_collection_expired','Continuação expirada ou indisponível. Inicie uma nova coleta.'));
            $save=static function(array $next)use($cursor): bool {
                $ttl=max(1,$next['expires_at']-time());
                $r=Cache::set(self::key($cursor),$next,$ttl);
                return $r===true;
            };
            $result=self::collect($input,$state,$save);
            if(isset($result['collection']))$result['collection']['continuation']=!empty($result['collection']['resumable'])?$cursor:null;
            return $result;
        }
        finally {
            Lock::release($lock);
        }
    }
    /** Worker supplies its fenced job checkpoint. No new job is created by query. */
    public static function collect(array $input,?array $state,callable $save,bool $job=false): array {
        $config=$input['collection']??[];
        if(!ContractSchema::valid($config,self::schema()))return Response::fail(new \WP_Error('f3_google_collection_input','Limites da coleta inválidos.'));
        if($state===null) {
            $state=self::prepare($input,$job);
            if(is_wp_error($state))return Response::fail($state);
            if(strlen((string)wp_json_encode($state))>$state['limits']['max_bytes'])return self::result($state,'byte_budget',false);
            if(!$save($state))return self::persistence();
        }
        if($state['request_hash']!==self::hash($input)||(!$job&&$state['expires_at']<=time()))return Response::fail(new \WP_Error('f3_google_collection_changed','Consulta alterada ou continuação expirada.'));
        $guard=self::guard($state,$job);
        if($guard)return Response::fail($guard);
        $seconds=$config['seconds_per_pass']??20;
        return Execution::run(static function()use(&$state,$save,$job,$config): array {
            $per_pass=$config['pages_per_pass']??10;
            $reason=null;
            $resumable=false;
            for($pass=0;$pass<$per_pass;++$pass) {
                $pending=null;
                foreach($state['slices'] as $i=>$slice)if(in_array($slice['status'],['pending','partial'],true)){
                    $pending=$i;
                    break;
                }
                if($pending===null)break;
                if($state['pages']>=$state['limits']['max_pages']){
                    $reason='page_budget';
                    break;
                }
                if($state['rows_native']>=$state['limits']['max_rows']){
                    $reason='row_budget';
                    break;
                }
                if(Execution::remaining()<1){
                    $reason='time_budget';
                    $resumable=true;
                    break;
                }
                if($guard=self::guard($state,$job))return Response::fail($guard);
                $slice=$state['slices'][$pending];
                $one=$state['input'];
                unset($one['collection'],$one['compare_date_range'],$one['startRow'],$one['start_row']);
                $one['accounts']=[$slice['account_id']];
                $one['date_range']=$slice['dates'];
                $one['limit']=min($state['limits']['page_size'],$state['limits']['max_rows']-$state['rows_native']);
                $one['offset']=$slice['offset'];
                $prior_limit=self::$response_bytes;
                self::$response_bytes=$state['limits']['max_bytes'];
                try {
                    $response=Quality::page(Query::page($one),$one);
                }
                finally{
                    self::$response_bytes=$prior_limit;
                }
                if($guard=self::guard($state,$job))return Response::fail($guard);
                $native=$response['quality']['pages'][0]??null;
                if(!$native) {
                    $native=Quality::native($state['connector'],$slice['account_id'],[$slice['range_name']=>$slice['dates']],$slice['offset'],$one['limit'],new \WP_Error($response['error_code']??'f3_google_collection_response',$response['message']??'Resposta inválida.'));
                }
                $next=$state;
                ++$next['pages'];
                $native['slice']=$pending;
                $native['ranges']=[$slice['range_name']=>$slice['dates']];
                $next['evidence'][]=$native;
                $native_count=$native['rows_received'];
                if($native['status']!=='ok'||empty($response['success'])) {
                    $details=$native['error_details']??[];
                    $retryable=!empty($response['retryable'])||!empty($details['retryable'])||($details['status']??$details['http_status']??0)===429;
                    $next['slices'][$pending]['error_code']=$native['error_code']??$response['error_code']??'f3_google_collection_failed';
                    $next['slices'][$pending]['status']=$retryable?'partial':'failed';
                    if($retryable){
                        $reason='source_retry';
                        $resumable=true;
                    }
                }
                else {
                    $previous=null;
                    foreach(array_reverse($state['evidence']) as $seen)if(($seen['slice']??null)===$pending&&$seen['status']==='ok'){
                        $previous=$seen;
                        break;
                    }
                    if($previous)foreach(['metadata','timezone','currency','response_aggregation_type','data_state'] as $field)if(($previous[$field]??null)!==($native[$field]??null))$next['changes'][]=['slice'=>$pending,'field'=>$field,'previous'=>$previous[$field]??null,'current'=>$native[$field]??null];
                    $old_total=$slice['total_rows'];
                    if($old_total!==null&&$native['total_rows']!==null&&$old_total!==$native['total_rows'])$next['changes'][]=['slice'=>$pending,'field'=>'total_rows','previous'=>$old_total,'current'=>$native['total_rows']];
                    $next['slices'][$pending]['total_rows']=$native['total_rows'];
                    $next['slices'][$pending]['error_code']=null;
                    if(!$next['columns'])$next['columns']=self::columns($response['columns'],$next);
                    foreach($response['rows']??[] as $row)$next['rows'][]=array_merge(self::prefix($slice,$next),$row);
                    $next['rows_native']+=$native_count;
                    $next['slices'][$pending]['rows_native']+=$native_count;
                    $next['slices'][$pending]['rows_emitted']+=count($response['rows']??[]);
                    $next['slices'][$pending]['offset']=$slice['offset']+$native_count;
                    $next['slices'][$pending]['status']=$native['next_offset']===null?'complete':'partial';
                    if($native['next_offset']!==null&&$native_count===0){
                        $next['slices'][$pending]['status']='failed';
                        $next['slices'][$pending]['error_code']='f3_google_collection_no_progress';
                    }
                    foreach($response['warnings']??[] as $warning)if(!in_array($warning,$next['warnings'],true))$next['warnings'][]=$warning;
                }
                $bytes=strlen((string)wp_json_encode($next));
                if($bytes>$state['limits']['max_bytes']){
                    $reason='byte_budget';
                    break;
                }
                $next['bytes']=$bytes;
                // One verified write contains the page and its next offset. A crash has no intermediate cursor state.
                if(!$save($next))return self::persistence();
                $state=$next;
                if($reason)break;
            }
            $pending=count(array_filter($state['slices'],static fn($s)=>in_array($s['status'],['pending','partial'],true)));
            if($pending&&$reason===null){
                $reason='pass_budget';
                $resumable=true;
            }
            return self::result($state,$reason??'end_of_api',$resumable);
            },$seconds);
    }
    private static function prepare(array $input,bool $job) {
        $connector=Query::connector($input['connector']??'');
        if(!in_array($connector,['ga4','search-console'],true))return new \WP_Error('f3_google_collection_connector','Coleta completa/calendário disponíveis para GA4 e Search Console.');
        if(($input['offset']??$input['start_row']??$input['startRow']??0)!==0)return new \WP_Error('f3_google_collection_offset','A coleta completa começa no início; use o cursor opaco para continuar.');
        $frozen=FrozenInput::resolve('query',$input);
        if(is_wp_error($frozen))return $frozen;
        $context=Context::capture();
        if(is_wp_error($context))return $context;
        $config=$input['collection']??[];
        $limits=['page_size'=>min($config['page_size']??$input['limit']??Options::max_rows(),Options::max_rows(),25000),'max_rows'=>$config['max_rows']??50000,'max_bytes'=>$config['max_bytes']??8388608,'max_pages'=>$config['max_pages']??100];
        if($limits['page_size']<1)return new \WP_Error('f3_google_collection_page_size','Tamanho de página inválido.');
        $ranges=['current'=>$frozen['date_range']];
        if(isset($frozen['compare_date_range']))$ranges['previous']=$frozen['compare_date_range'];
        $slices=[];
        if(isset($input['calendar']))foreach($input['dimensions']??[] as $dim)if(preg_match('/date|hour|week|month|quarter|year/i',$dim))return new \WP_Error('f3_google_calendar_dimension','Remova dimensões temporais: o calendário consulta cada intervalo agregado na origem.');
        foreach($frozen['accounts'] as $account)foreach($ranges as $name=>$dates) {
            $intervals=isset($input['calendar'])?Calendar::intervals($dates,$input['calendar']):[['from'=>$dates['from'],'to'=>$dates['to']]];
            if(is_wp_error($intervals))return $intervals;
            foreach($intervals as $interval)$slices[]=['account_id'=>$account,'range_name'=>$name,'dates'=>['from'=>$interval['from'],'to'=>$interval['to']],'calendar'=>isset($input['calendar'])?$interval:null,'status'=>'pending','offset'=>0,'rows_native'=>0,'rows_emitted'=>0,'total_rows'=>null,'error_code'=>null];
        }
        if(!$slices||count($slices)>200)return new \WP_Error('f3_google_collection_slices','O plano deve conter de 1 a 200 recortes.');
        return ['request_hash'=>self::hash($input),'plan_hash'=>FrozenInput::hash($frozen),'input'=>$frozen,'connector'=>$connector,'context'=>$context,'channel'=>self::channel(),
            'expires_at'=>time()+self::TTL,'limits'=>$limits,'slices'=>$slices,'columns'=>[],'rows'=>[],'pages'=>0,'rows_native'=>0,'bytes'=>0,'evidence'=>[],'changes'=>[],'warnings'=>[]];
    }
    private static function channel(): ?array {
        $sdk='\\Fator3\\McpFiles\\ConnectionContext';
        if(!is_callable([$sdk,'get']))return null;
        $c=$sdk::get();
        if(!$c)return null;
        $projection=array_intersect_key($c,array_flip(['user_id','connection_id','profile','policy_version','status','expires','abilities']));
        ksort($projection);
        return $projection;
    }
    public static function guard(array $state,bool $job=false): ?\WP_Error {
        if(($state['context']['actor']??null)!==get_current_user_id()||(!$job&&($state['channel']??null)!==self::channel()))return new \WP_Error('f3_google_collection_actor','Coleta pertence a outro ator ou concessão.');
        if($error=Context::validate($state['context']))return $error;
        if($error=\Fator3\McpGoogle\Storage\Admission::dispatch_guard())return $error;
        $service=$state['connector']==='ga4'?'ga':'gsc';
        $gate=Gate::check($service);
        if($gate!==null)return new \WP_Error($gate['error_code']??'f3_google_collection_forbidden',$gate['message']??'Acesso revogado.');
        foreach($state['slices'] as $slice)if(!Policy::permitted($service,$slice['account_id']))return new \WP_Error('f3_google_policy_denied','Recurso fora da política atual.');
        if(($state['context']['channel_principal']??null)!==null&&is_callable(['\\Fator3\\McpFiles\\ConnectionContext','get'])) {
            $allowed=Channel::authorize('google/query',$state['input'],true);
            if(is_wp_error($allowed))return $allowed;
        }
        return null;
    }
    private static function columns(array $columns,array $s): array {
        $meta=[];
        if(isset($s['input']['compare_date_range']))$meta[]='date_range_name';
        if(count($s['input']['accounts'])>1)$meta=array_merge($meta,['account_id','account_name']);
        if(isset($s['input']['calendar']))$meta=array_merge($meta,['calendar_period','period_start','period_end']);
        return array_merge(array_map(static fn($id)=>['id'=>$id,'label'=>$id,'type'=>'meta','kind'=>'string'],$meta),$columns);
    }
    private static function prefix(array $slice,array $s): array {
        $out=[];
        if(isset($s['input']['compare_date_range']))$out[]=$slice['range_name'];
        if(count($s['input']['accounts'])>1)$out=array_merge($out,[$slice['account_id'],$slice['account_id']]);
        if($slice['calendar'])$out=array_merge($out,[$slice['calendar']['label'],$slice['dates']['from'],$slice['dates']['to']]);
        return $out;
    }
    private static function result(array $s,string $reason,bool $resumable): array {
        $complete=count(array_filter($s['slices'],static fn($x)=>$x['status']!=='complete'))===0;
        $rows=$s['rows'];
        $order=$s['input']['order_by']??$s['input']['order_bys']??[];
        if(is_string($order))$order=[['field'=>$order]];
        elseif(isset($order['field']))$order=[$order];
        $index=array_flip(array_column($s['columns'],'id'));
        if($complete&&$order)usort($rows,static function($a,$b)use($order,$index){
            foreach($order as $o){
                if(is_string($o))$o=['field'=>$o];
                $i=$index[$o['field']]??null;
                if($i!==null&&($c=$a[$i]<=>$b[$i]))return ($o['direction']??'desc')==='asc'?$c:-$c;
            }
            return 0;
            });
        $failed=count(array_filter($s['slices'],static fn($x)=>$x['status']==='failed'));
        $ok=count(array_filter($s['slices'],static fn($x)=>in_array($x['status'],['complete','partial'],true)))>0;
        return ['success'=>$ok,'error_code'=>$ok?null:'f3_google_collection_failed','message'=>$complete?'Coleta concluída sobre as linhas disponibilizadas pela API.':'Coleta incompleta; consulte a cobertura.',
            'connector'=>$s['connector'],'columns'=>$s['columns'],'rows'=>$rows,'row_count'=>count($rows),'accounts'=>array_map(static fn($a)=>['account_id'=>$a,'name'=>$a],$s['input']['accounts']),
            'date_range'=>$s['input']['date_range'],'compare_date_range'=>$s['input']['compare_date_range']??null,'warnings'=>$s['warnings'],'truncated'=>!$complete,
            'collection'=>['mode'=>'complete','plan_hash'=>$s['plan_hash'],'complete'=>$complete,'pages'=>$s['pages'],'rows_native'=>$s['rows_native'],'rows_emitted'=>count($rows),'bytes'=>$s['bytes'],'stop_reason'=>$reason,'resumable'=>$resumable,'continuation'=>null,'expires_at'=>$s['expires_at'],'failed_slices'=>$failed,'limits'=>$s['limits']],
            'coverage'=>$s['slices'],'quality'=>['source'=>$s['connector'],'all_rows_guaranteed'=>$s['connector']==='search-console'?false:null,'snapshot_consistency'=>$s['changes']?'changes_observed':'not_guaranteed','changes'=>$s['changes'],'ordering_scope'=>$complete?'collected_set':'page','missing_days'=>'not_inferred','pages'=>$s['evidence'],'aggregation'=>isset($s['input']['calendar'])?'native_per_interval':'native_query','cross_account_totals'=>'not_calculated','metric_provenance'=>isset($s['input']['calendar'])&&$s['connector']==='search-console'?['ctr'=>'clicks_divided_by_impressions','formula'=>'clicks / impressions','unit'=>'fraction','source_fields'=>'clicks, impressions','undefined_reason'=>'missing_counts_or_zero_denominator_without_native_zero','zero_denominator'=>'native_zero_preserved_otherwise_null','position'=>'native_interval_aggregate']:['metrics'=>'native_interval_or_query'],'limitations'=>$s['connector']==='search-console'?['api_top_rows_only','anonymized_queries_may_be_omitted']:['metadata_omission_is_unknown']]];
    }
    private static function persistence(): array {
        return Response::fail(new \WP_Error('f3_google_collection_persistence','Não foi possível confirmar a página e seu cursor. Retome apenas a última continuação confirmada.'));
    }
}
