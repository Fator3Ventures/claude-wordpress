<?php
/** Extraction evidence is separate from transport success and source completeness. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Unified;
if (!defined( 'ABSPATH' )) {
    exit;
}
final class Quality {
    public static function native(string $connector,string $account,array $ranges,int $offset,int $limit,$response): array {
        $base=['account_id'=>$account,'ranges'=>$ranges,'offset'=>$offset,'limit'=>$limit,'observed_at'=>gmdate('c'),'api_version'=>$connector==='ga4'?'analyticsdata/v1beta':'webmasters/v3'];
        if(is_wp_error($response))return $base+['status'=>'failed','error_code'=>$response->get_error_code(),'error_details'=>$response->get_error_data(),'rows_received'=>0,'total_rows'=>null,'next_offset'=>null,'metadata'=>null,'timezone'=>null,'currency'=>null];
        $count=count($response['rows']??[]);
        $total=$connector==='ga4'&&isset($response['rowCount'])&&is_numeric($response['rowCount'])?(int)$response['rowCount']:null;
        $more=$connector==='ga4'&&$total!==null?$offset+$count<$total:$count>=$limit;
        $metadata=$response['metadata']??null;
        return $base+['status'=>'ok','rows_received'=>$count,'total_rows'=>$total,'next_offset'=>$more?$offset+$count:null,
            'metadata'=>$metadata,'timezone'=>$connector==='search-console'?'America/Los_Angeles':($metadata['timeZone']??null),
            'currency'=>$connector==='ga4'?($metadata['currencyCode']??null):null,
            'response_aggregation_type'=>$response['responseAggregationType']??null,'data_state'=>$response['dataState']??null,
            'sampling_known'=>is_array($metadata)&&array_key_exists('samplingMetadatas',$metadata),
            'thresholding_known'=>is_array($metadata)&&array_key_exists('subjectToThresholding',$metadata),
            'data_loss_known'=>is_array($metadata)&&array_key_exists('dataLossFromOtherRow',$metadata)];
    }
    public static function page(array $result,array $input): array {
        $connector=Query::connector($input['connector']??'');
        if(!in_array($connector,['ga4','search-console'],true))return $result;
        $pages=$result['native_pages']??[];
        $coverage=[];
        $complete=!empty($result['success'])&&count($pages)>0;
        $raw=0;
        foreach($pages as $page) {
            $ok=$page['status']==='ok';
            $done=$ok&&$page['offset']===0&&$page['next_offset']===null;
            $raw+=$page['rows_received'];
            $complete=$complete&&$done;
            foreach($page['ranges'] as $name=>$dates)$coverage[]=['account_id'=>$page['account_id'],'date_range_name'=>$name,'requested_dates'=>$dates,'effective_dates'=>$dates,
                'status'=>$ok?($done?'complete':'partial'):'failed','error_code'=>$page['error_code']??null,'rows_native'=>$page['rows_received'],
                'rows_scope'=>count($page['ranges'])>1?'combined_date_ranges':'this_slice','total_rows'=>$page['total_rows'],'next_offset'=>$page['next_offset']];
        }
        if(!empty($result['accounts_dropped']))$complete=false;
        $result['collection']=['mode'=>'page','complete'=>$complete,'pages'=>count($pages),'rows_native'=>$raw,'rows_emitted'=>count($result['rows']??[]),'stop_reason'=>$complete?'end_of_api':($pages?'page_limit':'query_failed'),'continuation'=>null];
        $result['coverage']=$coverage;
        $result['quality']=['source'=>$connector,'all_rows_guaranteed'=>$connector==='search-console'?false:null,'snapshot_consistency'=>'not_guaranteed','missing_days'=>'not_inferred','ordering_scope'=>'page','pages'=>$pages,
            'limitations'=>$connector==='search-console'?['api_top_rows_only','anonymized_queries_may_be_omitted']:['metadata_omission_is_unknown']];
        unset($result['native_pages']);
        return $result;
    }
    public static function schema(): array {
        $str=['type'=>'string'];
        $int=['type'=>'integer'];
        $bool=['type'=>'boolean'];
        $nullableInt=['type'=>['integer','null']];
        $dates=['type'=>'object','properties'=>['from'=>$str,'to'=>$str]];
        $page=['type'=>'object','properties'=>[
                'account_id'=>$str,'ranges'=>['type'=>'object','additionalProperties'=>$dates],'offset'=>$int,'limit'=>$int,'observed_at'=>$str,'api_version'=>$str,
                'status'=>['type'=>'string','enum'=>['ok','failed']],'rows_received'=>$int,'total_rows'=>$nullableInt,'next_offset'=>$nullableInt,
                'error_code'=>$str,'error_details'=>['type'=>['object','array','null']], 'metadata'=>['type'=>['object','null'],'description'=>'Metadados nativos da API. Ausência não comprova ausência de amostragem ou limiar.'],
                'timezone'=>['type'=>['string','null']],'currency'=>['type'=>['string','null']],'response_aggregation_type'=>['type'=>['string','null']],
                'data_state'=>['type'=>['string','null']],'requested_data_state'=>$str,'sampling_known'=>$bool,'thresholding_known'=>$bool,'data_loss_known'=>$bool,'slice'=>$int]];
        $slice=['type'=>'object','properties'=>['account_id'=>$str,'range_name'=>$str,'date_range_name'=>$str,'dates'=>$dates,'requested_dates'=>$dates,'effective_dates'=>$dates,
                'calendar'=>['type'=>['object','null'],'properties'=>['label'=>$str,'from'=>$str,'to'=>$str,'partial'=>$bool,'period'=>$str,'full_from'=>$str,'full_to'=>$str]],
                'status'=>['type'=>'string','enum'=>['pending','partial','failed','complete']],'offset'=>$int,'next_offset'=>$nullableInt,'total_rows'=>$nullableInt,'error_code'=>['type'=>['string','null']],'rows_native'=>$int,'rows_emitted'=>$int,'rows_scope'=>$str]];
        return ['type'=>'object','properties'=>[
                'success'=>$bool,'message'=>$str,'error_code'=>['type'=>['string','null']],'details'=>['type'=>['object','null']],
                'connector'=>$str,'row_count'=>$int,'rows'=>['type'=>'array','items'=>['type'=>'array','items'=>['type'=>['string','number','boolean','null']]]],
                'columns'=>['type'=>'array','items'=>['type'=>'object','properties'=>['id'=>$str,'label'=>$str,'type'=>$str,'kind'=>$str,'native'=>$str]]],
                'accounts'=>['type'=>'array','items'=>['type'=>'object','properties'=>['account_id'=>$str,'name'=>$str]]],
                'date_range'=>$dates,'compare_date_range'=>array_replace($dates,['type'=>['object','null']]),'warnings'=>['type'=>'array','items'=>$str],'truncated'=>$bool,
                'collection'=>['type'=>'object','properties'=>['mode'=>$str,'plan_hash'=>$str,'complete'=>$bool,'pages'=>$int,'rows_native'=>$int,'rows_emitted'=>$int,'bytes'=>$int,'stop_reason'=>$str,'resumable'=>$bool,'continuation'=>['type'=>['string','null']],'expires_at'=>$int,'failed_slices'=>$int,'limits'=>['type'=>'object','additionalProperties'=>$int]]],
                'coverage'=>['type'=>'array','items'=>$slice],
                'quality'=>['type'=>'object','properties'=>['source'=>$str,'all_rows_guaranteed'=>['type'=>['boolean','null']],'snapshot_consistency'=>$str,'ordering_scope'=>$str,'missing_days'=>$str,'aggregation'=>$str,'cross_account_totals'=>$str,
                        'metric_provenance'=>['type'=>'object','additionalProperties'=>$str], 'limitations'=>['type'=>'array','items'=>$str],
                        'changes'=>['type'=>'array','items'=>['type'=>'object','properties'=>['slice'=>$int,'field'=>$str,'previous'=>['type'=>['object','array','number','string','boolean','null']],'current'=>['type'=>['object','array','number','string','boolean','null']]]]],
                        'pages'=>['type'=>'array','items'=>$page]]],
            ]];
    }
    /** Unknown extraction cannot be promoted to complete by a successful write. */
    public static function complete(array $table): bool {
        return ($table['collection']['complete']??null)===true;
    }
}
