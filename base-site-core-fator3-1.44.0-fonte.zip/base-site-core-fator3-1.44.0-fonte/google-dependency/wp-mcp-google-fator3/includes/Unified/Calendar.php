<?php
/** Civil calendar intervals are queried at the source, never summed from daily users. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Unified;
if (!defined( 'ABSPATH' )) {
    exit;
}
final class Calendar {
    public static function schema(): array {
        return ['type'=>'object','description'=>'Consulta intervalos civis na origem; não soma usuários ou sessões diários.','additionalProperties'=>false,'required'=>['period'],'properties'=>[
                'period'=>['type'=>'string','enum'=>['iso_week','month','quarter','year']],
                'partial_periods'=>['type'=>'string','enum'=>['include','exclude','reject'],'default'=>'include']]];
    }
    public static function intervals(array $range,array $calendar) {
        if(!\Fator3\McpGoogle\ContractSchema::valid($calendar,self::schema()))return new \WP_Error('f3_google_calendar','Calendário inválido.');
        $period=$calendar['period'];
        $partial=$calendar['partial_periods']??'include';
        $date=new \DateTimeImmutable($range['from'],new \DateTimeZone('UTC'));
        $end=new \DateTimeImmutable($range['to'],new \DateTimeZone('UTC'));
        $out=[];
        while($date<=$end) {
            $start=match($period) {
                'iso_week'=>$date->modify('monday this week'),
                'month'=>$date->modify('first day of this month'),
                'quarter'=>$date->setDate((int)$date->format('Y'),1+3*(int)floor(((int)$date->format('n')-1)/3),1),
                'year'=>$date->setDate((int)$date->format('Y'),1,1),
            };
            $next=$start->modify(match($period){
                'iso_week'=>'+7 days','month'=>'+1 month','quarter'=>'+3 months','year'=>'+1 year'
                });
            $last=$next->modify('-1 day');
            $from=max($date,$start);
            $to=min($end,$last);
            $is_partial=$from!=$start||$to!=$last;
            if($is_partial&&$partial==='reject')return new \WP_Error('f3_google_calendar_partial','O intervalo solicitado contém um período parcial.');
            if(!$is_partial||$partial!=='exclude')$out[]=['label'=>match($period){
                'iso_week'=>$start->format('o-\WW'),'month'=>$start->format('Y-m'),'quarter'=>$start->format('Y').'-Q'.(1+(int)floor(((int)$start->format('n')-1)/3)),'year'=>$start->format('Y')
                },'from'=>$from->format('Y-m-d'),'to'=>$to->format('Y-m-d'),'full_from'=>$start->format('Y-m-d'),'full_to'=>$last->format('Y-m-d'),'partial'=>$is_partial];
            if(count($out)>200)return new \WP_Error('f3_google_calendar_limit','Máximo de 200 intervalos por plano.');
            $date=$next;
        }
        return $out;
    }
}
