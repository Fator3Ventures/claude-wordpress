<?php
/**
 * Optional administrator-selected distribution origin with verified package bytes.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Updater {
	public const OPTION    = 'f3_mcp_google_update_origin';
	public const MAX_HOSTS = 5;
	private static ?array $pending = null;
	private const PLUGIN   = 'wp-mcp-google-fator3/wp-mcp-google-fator3.php';
	public static function schema(): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'enabled'       => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'manifest_url'  => array(
					'type'        => 'string',
					'description' => 'URL HTTPS obrigatória quando enabled=true.',
				),
				'allowed_hosts' => array(
					'type'        => 'array',
					'maxItems'    => self::MAX_HOSTS,
					'items'       => array(
						'type'    => 'string',
						'pattern' => '^[a-z0-9.-]+$',
					),
					'description' => 'Hosts exatos do manifesto, pacote e redirecionamentos.',
				),
			),
		);
	}
	public static function init(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'updates' ) );
		add_filter( 'upgrader_pre_download', array( self::class, 'download' ), 10, 4 );
		add_action('f3_mcp_register_packages',[Distribution::class,'register']);
        add_filter('upgrader_pre_install',[self::class,'pre_install'],10,2);
	}
    /** Discovery uses the public selection only and never performs HTTP. */
    public static function channel_selected(): bool {return Distribution::selection()['origin']==='mcp';}
    public static function pre_install($reply,array $extra=[]) {
        if(($extra['plugin']??'')!==self::PLUGIN||self::$pending===null||is_wp_error($reply))return $reply;
        $guard=Distribution::guard(self::$pending['selection'],self::$pending['origin_hash']??null);
        return is_wp_error($guard)?$guard:$reply;
    }
	public static function configure( array $input ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return Response::fail( new \WP_Error( 'f3_google_update_forbidden', 'Configurar distribuição exige manage_options.' ) );
		}
		$origin = $input['origin'] ?? array();
		if ( ! is_array( $origin ) || array_diff( array_keys( $origin ), array( 'manifest_url', 'allowed_hosts', 'enabled' ) ) || ! is_bool( $origin['enabled'] ?? false ) ) {
			return Response::fail( new \WP_Error( 'f3_google_update_origin', 'Origem inválida.' ) );
		}
		if ( ! empty( $origin['enabled'] ) ) {
			$url   = $origin['manifest_url'] ?? '';
			$hosts = $origin['allowed_hosts'] ?? array();
			if ( ! is_string( $url ) || ! is_array( $hosts ) || ! $hosts || count( $hosts ) > self::MAX_HOSTS || 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! in_array( wp_parse_url( $url, PHP_URL_HOST ), $hosts, true ) ) {
				return Response::fail( new \WP_Error( 'f3_google_update_origin', 'Informe manifesto HTTPS e até cinco hosts de distribuição explicitamente confiáveis.' ) );
			}
			foreach ( $hosts as $host ) {
				if ( ! is_string( $host ) || ! preg_match( '/^[a-z0-9.-]+$/D', $host ) ) {
					return Response::fail( new \WP_Error( 'f3_google_update_origin', 'Host inválido.' ) );
				}
			}
		}
		$saved = Settings::save( array( self::OPTION => $origin, Distribution::CONSENT => Distribution::origin_hash($origin) ), array(), array(), $input['expected_revision'] ?? null );
		if ( $saved['success'] ) {
			\Fator3\McpGoogle\Cache::delete( 'f3_mcp_google_update_manifest' );
		}
		return $saved;
	}
	public static function check( bool $refresh = false ): array {
        $selection=Distribution::selection();
        $origin=Options::get(self::OPTION,[]);
        if(empty($selection['available'])) {
            if(empty($origin['enabled'])&&($selection['reason']??'')==='selection_not_confirmed')return Response::ok(['state'=>'not_configured','update_available'=>false,'selection'=>$selection]);
            return Response::fail(new \WP_Error('f3_google_distribution_unavailable','A origem não pôde ser confirmada. Configure a distribuição ou use um ZIP manual.'),['state'=>'selection_unavailable','selection'=>$selection]);
        }
        if($selection['origin']==='mcp') {
            $manifest=Distribution::manifest($selection);
            if(is_wp_error($manifest))return Response::fail($manifest,['owner'=>'mcp','state'=>'check_failed','selection'=>$selection]);
            if(!is_array($manifest)||!isset($manifest['version'],$manifest['url'],$manifest['sha256'],$manifest['requires']['php'],$manifest['requires']['wordpress']))return Response::fail(new \WP_Error('f3_google_distribution_manifest','Manifesto público incompleto.'));
            $compatible=version_compare(PHP_VERSION,$manifest['requires']['php'],'>=')&&version_compare(get_bloginfo('version'),$manifest['requires']['wordpress'],'>=');
            $result=Response::ok(['owner'=>'mcp','state'=>$compatible?'checked':'incompatible','manifest'=>$manifest,'selection'=>$selection,'update_available'=>$compatible&&version_compare($manifest['version'],F3_MCP_GOOGLE_VERSION,'>'),'checked_at'=>gmdate('c')]);
            Cache::set('f3_mcp_google_update_manifest',['selection'=>$selection,'result'=>$result],3600);
            return $result;
        }
		$origin = Options::get( self::OPTION, array() );
		if ( empty( $origin['enabled'] ) ) {
			return Response::ok(
				array(
					'state'            => 'not_configured',
					'update_available' => false,
				)
			);
		}
		$key         = 'f3_mcp_google_update_manifest';
		$cached      = \Fator3\McpGoogle\Cache::get( $key );
		$origin_hash = Distribution::origin_hash($origin);
		if ( ! $refresh && is_array( $cached ) && ( $cached['origin_hash'] ?? '' ) === $origin_hash && ($cached['selection']??null)===$selection ) {
			return $cached['result'];
		}
		$response = Http\PublicPage::fetch( $origin['manifest_url'], $origin['allowed_hosts'], 5, 262144, array( 'https' ) );
		if ( empty( $response['success'] ) || ! empty( $response['truncated'] ) || 200 !== ( $response['http_status'] ?? 0 ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_update_manifest_fetch', 'Falha ao consultar a origem de distribuição.' ),
				array(
					'state'     => 'check_failed',
					'transport' => $response['error_code'] ?? null,
				)
			);
		}
		$guard=Distribution::guard($selection,$origin_hash);
        if(is_wp_error($guard))return Response::fail($guard);
        $manifest = json_decode( $response['body'] ?? '', true );
		$issue    = self::validate( $manifest, $origin );
		if ( null !== $issue ) {
			return Response::fail( $issue, array( 'state' => 'invalid_manifest' ) );
		}
		$compatible = version_compare( PHP_VERSION, $manifest['requires_php'], '>=' ) && version_compare( get_bloginfo( 'version' ), $manifest['requires_wordpress'], '>=' );
		$result     = Response::ok(
			array(
				'state'            => $compatible ? 'checked' : 'incompatible',
				'manifest'         => $manifest,
                'selection'        => $selection,
                'owner'            => 'provider',
				'update_available' => $compatible && version_compare( $manifest['version'], F3_MCP_GOOGLE_VERSION, '>' ),
				'checked_at'       => gmdate( 'c' ),
			)
		);
		\Fator3\McpGoogle\Cache::set(
			$key,
			array(
				'origin_hash' => $origin_hash,
                'selection' => $selection,
				'result'      => $result,
			),
			3600
		);
		return $result;
	}
	public static function validate( $manifest, array $origin ): ?\WP_Error {
		if ( ! is_array( $manifest ) || ( $manifest['schema_version'] ?? '' ) !== '1.0.0' || ( $manifest['plugin'] ?? '' ) !== 'wp-mcp-google-fator3' || ! preg_match( '/^\d+\.\d+\.\d+$/D', (string) ( $manifest['version'] ?? '' ) ) || ! preg_match( '/^[a-f0-9]{64}$/D', (string) ( $manifest['sha256'] ?? '' ) ) || ! preg_match( '/^\d+\.\d+(?:\.\d+)?$/D', (string) ( $manifest['requires_php'] ?? '' ) ) || ! preg_match( '/^\d+\.\d+(?:\.\d+)?$/D', (string) ( $manifest['requires_wordpress'] ?? '' ) ) ) {
			return new \WP_Error( 'f3_google_update_manifest', 'Manifesto incompatível ou incompleto.' );
		}
		$url = $manifest['package_url'] ?? '';
		if ( ! is_string( $url ) || 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! in_array( wp_parse_url( $url, PHP_URL_HOST ), $origin['allowed_hosts'] ?? array(), true ) || wp_parse_url( $url, PHP_URL_USER ) || ! str_ends_with( (string) wp_parse_url( $url, PHP_URL_PATH ), '.zip' ) ) {
			return new \WP_Error( 'f3_google_update_package_origin', 'Pacote fora da origem confiável.' );
		}
		return null;
	}
	public static function updates( $transient ) {
		if ( self::channel_selected() || ! is_object( $transient ) ) {
			return $transient;
		}
		$check = self::check();
		if ( empty( $check['success'] ) || empty( $check['update_available'] ) ) {
			return $transient;
		}
		$m                                   = $check['manifest'];
		$transient->response[ self::PLUGIN ] = (object) array(
			'id'           => 'wp-mcp-google-fator3',
			'slug'         => 'wp-mcp-google-fator3',
			'plugin'       => self::PLUGIN,
			'new_version'  => $m['version'],
			'package'      => $m['package_url'],
			'url'          => $m['release_url'] ?? '',
			'requires'     => $m['requires_wordpress'],
			'requires_php' => $m['requires_php'],
		);
		return $transient;
	}
	public static function download( $reply, string $package, $upgrader, array $hook_extra = array() ) {
        self::$pending=null;
        if(($hook_extra['plugin']??'')!==self::PLUGIN||false!==$reply)return $reply;
        // WordPress uploads are independent of feed selection and remain available.
        if(!preg_match('~^[a-z][a-z0-9+.-]*://~i',$package)&&is_file($package))return $reply;
        $cached=Cache::get('f3_mcp_google_update_manifest');
        if(!is_array($cached)&&self::channel_selected()){self::check();$cached=Cache::get('f3_mcp_google_update_manifest');}
        if(!is_array($cached)||!isset($cached['selection'],$cached['result']['manifest']))return new \WP_Error('f3_google_update_unverified','Consulte uma oferta antes do download.');
        $guard=Distribution::guard($cached['selection'],$cached['origin_hash']??null);
        if(is_wp_error($guard))return $guard;
        $check=$cached['result'];$manifest=$check['manifest'];
        if(empty($check['success'])||($check['state']??'')!=='checked'||($manifest['package_url']??$manifest['url']??null)!==$package)return new \WP_Error('f3_google_update_unverified','O pacote não corresponde à oferta confirmada.');
        self::$pending=$cached;
        if($cached['selection']['origin']==='mcp')return $reply; // Public MCP handler owns the selected download.
		$origin = Options::get( self::OPTION, array() );
		$r      = Http\PublicPage::fetch( $package, $origin['allowed_hosts'], 5, 32 * 1024 * 1024, array( 'https' ) );
		if ( empty( $r['success'] ) || ! empty( $r['truncated'] ) || ! hash_equals( $check['manifest']['sha256'], hash( 'sha256', $r['body'] ?? '' ) ) ) {
			return new \WP_Error( 'f3_google_update_checksum', 'Download incompleto ou hash divergente.' );
		}
        $guard=Distribution::guard($cached['selection'],$cached['origin_hash']??null);
        if(is_wp_error($guard))return $guard;
		$file = wp_tempnam( 'wp-mcp-google-fator3.zip' );
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- WordPress-created local temporary ZIP; exact byte count and package hash are verified.
		if ( ! $file || strlen( $r['body'] ) !== file_put_contents( $file, $r['body'] ) ) {
			return new \WP_Error( 'f3_google_update_storage', 'Não foi possível salvar o pacote temporário.' );
		}
		require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		$zip  = new \PclZip( $file );
		$list = $zip->listContent();
		$main = false;
		if ( is_array( $list ) ) {
			foreach ( $list as $entry ) {
				$path = $entry['filename'];
				if ( ! str_starts_with( $path, 'wp-mcp-google-fator3/' ) || str_contains( $path, '..' ) || preg_match( '~/(docs|reference)/|\.md$~i', $path ) ) {
					wp_delete_file( $file );
					return new \WP_Error( 'f3_google_update_package_shape', 'Estrutura do pacote incompatível.' );
				}
				if ( self::PLUGIN === $path ) {
					$main = true;
				}
			}
		}
		$paths       = array();
		$directories = array( 'wp-mcp-google-fator3' );
		$total       = 0;
		foreach ( is_array( $list ) ? $list : array() as $entry ) {
			$path   = rtrim( $entry['filename'], '/' );
			$total += (int) ( $entry['size'] ?? 0 );
			if ( isset( $paths[ $path ] ) || str_contains( $path, '\\' ) || basename( $path ) === '.htaccess' || count( $paths ) >= 2000 || $total > 128 * 1024 * 1024 ) {
				wp_delete_file( $file );
				return new \WP_Error( 'f3_google_update_package_shape', 'Arquivo duplicado, caminho inseguro ou pacote expandido excessivo.' );
			}
			$paths[ $path ] = true;
			for ( $parent = dirname( $path );'.' !== $parent;$parent = dirname( $parent ) ) {
				$directories[ $parent ] = $parent;
			}
		}
		foreach ( $directories as $directory ) {
			if ( ! isset( $paths[ $directory . '/index.php' ] ) ) {
				wp_delete_file( $file );
				return new \WP_Error( 'f3_google_update_package_shape', 'O pacote contém diretório sem índice de proteção.' );
			}
		}
		if ( ! $main ) {
			wp_delete_file( $file );
			return new \WP_Error( 'f3_google_update_package_shape', 'Arquivo principal ausente.' );
		}
		$source = $zip->extract( PCLZIP_OPT_BY_NAME, self::PLUGIN, PCLZIP_OPT_EXTRACT_AS_STRING );
		$header = $source[0]['content'] ?? '';
		if ( ! preg_match( '/Version:\s*' . preg_quote( $check['manifest']['version'], '/' ) . '\s*$/m', $header ) ) {
			wp_delete_file( $file );
			return new \WP_Error( 'f3_google_update_package_version', 'Versão interna diverge do manifesto.' );
		}
		return $file;
	}
	public static function register(): void {
		Ability::register(
			'google/check-update',
			'any',
			array(
				'label'        => 'Google: verificar atualização',
				'description'  => 'Consulta somente a origem explicitamente configurada. Distingue ausência de atualização, incompatibilidade e falha de consulta.',
				'input_schema' => array( 'properties' => array( 'refresh' => array( 'type' => 'boolean' ) ) ),
				'callback'     => static fn ( array $i ) => self::check( ! empty( $i['refresh'] ) ),
			)
		);
		Ability::register(
			'google/configure-update-origin',
			'any',
			array(
				'label'        => 'Google: configurar distribuição',
				'description'  => 'Define manifesto HTTPS e hosts confiáveis. Não publica pacote nem ativa atualização automática.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'origin', 'expected_revision' ),
					'properties' => array(
						'origin'            => self::schema(),
						'expected_revision' => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'configure' ),
			)
		);
	}
}
