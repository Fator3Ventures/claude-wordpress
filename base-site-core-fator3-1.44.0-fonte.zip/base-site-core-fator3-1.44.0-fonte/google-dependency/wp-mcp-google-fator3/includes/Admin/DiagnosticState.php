<?php
/** Read-only labels for local credential and cached diagnostic states. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class DiagnosticState {
    public static function identity( $provider, array $candidate ): string {
        if ( is_wp_error($provider) ) {
            $code = $provider->get_error_code();
            if ( 'f3_google_crypto_decrypt' === $code ) { return 'Falha de descriptografia da credencial ativa; consulte diagnóstico e recuperação'; }
            if ( 'f3_google_option_read' === $code ) { return 'Falha de leitura da credencial ativa; consulte diagnóstico e recuperação'; }
            if ( !empty($candidate['present']) && empty($candidate['readable']) ) { return 'Credencial candidata salva, mas ilegível'; }
            if ( !empty($candidate['present']) ) { return 'Credencial candidata salva; ativação pendente'; }
            if ( 'f3_google_auth_not_active' === $code ) { return 'Credencial salva; ativação pendente'; }
            return 'Credencial ausente; configure na área Conexão';
        }
        $label = 'Credencial ativa legível: ' . (string)($provider->describe()['identity'] ?? 'identidade disponível');
        if ( !empty($candidate['present']) ) { $label .= empty($candidate['readable']) ? ' · candidata ilegível' : ' · candidata salva; ativação pendente'; }
        return $label;
    }
    public static function valid( array $result ): bool {
        if ( !isset($result['result_status'],$result['execution_success'],$result['checked_at'],$result['revision']) || !is_bool($result['execution_success']) || !is_string($result['checked_at']) || !is_string($result['revision']) ) { return false; }
        if ( !in_array($result['result_status'],array('passed','incomplete','failed','execution_error'),true) || !is_array($result['checks'] ?? array()) ) { return false; }
        if ( $result['execution_success'] ) {
            if ( 'execution_error' === $result['result_status'] || !isset($result['checks']) ) { return false; }
            foreach ( array('passed','failed','skipped','not_configured') as $key ) { if ( !is_int($result[$key] ?? null) || $result[$key] < 0 ) { return false; } }
        } elseif ( 'execution_error' !== $result['result_status'] ) { return false; }
        if ( isset($result['message']) && !is_string($result['message']) ) { return false; }
        foreach ( $result['checks'] ?? array() as $check ) { if ( !is_array($check) || !is_string($check['status'] ?? null) || !is_string($check['name'] ?? null) ) { return false; } }
        return true;
    }
    public static function instant( string $date ): string {
        $timestamp = strtotime($date);
        if ( false === $timestamp ) { return 'Horário indisponível'; }
        return wp_date('d/m/Y H:i:s T',$timestamp);
    }
}
