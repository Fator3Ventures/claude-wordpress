<?php
/** Consumer of the public Core measurement SDK; no private options or files. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if (!defined( 'ABSPATH' )) {
    exit;
}
final class CoreContext {
    public const CONTRACT='site-measurement-context/1.0.0';
    private const PROVIDER='base-site-core-fator3';
    private const SDK='\\F3Base_Medicao_Contexto';
    public static function schema(string $method): array {
        static $schemas;
        if($schemas===null)$schemas=require __DIR__.'/Data/CoreMeasurement.php';
        return $schemas[$method]??[];
    }
    public static function failure(string $code): array {
        return ['ok'=>false,'code'=>$code,'contract'=>self::CONTRACT,'provider'=>self::PROVIDER,'data'=>null,
            'message'=>'Contexto público de medição indisponível: '.$code.'.'];
    }
    private static function call(string $method,array $input=[]): array {
        try {
            $r=$method==='events'?call_user_func([self::SDK,$method],$input):call_user_func([self::SDK,$method]);
            if(!is_array($r)||!ContractSchema::valid($r,self::schema($method)))return self::failure('unsupported');
            if(($r['contract']??null)!==self::CONTRACT||($r['provider']??null)!==self::PROVIDER)return self::failure('unsupported');
            return $r['ok']?$r:self::failure($r['code']);
        }
        catch(\Throwable $error) {
            return self::failure('unreadable');
        }
    }
    public static function capabilities(): array {
        if(!class_exists(self::SDK))return self::failure('unavailable');
        foreach(['capabilities','snapshot','events'] as $method)if(!is_callable([self::SDK,$method]))return self::failure('unsupported');
        $r=self::call('capabilities');
        if(!$r['ok'])return $r;
        if($r['data']['schema_revision']!=='1'||array_diff(['measurement.context.read','measurement.events.read'],$r['data']['capabilities']))return self::failure('unsupported');
        return $r;
    }
    public static function snapshot(): array {
        $cap=self::capabilities();
        return $cap['ok']?self::call('snapshot'):$cap;
    }
    public static function events(array $snapshot,int $max_pages=20,int $page_size=100): array {
        if(empty($snapshot['ok'])||!ContractSchema::valid($snapshot,self::schema('snapshot')))return self::failure('unsupported');
        $revision=$snapshot['data']['events_revision'];
        $offset=0;
        $items=[];
        $total=null;
        $names=[];
        $last='';
        for($page=0;$page<min(20,max(1,$max_pages));++$page) {
            $cap=self::capabilities();
            if(!$cap['ok'])return $cap;
            $r=self::call('events',['limit'=>min(200,max(1,$page_size)),'offset'=>$offset,'expected_revision'=>$revision]);
            if(!$r['ok'])return $r;
            $d=$r['data'];
            if($d['revision']!==$revision)return self::failure('revision_conflict');
            if($total!==null&&$total!==$d['total'])return self::failure('revision_conflict');
            $total=$d['total'];
            foreach($d['items'] as $item) {
                if(isset($names[$item['name']]))return self::failure('unsupported');
                $names[$item['name']]=true;
                $last=$item['name'];
                $items[]=$item;
            }
            $next=$d['next_offset'];
            if($d['complete']) {
                if($next!==null||count($items)!==$total)return self::failure('unsupported');
                $now=self::snapshot();
                if(!$now['ok'])return $now;
                if($now['data']['revision']!==$snapshot['data']['revision'])return self::failure('revision_conflict');
                return ['ok'=>true,'code'=>'ok','contract'=>self::CONTRACT,'provider'=>self::PROVIDER,'data'=>['revision'=>$revision,'total'=>$total,'items'=>$items,'next_offset'=>null,'complete'=>true]];
            }
            if(!is_int($next)||$next!==$offset+count($d['items'])||$next<=$offset||$next>=$total)return self::failure('unsupported');
            $offset=$next;
        }
        return self::failure('catalog_budget_exceeded');
    }
    public static function error(array $response): \WP_Error {
        return new \WP_Error('f3_google_core_'.$response['code'],'Não foi possível obter o contexto público do Core. Informe os IDs explicitamente ou confira a capacidade de medição.',
            ['core_code'=>$response['code'],'core_contract'=>self::CONTRACT]);
    }
    public static function id(array $snapshot,string $slot,string $field): string {
        if(empty($snapshot['ok'])||($snapshot['data']['slots'][$slot]['state']??'')!=='configured')return '';
        return (string)($snapshot['data']['slots'][$slot]['effective']['fields'][$field]??'');
    }
}
