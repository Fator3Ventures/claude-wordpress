<?php
/** Strict validation of the packaged public PHP contract schemas (no coercion). */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if (!defined( 'ABSPATH' )) {
    exit;
}
final class ContractSchema {
    public static function valid($value, array $schema, int $depth=0): bool {
        if ($depth>40) return false;
        foreach (['oneOf','anyOf'] as $union) {
            if (!isset($schema[$union])) continue;
            $matches=0;
            foreach ($schema[$union] as $branch) if(self::valid($value,$branch,$depth+1)) ++$matches;
            if ($union==='oneOf' ? $matches!==1 : $matches===0) return false;
        }
        $types=(array)($schema['type']??[]);
        $type=null;
        foreach($types as $candidate) {
            $valid=match($candidate) {
                'null'=>$value===null, 'string'=>is_string($value), 'boolean'=>is_bool($value),
                'integer'=>is_int($value), 'number'=>is_int($value)||is_float($value),
                'array'=>is_array($value)&&($value===[]||array_keys($value)===range(0,count($value)-1)),
                'object'=>$value instanceof \stdClass||(is_array($value)&&($value===[]||array_keys($value)!==range(0,count($value)-1))),
                default=>false,
            };
            if($valid){
                $type=$candidate;
                break;
            }
        }
        if($types&&$type===null) return false;
        if(isset($schema['enum'])&&!in_array($value,$schema['enum'],true)) return false;
        if($type==='string') {
            $length=function_exists('mb_strlen')?mb_strlen($value,'UTF-8'):strlen($value);
            if(isset($schema['pattern'])&&!preg_match('~'.str_replace('~','\\~',$schema['pattern']).'~u',$value))return false;
            if(isset($schema['minLength'])&&$length<$schema['minLength'])return false;
            if(isset($schema['maxLength'])&&$length>$schema['maxLength'])return false;
        }
        if(in_array($type,['integer','number'],true)) {
            if(!is_finite((float)$value))return false;
            if(isset($schema['minimum'])&&$value<$schema['minimum'])return false;
            if(isset($schema['maximum'])&&$value>$schema['maximum'])return false;
        }
        if($type==='object') {
            $object=(array)$value;
            foreach($schema['required']??[] as $key)if(!array_key_exists($key,$object))return false;
            foreach($object as $key=>$item) {
                $child=$schema['properties'][$key]??($schema['additionalProperties']??true);
                if($child===false||(is_array($child)&&!self::valid($item,$child,$depth+1)))return false;
            }
        }
        if($type==='array') {
            if(isset($schema['minItems'])&&count($value)<$schema['minItems'])return false;
            if(isset($schema['maxItems'])&&count($value)>$schema['maxItems'])return false;
            foreach($value as $item)if(isset($schema['items'])&&!self::valid($item,$schema['items'],$depth+1))return false;
        }
        return true;
    }
}
