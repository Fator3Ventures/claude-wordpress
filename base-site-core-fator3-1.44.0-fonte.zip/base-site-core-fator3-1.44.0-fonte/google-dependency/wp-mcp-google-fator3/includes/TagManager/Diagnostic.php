<?php
/**
 * Static evidence from the published container and this site's Core slots.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\TagManager;

use Fator3\McpGoogle\{
	Ability, Response
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Diagnostic {
    public static function slots(?array $context=null): array {
        $context=$context??\Fator3\McpGoogle\CoreContext::snapshot();
        $out=[];
        foreach(['ga4'=>'measurement_id','google_ads'=>'conversion_id','meta'=>'pixel_id','linkedin'=>'partner_id','clarity'=>'project_id'] as $slot=>$field)
            $out[$slot]=\Fator3\McpGoogle\CoreContext::id($context,$slot,$field);
        $out['meta_server']=\Fator3\McpGoogle\CoreContext::id($context,'meta','server_pixel_id');
        return $out;
    }
	public static function analyze( array $version, array $slots ): array {
		$constants = array();
		foreach ( $version['variable'] ?? array() as $v ) {
			if ( ( $v['type'] ?? '' ) === 'c' ) {
				foreach ( $v['parameter'] ?? array() as $p ) {
					if ( ( $p['key'] ?? '' ) === 'value' && is_string( $p['value'] ?? null ) ) {
						$constants[ $v['name'] ] = $p['value'];
					}
				}
			}
		}
		$matches    = array();
		$consent    = array();
		$unresolved = array();
		foreach ( $version['tag'] ?? array() as $tag ) {
			// IDs must be found in tag parameters, never metadata such as tagId or name.
			$json = (string) wp_json_encode( $tag['parameter'] ?? array() );
			foreach ( $constants as $name => $value ) {
				$json = str_replace( '{{' . $name . '}}', $value, $json );
			}
			$dynamic = str_contains( $json, '{{' ) || ( $tag['type'] ?? '' ) === 'html';
			if ( $dynamic ) {
				$unresolved[] = array(
					'tag_id' => $tag['tagId'] ?? null,
					'name'   => $tag['name'] ?? '',
					'reason' => ( $tag['type'] ?? '' ) === 'html' ? 'custom_html_not_executed' : 'dynamic_variable',
				);
			}
			foreach ( $slots as $service => $expected ) {
				if ( '' !== $expected && preg_match( '~(?<![A-Za-z0-9_-])' . preg_quote( $expected, '~' ) . '(?![A-Za-z0-9_-])~', $json ) ) {
					$matches[ $service ][] = array(
						'tag_id'             => $tag['tagId'] ?? null,
						'name'               => $tag['name'] ?? '',
						'state'              => $dynamic ? 'potential_match' : 'literal_match',
						'paused'             => ! empty( $tag['paused'] ),
						'firing_trigger_ids' => $tag['firingTriggerId'] ?? array(),
					);
				}
			}
			if ( isset( $tag['consentSettings'] ) || preg_match( '/consent|ad_storage|analytics_storage|ad_user_data|ad_personalization/i', $json ) ) {
				$consent[] = array(
					'tag_id'   => $tag['tagId'] ?? null,
					'name'     => $tag['name'] ?? '',
					'type'     => $tag['type'] ?? '',
					'settings' => $tag['consentSettings'] ?? null,
					'evidence' => 'static_configuration',
				);
			}
		}
		$out = array();
		foreach ( $slots as $service => $id ) {
			$out[ $service ] = array(
				'expected_id' => $id,
				'state'       => '' === $id ? 'not_configured' : ( ! empty( $matches[ $service ] ) ? 'matches_found' : ( $unresolved ? 'unresolved' : 'not_found' ) ),
				'matches'     => $matches[ $service ] ?? array(),
			);
		}
		return array(
			'version_id'       => $version['containerVersionId'] ?? null,
			'slots'            => $out,
			'consent_tags'     => $consent,
			'unresolved_tags'  => $unresolved,
			'runtime_verified' => false,
			'scope'            => 'published_version_static_analysis',
			'limitations'      => array( 'A literal match does not prove tag firing or delivery.', 'Dynamic variables and custom HTML require runtime verification.', 'Consent configuration is not proof of consent behavior in the browser.' ),
		);
	}
	public static function run( array $input ): array {
		$core = \Fator3\McpGoogle\CoreContext::snapshot();
        $conversions = \Fator3\McpGoogle\CoreConversions::snapshot();
        $container = Api::container( $input );
		if ( is_wp_error( $container ) && empty( $input['container_path'] ) ) {
			if (!$core['ok']) return Response::fail(\Fator3\McpGoogle\CoreContext::error($core));
            $public = \Fator3\McpGoogle\CoreContext::id($core,'gtm','container_id');
			if ( preg_match( '/^GTM-[A-Z0-9]+$/D', $public ) ) {
				$found = Api::call( 'containers.lookup', array(), array( 'tagId' => $public ) );
				if ( is_wp_error( $found ) ) {
					return Response::fail( $found );
				}
				$container = Api::container( array( 'container_path' => $found['path'] ?? '' ) );
			}
		}
		if ( is_wp_error( $container ) ) {
			return Response::fail( $container );
		}
		$live = Api::call( 'containers.versions.live', array( 'parent' => $container ) );
		if ( is_wp_error( $live ) ) {
			return Response::fail( $live );
		}
        $events=$core['ok']?\Fator3\McpGoogle\CoreContext::events($core):$core;
        $current=\Fator3\McpGoogle\CoreContext::snapshot();
        if($core['ok'] && (!$current['ok'] || $current['data']['revision']!==$core['data']['revision']))
            return Response::fail(\Fator3\McpGoogle\CoreContext::error($current['ok']?\Fator3\McpGoogle\CoreContext::failure('revision_conflict'):$current));
		return Response::ok(
			array(
				'container_path' => $container,
				'core_available' => $core['ok'],
                'core_context' => $core,
                'core_events' => $events,
                'core_conversion_context' => \Fator3\McpGoogle\CoreConversions::revalidate($conversions, $core),
			) + self::analyze( $live, self::slots($core) )
		);
	}
	public static function register(): void {
		Ability::register(
			'gtm/diagnostico',
			'gtm',
			array(
				'label'        => 'GTM: diagnóstico da versão publicada',
				'description'  => 'Compara os IDs publicados com os slots do Core e identifica configuração de consentimento. Acrescenta contexto opcional de contato/material com revisão coerente. Análise estática não comprova entrega.',
				'output_schema' => ['type'=>'object', 'properties'=>['success'=>['type'=>'boolean'], 'message'=>['type'=>'string'], 'core_conversion_context'=>\Fator3\McpGoogle\CoreConversions::response_schema()]],
				'input_schema' => array( 'properties' => array( 'container_path' => array( 'type' => 'string' ) ) ),
				'callback'     => array( self::class, 'run' ),
			)
		);
	}
}
