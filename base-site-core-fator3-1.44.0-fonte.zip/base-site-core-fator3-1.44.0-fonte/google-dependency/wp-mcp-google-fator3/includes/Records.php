<?php
/**
 * Independent, non-autoloaded records; unique inserts do not overwrite other writers.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Records {
    public static function key(string $kind, string $id): string {
        if (!preg_match('/^[a-z]+$/D', $kind) || !preg_match('/^[a-zA-Z0-9_-]{1,100}$/D', $id)) {
            throw new \InvalidArgumentException('Identificador de registro inválido.');
        }
        return $kind . ':' . $id;
    }
    public static function id(): string {
        return sprintf('%020d', (int) floor(microtime(true)*1000000)) . '_' . bin2hex(random_bytes(8));
    }
    public static function get(string $kind, string $id): ?array {
        $value = Storage\Repository::get($kind, $id);
        if (is_wp_error($value)) throw new \RuntimeException($value->get_error_code());
        return $value;
    }
    public static function insert(string $kind, string $id, array $record): bool {
        return Storage\Repository::insert($kind, $id, $record);
    }
    public static function put(string $kind, string $id, array $record): array {
        return Storage\Repository::put($kind, $id, $record);
    }
    public static function remove(string $kind, string $id): array {
        return Storage\Repository::remove($kind, $id);
    }
    public static function has_work(): bool {
        $work = Storage\Repository::has_work();
        return is_wp_error($work) || $work;
    }
    public static function ids(string $kind, int $limit=1000, bool $newest=true, int $offset=0): array {
        $rows = Storage\Repository::select($kind, [], $limit, $offset, $newest);
        if (is_wp_error($rows)) throw new \RuntimeException($rows->get_error_code());
        return array_column($rows, 'record_id');
    }
    public static function list( string $kind, int $limit = 1000, bool $newest = true ): array {
        $out = array();
        foreach ( self::ids( $kind, $limit, $newest ) as $id ) {
            $value = self::get( $kind, $id );
            if ( null !== $value ) {
                $out[ $id ] = $value;
            }
        }
        return $out;
    }
}
