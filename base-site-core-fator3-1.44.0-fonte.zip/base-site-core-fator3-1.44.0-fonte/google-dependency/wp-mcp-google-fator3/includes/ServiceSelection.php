<?php
/** Pure service-selection diff from fresh, connection-scoped settings. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ServiceSelection {
    public static function snapshot() {
        $out=[];
        foreach ([Connections::SERVICES=>null,Options::GA_ENABLED=>false,Options::ADS_ENABLED=>false] as $name=>$default) {
            $r=Options::stored(Options::storage_name($name));
            if (!$r['success']) return new \WP_Error('f3_google_option_read','Falha ao ler a seleção de serviços.');
            $out[$name]=$r['exists']?$r['value']:$default;
        }
        $selected=$out[Connections::SERVICES];
        if ($selected!==null&&!is_array($selected)) return new \WP_Error('f3_google_services_state','Seleção de serviços persistida inválida.');
        foreach ($selected??[] as $service=>$level) if (!is_string($level)||!in_array($level,Setup::LEVELS[$service]??[],true)) return new \WP_Error('f3_google_services_state','Perfil persistido inválido.');
        if(is_array($out[Connections::SERVICES])) ksort($out[Connections::SERVICES]);
        $out[Options::GA_ENABLED]=(bool)$out[Options::GA_ENABLED];
        $out[Options::ADS_ENABLED]=(bool)$out[Options::ADS_ENABLED];
        return $out;
    }
    public static function effective(array $values): array {
        $selected=$values[Connections::SERVICES];
        $fallback=['ga'=>'admin','ads'=>'write','gsc'=>'write','siteverification'=>'write','sheets'=>'write','drive'=>'write'];
        $out=[];
        foreach(Setup::LEVELS as $service=>$levels) {
            $level=($selected??$fallback)[$service]??null;
            $on=$level!==null && ($service!=='ga'||(bool)$values[Options::GA_ENABLED]) && ($service!=='ads'||(bool)$values[Options::ADS_ENABLED]);
            $out[$service]=['enabled'=>$on,'level'=>$on?$level:null,'source'=>$selected===null?'inherited':'explicit'];
        }
        return $out;
    }
    public static function compile(array $input) {
        foreach(['dry_run','merge','confirm_service_reduction','discover','validate_access','vincular_site_core'] as $field) if(array_key_exists($field,$input)&&!is_bool($input[$field])) return new \WP_Error('f3_google_setup_input',$field.' deve ser booleano.');
        if (!empty($input['merge'])&&!array_key_exists('services',$input)) return new \WP_Error('f3_google_setup_input','merge exige services.');
        $before=self::snapshot();
        if(is_wp_error($before)) return $before;
        $after=$before;
        $values=[];
        if(array_key_exists('services',$input)) {
            $selection=$input['services'];
            if(!is_array($selection)) return new \WP_Error('f3_google_setup_input','services deve ser objeto; omita para preservar.');
            foreach($selection as $service=>$level) if(!is_string($level)||!in_array($level,Setup::LEVELS[$service]??[],true)) return new \WP_Error('f3_google_setup_input','Serviço ou perfil inválido: '.(string)$service);
            if(empty($input['merge'])) {
                $after=[Connections::SERVICES=>$selection,Options::GA_ENABLED=>isset($selection['ga']),Options::ADS_ENABLED=>isset($selection['ads'])];
            }
            elseif($selection) {
                $base=$before[Connections::SERVICES];
                if($base===null) {
                    $base=[];
                    foreach(self::effective($before) as $service=>$state) if($state['enabled']) $base[$service]=$state['level'];
                }
                $after[Connections::SERVICES]=array_replace($base,$selection);
                foreach(['ga'=>Options::GA_ENABLED,'ads'=>Options::ADS_ENABLED] as $service=>$flag) if(isset($selection[$service])) $after[$flag]=true;
            }
            if(is_array($after[Connections::SERVICES])) ksort($after[Connections::SERVICES]);
            if($selection||empty($input['merge'])) $values=$after;
        }
        $from=self::effective($before);
        $to=self::effective($after);
        $diff=['enabled'=>[],'disabled'=>[],'upgraded'=>[],'downgraded'=>[],'unchanged'=>[]];
        foreach($from as $service=>$state) {
            $new=$to[$service];
            $kind='unchanged';
            if($state['enabled']&&!$new['enabled']) $kind='disabled';
            elseif(!$state['enabled']&&$new['enabled']) $kind='enabled';
            elseif($state['enabled']&&$new['enabled']&&$state['level']!==$new['level']) $kind=array_search($new['level'],Setup::LEVELS[$service],true)>array_search($state['level'],Setup::LEVELS[$service],true)?'upgraded':'downgraded';
            $diff[$kind][]=$service;
        }
        return ['values'=>$values,'services_before'=>$from,'services_after'=>$to,'services_stored_before'=>$before[Connections::SERVICES],
            'services_stored_after'=>$after[Connections::SERVICES],'service_changes'=>$diff,'services_mode'=>!array_key_exists('services',$input)?'preserve':(!empty($input['merge'])?'merge':'replace'),
            'confirmation_required'=>(bool)($diff['disabled']||$diff['downgraded'])];
    }
    public static function hash(array $value): string {
        $canonical=static function($v) use(&$canonical) {
            if(is_array($v)) {
                ksort($v);
                foreach($v as &$item) $item=$canonical($item);
                unset($item);
            }
            return $v;
        };
        return hash('sha256',wp_json_encode($canonical($value)));
    }
}
