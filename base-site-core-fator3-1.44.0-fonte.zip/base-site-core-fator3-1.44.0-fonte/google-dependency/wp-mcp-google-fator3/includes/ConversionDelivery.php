<?php
/** Core delivery contract. The Core owns eligibility, the queue and deduplication. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Automation\Execution;
if (!defined('ABSPATH')) {
    exit;
}
final class ConversionDelivery {
    public const CONTRACT='site-conversion-delivery/1.0.0';
    public const CONFIG='f3_mcp_google_conversion_delivery';
    public const SECRET='f3_mcp_google_mp_secret';
    private string $target;
    private string $connection;
    private ?string $selection_error;
    public function __construct(string $target,?string $connection=null,?string $error=null) {
        $this->target=$target;
        $this->connection=$connection??Connections::id();
        $this->selection_error=$error;
    }
    public static function init(): void {
        add_filter('f3base_conversoes_adaptador',[self::class,'adapter'],20,3);

    }
    public static function adapter($existing,$target,$contract) {
        if ($existing!==null || $contract!==self::CONTRACT || !in_array($target,['ga4','google_ads'],true)) return $existing;
        $registry=Connections::registry_verified();
        if (is_wp_error($registry)) return new self($target,'default','connections_unreadable');
        $selected=[];
        foreach (array_keys($registry) as $cid) {
            $value=Connections::run($cid,static fn()=>self::read());
            $c=['success'=>!is_wp_error($value),'value'=>is_wp_error($value)?[]:$value];
            if (empty($c['success'])) return new self($target,'default','configuration_unreadable');
            if (!empty($c['value']['enabled']) && !empty($c['value'][$target==='ga4'?'measurement_id':'conversion_action'])) $selected[]=$cid;
        }
        return new self($target,$selected[0]??'default',count($selected)>1?'ambiguous_connection':null);
    }
    public static function defaults(): array {
        return ['enabled'=>false,'measurement_id'=>'','stream'=>'','customer_id'=>'','conversion_action'=>''];
    }
    private static function read() {
        $r=Options::stored(Options::storage_name(self::CONFIG));
        if (!$r['success'] || ($r['exists']&&!is_array($r['value']))) return new \WP_Error('configuration_unreadable','Configuração de conversões ilegível.');
        $c=($r['value']??[])+self::defaults();
        $c['measurement_id']=self::measurement_id();
        return $c;
    }
    public static function measurement_id(): string {
        $snapshot=CoreContext::snapshot();
        $id=$snapshot['data']['slots']['ga4']['effective']['fields']['measurement_id']??'';
        return !empty($snapshot['ok'])&&is_string($id)&&preg_match('/^G-[A-Z0-9]+$/D',$id)?$id:'';
    }
    public static function revision(): string {
        $r=Options::stored(Options::storage_name(self::CONFIG));
        return $r['success']?hash('sha256',(string)wp_json_encode($r['value']??[])):'';
    }
    private static function identity(array $c,string $target): string {
        $destination=$target==='ga4'?[$c['measurement_id'],$c['stream']]:[$c['customer_id'],$c['conversion_action']];
        return hash('sha256',wp_json_encode([get_current_blog_id(),Connections::id(),Credentials::execution_identity(),$target,$destination]));
    }
    private static function proof_revision(array $c,string $target): string {
        $parts=[self::identity($c,$target),Credentials::identity_key(),
            $target==='ga4'?Options::get_secret(self::SECRET):Options::get_secret(Options::ADS_DEVELOPER_TOKEN),
            Options::ads_api_version(),Options::get(Connections::SERVICES),Policy::current(),Recovery::generation()];
        if ($target==='google_ads') $parts[]='data-manager-v1';
        return hash_hmac('sha256',wp_json_encode($parts),wp_salt('auth'));
    }
    public static function legacy_ads_eligible(string $customer): bool {
        $c=self::read();if(is_wp_error($c)||$c['customer_id']!==$customer) return false;
        $proof=$c['verified']['google_ads']??[];
        if (($proof['eligibility_source']??'')!=='administrator_attestation_and_action_read'||($proof['expires']??0)<=time()) return false;
        $parts=[self::identity($c,'google_ads'),Credentials::identity_key(),Options::get_secret(Options::ADS_DEVELOPER_TOKEN),Options::ads_api_version(),Options::get(Connections::SERVICES),Policy::current(),Recovery::generation()];
        return hash_equals(hash_hmac('sha256',wp_json_encode($parts),wp_salt('auth')),(string)($proof['revision']??''));
    }
    private static function local_reason(array $c,string $target): ?string {
        if (!Options::is_enabled()) return 'channel_disabled';
        if (!$c['enabled']) return 'integration_disabled';
        if (!Options::user_authorized((int)($c['granted_by']??0))) return 'grant_revoked';
        $service=$target==='ga4'?'ga':'ads';
        if (!Connections::enabled($service)||($service==='ga'?!Options::ga_enabled():!Options::ads_enabled())) return 'service_disabled';
        if (Operation::profile($service,'write')) return 'service_read_only';
        if (is_wp_error(Credentials::current())) return 'credential_unavailable';
        if ($target==='ga4' && (!$c['measurement_id']||!$c['stream'])) return 'destination_missing';
        if ($target==='google_ads' && (!$c['customer_id']||!$c['conversion_action'])) return 'destination_missing';
        if ($target==='ga4' && Options::get_secret(self::SECRET)==='') return 'mp_secret_missing';
        if ($target==='google_ads' && Options::get_secret(Options::ADS_DEVELOPER_TOKEN)==='') return 'ads_developer_token_missing';
        $url=$target==='ga4'?GoogleClient::HOST_MP.'/mp/collect':Ads\DataManager::BASE.'/events:ingest';
        if ($target==='google_ads'&&class_exists('F3Base_Conversoes_Servidor')&&!is_callable(['F3Base_Conversoes_Servidor','reconciliar'])) return 'core_async_unsupported';
        $opts=$target==='ga4'?self::http_options($target):Ads\DataManager::options($c);
        $opts['query']=$target==='ga4'?['measurement_id'=>$c['measurement_id']]:[];
        if (Policy::check_http('POST',$url,null,$opts)) return 'resource_not_permitted';
        if (Storage\Admission::dispatch_guard()) return 'storage_or_recovery_unavailable';
        return null;
    }
    public function capabilities(): array {
        return Connections::run($this->connection,function() {
            $c=self::read();
            $reason=$this->selection_error;
            if (!in_array($this->target,['ga4','google_ads'],true)) $reason='unsupported_destination';
            if (is_wp_error($c)) {
                $reason='configuration_unreadable';
                $c=self::defaults();
            }
            if (!$reason) $reason=self::local_reason($c,$this->target);
            $proof=$c['verified'][$this->target]??[];
            if (!$reason && (!hash_equals(self::proof_revision($c,$this->target),(string)($proof['revision']??'')) || ($proof['expires']??0)<=time())) $reason='verification_required';
            return ['contract'=>self::CONTRACT,'ready'=>$reason===null,'destination_ref'=>'google:'.$this->target.':'.self::identity($c,$this->target),
                'reason'=>$reason??'ok','connection_id'=>$this->connection,'verified_at'=>$proof['at']??null,'verification_expires_at'=>$proof['expires']??null,
                'async_reconciliation'=>$this->target==='google_ads'?Ads\DataManager::RECONCILE:null,
                'renewal'=>$c['renewal'][$this->target]??null,
                'evidence'=>$this->target==='ga4'?'http_received':'single_event_request_status','analytics_homologated'=>false];
            });
    }
    private static function status_capability(string $target): array {
        $selected=self::adapter(null,$target,self::CONTRACT);
        return (new self($target,null,$selected->selection_error))->capabilities();
    }
    public static function status(array $input=[]): array {
        if (!Options::authorized()) return self::fail('not_authorized');
        $c=self::read();
        if (is_wp_error($c)) return self::fail($c->get_error_code());
        return Response::ok(['ok'=>true,'revision'=>self::revision(),'connection_id'=>Connections::id(),
                'config'=>array_intersect_key($c,self::defaults()),'ga4'=>self::status_capability('ga4'),
                'google_ads'=>self::status_capability('google_ads'),'mp_secret_present'=>Options::get_secret(self::SECRET)!=='',
                'ads_eligibility_source'=>$c['verified']['google_ads']['eligibility_source']??null,'core_transport'=>self::core_transport(),
                'google_checks_performed'=>false]);
    }
    public static function core_transport(): array {
        if (!is_callable(['F3Base_Conversoes_Contexto','snapshot'])) return ['ok'=>false,'code'=>'core_absent'];
        try {
            $out=\F3Base_Conversoes_Contexto::snapshot(['contract'=>'site-conversion-purposes/1.1.0']);
            $schema=require __DIR__.'/Data/CoreTransport140.php';
            return ContractSchema::valid($out,$schema)?$out:['ok'=>false,'code'=>'core_unsupported'];
        }
        catch (\Throwable $e) {
            return ['ok'=>false,'code'=>'core_unsupported'];
        }
    }
    private static function fail(string $code,array $extra=[]): array {
        return Response::fail(new \WP_Error('f3_google_delivery_'.$code,'Conversões Google: '.$code),['ok'=>false,'code'=>$code]+$extra);
    }
    private static function locked(callable $callback,bool $background=false): array {
        if (!$background&&!Options::authorized()) return self::fail('not_authorized');
        return Recovery::run(static function() use($callback) {
            $lock=Lock::acquire('conversion-delivery:'.Connections::id(),90);
            if (!$lock) return self::fail('busy');
            try {
                return $callback($lock);
            }
            finally {
                Lock::release($lock);
            }
            });
    }
    public static function configure(array $v): array {
        return self::locked(static function($lock) use($v) {
            $revision=self::revision();
            if (!$revision||!hash_equals($revision,(string)($v['expected_revision']??''))) return self::fail('revision_conflict',['conflict'=>true]);
            $c=$v['config']??null;
            if (!is_array($c)||!ContractSchema::valid($c,self::config_schema())) return self::fail('invalid_config');
            $c+=self::defaults();
            $c['measurement_id']=self::measurement_id();
            if ($c['conversion_action'] && !str_starts_with($c['conversion_action'],'customers/'.$c['customer_id'].'/')) return self::fail('action_customer_mismatch');
            if (!empty($v['clear_mp_secret'])&&!empty($v['mp_secret'])) return self::fail('secret_action_conflict');
            if (isset($v['mp_secret'])&&(!is_string($v['mp_secret'])||strlen($v['mp_secret'])>256||preg_match('/[\x00-\x20\x7f]/',$v['mp_secret']))) return self::fail('invalid_secret');
            // Revoke old proofs durably before replacing a secret. A partial save cannot retain readiness.
            $old=self::read();
            $unchanged=!is_wp_error($old)&&array_intersect_key($old,self::defaults())===$c&&($old['granted_by']??0)===get_current_user_id()&&empty($v['clear_mp_secret'])&&empty($v['mp_secret']);
            if ($unchanged) return Response::ok(['ok'=>true,'persisted'=>true,'changed'=>false,'revision'=>self::revision(),'verification_required'=>false]);
            $c['granted_by']=get_current_user_id();
            $c['verified']=[];
            if (!Lock::owned($lock)) return self::fail('lock_lost');
            $r=Options::set(self::CONFIG,$c);
            if (empty($r['success'])) return self::fail('configuration_not_saved');
            if (!empty($v['clear_mp_secret'])||!empty($v['mp_secret'])) {
                $r=Options::set_secret(self::SECRET,!empty($v['clear_mp_secret'])?'':$v['mp_secret']);
                if (empty($r['success'])) return self::fail('secret_not_saved',['revision'=>self::revision(),'persisted'=>true,'ready'=>false]);
            }
            return Response::ok(['ok'=>true,'persisted'=>true,'revision'=>self::revision(),'verification_required'=>true]);
            });
    }
    private static function http_options(string $target): array {
        return ['auth'=>$target!=='ga4','connector'=>$target==='ga4'?'ga':'ads',
            'operation_id'=>$target==='ga4'?'measurementprotocol.collect':'googleads.customers.uploadClickConversions',
            'mode'=>'write','retries'=>0,'timeout'=>8,'budget_seconds'=>12,'headers'=>$target==='google_ads'?Ads\AdsApi::headers():[]];
    }
    private static function mp(array $c,array $body,bool $debug) {
        $opts=self::http_options('ga4');
        $opts['query']=['measurement_id'=>$c['measurement_id'],'api_secret'=>Options::get_secret(self::SECRET)];
        return GoogleClient::request('POST',GoogleClient::HOST_MP.($debug?'/debug':'').'/mp/collect',$body,$opts);
    }
    public static function verify(array $v): array { return self::verify_internal($v,false); }
    private static function verify_internal(array $v,bool $background): array {
        return self::locked(static function($lock) use($v,$background) {
            $revision=self::revision();
            if (!$revision||!hash_equals($revision,(string)($v['expected_revision']??''))) return self::fail('revision_conflict',['conflict'=>true]);
            $target=$v['target']??'';
            $c=self::read();
            if (is_wp_error($c)||!in_array($target,['ga4','google_ads'],true)) return self::fail('invalid_target');
            if ($background&&!hash_equals(self::proof_revision($c,$target),(string)($c['verified'][$target]['revision']??''))) return self::fail('verification_required');
            if ($reason=self::local_reason($c,$target)) return self::fail($reason);
            $before=self::proof_revision($c,$target);
            $result=Execution::run(static function() use($target,$c,$v) {
                if ($target==='ga4') {
                    $read=['connector'=>'ga','operation_id'=>'analyticsadmin.properties.dataStreams.get','mode'=>'read','retries'=>0,'scopes'=>Credentials::scopes_for('ga')];
                    $stream=GoogleClient::request('GET',GoogleClient::HOST_GA_ADMIN.'/v1beta/'.$c['stream'],null,$read);
                    if (is_wp_error($stream)||($stream['name']??'')!==$c['stream']||($stream['webStreamData']['measurementId']??'')!==$c['measurement_id']) return self::fail('stream_unverified');
                    $read['operation_id']='analyticsadmin.properties.dataStreams.measurementProtocolSecrets.list';
                    $found=false;
                    $page='';
                    $secret=Options::get_secret(self::SECRET);
                    for($n=0;$n<10;$n++) {
                        $read['query']=$page?['pageToken'=>$page]:[];
                        $secrets=GoogleClient::request('GET',GoogleClient::HOST_GA_ADMIN.'/v1beta/'.$c['stream'].'/measurementProtocolSecrets',null,$read);
                        if (is_wp_error($secrets)) return self::fail('mp_secret_unverified');
                        foreach ($secrets['measurementProtocolSecrets']??[] as $s) if (is_string($s['secretValue']??null)&&hash_equals($secret,$s['secretValue'])) $found=true;
                        $page=$secrets['nextPageToken']??'';
                        if ($found||!$page) break;
                    }
                    if (!$found) return self::fail('mp_secret_unverified');
                    $body=['client_id'=>'1.1','events'=>[['name'=>'generate_lead','params'=>['session_id'=>time(),'event_id'=>str_repeat('0',32)]]],'validation_behavior'=>'ENFORCE_RECOMMENDATIONS'];
                    $debug=self::mp($c,$body,true);
                    if (is_wp_error($debug)||($debug['validationMessages']??null)!==[]) return self::fail('ga4_prevalidation_failed');
                    return ['ok'=>true,'source'=>'admin_api_secret_match_and_debug'];
                }
                return Ads\DataManager::verify($c);
                },18,static function() use($lock,$revision,$c,$target,$before) {
                    return Lock::owned($lock)&&self::revision()===$revision&&!self::local_reason($c,$target)&&hash_equals($before,self::proof_revision($c,$target))?null:new \WP_Error('f3_google_verification_changed','Autorização alterada durante a verificação.');
                });
            if (empty($result['ok'])) return $result;
            if (!Lock::owned($lock)||self::revision()!==$revision||!hash_equals($before,self::proof_revision($c,$target))) return self::fail('revision_conflict',['conflict'=>true]);
            $c['verified'][$target]=['revision'=>$before,'at'=>time(),'expires'=>time()+DAY_IN_SECONDS,'by'=>$c['granted_by'],'eligibility_source'=>$result['source']];
            foreach (['value','currency'] as $key) if (isset($result[$key])) $c['verified'][$target][$key]=$result[$key];
            $c['renewal'][$target]=['last_at'=>time(),'result'=>'success','next_attempt'=>time()+12*HOUR_IN_SECONDS,'failures'=>0];
            $r=Options::set(self::CONFIG,$c);
            return empty($r['success'])?self::fail('verification_not_saved'):Response::ok(['ok'=>true,'persisted'=>true,'revision'=>self::revision(),'verification_expires_at'=>$c['verified'][$target]['expires'],'analytics_homologated'=>false]);
            },$background);
    }
    /** Called by the existing bounded executor, never by status reads. */
    public static function renew_due(): array {
        $out=[];
        foreach (['ga4','google_ads'] as $target) {
            if (Execution::remaining()<3) break;
            $c=self::read();
            if (is_wp_error($c)||empty($c['enabled'])) break;
            $proof=$c['verified'][$target]??[];
            if (!$proof||!hash_equals(self::proof_revision($c,$target),(string)($proof['revision']??''))) continue;
            $renew=$c['renewal'][$target]??[];
            if (($renew['next_attempt']??($proof['at']+12*HOUR_IN_SECONDS))>time()) continue;
            $before=self::revision();
            $r=self::verify_internal(['target'=>$target,'expected_revision'=>$before],true);
            $out[$target]=['success'=>!empty($r['success']),'code'=>$r['code']??'verification_failed'];
            if (!empty($r['success'])) {
                self::renewal_incident($target,false);
                continue;
            }
            // Reacquire before updating retry metadata: a simultaneous admin save wins.
            self::locked(static function($lock) use($before,$target,$r) {
                if (self::revision()!==$before) return self::fail('revision_conflict');
                $c=self::read();if (is_wp_error($c)) return self::fail('configuration_unreadable');
                $n=(int)($c['renewal'][$target]['failures']??0)+1;
                $c['renewal'][$target]=['last_at'=>time(),'result'=>'failed','code'=>$r['code']??'verification_failed',
                    'failures'=>$n,'next_attempt'=>time()+min(3600,300*(2**min(4,$n-1)))];
                $saved=Options::set(self::CONFIG,$c);
                if (!empty($saved['success'])) self::renewal_incident($target,true);
                return $saved;
            },true);
        }
        return $out;
    }
    private static function renewal_incident(string $target,bool $failed): void {
        $id=hash('sha256',Connections::id().'|conversion_renewal|'.$target);
        $old=Records::get('incident',$id);
        if (!$old&&!$failed) return;
        $name=$target==='ga4'?'Google Analytics':'Google Ads';
        $incident=['id'=>$id,'connection_id'=>Connections::id(),'event'=>'conversion_renewal','resource'=>$name,
            'status'=>$failed?'open':'resolved','code'=>'verification_renewal_failed',
            'action'=>'Confira o acesso da conta, o segredo e o destino na aba Conversões. A renovação será tentada novamente automaticamente.',
            'created_at'=>$old['created_at']??time(),'updated_at'=>time(),'generation'=>($old['generation']??0)+1,
            'email_state'=>$old['email_state']??'pending','task'=>'renewal_notice'];
        $notify=$failed&&(!$old||($old['status']??'')!=='open'||($old['email_state']??'')==='failed');
        if ($notify) $incident['email_state']='dispatching';
        if (empty(Records::put('incident',$id,$incident)['success'])||!$notify) return;
        // Persist notification intent first. wp_mail acceptance is not mailbox delivery.
        try {$ok=wp_mail(get_option('admin_email'),'Fator3 — Verificação de conversões precisa de atenção',
            'A renovação da verificação de '.$name.' falhou em '.home_url().".\n".$incident['action']);}
        catch (\Throwable $e) {$ok=false;}
        $incident['email_state']=$ok?'accepted':'failed';
        Records::put('incident',$id,$incident);
    }
    /** Optional read-only extension. Never ingest or reconstruct a missing receipt. */
    public function reconcileBound(string $recordId,string $destinationRef): array {
        if ($this->target!=='google_ads'||!preg_match('/^[a-f0-9]{32}$/D',$recordId)||$destinationRef==='') return ['status'=>'incerto','code'=>'reconciliation_invalid'];
        return Connections::run($this->connection,function() use($recordId,$destinationRef) {
            return Recovery::run(function() use($recordId,$destinationRef) {
                $lock=Lock::acquire('conversion-delivery:'.Connections::id(),90);
                if (!$lock) return ['status'=>'incerto','code'=>'reconciliation_busy'];
                try {
                    $c=self::read();
                    if (is_wp_error($c)||self::local_reason($c,'google_ads')||!hash_equals($destinationRef,'google:google_ads:'.self::identity($c,'google_ads'))) return ['status'=>'incerto','code'=>'reconciliation_not_authorized'];
                    return Execution::run(fn()=>Ads\DataManager::reconcile($recordId,$destinationRef,$c),12,function() use($lock,$destinationRef) {
                        $now=self::read();
                        return !is_wp_error($now)&&Lock::owned($lock)&&!self::local_reason($now,'google_ads')&&hash_equals($destinationRef,'google:google_ads:'.self::identity($now,'google_ads'))?null:new \WP_Error('f3_google_reconcile_guard','Consulta suspensa.');
                    });
                } catch (\Throwable $e) {return ['status'=>'incerto','code'=>'reconciliation_unknown'];}
                finally {Lock::release($lock);}
            });
        });
    }
    private static function refused(string $code): array {
        return ['status'=>'recusado','non_delivery_proven'=>true,'code'=>$code,'retry_after'=>3600];
    }
    public function sendBound(array $p,string $destinationRef): array {
        if($destinationRef===''||strlen($destinationRef)>191) return self::refused('destination_mismatch');
        return $this->dispatch($p,$destinationRef);
    }
    public function send(array $p): array { return $this->dispatch($p,null); }
    private function dispatch(array $p,?string $destinationRef): array {
        // Core 1.41 binds the accepted destination with sendBound; send remains for older consumers.
        // There is no REST/ability dispatch endpoint. The stored administrator grant is rechecked below.
        return Connections::run($this->connection,function() use($p,$destinationRef) {
            if (empty($this->capabilities()['ready'])) return self::refused('not_ready');
            return Recovery::run(function() use($p,$destinationRef) {
                $lock=Lock::acquire('conversion-delivery:'.Connections::id(),90);
                if (!$lock) return self::refused('busy');
                try {
                    if (empty($this->capabilities()['ready'])) return self::refused('not_ready');
                    $c=self::read();
                    if($destinationRef!==null&&!hash_equals($destinationRef,'google:'.$this->target.':'.self::identity($c,$this->target))) return self::refused('destination_mismatch');
                    $expected=self::proof_revision($c,$this->target);
                    $dispatchRef='google:'.$this->target.':'.self::identity($c,$this->target);
                    return Execution::run(fn()=>$this->deliver($p,$c),18, function() use($lock,$c,$expected,$dispatchRef) {
                        // Read the current identity, not just the configuration captured before debug/token HTTP.
                        $current=$this->capabilities();
                        if (!hash_equals($dispatchRef,$current['destination_ref'])) return new \WP_Error('f3_google_delivery_destination_mismatch','Destino de conversão alterado.',['operation_outcome'=>'not_applied']);
                        return Lock::owned($lock)&&!empty($current['ready'])&&hash_equals($expected,self::proof_revision($c,$this->target))?null:new \WP_Error('f3_google_delivery_authorization_changed','Autorização de conversão alterada.',['operation_outcome'=>'not_applied']);
                        });
                }
                catch (\Throwable $e) {
                    return ['status'=>'incerto','code'=>'dispatch_exception'];
                }
                finally {
                    Lock::release($lock);
                }
                });
            });
    }
    private static function dispatch_refusal($result): ?array {
        // Only our pre-dispatch fence proves non-delivery; provider/network errors stay uncertain.
        if (!is_wp_error($result)) return null;
        $codes=['f3_google_delivery_destination_mismatch'=>'destination_mismatch','f3_google_delivery_authorization_changed'=>'authorization_changed'];
        $code=$codes[$result->get_error_code()]??null;
        return $code!==null?self::refused($code):null;
    }
    private function deliver(array $p,array $c): array {
        if (!is_string($p['record_id']??null)||!preg_match('/^[a-f0-9]{32}$/D',$p['record_id'])||($p['event_id']??'')!==$p['record_id']) return self::refused('invalid_identity');
        if (!is_string($p['occurred_at']??null)||!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/D',$p['occurred_at'])) return self::refused('invalid_time');
        $stamp=strtotime($p['occurred_at']);
        if (!$stamp||$stamp>time()) return self::refused('invalid_time');
        if ($this->target==='ga4') {
            if (($p['measurement_id']??'')!==$c['measurement_id']||($p['event_name']??'')!=='generate_lead'||!is_string($p['client_id']??null)||!preg_match('/^[0-9]{1,20}\.[0-9]{1,20}$/D',$p['client_id'])||!is_string($p['session_id']??null)||!preg_match('/^[1-9][0-9]{0,19}$/D',$p['session_id'])||!is_int($p['timestamp_micros']??null)||intdiv($p['timestamp_micros'],1000000)!==$stamp||$stamp<time()-72*HOUR_IN_SECONDS) return self::refused('ga4_identity_or_time_invalid');
            $params=['session_id'=>$p['session_id'],'event_id'=>$p['event_id']];
            if (isset($p['engagement_time_msec'])) {
                if (!is_int($p['engagement_time_msec'])||$p['engagement_time_msec']<0) return self::refused('invalid_engagement');
                $params['engagement_time_msec']=$p['engagement_time_msec'];
            }
            $body=['client_id'=>$p['client_id'],'timestamp_micros'=>$p['timestamp_micros'],'consent'=>['ad_user_data'=>'DENIED','ad_personalization'=>'DENIED'],'events'=>[['name'=>'generate_lead','params'=>$params]]];
            $validation=self::mp($c,$body+['validation_behavior'=>'ENFORCE_RECOMMENDATIONS'],true);
            if ($refused=self::dispatch_refusal($validation)) return $refused;
            if (is_wp_error($validation)||($validation['validationMessages']??null)!==[]) return self::refused('ga4_prevalidation_failed');
            $r=self::mp($c,$body,false);
            if ($refused=self::dispatch_refusal($r)) return $refused;
            return is_wp_error($r)?['status'=>'incerto','code'=>'ga4_receipt_unknown']:['status'=>'entregue','evidence'=>'http_received','processed'=>null];
        }
        $ids=$p['click_ids']??null;
        if (!is_array($ids)||count($ids)!==1||array_diff(array_keys($ids),['gclid','gbraid','wbraid'])) return self::refused('ambiguous_click_identifiers');
        $click=reset($ids);
        if (!is_string($click)||!preg_match('/^[A-Za-z0-9._~-]{1,500}$/D',$click)||($p['order_id']??'')!==$p['record_id']||($p['ad_user_data']??'')!=='GRANTED'||$stamp<time()-90*DAY_IN_SECONDS) return self::refused('ads_payload_invalid');
        return Ads\DataManager::send($p,$c,'google:google_ads:'.self::identity($c,'google_ads'));
    }
    public static function config_schema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['enabled'],'properties'=>[
                'enabled'=>['type'=>'boolean'],'measurement_id'=>['type'=>'string','pattern'=>'^(G-[A-Z0-9]+)?$'],
                'stream'=>['type'=>'string','pattern'=>'^(properties/[0-9]+/dataStreams/[0-9]+)?$'],
                'customer_id'=>['type'=>'string','pattern'=>'^([0-9]{10})?$'],
                'conversion_action'=>['type'=>'string','pattern'=>'^(customers/[0-9]{10}/conversionActions/[0-9]+)?$']]];
    }
    public static function status_schema(): array {
        $s=['type'=>'string'];
        $b=['type'=>'boolean'];
        $n=['type'=>['integer','null']];
        $cap=['type'=>'object','properties'=>['contract'=>$s,'ready'=>$b,'destination_ref'=>$s,'reason'=>$s,'connection_id'=>$s,'verified_at'=>$n,'verification_expires_at'=>$n,'evidence'=>$s,'analytics_homologated'=>$b,'async_reconciliation'=>['type'=>['string','null']],'renewal'=>['type'=>['object','null']]]];
        return ['type'=>'object','properties'=>['success'=>$b,'ok'=>$b,'revision'=>$s,'connection_id'=>$s,'config'=>self::config_schema(),'ga4'=>$cap,'google_ads'=>$cap,'mp_secret_present'=>$b,'core_transport'=>['type'=>'object'],'google_checks_performed'=>$b]];
    }
    public static function register(): void {
        $rev=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        $definitions=[
            'conversion-delivery-status'=>['status',[],[]],
            'configure-conversion-delivery'=>['configure',['expected_revision'=>$rev,'config'=>self::config_schema(),'mp_secret'=>['type'=>'string','maxLength'=>256],'clear_mp_secret'=>['type'=>'boolean']],['expected_revision','config']],
            'verify-conversion-delivery'=>['verify',['expected_revision'=>$rev,'target'=>['type'=>'string','enum'=>['ga4','google_ads']],
                    'eligibility_receipt'=>['type'=>'object','additionalProperties'=>false,'required'=>['customer_id','conversion_action','successful_upload_confirmed','request_id'],
                        'properties'=>['customer_id'=>['type'=>'string'],'conversion_action'=>['type'=>'string'],'successful_upload_confirmed'=>['type'=>'boolean'],'request_id'=>['type'=>'string','maxLength'=>200]]]],['expected_revision','target']]
        ];
        foreach ($definitions as $name=>$d) Ability::register('google/'.$name,'any',[
                'label'=>'Conversões Google: '.$name,'description'=>'Contrato Core 1.0.0. Configurar e verificar explicitamente; status local não chama fornecedor.',
                'mode'=>$d[0]==='status'?'read':'write','input_schema'=>['properties'=>$d[1],'required'=>$d[2]],
                'callback'=>[self::class,$d[0]],'output_schema'=>self::status_schema()]);
    }
    public static function screen(): void {
        Admin\ConversionScreen::render();
    }
}
