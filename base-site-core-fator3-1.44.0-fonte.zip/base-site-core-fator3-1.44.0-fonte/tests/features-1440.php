<?php
require __DIR__.'/bootstrap.php';
wp_get_abilities();global $wpdb;
raw('timezone_string','America/Sao_Paulo');
check(F3Base_Qualidade::instante_local('2026-10-21T01:18')===strtotime('2026-10-21 04:18:00 UTC'),'246_datetime_usa_fuso_site');
check(F3Base_Qualidade::instante_local('2026-02-30T01:18')===0,'246_data_invalida_recusada');
raw('timezone_string','America/New_York');check(F3Base_Qualidade::instante_local('2026-03-08T02:30')===0,'246_hora_inexistente_DST_recusada');raw('timezone_string','America/Sao_Paulo');
$note=F3Base_Contato_Apresentacao::nota(array('capturado_em'=>'2026-10-21 04:18:10'),'fixture');check(str_contains($note,'21/10/2026 01:18:10 -03:00'),'256_nota_local_com_offset');
check(F3Base_Options::declaracao('f3base_meta_janela')['subcampos']['conferida_em']['html_tipo']==='date','246_meta_data_nativa');check(F3Base_Options::declaracao('f3base_gsc')['subcampos']['inicio']['html_tipo']==='date','246_gsc_data_nativa');
$before=$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Vitais::tabela());F3Base_Vitais::instalar();check(F3Base_Vitais::pronta(),'261_schema_pronto');
$today=wp_date('Y-m-d');$path='/fixture-144/';$wpdb->delete(F3Base_Vitais::tabela(),array('caminho'=>$path));
function sample144($id,$n=1,$a=null){$s=array('id'=>'fixture144_'.$id,'dispositivo'=>'desktop','sequencia'=>$n);if($a!==null){$s['atribuicao']=$a;}return $s;}
$attr=array('alvo'=>'body:nth-of-type(1)>button:nth-of-type(1)','tipo'=>'ponteiro','origem_script'=>'https://static.example.test','loaf'=>true,'fases'=>array('entrada'=>50,'processamento'=>100,'apresentacao'=>50));
check(F3Base_Vitais::atribuicao_valida($attr),'260_atribuicao_fechada_valida');
foreach(array(array('alvo'=>'#email-ana@example.test'),array('texto'=>'segredo'),array('recurso'=>'https://host.test/a.jpg?email=ana'),array('recurso'=>'https://ana:pass@host.test/a.jpg'),array('recurso'=>'https://host.test/ana%40example.test.jpg'),array('origem_script'=>'https://host.test/private.js'),array('fases'=>array('entrada'=>-1))) as $i=>$bad){check(!F3Base_Vitais::atribuicao_valida($bad),'260_recusa_dado_inseguro_'.$i);}
foreach(array(100,200,300,400) as $i=>$value){check(F3Base_Vitais::gravar($today,$path,array('amostra'=>sample144('human'.$i,1,$attr),'detalhe'=>'INP','soma'=>$value),'nao_marcado',array('automacao'=>'nao_identificada')),'261_amostra_normal_'.$i);}
check(F3Base_Vitais::gravar($today,$path,array('amostra'=>sample144('robot',1,$attr),'detalhe'=>'INP','soma'=>13000),'nao_marcado',array('automacao'=>'provavel','automacao_motivos'=>'headless_chrome','automacao_regra'=>'fixture')),'261_amostra_automacao');
$wpdb->insert(F3Base_Vitais::tabela(),array('amostra'=>hash('sha256','legacy144'),'dia'=>$today,'caminho'=>$path,'metrica'=>'INP','dispositivo'=>'desktop','sequencia'=>1,'valor'=>20000));
$input=array('caminho'=>$path,'metrica'=>'INP','dispositivo'=>'desktop','dias'=>1);$r=wp_get_ability('f3base/vitais-ler')->execute($input);check(!is_wp_error($r)&&$r['ok'],'260_ability_tipificada');$row=$r['linhas'][0];check($row['p75']===300.0&&$row['amostras']===4&&$row['excluidas_automacao']===1&&$row['excluidas_legado']===1,'261_p75_sem_automacao_e_legado');check($row['alvos'][0]['amostras']===4&&$row['scripts'][0]['valor']==='https://static.example.test'&&$row['fase_dominante']==='processamento','260_leitura_alvos_scripts_fase');
$r=F3Base_Vitais::consultar($input+array('automacao'=>'todas'));check($r['linhas'][0]['amostras']===6&&$r['linhas'][0]['p75']===13000.0,'261_todas_explicito');
F3Base_Vitais::gravar($today,$path,array('amostra'=>sample144('human0',2,$attr),'detalhe'=>'INP','soma'=>250),'nao_marcado',array('automacao'=>'nao_identificada'));F3Base_Vitais::gravar($today,$path,array('amostra'=>sample144('human0',1,$attr),'detalhe'=>'INP','soma'=>9000));$r=F3Base_Vitais::consultar($input);check($r['linhas'][0]['amostras']===4&&$r['linhas'][0]['p75']===300.0,'260_revisao_idempotente_fora_ordem');
F3Base_Vitais::gravar($today,$path,array('amostra'=>sample144('robot',2,$attr),'detalhe'=>'INP','soma'=>100),'nao_marcado',array('automacao'=>'nao_identificada'));check(F3Base_Vitais::consultar($input)['linhas'][0]['excluidas_automacao']===1,'261_automacao_nao_rebaixada');
wp_set_current_user(0);check(F3Base_Vitais::consultar($input)['codigo']==='sem_permissao','260_leitura_privada');check(F3Base_Linkedin_Cliente::catalogo('formularios')['codigo']==='sem_permissao','249_catalogo_admin');wp_set_current_user(1);
// Two retained days inside a longer comparison period must be advertised at comparison level.
$t=F3Base_Editorial::tabela('editorial_diario');$cols=$wpdb->get_col('SHOW COLUMNS FROM '.$t);
$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE dia BETWEEN %s AND %s',$t,'2001-02-01','2001-02-20'));
$wpdb->insert($t,array('dia'=>'2001-02-09','post_id'=>0,'caminho'=>'/fixture/','metrica'=>'visualizacoes','contagem'=>4));
check(!$wpdb->last_error,'258_fixture_retencao');
$r=F3Base_Editorial_Relatorios::consultar(array('de'=>'2001-02-11','ate'=>'2001-02-20','comparar'=>true));check(($r['comparacao']['codigo']??'')==='anterior_parcial'&&$r['comparacao']['dias_retidos']===1&&$r['comparacao']['dias_periodo']===10&&$r['comparacao']['dias_com_audiencia_retida']===array('2001-02-09'),'258_anterior_parcial_explicito');check(isset($r['definicoes_sessoes']['sessoes_iniciadas']),'258_definicoes_sessoes');
F3Base_Formularios::estilo();check(wp_styles()->registered['f3base-formularios']->src===false,'262_css_sem_recurso_externo');check(str_contains(implode('',wp_styles()->get_data('f3base-formularios','after')),'.f3base-formulario'),'262_css_integral_inline');
evidence('features-1440');
