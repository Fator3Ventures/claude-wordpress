<?php
require __DIR__.'/bootstrap.php';require getenv('F3BASE_ROOT').'/companions/wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php';
use Fator3\LinkedIn\{Store,Api,Connections};
Store::install();wp_get_abilities();if(!wp_get_ability('linkedin/admin-options')){Api::abilities();}
$existing=Store::get('connection','fixture144');$saved=Api::dispatch('save-connection',array('connection_id'=>'fixture144','expected_revision'=>$existing['revision']??0,'token'=>'synthetic-linkedin','assets'=>array('leads'=>array('123'),'ads'=>array('123'))));check($saved['success'],'249_conexao_fixture');
$cfg=F3Base_Options::ler(F3Base_Linkedin::OPCAO);$cfg['integracoes']['principal']['cliente']='linkedin_plugin';$cfg['integracoes']['principal']['connection_id']='fixture144';$cfg['integracoes']['principal']['conta_id']='123';raw(F3Base_Linkedin::OPCAO,$cfg);
$calls=array();$change=false;
add_filter('pre_http_request',static function($pre,$args,$url)use(&$calls,&$change){
 if(wp_parse_url($url,PHP_URL_HOST)!=='api.linkedin.com'){return $pre;}$calls[]=$url;$path=wp_parse_url($url,PHP_URL_PATH);parse_str(wp_parse_url($url,PHP_URL_QUERY)?:'',$q);$body=array();
 if(str_ends_with($path,'leadForms')){$start=(int)($q['start']??0);$body=array('elements'=>array(),'paging'=>array('start'=>$start,'count'=>50,'total'=>51));for($i=$start;$i<min(51,$start+50);$i++){$body['elements'][]=array('id'=>(string)(1000+$i),'name'=>'Formulário '.$i,'versionId'=>'1','owner'=>array('sponsoredAccount'=>'urn:li:sponsoredAccount:123'));}}
 elseif(str_contains($path,'adCampaigns')){$body=array('elements'=>array(array('id'=>'700','name'=>'Campanha teste','account'=>'urn:li:sponsoredAccount:123')),'metadata'=>array());}
 elseif(str_ends_with($path,'adAccounts/123')){$body=array('id'=>'123','name'=>'Conta exemplo');}
 else {throw new RuntimeException('Unexpected LinkedIn fixture '.$path);}
 return array('response'=>array('code'=>200),'headers'=>array(),'body'=>wp_json_encode($body));
},999,3);
$r=F3Base_Linkedin_Integracoes::executar('principal',static fn()=>F3Base_Linkedin_Cliente::catalogo('formularios'));check($r['ok']&&count($r['linhas'])===50&&$r['linhas'][0]['name']==='Formulário 0'&&$r['cursor']!=='','249_descoberta_forms_publica_041');$cursor=$r['cursor'];
$r=F3Base_Linkedin_Integracoes::executar('principal',static fn()=>F3Base_Linkedin_Cliente::catalogo('formularios',$cursor));check($r['ok']&&count($r['linhas'])===1&&$r['cursor']==='','249_paginacao_forms');
$r=F3Base_Linkedin_Integracoes::executar('principal',static fn()=>F3Base_Linkedin_Cliente::catalogo('campanhas'));if(empty($r['ok'])){echo wp_json_encode(array('result'=>$r,'api'=>Api::dispatch('admin-options',array('kind'=>'objects','channel'=>'ads','account_id'=>'123','connection_id'=>'fixture144','report'=>'campaigns'))))."\n";}check($r['ok']&&$r['linhas'][0]['id']==='700'&&$r['linhas'][0]['name']==='Campanha teste','249_descoberta_campanhas_publica');
$old=Connections::get('fixture144');Api::dispatch('save-connection',array('connection_id'=>'fixture144','expected_revision'=>$old['revision'],'label'=>'Nova revisão'));
$r=F3Base_Linkedin_Integracoes::executar('principal',static fn()=>F3Base_Linkedin_Cliente::catalogo('formularios',$cursor));check(!$r['ok']&&$r['codigo']==='configuracao_alterada','249_revisao_divergente_recusada');
check(F3Base_Options::ler(F3Base_Linkedin::OPCAO)['integracoes']['principal']['cliente']==='linkedin_plugin','249_cliente_preservado');check(empty(Connections::get('fixture144')['forms']),'249_catalogo_nao_concede_forms');
wp_set_current_user(0);check(!F3Base_Linkedin_Cliente::catalogo('formularios')['ok'],'249_sem_permissao');wp_set_current_user(1);$cfg['integracoes']['principal']['cliente']='core';raw(F3Base_Linkedin::OPCAO,$cfg);
evidence('linkedin-1440');
