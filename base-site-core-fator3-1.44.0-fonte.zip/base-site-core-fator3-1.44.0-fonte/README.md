# Fator3 Site Core 1.44.0 — fonte

Runtime em work/plugin/base-site-core-fator3. Build e provas em build/README.md. Instalador é artefato separado; este ZIP não é instalável. Consulte o relatório para pendências de homologação.
