# Plano — Fator3 Site Core 1.44.0

Base imutável: 1.43.0, instalador SHA-256 5a7c02abb97f7161617ddfd8e4d28faf2fdb22e4ae5d4ed75416dc68d76ee9e7.
Entrada: Fator3 Site Core(20261021-141715).md. Escopo: 246, 248, 249, 256, 258–262.
Companheiros: MCP 0.25.0, Google 0.16.0, Meta 0.4.1, LinkedIn 0.4.1.

1. Datas nativas no fuso do site, revisão de descrições e títulos específicos de mapeamento.
2. Descoberta LinkedIn pela ability pública linkedin/admin-options já existente na 0.4.1: forms/leads e objects/ads/campaigns. Consumidor mantém SDK 1.1.0 para ingestão e as concessões existentes. Leitura administrativa, sem copiar credenciais, alterar cliente ou criar assinaturas. Paginação confere revisão da conexão. Nenhuma mudança necessária no plugin LinkedIn.
3. Nota do contato no horário local e comparação parcial com dias de audiência retida explícitos.
4. Recuperação administrativa por destino: confirmação de não entrega e vínculo ready, auditoria, simulação explicativa, preservação do transporte original. Sem mudança no contrato Google 0.16.0 nem envio fora da fila do Core.
5. INP/LCP com atribuição limitada e sem texto/IDs/classes do DOM; automação armazenada junto à amostra. Legado sem classificação continua desconhecido, excluído da leitura padrão; sem pareamento heurístico.
6. CSS pequeno dos formulários embutido no head antes das folhas dos temas.

Validação: fixtures locais de privacidade, idempotência, concorrência, paginação, datas, cobertura e desempenho; navegador; instalação limpa e atualização direta 1.43→1.44; ciclo no Site-Teste compartilhado preservando dados. Nenhum envio real de anúncios/CRM/e-mail usado como teste. Aceites dependentes de conta, frota e sete dias de dados ficam explicitamente pendentes.

## Pedido adicional 263 — 21/10/2026

Capturar por campo estado, regra, motivo de telefone e valor em tentativa barrada; sessão/instância, correção e envio/saída observada. Ability privada com f3base_ler_leads e agregação sem valores em comportamento-ler. Tabela isolada, cifras autenticadas, retenção padrão 30 dias configurável de 1 a 90, interruptor por site e eliminação pelo contato/sessão e pelo titular. Nenhum repasse a avisos, Pipedrive ou plataformas. Aceite local sintético e pendência explícita de comprovação no ctooffice após implantação na frota.
