# Reproduzir a rodada 0.32.0

O executor PHP/Python exige PHP 8.3+ de 64 bits com mysqli, mbstring, JSON e criptografia, uma árvore WordPress 7.1.4+ com wp-config-sample.php padrão e um servidor MySQL/MariaDB dedicado em **127.0.0.1**, com banco descartável de nome começando por meta32lab. A bancada desta edição usou WordPress 7.1.4, PHP 8.4.27 e MariaDB 11.8.6. Não execute estes scripts em um WordPress compartilhado. As raízes /tmp e seus prefixos são aleatórios por cenário. O runner remove os arquivos temporários ao terminar. Descarte o banco dedicado ao final.

Use o ZIP oficial 0.31.0 em --base e o instalador 0.32.0 fechado em --candidate. Na pasta --companions, coloque os cinco instaladores citados em evidence/032/matriz-entradas.json com os nomes de distribuição sem sufixo de cópia. O runner confere o SHA-256 e o slug de cada um antes de extrair. Não há alteração dos acompanhantes.

    F3_QA_DB=meta32lab F3_QA_DB_USER=root python3 tests/lab/review032.py \
      --php /caminho/php --wp-core /caminho/wordpress --db-port 33932 \
      --base /entregas/wp-mcp-meta-fator3-0.31.0-instalador.zip \
      --candidate /entregas/wp-mcp-meta-fator3-0.32.0-instalador.zip \
      --companions /entregas/acompanhantes --out /tmp/resultado-meta32

F3_QA_DB_PASSWORD é opcional; use exclusivamente a senha desse banco temporário. Mantenha os segredos fora das evidências. Cada processo PHP carrega a versão que está no diretório correspondente; a troca de arquivos não desinstala o plugin. A base salva uma política de recuperação personalizada, duas configurações de retenção, agendas, dados, histórico e checkpoints. A candidata compara os digests e valores públicos em novo processo.

A suíte testa a carga dos assets por rota e capacidade, a preservação dos endereços de navegação e dos contratos da 0.31.0, a política e administração, recuperação, métricas, incidentes e dados de histórico. O teste de lacunas distingue a abertura do recibo pelo Meta após 26 horas da entrega por e-mail sob a carência própria do Core. Após verificar a espera padrão, somente a massa privada configura a carência zero e constata uma abertura e uma recuperação. O teste de convivência usa as implementações reais de Core e MCP, percorre os 32 documentos por páginas e verifica a confirmação de política. Graph e envio externo de e-mail são interceptados; o relatório não dá esses fornecedores por homologados. A prova visual da seção 7 usa navegador e massa sintética em instância separada: veja tests/visual e evidence/032.

Para regenerar exemplos execute o build inicialmente com F3_EXAMPLES_BOOTSTRAP=1 e F3_SOCIAL_PHP. Em instalação nova desse runtime (guarda F3_LAB_ROOT e flavor current), execute tests/docs/capture-examples.php e grave seu JSON em build/docs/examples/captured.json. Reconstrua sem a chave bootstrap e use o ZIP fechado nas verificações acima. Nenhum auxiliar de teste vai no instalador.
