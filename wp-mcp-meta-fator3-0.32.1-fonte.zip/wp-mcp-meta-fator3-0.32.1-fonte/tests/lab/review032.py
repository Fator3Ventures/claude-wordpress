"""Run isolated release checks against the provided installer and five pinned companions.

Needs an *already running* local MySQL/MariaDB on 127.0.0.1 and a disposable database.
Never pass a site database. Only a randomly generated prefix is used per scenario.
See RODADA-032.md. No commercial credentials, Graph requests or mail are required.
"""
import argparse, hashlib, json, os, secrets, shutil, subprocess, tempfile, zipfile
from pathlib import Path
testdir=Path(__file__).resolve().parents[1]
base_version='0.31.0'
candidate_version='0.32.0'
slug='wp-mcp-meta-fator3'
versions={'base-site-core-fator3':'1.100.1','wp-mcp-fator3':'0.54.0','wp-mcp-google-fator3':'0.42.0','wp-mcp-linkedin-fator3':'0.27.0','wp-mcp-pipedrive-fator3':'0.13.0'}
parser=argparse.ArgumentParser(__doc__)
for x in ['wp-core','php','base','candidate','companions','out']:parser.add_argument('--'+x,type=Path,required=True)
parser.add_argument('--db-port',type=int,required=True)
a=parser.parse_args()
db=os.environ.get('F3_QA_DB','')
if not db.startswith('meta32lab') or not db.isalnum():raise SystemExit('Disposable meta32lab database required.')
a.out.mkdir(parents=True,exist_ok=True)
core=a.wp_core.resolve();php=str(a.php.resolve());roots=[];sum_checks={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def install_files(archive,parent,root):
    hashes={}
    with zipfile.ZipFile(archive) as z:
        for i in z.infolist():
            n=Path(i.filename)
            if n.is_absolute() or '..' in n.parts or n.parts[0]!=root or (i.external_attr>>16)&0o170000==0o120000:raise ValueError('Unexpected archive path')
            if not i.is_dir():hashes[n]=hashlib.sha256(z.read(i)).hexdigest()
        z.extractall(parent)
    for n,h in hashes.items():
        if digest(parent/n)!=h:raise ValueError('Installed file differs: '+str(n))
    if len(hashes)!=len([p for p in (parent/root).rglob('*') if p.is_file()]):raise ValueError('Unexpected installed file')
    return len(hashes)
def instance(archive):
    root=Path(tempfile.gettempdir())/('f3qa022_'+secrets.token_hex(6)+'_');root.mkdir(mode=0o700);roots.append(root)
    wp=root/'wordpress';wp.mkdir();(root/'evidence').mkdir()
    for f in core.glob('*.php'):
        if f.name not in ('wp-config.php','wp-config-sample.php'):shutil.copy2(f,wp)
    shutil.copytree(core/'wp-admin',wp/'wp-admin');(wp/'wp-includes').symlink_to(core/'wp-includes',target_is_directory=True)
    (wp/'wp-content/plugins').mkdir(parents=True);mu=wp/'wp-content/mu-plugins';mu.mkdir()
    (mu/'isolate.php').write_text("<?php add_filter('pre_wp_mail','__return_true');add_filter('pre_http_request',static fn($p)=>$p===false?new WP_Error('lab_blocked'):$p,9999);")
    esc=lambda s:s.replace('\\','\\\\').replace("'","\\'")
    cfg=(core/'wp-config-sample.php').read_text().replace('database_name_here',db).replace('username_here',esc(os.environ.get('F3_QA_DB_USER','root'))).replace('password_here',esc(os.environ.get('F3_QA_DB_PASSWORD',''))).replace('localhost','127.0.0.1:'+str(a.db_port)).replace("'wp_';","'"+root.name+"';")
    while 'put your unique phrase here' in cfg:cfg=cfg.replace('put your unique phrase here',secrets.token_hex(32),1)
    cfg=cfg.replace("define( 'WP_DEBUG', false );","define('DISABLE_WP_CRON',true);define('WP_HTTP_BLOCK_EXTERNAL',true);define('WP_HOME','http://127.0.0.1');define('WP_SITEURL','http://127.0.0.1');define('WP_DEBUG',false);define('FS_METHOD','direct');")
    (wp/'wp-config.php').write_text(cfg);(wp/'wp-config.php').chmod(0o600)
    count=install_files(archive,wp/'wp-content/plugins',slug)
    return root,count
def run(root,script,key,extra=(),flavor='current'):
    env=os.environ|{'F3_LAB_ROOT':str(root),'F3_LAB_FLAVOR':flavor}
    result=subprocess.run([php,str(testdir/script),*extra],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if result.returncode or result.stderr:
        if result.returncode:print(result.stdout[-2000:].decode(errors='replace'))
        if result.stderr:print(result.stderr[-2000:].decode(errors='replace'))
    result.check_returncode()
    if result.stdout.strip():
        data=json.loads(result.stdout)
        if key:(a.out/(key+'.json')).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
        if 'total' in data and 'failed' in data:
            if data['failed']:raise ValueError(key+' reported a failure')
            sum_checks[key]=data['total']
    return result
def activate(root):
    plugins=root/'wordpress/wp-content/plugins'
    for name,vs in versions.items():
        pkg=a.companions/(name+'-'+vs+'-instalador.zip');expected=lock[name]
        if digest(pkg)!=expected:raise ValueError(name+' package/hash mismatch')
        install_files(pkg,plugins,name)
    run(root,'native/activate023.php','companions-active')
def clean():
    root,count=instance(a.candidate);run(root,'native/install.php','clean-install')
    run(root,'native/smoke.php','smoke');run(root,'native/admin032.php','admin-scope')
    r=subprocess.run([os.environ.get('PYTHON3','python3'),str(testdir/'docs/check.py'),php,str(root/'wordpress/wp-content/plugins'/slug)],capture_output=True,check=True)
    j=json.loads(r.stdout);assert j['failed']==0;sum_checks['docs']=j['total'];(a.out/'docs.json').write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
    return count
def upgrade():
    root,_=instance(a.base);run(root,'native/install.php','base-install',flavor='baseline');run(root,'native/preserve-policy032.php',None,['seed']);run(root,'native/seed-base030.php','base-seed',flavor='baseline')
    pluginroot=root/'wordpress/wp-content/plugins';(pluginroot/slug).rename(root/'outgoing')
    install_files(a.candidate,pluginroot,slug);run(root,'native/migrate.php','migration');run(root,'native/preserve-policy032.php','migration-policy',['verify'])
lock={x['slug']:x['zip_hash'] for x in json.loads((testdir.parent/'evidence/032/matriz-entradas.json').read_bytes())['acompanhantes']}
try:
    count=clean();upgrade()
    for name,scripts,companions in [
        ('matrix',['native/combination032.php'],True),('gaps',['native/gaps032.php'],True),
        ('metrics',['native/metrics031.php'],False),('recovery',['native/recovery031.php'],False),
        ('policy',['native/policy031.php'],False),('eligibility',['native/eligibility031.php'],False),
        ('budget',['regressions/diagnostics0190.php','regressions/budget031.php'],False)]:
        root,_=instance(a.candidate);run(root,'native/install.php',None)
        if companions:activate(root)
        for i,script in enumerate(scripts):run(root,script,'diagnostics' if name=='budget' and i==0 else name)
    out={'installer_sha256':digest(a.candidate),'base_sha256':digest(a.base),'files_per_candidate_install':count,'instances':len(roots),'suites':sum_checks,'total':sum(sum_checks.values()),'failed':0,'graph':'simulated','external_mails':0}
    (a.out/'native-summary.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps(out))
finally:
    # The dedicated DB belongs to the caller; discard it after all scenarios and visual checks.
    for root in roots:shutil.rmtree(root)
