# Rodada 0.32.1: duas atualizações de base e efeito no Core

Use apenas uma cópia local de WordPress ≥7.1.4, PHP 8.3+ 64 bits e MariaDB/MySQL dedicado no loopback. A suíte cria um prefixo privado por cenário e só aceita banco descartável cujo nome comece por meta32lab. Não forneça credenciais comerciais. Não aponte o runner ao banco de um site compartilhado.

A base deste roteiro é o instalador Meta 0.32.0; a candidata é o ZIP 0.32.1 final. O diretorio de acompanhantes deve conter os cinco ZIPs oficiais com os nomes e hashes de `evidence/032/matriz-entradas.json`. O verificador extrai e confere todos os arquivos em cada instância.

    F3_QA_DB=meta32lab35 F3_QA_DB_USER=root python3 tests/lab/review035.py \
      --php /caminho/php --wp-core /caminho/wordpress --db-port 33935 \
      --base /entregas/wp-mcp-meta-fator3-0.32.0-instalador.zip \
      --candidate /entregas/wp-mcp-meta-fator3-0.32.1-instalador.zip \
      --companions /entregas/acompanhantes --out /tmp/prova-meta-0321

O cenário de incidentes usa um WordPress exclusivo com o Core 1.100.1 real. O ensaio emula respostas HTTP da Graph e o avanço temporal no processo do Meta, limita o transporte no Core e lê a fila por `f3base/email-wordpress-fila-ler`. A convivência com os cinco acompanhantes ativos usa um prefixo separado, com MCP e as verificações de transporte do pacote. A suíte guarda os resultados focais em JSON. Entre as três opções verificadas na migração, duas ficam byte a byte; o marcador técnico da migração existente avança para `1:availability-035`, preservando sua etapa numérica anterior. Não há alteração de nomes.

Para **0.31.0 → 0.32.1**, use uma instalação descartável da 0.31.0 com o Core oficial ativo. Aplique `tests/native/incidents035.php` com a fase baseline e a versão de origem 0.31.0 conforme a ajuda no próprio script; troque apenas a árvore instalada do Meta pelo ZIP fechado, conservando banco e prefixo, e aplique a fase candidate. O arquivo `evidence/0321/migracao-direta-frota.json` contém os hashes e resultados. A data de envio da fila no Core segue o relógio do site; o tempo de 26 horas referido nas provas é o avanço controlado do relógio do Meta.

Veja também [prova visual local](../visual/PEDIDO-35.md), [prova no Site-Teste](../site/0321/README.md) e o roteiro da proposta isolada em `integration/035-core/`. Descarte o banco, a fila e a massa sintética ao terminar.
