// Usage: node tests/browser/connection-state032.cjs [installed assets/admin.js]
// Exercise the actual compiled client predicate without exposing a test API in wp-admin.
'use strict';
const {readFileSync}=require('node:fs'),{resolve}=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const file=process.argv[2]||resolve(__dirname,'../../build/assets/admin.js'),text=readFileSync(file,'utf8');
const start=text.indexOf('function connectionState('),end=text.indexOf('\nfunction renderConnections()',start);
assert(start>=0&&end>start,'No connection classifier in this client');
const classify=vm.runInNewContext('('+text.slice(start,end)+')'),now=1800000000;
const verified={enabled:true,token_configured:true,expires_at:now+1,credential_generation:2,identity:{validated_generation:2,app_verified:true}};
const cases=[
 ['Unconfigured active connection', {token_configured:false},'Não configurada','',false],
 ['Pause takes precedence over expiration', {enabled:false,expires_at:now-1},'Pausada','is-warn',true],
 ['Pause with blank token', {enabled:false,token_configured:false},'Pausada','is-warn',false],
 ['Expiry boundary', {expires_at:now},'Expirada','is-error',true],
 ['Expired yesterday', {expires_at:now-86400},'Expirada','is-error',true],
 ['No proof stored', {identity:null},'Pendente','is-warn',false],
 ['Credential changed after proof', {credential_generation:3},'Pendente','is-warn',false],
 ['Identity unverified for this generation', {identity:{validated_generation:2,app_verified:false}},'Pendente','is-warn',false],
 ['Legacy unversioned proof', {credential_generation:undefined,identity:{app_verified:true}},'Pendente','is-warn',false],
 ['Proof and expiry unknown', {identity:null,expires_at:undefined},'Pendente','is-warn',false],
 ['Indeterminate expiry', {expires_at:null},'Pendente','is-warn',true],
 ['Exact generation and validity confirmed', {},'Conectada','is-ok',true],
 ['Explicit nonexpiring credential', {expires_at:0},'Conectada','is-ok',true]
];
for(const [name,patch,label,tone,proof] of cases){
 const actual=classify({...verified,...patch},now);
 assert.deepEqual([actual.text,actual.tone,actual.checked],[label,tone,proof],name);
}
console.log(JSON.stringify({suite:'connection-state032',total:cases.length,failed:0,checks:cases.map(([name])=>({name,passed:true}))}));
