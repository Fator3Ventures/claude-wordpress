<?php
/**
 * Plugin Name: Bancada temporária de tela Meta 0321
 * Version: 1.1.0
 * Description: Moldura de observação privada do Site-Teste; não grava dados.
 */
defined('ABSPATH') || exit;
if('fator3-teste-mcp-1.dreamhosters.com' !== wp_parse_url(home_url(),PHP_URL_HOST))return;
// QA preview of the native WordPress color scheme; scoped to the tested admin request, no preference write.
add_filter('get_user_option_admin_color', static function($value){
 if(is_admin() && current_user_can('manage_options') && ($_GET['page']??'')==='wp-mcp-meta-fator3'
   && ($_GET['f3meta0321_scheme']??'')==='light')return 'light';
 return $value;
});
add_action('admin_post_f3_meta_qa_vista0321',static function(){
 if(!current_user_can('manage_options'))wp_die('Acesso restrito.','',['response'=>403]);
 nocache_headers();
 send_frame_options_header();header('Referrer-Policy: same-origin');
 $tabs=['connections','assets','ads-access','reports','jobs','history','messaging','archive','diagnostics','help'];
 $selected=isset($_GET['qa_tab']) && in_array($_GET['qa_tab'],$tabs,true)?$_GET['qa_tab']:'connections';
 $self=add_query_arg('action','f3_meta_qa_vista0321',admin_url('admin-post.php'));$query=['tab'=>$selected];
 if(($_GET['palette']??'')==='light')$query['f3meta0321_scheme']='light';
 $link=add_query_arg(['page'=>'wp-mcp-meta-fator3'],admin_url('tools.php'));
 $w=(int)($_GET['largura']??0);
 if(in_array($w,[360,768,1440],true)){
 ?><!DOCTYPE html><html lang="pt-BR"><meta charset="utf-8"><title>Captura Meta · <?=esc_html($selected)?> · <?=intval($w)?> px</title>
 <style>html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:white}iframe{display:block;border:0;transform-origin:0 0}footer{position:fixed;bottom:0;right:0;background:white;font:11px system-ui}</style>
 <iframe id="panel" title="Subaba do Meta" width="<?=intval($w)?>" height="920" scrolling="no" src="<?=esc_url(add_query_arg($query,$link))?>"></iframe>
 <i aria-hidden="true" id="cor" style="position:fixed;left:0;top:0;width:22px;height:22px;background:#000"></i><footer style="max-width:300px;height:45px;overflow:hidden"><button id="measure" type="button">Medir critérios</button><span id="estado" style="white-space:nowrap;display:inline-block;max-width:140px;overflow:hidden">Carregando…</span><output id="res" style="display:block;white-space:nowrap;overflow:hidden" aria-live="polite"></output></footer>
 <script src="<?=esc_url(add_query_arg('v','110',plugins_url('measure.js',__FILE__)))?>"></script>
 <script>
 (()=>{const f=document.querySelector('#panel'); const w=Number(f.width),scale=Math.min(1,(innerWidth-22)/w);f.style.transform='scale('+scale+')';
 const ready=()=>{const doc=f.contentDocument,win=f.contentWindow;if(!doc||!doc.querySelector('.wrap.f3-social .f3-version')||!doc.querySelector('.publishpress-authors-wp-reviews-notice'))return;
 const root=doc.querySelector('.wrap.f3-social'),header=root.querySelector('.f3-heading'),bar=doc.querySelector('#wpadminbar');
 if(!header||!bar)return;win.scrollTo(0,0);
 requestAnimationFrame(()=>requestAnimationFrame(()=>{const box=root.getBoundingClientRect(), top=Math.max(0,box.top,bar.getBoundingClientRect().bottom), left=Math.max(0,box.left);
 const crop={x:Math.ceil(left*scale),y:Math.ceil(top*scale),width:Math.floor(Math.min(box.width,w-left)*scale),height:Math.floor(Math.min(800,win.innerHeight-top)*scale)};
 const state={tab:new URL(doc.URL).searchParams.get('tab'),viewport:win.innerWidth,outer:[innerWidth,innerHeight],scale,frameY:f.getBoundingClientRect().top,scroll:win.scrollY,title:header.querySelector('h1').textContent,version:root.querySelector('.f3-version').textContent,crop};
 const route=<?=intval(array_search($selected,$tabs,true))?>, wi=[360,768,1440].indexOf(w);state.marker=[53+50*(route%4),53+70*Math.floor(route/4),53+80*wi];document.getElementById('cor').style.background='rgb('+state.marker.join(',')+')'; const status=document.querySelector('#estado');status.textContent='Pronto · '+JSON.stringify(state);
 }));};f.addEventListener('load',ready);if(f.contentDocument.readyState==='complete')ready();})();
 </script></html><?php exit;
 }
 ?><!DOCTYPE html><html lang="pt-BR"><meta charset="utf-8"><title>Prova visual Meta no Site-Teste</title>
 <style>html,body{margin:0;padding:0}iframe{border:0;display:block;max-width:none}aside{margin:8px 0}output{display:block;max-width:1200px;overflow-wrap:anywhere}</style>
 <iframe id="panel" title="Painel Meta real" width="768" height="920" scrolling="no" src="<?=esc_url(add_query_arg($query,$link))?>"></iframe>
 <aside><div><?php foreach($tabs as $tab)echo '<a href="'.esc_url(add_query_arg('qa_tab',$tab,$self)).'">'.esc_html($tab).'</a> '; ?></div>
 <div><?php foreach([360,768,1440] as $w)echo '<button type="button" data-w="'.$w.'">'.$w.' px</button> ';?></div>
 <div><?php foreach($tabs as $t)foreach([360,768,1440] as $w)echo '<a href="'.esc_url(add_query_arg(['qa_tab'=>$t,'largura'=>$w],$self)).'">Captura '.esc_html($t).' '.$w.'</a> '; ?></div><button type="button" id="measure">Medir critérios</button>
 <a href="<?=esc_url(add_query_arg(['qa_tab'=>'connections','palette'=>'light','largura'=>768],$self))?>">Conexão com paleta clara</a></aside>
 <output id="res" aria-live="polite"></output>
 <script src="<?=esc_url(add_query_arg('v','110',plugins_url('measure.js',__FILE__)))?>"></script></html><?php
 exit;
});
