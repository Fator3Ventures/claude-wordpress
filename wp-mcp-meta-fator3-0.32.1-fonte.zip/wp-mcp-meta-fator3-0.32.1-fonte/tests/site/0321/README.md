# Aceite do painel 0.32.1 no Site-Teste

Este auxiliar observacional requer acesso normal ao `wp-admin`, a capacidade `manage_options` e o hostname autorizado do Site-Teste. Ele não cria usuários nem registra rota pública, credenciais ou tabelas. A pré-visualização da paleta usa a configuração nativa só durante a requisição marcada; não altera o perfil. O aviso real do PublishPress Authors permanece ativo.

Para reproduzir, compacte os dois arquivos PHP e JS dentro de uma pasta `f3-meta-qa-vista0321`, instale exclusivamente no site autorizado e use `wp-admin/admin-post.php?action=f3_meta_qa_vista0321`. Abra os links de captura de cada uma das dez subabas (360, 768 e 1440 pixels). A moldura abre a página Meta verdadeira; o painel não recebe CSS nem JS do auxiliar. Acione “Medir critérios” pelo teclado. A saída discrimina as doze verificações e os elementos realmente presentes em cada tela. Faça uma medição adicional na pré-visualização clara.

Para garantir que uma fotografia corresponde à aba e à largura esperadas, confira no JPEG nativo a cor do marcador externo em (8,8) contra o valor exibido em “Pronto”. A diferença admissível é de sete unidades por componente, por causa da compressão JPEG. Só depois recorte a área útil a partir das coordenadas e escala da própria moldura. Exclua do recorte a barra e o menu WordPress, as ferramentas de medição e o marcador. Verifique o título do Meta e o aviso do PublishPress em cada imagem por reconhecimento de texto. Os JSONs não coletam valores de formulários.

Após a prova, desative e exclua **somente o auxiliar** e verifique a ausência no inventário do Site-Teste. Não inclua o auxiliar no instalador Meta. Consulte `evidence/0321/site` para os resultados da execução do pacote correspondente.
