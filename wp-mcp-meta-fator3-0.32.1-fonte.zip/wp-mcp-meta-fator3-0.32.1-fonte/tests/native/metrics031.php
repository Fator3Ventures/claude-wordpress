<?php
/** Pedido 33: real WordPress, Graph over the HTTP filter; no network or production data. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
require __DIR__.'/seed-connection090.php';
$checks=[];$calls=[];$mode='malformed';$bad='follows_and_unfollows';$private='example-private-provider-data-f31';
function metric31_check(string $name,bool $ok):void{global $checks;$checks[]=['name'=>$name,'passed'=>$ok];if(!$ok)fwrite(STDERR,"Failed: $name\n");}
function metric31_read(array $q,bool $isolated=false,bool $prior=false):array{
    M\Http::budget(40,25);
    $read=static fn()=>M\Query::execute($q);
    return $isolated?M\Adapter::withMetricIsolation($read,$prior):$read();
}
function metric31_fault(callable $test):?M\Fault{try{$test();return null;}catch(M\Fault $fault){return $fault;}}
function metric31_row(array $data,string $field):array{return array_column($data['rows'],null,'metric')[$field]??[];}
$values=['reach'=>8,'views'=>44,'accounts_engaged'=>8,'total_interactions'=>13,'likes'=>10,'comments'=>0,'shares'=>1,'saves'=>0,'profile_links_taps'=>0,'follows_and_unfollows'=>0];
$reply=static fn(array $body,int $http=200)=>['headers'=>[],'response'=>['code'=>$http],'body'=>wp_json_encode($body)];
$http=static function($pre,$args,$url)use(&$mode,&$bad,&$calls,$values,$private,$reply){
    $path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);
    if($path!=='/v24.0/31031/insights')return new WP_Error('unexpected_request');
    $fields=explode(',',$q['metric']);$calls[]=$q['metric'];
    if($mode==='malformed_envelope'||($mode==='isolated'&&in_array($bad,$fields,true)))return $reply(['data'=>'not-a-list']);
    if($mode==='scalar_row')return $reply(['data'=>[42]]);
    if($mode==='nonscalar_name')return $reply(['data'=>[['name'=>['not-a-name']]]]);
    if($mode==='unknown_metric')return $reply(['data'=>[['name'=>'extraneous','total_value'=>['value'=>0]]]]);
    if($mode==='503')return $reply(['error'=>['code'=>100,'message'=>$private]],503);
    if($mode==='400-transient')return $reply(['error'=>['code'=>100,'is_transient'=>true,'message'=>$private]],400);
    if($mode==='408')return $reply([],408);
    if($mode==='unproven403')return $reply([],403);
    $data=[];foreach($fields as $field){
        if($bad!==$field){$data[]=['name'=>$field,'total_value'=>['value'=>$values[$field]]];continue;}
        if($mode==='omitted')continue;
        $total=match($mode){
            'malformed'=>['breakdowns'=>[['dimension_keys'=>['follow_type'],'results'=>[$private=>[$private]]]]],
            'malformed_bucket'=>['breakdowns'=>[['results'=>[['value'=>0,'dimension_values'=>[[$private]]]]]]],
            'bad_scalar'=>$private,
            'empty_groups'=>['breakdowns'=>[]],
            'empty_buckets'=>['breakdowns'=>[['dimension_keys'=>['follow_type'],'results'=>[]]]],
            'no_result_proof'=>['breakdowns'=>[['dimension_keys'=>['follow_type']]]],
            'missing'=>null,
            'zero'=>['value'=>0,'breakdowns'=>[]],
            'zero_bucket'=>['breakdowns'=>[['dimension_keys'=>['follow_type'],'results'=>[['dimension_values'=>['FOLLOWER'],'value'=>0]]]]],
            default=>['value'=>10],
        };
        $data[]=['name'=>$field,'total_value'=>$total];
    }
    return $reply(['data'=>$data]);
};
add_filter('pre_http_request',$http,1,3);
$id='metric031-'.substr(wp_generate_uuid4(),0,8);
lab_seed_connection090(['connection_id'=>$id,'expected_revision'=>0,'token'=>'synthetic-'.$id,'users'=>[1],'assets'=>['instagram'=>['31031']]]);
$day=gmdate('Y-m-d',time()-86400);$selection=['connection_id'=>$id,'channel'=>'instagram','account_id'=>'31031','report'=>'account_insights','date_from'=>$day,'date_to'=>$day];
$q=$selection+['granularity'=>'day','fields'=>array_keys($values)];$q2=array_replace($q,['fields'=>['reach','views']]);
$j=M\Jobs::create(['query'=>$q,'idempotency_key'=>$id]);
$r=M\Jobs::run($j['job_id'],true);
metric31_check('Nine peers persist in the same ten-metric job',$r['status']==='partial'&&$r['successful_rows']===9&&$r['unavailable_metrics']===[$bad]);
$err=$r['errors'][0]??[];metric31_check('Coverage identifies the failing field and cause',($err['field']??'')===$bad&&$err['code']==='breakdown_unreadable'&&$err['cause']==='breakdown_unreadable');
$sample=$err['shape_sample']??[];metric31_check('Bounded shape contains only structural paths and types',isset($sample['total_value.breakdowns[].results'])&&$sample['total_value.breakdowns[].results']===['object']&&count($sample)<=45);
metric31_check('Public last_error retains the safe sample',($r['last_error']['shape_sample']??null)===$sample);
$tainted=['total_value.breakdowns'=>['list',$private],$private=>['string'],'total_value.'.$private=>['string']];metric31_check('Reprojection rejects injected path and type strings',M\InsightDiagnostics::projectShape($tainted)===['total_value.breakdowns'=>['list']]);
$history=M\History::query($selection);$rows=array_column(array_column($history['rows'],'row'),null,'metric');
metric31_check('History contains exactly ten attributed rows',count($rows)===10);
foreach(array_slice($values,0,9,true) as $field=>$v)metric31_check("History preserves value: $field",($rows[$field]['value']??null)===$v && $rows[$field]['availability']==='available');
metric31_check('Unusable metric is null, including in stored history',$rows[$bad]['value']===null&&$rows[$bad]['availability']==='breakdown_unreadable'&&$rows[$bad]['diagnostic']['shape_sample']===$sample);
metric31_check('Neither private keys nor values appear in record or history',!str_contains(wp_json_encode([$history,$r]),$private));
$bad='views';$mode='malformed_bucket';$d=metric31_read($q2);
metric31_check('Different metric and sibling within one Graph response isolated',$d['coverage']['successful_rows']===1&&$d['coverage']['unavailable_metrics']===['views']&&metric31_row($d,'reach')['value']===8);
$bad='follows_and_unfollows';$follow=array_replace($q,['fields'=>[$bad]]);
foreach(['empty_groups','empty_buckets'] as $mode){
    $d=metric31_read($follow);$row=metric31_row($d,$bad);
    metric31_check("Explicit empty $mode completes without inventing a zero",$d['coverage']['complete']&&$d['coverage']['error_count']===0&&$row['availability']==='empty_breakdown'&&$row['value']===null);
}
foreach(['zero','zero_bucket'] as $mode){
    $d=metric31_read($follow);$row=metric31_row($d,$bad);
    metric31_check("Supplied zero in $mode remains an observation",$d['coverage']['successful_rows']===1&&$d['coverage']['complete']&&($row['value']??$row['breakdowns'][0]['results'][0]['value'])===0);
}
foreach(['missing','omitted','no_result_proof','bad_scalar'] as $mode){
    $d=metric31_read($follow);metric31_check("$mode never implies an observed empty breakdown",!$d['coverage']['complete']&&$d['coverage']['unavailable_metrics']===[$bad]&&metric31_row($d,$bad)['value']===null);
}
foreach(['malformed_envelope','scalar_row','nonscalar_name','unknown_metric','503','408','400-transient','unproven403'] as $mode){
    $fault=metric31_fault(fn()=>metric31_read($q2));
    metric31_check("$mode is not treated as a successful page",$fault!==null);
}
$oldStory=gmdate('c',time()-2*86400);
foreach([['http_status'=>503,'provider_code'=>200],['http_status'=>400,'provider_code'=>10,'provider_is_transient'=>true],['http_status'=>403,'provider_code'=>null]] as $details){
    $fault=new M\Fault('asset_access_denied','',$details);
    metric31_check('Transient/ambiguous Story refusal does not prove expiry: '.$details['http_status'],M\CollectionState::storyFault($fault,[],$oldStory)===$fault);
}
$bad='views';$mode='isolated';$calls=[];$d=metric31_read($q2,true);
metric31_check('Final scoped pass queries individual metrics and keeps useful peer',$calls===['reach','views']&&$d['coverage']['successful_rows']===1&&$d['coverage']['errors'][0]['code']==='metric_retry_exhausted');
$mode='malformed_envelope';$fault=metric31_fault(fn()=>metric31_read($q2,true));
metric31_check('Whole provider outage remains a failure after isolation',$fault!==null&&$fault->reason==='upstream_invalid');
$d=metric31_read(array_replace($q2,['fields'=>['views']]),true,true);
metric31_check('A useful prior page permits isolating an unreadable final field',$d['coverage']['unavailable_metrics']===['views']);
$calls=[];$mode='normal';metric31_read($q2);metric31_check('Scope restored even after exceptions',$calls===['reach,views']);
remove_filter('pre_http_request',$http,1);$failed=count(array_filter($checks,fn($x)=>!$x['passed']));
echo wp_json_encode(['version'=>M\Config::VERSION,'total'=>count($checks),'failed'=>$failed,'checks'=>$checks,'provider'=>'simulated'])."\n";exit($failed?1:0);
