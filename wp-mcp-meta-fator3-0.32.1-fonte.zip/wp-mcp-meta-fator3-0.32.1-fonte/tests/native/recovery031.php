<?php
/** Real WordPress queues, durable records and current permissions, isolated HTTP responses only. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
require __DIR__.'/seed-connection090.php';
$checks=[];$mode='healthy';$calls=[];$seq=0;
function rc31(string $name,bool $ok):void{global $checks;$checks[]=['name'=>$name,'passed'=>$ok];if(!$ok)throw new RuntimeException($name);}
function change31(string $kind,string $key,callable $fn):array{$r=M\Store::get($kind,$key);$v=$r['value'];$fn($v);return M\Store::put($kind,$key,$v,$r['revision'],$r['expires_at']);}
function due31(string $key):array{change31('job',$key,static function(&$v){$v['next_at']=time()-1;});return M\Jobs::run($key,true);}
function job31(array $q):string{global $seq;return M\Jobs::create(['query'=>$q,'idempotency_key'=>'retry031-'.++$seq])['job_id'];}
function policy31(int $max):void{
 $old=M\RecoveryPolicy::current();$in=['expected_revision'=>$old['revision'],'policy'=>['max_attempts'=>$max,'gap_days'=>30,'retry_minutes'=>[5,10,20,40,60],'repeat_minutes'=>360]];
 $in['plan_digest']=M\RecoveryPolicy::simulate($in)['plan_digest'];M\RecoveryPolicy::save($in);
}
function reg31(string $id):void{lab_seed_connection090(['connection_id'=>$id,'expected_revision'=>0,'token'=>'fixture-only','enabled'=>true,'users'=>[1],'assets'=>['instagram'=>['3101','3102']]]);}
$fixture=static function($pre,$args,$url)use(&$mode,&$calls){
 $p=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$x);$calls[]=[$p,$x['metric']??null];
 $reply=static fn($data,$status=200)=>['headers'=>[],'body'=>wp_json_encode($data),'response'=>['code'=>$status]];
 if($mode==='invalid')return ['headers'=>[],'body'=>'{','response'=>['code'=>200]];
 if($mode==='network')return new WP_Error('simulated_timeout');
 if($mode==='401-no-code')return $reply(['error'=>['message'=>'Unavailable']],401);
 if($mode==='500-with-code')return $reply(['error'=>['code'=>190]],503);
 if($mode==='transient')return $reply(['error'=>['code'=>190,'is_transient'=>true]],400);
 if($mode==='403-real')return $reply(['error'=>['code'=>200]],403);
 if($mode==='denied')return $reply(['error'=>['code'=>190]],401);
 if(str_ends_with($p,'/me'))return $reply(['id'=>'3100']);
 if(str_ends_with($p,'/insights')){
  $metrics=explode(',',$x['metric']);if($mode==='isolate' && ($metrics===['views']||count($metrics)>1))return $reply([],503);
  return $reply(['data'=>array_map(static fn($m)=>['name'=>$m,'total_value'=>['value'=>2]],$metrics)]);
 }
 if(preg_match('~/([0-9]+)$~D',$p,$m))return $reply(['id'=>$m[1],'username'=>'test']);
 return new WP_Error('unexpected_fixture');
};
add_filter('pre_http_request',$fixture,1,3);
try{
 reg31('retry031');reg31('other031');
 $q=['connection_id'=>'retry031','channel'=>'instagram','account_id'=>'3101','report'=>'profile'];$qd=$q;$qd['report']='account_insights';$qd+=['fields'=>['reach','views'],'date_from'=>gmdate('Y-m-d',time()-86400),'date_to'=>gmdate('Y-m-d',time()-86400),'granularity'=>'day'];
 foreach(['invalid'=>'upstream_invalid','network'=>'upstream_error','401-no-code'=>'token_rejected','500-with-code'=>'token_rejected','transient'=>'token_rejected'] as $scenario=>$code){
  $mode=$scenario;$j=job31($q);$before=time();$r=M\Jobs::run($j,true);
  rc31("First $scenario retains page, waits five minutes",$r['job_id']===$j&&$r['status']==='retry'&&$r['last_code']===$code&&$r['attempts']===1 && $r['next_retry_at']>=$before+300&&$r['next_retry_at']<=time()+300&&$r['pause_reason']===null&&$r['pages']===0);
  $n=count($calls);$again=M\Jobs::run($j,true);rc31("No premature request for $scenario",$r['revision']===$again['revision']&&$n===count($calls));
  $mode='healthy';$r=due31($j);rc31("Same job recovers after $scenario",$r['job_id']===$j&&$r['status']==='complete'&&$r['pages']===1&&$r['attempts']===0&&$r['next_retry_at']===null);
 }
 $mode='invalid';$j=job31($q);$saved=[];$waits=[5,10,20,40,60,360,360];foreach($waits as $n=>$minutes){
  $before=time();$r=$n?due31($j):M\Jobs::run($j,true);rc31("Default wait ".($n+1),$r['attempts']===$n+1&&$r['next_retry_at']>=$before+60*$minutes&&$r['next_retry_at']<=time()+60*$minutes&&$r['status']==='retry');
  if($n===0){policy31(2);$saved=$r;}
 }
 $r=due31($j);rc31('Frozen policy reaches eight attempts and records exhausted pause',$r['status']==='paused'&&$r['attempts']===8&&$r['pause_reason']==='attempts_exhausted'&&$r['max_attempts']===8&&!$r['isolation_attempted']&&$r['recovery_policy_revision']===$saved['recovery_policy_revision']);
 M\JobRecovery::maintenance();rc31('Prior success cannot re-arm exhaustion',M\Jobs::status($j)['status']==='paused');
 $mode='healthy';$other=job31(array_replace($q,['connection_id'=>'other031']));M\Jobs::run($other,true);$otherReport=job31($qd);M\Jobs::run($otherReport,true);M\JobRecovery::maintenance();
 rc31('Success on other connection or report does not re-arm',M\Jobs::status($j)['status']==='paused');
 $mode='healthy';M\Jobs::run(job31($q),true);$jobsBefore=M\Store::list('job',0,100);$n=count($calls);M\JobRecovery::maintenance();
 rc31('A later success re-arms same job locally, no duplicate or HTTP',M\Jobs::status($j)['status']==='queued'&&M\Jobs::status($j)['pages']===0&&$n===count($calls)&&count(M\Store::list('job',0,100))===count($jobsBefore));rc31('Re-armed job concludes',M\Jobs::run($j,true)['status']==='complete');
 $j=job31($qd);$mode='isolate';$r=M\Jobs::run($j,true);rc31('Broken group first waits',$r['status']==='retry'&&$r['max_attempts']===2);
 $n=count($calls);$r=due31($j);$metrics=array_column(array_slice($calls,$n),1);
 rc31('Final read isolates each metric before pausing; useful peer is stored',$r['status']==='partial'&&$r['successful_rows']===1&&$r['unavailable_metrics']===['views']&&$metrics===['reach','views']);
 $j=job31($qd);$mode='network';M\Jobs::run($j,true);$r=due31($j);rc31('Total outage after isolation stays paused/exhausted',$r['status']==='paused'&&$r['pause_reason']==='attempts_exhausted'&&$r['isolation_attempted']&&$r['pages']===0);
 $j=job31($q);$mode='403-real';$r=M\Jobs::run($j,true);rc31('Confirmed provider permission refusal pauses permanently',$r['status']==='paused'&&$r['pause_reason']==='permanent'&&$r['attempts']===1&&$r['next_retry_at']===null);
 $p=$j;$mode='healthy';M\JobRecovery::maintenance();rc31('No immediate repeated denied call',M\Jobs::status($p)['status']==='paused');
 M\Jobs::run(job31(array_replace($q,['fields'=>['id']])),true);M\JobRecovery::maintenance();
 rc31('Another field selection cannot prove a permanent refusal was lifted',M\Jobs::status($p)['status']==='paused');
 $manual=job31($q);M\Jobs::control(['job_id'=>$manual,'expected_revision'=>1,'action'=>'pause']);$cancel=job31($q);M\Jobs::control(['job_id'=>$cancel,'expected_revision'=>1,'action'=>'cancel']);
 M\Jobs::run(job31($q),true);M\JobRecovery::maintenance();rc31('Subsequent proof on same account and report re-arms permanent job',M\Jobs::status($p)['status']==='queued');
 $r=M\Jobs::run($p,true);rc31('Completed job kept one page',$r['status']==='complete'&&$r['pages']===1);
 rc31('Manual pause and cancellation stay intact',M\Jobs::status($manual)['pause_reason']==='manual'&&M\Jobs::status($cancel)['status']==='cancelled');
 $j=job31($q);$mode='denied';M\Jobs::run($j,true);
 change31('connection','retry031',static function(&$c){++$c['credential_generation'];$c['token_identity']['validated_generation']=$c['credential_generation'];$c['plan_floor']=0;});
 M\JobRecovery::maintenance();rc31('New validated credential re-arms rejected job',M\Jobs::status($j)['status']==='queued');
 $mode='healthy';M\Jobs::run($j,true);$mode='denied';$j=job31($q);M\Jobs::run($j,true);
 change31('connection','retry031',static function(&$c){++$c['credential_generation'];$c['token_identity']['validated_generation']=$c['credential_generation'];$c['assets']['instagram']=['3102'];});$n=count($calls);M\JobRecovery::maintenance();
 rc31('Revoked asset is never reauthorized by renewal or maintenance',M\Store::get('job',$j)['value']['status']==='paused'&&$n===count($calls));
 $n=count($calls);$h=M\JobRecovery::health();rc31('Bounded read-only health reports paused reason and attempts',count($calls)===$n&&!$h['truncated']&&count(array_filter($h['jobs'],fn($x)=>$x['job_id']===$j&&$x['pause_reason']==='permanent'&&$x['attempts']===1))===1);
 $timeout=new M\Fault('upstream_validation','',['http_status'=>408]);rc31('408/transient failures are publicly retryable, ambiguous writes are not',M\Result::fail($timeout)['retryable']&&M\Result::fail(new M\Fault('upstream_invalid',''))['retryable']&&!M\Result::fail(new M\Fault('operation_uncertain','',['http_status'=>503]))['retryable']);
}catch(Throwable $e){$checks[]=['name'=>'suite concluded: '.get_class($e).' '.$e->getMessage(),'passed'=>false];}
finally{remove_filter('pre_http_request',$fixture,1);}
$failed=count(array_filter($checks,fn($t)=>!$t['passed']));echo wp_json_encode(['version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>$failed,'simulated_calls'=>count($calls)])."\n";exit($failed?1:0);
