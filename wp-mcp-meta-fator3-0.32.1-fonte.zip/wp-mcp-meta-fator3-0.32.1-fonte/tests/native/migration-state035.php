<?php
/** Stable business-state digest; exports no row contents to evidence. */
function f3qa022_state(): array {
    global $wpdb;
    $records=Fator3\Meta\Store::table();$history=Fator3\Meta\History::table();
    $queries=[
        'records'=>$wpdb->prepare("SELECT * FROM %i WHERE bucket NOT IN ('audit','migration','history_generation') ORDER BY bucket,record_key",$records),
        'history'=>$wpdb->prepare('SELECT * FROM %i ORDER BY row_key',$history),
        'options'=>$wpdb->prepare("SELECT option_name,option_value FROM %i WHERE option_name LIKE %s AND option_name NOT IN ('f3_meta_schema','f3_meta_history_schema','f3_meta_queue_migration','f3_meta_queue_settled','f3_meta_worker_schedule_attempt','f3_meta_audit_health','f3_meta_retention0110') ORDER BY option_name",$wpdb->options,$wpdb->esc_like('f3_meta_').'%')
    ];
    // Permit exactly the named internal migration marker to advance. Compare its raw
    // value separately; every other option name and value still enters an exact digest.
    $keys=$wpdb->get_results($queries['options'],ARRAY_A);
    $business=array_values(array_filter($keys,static fn($x)=>$x['option_name']!=='f3_meta_site_owner_031'));
    $state=['owner_marker'=>get_option('f3_meta_site_owner_031'),'unchanged_options'=>['count'=>count($business),'sha256'=>hash('sha256',serialize($business))]];
    foreach ($queries as $kind=>$sql) {
        $rows=$wpdb->get_results($sql,ARRAY_A);
        if ($wpdb->last_error || !is_array($rows) || !$rows)throw new RuntimeException('Missing seeded state for '.$kind);
        $state[$kind]=['count'=>count($rows),'sha256'=>hash('sha256',serialize($rows))];
    }
    return $state;
}
