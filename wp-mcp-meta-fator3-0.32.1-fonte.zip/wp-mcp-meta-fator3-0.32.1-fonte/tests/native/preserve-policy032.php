<?php
/** An admin saved a nondefault policy in 0.31.0; require identical values and revision after the file swap. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();wp_set_current_user(1);
$settings=['retry_minutes'=>[3,7,21],'repeat_minutes'=>90,'max_attempts'=>6,'gap_days'=>17];
$phase=$argv[1]??'';
if($phase==='seed'){
    if(M\Config::VERSION!==F3QA_BASE)throw new RuntimeException('Base expected');
    $i=['expected_revision'=>0,'policy'=>$settings];$p=M\RecoveryPolicy::simulate($i);
    $out=M\RecoveryPolicy::save($i+['plan_digest'=>$p['plan_digest']]);
    if($out['policy']!==$settings+['revision'=>1])throw new RuntimeException('Base policy not saved');
}elseif($phase==='verify'){
    if(M\Config::VERSION!==F3QA_CANDIDATE)throw new RuntimeException('Candidate expected');
    $checks=[
        ['name'=>'Previous durable policy values and revision remain unchanged','passed'=>M\RecoveryPolicy::current()===$settings+['revision'=>1]],
        ['name'=>'Retry schedule still uses saved intervals and cycles','passed'=>M\RecoveryPolicy::delayMinutes(M\RecoveryPolicy::current(),3)===21 && M\RecoveryPolicy::delayMinutes(M\RecoveryPolicy::current(),4)===90],
    ];
    $failed=count(array_filter($checks,fn($c)=>!$c['passed']));echo wp_json_encode(['total'=>count($checks),'failed'=>$failed,'checks'=>$checks])."\n";exit($failed?1:0);
}else throw new InvalidArgumentException('Phase must be seed or verify');
