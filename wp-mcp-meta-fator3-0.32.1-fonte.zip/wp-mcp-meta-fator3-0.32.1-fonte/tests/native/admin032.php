<?php
/** Server-side, real WordPress: assets and permissions remain scoped to the package. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
$checks=[];$ck=static function(string $name,bool $yes)use(&$checks){$checks[]=['name'=>$name,'passed'=>$yes];};
$src=fn($r)=>(string)($r->src??'');
$own=static function($styles)use($src){return array_values(array_filter($styles->queue,fn($k)=>str_contains($src($styles->registered[$k]??null),'/wp-mcp-meta-fator3/')));};
wp_set_current_user(1);$hook='tools_page_'.M\Config::SLUG;$styles=wp_styles();require_once ABSPATH.'wp-admin/includes/admin.php';set_current_screen('dashboard');
do_action('wp_enqueue_scripts');$ck('Front end loads neither admin style',!$own($styles));
foreach(['index.php','plugins.php','tools_page_wp-mcp-fator3'] as $other){do_action('admin_enqueue_scripts',$other);$ck('No Meta assets for '.$other,!$own($styles)&&!wp_script_is(M\Config::KEY,'enqueued'));}
$u=wp_create_user('guide-test-reader',wp_generate_password(),'reader-guide32@example.invalid');if(is_wp_error($u))throw new RuntimeException('Fresh WP required');(new WP_User($u))->set_role('subscriber');wp_set_current_user($u);
do_action('admin_enqueue_scripts',$hook);
$ck('Subscriber receives no assets or localized editor state',!$own($styles)&&!wp_script_is(M\Config::KEY,'enqueued'));
$reply=0;add_filter('wp_die_handler',static function()use(&$reply){return static function($msg,$title,$args)use(&$reply){$reply=$args['response']??null;throw new RuntimeException('guarded');};});
try{M\Admin::screen();}catch(RuntimeException $e){if($e->getMessage()!=='guarded')throw $e;}
$ck('Restricted user cannot render admin screen (HTTP 403)',$reply===403);
wp_set_current_user(1);$calls=0;add_filter('pre_http_request',static function($pre)use(&$calls){$calls++;return new WP_Error('unexpected_external_request');},1);
do_action('admin_enqueue_scripts',$hook);$keys=$own($styles);$hrefs=array_map(fn($k)=>basename($src($styles->registered[$k])),$keys);
$ck('Style order on plugin page is common first and Meta second',$hrefs===['f3-ui.css','admin.css']);
$ck('Package stylesheet depends on shared stylesheet',count($keys)===2 && in_array($keys[0],$styles->registered[$keys[1]]->deps,true));
$ck('JS enqueued only after entering the authorized package page',wp_script_is(M\Config::KEY,'enqueued'));
foreach(M\Admin::tabs() as $id=>$label){$_GET['tab']=$id;$ck('Existing tab URL maps to '.$id,M\Admin::currentTab()===$id);}
$_GET['tab']='not-a-tab';$ck('Unknown route falls back to Connections',M\Admin::currentTab()==='connections');
$ck('Loading the admin assets performs no supplier requests',$calls===0);
$failed=count(array_filter($checks,fn($c)=>!$c['passed']));echo wp_json_encode(['version'=>M\Config::VERSION,'total'=>count($checks),'failed'=>$failed,'checks'=>$checks])."\n";exit($failed?1:0);
