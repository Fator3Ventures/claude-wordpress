<?php
/** Deterministic deadline boundaries. With no arguments, runs against the installed, guarded WP.
 * CLI before/after: php deadlines321.php base|candidate /absolute/path/to/shipped/ScheduleGaps.php */
declare(strict_types=1);
use Fator3\Meta\ScheduleGaps as G;
$phase=$argv[1]??'candidate';
if(!in_array($phase,['base','candidate'],true))throw new RuntimeException('Invalid phase');
if(isset($argv[2])){if(PHP_SAPI!=='cli'||basename($argv[2])!=='ScheduleGaps.php'||!is_file($argv[2]))throw new RuntimeException('Invalid fixture');define('ABSPATH',__DIR__.'/');require $argv[2];}
else{require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();}
$checks=[];$ck=static function(string $name,bool $result)use(&$checks){$checks[]=['name'=>$name,'passed'=>$result];if(!$result)throw new RuntimeException($name);};
$t=1700000000;$day=86400;$week=7*$day;$grace=7200;
$new=static fn(int $i)=>['enabled'=>true,'interval_minutes'=>$i,'next_at'=>$t,'query'=>['report'=>'audience'],'collection_epoch'=>'a'];
$s=$new(10080);$s['last_run_status']='queued';G::failure($s,$t);$s['next_at']=$t+4*$week;
$ck('Former 26h weekly queued false positive is reproduced only on base', (G::since($s,$t+26*3600)!==null)===($phase==='base'));
$d=$new(1440);G::failure($d,$t);$d['next_at']=$t+4*$day;$d['last_run_status']='queued';
$ck('Former 26h daily queued false positive is reproduced only on base',(G::since($d,$t+26*3600)!==null)===($phase==='base'));
$legacy=$new(1440);$legacy['next_at']=$t+10*$day;$legacy['last_run_status']='failed';$legacy['last_code']='upstream_unavailable';
$legacy['last_error']=['code'=>'upstream_unavailable','observed_at'=>$t];$legacy['collection_failure_since']=$t-10*3600;
$ck('Older pending dispatch cannot predate a confirmed first failure',(G::since($legacy,$t+20*3600)!==null)===($phase==='base'));
if($phase==='candidate'){
    foreach([15,60,1440,10080] as $m){
        $i=60*$m;$s=$new($m);$s['next_at']=$t+10*$i+$grace;$s['last_run_status']='queued';G::failure($s,$t);G::failure($s,$t+$i);
        $s['last_success_at']=$t+$i; // progress on a page is not completion.
        $ck("Queued {$m}m schedule is under limit a second before its deadline",G::overdue($s,$t+2*$i+$grace-1)===null);
        $v=G::overdue($s,$t+2*$i+$grace);$ck("Queued {$m}m schedule reaches two intervals plus grace",$v===['clock'=>'missed_slots','blocked_since'=>$t,'deadline_at'=>$t+2*$i+$grace,'threshold_seconds'=>2*$i+$grace]);
        $s=$new($m);$s['next_at']=$t;$s['collection_success_at']=$t-$i;
        $ck("Missed {$m}m cron after a known completion uses the two due slots",G::since($s,$t+$i+$grace-1)===null&&G::since($s,$t+$i+$grace)===$t-$i);
        $s=$new($m);$s['next_at']=$t+10*$i+$grace;$s['last_run_status']='failed';G::confirmedFailure($s,$t);G::confirmedFailure($s,$t+$i);
        $ck("Confirmed {$m}m failure persists until its second expected slot plus grace",G::overdue($s,$t+$i+$grace-1)===null&&G::overdue($s,$t+$i+$grace)['clock']==='confirmed_failure'&&G::since($s,$t+$i+$grace)===$t);
    }
    $ck('Legacy record with an attributable error uses last_error.observed_at',G::since($legacy,$t+26*3600)===$t);
    $auth=$legacy;$auth['last_run_status']='queued';$auth['last_code']='not_authorized';$auth['last_successful_rows']=3;
    $auth['last_error']=['code'=>'not_authorized','auth_scope'=>'connection','observed_at'=>$t];
    $ck('A confirmed legacy connection failure survives earlier row counts or a queued status',G::since($auth,$t+26*3600)===$t);
    $s=$new(1440);$s['next_at']=$t+5*$day;$s['last_run_status']='queued';G::failure($s,$t-5*3600);G::confirmedFailure($s,$t);
    $ck('A job that waited in the queue before its first failure starts the short clock at that failure',G::since($s,$t+26*3600-1)===null&&G::since($s,$t+26*3600)===$t);
    $s['last_run_status']='failed';$s['last_code']='upstream_unavailable';$s['last_error']=['code'=>'upstream_unavailable','observed_at'=>$t+$day];$s['last_success_at']=null;
    $j=['query'=>$s['query'],'schedule_id'=>'fixture','schedule_epoch'=>'a','updated_at'=>$t+2*$day,'status'=>'partial','outcome'=>'nao_aplicavel','successful_rows'=>0];
    $ck('Resolved no-data clears both clocks without fabricating last_success_at',G::record($s,'fixture','job',$j,true)&&!isset($s['collection_error_since'],$s['collection_failure_since'])&&$s['collection_success_at']===$j['updated_at']&&$s['last_success_at']===null);
    $s['last_run_status']='nao_aplicavel';$s['last_code']='fields_unavailable';$s['availability_assessment']=['kind'=>'nao_aplicavel'];
    $ck('Receipt remains healthy 26h later',G::since($s,$j['updated_at']+26*3600)===null);
    $s['interval_minutes']=10080;$s['next_at']=$j['updated_at']+$week;
    $ck('A no-data receipt does not suppress genuinely missed future weeks',G::since($s,$j['updated_at']+2*$week+$grace)===$j['updated_at']);
    $s['enabled']=false;$ck('Disabled schedule never opens',G::since($s,$t+100*$week)===null);
    $s=$legacy;$s['collection_observation_started_at']=$t+24*3600;$s['next_at']=$t+6*$day;unset($s['collection_failure_since']);
    $ck('Re-enabling an old failed schedule does not revive an old confirmed error',G::since($s,$t+50*3600)===null);
    $s=$new(1440);$s['collection_success_at']=$t-100*$day;
    $ck('A deliberately distant next slot is not aged by ancient successes',G::since($s,$t+$grace)===null);
    $s=$new(1440);G::confirmedFailure($s,$t);$j=['query'=>$s['query'],'schedule_id'=>'fixture','schedule_epoch'=>'old','updated_at'=>$t+2*$day,'status'=>'complete'];
    $ck('Late result from a retired selection cannot acknowledge a current failure',!G::record($s,'fixture','old',$j,false)&&$s['collection_error_since']===$t);
    $s=$legacy;G::failure($s,$t+$day);$s['last_code']=null;$s['last_run_status']='queued';
    $ck('Re-dispatch preserves a provable pre-upgrade failure while retrying',G::since($s,$t+26*3600)===$t);
}
echo json_encode(['phase'=>$phase,'total'=>count($checks),'failed'=>0,'checks'=>$checks],JSON_UNESCAPED_UNICODE)."\n";
