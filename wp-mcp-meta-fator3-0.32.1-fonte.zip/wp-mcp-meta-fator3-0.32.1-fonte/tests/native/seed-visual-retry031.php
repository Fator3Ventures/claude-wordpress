<?php
/** Produce one real pending retry for the browser test, using a synthetic Graph transport. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$fake=static fn()=>['response'=>['code'=>503],'headers'=>[],'body'=>'{}'];
add_filter('pre_http_request',$fake,1);
try {
 $q=['connection_id'=>'demo-painel','channel'=>'instagram','account_id'=>'1001','report'=>'profile'];
 $j=M\Jobs::create(['query'=>$q,'idempotency_key'=>'visual-retry031']);$j=M\Jobs::run($j['job_id'],true);
 if($j['status']!=='retry'||$j['attempts']!==1||$j['next_retry_at']<=time())throw new RuntimeException('Real first retry required.');
}finally{remove_filter('pre_http_request',$fake,1);}
