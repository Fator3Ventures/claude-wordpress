<?php
/** Two separate WordPress bootstraps around a ZIP upgrade. The Core mail outbox is real.
 * Usage: F3_LAB_ROOT=<private root> php incidents035.php baseline|candidate [0.32.0|0.31.0].
 * Supply 0.31.0 explicitly on both invocations when verifying the direct fleet upgrade.
 * Graph and clock are controlled; SMTP is forbidden. Do not run against any shared site. */
namespace Fator3\Meta {
    function time(): int { return \time() + (int)($GLOBALS['f3qa035_clock_shift'] ?? 0); }
}
namespace {
use Fator3\Meta as M;
require __DIR__.'/guard.php';
$phase=$argv[1]??'';if(!in_array($phase,['baseline','candidate'],true))throw new RuntimeException('Pass baseline or candidate');
$baselineVersion=$argv[2]??'0.32.0';
if(!in_array($baselineVersion,['0.32.0','0.31.0'],true))throw new RuntimeException('Unsupported baseline');
$root=f3qa022_root();$backup=$root.'/evidence/pedido035-before.json';
// Install guards before the first candidate plugins_loaded. Keep the Core pre_wp_mail hook:
// a true-returning test stub would hide the exact regression this suite is meant to detect.
$GLOBALS['wp_filter']['muplugins_loaded'][5][]=['function'=>static function(){
    remove_filter('pre_wp_mail','__return_true');
    add_filter('f3base_wp_mail_smtp_cliente',static function(){throw new RuntimeException('SMTP must never run');});
    add_action('plugins_loaded',static function(){
        add_filter('pre_wp_mail',static fn($r)=>$r??false,PHP_INT_MAX);
    },-99);
},'accepted_args'=>0];
require $root.'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
require __DIR__.'/seed-connection090.php';
function ck35(string $name,bool $ok): void {global $checks;if(!$ok)throw new RuntimeException($name);$checks[]=$name;}
function read35(string $key): array {return M\Store::get('schedule',$key)['value'];}
function edit35(string $key,array $patch): void {$r=M\Store::get('schedule',$key);M\Schedules::checkpoint(['key'=>$key]+$r,array_replace($r['value'],$patch));}
function observe35(): void {M\Worker::notify();F3Base_Incidentes_Provedores::meta();}
function list35(): array {$r=F3Base_Incidentes::listar();ck35('Core incident registry read',!empty($r['ok'])&&empty($r['proximo']));return array_column($r['itens'],null,'recurso_ref');}
function ref35(string $resource): string {return hash_hmac('sha256',$resource,wp_salt('auth'));}
function scheduleRef35(string $key): string {return ref35(hash('sha256','schedule_overdue|'.$key));}
function queue35(): array {
    $ability=wp_get_ability('f3base/email-wordpress-fila-ler');ck35('Core outbox ability registered',!is_null($ability));
    $r=$ability->execute(['pagina'=>1]);ck35('Outbox read completely',is_array($r)&&!empty($r['ok'])&&count($r['linhas'])<50);
    $rows=[];foreach($r['linhas'] as $line){$subject=$line['diagnostico']['assunto']??'';if(!str_ends_with($subject,' · meta · agenda_parada'))continue;
        ck35('Incident receipt is persisted before SMTP',$line['estado']==='pendente'&&$line['codigo']==='retido_pela_cota');
        $rows[$line['id']]=$subject;
    }return $rows;
}
function split35(array $q,string $prefix): array {return array_filter($q,static fn($s)=>str_starts_with($s,$prefix));}
function recurring35(array $keys): array {$out=[];foreach($keys as $id){$s=read35($id);$out[$id]=array_intersect_key($s,array_flip(['query','enabled','interval_minutes','lookback_days','next_at','collection_epoch','last_job']));}return $out;}
function issueIds35(string $code): array {return array_column(array_filter(M\Worker::health(true)['issues'],static fn($i)=>$i['code']===$code),'schedule_id');}
function new35(string $key,array $query,int $minutes): void {M\Schedules::save(['schedule_id'=>$key,'query'=>$query,'expected_revision'=>0,'enabled'=>true,'lookback_days'=>1,'interval_minutes'=>$minutes,'next_at'=>M\time()+$minutes*60]);}
function run35(string $key): array {static $n=0;edit35($key,['next_at'=>M\time()-100+(++$n)]);M\Schedules::tick();$j=read35($key)['last_job'];$v=M\Jobs::run($j,true);return $v;}
$checks=[];$proof=[];$delta=26*3600+4;$GLOBALS['f3qa035_clock_shift']=0;
ck35('Expected Meta ZIP active',M\Config::VERSION===($phase==='baseline'?$baselineVersion:'0.32.1'));
ck35('Expected official Site Core active',defined('F3BASE_PLUGIN_VERSAO')&&F3BASE_PLUGIN_VERSAO==='1.100.1');
$dimensions=['ig-publico-cidade'=>'city','ig-publico-genero'=>'gender','ig-publico-idade'=>'age','ig-publico-pais'=>'country'];
$weekly=array_keys($dimensions);$cid='lab-035';$acc='35035';$q=['connection_id'=>$cid,'channel'=>'instagram','account_id'=>$acc];
$source='empty';$count=null;$graphCalls=0;
add_filter('pre_http_request',static function($prev,$args,$url)use(&$graphCalls,&$count,&$source,$acc){
    ++$graphCalls;$path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);
    $resp=static fn($data,$code=200)=>['response'=>['code'=>$code],'headers'=>[],'body'=>wp_json_encode($data)];
    if($path==='/v24.0/'.$acc&&($q['fields']??'')==='id,followers_count')return $resp(array_filter(['id'=>$acc,'followers_count'=>$count],static fn($v)=>$v!==null));
    if($path!=='/v24.0/'.$acc.'/insights')return new WP_Error('test_endpoint_blocked');
    if(($q['metric']??'')==='reach')return $resp(['error'=>['code'=>100,'message'=>'Invalid metric for this account']],400);
    if(($q['metric']??'')!=='follower_demographics')return new WP_Error('test_metric_blocked');
    return $resp(['data'=>$source==='available'?[['name'=>'follower_demographics','total_value'=>['breakdowns'=>[['results'=>[['dimension_values'=>['example'],'value'=>7]]]]]]]:[]]);
},1,3);
if($phase==='baseline'){
    ck35('Independent lab starts without previous checkpoint',!file_exists($backup));
    // Two independent guards: pending quota prevents SMTP in Core; the SMTP client filter
    // also blocks every socket should quota reservation ever change.
    $dest='incidentes@example.invalid';$mail=F3Base_Email_Site::cfg();$mail=array_replace($mail,['wp_mail_pela_caixa'=>true,'alocacao_confirmada'=>true,'endereco'=>'laboratorio@example.invalid','nome_exibicao'=>'Laboratório','usuario'=>'laboratorio@example.invalid','smtp_host'=>'127.0.0.1','smtp_porta'=>1,'cco'=>[],'homologacao'=>true,'homologacao_emails'=>[$dest],'cota_destinatarios_hora'=>1]);
    update_option(F3Base_Email_Site_Config::OPTION,$mail,false);
    $secret=F3Base_Email_Site_Config::SECRET;update_option($secret,F3Base_Segredos::cifrar($secret,bin2hex(random_bytes(16))),false);
    ck35('Core transport enabled for isolated mailbox',F3Base_Email_Site::cfg()['wp_mail_pela_caixa']&&F3Base_Segredos::abrir($secret)!=='');
    ck35('SMTP quota fully reserved',F3Base_Email_Novo_Lead::reservar_cota(1,1));
    $policy=F3Base_Options::ler('f3base_avisos_tecnicos');$policy['email']=$dest;F3Base_Options::gravar('f3base_avisos_tecnicos',$policy);
    ck35('Outbox starts empty',queue35()===[]);
    $GLOBALS['f3qa035_clock_shift']=-30*3600;
    lab_seed_connection090(['connection_id'=>$cid,'expected_revision'=>0,'token'=>'private-lab-token','assets'=>['instagram'=>[$acc]],'users'=>[1]]);
    foreach($dimensions as $id=>$b){new35($id,$q+['report'=>'audience','fields'=>['follower_demographics'],'breakdown'=>$b],10080);
        $job=run35($id);$s=read35($id);
        ck35("$id historical terminal source evidence",$job['outcome']==='failed'&&$job['successful_rows']===0&&$s['last_code']==='fields_unavailable'&&$s['last_error']['code']==='empty_or_suppressed');
        // Outgoing release may populate newer clock fields when making a new job.
        // The fleet snapshot predates those fields, and represents them as explicit nulls.
        edit35($id,['collection_success_at'=>null,'collection_failure_since'=>null,'last_success_at'=>null,'availability_assessment'=>null]);
        $view=M\CollectionState::scheduleDiagnostic(read35($id));
        ck35("$id matches the original failed fleet record",$view['last_run_status']==='failed'&&$view['last_error_state']==='current'&&$view['last_error_superseded']===false&&count($view['last_errors'])===1&&$view['collection_success_at']===null&&$view['collection_failure_since']===null&&read35($id)['unavailable_metrics']===['follower_demographics']&&$view['availability_assessment']===null);
    }
    $GLOBALS['f3qa035_clock_shift']=0;
    observe35();$base=list35();$policy=F3Base_Options::ler('f3base_avisos_tecnicos');
    foreach($weekly as $id){$e=$base[scheduleRef35($id)]??[];ck35("$id Core opened with default grace",($e['estado']??'')==='aberto'&&$e['episodio']===1&&$e['entregas_pendentes']===1);$policy['carencia_por_codigo_minutos'][$e['codigo_carencia']]=0;}
    F3Base_Options::gravar('f3base_avisos_tecnicos',$policy);
    // Force the configured grace to elapse without a 30-minute wait. Only subsequent
    // delivery timing changes; the real debt and the four Core records already exist.
    observe35();$outbox=queue35();ck35('Exactly four historic opening mail receipts',count($outbox)===4&&count(split35($outbox,'Incidente técnico'))===4);
    $control='control035-unrelated-resource';$posted=F3Base_Incidentes::publicar(['pacote'=>'meta','codigo'=>'integracao_indisponivel','recurso'=>$control,'estado'=>'aberto']);
    $unrelated=list35()[ref35($control)]??[];ck35('Separate incident persisted as open',($posted['ok']??false)&&($unrelated['estado']??'')==='aberto');
    $bad=issueIds35('schedule_collection_unresolved');sort($bad);$expected=$weekly;sort($expected);ck35('Outgoing policy indicates all four false gaps',$bad===$expected);
    // Exercise the event replay paths rather than relying on perfectly synchronized queues.
    // Core has the first episode even if Meta has lost its local acknowledgement. The second
    // has an undelivered old opening in the Meta outbox; that stale opening must be replaced.
    $transitions=get_option('f3_meta_incident_transitions',[]);$coreOnly=hash('sha256','schedule_overdue|'.$weekly[0]);$stale=hash('sha256','schedule_overdue|'.$weekly[1]);
    ck35('Baseline incident publisher really observed both fixtures',isset($transitions['active'][$coreOnly],$transitions['active'][$stale]));
    unset($transitions['active'][$coreOnly]);$transitions['pending'][$stale][]=($transitions['active'][$stale]+['estado'=>'aberto']);
    update_option('f3_meta_incident_transitions',$transitions,false);
    file_put_contents($backup,wp_json_encode(['baseline_version'=>M\Config::VERSION,'schedules'=>recurring35($weekly),'opening_ids'=>array_keys($outbox),'control'=>$unrelated['id']]));
    $proof=['weekly_false_gaps'=>count($bad),'original_openings'=>count($outbox)];
}else{
    ck35('Existing baseline was retained',is_readable($backup));$prior=json_decode(file_get_contents($backup),true,512,JSON_THROW_ON_ERROR);
    ck35('Baseline version matches this upgrade route',($prior['baseline_version']??null)===$baselineVersion);
    // The version bootstrap has already executed; the test never calls the reclassifier directly.
    foreach($weekly as $id){$v=read35($id);ck35("$id corrected on first WordPress load",$v['last_run_status']==='nao_aplicavel'&&($v['availability_assessment']['kind']??'')==='nao_aplicavel'&&$v['last_success_at']===null&&$v['last_successful_rows']===0);}
    ck35('No query, enabled flag, scheduled slot, job or generation changed',recurring35($weekly)===$prior['schedules']);
    $firstLoad=list35();$transitions=get_option('f3_meta_incident_transitions',[]);
    foreach($weekly as $id){$h=hash('sha256','schedule_overdue|'.$id);
        ck35("$id closed on startup before either observer is explicitly called",($firstLoad[scheduleRef35($id)]['estado']??null)==='recuperado');
        ck35("$id no obsolete opening left for replay",empty($transitions['active'][$h])&&empty($transitions['pending'][$h]));
    }
    foreach([0,0,$delta,$delta] as $shift){$GLOBALS['f3qa035_clock_shift']=$shift;observe35();$core=list35();
        ck35('No weekly false gaps at +'.$shift.'s',array_intersect($weekly,issueIds35('schedule_collection_unresolved'))===[]);
        foreach($weekly as $id){$v=$core[scheduleRef35($id)]??[];ck35("$id only original Core episode, recovered at +".$shift.'s',($v['estado']??'')==='recuperado'&&$v['episodio']===1);}
        $current=list35()[ref35('control035-unrelated-resource')]??[];ck35('Unrelated Core entry remains open',($current['estado']??null)==='aberto'&&$current['id']===$prior['control']&&$current['episodio']===1);
        $qrows=queue35();$opens=split35($qrows,'Incidente técnico');
        ck35('No new opening in persisted Core outbox',count($opens)===4&&!array_diff(array_keys($opens),$prior['opening_ids']));
    }
    $proof=['weekly_resolved'=>4,'elapsed_seconds'=>$delta,'original_openings'=>count($opens),'new_weekly_openings'=>0,'weekly_recovery_receipts'=>count(split35($qrows,'Recuperação técnica'))];
    $GLOBALS['f3qa035_clock_shift']=0;
    $count=11;$fresh=run35($weekly[0]);ck35('New provider read: below threshold remains resolved without rows or invented success',$fresh['outcome']==='nao_aplicavel'&&$fresh['successful_rows']===0&&$fresh['availability_assessment']['followers_count']===11&&empty(read35($weekly[0])['last_success_at']));
    $source='available';$fresh=run35($weekly[0]);ck35('Later useful response is collected and restores the real success date',$fresh['outcome']==='complete'&&$fresh['successful_rows']===1&&!empty(read35($weekly[0])['last_success_at'])&&empty(read35($weekly[0])['availability_assessment']));
    $day=gmdate('Y-m-d',time()-86400);$daily='ig-diaria-controle-035';new35($daily,$q+['report'=>'account_insights','fields'=>['reach'],'granularity'=>'day','date_from'=>$day,'date_to'=>$day],1440);$j=run35($daily);
    ck35('A real upstream rejection on daily report stays a failure',$j['outcome']==='failed'&&$j['successful_rows']===0&&empty(read35($daily)['availability_assessment']));
    observe35();ck35('Actual failure is not reported prematurely',!in_array($daily,issueIds35('schedule_collection_unresolved'),true)&&!isset(list35()[scheduleRef35($daily)]));
    $GLOBALS['f3qa035_clock_shift']=$delta;observe35();observe35();$e=list35()[scheduleRef35($daily)]??[];$newQ=queue35();
    ck35('True daily failure opens exactly one Core incident at +26h',in_array($daily,issueIds35('schedule_collection_unresolved'),true)&&($e['estado']??null)==='aberto'&&$e['episodio']===1);
    ck35('One new genuine daily opening persisted after repeats',count(split35($newQ,'Incidente técnico'))===5&&count(array_diff_key(split35($newQ,'Incidente técnico'),$opens))===1);
    $proof['genuine_daily_openings']=1;
}
echo wp_json_encode(['phase'=>$phase,'baseline_version'=>$baselineVersion,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'meta'=>M\Config::VERSION,'core'=>F3BASE_PLUGIN_VERSAO,'proof'=>$proof,'assertions'=>count($checks),'graph_calls'=>$graphCalls,'passed'=>true])."\n";
}
