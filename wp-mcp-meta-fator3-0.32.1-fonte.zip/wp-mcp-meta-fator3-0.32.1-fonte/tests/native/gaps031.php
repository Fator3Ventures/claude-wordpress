<?php
/** Daily calendar simulation in an isolated WP. HTTP provider and mail transport mocked; Core observer real. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
require __DIR__.'/seed-connection090.php';
if(!class_exists('F3Base_Incidentes_Provedores'))throw new RuntimeException('This suite requires the shipped Site Core.');
$checks=[];$ck=static function(string $name,bool $ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>$ok];if(!$ok)throw new RuntimeException($name);};
$cid='gap-lab-031';$sid='gap-ig-daily-031';$acc='11031';$mail=[];$http=[];$success=false;
$to='recovery-lab@example.invalid';$cfg=F3Base_Options::ler('f3base_avisos_tecnicos');$cfg['email']=$to;F3Base_Options::gravar('f3base_avisos_tecnicos',$cfg);
add_filter('pre_wp_mail',static function($prev,$args)use(&$mail){$mail[]=$args['to'];return true;},PHP_INT_MAX,2);
add_filter('pre_http_request',static function($prev,$args,$url)use(&$http,&$success,$acc){
 $path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);
 if($path!=='/v24.0/'.$acc.'/insights')return new WP_Error('unexpected_request');
 $http[]=gmdate('Y-m-d',(int)$q['since']);return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode(['data'=>$success?[['name'=>'reach','total_value'=>['value'=>7]]]:[]])];
},1,3);
lab_seed_connection090(['connection_id'=>$cid,'expected_revision'=>0,'enabled'=>true,'token'=>'lab-031','assets'=>['instagram'=>[$acc]],'users'=>[1]]);
$today=gmdate('Y-m-d',time()-86400);$yesterday=gmdate('Y-m-d',time()-2*86400);$q=['connection_id'=>$cid,'channel'=>'instagram','account_id'=>$acc,'report'=>'account_insights','fields'=>['reach'],'granularity'=>'day','date_from'=>$today,'date_to'=>$today];
$edit=function(string $bucket,string $key,callable $fn){$r=M\Store::get($bucket,$key);$v=$r['value'];$fn($v);if($bucket==='schedule')M\Schedules::checkpoint(['key'=>$key]+$r,$v);else M\Store::put($bucket,$key,$v,$r['revision']);};
$sched=fn()=>M\Store::get('schedule',$sid)['value'];
$read=fn()=>M\Api::dispatch('health')['data'];
$observe=static function(){M\Worker::notify();F3Base_Incidentes_Provedores::meta();M\Worker::notify();F3Base_Incidentes_Provedores::meta();};
$cfg=['schedule_id'=>$sid,'query'=>$q,'enabled'=>true,'interval_minutes'=>1440,'lookback_days'=>1,'next_at'=>time()-90,'expected_revision'=>0];
M\Schedules::save($cfg);M\Schedules::tick();$first=$sched()['last_job'];
// Advance the synthetic calendar by placing the first scheduled job on the preceding agent day.
$edit('job',$first,static function(&$v)use($yesterday){$v['query']['date_from']=$v['query']['date_to']=$yesterday;});
$j=M\Jobs::run($first,true);$h=$read();$ck('First scheduled day terminates without useful data',$j['status']==='partial'&&$j['outcome']==='failed'&&$j['successful_rows']===0);
$ck('A day with no successful row is retained',array_keys($sched()['pending_days'])===[$yesterday]);
$ck('Real failures remain visible before the incident threshold',$h['state']==='degraded'&&$h['failed_schedules']===1);
$near=time()-26*3600+60;$edit('schedule',$sid,static function(&$v)use($near){$v['collection_failure_since']=$near;$v['collection_success_at']=$near;});
$observe();$ck('Neither publisher nor Core observer notifies before 26h',$mail===[]);
$aged=time()-26*3600-3;$edit('schedule',$sid,static function(&$v)use($aged){$v['collection_failure_since']=$v['collection_success_at']=$aged;});
$observe();$h=$read();$ck('One incident from the two real observers after 26h',count($mail)===1&&$mail[0]===$to&&in_array('schedule_collection_unresolved',array_column($h['issues'],'code'),true));
$slot=time()-9;$edit('schedule',$sid,static function(&$v)use($slot){$v['next_at']=$slot;});M\Schedules::tick();
$s=$sched();$second=$s['last_job'];$gap=$s['pending_days'][$yesterday]??null;$cur=M\Store::get('job',$second)['value'];$part=$gap?M\Store::get('job',$gap)['value']:null;
$ck('Ordinary window still covers its most recent day only',$first!==$second&&$cur['query']['date_from']===$today&&$cur['query']['date_to']===$today);
$ck('Next pass also queues exactly the missed prior day outside lookback 1',$gap!==$first&&$gap!==$second&&$part['status']==='queued'&&$part['gap_day']===$yesterday&&$part['query']['date_from']===$yesterday&&$part['query']['date_to']===$yesterday);
$ck('Gap replay records the applied policy revision',$part['gap_policy_revision']===M\RecoveryPolicy::current()['revision']);
$edit('schedule',$sid,static function(&$v)use($slot){$v['next_at']=$slot;});M\Schedules::tick();
$ck('Restarting the identical slot keeps exactly the same jobs',$sched()['last_job']===$second&&$sched()['pending_days'][$yesterday]===$gap);
$ck('Both queued jobs remain eligible for priority selection',!array_diff([$second,$gap],M\Schedules::priorityJobs()));$observe();$ck('Re-dispatch is not evidence of recovery',count($mail)===1);
$success=true;M\Jobs::run($second,true);$observe();$ck('Actual successful collection closes one incident',count($mail)===2&&$mail[1]===$to&&!in_array('schedule_collection_unresolved',array_column($read()['issues'],'code'),true));
M\Jobs::run($gap,true);M\Jobs::run($gap,true);$observe();
$hist=M\History::query(['connection_id'=>$cid,'channel'=>'instagram','account_id'=>$acc,'report'=>'account_insights','date_from'=>$yesterday,'date_to'=>$today]);$days=array_map(static fn($r)=>$r['row']['date'],$hist['rows']);sort($days);
$ck('History keeps exactly two measured days, one row per date even after repeated processing',$days===[$yesterday,$today]&&$http===[$yesterday,$today,$yesterday]);
$ck('Recovery removes gap, duplicate processing sends no new technical notice',empty($sched()['pending_days'])&&count($mail)===2);
$old=gmdate('Y-m-d',time()-31*86400);$valid=gmdate('Y-m-d',time()-30*86400);
$edit('schedule',$sid,static function(&$v)use($old,$valid,$first){$v['pending_days']=[$old=>$first,$valid=>$first];$v['next_at']=time()-50;});M\Schedules::tick();
$ck('Only last 30 provider calendar days are eligible',!isset($sched()['pending_days'][$old])&&isset($sched()['pending_days'][$valid]));
$dates=[];for($ago=3;$ago<=9;++$ago)$dates[]=gmdate('Y-m-d',time()-$ago*86400);
$edit('schedule',$sid,static function(&$v)use($dates,$first){$v['pending_days']=array_fill_keys($dates,$first);$v['next_at']=time()-53;});M\Schedules::tick();
$replays=$sched()['pending_days'];$ck('Seven disjoint-from-lookback dates are all queued on next pass',count(array_intersect_key($replays,array_flip($dates)))===7&&count(array_unique(array_intersect_key($replays,array_flip($dates))))===7&&!in_array($first,$replays,true));
// Outstanding window must outlive dispatch cycles even when no job reaches a terminal state.
$ck('Queued unchanged past the deadline also alerts',M\ScheduleGaps::since(['enabled'=>true,'next_at'=>time()+86400,'last_run_status'=>'queued','collection_failure_since'=>$aged,'interval_minutes'=>1440],time())===$aged);
$stillQueued=['enabled'=>true,'last_run_status'=>'queued','next_at'=>time()+86400,'interval_minutes'=>1440];
M\ScheduleGaps::failure($stillQueued,$aged);$stillQueued['last_success_at']=time();
$ck('Intermediate page progress cannot slide the time of the last completed run',M\ScheduleGaps::since($stillQueued,time())===$aged);
$ck('Never-due and disabled schedules do not alert',M\ScheduleGaps::since(['enabled'=>true,'next_at'=>time()+86400],time())===null&&M\ScheduleGaps::since(['enabled'=>false,'collection_failure_since'=>$aged],time())===null);
// Return to the original selection on exactly the same due slot, then deliver its original job late.
$oldEpoch=$sched()['collection_epoch'];$late=M\Store::get('job',$second)['value'];$late['updated_at']=time();
$cfg['next_at']=$slot;$cfg['expected_revision']=1;$cfg['query']['fields']=['views'];M\Schedules::save($cfg);M\Schedules::tick();$other=$sched()['last_job'];
$cfg['expected_revision']=2;$cfg['query']=$q;M\Schedules::save($cfg);M\Schedules::tick();$reset=$sched();$resetJob=$reset['last_job'];
$ck('Returning to the original selection in the same slot creates a new schedule generation and job',count(array_unique([$second,$other,$resetJob]))===3&&$oldEpoch!==$reset['collection_epoch']);
M\CollectionState::record($second,$late,M\Connections::get($cid),true);$reset=$sched();
$ck('Late success from a retired generation cannot credit the new selection',empty($reset['collection_success_at'])&&$reset['last_job']===$resetJob&&$reset['last_run_status']==='queued');
$late['schedule_epoch']=$reset['collection_epoch'];$reset['pending_days']=[$today=>$resetJob];$reset['collection_failure_since']=$aged;
$changed=M\ScheduleGaps::record($reset,$sid,$second,$late,false);
$ck('Late success of the same generation updates only the clock, preserving the current pending slot and days',$changed&&$reset['collection_success_at']===$late['updated_at']&&$reset['last_run_status']==='queued'&&$reset['collection_failure_since']===$aged&&$reset['pending_days']===[$today=>$resetJob]&&M\ScheduleGaps::since($reset,time())===null);
echo wp_json_encode(['version'=>M\Config::VERSION,'total'=>count($checks),'failed'=>0,'checks'=>$checks,'synthetic_graph_calls'=>count($http),'intercepted_core_emails'=>count($mail)])."\n";
