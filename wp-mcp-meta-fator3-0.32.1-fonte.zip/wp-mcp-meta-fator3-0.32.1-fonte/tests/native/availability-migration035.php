<?php
/** Local native WP fixture. Stored Graph evidence, real encrypted schedules/jobs/results and existing incident outbox. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$checks=[];$receipts=[];$offline=true;
function ck35m(string $name,bool $ok):void{global $checks;$checks[$name]=$ok;if(!$ok)fwrite(STDERR,"FAIL: $name\n");}
$clock=time()-3*86400;$q=['connection_id'=>'migration035','channel'=>'instagram','account_id'=>'12345','report'=>'audience','fields'=>['follower_demographics'],'breakdown'=>'city'];
$make=function(string $id,string $mode)use($q,$clock){
    $key=hash('sha256',$id);$d=['code'=>'empty_or_suppressed','observed_at'=>$clock,'http_status'=>null,'provider_code'=>null];
    $e=$d+['field'=>'follower_demographics','classification'=>'provider_data_unavailable','cause'=>'undetermined','rule_confirmed'=>false];
    $s=['query'=>$q,'label'=>$id,'last_job'=>$key,'enabled'=>true,'next_at'=>$clock+7*86400,'interval_minutes'=>10080,'edit_revision'=>8,
        'last_code'=>'fields_unavailable','last_run_status'=>'failed','last_error'=>$d,'last_errors'=>[],'unavailable_metrics'=>['follower_demographics'],'last_successful_rows'=>0,
        'collection_epoch'=>'existing-generation','availability_assessment'=>null,'last_success_at'=>null,'collection_success_at'=>null,'collection_failure_since'=>null];
    $j=['query'=>$q,'schedule_id'=>$id,'schedule_epoch'=>$s['collection_epoch'],'status'=>'partial','outcome'=>'failed','last_code'=>'fields_unavailable','errors'=>[$e],
        'pages'=>1,'rows'=>1,'successful_rows'=>0,'next_at'=>0,'updated_at'=>$clock,'cursor'=>null];
    $cov=['plan_complete'=>true,'successful_rows'=>0,'error_count'=>1,'errors'=>[$e],'errors_sampled'=>false];
    switch($mode){
        case 'job':$s['collection_failure_since']=$clock-7200;break;
        case 'snapshot':$s['last_errors']=[$d];break;
        case 'missing_page':break;
        case 'auth':$s['last_error']['code']='not_authorized';break;
        case 'network':$s['last_error']['http_status']=503;break;
        case 'mixed':$cov['error_count']=2;$cov['errors_sampled']=true;break;
        case 'wrong_job':$j['schedule_id']='other';break;
        case 'wrong_query':$j['query']['account_id']='012345';break;
        case 'wrong_epoch':$j['schedule_epoch']='other';break;
        case 'stale_generation':$j['credential_generation']=1;$s['credential_generation']=2;break;
        case 'recent_success':$s['last_success_at']=$clock+1;break;
        case 'real':$s['query']['report']='account_insights';$s['interval_minutes']=1440;$s['last_code']='upstream_error';$s['last_error']['code']='upstream_error';$s['collection_error_since']=$clock;$s['collection_failure_since']=$clock;break;
        case 'disabled':$s['enabled']=false;break;
        case 'other_field':$s['unavailable_metrics']=['reach'];break;
        case 'no_evidence':$s['last_error']['code']='fields_unavailable';break;
        case 'null_rows':$s['last_successful_rows']=null;break;
        case 'newer_failure':$s['collection_failure_since']=$clock+120;break;
        case 'last_errors':$s['last_errors']=[['code'=>'upstream_error','observed_at'=>$clock]];break;
    }
    if(in_array($mode,['job','missing_page','mixed','wrong_job','wrong_query','wrong_epoch','stale_generation','auth','network','unreadable_job','unreadable_page'],true)){
        M\Store::put('job',$key,$j);
        if($mode!=='missing_page')M\Store::put('result',$key.':000000',['query'=>$q,'data'=>['channel'=>'instagram','report'=>'audience','connection_id'=>$q['connection_id'],'account_id'=>$q['account_id'],'coverage'=>$cov,'rows'=>[['metric'=>'follower_demographics','value'=>null]],'next_cursor'=>null]]);
    }
    M\Store::put('schedule',$id,$s);return $key;
};
$yes=['job','snapshot','missing_page'];$no=['auth','network','mixed','wrong_job','wrong_query','wrong_epoch','stale_generation','recent_success','real','disabled','other_field','no_evidence','null_rows','newer_failure','last_errors','unreadable_job','unreadable_page'];
$jobs=[];foreach(array_merge($yes,$no) as $mode)$jobs[$mode]=$make('m035-'.$mode,$mode);
// Simulate unreadable ciphertext, including a schedule unrelated to the others. The migration must preserve each record.
global $wpdb;$badId='m035-bad-record';$make($badId,'disabled');$original=[];
$broken=[['job',$jobs['unreadable_job']],['result',$jobs['unreadable_page'].':000000'],['schedule',$badId]];
foreach($broken as [$b,$k]){
    $original[]=$wpdb->get_var($wpdb->prepare('SELECT payload FROM %i WHERE bucket=%s AND record_key=%s',M\Store::table(),$b,$k));
    $wpdb->update(M\Store::table(),['payload'=>'unreadable-fixture-035'],['bucket'=>$b,'record_key'=>$k]);
}
$ids=array_map(fn($n)=>hash('sha256','schedule_overdue|m035-'.$n),array_combine($yes,$yes));
$other=hash('sha256','schedule_overdue|m035-real');$t=fn($id)=>['pacote'=>'meta','codigo'=>'agenda_parada','recurso'=>$id,'desde'=>$clock];
$old=['active'=>[$ids['job']=>$t($ids['job']),$other=>$t($other)],'pending'=>[$ids['job']=>[$t($ids['job'])+['estado'=>'aberto']],$other=>[$t($other)+['estado'=>'aberto']]]];
update_option('f3_meta_incident_transitions',$old,false);update_option('f3_meta_site_owner_031',1,true);
$previous=M\Store::get('job',$jobs['job']);$result=M\Store::get('result',$jobs['job'].':000000');
add_filter('f3base_incidente_publicar_v1',function($reply,$data)use(&$receipts,&$offline){$receipts[]=[$data['recurso'],$data['estado']];return ['ok'=>!$offline];},999,2);
M\Worker::bootstrap();
foreach($yes as $key){
    $r=M\Store::get('schedule','m035-'.$key);$s=$r['value'];$a=$s['availability_assessment'];
    ck35m($key.': eligible source absence, matching account and original time',($a['reason']??null)==='audience_data_unavailable'&&$a['account_id']===$q['account_id']&&$a['observed_at']===$clock&&!isset($a['followers_count'])&&$s['last_run_status']==='nao_aplicavel');
    ck35m($key.': cadence, data clock and editor revision preserved',$s['enabled']&&$s['next_at']===$clock+7*86400&&$s['interval_minutes']===10080&&$s['edit_revision']===8&&$s['last_success_at']===null&&$s['collection_success_at']===$clock&&empty($s['collection_failure_since'])&&$s['last_job']===$jobs[$key]&&$s['last_error']['code']==='empty_or_suppressed');
}
foreach($no as $key){$r=M\Store::get('schedule','m035-'.$key);ck35m($key.': original failure preserved',$r['revision']===1&&$r['value']['last_run_status']==='failed'&&$r['value']['availability_assessment']===null);}
ck35m('history and terminal job byte-for-byte equivalent',M\Store::get('job',$jobs['job'])===$previous&&M\Store::get('result',$jobs['job'].':000000')===$result);
ck35m('daily real fault is still due',M\ScheduleGaps::since(M\Store::get('schedule','m035-real')['value'],time())!==null);
$o=get_option('f3_meta_incident_transitions');ck35m('only recovery receipts, including observer-only and stale queued opening',count($receipts)===count($yes)&&count(array_filter($receipts,fn($rc)=>in_array($rc[0],$ids,true)&&$rc[1]==='recuperado'))===count($yes));
ck35m('unrelated incident and opening unchanged',$o['active'][$other]===$old['active'][$other]&&$o['pending'][$other]===$old['pending'][$other]);
ck35m('offline recovery queued durably for every eligible schedule',count(array_filter($ids,fn($id)=>array_column($o['pending'][$id]??[],'estado')===['recuperado']))===count($yes));
$once=count($receipts);$revs=array_map(fn($k)=>M\Store::get('schedule','m035-'.$k)['revision'],$yes);M\Worker::bootstrap();M\ScheduleReclassification::run();
ck35m('warm bootstrap does not reclassify or duplicate recovery',$once===count($receipts)&&$revs===array_map(fn($k)=>M\Store::get('schedule','m035-'.$k)['revision'],$yes)&&M\Store::get('migration','audience-availability-035')===null);
$offline=false;M\Store::put('migration','audience-availability-035',['ids'=>['m035-job']]);update_option('f3_meta_site_owner_031',1,true);
M\ScheduleReclassification::run();$o=get_option('f3_meta_incident_transitions');
ck35m('restart after checkpoint resends only recovery, then removes journal',end($receipts)===[$ids['job'],'recuperado']&&!isset($o['pending'][$ids['job']])&&M\Store::get('migration','audience-availability-035')===null);
foreach($broken as $n=>[$b,$k]){
    $payload=$wpdb->get_var($wpdb->prepare('SELECT payload FROM %i WHERE bucket=%s AND record_key=%s',M\Store::table(),$b,$k));
    ck35m($b.': unreadable ciphertext not rewritten or deleted',$payload==='unreadable-fixture-035');
    $wpdb->update(M\Store::table(),['payload'=>$original[$n]],['bucket'=>$b,'record_key'=>$k]);
}
echo wp_json_encode(['total'=>count($checks),'failed'=>count(array_filter($checks,fn($ok)=>!$ok)),'checks'=>$checks])."\n";exit(in_array(false,$checks,true)?1:0);
