<?php
/** Real WP REST, option persistence, revision guard and preview binding. No supplier. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
wp_set_current_user(1);
$checks=[];$http=0;
function pc31($n,$pass){global $checks;$checks[]=['name'=>$n,'passed'=>$pass===true];}
function req31($op,$i=[]){$r=new WP_REST_Request('POST','/'.M\Config::REST.'/'.$op);$r->set_header('Content-Type','application/json');$r->set_body(wp_json_encode((object)$i));$v=rest_do_request($r);return ['http'=>$v->get_status()]+$v->get_data();}
$intercept=static function($pre)use(&$http){++$http;return new WP_Error('unexpected_remote_request');};add_filter('pre_http_request',$intercept,1);
global $wpdb;$countAudit=static fn()=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".M\Store::table()." WHERE bucket='audit'");
if(get_option('f3_meta_recovery_policy',false)!==false)throw new RuntimeException('Requires fresh isolated option');
try{
$n=$countAudit();$base=req31('get-recovery-policy');$policy=$base['data']['policy'];$defaults=['retry_minutes'=>[5,10,20,40,60],'repeat_minutes'=>360,'max_attempts'=>8,'gap_days'=>30];
pc31('Default read from clean install',$base['success'] && $policy===$defaults+['revision'=>0]);
$p=['expected_revision'=>0,'policy'=>$defaults];$r=req31('simulate-recovery-policy',$p);
pc31('Default timing includes first attempt and repeating six-hour waits',$r['success']&&$r['data']['waits_minutes']===[5,10,20,40,60,360,360]&&$r['data']['changed']===false);
$p['policy']=['retry_minutes'=>[5,15],'repeat_minutes'=>60,'max_attempts'=>4,'gap_days'=>14];$preview=req31('simulate-recovery-policy',$p)['data'];
pc31('Bounded four-attempt preview',$preview['waits_minutes']===[5,15,60]&&$preview['total_wait_minutes']===80&&$preview['changed']);
pc31('Reading and simulating do not persist option, audit, or contact supplier',$countAudit()===$n&&!get_option('f3_meta_recovery_policy',false)&&!$http);
foreach([['retry_minutes',[5,1]],['retry_minutes',[]],['retry_minutes',array_fill(0,13,10)],['repeat_minutes',1],['gap_days',31],['max_attempts',1],['max_attempts',31]] as [$f,$v]){
 $i=$p;$i['policy'][$f]=$v;$r=req31('simulate-recovery-policy',$i);pc31('Refuses invalid '.$f.' '.json_encode($v),empty($r['success'])&&$r['code']==='invalid_input');
}
$r=req31('save-recovery-policy',$p+['plan_digest'=>str_repeat('0',64)]);pc31('Mismatched preview rejected',$r['code']==='simulation_mismatch'&&get_option('f3_meta_recovery_policy',false)===false);
$i=$p+['plan_digest'=>$preview['plan_digest']];$i['policy']['gap_days']++;pc31('Editing the preview invalidates confirmation',req31('save-recovery-policy',$i)['code']==='simulation_mismatch');
$r=req31('save-recovery-policy',$p+['plan_digest'=>$preview['plan_digest']]);pc31('First save confirms real option revision',($r['data']['persisted']??false)&&$r['data']['changed']&&$r['data']['policy']===$p['policy']+['revision'=>1]&&get_option('f3_meta_recovery_policy')===$r['data']['policy']);
pc31('Current runtime uses saved repeat and window',M\RecoveryPolicy::delayMinutes(M\RecoveryPolicy::current(),3)===60&&M\RecoveryPolicy::current()['gap_days']===14);
pc31('Old revision refused on a competing save',req31('save-recovery-policy',$p+['plan_digest'=>$preview['plan_digest']])['code']==='revision_conflict');
$p['expected_revision']=1;$same=req31('simulate-recovery-policy',$p)['data'];$r=req31('save-recovery-policy',$p+['plan_digest'=>$same['plan_digest']]);pc31('No-op does not increment revision',$r['data']['policy']['revision']===1&&!$r['data']['changed']);
$events=M\Audit::list([])['events'];pc31('Accepted effect recorded without exposing confirmation',(bool)array_filter($events,fn($e)=>$e['operation']==='save-recovery-policy'&&($e['policy_revision']??null)===1&&($e['changed']??null)===true&&!array_key_exists('plan_digest',$e)));
$u=wp_create_user('recovery-policy-subscriber',wp_generate_password(),'policy031@example.invalid');if(is_wp_error($u))throw new RuntimeException('Fresh subscriber required');(new WP_User($u))->set_role('subscriber');wp_set_current_user($u);
foreach(['get-recovery-policy','simulate-recovery-policy','save-recovery-policy'] as $op)pc31('Subscriber denied '.$op,req31($op,$p)['http']===403);
pc31('All policy calls were local',$http===0);
}finally{wp_set_current_user(1);remove_filter('pre_http_request',$intercept,1);}
$failed=count(array_filter($checks,static fn($r)=>!$r['passed']));echo wp_json_encode(['version'=>M\Config::VERSION,'total'=>count($checks),'failed'=>$failed,'checks'=>$checks])."\n";exit($failed?1:0);
