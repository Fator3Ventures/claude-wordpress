"""Policy in real wp-admin, real REST responses, synthetic isolated installation only."""
import json,os,sys
from pathlib import Path
from urllib.parse import unquote,urlparse
from playwright.sync_api import sync_playwright
out=Path(sys.argv[1]);url=os.environ['F3_QA_URL'];assert urlparse(url).hostname=='127.0.0.1'; checks=[];saves=[];errors=[]
def ck(w,n,b):
 checks.append(dict(width=w,name=n,passed=bool(b)))
def op(r,name):
 return r.request.method=='POST' and ('/'+name) in unquote(r.url)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox','--no-zygote'])
 p=b.new_page(locale='pt-BR',timezone_id='UTC');p.set_default_timeout(10000)
 p.route('**/*',lambda r:r.continue_() if r.request.url.startswith(url+'/') else r.abort())
 p.on('response',lambda r:saves.append(r.status) if op(r,'save-recovery-policy') else None)
 p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto(url+'/wp-login.php');p.locator('#user_login').fill('qa022admin');p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click()
 for width in (360,768,1440):
  p.set_viewport_size({'width':width,'height':900});p.goto(url+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab=diagnostics',wait_until='networkidle')
  recovery=p.locator('#f3-diagnostic-result');recovery.get_by_role('heading',name='Coletas em recuperação',exact=True).wait_for()
  ck(width,'A real pending job appears with a scheduled retry',recovery.locator('table').filter(has_text='Avulsa').count()>=1 and recovery.get_by_text('Sem horário',exact=True).count()==0)
  job_table=recovery.locator('table').filter(has_text='Avulsa')
  ck(width,'ID da coleta labels the technical column',job_table.locator('th').first.inner_text()=='ID da coleta')
  ck(width,'Full job ID stays selectable and within its own cell',job_table.locator('tbody tr').first.locator('td').first.evaluate("""c=>{const r=document.createRange();r.selectNodeContents(c);const b=c.getBoundingClientRect();return /^[0-9a-f]{64}$/i.test(r.toString())&&[...r.getClientRects()].every(x=>x.right<=b.right+1&&x.left>=b.left-1)}"""))
  sec=p.locator('#f3-recovery-settings');ck(width,'Initially collapsed',not sec.get_attribute('open') and not sec.locator('form').is_visible())
  with p.expect_response(lambda r:op(r,'get-recovery-policy')) as read:
   sec.locator('summary').click()
  current=read.value.json()['data']['policy'];form=sec.locator('form')
  ck(width,'Policy reads persisted revision and default waits',current['revision']==0 and current['retry_minutes']==[5,10,20,40,60])
  field=form.locator('[name=gap_days]');apply=sec.locator('#f3-recovery-apply');preview=sec.locator('#f3-recovery-preview');field.fill('14')
  ck(width,'Edited form cannot commit without simulation',apply.is_disabled())
  with p.expect_response(lambda r:op(r,'simulate-recovery-policy')) as sim:preview.click()
  report=sim.value.json()['data'];apply.wait_for(state='visible');p.wait_for_function("!document.querySelector('#f3-recovery-apply').disabled")
  ck(width,'Simulator retains current values and computes new 14-day plan',report['current']['gap_days']==30 and report['proposed']['gap_days']==14 and report['waits_minutes']==[5,10,20,40,60,360,360])
  ck(width,'Read and preview do not save',saves==[])
  ck(width,'All settings and action buttons fit horizontally',form.evaluate("(f)=>document.documentElement.scrollWidth<=innerWidth+1 && [...f.querySelectorAll('input,button')].filter(x=>x.offsetWidth).every(x=>x.getBoundingClientRect().right<=innerWidth+1)"))
  p.evaluate('window.scrollTo(0,0)');p.screenshot(path=str(out/'capturas'/('diagnostics-recovery-'+str(width)+'.png')),full_page=True,animations='disabled')
  field.fill('13');ck(width,'New edits invalidate the preview before commit',apply.is_disabled())
  if width==1440:
   with p.expect_response(lambda r:op(r,'simulate-recovery-policy')) as sim:preview.click()
   p.wait_for_function("!document.querySelector('#f3-recovery-apply').disabled")
   with p.expect_response(lambda r:op(r,'save-recovery-policy')) as save:apply.click()
   ck(width,'One guarded commit increments revision and writes 13 days',save.value.json()['data']['policy']['revision']==1 and save.value.json()['data']['policy']['gap_days']==13 and saves==[200])
   p.reload(wait_until='networkidle');sec=p.locator('#f3-recovery-settings')
   with p.expect_response(lambda r:op(r,'get-recovery-policy')) as read2:sec.locator('summary').click()
   ck(width,'Fresh page recovers saved policy and revision',read2.value.json()['data']['policy']['revision']==1 and read2.value.json()['data']['policy']['gap_days']==13)
 b.close()
ck(0,'No JavaScript error',not errors)
d={'checks':checks,'total':len(checks),'failed':sum(not x['passed'] for x in checks),'writes_to_isolated_lab':len(saves)};(out/'ui-policy.json').write_text(json.dumps(d,indent=2,ensure_ascii=False));assert not d['failed'],[x for x in checks if not x['passed']]
