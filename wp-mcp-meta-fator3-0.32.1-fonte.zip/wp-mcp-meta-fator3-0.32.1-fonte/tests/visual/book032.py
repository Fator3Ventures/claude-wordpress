"""Standalone visual acceptance notebook. Accept only synthetic captures from the local matrix."""
from pathlib import Path
from html import escape
from io import BytesIO
import base64,json,sys
from PIL import Image
root=Path(sys.argv[1]);out=Path(sys.argv[2]);doc=json.loads((root/'guia-visual.json').read_text())
if doc.get('environment')!='WordPress local isolado':raise SystemExit('Only synthetic local capture sets are eligible.')
def image(p):
 with Image.open(p) as im:
  b=BytesIO();im.convert('RGB').save(b,format='WEBP',quality=85,method=4)
 return 'data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
names=dict(connections='Conexão',assets='Ativos',reports='Relatórios',jobs='Coletas',history='Histórico',messaging='Conversas',archive='Arquivo de Stories',diagnostics='Diagnóstico',help='Ajuda');names['ads-access']='Consumidores de anúncios'
crit=['Integridade e ordem da folha comum','Cabeçalho e versão','Aviso externo após o cabeçalho','Grupos, subabas e endereços','Cor do esquema WordPress','Selos de estado','Rótulos e disposição dos campos','Tabelas e paginação','Largura sem rolagem geral','Alvos de toque','Foco por teclado','Folha CSS do Meta']
h=['''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meta 0.32.0 · Prova visual</title><style>:root{font-family:system-ui,sans-serif;color:#1d2327;background:#f6f7f7}body{margin:auto;max-width:1200px;padding:1rem}main,section,header{background:white;padding:1rem;margin-bottom:1rem;border-radius:.5rem}h1,h2{margin:0 0 .5rem}p{max-width:80ch}nav,.screens{display:flex;flex-wrap:wrap;gap:1rem}nav a{color:#135e96}figure{margin:0;flex:1 1 260px;min-width:0}figure img{display:block;width:100%;height:22rem;object-fit:contain;object-position:top;background:#eee;cursor:zoom-in}figure figcaption{font-weight:600;margin:.5rem 0}table{border-collapse:collapse;width:100%;font-size:.9rem}td,th{text-align:left;border-block-end:1px solid #dcdcde;padding:.35rem}dialog{border:0;padding:0;max-width:95vw;width:max-content;max-height:94vh;overflow:auto;background:#f6f7f7}dialog img{display:block;max-width:100%;height:auto}dialog button{position:sticky;top:.5rem;float:right;padding:.55rem 1rem;margin:.5rem;font:inherit}button.shot{border:1px solid #c3c4c7;padding:0;width:100%;background:none}code{overflow-wrap:anywhere}.ok{color:#005c12}details{margin:.7rem 0}summary{cursor:pointer}</style><header><h1>Fator3 MCP Meta 0.32.0</h1><p>Pedido MCP Meta 34 · Prova visual das dez subabas no WordPress de laboratório. A conta, os dados e o aviso externo são de demonstração. Selecione uma imagem para ler a captura em tamanho original.</p>''']
h.append(f'<p><strong>{doc["checks"]} conferências de layout e acessibilidade; {doc["failed"]} falhas.</strong> Análise de {len(doc["samples"])} telas em 360, 768 e 1440 px. A folha comum 1.0.0 tem SHA-256 <code>{doc["style_sha256"]}</code>. As fotografias usam o esquema Moderno; a alteração para o esquema Padrão foi verificada à parte no WordPress.</p><nav>')
for t in names:h.append(f'<a href="#{t}">{names[t]}</a>')
h.append('</nav></header>')
for t,n in names.items():
 rows=[s for s in doc['samples'] if s['tab']==t];h.append(f'<section id="{t}"><h2>{n}</h2><div class="screens">')
 for s in rows:
  name=f'{n} — {s["width"]} px';f=root/s['screenshot'];h.append(f'<figure><figcaption>{name}</figcaption><button class="shot" aria-label="Ampliar: {name}"><img src="{image(f)}" loading="lazy" alt="Administração do Meta: {name}, com aviso de outro plugin."></button></figure>')
 h.append('</div><details><summary>Conferência da seção 7 por largura</summary><table><tr><th>Critério do guia</th><th>360 px</th><th>768 px</th><th>1440 px</th></tr>')
 for i,k in enumerate(crit):
  h.append(f'<tr><th>{i+1}. {k}</th>'+''.join('<td class="ok">'+('Passou' if r['criteria'][i]['ok'] else 'Falhou')+'</td>' for r in rows)+'</tr>')
 h.append('</table></details></section>')
h.append('<section><h2>Verificações complementares</h2><p>Na referência 0.31.0, o WordPress injetava o aviso dentro do cabeçalho. Na candidata, a divisão é respeitada com JavaScript; sem JavaScript, o WordPress mantém o aviso antes da área do pacote, e o botão longo cabe no telefone.</p><div class="screens">')
for name,label in [('base-031-aviso-360.png','0.31.0 — aviso entre o título e a descrição'),('capturas/connections-360-sem-js.png','0.32.0 — aviso longo sem JavaScript, 360 px'),('capturas/connections-editor-360.png','Editor de conexão, 360 px'),('capturas/help-1440-esquema-padrao.png','Ajuda, esquema de cores Padrão, 1440 px')]:
 if (root/name).exists():h.append(f'<figure><figcaption>{label}</figcaption><button class="shot" aria-label="Ampliar: {label}"><img src="{image(root/name)}" loading="lazy" alt="{label}"></button></figure>')
h.append('</div></section>')
h.append('''<dialog><button type="button">Fechar</button><img alt=""></dialog><script>const d=document.querySelector("dialog"),di=d.querySelector("img");document.querySelectorAll("button.shot").forEach(b=>b.addEventListener("click",()=>{let i=b.querySelector("img");di.src=i.src;di.alt=i.alt;d.showModal();d.scrollTop=0}));d.querySelector("button").addEventListener("click",()=>d.close());</script></html>''')
out.write_text(''.join(h),encoding='utf-8')
