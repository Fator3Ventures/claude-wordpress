"""Validate final rehearsal evidence independently of browser stdout."""
import hashlib,json,sys
from pathlib import Path
from PIL import Image
d=Path(sys.argv[1]);archive=Path(sys.argv[2])
guide=json.loads((d/'guia-visual.json').read_bytes());flow=json.loads((d/'fluxos-visuais.json').read_bytes())
assert guide['checks']==360 and guide['failed']==guide['interactions_failed']==guide['javascript_error_count']==0
assert flow['total']==22 and flow['failed']==0
assert len({(s['tab'],s['width']) for s in guide['samples']})==30
assert len({s['tab'] for s in guide['alternate_palette'] if s['changed']})==10
files={};focus_count=0
for s in guide['samples']:
 f=d/s['screenshot'];im=Image.open(f);assert im.width==s['width'] and im.height>=900
 assert all(c['ok'] for c in s['criteria']) and len(s['criteria'])==12
 for el in s['criteria'][10]['measure']['tested']:
  accent=el['theme'].removeprefix('#');expected='rgb('+', '.join(str(int(accent[i:i+2],16)) for i in range(0,6,2))+')'
  assert el['ok'] and el['color']==expected and float(el['width'].removesuffix('px'))>=2
  focus_count+=1
 files[s['screenshot']]=hashlib.sha256(f.read_bytes()).hexdigest()
for f in sorted((d/'capturas').glob('*.png')):files.setdefault(str(f.relative_to(d)),hashlib.sha256(f.read_bytes()).hexdigest())
summary={'environment':guide['environment'],'installer_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'guide_criteria':360,'interactive_checks':len(guide['interactions']),'flow_checks':22,'focus_color_comparisons':focus_count,'capture_count_including_extra':len(files),'screen_sha256':files}
(d/'prova-fechada.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(summary['installer_sha256'],len(guide['samples']),len(files),focus_count)
