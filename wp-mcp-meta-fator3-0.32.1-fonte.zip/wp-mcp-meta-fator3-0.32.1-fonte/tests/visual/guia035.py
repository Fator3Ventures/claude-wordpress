"""Regressão visual real de 0.32.1. Instalar/semear antes; só aceita o WP de bancada.

python guia035.py <instalador.zip> <sha256> <diretório vazio de evidência>
Requer as variáveis de guide032.py, Tesseract eng e Chromium com Playwright.
"""
import concurrent.futures, datetime, hashlib, io, json, os, re, subprocess, sys, unicodedata, zipfile
from pathlib import Path
from urllib.parse import urlparse
from PIL import Image, ImageEnhance, ImageOps
here=Path(__file__).resolve().parent
archive,expected,out=Path(sys.argv[1]),sys.argv[2].lower(),Path(sys.argv[3])
assert re.fullmatch('[0-9a-f]{64}',expected)
assert urlparse(os.environ['F3_QA_URL']).hostname=='127.0.0.1'
root=Path(os.environ['F3_LAB_ROOT'])
assert root.parent==Path('/tmp') and re.fullmatch(r'f3qa022_[0-9a-f]{12}_',root.name) and not root.is_symlink()
installed=root/'wordpress/wp-content/plugins/wp-mcp-meta-fator3'
assert installed.is_dir() and not installed.is_symlink()
assert not (out/'capturas').exists(), 'Use um diretório sem capturas anteriores'
def sha(v):return hashlib.sha256(v).hexdigest()
def verify_runtime():
 assert sha(archive.read_bytes())==expected,'Arquivo instalador diferente da release'
 with zipfile.ZipFile(archive) as z:
  records={i.filename:i for i in z.infolist() if not i.is_dir()}
  assert set(records)=={'wp-mcp-meta-fator3/'+p.relative_to(installed).as_posix() for p in installed.rglob('*') if p.is_file()},'Árvores diferentes'
  for k,info in records.items():
   if (installed/Path(k).relative_to('wp-mcp-meta-fator3')).read_bytes()!=z.read(info):raise AssertionError('Arquivo instalado divergente '+k)
 return len(records)
def ocr(entry):
 im=Image.open(out/entry);w,h=im.size;filename=Path(entry).name
 box=(0,28,w,650) if 'sem-js' in filename else (175 if w==1440 else 2,28 if w==1440 else 44,w-4,{360:380,768:248,1440:235}[w])
 c=ImageEnhance.Contrast(ImageOps.grayscale(im.crop(box))).enhance(1.3)
 c=c.resize((c.width*2,c.height*2));buf=io.BytesIO();c.save(buf,format='PNG')
 t=subprocess.run(['tesseract','stdin','stdout','--psm','6','-l','eng'],input=buf.getvalue(),capture_output=True,check=True,env={**os.environ,'OMP_THREAD_LIMIT':'1'}).stdout.decode()
 n=' '.join(re.sub(r'[^a-zA-Z0-9 ]',' ',unicodedata.normalize('NFKD',t).encode('ASCII','ignore').decode()).lower().split())
 return {'arquivo':filename,'largura':w,'altura':h,'titulo':'fator3 mcp meta' in n,'versao':bool(re.search(r'vers.{1,3}o 0 32 1',n)),'aviso':bool(re.search('aviso de demon.{0,12} de outro plugin',n)),'botao_aviso':'outro plugin' in n and 'complementar' in n}
count=verify_runtime();out.mkdir(parents=True,exist_ok=True)
env={**os.environ,'F3_QA_VERSION':'0.32.1'};env.pop('F3_QA_QUICK',None)
for name,args in [('guide032.py',[]),('flow035.py',[]),('check-evidence032.py',[str(archive)])]:
 subprocess.run([sys.executable,str(here/name),str(out),*args],env=env,check=True)
assert verify_runtime()==count
guide=json.loads((out/'guia-visual.json').read_bytes())
flow=json.loads((out/'fluxos-visuais.json').read_bytes())
proof=json.loads((out/'prova-fechada.json').read_bytes())
assert guide['version']==flow['version']=='0.32.1' and expected==proof['installer_sha256']
assert len(proof['screen_sha256'])==33
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: images=list(ex.map(ocr,proof['screen_sha256']))
for i in images:assert all(i[k] for k in ['titulo','versao','aviso','botao_aviso']),i
proof.update({'versao':'0.32.1','arquivos_instalados_conferidos_antes_e_depois':count,'executado_em_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ocr':{'regiao':'Cabeçalho + aviso externo real, recorte do PNG. Sem JavaScript o WordPress conserva o aviso antes do cabeçalho.','metodo':'Tesseract eng; 2x; quatro marcadores em cada PNG','resultados':images}})
(out/'prova-fechada.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print('VISUAL35',expected,len(guide['samples']),len(images),proof['focus_color_comparisons'],flush=True)
