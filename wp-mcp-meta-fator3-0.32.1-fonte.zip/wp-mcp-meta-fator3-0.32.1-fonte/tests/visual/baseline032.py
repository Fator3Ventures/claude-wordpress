"""Prove the original layout with a genuine notice raised outside the plugin."""
import os,json
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
url=os.environ['F3_QA_URL'];assert urlparse(url).hostname=='127.0.0.1'
out=Path('r32/src/evidence/032/local');out.mkdir(parents=True,exist_ok=True)
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox']);p=b.new_page(viewport={'width':360,'height':900})
 p.route('**/*',lambda r:r.continue_() if r.request.url.startswith(url+'/') else r.abort())
 p.goto(url+'/wp-login.php');p.locator('#user_login').fill('qa022admin');p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click()
 p.goto(url+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab=connections',wait_until='networkidle')
 data=p.evaluate("""()=>({version:document.querySelector('.f3-badge')?.textContent,hrInsidePanel:!!document.querySelector('.f3-social > hr.wp-header-end'),externalNoticeVisible:document.querySelector('#f3-qa-external-notice')?.offsetHeight>0,externalNoticeInsideHeader:!!document.querySelector('.f3-social header #f3-qa-external-notice'),commonCSS:!!document.querySelector('link[href*="/wp-mcp-meta-fator3/assets/f3-ui.css"]')})""");assert data['version']=='Versão 0.31.0' and data['externalNoticeVisible'] and not data['commonCSS'] and not data['hrInsidePanel'],data
 p.screenshot(path=str(out/'base-031-aviso-360.png'));(out/'base-031.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n');b.close()
