<?php
require dirname(__DIR__).'/native/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
$arg=$argv[1]??'';
if(!in_array($arg,['modern','light','fresh'],true)||get_user_by('id',1)->user_login!=='qa022admin')exit(2);
update_user_option(1,'admin_color',$arg,true);
if(get_user_option('admin_color',1)!==$arg)exit(3);
