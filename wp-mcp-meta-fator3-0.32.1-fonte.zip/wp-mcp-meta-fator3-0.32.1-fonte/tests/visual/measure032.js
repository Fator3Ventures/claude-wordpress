/* Execute in the panel document (inside the iframe, if any). No network, storage or DOM writes.
   Arguments: {tab,version,noticeSelector,commonSha,ownCss,focus:[{kind,ok}],paletteVerified:boolean}.
   Returns one entry per criterion of section 7, with measurements and coverage counts. */
(p)=>{
 const q=(sel,el=document)=>Array.from(el.querySelectorAll(sel)), live=e=>e.getClientRects().length&&e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0, rect=e=>e.getBoundingClientRect(),css=e=>getComputedStyle(e),txt=e=>e?.textContent.trim()||'',hex=s=>{s=(s||'').trim();const m=s.match(/^#([\da-f]{6})$/i);return m?'rgb('+[1,3,5].map(i=>parseInt(s.slice(i,i+2),16)).join(', ')+')':s};
 const root=document.querySelector('.wrap.f3-social'),o=[],test=(n,ok,measure)=>o.push({n,ok:!!ok,measure}),vis=s=>q(s,root).filter(live),bad=(els,pred)=>els.filter(e=>!pred(e)).map(e=>e.id||e.name||e.tagName+'.'+e.className).slice(0,12);
 if(!root)return {missing_root:true};
 const links=q('link[rel=stylesheet][href]'),common=links.find(e=>e.href.includes('/wp-mcp-meta-fator3/assets/f3-ui.css')),own=links.find(e=>e.href.includes('/wp-mcp-meta-fator3/assets/admin.css'));
 test(1,common&&own&&links.indexOf(common)<links.indexOf(own)&&p.commonSha==='15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b',{commonSha:p.commonSha,commonBeforeOwn:!!common&&!!own&&links.indexOf(common)<links.indexOf(own)});
 const h=root.querySelector(':scope > header.f3-heading'),h1=h?.querySelector(':scope > h1'),description=h?.querySelector(':scope > p'),ver=h?.querySelector(':scope > .f3-version');
 test(2,root.classList.contains('f3-ui')&&txt(h1)==='Fator3 MCP Meta'&&txt(description)&&txt(ver)==='Versão '+p.version,{h1:txt(h1),description:txt(description),version:txt(ver),maxWidth:css(root).maxWidth});
 const hr=h?.nextElementSibling,notice=q(p.noticeSelector||'#f3-qa-external-notice').find(live),nav=root.querySelector('.f3-nav');
 test(3,hr?.matches('hr.wp-header-end')&&notice&&root.contains(notice)&&!h.contains(notice)&&(hr.compareDocumentPosition(notice)&Node.DOCUMENT_POSITION_FOLLOWING)&&(notice.compareDocumentPosition(nav)&Node.DOCUMENT_POSITION_FOLLOWING),{divider:hr?.className||null,noticeVisible:!!notice,insideHeader:!!notice&&!!h?.contains(notice),afterHeader:!!notice&&!!h&&(h.compareDocumentPosition(notice)&Node.DOCUMENT_POSITION_FOLLOWING)!==0});
 const groups=vis('.f3-groups a'),sub=vis('.f3-subtabs a'),names=groups.map(txt),tabLink=sub.filter(e=>e.getAttribute('data-tab')===p.tab&&e.getAttribute('aria-current')==='page'),sg=groups.filter(e=>e.hasAttribute('aria-current')),gn=txt(sg[0]),expected=({'Configurar':['Conexão','Ativos','Consumidores de anúncios'],'Dados':['Relatórios','Coletas','Histórico','Conversas','Arquivo de Stories'],'Suporte':['Diagnóstico','Ajuda']})[gn];
 test(4,nav?.getAttribute('aria-label')&&names.join('|')==='Configurar|Dados|Suporte'&&JSON.stringify(expected)===JSON.stringify(sub.map(txt))&&tabLink.length===1&&sg.length===1&&[...groups,...sub].every(e=>new URL(e.href).searchParams.has('tab'))&&q('nav nav',nav).length===0,{groups:names,activeGroup:gn,visibleTabs:sub.map(txt),activeTab:txt(tabLink[0])});
 const accent=hex(css(root).getPropertyValue('--wp-admin-theme-color')),activeFill=sg[0]&&css(sg[0]).backgroundColor,activeLine=tabLink[0]&&css(tabLink[0]).borderBottomColor;
 test(5,accent&&accent===activeFill&&accent===activeLine&&(p.paletteVerified!==false),{scheme:[...document.body.classList].find(x=>x.startsWith('admin-color-')),accent,activeFill,activeLine});
 const pills=vis('.f3-pill'),old=vis('.f3-badge,.f3-status-badge,.f3-warning,.f3-inline-error,.f3-identity-warning,.f3-credential-warning,.f3-notice,.f3-notice-error,.f3-danger-zone,.f3-panel'),badPill=bad(pills,e=>!!txt(e)&&[...e.classList].filter(c=>c.startsWith('is-')).every(c=>['is-warn','is-ok','is-info','is-error'].includes(c)));
 test(6,!old.length&&!badPill.length,{visiblePills:pills.length,legacyComponents:old.map(e=>e.className),badPill,neutral:pills.filter(e=>![...e.classList].some(c=>c.startsWith('is-'))).length});
 const f=vis('input:not([type=hidden]):not([type=button]):not([type=submit]), select,textarea'),isCheck=e=>['radio','checkbox'].includes(e.type),labels=e=>e.labels?Array.from(e.labels):[],name=e=>labels(e).some(l=>l.htmlFor&&l.htmlFor===e.id&&txt(l)),above=e=>labels(e).some(l=>{const r=rect(l);if(l.contains(e))return isCheck(e);return r.bottom<=rect(e).top+2});
 const bLabel=bad(f,e=>name(e)&&(isCheck(e)||above(e)));
 test(7,!q('.form-table',root).length&&!bLabel.length,{visibleFields:f.length,failedLabel:bLabel,formTables:q('.form-table',root).length});
 const tables=q('table',root),badTable=bad(tables,e=>e.closest('.f3-table-scroll')&&e.matches('.widefat')),large=vis('table').filter(e=>q('tbody tr',e).filter(live).length>20),tools=vis('.f3-list-tools');
 test(8,!badTable.length&&!large.length,{allTables:tables.length,unwrappedOrUnstyled:badTable,unpaginated:large.length,visibleToolbars:tools.length,visibleRows:vis('table').map(t=>q('tbody tr',t).filter(live).length)});
 const viewport=window.innerWidth,docWidth=document.documentElement.scrollWidth,navOverflow=bad([...groups,...sub],e=>rect(e).right<=viewport+1&&rect(e).left>=-1);
 test(9,docWidth===viewport&&!navOverflow.length,{viewport,document:docWidth,clippedNavigation:navOverflow});
 const buttons=vis('button,.button,input[type=submit]'),controls=[...buttons,...f],hit=e=>isCheck(e)?Math.max(rect(e).height,...labels(e).map(l=>rect(l).height)):rect(e).height;
 const shortNav=bad([...groups,...sub],e=>rect(e).height>=(viewport<=782?44:40)-.1),short=viewport<=782?bad(controls,e=>hit(e)>=39.9):[];
 test(10,!shortNav.length&&!short.length,{minNavigation:Math.min(...[...groups,...sub].map(e=>rect(e).height)),shortNav,shortControls:short,controls:controls.length,minControl:controls.length?Math.min(...controls.map(hit)):null});
 const foc=p.focus||[];test(11,foc.length>0&&foc.every(x=>x.ok),{tested:foc});
 const raw=(p.ownCss||'').replace(/\/\*[\s\S]*?\*\//g,''),colors=raw.match(/#[a-fA-F0-9]{3,8}(?=[;,\s}])|\b(?:rgba?|hsla?)\([^)]*\)/g)||[],defs=raw.match(/(?:^|[;{\s])--f3-[\w-]+\s*:/g)||[],sizes=[];
 for(const m of raw.matchAll(/(?:^|[;{])\s*([\w-]+)\s*:\s*([^;{}]+)/g))if(/^(?:padding|margin|gap|row-gap|column-gap|border-radius)(?:-|$)/.test(m[1])&&/(?:\d+\.?\d*)px\b/.test(m[2]))sizes.push(m[1]+':'+m[2]);
 test(12,raw.length>0&&!colors.length&&!defs.length&&!sizes.length,{domainBytes:p.ownBytes??raw.length,colorLiterals:colors,customTokenDefinitions:defs,outsideTokenSpacing:sizes});
 return {tab:p.tab,width:viewport,criteria:o,failed:o.filter(k=>!k.ok).map(k=>k.n)};
}
