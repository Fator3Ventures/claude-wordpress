"""Check navigation and notices; local-only WP account, no changes to plugin settings."""
import os,json,sys
from pathlib import Path
from urllib.parse import urlsplit,unquote
from playwright.sync_api import sync_playwright
u=os.environ['F3_QA_URL'];assert urlsplit(u).hostname=='127.0.0.1';checks=[];out=Path(sys.argv[1]);out.mkdir(exist_ok=True,parents=True)
def ck(n,x):checks.append({'name':n,'passed':bool(x)})
def gate(r):
 if not r.request.url.startswith(u+'/'):return r.abort()
 if r.request.method=='POST' and unquote(r.request.url).endswith('/query'):
  return r.fulfill(json={'success':False,'code':'rate_limited','message':'Limite simulado atingido. Tente novamente após a espera.','data':{}})
 return r.continue_()
panel=u+'/wp-admin/tools.php?page=wp-mcp-meta-fator3'
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox']);c=b.new_context(viewport={'width':768,'height':900});p=c.new_page();p.route('**/*',gate);p.set_default_timeout(6000)
 p.goto(u+'/wp-login.php');p.locator('#user_login').fill('qa022admin');p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click();p.goto(panel,wait_until='networkidle');version=p.locator('.f3-ui header .f3-version').inner_text();assert version=='Versão 0.32.1',version;d=p.locator('#f3-group-description').inner_text()
 ck('Endereço publicado sem aba abre Configurar › Conexão',p.locator('[data-tab=connections][aria-current=page]').is_visible())
 p.locator('[data-group=dados]').click();p.locator('[data-tab=reports][aria-current=page]').wait_for();ck('Navegar entre grupos troca descrição e mantém endereço próprio','tab=reports' in p.url and p.locator('#f3-group-description').inner_text()!=d)
 p.locator('[data-tab=history]').click();p.locator('[data-tab=history][aria-current=page]').wait_for();ck('Título no navegador acompanha a área e subaba','Histórico' in p.title() and 'Dados' in p.title())
 p.go_back(wait_until='networkidle');ck('Voltar no navegador recupera a subaba anterior',p.locator('[data-tab=reports][aria-current=page]').is_visible())
 p.wait_for_function("document.querySelector('#f3-context [name=account_id]').value!==''");p.locator('#f3-query .button-primary').click();msg=p.locator('#f3-message');msg.wait_for();ck('Erro do fornecedor simulado tem papel de alerta e estilo de erro',msg.get_attribute('role')=='alert' and 'is-error' in msg.get_attribute('class').split())
 msg.get_by_role('button',name='Dispensar').click();ck('Dispensar oculta o aviso e mantém o contexto',not msg.is_visible() and p.locator('[data-tab=reports][aria-current=page]').is_visible())
 p.locator('[data-group=suporte]').click();p.locator('#f3-recovery-settings summary').click()
 p.wait_for_function("!document.querySelector('#f3-recovery-policy fieldset').disabled");f=p.locator('#f3-recovery-policy');f.locator('[name=gap_days]').fill('14')
 with p.expect_response(lambda a:a.request.method=='POST' and '/simulate-recovery-policy' in unquote(a.url)) as resp:f.locator('#f3-recovery-preview').click()
 ck('Gravação segue condicionada a simulação válida após mudança visual',resp.value.json()['data']['proposed']['gap_days']==14 and not f.locator('#f3-recovery-apply').is_disabled())
 p.locator('[data-tab=help]').click();p.locator('#f3-help-index input[type=search]').fill('retenção');p.wait_for_function("document.querySelectorAll('#f3-help-index li:not([hidden])').length>0");ck('Busca nos manuais permanece operante',p.locator('#f3-help-index li:visible').count()>0)
 # Browser without JS: GET links must still resolve on the server using same test account.
 nj=b.new_context(java_script_enabled=False,reduced_motion='reduce',storage_state=c.storage_state(),viewport={'width':360,'height':900});q=nj.new_page();q.set_default_timeout(6000);q.route('**/*',gate);q.goto(panel,wait_until='networkidle')
 def hit(sel):
  q.wait_for_function("""s=>{const a=document.querySelector(s);if(!a)return false;const b=a.getBoundingClientRect();const e=document.elementFromPoint(b.x+b.width/2,b.y+b.height/2);return a===e||a.contains(e)}""",arg=sel)
 def real_click(sel):
  a=q.locator(sel);a.scroll_into_view_if_needed();hit(sel)
  with q.expect_navigation(wait_until='networkidle'):a.click()
 real_click('[data-group=dados]');ck('Sem JavaScript o link de grupo abre a primeira subaba de Dados','tab=reports' in q.url and q.locator('#f3-reports').is_visible())
 real_click('[data-tab=history]');ck('Endereço antigo do Histórico e subaba funcionam sem JavaScript','tab=history' in q.url and q.locator('#f3-history').is_visible())
 a=q.locator('[data-tab=jobs]');a.focus();q.keyboard.press('Shift+Tab');q.keyboard.press('Tab');ck('O teclado alcança a subaba Coletas sem JavaScript',a.evaluate('e=>document.activeElement===e'))
 with q.expect_navigation(wait_until='networkidle'):q.keyboard.press('Enter')
 ck('Tecla Enter abre o endereço da subaba sem JavaScript','tab=jobs' in q.url and q.locator('#f3-jobs').is_visible())
 for t in 'connections assets ads-access reports jobs history messaging archive diagnostics help'.split():
  q.goto(panel+'&tab='+t,wait_until='networkidle');section=q.locator('#f3-'+t+'[data-tab-panel]');dims=q.evaluate('()=>[document.documentElement.scrollWidth,innerWidth]');ck('Sem JavaScript: URL, visibilidade e largura de '+t,section.is_visible() and dims[0]==dims[1]);checks[-1]['document_width']=dims[0];checks[-1]['viewport']=dims[1]
  if t=='connections':
   (out/'capturas').mkdir(exist_ok=True);q.screenshot(path=str(out/'capturas'/'connections-360-sem-js.png'),animations='disabled')
 # Pedido 35: contrastar a projeção de dois resultados com evidência diferente.
 # O conteúdo decorre de duas coletas reais de bancada, sem interceptar a rota health.
 p.goto(panel+'&tab=diagnostics',wait_until='networkidle')
 neutral=p.locator('#f3-diagnostic-result li').filter(has_text='demo-publico-sem-dados').first
 limited=p.locator('#f3-diagnostic-result li').filter(has_text='demo-publico-limiar').first
 neutral.wait_for(state='visible');limited.wait_for(state='visible')
 n,l=neutral.inner_text(),limited.inner_text()
 future=p.locator('#f3-diagnostic-result').get_by_text('Estas agendas voltam a consultar a Meta no próximo horário.',exact=True)
 findings=[{'cenario':'Sem contagem verificável: a interface informa demografia indisponível','texto':n,'aprovado':'Execução resolvida sem dados' in n and 'demografia' in n and all(t not in n.lower() for t in ['undefined','null','seguidor','mínimo'])},
 {'cenario':'Contagem sintética de onze: a interface informa o mínimo cem','texto':l,'aprovado':'11 seguidores' in l and 'mínimo de 100' in l and 'undefined' not in l},
 {'cenario':'Agenda permanece programada','texto':future.inner_text(),'aprovado':future.is_visible()}]
 (out/'diagnostico-demografia.json').write_text(json.dumps({'versao':version.removeprefix('Versão '),'origem':'WordPress isolado; agenda, job, REST e DOM reais; respostas Graph simuladas','casos':findings},ensure_ascii=False,indent=2)+'\n')
 assert all(v['aprovado'] for v in findings),findings
 b.close()
s={'version':version.removeprefix('Versão '),'checks':checks,'total':len(checks),'failed':sum(not c['passed'] for c in checks),'supplier':'simulated','writes':0};(out/'fluxos-visuais.json').write_text(json.dumps(s,indent=2,ensure_ascii=False));print(s['total'],s['failed'],[c for c in checks if not c['passed']]);assert not s['failed']
