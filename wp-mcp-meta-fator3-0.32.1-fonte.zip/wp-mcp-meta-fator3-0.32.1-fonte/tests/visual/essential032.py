"""Render every route with PHP, then exercise destructive-action confirmations in Chromium.
    F3_SOCIAL_PHP=/path/to/php F3_QA_CHROME=/path/to/chromium python3 tests/visual/essential032.py RUNTIME EVIDENCE
Uses only synthetic credentials; requests are handled in memory. No provider or WP writes."""
import hashlib, json, os, sys, subprocess
from pathlib import Path
from lxml import html
from playwright.sync_api import sync_playwright
runtime=Path(sys.argv[1]);out=Path(sys.argv[2]);tests=Path(__file__).resolve().parents[1]
php=os.environ.get('F3_SOCIAL_PHP','php')
def render(tab):
    return json.loads(subprocess.check_output([php,str(tests/'browser/render.php'),str(runtime),'identity',tab]))
tabs='connections assets ads-access reports jobs history messaging archive diagnostics help'.split()
evidence={'scope':'HTML real do renderer PHP, helpers WP simulados; Chromium e JS do instalador, transporte simulado, nenhum efeito externo','routes':{},'checks':[]}
for tab in tabs:
    fixture=render(tab);doc=html.fromstring(fixture['html'])
    ids=doc.xpath('//*[@id]/@id')
    assert len(ids)==len(set(ids)) and [n.tag for n in doc.xpath('//header/*')]==['h1','p','span']
    assert doc.xpath('//header/following-sibling::*[1][self::hr and @class="wp-header-end"]')
    assert [a.get('data-tab') for a in doc.xpath('//nav[1]/div[not(@hidden)]/a[@data-tab and @aria-current]')]==[tab]
    assert [a.get('id') for a in doc.xpath('//*[@data-tab-panel and not(@hidden)]')]==['f3-'+tab]
    for control in doc.xpath('//input[not(@type="hidden")]|//select|//textarea'):
        assert control.get('id') and doc.xpath('//label[@for=$id]',id=control.get('id'))
    assert not doc.xpath('//form[not(@method="post")]|//form//form|//details[not(contains(@class,"f3-collapsible"))]')
    evidence['routes'][tab]={'ids_uniques':len(ids),'visible_tab':tab,'all_fields_labelled':True,'no_script_nav':True,'forms_safe_methods':True}
fixture=render('connections')
script=(runtime/'assets/admin.js').read_text()
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox'],headless=True)
    page=b.new_page();errors=[];page.on('pageerror',lambda x:errors.append(str(x)))
    def fresh():
        page.route('https://example.invalid/**',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body=fixture['html']))
        page.goto('https://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3')
    fresh();runner=(tests/'browser/identity-cases.js').read_text()
    proof=page.evaluate('(a)=>('+runner+')(window,a.fixture,a.js)',{'fixture':fixture,'js':script})
    assert proof['failed']==0
    evidence['checks']+=proof['checks']
    fresh()
    page.evaluate("""
    (cfg)=>{window.F3Social=cfg;window.sim={calls:[],job:'queued',allow:false};
     const s=window.sim;window.confirm=()=>s.allow;
     window.fetch=async(url,args)=>{const op=url.split('/').pop(),i=JSON.parse(args.body);s.calls.push({op,action:i.action});
      let data={};if(op==='list-jobs')data={jobs:[{job_id:'demo',revision:1,query:{report:'profile'},status:s.job,rows:0,pages:0}],next_offset:null};
      if(op==='control-job'){s.job=({cancel:'cancelled',pause:'paused',resume:'queued'})[i.action];}
      if(op==='admin-options')data={rows:[],next_offset:null};if(op==='list-fields')data={fields:[]};if(op==='list-schedules')data={schedules:[]};
      if(op==='list-connections')data={connections:cfg.bootstrap.connections,next_offset:null};
      return {ok:true,status:200,json:async()=>({success:true,version:cfg.version,data})}};
    }""",fixture['config'])
    page.add_script_tag(content=script)
    def ck(name,ok):
        assert ok,name
        evidence['checks'].append({'name':name,'passed':True})
    page.locator('#f3-connection-list button').filter(has_text='Editar conexão').first.click()
    form=page.locator('#f3-connection')
    form.locator('[name="token"]').fill('synthetic-candidate-secret')
    form.locator('#f3-remove-credentials summary').click()
    form.locator('[name="clear_token"]').check()
    form.evaluate("n=>n.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}))")
    ck('Declining credential removal does not send a write',page.evaluate("sim.calls.filter(x=>x.op==='save-connection').length")==0)
    page.locator('#f3-connection-back').click()
    ck('Declining to discard keeps draft and secret in same editor',form.is_visible() and form.locator('[name="token"]').input_value()=='synthetic-candidate-secret')
    page.evaluate('sim.allow=true');page.locator('#f3-connection-back').click()
    ck('Confirming discard clears secret and returns to list without saving',not form.is_visible() and form.locator('[name="token"]').input_value()=='' and not page.evaluate("sim.calls.some(x=>x.op==='save-connection')"))
    page.locator('[data-group="dados"]').click();page.locator('[data-tab="jobs"]').click()
    jobs=page.locator('#f3-job-list')
    jobs.get_by_role('button',name='Pausar',exact=True).click()
    jobs.get_by_role('button',name='Retomar',exact=True).click()
    ck('Pause and resume send expected manual control actions',page.evaluate("sim.calls.filter(x=>x.op==='control-job').map(x=>x.action)")==['pause','resume'])
    jobs.locator('details.f3-danger summary').click();page.evaluate('sim.allow=false')
    jobs.get_by_role('button',name='Cancelar coleta',exact=True).click()
    ck('Declining cancellation keeps queued job',page.evaluate("sim.job==='queued'&&!sim.calls.some(x=>x.action==='cancel')"))
    page.evaluate('sim.allow=true');jobs.get_by_role('button',name='Cancelar coleta',exact=True).click()
    ck('Accepting cancellation sends exactly one cancellation',page.evaluate("sim.job==='cancelled'&&sim.calls.filter(x=>x.action==='cancel').length===1"))
    ck('No javascript exceptions',not errors)
    b.close()
evidence['runtime_sha256']={n:hashlib.sha256((runtime/n).read_bytes()).hexdigest() for n in ['includes/Admin.php','assets/admin.js','assets/f3-ui.css','assets/admin.css']}
evidence['version']=fixture['config']['version'];evidence['total']=len(evidence['checks'])+len(evidence['routes']);evidence['failed']=0
out.write_text(json.dumps(evidence,indent=2,ensure_ascii=False)+'\n')
print('passed',evidence['total'])
