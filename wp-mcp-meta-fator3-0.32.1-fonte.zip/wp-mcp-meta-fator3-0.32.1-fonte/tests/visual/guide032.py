"""Acceptance matrix for Meta 34, backed by a real wp-admin and a real external notice.
Local: F3_QA_URL, F3_QA_CHROME, F3_QA_PASSWORD, F3_LAB_ROOT, F3_SOCIAL_PHP.
Site-Teste: F3_QA_URL, F3_QA_STORAGE_STATE or password/user, F3_QA_NOTICE_SELECTOR.
Remote mode opens tabs read-only and performs no data queries, profile writes or supplier calls.
"""
import os,sys,json,hashlib,subprocess
from pathlib import Path
from urllib.parse import unquote,urlparse
from playwright.sync_api import sync_playwright
here=Path(__file__).resolve().parent
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);shots=out/'capturas';shots.mkdir(exist_ok=True)
url=os.environ['F3_QA_URL'].rstrip('/');host=urlparse(url).hostname;local=host=='127.0.0.1';assert local or host=='fator3-teste-mcp-1.dreamhosters.com'
version=os.environ.get('F3_QA_VERSION','0.32.0');notice=os.environ.get('F3_QA_NOTICE_SELECTOR','#f3-qa-external-notice');js=(here/'measure032.js').read_text()
quick=os.getenv('F3_QA_QUICK')=='1';widths=[360] if quick else [360,768,1440];tabs='connections assets ads-access reports jobs history messaging archive diagnostics help'.split()
summary={'version':version,'environment':'WordPress local isolado' if local else 'Site-Teste','data_fixtures':local,'samples':[],'interactions':[],'javascript_errors':[],'outside_requests_blocked':0};oplog=[]
def write():
 (out/'guia-visual.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
def interaction(name,ok,**kwargs):
 summary['interactions'].append(dict(name=name,ok=bool(ok),**kwargs))
def intercept(route):
 req=route.request
 if not req.url.startswith(url+'/'):
  summary['outside_requests_blocked']+=1;return route.abort()
 op=unquote(req.url).split('/')[-1].split('&')[0].split('?')[0]
 if req.method=='POST' and op in ['query','story-archive','history-query','conversations']:
  if not local:return route.abort()
  oplog.append(op);rows=[dict(name=('Ação especial' if i==22 else 'Campanha de exemplo')+' '+str(i),date='2026-11-19',reach=1000+i,impressions=i*123,status='complete',account_id='1001') for i in range(1,26)]
  if op=='story-archive':rows=[dict(story_id='700'+str(i),caption='Story de exemplo '+str(i),thumbnail_available=False) for i in range(1,4)]
  return route.fulfill(json={'success':True,'data':{'rows':rows,'next_cursor':None,'coverage':'Stories de exemplo.' if op=='story-archive' else {'complete':True},'warnings':[],'started_per_day_in_page':{},'migration_complete':True,'retention':{'mode':'unlimited'}}})
 return route.continue_()
def taburl(t):return url+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab='+t
def goto(t):
 p.goto(taburl(t),wait_until='networkidle');p.locator('#f3-'+t+'.f3-section').wait_for()
def css_files():
 links=p.locator('link[rel=stylesheet][href]').evaluate_all('(links)=>links.map(l=>l.href)')
 a=[]
 for fname in ('f3-ui.css','admin.css'):
  matches=[s for s in links if '/wp-mcp-meta-fator3/assets/'+fname in s];assert len(matches)==1,(fname,matches)
  body=p.request.get(matches[0]).body();a.append(body)
 return hashlib.sha256(a[0]).hexdigest(),a[1].decode(),len(a[1])
def real_keyboard_focus():
 probe=[]
 for kind,selector in [('navigation','nav a[aria-current]'),('button','button:not(:disabled),a.button'),('field','input:not([type=hidden]):not(:disabled),select:not(:disabled),textarea:not(:disabled)'),('summary','summary')]:
  loc=p.locator('.f3-social').locator(selector).filter(visible=True);loc=loc.first
  if loc.count()==0:continue
  # Start at the element, step back, then into it via a genuine Tab keystroke.
  loc.focus();p.keyboard.press('Shift+Tab');p.keyboard.press('Tab')
  probe.append(dict(kind=kind,**loc.evaluate("""e=>{const s=getComputedStyle(e),a=getComputedStyle(e.closest('.f3-ui')).getPropertyValue('--wp-admin-theme-color').trim();return {ok:document.activeElement===e&&e.matches(':focus-visible')&&s.outlineStyle!=='none'&&parseFloat(s.outlineWidth)>=2,style:s.outlineStyle,width:s.outlineWidth,color:s.outlineColor,theme:a}}""")))
 return probe
def palette(scheme):subprocess.run([os.environ['F3_SOCIAL_PHP'],str(here/'palette032.php'),scheme],check=True,capture_output=True)
def screenshot(name):
 p.evaluate("()=>{document.activeElement?.blur();window.scrollTo(0,0)}");p.screenshot(path=str(shots/name),full_page=True,animations='disabled')
def content(tab):
 if not local:return
 if tab in ['reports','jobs','history','messaging','archive','diagnostics']:
  sel=p.locator('#f3-context [name=connection_id]');p.wait_for_function("document.querySelector('#f3-context [name=connection_id] option[value=\"demo-painel\"]')")
  if sel.input_value()!='demo-painel':sel.select_option('demo-painel')
  p.wait_for_function("document.querySelector('#f3-context [name=account_id]').value !== ''")
 if tab=='assets':
  sel=p.locator('#f3-assets-connection');sel.select_option('demo-painel');p.locator('fieldset[data-channel=instagram] input[type=checkbox]').first.wait_for()
 if tab=='reports':p.locator('#f3-query .button-primary').click();p.locator('#f3-result tbody tr').first.wait_for()
 if tab in ('history','messaging','archive'):
  key,dest={'history':('history-query','history-result'),'messaging':('msg-query','msg-result'),'archive':('archive-query','archive-result')}[tab]
  p.locator('#f3-'+key).click();p.wait_for_load_state('networkidle')
 if p.locator('.f3-result:visible button').count():p.locator('.f3-result:visible button').first.click()
def per_page(tab,width):
 goto(tab);content(tab)
 f=real_keyboard_focus()
 data=p.evaluate(js,dict(tab=tab,version=version,noticeSelector=notice,commonSha=sh,ownCss=own,ownBytes=owlen,focus=f,paletteVerified=True));data['screenshot']=str(Path('capturas')/(tab+'-'+str(width)+'.png'))
 screenshot(tab+'-'+str(width)+'.png');summary['samples'].append(data);write()
 return data
def pagination():
 target=p.locator('#f3-result');bar=target.locator('.f3-list-tools');nxt=bar.get_by_role('button',name='Próxima',exact=True)
 ready=bar.count()==1 and nxt.count()==1 and bar.locator('input[type=search]').count()==1
 if not ready:interaction('Resultados com 25 itens oferecem busca, total e paginação',False);return
 interaction('Primeira página com 20 de 25 resultados',target.locator('tbody tr:visible').count()==20 and '25' in bar.inner_text())
 nxt.click();interaction('Segunda página com cinco itens e Próxima desabilitada',target.locator('tbody tr:visible').count()==5 and nxt.is_disabled())
 bar.locator('input[type=search]').fill('acao especial');interaction('Busca encontra item 22 sem acento',target.locator('tbody tr:visible').count()==1 and 'Ação especial' in target.locator('tbody tr:visible').inner_text())
 bar.locator('input[type=search]').fill('')
with sync_playwright() as w:
 kw={'args':['--no-sandbox','--no-zygote']}
 if os.getenv('F3_QA_CHROME'):kw['executable_path']=os.environ['F3_QA_CHROME']
 b=w.chromium.launch(**kw);ctxkw={'locale':'pt-BR','timezone_id':'America/Sao_Paulo','reduced_motion':'reduce','viewport':{'width':1440,'height':900}}
 if os.getenv('F3_QA_STORAGE_STATE'):ctxkw['storage_state']=os.environ['F3_QA_STORAGE_STATE']
 ctx=b.new_context(**ctxkw);p=ctx.new_page();p.set_default_timeout(6000);p.route('**/*',intercept);p.on('pageerror',lambda e:summary['javascript_errors'].append(str(e)[:160]))
 if not os.getenv('F3_QA_STORAGE_STATE'):
  p.goto(url+'/wp-login.php');p.locator('#user_login').fill(os.environ.get('F3_QA_USER','qa022admin'));p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click()
 if local:palette('modern')
 goto('connections');sh,own,owlen=css_files();summary['style_sha256']=sh;summary['own_css_bytes']=owlen
 for width in widths:
  p.set_viewport_size({'width':width,'height':900})
  for tab in tabs:
   try:
    item=per_page(tab,width)
    if item['failed']:print(width,tab,item['failed'],flush=True)
    if local and tab=='reports' and width==360:pagination()
    if local and tab=='connections' and width==360:
     p.locator('.f3-edit-connection').first.click();p.wait_for_load_state('networkidle');res=p.evaluate(js,dict(tab=tab,version=version,noticeSelector=notice,commonSha=sh,ownCss=own,focus=real_keyboard_focus()));interaction('Editor de conexão na largura móvel',not res['failed'],failed=res['failed'],details=[c for c in res['criteria'] if not c['ok']]);screenshot('connections-editor-360.png')
   except Exception as ex:
    summary['samples'].append(dict(tab=tab,width=width,error=type(ex).__name__+': '+str(ex)[:450],failed=list(range(1,13))));print('ERRO',width,tab,str(ex)[:220],flush=True);write()
 if local and not quick:
  palette('fresh');variants=[]
  for tab in tabs:
   goto(tab);active=p.locator('.f3-groups a[aria-current]');line=p.locator('.f3-subtabs a[aria-current]:visible')
   d=active.evaluate("(e)=>({scheme:[...document.body.classList].find(x=>x.startsWith('admin-color-')),fill:getComputedStyle(e).backgroundColor,theme:getComputedStyle(e).getPropertyValue('--wp-admin-theme-color').trim()})");d['line']=line.evaluate('e=>getComputedStyle(e).borderBottomColor');d['tab']=tab
   source=next(a for a in summary['samples'] if a.get('tab')==tab and 'criteria' in a);prev=source['criteria'][4]['measure']['activeFill'];d['changed']=d['fill']!=prev and d['fill']==d['line'];variants.append(d)
  summary['alternate_palette']=variants;interaction('Mudança real do esquema de cores em todas as subabas',all(d['changed'] for d in variants))
  screenshot('help-1440-esquema-padrao.png');palette('modern')
 b.close()
summary['checks']=len(summary['samples'])*12;summary['failed']=sum(len(s['failed']) for s in summary['samples']);summary['javascript_error_count']=len(summary['javascript_errors']);summary['interactions_failed']=sum(not i['ok'] for i in summary['interactions']);write()
print('MATRIZ',summary['checks'],summary['failed'],summary['interactions_failed'],summary['javascript_error_count'],flush=True)
sys.exit(int(bool(summary['failed'] or summary['interactions_failed'] or summary['javascript_error_count'])))
