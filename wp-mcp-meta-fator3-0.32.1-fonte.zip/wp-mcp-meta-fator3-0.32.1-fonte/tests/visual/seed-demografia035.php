<?php
/** Duas agendas da bancada visual, Graph estritamente simulado e nenhum e-mail. */
use Fator3\Meta as M;
require dirname(__DIR__).'/native/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();
if ((parse_url(home_url(), PHP_URL_HOST) !== '127.0.0.1') || getenv('F3_QA_VISUAL_DEMO') !== '1') {
    throw new RuntimeException('Contexto visual privado obrigatório.');
}
wp_set_current_user(1);
$count = null;
$fake = static function($pre, $args, $url) use (&$count) {
    $path = parse_url($url, PHP_URL_PATH);
    parse_str(parse_url($url, PHP_URL_QUERY) ?? '', $query);
    if ($path === '/v24.0/1001/insights' && ($query['metric'] ?? '') === 'follower_demographics') {
        $body = ['data'=>[]];
    } elseif ($path === '/v24.0/1001' && ($query['fields'] ?? '') === 'id,followers_count') {
        $body = ['id'=>'1001'];
        if ($count !== null) $body['followers_count'] = $count;
    } else {
        return new WP_Error('visual_unexpected_endpoint');
    }
    return ['headers'=>[], 'body'=>wp_json_encode($body), 'response'=>['code'=>200]];
};
add_filter('pre_http_request', $fake, 1, 3);
try {
    $cases = [
        'demo-publico-sem-dados'=>['Público semanal: dados indisponíveis','city',null,'audience_data_unavailable'],
        'demo-publico-limiar'=>['Público semanal: contagem abaixo do mínimo','age',11,'below_minimum_followers'],
    ];
    foreach ($cases as $id => [$label,$dimension,$count,$reason]) {
        $existing = M\Store::get('schedule',$id);
        if (!$existing) {
            $q = ['connection_id'=>'demo-painel','channel'=>'instagram','account_id'=>'1001',
                  'report'=>'audience','fields'=>['follower_demographics'],'breakdown'=>$dimension];
            M\Schedules::save(['schedule_id'=>$id,'label'=>$label,'query'=>$q,'enabled'=>true,
                 'expected_revision'=>0,'interval_minutes'=>10080,'lookback_days'=>1,'next_at'=>time()+3600]);
            $rec = M\Store::get('schedule',$id);
            $v = $rec['value'];
            $v['next_at'] = time()-60;
            M\Schedules::checkpoint(['key'=>$id]+$rec,$v);
            M\Schedules::tick();
            $job = M\Store::get('schedule',$id)['value']['last_job'];
            M\Jobs::run($job,true);
        }
        $s = M\Store::get('schedule',$id)['value'];
        if (!$s['enabled'] || $s['last_run_status']!=='nao_aplicavel' ||
            $s['availability_assessment']['reason']!==$reason || ($s['last_successful_rows']??-1)!==0 ||
            !empty($s['last_success_at'])) throw new RuntimeException('Exemplo de agenda sem dados não confirmado: '.$id);
    }
} finally {
    remove_filter('pre_http_request',$fake,1);
}
echo "2 agendas semanais demonstrativas; respostas Graph simuladas.\n";
