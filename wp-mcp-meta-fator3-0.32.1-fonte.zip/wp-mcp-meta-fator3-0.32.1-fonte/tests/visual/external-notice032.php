<?php
/**
 * Plugin Name: Aviso de outro plugin — demonstração de layout
 * Description: Fixture exclusiva da bancada isolada de aceitação do pedido Meta 34.
 * Version: 1.0.0
 */
defined('ABSPATH') || exit;
add_action('admin_notices',static function(){
 if(!current_user_can('manage_options') || !function_exists('get_current_screen') || (get_current_screen()->id??'')!=='tools_page_wp-mcp-meta-fator3') return;
 echo '<div id="f3-qa-external-notice" class="notice notice-info"><p><strong>Aviso de demonstração de outro plugin.</strong> O WordPress apresenta este aviso após o cabeçalho do Meta.</p><p><a class="button" href="#f3-qa-external-notice">Ver orientação de configuração complementar fornecida por outro plugin</a></p></div>';
});
