# Fechamento — Meta 0.31.0

Checklist da seção 14 do padrão Fator3, revisão 5 de 02/11/2026.

- Base 0.30.0 oficial; instruções, padrão completo, regra comum, aba Meta, pedido 33 e relatórios recebidos examinados. A política, a recuperação e as novas operações justificam a mudança para 0.31.0.
- Requisitos no cabeçalho e manuais: WordPress 7.1.4+, PHP 8.3+ de 64 bits. Bancada 7.1.4/8.4.27; Site-Teste 7.1.5/8.3.37. Sem promessa de compatibilidade retroativa nem de downgrade.
- Instalador fechado, arquivo principal e raiz conservados, runtime no fonte verificado. A identidade final dos dois ZIPs está no relatório externo. O relatório interno antecede o fechamento do fonte.
- Conjunto e fronteiras testados: matriz com cinco acompanhantes sem alterar seus pacotes. Em paralelo, o transporte disponível ao fim no Site-Teste se identificou como MCP 0.53.0 e foi verificado separadamente. Não há solicitação técnica para outro plugin.
- Instalação limpa e atualização direta com dados, preservação de credenciais, permissões, retenção, IDs e progresso: smoke, migration, cross-base e cross-verify. Os testes dedicados de métricas, pausas, lacunas e política usam Graph simulada e banco WordPress real; incidentes exercitam o contrato do Core real. Sem fixture ativa, dump ou configuração da bancada no instalador.
- Painel administrativo verificado em 360, 768 e 1440 px. Guardas de capacidade e revisão cobertas pelo teste de política. Ajuda empacotada e integralmente recuperada no Site-Teste pela interface MCP; todos os SHA-256 conferidos.
- Backup privado anterior, instalação via MCP com slug e SHA-256 esperados, Meta ativo e estado final verificado. O ambiente de teste preservou zero conexões e zero agendas. Ações futuras da frota e limite do aceite de fornecedor constam na seção 6 do relatório. Não houve distribuição em repositório público.
