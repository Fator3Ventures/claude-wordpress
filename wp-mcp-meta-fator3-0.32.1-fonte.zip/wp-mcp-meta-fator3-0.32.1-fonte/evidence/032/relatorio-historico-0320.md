# Entrega — Fator3 MCP Meta 0.32.0

20/11/2026 · Revisão 1 · Implementação de **Pedidos MCP Meta 34** · Slug e basename: `wp-mcp-meta-fator3/wp-mcp-meta-fator3.php`. **Apta no escopo testado.**

## 1. De onde esta versão entra

Atualização direta **0.31.0 → 0.32.0**. O guia específico descreveu o Meta 0.30.0; a implementação partiu do fonte entregue da 0.31.0. Nessa base também foi reproduzida a falha: com o aviso de outro plugin ativo, o WordPress o inseria dentro do cabeçalho. A reprodução em WordPress local e a leitura anterior à instalação no Site-Teste foram separadas.

Fonte-base SHA-256 `bbfdc70092ef92963979ff7e38782672283a724f99f9658320729de5f703a4be`; instalador-base `881e1e8839d846479ab684e30fa5a69c7ebb41fb98bc01f9c85c85ceffa4aecf`. Requisitos: WordPress 7.1.4+; PHP 8.3+ de 64 bits. Instalação limpa e atualização em bancada: WP 7.1.4, PHP 8.4.27 e MariaDB 11.8.6. Site-Teste: WP 7.1.5/PHP 8.3.37. Normas centrais: `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, revisão 5 de 02/11/2026. Guia comum, folha 1.0.0, guia específico e pedido de 20/11 foram incorporados como referências no fonte.

## 2. Convivência e encaminhamentos

A combinação de bancada reúne **Core 1.100.1, MCP 0.54.0, Google 0.42.0, LinkedIn 0.27.0 e Pipedrive 0.13.0**. Os cinco ficam ativos junto com o Meta; o transporte descobre 50 operações. O Site-Teste é compartilhado. No inventário inicial, usava Pipedrive 0.12.0; a manutenção do Meta não atualizou o Pipedrive nem outro acompanhante.

| Folha do instalador oficial | Resultado desta rodada |
|---|---|
| Referência anexada e texto na aba “Folha comum” | 11.886 bytes; SHA-256 `15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b` |
| Meta 0.32.0, Core 1.100.1, LinkedIn 0.27.0 e Pipedrive 0.13.0 | Bytes idênticos à referência |
| MCP 0.54.0 e Google 0.42.0 | Esses instaladores ainda não incluem arquivo `f3-ui.css`; não há hash dessa folha para comparar. O Meta não depende do carregamento por outro pacote. |

Foi preservado o contrato de configuração do Core e o transporte do MCP. Não há mudança para o plugin do LinkedIn. A divergência entre a altura móvel da folha comum 1.0.0 e a altura dos campos pedida no guia já foi registrada pelos responsáveis por outros pacotes. O Meta manteve a folha comum intacta e aplicou o token de toque aos seus controles. Nenhuma nova ação em outro pacote foi identificada; não foi emitido relatório de impacto.

## 3. Mudanças e evidência

| Item do Pedido 34 | O que mudou e como conferir |
|---|---|
| 1–2 · Estilos e escopo | A tela conserva a raiz `f3-social` e acrescenta `f3-ui`. O WordPress enfileira primeiro a folha comum e depois a específica, apenas no painel do Meta. O destaque acompanha o esquema de cores do administrador. |
| 3–4 · Cabeçalho e navegação | Nome, descrição do grupo e versão são filhos diretos do cabeçalho. O divisor `hr.wp-header-end` recebe os avisos externos antes da navegação. Configurar, Dados e Suporte mantêm as dez subabas e os URLs de entrada direta. O link ativo informa `aria-current`; os links funcionam sem JavaScript. |
| 5–7 · Cartões, resultados e risco | Os cartões usam `f3-section` e espaçamento comum. O resultado de uma ação pode ser dispensado e é anunciado como estado ou alerta. Opções avançadas e ações de risco usam os componentes comuns; a confirmação antecede a ação destrutiva. |
| 8–9 · Campos e avisos | Rótulos associados aos controles por identificador; instruções próximas do campo e caixas de seleção com alvo de toque. As mensagens em linha distinguem atenção e erro por texto e aparência. |
| 10 · Dados e tabelas | As tabelas rolam no próprio bloco. Listas locais de mais de 20 itens oferecem busca, total e paginação; a seleção permanece ao mudar de página. O fuso do site é usado na apresentação dos instantes. A validade editável da credencial permanece explícita em UTC. |
| 11–12 · Folha específica | A folha do Meta passou de 18.089 para 4.205 bytes; não declara cores literais nem redefine os tokens comuns. Mantém o layout de primeiros passos, busca, dados de diagnóstico e Ajuda. Com JavaScript desligado, o aviso externo permanece no local em que o WordPress o inseriu; uma regra limitada à tela Meta permite quebrar o botão comprido desse aviso sem alargar a página. A comum tem 11.886 bytes e é distribuída no próprio instalador. |

O selo **Conectada** exige conexão habilitada, token salvo, validade vigente ou explicitamente sem expiração e identidade do aplicativo conferida na geração atual. **Pendente** distingue a configuração incompleta, inclusive quando há apenas uma verificação antiga. Trata-se da última evidência local; abrir o painel não testa a Graph.

A comparação do runtime encontrou um arquivo novo, `assets/f3-ui.css`, 15 arquivos alterados e nenhum removido (excluído o próprio manifesto). Os **50 schemas de entrada permaneceram idênticos**. As mudanças executáveis se concentram no painel e na identificação da versão. Agendas, retenção, recuperação do Pedido 33, incidentes, rotas, capacidades e options conservam os contratos anteriores.

**Bancada.** 394 verificações nativas de WordPress e integração, sem falhas; o inventário verificou 80 arquivos em cada instalação candidata. A atualização direta preservou 17 registros de negócio, quatro linhas históricas e três opções, incluindo uma política personalizada de recuperação de 17 dias com revisão 1. Os 13 casos do selo de conexão, os 39 casos de estrutura e interações administrativas (Chromium, REST simulado) e os 22 fluxos de navegação (incluindo teclado, voltar e as dez rotas sem JavaScript) passaram. Em WordPress com dados sintéticos e um segundo plugin ativo, foram aprovadas 360 verificações visuais e cinco verificações adicionais de interação e paleta. A busca encontra inclusive um item que começou na segunda página; números, ações e controles continuam utilizáveis no telefone.

**Site-Teste · conferência por subaba.** A tabela conta, em cada célula, os 12 critérios da seção 7 do guia. Os JSON do fonte guardam os valores medidos: hash e ordem das folhas, cabeçalho, posição do aviso, grupos/subabas, cor ativa, selos, rótulos, tabelas/listas, largura do documento, tamanho dos controles, foco e limites da folha própria. O teste remoto usou o aviso do **PublishPress Authors** na sessão administrativa real e a pré-visualização do esquema Claro. A bancada também alterou o esquema da conta sintética entre Moderno e Padrão. Quando uma tela do Site-Teste não tinha tabelas ou listas longas, a conferência verificou apenas os elementos presentes. A prova de busca e paginação com dados vem da bancada.

| Subaba | 360 px | 768 px | 1440 px |
|---|---:|---:|---:|
| Conexão | 12/12 | 12/12 | 12/12 |
| Ativos | 12/12 | 12/12 | 12/12 |
| Consumidores de anúncios | 12/12 | 12/12 | 12/12 |
| Relatórios | 12/12 | 12/12 | 12/12 |
| Coletas | 12/12 | 12/12 | 12/12 |
| Histórico | 12/12 | 12/12 | 12/12 |
| Conversas | 12/12 | 12/12 | 12/12 |
| Arquivo de Stories | 12/12 | 12/12 | 12/12 |
| Diagnóstico | 12/12 | 12/12 | 12/12 |
| Ajuda | 12/12 | 12/12 | 12/12 |

[Caderno visual: as 30 capturas do Site-Teste e as 30 correspondentes da bancada](wp-mcp-meta-fator3-0.32.0-prova-visual.html). No Site-Teste as larguras são do documento do WordPress dentro de uma moldura de teste; as imagens mostram apenas o painel e o aviso, excluindo a barra de identificação. As capturas locais adicionais do editor e do teste sem JavaScript e os roteiros estão no fonte. Evidências da rodada: `evidence/032/`; as pastas de rodadas anteriores são históricas.

## 4. Instalação e prova da troca

O Site-Teste instalou o ZIP fechado via MCP com `expected_slug=wp-mcp-meta-fator3` e SHA-256 esperado. O recibo confirmou **0.31.0 → 0.32.0**, ativo antes e depois, arquivo aplicado e sondagens bem-sucedidas. A saúde do Meta retornou `ok`, o autoteste aprovou oito verificações e o transporte MCP 0.54.0 informou `healthy=true`. O site seguiu com zero conexões, zero agendas ativas e revisão 0 da política de recuperação; não foi necessário reparar o cron. A instalação compartilhada manteve Core 1.100.1, Google 0.42.0, LinkedIn 0.27.0 e Pipedrive 0.12.0.

Pelo leitor `meta/documentation`, o índice e os 32 documentos da versão instalada foram lidos integralmente em 45 páginas de conteúdo (326.437 bytes). A revisão, o tamanho e o SHA-256 de cada documento coincidiram com os bytes do instalador. O auxiliar administrativo da medição foi retirado depois do ensaio, com ausência confirmada no inventário; ele não integra o plugin. As provas, o comparativo da base e a checagem das operações estão em `evidence/032/site/`, `site-teste.json`, `documentos-site.json` e `diferencas-instaladores.json`.

O arquivo instalável é o ZIP de raiz `wp-mcp-meta-fator3/`. Para distribuição, a frota usa o slug esperado e o hash da seção 8, confere os bytes da URL publicada e instala sem desinstalar a versão vigente. Nenhum arquivo foi publicado no repositório e nenhum site de produção foi alterado nesta rodada.

## 5. Banco, migração e correção por nova versão

A revisão visual dispensa execução de SQL de migração e mantém o armazenamento e a política de retenção. Antes da troca, o Site-Teste teve cópias privadas das duas tabelas Meta (753 registros no total) e de 12 opções. O relatório de evidência inclui somente tamanhos, contagens e hashes. Na atualização de bancada, configuração, permissões, dados históricos e checkpoints da base foram conferidos. Para corrigir código após instalação, entregar nova versão e preservar os dados já gravados.

## 6. O que permanece pendente

O Site-Teste estava sem conexões da Meta. As telas preenchidas, as listas com mais de 20 registros e a preservação de configurações reais de WordPress com valores sintéticos foram verificadas na bancada isolada. Com JavaScript desligado, os links abrem as dez subabas; ações dinâmicas e a realocação de avisos após o divisor dependem do JavaScript do WordPress. Nessa condição o aviso fica na posição original do WordPress e sua quebra de linha foi conferida em 360 px. A prova não implica teste de todo navegador ou versão futura.

O aceite operacional de produção e a reunificação das agendas do Pedido 33 continuam com a frota. A atualização visual não executa essas alterações. O acesso à Graph com credencial comercial e a entrega externa de mensagens não foram exercitados; o Pedido 34 não altera essas integrações.

## 7. Credenciais e configuração do dono

O administrador entra em **Ferramentas → Fator3 MCP Meta** com a capacidade `manage_options`. Para atualização a partir da base não é necessário regravar token, segredo ou ativos. Em nova instalação, **Configurar → Conexão** recebe o nome, App ID, App Secret e token do sistema; em **Ativos** o administrador seleciona as contas autorizadas. As permissões Graph dependem da consulta; veja `CONFIGURATION.md` da versão instalada. A troca visual não requer novas permissões no app da Meta.

## 8. Identidade dos arquivos

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| [wp-mcp-meta-fator3-0.32.0-instalador.zip](wp-mcp-meta-fator3-0.32.0-instalador.zip) | 305086 | `34a39b05650a8d7dee7637ca8316d1004ffc7c7a44996df7d9972cde84d967e3` |
| [wp-mcp-meta-fator3-0.32.0-fonte.zip](wp-mcp-meta-fator3-0.32.0-fonte.zip) | 30929700 | `a3f09eb086485d6767b515f50954a2087851ffbe8727f907a86734daa6240c6e` |
| [wp-mcp-meta-fator3-0.32.0-prova-visual.html](wp-mcp-meta-fator3-0.32.0-prova-visual.html) | 11033334 | `36a7e24726553a699469296c1f600e65cdb2a977165eaebef500bebf1b618513` |

A cópia do relatório incorporada no fonte precede o fechamento desse ZIP.
