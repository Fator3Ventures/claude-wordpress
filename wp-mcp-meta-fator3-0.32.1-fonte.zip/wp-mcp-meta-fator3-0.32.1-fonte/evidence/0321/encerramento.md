# Conferência da entrega 0.32.1 — 20/11/2026

- Revisão 5 dos dois documentos centrais, padrão específico, normas comuns e guias do painel aplicados. Pedidos 34 e 35 preservados em seus escopos.
- Candidata deriva da 0.32.0. Foram verificadas instalação limpa e atualizações diretas das versões 0.31.0 e 0.32.0; os recibos preservam os hashes, a evidência de dados e o relógio utilizado.
- Escopo operacional: instalação restrita ao Site-Teste, pré e pós-sondagens, documentação lida pelo MCP real, sem tokens nem dumps no ZIP. Antes de fechar o fonte foram conferidos a presença do aviso real de terceiros e os 12 critérios por aba e tamanho. A coleta remota na Graph e o SMTP externo não foram exercitados.
- Impacto solicitado só para o Core: a fila oficial ainda notifica a recuperação de um falso episódio já avisado. O diff validado, os negativos e o roteiro de aplicação estão isolados em integration/035-core, nunca no instalador Meta. Sem encaminhamento para LinkedIn ou outro pacote.
- Provas de produção pré-implantação separadas de relógio controlado de laboratório e do aceite futuro pela frota; sem escrever em outro site ou publicar em repositório.
- Conferência final dos manifestos e de todas as entradas dos ZIPs; cópia do runtime no fonte idêntica ao instalador; relatório externo com os hashes finais.
