<?php
/** Exercise the official Core public transaction with simulated option store/transport.
 * No WordPress installation, DB, current user session or SMTP used by this script. */
declare(strict_types=1);
namespace Fator3\Meta {final class Worker {public static array $report=[];public static function health(bool $op=false):array{return self::$report;}}}
namespace {
if(PHP_SAPI!=='cli'||empty($argv[1]))throw new RuntimeException('Pass the isolated patched plugin directory.');
define('ABSPATH',__DIR__.'/');const MINUTE_IN_SECONDS=60,HOUR_IN_SECONDS=3600;
function get_option($k,$default=[]){return $GLOBALS['options'][$k]??$default;}
function update_option($k,$v,$a=false){$before=get_option($k,null);$GLOBALS['options'][$k]=$v;return $before!==$v;}
function wp_cache_delete(...$x){}function wp_salt($x){return 'synthetic-local-fixture';}
function wp_generate_uuid4(){return '019df511-6572-486c-9c46-d38c9d46ebc7';}
function get_current_user_id(){return 1;}
function current_user_can($x){return $x==='manage_options';}
function home_url(){return 'https://example.invalid/';}
function wp_parse_url($x,$p){return parse_url($x,$p);}function wp_date($f,$x){return gmdate($f,$x);}
function admin_url($x){return home_url().$x;}
final class F3Base_Pipedrive_Fila {
    public static bool $busy=false;
    public static function travar_linha($k){return !self::$busy;}public static function liberar_linha($k){}
}
final class F3Base_Alertas_Operacionais {
    public static array $mail=[];public static bool $incierto=false;
    public static function carencia_minutos($k){return 0;}public static function janela_agrupamento_horas(){return 0;}
    public static function destinatario(){return 'lab@example.invalid';}
    public static function enviar($t,$body){self::$mail[]=$t;return self::$incierto?['ok'=>false,'estado'=>'incerto','codigo'=>'incerto']:['ok'=>true,'codigo'=>'aceito_wp_mail'];}
}
require $argv[1].'/includes/class-f3base-incidentes-provedores.php';require $argv[1].'/includes/class-f3base-incidentes.php';
$t=time()-4*86400;$checks=[];$check=static function($n,$b)use(&$checks){if(!$b)throw new RuntimeException($n);$checks[]=$n;};
$fixture=static function($sid)use($t){$h=&\Fator3\Meta\Worker::$report;$h=['schedules'=>[['schedule_id'=>$sid,'connection_id'=>'test',
    'enabled'=>true,'last_run_status'=>'nao_aplicavel','last_code'=>'fields_unavailable','last_error_state'=>'expected',
    'last_error_superseded'=>false,'collection_failure_since'=>null,'collection_success_at'=>$t,'last_error_at'=>$t,'last_error'=>['code'=>'empty_or_suppressed'],
    'availability_assessment'=>['kind'=>'nao_aplicavel','reason'=>'audience_data_unavailable','metrics'=>['follower_demographics'],'account_id'=>'42','observed_at'=>$t]]],'issues'=>[]];
    F3Base_Alertas_Operacionais::$mail=[];F3Base_Alertas_Operacionais::$incierto=false;
    $ref=hash('sha256','schedule_overdue|'.$sid);$id=hash('sha256','meta|agenda_parada|'.hash_hmac('sha256',$ref,wp_salt('auth')));
    $key='f3base_incidente_v1_'.$id;
    $event=static fn($s,$a=null)=>F3Base_Incidentes::publicar(['pacote'=>'meta','codigo'=>'agenda_parada','recurso'=>$ref,'estado'=>$s,'desde'=>$a??$t]);
    return [$id,$key,$event];
};
foreach(['aceito','nao_enviado'] as $result){
 [$id,$key,$event]=$fixture('reserved-'.$result);
 F3Base_Alertas_Operacionais::$incierto=true;$open=$event('aberto');$check('Opening reserved: '.$result,$open['estado']==='incerto');
 $slot=get_option($key)['fila'][0];$close=$event('recuperado');$r=get_option($key);
 $check('Recovery leaves uncertain transport for reconciliation: '.$result,$close['ok']&&$r['estado']==='recuperado'&&count($r['fila'])===1&&$r['fila'][0]['reserva']===$slot['reserva']&&$r['fila'][0]['dispensar_retentativa']&&$r['fila'][0]['encerramento_silencioso']&&$r['encerramento_meta_reclassificado']['episodio']===1);
 $check('Repetition preserves original reserve: '.$result,$event('recuperado')['ok']&&get_option($key)['fila']===$r['fila']);
 $reconciled=F3Base_Incidentes::reconciliar(['id'=>$id,'reserva'=>$slot['reserva'],'resultado'=>$result]);
 $check('Reconciliation never queues technical recovery: '.$result,$reconciled['ok']&&get_option($key)['fila']===[]&&count(F3Base_Alertas_Operacionais::$mail)===1);
}
[$id,$key,$ev]=$fixture('in-flight');$ev('aberto');
F3Base_Pipedrive_Fila::$busy=true;$check('Competing write returns failure without mutating state',!$ev('recuperado')['ok']&&get_option($key)['estado']==='aberto');F3Base_Pipedrive_Fila::$busy=false;
$check('Retry closes once without follow-up mail',$ev('recuperado')['ok']&&get_option($key)['fila']===[]&&count(F3Base_Alertas_Operacionais::$mail)===1);
$check('Delayed pilot opening cannot reopen classified episode',$ev('aberto')['estado']==='observacao_superada'&&get_option($key)['episodio']===1);
\Fator3\Meta\Worker::$report['issues'][]=['code'=>'schedule_collection_unresolved','schedule_id'=>'in-flight','connection_id'=>'test'];
$check('A real later disruption can reopen the same resource',$ev('aberto')['ok']&&get_option($key)['episodio']===2&&count(F3Base_Alertas_Operacionais::$mail)===2);
$check('Stale recovery cannot close a current disruption',$ev('recuperado')['estado']==='observacao_superada'&&get_option($key)['estado']==='aberto');
\Fator3\Meta\Worker::$report['issues']=[];$check('Previous receipt cannot silence a second genuine episode',$ev('recuperado')['ok']&&count(F3Base_Alertas_Operacionais::$mail)===3&&F3Base_Alertas_Operacionais::$mail[2]==='Recuperação técnica · meta · agenda_parada');
foreach(['future_receipt','different_clock','different_resource','no_proof','future_source','unknown_metric','different_cause','disabled'] as $case){
 [$id,$key,$ev]=$fixture($case);$ev('aberto');$s=&\Fator3\Meta\Worker::$report['schedules'][0];
 switch($case){
 case 'future_receipt': $s['last_error_at']=$s['collection_success_at']=time();break;
 case 'different_clock': $s['last_error_at']=$s['collection_success_at']=$t+2;break;
 case 'different_resource': $s['schedule_id']='other';break;
 case 'no_proof': $s['availability_assessment']=null;break;
 case 'future_source': $s['availability_assessment']['observed_at']=time()+1;break;
 case 'unknown_metric': $s['availability_assessment']['metrics']=['reach'];break;
 case 'different_cause': $r=get_option($key);$r['codigo_carencia']='credencial_recusada';update_option($key,$r);break;
 case 'disabled': $s['enabled']=false;break;
 }
 unset($s);$ev('recuperado');$check('No silent inference when '.$case,count(F3Base_Alertas_Operacionais::$mail)===2&&empty(get_option($key)['encerramento_meta_reclassificado']));
}
echo json_encode(['total'=>count($checks),'checks'=>$checks,'failed'=>0],JSON_UNESCAPED_UNICODE)."\n";
}
