<?php
/** Standalone addendum using the native guarded two-phase WP suite; see prova-fila.md.
 * Graph and the Meta clock are fixtures. WordPress, wp_mail receipts, Core and both cron observers are real. */
use Fator3\Meta as M;
const CROSS035_BASELINE='0.31.0';
const CROSS035_OTHER='pendencia-nao-relacionada-035';
const CROSS035_MESSAGE='Controle independente da fila 035';
if(!in_array($argv[1]??'', ['baseline','candidate'],true)||($argv[2]??'')!==CROSS035_BASELINE)throw new RuntimeException('Use baseline|candidate 0.31.0');
ob_start();
try{require __DIR__.'/../../tests/native/incidents035.php';$shared=json_decode(ob_get_clean(),true,512,JSON_THROW_ON_ERROR);}
catch(Throwable $e){if(ob_get_level())ob_end_clean();throw $e;}
$reference=$root.'/evidence/035-outbox-cross.json';
$plus=[];
function checkCross035(string $name,bool $ok): void {global $plus;if(!$ok)throw new RuntimeException($name);$plus[]=$name;}
function allCross035(): array {
 $r=wp_get_ability('f3base/email-wordpress-fila-ler')->execute(['pagina'=>1]);checkCross035('Complete durable email queue',!empty($r['ok'])&&count($r['linhas'])<50);
 $rows=[];foreach($r['linhas'] as $row)$rows[$row['id']]=['subject'=>$row['diagnostico']['assunto']??null,'estado'=>$row['estado'],'codigo'=>$row['codigo'],'fase'=>$row['fase'],'created'=>$row['criado_em']];
 ksort($rows);return $rows;
}
function controlCross035(): array {
 $r=list35()[ref35(CROSS035_OTHER)]??[];return array_intersect_key($r,array_flip(['id','episodio','estado','entregas_pendentes','proxima_entrega','observado_em','recurso_ref']));
}
if($phase==='baseline'){
 checkCross035('Exactly four historical audience opening receipts',$shared['proof']['original_openings']===4&&count(queue35())===4);
 checkCross035('Unrelated mail durably accepted',wp_mail('incidentes@example.invalid',CROSS035_MESSAGE,'Mensagem de controle no laboratório.'));
 $policy=F3Base_Options::ler('f3base_avisos_tecnicos');$restore=$policy;$policy['carencia_por_codigo_minutos']['agenda_parada']=10080;
 F3Base_Options::gravar('f3base_avisos_tecnicos',$policy);
 $r=F3Base_Incidentes::publicar(['pacote'=>'meta','codigo'=>'agenda_parada','recurso'=>CROSS035_OTHER,'estado'=>'aberto','desde'=>time()]);
 $control=controlCross035();
 checkCross035('Same-code unrelated incident is open with pending delivery',!empty($r['ok'])&&$control['estado']==='aberto'&&$control['entregas_pendentes']===1);
 // Grace is only for seeding this independent, pending event. Neither package's notifier
 // owns its resource, so observing the four others must leave it pending.
 F3Base_Options::gravar('f3base_avisos_tecnicos',$restore);
 $baselineRows=allCross035();checkCross035('Unrelated message retained by quota',count(array_filter($baselineRows,static fn($r)=>$r['subject']===CROSS035_MESSAGE&&$r['codigo']==='retido_pela_cota'))===1);
 file_put_contents($reference,wp_json_encode(['rows'=>$baselineRows,'control'=>$control]));
 $result=['historical_openings'=>4,'other_mail'=>1,'pending_same_code_incident'=>1];
}else{
 $saved=json_decode(file_get_contents($reference),true,512,JSON_THROW_ON_ERROR);
 $c=$shared['proof'];
 checkCross035('All historical episodes close; +26h creates zero audience openings AND zero recovery mail',$c['weekly_resolved']===4&&$c['new_weekly_openings']===0&&$c['weekly_recovery_receipts']===0&&$c['elapsed_seconds']>=26*3600);
 $all=allCross035();checkCross035('Historical receipts and other queued mail unchanged',array_intersect_key($all,$saved['rows'])===$saved['rows']);
 checkCross035('Unrelated pending agenda_parada unchanged',controlCross035()===$saved['control']);
 $new=array_diff_key($all,$saved['rows']);checkCross035('Only one additional receipt is the true daily opening',count($new)===1&&reset($new)['subject']==='Incidente técnico · meta · agenda_parada');
 // A useful provider response on the next daily pass must flow through the ordinary notification path.
 add_filter('pre_http_request',static function($r,$args,$url)use($acc){
  $path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$p);
  if($path==='/v24.0/'.$acc.'/insights'&&($p['metric']??null)==='reach')return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode(['data'=>[['name'=>'reach','total_value'=>['value'=>12]]]])];
  return $r;
 },2,3);
 $j=run35($daily);checkCross035('The daily control genuinely collects a useful row',$j['outcome']==='complete'&&$j['successful_rows']===1);
 observe35();observe35();$core=list35();$r=$core[scheduleRef35($daily)]??[];
 checkCross035('Genuine daily episode recovered once',($r['estado']??'')==='recuperado'&&$r['episodio']===1);
 $all=allCross035();$new=array_diff_key($all,$saved['rows']);$subjects=array_count_values(array_column($new,'subject'));ksort($subjects);
 checkCross035('Exactly the normal two emails for true daily incident',count($new)===2&&($subjects['Incidente técnico · meta · agenda_parada']??0)===1&&($subjects['Recuperação técnica · meta · agenda_parada']??0)===1);
 checkCross035('All prior receipts still present and unchanged',array_intersect_key($all,$saved['rows'])===$saved['rows']);
 checkCross035('Unrelated delivery still pending after normal recovery',controlCross035()===$saved['control']);
 foreach($weekly as $id){$r=$core[scheduleRef35($id)]??[];$m=$r['encerramento_meta_reclassificado']??[];
  checkCross035("$id retains silent recovery audit",($r['estado']??null)==='recuperado'&&$r['episodio']===1&&($m['episodio']??null)===1&&(int)($m['prova_em']??0)>0);}
 // Boundary: a different weekly audience schedule suffered a real upstream rejection. A later
 // successful request with followers below the threshold is normal recovery, not historical correction.
 $ac2='35036';$c2='lab-035-origem';$w2='ig-publico-controle-real-035';$reject=true;
 $GLOBALS['f3qa035_clock_shift']=-8*86400;
 lab_seed_connection090(['connection_id'=>$c2,'expected_revision'=>0,'token'=>'private-lab-control','assets'=>['instagram'=>[$ac2]],'users'=>[1]]);
 add_filter('pre_http_request',static function($r,$args,$url)use($ac2,&$reject){
  $p=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);
  $resp=static fn(array $body,int $code=200)=>['response'=>['code'=>$code],'headers'=>[],'body'=>wp_json_encode($body)];
  if($p==='/v24.0/'.$ac2.'/insights'&&($q['metric']??null)==='follower_demographics')
   return $reject?$resp(['error'=>['code'=>100,'message'=>'Invalid metric for this account']],400):$resp(['data'=>[]]);
  if($p==='/v24.0/'.$ac2&&($q['fields']??null)==='id,followers_count')return $resp(['id'=>$ac2,'followers_count'=>8]);
  return $r;
 },2,3);
 new35($w2,['connection_id'=>$c2,'channel'=>'instagram','account_id'=>$ac2,'report'=>'audience','fields'=>['follower_demographics'],'breakdown'=>'city'],10080);
 $w=run35($w2);checkCross035('Weekly audience control genuinely rejected eight days earlier',$w['outcome']==='failed'&&empty(read35($w2)['availability_assessment']));
 $GLOBALS['f3qa035_clock_shift']=0;observe35();$before=list35()[scheduleRef35($w2)]??[];
 checkCross035('Real weekly rejection opens and is not treated as a historical correction',($before['estado']??'')==='aberto'&&$before['episodio']===1&&empty($before['encerramento_meta_reclassificado']));
 $q1=allCross035();$wd=array_diff_key($q1,$all);checkCross035('Real weekly failure emits usual opening receipt',count($wd)===1&&reset($wd)['subject']==='Incidente técnico · meta · agenda_parada');
 // Run after the actual opening, not at its synthetic older time. Preserve the order down to seconds.
 $GLOBALS['f3qa035_clock_shift']=15;$reject=false;$w=run35($w2);
 checkCross035('Fresh origin proof after a genuine weekly incident',$w['outcome']==='nao_aplicavel'&&$w['availability_assessment']['followers_count']===8);
 observe35();observe35();$after=list35()[scheduleRef35($w2)]??[];$q2=allCross035();$wr=array_diff_key($q2,$q1);
 checkCross035('New evidence resolves normally and sends one unstifled recovery',($after['estado']??null)==='recuperado'&&empty($after['encerramento_meta_reclassificado'])&&count($wr)===1&&reset($wr)['subject']==='Recuperação técnica · meta · agenda_parada');
 checkCross035('Original and unrelated queue entries untouched after both real episodes',array_intersect_key($q2,$saved['rows'])===$saved['rows']&&controlCross035()===$saved['control']);
 $result=['historical_openings_preserved'=>4,'elapsed_seconds'=>$c['elapsed_seconds'],'weekly_closed'=>4,'new_weekly_openings'=>0,'new_weekly_recoveries'=>0,'genuine_daily_openings'=>1,'genuine_daily_recoveries'=>1,'genuine_weekly_rejection_openings'=>1,'subsequent_no_data_recoveries'=>1,'other_mail_unchanged'=>1,'pending_same_code_incident_unchanged'=>1];
}
echo wp_json_encode(['phase'=>$phase,'wordpress'=>$shared['wordpress'],'php'=>$shared['php'],'meta'=>$shared['meta'],'core'=>$shared['core'],'shared_checks'=>$shared['assertions'],'cross_checks'=>count($plus),'proof'=>$result,'passed'=>true])."\n";
