# Proposta para o Site Core — Pedido Meta 35

**Destinatário:** manutenção do Fator3 Site Core. **Base:** 1.100.1 oficial. A proposta está em `core-1.100.1-035.patch`. Não constitui release do Core e não integra o instalador do Meta. O Meta 0.32.1 final funciona sem essa proposta. O objetivo adicional é evitar que uma correção de classificação crie e-mails de **recuperação** para falsos episódios históricos já avisados.

**Efeito observado com o Core oficial.** Na troca do Meta, quatro episódios antigos de público fecharam sem abertura nova. A fila do Core preservou as quatro aberturas anteriores e recebeu quatro recuperações. Isso segue a regra ordinária do Core para episódios cuja abertura já fora aceita. Não há motivo de encerramento no evento padrão do produtor que autorize suprimir essas mensagens.

**Mudança solicitada ao Core.** O produtor Meta e o observador periódico chegam ao método comum `F3Base_Incidentes::publicar`. Confirmar ali, sob a trava do episódio, se o diagnóstico local de `Fator3\Meta\Worker::health(true)` demonstra aquela reclassificação histórica. A leitura é local, não executa agenda, não toca na Graph e não exige nova versão ou nova permissão no Meta. As duas classes alteradas constam de `identidade.json`; todos os demais arquivos dos dois pacotes ficam intactos.

A exceção somente se aplica quando todas estas condições coincidem:

1. O evento é recuperação, o pacote é `meta`, o código e o qualificador do episódio são `agenda_parada` e o recurso é exatamente o SHA-256 de `schedule_overdue|<identificador da agenda>` calculado para uma agenda habilitada da projeção local.
2. A última execução ficou `nao_aplicavel`, com `fields_unavailable`, erro esperado não superado e avaliação atribuída a uma conta de público: conjunto explícito de métricas demográficas indisponíveis ou contagem medida abaixo do mínimo. Não há falha de agenda ou autorização da conexão ativa na leitura. Nenhuma decisão depende do rótulo ou prefixo `ig-publico-`.
3. A abertura do episódio apontava a **mesma ocorrência histórica**: `desde` da abertura = `last_error_at` = `collection_success_at` (esta última marca a execução resolvida, ainda que não haja dado). Tanto o horário da evidência quanto o do erro são anteriores, em segundos inteiros, à primeira observação do episódio pelo Core. Uma nova resposta de indisponibilidade posterior a uma interrupção real não satisfaz o critério. A mesma prova não pode silenciar um segundo episódio.

O registro conserva recibos anteriores e ganha `encerramento_meta_reclassificado: {episodio, prova_em}`. A configuração, tabelas, rotas, slug e agenda não mudam. São dispensados somente avisos ainda não reservados de abertura ou recuperação **daquele episódio** dentro da fila do incidente. Reservas já feitas ficam disponíveis para a reconciliação normal (`aceito` / `nao_enviado`), sem nova tentativa automática nem aviso complementar. Um processamento concorrente sem a trava é elegível a repetição. Uma abertura antiga repetida não ressuscita o episódio; um novo atraso observado volta a abrir normalmente. Nenhum e-mail já aceito pela fila WordPress é apagado, cancelado ou reenviado. Um SMTP externo não participou da prova.

**Limite do contrato existente.** O evento recuperado não contém geração de agenda, prova nominal de migração ou vínculo explícito do produtor ao episódio Core; a visão de saúde é o último estado. Se o horário não coincidir, a fonte não for verificável, a evidência for posterior ou do mesmo segundo da abertura, a falha original for de outra causa, ou o recurso não puder ser identificado, o caminho normal envia a recuperação conforme sua política. O patch não tenta inferir que todas as recuperações de uma agenda de público são correções. Para silenciar também casos sem essa correspondência seria necessário um recibo explícito, durável e idempotente do produtor, com identidade do recurso, geração da seleção e identidade temporal da ocorrência a que a reclassificação se refere, verificável pelo receptor; não ampliar por aproximação de horários ou prefixo do nome.

**Ordem e volta.** Se o Core homologar e publicar a proposta, instalar primeiro sua versão oficial receptora e em seguida o Meta 0.32.1. O Core constata a evidência já confirmada no instante em que recebe ou observa a recuperação. Se o Core oficial anterior já aceitou alguma recuperação, trocar arquivos depois não a retira da caixa. A volta ao Core anterior preserva históricos e reservas; ele não reconhece o marcador específico e volta à sua política normal para episódios futuros.

## Reproduzir

1. Na raiz de um diretório descartável, verificar os dois hashes oficiais em `identidade.json`, extrair o instalador oficial do Core 1.100.1, conferir as duas classes com o fonte oficial e aplicar:
   ```sh
   patch -p1 --fuzz=0 --dry-run < /caminho/core-1.100.1-035.patch
   patch -p1 --fuzz=0 < /caminho/core-1.100.1-035.patch
   php /caminho/prova-reservas.php ./base-site-core-fator3
   ```
   Os dois arquivos resultantes devem bater com seus hashes `proposta_sha256`. Não transportar esse diretório para um site de frota.
2. Seguir `prova-fila.md` para a prova ponta a ponta com WordPress, ambos os instaladores oficiais do Meta, Core e caixa consultada pela ability `f3base/email-wordpress-fila-ler`. `prova-reservas.php` é complementar: testa o receptor real com armazenamento e transporte simulados para produzir estados incertos e ordens de eventos com reprodutibilidade; o JSON tem 22 verificações. O resultado end-to-end tem evidências separadas.
