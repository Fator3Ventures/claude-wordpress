# Coletas, worker e alertas

Este guia descreve a fila de coletas, o worker, a manutenção horária, a diferença entre `meta/health` e `meta/status`, os códigos de `issues` e os avisos por e-mail. O resumo operacional está em OPERATIONS.md.

## Fila e worker

Cada coleta é um registro cifrado na tabela do plugin. Uma projeção técnica sem dados de negócio (`queue_state`, `queue_next` e o índice `runnable`) permite escolher as coletas a executar sem decifrar as concluídas. O registro e a projeção são gravados juntos, com conferência de revisão.

Em cada passagem, o worker:

1. Materializa as agendas vencidas em coletas.
2. Seleciona até 20 coletas `queued` ou `retry` já vencidas, por duas buscas indexadas, com prioridade para as últimas coletas de agendas ativas (EXECUTION-BUDGET.md).
3. Revalida estado, prazo e autorização de cada coleta sob a trava dela e executa uma página.
4. Pré-agenda a passagem seguinte e confere de novo o evento ao sair, mesmo após exceção.

Registros de coleta ainda sem projeção (de instalações antigas) são migrados em lotes de 100 por passagem, sem alterar conteúdo cifrado, revisão ou prazo; enquanto isso, o worker continua necessário. Depois de confirmada a migração, a opção `f3_meta_queue_settled` e as marcas de schema ficam no autoload, e uma requisição comum não executa consulta SQL própria do plugin.

Travas de banco impedem duas passagens concorrentes e dois reagendamentos simultâneos. Uma tentativa automática conserva o ID, as páginas já gravadas e o recorte de datas da coleta. A manutenção distingue pausa manual, causa permanente comprovada e esgotamento das tentativas. Coletas concluídas ou canceladas e pausas manuais permanecem como estão.

## Manutenção horária

O evento `f3_meta_maintenance` roda a cada hora e:

1. Confere e, se preciso, recria o evento do worker.
2. Avança a migração da fila e a migração do histórico (lotes de 25 páginas de resultado).
3. Aplica a retenção apenas a registros com prazo vencido (RETENTION.md).
4. Reavalia as pausas automáticas com evidência de recuperação, confere o worker e publica no Site Core as transições de incidente pertinentes.

Se a manutenção sumir do cron, a primeira requisição seguinte do site a reagenda para cinco minutos depois, sob trava. Enquanto falta, `meta/health` mostra `maintenance_missing`.

## Health e status

| | `meta/health` | `meta/status` |
|---|---|---|
| Modo | Leitura | Escrita local |
| Rearma o worker | Não (`repair=not_attempted`) | Sim, se faltar o evento e houver agenda ativa, coleta pendente ou migração pendente |
| Envia e-mail | Não | Não |
| Consulta a Meta | Não | Não |
| Perfil MCP | Leitura basta | Exige perfil que autorize escrita |

As duas devolvem o mesmo diagnóstico: `state` (`ok` ou `degraded`), `observed_at`, `issues[]`, `active_schedules`, `partial_schedules`, `failed_schedules`, `worker_required`, `cron`, `queue`, `execution_budget_policy`, `budgets[]`, `schedules[]` (até 100 agendas) e `notification`. Em `recovery_jobs.jobs`, consulte `attempts`, `max_attempts`, `next_retry_at` e `pause_reason`. O resumo exibe até 50 coletas; com `truncated=true`, `total` é nulo e `at_least` indica um mínimo. Use `meta/list-jobs` para paginar a fila. `meta/health` acrescenta `maintenance`, `messaging` e `datasets` (MONITORING.md). `meta/status` acrescenta `recovery` (`attempted`, `scheduled`, `code`) e `cron.observed_next`, que mostra o evento antes da tentativa; `cron.next` mostra o evento depois.

Quando o WordPress recusa o agendamento, `recovery.scheduled=false` e `recovery.code` informa o código dessa tentativa. Com agendamento confirmado, o código é `ok`. Sem tentativa, ambos são `null`. Na manutenção horária, `maintenance.last.recovery` indica se, ao concluir a manutenção, havia evento para o trabalho pendente ou a fila dispensava agendamento.

O estado é observado antes da recuperação. Uma consulta seguinte pode mostrar `ok`. `audit_health` trata só da auditoria e não substitui `state`.

`queue.oldest_due_lag_seconds` é o atraso da coleta vencida mais antiga, ou zero; `queue.oldest_due_at` é `null` sem coletas vencidas. Durante a migração da fila, `queue.migration_pending=true` indica que o atraso cobre só os registros já migrados.

## Códigos de `issues`

| Código | Significado | Ação | Incidente no Core |
|---|---|---|---|
| `worker_missing` | Há trabalho e o evento do worker não está no cron | `meta/status` ou **Verificar e recuperar agendamento**; conferir o cron do servidor | Sim |
| `schedule_overdue` | Agenda ativa com `next_at` vencido há mais de duas vezes o intervalo | Conferir o cron e a autorização da agenda | Na janela da agenda, descrita abaixo |
| `schedule_authorization_failed` | Falta administrador, conexão ativa ou credencial válida | Conferir a causa no último erro e restabelecer o acesso local ou da Meta | Na janela da agenda, descrita abaixo |
| `connection_authorization_failed` | A Meta recusou a credencial também em `/me` (uma issue por conexão) | Renovar o token ou restaurar as permissões do aplicativo; não precisa recriar agendas | Na janela da agenda, se houver uma ativa; independente para conexão sem agenda ativa |
| `schedule_resource_access_failed` | A Meta recusou o recurso da consulta, sem revogação comprovada da conexão | Conferir a seleção e as permissões do relatório | Na janela da agenda, descrita abaixo |
| `schedule_budget_exhausted` | Agenda bloqueada pelo orçamento local há mais de 24 horas | EXECUTION-BUDGET.md | Na janela da agenda, descrita abaixo |
| `schedule_collection_unresolved` | Agenda habilitada com falha comprovada ou despacho sem resolução além da janela da agenda | Consultar tentativas e conferir o próximo cron | Sim; a primeira recuperação fecha o incidente |
| `schedule_failed` | Coleta falhou sem diagnóstico mais específico | Conferir o código e a próxima execução | Não |
| `schedule_partial` | A última execução terminou parcial, com dados úteis preservados e lacunas inesperadas | Conferir as métricas indisponíveis | Não |
| `schedule_job_unreadable` | A última coleta da agenda está ilegível | Conferir os salts; os dados foram preservados | Não |
| `queue_record_unreadable` | Há coletas que a chave atual não abre (`count`) | Conferir os salts do `wp-config.php` | Não |
| `queue_migration_pending` | A migração da fila ainda não terminou | Aguardar as passagens do worker | Não |
| `maintenance_missing` / `maintenance_failed` | Manutenção ausente ou com erro | Conferir o cron e o armazenamento | Sim |
| `dataset_optimized_event_zero` | Evento otimizado com zero confirmado (só em `meta/health`) | MONITORING.md | Não |

Recusas isoladas de Story têm código próprio e não geram issue de autorização (COLLECTION-DIAGNOSTICS.md).

## Tentativas e recuperação do dia

1. **Confira o que falhou.** Um detalhamento ilegível já identificado tem código `breakdown_unreadable`. Os demais campos da página são preservados. Uma página inválida sem métrica identificável, um erro de rede, um HTTP 5xx ou uma falha transitória indicada pelo fornecedor voltam ao worker como `retry`. O diagnóstico da coleta informa as tentativas e o próximo horário elegível; não é preciso criar outra coleta para o mesmo dia.
2. **Respeite a espera.** O padrão do site é 5, 10, 20, 40 e 60 minutos e, depois, 360 minutos. Quando a mesma falha de leitura se repete até o limite, o worker tenta separar as métricas quando a consulta permite. O que faltar continua explícito. Uma recusa comprovada ou o esgotamento registra `pause_reason=permanent` ou `attempts_exhausted`; o comando de pausa registra `manual`. A política fica fixa durante as tentativas da mesma página. O cron precisa executar para que uma tentativa elegível comece.
3. **Confira a evidência de recuperação.** A manutenção horária pode retomar a coleta esgotada depois de outra coleta bem-sucedida da mesma conexão e relatório. Para recusas permanentes, a credencial ou as condições de autorização precisam ter mudado, ou uma nova coleta precisa evidenciar que a recusa cessou. Pausas deliberadas e cancelamentos não são retomados automaticamente. A nova tentativa revalida a autorização. Uma recusa remota também pode ser conferida de novo após a espera periódica; reentrar na fila não comprova a restauração do acesso. A manutenção percorre as pausas em lotes de 50.
4. **Confira o histórico do dia original.** Uma agenda diária com um dia sem sucesso pode recompor esse dia na passagem seguinte, mesmo com `lookback_days=1`. A janela de reposição pode chegar a 30 dias. A reposição aplica-se a relatórios que aceitam janela por dia, como insights da conta ou página, anúncios e qualidade de datasets. Snapshots de perfil, público e Stories não permitem reconstruir retrospectivamente o estado observado. A recomposição usa as mesmas chaves do histórico, e o dia normal continua a ser coletado. Veja em COLLECTION-DIAGNOSTICS.md a diferença entre um parcial com valores e uma coleta sem dados úteis.
5. **Para alterar o comportamento**, consulte `meta/get-recovery-policy`, simule com `meta/simulate-recovery-policy` e confirme a alteração com `meta/save-recovery-policy`, usando a revisão e a confirmação da prévia. O escopo da política é o site. Uma simulação não altera a fila nem consulta a Meta.

## Registros ilegíveis

Uma coleta cujo conteúdo cifrado a chave atual não abre recebe `queue_state=unreadable`. O plugin não reescreve conteúdo, revisão, datas ou prazo; o registro sai da seleção do worker e da retenção e não é apagado. A decisão usa o mesmo conteúdo lido sob trava e conferido na gravação, para não confundir uma falha transitória de banco com corrupção.

Registros isolados não voltam sozinhos à fila. Restaure os salts corretos e avalie a reparação com o administrador. Não apague registros para destravar a fila.

## Avisos por e-mail

O worker e a manutenção publicam abertura e recuperação no contrato local do Site Core, `f3base_incidente_publicar_v1`. Para uma agenda, o diagnóstico aparece assim que a falha é conhecida. A janela de `agenda_parada` depende da cadência e do que foi observado:

- **Sem execução resolvida nem falha comprovada:** são dois intervalos completos mais duas horas de folga: 50 horas para uma diária; 14 dias e duas horas para uma semanal.
- **Falha operacional registrada:** a tentativa que falhou já ocupa o primeiro horário previsto. Conta-se um intervalo mais duas horas desde a primeira falha persistente: 26 horas para uma diária e sete dias e duas horas para uma semanal. Uma nova tentativa com erro não reinicia a contagem.
- **Público indisponível na origem:** a passagem fica resolvida sem dados. A agenda permanece habilitada para consultar no próximo horário; não se registra sucesso com linhas úteis.

As duas vias usam a mesma identidade de incidente no Core. Uma coleta com dados úteis, zero legítimo ou resultado comprovadamente não aplicável restabelece a disponibilidade. Falhas de infraestrutura, como cron ausente, têm aviso independente. Configure o e-mail técnico no Core. O Meta guarda transições pendentes se o Core estiver ausente ou ocupado. Não envia ao Slack. O Core deduplica eventos, conserva a entrega pendente quando falta destinatário e expõe o recibo em `f3base/incidentes-tecnicos-ler`. Aceite do contrato não prova entrega à caixa postal.

## Autorização das agendas

A coleta pertence ao site. O worker revalida a conexão, o ativo selecionado e um administrador WordPress com manage_options. Se quem salvou perder a capacidade, outro administrador assume e o Core recebe um aviso. A concessão MCP de origem é informação de auditoria. A revisão pública protege somente a edição. Tentativas, erros e recuperações permanecem no diagnóstico.

Uma revogação confirmada da conexão é agregada em `connection_authorization_failed` e marca todas as agendas da conexão, inclusive as pausadas, sem alterar seleção, principal ou estado. O alerta só some quando uma execução seguinte comprova a retomada.

## Limites

O WP-Cron é uma lista global: código de outro plugin que grave o cron ao mesmo tempo pode apagar um evento depois da conferência. A manutenção horária reduz a falha persistente, mas não garante atomicidade do WordPress. Se todo o cron estiver parado, nenhuma recuperação automática acontece: configure o agendador do servidor.

## Comprovação da agenda e da execução

O evento avulso é `f3_meta_worker`, sem argumentos. Um worker já presente é reaproveitado. Ao criar um novo, o pacote fixa o horário antes de chamar o WordPress. Se o retorno for `could_not_set`, a tentativa só é confirmada se a mesma ocorrência avulsa existir naquele instante. Um evento em outro horário, com outros argumentos ou recorrente não confirma esta gravação. Um veto com outro código permanece falha.

No recibo `cron.last_schedule_attempt`, `requested_at` é o timestamp solicitado, `native_code` é o código devolvido pela API quando houver e `exact_event` indica se a releitura comprovou a ocorrência exata. Um evento equivalente reaproveitado após uma disputa de duplicidade conserva a semântica anterior. O WP Activity Log continua observando a criação e a remoção. A correção preserva o retorno anterior da cadeia do WordPress somente na chamada do worker do Meta.

Para comprovar execução, confira separadamente `cron.last` e o estado, as páginas e a revisão da coleta. `processed` conta tentativas; uma coleta com erro não é sucesso comercial. A falta do evento após a remoção também não comprova execução. Se houver trabalho pendente sem próximo evento, use Suporte → Diagnóstico → Verificar e recuperar agendamento. Releia a saúde e o checkpoint antes de repetir a operação.

A classificação das lacunas esperadas e a decomposição de `partial_schedules` estão em COLLECTION-DIAGNOSTICS.md.
