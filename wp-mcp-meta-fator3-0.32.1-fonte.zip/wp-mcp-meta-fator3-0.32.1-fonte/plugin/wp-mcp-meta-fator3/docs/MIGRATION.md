# Instalação e migração

Este documento cobre a instalação limpa da versão 0.32.1 e a atualização direta a partir da versão-base 0.32.0. Não há downgrade: correções chegam em versão nova (OPERATIONS.md).

## Atualização da 0.31.0 ou da 0.32.0

A 0.32.1 preserva as conexões, jobs, agendas, histórico e permissões da instalação. A revisão de agendas usa os registros existentes. Não é necessário regravar a conexão, reenviar as consultas nem desativar nenhuma agenda. O painel conserva a folha visual comum da 0.32.0.

Na primeira execução, o Meta procura passagens de público antes registradas como falhas. Só reclassifica uma passagem com evidência da indisponibilidade da mesma consulta; mantém a quantidade de linhas úteis em zero. Quando existe incidente de agenda parada pela coleta já resolvida, o produtor e o observador do Core reconciliam a mesma identidade de incidente. Uma falha de autorização, de infraestrutura ou de outra consulta continua visível. A versão não apaga entradas antigas da fila nem recolhe e-mails que já foram enviados.

Após a troca, consulte a disponibilidade e o estado da última passagem em `meta/list-schedules`, as issues em `meta/health`, os episódios em `f3base/incidentes-tecnicos-ler` e a fila em `f3base/email-wordpress-fila-ler`. Use a data da atualização para distinguir uma abertura nova de uma notificação histórica ou de recuperação. Repita a leitura 26 horas depois. Não suspenda a agenda para silenciar o incidente.

## Requisitos

- WordPress 7.1.4 ou superior.
- PHP 8.3 ou superior, de 64 bits.
- Banco com InnoDB e travas nomeadas.
- Criptografia autenticada disponível (sodium ou OpenSSL AES-256-GCM).

O painel e a ajuda funcionam sem outros plugins. O acesso remoto pelo MCP exige o Fator3 MCP ativo.

## Instalação limpa

1. Envie o instalador, cuja raiz é a pasta `wp-mcp-meta-fator3/`, e ative **Fator3 MCP Meta**. Em multisite, ative em cada site.
2. A ativação cria as tabelas, agenda a manutenção horária e marca a migração do histórico como concluída, porque não há resultados antigos a migrar.
3. Abra **Ferramentas → Fator3 MCP Meta**. Sem conexões, a aba Conexão abre o editor para a primeira conexão; depois de salvar, a lista mostra a faixa **Primeiros passos** até haver conexão com token e ativo selecionado.
4. Confira em **Diagnóstico** (ou `meta/health`) que armazenamento e criptografia estão prontos.
5. Confira `meta/history-status`: `migration.complete=true`.
6. Em **Ajuda** (ou `meta/documentation`), confira que a versão exibida é 0.32.1.

Ativar não cria conexão, não consulta a Meta e não publica nada.

## Atualização direta de 0.32.0 para 0.32.1

1. Faça backup consistente do banco e das chaves e salts do `wp-config.php`.
2. Substitua o plugin pelo instalador novo, no mesmo diretório, sem desinstalar.
3. Recarregue as abas do painel que estavam abertas, para carregar o JavaScript novo.
4. Confira versão, conexões, ativos, retenção e agendas.
5. Confira `meta/health` e `meta/history-status`.
6. Leia a documentação pela Ajuda ou por `meta/documentation` e confira a versão.

## O que é preservado

Tabelas, conexões, credenciais cifradas, identidade conferida, seleção de ativos, usuários associados, retenção, agendas (inclusive pausadas), coletas e seu progresso, histórico, exportações, concessões de consumidores, configuração de mensagens, bloqueios e recibos de eliminação, arquivo de Stories e auditoria. A marca e o progresso da migração do histórico também são preservados. Não há tabela nova. Apenas checkpoints que precisam de retomada são atualizados; registros concluídos conservam seus identificadores.

## Conferência após a troca

O índice instalado informa 0.32.1. Na aba Ajuda, procure um documento pelo nome; na aba Relatórios, confira a tabela na largura do dispositivo. Na aba Diagnóstico, valide um ativo e troque a seleção: o resultado anterior sai da tela. Em uma integração REST, envie um objeto JSON; uma entrada de tipo inválido retorna `invalid_input` antes de qualquer reparo de agendamento. Consulte CONTRACTS.md para o formato de entrada.

## Leitura do anúncio de origem

As concessões anteriores à funcionalidade preservam somente a leitura local. Uma permissão de consulta por ID já gravada em 0.32.0 conserva seu valor ao instalar 0.32.1. Não há migração de tabelas, conversão de IDs ou alteração da retenção.
