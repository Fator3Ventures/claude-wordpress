<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Eligibility of a collection; never changes the supplier value or the next due date. */
final class ScheduleAvailability {
    private const MIN_FOLLOWERS = 100;
    private const DEMOGRAPHICS = ['follower_demographics','engaged_audience_demographics','reached_audience_demographics'];
    private const EMPTY_CODES = ['empty_or_suppressed','value_unavailable'];

    public static function emptyMetric(array $error,string $metric): bool {
        return ($error['field']??null)===$metric && in_array($error['code']??null,self::EMPTY_CODES,true);
    }

    /** Keep malformed JSON containers distinct from an actual empty demographic response. */
    public static function validateAudienceEnvelope(string $raw): void {
        $body=json_decode($raw,false,96,JSON_BIGINT_AS_STRING);
        if(!is_object($body)||!is_array($body->data??null)||isset($body->error))
            throw new Fault('upstream_invalid','A resposta de público não contém uma lista de métricas válida.');
        foreach($body->data as $row){
            if(!is_object($row))throw new Fault('upstream_invalid','A resposta de público contém uma métrica inválida.');
            if(isset($row->values)){
                if(!is_array($row->values))throw new Fault('upstream_invalid','A série de público não contém uma lista de valores.');
                foreach($row->values as $point)if(!is_object($point)||!property_exists($point,'value'))
                    throw new Fault('upstream_invalid','A série de público contém uma observação inválida.');
            }
            $groups=$row->total_value->breakdowns??null;
            if($groups===null)continue;
            if(!is_array($groups))throw new Fault('upstream_invalid','O detalhamento de público não contém uma lista.');
            foreach($groups as $group){
                if(!is_object($group)||!is_array($group->results??null))
                    throw new Fault('upstream_invalid','Um grupo de público não contém uma lista de resultados.');
            }
        }
    }

    /** Validates only the per-metric Graph total, after the parent row has been attributed. */
    public static function totalState(mixed $total,bool $requestedBreakdown): string {
        if($total===null || $total===[])return 'absent';
        if(!is_array($total)||array_is_list($total))return 'unreadable';
        $value=$total['value']??null;
        if($value!==null&&!is_numeric($value)&&($requestedBreakdown||array_key_exists('breakdowns',$total)))return 'unreadable';
        if(!array_key_exists('breakdowns',$total))return $value!==null?'available':(array_key_exists('value',$total)?'absent':'unreadable');
        $groups=$total['breakdowns'];
        if(!is_array($groups)||!array_is_list($groups))return 'unreadable';
        $hasValue=$value!==null;
        foreach($groups as $group){
            if(!is_array($group)||!is_array($group['results']??null)||!array_is_list($group['results']))return 'unreadable';
            if(array_key_exists('dimension_keys',$group)&&!self::dimensions($group['dimension_keys'],true))return 'unreadable';
            foreach($group['results'] as $bucket){
                if(!is_array($bucket)||!is_numeric($bucket['value']??null))return 'unreadable';
                if(array_key_exists('dimension_values',$bucket)&&!self::dimensions($bucket['dimension_values'],false))return 'unreadable';
                $hasValue=true;
            }
        }
        return $hasValue?'available':'empty_breakdown';
    }
    private static function dimensions(mixed $values,bool $keys): bool {
        if(!is_array($values)||!array_is_list($values))return false;
        foreach($values as $v)if(!is_string($v)&&($keys||!is_numeric($v)))return false;
        return true;
    }

    /** Probe only after a successful, empty follower-demographics read on the same selected IG account. */
    public static function observeAudience(array $connection,string $account,array &$page): void {
        if(count($page['errors'])!==1 || !self::emptyMetric($page['errors'][0],'follower_demographics')
            || array_filter($page['rows'],[CollectionState::class,'useful']))return;
        $p=Http::request($connection,$account,['fields'=>'id,followers_count'])['body'];
        if((string)($p['id']??'')!==$account)throw new Fault('upstream_invalid','O perfil de conferência não corresponde à conta da consulta.');
        $count=$p['followers_count']??null;
        if($count===null)return;
        if(!is_int($count)||$count<0)throw new Fault('upstream_invalid','O perfil devolveu uma contagem de seguidores inválida.');
        if($count>=self::MIN_FOLLOWERS)return;
        $proof=['kind'=>'nao_aplicavel','reason'=>'below_minimum_followers','followers_count'=>$count,
            'minimum_followers'=>self::MIN_FOLLOWERS,'account_id'=>$account,'observed_at'=>time()];
        $page['errors'][0]['eligibility']=$proof;
        foreach($page['rows'] as &$row){
            $row['diagnostic']['eligibility']=$proof;
            $row['diagnostic']['message']='O perfil tem '.$count.' seguidores; o mínimo para esta consulta é '.self::MIN_FOLLOWERS.'.';
        }
        unset($row);
        $page['errors'][0]['message']=$page['rows'][0]['diagnostic']['message'];
    }

    /** Count every error, including those that do not fit the diagnostic sample. */
    public static function followGaps(array $errors): int {
        return count(array_filter($errors,static fn($e)=>self::emptyMetric($e,'follows_and_unfollows')));
    }

    /** The caller verifies complete coverage or unambiguous schedule evidence before using this classifier.
     *  fields_unavailable on its own also covers malformed responses and real access failures. */
    public static function audienceNoData(array $query,array $errors,int $observedAt): ?array {
        $account=$query['account_id']??null;
        if(($query['channel']??null)!=='instagram'||($query['report']??null)!=='audience'||!is_string($account)||$account==='')return null;
        $requested=$query['fields']??[];if($requested===[])$requested=['follower_demographics'];
        if(!is_array($requested)||!$errors||count($requested)!==count($errors))return null;
        $seen=[];$observed=0;$proof=null;
        foreach($errors as $e){
            if(!is_array($e))return null;
            $field=$e['field']??null;
            if(!in_array($field,self::DEMOGRAPHICS,true)||!in_array($field,$requested,true)
                ||(array_key_exists('entity_id',$e)&&$e['entity_id']!==$account)||!self::emptyMetric($e,$field)
                ||($e['classification']??'provider_data_unavailable')!=='provider_data_unavailable'
                ||($e['cause']??'undetermined')!=='undetermined'
                ||isset($e['reason'])||($e['http_status']??0)>=400||isset($e['provider_code'])||isset($e['provider_subcode'])
                ||!empty($e['provider_is_transient']))return null;
            $at=$e['observed_at']??$observedAt;if(!is_int($at)||$at<=0)return null;
            $seen[]=$field;$observed=max($observed,$at);
            if(isset($e['eligibility'])){
                $m=$e['eligibility'];
                if(!is_array($m)||$field!=='follower_demographics'||($m['kind']??null)!=='nao_aplicavel'
                    ||($m['reason']??null)!=='below_minimum_followers'||($m['account_id']??null)!==$account
                    ||($m['minimum_followers']??null)!==self::MIN_FOLLOWERS||!is_int($m['followers_count']??null)
                    ||$m['followers_count']<0||$m['followers_count']>=self::MIN_FOLLOWERS
                    ||!is_int($m['observed_at']??null)||$m['observed_at']<=0)return null;
                $proof=$m;
            }
        }
        sort($seen);sort($requested);if($seen!==$requested)return null;
        if($proof!==null&&$seen===['follower_demographics'])return $proof;
        return ['kind'=>'nao_aplicavel','reason'=>'audience_data_unavailable','metrics'=>array_values(array_unique($seen)),
            'account_id'=>$account,'observed_at'=>$observed];
    }

    public static function assessment(array $job,array $coverage): ?array {
        if(($job['last_code']??null)!=='fields_unavailable'||($coverage['plan_complete']??false)!==true||($job['query']['channel']??null)!=='instagram')return null;
        $n=(int)($coverage['error_count']??0);
        if($n<1)return null;
        if($job['query']['report']==='audience' && ($job['successful_rows']??null)===0
            && empty($coverage['errors_sampled']) && is_array($coverage['errors']??null) && count($coverage['errors'])===$n)
            return self::audienceNoData($job['query'],$coverage['errors'],0);
        if($job['query']['report']==='account_insights' && $job['successful_rows']>0 && ($coverage['follow_gap_count']??null)===$n)
            return ['kind'=>'parcial_esperado','reason'=>'follows_and_unfollows_unavailable','metric'=>'follows_and_unfollows'];
        return null;
    }
}
