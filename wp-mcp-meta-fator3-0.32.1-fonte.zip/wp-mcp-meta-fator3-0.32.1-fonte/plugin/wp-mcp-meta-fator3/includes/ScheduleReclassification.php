<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** One-time correction of historical Instagram audience schedules. Jobs, pages and original errors are evidence. */
final class ScheduleReclassification {
    private const STAGE_OPTION='f3_meta_site_owner_031';
    // The outgoing release casts this marker to int. It must still read stage 1 after a downgrade.
    private const COMPLETE='1:availability-035';
    private const JOURNAL='audience-availability-035';

    /** No record reads on a settled site. The schedule limit and the temporary journal are both bounded to 100 IDs. */
    public static function run(): void {
        if(Util::boot(self::STAGE_OPTION,0)===self::COMPLETE)return;
        Store::lock('availability-migration-035',static function(){
            if(get_option(self::STAGE_OPTION,0)===self::COMPLETE)return;
            $ids=Store::lock('schedules',static function(){
                $journal=Store::get('migration',self::JOURNAL);
                $pending=$journal['value']['ids']??[];$changes=[];
                global $wpdb;
                // Decode candidates independently: one unreadable record cannot block intact schedules.
                $keys=$wpdb->get_col($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s ORDER BY record_key LIMIT 100',Store::table(),'schedule'));
                if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao verificar as agendas existentes.');
                foreach($keys as $key){
                    try{
                        $stored=Store::get('schedule',$key);if(!$stored)continue;$row=['key'=>$key]+$stored;
                        $proof=self::proof($key,$row['value']);
                    }
                    catch(Fault $e){
                        // A damaged job/page is not proof of source unavailability. Keep its diagnostics intact.
                        if(in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))continue;
                        throw $e;
                    }
                    if($proof===null)continue;
                    $pending[]=$row['key'];$changes[]=[$row,$proof];
                }
                $pending=array_values(array_unique($pending));
                // A crash after any checkpoint must not strand an incident opened by the Core observer.
                if($changes&&($journal['value']['ids']??[])!==$pending)
                    Store::put('migration',self::JOURNAL,['ids'=>$pending],$journal['revision']??0);
                foreach($changes as [$row,$proof]){
                    $s=$row['value'];$s['availability_assessment']=$proof['assessment'];$s['last_run_status']='nao_aplicavel';
                    $s['collection_success_at']=max((int)($s['collection_success_at']??0),$proof['at']);
                    unset($s['collection_failure_since'],$s['collection_error_since']);
                    Schedules::checkpoint($row,$s);
                }
                return $pending;
            });
            // Retry after a crash or an unavailable store; the Core publisher durably queues undelivered receipts.
            if($ids&&!Worker::recoverAvailabilityIncidents($ids))throw new Fault('persistence_unconfirmed','Recuperação de incidentes ainda não confirmada.');
            $journal=Store::get('migration',self::JOURNAL);
            if($journal)Store::remove('migration',self::JOURNAL,$journal['revision']);
            // Never skip the older owner migration when upgrading directly from an earlier release.
            if((int)get_option(self::STAGE_OPTION,0)===1){
                update_option(self::STAGE_OPTION,self::COMPLETE,true);
                if(get_option(self::STAGE_OPTION,0)!==self::COMPLETE)throw new Fault('persistence_unconfirmed','Migração das agendas ainda não confirmada.');
            }
        });
    }

    /** An exact query, job generation, and completed terminal page take precedence over summaries. */
    private static function proof(string $id,array $s): ?array {
        $q=$s['query']??[];$err=$s['last_error']??[];$at=$err['observed_at']??0;
        if(empty($s['enabled'])||($q['channel']??null)!=='instagram'||($q['report']??null)!=='audience'
            ||!is_string($q['account_id']??null)||$q['account_id']===''||!is_string($q['connection_id']??null)||$q['connection_id']===''
            ||!is_array($s['last_errors']??[])||!empty($s['availability_assessment'])||($s['last_run_status']??null)!=='failed'||($s['last_code']??null)!=='fields_unavailable'
            ||($s['last_successful_rows']??null)!==0||!is_int($at)||$at<1||$at>time()||!is_string($s['last_job']??null)||$s['last_job']===''
            ||ExecutionBudget::since($s)!==null||!empty($err['auth_scope'])
            ||max((int)($s['collection_failure_since']??0),(int)($s['collection_error_since']??0),(int)($s['last_success_at']??0),(int)($s['collection_success_at']??0))>$at
            ||!self::currentIdentity($err,$s))return null;
        $job=Store::get('job',$s['last_job']);$assessment=null;
        if($job){
            $j=$job['value'];$pages=$j['pages']??null;
            if(($j['schedule_id']??null)!==$id||($j['schedule_epoch']??null)!==($s['collection_epoch']??null)
                ||!is_array($j['query']??null)||!self::sameSelection($j['query'],$q)||!self::currentIdentity($j,$s)||($j['last_code']??null)!=='fields_unavailable'
                ||($j['status']??null)!=='partial'||($j['outcome']??null)!=='failed'||($j['successful_rows']??null)!==0
                ||!empty($j['manual_pause'])||!empty($j['cursor'])||!is_int($pages)||$pages<1
                ||!is_array($j['errors']??null)||!self::consistentErrors($err,$s['last_errors']??[],$j['errors'])
                ||!is_int($j['updated_at']??null)||$j['updated_at']<1||$j['updated_at']>time())return null;
            $page=Store::get('result',$s['last_job'].':'.str_pad((string)($pages-1),6,'0',STR_PAD_LEFT));
            if($page&&(!$page['expires_at']||$page['expires_at']>=time())&&(!$job['expires_at']||$job['expires_at']>=time())){
                $p=$page['value'];$data=$p['data']??[];$cov=$data['coverage']??[];
                if(!is_array($p['query']??null)||!self::sameSelection($p['query'],$q)||($data['account_id']??null)!==$q['account_id']
                    ||($data['connection_id']??null)!==$q['connection_id']||($data['report']??null)!=='audience'
                    ||($data['channel']??null)!=='instagram'||!empty($data['next_cursor'])||($cov['successful_rows']??null)!==0
                    ||empty($cov['plan_complete'])||!empty($cov['errors_sampled'])
                    ||($cov['errors']??null)!==($j['errors']??null)||($cov['error_count']??0)!==count($j['errors']??[]))return null;
                $assessment=ScheduleAvailability::assessment($j,$cov);
                if(($assessment['kind']??null)!=='nao_aplicavel')return null;
            }else{
                // A terminal job cannot override contradictory evidence in the surviving schedule or vice versa.
                if(!self::snapshot($s,$q,$err,$at))return null;
                $assessment=ScheduleAvailability::audienceNoData($q,$j['errors']??[],$at);
            }
        }else $assessment=self::snapshot($s,$q,$err,$at);
        return ($assessment['kind']??null)==='nao_aplicavel'&&is_int($assessment['observed_at']??null)
            &&$assessment['observed_at']>0&&$assessment['observed_at']<=time()?['assessment'=>$assessment,'at'=>$at]:null;
    }
    private static function sameSelection(array $a,array $b): bool {
        ksort($a);ksort($b);
        return $a===$b;
    }
    private static function consistentErrors(array $last,array $samples,array $errors):bool {
        $codes=array_column($errors,'code');$codes[]='fields_unavailable';
        foreach(array_merge([$last],$samples) as $e)
            if(!is_array($e)||!in_array($e['code']??null,$codes,true)||!empty($e['auth_scope'])||($e['http_status']??0)>=400
                ||isset($e['provider_code'])||isset($e['provider_subcode'])||!empty($e['provider_is_transient']))return false;
        return true;
    }
    private static function currentIdentity(array $e,array $s):bool {
        foreach(['credential_generation','authorization_revision'] as $key)
            if(isset($e[$key])&&($s[$key]??null)!==$e[$key])return false;
        return true;
    }
    /** When old pages expired, only the unique metric and the original, source-specific local error qualify. */
    private static function snapshot(array $s,array $q,array $err,int $at):?array {
        if(($s['unavailable_metrics']??null)!==['follower_demographics']||!in_array($q['fields']??[],[[],['follower_demographics']],true)
            ||($err['code']??null)!=='empty_or_suppressed')return null;
        $errors=$s['last_errors']??[];
        foreach($errors as $sample)if(!is_array($sample)||($sample['code']??null)!==$err['code']
            ||!ScheduleAvailability::audienceNoData($q,[$sample+['field'=>'follower_demographics']],$at))return null;
        return ScheduleAvailability::audienceNoData($q,[$err+['field'=>'follower_demographics']],$at);
    }
}
