# Pedidos — Fator3 MCP Meta (wp-mcp-meta-fator3)

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-meta-fator3**. Cite como "Pedidos MCP Meta N". Próximo número: 35; número retirado fica vago. Pedido entregue sai daqui na troca de versão, mesmo sem aceite; o aceite segue nas pendências do estado da frota, e o reprovado vira pedido novo (dono, 19/11/2026).

## wp-mcp-meta-fator3 — pendentes

**34. Tela no Guia visual: folha comum, nomes comuns e `hr.wp-header-end` (dono, 20/11/2026 às 14:08: "Ainda temos diferenças entre a parte visual (design/ux) dos plugins ... Analise as versões e padronize").**

*Evidência.* Fator3 MCP Meta 0.30.0, Site-Teste, 20/11/2026, código do instalador e estilos computados: a tela é a base do guia (1320 px, h1 nativo, cor do esquema do wp-admin, pílulas de 40 px, selos `f3-pill`), mas falta o `hr.wp-header-end`, e o aviso de outro plugin entra no cabeçalho, entre o título e a descrição; a navegação e o selo de versão usam nomes próprios (`f3-tabs`, `f3-group-row`, `f3-tab-list`, `f3-badge`); há duas classes para o mesmo cartão (`f3-section`, `f3-panel`), três para bloco recolhível e quatro avisos em linha; a folha própria tem 17,9 KB com as regras que passam à folha comum. Arquivos e linhas: [Guia visual das telas dos pacotes Fator3](https://claude.ai/code/artifact/87331836-0b71-4263-a10a-f4e63fb0cd22), aba "Fator3 MCP Meta".

*Pedido.* Aplicar o guia: (1) `assets/f3-ui.css` igual ao texto da aba "Folha comum", carregada antes da folha própria; (2) os 12 ajustes da aba "Fator3 MCP Meta". Slug, capacidade, rotas e options não mudam.

*Aceite.* No Site-Teste, a conferência da seção 7 do guia preenchida por subaba, com as capturas a 360, 768 e 1440 px; com um aviso de outro plugin ativo, o aviso aparece depois do cabeçalho; sha256 de `f3-ui.css` igual ao dos outros pacotes.
