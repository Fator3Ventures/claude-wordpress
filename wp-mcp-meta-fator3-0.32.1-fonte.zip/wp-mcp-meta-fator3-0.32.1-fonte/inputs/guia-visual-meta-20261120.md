# Fator3 MCP Meta — ajustes de tela

O Fator3 MCP Meta 0.30.0 é a base do guia: a folha comum saiu das regras dele. O que muda é trocar os nomes próprios pelos comuns, tirar da folha própria o que passou à folha comum e acrescentar o `hr.wp-header-end`, que falta. Slug, capacidade, rotas e options não mudam. O Site-Teste recebeu a 0.31.0 durante a leitura; a tela dela não foi comparada.

## Navegação

Já segue o guia: Configurar (Conexão · Ativos · Consumidores de anúncios) · Dados (Relatórios · Coletas · Histórico · Conversas · Arquivo de Stories) · Suporte (Diagnóstico · Ajuda). Não tem o grupo Operação e abre em Configurar › Conexão.

## Ajustes

| # | onde | hoje | muda para |
| --- | --- | --- | --- |
| 1 | carga da folha (`includes/Admin.php` linha 60) | só `assets/admin.css` | `assets/f3-ui.css` antes da folha própria |
| 2 | raiz `div.wrap.f3-social` | variáveis `--f3-accent`, `--f3-border`, `--f3-muted` e `--f3-gap` declaradas na folha própria | acrescentar `f3-ui`; a folha própria deixa de declarar variável |
| 3 | cabeçalho `header.f3-heading` (linha 96) | h1 e descrição dentro de `div`; selo `span.f3-badge`; sem `hr.wp-header-end`, e o aviso de outro plugin entra entre o título e a descrição | sem `div`; `span.f3-version`; `hr.wp-header-end` depois do cabeçalho |
| 4 | navegação (linha 97): `nav.f3-tabs`, `div.f3-group-row` com `a.f3-group-link`, `div.f3-tab-list` com `a[data-tab]` | o desenho é o do guia; os nomes são próprios | `nav.f3-nav`, `div.f3-groups` e `div.f3-subtabs` |
| 5 | cartões `.f3-section` e `.f3-panel` | duas classes para o mesmo cartão; 20 px de distância entre cartões | só `f3-section`; 16 px, pela folha comum |
| 6 | aviso de resultado `.f3-notice` e `.f3-notice-error` | o nome se confunde com `.notice` do WordPress | `f3-result` e `is-error` |
| 7 | blocos recolhíveis `details.f3-form-block`, `details.f3-collapsible` e `.f3-danger-zone` | três nomes | `details.f3-collapsible`; `f3-danger` na zona de risco |
| 8 | campos: `label` direto em `.f3-grid`, com `.f3-grid-2`, `.f3-grid-3` e `.f3-grid-compact` | quatro grades; rótulo e campo no mesmo `label` | `f3-field` em `f3-grid`, ou `f3-grid is-wide` |
| 9 | avisos em linha `.f3-warning` (fundo `#fcf9e8`, sem barra), `.f3-identity-warning` (barra `#dba617`), `.f3-credential-warning` (texto `#8a4b00`) e `.f3-inline-error` | quatro desenhos | `f3-callout` com `is-warn` ou `is-error` |
| 10 | tabelas: regra na raiz (`.f3-social table`), `.f3-scroll` com altura máxima de 650 px e `.f3-table-scroll` | três formas | toda tabela dentro de `f3-table-scroll`; `.f3-scroll` sai |
| 11 | cores fixas na folha: `#00a32a`, `#d63638`, `#dba617`, `#8a4b00`, `#5c1e1e`, `#c3c4c7` | valores repetidos | variáveis `--f3-*` |
| 12 | folha própria `assets/admin.css` | 17,9 KB, com cabeçalho, navegação, cartão, selo, grade, ações e tela estreita | fica só o que é do Meta: primeiros passos (`f3-steps`), navegador de dados (`f3-browser`), efeitos do diagnóstico e ajuda em duas colunas |

## Já está conforme

- Largura de 1320 px, h1 nativo, cor de destaque do esquema do wp-admin.
- Grupos e subabas com 40 px, e 44 px abaixo de 782 px; links com endereço e `aria-current`.
- Selos `f3-pill` com `is-ok`, `is-warn`, `is-error` e `is-info`, nas cores do guia.
- A 360 px a página não rola na horizontal; botões com 40 px.

## Aceite

A conferência da seção 7 do guia preenchida por subaba, com as capturas a 360, 768 e 1440 px; com um aviso de outro plugin ativo, o aviso aparece depois do cabeçalho.
