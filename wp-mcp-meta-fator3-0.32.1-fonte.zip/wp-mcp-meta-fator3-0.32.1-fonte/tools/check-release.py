"""Verify distribution identities, release layout and equality of the two runtime copies."""
import hashlib, json, re, sys, zipfile
from pathlib import Path

def require(value, message):
    if not value: raise SystemExit(message)

def digest(data): return hashlib.sha256(data).hexdigest()

def paths(z, root):
    found={}
    for i in z.infolist():
        parts=i.filename.split('/')
        require(len(parts)>1 and parts[0]==root and not any(s in ('.','..','') for s in parts),'unexpected ZIP path: '+i.filename)
        require(not i.filename.lower().endswith(('.zip','.sql','.pyc')),'unexpected payload: '+i.filename)
        require(i.filename not in found,'duplicate: '+i.filename)
        require((i.external_attr>>16)&0o170000!=0o120000,'symlink: '+i.filename)
        found[i.filename]=digest(z.read(i))
    return found

install,source=map(Path,sys.argv[1:3])
slug='wp-mcp-meta-fator3'; version=install.name.removeprefix(slug+'-').removesuffix('-instalador.zip')
prefix=slug+'-'+version+'-fonte'
require(source.name==prefix+'.zip','source/version mismatch')
with zipfile.ZipFile(install) as a, zipfile.ZipFile(source) as b:
    ia=paths(a,slug);sb=paths(b,prefix)
    sha={k.removeprefix(slug+'/'):v for k,v in ia.items()}
    require(json.loads(a.read(slug+'/manifest.sha256.json'))=={k:v for k,v in sha.items() if k!='manifest.sha256.json'},'installer manifest')
    runtime=prefix+'/plugin/'+slug+'/'
    require(sha=={k.removeprefix(runtime):v for k,v in sb.items() if k.startswith(runtime)},'runtime copy differs')
    header=a.read(slug+'/'+slug+'.php').decode()
    for tag,val in [('Version',version),('Requires at least','7.1.4'),('Requires PHP','8.3')]:
        require(re.search(r'(?m)^\s*\*?\s*'+re.escape(tag)+r':\s*'+re.escape(val)+r'\s*$',header),'header: '+tag)
    require('cópia anterior ao fechamento do fonte' in b.read(prefix+'/'+slug+'-'+version+'-relatorio.md').decode(),'missing report')
print(json.dumps({'version':version,'installer_entries':len(ia),'source_entries':len(sb),'runtime_identical':True,'hashes':{p.name:digest(p.read_bytes()) for p in (install,source)}},ensure_ascii=False))
