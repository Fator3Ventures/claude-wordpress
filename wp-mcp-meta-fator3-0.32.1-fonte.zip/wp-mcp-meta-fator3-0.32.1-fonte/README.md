# Fator3 MCP Meta 0.32.1

**Pedidos MCP Meta 34 e 35.** A 0.32.1 conserva a padronização visual da 0.32.0 e corrige o diagnóstico de agendas de público. Veja [Pedido 35](planning/pedido-35.md) e [conferência](evidence/0321/). O painel mantém o nome e os endereços existentes. A folha visual comum Fator3 1.0.0 pertence ao pacote e carrega somente na tela administrativa do Meta. WordPress 7.1.4+ e PHP 8.3+ de 64 bits.

- `build/common/Admin.php`: marcação e registro dos recursos do painel.
- `build/assets/f3-ui.css`: cópia da folha comum; `admin.css` e `admin.js`: apresentação e comportamento específicos do Meta.
- `build/docs/meta`: manuais editáveis. O instalador contém os documentos gerados e o leitor MCP.
- `tests` e `evidence/0321`: testes, capturas e comprovantes desta rodada. As pastas de outras versões preservam evidências históricas.
- `plugin/wp-mcp-meta-fator3`: árvore idêntica à pasta instalada pelo WordPress.

Para reproduzir o pacote, use `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. A saída fica em `build/dist`. Somente o arquivo `-instalador.zip` é instalável. Consulte o relatório externo para a identidade final da entrega.
