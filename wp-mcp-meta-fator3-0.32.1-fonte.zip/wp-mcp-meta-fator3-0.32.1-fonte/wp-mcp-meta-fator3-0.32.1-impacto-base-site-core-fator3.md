# Impacto para o Fator3 Site Core — encerrar silenciosamente falsos episódios de público

**Emissor:** `wp-mcp-meta-fator3`, base 0.32.0, versão 0.32.1, instalador SHA-256 `c8dd8e3bfd43e5ece774920ecc12d12b1b4ceb2d1080b1ddca2da3d731568e70`. Origem: Pedidos MCP Meta 35. Destinatário: `base-site-core-fator3`, base examinada 1.100.1. Etapa: **entrega**. Situação: **aberto para incorporação no Core**. Prontidão: **pronto para implementação**. Natureza: contrato de incidentes e fila de e-mail. Revisão 1, 20/11/2026.

## Impacto e pedido

Quando a atualização corrige uma antiga passagem de público que já tinha sido notificada como `agenda_parada`, o Meta 0.32.1 publica a recuperação com a identidade original. Se a abertura já foi comunicada, o Core 1.100.1 cria um novo e-mail de **Recuperação técnica**. A abertura antiga continua corretamente na fila/histórico. Altera-se o estado do incidente; os quatro e-mails de recuperação ainda desatendem o critério de nenhuma nova mensagem para os falsos episódios.

**Ação pedida ao mantenedor do Core:** integrar o encerramento silencioso *somente* para episódios correlacionados à reclassificação histórica de demografia. Registrar a recuperação no incidente e preservar a trilha de auditoria. Manter avisos normais para falha diária ou semanal real, inclusive se, depois da falha, a origem voltar respondendo sem dados. Não alterar destinatários, carências gerais, mensagens de outros recursos nem os registros históricos da fila. Não requer versão adicional do Meta.

## Comportamento do contrato proposto

As observações do produtor e do observador periódico entram no contrato existente `f3base_incidente_publicar_v1`. Sob a trava do episódio, o Core confere o pacote, o código, a identidade estável do recurso, o estado atual da agenda e os instantes da evidência. A projeção de saúde do Meta já consumida pelo observador fornece a avaliação local; não se consultam a Graph nem segredos. O Core só silencia a recuperação quando a prova dessa mesma passagem já existia antes da abertura, o início do episódio coincide com o erro reclassificado e a agenda não apresenta falha atual. Um chamador não pode solicitar silêncio por meio de um campo no evento. Sem prova suficiente, prevalece o fluxo normal de notificações.

Entregas pendentes do próprio episódio seguem as regras de travas e reservas do Core. Não há promessa de retirar e-mail já aceito pelo transporte. Uma reserva de envio em curso ou de resultado incerto precisa de reconciliação pelo procedimento existente. A marca de encerramento é vinculada ao episódio; uma falha nova volta a gerar os avisos normais.

## Proposta aplicável e validação

[Baixar a proposta técnica para o Core](wp-mcp-meta-fator3-0.32.1-proposta-base-site-core-fator3.zip). É um conjunto de revisão: diff, roteiros e evidências. **Não é um instalador WordPress.** A mesma árvore está em `integration/035-core/` no fonte do Meta.

- Base oficial do Core: instalador `15b5f18858d5e56e5cdbc96bdef83fcc60629279cc6c8e7e17d14571a9fe2f11`; fonte `c4741babb4624daa7088785e74a0f896471fa98fca3a14cae5f62df14443210d`. A identidade do patch está em `identidade.json`.
- Partindo da árvore de distribuição extraída, confira os hashes-base e aplique `patch -p1 < core-1.100.1-035.patch` a partir da pasta **pai** de `base-site-core-fator3/`. Altera apenas `includes/class-f3base-incidentes.php` e `includes/class-f3base-incidentes-provedores.php`. Confira os dois hashes resultantes no manifesto e incorpore no fonte oficial do Core conforme a sua estrutura.
- WordPress 7.1.4, PHP 8.4.27, Meta 0.31.0 → 0.32.1 oficial inalterado, banco e fila reais, Graph simulada e SMTP bloqueado. A prova da fila passou em **153 verificações**; a prova complementar de reservas e repetição passou em **22**. Os JSONs distinguem verificações anteriores e posteriores.
- Com Core estável: **4** aberturas históricas + **4** novos e-mails de recuperação, **0** novas aberturas de público. Com a proposta: as mesmas **4** aberturas históricas conservadas, **4** incidentes recuperados e **0 novos e-mails de público**, inclusive após +93.604 segundos no relógio do Meta. O incidente diário real e uma falha semanal real que só depois recebeu indisponibilidade geraram normalmente seus avisos de abertura e recuperação. Uma mensagem e uma pendência de outro recurso foram preservadas.

## Incorporação, ordem e aceite

O mantenedor do Core revisa o patch, incorpora em uma nova versão própria e valida novamente a fila, incluindo a concorrência com o observador e as reservas já existentes. A frota deve instalar o **Core com a correção antes do primeiro carregamento do Meta 0.32.1** nos sites afetados se o objetivo for evitar também os e-mails de recuperação. Instalar o Core depois não recolhe correio já aceito. Nenhuma modificação desta proposta foi aplicada ao Core oficial, ao Site-Teste compartilhado ou à produção. O mantenedor do Meta fornece a prova de origem e o contrato corrente; a decisão de incorporação e a publicação do destinatário cabem a seu mantenedor e à frota.

Critério de aceite: quatro episódios falsos encerrados com o histórico preservado, sem novos e-mails de abertura **nem** de recuperação relativos a essas reclassificações; o sistema continua notificando episódios reais e preservando recursos não envolvidos. Repetir a leitura após pelo menos 26 horas no site atualizado. Revisão 1: impacto identificado comparando os recibos do Core oficial; proposta limitada ao episódio e validada em cópia isolada.

**Pacote de revisão:** wp-mcp-meta-fator3-0.32.1-proposta-base-site-core-fator3.zip, SHA-256 `0d13e52d59e51622a74fd407d23244467ae95a03485296a2b965872b2a32297c`.
