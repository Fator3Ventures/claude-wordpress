# Fator3 MCP LinkedIn 0.12.0

Base aceita 0.11.0. Implementa o contrato opcional comercial 1.2.0 solicitado no impacto Core 1.58.0 revisão 2, Pedido Core 323. Concessão por consumidor/finalidade/conta/ação, referência vinculada, validação e diário durável próprios. Mantém aquisição 1.0.0, Lead Sync, Pages/Ads, retenção e histórico.

Três operações novas, total 93; configuração no painel Ativos. Leia STAGE-CONVERSIONS.md para contrato, payload, concorrência, permissões, recibos e recuperação. Os mínimos permanecem WordPress 6.4/PHP 8.1.2 de 64 bits. Core 1.58.0 é necessário para o consumidor comercial, não para o funcionamento independente do LinkedIn.

Companheiros de referência: Core 1.58.0, MCP 0.34.0, Google 0.21.0, Meta 0.13.0, Pipedrive 0.3.0. A exigência própria PHP 8.3.36 do Pipedrive não é contornada em laboratório PHP 8.3.6. Os testes cobrem clean, upgrade direto, isolamento, mínimos, consumidor Core real, schema/docs MCP e DOM; consulte o relatório externo para resultados e identidades finais.

Achado de impacto: MCP 0.34.0 restringe identidade de serviço ao consumidor de aquisição. O novo consumidor comercial conserva recibo local e informa ausência de confirmação central. O mantenedor MCP deve admitir explicitamente site-core-quality; nenhum código/documento dele é alterado nesta entrega. O impacto recebido do Core é respondido no relatório principal, conforme norma revisão 5.

Sem migração de schema nem ativação automática. Reconfirmar concessão comercial gira a referência; o Core bloqueia reservas anteriores. Reversão exige desligar o destino comercial e conservar banco/salts/recibos. Não houve envio real de conversão, publicação ou gasto Ads para validar a versão.
