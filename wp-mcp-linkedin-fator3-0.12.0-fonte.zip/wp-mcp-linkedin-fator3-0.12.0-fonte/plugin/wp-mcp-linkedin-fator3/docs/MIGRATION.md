# Atualização 0.8.1 → 0.9.0

Na rodada corrente: atualização direta 0.10.1 → 0.11.0. Confirme versão, 90 operações e selftest; leia HISTORY.md integralmente. Há tabela histórica própria, proteção de auditorias existentes e migração em lotes sem exclusão na atualização. A política finita explícita continua válida na manutenção posterior. Reversão requer avaliar/restaurar banco e salts, não apenas os arquivos.

Procedimento histórico da 0.9.0: substitua o ZIP de raiz `wp-mcp-linkedin-fator3` e confirme a versão 0.9.0 em uma nova requisição a `linkedin/status`, `linkedin/selftest`, as 81 operações `linkedin/*` e a leitura integral de `linkedin/documentation`. Combinação desta rodada: Site Core 1.49.1, Fator3 MCP 0.29.1, MCP Google 0.18.1 e MCP Meta 0.7.1. Não é necessário desativar os acompanhantes.

A atualização direta da 0.8.1 mantém schema 2, opções, credenciais, concessões, agendas, revisões, ciphertexts, datas, expiração e projeções. Nenhuma nova migração de banco é criada. A mudança atua quando um registro ilegível precisa sair da seleção: relê sob bloqueio individual e altera somente a projeção caso revisão e ciphertext ainda coincidam. Um reparo concorrente permanece intacto; na migração, pode ficar pendente para o próximo lote.

Registros já isolados não são reativados automaticamente. Faça backup de arquivos, banco e salts antes de atualizar. Voltar os arquivos para 0.8.1 mantém os dados, mas reintroduz a corrida corrigida pelo pedido 12; não desfaz conversões, coletas ou envios.

## Histórico — atualização 0.7.0 → 0.8.0


Na atualização histórica para 0.8.0, substitua o ZIP de raiz wp-mcp-linkedin-fator3 e confirme, em nova requisição, versão 0.8.0 em `linkedin/status` (com `state` e `queue.migration_pending=false` depois das primeiras requisições), `linkedin/selftest`, 81 operações `linkedin/*` e `linkedin/documentation`. Combinação examinada: Site Core 1.48.0, Fator3 MCP 0.28.0, MCP Google 0.17.0 e MCP Meta 0.6.0. Não exige desativar acompanhantes.

Schema SQL passa de 1 para 2 por dbDelta aditivo (colunas `queue_state`, `queue_next`, índice `runnable`). Registros, ciphertext, revisões, datas, retenção, conexões, credenciais, concessões Lead Sync/CAPI, agendas, prévias e diários são preservados byte a byte; só a projeção técnica das coletas é preenchida, em lotes de 100. Opções novas: `f3_linkedin_queue_migration`, `f3_linkedin_queue_settled` (autoload), `f3_linkedin_worker_schedule_attempt/failure`, `f3_linkedin_last_maintenance` e, se necessário, `f3_linkedin_maintenance_rearmed`. A opção antiga `f3_linkedin_scan` deixa de ser usada e não é apagada.

Volta para a 0.7.0: os arquivos da base funcionam com o mesmo banco (colunas extras ignoradas) e voltam ao worker antigo. Ao reinstalar a 0.8.0, o schema é reaplicado e as projeções reconstruídas. Faça backup de arquivos, banco e salts. Restaurar arquivos não desfaz conversões, coletas ou envios já feitos.

# Histórico — atualização 0.6.0 → 0.7.0


Substitua o ZIP de raiz wp-mcp-linkedin-fator3 e confirme 0.7.0, selftest, documentação, manutenção e service_audit no status. Core 1.47.0, MCP 0.27.0, Google 0.17.0 e Meta 0.4.1 são a combinação examinada. Não exige desativar acompanhantes ou alterar a fila Core.

Schema SQL permanece 1. Conexões, credenciais sobrepostas, concessões Lead Sync/CAPI, agendas, prévias, cursores e diários são preservados. Não cria nem reconfirma concessão na atualização. Novos diários de envio SDK recebem service_identity antes do POST; diários 0.6.0 sem vínculo permanecem legados, não são importados ou reemitidos automaticamente. Nenhum novo cron de auditoria é criado.

Reconfirmação/revogação da concessão altera sua revisão e bloqueia detalhes de referências antigas no leitor de serviço. Mudança de token exige prova local de escopos correspondente para ler. A referência central histórica, quando existir, permanece sob a retenção do MCP; diário local não é apagado por revogação. Veja SERVICE-AUDIT.md.

Voltar os arquivos à 0.6.0 remove descritor/introspector/leitor e emissão de serviço, preservando dados; o canal deve falhar fechado se o leitor ficar indisponível. CAPI e auditoria humana da base continuam existentes. Faça backup de arquivos, banco e salts e coordene a fila/escritores. Restaurar arquivos não desfaz conversões aceitas nem banco. Não recrie IDs para reenviar eventos confirmados/incertos. Desativação remove somente os hooks agendados próprios; desinstalação conserva dados.

## Patch 0.8.1

Atualização direta da 0.8.0, sem migração adicional; schema 2, opções, concessões, ciphertexts e projeções da fila são preservados. Ao partir da 0.7.0 aplica-se a migração aditiva descrita para a 0.8.0. Voltar à 0.8.0 reintroduz os defeitos de recuperação/diagnóstico corrigidos, sem desfazer envios ou coletas. Registros já marcados unreadable permanecem preservados e isolados.


## Atualização 0.10.0 — pedido 13

Consulte RELEASE-0.10.0.md e CREDENTIALS.md: candidata conferida antes de persistir, identidade guiada, nomes com origem explícita e agendas rebaseadas no mesmo salvamento. A configuração recebe revisão a cada gravação; authorization_revision e credential_generation distinguem autorização e credencial. Uma alteração benigna mantém o vínculo das identidades de serviço CAPI já emitidas; uma nova concessão ou identidade continua revogando o vínculo anterior. Não editar documentos recebidos de outros pacotes para responder a pedidos.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.34.0 ainda não confirma auditoria central desse novo consumidor; o recibo local permanece disponível. Não repetir evento por falta de recibo central. Atualização direta de referência: 0.11.0 → 0.12.0.
