<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Optional commercial-stage transport; Core owns consent, stage selection and its queue. */
final class StageConversions {
    public const CONTRACT='site-conversion-delivery/1.2.0';
    public const CONSUMER='site-core-quality';
    public const PURPOSE='crm_stage';
    public static function key(string $action): string {
        if(!preg_match('/^[1-9][0-9]{0,29}$/D',$action))throw new Fault('acao_invalida','Escolha o ID numérico da regra comercial.');
        return self::CONSUMER.':'.$action;
    }
    public static function schemas(): array {
        $action=['type'=>'string','pattern'=>'^[1-9][0-9]{0,29}$'];$rev=['type'=>'integer','minimum'=>0];$bool=['type'=>'boolean'];
        return [
            'get-stage-conversion-grants'=>Schemas::obj(['offset'=>['type'=>'integer','minimum'=>0,'maximum'=>100000]]),
            'stage-conversion-capabilities'=>Schemas::obj(['action'=>$action],['action']),
            'save-stage-conversion-grant'=>Schemas::obj(['consumer_id'=>['type'=>'string','enum'=>[self::CONSUMER]],'purpose'=>['type'=>'string','enum'=>[self::PURPOSE]],'action'=>$action,'expected_revision'=>$rev,'enabled'=>$bool,'connection_id'=>['type'=>'string','pattern'=>'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$'],'account_id'=>['type'=>'string','pattern'=>'^[0-9]{1,40}$'],'expected_connection_revision'=>$rev,'dry_run'=>$bool,'confirm'=>$bool],['consumer_id','purpose','action','expected_revision','enabled'])
        ];
    }
    public static function grant(string $action): array {
        $r=Store::get('conversion_grant',self::key($action));
        return $r?array_intersect_key($r['value'],array_flip(['consumer_id','purpose','action','enabled','connection_id','account_id','conversion_id','destination_ref','connection_revision','authorization_revision','rule','created_at']))+['revision'=>$r['revision']]:['consumer_id'=>self::CONSUMER,'purpose'=>self::PURPOSE,'action'=>$action,'revision'=>0,'enabled'=>false];
    }
    public static function grants(array $i): array {
        Access::admin();$at=$i['offset']??0;$rows=Store::list('conversion_grant',$at,51);$out=[];
        foreach(array_slice($rows,0,50) as $r)if(($r['value']['consumer_id']??'')===self::CONSUMER)$out[]=self::grant($r['value']['action']);
        return ['grants'=>$out,'next_offset'=>count($rows)>50?$at+50:null,'consumer_id'=>self::CONSUMER,'purpose'=>self::PURPOSE];
    }
    public static function denyAcquisition(string $action): void {
        $g=Store::get('conversion_grant',Conversions::CONSUMER);
        if($g&&($g['value']['conversion_id']??'')===$action)throw new Fault('acao_de_aquisicao','A etapa comercial exige regra distinta da aquisição.');
    }
    public static function denyCommercial(string $action): void {
        $g=Store::get('conversion_grant',self::key($action));
        if($g&&!empty($g['value']['enabled']))throw new Fault('acao_comercial','Esta regra já tem concessão comercial ativa. Escolha outra regra para aquisição.');
    }
    /** Strict local readiness. No HTTP or mutation, including under user zero. */
    public static function context(string $action,string $ref=''): array {
        $r=Store::get('conversion_grant',self::key($action));if(!$r||empty($r['value']['enabled']))throw new Fault('sem_concessao','Conceda esta ação comercial explicitamente.');$g=$r['value'];
        if(($g['consumer_id']??'')!==self::CONSUMER||($g['purpose']??'')!==self::PURPOSE||($g['action']??'')!==$action||($g['conversion_id']??'')!==$action)throw new Fault('concessao_divergente','Concessão de outra finalidade ou ação.');
        if(!is_string($g['destination_ref']??null)||!preg_match('/^[a-f0-9]{64}$/D',$g['destination_ref'])||($ref!==''&&!hash_equals($g['destination_ref'],$ref)))throw new Fault('destino_alterado','O destino vinculado mudou.');
        self::denyAcquisition($action);$c=Connections::get($g['connection_id']);Connections::usable($c);Access::checkPrincipal($g['principal']);Access::asset($c,'ads',$g['account_id']);
        if($c['revision']!==$g['connection_revision']||($c['authorization_revision']??1)!==($g['authorization_revision']??0))throw new Fault('destino_alterado','Reconfirme a concessão após alterar a autorização.');
        if(($g['rule']['id']??'')!==$action||($g['rule']['account_id']??'')!==$g['account_id']||($g['rule']['conversion_method']??'')!=='CONVERSIONS_API'||($g['rule']['enabled']??false)!==true)throw new Fault('regra_divergente','Regra API ativa não comprovada para esta conta.');
        Conversions::requireLocalProof($c);return [$g,$c,$r['revision']];
    }
    public static function capabilities(string $action): array {
        $a=['action'=>$action,'purpose'=>self::PURPOSE,'ready'=>false,'reason'=>'sem_concessao','destination_ref'=>''];
        try{[$g]=self::context($action);$a['ready']=true;$a['reason']='pronto';$a['destination_ref']=$g['destination_ref'];}
        catch(Fault $e){$a['reason']=$e->reason;}catch(\Throwable $e){$a['reason']='armazenamento_indisponivel';}
        return ['contract'=>self::CONTRACT,'supported_contracts'=>[self::CONTRACT],'purposes'=>[self::PURPOSE],'ready'=>$a['ready'],'reason'=>$a['reason'],'actions'=>[$action=>$a]];
    }
    public static function save(array $i): array {
        Access::admin();Schemas::validate('save-stage-conversion-grant',$i);$key=self::key($i['action']);
        $save=static function()use($i,$key){return Store::lock('conversion-grant',static function()use($i,$key){
            $old=Store::get('conversion_grant',$key);if(($old['revision']??0)!==$i['expected_revision'])throw new Fault('revision_conflict','Releia a concessão comercial.');
            $preview=$i['dry_run']??true;if(!$preview&&empty($i['confirm']))throw new Fault('confirmation_required','Confirme a concessão comercial.');
            if(!$i['enabled']){
                if($preview)return ['dry_run'=>true,'remote_write_sent'=>false,'action'=>$i['action'],'enabled'=>false,'expected_revision'=>$i['expected_revision']];
                $v=$old['value']??['consumer_id'=>self::CONSUMER,'purpose'=>self::PURPOSE,'action'=>$i['action']];$v['enabled']=false;Store::put('conversion_grant',$key,$v,$i['expected_revision']);return self::grant($i['action']);
            }
            foreach(['connection_id','account_id','expected_connection_revision'] as $k)if(!isset($i[$k]))throw new Fault('invalid_input','Escolha conexão, conta e revisão.');
            self::denyAcquisition($i['action']);$c=Connections::get($i['connection_id']);Access::connection($c,'ads',$i['account_id']);
            if($c['revision']!==$i['expected_connection_revision'])throw new Fault('revision_conflict','A conexão mudou.');
            $rule=Conversions::verifyDestination($c,$i['account_id'],$i['action']);Connections::revalidate($c);$principal=Access::principal();Access::checkPrincipal($principal);
            if($preview)return ['dry_run'=>true,'remote_write_sent'=>false,'consumer_id'=>self::CONSUMER,'purpose'=>self::PURPOSE,'action'=>$i['action'],'connection_id'=>$c['id'],'account_id'=>$i['account_id'],'rule'=>$rule,'expected_revision'=>$i['expected_revision'],'expected_connection_revision'=>$c['revision']];
            $v=['consumer_id'=>self::CONSUMER,'purpose'=>self::PURPOSE,'action'=>$i['action'],'enabled'=>true,'connection_id'=>$c['id'],'connection_revision'=>$c['revision'],'authorization_revision'=>$c['authorization_revision']??1,'account_id'=>$i['account_id'],'conversion_id'=>$i['action'],'rule'=>$rule,'principal'=>$principal,'destination_ref'=>bin2hex(random_bytes(32)),'created_at'=>time()];
            Store::put('conversion_grant',$key,$v,$i['expected_revision']);return self::grant($i['action']);
        });};
        return !empty($i['connection_id'])?Store::lock('connection:'.$i['connection_id'],$save):$save();
    }
    public static function payload(array $p,string $action): array {
        $required=['contract','purpose','record_id','stage_id','action','event_id','occurred_at','eventId','conversion','conversionHappenedAt','user'];
        if(array_diff($required,array_keys($p))||array_diff(array_keys($p),$required)||$p['contract']!==self::CONTRACT||$p['purpose']!==self::PURPOSE||$p['action']!==$action)throw new Fault('payload_invalido','Evento fora do contrato comercial 1.2.0.');
        foreach(['record_id','stage_id','event_id','occurred_at'] as $k)if(!is_string($p[$k]))throw new Fault('payload_invalido','Envelope comercial inválido.');
        if(!preg_match('/^[a-f0-9]{32}$/D',$p['record_id'])||$p['stage_id']===''||mb_strlen($p['stage_id'])>60||preg_match('/[\x00-\x1f]/',$p['stage_id'])||!preg_match('/^f3q-[a-f0-9]{64}$/D',$p['event_id']))throw new Fault('payload_invalido','Identificadores comerciais inválidos.');
        if(!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/D',$p['occurred_at']))throw new Fault('instante_invalido','Informe o instante RFC3339 original da etapa.');
        $date=\DateTimeImmutable::createFromFormat('!Y-m-d\TH:i:sP',$p['occurred_at']);$errors=\DateTimeImmutable::getLastErrors();
        if(!$date||($errors&&($errors['warning_count']||$errors['error_count'])))throw new Fault('instante_invalido','Data comercial inválida.');
        $time=$date->getTimestamp();if($time>time()||$time<time()-7*86400||!is_int($p['conversionHappenedAt'])||$p['conversionHappenedAt']!==$time*1000)throw new Fault('instante_invalido','Preserve o instante da etapa, sem data futura, na janela de sete dias.');
        if(!is_array($p['user'])||array_keys($p['user'])!==['userIds']||!is_array($p['user']['userIds'])||!array_is_list($p['user']['userIds'])||count($p['user']['userIds'])<1)throw new Fault('sem_identificador','Use somente identificadores permitidos, sem dados pessoais em texto.');
        $legacy=array_intersect_key($p,array_flip(['record_id','event_id','eventId','conversion','conversionHappenedAt','user']));$legacy['contract']='site-linkedin-conversion/1.0.0';
        return Conversions::payload($legacy);
    }
    public static function send(array $p,string $ref,string $action): array {
        try {
            if(!preg_match('/^[a-f0-9]{64}$/D',$ref))throw new Fault('destination_binding_required','Informe a referência vinculada.');
            [$g]=self::context($action,$ref);
            // Same order as connection edits and grants. Revocation cannot race a dispatched effect.
            return Store::lock('connection:'.$g['connection_id'],static fn()=>Store::lock('conversion-grant',static fn()=>Conversions::deliver([$p],$ref,null,$action)[0]));
        }catch(Fault $e){return ['status'=>'recusado','code'=>$e->reason,'http'=>0,'non_delivery_proven'=>true];}
        catch(\Throwable $e){return ['status'=>'incerto','code'=>'falha_interna','http'=>0,'non_delivery_proven'=>false];}
    }
}
final class StageConversionDelivery {
    private string $action;
    public function __construct(string $action){StageConversions::key($action);$this->action=$action;}
    public function capabilities(): array {return StageConversions::capabilities($this->action);}
    public function sendBound(array $payload,string $destination_ref): array {return StageConversions::send($payload,$destination_ref,$this->action);}
}
