<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class ConversionSchemas {
    public static function payload(): array {
        $str=static fn($n,$pattern='')=>['type'=>'string','minLength'=>1,'maxLength'=>$n]+($pattern?['pattern'=>$pattern]:[]);
        $id=$str(128,'^[A-Za-z0-9_.:-]+$');
        $info= Schemas::obj(['firstName'=>$str(100),'lastName'=>$str(100),'companyName'=>$str(100),'title'=>$str(100),'countryCode'=>$str(2,'^[A-Z]{2}$')]);
        $user=Schemas::obj(['userIds'=>['type'=>'array','maxItems'=>2,'items'=>Schemas::obj(['idType'=>['type'=>'string','enum'=>['SHA256_EMAIL','LINKEDIN_FIRST_PARTY_ADS_TRACKING_UUID']],'idValue'=>$str(500)],['idType','idValue'])],'userInfo'=>$info]);
        return Schemas::obj(['contract'=>['type'=>'string','enum'=>['site-linkedin-conversion/1.0.0']],'record_id'=>$id,'event_id'=>$id,'eventId'=>$id,'conversion'=>$str(80,'^urn:lla:llaPartnerConversion:[0-9]+$'),'conversionHappenedAt'=>['type'=>'integer','minimum'=>1],'user'=>$user,'conversionValue'=>Schemas::obj(['currencyCode'=>$str(3,'^[A-Z]{3}$'),'amount'=>$str(40,'^[0-9]+(\.[0-9]+)?$')],['currencyCode','amount'])],['contract','record_id','event_id','eventId','conversion','conversionHappenedAt','user']);
    }
    public static function all(): array {
        $id=['type'=>'string','pattern'=>'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$'];$num=['type'=>'string','pattern'=>'^[0-9]{1,40}$'];$hash=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];$rev=['type'=>'integer','minimum'=>0];$bool=['type'=>'boolean'];
        $target=['connection_id'=>$id,'account_id'=>$num];
        $send=['destination_ref'=>$hash,'dry_run'=>$bool,'confirm'=>$bool,'confirm_token'=>$hash];
        return StageConversions::schemas()+[
            'list-conversion-rules'=>Schemas::obj($target+['offset'=>['type'=>'integer','minimum'=>0,'maximum'=>100000]],array_keys($target)),
            'get-conversion-grant'=>Schemas::obj(),
            'get-service-write-operation'=>ServiceAudit::schema(),
            'save-conversion-grant'=>Schemas::obj(['consumer_id'=>['type'=>'string','enum'=>['site-core-conversions']],'expected_revision'=>$rev,'enabled'=>$bool]+$target+['conversion_id'=>$num,'expected_connection_revision'=>$rev],['consumer_id','expected_revision','enabled']),
            'conversion-capabilities'=>Schemas::obj(),
            'diagnose-conversions'=>Schemas::obj(['conversion_id'=>$num]),
            'send-conversion-event'=>Schemas::obj($send+['payload'=>self::payload()],['destination_ref','payload']),
            'send-conversion-events'=>Schemas::obj($send+['payloads'=>['type'=>'array','minItems'=>1,'maxItems'=>100,'items'=>self::payload()]],['destination_ref','payloads'])
        ];
    }
}
