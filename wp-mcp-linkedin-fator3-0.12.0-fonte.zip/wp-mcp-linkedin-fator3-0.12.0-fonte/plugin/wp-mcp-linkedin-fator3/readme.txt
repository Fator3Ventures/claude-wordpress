=== Fator3 MCP LinkedIn ===
Requires at least: 6.4
Requires PHP: 8.1.2
Stable tag: 0.12.0
License: GPL-2.0-or-later

Configure em Ferramentas > Fator3 MCP LinkedIn. Consulte docs/README.md e docs/CONTRACTS.md.
