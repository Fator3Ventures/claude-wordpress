"""Isolated native WordPress tests for the Fator3 social packages.

Requires an explicit dependency manifest (paths + SHA-256); never edits another lab.
Database: a new schema on an existing MySQL server named in the manifest (no shared tables).
WordPress, PHP runtimes and companion installers are external and never nested in the source.

Example:
  python3 tools/lab.py --manifest tools/lab-local.json --workdir /tmp/new-lab --order meta-only
  python3 tools/lab.py --manifest tools/lab-local.json --workdir /tmp/new-lab --order meta-integrated --origin upgrade
  python3 tools/lab.py --manifest tools/lab-local.json --workdir /tmp/new-lab --order meta-only --wordpress wordpress_minimum --php php81
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, uuid, zipfile, re

ROOT = Path(__file__).resolve().parents[1]
PROVIDER = 'meta' if 'meta' in ROOT.name else 'linkedin'
OTHER = 'linkedin' if PROVIDER == 'meta' else 'meta'
VERSION = re.search(r"^VERSION='([0-9]+\.[0-9]+\.[0-9]+)'", (ROOT / 'build/build.py').read_text(), re.M).group(1)
DEFAULT_TESTS = {
    'meta': ['release070-metadata.php', 'release060.php', 'release070.php', 'suite.php', 'mcp-docs070.php'],
    'linkedin': ['suite.php', 'mcp-docs080.php'],
}


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def tree_digest(path):
    h = hashlib.sha256()
    for p in sorted(Path(path).rglob('*')):
        if p.is_file() and not p.is_symlink():
            h.update(p.relative_to(path).as_posix().encode() + b'\0' + bytes.fromhex(digest(p)))
    return h.hexdigest()


def extract_zip(p, target):
    with zipfile.ZipFile(p) as z:
        for x in z.infolist():
            name = Path(x.filename)
            if name.is_absolute() or '..' in name.parts or (x.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Unsafe archive: ' + str(p))
        z.extractall(target)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', required=True, type=Path)
    ap.add_argument('--workdir', required=True, type=Path)
    ap.add_argument('--origin', choices=['clean', 'upgrade'], default='clean')
    ap.add_argument('--order', choices=['meta-only', 'linkedin-only', 'meta-first', 'linkedin-first', 'meta-integrated', 'linkedin-integrated', 'trio-first', 'social-first'], default=PROVIDER + '-only')
    ap.add_argument('--wordpress', default='wordpress', help='manifest key of the WordPress archive')
    ap.add_argument('--php', default='php', help='manifest key of the PHP runtime')
    ap.add_argument('--tests', default='', help='comma-separated files in tests/native (default: release plan)')
    ap.add_argument('--keep', action='store_true', help='keep database after the run')
    ap.add_argument('--candidate', type=Path, help='alternative installer under test (e.g. the base, to prove a defect)')
    a = ap.parse_args()
    inputs = json.loads(a.manifest.read_text())
    paths = {}
    for name, item in inputs.items():
        if 'path' not in item:
            continue
        p = Path(item['path'])
        p = (p if p.is_absolute() else a.manifest.parent / p).resolve()
        if not p.exists():
            raise ValueError('Missing input: ' + name)
        if (tree_digest(p) if p.is_dir() else digest(p)) != item['sha256']:
            raise ValueError('Dependency hash mismatch: ' + name)
        paths[name] = p
    lab = a.workdir.resolve()
    if lab.exists() and any(lab.iterdir()):
        raise ValueError('Workdir must be new/empty')
    lab.mkdir(parents=True, mode=0o700, exist_ok=True)
    identity = uuid.uuid4().hex
    (lab / '.social-lab.json').write_text(json.dumps({'id': identity, 'path': str(lab)}))
    php_item = inputs[a.php]
    env = os.environ.copy()
    if php_item.get('kind') == 'tree':
        rt = paths[a.php]
        php = rt / php_item['binary']
        modules = php_item['extensions']
        (lab / 'php.ini').write_text('extension_dir=' + str(rt / php_item['extension_dir']) + '\n' + ''.join('extension=' + x + '.so\n' for x in modules) + 'memory_limit=1024M\ndate.timezone=UTC\n')
        env['LD_LIBRARY_PATH'] = str(rt / 'usr/lib/x86_64-linux-gnu')
        php_cmd = [str(php), '-c', str(lab / 'php.ini')]
    else:
        php_cmd = [str(paths[a.php]), '-d', 'memory_limit=1024M']
    env.update(F3_LAB_ROOT=str(lab), F3_LAB_ID=identity, F3_LAB_ORIGIN=a.origin, F3_LAB_ORDER=a.order, F3_SOURCE_ROOT=str(ROOT), F3_LAB_VERSION=VERSION, F3_LAB_PHP=json.dumps(php_cmd))

    def run(script):
        return subprocess.run(php_cmd + [str(script)], env=env, check=True)

    extract_zip(paths[a.wordpress], lab)
    wp = lab / 'wordpress'
    plugins = wp / 'wp-content/plugins'
    plugins.mkdir(exist_ok=True, parents=True)
    for d in ['evidence', 'private']:
        (lab / d).mkdir()
    if a.order.endswith('-only') or a.order.endswith('-integrated'):
        selected = [a.order.split('-')[0]]
    else:
        selected = ['meta', 'linkedin'][::-1] if a.order == 'linkedin-first' else ['meta', 'linkedin']
    candidate_dir = ROOT / 'build/dist'
    cand = {PROVIDER: a.candidate.resolve() if a.candidate else candidate_dir / ('wp-mcp-' + PROVIDER + '-fator3-' + VERSION + '-instalador.zip')}
    if a.candidate:
        with zipfile.ZipFile(cand[PROVIDER]) as z:
            head = z.read('wp-mcp-' + PROVIDER + '-fator3/wp-mcp-' + PROVIDER + '-fator3.php')[:4096].decode()
        env['F3_LAB_VERSION'] = re.search(r'Version:\s*([0-9.]+)', head).group(1)
    packages = {}
    for name in selected:
        if name == PROVIDER:
            packages[name] = paths['baseline_' + name] if a.origin == 'upgrade' else cand[name]
        else:
            packages[name] = paths[name]  # companion base of the other social package
    for p in packages.values():
        extract_zip(p, plugins)
    if a.order in ['trio-first', 'social-first', 'meta-integrated', 'linkedin-integrated']:
        for name in ['core', 'mcp', 'google'] + ([OTHER] + (['pipedrive'] if 'pipedrive' in paths else []) if a.order.endswith('-integrated') else []):
            extract_zip(paths[name], plugins)
    companions = {}
    for main in sorted(plugins.glob('*/*.php')):
        m = re.search(r'^[ \t/*#@]*Version:\s*([0-9.]+)', main.read_text(errors='replace')[:8192], re.M)
        if m and main.parent.name != 'wp-mcp-' + PROVIDER + '-fator3' and main.stem == main.parent.name:
            companions[main.parent.name + '/' + main.name] = m.group(1)
    env['F3_LAB_COMPANIONS'] = json.dumps(companions)
    mu = wp / 'wp-content/mu-plugins'
    mu.mkdir(exist_ok=True)
    (mu / 'lab.php').write_text("<?php add_filter('pre_wp_mail',static function($n,$atts){$f=WP_CONTENT_DIR.'/lab-mail.jsonl';file_put_contents($f,wp_json_encode(['to'=>$atts['to']??null,'subject'=>$atts['subject']??null]).\"\\n\",FILE_APPEND);return true;},PHP_INT_MAX,2);add_filter('pre_http_request',static fn($pre)=>$pre!==false?$pre:new WP_Error('lab_network_blocked','Only test fixtures are allowed'),PHP_INT_MAX);\n")
    db = inputs['mysql']
    dbname = 'social_' + identity[:12]
    db['password'] = db.get('password') or os.environ.get(db.get('password_env', 'F3_LAB_DB_PASSWORD'), '')
    mysql = ['mysql', '-h' + db['host'], '-P' + str(db['port']), '-u' + db['user'], '-p' + db['password']]
    subprocess.run(mysql + ['-e', 'CREATE DATABASE `' + dbname + '` CHARACTER SET utf8mb4'], check=True, stderr=subprocess.DEVNULL)
    try:
        config = "<?php define('DB_NAME',%r);define('DB_USER',%r);define('DB_PASSWORD',%r);define('DB_HOST',%r);define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');$table_prefix='wp_';define('DISABLE_WP_CRON',true);define('WP_DEBUG',true);define('WP_DEBUG_LOG',true);define('WP_DEBUG_DISPLAY',false);define('FS_METHOD','direct');define('F3_MCP_PRIVATE_ROOT',%r);\n" % (dbname, db['user'], db['password'], db['host'] + ':' + str(db['port']), str(lab / 'private'))
        config += ''.join("define('%s','%s');\n" % (k, os.urandom(32).hex()) for k in ['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT'])
        config += "\nif(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';"
        (wp / 'wp-config.php').write_text(config)
        (wp / 'wp-config.php').chmod(0o600)
        run(ROOT / 'tests/native/init.php')
        if a.origin == 'upgrade':
            run(ROOT / 'tests/native/seed.php')
            path = plugins / ('wp-mcp-' + PROVIDER + '-fator3')
            shutil.rmtree(path)
            extract_zip(cand[PROVIDER], plugins)
        tests = [t for t in (a.tests.split(',') if a.tests else DEFAULT_TESTS[PROVIDER]) if t]
        results = {}
        for t in tests:
            results[t] = subprocess.run(php_cmd + [str(ROOT / 'tests/native' / t)], env=env).returncode
        inventory = {}
        archive = cand[PROVIDER]
        slug = 'wp-mcp-' + PROVIDER + '-fator3'
        if PROVIDER in selected:
            with zipfile.ZipFile(archive) as z:
                expected = {n: hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
            actual = {p.relative_to(plugins).as_posix(): digest(p) for p in (plugins / slug).rglob('*') if p.is_file()}
            inventory[PROVIDER] = {'sha256': digest(archive), 'files': len(actual), 'exact': expected == actual}
        log = wp / 'wp-content/debug.log'
        lines = log.read_text(errors='replace').splitlines() if log.exists() else []
        own = [l for l in lines if re.search(r'PHP (Notice|Warning|Deprecated|Fatal|Parse)', l) and ('wp-mcp-' + PROVIDER + '-fator3' in l or ('wp-mcp-' + OTHER + '-fator3' in l and OTHER in selected))]
        foreign = [l for l in lines if re.search(r'PHP (Notice|Warning|Deprecated|Fatal|Parse)', l) and l not in own]
        env_report = {'origin': a.origin, 'order': a.order, 'wordpress_key': a.wordpress, 'php_key': a.php, 'tests': results, 'inputs': {k: v for k, v in inputs.items() if k != 'mysql'}, 'packages': inventory, 'companions': companions,
                      'runtime': subprocess.run(php_cmd + ['-v'], env=env, capture_output=True, text=True).stdout.splitlines()[0],
                      'wordpress_version': re.search(r"wp_version = '([^']+)'", (wp / 'wp-includes/version.php').read_text()).group(1),
                      'debug_log': {'own_package_entries': own, 'other_entries_unique': sorted(set(re.sub(r'^\[[^]]*\] ', '', l)[:300] for l in foreign))}}
        (lab / 'evidence/environment.json').write_text(json.dumps(env_report, indent=2, ensure_ascii=False))
        print(json.dumps({'tests': results, 'exact_install': inventory.get(PROVIDER, {}).get('exact'), 'own_log_entries': len(own), 'other_log_entries': len(env_report['debug_log']['other_entries_unique']), 'wordpress': env_report['wordpress_version'], 'php': env_report['runtime'][:20]}))
        if any(results.values()) or own or (PROVIDER in selected and not inventory[PROVIDER]['exact']):
            raise SystemExit(1)
    finally:
        if not a.keep:
            subprocess.run(mysql + ['-e', 'DROP DATABASE IF EXISTS `' + dbname + '`'], stderr=subprocess.DEVNULL)
        (lab / '.social-lab.json').write_text(json.dumps({'id': identity, 'path': str(lab), 'stopped': True, 'database': dbname if a.keep else None}))


if __name__ == '__main__':
    main()
