<?php
/** Temporary Site-Teste callback. Never part of the installable plugin. */
declare(strict_types=1);
defined('ABSPATH')||exit;
function f3_linkedin_081_acceptance(): array {
 $ns='Fator3\\LinkedIn\\';$config=$ns.'Config';$store=$ns.'Store';$api=$ns.'Api';$conv=$ns.'Conversions';$connections=$ns.'Connections';
 if(!current_user_can('manage_options')||!class_exists($config)||$config::VERSION!=='0.8.1')return ['success'=>false,'code'=>'wrong_context'];
 if($store::list('job',0,1)||$store::list('schedule',0,1)||$store::list('connection',0,1)||$store::get('conversion_grant','site-core-conversions'))return ['success'=>false,'code'=>'requires_empty_linkedin_configuration'];
 $serviceEvents=[];$captureService=static function($event)use(&$serviceEvents){$serviceEvents[]=$event;};add_action('f3_linkedin_service_mutation_recorded',$captureService);
 $prefix='qa081-'.bin2hex(random_bytes(6));$checks=[];$previews=[];$operations=[];$mode='normal';$posts=0;$blocked=0;$failure=null;$ownJobs=[];$ownSchedules=[];$workerBefore=wp_next_scheduled('f3_linkedin_worker');$trackedOptions=['f3_linkedin_worker_schedule_attempt','f3_linkedin_worker_schedule_failure'];$savedOptions=[];foreach($trackedOptions as $k)$savedOptions[$k]=get_option($k,null);
 $response=static fn($body,$status=200)=>['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>$status,'message'=>'Synthetic fixture'],'cookies'=>[]];
 $http=static function($pre,$args,$url)use(&$mode,&$posts,&$blocked,$response){
  $path=parse_url($url,PHP_URL_PATH);$method=$args['method']??'GET';
  if(str_ends_with($path,'/introspectToken'))return $response(['active'=>true,'client_id'=>'qa-app','scope'=>$mode==='deny'?'r_ads':'rw_conversions,r_ads','expires_at'=>time()+7200]);
  if($path==='/rest/adAccountUsers')return $response(['elements'=>[['account'=>'urn:li:sponsoredAccount:222','role'=>'ACCOUNT_MANAGER']],'paging'=>['start'=>0,'total'=>1]]);
  $rule=['id'=>67890,'account'=>'urn:li:sponsoredAccount:222','enabled'=>true,'conversionMethod'=>'CONVERSIONS_API','name'=>'Regra de teste sintética'];
  if($path==='/rest/conversions')return $response(['elements'=>[$rule],'paging'=>['start'=>0,'total'=>1]]);
  if($path==='/rest/conversions/67890')return $response($rule);
  if(str_starts_with((string)$path,'/rest/networkSizes/')){parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);return ($q['edgeType']??'')==='COMPANY_FOLLOWED_BY_MEMBER'?$response(['firstDegreeSize'=>4321]):$response([],400);}
  if($path==='/rest/conversionEvents'&&$method==='POST'){$posts++;$body=json_decode($args['body'],true);if(isset($body['record_id'],$body['contract']))return $response([],400);if($mode==='timeout')return new WP_Error('synthetic_timeout','No receipt');return $response([],201);}
  $blocked++;return new WP_Error('qa_network_blocked','No real network allowed in acceptance callback');
 };
 $mail=static fn()=>true;$call=static function($op,$i=[])use($api){$r=$api::dispatch($op,$i);if(!$r['success'])throw new RuntimeException($op.':'.$r['code']);return $r['data'];};
 $assert=static function($ok,$name)use(&$checks){if(!$ok)throw new RuntimeException($name);$checks[]=['name'=>$name,'passed'=>true];};
 add_filter('pre_http_request',$http,-10000,3);add_filter('pre_wp_mail',$mail,-10000);
 try {
  $call('save-connection',['connection_id'=>$prefix,'expected_revision'=>0,'token'=>'synthetic-qa-token','client_id'=>'qa-app','client_secret'=>'synthetic-qa-secret','expires_at'=>time()+86400,'assets'=>['ads'=>['222'],'pages'=>['111']]]);
  $g=['consumer_id'=>'site-core-conversions','expected_revision'=>0,'enabled'=>true,'connection_id'=>$prefix,'account_id'=>'222','conversion_id'=>'67890','expected_connection_revision'=>$connections::get($prefix)['revision']];
  $mode='deny';$r=$api::dispatch('save-conversion-grant',$g);$assert(!$r['success']&&$r['code']==='sem_escopo'&&$posts===0,'Escopo ausente recusa antes de qualquer evento');$mode='normal';
  $g=$call('save-conversion-grant',$g);$cap=$conv::capabilities();$assert($cap['ready']&&$cap['conversion_id']==='67890','Concessão explícita e capabilities local');
  $p=['contract'=>'site-linkedin-conversion/1.0.0','record_id'=>$prefix.'-record','event_id'=>$prefix.'-event','eventId'=>$prefix.'-event','conversion'=>'urn:lla:llaPartnerConversion:67890','conversionHappenedAt'=>time()*1000,'user'=>['userIds'=>[['idType'=>'SHA256_EMAIL','idValue'=>str_repeat('a',64)]]]];
  $i=['destination_ref'=>$g['destination_ref'],'payload'=>$p];$prev=$call('send-conversion-event',$i);$previews[]=hash('sha256',$prev['confirm_token']);$assert($prev['dry_run']&&$posts===0&&!str_contains(wp_json_encode($prev),str_repeat('a',64)),'Prévia sem evento nem identificação pessoal');
  $r=wp_get_ability('linkedin/send-conversion-event')->execute($i+['dry_run'=>false,'confirm'=>true,'confirm_token'=>$prev['confirm_token']]);$assert($r['success']&&$r['data']['status']==='entregue'&&$posts===1,'Escrita MCP simulada com aceite HTTP');$id=$r['data']['operation_id'];$operations[]=$id;
  $audit=wp_get_ability('audit/get-operation')->execute(['provider'=>$config::SLUG,'operation_id'=>$id]);$assert($audit['success']&&str_contains(wp_json_encode($audit),'nao_enviado')&&!str_contains(wp_json_encode($audit),str_repeat('a',64)),'Registro central lê antes/depois sem PII');
  $panel=static function($input)use($config){$request=new WP_REST_Request('POST','/'.$config::REST.'/send-conversion-event');$request->set_header('Content-Type','application/json');$request->set_body(wp_json_encode($input));return rest_do_request($request)->get_data();};
  $p['event_id']=$p['eventId']=$prefix.'-panel';$i=['destination_ref'=>$g['destination_ref'],'payload'=>$p];$prev=$panel($i);if(empty($prev['success']))throw new RuntimeException('Panel preview refused');$previews[]=hash('sha256',$prev['data']['confirm_token']);
  $r=$panel($i+['dry_run'=>false,'confirm'=>true,'confirm_token'=>$prev['data']['confirm_token']]);$assert($r['success']&&$r['data']['status']==='entregue'&&$posts===2,'Rota administrativa do painel confirma escrita simulada');$id=$r['data']['operation_id'];$operations[]=$id;
  $audit=wp_get_ability('audit/get-operation')->execute(['provider'=>$config::SLUG,'operation_id'=>$id]);$assert($audit['success']&&str_contains(wp_json_encode($audit),'nao_enviado')&&!str_contains(wp_json_encode($audit),str_repeat('a',64)),'Registro central lê antes/depois da rota do painel sem PII');
  $mode='timeout';$p['event_id']=$p['eventId']=$prefix.'-unknown';$actor=get_current_user_id();wp_set_current_user(0);try{$r=$conv::sendBound($p,$g['destination_ref']);$assert(get_current_user_id()===0,'Serviço conserva usuário zero');}finally{wp_set_current_user($actor);}$operations[]=$r['operation_id'];$n=$posts;$again=$conv::sendBound($p,$g['destination_ref']);$assert($r['status']==='incerto'&&$again['replayed']&&$posts===$n,'SDK conserva incerteza e impede reenvio');$mode='normal';
  $assert($r['central_audit']==='recorded','MCP 0.28 confirma persistência central de serviço');
  $identity=$store::get('conversion_event',$r['operation_id'])['value']['service_identity'];$proof=f3_linkedin_introspect_service_grant($identity);$assert($proof['valid']&&count($serviceEvents)===1,'Introspector público valida evento de serviço persistido');
  $read=wp_get_ability('linkedin/get-service-write-operation')->execute($identity);$assert(!is_wp_error($read)&&$read['success']&&$read['data']['principal_type']==='service'&&$read['data']['after']===null,'Leitor público mostra snapshot técnico incerto');
  $central=wp_get_ability('audit/get-service-operation')->execute($identity);$assert(!is_wp_error($central)&&!empty($central['success'])&&str_contains(wp_json_encode($central),'service'),'Leitor central de serviço confirma detalhe atual');
  $clean=wp_json_encode([$serviceEvents,$proof,$read,$central]);$assert(!str_contains($clean,str_repeat('a',64))&&!str_contains($clean,'synthetic-qa-token')&&!str_contains($clean,'userIds'),'Evento e leitura sem payload ou identificador pessoal');
  $bad=$identity;$bad['grant_revision']=str_repeat('f',64);$assert(!f3_linkedin_introspect_service_grant($bad)['valid'],'Revisão divergente falha fechada');
  $r=$call('query',['connection_id'=>$prefix,'channel'=>'pages','account_id'=>'111','report'=>'follower_total']);$assert($r['rows'][0]['firstDegreeSize']===4321,'Total de seguidores usa enum atual');
  $assert(\Fator3\LinkedIn\CentralAudit::status()==='registered','Descritor explícito admitido pelo MCP vigente');

  // Independent patch checks: only synthetic records owned by this callback.
  global $wpdb;$t=$store::table();$proofRow=$store::get('token_proof',$prefix);$v=$proofRow['value'];$v['expires_at']=time()-1;$store::put('token_proof',$prefix,$v,$proofRow['revision']);
  $d=$conv::diagnose([]);$c=$conv::capabilities();$by=array_column($d['checks'],null,'id');$assert(!$d['ready']&&!$c['ready']&&$by['token_proof_valid']['code']==='token_expired','R3 prova expirada bloqueia prontidão local');
  $now=$store::get('token_proof',$prefix);$store::put('token_proof',$prefix,$proofRow['value'],$now['revision']);
  $badJob=$prefix.'-bad';$ownJobs[]=$badJob;$payload='s1.'.base64_encode(random_bytes(80));$wpdb->insert($t,['bucket'=>'job','record_key'=>$badJob,'revision'=>7,'payload'=>$payload,'updated_at'=>time(),'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
  try{\Fator3\LinkedIn\Jobs::run($badJob,true);throw new RuntimeException('Expected unreadable');}catch(\Fator3\LinkedIn\Fault $e){$assert($e->reason==='cipher_unreadable','R1 erro de cifra permanece explícito');}
  $row=$wpdb->get_row($wpdb->prepare("SELECT queue_state,payload,revision FROM %i WHERE bucket='job' AND record_key=%s",$t,$badJob),ARRAY_A);$assert($row['queue_state']==='unreadable'&&$row['payload']===$payload&&(int)$row['revision']===7,'R1 isolamento preserva registro cifrado e revisão');
  $sid=$prefix.'-agenda';$ownSchedules[]=$sid;\Fator3\LinkedIn\Schedules::save(['schedule_id'=>$sid,'expected_revision'=>0,'query'=>['connection_id'=>$prefix,'channel'=>'pages','account_id'=>'111','report'=>'organization'],'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()+3600]);
  $r=$store::get('schedule',$sid);$v=$r['value'];$v['last_job']=$badJob;$store::put('schedule',$sid,$v,$r['revision']);$h=\Fator3\LinkedIn\Worker::health();$assert($h['state']==='degraded'&&in_array('schedule_job_unreadable',array_column($h['issues'],'code'),true),'R2 diagnóstico sobrevive ao último job ilegível');
  $r=$store::get('schedule',$sid);$v=$r['value'];$v['connection_revision']=-1;$v['next_at']=time()-1;$v['last_job']=null;$store::put('schedule',$sid,$v,$r['revision']);\Fator3\LinkedIn\Schedules::tick();$r=$store::get('schedule',$sid);$h=\Fator3\LinkedIn\Worker::health();$assert(!$r['value']['enabled']&&in_array('schedule_authorization_failed',array_column($h['issues'],'code'),true),'R4 agenda pausada por revisão divergente continua visível');

  $grant=$conv::grant();$call('save-conversion-grant',['consumer_id'=>'site-core-conversions','expected_revision'=>$grant['revision'],'enabled'=>false]);$assert(!f3_linkedin_introspect_service_grant($identity)['valid']&&$store::get('conversion_event',$rServiceId=$identity['operation_id'])!==null,'Revogação bloqueia detalhe e conserva diário');
  $centralAfter=wp_get_ability('audit/get-service-operation')->execute($identity);$assert(!is_wp_error($centralAfter)&&empty($centralAfter['success'])&&!isset($centralAfter['before'],$centralAfter['after']), 'Revogação não entrega snapshot central antigo');
  $assert($blocked===0,'Nenhuma chamada de rede real');
 }catch(Throwable $e){$failure=$e instanceof \Fator3\LinkedIn\Fault?$e->reason:$e->getMessage();}
 finally {
  global $wpdb;foreach($ownJobs as $id)$wpdb->delete($store::table(),['bucket'=>'job','record_key'=>$id]);foreach($ownSchedules as $id)$wpdb->delete($store::table(),['bucket'=>'schedule','record_key'=>$id]);
  if(!$workerBefore)wp_clear_scheduled_hook('f3_linkedin_worker');foreach($savedOptions as $k=>$value){if($value===null)delete_option($k);else update_option($k,$value,false);}
  remove_action('f3_linkedin_service_mutation_recorded',$captureService);
  remove_filter('pre_http_request',$http,-10000);remove_filter('pre_wp_mail',$mail,-10000);
  foreach(['connection','token_proof','credential','credential_health'] as $bucket){$r=$store::get($bucket,$prefix);if($r)$store::remove($bucket,$prefix,$r['revision']);}
  $g=$store::get('conversion_grant','site-core-conversions');if($g&&($g['value']['connection_id']??'')===$prefix)$store::remove('conversion_grant','site-core-conversions',$g['revision']);
  foreach($previews as $key){$r=$store::get('conversion_preview',$key);if($r)$store::remove('conversion_preview',$key,$r['revision']);}
  foreach($operations as $key){$r=$store::get('conversion_event',$key);if($r&&$r['value']['connection_id']===$prefix)$store::remove('conversion_event',$key,$r['revision']);}
 }
 return ['success'=>$failure===null,'version'=>$config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'failure'=>$failure,'synthetic_posts'=>$posts,'real_provider_calls'=>0,'configuration_remaining'=>count($store::list('connection',0,100)),'jobs_remaining'=>count($store::list('job',0,100)),'schedules_remaining'=>count($store::list('schedule',0,100)),'audit_references_retained'=>true,'operation_ids'=>$operations];
}
add_action('wp_abilities_api_init',static function(){wp_register_ability('linkedin-qa/run-081',['label'=>'LinkedIn: executar aceite sintético da versão','description'=>'Valida CAPI, diário, Registro e seguidores com rede interceptada, sem credenciais reais e somente com configuração LinkedIn vazia; remove os dados próprios.','category'=>'linkedin','input_schema'=>['type'=>'object','properties'=>[],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'f3_linkedin_081_acceptance','meta'=>['mcp'=>['public'=>true],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false]]]);},40);
