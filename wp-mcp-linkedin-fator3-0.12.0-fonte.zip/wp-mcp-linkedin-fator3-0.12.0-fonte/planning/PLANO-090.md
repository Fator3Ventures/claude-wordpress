# Plano — Fator3 MCP LinkedIn 0.9.0

## Registro pré-implementação

23/10/2026 · implementação de nova rodada · Base 0.8.1, SHA-256 172081883af66b8c4b61676396d85066d4be0778b7ca06fb22262b30a4d2374a. Alvo 0.9.0 pelo incremento minor padrão. Instalador-alvo ainda não gerado.

Pedido MCP LinkedIn 12: reproduzir corrida nas rotas Queue::migrate e Store::prune; evitar isolamento baseado em leitura antiga. Referência: impacto Meta 0.7.1 revisão 3 e testes review071.php; o código será adaptado ao domínio e verificado independentemente. Base aceita do pedido confirma 0.8.1 na frota; somente o Site-Teste integra o escopo de instalação desta rodada.

Proposta: centralizar isolamento numa função que relê o registro sob job:<id>, valida o mesmo ciphertext lido e executa UPDATE condicionado à revisão e aos bytes exatos. Worker, migração e retenção usam a mesma guarda. Erros SQL propagam sem isolamento; trava ocupada mantém o registro para passagem futura. Preservar payload, revisão, timestamps, retenção, schema 2 e contratos públicos.

Testes previstos: injetar escrita de outra conexão MySQL entre leitura e UPDATE em migração e retenção; revisão nova legível preservada; mudança de payload sem incremento de revisão também protegida; concorrência na trava; falhas reais SQL controladas; snapshot exato; fila e resultado filho; banco/schema, configuração, autorização e documentação na atualização direta 0.8.1→0.9.0. Instalação limpa isolada e integrada com Core 1.49.1/MCP 0.29.1/Google 0.18.1/Meta 0.7.1; mínimo WP6.4/PHP8.1.2. Chamadas comerciais interceptadas.

Impactos avaliados antes da implementação: alteração interna à fila do LinkedIn, sem SDK, schema, opções ou nova necessidade de adaptação nos acompanhantes. Nenhum novo impacto individual de simples aviso será emitido. O impacto recebido do MCP 0.29.1 mantém retry conservador; não acrescentar applied=false por suposição. R1/R2 do alerta emitido ao Meta na 0.8.1 foram atendidos segundo a revisão 3 recebida; atualizar somente esse encaminhamento próprio com seu desfecho, preservando emissor/identidade histórica. Resposta ao pedido 12 e prova do LinkedIn serão registradas no relatório próprio. Originais do Core/MCP/Meta/Google e a aba central de pedidos ficam intactos.


## Entrega e desfecho

0.9.0 implementada e validada sobre a 0.8.1. Pedido 12 atendido nas provas próprias de `evidence/release090/`. Matriz local: 729 verificações aprovadas, duas não aplicáveis no mínimo, zero falhas. Site-Teste: 18 casos novos aprovados, oito selftests, 81 operações e 25 documentos lidos integralmente em 32 páginas. Instalador congelado: 236277 bytes, SHA-256 `d4857927ebacfca9321b79d13bc15f15c6969ae67047fd1793e509524b7a60f8`.

Nenhum contrato ou acompanhante precisou ser alterado. Encaminhamento próprio LinkedIn 0.8.1 → Meta encerrado na revisão 2 pela resposta recebida do responsável; originais recebidos e lista central de pedidos preservados. Homologação comercial e frota permanecem fora desta execução, nos limites do relatório.
