# Revisão independente — LinkedIn 0.8.0 → 0.8.1

23/10/2026 · planejamento · patch autorizado expressamente pelo dono nesta rodada.

Base imutável: instalador 0.8.0, 227651 bytes, SHA-256 035a84fea5a02480c933c626cda994c49e58649ab4fb192f90b1f526238e8c35; fonte aa3b79a7a7c5e502007c0b49e1b729b6ec76fed3443decb2ee04d14730ec0d52. Alvo previsto 0.8.1, instalador ainda não gerado.

Reprodução própria em WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46: 127 checagens existentes aprovadas, quatro novas reprovadas na base exata.

1. R1: vinte coletas indexadas ilegíveis permanecem nas primeiras posições em todas as passagens e impedem uma coleta válida de avançar. Isolar sob a trava da própria coleta, alterando somente a projeção técnica e preservando payload/revisão/datas/retenção.
2. R2: status falha inteiramente se a última coleta de uma agenda ativa estiver ilegível. Expor issue sanitizada sem gravação/reparo.
3. R3: prova local vigente de token já vencida é ignorada na prontidão CAPI. Conferir expiração e atividade da prova existente tanto no diagnóstico quanto em capabilities; preservar verificação remota obrigatória antes do envio.
4. R4: erro de autorização desabilita a agenda e o novo diagnóstico a exclui antes de observar o erro. Conservar aviso da autorização mesmo desabilitada, sem reativar.

Fronteiras: SDKs, eventos e recibos humanos/de serviço não mudam. O Core passa a receber ready=false quando a prova vigente conhecida venceu; precisa revalidar credencial, não trocar payload/IDs. MCP continua com o contrato de serviço implementado desde a 0.28.0; confirmar integração real em laboratório/Site-Teste. A documentação de impacto recebida será atualizada explicitamente pela revisão do destinatário, preservando autoria/histórico, conforme pedido do dono. Código comum foi copiado de Meta, mas os builds são independentes; avaliar a presença de R1 no Meta recebido antes de emitir alerta, sem modificar o pacote alheio.

Validação prevista: regressões falham na base e passam no patch, instalação limpa isolada/integrada, atualização 0.8.0→0.8.1 e salto do Site-Teste 0.7.0→patch com preservação, leitura integral documental MCP, permissões, auditoria de serviço com MCP real e envio simulado. Fornecedor real e distribuição da frota fora do teste.

## Encerramento da revisão

Alvo implementado 0.8.1, instalador 232544 bytes, SHA-256 172081883af66b8c4b61676396d85066d4be0778b7ca06fb22262b30a4d2374a. Os quatro achados foram corrigidos; sete casos adicionais protegem comportamento e limites. Instalação limpa, duas origens de atualização, mínimo e Site-Teste concluídos. Impactos Core/MCP atualizados na revisão 3; alerta ao Meta emitido após inspeção estática de R1/R2. Relatório/evidence/review081 distinguem provas próprias, herdadas e pendências. Nenhum pacote alheio foi alterado.
