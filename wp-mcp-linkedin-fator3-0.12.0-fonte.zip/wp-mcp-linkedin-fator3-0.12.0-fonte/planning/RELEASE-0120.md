# Plano — Fator3 MCP LinkedIn 0.12.0

28/10/2026, America/Sao_Paulo. Base aceita 0.11.0, instalador SHA-256 `34541afa67c0991e9dc0b5474ab8678dff8cf806eace6ceb1edb47983f9e0308`. Alvo previsto 0.12.0, ainda não gerado. Pedido: impacto Core 1.58.0 → LinkedIn, revisão 2, Core 323; não há número novo de pedido LinkedIn. Aplicam-se as normas revisão 5 recebidas nos fontes atuais.

## Escopo e fronteiras

Implementar a seleção opcional `site-conversion-delivery/1.2.0`, consumidor `site-core-quality`, finalidade `crm_stage`, ação numérica explícita. Preservar 1.0.0 e a concessão de aquisição. Core mantém etapas, consentimento, elegibilidade, fila e recibos comerciais; LinkedIn mantém credenciais, regras/concessões, transporte e diário técnico.

Concessões por ação no bucket próprio existente, desligadas até configuração administrativa, com revisão e simulação. Provar conta, escopos e regra API de cada ação. Não derivar autorização comercial da aquisição. Recusar a mesma ação da concessão de aquisição e impedir a sobreposição inversa. A configuração do ID de aquisição Core continua sendo conferida pelo consumidor público, sem ler opções privadas do Core.

Capabilities locais sem HTTP e referências vinculadas à ação, conta, identidade e geração da concessão/autorização. Envio com schema fechado, instante coerente e janela de sete dias, IDs elegíveis, identidade do evento preservada. Revalidar contexto antes do efeito e serializar a alteração das concessões/conexão durante o despacho. Nenhuma escolha alternativa de destino.

Reutilizar transporte/jornal/idempotência conservadora, mantendo estado incerto após falha sem prova. Ampliar auditoria de serviço para reconhecer o consumidor comercial e sua concessão exata, preservando leitores antigos. Troca de identidade invalida referências comerciais; edição benigna conserva a autorização sem ampliar seus ativos.

Painel e MCP: listagem, prévia, concessão/revogação e diagnóstico por ação. Guia próprio, schema de payload e exemplos instalados. Sem alteração de Core/MCP/Google/Meta/Pipedrive ou da regra central.

## Impactos recebidos e emissões

O contrato solicitado já está especificado e consumido pelo Core 1.58.0. Seu atendimento será respondido no relatório principal, sem reemitir impacto de encerramento. Até aqui não há consequência nova que exija mudança de outro mantenedor. Caso o teste integrado revele uma incompatibilidade concreta, emitir o encaminhamento antes de consolidar a fronteira afetada. A extensão do consumidor da auditoria usa o contrato MCP vigente.

Pacotes considerados: Core 1.58.0, MCP 0.34.0, Google 0.21.0, Meta 0.13.0, Pipedrive 0.3.0. No Site-Teste, Core ainda 1.57.1, demais nas versões recebidas, LinkedIn 0.11.0, zero conexões. Só LinkedIn será atualizado por esta tarefa; não instalar o Core por inferência.

## Provas e entrega

WordPress real: limpa isolada, integrada com Core real, upgrade direto 0.11.0 e mínimo WP6.4/PHP8.1.2. Testar duas ações, aquisições preservadas, referências trocadas/revogadas, identidade, escopos, papel, regra, conta, consentimento/janela/identificador no consumidor, prévia sem fila/HTTP, deduplicação evento/regra, confirmação 201, erro 4xx provado, 5xx/timeout incerto sem reenvio, falha de persistência, auditoria de serviço e permissões MCP/REST/painel. Fornecedor e e-mail interceptados; sem efeito comercial real.

Site-Teste: somente instalação do LinkedIn com hash/pré-imagem e uma operação por vez; leitura de prontidão, schema, capabilities e todos os documentos. Nenhum helper/MU-plugin remoto; não repetir o auxiliar recusado em rodada anterior. Sem credenciais, aceite real permanece pendente.

Fechar instalador, comprovar runtime idêntico/reprodução, fonte com código/testes/evidências e relatório interno anterior ao fechamento, relatório externo com bytes/hashes finais. Três artefatos; nenhum push/distribuição/frota/mensagem externa.

## Achado durante a integração
MCP 0.34.0 limita o schema de identidade de serviço a site-core-conversions. Emitido impacto substantivo próprio em impacts/wp-mcp-linkedin-fator3-0.12.0-impacto-wp-mcp-fator3.md antes de fechar a implementação. O diário local e o contrato Core funcionam; não simular confirmação central. Nenhum arquivo MCP foi alterado.

## Fechamento

Implementação concluída na 0.12.0, aquisição preservada e consumidor Core 1.58.0 exercitado. Cinco matrizes finais, 989 execuções funcionais aprovadas, oito não aplicáveis, 96 documentais e 26 DOM. Instalador 304948 bytes, SHA-256 19748e788190f371809db469a6de052a645e25f39fad1672606dc776234ec54c, reproduzido exatamente.

Somente LinkedIn aplicado no Site-Teste. Status ok e selftest 9/9; 31 documentos lidos integralmente pelo MCP e comparados ao instalador. Core remoto permanece 1.57.1. Pendências: implantação Core 1.58.0 pelo mantenedor, admissão de site-core-quality na auditoria central MCP, homologação real do fornecedor e inspeção visual. Resposta ao impacto recebido e evidências finais constam no relatório principal. O impacto próprio ao MCP permanece aberto; não se declara concluído trabalho alheio.
