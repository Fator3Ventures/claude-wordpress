# Plano da versão 0.10.0 — Pedido MCP LinkedIn 13

23/10/2026. Base aceita: 0.9.0. Pacotes considerados: Core 1.50.0, MCP 0.29.1, Meta 0.8.0 e Google 0.19.0. Documentos recebidos permanecem intactos.

## Implementação

1. Validar formato dos campos enviados e conferir a tupla candidata por introspecção antes de persistir. Exigir os quatro escopos de leitura, Client ID confirmado e expiração futura. A renovação e o callback OAuth passam pela mesma verificação.
2. Guardar comprovação ligada à credencial, sem exportar segredos. A introspecção não fornece membro ou nome do aplicativo. Consultar userinfo somente com openid/profile já autorizados; marcar nomes declarados e identidade desconhecida explicitamente. Não inferir identidade pelo rótulo.
3. Estender save-connection com simulação e confirmação vinculadas ao administrador, revisão, candidata e agendas/concessões exibidas. Nova identidade ou identidade não comprovável exige esse caminho. A confirmação repete a conferência. Reconfirmar concessões ativas de Lead Sync e CAPI explicitamente na mesma tela.
4. Separar revisão de autorização e geração de credencial. Regravar agendas vinculadas no mesmo commit da conexão; preservar seleção e registrar histórico limitado. Não reativar concessões antigas conflitantes nem transferir silenciosamente trabalhos em execução. Alterações de seleção continuam exigindo revisão de concessões.
5. Proteger conexão, agendas e concessões com travas e transação InnoDB. Falha de CAS/persistência desfaz o conjunto. Nenhuma chamada externa ocorre dentro da transação.
6. Atualizar somente código/documentação do LinkedIn, gerar catálogo e conferir documentação instalada. Sem novo contrato do Core/MCP, sem edição de pedidos ou impactos recebidos. Emitir impacto apenas se surgir adaptação obrigatória em outro pacote.

## Validação e fechamento

Testes negativos de formato, fornecedor, escopos, identidade, prévia adulterada/expirada e revisão; testes de continuidade das agendas e concessões; rollback de persistência e concorrência; renovação; testes DOM da tela; regressões anteriores e convivência com os pacotes atuais em WordPress real, mínimos declarados e atualização sobre 0.9.0. Conferir Site-Teste antes/depois, atualizar somente LinkedIn e executar QA isolado sem credenciais comerciais.

Congelar instalador validado, atualizar runtime do fonte, gerar fonte sem ZIP aninhado e relatório externo final com hashes. Relatório interno anterior ao fechamento evita hash circular. Não distribuir à frota nem publicar em git nesta rodada.

## Limites documentados

API oficial: https://learn.microsoft.com/en-us/linkedin/shared/authentication/token-introspection e https://learn.microsoft.com/en-us/linkedin/consumer/integrations/self-serve/sign-in-with-linkedin-v2 (consultadas em 23/10/2026). O mínimo de cem caracteres é a política solicitada pelo dono. Fixtures comprovam comportamento do plugin, não aceitação de credenciais reais pelo LinkedIn.

## Fechamento em 0.10.1

Após aplicar 0.10.0 no Site-Teste, a revisão final detectou que Refresh Token manual de outro membro poderia renovar sem identidade legível. Corrigido em patch 0.10.1, com candidata e confirmação quando a continuidade não é comprovada e remoção atômica da sobreposição antiga. Meta avançou de 0.8.0 para 0.9.0 por outra operação durante o fechamento; a matriz local usa o ZIP recebido 0.8.0 e a convivência final no Site-Teste observa 0.9.0. O auxiliar remoto isolado foi bloqueado pela revisão automática de aprovação; não foi gravado nem contornado. Testes locais, operações públicas existentes, sondas e leitura documental completam a verificação possível.
