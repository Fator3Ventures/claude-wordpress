# Plano — Fator3 MCP LinkedIn 0.11.0

26/10/2026, America/Sao_Paulo. Base aceita 0.10.1, SHA-256 do instalador `6182ea63bff6788f5d2637467e7ab29d58568e37283d6ece82d3e58ee41c13bc`. Pedido MCP LinkedIn 14 (a–d). Norma comum revisão 5 recebida nos fontes atuais prevalece sobre a cópia avulsa revisão 4. Documentos centrais e dos acompanhantes permanecem intactos.

## Implementação

1. Auditoria local configurável por painel/MCP, padrão unlimited, revisão otimista e prévia. Proteger eventos existentes antes da manutenção. Tokens, confirmações e capacidades temporárias mantêm vencimento de segurança.
2. Conexões novas usam unlimited; existentes preservam finite/retention_days, inclusive os 3.650 dias explicitamente salvos. Resultados e jobs respeitam a política da conexão. Histórico analítico tem retenção independente sem prazo.
3. Acervo cifrado e indexado por principal/conexão/ativo/data/relatório/dimensão/métrica. Ingestão idempotente de páginas persistidas antes do checkpoint; observação mais recente sem zeros inventados. Datas vêm da resposta: snapshots/agregados mensais não viram séries diárias. Leitura exige administrador, autorização atual e ativo selecionado; cursores vinculados à seleção e geração do acervo.
4. Backfill pela fila existente, com período congelado, limites por relatório, paginação, retomada e cobertura. Página: seguidores, visualizações e publicações; Ads: campanha, criativo e conversão. CSV/JSON autenticados em partes; sem URL pública.
5. Migração das páginas legadas em lotes sem exclusão no upgrade. Preservar páginas bloqueadas/ilegíveis para revisão. Tabela histórica própria, sem alterar o schema 2 dos registros existentes. Versão antiga não entende unlimited nem lê o acervo novo: documentar reversão.

## Fronteiras e impactos

Core 1.56.0, MCP 0.33.0, Meta 0.12.0, Pipedrive 0.1.0 recebidos; Google 0.19.0 observado no Site-Teste e recuperado. Não foi identificada mudança de contrato que exija alteração de outro mantenedor. O catálogo MCP descobre as operações próprias. Histórico não ingere contatos nem modifica Lead Sync, CAPI ou mensagens. Nenhum impacto apenas para anunciar versão ou responder a encaminhamento.

Impactos antigos pertinentes: MCP 0.29.1 (idempotência conservadora), Meta 0.7.1 (isolamento concorrente de jobs) e Core 1.48.0 (regra de conversão de servidor). Preservar atendimento prévio; registrar respostas e evidências no relatório principal.

## Validação e entrega

Testar auditoria com mais de 30 dias, política finita explícita e unlimited, migração sem perdas, histórico diário, replay, rollback, datas/limites, conversões, lacunas, revogação, cursores, exportação e painel. Matriz WordPress real: limpa isolada, integrada, atualização direta 0.10.1 e mínimos declarados. Fixtures não homologam fornecedor.

No Site-Teste, reler estado, atualizar somente LinkedIn com backup/hash e conferir saúde, schemas e documentação. Não repetir nem contornar o auxiliar MU-plugin recusado na rodada anterior. Sem credenciais reais, aceite retroativo no fornecedor permanece pendente.

Fechar instalador validado; fonte com runtime idêntico, código/testes/evidências e cópia do relatório anterior ao fechamento; relatório externo com bytes/SHA-256 finais. Salvar três artefatos. Sem distribuição à frota ou publicação em git.

## Fechamento — 27/10/2026 UTC

Achados corrigidos antes da instalação: isolamento concorrente dos jobs na retenção, ID duplicado do formulário e guardas de contexto/intervalo histórico. Teste de revogação corrigido para usar o executor MCP. Runtime reproduzido exatamente e aprovado em cinco matrizes, incluindo mínimos e upgrade direto. Evidências em evidence/release0110/.

Google 0.20.0 e Pipedrive 0.2.0 apareceram ativos por outras operações durante o fechamento. Pacotes/relatórios/contratos recuperados e examinados; matriz integrada adicional aprovada com Google 0.20.0. Pipedrive inativo no laboratório pelo mínimo PHP próprio, limitação registrada. Nenhuma adaptação adicional LinkedIn necessária.

0.11.0 aplicada no Site-Teste com pré-imagem/hash; saúde, schema, migração vazia e todos os documentos confirmados. Somente LinkedIn mudou entre os inventários imediatamente anterior/posterior. Homologação real sem credenciais permanece pendente.
