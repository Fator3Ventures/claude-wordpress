# Entrega — Fator3 MCP LinkedIn 0.8.0

> Cópia anterior ao fechamento do fonte. Relatório externo canônico: `wp-mcp-linkedin-fator3-0.8.0-relatorio.md`, entregue ao lado deste ZIP, com o tamanho e o SHA-256 do próprio fonte.

Revisão: 1 · Data/hora: 2026-10-23T02:15-03:00 · Rodada: implementação (melhorias por ordem do dono de 22/10/2026, rodada conjunta dos cinco pacotes Fator3). Candidato corrigido após revisão independente interna, antes de qualquer entrega ao dono.
Slug: `wp-mcp-linkedin-fator3` · Versão/build: 0.8.0 / build determinístico de `build/build.py`
Status: `com-pendencias` — apta no escopo testado em laboratório local; instalação no Site-Teste e na frota e homologação no LinkedIn real ficam pendentes (seção 6).

## 1. De onde esta versão entra

Instalação nova em WordPress limpo e atualização direta da **0.7.0**, sem versão intermediária. Base recebida e preservada byte a byte: `wp-mcp-linkedin-fator3-0.7.0-instalador.zip`, 207524 bytes, SHA-256 `85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515`; fonte 583713 bytes, SHA-256 `070dc8488219a5282036e8bb6a077a62c845f97d5f37e0d83ce5a1a36e3fcdde`. O build do fonte-base reproduziu o instalador 0.7.0 byte a byte antes de qualquer mudança.

Identidade preservada: nome Fator3 MCP LinkedIn, slug/pasta/provider, basename `wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php`, namespace `Fator3\LinkedIn`, Text Domain, Update URI, rota REST `f3-linkedin/v1`, tabela `wp_f3_linkedin_records`, opções, hooks (inclusive `f3_linkedin_register_consumers` e `f3_linkedin_service_mutation_recorded`), funções públicas de auditoria de serviço e os 80 IDs `linkedin/*`. Incremento minor.

Requisitos comprovados nesta rodada: **WordPress 6.4 com PHP 8.1.2** (instalação limpa, sem Abilities API, portanto sem MCP) e **WordPress 7.1.3 com PHP 8.3.6**, MySQL 8.0.46, PHP de 64 bits. Os mínimos do cabeçalho (6.4 e 8.1.2) deixam de ser apenas herdados. PHP 8.1.2 veio do arquivo oficial do Ubuntu 22.04 (`8.1.2-1ubuntu2.28`, índices com assinatura conferida); WordPress dos ZIPs oficiais.

## 2. Convivência e encaminhamentos

| Pacote | Conjunto da rodada (versões novas) | Conjunto hoje na frota |
|---|---|---|
| Fator3 Site Core | 1.49.0, `64a80ede90d8cc4a555ba39a016eae217898191a6275cb9cdaaed71388af8657` | 1.48.0, `91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de` |
| Fator3 MCP | 0.29.0, `1720f2db05c5a6ee90d1269ebdc764c14fb6b60e2878f765cf1183093ef1fb2a` | 0.28.0, `d1d297d8aaee0e5188b92fe9eae20a9dcc07e79d639baae25f267bf64f7243b0` |
| Fator3 MCP Google | 0.18.0, `b1ce908558502c8edf2c6928112d5a772b3690810cfc11405dcfe0547f2baea9` | 0.17.0, `42bd11080b518c82e0960753fa7b08d7adae28743cfcd3e96f9b83bf3f4709b0` |
| Fator3 MCP Meta | 0.7.0, `727fab33a1b8e43c2d8980a1b6ca8deb8af39762b334ac1f524471f9d6bbfaa8` | 0.6.0, `36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69` |

A 0.8.0 foi validada com os dois conjuntos (seção 4). Nenhuma ordem de troca é exigida. Por ordem do dono, esta entrega tem só três arquivos; as consequências para outros pacotes ficam nesta seção:

- **Site Core — `validacao-coordenada`, resolvida no escopo testado.** O hook `f3_linkedin_register_consumers` (mesmo nome e argumento `PublicApi::class`) passa de `plugins_loaded` prioridade 20 para `init` prioridade 1. O manipulador do Core (`F3Base_Linkedin_Cliente::registrar`) não muda e continua registrado antes do WP-Cron (`init` 10), da REST e do painel. Com o Core 1.48.0 isso elimina o aviso `_load_textdomain_just_in_time` do domínio `f3base` que aparecia em toda requisição (sonda D8: falha com a 0.7.0, passa com a 0.8.0). O Core 1.49.0 corrige o mesmo aviso do lado dele: com ele, nem a 0.7.0 provoca o aviso. As duas correções são compatíveis. Com Core 1.48.0 e 1.49.0 reais: consumidor do Core registrado e payload do Core aceito pelo adaptador (`site-conversion-delivery/1.0.0`). Não exercitado com o Core 1.47.0 que roda em 11 sites.
- **Site Core — informação técnica.** `linkedin/diagnose-conversions` aceita em `conversion_id` o ID da regra de servidor configurado no Core (Medição → Conversions API) e acusa `regra_divergente` quando difere da regra concedida. O LinkedIn não lê opção do Core.
- **Fator3 MCP — sem ação.** Com o MCP 0.28.0 e com o 0.29.0 reais, `service_audit.central_registered=true` e envios de serviço `central_audit=recorded` (suítes integradas). A nova operação é leitura (mode=read) e não muda perfis.
- **Fator3 MCP Meta — sem ação.** Código comum convergido com a Meta 0.7.0 (`Support.php`, `Query.php`, `Queue.php`, `Documentation.php`, `Export.php` idênticos em texto); builds e versões independentes.

Escopo avaliado: registro de consumidores Lead Sync, adaptador CAPI e contrato com o Core, auditoria humana e de serviço com o MCP, descoberta/perfis MCP, documentação pelo executor MCP, cron, opções e tabela. Google: sem fronteira afetada. Implantador não recebido: `nao-avaliado`.

## 3. Mudanças e evidência

Pedidos numerados abertos: nenhum (aba LinkedIn em 22/10/2026: "nada pendente"). Itens desta rodada: Melhorias M1–M6, origem ordem do dono de 22/10/2026. As sondas `tests/native/defects.php` rodam iguais na base, no primeiro candidato e no candidato final.

Convenção de efeitos (documentada em CONTRACTS.md): toda operação despachada pelo painel, REST, ability ou MCP grava uma linha no registro de auditoria local (`linkedin/audit`, retenção de 30 dias) e atualiza `f3_linkedin_audit_health` quando muda; `documentation` e `get-service-write-operation` são as exceções. `local_effect` descreve o estado operacional (configuração, concessões, credenciais, fila, agendas, diários) e não conta essa linha.

| Item | Problema na 0.7.0 | Mudança | Resultado e evidência |
|---|---|---|---|
| M1 — Worker de coletas | O LinkedIn não recebeu as correções que a Meta ganhou na 0.6.0 (Pedidos MCP Meta 13 e 14): o worker lia 20 coletas históricas por passagem a partir de um cursor; uma exceção na passagem encerrava a cadeia sem novo evento; nada recriava o evento perdido. | Fila indexada (schema 2: `queue_state`, `queue_next`, índice `runnable`), passagem sob trava de banco, pré-agendamento e rearme em `finally`, recuperação na manutenção horária e no bootstrap, migração em lotes de 100, registro ilegível isolado (`unreadable`). `linkedin/status` acrescenta `state`, `issues`, `queue`, `cron_worker`, `maintenance`; continua leitura (não repara, não reagenda, não envia e-mail; grava só a linha de auditoria). | Sondas D1 (exceção) e D2 (2000 coletas concluídas) falham na 0.7.0 e passam na 0.8.0; EXPLAIN usa `runnable` sem filesort; passagem concorrente não processa; `linkedin/status` pelo REST e pela ability escreve só a linha de auditoria; manutenção rearma. |
| M2 — Registro de consumidores em `init` | `do_action('f3_linkedin_register_consumers')` em `plugins_loaded` levava o Core 1.47/1.48 a carregar traduções antes de `init`: um aviso por requisição em cada site com Core e LinkedIn. | Disparo em `init` prioridade 1. | Sonda D8 com Core 1.48.0: 1 aviso por requisição na 0.7.0, 0 na 0.8.0. Processo novo: nada registrado durante `plugins_loaded`, registrado antes de `init` 5. |
| M3 — Manutenção autorreparável | `f3_linkedin_maintenance` (renovação de credenciais, retenção e recuperação do worker) só voltava ao reativar o plugin. | Em `init` (20), sob trava, reagenda a manutenção ausente; diagnóstico `maintenance_missing`. | Sonda D3 falha na base e passa na 0.8.0. |
| M4 — `linkedin/diagnose-conversions` | `conversion-capabilities` devolve só o primeiro motivo de bloqueio; a configuração da CAPI em CTO Office exige descobrir requisito por requisito. | Nova leitura administrativa local: concessão, conexão, revisão, conta, regra com fonte Conversions API, regra ativa, escopos, dono da concessão, regra de servidor do Core (quando informada), validade do token, idade da prova de escopos e registro central, cada um com código e ação. Sem HTTP; grava só a linha de auditoria. mode=read, local_effect=none, remote_effect=none. | Pelo REST e pela ability: única escrita é a linha de auditoria e `f3_linkedin_audit_health`, sem chamada ao fornecedor; `ready` igual a `conversion-capabilities.ready` sem `conversion_id`; regra do Core diferente → `regra_divergente` citando a regra concedida; regra Insight Tag → `regra_sem_fonte_api`; editor recusado (dispatch e REST 403). |
| M5 — Registro, listagens, retenção e carregamento | `linkedin/audit` em ordem de UUID; `list-connections` decifrava duas vezes; registro de coleta ilegível vencido abortava a retenção; cada requisição consultava `f3_linkedin_schema` (sem autoload). | `linkedin/audit` do mais recente com `since`; `list-connections` com uma leitura; retenção exclui coletas `unreadable` da seleção e marca as ilegíveis que encontrar; `f3_linkedin_schema` passa a autoload uma vez e a marca `f3_linkedin_queue_settled=2` (autoload) dispensa a consulta de migração. | Sondas D4 (150 ilegíveis vencidas antes de uma legível vencida) e D6 (toda consulta do pacote numa requisição nova) falham no primeiro candidato e passam no final; D4 e D5 falham na 0.7.0. Requisição nova: zero consultas SQL do pacote. |
| Leitura documental | `linkedin/documentation` recusava `offset` acima de 100000, e o `input-schemas.json` instalado tem cerca de 117 KB: com páginas de 16 KB o final do documento era inacessível pela operação (MCP, REST e ability). | Teto de `offset` elevado a 16777216. | Sonda D9 falha na base e passa; 23 documentos lidos integralmente pelo executor MCP real em 30 páginas de 16 KB. |
| M6 — Testes | Com os acompanhantes atuais, a suíte integrada da 0.7.0 reprovava 11 checagens por defasagem (versões fixas Meta 0.4.1/MCP 0.27.0/Core 1.47.0, payload sem a regra de servidor da 1.48.0, expectativa de auditoria central ausente); a espera de 2 s do teste de trava falhava sob carga. | Versões lidas dos instaladores extraídos, expectativa central conforme o MCP presente, payload com `server_conversion_id`, espera de até 15 s, processo filho com o PHP/ini do laboratório, checagens de ability `nao-aplicavel` sem a API, escritas medidas pelo caminho publicado, `release080.php`, `upgrade080.php`, sondas base × candidatos. | Linha de base registrada (0.7.0 integrado: 136 checagens, 11 falhas por defasagem); 0.8.0 integrado: 159 checagens, zero falhas. |

Contrato: 81 operações (80 preservadas + `diagnose-conversions`). Schemas de entrada iguais aos da 0.7.0, exceto `audit` (`since` opcional) e `documentation` (teto de `offset`). Rótulos em português. Arquivos de runtime: 57 (28 PHP, 23 documentos); acrescentados `includes/Queue.php`, `includes/Worker.php`, `docs/WORKER.md`, `docs/RELEASE-0.8.0.md`; nenhum removido.

## 4. Instalação e prova da troca

Procedimento para a frota: publicar o instalador e este relatório na raiz `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/`, conferir os bytes servidos e instalar com `plugins/upload` usando a URL raw, `expected_slug: wp-mcp-linkedin-fator3` e o SHA-256 da seção 8. Prova da troca, em requisição nova: `linkedin/status` com `version=0.8.0`, `queue.migration_pending=false` após as primeiras requisições, `state` coerente, `service_audit.central_registered=true` com o Fator3 MCP; `linkedin/selftest` aprovado; 81 operações `linkedin/*`; `linkedin/documentation` com `document=index`. Em CTO Office, `linkedin/diagnose-conversions` com o ID da regra de servidor do Core mostra o que falta para a CAPI.

| Cenário | Ambiente | Resultado | Evidência no fonte |
|---|---|---|---|
| Instalação limpa isolada | WP 7.1.3, PHP 8.3.6, MySQL 8.0.46, só o LinkedIn | 127 checagens, zero falhas | `evidence/final/clean-isolated/` |
| Instalação limpa, conjunto da rodada | + Core 1.49.0, MCP 0.29.0, Google 0.18.0, Meta 0.7.0 | 159 checagens e documentação MCP 24 (23 documentos, 30 páginas); zero falhas; `debug.log` vazio | `evidence/final/clean-integrated-rodada/` |
| Atualização direta 0.7.0 → 0.8.0, conjunto da rodada | dados semeados na 0.7.0 (concessão CAPI, prova de escopo, prévia, diário, agenda, coleta, assinatura) | 165 checagens: registros idênticos byte a byte (ciphertext, revisão, datas, retenção), opções preservadas (só o schema 1→2), coleta legada projetada, worker e manutenção armados; documentação MCP 24; zero falhas | `evidence/final/upgrade-integrated-rodada/` |
| Instalação limpa, conjunto de hoje na frota | + Core 1.48.0, MCP 0.28.0, Google 0.17.0, Meta 0.6.0 | 159 checagens e documentação MCP 24; zero falhas; nenhum aviso `f3base` | `evidence/final/clean-integrated-frota/` |
| Mínimos do cabeçalho | WP 6.4, PHP 8.1.2, só o LinkedIn | 125 aprovadas, 2 não aplicáveis (Abilities API ausente), zero falhas | `evidence/final/minimum-wp64-php812/` |
| Sondas base × candidatos | conjunto da rodada e conjunto de hoje | 0.7.0: D1–D5 e D9 falham (D8 também com Core 1.48.0); primeiro candidato: D4 e D6 falham; final: D1–D9 aprovadas nos dois conjuntos | `evidence/final/defects-*` |

Contagens por suíte, com regressões comuns; não são casos únicos somáveis. Em todos os cenários: instalador idêntico ao instalado e nenhuma linha de notice/warning/deprecation/fatal atribuída ao LinkedIn no `debug.log`. Fornecedor e e-mail interceptados; nenhuma chamada real ao LinkedIn, nenhuma conversão real.

Documentação instalada atualizada: README, CHANGELOG, RELEASE-0.8.0 (nova), WORKER (nova), CONTRACTS, CONVERSIONS, SDK-PHP (momento do hook), SERVICE-AUDIT, AGENTS, TROUBLESHOOTING, MIGRATION e títulos de versão.

Estado final: laboratórios locais descartáveis, bancos removidos ao final de cada execução. Nenhum site da frota nem o Site-Teste foi alterado.

## 5. Banco e volta de versão

Schema SQL 1 → 2 por dbDelta aditivo na primeira requisição: colunas `queue_state` e `queue_next`, índice `runnable`. Nenhuma tabela nova. A migração preenche só a projeção técnica das coletas, em lotes de 100, sem tocar no payload cifrado; retoma sozinha a cada requisição/passagem até concluir. Opções novas: `f3_linkedin_queue_migration`, `f3_linkedin_queue_settled` (autoload), `f3_linkedin_worker_schedule_attempt/failure`, `f3_linkedin_last_maintenance` e, quando necessário, `f3_linkedin_maintenance_rearmed`; a coluna `autoload` de `f3_linkedin_schema` passa a ligada na primeira requisição. A opção `f3_linkedin_scan` do worker antigo deixa de ser usada e não é apagada. Concessões, credenciais, diários CAPI e Lead Sync, prévias e agendas não mudam.

Volta à 0.7.0: os arquivos da base funcionam com o mesmo banco (colunas extras e autoload ignorados) e retomam o worker antigo, sem recuperação. Ao reinstalar a 0.8.0, o schema é reaplicado e as projeções reconstruídas. Restaurar arquivos não desfaz conversões, coletas ou envios já feitos e não autoriza reenvio. Preserve banco e salts com o backup; não desinstale para simular rollback. Downgrade não foi ensaiado nesta rodada.

## 6. O que permanece pendente

| Pendência | Responsável |
|---|---|
| Instalar no Site-Teste e repetir a prova da seção 4 em WordPress real compartilhado | Site Geral \| Todos / dono |
| Publicar e distribuir na frota com `expected_sha256` e `expected_slug` | Dono / frota |
| Convivência com o Core 1.47.0 (11 sites) | Não exercitada nesta rodada |
| CAPI real em CTO Office: `rw_conversions`, regra com fonte Conversions API na conta, concessão ao `site-core-conversions`, conversão entregue e contada uma vez (pendências 20/92/116 da frota) | Dono / frota / Core |
| Atualização a partir da 0.7.0 no WordPress 6.4/PHP 8.1.2 | Não executada; o mínimo foi provado em instalação limpa |
| Botão de diagnóstico CAPI na tela | Não implementado: a operação está em MCP/REST; telas e JavaScript não mudaram |

## 7. Credenciais e configuração do dono

Nenhum campo ou segredo novo. Conexão (Access Token, Client ID, Primary Client Secret, Refresh Token opcional) e concessão de Conversions API continuam em Ferramentas → Fator3 MCP LinkedIn. Não recrie credenciais para atualizar. Para usar `linkedin/diagnose-conversions` por agente com perfil personalizado, inclua a operação no perfil; `manage_options` continua obrigatório.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | `wp-mcp-linkedin-fator3-0.8.0-instalador.zip` | 227651 | `035a84fea5a02480c933c626cda994c49e58649ab4fb192f90b1f526238e8c35` |
| Fonte | `wp-mcp-linkedin-fator3-0.8.0-fonte.zip` | a preencher no relatório externo após empacotamento | a preencher no relatório externo após empacotamento |

Somente o instalador é instalável (raiz `wp-mcp-linkedin-fator3/`). O fonte tem raiz `wp-mcp-linkedin-fator3-0.8.0-fonte/`, runtime idêntico ao instalador, build, testes, ferramentas, evidências sanitizadas e a cópia deste relatório anterior ao fechamento. Nenhum ZIP contém outro ZIP. O instalador foi gerado duas vezes a partir do fonte com bytes idênticos. Este candidato substitui o primeiro (SHA-256 `1e383c260d261beea99d8dad394ddde124cdf75df0afa75279effbd663b8124e`), que não foi entregue.
