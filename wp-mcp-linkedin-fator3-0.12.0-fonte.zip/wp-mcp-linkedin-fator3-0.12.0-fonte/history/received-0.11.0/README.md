# Fonte — Fator3 MCP LinkedIn 0.11.0

Versão corrente desta entrega, sobre a base aceita 0.10.1. Implementa o Pedido MCP LinkedIn 14(a–d): auditoria configurável sem prazo por padrão, conexões unlimited preservando escolhas finitas, acervo diário cifrado Pages/Ads, backfill, leitura/exportação e migração conservadora. Instale somente `wp-mcp-linkedin-fator3-0.11.0-instalador.zip`.

## Conteúdo

- `plugin/wp-mcp-linkedin-fator3/`: 67 arquivos exatos do instalador, 32 PHP e 29 documentos. 90 operações; registros schema 2 e histórico schema 1.
- `build/linkedin/{Retention,History,HistoryExport}.php`: classes novas próprias. Adaptador, fila, autorização, schemas e painel adaptados em `build/`; build autônomo, sem templates externos.
- `build/docs/linkedin/HISTORY.md`: políticas, métricas, limites da API, particionamento, exportação, migração e reversão. Notas anteriores são históricas.
- `tests/native/request014.php`: 27 casos, um condicional de upgrade. `seed014.php` semeia dados na 0.10.1. Pedidos 12 e 13 mantêm 18 e 33 verificações.
- `tests/native/mcp-history011.php`: seis provas pelo executor original MCP 0.33.0. `mcp-docs080.php` lê os documentos correntes, apesar do nome histórico.
- `tests/native/ui011.php` e `ui011.cjs`: 20 verificações DOM com HTML/JS reais e REST autenticado; jsdom 27.4.0 fixado em `tests/dom/`. Não equivale a inspeção visual em navegador.
- `evidence/release0110/`: cinco matrizes finais, comparação com a base, integridade, instalação, documentação e estado final do Site-Teste. Provas históricas não são somadas.
- `inputs/0.11.0/`: pedido, normas revisão 5, relatórios e impactos recebidos intactos e hashes dos pacotes externos, sem ZIP aninhado.
- `planning/RELEASE-0110.md`: plano e fechamento. `history/received-0.10.1/` preserva README e relatório anteriores.
- Ferramentas `site-qa-*` antigas são históricas de laboratório, fora do runtime; não devem ser instaladas no Site-Teste compartilhado. Esta entrega não instalou auxiliar remoto.

## Reprodução

Prepare WordPress, PHP, MySQL e os instaladores em caminhos externos. Ajuste `tools/lab-release0110.example.json`, preservando hashes dos pacotes e preenchendo os hashes das árvores de runtimes. MySQL deve ser descartável e permitir criar/remover schemas de laboratório. Nunca use credenciais de produção. O laboratório exige destino novo, bloqueia HTTP do fornecedor/e-mail e compara os bytes instalados; não executa o build automaticamente.

```sh
F3_SOCIAL_PHP=/usr/bin/php python3 build/build.py
python3 tools/lab.py --manifest tools/lab-release0110.example.json --workdir /tmp/li011-integrated --order linkedin-integrated --tests suite.php,request012.php,request013.php,request014.php,mcp-history011.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release0110.example.json --workdir /tmp/li011-upgrade --order linkedin-integrated --origin upgrade --tests request014.php,suite.php,request012.php,request013.php,mcp-history011.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release0110.example.json --workdir /tmp/li011-minimum --order linkedin-only --wordpress wordpress_minimum --php php81 --tests suite.php,request012.php,request013.php,request014.php
python3 tools/lab.py --manifest tools/lab-release0110.example.json --workdir /tmp/li011-isolated --order linkedin-only --tests suite.php,request012.php,request013.php,request014.php
npm ci --prefix tests/dom
F3_JSDOM="$PWD/tests/dom/node_modules/jsdom" CODEX_PRIMARY_RUNTIME_NODE=/usr/bin/node python3 tools/lab.py --manifest tools/lab-release0110.example.json --workdir /tmp/li011-ui --order linkedin-integrated --tests ui011.php
```

No upgrade, execute `request014.php` primeiro, antes das demais mutações. O exemplo usa Google 0.20.0/Pipedrive 0.2.0; matrizes iniciais e de upgrade usaram Google 0.19.0/Pipedrive 0.1.0, com identidades em cada `environment.json`. Pipedrive não é ativado abaixo do mínimo próprio PHP 8.3.36; use runtime compatível para ampliar a prova, sem contornar o requisito.

## Resultado e limites

**1.093 verificações funcionais aprovadas, oito não aplicáveis e zero falhas**, mais 90 documentais locais e 20 DOM. WordPress 7.1.3/PHP 8.3.6 e WordPress 6.4/PHP 8.1.2, MySQL 8.0.46. As cinco matrizes usam o instalador SHA-256 `34541afa67c0991e9dc0b5474ab8678dff8cf806eace6ceb1edb47983f9e0308`, reproduzido exatamente. Quinze árvores de acompanhantes coincidem com seus ZIPs.

Site-Teste: 0.10.1 → 0.11.0 aplicada, ativa, sondas de mesma origem 200, status ok, selftest 9/9. Leitura remota de 29 documentos/30 páginas/254.834 bytes, idênticos. Schema de retenção e migração vazia confirmados. Zero conexões; nenhuma credencial ou operação comercial real. Auditoria de 100 dias e acervo anterior à instalação foram provados em WordPress real com dados/respostas controlados. Aceite do fornecedor e inspeção visual permanecem pendentes.

Somente LinkedIn foi atualizado remotamente. Core 1.56.0, MCP 0.33.0, Google 0.20.0, Meta 0.12.0 e Pipedrive 0.2.0 já estavam ativos imediatamente antes e assim permaneceram. Nenhum documento de outro mantenedor foi editado. Nenhum novo impacto; os recebidos são tratados no relatório principal.

`tools/package-source.py` exige runtime idêntico ao instalador e recusa ZIP aninhado ou sobrescrita do fonte fechado. Relatório interno anterior ao fechamento; bytes/hash finais do fonte somente no relatório externo. Reversão para 0.10.1 exige avaliar banco/salts e interromper a manutenção antiga, que não entende unlimited; leia HISTORY.md.
