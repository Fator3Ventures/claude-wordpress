# Impacto para MCP LinkedIn — Core 1.48.0

Revisão: 3 · Data: 23/10/2026 · Etapa: entrega · Situação: resolvido quanto à implementação da interface; aceite comercial pendente.
Emissor: `base-site-core-fator3` 1.48.0, base 1.47.0. Destinatário originalmente examinado: `wp-mcp-linkedin-fator3` 0.7.0; revalidação pelo destinatário na 0.8.1 nesta revisão.
Pedido: 289. Instalador emissor: `base-site-core-fator3-1.48.0-instalador.zip`, SHA-256 `91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de`.

## Problema e contrato entregue

O ID do Insight Tag não é a regra de fonte CONVERSIONS_API. O consumidor `site-core-conversions` preserva `site-conversion-delivery/1.0.0` e `site-linkedin-conversion/1.0.0`, mas passa a fornecer exclusivamente `f3base_linkedin_server_conversion_id` ao servidor. `f3base_linkedin_conversion_id` permanece a regra do navegador. Os dois destinos compartilham o mesmo `event_id`.

Sem regra de servidor há bloqueio `regra_ausente`; não existe fallback para a regra do navegador nem transferência automática de registros anteriores. A prévia identifica os dois destinos e a leitura administrativa declara a extensão `site-linkedin-destinations/1.0.0`. O SDK Google `site-measurement-context/1.0.0` permanece sem novos campos. Material continua somente no navegador.

## Compatibilidade e evidência

O adaptador LinkedIn 0.7.0 já concede regra CONVERSIONS_API: nenhuma mudança de código é solicitada ao fornecedor. O Core compara o ID configurado à concessão e bloqueia divergência. Teste local com adaptador real 0.7.0 e MCP 0.28.0, HTTP interceptado: regra do navegador 67890, regra do servidor 98765, mesmo evento; HTTP 201 simulado, deduplicação do fornecedor e auditoria central de serviço confirmados. Foram dez verificações do fornecedor e 48 do consumidor, além do schema real do Google 0.17.0. O Site-Teste validou configuração com simulação/releitura, prévia e diagnóstico, sem evento comercial.

A auditoria de serviço foi confirmada com MCP 0.28.0; a limitação anterior relatada para MCP 0.27.0 não se aplica ao conjunto testado. Os pacotes dos fornecedores não foram alterados. Estas são provas do emissor usando o contrato existente, não declaração de nova implementação pelo mantenedor destinatário.

## Ação restante

Em CTO Office, após a autorização `rw_conversions`, selecionar a regra API ativa da conta 558431216, concedê-la ao consumidor e preencher o novo campo do Core. Conferir um contato real entregue e contado uma vez. Não há aceite comercial nem mudança de configuração nessa conta nesta rodada. O encaminhamento é entregue ao dono; não foi enviado por mensagem ao mantenedor.

## Histórico

Revisão 1: aberto no planejamento antes da alteração de fronteira, com proposta de separar IDs e conservar o SDK Google. Revisão 2: comportamento entregue e validação do adaptador existente; nenhuma mudança exigida no fornecedor, pendência restrita à habilitação e ao aceite comercial.

## Revisão 3 — retorno do mantenedor LinkedIn

Revisão do destinatário, sem alterar a autoria ou as evidências da revisão 2 do Core. LinkedIn 0.8.0 revisado e corrigido na 0.8.1, instalador SHA-256 `172081883af66b8c4b61676396d85066d4be0778b7ca06fb22262b30a4d2374a` (232544 bytes). Mantidos os contratos, a separação das regras navegador/servidor, `event_id`, concessão explícita e bloqueio de regra divergente. Nenhuma migração de histórico nem fallback de destino foi introduzido.

Consequência técnica pertinente: `conversion-capabilities.ready` e `diagnose-conversions.ready` agora são falsos quando a prova de token vinculada à credencial vigente registra expiração conhecida ou `active=false`. A ação é renovar/revalidar a credencial; não trocar regra, payload ou ID de evento. Prova ausente continua com o comportamento anterior de escopos da concessão e aviso de revalidação. O envio continua exigindo inspeção remota antes de qualquer POST. Diagnóstico permanece local, sem reparo ou HTTP.

Prova própria do destinatário: instalação integrada com Core 1.48.0, MCP 0.28.0, Google 0.17.0 e Meta 0.6.0, 166 verificações aprovadas; atualizações 0.8.0→0.8.1 e 0.7.0→0.8.1 com 173 verificações em cada cenário. A suíte inclui o payload real do consumidor Core e o bloqueio por regra de servidor divergente. No Site-Teste, 25 verificações sintéticas, auditoria de serviço `recorded`, três POST interceptados, nenhuma chamada real ao LinkedIn; conexão, concessão, agenda e jobs de QA removidos. Não se trata de homologação comercial do pipeline Core.

A interface técnica permanece resolvida para a combinação efetivamente ensaiada. Os instaladores Core 1.49.0/MCP 0.29.0/Google 0.18.0/Meta 0.7.0 citados na entrega recebida da 0.8.0 não estavam disponíveis para esta reexecução; sua prova é herdada e identificada como tal no relatório. A ação comercial da seção anterior permanece com o dono. Nenhum contato real foi enviado nem relatório encaminhado a terceiros.
