# Histórico recebido da base 0.8.1

Conteúdo preservado para rastreabilidade, sem aprovação ou reemissão pela rodada 0.9.0. As revisões herdadas dos impactos Core 1.48.0/MCP 0.28.0 foram produzidas indevidamente na rodada anterior e não são documentos correntes de seus mantenedores. Os originais recebidos permanecem em inputs/0.8.1; as novas entradas correntes estão em inputs/0.9.0, com hashes. A rodada 0.9.0 não altera documentos de outros responsáveis.
