# Fonte — Fator3 MCP LinkedIn 0.10.1

Versão corrente desta entrega. Implementa o Pedido MCP LinkedIn 13 sobre a base aceita 0.9.0. A 0.10.0 chegou a ser aplicada no Site-Teste; a revisão posterior corrigiu a continuidade de identidade na troca manual de Refresh Token, gerando o patch 0.10.1. Instale somente `wp-mcp-linkedin-fator3-0.10.1-instalador.zip`.

## Estrutura e evidências

- `plugin/wp-mcp-linkedin-fator3/`: os 62 arquivos exatos do instalador testado, 29 PHP e 27 documentos. Não contém ferramentas de laboratório.
- `build/linkedin/ConnectionChanges.php`: validação, conferência prévia, identidade, confirmação e commit atômico da conexão/agendas/concessões. `Credentials.php` trata comprovação, callback e renovação. `build/common/` contém as adaptações próprias de contratos, agendas, SDK, painel e manutenção. O build continua autônomo.
- `build/docs/linkedin/`: documentação instalada; notas 0.10.0 e 0.10.1. As 81 operações e o schema SQL 2 permanecem; apenas `save-connection` e `oauth-start` recebem parâmetros aditivos no catálogo de entrada.
- `tests/native/request013.php`: 33 verificações do pedido e do patch, com WordPress/MySQL reais e HTTP do fornecedor interceptado. `request012.php` mantém as 18 provas concorrentes da fila. `suite.php` cobre regressões e atualização; `seed.php` aceita 0.9.0.
- `tests/native/ui010.php` e `ui010.cjs`: 13 verificações DOM com HTML/JS reais do painel e REST autenticado. Dependência jsdom 27.4.0 fixada em `tests/dom/`. Não equivale a inspeção visual em navegador.
- `evidence/release0101/`: resultados finais, reprodução de três problemas na 0.9.0, diff, hashes, integridade dos acompanhantes e Site-Teste. `preliminary-observations.json` distingue correções de runtime, ajustes de fixtures e falha de infraestrutura das provas finais.
- `planning/PLANO-0100.md`: plano anterior à implementação, com complemento de fechamento 0.10.1.
- `inputs/0.10.1/`: pedido, normas, relatórios e impactos recebidos sem alterações; hashes dos documentos e instaladores. Dependências externas não são aninhadas no fonte.
- `history/received-0.9.0/`, evidências e inputs anteriores: histórico recebido, não provas novas. O impacto próprio antigo foi arquivado; esta rodada não emite impacto novo nem responde editando documento de outro mantenedor.
- `tools/site-qa-0100.php`: auxiliar de teste validado somente no laboratório, na candidata 0.10.0. Sua criação remota foi recusada pela revisão automática de aprovação, pois criaria MU-plugin/ability fora do pacote autorizado. Não foi instalado, não integra o runtime e não comprova os testes completos no Site-Teste. Os demais auxiliares numerados são históricos.

## Reprodução

Prepare WordPress, runtimes, MySQL e os instaladores recebidos em caminhos externos. Ajuste `tools/lab-release0101.example.json`, preservando os hashes dos pacotes e preenchendo o hash do runtime local. O laboratório exige um diretório vazio e cria um schema próprio no MySQL informado. Fornecedor e e-mail ficam interceptados no laboratório. Não use esses auxiliares em site compartilhado.

```sh
F3_SOCIAL_PHP=/usr/bin/php python3 build/build.py
python3 tools/lab.py --manifest tools/lab-release0101.example.json --workdir /tmp/li0101-integrated --order linkedin-integrated --tests suite.php,request012.php,request013.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release0101.example.json --workdir /tmp/li0101-upgrade --order linkedin-integrated --origin upgrade --tests suite.php,request012.php,request013.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release0101.example.json --workdir /tmp/li0101-minimum --order linkedin-only --wordpress wordpress_minimum --php php81 --tests suite.php,request012.php,request013.php
python3 tools/lab.py --manifest tools/lab-release0101.example.json --workdir /tmp/li090-reproduce --order linkedin-only --candidate /CAMINHO/DEPENDENCIAS/wp-mcp-linkedin-fator3-0.9.0-instalador.zip --tests reproduce013.php
npm ci --prefix tests/dom
F3_JSDOM="$PWD/tests/dom/node_modules/jsdom" CODEX_PRIMARY_RUNTIME_NODE=/usr/bin/node python3 tools/lab.py --manifest tools/lab-release0101.example.json --workdir /tmp/li0101-ui --order linkedin-integrated --tests ui010.php
```

A reprodução da base registra os três comportamentos antigos: campo trocado aceito, token inativo gravado sem introspecção e agenda inválida após renomear. Não é resultado aprovado da 0.10.1. O build não é executado automaticamente pelo laboratório; sempre confira o instalador indicado.

## Matriz final e limites

WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46: 218 verificações funcionais aprovadas na instalação integrada limpa e 225 na atualização direta da 0.9.0. WordPress 6.4/PHP 8.1.2-1ubuntu2.28 isolado: 183 aprovadas e três não aplicáveis. Total: 626 aprovadas, três não aplicáveis e zero falhas. Somam-se 56 verificações documentais pelo executor MCP local e 13 DOM. Os acompanhantes locais são Core 1.50.0, MCP 0.29.1, Google 0.19.0 e Meta 0.8.0; suas árvores foram conferidas contra os ZIPs recebidos em ambos os cenários integrados.

O arquivo `patch-minimum-013/request013.json` é a prova canônica do pedido 13 no mínimo: corrigiu a contabilização do teste MCP ausente como não aplicável. O arquivo anterior `patch-minimum/request013.json` é preservado como observação anterior e não entra de novo no total.

Site-Teste: 0.10.1 ativa, sondas inicial/REST 200, selftest 8/8, status ok e zero conexões. Leitura completa dos 27 documentos em 28 páginas, conteúdo idêntico ao instalador. Meta 0.9.0 apareceu por outra operação durante o fechamento: documentação instalada e selftest foram lidos, sem modificar esse plugin. Seu ZIP não estava disponível para repetir a matriz local; essa observação remota não substitui a matriz com Meta 0.8.0.

Sem credenciais reais, homologação no LinkedIn permanece pendente. A introspecção não retorna nome de membro nem nome do aplicativo: o Client ID/validade/escopos são conferidos; o nome do aplicativo é declarado pelo administrador, e o membro é lido por userinfo somente quando openid/profile já estiverem autorizados. Identidade desconhecida exige confirmação ao trocar token; não se infere pelo rótulo.

`tools/package-source.py` exige runtime idêntico ao instalador e recusa ZIP aninhado ou sobrescrita de fonte fechado. O relatório interno é anterior ao fechamento; tamanho/hash finais do fonte constam do relatório externo. O instalador foi reproduzido em diretório limpo com o mesmo SHA-256.
