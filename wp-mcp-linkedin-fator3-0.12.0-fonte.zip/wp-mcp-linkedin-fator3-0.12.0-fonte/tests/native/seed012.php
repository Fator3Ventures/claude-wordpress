<?php
/** Executed by the immutable accepted 0.11.0 before candidate replacement. */
use Fator3\LinkedIn as L;
require __DIR__.'/seed014.php';
$c=L\Connections::get('legacy14');$g=['consumer_id'=>'site-core-conversions','enabled'=>true,'connection_id'=>'legacy14','connection_revision'=>$c['revision'],'account_id'=>'222','conversion_id'=>'999','rule'=>['id'=>'999','account_id'=>'222','enabled'=>true,'conversion_method'=>'CONVERSIONS_API','checked_at'=>time()],'scopes'=>['rw_conversions','r_ads'],'principal'=>L\Access::principal(),'destination_ref'=>str_repeat('9',64),'created_at'=>time()];$r=L\Store::put('conversion_grant','site-core-conversions',$g,0);
L\Store::put('token_proof','legacy14',['active'=>true,'binding'=>L\Credentials::binding($c),'scopes'=>['r_ads','rw_conversions'],'expires_at'=>time()+10000,'checked_at'=>time()],L\Store::get('token_proof','legacy14')['revision']);
foreach(['confirmed','uncertain'] as $state){$key=hash('sha256','baseline012-'.$state);$res=['status'=>$state==='confirmed'?'entregue':'incerto','code'=>$state==='confirmed'?'linkedin_http_201':'envio_sem_recibo','http'=>$state==='confirmed'?201:0,'non_delivery_proven'=>false];L\Store::put('conversion_event',$key,['connection_id'=>$c['id'],'account_id'=>'222','conversion_id'=>'999','principal'=>$g['principal'],'service'=>true,'payload_digest'=>hash('sha256','fixture012-'.$state),'state'=>$state,'created_at'=>time(),'before'=>['status'=>'nao_enviado'],'after'=>$state==='confirmed'?$res:null,'operation'=>'send-conversion-event','result'=>$res,'service_identity'=>L\ServiceAudit::bind($g,$r['revision'])+['operation_id'=>$key]],0);}
L\History::ingest($d,$p,$c,'legacy14:000000');$rp=L\Retention::get();L\Retention::save(['expected_revision'=>$rp['revision'],'audit_mode'=>'finite','audit_days'=>365,'dry_run'=>false]);
$tables=[];global $wpdb;foreach([L\Store::table(),L\History::table()] as $table){$rows=$wpdb->get_results('SELECT * FROM '.$table.' ORDER BY 1',ARRAY_A);$tables[$table]=['rows'=>count($rows),'sha256'=>hash('sha256',serialize($rows))];}
file_put_contents(getenv('F3_LAB_ROOT').'/baseline012.json',wp_json_encode(['version'=>L\Config::VERSION,'tables'=>$tables,'retention'=>L\Retention::get(),'connection'=>L\Connections::public(L\Connections::get('legacy14')),'grant'=>L\Conversions::grant()]));

unlink(getenv('F3_LAB_ROOT').'/baseline-014.json');
