<?php
if(is_file(getenv('F3_LAB_ROOT').'/baseline012.json'))return; // 0.11.0 preservation is verified by upgrade012.php before fixture cleanup.
if(is_file(getenv('F3_LAB_ROOT').'/baseline-014.json'))return; // Current baseline is covered by request014.php, before mutation fixtures.
/** Direct accepted baseline 0.7.0 / 0.8.0 → current patch upgrade: data, ciphertext and options preserved; schema 2 migrated; worker supervised. */
require_once __DIR__.'/lab-helpers.php';
if(getenv('F3_LAB_ORIGIN')!=='upgrade'||!class_exists('Fator3\\LinkedIn\\Worker'))return;
check('080 upgrade preserves every record byte for byte (ciphertext, revision, timestamps, retention)',function(){
 global $wpdb;$b=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline-080.json'),true);$t=\Fator3\LinkedIn\Store::table();
 $raw=$wpdb->get_results("SELECT bucket,record_key,revision,payload,updated_at,expires_at FROM $t ORDER BY bucket,record_key",ARRAY_A);
 expect(hash('sha256',serialize($raw))===$b['raw_sha256']&&count($raw)===$b['rows'],'rows '.count($raw).' vs '.$b['rows']);
});
check('080 upgrade preserves existing options; only the schema marker advances',function(){
 global $wpdb;$b=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline-080.json'),true);
 foreach($b['options'] as $o){$now=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$o['option_name']));
  if($o['option_name']==='f3_linkedin_schema'){expect(in_array($o['option_value'],['1','2'],true)&&$now==='2');continue;}
  expect($now===$o['option_value'],$o['option_name']);}
});
check('080 upgrade migrates legacy jobs into the runnable projection and keeps the schedule supervised',function(){
 global $wpdb;$t=\Fator3\LinkedIn\Store::table();
 expect(!\Fator3\LinkedIn\Queue::pending()&&\Fator3\LinkedIn\Queue::settled());
 expect($wpdb->get_var($wpdb->prepare("SELECT queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,str_repeat('b',64)))==='complete');
 $s=\Fator3\LinkedIn\Store::get('schedule','legacy');expect($s&&$s['value']['enabled']===true);
 expect(wp_next_scheduled('f3_linkedin_worker')!==false&&wp_next_scheduled('f3_linkedin_maintenance')!==false);
});

check('081 upgrade from schema 2 preserves the queue projection exactly',function(){
 global $wpdb;$b=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline-080.json'),true);
 if($b['projection_sha256']===null)return;
 $t=\Fator3\LinkedIn\Store::table();$rows=$wpdb->get_results("SELECT bucket,record_key,queue_state,queue_next FROM $t ORDER BY bucket,record_key",ARRAY_A);
 expect(hash('sha256',serialize($rows))===$b['projection_sha256']);
});
