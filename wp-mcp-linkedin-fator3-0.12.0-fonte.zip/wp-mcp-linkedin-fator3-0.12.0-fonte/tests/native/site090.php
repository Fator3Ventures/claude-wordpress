<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
require dirname(__DIR__,2).'/tools/site-qa-090.php';
$r=f3_linkedin_090_acceptance();file_put_contents(getenv('F3_LAB_ROOT').'/evidence/site090-helper.json',wp_json_encode($r,JSON_PRETTY_PRINT));echo wp_json_encode($r).PHP_EOL;exit($r['success']?0:1);
