<?php
/** Pedido 12: deterministic interleavings on independent real MySQL connections. No provider required.
 * Migration repair deliberately leaves the projection pending (legacy/restore writer), exercising the
 * revision and ciphertext guards independently of Store::put's projection update. */
use Fator3\LinkedIn as Q12;
function request012_cases(): array {
 global $wpdb;$t=Q12\Store::table();$checks=[];$keys=[];
 [$h,$p,$sock]=$wpdb->parse_db_host(DB_HOST);$other=new mysqli($h,DB_USER,DB_PASSWORD,DB_NAME,(int)($p?:3306),$sock?:null);
 $prefix='qa012_'.bin2hex(random_bytes(5));$errors=$wpdb->suppress_errors(true);
 $check=static function($name,callable $fn)use(&$checks){try{$fn();$checks[]=['name'=>$name,'passed'=>true];}catch(Throwable $e){$checks[]=['name'=>$name,'passed'=>false,'reason'=>$e->getMessage()];}};
 $assert=static function($ok,$why='Postcondition failed'){if(!$ok)throw new RuntimeException($why);};
 $raw=static fn($key)=>$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE bucket='job' AND record_key=%s",$t,$key),ARRAY_A);
 $seed=static function($kind)use(&$keys,$prefix,$wpdb,$t){$key=$prefix.'_'.count($keys);$keys[]=$key;$wpdb->insert($t,['bucket'=>'job','record_key'=>$key,'revision'=>7,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>123,'expires_at'=>$kind==='prune'?time()-10:0,'queue_state'=>$kind==='migrate'?'':'queued','queue_next'=>1]);return $key;};
 $run=static function($kind){return $kind==='migrate'?Q12\Queue::migrate():Q12\Store::prune();};
 try {
  foreach(['migrate','prune'] as $kind){
   foreach(['revision','payload'] as $change){
    $check("12 $kind preserves a concurrently repaired $change",static function()use($kind,$change,$seed,$raw,$run,$assert,$wpdb,$t,$other){
     $key=$seed($kind);$fresh=Q12\Crypto::seal(Q12\Util::json(['status'=>'queued','next_at'=>time()+3600,'sentinel'=>'readable replacement']));$changed=false;
     $race=static function($sql)use(&$changed,$key,$fresh,$change,$kind,$t,$other){
      if(!$changed&&str_starts_with($sql,'UPDATE ')&&str_contains($sql,$key)&&str_contains($sql,"'unreadable'")){
       $changed=true;$rev=$change==='revision'?',revision=revision+1':'';$state=$kind==='migrate'?'':'queued';
       if(!$other->query("UPDATE `".$other->real_escape_string($t)."` SET payload='".$other->real_escape_string($fresh)."',queue_state='$state',queue_next=1234567890$rev WHERE bucket='job' AND record_key='".$other->real_escape_string($key)."'"))throw new RuntimeException('Concurrent writer failed');
      }return $sql;
     };
     add_filter('query',$race);try{$run($kind);}finally{remove_filter('query',$race);}
     $r=$raw($key);$assert($changed,'Interleaving was not reached');$assert($r['queue_state']===($kind==='migrate'?'':'queued')&&(int)$r['queue_next']===1234567890&&$r['payload']===$fresh&&(int)$r['revision']===($change==='revision'?8:7),'Readable replacement incorrectly quarantined');
     $assert(Q12\Store::get('job',$key)['value']['sentinel']==='readable replacement');$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
    });
   }
   $check("12 $kind propagates transient read failure without quarantine",static function()use($kind,$seed,$raw,$run,$assert,$wpdb,$t){
    $key=$seed($kind);$before=$raw($key);$hit=false;
    $fail=static function($sql)use(&$hit,$key){if(!$hit&&str_starts_with($sql,'SELECT * FROM')&&str_contains($sql,$key)){$hit=true;return 'SELECT * FROM `qa012_nonexistent_table`';}return $sql;};
    add_filter('query',$fail);$reason=null;try{$run($kind);}catch(Q12\Fault $e){$reason=$e->reason;}finally{remove_filter('query',$fail);}
    $assert($hit&&$reason==='storage_unavailable'&&$raw($key)===$before,'Transient read was not propagated unchanged');$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
   });
   $check("12 $kind respects a competing job lock and preserves encrypted fields",static function()use($kind,$seed,$raw,$run,$assert,$wpdb,$t,$other){
    $key=$seed($kind);$before=$raw($key);$lock='f3s:'.substr(hash('sha256',DB_NAME.'|'.$t.'|job:'.$key),0,55);$held=$other->query("SELECT GET_LOCK('".$other->real_escape_string($lock)."',0)")->fetch_row();$assert($held[0]==='1');
    try{$run($kind);$assert($raw($key)===$before,'Projection changed without owning job lock');}finally{$other->query("SELECT RELEASE_LOCK('".$other->real_escape_string($lock)."')");}
    $run($kind);$after=$raw($key);$assert($after['queue_state']==='unreadable'&&(int)$after['queue_next']===0);unset($before['queue_state'],$before['queue_next'],$after['queue_state'],$after['queue_next']);$assert($after===$before,'Encrypted fields changed');$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
   });
   $check("12 $kind propagates failed isolation UPDATE and conserves record",static function()use($kind,$seed,$raw,$run,$assert,$wpdb,$t){
    $key=$seed($kind);$before=$raw($key);$hit=false;$fail=static function($sql)use(&$hit,$key){if(!$hit&&str_starts_with($sql,'UPDATE ')&&str_contains($sql,$key)&&str_contains($sql,"'unreadable'")){$hit=true;return "UPDATE `qa012_nonexistent_table` SET x=1";}return $sql;};
    add_filter('query',$fail);$reason=null;try{$run($kind);}catch(Q12\Fault $e){$reason=$e->reason;}finally{remove_filter('query',$fail);}
    $assert($hit&&$reason==='storage_unavailable'&&$raw($key)===$before);$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
   });
   $check("12 $kind rereads a repaired record before considering isolation",static function()use($kind,$seed,$raw,$run,$assert,$wpdb,$t,$other){
    $key=$seed($kind);$before=$raw($key);$fresh=Q12\Crypto::seal('{"status":"queued","sentinel":"repaired before lock read"}');$reads=0;
    $race=static function($sql)use(&$reads,$key,$fresh,$t,$other){if(str_starts_with($sql,'SELECT * FROM')&&str_contains($sql,$key)&&++$reads===2)$other->query("UPDATE `".$other->real_escape_string($t)."` SET payload='".$other->real_escape_string($fresh)."',revision=revision+1 WHERE bucket='job' AND record_key='".$other->real_escape_string($key)."'");return $sql;};
    add_filter('query',$race);try{$run($kind);}finally{remove_filter('query',$race);}
    $after=$raw($key);$expected=$before;$expected['payload']=$fresh;$expected['revision']='8';$assert($reads>=2&&$after===$expected,'Repaired snapshot was quarantined or not reread');$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
   });
   $check("12 $kind propagates failure of the isolation reread",static function()use($kind,$seed,$raw,$run,$assert,$wpdb,$t){
    $key=$seed($kind);$before=$raw($key);$reads=0;$fail=static function($sql)use(&$reads,$key){if(str_starts_with($sql,'SELECT * FROM')&&str_contains($sql,$key)&&++$reads===2)return 'SELECT * FROM `qa012_nonexistent_table`';return $sql;};
    add_filter('query',$fail);$reason=null;try{$run($kind);}catch(Q12\Fault $e){$reason=$e->reason;}finally{remove_filter('query',$fail);}
    $assert($reads===2&&$reason==='storage_unavailable'&&$raw($key)===$before);$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
   });
   $check("12 $kind isolates corrupt decrypted JSON without rewriting receipt",static function()use($kind,$seed,$raw,$run,$assert,$wpdb,$t){
    foreach(['{broken','42'] as $json){$key=$seed($kind);$wpdb->update($t,['payload'=>Q12\Crypto::seal($json)],['bucket'=>'job','record_key'=>$key]);$before=$raw($key);$run($kind);$after=$raw($key);$assert($after['queue_state']==='unreadable'&&(int)$after['queue_next']===0);unset($before['queue_state'],$before['queue_next'],$after['queue_state'],$after['queue_next']);$assert($after===$before);$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);}
   });
  }
  $check('12 worker isolation preserves a concurrently repaired readable job',static function()use($seed,$raw,$assert,$wpdb,$t,$other){
   $key=$seed('prune');$fresh=Q12\Crypto::seal('{"status":"queued","sentinel":"worker repair"}');$changed=false;
   $race=static function($sql)use(&$changed,$key,$fresh,$t,$other){if(!$changed&&str_starts_with($sql,'UPDATE ')&&str_contains($sql,$key)&&str_contains($sql,"'unreadable'")){$changed=true;$other->query("UPDATE `".$other->real_escape_string($t)."` SET payload='".$other->real_escape_string($fresh)."',revision=revision+1 WHERE bucket='job' AND record_key='".$other->real_escape_string($key)."'");}return $sql;};
   add_filter('query',$race);$reason=null;try{Q12\Jobs::run($key,true);}catch(Q12\Fault $e){$reason=$e->reason;}finally{remove_filter('query',$race);}
   $r=$raw($key);$assert($changed&&$reason==='cipher_unreadable'&&$r['queue_state']==='queued'&&$r['payload']===$fresh&&(int)$r['revision']===8);
   $lock='f3s:'.substr(hash('sha256',DB_NAME.'|'.$t.'|job:'.$key),0,55);$assert($other->query("SELECT GET_LOCK('".$other->real_escape_string($lock)."',0)")->fetch_row()[0]==='1','Nested job lock leaked');$other->query("SELECT RELEASE_LOCK('".$other->real_escape_string($lock)."')");$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
  });
  $check('12 missing, readable and already isolated records are idempotent no-ops',static function()use($seed,$raw,$assert,$wpdb,$t){
   $key=$seed('prune');$wpdb->update($t,['payload'=>Q12\Crypto::seal('{"status":"queued"}')],['bucket'=>'job','record_key'=>$key]);$before=$raw($key);$assert(Q12\Queue::isolateUnreadable($key)===false&&$raw($key)===$before);
   $wpdb->update($t,['payload'=>'broken','queue_state'=>'unreadable','queue_next'=>0],['bucket'=>'job','record_key'=>$key]);$before=$raw($key);$assert(Q12\Queue::isolateUnreadable($key)===false&&$raw($key)===$before);$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);$assert(Q12\Queue::isolateUnreadable($key)===false);
  });
 }finally{foreach($keys as $key)$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);$wpdb->suppress_errors($errors);$other->close();}
 return ['version'=>Q12\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($c)=>!$c['passed'])),'concurrency'=>'deterministic SQL boundary; independent mysqli connection; real named locks','provider_calls'=>0];
}
