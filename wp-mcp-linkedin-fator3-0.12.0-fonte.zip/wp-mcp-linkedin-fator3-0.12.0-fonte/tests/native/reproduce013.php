<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);use Fator3\LinkedIn as L;
if(L\Config::VERSION!=='0.9.0')throw new RuntimeException('Requires immutable accepted baseline 0.9.0');
$c=L\Connections::save(['connection_id'=>'base13','expected_revision'=>0,'token'=>'secret-in-token','client_id'=>'clientA','client_secret'=>'secretA','assets'=>['pages'=>['111']]])['connection'];
$s=L\Schedules::save(['schedule_id'=>'base13','expected_revision'=>0,'query'=>['connection_id'=>'base13','channel'=>'pages','account_id'=>'111','report'=>'organization'],'enabled'=>true,'interval_minutes'=>60]);
$c=L\Connections::save(['connection_id'=>'base13','expected_revision'=>$c['revision'],'label'=>'Renomeada'])['connection'];$conflict=false;try{L\Connections::checkPlan(L\Store::get('schedule','base13')['value'],L\Connections::get('base13'));}catch(L\Fault $e){$conflict=$e->reason==='revision_conflict';}
$calls=0;$fixture=static function()use(&$calls){$calls++;return ['body'=>'{"active":false}','headers'=>[],'response'=>['code'=>200],'cookies'=>[]];};add_filter('pre_http_request',$fixture,-100);
L\Connections::save(['connection_id'=>'base13','expected_revision'=>$c['revision'],'token'=>str_repeat('inactive-fixture',10)]);remove_filter('pre_http_request',$fixture,-100);
$r=['version'=>L\Config::VERSION,'wrong_field_accepted'=>true,'rename_breaks_schedule'=>$conflict,'inactive_candidate_accepted_without_introspection'=>$calls===0,'supplier'=>'blocked fixtures'];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/reproduce013.json',wp_json_encode($r,JSON_PRETTY_PRINT));echo wp_json_encode($r).PHP_EOL;exit($conflict&&$calls===0?0:1);
