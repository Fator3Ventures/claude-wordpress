<?php
/** Executed under immutable 0.10.1, before replacement by the candidate. */
use Fator3\LinkedIn as L;
add_filter('pre_http_request',static function($pre,$a,$url){if(!str_ends_with($url,'introspectToken'))return $pre;parse_str($a['body'],$i);return ['headers'=>[],'body'=>wp_json_encode(['active'=>true,'client_id'=>$i['client_id'],'expires_at'=>time()+864000,'scope'=>'r_ads,r_ads_reporting,r_organization_admin,r_organization_social']),'response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]];},1,3);
L\Connections::save(['connection_id'=>'legacy14','expected_revision'=>0,'retention_days'=>3650,'token'=>'fixture14-'.str_repeat('x',110),'client_id'=>'client14','client_secret'=>'secret14','assets'=>['pages'=>['111'],'ads'=>['222']]]);
$p=['user_id'=>1,'channel'=>null];$q=['connection_id'=>'legacy14','channel'=>'pages','account_id'=>'111','report'=>'page_statistics','date_from'=>'2020-01-02','date_to'=>'2020-01-02'];$at=time()-100*86400;$t=strtotime('2020-01-02 UTC')*1000;
$d=['connection_id'=>'legacy14','channel'=>'pages','account_id'=>'111','report'=>'page_statistics','selection'=>$q,'rows'=>[['organization'=>'urn:li:organization:111','timeRange'=>['start'=>$t,'end'=>$t+86400000],'totalPageStatistics'=>['views'=>['allPageViews'=>['pageViews'=>123]]]]],'api_version'=>'202609','fetched_at'=>gmdate('c',$at),'timezone'=>'UTC','currency'=>null,'temporal'=>'interval','coverage'=>['complete'=>true,'errors'=>[]],'next_cursor'=>null];
L\Store::put('result','legacy14:000000',['principal'=>$p,'query'=>$q,'data'=>$d],0,time()-1);
L\Store::put('audit','old-audit14',['operation'=>'query','at'=>$at],0,time()-1);
global $wpdb;$wpdb->query($wpdb->prepare('UPDATE %i SET updated_at=%d WHERE bucket=%s AND record_key=%s',L\Store::table(),$at,'audit','old-audit14'));
L\Store::put('schedule','legacy14',['query'=>$q,'principal'=>$p,'connection_revision'=>1,'authorization_revision'=>1,'credential_generation'=>1,'enabled'=>false,'label'=>'Preservar agenda','interval_minutes'=>1440,'lookback_days'=>7,'next_at'=>time()+86400,'last_job'=>null,'last_code'=>null]);
$records=[];foreach($wpdb->get_results('SELECT bucket,record_key,revision,payload FROM '.L\Store::table().' ORDER BY bucket,record_key',ARRAY_A) as $r)$records[]=['bucket'=>$r['bucket'],'key'=>$r['record_key'],'revision'=>(int)$r['revision'],'sha256'=>hash('sha256',$r['payload'])];
file_put_contents(getenv('F3_LAB_ROOT').'/baseline-014.json',wp_json_encode(['base_version'=>L\Config::VERSION,'records'=>$records]));
echo "{\"baseline_seeded\":\"0.10.1\"}\n";
