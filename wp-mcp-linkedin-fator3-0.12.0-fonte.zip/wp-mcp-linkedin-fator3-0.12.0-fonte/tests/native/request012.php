<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
require __DIR__.'/request012-cases.php';
$r=request012_cases();file_put_contents(getenv('F3_LAB_ROOT').'/evidence/request012.json',wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($r).PHP_EOL;exit($r['failed']?1:0);
