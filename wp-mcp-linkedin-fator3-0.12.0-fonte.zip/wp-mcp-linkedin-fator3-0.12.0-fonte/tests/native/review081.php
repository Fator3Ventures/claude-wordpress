<?php
/** Independent review regressions; real WordPress, synthetic provider only. */
use Fator3\LinkedIn as L;

check('081 R1 unreadable indexed jobs cannot starve a healthy collection',function(){
 global $wpdb;resetHttp();$t=L\Store::table();$keys=[];$snap=[];$good=null;
 try{
  for($n=0;$n<20;$n++){
   $key='000review081_bad_'.str_pad((string)$n,3,'0',STR_PAD_LEFT);$keys[]=$key;
   $wpdb->insert($t,['bucket'=>'job','record_key'=>$key,'revision'=>7,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time()-90,'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
   $snap[$key]=$wpdb->get_row($wpdb->prepare("SELECT payload,revision,updated_at,expires_at FROM %i WHERE bucket='job' AND record_key=%s",$t,$key),ARRAY_A);
  }
  $good=L\Jobs::create(['query'=>['connection_id'=>'qa','channel'=>'pages','account_id'=>'111','report'=>'organization'],'idempotency_key'=>'review081-healthy']);
  for($n=0;$n<3;$n++){wp_clear_scheduled_hook('f3_linkedin_worker');L\Jobs::tick();}
  $job=L\Store::get('job',$good['job_id']);
  expect($job['value']['status']==='complete','Healthy job stayed '.$job['value']['status'].' behind unreadable indexed jobs');
  foreach($keys as $key){
   $r=$wpdb->get_row($wpdb->prepare("SELECT payload,revision,updated_at,expires_at,queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,$key),ARRAY_A);
   expect($r['queue_state']==='unreadable','Bad row still runnable');unset($r['queue_state']);expect($r===$snap[$key],'Encrypted record changed');
  }
 }finally{
  foreach($keys as $key)$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);
  if($good){$wpdb->delete($t,['bucket'=>'job','record_key'=>$good['job_id']]);$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='result' AND record_key LIKE %s",$t,$wpdb->esc_like($good['job_id'].':').'%'));}
 }
});

check('081 R2 status survives an unreadable last scheduled job without repairing it',function(){
 global $wpdb;$t=L\Store::table();$job='review081_health_bad';$schedule='review081_health';
 $wpdb->insert($t,['bucket'=>'job','record_key'=>$job,'revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>0,'queue_state'=>'unreadable','queue_next'=>0]);
 try{
  L\Schedules::save(['schedule_id'=>$schedule,'expected_revision'=>0,'query'=>['connection_id'=>'qa','channel'=>'pages','account_id'=>'111','report'=>'organization'],'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()+3600]);
  $r=L\Store::get('schedule',$schedule);$v=$r['value'];$v['last_job']=$job;L\Store::put('schedule',$schedule,$v,$r['revision']);
  [$h,$writes]=lab_writes(static fn()=>L\Worker::health());
  expect($writes===[]&&$h['state']==='degraded'&&in_array('schedule_job_unreadable',array_column($h['issues'],'code'),true),wp_json_encode($h));
  $r=L\Api::dispatch('status');expect($r['success']&&$r['data']['state']==='degraded',wp_json_encode($r));
 }finally{$wpdb->delete($t,['bucket'=>'job','record_key'=>$job]);$wpdb->delete($t,['bucket'=>'schedule','record_key'=>$schedule]);}
});

check('081 R3 a known expired scope proof cannot report conversion readiness',function(){
 $r=L\Store::get('token_proof','conversions');expect($r!==null);$saved=$r['value'];$v=$saved;$v['expires_at']=time()-1;L\Store::put('token_proof','conversions',$v,$r['revision']);
 try{
  $before=count($GLOBALS['capiCalls']);[$d,$writes]=lab_writes(static fn()=>L\Conversions::diagnose([]));$cap=L\Conversions::capabilities();
  expect(!$d['ready']&&!$cap['ready'],'Expired verified token was reported ready');
  $by=array_column($d['checks'],null,'id');expect(($by['token_proof_valid']['code']??null)==='token_expired',wp_json_encode($d));
  expect($writes===[]&&count($GLOBALS['capiCalls'])===$before,'Diagnostic mutated state or made HTTP');
 }finally{$now=L\Store::get('token_proof','conversions');L\Store::put('token_proof','conversions',$saved,$now['revision']);}
});

check('081 R5 an inactive current proof blocks both readiness interfaces',function(){
 $r=L\Store::get('token_proof','conversions');$saved=$r['value'];$v=$saved;$v['active']=false;L\Store::put('token_proof','conversions',$v,$r['revision']);
 try{$d=L\Conversions::diagnose([]);$c=L\Conversions::capabilities();$by=array_column($d['checks'],null,'id');expect(!$d['ready']&&!$c['ready']&&$c['reason']==='token_rejected'&&$by['token_proof_valid']['code']==='token_rejected');}
 finally{$now=L\Store::get('token_proof','conversions');L\Store::put('token_proof','conversions',$saved,$now['revision']);}
});

check('081 R6 corrupt child result pauses its readable parent without quarantining it or making HTTP',function(){
 global $wpdb;resetHttp();$t=L\Store::table();$j=L\Jobs::create(['query'=>['connection_id'=>'qa','channel'=>'pages','account_id'=>'111','report'=>'organization'],'idempotency_key'=>'review081-bad-child']);$key=$j['job_id'].':000000';
 $wpdb->insert($t,['bucket'=>'result','record_key'=>$key,'revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
 try{$n=count($GLOBALS['requests']);$r=L\Jobs::run($j['job_id'],true);expect($r['status']==='paused'&&$r['last_code']==='cipher_unreadable'&&count($GLOBALS['requests'])===$n);expect($wpdb->get_var($wpdb->prepare("SELECT queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,$j['job_id']))==='paused');}
 finally{$wpdb->delete($t,['bucket'=>'result','record_key'=>$key]);$wpdb->delete($t,['bucket'=>'job','record_key'=>$j['job_id']]);}
});

check('081 R7 isolation respects the job lock and never alters its payload or revision',function(){
 global $wpdb;$t=L\Store::table();$key='review081_locked_bad';$payload='s1.'.base64_encode(random_bytes(80));
 $wpdb->insert($t,['bucket'=>'job','record_key'=>$key,'revision'=>11,'payload'=>$payload,'updated_at'=>time(),'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
 [$h,$p,$sock]=$wpdb->parse_db_host(DB_HOST);$other=new mysqli($h,DB_USER,DB_PASSWORD,DB_NAME,(int)($p?:3306),$sock?:null);$name='f3s:'.substr(hash('sha256',DB_NAME.'|'.$t.'|job:'.$key),0,55);$other->query("SELECT GET_LOCK('".$other->real_escape_string($name)."',0)");
 try{
  fault(static fn()=>L\Jobs::run($key,true),'busy');expect($wpdb->get_var($wpdb->prepare("SELECT queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,$key))==='queued');
  $other->query("SELECT RELEASE_LOCK('".$other->real_escape_string($name)."')");fault(static fn()=>L\Jobs::run($key,true),'cipher_unreadable');
  $r=$wpdb->get_row($wpdb->prepare("SELECT queue_state,payload,revision FROM %i WHERE bucket='job' AND record_key=%s",$t,$key),ARRAY_A);expect($r['queue_state']==='unreadable'&&$r['payload']===$payload&&(int)$r['revision']===11);
 }finally{$other->close();$wpdb->delete($t,['bucket'=>'job','record_key'=>$key]);}
});

check('081 R4 auto-disabled unauthorized schedule remains visible in status',function(){
 global $wpdb;$t=L\Store::table();$id='review081_auth';
 try{
  L\Schedules::save(['schedule_id'=>$id,'expected_revision'=>0,'query'=>['connection_id'=>'qa','channel'=>'pages','account_id'=>'111','report'=>'organization'],'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()-1]);
  $r=L\Store::get('schedule',$id);$v=$r['value'];$v['connection_revision']=-1;$v['authorization_revision']=-1;L\Store::put('schedule',$id,$v,$r['revision']);L\Schedules::tick();
  $s=L\Store::get('schedule',$id);expect(!$s['value']['enabled']&&$s['value']['last_code']==='revision_conflict');
  [$h,$writes]=lab_writes(static fn()=>L\Worker::health());
  $issues=array_filter($h['issues'],static fn($x)=>($x['schedule_id']??null)===$id&&($x['code']??null)==='schedule_authorization_failed');
  expect(count($issues)===1&&$writes===[],'Automatic authorization pause disappeared from health');
 }finally{$wpdb->delete($t,['bucket'=>'schedule','record_key'=>$id]);}
});
