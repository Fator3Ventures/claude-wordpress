# Fonte — Fator3 MCP LinkedIn 0.12.0

Versão corrente desta entrega, sobre a base aceita 0.11.0. Implementa a fronteira LinkedIn do Pedido Core 323, impacto Core 1.58.0 revisão 2: conversões comerciais por ação, contrato opcional 1.2.0. Instale somente `wp-mcp-linkedin-fator3-0.12.0-instalador.zip`.

## Conteúdo

- `plugin/wp-mcp-linkedin-fator3/`: 71 arquivos exatos do instalador, 33 PHP e 31 documentos; 93 operações. Schemas de armazenamento 2 e histórico 1 preservados.
- `build/linkedin/StageConversions.php`: concessões comerciais, validação, capacidades e adaptador. Alterações delimitadas em Conversions, ServiceAudit, ConnectionChanges, schemas, painel e documentação próprios.
- `build/docs/linkedin/STAGE-CONVERSIONS.md`: configuração, contrato, payload, recibos e reversão. Notas de versões anteriores são históricas.
- `tests/native/stages012.php` e `stages012-core.php`: 24 cenários com Core real; 17 aplicáveis sem Core. Não substituem o adaptador por mock; HTTP do fornecedor é sintético.
- `tests/native/mcp-stages012.php`: cinco provas pelo executor MCP 0.34.0 original, incluindo concessão própria, schema, redação e revogação do transporte.
- `tests/native/seed012.php`/`upgrade012.php`: dados na base 0.11.0 e oito verificações de preservação antes das mutações dos demais testes.
- `tests/native/ui012.php`/`ui012.cjs`: 26 verificações DOM com HTML/JS e REST autenticado reais; jsdom 27.4.0. Não equivale a inspeção visual em navegador.
- `evidence/release0120/`: cinco matrizes finais, comparação de código/schema, integridade, instalação e documentação remota. 989 execuções funcionais aprovadas, oito não aplicáveis, zero falhas; 96 documentais e 26 DOM adicionais. Casos repetidos em matrizes distintas não são apresentados como testes únicos.
- `inputs/0.12.0/`: relatórios, impacto recebido, normas revisão 5 e identidades dos pacotes; bytes recebidos preservados. Não contém os ZIPs externos.
- `planning/RELEASE-0120.md`: plano e achado de integração. `impacts/wp-mcp-linkedin-fator3-0.12.0-impacto-wp-mcp-fator3.md`: pedido substantivo ao mantenedor MCP.
- `history/received-0.11.0/`: README/relatório da base. Provas e ferramentas anteriores são históricas e não são contadas nesta rodada. `tools/site-qa-*` antigos nunca devem ser instalados no Site-Teste compartilhado.

## Reprodução

Dependências de desenvolvimento externas ao fonte: WordPress 7.1.3/6.4, PHP 8.3.6/8.1.2, MySQL 8.0.46, instaladores acompanhantes e base. Ajuste `tools/lab-release0120.example.json`, preserve hashes dos pacotes e preencha os hashes das árvores de runtimes. Os fetchers validam SHA-256; PHP 8.1 usa os pacotes fixados 8.1.2-1ubuntu2.28, pois o pin anterior .26 deixou o arquivo público. Dependências não são instaladas no servidor WordPress.

O MySQL do laboratório deve ser descartável; o harness exige diretório novo, banco próprio, bloqueia HTTP externo/e-mail e confere cada byte instalado. Nunca usar banco ou credenciais de produção. `lab.py` não executa build automaticamente.

```sh
F3_SOCIAL_PHP=/usr/bin/php python3 build/build.py
python3 tools/lab.py --manifest tools/lab-release0120.example.json --workdir /tmp/li012-clean --order linkedin-integrated --tests suite.php,request012.php,request013.php,request014.php,mcp-history011.php,stages012.php,mcp-stages012.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release0120.example.json --workdir /tmp/li012-upgrade --order linkedin-integrated --origin upgrade --tests upgrade012.php,suite.php,request012.php,request013.php,request014.php,mcp-history011.php,stages012.php,mcp-stages012.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release0120.example.json --workdir /tmp/li012-min --order linkedin-only --wordpress wordpress_minimum --php php81 --tests suite.php,request012.php,request013.php,request014.php,stages012.php
python3 tools/lab.py --manifest tools/lab-release0120.example.json --workdir /tmp/li012-isolated --order linkedin-only --tests suite.php,request012.php,request013.php,request014.php,stages012.php
npm ci --prefix tests/dom
F3_JSDOM="$PWD/tests/dom/node_modules/jsdom" CODEX_PRIMARY_RUNTIME_NODE=/usr/bin/node python3 tools/lab.py --manifest tools/lab-release0120.example.json --workdir /tmp/li012-ui --order linkedin-integrated --tests stages012.php,mcp-stages012.php,mcp-docs080.php,ui012.php
```

No upgrade execute upgrade012 primeiro: ele comprova preservação e depois retira somente a concessão sintética da base e restaura a política padrão para os cenários independentes seguintes. Os diários/histórico semeados ficam preservados. Não se executam suítes de migração de bases antigas na matriz 0.11.0.

## Resultado e fronteiras

Instalador reproduzido exatamente, SHA-256 `19748e788190f371809db469a6de052a645e25f39fad1672606dc776234ec54c`. Instalação limpa, atualização direta, isolamento, mínimos e interface aprovados. Core 1.58.0, MCP 0.34.0, Google 0.21.0 e Meta 0.13.0 ativos nos testes integrados. Pipedrive 0.3.0 preservado mas não ativado no PHP 8.3.6, inferior ao mínimo próprio 8.3.36. Não se contornou a exigência.

Somente LinkedIn atualizado no Site-Teste: 0.11.0 → 0.12.0, ativo, status ok, selftest 9/9. Home/REST HTTP 200 em sondas internas de mesma origem. Leitura remota integral: 31 documentos, 33 páginas, 272.425 bytes idênticos ao instalador. Zero conexões/concessões comerciais. Nenhum helper remoto nem efeito comercial real.

O Core do Site-Teste permanece 1.57.1; habilitar o consumidor comercial exige implantação do Core 1.58.0 pelo mantenedor correspondente. O MCP 0.34.0 ainda restringe a auditoria central a site-core-conversions: o novo consumidor conserva recibos locais e pode informar service_record_unconfirmed. O impacto solicita admitir site-core-quality sem reduzir validações. A aquisição continua registrada normalmente. Não foram alterados código ou documentos de outros pacotes; cinco fontes recebidos e dez árvores instaladas de acompanhantes foram comparados byte a byte.

Fonte e instalador são imutáveis após a entrega. O relatório interno é anterior ao fechamento; bytes/hash finais do fonte constam somente no relatório externo. `tools/package-source.py` confere runtime idêntico, raiz única e ausência de ZIP aninhado, e recusa sobrescrever o fonte fechado. Sem publicação GitHub ou implantação em frota nesta rodada.
