# Pedidos — Fator3 MCP LinkedIn (wp-mcp-linkedin-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no pacote **wp-mcp-linkedin-fator3** (rotas `linkedin/*`). Em outros documentos, cite como "Pedidos MCP LinkedIn N". Serve também de documento para o responsável pelo pacote. Base: 0.9.0. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba.

**Escopo do pacote (0.9.0).** LinkedIn Pages e Ads com leitura e gestão (grupos, campanhas e anúncios em rascunho com ativação separada; publicações e comentários da Página), o SDK do Lead Sync (`SPONSORED`) com concessões por consumidor, conta e formulário, verificação criptográfica das notificações e gestão das assinaturas próprias, e o envio à Conversions API como adaptador do consumidor `site-core-conversions` do Site Core (filtro `f3base_conversoes_adaptador`, contrato `site-conversion-delivery/1.0.0`; concessão própria, separada da do Lead Sync, com `rw_conversions` e `r_ads` por introspecção e regra ativa da conta com `conversionMethod` `CONVERSIONS_API`), com o envio em segundo plano registrado no Registro do Fator3 MCP como principal de serviço (contrato `mutation-service-audit/1.0.0`, leitor `linkedin/get-service-write-operation`); painel em Ferramentas → Fator3 MCP LinkedIn, com ajuda ao lado de cada campo (nome e caminho no LinkedIn) e a aba Ajuda; conexões cifradas (`linkedin/save-connection` com `expected_revision`; ativos `pages`, `ads` e `leads`), coleta, agendas, exportação CSV e JSON e 81 operações públicas (entre elas `linkedin/diagnose-conversions`, diagnóstico local da Conversions API). A entrada do contato vindo do Lead Sync é do Site Core (`f3base_anuncios_linkedin`). Requisitos: WordPress 6.4 e PHP 8.1.2 de 64 bits e travas nomeadas no banco. Atualização por ZIP manual.

**Situação em 23/10/2026: aberto o 13.** Versão instalada nos 12 sites da frota: 0.9.0 (ZIP `wp-mcp-linkedin-fator3-0.9.0-instalador.zip`, 236.277 bytes, sha256 `d4857927…`, igual ao relatório; no `main` com a fonte `26fc1c75…` e o relatório, commit `a61a8cd`), direto sobre a 0.8.1: no Site-Teste pelo agente do pacote e nos outros 11 pela frota em 23/10/2026 entre 16:55 e 17:21 −03 (korvena.com.br por último, por ordem do dono), depois do Meta 0.8.0 em cada site, com `applied` e sondas 200 antes e depois. A 0.9.0 atendeu o pedido 12 (retirado): `Queue::isolateUnreadable` relê o registro sob a trava `job:<id>`, decodifica o mesmo snapshot e só marca `unreadable` se a revisão e o ciphertext ainda coincidem, na migração, na retenção e no worker; trava ocupada adia, e falha do banco devolve `storage_unavailable`, sem quarentena; sem schema, opção ou concessão nova (schema SQL 2, 81 operações). Lido depois da troca nos 12: `linkedin/status` com `state` `ok`, `issues` vazio, `unreadable_jobs` 0, `service_audit.central_registered` true e `access_lifecycle.next_maintenance` preenchido; em ctooffice e fator3.com.br as conexões seguem com 59 dias de validade, só os quatro escopos de leitura e `rw_conversions` false. O aceite real (conversão entregue e contada, a referência de serviço no Registro de ctooffice, conexão nova preenchida pelo dono só com a tela, segredo errado indicando o par recusado) fica nas pendências 20, 92 e 116 do estado da frota; a regra 31692506 é do Insight Tag, e o pacote exige regra com fonte API (pendência 116). Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 14) e vai no fim; item retirado deixa o número vago.

## wp-mcp-linkedin-fator3 — pendentes

**13. Conexão: nome com os nomes do LinkedIn, formato de cada campo, conferência antes de gravar, o que está salvo e agendas que acompanham a revisão (23/10/2026; ordem do dono de 23/10/2026 às 17:22: "O mesmo pedido Meta 15, deve ser estendido a todos os outros pacotes"; equivalente ao Pedidos MCP Meta 15).** Tela: Ferramentas → Fator3 MCP LinkedIn → aba Conexão (formulário da conexão e "Autorização pelo LinkedIn e renovação") e rotas `linkedin/save-connection`, `linkedin/inspect-token`, `linkedin/refresh-token` e `linkedin/save-schedule`.

**Situação na 0.9.0 (lida no código em 23/10/2026):** os campos já trazem o nome do LinkedIn e o caminho (`FieldHelp`, Pedidos MCP LinkedIn 11), mas `linkedin/save-connection` grava token, Client ID e Primary Client Secret sem consultar o LinkedIn (a introspecção só acontece depois, em `linkedin/inspect-token`) e só recusa espaço e tamanho acima de 16 KiB; o plano de cada agenda compara `connection_revision` com a revisão da conexão (`Connections::checkPlan`): qualquer gravação da conexão, até só do nome, deixa as agendas em `revision_conflict`. O "Nome da conexão" diz "não é um campo do LinkedIn", sem regra de nome.

**Pedido 1 — rótulos, ajudas e validação** (português, ajuda abaixo do campo, sempre visível):

• "Nome da conexão" — ajuda: "Use o nome do membro que gerou o token e o nome do aplicativo como aparecem no LinkedIn, separados por ·. Exemplo: Anderson Siqueira · \<nome do aplicativo>. Onde ver: LinkedIn Developers → My apps → \<aplicativo> → Settings → App name; o membro é o perfil conectado ao gerar o token no Token Generator." Placeholder: "membro · aplicativo".

• "Token de acesso (Access Token)" — ajuda atual mantida. Validação: 100 caracteres ou mais, sem espaços; recusar com "Isto parece a Chave secreta do aplicativo (Primary Client Secret) ou o Client ID, não um token. Copie o Access Token no Token Generator." quando o valor for igual ao Client ID ou à chave salva ou informada, ou tiver menos de 100 caracteres.

• "ID do cliente (Client ID)" — validação: só letras e números, sem espaços; valor só com dígitos recusado com "Isto é o número do aplicativo no endereço, não o Client ID. Copie o Client ID em Auth → Application credentials."

• "Chave secreta do aplicativo (Primary Client Secret)" — validação: diferente do token e do Client ID, menos de 100 caracteres; recusar com "Isto parece um Access Token, não a Primary Client Secret."

• "Número do aplicativo (App ID no endereço)" — validação: só dígitos.

• "Token de renovação (Refresh Token, opcional)" — validação: diferente do Access Token.

• "Validade do acesso" — depois de gravar, a tela troca o valor informado pelo `expires_at` da introspecção.

**Pedido 2 — conferir antes de gravar:** com token, Client ID ou Primary Client Secret novo, `linkedin/save-connection` e "Salvar conexão" chamam `introspectToken` com o par informado antes de persistir; com par recusado, `active` false, token de outro aplicativo (`client_id` diferente) ou sem os escopos de leitura (r\_ads, r\_ads\_reporting, r\_organization\_admin, r\_organization\_social), não gravam, mantêm o salvo e devolvem o motivo em português (ex.: "O LinkedIn recusou este token: inativo ou de outro aplicativo. O token salvo continua em uso."). Vale também para a renovação.

**Pedido 3 — mostrar o que está salvo:** no topo da conexão, "Token de: \<membro, quando legível> · Aplicativo: \<nome> (Client ID \<id>) · Validade: \<data> · Escopos: \<lista>", lidos da introspecção, com os escopos de escrita (rw\_ads, w\_organization\_social, rw\_organization\_admin, rw\_conversions) destacados.

**Pedido 4 — troca de identidade guiada:** token válido de outro membro ou de outro aplicativo: "O token novo é de outra identidade (\<membro ou aplicativo>). Para trocar, use 'Trocar identidade e regravar agendas': o token é conferido, a seleção de ativos, formulários e concessões é mantida e as agendas são regravadas na nova revisão.", com simulação e `expected_revision`; as concessões do Lead Sync e da Conversions API se reconfirmam na mesma tela.

**Pedido 5 — agendas acompanham a revisão:** mudar o nome, o Client ID ou a chave, ou trocar o token da mesma identidade, não deixa agenda em `revision_conflict`; o pacote rebaseia as agendas da conexão no mesmo salvamento e registra isso no histórico (modelo do Meta: `authorization_revision` e `credential_generation`).

**Aceite (Site-Teste):** (a) a Primary Client Secret ou o Client ID colado em "Token de acesso" é recusado com a mensagem do Pedido 1, sem mudar o salvo; (b) token inativo é recusado sem gravar; (c) token de outro membro passa pela troca guiada e as agendas ficam na revisão nova; (d) gravar só o nome não deixa agenda em `revision_conflict`; (e) rótulos e ajudas como no Pedido 1; (f) o topo mostra membro, aplicativo, validade e escopos da introspecção.

## Decidido não fazer

Nada registrado.
