# Entrega — Fator3 MCP Pipedrive 0.2.0

Revisão: 1 · Data: 27/10/2026 UTC · Rodada: implementação
Slug: `wp-mcp-pipedrive-fator3` · Versão/build: `0.2.0`
Status: **com-pendencias** — implementação e testes em WordPress isolado concluídos; implantação no Site-Teste compartilhado bloqueada pela revisão automática de aprovação.

**Relatório externo canônico.** A cópia dentro do fonte é identificada como anterior ao fechamento e não contém seu próprio hash. A identidade final do fonte está na seção 8 deste relatório; resultados, escopo e pendências são iguais aos da cópia interna.

## 1. De onde esta versão entra

Base direta aceita: Pipedrive **0.1.0**, instalador de 42.095 bytes, SHA-256 `3366d83ca8908e407a0736812d30b8fa1506a8c1458a28cfb47eda6fd8f3c54f`; fonte de 159.941 bytes, SHA-256 `bb06315b60a5b0a36c0458d9dcb000505e52b5f444278a3effb26414186a3f2c`. Não há versão intermediária. Foram provadas instalação limpa e atualização direta com o instalador final 0.2.0.

Escopo: **Pedidos MCP Pipedrive 2(a–d), Diário de operações sem prazo**, aberto em 26/10/2026 no documento recebido `Fator3 MCP Pipedrive(1).md`. O item 1 já consta como entregue e homologado na aba recebida; suas operações reais anteriores são evidências da frota, não testes desta rodada.

Considerados os fontes, instaladores e relatórios novos de Core 1.56.0, MCP 0.33.0 e Meta 0.12.0; a entrega anterior Pipedrive; e o impacto Pipedrive 0.1.0→Core, revisão 1. Identidades das entradas estão em `evidence/inputs.json`. As normas revisão 4 reanexadas foram comparadas com a revisão 5 vigente distribuída pelo Core; prevalece a revisão 5, inclusive a regra de registrar respostas/encerramentos no relatório principal, sem reemitir impacto apenas para encerrá-lo.

Requisitos executados: **WordPress 7.1.3, PHP 8.3.36 de 64 bits, MySQL 8.0.41/InnoDB**, criptografia OpenSSL e funções administrativas nativas. São os mínimos WordPress/PHP declarados. PHP CLI local 8.3.6 foi usado somente para lint e exportação de schemas; não é a versão da prova funcional. Empacotamento com Python 3.12.14, sem dependências Composer/npm.

## 2. Convivência e encaminhamentos

| Pacote | Versão examinada e ativa no laboratório integrado | SHA-256 do instalador de referência |
|---|---|---|
| Base Site Core Fator3 | 1.56.0 | `e9dd77379d64706ad37de2428dc91a02bdaeb0649f68b38d3024ffcaac4ebed9` |
| Fator3 MCP | 0.33.0 | `f16ee3e31e4143ffb42c566ea6da4f2da81d3771a01a0f90b5d34e3d02ac8caa` |
| Fator3 MCP Google | 0.19.0 | `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1` |
| Fator3 MCP Meta | 0.12.0 | `b519203886d0964fa531c70cd0a66e2f8e199ff04700f0c3c5fa946d6d83e880` |
| Fator3 MCP LinkedIn | 0.10.1 | `6182ea63bff6788f5d2637467e7ab29d58568e37283d6ece82d3e58ee41c13bc` |

A prova de convivência cobre carregamento simultâneo, descoberta do provider, permissões, documentação e contratos efetivamente usados. Não certifica funções sociais/comerciais alheias. Nenhum acompanhante foi modificado. Google e LinkedIn foram observados nas versões existentes; os novos pacotes recebidos nesta rodada foram Core, MCP e Meta.

**Desfecho do encaminhamento anterior:** `wp-mcp-pipedrive-fator3-0.1.0-impacto-base-site-core-fator3.md`, revisão 1, pedido Core 294 C1–C8 e Pipedrive 1, solicitava o cliente `pipedrive-api-client/1.0.0` ao mantenedor Core. O histórico recebido informa entrega desde Core 1.51.0. Nesta rodada, a inspeção do Core 1.56.0 e oito verificações com suas classes reais confirmaram registro, autorização, status sem HTTP, requisições, revisão/orçamento, repetição de recibo e sanitização no cenário coberto. **O bloqueio de contrato ausente da primeira entrega está superado para a integração examinada.** Não se declara nova homologação integral C1–C8/A1–A16 no fornecedor. O documento anterior permanece histórico; nenhum arquivo de impacto é reemitido para comunicar esse atendimento.

**Novos encaminhamentos: zero.** A política fica nas tabelas/options do Pipedrive. As duas rotas adicionais usam o registro e o gate de escrita existentes do MCP 0.33.0; não exigem adaptação em outro pacote. Foram avaliados contrato Core, transporte/autorização/documentação MCP, coexistência e limites de responsabilidade de Meta/Google/LinkedIn. Não foi identificado efeito técnico que exija pedido a outro mantenedor. A implantação e a conferência da conexão pela frota seguem como ações operacionais da seção 6.

## 3. Mudanças e evidência

| Pedido exato | Problema anterior | Mudança entregue | Evidência e estado |
|---|---|---|---|
| 2(a): prazo configurável por MCP/painel, opção e padrão sem prazo | Diário fixo em 180 dias, sem configuração | `diario_dias=0` significa sem prazo; 1–36.500 dias é escolha explícita. Novas rotas `pipedrive/retencao-ler` e `pipedrive/retencao-configurar`; formulário administrativo | `implementado`, `validado-wordpress`: padrão, persistência relida, revisão, autorização, nonce, POST e reativação |
| 2(b): recibo pode expirar sem eliminar a linha técnica | Exclusão do diário vinculada ao recibo | Recibos cifrados continuam em 180 dias; exclusão do diário depende exclusivamente da política própria | `implementado`, `validado-wordpress`: recibo vencido removido e linha com 400 dias preservada após prévia e aplicação |
| 2(c): status mostra prazo em vigor | Política ausente no status | `pipedrive/status.data.retencao` informa diário, sem prazo, recibos, prévias e revisão, inclusive quando Core está indisponível/não autorizado | `implementado`, `validado-wordpress`: status sem HTTP e sem criar configuração |
| 2(d): atualização preserva linhas existentes | Risco de limpeza/redefinição na troca | Atualização/ativação não expurga, não regrava registros e não troca escolha explícita; ausência de opção assume sem prazo | `implementado`, `validado-wordpress`: atualização nativa 0.1.0→0.2.0 preservou três operações e duas linhas antigas byte a byte |

Nova opção própria `f3_pipedrive_retention`, JSON, autoload desativado. Ausência não exige gravação: leituras são observacionais. A configuração exige `manage_options`, revisão esperada e `confirmar_expurgo=true` para prazo finito. Usa comparação atômica, geração de revisão que detecta alterações intermediárias, releitura do valor persistido e trava MySQL compartilhada com a limpeza. Revisão desatualizada, trava indisponível ou política corrompida falham sem expurgo. O painel usa nonce e o mesmo dispatcher das rotas.

Salvar a política não chama o fornecedor nem remove registros naquele momento. A limpeza continua sob demanda em prévia/aplicação, sem cron. Prazo finito utiliza a data UTC original. Tentativas `running` e suas linhas permanecem para reconciliação; payload expirado é esvaziado. Prévia continua válida por 900 segundos. Recibos duram 180 dias desde a criação da prévia; após expirar, a linha técnica permanece conforme a política, mas a resposta privada deixa de ser reproduzível.

Preservados slug, basename, provider, namespace REST `f3-pipedrive/v1`, seis rotas anteriores, tabelas e schema 1. Passam a existir oito rotas. Configuração é escrita local para o gate MCP; não concede autorização comercial no Core. Sem token, cliente HTTP, orçamento ou reparo de configuração Core próprios. Documentação instalada atualizada e schemas exportados do código.

## 4. Instalação e prova da troca

**Instalador final:** SHA-256 `b7065e4780cbc2166605164e4a822338b76627bef48c5f05a9fb9c3505efbb4a`; os 21 arquivos coincidem com os hashes da instalação testada. Instalado e ativado via `Plugin_Upgrader` em WordPress descartável; atualização da 0.1.0 também pelo mecanismo nativo, com conferência em processo PHP novo.

| ID | Ambiente/cenário | Resultado | Evidência no fonte | Limite |
|---|---|---|---|---|
| T1 | WordPress limpo, instalação nativa | Aprovado, versão 0.2.0/schema 1 | `current-install.json` | Banco/diretório isolados |
| T2 | Operações, transações, REST, permissões e disputa de prévia em dois processos | **76/76** | `current-native.json` | Cliente controlado; sem fornecedor |
| T3 | Retenção, diário de 400 dias, recibos, prazo finito, revisão, corrupção, trava em outra conexão, painel/nonce | **33/33** | `current-retention.json` | Painel executado por PHP nativo; sem inspeção visual de navegador |
| T4 | Executor/política originais MCP 0.33.0 e cinco acompanhantes | **25/25** | `current-integrated.json` | Executor em WordPress isolado; não sessão HTTP MCP externa da 0.2.0 |
| T5 | Cliente original Core 1.56.0, prévia/aplicação/recibo e orçamento | **8/8** | `current-core.json` | Credencial/respostas sintéticas; três chamadas interceptadas, nenhum HTTP ao fornecedor |
| T6 | Atualização nativa 0.1.0→0.2.0 e preservação byte a byte | **9/9** | `upgrade-upgrade.json`, `upgrade-verify-upgrade.json` | Três operações e duas linhas de 400 dias sem dados comerciais |
| T7 | Política de 730 dias em novo processo e reativação | **2/2** | `upgrade-upgrade-restart.json` | Banco isolado |
| T8 | Lint, schemas, raiz/CRC, conteúdo, igualdade com runtime testado e reprodução byte a byte | **37/37** | `static-build.json` | Lint em 20 arquivos PHP, dos quais 11 de runtime; não substitui testes funcionais |
| T9 | Sobrescrever/ativar no Site-Teste compartilhado | **Bloqueado antes da execução** | `shared-install.json` | Revisão automática exigiu autorização explícita para a implantação |

**Total funcional final: 153 verificações aprovadas, zero falhas.** As 37 verificações estáticas são contadas separadamente; setup, tentativas preliminares e sondas HTTP não entram no total. Todos os processos finais das baterias retornaram exit code 0 e stderr vazio. Ajustes preliminares foram no harness: includes administrativos ausentes, marcador de isolamento de worker e repetição indevida de suíte que exigia banco limpo. As baterias finais foram executadas em estado apropriado; detalhes em `tests/README.md`.

**Documentação:** nove documentos instalados, consultados integralmente em 23 páginas pela operação `pipedrive/documentacao-ler`, passando pelo executor original MCP 0.33.0. Índice, allowlist, versão 0.2.0 e SHA-256 de cada texto conferidos contra os arquivos. `docs/schemas.json` coincide com a exportação de `build/schemas.php`. Nenhuma consulta documental chamou fornecedor. Evidência em `current-integrated.json`; sessão MCP externa no site compartilhado permanece pendente.

**Critério de aceite do item 2:** linha com 400 dias permaneceu byte a byte após prévia e aplicação, e o status exibiu sem prazo. Isso foi comprovado em WordPress real isolado no hospedeiro de testes, inclusive com o cliente original Core e HTTP sintético. O mesmo aceite na instalação compartilhada do Site-Teste ainda não foi executado.

**Procedimento para a implantação autorizada:** preservar banco e salts, conferir a identidade da seção 8, usar `expected_slug=wp-mcp-pipedrive-fator3` e `expected_sha256` do instalador final. Sobrescrever e ativar somente Pipedrive. Conferir `pipedrive/status {}` e `pipedrive/retencao-ler {}`: `diario_dias=0`, `diario_sem_prazo=true`, `recibos_dias=180`, `previas_segundos=900`, salvo escolha explícita preexistente. Core sem concessão pode retornar `operacao_nao_autorizada`; isso não impede ler a política local e não deve ser corrigido ativando operação comercial por inferência. Conferir documentação e permissões da conexão. Mudanças de versão/configuração Core podem invalidar vínculos de prévias anteriores; gerar nova prévia após a atualização quando necessário, sem reenviar operação incerta.

**Publicação raw:** não realizada. URL prevista após publicação pela frota, ainda não comprovada: `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/wp-mcp-pipedrive-fator3-0.2.0-instalador.zip`. Nesta entrega, usar o arquivo fornecido ao dono; não presumir que a URL já sirva estes bytes.

**Estado final do Site-Teste:** Pipedrive **0.1.0 permanece ativo**; Core 1.56.0, MCP 0.33.0, Google 0.19.0, Meta 0.12.0 e LinkedIn 0.10.1 permanecem ativos e inalterados. Inventário de nove plugins igual antes/depois; saúde aprovada em 11 verificações. As duas tabelas Pipedrive compartilhadas tinham zero linhas antes/depois; hashes das opções de schema/autorização Core permaneceram iguais. Isso prova preservação do estado observado, não preservação de linhas antigas no banco compartilhado; esta foi provada no laboratório.

Limpeza: removidos os dois diretórios descartáveis e **103 tabelas de laboratório** (89+14); consulta independente retornou zero tabelas remanescentes com os prefixos exclusivos. Bundle/controlador temporários removidos com backup pelo mecanismo do MCP; ability temporária ausente; sondas internas de home e REST com HTTP 200 antes/depois. Backups geridos pelo MCP ficam sob a política desse pacote. Evidências: `current-cleanup-final.json`, `upgrade-cleanup-final.json`, `zero-tables.json`, `shared-state.json`. Nenhuma chamada real ao Pipedrive, mensagem, e-mail ou publicação foi feita nesta rodada.

## 5. Banco e volta de versão

Continuam as tabelas próprias `{prefix}f3_pipedrive_operations` e `{prefix}f3_pipedrive_journal`, schema 1, sem migração destrutiva. Atualizar arquivos não executa limpeza. Nova opção só é criada ao salvar uma escolha; reativação/reinstalação preserva essa escolha. Desativação/desinstalação preservam registros e não chamam a API.

O diário permanente contém metadados técnicos: caminho/IDs, classe, status, chaves alteradas e saldo; não guarda conteúdo de nota ou valor de campo pessoal. O recibo privado cifrado é separado e pode conter resposta do fornecedor. Backup deve incluir banco e salts WordPress para sua decifragem. Não há banco, wp-config ou credenciais reais no fonte entregue.

Escolher prazo finito autoriza exclusão futura pela data original; voltar a zero ou ampliar prazo não restaura linhas já apagadas. Restaurar somente arquivos também não desfaz opções, exclusões nem efeitos externos. Operações incertas não devem ser resetadas/repetidas sem reconciliação.

**Reverter para 0.1.0 exige cuidado concreto:** o código anterior ignora a nova política e pode apagar diário com mais de 180 dias na próxima prévia/aplicação. Interromper operações antes da reversão, preservar backup do banco e preferir correção adiante. Não há promessa de que a restauração do ZIP antigo preserve a nova retenção.

## 6. O que permanece pendente

| Pendência | Motivo/estado | Responsável/próximo passo |
|---|---|---|
| Instalar 0.2.0 e executar aceite no Site-Teste compartilhado | `bloqueado`: revisão automática rejeitou overwrite+ativação por não reconhecer autorização clara para essa implantação, considerando risco de indisponibilidade/estado persistente | Dono autoriza essa atualização; responsável Pipedrive/frota executa com hash e conferência antes/depois |
| Sessão HTTP MCP externa da 0.2.0 e permissões das novas rotas na conexão efetiva | `pendente`: produto compartilhado permaneceu 0.1.0; executor/política foram testados no laboratório | Responsável pela implantação confere descoberta, status, leitura/configuração e documentação na conexão autorizada |
| Inspeção visual completa do painel | `pendente`: Chromium indisponível; renderização PHP, POST, nonce e política passaram | Responsável Pipedrive/frota confere formulário no navegador após implantação |
| Nova homologação de operações no fornecedor | `nao-aplicavel` ao aceite local de retenção; não executada nesta rodada | Homologação histórica recebida pertence à 0.1.0; não extrapolar para nova prova comercial |
| Publicação e atualização dos sites-porta | `pendente`, não incluídas nas ações executadas | Frota, conforme autorização do dono; conferir SHA-256 antes de instalar |

Não foi alterada a aba central de pedidos para dar baixa no item 2. Seu revisor deve considerar a implementação/prova isolada e a pendência explícita do aceite no Site-Teste. Instalação limpa, atualização direta e mínimos WordPress/PHP foram testados; não há suporte declarado a multisite nesta versão. Compatibilidade com versões de banco diferentes de MySQL 8.0.41 não foi exercitada.

## 7. Credenciais e configuração do dono

Não há credencial nova. Token/conta, autorização e orçamento continuam no Core, por sua tela e contrato público; nenhum valor secreto é solicitado no chat ou incorporado no plugin. A atualização não habilita operação comercial nem altera consumidores autorizados. O documento recebido informa os sites-porta korvena.net.br e korvena.com.br autorizados pelo dono na rodada anterior; não foram acessados/modificados nesta rodada.

Para retenção: **Ferramentas → Fator3 MCP Pipedrive → Retenção do diário de operações**. Deixar **0** para sem prazo; prazo positivo exige confirmação de expurgo futuro. Pelo MCP, ler `pipedrive/retencao-ler {}` e enviar `diario_dias`, `revisao_esperada` e, para prazo positivo, `confirmar_expurgo=true` a `pipedrive/retencao-configurar`. Conferir `persisted`, `changed` e a política retornada. Perfil somente de leitura não autoriza essa gravação; o administrador precisa também de `manage_options`.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | `wp-mcp-pipedrive-fator3-0.2.0-instalador.zip` | 48865 | `b7065e4780cbc2166605164e4a822338b76627bef48c5f05a9fb9c3505efbb4a` |
| Fonte | `wp-mcp-pipedrive-fator3-0.2.0-fonte.zip` | 186893 | `803617faeb4244d6bbf375d3fe11f4652973ee49432c92f5b505f9378f69e7ef` |

Somente o instalador é instalável: raiz `wp-mcp-pipedrive-fator3/`, 21 arquivos de runtime/documentação/licença. Fonte: raiz `wp-mcp-pipedrive-fator3-0.2.0-fonte/`, código, build determinístico, testes, evidências sanitizadas, entradas e esta cópia documental. Nenhum ZIP contém outro ZIP. Relatório externo canônico com a identidade final do fonte; o ZIP fonte não será reaberto para inserir seu próprio hash. Três artefatos principais, nenhum novo relatório de impacto.
