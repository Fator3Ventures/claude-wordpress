# Observações anteriores ao fechamento

Nenhuma destas observações ficou pendente no pacote entregue.

- Primeiro ensaio apontou regra antiga no leitor de auditoria de mutações. Corrigida para compartilhar classificação de campos/formatos e validada no HTTP e na leitura nativa.
- Revisão do diff encontrou referência à variável errada no novo ramo de redação por formato de SQL. Corrigida antes da instalação no Site-Teste. Caso específico passa com warnings convertidos em exceção no teste unitário e confere `sensitive_value` antes do transporte/exportação; nenhuma advertência inesperada nos ambientes finais.
- Inventário inicial de caminhos contava menção textual ao marcador em documentação. Ajustado para valores realmente transformados, marcadores integrais e mensagens diagnósticas; caso documental coberto.
- Harness do Core procurou saude no envelope externo; o payload sem success próprio fica em data. Ajustada apenas a leitura do teste. Contadores reais do Core foram conferidos no laboratório e no Site-Teste.
- Ambiente: executáveis em workspace não executavam diretamente; wrapper copiado para /tmp. Extração de lighttpd informou chown de diretórios de log/cache incompatível com o contêiner; binários/libraries íntegros, serviços loopback e testes finais funcionaram. Estes eventos não são erros do plugin.

A versão 0.31.0 foi fechada e instalada uma única vez no Site-Teste. Candidatos locais anteriores não são artefatos de entrega. As evidências 0310 contêm as verificações do instalador final; diretórios de outras rodadas permanecem históricos.
