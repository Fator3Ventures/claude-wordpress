# Fator3 MCP 0.36.0

Base direta0.34.0. Atende o impacto LinkedIn0.12.0→MCP, revisão1, referência Core323: auditoria central do consumidor comercial site-core-quality, preservando aquisição e todas as guardas de serviço. Matriz: Core1.59.0, Google0.22.0, LinkedIn0.12.0, Meta0.13.0 e Pipedrive0.3.0. Mínimos MCP WordPress7.1.2/PHP8.3.6; Pipedrive exige8.3.36.

Instale somente wp-mcp-fator3-0.35.0-instalador.zip. Código em fontes/wp-mcp-fator3, docs editáveis em docs, reprodução em tools/release0350/README.md. O relatório externo contém identidades finais, provas próprias e pendências. Documentos/evidências anteriores são histórico; system/guide expõe a documentação instalada atual.
