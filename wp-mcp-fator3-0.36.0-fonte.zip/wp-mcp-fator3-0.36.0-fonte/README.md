# Fator3 MCP 0.36.0

Base direta 0.35.0. Pedidos MCP 70 (logs DreamHost/www/Apache/amostras) e 74 (exclusão de usuários e diagnóstico sanitizado). Matriz: Core 1.59.0, Google 0.22.0, LinkedIn 0.12.0, Meta 0.14.0 e Pipedrive 0.3.0. Mínimos MCP WordPress 7.1.2/PHP 8.3.6.

Instalar somente wp-mcp-fator3-0.36.0-instalador.zip. Código em fontes/wp-mcp-fator3, documentação editável em docs, reprodução em tools/release0360/README.md, evidências atuais em evidencias/0360. Documentos e evidências anteriores são histórico. O relatório externo registra identidades finais e limites de validação.
