# Fator3 MCP 0.32.0 — política de sinais e correio do Core

Base direta 0.31.0. Trata impacto Core 1.53.0 revisão 2, pedidos Core 300 e 301 atualizado. A política f3base_formularios_sinais preserva regras token_* somente em caminhos publicados, aceitando exatamente suspeito/aviso booleanos. Outros caminhos, senhas e tokens reais continuam redigidos. Linhas alternativas, revisão e contagens são preservadas. Regras inválidas recebem marcador e caminho no envelope MCP.

Caminhos: avisos/sinais_formularios/regras; assuntos/N/sinais_formularios/regras (com option exata); opcoes/f3base_formularios_sinais/{valor,padrao_declarado,valor_efetivo,valor_bruto}. Prévia antes/depois/lido exige nome=f3base_formularios_sinais no mesmo objeto. Até dois envelopes data são reconhecidos. Sem identificação da option, lido permanece conservador: releia por f3base/config-core-ler. Limites e formatos em redacao.

Novas abilities de correio pertencem ao Core. Descubra schemas atuais; Manutenção permite a escrita no canal, mas f3base/email-enviar exige também f3base_enviar_email e f3base_ler_leads. O MCP não atribui essas capacidades. Registros privados exigem f3base_ler_leads. Enviar usa record_id, assunto, texto, simular e revisão; não aceita destinatário livre. Uma falha/recibo incerto não comprova ausência de efeitos: não trocar a revisão/chave para forçar repetição. Preserve o código de domínio e reenvio_automatico=false.

Não habilita conta de correio nem faz homologação SMTP/IMAP. Nenhuma migração, credencial, ability nova do MCP ou modificação dos acompanhantes. Atualizar por plugins/upload com hash/slug; verificar versão, saúde e documentos em nova requisição. Rollback para 0.31.0 reintroduz a redação das regras; backup de arquivos não reverte banco ou efeitos externos.

### Pendência de autorização no Core 1.53.0

O Core exige as capacidades de envio/leitura no callback executivo, mas seu permission_callback admite manage_options. Com uma chave de idempotência já usada, um administrador cuja capacidade foi revogada pode receber novamente a prévia/recibo anterior. Não ocorre novo envio, porém a revogação não bloqueia essa leitura em cache. Até o Core alinhar seu permission_callback aos gates efetivos, revogue a conexão MCP ou retire a ability do perfil para bloquear o acesso, sem trocar chaves para forçar envio. Essa revogação operacional é explícita; a atualização MCP não a realiza automaticamente. Encaminhamento ao mantenedor Core no relatório da rodada.
