# Fator3 MCP 0.31.0 — Pedido MCP 67

Base direta: 0.30.1. Redação por nomes completos/componentes, formatos de credencial e tipos diagnósticos. `passagens`, `passagens_24h`, `contagem_passagens`, `bypass`, `checks_passed`, `secretaria` e `tokenization` deixam de ser confundidos com segredos. Senhas, tokens de acesso, cookies, chaves privadas e credenciais continuam protegidos.

O transporte JSON inclui `_meta["fator3/redaction"]` com caminhos JSON Pointer relativos a `structuredContent`, total e indicação de truncamento. Nenhum campo adicional é inserido no objeto de negócio. Detalhes e limites em `redacao` no system/guide.

Nenhuma rota nova, alteração de permissão, configuração ou banco. Acompanhantes considerados: Core 1.52.1, Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1 e Pipedrive 0.1.0. Sem requisito novo de atualização conjunta.

Atualizar pelo mecanismo nativo/`plugins/upload`, conferindo SHA-256 e slug. Confirmar versão e saúde em nova requisição; consultar diagnósticos e documentação. A volta a 0.30.1 reintroduz falsos positivos; backups de arquivos não revertem auditorias ou operações de banco.
