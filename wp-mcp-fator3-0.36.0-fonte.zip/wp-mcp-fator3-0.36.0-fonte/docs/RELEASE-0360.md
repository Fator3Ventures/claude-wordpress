# Fator3 MCP 0.36.0 — logs da hospedagem e exclusão de usuários

Base direta 0.35.0. Pedidos MCP 70 (reduzido) e 74 de 28/10/2026. Mínimos mantidos: WordPress 7.1.2/PHP 8.3.6. Matriz: Core 1.59.0, Google 0.22.0, LinkedIn 0.12.0, Meta 0.14.0 e Pipedrive 0.3.0. O relatório externo informa as combinações efetivamente testadas e o estado do Site-Teste.

## Pedido 70 — logs DreamHost

`system/error-log` procura o domínio exato de home_url e, se começar com `www.`, também o domínio sem esse prefixo inicial. O domínio exato tem preferência nos ancestrais suportados. Não procura domínios arbitrários e uma recusa de acesso não autoriza tentar outro caminho. As mesmas restrições de `files/read`, raiz, usuário e perfil permanecem. Nenhuma opção, symlink ou pasta da hospedagem é alterada.

Além do PHP, o leitor reconhece Apache 2.4 e o envelope DreamHost `[data] [domínio] [warn/error] [client ...] [pid ...] módulo.c(linha): ...`. Para `mod_fcgid: stderr:`, extrai a mensagem depois de stderr; mensagens Apache como AH01276 também formam grupos. Quando há nível explícito PHP, ele prevalece: PHP Warning dentro de envelope Apache error continua warning.

Filtros/saída `level`: fatal, warning, notice, deprecated, error, critical, alert, emergency, info e debug. Apache warn→warning, crit→critical, emerg→emergency e trace1–8→debug; os demais são preservados. Fatal/Parse error PHP→fatal. Os grupos continuam por nível/mensagem normalizada/arquivo/linha, com contagem e primeiro/último instante no fuso do site. Datas Apache sem offset continuam interpretadas em America/Los_Angeles, incluindo horário de verão; não adivinhar o offset de uma hora repetida sem informação no arquivo.

Ao lado de `unparsed_lines`, `unparsed_samples` contém até 3 exemplos (`source`, `line`, `sample`). A origem é só o nome do log. A amostra é mascarada antes do corte: credenciais identificáveis, valores conhecidos de senha/salts, textos entre aspas, URLs, e-mails, IPs, cookies, valores opacos longos e trechos de SQL/stack. São fragmentos diagnósticos autorizados, não log bruto nem garantia de classificar todo texto pessoal arbitrário.

`unparsed_scope: scanned_files` deixa explícito que contagem/amostra de linhas não reconhecidas cobrem os arquivos examinados, pois nem todas têm data interpretável. Filtros de período/nível/texto regem os grupos reconhecidos; a amostra não é uma contagem de incidentes no período. Até256 bytes JSON por exemplo e três exemplos, dentro do limite total de 8 KiB por página. Não aumentar amostras para obter um dump.

Exemplo: `{"since":"2026-10-28T00:00:00-03:00","until":"2026-10-29T00:00:00-03:00","level":"warning"}`. Sem datas, últimas24 h. since inclusivo/until exclusivo. Para Apache nativo, usar level error quando pertinente. Página seguinte usa next_cursor com os mesmos filtros; cursor anterior à 0.36 é recusado e deve ser reiniciado.

Mantidos gzip/CRC de todos os membros, até 128 arquivos,32 MiB expandidos,16 MiB comprimidos por arquivo,5 s,5000 grupos e 31 dias por consulta. Alteração de arquivo/inventário invalida paginação. Falha/limite não devolve contagem parcial como completa. O aceite real com `.gz` na janela e host www depende do site atualizado da frota.

## Pedido 74 — users/delete

A operação carrega `wp-admin/includes/user.php` quando `wp_delete_user` ainda não existe. O carregador administrativo compartilhado também passa a verificar essa função; `wp_create_user` já existir não comprova disponibilidade da API de exclusão.

Fluxo normal: chamar `users/delete` com `id` e `delete_content:true` ou `reassign_to` válido; examinar a prévia; repetir a mesma intenção com `confirm_token`. A confirmação permanece vinculada à conexão, alvo e pré-imagem, por 600 s. Permissões WordPress e perfil são reavaliados, e alteração posterior produz conflito. Preservam-se backup privado, locks e replay da confirmação concluída. delete_content:true usa a política nativa do WordPress: posts podem ir à lixeira; não impõe exclusão física adicional. O operador pode consultar `audit/list` pela operação devolvida; registros de users/delete preservam os indicadores applied/persisted e o estado de releitura quando fornecidos.

Após sucesso nativo, o MCP limpa o cache e relê o estado: `applied`, `changed` e `persisted` true apenas com remoção confirmada. Retorna id, user_exists e deletion_scope. Em site único, o usuário deixa de existir; em multisite, a API nativa remove a participação no site e pode conservar a conta da rede (`deletion_scope:site_membership`). Homologação multisite depende de ensaio próprio; não altera a semântica nativa.

Falhas têm códigos `user_delete_failed`, `user_delete_exception` ou `user_delete_unconfirmed`. A mensagem preserva um trecho real, sanitizado e limitado, sem stack/consulta SQL. `user_exists` informa a releitura quando disponível. Exceção em hook pode ocorrer antes ou depois de efeitos: `applied:null`, `persisted:null` e `retryable:false` não autorizam repetição automática. A mesma confirmação reproduz o recibo; reconciliar estado antes de criar outra intenção. O tratamento genérico de exceções das outras abilities não foi ampliado.

Nunca excluir a própria conta, trocar para SQL direto para contornar a confirmação ou apagar histórico para repetir. Backup de usuário contém dados sensíveis e não desfaz automaticamente hooks ou efeitos externos. O pedido foi reproduzido com usuário sintético, e o relatório identifica o teste remoto próprio.

## Atualização e reversão

Sem tabela, option, migração, credencial ou concessão nova. Upgrade direto0.35→0.36 preserva políticas, tokens, recibos e backups. Reverter arquivos para0.35 restaura as limitações dos pedidos 70/74; não restaura usuário/conteúdo excluído e não desfaz hooks. Guardar pré-imagem e consultar o plano de recuperação antes de reverter. Os pedidos 69/71/72/73 e a auditoria comercial0.35 continuam vigentes.

Meta 0.14.0 altera internamente o formato de token admitido e mantém os contratos públicos; não exige troca coordenada adicional do MCP. Validade comercial continua dependente de prova remota do próprio Meta. Não há autorização automática de fornecedor, publicação ou implantação nos demais sites.
