# Plano — Fator3 MCP 0.31.0

Revisão 1 · 25/10/2026 · America/Sao_Paulo · implementação.
Base aceita: wp-mcp-fator3 0.30.1, instalador SHA-256 `4dbe9ea5e3c9c2bc6ef5aaa574800e482226f0f1406e87a4fd818c68aa7260da`. Alvo 0.31.0; instalador ainda não gerado neste planejamento.

Pedido MCP 67: remover falsos positivos de substring (passagens), preservar diagnósticos tipados, manter segredos protegidos em resultados/erros/auditoria e expor caminhos mascarados. Entrada: impacto Core 1.52.1 para MCP, revisão 1. A resposta ao impacto será registrada no relatório principal; sem encaminhamento técnico novo a outro mantenedor. Metadado de transporte aditivo, sem exigir adaptação dos acompanhantes.

Escopo: classificador de nomes completos e componentes delimitados/camelCase; exceções diagnósticas somente com nome e tipo reconhecidos; reconhecimento conservador de formatos de credencial; caminhos JSON Pointer em `_meta["fator3/redaction"]`, fora do payload de negócio. Preservar esquemas, confirmações, idempotência, perfis e guardas de SQL/configuração. Nenhuma rota nova, migração de banco, execução PHP ou operação de frota.

Acompanhantes: Core 1.52.1, Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1, Pipedrive 0.1.0. Conferir integridade dos pacotes, descoberta e interfaces disponíveis. Não executar fluxos comerciais externos.

Provas planejadas: matriz de falsos positivos/segredos/tipos/serialização/esquemas/caminhos; instalação limpa nos mínimos declarados; atualização direta 0.30.1 → 0.31.0; regressões de autorização, SQL, CIMD, idempotência, mídia e documentação. Site-Teste: reproduzir antes, atualizar apenas MCP e comprovar passagens numéricas visíveis e password/token mascarados. Leitura integral dos documentos instalados. Installer fechado antes do fonte; relatório externo contém identidade final do fonte.

Pedido 66: documento central atualizado registra aceite em AWN e atualização dos 12 sites à base 0.30.1. Evidência recebida, sem repetir execução na frota.
