# Fator3 MCP 0.35.0 — auditoria de conversões comerciais

Base direta 0.34.0. Mínimos mantidos: WordPress7.1.2/PHP8.3.6. Entrada: impacto LinkedIn0.12.0 → MCP, revisão1, referência Pedido Core323. Acompanhantes examinados: Core1.59.0, Google0.22.0, LinkedIn0.12.0, Meta0.13.0 e Pipedrive0.3.0. O relatório externo distingue matriz local, observação no Site-Teste e aceites de fornecedor.

## Comportamento

O schema de identidade de `mutation-service-audit/1.0.0` passa a admitir exatamente dois consumidores: `site-core-conversions` (aquisição) e `site-core-quality` (etapas comerciais). A allowlist é compartilhada pelo evento, recibo e leitor `audit/get-service-operation`. O Registro preserva o consumidor original no rótulo e na consulta do detalhe. Não há alias comercial para aquisição nem consumidores arbitrários.

O LinkedIn0.12.0 publica o mesmo descritor, hook, leitor e introspector previstos pelo contrato e já aceita ambos os consumidores. Mantêm-se origem física dos pontos públicos, provider e schema fechado, prova corrente da concessão, identidade completa, digest exato e persistência confirmada. A referência continua técnica: não recebe payload, contato, hash de e-mail, li_fat_id ou credencial. O envio permanece no produtor e não depende de sucesso no Registro.

O serviço pode emitir como usuário WordPress zero. Ler recibo exige administrador autorizado, perfil/ability aplicáveis e propriedade/concessão corrente no produtor; a emissão não concede acesso administrativo. Referência/revisão alterada, concessão revogada, consumidor forjado ou digest divergente continuam recusados. Repetição confirmada/incerta não reenvia nem duplica a referência.

## Uso e aceite

Depois de uma operação comercial autorizada, confirme no recibo LinkedIn `central_audit:"recorded"`. Consulte o Registro ou `audit/get-service-operation` com provider `wp-mcp-linkedin-fator3`, consumer_id `site-core-quality` e os valores exatos de principal_ref, grant_revision e operation_id devolvidos pelo produtor. Não remonte referências e não substitua o consumidor.

O recebimento do hook não basta: o produtor só pode afirmar recorded quando o consumidor central confirma o mesmo digest persistido. A leitura exibe snapshots técnicos via leitor público do produtor e informa `reference_current`; ela não envia conversão, cria concessão ou modifica a fila Core. Não há rota MCP para emitir artificialmente evento ou registrar descritor.

LinkedIn0.12.0 pode preceder esta atualização. Até o MCP0.34.0 o diário comercial permanecia local com `service_record_unconfirmed`; a partir desta versão pode receber confirmação central. Eventos antigos não são importados, reenviados nem reemitidos automaticamente. Esta mudança não implementa a reconciliação Google, que pertence ao Core1.59.0/Google0.22.0.

## Instalação, dados e reversão

Instale somente o ZIP instalador0.35.0. Confirme versão/saúde, descritor de serviço registrado, schema contendo os dois consumidores e documentação instalada. Instalação não concede ações, configura contas ou homologa fornecedor real.

Sem tabela, option ou migração de dados nova. Contratos mutation-service-audit/1.0.0 e linkedin-service-mutation/1.0.0 mantidos; ampliação aditiva de enum. Upgrade direto0.34→0.35 preserva credenciais, perfis, diário e referências existentes. Ao voltar arquivos à0.34, referências comerciais já persistidas continuam no banco, mas o leitor dessa versão não admite o consumidor. Preserve pré-imagem e diários; rollback de arquivos não reverte envio externo.

A validação usa WordPress e produtores originais, com transporte de fornecedor sintético. O relatório registra instalação limpa/upgrade, casos negativos, painel, aquisição anterior e duas ações comerciais. Aceite de conta real pertence ao operador. Os pedidos69–73 permanecem; o aceite de `.gz` em um site da frota segue separado da implementação desta rodada.
