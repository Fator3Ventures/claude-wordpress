# Redação de segredos e diagnósticos — contrato 1

## Regras

1. Nomes completos e componentes separados por delimitadores ou camelCase: pass/password/passwd/pwd, senha, secret/segredo, token, credential/credenciais, cookie, authorization, salt, chave; famílias api/private/auth/activation/access/consumer/client/encryption/signing key. Plurais e nomes legados concatenados conhecidos são reconhecidos. Não procurar `pass`, `secret` ou `token` dentro de qualquer palavra.
2. Campos diagnósticos com componente secreto somente permanecem públicos quando terminam em configured/present/available/valid/expired/enabled/verified e são booleanos; count/total/generation/revision/age_seconds/expires_in/ttl_seconds e são números finitos não negativos; created_at/updated_at/expires_at/expired_at/issued_at/checked_at e contêm data ISO. Nome secreto simples, como password ou token, continua mascarado mesmo com valor numérico/booleano. Tipos errados não ganham exceção.
3. `credential` é um contêiner fechado: somente configured booleano é público. Tokens de confirmação de 64 dígitos hexadecimais em confirm_token/confirmation_token continuam utilizáveis; não são credenciais de autenticação.
4. Valores completos com formato Authorization/Bearer/Basic, JWT ou chave privada PEM são mascarados mesmo sob nome neutro. Textos de erros/logs também ocultam Bearer/Basic embutidos. Não usar entropia para classificar hashes, UUIDs, revisões ou cursores; não se promete identificar segredo opaco sem nome ou formato reconhecível.
5. Schemas preservam nomes/descritores; defaults/examples de propriedades secretas são mascarados. SQL conserva proveniência de coluna, proteção de option_value/meta_value com origem desconhecida e filtro adicional de sensibilidade. Guardas de escrita/configuração não recebem as exceções de apresentação.
6. Redação é uma cópia de apresentação: não usar em recuperação, comparação de revisões, persistência de credenciais ou recibos de idempotência. Auditoria registra somente sua projeção habitual, agora sanitizada antes da persistência; não passa a guardar argumentos ou resultados brutos.

## Caminhos no transporte

Respostas JSON de tools/call incluem `_meta["fator3/redaction"]`: contract=fator3-redaction/1, path_format=json-pointer, scope=structuredContent, paths, total, truncated, includes_existing_markers=true. Caminho vazio representa a raiz; `/` e `~` de nomes viram `~1` e `~0`. Exemplos: `/data/rows/0/password`, `/data/error_details/access_token`.

paths lista até 256 posições e 16 KiB acumulados de caminhos. total conta as posições redigidas ou com marcador integral/diagnóstico preexistente; truncated informa omissões. Inclui valores integrais `[redigido]` e marcadores preexistentes em mensagens diagnósticas, inclusive fornecidos pelo provedor, portanto não atribui ao MCP a origem de todo marcador. Uma menção literal ao marcador em texto documental não é contada como campo mascarado. Metadados são externos ao objeto de negócio, não alteram schemas fechados e não contêm os valores ocultos. Clientes que descartam `_meta` devem consultar o envelope MCP original; `db/query` também conserva seu campo redacted com coluna/origem/motivo.

O inventário cobre resultados JSON e erros de execução de ferramentas. Não transforma conteúdo binário de imagens/recursos em JSON nem modifica arquivos de negócio. Falhas de protocolo anteriores à execução continuam com mensagens genéricas. Autorização é obrigatória; redação de apresentação não constitui isolamento contra inferência SQL.

## Falsos positivos a verificar

`passagens`, `passagens_24h`, `contagem_passagens`, `bypass`, `checks_passed`, `all_checks_passed`, `cache_bypass_verified`, `secretaria`, `tokenization`, hashes/revisões, booleanos de configuração, contagens e datas diagnósticas. Conferir também senha/token/cookie reais sintéticos, camelCase, credencial numérica, tipo indevido, JWT/PEM/Bearer, caminhos escapados e truncamento.

## Exceção da política do Core — 0.32.0

Somente os caminhos publicados em release-0320 aceitam regras de f3base_formularios_sinais. Cada linha deve ter exatamente suspeito e aviso booleanos, nome [a-z0-9_]{1,80}, até 100 sinais. Não há coerção. Strings, nulos, números, objetos customizados e chaves extras não recebem exceção; linha inválida é mascarada por inteiro. Não basta encontrar token no nome ou um par de booleanos em outro caminho. Senha, token real, auditoria, SQL e guards permanecem protegidos. As duas representações JSON do transporte usam a mesma cópia sanitizada. Esquemas mantêm seus caminhos durante a travessia; um default ou exemplo não ganha a exceção por reproduzir o formato da política.

## 0.33.0 — Pedido MCP 68

O contexto mínimo da chamada resolvida complementa o reconhecimento pelo dado. Em f3base/config-core-escrever com nome=f3base_formularios_sinais, lido mantém as regras tipadas mesmo sem nome na resposta. O contexto não é persistido, não muda autorização nem vem de propriedades da resposta. Executores genérico/de leitura e exposição direta usam a mesma decisão; parâmetros objeto ou JSON codificado são reconhecidos.

A leitura de instrumentação preserva token_indisponivel somente como texto de interface nas duas projeções formularios/N/complemento/mensagens, com até 1000 caracteres. Leitura de configuração preserva opcoes/NOME/chaves_herdadas como lista de até 4096 caminhos de até 1024 bytes, ou null legítimo. Valores inválidos e segredos reconhecíveis são redigidos. Não se abre qualquer nome chave/token globalmente. Casos mascarados mantêm caminhos JSON Pointer e paridade texto/structuredContent; contratos completos em RELEASE-0330.md.
