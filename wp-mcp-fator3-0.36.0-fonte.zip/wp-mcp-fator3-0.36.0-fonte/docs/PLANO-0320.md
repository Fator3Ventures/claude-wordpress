# Plano — Fator3 MCP 0.32.0

Revisão 1 · 25/10/2026 · America/Sao_Paulo · implementação.
Base aceita 0.31.0; instalador 883088 bytes, SHA-256 2285c633b5d11c9990bed376f17291612b44958b073e0db2489efac20c1ec4ef. Alvo 0.32.0; installer ainda não gerado no planejamento.

Entrada: impacto Core 1.53.0 para MCP, revisão 2; pedidos Core 300 e 301 atualizado. Normas revisão 5 preservadas. Fonte e installer aceitos do MCP verificados por hash; Core 1.53.0 já ativo no Site-Teste. Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1 e Pipedrive 0.1.0 permanecem atuais.

1. Exceção de apresentação para mapas de regras da option f3base_formularios_sinais em caminhos canônicos: avisos/sinais_formularios/regras, assuntos/N/sinais_formularios/regras e opcoes/f3base_formularios_sinais/{valor,padrao_declarado,valor_efetivo,valor_bruto}. Prévia de configuração somente quando nome identifica exatamente a option. Aceitar cada regra apenas com suspeito e aviso booleanos, sem coerção nem chaves extras; limite de 100 sinais e nomes conforme schema do Core. Outras posições sensíveis, SQL, auditoria e guards não ganham exceção global.
2. Conferir regras/linhas, configuração e as duas representações JSON do transporte. Preservar caminhos de campos mascarados, password/senha, tokens reais, schemas e confirmações; testar objetos, arrays, caminhos semelhantes e entradas inválidas.
3. Validar cinco novas abilities de correio, perfis do canal e capacidades WordPress próprias. Manutenção não concede f3base_enviar_email/f3base_ler_leads. Simulação, revisão, códigos de recusa e recibo incerto não podem virar envio concluído ou ser repetidos. Ensaios locais com contatos/recibos sintéticos e bloqueio de rede; Site-Teste apenas simulação de contato inexistente, sem SMTP/IMAP ou dados comerciais.
4. Instalação limpa no mínimo, atualização direta da base, convivência, regressões 67/OAuth/idempotência/mídia, documentação completa por MCP. Fechar installer antes do fonte; entregar fonte/installer/relatório.

Encaminhamentos novos: nenhum identificado nesta fase. O pedido recebido pode ser atendido no MCP sem alteração do Core; respostas/aceites serão registrados no relatório principal. Se surgir consequência própria a outro mantenedor, emitir impacto antes de implementar a fronteira correspondente. Nenhuma mudança de credencial, configuração comercial, rota de PHP, pacote alheio ou distribuição na frota.

## Achado durante a validação — revisão 2 do plano

Core 1.53.0 registra email-enviar com permission_callback manage_options OU capacidade de envio, mas exige envio E leitura de leads dentro do callback executivo. Um recibo de transporte reapresentado não executa esse callback; a revogação de capacidade do administrador não basta para recusar o recibo. O recebimento incerto continua sem repetição de SMTP. Encaminhar ação ao Core, dono dos gates de domínio, em wp-mcp-fator3-0.32.0-impacto-base-site-core-fator3.md. Reproduzir também com base MCP 0.31.0 e prévia privada, registrar falhas separadas das regressões próprias. Não copiar regras comerciais/capacidades Core para MCP, não reexecutar efeitos para tentar autorizar um recibo e não alterar pacote alheio. A correção de sinais é independente; a validação integral Core300 permanece com pendência.
