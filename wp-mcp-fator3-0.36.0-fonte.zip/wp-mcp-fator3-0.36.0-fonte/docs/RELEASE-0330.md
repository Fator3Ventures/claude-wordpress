# Fator3 MCP 0.33.0 — Pedido MCP 68

Base direta 0.32.0. Acompanhantes examinados: Core 1.54.0, Google 0.19.0, Meta/LinkedIn 0.10.1 e Pipedrive 0.1.0. Sem migração de dados, credenciais ou mudança de capacidades.

## Apresentação contextual

A resposta aplicada de f3base/config-core-escrever preserva lido da option f3base_formularios_sinais mesmo quando o Core não devolve nome. O transporte usa a ability efetivamente chamada e o nome enviado à operação; não insere campos no resultado nem conserva esse contexto entre chamadas. São aceitos apenas mapas de até 100 sinais com suspeito/aviso booleanos, exatamente como na 0.32.0. Uma resposta sem identificação no dado e sem contexto correspondente continua conservadora.

f3base/conteudo-instrumentacao-ler preserva token_indisponivel como texto de interface, até 1000 caracteres, em por_url/URL/formularios/N/complemento/mensagens e linhas/N/formularios/N/complemento/mensagens. Valores inválidos e credenciais reconhecíveis permanecem mascarados. A exceção não vale para qualquer campo token_* nem para SQL.

f3base/config-core-ler preserva chaves_herdadas em opcoes/NOME: lista de nomes de caminhos, inclusive vazia, ou null quando a leitura é indeterminada. Os nomes aceitam letras, números, sublinhado, hífen e segmentos separados por ponto; string vazia designa a raiz. Limites de apresentação: 4096 entradas e 1024 bytes por nome. Forma inválida, item não textual ou valor de segredo reconhecível recebe [redigido]. Listas fora dessa operação/caminho mantêm a proteção geral.

## Conferência

Descubra schemas atuais. Para testar uma gravação, leia a option, simule com valor e revisao_esperada atuais e aplique explicitamente com simular=false. Confira ok, persisted, lido e revisão; o Core não fornece changed nessa resposta. Repetir uma intenção mantém seus parâmetros e chave. A releitura continua útil para confirmar persistência. Simulação e aplicação usam chaves distintas quando uma chave de transporte é fornecida.

O envelope mantém _meta["fator3/redaction"], contrato fator3-redaction/1, paths em JSON Pointer, total/truncated e scope=structuredContent. Todo campo mascarado continua representado ali; a representação textual corresponde ao objeto estruturado. Pontes de conectores que removem _meta não demonstram ausência de máscaras: use o transporte MCP que exponha esse metadado. O canal não injeta caminhos em objetos de negócio.

Senha, token real, lista inválida e nomes fora dos contextos documentados continuam protegidos. A apresentação não modifica options, comparação, backup, recuperação, auditoria ou recibos internos. As permissões pertencem ao produtor e à política de conexão.

O Core 1.54.0 contém o alinhamento dos permission_callback de correio solicitado na 0.32.0; o resultado do reteste desta rodada é registrado no relatório externo. Não é homologação de SMTP/IMAP real. As observações históricas de autorização no documento release-0320 se referem ao Core 1.53.0.

Atualizar por plugins/upload com expected_sha256 e expected_slug, preservar o backup e conferir versão/saúde/documentos em nova requisição. Voltar para 0.32.0 restaura o mascaramento descrito no pedido 68. O backup de arquivos não reverte banco ou efeitos externos.
