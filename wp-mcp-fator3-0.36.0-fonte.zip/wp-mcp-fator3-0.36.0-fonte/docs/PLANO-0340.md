# Plano 0.34.0 — 28/10/2026

Base aceita: 0.33.0. Incremento minor para os pedidos MCP 69–73. Normas 01/02 revisão 5, idênticas às da base. Entradas: Core 1.57.1, Google 0.20.0, Meta 0.12.0, LinkedIn 0.11.0, Pipedrive 0.2.0; hashes no inventário de entradas. Alterações somente no MCP.

1. 69: projeção explícita de diagnósticos, resumo até 2 KiB, filtros de blocos e contagem de incidentes nas últimas 24 h. Explicitar cobertura quando o histórico anterior estiver saturado; não inventar contagens perdidas.
2. 70: leitor de logs por domínio, leitura limitada e paginação verificável; logs diários e gzip, horário America/Los_Angeles convertido ao fuso do WordPress; agrupamento e máscara antes da exposição. Sem caminho arbitrário ou escape das permissões de arquivos.
3. 71: recibo durável ligado à operação de pacote antes de efeitos, reconciliação somente por leitura em repetição, sem download/sonda/instalação. Chave conflitante recusada; timeout inicial de 1–30 s e duração medida. Preservar autorização atual e idempotência dos demais produtores.
4. 72: metadados na pré-imagem e auditoria, filtros de tipo/plugin/período; política package_preimages seleciona troca sucedida do mesmo plugin OU idade. Seleção congelada, referências ativas preservadas, tombstones duráveis e prevenção de reimportação.
5. 73: modo served anônimo sem marca de teste, assinatura ou query anticache; evidência e idade do cache somente quando observáveis. Preservar bypass e declarar alcance interno da sonda.

## Validação e entrega

Testes unitários, integração WordPress/MySQL/HTTP e regressões de autorização, redação, idempotência, recuperação, backups, cache e documentação; instalação limpa e atualização direta da base. Testar acompanhantes nas versões recebidas, respeitando piso PHP do Pipedrive.

No Site-Teste: atualização do próprio MCP após testes locais; conferir diagnósticos e documentação integral. Fixtures identificadas e removíveis: MU-plugin para warning, plugin QA sem funções de negócio para duas trocas e poda exclusivamente das suas pré-imagens, página de cache temporária. Não podar backups existentes do usuário, não modificar acompanhantes, não distribuir para a frota. A aceitação de gzip na frota será separada da cobertura local e ficará pendente se a nova rota ainda não estiver instalada ali.

Nenhum impacto técnico novo a outro mantenedor identificado na análise das entradas: as cinco versões já estão ativas no Site-Teste. Eventual achado concreto será registrado antes de solicitar mudança externa. Entregar instalador ZIP, fonte ZIP e relatório em português com hashes, evidência e pendências; congelar o fonte somente após finalizar instalador e relatório interno.
