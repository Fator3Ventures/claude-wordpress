## Verificação de pacotes

Contrato corrente 0.34.0: consulte RELEASE-0340.md para compact/fields, error-log, recibos de upload, metadados/política de pré-imagens e cache servido, conforme aplicável. As descrições anteriores permanecem válidas nos pontos não alterados.

`plugins/upload`, `plugins/upload-base64` e `plugins/update` aceitam `probe_timeout_seconds`, inteiro entre 1 e 30, padrão 15. O mesmo limite vale por requisição de ativação e por requisição da sonda posterior. Home e REST compartilham orçamento máximo de `min(45, 2*timeout+2)` segundos; ativação, staging e sonda inicial têm seus próprios tempos. Não é um prazo total da chamada. A sonda inicial permanece em 5 segundos: site já inconclusivo é recusado antes da troca. `system/probe` mantém o contrato geral de 1–10 segundos.

Após instalação completa, timeout, falha de transporte, HTTP 4xx, ausência da marca PHP ou divergência de versão/ativação produzem `package_verification_pending`, `applied:null`, `files_applied:true`, `pending:true`, `retryable:false`, `recovery_status:verification_pending`. Os arquivos candidatos, backup e diário são preservados. HTTP 5xx na sonda posterior ou falha de ativação concluída permitem recuperar a pré-imagem. HTTP 5xx do worker sem conclusão permanece inconclusivo. Corrupção estrutural da instalação continua tendo recuperação própria. Nenhum desses caminhos desfaz migrações de banco ou efeitos externos: `database_effects_reversible:false`.

Use o `package_operation_id` de 32 caracteres devolvido pela troca. Ele identifica o diário e é distinto de `operation_id` do executor/idempotência. `plugins/operation-status` lê apenas operações da mesma conexão; devolve estado, versão/ativação observadas, backup, `file_state`, estado da ativação e última evidência. Essa consulta não faz sondas nem conclui a operação. `success:true` nela indica sucesso da leitura. `plugins/reconcile` verifica hash, ativação e home/REST em nova requisição e conclui o diário apenas com prova efetiva. Possui as mesmas permissões de atualização e exige ativação quando necessária. Perfil personalizado deve conceder as novas habilidades explicitamente.

```json
{"ability_name":"plugins/operation-status","parameters":{"operation_id":"0123456789abcdef0123456789abcdef"}}
```

```json
{"ability_name":"plugins/reconcile","parameters":{"operation_id":"0123456789abcdef0123456789abcdef","probe_timeout_seconds":30}}
```

Uma ativação que ainda roda não é repetida. Somente uma ativação nunca reivindicada e com token expirado, ou ainda não solicitada, pode ser iniciada pela reconciliação. Ativação interrompida em `running` permanece pendente e requer avaliação operacional; não se presume que seus efeitos foram desfeitos. Mudança da pós-imagem bloqueia a reconciliação. Upload do mesmo plugin enquanto há diário não resolvido é recusado. Não reutilize a chave de idempotência do upload para reconciliar: a resposta anterior continua sendo um recibo, não uma nova observação.

A sentinela preserva `verification_pending` mesmo após expirar a lease. Executor abandonado depois de instalar a árvore inteira passa a pendente; interrupção estrutural durante renomeação continua recuperável. `plugins/rollback` permite recuperação explícita de uma troca pendente, com backup da própria conexão e hash da pós-imagem, e não troca arquivos durante ativação em execução. Essa escolha continua sem reversão de banco. Após rollback, a sentinela invalida o cache do PHP servidor durante uma janela de 60 segundos; isso cobre rollback iniciado em CLI, cujo OPcache é separado do FPM.

O diário e o executor possuem identidades separadas. A troca de pacote preserva os recibos atuais da 0.21.0, sem converter operações pendentes. Retorno de arquivos não equivale a retorno do banco ou de efeitos externos.


## Ativação com prova na 0.22.0

A intenção e o modo de ativação entram no diário assinado antes da troca de arquivos. `native_activation` executa o ciclo nativo WordPress em PHP independente quando o plugin era novo/inativo e activate:true. `silent_reactivation` preserva um plugin que já estava ativo sem repetir seus hooks de primeira ativação. `none` mantém o pacote inativo. Pacote idêntico já no estado desejado é noop; pacote idêntico inativo com activate:true ainda precisa da ativação nativa.

`activation_hook_cycle_completed` somente é true quando o ciclo nativo retornou e o evento activated_plugin foi observado. `active`/`activated` indicam estado ativo, não prova de instalação funcional. `fresh_php_request` e `independent_worker` são evidências do executor. `business_readiness_verified:false` evita confundir ativação, sonda anônima de saúde e prontidão funcional do provedor.

Timeout ou fatal sem recibo de conclusão mantém pending/running; reconciliação não repete hooks. Um ativo inesperado antes da ativação nativa fica `uncertain`. Apenas pending expirado sem entrada ou ativação ainda não solicitada admite token novo. Diários correntes emitidos pela 0.21.0 sem o novo campo preservam sua semântica silenciosa; não se presume que um hook antigo precise rodar. Isso é continuidade de uma operação corrente, sem migração de estado ou pacote intermediário.

Backup/rollback protege arquivos e estado ativo observado. Não desfaz banco, migrações ou efeitos externos. Releia a saúde e os contratos funcionais do provedor após a troca. A sentinela MU é atualizada para novas requisições, incluindo o cache PHP do servidor.
