# Plano — Fator3 MCP 0.33.0

Revisão 1 · 25/10/2026 · America/Sao_Paulo · Implementação do pedido MCP 68.

Base aceita 0.32.0, instalador 885606 bytes, SHA-256 fd2097055383a26e6ca5b79b655f0b3740c337a42dab6ce2b43b4236c07496b1. Alvo 0.33.0 previsto; instalador ainda não gerado. Core 1.54.0, Google 0.19.0, Meta/LinkedIn 0.10.1 e Pipedrive 0.1.0. Normas revisão 5 preservadas. Fonte/base e anexos com hashes verificados.

1. MCP68(a): levar contexto mínimo da chamada resolvida até a apresentação, sem estado global nem alteração do objeto de negócio. Reconhecer `lido` da escrita de f3base_formularios_sinais pela ability/option solicitadas; manter os dois booleanos exatos e os limites da 0.32.0. Preservar token_indisponivel em complemento.mensagens dos formulários nas duas projeções do diagnóstico de instrumentação, com tipo/tamanho e redação de valores reconhecíveis como segredo.
2. MCP68(b): preservar chaves_herdadas como lista de nomes de caminhos, inclusive vazia/null legítimos, em config-core-ler. Recusar forma inválida e valores secretos reconhecíveis; não abrir qualquer campo chamado chave/token globalmente.
3. MCP68(c): manter caminhos JSON Pointer no envelope para todos os campos ainda mascarados, com igualdade texto/structuredContent, casos de erro, objeto, custom serializer, nomes escapados e isolamento entre chamadas.
4. Repetir o reprodutor de autorização de e-mail contra Core 1.54.0. Encerrar o impacto recebido/atendido somente no relatório principal se os testes confirmarem. Conferir descoberta das novas abilities Core302 e suas capacidades sem efeitos comerciais.
5. Validar matriz unitária, HTTP WordPress real, instalação mínima, atualização direta da 0.32.0, regressões de segurança/transporte, acompanhantes e leitura integral da documentação. Aceite Site-Teste: aplicar o mesmo valor da política com revisão vigente (sem mudar preferências), comprovar lido, mensagem de interface e nomes herdados; conferir segredo sintético e saúde. Nenhuma alteração de outro plugin, dado comercial, SMTP ou operação na frota.

Fronteiras avaliadas: transporte/apresentação versus dono da configuração; registro e gates Core; documentação e idempotência. Nenhum impacto técnico novo a outro mantenedor identificado: a correção 68 é feita no MCP e não requer mudar o Core para acrescentar nome. Caso surja consequência nova, emitir impacto antes de implementar a parte afetada. A implantação da 0.32.0 na frota é evidência recebida do pedido, não execução desta rodada.

## Fechamento — 25/10/2026

Plano executado. Instalador final 888204 bytes, SHA-256 f16ee3e31e4143ffb42c566ea6da4f2da81d3771a01a0f90b5d34e3d02ac8caa. 828 checks locais, 15 de pacote, 453 PHP com lint aprovado, 21 de aceite remoto e 32 documentos conferidos integralmente. 0.33.0 ativa e saudável no Site-Teste. Pedido68 atendido. Impacto anterior de autorização encerrado após reteste do Core1.54 com MCP0.32/0.33; nenhum novo encaminhamento. Detalhes, ajustes do harness e limites no relatório principal.
