# Impacto do Fator3 Site Core 1.52.1 no Fator3 MCP

Revisão 1 · 24/10/2026 · Etapa: implementação/entrega · Situação: `demanda-aberta`.
Emissor: `base-site-core-fator3` 1.52.1, contrato 8.17.0. Destinatário examinado: `wp-mcp-fator3` 0.30.1. Classificação: correção de diagnóstico. Não enviado externamente por ferramenta.

## Mudança e consequência

Na homologação da 1.52.0 no Site-Teste, o retorno de `f3base/como-usar` com `{"compacto":true,"assuntos":["acessos-servidor"]}` chegou com `captacao_meta.passagens_perdidas` e `captacao_meta.limiar_passagens_perdidas` iguais a `[redigido]`. Os valores nativos eram contadores inteiros, sem segredo. O mesmo ocorre com `passagens_24h` no diagnóstico de execuções e com booleanos de teste cujas chaves contêm a palavra `passagem`.

Isso impede ler diretamente pelo canal o limite exigido pelo Pedido core 298. A evidência está em `evidence/1520/site-teste.json`, bloco `site_guide`; a leitura foi autenticada e o restante do diagnóstico chegou normalmente.

O Core 1.52.1 usa os nomes operacionais `execucoes_esperadas_perdidas` e `limiar_execucoes_perdidas` no novo diagnóstico. Não muda permissões nem solicita a exposição de segredo. Os demais campos antigos de diagnóstico ficam fora dessa correção pontual.

## Pedido ao mantenedor MCP

Revisar a identificação de chaves sensíveis para não classificar contadores/limiares de passagens como senhas somente por parte do nome. Usar contexto e nomes operacionais conhecidos, preservando a redação de password, senha, tokens e credenciais reais. Acrescentar regressão que compare os contadores inteiros e booleanos acima com os valores nativos e mantenha segredos ocultos em erros, auditoria e resultados.

Responsável pela mudança no redator: mantenedor MCP. Não foi alterado o runtime do MCP nesta rodada. Não há pedido de mudança para Google, Meta, LinkedIn ou Pipedrive por esse achado.

## Compatibilidade e sequência

A 1.52.1 pode ser instalada sem esperar outro MCP; a mudança local elimina a colisão nos campos novos. Não altera `pipedrive-api-client/1.0.0`, o SDK Google ou o contrato LinkedIn. A correção geral do falso positivo no MCP continua aberta; não se presume atendimento pelo destinatário.

## Validação e evidência

WordPress 7.1.3/PHP 8.3.36 no Site-Teste, MCP 0.30.1. Os testes nativos do Core aprovam o limite de duas ausências e três falhas de transporte; o relatório principal registra a leitura final pelo canal e a identidade do instalador. Esta emissão comunica uma consequência e um pedido técnicos novos; não é reemissão de encerramento de impacto anterior.
