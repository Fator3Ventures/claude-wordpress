# Pedidos — Fator3 MCP (wp-mcp-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no canal **wp-mcp-fator3** (o servidor MCP de cada site; Conector WP MCP §1 e §2). Em outros documentos, cite como "Pedidos MCP N". Serve também de documento para o responsável pelo canal. Base da análise: código da 0.30.1. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba. A numeração não muda.

**Situação em 24/10/2026: um pedido aberto (67, aberto em 24/10/2026).** Versão instalada nos 12 sites da frota: 0.30.1 (ZIP `wp-mcp-fator3-0.30.1-instalador.zip`, 879.690 bytes, sha256 `4dbe9ea5…`, igual ao relatório e ao servido pelo raw; no `main` do repositório com a fonte `81478d43…` e o relatório, commit `76d84fa`), direto sobre a 0.29.1: no Site-Teste pelo agente do pacote (passando pela 0.30.0) e nos outros 11 pela frota em 24/10/2026 entre 08:31 e 08:35 −03, com `applied` e sondas `/` e `/wp-json/` 200 antes e depois; `system/capabilities` com 0.30.1 e `system/health` `healthy` (11 de 11) nos 12. Exige WordPress 7.1.2 e PHP 8.3.6; sem tabela, opção ou concessão nova. Entregou e teve retirado o item 66: rota `media/convert` (`id`, `formato` `webp`, `qualidade` opcional, `expected_revision` lida em `media/get`, `idempotency_key`), que cria anexo novo em WebP a partir de JPEG ou PNG, copia título, texto alternativo e legenda, gera os derivados, preserva a origem e se desfaz por `media/delete` do anexo novo; desde a 0.30.1 `media/get` devolve `revision`. Aceite: no Site-Teste, JPEG e PNG convertidos pelo agente do pacote com os originais idênticos; a recusa `media_webp_unsupported` provada só em laboratório (o servidor da frota grava WebP); em awnventures.com.br, por ordem do dono de 23/10/2026 às 21:06, o anexo 14 virou o anexo 67 (28.862 bytes contra 56.417 do JPEG, original intacto) e o bloco da página 28 passou ao anexo 67 por `content/patch-page` com `expected_revision`, com o `srcset` em WebP no HTML servido (Quadro, awnventures A-WEBP-2110). Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 68) e vai no fim; item retirado deixa o número vago.

## wp-mcp-fator3 — pendentes

**67. A redação do canal mascara campos operacionais com "passagens" no nome (24/10/2026; wp-mcp-fator3 0.30.1).**

Evidência: relatório do base-site-core-fator3 1.52.1 (24/10/2026, seções 2 e 9) e impacto `base-site-core-fator3-1.52.1-impacto-wp-mcp-fator3.md`, revisão 1, emitido ao mantenedor do canal: no Site-Teste, com o canal 0.30.1, a leitura dos contadores e limiares do alarme de captação da candidata 1.52.0, com "passagens" no nome, voltou mascarada. O Site Core 1.52.1 trocou os nomes para `execucoes_esperadas_perdidas` e `limiar_execucoes_perdidas`, e a leitura final mostrou 0 e 2 (limite de transporte 3). Reproduzido na frota em 24/10/2026 às 21:07 −03, com Site Core 1.52.1 e canal 0.30.1: f3base/como-usar (compacto) em ctooffice.com.br e korvena.com.br devolve execucoes.passagens\_24h como "\[redigido\]" (contador que manteve o nome); os campos renomeados do alarme voltam legíveis. O arquivo de impacto está dentro do ZIP da fonte do Core, não na raiz do repositório. "passagens" contém a sequência "pass"; conferido na fonte do instalador 0.30.1 em 24/10/2026: DataSafety::secret\_key usa a expressão sem limite de palavra (?:pass(?:word|wd)?|secret|token|credential|…), que casa qualquer nome com "pass" (e também "token" ou "secret" no meio de nome operacional).

Pedido: (a) a redação decide por nomes de segredo inteiros (senha, password, token, chave, secret, cookie e afins) e pelo formato do valor, não por trecho que aparece em nome operacional; números, booleanos e datas em campo de diagnóstico não se mascaram; (b) o que foi mascarado aparece na resposta com o caminho do campo; (c) o relatório da entrega lista as regras da redação e os falsos positivos testados, entre eles "passagens".

Aceite: no Site-Teste, campo de teste com "passagens" no nome e valor numérico volta legível, e campo com senha ou token segue mascarado.

## Decidido não fazer

Da lista comum da frota, o que toca o canal:

- Rota de execução de PHP.
- Rota "frota" (um site chamando os outros).
- `db/execute` em uma fase.
- Fonte de atualização publicada para os pacotes Fator3 (decisão do dono, 01/10/2026): os pacotes seguem trocados por `plugins/upload` com o ZIP versionado do GitHub e `expected_sha256`, pela ordem do Padrão §1.1, e ficam fora de `auto_update_plugins`.
