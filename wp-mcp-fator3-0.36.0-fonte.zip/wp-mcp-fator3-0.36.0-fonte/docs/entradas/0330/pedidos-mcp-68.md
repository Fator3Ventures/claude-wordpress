# Pedidos — Fator3 MCP (wp-mcp-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no canal **wp-mcp-fator3** (o servidor MCP de cada site; Conector WP MCP §1 e §2). Em outros documentos, cite como "Pedidos MCP N". Serve também de documento para o responsável pelo canal. Base da análise: código da 0.32.0. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba. A numeração não muda.

**Situação em 25/10/2026: um pedido aberto (68, aberto em 25/10/2026).** Versão instalada nos 12 sites da frota: 0.32.0 (ZIP `wp-mcp-fator3-0.32.0-instalador.zip`, 885.606 bytes, sha256 `fd209705…`, igual ao relatório e ao servido pelo raw; no `main` do repositório com a fonte `d7413eda…`, commit `d5a27ed`), direto sobre a 0.30.1 (a 0.31.0 não passou pela frota; nenhuma das duas muda o banco): no Site-Teste pelo agente do pacote e nos outros 11 pela frota em 25/10/2026 entre 21:29 e 21:37 −03, em cada site antes do Site Core 1.54.0, com `applied`; `system/health` `healthy`, com as 11 verificações, nos 11 (lido entre 21:39 e 21:43 −03). Entregou e teve retirado o item 67: desde a 0.31.0 a redação não casa trecho de nome operacional, e na 0.32.0 as regras `token_*` de `f3base_formularios_sinais` saem legíveis nas projeções publicadas de configuração. Aceite em produção: `execucoes.passagens_24h` com três inteiros nos 11 (`f3base/como-usar`, 25/10 às 21:4x −03) e as regras `token_*` legíveis em `f3base/config-core-ler` de ctooffice.com.br (21:5x −03). O impacto da 0.32.0 ao Site Core (`permission_callback` dos resultados repetidos das rotas de e-mail) foi tratado no Site Core 1.54.0. Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 69) e vai no fim; item retirado deixa o número vago.

## wp-mcp-fator3 — pendentes

**68. Regras `token_*` e nomes com "chave" ainda saem mascarados fora das projeções publicadas (25/10/2026; wp-mcp-fator3 0.32.0, Site Core 1.54.0).**

Evidência: em ctooffice.com.br, 25/10/2026 às 21:5x −03, `f3base/config-core-escrever` de `f3base_formularios_sinais` com `simular` false (operação `03b3e7b4…`) devolve em `lido` `token_vencido`, `token_revisao_anterior` e `token_assinatura_invalida_ou_ausente` como "\[redigido\]", embora sejam objetos `{suspeito, aviso}` booleanos (a simulação anterior mostrou os três legíveis em `antes` e `depois`, e `f3base/config-core-ler` logo depois também); `f3base/conteudo-instrumentacao-ler` da home devolve a mensagem de interface `token_indisponivel` dos dois formulários como "\[redigido\]"; `f3base/config-core-ler` devolve `chaves_herdadas` como "\[redigido\]" em `f3base_formularios_sinais` (ctooffice.com.br) e `f3base_pipedrive` (korvena.net.br, 21:5x −03). O relatório da 0.32.0 limita a correção a "caminhos publicados" e reconhece a option em \`antes\`, \`depois\` e \`lido\` só com \`nome\` no mesmo objeto; a resposta simulada do Site Core 1.54.0 traz \`nome\` e a aplicada não traz.

Pedido: (a) o canal reconhece a option também na resposta aplicada (ou combina com o Site Core devolver \`nome\` nela), e a regra das projeções publicadas vale também para `lido` de `config-core-escrever` e para as leituras de diagnóstico: objeto de booleanos ou texto de interface sem valor de segredo não se mascara pelo nome; (b) `chaves_herdadas`, lista de nomes de chave, sai legível; (c) o que continuar mascarado traz o caminho do campo.

Aceite: no Site-Teste, a escrita aplicada de `f3base_formularios_sinais` com as regras `token_*` legíveis em `lido`, `conteudo-instrumentacao-ler` com `token_indisponivel` legível e `chaves_herdadas` legível; senha e token reais seguem mascarados. Prioridade baixa: a releitura por `config-core-ler` dá o valor completo.

## Decidido não fazer

Da lista comum da frota, o que toca o canal:

- Rota de execução de PHP.
- Rota "frota" (um site chamando os outros).
- `db/execute` em uma fase.
- Fonte de atualização publicada para os pacotes Fator3 (decisão do dono, 01/10/2026): os pacotes seguem trocados por `plugins/upload` com o ZIP versionado do GitHub e `expected_sha256`, pela ordem do Padrão §1.1, e ficam fora de `auto_update_plugins`.
