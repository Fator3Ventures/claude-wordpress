# Entrega — Fator3 Site Core 1.53.0

Revisão 1 · 25/10/2026 · referência America/Sao_Paulo. Rodada de implementação dos pedidos Core 299, 300 e 301, com a atualização expressa de 25/10 às 17h19. Estado: **com-pendencias**. Código implementado, validado localmente e em WordPress real; instalação compartilhada concluída. Não se declara homologação de fornecedores nem conclusão da matriz de autopreenchimento.

## 1. Bases aceitas

Base direta: **1.52.1 → 1.53.0**, além de WordPress limpo. Instalador-base: 2117492 bytes, SHA-256 `b93a2fe56fa857f46dfa1d6acb1ac674555f7d4dac2f1a84db4b197992db6fcb`. Não há versão intermediária exigida. Cabeçalho, constante, contrato, schemas e documentação corrente identificam 1.53.0; contrato administrativo aditivo **8.18.0**. Identidades públicas e basename `base-site-core-fator3/base-site-core-fator3.php` preservados.

Entrada nova de pedidos: `Fator3 Site Core(20261025-201035).md`, 16833 bytes, SHA-256 `c4d8dce900c05e76b096ef3b6b6217cc7ffcd1f61ff24833302ab7fc531c1390`. A atualização textual do dono neste chat prevalece sobre a redação anterior do pedido 301 e está consolidada em `inputs/1530/pedido-301-atualizacao.md`. Normas comuns revisão 5, de 23/10, incluídas no runtime. Entradas e identidades em `evidence/1530/inputs.json`; plano da rodada preservado como histórico de planejamento.

Mínimos exercitados: WordPress **7.1.2**, PHP **8.3.6**, MySQL **8.0.46**. Site-Teste: WordPress **7.1.3**, PHP **8.3.36**. Não se infere suporte a versões menores nem a outro banco a partir desses ensaios.

## 2. Convivência e encaminhamentos

| Acompanhante original | Versão | Prova desta rodada |
|---|---|---|
| Fator3 MCP | 0.31.0 | Convivência local, SafeOutput original e transporte real no Site-Teste |
| Fator3 MCP Google | 0.19.0 | Árvore original preservada da base, convivência e fronteira de configuração |
| Fator3 MCP Meta | 0.10.1 | Igualdade com instalador recebido, convivência e regressões Core pertinentes |
| Fator3 MCP LinkedIn | 0.10.1 | Igualdade com instalador recebido, convivência e seleção por integração |
| Fator3 MCP Pipedrive | 0.1.0 | Igualdade com instalador recebido, consumidor original em fixture e presença no Site-Teste |

`evidence/1530/companions.json` identifica quatro instaladores e comprova igualdade de suas árvores usadas. Google é comparado com a cópia original preservada da 1.52.1; não foi recebido Google mais novo nesta rodada. O plugin Pipedrive completo exige PHP 8.3.36: não foi ativado no laboratório PHP 8.3.6. Seu consumidor original foi exercitado sem transporte comercial; no Site-Teste o pacote permanece presente e a operação comercial desligada.

Não foi editado pacote alheio. O contrato `pipedrive-api-client/1.0.0` não mudou. A regra de oportunidade da mesma unidade pertence à entrega comercial interna do Core; o rascunho exploratório de impacto Pipedrive não gerou demanda ao destinatário. Google/Meta/LinkedIn não recebem novas exigências de contrato nesta rodada. Homologação de cada fornecedor não está coberta pela simples convivência.

**MCP:** o documento `base-site-core-fator3-1.53.0-impacto-wp-mcp-fator3.md`, revisão 2, registra a política de sinais indevidamente redigida e a validação coordenada das novas operações privadas de correio. Manutenção é perfil do canal; `f3base_enviar_email` é capacidade WordPress, concedida pelo Core ao administrador. Não se pede elevação automática pelo MCP.

**Resposta ao impacto anterior de contadores Core 1.52.1:** o MCP 0.31.0 preserva os contadores tipados examinados; comprovado em `request-301-mcp.json`. Encerramento registrado aqui, sem reemitir arquivo apenas para comunicar atendimento. A nova redação dos objetos `token_*` é caso distinto: Core fornece `linhas` com a política completa, sem bloquear a operação enquanto o MCP avalia a exceção tipada.

## 3. Mudanças e evidências

### Pedido 299 — limpeza da automação antiga

A comparação de `f3base_c0` ignora somente a chave `ativo` na raiz. Compara conteúdo por chave, independentemente da ordem, e continua apontando divergências reais pelo nome, sem seus valores. Revisão esperada, travas e prova das tabelas permanecem. Não executa limpeza automaticamente nem altera snapshots para fabricar igualdade. Cinco verificações próprias e 25 da regressão 296 passaram. Limpeza efetiva em produção continua sendo operação explícita da frota depois da adoção da versão.

### Pedido 300 — caixa de e-mail do site

Importação IMAP e envio SMTP possuem interruptores independentes, ambos desligados por padrão. A configuração fica em `f3base_email_site`, segredo cifrado em `f3base_email_site_senha`, estado em `f3base_email_site_estado`. Tela com ajuda por campo; capacidades, catálogo de credenciais e schemas atualizados. Agenda de 5 minutos, até dez mensagens por lote, marco de ativação, cursor UID/UIDVALIDITY e histórico privado. Sem importação retroativa automática; UIDVALIDITY divergente bloqueia para reconciliação.

IMAP TLS 993 funciona sem ext-imap, com validação de certificado e destino público, leitura BODY.PEEK e limites de tamanho/tempo. Mensagem persiste antes de MOVE para Importados; falha de movimentação é retomável sem duplicar contato. Parser MIME maduro `zbateson/mail-mime-parser` **4.0.7**, com namespace `F3BaseEmailVendor`, dependências e licenças incluídas. Não se usa parser MIME artesanal. Binários de anexos não são armazenados; nomes são limitados. Descarte conserva motivo e identidade mínima, sem corpo. Conteúdo de histórico fica cifrado e a eliminação remove dados privados, mantendo tombstone contra reimportação.

Destinatário próprio, remetente, mensagens automáticas/listas/bounces, DMARC e lista de homologação participam da classificação. Falta de autenticação confiável fica suspeita; nome substituto é marcado, empresa não é inferida. Conversas reutilizam contato local por referências ou e-mail; cada mensagem tem identidade independente de aviso/nota. Recepção não responde automaticamente nem produz conversão em anúncios.

Envio por `f3base/email-enviar` exige contato local aceito, `f3base_enviar_email` e `f3base_ler_leads`, com simulação e revisão. Não admite destinatário livre. PHPMailer usa a conta do site, assinatura e threading; Cco e Smart Bcc explícitos contam na cota comum da automação. Cco padrão configurável: `korvena@korvena.net.br`. Cota local padrão 20 destinatários/hora, máximo 99; a alocação total entre sites da mesma conta precisa de confirmação operacional. Em homologação todos os destinatários devem estar na lista autorizada.

A intenção durável antecede SMTP. Todos os RCPT precedem DATA; resultado incerto não é repetido. Aceite SMTP e cópia IMAP são estados diferentes: falha/incerteza no APPEND não autoriza novo SMTP. Mensagem enviada aparece no histórico e em nota CRM, sem nova atividade de entrada. A automação de primeiro contato só usa essa conta se o envio estiver habilitado; não é ligada pela importação.

Seleção Pipedrive consulta campos completos e confirma unidade antes da reutilização; outra unidade gera novo lead. Negócio aberto da mesma unidade recebe nota e atividade somente conforme a configuração existente. A leitura é repetida antes da escrita, cobrindo mudança entre etapas. Mapeamentos de ponto/canal/parceiro são configuráveis; IDs 168/85/51 são fixtures do cenário, não valores fixos do runtime. Essa regra vale também aos formulários e entradas nativas. Um achado na validação — texto de e-mail ausente na nota — foi corrigido antes de fechar o instalador.

Saúde: três falhas consecutivas ou mais de quinze minutos sem tentativa abrem incidente, com aviso de abertura/recuperação sem conteúdo pessoal. Observador independente de cinco minutos; não promete detectar externamente cron/PHP completamente parado. Manual instalado: `docs/EMAIL-SITE-1.53.md`.

### Pedido 301 atualizado — quarta isca e política por sinal

**Escolha entregue:** rótulo **Segmento de atuação**, nome **segmento_atuacao**, ID único **f3base-segmento-N**, tipo texto. As três iscas atuais mantêm seus elementos e rótulos existentes. A quarta compartilha `.f3base-isca`, `aria-hidden=true` e `tabindex=-1`; entra no envio, no complemento e na lista de campos que o JavaScript não trata como preenchimento real. Sinal próprio `isca_segmento_atuacao`, legível pelo filtro `sinal`. Campo ausente permanece aceito, inclusive página antiga em cache.

**Prova de (b), com limite explícito:** o teste estático confere rótulo, nome, ID, ocultação e atributos. Os termos pessoais listados no pedido não foram usados na nova identificação. Entregues `autocomplete=off`, `autocapitalize=off`, `spellcheck=false` e hints `data-1p-ignore`, `data-lpignore`, `data-bwignore`. Isso não comprova que nenhum navegador preencha o campo. O requisito de um valor universalmente infalível de autocomplete **não está demonstrado**; não se substituiu por token inventado nem se apresenta `off` como garantia. A matriz de dispositivos reais abaixo segue pendente. A base técnica consultada está na documentação HTML de autofill, referenciada no manual instalado.

Option por site **`f3base_formularios_sinais`**, objeto de no máximo 100 sinais, nomes `[a-z0-9_]{1,80}`. Cada linha exige exatamente dois booleanos `suspeito` e `aviso`; chaves extras da linha são recusadas. Novos sinais podem ter regra. Sem regra, sinal desconhecido só fica registrado. Tela de Avisos traz uma linha por sinal e duas caixas; dez linhas/vinte controles no padrão.

Padrão entregue:

```json
{
  "isca_website": {"suspeito": false, "aviso": false},
  "isca_ctodesenvolvimentofator3": {"suspeito": true, "aviso": true},
  "isca_segmento_atuacao": {"suspeito": true, "aviso": true},
  "isca_comentario": {"suspeito": true, "aviso": true},
  "tempo_curto": {"suspeito": false, "aviso": false},
  "token_vencido": {"suspeito": false, "aviso": false},
  "token_revisao_anterior": {"suspeito": false, "aviso": false},
  "token_assinatura_invalida_ou_ausente": {"suspeito": true, "aviso": true},
  "sem_pagina_origem": {"suspeito": true, "aviso": true},
  "cota_excedida": {"suspeito": true, "aviso": true}
}
```

Qualquer sinal com suspeito ligado marca suspeita. Entre os que marcaram a suspeita, um com aviso ligado permite aviso. A condição histórica `contato_valido` permanece: nome e e-mail ou telefone válido. A decisão guarda revisão, sinais que pesaram e marca de supressão em `dados.sinais_politica`; `aviso=suprimido_sinais` impede Slack e contingência por e-mail. O contato permanece no WordPress, aprovável, fora do Pipedrive até aprovação. Workers reavaliam a supressão antes de entregar fila antiga se o complemento mudou a classificação. Valores das iscas não são exportados a avisos, CRM ou anúncios.

| Caso exercitado com contato válido | Resultado observado |
|---|---|
| Padrão: comentario preenchido | Suspeito, aviso enfileirado |
| Padrão: ctodesenvolvimentofator3 preenchido | Suspeito, aviso enfileirado |
| Padrão: segmento_atuacao preenchido | Suspeito, sinal próprio, aviso enfileirado |
| Só website preenchido | Aceito, com sinal |
| Nova isca com aviso desligado | Suspeito, supressão persistida, sem fila Slack/contingência |
| ctodesenvolvimentofator3 com aviso desligado | Mesmo comportamento de supressão |
| comentario + ctodesenvolvimentofator3 com este desligado | Suspeito, aviso por comentario |
| Sinal com suspeito desligado, sem outra causa | Aceito, sinal conservado |
| Política permite aviso, mas contato inválido | Condição antiga impede aviso |
| Complemento passa a suspeito com supressão | Fila anterior não gera contingência |
| Página antiga sem quarta isca | Envio aceito |
| Simulação, gravação e releitura da option | Confirmadas; revisão antiga recusada |

São 59 verificações da suíte 301, repetidas no mínimo WordPress e no ambiente isolado do Site-Teste. Avisos foram interceptados: a prova demonstra a decisão/fila e ausência de chamadas proibidas, não entrega real ao Slack.

`f3base/como-usar`, assunto `avisos`, retorna configuração, revisão e contagens de suspeitos sem aviso em 7/30 dias. As contagens abrangem contatos ainda suspeitos e retidos, fora de teste/lixeira/eliminação; não são total histórico imutável. Aprovação ou eliminação retira o registro desse conjunto, e mudança de regra não reclassifica contatos antigos. No MCP 0.31.0, usar a projeção `linhas` para leitura completa das regras `token_*` mascaradas em `regras`.

**CTO Office:** leitura de produção ainda identificou 1.52.1. Não houve troca de pacote nem gravação da nova option nesse site. Ordem preservada: depois da adoção, nova isca e ctodesenvolvimentofator3 com suspeito ligado/aviso desligado; demais sinais no padrão. Nos outros onze sites, padrão até decisão do dono. Verificação diária condicional agendada: ao detectar versão e contrato, aplica somente essa configuração se ainda integralmente padrão, com simulação/revisão/releitura, ou respeita divergência possivelmente posterior. Confere HTML dos dois formulários e inicia trinta dias de acompanhamento após configuração confirmada; o período não foi contado como executado antecipadamente. Evidência: `acompanhamento-301.json`.

## 4. Instalação e provas de prontidão

O mesmo instalador final passou por instalação limpa e atualização nativa via Plugin_Upgrader desde 1.52.1, em processos novos. Configuração, credenciais cifradas, snapshots, callbacks, cursores, listas vazias e intenções incertas foram preservados. Finalização foi acelerada somente nos laboratórios descartáveis; Site-Teste confirmou a passagem real do executor.

| Grupo | Asserções booleanas locais | Resultado |
|---|---:|---|
| Pedido 299 | 5 | Todas passaram |
| Pedido 301 | 59 | Todas passaram |
| MIME / estado / transportes / coletor / CRM do pedido 300 | 25 / 27 / 19 / 13 / 38 | Todas passaram |
| Compatibilidade com SafeOutput MCP 0.31 | 4 | Todas passaram |
| Regressões formulários / Pipedrive | 32 / 39 | Todas passaram |
| Regressões 294 / recuperação 294 / 295 / 296 / 297 / 298 | 46 / 6 / 25 / 25 / 8 / 18 | Todas passaram |
| Convivência dos quatro acompanhantes ativados localmente | 26 | Todas passaram |
| Documentação instalada | 847 | 115 documentos, 591 páginas, texto/hash completos |

As sete suítes novas (299, 301 e cinco grupos 300) e a documental passaram também no WordPress mínimo 7.1.2 e na instalação isolada do Site-Teste. A tabela não soma repetidamente ambientes como se fossem casos novos. PHP lint: **528 arquivos**, sem erro. Build MIME reproduzido, quatro JavaScripts minificados e manifesto atualizados. Evidências em `evidence/1530/`, mínimo em `minimum/`, Site-Teste em `site1530-*.json`.

**Site-Teste:** atualizado de 1.52.1 para 1.53.0 pelo MCP `plugins/upload-base64`, com `zip_path`, `expected_slug`, SHA esperado, overwrite e ativação. Operação de pacote `c260a9633944a0dda5a654b282221ba3`, backup `90fbad0b06aad802e772d105`. Sondas antes/depois: home e REST HTTP 200, plugin ativo e verificação em PHP novo. Ciclo `a67edb50-7c70-4711-b0e3-bd1e5fc3e8b7`: 17 etapas, zero falhas, estado concluído, confirmação do executor Unix 1792962906.

Leitura posterior: versão 1.53.0, contrato 8.18.0, 151 abilities, telas novas presentes, options preservadas, quarta isca renderizada, importação/envio desligados e política padrão. **713 arquivos instalados idênticos** ao runtime local, manifesto SHA-256 `f370758126b941c572ed068decbe0e08aadc9657be7dd5b66eed7370ac675c91`. Contagens compartilhadas 7/30 em zero após testes isolados. Nenhum contato de QA ficou no conjunto comercial compartilhado.

Os testes remotos criaram tabelas e diretório privados isolados; limpeza confirmou **70 tabelas removidas, zero remanescentes**, diretório e manifesto temporários removidos. Controlador MU de QA e ZIP temporário também excluídos, com guarda de hash. Backup privado do controlador conservado pelo MCP. Contas externas, credenciais, usuários e conteúdos comerciais não foram usados para produzir os efeitos sintéticos.

Documentação completa foi lida pela ability no WordPress local, mínimo e no QA remoto. Pelo conector MCP real, as leituras completas dos três documentos `docs/FORMULARIOS-SINAIS-1.53.md`, `docs/EMAIL-SITE-1.53.md` e `docs/RELEASE-1.53.0.md` terminaram com `proxima_linha:null` e SHA correspondente. Nomes sem prefixo `docs/` foram corretamente recusados como não catalogados. A simulação de envio para record_id inexistente foi recusada com `contato_nao_elegivel`, sem SMTP. Descoberta não é tratada como prova de envio.

## 5. Banco, dependências e reversão

Nova tabela `{prefix}f3base_email_site`, incluída no inventário de 58 tabelas, com identidade única por contexto/mensagem, índice sequencial, estado de movimento/CRM/aviso e payload cifrado. Defaults não ativam a caixa nem mudam política já gravada. Catálogo: 146 options, 79 operáveis; schemas/abilities gerados a partir do runtime. A instalação continua com 17 etapas.

Parser e transitivas: onze pacotes de runtime, lockfiles, licenças e script de prefixação/reprodução no fonte. **297 arquivos**, 1191538 bytes descompactados; payload comprimido 337008 bytes, acréscimo exato de 411724 bytes no ZIP incluindo cabeçalhos de entradas. Detalhes em `mime-size.json`, `mime-build.json` e `docs/DEPENDENCIAS-EMAIL-1.53.md`. PHP-Scoper 0.18.20; template misto PHP/texto do PHP-DI preservado do original porque a transformação introduzia sintaxe inválida. O instalador não inclui Composer, ferramenta de build, fixtures ou vendors de desenvolvimento. Namespace original do parser não é carregado pelos testes.

Antes de voltar versão, pausar captura/entregas e reconciliar intenções SMTP/CRM/IMAP. Restaurar arquivos não desfaz tabelas, mensagens enviadas, MOVE ou notas externas. Não repetir envio incerto nem retirar tombstones sem reconciliar. Backup deve conter banco, tabela nova e chaves privadas do Core. Voltar à 1.52.1 remove a aplicação da política nova e pode reintroduzir avisos antigos; exige avaliação das filas, não simples rollback cego. O backup de pacote do Site-Teste não é apresentado como backup integral de banco/fornecedores.

## 6. Pendências e responsáveis

- **301 — navegadores, dono/homologação:** Chrome e Edge em computador/Android; Safari macOS/iOS; Firefox; Samsung Internet; navegadores internos Instagram/Facebook/Kwai; ao menos um gerenciador de senhas. Preencher campos reais e provar a quarta isca vazia. Esses ambientes não estavam disponíveis; o aceite de autopreenchimento permanece aberto.
- **301 — frota/CTO Office:** publicar/adotar a versão pela distribuição autorizada. A configuração ordenada e os dois formulários da home ainda não foram conferidos em produção com esta versão. Automação condicional prepara a aplicação/releitura e o acompanhamento posterior; nenhuma observação futura é contada nesta entrega. Outros onze sites ficam no padrão.
- **300 — dono/frota:** preparar caixa dedicada, senha, pastas e authserv_ids da hospedagem; homologar recepção real, MIME do provedor, MOVE, SMTP, Cco/Smart Bcc, cópia Sent e aviso de falha/recuperação em destinos de teste autorizados. Conferir cota global da conta. Sem essas provas, importação e envio devem continuar desligados.
- **300 — CRM:** homologar comercialmente a seleção por unidade, mapeamentos e notas/atividade nas unidades autorizadas. Os testes desta entrega usam transportes controlados.
- **299 — frota:** executar limpeza explícita onde ainda necessária, simulando/revalidando a revisão após atualizar; não houve limpeza em CTO Office ou Korvena nesta rodada.
- **MCP — mantenedor:** ação e validação descritas no impacto revisão 2. O caminho alternativo `linhas` já permite operar.

Nenhuma dessas pendências autoriza alegar impacto zero. As regressões executadas não encontraram falha restante no escopo ensaiado; fornecedores, autofill e comportamento de produção permanecem com os limites acima.

## 7. Credenciais

O dono preenche `f3base_email_site_senha` na tela Site Core → Configurações → Conexões e entregas → E-mail do site. A senha da caixa não é token OAuth e não é retornada pelo contrato. Configurar endereço/usuário, hosts/portas TLS, pastas, nome, assinatura e cópias sem reutilizar secretamente outra conta. Nenhuma senha foi incluída na entrega. Slack, Google, Meta, LinkedIn e Pipedrive mantêm suas credenciais/consentimentos existentes; não foram renovados nem ativados nesta rodada. `credenciais-ler` e `credenciais-verificar` documentam o inventário sem revelar os valores.

## 8. Identidade final dos arquivos

| Artefato | Bytes | SHA-256 |
|---|---:|---|
| base-site-core-fator3-1.53.0-instalador.zip | 2574091 | `086adf2530809c73d30d38ccb747b0a8de8c7cd7419543273c2e2c50940d99f1` |
| base-site-core-fator3-1.53.0-fonte.zip | 3567859 | `4a90eb3fb2b05e0f0c6e494ddf9675a94a08c9ed0bdfa2f042b8f32b0d16ecbc` |

Instalador com raiz única `base-site-core-fator3/`; fonte com raiz `base-site-core-fator3-1.53.0-fonte/`. Os arquivos de runtime do fonte são conferidos byte a byte contra o instalador. Não há ZIP da entrega dentro de outro ZIP. O relatório interno é explicitamente anterior ao fechamento do fonte; a identidade final acima existe somente no relatório externo canônico, evitando circularidade.

Entregues ao dono: fonte, instalador, este relatório e `base-site-core-fator3-1.53.0-impacto-wp-mcp-fator3.md`. Publicação no repositório e distribuição da frota não foram executadas. A frota deve conferir os bytes/SHA servidos antes de instalar com expected_sha256 e expected_slug. O fonte permanece com o dono conforme a regra vigente.
