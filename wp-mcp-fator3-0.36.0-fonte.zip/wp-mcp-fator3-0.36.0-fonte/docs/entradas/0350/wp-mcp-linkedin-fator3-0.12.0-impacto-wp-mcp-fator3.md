# Impacto — auditoria central do consumidor comercial LinkedIn

- Emissor: Fator3 MCP LinkedIn, base 0.11.0, alvo previsto 0.12.0.
- Destinatário/responsável: mantenedor Fator3 MCP, base examinada 0.34.0.
- Data: 28/10/2026. Revisão 1. Etapa: validação do candidato, antes do congelamento do instalador final.
- Classificação: `acao-necessaria`. Situação: demanda aberta.
- Referência: Pedido Core 323; impacto Core 1.58.0 → LinkedIn, revisão 2. Não há número novo de pedido MCP atribuído.

## Consequência técnica

O novo contrato opcional `site-conversion-delivery/1.2.0` usa consumidor `site-core-quality` e finalidade `crm_stage`, independentes de `site-core-conversions`. No MCP 0.34.0, `MutationServiceAudit::identity_schema()` restringe `consumer_id` a `site-core-conversions`. Por isso o produtor pode ser admitido, mas o evento comercial é recusado pelo consumidor central. A entrega LinkedIn pode retornar `entregue` e `central_audit=service_record_unconfirmed`; seu diário local continua íntegro. O contrato de aquisição não muda.

Prova: WordPress 7.1.3/PHP 8.3.6, Core 1.58.0 + MCP 0.34.0 originais, LinkedIn candidato 0.12.0, HTTP sintético. `stages012.php` comprovou `ServiceAudit::introspect(...).valid=true`, envio aceito e ausência do recibo central para `site-core-quality`. Não foi alterado nenhum arquivo MCP. O instalador final ainda não estava gerado na identificação deste impacto.

## Solicitação e proposta

Admitir explicitamente `site-core-quality` no schema de identidade e, por derivação, no evento, no leitor `audit/get-service-operation` e no painel. Preservar os demais campos e validações de `mutation-service-audit/1.0.0`: descritor de origem, provider, hook, leitor, introspector, digest, concessão/revisão, administrador autorizado e ausência de dados pessoais. Não abrir consumidores arbitrários nem representar o novo consumidor como aquisição.

O LinkedIn publica o mesmo descritor, com schema fechado do leitor aceitando os dois consumidores. Identidades comerciais são vinculadas por HMAC a consumidor, referência opaca, revisão da concessão, conta, regra, conexão e concedente. O introspector resolve a concessão pelo vínculo persistido no próprio diário. Eventos mantêm dez campos, operação `send-conversion-event`, estados e hashes técnicos existentes. Nenhum contato, hash de email ou li_fat_id vai ao evento central.

## Aceite e validação coordenada

1. Aquisição existente continua registrada/lida sem alterações de identidade.
2. Duas concessões comerciais distintas produzem `central_audit=recorded`, inclusive usuário WordPress zero, somente após recibo de digest exato.
3. Leitor/painel autorizados exibem `site-core-quality`; consumidor forjado, referência/revisão alterada e concessão revogada falham fechados.
4. Replay confirmado/incerto não repete HTTP nem duplica referência; payload e identificadores pessoais não aparecem no Registro.
5. Executar `tests/native/stages012.php` com o novo MCP original; atualizar a expectativa documentada da combinação 0.34.0 para o recibo confirmado somente quando houver prova real do consumidor atualizado.

A mudança é de observabilidade central. A entrega, a deduplicação e os recibos locais do LinkedIn não dependem dela. Ordem: LinkedIn 0.12.0 pode ser instalado antes; para auditoria central comercial, atualizar o MCP para a versão que efetivamente admitir esse consumidor. Eventos anteriores não são reenviados automaticamente. Respostas e encerramento deverão constar no relatório principal da rodada responsável, conforme norma revisão 5.
