# M40/M41 — sondas de teste e auditoria de acesso

Contrato corrente 0.34.0: consulte RELEASE-0340.md para compact/fields, error-log, recibos de upload, metadados/política de pré-imagens e cache servido, conforme aplicável. As descrições anteriores permanecem válidas nos pontos não alterados.

## system/probe

`contexto_teste` é booleano e opcional. Se omitido, o cabeçalho opcional `X-F3Base-Teste` determina a classe (`1` = teste; `0` = não marcado). Sem ambos, sai explicitamente `0`, sem herdar cookie ou cabeçalho do solicitante. Se ambos estiverem presentes, devem concordar. Cabeçalhos são comparados sem distinção de maiúsculas/minúsculas.

```json
{"ability_name":"system/probe","parameters":{"contexto_teste":true,"paths":[{"path":"/","assert":{"status":200}},{"path":"/wp-json/","assert":{"status":200}}]}}
```

Resultados e amostras incluem `contexto_teste`, `classe_trafego:teste|nao_marcado` e `traffic_class_scope:outgoing_request`. Isso informa a marca enviada, não prova coleta, consentimento, gravação ou contagem pelo Core. A marca não concede permissões. `success:true` indica execução da ferramenta; confira também `passed`, as asserções e `cache_bypass_verified`.

Códigos de recusa: `probe_test_context_invalid` (tipo/valor inválido), `probe_test_context_conflict` (argumento e cabeçalho discordam), `probe_header_conflict` (duplicatas discordam) e `probe_header_forbidden` (cabeçalho não permitido ou injeção). Cookies e Authorization permanecem recusados. A marca acompanha GET, HEAD, repetições, redirecionamentos da mesma origem e teste de armazenamento privado; sair da origem é recusado.

Sondas internas de troca/recuperação de plugins, temas, arquivos PHP, árvores e endereços usam `contexto_teste:true`. O executor anterior ainda em memória durante um self-upload conserva seu contrato. A política de timeout e reconciliação da seção Verificação de pacotes vale para operações iniciadas pela 0.19.0.

O Core 1.25.0 reconhece o cabeçalho em `F3Base_Testes::resolver`. GET/HEAD da sonda não executa JavaScript nem envia um evento de navegador ao coletor de análise/comportamento. Portanto a ausência de evento nessas leituras não prova perda da marca. O MCP não fabrica métricas nem grava diretamente tabelas de medição do Core. A evidência da release distingue recepção da marca de persistência em métricas; encaminhamento separado ao Core trata essa lacuna do aceite solicitado.

## Recusa anônima MCP

GET sem credencial a `/wp-json/mcp/wp-mcp-fator3` e ao alias `/wp-json/mcp/wp-mcp-ultimate` continua recebendo 401. A recusa esperada não gera erro no error.log. `audit/list` expõe `ability:mcp/access-denied`, alvo da rota, `user:0`, `success:false` e `error_code:mcp_authentication_required`.

As avaliações repetidas de permissão para o mesmo objeto WP_REST_Request produzem uma única entrada. Requisições distintas continuam auditadas. Não são persistidos Authorization, cookies, corpo, query string ou IP nesse registro. Falha de gravação usa o diagnóstico existente de persistência de auditoria; não concede acesso. O tamanho da auditoria continua sujeito à retenção MCP.

Usuário autenticado sem a capacidade exigida é uma recusa diferente (`mcp_permission_denied`) e conserva aviso único. Erros inesperados do servidor continuam no log com diagnóstico sanitizado. Esta mudança não suprime globalmente `error_log` nem altera o servidor MCP próprio do Elementor.

## Projeção pública — 0.24.0

Pedido MCP 61: cache_bypass_verified conserva estritamente true/false nas amostras e no total, inclusive dentro de probe_before/probe_after. Tipos inesperados permanecem redigidos. false indica ausência de prova; não é convertido para true. O produtor da sonda e as guardas de recuperação permanecem iguais.
