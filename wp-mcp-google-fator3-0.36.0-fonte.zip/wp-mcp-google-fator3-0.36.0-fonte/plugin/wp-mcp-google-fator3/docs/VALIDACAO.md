# Verificação da instalação · 0.36.0

A regressão da 0.35.0 cobre cabeçalhos Ads, nível por projeto, prova Data Manager, continuidade das autorizações persistentes e avisos por concessão de tarefa avulsa. O relatório da versão discrimina WordPress real, transporte simulado e aceite do fornecedor.

Na 0.36.0 confira os três grupos a 360, 768 e 1440 px. Compare o status do cron antes e depois de uma confirmação posterior. O recibo do último erro deve apontar para a observação que o resolveu.

## Conferir uma instalação

Em nova requisição, com administrador:

1. `google/status {"compact":true}`: `plugin_version` igual a 0.36.0, conexão e identidade esperadas, `health` e `incidents_open`.
2. `google/readiness-status {}`: `state` e `actions[]`.
3. `google/documentation {}`: `plugin_version` 0.36.0 e os documentos do mapa de `README.md`; leia um documento até `next_offset: null` e confira `total_bytes` e `revision`.
4. `google/ability-catalog {"limit":1}`: `plugin_version` 0.36.0 e `total` igual ao de `ability-catalog.json`.
5. Antes de operar, confira serviços, recursos e identidade da conexão.

## Verificação da versão 0.34.0

O conjunto da rodada reúne Google 0.34.0, Site Core 1.80.0, MCP 0.44.0, Meta 0.23.0, LinkedIn 0.20.0 e Pipedrive 0.9.0. A base de migração é Google 0.33.0. O relatório de entrega identifica os pacotes e registra o resultado efetivo de cada ambiente.

Para o pedido 50, valide a origem em CORE-ACERVOS.md com um clique conhecido, um dia pendente e uma concessão revogada. Confira o papel de cada imagem e a identificação do anúncio.

1. Em uma instalação limpa, ative o Google e abra a Ajuda como administrador. Verifique a leitura do guia e o agendamento do executor.
2. Para testar a atualização, configure uma segunda conexão na base, salve um recurso e registre sua revisão. Substitua o pacote, reabra o painel e confira a conexão, o recurso, a revisão e o estado das credenciais.
3. Em **Conexão → Serviços e recursos**, preencha uma propriedade GA4 ou uma planilha pelo ID, revise e salve. Repita o preenchimento com JavaScript desativado. Uma consulta parcial mostra apenas as sugestões da página recebida.
4. Repita a consulta após uma falha e depois de mudar a configuração em outra aba. Confira a mensagem e refaça a leitura com o formulário atual.
5. Verifique que um usuário sem a capacidade administrativa não consegue salvar nem ler a documentação pelo canal protegido.

O PHPUnit usa respostas simuladas do fornecedor. O laboratório executa WordPress com banco real. A aceitação de uma conta Google, incluindo permissões de Ads e entrega de conversões, exige acesso ao ativo correspondente.
