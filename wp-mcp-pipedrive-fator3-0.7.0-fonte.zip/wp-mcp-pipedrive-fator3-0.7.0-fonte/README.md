# Fator3 MCP Pipedrive 0.7.0 — fonte de desenvolvimento

Instale o **ZIP instalador**. Este fonte contém a árvore exata em `plugin/wp-mcp-pipedrive-fator3/`, scripts em `build/`, testes em `tests/`, referências em `inputs/` e evidências em `evidence/`. O guia operacional para o administrador está no instalador: **Ferramentas → Fator3 MCP Pipedrive → Ajuda → Guia do painel**.

## Requisitos e preparação

WordPress 7.1.4+, PHP 8.3+ de 64 bits com OpenSSL e mbstring, banco com InnoDB. O build usa Python 3 e a biblioteca padrão; não exige Composer, npm ou um serviço externo. Os testes de navegador usam Playwright para Python e um Chromium real. A atualização direta parte da versão 0.6.0. O conjunto final testado está no relatório e em `evidence/inventory-final.json`.

## Reproduzir os pacotes

Na raiz extraída deste fonte, escolha um diretório de saída **fora** desta árvore:

```sh
php build/schemas.php > plugin/wp-mcp-pipedrive-fator3/docs/schemas.json
python3 build/package.py installer --out /caminho/saida
python3 build/verify.py --php /caminho/php --installer /caminho/saida/wp-mcp-pipedrive-fator3-0.7.0-instalador.zip
python3 build/package.py source --out /caminho/saida
```

`verify.py` refaz o lint, confere o schema gerado, reproduz o instalador e compara hashes/evidências congeladas. Para executar WordPress, use os cenários de `tests/README.md`. Alterar o pacote instalado exige nova versão; o fonte conserva uma cópia do relatório anterior ao fechamento do próprio ZIP.

## Onde começar no código

- `includes/Admin.php` organiza as seções e o CSS da tela. `AdminRules.php` traduz o formulário e apresenta a revisão; `AdminDocument.php` apresenta a documentação instalada. A validação e a escrita continuam no domínio, também utilizado pelo MCP/REST.
- `Configuration.php` valida os tipos e as regras, lê a opção sem criá-la e usa revisão e comparação dos bytes na gravação. `Workflows.php` vincula prévias à conta, administrador e revisão; o painel aceita apenas prévias de configuração.
- `Rules.php` e `Cadence.php` calculam a fila. `Collection.php` verifica identidade, paginação e orçamento de coleta. `Store.php` preserva o vínculo entre recibo e diário. `CoreClient.php` consome o cliente do Core, dono da credencial e transporte.
- `Insights.php` indexa atividades por vínculo e separa regras constatadas de regras não avaliadas. `Workflows.php` resolve o mesmo recibo de mensagem apesar da ordem das propriedades; `Store.php` preserva evidência durante a reconciliação.
- `docs/PANEL.md` começa pelo fluxo do administrador. O índice contém os 12 IDs publicados; `schemas.json` vem de `build/schemas.php`.

Consulte o relatório externo para versões efetivamente exercitadas, chamadas realizadas no Site-Teste e limites da prova. A publicação no repositório/frota não faz parte desta entrega.
