# Referências da rodada — Fator3 MCP Pipedrive 0.7.0

## Pedido e normas

O pedido do dono é uma nova rodada de revisão de código e funcionalidades, ampliação dos testes automatizados, melhoria da configuração e dos textos do painel e atualização da documentação. Instalação e teste estão autorizados no Site-Teste. O pedido direto não recebeu número; não foi criado um item por conta própria na aba central.

As duas cópias desta pasta vieram das fontes anexadas ao projeto. Ambas são a **revisão 5, de 02/11/2026**:

| Documento | Bytes | SHA-256 |
|---|---:|---|
| `01-padrao-desenvolvimento-plugins-fator3.md` | 65.983 | `6dd73913cf41f0157a8e68cf922cbc2b97757537488fcf441ef67a9dee5e3166` |
| `02-instrucoes-agentes-plugins-fator3.md` | 12.765 | `f0c48263597444bf304be515e3a61d268751c47cd5eaf7dfcfa9db7ea47773fc` |

O padrão completo prevalece em caso de divergência; os mínimos são PHP 8.3 e WordPress 7.1.4. A revisão 5 incorpora a regra comum de 16/10/2026. Não houve acesso direto a uma versão mais recente da aba central do pacote.

## Base e pedido numerado herdado

| Artefato de origem | Bytes | SHA-256 calculado na rodada |
|---|---:|---|
| `wp-mcp-pipedrive-fator3-0.6.0-instalador.zip` | 106.032 | `0cfec48e6142064d6024b49e9026e79e359178ae04846fd5c442597c6b70908e` |
| `wp-mcp-pipedrive-fator3-0.6.0-fonte.zip` | 273.167 | `42c0fbdb6cb055ba12fc39a2263986d9cdad8012b3eb56bd72d06bde475d5d9f` |
| `wp-mcp-pipedrive-fator3-0.6.0-relatorio.md` | 18.041 | `92b4802d6997ee131875bc5eeb29a618681eed42c5d2de8a3ae78a72d0e2990c` |

No fonte-base, `inputs/pedidos-pipedrive-base.md` contém a aba “Pedidos — Fator3 MCP Pipedrive” de 30/10/2026 (6.788 bytes; SHA-256 `e66834abe3aedb9ab082cd45f79a56f8fb1043542f0b5be4ea17be43a5636791`). **Pedidos MCP Pipedrive 10** abrange registro idempotente de WhatsApp; auditoria da data de etapa e nomes de organização; formato da nota; calendário, prazo útil, textos condicionais e exceções de canal da cadência. A 0.6.0 registrou esses itens como regressões e manteve pendente o aceite em conta Pipedrive real no site-porta. As provas desta rodada em registros sintéticos não encerram esse aceite nem alteram a aba.

## Acompanhantes e relatórios examinados

No Site-Teste, o inventário de abertura (`evidence/inventory-initial.json`) tem Meta 0.20.0; no inventário de retomada (`evidence/inventory-resume.json`), Meta 0.21.0. Core, MCP, Google e LinkedIn mantiveram suas versões. A tabela identifica a referência usada na integração. As identidades de instaladores vêm dos relatórios dos mantenedores ou, para Meta, do cálculo sobre o ZIP identificado; os resultados da própria bancada ficam em `evidence/`.

| Plugin | Versão de referência | SHA-256 do instalador | Fronteira avaliada |
|---|---|---|---|
| `base-site-core-fator3` | 1.71.0 | `7aa9f94e4ecfd30db81ab10603981fb3e4503f7039aeaf5b0fae1ab287d37e57` | O contrato administrativo 8.33.0 acrescenta leitura de resumo na medição de vitais. O cliente comercial continua `pipedrive-api-client/1.0.0`: o Core retém credencial, autorização, revisão, transporte e orçamento. |
| `wp-mcp-fator3` | 0.40.0 | `2434f99df49c56b6f0200d0ddca18c6dffe1b7c6058c2c88f04859f1e046bd81` | As mudanças do painel de clientes, das opções do canal administrativo e da Ajuda do MCP não pedem adaptação do registro `pipedrive/` nem das operações de documentação. |
| `wp-mcp-google-fator3` | 0.28.0 | `10d3722e12d1493308273ab0febbabe68f8dd4c901c7abb3a7c03d3cec3e8919` | Mudanças próprias em planejador, conversões e telas Google; o Pipedrive não consome o histórico de palavras-chave nem os leitores de conversão do Google. |
| `wp-mcp-meta-fator3` | 0.21.0 | `9589456a2ee5ed13cb72941437e4350c0815907f6ba20b8eb47837a77064334a` | A revisão de acesso aos datasets Ads, confirmação de partes do histórico, invalidação de contexto no painel e índice da ajuda são próprios da Meta. O Pipedrive não lê datasets Ads, cursores de exportação ou credenciais da Meta. |
| `wp-mcp-linkedin-fator3` | 0.18.0 | `1e6c6e398ab2c507d827e428ae3b28099753459ef1b97a04ddf1c3922d819460` | A regra de canal de um lead no Pipedrive não registra ingestão LinkedIn nem requer cliente Lead Sync. |

Fontes: relatórios `base-site-core-fator3-1.71.0-relatorio.md` (revisão 1, SHA-256 local `d8962a190a8f90d813f1ace825d8380832f297c37751b5be7dce177c764e3f4e`), `wp-mcp-fator3-0.40.0-relatorio.md` (revisão 1, SHA-256 local `06f2e47c79b77a27fd946452244a092c8e2464396d5175b26a50737cd8e16779`, seção 2 para o hash LinkedIn) e `wp-mcp-google-fator3-0.28.0-relatorio.md` (revisão 1, lida integralmente). Para Meta, versão, CRC, hash e notas `docs/CHANGELOG.md` foram conferidos no instalador 0.21.0 (243.040 bytes). O recibo de instalação do mantenedor confirma 0.20.0 → 0.21.0, ativo, com o mesmo SHA-256; o inventário próprio confirma a versão ativa. O relatório de entrega 0.21.0 ainda não foi localizado nas fontes consultadas. Os pacotes dos acompanhantes não integram este fonte.

## Impacto e limites

O encaminhamento recebido `base-site-core-fator3-1.51.0-impacto-wp-mcp-pipedrive-fator3.md` (revisão 1 de 24/10, 3.969 bytes; SHA-256 da cópia no fonte-base `75a99cfffc1719e1bb9eff8345532a09ef66671987407e7a6bfbc531dcf56e04`) trata de **Pedido Core 294, C1–C8**. Mantém-se a distinção entre bloqueio antes do despacho e resultado externo incerto; uma resposta incerta exige reconciliação. O cliente permanece indisponível isoladamente quando não há Core compatível, sem impedir a documentação e o painel locais.

Foram consultados os anexos deste projeto, a última entrega, os relatórios de Core, MCP e Google, as notas 0.21.0 do pacote Meta e os índices de documentos disponíveis, incluindo busca por impacto endereçado ao slug Pipedrive. Não foi localizado impacto novo endereçado ao Pipedrive nem identificada adaptação necessária em outro plugin para os fluxos desta rodada. O Implantador não constava no conjunto ativo observado, não foi instalado nesta rodada e não recebeu encaminhamento. Estas conclusões são limitadas às fontes consultadas; não se atribuem testes funcionais dos serviços sociais, do Google ou do Pipedrive real a esta análise documental.
