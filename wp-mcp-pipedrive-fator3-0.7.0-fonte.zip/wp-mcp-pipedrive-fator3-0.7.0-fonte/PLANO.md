# Plano da rodada 0.7.0 — Fator3 MCP Pipedrive

Rodada de implementação sobre `wp-mcp-pipedrive-fator3` 0.6.0, instalador SHA-256 `0cfec48e6142064d6024b49e9026e79e359178ae04846fd5c442597c6b70908e`. Alvo previsto: 0.7.0; o pacote não estava fechado no planejamento. Documentos centrais: revisão 5, 02/11/2026. Referência de ambiente: WordPress 7.1.4, PHP 8.3, Site-Teste Fator3. Sem testes em site-porta.

1. Auditar rotas de escrita, confirmação, colisões e retenção. Cobrir recibos anteriores, ambiguidade, erro no diário, prevenção de repetição e confronto do estado antes/depois da atualização direta.
2. Reproduzir falhas de interpretação de dados incompletos e custo das buscas repetidas por vínculo. Cobrir falha parcial, conjuntos duplicados, limites e identidade de catálogo/registros.
3. Reapresentar a confirmação corrigível sem nova simulação; tratar expiração, capacidade, escopo de operação e alteração concorrente. Testar Ajuda com leitura semântica, listas, tabelas e JSON paginado, em teclado, desktop e celular.
4. Atualizar material embarcado e ler cada documento pela interface MCP instalada. Preservar contratos de acompanhantes. Nenhuma necessidade inicial de alterar outro plugin: reavaliar depois da integração.
5. Comparar o instalador com o runtime fonte; exercitar instalação limpa, atualização 0.6.0→0.7.0 e coexistência com cópia congelada dos acompanhantes reais. Aplicar o mesmo ZIP no Site-Teste e conferir integridade, dados, descoberta, saúde e remoção dos recursos temporários. Não emitir transações comerciais nem habilitar o Core no site-porta.
