<?php
/** Fixed QA snapshot and aggregate-report fixture. Remove after this round. */
defined('ABSPATH')||exit;
add_action('f3_mcp_register_providers',static function($v){if($v===1&&class_exists('Fator3\\McpFiles\\ExtensionContract'))Fator3\McpFiles\ExtensionContract::register('f3-pipedrive-shared-qa070','0.7.0',['qa-pipedrive070-shared/']);});
add_action('wp_abilities_api_init',static function(){wp_register_ability('qa-pipedrive070-shared/run',[
 'label'=>'Pipedrive 0.7.0 QA','description'=>'Fixed snapshot of own state and in-memory report fixture; no account API or database mutation.',
 'category'=>'site','input_schema'=>['type'=>'object','properties'=>['acao'=>['type'=>'string','enum'=>['snapshot']]],'required'=>['acao'],'additionalProperties'=>false],
 'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),
 'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false]],
 'execute_callback'=>static function($i){
  global $wpdb;
  if(home_url('/')!=='https://fator3-teste-mcp-1.dreamhosters.com/'||!current_user_can('manage_options'))return new WP_Error('qa_guard','Wrong site or capability');
  $tables=[];foreach(['ops','journal'] as $name){$table=Fator3\Pipedrive\Store::table($name);$rows=$wpdb->get_results('SELECT * FROM `'.$table.'`',ARRAY_A);$hashes=array_map(static fn($x)=>hash('sha256',wp_json_encode($x)),$rows);sort($hashes);$tables[$name]=['rows'=>count($rows),'sha256'=>hash('sha256',wp_json_encode($hashes))];}
  $retention=Fator3\Pipedrive\Retention::read();
  $client=Fator3\Pipedrive\Api::dispatch('status');
  $manifest=[];$root=Fator3\Pipedrive\ROOT;$iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));foreach($iterator as $f)if($f->isFile())$manifest[substr($f->getPathname(),strlen($root)+1)]=hash_file('sha256',$f->getPathname());ksort($manifest);
  return ['version'=>Fator3\Pipedrive\VERSION,'tables'=>$tables,'retention_sha256'=>hash('sha256',wp_json_encode($retention)),'diario_dias'=>$retention['diario_dias'],'schema'=>get_option('f3_pipedrive_schema'),'core_operation_option_sha256'=>hash('sha256',(string)$wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name='f3base_pipedrive_operacao'")),'rules_raw_sha256'=>hash('sha256',(string)$wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name='f3_pipedrive_operation_rules'")),'core_status_code'=>$client['code'],'runtime_sha256'=>$manifest,'runtime'=>['wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'mysql'=>$wpdb->db_version()]];
 }
]);},40);
