<?php
/** Native MCP executor, original 0.40.0, in disposable WordPress. */
use Fator3\McpFiles as C;
use Fator3\Pipedrive\{Api,Documentation};
if (!defined('F3_PIPEDRIVE_DISPOSABLE')) { exit(2); }
wp_set_current_user(1);$checks=[];$reads=[];$http=0;
$check=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
$block=static function()use(&$http){++$http;return new WP_Error('qa_block','No network in fixture');};add_filter('pre_http_request',$block,1);
$inventory=[];foreach(['base-site-core-fator3'=>'1.71.0','wp-mcp-fator3'=>'0.40.0','wp-mcp-google-fator3'=>'0.28.0','wp-mcp-meta-fator3'=>'0.21.0','wp-mcp-linkedin-fator3'=>'0.18.0'] as $slug=>$version){$file=$slug.'/'.$slug.'.php';$data=get_plugin_data(WP_PLUGIN_DIR.'/'.$file,false,false);$inventory[$slug]=['version'=>$data['Version'],'active'=>is_plugin_active($file)];$check('convivencia_'.$slug,$inventory[$slug]['active']&&$data['Version']===$version);}
$grant='pipedrive-qa-'.bin2hex(random_bytes(8));
C\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>1,'client_id'=>'qa-pipedrive','profile'=>'maintenance','status'=>'active']);
C\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$grant,'client_id'=>'qa-pipedrive','profile'=>'maintenance']);
$execute=static function($op,$i=[]){return \WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute(['ability_name'=>'pipedrive/'.$op,'parameters'=>$i]);};
try {
    $listing=C\Discovery::listing(wp_get_abilities(),['prefix'=>'pipedrive/','compact'=>true,'per_page'=>50]);
    $check('provider_novo_descoberto',($listing['total']??0)===19);
    $check('provider_versao_exata',count(array_filter($listing['abilities']??[],static fn($x)=>$x['provider']==='wp-mcp-pipedrive-fator3'&&$x['version']==='0.7.0'))===19);
    foreach (Documentation::DOCUMENTS as $id=>$file) {
        $offset=0;$text='';$pages=0;$hash=null;
        do {
            $args=['documento'=>$id,'offset'=>$offset,'limite_bytes'=>2048];if ($hash) {$args['sha256_esperado']=$hash;}
            $r=$execute('documentacao-ler',$args);
            $d=$r['data']['data']??null;
            if (empty($r['success'])||empty($r['data']['success'])||!is_array($d)) { throw new RuntimeException('MCP document failed: '.json_encode($r)); }
            $text.=$d['conteudo'];$offset=$d['proximo_offset'];$hash=$d['sha256'];++$pages;
        } while ($offset!==null);
        $check('mcp_doc_'.$id,$text===file_get_contents(Fator3\Pipedrive\ROOT.'/docs/'.$file)&&hash('sha256',$text)===$hash);
        $reads[]=['documento'=>$id,'sha256'=>$hash,'bytes'=>strlen($text),'pages'=>$pages];
    }
    $check('docs_sem_fornecedor',$http===0);
    $r=$execute('status');$check('core_registrado_contrato',($r['data']['data']['registro_cliente']??'')==='registrado');
    C\Persistence::put('connections','grant:'.$grant,['connection_id'=>'grant:'.$grant,'user_id'=>1,'profile'=>'read','status'=>'active','policy_version'=>2,'expires'=>0]);
    $check('perfil_leitura_recusa_retencao',is_wp_error(C\AuthorizationPolicy::check('pipedrive/retencao-configurar',[],false)));
    $check('perfil_leitura_nao_escreve',is_wp_error(C\AuthorizationPolicy::check('pipedrive/api-aplicar',[],false)));
    $check('perfil_leitura_documentacao',C\AuthorizationPolicy::check('pipedrive/documentacao-ler',[],true)===true);
    $meta=wp_get_ability('pipedrive/api-previa')->get_meta();$check('previa_classificada_escrita',empty($meta['annotations']['readonly'])&&($meta['fator3']['remote_effect']??'')==='read');
    $meta=wp_get_ability('pipedrive/status')->get_meta();$check('status_observacional',!empty($meta['annotations']['readonly'])&&($meta['fator3']['local_effect']??'')==='none');
    $check('sem_executor_irrestrito',!C\AuthorizationPolicy::executor(wp_get_ability('pipedrive/api-aplicar')));
    $client=new class {
 public function capabilities(){return ['contract'=>'pipedrive-api-client/1.0.0'];}
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>1,'usuario_id'=>2],'revisao'=>'r1','orcamento'=>['teto'=>3000,'consumido'=>0,'reservado'=>0],'saldo_conta'=>null]];}
 public function request($m,$p,$q,$b,$c){return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>['api_token'=>'secret-fixture','name'=>'Allowed fixture']],'saldo_conta'=>null]];}
};
$registry=new class($client){public function __construct(public $client){}public function register_consumer(...$args){return $this->client;}};
\Fator3\Pipedrive\CoreClient::register($registry,'pipedrive-api-client/1.0.0');
$redacted=$execute('api-ler',['caminho'=>'/v1/users/me']);
$check('saida_redigida_no_executor',!empty($redacted['data']['success'])&&!str_contains(json_encode($redacted),'secret-fixture')&&str_contains(json_encode($redacted),'Allowed fixture'));
$reportClient=new class {
 public function capabilities(){return ['contract'=>'pipedrive-api-client/1.0.0'];}
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>1,'usuario_id'=>2],'revisao'=>'r1','orcamento'=>['teto'=>3000,'consumido'=>0,'reservado'=>0],'saldo_conta'=>null]];}
 public function request($m,$p,$q,$b,$c){$data=[];if($p==='/v1/dealFields')foreach(['Parceiro','Unidade','Canal','Campanha','Ponto de conversão'] as $n=>$name)$data[]=['key'=>str_repeat((string)($n+1),40),'name'=>$name,'field_type'=>'enum','options'=>[]];return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>$data,'additional_data'=>str_starts_with($p,'/api/v2/')?['next_cursor'=>null]:['pagination'=>['more_items_in_collection'=>false]]],'saldo_conta'=>null]];}
};
$registry=new class($reportClient){public function __construct(public $client){}public function register_consumer(...$args){return $this->client;}};
\Fator3\Pipedrive\CoreClient::register($registry,'pipedrive-api-client/1.0.0');
$r=$execute('relatorio',['data_inicio'=>'2026-09-28','data_fim'=>'2026-10-27','limite_plano'=>1000]);
$check('report_read_profile_execution',($r['data']['data']['completo']??false)===true);
$check('report_mcp_cost',($r['data']['data']['custo']['gasto']??null)===100);
$meta=wp_get_ability('pipedrive/relatorio')->get_meta();$check('report_remote_read',($meta['fator3']['remote_effect']??'')==='read'&&!empty($meta['annotations']['readonly']));
$check('report_mcp_zero_http',$http===0);
foreach(['cadencia-fila','auditoria','contar-por-campo','configuracao-ler'] as $newop){$args=$newop==='contar-por-campo'?['entidade'=>'leads','campo'=>str_repeat('1',40)]:[];$result=$execute($newop,$args);$check('new_mcp_read_'.$newop,!empty($result['data']['success']));}
foreach(['configuracao-simular','operacao-aplicar','whatsapp-registrar','lead-encerrar','negocio-perder','lead-arquivado-editar'] as $newop)$check('read_profile_denies_'.$newop,is_wp_error(C\AuthorizationPolicy::check('pipedrive/'.$newop,[],false)));

} finally {
    C\Persistence::delete('connections','grant:'.$grant);C\Persistence::delete('oauth-grants',$grant);C\ConnectionContext::restore_identity(null,1);remove_filter('pre_http_request',$block,1);
}
return ['checks'=>$checks,'passed'=>count(array_filter($checks,static fn($x)=>$x['passed'])),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),
    'companions'=>$inventory,'runtime_sha256'=>(function(){$out=[];$dir=Fator3\Pipedrive\ROOT;foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS)) as $f){if($f->isFile())$out[substr($f->getPathname(),strlen($dir)+1)]=hash_file('sha256',$f->getPathname());}ksort($out);return $out;})(),'documents'=>$reads,'pages'=>array_sum(array_column($reads,'pages')),'mcp_version'=>F3_MCP_FILES_VERSION,'transport'=>'Executor MCP original em WordPress isolado; sem sessão HTTP MCP própria','http_real'=>$http];
