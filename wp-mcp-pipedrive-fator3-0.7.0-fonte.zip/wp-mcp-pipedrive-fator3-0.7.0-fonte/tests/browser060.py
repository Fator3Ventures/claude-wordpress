#!/usr/bin/env python3
"""Real Chromium submits plugin forms to Admin::page in a disposable WP through a file bridge.
The bridge transports only synthetic test requests. It does not simulate the PHP result."""
import argparse,json,time,re,os,sys,subprocess
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();transport=p.add_mutually_exclusive_group(required=True);transport.add_argument('--bridge',type=Path);transport.add_argument('--local-runner',type=Path);p.add_argument('--php',default='php');p.add_argument('--chromium',required=True);p.add_argument('--wp',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--screens',type=Path,required=True);args=p.parse_args()
if args.bridge:args.bridge.mkdir(parents=True,exist_ok=True)
args.screens.mkdir(parents=True,exist_ok=True)
root=Path(__file__).resolve().parents[1];css=root/'plugin/wp-mcp-pipedrive-fator3/assets/admin.css';checks=[];fixtures='absent';profile='admin';last={};requests=[];errors=[]
# Missing style sheets inside a route callback would otherwise leave Chromium waiting for navigation.
styles={'/assets/admin.css':css,'/assets/common.css':args.wp/'wp-admin/css/common.min.css','/assets/forms.css':args.wp/'wp-admin/css/forms.min.css','/assets/buttons.css':args.wp/'wp-includes/css/buttons.min.css'}
missing=[str(file) for file in styles.values() if not file.is_file()]
if missing:p.error('Missing WordPress or plugin stylesheets: '+', '.join(missing))
def check(name,v):
 checks.append({'name':name,'passed':bool(v)})
 if not v:raise AssertionError(name)
def params(q):
 out={}
 for k,v in parse_qs(q,keep_blank_values=True).items():out[k[:-2] if k.endswith('[]') else k]=v if k.endswith('[]') else v[-1]
 return out
def route(r):
 global last
 url=urlsplit(r.request.url)
 if url.netloc!='pipedrive-qa.test':r.abort();return
 if url.path.startswith('/assets/'):
  if url.path in styles:r.fulfill(content_type='text/css',body=styles[url.path].read_bytes());return
 if url.path!='/wp-admin/tools.php':r.fulfill(status=404,body='');return
 n=len(requests);q=params(url.query);post=params(r.request.post_data or '');req={'get':q,'post':post,'fixture':fixtures,'profile':profile};
 if args.local_runner:
  run=subprocess.run([args.php,str(args.local_runner.resolve()),'ui060'],input=json.dumps(req),capture_output=True,text=True,timeout=120,check=True)
  last=json.loads(run.stdout.rsplit('F3_QA_RESULT=',1)[1])
 else:
  tmp=args.bridge/f'req-{n}.tmp';tmp.write_text(json.dumps(req));tmp.rename(args.bridge/f'req-{n}.json');target=args.bridge/f'resp-{n}.json';start=time.monotonic()
  while not target.exists():
   if time.monotonic()-start>120:raise TimeoutError(f'No WordPress response for {n}')
   time.sleep(.12)
  last=json.loads(target.read_text())
 html=last.pop('html');requests.append({'method':r.request.method,'section':q.get('aba','visao'),'action':post.get('f3_pipedrive_action'),'status':last['status'],'fixture_reads':last['fixture_reads'],'supplier_writes':last['supplier_writes']});
 page='<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pipedrive QA</title>'+''.join('<link rel="stylesheet" href="/assets/'+n+'.css">' for n in ['common','forms','buttons','admin'])+'</head><body class="wp-admin wp-core-ui"><div id="wpbody-content" style="box-sizing:border-box;padding-left:12px">'+html+'</div></body></html>'
 r.fulfill(status=last['status'],content_type='text/html; charset=utf-8',body=page)
result={'wp_backend':'isolated Site-Teste via fixed MCP bridge; no browser login to shared site','checks':checks,'requests':requests}
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(executable_path=args.chromium,args=['--disable-dev-shm-usage']);result['browser']=b.version
  context=b.new_context(viewport={'width':1280,'height':900},locale='pt-BR');page=context.new_page();page.set_default_timeout(90000);page.route('**/*',route);page.on('pageerror',lambda ex:errors.append(str(ex)))
  def click(label,role='button'):page.get_by_role(role,name=label,exact=True).click();page.wait_for_load_state('load')
  def label(txt):return page.get_by_label(txt,exact=True)
  def screen(n):page.screenshot(path=str(args.screens/(n+'.png')),full_page=True)
  url='https://pipedrive-qa.test/wp-admin/tools.php?page=wp-mcp-pipedrive-fator3';page.goto(url);check('unavailable_core_actionable',page.get_by_role('heading',name='Cliente do Site Core indisponível').count()==1 and last['fixture_reads']==0);screen('overview-desktop')
  fixtures='ok';click('Regras de operação','link');check('guided_labels_present',label('Fuso horário').count()==1 and label('Arquivamento de leads').count()==1);check('field_help_associated',all(page.locator('#'+id).count()==1 for id in page.locator('[aria-describedby]').evaluate_all('(els)=>els.flatMap(e=>e.getAttribute("aria-describedby").split(" "))')))
  stamp=last['rules_revision'];drafts=last['drafts'];label('Fuso horário').fill('America/Sao_Paulo');label('Segunda').check();label('Início da janela').fill('09:00');label('Fim da janela').fill('18:00');label('Períodos').fill('manha 09:30');label('Feriados').fill('2026-12-25');label('Perda de negócios').fill('Motivo de teste');click('Validar campos');check('local_validate_no_io_or_save','Campos válidos' in page.locator('main').inner_text() and last['fixture_reads']==0 and last['drafts']==drafts and last['rules_revision']==stamp);check('draft_retained',label('Fuso horário').input_value()=='America/Sao_Paulo');
  label('Períodos').fill('sem-horario');click('Validar campos');check('invalid_guided_error_preserves_draft','Em Períodos' in page.get_by_role('alert').inner_text() and label('Períodos').input_value()=='sem-horario');label('Períodos').fill('manha 09:30');
  fixtures='partial';click('Simular na conta');check('partial_has_no_apply',page.get_by_role('button',name='Aplicar regras simuladas').count()==0 and 'Coleta incompleta' in page.get_by_role('alert').inner_text() and last['drafts']==drafts);
  fixtures='ok';click('Simular na conta');check('simulation_does_not_save',last['drafts']==drafts+1 and last['rules_revision']==stamp and last['fixture_reads']>0);check('comparison_shows_changed_groups','Fuso horário' in page.locator('.f3pd-confirm').inner_text() and 'Feriados' in page.locator('.f3pd-confirm').inner_text());screen('review-desktop');
  confirm=page.get_by_role('button',name='Aplicar regras simuladas');entries=len(requests);confirm.click();check('browser_prevents_empty_confirmation',len(requests)==entries and not label('Frase de confirmação').evaluate('(e)=>e.validity.valid'));
  stale=page.context.new_page();stale.route('**/*',route);stale.goto(url+'&aba=regras');
  phrase=page.locator('.f3pd-phrase').inner_text();preview=page.locator('[name=previa_id]').input_value()
  label('Frase de confirmação').fill('frase incompleta');label('Recebi a ordem do dono para aplicar estas regras.').check();click('Aplicar regras simuladas')
  check('wrong_phrase_recovers_same_preview',page.get_by_role('heading',name='Corrigir a confirmação').count()==1 and page.get_by_role('alert').count()==1 and page.locator('[name=previa_id]').input_value()==preview and page.locator('.f3pd-phrase').inner_text()==phrase)
  check('retry_preserves_revision_budget_and_draft_count',last['rules_revision']==stamp and last['fixture_reads']==0 and last['drafts']==drafts+1)
  check('retry_requires_fresh_confirmation',label('Frase de confirmação').input_value()=='' and not label('Recebi a ordem do dono para aplicar estas regras.').is_checked());screen('confirmation-retry')
  label('Frase de confirmação').fill(phrase);label('Recebi a ordem do dono para aplicar estas regras.').evaluate("e=>e.removeAttribute('required')");click('Aplicar regras simuladas')
  check('server_missing_order_recovers_without_save','ordem do dono' in page.get_by_role('alert').inner_text() and page.locator('[name=previa_id]').input_value()==preview and last['rules_revision']==stamp and last['fixture_reads']==0 and last['drafts']==drafts+1)
  outdated=context.new_page();outdated.route('**/*',route);outdated.goto(url+'&aba=regras');outdated.get_by_label('Fuso horário',exact=True).fill('Europe/Lisbon');outdated.get_by_role('button',name='Simular na conta').click();outdated.wait_for_load_state('load')
  label('Frase de confirmação').fill(phrase);label('Recebi a ordem do dono para aplicar estas regras.').check();click('Aplicar regras simuladas');check('confirmed_change_persisted',last['zone']=='America/Sao_Paulo' and last['rules_revision']!=stamp and 'Regras persistidas' in page.locator('main').inner_text());
  outdated.get_by_label('Frase de confirmação',exact=True).fill('frase incorreta');outdated.locator('[name=ordem]').evaluate("e=>e.removeAttribute('required')");outdated.get_by_role('button',name='Aplicar regras simuladas').click();outdated.wait_for_load_state('load')
  check('stale_preview_never_reoffered','As regras mudaram' in outdated.get_by_role('alert').inner_text() and outdated.locator('.f3pd-phrase').count()==0 and last['fixture_reads']==0 and last['zone']=='America/Sao_Paulo');outdated.close()
  stable=last['rules_revision'];stale.get_by_label('Fuso horário',exact=True).fill('Europe/Lisbon');stale.get_by_role('button',name='Simular na conta').click();stale.wait_for_load_state('load');check('stale_browser_tab_refused_before_read','As regras mudaram' in stale.get_by_role('alert').inner_text() and last['fixture_reads']==0 and last['rules_revision']==stable);stale.get_by_role('link',name='Recarregar regras atuais').click();check('stale_form_reload_uses_persisted_zone',stale.get_by_label('Fuso horário',exact=True).input_value()=='America/Sao_Paulo');stale.close()
  click('Configuração completa (JSON)','link');obj=json.loads(label('Objeto de regras').input_value());check('saved_guided_fields_in_full_object',obj['feriados']==['2026-12-25'] and obj['dias']==[1] and obj['lost_reasons']==['Motivo de teste']);
  attack='</textarea><img id="qa-injected" src="x">';label('Objeto de regras').fill(attack);click('Validar campos');check('invalid_json_escaped_and_retained',page.locator('#qa-injected').count()==0 and label('Objeto de regras').input_value()==attack and 'JSON válido' in page.get_by_role('alert').inner_text());
  click('Diário e retenção','link');label('Dias de conservação').fill('45');click('Salvar retenção');check('finite_requires_consent',last['retention']==0 and page.get_by_role('alert').count()==1);label('Dias de conservação').fill('45');page.locator('[name=confirmar_expurgo]').check();click('Salvar retenção');check('finite_saved_in_wp',last['retention']==45 and page.get_by_role('status').count()==1);label('Dias de conservação').fill('0');click('Salvar retenção');check('unlimited_restored',last['retention']==0)
  click('Ajuda','link');guide=page.locator('article.f3pd-document');check('guide_default_local',guide.get_by_role('heading',name='Configurar o Pipedrive pelo WordPress',exact=True).count()==1 and last['fixture_reads']==0)
  check('guide_semantic_table_list',guide.get_by_role('columnheader',name='Quando usar').count()==1 and guide.locator('ol > li').count()>=3);screen('guide-desktop')
  entries=len(requests);guide.get_by_role('navigation',name='Nesta página').get_by_role('link',name='Conservar o diário').click()
  check('guide_section_navigation_local',len(requests)==entries and page.evaluate('document.getElementById(location.hash.slice(1))?.textContent')=='Conservar o diário')
  click('Exemplos de uso','link');guide=page.locator('article.f3pd-document')
  check('guide_code_and_literal_markup',guide.locator('pre > code').count()>0 and '<resumo exato>' in guide.inner_text() and guide.locator('resumo').count()==0 and last['fixture_reads']==0)
  click('Schemas JSON','link');check('json_stays_plain_source',page.locator('pre.f3pd-source').count()==1 and page.locator('article.f3pd-guide').count()==0)
  click('Ler próxima parte','link');check('revision_bound_reading_page','revisao=' in page.url and 'offset=16000' in page.url and last['fixture_reads']==0)
  page.goto(re.sub(r'revisao=[a-f0-9]{64}','revisao='+'0'*64,page.url));check('changed_doc_has_restart',page.get_by_role('alert').count()==1 and page.get_by_role('link',name='Voltar ao início do documento').count()==1 and page.locator('.f3pd-document').count()==0);click('Voltar ao início do documento','link')
  page.set_viewport_size({'width':360,'height':800});click('Guia do painel','link');check('mobile_guide_no_horizontal_scroll',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'));screen('guide-mobile')
  clicks=len(requests);page.set_viewport_size({'width':360,'height':800});click('Regras de operação','link');check('mobile_no_horizontal_scroll',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'));check('mobile_tabs_reachable',page.locator('.f3pd-tabs a').count()==4);screen('rules-mobile');page.locator('[name=fuso]').focus();page.keyboard.press('Tab');check('keyboard_advances_to_labeled_field',page.locator(':focus').get_attribute('name')=='tipo_whatsapp')
  page.locator('input[name=_wpnonce]').evaluate("e=>e.value='invalid-fixture'");click('Validar campos');check('invalid_form_nonce_refused',last['status']==403 and last['rules_revision']==stable)
  profile='anonymous';page.goto(url+'&aba=regras');check('unauthorized_browser_refused',last['status']==403 and not page.locator('textarea').count());check('no_provider_writes',all(x['supplier_writes']==0 for x in requests));check('no_client_errors',not errors);b.close()
except BaseException as e:
 result['error']=type(e).__name__+': '+str(e)[:550]
finally:
 result.update(passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks)+(1 if 'error' in result and not any(not x['passed'] for x in checks) else 0));args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2))
 if args.bridge:(args.bridge/'finished').write_text('done')
 print({k:result.get(k) for k in ['browser','passed','failed','error']})
if result['failed']:sys.exit(1)
