<?php
use Fator3\Pipedrive\{Api,Documentation};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0700'))throw new RuntimeException('Disposable only');
wp_set_current_user(1);$checks=[];$pages=0;
foreach(Documentation::DOCUMENTS as $id=>$file){$offset=0;$text='';$hash=null;do{$a=['documento'=>$id,'offset'=>$offset,'limite_bytes'=>2048];if($hash)$a['sha256_esperado']=$hash;$r=Api::dispatch('documentacao-ler',$a);if(!$r['success'])throw new RuntimeException('Read failed');$d=$r['data'];$text.=$d['conteudo'];$hash=$d['sha256'];$offset=$d['proximo_offset'];$pages++;}while($offset!==null);$checks[$id]=$text===file_get_contents(Fator3\Pipedrive\ROOT.'/docs/'.$file)&&hash('sha256',$text)===$hash;}
$checks['schema_version']=json_decode(file_get_contents(Fator3\Pipedrive\ROOT.'/docs/schemas.json'),true)['version']==='0.7.0';$checks['runtime_version']=Fator3\Pipedrive\VERSION==='0.7.0';
$manifest=[];$root=Fator3\Pipedrive\ROOT;foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $f)if($f->isFile())$manifest[substr($f->getPathname(),strlen($root)+1)]=hash_file('sha256',$f->getPathname());ksort($manifest);
// Use WordPress' actual page hook and style queue, without loading any companion in this site.
require_once ABSPATH.'wp-admin/includes/admin.php';$GLOBALS['admin_page_hooks']['tools.php']='tools';set_current_screen('dashboard');
Fator3\Pipedrive\Admin::menu();$hook=get_plugin_page_hookname(Fator3\Pipedrive\SLUG,'tools.php');
do_action('admin_enqueue_scripts','index.php');$checks['unrelated_screen_has_no_asset']=!wp_style_is('f3-pipedrive-admin','enqueued');
set_current_screen($hook);do_action('admin_enqueue_scripts',$hook);$style=wp_styles()->registered['f3-pipedrive-admin']??null;
$checks['own_screen_enqueues_asset']=wp_style_is('f3-pipedrive-admin','enqueued');
$checks['installed_css_url_and_version']=$style&&str_ends_with((string)wp_parse_url($style->src,PHP_URL_PATH),'/plugins/wp-mcp-pipedrive-fator3/assets/admin.css')&&$style->ver===Fator3\Pipedrive\VERSION;
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count(array_filter($checks,fn($x)=>!$x)),'pages'=>$pages,'runtime_sha256'=>$manifest,'supplier_http'=>0];
