# Uso — 0.7.0

Todos os exemplos são sintéticos. Substitua IDs apenas por registros autorizados. Leia o schema no catálogo; o transporte MCP pode acrescentar seus próprios campos de controle.

## Leitura e vazio

`pipedrive/status {}` não faz HTTP.

`pipedrive/api-ler {"caminho":"/v1/dealFields","query":{"limit":100,"start":0}}` consulta campos. Resultado: success, code, message e data com http_status, body e saldo_conta. Coleção vazia retorna data do fornecedor vazia; não é erro. Siga a paginação do fornecedor quando presente. Não interpretar saldo null como orçamento ilimitado.

## Atualizar campo personalizado de lead

Primeiro obtenha pelo catálogo a chave real do campo (o ID numérico 152 não substitui a chave de 40 hexadecimais) e os IDs de suas opções.

```json
{"metodo":"PATCH","caminho":"/v1/leads/00000000-0000-4000-8000-000000000001","corpo":{"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa":152}}
```

Enviar a `pipedrive/api-previa`. A resposta mostra estado_atual, corpo_a_enviar, previa_id, expira_em, custo_estimado e classe. Rever tudo. Enviar `pipedrive/api-aplicar {"previa_id":"ID_DEVOLVIDO"}`. Conferir GET do lead e `pipedrive/registro-ler {}`. Repetir o mesmo ID retorna o mesmo recibo dentro da retenção, enquanto usuário/conta/revisão permanecem autorizados; não envia outra chamada. A prévia pendente expira aos 15 minutos, inclusive igualdade no limite.

## Estrutura

Prévia de etiqueta:

```json
{"metodo":"POST","caminho":"/v1/leadLabels","corpo":{"name":"Teste pipedrive-operacao (apagar)","color":"blue"}}
```

Após a ordem do dono, chamar aplicar com previa_id e confirmacao copiados da resposta. A frase é `Confirmo por ordem do dono de DD/MM/AAAA: <resumo exato>`. Confirmacao é obrigatória também para DELETE de etiqueta/campo/filtro. Remover a etiqueta sintética pela mesma sequência DELETE com seu UUID.

Para opções de campo, enviar todas as que devem permanecer, com IDs e labels. Se uma existente for retirada, listar o ID em remover_opcoes. Omitir alguma por engano retorna opcao_seria_apagada, com opções afetadas; não envia PUT. Criar alternativa nova usa label sem id junto das existentes.

## Resultado incerto e erros

* caminho_fora_da_lista: URL absoluta, mailbox, ids em massa, merge, método ou chave não autorizada; zero chamadas.
* confirmacao_ausente: frase ausente ou diferente; zero mutações.
* previa_expirada, previa_de_outro_usuario, contexto_alterado ou estado_alterado: revisar e gerar outra prévia se não houve tentativa anterior.
* resultado_incerto: chamada em execução/interrompida, timeout, 5xx ou recibo não confirmado. Ler registro e consultar a entidade; não gerar outra prévia para repetir sem reconciliar o efeito.
* saldo_conta_baixo, operacao_nao_autorizada, core_em_recuperacao ou orcamento_esgotado: seguir o diagnóstico Core; não alterar filas de entrega.
* resposta_excedeu_limite: limite de 512 KiB. Reduzir paginação nas leituras. Se houve escrita, conferir por GET antes de qualquer nova ação.

Corpos remotos de erro não são expostos porque podem repetir entradas privadas. Não há retry automático. Uma recusa definitiva do fornecedor também produz recibo único; corrigir a entrada exige nova prévia. Código de falha não equivale a certeza de ausência de efeito: consultar remote_dispatched/applied, que podem ser null.

## Distinguir ausência de informação de um problema confirmado

Chame `pipedrive/auditoria {"max_chamadas":20}`. Se o limite interromper a coleção de atividades, a resposta pode trazer `code: coleta_parcial` e este trecho em `data` (ID fictício):

```json
{"coleta_completa":false,"avaliacao_completa":false,"itens_nao_avaliados":[{"entidade":"lead","id":"00000000-0000-4000-8000-000000000001","regra":"sem_proxima_atividade","motivo":"colecao_atividades_incompleta"}]}
```

Esse lead precisa de verificação. Só uma ocorrência da regra em `itens` indica falta de atividade segundo os registros visíveis. Se apenas uma data individual ficou ilegível, a coleta pode estar completa e a avaliação permanecer parcial. Consulte `fluxos` para interpretar motivos e limites.

## Diário local e REST

`pipedrive/registro-ler {"limite":50}` retorna itens e proximo_antes_id; usar esse valor em antes_id. Ordenação estável por id decrescente. O histórico não contém nome, e-mail, telefone, conteúdo de nota ou valor de campo pessoal. Mudanças de estrutura incluem apenas nomes/opções de estrutura.

REST: namespace `/wp-json/f3-pipedrive/v1/`. GET para status, registro-ler, documentacao-ler; POST com JSON para api-ler, api-previa, api-aplicar. Cookie administrativo exige nonce wp_rest; application passwords exigem HTTPS e capacidade administrativa. Respostas têm Cache-Control private, no-store.


## Configurar e verificar retenção

1. `pipedrive/retencao-ler {}`. Anote data.revisao e confira diario_dias.
2. Para conservar o diário permanentemente: `pipedrive/retencao-configurar {"diario_dias":0,"revisao_esperada":"HASH_LIDO"}`. Não há chamada ao fornecedor ou expurgo.
3. Para prazo finito deliberado de 730 dias: `{"diario_dias":730,"revisao_esperada":"HASH_LIDO","confirmar_expurgo":true}`. Linhas anteriores ao corte ficam elegíveis nas próximas limpezas, exceto tentativas em execução e registros protegidos por uma trava de reconciliação.
4. Leia retencao-ler e status novamente; confira persisted=true, política e revisão. Se houver revisao_conflitante, releia e reavalie a escolha antes de enviar nova revisão. Se o Core estiver desautorizado, status pode ter success=false e ainda trazer data.retencao; a configuração local continua disponível.

O diário permanente não prolonga validade de prévias, tokens, locks ou recibos. A linha técnica permanece após a expiração do recibo; ela não contém os valores pessoais da resposta privada cifrada.

## Relatório agregado — pedido 3, herdado da 0.3.0

`pipedrive/relatorio` é leitura administrativa (`manage_options`), com efeito remoto `read`. Usa apenas GET pelo cliente público Core `pipedrive-api-client/1.0.0`, consumidor `operacao`. Não cria diário, recibo, cache, configuração ou cron. A medição do orçamento é do Core. REST: GET `/wp-json/f3-pipedrive/v1/relatorio` com autenticação WordPress; MCP: `pipedrive/relatorio`. Não há novo formulário no painel; a ajuda instalada orienta a chamada.

Exemplo de 30 dias, em America/Sao_Paulo:

```json
{"data_inicio":"2026-09-28","data_fim":"2026-10-27","limite_plano":1500,"max_chamadas":100}
```

O limite 1500 é fictício: substitua pelo valor confirmado em Configurações → Empresa → Uso do Pipedrive. Não é descoberto pela API do Core nem inferido do nome do plano. Omiti-lo deixa `limite`, `percentual` e `saldo` nulos, com `limite_plano_nao_informado`. `total` continua disponível se a coleta ativa estiver completa. Conferir visibilidade global do token antes de comparar o total visível com Uso da conta. O orçamento de API é outra medida.

### Período e contagem

Datas civis reais, inclusivas, fuso IANA (padrão America/Sao_Paulo), até 3660 dias. O fim é convertido ao início do dia seguinte no fuso; timestamps do fornecedor sem offset são UTC. Padrão `criterio_leads: criacao`: leads abertos/arquivados criados no período, conforme `add_time` e estado atual. Negócios por funil/etapa também usam criação. `criterio_leads: arquivamento` usa `archive_time` somente nos leads arquivados; abertos continuam por criação. Se o fornecedor não enviar essa data, o relatório fica parcial, sem substituir por atualização. Portanto não é histórico de todas as transições nem fotografia da conta na data final. Ganhos/perdas atuais usam `won_time`/`lost_time` no período, inclusive negócios arquivados; negócios reabertos não entram como ganho/perda histórica.

`leads.grupos` cruza estado, parceiro, unidade, canal, campanha, ponto_conversao e motivo_arquivamento. Some `quantidade` para obter marginais por Parceiro ou por motivo, ou o cruzamento entre ambos. Campo multisseleção é um conjunto ordenado e sem repetição; um registro conta uma vez no conjunto, não uma vez por membro. `negocios.por_funil_etapa` cruza IDs de funil/etapa, estado e arquivamento. `por_resultado_motivo` agrupa ganhos/perdas. Não existe motivo nativo de ganho documentado: configure o campo customizado `motivo_ganho` ou a categoria retornada será `sem_campo`. Isso não implica que todos os ganhos tenham um motivo comercial conhecido.

`uso_plano` ignora o período: soma leads ativos e negócios open/won/lost não arquivados nem excluídos. Não usa só negócios abertos e não soma arquivados. IDs de registros só deduplicam em memória; duplicatas ou estado divergente indicam possível movimento durante paginação e impedem declarar total fechado. Não há snapshot transacional. Registros excluídos não entram.

### Campos e proteção de dados

O catálogo `/v1/dealFields` é paginado. Descoberta por nome exato, sem acento e sem distinção de caixa: Parceiro, Unidade, Canal, Campanha, Ponto de conversão, Motivo de ganho. Nome ambíguo/ausente gera pendência; `campos` permite chaves hexadecimais de 40 posições para resolver. `campos.canal: channel` seleciona explicitamente o canal nativo. Não se presume equivalência entre canal nativo e campo Canal.

Tipos aceitos: enum, set, varchar, varchar_auto e text. people, user, org, phone e demais tipos não são usados como dimensão. Não saem títulos, nomes, e-mails, telefones, IDs de pessoas/leads/negócios, respostas brutas, textos de motivos ou rótulos livres do fornecedor. Opções conhecidas saem `opcao:ID`; funis/etapas, IDs numéricos. Textos e opções desconhecidas viram `categoria:HMAC-SHA256`, estável por site/conta/dimensão e salt, e não reversível pelo relatório. Isso protege o texto, mas não constitui anonimização estatística; administrador deve tratar agregados pequenos com cuidado. Troca dos salts altera esses códigos.

Para distinguir motivos com códigos de negócio conhecidos sem devolver texto livre, inclua um dicionário opcional, apenas em memória:

```json
{"data_inicio":"2026-09-28","data_fim":"2026-10-27","limite_plano":1500,"categorias":[{"dimensao":"motivo_arquivamento","valor":"Sem interesse","codigo":1},{"dimensao":"motivo_perda","valor":"Preço","codigo":2}]}
```

Correspondência textual exata; retorno `codigo:1`/`codigo:2`. Podem existir até 200 entradas, valor de até 500 caracteres e código inteiro positivo. O chamador guarda o significado dos códigos. Valores nunca são refletidos ou persistidos pelo plugin. Use categorias comerciais, não identidades individuais. A mesma combinação dimensão/valor não pode apontar a códigos distintos. Código igual pode consolidar valores deliberadamente. As dimensões aceitas estão no schema. Campos não preenchidos usam `sem_valor`; campo não mapeado usa `sem_campo`. Para igualdade com a tela, aplique mesmos campos, códigos, visibilidade, fuso e critério de data.

### Completude, paginação e custo

Cinco fontes sequenciais: catálogo, leads ativos, leads arquivados, negócios ativos v2 e negócios arquivados v2. Página de 100, offset v1 e cursor v2; paginação inválida/repetida é erro parcial. `fontes` traz páginas, registros observados e conclusão de cada lista. `coleta_completa` indica fim válido das cinco listas; `completo` exige também ausência de pendências de dados/configuração. Todo contador com sufixo `_observados` é subtotal quando parcial. Fonte não concluída não autoriza interpretar zero como ausência. `success:true, code:relatorio_parcial` entrega agregados parciais com `completo:false` e `pendencias`; nunca ignorar essas flags.

Teto de 100 chamadas por padrão, configurável entre 1 e 120; duração cooperativa padrão 45 segundos, entre 1 e 120. Uma chamada em curso pode levar os 20 segundos de timeout do Core além do limite cooperativo. Máximo 12000 registros entre fontes, 200 grupos e 32000 bytes de dimensões agregadas; exceder qualquer teto interrompe com parcial. Não há retry automático nem cursor de retomada público. Executar novamente recolhe tudo e consome orçamento novamente. Se a conta exceder o teto, esta versão não fecha a coleta numa chamada; registre a pendência em vez de extrapolar contagens.

Core 1.71.0 reserva/debita 20 unidades locais por GET enviado, independentemente do custo oficial da rota. `custo.gasto` soma envios confirmados, inclusive falha HTTP; recusa anterior ao envio custa zero. Envio incerto retorna gasto null, minimo/maximo e envio_incerto. Não usar diferença de saldo global como custo exclusivo desta leitura, pois há concorrência. Aumentar max_chamadas não contorna o orçamento nem a reserva de saldo da conta. Nenhum segredo ou corpo de erro é devolvido.

Sem autorização/Core, datas inválidas ou falta de manage_options, a chamada falha antes da coleta. Se o contexto mudar durante a coleta, retorna parcial. Sem Core, a documentação e retenção local continuam utilizáveis.
