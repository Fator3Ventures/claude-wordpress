# Fator3 MCP Pipedrive 0.7.0

Operações administrativas na conta Pipedrive pelo token que permanece no Site Core. Este pacote não armazena token, não faz HTTP próprio e não interfere nas filas de entrega de leads.

## Por onde começar

- **Administrador do WordPress:** abra Ferramentas → Fator3 MCP Pipedrive. O guia `painel` descreve as quatro seções, os campos e a confirmação.
- **Agente MCP:** consulte `agentes` e `schemas` antes de preparar uma operação. Existem 19 operações administrativas. Leia cobertura, erros e custo antes de usar resultados.
- **Diagnóstico:** `pipedrive/status` distingue contrato ausente de operação desautorizada. O plugin usa o cliente `pipedrive-api-client/1.0.0`; a autorização deve estar ativa no site correto. A atualização não a concede.
- **Reconciliar uma escrita:** consulte `operacao` para retenção e recuperação, e `fluxos` para os passos do processo. Antes de repetir, confira o diário e o estado no fornecedor.

## Índice e leitura

| ID | Arquivo | Assunto |
|---|---|---|
| index | README.md | Visão geral |
| especificacao | SPECIFICATION.md | Listas e comportamento |
| configuracao | CONFIGURATION.md | Pré-requisitos e autorização |
| uso | USAGE.md | Fluxo e exemplos |
| contratos | CONTRACTS.md | Contratos Core, retenção e erros |
| agentes | AGENT-GUIDE.md | Orientação de operação |
| operacao | OPERATIONS.md | Armazenamento e recuperação |
| release | CHANGELOG.md | Escopo 0.7.0 |
| painel | PANEL.md | Configurar pelo WordPress, revisar e confirmar |
| fluxos | WORKFLOWS.md | Regras, cadência, operações e auditoria atual |
| regras-iniciais | regras-iniciais.json | Defaults sem configuração comercial presumida |
| schemas | schemas.json | Schemas gerados do runtime |

Descobrir `pipedrive/documentacao-ler`. Chamar `{}` para este índice, ou `{"documento":"uso"}`. Na próxima chamada, copie `data.proximo_offset` para `offset` e `data.sha256` para `sha256_esperado`. Encerrar quando `fim=true`. Páginas de 256 a 24.000 bytes, padrão 16.000, com corte UTF-8. O SHA-256 representa o documento completo. Não juntar revisões diferentes. IDs são fechados; caminhos arbitrários e symlinks externos são recusados. Todos os acessos exigem manage_options.

A documentação é estática: sua leitura não consulta o Core nem fornecedor, não verifica token e não cria tabelas, cron ou configurações. Painel: Ferramentas → Fator3 MCP Pipedrive.

## Cobertura de leitura

`pipedrive/relatorio` agrega o período solicitado. Consulte `uso` para distinguir totais completos, subtotais observados, visibilidade e limite do plano. A auditoria local de escritas é diferente de `pipedrive/auditoria`, que lê dados da conta e depende do Core.
