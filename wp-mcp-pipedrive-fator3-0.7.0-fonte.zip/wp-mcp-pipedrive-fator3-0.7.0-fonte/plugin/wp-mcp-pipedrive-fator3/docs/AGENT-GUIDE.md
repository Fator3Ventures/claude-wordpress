# Guia para agentes — 0.7.0

Para orientar um administrador, comece por `pipedrive/documentacao-ler {"documento":"painel"}`. Validação local não comprova conexão. Releia depois de aplicar e nunca use a tela de regras para aplicar uma prévia comercial.


1. Descobrir pipedrive/* e ler schemas; obter index e contratos via documentacao-ler. Não tratar documentação como autorização para efeitos.
2. Consultar status sem chamada externa. Se core_indisponivel, pedir ao mantenedor Core o contrato confirmado de Pedidos core 294; não tentar obter o token ou chamar API diretamente.
3. Conferir site-porta, conta, usuário, autorização, revisão e orçamento. Usar API só nos registros/ações autorizados. Saldo null é desconhecido.
4. Ler estado e campos permitidos. O ID 152 do exemplo de Perfil (ICP) não identifica sozinho a chave personalizada do lead; usar o catálogo real.
5. Preparar prévia, conferir corpo, efeito e reversibilidade. Para estrutura, obter a ordem do dono antes de copiar a confirmação. A data e o resumo devem coincidir literalmente.
6. Aplicar uma vez; guardar previa_id, HTTP e status. Repetição usa o mesmo previa_id. Se resultado_incerto, reconciliar por GET e auditoria antes de qualquer nova prévia equivalente.
7. Confirmar o resultado com leitura e limpar os registros sintéticos autorizados no mesmo trabalho. Não enviar e-mails, avisos, campanhas ou assinaturas como teste.
8. Auditoria não guarda valores pessoais; conteúdo da resposta é administrativo. Não copiar dados reais/segredos em relatórios ou exemplos.

O Core 1.71.0 fornece o contrato e suas guardas. A integração comercial exige autorização por site e homologação real. Testes com transporte interceptado demonstram integração do cliente original; não representam aceite da API real. Este pacote não habilita automaticamente a option de operação.

Não alterar o Core, MCP ou documentos centrais para fazer esta versão parecer pronta. Relatar o contrato ausente e o pedido específico ao responsável. Não usar acesso genérico a arquivos como substituto da documentação do plugin.


## Retenção — Pedido MCP Pipedrive 2

Comece com retencao-ler e status.data.retencao. O padrão é diario_dias=0 (sem prazo); não proponha prazo menor por economia de armazenamento. Se houver ordem de prazo finito, explique o corte por data original e envie confirmar_expurgo=true com a revisão atual. Não edite options por SQL nem execute limpeza para provar uma leitura. Após erro de persistência, releia. A configuração não exige acesso comercial ao Core e não concede esse acesso.

Na atualização da 0.6.0, preserve registros, salts, prazos e escolhas já salvas. Se a troca falhar, suspenda apenas as operações afetadas, registre o estado e confirme no fornecedor qualquer efeito incerto. A correção parte desse estado em nova versão.

## Auditoria, contagem e repetição segura

- Para decidir se falta uma próxima atividade, chame `pipedrive/auditoria`. Separe `itens` (regra constatada) de `itens_nao_avaliados` (faltou evidência). Só trate o resultado inteiro como avaliado quando `coleta_completa` e `avaliacao_completa` forem verdadeiros.
- Em `pipedrive/contar-por-campo`, compare grupos apenas depois de verificar `motivos` e `coleta_completa`. Um registro com opção ilegível pode entrar no total observado sem aparecer em grupo algum.
- Depois de um envio de WhatsApp já confirmado pelo canal, registre com a mesma chave e os mesmos valores em qualquer repetição. `idempotencia_conflitante` pede conferência da entrada; `reconciliacao_necessaria` pede conferência dos efeitos, preservando a chave. No diário, acompanhe as etapas confirmadas pelo plugin e verifique o estado no CRM antes de decidir uma nova intenção.

## Relatório agregado

Para pedido 3, leia USAGE.md e schema relatorio. Informe datas e limite do plano conhecido; valide campos. Consuma completo, coleta_completa, pendencias, fontes e custo antes de usar números. Nunca declare homologação com Pipedrive real a partir de fixture. IDs/códigos de motivos exigem dicionário comercial correspondente para conferência da tela.
