<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** WordPress admin only. Each section loads its own data; navigation never writes. */
final class Admin {
    private const TABS=['visao'=>'Visão geral','regras'=>'Regras de operação','diario'=>'Diário e retenção','ajuda'=>'Ajuda'];
    private const HELP=[
        'Começar a configurar'=>['painel'=>'Guia do painel','configuracao'=>'Configurar a integração','regras-iniciais'=>'Regras iniciais'],
        'Operar e investigar'=>['fluxos'=>'Cadência e operações','uso'=>'Exemplos de uso','operacao'=>'Operar e recuperar','release'=>'Notas da versão'],
        'Consultar a referência'=>['agentes'=>'Guia para agentes','contratos'=>'Contratos e permissões','schemas'=>'Schemas JSON','especificacao'=>'Especificação','index'=>'Índice técnico']
    ];
    public static function menu(): void {
        $hook=add_management_page('Fator3 MCP Pipedrive','Fator3 MCP Pipedrive','manage_options',SLUG,[self::class,'page']);
        if($hook)add_action('admin_enqueue_scripts',static function($screen)use($hook){if($screen===$hook)wp_enqueue_style('f3-pipedrive-admin',plugins_url('assets/admin.css',ROOT.'/'.SLUG.'.php'),[],VERSION);});
    }
    public static function url(string $tab,array $extra=[]): string {return add_query_arg(['page'=>SLUG,'aba'=>$tab]+$extra,admin_url('tools.php'));}
    public static function text(array $source,string $key,string $default=''): string {return isset($source[$key])&&is_string($source[$key])?wp_unslash($source[$key]):$default;}
    public static function notice(string $message,bool $ok=false): void {
        echo '<div class="notice inline '.($ok?'notice-success':'notice-error').'" role="'.($ok?'status':'alert').'"><p>'.esc_html($message).'</p></div>';
    }
    public static function page(): void {
        if(!current_user_can('manage_options'))wp_die('Acesso administrativo necessário.');
        $tab=self::text($_GET,'aba');$action=($_SERVER['REQUEST_METHOD']??'GET')==='POST'?self::text($_POST,'f3_pipedrive_action'):'';
        if(!isset(self::TABS[$tab]))$tab=isset($_GET['documento'])?'ajuda':(isset($_GET['antes_id'])?'diario':'visao');
        if($action==='retention')$tab='diario';elseif(str_starts_with($action,'rules_'))$tab='regras';
        echo '<div class="wrap f3pd"><header class="f3pd-head"><p class="f3pd-kicker">Integrações · CRM</p><h1>Fator3 MCP Pipedrive</h1><p>Configure a cadência comercial e acompanhe as operações desta instalação. <span class="f3pd-version">Versão '.esc_html(VERSION).'</span></p></header><nav class="nav-tab-wrapper f3pd-tabs" aria-label="Seções do Pipedrive">';
        foreach(self::TABS as $id=>$title)echo '<a class="nav-tab'.($tab===$id?' nav-tab-active':'').'" '.($tab===$id?'aria-current="page" ':'').'href="'.esc_url(self::url($id)).'">'.esc_html($title).'</a>';
        echo '</nav><main class="f3pd-body">';
        match($tab){'regras'=>AdminRules::render($action),'diario'=>self::journal($action),'ajuda'=>self::help(),default=>self::overview()};
        echo '</main></div>';
    }
    private static function overview(): void {
        $status=Api::dispatch('status');$cfg=Api::dispatch('configuracao-ler');$s=is_array($status['data'])?$status['data']:[];
        $ready=$status['success'];$rules=$cfg['success']?$cfg['data']['regras']:null;
        $title=$ready?'Operação autorizada':match($status['code']){'core_indisponivel'=>'Cliente do Site Core indisponível','operacao_nao_autorizada'=>'Autorização pendente',default=>'Verificação necessária'};
        echo '<section class="f3pd-panel"><div class="f3pd-overline">Conexão com a conta</div><h2>'.esc_html($title).'</h2><p>'.esc_html($ready?'O Site Core disponibilizou o cliente Pipedrive para esta instalação. Esta leitura é local.':($status['code']==='core_indisponivel'?'Esta instalação ainda não recebeu o cliente Pipedrive do Site Core.':$status['message'])).'</p>';
        if(!$ready)echo '<p>Confira a instalação do Site Core, a credencial da conta e a autorização do consumidor <code>operacao</code> no site que acessa o CRM.</p>';
        echo '<dl class="f3pd-facts">';
        $facts=['Conta'=>$ready?($s['conta']['dominio']??'Não informada'):'Indisponível','Cadência'=>$rules===null?'Regras indisponíveis':($rules['habilitada']?'Habilitada':'Desligada'),'Orçamento de operação'=>$ready?number_format_i18n($s['orcamento']['consumido']).' de '.number_format_i18n($s['orcamento']['teto']).' unidades':'Indisponível'];
        foreach($facts as $k=>$v)echo '<div><dt>'.esc_html($k).'</dt><dd>'.esc_html((string)$v).'</dd></div>';
        echo '</dl><details><summary>Detalhes do contrato</summary><p>Contrato exigido: <code>'.esc_html(CONTRACT).'</code>. Registro do cliente: '.esc_html((string)($s['registro_cliente']??'indisponível')).'. A autorização e o token são mantidos no Fator3 Site Core.</p></details></section>';
        if(!$cfg['success'])self::notice($cfg['message']);
        echo '<section class="f3pd-panel"><h2>Próximos passos</h2><ul class="f3pd-links">';
        foreach([['regras','Configurar regras','Revise os horários, motivos e textos antes de simular a cadência.'],['diario','Consultar o diário','Confira tentativas de escrita e o prazo de conservação do histórico.'],['ajuda','Documentação instalada','Leia o guia do painel e os exemplos da versão instalada.']] as [$tab,$label,$desc])echo '<li><a href="'.esc_url(self::url($tab)).'">'.esc_html($label).'</a><span>'.esc_html($desc).'</span></li>';
        echo '</ul></section>';
    }
    private static function journal(string $action): void {
        if($action==='retention'){
            check_admin_referer('f3_pipedrive_retention');$days=self::text($_POST,'diario_dias');
            $notice=Api::dispatch('retencao-configurar',['diario_dias'=>ctype_digit($days)&&strlen($days)<=5?(int)$days:$days,'revisao_esperada'=>self::text($_POST,'revisao_esperada'),'confirmar_expurgo'=>self::text($_POST,'confirmar_expurgo')==='1']);
            self::notice($notice['message'],$notice['success']);
        }
        $policy=Api::dispatch('retencao-ler');
        echo '<section class="f3pd-panel"><h2>Retenção do diário</h2><p>Escolha por quanto tempo manter o registro das tentativas. A mudança vale para as próximas limpezas.</p>';
        if(!$policy['success'])self::notice($policy['message']);else{
            $p=$policy['data'];echo '<form method="post" action="'.esc_url(self::url('diario')).'">';wp_nonce_field('f3_pipedrive_retention');
            echo '<input type="hidden" name="f3_pipedrive_action" value="retention"><input type="hidden" name="revisao_esperada" value="'.esc_attr($p['revisao']).'"><label class="f3pd-label" for="f3pd-days">Dias de conservação</label><input id="f3pd-days" type="number" min="0" max="36500" step="1" required name="diario_dias" aria-describedby="f3pd-days-help" value="'.esc_attr((string)$p['diario_dias']).'"><p id="f3pd-days-help" class="description">0 = sem prazo. Para limitar o histórico, use de 1 a 36.500 dias. Prazo atual: '.($p['diario_sem_prazo']?'sem prazo':esc_html((string)$p['diario_dias']).' dias').'.</p>';
            echo '<p><label><input type="checkbox" name="confirmar_expurgo" value="1"> Para prazo finito, autorizo excluir entradas vencidas nas próximas limpezas.</label></p><p class="description">Salvar não exclui linhas. Aumentar o prazo depois não recupera entradas excluídas. Prévias duram 15 minutos; recibos comuns duram 180 dias; recibos de WhatsApp não expiram automaticamente.</p>';submit_button('Salvar retenção','secondary');echo '</form>';
        }echo '</section><section class="f3pd-panel"><h2>Registro de escritas</h2><p>Horários em UTC. Use a prévia para identificar uma tentativa antes de decidir se deve retomar a operação.</p>';
        $before=self::text($_GET,'antes_id');$i=['limite'=>20];if($before!=='')$i['antes_id']=ctype_digit($before)?(int)$before:0;
        $r=Api::dispatch('registro-ler',$i);if(!$r['success'])self::notice($r['message']);elseif(!$r['data']['itens'])echo '<p class="f3pd-empty">Nenhuma tentativa de escrita nesta página do diário.</p>';else{
            echo '<div class="f3pd-table" role="region" aria-label="Tentativas de escrita" tabindex="0"><table class="widefat striped"><thead><tr><th>UTC</th><th>Método e caminho</th><th>Classe</th><th>Estado</th><th>Prévia</th><th>Chaves alteradas</th><th>Saldo</th></tr></thead><tbody>';
            foreach($r['data']['itens'] as $item){echo '<tr>';foreach([$item['instante_utc'],($item['metodo']??'').' '.($item['caminho']??'—'),$item['classe']??'—',$item['status']??'—',$item['previa_id']??'—',implode(', ',$item['chaves_alteradas']??[]),$item['saldo_depois']['restante']??'—'] as $value)echo '<td>'.esc_html((string)$value).'</td>';echo '</tr>';}
            echo '</tbody></table></div>';if($r['data']['proximo_antes_id']!==null)echo '<p><a href="'.esc_url(self::url('diario',['antes_id'=>$r['data']['proximo_antes_id']])).'">Registros anteriores</a></p>';
        }echo '</section>';
    }
    private static function help(): void {
        $id=self::text($_GET,'documento','painel');$offset=self::text($_GET,'offset','0');$hash=self::text($_GET,'revisao');
        $labels=array_merge(...array_values(self::HELP));
        echo '<section class="f3pd-panel"><h2>Documentação instalada</h2><p>Escolha um assunto. A consulta é local e funciona mesmo sem autorização do CRM.</p><p><a href="#f3pd-help-current">Ir ao documento selecionado</a></p><nav class="f3pd-help-nav" aria-label="Documentos">';
        foreach(self::HELP as $title=>$group){
            echo '<div><h3>'.esc_html($title).'</h3><ul>';
            foreach($group as $key=>$label)echo '<li><a '.($key===$id?'aria-current="page" ':'').'href="'.esc_url(self::url('ajuda',['documento'=>$key])).'">'.esc_html($label).'</a></li>';
            echo '</ul></div>';
        }
        echo '</nav></section><section class="f3pd-panel" id="f3pd-help-current" tabindex="-1"><h2>'.esc_html($labels[$id]??'Documento').'</h2>';
        $guide=str_ends_with(Documentation::DOCUMENTS[$id]??'', '.md');
        $args=['documento'=>$id,'offset'=>ctype_digit($offset)?(int)$offset:-1,'limite_bytes'=>$guide?24000:16000];if($hash!=='')$args['sha256_esperado']=$hash;
        $r=Api::dispatch('documentacao-ler',$args);if(!$r['success']){
            self::notice($r['message']);
            if($offset!=='0' && isset($labels[$id]))echo '<a href="'.esc_url(self::url('ajuda',['documento'=>$id])).'">Voltar ao início do documento</a>';
        }else{
            $d=$r['data'];echo '<p class="description">Versão '.esc_html($d['version']).' · '.esc_html(number_format_i18n($d['total_bytes'])).' bytes no documento.</p>';
            // Render whole guides only: offsets are byte positions and can split tables or code fences.
            if($guide && $d['offset']===0 && $d['fim']){
                echo AdminDocument::render($d['conteudo']);
            }else{
                if($d['proximo_offset']!==null || $d['offset']>0)echo '<p class="description">Trecho do arquivo em texto original. Use os links após a leitura para navegar entre as partes.</p>';
                echo '<pre class="f3pd-document f3pd-source" tabindex="0">'.esc_html($d['conteudo']).'</pre>';
            }
            if($d['proximo_offset']!==null)echo '<a class="button" href="'.esc_url(self::url('ajuda',['documento'=>$id,'offset'=>$d['proximo_offset'],'revisao'=>$d['sha256']])).'">Ler próxima parte</a>';
            if($d['offset']>0)echo ' <a href="'.esc_url(self::url('ajuda',['documento'=>$id])).'">Voltar ao início do documento</a>';
        }echo '</section>';
    }
}
