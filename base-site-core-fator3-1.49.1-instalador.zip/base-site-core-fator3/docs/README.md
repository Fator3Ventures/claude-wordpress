# Versão atual: 1.49.1

Consulte [RELEASE-1.49.1.md](RELEASE-1.49.1.md) e [AGENTES-1.49.1.md](AGENTES-1.49.1.md). Base direta: [RELEASE-1.49.0.md](RELEASE-1.49.0.md).
