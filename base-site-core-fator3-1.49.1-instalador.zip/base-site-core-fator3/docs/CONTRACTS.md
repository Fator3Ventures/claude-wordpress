> Atualização 1.49.1, contrato administrativo 8.14.1: leia [RELEASE-1.49.1.md](RELEASE-1.49.1.md) e [AGENTES-1.49.1.md](AGENTES-1.49.1.md). Pedido 291 (nomes/fontes e Campanha no Pipedrive), schemas de contato/consentimento e falhas de consulta/agendamento da fila. O conteúdo anterior abaixo é histórico.

> Atualização 1.49.0, contrato administrativo 8.14.0: consulte RELEASE-1.49.0.md e AGENTES-1.49.0.md para as melhorias M1–M11 (tradução antes de init, motivo das recusas nativas, rotas públicas, prioridade e leitura da fila de conversões, catálogo LinkedIn sem conta, custo do contexto de medição, estado LinkedIn sem resposta do SDK, link do relatório Search Console). As seções de versões anteriores abaixo são históricas.

> Atualização 1.48.0, contrato administrativo 8.13.0: consulte RELEASE-1.48.0.md e AGENTES-1.48.0.md para os pedidos 288–290. As seções de versões anteriores abaixo são históricas.

> Versão vigente: Core **1.43.0**, contrato **8.8.0**. Leia [RELEASE-1.43.0.md](RELEASE-1.43.0.md) e [AGENTES-1.43.0.md](AGENTES-1.43.0.md). Conteúdo de versões anteriores abaixo é histórico.

# Atualização 1.40.0

Pedidos 236/237: transporte por destino, snapshot imutável e e-mail automático ao novo lead após novo lead. Consulte [RELEASE-1.40.0.md](RELEASE-1.40.0.md). Contrato administrativo 8.5.0; conversões SDK 1.0 preservado e 1.1 negociado.

> Versão atual 1.39.0, contrato administrativo 8.4.0. Consulte [RELEASE-1.39.0.md](RELEASE-1.39.0.md) e [AGENTES-1.39.0.md](AGENTES-1.39.0.md) para alterações 230–235 e bloqueios de aceite. Seções anteriores permanecem referência histórica.

> Vigente na 1.38.0: RELEASE-1.38.0.md, PIPEDRIVE-1.37.md e AGENTES-1.38.0.md. SDKs de medição/conversões preservados.

# Contratos — Core 1.38.0

Contrato de configuração 8.3.0; perfil 3.5. Referências executáveis: `dados/configuracao-schema.json`, `dados/abilities-*.json` e `dados/contrato.json`. Provider `base-site-core-fator3` preservado.

A retirada de `f3base/config-procedencia-reparar` é deliberada; não há alias de reparo antigo. `config-complementacoes-ler` permanece leitura histórica. Novas abilities LinkedIn e seus argumentos estão no catálogo gerado; não inferir schema pelo rótulo. Segredos são mascarados e inseridos na tela.

Configuração usa revisão opaca, simulação por padrão e mescla tipada quando explicitada. `persisted` confirma gravação; `audit` confirma procedência; `effect` e `verification` descrevem efeitos e evidências distintos. Complementação preserva autoria/canal/data, registra subchaves à parte e muda a revisão do valor quando necessário. Releia após conflito.

Companheiros são descobertos por contrato e capacidades: MCP `server-integration/1.0.0`, política 1, identidade do provider e registro de extensão; Google `search-console-reader/1.0.0`, leitura página/dia, `query` e `effective_status`. Número da versão é informativo. Ausência, resposta malformada ou exceção degradam a integração correspondente sem impedir instalação ou bootstrap.

Leitura de jornada exige permissão de leads ou administração. Mutações administrativas exigem `manage_options`; o conector soma sua política. Recuperação preserva leitura documental e bloqueia efeitos comerciais. Não transformar retorno incerto em autorização para repetir criação externa.

## Códigos de recuperação

A guarda usa `wp-content/f3-core-state/`: `site-N.php` é a sentinela, `site-N-state.php` registra a barreira, `site-N-workers.php` coordena entradas e `site-N-task-<tarefa>.php` reserva cada tarefa. A resposta deve ser interpretada pelo código, estado e precondição atuais. Números de linha são apenas referência histórica da especificação.

| Grupo | Código | Linha | Significado | Ação |
| --- | --- | --- | --- | --- |
| Estado da guarda | `core_operacional` | 20 | Sentinela válida, sem pausa e sem falha de trava | Nenhuma |
| Estado da guarda | `core_pausado` | 20 | Sentinela com `pausado: true`; tarefas e mutações paradas | Reconciliar e chamar `retomar` |
| Estado da guarda | `trava_inacessivel` | 20, 78–79 | `site-N-workers.php` é link ou não abre para escrita | Corrigir dono e permissão; se persistir, `recriar` |
| Estado da guarda | `trava_ocupada` | 20, 80 | Outra operação segura a trava exclusiva | Aguardar e repetir |
| Estado da guarda | `trava_falhou` | 20, 80 | `flock` falhou sem indicar bloqueio | Conferir o sistema de arquivos; depois `recriar` |
| Estado da guarda | `sentinela_ausente` | 16 | `site-N.php` não existe | `recriar` com `precondicao_esperada` e as confirmações |
| Estado da guarda | `sentinela_ilegivel` | 16, 18 | Não é arquivo regular ou a leitura falhou | Corrigir tipo e permissão; depois `recriar` |
| Estado da guarda | `sentinela_invalida` | 18 | Conteúdo sem o cabeçalho ou sem `geracao` e `pausado` | `recriar` |
| Estado da guarda | `sentinela_link_recusado` | 16 | `site-N.php` é link simbólico | Remover o link; depois `recriar` |
| Estado da guarda | `diretorio_sentinela_link_recusado` | 15, 28 | A pasta é link simbólico | Trocar por pasta real |
| Estado da guarda | `diretorio_sentinela_indisponivel` | 15, 29, 43, 67 | Pasta ausente, ilegível ou impossível de criar | Criar a pasta ou corrigir a permissão |
| Estado da guarda | `indice_protetor_link_recusado` | 15, 30, 43 | `index.php` da pasta é link simbólico | Remover o link; a provisão recria o índice |
| Proteção em disco | `indice_protetor_confirmado` | 27 | `index.php` com o conteúdo esperado | Nenhuma |
| Proteção em disco | `indice_protetor_indisponivel` | 31 | `index.php` ausente ou ilegível; não pausa | Corrigir a permissão |
| Proteção em disco | `indice_protetor_divergente` | 32 | Conteúdo diferente; não é sobrescrito e não pausa | Repor o conteúdo esperado |
| Entrada da requisição | `nao_tentada` | 9 | Nenhuma tarefa protegida tentou entrar | Nenhuma |
| Entrada da requisição | `entrada_confirmada` | atual | Entrada aceita com trava compartilhada | Nenhuma |
| Respostas da operação | `core_em_recuperacao` | 85 | Chamada protegida recusada pela guarda | Ler `recuperacao` na resposta |
| Respostas da operação | `sem_permissao` | 87 | Sem `manage_options` e fora do WP-CLI | Usar conta administradora |
| Respostas da operação | `geracao_invalida` | 88 | `geracao_esperada` ausente ou não inteira | Ler o estado e enviar `geracao` |
| Respostas da operação | `geracao_divergente` | 93 | Geração diferente da enviada | Reler e repetir |
| Respostas da operação | `acao_invalida` | 94 | `acao` fora de `preparar`, `retomar`, `recriar` | Corrigir a chamada |
| Respostas da operação | `reconciliacao_externa_nao_confirmada` | 95 | `retomar` sem `reconciliacao_confirmada` | Reconciliar e confirmar |
| Respostas da operação | `barreira_ocupada` | 46, 91 | Outra operação de recuperação em curso | Aguardar e repetir |
| Respostas da operação | `barreira_nao_persistida` | 96 | `preparar` não gravou a pausa | Conferir escrita na pasta |
| Respostas da operação | `aguardando_drenagem` | 40, 49, 97 | Há trabalho em voo | Repetir a mesma chamada até `core_drenado` |
| Respostas da operação | `core_drenado` | 104 | Pausado, sem trabalho em voo | Restaurar preservando a pasta |
| Respostas da operação | `core_retomado` | 104 | Geração incrementada, filas invalidadas | Reconciliar os itens suspensos e incertos |
| Respostas da operação | `ja_retomado` | 100 | O Core já estava sem pausa | Nenhuma |
| Respostas da operação | `trava_link_recusado` | 44, 89 | Arquivo de estado ou de workers é link | Remover o link |
| Respostas da operação | `sentinela_gravacao_falhou` | 51, 58, 104 | A sentinela não foi gravada | Conferir escrita e espaço em disco |
| Respostas da operação | `sentinela_existente` | 40 | `recriar` recusado: a sentinela é válida | Usar `preparar` ou `retomar` |
| Respostas da operação | `confirmacao_recriacao_necessaria` | 41 | Falta `reconciliacao_confirmada` ou `copia_outro_host` | Enviar os dois campos |
| Respostas da operação | `precondicao_divergente` | 42, 48 | A sentinela mudou desde a leitura | Reler `precondicao` e repetir |
| Respostas da operação | `identidade_nao_persistida` | 55 | Identidade nova do Pipedrive não gravou | Repetir `recriar` |
| Respostas da operação | `sentinela_recriada` | 58 | Nova geração gravada; filas suspensas | Reconciliar; com `manter_pausado`, `retomar` depois |
| Invalidação de filas | `inventario_recuperacao_falhou` | 115 | Contagem prévia de uma fila falhou | Corrigir o banco e repetir a ação |
| Invalidação de filas | `fila_nao_suspensa` | 124 | Fila da Meta ou do Pipedrive não foi suspensa | Idem |
| Invalidação de filas | `avisos_nao_suspensos` | 128 | Avisos de contato não foram marcados | Idem |
| Invalidação de filas | `intencoes_nao_suspensas` | 129 | Marca das entregas ao Pipedrive não gravou | Idem |
| Invalidação de filas | `eliminacoes_nao_suspensas` | 131 | Eliminações remotas não foram suspensas | Idem |
| Invalidação de filas | `alertas_nao_suspensos` | 133, 134 | Alertas de entrega não foram marcados | Idem |
| Invalidação de filas | `alerta_conta_nao_suspenso` | 137 | Alerta de conta não foi marcado | Idem |
| Invalidação de filas | `cursor_nao_invalidado` | 138 | Cursor do Search Console não foi invalidado | Idem |
| Invalidação de filas | `reservas_nao_invalidadas` | 139 | Reservas do executor não foram zeradas | Idem |
| Invalidação de filas | `intencoes_nao_invalidadas` | 140 | Intenções pendentes não passaram a `suspensa` | Idem |
| Reserva de tarefa | `reserva_indisponivel` | 142, 145 | Arquivo de tarefa como link simbólico | Conferir o arquivo de tarefa |
| Reserva de tarefa | `trava_arquivo_inacessivel` | 145 | Arquivo de tarefa não abre para escrita | Corrigir a permissão |
| Reserva de tarefa | `reserva_ocupada` | 145 | Outra execução da mesma tarefa em curso | Aguardar |
| Reserva de tarefa | `trava_arquivo_falhou` | 145 | `flock` do arquivo de tarefa falhou | Conferir o sistema de arquivos |
| Marcas nos dados | `restauracao_requer_reconciliacao` | 124–137 | Item suspenso ou incerto por retomada ou recriação | Reconciliar no módulo dono antes de reenviar |
| Marcas nos dados | `copia_requer_verificacao` | 54 | Site copiado de outro host | Verificar a integração |
| Entrada da requisição | `protecao_degradada` | atual | Módulos de atendimento subiram, mas tarefas e gravações protegidas estão bloqueadas | Corrigir dono, permissão e arquivo de coordenação |
| Retirada de URL | `caminho_nao_retirado` | atual | Foi solicitada restauração de um caminho sem retirada prévia; nenhuma escrita ocorreu | Confira a operação desejada e o histórico do caminho |


## Interfaces adicionais

Contexto e catálogo: MEDICAO-SDK-1.33.md, contrato `site-measurement-context/1.0.0`. SDK GSC permanece separado. Não existem versões mínimas numéricas nem recusa de sufixo do acompanhante; conferir contrato e capacidades da função pretendida.

Ponte `f3base/config-ler` / `config-escrever`: `scope:installer_json`, `site_config_applied:false`. O adaptador `F3Base_Implantador_Adaptador` concentra localização, leitura, validação e gravação; ainda depende do validador privado do implantador. Não é aplicação de configuração Core ou tema.

LinkedIn externo: interface `linkedin-lead-reader/1.0.0` aguardando especificação executável e homologação; somente cliente interno disponível. Cinco donos e limites: IMPACTO-SOCIAIS-1.33.md.


## Complementos vigentes

Configuração LinkedIn por integração e troca dedicada: LINKEDIN-LEAD-SYNC.md. Correções de operação e retenção: CORRECOES-OPERACIONAIS-1.34.md. Matriz de bancada atual: MCP 0.23.0 / Google 0.10.0 / LinkedIn 0.2.0 / Meta 0.2.0. Leia RELEASE-1.35.0.md antes de atualizar ou reverter.


## Alterações 1.35.0

Leia CONVERSOES-CONTEUDO-1.35.md. Instalação nova ou base 1.34.0; mínimos WP 7.1.2/PHP 8.3.6 64 bits. Contrato administrativo 8.3.0; SDK 1.0.0 fechado sem material. Reserva editorial adaptativa, equivalência Slack por blocos exibidos, rótulos Meta em texto CRM e tela de conexões corrigida. Migração de reservas e suspensão de Lead legado de material; sem reenvio ou correção retroativa.
