# Fator3 Site Core 1.49.1

Instalação nova ou atualização de 1.49.0; salto de 1.48.0 também validado. Contrato administrativo 8.14.1. Leia docs/DOCUMENTACAO.md, docs/RELEASE-1.49.1.md e docs/AGENTES-1.49.1.md. Documentação instalada legível por f3base/documentacao-ler.
