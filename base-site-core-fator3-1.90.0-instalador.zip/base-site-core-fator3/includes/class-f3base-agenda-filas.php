<?php
/** Alterações pontuais no cron nativo para os seis ganchos das filas do Site Core. */
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3Base_Agenda_Filas {
    public static function iniciar(): void {
        add_filter('pre_schedule_event', [self::class, 'agendar'], PHP_INT_MAX, 3);
        add_filter('pre_unschedule_event', [self::class, 'remover'], PHP_INT_MAX, 5);
    }

    public static function agendar($pre, $evento, bool $com_erro) {
        if ($pre !== null || !isset(F3Base_Fila::RECORRENCIAS[$evento->hook])) { return $pre; }
        $evento = apply_filters('schedule_event', $evento);
        if (!$evento) { return $com_erro ? new WP_Error('schedule_event_false', 'Evento recusado.') : false; }
        return self::alterar($evento->hook, (int)$evento->timestamp, $evento->args, $evento, $com_erro);
    }

    public static function remover($pre, $hora, string $hook, array $args, bool $com_erro) {
        if ($pre !== null || !isset(F3Base_Fila::RECORRENCIAS[$hook])) { return $pre; }
        return self::alterar($hook, (int)$hora, $args, null, $com_erro);
    }

    private static function invalidar_cache(): void {
        wp_cache_delete('cron', 'options');
        wp_cache_delete('alloptions', 'options');
        wp_cache_delete('notoptions', 'options');
    }

    private static function alterar(string $hook, int $hora, array $args, ?object $evento, bool $com_erro) {
        global $wpdb;
        $chave = md5(serialize($args));
        $operacao = $evento ? 'agendar' : 'remover';
        for ($i = 0; $i < 16; ++$i) {
            $raw = $wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s', $wpdb->options, 'cron'));
            if ($wpdb->last_error) { break; }
            $cron = $raw === null ? [] : maybe_unserialize($raw);
            if (!is_array($cron)) { break; }
            $antes = $cron[$hora][$hook][$chave] ?? null;
            $depois = $evento ? ['schedule'=>$evento->schedule, 'args'=>$args] : null;
            if ($evento && $evento->schedule) { $depois['interval'] = (int)$evento->interval; }
            if ($antes === $depois) {
                self::invalidar_cache();
                do_action('f3base_fila_agenda_medida', $hook, $hora, $operacao, 'ja_persistido');
                return true;
            }
            if ($evento && !$evento->schedule) {
                $agora = time();
                $min = $hora < $agora + 600 ? 0 : $hora - 600;
                $max = max($agora, $hora) + 600;
                foreach ($cron as $t => $hooks) {
                    if (is_numeric($t) && $t >= $min && $t <= $max && isset($hooks[$hook][$chave])) {
                        return $com_erro ? new WP_Error('duplicate_event', 'Evento único já presente na janela.') : false;
                    }
                }
            }
            unset($cron['version']);
            if ($evento) {
                $cron[$hora][$hook][$chave] = $depois;
                uksort($cron, 'strnatcasecmp');
            } else {
                unset($cron[$hora][$hook][$chave]);
                if (!$cron[$hora][$hook]) { unset($cron[$hora][$hook]); }
                if (!$cron[$hora]) { unset($cron[$hora]); }
            }
            $cron['version'] = 2;
            if ($raw === null) {
                $salvo = (int)add_option('cron', $cron, '', true);
            } else {
                $salvo = $wpdb->query($wpdb->prepare(
                    'UPDATE %i SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s',
                    $wpdb->options, maybe_serialize($cron), 'cron', $raw
                ));
            }
            self::invalidar_cache();
            if ($salvo === false) { break; }
            if ($salvo === 1) {
                if ($raw !== null) {
                    $anterior = maybe_unserialize($raw);
                    do_action('update_option_cron', $anterior, $cron, 'cron');
                    do_action('updated_option', 'cron', $anterior, $cron);
                }
                do_action('f3base_fila_agenda_medida', $hook, $hora, $operacao, 'gravado');
                return true;
            }
            // Outra escrita ganhou entre leitura e UPDATE. Refazer só o delta deste evento.
            usleep(random_int(500, 2500));
        }
        do_action('f3base_fila_agenda_medida', $hook, $hora, $operacao, 'falha_persistencia');
        return $com_erro ? new WP_Error('could_not_set', 'A alteração da agenda não foi confirmada pelo banco.') : false;
    }
}
