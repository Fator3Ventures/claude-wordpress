from pathlib import Path
import os,subprocess,shutil,zipfile,json,socket,time,urllib.request,urllib.error,base64,hashlib,signal
root=Path(__file__).resolve().parents[1];content=root/'lab/content-mcp';candidate=Path(os.environ.get('F3BASE_CANDIDATE',str(root/'build/candidate.zip')))
if content.exists():shutil.rmtree(content)
content.mkdir();(content/'plugins').mkdir()
shutil.copytree(root/'lab/wordpress/wp-content/themes',content/'themes');shutil.copytree(root/'lab/wordpress/wp-content/mu-plugins',content/'mu-plugins')
(content/'mu-plugins/http-auth.php').write_text("<?php add_filter('wp_is_application_passwords_available','__return_true');")
with zipfile.ZipFile(root.parent/'release/base-site-core-fator3-1.34.0-instalador.zip') as z:z.extractall(content/'plugins')
shutil.copytree(root.parent/'companions/wp-mcp-fator3-0.23.0-instalador/wp-mcp-fator3',content/'plugins/wp-mcp-fator3')
env=dict(os.environ,F3BASE_LAB_DB='core1350_mcp',F3BASE_LAB_CONTENT=str(content),PHP_CLI_SERVER_WORKERS='4',NO_PROXY='127.0.0.1,localhost',no_proxy='127.0.0.1,localhost')
def run(mode,*args):
 p=subprocess.run([str(root/'build/php'),str(root/'tests/cycle-1350.php'),mode,*map(str,args)],env=env,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(mode+' '+p.stderr+p.stdout[-1000:])
 return json.loads(p.stdout)
report={'install':run('install'),'seed':run('seed'),'before':run('snapshot')};auth=run('auth');headers={'Authorization':'Basic '+base64.b64encode((auth['user']+':'+auth['password']).encode()).decode(),'Content-Type':'application/json','Accept':'application/json, text/event-stream'}
server=subprocess.Popen([str(root/'build/php'),'-S','127.0.0.1:8134','-t',str(root/'lab/wordpress'),str(root/'tests/router.php')],env=env,stdout=open(root/'lab/mcp-http.log','w'),stderr=subprocess.STDOUT,start_new_session=True)
def rpc(method,params,ident=1):
 body={'jsonrpc':'2.0','method':method,'params':params}
 if ident is not None:body['id']=ident
 req=urllib.request.Request('http://127.0.0.1:8134/wp-json/mcp/wp-mcp-fator3',data=json.dumps(body).encode(),headers=headers)
 try:res=urllib.request.urlopen(req,timeout=55)
 except urllib.error.HTTPError as e:raise RuntimeError(str(e.code)+' '+e.read().decode()[:1000])
 raw=res.read().decode()
 if res.headers.get('Mcp-Session-Id'):headers['Mcp-Session-Id']=res.headers['Mcp-Session-Id']
 if not raw.strip():return {}
 if raw.lstrip().startswith('{'):return json.loads(raw)
 return next((json.loads(x[5:].strip()) for x in raw.splitlines() if x.startswith('data:') and json.loads(x[5:].strip()).get('id')==ident),{})
def ability(name,params):
 d=rpc('tools/call',{'name':'wp-mcp-ultimate-execute-ability','arguments':{'ability_name':name,'parameters':params}})
 t=d.get('result',{});v=t.get('structuredContent')
 if v is None:
  for x in t.get('content',[]):
   if x.get('type')=='text':
    try:v=json.loads(x['text']);break
    except ValueError:pass
 if v is None:raise RuntimeError(str(d)[:1000])
 return v
try:
 for _ in range(80):
  try:
   socket.create_connection(('127.0.0.1',8134),.2).close();break
  except OSError:time.sleep(.1)
 init=rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'Core1350 disposable QA','version':'1.35.0'}});assert 'result' in init,init;headers['MCP-Protocol-Version']=init['result']['protocolVersion'];rpc('notifications/initialized',{},None)
 report['upload']=ability('plugins/upload-base64',{'content_base64':base64.b64encode(candidate.read_bytes()).decode(),'expected_slug':'base-site-core-fator3','expected_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'overwrite':True})
 assert report['upload']['success'],report['upload'];report['migrate']=run('migrate');report['finalize']=run('finalize');report['status']=run('status');assert report['status']['structure_ready'] and report['status']['versao']=='1.35.0'
 report['after']=run('snapshot');assert report['before']==report['after']
 report['documents']=ability('f3base/documentacao-ler',{});assert report['documents']['success'],report['documents']
 report['conflict']=ability('f3base/tracking-encerrar-gtm',{'revisao':'obsolete','simular':False});assert report['conflict']['success'] is False and (report['conflict'].get('code') or report['conflict'].get('error_code'))=='revision_conflict' and report['conflict']['data']['data'] is None and report['conflict']['data']['conflict'] is True,report['conflict']
 report['diagnostic']=ability('f3base/tracking-diagnostico',{});assert report['diagnostic']['success'] and isinstance(report['diagnostic']['data']['vigente'],bool),report['diagnostic']
 report['checks']={'native_mcp_http':True,'upgrade_preserved':True,'readiness_new_request':True,'docs_authorized':True,'revision_conflict_null':True,'boolean_preserved':True}
finally:
 run('auth_clear',auth['uuid']);os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=10)
# Prove final installed tree only after all PHP processes stop.
with zipfile.ZipFile(candidate) as z:
 expected={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
 actual={str(f.relative_to(content/'plugins')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (content/'plugins/base-site-core-fator3').rglob('*') if f.is_file()}
 assert expected==actual,(set(expected)^set(actual));report['inventory']={'files':len(actual),'exact':True}
report['candidate_sha256']=hashlib.sha256(candidate.read_bytes()).hexdigest();(root/'evidence/mcp-cycle-1350.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('MCP HTTP 0.23.0 upgrade, contracts and inventory OK')
