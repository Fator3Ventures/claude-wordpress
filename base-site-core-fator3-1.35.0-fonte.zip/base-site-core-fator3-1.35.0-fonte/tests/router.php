<?php
$p=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);$f=$_SERVER['DOCUMENT_ROOT'].$p;if(is_file($f)){return false;}require $_SERVER['DOCUMENT_ROOT'].'/index.php';
