const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..'),checks=[];
class CustomEvent extends Event{constructor(n,o={}){super(n);this.detail=o.detail;}}
async function run(enabled,method,min){
 const doc=new EventTarget(),win=new EventTarget(),requests=[];doc.cookie='_fbp=fb.1.1792190000000.synthetic';doc.visibilityState='visible';
 const loc={pathname:'/ebook/',protocol:'https:',search:''};Object.assign(win,{f3baseMetaTransporteDados:{pixel:'123',material:enabled,modo:'ambos',endpoint:'/meta-eventos',token:'synthetic'},f3baseContexto:{pronto:()=>true,teste:()=>false,token:()=>Promise.resolve('synthetic')},f3baseConsentimento:{permiteCategoria:()=>true},location:loc});
 const ctx={window:win,document:doc,location:loc,CustomEvent,crypto:require('crypto').webcrypto,Uint8Array,Uint32Array,URLSearchParams,Map,AbortController,setTimeout:()=>1,clearTimeout:()=>{},fetch:async(url,opt)=>{requests.push(JSON.parse(opt.body));return {ok:true,json:async()=>({ok:true})};}};
 vm.runInNewContext(fs.readFileSync(root+'/work/plugin/base-site-core-fator3/assets/f3base-meta-transporte'+(min?'.min':'')+'.js','utf8'),ctx);
 doc.dispatchEvent(new CustomEvent('f3base-lead-confirmado',{detail:{metodo:method,meta_evento:method==='conteudo'?'MaterialDownload':'Lead',id:'b'.repeat(32),teste:false}}));
 await new Promise(setImmediate);return requests;
}
(async()=>{for(const min of [false,true]){let r=await run(true,'conteudo',min);assert(r.some(x=>x.nome==='MaterialDownload')&&!r.some(x=>x.nome==='Lead'));checks.push('material sem Lead '+min);r=await run(false,'conteudo',min);assert(!r.some(x=>x.nome==='MaterialDownload'||x.nome==='Lead'));checks.push('material off '+min);r=await run(false,'whatsapp_formulario',min);assert(r.some(x=>x.nome==='Lead'));checks.push('contato Lead '+min);}fs.writeFileSync(root+'/evidence/meta-routing.json',JSON.stringify({ambiente:'Node VM, capturas HTTP simuladas',checks},null,2));console.log(checks.length+' Meta JS checks OK');})().catch(e=>{console.error(e);process.exit(1)});
