<?php
require __DIR__.'/bootstrap.php';
$index=F3Base_Configuracao_Atual::documentacao();check($index['ok']&&$index['versao']==='1.35.0','indice_atual');$names=$index['arquivos'];echo wp_json_encode(array_slice($names,0,2))."\n";
foreach(array('docs/RELEASE-1.35.0.md','docs/AGENTES-1.35.0.md','docs/CONVERSOES-CONTEUDO-1.35.md','docs/dados/configuracao-schema.json') as $file){$at=1;$text='';do{$r=F3Base_Configuracao_Atual::documentacao(array('arquivo'=>$file,'linha'=>$at,'limite'=>30));check($r['ok'],'pagina_'.$file.'_'.$at);$text.=$r['texto'];$at=$r['proxima_linha'];}while($at!==null);check($r['sha256']===hash_file('sha256',F3BASE_PLUGIN_DIR.$file),'hash_'.$file);}
check(!F3Base_Configuracao_Atual::documentacao(array('arquivo'=>'../../wp-config.php'))['ok'],'confinamento_traversal');wp_set_current_user(0);check(!F3Base_Configuracao_Atual::documentacao()['ok'],'documentacao_admin_explicito');wp_set_current_user(1);evidence('docs-1350');
