<?php
$m=new mysqli('127.0.0.1','root','',null,33434);$m->query('CREATE DATABASE IF NOT EXISTS core1350');$m->close();
define('WP_INSTALLING',true);$_SERVER['HTTP_HOST']='127.0.0.1:8134';$_SERVER['SERVER_NAME']='127.0.0.1';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../lab/wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';
if(!is_blog_installed()){wp_install('Core 1.35 laboratório','admin','admin@example.test',true,'','','synthetic-only-1350');}
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');
echo wp_json_encode(array('ativacao'=>is_wp_error($r)?$r->get_error_codes():true,'ciclo'=>F3Base_Instalacao::atualizar(),'estrutura'=>F3Base_Atualizacao::pronta()),JSON_PRETTY_PRINT)."\n";
