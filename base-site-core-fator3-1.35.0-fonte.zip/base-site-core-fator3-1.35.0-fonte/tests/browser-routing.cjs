const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').resolve(__dirname,'..'),plugin=root+'/work/plugin/base-site-core-fator3';
const checks=[];
function run(flags,method='conteudo',extra={}){
 const calls=[],doc=new EventTarget(),win=new EventTarget();doc.readyState='complete';doc.cookie='';doc.querySelectorAll=()=>[];doc.referrer='';
 const loc={protocol:'https:',search:'',origin:'https://example.test',pathname:'/material/'};
 Object.assign(win,{location:loc,localStorage:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}},dataLayer:[],f3baseLeadsDados:{medicao:{ga4:'G-TEST001',gtm:'GTM-TEST001',ads:{id:'AW-123',label:'Contato'},meta:{pixelId:'123',modo:extra.mode||'ambos'},linkedin:{conversionId:'54'},conteudo:Object.assign({adsLabel:'Material',linkedinId:'151'},flags,extra.ids||{})}},f3baseContexto:{pronto:()=>!extra.pending,pendente:()=>!!extra.pending,teste:()=>!!extra.test,politica:()=>extra.suppress?'suprimir':'permitir'},f3baseConsentimento:{permiteCategoria:()=>!extra.denied,permiteGtm:()=>!extra.denied},gtag:(...x)=>calls.push(['google',...x]),fbq:(...x)=>calls.push(['meta',...x]),lintrk:(...x)=>calls.push(['linkedin',...x])});
 class CustomEvent extends Event{constructor(n,o={}){super(n);this.detail=o.detail;}}
 const context={window:win,document:doc,CustomEvent,Event,URLSearchParams,URL,navigator:{},console,setTimeout,clearTimeout,crypto:require('crypto').webcrypto,Uint8Array,Uint32Array,Map,Set,Blob,location:loc};
 vm.runInNewContext(fs.readFileSync(plugin+'/assets/f3base-leads'+(extra.min?'.min':'')+'.js','utf8'),context);
 const id='a'.repeat(32),detail={formulario:'ebook',method,correlacao:id,conversao:{elegivel:true,event_id:id},contexto_teste:!!extra.test};
 doc.dispatchEvent(new CustomEvent('f3base-formulario-aceito',{detail}));doc.dispatchEvent(new CustomEvent('f3base-formulario-aceito',{detail}));
 return {calls,layer:win.dataLayer};
}
function check(x,n){assert(x,n);checks.push(n);}
const on={ga4:true,meta:true,google_ads:true,linkedin:true};
for(const min of [false,true]){
 let r=run(on,'conteudo',{min});check(r.calls.filter(x=>x[0]==='google'&&x[2]==='download_material').length===1,'material GA4 once '+min);check(!r.calls.some(x=>x[2]==='generate_lead'||x[2]==='Lead'),'material no contact events '+min);check(r.calls.some(x=>x[0]==='meta'&&x[1]==='trackCustom'&&x[2]==='MaterialDownload'&&x[4].eventID==='a'.repeat(32)),'Meta custom correlation '+min);check(r.calls.some(x=>x[2]==='conversion'&&x[3].send_to==='AW-123/Material'),'Ads own label '+min);check(r.calls.some(x=>x[0]==='linkedin'&&x[2].conversion_id===151),'LI own ID '+min);
 r=run({},'conteudo',{min});check(r.calls.length===0&&r.layer.length===0,'material defaults silent '+min);
 for(const dest of Object.keys(on)){const flags={...on,[dest]:false};r=run(flags,'conteudo',{min});const kind={ga4:'google',meta:'meta',google_ads:'google',linkedin:'linkedin'}[dest];check(!r.calls.some(x=>x[0]===kind&&(dest==='ga4'?x[2]==='download_material':dest==='google_ads'?x[2]==='conversion':true)),'independent '+dest+' '+min);}
 r=run(on,'conteudo',{min,ids:{adsLabel:'',linkedinId:''}});check(!r.calls.some(x=>x[2]==='conversion'||x[0]==='linkedin'),'empty IDs no fallback '+min);
 r=run({},'whatsapp_formulario',{min});check(r.calls.some(x=>x[2]==='generate_lead')&&r.calls.some(x=>x[1]==='track'&&x[2]==='Lead')&&r.calls.some(x=>x[2]==='conversion'&&x[3].send_to==='AW-123/Contato')&&r.calls.some(x=>x[0]==='linkedin'&&x[2].conversion_id===54),'normal contact unchanged '+min);
 r=run(on,'conteudo',{min,denied:true});check(r.calls.length===0,'consent denied '+min);r=run(on,'conteudo',{min,pending:true});check(r.calls.length===0,'context pending '+min);r=run(on,'conteudo',{min,test:true});check(!r.calls.some(x=>x[0]!=='google'||x[2]!=='download_material'),'test no commercial destinations '+min);r=run(on,'conteudo',{min,mode:'servidor'});check(!r.calls.some(x=>x[0]==='meta'),'server mode no pixel '+min);
}
fs.writeFileSync(root+'/evidence/browser-routing.json',JSON.stringify({runtime:process.version,ambiente:'Node VM, ativos completos e eventos DOM; fornecedores capturados, sem rede',checks},null,2));console.log(checks.length+' JS checks OK');
