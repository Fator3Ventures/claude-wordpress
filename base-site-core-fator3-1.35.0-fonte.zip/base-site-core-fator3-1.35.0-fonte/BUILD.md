# Build e ensaio — Core 1.35.0

Código final em work/plugin/base-site-core-fator3, idêntico ao instalador fechado. Scripts Python usam biblioteca padrão; assets.py usa rjsmin==1.2.5 (python -m pip install --target build/vendor -r build/requirements.txt). Execute python build/assets.py e python build/package-installer.py; PHP_BIN efetivo deve estar em F3BASE_PHP_BIN ou PATH. package-installer.py roda lint antes do ZIP determinístico. ZIPs da base/companhias não são embutidos.

Node: node tests/browser-routing.cjs e node tests/meta-routing.cjs. São ativos completos, DOM EventTarget e transportes simulados; não navegador gráfico.

Bancada nativa requer WordPress 7.1.2 e MySQL 8.0.46 descartáveis, PHP 8.3.6 64 bits com mysqli/mbstring/dom/xml/curl/zip/sodium e extensões WordPress. Forneça sua instalação em lab/wordpress, wp-config local apontando ao banco core1350 em 127.0.0.1:33434, sem uso de dados reais. A configuração deve aceitar F3BASE_LAB_DB e F3BASE_LAB_CONTENT. Vincule wp-content/plugins/base-site-core-fator3 ao código. Mu-plugin de bancada deve bloquear pre_wp_mail e pre_http_request externo; fixtures não podem chamar fornecedores.

Defina F3BASE_SITE ao wp-load.php e F3BASE_ROOT à raiz do fonte. Os scripts run-lab/native-cycles/mcp-cycle são receitas da bancada executada: ajuste caminhos dos binários, datadir e entradas no seu ambiente. run-lab documenta os caminhos originais; não pressupõe que existam em outra máquina. Use instância MySQL isolada; os ciclos removem SOMENTE seus bancos descartáveis core1350_fresh/upgrade/mcp e diretórios de fixture.

Entradas externas para upgrade: instalador 1.34.0, hash no relatório; MCP 0.23.0 e Google 0.10.0 recebidos, nas pastas companions referenciadas pelos testes. Eles não são parte deste fonte. Nenhum script é instrução para rodar em produção. Os testes PHP são iniciados por run-lab.py no mesmo namespace de rede do MySQL. Docs são geradas por tests/base-1330/gerar-inventario.php e gerar-contratos.php com Core ativo. Os nomes herdados 1330 identificam origem do teste; as evidências registram versão efetiva 1.35.0.

Relatório interno antecede o fechamento do fonte. Hash final está no relatório externo. Reempacotamento independente só reproduz o instalador usando os arquivos finais, datas e ordem do gerador; atualizar docs/evidências pode alterar bytes. Não editar arquivo publicado mantendo a mesma versão sem autorização.
