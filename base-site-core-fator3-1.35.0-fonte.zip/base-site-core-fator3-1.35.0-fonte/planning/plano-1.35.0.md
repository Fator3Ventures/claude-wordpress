# Core 1.35.0 — implementação

Base imutável: 1.34.0, SHA-256 3d3d3ffa084026a0f36e3badf852cba8aeb30620503878534328bddb9a260be1.
Pedidos da frota: 212(a), 219, 220, 221, 222(a/b/c), 223. Base recebida em Fator3 Site Core(1).md, 16/10/2026. Normas r4.

- 212: medir uso vivo e arena PHP separadamente; reserva adaptável à folga, fontes retidas e crescimento da consulta explícitos; sem aumentar memory_limit; 28 dias exatos em baixo volume e falha segura em insuficiência.
- 219: cabeçalho passa ao mínimo efetivamente exercitado: WP 7.1.2/PHP 8.3.6, 64 bits. Nova instalação e atualização direta no mesmo ambiente.
- 220: comparar texto/blocos canônicos, metadados Slack e transformações de links/e-mail; detectar edições reais. Investigar divergência além dos metadados já normalizados em 1.34.
- 221: campos textuais Meta usam rótulos do catálogo, múltiplos separados por vírgula; desconhecido mantém chave e resposta livre mantém texto; enums seguem IDs.
- 222: material usa download_material (GA4), MaterialDownload (Meta), rótulo Ads próprio e ID LinkedIn próprio. Quatro chaves liga/desliga, desligadas por padrão para exigir escolha explícita; sem fallback para contato. Reserva de aquisição separa material/contato. Servidor e navegador usam mesmo nome/ID e consentimento. Pipedrive mapa_pontos.conteudo com fallback site. Relatórios distinguem volumes material/contato sem apagar histórico.
- 223: remover espalhamento associativo em array_merge; render completo da tela com coleção LinkedIn, mesmo pausada.

Impactos prévios: base-site-core-fator3-1.35.0-impacto-wp-mcp-google-fator3.md e base-site-core-fator3-1.35.0-impacto-implantador-base.md. Sem alteração no SDK local Lead Sync/Meta orgânico/MCP; nenhum patch nesses plugins.

Provas: PHP/JS, cenários WordPress reais com fornecedores simulados, navegador se disponível, instalação limpa, upgrade 1.34→1.35, comparação do ZIP final, instalação e docs no Site-Teste. Homologação real CTO/Korvena/Slack somente com recursos concretamente autorizados, sem envio comercial automático. Não publicar frota/GitHub.

## Fechamento

Instalador 1368395e6c5842c21e822010310c1d544000ed7d72b2f6ee234491d18c686f20. Site-Teste ativo, 15 etapas concluídas e 0 falhas. Matriz mínima e MCP real aprovados. SDK 1.0.0 mantém enumeração fechada; proposta inicial de extensão de evento substituída por configuração administrativa 8.1.0 e impacto coordenado Google. Limites externos constam no relatório.
