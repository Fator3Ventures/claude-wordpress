# Fator3 Site Core 1.35.0 — fonte

Leia BUILD.md e docs/base-site-core-fator3-1.35.0-relatorio.md. O plugin instalável fica no artefato -instalador.zip, entregue separadamente.
