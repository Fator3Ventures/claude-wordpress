# Impacto de base-site-core-fator3 1.35.0 em implantador-base

Revisão 3 · Etapa: entrega · Data: 2026-10-17 UTC · Situação: aberto para o destinatário
Emissor: Fator3 Site Core, base 1.34.0 → alvo 1.35.0 implementado.
Instalador: `base-site-core-fator3-1.35.0-instalador.zip` · SHA-256 `1368395e6c5842c21e822010310c1d544000ed7d72b2f6ee234491d18c686f20`.
Pedido: 219/222 · Classificação: validacao-coordenada. Preparado para o dono; não enviado ao destinatário.

## Resultado desta entrega

Instalação nova e upgrade direto da base aprovados no mínimo WP 7.1.2/PHP 8.3.6 64 bits; Site-Teste WP 7.1.3/PHP 8.3.30 concluiu 15 etapas sem falhas. Contrato administrativo 8.1.0 adiciona f3base_conversoes_conteudo (quatro booleanos false), f3base_google_ads.conteudo_conversion_label (vazio) e f3base_linkedin_conteudo_conversion_id (vazio).

Responsável Implantador 2.8.0: validar mínimos, aceitar schema aditivo, preservar configuração de contato e não habilitar material automaticamente. Ensaiar o próprio binário com esta versão do Core e a recusa de revisão obsoleta. Identidade recebida confirmada no insumo da base: implantador-base/implantador-base.php; pacote de referência SHA-256 2e7b408ede054c3f5185de32014be0903f2889b3d60947a15be18ce7f96e7f91. Binário do Implantador não foi executado nesta rodada. Aceite do destinatário pendente.

## Histórico de planejamento e implementação (superado onde indicado)

Revisão 1 · Etapa: planejamento · Data: 2026-10-16 · Situação: aberto
Classificação: validacao-coordenada · Natureza: contrato/configuração/requisitos
Base: 1.34.0 (SHA-256 3d3d3ffa084026a0f36e3badf852cba8aeb30620503878534328bddb9a260be1). Alvo 1.35.0 previsto; instalador ainda não gerado.

Pedidos 219/222: novo mínimo WP 7.1.2/PHP 8.3.6 e configuração explícita de material. Responsável Implantador 2.8: validar ambiente antes de instalar e não ativar novas conversões automaticamente. Preservar campos de contato. Novas chaves documentadas no catálogo; contrato administrativo aditivo 8.1.0. Ensaiar instalação limpa e configuração com defaults desligados.

Critério de aceite: confirmar os contratos no binário e demonstrar material separado de contato, preservação de configurações anteriores e autorização administrativa. Não há aprovação do destinatário nem mudança do seu pacote nesta rodada. Documento será atualizado com resultados e hash final. Preparado para encaminhamento; não enviado.
