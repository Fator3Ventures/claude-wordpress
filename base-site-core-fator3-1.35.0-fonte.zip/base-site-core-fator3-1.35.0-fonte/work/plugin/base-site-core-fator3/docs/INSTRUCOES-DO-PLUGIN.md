# Instruções do plugin

Leia AGENTES-1.35.0.md, DOCUMENTACAO.md e CONVERSOES-CONTEUDO-1.35.md. Normas comuns revisão 4. Contratos instalados descrevem o candidato efetivo; arquivos históricos não prevalecem.
