# Documentação do pacote

Índice: DOCUMENTACAO.md. Procedimentos vigentes: AGENTES-1.35.0.md e RELEASE-1.35.0.md.
