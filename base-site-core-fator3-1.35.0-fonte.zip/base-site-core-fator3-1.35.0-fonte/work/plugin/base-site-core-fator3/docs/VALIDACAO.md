# Validação — Core 1.35.0

Instalação limpa e atualização direta 1.34→1.35 no WordPress 7.1.2/PHP 8.3.6, 64 bits; lint; seis pedidos; HTML completo da tela Conexões com LinkedIn pausado; eventos DOM nos scripts completos e minificados; SDK público e consumidor real Google 0.10.0; paginação e autorização documental; transporte MCP 0.23.0. Laboratório descartável com correio e fornecedores simulados/bloqueados. Memória ensaiada sob limite PHP real de 128 MiB, com 126 MiB alocados. Fixture usa volume e período declarados na evidência.

HTML renderizado e Node VM não equivalem a inspeção visual em navegador nem Tag Assistant. Binário do navegador indisponível após falha de download neste ambiente. Fornecedor simulado não prova entrega. O relatório externo registra instalador exato, resultados remotos, limitações e aceites em CTO/Korvena/Slack pendentes. Não reutilizar a matriz de 1.34 como prova própria desta versão.
