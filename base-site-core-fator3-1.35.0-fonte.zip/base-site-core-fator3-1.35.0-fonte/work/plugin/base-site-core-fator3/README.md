# Fator3 Site Core 1.35.0

Instalação nova ou atualização direta 1.34.0. WordPress 7.1.2/PHP 8.3.6 64 bits. Pasta e basename base-site-core-fator3/base-site-core-fator3.php. Contrato administrativo 8.1.0; SDK de medição 1.0.0/schema 1 mantido.

Leia docs/DOCUMENTACAO.md, docs/RELEASE-1.35.0.md e docs/CONVERSOES-CONTEUDO-1.35.md. O relatório externo informa provas, limites, nomes e hashes exatos.
