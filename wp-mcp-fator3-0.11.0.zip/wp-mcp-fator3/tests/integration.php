<?php
/** Run only on disposable WordPress: php integration.php /absolute/wp-root. */
declare(strict_types=1);
if ( PHP_SAPI !== 'cli' || empty( $argv[1] ) ) { exit(1); }
define('WP_DISABLE_FATAL_ERROR_HANDLER',true);
$_SERVER['HTTP_HOST']='127.0.0.1:8787';$_SERVER['REQUEST_URI']='/';
require rtrim($argv[1],'/').'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/user.php';
wp_set_current_user(1);
add_filter('pre_wp_mail','__return_false');
use Fator3\McpFiles\PathGuard;
$checks=[];$posts=[];$users=[];$comments=[];$paths=[];$dirs=[];$backup_ids=[];
function check(string $name,bool $ok,string $detail=''):void {global $checks;$checks[]=['test'=>$name,'ok'=>$ok,'detail'=>$detail];}
function call_ability(string $name,array $args=[]):array {
	$a=wp_get_ability($name);if(!$a)throw new Exception('Missing '.$name);
	$r=$a->execute($args);
	if(is_wp_error($r))throw new Exception($name.': '.$r->get_error_code().' '.$r->get_error_message());
	if(!is_array($r)||isset($r['success'])&&!$r['success'])throw new Exception($name.': '.json_encode($r));
	global $backup_ids;if(!empty($r['backup_id']))$backup_ids[]=$r['backup_id'];
	return $r;
}
function denied(string $name,array $args):bool {$r=wp_get_ability($name)->execute($args);return is_wp_error($r)||is_array($r)&&isset($r['success'])&&!$r['success'];}
try {
	$expected=json_decode(file_get_contents(__DIR__.'/expected-abilities.json'),true);
	$actual=array_keys(wp_get_abilities());
	check('all_73_original_abilities_preserved',!array_diff($expected,$actual));
	check('single_plugin_active',count(get_option('active_plugins'))===1);
	foreach(['discover-abilities','get-ability-info','execute-ability'] as $name){$meta=wp_get_ability('wp-mcp-ultimate/'.$name)->get_meta();check('mcp_meta:'.$name,!empty($meta['mcp']['public']));}
	$r=call_ability('wp-mcp-ultimate/execute-ability',['ability_name'=>'plugins/list','parameters'=>'{}']);
	check('stringified_empty_parameters_accepted',!empty($r['success'])&&is_array($r['data']));
	check('invalid_json_parameters_rejected',denied('wp-mcp-ultimate/execute-ability',['ability_name'=>'plugins/list','parameters'=>'{invalid']));

	$markup=serialize_blocks([['blockName'=>'core/paragraph','attrs'=>['className'=>'a--b','label'=>'Segunda opinião','url'=>'https://example.org/a/b','literal'=>'C:\\path\\file'],'innerBlocks'=>[],'innerHTML'=>'<p>TOKEN0</p>','innerContent'=>['<p>TOKEN0</p>']]]);
	$markup=str_replace('opinião', 'opini\\u00e3o', $markup);
	check('fixture_contains_real_gutenberg_escapes',str_contains($markup,'\\u002d')&&str_contains($markup,'\\u00e3'));
	$title='Title \\path "quoted"';$excerpt='Excerpt \\u00e3 \\/';
	foreach(['post','page'] as $type){
		$r=call_ability('content/create-'.$type,['title'=>$title,'content'=>$markup,'excerpt'=>$excerpt]);$id=$r['id'];$posts[]=$id;
		check($type.':create_bytes',get_post($id)->post_content===$markup&&get_post($id)->post_title===$title&&get_post($id)->post_excerpt===$excerpt);
		call_ability('content/update-'.$type,['id'=>$id,'content'=>$markup,'title'=>$title.'2','excerpt'=>$excerpt.'2']);
		check($type.':update_bytes',get_post($id)->post_content===$markup&&get_post($id)->post_title===$title.'2'&&get_post($id)->post_excerpt===$excerpt.'2');
		$want=$markup;
		for($i=0;$i<3;$i++){
			$find='TOKEN'.$i;$replace='TOKEN'.($i+1);$want=str_replace($find,$replace,$want);
			call_ability('content/patch-'.$type,['id'=>$id,'find'=>$find,'replace'=>$replace]);
			check($type.':patch_roundtrip_'.($i+1),get_post($id)->post_content===$want);
		}
		call_ability('content/patch-'.$type,['id'=>$id,'find'=>'/TOKEN3/','replace'=>'TOKEN4','regex'=>true]);$want=str_replace('TOKEN3','TOKEN4',$want);
		check($type.':regex_bytes',get_post($id)->post_content===$want);
		call_ability('content/patch-'.$type,['id'=>$id,'find'=>'TOKEN4','replace'=>'$1 \\literal','limit'=>1]);$want=str_replace('TOKEN4','$1 \\literal',$want);
		check($type.':limited_literal_replacement',get_post($id)->post_content===$want);
		check($type.':regex_invalid_rejected',denied('content/patch-'.$type,['id'=>$id,'find'=>'/[invalid/','replace'=>'x','regex'=>true]));
	}
	$nav=wp_insert_post(wp_slash(['post_type'=>'wp_navigation','post_title'=>'Navigation fixture','post_content'=>$markup,'post_status'=>'draft']),true);$posts[]=$nav;
	call_ability('content/patch-post',['id'=>$nav,'find'=>'TOKEN0','replace'=>'MENU']);
	check('navigation_block_json_preserved',get_post($nav)->post_content===str_replace('TOKEN0','MENU',$markup));

	$pass='Pass\\word"123!';$description='Bio \\u00e3 \\path';$display='F3 \\Display';
	$u=call_ability('users/create',['username'=>'f3-test-'.bin2hex(random_bytes(4)),'email'=>'f3-'.bin2hex(random_bytes(4)).'@example.invalid','password'=>$pass,'display_name'=>$display,'description'=>$description]);$users[]=$u['id'];
	check('users:create_bio_bytes',get_user_meta($u['id'],'description',true)===$description);
	check('users:create_display_bytes',get_userdata($u['id'])->display_name===$display);
	check('users:create_password_not_slashed',wp_check_password($pass,get_userdata($u['id'])->user_pass,$u['id']));
	call_ability('users/update',['id'=>$u['id'],'description'=>$description.'2','display_name'=>$display.'2','password'=>$pass.'2']);
	check('users:update_bio_bytes',get_user_meta($u['id'],'description',true)===$description.'2');
	check('users:update_display_bytes',get_userdata($u['id'])->display_name===$display.'2');
	check('users:update_password_not_slashed',wp_check_password($pass.'2',get_userdata($u['id'])->user_pass,$u['id']));

	$c=call_ability('comments/create',['post_id'=>$posts[0],'content'=>$description,'author'=>$display]);$cid=$c['id']??$c['comment_id'];$comments[]=$cid;
	check('comments:create_bytes',get_comment($cid)->comment_content===$description&&get_comment($cid)->comment_author===$display);
	$c=call_ability('comments/reply',['parent_id'=>$cid,'content'=>$description.'2']);$rid=$c['id']??$c['comment_id'];$comments[]=$rid;
	check('comments:reply_bytes',get_comment($rid)->comment_content===$description.'2');
	$aid=wp_insert_attachment(['post_title'=>'Attachment fixture','post_status'=>'inherit','post_mime_type'=>'image/png']);$posts[]=$aid;
	call_ability('media/update',['id'=>$aid,'title'=>$title,'caption'=>$excerpt,'description'=>$description,'alt_text'=>$title]);
	$a=get_post($aid);check('media:update_all_fields',$a->post_title===$title&&$a->post_excerpt===$excerpt&&$a->post_content===$description&&get_post_meta($aid,'_wp_attachment_image_alt',true)===$title);

	check('path:default_unconfined',PathGuard::roots()===[]&&!PathGuard::is_confined());
	check('path:absolute_wp_config',PathGuard::resolve(ABSPATH.'wp-config.php',false)===realpath(ABSPATH.'wp-config.php'));
	check('path:traversal',PathGuard::resolve(ABSPATH.'wp-content/../wp-config.php',false)===realpath(ABSPATH.'wp-config.php'));
	check('path:root_slash',PathGuard::resolve('/',false)==='/');
	foreach(["x\0","\0x",'php://filter/resource=x','phar://x/y','https://example.org/x','data:text/plain,x'] as $invalid)check('path:reject_'.bin2hex($invalid),is_wp_error(PathGuard::resolve($invalid,true)));
	$outside=dirname(rtrim(ABSPATH,'/')).'/f3-outside-'.bin2hex(random_bytes(5));$dirs[]=$outside;$path=$outside.'/deep/file.txt';$paths[]=$path;
	call_ability('files/write',['path'=>$path,'content'=>$description,'create_dirs'=>true]);
	check('files:write_outside_wordpress',file_get_contents($path)===$description);
	check('files:read_outside_wordpress',call_ability('files/read',['path'=>$path])['content']===$description);
	check('files:stale_sha_rejected',denied('files/write',['path'=>$path,'content'=>'wrong','expected_sha256'=>str_repeat('0',64)])&&file_get_contents($path)===$description);
	$del=call_ability('files/delete',['path'=>$path]);clearstatcache(true,$path);
	check('files:delete_creates_backup',!file_exists($path)&&!empty($del['backup_id']));
	call_ability('files/restore',['backup_id'=>$del['backup_id']]);check('files:restore_deleted_bytes',file_get_contents($path)===$description);
	$meta=Fator3\McpFiles\StateStore::get('backups',$del['backup_id']);$meta['content_base64']=base64_encode('corrupted');Fator3\McpFiles\StateStore::put('backups',$del['backup_id'],$meta);
	check('files:reject_corrupted_backup',denied('files/restore',['backup_id'=>$del['backup_id']])&&file_get_contents($path)===$description);
	$broken=$outside.'/broken.php';$paths[]=$broken;
	check('files:invalid_php_not_written',denied('files/write',['path'=>$broken,'content'=>'<?php function broken( {'])&&!file_exists($broken));
	check('files:delete_directory_rejected',denied('files/delete',['path'=>$outside]));
	$self=F3_MCP_FILES_DIR.'includes/PathGuard.php';
	check('files:self_read_allowed',!is_wp_error(PathGuard::resolve($self,false)));
	check('files:self_edit_rejected',is_wp_error(PathGuard::resolve($self,true)));
	$theme=realpath(get_theme_root());$link=$theme.'/f3-link-'.bin2hex(random_bytes(5));symlink($outside,$link);$paths[]=$link;
	$clamp=static fn()=>[$theme];add_filter('f3_mcp_files_roots',$clamp,PHP_INT_MAX);
	try{
		check('clamp:outside_read_rejected',is_wp_error(PathGuard::resolve($path,false)));
		check('clamp:symlink_rejected',is_wp_error(PathGuard::resolve($link.'/deep/file.txt',false)));
		check('clamp:create_dirs_rejected',is_wp_error(PathGuard::prepare_parent($link.'/unwanted/x.txt'))&&!file_exists($outside.'/unwanted'));
		check('clamp:prefix_rejected',is_wp_error(PathGuard::resolve($theme.'-evil/file.txt',true)));
		$listing=call_ability('files/list',['path'=>$theme,'recursive'=>true]);
		check('clamp:list_does_not_follow_outside_symlink',!in_array(basename($link),array_column($listing['entries'],'name'),true));
	}finally{remove_filter('f3_mcp_files_roots',$clamp,PHP_INT_MAX);}
	$badroot=static fn()=>['/f3-nonexistent-root-'.PHP_INT_MAX];add_filter('f3_mcp_files_roots',$badroot,PHP_INT_MAX);
	try{check('clamp:invalid_roots_fail_closed',is_wp_error(PathGuard::resolve(ABSPATH.'wp-config.php',false)));}finally{remove_filter('f3_mcp_files_roots',$badroot,PHP_INT_MAX);}
	$closed=static fn()=>false;add_filter('f3_mcp_files_enabled',$closed,PHP_INT_MAX);
	try{check('gate:kill_switch',denied('files/read',['path'=>$path]));check('gate:db_kill_switch',denied('db/query',['sql'=>'SELECT 1']));}finally{remove_filter('f3_mcp_files_enabled',$closed,PHP_INT_MAX);}
	wp_set_current_user($u['id']);check('gate:subscriber_cannot_read_files',denied('files/read',['path'=>$path]));wp_set_current_user(1);
	foreach(['f3_mcp_files_enabled','f3_mcp_db_writes','f3_mcp_files_audit','f3_mcp_oauth_clients'] as $key)check('options:protect_'.$key,denied('options/update',['name'=>$key,'value'=>false]));

	$sql="UPDATE {$wpdb->posts} SET post_title='F3 database changed' WHERE ID=".(int)$posts[0];
	$old=get_post($posts[0])->post_title;$preview=call_ability('db/execute',['sql'=>$sql]);
	check('db:preview_has_no_write',empty($preview['applied'])&&get_post($posts[0])->post_title===$old&&!empty($preview['confirm_token']));
	check('db:wrong_confirmation_rejected',denied('db/execute',['sql'=>$sql,'confirm_token'=>'wrong']));
	$done=call_ability('db/execute',['sql'=>$sql,'confirm_token'=>$preview['confirm_token']]);clean_post_cache($posts[0]);
	check('db:confirmed_write_applied',!empty($done['applied'])&&get_post($posts[0])->post_title==='F3 database changed'&&!empty($done['backup_id']));
	check('db:unbounded_delete_rejected',denied('db/execute',['sql'=>"DELETE FROM {$wpdb->posts}"]));
	check('fetch:ssrf_loopback_rejected',is_wp_error(Fator3\McpFiles\Http::fetch('http://127.0.0.1/private',100)));
	$selftest=call_ability('files/selftest');foreach($selftest['checks'] as $row)check('selftest:'.$row['check'],$row['ok'],$row['detail']??'');
}catch(Throwable $e){check('unexpected_exception',false,$e->getMessage());}
finally{
	wp_set_current_user(1);
	foreach($comments as $id)wp_delete_comment($id,true);
	foreach($posts as $id)wp_delete_post($id,true);
	foreach($users as $id)wp_delete_user($id);
	foreach(array_reverse($paths) as $path)if(is_file($path)||is_link($path))@unlink($path);
	foreach($dirs as $dir){@rmdir($dir.'/deep');@rmdir($dir);}
	foreach($backup_ids as $id){Fator3\McpFiles\StateStore::delete('backups',$id);Fator3\McpFiles\StateStore::delete('backup-index',$id);}
}
$failed=count(array_filter($checks,static fn($x)=>!$x['ok']));
$report=['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'passed'=>count($checks)-$failed,'failed'=>$failed,'checks'=>$checks];
if(!empty($argv[2]))file_put_contents($argv[2],json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo json_encode(['passed'=>$report['passed'],'failed'=>$failed,'failures'=>array_values(array_filter($checks,static fn($x)=>!$x['ok']))],JSON_UNESCAPED_UNICODE).PHP_EOL;
exit($failed?1:0);
