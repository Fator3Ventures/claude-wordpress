<?php
/** Cross-cutting contracts for this distribution's abilities. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class AbilityRuntime {
	private const PREFIXES = ['files/', 'db/', 'content/', 'comments/', 'media/', 'menus/', 'widgets/', 'users/', 'options/', 'plugins/', 'themes/', 'system/', 'operations/', 'audit/', 'backups/'];
	public static function init(): void {
		add_filter('wp_register_ability_args', [self::class, 'decorate'], 90, 2);
	}
	public static function decorate(array $args, string $name): array {
		$owned = !empty($args['meta']['fator3']['owned']);
		if (!$owned && isset($args['execute_callback'])) {
			try {
				$cb = $args['execute_callback']; $reflection = is_array($cb) ? new \ReflectionMethod($cb[0], $cb[1]) : new \ReflectionFunction($cb);
				$file = wp_normalize_path((string)$reflection->getFileName());
				$owned = str_starts_with($file, wp_normalize_path(F3_MCP_FILES_DIR));
			} catch (\Throwable $e) { $owned = false; }
		}
		if (str_starts_with($name, 'wp-mcp-ultimate/')) return $args;
		if (!$owned || !isset($args['execute_callback'])) return $args;
		$read = !empty($args['meta']['annotations']['readonly']);
		$props = &$args['input_schema']['properties'];
		if (!is_array($props)) $props = [];
		if (!isset($args['input_schema']['type'])) $args['input_schema']['type'] = 'object';
		if (!$read) $props['idempotency_key'] = ['type' => 'string', 'minLength' => 1, 'maxLength' => 128, 'description' => 'Stable operation key. A completed call can be replayed without repeating its side effects.'];
		if (in_array($name, ['files/fetch', 'files/restore'], true)) $props['expected_sha256'] = ['type' => 'string', 'description' => 'Expected current destination SHA-256, checked under its exclusive lock.'];
		if (preg_match('~^(content/(update|patch|delete)-(post|page)|media/(update|delete))$~', $name)) $props['expected_revision'] = ['type' => 'string', 'description' => 'Opaque revision token from a content/media read. Reject changes since that read.'];
		if (isset($args['output_schema'])) {
			$args['output_schema']['properties'] = ($args['output_schema']['properties'] ?? []) + array_intersect_key(Result::schema()['properties'], array_flip(['success','message','error_code','conflict','retryable'])) + [
				'operation_id' => ['type' => 'string'], 'replayed' => ['type' => 'boolean'], 'revision' => ['type' => 'string'],
				'current_revision' => ['type' => 'string'], 'current_sha256' => ['type' => 'string'], 'retry_after_ms' => ['type' => 'integer'],
			];
		}
		if ('files/list' === $name || 'files/backups' === $name) $props += ['offset' => Registry::integer(), 'per_page' => Registry::integer(1, 'files/list' === $name ? 1000 : 200)];
		if ('files/read' === $name) $props += ['cursor' => Registry::string('Byte cursor. Empty string starts at byte zero. Cannot combine with line/tail/grep options.'), 'byte_limit' => Registry::integer(1, PathGuard::max_bytes())];
		if ('files/read' === $name) { $args['output_schema']['properties']['mode']['enum'][] = 'cursor'; }
		if ('db/execute' === $name) $args['output_schema']['properties']['applied']['type'] = ['boolean', 'null'];
		$callback = $args['execute_callback'];
		$permission = $args['permission_callback'] ?? static fn() => false;
		$args['execute_callback'] = static function ($input = []) use ($callback, $permission, $name, $read): array {
			$input = is_array($input) ? $input : [];
			$start = microtime(true);
			$id = bin2hex(random_bytes(12));
			try {
				$allowed = $permission($input);
				if (is_wp_error($allowed) || !$allowed) return Result::fail('permission_denied', 'Permission denied.');
				$run = static fn() => self::locked($name, $input, $callback);
				$result = !$read && isset($input['idempotency_key']) ? self::once($name, $input, $run, $id) : $run();
				$result = Result::normalize($result);
				if (!$read) $result['operation_id'] = $result['operation_id'] ?? $id;
				if (false !== ($result['success'] ?? true) && !empty($input['id']) && (str_starts_with($name, 'content/') || str_starts_with($name, 'media/')) && get_post((int)$input['id'])) $result['revision'] = ContentTools::revision((int)$input['id']);
				Audit::record($name, $input, $result, (int)round((microtime(true) - $start) * 1000));
				return $result;
			} catch (\Throwable $error) {
				$failure = Result::fail('operation_exception', $error->getMessage(), ['operation_id' => $id]);
				Audit::record($name, $input, $failure, (int)round((microtime(true) - $start) * 1000));
				return $failure;
			}
		};
		$args['meta']['fator3'] = ['version' => F3_MCP_FILES_VERSION, 'result_contract' => 1];
		return $args;
	}
	private static function locked(string $name, array $input, callable $callback) {
		$call = static function () use ($input, $callback, $name) { $args = $input; unset($args['idempotency_key']);
			if (preg_match('~^(content/(update|patch|delete)-(post|page)|media/(update|delete))$~', $name)) unset($args['expected_revision']); return $callback($args); };
		if (in_array($name, ['db/query','db/execute'], true)) return DatabaseBudget::run((string)($input['sql'] ?? ''), $call);
		if (in_array($name, ['files/read','files/stat'], true)) return Locks::files([(string)($input['path'] ?? '')], static fn() => $call(), false);
		if ('media/upload' === $name || 'media/delete' === $name || 'content/delete-post' === $name && !empty($input['id']) && 'attachment' === get_post_type((int)$input['id'])) {
			$upload = wp_upload_dir(null, false); $roots = [$upload['basedir']];
			if (!empty($input['id'])) { $attached = get_attached_file((int)$input['id']); if ($attached) $roots[] = dirname($attached); }
			foreach ($roots as &$root) while (!is_dir($root) && dirname($root) !== $root) $root = dirname($root); unset($root);
			$native = $call; $call = static fn() => Locks::trees(array_unique($roots), $native);
		}
		if (in_array($name, ['plugins/upload','plugins/upload-base64','plugins/delete','plugins/install','plugins/update'], true)) return Locks::trees([WP_PLUGIN_DIR], $call);
		if (in_array($name, ['themes/install','themes/activate'], true)) return Locks::trees([get_theme_root()], $call);
		if (in_array($name, ['files/write', 'files/patch', 'files/delete', 'files/fetch', 'files/restore'], true)) {
			if (!PathGuard::is_enabled() || !PathGuard::can_edit()) return Result::fail('permission_denied', 'File channel is closed or permission is missing.');
			$requested = (string)($input['path'] ?? '');
			if ('files/restore' === $name) {
				$meta = Backups::metadata((string)($input['backup_id'] ?? ''), false);
				if (is_wp_error($meta)) return Result::error($meta);
				if (($meta['kind'] ?? '') !== 'file' || !is_string($meta['path'] ?? null)) return Result::fail('backup_type_mismatch', 'files/restore requires a file backup.');
				$requested = (string)$meta['path'];
			}
			return Locks::files([$requested], static function ($paths) use ($requested, $input, $call) {
				$conflict = Locks::check_hash($paths[$requested], $input);
				return $conflict ?? $call();
			});
		}
		if (preg_match('~^(content/(update|patch|delete)-(post|page)|media/(update|delete))$~', $name) && !empty($input['id'])) {
			return Locks::run(['post:' . get_current_blog_id() . ':' . (int)$input['id'] => LOCK_EX], static function () use ($input, $call) {
				clean_post_cache((int)$input['id']);
				if (isset($input['expected_revision']) && get_post((int)$input['id'])) {
					$current = ContentTools::revision((int)$input['id']);
					if (!hash_equals($current, (string)$input['expected_revision'])) return Result::fail('content_conflict', 'Content changed since the supplied revision.', ['conflict' => true, 'current_revision' => $current]);
				}
				return $call();
			});
		}
		if ('options/update' === $name) return Locks::run(['option:' . get_current_blog_id() . ':' . (string)($input['name'] ?? '') => LOCK_EX], $call);
		if ('comments/delete' === $name) return Locks::run(['comment:' . get_current_blog_id() . ':' . (int)($input['id'] ?? 0) => LOCK_EX], $call);
		return $call();
	}
	private static function canonical($value) { if (!is_array($value)) return $value; if (array_keys($value) !== range(0, count($value) - 1)) ksort($value); foreach ($value as &$v) $v = self::canonical($v); unset($v); return $value; }
	private static function once(string $name, array $input, callable $run, string $operation_id): array {
		$key = get_current_user_id() . ':' . $name . ':' . $input['idempotency_key'];
		$args = $input; unset($args['idempotency_key']);
		$fingerprint = hash('sha256', serialize(self::canonical($args)));
		return Locks::run(['once:' . get_current_blog_id() . ':' . $key => LOCK_EX], static function () use ($key, $fingerprint, $run, $operation_id) {
			$state = StateStore::get('idempotency', $key);
			if ($state) {
				if (!hash_equals($state['fingerprint'], $fingerprint)) return Result::fail('idempotency_conflict', 'This key was used with different parameters.', ['conflict' => true]);
				if ('complete' === $state['status']) return array_replace($state['result'], ['replayed' => true]);
				return Result::fail('operation_uncertain', 'A previous execution did not record completion. Inspect its target before creating another operation.', ['operation_id' => $state['operation_id']]);
			}
			StateStore::put('idempotency', $key, ['status' => 'running', 'fingerprint' => $fingerprint, 'operation_id' => $operation_id, 'time' => time()]);
			$result = Result::normalize($run());
			$result['operation_id'] = $operation_id;
			if (in_array($result['error_code'] ?? '', ['resource_busy','file_conflict','content_conflict','database_conflict'], true)) { StateStore::delete('idempotency', $key); return $result; }
			StateStore::put('idempotency', $key, ['status' => 'complete', 'fingerprint' => $fingerprint, 'operation_id' => $operation_id, 'result' => $result, 'time' => time()]);
			return $result;
		});
	}
}
