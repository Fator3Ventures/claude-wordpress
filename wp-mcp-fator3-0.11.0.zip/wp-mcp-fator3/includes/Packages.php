<?php
/** Native WordPress package management with captured filesystem prompts. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Packages {
	public static function register(): void {
		Registry::add('themes/list', 'List installed themes, active template/stylesheet, parent and compatibility.', [], [], [self::class, 'listing'], 'edit_theme_options');
		Registry::add('themes/validate', 'Validate an installed theme and parent requirements before activation. Does not execute theme code or render the site.', ['stylesheet' => Registry::string()], ['stylesheet'], [self::class, 'validate'], 'edit_theme_options');
		Registry::add('themes/install', 'Install a theme by its WordPress.org catalog slug. Does not activate it.', ['slug' => Registry::string()], ['slug'], static fn($a) => self::install($a, 'theme'), 'install_themes', false);
		Registry::add('themes/activate', 'Activate a validated installed theme with switch_theme and verify the effective stylesheet/template.', ['stylesheet' => Registry::string()], ['stylesheet'], [self::class, 'activate'], 'switch_themes', false);
		Registry::add('plugins/install', 'Install a plugin by its WordPress.org catalog slug. Does not activate it.', ['slug' => Registry::string()], ['slug'], static fn($a) => self::install($a, 'plugin'), 'install_plugins', false);
		Registry::add('plugins/update', 'Update one installed plugin through its WordPress update offer and verify the installed version. The MCP server itself must be updated through wp-admin.', ['plugin' => Registry::string('folder/main.php')], ['plugin'], [self::class, 'update'], 'update_plugins', false);
	}
	private static function info(\WP_Theme $theme): array {
		$error = $theme->errors();
		return ['stylesheet' => $theme->get_stylesheet(), 'template' => $theme->get_template(), 'name' => $theme->get('Name'), 'version' => $theme->get('Version'), 'parent' => $theme->get('Template'), 'active' => get_stylesheet() === $theme->get_stylesheet(), 'block_theme' => $theme->is_block_theme(), 'requires_wordpress' => $theme->get('RequiresWP'), 'requires_php' => $theme->get('RequiresPHP'), 'errors' => is_wp_error($error) ? $error->get_error_messages() : []];
	}
	public static function listing(array $input = []): array { return Result::ok(['themes' => array_values(array_map([self::class, 'info'], wp_get_themes(['errors' => null]))), 'stylesheet' => get_stylesheet(), 'template' => get_template()]); }
	public static function validate(array $input): array {
		$theme = wp_get_theme($input['stylesheet']);
		if (!$theme->exists()) return Result::fail('theme_not_found', 'Installed theme not found.');
		$info = self::info($theme); $errors = $info['errors'];
		if ($theme->get('RequiresWP') && !is_wp_version_compatible($theme->get('RequiresWP'))) $errors[] = 'WordPress version requirement not met.';
		if ($theme->get('RequiresPHP') && !is_php_version_compatible($theme->get('RequiresPHP'))) $errors[] = 'PHP version requirement not met.';
		if (is_multisite() && !$theme->is_allowed()) $errors[] = 'Theme is not enabled for this site/network.';
		return $errors ? Result::fail('theme_invalid', implode(' ', $errors), ['theme' => $info, 'valid' => false]) : Result::ok(['theme' => $info, 'valid' => true]);
	}
	public static function activate(array $input): array {
		$valid = self::validate($input); if (!$valid['success']) return $valid;
		$before = get_stylesheet(); if ($before === $input['stylesheet']) return Result::ok(['changed' => false, 'stylesheet' => $before, 'template' => get_template()]);
		switch_theme($input['stylesheet']);
		if (get_stylesheet() !== $input['stylesheet']) return Result::fail('theme_activation_failed', 'The requested stylesheet did not become active.');
		return Result::ok(['changed' => true, 'stylesheet' => get_stylesheet(), 'template' => get_template(), 'previous_stylesheet' => $before]);
	}
	private static function filesystem() {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		if (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS) return new \WP_Error('file_modifications_disabled', 'WordPress package changes are disabled.');
		ob_start(); try { $credentials = request_filesystem_credentials(''); } finally { ob_end_clean(); }
		if (false === $credentials || !WP_Filesystem($credentials)) return new \WP_Error('filesystem_credentials_required', 'Configure WordPress filesystem access before using package abilities.');
		return $credentials;
	}
	private static function upgrade(callable $run): array {
		$credentials = self::filesystem(); if (is_wp_error($credentials)) return Result::error($credentials);
		$filter = static fn($value, $url, $type, $error) => $error ? false : $credentials;
		add_filter('request_filesystem_credentials', $filter, PHP_INT_MAX, 4);
		ob_start();
		try { return $run(); }
		finally { ob_end_clean(); remove_filter('request_filesystem_credentials', $filter, PHP_INT_MAX); }
	}
	public static function install(array $input, string $kind): array {
		$slug = $input['slug'];
		if (!preg_match('/^[a-z0-9][a-z0-9-]{0,99}$/D', $slug)) return Result::fail('invalid_slug', 'Supply a WordPress.org catalog slug.');
		if ('theme' === $kind && wp_get_theme($slug)->exists()) return Result::fail('package_exists', 'Theme is already installed.');
		return self::upgrade(static function () use ($slug, $kind) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php'; require_once ABSPATH . 'wp-admin/includes/theme-install.php'; require_once ABSPATH . 'wp-admin/includes/theme.php';
			$api = 'theme' === $kind ? themes_api('theme_information', ['slug' => $slug, 'fields' => ['sections' => false]]) : plugins_api('plugin_information', ['slug' => $slug, 'fields' => ['sections' => false]]);
			if (is_wp_error($api)) return Result::error($api);
			$url = $api->download_link ?? ''; $parts = wp_parse_url($url);
			if (!$parts || ($parts['scheme'] ?? '') !== 'https' || ($parts['host'] ?? '') !== 'downloads.wordpress.org') return Result::fail('catalog_download_invalid', 'Catalog did not return an official HTTPS package URL.');
			if (!is_wp_version_compatible($api->requires ?? '') || !is_php_version_compatible($api->requires_php ?? '')) return Result::fail('package_requirements', 'Package PHP/WordPress version requirement is not met.');
			$skin = new \Automatic_Upgrader_Skin(); $upgrader = 'theme' === $kind ? new \Theme_Upgrader($skin) : new \Plugin_Upgrader($skin);
			$result = $upgrader->install($url);
			if (is_wp_error($result)) return Result::error($result);
			if (!$result || is_wp_error($upgrader->result)) return Result::fail('package_install_failed', 'WordPress did not confirm package installation.');
			if ('theme' === $kind) { wp_clean_themes_cache(); $theme = wp_get_theme($slug); if (!$theme->exists()) return Result::fail('package_verify_failed', 'Installed theme was not found after upgrade.'); return Result::ok(['slug' => $slug, 'theme' => self::info($theme), 'activated' => false]); }
			wp_clean_plugins_cache(false); $plugin = $upgrader->plugin_info(); $all = get_plugins();
			if (!$plugin || !isset($all[$plugin])) return Result::fail('package_verify_failed', 'Installed plugin was not found after upgrade.');
			return Result::ok(['plugin' => $plugin, 'version' => $all[$plugin]['Version'], 'activated' => false]);
		});
	}
	public static function update(array $input): array {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$file = $input['plugin']; $plugins = get_plugins();
		if (!isset($plugins[$file])) return Result::fail('plugin_not_found', 'Installed plugin not found.');
		if (dirname($file) === basename(rtrim(F3_MCP_FILES_DIR, '/'))) return Result::fail('self_update_requires_admin', 'Update the active MCP server through the WordPress administration screen.');
		return self::upgrade(static function () use ($file, $plugins) {
			wp_update_plugins(); $offers = get_site_transient('update_plugins'); $offer = $offers->response[$file] ?? null;
			if (!$offer) return Result::ok(['plugin' => $file, 'changed' => false, 'version' => $plugins[$file]['Version']], 'No update offered by WordPress.');
			if (empty($offer->package)) return Result::fail('plugin_update_unavailable', 'Update offer has no package URL.');
			$upgrader = new \Plugin_Upgrader(new \Automatic_Upgrader_Skin()); $result = $upgrader->upgrade($file);
			if (is_wp_error($result)) return Result::error($result);
			wp_clean_plugins_cache(false); $actual = get_plugins();
			if (!$result || !isset($actual[$file]) || version_compare($actual[$file]['Version'], $offer->new_version, '<')) return Result::fail('plugin_update_failed', 'Installed version does not match the WordPress update offer.');
			return Result::ok(['plugin' => $file, 'changed' => $actual[$file]['Version'] !== $plugins[$file]['Version'], 'old_version' => $plugins[$file]['Version'], 'version' => $actual[$file]['Version']]);
		});
	}
}
