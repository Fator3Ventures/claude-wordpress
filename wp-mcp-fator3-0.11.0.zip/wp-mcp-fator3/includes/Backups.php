<?php
/** Protected backup envelopes; existing .json/.bak backups remain readable. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Backups {
	public static function metadata(string $id, bool $with_content = true) {
		if (!preg_match('/^(?:db)?[a-f0-9]{16,64}$/iD', $id)) return new \WP_Error('invalid_backup_id', 'Invalid backup identifier.');
		$stored = StateStore::get($with_content ? 'backups' : 'backup-index', $id);
		if (!$stored && !$with_content) $stored = StateStore::get('backups', $id);
		if (!$stored) {
			$path = WP_CONTENT_DIR . '/f3-mcp-backups/' . $id . '.json';
			if (!is_file($path)) return new \WP_Error('backup_not_found', 'Backup not found.');
			$stored = json_decode((string)file_get_contents($path), true);
			if (!is_array($stored)) return new \WP_Error('backup_corrupt', 'Invalid backup metadata.');
			$stored['legacy'] = true;
			$stored['kind'] = isset($stored['rows']) ? 'database' : 'file';
		}
		if (($stored['id'] ?? '') !== $id) return new \WP_Error('backup_corrupt', 'Backup identity mismatch.');
		return $stored;
	}
	private static function persist(string $id, array $payload): void {
		$result = Locks::run(['backups:' . get_current_blog_id() => LOCK_EX], static function () use($id, $payload) {
			StateStore::put('backups', $id, $payload);
			unset($payload['rows'], $payload['sql'], $payload['content_base64']);
			$payload['stored_bytes'] = filesize(StateStore::path('backups', $id));
			StateStore::put('backup-index', $id, $payload);
			return Result::ok();
		});
		if (!$result['success']) throw new \RuntimeException($result['message']);
	}
	public static function create_file(string $path) {
		$size = filesize($path);
		$max = (int)apply_filters('f3_mcp_backup_max_bytes', 64 * 1024 * 1024);
		if (false === $size || $size > $max) return new \WP_Error('backup_size_limit', 'File exceeds the configured backup size limit; no change made.');
		$memory_limit = wp_convert_hr_to_bytes(ini_get('memory_limit'));
		if ($memory_limit > 0 && $size * 6 + memory_get_usage(true) > $memory_limit) return new \WP_Error('backup_memory_limit', 'Backup cannot fit in the PHP memory limit. No file change was made.');
		$content = @file_get_contents($path);
		if (false === $content || strlen($content) !== $size) return new \WP_Error('backup_read_failed', 'Incomplete backup read.');
		$id = bin2hex(random_bytes(12));
		try {
			self::persist($id, ['id' => $id, 'kind' => 'file', 'path' => PathGuard::to_relative($path), 'time' => gmdate('c'), 'user' => get_current_user_id(), 'bytes' => strlen($content), 'sha256' => hash('sha256', $content), 'content_base64' => base64_encode($content)]);
		} catch (\Throwable $e) { return new \WP_Error('backup_write_failed', $e->getMessage()); }
		return $id;
	}
	public static function create_rows(string $table, string $sql, array $rows) {
		$id = 'db' . bin2hex(random_bytes(11));
		try {
			self::persist($id, ['id' => $id, 'kind' => 'database', 'table' => $table, 'sql' => $sql, 'rows' => DatabaseWriter::transport_rows($rows), 'binary_encoding' => 'Cells with encoding=base64 contain original binary bytes', 'time' => gmdate('c'), 'user' => get_current_user_id(), 'count' => count($rows)]);
		} catch (\Throwable $e) { return new \WP_Error('backup_write_failed', $e->getMessage()); }
		return $id;
	}
	public static function restore(array $input): array {
		$meta = self::metadata((string)($input['backup_id'] ?? ''));
		if (is_wp_error($meta)) return Result::error($meta);
		if ('file' !== $meta['kind']) return Result::fail('backup_type_mismatch', 'Use a file backup with files/restore.');
		$path = PathGuard::resolve((string)$meta['path'], true);
		if (is_wp_error($path)) return Result::error($path);
		$valid = PathGuard::check_extension($path);
		if (is_wp_error($valid)) return Result::error($valid);
		$content = !empty($meta['legacy']) ? @file_get_contents(WP_CONTENT_DIR . '/f3-mcp-backups/' . $meta['id'] . '.bak') : base64_decode($meta['content_base64'] ?? '', true);
		if (false === $content || !hash_equals($meta['sha256'] ?? '', hash('sha256', $content))) return Result::fail('backup_corrupt', 'Backup content hash mismatch.');
		if ('php' === strtolower(pathinfo($path, PATHINFO_EXTENSION))) {
			$check = PathGuard::check_php_syntax($content);
			if (is_wp_error($check)) return Result::error($check);
		}
		$before = is_file($path) ? self::create_file($path) : '';
		if (is_wp_error($before)) return Result::error($before);
		$result = Files::atomic_write($path, $content);
		if (is_wp_error($result)) return Result::error($result);
		PathGuard::audit('restore', PathGuard::to_relative($path), ['backup_id' => $meta['id']]);
		return Result::ok(['path' => PathGuard::to_relative($path), 'bytes' => strlen($content), 'backup_id' => $before, 'sha256' => hash('sha256', $content)], 'File restored.');
	}
	public static function listing(array $input): array {
		$items = [];
		foreach (glob(StateStore::directory('backup-index') . '/*.php') ?: [] as $file) {
			$raw = @file_get_contents($file);
			if (false === $raw || !str_starts_with($raw, StateStore::HEADER)) continue;
			$item = json_decode(substr($raw, strlen(StateStore::HEADER)), true);
			if (is_array($item) && (int)($item['site_id'] ?? 1) === get_current_blog_id()) { unset($item['content_base64'], $item['rows'], $item['sql']); $items[] = $item; }
		}
		foreach (glob(WP_CONTENT_DIR . '/f3-mcp-backups/*.json') ?: [] as $file) {
			$item = json_decode((string)@file_get_contents($file), true);
			if (is_array($item) && !empty($item['id'])) { $item['legacy'] = true; $item['kind'] = isset($item['rows']) ? 'database' : 'file'; unset($item['rows'], $item['sql']); $items[] = $item; }
		}
		if (!empty($input['path'])) { $wanted = PathGuard::lock_path($input['path']); if (is_wp_error($wanted)) return Result::error($wanted); $wanted = PathGuard::to_relative($wanted); $items = array_values(array_filter($items, static fn($v) => ($v['path'] ?? '') === $wanted)); }
		usort($items, static fn($a, $b) => strcmp(($b['time'] ?? '') . $b['id'], ($a['time'] ?? '') . $a['id']));
		$offset = max(0, (int)($input['offset'] ?? 0)); $limit = min(200, max(1, (int)($input['per_page'] ?? 30)));
		return Result::ok(['backups' => array_slice($items, $offset, $limit), 'total' => count($items), 'has_more' => count($items) > $offset + $limit, 'next_offset' => count($items) > $offset + $limit ? $offset + $limit : null], 'Backups listed.');
	}
	public static function export(array $input): array {
		$meta = self::metadata($input['backup_id']);
		if (is_wp_error($meta)) return Result::error($meta);
		if ('file' === $meta['kind']) { $scope = PathGuard::lock_path((string)$meta['path']); if (is_wp_error($scope)) return Result::error($scope); }
		if (!empty($meta['legacy']) && 'file' === $meta['kind']) $meta['content_base64'] = base64_encode((string)file_get_contents(WP_CONTENT_DIR . '/f3-mcp-backups/' . $meta['id'] . '.bak'));
		$bytes = json_encode($meta, JSON_THROW_ON_ERROR);
		if (4 * (int)ceil(strlen($bytes) / 3) > PathGuard::max_bytes()) return Result::fail('export_size_limit', 'Backup is too large for one MCP response.');
		return Result::ok(['filename' => $meta['id'] . '.json', 'content_base64' => base64_encode($bytes), 'sha256' => hash('sha256', $bytes)], 'Backup exported.');
	}
	private static function stored_bytes(string $file): int { $row = json_decode(substr((string)file_get_contents($file), strlen(StateStore::HEADER)), true); return (int)($row['stored_bytes'] ?? filesize($file)); }
	private static function remove_snapshot(string $file): bool {
		$row = json_decode(substr((string)file_get_contents($file), strlen(StateStore::HEADER)), true);
		if (!is_array($row) || empty($row['id'])) return false;
		if (!StateStore::delete('backups', $row['id'])) return false;
		return @unlink($file);
	}
	private static function belongs_to_site(string $file): bool { $row = json_decode(substr((string)file_get_contents($file), strlen(StateStore::HEADER)), true); return is_array($row) && (int)($row['site_id'] ?? 1) === get_current_blog_id(); }
	public static function prune(array $input): array { return Locks::run(['backups:' . get_current_blog_id() => LOCK_EX], static fn() => self::prune_locked($input)); }
	private static function prune_locked(array $input): array {
		$days = max(1, (int)($input['older_than_days'] ?? 30));
		$dry = $input['dry_run'] ?? true;
		$selected = []; $bytes = 0;
		foreach (glob(StateStore::directory('backup-index') . '/*.php') ?: [] as $file) {
			if (self::belongs_to_site($file) && filemtime($file) < time() - $days * DAY_IN_SECONDS) { $selected[] = $file; $bytes += self::stored_bytes($file); }
		}
		$max = max(0, (int)($input['max_total_bytes'] ?? 0));
		$all = array_values(array_filter(glob(StateStore::directory('backup-index') . '/*.php') ?: [], [self::class, 'belongs_to_site']));
		usort($all, static fn($a, $b) => filemtime($a) <=> filemtime($b));
		$total = array_sum(array_map([self::class, 'stored_bytes'], $all));
		if ($max > 0) foreach ($all as $file) {
			if ($total - $bytes <= $max) break;
			if (!in_array($file, $selected, true)) { $selected[] = $file; $bytes += self::stored_bytes($file); }
		}
		$removed = 0;
		if (!$dry) foreach ($selected as $file) { if (!self::remove_snapshot($file)) return Result::fail('backup_prune_failed', 'Could not remove a selected backup.', ['removed' => $removed]); ++$removed; }
		return Result::ok(['dry_run' => $dry, 'selected' => count($selected), 'bytes' => $bytes, 'removed' => $removed, 'legacy_preserved' => true], 'Retention evaluated.');
	}
}
