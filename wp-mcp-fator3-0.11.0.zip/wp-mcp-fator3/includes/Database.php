<?php
/**
 * Habilidades db/* — consulta e alteração do banco do WordPress.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class Database {

	/** Opção que liga/desliga especificamente a ESCRITA no banco. */
	public const OPTION_WRITES = 'f3_mcp_db_writes';

	/** Tabelas que costumam guardar dados pessoais de terceiros. */
	private const PII_HINTS = array( 'users', 'usermeta', 'comments', 'flamingo', 'cf7', 'contact', 'leads', 'orders', 'postmeta' );

	private static function gate(): ?array {
		if ( ! PathGuard::is_enabled() ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'O canal está fechado. Reabra em Ferramentas > MCP Fator3 no wp-admin.', 'wp-mcp-fator3' ),
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'Permissão insuficiente: é exigida a capacidade manage_options.', 'wp-mcp-fator3' ),
			);
		}

		return null;
	}

	private static function permission(): bool {
		return PathGuard::is_enabled() && current_user_can( 'manage_options' );
	}

	public static function writes_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_db_writes_enabled', (bool) get_option( self::OPTION_WRITES, true ) );
	}

	private static function fail( \WP_Error $e ): array {
		return Result::error($e);
	}

	/** Aviso quando o resultado provavelmente contém dados pessoais. */
	private static function pii_note( string $sql ): string {
		foreach ( self::PII_HINTS as $hint ) {
			if ( false !== stripos( $sql, $hint ) ) {
				return ' ' . esc_html__( 'Este resultado pode conter dados pessoais de terceiros — trate como tal e não o repasse adiante sem necessidade.', 'wp-mcp-fator3' );
			}
		}
		return '';
	}

	public static function register(): void {

		// =====================================================================
		// DB — Schema
		// =====================================================================
		wp_register_ability(
			'db/schema',
			array(
				'label'               => 'Database Schema',
				'description'         => 'Lista as tabelas do banco do WordPress com contagem de linhas, e opcionalmente as colunas de uma tabela. Params: table (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'table' => array(
							'type'        => 'string',
							'description' => 'Nome da tabela para detalhar as colunas. Vazio lista todas as tabelas.',
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'prefix'  => array( 'type' => 'string' ),
						'tables'  => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
						'columns' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					global $wpdb;
					$input = is_array( $input ) ? $input : array();

					if ( ! empty( $input['table'] ) ) {
						$table = preg_replace( '/[^A-Za-z0-9_]/', '', (string) $input['table'] );
						if ( '' === $table ) {
							return array( 'success' => false, 'message' => esc_html__( 'Nome de tabela inválido.', 'wp-mcp-fator3' ) );
						}

						$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
						if ( ! $exists ) {
							return array( 'success' => false, 'message' => esc_html__( 'Tabela não encontrada.', 'wp-mcp-fator3' ) );
						}

						// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nome saneado para [A-Za-z0-9_] e confirmado por SHOW TABLES.
						$columns = $wpdb->get_results( "DESCRIBE `{$table}`", ARRAY_A );

						return array(
							'success' => true,
							'message' => esc_html__( 'Colunas listadas.', 'wp-mcp-fator3' ),
							'prefix'  => $wpdb->prefix,
							'tables'  => array(),
							'columns' => is_array( $columns ) ? $columns : array(),
						);
					}

					$rows   = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );
					$tables = array();
					foreach ( (array) $rows as $row ) {
						$tables[] = array(
							'name'      => $row['Name'] ?? '',
							'rows'      => isset( $row['Rows'] ) ? (int) $row['Rows'] : null,
							'engine'    => $row['Engine'] ?? '',
							'data_size' => isset( $row['Data_length'] ) ? size_format( (int) $row['Data_length'] ) : null,
						);
					}

					return array(
						'success' => true,
						'message' => esc_html(
							sprintf(
								/* translators: %d: número de tabelas. */
								_n( '%d tabela.', '%d tabelas.', count( $tables ), 'wp-mcp-fator3' ),
								count( $tables )
							)
						),
						'prefix'  => $wpdb->prefix,
						'tables'  => $tables,
						'columns' => array(),
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
				),
			)
		);

		// =====================================================================
		// DB — Query (somente leitura)
		// =====================================================================
		wp_register_ability(
			'db/query',
			array(
				'label'               => 'Query Database (read-only)',
				'description'         => 'Executa uma consulta de LEITURA (SELECT/SHOW/DESCRIBE/EXPLAIN) no banco do WordPress. Um statement por chamada. Hash de senha nunca é devolvido. Params: sql (required), limit (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'sql'   => array(
							'type'        => 'string',
							'description' => 'Um único statement de leitura.',
						),
						'limit' => array(
							'type'        => 'integer',
							'default'     => 200,
							'minimum'     => 1,
							'maximum'     => 2000,
							'description' => 'Máximo de linhas. Teto aplicado ao LIMIT externo, inclusive se explícito.',
						),
					),
					'required'             => array( 'sql' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'sql'       => array( 'type' => 'string' ),
						'rows'      => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
						'row_count' => array( 'type' => 'integer' ),
						'redacted'  => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					global $wpdb;
					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['sql'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: sql', 'wp-mcp-fator3' ) );
					}

					$clean = SqlGuard::validate_select( (string) $input['sql'] );
					if ( is_wp_error( $clean ) ) {
						return self::fail( $clean );
					}

					$limit = isset( $input['limit'] )
						? min( SqlGuard::MAX_ROWS, max( 1, (int) $input['limit'] ) )
						: SqlGuard::DEFAULT_ROWS;

					$final = SqlGuard::enforce_limit( $clean, $limit );

					$suppress = $wpdb->suppress_errors( true );
					// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- statement validado por SqlGuard::validate_select(); é a função desta habilidade.
					$rows = $wpdb->get_results( $final, ARRAY_A );
					$error = $wpdb->last_error;
					$wpdb->suppress_errors( $suppress );

					if ( ! empty( $error ) ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: %s: erro do MySQL. */
									__( 'Erro do MySQL: %s', 'wp-mcp-fator3' ),
									$error
								)
							),
							'sql'     => $final,
						);
					}

					$rows = array_slice(is_array($rows) ? $rows : [], 0, $limit);
					if (strlen(serialize($rows)) > PathGuard::max_bytes()) return Result::fail('query_byte_limit', 'Result exceeds the response byte limit; select fewer columns or rows.');
					$rows = DatabaseWriter::transport_rows($rows);
					$safe   = SqlGuard::redact( $rows );
					$note   = self::pii_note( $final );

					PathGuard::audit( 'db:query', SqlGuard::verb($final), array( 'rows' => count( $safe['rows'] ) ) );

					return array(
						'success'   => true,
						'message'   => esc_html(
							sprintf(
								/* translators: %d: número de linhas. */
								_n( '%d linha.', '%d linhas.', count( $safe['rows'] ), 'wp-mcp-fator3' ),
								count( $safe['rows'] )
							)
						) . $note,
						'sql'       => $final,
						'rows'      => $safe['rows'],
						'row_count' => count( $safe['rows'] ),
						'redacted'  => $safe['redacted'],
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
				),
			)
		);

		// =====================================================================
		// DB — Execute (escrita, em duas fases)
		// =====================================================================
		wp_register_ability(
			'db/execute',
			array(
				'label'               => 'Execute Database Write (two-phase)',
				'description'         => 'Executa UPDATE, DELETE, INSERT ou REPLACE. Por padrão faz apenas a PRÉ-VISUALIZAÇÃO: mostra as linhas que seriam afetadas e devolve um confirm_token. Repita a chamada com o mesmo sql e o token para aplicar de verdade. Params: sql (required), confirm_token (opcional), limit_preview (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'sql'            => array(
							'type'        => 'string',
							'description' => 'Um único statement de escrita. UPDATE e DELETE exigem WHERE.',
						),
						'confirm_token'  => array(
							'type'        => 'string',
							'description' => 'Token devolvido pela pré-visualização. Sem ele, nada é gravado.',
						),
						'limit_preview'  => array(
							'type'        => 'integer',
							'default'     => 20,
							'minimum'     => 1,
							'maximum'     => 200,
							'description' => 'Quantas linhas afetadas mostrar na pré-visualização.',
						),
					),
					'required'             => array( 'sql' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'        => array( 'type' => 'boolean' ),
						'message'        => array( 'type' => 'string' ),
						'applied'        => array( 'type' => 'boolean' ),
						'affected_rows'  => array( 'type' => 'integer' ),
						'preview_rows'   => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
						'confirm_token'  => array( 'type' => 'string' ),
						'backup_id'      => array( 'type' => 'string' ),
						'warning'        => array( 'type' => 'string' ),
						'table'          => array( 'type' => 'string' ),
					),
				),
				'execute_callback' => static fn($input = []) => DatabaseWriter::execute(is_array($input) ? $input : []),
				'permission_callback' => function (): bool {
					return self::permission() && self::writes_enabled();
				},
				'meta'                => array(
					'annotations' => array( 'readonly' => false, 'destructive' => true, 'idempotent' => false ),
				),
			)
		);
	}

}
