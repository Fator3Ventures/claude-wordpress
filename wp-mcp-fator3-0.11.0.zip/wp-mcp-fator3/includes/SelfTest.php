<?php
/** Fixed, reversible checks for the 0.9.0 filesystem contract. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class SelfTest {
	private static function row( string $name, bool $ok, string $detail = '' ): array {
		return array( 'check' => $name, 'ok' => $ok, 'detail' => $detail );
	}

	public static function run(): array {
		if ( ! PathGuard::can_edit() || ! PathGuard::is_enabled() ) {
			return array( 'success' => false, 'passed' => 0, 'failed' => 1, 'checks' => array(), 'message' => 'Canal fechado ou permissão insuficiente.' );
		}
		$checks = array_merge( self::paths(), self::gates(), self::roundtrip(), self::check_sql_guard() );
		$failed = count( array_filter( $checks, static function ( $row ) { return ! $row['ok']; } ) );
		return array(
			'success' => 0 === $failed, 'passed' => count( $checks ) - $failed,
			'failed' => $failed, 'checks' => $checks,
			'message' => sprintf( '%d verificações, %d falhas. Valida sintaxe, backup, capacidade, kill-switch e confinamento configurado; o alcance padrão é o do usuário do PHP.', count( $checks ), $failed ),
		);
	}

	private static function paths(): array {
		$rows = array();
		$roots = PathGuard::roots();
		$sample = PathGuard::is_confined() ? ( $roots[0] ?? '' ) : ABSPATH;
		$resolved = PathGuard::resolve( $sample, false );
		$rows[] = self::row( 'absoluto_resolve', ! is_wp_error( $resolved ) && wp_normalize_path( realpath( $sample ) ?: '' ) === $resolved );
		foreach ( array( 'null_byte' => "x\0.php", 'null_byte_final' => "x.php\0", 'php_wrapper' => 'php://filter/resource=x', 'phar_wrapper' => 'phar://x/y', 'empty' => '' ) as $name => $value ) {
			$rows[] = self::row( 'nega:' . $name, is_wp_error( PathGuard::resolve( $value, false ) ) );
		}
		$theme = realpath( get_theme_root() );
		$clamp = static function () use ( $theme ) { return array( $theme ); };
		add_filter( 'f3_mcp_files_roots', $clamp, PHP_INT_MAX );
		try {
			$rows[] = self::row( 'clamp_aceita_raiz', ! is_wp_error( PathGuard::resolve( $theme, false ) ) );
			$rows[] = self::row( 'clamp_nega_fora', is_wp_error( PathGuard::resolve( ABSPATH, false ) ) );
		} finally {
			remove_filter( 'f3_mcp_files_roots', $clamp, PHP_INT_MAX );
		}
		$rows[] = self::row( 'confine_wp', ! defined( 'F3_MCP_FILES_CONFINE' ) || 'wp' !== F3_MCP_FILES_CONFINE || ( PathGuard::roots() === PathGuard::wp_roots() && in_array( 'wp-config.php', PathGuard::denied_basenames(), true ) ), defined( 'F3_MCP_FILES_CONFINE' ) ? (string) F3_MCP_FILES_CONFINE : 'não configurado; o harness testa a constante em processo separado' );
		$rows[] = self::row( 'detecta_php_quebrado', is_wp_error( PathGuard::check_php_syntax( "<?php function broken() {" ) ) );
		$rows[] = self::row( 'aceita_php_valido', true === PathGuard::check_php_syntax( "<?php function valid_probe() { return 1; }" ) );
		return $rows;
	}

	private static function gates(): array {
		$rows = array();
		$ability = wp_get_ability( 'files/read' );
		$rows[] = self::row( 'rota_e_permission_callback', null !== $ability );
		if ( ! $ability ) { return $rows; }
		$off = static function () { return false; };
		add_filter( 'f3_mcp_files_enabled', $off, PHP_INT_MAX );
		try {
			$permission = $ability->check_permissions( array( 'path' => ABSPATH ) );
			$gate = new \ReflectionMethod( Files::class, 'gate' );
			$gate->setAccessible( true );
			$rows[] = self::row( 'kill_switch_permission_e_gate', ( is_wp_error( $permission ) || ! $permission ) && null !== $gate->invoke( null ) );
		} finally {
			remove_filter( 'f3_mcp_files_enabled', $off, PHP_INT_MAX );
		}
		$user = get_current_user_id();
		try {
			wp_set_current_user( 0 );
			$permission = $ability->check_permissions( array( 'path' => ABSPATH ) );
			$rows[] = self::row( 'nega_sem_manage_options', is_wp_error( $permission ) || ! $permission );
		} finally {
			wp_set_current_user( $user );
		}
		return $rows;
	}

	/** Exercise actual write/delete/restore callbacks, never production files. */
	private static function roundtrip(): array {
		$roots = PathGuard::is_confined() ? PathGuard::roots() : array( ABSPATH );
		$root = null;
		foreach ( $roots as $candidate ) {
			if ( is_writable( $candidate ) ) { $root = $candidate; break; }
		}
		if ( null === $root ) { return array( self::row( 'backup_restore', false, 'Nenhuma raiz de teste gravável.' ) ); }
		$path = rtrim( $root, '/' ) . '/f3-selftest-' . bin2hex( random_bytes( 8 ) ) . '.txt';
		$result = Locks::files([$path], static fn() => self::roundtrip_path($path));
		return isset($result['success']) ? [self::row('backup_restore', false, $result['message'] ?? 'Lock unavailable.')] : $result;
	}

	private static function roundtrip_path(string $path): array {
		$ids = array();
		$rows = array();
		$call = static function ( string $name, array $args ) use ( &$ids ) {
			$ability = wp_get_ability( $name );
			$result = $ability ? $ability->execute( $args ) : null;
			if ( is_array( $result ) && ! empty( $result['backup_id'] ) ) { $ids[] = $result['backup_id']; }
			return $result;
		};
		try {
			$original = "original \\u00e3 \\/ \\path\n";
			$a = $call( 'files/write', array( 'path' => $path, 'content' => $original ) );
			$b = $call( 'files/write', array( 'path' => $path, 'content' => 'changed' ) );
			$restored = ! empty( $b['backup_id'] ) ? $call( 'files/restore', array( 'backup_id' => $b['backup_id'] ) ) : null;
			$rows[] = self::row( 'sobrescrita_backup_restore_bytes', is_array( $restored ) && ! empty( $restored['success'] ) && $original === @file_get_contents( $path ) );
			$deleted = $call( 'files/delete', array( 'path' => $path ) );
			clearstatcache( true, $path );
			$gone = ! file_exists( $path );
			$restored = ! empty( $deleted['backup_id'] ) ? $call( 'files/restore', array( 'backup_id' => $deleted['backup_id'] ) ) : null;
			$rows[] = self::row( 'exclusao_backup_restore_bytes', $gone && is_array( $restored ) && ! empty( $restored['success'] ) && $original === @file_get_contents( $path ) );
			$bad = $call( 'files/restore', array( 'backup_id' => '../../invalido' ) );
			$rows[] = self::row( 'nega_backup_id_corrompido', is_wp_error( $bad ) || ( is_array( $bad ) && empty( $bad['success'] ) ) );
			if ( ! empty( $b['backup_id'] ) ) {
				$meta = StateStore::get('backups', $b['backup_id']);
				$meta['content_base64'] = base64_encode('corrupted');
				StateStore::put('backups', $b['backup_id'], $meta);
				$bad = $call( 'files/restore', array( 'backup_id' => $b['backup_id'] ) );
				$rows[] = self::row( 'nega_backup_bytes_corrompidos', is_array( $bad ) && empty( $bad['success'] ) && $original === @file_get_contents( $path ) );
			}
		} catch ( \Throwable $e ) {
			$rows[] = self::row( 'backup_restore', false, $e->getMessage() );
		} finally {
			if ( is_file( $path ) ) { @unlink( $path ); }
			Locks::run(['backups:' . get_current_blog_id() => LOCK_EX], static function() use($ids) { foreach ($ids as $id) { StateStore::delete('backups', $id); StateStore::delete('backup-index', $id); } });
		}
		return $rows;
	}

	private static function check_sql_guard(): array {
		$rows = array();

		$deve_negar = array(
			'sql:stacked'        => array( 'select', 'SELECT 1; DROP TABLE wp_posts' ),
			'sql:update_em_read' => array( 'select', 'UPDATE wp_posts SET post_title = "x" WHERE ID=1' ),
			'sql:into_outfile'   => array( 'select', "SELECT 1 INTO OUTFILE '/tmp/x'" ),
			'sql:load_file'      => array( 'select', "SELECT LOAD_FILE('/etc/passwd')" ),
			'sql:drop'           => array( 'write', 'DROP TABLE wp_posts' ),
			'sql:truncate'       => array( 'write', 'TRUNCATE TABLE wp_posts' ),
			'sql:alter'          => array( 'write', 'ALTER TABLE wp_posts ADD COLUMN x INT' ),
			'sql:update_sem_where' => array( 'write', "UPDATE wp_posts SET post_content=''" ),
			'sql:delete_sem_where' => array( 'write', 'DELETE FROM wp_posts' ),
			'sql:select_em_write'  => array( 'write', 'SELECT * FROM wp_posts' ),
		);

		foreach ( $deve_negar as $name => $case ) {
			$result = ( 'select' === $case[0] )
				? SqlGuard::validate_select( $case[1] )
				: SqlGuard::validate_write( $case[1] );

			$rows[] = self::row(
				'nega:' . $name,
				is_wp_error( $result ),
				is_wp_error( $result ) ? $result->get_error_code() : 'PASSOU INDEVIDAMENTE'
			);
		}

		// O caminho legítimo precisa continuar funcionando.
		$rows[] = self::row(
			'aceita:sql_select_simples',
			! is_wp_error( SqlGuard::validate_select( 'SELECT ID FROM ' . $GLOBALS['wpdb']->posts . ' LIMIT 1' ) )
		);
		$rows[] = self::row(
			'aceita:sql_update_com_where',
			! is_wp_error( SqlGuard::validate_write( 'UPDATE ' . $GLOBALS['wpdb']->posts . " SET post_status='draft' WHERE ID=0" ) )
		);

		// O scanner respeita literais? É a base de tudo acima.
		$scan   = SqlGuard::scan( "SELECT 'a;b' FROM t" );
		$rows[] = self::row( 'sql:scanner_respeita_string', 1 === $scan['statements'], 'statements=' . $scan['statements'] );

		// A redação de senha funciona?
		$red    = SqlGuard::redact( array( array( 'user_pass' => 'hash-secreto' ) ) );
		$rows[] = self::row( 'sql:redige_hash_de_senha', '[redigido]' === $red['rows'][0]['user_pass'] );

		$rows[] = self::row(
			'sql:escrita_no_banco',
			true,
			Database::writes_enabled() ? 'LIGADA' : 'desligada'
		);

		return $rows;
	}

}
