<?php
/** Byte-preserving SQL scanner. Only a deliberately bounded DML subset is previewable. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SqlGuard {
	public const MAX_ROWS = 2000;
	public const DEFAULT_ROWS = 200;
	private const NEVER_RETURN = ['user_pass', 'user_activation_key'];
	public static function scan(string $sql): array {
		$out = ''; $statements = 0; $content = false; $error = '';
		$n = strlen($sql);
		for ($i = 0; $i < $n; $i++) {
			$c = $sql[$i]; $next = $sql[$i + 1] ?? '';
			if ("'" === $c || '"' === $c || '`' === $c) {
				$q = $c; $out .= $c; $content = true; $closed = false;
				while (++$i < $n) {
					$c = $sql[$i]; $out .= $c;
					if ('\\' === $c && '`' !== $q && $i + 1 < $n) { $out .= $sql[++$i]; continue; }
					if ($q === $c) { if (($sql[$i + 1] ?? '') === $q) { $out .= $sql[++$i]; continue; } $closed = true; break; }
				}
				if (!$closed) $error = 'Unterminated quoted SQL value.';
				continue;
			}
			if ('#' === $c || ('-' === $c && '-' === $next && ('' === ($sql[$i + 2] ?? '') || ord($sql[$i + 2]) <= 32))) {
				while ($i < $n && "\n" !== $sql[$i]) $i++;
				$out .= ' '; continue;
			}
			if ('/' === $c && '*' === $next) {
				if (in_array($sql[$i + 2] ?? '', ['!', '+'], true) || substr($sql, $i + 2, 2) === 'M!') $error = 'Executable comments and optimizer hints are not accepted.';
				$end = strpos($sql, '*/', $i + 2);
				if (false === $end) { $error = 'Unterminated SQL comment.'; break; }
				$i = $end + 1; $out .= ' '; continue;
			}
			if (';' === $c) { if ($content) $statements++; $content = false; $out .= ' '; continue; }
			if ('' !== trim($c)) $content = true;
			$out .= $c;
		}
		return ['sql' => trim($out), 'statements' => $statements + (int)$content, 'error' => $error];
	}
	/** Same byte positions as input; literals (and optionally nested SQL) become spaces. */
	public static function mask(string $sql, bool $top_only = false): string {
		$out = $sql; $n = strlen($sql); $depth = 0;
		for ($i = 0; $i < $n; $i++) {
			$c = $sql[$i];
			if ("'" === $c || '"' === $c || '`' === $c) {
				$q = $c; $start = $i;
				while (++$i < $n) {
					if ('\\' === $sql[$i] && '`' !== $q) { $i++; continue; }
					if ($q === $sql[$i]) { if (($sql[$i + 1] ?? '') === $q) { $i++; continue; } break; }
				}
				if ('`' !== $q || ($top_only && $depth > 0)) for ($j = $start; $j <= min($i, $n - 1); $j++) $out[$j] = ' ';
				continue;
			}
			if ('(' === $c) $depth++;
			if ($top_only && $depth > 0) $out[$i] = ' ';
			if (')' === $c) $depth--;
		}
		return $out;
	}
	public static function verb(string $sql): string { return preg_match('/^\s*([a-z]+)/i', $sql, $m) ? strtolower($m[1]) : ''; }
	private static function common(string $sql) {
		if (strlen($sql) > 65536 || str_contains($sql, "\0")) return new \WP_Error('f3_sql_invalid', 'SQL exceeds 64 KiB or contains a null byte.');
		$scan = self::scan($sql);
		if ($scan['error']) return new \WP_Error('f3_sql_syntax', $scan['error']);
		if (1 !== $scan['statements']) return new \WP_Error('f3_sql_multiple', 'Send exactly one SQL statement.');
		$mask = str_replace('`', '', self::mask($scan['sql']));
		if (preg_match('/\b(into\s+(outfile|dumpfile)|load_file\s*\(|load\s+data|sys_exec|mysql\s*\.\s*user|information_schema\s*\.\s*user_privileges)/i', $mask)) return new \WP_Error('f3_sql_forbidden_construct', 'This SQL construct is not allowed.');
		return $scan['sql'];
	}
	public static function validate_select(string $sql) {
		$clean = self::common($sql); if (is_wp_error($clean)) return $clean;
		if (!in_array(self::verb($clean), ['select', 'show', 'describe', 'desc', 'explain'], true)) return new \WP_Error('f3_sql_not_select', 'db/query requires a read statement.');
		$mask = self::mask($clean);
		foreach (self::NEVER_RETURN as $column) if (preg_match('/\b' . $column . '\b/i', $mask)) return new \WP_Error('f3_sql_sensitive_column', 'Sensitive credential columns cannot be queried.');
		if (preg_match('/\b(sleep|benchmark|get_lock|release_lock)\s*\(|\bfor\s+(update|share)\b|\block\s+in\s+share\b|\binto\s+@|:=/i', $mask)) return new \WP_Error('f3_sql_not_readonly', 'Read queries cannot acquire explicit locks, sleep or assign variables.');
		if ('explain' === self::verb($clean) && !preg_match('/^explain\s+(?:format\s*=\s*\w+\s+)?select\b/i', $mask)) return new \WP_Error('f3_sql_explain_unsupported', 'Use EXPLAIN SELECT (without ANALYZE).');
		return $clean;
	}
	public static function validate_write(string $sql) {
		$clean = self::common($sql); if (is_wp_error($clean)) return $clean;
		$verb = self::verb($clean);
		if (!in_array($verb, ['update', 'delete', 'insert', 'replace'], true)) return new \WP_Error('f3_sql_not_write', 'Only UPDATE, DELETE, INSERT and REPLACE are supported.');
		if (in_array($verb, ['update', 'delete'], true) && !preg_match('/\bwhere\b/i', self::mask($clean, true))) return new \WP_Error('f3_sql_no_where', 'UPDATE and DELETE require an explicit top-level WHERE.');
		return $clean;
	}
	/** Outer numeric LIMIT is clamped even if explicitly supplied; inner LIMIT never disables it. */
	public static function enforce_limit(string $sql, int $limit): string {
		if ('select' !== self::verb($sql)) return $sql;
		$limit = max(1, min(self::MAX_ROWS + 1, $limit));
		$mask = self::mask($sql, true);
		if (preg_match('/\blimit\s+(\d+)\s*(?:,\s*(\d+)|\boffset\s+(\d+))?\s*$/i', $mask, $m, PREG_OFFSET_CAPTURE)) {
			$offset = ''; $count = (int)$m[1][0];
			if (isset($m[2]) && '' !== $m[2][0]) { $offset = ' OFFSET ' . $m[1][0]; $count = (int)$m[2][0]; }
			elseif (isset($m[3]) && '' !== $m[3][0]) $offset = ' OFFSET ' . $m[3][0];
			return rtrim(substr($sql, 0, $m[0][1])) . ' LIMIT ' . min($limit, $count) . $offset;
		}
		return rtrim($sql, "; \r\n\t") . ' LIMIT ' . $limit;
	}
	public static function preimage(string $sql) {
		$verb = self::verb($sql); $mask = self::mask($sql, true);
		if (in_array($verb, ['update', 'delete'], true)) {
			$pattern = 'update' === $verb ? '/^update\s+(`?[a-zA-Z0-9_]+`?)\s+set\b/i' : '/^delete\s+from\s+(`?[a-zA-Z0-9_]+`?)\s+where\b/i';
			if (!preg_match($pattern, $mask, $m) || !preg_match('/\bwhere\b/i', $mask, $where, PREG_OFFSET_CAPTURE)) return new \WP_Error('f3_sql_unparsed', 'Only single-table UPDATE/DELETE without aliases or JOIN can be previewed.');
			if (preg_match('/\b(select|join|union)\b/i', self::mask($sql))) return new \WP_Error('f3_sql_complex', 'Subqueries and joins cannot be included in a write preview.');
			$table = trim($m[1], '`');
			return ['table' => $table, 'select' => 'SELECT * FROM `' . $table . '` ' . substr($sql, $where[0][1]), 'verb' => $verb];
		}
		if (!preg_match('/^(insert|replace)\s+into\s+`?([a-zA-Z0-9_]+)`?\s*\(([^)]+)\)\s*values\s*/i', $sql, $m)) return new \WP_Error('f3_sql_unparsed', 'INSERT/REPLACE require explicit columns and literal VALUES. INSERT SELECT, SET and ON DUPLICATE KEY UPDATE are not previewable.');
		$columns = array_map('trim', explode(',', $m[3]));
		foreach ($columns as &$column) { if (!preg_match('/^`?[a-zA-Z0-9_]+`?$/D', $column)) return new \WP_Error('f3_sql_columns', 'Invalid column list.'); $column = trim($column, '`'); } unset($column);
		if (count(array_unique($columns)) !== count($columns)) return new \WP_Error('f3_sql_columns', 'Duplicate columns.');
		$rest = trim(substr($sql, strlen($m[0]))); $rows = [];
		while ('' !== $rest) {
			if ('(' !== $rest[0]) return new \WP_Error('f3_sql_values', 'Use comma-separated literal VALUES tuples only.');
			$plain = self::mask($rest); $end = strpos($plain, ')');
			if (false === $end) return new \WP_Error('f3_sql_values', 'Unterminated VALUES tuple.');
			$tuple = substr($rest, 1, $end - 1); $parts = self::split_literals($tuple);
			if (count($parts) !== count($columns)) return new \WP_Error('f3_sql_values', 'VALUES length differs from the column list.');
			foreach ($parts as $literal) if (!preg_match('/^(?:NULL|[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\'(?:[^\'\\\\]|\\\\.|\'\')*\')$/isD', $literal)) return new \WP_Error('f3_sql_literal_required', 'VALUES only accepts single-quoted strings, numbers and NULL; expressions cannot be previewed reliably.');
			$rows[] = array_combine($columns, $parts);
			if (count($rows) > self::MAX_ROWS) return new \WP_Error('f3_sql_row_limit', 'Too many VALUES rows.');
			$rest = trim(substr($rest, $end + 1));
			if ('' !== $rest) { if (',' !== $rest[0]) return new \WP_Error('f3_sql_complex', 'ON DUPLICATE KEY UPDATE and other suffixes require a separate explicit UPDATE preview.'); $rest = ltrim(substr($rest, 1)); if ('' === $rest) return new \WP_Error('f3_sql_values', 'Trailing comma.'); }
		}
		if (!$rows) return new \WP_Error('f3_sql_values', 'VALUES required.');
		return ['table' => $m[2], 'select' => '', 'verb' => $verb, 'values' => $rows];
	}
	private static function split_literals(string $text): array {
		$mask = self::mask($text); $start = 0; $parts = [];
		for ($i = 0; $i < strlen($mask); $i++) if (',' === $mask[$i]) { $parts[] = trim(substr($text, $start, $i - $start)); $start = $i + 1; }
		$parts[] = trim(substr($text, $start)); return $parts;
	}
	public static function redact(array $rows): array {
		$redacted = [];
		foreach ($rows as &$row) foreach ($row as $col => &$value) if (in_array(strtolower((string)$col), self::NEVER_RETURN, true)) { $value = '[redigido]'; $redacted[] = (string)$col; } unset($row, $value);
		return ['rows' => $rows, 'redacted' => array_values(array_unique($redacted))];
	}
	public static function serialized_warning(string $sql, string $table): ?string {
		return preg_match('/(?:options|postmeta|usermeta|termmeta|commentmeta)$/i', $table) ? 'Raw SQL may corrupt serialized option/meta values. Prefer typed WordPress abilities. Backups cover target rows, not a full database.' : null;
	}
}
