<?php
/** Shared result and persistent state contracts. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Result {
	public static function ok(array $data = [], string $message = ''): array {
		return array_replace(['success' => true, 'message' => $message], $data);
	}
	public static function fail(string $code, string $message, array $data = []): array {
		return array_replace(['success' => false, 'error_code' => $code, 'message' => $message, 'retryable' => false, 'conflict' => false], $data);
	}
	public static function error(\WP_Error $error): array {
		$data = $error->get_error_data();
		return array_replace(self::fail((string) $error->get_error_code(), $error->get_error_message()), is_array($data) ? $data : []);
	}
	public static function normalize($result): array {
		if (is_wp_error($result)) return self::error($result);
		if (!is_array($result)) return self::ok(['data' => $result]);
		if (isset($result['error']) && !isset($result['success'])) $result['success'] = false;
		if (false === ($result['success'] ?? true)) {
			$result += ['error_code' => 'operation_failed', 'retryable' => false, 'conflict' => false];
			$result['message'] = $result['message'] ?? (is_string($result['error'] ?? null) ? $result['error'] : 'Operation failed.');
		}
		return $result;
	}
	public static function any_schema(): array {
		return ['type' => ['string', 'number', 'boolean', 'array', 'object', 'null'], 'items' => ['type' => ['string', 'number', 'boolean', 'array', 'object', 'null']]];
	}
	public static function schema(): array {
		$properties = [];
		foreach (['message','error_code','operation_id','revision','current_revision','sha256','current_sha256','sha256_scope','backup_id','source_backup_id','path','source','plan_id','status','mode'] as $name) $properties[$name] = ['type' => 'string'];
		foreach (['success','conflict','retryable','replayed','changed','created','has_more','partial','preview','atomic'] as $name) $properties[$name] = ['type' => 'boolean'];
		foreach (['id','bytes','file_bytes','row_count','affected_rows','total','offset','retry_after_ms'] as $name) $properties[$name] = ['type' => 'integer'];
		foreach (['entries','matches','backups','preview_rows'] as $name) $properties[$name] = ['type' => 'array', 'items' => ['type' => 'object']];
		$properties['next_cursor'] = ['type' => ['string','null']]; $properties['next_offset'] = ['type' => ['integer','null']];
		$properties['plan'] = ['type' => 'object']; $properties['applied'] = ['type' => ['boolean','null']];
		return ['type' => 'object', 'properties' => $properties];
	}
}

final class StateStore {
	public const HEADER = "<?php exit; ?>\n";
	public static function directory(string $bucket = ''): string {
		$base = defined('F3_MCP_PRIVATE_DIR') ? (string) F3_MCP_PRIVATE_DIR : WP_CONTENT_DIR . '/f3-mcp-private';
		$base = rtrim(wp_normalize_path($base), '/');
		if (!str_starts_with($base, '/') && !preg_match('~^[A-Za-z]:/~', $base)) throw new \RuntimeException('F3_MCP_PRIVATE_DIR must be an absolute path.');
		if (!is_dir($base) && !@mkdir($base, 0700, true) && !is_dir($base)) throw new \RuntimeException('Cannot create MCP private storage.');
		if (is_link($base)) throw new \RuntimeException('Private storage must not be a symbolic link.');
		if (!is_file($base . '/index.php')) @file_put_contents($base . '/index.php', self::HEADER);
		if (!is_file($base . '/.htaccess')) @file_put_contents($base . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
		$dir = $base . ('' === $bucket ? '' : '/' . $bucket);
		if (!is_dir($dir) && !@mkdir($dir, 0700) && !is_dir($dir)) throw new \RuntimeException('Cannot create MCP state directory.');
		if (is_link($dir)) throw new \RuntimeException('State directory must not be a symbolic link.');
		return $dir;
	}
	public static function path(string $bucket, string $key): string {
		return self::directory($bucket) . '/' . hash('sha256', get_current_blog_id() . '|' . $key) . '.php';
	}
	public static function get(string $bucket, string $key): ?array {
		$path = self::path($bucket, $key);
		if (!is_file($path)) return null;
		$raw = @file_get_contents($path);
		if (false === $raw || !str_starts_with($raw, self::HEADER)) throw new \RuntimeException('Invalid MCP state file.');
		$value = json_decode(substr($raw, strlen(self::HEADER)), true, 512, JSON_THROW_ON_ERROR);
		if (!is_array($value)) throw new \RuntimeException('Invalid MCP state payload.');
		return $value;
	}
	public static function put(string $bucket, string $key, array $value): void {
		$value['site_id'] = get_current_blog_id();
		self::write(self::path($bucket, $key), self::HEADER . json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE));
	}
	public static function write(string $path, string $bytes): void {
		$temp = $path . '.' . bin2hex(random_bytes(8)) . '.php';
		$handle = @fopen($temp, 'xb');
		if (!$handle) throw new \RuntimeException('Cannot create state temporary file.');
		try {
			@chmod($temp, 0600);
			$offset = 0;
			while ($offset < strlen($bytes)) {
				$n = fwrite($handle, substr($bytes, $offset, 65536));
				if (false === $n || 0 === $n) throw new \RuntimeException('Incomplete state write.');
				$offset += $n;
			}
			if (!fflush($handle)) throw new \RuntimeException('Cannot flush state file.');
		} catch (\Throwable $e) { @unlink($temp); throw $e; }
		finally { fclose($handle); }
		if (!@rename($temp, $path)) { @unlink($temp); throw new \RuntimeException('Cannot commit state file.'); }
	}
	public static function delete(string $bucket, string $key): bool {
		$path = self::path($bucket, $key);
		return !file_exists($path) || @unlink($path);
	}
}
