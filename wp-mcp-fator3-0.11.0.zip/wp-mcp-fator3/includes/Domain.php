<?php
/** Shared domain contracts; native WordPress calls remain the authority. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Deletion {
	public static function media(array $input): array {
		$id = (int)($input['id'] ?? 0); $post = get_post($id);
		if (!$post || 'attachment' !== $post->post_type) return Result::fail('not_found', 'Attachment not found.');
		if (!current_user_can('delete_post', $id)) return Result::fail('permission_denied', 'Cannot delete this attachment.');
		$force = $input['force'] ?? true;
		if (!is_bool($force)) return Result::fail('invalid_force', 'force must be a boolean.');
		if (!$force) {
			if (!defined('MEDIA_TRASH') || !MEDIA_TRASH) return Result::fail('media_trash_disabled', 'Media trash is disabled; attachment was not permanently deleted. force=true is required.');
			return self::run($input, 'attachment');
		}
		$result = wp_delete_attachment($id, true); clean_post_cache($id);
		if (!$result || is_wp_error($result) || get_post($id)) return Result::fail('delete_not_confirmed', 'Permanent attachment deletion was not confirmed.');
		return Result::ok(['id' => $id, 'deleted' => true, 'changed' => true], 'Attachment permanently deleted.');
	}
	public static function run(array $input, string $kind = 'post'): array {
		$id = (int)($input['id'] ?? 0);
		if (isset($input['force']) && !is_bool($input['force'])) return Result::fail('invalid_force', 'force must be a boolean.');
		$force = $input['force'] ?? false;
		$comment = 'comment' === $kind;
		$item = $comment ? get_comment($id) : get_post($id);
		if (!$item || ('page' === $kind && 'page' !== $item->post_type)) return Result::fail('not_found', ucfirst($kind) . ' not found.');
		if (!current_user_can($comment ? 'edit_comment' : 'delete_post', $id)) return Result::fail('permission_denied', 'Permission denied for this item.');
		$status = $comment ? $item->comment_approved : $item->post_status;
		if (!$force && 'trash' === $status) return Result::ok(['id' => $id, 'changed' => false, 'status' => 'trash', 'deleted' => false], 'Already in trash; no changes made.');
		if (!$force && (!defined('EMPTY_TRASH_DAYS') || !EMPTY_TRASH_DAYS)) return Result::fail('trash_disabled', 'Trash is disabled. Permanent deletion requires force=true.', ['id' => $id, 'deleted' => false]);
		$result = $comment ? ($force ? wp_delete_comment($id, true) : wp_trash_comment($id)) : ($force ? wp_delete_post($id, true) : wp_trash_post($id));
		if ($comment) clean_comment_cache($id); else clean_post_cache($id);
		$remaining = $comment ? get_comment($id) : get_post($id);
		$actual = $remaining ? ($comment ? $remaining->comment_approved : $remaining->post_status) : 'deleted';
		if (!$result || is_wp_error($result) || ($force ? (bool)$remaining : (!$remaining || 'trash' !== $actual))) return Result::fail('delete_not_confirmed', 'The requested deletion/trash state was not confirmed.', ['id' => $id, 'status' => (string)$actual]);
		return Result::ok(['id' => $id, 'changed' => true, 'status' => (string)$actual, 'deleted' => $force], $force ? 'Permanently deleted.' : 'Moved to trash.');
	}
}

final class VerifiedOptions {
	public static function update(string $name, array $input): array {
		$missing = new \stdClass();
		$old = get_option($name, $missing);
		$exists = $old !== $missing;
		$key = $input['key'] ?? null;
		if (null !== $key && $exists && !is_array($old)) return Result::fail('option_type_conflict', 'key requires an array option. Existing scalar was not replaced.', ['conflict' => true, 'name' => $name]);
		$desired = $input['value'];
		if (null !== $key) { $desired = $exists ? $old : []; $desired[$key] = $input['value']; }
		// Observe the sanitized value in the SAME update, without invoking user filters twice.
		$sanitized = $desired;
		$observe = static function ($value) use (&$sanitized) { $sanitized = $value; return $value; };
		add_filter('sanitize_option_' . $name, $observe, PHP_INT_MAX);
		try { $written = update_option($name, $desired); }
		finally { remove_filter('sanitize_option_' . $name, $observe, PHP_INT_MAX); }
		// Query storage directly: option filters and caches must not fabricate persistence.
		global $wpdb;
		$row = $wpdb->get_row($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name), ARRAY_A);
		if (!$row || $wpdb->last_error) return Result::fail('option_write_failed', 'Persisted option could not be verified.', ['name' => $name]);
		$actual = maybe_unserialize($row['option_value']);
		$equal = static fn($a, $b): bool => (string)maybe_serialize($a) === (string)maybe_serialize($b);
		$changed = !$exists || !$equal($old, $actual);
		$data = ['name' => $name, 'changed' => $changed, 'old_value' => null !== $key ? ($exists ? ($old[$key] ?? null) : null) : ($exists ? $old : null), 'new_value' => null !== $key && is_array($actual) ? ($actual[$key] ?? null) : $actual, 'requested_value' => $input['value'], 'normalized' => !$equal($desired, $actual)];
		if (null !== $key) $data['key'] = $key;
		if (!$written && !$equal($actual, $sanitized)) return Result::fail('option_write_rejected', 'The requested value was not persisted. A filter veto or storage failure may have prevented the update.', $data);
		return Result::ok($data, $changed ? 'Option updated and verified.' : 'Option already has the effective value.');
	}
}

final class Registry {
	public static function add(string $name, string $description, array $properties, array $required, callable $callback, $permission = 'manage_options', bool $readonly = true): void {
		wp_register_ability($name, ['label' => ucwords(str_replace(['/', '-'], ' ', $name)), 'description' => $description, 'category' => 'site',
			'input_schema' => ['type' => 'object', 'properties' => $properties, 'required' => $required, 'additionalProperties' => false],
			'output_schema' => Result::schema(), 'execute_callback' => $callback,
			'permission_callback' => is_callable($permission) ? $permission : static fn() => current_user_can($permission),
			'meta' => ['mcp' => ['public' => true, 'type' => 'tool'], 'fator3' => ['owned' => true], 'annotations' => ['readonly' => $readonly, 'destructive' => !$readonly, 'idempotent' => $readonly]]]);
	}
	public static function string(string $description = ''): array { return ['type' => 'string', 'description' => $description]; }
	public static function integer(int $min = 0, int $max = PHP_INT_MAX): array { return ['type' => 'integer', 'minimum' => $min, 'maximum' => $max]; }
	public static function boolean(bool $default = false): array { return ['type' => 'boolean', 'default' => $default]; }
}
