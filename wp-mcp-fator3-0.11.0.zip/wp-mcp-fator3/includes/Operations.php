<?php
/** Persistent, bounded deployment plans. No distributed transaction is promised. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Operations {
	private const ALLOWED = ['files/write','files/patch','files/delete','files/fetch','files/restore','files/mkdir','files/move','files/copy','content/create-post','content/create-page','content/update-post','content/update-page','content/patch-post','content/patch-page','content/upsert','content/untrash','content/restore-revision','content/edit-block','options/update','themes/install','themes/activate','plugins/install','plugins/update','plugins/activate','plugins/deactivate'];
	public static function register(): void {
		$step = ['type' => 'object', 'properties' => ['id' => ['type' => 'string', 'pattern' => '^[a-zA-Z0-9_-]{1,64}$'], 'ability' => ['type' => 'string', 'enum' => self::ALLOWED], 'parameters' => ['type' => 'object'], 'depends_on' => ['type' => 'array', 'items' => Registry::string(), 'maxItems' => 50]], 'required' => ['id','ability','parameters'], 'additionalProperties' => false];
		Registry::add('operations/plan', 'Validate and store an ordered deployment plan without executing steps. References use {"$ref":"step_id.field.subfield"} and require an earlier dependency. Plans expire after 24h before starting. Compensation is best effort and limited to explicitly reversible results.', ['steps' => ['type' => 'array', 'items' => $step, 'minItems' => 1, 'maxItems' => 50], 'on_failure' => ['type' => 'string', 'enum' => ['stop','compensate'], 'default' => 'stop']], ['steps'], [self::class, 'plan'], 'edit_posts', false);
		Registry::add('operations/apply', 'Execute up to max_steps of a saved plan, storing each result and reusing per-step idempotency keys. Resume the same plan ID after a partial response. An uncertain step is never blindly repeated.', ['plan_id' => Registry::string(), 'max_steps' => Registry::integer(1, 20)], ['plan_id'], [self::class, 'apply'], 'edit_posts', false);
		Registry::add('operations/status', 'Read a plan and step results owned by the authenticated user. A plan is not a global atomic transaction.', ['plan_id' => Registry::string()], ['plan_id'], [self::class, 'status'], 'edit_posts');
	}
	private static function references($value, array $allowed): bool {
		if (!is_array($value)) return false;
		$found = false;
		if (isset($value['$ref'])) {
			if (count($value) !== 1 || !is_string($value['$ref']) || !preg_match('/^([a-zA-Z0-9_-]+)\.([a-zA-Z0-9_.-]+)$/D', $value['$ref'], $m) || !in_array($m[1], $allowed, true)) throw new \RuntimeException('A reference must name an earlier explicit dependency and a result field.');
			return true;
		}
		foreach ($value as $child) $found = self::references($child, $allowed) || $found;
		return $found;
	}
	private static function resolve($value, array $results) {
		if (!is_array($value)) return $value;
		if (isset($value['$ref'])) {
			$parts = explode('.', $value['$ref']); $id = array_shift($parts); $data = $results[$id] ?? null;
			foreach ($parts as $part) { if (!is_array($data) || !array_key_exists($part, $data)) throw new \RuntimeException('Reference not found: ' . $value['$ref']); $data = $data[$part]; }
			return $data;
		}
		foreach ($value as &$child) $child = self::resolve($child, $results); unset($child); return $value;
	}
	public static function plan(array $input): array {
		if (strlen(serialize($input)) > 4194304) return Result::fail('plan_size_limit', 'Plan exceeds 4 MiB.');
		$seen = []; $steps = [];
		try { foreach ($input['steps'] as $step) {
			if (isset($seen[$step['id']])) return Result::fail('plan_duplicate_id', 'Step IDs must be unique.');
			$deps = $step['depends_on'] ?? [];
			foreach ($deps as $dep) if (!isset($seen[$dep])) return Result::fail('plan_dependency_invalid', 'Dependencies must occur before their dependent step.');
			if (!in_array($step['ability'], self::ALLOWED, true)) return Result::fail('plan_ability_forbidden', 'Ability is not supported in resumable plans.');
			$ability = wp_get_ability($step['ability']); if (!$ability) return Result::fail('ability_not_found', $step['ability']);
			$meta = $ability->get_meta(); if (empty($meta['mcp']['public'])) return Result::fail('ability_not_public', 'The requested ability is not publicly exposed.');
			$refs = self::references($step['parameters'], $deps);
			if (!$refs) { $valid = rest_validate_value_from_schema($step['parameters'], $ability->get_input_schema(), 'parameters'); if (is_wp_error($valid)) return Result::error($valid); $permission = $ability->check_permissions($step['parameters']); if (is_wp_error($permission) || !$permission) return Result::fail('permission_denied', 'Permission denied for plan step: ' . $step['id']); }
			unset($step['parameters']['idempotency_key']);
			$steps[] = $step + ['depends_on' => $deps, 'status' => 'pending', 'schema_hash' => hash('sha256', serialize($ability->get_input_schema())), 'validation' => $refs ? 'deferred_until_references_resolve' : 'validated']; $seen[$step['id']] = true;
		} } catch (\Throwable $e) { return Result::fail('plan_reference_invalid', $e->getMessage()); }
		$id = bin2hex(random_bytes(16));
		$state = ['plan_id' => $id, 'owner' => get_current_user_id(), 'blog' => get_current_blog_id(), 'time' => time(), 'expires' => time() + DAY_IN_SECONDS, 'status' => 'pending', 'steps' => $steps, 'on_failure' => $input['on_failure'] ?? 'stop', 'version' => F3_MCP_FILES_VERSION];
		StateStore::put('plans', $id, $state);
		return Result::ok(['plan_id' => $id, 'status' => 'pending', 'steps' => count($steps), 'expires_at' => gmdate('c', $state['expires']), 'atomic' => false]);
	}
	private static function get(string $id) {
		if (!preg_match('/^[a-f0-9]{32}$/D', $id)) return new \WP_Error('plan_invalid', 'Invalid plan identifier.');
		$state = StateStore::get('plans', $id);
		if (!$state || $state['owner'] !== get_current_user_id() || $state['blog'] !== get_current_blog_id()) return new \WP_Error('plan_not_found', 'Plan not found for this user and site.');
		return $state;
	}
	public static function status(array $input): array {
		$state = self::get($input['plan_id']); if (is_wp_error($state)) return Result::error($state);
		foreach ($state['steps'] as &$step) unset($step['parameters'], $step['schema_hash']); unset($step);
		return Result::ok(['plan' => $state, 'atomic' => false]);
	}
	public static function apply(array $input): array {
		$id = $input['plan_id'];
		return Locks::run(['plan:' . get_current_blog_id() . ':' . $id => LOCK_EX], static function () use ($id, $input) {
			$state = self::get($id); if (is_wp_error($state)) return Result::error($state);
			if ('complete' === $state['status']) return self::status(['plan_id' => $id]);
			if ('compensated' === $state['status'] || 'compensation_incomplete' === $state['status']) return Result::fail('plan_closed', 'This failed plan has entered compensation and cannot be reapplied.', ['plan_id' => $id]);
			if ('pending' === $state['status'] && $state['expires'] < time()) return Result::fail('plan_expired', 'Plan expired before execution. Create a new plan.');
			$done = 0; $results = []; $start = microtime(true); $max = max(1, min(20, (int)($input['max_steps'] ?? 5)));
			$state['status'] = 'running'; StateStore::put('plans', $id, $state);
			foreach ($state['steps'] as $index => &$step) {
				if ('complete' === $step['status']) { $results[$step['id']] = $step['result']; continue; }
				if ($done >= $max || microtime(true) - $start > 15) break;
				if ('failed' === $step['status'] && empty($step['result']['retryable'])) { $state['status'] = 'failed'; break; }
				try {
					$ability = wp_get_ability($step['ability']);
					if (!$ability || !hash_equals($step['schema_hash'], hash('sha256', serialize($ability->get_input_schema())))) { $result = Result::fail('plan_schema_changed', 'Ability schema changed. Review and create a new plan.'); }
					else {
						$args = self::resolve($step['parameters'], $results); $args['idempotency_key'] = 'plan:' . $id . ':' . $step['id'];
						$step['status'] = 'running'; StateStore::put('plans', $id, $state);
						$result = Result::normalize($ability->execute($args));
					}
				} catch (\Throwable $e) { $result = Result::fail('plan_step_exception', $e->getMessage()); }
				$step['result'] = $result; $step['status'] = false === ($result['success'] ?? true) ? 'failed' : 'complete'; $done++;
				if ('failed' === $step['status']) { $state['status'] = 'failed'; StateStore::put('plans', $id, $state); break; }
				$results[$step['id']] = $result; StateStore::put('plans', $id, $state);
			} unset($step);
			if ('failed' === $state['status'] && 'compensate' === $state['on_failure']) $state = self::compensate($state);
			elseif ('failed' !== $state['status']) $state['status'] = count(array_filter($state['steps'], static fn($s) => 'complete' !== $s['status'])) ? 'paused' : 'complete';
			StateStore::put('plans', $id, $state);
			$response = self::status(['plan_id' => $id]);
			if (in_array($state['status'], ['failed','compensated','compensation_incomplete'], true)) return Result::fail('plan_step_failed', 'A plan step failed. Inspect per-step results before continuing.', ['plan' => $response['plan'], 'atomic' => false]);
			return $response;
		});
	}
	private static function compensate(array $state): array {
		$complete = true;
		foreach ($state['steps'] as $failed) if ('failed' === $failed['status'] && !in_array($failed['result']['error_code'] ?? '', ['file_not_found','file_conflict','content_conflict','resource_busy','permission_denied','ability_invalid_input','destination_exists','invalid_hash','plan_schema_changed'], true) && false !== ($failed['result']['applied'] ?? null)) $complete = false;
		for ($i = count($state['steps']) - 1; $i >= 0; $i--) {
			$step = &$state['steps'][$i]; if ('complete' !== $step['status']) continue;
			$r = $step['result']; $ability = ''; $args = [];
			if (!empty($r['backup_id']) && isset($r['sha256']) && in_array($step['ability'], ['files/write','files/patch','files/fetch','files/copy','files/restore'], true)) { $ability = 'files/restore'; $args = ['backup_id' => $r['backup_id'], 'expected_sha256' => $r['sha256']]; }
			elseif ('files/mkdir' === $step['ability'] && !empty($r['created'])) { $ability = 'files/delete'; $args = ['path' => $r['path'], 'empty_dir' => true]; }
			elseif (false === ($r['changed'] ?? true)) { $step['compensation'] = ['success' => true, 'changed' => false]; continue; }
			if (!$ability) { $step['compensation'] = Result::fail('compensation_unavailable', 'No complete inverse is recorded for this step.'); $complete = false; continue; }
			$args['idempotency_key'] = 'compensate:' . $state['plan_id'] . ':' . $step['id'];
			$step['compensation'] = Result::normalize(wp_get_ability($ability)->execute($args));
			if (false === ($step['compensation']['success'] ?? true)) $complete = false;
			StateStore::put('plans', $state['plan_id'], $state);
		} unset($step);
		$state['status'] = $complete ? 'compensated' : 'compensation_incomplete'; return $state;
	}
}
