<?php
/** Stable sidecar locks: locking the destination inode is unsafe across rename. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Locks {
	private static array $held = [];
	/** Acquire in deterministic order; never unlink a lock file. */
	public static function run(array $resources, callable $callback) {
		ksort($resources, SORT_STRING);
		$acquired = [];
		$deadline = microtime(true) + max(0, min(10, (float) apply_filters('f3_mcp_lock_timeout', 2.0)));
		try {
			foreach ($resources as $key => $mode) {
				if (isset(self::$held[$key])) {
					if (LOCK_EX === $mode && LOCK_SH === self::$held[$key]['mode']) return Result::fail('lock_upgrade_conflict', 'An enclosing operation holds a read lock.', ['conflict' => true]);
					continue;
				}
				$path = StateStore::directory('locks') . '/' . hash('sha256', $key) . '.php';
				if (is_link($path)) return Result::fail('lock_storage_invalid', 'Invalid lock file.');
				$handle = @fopen($path, 'c+b');
				if (!$handle) return Result::fail('lock_unavailable', 'Cannot open resource lock.');
				@chmod($path, 0600);
				while (!@flock($handle, $mode | LOCK_NB, $would_block)) {
					if (!$would_block) { fclose($handle); return Result::fail('lock_unavailable', 'The filesystem could not acquire an advisory lock.'); }
					if (microtime(true) >= $deadline) {
						fclose($handle);
						return array_replace(Result::fail('resource_busy', 'Another operation is changing this resource.'), ['conflict' => true, 'retryable' => true, 'retry_after_ms' => 250]);
					}
					usleep(10000);
				}
				if (0 === fstat($handle)['size'] && LOCK_EX === $mode) { fwrite($handle, StateStore::HEADER); fflush($handle); }
				self::$held[$key] = ['handle' => $handle, 'mode' => $mode];
				$acquired[] = $key;
			}
			return $callback();
		} finally {
			foreach (array_reverse($acquired) as $key) {
				flock(self::$held[$key]['handle'], LOCK_UN);
				fclose(self::$held[$key]['handle']);
				unset(self::$held[$key]);
			}
		}
	}
	/** Canonical destination, including missing parents; validates but creates nothing. */
	public static function path(string $requested) {
		return PathGuard::lock_path($requested);
	}
	/** Shared ancestors prevent parent rmdir while a child is being modified. */
	public static function files(array $paths, callable $callback, bool $write = true) {
		$resources = [];
		$canonical = [];
		foreach ($paths as $requested) {
			$path = $write ? self::path($requested) : PathGuard::resolve($requested, false);
			if (is_wp_error($path)) return Result::error($path);
			$canonical[$requested] = $path;
			$resources['file:' . $path] = $write ? LOCK_EX : ($resources['file:' . $path] ?? LOCK_SH);
			for ($parent = dirname($path); ; $parent = dirname($parent)) {
				$resources['file:' . $parent] = $resources['file:' . $parent] ?? LOCK_SH;
				if (dirname($parent) === $parent) break;
			}
		}
		return self::run($resources, static function () use ($canonical, $callback, $write) {
			clearstatcache(true);
			foreach ($canonical as $requested => $path) {
				$current = $write ? self::path($requested) : PathGuard::resolve($requested, false);
				if (is_wp_error($current)) return Result::error($current);
				if ($current !== $path) return array_replace(Result::fail('file_path_conflict', 'Path changed while waiting for its lock.'), ['conflict' => true]);
			}
			return $callback($canonical);
		});
	}
	/** Lock native package roots without imposing the optional files/* scope policy. */
	public static function trees(array $roots, callable $callback) {
		$resources = [];
		foreach ($roots as $root) {
			$path = realpath($root); if (false === $path) return Result::fail('lock_path_missing', 'Package root is missing.');
			$path = rtrim(wp_normalize_path($path), '/'); $resources['file:' . $path] = LOCK_EX;
			for ($p = dirname($path); ; $p = dirname($p)) { $resources['file:' . $p] = $resources['file:' . $p] ?? LOCK_SH; if (dirname($p) === $p) break; }
		}
		return self::run($resources, $callback);
	}
	public static function check_hash(string $path, array $input, string $field = 'expected_sha256'): ?array {
		if (!array_key_exists($field, $input) || '' === $input[$field]) return null;
		if (!is_string($input[$field]) || !preg_match('/^[a-f0-9]{64}$/iD', $input[$field])) return Result::fail('invalid_hash', $field . ' must be a SHA-256 hex string.');
		if (is_dir($path)) return Result::fail('hash_requires_file', 'SHA-256 requires a file.');
		$actual = file_exists($path) ? @hash_file('sha256', $path) : hash('sha256', '');
		if (false === $actual) return Result::fail('file_read_failed', 'Cannot hash the current file.');
		if (!hash_equals($actual, strtolower($input[$field]))) return array_replace(Result::fail('file_conflict', 'File changed. Read its current contents before retrying.'), ['conflict' => true, 'current_sha256' => $actual, 'sha256' => $actual]);
		return null;
	}
}
