<?php
/** Restore connection-local limits after each query/write. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DatabaseBudget {
	public static function run(string $sql, callable $callback) {
		global $wpdb;
		if (defined('DB_ENGINE') && 'sqlite' === DB_ENGINE) return $callback();
		$old = []; $suppress = $wpdb->suppress_errors(true);
		try {
			$mode = (string)$wpdb->get_var('SELECT @@SESSION.sql_mode');
			if ($wpdb->last_error) return Result::fail('sql_mode_unknown', 'Cannot verify SQL parsing mode.');
			if (str_contains($mode, 'ANSI_QUOTES') && str_contains($sql, '"') || str_contains($mode, 'NO_BACKSLASH_ESCAPES') && str_contains($sql, '\\')) return Result::fail('sql_mode_unsupported', 'SQL quoting does not match this connection mode.');
			$server = (string)$wpdb->get_var('SELECT VERSION()');
			$seconds = max(1, min(30, (int)apply_filters('f3_mcp_sql_timeout', 5)));
			$limits = stripos($server, 'mariadb') !== false ? ['max_statement_time' => $seconds] : ['max_execution_time' => $seconds * 1000];
			$limits['innodb_lock_wait_timeout'] = $seconds;
			foreach ($limits as $variable => $value) {
				$previous = $wpdb->get_var('SELECT @@SESSION.' . $variable);
				if ($wpdb->last_error || !is_numeric($previous)) return Result::fail('sql_budget_unavailable', 'This server does not expose the required query limit: ' . $variable);
				$old[$variable] = (float)$previous;
				if (false === $wpdb->query('SET SESSION ' . $variable . '=' . $value)) return Result::fail('sql_budget_unavailable', 'Cannot set the query execution limit.');
			}
			return $callback();
		} finally {
			foreach ($old as $variable => $value) $wpdb->query('SET SESSION ' . $variable . '=' . $value);
			$wpdb->suppress_errors($suppress);
		}
	}
}
