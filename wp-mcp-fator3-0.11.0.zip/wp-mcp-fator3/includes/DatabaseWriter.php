<?php
/** Consumable previews with transaction-time preimage verification. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DatabaseWriter {
	public static function execute(array $input): array {
		if (!PathGuard::is_enabled() || !Database::writes_enabled() || !current_user_can('manage_options')) return Result::fail('permission_denied', 'Database writes are disabled or unauthorized.');
		$clean = SqlGuard::validate_write((string)($input['sql'] ?? ''));
		if (is_wp_error($clean)) return Result::error($clean);
		$pre = SqlGuard::preimage($clean); if (is_wp_error($pre)) return Result::error($pre);
		return Locks::run(['database:' . get_current_blog_id() . ':' . $pre['table'] => LOCK_EX], static function () use ($clean, $pre, $input) {
			global $wpdb;
			$old_suppress = $wpdb->suppress_errors(true);
			$original_mode = null;
			try {
				if (!(defined('DB_ENGINE') && 'sqlite' === DB_ENGINE)) {
					$original_mode = (string)$wpdb->get_var('SELECT @@SESSION.sql_mode');
					if ($wpdb->last_error || false === $wpdb->query($wpdb->prepare('SET SESSION sql_mode=%s', $original_mode . ($original_mode ? ',' : '') . 'STRICT_ALL_TABLES'))) return Result::fail('sql_mode_unavailable', 'Cannot establish strict SQL mode for a verified write.');
				}
				$check = self::requirements($pre, $clean);
				if (is_wp_error($check)) return Result::error($check);
				if (empty($input['confirm_token'])) {
					$rows = self::rows($pre, false);
					if (is_wp_error($rows)) return Result::error($rows);
					$token = bin2hex(random_bytes(32));
					$state = ['status' => 'pending', 'user' => get_current_user_id(), 'blog' => get_current_blog_id(), 'sql_hash' => hash('sha256', $clean), 'preimage_hash' => self::digest($rows), 'expires' => time() + 600, 'time' => time(), 'count' => count($rows)];
					StateStore::put('db-confirmations', $token, $state);
					$shown = SqlGuard::redact(array_slice($rows, 0, max(1, min(200, (int)($input['limit_preview'] ?? 20)))));
					return Result::ok(['applied' => false, 'affected_rows' => count($rows), 'preview_rows' => self::transport_rows($shown['rows']), 'confirm_token' => $token, 'expires_at' => gmdate('c', $state['expires']), 'table' => $pre['table'], 'statement_type' => $pre['verb'], 'input_rows' => count($pre['values'] ?? []), 'warning' => (string)SqlGuard::serialized_warning($clean, $pre['table'])], 'Preview only. Confirmation is bound to these rows, this user and site for 10 minutes.');
				}
				$token = (string)$input['confirm_token'];
				if (!preg_match('/^[a-f0-9]{64}$/D', $token)) return Result::fail('confirmation_invalid', 'Invalid confirmation token.');
				return Locks::run(['confirmation:' . get_current_blog_id() . ':' . $token => LOCK_EX], static function () use ($pre, $clean, $token, $check) {
					$state = StateStore::get('db-confirmations', $token);
					if (!$state || $state['user'] !== get_current_user_id() || $state['blog'] !== get_current_blog_id() || !hash_equals($state['sql_hash'], hash('sha256', $clean))) return Result::fail('confirmation_invalid', 'Token does not belong to this SQL, user and site.');
					if ('complete' === $state['status']) return array_replace($state['result'], ['replayed' => true]);
					if ('pending' !== $state['status']) return Result::fail('confirmation_uncertain', 'The token was consumed but completion could not be recorded. Inspect the database and backup before creating another preview.', ['backup_id' => $state['backup_id'] ?? '', 'conflict' => true]);
					if ($state['expires'] < time()) return Result::fail('confirmation_expired', 'Preview expired. Request a new preview.', ['conflict' => true]);
					return self::apply($pre, $clean, $token, $state, $check);
				});
			} catch (\Throwable $e) { return Result::fail('database_operation_failed', $e->getMessage()); }
			finally { if (null !== $original_mode) $wpdb->query($wpdb->prepare('SET SESSION sql_mode=%s', $original_mode)); $wpdb->suppress_errors($old_suppress); }
		});
	}
	private static function requirements(array $pre, string $sql) {
		global $wpdb;
		$sqlite = defined('DB_ENGINE') && 'sqlite' === DB_ENGINE;
		if (!$sqlite) {
			$mode = (string)$wpdb->get_var('SELECT @@SESSION.sql_mode');
			if ($wpdb->last_error) return new \WP_Error('sql_mode_unknown', 'Could not verify SQL parsing mode.');
			if (isset($pre['values']) && !str_contains($mode, 'STRICT_TRANS_TABLES') && !str_contains($mode, 'STRICT_ALL_TABLES')) return new \WP_Error('sql_strict_mode_required', 'INSERT/REPLACE previews require strict SQL mode to prevent silent value coercion or truncation.');
			if (str_contains($mode, 'ANSI_QUOTES') && str_contains($sql, '"') || str_contains($mode, 'NO_BACKSLASH_ESCAPES') && str_contains($sql, '\\')) return new \WP_Error('sql_mode_unsupported', 'SQL uses quoting incompatible with the active SQL mode.');
			$engine = $wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s', $pre['table']));
			if ('innodb' !== strtolower((string)$engine)) return new \WP_Error('transaction_unavailable', 'Verified writes require an InnoDB table. Engine is absent or nontransactional.');
			$triggers = $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND EVENT_OBJECT_TABLE=%s', $pre['table']));
			if ($wpdb->last_error) return new \WP_Error('trigger_check_failed', 'Cannot verify table triggers.');
			if ((int)$triggers) return new \WP_Error('sql_trigger_unsupported', 'This table has triggers. Their changes cannot be represented by a target-row preview; use a typed application operation.');
			// A cascading relationship can alter records outside the advertised backup.
			$fk = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME=%s AND (DELETE_RULE IN ('CASCADE','SET NULL') OR UPDATE_RULE IN ('CASCADE','SET NULL'))", $pre['table']));
			if ($wpdb->last_error || (int)$fk) return new \WP_Error('sql_cascade_unsupported', 'Could not exclude cascading writes beyond the target-row backup.');
		}
		$mask = SqlGuard::mask($sql);
		if (preg_match('/\b(rand|uuid|now|sysdate|sleep|benchmark|load_file|get_lock|current_timestamp|current_date|current_time)\b|@/i', $mask)) return new \WP_Error('sql_nondeterministic', 'Writes must use deterministic expressions and cannot reference session variables.');
		return ['sqlite' => $sqlite];
	}
	private static function select(array $pre) {
		global $wpdb;
		if ('' !== $pre['select']) return $pre['select'];
		$table = $pre['table'];
		$indices = $wpdb->get_results("SHOW INDEX FROM `{$table}`", ARRAY_A);
		if ($wpdb->last_error) return new \WP_Error('sql_index_failed', $wpdb->last_error);
		$columns = $wpdb->get_results("DESCRIBE `{$table}`", ARRAY_A);
		if ($wpdb->last_error) return new \WP_Error('sql_columns_failed', $wpdb->last_error);
		$defs = []; foreach ($columns as $col) $defs[strtolower($col['Field'])] = $col;
		$unique = [];
		foreach ($indices as $idx) if (0 === (int)$idx['Non_unique']) {
			if (empty($idx['Column_name']) || !empty($idx['Sub_part'])) return new \WP_Error('sql_index_unsupported', 'Expression or prefix unique indexes cannot be previewed reliably.');
			$unique[$idx['Key_name']][(int)$idx['Seq_in_index']] = $idx['Column_name'];
		}
		$ors = [];
		foreach ($pre['values'] as $row) {
			$row = array_change_key_case($row, CASE_LOWER);
			foreach ($row as $column => $_) if (!isset($defs[$column])) return new \WP_Error('sql_column_unknown', 'Unknown insert column: ' . $column);
			foreach ($unique as $key) {
				$and = []; $skip = false;
				foreach ($key as $column) {
					$lower = strtolower($column); $def = $defs[$lower] ?? [];
					if (isset($row[$lower])) $value = $row[$lower];
					else {
						if (str_contains(strtolower($def['Extra'] ?? ''), 'auto_increment')) { $skip = true; break; }
						if (str_contains(strtolower($def['Extra'] ?? ''), 'generated') || !array_key_exists('Default', $def)) return new \WP_Error('sql_default_unsupported', 'An omitted unique key depends on an expression or unknown default.');
						$value = null === $def['Default'] ? 'NULL' : $wpdb->prepare('%s', $def['Default']);
					}
					if ('null' === strtolower($value)) { $skip = true; break; }
					$and[] = '`' . $column . '` = ' . $value;
				}
				if (!$skip && $and) $ors[] = '(' . implode(' AND ', $and) . ')';
			}
		}
		return 'SELECT * FROM `' . $table . '` WHERE ' . ($ors ? implode(' OR ', array_unique($ors)) : '1=0');
	}
	private static function rows(array $pre, bool $lock) {
		global $wpdb;
		$sql = self::select($pre); if (is_wp_error($sql)) return $sql;
		$sql = SqlGuard::enforce_limit($sql, SqlGuard::MAX_ROWS + 1);
		if ($lock) $sql .= ' FOR UPDATE';
		$rows = $wpdb->get_results($sql, ARRAY_A);
		if ($wpdb->last_error || !is_array($rows)) return new \WP_Error('sql_preview_failed', $wpdb->last_error ?: 'Could not read preview rows.');
		if (count($rows) > SqlGuard::MAX_ROWS || strlen(serialize($rows)) > 16777216) return new \WP_Error('sql_preview_limit', 'The preimage exceeds 2000 rows or 16 MiB. Use a smaller explicit selection.');
		return $rows;
	}
	private static function digest(array $rows): string {
		$packed = []; foreach ($rows as $row) { ksort($row); $packed[] = serialize($row); } sort($packed, SORT_STRING);
		return hash('sha256', serialize($packed));
	}
	public static function transport_rows(array $rows): array {
		foreach ($rows as &$row) foreach ($row as &$value) if (is_string($value) && !preg_match('//u', $value)) $value = ['encoding' => 'base64', 'data' => base64_encode($value)]; unset($row, $value);
		return $rows;
	}
	/** Execute transaction statements without wpdb's automatic reconnect/replay. */
	private static function transaction_query(string $sql) {
		global $wpdb;
		if (defined('DB_ENGINE') && 'sqlite' === DB_ENGINE) return $wpdb->query($sql);
		if (!($wpdb->dbh instanceof \mysqli)) { $wpdb->last_error = 'Unsupported transaction connection adapter.'; return false; }
		$filtered = apply_filters('query', $sql);
		if (!is_string($filtered) || '' === $filtered) { $wpdb->last_error = 'A query filter rejected the statement.'; return false; }
		$wpdb->flush(); $wpdb->last_query = $filtered; $wpdb->num_queries++;
		try {
			$result = mysqli_query($wpdb->dbh, $filtered);
			if (false === $result) { $wpdb->last_error = mysqli_error($wpdb->dbh); return false; }
			if ($result instanceof \mysqli_result) mysqli_free_result($result);
			$wpdb->rows_affected = max(0, mysqli_affected_rows($wpdb->dbh));
			$wpdb->insert_id = mysqli_insert_id($wpdb->dbh);
			return $wpdb->rows_affected;
		} catch (\Throwable $e) { $wpdb->last_error = $e->getMessage(); return false; }
	}
	private static function apply(array $pre, string $sql, string $token, array $state, array $requirements): array {
		global $wpdb;
		$begun = false; $committed = false;
		$connection = $requirements['sqlite'] ? null : (string)$wpdb->get_var('SELECT CONNECTION_ID()');
		try {
			if (!$requirements['sqlite'] && false === self::transaction_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')) return Result::fail('transaction_isolation_failed', 'Cannot set serializable isolation. Nothing was applied.');
			if (false === self::transaction_query('START TRANSACTION')) return Result::fail('transaction_begin_failed', 'Cannot start a transaction. Nothing was applied.');
			$begun = true;
			$rows = self::rows($pre, !$requirements['sqlite']);
			if (is_wp_error($rows)) return self::rollback(Result::error($rows));
			if (null !== $connection && $connection !== (string)$wpdb->get_var('SELECT CONNECTION_ID()')) return self::rollback(Result::fail('transaction_connection_changed', 'Database reconnected during preview locking. No write was attempted.', ['conflict' => true]));
			if (!hash_equals($state['preimage_hash'], self::digest($rows))) return self::rollback(Result::fail('database_conflict', 'Rows changed since the preview. Request a new preview.', ['conflict' => true, 'applied' => false]));
			$backup = $rows ? Backups::create_rows($pre['table'], $sql, $rows) : '';
			if (is_wp_error($backup)) return self::rollback(Result::error($backup));
			$state['status'] = 'running'; $state['backup_id'] = $backup;
			StateStore::put('db-confirmations', $token, $state);
			$actual = self::transaction_query($sql);
			if (false === $actual) $result = self::rollback(Result::fail('sql_write_failed', $wpdb->last_error ?: 'Database rejected the statement.', ['applied' => false, 'backup_id' => $backup]));
			elseif (in_array($pre['verb'], ['update', 'delete'], true) && $actual > count($rows)) $result = self::rollback(Result::fail('database_conflict', 'The write exceeded its preimage and was rolled back.', ['conflict' => true, 'applied' => false, 'backup_id' => $backup]));
			elseif (false === self::transaction_query('COMMIT')) {
				// Loss of the commit acknowledgement cannot prove whether the server committed.
				self::transaction_query('ROLLBACK');
				return Result::fail('transaction_commit_uncertain', 'COMMIT was not acknowledged. The token remains consumed; inspect the target before another operation.', ['applied' => null, 'backup_id' => $backup]);
			} else {
				$committed = true;
				$result = Result::ok(['applied' => true, 'affected_rows' => (int)$actual, 'backup_id' => $backup, 'preview_rows' => [], 'confirm_token' => '', 'table' => $pre['table'], 'warning' => (string)SqlGuard::serialized_warning($sql, $pre['table'])], 'Write committed. Reusing this token returns this recorded result.');
				wp_cache_flush();
			}
			$state['status'] = 'complete'; $state['result'] = $result;
			StateStore::put('db-confirmations', $token, $state);
			return $result;
		} catch (\Throwable $e) {
			if ($committed) return Result::fail('confirmation_commit_record_failed', 'Database committed but completion could not be saved. Do not repeat with a new token.', ['applied' => true, 'backup_id' => $state['backup_id'] ?? '']);
			return $begun ? self::rollback(Result::fail('database_operation_failed', $e->getMessage())) : Result::fail('database_operation_failed', $e->getMessage());
		} finally { if ($begun && !$committed) self::transaction_query('ROLLBACK'); }
	}
	private static function rollback(array $result): array {
		global $wpdb;
		if (false === self::transaction_query('ROLLBACK')) return Result::fail('transaction_rollback_failed', 'Rollback was not acknowledged. Inspect database state before continuing.', ['applied' => null, 'original_error' => $result, 'backup_id' => $result['backup_id'] ?? '']);
		$result['rolled_back'] = true; $result['applied'] = false; return $result;
	}
}
