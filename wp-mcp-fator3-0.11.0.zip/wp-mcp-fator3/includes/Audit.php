<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Audit {
	public static function record(string $name, array $input, array $result, int $duration): void {
		if (str_starts_with($name, 'audit/')) return;
		try {
			$id = gmdate('YmdHis') . '-' . bin2hex(random_bytes(8));
			$target = $input['path'] ?? $input['destination'] ?? $input['source'] ?? $input['id'] ?? $input['name'] ?? $input['slug'] ?? '';
			StateStore::put('audit', $id, ['id' => $id, 'time' => gmdate('c'), 'user' => get_current_user_id(), 'ability' => $name, 'target' => is_scalar($target) ? (string)$target : '', 'duration_ms' => $duration, 'success' => $result['success'] ?? true, 'error_code' => $result['error_code'] ?? '', 'operation_id' => $result['operation_id'] ?? '', 'backup_id' => $result['backup_id'] ?? '', 'replayed' => $result['replayed'] ?? false]);
		} catch (\Throwable $e) { error_log('Fator3 MCP audit could not be stored.'); }
	}
	public static function listing(array $input): array {
		$rows = [];
		foreach (glob(StateStore::directory('audit') . '/*.php') ?: [] as $file) {
			$raw = @file_get_contents($file);
			if (false === $raw || !str_starts_with($raw, StateStore::HEADER)) continue;
			$row = json_decode(substr($raw, strlen(StateStore::HEADER)), true);
			if (!is_array($row) || (int)($row['site_id'] ?? 1) !== get_current_blog_id()) continue;
			if (isset($input['user']) && (int)$input['user'] !== $row['user']) continue;
			if (!empty($input['ability']) && !str_starts_with($row['ability'], $input['ability'])) continue;
			if (isset($input['success']) && $input['success'] !== $row['success']) continue;
			if (!empty($input['before']) && strcmp($row['id'], $input['before']) >= 0) continue;
			$rows[] = $row;
		}
		usort($rows, static fn($a,$b) => strcmp($b['id'],$a['id']));
		$limit = min(200, max(1, (int)($input['per_page'] ?? 50)));
		$more = count($rows) > $limit; $rows = array_slice($rows, 0, $limit);
		return Result::ok(['entries' => $rows, 'has_more' => $more, 'next_cursor' => $more ? end($rows)['id'] : null]);
	}
	public static function prune(array $input): array {
		$cutoff = time() - max(1, (int)($input['older_than_days'] ?? 90)) * DAY_IN_SECONDS;
		$files = array_values(array_filter(glob(StateStore::directory('audit') . '/*.php') ?: [], static function($f) use($cutoff) { $row = json_decode(substr((string)file_get_contents($f), strlen(StateStore::HEADER)), true); return is_array($row) && (int)($row['site_id'] ?? 1) === get_current_blog_id() && filemtime($f) < $cutoff; }));
		$n = 0;
		if (empty($input['dry_run']) && isset($input['dry_run'])) foreach ($files as $file) { if (!@unlink($file)) return Result::fail('audit_prune_failed', 'Unable to remove audit entry.', ['removed' => $n]); ++$n; }
		return Result::ok(['selected' => count($files), 'removed' => $n, 'dry_run' => $input['dry_run'] ?? true]);
	}
}
