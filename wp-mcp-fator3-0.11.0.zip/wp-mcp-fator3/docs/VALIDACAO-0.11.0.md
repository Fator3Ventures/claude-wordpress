# Validação — WP MCP Fator3 0.11.0

Validação executada em laboratório descartável. O site do usuário não foi alterado.

## Ambientes efetivamente executados

- Linux, PHP 8.3.6.
- WordPress 6.9.4, com Abilities API nativa, e WordPress 6.7.4, com polyfill do plugin.
- SQLite Database Integration 3.0.1 para os dois WordPress.
- MariaDB 10.11.14/InnoDB, conexão mysqli nativa, WordPress 6.9.4.
- HTTP real em loopback com servidor de desenvolvimento PHP, REST WordPress, Application Password e sessão MCP.

Não foram executados testes em MySQL 8, PHP 8.0, Windows, múltiplos nós ou no servidor de produção. A auditoria completa de OAuth não foi repetida.

## Resultados

Todos os registros JSON foram conferidos após a execução: nenhuma asserção falhou. As 19 invocações do executor final terminaram com código zero; algumas invocações contêm mais de uma suíte. As contagens abaixo incluem a repetição intencional de cenários em diferentes ambientes, sem representar casos únicos.

| Suíte | Aprovados/total | Evidência JSON |
|---|---:|---|
| Contratos, WordPress 6.9.4 + SQLite | 72/72 | `contracts-sqlite.json` |
| Contratos, WordPress 6.9.4 + SQLite, lixeira desativada | 9/9 | `contracts-sqlite-trash-disabled.json` |
| Contratos, WordPress 6.7.4 + SQLite / polyfill | 72/72 | `contracts-wp67.json` |
| Contratos, WordPress 6.7.4 + SQLite, lixeira desativada | 9/9 | `contracts-wp67-trash-disabled.json` |
| Contratos, WordPress 6.9.4 + MariaDB | 72/72 | `contracts-mariadb-enabled.json` |
| Contratos, WordPress 6.9.4 + MariaDB, lixeira desativada | 9/9 | `contracts-mariadb-disabled.json` |
| MariaDB: transações, bytes, falhas e confirmação concorrente | 10/10 | `mariadb-extra.json` |
| Recursos avançados e compensação de planos | 18/18 | `advanced.json` |
| Instalação/atualização nativa de pacotes controlados | 9/9 | `packages.json` |
| Concorrência real entre processos PHP | 14/14 | `concurrency.json` |
| Transporte HTTP MCP e autenticação | 6/6 | `http.json` |
| Integração herdada e preservação de bytes/unslash | 105/105 | `inherited-integration.json` |
| Regressões files/read e plugins/delete | 85/85 | `inherited-files091.json` |
| Regressões de melhorias upstream | 10/10 | `inherited-upstream.json` |
| Exclusão de posts/tipos, lixeira habilitada | 77/77 | `inherited-delete-post-enabled.json` |
| Exclusão de posts/tipos, lixeira desativada | 58/58 | `inherited-delete-post-disabled.json` |
| rmdir: filesystem real com stubs de WordPress | 38/38 | `inherited-rmdir.json` |
| Confinamento e constantes de bloqueio | 13/13 | `confine-wp.json`, `confine-edit.json`, `confine-mods.json` |

Análise sintática dos **105 arquivos PHP de produção**: zero erros (`php-lint.json`).

Inventário: **73 abilities próprias anteriores preservadas + 27 novas = 100**. O catálogo observado no WordPress 6.9.4 contém também três abilities nativas `core/*`, totalizando 103. As três ferramentas MCP de descoberta, informação e execução foram preservadas. Consulte `ability-inventory.json`.

## O que os testes de concorrência demonstram

Duas requisições PHP independentes usam o mesmo `expected_sha256` para alterar o mesmo arquivo: somente uma grava; a outra recebe `file_conflict`. Leitura, comparação, backup e substituição ocorrem sob o mesmo lock persistente por caminho canônico.

Os casos verificam a participação de write, patch, delete, fetch, restore, copy e move; hash/bytes preservados quando o lock está ocupado; alias por symlink; bloqueio do destino de copy; rmdir do pai durante alteração do filho; coordenação da exclusão nativa de plugin com seus descendentes; e idempotência concorrente com um único backup.

No MariaDB, duas confirmações concorrentes do mesmo token incrementam o registro somente uma vez. Falhas injetadas de início/commit, token consumido sem conclusão, modo estrito, pré-imagem binária, triggers e tabelas não transacionais também têm verificação explícita.

Esses resultados cobrem escritores participantes do protocolo. Não demonstram exclusão mútua com FTP, editor nativo, WP-CLI ou plugins externos que não adquiram os mesmos locks, nem em armazenamento distribuído não testado.

## Limites dos demais ensaios

- Instalação, atualização e ativação usam o upgrader nativo WordPress, com ZIPs e respostas de catálogo controlados; não são testes do catálogo remoto inteiro.
- O HTTP MCP exercita inicialização, sessão, os três metatools, permissões e propagação de erro de domínio como `isError=true`; a rota REST foi acessada pela forma `index.php?rest_route=/mcp/wp-mcp-ultimate`.
- O envelope privado foi acessado por HTTP local sem expor o payload. Isso não certifica a configuração HTTP de outro servidor.
- As suítes de conteúdo usam APIs reais do WordPress e conferem os bytes persistidos. A suíte isolada de rmdir usa stubs explícitos de WordPress e operações reais de filesystem.
- Os testes herdados que inspecionavam `.bak` foram adaptados para corromper/verificar o novo envelope de backup. A restauração de backups legados tem um caso separado.
- Testes históricos JavaScript/E2E permanecem no código, mas não foram executados nesta rodada. Relatórios de versões antigas mantêm seus nomes históricos; os resultados desta versão são os arquivos referidos acima.

## Reprodução e integridade

O pacote `wp-mcp-fator3-0.11.0-testes.zip` contém os JSONs desta execução, os harnesses PHP/Python, fixtures de pacotes, inventário de abilities e manifestos SHA-256. O README desse pacote explica a montagem do laboratório e quais caminhos precisam ser ajustados. Ele não contém WordPress, bancos de dados, credenciais ou runtimes binários.

Os arquivos PHP de produção no ZIP instalável são conferidos byte a byte contra a árvore usada nos testes. O nome da pasta e o arquivo principal continuam `wp-mcp-fator3/wp-mcp-fator3.php`.
