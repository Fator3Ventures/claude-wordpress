# WP MCP Fator3 0.11.0

Esta versão reúne as correções e as funcionalidades das três etapas do roadmap da análise da 0.9.3. A base é o ZIP `wp-mcp-fator3-0.9.3.zip`, SHA-256 `9039c572ca4e30f6c023965d74a799e6abb2d71e4056118b5b38529e4df1e2e4`. Não é necessário instalar versões intermediárias.

## Instalação e compatibilidade

1. No WordPress, envie `wp-mcp-fator3-0.11.0.zip` em Plugins → Adicionar plugin → Enviar plugin.
2. Escolha substituir a versão instalada. A pasta e o arquivo principal continuam sendo `wp-mcp-fator3/wp-mcp-fator3.php`.
3. Se o Ultimate separado ainda estiver ativo, mantenha o Fator3 ativo e desative/exclua o Ultimate para carregar todas as correções do núcleo integrado.
4. No conector, consulte `system/capabilities` e `system/health`. Atualize a descoberta de abilities para obter os schemas novos.

A rota continua **`/wp-json/mcp/wp-mcp-ultimate`**, preservando as conexões existentes. Sem permalinks amigáveis, o WordPress pode usar `index.php?rest_route=/mcp/wp-mcp-ultimate`. `system/capabilities.endpoint` devolve a URL completa da instalação, inclusive eventual subdiretório.

São mantidos Discover Abilities, Get Ability Info e Execute Ability. Nenhuma nova ferramenta direta é exigida. Credenciais, opções de canais e a migração do Ultimate mantêm o mecanismo da 0.9.3. Os plugins Google e Base Site Core não fazem parte desta alteração.

Requisitos do plugin: WordPress 6.7+ e PHP 8.0+. A execução SQL verificada exige uma conexão/engine compatível e as variáveis de limite de execução suportadas pelo servidor; tabelas não transacionais são recusadas. A seção de testes distingue os ambientes efetivamente executados.

## Gravação concorrente de arquivos

Todas as alterações das abilities `files/write`, `patch`, `delete`, `fetch`, `restore`, `mkdir`, `move` e `copy` usam o mesmo mecanismo de locks. Leituras de `files/read` e `files/stat` usam locks compartilhados. O ciclo de diagnóstico também protege seus próprios arquivos temporários.

O lock é associado ao caminho canônico e fica em um arquivo auxiliar persistente. Ele não depende do inode do arquivo de destino: continua válido quando a gravação troca o destino por `rename()`. Links simbólicos para o mesmo destino compartilham a chave canônica. Locks compartilhados nos diretórios ancestrais impedem remover um diretório enquanto um descendente está sendo modificado. Cópia e movimentação adquirem os dois caminhos em ordem definida.

Dentro do lock exclusivo acontecem a leitura atual, a comparação de `expected_sha256`, a criação do backup e a substituição/exclusão. As operações nativas de instalação, atualização e remoção de plugins, instalação/ativação de temas e upload/exclusão de anexos coordenam seus diretórios com esses locks.

| Código | Significado | Ação do agente |
|---|---|---|
| `file_conflict` | O conteúdo atual difere do hash esperado | Ler novamente, revisar a alteração e enviar o novo hash |
| `resource_busy` | Outra operação mantém o recurso ocupado | Repetir após a espera informada; `retryable=true` |
| `file_path_conflict` | O caminho mudou enquanto aguardava o lock | Resolver e conferir o destino novamente |
| `lock_unavailable` | O armazenamento não conseguiu oferecer o lock | Corrigir o ambiente; não insistir como se fosse disputa temporária |
| `content_conflict` | A revisão de conteúdo ficou desatualizada | Ler novamente antes de alterar |
| `database_conflict` | Os registros mudaram desde a prévia | Solicitar outra prévia e conferir o resultado |

Exemplo de resposta de conflito da ability:

```json
{
  "success": false,
  "error_code": "file_conflict",
  "conflict": true,
  "retryable": false,
  "current_sha256": "<hash atual>"
}
```

Pelo Execute Ability, a resposta é preservada em `data`; a falha externa recebe `success=false`, e o resultado MCP recebe `isError=true` e conteúdo estruturado.

O hash é opcional para manter compatibilidade. Sem ele, as operações são serializadas, mas uma alteração baseada em uma leitura antiga ainda pode substituir conteúdo mais recente. Para compare-and-swap, envie `expected_sha256` de uma leitura completa ou de `files/stat`. O hash de uma leitura parcial/grep/tail identifica apenas o conteúdo devolvido.

Os locks coordenam processos que usam este mecanismo. FTP, editores, WP-CLI, plugins de terceiros e outros escritores externos precisam cooperar para obter a mesma garantia. Em instalações com vários servidores, o diretório de locks deve ser o mesmo armazenamento físico e oferecer `flock` compartilhado entre os nós. Não há promessa de transação entre máquinas com diretórios privados separados. [Semântica de flock no PHP](https://www.php.net/manual/en/function.flock.php).

## Correções de contrato

- `content/delete-post`, `content/delete-page` e `comments/delete`: `force=false` somente envia para a lixeira; repetição é sucesso sem alteração; lixeira desativada retorna erro, sem exclusão definitiva como fallback. O estado persistido e as permissões por objeto são verificados.
- `media/delete`: mantém exclusão definitiva por padrão (`force=true`). Uma chamada explícita com `force=false` exige lixeira de mídia habilitada e não seleciona exclusão definitiva como fallback.
- `plugins/delete`: preserva o carregamento de `wp-admin/includes/file.php` e o tratamento sem formulário interativo de credenciais de filesystem. Instalação/atualização de pacotes também carrega as dependências administrativas necessárias.
- `options/update`: relê o valor efetivamente persistido; informa `changed`, `requested_value`, `new_value` e `normalized`. Reaplicar o valor efetivo é sucesso sem alteração. Atualização de uma chave em opção inexistente cria um array; opção escalar recebe `option_type_conflict`. Veto/falha recebe erro identificável. Os schemas de valores admitem os tipos JSON e não omitem `type`.
- `db/query`: preserva bytes dos literais; ignora LIMIT dentro de strings/subconsultas; limita o LIMIT externo, inclusive explícito. Limites: 64 KiB de SQL, até 2.000 linhas e teto de bytes da resposta.
- `db/execute`: token aleatório, vinculado a SQL, usuário, site e assinatura dos registros; validade de 10 minutos antes do consumo; verificação da pré-imagem dentro da transação. Repetição de token concluído devolve o resultado anterior. Estado consumido sem conclusão retorna erro de resultado incerto.
- `REPLACE`: examina conflitos em chave primária e índices únicos, incluindo múltiplos registros conflitantes, e guarda a pré-imagem. INSERT/REPLACE exigem colunas explícitas e VALUES literais. Expressões, índices únicos de prefixo/expressão, triggers, cascatas e formas complexas cuja pré-imagem não é garantida são recusadas com código próprio. `ON DUPLICATE KEY UPDATE` deve ser desdobrado em uma operação tipada ou UPDATE com prévia.
- InnoDB: isolamento SERIALIZABLE e leitura bloqueante da pré-imagem; comandos de transação/escrita usam a conexão mysqli sem a repetição automática de consultas do wpdb. Falhas de BEGIN, COMMIT e ROLLBACK são diferenciadas. Ausência de confirmação do commit é reportada como resultado incerto, sem repetir o comando.
- Erros de domínio, `WP_Error` e exceções chegam corretamente ao metatool/handler. O polyfill das abilities também valida entrada, permissão e saída.

O SQL usa temporariamente modo estrito nas escritas. Os limites de tempo são locais à conexão e restaurados depois: MariaDB oferece `max_statement_time`; MySQL oferece `max_execution_time` para SELECT. A espera por locks InnoDB também é limitada. O adaptador SQLite mantém os limites de linhas/bytes, sem afirmar um timeout de execução equivalente. Esses limites não representam um prazo global de todo um plano.

Backups de banco cobrem os registros da tabela alvo, não uma cópia completa do banco. Células binárias são codificadas explicitamente em base64; não há substituição silenciosa de bytes inválidos por caracteres Unicode.

## 27 abilities adicionadas

| Área | Abilities |
|---|---|
| Diagnóstico | `system/capabilities`, `system/health` |
| Temas | `themes/list`, `themes/validate`, `themes/install`, `themes/activate` |
| Plugins | `plugins/install`, `plugins/update` |
| Conteúdo | `content/upsert`, `content/untrash`, `content/restore-revision`, `content/diff`, `content/blocks`, `content/edit-block` |
| Arquivos | `files/stat`, `files/mkdir`, `files/move`, `files/copy`, `files/search` |
| Planos | `operations/plan`, `operations/apply`, `operations/status` |
| Auditoria | `audit/list`, `audit/prune` |
| Backups | `backups/list`, `backups/export`, `backups/prune` |

As 73 abilities próprias do pacote anterior foram preservadas, totalizando 100. No WordPress 6.9.4 usado no laboratório, três abilities nativas adicionais levaram a descoberta pública a 103. O total pode variar conforme os complementos e a versão do WordPress.

### Descoberta e diagnóstico

Discover Abilities aceita `query`, `prefix`, `category`, `readonly`, `per_page`, `cursor` e `compact`. Sem parâmetros, mantém a lista completa anterior. Uma página informa `has_more`, `next_cursor` e a assinatura do catálogo. Mudança do catálogo invalida o cursor.

`availability=requires_input` não significa falta de permissão: indica que os argumentos do objeto ainda precisam ser avaliados. A execução sempre verifica a permissão real com os parâmetros fornecidos.

`system/health` verifica condições locais e identifica explicitamente que não testou conectividade externa, OAuth ou a proteção HTTP no servidor do usuário.

### Conteúdo, Gutenberg e navegação

Leituras de conteúdo com `id` devolvem um token `revision`. Updates/patches/exclusões aceitam `expected_revision`, comparado sob lock do post. Essa coordenação cobre as operações participantes do plugin; o editor nativo e escritores externos não adquirem automaticamente esse lock.

`content/upsert` usa `post_type` + `external_ref` para manter um ID estável. Uma referência cujo item foi excluído não recria conteúdo silenciosamente. Templates, partes e navegação são aceitos quando o tipo/capacidades permitem; `taxonomy` pode associar `wp_theme` ao tema correspondente. A ability exige também as capacidades de publicação/atribuição de termos pertinentes.

`content/blocks` devolve a árvore do WordPress, referências e um índice de caminhos de blocos nomeados; fragmentos livres não contam nesses caminhos. `content/edit-block` altera atributos, `inner_html` ou `children`. Bytes fora do bloco selecionado são preservados. Ao substituir filhos, mantém a marcação anterior ao primeiro e posterior ao último filho. A validação PHP não substitui a validação JavaScript do editor. Alterações de atributos que influenciam o HTML salvo também precisam da marcação correspondente.

`content/diff` oferece prévia sem salvar, com limite combinado de 2 MiB. Restauração de revisão exige que a revisão pertença ao conteúdo e que revisões estejam habilitadas para esse tipo.

### Arquivos e logs

`files/list` acrescenta `offset`/`per_page` (200 por padrão, máximo 1.000), `has_more`, `next_offset` e assinatura da listagem. Preserva os campos anteriores `type=dir|file`, `size`, `modified` e `writable`; acrescenta `is_symlink`. O limite de varredura é 50.000 entradas; use diretórios menores quando necessário.

`files/copy` e `files/move` operam em arquivos regulares. Sobrescrita exige `overwrite=true`; há hash opcional da origem e do destino. Move entre filesystems é recusado: faça copy, confira o destino e exclua a origem explicitamente. Não há movimentação recursiva de árvores.

`files/search` faz busca literal limitada: arquivos de até 2 MiB, orçamento de 16 MiB de leitura, teto de matches e indicação de arquivos truncados/ignorados. Não atravessa links simbólicos. Continue um arquivo truncado com `files/read`; `next_offset` avança na listagem de arquivos.

`files/read` preserva `tail_lines`, `offset`, `limit`, `grep` e `grep_regex`. O novo modo de bytes começa com `cursor:""`; `byte_limit` é 65.536 por padrão. Retorna `next_cursor` inclusive no EOF, permitindo consultar novos bytes anexados. Identidade, tamanho e amostras dos bytes anteriores detectam rotação/truncamento observável e retornam `file_rotated`. Recriar exatamente os mesmos bytes no mesmo inode não é distinguível por essa técnica. Cursor não combina com parâmetros de linhas/grep/tail. Um corte no meio de UTF-8 retorna bytes em base64.

### Repetição e planos com retomada

Abilities mutáveis próprias aceitam `idempotency_key`. A mesma chave, usuário, site, ability e parâmetros devolvem o resultado registrado; parâmetros diferentes produzem `idempotency_conflict`. Registros incompletos não são repetidos automaticamente. As chaves não são descartadas automaticamente por idade nesta versão.

`operations/plan` valida até 50 etapas ordenadas e persiste o plano. Dependências devem aparecer antes da etapa dependente. Uma referência tem a forma `{"$ref":"etapa.campo"}` e exige dependência explícita. Argumentos com referências são validados depois de resolvidos.

`operations/apply` executa até `max_steps` (5 por padrão, máximo 20) e pausa entre etapas quando atinge o orçamento da chamada. Reutilize o mesmo `plan_id` para continuar. Cada etapa tem chave de idempotência própria. Não há transação global entre WordPress, arquivos e serviços externos; uma etapa individual pode durar mais que o orçamento entre etapas.

Com `on_failure=compensate`, o plano tenta restaurar backups de gravações/patches/fetch/copy/restore usando o hash do resultado anterior e remover diretórios criados que ainda estejam vazios. Etapas sem uma inversa completa, conflito na compensação e alterações parciais/incertas são informadas; o estado pode ser `compensation_incomplete`. Não há rollback automático de exclusões definitivas, instalações, SQL, movimentos ou ações externas arbitrárias.

### Backups e auditoria

Novos registros e backups ficam em `wp-content/f3-mcp-private`, ou no caminho absoluto configurado por `F3_MCP_PRIVATE_DIR` no wp-config.php. Prefira uma localização fora da área pública quando o ambiente permitir. Todos os workers devem usar a mesma localização. Mover esse diretório exige preservar integralmente seu conteúdo e realizar a mudança sem operações simultâneas.

Os arquivos persistidos usam envelope PHP que encerra a execução antes do payload, permissões restritas e proteção adicional para Apache. O canal de arquivos não lê nem altera diretamente os arquivos internos de estado/locks. O teste HTTP local do envelope não certifica a configuração do servidor de produção.

Listagem usa um índice de metadados, sem carregar os conteúdos dos novos backups. `backups/export` verifica o limite da resposta e entrega JSON em base64. `backups/prune` aplica idade e/ou volume, com `dry_run=true` por padrão. Retenção não é executada automaticamente na atualização. Os backups legados `.json/.bak` continuam legíveis/restauráveis e não são apagados pela retenção nova; conservam sua proteção anterior e devem ser tratados na configuração do servidor.

A auditoria registra usuário, alvo, duração, resultado, código de erro, ID de operação e backup, sem gravar os parâmetros/conteúdos completos. `audit/list` oferece filtros e cursor; `audit/prune` oferece retenção por idade. Os registros da opção antiga permanecem disponíveis no painel existente.

## Configurações de infraestrutura

- `F3_MCP_PRIVATE_DIR`: caminho absoluto para estado, locks, backups e auditoria. Uma mudança não migra dados automaticamente.
- Filtro `f3_mcp_lock_timeout`: espera pelo lock, padrão 2 segundos, limitada a 0–10 segundos.
- Filtro `f3_mcp_sql_timeout`: limite nativo de consulta/espera por lock, padrão 5 segundos, limitado a 1–30 segundos.
- Filtro `f3_mcp_backup_max_bytes`: teto de backup por arquivo, padrão 64 MiB; há também uma verificação do orçamento de memória do PHP.
- Filtros/constantes anteriores de capacidade, canal, extensões, tamanho e confinamento permanecem válidos.

## Validação

Consulte `VALIDACAO-0.11.0.md` para os resultados finais por suíte. Foram utilizados WordPress 6.9.4 e 6.7.4, PHP 8.3.6, SQLite Database Integration e MariaDB 10.11.14. Os testes incluem concorrência real entre processos, confirmação SQL concorrente, bytes de conteúdo/backup, permissões e transporte HTTP MCP.

O ciclo nativo de instalação/atualização/ativação/exclusão foi exercitado com ZIPs e respostas de catálogo controlados. Isso valida o funcionamento do upgrader e filesystem; não equivale a testar todos os pacotes do catálogo real. Não houve instalação no site do usuário, ensaio em MySQL 8, PHP 8.0, Windows ou múltiplos nós. Não foi refeita uma auditoria completa de OAuth.

## Referências técnicas

Os contratos de lixeira respeitam as diferenças entre [wp_delete_post](https://developer.wordpress.org/reference/functions/wp_delete_post/) e [wp_trash_post](https://developer.wordpress.org/reference/functions/wp_trash_post/). A verificação de opções considera o [retorno de update_option](https://developer.wordpress.org/reference/functions/update_option/). O tratamento de falhas MCP segue [Tools — Error Handling](https://modelcontextprotocol.io/specification/2025-06-18/server/tools#error-handling). A pré-imagem de REPLACE considera sua [semântica de substituição por conflitos de chave](https://dev.mysql.com/doc/refman/8.4/en/replace.html).
