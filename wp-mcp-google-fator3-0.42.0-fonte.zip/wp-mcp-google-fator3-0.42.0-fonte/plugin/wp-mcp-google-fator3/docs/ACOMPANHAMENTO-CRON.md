# Acompanhamento operacional do cron

Agendas e tarefas avulsas conservam a autorização do site após rotação MCP. O executor revalida administrador, conexão, identidade e política. Avisos são publicados no destino técnico do Core, com fila persistente para indisponibilidade do contrato. Um estado incerto de escrita exige reconciliação.

Como o executor, o histórico de passagens, a agenda e a manutenção funcionam, e como diagnosticar e corrigir. Contrato dos campos: `CONTRACTS.md`, seções "Cron e executor" e "Armazenamento e manutenção".

## Eventos e disparo

| Gancho | Função |
|---|---|
| `f3_mcp_google_jobs_tick` | Executor de minuto (`f3_google_minute`): tarefas, agendas, alertas, renovação de provas de conversão e coletor do acervo Ads |
| `f3_mcp_google_maintenance` | Manutenção local horária; pede nova passagem em 15 s quando há lote pendente |

`cron.scheduling` observa somente esses dois ganchos.

O WP-Cron depende de visitas. Sem tráfego, configure no servidor `wp mcp-google run-due --user=<administrador>` ou chame `google/executar-vencidos`. O marcador `f3_mcp_cron_observed` pertence ao Fator3 MCP; ganchos `f3base_` pertencem ao Site Core.

## Acervo Ads no executor

O mesmo evento de minuto aciona o coletor Ads depois do executor de jobs: até quatro contas por passagem e uma página por conta, sob orçamento cooperativo de 20 s. O cron assume somente o administrador que concedeu a coleta, revalida identidade, canal e política e restaura o usuário anterior. Falhas deferem o recorte por 5 minutos a 6 horas sem bloquear outros datasets. `ads/archive-status` informa progresso e recortes deferidos e não coleta.

## Passagem, histórico e cobertura

`google/status.cron` traz `ultima_cli`, `ultima_http`, `ultima_manual`, `last_run`, `cron_servidor_ativo`, `executor`, `passagens_24h`, `observed_since`, `window_complete` e a manutenção. CLI observada nas últimas duas horas define `server-cron`; isso não comprova crontab instalado nem sucesso dos trabalhos. Uma origem não sobrescreve outra.

`google/executar-vencidos` e `wp mcp-google run-due` retornam cessão normal (`success:true`, `state:"yielded"`, `work_success:null`, zero itens, `connection_examined:false`) quando outra passagem possui a admissão. Falha real de leitura, escrita ou posse conserva o código de erro.

`history_status`: `confirmed` (evento e projeção confirmados), `pending` (fonte durável para reconciliação) ou `unconfirmed` (prova insuficiente). Repetir uma escrita remota para corrigir histórico é proibido. A próxima execução autorizada reconcilia até 20 fontes pendentes por conexão, sem executar o trabalho de novo. Leitura de status reconstrói projeções somente em memória.

`observability_error` é falha ativa; `last_observability_error` conserva a identidade original e `resolved_at`/`resolved_by` comprovam a resolução. Idade, outra conexão, passagem apenas iniciada, cessão e sucesso HTTP isolado não limpam o erro.

`history_pending`, `coverage_gap` e `truncated_in_window` mantêm as lacunas visíveis; `window_complete:false` não deve ser tratado como aprovação. `observation_health` distingue `observed`, `gap` e `unreadable`. `work_observation` descreve somente a fila atual (`interval_proven:false`). Passagem sem conclusão e sem sessão viva aparece como `interrupted`, causa desconhecida, salvo `time_limit`, `memory_limit` ou `php_fatal` observados.

## Agenda (`cron.scheduling`)

Contrato 2.0.0, escopo site. Cada observação contém gancho, operação, origem, `target_at`, recorrência e intervalo, assinatura dos argumentos, `at`, idade, `original_code`, `read_success`, `postcondition`, `state`, `diagnostic_persisted`. Argumentos brutos e eventos de terceiros não são expostos. `observations` guarda o último estado por gancho, origem e operação; `active_errors` contém erros por intenção (até 100; `untracked_errors>0` declara perda de detalhe); `last_errors` conserva histórico limitado. Erros não expiram por idade.

| Operação | Confirmação exigida |
|---|---|
| `schedule` | Evento esperado com timestamp, argumentos, recorrência e intervalo |
| `schedule` de evento único recusado com `duplicate_event` | Evento equivalente (mesmo gancho e argumentos) dentro da janela de duplicidade do WordPress |
| `reschedule` | Próxima ocorrência esperada ou posterior da mesma cadeia; nunca apenas a vencida |
| `unschedule` | Ausência da ocorrência removida |
| `clear` | Ausência dos eventos do gancho com os argumentos incluídos |

Estados: `confirmed`, `failed`, `unconfirmed`. A confirmação usa leitura persistida nova e a visão efetiva do WordPress, sem flush global.

### Confirmação posterior da agenda

Na 0.37.0, o histórico pode provar que um erro deixou de estar ativo. A confirmação deve ser posterior, identificar o mesmo gancho e os mesmos argumentos e demonstrar o estado solicitado. Uma agenda recorrente exige a mesma frequência e o mesmo intervalo. Para uma chamada avulsa do trabalhador, uma ocorrência confirmada atende um prazo já vencido ou uma chamada confirmada para até o prazo solicitado. A remoção de uma ocorrência exige o mesmo horário ou uma limpeza completa. A simples passagem do tempo não resolve um erro.

O último erro retido do grupo mantém seu ID e recebe `resolved_at` e `resolved_by`, respectivamente o instante e o ID da observação que comprovou o estado. O campo aditivo `resolution_receipts` conserva até 100 vínculos com ID do erro, gancho, instante e ID da confirmação, inclusive quando outro erro já ocupa a posição em `last_errors`. A primeira leitura da versão reconstrói o resultado em memória. A manutenção normal ou a próxima gravação de agenda o persiste sob o lock existente. Um executor ausente ou inválido continua aparecendo como erro atual separado. A leitura de status não executa nem reagenda o gancho.

### Recusa `duplicate_event`

O WordPress recusa um evento único com `duplicate_event` quando já existe evento do mesmo gancho e argumentos a até 600 s do horário pedido (para horário no passado ou nos próximos 600 s, a janela vai do início até agora + 600 s). Essa recusa é tratada como pós-condição atendida:

1. A observação fica `state:"confirmed"`, `success:true`, `original_code:"duplicate_event"`, `error_code:null` e `equivalent_at` com o horário do evento equivalente.
2. Um erro ativo antigo de evento único com `original_code:"duplicate_event"` é resolvido na passagem de manutenção quando a leitura da agenda feita nessa passagem encontra uma ocorrência pendente do mesmo gancho e argumentos, em qualquer horário. O erro passa a ter `resolved_by:"duplicate_event_equivalent"`, `resolved_at` e `equivalent_at` com o menor horário entre as ocorrências pendentes equivalentes. Na ausência dessa ocorrência, aplica-se também a regra de confirmação posterior descrita acima.
3. A manutenção não pede evento único quando a próxima ocorrência de `f3_mcp_google_maintenance` já está dentro dessa janela, e não registra erro nesse caso.
4. As demais falhas de agenda continuam em `active_errors` até prova e mantêm `cron.health:"degraded"`.

A manutenção reconfere até 20 erros de agenda por passagem, em rodízio, sem repetir chamadas de agenda nem callbacks. Resolução por pós-condição comprovada usa `resolved_by:"postcondition_recheck"`.

## Saúde

| Campo | Valores | Onde |
|---|---|---|
| `health` | `degraded`, `due`, `blocked`, `idle` | `cron.health` (completo) e `health` (compacto) |
| `work_health` | `unknown`, `due`, `blocked`, `idle` | `cron.work_health` e `work_health` (compacto) |
| `scheduling_active_errors` | inteiro | Compacto; quantidade de `cron.scheduling.active_errors` |
| `incidents_open` | inteiro ou `null` | Compacto; incidentes abertos da conexão; `null` quando a leitura falhou |

`degraded` prevalece quando há erro ativo de agenda ou a leitura da agenda falhou. O compacto não consulta o Google.

## Diagnóstico e reparação

1. `google/status {"compact":true}`. Com `health:"degraded"` ou `scheduling_active_errors>0`, siga.
2. `google/status {}`: leia `cron.scheduling.checks.executor` e `cron.scheduling.active_errors`. `missing` exige reparação; `invalid` exige avaliar forma e multiplicidade; `unknown` exige resolver a leitura.
3. Confira `desired_state` e `repair_blocked_by`. Pausa de recuperação ou armazenamento indisponível precisam ser resolvidos antes.
4. Execute uma passagem admitida: `google/maintenance {}`, `google/executar-vencidos {}`, `wp mcp-google run-due --user=<administrador>` ou `wp cron event run --due-now`. A execução manual pode processar trabalho vencido; não é consulta.
5. Releia `executor_repair`, `checks.executor` e `active_errors`. `present` prova agenda, não processamento.
6. Compare `ultima_cli`, `ultima_http`, `ultima_manual`, `last_run`, histórico e cobertura separadamente.

Não edite a option `cron` inteira, não remova ganchos do Fator3 MCP ou do Site Core, não repita jobs para corrigir o diagnóstico e não oculte `error.log`. `profile_denied` no comando `wp mcp-google` é recusa de perfil MCP, não falha de cron.

## Avisos nativos do WordPress

O WordPress escreve `could_not_set` antes de chamar `cron_reschedule_event_error` ou `cron_unschedule_event_error`. Sozinho, o aviso não distingue falha real, ausência de alteração e disputa. Correlacione com gancho, operação, horário, origem e pós-condição em `cron.scheduling`. `at` e `target_at` são Unix UTC; o painel usa o fuso do WordPress.

## Retenção e evidências

O diário retém 8 dias, até 20.000 passagens e 1.000 incidentes por conexão; a limpeza remove até 100 registros por tipo por passagem e mantém as últimas projeções. Exporte as evidências necessárias antes da poda. Snapshot saudável não comprova execução contínua.

Desativação e desinstalação removem os eventos `f3_mcp_google_jobs_tick` e `f3_mcp_google_maintenance` sem executar trabalho nem registrar passagem.

O pedido 59 distingue incidentes da agenda, erros de diagnóstico avulso e recusas de leitura IAM. Consulte a seção de acesso no `GUIA-0.42.0.md` para prazos, configuração por conexão e encerramento.
