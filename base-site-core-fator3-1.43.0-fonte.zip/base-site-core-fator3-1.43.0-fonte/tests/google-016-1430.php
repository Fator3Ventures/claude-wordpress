<?php
require __DIR__.'/bootstrap.php';require getenv('F3BASE_ROOT').'/google-dependency/wp-mcp-google-fator3/wp-mcp-google-fator3.php';\Fator3\McpGoogle\Storage\State::ensure_ready();function verifyLab($name,$ok,$detail=null){if(!$ok){echo wp_json_encode($detail)."\n";}check($ok,$name);}
use Fator3\McpGoogle\{ConversionDelivery as D,Options as O,Connections as C,Policy,Settings,Records,Admin};
use Fator3\McpGoogle\Ads\DataManager as DM;
foreach(Records::ids('conversion') as $id){Records::remove('conversion',$id);}foreach(Records::ids('incident') as $id){Records::remove('incident',$id);}
wp_get_abilities();raw('f3base_ga4_measurement_id','G-TEST016');
$calls=[];$scenario='ok';$mail=0;$secret='synthetic-mp-016';$receipts=[];$during=null;
$fixture=static function($pre,$args,$url)use(&$calls,&$scenario,$secret,&$receipts,&$during){
 if(str_starts_with($url,'http://127.0.0.1'))return new WP_Error('fixture_local_http_blocked');
 $calls[]=[$url,$args];$body=[];$code=200;
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access016','expires_in'=>3600];
 elseif(str_contains($url,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$scenario==='wrong-secret'?'different':$secret]]];
 elseif(str_contains($url,'analyticsadmin.googleapis.com'))$body=['name'=>'properties/123/dataStreams/456','webStreamData'=>['measurementId'=>'G-TEST016']];
 elseif(str_contains($url,'/debug/mp/collect')){$body=['validationMessages'=>[]];if($during){$f=$during;$during=null;$f();}}
 elseif(str_contains($url,'/mp/collect'))$code=204;
 elseif(str_contains($url,'googleAds:search'))$body=['results'=>[['conversionAction'=>['resourceName'=>'customers/1234567890/conversionActions/789','type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>37.5,'defaultCurrencyCode'=>'BRL']]]]];
 elseif(str_contains($url,'/events:ingest')) {
  $sent=json_decode($args['body'],true);if($scenario==='timeout'&&empty($sent['validateOnly']))return new WP_Error('http_request_failed','synthetic timeout');
  $rid='receipt-'.count($receipts);$receipts[$rid]=$sent;$body=!empty($sent['validateOnly'])?[]:['requestId'=>$rid];
 } elseif(str_contains($url,'requestStatus:retrieve')) {
  parse_str(parse_url($url,PHP_URL_QUERY),$query);$d=$receipts[$query['requestId']]['destinations'][0];
  if($scenario==='wrong-destination')$d['productDestinationId']='888';
  $status=['processing'=>'PROCESSING','partial'=>'PARTIAL_SUCCESS','duplicate'=>'FAILED','invalid'=>'FAILED'][$scenario]??'SUCCESS';
  $one=['destination'=>$d,'requestStatus'=>$status,'eventsIngestionStatus'=>['recordCount'=>$scenario==='count-mismatch'?'2':'1']];
  if(in_array($scenario,['duplicate','invalid'],true))$one['errorInfo']=['errorCounts'=>[['recordCount'=>'1','reason'=>$scenario==='duplicate'?'PROCESSING_ERROR_REASON_DUPLICATE_TRANSACTION_ID':'PROCESSING_ERROR_REASON_INVALID_GCLID']]];
  $body=['requestStatusPerDestination'=>[$one]];
 } else return new WP_Error('fixture_unexpected_http');
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>$code===204?'':wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);add_filter('pre_wp_mail',static function($pre,$atts)use(&$mail){++$mail;return true;},1,2);
$config=['enabled'=>true,'measurement_id'=>'G-IGNORED','stream'=>'properties/123/dataStreams/456','customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789'];
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-016',O::OAUTH_REFRESH_TOKEN=>'synthetic-016',O::ADS_DEVELOPER_TOKEN=>'synthetic-dev016']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>$config,'mp_secret'=>$secret]);verifyLab('Configuration saves and reads measurement from Core',$r['success']&&D::status()['config']['measurement_id']==='G-TEST016',$r);
$r=D::verify(['expected_revision'=>D::revision(),'target'=>'ga4']);verifyLab('GA verification uses Admin and debug without collection',!empty($r['success'])&&!array_filter($calls,fn($x)=>str_contains($x[0],'/mp/collect')&&!str_contains($x[0],'/debug/')),$r);
$r=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);verifyLab('Ads verification needs no legacy receipt',!empty($r['success']),$r);
$body=json_decode(end($calls)[1]['body'],true);verifyLab('Ads verification is validateOnly with action value',$body['validateOnly']===true&&$body['events'][0]['conversionValue']===37.5);
$ga=new D('ga4');$ads=new D('google_ads');verifyLab('Both verified targets ready',$ga->capabilities()['ready']&&$ads->capabilities()['ready']);
$adsref=$ads->capabilities()['destination_ref'];$ref=$ga->capabilities()['destination_ref'];
$old=O::get(D::CONFIG);$old['renewal']['ga4']['next_attempt']=time()-1;$old['verified']['ga4']['at']=time()-43000;O::set(D::CONFIG,$old);
wp_set_current_user(0);$r=D::renew_due();wp_set_current_user(1);verifyLab('Background renewal works without impersonation',!empty($r['ga4']['success'])&&$ga->capabilities()['verified_at']>time()-10,$r);
$old=O::get(D::CONFIG);$old['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$old);$expiry=$ga->capabilities()['verification_expires_at'];$scenario='wrong-secret';
wp_set_current_user(0);$r=D::renew_due();wp_set_current_user(1);$renew=$ga->capabilities()['renewal'];
verifyLab('Failure preserves unexpired readiness and alerts administrator',$ga->capabilities()['ready']&&$ga->capabilities()['verification_expires_at']===$expiry&&$renew['result']==='failed'&&$renew['next_attempt']>=time()+295&&$mail===1,$r);
$incident=Records::get('incident',hash('sha256','default|conversion_renewal|ga4'));verifyLab('Renewal incident contains human remediation and mail acceptance',$incident['status']==='open'&&$incident['email_state']==='accepted'&&strlen($incident['action'])>20);
$n=count($calls);D::renew_due();verifyLab('Backoff prevents immediate calls and repeated email',count($calls)===$n&&$mail===1);
$old=O::get(D::CONFIG);$old['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$old);D::renew_due();verifyLab('Second failure increases backoff',$ga->capabilities()['renewal']['next_attempt']>=time()+595&&$mail===1);
$scenario='ok';$old=O::get(D::CONFIG);$old['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$old);D::renew_due();verifyLab('Recovery renews and resolves incident',Records::get('incident',hash('sha256','default|conversion_renewal|ga4'))['status']==='resolved');
// The real Google executor must invoke renewals, not just a direct helper call.
$old=O::get(D::CONFIG);$old['renewal']['ga4']['next_attempt']=time()-1;$old['verified']['ga4']['at']=time()-43000;O::set(D::CONFIG,$old);
wp_set_current_user(0);$run=Fator3\McpGoogle\Automation\Executor::run();wp_set_current_user(1);
verifyLab('Existing executor invokes renewal under background grant',$ga->capabilities()['verified_at']>time()-10,$run['error_code']??null);
$old=O::get(D::CONFIG);$old['renewal']['ga4']['next_attempt']=time()-1;$old['verified']['ga4']['expires']=time()-1;O::set(D::CONFIG,$old);
verifyLab('Expired proof blocks sends locally',!$ga->capabilities()['ready']);D::renew_due();verifyLab('Unchanged grant can renew after expiry',$ga->capabilities()['ready']);
$old=O::get(D::CONFIG);$old['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$old);O::set_secret(D::SECRET,'changed-secret');$n=count($calls);D::renew_due();verifyLab('Secret change requires manual verification without background HTTP',!$ga->capabilities()['ready']&&count($calls)===$n);O::set_secret(D::SECRET,$secret);
function p016($id,$click='gclid'){return ['record_id'=>$id,'event_id'=>$id,'order_id'=>$id,'occurred_at'=>gmdate('c',time()-5),'click_ids'=>[$click=>'synthetic-click'],'ad_user_data'=>'GRANTED','value'=>0,'currency'=>'USD'];}
function due016($id){$key=hash('sha256','default|'.$id);$r=Records::get('conversion',$key);$r['next_attempt']=time()-1;Records::put('conversion',$key,$r);}
foreach(['gclid','gbraid','wbraid'] as $i=>$click) {
 $id=md5($click);$payload=p016($id,$click);wp_set_current_user(0);$r=$ads->sendBound($payload,$adsref);wp_set_current_user(1);
 verifyLab('Ingestion is uncertain before confirmation '.$click,$r['status']==='incerto',$r);
 $sent=json_decode(end($calls)[1]['body'],true);$event=$sent['events'][0];
 verifyLab('Single event preserves identity click consent and action value '.$click,count($sent['events'])===1&&count($sent['destinations'])===1&&$event['transactionId']===$id&&$event['adIdentifiers']===$payload['click_ids']&&$event['conversionValue']===37.5&&$event['currency']==='BRL'&&$event['consent']['adUserData']==='CONSENT_GRANTED'&&!isset(end($calls)[1]['headers']['developer-token']));
 $n=count($calls);$ads->sendBound($payload,$adsref);verifyLab('Same record never ingests twice '.$click,count($calls)===$n);
 due016($id);$r=$ads->reconcileBound($id,$adsref);verifyLab('Matching single event status confirms '.$click,$r['status']==='entregue',$r);
 $n=count($calls);$ads->sendBound($payload,$adsref);verifyLab('Confirmed duplicate call returns receipt locally '.$click,count($calls)===$n);
}
foreach(['processing','partial','duplicate','wrong-destination','count-mismatch','invalid','timeout'] as $case){
 $id=md5($case);$scenario=$case;$r=$ads->sendBound(p016($id),$adsref);due016($id);$r=$ads->reconcileBound($id,$adsref);verifyLab('Conservative outcome '.$case,$r['status']===($case==='invalid'?'recusado':'incerto'),$r);
 $n=count($calls);$ads->sendBound(p016($id),$adsref);verifyLab('No ingestion replay '.$case,count($calls)===$n);
}
$scenario='ok';$id=md5('bound');$n=count($calls);$r=$ads->sendBound(p016($id),'google:wrong');verifyLab('Destination binding refuses before provider HTTP',$r['status']==='recusado'&&$r['non_delivery_proven']&&count($calls)===$n);
$legacy=Fator3\McpGoogle\Http\GoogleClient::request('POST',Fator3\McpGoogle\Ads\AdsApi::base().'/customers/1234567890:uploadClickConversions',[],['connector'=>'ads','mode'=>'write']);verifyLab('Legacy upload rejected before HTTP without current eligibility',is_wp_error($legacy)&&$legacy->get_error_code()==='f3_google_ads_legacy_not_eligible'&&count($calls)===$n);
$payload=['record_id'=>md5('ga'),'event_id'=>md5('ga'),'occurred_at'=>gmdate('c',time()-5),'measurement_id'=>'G-TEST016','event_name'=>'generate_lead','client_id'=>'123.456','session_id'=>'42','timestamp_micros'=>(time()-5)*1000000];
$r=$ga->sendBound($payload,$ref);verifyLab('GA4 synchronous delivery preserved',$r['status']==='entregue',$r);
$during=static function(){raw('f3base_ga4_measurement_id','G-CHANGED');};$n=count($calls);$r=$ga->sendBound($payload,$ref);verifyLab('Core measurement change during debug fences collection',$r['status']==='recusado'&&$r['non_delivery_proven']&&count($calls)===$n+1,$r);raw('f3base_ga4_measurement_id','G-TEST016');
$n=count($calls);D::status();verifyLab('Status remains read-only and shows renewal without HTTP',count($calls)===$n&&isset(D::status()['ga4']['renewal']['next_attempt']));
// Native Core queue: acceptance then later read-only reconciliation.
$record=F3Base_Leads_Repositorio::guardar(['nome'=>'Fixture','email'=>'delivery016@example.test','metodo'=>'formulario','captura'=>'aceito','formulario'=>'fixture016','contexto_teste'=>false,'notificar'=>false]);verifyLab('Core persists synthetic contact',!empty($record['persisted']),$record);
$rid=$record['record_id'];$lead=F3Base_Leads_Repositorio::obter($rid);$d=$lead['dados'];$d['conversoes_transporte']['destinos']=['google_ads'=>'servidor'];$d['conversoes_transporte']['referencias']=['google_ads'=>$adsref];$d['audiencia_excluida']=false;$d['consentimento_snapshot']=['medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:'.F3Base_Modulo_Consentimento::politica_versao()];$d['atribuicao']=['gclid'=>'synthetic-click'];
$wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($d),'classe_trafego'=>'nao_marcado'],['record_id'=>$rid]);$lead=F3Base_Leads_Repositorio::obter($rid);F3Base_Conversoes_Servidor::capturar($lead,'google_ads');F3Base_Execucoes::encerrar();F3Base_Conversoes_Servidor::processar();$rows=F3Base_Conversoes_Servidor::ler(['record_id'=>$rid])['entregas'];verifyLab('Core initially journals uncertain ingestion',$rows[0]['estado']==='incerto',$rows);
$wpdb->update(F3Base_Conversoes_Servidor::tabela(),['proxima'=>time()-1],['record_id'=>$rid]);due016($rid);$n=count(array_filter($calls,fn($x)=>str_contains($x[0],'events:ingest')));F3Base_Execucoes::encerrar();F3Base_Conversoes_Servidor::processar();$rows=F3Base_Conversoes_Servidor::ler(['record_id'=>$rid])['entregas'];verifyLab('Core confirms through status without reingestion',$rows[0]['estado']==='entregue'&&count(array_filter($calls,fn($x)=>str_contains($x[0],'events:ingest')))===$n,$rows);
// Render all six sections with native admin helpers.
require_once ABSPATH.'wp-admin/includes/template.php';

remove_filter('pre_http_request',$fixture,1);evidence('google-016-1430');
