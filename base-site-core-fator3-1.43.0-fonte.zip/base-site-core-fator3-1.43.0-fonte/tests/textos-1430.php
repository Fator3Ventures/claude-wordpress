<?php
require __DIR__.'/bootstrap.php';
$before=F3Base_Options::ler('f3base_contato');
$custom=$before;
foreach(F3Base_Textos_Contato::CAMPOS as $key=>[$label,$default]){$custom['texto_'.$key]='Exemplo: '.$default;}
$custom['texto_resumo_introducao']='Há {quantidade} contatos para revisar.';
$custom['texto_confirmacao_continuar']='Abrir & continuar';
try {
    check(!empty(save('f3base_contato',$custom)['persisted']),'textos_gravados_pelo_canal');
    $cfg=F3Base_Options::ler('f3base_contato');
    check($cfg['texto_confirmacao_continuar']==='Abrir & continuar','texto_preservado');
    check(F3Base_Textos_Contato::ler('resumo_introducao',array('quantidade'=>3))==='Há 3 contatos para revisar.','resumo_variavel');
    $invalid=$custom;$invalid['texto_aviso_titulo']=array('x');
    check(empty(save('f3base_contato',$invalid)['persisted']),'texto_estrutura_invalida_recusada');
    $a=array('site'=>'site.example.test','teste'=>false,'teste_origem'=>'fixture','secoes_comunicacao'=>array('Contato'=>array('Nome'=>'Ana Exemplo')),'registro_url'=>admin_url('admin.php?page=f3base-leads'));
    $html=F3Base_Email::corpo($a);
    check(str_contains($html,'Exemplo: Novo contato recebido')&&str_contains($html,'Exemplo: Consultar contato no WordPress')&&str_contains($html,'Exemplo: O acesso ao registro exige login autorizado.'),'email_usa_textos_configurados');
    check(str_contains(F3Base_Contato_Apresentacao::texto($a),'Exemplo: Consultar contato no WordPress'),'alternativa_textual_usa_texto');
    $slack=F3Base_Slack::simples('Exemplo',array(),$a['registro_url']);
    check(str_contains(wp_json_encode($slack),'Exemplo: Consultar contato no WordPress'),'slack_usa_rotulo');
    ob_start();F3Base_Textos_Contato::previa();$preview=ob_get_clean();
    check(str_contains($preview,'Há 3 contatos para revisar.')&&str_contains($preview,'Abrir &amp; continuar'),'previa_mesmos_textos_escape');
    $captured=null;
    add_filter('wp_die_handler',static function()use(&$captured){return static function($message,$title,$args)use(&$captured){$captured=compact('message','title','args');throw new RuntimeException('qa_wp_die');};});
    $ref=str_repeat('a',64);set_transient('f3base_confirmacao_'.$ref,array('mensagem'=>'Recebido','url'=>'https://example.test/material','destino'=>home_url('/obrigado')),600);
    $_GET['ref']=$ref;
    try{F3Base_Formularios::confirmacao();}catch(RuntimeException $e){if($e->getMessage()!=='qa_wp_die'){throw $e;}}
    check($captured['title']==='Exemplo: Confirmação'&&str_contains($captured['message'],'Abrir &amp; continuar'),'confirmacao_ponte_configurada');
    $_GET['f3base_confirmacao_ref']=$ref;$_SERVER['REQUEST_URI']='/obrigado';
    try{F3Base_Confirmacao::pagina();}catch(RuntimeException $e){if($e->getMessage()!=='qa_wp_die'){throw $e;}}
    check($captured['args']['response']===200&&str_contains($captured['message'],'Abrir &amp; continuar'),'confirmacao_pagina_configurada');
    delete_transient('f3base_confirmacao_'.$ref);
    try{F3Base_Confirmacao::pagina();}catch(RuntimeException $e){if($e->getMessage()!=='qa_wp_die'){throw $e;}}
    check($captured['args']['response']===410&&str_contains($captured['message'],'Exemplo: Esta confirmação expirou.'),'confirmacao_expirada_configurada');
    $mail=F3Base_Email_Novo_Lead::definicao()['padrao'];$mail['origem_meta']='pela {origem}';
    check(F3Base_Email_Novo_Lead::substituir('Recebemos {origem}.',array('nome'=>'Ana','origem_nativa'=>array('origem'=>'meta')),$mail)==='Recebemos pela Meta.','origem_sem_autorreferencia');
} finally {save('f3base_contato',$before);}
evidence('textos-1430');
