# Fator3 MCP 0.29.0

Atualização direta da 0.28.0 e instalação limpa. Mínimos WordPress 7.1.2 / PHP 8.3.6. Acompanhantes validados no laboratório: Site Core 1.48.0, MCP Google 0.17.0, MCP Meta 0.6.0 e MCP LinkedIn 0.7.0. Sem tabela, migração, opção, credencial, cron ou consentimento novo. As três metatools, o contrato humano `mutation-audit/1.0.0` e o de serviço `mutation-service-audit/1.0.0` permanecem.

## M1 — chamada nativa de administrador a habilidade aderente

Antes: com o MCP ativo, a tela de um provedor aderente (Site Core, Google, Meta, LinkedIn) que executava a própria habilidade pelo Abilities API recebia `profile_denied`, porque a sessão do navegador não tem política de conexão MCP. Sem o MCP, a mesma chamada chegava ao domínio.

Agora a política de conexão deixa a decisão ao `permission_callback` do domínio quando todas as condições valem:

- a habilidade pertence a provedor aderente registrado que não é o próprio MCP, está decorada e não é executor;
- o usuário tem `manage_options` e não há identidade de transporte na requisição (senha de aplicativo, token OAuth ou identidade de job interno);
- nenhuma chamada `tools/call` do servidor MCP está aberta e a rota não é endpoint MCP;
- requisição web administrativa (nunca linha de comando): leitura de tela do wp-admin (GET/HEAD) só para habilidades de leitura; admin-post ou admin-ajax depois de nonce aceito por `check_admin_referer`/`check_ajax_referer` na mesma requisição; REST autenticado pelo cookie de login com nonce `wp_rest` válido.

Nada é gravado: não se cria política para `integration:user:N`. Continuam exigindo política de conexão: habilidades do próprio MCP (`files/`, `db/`, `users/`, `backups/`, `options/`, `plugins/`, `content/` etc.), executores, confirmações destrutivas em duas fases do MCP, senha de aplicativo, OAuth, CLI, cron e qualquer POST administrativo sem nonce verificado. A chamada fica registrada na auditoria com a identidade `integration:user:N`.

## M2 — descoberta: busca e custo

`query` ignora acentos e maiúsculas e aceita vários termos em qualquer ordem; todos precisam aparecer em nome, rótulo, descrição, categoria ou provedor. Um termo único mantém a semântica de substring da 0.28.0 (todo resultado antigo continua no resultado novo). Os filtros baratos (prefixo, categoria, provedor, leitura, termos) rodam antes da política; a política roda uma vez por habilidade (a 0.28.0 avaliava duas) e a identidade da conexão é resolvida uma vez por listagem. Em laboratório, a listagem completa de 708 habilidades caiu de cerca de 1 s para cerca de 50 ms dentro do PHP, com resultado idêntico ao algoritmo anterior para os perfis Manutenção, Leitura, Conteúdo e Personalizado.

## M3 — descrições de parâmetros em português

Os parâmetros das três metatools e do executor de leitura têm descrição em português. As 188 descrições em inglês das habilidades próprias foram traduzidas por correspondência exata (`includes/property-descriptions-pt_BR.json`); nomes de parâmetros não mudam. Descrições de provedores terceiros não são alteradas. O `schema_sha256` dessas habilidades muda porque o texto mudou.

## M4 — idempotência e falha transitória

Falha com `retryable:true` sem efeito (`applied`, `persisted` e `changed` diferentes de true; código diferente de `operation_uncertain`) não consome a chave: repetir a mesma chamada com a mesma `idempotency_key` executa de novo. Falha definitiva, resultado aplicado, incerto ou concluído continuam reproduzidos com `replayed:true`. Uma falha transitória gravada pela 0.28.0 é liberada na próxima chamada com o mesmo conteúdo.

## M5 — pesquisa na documentação instalada

`system/guide` com `query` (2 a 200 caracteres) devolve seções de todos os documentos instalados onde todos os termos aparecem, sem diferença de acento ou caixa. Cada item traz documento, seção, linha, trecho, `offset_bytes`, `document_sha256` e `cursor`. Leia com `system/guide {"document": ID, "cursor": CURSOR}` e continue por `next_cursor`. `document` restringe a um documento; `limit` (1 a 50, padrão 20) limita a resposta e `truncated` informa o corte. Sem chamada a fornecedor e sem alteração de estado.

## M6 — descoberta por provedor e com schemas

`provider` filtra pelo slug exato do pacote (ex.: `wp-mcp-meta-fator3`). `include_schemas:true` acrescenta `input_schema` e `output_schema` efetivos de cada item, os mesmos de Get Ability Info, com no máximo 25 itens por página (`per_page_effective`). Uma chamada substitui até 25 chamadas de Get Ability Info.

## M7 — tela Conexões sem aviso de PHP

Conexões sem rótulo (forma gravada quando uma concessão OAuth materializa a política) geravam `Undefined array key "label"` na lista e na edição da aba Conexões. A tela mostra "Cliente sem nome" sem aviso. A leitura do leitor de serviço e do leitor humano do LinkedIn confere a existência da habilidade antes de buscá-la, sem aviso `get_registered` quando o leitor está ausente.

## Compatibilidade e volta

Clientes antigos continuam válidos: os parâmetros novos são opcionais e os resultados só ganham campos. Voltar à 0.28.0 restaura a recusa `profile_denied` nas telas dos provedores com o MCP ativo, a busca por substring e a reprodução de falhas transitórias; nenhum dado precisa ser migrado de volta.
