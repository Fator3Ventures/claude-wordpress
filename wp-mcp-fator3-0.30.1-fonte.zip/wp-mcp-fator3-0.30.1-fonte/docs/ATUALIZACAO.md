# Atualização para Fator3 MCP 0.28.0

> Vigente: MCP 0.28.0, base 0.27.0; Core 1.47.0, Google 0.17.0, Meta 0.5.0 e LinkedIn 0.7.0. Pedido 65: consulte RELEASE-0280 e MUTATION-SERVICE-AUDIT. Pedidos 63/64 aceitos conforme aba recebida, inclusive conector Claude real. Mínimos WordPress 7.1.2/PHP 8.3.6.
Bases aceitas: WordPress limpo ou MCP 0.26.1, sem trava por versão de origem e sem dependência de presença, versão ou ordem de Core/Google. O schema permanece 2 e policy_contract permanece 1.

1. Confirme o SHA-256 do instalador entregue.
2. Instalação limpa: envie `wp-mcp-fator3-0.27.0-instalador.zip` ao wp-admin, ative e configure conexão/perfil explicitamente.
3. Atualização da 0.26.1: use `plugins/upload` com URL HTTPS, `expected_sha256`, `expected_slug:wp-mcp-fator3`, `overwrite:true`, ou a rota de upload em base64/arquivo já disponível. O executor 0.26.1 preserva pré-imagem e diário; a nova requisição confirma a 0.27.0.
4. Consulte `plugins/operation-status` se a verificação ficar pendente. `plugins/reconcile` repete a verificação sob autorização própria. `plugins/rollback dry_run:true` verifica o retorno de arquivos sem aplicá-lo.
5. Releia `system/capabilities`, `system/health` e o catálogo. Confirme identidade, versões observadas e agenda; diagnóstico não repara cron.

A inicialização não importa opções/transientes antigos, não recaptura credenciais nem renova tokens. Conexões atuais, restrições, revogações, auditoria SQL, backups privados e operações da 0.26.1 permanecem. Acervo histórico não é apagado nem convertido. Importadores e rotas de acervo anterior foram retirados; não há caminho por pacotes intermediários.

`ReleaseState` usa apenas `release-state/current`. Schema desconhecido ou falha de persistência é recusado explicitamente. Falha de verificação de pacote preserva o diário e a pré-imagem conforme o contrato corrente; rollback de arquivos não desfaz migrações de banco dos companheiros.

`Update URI: https://fator3.com.br/plugins/wp-mcp-fator3` identifica o pacote; não publica feed automaticamente. `requires.plugins` de manifesto é descritivo e não impede ofertas. WordPress/PHP, origem HTTPS e digest continuam sendo verificados.

O instalador contém somente MCP. Acompanhantes desta rodada: Core 1.46.1, Google 0.17.0, Meta 0.4.1 e LinkedIn 0.5.0. Não são dependências obrigatórias. Consulte RELEASE-0261.md para os contratos corrigidos, política dos registros idempotentes antigos e aceites externos pendentes. Não desinstale plugins para atualizar.

A resposta da troca pode ter sido produzida pelo executor anterior. Confirme a versão e as sondas em uma requisição nova. A correção de projeção do pedido 61 permanece; registros antigos já redigidos não são reconstruídos.

A administração do pedido 62 está descrita em ADMINISTRACAO.md. A tela Atualizações salva somente o canal do MCP e preserva os canais já configurados dos demais pacotes. Nenhuma configuração ou fonte de distribuição é habilitada automaticamente.

As referências de mutação usam o bucket audit existente, sem alteração de schema. Nenhum snapshot do LinkedIn é copiado. Rollback para 0.26.1 mantém o Registro humano, mas remove a nova consulta de falhas e restaura a recusa de capacidades extras no CIMD. Não desfaça alterações do diário do provedor. Sem backfill de eventos históricos.
