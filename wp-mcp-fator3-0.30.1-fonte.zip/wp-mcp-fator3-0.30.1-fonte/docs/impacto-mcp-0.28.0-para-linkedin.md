# Impacto de Fator3 MCP 0.28.0 em wp-mcp-linkedin-fator3

Data: 2026-10-22 · Revisão 2 · Etapa entrega · Situação resolvido no escopo técnico.
Classificação: validacao-coordenada. Natureza: contrato e auditoria de serviço.
Base MCP 0.27.0; alvo entregue 0.28.0, instalador de 853885 bytes, SHA-256 d1d297d8aaee0e5188b92fe9eae20a9dcc07e79d639baae25f267bf64f7243b0. Destinatário examinado: LinkedIn 0.7.0, instalador SHA-256 85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515.
Pedidos MCP 65 e MCP LinkedIn 8(d); resposta ao impacto LinkedIn revisão 3 e evolução da proposta MCP 0.27.0 revisão 2.

## Decisão e contrato

O mantenedor MCP aceita o descritor fechado de seis campos, hook f3_mcp_register_mutation_service_audit com contrato e dois callables locais, introspector f3_linkedin_introspect_service_grant e recibo com recorded/event_sha256. O canal registrará somente evento exato comprovado pelo introspector, sob chave site/provider/principal_ref/operation_id. Concessão e revisão opacas, user=0, sem identidade humana assumida, snapshot, payload ou segredo no armazenamento central. Consulta nova audit/get-service-operation de cinco campos encaminha ao leitor público linkedin/get-service-write-operation, com manage_options, perfil e gates do domínio. Registro administrativo mostrará principal de serviço e antes/depois técnico.

## Consequência e sequência

LinkedIn 0.7.0 pode preceder o canal. Com MCP 0.28.0, o bootstrap PHP confirma a admissão; recorded exige hash do evento efetivamente persistido. Registro negado/indisponível não altera o resultado comercial nem autoriza reenvio. Sem backfill dos diários anteriores. Revogação/perda de revisão ou leitor conserva metadados e bloqueia detalhes. O contrato humano permanece independente. Core não precisa alterar consumidor/filas nem emitir auditoria.

## Aceite e responsáveis

MCP implementará e testará as interfaces reais dos dois pacotes com fornecedor simulado: usuário zero e incidental, digest, recibo, leitura central e painel, revogação/perfil/ativo, replay confirmado e incerto, falha sem reenvio, retenção. Evidência planejada ainda não executada. Não há adaptação de código requerida no LinkedIn para o contrato aceito; o dono/revisor confere a prova conjunta e encerra os pedidos na aba central. Conversão real continua fora desta validação.

## Evolução

Revisão 1: planejamento anterior à implementação, aceitação da contraproposta pública. Documento preparado para o dono, sem envio a terceiros.

## Revisão 2 — implementação e aceite conjunto

Contrato implementado conforme a contraproposta recebida, sem mudança requerida no LinkedIn 0.7.0. Interfaces do domínio e consumidor central reais: 54 verificações locais de serviço, 32 regressões humanas e 8 de apresentação, zero falhas. No Site-Teste, MCP 0.27.0 → 0.28.0 pela operação ab473c9a321d8dbf39b41e35a133b33a, backup 210a2dce49261d5a80464336. O mesmo hash passou pela instalação limpa isolada, mínimos WP 7.1.2/PHP 8.3.6 e atualização direta.

35 verificações no Site-Teste, quatro POST sintéticos e zero chamadas reais ao LinkedIn. Serviço como usuário zero e incidental produziu central_audit=recorded; reference principal_type=service/user=0, digest exato e concessão opaca. Recibos confirmado/incerto consultados por audit/get-service-operation. Replay sem POST/hook extra; identidade/digest/campo extra falsos recusados; revogação conserva referência e nega detalhe. UI mostra “Serviço — site-core-conversions” e link próprio; após limpar concessão, leitura falha fechada. Prova adicional local: autorização dos dois leitores, outro administrador, assinante, perda de escopo, leitor ausente, SQL indisponível e retenção normal.

Status LinkedIn depois da troca: domain_implemented=true, central_registered=true, central_audit=service_provider_registered na consulta de capacidades; recorded foi confirmado por operação antes da limpeza. Não confundir status de admissão sem operação com falta de implementação. O auxiliar temporário e a configuração sintética foram removidos; referências de auditoria e backups administrativos permanecem. 24 documentos instalados, 26 páginas, bytes/hash iguais.

Encaminhamento original resolvido tecnicamente: MCP aceitou e implementou o handshake/recibo público; nenhuma adaptação do Core/LinkedIn é necessária para esta combinação. Dono/revisor faz o encerramento editorial de MCP 65/LinkedIn 8(d) e decide distribuição. Conversão comercial real, produto/escopos externos e ativos da frota permanecem no escopo dos responsáveis originais. Nenhum relatório foi enviado a terceiros.
