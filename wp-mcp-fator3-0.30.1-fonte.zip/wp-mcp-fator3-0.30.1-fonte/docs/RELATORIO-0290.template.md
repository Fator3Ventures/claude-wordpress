# Entrega — Fator3 MCP 0.29.0

Revisão 1 · {{DATE}} · America/Sao_Paulo · Rodada: implementação.
Slug: `wp-mcp-fator3` · Versão: `0.29.0` · Status: **com-pendencias** — implementação e provas locais em WordPress real concluídas sem falha; instalação no Site-Teste, conector Claude real e distribuição na frota não foram executados nesta rodada.

{{REPORT_COPY_NOTE}}

## 1. De onde esta versão entra

Instalação limpa e atualização direta da **0.28.0** (instalador 853885 bytes, SHA-256 `d1d297d8aaee0e5188b92fe9eae20a9dcc07e79d639baae25f267bf64f7243b0`; fonte 3543405 bytes, `1b446b52c649e791407484702df5ddf280cb8e21b7b4d0a5f6508f4b304111ed`). Não há versão intermediária. A frota tem a 0.28.0 nos 12 sites (aba Pedidos MCP, 22/10/2026), sem pedido aberto.

Origem da rodada: ordem do dono de 22/10/2026 para melhorar código, testes e funcionalidades dos cinco pacotes, e pedido complementar do coordenador com o achado da chamada nativa de administrador (M1). As melhorias são numeradas M1 a M7; não há número de pedido na aba MCP. Exceção registrada pela mesma ordem: entrega de três arquivos, com as consequências para outros pacotes na seção 2, sem arquivo de impacto separado.

Mínimos declarados e executados: **WordPress 7.1.2 e PHP 8.3.6** (instalação limpa em 7.1.2 e 7.1.3; PHP 8.3.6 64 bits; MySQL 8.0.46). Identidade preservada: nome Fator3 MCP, slug/pasta/provider `wp-mcp-fator3`, basename `wp-mcp-fator3/wp-mcp-fator3.php`, namespaces, Text Domain, Update URI, rotas, opções, tabelas e IDs das habilidades. As três metatools permanecem; os parâmetros novos são opcionais.

## 2. Convivência e encaminhamentos

Laboratório integrado com os instaladores originais recebidos:

| Pacote | Versão | SHA-256 do instalador | Resultado com o candidato |
|---|---|---|---|
| Fator3 Site Core | 1.48.0 | `91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de` | ativo; sem mudança requerida |
| Fator3 MCP Google | 0.17.0 | `42bd11080b518c82e0960753fa7b08d7adae28743cfcd3e96f9b83bf3f4709b0` | ativo; sem mudança requerida |
| Fator3 MCP Meta | 0.6.0 | `36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69` | ativo; sem mudança requerida |
| Fator3 MCP LinkedIn | 0.7.0 | `85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515` | ativo; contratos humano e de serviço em regressão sem falha |

Ordem de troca: nenhuma exigida. A 0.29.0 não muda contrato consumido pelos acompanhantes; pode entrar antes ou depois deles.

**Site Core (consequência de M1).** Com a 0.28.0 ativa, as telas do Core que executam habilidade aderente pelo Abilities API recebiam `profile_denied`: `F3Base_Linkedin_Cliente::catalogo` → `linkedin/admin-options` (botão "Atualizar campanhas da conta" e seleção de formulários com o cliente do plugin LinkedIn) e `F3Base_Anuncios_Selecao` → `ads/search` (campanhas e formulários do Google Ads), ambas por admin-ajax com `check_ajax_referer`. Na 0.29.0 essas chamadas chegam ao domínio quando o usuário tem `manage_options`. A correção é do MCP; o Core 1.49.0 só precisa exibir com clareza os códigos de recusa que continuam possíveis fora desse contexto (`profile_denied`, `connection_context_required`). Com o MCP 0.28.0, as telas continuam recusadas. Prova: `linkedin/admin-options` real devolveu `not_configured` (decisão do domínio) por admin-ajax com nonce; `ads/search` devolveu `permission_denied` do próprio Google, sem configuração do Ads no laboratório, antes e depois — o caminho com Google Ads configurado não foi exercitado.

**LinkedIn.** `mutation-audit/1.0.0` e `mutation-service-audit/1.0.0` intactos; suíte de serviço (54 verificações) e contrato humano (32) da 0.28.0 sem falha contra o candidato, com LinkedIn 0.7.0 real e HTTP LinkedIn sintético.

**Google.** As ferramentas próprias do Google expostas no `tools/list` (`google-mcp-read`, `google-mcp-write`) têm descrições de parâmetros fora do português; M3 traduz somente schemas do MCP e não altera provedor terceiro. Observação ao mantenedor Google, sem ação exigida do MCP.

**Meta.** Sem mudança. M4 não altera a reprodução de resultado concluído: para observar o estado atual por `meta/status`, continue omitindo `idempotency_key`.

Implantador não recebido: não avaliado. Nenhum pacote alheio, documento central, site da frota ou Site-Teste foi alterado.

## 3. Mudanças e evidência

| Item | Problema na 0.28.0 | Mudança | Resultado e evidência |
|---|---|---|---|
| M1 — chamada nativa de administrador | Tela de provedor aderente que executava a própria habilidade pelo Abilities API recebia `profile_denied` com o MCP ativo; a sessão do navegador não tem política de conexão. | `NativeAdminCall`: a política de conexão deixa a decisão ao `permission_callback` do domínio só para habilidade de provedor aderente (não do MCP, não executor), usuário com `manage_options`, sem senha de aplicativo/OAuth/job, sem `tools/call` aberto nem rota MCP, em requisição web administrativa: tela wp-admin GET/HEAD (só leitura), admin-post/admin-ajax após nonce aceito por `check_admin_referer`/`check_ajax_referer`, REST com cookie e nonce `wp_rest`. Nada é gravado; CLI e cron seguem a política. | {{M1}} |
| M2 — busca e custo da descoberta | `query` por substring de bytes: "CONVERSÃO" e "conversao" não achavam "conversão"; termos fora de ordem não casavam. A política era avaliada duas vezes por habilidade e a identidade da conexão relida a cada avaliação. | Busca sem acento nem caixa, vários termos em qualquer ordem (superconjunto da 0.28.0); filtros baratos antes da política; uma avaliação por habilidade; identidade resolvida uma vez por listagem. | {{M2}} |
| M3 — parâmetros em português | Parâmetros das metatools vazios ou em inglês; 188 descrições em inglês nas habilidades próprias. | `includes/property-descriptions-pt_BR.json`: tradução por correspondência exata e descrições das metatools. Nomes de parâmetros inalterados. | {{M3}} |
| M4 — falha transitória e idempotência | Falha `retryable:true` sem efeito ficava gravada; repetir com a mesma `idempotency_key` reproduzia a falha para sempre. | Falha transitória sem efeito libera a chave, inclusive registro deixado pela 0.28.0; concluído, definitivo, aplicado ou incerto continua reproduzido. | {{M4}} |
| M5 — pesquisa na documentação | Achar um assunto exigia ler os 24 documentos página a página. | `system/guide` com `query` (e `document`, `limit`): seções onde todos os termos aparecem, com trecho, linha, `offset_bytes`, hash e `cursor` para a leitura paginada normal. Local, sem fornecedor. | {{M5}} |
| M6 — descoberta por provedor e com schemas | Para conhecer os schemas de um domínio, uma chamada de Get Ability Info por habilidade. | Filtro `provider` e `include_schemas` (até 25 por página, schemas iguais aos de Get Ability Info). | {{M6}} |
| M7 — tela Conexões | Conexão sem rótulo (forma gravada pela materialização de concessão OAuth) gerava `Undefined array key "label"` na lista e na edição; leitor de auditoria ausente gerava aviso `get_registered`. | Chaves opcionais protegidas; existência do leitor conferida antes da busca. | {{M7}} |

Testes novos que falham na 0.28.0 e passam na 0.29.0 (mesmo laboratório integrado, mesmo script):

{{BASELINE_TABLE}}

Desempenho medido (mesma máquina, laboratório integrado, 708 habilidades visíveis no perfil Manutenção): {{TIMING}}

Arquivos de runtime: {{INST_FILES}} ({{PHP_FILES}} PHP); dois adicionados (`includes/NativeAdminCall.php`, `includes/property-descriptions-pt_BR.json`), {{CHANGED}} alterados, nenhum removido.

## 4. Instalação e prova da troca

Instalação pela frota: publicar o instalador e este relatório na raiz de `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/`, conferir os bytes servidos e instalar com `plugins/upload` (ou `plugins/upload-base64`) usando `expected_slug: wp-mcp-fator3` e o `expected_sha256` da seção 8. Prontidão: `system/capabilities` com `plugin_version` 0.29.0; `system/health` com `healthy:true`; `system/guide {"document":"release-0290"}` legível; `system/guide {"query":"descoberta provedor"}` com resultado.

| Prova (WordPress real local) | Resultado | Limite |
|---|---|---|
{{PROOF_TABLE}}

Documentação: {{DOCS_HTTP}} Índice por `system/guide` sem argumentos; leitura por `document` + `cursor` + `byte_limit` até 32768; pesquisa por `query`. Recusa de identificador com caminho e de continuação com hash diferente comprovadas.

Todas as provas usaram exatamente o instalador da seção 8. Laboratórios descartáveis (banco e diretório novos por suíte), HTTP externo bloqueado e e-mail capturado; nenhum fornecedor real chamado. Estado final: nenhum site real alterado; laboratórios locais descartáveis permanecem fora dos pacotes.

## 5. Banco e volta de versão

Sem tabela, coluna, migração, opção, cron, credencial ou consentimento novo. Única mudança de gravação: a 0.29.0 apaga o registro de idempotência de uma falha transitória sem efeito (antes ficava gravado como concluído); registros concluídos, definitivos, aplicados ou incertos ficam como estavam. M1 não grava política nem perfil. A atualização direta preservou senha de aplicativo, concessão e tokens OAuth (validade sem extensão; renovação funcionando), prévia SQL pendente, recibo de conteúdo, backup privado, opções false/vazias e recibo incerto; cursor documental antigo é recusado; prévia de rollback confere a pré-imagem.

Volta para a 0.28.0 por arquivos: restaura a recusa `profile_denied` nas telas dos provedores com o MCP ativo, a busca por substring, a reprodução de falhas transitórias e o aviso na aba Conexões. Não há dado a desfazer. Backup de arquivos não é backup de banco; preserve banco e salts com o backup operacional e não desinstale para simular rollback.

## 6. O que permanece pendente

| Pendência | Responsável |
|---|---|
| Instalar no Site-Teste e repetir a prontidão e a leitura documental pelo conector WP MCP fator3-teste | Site Geral \| Todos / dono |
| Distribuição na frota com `expected_sha256`/`expected_slug` e retirada da 0.28.0 do `main` | Site Geral \| Todos / dono |
| Aceite em produção das telas do Core com MCP ativo (catálogo LinkedIn com cliente do plugin; Google Ads configurado) | dono / mantenedor Core |
| Conector Claude real (OAuth) contra a 0.29.0; navegador real na aba Conexões | dono |
| Multisite e PHP-FPM não homologados; PHP mínimo declarado = PHP executado (8.3.6) | mantenedor MCP |

Sem falha conhecida nas provas finais executadas.

## 7. Credenciais e configuração do dono

Nenhum campo, credencial ou consentimento novo. A atualização não reautoriza conexões nem amplia perfis. Perfis personalizados continuam exigindo autorização explícita de cada habilidade; os parâmetros novos de descoberta e documentação não exigem perfil diferente. A regra de M1 não depende de configuração: vale para administrador com `manage_options` na tela do provedor.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | wp-mcp-fator3-0.29.0-instalador.zip | {{INST_BYTES}} | `{{INST_SHA}}` |
| Fonte | wp-mcp-fator3-0.29.0-fonte.zip | {{SOURCE_BYTES}} | {{SOURCE_SHA}} |

Apenas o instalador é instalável (raiz `wp-mcp-fator3/`). O fonte tem raiz `wp-mcp-fator3-0.29.0-fonte/` com runtime, documentação, build, testes, kit de laboratório, evidências sanitizadas e a cópia deste relatório anterior ao fechamento. Nenhum ZIP contém outro ZIP. O fonte foi fechado uma vez e reproduz o instalador byte a byte.
