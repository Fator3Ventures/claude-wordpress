# Plano — Fator3 MCP 0.30.0

24/10/2026 UTC (23/10 no início da rodada, America/Sao_Paulo). Planejamento anterior à alteração do runtime. Base imutável 0.29.1; Pedido MCP 66, documento recebido Fator3 MCP(7).md. Aplicam-se as instruções comuns e padrão revisão 5 recebidos no fonte Meta 0.9.0.

Implementar media/convert: JPEG/PNG → novo WebP, título/alt/legenda copiados, derivados por MediaImages::generate, revisão obrigatória, autorização e travas existentes. A origem e seus arquivos são somente leitura; retornar hashes, bytes, economia (inclusive negativa), id e revisão novos. Recusar falta de suporte antes de criar arquivo/anexo. Falhas posteriores à criação devem identificar o novo anexo e os efeitos parciais para reconciliação; desfazer por media/delete em duas fases.

Verificar formatos reais, filtros de saída do editor, imagem grande, transparência, metadados, revisão obsoleta, autorização, repetição e falhas. Incluir caso em tools/lab/media.php. Testar instalação limpa/mínimos WP 7.1.2/PHP 8.3.6, atualização direta 0.29.1 e regressões das fronteiras compartilhadas. Conferir compatibilidade com Core 1.51.0, Google 0.19.0, Meta 0.9.0, LinkedIn 0.10.1 e Pipedrive 0.1.0; não alterar acompanhantes nem chamar fornecedores comerciais.

Instalar somente MCP no Site-Teste, validar JPEG/PNG, arquivos, preservação, saúde e documentação instalada; remover fixtures. A simulação de servidor sem WebP exige ambiente isolado, sem ampliar a superfície pública de execução. AWN: executar apenas se houver conexão autorizada disponível, revisando anexo 14/página 28 antes da conversão e patch; caso contrário registrar o limite e o procedimento de aceite.

Avaliação prévia de impacto: operação própria aditiva, sem alteração nos contratos dos acompanhantes, concessões, IDs, tokens, schema persistente ou configuração. Nenhuma adaptação obrigatória identificada em outro plugin; não emitir arquivos de impacto para comunicar versão ou fechamento. Reavaliar se os testes revelarem consequência técnica real. Evidência histórica permanece identificada como histórica; totais desta rodada serão separados.

Fechar instalador, testá-lo, fechar fonte uma única vez e calcular seu hash externamente. Entregar instalador, fonte e relatório com limites de prova, reversão e pendências; não publicar nem atualizar a frota.

## Ajuste de homologação e fechamento

A leitura real media/get não incluía revision. O instalador 0.30.0 já aplicado foi preservado; correção aditiva em 0.30.1, com trava de leitura e teste ler → converter → reler pelo MCP. Reexecutados mínimos, atualização direta e regressões usando o instalador final. Nenhuma adaptação em outro plugin decorreu do achado; continua sem relatório de impacto novo. Aceite AWN indisponível por conexão ausente; recusa sem WebP provada só em laboratório isolado.
