# Revisão independente — MCP 0.29.1

23/10/2026. Base recebida 0.29.0 preservada; referência anterior 0.28.0. Patch autorizado pelo pedido do dono.

Reprodução própria em WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46, com Core 1.48.0, Google 0.18.1, Meta 0.7.1 e LinkedIn 0.8.1:
- R1: mesma chave executou duas vezes quando applied faltava, era null, persisted/changed eram null ou partial era true. Controles applied=true e operation_uncertain não repetiram; ausência de efeito explicitamente declarada deve continuar permitindo repetição.
- R2: consulta com 13º termo inexistente ainda retornou resultados em descoberta e guia. O contrato promete todos os termos.
- R3: admin-post GET com nonce validado recusou escrita; sem nonce aceitou leitura como tela. A regra contratada exige nonce em admin-post.
- Um check CLI adicional falhou por preparação: setup criou política maintenance para usuário 1. O teste será executado como administrador nativo sem política; isso não é achado de produto.

Antes de código dependente: impactos individuais aos três provedores sobre R1; alerta ao Core sobre R3. Correções restauram proteção/documentação existentes, sem assinatura pública nova nem adaptação obrigatória dos destinatários. Não há conflito de contrato a resolver externamente.

Entradas Meta 0.6.0 e LinkedIn 0.7.0 preservadas em entradas/0291. Meta status continua escrita, health leitura. Handshake de serviço do LinkedIn já implementado em MCP 0.28.0; repetir com 0.8.1, não reabrir pedido pela previsão histórica.

Plano de prova: casos negativos acima, suite M1–M7, auditoria humana/serviço, documentos completos, instalação limpa nos mínimos, atualização direta 0.29.0 e 0.28.0, lint/build exato. Fornecedores simulados; nenhuma conversão ou mensagem real. Homologação remota somente do MCP, preservando os acompanhantes encontrados.
