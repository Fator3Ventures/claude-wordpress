# Fator3 MCP 0.30.1 — revisão pública do anexo

A 0.30.0 implementou o Pedido 66; a homologação pelo MCP real revelou que media/get não fornecia a revisão exigida pelo novo fluxo. A 0.30.1 acrescenta revision à resposta de media/get, sob trava de leitura do anexo e conferência antes/depois. Leitura que observa mudança externa retorna content_conflict; o cliente deve reler. Autorização, formato dos campos existentes e condição de leitura permanecem.

Fluxo validado: media/get {id} → guardar revision → media/convert {id,formato:"webp",expected_revision:revision} → media/get {id:novo_id}. A revision da conversão pertence ao novo anexo; source_revision permanece da origem. Demais contratos, economia, arquivos, erros e reversão constam em RELEASE-0300.md.

Atualização direta suportada da 0.29.1 e correção sobre 0.30.0, sem migração ou concessão nova. Usar instalador 0.30.1 com slug e SHA-256 do relatório. Prontidão: system/capabilities plugin_version=0.30.1, saúde normal e system/guide document=release-0301. A versão 0.30.0 permanece identificada como etapa intermediária da homologação; a entrega corrente é 0.30.1.
