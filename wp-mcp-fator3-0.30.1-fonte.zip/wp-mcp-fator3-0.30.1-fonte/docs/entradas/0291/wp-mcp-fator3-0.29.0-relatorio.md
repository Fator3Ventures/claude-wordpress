# Entrega — Fator3 MCP 0.29.0

Revisão 2 · 23/10/2026 00:01 · America/Sao_Paulo · Rodada: implementação. Revisão documental de 23/10/2026: acrescentada a prova integrada da rodada (seção 4), executada pelo orquestrador; instalador e fonte inalterados (seção 8).
Slug: `wp-mcp-fator3` · Versão: `0.29.0` · Status: **com-pendencias** — implementação e provas locais em WordPress real concluídas sem falha; instalação no Site-Teste, conector Claude real e distribuição na frota não foram executados nesta rodada.

Relatório externo canônico. A cópia dentro do fonte é a anterior ao fechamento; tamanho e SHA-256 do próprio fonte são completados somente aqui.

## 1. De onde esta versão entra

Instalação limpa e atualização direta da **0.28.0** (instalador 853885 bytes, SHA-256 `d1d297d8aaee0e5188b92fe9eae20a9dcc07e79d639baae25f267bf64f7243b0`; fonte 3543405 bytes, `1b446b52c649e791407484702df5ddf280cb8e21b7b4d0a5f6508f4b304111ed`). Não há versão intermediária. A frota tem a 0.28.0 nos 12 sites (aba Pedidos MCP, 22/10/2026), sem pedido aberto.

Origem da rodada: ordem do dono de 22/10/2026 para melhorar código, testes e funcionalidades dos cinco pacotes, e pedido complementar do coordenador com o achado da chamada nativa de administrador (M1). As melhorias são numeradas M1 a M7; não há número de pedido na aba MCP. Exceção registrada pela mesma ordem: entrega de três arquivos, com as consequências para outros pacotes na seção 2, sem arquivo de impacto separado.

Mínimos declarados e executados: **WordPress 7.1.2 e PHP 8.3.6** (instalação limpa em 7.1.2 e 7.1.3; PHP 8.3.6 64 bits; MySQL 8.0.46). Identidade preservada: nome Fator3 MCP, slug/pasta/provider `wp-mcp-fator3`, basename `wp-mcp-fator3/wp-mcp-fator3.php`, namespaces, Text Domain, Update URI, rotas, opções, tabelas e IDs das habilidades. As três metatools permanecem; os parâmetros novos são opcionais.

## 2. Convivência e encaminhamentos

Laboratório integrado com os instaladores originais recebidos:

| Pacote | Versão | SHA-256 do instalador | Resultado com o candidato |
|---|---|---|---|
| Fator3 Site Core | 1.48.0 | `91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de` | ativo; sem mudança requerida |
| Fator3 MCP Google | 0.17.0 | `42bd11080b518c82e0960753fa7b08d7adae28743cfcd3e96f9b83bf3f4709b0` | ativo; sem mudança requerida |
| Fator3 MCP Meta | 0.6.0 | `36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69` | ativo; sem mudança requerida |
| Fator3 MCP LinkedIn | 0.7.0 | `85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515` | ativo; contratos humano e de serviço em regressão sem falha |

Ordem de troca: nenhuma exigida. A 0.29.0 não muda contrato consumido pelos acompanhantes; pode entrar antes ou depois deles.

**Site Core (consequência de M1).** Com a 0.28.0 ativa, as telas do Core que executam habilidade aderente pelo Abilities API recebiam `profile_denied`: `F3Base_Linkedin_Cliente::catalogo` → `linkedin/admin-options` (botão "Atualizar campanhas da conta" e seleção de formulários com o cliente do plugin LinkedIn) e `F3Base_Anuncios_Selecao` → `ads/search` (campanhas e formulários do Google Ads), ambas por admin-ajax com `check_ajax_referer`. Na 0.29.0 essas chamadas chegam ao domínio quando o usuário tem `manage_options`. A correção é do MCP; o Core 1.49.0 só precisa exibir com clareza os códigos de recusa que continuam possíveis fora desse contexto (`profile_denied`, `connection_context_required`). Com o MCP 0.28.0, as telas continuam recusadas. Prova: `linkedin/admin-options` real devolveu `not_configured` (decisão do domínio) por admin-ajax com nonce; `ads/search` devolveu `permission_denied` do próprio Google, sem configuração do Ads no laboratório, antes e depois — o caminho com Google Ads configurado não foi exercitado.

**LinkedIn.** `mutation-audit/1.0.0` e `mutation-service-audit/1.0.0` intactos; suíte de serviço (54 verificações) e contrato humano (32) da 0.28.0 sem falha contra o candidato, com LinkedIn 0.7.0 real e HTTP LinkedIn sintético.

**Google.** As ferramentas próprias do Google expostas no `tools/list` (`google-mcp-read`, `google-mcp-write`) têm descrições de parâmetros fora do português; M3 traduz somente schemas do MCP e não altera provedor terceiro. Observação ao mantenedor Google, sem ação exigida do MCP.

**Meta.** Sem mudança. M4 não altera a reprodução de resultado concluído: para observar o estado atual por `meta/status`, continue omitindo `idempotency_key`.

Implantador não recebido: não avaliado. Nenhum pacote alheio, documento central, site da frota ou Site-Teste foi alterado.

## 3. Mudanças e evidência

| Item | Problema na 0.28.0 | Mudança | Resultado e evidência |
|---|---|---|---|
| M1 — chamada nativa de administrador | Tela de provedor aderente que executava a própria habilidade pelo Abilities API recebia `profile_denied` com o MCP ativo; a sessão do navegador não tem política de conexão. | `NativeAdminCall`: a política de conexão deixa a decisão ao `permission_callback` do domínio só para habilidade de provedor aderente (não do MCP, não executor), usuário com `manage_options`, sem senha de aplicativo/OAuth/job, sem `tools/call` aberto nem rota MCP, em requisição web administrativa: tela wp-admin GET/HEAD (só leitura), admin-post/admin-ajax após nonce aceito por `check_admin_referer`/`check_ajax_referer`, REST com cookie e nonce `wp_rest`. Nada é gravado; CLI e cron seguem a política. | `native-admin`: 24 verificações, 0 falhas, por HTTP real (admin-ajax, admin-post, tela, REST, senha de aplicativo, OAuth). Na 0.28.0: 6 casos nativos recusados com `profile_denied`; recusas para editor, assinante, sem nonce, nonce inválido, POST sem nonce, habilidade do MCP, executor, senha de aplicativo sem política, OAuth Leitura e linha de comando mantidas; nenhuma política criada para `integration:user:1`. |
| M2 — busca e custo da descoberta | `query` por substring de bytes: "CONVERSÃO" e "conversao" não achavam "conversão"; termos fora de ordem não casavam. A política era avaliada duas vezes por habilidade e a identidade da conexão relida a cada avaliação. | Busca sem acento nem caixa, vários termos em qualquer ordem (superconjunto da 0.28.0); filtros baratos antes da política; uma avaliação por habilidade; identidade resolvida uma vez por listagem. | `discovery`: 17 verificações, 0 falhas; `discovery-equivalence`: 17, 0 falhas — linhas idênticas ao algoritmo da 0.28.0 em 4 perfis × 4 filtros. Na 0.28.0, "CONVERSÃO" achou 0 de 9 e "campanha criar" achou 0. |
| M3 — parâmetros em português | Parâmetros das metatools vazios ou em inglês; 188 descrições em inglês nas habilidades próprias. | `includes/property-descriptions-pt_BR.json`: tradução por correspondência exata e descrições das metatools. Nomes de parâmetros inalterados. | Todas as propriedades das metatools com descrição em português e nenhuma das 188 descrições catalogadas restante. Na 0.28.0: 228 propriedades das habilidades próprias com descrição em inglês (188 textos distintos) e parâmetros das metatools sem descrição. |
| M4 — falha transitória e idempotência | Falha `retryable:true` sem efeito ficava gravada; repetir com a mesma `idempotency_key` reproduzia a falha para sempre. | Falha transitória sem efeito libera a chave, inclusive registro deixado pela 0.28.0; concluído, definitivo, aplicado ou incerto continua reproduzido. | `idempotency`: 7 verificações, 0 falhas, por MCP HTTP. Na 0.28.0: 3 falhas (segunda chamada reproduzia a falha, registro antigo bloqueava a chave). |
| M5 — pesquisa na documentação | Achar um assunto exigia ler os 24 documentos página a página. | `system/guide` com `query` (e `document`, `limit`): seções onde todos os termos aparecem, com trecho, linha, `offset_bytes`, hash e `cursor` para a leitura paginada normal. Local, sem fornecedor. | `guide-search`: 11 verificações, 0 falhas; cursor abre a seção com hash conferido; nenhuma requisição HTTP durante pesquisa e leitura. Inexistente na 0.28.0 (10 falhas). |
| M6 — descoberta por provedor e com schemas | Para conhecer os schemas de um domínio, uma chamada de Get Ability Info por habilidade. | Filtro `provider` e `include_schemas` (até 25 por página, schemas iguais aos de Get Ability Info). | Incluídas em `discovery`: filtro `provider` devolve exatamente as 33 habilidades Meta; `include_schemas` pagina 33 itens em 2 páginas de até 25 e devolve schemas iguais aos de Get Ability Info; `if_catalog_sha256` mantém `unchanged`. Na 0.28.0 os parâmetros eram recusados pelo schema. |
| M7 — tela Conexões | Conexão sem rótulo (forma gravada pela materialização de concessão OAuth) gerava `Undefined array key "label"` na lista e na edição; leitor de auditoria ausente gerava aviso `get_registered`. | Chaves opcionais protegidas; existência do leitor conferida antes da busca. | `admin-render`: 3 verificações, 0 falhas, renderização real da aba (lista e edição). Na 0.28.0: aviso `Undefined array key "label"`. Leitor ausente sem aviso na suíte de serviço. |

Testes novos que falham na 0.28.0 e passam na 0.29.0 (mesmo laboratório integrado, mesmo script):

| Script | Verificações | Falhas na 0.28.0 | Falhas na 0.29.0 |
|---|---:|---:|---:|
| native-admin | 24 | 7 | 0 |
| idempotency | 7 | 3 | 0 |
| discovery | 17 | 10 | 0 |
| guide-search | 11 | 10 | 0 |
| admin-render | 3 | 1 | 0 |

Na 0.28.0, `native-admin` inclui uma verificação de API nova (classe `NativeAdminCall`) além dos casos funcionais.

Desempenho medido (mesma máquina, laboratório integrado, 708 habilidades visíveis no perfil Manutenção): listagem completa dentro do PHP, mediana de 3: 0.28.0 968 ms → 0.29.0 75.3 ms; prefixo `meta/`: 933.4 ms → 4.8 ms. Catálogo inteiro por MCP HTTP (4 páginas de 200, uma execução cada): 0.28.0 5665 ms → 0.29.0 2658 ms.

Arquivos de runtime: 461 (451 PHP); dois adicionados (`includes/NativeAdminCall.php`, `includes/property-descriptions-pt_BR.json`), 13 alterados, nenhum removido.

## 4. Instalação e prova da troca

Instalação pela frota: publicar o instalador e este relatório na raiz de `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/`, conferir os bytes servidos e instalar com `plugins/upload` (ou `plugins/upload-base64`) usando `expected_slug: wp-mcp-fator3` e o `expected_sha256` da seção 8. Prontidão: `system/capabilities` com `plugin_version` 0.29.0; `system/health` com `healthy:true`; `system/guide {"document":"release-0290"}` legível; `system/guide {"query":"descoberta provedor"}` com resultado.

| Prova (WordPress real local) | Resultado | Limite |
|---|---|---|
| Testes novos M1–M7 com os quatro acompanhantes ativos (WordPress 7.1.3) | 107 verificações, 0 falhas | fornecedores e e-mail interceptados |
| Regressão da 0.28.0: ativação nativa, serviço LinkedIn, contrato humano, idioma, documentos | 4+54+32+8+26 verificações, 0 falhas | LinkedIn 0.7.0 real; HTTP LinkedIn sintético |
| Instalação limpa, só o MCP, WordPress 7.1.3 | 13 verificações, 0 falhas | ativação num processo, leitura e HTTP MCP em processo novo |
| Instalação limpa, só o MCP, WordPress 7.1.2 (mínimo) | 13 verificações, 0 falhas | mesmo roteiro |
| Atualização direta 0.28.0 → 0.29.0 pelo próprio MCP (`plugins/upload-base64` por HTTP) | 22 verificações, 0 falhas | 4 workers do servidor embutido; rollback só em prévia |
| Pacote: reconstrução byte a byte, recusas de variantes, `php -l` de 451 PHP, cabeçalho, ausência de segredo | 15/15 | PHP 8.3.6 |
| debug.log dos laboratórios do candidato | nenhum notice/warning/deprecation do `wp-mcp-fator3` | avisos `f3base` de tradução antecipada pertencem ao Site Core |

Documentação: 25 documentos instalados lidos inteiros por MCP HTTP em 27 páginas, 198166 bytes, todos idênticos à documentação compilada. Índice por `system/guide` sem argumentos; leitura por `document` + `cursor` + `byte_limit` até 32768; pesquisa por `query`. Recusa de identificador com caminho e de continuação com hash diferente comprovadas.

Todas as provas usaram exatamente o instalador da seção 8. Laboratórios descartáveis (banco e diretório novos por suíte), HTTP externo bloqueado e e-mail capturado; nenhum fornecedor real chamado. Estado final: nenhum site real alterado; laboratórios locais descartáveis permanecem fora dos pacotes.


### Prova integrada da rodada (orquestrador, 23/10/2026)

Laboratório local descartável: WordPress 7.1.3, PHP 8.3.6, MySQL 8.0.46, servidor PHP com quatro processos, HTTP externo bloqueado e e-mail capturado. Instaladores finais desta rodada, conferidos pelo SHA-256 da seção 8 de cada relatório: Site Core 1.49.0 `64a80ede…8657`, MCP 0.29.0 `1720f2db…fb2a`, Google 0.18.0 `b1ce9085…aea9`, Meta 0.7.0 `727fab33…faa8`, LinkedIn 0.8.0 `035a84fe…8e35`. Leituras pelo transporte MCP HTTP real (senha de aplicativo temporária, perfil Manutenção).

| Cenário | Resultado |
|---|---|
| Atualização a partir do conjunto em uso (Core 1.48.0, MCP 0.28.0, Google 0.17.0, Meta 0.6.0, LinkedIn 0.7.0), um pacote por vez pelo `Plugin_Upgrader` nativo, na ordem MCP → LinkedIn → Meta → Google → Core | Cinco trocas aplicadas, plugins ativos antes e depois. Depois de cada troca, em requisições novas: `/`, `/wp-json/`, `/robots.txt`, `/wp-json/f3base/v1`, `/wp-cron.php` e dez telas do painel com HTTP 200, sem mensagem PHP na página. Ao final, 11 de 11 leituras de prontidão com sucesso: `system/health` (healthy), `google/selftest` (11 aprovadas), `google/status`, `google/readiness-status`, `meta/selftest`, `meta/health` (state ok), `linkedin/selftest`, `linkedin/status` (state ok), `linkedin/diagnose-conversions`, `f3base/saude-ler` (1.49.0), `f3base/conversoes-fila-ler`. |
| Instalação limpa dos cinco, ativação na ordem inversa (LinkedIn → Meta → Google → Core → MCP) | Ativação sem erro; as mesmas 11 leituras com sucesso em duas requisições novas seguidas; mesmas URLs e telas com HTTP 200. |
| `debug.log` | Com o conjunto em uso: 44 avisos `_load_textdomain_just_in_time` do domínio `f3base` por rodada de páginas. Depois da troca do LinkedIn: 1. Depois do Meta, do Google e do Core, e na instalação limpa: nenhum notice, warning, deprecation ou erro dos cinco pacotes. Restam só avisos do próprio WordPress por não alcançar wordpress.org no laboratório. |
| Documentação pelo MCP 0.29.0 | Índices dos cinco pacotes lidos. Um documento de release por pacote lido inteiro em páginas pequenas (`docs/RELEASE-1.49.0.md` 6 páginas, `GUIA-0.18.0.md` 6, `CHANGELOG.md` do Meta 6, `RELEASE-0.8.0.md` 3, `release-0290` 6): conteúdo remontado com o SHA-256 informado pela operação e, onde o documento é arquivo do instalador, igual ao arquivo do ZIP. |
| Catálogo LinkedIn do Core pela tela (admin-ajax com nonce) | MCP 0.28.0: `profile_denied`, a chamada não sai do canal. MCP 0.29.0 com Core 1.49.0: sem conta salva, `salve_a_conta` sem chamar o LinkedIn; com conta e conexão preenchidas, a chamada chega ao LinkedIn e volta com a decisão do domínio (`not_configured`, conexão sintética inexistente). |

Limites: sem conta real de fornecedor, sem Site-Teste, sem navegador real; o salto Core 1.47.0 → 1.49.0 (11 sites-alvo) não foi ensaiado porque o instalador 1.47.0 não estava disponível.

## 5. Banco e volta de versão

Sem tabela, coluna, migração, opção, cron, credencial ou consentimento novo. Única mudança de gravação: a 0.29.0 apaga o registro de idempotência de uma falha transitória sem efeito (antes ficava gravado como concluído); registros concluídos, definitivos, aplicados ou incertos ficam como estavam. M1 não grava política nem perfil. A atualização direta preservou senha de aplicativo, concessão e tokens OAuth (validade sem extensão; renovação funcionando), prévia SQL pendente, recibo de conteúdo, backup privado, opções false/vazias e recibo incerto; cursor documental antigo é recusado; prévia de rollback confere a pré-imagem.

Volta para a 0.28.0 por arquivos: restaura a recusa `profile_denied` nas telas dos provedores com o MCP ativo, a busca por substring, a reprodução de falhas transitórias e o aviso na aba Conexões. Não há dado a desfazer. Backup de arquivos não é backup de banco; preserve banco e salts com o backup operacional e não desinstale para simular rollback.

## 6. O que permanece pendente

| Pendência | Responsável |
|---|---|
| Instalar no Site-Teste e repetir a prontidão e a leitura documental pelo conector WP MCP fator3-teste | Site Geral \| Todos / dono |
| Distribuição na frota com `expected_sha256`/`expected_slug` e retirada da 0.28.0 do `main` | Site Geral \| Todos / dono |
| Aceite em produção das telas do Core com MCP ativo (catálogo LinkedIn com cliente do plugin; Google Ads configurado) | dono / mantenedor Core |
| Conector Claude real (OAuth) contra a 0.29.0; navegador real na aba Conexões | dono |
| Multisite e PHP-FPM não homologados; PHP mínimo declarado = PHP executado (8.3.6) | mantenedor MCP |

Sem falha conhecida nas provas finais executadas.

## 7. Credenciais e configuração do dono

Nenhum campo, credencial ou consentimento novo. A atualização não reautoriza conexões nem amplia perfis. Perfis personalizados continuam exigindo autorização explícita de cada habilidade; os parâmetros novos de descoberta e documentação não exigem perfil diferente. A regra de M1 não depende de configuração: vale para administrador com `manage_options` na tela do provedor.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | wp-mcp-fator3-0.29.0-instalador.zip | 870821 | `1720f2db05c5a6ee90d1269ebdc764c14fb6b60e2878f765cf1183093ef1fb2a` |
| Fonte | wp-mcp-fator3-0.29.0-fonte.zip | 3745528 | `c59bc9ff5afab9de2b55f58d57b1efc362791d10ae441ac69f6861c3d891ae2c` |

Apenas o instalador é instalável (raiz `wp-mcp-fator3/`). O fonte tem raiz `wp-mcp-fator3-0.29.0-fonte/` com runtime, documentação, build, testes, kit de laboratório, evidências sanitizadas e a cópia deste relatório anterior ao fechamento. Nenhum ZIP contém outro ZIP. O fonte foi fechado uma vez e reproduz o instalador byte a byte.
