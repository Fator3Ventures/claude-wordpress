# Entradas da rodada 0.29.0

Ordem do dono de 22/10/2026 (chat do projeto Orquestrador | Geral): analisar em conjunto os cinco pacotes e, para cada um, produzir nova versão com melhorias no código, nos testes e nas funcionalidades, entregando relatório, instalador e fonte. Exceção registrada por essa ordem: entrega só dos três arquivos; consequências para outro pacote ficam na seção 2 do relatório, sem arquivo de impacto separado.

Pedido complementar do coordenador da rodada (mesma data): achado medido no laboratório conjunto — com o MCP 0.28.0 ativo, chamada nativa de administrador a habilidade aderente (`linkedin/admin-options` pelo Abilities API) recebia `profile_denied` porque `ConnectionContext::get()` cria `integration:user:N` com perfil `unconfigured`; pedido de regra estreita para chamada nativa de administrador, com testes de recusa preservada. Implementado como M1.

Normas: 01-instrucoes-agentes-plugins-fator3 e 02-padrao-desenvolvimento-plugins-fator3, revisão 4 (16/10/2026), cópias em `docs/entradas/0270/`. Pedidos aos pacotes: aba Fator3 MCP sem pedido aberto em 22/10/2026; "Decidido não fazer" respeitado (sem rota de execução de PHP, sem rota frota, sem db/execute em uma fase, sem fonte de atualização publicada).

Artefatos recebidos e conferidos (bytes e SHA-256):

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| wp-mcp-fator3-0.28.0-instalador.zip | 853885 | `d1d297d8aaee0e5188b92fe9eae20a9dcc07e79d639baae25f267bf64f7243b0` |
| wp-mcp-fator3-0.28.0-fonte.zip | 3543405 | `1b446b52c649e791407484702df5ddf280cb8e21b7b4d0a5f6508f4b304111ed` |
| wp-mcp-fator3-0.28.0-relatorio.md | 14053 | `fd137dd34180c6f80c7e241645a830eeb33896898ce70620683ce85019b8a77f` |
| base-site-core-fator3-1.48.0-instalador.zip | 2217146 | `91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de` |
| wp-mcp-google-fator3-0.17.0-instalador.zip | 767299 | `42bd11080b518c82e0960753fa7b08d7adae28743cfcd3e96f9b83bf3f4709b0` |
| wp-mcp-meta-fator3-0.6.0-instalador.zip | 134999 | `36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69` |
| wp-mcp-linkedin-fator3-0.7.0-instalador.zip | 207524 | `85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515` |
| base-site-core-fator3-1.48.0-relatorio.md | 19826 | `59718ba4295da178380854534b1abe0e163ecba04b90c70fff516ccc5a701694` |
| wp-mcp-google-fator3-0.17.0-relatorio.md | 10466 | `7334f72f0406dccca508ef0d67273edd1ac8de9886429d187593a52d6d15a3b6` |
| wp-mcp-meta-fator3-0.6.0-relatorio.md | 20695 | `29cd7c8b6d102182d6de7dbeb612b6a37a00f0f0661d26e98314726aca2ece8c` |
| wp-mcp-linkedin-fator3-0.7.0-relatorio.md | 19547 | `2fab3885cd1dd06a085a28a7ac3f36763fbe01901a4f3f68f142912c1d017d4b` |
