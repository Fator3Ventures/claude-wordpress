# Entrega — Fator3 MCP 0.29.1

Revisão 2 · 23/10/2026 · Rodada: análise dos pedidos atuais e validação de compatibilidade.
Slug: `wp-mcp-fator3` · Versão corrente: **0.29.1**.
Status: **apta-no-escopo-testado**, com limites externos na seção 6.

**Conclusão desta rodada:** nenhuma alteração no MCP foi necessária. A aba `Fator3 MCP(6).md` declara nenhum pedido aberto; as versões atuais dos acompanhantes passaram nas fronteiras examinadas. Foram aprovadas **276 verificações finais próprias**, com zero falhas. A versão 0.30.0 não foi gerada. Fonte e instalador 0.29.1 permanecem byte a byte iguais à entrega anterior.

Este relatório externo substitui a revisão 1. A revisão 1 completa permanece congelada no fonte original e também no complemento de evidências desta rodada. A revisão 2 acrescenta os resultados atuais e conserva abaixo o histórico material da correção 0.29.1. Os 319 checks da revisão 1 são históricos e não são somados aos 276 atuais.

## 1. De onde esta versão entra

Base corrente: **MCP 0.29.1**, instalador de 873894 bytes, SHA-256 `1b627aec5c24dc88f52eaf6a0d34367437d7f9e7b599f9f07850567fd57610e6`. Fonte de 3945818 bytes, SHA-256 `99ea12645e25d75f2466feebc4ac146e776f33b398d74802f4f6a48327a4142a`.

Entradas atuais: `Fator3 MCP(6).md`; fontes, instaladores e relatórios de Google 0.19.0, Meta 0.8.0, LinkedIn 0.9.0 e Core 1.49.1; impacto MCP 0.29.1→Google revisão 2; instruções comuns e padrão de desenvolvimento revisão 4. Os anexos foram lidos localmente e preservados. Os hashes de todos os oito ZIPs acompanhantes conferem com seus relatórios. Cada arquivo do runtime dos instaladores também confere com o fonte correspondente; o fonte Google inclui ferramentas adicionais fora do runtime.

A aba recebida registra a implantação da 0.29.1 nos doze sites e o encerramento dos pedidos. Essa é evidência recebida do responsável pela frota. A prova remota própria desta rodada abrange somente o Site-Teste, onde 0.29.1 foi observada ativa antes e depois.

**Histórico da revisão 1:** revisão independente da 0.29.0; comparação com 0.28.0; correção de três defeitos e entrega da 0.29.1. Foram comprovadas instalação limpa em WordPress 7.1.3/7.1.2, atualização direta 0.29.0→0.29.1 e adicional 0.28.0→0.29.1, com PHP 8.3.6 e MySQL 8.0.46. Os mínimos permanecem WordPress 7.1.2 e PHP 8.3.6. Esta rodada não ampliou a janela de suporte.

## 2. Convivência e encaminhamentos

| Pacote | Versão testada nesta rodada | SHA-256 do instalador |
|---|---|---|
| Core | 1.49.1 | `4ad3be4159310578a2db47cf179d02fa061fb98021e2f66ca933b59e7db4fb40` |
| MCP Google | 0.19.0 | `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1` |
| MCP Meta | 0.8.0 | `36e4e098955576c3d43ea1b1bd2c14fe68608472b8666a652e84da5165ce25e1` |
| MCP LinkedIn | 0.9.0 | `d4857927ebacfca9321b79d13bc15f15c6969ae67047fd1793e509524b7a60f8` |

Essas quatro versões convivem com MCP 0.29.1 no laboratório e foram observadas ativas no Site-Teste. A instalação de cada acompanhante é trabalho de seu respectivo responsável; nenhuma foi feita por esta rodada.

Google 0.19.0 adiciona `google/rename-connection`, `google/plan-identity-change` e `google/switch-identity`. O MCP já fornece descoberta, schemas, política de conexão e idempotência compatíveis. As mudanças de fila em Meta/LinkedIn mantêm as interfaces de transporte/auditoria examinadas. As mudanças do Core preservam o contrato utilizado pelo MCP.

O impacto recebido MCP→Google já estava resolvido na 0.29.1. O relatório Google confirma a preservação da regra conservadora de repetição; essa regra foi revalidada nesta rodada. Respostas e encerramentos são registrados aqui. **Nenhum novo impacto técnico que exija encaminhamento foi identificado**, portanto não há novo relatório individual. Não se exige ordem conjunta de instalação por causa desta revisão de compatibilidade. Documentos centrais e pacotes acompanhantes permanecem sob seus responsáveis.

## 3. Mudanças e evidência

### Resultado da análise atual

Não há mudança em runtime, cabeçalho, versão, schemas ou documentação instalada do MCP. Os arquivos novos são testes/evidências e esta revisão externa do relatório. O plano registrou previamente a condição de gerar 0.30.0 somente se surgisse adaptação necessária.

| Entrada ou fronteira | Verificação própria | Resultado |
|---|---|---|
| Pedidos MCP atuais | Leitura integral da aba com base 0.29.1 | Nenhum pedido aberto; nenhum número novo atribuído. |
| Novas operações Google | Registro, descoberta paginada, schemas e classificação de escrita | Três operações presentes na versão 0.19.0, com chave de idempotência do transporte. |
| Renomeação Google | Escrita por perfil custom autorizado, readback e revisão | Nome de negócio preservado, persistência confirmada. |
| Repetição e autorização | Mesma chave, parâmetros divergentes e alteração do perfil | Repetição conserva resultado; outra intenção conflita; perfil revogado recusa inclusive replay. |
| Troca de identidade Google | Ausência de candidata, plano inválido e confirmação falsa | Validações de domínio alcançadas; configuração preservada. |
| Contextos administrativos | Cookie/nonce, AJAX, admin-post GET/POST, REST, CLI e identidades remotas | 26 verificações aprovadas. |
| Auditoria LinkedIn | Fluxos de serviço e humanos com classes 0.9.0, HTTP sintético | 54 e 32 verificações aprovadas. |
| Meta | Perfis read/custom/maintenance e separação health/status | Comportamento de leitura/reparo preservado. |
| Busca e documentação | Termos, acentos, filtros, paginação, revisão e confinamento | Regressões aprovadas. |

O Google registra **290 habilidades nativas**. No laboratório configurado nesta rodada, **283 alvos** foram visíveis: `google/mcp-read` e `google/mcp-write` são executores indiretos; cinco consultas sem entrada foram recusadas por suas permissões efetivas (`ads/list-accessible-customers`, `ads/list-resources`, `gtm/diagnostico`, `gtm/list-accounts`, `gtm/lookup-container`). As cinco recusas foram verificadas. O número visível depende da configuração/permissão, não é um total universal do produto.

As duas tentativas preliminares do teste de contagem confundiram total nativo com catálogo visível e depois consideraram somente os dois executores. As expectativas do teste foram corrigidas após identificar e verificar as cinco recusas. As evidências preliminares foram preservadas; não são contadas como testes aprovados. Nenhuma correção de produto decorreu delas.

### Correções já entregues na revisão 1 — histórico preservado

1. **R1 — repetição com efeito desconhecido:** `retryable=true` só libera a mesma chave quando `applied=false` é explícito e nenhum dos campos presentes `persisted`, `changed` ou `partial` contradiz a ausência de efeito. Resultados desconhecidos/possivelmente aplicados permanecem conservados. Casos com recibos novos e antigos continuam aprovados.
2. **R2 — busca:** descoberta e guia consideram todos os termos, inclusive após o 12º.
3. **R3 — admin-post:** GET e POST exigem nonce para o contexto administrativo nativo; os demais gates permanecem.

Esses três defeitos haviam sido reproduzidos na 0.29.0. Não foram reintroduzidos nem alterados nesta rodada.

## 4. Instalação e prova da troca

**Nesta rodada não houve troca de plugin no Site-Teste.** O runtime já era 0.29.1 e permaneceu igual. As operações remotas foram leituras de inventário, saúde, descoberta, schemas e documentação, com a auditoria normal do canal. Nenhuma fixture foi enviada ao site.

Laboratório descartável: WordPress **7.1.3**, PHP **8.3.6**, MySQL **8.0.46**, PHP-FPM com quatro workers e OPcache sem validação de timestamps. Os cinco instaladores exatos foram usados. HTTP externo/e-mail foram interceptados; nenhuma credencial comercial foi utilizada.

| Suíte final atual | Verificações | Falhas |
|---|---:|---:|
| Idempotência adversarial e regressão | 25 | 0 |
| Chamadas administrativas nativas | 26 | 0 |
| Descoberta e equivalência por perfil | 34 | 0 |
| Pesquisa no guia | 11 | 0 |
| Documentação por HTTP MCP | 29 | 0 |
| Renderização administrativa | 3 | 0 |
| Auditoria de serviço LinkedIn | 54 | 0 |
| Auditoria humana/aceite LinkedIn | 32 | 0 |
| Idioma e catálogo | 8 | 0 |
| Leitor documental nativo | 27 | 0 |
| Novas operações Google 0.19.0 | 27 | 0 |
| **Total atual** | **276** | **0** |

Cinco verificações de ativação/preparação foram excluídas desse total. Há sobreposição entre suítes; 276 é o número de asserções executadas, não de funcionalidades independentes.

Os **1177 arquivos** dos cinco runtimes instalados localmente conferem com os instaladores: MCP 463, Core 453, Google 160, Meta 42 e LinkedIn 59, sem diferenças nem extras. Nenhum Warning/Notice/Deprecated/Fatal apontou para o runtime MCP. Três avisos do próprio WordPress ocorreram ao consultar atualizações de core/plugins/temas, devido ao bloqueio deliberado de rede externa do laboratório; estão classificados separadamente.

Documentação local: **26 documentos, 28 páginas HTTP**, conteúdos completos e hashes exatos. Foram testados conflito de revisão e recusa de caminhos arbitrários. No Site-Teste, o índice dos 26 documentos confere em tamanho/hash; quatro documentos foram lidos integralmente, em **seis páginas / 107747 bytes**: manual de operação, release-0291, contrato de extensões e auditoria de serviço. Conteúdo e SHA-256 conferem com o instalador. A leitura remota usou `system/guide`, IDs da allowlist, `expected_sha256` e continuação por cursor.

Estado remoto final: WordPress **7.1.3**, PHP **8.3.36**, MCP **0.29.1**; `system/health.healthy=true`, onze checks positivos e nenhuma recuperação pendente. Meta 0.8.0 e LinkedIn 0.9.0 retornaram `state=ok`, sem issues; LinkedIn manteve auditoria central de serviço registrada. Inventário antes/depois igual, oito plugins ativos, incluindo WP Super Cache 3.1.4, Yoast SEO 28.7 e DreamHost Panel Login 1.0.0.

**Provas históricas da revisão 1, não repetidas nem somadas:** 319 verificações, lint de 452 PHP e reprodução do instalador byte a byte a partir do fonte fechado; instalação limpa/miníma e upgrades 0.29.0/0.28.0; instalação remota 0.28.0→0.29.1 com operação de pacote `8e576298df043d3b092f6f78b049379c`, pré-imagem `841b0048fbad5637e6272c2f`, plugin ativo e sondas home/REST 200 antes/depois. A reativação remota foi silenciosa; a ativação normal foi comprovada no laboratório. Esses registros continuam no fonte original e no relatório revisão 1.

Não foi simulado upgrade sobre o mesmo ZIP como se fosse uma nova versão. A integridade dos artefatos originais é a razão para conservar as provas históricas de instalação; a matriz atual acrescenta convivência com os acompanhantes novos.

## 5. Banco e volta de versão

Nenhuma tabela, coluna, opção, migração, concessão ou alteração de configuração de produção foi introduzida por esta rodada. Escritas da nova suíte Google ocorreram exclusivamente no laboratório descartável. Os processos locais foram encerrados; nenhum auxiliar permaneceu no Site-Teste.

A revisão 1 comprovou preservação de senha de aplicativo, grants/tokens OAuth e validade, refresh, opções false/vazias, confirmação SQL pendente, backup privado e recibos concluídos/incertos nos upgrades. Rollback foi validado em prévia; não foi aplicado downgrade.

Restaurar arquivos para 0.29.0 reintroduz os três defeitos. Backup de plugin não desfaz efeitos de banco/fornecedor. Não criar outra chave para contornar um resultado incerto sem investigar o efeito anterior. O comportamento conservador de idempotência permanece vigente.

## 6. O que permanece pendente

- **Dono/operadores comerciais:** homologação com credenciais e ativos reais de Google/Meta/LinkedIn/Core. Testes de transporte, guardas e callbacks sintéticos não comprovam conversão aceita, atribuição, permissão externa ou entrega de e-mail. O fluxo completo de rotação/troca de conta Google foi coberto pelo mantenedor com fixtures; esta rodada comprova a fronteira MCP e não repete toda a suíte Google.
- **Matriz adicional:** multisite, MariaDB, downgrade aplicado e novo ciclo OAuth completo de cliente Claude real não foram exercitados. O conector ChatGPT existente foi usado com sucesso. Isso não reabre o aceite anterior de B22/CIMD.
- **Escopo remoto:** somente Site-Teste foi consultado; estado dos outros onze sites é informação recebida da frota. Não houve nova inspeção visual em navegador nesta rodada; renderização e permissões foram verificadas em WordPress local.
- **Mínimos:** WordPress 7.1.2 foi comprovado na revisão 1; a matriz integrada atual usou 7.1.3. Não se afirma uma nova execução integrada em 7.1.2.
- **Documentação histórica:** títulos de alguns guias preservam versões anteriores, com versão corrente e notas 0.29.1 disponíveis. Nenhum conteúdo instalado foi recompilado nesta revisão externa.

As lacunas anteriores de disponibilidade do Core 1.49.x e teste com Google atualizado foram superadas pelas entradas Core 1.49.1 e Google 0.19.0 atuais. A aba MCP recebida informa nenhum item aberto; não se mantém MCP 65 como pendência editorial própria contra essa evidência.

Nenhuma falha permanece nos cenários finais executados. Isso delimita a conclusão; não é prova de ausência de todo impacto em ambientes e contas não examinados.

## 7. Credenciais e configuração do dono

Nenhuma credencial ou configuração nova é exigida para o MCP. Não é necessário recriar conexões. Perfis e permissões existentes continuam aplicáveis às operações novas dos acompanhantes.

Para autores de provedores, `retryable` sozinho não prova ausência de efeito; `applied=false` só deve ser declarado quando comprovado. Resultados desconhecidos exigem reconciliação. No Meta, usar health para leitura e status somente com perfil autorizado para a escrita local correspondente.

Nenhum segredo real, cookie, dump de banco ou captura de navegador integra os artefatos. As evidências novas e os testes estão no complemento de validação, fora do instalador.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador inalterado | `wp-mcp-fator3-0.29.1-instalador.zip` | 873894 | `1b627aec5c24dc88f52eaf6a0d34367437d7f9e7b599f9f07850567fd57610e6` |
| Fonte inalterado | `wp-mcp-fator3-0.29.1-fonte.zip` | 3945818 | `99ea12645e25d75f2466feebc4ac146e776f33b398d74802f4f6a48327a4142a` |

Relatório externo canônico: `wp-mcp-fator3-0.29.1-relatorio.md`, revisão 2. O fonte original conserva a cópia da revisão 1 anterior ao fechamento; não foi reaberto para inserir esta revisão documental.

Complemento desta rodada: `wp-mcp-fator3-0.29.1-validacao-20261023.zip`, com plano, testes reproduzíveis, hashes das entradas, resultados finais, observações preliminares e provas remotas sanitizadas. Não contém ZIPs aninhados, bancos, runtimes baixados nem configuração privada de laboratório. Identidade do complemento: **183247 bytes**, SHA-256 `77cfc665dabb5ee3eaa4ef1d599fd2f15335ce5aad3707176007ad7797f6a83b`. Nenhum novo documento de impacto foi emitido.
