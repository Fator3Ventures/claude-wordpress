# Impacto de Fator3 MCP 0.29.1 em wp-mcp-google-fator3

Estado corrente: **revisão 2, entrega, resolvido no MCP**. A revisão 1 abaixo documenta o planejamento anterior à alteração de código.

## Planejamento preservado — revisão 1

23/10/2026 · Revisão 1 · Etapa planejamento · Situação alinhado com contrato vigente · alerta-tecnico.
Base 0.29.0 (instalador SHA-256 1720f2db05c5a6ee90d1269ebdc764c14fb6b60e2878f765cf1183093ef1fb2a); alvo previsto 0.29.1, ainda sem pacote fechado. Destinatário examinado: wp-mcp-google-fator3 0.18.1.

## Mudança e consequência

R1: falha retryable não prova ausência de efeito. A 0.29.0 liberava a chave quando applied faltava/era null; pode duplicar tentativa. O patch exige applied=false explícito e rejeita persisted/changed/partial presentes com valor diferente de false. Código de incerteza continua bloqueando. Falhas sem prova ficam conservadas e reproduzidas. Não assumir que retryable autoriza reenvio externo.



## Ação e compatibilidade

Nenhuma mudança obrigatória no destinatário, nenhuma ordem de atualização conjunta. O mantenedor pode declarar applied=false somente quando provar ausência de efeito e desejar liberar repetição da mesma chave. Campo ausente conserva o resultado; não ampliar retry por suposição. O patch não muda SDK, IDs, schemas obrigatórios nem concessões. Nenhuma mensagem enviada.

## Validação e evolução

Reprodução própria descrita em PLANO-0291.md. Regressões de integração previstas antes da entrega; prova final será acrescentada sem apagar este planejamento. Nenhum ticket novo inventado. Resposta externa dispensável para este alerta sem ação imediata.

## Revisão 2 — entrega e verificação

23/10/2026. Correção concluída; alerta técnico resolvido no MCP, sem ação obrigatória do destinatário. Instalador 0.29.1: 873894 bytes, SHA-256 `1b627aec5c24dc88f52eaf6a0d34367437d7f9e7b599f9f07850567fd57610e6`.

Prova própria: 18 verificações adversariais, 26 de chamadas nativas e 7 de idempotência, sem falhas; recibos novos e antigos protegidos. Meta read/custom recusam status e read permite health; maintenance permite status. Auditoria LinkedIn: 54 verificações de serviço e 32 humanas, sem falhas, usando LinkedIn 0.8.1 real e HTTP de fornecedor sintético. Nenhuma reemissão real.

Conjunto local Core 1.48.0/Google 0.18.1/Meta 0.7.1/LinkedIn 0.8.1. No Site-Teste, MCP atualizado 0.28.0→0.29.1, saúde normal, documentos completos exatos; Core 1.48.0, Google 0.17.0, Meta 0.7.1 e LinkedIn 0.8.1 preservados. O caso de Core/Google com conta comercial configurada não foi homologado.

Impactos recebidos: o comportamento de Meta status foi confirmado; o handshake LinkedIn originalmente pendente no MCP 0.27.0 está implementado desde 0.28.0 e validado novamente com o patch. MCP 65/LinkedIn 8(d) resolvidos tecnicamente; fechamento editorial pelo dono. Nenhum documento central ou pacote alheio foi alterado; nenhum encaminhamento foi enviado.
