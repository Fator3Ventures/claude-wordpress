# Fator3 MCP 0.28.0

Atualização direta da 0.27.0; WordPress mínimo 7.1.2/PHP 8.3.6. Matriz: Core 1.47.0, Google 0.17.0, Meta 0.5.0 e LinkedIn 0.7.0.

Pedido MCP 65: implementado mutation-service-audit/1.0.0 conforme contraproposta LinkedIn 0.7.0. Bootstrap PHP, introspecção pública, digest de evento e recibo de persistência, referência estável de serviço, leitura audit/get-service-operation e Registro administrativo. Identidade de serviço separada do usuário incidental, sem payload/PII/segredo. Revogação conserva referência e nega detalhes; replay/incerteza não autoriza reenvio. Consulte MUTATION-SERVICE-AUDIT para contratos, configuração, falhas e retenção.

Não há migração, credencial, consentimento ou cron novo. Funções autônomas e contrato humano preservados. Meta 0.5.0 fornece seus 33 rótulos/descrições; não se duplicam traduções. O documento de pedidos recebido confirma aceite real do Claude em 22/10/2026 e revogação posterior do conector de teste pelo dono; esse aceite recebido encerra a pendência 64, sem apresentá-lo como execução desta rodada.

Instalação limpa e atualização direta, fornecedor simulado e Site-Teste são provas distintas; resultados exatos no relatório externo. Nenhuma conversão comercial real é enviada nesta validação.
