# Fator3 MCP 0.29.1 — revisão independente

23/10/2026. Patch da 0.29.0 recebida, com comparação à referência 0.28.0. M1–M7 da 0.29.0 preservadas.

## R1 — repetição segura

A 0.29.0 confundia ausência de informação com ausência de efeito. Falhas retryable com applied ausente/null, persisted/changed null ou partial=true liberavam a chave e podiam executar novamente.

A 0.29.1 exige success=false, retryable=true e applied=false explícito. Se persisted, changed ou partial estiverem presentes, precisam ser false. Códigos de incerteza/conflito continuam conservados. A mesma regra vale para recibos novos e antigos. Não afirmar applied=false após timeout se o fornecedor pode ter aplicado a operação. Falhas desconhecidas continuam reproduzidas; investigar o resultado antes de nova intenção. Nenhum reenvio automático, migração ou limpeza de recibos.

## R2 — todos os termos

Descoberta e pesquisa documental agora consideram todos os termos, sem descartar silenciosamente o 13º em diante. Termos repetidos são deduplicados; ordem e acentos continuam indiferentes. Campos e paginação preservados.

## R3 — admin-post em GET

admin-post exige nonce validado na requisição para qualquer método, incluindo GET. Com nonce, uma habilidade aderente pode chegar ao permission_callback do domínio. Sem nonce continua exigida política MCP. GET/HEAD de telas wp-admin comuns continuam restritos a leitura. Executors, habilidades próprias, aplicativo/OAuth/CLI e usuários sem manage_options mantêm seus gates.

## Integrações

Conjunto local: Core 1.48.0 (último instalador localizado), Google 0.18.1, Meta 0.7.1 e LinkedIn 0.8.1. Core 1.49.0 aparece no relatório recebido, mas seus bytes não foram localizados para nova execução.

Meta: status permanece escrita local e exige manutenção/custom explícito; health é leitura. Omitir idempotency_key para observação atual. LinkedIn: mutation-audit/1.0.0 e mutation-service-audit/1.0.0 preservados, sem backfill. O impacto recebido de LinkedIn 0.7.0 era anterior à implementação central na 0.28.0; não representa ausência do contrato atual.

## Instalação, dados e volta

Atualizar diretamente da 0.29.0 ou 0.28.0, mantendo pasta/basename; somente o instalador é instalável. Verificar hash do relatório e expected_slug=wp-mcp-fator3. Prontidão: system/capabilities plugin_version=0.29.1, system/health e system/guide document=release-0291.

Nenhuma opção, tabela, coluna, credencial ou concessão nova. Rollback de arquivos para 0.29.0 reintroduz os três achados; não desfaz auditoria nem efeitos externos. Preservar backup operacional e salts. Provas e limites exatos no relatório externo; testes de fornecedor são simulados, sem comprovação comercial.
