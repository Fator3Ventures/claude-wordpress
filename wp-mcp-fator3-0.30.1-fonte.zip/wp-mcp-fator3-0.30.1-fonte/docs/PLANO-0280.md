# Plano — Fator3 MCP 0.28.0

Base aceita imutável: 0.27.0. Pedido MCP 65 / LinkedIn 8(d). Matriz recebida: Core 1.47.0, Google 0.17.0, Meta 0.5.0, LinkedIn 0.7.0. Alvo minor 0.28.0. Mínimos mantidos e a comprovar: WordPress 7.1.2/PHP 8.3.6.

Aceito o handshake e recibo da contraproposta LinkedIn 0.7.0, impacto revisão 3. Criar consumidor de mutation-service-audit/1.0.0 separado do contrato humano. Registrar apenas metadados técnicos depois de conferir evento integral, digest canônico e introspector PHP público. Conferir origem instalada e leitor administrativo decorado. Chave estável por site/provedor/principal/operação; não assumir usuário incidental. Persistir user=0/principal_type=service. Consulta central nova audit/get-service-operation e Registro visual usam leitor público e concessão vigente; manage_options e política MCP, sem fabricar autorização de domínio. Revogação conserva referência, nega detalhes. Sem importação retroativa ou reenvio.

Impacto relevante: docs/impacto-mcp-0.28.0-para-linkedin.md, criado antes do código. Nenhuma mudança requerida em Core/Google/Meta: Core continua adaptador/consumidor, Meta 0.5.0 só muda metadados de apresentação. Implantador não recebido: não avaliado, sem risco específico identificado.

Provas previstas: WordPress nativo com pacotes reais e HTTP sintético, serviço usuário zero/incidental, antes/depois, replay/incerto, identidades falsas, campos extras, revisão/perfil/concessão/ativo revogados, perda do leitor, falha de persistência e retenção; regressão humana. Instalação limpa isolada e atualização direta 0.27.0, preservação, documentação completa por hash, sintaxe e build reproduzível. Site-Teste: uma instalação MCP, cenário sintético temporário com limpeza e Registro visual. Nenhum POST social real ou gasto.

Pedidos 63/64 aceitos conforme aba recebida, inclusive conector Claude real autorizado e depois revogado pelo dono; não reabrir o aceite. Relatório Meta interno recebido não contém identidade final do próprio fonte: calcular bytes do ZIP recebido; não tratá-lo como relatório externo canônico.

Fechamento: cópias externas canônicas de relatório Meta 0.5.0 e impacto LinkedIn 0.7.0 recuperadas; o impacto é idêntico ao interno e o relatório Meta completa a identidade do fonte recebido. Escopo permanece inalterado. Provas executadas em evidencias/0280 e relatório externo; instalador final preservado.
