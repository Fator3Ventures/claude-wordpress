# Fator3 MCP 0.30.1

Entrega do Pedido MCP 66: conversão JPEG/PNG em novo WebP, preservação da origem, derivados e hashes conferidos, economia em bytes e reversão por media/delete. A correção 0.30.1 acrescenta à leitura media/get a revisão necessária ao fluxo público. Mínimos: WordPress 7.1.2 / PHP 8.3.6. Identidade wp-mcp-fator3/wp-mcp-fator3.php preservada.

Instale somente wp-mcp-fator3-0.30.1-instalador.zip; o fonte não é instalável. Consulte o relatório externo para hashes, reversão e limites de homologação. Atualização direta 0.29.1 → 0.30.1 foi validada localmente; Site-Teste passou por 0.30.0 e depois 0.30.1. A versão 0.30.0 foi mantida como etapa intermediária, após achar a ausência de revisão em media/get no teste real.

Código em fontes/wp-mcp-fator3. Operação: docs/OPERACAO.md, docs/RELEASE-0300.md e docs/RELEASE-0301.md. Guia instalado: system/guide. Pedido, instruções revisão 5 e manifestos recebidos ficam em docs/entradas. Não houve alteração nos documentos centrais nem distribuição à frota.

Evidências finais: evidencias/0301; 77 verificações no mínimo e 218 no laboratório integrado, todas aprovadas. Os demais diretórios de evidências são históricos ou intermediários, nunca somados ao total final. Testes de mídia em tools/lab/media.php e media-convert.php; fluxo MCP público em tools/release0300/media-http.php. O nome release0300 identifica a rodada minor e também contém a correção 0.30.1.

Core 1.51.0, Google 0.19.0, Meta 0.9.0 e LinkedIn 0.10.1 foram exercitados juntos no laboratório; nenhum de seus arquivos mudou. Pipedrive 0.1.0 foi verificado no Site-Teste com PHP 8.3.36, por catálogo e recusa de autorização local. Não se declara teste de sua API comercial ou ativação abaixo do seu mínimo de PHP.

Build reproduzível: python3 tools/sync_docs.py; python3 tools/build_packages.py --out DIRETORIO. O instalador inclui índices de proteção gerados pelo build. Para testar igualdade do pacote, F3_MCP_SOURCE deve apontar ao instalador extraído, e não à árvore de desenvolvimento. Fechar o fonte por tools/pack_source.py só após concluir relatório/evidências; hash do próprio fonte fica exclusivamente no relatório externo.

Reprodução dos ensaios: tools/release0300/README.md. Os scripts são exclusivos de WordPress descartável; não executar os testes em produção. Nenhuma credencial real, banco de laboratório ou dependência binária foi incluída.
