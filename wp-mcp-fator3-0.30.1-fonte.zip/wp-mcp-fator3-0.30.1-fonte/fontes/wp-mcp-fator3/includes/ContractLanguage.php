<?php
/** One localized description layer; parameter names always come from the effective schema. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ContractLanguage {
    public static function describe(array $args, string $name): array {
        static $descriptions=null, $labels=null;
        if($labels===null)$labels=json_decode((string)file_get_contents(__DIR__.'/labels-pt_BR.json'),true,512,JSON_THROW_ON_ERROR);
        if(isset($labels[$name]))$args['label']=$labels[$name];
        if($descriptions===null)$descriptions=json_decode((string)file_get_contents(__DIR__.'/descriptions-pt_BR.json'),true,512,JSON_THROW_ON_ERROR);
        $args=self::properties($args,$name);
        if(!isset($descriptions[$name]))return $args;
        $params=array_keys($args['input_schema']['properties']??[]);$required=$args['input_schema']['required']??[];
        $args['description']=$descriptions[$name];
        if($params)$args['description'].=' Parâmetros: '.implode(', ',$params).'.';
        if($required)$args['description'].=' Obrigatórios: '.implode(', ',$required).'.';
        return $args;
    }
    /**
     * 0.29.0: Portuguese parameter descriptions for this plugin's own abilities.
     * `exact` replaces a known English text only on exact match; `ability` fills
     * the listed parameters. Unknown texts and third-party schemas are untouched.
     */
    public static function properties(array $args, string $name): array {
        static $map=null;
        if($map===null){$file=__DIR__.'/property-descriptions-pt_BR.json';$map=is_file($file)?json_decode((string)file_get_contents($file),true,512,JSON_THROW_ON_ERROR):['exact'=>[],'ability'=>[]];}
        if(!isset($args['input_schema']['properties'])||!is_array($args['input_schema']['properties']))return $args;
        foreach($args['input_schema']['properties'] as $property=>&$definition){
            if(!is_array($definition))continue;
            if(isset($map['ability'][$name][$property]))$definition['description']=$map['ability'][$name][$property];
            elseif(isset($definition['description'])&&is_string($definition['description'])&&isset($map['exact'][$definition['description']]))$definition['description']=$map['exact'][$definition['description']];
        }
        unset($definition);
        return $args;
    }
}
