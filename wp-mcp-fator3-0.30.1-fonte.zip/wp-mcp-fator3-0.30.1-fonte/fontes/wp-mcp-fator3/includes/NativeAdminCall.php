<?php
/**
 * Native administrator call to an adherent provider ability (0.29.0).
 *
 * Problem measured on 0.28.0: a domain plugin screen that runs its own ability
 * through the WordPress Abilities API (admin-ajax with nonce, admin-post with
 * check_admin_referer, wp-admin screen or REST with cookie + wp_rest nonce) was
 * refused with profile_denied whenever this plugin was active, because the
 * decorated permission asked for an MCP connection policy that a browser
 * session never has. Without this plugin the same call reached the domain.
 *
 * Rule (all conditions, evaluated on every check, nothing persisted):
 * - the ability belongs to a registered adherent provider other than this
 *   plugin, is decorated, and is not an executor;
 * - the current user is authenticated, has manage_options, and no transport
 *   identity exists in this request (no application password, no OAuth bearer,
 *   no internal job identity);
 * - no MCP tool dispatch is open (RootToolContext inactive) and the request is
 *   not an MCP server endpoint;
 * - the request is a web administrative request (never CLI): wp-admin screen
 *   read (GET/HEAD, readonly abilities only), admin-post or admin-ajax after a
 *   nonce verified by check_admin_referer / check_ajax_referer in this request,
 *   or REST authenticated by the logged-in cookie with a valid wp_rest nonce.
 * The domain permission_callback already ran before this point and keeps the
 * final decision. Abilities owned by this plugin (files/, db/, users/,
 * backups/, options/, plugins/, …), executors and the two-phase destructive
 * confirmations keep requiring an explicit connection policy.
 */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class NativeAdminCall {
    private static bool $nonce_verified = false;

    public static function init(): void {
        $track = static function ($action, $result): void { if (false !== $result && null !== $result && 0 !== $result) self::$nonce_verified = true; };
        add_action('check_ajax_referer', $track, 10, 2);
        add_action('check_admin_referer', $track, 10, 2);
    }

    /** Context label when the request qualifies, null otherwise. Never reads client arguments. */
    public static function context(): ?string {
        // Web requests only: WP-CLI and other command-line runs keep the policy.
        if (PHP_SAPI === 'cli' || (defined('WP_CLI') && WP_CLI)) return null;
        $user = get_current_user_id();
        if ($user <= 0 || !current_user_can('manage_options')) return null;
        if (ConnectionContext::transport_identity() !== null) return null;
        if (RootToolContext::active()) return null;
        if (self::rest_request()) {
            $route = ConnectionEndpoints::request_route();
            if (null === $route || ConnectionEndpoints::matches($route) || str_starts_with($route, '/mcp/')) return null;
            if (true !== ($GLOBALS['wp_rest_auth_cookie'] ?? null)) return null;
            $nonce = $_REQUEST['_wpnonce'] ?? ($_SERVER['HTTP_X_WP_NONCE'] ?? null); // phpcs:ignore WordPress.Security.NonceVerification
            if (!is_string($nonce) || !wp_verify_nonce(sanitize_text_field(wp_unslash($nonce)), 'wp_rest')) return null;
            return 'rest_cookie_nonce';
        }
        if (!is_admin()) return null;
        if (wp_doing_ajax()) return self::$nonce_verified ? 'admin_ajax_nonce' : null;
        // admin-post is a nonce-protected action endpoint for every HTTP method.
        // A GET here is not an ordinary wp-admin screen read.
        if (($GLOBALS['pagenow'] ?? '') === 'admin-post.php') return self::$nonce_verified ? 'admin_post_nonce' : null;
        $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        if (in_array($method, ['GET', 'HEAD'], true)) return 'admin_screen';
        return self::$nonce_verified ? 'admin_post_nonce' : null;
    }

    public static function allows(string $name): bool {
        $ability = function_exists('wp_get_ability') ? wp_get_ability($name) : null;
        if (!$ability instanceof \WP_Ability) return false;
        $meta = $ability->get_meta(); $f3 = (array)($meta['fator3'] ?? []);
        $provider = (string)($f3['provider'] ?? '');
        if ('' === $provider || 'wp-mcp-fator3' === $provider || !empty($f3['owned']) || empty($f3['adherent']) || empty($f3['decorated'])) return false;
        if (!Providers::known($provider) || AuthorizationPolicy::executor($ability)) return false;
        if (str_starts_with($name, 'wp-mcp-ultimate/')) return false;
        // An executor in the native call chain (e.g. execute-ability called from PHP)
        // keeps the connection policy for its target.
        foreach (RootToolContext::stack() as $outer) {
            if ($outer === $name) continue;
            $outer_ability = wp_get_ability($outer);
            if (str_starts_with($outer, 'wp-mcp-ultimate/') || ($outer_ability instanceof \WP_Ability && AuthorizationPolicy::executor($outer_ability))) return false;
        }
        $context = self::context();
        if (null === $context) return false;
        // A screen read without nonce never runs a write: writes need a verified nonce.
        if ('admin_screen' === $context && empty($meta['annotations']['readonly'])) return false;
        return true;
    }

    private static function rest_request(): bool {
        if (function_exists('wp_is_serving_rest_request')) return wp_is_serving_rest_request();
        return defined('REST_REQUEST') && REST_REQUEST;
    }
}
