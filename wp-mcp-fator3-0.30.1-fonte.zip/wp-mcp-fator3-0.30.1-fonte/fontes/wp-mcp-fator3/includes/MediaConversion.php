<?php
/** Additive native conversion: the source attachment is never an output target. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class MediaConversion {
    private static function source_state(int $id) {
        $snapshot=DeletionSnapshot::post($id);
        if(is_wp_error($snapshot))return $snapshot;
        return ['revision'=>ContentTools::revision($id),'files'=>$snapshot['files']??[]];
    }
    private static function source_preserved(int $id,array $before): bool {
        clean_post_cache($id);$after=self::source_state($id);
        return !is_wp_error($after)&&$before===$after;
    }
    public static function convert(array $input): array {
        $id=(int)$input['id'];$post=get_post($id);
        $fail=static fn($code,$message,$extra=[])=>Result::fail($code,$message,$extra+['source_id'=>$id,'applied'=>false,'changed'=>false,'persisted'=>false]);
        if(!$post||$post->post_type!=='attachment'||!in_array($post->post_mime_type,['image/jpeg','image/png'],true))return $fail('media_conversion_source_invalid','A origem precisa ser um anexo JPEG ou PNG.');
        if(($input['formato']??'')!=='webp')return $fail('media_conversion_format_invalid','Formato de saída permitido: webp.');
        require_once ABSPATH.'wp-admin/includes/image.php';
        if(!wp_image_editor_supports(['mime_type'=>'image/webp']))return $fail('media_webp_unsupported','O editor WordPress deste servidor não suporta image/webp.');
        $file=wp_get_original_image_path($id);$dimensions=$file&&is_file($file)?wp_getimagesize($file):false;
        if(!$dimensions||!in_array($dimensions['mime']??'',['image/jpeg','image/png'],true)||$dimensions['mime']!==$post->post_mime_type)return $fail('media_conversion_source_invalid','Arquivo original ausente ou formato real diferente do anexo.');
        $before=self::source_state($id);if(is_wp_error($before))return $fail($before->get_error_code(),$before->get_error_message());
        $source_bytes=filesize($file);$source_hash=hash_file('sha256',$file);
        $editor=wp_get_image_editor($file);
        if(is_wp_error($editor))return $fail('media_editor_unavailable','Não foi possível abrir a origem no editor WordPress.');
        if(isset($input['qualidade'])){$quality=$editor->set_quality((int)$input['qualidade']);if(is_wp_error($quality))return $fail('media_conversion_quality_invalid','Qualidade recusada pelo editor.');}
        $upload=wp_upload_dir();if(!empty($upload['error']))return $fail('media_conversion_upload_unavailable','Diretório de uploads indisponível.');
        // Random isolated basename also prevents collisions with existing derivative names.
        $stem=sanitize_file_name(pathinfo($file,PATHINFO_FILENAME)).'-webp-'.bin2hex(random_bytes(8));
        $destination=$upload['path'].'/'.wp_unique_filename($upload['path'],$stem.'.webp');
        $prefix=substr($destination,0,-5);$new_id=0;$saved_path=$destination;$inserting=false;
        // An output mapping must not silently change the explicit WebP request to JPEG.
        // Native subsize editors pass a null filename; cover those WebP writes only for this call.
        $format=static function($formats,$filename,$mime)use($prefix){if(($filename===null&&$mime==='image/webp')||(is_string($filename)&&str_starts_with($filename,$prefix)))$formats['image/webp']='image/webp';return $formats;};
        add_filter('image_editor_output_format',$format,PHP_INT_MAX,3);
        try {
            $saved=$editor->save($destination,'image/webp');unset($editor);
            if(!is_wp_error($saved)&&is_array($saved)&&isset($saved['path']))$saved_path=$saved['path'];
            $actual=is_file($saved_path)?wp_getimagesize($saved_path):false;
            if(is_wp_error($saved)||$saved_path!==$destination||!$actual||($actual['mime']??'')!=='image/webp'||!filesize($saved_path)||$actual[0]!==$dimensions[0]||$actual[1]!==$dimensions[1]){
                // An editor may fall back to another extension. Remove only this invocation's
                // random basename; an unrelated returned path must remain untouched/uncertain.
                if(is_file($destination))wp_delete_file($destination);
                if($saved_path!==$destination&&dirname($saved_path)===dirname($destination)&&pathinfo($saved_path,PATHINFO_FILENAME)===pathinfo($destination,PATHINFO_FILENAME)&&is_file($saved_path))wp_delete_file($saved_path);
                clearstatcache(true);$remaining=is_file($destination)||is_file($saved_path);$preserved=self::source_preserved($id,$before);$uncertain=$remaining||!$preserved;
                return $fail('media_conversion_save_failed','O editor não confirmou o WebP solicitado.',['file'=>wp_basename($saved_path),'applied'=>$uncertain?null:false,'changed'=>$uncertain?null:false,'persisted'=>$uncertain?null:false,'cleanup_required'=>$remaining,'original_preserved'=>$preserved]);
            }
            $converted_bytes=filesize($destination);
            $inserting=true;
            $new_id=wp_insert_attachment(wp_slash(['post_title'=>$post->post_title,'post_excerpt'=>$post->post_excerpt,'post_mime_type'=>'image/webp','post_status'=>'inherit']),$destination,0,true);
            if(is_wp_error($new_id)||!$new_id){$new_id=0;wp_delete_file($destination);return $fail('media_conversion_insert_failed','Não foi possível registrar o novo anexo.',['applied'=>is_file($destination)?null:false,'changed'=>is_file($destination)?null:false,'cleanup_required'=>is_file($destination),'original_preserved'=>self::source_preserved($id,$before)]);}
            update_post_meta($new_id,'_wp_attachment_image_alt',wp_slash((string)get_post_meta($id,'_wp_attachment_image_alt',true)));
            $generation=MediaImages::generate($new_id);
            clean_post_cache($new_id);$new=get_post($new_id);$meta=wp_get_attachment_metadata($new_id);$attached=get_attached_file($new_id);$files=[];$valid=true;
            $paths=['full'=>$attached,'converted_original'=>$destination];
            foreach($meta['sizes']??[] as $size=>$entry)$paths[$size]=dirname($attached).'/'.$entry['file'];
            foreach($paths as $role=>$path){
                $size=$path&&is_file($path)?wp_getimagesize($path):false;
                if(!$size||($size['mime']??'')!=='image/webp'||strtolower(pathinfo($path,PATHINFO_EXTENSION))!=='webp'){$valid=false;continue;}
                $files[$role]=['file'=>wp_basename($path),'width'=>$size[0],'height'=>$size[1],'mime_type'=>'image/webp','bytes'=>filesize($path),'sha256'=>hash_file('sha256',$path)];
            }
            $preserved=self::source_preserved($id,$before);
            $copied=$new&&$new->post_title===$post->post_title&&$new->post_excerpt===$post->post_excerpt&&get_post_meta($new_id,'_wp_attachment_image_alt',true)===get_post_meta($id,'_wp_attachment_image_alt',true);
            $data=['id'=>$new_id,'source_id'=>$id,'source_revision'=>$before['revision'],'revision'=>ContentTools::revision($new_id),'formato'=>'webp','mime_type'=>$new->post_mime_type??null,'url'=>wp_get_attachment_url($new_id),'files'=>$files,'source_file'=>['file'=>wp_basename($file),'bytes'=>$source_bytes,'sha256'=>$source_hash],'savings_bytes'=>$source_bytes-$converted_bytes,'original_preserved'=>$preserved,'metadata_copied'=>$copied,'generation'=>$generation,'changed'=>true,'persisted'=>true,'applied'=>true,'undo'=>['ability'=>'media/delete','id'=>$new_id,'force'=>true]];
            if(empty($generation['success'])||!$valid||!$preserved||!$copied||($new->post_mime_type??'')!=='image/webp')return Result::fail('media_conversion_partial','Anexo criado com divergências; examine generation e files. Para desfazer, exclua somente o novo id por media/delete.',$data+['partial'=>true]);
            return Result::ok($data);
        } catch(\Throwable $error) {
            if(!$new_id&&!$inserting&&is_file($destination))wp_delete_file($destination);
            return Result::fail('media_conversion_failed','Conversão interrompida; reconcilie o novo anexo/arquivo antes de repetir.',['source_id'=>$id,'file'=>wp_basename($destination),'applied'=>$new_id?true:($inserting||is_file($destination)?null:false),'partial'=>$inserting,'cleanup_required'=>$inserting||is_file($destination),'original_preserved'=>self::source_preserved($id,$before)]+($new_id?['id'=>$new_id]:[]));
        } finally {remove_filter('image_editor_output_format',$format,PHP_INT_MAX);}
    }
}
