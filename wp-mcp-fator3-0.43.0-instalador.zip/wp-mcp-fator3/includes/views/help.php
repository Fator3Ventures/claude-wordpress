<?php
namespace Fator3\McpFiles;
if (!current_user_can('manage_options'))return;
$url=Admin::url('help');
$release_document = 'release-' . str_replace('.', '', F3_MCP_FILES_VERSION);
$query=is_string($_GET['doc_search']??null)?trim(wp_unslash($_GET['doc_search'])):'';
$document=is_string($_GET['document']??null)?wp_unslash($_GET['document']):'administracao';
?>
<div class="f3-page-intro"><h2>Ajuda</h2><p>Consulte o manual da versão <?php echo esc_html(F3_MCP_FILES_VERSION); ?>. O assistente pode ler os mesmos textos com <code>system/guide</code>.</p></div>
<section class="f3-card"><form method="get" class="f3-search" action="<?php echo esc_url(admin_url('tools.php')); ?>">
<input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="help">
<label for="f3-doc-search">Pesquisar nos documentos instalados</label><div class="f3-actions"><input type="search" id="f3-doc-search" name="doc_search" minlength="2" maxlength="200" value="<?php echo esc_attr($query); ?>"><button class="button">Pesquisar</button></div>
</form>
<?php if($query!==''):
    $result=preg_match('/^.{2,200}$/usD',$query)?Guide::search(['query'=>$query,'limit'=>20]):Result::fail('guide_input_invalid','Use entre 2 e 200 caracteres.');
    if(empty($result['success'])): ?><p role="alert"><?php echo esc_html($result['message']); ?></p>
    <?php elseif(empty($result['matches'])): ?><p>Nenhuma seção encontrada. Experimente um termo como “perfil” ou “retenção”.</p>
    <?php else: ?><h3>Resultados da pesquisa</h3><p><?php echo (int)$result['returned']; ?> de <?php echo (int)$result['total_matches']; ?> seções encontradas.</p><ul class="f3-link-list">
        <?php foreach($result['matches'] as $hit): ?><li><a href="<?php echo esc_url(add_query_arg(['document'=>$hit['document_id'],'cursor'=>$hit['cursor']],$url)); ?>"><?php echo esc_html($hit['section']); ?></a><small><?php echo esc_html($hit['document_title']); ?></small><p><?php echo esc_html($hit['snippet']); ?></p></li><?php endforeach; ?>
    </ul><?php endif; ?>
    <p><a href="<?php echo esc_url($url); ?>">Limpar pesquisa</a></p></section><?php return; endif; ?>
<div class="f3-related"><a href="<?php echo esc_url(add_query_arg('document','administracao',$url)); ?>">Configurar o MCP</a> · <a href="<?php echo esc_url(add_query_arg('document','atualizacao',$url)); ?>">Instalar a versão</a> · <a href="<?php echo esc_url(add_query_arg('document', $release_document, $url)); ?>">Notas desta versão</a></div>
</section>
<?php
$catalog=Guide::read([]);
$input=['document'=>$document,'byte_limit'=>8192];
if(is_string($_GET['cursor']??null))$input['cursor']=wp_unslash($_GET['cursor']);
$page=Guide::read($input);
?>
<section class="f3-card"><form method="get" action="<?php echo esc_url(admin_url('tools.php')); ?>" class="f3-search">
<input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="help">
<label for="f3-help-document">Abrir documento</label><div class="f3-actions"><select name="document" id="f3-help-document">
<?php foreach($catalog['documents']??[] as $doc): ?><option value="<?php echo esc_attr($doc['id']); ?>" <?php selected($document,$doc['id']); ?>><?php echo esc_html($doc['title']); ?></option><?php endforeach; ?>
</select><button class="button">Abrir</button></div></form>
<?php if(empty($page['success'])): ?><p role="alert"><?php echo esc_html($page['message']??'Documento indisponível.'); ?></p>
<?php else: ?>
<p class="description">Trecho <?php echo (int)$page['offset_bytes']+1; ?> a <?php echo (int)$page['offset_bytes']+(int)$page['returned_bytes']; ?> de <?php echo (int)$page['total_bytes']; ?> bytes.</p>
<pre class="f3-manual" tabindex="0"><?php echo esc_html($page['content']); ?></pre>
<div class="f3-actions"><?php if($page['offset_bytes']>0): ?><a href="<?php echo esc_url(add_query_arg('document',$document,$url)); ?>">Início do documento</a><?php endif; ?>
<?php if($page['has_more']): ?><a class="button" href="<?php echo esc_url(add_query_arg(['document'=>$document,'cursor'=>$page['next_cursor']],$url)); ?>">Continuar leitura</a><?php endif; ?></div>
<?php endif; ?></section>
