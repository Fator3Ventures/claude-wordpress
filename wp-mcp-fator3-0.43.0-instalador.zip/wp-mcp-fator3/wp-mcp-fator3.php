<?php
/**
 * Plugin Name:       Fator3 MCP
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Servidor MCP do site para agentes de IA: OAuth com perfil por conexão, conteúdo, mídia, arquivos, banco de dados, plugins, temas e auditoria, com backup e conferência em cada escrita. Configuração e desligamento em Ferramentas → Fator3 MCP.
 * Version:           0.43.0
 * Update URI:        https://fator3.com.br/plugins/wp-mcp-fator3
 * Requires at least: 7.1.4
 * Requires PHP:      8.3
 * Author:            Fator3
 * Author URI:        https://www.fator3.com.br
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-mcp-fator3
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'F3_MCP_FILES_VERSION', '0.43.0' );
define( 'F3_MCP_FILES_DIR', plugin_dir_path( __FILE__ ) );
define( 'F3_MCP_UPSTREAM_VERSION', '2.1.0' );
define( 'F3_MCP_UPSTREAM_COMMIT', 'd5eff50ff3d5609fa491dfb9af7946c261b00c89' );
require_once F3_MCP_FILES_DIR . 'includes/ConnectionEndpoints.php';
require_once F3_MCP_FILES_DIR . 'includes/ConnectionStatus.php';
require_once F3_MCP_FILES_DIR . 'includes/ConnectionTest.php';
add_action('init', static function (): void { $route = ConnectionEndpoints::request_route(); if (null !== $route && ConnectionEndpoints::matches($route)) ConnectionEndpoints::no_cache(); }, 0);
require_once F3_MCP_FILES_DIR . 'includes/ServerContract.php';
require_once F3_MCP_FILES_DIR . 'includes/ExecutorRegistry.php';
require_once F3_MCP_FILES_DIR . 'includes/RootToolContext.php';
require_once F3_MCP_FILES_DIR . 'includes/ReleaseState.php';
add_action('plugins_loaded', [ReleaseState::class, 'boot'], 1);

require_once F3_MCP_FILES_DIR . 'includes/PathGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/Support.php';
require_once F3_MCP_FILES_DIR . 'includes/DataSafety.php';
require_once F3_MCP_FILES_DIR . 'includes/Persistence.php';
require_once F3_MCP_FILES_DIR . 'includes/ResourceMetadata.php';
require_once F3_MCP_FILES_DIR . 'includes/Domain.php';
require_once F3_MCP_FILES_DIR . 'includes/Locks.php';
require_once F3_MCP_FILES_DIR . 'includes/BackupStream.php';
require_once F3_MCP_FILES_DIR . 'includes/Backups.php';
require_once F3_MCP_FILES_DIR . 'includes/BackupInventory.php';
require_once F3_MCP_FILES_DIR . 'includes/BackupExport.php';
require_once F3_MCP_FILES_DIR . 'includes/Retention.php';
require_once F3_MCP_FILES_DIR . 'includes/SqlArtifacts.php';
require_once F3_MCP_FILES_DIR . 'includes/StateMaintenance.php';
require_once F3_MCP_FILES_DIR . 'includes/TokenRetention.php';
require_once F3_MCP_FILES_DIR . 'includes/Audit.php';
require_once F3_MCP_FILES_DIR . 'includes/MutationAudit.php';
MutationAudit::init();
require_once F3_MCP_FILES_DIR . 'includes/MutationServiceAudit.php';
MutationServiceAudit::init();
require_once F3_MCP_FILES_DIR . 'includes/ContractLanguage.php';
require_once F3_MCP_FILES_DIR.'includes/Release014.php';
require_once F3_MCP_FILES_DIR.'includes/ConnectionTools.php';
require_once F3_MCP_FILES_DIR.'includes/CronTools.php';
require_once F3_MCP_FILES_DIR.'includes/DatabaseRead.php';
require_once F3_MCP_FILES_DIR.'includes/PrivateArtifact.php';
require_once F3_MCP_FILES_DIR.'includes/QueryExports.php';
require_once F3_MCP_FILES_DIR.'includes/SqlMutationPlan.php';
require_once F3_MCP_FILES_DIR.'includes/SqlRowBackup.php';
require_once F3_MCP_FILES_DIR.'includes/SqlMutation.php';
require_once F3_MCP_FILES_DIR.'includes/OwnedState.php';
require_once F3_MCP_FILES_DIR.'includes/DatabaseAdmin.php';
require_once F3_MCP_FILES_DIR.'includes/SiteAdmin.php';
require_once F3_MCP_FILES_DIR.'includes/Roles.php';
require_once F3_MCP_FILES_DIR.'includes/ArchiveTools.php';
require_once F3_MCP_FILES_DIR.'includes/ThemePackages.php';
require_once F3_MCP_FILES_DIR.'includes/ZipPackage.php';
QueryExports::init();
Release014::init();
require_once F3_MCP_FILES_DIR . 'includes/AbilityRuntime.php';
require_once F3_MCP_FILES_DIR . 'includes/DatabaseWriter.php';
require_once F3_MCP_FILES_DIR . 'includes/DatabaseBudget.php';
require_once F3_MCP_FILES_DIR . 'includes/ContentTools.php';
require_once F3_MCP_FILES_DIR . 'includes/TaxonomyTerms.php';
require_once F3_MCP_FILES_DIR . 'includes/TermUpdate.php';
require_once F3_MCP_FILES_DIR . 'includes/FileTools.php';
require_once F3_MCP_FILES_DIR . 'includes/Packages.php';
require_once F3_MCP_FILES_DIR . 'includes/Operations.php';
require_once F3_MCP_FILES_DIR . 'includes/Diagnostics.php';
require_once F3_MCP_FILES_DIR . 'includes/HostingErrorLog.php';
require_once F3_MCP_FILES_DIR . 'includes/SystemTools.php';
require_once F3_MCP_FILES_DIR . 'includes/Guide.php';
require_once F3_MCP_FILES_DIR . 'includes/ConnectionContext.php';
ConnectionContext::init();
require_once F3_MCP_FILES_DIR . 'includes/NativeAdminCall.php';
NativeAdminCall::init();
require_once F3_MCP_FILES_DIR.'includes/ExtensionContract.php';
ExtensionContract::init();
Providers::register('wp-mcp-fator3', F3_MCP_FILES_VERSION, ['files/','db/','content/','media/','plugins/','themes/','users/','options/','comments/','menus/','widgets/','system/','audit/','backups/','operations/','rewrite/','connections/','cron/','site/','roles/']);
require_once F3_MCP_FILES_DIR . 'includes/ContentContracts.php';
require_once F3_MCP_FILES_DIR . 'includes/DeletionSnapshot.php';
require_once F3_MCP_FILES_DIR . 'includes/DestructiveActions.php';
require_once F3_MCP_FILES_DIR . 'includes/MaintenanceTools.php';
require_once F3_MCP_FILES_DIR . 'includes/MediaImages.php';
require_once F3_MCP_FILES_DIR . 'includes/MediaConversion.php';
require_once F3_MCP_FILES_DIR . 'includes/PackageReceipt.php';
require_once F3_MCP_FILES_DIR . 'includes/ExecutionCoordinator.php';
if (!class_exists('Fator3\\RecoveryV1\\Engine', false)) require_once F3_MCP_FILES_DIR . 'includes/RecoveryEngine.php';
require_once F3_MCP_FILES_DIR . 'includes/Recovery.php';
add_action('plugins_loaded', [Recovery::class, 'refresh_existing_sentinel'], 2);
require_once F3_MCP_FILES_DIR . 'includes/SelfUpdate.php';
require_once F3_MCP_FILES_DIR . 'includes/CronMarker.php';
require_once F3_MCP_FILES_DIR . 'includes/Probe.php';
Probe::init();
require_once F3_MCP_FILES_DIR.'includes/PackageService.php';

require_once F3_MCP_FILES_DIR.'includes/ReadExecutor.php';
require_once F3_MCP_FILES_DIR.'includes/MetadataTools.php';
require_once F3_MCP_FILES_DIR.'includes/SeoIndexables.php';
require_once F3_MCP_FILES_DIR.'includes/SeoAdapter.php';
require_once F3_MCP_FILES_DIR.'includes/Transfers.php';
require_once F3_MCP_FILES_DIR.'includes/DebugTools.php';
AbilityRuntime::init();
require_once F3_MCP_FILES_DIR . 'includes/Http.php';
require_once F3_MCP_FILES_DIR . 'includes/UpdateChannel.php';
require_once F3_MCP_FILES_DIR . 'includes/PackageDistribution.php';
PackageDistribution::init();
UpdateChannel::init();
require_once F3_MCP_FILES_DIR . 'includes/SqlReadPolicy.php';
require_once F3_MCP_FILES_DIR . 'includes/SqlSelection.php';
require_once F3_MCP_FILES_DIR . 'includes/SqlGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/SchemaTools.php';
require_once F3_MCP_FILES_DIR . 'includes/Database.php';
require_once F3_MCP_FILES_DIR . 'includes/SelfTest.php';
require_once F3_MCP_FILES_DIR . 'includes/FileReader.php';
require_once F3_MCP_FILES_DIR . 'includes/GzipReader.php';
require_once F3_MCP_FILES_DIR . 'includes/Files.php';
require_once F3_MCP_FILES_DIR . 'includes/Admin.php';

/**
 * Registra as habilidades na Abilities API.
 *
 * `wp_abilities_api_init` é disparado tanto pelo WordPress 6.9+ nativo quanto
 * pelo polyfill do núcleo integrado. Uma vez registradas, as
 * habilidades aparecem no `discover-abilities` e podem ser chamadas pelo
 * `execute-ability` do servidor MCP integrado.
 */
add_action(
	'wp_abilities_api_init',
	static function (): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		Files::register();
		Database::register();
		ContentTools::register();
		FileTools::register();
		Packages::register();
        PackageService::register();
		Operations::register();
		SystemTools::register();
        HostingErrorLog::register();
        Guide::register();
		MaintenanceTools::register();
		Probe::register();
		ReadExecutor::register();
		MetadataTools::register();
        SeoAdapter::register();
        Transfers::register();
        StateMaintenance::register();
        TaxonomyTerms::register();TermUpdate::register();
        Release014::register();
	}
);

require_once F3_MCP_FILES_DIR.'includes/ConnectionsAdmin.php';
ConnectionsAdmin::init();
require_once F3_MCP_FILES_DIR.'includes/OperationsAdmin.php';
OperationsAdmin::init();
Admin::init();

/**
 * Protege as opções deste plugin contra a habilidade options/update.
 *
 * A lista de proteção padrão do WP MCP Ultimate cobre ~23 nomes fixos e
 * libera todo o resto. Sem isto, o agente poderia reabrir o canal depois de
 * você fechá-lo, ou apagar o próprio log de auditoria, com um options/update.
 *
 * Isto não é contenção contra um agente comprometido — quem tem
 * `install_plugins` já pode instalar PHP arbitrário. É para que o botão
 * "fechar o canal" signifique o que promete no uso normal.
 */
add_filter(
	'wp_mcp_ultimate_protected_options',
	static function ( $protected ) {
		if ( ! is_array( $protected ) ) {
			$protected = array();
		}
		$protected[] = PathGuard::OPTION_ENABLED;
		$protected[] = 'f3_mcp_files_audit';
		$protected[] = Database::OPTION_WRITES;
		$protected[] = 'f3_mcp_ultimate_migrated';
		$protected[] = 'f3_mcp_oauth_clients';
		$protected[] = 'f3_mcp_settings';
		$protected = array_merge($protected, ['f3_mcp_schema_version','f3_mcp_policy_installed_at','f3_mcp_legacy_catalog','f3_mcp_update_channels','f3_mcp_probe_secret','f3_mcp_allowed_origins']);
		return $protected;
	}
);

/**
 * Ativar o plugin abre o canal — ativar já é o ato humano explícito.
 */
register_activation_hook(
	__FILE__,
	static function (): void {
		add_option( PathGuard::OPTION_ENABLED, true, '', true );
		add_option( Database::OPTION_WRITES, true, '', true );
		$ready = ReleaseState::run();
		if ( ! empty( $ready['success'] ) ) CronMarker::activate();
	}
);

/**
 * A Abilities API existe nesta instalação?
 *
 * Vem do WordPress 6.9+, ou do polyfill integrado. Sem ela,
 * `wp_abilities_api_init` nunca dispara e este plugin não
 * registra rota nenhuma.
 */
function f3_mcp_files_abilities_api_disponivel(): bool {
	return function_exists( 'wp_register_ability' );
}

/**
 * Existe algum servidor MCP para expor as rotas para fora?
 *
 * Registrar habilidades não basta: elas ficam no WordPress e ninguém de fora as
 * alcança sem um servidor MCP. O núcleo integrado cumpre esse papel;
 * a checagem preserva o filtro de compatibilidade existente.
 */
function f3_mcp_files_servidor_mcp_detectado(): bool {
	return ConnectionStatus::snapshot(false)['core_loaded']
        || (bool) apply_filters('f3_mcp_files_servidor_mcp_detectado', false);
}

/**
 * Avisos no admin — apenas pré-requisito ausente.
 *
 * Não há aviso de estado do canal: ele aparecia em toda visita à tela de
 * Plugins e não informava nada que a própria tela de controle não mostre. O que
 * sobra aqui é só falha silenciosa: sem a Abilities API o plugin ativa, a tela
 * diz "ABERTO" e nada funciona — isso precisa gritar.
 */
add_action(
	'admin_notices',
	static function (): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! f3_mcp_files_abilities_api_disponivel() ) {
			printf(
				'<div class="notice notice-error"><p><strong>Fator3 MCP:</strong> %s</p></div>',
				esc_html__( 'a Abilities API não foi carregada. O pacote inclui o polyfill para WordPress anterior ao 6.9. Reinstale este ZIP e confira os requisitos de WordPress e PHP.', 'wp-mcp-fator3' )
			);
			return;
		}

		if ( ! f3_mcp_files_servidor_mcp_detectado() ) {
			printf(
				'<div class="notice notice-warning"><p><strong>Fator3 MCP:</strong> %s</p></div>',
				esc_html__( 'o servidor MCP integrado não foi carregado. Reinstale este ZIP e confira o log de erros do WordPress.', 'wp-mcp-fator3' )
			);
		}
	}
);

/**
 * Atalho "Configurar" na linha do plugin.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	static function ( array $links ): array {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'tools.php?page=wp-mcp-fator3' ) ) . '">'
				. esc_html__( 'Configurar', 'wp-mcp-fator3' ) . '</a>'
		);
		return $links;
	}
);

/**
 * Desativar o plugin já remove as habilidades do registro; nada a limpar.
 *
 * Os backups são preservados de propósito — desativar não deve destruir a
 * única cópia de um arquivo que alguém pode precisar restaurar.
 */
register_deactivation_hook(
	__FILE__,
	static function (): void {
		CronMarker::deactivate();
	}
);
