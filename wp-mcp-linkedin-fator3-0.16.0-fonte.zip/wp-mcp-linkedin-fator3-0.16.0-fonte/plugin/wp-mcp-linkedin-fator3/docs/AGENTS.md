# Guia para agentes — 0.16.0

Leia `documentation` com document=index e continue cada documento por next_offset e expected_revision. Confira SHA-256. O catálogo não comprova disponibilidade remota. Entradas humanas exigem administrador; `users` não amplia esse direito. Não obtenha credenciais pelo navegador nem escreva arquivos para expô-las.

Antes de gravar, releia a configuração e use a revisão. Descubra nomes por `admin-options` e mantenha seleção explícita. Nunca interprete uma lista descoberta como autorização. Preservar campos não enviados é a forma de atualizar apenas a seção desejada. Confirme o retorno persistido e a revisão. Não repita mutações incertas.

Meta orgânico e Pixel/CAPI da Meta não são incorporados neste pacote. O cliente Conversions API do LinkedIn integra a fila do Core por concessão própria. LinkedIn mantém Lead Reader 1.0/1.1/1.2; o consumidor Core detém ingestão e deduplicação comercial. `admin-options` é auxílio administrativo e não substitui o cliente SDK nem conclui demandas de outro pacote.

Distinguir testes de fixtures, WordPress real e fornecedor real. As credenciais do dono e aprovação do produto são necessárias para homologação externa. Não publicar, gastar Ads, enviar notificações reais ou criar assinaturas comerciais como teste sem autorização específica.

## Regras das novas escritas

Nunca omita a prévia nem derive expected_revision de dados antigos. Use request_key de domínio; omita a chave opcional idempotency_key do MCP entre fases ou diferencie as chaves de transporte. Registre data.operation_id. Uma criação Ads DRAFT não autoriza ativar. Publicação/comentário são efeitos imediatos. Verifique seleção, escopos introspectados e consentimento do dono para testes reais. Leia MANAGEMENT.md e CREDENTIALS.md por inteiro antes de operar.

A auditoria de mutações humanas é registrada por descritor público no MCP 0.27.0. Para o envio CAPI em segundo plano, não assuma usuário: o contrato humano não admite principal de serviço. Consulte SERVICE-AUDIT.md para a fronteira de domínio implementada, o handshake proposto e o fallback real do MCP 0.27.0. Nunca anuncie Registro central de serviço apenas por encontrar o hook. Não declare refresh real aprovado por ter passado fixture. Não enfraqueça redatores do transporte para obter uploadToken; use interface autorizada prevista.

## Diagnóstico na 0.8.0

Antes de mexer em Conversions API, chame `linkedin/diagnose-conversions` (com `conversion_id` da regra de servidor do Site Core, se conhecida) e siga as ações dos itens com `ok=false`. Para o worker, leia `state` e `issues` em `linkedin/status`; ele não repara. `linkedin/audit` vem do mais recente; use `since`.


## Atualização 0.10.0 — pedido 13

Consulte RELEASE-0.10.0.md e CREDENTIALS.md: candidata conferida antes de persistir, identidade guiada, nomes com origem explícita e agendas rebaseadas no mesmo salvamento. A configuração recebe revisão a cada gravação; authorization_revision e credential_generation distinguem autorização e credencial. Uma alteração benigna mantém o vínculo das identidades de serviço CAPI já emitidas; uma nova concessão ou identidade continua revogando o vínculo anterior. Não editar documentos recebidos de outros pacotes para responder a pedidos.


## Retenção e histórico na 0.11.0

Consulte HISTORY.md: auditoria local configurável com padrão unlimited; conexões existentes preservam a política finita; o acervo diário independe da retenção dos resultados. Nove operações novas, total 90. A consulta local mantém as permissões e a partição da identidade/concessão de origem. A coleta retroativa usa janelas publicadas e não garante integralidade remota. Não alterar documentos de outros pacotes ao entregar esta versão.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central. Atualização histórica da 0.13.0: 0.12.0 → 0.13.0. Veja RELEASE-0.13.0.md para os avisos de credenciais.

## Credenciais na 0.13.0

Pedido MCP LinkedIn 15: espaços externos aparados com aviso; espaços internos e heurísticas de formato são avisos por campo, com decisão remota. Controles, limites máximos, escopos, identidade, CAS e confirmação permanecem. Leia CREDENTIALS.md e RELEASE-0.13.0.md. Sucesso/prévia retornam data.warnings; erros de validação remota retornam details.warnings. Nenhum segredo aparece no aviso.

## Histórico 0.14.0 — pedidos 16/17

Pedidos 16/17: consulte RELEASE-0.14.0.md. Atualização histórica: 0.14.0 → 0.15.0; pedidos 18–21 em RELEASE-0.15.0.md. Não alterar documentos do Core/MCP. Leia oauth-finish em audit e diferencie causa observada de hipótese; jamais repetir código OAuth ou aceitar token inativo. credential_notice_days exige simulação/confirmação. A primeira renovação manual pode exigir Renovar agora e confirmação de identidade; não repetir automaticamente nem interpretar candidato como token salvo.

Seleção automática opcional de formulários: veja LEAD-DISCOVERY.md para configuração da conexão e concessão, simulação, cron, eventos, callback, retomada e dependência real do consumidor Core. A seleção explícita existente permanece padrão.

## Atualização 0.16.0

Leia CAMPAIGN-METADATA.md e RELEASE-0.16.0.md. Metadados de campanha são solicitados e validados nas leituras existentes. A nova permissão campaign_lookup é opcional, exige responses e conta Ads selecionada, com simulação/confirmação; não é adicionada a concessões antigas. O método resolve_campaign é somente leitura remota e não importa contatos. Core 1.68.0 já adota a descoberta 1.2 e consome a decoração; o fallback novo ainda exige adoção própria. Documentos e pacotes Core/MCP não são alterados.
