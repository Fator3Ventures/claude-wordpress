# Atualização 0.14.0 → 0.16.0

Instalar somente wp-mcp-linkedin-fator3, preservando banco, salts e demais pacotes. A base direta é a 0.14.0, inclusive o LeadReader corrigido localmente pela frota nos pedidos 19/20: ambas as correções estão incorporadas nesta entrega. Não usar desinstalação para atualizar.

Após substituir o ZIP, em nova requisição confira versão 0.15.0, 97 operações, `selftest`, `status` e leitura integral de RELEASE-0.15.0.md/LEAD-DISCOVERY.md pelo MCP. Nenhuma credencial nova é exigida para as correções. OAuth/avisos da 0.14.0 permanecem.

Mesmas tabelas/schema físico. Novos buckets cifrados `lead_scan`, `lead_catalog`, `lead_form_event`; opções de checkpoint/cron sob f3_linkedin. Conexões antigas leem `all_forms_accounts:[]` e `lead_discovery_interval_minutes:60`, sem regravação automática ou ampliação de autorização. Concessão automática exige simulação e contrato 1.2 explícitos.

Migração de rejeições na primeira requisição e manutenção, até 50 registros por passagem, sem HTTP. Somente casos comprováveis por diagnóstico persistido ou pelos dois incidentes recebidos são encerrados; preserva diário, código antigo e origem da evidência. Veja MANAGEMENT.md. Um marcador autoload evita SQL novo no bootstrap após terminar. Os casos sem prova permanecem incertos e podem ser encerrados pelo administrador com risco explícito.

Backup recuperável inclui arquivos, banco e salts. Voltar arquivos para 0.14.0 não remove catálogo/eventos, não desfaz webhook criado, encerramento administrativo, migração ou mensagem. A 0.14.0 ignora a seleção automática e os novos estados terminais deixam a guarda liberada; não repetir operações por retornar arquivos. Manter banco atual, pausar descoberta e decidir explicitamente o destino das assinaturas já criadas. Restaurar banco anterior perde recibos e pode duplicar efeitos remotos; não fazer rollback de banco sem coordenação.

A atualização do LinkedIn é independente dos acompanhantes. O Core 1.67.0 mantém sua seleção explícita; a inclusão automática nele depende do encaminhamento Core desta release. Não alterar documentos ou armazenamento privado do Core/MCP.

## Atualização 0.16.0

Leia CAMPAIGN-METADATA.md e RELEASE-0.16.0.md. Metadados de campanha são solicitados e validados nas leituras existentes. A nova permissão campaign_lookup é opcional, exige responses e conta Ads selecionada, com simulação/confirmação; não é adicionada a concessões antigas. O método resolve_campaign é somente leitura remota e não importa contatos. Core 1.68.0 já adota a descoberta 1.2 e consome a decoração; o fallback novo ainda exige adoção própria. Documentos e pacotes Core/MCP não são alterados.
