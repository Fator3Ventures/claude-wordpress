# Fator3 MCP LinkedIn 0.16.0 — fonte da entrega

Evolução direta da base aceita 0.15.0 para atender ao impacto Core 1.68.0 revisão 2, item 369(d). Solicita metadados opcionais do Lead Sync, valida campanha/conta/resposta e oferece fallback público sob autorização explícita. O Core atual já consome a decoração; precisa adotar o método adicional quando necessário. Leia o relatório desta versão e o impacto Core.

## Organização

- `plugin/wp-mcp-linkedin-fator3/`: runtime idêntico ao instalador.
- `build/`: código autoral, documentação instalada e build determinístico exclusivo LinkedIn.
- `tests/native/request369d.php`: projeção, vínculo, grants, serviço, revogação, erros, orçamento e MCP real.
- `tests/core1680/`: teste consumidor adaptado do Core original, cuja cópia recebida está em inputs; nenhum runtime Core alterado. Acrescenta projeção opcional, coleta com usuário 0 e provas de nome novo sobre lead histórico/mapa local.
- `tests/native/seed0160.php`, `upgrade0160.php`, `ui0160.*`: preservação direta e painel.
- `tools/lab.py`, `tools/lab-release0160.example.json`: laboratório descartável com dependências verificadas.
- `evidence/release0160/`: evidências desta rodada; as de entregas anteriores permanecem históricas.
- `inputs/0.16.0/`: relatório e impacto Core recebidos; normas/pedidos históricos preservados.
- `planning/PLANO-0.16.0.md`, `impacts/wp-mcp-linkedin-fator3-0.16.0-impacto-base-site-core-fator3.md`: decisão e encaminhamento pertinente.
- `history/`: relatórios anteriores imutáveis.

## Reprodução

WordPress 6.4+, PHP 8.1.2+ de 64 bits, MySQL/MariaDB com InnoDB e bloqueios nomeados, criptografia autenticada. Bancada: WordPress 7.1.4, PHP 8.3.6, MySQL 8.0.46; mínimo exercitado WP 6.4/PHP 8.1.2. Originais integrados: Core 1.68.0, MCP 0.38.0, Google 0.26.0 e Meta 0.19.0. Pipedrive 0.5.0 foi extraído, mas não ativado localmente por exigir PHP 8.3.36; confira a evidência do Site-Teste para coexistência ativa.

`python3 build/build.py` usa PHP do PATH ou `F3_SOCIAL_PHP`. Instalador final: 363060 bytes, SHA-256 `beb018c0e89a6fcc25beff7d5e2955f606c78ea1cbc8148c17666dd4e9c50bc8`. `build/dist` não integra o fonte. O build inclui Markdown/JSON instalados no catálogo documental; arquivos de teste nunca entram no runtime.

Copie o manifesto de exemplo e ajuste caminhos/credenciais de um MySQL descartável. O runner exige diretório vazio, cria schema próprio e apaga somente esse schema no término. WordPress, runtimes e acompanhantes são dependências externas, identificadas por SHA-256; não estão aninhados neste ZIP. Não use site existente como bancada.

```bash
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li016-new --order linkedin-integrated --tests request369d.php,core1680.php,mcp-docs080.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li016-upgrade --order linkedin-integrated --origin upgrade --tests upgrade0160.php,request369d.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li016-min --order linkedin-only --wordpress wordpress_minimum --php php81 --tests request369d.php,suite.php
```

A matriz completa está em `evidence/release0160/regression/environment.json`. Para contrastar a base, use `--candidate` apontando para o instalador imutável 0.15.0 com `request369d.php`: duas verificações reproduzem a falta de projeção e de método complementar.

DOM: use dependências de `tests/dom/package-lock.json` externamente; configure `F3_JSDOM` para jsdom 27.4.0 e `CODEX_PRIMARY_RUNTIME_NODE` para Node 24.22.1. Execute `ui0160.php` sozinho em laboratório limpo integrado. HTML/JS reais, REST autenticado e confirmação em português; não é inspeção visual em navegador.

`python3 tools/package-source.py --output-dir /diretorio/externo` confere igualdade runtime/instalador e fecha a raiz versionada, sem ZIPs aninhados. O relatório interno antecede o fechamento; o externo canônico recebe tamanho/hash final do fonte. Não modificar instalador após entrega sem nova versão.
