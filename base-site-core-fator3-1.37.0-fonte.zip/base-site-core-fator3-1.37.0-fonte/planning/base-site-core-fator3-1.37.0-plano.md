> Revisão 3 · 18/10/2026 · Implementação 1.37.0 entregue, com aceite comercial real pendente.
>
> Pedidos 225 e 226(a–h) implementados. Contrato 8.2.0; perfil piso-padrao-3.5; 65 opções operáveis e 130 abilities, sem adição/remoção. Instalador SHA-256 a7cd1c225bb9de76a5d1c3ad4b2184df47a6270856da902b8a268a4105ad20ad, 1.987.998 bytes. Código e evidências estão no fonte; o relatório externo é a referência final.
>
> Instalação limpa e upgrade nativos da 1.36.0 aprovados. Sete suítes pertinentes somam 217 verificações; fornecedores Pipedrive/Slack simulados, com casos de criação, reutilização, timeout, complemento, C1, native IDs e thread. Site-Teste atualizado: 15 etapas, zero falhas, finalização natural; home/REST 200; documentação completa com conteúdo/hash conferidos pelo MCP. Pipedrive permaneceu desligado nesse ambiente.
>
> Pendências: projeto Pipedrive fornece chaves/alternativas reais e homologa em CTOoffice/korvena.com.br; frota decide implantação e limpa mapas legados após aceite. Implantador confere contrato 8.2.0; runtime não fornecido. Sem IDs/payloads completos, causa dos dois casos Apex permanece não comprovada. SDKs Google inalterados; nenhuma nova exigência para Google 0.12.0.
>
> Impacto pertinente atualizado: base-site-core-fator3-1.37.0-impacto-implantador-base.md r2. Nenhum encaminhamento foi enviado ou pacote alheio alterado. Revisões r2/r1 abaixo são o histórico do planejamento; esta revisão registra a execução.

# Plano — Fator3 Site Core 1.37.0

## Estado vigente — revisão 2, 18/10/2026

Etapa: implementação autorizada pelo dono. A base continua 1.36.0. O novo **Pedido core 226(a–h)** justifica a release **1.37.0**; o condicionamento da revisão 1 foi atendido. Instalador-alvo ainda não gerado no início desta revisão.

Escopo: 225 (quadro completo de contrato/perfil/contagens); 226(a) título explícito sem host; (b) organização apenas com empresa válida; (c) campo consolidado de perguntas/respostas; (d) mapas de serviço nativo/campanha e aviso; (e) C1 por canal e janela útil; (f) negócio/lead aberto da mesma pessoa; (g) diagnóstico e mapeamento de anúncio/ID nativo; (h) retorno Pipedrive na thread Slack com link e prazo.

Decisões: contrato administrativo 8.2.0 para novas propriedades; nenhum delta nos SDKs Google. Não alterar retroativamente oportunidades/atividades existentes. Havendo múltiplas oportunidades elegíveis, suspender seleção para revisão. Resultados remotos incertos exigem reconciliação. IDs da conta e catálogo de tipos/campos são verificados, nunca inventados. Feriados não serão presumidos; a janela configurável usa dias da semana e fuso IANA. O pedido de 10/10 não fornece IDs completos/payloads: registrar a limitação da investigação e corrigir a observabilidade futura.

Impacto emitido antes do código: base-site-core-fator3-1.37.0-impacto-implantador-base.md, r1. Google 0.12.0 plano/impacto r2 recebidos: contrato Core 1.36.0 já suficiente; sem nova dependência no consumidor.

Matriz: testes de domínio e fluxo remoto simulado no WordPress nativo; instalação limpa e upgrade direto; leitura documental e prontidão no Site-Teste. O aceite Pipedrive real pertence a CTO/korvena e ao projeto Pipedrive; não instalar nem alterar produção implicitamente para fabricar esse aceite. Os testes não enviam mensagens a clientes.

## Histórico — revisão 1

A versão abaixo registra o planejamento anterior ao recebimento do 226; a revisão 2 prevalece.


Revisão 1 · Data: 2026-10-17 · Etapa: **planejamento**.
Emissor: `base-site-core-fator3` · Base aceita: **1.36.0** · Alvo numérico previsto: **1.37.0**.
Situação: **escopo documental definido; nova release de software condicionada a alteração justificada no pacote**.
Instalador/fonte 1.37.0: **ainda não gerados**. Este plano não autoriza publicação ou implantação na frota.

## 1. Decisão proposta

A prioridade é atender **Pedidos core 225**, completando o quadro obrigatório do relatório e preservando-o nas próximas entregas. O relatório externo da 1.36.0 foi corrigido nesta rodada como revisão 2; os ZIPs publicados permanecem idênticos. A conferência formal e a retirada do item da lista central cabem à frota.

Não há pedido funcional aberto do Core nos anexos recebidos. Os aceites de 212(a) e 224 foram registrados pela frota. O Google confirma que o contrato publicado na 1.36.0 é suficiente para implementar sua 0.12.0, sem solicitar novo código Core. Assim, **não há razão técnica atual para gerar uma 1.37.0 apenas para mudar o relatório externo**.

A 1.37.0 fica como próximo alvo caso seja necessária uma mudança distribuída em código, documentação instalada ou ferramentas do pacote. Antes de implementá-la, registrar o problema concreto, o delta e o aceite neste plano. Se o escopo continuar exclusivamente no relatório externo, concluir a correção documental na 1.36.0 e manter a 1.37.0 sem empacotamento. Não criar funcionalidade, migração ou alteração de contrato para justificar o número.

## 2. Base e diagnóstico conferidos

| Aspecto | Base da rodada |
|---|---|
| Plugin / basename | Fator3 Site Core / `base-site-core-fator3/base-site-core-fator3.php` |
| Base direta de eventual atualização | 1.36.0; instalação limpa também deverá ser validada |
| Contrato de configuração | 8.1.0, `f3base/config-core-contrato-v1` |
| Perfil do piso | `piso-padrao-3.5`, revisão `2026-10-12-core-1.31.0` |
| Options operáveis | **65** |
| Abilities Core | **130**, provider `base-site-core-fator3` |
| Delta já entregue, 1.35.0 → 1.36.0 | Entrou `f3base/conversoes-contexto-ler`; saiu nenhuma; 129 → 130 |
| Delta previsto neste plano, sobre 1.36.0 | Nenhuma nova option/ability; nenhuma remoção; recalcular se o escopo mudar |
| SDK de medição | `site-measurement-context/1.0.0`, preservado |
| SDK opcional de conversões | `site-conversion-purposes/1.0.0`, `schema_revision:"1"`, sem paginação |
| Acompanhantes ativos observados | MCP 0.24.0, Google 0.11.0, Meta 0.3.0 e LinkedIn 0.3.0 |
| Alvo Google | 0.12.0 planejado, consumidor ainda não entregue |
| Mínimos comprovados da base | WordPress 7.1.2 e PHP 8.3.6; não estender suporte por inferência |

**Critério da contagem:** o contrato consultado no Site-Teste possui 68 entradas: 65 com `operavel:true` e três não operáveis (`f3base_nav_id`, `f3base_operaveis`, `f3base_politica_canal`). Os JSONs de referência têm 67 entradas: as 65 operáveis e as duas declarações de governança; não incluem `f3base_nav_id`. Essa diferença é explicada pelo critério do gerador e não constitui defeito demonstrado. Não contar subcampos, estado interno, opções de outros plugins ou as 653 abilities de todo o ambiente como inventário operável do Core. Restrições de uma instalação podem reduzir a disponibilidade efetiva.

**Conferência própria desta rodada:** leitura administrativa do contrato, request `b8d56aa5725bc086a2a91d0e`; descoberta de 130 abilities do provider; comparação dos catálogos dos instaladores íntegros 1.35.0/1.36.0, com igualdade entre o catálogo 1.36.0 distribuído e a descoberta instalada. A leitura de plugins, request `d11e34c7c281f571dbf1e71d`, confirma as versões ativas acima. Essas consultas verificam inventário/contrato; não são uma nova matriz de homologação funcional.

**Evidência recebida da frota:** instalação 1.36.0 nos 12 ambientes, 15 etapas e zero falhas; perfil sem divergências fora das exceções. 212(a) no CTO respondeu nas duas visões com 1.112 visualizações e 948 sessões; 224 concluiu seis partes em 23 segundos só com WP-Cron. A publicação informada é o commit `db12565`, sem verificação nova do repositório nesta rodada. Aceites operacionais adicionais permanecem na pendência 20 da frota.

## 3. Trabalho e critérios de aceite

Os identificadores P37 abaixo são tarefas locais deste plano. Não atribuem nem consomem o próximo número central 226.

| ID local / referência | Entrega e responsável | Aceite | Estado |
|---|---|---|---|
| P37-01 / Pedidos core 225 | Core: corrigir o relatório externo 1.36.0, seção Convivência, com contrato, perfil, contagens e entradas/saídas | 8.1.0; piso-padrao-3.5; 65 operáveis; 130 abilities; uma entrada nomeada e zero saídas; fontes de contagem explícitas; hashes dos ZIPs preservados | **Concluído documentalmente nesta rodada**; conferência da frota pendente |
| P37-02 / Pedidos core 225 | Core: incorporar o mesmo quadro à próxima entrega e conferi-lo antes do fechamento | Comparar catálogos únicos da base aceita e do candidato; contar somente provider Core; separar catálogo de configuração de opções operáveis; nomes e números do relatório coincidem com os bytes entregues | Planejado para a próxima release efetiva |
| P37-03 / Core 222, impacto Google 0.12.0 r1 | Core: manter contrato publicado e registrar o retorno recebido; Google: implementar e validar seu consumidor | Decisão do produtor encerrada, responsabilidades separadas, consumidor comprovado pelo Google ou divergência acompanhada de caso mínimo | Encaminhamento Core atualizado para r3; implementação/aceite Google pendentes |
| P37-04 / decisão de escopo | Core e dono: consolidar motivo para uma eventual 1.37.0 | Alteração distribuída concreta, objetivo e evidência de aceite definidos; impactos pertinentes emitidos antes de alterar a fronteira afetada | Condicional; não existe novo delta funcional autorizado pelo plano |

**Sequência:** entregar correção documental → frota conferir o item 225 → acompanhar implementação Google 0.12.0 → incorporar eventual defeito reproduzível ou demanda nova → revisar este plano → implementar/validar somente o delta definido → fechar artefatos de eventual 1.37.0. Não há data comprometida nos pedidos recebidos.

O quadro do próximo relatório deve ficar na seção **2. Convivência e encaminhamentos**, correspondente ao item 3 da ordem geral que conta o título como item 1. Preservar as oito seções do modelo de entrega. O campo de entrada/saída deve dizer explicitamente “nenhuma” quando o delta for vazio; não omiti-lo.

## 4. Integração com o Google e demais fronteiras

O plano Google 0.12.0 prevê um consumidor opcional, a leitura administrativa `google/conversion-context` e o bloco `core_conversion_context` em `gtm/diagnostico`. Esses nomes são capacidades **planejadas do Google**, não abilities do Core nem funções existentes no Google 0.11.0.

O retorno Core fica no mesmo documento [base-site-core-fator3-1.36.0-impacto-wp-mcp-google-fator3.md](base-site-core-fator3-1.36.0-impacto-wp-mcp-google-fator3.md), agora **r3**, classificação `validacao-coordenada`, situação `alinhado`: decisão/publicação resolvida; aceite do consumidor pendente. O ciclo de implementação é acompanhado pelo impacto Google 0.12.0 → Core r1 recebido. Não emitir um impacto Core 1.37.0 apenas por mudança de número.

Condições a preservar e critérios para analisar um eventual caso mínimo:

- Provider, contrato, versão e métodos exatos; `schema_revision` como string `"1"`; capability `conversion.purposes.read`; snapshot sem offset/limit.
- Schema PHP para chamada PHP, separado da decoração da ability. Uma finalidade contact e uma material, identificadas por `purpose`; duplicação ou ausência deve ser rejeitada pelo consumidor.
- IDs próprios de material, sem fallback para contato; false, null, vazio e enabled:true/configured:false preservados. Não transformar flags de verificação false em aceite comercial.
- Autorização administrativa nas entradas Google: manage_options, capability configurada e políticas de canal. A classe PHP Core não substitui a autorização do consumidor.
- Conferir measurement_revision ao combinar contextos e revalidar a revisão de conversões após a consulta GTM existente. Em conflito, descartar o bloco adicional e preservar o diagnóstico antigo válido; não repetir escrita externa.
- Consumidor tolera ausência da classe/contrato e rollback Core para 1.35.0. Somente a descoberta adicional fica indisponível; não criar dependência de atualização simultânea.
- Leitor puro sem rede ou escrita de configuração. Auditar separadamente possíveis registros da infraestrutura. Nenhuma criação automática de ação, tag, campanha ou evento-chave no fornecedor.

**Responsabilidade Core:** manter o produtor entregue e tratar divergência reproduzível se houver. **Responsabilidade Google:** implementar os caminhos novos, permissões, validação e matriz da 0.12.0. **Dono/frota:** configuração de ações/IDs e homologação comercial. O recebimento do plano Google não demonstra implementação do consumidor.

Escopo de impacto examinado: contrato de configuração, perfil, inventário de abilities, produtor de conversões e transporte/descoberta MCP. A correção externa de relatório não muda runtime, permissões, dados, jobs, SDK, Meta, LinkedIn ou implantação. Não foi identificado impacto técnico novo que justifique documento individual para esses pacotes. MCP 0.25.0 planejado não é dependência deste trabalho. APIs comerciais e ciclos com aplicativos reais permanecem `nao-avaliado` nesta rodada, sem emissão de impacto genérico por destinatário.

## 5. Validação proporcional ao delta

**Já realizada para a correção documental:** verificação dos hashes dos ZIPs da base; inventário administrativo; comparação de nomes das abilities 1.35.0/1.36.0; leitura dos critérios do catálogo/gerador; preenchimento do relatório e conciliação dos aceites recebidos. Nenhum novo teste de formulário, envio Slack, instalação, migração, rollback ou acesso a conta comercial foi executado nesta rodada.

**Se uma 1.37.0 de software for necessária:** atualizar primeiro escopo e critérios de aceite; então validar o candidato efetivo. A evidência histórica 1.36.0 não pode ser renomeada como teste 1.37.0.

| Verificação futura | Evidência exigida / limite |
|---|---|
| Correção que motivar a release | Reprodução anterior e demonstração do resultado no candidato; testar limites diretamente afetados |
| Identidade e contrato | Slug/basename preservados; versão coerente; quadro de opções/abilities recalculado; schemas, perfil e documentação concordantes |
| Instalação limpa e upgrade direto | WordPress 7.1.2/PHP 8.3.6; upgrade 1.36.0 → candidato com dados/configuração preservados; sem criar intermediária |
| Coexistência | Versões reais disponíveis dos acompanhantes; preservar SDK antigo e caminho opcional; não declarar Google 0.12.0 homologado enquanto só houver plano |
| Prontidão e documentação instalada | Executor real concluído sem falhas; leitura MCP paginada com versão/hash estáveis e permissões verificadas, conforme o delta |
| Site-Teste, quando autorizado no ciclo de implementação | Usar instalador final com expected_slug e expected_sha256; registrar estado anterior/final, evidência e limpeza pertinentes |
| Entrega | Instalador fechado antes dos testes finais; fonte com código/build/evidências sanitizadas e cópia anterior ao fechamento; relatório externo com bytes/hash finais |

Repetir testes amplos somente quando o delta ou uma exigência de release os justificar. Para a correção externa atual, não há candidato nem motivo para reinstalar a mesma versão. Os efeitos de reversão, filas e contas comerciais seguem os limites do relatório 1.36.0 até haver alteração comprovada.

## 6. Limites e pendências

1. **Pedido 225:** correção externa pronta, conferência pela frota pendente. A lista central permanece intacta; o próximo relatório de release deve repetir o quadro completo com números atualizados.
2. **Google 0.12.0:** implementação e aceite ainda pendentes do mantenedor Google. Não bloquear sua implementação aguardando Core 1.37.0.
3. **Nova release Core:** falta um delta distribuído que justifique gerar a 1.37.0. Uma divergência concreta recebida deverá ser registrada e avaliada antes de ampliar o escopo.
4. **Homologações externas:** rollback real no Site-Teste, Lead Sync LinkedIn com aplicativo real, envio comercial Meta, Google/Pipedrive e material com IDs próprios não foram reexecutados. Dependem dos responsáveis, ambientes e contas apropriados.
5. **Frota:** aceites de produção adicionais ficam na pendência 20. A evidência recebida não é apresentada como teste próprio nem altera os documentos centrais.

Não ampliar a enumeração fechada do SDK de medição, habilitar integrações comerciais, inventar IDs, alterar consentimento ou reabrir 212(a)/224/222 sem evidência nova. Publicar a próxima versão na frota continua sendo decisão do dono.

## 7. Artefatos, identidade e referências

Artefatos desta rodada documental: este plano r1; relatório externo 1.36.0 r2; impacto Core 1.36.0 → Google r3. Os dois ZIPs abaixo são a base aceita novamente disponibilizada, **não builds novos**.

| Artefato da base | Bytes | SHA-256 |
|---|---:|---|
| [base-site-core-fator3-1.36.0-instalador.zip](base-site-core-fator3-1.36.0-instalador.zip) | 1967841 | `eeec2a765d7e004aab1046fd59a25e455b6b5651d4468368fdf220b3e23d811b` |
| [base-site-core-fator3-1.36.0-fonte.zip](base-site-core-fator3-1.36.0-fonte.zip) | 2088119 | `867b4a3dd122858019526197a093168deba6a484de123e0c8349140b1fa82063` |

[base-site-core-fator3-1.36.0-relatorio.md](base-site-core-fator3-1.36.0-relatorio.md), r2, contém o quadro corrigido e mantém a ordem de entrega. A cópia do relatório dentro do ZIP fonte permanece congelada, anterior ao fechamento e às revisões externas; não reabrir o ZIP para inserir r2.

Fontes recebidas: `Fator3 Site Core(3).md` (última entrega/aceites e pedido 225); instruções comuns e padrão de desenvolvimento r4, 16/10/2026; plano Google 0.12.0 r1 e impacto → Core r1 de 17/10/2026 16:03:52 −03; impacto Google 0.11.0 → Core r3 e relatório Google 0.11.0 r2. As provas históricas da implementação Core estão no fonte 1.36.0; as novas consultas foram usadas apenas para inventário e planejamento.

Se o alvo se tornar uma release efetiva, os nomes previstos são `base-site-core-fator3-1.37.0-instalador.zip`, `base-site-core-fator3-1.37.0-fonte.zip` e `base-site-core-fator3-1.37.0-relatorio.md`. Tamanhos, hashes e resultados ainda não existem e não são antecipados neste plano.
