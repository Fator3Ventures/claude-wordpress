# Documentação instalada — Core 1.37.0

Índice vigente. Ajuda estática: f3base/documentacao-ler, manage_options, arquivo/linha/limite até 200, SHA-256 e proxima_linha. Continue até nulo. Histórico não substitui estes procedimentos.

| Arquivo | Conteúdo |
|---|---|
| RELEASE-1.37.0.md | Regras comerciais e atualização 1.36 → 1.37 |
| AGENTES-1.37.0.md | Receitas, autorização, leitura e evidência |
| CONVERSOES-CONTEUDO-1.35.md | Configuração, eventos, deduplicação, Pipedrive e limite do SDK |
| CONVERSOES-SDK-1.36.md | Contrato opcional por finalidade, permissões e receitas |
| schemas/conversion-*.json / fixtures/conversion/*.json | Schemas e exemplos do contrato novo |
| PIPEDRIVE-1.37.md | Título, empresa, respostas, serviço, C1, oportunidade e thread |
| CONFIGURACAO.md / AJUDA-OPCOES.md | Configuração e ajuda extraída do código |
| CONTRACTS.md / dados/abilities-*.json | Contratos e schemas integrais |
| dados/configuracao-schema.json | Contrato administrativo 8.2.0 |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas, unidades, retenção e vínculos |
| ../dados/estado-inventario.json | Propriedade e backup de estado |
| MEDICAO-SDK-1.33.md / MEDICAO-EVENTOS-1.33.md | SDK 1.0.0 fechado; não inclui material |
| schemas/measurement-*.json / fixtures/measurement/*.json | Exemplos e schemas do SDK mantido |
| LINKEDIN-LEAD-SYNC.md / GSC-1.34.md | Integrações mantidas |
| OPERACAO-E-RECUPERACAO.md / VALIDACAO.md | Recuperação e tipos de prova |

RELEASE/AGENTES/IMPACTO/CORRECOES de versões anteriores são históricos. As regras comerciais desta release prevalecem sobre textos históricos. A leitura não ativa integrações nem comprova acesso a fornecedor.
