> Revisão 2 · 18/10/2026 · Etapa: entrega · Situação: implementação Core concluída; aceite coordenado pendente.
>
> Contrato efetivo 8.2.0, 65 opções operáveis, 130 abilities, delta zero. Perfil piso-padrao-3.5 preservado. Instalador base-site-core-fator3-1.37.0-instalador.zip, 1.987.998 bytes, SHA-256 a7cd1c225bb9de76a5d1c3ad4b2184df47a6270856da902b8a268a4105ad20ad.
>
> Cinco propriedades e dois papéis novos implementados conforme a proposta. Schemas gerados da instalação nativa em docs/dados/configuracao-schema.json; guia PIPEDRIVE-1.37.md. Instalação limpa e upgrade da 1.36 passaram; testes de catálogo recusam texto curto, alternativas desconhecidas e tipos de atividade ausentes. Escolhas anteriores preservadas; sem ativação automática. SDKs de medição/conversões e seus schemas idênticos à base.
>
> Implantador: runtime 2.5.0 não fornecido, portanto integração operacional não avaliada. Responsável Implantador deve conferir descoberta/edição do contrato 8.2.0; frota decide distribuição. Projeto Pipedrive fornece chaves reais, homologa tipos/serviços/prazo/thread e coordena o aceite em CTOoffice/korvena.com.br. Nenhum pacote externo foi modificado ou encaminhamento enviado. Este documento não encerra o trabalho desses responsáveis.
>
> Histórico da proposta r1 abaixo, mantido como registro; os valores efetivos desta revisão prevalecem.

# Impacto de Fator3 Site Core 1.37.0 em Fator3 Implantador

Revisão 1 · 2026-10-18 · Etapa: planejamento · Situação: aberto.
Emissor: base-site-core-fator3, base 1.36.0, alvo 1.37.0 previsto; instalador-alvo ainda não gerado.
Destinatário: implantador-base, 2.5.0 citado na aba de 17/10; runtime atual não fornecido nem homologado.
Classificação: validacao-coordenada · Natureza: contrato/configuração comercial.
Referências: Pedidos core 225/226; Pedidos ao implantador 5, 7 e 10 apenas como vínculo, sem declarar implementação externa.

## Proposta e consequência

O contrato administrativo passa de 8.1.0 para 8.2.0 por adição de propriedades de f3base_pipedrive. SDKs site-measurement-context/1.0.0 e site-conversion-purposes/1.0.0 permanecem intactos. Nenhuma nova option ou ability é prevista. Configuração existente será preservada; sem ativação automática de integrações, atividade ou homologação.

Propostos: empresas_invalidas; mapa_servicos_formularios e mapa_servicos_campanhas; atividade_canais e atividade_janela. mapa_campos recebe os papéis respostas_formulario (texto longo) e lead_nativo_id (texto). Título explícito sem {site} passa a omitir o host; {unidade} usa o rótulo da alternativa cadastrada. Modelo vazio conserva o padrão com host. O tipo legado atividade_tipo é mantido; a seleção nova por canal tem precedência para novas atividades quando configurada/padrão efetivo da 1.37.0, e precisa dos tipos existentes na conta.

## Ação e aceite

Core publica schema, ajuda, exemplos, defaults e critérios efetivos na entrega. Implantador deve descobrir o contrato/configuração efetivo antes de gravar, aceitar as propriedades novas se oferecer esse formulário e preservar campos desconhecidos ao editar uma configuração existente. Não fixar IDs da conta nem preencher chaves de campos com exemplos. Perfis e ativação permanecem sob decisão do dono. Nenhuma alteração no implantador foi solicitada para habilitar o runtime isolado do Core.

Aceite coordenado: instalação nova e atualização não habilitam Pipedrive; gravação conforme schema 8.2.0 preserva configuração alheia e aplica recusas de tipos/alternativas; preview reproduz os critérios 226. Atualizar o catálogo de distribuição somente após a release efetiva e a decisão da frota, usando o hash final e mantendo os requisitos comprovados. A compatibilidade do runtime implantador permanece não avaliada por ausência do pacote.

## Validação prevista e pendências

Bancada WordPress 7.1.2/PHP 8.3.6: instalação limpa, upgrade 1.36.0, configuração, títulos, empresa, campos, serviço e atividade. Site-Teste: instalação e documentação; Pipedrive real deve ser conferido em CTO/korvena com o projeto Pipedrive, conforme regra do dono. Não será enviado este documento nem alterado pacote alheio.
