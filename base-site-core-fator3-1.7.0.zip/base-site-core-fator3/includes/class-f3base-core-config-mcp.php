<?php
/** Configuração persistente do Core, com schema, simulação e revisão concorrente. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Core_Config_Mcp {
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) { return; }
		$nomes = array_keys( array_filter( F3Base_Options::catalogo(), static fn( $d ) => ! empty( $d['operavel'] ) ) );
		$nome = array( 'type' => 'string', 'enum' => $nomes );
		$comum = array( 'category' => F3BASE_PREFIXO, 'permission_callback' => static fn( $entrada = null ) => current_user_can( 'manage_options' ), 'output_schema' => array( 'type' => 'object' ) );
		wp_register_ability( 'f3base/config-core-ler', array_merge( $comum, array(
			'label' => 'Ler configuração persistente do Core',
			'description' => 'Lê valores operáveis, revisão opaca, origem e schema do próprio Core; segredos são mascarados. Independe do implantador.',
			'input_schema' => array( 'type' => 'object', 'properties' => array( 'nome' => $nome ), 'additionalProperties' => false ),
			'execute_callback' => array( __CLASS__, 'ler' ),
		) ) );
		wp_register_ability( 'f3base/config-core-escrever', array_merge( $comum, array(
			'label' => 'Simular ou aplicar configuração persistente do Core',
			'description' => 'Grava pela operação do dono (F3Base_Options::gravar). Envie valor completo e revisão. Simular é o padrão. Confira persisted, effect e verification separadamente; ok mantém compatibilidade. A recusa do Core não autoriza escrita direta ou alteração do tema.',
			'output_schema' => F3Base_Config_Contrato::schema_gravacao(),
			'input_schema' => array( 'type' => 'object', 'properties' => array( 'nome' => $nome, 'valor' => array( 'description' => 'Valor completo conforme o schema da option.' ), 'revisao_esperada' => array( 'type' => 'string', 'pattern' => '^[a-f0-9]{64}$' ), 'simular' => array( 'type' => 'boolean', 'default' => true ) ), 'required' => array( 'nome', 'valor', 'revisao_esperada' ), 'additionalProperties' => false ),
			'execute_callback' => array( __CLASS__, 'escrever' ),
		) ) );
		wp_register_ability( F3Base_Config_Contrato::HABILIDADE, array_merge( $comum, array(
			'label' => 'Contrato de configuração do Core — v1',
			'description' => 'Catálogo versionado do dono: tipos, limites canônicos, aceitação de entrada, valores atuais, padrões, revisão, dependências e operações permitidas. Segredos mascarados. Leitura de estado do site; não edita os JSONs do implantador.',
			'input_schema' => array( 'type' => 'object', 'properties' => array( 'nome' => array( 'type' => 'string', 'enum' => F3Base_Config_Contrato::nomes() ) ), 'additionalProperties' => false ),
			'output_schema' => F3Base_Config_Contrato::schema_resposta(),
			'execute_callback' => array( 'F3Base_Config_Contrato', 'consultar' ),
			'meta' => array( 'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ) ),
		) ) );
		wp_register_ability( F3Base_Config_Contrato::VERIFICAR, array_merge( $comum, array(
			'label' => 'Consultar a verificação de uma configuração do Core',
			'description' => 'Consulta prova e escopo do comportamento sem regravar a preferência nem repetir seu efeito. ok indica consulta executada; o resultado da verificação fica em verification.status.',
			'input_schema' => array( 'type' => 'object', 'properties' => array( 'nome' => array( 'type' => 'string', 'enum' => F3Base_Config_Contrato::nomes() ), 'revisao_esperada' => array( 'type' => 'string', 'pattern' => '^[a-f0-9]{64}$' ) ), 'required' => array( 'nome' ), 'additionalProperties' => false ),
			'output_schema' => array( 'type' => 'object', 'properties' => array( 'ok' => array( 'type' => 'boolean' ), 'codigo' => array( 'type' => 'string' ), 'nome' => array( 'type' => 'string' ), 'revisao' => array( 'type' => 'string' ), 'existe_no_banco' => array( 'type' => 'boolean' ), 'verification' => F3Base_Config_Contrato::schema_verificacao(), 'configuracao_alterada' => array( 'type' => 'boolean' ), 'efeito_repetido' => array( 'type' => 'boolean' ) ) ),
			'execute_callback' => array( 'F3Base_Config_Contrato', 'verificar' ),
			'meta' => array( 'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ) ),
		) ) );
	}
	public static function ler( $entrada = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) { return array( 'ok' => false, 'codigo' => 'sem_permissao' ); }
		$saida = array(); $pedido = is_array( $entrada ) ? (string) ( $entrada['nome'] ?? '' ) : '';
		foreach ( F3Base_Options::catalogo() as $nome => $d ) {
			if ( ! F3Base_Options::operavel( $nome ) || ( '' !== $pedido && $pedido !== $nome ) ) { continue; }
			$schema = F3Base_Config_Contrato::campos( $d );
			$foto = F3Base_Options::fotografia( $nome );
			if ( ! empty( $foto['erro'] ) ) { return array( 'ok' => false, 'codigo' => 'leitura_falhou' ); }
			$saida[ $nome ] = array( 'valor' => self::visivel( $nome, $foto['valor'] ), 'revisao' => $foto['revisao'], 'origem' => F3Base_Options::proveniencia( $nome ), 'schema' => F3Base_Config_Contrato::schema_valor( $d ), 'schema_entrada' => F3Base_Config_Contrato::schema_entrada( $d ), 'campos' => $schema, 'existe_no_banco' => $foto['existe'], 'verification' => F3Base_Options::verificar_configuracao( $nome, $foto['valor'] ) );
		}
		return array( 'ok' => '' === $pedido || isset( $saida[ $pedido ] ), 'opcoes' => $saida, 'contract_version' => F3Base_Config_Contrato::VERSAO, 'contrato' => F3Base_Config_Contrato::HABILIDADE );
	}
	private static function visivel( string $nome, $valor ) {
		return F3Base_Config_Contrato::visivel( $nome, $valor );
	}
	public static function escrever( $entrada ): array {
		if ( ! current_user_can( 'manage_options' ) ) { return self::recusa( 'sem_permissao' ); }
		if ( ! is_array( $entrada ) || ( array_key_exists( 'simular', $entrada ) && ! is_bool( $entrada['simular'] ) ) ) { return self::recusa( 'entrada_invalida' ); }
		$nome = is_string( $entrada['nome'] ?? null ) ? $entrada['nome'] : '';
		if ( ! F3Base_Options::operavel( $nome ) || ! array_key_exists( 'valor', $entrada ) ) { return self::recusa( 'option_nao_operavel' ); }
		$foto = F3Base_Options::fotografia( $nome ); if ( ! empty( $foto['erro'] ) ) { return self::recusa( 'leitura_falhou' ); } $revisao = $foto['revisao']; $esperada = $entrada['revisao_esperada'] ?? '';
		if ( ! is_string( $esperada ) || ! hash_equals( $revisao, $esperada ) ) { if ( false === ( $entrada['simular'] ?? true ) ) { F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'conflito' ); } return self::recusa( 'conflito', 'A configuração mudou; leia novamente antes de aplicar.' ); }
		$d = F3Base_Options::declaracao( $nome );
		$validacao = rest_validate_value_from_schema( $entrada['valor'], F3Base_Config_Contrato::schema_entrada( $d ), $nome );
		if ( is_wp_error( $validacao ) ) {
			if ( false === ( $entrada['simular'] ?? true ) ) { F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'tipo_invalido' ); }
			return self::recusa( 'tipo_invalido', 'Tipo incompatível com o schema de entrada da option.' );
		}
		$recusa = F3Base_Options::recusar( $nome, $entrada['valor'], $d );
		if ( '' !== $recusa ) {
			if ( false === ( $entrada['simular'] ?? true ) ) { F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'valor_recusado' ); }
			return self::recusa( 'valor_recusado', F3Base_Options::e_segredo( $nome ) ? 'Valor secreto recusado.' : $recusa );
		}
		$ajuste = F3Base_Options::ajustar_na_escrita( $nome, F3Base_Options::sanitizar( $nome, $entrada['valor'] ), $d );
		$valor = $ajuste['valor'];
		if ( $entrada['simular'] ?? true ) {
			return array_replace( F3Base_Options::resultado_gravacao( false, self::visivel( $nome, $foto['valor'] ) ), array( 'ok' => true, 'simulado' => true, 'nome' => $nome, 'revisao' => $revisao, 'antes' => self::visivel( $nome, $foto['valor'] ), 'depois' => self::visivel( $nome, $valor ), 'motivo' => F3Base_Options::e_segredo( $nome ) ? 'Valor secreto preservado na simulação.' : trim( implode( ' ', $ajuste['avisos'] ) . ' ' . F3Base_Options::aviso_de_normalizacao( $nome, $entrada['valor'], $valor ) ) ) );
		}
		$r = F3Base_Options::gravar( $nome, $entrada['valor'], F3Base_Options::ORIGEM_MANUAL, $esperada );
		$r['lido'] = self::visivel( $nome, $r['lido'] ); $r['revisao'] = $r['revisao'] ?? F3Base_Options::revisao( $nome );
		if ( F3Base_Options::e_segredo( $nome ) && ! empty( $r['ok'] ) ) { $r['motivo'] = ''; }
		return $r;
	}
	private static function recusa( string $codigo, string $motivo = '' ): array { return F3Base_Options::resultado_gravacao( false, null, $motivo, $codigo ); }
}
