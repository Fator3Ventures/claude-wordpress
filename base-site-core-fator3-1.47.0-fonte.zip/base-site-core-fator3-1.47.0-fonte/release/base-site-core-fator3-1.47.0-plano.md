# Plano — Fator3 Site Core 1.47.0

22/10/2026. Base 1.46.1, instalador SHA-256 2e834ba27728a32a22fa588cc05863d1d69ccc2e09b0c05e016d88404eaadc76. Somente Pedidos core 284–287. Site-Teste autorizado; produção e publicação ficam com a frota.

1. 284: prova de criação da atividade do e-mail automático, vínculo durável à eliminação, inventário de notas/atividades impeditivas e declaração das cópias de e-mail restantes. Não apagar thread inteira por inferir autoria a partir do vínculo ao lead.
2. 285: mesmo event_id no navegador e fila; payload LinkedIn, consentimento/supressão, prévia administrativa, transporte/destino vinculados, recusas/incerteza/repetição. Adaptador público site-conversion-delivery/1.0.0, consumidor site-core-conversions, destino linkedin; nenhuma leitura de tokens/opções privadas do provedor. LinkedIn 0.5.0 não implementa o destino; impacto pertinente emitido antes da parte dependente.
3. 286: papel contato do tipo text, obrigatório por presença, grupo, classificação no servidor, sem exigir JavaScript do tema; integrações recebem somente contato válido normalizado, original continua no registro privado.
4. 287: confirmação interna renderizada no template nativo, conteúdo de blocos e mensagem/botão único do formulário; cabeçalhos de privacidade preservados.

Validar funções afetadas, isolamento, atualização 1.46.1→1.47.0, documentação MCP e casos sintéticos no Site-Teste. Sem reabrir 274–283, já aceitos pela frota no documento recebido. Relatórios de impacto somente LinkedIn (contrato novo de destino) e Implantador (schema/cópia de formulário).
