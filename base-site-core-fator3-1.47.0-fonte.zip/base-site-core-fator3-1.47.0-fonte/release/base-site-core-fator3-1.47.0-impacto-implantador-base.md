# Impacto de Site Core 1.47.0 no Implantador

Data: 22/10/2026 · revisão 2 · etapa entrega · aberto · acao-necessaria.
Emissor base-site-core-fator3, base direta 1.46.1, alvo entregue 1.47.0. Instalador: base-site-core-fator3-1.47.0-instalador.zip, SHA-256 dd16cb720e57c2d448e78a744eb0fd761d6aff04aadeeed8309b6b5003b417c1.
Destinatário: implantador-base, identidade do encaminhamento 1.46.x; versão/fonte atual não recebidos. Natureza: contrato de formulário e transição de tema. Pedido Core 286; complemento ao item 21 do Implantador. Confirmação relacionada: Core 287.

## Mudança e consequência

O schema de f3base_formularios admite papel contato exclusivamente em campo text da etapa 1. Campo único Celular ou e-mail: obrigatório exige presença; pode pertencer a exigir_um_de, com obrigatório individual false. E-mail válido preenche email normalizado; demais valores passam pelo telefone livre no país declarado, com classe valido, sem_ddd ou invalido. campos.<nome> conserva o original, contato_normalizacao traz classificação; só identidade válida segue para integrações. Campo preenchido de papel contato prevalece sobre cópias ocultas legadas. Campos separados continuam suportados.

Confirmacao_url interna usa o template da página pública e o conteúdo principal, com blocos, mensagem e botão do Core somente se a URL de WhatsApp for válida. O rótulo usa mensagens.continuar_whatsapp; noindex/no-store/no-referrer permanecem. O Core não remove botões inseridos pelo autor da página. Tema deve executar o fluxo normal the_content; templates que o contornam exigem adequação.

## Ação e sequência

Atualizar cópia do schema e seleção de papel do Implantador. Em cada site, conferir Core 1.47.0, declarar papel contato e então retirar a cópia para hidden email/telefone em contato.js. Sites anteriores conservam o caminho compatível até a troca. Não aplicar migração em massa por simples atualização de pacote. Conferir páginas de confirmação e evitar um segundo botão de WhatsApp no conteúdo editorial quando já usam o botão do Core.

## Validação e aceite

Core: 32 verificações locais; no Site-Teste, formulário público temporário sem cópias ocultas recebeu por POST nativo, sem JavaScript, voce@empresa.com.br, 11 91234-5678 e abc; persistência confirmou e-mail, telefone +5511912345678 válido e texto classificado inválido sem identidade normalizada. Formulário com campos de etapa 2 também funcionou no fallback. Quatro confirmações mantiveram cabeçalho, rodapé, blocos, um botão do Core com rótulo próprio e headers privados. Localmente, a sequência de duas etapas e a confirmação sem botão também passaram. Configurações e páginas temporárias foram removidas.

Implantador/frota devem validar o popup e contato.js do tema real depois da transição; fonte do Implantador não foi testado nesta entrega. Confirmação Segunda Opinião de ctooffice é aceite de frota após instalação, não prova realizada no Site-Teste. Sem novo impacto relevante para Google/MCP/Meta no escopo examinado.

## Evolução e resposta esperada

Revisão 1 emitida no planejamento; revisão 2 registra contrato e evidência implementados. Aguardam adequação/validação do Implantador e migração explícita pela frota, informando versão e teste do tema. Encaminhamento anterior 1.46.x conserva seus próprios aceites. Documento entregue ao dono, sem transmissão a terceiros nem alteração do Implantador.
