# Fator3 Site Core 1.47.0 — fonte

Runtime em work/plugin/base-site-core-fator3, idêntico ao instalador final. Este ZIP não é instalável. Base direta 1.46.1; contrato 8.12.0; pedidos 284–287. Build/testes em build/README.md; relatório na raiz e impactos em release/.

companions/ contém versões intactas usadas apenas em testes (MCP 0.26.1, Google 0.17.0, LinkedIn 0.5.0, Meta 0.4.1). Não são instaladas com o Core. evidence/ contém somente provas da rodada; scripts 1460/1461 retidos e relatório histórico não representam reexecução completa. Banco, runtime, sessões e instalador-base são externos e não acompanham o ZIP.
