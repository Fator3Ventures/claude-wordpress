from pathlib import Path
import os, subprocess, socket, time, sys
root=Path(__file__).resolve().parents[1]
runtime=Path(os.environ['F3BASE_RUNTIME'])
env=dict(os.environ,LD_LIBRARY_PATH=str(runtime/'usr/lib/x86_64-linux-gnu'),F3BASE_SITE=str(root/'lab/wordpress/wp-load.php'),F3BASE_ROOT=str(root))
data=Path('/tmp/f3core1470-mysql');files=root/'lab/mysql-files';files.mkdir(exist_ok=True)
base=[str(runtime/'usr/sbin/mysqld'),'--no-defaults','--user=root','--basedir='+str(runtime/'usr'),'--datadir='+str(data)]
if not data.exists():
 data.mkdir();subprocess.run(base+['--initialize-insecure'],env=env,check=True,capture_output=True)
log=open(root/'lab/mysql-run.log','a')
server=subprocess.Popen(base+['--port=33436','--bind-address=127.0.0.1','--socket=','--mysqlx=0','--pid-file='+str(root/'lab/mysql.pid'),'--secure-file-priv='+str(files)],env=env,stdout=log,stderr=log)
try:
 for i in range(100):
  if server.poll() is not None:raise RuntimeError('MySQL failed; see log')
  try:
   with socket.create_connection(('127.0.0.1',33436),.2):break
  except OSError:time.sleep(.1)
 else:raise RuntimeError('MySQL startup timeout')
 for test in sys.argv[1:]:
  command=([sys.executable] if test.endswith('.py') else [str(root/'build/php')])+[str(root/test)]
  result=subprocess.run(command,env=env);print('TEST',test,'EXIT',result.returncode,flush=True)
  if result.returncode:sys.exit(result.returncode)
finally:
 server.terminate()
 try:server.wait(timeout=15)
 except subprocess.TimeoutExpired:server.kill()
