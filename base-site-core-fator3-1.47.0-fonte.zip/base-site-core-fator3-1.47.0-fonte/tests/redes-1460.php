<?php
require __DIR__.'/bootstrap.php';
$original=F3Base_Options::ler('f3base_redes_robos');$config=F3Base_Options::ler('f3base_medicao_editorial');$cron=get_option('cron');
$body=wp_json_encode(array('creationTime'=>'2026-10-22','prefixes'=>array(array('ipv4Prefix'=>'203.0.113.0/24'))));
$response=static fn($status,$body='',$location='')=>array('headers'=>array('location'=>$location),'body'=>$body,'response'=>array('code'=>$status,'message'=>'fixture'),'cookies'=>array(),'filename'=>null);
$mode='ok';$calls=array();$filter=static function($pre,$args,$url)use(&$mode,&$calls,$body,$response){
    $calls[]=$url;check($args['redirection']===0&&$args['sslverify']===true&&empty($args['cookies']),'safe_args_'.count($calls));
    if($mode==='transport'){return new WP_Error('http_request_failed','Synthetic timeout');}
    if($mode==='http'){return $response(503);}
    if($mode==='invalid'){return $response(200,'{}');}
    if($mode==='blocked'){return $response(302,'','https://outside.example.test/ranges.json');}
    if($mode==='downgrade'){return $response(301,'','http://www.perplexity.ai/ranges.json');}
    if($mode==='credentials'){return $response(302,'','https://user:pass@www.perplexity.ai/ranges.json');}
    if($mode==='port'){return $response(302,'','https://www.perplexity.ai:8443/ranges.json');}
    if($mode==='unsupported'){return $response(307,'','https://www.perplexity.ai/ranges.json');}
    if($mode==='loop'){return $response(302,'',$url);}
    if($mode==='limit'){return $response(302,'','https://www.perplexity.com/ranges.json?hop='.count($calls));}
    if($mode==='relative'&&count($calls)===1){return $response(301,'','/ranges.json');}
    if($mode==='redirect'&&str_contains($url,'www.perplexity.com')){return $response(302,'',str_replace('www.perplexity.com','www.perplexity.ai',$url));}
    return $response(200,$body);
};add_filter('pre_http_request',$filter,10,3);
try{
    $fetch=new ReflectionMethod(F3Base_Redes_Robos::class,'obter_fonte');
    foreach(array('redirect','relative') as $mode){$calls=array();[$r,$d]=$fetch->invoke(null,F3Base_Redes_Robos::FONTES['perplexitybot'],1048577);check(count($calls)===2&&$d['http_status']===200&&$d['redirecionamentos'][0]['seguido'],'283_'.$mode);}
    foreach(array('blocked','downgrade','credentials','port','unsupported','loop') as $mode){$calls=array();[$r,$d]=$fetch->invoke(null,F3Base_Redes_Robos::FONTES['perplexitybot'],1048577);check(count($calls)===1&&!$d['redirecionamentos'][0]['seguido']&&isset($d['destino_redirecionamento']),'283_refuse_'.$mode);}
    $mode='limit';$calls=array();[$r,$d]=$fetch->invoke(null,F3Base_Redes_Robos::FONTES['perplexitybot'],1048577);check(count($calls)===3&&$d['erro']==='redirecionamento_nao_seguido','283_redirect_bound');
    raw('f3base_medicao_editorial',array_replace($config,array('redes_oficiais'=>true)));
    // A recent but unavailable source MUST be retried; fresh successful sources stay untouched.
    $fixture=array('listas'=>array(),'tentativas'=>array());
    foreach(F3Base_Redes_Robos::FONTES as $key=>$url){$fixture['listas'][$key]=F3Base_Redes_Robos::validar($body)+array('url'=>$url,'obtida_em'=>time(),'valida_ate'=>time()+DAY_IN_SECONDS);$fixture['tentativas'][$key]=array('em'=>time(),'resultado'=>'atualizada');}
    foreach(array('redirect','http','transport','invalid','blocked') as $mode){
        $state=$fixture;foreach(array('perplexitybot','perplexity-user') as $k){$state['tentativas'][$k]=array('em'=>time()-DAY_IN_SECONDS,'resultado'=>'fonte_indisponivel');}
        raw('f3base_redes_robos',$state);$calls=array();$r=F3Base_Redes_Robos::atualizar();$after=F3Base_Options::ler('f3base_redes_robos');
        check($r['ok']&&count($r['fontes'])===2,'283_daily_retry_'.$mode);
        foreach(array('perplexitybot','perplexity-user') as $key){
            $t=$after['tentativas'][$key];check($t['em']>$state['tentativas'][$key]['em'],'283_attempt_time_'.$mode.'_'.$key);
            if($mode==='redirect'){check($t['resultado']==='atualizada'&&$t['http_status']===200&&$t['redirecionamentos'][0]['http_status']===302,'283_live_shape_'.$key);check(F3Base_Redes_Robos::verificar($key,'203.0.113.4',true)['rede_estado']==='rede_compativel','283_classification_'.$key);}
            else{check($after['listas'][$key]===$state['listas'][$key],'283_preserve_valid_'.$mode.'_'.$key);check(str_starts_with($t['resultado'],$mode==='transport'?'fonte_indisponivel_transporte_http_request_failed':'fonte_indisponivel_http_'),'283_failure_detail_'.$mode.'_'.$key);}
        }
        $before=$after;$calls=array();F3Base_Redes_Robos::atualizar();check(!$calls&&F3Base_Options::ler('f3base_redes_robos')['tentativas']===$before['tentativas'],'283_no_busy_retry_'.$mode);
    }
    // Full missing-source cycle, including all three clouds; advance the existing future continuation.
    raw('f3base_redes_robos',array());wp_clear_scheduled_hook(F3Base_Redes_Robos::EVENTO,array('continuacao'));wp_schedule_single_event(time()+HOUR_IN_SECONDS,F3Base_Redes_Robos::EVENTO,array('continuacao'));
    $mode='http';$calls=array();$r=F3Base_Redes_Robos::atualizar();check($r['parcial']&&$r['restantes']===count(F3Base_Redes_Robos::FONTES)-2,'283_remaining_explicit');check(wp_next_scheduled(F3Base_Redes_Robos::EVENTO,array('continuacao'))<=time()+11,'283_continuation_advanced');
    for($i=0;$i<7;$i++){F3Base_Redes_Robos::atualizar();}
    $after=F3Base_Options::ler('f3base_redes_robos');check(count($after['tentativas'])===count(F3Base_Redes_Robos::FONTES)&&count($calls)===count(F3Base_Redes_Robos::FONTES),'283_all_missing_attempted_once');
    foreach(array('nuvem-aws','nuvem-google','nuvem-azure') as $key){check($after['tentativas'][$key]['resultado']==='fonte_indisponivel_http_503','283_cloud_attempt_'.$key);}
    $all=$after['tentativas'];$calls=array();F3Base_Redes_Robos::atualizar();check(!$calls,'283_all_backoff');
    foreach($after['tentativas'] as &$a){$a['em']-=DAY_IN_SECONDS;}unset($a);raw('f3base_redes_robos',$after);$calls=array();for($i=0;$i<8;$i++){F3Base_Redes_Robos::atualizar();}check(count($calls)===count(F3Base_Redes_Robos::FONTES),'283_next_daily_every_failed_retried');
    $configOff=$config;$configOff['redes_oficiais']=false;raw('f3base_medicao_editorial',$configOff);$calls=array();check(F3Base_Redes_Robos::atualizar()['codigo']==='desligado'&&!$calls,'283_toggle_preserved');
}finally{remove_filter('pre_http_request',$filter,10);raw('f3base_redes_robos',$original);raw('f3base_medicao_editorial',$config);raw('cron',$cron);}
evidence('redes-1460');
