from pathlib import Path
import os,subprocess,json,urllib.request,time,socket
root=Path(__file__).resolve().parents[1]
subprocess.run([str(root/'build/php'),str(root/'tests/confirmation-fixture-1470.php')],check=True)
f=json.loads((root/'lab/confirmation-1470.json').read_text());out={}
p=subprocess.Popen([str(root/'build/php'),'-S','127.0.0.1:8134','-t',str(root/'lab/wordpress')],stdout=subprocess.DEVNULL,stderr=open(root/'lab/http-1470.log','w'))
try:
 for _ in range(50):
  try:
   with socket.create_connection(('127.0.0.1',8134),.1):break
  except OSError:time.sleep(.1)
 for case in ['stage2','whatsapp']:
  with urllib.request.urlopen(f[case],timeout=20) as res:
   body=res.read().decode();h=dict(res.headers);status=res.status
  checks={'status':status==200,'header':'id="theme-header"' in body,'footer':'id="theme-footer"' in body,'style':'qa-theme-css' in body,'blocks':'wp-block-group bloco-qa' in body and '<!-- wp:group' not in body,'no_error_page':'id="error-page"' not in body,'single_message':body.count('class="f3base-confirmacao"')==1,'no_store':'no-store' in h.get('Cache-Control',''),'no_referrer':h.get('Referrer-Policy')=='no-referrer','no_index':'noindex' in h.get('X-Robots-Tag',''),'whatsapp_count':body.count('href="https://wa.me/')==(1 if case=='whatsapp' else 0)}
  if case=='whatsapp':checks['button_label']='Conversar com nossa equipe' in body
  out[case]=checks
  (root/'lab'/('confirmation-'+case+'.html')).write_text(body)
  assert all(checks.values()),(case,checks)
 (root/'evidence/confirmation-http-1470.json').write_text(json.dumps(out,indent=2));print('confirmation-http-1470: native theme and stage 2 OK')
finally:p.terminate();p.wait(timeout=10)
