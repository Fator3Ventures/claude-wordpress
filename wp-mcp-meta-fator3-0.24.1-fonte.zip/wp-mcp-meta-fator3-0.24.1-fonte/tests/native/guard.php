<?php
/** Prevent tests being accidentally run against the shared WordPress. */
const F3QA_CANDIDATE='0.24.1'; // versão candidata desta rodada
define('F3QA_BASE',getenv('F3_QA_FROM')==='0.23.0'?'0.23.0':'0.24.0');      // base vigente de migração
function f3qa022_root(): string {
    $root=getenv('F3_LAB_ROOT');
    if (!is_string($root)||!preg_match('/^f3qa022_[a-f0-9]{12}_$/D',basename($root))||
        $root!==sys_get_temp_dir().'/'.basename($root)||!is_dir($root)||is_link($root)) {
        throw new RuntimeException('An isolated native Meta lab is required');
    }
    return $root;
}
function f3qa022_guard_db(): void {
    global $wpdb;
    if ($wpdb->prefix!==basename(f3qa022_root())||ABSPATH!==f3qa022_root().'/wordpress/') {
        throw new RuntimeException('Private WP root or table prefix mismatch');
    }
    if (PHP_VERSION_ID<80300||PHP_INT_SIZE!==8||version_compare($GLOBALS['wp_version'],'7.1.4','<')) {
        throw new RuntimeException('Requires WordPress 7.1.4+ and 64-bit PHP 8.3+');
    }
}
