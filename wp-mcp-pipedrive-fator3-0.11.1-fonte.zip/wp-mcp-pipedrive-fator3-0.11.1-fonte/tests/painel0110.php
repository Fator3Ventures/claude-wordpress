<?php
use Fator3\Pipedrive\{AdminList,Admin,Store,Fault};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))throw new RuntimeException('WordPress descartável obrigatório');
$checks=[];$table=Store::table('journal');$ids=[];
try{
 for($i=0;$i<45;$i++){
    $id=bin2hex(random_bytes(16));$ids[]=$id;
    $meta=['previa_id'=>$id,'metodo'=>'POST','classe'=>'registro','status'=>$i===0?'operacao_recusada':'operacao_concluida','caminho'=>'/qa0110/'.($i===0?'antiga':($i===1?'por%cento':'recente')),'prova_recuperacao'=>'termo-reservado'];
    if(!$wpdb->insert($table,['previa_id'=>$id,'created'=>time(),'metadata'=>wp_json_encode($meta)]))throw new RuntimeException('Fixture de diário não gravada');
 }
 $list=static fn($t,$p=1,$extra=[])=>AdminList::journal(['busca'=>$t]+$extra,$p);
 $first=$list('qa0110');$last=$list('qa0110',95);$second=$list('qa0110',2);
 $checks['total_global_e_intervalos']=$first['total']===45&&count($first['items'])===20&&$last['page']===3&&count($last['items'])===5;
 $checks['paginas_sem_duplicar']=count(array_unique(array_column(array_merge($first['items'],$second['items'],$last['items']),'id')))===45;
 $checks['busca_atinge_a_mais_antiga']=($list('antiga')['items'][0]['previa_id']??'')===$ids[0];
 $checks['filtros_combinados']=$list('qa0110',1,['resultado'=>'operacao_recusada','classe'=>'registro'])['total']===1;
 $checks['texto_visivel_de_resultado']=$list('recusada')['total']>=1;
 $checks['percentual_literal']=$list('por%')['total']===1;
 $checks['prova_privada_nao_pesquisavel']=$list('termo-reservado')['total']===0;
 $checks['prova_privada_nao_renderizada']=!isset($first['items'][0]['prova_recuperacao']);
 foreach(['visao'=>'operacao','diario'=>'operacao','regras'=>'configurar','retencao'=>'configurar','pendencias'=>'suporte','ajuda'=>'suporte'] as $tab=>$group){parse_str(parse_url(Admin::url($tab),PHP_URL_QUERY),$q);$checks['destino_'.$tab]=$q['aba']===$tab&&$q['grupo']===$group;}
 wp_set_current_user(0);try{$list('');$checks['leitura_exige_administrador']=false;}catch(Fault){$checks['leitura_exige_administrador']=true;}
}finally{wp_set_current_user(1);foreach($ids as $id)$wpdb->delete($table,['previa_id'=>$id]);}
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count(array_filter($checks,fn($v)=>!$v))];
