# Testes da 0.11.1

A bancada usa WordPress real, PHP 8.3 de 64 bits com OpenSSL, mysqli, zlib, mbstring e DOM, MySQL ou MariaDB. A release foi preparada com WordPress 7.1.4. O serviço Pipedrive é simulado. Nenhum controlador de teste é instalado no site compartilhado. O MU-plugin de bancada `network-fence.php` recusa qualquer transporte HTTP real e bloqueia e-mails. O teste do Core recebe respostas sintéticas de filtros locais antes dessa recusa.

## Reprodução em uma estação

1. Tenha o ZIP oficial do WordPress (raiz `wordpress/`), os instaladores Pipedrive 0.10.0 e 0.11.1 e os hashes do relatório. Para a matriz, também tenha os cinco instaladores identificados em `evidence/0111/companion-installers.json`. A matriz vigente usa Core 1.81.1, MCP 0.44.0, Google 0.34.0, Meta 0.24.1 e LinkedIn 0.21.0.
2. Crie **três bancos novos e vazios** no MySQL local, um para cada cenário, e conceda privilégios somente nesses bancos a um usuário de teste. Defina `F3_QA_USER` e `F3_QA_PASSWORD` no ambiente. A ferramenta exige nomes começando com `f3pipqa_0900_`, recusa tabelas existentes e conecta exclusivamente a `127.0.0.1`. Ela não cria nem remove bancos.
3. Da raiz do fonte, rode o exemplo para cada cenário, usando diretório descartável ainda inexistente e fora do fonte. Troque os caminhos e use o SHA-256 do instalador publicado.

    python3 build/lab.py --scenario clean --db f3pipqa_0900_clean --work /tmp/f3qa-clean --wordpress /pacotes/wordpress-7.1.4.zip --base /pacotes/wp-mcp-pipedrive-fator3-0.10.0-instalador.zip --candidate /pacotes/wp-mcp-pipedrive-fator3-0.11.1-instalador.zip --candidate-sha256 SEU_SHA256

    Para migração, mude para `--scenario upgrade --db f3pipqa_0900_upgrade --work /tmp/f3qa-upgrade`. Para integração, use `--scenario matrix --db f3pipqa_0900_matrix --work /tmp/f3qa-matrix --companions /pacotes`. São aceitos `--php /caminho/php` e `--port 3306`. As extensões precisam estar disponíveis também para os processos filhos; em PHP isolado use PHPRC com caminho absoluto. Não use endereços, bancos, configurações ou credenciais de produção.
4. Cada suíte roda num processo PHP novo. Consulte `results/NOME.json` no diretório criado. A instalação do plugin usa `Plugin_Upgrader`. Na migração, uma instalação 0.10.0 recebe configuração, recibo, progresso, diário, pendência e política de retenção sintéticos; o instalador 0.11.1 é aplicado e outro processo confere persistência e replay. A matriz usa códigos reais dos cinco acompanhantes e intercepta o HTTP do fornecedor com dados sintéticos.
5. Depois de preservar os JSON sanitizados, elimine apenas os três bancos e diretórios descartáveis desta rodada. Os arquivos de configuração e os snapshots privados de migração não entram nas evidências distribuídas.

O catálogo de testes de comportamento inclui classificação de escritas ambíguas (`escritas090` e `restart090`), recuperação e autorizações (`recuperacao090`, `policy090`, `integrated`), fila e simulação (`fila090`), retenção e concorrência em processos PHP independentes (`travas090`), além de ajuda e catálogo (`doc090`, `documents050`). As suítes anteriores ainda pertinentes são executadas em conjunto. Mutantes são aplicados apenas em cópias descartáveis.

Os testes de navegador usam Chromium e Python Playwright em WordPress local com o fornecedor sintético. Os resultados do navegador são independentes das asserções PHP.

Para o teste nativo do painel, prepare um WordPress descartável com URL estritamente local `http://127.0.0.1:18490`, banco `f3pipqa_0900_browser`, `WP_HTTP_BLOCK_EXTERNAL=true`, regras iniciais, plugin ativo e administrador exclusivo da bancada. Copie `tests/fixture050.php` para `tests/` no diretório pai da raiz do WordPress, e `tests/browser090-fixture.php` para o diretório dos MU-plugins dessa instalação. A fixture tem travas de nome de banco, URL e bloqueio de HTTP externo. O diretório pai chama-se `browser` e deve conter um arquivo vazio `marker` para indicar a bancada; as contagens de chamadas são gravadas em `browser/browser090-counts.jsonl`. Defina `F3_BROWSER_URL`, `F3_WP_ROOT`, `F3_BROWSER_USER`, `F3_BROWSER_PASSWORD_FILE` (arquivo local privado) e, se necessário, `F3_CHROMIUM` (executável Chromium, inclusive headless shell). Execute `python3 tests/browser090.py`. O relatório sanitizado é `evidence/0111/browser090.json`. Para injetar os defeitos de truncamento do guia e repetição da mesma tentativa em cópias temporárias isoladas do código, execute a suíte PHP `painel090` com `F3_QA_MUTACAO_PAINEL=1`; o resultado esperado é falha nas respectivas asserções.

## Repetir o Pedido 13 na versão 0.11.1

Rode as suítes clean, matrix e upgrade de build/lab.py; para upgrade, execute em bancos distintos com os instaladores 0.10.0 e 0.11.0. Os hashes aceitos estão no próprio script. evidence/0111/companion-installers.json identifica os cinco instaladores da matriz final, inclusive o LinkedIn 0.24.0.

Para repetir as capturas e as provas com sessão, faça outra instalação clean em WordPress descartável numa pasta chamada clean, com banco f3pipqa_0900_r11_clean, em 127.0.0.1 e URL http://127.0.0.1:18491. Exporte F3_QA_DB, F3_QA_USER, F3_QA_PASSWORD e F3_QA_PORT para o banco de teste. Execute:

    python3 build/browser.py --work /bancada/clean --php /caminho/php --chromium /caminho/chromium

São necessários Python com Playwright, Chromium, PHP CLI com os módulos exigidos pelo WordPress e MariaDB/MySQL local. O inicializador redefine exclusivamente as regras da instalação descartável, gera uma senha temporária para o administrador sintético e remove a fixture de navegador ao sair. Abra evidence/0111/capturas/index.html para escolher uma aba e uma largura. Os PNGs são das páginas inteiras, antes de qualquer edição nessa sessão.
