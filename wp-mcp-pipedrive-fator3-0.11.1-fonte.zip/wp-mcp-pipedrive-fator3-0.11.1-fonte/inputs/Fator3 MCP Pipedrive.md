# Pedidos — Fator3 MCP Pipedrive

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-pipedrive-fator3**. Cite como "Pedidos MCP Pipedrive N". Próximo número: 14; número retirado fica vago.

## wp-mcp-pipedrive-fator3 — pendentes

**13 (14/11/2026, korvena.com.br e Site-Teste, P3; dono, 14/11/2026 às 11:03, no chat do Orquestrador | Geral: "Peça esse mesmo padrão visual a todas as telas de todos os plugins"). Todas as telas do MCP Pipedrive no padrão visual das telas.** Padrão: Padrão de entrega dos pacotes Fator3, aba Regra comum, "Padrão visual das telas" (referência: telas do MCP Meta 0.26.0 e do MCP LinkedIn 0.23.0). Em resumo: cabeçalho com título, linha de descrição e selo de versão à direita; navegação em dois níveis (grupos em pílulas, subabas sublinhadas), sem destino escondido em rolagem horizontal; cartões com título, orientação e ações; estado em selo com cor; rótulo acima do campo, grade que cai para uma coluna, avançado recolhível; tabela com busca, total e paginação, rolagem horizontal própria abaixo de 782 px e sem palavra partida; português com acento; 360 a 1440 px. Não mudam slug, capacidade, rotas e dados; endereço antigo de aba redireciona. Prova: capturas de cada aba a 360, 768 e 1440 px.

Divergências lidas em Ferramentas → Fator3 MCP Pipedrive de korvena.com.br com a 0.10.0, em 14/11 por volta das 11h −03, a 750 px: estilo próprio (classes f3pd-\*); linha "Integrações · CRM" acima do título; versão como selo no fim da descrição, não à direita do título; quatro abas em quadrados cinza (Visão geral, Regras de operação, Diário e retenção, Ajuda) no lugar de pílulas. O cartão "Precisa de atenção" e o cartão "Operação autorizada" já estão próximos do padrão; estados como "Habilitada" aparecem em texto, sem selo.
