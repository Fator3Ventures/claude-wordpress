# Padrão de entrega — Fator3 MCP Pipedrive (wp-mcp-pipedrive-fator3)

Para o agente responsável pelo Fator3 MCP Pipedrive. A regra comum aos pacotes está na aba "Regra comum", e o essencial vai repetido aqui.

## Arquivos

| tipo | nome | conteúdo |
| --- | --- | --- |
| instalador | `wp-mcp-pipedrive-fator3-<versão>-instalador.zip` | pasta interna `wp-mcp-pipedrive-fator3/`, arquivo principal `wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php` |
| fonte | `wp-mcp-pipedrive-fator3-<versão>-fonte.zip` | pasta interna `wp-mcp-pipedrive-fator3-<versão>-fonte/`: código, build, testes, evidências e uma cópia do relatório |
| relatório | `wp-mcp-pipedrive-fator3-<versão>-relatorio.md` | Markdown, em português, só deste pacote |
| impacto | `wp-mcp-pipedrive-fator3-<versão>-impacto-base-site-core-fator3.md` | contrato `pipedrive-api-client/1.0.0` exercitado e códigos de recusa; outro para `wp-mcp-fator3` só se o canal precisar mudar |

Versão `X.Y.Z`, sem sufixo; homologação e sha256 só dentro do relatório.

## Cabeçalho e tela

| campo | valor |
| --- | --- |
| Plugin Name | Fator3 MCP Pipedrive |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | Operação da conta Pipedrive pelo agente, com o token guardado no Fator3 Site Core. Configuração: Ferramentas → Fator3 MCP Pipedrive. |
| Version | `X.Y.Z`, a mesma do nome dos arquivos |
| Requires at least, Requires PHP | os validados pela versão (0.8.0: 7.1.4 e 8.3, 64 bits) |
| Author | Fator3 |
| Author URI | `https://www.fator3.com.br` |
| License | GPL-2.0-or-later |
| Text Domain | `wp-mcp-pipedrive-fator3` |
| Update URI | `https://fator3.com.br/plugins/wp-mcp-pipedrive-fator3` |
| tela | Ferramentas → Fator3 MCP Pipedrive, com `manage_options` |

**Capacidade.** A tela e as rotas `pipedrive/*` pedem `manage_options` no servidor, por MCP, REST e tela.

## O que não muda

Slug e pasta `wp-mcp-pipedrive-fator3`, arquivo principal, Text Domain, Update URI, o prefixo `pipedrive/` e os nomes das rotas já publicadas (19 operações na 0.8.0), o cliente `pipedrive-api-client/1.0.0` e o consumidor `wp-mcp-pipedrive-fator3` registrado no contrato do Core.

## Relatório

Nesta ordem:

1. Título `Entrega — Fator3 MCP Pipedrive <versão>`.
2. De onde a versão entra (WordPress limpo; versões anteriores aceitas direto) e as versões do Site Core e do Fator3 MCP com que foi validada, com a ordem de troca entre eles.
3. Escopo: as listas de leitura e de escrita e o que fica fora.
4. O que mudou, citando cada "Pedidos MCP Pipedrive N" atendido, com a evidência.
5. Prova da troca: `pipedrive/status` com contrato, autorização, conta e orçamento esperados.
6. Aceite de cada pedido atendido: exercitado ou pendente, com o caminho para fechar.
7. O que não foi homologado (conta real, endpoints v2 de campos).
8. Credenciais: nenhuma; o token fica no Site Core.
9. Identidade: nome, tamanho e sha256 do instalador e da fonte.

## Conformidade da 0.8.0 (09/11/2026)

Lida no `main` (commit `e3580d3`): instalador `wp-mcp-pipedrive-fator3-0.8.0-instalador.zip` (122.083 bytes, sha256 `89e41f2f…`) com a pasta `wp-mcp-pipedrive-fator3/` e o arquivo principal; fonte `wp-mcp-pipedrive-fator3-0.8.0-fonte.zip` (507.256 bytes, sha256 `b4ae837c…`) com a pasta `wp-mcp-pipedrive-fator3-0.8.0-fonte/`; os dois sha256 no relatório, só deste pacote, iguais aos dos arquivos; nenhum ZIP dentro de outro. Título `Entrega — Fator3 MCP Pipedrive 0.8.0`; cabeçalho e tela como acima. Nenhum pedido aberto sobre a entrega.
