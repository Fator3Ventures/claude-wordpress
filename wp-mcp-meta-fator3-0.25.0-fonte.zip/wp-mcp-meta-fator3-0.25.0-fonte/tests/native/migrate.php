<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();wp_set_current_user(1);
require __DIR__.'/migration-state.php';
require __DIR__.'/migration-consumer.php';
$before=json_decode(file_get_contents(f3qa022_root().'/baseline-state.json'),true,512,JSON_THROW_ON_ERROR);
$after=f3qa022_state();$checks=[];
$ck=static function(string $name,bool $ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>$ok];};
$ck('Base snapshot is from activated Meta '.F3QA_BASE,($before['source_version']??null)===F3QA_BASE);
$ck('New process loads active Meta '.F3QA_CANDIDATE,M\Config::VERSION===F3QA_CANDIDATE&&get_option('active_plugins')===['wp-mcp-meta-fator3/wp-mcp-meta-fator3.php']);
foreach(['records','history','options'] as $kind){
    $ck('Direct migration preserves count and digest: '.$kind,$before[$kind]===$after[$kind]);
}
$ck('Unlimited retention, owner and asset are preserved',($c=M\Connections::get('qa-upgrade021'))['retention_mode']==='unlimited'&&$c['users']===[1]&&$c['assets']['instagram']===['777071']);
$ck('Explicit 30-day policy remains finite',($c=M\Connections::get('upgrade-finite021'))['retention_mode']==='finite'&&(int)$c['retention_days']===30);
$ck('Paused job retains cursor and progress',($paused=M\Store::get('job','qa-paused021')['value'])['status']==='paused'&&$paused['cursor']==='synthetic-checkpoint'&&$paused['pages']===2&&$paused['rows']===5);
$ck('Schedule remains enabled',M\Store::get('schedule','qa-upgrade021')['value']['enabled']);
$ck('No automatic erasure; all four message receipts preserved',get_option('f3_meta_message_privacy_key',false)===false&&count(M\Store::list('message_event'))===4);
$ck('Monitoring grant remains ready',f3qa022_consumer()->status(['connection_id'=>'upgrade-monitor021','account_id'=>'160'])['success']);
$selection=['connection_id'=>'upgrade-monitor021','account_id'=>'160'];
$legacy=M\AdsReader::register_consumer('qa-legacy-ads','1.0.0',M\AdsReader::CONTRACT,static fn()=>$selection+['revision'=>'qa-v1','ready'=>true]);
$ck('Grant written by outgoing release still permits only local reads',$legacy->status($selection)['success']&&$legacy->ad_origin($selection+['ad_id'=>'776'])['code']==='ad_origin_not_granted');
if(F3QA_BASE==='0.24.1'){$alreadyGranted=M\AdsReader::register_consumer('qa-online-ads','1.0.0',M\AdsReader::CONTRACT,static fn()=>$selection+['revision'=>'qa-v1','ready'=>true]);
$ck('Patch preserves an explicit online permission written by 0.24.1',$alreadyGranted->status($selection)['data']['allow_ad_origin']===true);}
$h=M\Api::dispatch('health');$s=M\Api::dispatch('list-schedules');
$ck('Local health available and read-only',$h['success']&&($h['data']['repair']??null)==='not_attempted');
$related=static function(array $s){foreach($s as $v)if(($v['id']??$v['schedule_id']??null)==='qa-upgrade021')return $v;return [];};
$ls=$related($s['data']['schedules']??[]);$hs=$related($h['data']['schedules']??[]);
$ck('Prior error stays superseded in schedule and health',($ls['last_error_superseded']??false)&&($ls['last_error_at']??0)===100&&($hs['last_error_state']??null)==='superseded');
$docs=M\Documentation::read(['document'=>'README.md']);
$ck('New process serves candidate documentation',$docs['plugin_version']===M\Config::VERSION&&$docs['sha256']===hash_file('sha256',M\Config::DIR.'docs/README.md')&&isset($docs['title']));
// A7 em atualização: troca de arquivos sem reativação não toca marca nem progresso da migração do histórico.
$marker=M\Store::get('migration','history-020');
$ck('History migration marker and progress preserved by file swap',isset($before['history_migration']['value'])&&$marker===$before['history_migration']&&$marker['value']['complete']===false);
// Reativação com páginas ainda a migrar também não altera o progresso (a ativação só conclui quando não há páginas).
deactivate_plugins('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');$re=activate_plugin('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');
$ck('Reactivation with pending pages keeps marker and progress',!is_wp_error($re)&&M\Store::get('migration','history-020')===$before['history_migration']);
$out=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'version'=>M\Config::VERSION,'base_version'=>$before['source_version'],'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed'])),'records'=>$after['records']['count'],'history_rows'=>$after['history']['count'],'options'=>$after['options']['count']];
echo wp_json_encode($out)."\n";exit($out['failed']?1:0);
