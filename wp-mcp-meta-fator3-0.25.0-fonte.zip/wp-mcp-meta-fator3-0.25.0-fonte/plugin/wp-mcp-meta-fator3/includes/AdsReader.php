<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** In-process registered consumers; explicit grants never provide provider credentials. */
final class AdsReader {
    public const CONTRACT='meta-ads-reader/1.0.0';
    private static array $consumers=[];
    public static function contract(): array {return ['contract'=>self::CONTRACT,'registration_hook'=>'f3_meta_register_ads_consumers','sdk'=>self::class,'methods'=>['register_consumer','client.status','client.query'],'grant'=>'explicit_per_consumer_connection_account','source'=>'encrypted_local_history','remote_calls'=>false,'extensions'=>['ad_origin'=>['contract'=>AdOrigin::CONTRACT,'method'=>'client.ad_origin','grant_flag'=>'allow_ad_origin','default'=>false,'remote_calls'=>true,'writes_ads'=>false]],'writes_ads'=>false,'retention'=>'unlimited','levels'=>['account','campaign','adset','ad'],'identity'=>'day_level_entity_attribution; revisions_replace_not_add','attribution'=>Ads::ATTRIBUTION];}
    public static function register_consumer(string $id,string $version,string $contract,callable $configuration,string $label=''): AdsReaderClient {
        Util::id($id);if(!preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/D',$version)||$contract!==self::CONTRACT)throw new Fault('contract_mismatch','Contrato de consumidor Meta Ads incompatível.');
        if(isset(self::$consumers[$id]))throw new Fault('consumer_conflict','Consumidor de anúncios já registrado.');
        $client=new AdsReaderClient();self::$consumers[$id]=['client'=>$client,'configuration'=>$configuration,'version'=>$version,'label'=>sanitize_text_field($label?:$id)];return $client;
    }
    private static function principal(): array {
        $p=Access::principal();$sdk='\\Fator3\\McpFiles\\ConnectionContext';
        if(is_callable([$sdk,'transport_identity'])){$x=$sdk::transport_identity();if(is_array($x)&&preg_match('/^(grant:|app:)/',$x['connection_id']??'')&&(!$p['channel']||($x['user_id']??0)!==$p['user_id']))throw new Fault('not_authorized','Concessão de transporte revogada.');}
        Access::checkPrincipal($p);return $p;
    }
    private static function key(array $i): string {return hash('sha256',Util::json([$i['consumer_id'],$i['connection_id'],$i['account_id']]));}
    private static function configuration(string $id): array {
        if(!isset(self::$consumers[$id]))throw new Fault('consumer_unavailable','Consumidor de anúncios não registrado.');
        try{$v=(self::$consumers[$id]['configuration'])();}catch(\Throwable $e){throw new Fault('consumer_unavailable','Configuração do consumidor indisponível.');}
        if(!is_array($v)||($v['ready']??false)!==true||!is_string($v['connection_id']??null)||!is_string($v['account_id']??null)||!(is_int($v['revision']??null)||is_string($v['revision']??null)))throw new Fault('consumer_not_ready','Consumidor precisa informar conexão, conta e revisão prontas.');
        Util::id($v['connection_id']);Util::numeric($v['account_id']);if(strlen((string)$v['revision'])>128||(string)$v['revision']==='')throw new Fault('consumer_not_ready','Revisão inválida do consumidor.');
        return array_intersect_key($v,array_flip(['connection_id','account_id','revision','ready']));
    }
    public static function consumers(): array {
        self::principal();$out=[];foreach(self::$consumers as $id=>$r){try{$cfg=self::configuration($id);$state='ready';}catch(Fault $e){$cfg=null;$state=$e->reason;}$out[]=['consumer_id'=>$id,'label'=>$r['label'],'version'=>$r['version'],'configuration'=>$cfg,'state'=>$state];}
        $grants=[];for($at=0;;$at+=100){$batch=Store::list('ads_grant',$at,100);foreach($batch as $r){$v=$r['value'];$grants[]=array_intersect_key($v,array_flip(['consumer_id','connection_id','account_id','enabled']))+['allow_ad_origin'=>!empty($v['allow_ad_origin']),'revision'=>$r['revision']];}if(count($batch)<100)break;}
        return ['contract'=>self::CONTRACT,'consumers'=>$out,'grants'=>$grants];
    }
    public static function grant(array $i): array {Schemas::validate('get-ads-grant',$i);self::principal();$r=Store::get('ads_grant',self::key($i));return $i+['revision'=>$r['revision']??0,'enabled'=>$r['value']['enabled']??false,'allow_ad_origin'=>!empty($r['value']['allow_ad_origin']),'authorization_revision'=>$r['value']['authorization_revision']??null,'consumer_revision'=>$r['value']['configuration']['revision']??null];}
    public static function save(array $i): array {
        Schemas::validate('save-ads-grant',$i);$p=self::principal();$key=self::key($i);
        return Store::lock('ads-grant:'.$key,static function()use($i,$p,$key){
            $old=Store::get('ads_grant',$key);if(($old['revision']??0)!==$i['expected_revision'])throw new Fault('revision_conflict','Concessão de anúncios alterada.');
            $v=['consumer_id'=>$i['consumer_id'],'connection_id'=>$i['connection_id'],'account_id'=>$i['account_id'],'enabled'=>$i['enabled'],'allow_ad_origin'=>false,'principal'=>$p,'authorization_revision'=>null,'configuration'=>null];
            if($i['enabled']){$c=Connections::get($i['connection_id']);Access::worker($p,$c,'ads',$i['account_id'],false);$cfg=self::configuration($i['consumer_id']);if($cfg['connection_id']!==$c['id']||$cfg['account_id']!==$i['account_id'])throw new Fault('consumer_scope_mismatch','O consumidor selecionou outra conexão ou conta.');$v['configuration']=$cfg;$v['authorization_revision']=$c['authorization_revision'];
                $previous=$old['value']??[];$same=!empty($previous['enabled'])&&($previous['configuration']??null)===$cfg&&($previous['authorization_revision']??null)===$c['authorization_revision']&&($previous['principal']??null)===$p;
                $v['allow_ad_origin']=$i['allow_ad_origin']??($same&&!empty($previous['allow_ad_origin']));}
            Access::checkPrincipal($p);$r=Store::put('ads_grant',$key,$v,$i['expected_revision'],0);
            return ['revision'=>$r['revision'],'enabled'=>$v['enabled'],'allow_ad_origin'=>$v['allow_ad_origin'],'consumer_id'=>$i['consumer_id'],'connection_id'=>$i['connection_id'],'account_id'=>$i['account_id']];
        });
    }
    private static function authorized(string $id,array $i): array {
        $cfg=self::configuration($id);if($i['connection_id']!==$cfg['connection_id']||$i['account_id']!==$cfg['account_id'])throw new Fault('consumer_scope_mismatch','Seleção fora da configuração do consumidor.');
        $r=Store::get('ads_grant',self::key($i+['consumer_id'=>$id]));if(!$r||empty($r['value']['enabled']))throw new Fault('grant_revoked','Leitura do acervo não autorizada.');$v=$r['value'];
        if(!Util::same($cfg,$v['configuration']))throw new Fault('revision_conflict','Configuração do consumidor mudou; reautorize a concessão.');
        $c=Connections::get($i['connection_id']);if($c['authorization_revision']!==$v['authorization_revision'])throw new Fault('revision_conflict','Autorização da conexão mudou; reautorize o consumidor.');
        Access::worker($v['principal'],$c,'ads',$i['account_id'],false);return [$r,$cfg,$c];
    }
    public static function call(AdsReaderClient $client,string $op,array $i): array {
        $id=null;foreach(self::$consumers as $key=>$r)if($r['client']===$client){$id=$key;break;}
        $result=Result::run(static function()use($id,$op,$i){
            if($id===null)throw new Fault('not_authorized','Cliente não registrado.');
            $keys=match($op){'status'=>[], 'ad_origin'=>['ad_id'], 'query'=>['ads_level','date_from','date_to','limit','cursor'], default=>throw new Fault('invalid_input','Método de leitura desconhecido.')};
            Util::guardKeys($i,array_merge(['connection_id','account_id'],$keys));
            if(!is_string($i['connection_id']??null)||!is_string($i['account_id']??null))throw new Fault('invalid_input','Informe conexão e conta.');Util::id($i['connection_id']);Util::numeric($i['account_id']);
            if($op==='ad_origin'){
                $ad=Util::numeric($i['ad_id']??null);[$grant,$cfg,$c]=self::authorized($id,$i);
                if(empty($grant['value']['allow_ad_origin']))throw new Fault('ad_origin_not_granted','Consultas de anúncios de origem não autorizadas para esta conta.');
                Ads::scope($c);
                $check=static function()use($id,$i,$grant,$cfg,$c){[$current,$selection,$conn]=self::authorized($id,$i);
                    Connections::usable($conn);if($current['revision']!==$grant['revision']||empty($current['value']['allow_ad_origin'])||$selection!==$cfg||$conn['revision']!==$c['revision'])throw new Fault('revision_conflict','A concessão ou a seleção mudou.');};
                $data=Http::adOriginBudget(static fn()=>AdOrigin::read($c,$i['account_id'],$ad,$check));$check();return $data+['grant_revision'=>$grant['revision']];
            }
            $key=self::key($i+['consumer_id'=>$id]);
            return Store::lock('ads-grant:'.$key,static function()use($id,$op,$i){
                [$grant,$cfg,$c]=self::authorized($id,$i);
                if($op==='status')return self::contract()+['ready'=>true,'allow_ad_origin'=>!empty($grant['value']['allow_ad_origin']),'grant_revision'=>$grant['revision'],'connection_revision'=>$c['authorization_revision'],'consumer_revision'=>$cfg['revision'],'account_id'=>$i['account_id']];
                $q=$i;unset($q['cursor']);$q+=['channel'=>'ads','report'=>'ads_insights','ads_level'=>'campaign'];$binding=hash('sha256',Util::json([$id,$grant['revision'],$cfg,$c['authorization_revision'],$q]));
                if(!empty($i['cursor'])){if(!is_string($i['cursor'])||strlen($i['cursor'])>50000)throw new Fault('invalid_cursor','Cursor inválido.');$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação de outra concessão ou seleção.');$q['cursor']=$cur['history_cursor'];}
                $data=History::readAuthorized($q,$grant['value']['principal']);
                [$after,$again,$current]=self::authorized($id,$i);if($after['revision']!==$grant['revision']||!Util::same($cfg,$again)||$current['revision']!==$c['revision'])throw new Fault('revision_conflict','Autorização alterada durante a leitura.');
                if($data['next_cursor'])$data['next_cursor']=Util::cursor(['binding'=>$binding,'history_cursor'=>$data['next_cursor'],'expires'=>time()+86400]);
                $data['contract']=self::CONTRACT;$data['grant_revision']=$grant['revision'];$data['attribution']=Ads::ATTRIBUTION;return $data;
            });
        });
        Audit::record('ads-reader-'.$op,$i,$result,$id,'local_sdk');return $result;
    }
}
final class AdsReaderClient {
    public function ad_origin(array $i): array {return AdsReader::call($this,'ad_origin',$i);}
    public function status(array $i): array {return AdsReader::call($this,'status',$i);}
    public function query(array $i): array {return AdsReader::call($this,'query',$i);}
}
