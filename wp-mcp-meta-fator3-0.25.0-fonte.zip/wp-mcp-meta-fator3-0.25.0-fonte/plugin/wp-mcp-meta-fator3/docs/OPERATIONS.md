# Operação

Este documento cobre o funcionamento contínuo do plugin: cron e worker, orçamento de execução, retenção, auditoria, instalação, atualização, desativação, desinstalação e recuperação. Os detalhes de cada assunto ficam nos guias indicados.

## Cron e worker

O plugin usa três eventos do WP-Cron:

| Evento | Função |
|---|---|
| `f3_meta_worker` | Materializa agendas vencidas e avança coletas `queued` ou `retry` |
| `f3_meta_maintenance` | Manutenção horária: confere o worker, migra a fila e o histórico, aplica a retenção e avalia avisos |
| `f3_meta_messages` | Continua o processamento de mensagens do Instagram, quando habilitado |

O WP-Cron só roda quando há tráfego, a menos que o servidor chame o cron. Para coletas regulares, configure o agendador do servidor. Se a manutenção sumir do cron, a requisição seguinte do site a recria. Se o worker sumir, `meta/health` mostra `worker_missing` e `meta/status` o rearma.

Também é possível executar pelo WP-CLI:

- `wp f3-meta run` — executa uma passagem do worker e imprime o último estado.
- `wp f3-meta selftest` — executa o autoteste local; termina com erro se algum item falhar.

WORKER.md descreve a fila, a recuperação, a manutenção, os códigos de `issues` e os avisos por e-mail.

## Orçamento de execução

Cada operação e cada passagem do worker têm um limite local de chamadas HTTP e de tempo. Esgotado o limite, a resposta é `budget_exhausted` e a próxima execução continua. Não existe quota diária local. EXECUTION-BUDGET.md traz os números e os campos de diagnóstico.

## Retenção

Resultados, histórico, auditoria, exportações, arquivo de Stories e diário de mensagens não expiram por padrão. Cursores, confirmações e outros comprovantes temporários mantêm seus prazos curtos. A manutenção horária só remove registros cujo prazo foi definido e venceu. RETENTION.md descreve a política completa.

## Auditoria

Toda operação despachada grava uma linha de auditoria cifrada, inclusive as leituras feitas pelo painel; só a leitura da documentação não grava. A linha guarda operação, ator, transporte, conexão, código do resultado e instante, sem token, segredo ou dados coletados. As linhas não expiram: o volume cresce com o uso, por decisão de projeto.

Consulte com `meta/audit` (mais recentes primeiro, 50 por página, `since` opcional em Unix). Se a gravação falhar, a operação devolve `audit_warning` e `meta/health` mostra `audit_health=failed`.

## Instalação

Requisitos: WordPress ≥ 7.1.4, PHP ≥ 8.3 de 64 bits, InnoDB com travas nomeadas e criptografia autenticada. A ativação recusa ambientes sem esses requisitos e a ativação em rede. Ao ativar, o plugin cria suas tabelas, agenda a manutenção para uma hora depois e prepara o worker. Ativar não cria conexão nem consulta a Meta. MIGRATION.md traz a sequência e a conferência.

## Atualização

A atualização é direta a partir da versão-base 0.24.1, substituindo os arquivos no mesmo diretório, sem desinstalar. Dados, conexões, credenciais, agendas, pausas, concessões e progresso são preservados. MIGRATION.md descreve o que muda na primeira leitura.

## Desativação e desinstalação

- **Desativar** remove os três eventos de cron do plugin. Nenhum dado é apagado. Ao reativar, a manutenção volta a ser agendada, e o worker também, se houver agenda ativa ou coleta pendente.
- **Desinstalar** remove os eventos de cron e **preserva** as tabelas e opções com os dados cifrados. A remoção definitiva dos dados é um procedimento administrativo deliberado, com backup prévio; o plugin não oferece botão para isso.
- O plugin nunca apaga dados de outros plugins.

## Backup

O backup precisa incluir o banco **e** as chaves e salts do `wp-config.php`. Sem os mesmos salts, os dados cifrados ficam ilegíveis (`cipher_unreadable`). Para mensagens, preserve também a opção de chave de privacidade e os bloqueios (MESSAGE-PRIVACY.md).

## Recuperação

- **Coletas** gravam a página antes de avançar o checkpoint; uma coleta interrompida retoma da página seguinte à última gravada.
- **Exportações** com falha de gravação de uma parte são retomadas repetindo `meta/history-export-step` com o mesmo `export_id`.
- **Registros ilegíveis** são isolados, não executados e não apagados (WORKER.md). Restaure os salts corretos; não regrave por cima.
- **Resultado incerto** de uma gravação exige reler o estado antes de repetir (AGENTS.md).

## Correção por nova versão

Não existe procedimento de downgrade. Uma versão instalada não volta à anterior. Se houver falha, registre o estado alcançado, pause o fluxo afetado (agenda ou conexão) e instale a versão corretiva, que continua a partir desse estado. Preserve banco, salts, revisões e recibos para reconciliar efeitos antes de retomar.
