# Referência das operações

Documento gerado pelo build a partir do registro do código da versão 0.25.0: 47 operações. Rótulos, descrições, efeitos e schemas saem do próprio plugin; não edite à mão.

Cada operação é a habilidade `meta/<operação>` da Abilities API (também exposta pelo Fator3 MCP) e a rota REST `POST f3-meta/v1/<operação>`. Parâmetros aninhados aparecem em notação de ponto.

## Operações de leitura

### `meta/admin-options`

- Rótulo: Meta: listar opções dos formulários
- Descrição: Lista usuários, ativos e objetos pelos nomes para os formulários administrativos, sem selecioná-los automaticamente.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `kind` | texto | um de: `users`, `assets`, `selected`, `objects`, `forms`, `journal` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |
| `cursor` | texto | até 50000 caracteres |
| `offset` | inteiro | de 0 a 100000 |
| `search` | texto | até 100 caracteres |
| `ids` | lista de inteiro | até 100 itens; itens sem repetição; cada item: mínimo 1 |

### `meta/ads-consumers`

- Rótulo: Meta: listar consumidores de anúncios
- Descrição: Lista consumidores registrados, contas selecionadas e permissões para histórico local e consulta do anúncio de origem.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/audit`

- Rótulo: Meta: consultar registros de auditoria
- Descrição: Lista os registros locais de operações, autores, resultados e datas, com paginação.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `offset` | inteiro | de 0 a 100000 |
| `since` | inteiro | mínimo 0 |

### `meta/capabilities`

- Rótulo: Meta: consultar recursos disponíveis
- Descrição: Lista os recursos, contratos, canais e limites disponíveis no plugin.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/configuration-schema`

- Rótulo: Meta: consultar campos de configuração
- Descrição: Descreve os campos, regras de revisão e tratamento de credenciais da conexão.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/contracts`

- Rótulo: Meta: consultar contratos das operações
- Descrição: Retorna os esquemas de entrada, o formato de resposta e as capacidades das operações.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/conversations`

- Rótulo: Meta: ler conversas do Instagram
- Descrição: Lê metadados das conversas e primeira mensagem disponível, sem texto, com origem comprovada quando disponível e contagem diária paginada.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `date_from` | texto | até 10 caracteres |
| `date_to` | texto | até 10 caracteres |
| `page_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `limit` | inteiro | de 1 a 10 |
| `cursor` | texto | até 50000 caracteres |

### `meta/documentation`

- Rótulo: Meta: ler documentação instalada
- Descrição: Lê o índice ou um documento local por páginas, com versão e integridade, sem consultar o fornecedor.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `document` | texto | até 100 caracteres |
| `offset` | inteiro | de 0 a 16777216 |
| `limit_bytes` | inteiro | de 256 a 65536 |
| `expected_revision` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |

### `meta/export-read`

- Rótulo: Meta: ler arquivo exportado da coleta
- Descrição: Lê o arquivo exportado em partes autenticadas, com integridade e continuação; não cria endereço público.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `export_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `offset_bytes` | inteiro | de 0 a 12582912 |
| `byte_limit` | inteiro | de 1 a 196608 |

### `meta/get-ads-grant`

- Rótulo: Meta: consultar concessão de anúncios
- Descrição: Lê a revisão da concessão e as permissões do histórico e da consulta por ID, por consumidor, conexão e conta.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `consumer_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |

Parâmetros opcionais:

Nenhum.

### `meta/get-connection`

- Rótulo: Meta: consultar conexão
- Descrição: Mostra a configuração e a revisão de uma conexão, sem revelar credenciais.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |

Parâmetros opcionais:

Nenhum.

### `meta/get-monitoring-grant`

- Rótulo: Meta: monitoramento — consultar concessão
- Descrição: Consulta a revisão e a seleção da concessão de leitura local de monitoramento.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `consumer_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |

Parâmetros opcionais:

Nenhum.

### `meta/health`

- Rótulo: Meta: consultar saúde das coletas (somente leitura)
- Descrição: Mostra o mesmo diagnóstico do estado (agendas atrasadas ou sem autorização, worker, fila e manutenção) sem rearmar nada, sem e-mail e sem chamar a Meta; disponível ao perfil de leitura.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/history-export-read`

- Rótulo: Meta: ler parte da exportação do histórico
- Descrição: Lê uma parte da exportação concluída, com verificação de integridade e continuação por bytes.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `export_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `part` | inteiro | de 0 a 10000 |
| `offset_bytes` | inteiro | de 0 a 1000000 |
| `byte_limit` | inteiro | de 1 a 196608 |

### `meta/history-query`

- Rótulo: Meta: consultar histórico armazenado
- Descrição: Consulta o histórico local por ativo, relatório e período, com paginação e autorização atual.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `ads_level` | texto | um de: `account`, `campaign`, `adset`, `ad` |
| `report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |
| `date_from` | texto | até 10 caracteres |
| `date_to` | texto | até 10 caracteres |
| `limit` | inteiro | de 1 a 100 |
| `cursor` | texto | até 50000 caracteres |

### `meta/history-status`

- Rótulo: Meta: consultar estado do histórico
- Descrição: Informa estrutura, quantidade de registros e andamento da migração do histórico local.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/job-results`

- Rótulo: Meta: ler resultados da coleta
- Descrição: Lê uma página de resultados já armazenados de uma coleta autorizada.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `job_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `page` | inteiro | de 0 a 9999 |

### `meta/job-status`

- Rótulo: Meta: consultar andamento da coleta
- Descrição: Informa estado, progresso, próxima execução e falhas registradas de uma coleta.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `job_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |

Parâmetros opcionais:

Nenhum.

### `meta/list-accounts`

- Rótulo: Meta: listar contas e páginas disponíveis
- Descrição: Consulta contas e Páginas acessíveis à conexão, com continuação; a descoberta não concede acesso aos ativos.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `cursor` | texto | até 50000 caracteres |

### `meta/list-connections`

- Rótulo: Meta: listar conexões
- Descrição: Lista as conexões cadastradas com paginação, sem revelar credenciais.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `offset` | inteiro | de 0 a 100000 |

### `meta/list-fields`

- Rótulo: Meta: listar campos e métricas
- Descrição: Descreve campos, métricas, períodos e disponibilidade para o relatório e a versão da interface selecionados.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `api_version` | texto | até 10 caracteres |
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |

### `meta/list-jobs`

- Rótulo: Meta: listar coletas de dados
- Descrição: Lista as coletas acessíveis ao usuário, com estado, progresso e paginação.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `offset` | inteiro | de 0 a 100000 |

### `meta/list-schedules`

- Rótulo: Meta: listar agendas de coleta
- Descrição: Lista as agendas acessíveis ao usuário, incluindo habilitação, próxima execução e último resultado.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/messaging-status`

- Rótulo: Meta: conferir permissões de mensagens
- Descrição: Consulta configuração, escopos já observados e declaração de App Review; não consulta a Meta nem comprova aprovação avançada.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

Nenhum.

### `meta/monitoring-consumers`

- Rótulo: Meta: monitoramento — listar consumidores
- Descrição: Lista consumidores locais de atividades e qualidade de datasets e suas concessões explícitas.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/query`

- Rótulo: Meta: consultar relatório
- Descrição: Consulta uma página do relatório. Preserve a seleção e a continuação; ausência de métricas não comprova acesso integral.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `fields` | lista de texto | até 30 itens; itens sem repetição; cada item: até 80 caracteres |
| `date_from` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `date_to` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `limit` | inteiro | de 1 a 100 |
| `cursor` | texto | até 50000 caracteres |
| `ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `ads_level` | texto | um de: `account`, `campaign`, `adset`, `ad` |
| `media_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `entity_id` | texto | até 81 caracteres; padrão `^[0-9]+(_[0-9]+)?$` |
| `granularity` | texto | um de: `day`, `interval` |
| `iterate_media` | booleano | — |
| `timeframe` | texto | um de: `this_month`, `this_week`, `last_14_days`, `last_30_days`, `last_90_days`, `prev_month`, `prev_week` |
| `breakdown` | texto | um de: `country`, `city`, `age`, `gender`, `media_product_type` |

### `meta/selftest`

- Rótulo: Meta: executar diagnóstico local
- Descrição: Verifica armazenamento, criptografia, permissões e contratos locais, sem validar credenciais no fornecedor.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/story-archive`

- Rótulo: Meta: consultar arquivo de Stories
- Descrição: Lê metadados privados dos Stories capturados pelas coletas, preservados sem expiração automática nem descarte por quantidade.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `date_from` | texto | até 10 caracteres |
| `date_to` | texto | até 10 caracteres |
| `limit` | inteiro | de 1 a 25 |
| `cursor` | texto | até 50000 caracteres |

### `meta/story-archive-thumbnail`

- Rótulo: Meta: ler miniatura de Story arquivado
- Descrição: Lê uma miniatura privada em JPEG reduzido, mediante autorização atual da conexão; não fornece URL pública.
- Modo: leitura (`read`)
- Efeito local: nenhum (`none`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `true`, destructive `false`, idempotent `true`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `story_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

Nenhum.

## Operações de escrita

### `meta/control-job`

- Rótulo: Meta: pausar, retomar ou cancelar coleta
- Descrição: Altera o estado de uma coleta autorizada, preservando os resultados já armazenados.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `job_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |
| `expected_revision` | inteiro | mínimo 0 |
| `action` | texto | um de: `pause`, `resume`, `cancel` |

Parâmetros opcionais:

Nenhum.

### `meta/create-backfill`

- Rótulo: Meta: criar carga retroativa
- Descrição: Cria uma coleta para o período passado solicitado; a cobertura disponível depende dos limites do fornecedor.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `query` | objeto | — |
| `query.connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `query.channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `query.account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |
| `idempotency_key` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `query.fields` | lista de texto | até 30 itens; itens sem repetição; cada item: até 80 caracteres |
| `query.date_from` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `query.date_to` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `query.limit` | inteiro | de 1 a 100 |
| `query.cursor` | texto | até 50000 caracteres |
| `query.ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.ads_level` | texto | um de: `account`, `campaign`, `adset`, `ad` |
| `query.media_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.entity_id` | texto | até 81 caracteres; padrão `^[0-9]+(_[0-9]+)?$` |
| `query.granularity` | texto | um de: `day`, `interval` |
| `query.iterate_media` | booleano | — |
| `query.timeframe` | texto | um de: `this_month`, `this_week`, `last_14_days`, `last_30_days`, `last_90_days`, `prev_month`, `prev_week` |
| `query.breakdown` | texto | um de: `country`, `city`, `age`, `gender`, `media_product_type` |
| `max_pages` | inteiro | de 1 a 10000 |

### `meta/create-job`

- Rótulo: Meta: criar coleta de dados
- Descrição: Cria uma coleta persistente vinculada à identidade e à chave de repetição; execução e resultados são consultados separadamente.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `query` | objeto | — |
| `query.connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `query.channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `query.account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |
| `idempotency_key` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `query.fields` | lista de texto | até 30 itens; itens sem repetição; cada item: até 80 caracteres |
| `query.date_from` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `query.date_to` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `query.limit` | inteiro | de 1 a 100 |
| `query.cursor` | texto | até 50000 caracteres |
| `query.ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.ads_level` | texto | um de: `account`, `campaign`, `adset`, `ad` |
| `query.media_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.entity_id` | texto | até 81 caracteres; padrão `^[0-9]+(_[0-9]+)?$` |
| `query.granularity` | texto | um de: `day`, `interval` |
| `query.iterate_media` | booleano | — |
| `query.timeframe` | texto | um de: `this_month`, `this_week`, `last_14_days`, `last_30_days`, `last_90_days`, `prev_month`, `prev_week` |
| `query.breakdown` | texto | um de: `country`, `city`, `age`, `gender`, `media_product_type` |
| `max_pages` | inteiro | de 1 a 10000 |

### `meta/export`

- Rótulo: Meta: exportar resultados da coleta
- Descrição: Prepara resultados da coleta em CSV ou JSON; resultados parciais exigem autorização explícita.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `job_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |
| `format` | texto | um de: `csv`, `json` |
| `idempotency_key` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `allow_partial` | booleano | — |

### `meta/history-export`

- Rótulo: Meta: preparar exportação do histórico
- Descrição: Cria uma exportação do histórico em CSV ou JSON; etapas posteriores processam e disponibilizam as partes.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `query` | objeto | — |
| `query.connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `query.channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `query.account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `format` | texto | um de: `csv`, `json` |
| `idempotency_key` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `query.ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.ads_level` | texto | um de: `account`, `campaign`, `adset`, `ad` |
| `query.report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |
| `query.date_from` | texto | até 10 caracteres |
| `query.date_to` | texto | até 10 caracteres |
| `query.limit` | inteiro | de 1 a 100 |
| `query.cursor` | texto | até 50000 caracteres |

### `meta/history-export-step`

- Rótulo: Meta: processar etapa da exportação do histórico
- Descrição: Avança uma etapa da exportação persistida e informa progresso, conclusão ou falha.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `export_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |

Parâmetros opcionais:

Nenhum.

### `meta/history-migrate`

- Rótulo: Meta: migrar resultados para o histórico
- Descrição: Avança a migração dos resultados locais já armazenados para o histórico cifrado, com retomada.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/process-messages`

- Rótulo: Meta: encaminhar primeiras mensagens ao Core
- Descrição: Confere primeiras mensagens disponíveis e entrega candidatos mínimos ao consumidor local do Site Core explicitamente autorizado; pode criar contatos.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: grava no fornecedor (`write`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `cursor` | texto | até 50000 caracteres |

### `meta/rotate-token`

- Rótulo: Meta: renovar credencial preservando as agendas
- Descrição: Valida a nova credencial e preserva a autorização das agendas quando aplicativo, identidade, permissões e ativos coincidem.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `expected_revision` | inteiro | mínimo 0 |
| `token` | texto | até 16384 caracteres |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `expires_at` | inteiro | mínimo 0 |

### `meta/run-job`

- Rótulo: Meta: executar etapa da coleta
- Descrição: Executa uma página da coleta persistida, grava os resultados e atualiza o progresso para retomada.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `job_id` | texto | até 64 caracteres; padrão `^[a-f0-9]{64}$` |

Parâmetros opcionais:

Nenhum.

### `meta/save-ads-grant`

- Rótulo: Meta: configurar permissões de leitura de anúncios
- Descrição: Grava a concessão do histórico e a permissão separada para consultar o anúncio de origem na Meta. Salvar só altera a configuração local; a consulta por ID ocorre quando o consumidor a solicita.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `true`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `consumer_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `expected_revision` | inteiro | mínimo 0 |
| `enabled` | booleano | — |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `allow_ad_origin` | booleano | — |

### `meta/save-connection`

- Rótulo: Meta: salvar conexão
- Descrição: Salva a conexão cifrada com revisão esperada. Credencial vazia mantém a atual; ativos vazios não concedem acesso.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `false`, destructive `true`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `expected_revision` | inteiro | mínimo 0 |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `label` | texto | até 120 caracteres |
| `token` | texto | até 16384 caracteres |
| `client_secret` | texto | até 16384 caracteres |
| `clear_token` | booleano | — |
| `clear_client_secret` | booleano | — |
| `client_id` | texto | até 16384 caracteres |
| `application_id` | texto | até 160 caracteres |
| `enabled` | booleano | — |
| `expires_at` | inteiro | mínimo 0 |
| `users` | lista de inteiro | até 100 itens; itens sem repetição; cada item: mínimo 1 |
| `assets` | objeto | — |
| `assets.instagram` | lista de texto | até 100 itens; itens sem repetição; cada item: até 40 caracteres; padrão `^[0-9]+$` |
| `assets.facebook` | lista de texto | até 100 itens; itens sem repetição; cada item: até 40 caracteres; padrão `^[0-9]+$` |
| `assets.ads` | lista de texto | até 100 itens; itens sem repetição; cada item: até 40 caracteres; padrão `^[0-9]+$` |
| `assets.dataset` | lista de texto | até 100 itens; itens sem repetição; cada item: até 40 caracteres; padrão `^[0-9]+$` |
| `forms` | objeto | até 100 chaves; chaves livres; cada valor: lista de texto (até 100 itens; itens sem repetição; cada item: até 40 caracteres; padrão `^[0-9]+$`) |
| `api_version` | texto | até 10 caracteres |
| `retention_days` | inteiro | de 1 a 3650 |
| `retention_mode` | texto | um de: `finite`, `unlimited` |

### `meta/save-messaging-settings`

- Rótulo: Meta: configurar recepção de mensagens
- Descrição: Salva Página selecionada, verificação do webhook e autorização opcional de contatos; inspeciona vínculo Página/Instagram ao habilitar.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `expected_revision` | inteiro | mínimo 0 |
| `enabled` | booleano | — |
| `contacts_enabled` | booleano | — |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `page_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `app_review` | texto | um de: `unknown`, `standard`, `advanced` |
| `verify_token` | texto | até 128 caracteres |

### `meta/save-monitoring-grant`

- Rótulo: Meta: monitoramento — salvar concessão
- Descrição: Autoriza ou revoga os relatórios e datasets explicitamente selecionados pelo consumidor.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `true`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `consumer_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `expected_revision` | inteiro | mínimo 0 |
| `enabled` | booleano | — |
| `reports` | lista de texto | até 2 itens; itens sem repetição; cada item: um de: `ads_activity`, `dataset_quality` |
| `dataset_ids` | lista de texto | até 12 itens; itens sem repetição; cada item: até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

Nenhum.

### `meta/save-schedule`

- Rótulo: Meta: salvar agenda de coleta
- Descrição: Cria ou atualiza uma agenda com revisão esperada, consulta, intervalo, nome e próxima execução.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `schedule_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `expected_revision` | inteiro | mínimo 0 |
| `query` | objeto | — |
| `query.connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `query.channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `query.account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.report` | texto | um de: `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings`, `stories_insights`, `ads_insights`, `ads_activity`, `dataset_quality` |
| `enabled` | booleano | — |
| `interval_minutes` | inteiro | de 60 a 43200 |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `label` | texto | até 120 caracteres |
| `next_at` | inteiro | mínimo 0 |
| `query.fields` | lista de texto | até 30 itens; itens sem repetição; cada item: até 80 caracteres |
| `query.date_from` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `query.date_to` | texto | até 10 caracteres; padrão `^[0-9]{4}-[0-9]{2}-[0-9]{2}$` |
| `query.limit` | inteiro | de 1 a 100 |
| `query.cursor` | texto | até 50000 caracteres |
| `query.ads_account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.ads_level` | texto | um de: `account`, `campaign`, `adset`, `ad` |
| `query.media_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |
| `query.entity_id` | texto | até 81 caracteres; padrão `^[0-9]+(_[0-9]+)?$` |
| `query.granularity` | texto | um de: `day`, `interval` |
| `query.iterate_media` | booleano | — |
| `query.timeframe` | texto | um de: `this_month`, `this_week`, `last_14_days`, `last_30_days`, `last_90_days`, `prev_month`, `prev_week` |
| `query.breakdown` | texto | um de: `country`, `city`, `age`, `gender`, `media_product_type` |
| `lookback_days` | inteiro | de 1 a 30 |

### `meta/status`

- Rótulo: Meta: verificar estado e recuperar agendamento
- Descrição: Mostra saúde, atrasos e agendas sem autorização; rearma o worker local ausente, sem consultar o fornecedor. Exige permissão de escrita local.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: nenhum (`none`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

Nenhum.

Parâmetros opcionais:

Nenhum.

### `meta/switch-identity`

- Rótulo: Meta: trocar identidade e regravar agendas
- Descrição: Confere identidade e ativos, simula a troca e exige confirmação vinculada à revisão para gravar conexão e agendas.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `false`, destructive `true`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `expected_revision` | inteiro | mínimo 0 |
| `token` | texto | até 16384 caracteres |
| `dry_run` | booleano | — |

Parâmetros opcionais:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `expires_at` | inteiro | mínimo 0 |
| `label` | texto | até 120 caracteres |
| `client_id` | texto | até 16384 caracteres |
| `client_secret` | texto | até 16384 caracteres |
| `confirmation` | texto | até 50000 caracteres |

### `meta/validate-connection`

- Rótulo: Meta: validar conexão no fornecedor
- Descrição: Consulta a identidade e as permissões no fornecedor e grava o diagnóstico da conexão ou da Página selecionada.
- Modo: escrita (`write`)
- Efeito local: grava estado local (`write`)
- Efeito remoto: consulta o fornecedor (`read`)
- Anotações: readonly `false`, destructive `false`, idempotent `false`

Parâmetros obrigatórios:

| Parâmetro | Tipo | Limites |
|---|---|---|
| `connection_id` | texto | até 64 caracteres; padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` |
| `channel` | texto | um de: `instagram`, `facebook`, `ads`, `dataset` |
| `account_id` | texto | até 40 caracteres; padrão `^[0-9]+$` |

Parâmetros opcionais:

Nenhum.
