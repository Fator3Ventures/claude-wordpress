# Fonte do Fator3 Site Core 1.95.0

Base oficial 1.94.0. O runtime está em `work/plugin/base-site-core-fator3/`. A cópia do relatório em `RELATORIO-PRE-FECHAMENTO.md` antecede o cálculo do hash deste ZIP. Os testes desta rodada estão em `tests/195/`, as evidências em `evidence/1950/` e os pedidos, propostas e respostas individuais em `reference/1950/`. Diretórios com outras versões documentam ensaios anteriores.

## Reproduzir os pacotes

Na raiz do fonte, com Python 3, zlib 1.3.2 e PHP CLI de 64 bits a partir de 8.3, execute os comandos abaixo. O verificador usa a ordem dos arquivos, o inventário e o SHA-256 de cada entrada.

```sh
F3BASE_PHP=php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.95.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.95.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.95.0-fonte.zip
```

## Reproduzir o aceite no WordPress

Use quatro instalações descartáveis de WordPress 7.1.4 em loopback, PHP 8.3 de 64 bits, MariaDB e WP-CLI. Configure ambiente local, cron automático desligado, interceptação de correio e bloqueio de HTTP externo. Preserve respostas simuladas já produzidas por filtros de menor prioridade. Use os pacotes de `evidence/1950/conjunto.json`. Os bancos a seguir são exclusivos da bancada. Os comandos `wp` usam a raiz da instalação correspondente e o usuário 1.

1. **Instalação limpa.** Em `core_195_clean`, instale o Core final com `wp plugin install CAMINHO --activate`. Execute `wp eval-file tests/195/instalacao.php` em outro processo. Execute `wp eval-file tests/195/fila-iam.php` com PHP 8.3 e 8.4. A fixture gera nomes sintéticos distintos, simula a fila e confere as permissões de leitura.
2. **Atualização.** Em `core_195_migracao`, instale Core 1.94.0 e os cinco acompanhantes oficiais. Use site em `http://127.0.0.1:33795`. Execute `F3_PHASE38=capture wp eval-file tests/195/google-chave.php` e `wp eval-file tests/195/migracao.php`. Instale o Core 1.95.0 com `wp plugin install CAMINHO --force --activate`. Execute de novo `migracao.php` e depois `instalacao.php`. Confira identidade, data e recibo originais, contexto IAM e zero novos envios.
3. **Produtor Google.** Em `core_195_google`, use os seis pacotes finais com site em loopback. Execute `F3_PHASE38=patch F3_RESULT38=/tmp/google-195.json wp eval-file tests/195/google-chave.php`. O nome da fase vem do teste original do Google 0.38.0. O ensaio usa a instalação oficial 1.95.0 e simula as respostas IAM, OAuth e GA4 e o transporte do e-mail.
4. **Leitura pelo MCP.** Na instalação de migração, conserve o episódio já enriquecido. Permita HTTP somente para o loopback e senhas de aplicação locais. Inicie o servidor PHP com a raiz do WordPress como diretório corrente e `tests/195/router.php` como roteador. Execute `F3_RESULT38=/tmp/aceite-195.json wp eval-file tests/195/aceite-mcp.php` de outro processo. O teste lê o incidente pelo MCP, verifica duas permissões do assinante e revoga a identidade de ensaio.
5. **Canal.** Em `core_195_canal`, com os seis pacotes, copie `registration.php` para junto de wp-load.php e `observer-fixture.php` para mu-plugins. Crie os marcadores `f3-disposable-lab.marker`, `f3-test-core-observer`, `f3-test-early` e `f3-test-disable-server` nessa raiz. Rode `F3_ANTES=1 wp eval-file tests/195/historico.php`. Inicie um servidor PHP HTTP na raiz do WordPress. Rode `python3 tests/195/registration.py --site /CAMINHO/wordpress --port 33795 --out /tmp/registro-195.json`. Recrie o marcador disable-server e execute `wp eval-file tests/195/historico.php`. São seis requisições independentes. O histórico final do Core tem uma abertura e uma recuperação.
6. **Demais integrações.** Aponte `F3BASE_SITE` para o wp-load.php de migração e execute um servidor PHP local com `tests/195/contratos.php` como roteador. Faça GET em /wp-admin/tools.php. Repita com PHP 8.4 e confira cinco mensagens, uma linha do Pipedrive e a recusa ao visitante. Rode `wp eval-file tests/193/produtores.php` para Meta e cron. Ao terminar, encerre os servidores e descarte os quatro bancos e suas instalações sintéticas.

No Site-Teste, a leitura de `f3base/como-usar` confirmou a atualização em processo posterior. A documentação de operação está no instalador, em `docs/RELEASE-1.95.0.md` e `docs/AGENTES-1.95.0.md`.
