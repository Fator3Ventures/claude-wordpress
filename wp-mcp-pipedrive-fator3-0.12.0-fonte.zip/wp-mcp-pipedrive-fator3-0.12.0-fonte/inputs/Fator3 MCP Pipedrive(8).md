# Pedidos — Fator3 MCP Pipedrive

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-pipedrive-fator3**. Cite como "Pedidos MCP Pipedrive N". Próximo número: 14; número retirado fica vago.

## wp-mcp-pipedrive-fator3 — pendentes

Nenhum pedido em aberto. 13 entregue na 0.11.1 e retirado em 15/11.
