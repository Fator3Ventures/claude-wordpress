# Fator3 MCP Pipedrive — fonte 0.12.0

Base: 0.11.1. Rodada 18/11/2026. Normas comuns revisão 5, 02/11/2026. Leia RELATORIO-PRE-FECHAMENTO.md para o escopo, evidências e pendências desta entrega. Essa cópia precede o fechamento do ZIP e não contém o hash de si própria.

- plugin/wp-mcp-pipedrive-fator3/: árvore exata do instalador e 12 documentos de uso.
- build/: empacotamento determinístico, verificação e preparação das bancadas.
- tests/: regressões e instruções reproduzíveis; nunca instalar no site compartilhado.
- evidence/0120/: resultados sanitizados e capturas de navegadores. clean, upgrade e matrix são PHP 8.4.27; php83 contém os mesmos cenários em PHP 8.3.6.
- inputs/: normas, pedido vigente e impacto recebido; cópias de referência, sem alterar os documentos centrais.
- PLAN.md: decisões e encerramento.

Execute python3 build/package.py installer --out /diretorio/externo para produzir o ZIP instalado nas bancadas. Execute python3 build/verify.py --installer /diretorio/externo/wp-mcp-pipedrive-fator3-0.12.0-instalador.zip --php /caminho/php para conferir árvore, sintaxe, schemas, documentação e reprodução byte a byte. O teste de verificação final de implantação em site compartilhado continua pendente; não execute phase final como substituto da instalação.

O Core publica, deduplica e entrega incidentes. Este plugin só consulta a interface pública. Não há token, dump, transporte de teste ou fixture no instalador. Não há dependências de build baixadas dentro do fonte. Os instaladores dos acompanhantes e da base precisam ser obtidos separadamente e conferidos pelos hashes.
