# Plano — 0.12.0 · 18/11/2026

Base 0.11.1. Normas centrais revisão 5, de 02/11; pedido atual sem itens abertos. O Pedido 13 permanece concluído. Esta rodada responde ao impacto Core 1.93.0, Pedido Core 430, revisão 2: leitura administrativa dos incidentes do próprio domínio, diagnóstico de transporte e aceite do adaptador de autorização.

Decisão de contrato no planejamento: pipedrive/incidentes-ler (GET/readonly) consome a ability pública f3base/incidentes-tecnicos-ler. Uma página por chamada e cursor inalterado; páginas podem não conter Pipedrive. Projeção por allowlist, sem e-mail, identidade comercial ou dados de outros pacotes. Sem permissões novas. Falha do contrato limita esta consulta, sem impedir regras, documentação ou fluxo próprio. A tela mostra resumo com limite explícito e nunca deduz recuperação a partir de falta de autorização. O Core continua responsável pela observação, persistência, deduplicação e transporte.

Validação coordenada: ausência do Core; retorno inválido; cursor vazio/intermediário/cíclico; erro na segunda página sem resumo falso; entrega pendente/incerta; perfil sem permissão; nenhum e-mail/HTTP/escrita em leituras; Core oficial para transição de autorização recusada/recuperada, desativação intencional e repetição. Fixtures e correio interceptado apenas em WordPress descartável. Atualização direta 0.11.1, matriz vigente, navegador e instalação no Site-Teste.

Acompanhantes iniciais: Core 1.93.0, MCP 0.48.0, LinkedIn 0.26.0 (anexos); Google 0.36.0 e Meta 0.28.0 (inventário Site-Teste e pacotes existentes). Nenhuma mudança exigida em seus códigos. A referência de incidente está no contrato público do Core; não ler opções privadas no runtime. O planejamento determinou encaminhamento individual ao Core com aceite e limites.

## Encerramento — revisão 2, 18/11/2026

Implementação 0.12.0 fechada. Mesmos bytes passaram em WordPress 7.1.4, PHP 8.3.6 e 8.4.27: 784 asserções por runtime. Navegador: 98 verificações e 21 capturas. Os 12 documentos foram lidos integralmente pelo executor MCP original nas duas matrizes. Nenhum acompanhante foi modificado. Core: impacto revisão 2, alinhado tecnicamente; autorização real e entrega postal pendentes.

A consulta ao Site-Teste confirmou 0.11.1 ativa e saudável, com os cinco acompanhantes vigentes; nenhuma mutação foi feita. A consulta GitHub da candidata em main retornou NOT_FOUND. A seção 4.4 exige publicação pela frota e conferência dos bytes raw antes da instalação compartilhada; o envio Base64 não foi usado como substituição. Publicação/implantação e aceite operacional ficam com dono/frota, com procedimento executável no relatório. Não há recibo compartilhado da 0.12.0 nem homologação comercial.

Status de entrega: com-pendencias. Fonte e relatório são fechados segundo a seção 4.3; instalador imutável após a entrega. O relatório externo é canônico para a identidade do ZIP fonte. Nenhum Pedido 14 criado; Pedido 13 permanece entregue na base.
