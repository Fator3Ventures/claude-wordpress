"""Authenticated WordPress panel checks. Run against the disposable lab, never a shared site."""
import os,json,sys
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.sync_api import sync_playwright
base='http://127.0.0.1:18491';entry=base+'/wp-admin/tools.php?page=wp-mcp-pipedrive-fator3'
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
tabs={'visao':'operacao','diario':'operacao','regras':'configurar','retencao':'configurar','pendencias':'suporte','ajuda':'suporte'}
checks={};errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ['F3_CHROMIUM'],args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']);ctx=b.new_context(locale='pt-BR',timezone_id='America/Sao_Paulo');page=ctx.new_page()
 page.on('pageerror',lambda e:errors.append(str(e)));page.set_default_timeout(10000)
 page.goto(base+'/wp-login.php');page.locator('#user_login').fill('qa_admin');page.locator('#user_pass').fill(os.environ['F3_BROWSER_PASSWORD']);page.locator('#wp-submit').click();page.wait_for_url('**/wp-admin/**')
 for w,h in [(360,800),(768,1024),(1440,1000)]:
  page.set_viewport_size({'width':w,'height':h})
  for tab,g in tabs.items():
   result=page.goto(entry+'&aba='+tab);page.wait_for_selector('.f3pd-subtabs [aria-current=page]');q=parse_qs(urlparse(page.url).query)
   name=f'{tab}-{w}';checks[name+'_redirect']=q.get('grupo')==[g] and q.get('aba')==[tab] and result.request.redirected_from is not None
   metrics=page.evaluate("""() => {const head=document.querySelector('.f3pd-head'), badge=head.querySelector('.f3pd-version').getBoundingClientRect(), t=head.querySelector('h1').getBoundingClientRect();return {width:document.documentElement.scrollWidth,nav:[...document.querySelectorAll('.f3pd-groups a,.f3pd-subtabs a')].every(a=>a.getBoundingClientRect().right<=innerWidth),badge:badge.left>=t.right-1, text:head.innerText}}""")
   checks[name+'_layout']=metrics['width']<=w+1 and metrics['nav'] and metrics['badge'] and 'Versão 0.12.0' in metrics['text']
   if not checks[name+'_layout']:print(name,metrics,flush=True)
   page.screenshot(path=str(out/(name+'.png')),full_page=True,animations='disabled')
   if tab=='diario' and w==360:
    checks['rolagem_interna']=page.locator('.f3pd-table').first.evaluate('e=>e.scrollWidth>e.clientWidth && getComputedStyle(e).overflowX==="auto"')
   if tab=='ajuda' and w==360:
    f=page.get_by_label('Buscar documento');f.fill('contratos');checks['busca_indice']=page.locator('.f3pd-help-nav li:visible').count()==1;f.fill('')
 page.goto(entry+'&aba=diario');page.locator('[name=busca]').fill('lead-original');page.get_by_role('button',name='Buscar',exact=True).click();checks['busca_fora_primeira_pagina']='1–1 de 1' in page.locator('.f3pd-pager').inner_text() and 'lead-original' in page.locator('tbody').last.inner_text()
 page.get_by_role('link',name='Limpar',exact=True).click();page.get_by_role('link',name='Próxima',exact=True).first.click();checks['proxima_exata']='21–40 de' in page.locator('.f3pd-pager').inner_text()
 page.get_by_role('link',name='Anterior',exact=True).first.click();checks['anterior_exata']='1–20 de' in page.locator('.f3pd-pager').inner_text()
 page.goto(entry+'&aba=pendencias');checks['pendencias_total']='1–10 de 12' in page.locator('.f3pd-pager').inner_text()
 checks['rotulo_operacao_em_portugues']=page.locator('#f3pd-recuperacao details summary').first.inner_text().startswith('Registrar perda')
 page.get_by_role('link',name='Próxima',exact=True).click();checks['pendencias_pagina_final']='11–12 de 12' in page.locator('.f3pd-pager').inner_text()
 page.locator('[name=busca]').fill('21012');page.get_by_role('button',name='Buscar',exact=True).click();checks['pendencias_busca_global']='1–1 de 1' in page.locator('.f3pd-pager').inner_text() and '21012' in page.locator('.f3pd-body').inner_text()
 page.locator('[name=busca]').fill('Sem prova da intenção');page.get_by_role('button',name='Buscar',exact=True).click();checks['busca_situacao_portugues']='1–10 de 12' in page.locator('.f3pd-pager').inner_text()
 page.goto(entry+'&aba=diario&apos_pendencia=4');checks['cursor_legado_pendencias']=parse_qs(urlparse(page.url).query).get('aba')==['pendencias']
 page.goto(entry+'&documento=contratos');checks['favorito_documento']=page.locator('#f3pd-help-current h2').first.inner_text()=='Contratos e permissões'
 page.goto(entry+'&aba=regras&modo=json');checks['favorito_editor_json']=page.locator('[name=regras_json]').count()==1
 nojs=b.new_context(java_script_enabled=False,storage_state=ctx.storage_state());pj=nojs.new_page();pj.goto(entry+'&aba=diario&busca=lead-original');checks['busca_sem_javascript']='1–1 de 1' in pj.locator('.f3pd-pager').inner_text();nojs.close()
 checks['sem_erros_js']=not errors;version=b.version;b.close()
report={'chromium':version,'screenshots':len(list(out.glob('*.png'))),'checks':checks,'passed':sum(checks.values()),'failed':sum(not x for x in checks.values()),'errors':errors}
(out.parent/'browser0110.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['screenshots'],report['passed'],[x for x,v in checks.items() if not v]);sys.exit(bool(report['failed']))
