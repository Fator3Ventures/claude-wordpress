<?php
/** Native MCP executor, original 0.44.0, in disposable WordPress. */
use Fator3\McpFiles as C;
use Fator3\Pipedrive\{Api,Documentation};
if (!defined('F3_PIPEDRIVE_DISPOSABLE')) { exit(2); }
wp_set_current_user(1);$checks=[];$reads=[];$http=0;
$check=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
$block=static function()use(&$http){++$http;return new WP_Error('qa_block','No network in fixture');};add_filter('pre_http_request',$block,1);
$inventory=[];foreach(['base-site-core-fator3'=>'1.93.0','wp-mcp-fator3'=>'0.48.0','wp-mcp-google-fator3'=>'0.36.0','wp-mcp-meta-fator3'=>'0.28.0','wp-mcp-linkedin-fator3'=>'0.26.0'] as $slug=>$version){$file=$slug.'/'.$slug.'.php';$data=get_plugin_data(WP_PLUGIN_DIR.'/'.$file,false,false);$inventory[$slug]=['version'=>$data['Version'],'active'=>is_plugin_active($file)];$check('convivencia_'.$slug,$inventory[$slug]['active']&&$data['Version']===$version);}
$expected=json_decode('{"wp-mcp-fator3":{"files":481,"sha256":"eb8072007e1e94f947878fc7f34cc203cf7984a346553e9fcb26dd80a5c3da80"},"wp-mcp-linkedin-fator3":{"files":100,"sha256":"58b1ad655fd38d131d877f0eaf59fb905fa69f14fdc49ba00c3154ab7d59217d"},"base-site-core-fator3":{"files":1274,"sha256":"9b60df0575783b455310d80d52a3c4e39adb60232e5fc35bf4b864c44cbd7e33"},"wp-mcp-google-fator3":{"files":205,"sha256":"d0b54132835186bf98a9266b82e66fb6dfc8726c7d25b7caca7aada68bf1df8e"},"wp-mcp-meta-fator3":{"files":74,"sha256":"d3da64ee8e5e616bc97ce201e5d3b2ad87e6f44b470120819ae814fe6d7e4712"}}',true);$parity=[];foreach($expected as $slug=>$e){$tree=[];$base=WP_PLUGIN_DIR.'/'.$slug;foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS)) as $file)if($file->isFile())$tree[substr($file->getPathname(),strlen($base)+1)]=hash_file('sha256',$file->getPathname());ksort($tree);$parity[$slug]=['files'=>count($tree),'sha256'=>hash('sha256',json_encode($tree,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE))];$check('installer_parity_'.$slug,$parity[$slug]===$e);}
$grant='pipedrive-qa-'.bin2hex(random_bytes(8));
C\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>1,'client_id'=>'qa-pipedrive','profile'=>'maintenance','status'=>'active']);
C\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$grant,'client_id'=>'qa-pipedrive','profile'=>'maintenance']);
$execute=static function($op,$i=[]){return \WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute(['ability_name'=>'pipedrive/'.$op,'parameters'=>$i]);};
try {
    $listing=C\Discovery::listing(wp_get_abilities(),['prefix'=>'pipedrive/','compact'=>true,'per_page'=>50]);
    $check('provider_novo_descoberto',($listing['total']??0)===count(Api::schemas()));
    $check('provider_versao_exata',count(array_filter($listing['abilities']??[],static fn($x)=>$x['provider']==='wp-mcp-pipedrive-fator3'&&$x['version']==='0.12.0'))===count(Api::schemas()));
    foreach (Documentation::DOCUMENTS as $id=>$file) {
        $offset=0;$text='';$pages=0;$hash=null;
        do {
            $args=['documento'=>$id,'offset'=>$offset,'limite_bytes'=>2048];if ($hash) {$args['sha256_esperado']=$hash;}
            $r=$execute('documentacao-ler',$args);
            $d=$r['data']['data']??null;
            if (empty($r['success'])||empty($r['data']['success'])||!is_array($d)) { throw new RuntimeException('MCP document failed: '.json_encode($r)); }
            $text.=$d['conteudo'];$offset=$d['proximo_offset'];$hash=$d['sha256'];++$pages;
        } while ($offset!==null);
        $check('mcp_doc_'.$id,$text===file_get_contents(Fator3\Pipedrive\ROOT.'/docs/'.$file)&&hash('sha256',$text)===$hash);
        $reads[]=['documento'=>$id,'sha256'=>$hash,'bytes'=>strlen($text),'pages'=>$pages];
    }
    $ir=$execute('incidentes-ler');$check('leitura_incidentes_pelo_executor',!empty($ir['data']['success'])&&isset($ir['data']['data']['itens']));
    $check('docs_sem_fornecedor',$http===0);
    $r=$execute('status');$check('core_registrado_contrato',($r['data']['data']['registro_cliente']??'')==='registrado');
    C\Persistence::put('connections','grant:'.$grant,['connection_id'=>'grant:'.$grant,'user_id'=>1,'profile'=>'read','status'=>'active','policy_version'=>2,'expires'=>0]);
    $check('perfil_leitura_recusa_retencao',is_wp_error(C\AuthorizationPolicy::check('pipedrive/retencao-configurar',[],false)));
    $check('perfil_leitura_nao_escreve',is_wp_error(C\AuthorizationPolicy::check('pipedrive/api-aplicar',[],false)));
    $check('perfil_leitura_documentacao',C\AuthorizationPolicy::check('pipedrive/documentacao-ler',[],true)===true);
    $meta=wp_get_ability('pipedrive/api-previa')->get_meta();$check('previa_classificada_escrita',empty($meta['annotations']['readonly'])&&($meta['fator3']['remote_effect']??'')==='read');
    $meta=wp_get_ability('pipedrive/status')->get_meta();$incidentMeta=wp_get_ability('pipedrive/incidentes-ler')->get_meta();$check('incidente_somente_leitura',!empty($incidentMeta['annotations']['readonly'])&&$incidentMeta['fator3']['remote_effect']==='none');$check('perfil_leitura_incidentes',C\AuthorizationPolicy::check('pipedrive/incidentes-ler',[],true)===true);
    $check('status_observacional',!empty($meta['annotations']['readonly'])&&($meta['fator3']['local_effect']??'')==='none');
    $check('sem_executor_irrestrito',!C\AuthorizationPolicy::executor(wp_get_ability('pipedrive/api-aplicar')));
    $client=new class {
 public function capabilities(){return ['contract'=>'pipedrive-api-client/1.0.0'];}
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>1,'usuario_id'=>2],'revisao'=>'r1','orcamento'=>['teto'=>3000,'consumido'=>0,'reservado'=>0],'saldo_conta'=>null]];}
 public function request($m,$p,$q,$b,$c){return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>['api_token'=>'secret-fixture','name'=>'Allowed fixture']],'saldo_conta'=>null]];}
};
$registry=new class($client){public function __construct(public $client){}public function register_consumer(...$args){return $this->client;}};
\Fator3\Pipedrive\CoreClient::register($registry,'pipedrive-api-client/1.0.0');
$redacted=$execute('api-ler',['caminho'=>'/v1/users/me']);
$check('saida_redigida_no_executor',!empty($redacted['data']['success'])&&!str_contains(json_encode($redacted),'secret-fixture')&&str_contains(json_encode($redacted),'Allowed fixture'));
$reportClient=new class {
 public function capabilities(){return ['contract'=>'pipedrive-api-client/1.0.0'];}
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>1,'usuario_id'=>2],'revisao'=>'r1','orcamento'=>['teto'=>3000,'consumido'=>0,'reservado'=>0],'saldo_conta'=>null]];}
 public function request($m,$p,$q,$b,$c){$data=[];if($p==='/v1/dealFields')foreach(['Parceiro','Unidade','Canal','Campanha','Ponto de conversão'] as $n=>$name)$data[]=['key'=>str_repeat((string)($n+1),40),'name'=>$name,'field_type'=>'enum','options'=>[]];return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>$data,'additional_data'=>str_starts_with($p,'/api/v2/')?['next_cursor'=>null]:['pagination'=>['more_items_in_collection'=>false]]],'saldo_conta'=>null]];}
};
$registry=new class($reportClient){public function __construct(public $client){}public function register_consumer(...$args){return $this->client;}};
\Fator3\Pipedrive\CoreClient::register($registry,'pipedrive-api-client/1.0.0');
$r=$execute('relatorio',['data_inicio'=>'2026-09-28','data_fim'=>'2026-10-27','limite_plano'=>1000]);
$check('report_read_profile_execution',($r['data']['data']['completo']??false)===true);
$check('report_mcp_cost',($r['data']['data']['custo']['gasto']??null)===100);
$meta=wp_get_ability('pipedrive/relatorio')->get_meta();$check('report_remote_read',($meta['fator3']['remote_effect']??'')==='read'&&!empty($meta['annotations']['readonly']));
$check('report_mcp_zero_http',$http===0);
foreach(['cadencia-fila','auditoria','contar-por-campo','configuracao-ler'] as $newop){$args=$newop==='contar-por-campo'?['entidade'=>'leads','campo'=>str_repeat('1',40)]:[];$result=$execute($newop,$args);$check('new_mcp_read_'.$newop,!empty($result['data']['success']));}
foreach(['configuracao-simular','operacao-aplicar','whatsapp-registrar','lead-encerrar','negocio-perder','lead-arquivado-editar'] as $newop)$check('read_profile_denies_'.$newop,is_wp_error(C\AuthorizationPolicy::check('pipedrive/'.$newop,[],false)));


// Use genuine MCP grant/profile resolution and the native REST dispatcher. Only the supplier is a fixture.
$profile = static function (string $type, array $abilities=[]) use ($grant): void {
    C\Persistence::put('connections','grant:'.$grant,['connection_id'=>'grant:'.$grant,'user_id'=>1,'profile'=>$type,'abilities'=>$abilities,'status'=>'active','policy_version'=>2,'expires'=>0]);
};
$rest = static function (string $method,string $op,array $params=[]): \WP_REST_Response {
    $req=new \WP_REST_Request($method,'/f3-pipedrive/v1/'.$op);
    if ($method==='POST') {$req->set_header('Content-Type','application/json');$req->set_body(wp_json_encode($params));} else {$req->set_query_params($params);}
    return rest_do_request($req);
};
$ops=Fator3\Pipedrive\Store::table('ops');$journal=Fator3\Pipedrive\Store::table('journal');
$countRows=static fn()=>[(int)$GLOBALS['wpdb']->get_var("SELECT COUNT(*) FROM $ops"),(int)$GLOBALS['wpdb']->get_var("SELECT COUNT(*) FROM $journal")];
$beforeRows=$countRows();$beforeHttp=$http;
$id=str_repeat('a',32);$inputs=['recuperacao-previa'=>['origem_id'=>$id], 'recuperacao-confirmar'=>['previa_id'=>$id,'confirmacao'=>'teste de perfil']];
$read=$execute('pendencias-ler',[]);$check('read_lists_only_local_pending',!empty($read['data']['success'])&&$beforeHttp===$http);
foreach($inputs as $op=>$args){
    $e=$execute($op,$args);
    $check('readonly_executor_denies_'.$op,($e['error_code']??$e['data']['code']??'')==='profile_denied');
    $r=$rest('POST',$op,$args);$check('readonly_rest_denies_'.$op,$r->get_status()===403&&($r->get_data()['code']??'')==='nao_autorizado');
}
$profile('custom',['pipedrive/documentacao-ler']);
$read=$execute('pendencias-ler',[]);$check('custom_executor_denies_unlisted_read',($read['error_code']??$read['data']['code']??'')==='profile_denied');
$r=$rest('GET','pendencias-ler');$check('custom_rest_denies_unlisted_read',$r->get_status()===403&&($r->get_data()['code']??'')==='nao_autorizado');
$profile('custom',['pipedrive/pendencias-ler']);
$read=$execute('pendencias-ler',[]);$check('custom_explicit_read_allowed',!empty($read['data']['success']));
$r=$rest('POST','recuperacao-previa',$inputs['recuperacao-previa']);$check('custom_rest_cannot_write',$r->get_status()===403&&($r->get_data()['code']??'')==='nao_autorizado');
$check('profile_denials_leave_journal_and_receipts_unchanged',$beforeRows===$countRows()&&$http===$beforeHttp);
C\ConnectionContext::restore_identity(null,1);
$r=$rest('GET','pendencias-ler');
$check('ordinary_wp_admin_can_read_own_account_locally',$r->get_status()===200&&($r->get_data()['success']??false)===true);
wp_set_current_user(0);$r=$rest('GET','pendencias-ler');
$check('anonymous_rest_denies_pending',in_array($r->get_status(),[401,403],true));
wp_set_current_user(1);

} finally {
    C\Persistence::delete('connections','grant:'.$grant);C\Persistence::delete('oauth-grants',$grant);C\ConnectionContext::restore_identity(null,1);remove_filter('pre_http_request',$block,1);
}
return ['checks'=>$checks,'passed'=>count(array_filter($checks,static fn($x)=>$x['passed'])),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),
    'companion_parity'=>$parity,'companions'=>$inventory,'runtime_sha256'=>(function(){$out=[];$dir=Fator3\Pipedrive\ROOT;foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS)) as $f){if($f->isFile())$out[substr($f->getPathname(),strlen($dir)+1)]=hash_file('sha256',$f->getPathname());}ksort($out);return $out;})(),'documents'=>$reads,'pages'=>array_sum(array_column($reads,'pages')),'mcp_version'=>F3_MCP_FILES_VERSION,'transport'=>'Executor MCP original em WordPress isolado; sem sessão HTTP MCP própria','http_real'=>$http];
