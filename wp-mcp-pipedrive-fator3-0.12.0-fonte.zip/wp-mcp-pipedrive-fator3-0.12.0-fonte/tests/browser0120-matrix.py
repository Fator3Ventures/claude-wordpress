"""Native Core/MCP admin read of a synthetic uncertain incident. Local only."""
import os,json,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
assert os.environ['F3_QA_DB']=='f3pipqa_0900_r12c_matrix'
base='http://127.0.0.1:18491';out=Path(sys.argv[1]);out.mkdir(exist_ok=True,parents=True)
checks={};errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ['F3_CHROMIUM'],args=['--no-sandbox','--disable-dev-shm-usage']);ctx=b.new_context(locale='pt-BR',timezone_id='America/Sao_Paulo');page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(base+'/wp-login.php');page.locator('#user_login').fill('qa_admin');page.locator('#user_pass').fill(os.environ['F3_BROWSER_PASSWORD']);page.locator('#wp-submit').click();page.wait_for_url('**/wp-admin/**')
 url=base+'/wp-admin/tools.php?page=wp-mcp-pipedrive-fator3&grupo=suporte&aba=pendencias'
 for width,height in [(360,800),(768,1024),(1440,1000)]:
  page.set_viewport_size({'width':width,'height':height});page.goto(url);panel=page.locator('#f3pd-incidentes')
  checks[f'central_nativa_{width}']='Há incidentes abertos' in panel.inner_text() and 'Diagnóstico indisponível' not in panel.inner_text()
  values=panel.locator('dd').all_text_contents();checks[f'contagem_real_{width}']=values==['1','0','1','1']
  checks[f'limites_explicitos_{width}']='não comprova recebimento' in panel.inner_text() and 'não confirma a autorização' in panel.inner_text()
  checks[f'layout_{width}']=page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  checks[f'sem_acao_mutante_{width}']=panel.locator('form,button,input').count()==0
  page.screenshot(path=str(out/f'incidentes-core-{width}.png'),full_page=True,animations='disabled')
 page.locator('#f3pd-incidentes').get_by_role('link',name='Consultar diagnóstico e recuperação').click();checks['guia_funciona']='Operar e recuperar' in page.locator('#f3pd-help-current').inner_text()
 checks['sem_erros_js']=not errors
 ctx2=b.new_context(java_script_enabled=False,storage_state=ctx.storage_state());pg=ctx2.new_page();pg.goto(url);checks['sem_javascript']='Há incidentes abertos' in pg.locator('#f3pd-incidentes').inner_text();ctx2.close()
 version=b.version;b.close()
result={'chromium':version,'checks':checks,'passed':sum(checks.values()),'failed':sum(not x for x in checks.values()),'errors':errors,'ambiente':'Core e MCP originais; incidente e transporte sintéticos, autorização CRM ausente'}
(out.parent/'browser0120-matrix.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(result);sys.exit(bool(result['failed']))
