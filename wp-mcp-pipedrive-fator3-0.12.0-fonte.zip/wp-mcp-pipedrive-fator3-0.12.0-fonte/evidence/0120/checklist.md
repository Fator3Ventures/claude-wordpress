# Checklist de encerramento — 0.12.0

Aplicação da seção 14 do padrão revisão 5. Esta cópia precede o fechamento do fonte.

| Item | Resultado / evidência |
|---|---|
| Duas normas centrais integrais e revisões | Verificado: revisão 5, 02/11/2026; fontes em inputs/ |
| Base, alvo e conjunto vigente | Verificado: 0.11.1 → 0.12.0; cinco acompanhantes em companion-installers.json |
| Mínimos e runtimes | Declarados WP 7.1.4/PHP 8.3; executados WP 7.1.4/PHP 8.3.6 e 8.4.27 |
| Somente versões vigentes | Verificado; 0.11.1 somente como origem da migração |
| Nova versão para correção; preservação | Documentado e migração/replay verificados; sem downgrade |
| Artefatos próprios | Instalador, fonte, relatório externo e impacto preparados; hash do fonte completado externamente |
| Impactos, proposta e decisão | Pedido Core 430; plano e impacto próprio desde implementação; produtor permanece no Core |
| Diagnóstico e pontos de integração | Impacto revisão 2 identifica classes, métodos, schema, cursor e permissão |
| Teste isolado do destinatário | Core original, sem patch; 14 asserções por runtime |
| Emissor pronto | Implementado, falta/recusa do contrato exercitadas; nenhum patch adicional pedido no Core |
| Atualização do impacto | Revisão 2 de entrega; aceite técnico alinhado, operacional pendente |
| Nomes, bytes e hashes | Instalador fechado; fonte calculado após esta cópia; relatório externo canônico |
| Fonte único e sem ZIP interno | Conferido pelo empacotador; relatório pré-fechamento explícito |
| Cabeçalho, painel e capacidades | Verificados; identidade preservada; manage_options e política mantidas |
| Raw/expected_sha256/expected_slug | Pendente da frota. Sem instalação compartilhada nesta rodada; fonte não publicado |
| Documentação instalada | 12 documentos na árvore runtime e no instalador |
| Leitura integral pelo MCP | 87 páginas por matriz com executor MCP original; sessão remota candidata pendente |
| Limpa e atualização | 650 e 17 asserções por runtime; verificação em novo processo |
| Funções e integrações | 107 asserções de matriz por runtime; 98 de navegador; fornecedor sintético |
| Configurações e dados | Preservação na migração; compartilhado somente consultado, nenhuma mutação |
| Segredos e fixtures no instalador | Ausentes; 43 arquivos de runtime/documentação; QA fora do instalador |
| Acesso real separado de simulação | CRM e e-mail reais não homologados; responsável dono/frota |
| Estado final e limpeza | Site-Teste 0.11.1 saudável; servidores locais encerrados; nenhum controlador publicado |
| Autorização e propriedade | Nenhuma publicação, mensagem ou alteração de pacote alheio; somente cópias isoladas |

Status: com-pendencias. Os itens não comprovados não foram convertidos em aprovação.
