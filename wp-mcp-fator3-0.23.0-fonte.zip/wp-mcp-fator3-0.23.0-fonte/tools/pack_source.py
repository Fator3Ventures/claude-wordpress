#!/usr/bin/env python3
"""Build sources, canonical documentation and evidence; exclude labs/dependencies/secrets."""
from pathlib import Path
import argparse,hashlib,json
import build

def inventory():
 root=build.ROOT;result={};prefix=f'wp-mcp-fator3-{build.version()}-fonte'
 for item in ['VERSION','README.md','fontes','tools','docs','evidencias',f'wp-mcp-fator3-{build.version()}-relatorio-base.md']:
  path=root/item
  if not path.exists():raise ValueError('Missing source item: '+item)
  for file in ([path]if path.is_file()else path.rglob('*')):
   rel=file.relative_to(root)
   if 'fixtures' in rel.parts or not file.is_file()or '__pycache__'in rel.parts or file.suffix in {'.pyc','.zip','.log','.sqlite','.sqlite3'}or file.name in {'.env','fixture-private.json'}:continue
   if file.is_symlink():raise ValueError('Symlink in source: '+str(rel))
   result[prefix+'/'+rel.as_posix()]=file.read_bytes()
 return result

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path);args=parser.parse_args();build.inventory()
 path=args.out or build.ROOT/f'wp-mcp-fator3-{build.version()}-fonte.zip';data=inventory();build.write_zip(path,data)
 print(json.dumps({'file':path.name,'bytes':path.stat().st_size,'files':len(data),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
