<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);
$config=json_decode(file_get_contents($argv[1]),true);$index=(int)$argv[2];$deadline=microtime(true)+10;
file_put_contents($config['ready'].'.'.$index,'ready');
while(!is_file($config['barrier'])){if(microtime(true)>$deadline)exit(3);usleep(1000);}
if($config['kind']==='oauth') {
    $result=WpMcpUltimate\OAuth\TokenStore::exchange($config['params']);
    $out=is_wp_error($result)?['success'=>false,'error_code'=>$result->get_error_code()]:['success'=>true];
}elseif($config['kind']==='file') {
    $r=wp_get_ability('files/write')->execute(['path'=>$config['target'],'content'=>'worker-'.$index,'expected_sha256'=>$config['expected']]);
    $out=is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code()]:array_intersect_key($r,array_flip(['success','error_code','conflict']));
}else{
    $result=Fator3\McpFiles\ExecutionCoordinator::once('fixture/once',['idempotency_key'=>$config['key']],static function()use($config){file_put_contents($config['target'],"effect\n",FILE_APPEND|LOCK_EX);usleep(150000);return Fator3\McpFiles\Result::ok(['changed'=>true]);},'fixture-operation');
    $out=array_intersect_key($result,array_flip(['success','replayed','error_code']));
}
echo json_encode($out);exit(0);
