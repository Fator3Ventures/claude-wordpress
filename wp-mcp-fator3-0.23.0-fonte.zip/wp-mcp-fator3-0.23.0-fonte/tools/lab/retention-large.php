<?php
namespace Fator3\RecoveryV1 {
    // Test-only filesystem fault: fail one quarantine removal, then allow resume.
    function unlink($path) { if(!empty($GLOBALS['f3_retention_fault'])&&str_contains($path,'/.f3-prune-')){$GLOBALS['f3_retention_fault']=false;return false;}return \unlink($path); }
}
namespace {
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\{Persistence,Backups,StateStore};
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'allow_backup_export'=>true,'allow_foreign_backup_export'=>true,'time'=>time()]);
$dir=WP_CONTENT_DIR.'/f3-mcp-backups';wp_mkdir_p($dir);$created=[];$ids=[];$tests=[];
function check_large($name,$ok){global $tests;$tests[]=['name'=>$name,'passed'=>(bool)$ok];}
for($i=0;$i<450;$i++){$id=bin2hex(random_bytes(12));$ids[]=$id;$body='synthetic-'.$id;file_put_contents($dir.'/'.$id.'.bak',$body);file_put_contents($dir.'/'.$id.'.json',wp_json_encode(['id'=>$id,'time'=>'2001-01-01T00:00:00Z','path'=>'wp-content/synthetic.txt','sha256'=>hash('sha256',$body)]));$created[]=$dir.'/'.$id.'.bak';$created[]=$dir.'/'.$id.'.json';}
$orphan=bin2hex(random_bytes(12));file_put_contents($dir.'/'.$orphan.'.bak','orphan');$created[]=$dir.'/'.$orphan.'.bak';
$missing=bin2hex(random_bytes(12));file_put_contents($dir.'/'.$missing.'.json',wp_json_encode(['id'=>$missing,'time'=>'2001-01-01T00:00:00Z','sha256'=>str_repeat('0',64)]));$created[]=$dir.'/'.$missing.'.json';
$unknown=$dir.'/unrelated-'.bin2hex(random_bytes(8)).'.txt';file_put_contents($unknown,'preserve');$created[]=$unknown;
$seen=[];$blocked=[];$after='';$first=null;$pages=0;$start=microtime(true);$before_memory=memory_get_usage(true);
do{$p=Backups::prune(['older_than_days'=>3650,'include_legacy'=>true]+($after?['legacy_after'=>$after]:[]));if(empty($p['success']))throw new RuntimeException('Preview failed.');$first??=$p;$seen=array_merge($seen,array_column($p['selection'],'id'));$blocked=array_merge($blocked,array_column($p['blocked'],'id'));$after=$p['legacy_after'];$pages++;if($pages>10)throw new RuntimeException('Unbounded pagination.');}while($after);
check_large('O08 450 complete legacy pairs enumerated in bounded windows',!array_diff($ids,$seen)&&count(array_unique($seen))>=450&&$pages>=3);
check_large('O08 both directions of incomplete pair are blocked',in_array($orphan,$blocked,true)&&in_array($missing,$blocked,true));
$GLOBALS['f3_retention_fault']=true;$r=Backups::prune(['dry_run'=>false,'expected_selection_sha256'=>$first['expected_selection_sha256']]);
check_large('O08 partial removal reports remaining component',($r['error_code']??'')==='backup_prune_partial'&&!empty($r['failed'])&&!empty($r['pending']));
$r=Backups::prune(['dry_run'=>false,'expected_selection_sha256'=>$first['expected_selection_sha256']]);
check_large('O08 same frozen selection resumes after filesystem failure',!empty($r['success'])&&$r['removed']===$first['selected']);
check_large('O08 unrecognized files and incomplete pairs preserved',is_file($unknown)&&is_file($dir.'/'.$orphan.'.bak')&&is_file($dir.'/'.$missing.'.json'));
foreach($created as $file)if(is_file($file))unlink($file);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'scope'=>'450 complete legacy pairs, two incomplete pairs, unrelated file; one test-only unlink failure, resumable frozen selection. Not a full-disk test.','pages'=>$pages,'seconds'=>round(microtime(true)-$start,3),'memory_growth_bytes'=>memory_get_usage(true)-$before_memory,'tests'=>count($tests),'failures'=>count(array_filter($tests,static fn($r)=>!$r['passed'])),'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/retention-large-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out,JSON_PRETTY_PRINT)."\n";exit($out['failures']?1:0);
}
