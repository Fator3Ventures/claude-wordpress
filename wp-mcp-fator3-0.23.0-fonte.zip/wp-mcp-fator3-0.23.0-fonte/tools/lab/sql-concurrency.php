<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'database_write'=>true,'roots'=>[ABSPATH],'time'=>time()]);
$t=$wpdb->prefix.'f3_fixture_targets';$s=$wpdb->prefix.'f3_fixture_sources';$dir=WP_CONTENT_DIR.'/f3-sql-fixtures';wp_mkdir_p($dir);
add_filter('f3_mcp_sql_read_tables',static fn($tables)=>array_merge($tables,[$t,$s]));
$tests=[];
function start_worker($config,$mode){$p=proc_open([PHP_BINARY,...(php_ini_loaded_file()?['-c',php_ini_loaded_file()]:[]),__DIR__.'/sql-worker.php',$config,$mode],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);return [$p,$pipes];}
function join_worker($worker){[$p,$pipes]=$worker;$stdout=stream_get_contents($pipes[1]);$stderr=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$code=proc_close($p);return json_decode($stdout,true)??['success'=>false,'exit'=>$code];}
function await_file($file){$deadline=microtime(true)+8;while(!is_file($file)){if(microtime(true)>$deadline)throw new RuntimeException('Fixture timeout.');usleep(1000);}}
foreach(['target','source'] as $kind){
    $wpdb->query("DROP TABLE IF EXISTS `$t`, `$s`");$wpdb->query("CREATE TABLE `$t` (id INT PRIMARY KEY,grp INT,val VARCHAR(20),KEY grp(grp)) ENGINE=InnoDB");$wpdb->query("CREATE TABLE `$s` (id INT PRIMARY KEY,grp INT,chosen INT,KEY chosen(chosen)) ENGINE=InnoDB");
    $wpdb->query("INSERT INTO `$t` VALUES(1,10,'old'),(2,20,'old')");$wpdb->query("INSERT INTO `$s` VALUES(1,10,1)");
    $sql="UPDATE `$t` AS t SET t.val='done' WHERE t.grp IN (SELECT s.grp FROM `$s` AS s WHERE s.chosen=1)";$preview=wp_get_ability('db/execute')->execute(['sql'=>$sql]);if(empty($preview['confirm_token']))throw new RuntimeException('Preview unavailable.');
    $base=$dir.'/'.bin2hex(random_bytes(8));$config=['target'=>$t,'source'=>$s,'sql'=>$sql,'confirm_token'=>$preview['confirm_token'],'locked'=>$base.'.locked','release'=>$base.'.release','started'=>$base.'.started','finished'=>$base.'.finished','concurrent_sql'=>$kind==='target'?"INSERT INTO `$t` VALUES(3,10,'phantom')":"INSERT INTO `$s` VALUES(2,20,1)"];
    $file=$base.'.json';file_put_contents($file,json_encode($config));chmod($file,0600);$confirmation=start_worker($file,'confirm');await_file($config['locked']);$mutation=start_worker($file,'mutate');await_file($config['started']);usleep(200000);$blocked=!is_file($config['finished']);file_put_contents($config['release'],'continue');$a=join_worker($confirmation);$b=join_worker($mutation);
    $unchanged=$kind==='target'?$wpdb->get_var("SELECT val FROM `$t` WHERE id=3")==='phantom':$wpdb->get_var("SELECT val FROM `$t` WHERE id=2")==='old';
    $tests[]=['name'=>'F23 '.$kind.' phantom waits for serializable confirmation','passed'=>$blocked&&!empty($a['success'])&&!empty($a['applied'])&&$a['affected_rows']===1&&!empty($b['success'])&&$unchanged,'confirmation'=>$a,'concurrent_writer'=>$b,'observed_wait'=>$blocked];
    foreach(glob($base.'*') as $path)unlink($path);
}
$wpdb->query("DROP TABLE `$t`, `$s`");rmdir($dir);
$failures=count(array_filter($tests,static fn($t)=>!$t['passed']));$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'processes'=>'separate PHP CLI workers, native concurrent writer, ready/release barriers','tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/sql-concurrency-0130.json',json_encode($out,JSON_PRETTY_PRINT));echo json_encode($out,JSON_PRETTY_PRINT)."\n";exit($failures?1:0);
