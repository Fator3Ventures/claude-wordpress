<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'allow_backup_export'=>true,'meta_keys'=>['_f3_fixture_multi'],'time'=>time()]);
$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function ability($name,$args=[]){$a=wp_get_ability($name);if(!$a)return ['error_code'=>'ability_missing'];$r=$a->execute($args);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
$dir=WP_CONTENT_DIR.'/f3-test-fixtures';wp_mkdir_p($dir);
$text="um\\dois\nlinha erro\nçã🙂\n";$path=$dir.'/log.gz';file_put_contents($path,gzencode($text));
$r=ability('files/read',['path'=>$path,'compression'=>'gzip']);check('N06 gzip full bytes',!empty($r['success'])&&($r['content']??'')===$text&&!empty($r['integrity_verified']),$r);
$r=ability('files/read',['path'=>$path,'compression'=>'auto','grep'=>'erro']);check('N06 gzip grep',!empty($r['success'])&&str_contains($r['content']??'','linha erro'),$r);
file_put_contents($path,gzencode('primeiro').gzencode('segundo'));$r=ability('files/read',['path'=>$path,'compression'=>'gzip']);check('N06 concatenated members',($r['content']??'')==='primeirosegundo'&&($r['gzip_members']??0)===2,$r);
file_put_contents($path,gzencode(''));$r=ability('files/read',['path'=>$path,'compression'=>'gzip']);check('N06 empty gzip',!empty($r['success'])&&($r['expanded_bytes']??-1)===0,$r);
$bytes=gzencode('corrupted');$bytes[strlen($bytes)-6]="\x01";file_put_contents($path,$bytes);$r=ability('files/read',['path'=>$path,'compression'=>'gzip']);check('N06 CRC failure explicit',($r['error_code']??'')==='gzip_invalid',$r);
file_put_contents($path,gzencode("binary\0data"));$r=ability('files/read',['path'=>$path,'compression'=>'gzip','grep'=>'binary']);check('N06 binary filtering refused',($r['error_code']??'')==='gzip_binary_filter',$r);
$post=wp_insert_post(wp_slash(['post_title'=>'F3 meta','post_content'=>'<!-- wp:group --><div class="wp-block-group"><!-- wp:paragraph --><p>child</p><!-- /wp:paragraph --></div><!-- /wp:group -->','post_status'=>'draft']));
register_post_meta('post','f3_fixture_text',['type'=>'string','single'=>false,'show_in_rest'=>true,'auth_callback'=>'__return_true']);
$value='slashes \\path\\part';$r=ability('content/update-meta',['id'=>$post,'key'=>'f3_fixture_text','value'=>$value]);check('E01 native meta write preserves slash',!empty($r['success'])&&get_post_meta($post,'f3_fixture_text',true)===$value,$r);
$value.='\\next';$r=ability('content/update-meta',['id'=>$post,'key'=>'f3_fixture_text','value'=>$value]);check('E01 update-by-mid slash contract',!empty($r['success'])&&get_post_meta($post,'f3_fixture_text',true)===$value,$r);
add_post_meta($post,'f3_fixture_text','second');$r=ability('content/update-meta',['id'=>$post,'key'=>'f3_fixture_text','value'=>'third']);check('E01 multiple values require MID',($r['error_code']??'')==='meta_ambiguous',$r);
$r=ability('content/get-meta',['id'=>$post,'key'=>'f3_fixture_text']);check('E01 read keeps duplicate values and IDs',!empty($r['success'])&&count($r['values']??[])===2&&!empty($r['values'][0]['meta_id']),$r);
$r=ability('content/update-meta',['id'=>$post,'key'=>'unknown_unregistered','value'=>'bad']);check('E01 unregistered key denied',($r['error_code']??'')==='meta_unregistered',$r);
$r=ability('content/edit-block',['id'=>$post,'block_path'=>[0],'inner_html'=>'<div>lost</div>','preview'=>true]);check('F17 children loss refused in preview',($r['error_code']??'')==='block_children_would_be_lost',$r);
$r=ability('content/edit-block',['id'=>$post,'block_path'=>[0],'attributes'=>['unknown_fixture_attr'=>true],'preview'=>true]);check('E03 unregistered attribute refused',($r['error_code']??'')==='block_attribute_unknown',$r);
$plan=ability('operations/plan',['steps'=>[['id'=>'change','ability'=>'content/update-post','parameters'=>['id'=>$post,'title'=>'planned']]]]);$id=$plan['plan_id']??'';
$r=ability('operations/preview',['plan_id'=>$id]);check('O05 preview stores preconditions without mutation',!empty($r['preview_id'])&&get_post($post)->post_title==='F3 meta',$r);
wp_update_post(['ID'=>$post,'post_title'=>'external change']);$r=ability('operations/apply',['plan_id'=>$id]);check('O05 changed target conflicts before effect',($r['plan']['steps'][0]['result']['error_code']??'')==='plan_preview_conflict'&&get_post($post)->post_title==='external change',$r);
$plan=ability('operations/plan',['steps'=>[['id'=>'assert','ability'=>'operations/assert','parameters'=>['actual'=>'x','expected'=>'x']]]]);$id=$plan['plan_id']??'';
$r=ability('operations/cancel',['plan_id'=>$id]);$applied=ability('operations/apply',['plan_id'=>$id]);check('O06 cancellation prevents pending step',($applied['plan']['status']??'')==='cancelled'&&($applied['plan']['steps'][0]['status']??'')==='pending',[$r,$applied]);
$r=ability('operations/list',[]);check('O04 connection-bound listing',!empty($r['success'])&&count($r['operations']??[])>=2,$r);
wp_delete_post($post,true);unlink($path);@rmdir($dir);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$GLOBALS['wpdb']->db_version(),'tests'=>count($tests),'failures'=>$failures,'results'=>$tests];
file_put_contents(dirname(__DIR__,2).'/evidencias/extended-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
