<?php
require getenv('F3_WP_ROOT');
wp_set_current_user(1);$id=$argv[1];$barrier=$argv[2];
add_action('f3_mcp_database_restore_checkpoint',static function($journal,$count,$boot)use($barrier){if(!$boot||$count<20)return;file_put_contents($barrier,json_encode(['recovery_id'=>$journal,'checkpoint'=>$count]));while(true)usleep(10000);},10,3);
$r=Fator3\McpFiles\DatabaseAdmin::restore(['artifact_id'=>$id]);$r=Fator3\McpFiles\DatabaseAdmin::restore(['artifact_id'=>$id,'confirm_token'=>$r['confirm_token']]);echo json_encode($r);
