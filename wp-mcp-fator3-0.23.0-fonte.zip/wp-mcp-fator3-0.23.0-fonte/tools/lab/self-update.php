<?php
/** Isolated complete-package replacement; never point F3_WP_ROOT at production. */
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\{Persistence,StateStore,UpdateChannel,ConnectionTest,ConnectionStatus};
if((!str_contains(ABSPATH,'/lab/wordpress/')&&!(getenv('F3_ACCEPTANCE_LAB')==='1'&&ABSPATH==='/var/www/html/')&&!(getenv('F3_LAB_ISOLATED')==='1'&&str_starts_with(ABSPATH,'/tmp/f3-mcp-lab-')))||is_link(rtrim(F3_MCP_FILES_DIR,'/')))throw new RuntimeException('Isolated self-update copy required.');
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'time'=>time()]);
require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function call($name,$args){$r=wp_get_ability($name)->execute($args);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
$originalChannels=get_option('f3_mcp_update_channels',[]);$plugin='wp-mcp-fator3/wp-mcp-fator3.php';$base=(getenv('F3_FIXTURE_ROOT')?:dirname(__DIR__,3).'/lab').'/';$backup=null;$original_version=F3_MCP_FILES_VERSION;
foreach(['0.14.0-lab1','0.14.0-lab2'] as $version){
 $bytes=file_get_contents($base.'self-'.$version.'.zip');$url='https://1.1.1.1/self-'.$version.'.zip';$feed='https://1.1.1.1/'.$version.'/manifest.json';
 $manifest=['schema_version'=>1,'package'=>'wp-mcp-fator3','plugin'=>$plugin,'version'=>$version,'url'=>$url,'sha256'=>hash('sha256',$bytes),'requires'=>['wordpress'=>'7.1.2','php'=>'8.3.30'],'tested'=>['wordpress'=>'7.1.2','php'=>'8.3.30','evidence'=>'synthetic-lab']];
 update_option('f3_mcp_update_channels',['wp-mcp-fator3'=>['url'=>$feed,'package_hosts'=>[]]]);
 $offer=(object)['last_checked'=>time(),'checked'=>[$plugin=>$original_version],'response'=>[$plugin=>(object)['slug'=>'wp-mcp-fator3','plugin'=>$plugin,'new_version'=>$version,'package'=>$url,'f3_sha256'=>$manifest['sha256']]]];
 $offering=static fn()=>$offer;
 $http=static function($pre,$args,$target)use($feed,$url,$manifest,$bytes){
  if($target===$feed||$target===$url)return ['response'=>['code'=>200,'message'=>'OK'],'headers'=>['content-type'=>'application/json'],'body'=>$target===$feed?wp_json_encode($manifest):$bytes,'cookies'=>[]];
  if(str_contains($target,'api.wordpress.org'))return new WP_Error('fixture_no_external_network','Synthetic native offer.');return $pre;
 };
 add_filter('pre_site_transient_update_plugins',$offering);add_filter('pre_http_request',$http,10,3);
 try {
  if($version==='0.14.0-lab1'){
   $blocked=UpdateChannel::download(false,$url,new Plugin_Upgrader(new Automatic_Upgrader_Skin()),['plugin'=>$plugin]);
   check('O14 native updater refuses unjournaled self replacement',is_wp_error($blocked)&&$blocked->get_error_code()==='self_update_requires_recovery');
  }
  $result=call('plugins/update',['plugin'=>$plugin]);
  if($version==='0.14.0-lab1'){
   check('P06 complete self update via independent worker',!empty($result['success'])&&($result['version']??'')===$version&&!empty($result['active_after'])&&!empty($result['activation']['independent_worker']),$result);$backup=$result['backup_id']??null;
  } else check('P06 fatal self update restores previous MCP package',empty($result['success'])&&($result['recovery_status']??'')==='rolled_back'&&($result['version']??'')==='0.14.0-lab1'&&!empty($result['active_after']),$result);
 }finally{remove_filter('pre_site_transient_update_plugins',$offering);remove_filter('pre_http_request',$http,10);}
}
update_option('f3_mcp_update_channels',$originalChannels);
if($backup){$r=call('plugins/rollback',['backup_id'=>$backup]);check('P06 self rollback restores exact original package',!empty($r['success'])&&($r['version']??'')===$original_version&&!empty($r['active_after']),$r);}
$before=count(WP_Application_Passwords::get_user_application_passwords(1));$r=ConnectionTest::run('/mcp/wp-mcp-fator3');
check('O17 HTTP autotest succeeds with temporary restricted policy',!empty($r['success'])&&($r['protocol_version']??'')==='2025-11-25',$r);
check('O17 temporary native credential removed',count(WP_Application_Passwords::get_user_application_passwords(1))===$before);
check('O17 internal test is not an observed external connector',!array_filter(ConnectionStatus::observations(),static fn($o)=>($o['authentication']??'')==='wordpress-application-password'));
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'http'=>'PHP development server; not Apache acceptance','tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/self-update-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
