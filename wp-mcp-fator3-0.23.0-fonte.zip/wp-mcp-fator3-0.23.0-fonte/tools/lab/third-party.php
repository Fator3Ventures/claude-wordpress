<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;use Fator3\McpFiles\ResourceMetadata;
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'time'=>time()]);
$tests=[];$failures=0;$catalog=[];
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
$resources=[];
foreach(wp_get_abilities() as $a){
 if(str_starts_with($a->get_name(),'yoast-seo/')||str_starts_with($a->get_name(),'f3base/')||str_starts_with($a->get_name(),'elementor/'))$catalog[]=['name'=>$a->get_name(),'description'=>$a->get_description(),'input'=>$a->get_input_schema(),'output'=>$a->get_output_schema(),'meta'=>$a->get_meta()];
 if(str_starts_with($a->get_name(),'elementor/')&&($a->get_meta()['mcp']['type']??'')==='resource'){
  $r=\WpMcpUltimate\Server\Domain\Resources\RegisterAbilityAsMcpResource::make($a);$resources[]=$r;
  check('F16 real Elementor resource '.$a->get_name(),!is_wp_error($r)&&$r['uri']===$a->get_meta()['mcp']['uri']&&$r['mimeType']===$a->get_meta()['mcp']['mimeType'],is_wp_error($r)?$r->get_error_code():$r);
  check('C02 Elementor callback remains undecorated '.$a->get_name(),empty($a->get_meta()['fator3']['decorated']));
 }
}
check('F16 all seven Elementor resources recognized',count($resources)===7);
$routes=rest_get_server()->get_routes();check('C02 native default server preserved',isset($routes['/mcp/mcp-adapter-default-server']));
foreach(['/mcp/wp-mcp-fator3','/mcp/wp-mcp-ultimate'] as $route){
 $r=new WP_REST_Request('POST',$route);$r->set_header('Content-Type','application/json');$r->set_header('Accept','application/json');$r->set_header('Mcp-Protocol-Version','2026-07-28');$r->set_header('Mcp-Method','resources/list');$r->set_body(wp_json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>'resources/list','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()]]]));$response=rest_do_request($r);$body=json_decode(wp_json_encode($response->get_data()),true);
 $uris=array_column($body['result']['resources']??[],'uri');check('F16 seven real resources on '.$route,count(array_filter($uris,static fn($u)=>str_starts_with($u,'elementor://')))===7,['status'=>$response->get_status(),'body'=>$body]);
}
$yoast=wp_get_ability('yoast-seo/get-post-seo-data');$update=wp_get_ability('yoast-seo/update-post-seo-data');
check('E02 native Yoast structured methods exist but are not registered in 28.5',!$yoast&&!$update,array_column(array_filter($catalog,static fn($r)=>str_starts_with($r['name'],'yoast-seo/')),'name'));
$post=wp_insert_post(['post_title'=>'SEO fixture','post_status'=>'publish']);
$read=wp_get_ability('content/get-seo')->execute(['id'=>$post]);$args=['id'=>$post,'expected_revision'=>$read['revision']??'','values'=>['title'=>'SEO title \\folder','description'=>'SEO description','indexing'=>'noindex','nofollow'=>true,'open_graph_title'=>'Social title']];
$r=wp_get_ability('content/update-seo')->execute($args);
check('E02 SEO adapter uses real Yoast API with readback',is_array($r)&&!empty($r['success'])&&($r['values']['title']??'')===$args['values']['title']&&($r['values']['indexing']??'')==='noindex'&&!empty($r['indexable_rebuilt']),is_wp_error($r)?$r->get_error_code():$r);
$r=wp_get_ability('content/update-seo')->execute($args);check('E02 SEO stale revision conflict',is_array($r)&&($r['error_code']??'')==='content_conflict',is_wp_error($r)?$r->get_error_code():$r);
wp_delete_post($post,true);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'yoast'=>defined('WPSEO_VERSION')?WPSEO_VERSION:null,'elementor'=>defined('ELEMENTOR_VERSION')?ELEMENTOR_VERSION:null,'database'=>$wpdb->db_version(),'tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/third-party-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));file_put_contents(dirname(__DIR__,2).'/evidencias/third-party-catalog-0130.json',wp_json_encode(['yoast'=>$out['yoast'],'elementor'=>$out['elementor'],'catalog'=>$catalog],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
