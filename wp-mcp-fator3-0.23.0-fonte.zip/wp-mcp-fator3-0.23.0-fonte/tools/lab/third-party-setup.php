<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['wordpress-seo/wp-seo.php','elementor/elementor.php','base-site-core-fator3/base-site-core-fator3.php'] as $plugin){$r=activate_plugin($plugin,'',false,true);if(is_wp_error($r)){echo $plugin.' '.$r->get_error_code()."\n";exit(1);}echo 'Activated lab '.$plugin."\n";}
