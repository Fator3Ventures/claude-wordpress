<?php
/** Synthetic lab only. Used after initializing a clean local datadir. */
$base=getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
if(!str_contains($base,'/lab/wordpress/')&&!(getenv('F3_LAB_ISOLATED')==='1'&&str_starts_with($base,'/tmp/f3-mcp-lab-')))throw new RuntimeException('Only the local synthetic lab can be initialized here.');
$db=new mysqli('127.0.0.1','root','',null,18316);$db->query('CREATE DATABASE IF NOT EXISTS f3_lab CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');$db->close();
define('WP_INSTALLING',true);require $base;require_once ABSPATH.'wp-admin/includes/upgrade.php';
if(!is_blog_installed())wp_install('Fator3 synthetic lab','f3_lab_admin','lab@example.invalid',false,'',bin2hex(random_bytes(24)));
update_option('active_plugins',['wp-mcp-fator3/wp-mcp-fator3.php']);update_option('f3_mcp_files_enabled',true);update_option('f3_mcp_database_writes_enabled',true);
echo 'Synthetic WordPress initialized.'."\n";
