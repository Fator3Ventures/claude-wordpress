<?php
/** Functional loopback regression. CLI HTTP server is NOT the Apache acceptance gate. */
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\Probe;
use Fator3\McpFiles\PackageService;
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'database_write'=>true,'roots'=>[ABSPATH,dirname(ABSPATH)],'allow_backup_export'=>true,'time'=>time()]);
require_once ABSPATH.'wp-admin/includes/plugin.php';
$results=[];$failures=0;
function check($name,$ok,$detail=[]){global $results,$failures;$results[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function call_ability($name,$args){$r=wp_get_ability($name)->execute($args);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
$dir=(getenv('F3_FIXTURE_ROOT')?:dirname(__DIR__,3).'/lab').'/fixtures';$plugin='f3-synthetic-package/f3-synthetic-package.php';
deactivate_plugins($plugin,true);if(is_dir(WP_PLUGIN_DIR.'/f3-synthetic-package'))Fator3\RecoveryV1\Engine::remove(WP_PLUGIN_DIR.'/f3-synthetic-package');wp_clean_plugins_cache(false);
$probe=Probe::run();check('O13 anonymous fresh PHP marker',Fator3\McpFiles\Recovery::verified($probe),$probe);
$bytes=file_get_contents($dir.'/package-1.zip');
$input=['content_base64'=>base64_encode($bytes),'expected_slug'=>'f3-synthetic-package','expected_sha256'=>hash('sha256',$bytes)];
$bad=$input;$bad['expected_sha256']=str_repeat('0',64);$r=call_ability('plugins/upload-base64',$bad);check('O12 ZIP digest mismatch no install',($r['error_code']??'')==='package_hash_conflict'&&!file_exists(WP_PLUGIN_DIR.'/'.$plugin),$r);
$r=call_ability('plugins/upload-base64',$input);check('F08 omission installs inactive',!empty($r['success'])&&!is_plugin_active($plugin),$r);
$r=call_ability('plugins/upload-base64',$input);check('F08 omission does not overwrite',($r['error_code']??'')==='package_exists',$r);
$a=activate_plugin($plugin,'',false,true);check('fixture original activated',!is_wp_error($a)&&is_plugin_active($plugin),$a);
$bytes=file_get_contents($dir.'/package-2.zip');$input=['content_base64'=>base64_encode($bytes),'expected_slug'=>'f3-synthetic-package','overwrite'=>true];
$r=call_ability('plugins/upload-base64',$input);check('O12 overwrite preserves active with fresh activation',!empty($r['success'])&&!empty($r['active_before'])&&!empty($r['active_after'])&&($r['version']??'')==='0.2.0'&&!empty($r['activation']['fresh_php_request']),$r);
$backup=$r['backup_id']??null;
if($backup){$r=call_ability('plugins/rollback',['backup_id'=>$backup]);check('O12 explicit rollback restores old version and activation',!empty($r['success'])&&($r['version']??'')==='0.1.0'&&!empty($r['active_after']),$r);}
$bytes=file_get_contents($dir.'/package-fatal.zip');$r=call_ability('plugins/upload-base64',['content_base64'=>base64_encode($bytes),'overwrite'=>true]);
check('O12 fatal child activation rolls back in same call',empty($r['success'])&&($r['recovery_status']??'')==='rolled_back'&&($r['version']??'')==='0.1.0'&&!empty($r['active_after']),$r);
$download_url='https://1.1.1.1/f3-synthetic-package.0.2.0.zip';
$zip_bytes=file_get_contents($dir.'/package-2.zip');
$offer=(object)['last_checked'=>time(),'checked'=>[$plugin=>'0.1.0'],'response'=>[$plugin=>(object)['slug'=>'f3-synthetic-package','plugin'=>$plugin,'new_version'=>'0.2.0','package'=>$download_url]]];
$fake_offer=static fn()=>$offer;
$http=static function($pre,$args,$url)use($download_url,$zip_bytes){if($url===$download_url)return ['response'=>['code'=>200,'message'=>'OK'],'headers'=>[],'body'=>$zip_bytes,'cookies'=>[]];if(str_contains($url,'api.wordpress.org'))return new WP_Error('fixture_no_external_network','Synthetic native update offer.');return $pre;};
add_filter('pre_site_transient_update_plugins',$fake_offer);add_filter('pre_http_request',$http,10,3);
try{$r=call_ability('plugins/update',['plugin'=>$plugin]);check('F14 native upgrade reactivates originally active plugin',!empty($r['success'])&&!empty($r['active_before'])&&!empty($r['active_after'])&&($r['old_version']??'')==='0.1.0'&&($r['version']??'')==='0.2.0'&&!empty($r['activation']['independent_worker']),$r);}finally{remove_filter('pre_site_transient_update_plugins',$fake_offer);remove_filter('pre_http_request',$http,10);}
$preloaded=Fator3\McpFiles\SelfUpdate::preload();check('P06 complete private runtime preload',!is_wp_error($preloaded)&&($preloaded['preloaded_private_types']??0)>200,is_wp_error($preloaded)?[$preloaded->get_error_code(),$preloaded->get_error_data()]:$preloaded);
deactivate_plugins($plugin,true);if(is_dir(WP_PLUGIN_DIR.'/f3-synthetic-package'))Fator3\RecoveryV1\Engine::remove(WP_PLUGIN_DIR.'/f3-synthetic-package');wp_clean_plugins_cache(false);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$GLOBALS['wpdb']->db_version(),'transport'=>'PHP development HTTP server; not Apache acceptance','tests'=>count($results),'failures'=>$failures,'results'=>$results];
file_put_contents(dirname(__DIR__,2).'/evidencias/packages-functional.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
