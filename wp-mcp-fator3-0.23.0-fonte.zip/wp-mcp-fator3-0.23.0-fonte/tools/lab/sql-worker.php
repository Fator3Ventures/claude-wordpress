<?php
$config=json_decode(file_get_contents($argv[1]),true);
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);
add_filter('f3_mcp_sql_read_tables',static fn($tables)=>array_merge($tables,[$config['target'],$config['source']]));
if($argv[2]==='mutate'){
    file_put_contents($config['started'],'ready');$ok=$wpdb->query($config['concurrent_sql']);file_put_contents($config['finished'],json_encode(['success'=>$ok!==false]));echo json_encode(['success'=>$ok!==false]);exit($ok===false?1:0);
}
class F3SqlGateWpdb extends wpdb {
    public array $fixture=[];private bool $paused=false;
    public function query($query){$r=parent::query($query);
        if(!$this->paused&&str_contains($query,'SELECT `t`.*')&&str_contains($query,'FOR UPDATE')){
            $this->paused=true;file_put_contents($this->fixture['locked'],'locked');$deadline=microtime(true)+10;
            while(!is_file($this->fixture['release'])){if(microtime(true)>$deadline)throw new RuntimeException('Fixture barrier expired.');usleep(1000);}
        }return $r;
    }
}
$prefix=$wpdb->prefix;$wpdb=new F3SqlGateWpdb(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);$wpdb->set_prefix($prefix);$wpdb->fixture=$config;
$r=wp_get_ability('db/execute')->execute(['sql'=>$config['sql'],'confirm_token'=>$config['confirm_token']]);echo json_encode(is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code()]:['success'=>$r['success']??false,'applied'=>$r['applied']??null,'affected_rows'=>$r['affected_rows']??null,'error_code'=>$r['error_code']??null]);
