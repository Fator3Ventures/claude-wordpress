<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\{Persistence,ConnectionContext,ConnectionsAdmin};use WpMcpUltimate\OAuth\TokenStore;
$file=WP_CONTENT_DIR.'/f3-migration-lab/fixture.php';$state=json_decode(substr(file_get_contents($file),strlen("<?php exit; ?>\n")),true);wp_set_current_user(1);$tests=[];
function verify_migration($name,$passed){global $tests;$tests[]=['name'=>$name,'passed'=>(bool)$passed];}
verify_migration('MCP target installed after baseline',F3_MCP_FILES_VERSION==='0.13.0'&&(int)get_option('f3_mcp_schema_version')===2);
$item=WP_Application_Passwords::get_user_application_password(1,$state['uuid']);do_action('application_password_did_authenticate',wp_get_current_user(),$item);$c=ConnectionContext::get();
verify_migration('Existing native credential receives finite legacy window',($c['profile']??'')==='legacy'&&$c['expires']===(int)get_option('f3_mcp_policy_installed_at')+7*DAY_IN_SECONDS);
$replay=wp_get_ability('content/create-post')->execute($state['input']);verify_migration('Original completed operation replay preserves post identity',is_array($replay)&&!empty($replay['replayed'])&&($replay['id']??0)===$state['post_id']);
$token=TokenStore::get_access_token($state['token']);verify_migration('Original token migrates with exact expiry',is_array($token)&&$token['expires']===$state['expiry']&&!empty($token['legacy']));
TokenStore::get_client($state['client'],false);verify_migration('Original registered client preserved',!empty(Persistence::get('oauth-clients',$state['client'])['legacy']));
ConnectionContext::oauth($token);$oauth=ConnectionContext::get();$r=ConnectionsAdmin::save(['intent'=>'revoke','user_id'=>1,'connection_id'=>$oauth['connection_id']]);verify_migration('Legacy OAuth revocation blocks old transient too',!empty($r['success'])&&TokenStore::get_access_token($state['token'])===null);
verify_migration('Both original and primary REST routes present',isset(rest_get_server()->get_routes()['/mcp/wp-mcp-ultimate'],rest_get_server()->get_routes()['/mcp/wp-mcp-fator3']));
WP_Application_Passwords::delete_application_password(1,$state['uuid']);wp_delete_post($state['post_id'],true);unlink($file);rmdir(dirname($file));
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'from'=>'0.12.1','to'=>F3_MCP_FILES_VERSION,'tests'=>count($tests),'failures'=>count(array_filter($tests,static fn($r)=>!$r['passed'])),'results'=>$tests,'scope'=>'Same local MySQL database, separate original/new PHP processes, synthetic credentials and state. No production connectors.' ];file_put_contents(dirname(__DIR__,2).'/evidencias/migration-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out,JSON_PRETTY_PRINT)."\n";exit($out['failures']?1:0);
