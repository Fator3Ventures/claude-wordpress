<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\StateStore;
use Fator3\McpFiles\StateMaintenance;
use Fator3\McpFiles\ExecutionCoordinator;
use Fator3\McpFiles\ConnectionsAdmin;
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'database_write'=>true,'roots'=>[ABSPATH],'allow_backup_export'=>true,'time'=>time()]);
$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function call($name,$a=[]){$r=wp_get_ability($name)->execute($a);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
$old=time()-100*DAY_IN_SECONDS;$id=bin2hex(random_bytes(12));$count=0;$args=['idempotency_key'=>$id,'path'=>'fixture'];$effect=static function()use(&$count){$count++;return ['success'=>true,'changed'=>true,'synthetic_secret'=>'F3-MAINTENANCE-SECRET'];};
$r=ExecutionCoordinator::once('fixture/once',$args,$effect,$id);$key='integration:user:1:1:fixture/once:'.$id;
$table=Persistence::table('idempotency');$wpdb->query($wpdb->prepare("UPDATE `$table` SET updated_at=%d WHERE record_key=%s",$old,Persistence::hash('idempotency',$key)));
$p=call('system/maintenance',['category'=>'idempotency','older_than_days'=>90]);
check('O08 preview excludes stored result secret',!empty($p['success'])&&$p['selected']>0&&!str_contains(wp_json_encode($p),'F3-MAINTENANCE-SECRET'),$p);
$r=call('system/maintenance',['category'=>'idempotency','dry_run'=>false,'expected_selection_sha256'=>$p['selection_sha256']]);check('O08 compact confirmed selection',!empty($r['success']),$r);
$r=ExecutionCoordinator::once('fixture/once',$args,$effect,$id);check('O08 compacted key cannot repeat effect',($r['error_code']??'')==='idempotency_result_expired'&&$count===1,$r);
$r=ExecutionCoordinator::once('fixture/once',['idempotency_key'=>$id,'path'=>'other'],$effect,$id);check('O08 compacted key still compares fingerprint',($r['error_code']??'')==='idempotency_conflict'&&$count===1,$r);
$r=call('system/maintenance',['category'=>'idempotency','dry_run'=>false,'expected_selection_sha256'=>$p['selection_sha256']]);check('O08 maintenance apply replay',!empty($r['success'])&&!empty($r['replayed']),$r);
$expired=bin2hex(random_bytes(16));$active=bin2hex(random_bytes(16));$uncertain=bin2hex(random_bytes(16));
foreach([$expired=>['pending',time()-1],$active=>['pending',time()+86400],$uncertain=>['finalizing',time()-1]] as $id=>$state){mkdir(StateStore::directory('transfers').'/'.$id,0700);file_put_contents(StateStore::directory('transfers').'/'.$id.'/0.part','synthetic');StateStore::put('uploads',$id,['transfer_id'=>$id,'status'=>$state[0],'connection_id'=>'integration:user:1','user_id'=>1,'path'=>WP_CONTENT_DIR.'/fixture.txt','expires'=>$state[1],'time'=>time(),'parts'=>[],'total_bytes'=>9,'sha256'=>hash('sha256','synthetic')]);}
$p=call('system/maintenance',['category'=>'transfers']);$r=call('system/maintenance',['category'=>'transfers','dry_run'=>false,'expected_selection_sha256'=>$p['selection_sha256']]);
check('O08 abandoned parts cleaned; active and uncertain preserved',!empty($r['success'])&&!is_dir(StateStore::directory('transfers').'/'.$expired)&&is_dir(StateStore::directory('transfers').'/'.$active)&&is_dir(StateStore::directory('transfers').'/'.$uncertain),$r);
foreach([$active,$uncertain] as $id){\Fator3\RecoveryV1\Engine::remove(StateStore::directory('transfers').'/'.$id);Persistence::delete('uploads',$id);}
$marker='F3-AUDIT-MIGRATION-MARKER';$previous=get_option('f3_mcp_files_audit',null);update_option('f3_mcp_files_audit',[['action'=>'read','path'=>'/outside/fixture.log','time'=>'2026-09-01T00:00:00Z','user'=>1,'content'=>$marker]]);Persistence::delete('migration','audit-option');
$r=call('audit/list',['target'=>'/outside/fixture.log']);$r2=call('audit/list',['target'=>'/outside/fixture.log']);check('F07 legacy option migrated once without content',!empty($r['success'])&&count($r['entries'])===1&&count($r2['entries'])===1&&!str_contains(wp_json_encode($r),$marker),$r);
$previous===null?delete_option('f3_mcp_files_audit'):update_option('f3_mcp_files_audit',$previous);
add_filter('wp_is_application_passwords_available', '__return_true');
$created=ConnectionsAdmin::save(['intent'=>'create','user_id'=>1,'label'=>'Synthetic maintenance test','profile'=>'read']);
check('O01 credential issued with selected policy',!empty($created['success'])&&!empty($created['application_password'])&&($created['profile']??'')==='read',array_diff_key($created,['application_password'=>true]));
if(!empty($created['connection_id'])){$r=ConnectionsAdmin::save(['intent'=>'revoke','user_id'=>1,'connection_id'=>$created['connection_id']]);check('O02 revoke only issued credential',!empty($r['success'])&&!\Fator3\McpFiles\ConnectionContext::credential_active($created['connection_id'],1),$r);}
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/maintenance-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
