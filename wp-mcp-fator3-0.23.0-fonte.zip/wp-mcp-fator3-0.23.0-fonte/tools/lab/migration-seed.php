<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
if(F3_MCP_FILES_VERSION!=='0.12.1')throw new RuntimeException('Original stable baseline required.');
wp_set_current_user(1);add_filter('wp_is_application_passwords_available','__return_true');
[$pw,$item]=WP_Application_Passwords::create_new_application_password(1,['name'=>'Synthetic pre-migration connector']);
$items=WP_Application_Passwords::get_user_application_passwords(1);foreach($items as &$entry)if($entry['uuid']===$item['uuid'])$entry['created']=time()-120;unset($entry);update_user_meta(1,'_application_passwords',$items);
$token=bin2hex(random_bytes(32));$client='migration-'.bin2hex(random_bytes(8));
WpMcpUltimate\OAuth\TokenStore::save_client($client,['client_name'=>'Synthetic legacy client','redirect_uris'=>['https://example.invalid/callback'],'created'=>time()]);
WpMcpUltimate\OAuth\TokenStore::store_access_token($token,['user_id'=>1,'client_id'=>$client,'scope'=>'mcp']);
$expiry=(int)get_option('_transient_timeout_f3_mcp_oauth_at_'.hash('sha256',$token));
$input=['title'=>'Synthetic migration content','status'=>'draft','idempotency_key'=>'migration-'.bin2hex(random_bytes(8))];$post=wp_get_ability('content/create-post')->execute($input);
if(is_wp_error($post)||empty($post['id']))throw new RuntimeException('Baseline content fixture failed.');
$dir=WP_CONTENT_DIR.'/f3-migration-lab';wp_mkdir_p($dir);$file=$dir.'/fixture.php';file_put_contents($file,"<?php exit; ?>\n".wp_json_encode(['uuid'=>$item['uuid'],'token'=>$token,'client'=>$client,'expiry'=>$expiry,'input'=>$input,'post_id'=>$post['id']]));chmod($file,0600);
echo 'Original 0.12.1 state and native credential prepared; secrets not exported.' . "\n";
