<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
use WpMcpUltimate\OAuth\TokenStore;
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'time'=>time()]);
$dir=WP_CONTENT_DIR.'/f3-test-concurrency';wp_mkdir_p($dir);chmod($dir,0700);$tests=[];
function race(array $config): array {
    global $dir;$prefix=$dir.'/'.bin2hex(random_bytes(8));$file=$prefix.'.json';$config+=['barrier'=>$prefix.'.go','ready'=>$prefix.'.ready'];file_put_contents($file,json_encode($config));chmod($file,0600);
    $workers=[];$deadline=microtime(true)+12;
    for($i=0;$i<2;$i++){$p=proc_open([PHP_BINARY,...(php_ini_loaded_file()?['-c',php_ini_loaded_file()]:[]),__DIR__.'/concurrent-worker.php',$file,(string)$i],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$workers[]=[$p,$pipes];}
    while(!is_file($config['ready'].'.0')||!is_file($config['ready'].'.1')){if(microtime(true)>$deadline)throw new RuntimeException('Worker readiness timeout');usleep(1000);}
    file_put_contents($config['barrier'],'go');$rows=[];
    foreach($workers as [$p,$pipes]){$output=stream_get_contents($pipes[1]);$error=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($p);$rows[]=json_decode($output,true)??['error_code'=>'worker_failed','exit_code'=>$exit];}
    foreach(glob($prefix.'*') as $path)unlink($path);return $rows;
}
$client='synthetic-concurrency-'.bin2hex(random_bytes(6));TokenStore::save_client($client,['client_name'=>'Synthetic','redirect_uris'=>['https://example.org/callback'],'issuer'=>untrailingslashit(home_url())]);
$verifier=str_repeat('a',64);$challenge=rtrim(strtr(base64_encode(hash('sha256',$verifier,true)),'+/','-_'),'=');$code=TokenStore::generate_token();
TokenStore::store_code($code,['client_id'=>$client,'user_id'=>1,'redirect_uri'=>'https://example.org/callback','code_challenge'=>$challenge,'profile'=>'read','scope'=>'mcp:read']);
$rows=race(['kind'=>'oauth','params'=>['grant_type'=>'authorization_code','client_id'=>$client,'code'=>$code,'code_verifier'=>$verifier,'redirect_uri'=>'https://example.org/callback']]);
$tests[]=['name'=>'F02 two processes consume authorization code once','passed'=>count(array_filter($rows,static fn($r)=>!empty($r['success'])))===1&&count(array_filter($rows,static fn($r)=>($r['error_code']??'')==='invalid_grant'))===1,'results'=>$rows];
$target=$dir.'/race.txt';file_put_contents($target,'original');$rows=race(['kind'=>'file','target'=>$target,'expected'=>hash('sha256','original')]);
$tests[]=['name'=>'C03 shared file CAS across processes','passed'=>count(array_filter($rows,static fn($r)=>!empty($r['success'])))===1&&count(array_filter($rows,static fn($r)=>($r['error_code']??'')==='file_conflict'))===1,'results'=>$rows];
$counter=$dir.'/effects.txt';file_put_contents($counter,'');$rows=race(['kind'=>'once','target'=>$counter,'key'=>bin2hex(random_bytes(16))]);
$tests[]=['name'=>'C05 idempotency one effect across processes','passed'=>file_get_contents($counter)==="effect\n"&&count(array_filter($rows,static fn($r)=>!empty($r['replayed'])))===1,'results'=>$rows];
unlink($target);unlink($counter);rmdir($dir);
$failures=count(array_filter($tests,static fn($r)=>!$r['passed']));$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$GLOBALS['wpdb']->db_version(),'workers'=>'separate PHP CLI processes with readiness barrier; Apache gate pending','tests'=>count($tests),'failures'=>$failures,'results'=>$tests];
file_put_contents(dirname(__DIR__,2).'/evidencias/concurrency-0130.json',json_encode($out,JSON_PRETTY_PRINT));echo json_encode($out,JSON_PRETTY_PRINT)."\n";exit($failures?1:0);
