#!/usr/bin/env python3
"""Convert one recorded invocation into CI process results, without private logs."""
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--invocation', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
invocation = json.loads(args.invocation.read_text())
runs = invocation['suites']
failures = sum(run['exit_code'] != 0 for run in runs)
suite = ET.Element('testsuite', name='Fator3 integration commands', tests=str(len(runs)), failures=str(failures))
properties = ET.SubElement(suite, 'properties')
for name, value in {'transport': invocation['transport'], 'source_tree_sha256': invocation['source_tree_sha256'], 'release_gate_passed': 'false', 'granularity': 'one test case per completed command; detailed assertions are in its JSON evidence'}.items():
    ET.SubElement(properties, 'property', name=name, value=str(value))
for package in invocation.get('packages', {}).get('packages', []):
    ET.SubElement(properties, 'property', name=package['file'] + '.sha256', value=package['sha256'])
for run in runs:
    case = ET.SubElement(suite, 'testcase', classname='fator3.integration', name=run['file'])
    if run['exit_code'] != 0:
        ET.SubElement(case, 'failure', message='Command returned exit code ' + str(run['exit_code']))
ET.indent(suite)
args.out.parent.mkdir(parents=True, exist_ok=True)
ET.ElementTree(suite).write(args.out, encoding='utf-8', xml_declaration=True)
print(json.dumps({'commands': len(runs), 'failures': failures, 'release_gate_passed': False}))
raise SystemExit(bool(failures))
