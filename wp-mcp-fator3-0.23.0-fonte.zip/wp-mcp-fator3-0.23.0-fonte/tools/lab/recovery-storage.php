<?php
/** Real kernel ENOSPC through /dev/full, redirected only for synthetic temporaries. */
namespace Fator3\RecoveryV1 {
    function fopen($path, $mode, ...$args) {
        if (!empty($GLOBALS['f3_fixture_full']) && str_starts_with($path, $GLOBALS['f3_fixture_directory'] . '/') && str_ends_with($path, '.tmp')) {
            \touch($path);
            return \fopen('/dev/full', 'wb');
        }
        return \fopen($path, $mode, ...$args);
    }
}
namespace {
    use Fator3\RecoveryV1\Engine;
    if (PHP_SAPI !== 'cli' || !is_file('/dev/full') && !file_exists('/dev/full')) exit(2);
    define('AUTH_KEY', 'synthetic-recovery-key');
    define('SECURE_AUTH_KEY', 'synthetic-recovery-secondary-key');
    require getenv('F3_TEST_ENGINE') ?: dirname(__DIR__, 2) . '/fontes/wp-mcp-fator3/includes/RecoveryEngine.php';
    $root = sys_get_temp_dir() . '/f3-storage-failure-' . bin2hex(random_bytes(8));
    mkdir($root, 0700);
    $GLOBALS['f3_fixture_directory'] = $root;
    $checks = [];
    $record = static function ($name, $ok) use (&$checks) { $checks[] = ['name' => $name, 'passed' => (bool)$ok]; };
    // Ignore expected OS warnings only in this fault-injection process.
    set_error_handler(static fn() => true);
    try {
        $file = $root . '/target.php';
        file_put_contents($file, 'original');
        $GLOBALS['f3_fixture_full'] = true;
        $threw = false;
        try { Engine::atomic($file, str_repeat('replacement', 10000)); } catch (\Throwable $error) { $threw = true; }
        $record('ENOSPC during temporary write preserves original and removes temporary', $threw && file_get_contents($file) === 'original' && !(glob($root . '/.f3-*.tmp') ?: []));
        $GLOBALS['f3_fixture_full'] = false;
        $id = bin2hex(random_bytes(16));
        $journal = $root . '/' . $id . '.journal.php';
        $preimage = $root . '/' . $id . '.preimage';
        Engine::copy($file, $preimage);
        $before = Engine::digest(Engine::manifest($file));
        file_put_contents($file, 'changed');
        Engine::write($journal, ['id' => $id, 'status' => 'armed', 'target' => $file, 'preimage' => $preimage, 'before_sha256' => $before, 'after_sha256' => Engine::digest(Engine::manifest($file)), 'locks' => [], 'lease_until' => time()-1]);
        $GLOBALS['f3_fixture_full'] = true;
        $escaped = false;
        try { Engine::sweep($root); } catch (\Throwable $error) { $escaped = true; }
        $status = method_exists(Engine::class, 'sweep_status') ? Engine::sweep_status() : [];
        $record('ENOSPC in sentinel bookkeeping does not escape WordPress bootstrap', !$escaped && ($status['status'] ?? '') === 'degraded');
        $record('Recovery journal and original preimage survive failed sweep', (Engine::read($journal)['status'] ?? '') === 'armed' && Engine::digest(Engine::manifest($preimage)) === $before);
        $GLOBALS['f3_fixture_full'] = false;
        Engine::sweep($root);
        $record('A later sweep resumes recovery after storage becomes writable', (Engine::read($journal)['status'] ?? '') === 'rolled_back' && file_get_contents($file) === 'original');
        $record('Recovery diagnostics contain no private path or exception text', !str_contains(json_encode($status), $root) && !isset($status['exception']));
    } finally {
        $GLOBALS['f3_fixture_full'] = false;
        restore_error_handler();
        Engine::remove($root);
    }
    $out = ['php' => PHP_VERSION, 'engine_sha256' => hash_file('sha256', (new \ReflectionClass(Engine::class))->getFileName()), 'scope' => 'Kernel ENOSPC through /dev/full with test-only stream redirection. This is not a full mounted filesystem or Apache test.', 'tests' => count($checks), 'failures' => count(array_filter($checks, static fn($c) => !$c['passed'])), 'results' => $checks];
    file_put_contents(dirname(__DIR__,2) . '/evidencias/recovery-storage-0130.json', json_encode($out, JSON_PRETTY_PRINT) . "\n");
    echo json_encode($out, JSON_PRETTY_PRINT) . "\n";
    exit($out['failures'] ? 1 : 0);
}
