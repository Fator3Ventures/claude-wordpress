<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);$abilities=[];
foreach(wp_get_abilities() as $ability){$meta=$ability->get_meta();if(empty($meta['fator3']['owned'])&&!str_starts_with($ability->get_name(),'wp-mcp-ultimate/'))continue;
 $abilities[$ability->get_name()]=['description'=>$ability->get_description(),'input_schema'=>$ability->get_input_schema(),'output_schema'=>$ability->get_output_schema(),'readonly'=>!empty($meta['annotations']['readonly']),'provider'=>$meta['fator3']['provider']??'wp-mcp-fator3','result_contract'=>$meta['fator3']['result_contract']??null];
}
ksort($abilities);$out=['schema_version'=>1,'package_header_version'=>F3_MCP_FILES_VERSION,'implementation_target'=>'0.14.0','release_gate_passed'=>false,'source'=>'effective_wordpress_ability_registry','abilities'=>$abilities];
file_put_contents(dirname(__DIR__,2).'/docs/CONTRATOS-INSTALADOS.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");echo wp_json_encode(['exported'=>count($abilities)])."\n";
