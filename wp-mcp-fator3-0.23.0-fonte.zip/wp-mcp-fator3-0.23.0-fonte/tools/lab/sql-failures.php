<?php
/** Failure injection uses real MySQL writes; never connects to a production database. */
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\{Persistence,StateStore};
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'database_write'=>true,'roots'=>[ABSPATH],'time'=>time()]);
$tests=[]; $table=$wpdb->prefix.'f3_failure_fixture';
add_filter('f3_mcp_sql_read_tables',static fn($tables)=>array_merge($tables,[$table]));
$wpdb->query("DROP TABLE IF EXISTS `$table`");
$wpdb->query("CREATE TABLE `$table` (id INT PRIMARY KEY,value INT NOT NULL) ENGINE=InnoDB");
$wpdb->query("INSERT INTO `$table` VALUES (1,0)");
function execute_sql($sql,$token=''){ $r=wp_get_ability('db/execute')->execute(['sql'=>$sql]+($token?['confirm_token'=>$token]:[])); return is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code()]:$r; }
function check_sql($name,$ok,$result=[]){global $tests;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:array_intersect_key($result,array_flip(['success','error_code','applied','rolled_back']))];}
foreach(['commit_ack_lost','connection_lost_before_dml','dml_rejected'] as $mode){
    $wpdb->query("UPDATE `$table` SET value=0 WHERE id=1");
    $sql="UPDATE `$table` SET value=value+1 WHERE id=1";
    $p=execute_sql($sql);$token=$p['confirm_token']??'';
    if(!$token)throw new RuntimeException('No preview.');
    $injected=false;
    $filter=static function($query)use($mode,$table,&$injected,$token){
        global $wpdb;
        if($injected)return $query;
        $is_dml=str_starts_with($query,'UPDATE `'.$table.'`');
        if(($mode==='commit_ack_lost'&&$query==='COMMIT')||($mode!=='commit_ack_lost'&&$is_dml)){
            $state=StateStore::get('db-confirmations',$token);
            if(($state['status']??'')!=='running'||empty($state['backup_id']))throw new RuntimeException('Token not consumed before mutation.');
            $injected=true;
            if($mode==='commit_ack_lost'){
                // Commit on the actual server, then discard its successful acknowledgement
                // from the code under test. This models uncertainty, not a network proxy test.
                mysqli_query($wpdb->dbh,'COMMIT');$kill=new wpdb(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);$kill->query('KILL CONNECTION '.mysqli_thread_id($wpdb->dbh));return '';
            }
            if($mode==='connection_lost_before_dml'){$kill=new wpdb(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);$kill->query('KILL CONNECTION '.mysqli_thread_id($wpdb->dbh));return $query;}
            return '';
        }
        return $query;
    };
    add_filter('query',$filter,PHP_INT_MAX);
    $r=execute_sql($sql,$token);remove_filter('query',$filter,PHP_INT_MAX);
    // wpdb can reconnect for later reads; the pinned DML cannot reconnect/replay.
    $wpdb->check_connection(false);
    $value=(int)$wpdb->get_var("SELECT value FROM `$table` WHERE id=1");
    $state=StateStore::get('db-confirmations',$token);
    $again=execute_sql($sql,$token);
    check_sql($mode.' injected at real transaction',$injected);
    if($mode==='commit_ack_lost'){
        check_sql('lost acknowledgement retains durable consumption',($r['error_code']??'')==='transaction_commit_uncertain'&&array_key_exists('applied',$r)&&$r['applied']===null&&$value===1&&($state['status']??'')==='running',$r);
        check_sql('uncertain COMMIT cannot repeat increment',($again['error_code']??'')==='confirmation_uncertain'&&(int)$wpdb->get_var("SELECT value FROM `$table` WHERE id=1")===1,$again);
    }elseif($mode==='connection_lost_before_dml'){
        check_sql('disconnected DML is never replayed in autocommit',empty($r['success'])&&$value===0&&($state['status']??'')!=='pending',$r);
        check_sql('disconnected token remains consumed',empty($again['success'])&&(int)$wpdb->get_var("SELECT value FROM `$table` WHERE id=1")===0,$again);
    }else{
        check_sql('rejected DML rolls back and records outcome',($r['error_code']??'')==='sql_write_failed'&&!empty($r['rolled_back'])&&$value===0&&($state['status']??'')==='complete',$r);
        check_sql('rolled back token replays recorded refusal',!empty($again['replayed'])&&($again['error_code']??'')==='sql_write_failed',$again);
    }
}
foreach (['lock_timeout','deadlock'] as $mode) {
    $wpdb->query("DELETE FROM `$table`");
    $values=[];for($i=1;$i<=50;$i++)$values[]="($i,0)";
    $wpdb->query("INSERT INTO `$table` VALUES ".implode(',',$values));
    $sql="UPDATE `$table` SET value=value+1 WHERE id<=2";
    $p=execute_sql($sql);$token=$p['confirm_token'];
    $other=new wpdb(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);
    $other->query('START TRANSACTION');$other->query("UPDATE `$table` SET value=100 WHERE id>=2");
    $injected=false;$async=false;
    $filter=static function($query)use($table,$mode,$other,&$injected,&$async){
        global $wpdb;
        if(!$injected&&str_contains($query,"FROM `$table`")&&str_contains($query,'FOR UPDATE')) {
            $injected=true;
            if($mode==='lock_timeout')mysqli_query($wpdb->dbh,'SET SESSION innodb_lock_wait_timeout=1');
            else {
                mysqli_query($wpdb->dbh,"SELECT * FROM `$table` WHERE id=1 FOR UPDATE");
                $async=mysqli_query($other->dbh,"UPDATE `$table` SET value=100 WHERE id=1",MYSQLI_ASYNC);
            }
        }
        return $query;
    };
    add_filter('query',$filter,PHP_INT_MAX);$r=execute_sql($sql,$token);remove_filter('query',$filter,PHP_INT_MAX);
    if($async){$read=[$other->dbh];$error=$reject=[];if(mysqli_poll($read,$error,$reject,3)>0)mysqli_reap_async_query($other->dbh);}
    $other->query('ROLLBACK');$other->close();
    $state=StateStore::get('db-confirmations',$token);$again=execute_sql($sql,$token);
    check_sql($mode.' real InnoDB lock conflict rolled back',$injected&&empty($r['success'])&&!empty($r['rolled_back'])&&($r['applied']??null)===false,$r);
    check_sql($mode.' no target effect and no pending token',(int)$wpdb->get_var("SELECT SUM(value) FROM `$table`")===0&&($state['status']??'')==='running');
    check_sql($mode.' confirmation not silently retried',($again['error_code']??'')==='confirmation_uncertain',$again);
}
$wpdb->query("DROP TABLE `$table`");
$failures=count(array_filter($tests,static fn($t)=>!$t['passed']));
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'scope'=>'Real MySQL transactions with deterministic query-boundary fault injection; COMMIT acknowledgement discarded by fixture, not network-proxy packet loss.','tests'=>count($tests),'failures'=>$failures,'results'=>$tests];
file_put_contents(dirname(__DIR__,2).'/evidencias/sql-failures-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out,JSON_PRETTY_PRINT)."\n";exit($failures?1:0);
