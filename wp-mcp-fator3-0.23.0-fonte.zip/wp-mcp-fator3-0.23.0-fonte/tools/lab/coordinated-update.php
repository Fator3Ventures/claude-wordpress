<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\{Persistence,UpdateChannel};
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'time'=>time()]);
require_once ABSPATH.'wp-admin/includes/plugin.php';$original=get_option('f3_mcp_update_channels',[]);$tests=[];$initial=get_plugins();echo wp_json_encode(['before'=>array_map(static fn($p)=>$p['Version'],array_intersect_key($initial,array_flip(['base-site-core-fator3/base-site-core-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php'])))])."\n";
foreach(['base-site-core-fator3'=>['1.17.0','1.17.1'],'wp-mcp-google-fator3'=>['0.4.0','0.4.1']]as $slug=>[$before,$after]){
 $entry=$slug.'/'.$slug.'.php';$zip=dirname(__DIR__,2).'/dist/review/'.$slug.'-'.$after.'.nao-homologado.zip';$bytes=file_get_contents($zip);
 $feed='https://1.1.1.1/'.$slug.'/manifest.json';$url='https://1.1.1.1/'.$slug.'.zip';
 $manifest=['schema_version'=>1,'package'=>$slug,'plugin'=>$entry,'version'=>$after,'url'=>$url,'sha256'=>hash('sha256',$bytes),'requires'=>['wordpress'=>'7.1.2','php'=>'8.3.30'],'tested'=>['wordpress'=>'7.1.2','php'=>'8.3.30','evidence'=>'synthetic-lab']];
 update_option('f3_mcp_update_channels',[$slug=>['url'=>$feed,'package_hosts'=>[]]]);
 $offer=(object)['last_checked'=>time(),'checked'=>[$entry=>$before],'response'=>[$entry=>(object)['slug'=>$slug,'plugin'=>$entry,'new_version'=>$after,'package'=>$url,'f3_sha256'=>$manifest['sha256']]]];
 $offering=static fn()=>$offer;$http=static function($pre,$args,$target)use($feed,$url,$manifest,$bytes){if($target===$feed||$target===$url)return ['response'=>['code'=>200,'message'=>'OK'],'headers'=>['content-type'=>'application/json'],'body'=>$target===$feed?wp_json_encode($manifest):$bytes,'cookies'=>[]];if(str_contains($target,'api.wordpress.org'))return new WP_Error('fixture_no_network','No external network.');return $pre;};
 add_filter('pre_site_transient_update_plugins',$offering);add_filter('pre_http_request',$http,10,3);
 try{
  $r=wp_get_ability('plugins/update')->execute(['plugin'=>$entry]);
  $tests[]=['name'=>$slug.' update from '.$before.' to '.$after,'passed'=>is_array($r)&&!empty($r['success'])&&($r['old_version']??'')===$before&&($r['version']??'')===$after&&!empty($r['active_before'])&&!empty($r['active_after'])&&!empty($r['activation']['independent_worker']),'detail'=>is_array($r)?array_intersect_key($r,array_flip(['success','error_code','old_version','version','active_before','active_after','activation','changed','upgrader_error_code'])):[]];
 }finally{remove_filter('pre_site_transient_update_plugins',$offering);remove_filter('pre_http_request',$http,10);}
}
update_option('f3_mcp_update_channels',$original);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'scope'=>'Complete original companion packages to new compatibility packages using journaled updater, independent activation and anonymous probes. Native offers and HTTP downloads are synthetic.','tests'=>count($tests),'failures'=>count(array_filter($tests,static fn($r)=>!$r['passed'])),'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/coordinated-update-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out,JSON_PRETTY_PRINT)."\n";exit($out['failures']?1:0);
