<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);
$server=rest_get_server();
function request($route,$method,$params=[],$version='2026-07-28',$extra=[]) {
 $r=new WP_REST_Request('POST',$route);$r->set_header('content-type','application/json');$r->set_header('accept','application/json, text/event-stream');
 $r->set_header('mcp-protocol-version',$version);$r->set_header('mcp-method',$method);foreach($extra as $key=>$value)$r->set_header($key,$value);
 if($version==='2026-07-28')$params['_meta']=['io.modelcontextprotocol/protocolVersion'=>$version,'io.modelcontextprotocol/clientCapabilities'=>new stdClass()];
 $r->set_body(wp_json_encode(['jsonrpc'=>'2.0','id'=>'test-id','method'=>$method,'params'=>$params?:new stdClass()]));
 $v=rest_do_request($r);return ['status'=>$v->get_status(),'headers'=>$v->get_headers(),'body'=>json_decode(wp_json_encode($v->get_data()),true)];
}
$out=[];foreach(['/mcp/wp-mcp-fator3','/mcp/wp-mcp-ultimate'] as $route) {
 foreach(['server/discover','tools/list'] as $method)$out[$route][$method]=request($route,$method);
 $out[$route]['unknown']=request($route,'tools/list',[],'2099-01-01');
 $init=request($route,'initialize',['protocolVersion'=>'2025-06-18','capabilities'=>new stdClass(),'clientInfo'=>['name'=>'synthetic-lab','version'=>'1']],'2025-06-18');$out[$route]['legacy_initialize']=$init;
 $headers=array_change_key_case($init['headers']);$session=$headers['mcp-session-id']??'';
 if($session)$out[$route]['legacy_list']=request($route,'tools/list',[],'2025-06-18',['Mcp-Session-Id'=>$session]);
}
file_put_contents(dirname(__DIR__,2).'/evidencias/wire-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
foreach($out as $route=>$methods)foreach($methods as $method=>$row)echo wp_json_encode(['route'=>$route,'method'=>$method,'status'=>$row['status'],'error'=>$row['body']['error']??null,'result_keys'=>array_keys($row['body']['result']??[])])."\n";

$failures=[];
foreach($out as $route=>$methods) {
 foreach(['server/discover','tools/list','legacy_initialize','legacy_list'] as $name)if(($methods[$name]['status']??0)!==200)$failures[]=$route.' '.$name;
 if(($methods['unknown']['body']['error']['code']??null)!==-32022)$failures[]=$route.' unsupported version';
}
if($failures){fwrite(STDERR,wp_json_encode(['wire_failures'=>$failures])."\n");exit(1);}
