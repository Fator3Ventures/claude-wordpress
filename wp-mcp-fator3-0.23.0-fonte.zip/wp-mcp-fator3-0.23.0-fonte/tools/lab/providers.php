<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;use Fator3\McpFiles\ExtensionContract;use Fator3\McpFiles\ResourceMetadata;use Fator3\McpFiles\UpdateChannel;
wp_set_current_user(1);$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function profile($profile){Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>$profile,'status'=>'active','policy_version'=>1,'time'=>time()]);}
check('C06 explicit provider registration',ExtensionContract::register('synthetic-provider','1.2.3',['synthetic/'])===true);
$r=ExtensionContract::register('other-provider','1.0.0',['synthetic/']);check('C06 prefix ownership conflict',is_wp_error($r)&&$r->get_error_code()==='provider_prefix_conflict');
// Register only inside the native registration hook, as required by WordPress.
add_action('wp_abilities_api_init',static function(){
    foreach(['read'=>true,'write'=>false] as $op=>$read)wp_register_ability('synthetic/'.$op,['label'=>'Synthetic '.$op,'description'=>'Fixture for provider policy.','category'=>'site','input_schema'=>['type'=>'object','properties'=>[]],'output_schema'=>['type'=>'object'],'permission_callback'=>'__return_true','execute_callback'=>static fn()=>['ok'=>true],'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>$read],'fator3'=>['provider'=>'synthetic-provider','version'=>'1.2.3','policy_contract'=>1]]]);
});
// The first retrieval initializes all providers in this process.
profile('read');$read=wp_get_ability('synthetic/read');$write=wp_get_ability('synthetic/write');
check('C06 read callback retains provider fields and adds result contract',$read&&($r=$read->execute([]))&&($r['ok']??false)&&($r['result_contract']??0)===2,is_wp_error($r??null)?'WP_Error':($r??null));
$r=$write?$write->execute([]):[];check('C02 decorated provider denies indirect mutation under read profile',($r['error_code']??'')==='profile_denied',$r);
profile('maintenance');$r=$write?$write->execute([]):[];check('C06 native permission plus maintenance allows mutation',!empty($r['success']),$r);
$meta=['mcp'=>['type'=>'resource','uri'=>'elementor://style/best-practices','mimeType'=>'text/markdown']];check('F16 nested resource URI and MIME',ResourceMetadata::uri($meta)==='elementor://style/best-practices'&&ResourceMetadata::mime($meta)==='text/markdown');
check('F16 top-level legacy fallback',ResourceMetadata::uri(['uri'=>'fixture://legacy'])==='fixture://legacy');
$logged=0;$name='fixture/resource-'.bin2hex(random_bytes(4));for($i=0;$i<3;$i++)ResourceMetadata::log_once($name,'resource_uri_not_found',static function()use(&$logged){$logged++;});check('F16 once per catalog marker',$logged===1);
$manifest=['schema_version'=>1,'package'=>'wp-mcp-fator3','plugin'=>UpdateChannel::PACKAGES['wp-mcp-fator3'],'version'=>'0.13.0','url'=>'https://updates.example.org/mcp.zip','sha256'=>str_repeat('a',64),'requires'=>['wordpress'=>'7.1.2','php'=>'8.3.30','plugins'=>[]],'tested'=>['wordpress'=>'7.1.2','php'=>'8.3.30','evidence'=>'synthetic-test-only']];
check('O14 typed manifest validates explicit identity',is_array(UpdateChannel::validate($manifest,'wp-mcp-fator3',['updates.example.org'])));
$bad=$manifest;$bad['url']='http://updates.example.org/mcp.zip';$r=UpdateChannel::validate($bad,'wp-mcp-fator3',['updates.example.org']);check('O14 HTTP package forbidden',is_wp_error($r)&&$r->get_error_code()==='manifest_origin_invalid');
$bad=$manifest;$bad['plugin']='other/other.php';$r=UpdateChannel::validate($bad,'wp-mcp-fator3',['updates.example.org']);check('O14 identity mismatch forbidden',is_wp_error($r)&&$r->get_error_code()==='manifest_identity_invalid');
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$GLOBALS['wpdb']->db_version(),'tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/providers-0130.json',json_encode($out,JSON_PRETTY_PRINT));echo json_encode($out,JSON_PRETTY_PRINT)."\n";exit($failures?1:0);
