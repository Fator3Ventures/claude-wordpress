"""Run cooperating lab processes in one execution/network context; never expose MySQL externally."""
from pathlib import Path
import os,subprocess,socket,time,sys,json,hashlib
base=Path(os.environ.get('F3_LAB_ROOT','/workspace/scratch/d7106ddbcd96/implementacao-0130'))
runtime=base/'dependencies/lab-runtime/usr';lab=base/'lab'
if os.environ.get('F3_LAB_ISOLATED')=='1':
 import tempfile,shutil
 template=lab;lab=Path(tempfile.mkdtemp(prefix='f3-mcp-lab-',dir='/tmp'))
 shutil.copytree(template/'wordpress',lab/'wordpress',symlinks=True)
 shutil.copytree(template/'fixtures',lab/'fixtures')
 (lab/'mysql-files').mkdir(mode=0o700)
 for name in ['000-f3-mcp-recovery.php','f3-mcp-recovery-runtime-v1.php']:
  (lab/'wordpress/wp-content/mu-plugins'/name).unlink(missing_ok=True)
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(runtime/'lib/x86_64-linux-gnu');env['F3_WP_ROOT']=str(lab/'wordpress/wp-load.php');env['F3_FIXTURE_ROOT']=str(lab)
args=[str(runtime/'sbin/mysqld'),'--no-defaults','--user=root','--basedir='+str(runtime),'--datadir='+str(lab/'mysql'),'--socket=','--bind-address=127.0.0.1','--port=18316','--pid-file='+str(lab/'mysql.pid'),'--mysqlx=0','--secure-file-priv='+str(lab/'mysql-files'),'--log-error='+str(lab/'mysql-run.log')]
if os.environ.get('F3_RESET_LAB')=='1':
 import shutil
 if (lab/'mysql').exists():shutil.rmtree(lab/'mysql')
 for name in ['f3-mcp-private','f3-mcp-backups']:
  state_path=lab/'wordpress/wp-content'/name
  if state_path.is_dir():shutil.rmtree(state_path)
 for transient in (lab/'wordpress/wp-content/plugins').glob('.f3-*'):
  if transient.is_dir():shutil.rmtree(transient)
 (lab/'mysql').mkdir(mode=0o700)
 with open(lab/'mysql-initialize.log','w') as logfile:
  subprocess.run([str(runtime/'sbin/mysqld'),'--no-defaults','--initialize-insecure','--user=root','--basedir='+str(runtime),'--datadir='+str(lab/'mysql')],env=env,stdout=logfile,stderr=subprocess.STDOUT,check=True)
server=subprocess.Popen(args,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
php=os.environ.get('F3_PHP','/workspace/scratch/d7106ddbcd96/release-0121/runtime/usr/bin/php8.3')
ini=os.environ.get('F3_PHP_INI','/workspace/scratch/d7106ddbcd96/release-0121/php.ini')
web=None
import shutil,zipfile
project=Path(__file__).resolve().parents[2]
source=project/'fontes/wp-mcp-fator3'
package_report=None
if os.environ.get('F3_PACKAGE_TEST')=='1':
 if any(os.environ.get(flag)=='1' for flag in ['F3_BASELINE_TEST','F3_UPGRADE_BASELINE','F3_COMPANION_BASELINE']):raise RuntimeError('Package regression cannot also select an old baseline.')
 package_report=json.loads((project/'dist/review/packages.json').read_text())
if os.environ.get('F3_BASELINE_TEST')=='1' or os.environ.get('F3_UPGRADE_BASELINE')=='1':source=Path(os.environ.get('F3_BASELINE_PATH',str(project.parent/'bases/0121/wp-mcp-fator3')))
if not (lab/'wordpress/wp-config.php').is_file():raise RuntimeError('Existing disposable lab required.')
for slug in ['wp-mcp-fator3','base-site-core-fator3','wp-mcp-google-fator3']:
 origin=source if slug=='wp-mcp-fator3'else project/'fontes'/slug
 if os.environ.get('F3_COMPANION_BASELINE')=='1' and slug=='base-site-core-fator3':origin=base/'dependencies/companions/base-site-core-fator3-1.17.0/base-site-core-fator3'
 if os.environ.get('F3_COMPANION_BASELINE')=='1' and slug=='wp-mcp-google-fator3':origin=base/'dependencies/companions/wp-mcp-google-fator3-src-0.4.0/wp-mcp-google-fator3-src-0.4.0/wp-mcp-google-fator3'
 target=lab/'wordpress/wp-content/plugins'/slug
 if target.is_symlink():target.unlink()
 elif target.is_dir():shutil.rmtree(target)
 if package_report:
  package=next((p for p in package_report['packages'] if p['package']==slug),None)
  if package is None:
   shutil.copytree(origin,target)
   continue
  archive=project/'dist/review'/package['file']
  if hashlib.sha256(archive.read_bytes()).hexdigest()!=package['sha256']:raise RuntimeError('Package digest mismatch: '+slug)
  with zipfile.ZipFile(archive) as z:
   if any(not name.startswith(slug+'/') or '..' in Path(name).parts or name.startswith('/') for name in z.namelist()):raise RuntimeError('Invalid package root: '+slug)
   z.extractall(target.parent)
 else:shutil.copytree(origin,target)
target=lab/'wordpress/wp-content/plugins/wp-mcp-fator3'
if package_report:source=target
env['F3_TEST_ENGINE']=str(target/'includes/RecoveryEngine.php')
snapshot=hashlib.sha256()
for path in sorted(target.rglob('*')):
 if path.is_file():snapshot.update(path.relative_to(target).as_posix().encode()+b'\0'+hashlib.sha256(path.read_bytes()).digest())
invocation={'source_tree_sha256':snapshot.hexdigest(),'transport':'PHP development HTTP server' if os.environ.get('F3_HTTP_TESTS')=='1' else 'CLI','started_at':int(time.time()),'suites':[]}
if package_report:invocation['packages']=package_report
# Every invocation executes an immutable copy of the current source, not a stale self-update fixture.
if os.environ.get('F3_SELF_UPDATE_TEST') == '1':
 for version,fatal in [('0.14.0-lab1',False),('0.14.0-lab2',True)]:
  with zipfile.ZipFile(lab/('self-'+version+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
   for path in sorted(source.rglob('*')):
    if not path.is_file():continue
    data=path.read_bytes();relative=path.relative_to(source).as_posix()
    if relative=='wp-mcp-fator3.php':
     import re
     data=re.sub(rb'(Version:\s+)[^\s]+',lambda m:m[1]+version.encode(),data,count=1)
     data=re.sub(rb"('F3_MCP_FILES_VERSION', ')[^']+",lambda m:m[1]+version.encode(),data,count=1)
     if fatal:data+=b'\n'+bytes([92])+b'f3_synthetic_missing_function_for_recovery();\n'
    z.writestr('wp-mcp-fator3/'+relative,data)

if os.environ.get('F3_BASELINE_TEST')=='1':
 report=json.loads((project/'dist/review/packages.json').read_text())
 item=next(p for p in report['packages'] if p['package']=='wp-mcp-fator3')
 with zipfile.ZipFile(project/'dist/review'/item['file']) as original,zipfile.ZipFile(lab/'migration-fatal.zip','w',zipfile.ZIP_DEFLATED) as bad:
  for info in original.infolist():
   data=original.read(info.filename)
   if info.filename=='wp-mcp-fator3/wp-mcp-fator3.php':data+=b'\n'+bytes([92])+b'f3_synthetic_fatal_migration();\n'
   bad.writestr(info,data)

# The lab deploys the latest independent runtime before boot, without changing production files.
sentinel=lab/'wordpress/wp-content/mu-plugins/f3-mcp-recovery-runtime-v1.php'
if sentinel.is_file():
 import shutil
 shutil.copyfile(Path(__file__).resolve().parents[2]/'fontes/wp-mcp-fator3/includes/RecoveryEngine.php',sentinel)
try:
 ready=False
 for _ in range(100):
  if server.poll() is not None:raise RuntimeError('MySQL exited; inspect mysql-run.log')
  try:
   with socket.create_connection(('127.0.0.1',18316),.1):ready=True;break
  except OSError:time.sleep(.05)
 if not ready:raise RuntimeError('MySQL startup timed out')
 if os.environ.get('F3_RESET_LAB')=='1':
  subprocess.run([php,'-c',ini,str(Path(__file__).with_name('reset.php'))],env=env,check=True)
 if os.environ.get('F3_HTTP_TESTS')=='1':
  webenv=env.copy();webenv['PHP_CLI_SERVER_WORKERS']='4'
  web=subprocess.Popen([php,'-c',ini,'-S','127.0.0.1:18093','-t',str(lab/'wordpress'),str(Path(__file__).resolve().parent/'router.php')],env=webenv,stdout=open(lab/'http-test.log','w'),stderr=subprocess.STDOUT,start_new_session=True)
  for _ in range(100):
   try:
    with socket.create_connection(('127.0.0.1',18093),.1):break
   except OSError:time.sleep(.05)
 suite_failed=False
 for file in sys.argv[1:]:
  if os.environ.get('F3_UPGRADE_BASELINE')=='1' and Path(file).name=='migration-upgrade.php':
   upgrade_next=target.parent/'f3-lab-upgrade-next';upgrade_old=target.parent/'f3-lab-upgrade-old'
   if upgrade_next.exists():shutil.rmtree(upgrade_next)
   if upgrade_old.exists():shutil.rmtree(upgrade_old)
   shutil.copytree(project/'fontes/wp-mcp-fator3',upgrade_next)
   target.rename(upgrade_old);upgrade_next.rename(target)
   shutil.rmtree(upgrade_old)
   invocation['migration_to_source']=True
  extra=['-d','opcache.enable_cli=1','-d','opcache.validate_timestamps=0','-d','opcache.file_update_protection=0'] if Path(file).name=='opcache-recovery.php' else []
  p=subprocess.run([php,'-c',ini,*extra,file],env=env,text=True,capture_output=True)
  print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
  invocation['suites'].append({'file':file,'sha256':hashlib.sha256(Path(file).read_bytes()).hexdigest(),'exit_code':p.returncode})
  evidence=Path(__file__).resolve().parents[2]/'evidencias';history=evidence/'invocations';history.mkdir(exist_ok=True)
  serialized=json.dumps(invocation,indent=2)+'\n'
  (evidence/'local-invocation-latest.json').write_text(serialized)
  (history/(str(invocation['started_at'])+'-'+invocation['source_tree_sha256'][:12]+'.json')).write_text(serialized)
  if p.returncode:
   suite_failed=True
   if os.environ.get('F3_CONTINUE_TESTS')!='1':sys.exit(p.returncode)
 if suite_failed:sys.exit(1)
finally:
 if web is not None:
  import signal
  os.killpg(web.pid,signal.SIGTERM);web.wait(timeout=5)
 server.terminate()
 try:server.wait(timeout=8)
 except subprocess.TimeoutExpired:server.kill();server.wait()
 if os.environ.get('F3_LAB_ISOLATED')=='1':
  for name in ['mysql-run.log','http-test.log']:
   if (lab/name).is_file():shutil.copyfile(lab/name,base/'dependencies'/('isolated-'+name))
  debug=lab/'wordpress/wp-content/debug.log'
  if debug.is_file():shutil.copyfile(debug,base/'dependencies/isolated-wordpress-debug.log')
  shutil.rmtree(lab)
