<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Recovery;use Fator3\McpFiles\Locks;use Fator3\RecoveryV1\Engine;
wp_set_current_user(1);$target=$argv[1];$candidate=$argv[2];$barrier=$argv[3];$phase=$argv[4];
Locks::trees([dirname($target)],static function()use($target,$candidate,$barrier,$phase){
 $op=Recovery::begin($target,Engine::digest(Engine::manifest($candidate)),['lock_root'=>dirname($target),'plugin'=>'f3-crash-fixture/plugin.php','active_before'=>false]);
 Engine::prepare_install($op['file'],$candidate);
 if($phase==='gap'){$s=Engine::read($op['file']);$s['install_phase']='switching';Engine::write($op['file'],$s);rename($s['target'],$s['install_previous']);}
 elseif($phase==='installed')Engine::commit_install($op['file']);
 file_put_contents($barrier,json_encode(['journal'=>$op['file'],'id'=>$op['state']['id']]));
 // Parent kills this process at a deterministic filesystem transition, with its lease held.
 while(true)usleep(10000);
});
