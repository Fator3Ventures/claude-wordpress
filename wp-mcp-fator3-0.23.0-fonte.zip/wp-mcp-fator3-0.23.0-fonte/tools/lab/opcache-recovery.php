<?php
/** Exercises actual OPcache in one PHP process; Apache pool acceptance remains separate. */
use Fator3\RecoveryV1\Engine;
if(PHP_SAPI!=='cli'||!function_exists('opcache_get_status')||!opcache_get_status(false))throw new RuntimeException('Run with OPcache enabled for CLI, validate_timestamps=0 and file_update_protection=0.');
define('AUTH_KEY','synthetic-opcache-primary');define('SECURE_AUTH_KEY','synthetic-opcache-secondary');
require getenv('F3_TEST_ENGINE')?:dirname(__DIR__,2).'/fontes/wp-mcp-fator3/includes/RecoveryEngine.php';
$root=sys_get_temp_dir().'/f3-opcache-'.bin2hex(random_bytes(8));mkdir($root,0700);$checks=[];
function check($name,$passed){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$passed];}
function run_fixture($file){return include $file;}
try{
    $file=$root.'/atomic.php';file_put_contents($file,"<?php return 'before';");
    opcache_compile_file($file);check('OPcache fixture is warm',run_fixture($file)==='before'&&opcache_is_script_cached($file));
    Engine::atomic($file,"<?php return 'after';");check('Atomic replacement invalidates cached bytes',run_fixture($file)==='after');
    $target=$root.'/plugin';$source=$root.'/candidate';mkdir($target);mkdir($source);
    file_put_contents($target.'/main.php',"<?php return 'old-main';");file_put_contents($target.'/removed.php',"<?php return 'old-removed';");
    file_put_contents($source.'/main.php',"<?php return 'new-main';");file_put_contents($source.'/added.php',"<?php return 'new-added';");
    opcache_compile_file($target.'/main.php');opcache_compile_file($target.'/removed.php');
    $id=bin2hex(random_bytes(16));$journal=$root.'/'.$id.'.journal.php';$before=Engine::manifest($target);$after=Engine::manifest($source);$preimage=$root.'/'.$id.'.preimage';Engine::copy($target,$preimage);
    Engine::write($journal,['id'=>$id,'status'=>'armed','plugin'=>'fixture/main.php','target'=>$target,'preimage'=>$preimage,'before_sha256'=>Engine::digest($before),'after_sha256'=>Engine::digest($after),'locks'=>[],'lease_until'=>time()-1]);
    Engine::prepare_install($journal,$source);Engine::commit_install($journal);
    check('Package switch executes new main bytes',run_fixture($target.'/main.php')==='new-main');
    set_error_handler(static fn()=>true);
    try{$missing=run_fixture($target.'/removed.php');}finally{restore_error_handler();}
    check('Removed package script cannot execute stale cached bytes',$missing===false);
    opcache_compile_file($target.'/added.php');check('New package script is warm',run_fixture($target.'/added.php')==='new-added'&&opcache_is_script_cached($target.'/added.php'));
    $restored=Engine::restore($journal,true);check('Rollback restores original PHP bytes',($restored['status']??'')==='rolled_back'&&run_fixture($target.'/main.php')==='old-main'&&run_fixture($target.'/removed.php')==='old-removed');
    set_error_handler(static fn()=>true);
    try{$missing=run_fixture($target.'/added.php');}finally{restore_error_handler();}
    check('Rollback removes cached new-only script',$missing===false);
}finally{Engine::remove($root);}
$out=['php'=>PHP_VERSION,'engine_sha256'=>hash_file('sha256',(new ReflectionClass(Engine::class))->getFileName()),'sapi'=>PHP_SAPI,'opcache_version'=>phpversion('Zend OPcache'),'validate_timestamps'=>ini_get('opcache.validate_timestamps'),'scope'=>'Real OPcache in one CLI process; does not establish Apache/FPM pool or hosting acceptance.','tests'=>count($checks),'failures'=>count(array_filter($checks,static fn($r)=>!$r['passed'])),'results'=>$checks];
file_put_contents(dirname(__DIR__,2).'/evidencias/opcache-recovery-0130.json',json_encode($out,JSON_PRETTY_PRINT)."\n");echo json_encode($out,JSON_PRETTY_PRINT)."\n";exit($out['failures']?1:0);
