<?php
require getenv('F3_WP_ROOT');
add_action('f3_mcp_query_snapshot_ready',static function($id){file_put_contents($GLOBALS['argv'][2],$id);$end=microtime(true)+20;while(!is_file($GLOBALS['argv'][2].'.go')&&microtime(true)<$end)usleep(10000);});
\Fator3\McpFiles\QueryExports::worker($argv[1]);
