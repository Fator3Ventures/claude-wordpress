<?php
/** Contract regressions against real WordPress and MySQL, using synthetic data only. */
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\ConnectionContext;
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'database_write'=>true,'roots'=>[ABSPATH,dirname(ABSPATH)],'allow_backup_export'=>true,'time'=>time()]);
$tests=[];$fail=0;
function check($label,$condition,$detail=null) {global $tests,$fail;$tests[]=['name'=>$label,'passed'=>(bool)$condition,'detail'=>$condition?null:$detail];if(!$condition)$fail++;}
function ability($name,$args=[]) { $a=wp_get_ability($name);if(!$a)return ['error_code'=>'ability_missing'];$r=$a->execute($args);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r; }
$maintenance=Persistence::get('connections','integration:user:1');$restricted=$maintenance;$restricted['profile']='custom';$restricted['abilities']=['db/query'];Persistence::put('connections','integration:user:1',$restricted);
$a=ability('db/query',['sql'=>'SELECT user_pass FROM f3t_users']);check('F01 direct users denied',($a['error_code']??'')==='sql_source_forbidden',$a);
foreach(['SELECT COUNT(*) FROM (SELECT * FROM f3t_users) x WHERE user_pass LIKE \'$P%\'','SELECT ID FROM f3t_posts UNION SELECT user_pass FROM f3t_users','SELECT post_password AS secret FROM f3t_posts','SELECT ID FROM f3t_posts ORDER BY post_password'] as $sql) { $r=ability('db/query',['sql'=>$sql]);check('F01 protected influence denied',empty($r['success']),$r); }
$r=ability('db/query',['sql'=>'SELECT ID,post_title FROM f3t_posts ORDER BY ID LIMIT 2']);check('F01 permitted SELECT',!empty($r['success']),$r);
Persistence::put('connections','integration:user:1',$maintenance);
$post=wp_insert_post(wp_slash(['post_title'=>'F3 synthetic','post_content'=>"one --\\path-- one\n",'post_status'=>'draft']),true);
$before=get_post_field('post_content',$post,'raw');$rev=Fator3\McpFiles\ContentTools::revision($post);
$r=ability('content/patch-post',['id'=>$post,'find'=>'one','replace'=>'two','expected_revision'=>$rev]);check('F11 uniqueness rejects ambiguity',empty($r['success'])&&get_post_field('post_content',$post,'raw')===$before,$r);
$r=ability('content/patch-post',['id'=>$post,'find'=>'/one/','replace'=>'two','regex'=>true,'limit'=>1,'expected_revision'=>$rev]);check('F11 regex limit 1',!empty($r['success'])&&substr_count(get_post_field('post_content',$post,'raw'),'two')===1,$r);
$read=ability('content/get-post',['id'=>$post,'fields'=>['id','sha256','revision']]);check('N04 selective read omits content',!empty($read['success'])&&!isset($read['content']),$read);
$page=wp_insert_post(['post_type'=>'page','post_title'=>'F3 page','post_status'=>'draft']);
$r=ability('content/update-page',['id'=>$page,'parent'=>0,'parent_id'=>1]);check('F15 alias conflict',($r['error_code']??'')==='alias_conflict',$r);
$r=ability('content/update-page',['id'=>$page,'parent_id'=>0]);check('F15 parent alias accepted',!empty($r['success']),$r);
update_option('f3_lab_shape',['first'=>false,'nested'=>['synthetic_secret_token'=>'SYNTHETIC_SECRET_DO_NOT_LEAK']]);
$r=ability('options/get',['name'=>'f3_lab_shape','key'=>'first']);check('N05 false is existing key',!empty($r['success']),$r);
$r=ability('options/get',['name'=>'f3_lab_shape','key'=>'nested']);check('N05 nested secret is redacted',strpos(json_encode($r),'SYNTHETIC_SECRET_DO_NOT_LEAK')===false,$r);
$r=ability('options/get',['name'=>'f3_lab_shape','key'=>'absent']);check('N05 missing key distinct',empty($r['success']),$r);
$preview=ability('options/delete',['names'=>['f3_lab_shape']]);check('N08 preview has no values',!empty($preview['preview'])&&strpos(json_encode($preview),'SYNTHETIC_SECRET_DO_NOT_LEAK')===false,$preview);
if(!empty($preview['confirm_token'])) {
 $args=['names'=>['f3_lab_shape'],'confirm_token'=>$preview['confirm_token']];$r=ability('options/delete',$args);check('N08 confirmed native deletion',!empty($r['success'])&&get_option('f3_lab_shape',null)===null,$r);
 $r2=ability('options/delete',$args);check('N08 deletion replay',!empty($r2['replayed']),$r2);
}
$dir=WP_CONTENT_DIR.'/f3-test-fixtures';wp_mkdir_p($dir);$binary="PK\x03\x04\xff\x00".random_bytes(2048);file_put_contents($dir.'/binary.zip',$binary);
$r=ability('files/read',['path'=>$dir.'/binary.zip']);check('F09 binary full read exact',isset($r['content_base64'])&&base64_decode($r['content_base64'],true)===$binary,$r);
$r=ability('files/read',['path'=>$dir.'/binary.zip','offset_bytes'=>6,'byte_limit'=>10]);check('N01 seek arbitrary byte',base64_decode($r['content_base64']??'',true)===substr($binary,6,10),$r);
$r=ability('files/write',['path'=>$dir.'/binary.zip','content'=>'bad']);check('F09 refuses text for binary extension',empty($r['success'])&&file_get_contents($dir.'/binary.zip')===$binary,$r);
file_put_contents($dir.'/log.txt',"hello\nerror marker\n");$r=ability('files/search',['path'=>$dir.'/log.txt','grep'=>'error']);check('F19 single file search',!empty($r['success'])&&!empty($r['matches']),$r);
$r=ability('wp-mcp-ultimate/execute-ability',['ability_name'=>'wp-mcp-ultimate/execute-ability','parameters'=>[]]);check('F10 nested executor refused',empty($r['success']),$r);
$r=ability('wp-mcp-ultimate/discover-abilities',['compact'=>true]);$same=ability('wp-mcp-ultimate/discover-abilities',['compact'=>true,'if_catalog_sha256'=>$r['catalog_sha256']??'']);check('O15 unchanged catalog',!empty($same['unchanged'])&&$same['abilities']===[],$same);
wp_delete_post($post,true);wp_delete_post($page,true);@unlink($dir.'/binary.zip');@unlink($dir.'/log.txt');@rmdir($dir);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$GLOBALS['wpdb']->db_version(),'tests'=>count($tests),'failures'=>$fail,'results'=>$tests];
file_put_contents(dirname(__DIR__,2).'/evidencias/contracts-0130.json',json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($fail?1:0);
