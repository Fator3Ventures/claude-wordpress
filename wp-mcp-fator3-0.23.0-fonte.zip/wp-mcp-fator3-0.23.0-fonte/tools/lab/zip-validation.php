<?php
/** Synthetic hostile archives using the installed runtime and effective file limits. */
require getenv('F3_WP_ROOT');wp_set_current_user(1);\Fator3\McpFiles\Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'profile'=>'maintenance','status'=>'active','expires'=>0,'policy_version'=>1]);
use Fator3\McpFiles\ZipPackage;
function archive_bytes(array $entries): string {
    $locals='';$central='';
    foreach($entries as $entry){
        $name=$entry['name'];$value=$entry['value']??'fixture';$method=$entry['method']??8;$flags=$entry['flags']??0;
        $data=$method===8?gzdeflate($value):$value;
        $size=$entry['size']??strlen($value);$crc=$entry['crc']??crc32($value);$local_name=$entry['local_name']??$name;
        $offset=strlen($locals);
        $locals.="PK\x03\x04".pack('vvvvvVVVvv',20,$flags,$method,0,0,$crc,strlen($data),$size,strlen($local_name),0).$local_name.$data;
        $central.="PK\x01\x02".pack('vvvvvvVVVvvvvvVV',0x0314,$entry['needed']??20,$flags,$method,0,0,$crc,strlen($data),$size,strlen($name),0,0,0,0,($entry['mode']??0100644)<<16,$offset).$name;
    }
    return $locals.$central."PK\x05\x06".pack('vvvvVVv',0,0,count($entries),count($entries),strlen($central),strlen($locals),0);
}
function remove_fixture(string $path):void { if(is_dir($path)&&!is_link($path)){foreach(new DirectoryIterator($path)as $f)if(!$f->isDot())remove_fixture($f->getPathname());rmdir($path);}elseif(file_exists($path)||is_link($path))unlink($path); }
$cases=[
    'deflated exact bytes'=>[['name'=>'plugin/main.php','value'=>"<?php /* fixture */\n"],true],
    'stored binary exact bytes'=>[['name'=>'plugin/data.bin','value'=>"\0\xfffixture",'method'=>0],true],
    'empty file'=>[['name'=>'plugin/empty','value'=>''],true],
    'traversal rejected'=>[['name'=>'../escaped'],false],
    'absolute path rejected'=>[['name'=>'/escaped'],false],
    'windows path rejected'=>[['name'=>'C:\\escaped'],false],
    'symlink rejected'=>[['name'=>'plugin/link','mode'=>0120777],false],
    'device node rejected'=>[['name'=>'plugin/device','mode'=>0020600],false],
    'encrypted flag rejected'=>[['name'=>'plugin/main.php','flags'=>1],false],
    'ZIP64 version rejected'=>[['name'=>'plugin/main.php','needed'=>45],false],
    'declared expansion cap rejected'=>[['name'=>'plugin/large','size'=>134217729],false],
    'expanded bytes exceeding declaration rejected'=>[['name'=>'plugin/bomb','value'=>str_repeat('x',1048576),'size'=>1],false],
    'CRC mismatch rejected'=>[['name'=>'plugin/main.php','crc'=>0],false],
    'local central name disagreement rejected'=>[['name'=>'plugin/main.php','local_name'=>'plugin/evil.php'],false],
    'deep nesting rejected'=>[['name'=>str_repeat('p/',66).'data'],false],
    'unsupported method rejected'=>[['name'=>'plugin/main.php','method'=>12],false],
];
$root=sys_get_temp_dir().'/f3-zip-test-'.bin2hex(random_bytes(8));mkdir($root,0700);$tests=[];
try{
    foreach($cases as $name=>[$entry,$wanted]){
        $out=$root.'/out';mkdir($out,0700);$zip=$root.'/package.zip';file_put_contents($zip,archive_bytes([$entry]));$ok=false;
        try{$rows=ZipPackage::extract($zip,$out);$ok=count($rows)===1&&file_get_contents($out.'/'.$entry['name'])===($entry['value']??'fixture');}catch(Throwable $e){}
        $tests[]=['name'=>$name,'passed'=>$ok===$wanted];remove_fixture($out);unlink($zip);
    }
    foreach(['duplicate','parent_file','truncated']as $kind){
        $out=$root.'/out';mkdir($out,0700);$zip=$root.'/package.zip';
        $entries=$kind==='parent_file'?[['name'=>'plugin'],['name'=>'plugin/child']]:[['name'=>'plugin/data'],['name'=>'plugin/data']];
        $bytes=archive_bytes($entries);if($kind==='truncated')$bytes=substr($bytes,0,-3);file_put_contents($zip,$bytes);$rejected=false;
        set_error_handler(static fn()=>true);
        try{ZipPackage::extract($zip,$out);}catch(Throwable $e){$rejected=true;}finally{restore_error_handler();}
        $tests[]=['name'=>$kind.' rejected','passed'=>$rejected];remove_fixture($out);unlink($zip);
    }
}finally{remove_fixture($root);}
$failures=count(array_filter($tests,static fn($t)=>!$t['passed']));$out=['php'=>PHP_VERSION,'tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/zip-validation-0130.json',json_encode($out,JSON_PRETTY_PRINT));echo json_encode($out,JSON_PRETTY_PRINT)."\n";exit($failures?1:0);
