<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;use Fator3\McpFiles\ContentTools;use Fator3\McpFiles\Backups;
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'allow_backup_export'=>true,'time'=>time()]);
$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function call($name,$args=[]){$r=wp_get_ability($name)->execute($args);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
require_once ABSPATH.'wp-admin/includes/image.php';
$upload=wp_upload_dir();$file=$upload['path'].'/f3-media-fixture.png';$img=imagecreatetruecolor(640,640);imagefilledrectangle($img,0,0,639,639,imagecolorallocate($img,20,90,130));imagepng($img,$file);imagedestroy($img);$hash=hash_file('sha256',$file);
$id=wp_insert_attachment(['post_title'=>'Media fixture','post_mime_type'=>'image/png','post_status'=>'inherit'],$file);$old_icon=get_option('site_icon',0);add_image_size('f3-fixture-crop',77,93,true);
$r=call('media/regenerate',['id'=>$id]);check('E06 native GD generates registered crop and metadata',!empty($r['success'])&&($r['sizes']['f3-fixture-crop']['width']??0)===77&&($r['sizes']['f3-fixture-crop']['height']??0)===93&&hash_file('sha256',$file)===$hash,$r);
$backup=$r['backup_id']??'';$m=Backups::metadata($backup);check('E06 full preimage retains original file backup',!is_wp_error($m)&&!empty($m['snapshot']['file_backups']),is_wp_error($m)?$m->get_error_code():null);
$revision=ContentTools::revision($id);$r=call('media/regenerate',['id'=>$id,'expected_revision'=>$revision]);check('E06 repeated generation is observed no-op',!empty($r['success'])&&empty($r['changed'])&&hash_file('sha256',$file)===$hash,$r);
$r=call('media/set-site-icon',['id'=>$id]);check('E07 native icon sizes option URLs verified',!empty($r['success'])&&(int)get_option('site_icon')===$id&&count($r['urls']??[])>0&&empty($r['generation']['missing_sizes'])&&hash_file('sha256',$file)===$hash,$r);
$r=call('media/regenerate',['id'=>$id,'expected_revision'=>'stale']);check('E06 stale revision refuses effects',($r['error_code']??'')==='content_conflict',$r);
// Native save hooks must observe the thumbnail on the first save, not a later metadata repair.
$observed=[];$hook=static function($post_id,$post)use(&$observed){if($post->post_title==='Featured fixture')$observed[]=(int)get_post_thumbnail_id($post_id);};add_action('save_post',$hook,10,2);
$r=call('content/create-post',['title'=>'Featured fixture','status'=>'draft','featured_media'=>$id]);$post=$r['id']??$r['post']['id']??0;check('F21 first native save hook sees featured media',!empty($r['success'])&&$observed&&count(array_filter($observed,static fn($v)=>$v!==$id))===0,[$r,$observed]);
if($post){$read=call('content/get-post',['id'=>$post]);check('F21 response revision agrees with immediate read',($r['revision']??null)===($read['revision']??'different'),[$r,$read]);wp_delete_post($post,true);}remove_action('save_post',$hook,10);
// The permanent delete preimage includes physical files and native attachment metadata.
$p=call('media/delete',['id'=>$id,'force'=>true]);$r=call('media/delete',['id'=>$id,'force'=>true,'confirm_token'=>$p['confirm_token']??'']);
check('O11 media delete preserves complete preimage',!empty($r['success'])&&!get_post($id)&&!file_exists($file)&&!empty($r['backup_id']),$r);
if(!empty($r['backup_id'])){$m=Backups::metadata($r['backup_id']);check('O11 associated derivative bytes recoverable',!is_wp_error($m)&&count($m['snapshot']['file_backups']??[])>1,is_wp_error($m)?$m->get_error_code():array_keys($m['snapshot']??[]));}
update_option('site_icon',$old_icon);remove_image_size('f3-fixture-crop');if(get_post($id))wp_delete_attachment($id,true);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'gd'=>gd_info(),'database'=>$wpdb->db_version(),'tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/media-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
