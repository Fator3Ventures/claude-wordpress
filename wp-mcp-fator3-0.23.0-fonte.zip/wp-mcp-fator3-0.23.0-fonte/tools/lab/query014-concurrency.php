<?php
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence,StateStore,QueryExports,PrivateArtifact};
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'profile'=>'maintenance','status'=>'active','policy_version'=>1,'expires'=>0]);
$table=$wpdb->prefix.'query014_concurrency';$wpdb->query("CREATE TABLE `$table`(id int PRIMARY KEY,value varchar(60)) ENGINE=InnoDB");$wpdb->query("INSERT INTO `$table` VALUES(1,'before'),(2,'before')");$tests=[];
$http=static fn($pre,$args,$url)=>str_contains($url,'query-worker')?new WP_Error('synthetic_manual_worker'): $pre;add_filter('pre_http_request',$http,10,3);
foreach(['snapshot','cancel','kill'] as $kind){
 $wpdb->query("UPDATE `$table` SET value='before'");$r=QueryExports::create(['sql'=>"SELECT id,value FROM `$table` ORDER BY id",'format'=>'jsonl','gzip'=>false,'async'=>true]);$id=$r['operation_id'];$barrier=StateStore::directory('lab').'/query-'.$id;
 $p=proc_open([PHP_BINARY,'-c',php_ini_loaded_file(),__DIR__.'/query014-worker.php',$id,$barrier],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$end=microtime(true)+15;while(!is_file($barrier)&&microtime(true)<$end){if(!proc_get_status($p)['running'])break;usleep(10000);}$ready=is_file($barrier);
 if($kind==='snapshot')$wpdb->query("UPDATE `$table` SET value='after'");elseif($kind==='cancel')StateStore::put('query-cancel',$id,['status'=>'requested']);else proc_terminate($p,9);
 file_put_contents($barrier.'.go','go');$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);proc_close($p);
 if($kind==='kill'){$s=StateStore::get('query-jobs',$id);$s['lease_until']=time()-1;StateStore::put('query-jobs',$id,$s);}
 $s=QueryExports::status(['operation_id'=>$id]);$ok=false;
 if($kind==='snapshot'&&isset($s['artifact_id'])){$lines=iterator_to_array(PrivateArtifact::lines($s['artifact_id']));$rows=array_map(static fn($line)=>json_decode($line,true),$lines);$ok=count($rows)===2&&$rows[0]['value']==='before'&&$rows[1]['value']==='before'&&$wpdb->get_var("SELECT value FROM `$table` WHERE id=1")==='after';}
 if($kind==='cancel')$ok=($s['error_code']??'')==='export_cancelled'&&!isset($s['artifact_id']);if($kind==='kill')$ok=($s['error_code']??'')==='export_snapshot_lost'&&!isset($s['artifact_id']);
 $tests[]=['name'=>$kind,'passed'=>$ready&&$ok,'state'=>$s['status']??null];wp_clear_scheduled_hook('f3_mcp_query_job',[$id]);
}
remove_filter('pre_http_request',$http,10);$wpdb->query("DROP TABLE `$table`");$fail=count(array_filter($tests,static fn($t)=>!$t['passed']));$report=['tests'=>count($tests),'failures'=>$fail,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/query014-concurrency.json',json_encode($report,JSON_PRETTY_PRINT));echo json_encode($report,JSON_PRETTY_PRINT)."\n";exit($fail?1:0);
