<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);$rows=[];
foreach(wp_get_abilities() as $a)if(str_starts_with($a->get_name(),'yoast-seo/')||str_starts_with($a->get_name(),'f3base/')||str_starts_with($a->get_name(),'elementor/'))$rows[]=['name'=>$a->get_name(),'description'=>$a->get_description(),'input'=>$a->get_input_schema(),'output'=>$a->get_output_schema(),'meta'=>$a->get_meta()];
$r=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'yoast'=>defined('WPSEO_VERSION')?WPSEO_VERSION:null,'elementor'=>defined('ELEMENTOR_VERSION')?ELEMENTOR_VERSION:null,'catalog'=>$rows];file_put_contents(dirname(__DIR__,2).'/evidencias/third-party-catalog-0130.json',wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo 'Catalog: '.count($rows).' abilities; Yoast '.$r['yoast'].'; Elementor '.$r['elementor']."\n";
foreach($rows as $a)if(str_starts_with($a['name'],'yoast-seo/')||($a['meta']['mcp']['type']??'')==='resource')echo $a['name'].' '.json_encode($a['meta']['mcp']??[])."\n";
