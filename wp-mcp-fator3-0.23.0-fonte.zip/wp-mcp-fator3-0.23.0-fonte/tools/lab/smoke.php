<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);
\Fator3\McpFiles\Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'database_write'=>true,'roots'=>[ABSPATH],'allow_backup_export'=>true,'time'=>time()]);
$abilities=wp_get_abilities();echo json_encode(['abilities'=>count($abilities),'schema_version'=>get_option('f3_mcp_schema_version')])."\n";
foreach(['system/capabilities'=>[],'system/health'=>[],'db/schema'=>['table'=>'f3t_posts','contar'=>true],'wp-mcp-ultimate/discover-abilities'=>['compact'=>true,'per_page'=>2]] as $name=>$input) {
 try{$v=wp_get_ability($name)->execute($input);echo json_encode(['ability'=>$name,'success'=>!is_wp_error($v)&&!empty($v['success']),'error'=>is_wp_error($v)?$v->get_error_message():($v['message']??null),'result_keys'=>is_array($v)?array_keys($v):[]])."\n";}
 catch(Throwable $e){echo json_encode(['exception'=>$e->getMessage(),'trace'=>$e->getTraceAsString()])."\n";exit(1);}
}
