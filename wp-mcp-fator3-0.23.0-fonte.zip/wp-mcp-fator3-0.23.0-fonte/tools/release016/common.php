<?php
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence,ConnectionContext};
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'status'=>'active','profile'=>'maintenance']);
update_option('f3_mcp_files_enabled',true);update_option('f3_mcp_database_writes_enabled',true);
$checks=[];
function ck($ok,$name,$detail=null){global $checks;$checks[]=['test'=>$name,'passed'=>(bool)$ok];echo ($ok?'PASS ':'FAIL ').$name.($ok?'':' '.json_encode($detail,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))."\n";}
function calla($name,$input){$a=wp_get_ability($name);if(!$a)throw new RuntimeException('Missing '.$name);$r=$a->execute($input);return is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code(),'message'=>$r->get_error_message(),'data'=>$r->get_error_data()]:$r;}
function applied($name,$input){$p=calla($name,$input);if(empty($p['confirm_token']))return $p;return calla($name,$input+['confirm_token'=>$p['confirm_token']]);}
function finish($name){global $checks;$fail=count(array_filter($checks,static fn($c)=>!$c['passed']));file_put_contents(dirname(__DIR__,2).'/evidencias/'.$name.'.json',json_encode(['php'=>PHP_VERSION,'mysql'=>$GLOBALS['wpdb']->db_version(),'wordpress'=>$GLOBALS['wp_version'],'checks'=>$checks],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo count($checks).' checks; '.$fail." failures\n";exit($fail?1:0);}
