<?php
if(defined('WP_INSTALLING')&&WP_INSTALLING)return;
/** Synthetic provider intentionally does not warm the lazy registry. */
add_filter('mcp_adapter_create_default_server','__return_false');
add_action('plugins_loaded',static function(){
    Fator3\McpFiles\ExtensionContract::register('fixture-016','1.0.0',['fixture016/']);
    $GLOBALS['cold_before_init']=Fator3\McpFiles\ServerContract::status();
},20);
add_action('wp_abilities_api_categories_init',static fn()=>wp_register_ability_category('fixture016',['label'=>'Fixture','description'=>'Cold registry regression']));
add_action('wp_abilities_api_init',static function(){
    $GLOBALS['cold_during_init']=Fator3\McpFiles\ServerContract::status();
    if(F3_MCP_FILES_VERSION==='0.16.0')WpMcpUltimate\Server\McpAdapter::instance()->init(); // Reentrant entry must not publish partial server.
    foreach(['tool','resource','prompt'] as $type){
        wp_register_ability('fixture016/'.$type,['label'=>'Fixture '.$type,'description'=>'Cold fixture','category'=>'fixture016','input_schema'=>['type'=>'object','properties'=>new stdClass()],'output_schema'=>['type'=>'object','additionalProperties'=>true],
        'execute_callback'=>static fn()=>['value'=>'fixture016'],'permission_callback'=>'__return_true',
        'meta'=>['fator3'=>['provider'=>'fixture-016','version'=>'1.0.0','policy_contract'=>1],'mcp'=>['public'=>true,'type'=>$type,'uri'=>'fixture016://resource','mimeType'=>'text/plain'],'annotations'=>['readonly'=>true]]]);
    }
},20);
add_filter('f3_mcp_default_server_config',static function($c){
    if(F3_MCP_FILES_VERSION==='0.16.0')WpMcpUltimate\Server\McpAdapter::instance()->init();
    $c['tools'][]='fixture016/tool';return $c;
});
