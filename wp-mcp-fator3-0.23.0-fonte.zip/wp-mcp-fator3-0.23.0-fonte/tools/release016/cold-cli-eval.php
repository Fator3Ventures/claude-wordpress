<?php
$s=WpMcpUltimate\Server\McpAdapter::instance()->get_servers()['wp-mcp-ultimate-server']??null;
$names=$s?array_keys($s->get_tools($s->get_schemas()->forVersion('2025-11-25'))):[];
echo json_encode(['version'=>F3_MCP_FILES_VERSION,'registry_initializations'=>did_action('wp_abilities_api_init'),'early_checked'=>$GLOBALS['cold_before_init']['registry_checked']??null,'tools'=>$names]);
