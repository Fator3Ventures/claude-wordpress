<?php
require __DIR__.'/common.php';
use Fator3\McpFiles\ServerContract;
ck(did_action('wp_abilities_api_init')===0,'registry_still_cold_after_wp_load',did_action('wp_abilities_api_init'));
ck(($GLOBALS['cold_before_init']['registry_checked']??true)===false,'early_status_has_no_side_effect');
rest_get_server();$c=WpMcpUltimate\Server\DefaultServerFactory::configuration();
$servers=WpMcpUltimate\Server\McpAdapter::instance()->get_servers();$s=$servers['wp-mcp-ultimate-server']??null;
$expected=F3_MCP_FILES_VERSION==='0.16.0';$tools=$s?array_keys($s->get_tools($s->get_schemas()->forVersion('2025-11-25'))):[];
ck(in_array('fixture016-tool',$tools,true)===$expected,'cold_tool_regression_'.$expected,$tools);
ck(($GLOBALS['cold_during_init']['server_registered']??false)!==true,'during_registry_no_partial_ready');
ck(did_action('wp_abilities_api_init')===1,'registry_once');
ck(count($servers)===1,'server_once');
if($expected){ck(in_array('fixture016/resource',$c['resources'],true)&&in_array('fixture016/prompt',$c['prompts'],true),'resources_prompts_discovered');ck(ServerContract::status()['tools_ready']===true,'ready_after_registry');}
finish('cold-'.F3_MCP_FILES_VERSION);
