<?php
require __DIR__.'/common.php';
use Fator3\McpFiles\{DatabaseAdmin,DatabaseRead,ServerContract};
ck(defined('F3_MCP_GOOGLE_VERSION')&&F3_MCP_GOOGLE_VERSION==='0.7.1','google071');
$r=F3Base_Instalacao::atualizar();ck(F3Base_Instalacao::origem()==='atual','core1221_native_upgrade',$r);
$option=get_option('elementor_mcp_enabled','absent');rest_get_server();$s=ServerContract::status();ck(!empty($s['tools_ready']),'joint_server_ready',$s);
foreach(['f3base/operacao-recuperacao-ler','f3base/operacao-recuperacao','google/recovery-status','google/recovery'] as $n)ck(wp_get_ability($n)!==null,'ability_'.$n);
$core=calla('f3base/operacao-recuperacao',['acao'=>'preparar','geracao_esperada'=>F3Base_Recuperacao::ler()['geracao']]);$google=calla('google/recovery',['action'=>'prepare']);
ck(!empty($core['recuperacao']['pronto_para_restaurar']),'core_drained',$core);ck(!empty($google['ready_for_restore']),'google_drained',$google);
$gc=Fator3\McpGoogle\Recovery::status();$cc=F3Base_Recuperacao::ler();
$bad=calla('google/recovery',['action'=>'resume','expected_generation'=>$gc['generation'].'-stale','acknowledge_reconciled'=>true]);ck(empty($bad['success']),'wrong_google_generation_rejected',$bad);
$bad=calla('f3base/operacao-recuperacao',['acao'=>'retomar','geracao_esperada'=>$cc['geracao']+1,'reconciliacao_confirmada'=>true]);ck(empty($bad['ok']),'wrong_core_generation_rejected',$bad);
$export=DatabaseAdmin::export(['tables'=>['wp_scope016']]);$r=applied('db/restore',['artifact_id'=>$export['artifact_id']]);ck(!empty($r['success']),'restore_with_both_paused',$r);
ck(!empty(F3Base_Recuperacao::ler()['pausado'])&&!empty(Fator3\McpGoogle\Recovery::status()['paused']),'guards_persist_after_restore');
$bad=calla('google/recovery',['action'=>'resume','expected_generation'=>$gc['generation'],'acknowledge_reconciled'=>true]);ck(!empty($bad['success']),'google_explicit_resume',$bad);
ck(!empty(F3Base_Recuperacao::ler()['pausado']),'core_still_paused_independently');
$r=calla('f3base/operacao-recuperacao',['acao'=>'retomar','geracao_esperada'=>$cc['geracao'],'reconciliacao_confirmada'=>true]);ck(!empty($r['ok']),'core_explicit_resume',$r);
ck(get_option('elementor_mcp_enabled','absent')===$option,'elementor_option_preserved');
finish('companions-tests');
