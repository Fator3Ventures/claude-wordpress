<?php
require __DIR__.'/common.php';
use Fator3\McpFiles\Persistence;
$active=get_option('active_plugins');update_option('active_plugins',['wp-mcp-fator3/wp-mcp-fator3.php']);copy(__DIR__.'/cold-fixture.php',WPMU_PLUGIN_DIR.'/016-cold-fixture.php');
$app=WP_Application_Passwords::create_new_application_password(1,['name'=>'Cold disposable']);$id='app:'.$app[1]['uuid'];Persistence::put('connections',$id,['user_id'=>1,'connection_id'=>$id,'profile'=>'maintenance','status'=>'active']);$auth='Basic '.base64_encode(wp_get_current_user()->user_login.':'.$app[0]);
try{
 foreach(['wp-mcp-fator3','wp-mcp-ultimate'] as $route){
  foreach(['tools/list','resources/list','prompts/list','tools/call'] as $method){
   $params=['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()]];
   if($method==='tools/call')$params+=['name'=>'fixture016-tool','arguments'=>new stdClass()];
   $headers=['Authorization'=>$auth,'Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Protocol-Version'=>'2026-07-28','Mcp-Method'=>$method];if(isset($params['name']))$headers['Mcp-Name']=$params['name'];
   $response=wp_remote_post(rest_url('mcp/'.$route),['timeout'=>20,'headers'=>$headers,'body'=>json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>$method,'params'=>$params])]);$body=is_wp_error($response)?[]:json_decode(wp_remote_retrieve_body($response),true);
   ck(!is_wp_error($response)&&wp_remote_retrieve_response_code($response)===200&&str_contains(json_encode($body),'fixture016')&&empty($body['error'])&&empty($body['result']['isError']),'first_http_'.$method.'_'.$route,$body);
  }
 }
 $wpcli=getenv('F3_WP_CLI')?:'/workspace/scratch/ad9b0df8e636/release-071/dependencies/wp-cli.phar';
 $p=proc_open([PHP_BINARY,$wpcli,'--path='.ABSPATH,'--allow-root','eval-file',__DIR__.'/cold-cli-eval.php'],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$code=proc_close($p);$r=json_decode($out,true);
 ck($code===0&&($r['early_checked']??true)===false&&($r['registry_initializations']??0)===1&&in_array('fixture016-tool',$r['tools']??[]),'real_wp_cli_cold',[$code,$r,$err]);
}finally{@unlink(WPMU_PLUGIN_DIR.'/016-cold-fixture.php');update_option('active_plugins',$active);WP_Application_Passwords::delete_application_password(1,$app[1]['uuid']);}
finish('cold-http-cli');
