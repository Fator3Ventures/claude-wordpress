<?php
require getenv('F3_WP_ROOT');
$mu=WPMU_PLUGIN_DIR.'/016-cold-fixture.php';if(!is_dir(WPMU_PLUGIN_DIR))mkdir(WPMU_PLUGIN_DIR,0755,true);copy(__DIR__.'/cold-fixture.php',$mu);
