<?php
require getenv('F3_WP_ROOT');
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';
@unlink(WPMU_PLUGIN_DIR.'/016-cold-fixture.php');$GLOBALS['wpdb']->query('DROP TABLE IF EXISTS wp_f3base_guard');
foreach(['base-site-core-fator3/base-site-core-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php','elementor/elementor.php'] as $p){$r=activate_plugin($p);if(is_wp_error($r)){echo $p.' '.json_encode($r)."\n";exit(1);}}
echo 'Native companion activation complete.'."\n";
