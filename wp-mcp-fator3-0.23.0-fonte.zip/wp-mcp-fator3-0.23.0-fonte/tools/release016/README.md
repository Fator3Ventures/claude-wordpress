# Laboratório 0.16.0

Os testes usam MySQL 8.0.46, PHP 8.3.30, Apache 2.4.58 com suporte a execução local como root e WP-CLI real. Não usam SQLite nem o servidor embutido do PHP. Todos os serviços vinculam somente 127.0.0.1, em portas 18306/18083/19000; execute um laboratório por vez. Contas e salts são sintéticos, destinados somente ao laboratório descartável.

Os binários, WordPress e os dois provedores não integram o pacote MCP. Forneça o WordPress 7.1.2, instaladores Core 1.22.1 e Google 0.7.1 recebidos/reproduzidos e, para os testes com Elementor, o instalador 4.3.3. A tabela no relatório registra os hashes efetivamente usados. `create-lab.py --help` descreve as entradas explícitas; ele recusa diretório existente e só aceita `/tmp/f3-mcp-*/lab`.

Configure `F3_LAB_ROOT`, `F3_MYSQL_ROOT` (diretório usr com sbin/mysqld), `F3_PHP_ROOT`, `F3_PHP` (bin/php), `F3_APACHE_ROOT`, `F3_RUNTIME_LIBS` (bibliotecas dinâmicas) e `F3_WP_CLI` (phar). Os defaults absolutos de lab.py documentam o workspace da execução original. A configuração Apache fornecida destina-se ao runtime de teste compilado para root; não use esse perfil em servidor público.

`python3 tools/release016/lab.py tools/release016/smoke.php` inicializa o MySQL e WordPress locais, copia o candidato e encerra os serviços ao terminar. `F3_MCP_SOURCE` seleciona outro fonte, como a base 0.15.0. `F3_RESET_DATABASE=1` apaga somente o banco sintético f3_lab do datadir selecionado; para reproduzir instalação nova com guardas externas, crie também uma pasta de laboratório nova.

Sequência usada:

1. Base só com MCP: roles-tests, sql-artifacts-tests, regressões tools/release015/sql-tests e cold-setup/cold-tests. O cold-tests é executado na 0.15.0 e na 0.16.0; o caso antigo espera a ausência da contribuição antes da correção. Reentrada é exercitada no candidato.
2. companions-setup ativa Core/Google/Elementor nativamente. O caso de SQL antigo cria wp_f3base_guard; setup remove apenas essa tabela sintética antes da detecção de instalação limpa Core. Acompanhe F3Base_Instalacao::atualizar até concluir; nunca fabrique checkpoint.
3. google-bridge, companions-tests, core-permission-tests, concurrency-tests, inventory-tests, cold-http-cli, http-tests e full-recovery-tests. reverse-order/google-bridge-reverse/restore-order comprovam a outra ordem. As conexões Google criadas são sintéticas e sem credenciais.
4. Em outro datadir novo, carregue o fonte MCP 0.15.0 com F3_MCP_SOURCE e execute upgrade-http.php. Construa antes o ZIP candidato com tools/build_packages.py. O teste chama plugins/upload-base64 por HTTP, preserva confirmação/token/perfil, aquece OPcache e testa rollback de um candidato fatal gerado por create-lab.py. OPcache permanece com validate_timestamps=0 nesse laboratório.
5. export-contracts.php, check_documentation.py e check_package.py verificam schemas, documentação e pacote determinístico. O diretório evidencias guarda saídas finais sanitizadas. O pacote fonte exclui laboratórios, binários, ZIPs intermediários e arquivos de credenciais.

O aceite externo foi realizado separadamente pelo conector existente do Site-Teste. O roteiro e seus resultados estão em evidencias/site-test-0160.json; nenhum script deste pacote implanta automaticamente em um site remoto.
