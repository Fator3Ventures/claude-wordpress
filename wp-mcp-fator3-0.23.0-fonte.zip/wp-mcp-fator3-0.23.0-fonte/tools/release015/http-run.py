from pathlib import Path
import subprocess,os,time,socket,sys
base=Path(__file__).resolve().parents[2];lab=Path(os.environ.get('F3_LAB_ROOT',str(base/'lab')));env=os.environ.copy();env['F3_HTTP_TESTS']='1'
# Cooperating processes must share this orchestration call's network context.
env['LD_LIBRARY_PATH']=str(base/'dependencies/build-root/usr/lib/x86_64-linux-gnu')
(lab/'apache.pid').unlink(missing_ok=True)
fpm=subprocess.Popen([str(base/'dependencies/php-runtime/sbin/php-fpm'),'-R','-c',str(lab/'php.ini'),'-y',str(lab/'fpm.conf')],env=env,stdout=open(lab/'fpm-stdout.log','w'),stderr=subprocess.STDOUT)
apache=subprocess.Popen([str(base/'dependencies/apache-runtime/bin/httpd'),'-f',str(lab/'apache.conf'),'-DFOREGROUND'],env=env,stdout=open(lab/'apache-stdout.log','w'),stderr=subprocess.STDOUT)
try:
 for i in range(100):
  try:
   with socket.create_connection(('127.0.0.1',18093),.2) as c:break
  except OSError:time.sleep(.1)
 else:raise RuntimeError('Apache not listening')
 r=subprocess.run([sys.executable,str(base/'tools/release015/lab.py'),*sys.argv[1:]],env=env);sys.exit(r.returncode)
finally:
 for p in [apache,fpm]:
  p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill()
