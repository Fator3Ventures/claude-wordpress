<?php
/** Real loopback authorization/token journey with synthetic cookie and credentials. */
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\{Persistence,ConnectionStatus};
use WpMcpUltimate\OAuth\{TokenStore,ClientMetadata};
if(!str_contains(ABSPATH,'/lab/wordpress/')&&getenv('F3_ACCEPTANCE_LAB')!=='1'&&!(getenv('F3_LAB_ISOLATED')==='1'&&str_starts_with(ABSPATH,'/tmp/f3-mcp-lab-')))throw new RuntimeException('Disposable lab required.');
wp_set_current_user(1);$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function http($path,$args=[]){return wp_remote_request(home_url($path),$args+['timeout'=>15,'redirection'=>0,'limit_response_size'=>131072]);}
function json_body($response){return is_wp_error($response)?[]:json_decode(wp_remote_retrieve_body($response),true);}
// Do not serialize codes, cookies or tokens into test evidence.
$client=bin2hex(random_bytes(16));$redirect='https://example.invalid/f3-callback';TokenStore::save_client($client,['redirect_uris'=>[$redirect],'client_name'=>'F3 synthetic OAuth','issuer'=>untrailingslashit(home_url()),'time'=>time()]);
$session=WP_Session_Tokens::get_instance(1)->create(time()+300);$cookie=wp_generate_auth_cookie(1,time()+300,'logged_in',$session);$cookies=[new WP_Http_Cookie(['name'=>LOGGED_IN_COOKIE,'value'=>$cookie])];
$verifier=str_repeat('v',64);$challenge=rtrim(strtr(base64_encode(hash('sha256',$verifier,true)),'+/','-_'),'=');
$params=['client_id'=>$client,'redirect_uri'=>$redirect,'response_type'=>'code','state'=>'synthetic-state','scope'=>'mcp:read mcp:content mcp:content','code_challenge'=>$challenge,'code_challenge_method'=>'S256','resource'=>rest_url('mcp/wp-mcp-fator3')];
try {
 $get=http('/wp-mcp-oauth/authorize?'.http_build_query($params),['cookies'=>$cookies]);$html=wp_remote_retrieve_body($get);preg_match('/name="_wpnonce" value="([^"]+)"/',$html,$m);$nonce=$m[1]??'';
 check('F02 logged-in authorization displays real consent',wp_remote_retrieve_response_code($get)===200&&$nonce!==''&&str_contains($html,'f3_profile'));
 $post=http('/wp-mcp-oauth/authorize',['method'=>'POST','cookies'=>$cookies,'body'=>$params+['_wpnonce'=>$nonce,'wp_mcp_oauth_consent'=>'allow','f3_profile'=>'content']]);$location=wp_remote_retrieve_header($post,'location');parse_str((string)wp_parse_url($location,PHP_URL_QUERY),$approved);
 check('M03 consent binds state and RFC9207 issuer',wp_remote_retrieve_response_code($post)===302&&($approved['state']??'')===$params['state']&&($approved['iss']??'')===untrailingslashit(home_url())&&!empty($approved['code']));
 $exchange=['grant_type'=>'authorization_code','client_id'=>$client,'code'=>$approved['code']??'','redirect_uri'=>$redirect,'code_verifier'=>$verifier,'resource'=>$params['resource']];
 $wrong=http('/wp-mcp-oauth/token',['method'=>'POST','body'=>array_replace($exchange,['code_verifier'=>str_repeat('x',64)])]);check('F02 bad PKCE refused without consuming code',wp_remote_retrieve_response_code($wrong)===400&&(json_body($wrong)['error']??'')==='invalid_grant');
 $response=http('/wp-mcp-oauth/token',['method'=>'POST','body'=>$exchange]);$tokens=json_body($response);check('F02 real HTTP code exchange issues tokens',wp_remote_retrieve_response_code($response)===200&&!empty($tokens['access_token'])&&!empty($tokens['refresh_token'])&&($tokens['scope']??'')==='mcp:content');
 $again=http('/wp-mcp-oauth/token',['method'=>'POST','body'=>$exchange]);check('F02 authorization code cannot be reused',(json_body($again)['error']??'')==='invalid_grant');
 $rpc=['jsonrpc'=>'2.0','id'=>1,'method'=>'tools/list','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()]]];
 $r=http(str_replace(home_url(),'',rest_url('mcp/wp-mcp-fator3')),['method'=>'POST','headers'=>['Authorization'=>'Bearer '.($tokens['access_token']??''),'Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Method'=>'tools/list','Mcp-Protocol-Version'=>'2026-07-28'],'body'=>wp_json_encode($rpc)]);
 check('M02 stateless 2026 request uses new OAuth grant',wp_remote_retrieve_response_code($r)===200&&!empty(json_body($r)['result']['tools']),['status'=>wp_remote_retrieve_response_code($r),'response'=>json_body($r)]);
 $payload=TokenStore::get_access_token($tokens['access_token']??'');$grant=$payload['grant_id']??'';
 $observed=Persistence::get('connections','grant:'.$grant);
 check('O17 authenticated OAuth request has protocol evidence',($observed['last_protocol_request']['protocol_version']??'')==='2026-07-28'&&($observed['last_protocol_request']['authentication']??'')==='oauth');
 $refresh=['grant_type'=>'refresh_token','client_id'=>$client,'refresh_token'=>$tokens['refresh_token']??''];
 $r=http('/wp-mcp-oauth/token',['method'=>'POST','body'=>$refresh]);$rotated=json_body($r);check('F02 refresh rotates in real HTTP request',wp_remote_retrieve_response_code($r)===200&&!empty($rotated['access_token']));
 $r=http('/wp-mcp-oauth/token',['method'=>'POST','body'=>$refresh]);check('F02 refresh replay revokes whole family',(json_body($r)['error']??'')==='invalid_grant'&&TokenStore::get_access_token($rotated['access_token']??'')===null);
 $r=http('/wp-mcp-oauth/token',['method'=>'POST','headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['grant_type'=>'authorization_code','code'=>['bad']])]);check('F02 malformed scalar rejected explicitly',wp_remote_retrieve_response_code($r)===400&&(json_body($r)['error']??'')==='invalid_request');
 $r=http(str_replace(home_url(),'',rest_url('mcp/wp-mcp-fator3')),['method'=>'POST','headers'=>['Authorization'=>'Bearer '.($rotated['access_token']??''),'Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Method'=>'tools/list','Mcp-Protocol-Version'=>'2026-07-28'],'body'=>wp_json_encode($rpc)]);check('O02 revoked family cannot access MCP',wp_remote_retrieve_response_code($r)===401);
 $legacy=TokenStore::generate_token();$name='f3_mcp_oauth_at_'.hash('sha256',$legacy);set_transient($name,['client_id'=>$client,'user_id'=>1],60);update_option('_transient_timeout_'.$name,time()-60);check('F02 expired legacy transient cannot resurrect',TokenStore::get_access_token($legacy)===null);delete_transient($name);
} finally {WP_Session_Tokens::get_instance(1)->destroy($session);$row=Persistence::get('oauth-clients',$client);if($row){$row['status']='revoked';Persistence::put('oauth-clients',$client,$row);}}
$url='https://1.1.1.1/f3-client-metadata.json';$doc=['client_id'=>$url,'client_name'=>'Synthetic CIMD','redirect_uris'=>['https://example.invalid/callback'],'token_endpoint_auth_method'=>'none'];$fetches=0;
$mock=static function($pre,$args,$target)use($url,&$doc,&$fetches){if($target!==$url)return $pre;$fetches++;return ['response'=>['code'=>200],'headers'=>['content-type'=>'application/json','cache-control'=>'max-age=60'],'body'=>wp_json_encode($doc),'cookies'=>[]];};add_filter('pre_http_request',$mock,10,3);
try {Persistence::delete('oauth-clients',$url);$resolved=ClientMetadata::resolve($url,null);$stored=TokenStore::get_client($url,false);$cached=ClientMetadata::resolve($url,$stored);check('M03 CIMD exact document and bounded cache',is_array($resolved)&&is_array($cached)&&$fetches===1);$doc['client_id']='https://example.invalid/other';check('M03 CIMD changed document identity refused',ClientMetadata::resolve($url,null)===null);}finally{remove_filter('pre_http_request',$mock,10);Persistence::delete('oauth-clients',$url);}
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'http'=>'Apache + PHP-FPM; synthetic OAuth client','tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/oauth-http-0150.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
