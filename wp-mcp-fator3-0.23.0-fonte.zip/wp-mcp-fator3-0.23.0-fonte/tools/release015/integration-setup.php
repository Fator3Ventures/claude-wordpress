<?php
require getenv('F3_WP_ROOT');
$plugins=['wp-mcp-fator3/wp-mcp-fator3.php','base-site-core-fator3/base-site-core-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php','elementor/elementor.php'];
if(getenv('F3_REVERSE_LOAD'))$plugins=array_reverse($plugins);update_option('active_plugins',$plugins);
if(getenv('F3_ELEMENTOR_ENABLED')==='absent')delete_option('elementor_mcp_enabled');else update_option('elementor_mcp_enabled',getenv('F3_ELEMENTOR_ENABLED')==='1');
// The companion's own public option API is used after it boots, in the test request.
echo "Integration fixtures prepared.\n";
