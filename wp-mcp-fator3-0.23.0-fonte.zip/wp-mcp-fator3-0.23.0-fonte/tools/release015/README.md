# Suítes da release 0.15.0

Defina `F3_WP_ROOT` para `wp-load.php` em um WordPress descartável e `F3_FIXTURE_ROOT` para diretório privado de barreiras. Scripts PHP não devem ser apontados para produção. SQL usa massa sintética `wp_guard_*`/`wp_f3base_guard` e exige o prefixo `wp_`. Os JSONs de evidência não contêm senhas/tokens.

`lab.py` e `http-run.py` são orquestradores da execução desta sessão; seus caminhos padrão refletem esse ambiente. Para outra máquina, use a receita em `tools/acceptance` ou forneça PHP (`F3_PHP`), MySQL (`F3_MYSQL_ROOT`) e prepare `lab/wordpress`, `lab/mysql-files`, fixtures e os arquivos Apache/FPM locais. A árvore `dependencies` e o banco `lab` não são distribuídos. `F3_RESET_DATABASE=1` apaga somente o banco sintético `f3_lab`; `F3_MCP_SOURCE` escolhe o pacote inicial. Não use essas variáveis contra outro banco.

Fixture de isolamento, instalada somente no laboratório:

```php
add_filter('mcp_adapter_create_default_server', '__return_false');
add_action('mcp_adapter_init', static function(\WP\MCP\Core\McpAdapter $adapter) {});
add_filter('mcp_adapter_tool_name', static fn($name) => 'unexpected-'.$name);
add_action('plugins_loaded', static function() {
    if (class_exists('Fator3\\McpFiles\\ServerContract')) {
        $GLOBALS['f3_early_status'] = \Fator3\McpFiles\ServerContract::status();
    }
}, 0);
```

Remova essa fixture ao iniciar a prova da 0.14, pois ela reproduz o conflito que aquela versão ainda contém. A suíte de update aquece o pool na 0.14, chama `plugins/upload-base64` e confere respostas da 0.15, sem copiar classes novas no processo antigo.

Os testes `fixture-sdk-tests.php` provam apenas deduplicação do contrato futuro e independência de uma fachada PHP sintética. Não implementam nem certificam o serviço Search Console dos complementos futuros. Os fontes reais 1.19/0.6/Elementor 4.3.3 foram exercitados separadamente.

Para operações que trocam diretórios, use `F3_LAB_ROOT` apontando para uma árvore descartável fora de diretórios sincronizados, mantendo o sufixo `/lab/wordpress/`. As provas finais de self-upload/recuperação foram executadas assim. Um sincronizador que reintroduz arquivos antigos no destino causa corretamente `rollback_conflict`; não desabilite a proteção de pós-imagem para acomodar o laboratório. Os arquivos Apache/FPM devem apontar para essa mesma árvore.
