<?php
/** Contract fixture only: no assertion about unpublished Core/Google business implementation. */
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{ServerContract,Providers};
wp_set_current_user(1);wp_get_abilities();$checks=[];
function ck($ok,$name){global $checks;$checks[]=['test'=>$name,'passed'=>(bool)$ok];echo ($ok?'PASS ':'FAIL ').$name."\n";}
$called=0;$filter=static function($config,$identity)use(&$called){$called++;if(($identity['contract']??'')!==ServerContract::CONTRACT||($identity['provider']??'')!=='wp-mcp-fator3')return $config;$config['tools'][]='google/mcp-read';$config['tools'][]='google/mcp-write';return $config;};
add_filter('f3_mcp_default_server_config',$filter,10,2);$c=\WpMcpUltimate\Server\DefaultServerFactory::configuration();ck($called===1&&count(array_keys($c['tools'],'google/mcp-read',true))===1,'future_sdk_deduplicates_current_google_bridge');remove_filter('f3_mcp_default_server_config',$filter,10);
$service=static fn()=>['contract'=>'search-console-reader/1.0.0','origin'=>'synthetic PHP fixture'];update_option('f3_mcp_files_enabled',false);wp_set_current_user(0);ck($service()['contract']==='search-console-reader/1.0.0'&&!ServerContract::status()['channel_enabled'],'local_service_fixture_independent_of_mcp_identity_and_switch');update_option('f3_mcp_files_enabled',true);
file_put_contents(dirname(__DIR__,2).'/evidencias/future-sdk-fixture.json',json_encode(['scope'=>'Contract-only synthetic fixture; Core 1.20 and Google 0.7 not supplied, GSC service not implemented here.','checks'=>$checks],JSON_PRETTY_PRINT));exit(array_filter($checks,static fn($r)=>!$r['passed'])?1:0);
