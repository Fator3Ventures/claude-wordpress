<?php
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence,ConnectionContext,SqlMutationPlan,DatabaseRead,DatabaseAdmin,ServerContract};
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'profile'=>'maintenance','status'=>'active']);wp_get_abilities();
echo json_encode(ServerContract::status(),JSON_UNESCAPED_SLASHES)."\n";
$db=DatabaseRead::connection();$db->query('DROP TABLE IF EXISTS wp_f3base_guard');$db->query('CREATE TABLE wp_f3base_guard (id BIGINT PRIMARY KEY AUTO_INCREMENT, n INT NOT NULL, label VARCHAR(120) UNIQUE, body LONGBLOB NULL) ENGINE=InnoDB');$db->query("INSERT INTO wp_f3base_guard (n,label) VALUES (2,'a'),(3,'b')");
foreach(["UPDATE wp_f3base_guard SET n=n+1 WHERE id=1","UPDATE wp_f3base_guard SET n=n WHERE id=2","INSERT INTO wp_f3base_guard (id,n,label) VALUES (3,4,'c')","INSERT INTO wp_f3base_guard (id,n,label) VALUES (2,3,'b') ON DUPLICATE KEY UPDATE n=VALUES(n)"] as $sql){
 try{$p=(new SqlMutationPlan($db))->build([$sql]);echo json_encode(['sql'=>$sql,'presentation'=>$p['presentation'],'locks'=>$p['locks']],JSON_UNESCAPED_SLASHES)."\n";}catch(Throwable $e){echo get_class($e).':'.$e->getMessage()."\n";}
 $r=DatabaseAdmin::execute(['sql'=>$sql]);echo json_encode($r,JSON_UNESCAPED_SLASHES)."\n";
 if(isset($r['confirm_token']))echo json_encode(DatabaseAdmin::execute(['sql'=>$sql,'confirm_token'=>$r['confirm_token']]),JSON_UNESCAPED_SLASHES)."\n";
}
