<?php
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence,Upgrade015,ConnectionContext,ServerContract};
$checks=[];function ck($ok,$name){global $checks;$checks[]=['test'=>$name,'passed'=>(bool)$ok];echo ($ok?'PASS ':'FAIL ').$name."\n";}
$j=Persistence::get('migration','release:0.15.0');ck(($j['from']??'')==='clean'&&($j['status']??'')==='complete','clean_origin_complete');
ck(get_option('f3_mcp_release_version')==='0.15.0','clean_release_version');ck(get_option('f3_mcp_014_credential_ids')===[],'clean_no_implicit_old_credentials');
wp_set_current_user(1);$app=WP_Application_Passwords::create_new_application_password(1,['name'=>'clean fixture']);do_action('application_password_did_authenticate',wp_get_current_user(),$app[1]);$ctx=ConnectionContext::get();ck(($ctx['profile']??'')==='unconfigured'&&($ctx['status']??'')==='no_access','new_credential_no_implicit_access');WP_Application_Passwords::delete_application_password(1,$app[1]['uuid']);
update_option('f3_mcp_files_enabled',false);update_option('f3_mcp_update_channels',[]);Upgrade015::run();Upgrade015::run();ck(get_option('f3_mcp_files_enabled')===false&&get_option('f3_mcp_update_channels')===[],'repeat_preserves_false_empty');update_option('f3_mcp_files_enabled',true);
ck(!class_exists('Fator3\\McpFiles\\Migration'),'no_predecessor_migrator');
file_put_contents(dirname(__DIR__,2).'/evidencias/clean-tests.json',json_encode(['checks'=>$checks],JSON_PRETTY_PRINT));exit(array_filter($checks,static fn($r)=>!$r['passed'])?1:0);
