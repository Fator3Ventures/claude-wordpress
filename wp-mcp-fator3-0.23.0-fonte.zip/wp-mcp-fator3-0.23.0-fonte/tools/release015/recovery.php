<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\Recovery;
use Fator3\McpFiles\Locks;
use Fator3\RecoveryV1\Engine;
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'allow_backup_export'=>true,'time'=>time()]);
$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function ability($name,$args=[]){$r=wp_get_ability($name)->execute($args);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
require_once ABSPATH.'wp-admin/includes/plugin.php';
$plugin='f3-delete-fixture/f3-delete-fixture.php';$dir=WP_PLUGIN_DIR.'/f3-delete-fixture';wp_mkdir_p($dir);file_put_contents(WP_PLUGIN_DIR.'/'.$plugin,"<?php\n/* Plugin Name: F3 delete fixture\nVersion: 1.0.0\n*/\n");wp_clean_plugins_cache(false);$auto=(array)get_site_option('auto_update_plugins',[]);update_site_option('auto_update_plugins',array_values(array_unique(array_merge($auto,[$plugin,'other/sentinel.php']))));
$p=ability('plugins/delete',['plugin'=>$plugin]);check('F22 delete preview includes auto update bit',!empty($p['preview'])&&!empty($p['summary']['auto_update'])&&is_file(WP_PLUGIN_DIR.'/'.$plugin),$p);
$token=$p['confirm_token']??'';$r=ability('plugins/delete',['plugin'=>$plugin,'confirm_token'=>$token]);check('F22 delete removes only own auto update entry',!empty($r['success'])&&!file_exists($dir)&&!in_array($plugin,(array)get_site_option('auto_update_plugins',[]),true)&&in_array('other/sentinel.php',(array)get_site_option('auto_update_plugins',[]),true),$r);
$r=ability('plugins/delete',['plugin'=>$plugin,'confirm_token'=>$token]);check('F22 completed deletion replay',!empty($r['success'])&&!empty($r['replayed']),$r);update_site_option('auto_update_plugins',$auto);
$dir=WP_CONTENT_DIR.'/f3-recovery-fixtures';wp_mkdir_p($dir);$path=$dir.'/state.txt';file_put_contents($path,'before');
Locks::files([$path],static function()use($path){
    $op=Recovery::begin($path,Engine::digest(['kind'=>'file','files'=>[''=>['sha256'=>hash('sha256','after'),'bytes'=>5,'mode'=>fileperms($path)&0777]]]));
    file_put_contents($path,'after');Recovery::close($op,'applied');$r=Engine::restore($op['file'],true);check('P06 matching postimage restores before bytes',($r['status']??'')==='rolled_back'&&file_get_contents($path)==='before',$r);Recovery::release($op);
});
Locks::files([$path],static function()use($path){
    $op=Recovery::begin($path,Engine::digest(['kind'=>'file','files'=>[''=>['sha256'=>hash('sha256','after'),'bytes'=>5,'mode'=>fileperms($path)&0777]]]));
    file_put_contents($path,'third-party');Recovery::close($op,'applied');$r=Engine::restore($op['file'],true);check('P06 unrelated postimage refuses overwrite',($r['status']??'')==='rollback_conflict'&&file_get_contents($path)==='third-party'&&(Engine::read($op['file'])['status']??'')==='rollback_conflict',$r);Recovery::release($op);
});
file_put_contents($path,'before');
Locks::files([$path],static function()use($path){
    $op=Recovery::begin($path,Engine::digest(['kind'=>'file','files'=>[''=>['sha256'=>hash('sha256','after'),'bytes'=>5,'mode'=>fileperms($path)&0777]]]));
    file_put_contents($path,'after');Recovery::close($op,'restoring');$state=$op['state'];$prepared=dirname($path).'/.f3-restore-'.$state['id'];$quarantine=dirname($path).'/.f3-displaced-'.$state['id'];Engine::copy($state['preimage'],$prepared);rename($path,$quarantine);
    $r=Engine::restore($op['file'],true);check('P06 resumes interruption between directory renames',($r['status']??'')==='rolled_back'&&file_get_contents($path)==='before'&&!file_exists($quarantine),$r);Recovery::release($op);
});
// A syntactically valid fatal in an active MU plugin must be rolled back by the already-loaded caller.
$mu=WPMU_PLUGIN_DIR.'/f3-runtime-fixture.php';file_put_contents($mu,"<?php /* healthy fixture */\n");$before=hash_file('sha256',$mu);
$r=ability('files/write',['path'=>$mu,'content'=>"<?php f3_nonexistent_function_for_fixture();\n",'expected_sha256'=>$before]);check('F20 syntax-valid fatal restored in same call',($r['error_code']??'')==='runtime_verification_failed'&&hash_file('sha256',$mu)===$before&&($r['recovery_status']??'')==='rolled_back',$r);unlink($mu);
unlink($path);rmdir($dir);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$GLOBALS['wpdb']->db_version(),'transport'=>'Apache + PHP-FPM loopback; interruption fixture uses directory-state injection','tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/recovery-0150.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
