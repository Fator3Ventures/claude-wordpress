<?php
namespace Fator3\McpFiles {
 function fwrite($stream,$bytes,...$args){
  if(!empty($GLOBALS['f3_disk_full'])&&str_contains(stream_get_meta_data($stream)['uri']??'','/artifacts/')){$full=\fopen('/dev/full','wb');try{return @\fwrite($full,$bytes);}finally{\fclose($full);}}
  return \fwrite($stream,$bytes,...$args);
 }
}
namespace {
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{DatabaseRead,DatabaseAdmin,Persistence,StateStore};
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active']);$db=DatabaseRead::connection();$other=DatabaseRead::connection();$checks=[];
function ck($ok,$name,$details=[]){global $checks;$checks[]=['test'=>$name,'passed'=>(bool)$ok,'details'=>$details];echo ($ok?'PASS ':'FAIL ').$name.($ok?'':' '.json_encode($details))."\n";}
$db->query('DROP TABLE IF EXISTS wp_guard_failure');$db->query('CREATE TABLE wp_guard_failure(id INT PRIMARY KEY,n INT) ENGINE=InnoDB');for($i=1;$i<=50;$i++)$db->query("INSERT INTO wp_guard_failure VALUES($i,0)");
$sql='UPDATE wp_guard_failure SET n=n+1 WHERE id=1';$p=DatabaseAdmin::execute(['sql'=>$sql]);$GLOBALS['f3_disk_full']=true;$r=DatabaseAdmin::execute(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);$GLOBALS['f3_disk_full']=false;ck(($r['error_code']??'')==='database_backup_failed'&&(int)$db->query('SELECT n FROM wp_guard_failure WHERE id=1')->fetch_row()[0]===0,'backup_real_kernel_enospc_no_dml',['error_code'=>$r['error_code']??null]);
$p=DatabaseAdmin::execute(['sql'=>$sql]);$other->query('START TRANSACTION');$other->query('SELECT * FROM wp_guard_failure WHERE id=1 FOR UPDATE');$start=microtime(true);$r=DatabaseAdmin::execute(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);$elapsed=microtime(true)-$start;$other->rollback();ck(($r['error_code']??'')==='database_lock_timeout'&&(int)$db->query('SELECT n FROM wp_guard_failure WHERE id=1')->fetch_row()[0]===0,'real_mysql_lock_timeout',['elapsed'=>$elapsed,'error_code'=>$r['error_code']??null]);
$sql='UPDATE wp_guard_failure SET n=n+1 WHERE id<=2';$p=DatabaseAdmin::execute(['sql'=>$sql]);$other->query('START TRANSACTION');$other->query('UPDATE wp_guard_failure SET n=100 WHERE id>=2');
$hook=static function($stage,$id,$index,$connection)use($other){if($stage!=='before_locks')return;$connection->query('SELECT * FROM wp_guard_failure WHERE id=1 FOR UPDATE');$other->query('UPDATE wp_guard_failure SET n=100 WHERE id=1',MYSQLI_ASYNC);};add_action('f3_mcp_sql_checkpoint',$hook,10,4);$r=DatabaseAdmin::execute(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);remove_action('f3_mcp_sql_checkpoint',$hook,10);$read=[$other];$error=$reject=[];if(mysqli_poll($read,$error,$reject,1)>0)$other->reap_async_query();$other->rollback();ck(($r['error_code']??'')==='database_deadlock'&&(int)$db->query('SELECT SUM(n) FROM wp_guard_failure')->fetch_row()[0]===0,'real_mysql_deadlock_rollback',['error_code'=>$r['error_code']??null]);
// Mutable schema including triggers must conflict before any real DML.
$p=DatabaseAdmin::execute(['sql'=>$sql]);$db->query('CREATE TRIGGER guard_trigger BEFORE UPDATE ON wp_guard_failure FOR EACH ROW SET NEW.n=NEW.n+1');$r=DatabaseAdmin::execute(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);$db->query('DROP TRIGGER guard_trigger');ck(($r['error_code']??'')==='database_conflict'&&($r['conflict_reason']??'')==='schema_changed','new_trigger_conflicts_without_effect');
file_put_contents(dirname(__DIR__,2).'/evidencias/sql-failure-tests.json',json_encode(['scope'=>'Actual MySQL timeout/deadlock and kernel ENOSPC through test-only /dev/full redirection; not a mounted full filesystem.','checks'=>$checks],JSON_PRETTY_PRINT));exit(array_filter($checks,static fn($r)=>!$r['passed'])?1:0);
}
