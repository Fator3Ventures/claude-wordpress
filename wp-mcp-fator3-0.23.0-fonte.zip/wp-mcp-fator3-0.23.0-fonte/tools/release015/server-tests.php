<?php
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence,ConnectionContext,ServerContract,RootToolContext,AuthorizationPolicy,ConnectionStatus};
wp_set_current_user(1);$checks=[];$elementor_option=get_option('elementor_mcp_enabled','ABSENT');
function ck($ok,$name,$detail=null){global $checks;$checks[]=['test'=>$name,'passed'=>(bool)$ok];echo ($ok?'PASS ':'FAIL ').$name.($ok?'':' '.json_encode($detail,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))."\n";}
function req($route,$method,$params=[]){$r=new WP_REST_Request('POST',$route);foreach(['Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Protocol-Version'=>'2026-07-28','Mcp-Method'=>$method] as $k=>$v)$r->set_header($k,$v);if(isset($params['name']))$r->set_header('Mcp-Name',$params['name']);$params['_meta']=['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()];$r->set_body(wp_json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>$method,'params'=>$params]));$v=rest_do_request($r);return json_decode(wp_json_encode($v->get_data()),true);}
ck(($GLOBALS['f3_early_status']['registry_checked']??true)===false&&($GLOBALS['f3_early_status']['server_registered']??null)===null,'early_status_unknown_not_failed',$GLOBALS['f3_early_status']??null);
require_once ABSPATH.'wp-admin/includes/user.php';[$pass,$item]=WP_Application_Passwords::create_new_application_password(1,['name'=>'synthetic-015']);do_action('application_password_did_authenticate',wp_get_current_user(),$item);
$id='app:'.$item['uuid'];Persistence::put('connections',$id,['connection_id'=>$id,'user_id'=>1,'profile'=>'maintenance','status'=>'active']);
$listed=wp_get_ability('plugins/list')->execute(['campos'=>['plugin','version'],'prefixo'=>'wp-mcp-fator3/']);
ck(count($listed['plugins']??[])===1&&array_keys($listed['plugins'][0])===['version','plugin']&&($listed['plugins'][0]['plugin']??'')==='wp-mcp-fator3/wp-mcp-fator3.php','plugin_list_fields_prefix_aliases',$listed);
$conflict=wp_get_ability('plugins/list')->execute(['campos'=>['name'],'fields'=>['version']]);
ck((is_wp_error($conflict)&&str_contains(wp_json_encode($conflict),'alias_conflict'))||(is_array($conflict)&&($conflict['error_code']??'')==='alias_conflict'),'plugin_list_alias_conflict',$conflict);
$abilities=wp_get_abilities();$server=rest_get_server();$status=ServerContract::status();ck($status['server_registered']===true&&$status['tools_ready']===true,'own_server_generic_filter_false',$status);
ck(class_exists('Elementor\\Plugin')&&defined('ELEMENTOR_VERSION')&&ELEMENTOR_VERSION==='4.3.3','real_elementor_433_loaded');
foreach(['/mcp/wp-mcp-fator3','/mcp/wp-mcp-ultimate'] as $route){$r=req($route,'tools/list');$names=array_column($r['result']['tools']??[],'name');ck(!array_diff(['wp-mcp-ultimate-discover-abilities','wp-mcp-ultimate-get-ability-info','wp-mcp-ultimate-execute-ability','google-mcp-read','google-mcp-write'],$names),'tools_'.$route,$r);ck(count($names)===count(array_unique($names)),'tools_unique_'.$route);}
foreach(['google/mcp-read','google/mcp-write'] as $n){$a=wp_get_ability($n);ck($a&&ServerContract::google_bridge($a),'bridge_adheres_'.$n,$a?$a->get_meta():null);$r=AuthorizationPolicy::check($n,[],str_ends_with($n,'read'));ck(is_wp_error($r)&&$r->get_error_code()==='ability_executor_forbidden','not_root_'.$n);}
$r=req('/mcp/wp-mcp-fator3','tools/call',['name'=>'wp-mcp-ultimate-execute-ability','arguments'=>['ability_name'=>'google/mcp-read','parameters'=>['ability'=>'google/status']]]);ck(str_contains(json_encode($r),'ability_executor_forbidden'),'nested_google_forbidden',$r);
// Native Google permission must remain in force; without configured access this call is denied
// by the Google gate, not by the executor classification.
$r=req('/mcp/wp-mcp-fator3','tools/call',['name'=>'google-mcp-read','arguments'=>['ability'=>'google/status']]);ck(!str_contains(json_encode($r),'ability_executor_forbidden'),'direct_google_not_nested',$r);
add_filter('f3_mcp_google_enabled','__return_true');
$r=req('/mcp/wp-mcp-fator3','tools/call',['name'=>'google-mcp-read','arguments'=>['ability'=>'google/status']]);ck(($r['result']['structuredContent']['success']??false)===true,'real_google_status_through_direct_bridge',$r);
$r=req('/mcp/wp-mcp-fator3','tools/call',['name'=>'google-mcp-write','arguments'=>['ability'=>'google/create-connection','parameters'=>['id'=>'fixture_015','label'=>'Synthetic MCP 0.15 write']]]);ck(($r['result']['structuredContent']['success']??false)===true,'real_google_local_write_through_direct_bridge',$r);
Persistence::put('connections',$id,['connection_id'=>$id,'user_id'=>1,'profile'=>'read','status'=>'active']);
$r=req('/mcp/wp-mcp-fator3','tools/call',['name'=>'google-mcp-read','arguments'=>['ability'=>'google/status']]);ck(($r['result']['structuredContent']['success']??false)===true,'read_profile_google_read',$r);
$r=req('/mcp/wp-mcp-fator3','tools/call',['name'=>'google-mcp-write','arguments'=>['ability'=>'google/status']]);ck(str_contains(json_encode($r),'profile_denied'),'read_profile_refuses_write_bridge',$r);
Persistence::put('connections',$id,['connection_id'=>$id,'user_id'=>1,'profile'=>'custom','abilities'=>['google/mcp-read'],'status'=>'active']);
$r=req('/mcp/wp-mcp-fator3','tools/call',['name'=>'google-mcp-read','arguments'=>['ability'=>'google/status']]);ck(str_contains(json_encode($r),'profile_denied'),'custom_final_target_gate',$r);
Persistence::put('connections',$id,['connection_id'=>$id,'user_id'=>1,'profile'=>'maintenance','status'=>'active']);
remove_filter('f3_mcp_google_enabled','__return_true');
$a=wp_get_ability('google/mcp-read');ck(!RootToolContext::allows($a),'root_context_restored');
$original=\WpMcpUltimate\Server\DefaultServerFactory::configuration();$bad=static function($c){$c['server_route']='hijack';return $c;};add_filter('f3_mcp_default_server_config',$bad);$invalid=\WpMcpUltimate\Server\DefaultServerFactory::configuration();remove_filter('f3_mcp_default_server_config',$bad);ck($invalid['server_route']==='wp-mcp-fator3'&&$invalid['tools']===$original['tools'],'immutable_identity_invalid_filter');
$bad=static fn($c)=>'invalid';add_filter('f3_mcp_default_server_config',$bad);$invalid=\WpMcpUltimate\Server\DefaultServerFactory::configuration();remove_filter('f3_mcp_default_server_config',$bad);ck($invalid===$original,'invalid_filter_defaults');
add_filter('f3_mcp_create_default_server','__return_false');ck(ServerContract::enabled()===false&&ServerContract::status()['server_enabled']===false,'own_filter_controls_diagnostic');remove_filter('f3_mcp_create_default_server','__return_false');
update_option('f3_mcp_files_enabled',false);ck(ServerContract::status()['channel_enabled']===false,'kill_switch_status');update_option('f3_mcp_files_enabled',true);
$resources=req('/mcp/wp-mcp-fator3','resources/list');ck(count($resources['result']['resources']??[])>=7,'elementor_resources_preserved',$resources);
ck(get_option('elementor_mcp_enabled','ABSENT')===$elementor_option,'elementor_setting_untouched');
WP_Application_Passwords::delete_application_password(1,$item['uuid']);
file_put_contents(dirname(__DIR__,2).'/evidencias/server-tests-'.(getenv('F3_VARIANT')?:'default').'.json',json_encode(['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'elementor'=>defined('ELEMENTOR_VERSION')?ELEMENTOR_VERSION:null,'checks'=>$checks],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));$failed=array_filter($checks,static fn($v)=>!$v['passed']);echo count($checks).' checks, '.count($failed)." failed\n";exit($failed?1:0);
