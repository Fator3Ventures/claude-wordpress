<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;use Fator3\McpFiles\Recovery;use Fator3\RecoveryV1\Engine;
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'time'=>time()]);
$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
$root=WP_CONTENT_DIR.'/f3-crash-lab';wp_mkdir_p($root);$target=$root.'/target';$source=$root.'/candidate';$barrier=$root.'/barrier.json';
foreach(['prepared','gap','installed'] as $phase){
 foreach([$target,$source] as $p){if(file_exists($p))Engine::remove($p);mkdir($p);}
 file_put_contents($target.'/plugin.php','before');file_put_contents($source.'/plugin.php','after');@unlink($barrier);
 $cmd=[PHP_BINARY,...(php_ini_loaded_file()?['-c',php_ini_loaded_file()]:[]),__DIR__.'/recovery-worker.php',$target,$source,$barrier,$phase];$pipes=[];$process=proc_open($cmd,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
 $end=microtime(true)+10;while(!file_exists($barrier)&&microtime(true)<$end)usleep(10000);
 if(!file_exists($barrier)){proc_terminate($process,9);$err=stream_get_contents($pipes[2]);check('P06 barrier '.$phase,false,['worker_error'=>$err]);foreach($pipes as $p)fclose($p);proc_close($process);continue;}
 $info=json_decode(file_get_contents($barrier),true);$state=Engine::read($info['journal']);$state['lease_until']=time()-1;Engine::write($info['journal'],$state);
 Engine::sweep(Recovery::directory());check('P06 live lease prevents sentinel rollback '.$phase,(Engine::read($info['journal'])['status']??'')==='armed');
 proc_terminate($process,9);foreach($pipes as $p)fclose($p);proc_close($process);
 Engine::sweep(Recovery::directory());$state=Engine::read($info['journal']);check('P06 SIGKILL recovery '.$phase,($state['status']??'')==='rolled_back'&&is_file($target.'/plugin.php')&&file_get_contents($target.'/plugin.php')==='before'&&!file_exists($state['install_previous'])&&!file_exists($state['install_next']),['status'=>$state['status']??null]);
}
Engine::remove($root);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'scope'=>'SIGKILL at deterministic journal/filesystem barriers; no Apache or full-disk claim','tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/crash-0150.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
