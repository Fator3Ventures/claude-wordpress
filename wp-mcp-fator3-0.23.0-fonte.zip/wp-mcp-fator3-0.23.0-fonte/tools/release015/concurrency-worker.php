<?php
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence,DatabaseAdmin,DatabaseRead};
wp_set_current_user(1);$c=json_decode(file_get_contents($argv[1]),true);$mode=$argv[2];
if($mode==='write'){$db=DatabaseRead::connection();file_put_contents($c['started'],'1');$start=microtime(true);$r=$db->query($c['external']);$out=['success'=>$r!==false,'elapsed'=>microtime(true)-$start];file_put_contents($c['finished'],'1');echo json_encode($out);exit;}
add_action('f3_mcp_sql_checkpoint',static function($stage)use($c){if($stage==='locked'){file_put_contents($c['locked'],'1');$until=microtime(true)+10;while(!is_file($c['release'])){if(microtime(true)>$until)throw new RuntimeException('fixture_timeout');usleep(1000);}}});
$r=DatabaseAdmin::execute(['sql'=>$c['sql'],'confirm_token'=>$c['token']]);echo json_encode($r);
