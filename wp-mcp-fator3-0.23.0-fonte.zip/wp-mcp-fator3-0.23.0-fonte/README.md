# Fator3 MCP 0.23.0

Servidor MCP independente para WordPress. Instalação limpa ou atualização direta da 0.22.0. Requer WordPress 7.1.2 e PHP 8.3.

Esta versão corrige Pedidos MCP 60, diagnósticos públicos tipados e revision_conflict. A documentação instalada está disponível em system/guide, com lista, paginação por bytes e revisão/hash.

- Runtime: fontes/wp-mcp-fator3/. Identidade wp-mcp-fator3/wp-mcp-fator3.php.
- Operação e contratos: docs/OPERACAO.md e docs/RELEASE-0230.md.
- Build: python tools/sync_docs.py; python tools/build_packages.py.
- Testes e limitações: tools/release0230/README.md e relatório externo.
- Evidências próprias: evidencias/0230/. Diretórios anteriores são históricos.

Contratos server-integration/1.0.0, executor-registration/1.0.0 e package-distribution/1.0.0 mantidos. Nenhuma publicação automática de fonte, feed ou instalador. Tokens reais e bancos privados não integram o pacote.
