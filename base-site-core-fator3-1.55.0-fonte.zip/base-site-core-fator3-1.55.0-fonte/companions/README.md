# Acompanhantes para reproduzir os testes

Os runtimes dos acompanhantes não são republicados no fonte Core: pertencem a outros pacotes. O instalador Core é autônomo.

Nesta rodada a integração exercitada é com o original wp-mcp-fator3 0.33.0. Forneça seu instalador de 888204 bytes, SHA-256 `f16ee3e31e4143ffb42c566ea6da4f2da81d3771a01a0f90b5d34e3d02ac8caa`, e extraia sua pasta, sem mudanças, em companions/wp-mcp-fator3 e nos plugins do laboratório. Fonte recebido: 4585261 bytes, SHA-256 `fdef8375bd72533062dff506be52664057619655e948afa3b89e22d4114e2ed6`. Relatório recebido está em inputs/1550. Nenhum impacto novo ao Core nesta entrega MCP.

Os demais acompanhantes abaixo são bases herdadas; não houve nova homologação integral dos seus fornecedores nesta rodada. As provas anteriores permanecem identificadas por versão nos diretórios históricos.

| Pacote | Versão | Escopo desta rodada |
|---|---|---|
| wp-mcp-fator3 | 0.33.0 | Decorador real, permissões, recibos, idempotência e política tipada |
| wp-mcp-google-fator3 | 0.19.0 | Base preservada; sem teste de fornecedor |
| wp-mcp-meta-fator3 | 0.10.1 | Base preservada; sem teste de fornecedor |
| wp-mcp-linkedin-fator3 | 0.10.1 | Base preservada; sem teste de fornecedor |
| wp-mcp-pipedrive-fator3 | 0.1.0 | Base preservada; fluxo CRM do Core testado com transporte simulado |

Google 0.19.0 veio da base 1.51.0; seu instalador original está identificado pelo SHA-256 `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1`. Pipedrive completo exige PHP 8.3.36 e não deve ser ativado no laboratório PHP 8.3.6. Não confundir o pacote acompanhante com o cliente Pipedrive público do Core, cujo contrato permanece 1.0.0.
