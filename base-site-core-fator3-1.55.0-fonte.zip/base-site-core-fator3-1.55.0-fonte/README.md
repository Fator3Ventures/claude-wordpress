# Fonte Core 1.55.0

Base direta 1.54.0. Código instalável em work/plugin/base-site-core-fator3. Normas revisão 5 em inputs/1510; escopo e relatório MCP recebido em inputs/1550. Evidências desta rodada em evidence/1550; versões anteriores identificadas em seus diretórios e history. Não há credenciais ou banco de produção neste pacote.

Leia build/README.md e build/COMPANIONS.md. As suítes request-303/304/305/306 cobrem sessão administrativa, autenticação, IMAP/classificação de teste e confirmação de cache/robots. Integração exercitada com MCP original 0.33.0; o pedido 302 permanece coberto por regressões. O instalador contém somente runtime/documentação corrente. Testes, ferramentas e evidências ficam no fonte. Provas de fornecedores reais e pendências estão discriminadas no relatório externo canônico.
