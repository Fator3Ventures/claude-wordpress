# Fator3 Site Core 1.55.0

Comece em DOCUMENTACAO.md e AGENTES-1.55.0.md. Pedidos 303–306 em OPERACAO-1.55.md; contatos externos do pedido 302 permanecem em CONTATOS-EXTERNOS-1.54.md. Contrato administrativo 8.20.0, cliente pipedrive-api-client/1.0.0 preservado.
