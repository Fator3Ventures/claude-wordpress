# Validação — Core 1.55.0

Suítes da rodada: request-303 (cookies/tokens/revogação), request-304 (criptografia, SPF, DMARC e DNS adversarial), request-305-imap (protocolo/pastas), request-305 (coleta, retomada, teste/Slack/privacidade), request-306 (verificadores públicos e executor). Regressões de correio, formulários, contatos externos e gates de e-mail; MCP original 0.33.0; instalação nova e atualização direta da 1.54.0; WordPress mínimo e atual. Código e evidências sanitizadas ficam no fonte.

Fixtures não equivalem a Gmail, entrega do provedor, Slack ou CRM reais. O relatório externo final distingue ambiente e status de cada prova. A documentação instalada é testada integralmente por documentacao-ler, com paginação, hash, allowlist e autorização. Acompanhamento de cron de 24 horas na frota depende de publicação pelo dono.
