<?php
/** Explicit SMTP intent, shared recipient quota and a sent-copy checkpoint independent of SMTP. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Envio {
    public static function copias(string $to,string $smart=''): array {
        $addresses=array_merge(F3Base_Email_Site::cfg()['cco'],is_email($smart)?array($smart):array());
        return array_values(array_filter(array_unique(array_map('strtolower',$addresses)),static fn($a)=>$a!==strtolower($to)&&is_email($a)));
    }
    public static function configuracao_automatica(array $cfg): array {
        $site=F3Base_Email_Site::cfg();if(empty($site['envio_ativo'])){return $cfg;}
        return array_replace($cfg,array('remetente'=>$site['endereco'],'smtp_host'=>$site['smtp_host'],'smtp_porta'=>$site['smtp_porta'],'smtp_seguranca'=>$site['smtp_seguranca'],'smtp_usuario'=>$site['usuario'],'nome_exibicao'=>$site['nome_exibicao'],'assinatura'=>$site['assinatura'],'cota_destinatarios_hora'=>$site['cota_destinatarios_hora'],'alocacao_confirmada'=>$site['alocacao_confirmada']));
    }
    public static function senha_automatica(): string {return F3Base_Segredos::abrir(!empty(F3Base_Email_Site::cfg()['envio_ativo'])?F3Base_Email_Site_Config::SECRET:'f3base_email_novo_lead_smtp_senha');}
    public static function ultima(string $record): array {global $wpdb;$row=$wpdb->get_row($wpdb->prepare("SELECT payload FROM %i WHERE record_id=%s AND estado IN ('registrado','enviado','enviado_copia_incerta','enviado_copia_falhou') ORDER BY id DESC LIMIT 1",F3Base_Email_Site::tabela(),$record),ARRAY_A);return $row?F3Base_Contato_Comunicacao::abrir($row['payload'])??array():array();}
    public static function executar(array $e): array {
        if(!current_user_can(F3Base_Email_Site::SEND_CAP)||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $record=(string)($e['record_id']??'');$lead=F3Base_Leads_Repositorio::obter($record);$cfg=F3Base_Email_Site::cfg();
        if(!$lead||$lead['captura']!=='aceito'||$lead['lixeira']||$lead['eliminacao_pendente']||!is_email($lead['email'])){return array('ok'=>false,'codigo'=>'contato_nao_elegivel');}
        $subject=trim((string)($e['assunto']??''));$text=(string)($e['texto']??'');if($subject===''||preg_match('/[\r\n\x00]/',$subject)||mb_strlen($subject)>500||trim($text)===''||mb_strlen($text)>20000||str_contains($text,"\0")){return array('ok'=>false,'codigo'=>'email_mensagem_invalida');}
        $smart=(string)$cfg['smart_bcc'];$bcc=self::copias($lead['email'],$smart);$previous=self::ultima($record);$refs=array_values(array_unique(array_merge($previous['references']??array(),empty($previous['message_id'])?array():array($previous['message_id']))));
        $message=array('record_id'=>$record,'de'=>$cfg['endereco'],'nome_exibicao'=>$cfg['nome_exibicao'],'para'=>$lead['email'],'cco'=>$bcc,'assunto'=>$subject,'texto'=>$text."\n\n".$cfg['assinatura'],'in_reply_to'=>$previous['message_id']??'','references'=>array_slice($refs,-20));
        $revision=F3Base_Email_Site::h(wp_json_encode($message).'|'.F3Base_Options::revisao(F3Base_Email_Site_Config::OPTION).'|'.F3Base_Options::revisao(F3Base_Email_Site_Config::SECRET).'|'.F3Base_Options::revisao('f3base_pipedrive').'|'.$lead['atualizado_em']);
        if(($e['simular']??true)!==false){return array('ok'=>true,'simular'=>true,'revisao'=>$revision,'mensagem'=>$message,'destinatarios_cota'=>1+count($bcc),'envio_habilitado'=>!empty($cfg['envio_ativo']));}
        $key=(string)($e['revisao']??'');if(!preg_match('/^[a-f0-9]{64}$/D',$key)){return array('ok'=>false,'codigo'=>'revisao_obrigatoria');}
        if(!F3Base_Pipedrive_Fila::travar_linha('email-site-worker')){return array('ok'=>false,'codigo'=>'email_caixa_ocupada');}
        try{
            $old=F3Base_Email_Site::row($key);if($old){return $old['record_id']===$record?self::recibo($old,true):array('ok'=>false,'codigo'=>'conflito');}
            $current=self::executar(array_replace($e,array('simular'=>true)));if(empty($current['ok'])||!hash_equals($current['revisao']??'',$key)){return array('ok'=>false,'codigo'=>'conflito');}
            if(!empty(get_option(F3Base_Email_Site_Config::STATE,array())['reconciliacao_necessaria'])){return array('ok'=>false,'codigo'=>'email_restauracao_requer_reconciliacao');}
            if(empty($cfg['envio_ativo'])||empty($cfg['alocacao_confirmada'])||F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET)===''){return array('ok'=>false,'codigo'=>'email_envio_desligado_ou_incompleto');}
            $test=$cfg['homologacao']||$lead['classe_trafego']==='teste';if($test){$allowed=array_map('strtolower',$cfg['homologacao_emails']);if(array_diff(array_merge(array(strtolower($lead['email'])),$bcc),$allowed)){return array('ok'=>false,'codigo'=>'email_destinatario_fora_homologacao');}}
            if(!F3Base_Email_Novo_Lead::reservar_cota(1+count($bcc),(int)$cfg['cota_destinatarios_hora'])){return array('ok'=>false,'codigo'=>'email_cota_hora_excedida');}
            $message['message_id']='<'.bin2hex(random_bytes(16)).'@'.substr(strrchr($cfg['endereco'],'@'),1).'>';$message['recebida_em']=time();$message['nome']=$lead['nome'];$message['email']=$lead['email'];$message['teste']=$test;
            global $wpdb;$row=array('chave'=>$key,'contexto'=>F3Base_Email_Site_Config::identidade($cfg),'direcao'=>'saida','message_hash'=>F3Base_Email_Site::h($message['message_id']),'record_id'=>$record,'classe'=>'aceito','estado'=>'enviando','codigo'=>'smtp_reservado','payload'=>F3Base_Contato_Comunicacao::cifrar($message),'criada_em'=>time(),'atualizada_em'=>time());
            if($wpdb->insert(F3Base_Email_Site::tabela(),$row)!==1){return array('ok'=>false,'codigo'=>'email_intencao_nao_persistida');}
            // No connection or DATA is attempted before the durable sending state exists.
            $result=self::smtp($message,$cfg);$message['smtp']=$result['codigo'];
            if($result['estado']==='enviado'){
                if(!F3Base_Email_Site::patch($key,array('estado'=>'enviado','codigo'=>'smtp_aceito'))){return array('ok'=>false,'codigo'=>'email_aceite_sem_checkpoint','incerto'=>true);}
                $copyState='enviado';$code='smtp_aceito_copia_gravada';$imap=null;
                try{$imap=F3Base_Email_Site::conectar();$copyState='enviado_copia_incerta';$imap->append($cfg['pasta_enviados'],$result['mime']);$copyState='enviado';}
                catch(Throwable $x){if($copyState==='enviado'){$copyState='enviado_copia_falhou';}$code=F3Base_Email_Site::erro($x);}finally{if($imap){$imap->close();}}
                F3Base_Email_Site::patch($key,array('estado'=>$copyState,'codigo'=>$code,'movida_em'=>$copyState==='enviado'?time():0));
                F3Base_Email_Site::continuacoes();
            }else{F3Base_Email_Site::patch($key,array('estado'=>$result['estado']==='incerto'?'incerto':'falhou','codigo'=>$result['codigo']));}
            return self::recibo(F3Base_Email_Site::row($key));
        }catch(Throwable $x){return array('ok'=>false,'codigo'=>F3Base_Email_Site::erro($x),'incerto'=>isset($row));}
        finally{F3Base_Pipedrive_Fila::liberar_linha('email-site-worker');}
    }
    public static function recibo(array $r,bool $duplicate=false): array {$sent=str_starts_with($r['estado'],'enviado');return array('ok'=>$sent,'chave'=>$r['chave'],'record_id'=>$r['record_id'],'estado'=>$r['estado']==='enviando'?'incerto':$r['estado'],'codigo'=>$r['codigo'],'smtp_aceito'=>$sent,'copia_em_enviados'=>(int)$r['movida_em']>0,'duplicado'=>$duplicate,'reenvio_automatico'=>false);}
    public static function smtp(array $message,array $cfg): array {
        require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/SMTP.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';
        $mail=new \PHPMailer\PHPMailer\PHPMailer(true);$phase='preparo';
        try{
            $host=$cfg['smtp_host'];if(!wp_http_validate_url('https://'.$host.'/')){return array('estado'=>'falhou','codigo'=>'smtp_destino_invalido');}$ips=gethostbynamel($host)?:array();if(!$ips){return array('estado'=>'falhou','codigo'=>'smtp_dns_indisponivel');}foreach($ips as $ip){if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)){return array('estado'=>'falhou','codigo'=>'smtp_destino_invalido');}}
            $mail->isSMTP();$mail->Host=$ips[0];$mail->Port=(int)$cfg['smtp_porta'];$mail->SMTPSecure=$cfg['smtp_seguranca'];$mail->SMTPOptions=array('ssl'=>array('verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>$host,'allow_self_signed'=>false));$mail->SMTPAuth=true;$mail->Username=$cfg['usuario'];$mail->Password=F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET);$mail->Timeout=8;$mail->Timelimit=15;$mail->SMTPDebug=0;$mail->CharSet='UTF-8';$mail->MessageID=$message['message_id'];$mail->MessageDate=gmdate('D, d M Y H:i:s O',$message['recebida_em']);
            $mail->setFrom($cfg['endereco'],$cfg['nome_exibicao']);$mail->addAddress($message['para']);foreach($message['cco'] as $address){$mail->addBCC($address);}$mail->Subject=$message['assunto'];$mail->isHTML(false);$mail->Body=$message['texto'];
            if($message['in_reply_to']!==''){$mail->addCustomHeader('In-Reply-To',$message['in_reply_to']);}if($message['references']){$mail->addCustomHeader('References',implode(' ',$message['references']));}
            if(!$mail->preSend()||!$mail->smtpConnect()){return array('estado'=>'falhou','codigo'=>'smtp_conexao_recusada');}
            $mime=$mail->getSentMIMEMessage();$phase='data';$r=F3Base_Email_Novo_Lead::envelope($mail->getSMTPInstance(),$mime,array_merge(array($message['para']),$message['cco']),$cfg['endereco']);return $r+($r['estado']==='enviado'?array('mime'=>$mime):array());
        }catch(Throwable $x){return array('estado'=>$phase==='data'?'incerto':'falhou','codigo'=>$phase==='data'?'smtp_sem_confirmacao':'smtp_preparo_ou_conexao_falhou');}finally{$mail->smtpClose();}
    }
}
