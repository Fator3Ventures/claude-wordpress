# Core 1.83.0 · 13/11/2026

O bot do Slack precisa de files:read para conferir a imagem compartilhada. As opções do painel e o contrato administrativo mantêm os valores gravados. Consulte RELEASE-1.83.0.md.

# Core 1.80.0 · 10/11/2026

Nenhuma option, padrão ou regra de validação mudou. A tela Site Core → Configurações tem layout novo: índice da área, barra de salvar fixa e um rótulo por campo. Seis itens de estrutura própria deixaram de ser campo do formulário e aparecem só para leitura; com isso Coleta do site, Conteúdo e IA e SEO voltam a gravar. Conversões de material, transporte das conversões, navegação e consultas do Search Console voltam a aceitar alteração de uma chave por vez. Consulte GUIA-PAINEL.md, RELEASE-1.79.0.md e AGENTES-1.79.0.md.

# Core 1.78.0 · 10/11/2026

Autoria de WebPage no Yoast, filtro de caminhos do reaquecimento e HTTP 404 no diretório de atualização. Consulte RELEASE-1.78.0.md e AGENTES-1.78.0.md.

# Core 1.77.0 · 10/11/2026

Alvos por classe no editor, origem de anúncios em contatos sem sessão e formulário em duas etapas. Consulte RELEASE-1.77.0.md e AGENTES-1.77.0.md.

# Core 1.76.0 · 09/11/2026

Transporte CAPI em teste, decisão por PageView e retorno de etapas CRM de formulários nativos. Consulte RELEASE-1.76.0.md e AGENTES-1.76.0.md.

Core 1.75.1 · Consulte RELEASE-1.75.1.md para a política de abandono, pixels adicionais, tetos de cliques, e-mail e cadência.


Abra Site Core → Configurações para ajustar o plugin e Site Core → Relatórios para consultar a medição. GUIA-PAINEL.md apresenta os caminhos e os controles de cada área.

> Vigente em 1.62.0: contrato 8.27.0; pedidos 348–351 em RELEASE-1.62.0.md e CAMPANHAS-MARCAS-PERFIL-1.62.md. As notas atuais prevalecem nos pontos alterados.

> Atualização vigente: Core 1.60.0, contrato 8.24.0. Leia RELEASE-1.60.0.md e os guias 1.60 para as alterações dos pedidos 322 e 330–334; as regras anteriores incompatíveis são históricas.

> Consolidação 1.57.1: leia RELEASE-1.57.1.md para as correções e campos opcionais dos pedidos 312/313. Base direta canônica 1.57.0.

> Atualização 1.57.1: pedidos 312/313 em RELEASE-1.57.1.md, ACERVO-GA4-1.57.md e INSTAGRAM-EXCLUSAO-1.57.md. Esses documentos prevalecem sobre limites anteriores de integração Instagram/GA4.

# Configuração — Core 1.57.1

Contrato 8.22.1. Instalação nova ou atualização direta da 1.54.0 com preferências preservadas. Guia RELEASE-1.57.1.md; ajuda por campo AJUDA-OPCOES.md.

## Onde operar

O menu **Site Core** contém Configurações, Informações técnicas e a aba Operação. O menu Contatos centraliza a caixa de entrada, os formulários e o conteúdo privado. A aba Operação contém a política de opções e as operações já oferecidas pelo Core.

A configuração salva por seção usa revisão esperada. Uma escrita concorrente deve ser relida e reaplicada conscientemente; não substitua a revisão pelo valor novo sem conferir as alterações.

## Controles

Entrega do índice e Modo de consentimento usam seletores com os valores do catálogo. Os valores aceitos também são declarados pelo contrato de configuração. Não envie rótulos traduzidos no lugar das chaves.

Blocos de interface excluídos da conversão usam caixas de seleção dos blocos registrados. A busca apenas filtra a exibição e não desmarca valores. Um bloco salvo que esteja temporariamente indisponível continua listado e marcado. É possível acrescentar um identificador `namespace/bloco` registrado apenas na página pública. Desmarcar todos grava lista vazia.

## Contato

| Grupo | Ajuste | Efeito |
|---|---|---|
| Registro e avisos | Quem recebe os avisos internos | Até cinco e-mails da equipe. A lista específica do formulário prevalece quando declarada. |
| Registro e avisos | Enviar aviso interno de clique | Controla o aviso, inclusive de clique sem nome/e-mail; não desliga o registro. |
| Registro e avisos | Enviar aviso interno de formulário recebido | Avisa após persistir um envio aceito; falha de e-mail não perde o registro. |
| WhatsApp | Flutuante, número e mensagem | Configura o destino do WhatsApp e seu botão flutuante. Links próprios dos CTAs são respeitados. |
| Instrumentação | Classes adicionais de botões de contato | Uma classe CSS por linha, sem ponto; instrumenta o clique sem mudar seu destino. |

As chaves existentes continuam `email_leads`, `avisar_por_clique`, `avisar_por_formulario` e `classes_cta`, dentro de `f3base_contato`. As notificações internas continuam limitadas e com resumo de pendências. O estado do aviso é independente da captura e da resposta ao visitante.


## Permissões e gestão por agentes

Em Site Core → Operação, **Configurações editáveis** oferece Todas, Somente as selecionadas e Nenhuma. A seleção é substituída integralmente ao salvar: desmarcar revoga edição, sem alterar o valor configurado. Desmarcar todos em uma seleção salva Nenhuma. O administrador mantém acesso à própria gestão para reabrir permissões.

Use **Conferir seleção** para visualizar acréscimos e remoções sem gravar. **Salvar permissões** aplica a revisão exibida. Uma edição concorrente mantém o rascunho e exibe conflito; confira o estado salvo antes de tentar novamente.

O segundo formulário contém **Permitir que agentes alterem estas permissões** e **Salvar alteração**. É uma caixa de seleção persistente e reversível, com estado salvo e aviso de alteração não salva. Desligá-la impede a edição remota da política; a lista atual continua valendo para edições de configuração. Não é um interruptor geral de REST/MCP.

Os formulários têm nonces e revisões independentes. Funcionam sem JavaScript. Em site novo, a gestão vem ativa e o modo é Todas. Atualizações não reativam escolhas desligadas: a política estruturada da 1.16.0 é preservada integralmente, inclusive Nenhuma e seleções vazias.

## Sub-abas e precedência

Contato; Medição e anúncios; Consentimento; Privacidade e segurança; Conteúdo e IA; SEO. A URL mantém a sub-aba (`secao`) e o formulário salva apenas aquele grupo, com revisão. A ajuda “Como funciona e exemplo” apresenta funcionamento, escolha, vantagens, limitações, exemplo e significado do vazio. Campo ausente herda; false, zero e lista vazia explícitos prevalecem quando válidos no schema.

`f3base_contato.email_leads` é preenchido uma única vez pelo e-mail de administração se a chave não existe. Uma lista vazia já gravada não é preenchida. A alteração posterior do endereço de administração não muda o destino comercial; o atalho da tela preenche um rascunho para revisão. Lista própria vazia do formulário não herda a geral.

`f3base_llms.entrega` ausente usa `arquivo_gerado`. Uma escolha dinâmica anterior é preservada. Geração, arquivo, regras de cabeçalhos e prova pública têm estados independentes. A preferência de cabeçalhos não grava .htaccess automaticamente; faça a operação explícita.

As políticas de carga de Google, Meta e LinkedIn respeitam consentimento, destino configurado, gesto e teto declarados. Não se recomenda escolher disparo antes de confirmar necessidade e custo. O perfil integral `perfis/piso-padrao-3.6.json` avalia o piso recebido sem escrever configurações. Divergências e exceções são explícitas; cada site conserva suas decisões até uma operação autorizada.

Em Operação, a cadência mostra agendamento e último demonstrativo sem disparar consulta/envio ao abrir a tela. Valores `nenhuma`/zero são preservados; uma leitura não inventa frequência nova.

## Escrita parcial e ofertas

Na mescla, objetos preservam folhas não enviadas; listas enviadas substituem a lista inteira. A validação cobre o delta e dependências de domínio, como país/CNPJ. Um erro antigo independente aparece em diagnóstico e não bloqueia a alteração de outro campo. `false`, `0`, `""` e `[]` explícitos não são herança. Consulte `erros`, `avisos`, `valor_bruto_valido`, `heranca_status` e `chaves_herdadas`.

`servicos[]` e `servicos[].ofertas[]` têm schema fechado de escrita. Chaves extras antigas não são apagadas ao ler nem em alterações independentes. Para substituir uma lista, confira os caminhos recusados e `campos_removidos` na simulação. O Core não decide o significado de `publico`, não cria audience nem remove a chave automaticamente. A tela agrupa ofertas por serviço e plano, mostra página/evidência e mantém JSON no controle avançado. Leia OFERTAS.md.

## Navegação explícita

Em Conteúdo e IA selecione **Pelo tema**, **Menu clássico** ou **Bloco de navegação**. A busca retorna ID e título, com paginação. Exemplo: `{"schema":1,"tipo":"menu_classico","id":92}` aceita o termo `nav_menu` 92 existente; o mesmo número como bloco exige um post `wp_navigation` publicado. `tipo:tema` usa `id:0`.

O menu existente pode ser selecionado sem criar bloco órfão. O Core valida e descreve a referência, mas não muda localizações do tema nem prova que o menu selecionado aparece no cabeçalho. Uso observado e configuração válida são estados diferentes. `f3base_nav_id` só projeta o ID de bloco para leitura; escrita deve usar a opção estruturada. Na migração, um ID positivo antigo conserva a intenção de bloco; referência inválida fica pendente, sem conversão por tentativa.

## Integrações

Site Core → Configurações → Conexões e entregas organiza Pipedrive, Origens de anúncios e Entregas. A configuração utiliza revisão e credencial separadas. Salvar agenda verificação; a tela não faz chamadas externas ao abrir. Catálogos verificados abastecem os seletores de campos; os mapas de alternativas por ID ficam no editor avançado. Token vazio mantém o atual, Apagar credencial revoga a cópia local. Padrão global desligado; o checkbox do formulário só tem efeito quando o módulo está ativo.

Todos os textos “Como funciona e exemplo” são distribuídos em `docs/dados/ajuda-opcoes.json` e `AJUDA-OPCOES.md`, gerados da mesma fonte usada na interface/contrato. Valores pré-definidos usam seleção; JSON permanece para estruturas avançadas e mapas, com validação no servidor.


## Conexões atuais

Credenciais: CREDENCIAIS-1.51.md. Cliente Pipedrive: PIPEDRIVE-OPERACAO.md; autorização por site desligada por padrão. E-mail novo lead: integracao=f3base_email_novo_lead, somente conteúdo configurado no site. Limpeza dos resíduos: simular e aplicar email-legado-limpar com revisão; não é realizada ao salvar configuração.


## Atualização 1.53.0

Pedidos 299–301 e contrato 8.18.0: EMAIL-SITE-1.53.md documenta caixa, cinco abilities, tabela, retenção e restauração; FORMULARIOS-SINAIS-1.53.md documenta a quarta isca e a política de suspeita/aviso. RELEASE-1.57.1.md reúne as mudanças. A configuração de unidade Pipedrive é obrigatória para reutilizar ou criar oportunidade.

Sessão de administrador e campos de autenticação/teste de e-mail: OPERACAO-1.55.md.


## Atualização 1.73.0

Modo de Lead por site/formulário: f3base_meta_lead. Códigos de falhas IMAP passageiras: f3base_avisos_tecnicos.imap_codigos_passageiros. Simule as alterações e preserve a revisão esperada. Consulte RELEASE-1.73.0.md para exemplos, condições e prova de token CAPI por evento.