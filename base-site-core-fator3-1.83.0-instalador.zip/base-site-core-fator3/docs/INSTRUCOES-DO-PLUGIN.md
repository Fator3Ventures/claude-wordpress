# Instruções do plugin — Core 1.83.0

Este documento diz como operar o Fator3 Site Core 1.83.0 (contrato administrativo 8.39.0). O índice de todos os documentos está em DOCUMENTACAO.md. Versões anteriores aparecem só na seção final "Histórico".

## Regra principal

O Core já cuida de medição, consentimento, contatos, `llms.txt`, redirects, cabeçalhos, noindex e schema. Para mudar o comportamento, grave a opção do Core pelo canal dele. Não instale outro plugin para a mesma função, não edite o tema e não crie uma segunda tag de medição por fora. A ability `f3base/como-usar` lista o que o Core faz, por onde mudar cada coisa e o que não fazer.

## Quem pode operar

- As abilities do Core exigem a capacidade `manage_options` por padrão (parâmetro `$cap` de `F3Base_Servicos::ability`). Algumas abilities de contatos exigem também `f3base_ler_leads` ou `f3base_gerir_leads`; o requisito de cada uma está no documento do assunto e no schema.
- `f3base/documentacao-ler` exige `manage_options` e devolve `sem_permissao` sem ela.

## Sequência de trabalho

1. Descobrir: leia `f3base/como-usar` e `f3base/documentacao-ler` (sem argumentos devolve o índice).
2. Ler o estado: `f3base/config-core-ler` devolve valores operáveis, revisão opaca, origem e schema; segredos saem mascarados. `f3base/config-core-contrato-v1` devolve o catálogo de tipos, limites, padrões e dependências. `f3base/saude-ler`, `f3base/integracoes-ler` e `f3base/resumo-operacional-ler` não executam verificação nem correção.
3. Simular: `f3base/config-core-escrever` simula por padrão. Envie o valor completo e a revisão lida; `mesclar=true` permite alteração parcial de opções compostas.
4. Aplicar: repita a chamada com a simulação desligada. A resposta separa `persisted`, `effect` e `verification`; confira os três. `ok` existe por compatibilidade e não substitui essa conferência.
5. Verificar: `f3base/config-core-verificar` consulta ou executa a verificação do Core.

Se o Core recusar a gravação, não escreva a opção por outro caminho nem altere o tema.

## Duas pontes de configuração diferentes

- Site (`scope: site_configuration`): `f3base/config-core-ler`, `f3base/config-core-escrever` e `f3base/config-core-verificar`.
- Implantador (`scope: installer_json`): `f3base/config-ler` e `f3base/config-escrever` leem e gravam os JSONs do implantador (`config/projeto.json` e `config/site.json`) e não aplicam configuração no site (`aplica_no_site: false`).

## Credenciais

`f3base/credenciais-ler` devolve identidades e ajuda, nunca o valor. `f3base/credenciais-verificar` verifica uma credencial candidata sem gravar; a mudança de identidade exige confirmação. Segredos gerenciados ficam cifrados com `sodium_crypto_secretbox`. Validar o formato e confirmar o acesso no fornecedor são operações distintas.

## Efeitos externos

Abilities de leitura marcadas como locais não consultam fornecedores. Abilities que enviam, reenviam, reconciliam ou apagam têm simulação ou prévia e exigem a revisão lida; o texto de cada uma está em REFERENCIA-ABILITIES.md e no schema. Resultado incerto não autoriza repetir um envio externo: reconcilie antes.

## Recuperação e operação

Restauração de backup, pausa e retomada estão em OPERACAO-E-RECUPERACAO.md. Contratos e códigos de resposta estão em CONTRACTS.md. Como conferir uma instalação está em VALIDACAO.md.

## Histórico

Os guias por versão (`AGENTES-<versão>.md`, `RELEASE-<versão>.md`) descrevem as bases de cada release. Só os de 1.83.0 descrevem a release instalada. Os parágrafos das versões 1.57.1 a 1.72.1 que esta página trazia foram retirados porque não foram reconferidos contra o código da 1.80.0. As notas de cada versão estão nos arquivos dela.
