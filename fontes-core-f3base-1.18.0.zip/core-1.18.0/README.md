# Fontes — F3 Base Core 1.18.0

`fontes/plugin/` é o conteúdo instalável. `suite/versao-1180/` contém testes e evidências desta release; `suite/build-assets/` fixa a compilação dos assets. `referencias/` contém somente o instalador real 1.17.0 para a bancada. Executáveis, banco, runtime, node_modules e credenciais não acompanham o pacote.

Leia `fontes/plugin/docs/VALIDACAO.md`, `MAPA-ENTREGA-1.18.md` e `OPERACAO-E-RECUPERACAO.md`. A suíte exige laboratório descartável; não executar fixtures em produção. Sem downgrade. Para construir: `python3 montar-release.py --saida /DESTINO`. Para fechar após os testes: `python3 fechar-release.py --saida /DESTINO`. Não há publicação automática.
