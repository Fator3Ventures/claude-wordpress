# Escopo implementado — 1.18.0

Solicitação: implementar os ajustes avaliados após a conferência da 1.17.0. Base única 1.17.0 concluída ou site novo; sem tema, implantador, downgrade ou teste em korvena.net.br.

# Mapa da entrega — 1.18.0

Base: Pendências do site-core após a 1.17.0, conferência de 29/09–30/09. Implementado descreve o pacote local; aceites externos não são marcados como concluídos. Linhas referem-se aos arquivos desta entrega.

| Pedido | Disposição | Resultado e limite | Arquivo:linha | Teste / aceite |
|---|---|---|---|
| 89 / 83 | Implementado | Catálogo público, queries estruturais, reparo de aliases, barra final e descoberta separada; sem preencher IDs antigos por suposição. | `includes/class-f3base-editorial.php:89` | revisao.json; editorial.json; integridade.json |
| 50 / 86 | Implementado; aceite real aberto | Componentes de fontes antigas arquivados antes da publicação independente. Recibo transacional protege retomada. Dias e horas atuais deixam de depender de lacuna antiga. | `includes/class-f3base-acessos-legado.php:22` | revisao.json; fronteiras.json; conferir logs da frota |
| 90 / 81 | Implementado | OAuth/MCP operacional excluído; grupo de automação genérica separado dos identificados e consultável. | `includes/class-f3base-agentes.php:62` | revisao.json; ux-editorial.json |
| 91 — P32 | Implementado | Compara tipos editoriais como conjunto, sem alterar arrays ordenados gerais. | `includes/class-f3base-config-perfil.php:81` | revisao.json |
| 91 — consentimento | Implementado | Estado degradado somente quando a opção realmente falta ou existe problema efetivo; default explícito é configuração válida. | `includes/class-f3base-modulo-consentimento.php:143` | diagnosticos-1180.json |
| 91 — Markdown | Implementado | Incompleto já avaliado: 404 sem retry e HTML alternativo; preparo ainda pendente: 503 com retry. | `includes/class-f3base-modulo-llms-markdown.php:83` | http-1180.json |
| 42 | Implementado | Aviso e orientação para referência configurada não observada; navegação inline sugere administração pelo tema, sem modificar o tema. | `includes/class-f3base-navegacao.php:54` | diagnosticos-1180.json |
| 61 | Documentado; demais correções da base preservadas | Contrato explica QUERY_STRING intacta e reposição nativa restrita à atribuição. | `includes/class-f3base-redirects-servico.php:1` | http.json; redirects-bordas.json; docs/CONTRACTS.md |
| 66 | Implementado no texto pendente | Ajuda de full alinhada ao padrão true. Contagem do schema e remoção de código morto permanecem da base. | `includes/trait-f3base-options-catalogo.php:650` | fechamento.json; docs/AJUDA-OPCOES.md |
| 76 | Implementado com limite | Anotações aplicadas por padrão e editáveis/removíveis com revisão/auditoria; vale para relatórios e CSV. Não reclassifica histórico sem sinal nem exclui dias automaticamente. | `includes/class-f3base-inteligencia.php:124` | revisao.json; diagnosticos-1180.json; ux-editorial.json |
| 78 | Implementado | Onze origens IA em catálogo de dados versionado, aliases e fronteiras de host. Sinal pago preserva prioridade. | `includes/class-f3base-audiencia.php:25` | revisao.json; docs/dados/origens-ia.json |
| 80 | Implementado com finalidade não confirmada explícita | Meta ExternalFetcher/WebIndexer, DuckAssistBot, MistralAI-User, cohere-ai e YouBot nomeados. Assinaturas sem finalidade confirmada e Bytespider permanecem genéricos. | `includes/class-f3base-modulo-acessos-servidor.php:183` | dados/robos-conhecidos.tsv; docs/dados/robos-catalogo.json; fontes-publicas.json |
| 82 | Listas ampliadas; DNS reverso adiado | Perplexity ×2, Bing e DuckAssistBot adicionados. Confiança no IP é opção do site; compatibilidade não autentica robô. DNS requer projeto assíncrono específico. | `includes/class-f3base-redes-robos.php:26` | diagnosticos-1180.json; editorial.json |
| 87 | Implementado com limites | Saúde administrativa informa ausência recente, dias sem sinais de consumo e falha operacional observada. Retenção existente preservada; não promete coleta sem lacunas. | `includes/class-f3base-medicao-saude.php:6` | diagnosticos-1180.json; revisao.json; ux-editorial.json |
| 79 / 88 | Base preservada e UX ampliada | Conteúdo, sessões, jornada, IA, CSV e fuso; gerenciamento de exclusões, grupos de robôs e saúde. Amostra real permanece aceite do site. | `includes/class-f3base-medicao-editorial-ui.php:117` | editorial.json; ux-editorial.json; capturas PNG |
| 17 | Preservado; homologação externa | Pipedrive e ads existentes não são ativados; CRM-A01…A15 dependem de conta autorizada. Novo webhook comercial e confirmação por URL não entram nesta correção. | `includes/class-f3base-pipedrive-fila.php:166` | crm.json; capi.json; credenciais.json; origens.json |
| 38 | Sem alteração; limitação mantida | Não alterar captura apenas para ocultar requisição no PSI. Prazo existente preservado, sem nova medição nem promessa de ganho. | `includes/class-f3base-analise.php:87` | sintaxe-build.json; assets iguais à base |
| 52 | Aceite operacional aberto | Período de sete dias até 05/10 não é substituído por teste sintético. Sem acesso a korvena.net.br. | `includes/class-f3base-analise.php:106` | Aceite externo, sem alegação de conclusão |
| 85 | Contrato preservado; fonte externa necessária | Importação GSC já existe; conta, autorização e envio de fotografias reais são necessários. Nenhum novo OAuth/conector foi incluído. | `includes/class-f3base-inteligencia.php:146` | editorial.json; integridade.json |
| 45; 43; 32; 25; 9; 56 | Fora da correção atual ou aceite do site | Configuração de painel do tema, retirada de filtros do tema e aceites operacionais continuam por site. Sem alterações no implantador/tema. | `includes/class-f3base-configuracao-atual.php:49` | HTTP e regressões locais não encerram aceites externos |

Os itens resolvidos na 1.17.0 são preservados como base, sem nova alegação de implementação. Datas antigas não são excluídas por presunção de teste: um operador deve registrar o período comprovado. Retenções curtas, opções desligadas, listas vazias e decisões sobre confiança de IP permanecem.

## O que muda em cada site

- Banco: cria `{prefixo}f3base_acessos_legado`. As tabelas de catálogo/rotas são reparadas em lotes; agregados antigos conectados a fontes reprocessadas são arquivados e retirados dos totais correntes, sem apagar eventos ou leads. Não se inventa identidade histórica. Retenção do arquivo segue os logs diários.
- Options: cria checkpoint `f3base_release_1180`; acrescenta somente `f3base_medicao_editorial.aplicar_anotacoes=true` quando ausente, com procedência padrão. Catálogo e processamento atualizam seus estados técnicos. Listas vazias, `false`, destinatários, credenciais, tempo ativo e política permanecem. O preenchimento de defaults é auditável no checkpoint.
- Configuração de cache: nenhum novo parâmetro, exclusão ou requisito em `wp-cache-config.php`; `oppref` e exclusões existentes permanecem. Nenhuma nova diretiva no bloco `F3BASE MANAGED`. Regras existentes podem ser verificadas/reaplicadas pelo ciclo normal da instalação.
- Arquivos externos: nenhuma migração nova de robots, reserva privada ou anexos. Instalação nova continua provisionando a pasta privada. Arquivos já gerenciados seguem os serviços existentes.
- Execução: reparo editorial e releitura de logs disponíveis são agendados; podem precisar de mais de uma passagem do executor. Verificar cobertura e cursor, sem interpretar lacuna como zero. Quatro listas públicas adicionais são atualizadas na cadência existente, fora da visita pública.
- Frontend: nenhum JavaScript ou beacon novo, nenhum novo cookie e nenhum aumento da captura de dados pessoais. O diagnóstico adicional roda na consulta administrativa; a atualização/reconciliação usa recursos do servidor fora do caminho do visitante.
- Documentação: acompanha o instalador em `docs/`, com contrato 4.2.0, dicionário do banco, catálogos, exemplos de serviços, mapa por item, limites e recuperação. Disponível ao agente por leitura dos arquivos e `f3base/documentacao-ler`.

## Instalação e recuperação

Instale o ZIP pelo WordPress sobre uma 1.17.0 concluída ou em site novo. Confirme `f3base_release_1180.concluido_em`, execute pendências e confira saúde, reparo do catálogo e cobertura dos logs. A interface pode mostrar dados pendentes até concluir os lotes. Faça as anotações dos períodos de teste conhecidos, quando cabíveis, e compare com o filtro desligado.

Recuperação é retomada na própria versão: reinstalar os mesmos arquivos, corrigir a causa apontada e executar a atualização/pendências novamente. **Downgrade não é suportado.** Não apagar options/checkpoints para forçar origem nova. Backups operacionais permanecem responsabilidade da instalação. O pacote não foi publicado no GitHub nem implantado na frota nesta entrega; o ZIP local e as somas são o material para essa publicação.
