from pathlib import Path
import zipfile,json,hashlib
root=Path(__file__).resolve().parents[2];out=root.parents[1]/'deliverables/1.18.0';plugin=root/'fontes/plugin';manifest=json.loads((out/'manifesto-1.18.0.json').read_text());checks={}
with zipfile.ZipFile(out/'base-site-core-fator3-1.18.0.zip') as z:
 checks['estrutura_wordpress']=all(x.startswith('base-site-core-fator3/') and '..' not in x.split('/') for x in z.namelist())
 checks['manifesto_completo']=len(z.namelist())==len(manifest['arquivos'])
 checks['bytes_iguais_a_fonte_validada']=all(z.read('base-site-core-fator3/'+r['arquivo'])==(plugin/r['arquivo']).read_bytes() for r in manifest['arquivos'])
 checks['sha256_por_arquivo']=all(hashlib.sha256(z.read('base-site-core-fator3/'+r['arquivo'])).hexdigest()==r['sha256'] for r in manifest['arquivos'])
 checks['documentacao_instalada']=all('base-site-core-fator3/docs/'+n in z.namelist() for n in ['DOCUMENTACAO.md','MEDICAO-1.18.md','MAPA-ENTREGA-1.18.md','VALIDACAO.md','dados/contrato.json'])
 checks['sem_fixture_no_instalador']=not any('/suite/' in x or '/referencias/' in x or 'wp-config.php' in x for x in z.namelist())
 for name in z.namelist():
  if name.endswith('base-site-core-fator3.php'):checks['versao_1180']=b'1.18.0' in z.read(name)
checks['somas_dos_artefatos']=all(hashlib.sha256((out/name).read_bytes()).hexdigest()==sha for sha,name in (line.split('  ',1) for line in (out/'SHA256SUMS-1.18.0.txt').read_text().splitlines()))
with zipfile.ZipFile(out/'fontes-core-f3base-1.18.0.zip') as z:checks['fontes_mesmo_plugin']=all(z.read('core-1.18.0/fontes/plugin/'+r['arquivo'])==(plugin/r['arquivo']).read_bytes() for r in manifest['arquivos'])
f=[k for k,v in checks.items() if not v];result={'checks':checks,'falhas':f,'arquivos_plugin':len(manifest['arquivos'])};(Path(__file__).parent/'evidencias/pacote.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result));assert not f
