<?php
require __DIR__.'/bootstrap.php';
$checks=[];$details=[];function ck($k,$v,$d=null){global $checks,$details;$checks[$k]=(bool)$v;if(!$v){$details[$k]=$d;}}
$nav=get_option('f3base_navegacao');$proof=get_option('f3base_nav_prova');$consent=get_option('f3base_consentimento');$id=0;
try {
 $id=wp_insert_post(['post_type'=>'wp_navigation','post_status'=>'publish','post_title'=>'Fixture navegação 1180','post_content'=>'<!-- wp:navigation-link {"label":"Home","url":"/"} /-->']);
 F3Base_Options::gravar('f3base_navegacao',['schema'=>1,'tipo'=>'bloco','id'=>$id]);
 $context=(new ReflectionMethod(F3Base_Navegacao::class,'contexto_prova'))->invoke(null);
 F3Base_Options::atualizar_estado('f3base_nav_prova',static fn()=>['em'=>time(),'contexto'=>$context,'estado'=>'observada','referencias'=>[['tipo'=>'bloco','id'=>0,'inline'=>true]]]);
 $r=F3Base_Navegacao::diagnostico();ck('inline_avisa_incompatibilidade',in_array('navegacao_inline_administrada_pelo_tema',$r['warnings'],true)&&$r['uso_no_cabecalho']==='nao_comprovado',$r);ck('inline_orienta_tema',str_contains($r['orientacao'],'ID zero'));ck('referencia_nao_alterada',F3Base_Options::ler('f3base_navegacao')['id']===$id);
 $c=F3Base_Options::catalogo()['f3base_consentimento']['padrao'];$w=F3Base_Options::gravar('f3base_consentimento',$c,F3Base_Options::ORIGEM_PADRAO);ck('consentimento_gravado',!empty($w['persisted']));
 $module=new F3Base_Modulo_Consentimento();$r=(new ReflectionMethod($module,'calcular_estado'))->invoke($module);ck('padrao_explicito_nao_degradado',($r['estado']??'')==='ativo',$r);
 $net=F3Base_Redes_Robos::FONTES;ck('listas_adicionais',isset($net['perplexitybot'],$net['perplexity-user'],$net['bingbot'],$net['duckassistbot']),array_keys($net));
 foreach(glob(__DIR__.'/evidencias/fonte-*.json.txt') as $file){$r=F3Base_Redes_Robos::validar(file_get_contents($file));ck('json_oficial_'.basename($file),is_array($r)&&count($r['prefixos'])>0);}
 wp_set_current_user(0);ck('saude_requer_permissao',F3Base_Medicao_Saude::consultar()['codigo']==='sem_permissao');ck('legado_requer_permissao',F3Base_Acessos_Legado::consultar()['codigo']==='sem_permissao');ck('exclusao_requer_permissao',F3Base_Inteligencia::anotacao_excluir(['id'=>1,'revisao'=>1])['codigo']==='sem_permissao');
} finally {
 wp_set_current_user(1);if($id){wp_delete_post($id,true);}update_option('f3base_navegacao',$nav);update_option('f3base_nav_prova',$proof);update_option('f3base_consentimento',$consent);
}
$failed=array_keys(array_filter($checks,static fn($v)=>!$v));echo wp_json_encode(['checks'=>$checks,'falhas'=>$failed,'detalhes'=>$details],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);exit($failed?1:0);
