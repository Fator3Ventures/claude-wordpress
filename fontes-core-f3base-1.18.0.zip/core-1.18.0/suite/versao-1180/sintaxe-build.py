"""Static syntax and reproducible assets, without starting WordPress."""
from pathlib import Path
import os,subprocess,json,concurrent.futures
suite=Path(__file__).resolve().parent;root=suite.parents[1];plugin=root/'fontes/plugin';workspace=Path(os.environ['F3BASE_TEST_WORKSPACE'])
env=os.environ|{'LD_LIBRARY_PATH':str(workspace/'runtime1150/root/usr/lib/x86_64-linux-gnu')}
files=list(plugin.rglob('*.php'))+list(suite.glob('*.php'));js=list(plugin.rglob('*.js'))
def check(p):
 command=[str(workspace/'runtime1150/php'),'-l',str(p)] if p.suffix=='.php' else ['node','--check',str(p)]
 r=subprocess.run(command,env=env,capture_output=True,text=True)
 return None if r.returncode==0 else {'arquivo':str(p.relative_to(root)),'erro':r.stderr+r.stdout}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:fail=[x for x in pool.map(check,files+js) if x]
build=subprocess.run(['node',str(root/'suite/build-assets/build.cjs'),str(plugin),'--check'],capture_output=True,text=True)
try:result=json.loads(build.stdout)
except ValueError:result={'ok':False,'erro':build.stderr+build.stdout}
out={'php':len(files),'js':len(js),'falhas':fail,'build':result};(suite/'evidencias/sintaxe-build.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out));raise SystemExit(bool(fail) or build.returncode)
