from pathlib import Path
import os,subprocess,shutil,json
root=Path(os.environ['F3BASE_TEST_WORKSPACE']);suite=Path(__file__).resolve().parent;plugin=suite.parent.parent/'fontes/plugin';site=Path(os.environ['F3BASE_SITE']);out=root/'work/docs1180-geradas';out.mkdir(exist_ok=True)
shutil.copytree(plugin,site/'wp-content/plugins/base-site-core-fator3',dirs_exist_ok=True)
env=os.environ|{'F3BASE_DOCS_OUT':str(out)}
r=subprocess.run([str(root/'runtime1150/php'),str(suite/'documentar.php')],env=env,capture_output=True,text=True,check=True);print(r.stdout,flush=True)
for name in ['contrato.json','ajuda-opcoes.json']:shutil.copy2(out/name,plugin/'docs/dados'/name)
shutil.copy2(out/'AJUDA-OPCOES.md',plugin/'docs/AJUDA-OPCOES.md')
r=subprocess.run([str(root/'runtime1150/php'),str(suite/'documentar-catalogo.php')],env=env,capture_output=True,text=True,check=True);(plugin/'docs/REFERENCIA-CATALOGO.md').write_text(r.stdout)
print(json.dumps({p.name:p.stat().st_size for p in (plugin/'docs').rglob('*') if p.is_file() and p.stat().st_size>450000}),flush=True)
shutil.copytree(plugin,site/'wp-content/plugins/base-site-core-fator3',dirs_exist_ok=True)
