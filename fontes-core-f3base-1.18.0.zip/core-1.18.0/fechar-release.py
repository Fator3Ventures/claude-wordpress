"""Close local 1.18.0 release from verified evidence. No deployment."""
from pathlib import Path
import argparse,json,hashlib,zipfile,subprocess,re
ROOT=Path(__file__).resolve().parent;plugin=ROOT/'fontes/plugin';ev=ROOT/'suite/versao-1180/evidencias'
p=argparse.ArgumentParser();p.add_argument('--saida',default=str(ROOT.parents[1]/'deliverables/1.18.0'));out=Path(p.parse_args().saida).resolve();out.mkdir(parents=True,exist_ok=True)
labels={'revisao':'Regressões novas: identidade, arquivo, exclusões e origens','diagnosticos-1180':'Navegação, consentimento, redes reais e permissões','editorial':'Conteúdo, sessões, aquisição, referências IA e GSC','integridade':'Rotas, coortes e histórico','fronteiras':'Publicação independente, horas e agregados','core':'Captura, contratos, navegação e segredos','crm':'Pipedrive com transporte simulado','capi':'CAPI com transporte simulado','bordas':'Bordas de contratos e relatórios','llms':'Publicação LLMS','novas':'Ofertas, atribuição e agentes','origens':'Paginação de origens','credenciais':'Concorrência e rotação de credenciais','volume':'Volume, limites e orçamento de memória','obrigatorios':'P00, mudanças, TTL e executor','http':'HTTP local, cache PHP e formulário sem JS','http-1180':'Markdown incompleto versus preparo, GET e HEAD','redirects-bordas':'Redirects e evidência pública local','fechamento':'Documentação instalada e contrato','ux-editorial':'Telas, sessão, CSV, anotações, filtros, teclado e celular'}
results=[]
for key,label in labels.items():
 d=json.loads((ev/(key+'.json')).read_text());checks=d.get('checks',{});n=len(checks) or d.get('total',0)
 assert n and not d.get('falhas') and all(checks.values()) and not d.get('stderr') and not d.get('errors'),(key,d)
 results.append((label,n,key+'.json'))
upgrade=json.loads((ev/'upgrade.json').read_text());assert len(upgrade)==10 and all(x['exit']==0 and not x['stderr'] for x in upgrade)
syntax=json.loads((ev/'sintaxe-build.json').read_text());assert not syntax['falhas'] and syntax['build']['ok']
total=sum(row[1] for row in results)
validation=f'''# Validação — F3 Base Core 1.18.0

Data: 30/09/2026. Contrato 4.2.0. Instalação nova ou atualização de **1.17.0 concluída**, com retomada na própria versão. Nenhum site de produção foi acessado ou alterado nesta implementação. **Korvena.net.br não foi testado.** Tema e implantador estão fora do escopo.

## Ambiente e resultados

Bancada isolada: WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP Super Cache 3.1.3, Chromium Headless 151 e Playwright. Dados sintéticos; e-mail bloqueado e transporte comercial interceptado. HTTP local com oito workers.

**{total} asserções aprovadas**, mais dez etapas de instalação/atualização. Não são {total} cenários independentes. Evidências: `suite/versao-1180/evidencias/` no ZIP de fontes.

| Conjunto | Asserções | Evidência |
|---|---:|---|
'''+''.join(f'| {label} | {n} | `{name}` |\n' for label,n,name in results)+f'''
Instalação, dados semeados, atualização, repetição e retomada foram verificadas para cada caminho: novo e 1.17.0 real. Baseline SHA-256: `8d352740d70f4d6861e19a0539accd98d0e9467afe89dd4c397c8c5b6c18eee7`. Preferências falsas, listas vazias, contatos, política e credenciais cifradas foram preservados. A nova preferência de anotações preenche somente chave ausente.

Sintaxe: {syntax['php']} arquivos PHP (plugin e testes) e {syntax['js']} arquivos JavaScript. Os sete assets minificados foram recompostos e conferidos com Terser fixado. O instalador é conferido byte a byte contra as fontes e contra o manifesto de SHA-256.

## Correções efetivamente verificadas

- Query de CPT não vira home; templates não participam do catálogo; aliases comprovadamente errados são invalidados em lotes retomáveis.
- Histórico sem ID cruza pelo caminho normalizado, conservando `post_id=0`. Descoberta não entra em requisições de conteúdo.
- Dia novo e horas são publicados apesar de fonte antiga perdida. Agregado antigo permanece no arquivo auditável; reentrada e retomada com estado anterior não rearquivam totais novos. Lacuna permanece explícita.
- OAuth/MCP operacional sai do recorte de conteúdo. Robôs genéricos ficam consultáveis em grupo separado.
- Exclusão anotada vem aplicada, aceita desligamento no relatório e no serviço, e alcança o relatório integrado. Exclusão da anotação exige revisão e permissão e deixa auditoria. Nenhum contato é apagado.
- P32 ignora ordem somente no conjunto `f3base_llms.tipos`; arrays ordenados gerais mantêm sua semântica. Navegação inline gera orientação; consentimento explicitamente gravado não recebe o alerta de ausência.
- HTTP real local: Markdown conhecido incompleto responde 404, sem Retry-After, com alternativa HTML; pendente responde 503 com Retry-After; HEAD não leva corpo e HTML permanece 200.
- Catálogo de origens respeita fronteiras de domínio e prioridade de mídia paga. Os quatro JSONs públicos adicionados passaram pelo parser real. Não é prova de identidade de uma requisição.

A interface foi percorrida em 1440 e 360 px, com inspeção visual das capturas. Foram verificados sessão e jornada, exportação, filtros, inclusão/edição/remoção de anotações, foco de teclado, ausência de overflow da página e erros JavaScript. Tabelas largas têm rolagem própria. Datas da bancada usam locale do navegador; resultados e exportação informam fuso/UTC.

## Alcance e pendências externas

Os testes não certificam a hospedagem, SMTP, contas comerciais ou visitantes reais. Mocks de Pipedrive/CAPI/ads não encerram a homologação externa. Search Console continua exigindo fotografia de fonte autorizada. Redes oficiais dependem de disponibilidade futura e de configuração explícita de confiança no IP original; essa confiança continua desligada por padrão.

Itens 50/86: conferir a cobertura e publicação com os arquivos realmente disponíveis na frota. Fontes já perdidas não são reconstruídas. Item 52: observação de sete dias até 05/10 é operacional e permanece aberta; não foi feita visita ao site para esse aceite. Itens 79/88: a bancada valida o produto, mas amostra real e uso na frota ainda precisam ser conferidos.

Item 38: **não houve nova rodada PSI/Lighthouse nesta entrega**. O transporte JavaScript e seu prazo de cinco segundos após load não foram alterados; adiar não garante ausência em toda janela de medição. Não há alegação de ganho de nota ou causalidade. O diagnóstico novo é administrativo e não adiciona script, beacon ou sonda HTTP ao visitante.

As assinaturas MistralAI-User, cohere-ai e YouBot foram nomeadas, mas mantidas genéricas por falta de confirmação primária suficiente de finalidade. Bytespider também não foi promovido automaticamente a treinamento. DNS reverso foi adiado: exige execução assíncrona, confiança no endereço e validação direta/reversa própria. Não deve ser colocado na leitura síncrona de logs.

Erros iniciais das fixtures HTTP (modo inválido, visibilidade e arquivo LLMS concorrente da bancada) foram corrigidos antes dos resultados finais. A aplicação não foi alterada para contornar os contratos dessas fixtures. O percurso de jornada passou a aguardar explicitamente a URL e o cabeçalho da página antes de validar, corrigindo a corrida do teste durante navegação. Fontes públicas consultadas, hashes e limites estão em `fontes-publicas.json`; não se distribuem cópias integrais de páginas de terceiros.
'''
(plugin/'docs/VALIDACAO.md').write_text(validation)
items=[
('89 / 83','Implementado','Catálogo público, queries estruturais, reparo de aliases, barra final e descoberta separada; sem preencher IDs antigos por suposição.','editorial','reparar_catalogo','revisao.json; editorial.json; integridade.json'),
('50 / 86','Implementado; aceite real aberto','Componentes de fontes antigas arquivados antes da publicação independente. Recibo transacional protege retomada. Dias e horas atuais deixam de depender de lacuna antiga.','acessos-legado','reconciliar','revisao.json; fronteiras.json; conferir logs da frota'),
('90 / 81','Implementado','OAuth/MCP operacional excluído; grupo de automação genérica separado dos identificados e consultável.','agentes','consultar','revisao.json; ux-editorial.json'),
('91 — P32','Implementado','Compara tipos editoriais como conjunto, sem alterar arrays ordenados gerais.','config-perfil','comparar','revisao.json'),
('91 — consentimento','Implementado','Estado degradado somente quando a opção realmente falta ou existe problema efetivo; default explícito é configuração válida.','modulo-consentimento','calcular_estado','diagnosticos-1180.json'),
('91 — Markdown','Implementado','Incompleto já avaliado: 404 sem retry e HTML alternativo; preparo ainda pendente: 503 com retry.','modulo-llms-markdown','talvez_servir','http-1180.json'),
('42','Implementado','Aviso e orientação para referência configurada não observada; navegação inline sugere administração pelo tema, sem modificar o tema.','navegacao','diagnostico','diagnosticos-1180.json'),
('61','Documentado; demais correções da base preservadas','Contrato explica QUERY_STRING intacta e reposição nativa restrita à atribuição.','redirects-servico','executar','http.json; redirects-bordas.json; docs/CONTRACTS.md'),
('66','Implementado no texto pendente','Ajuda de full alinhada ao padrão true. Contagem do schema e remoção de código morto permanecem da base.','options-catalogo','','fechamento.json; docs/AJUDA-OPCOES.md'),
('76','Implementado com limite','Anotações aplicadas por padrão e editáveis/removíveis com revisão/auditoria; vale para relatórios e CSV. Não reclassifica histórico sem sinal nem exclui dias automaticamente.','inteligencia','anotacao_excluir','revisao.json; diagnosticos-1180.json; ux-editorial.json'),
('78','Implementado','Onze origens IA em catálogo de dados versionado, aliases e fronteiras de host. Sinal pago preserva prioridade.','audiencia','ia','revisao.json; docs/dados/origens-ia.json'),
('80','Implementado com finalidade não confirmada explícita','Meta ExternalFetcher/WebIndexer, DuckAssistBot, MistralAI-User, cohere-ai e YouBot nomeados. Assinaturas sem finalidade confirmada e Bytespider permanecem genéricos.','modulo-acessos-servidor','robos','dados/robos-conhecidos.tsv; docs/dados/robos-catalogo.json; fontes-publicas.json'),
('82','Listas ampliadas; DNS reverso adiado','Perplexity ×2, Bing e DuckAssistBot adicionados. Confiança no IP é opção do site; compatibilidade não autentica robô. DNS requer projeto assíncrono específico.','redes-robos','validar','diagnosticos-1180.json; editorial.json'),
('87','Implementado com limites','Saúde administrativa informa ausência recente, dias sem sinais de consumo e falha operacional observada. Retenção existente preservada; não promete coleta sem lacunas.','medicao-saude','consultar','diagnosticos-1180.json; revisao.json; ux-editorial.json'),
('79 / 88','Base preservada e UX ampliada','Conteúdo, sessões, jornada, IA, CSV e fuso; gerenciamento de exclusões, grupos de robôs e saúde. Amostra real permanece aceite do site.','medicao-editorial-ui','anotacoes_form','editorial.json; ux-editorial.json; capturas PNG'),
('17','Preservado; homologação externa','Pipedrive e ads existentes não são ativados; CRM-A01…A15 dependem de conta autorizada. Novo webhook comercial e confirmação por URL não entram nesta correção.','pipedrive-fila','processar','crm.json; capi.json; credenciais.json; origens.json'),
('38','Sem alteração; limitação mantida','Não alterar captura apenas para ocultar requisição no PSI. Prazo existente preservado, sem nova medição nem promessa de ganho.','analise','enfileirar','sintaxe-build.json; assets iguais à base'),
('52','Aceite operacional aberto','Período de sete dias até 05/10 não é substituído por teste sintético. Sem acesso a korvena.net.br.','analise','persistir','Aceite externo, sem alegação de conclusão'),
('85','Contrato preservado; fonte externa necessária','Importação GSC já existe; conta, autorização e envio de fotografias reais são necessários. Nenhum novo OAuth/conector foi incluído.','inteligencia','gsc_importar','editorial.json; integridade.json'),
('45; 43; 32; 25; 9; 56','Fora da correção atual ou aceite do site','Configuração de painel do tema, retirada de filtros do tema e aceites operacionais continuam por site. Sem alterações no implantador/tema.','configuracao-atual','documentacao','HTTP e regressões locais não encerram aceites externos')]
mapped=[]
for ids,status,change,cls,func,evidence in items:
 file=plugin/'includes'/('class-f3base-'+cls+'.php')
 if cls=='options-catalogo':file=plugin/'includes/trait-f3base-options-catalogo.php'
 assert file.exists(),file
 lines=file.read_text().splitlines();line=next((i+1 for i,l in enumerate(lines) if (re.search(r'function\s+'+re.escape(func)+r'\s*\(',l) if func else 'Ligado é o padrão' in l)),None)
 if not line:line=1
 mapped.append({'pedido':ids,'estado':status,'resultado':change,'arquivo':str(file.relative_to(plugin)),'linha':line,'funcao':func,'evidencia':evidence})
maptext='# Mapa da entrega — 1.18.0\n\nBase: Pendências do site-core após a 1.17.0, conferência de 29/09–30/09. Implementado descreve o pacote local; aceites externos não são marcados como concluídos. Linhas referem-se aos arquivos desta entrega.\n\n| Pedido | Disposição | Resultado e limite | Arquivo:linha | Teste / aceite |\n|---|---|---|---|\n'
for row in mapped:maptext+=f"| {row['pedido']} | {row['estado']} | {row['resultado']} | `{row['arquivo']}:{row['linha']}` | {row['evidencia']} |\n"
maptext+='\nOs itens resolvidos na 1.17.0 são preservados como base, sem nova alegação de implementação. Datas antigas não são excluídas por presunção de teste: um operador deve registrar o período comprovado. Retenções curtas, opções desligadas, listas vazias e decisões sobre confiança de IP permanecem.\n'
(plugin/'docs/MAPA-ENTREGA-1.18.md').write_text(maptext);(plugin/'docs/dados/entrega-1.18.json').write_text(json.dumps({'versao':'1.18.0','base':'1.17.0','itens':mapped},ensure_ascii=False,indent=2)+'\n')
for old in ['docs/MAPA-ENTREGA-1.17.md','docs/dados/entrega-1.17.json']:(plugin/old).unlink(missing_ok=True)
for file in (plugin/'docs').rglob('*.md'):
 if file.name=='CHANGELOG.md':continue
 text=file.read_text().replace('MAPA-ENTREGA-1.17.md','MAPA-ENTREGA-1.18.md').replace('entrega-1.17.json','entrega-1.18.json');file.write_text(text)
delta='''## O que muda em cada site

- Banco: cria `{prefixo}f3base_acessos_legado`. As tabelas de catálogo/rotas são reparadas em lotes; agregados antigos conectados a fontes reprocessadas são arquivados e retirados dos totais correntes, sem apagar eventos ou leads. Não se inventa identidade histórica. Retenção do arquivo segue os logs diários.
- Options: cria checkpoint `f3base_release_1180`; acrescenta somente `f3base_medicao_editorial.aplicar_anotacoes=true` quando ausente, com procedência padrão. Catálogo e processamento atualizam seus estados técnicos. Listas vazias, `false`, destinatários, credenciais, tempo ativo e política permanecem. O preenchimento de defaults é auditável no checkpoint.
- Configuração de cache: nenhum novo parâmetro, exclusão ou requisito em `wp-cache-config.php`; `oppref` e exclusões existentes permanecem. Nenhuma nova diretiva no bloco `F3BASE MANAGED`. Regras existentes podem ser verificadas/reaplicadas pelo ciclo normal da instalação.
- Arquivos externos: nenhuma migração nova de robots, reserva privada ou anexos. Instalação nova continua provisionando a pasta privada. Arquivos já gerenciados seguem os serviços existentes.
- Execução: reparo editorial e releitura de logs disponíveis são agendados; podem precisar de mais de uma passagem do executor. Verificar cobertura e cursor, sem interpretar lacuna como zero. Quatro listas públicas adicionais são atualizadas na cadência existente, fora da visita pública.
- Frontend: nenhum JavaScript ou beacon novo, nenhum novo cookie e nenhum aumento da captura de dados pessoais. O diagnóstico adicional roda na consulta administrativa; a atualização/reconciliação usa recursos do servidor fora do caminho do visitante.
- Documentação: acompanha o instalador em `docs/`, com contrato 4.2.0, dicionário do banco, catálogos, exemplos de serviços, mapa por item, limites e recuperação. Disponível ao agente por leitura dos arquivos e `f3base/documentacao-ler`.

## Instalação e recuperação

Instale o ZIP pelo WordPress sobre uma 1.17.0 concluída ou em site novo. Confirme `f3base_release_1180.concluido_em`, execute pendências e confira saúde, reparo do catálogo e cobertura dos logs. A interface pode mostrar dados pendentes até concluir os lotes. Faça as anotações dos períodos de teste conhecidos, quando cabíveis, e compare com o filtro desligado.

Recuperação é retomada na própria versão: reinstalar os mesmos arquivos, corrigir a causa apontada e executar a atualização/pendências novamente. **Downgrade não é suportado.** Não apagar options/checkpoints para forçar origem nova. Backups operacionais permanecem responsabilidade da instalação. O pacote não foi publicado no GitHub nem implantado na frota nesta entrega; o ZIP local e as somas são o material para essa publicação.
'''
(ROOT/'PLANO-APROVADO.md').write_text('# Escopo implementado — 1.18.0\n\nSolicitação: implementar os ajustes avaliados após a conferência da 1.17.0. Base única 1.17.0 concluída ou site novo; sem tema, implantador, downgrade ou teste em korvena.net.br.\n\n'+maptext+'\n'+delta)
(ROOT/'README.md').write_text('''# Fontes — F3 Base Core 1.18.0

`fontes/plugin/` é o conteúdo instalável. `suite/versao-1180/` contém testes e evidências desta release; `suite/build-assets/` fixa a compilação dos assets. `referencias/` contém somente o instalador real 1.17.0 para a bancada. Executáveis, banco, runtime, node_modules e credenciais não acompanham o pacote.

Leia `fontes/plugin/docs/VALIDACAO.md`, `MAPA-ENTREGA-1.18.md` e `OPERACAO-E-RECUPERACAO.md`. A suíte exige laboratório descartável; não executar fixtures em produção. Sem downgrade. Para construir: `python3 montar-release.py --saida /DESTINO`. Para fechar após os testes: `python3 fechar-release.py --saida /DESTINO`. Não há publicação automática.
''')
subprocess.run(['python3',str(ROOT/'montar-release.py'),'--saida',str(out)],check=True)
installer=out/'base-site-core-fator3-1.18.0.zip';digest=hashlib.sha256(installer.read_bytes()).hexdigest()
report='# Entrega — F3 Base Core 1.18.0\n\n'+f'Instalador: `base-site-core-fator3-1.18.0.zip`\n\nSHA-256: `{digest}`\n\nContrato 4.2.0. Base exclusiva: 1.17.0 concluída ou instalação nova.\n\n'+delta+'\n'+maptext+'\n'+validation
(out/'RELATORIO-1.18.0.md').write_text(report)
source=out/'fontes-core-f3base-1.18.0.zip';files=list((ROOT/'fontes').rglob('*'))+list((ROOT/'suite/versao-1180').rglob('*'))+list((ROOT/'suite/build-assets').rglob('*'))+[ROOT/'referencias/base-site-core-fator3-1.17.0.zip']+[ROOT/n for n in ['README.md','PLANO-APROVADO.md','montar-release.py','fechar-release.py']]
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(set(files)):
  if not file.is_file() or any(p in ['node_modules','__pycache__','.git','patches'] for p in file.parts) or file.suffix in ['.pyc']:continue
  assert not file.is_symlink(),file
  rel=file.relative_to(ROOT).as_posix();i=zipfile.ZipInfo('core-1.18.0/'+rel,(2026,9,30,0,0,0));i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,file.read_bytes())
artifacts=[installer,source,out/'RELATORIO-1.18.0.md',out/'manifesto-1.18.0.json']
(out/'SHA256SUMS-1.18.0.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in artifacts))
print(json.dumps({'versao':'1.18.0','assercoes':total,'upgrade_etapas':10,'sha256_instalador':digest,'arquivos':{f.name:f.stat().st_size for f in artifacts}},ensure_ascii=False))
