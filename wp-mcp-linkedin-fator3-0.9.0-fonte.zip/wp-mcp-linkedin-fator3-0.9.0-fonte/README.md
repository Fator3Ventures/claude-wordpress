# Fonte — Fator3 MCP LinkedIn 0.9.0

Nova rodada sobre a base aceita 0.8.1, pelo incremento minor padrão. Atende ao pedido MCP LinkedIn 12: isolamento concorrente seguro de coletas ilegíveis. Este fonte não é instalável; instale somente `wp-mcp-linkedin-fator3-0.9.0-instalador.zip`.

## Estrutura e evidências

- `plugin/wp-mcp-linkedin-fator3/`: 59 arquivos idênticos ao instalador testado, incluindo 28 PHP e 25 documentos.
- `build/common/Queue.php` e `Support.php`: mudança canônica de runtime; isolamento central, bloqueio e CAS do snapshot exato. O worker já chama a mesma rotina. `build/build.py` contém a versão 0.9.0.
- `build/docs/linkedin/`: documentação instalada, migração e notas 0.9.0; schemas públicos e assets permanecem byte a byte iguais à 0.8.1.
- `tests/native/request012-cases.php`: 18 verificações em MySQL real, com segunda conexão e interleavings determinísticos; `request012.php` é o executor local. A reparação de migração mantém a projeção pendente deliberadamente, para testar revisão/ciphertext sem depender da atualização de estado feita por Store::put.
- `tests/native/suite.php`: regressões, autorização, SDK, auditoria e preservação de dados/opções/agendas na atualização. `seed.php` aceita a base desta rodada, 0.8.1.
- `evidence/release090/`: provas próprias, diffs, integridade dos acompanhantes, reprodução na base, matriz final, documentação remota e Site-Teste.
- `evidence/review081/`, demais evidências antigas e `history/`: histórico recebido; não são novas execuções da rodada 0.9.0. `history/received-0.8.1/README.md` identifica as revisões indevidas de impactos de outros mantenedores herdadas da base.
- `inputs/0.9.0/`: pedidos, relatórios, impactos recebidos e normas preservados, com hashes. ZIPs de dependências não são aninhados no fonte.
- `impacts/`: somente o encaminhamento próprio LinkedIn 0.8.1 → Meta, agora revisão 2, encerrado pela resposta técnica recebida. Não reemite documentos de Core/MCP/Meta/Google.
- `tools/site-qa-090.php`: auxiliar temporário do Site-Teste; testes em tabela exclusiva, HTTP bloqueado, opções compartilhadas preservadas. Tabela e auxiliar foram removidos. Não integra o instalador.

## Reprodução

Prepare WordPress, runtimes, MySQL e os instaladores aceitos em caminhos externos. Ajuste `tools/lab-release090.example.json`; preserve hashes dos pacotes e preencha o hash do seu runtime. O laboratório exige um diretório vazio e cria um schema próprio no MySQL informado.

```sh
F3_SOCIAL_PHP=/usr/bin/php python3 build/build.py
python3 tools/lab.py --manifest tools/lab-release090.example.json --workdir /tmp/li090-isolated --order linkedin-only --tests suite.php,request012.php
python3 tools/lab.py --manifest tools/lab-release090.example.json --workdir /tmp/li090-integrated --order linkedin-integrated --tests suite.php,request012.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release090.example.json --workdir /tmp/li090-upgrade --order linkedin-integrated --origin upgrade --tests suite.php,request012.php,mcp-docs080.php
python3 tools/lab.py --manifest tools/lab-release090.example.json --workdir /tmp/li090-minimum --order linkedin-only --wordpress wordpress_minimum --php php81 --tests suite.php,request012.php
python3 tools/lab.py --manifest tools/lab-release090.example.json --workdir /tmp/li081-reproduce --order linkedin-only --candidate /CAMINHO/wp-mcp-linkedin-fator3-0.8.1-instalador.zip --tests request012.php
```

A reprodução na base é esperada falhar: 11 de 18 novas asserções não são atendidas pela 0.8.1. Na rodada inicial de dez verificações, cinco reproduziram diretamente as corridas/ausência de trava; os oito casos acrescentados cobrem releitura, corrupção, worker e idempotência. Isso não significa onze defeitos independentes.

## Ambiente e fechamento

WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46 e mínimo WordPress 6.4/PHP 8.1.2-1ubuntu2.28. No mínimo, 132 regressões + 18 casos novos passaram; duas verificações dependentes da Abilities API nativa não se aplicam. Acompanhantes: Core 1.49.1, MCP 0.29.1, Google 0.18.1, Meta 0.7.1. Site-Teste: WP 7.1.3/PHP 8.3.36. Zero chamadas comerciais ao LinkedIn.

`tools/package-source.py` exige que plugin/ seja idêntico ao instalador e recusa ZIP aninhado ou sobrescrita de um fonte já fechado. A cópia do relatório interna é anterior ao fechamento; hash e tamanho finais do fonte estão no relatório externo. O build foi reproduzido em diretório limpo com o mesmo hash do instalador.
