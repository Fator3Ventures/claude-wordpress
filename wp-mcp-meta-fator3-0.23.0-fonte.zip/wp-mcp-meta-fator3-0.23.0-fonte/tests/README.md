# Testes do Fator3 MCP Meta 0.23.0

Use Python 3, PHP CLI 8.3+ de 64 bits com mysqli, mbstring, JSON e criptografia, WordPress 7.1.4 e MySQL descartável com InnoDB. A bancada desta versão usa exclusivamente `127.0.0.1:34793` e cria bancos aleatórios com o usuário root local sem senha. Reserve a porta 34893 para o servidor HTTP do teste de interface.

- `F3_SOCIAL_PHP` aponta para o PHP CLI e `F3_QA_WP_CORE` para a raiz descompactada do WordPress.
- `F3_QA_BASE` aponta para a pasta do plugin extraída do instalador 0.22.1. `F3_QA_COMPANIONS` contém uma pasta com o slug para cada instalador vigente.
- Para os testes de interface instale Playwright para Python e defina `F3_QA_CHROME` como o executável Chrome ou Chromium Headless Shell.

Na raiz do fonte, execute:

```sh
python3 build/build.py
for fase in regression-base clean upgrade regression combination ui-final ui-assets; do
  python3 tests/lab/review023.py "$fase" || exit 1
done
python3 tests/visual/settings023.py plugin/wp-mcp-meta-fator3 evidence/023/settings-final.json
python3 tests/docs/check.py "$F3_SOCIAL_PHP" build/dist/wp-mcp-meta-fator3
python3 tests/docs/lint-cases.py
python3 tests/docs/build-cases.py
```

O cenário `regression-base` reproduz as falhas do cron na base. `settings023.py` aceita também a pasta do instalador-base para reproduzir as falhas visuais e retorna 1 nesse cenário. O cenário `combination` ativa os cinco acompanhantes oficiais, inicia outro processo PHP e usa o executor instalado do MCP para ler os documentos. `ui-assets` grava ativos pela REST local. Apenas a descoberta dos datasets é simulada nesse fluxo. O WordPress de teste bloqueia chamadas comerciais e e-mails. Cada cenário encerra o site e elimina seu banco.

O build normal usa exemplos capturados e congelados. Para renovar os exemplos em desenvolvimento, use `F3_EXAMPLES_BOOTSTRAP=1` no build, execute a fase `capture` e refaça o build normal. Isso gera nova captura e muda a identidade do pacote.

O restante deste arquivo descreve as ferramentas de desenvolvimento e os ensaios históricos; seus nomes e guardas de versão identificam a rodada de origem.

## Build e lint documental

```sh
python3 build/build.py                       # lint documental reprova (padrão)
F3_DOCS_LINT=warn python3 build/build.py     # R1–R5 e R7 viram aviso; R6 e R8 continuam reprovando
python3 tests/docs/lint-cases.py             # um caso por regra R1–R8, caso limpo e validação da captura de exemplos
python3 tests/docs/build-cases.py            # marcadores {{…}} resolvidos antes dos hashes, ordem do catálogo, recusas duras
python3 build/docs_lint.py build/dist/wp-mcp-meta-fator3 build/docs/meta/catalog.json   # lint avulso de um runtime construído
```

O build lê `build/docs/meta/catalog.json`, copia os manuais resolvendo `{{VERSION}}`, `{{OPERATION_COUNT}}`, `{{DOCUMENT_COUNT}}` e `{{BASE_VERSION}}`, gera `REFERENCE.md` do registro (schemas, rótulos e `Api::effects`) e `EXAMPLES.md` de `build/docs/examples/captured.json`, roda o lint e só então calcula bytes e SHA-256 do índice compilado e do manifesto. Um build reprovado não deixa ZIP.

## Captura dos exemplos (EXAMPLES.md)

`captured.json` precisa ser da mesma versão do build. Para recapturar depois de mudar o código:

```sh
F3_EXAMPLES_BOOTSTRAP=1 python3 build/build.py          # runtime só para a captura; não gera ZIP
STAGE=$(mktemp -d); cp tests/native/* tests/docs/capture-examples.php "$STAGE"/
export LAB_NAME=<nome>
scripts/native-lab.sh setup current f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" <base> "$STAGE"
scripts/native-lab.sh run capture-examples.php > build/docs/examples/captured.json
scripts/native-lab.sh cleanup                            # exigir remaining_tables=0
python3 build/build.py                                   # build final com os exemplos capturados
```

A captura roda no WordPress isolado com HTTP bloqueado. O exemplo parcial usa uma simulação `pre_http_request` restrita ao script; o token sintético é conferido para não aparecer na saída. O build recusa captura de outra versão, campo secreto preenchido e ausência dos tipos exigidos (sucesso de leitura, gravação de conexão sem credencial, vazio, `invalid_input` com `field`, `asset_access_denied`, `revision_conflict`, parcial).

## WordPress isolado local (suítes nativas)

`scripts/native-lab.sh` é o script `tests/lab/native-lab.sh` deste fonte (ver `tests/lab/README.md`). Ele cria `/tmp/f3qa022_<12hex>_/wordpress` com prefixo de tabela igual ao nome do diretório e HTTP/e-mail bloqueados; `tests/native/guard.php` recusa qualquer outro alvo.

| Ambiente | Comandos, em ordem | Aceite |
|---|---|---|
| Instalação limpa | `setup current f3qa022 <runtime> <base> tests/native`; `run release022.php` (primeiro, antes de qualquer coleta); `run smoke.php`; `run configuration.php`; `run export-integrity.php`; `run dataset.php`; `run effects-map.php`; `cleanup` | Saída zero e `failed=0` em cada suíte |
| Reprodução na base | `setup baseline f3qa022 <runtime> <base> tests/native`; `run release022.php`; `run effects-map.php`; `cleanup` | `release022.php` deve reprovar os itens corrigidos (A1, A2, A7, A8, C6, efeitos); não entra na contagem da candidata |
| Migração direta | `setup upgrade f3qa022 <runtime> <base> tests/native`; `upgrade`; `cleanup` | `migrate.php` com `failed=0`: registros, histórico, opções, agenda, pausa, cursor, concessão, retenção e marca/progresso da migração do histórico preservados; reativação com páginas pendentes não altera o progresso |

`release022.php` cobre: A1 (tabela de casos → `field`/`problem`, inclusive `query.report`, e valor-sentinela ausente da resposta por despacho e por REST), A2, A7 (marca concluída logo após ativar, lida em `evidence/activation.json` gravado por `install.php`; ativação sem usuário logado), A8 (rótulo novo, descrição e schema iguais aos da base), C6 (título, resumo e tema de todos os documentos; título na leitura) e a origem única dos efeitos (`Api::effects` igual às anotações registradas). `smoke.php` lê todos os documentos por páginas e confere bytes, SHA-256 e título contra o arquivo instalado.

Igualdade de efeitos com a base: rode `effects-map.php` no laboratório da base e no da candidata e compare:

```sh
python3 tests/native/effects-compare.py <mapa_base.json> <mapa_candidata.json>
```

A evidência desta frente está em `tests/native/evidence/`.

## Integridade da documentação fora do WordPress

```sh
python3 tests/docs/check.py <php> build/dist/wp-mcp-meta-fator3
```

Usa uma cópia temporária e PHP avulso com a capacidade simulada: bytes UTF-8, índice com título/resumo/tema, A2, arquivo alterado, ausente e link para fora da pasta. A autorização real é provada no WordPress isolado.

## Interface

### Suítes DOM (jsdom, transporte simulado)

Em `tests/browser`, instale as dependências do lock com `npm ci`. As suítes usam o HTML do renderer administrativo do pacote, o CSS e o JavaScript reais, com helpers do WordPress simulados e registros sintéticos. As chamadas REST são simuladas; jsdom não confirma layout.

```sh
php tests/browser/render.php build/dist/wp-mcp-meta-fator3 > /tmp/painel.html
php tests/browser/render.php build/dist/wp-mcp-meta-fator3 identity > /tmp/identidade.json
node tests/browser/run.cjs /tmp/painel.html /tmp/ui-dom.json
node tests/browser/identity.cjs /tmp/identidade.json build/dist/wp-mcp-meta-fator3/assets/admin.js /tmp/ui-identity.json
node tests/browser/monitoring.cjs /tmp/identidade.json build/dist/wp-mcp-meta-fator3/assets/admin.js /tmp/ui-monitoring.json
node tests/browser/messaging.cjs /tmp/identidade.json build/dist/wp-mcp-meta-fator3/assets/admin.js /tmp/ui-messaging.json
node tests/browser/selection-race.cjs /tmp/identidade.json build/dist/wp-mcp-meta-fator3/assets/admin.js /tmp/ui-selection-race.json
node tests/browser/panel.cjs /tmp/identidade.json build/dist/wp-mcp-meta-fator3/assets/admin.js tests/browser/fixtures/diagnostics.json /tmp/ui-panel.json
```

`panel.cjs` cobre a navegação em dois níveis, lista e editor da conexão, blocos recolhíveis, busca de usuários, aviso de resultado, sessão expirada, rótulos do diagnóstico (com a saída real de `health`, `status` e `selftest` guardada em `fixtures/diagnostics.json`, capturada por `fixtures/capture-diagnostics.php`), seletor de canal dos ativos, subvisões de Coletas e Conversas e a leitura formatada da Ajuda. Para reproduzir na base, passe ao renderer e às suítes o diretório e o `admin.js` do instalador da base.

### Layout em navegador real

`tests/visual/layout.cjs` usa Chrome (puppeteer-core) contra um WordPress real com o plugin ativo e o simulador `tests/visual/graph-simulator.php` em `mu-plugins`. Percorre as dez abas e as subvisões em quatro larguras e mede rolagem horizontal, distância entre botões, nome acessível, alinhamento, largura de campo, alvos de toque, contraste, orçamento de altura por tela e os comportamentos de busca de usuários e de aviso de resultado. O procedimento de montagem e os parâmetros estão em `tests/visual/README.md`. A suíte precisa falhar na base e passar na candidata; rode um site por vez.

## WordPress no Site-Teste

O controlador é temporário, restrito ao Site-Teste e não integra o instalador. Gere a bancada com `python3 tests/site/build.py <instalador-base.zip> <instalador-candidato.zip> <saida>`: o build exige o SHA-256 canônico do instalador da base (constante `BASE_SHA256` em `tests/site/build.py`) e confere versão de cabeçalho, manifesto e todos os arquivos dos dois instaladores. Transfira temporariamente `f3-qa022.php` e `f3-qa022.bundle.gz` para `wp-content/mu-plugins/`, use `meta/qa-022-lab` uma operação por vez (`setup` com `flavor`, depois `release022`, `smoke`, `configuration`, `export`, `dataset`, `effects-map`, `upgrade`, `cleanup`) e consulte `meta/qa-022-state` antes e depois. Exija saída zero e `failed=0` mesmo quando o transporte MCP devolver sucesso; após cada ambiente, zero tabelas e diretório removido.

Em `tests/regressions` estão cenários herdados que não entram na contagem da rodada sem evidência de execução.

A suíte complementar `python3 tests/visual/fixture0221.py` executa o fluxo geral e a troca de identidade em Chromium sobre o renderer PHP, com REST simulada. Ela usa as mesmas variáveis de PHP e navegador. O teste de acesso pode ser repetido com `python3 tests/lab/review0221.py access`.
