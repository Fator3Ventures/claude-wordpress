# Fator3 MCP Meta — fonte

Versão e base de migração: constantes `VERSION` e `BASE_VERSION` de `build/build.py`. O diretório `build/` contém os templates PHP, os manuais editáveis (`build/docs/meta/*.md`), o catálogo documental (`build/docs/meta/catalog.json`), a captura de exemplos (`build/docs/examples/captured.json`) e os assets. O instalador é sempre gerado pelo build; o fonte não embute o ZIP.

**Build:** Python 3 e PHP CLI 8.3+ de 64 bits com funções de JSON/hash. Execute `python3 build/build.py` (ou informe `F3_SOCIAL_PHP` com o caminho absoluto do PHP). O resultado é `build/dist/wp-mcp-meta-fator3-<versão>-instalador.zip`. O script verifica sintaxe, gera os catálogos JSON, resolve os marcadores `{{VERSION}}`, `{{OPERATION_COUNT}}`, `{{DOCUMENT_COUNT}}` e `{{BASE_VERSION}}` dos manuais, gera `REFERENCE.md` a partir do registro do código e `EXAMPLES.md` a partir da captura no laboratório, roda o lint documental (`build/docs_lint.py`, regras R1–R8; `F3_DOCS_LINT=warn` rebaixa as regras de conteúdo a aviso), compila o índice da ajuda na ordem do catálogo e fixa a ordem dos arquivos e o timestamp do ZIP. Para reproduzir um ZIP entregue, usar compressão zlib como no relatório.

A versão 0.23.0 está documentada em `planning/023.md`. As verificações desta entrega estão em `evidence/023/`. Os registros em `evidence/0221/` e o relatório em `inputs/` identificam a revisão anterior.

**Testes:** consulte `tests/README.md` (lint e casos de build, captura de exemplos, laboratório local com `tests/lab/native-lab.sh`, Site-Teste). Reproduções de falhas na base não entram na contagem de aprovações da candidata.

**Empacotamento do fonte:** `python3 tools/package-source.py <pasta_saida>` exige a cópia do relatório marcada “cópia anterior ao fechamento do fonte” na raiz e exclui `build/dist`.

Instruções operacionais e limites de aceite ficam em `docs/` do instalador. Os pacotes acompanhantes mantêm identidade própria; não há componentes de QA no runtime.
