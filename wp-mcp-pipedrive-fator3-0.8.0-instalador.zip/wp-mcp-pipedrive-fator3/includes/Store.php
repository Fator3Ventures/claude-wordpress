<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

final class Store {
    const PENDING_PREFIX = 'f3_pd_pending_';
    const CANONICAL_PENDING = self::PENDING_PREFIX.'v2_';
    public static function table(string $kind): string { global $wpdb; return $wpdb->prefix . 'f3_pipedrive_' . ($kind==='journal'?'journal':'operations'); }
    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset=$wpdb->get_charset_collate();$ops=self::table('ops');$log=self::table('journal');
        dbDelta("CREATE TABLE $ops (
            previa_id char(32) NOT NULL,
            actor_id bigint(20) unsigned NOT NULL,
            binding char(64) NOT NULL,
            state varchar(16) NOT NULL,
            created bigint(20) unsigned NOT NULL,
            expires bigint(20) unsigned NOT NULL,
            retain_until bigint(20) unsigned NOT NULL,
            payload longtext NOT NULL,
            result longtext NOT NULL,
            PRIMARY KEY  (previa_id),
            KEY retain_until (retain_until)
        ) ENGINE=InnoDB $charset;");
        dbDelta("CREATE TABLE $log (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            previa_id char(32) NOT NULL,
            created bigint(20) unsigned NOT NULL,
            metadata longtext NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY previa_id (previa_id),
            KEY created (created)
        ) ENGINE=InnoDB $charset;");
        self::ready();
        update_option('f3_pipedrive_schema',1,false);
    }
    public static function ready(): void {
        global $wpdb;
        foreach (['ops','journal'] as $kind) {
            $t=self::table($kind);
            $row=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s',$t),ARRAY_A);
            if (!$row || strcasecmp((string)$row['Engine'],'InnoDB')!==0) {
                throw new Fault('armazenamento_indisponivel','Reative o plugin após conferir tabelas InnoDB e permissões de banco.');
            }
        }
    }
    public static function cleanup(): void {
        Retention::locked(static function () { self::cleanupLocked(); });
    }
    private static function cleanupLocked(): void {
        global $wpdb;$t=self::table('ops');$log=self::table('journal');$now=time();
        // Read while holding the same lock as policy updates. Invalid policy fails closed.
        $days=Retention::read()['diario_dias'];
        $results=[];
        $results[]=$wpdb->query($wpdb->prepare("UPDATE $t SET payload='', state='expired' WHERE state='ready' AND expires<=%d",$now));
        $results[]=$wpdb->query($wpdb->prepare("UPDATE $t SET payload='' WHERE state='running' AND expires<=%d",$now));
        // A workflow can finish with a partial receipt and still own the entity's pending marker.
        // Its receipt AND journal remain evidence until reconciliation releases the marker.
        $prefix=$wpdb->esc_like(self::PENDING_PREFIX).'%';
        $markers="SELECT 1 FROM {$wpdb->options} p WHERE p.option_name LIKE %s AND p.option_value=";
        $results[]=$wpdb->query($wpdb->prepare("DELETE FROM $t WHERE retain_until<%d AND state<>'running' AND NOT EXISTS ($markers $t.previa_id)",$now,$prefix));
        if ($days>0) {
            $results[]=$wpdb->query($wpdb->prepare("DELETE j FROM $log j LEFT JOIN $t o ON o.previa_id=j.previa_id WHERE j.created<%d AND (o.state IS NULL OR o.state<>'running') AND NOT EXISTS ($markers j.previa_id)",$now-$days*DAY_IN_SECONDS,$prefix));
        }
        if (in_array(false,$results,true)) { throw new Fault('armazenamento_indisponivel','Não foi possível aplicar a retenção; nenhuma nova chamada será feita.'); }
    }
    /** Only the 0.6 marker key range is read: newer v2 keys sort after f. Bound the exceptional upgrade path. */
    public static function legacyMarkers(): array {
        global $wpdb;
        $ops=self::table('ops');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT p.option_name,p.option_value AS operation_id,o.state,o.payload,o.result FROM {$wpdb->options} p LEFT JOIN $ops o ON o.previa_id=p.option_value WHERE p.option_name >= %s AND p.option_name < %s LIMIT 65",self::PENDING_PREFIX.'0',self::PENDING_PREFIX.'g'),ARRAY_A);
        if($wpdb->last_error!==''||!is_array($rows))throw new Fault('armazenamento_indisponivel','Falha ao conferir pendências da atualização.');
        if(count($rows)>64)throw new Fault('reconciliacao_necessaria','Há mais de 64 marcadores antigos; reconcilie as pendências antes de escrever em leads.');
        return $rows;
    }
    /** Authenticated legacy evidence gives the original UUID spelling even when its cleartext payload was purged. */
    public static function legacyEntity(array $row): ?array {
        try{
            if(($row['state']??null)==='done'&&!empty($row['result'])){
                $r=Support::open($row['result']);if(($r['previa_id']??null)!==$row['operation_id'])return null;
                $op=$r['data']['operacao']??null;$id=$r['data']['id']??null;
            }elseif(($row['state']??null)==='running'&&!empty($row['payload'])){
                $p=Support::open($row['payload']);$op=$p['workflow']??null;$id=$p['input']['lead_id']??$p['input']['negocio_id']??null;
            }else{return null;}
        }catch(Fault $e){return null;}
        if($op==='negocio-perder'&&is_int($id)&&$id>0)return ['deal',(string)$id];
        if(in_array($op,['whatsapp-registrar','lead-encerrar','lead-arquivado-editar'],true)&&is_string($id)&&preg_match('/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/iD',$id))return ['lead',$id];
        return null;
    }
    /** At most six IDs: the three account fields had no fixed order in existing receipts. */
    public static function messageId(array $candidates): string {
        global $wpdb;$t=self::table('ops');
        $fields=implode(',',array_fill(0,count($candidates),'%s'));
        $found=$wpdb->get_col($wpdb->prepare("SELECT previa_id FROM $t WHERE previa_id IN ($fields) LIMIT 2",...$candidates));
        if($wpdb->last_error!=='')throw new Fault('armazenamento_indisponivel','Não foi possível verificar a chave da mensagem.');
        if(count($found)>1)throw new Fault('reconciliacao_necessaria','Há mais de um recibo para a mesma chave e conta; confira o diário antes de prosseguir.');
        return $found[0]??$candidates[0];
    }
    public static function keepMessage(string $id): void {
        global $wpdb;
        $written=$wpdb->update(self::table('ops'),['retain_until'=>PHP_INT_MAX],['previa_id'=>$id,'state'=>'ready']);
        if($written===false||($written===0&&(int)self::get($id)['retain_until']!==PHP_INT_MAX))throw new Fault('persistencia_falhou','Não foi possível preservar idempotência da mensagem.');
    }
    public static function checkpoint(string $id,array $meta): void {
        global $wpdb;$log=self::table('journal');$json=Support::json($meta);
        if($wpdb->update($log,['metadata'=>$json],['previa_id'=>$id])===false||
           $wpdb->get_var($wpdb->prepare("SELECT metadata FROM $log WHERE previa_id=%s",$id))!==$json){
            throw new Fault('persistencia_incerta','O diário não confirmou a etapa; reconcilie antes de continuar.');
        }
    }
    public static function create(string $id, string $binding, array $payload): void {
        global $wpdb;$now=time();
        $ok=$wpdb->insert(self::table('ops'),['previa_id'=>$id,'actor_id'=>get_current_user_id(),'binding'=>$binding,'state'=>'ready','created'=>$now,'expires'=>$now+900,'retain_until'=>$now+180*DAY_IN_SECONDS,'payload'=>Support::seal($payload),'result'=>'']);
        if ($ok!==1) { throw new Fault('persistencia_falhou','A prévia não foi persistida; nenhuma escrita externa foi feita.'); }
        $row=self::get($id);
        if (Support::open($row['payload'])!==$payload) { throw new Fault('persistencia_falhou','A releitura da prévia não confirmou o conteúdo.'); }
    }
    public static function get(string $id): array {
        global $wpdb;$t=self::table('ops');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE previa_id=%s",$id),ARRAY_A);
        if ($wpdb->last_error!=='') { throw new Fault('armazenamento_indisponivel','Falha de leitura do armazenamento.'); }
        if (!$row) { throw new Fault('previa_inexistente','Prévia inexistente ou fora da retenção.'); }
        if ((int)$row['actor_id']!==get_current_user_id()) { throw new Fault('previa_de_outro_usuario','A prévia pertence a outro administrador.'); }
        return $row;
    }
    /** Classify sealed receipts from their original envelopes, even after the journal has expired. */
    public static function receiptFor(array $row,string $route): array {
        $r=Support::open($row['result']);$origin=null;
        $hasId=($r['previa_id']??null)===$row['previa_id'];
        if($hasId&&array_key_exists('remote_dispatched',$r)&&array_key_exists('applied',$r)){
            $origin='api-aplicar';
        }elseif($hasId&&!array_key_exists('remote_dispatched',$r)){
            $op=$r['data']['operacao']??null;
            if($op==='whatsapp-registrar')$origin=$op;
            elseif(in_array($op,['lead-arquivado-editar','lead-encerrar','negocio-perder'],true))$origin='operacao-aplicar';
        }elseif(!array_key_exists('previa_id',$r)&&!array_key_exists('applied',$r)&&!array_key_exists('remote_dispatched',$r)){
            // Configuration alone stored a local result without an ID, including Fault envelopes on CAS/save failures.
            if(is_string($r['code']??null)&&is_string($r['message']??null)&&is_array($r['data']??null)&&
                (($r['success']??null)===false||(($r['success']??null)===true&&$r['code']==='configuracao_salva')))$origin='configuracao';
        }
        if($origin===null)throw new Fault('registro_ilegivel','Origem do recibo ilegível; preserve o registro para reconciliação.');
        if($route!==$origin&&!($route==='operacao-aplicar'&&$origin==='configuracao'))throw new Fault('operacao_invalida','Este recibo pertence a outra operação.');
        return $r;
    }
    public static function claim(string $id, array $metadata): bool {
        global $wpdb;$t=self::table('ops');
        if ($wpdb->query('START TRANSACTION')===false) { throw new Fault('persistencia_falhou','Não foi possível iniciar o registro da operação.'); }
        try {
            $updated=$wpdb->query($wpdb->prepare("UPDATE $t SET state='running' WHERE previa_id=%s AND state='ready' AND expires>%d",$id,time()));
            if ($updated!==1) { $wpdb->query('ROLLBACK');return false; }
            $ok=$wpdb->insert(self::table('journal'),['previa_id'=>$id,'created'=>time(),'metadata'=>Support::json($metadata)]);
            if ($ok!==1) { throw new Fault('persistencia_falhou','A auditoria não foi persistida.'); }
            if ($wpdb->query('COMMIT')===false) { throw new Fault('persistencia_incerta','Confirmação do registro local incerta; escrita não despachada.'); }
            $row=self::get($id);
            if ($row['state']!=='running') { throw new Fault('persistencia_incerta','A releitura não confirmou a aquisição da operação.'); }
            return true;
        } catch (\Throwable $e) { $wpdb->query('ROLLBACK');throw $e; }
    }
    public static function finish(string $id, array $result, array $metadata, ?array $progress=null): void {
        global $wpdb;$ops=self::table('ops');$log=self::table('journal');
        $sealed=Support::seal($result);
        if ($wpdb->query('START TRANSACTION')===false) { throw new Fault('resultado_incerto','Falha ao registrar o resultado. Não repita a escrita.'); }
        try {
            $changed=$wpdb->query($wpdb->prepare("UPDATE $ops SET state='done',result=%s,payload='' WHERE previa_id=%s AND state='running'",$sealed,$id));
            if ($changed!==1) { throw new Fault('resultado_incerto','O resultado externo não foi confirmado no recibo.'); }
            $journalJson=Support::json($metadata);$written=$wpdb->update($log,['metadata'=>$journalJson],['previa_id'=>$id]);
            if($written===false||($written===0&&$wpdb->get_var($wpdb->prepare("SELECT metadata FROM $log WHERE previa_id=%s",$id))!==$journalJson))throw new Fault('resultado_incerto','O diário não confirmou o resultado. Reconcilie a operação antes de retomar.');
            if($progress!==null)Progress::persist($progress);
            if ($wpdb->query('COMMIT')===false) { throw new Fault('resultado_incerto','Confirmação do resultado incerta. Não repita a escrita.'); }
            $row=self::get($id);
            if ($row['state']!=='done' || Support::open($row['result'])!==json_decode(Support::json($result),true,512,JSON_THROW_ON_ERROR)) { throw new Fault('resultado_incerto','Releitura do resultado divergente.'); }
        } catch (\Throwable $e) { $wpdb->query('ROLLBACK');throw $e; }
    }
    public static function journal(array $input): array {
        global $wpdb;$t=self::table('journal');
        $limit=$input['limite']??50;$before=$input['antes_id']??PHP_INT_MAX;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,created,metadata FROM $t WHERE id<%d ORDER BY id DESC LIMIT %d",$before,$limit+1),ARRAY_A);
        if ($wpdb->last_error!=='') { throw new Fault('armazenamento_indisponivel','Falha ao ler o registro.'); }
        $more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$items=[];
        foreach ($rows as $row) {
            $meta=json_decode($row['metadata'],true);
            if (!is_array($meta)) { throw new Fault('registro_ilegivel','Metadados de auditoria ilegíveis.'); }
            $items[]=['id'=>(int)$row['id'],'instante_utc'=>gmdate('Y-m-d\TH:i:s\Z',(int)$row['created'])]+$meta;
        }
        $retention=Retention::read();
        return ['itens'=>$items,'proximo_antes_id'=>$more?(int)end($rows)['id']:null,'retencao_dias'=>$retention['diario_dias'],'sem_prazo'=>$retention['diario_sem_prazo'],'recibos_dias'=>$retention['recibos_dias'],'limpeza'=>$retention['limpeza']];
    }
}
