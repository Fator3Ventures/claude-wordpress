<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Cadence {
    public static function marker(string $lead,string $touch,int $time,string $key): string {
        $data=$touch.':'.$time.':'.hash('sha256',$key);
        return '[F3PD1:'.$data.':'.hash_hmac('sha256',$lead.':'.$data,wp_salt('auth')).']';
    }
    public static function progress(array $lead,?array $activity,array $c,?int $now=null,?array $account=null): array {
        $now??=time();$n=-1;$last=null;$codes=array_column($c['toques'],'codigo');
        foreach($c['toques'] as $i=>$t)if($t['etiqueta_id']!==''&&in_array($t['etiqueta_id'],$lead['label_ids']??[],true))$n=max($n,$i);
        $note=(string)($activity['note']??'');
        preg_match_all('/\[F3PD1:([a-z0-9_-]{1,40}):(\d{10,11}):([a-f0-9]{64}):([a-f0-9]{64})\]/',$note,$matches,PREG_SET_ORDER);
        foreach($matches as $m){$index=array_search($m[1],$codes,true);if($index!==false&&hash_equals(hash_hmac('sha256',$lead['id'].':'.$m[1].':'.$m[2].':'.$m[3],wp_salt('auth')),$m[4])&&$index>=$n){$n=$index;$last=max($last??0,(int)$m[2]);}}
        $origin=$last!==null?'marcador':'etiqueta_ou_inicio';
        $local=$account!==null?Progress::read($account,(string)$lead['id'],$activity):null;
        if($local!==null){
            $index=array_search($local['touch'],$codes,true);
            if($index===false)throw new Fault('progresso_incompativel','O toque registrado não existe nas regras atuais. Reconcilie a configuração.');
            if($index>=$n){$n=$index;$last=$local['time'];$origin='registro_local';}
        }
        if($last===null){$adopted=Rules::adoption($lead,$activity,$c,$n,$now);if($adopted!==null)return $adopted;}
        return ['indice'=>$n+1,'ultimo'=>$last,'ambiguo'=>$note!==''&&$n===-1,'origem'=>$origin];
    }
    public static function slot(int $target,array $c): array {
        $zone=new \DateTimeZone($c['fuso']);$day=(new \DateTimeImmutable('@'.$target))->setTimezone($zone)->setTime(0,0);$periods=$c['periodos'];usort($periods,static fn($a,$b)=>strcmp($a['hora'],$b['hora']));
        for($d=0;$d<3660;$d++,$day=$day->modify('+1 day')){
            if(!Rules::working($day,$c))continue;
            foreach($periods as $p){[$h,$m]=array_map('intval',explode(':',$p['hora']));$at=$day->setTime($h,$m)->getTimestamp();if($at>=$target)return ['instante'=>$at,'periodo'=>$p['codigo']];}
        }
        throw new Fault('configuracao_invalida','Não há próximo período no calendário.');
    }
    public static function evaluate(array $lead,array $activities,array $c,int $now,?array $account=null): array {
        $out=['lead_id'=>$lead['id'],'toque'=>null,'devido_em_utc'=>null,'periodo'=>null,'texto_aprovado'=>null,'devido'=>false,'motivo'=>null,'acao'=>'mensagem','politica_canal'=>Rules::channel($lead,$c)];
        if(!$c['habilitada']){$out['motivo']='configuracao_pendente';return $out;}
        if(!empty($lead['is_archived'])){$out['motivo']='lead_arquivado';return $out;}
        if(array_intersect($lead['label_ids']??[],$c['exclusoes']['etiquetas'])){$out['motivo']='etiqueta_excluida';return $out;}
        foreach($c['exclusoes']['campos'] as $rule){if(Rules::matches($lead,['campo'=>$rule['campo'],'operador'=>'igual','valores'=>$rule['valores']])){$out['motivo']=$rule['regra'];return $out;}}
        $wa=array_values(array_filter($activities,static fn($a)=>(string)($a['lead_id']??'')===(string)$lead['id']&&($a['type']??'')===$c['tipo_whatsapp']));
        if(count($wa)>1){$out['motivo']='atividade_whatsapp_duplicada';return $out;}
        $a=$wa[0]??null;if($a&&!empty($a['done'])){$out['motivo']='atividade_concluida';return $out;}
        $progress=self::progress($lead,$a,$c,$now,$account);$index=$progress['indice'];
        if($progress['ambiguo']){$out['motivo']='historico_sem_marcador';return $out;}
        $out['origem_progresso']=$progress['origem'];
        $wait=$c['espera_entrega']??[];
        if(!empty($wait['habilitada'])&&Rules::matches($lead,$wait['condicao'])){
            $since=$wait['campo_desde']!==''?Collection::instant(Collection::field($lead,$wait['campo_desde'])):$progress['ultimo'];
            if($since===null||$since>$now){$out['motivo']='instante_entrega_indisponivel';return $out;}
            $review=$since+$wait['rever_minutos']*60;$end=$since+$wait['encerrar_minutos']*60;$closing=$now>=$end;
            $out['acao']=$closing?'encerrar':'verificar_entrega';$out['estado_espera']=$now<$review?'aguardando_verificacao':($closing?'limite_sem_entrega':'verificar_sem_entrega');
            $out['rever_em_utc']=gmdate('Y-m-d\TH:i:s\Z',$review);$out['limite_em_utc']=gmdate('Y-m-d\TH:i:s\Z',$end);
            return self::due($out,['instante'=>$closing?$end:$review,'periodo'=>null],$c,$now);
        }
        if(!isset($c['toques'][$index])){$out['motivo']='cadencia_concluida';return $out;}
        $t=$c['toques'][$index];$base=$t['base']==='entrada'?Collection::instant($lead['add_time']??null):$progress['ultimo'];
        if($base===null){$out['motivo']='instante_base_indisponivel';return $out;}
        $slot=Rules::deadline($base,$t,$c);$text=Rules::text($lead,$t,$c);
        $out['toque']=$t['codigo'];$out['acao']=$t['acao']??'mensagem';$out['texto_id']=$text['id'];$out['texto_aprovado']=$text['texto'];
        $out=self::due($out,$slot,$c,$now);
        if($text['motivo']!==null){$out['motivo']=$text['motivo'];$out['devido']=false;}
        return $out;
    }
    private static function due(array $out,array $slot,array $c,int $now): array {
        $out['periodo']=$slot['periodo'];$out['devido_em_utc']=gmdate('Y-m-d\TH:i:s\Z',$slot['instante']);
        $within=Rules::within($now,$c);$out['devido']=$within&&$slot['instante']<=$now;
        $out['motivo']=$out['devido']?null:($within?'aguardando_prazo':'fora_da_janela');
        if($out['acao']==='encerrar'&&(!$out['politica_canal']['encerramento']||!$out['politica_canal']['arquivamento'])){$out['devido']=false;$out['texto_aprovado']=null;$out['motivo']='canal_protegido';}
        return $out;
    }

    public static function queue(array $i,?array $candidate=null,?Collection $reader=null): array {
        $cfg=Configuration::read();$c=$candidate??$cfg['regras'];$reader??=new Collection($i);$now=isset($i['agora'])?Collection::instant($i['agora']):time();if($now===null)throw new Fault('entrada_invalida','agora deve ser RFC3339 UTC.');
        $leads=$reader->all('/v1/leads');$activities=$c['habilitada']?$reader->all('/api/v2/activities'):[];
        // Index only activities for leads in this response. Fetch details only when their note is needed.
        $visible=array_fill_keys(array_column(array_slice($leads,0,200),'id'),true);$byLead=[];
        foreach($activities as $a){
            $id=$a['lead_id']??null;if(!is_string($id)||!isset($visible[$id])||($a['type']??null)!==$c['tipo_whatsapp'])continue;
            if(!array_key_exists('note',$a)){
                try{$a=$reader->one('/api/v2/activities/'.(int)$a['id']);if(($a['lead_id']??null)!==$id||($a['type']??null)!==$c['tipo_whatsapp']||!array_key_exists('note',$a))throw new Fault('estado_incompleto','Detalhe de atividade incompleto.');}
                catch(Fault $e){$reader->issues[]=$e->reason;continue;}
            }
            $byLead[$id][]=$a;
        }
        $out=[];foreach($leads as $lead){if(count($out)>=200){$reader->issues[]='limite_de_saida';break;}try{$row=self::evaluate($lead,$byLead[$lead['id']]??[],$c,$now,$reader->status['conta']);}catch(Fault $e){$row=['lead_id'=>$lead['id'],'devido'=>false,'texto_aprovado'=>null,'motivo'=>$e->reason];}if(!$c['habilitada'])$row['motivo']='configuracao_pendente';$out[]=$row;}
        $result=$reader->result(['itens'=>$out,'revisao'=>$cfg['revisao'],'simulada'=>$candidate!==null,'agora_utc'=>gmdate('Y-m-d\TH:i:s\Z',$now)]);
        if(!$result['data']['coleta_completa'])foreach($result['data']['itens'] as &$row){$row['devido']=false;$row['texto_aprovado']=null;$row['motivo']='coleta_incompleta';}unset($row);
        return $result;
    }
}
