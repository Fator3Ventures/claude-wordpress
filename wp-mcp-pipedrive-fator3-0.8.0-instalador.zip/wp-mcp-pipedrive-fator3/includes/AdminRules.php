<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Forms only translate input. The same domain validation, account binding and receipts serve MCP and wp-admin. */
final class AdminRules {
    private const DAYS=[1=>'Segunda',2=>'Terça',3=>'Quarta',4=>'Quinta',5=>'Sexta',6=>'Sábado',7=>'Domingo'];
    private const GROUPS=['habilitada'=>'Ativação','fuso'=>'Fuso horário','dias'=>'Dias da semana','janela'=>'Janela diária','periodos'=>'Períodos','feriados'=>'Feriados','tipo_whatsapp'=>'Tipo de atividade','archive_reasons'=>'Motivos de arquivamento','lost_reasons'=>'Motivos de perda','toques'=>'Toques','textos'=>'Textos aprovados','exclusoes'=>'Exclusões','auditoria'=>'Auditoria','nota'=>'Formato da nota','variaveis'=>'Variáveis','canais'=>'Canais','espera_entrega'=>'Espera de entrega','adocao'=>'Adoção de histórico'];
    public static function render(string $action): void {
        Support::admin();$response=Api::dispatch('configuracao-ler');
        if(!$response['success']){Admin::notice($response['message']);return;}
        $saved=$response['data'];$posted=in_array($action,['rules_validate','rules_simulate'],true);
        $mode=($posted?Admin::text($_POST,'modo'):Admin::text($_GET,'modo'))==='json'?'json':'guiado';
        $review=null;$candidate=null;
        if($action==='rules_apply'){
            $id=Admin::text($_POST,'previa_id');check_admin_referer('f3pd_apply_'.$id);
            try{
                if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new Fault('previa_invalida','Identificador de prévia inválido.');
                if(Admin::text($_POST,'ordem')!=='1')throw new Fault('confirmacao_ausente','Confirme que recebeu a ordem do dono para esta prévia.');
                $r=Workflows::applySettings(['previa_id'=>$id,'confirmacao'=>Admin::text($_POST,'confirmacao')]);
                Admin::notice($r['message'],$r['success']);$saved=Configuration::read();
            }catch(Fault $e){
                if($e->reason==='confirmacao_ausente'){
                    try { $review=self::retryReview($id,$saved['revisao']); }
                    catch(Fault $unavailable){ $e=$unavailable; }
                }
                Admin::notice($e->getMessage());
            }
        }elseif($posted){
            check_admin_referer('f3pd_rules_edit');
            try{
                $revision=Admin::text($_POST,'revisao_esperada');
                if(!hash_equals($saved['revisao'],$revision))throw new Fault('revisao_conflitante','As regras mudaram depois que você abriu a tela. Recarregue as regras atuais e revise as diferenças.');
                $candidate=self::candidate($_POST,$saved['regras'],$mode);
                if($action==='rules_validate')Admin::notice('Campos válidos. A configuração em vigor continua igual. O próximo passo é simular na conta.',true);
                else{
                    $r=Api::dispatch('configuracao-simular',['regras'=>$candidate,'revisao_esperada'=>$revision]);
                    if(!$r['success'])Admin::notice($r['message']);
                    elseif($r['code']!=='simulacao_criada'){Admin::notice('Coleta incompleta. Nenhuma prévia aplicável foi criada. Motivos: '.implode(', ',$r['data']['motivos']??[]).'.');}
                    else $review=$r['data'];
                }
            }catch(Fault $e){Admin::notice($e->getMessage());}
        }
        if($review!==null)self::confirmation($review,$saved['regras'],$mode);
        echo '<section class="f3pd-panel"><h2>Regras de operação</h2><p>A cadência usa os dias, horários e textos aprovados para calcular o próximo toque de cada lead. O registro de WhatsApp documenta uma mensagem já enviada pelo operador. Ao criar a atividade, usa a pessoa vinculada ao lead como participante principal.</p><p>A nota recebe o texto configurado; o progresso da cadência é guardado neste site. Preserve o banco e os salts nas cópias de segurança.</p>';
        echo '<dl class="f3pd-facts">';foreach(['Regras em vigor'=>$saved['origem']==='configurado'?'Configuração salva':'Padrão inicial','Cadência'=>$saved['regras']['habilitada']?'Habilitada':'Desligada','Toques configurados'=>count($saved['regras']['toques'])] as $k=>$v)echo '<div><dt>'.esc_html($k).'</dt><dd>'.esc_html((string)$v).'</dd></div>';echo '</dl>';
        echo '<nav class="f3pd-mode" aria-label="Modo de edição">';foreach(['guiado'=>'Calendário e motivos','json'=>'Configuração completa (JSON)'] as $k=>$title)echo '<a '.($mode===$k?'aria-current="page" ':'').'href="'.esc_url(Admin::url('regras',['modo'=>$k])).'">'.esc_html($title).'</a>';echo '</nav><p class="description">Trocar o modo de edição recarrega as regras em vigor.</p></section>';
        echo '<form method="post" action="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">';wp_nonce_field('f3pd_rules_edit');
        $revision=$posted?Admin::text($_POST,'revisao_esperada'):$saved['revisao'];
        echo '<input type="hidden" name="modo" value="'.esc_attr($mode).'"><input type="hidden" name="revisao_esperada" value="'.esc_attr($revision).'">';
        if($mode==='json'){
            $default=wp_json_encode($saved['regras'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            echo '<section class="f3pd-panel"><h2>Configuração completa</h2><p>Use este modo para editar toques, textos, campos da conta, canais, auditoria e adoção de histórico. Comece pela configuração atual. As propriedades opcionais omitidas serão removidas ao aplicar.</p>';
            self::area('regras_json','Objeto de regras',$posted?Admin::text($_POST,'regras_json'):$default,'JSON completo, até 64 KiB de dados após a leitura. Não inclua tokens nem dados de clientes.',18,true);echo '<p><a href="'.esc_url(Admin::url('ajuda',['documento'=>'fluxos'])).'">Consultar formatos e exemplos</a></p></section>';
        }else self::guided($saved['regras'],$posted);
        echo '<section class="f3pd-panel"><h2>Revisar alterações</h2><p><strong>Validar campos</strong> verifica as regras localmente. <strong>Simular na conta</strong> consulta leads e atividades pelo Site Core, consome orçamento de leitura e prepara uma prévia por 15 minutos. A gravação exige uma confirmação separada.</p><div class="f3pd-actions"><button class="button button-secondary" name="f3_pipedrive_action" value="rules_validate">Validar campos</button><button class="button button-primary" name="f3_pipedrive_action" value="rules_simulate">Simular na conta</button><a href="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">Recarregar regras atuais</a></div></section><input type="hidden" name="form_completo" value="1"></form>';
    }
    private static function lines(string $text): array {
        return array_values(array_filter(array_map('trim',preg_split('/\R/u',$text)?:[]),static fn($v)=>$v!==''));
    }
    public static function candidate(array $post,array $current,string $mode): array {
        if(Admin::text($post,'form_completo')!=='1')throw new Fault('formulario_incompleto','O formulário chegou incompleto. Recarregue a página.');
        if($mode==='json'){
            $text=Admin::text($post,'regras_json');if(strlen($text)>131072)throw new Fault('configuracao_invalida','O texto JSON excedeu 128 KiB. O objeto de regras deve caber em 64 KiB.');
            try{$decoded=json_decode($text,false,64,JSON_THROW_ON_ERROR);if(!$decoded instanceof \stdClass)throw new \JsonException();$v=json_decode($text,true,64,JSON_THROW_ON_ERROR);}catch(\JsonException $e){throw new Fault('json_invalido','Informe um objeto JSON válido. Confira aspas, vírgulas e chaves.');}
        }else{
            foreach(['fuso','inicio','fim','periodos','feriados','tipo_whatsapp','archive_reasons','lost_reasons'] as $key)if(!isset($post[$key])||!is_string($post[$key]))throw new Fault('formulario_incompleto','Um campo do formulário está ausente ou inválido. Recarregue a página.');
            $v=$current;$v['habilitada']=Admin::text($post,'habilitada')==='1';$v['fuso']=trim(Admin::text($post,'fuso'));
            $days=$post['dias']??[];if(!is_array($days)||!array_is_list($days))throw new Fault('configuracao_invalida','Seleção de dias inválida.');
            $v['dias']=[];foreach($days as $day){if(!is_string($day)||!preg_match('/^[1-7]$/D',$day))throw new Fault('configuracao_invalida','Dia da semana inválido.');$v['dias'][]=(int)$day;}
            $v['janela']=['inicio'=>Admin::text($post,'inicio'),'fim'=>Admin::text($post,'fim')];$v['tipo_whatsapp']=trim(Admin::text($post,'tipo_whatsapp'));
            $v['periodos']=[];foreach(self::lines(Admin::text($post,'periodos')) as $line){if(!preg_match('/^([a-z0-9_-]{1,40})\s+([0-2][0-9]:[0-5][0-9])$/D',$line,$m))throw new Fault('configuracao_invalida','Em Períodos, use um código e um horário por linha, como manha 09:30.');$v['periodos'][]=['codigo'=>$m[1],'hora'=>$m[2]];}
            $holidays=self::lines(Admin::text($post,'feriados'));if($holidays||array_key_exists('feriados',$v))$v['feriados']=$holidays;
            foreach(['archive_reasons','lost_reasons'] as $key)$v[$key]=self::lines(Admin::text($post,$key));
        }
        return Configuration::validate($v);
    }
    private static function guided(array $c,bool $posted): void {
        $v=static fn($key,$fallback)=>$posted?Admin::text($_POST,$key):$fallback;
        echo '<section class="f3pd-panel"><h2>Cadência e calendário</h2><p>Os horários abaixo seguem o fuso escolhido. Este formulário preserva os textos, toques e restrições que não aparecem aqui.</p>';
        $enabled=$posted?Admin::text($_POST,'habilitada')==='1':$c['habilitada'];
        echo '<p><label><input type="checkbox" name="habilitada" value="1" '.checked($enabled,true,false).' aria-describedby="f3pd-enable-help"> Habilitar cadência</label></p><p id="f3pd-enable-help" class="description">Para habilitar, configure dias, períodos, tipo de atividade e ao menos um toque com texto aprovado. Toques e textos ficam na configuração completa.</p><div class="f3pd-grid">';
        self::field('fuso','Fuso horário',$v('fuso',$c['fuso']),'Exemplo: America/Sao_Paulo ou UTC.');self::field('tipo_whatsapp','Tipo de atividade WhatsApp',$v('tipo_whatsapp',$c['tipo_whatsapp']),'Código do tipo de atividade na conta Pipedrive.');echo '</div>';
        echo '<fieldset><legend>Dias úteis da cadência</legend><div class="f3pd-week">';$days=$posted?(is_array($_POST['dias']??null)?$_POST['dias']:[]):array_map('strval',$c['dias']);foreach(self::DAYS as $n=>$label)echo '<label><input type="checkbox" name="dias[]" value="'.(int)$n.'" '.checked(in_array((string)$n,$days,true),true,false).'> '.esc_html($label).'</label>';echo '</div></fieldset><div class="f3pd-grid">';
        self::field('inicio','Início da janela',$v('inicio',$c['janela']['inicio']),'Hora local de início.','time');self::field('fim','Fim da janela',$v('fim',$c['janela']['fim']),'No mesmo dia, após o início.','time');echo '</div><div class="f3pd-grid">';
        self::area('periodos','Períodos',$v('periodos',implode("\n",array_map(static fn($p)=>$p['codigo'].' '.$p['hora'],$c['periodos']))),'Um código e um horário por linha. Exemplo: manha 09:30.',4);
        self::area('feriados','Feriados',$v('feriados',implode("\n",$c['feriados']??[])),'Uma data por linha, no formato AAAA-MM-DD. Esses dias ficam fora da cadência.',4);echo '</div></section>';
        echo '<section class="f3pd-panel"><h2>Motivos permitidos</h2><p>Use um motivo por linha, como deve aparecer na conta. Somente motivos presentes na lista podem ser usados pelo fluxo correspondente.</p><div class="f3pd-grid">';
        self::area('archive_reasons','Arquivamento de leads',$v('archive_reasons',implode("\n",$c['archive_reasons'])),'Usados ao concluir e arquivar um lead.',5);self::area('lost_reasons','Perda de negócios',$v('lost_reasons',implode("\n",$c['lost_reasons'])),'Uma lista vazia impede registrar perda por este fluxo.',5);echo '</div></section>';
    }
    private static function field(string $name,string $label,string $value,string $help,string $type='text'): void {
        echo '<div class="f3pd-field"><label class="f3pd-label" for="f3pd-'.esc_attr($name).'">'.esc_html($label).'</label><input type="'.esc_attr($type).'" id="f3pd-'.esc_attr($name).'" name="'.esc_attr($name).'" value="'.esc_attr($value).'" aria-describedby="f3pd-'.esc_attr($name).'-help"><p class="description" id="f3pd-'.esc_attr($name).'-help">'.esc_html($help).'</p></div>';
    }
    private static function area(string $name,string $label,string $value,string $help,int $rows,bool $code=false): void {
        echo '<div class="f3pd-field"><label class="f3pd-label" for="f3pd-'.esc_attr($name).'">'.esc_html($label).'</label><textarea id="f3pd-'.esc_attr($name).'" name="'.esc_attr($name).'" rows="'.$rows.'" class="'.($code?'f3pd-code':'').'" aria-describedby="f3pd-'.esc_attr($name).'-help">'.esc_textarea($value).'</textarea><p class="description" id="f3pd-'.esc_attr($name).'-help">'.esc_html($help).'</p></div>';
    }
    /** Recover only the current actor's unclaimed config preview; never simulate or revive it. */
    private static function retryReview(string $id,string $revision): array {
        $row=Store::get($id); // Includes actor check.
        if($row['state']==='running')throw new Fault('resultado_incerto','Esta prévia já foi iniciada. Confira o diário antes de tentar novamente.');
        if($row['state']!=='ready' || (int)$row['expires']<=time())throw new Fault('previa_indisponivel','Esta prévia não está disponível para correção. Consulte o diário antes de iniciar outra simulação.');
        $p=Support::open($row['payload']);
        if(($p['workflow']??null)!=='configuracao')throw new Fault('operacao_invalida','A tela de regras aceita somente uma prévia de configuração.');
        if(!hash_equals($revision,$p['config_revision']))throw new Fault('revisao_conflitante','As regras mudaram. Recarregue a configuração atual e simule novamente.');
        if(!hash_equals($row['binding'],CoreClient::binding(CoreClient::status())))throw new Fault('contexto_alterado','A conta ou autorização mudou. Confira a conexão antes de simular novamente.');
        return ['previa_id'=>$id,'confirmacao_exigida'=>$p['confirmacao'],'regras'=>$p['input'],'expira'=>$row['expires']];
    }
    private static function confirmation(array $review,array $old,string $mode): void {
        $changes=[];foreach(self::GROUPS as $key=>$label)if(Support::digest($old[$key]??null)!==Support::digest($review['regras'][$key]??null))$changes[]=$label;
        $retry=!isset($review['simulacao']);
        echo '<section class="f3pd-panel f3pd-confirm"><p class="f3pd-overline">Regras de operação · Confirmação</p><h2>'.($retry?'Corrigir a confirmação':'Revisar prévia antes de aplicar').'</h2><p><strong>Grupos alterados:</strong> '.esc_html($changes?implode(', ',$changes):'Nenhuma diferença de conteúdo').'.</p>';
        if($retry){
            echo '<p>A simulação anterior continua disponível até '.esc_html(gmdate('H:i:s',(int)$review['expira'])).' UTC. Nenhuma regra foi salva por esta tentativa. Você pode corrigir a confirmação sem consultar os leads de novo.</p>';
        }else{
            $sim=$review['simulacao'];$rows=$sim['itens'];$due=count(array_filter($rows,static fn($r)=>!empty($r['devido'])));
            echo '<p>'.count($rows).' leads avaliados; '.$due.' com ação devida. Leituras pelo Site Core: '.(int)$sim['custo']['chamadas'].'. Prazo da prévia: 15 minutos.</p>';
            if($rows){echo '<details><summary>Ver resultado por lead (até 20)</summary><ul>';foreach(array_slice($rows,0,20) as $row)echo '<li>Lead <code>'.esc_html((string)$row['lead_id']).'</code>: '.esc_html((string)($row['motivo']??$row['acao']??'devido')).' · '.esc_html((string)($row['devido_em_utc']??'sem vencimento')).'</li>';echo '</ul></details>';}
        }
        echo '<h3>Confirmar a aplicação</h3><p id="f3pd-confirm-help">Após receber a ordem do dono, copie a frase inteira e cole no campo abaixo. A confirmação aplica somente as regras desta prévia.</p><code class="f3pd-phrase">'.esc_html($review['confirmacao_exigida']).'</code><form method="post" action="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">';wp_nonce_field('f3pd_apply_'.$review['previa_id']);
        echo '<input type="hidden" name="f3_pipedrive_action" value="rules_apply"><input type="hidden" name="previa_id" value="'.esc_attr($review['previa_id']).'"><p><label class="f3pd-label" for="f3pd-confirm">Frase de confirmação</label><input class="large-text" id="f3pd-confirm" name="confirmacao" type="text" autocomplete="off" spellcheck="false" aria-describedby="f3pd-confirm-help" required></p><p><label><input type="checkbox" name="ordem" value="1" required> Recebi a ordem do dono para aplicar estas regras.</label></p><div class="f3pd-actions"><button class="button button-primary">Aplicar regras simuladas</button><a href="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">Voltar às regras em vigor</a></div></form></section>';
    }
}
