<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Present the Markdown constructs used in bundled guides. All document text stays inert. */
final class AdminDocument {
    private static function inline(string $text): string {
        $out = '';
        $tokens = preg_split('/(`[^`]+`|\*\*[^*]+\*\*)/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        foreach ($tokens ?: [] as $n => $token) {
            if (($n % 2) === 0) { $out .= esc_html($token); }
            elseif (str_starts_with($token, '`')) { $out .= '<code>'.esc_html(substr($token, 1, -1)).'</code>'; }
            else { $out .= '<strong>'.esc_html(substr($token, 2, -2)).'</strong>'; }
        }
        return $out;
    }

    private static function cells(string $line): array {
        return array_map('trim', explode('|', trim(trim($line), '|')));
    }

    public static function render(string $source): string {
        $lines = preg_split('/\R/u', $source) ?: [];
        $out = '';
        $sections = [];
        $paragraph = [];
        $list = null;
        $flush = static function () use (&$out, &$paragraph, &$list): void {
            if ($paragraph) { $out .= '<p>'.self::inline(implode(' ', $paragraph)).'</p>'; $paragraph = []; }
            if ($list !== null) { $out .= '</'.$list.'>'; $list = null; }
        };

        for ($i = 0, $n = count($lines); $i < $n; ++$i) {
            $line = trim($lines[$i]);
            if ($line === '') { $flush(); continue; }
            if (str_starts_with($line, '```')) {
                $flush();
                $code = [];
                while (++$i < $n && !str_starts_with(trim($lines[$i]), '```')) { $code[] = $lines[$i]; }
                $out .= '<pre tabindex="0"><code>'.esc_html(implode("\n", $code)).'</code></pre>';
                continue;
            }
            if (preg_match('/^(#{1,6})\s+(.+)$/u', $line, $match)) {
                $flush();
                $depth = strlen($match[1]);
                $level = min(6, $depth + 1);
                $id = 'f3pd-doc-'.($i + 1);
                if ($depth === 2) { $sections[$id] = $match[2]; }
                $out .= '<h'.$level.' id="'.$id.'" tabindex="-1">'.self::inline($match[2]).'</h'.$level.'>';
                continue;
            }
            if (str_starts_with($line, '|') && preg_match('/^\|(?:\s*:?-{3,}:?\s*\|)+\s*$/D', trim($lines[$i + 1] ?? ''))) {
                $flush();
                $heads = self::cells($line);
                $out .= '<div class="f3pd-table" role="region" aria-label="Tabela do guia" tabindex="0"><table class="widefat striped"><thead><tr>';
                foreach ($heads as $cell) { $out .= '<th scope="col">'.self::inline($cell).'</th>'; }
                $out .= '</tr></thead><tbody>';
                ++$i;
                while ($i + 1 < $n && str_starts_with(trim($lines[$i + 1]), '|')) {
                    $out .= '<tr>';
                    foreach (self::cells($lines[++$i]) as $cell) { $out .= '<td>'.self::inline($cell).'</td>'; }
                    $out .= '</tr>';
                }
                $out .= '</tbody></table></div>';
                continue;
            }
            if (preg_match('/^([-*]|\d+\.)\s+(.+)$/u', $line, $match)) {
                $tag = ctype_digit($match[1][0]) ? 'ol' : 'ul';
                if ($list !== $tag) {
                    $flush();
                    $start = $tag === 'ol' ? (int)$match[1] : 1;
                    $out .= '<'.$tag.($start > 1 ? ' start="'.$start.'"' : '').'>';
                    $list = $tag;
                }
                $out .= '<li>'.self::inline($match[2]).'</li>';
                continue;
            }
            if ($list !== null) { $flush(); }
            $paragraph[] = $line;
        }
        $flush();
        $nav = '';
        if (count($sections) > 1) {
            $nav = '<nav class="f3pd-contents" aria-label="Nesta página"><strong>Nesta página</strong><ul>';
            foreach ($sections as $id => $title) { $nav .= '<li><a href="#'.$id.'">'.self::inline($title).'</a></li>'; }
            $nav .= '</ul></nav>';
        }
        return '<article class="f3pd-document f3pd-guide">'.$nav.$out.'</article>';
    }
}
