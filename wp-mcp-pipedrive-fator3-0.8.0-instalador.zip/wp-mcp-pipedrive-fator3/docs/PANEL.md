# Configurar o Pipedrive pelo WordPress

Abra **Ferramentas → Fator3 MCP Pipedrive** com uma conta que tenha `manage_options`. O painel tem quatro seções. Abrir ou trocar de seção é uma leitura: não salva regras, expurga linhas, consulta o CRM nem envia mensagens.

| Seção | Quando usar | O que observar |
| --- | --- | --- |
| Visão geral | Começar ou diagnosticar a instalação | Autorização, conta, consumo do orçamento local e estado da cadência. O token fica no Site Core. |
| Regras de operação | Preparar e aprovar uma mudança comercial | Calendário e motivos em campos guiados; edição completa em JSON para textos, toques, canais, espera, auditoria e adoção. |
| Diário e retenção | Investigar uma tentativa ou conservar seu histórico | UTC, estado, ID da prévia, chaves alteradas e saldo quando disponível. O prazo do diário é independente dos recibos. |
| Ajuda | Consultar um exemplo ou contrato | Use o índice “Nesta página” nos guias com vários assuntos. Arquivos longos, como o catálogo JSON, têm navegação por partes. |

## Primeiro acesso

1. Confira a **Visão geral**. “Autorização pendente” pede revisão da autorização do consumidor `operacao` no Site Core. “Cliente do Site Core indisponível” indica que o contrato atual não foi registrado. A ajuda e a validação de campos continuam disponíveis nesses estados.
2. Abra **Regras de operação**. O painel identifica se as regras são o padrão inicial ou uma configuração já salva. Anote os códigos reais da conta antes de editar. Nenhum fuso, canal, motivo de perda, ID ou texto de negócio é inferido.
3. Na edição guiada, escolha dias, fuso e janela. Informe um período por linha, por exemplo `manha 09:30`. Um feriado usa `AAAA-MM-DD`. Preencha motivos de arquivamento e perda em listas distintas. O modo guiado preserva todos os grupos que não exibe.
4. Para configurar toques ou mensagens, abra **Configuração completa (JSON)** a partir das regras em vigor e consulte o documento `fluxos`. Os campos opcionais omitidos nesse modo saem da próxima configuração. Trocar de modo ou recarregar a página descarta um rascunho não aplicado.

## Validar, simular e aplicar

**Validar campos** verifica estrutura, tipos, calendário e referências. É local: não faz HTTP, não cria prévia e não altera o banco. Uma validação bem-sucedida não confirma se um ID existe na conta.

**Simular na conta** lê leads e, com a cadência habilitada, atividades pelo cliente do Site Core. A leitura consome o orçamento de operação. Coleta incompleta não libera aplicação. A simulação completa cria uma prévia local cifrada, vinculada ao administrador, à conta, à revisão das regras e ao prazo de 15 minutos. A tela mostra os grupos alterados, o total de leads e quantos têm ação devida; apresenta até 20 IDs e vencimentos. Não mostra os textos individuais interpolados no resumo.

**Aplicar regras simuladas** exige a ordem do dono, a frase literal daquela prévia e permissão administrativa. Aplica somente a configuração simulada. Editar o formulário depois não muda uma prévia já emitida: simule novamente para aplicar o novo rascunho. Após o sucesso, confira o estado em vigor. Nenhuma dessas ações envia WhatsApp, arquiva lead ou perde negócio.

**Corrigir a confirmação:** se a frase estiver incorreta ou a ordem não estiver marcada, o painel mantém a mesma prévia enquanto ela estiver disponível. Confira os grupos alterados, copie a frase inteira e marque a ordem ao enviar. A correção não estende os 15 minutos nem consome outra leitura de leads. O horário de expiração aparece em UTC. Para abandonar o formulário sem salvar, escolha **Voltar às regras em vigor**.

## Quando a ação é recusada

| Mensagem ou situação | Próximo passo |
| --- | --- |
| Campos inválidos ou JSON ilegível | Corrija o rascunho: confira fuso, janela, períodos, códigos e a estrutura do objeto. Validar campos novamente não grava dados. |
| Revisão conflitante | Outra gravação mudou a configuração. Recarregue as regras atuais, reaplique a edição desejada e gere nova simulação. |
| Coleta incompleta / orçamento indisponível | Consulte o motivo, autorização e orçamento no Core. Não use um subtotal como fila completa. |
| Frase incorreta ou ordem ausente | Use “Corrigir a confirmação” antes do vencimento. A frase e a ordem devem ser informadas na nova tentativa. |
| Prévia expirada, conta alterada ou outro administrador | Verifique o usuário, a conta e a autorização atuais. Uma prévia vencida exige nova simulação; uma de outro usuário ou de uma operação comercial não pode ser aplicada pelo painel. |
| Resultado incerto | Preserve o recibo e consulte o diário. Não gere outra chave para contornar a pendência. |

## Conservar o diário

Deixe **Dias de conservação** em `0` para manter o diário sem prazo. Para um prazo finito, informe de 1 a 36.500 dias e confirme a exclusão futura. Salvar a política não exclui linhas. A limpeza ocorre quando os fluxos previstos a acionam. Ampliar o prazo depois não recupera registros já excluídos. Os recibos comuns duram 180 dias; os de WhatsApp não expiram automaticamente; prévias expiram em 15 minutos.

## Ler a ajuda instalada

Selecione o assunto em **Ajuda**. Os guias completos apresentam títulos, listas e tabelas; **Nesta página** leva diretamente ao assunto escolhido. Exemplos de código preservam espaços e quebras de linha para cópia. Em **Schemas JSON**, o conteúdo é o texto original. Use **Ler próxima parte** para avançar e **Voltar ao início do documento** para recomeçar. Se o arquivo mudar durante a leitura, volte ao início para ler a versão atual. Nenhum desses passos consulta a conta do Pipedrive.

## Mesmo fluxo pelo MCP

`pipedrive/configuracao-ler {}` → `pipedrive/configuracao-simular {regras, revisao_esperada}` → revisar → `pipedrive/operacao-aplicar {previa_id, confirmacao}`. Permissões e limites continuam no servidor. Para ler este guia: `pipedrive/documentacao-ler {"documento":"painel"}`; nas continuações use `offset` e `sha256_esperado` recebidos.
