# Configuração — 0.8.0

Requisitos declarados: WordPress 7.1.4+, PHP 8.3+, 64 bits, OpenSSL AES-256-GCM, mbstring e banco MySQL/MariaDB com InnoDB. Consulte o relatório para as versões realmente executadas. Site único; multisite não é suportado nesta versão.

1. Confirme os requisitos acima e confira o SHA-256 do instalador no relatório de entrega. Para usar a conta Pipedrive, o Site Core deve fornecer o contrato `pipedrive-api-client/1.0.0`. Um administrador pode abrir a ajuda, consultar o diário e ajustar sua retenção mesmo sem o Core.
2. Nos sites-porta definidos pelo dono/frota, instalar `wp-mcp-pipedrive-fator3-0.8.0-instalador.zip`. O ZIP fonte não é instalável. Em instalação limpa, a ativação cria as duas tabelas próprias e registra o schema. Na atualização da 0.7.0, preserve a configuração do Core, os salts e o banco do site. A troca não concede autorização comercial.
3. A credencial permanece no Core (`f3base_pipedrive_token`), usando sua tela e verificação. Nenhum token entra no chat nem neste plugin.
4. Pelo contrato de configuração Core, configurar `f3base_pipedrive_operacao.ativo=true` e conceder acesso ao consumidor `wp-mcp-pipedrive-fator3` no site autorizado, preservando concessões alheias. Consulte o schema efetivo de `f3base/config-core-escrever` e confira a configuração relida no Core. O plugin Pipedrive não grava options de outros plugins.
5. Conferir `pipedrive/status`: contrato 1.0.0, autorização, domínio/conta/usuário esperados, revisão, teto/consumido/reservado e saldo com instante. Compare com a conta e o usuário autorizados para esse site. Essa escolha pertence ao Core.
6. Autorizar explicitamente as rotas na conexão MCP. Registro do provider não concede perfil. Leitura não autoriza api-previa/api-aplicar. Toda operação exige também manage_options.

O orçamento operacao padrão de 3.000/dia UTC, reserva atômica GET=20/escrita=10, piso de saldo oficial 3.000, pausa remota e recuperação são responsabilidade do Core C2–C6. O plugin sempre consulta o cliente; não cria cota paralela. A prévia e a revalidação consomem GETs. Revogar autorização no Core suspende novas operações e leitura de recibos vinculados à conta pela aplicação; documentação e registro técnico local seguem administrativos.

Sem contrato: core_indisponivel. Sem concessão: operacao_nao_autorizada. A interface mostra o diagnóstico, sem pedir token ou fazer reparo automático. Não é necessário instalar Google, Meta ou LinkedIn para usar as funções próprias.


## Política de retenção

Ferramentas → Fator3 MCP Pipedrive → Diário e retenção → Retenção do diário. O campo dias aceita 0 (sem prazo) ou 1–36500. Salvar prazo finito exige marcar a autorização para expurgo futuro. O formulário usa revisão e nonce, e mostra confirmação somente após releitura persistida. Salvar não executa expurgo. Recibos e prévias têm prazos separados, não editáveis nesta versão.

Por MCP, leia retencao-ler, depois use retencao-configurar com a revisao recebida. A escolha fica na option própria f3_pipedrive_retention, JSON e autoload desativado. Ausência da option é o padrão sem prazo; uma leitura não a cria. Atualização/reativação não substitui escolha explícita nem apaga linhas antigas. Uma política ilegível falha fechada, sem escolher um prazo destrutivo por suposição.

## Parâmetros do relatório

Relatório não grava configuração. Parâmetros `campos`, `categorias` e `limite_plano` valem só na requisição. Nome ambíguo requer chave explícita. Motivo de ganho é customizado. O Core continua sendo único dono do token e da autorização operacao.

## Alterar regras com segurança

Acesse Ferramentas → Fator3 MCP Pipedrive → Regras de operação. Calendário e motivos usam campos guiados; toques e estruturas avançadas usam o objeto completo. Valide os campos, simule a leitura e confirme a prévia por ordem do dono. O guia `painel` explica cada campo, a interpretação dos resultados e a recuperação de conflitos.


## Conferência após atualizar

Abra a Ajuda ou consulte `pipedrive/documentacao-ler {"documento":"release"}`: a resposta deve trazer a versão 0.8.0 e o hash do documento instalado. Depois leia `pipedrive/configuracao-ler {}` e `pipedrive/retencao-ler {}`; confira se as regras, revisões e prazos permanecem os esperados. Em `pipedrive/status {}`, verifique a autorização do Core separadamente. Se a operação comercial estiver desautorizada, o diagnóstico e os guias locais continuam disponíveis.
