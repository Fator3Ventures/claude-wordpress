# Operação e recuperação — 0.8.0

Sem cron, fila, webhook ou HTTP próprio. Desativação e desinstalação não chamam a API e preservam as tabelas.

## Armazenamento

`{prefix}f3_pipedrive_operations`: chave de 32 hexadecimais, aleatória para prévias e derivada de HMAC para mensagens, administrador, digest de site/conta/revisão, estado ready/running/done/expired, prazos, payload e result cifrados AES-256-GCM. A prévia guarda corpo a enviar e hash do estado atual, sem persistir a cópia integral do estado lido. Payload removido ao concluir; pendentes expirados são esvaziados na próxima operação de manutenção sob demanda. Recibos comuns cifrados têm retenção ordinária de 180 dias; os de WhatsApp não têm expurgo automático. Os salts WordPress são necessários para decifrar.

`{prefix}f3_pipedrive_journal`: ID sequencial, previa_id único, instante UTC e metadados. Caminho com IDs, classe, status, chaves e saldo; nomes/opções de estrutura permitidos. Nenhum conteúdo de nota ou valor de campo pessoal é gravado no diário. O recibo privado cifrado é separado da auditoria; ele pode conter a resposta privada do fornecedor, necessária à repetição exata.

O diário tem **retenção sem prazo por padrão**: a limpeza de recibos vencidos não remove sua linha. Uma escolha explícita de 1–36.500 dias habilita expurgo do diário pelo instante UTC original; 0 desabilita esse expurgo. Configuração pelo painel ou retencao-configurar com revisão e confirmação para prazo finito. status.data.retencao e retencao-ler mostram a política efetiva. Salvar altera somente a política; os dados não são excluídos nessa chamada.

O prazo ordinário dos recibos comuns é de 180 dias desde a criação da prévia. Uma trava de reconciliação vinculada ao ID preserva recibo e diário mesmo quando o recibo já está concluído com resultado parcial ou o prazo do diário é finito. Depois de reconciliar e liberar essa trava, a próxima limpeza volta a aplicar os prazos vigentes pelo instante original. Recibos de mensagem WhatsApp são permanentes para impedir duplicação futura. Após remover um recibo, previa_id deixa de poder reproduzir a resposta; isso não impede consultar sua linha técnica preservada. Nunca usar recibo vencido como justificativa para repetir uma mutação. Reconcilie o fornecedor antes de nova intenção.

Limpeza sob demanda em prévia/aplicação, sem agendamento. Sem novas escritas, dados vencidos podem permanecer fisicamente. Tentativas running e suas linhas são preservadas para reconciliação mesmo com prazo finito; seu payload expirado é esvaziado na limpeza. Leitura de ajuda/status/registro/política não aciona reparo ou limpeza. Configuração e limpeza compartilham trava por banco/tabela de options; indisponibilidade da trava recusa a operação conservadoramente.

## Uma tentativa por prévia

UPDATE condicional ready→running e INSERT único na auditoria são confirmados em transação InnoDB antes do despacho. Duas execuções não podem adquirir a mesma prévia. Depois da chamada, recibo e auditoria são concluídos em outra transação. Falha de confirmação mantém a operação conservadoramente incerta. Nunca resetar running para ready para tentar novamente.

Falha entre a aquisição e o HTTP também fica incerta: a segurança contra duplicação tem prioridade. Reconciliar no fornecedor e registrar decisão administrativa fora do plugin antes de nova operação. Não há ferramenta de desbloqueio automático ou replay forçado.

## Identificadores de lead e pendências anteriores

O mesmo UUID, em qualquer combinação de maiúsculas e minúsculas, usa uma única trava de escrita. Na atualização, o plugin preserva os marcadores da 0.7.0. Se o recibo ou o payload cifrado ainda identifica o registro, o bloqueio é limitado ao lead e à conta correspondentes. Negócios permanecem isolados por seu ID numérico.

O erro reconciliacao_necessaria também pode indicar um marcador antigo sem evidência suficiente para excluir aquele lead. O plugin procura no máximo 64 marcadores antigos e testa até 256 grafias quando precisa excluir um vínculo sem recibo legível. Se não conseguir provar que é outro registro, interrompe a escrita antes do fornecedor. Guarde o ID da prévia, consulte o diário, confronte o efeito na conta e preserve a cópia dos dados para a decisão do administrador. Não apague o marcador para repetir a ação.

## Instalação e recuperação

Atualização direta 0.7.0 → 0.8.0. A troca preserva tabelas, estado de operações, regras, revisão e prazos. Não ativa conexão nem cadência. A versão do consumidor participa da revisão Core: confira o contexto de prévias anteriores antes de aplicar.

Se a atualização for interrompida, preserve banco, salts, recibos e tentativas pendentes. Confira os arquivos, a versão em nova requisição e a saúde do WordPress. Isole o fluxo afetado e corrija em nova versão; não há downgrade. Backup recupera dados e não desfaz operações executadas no fornecedor. Consulte `fluxos` para reconciliação e `painel` para investigar uma tentativa.

## Progresso privado da cadência

`progresso_divergente` indica mudança de atividade ou de texto depois do registro local; `progresso_incompativel` indica toque removido das regras. `atividade_nao_confirmada` indica releitura divergente após o envio. Preserve recibo, diário, tabela de operações e salts; confira a atividade e a sequência antes de decidir uma correção. Não exclua o estado privado para repetir um envio já registrado. A retenção do diário não reinicia a cadência.

O aceite do Pedido 11 em korvena.com.br requer uma pessoa vinculada, lead de teste criado e excluído no mesmo trabalho, nota sem novo marcador, participante principal conferido e repetição com o recibo original. Os ensaios sintéticos não substituem esse aceite da conta.
