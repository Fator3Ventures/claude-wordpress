# Especificação — 0.8.0

As 19 operações `pipedrive/*` exigem `manage_options` no WordPress. A conexão MCP também precisa de autorização para a operação. A ajuda e o diário leem o armazenamento local. As operações que consultam a conta usam exclusivamente o cliente do Site Core.

| Finalidade | Operações | Efeito principal |
| --- | --- | --- |
| Orientar e diagnosticar | `documentacao-ler`, `status` | Documentos instalados; estado local do contrato, da autorização e do orçamento, sem HTTP. |
| Consultar a conta | `api-ler`, `relatorio`, `cadencia-fila`, `auditoria`, `contar-por-campo` | GET pelo Core, com custo e limites de cobertura. A fila calcula vencimentos; não envia mensagens. |
| Configurar as regras | `configuracao-ler`, `configuracao-simular` | Leitura local; simulação consulta a conta e pode armazenar uma prévia local. Só a confirmação por `operacao-aplicar` salva as regras. |
| Aplicar uma operação da lista fechada | `api-previa`, `api-aplicar` | Prévia cifrada com validade de 15 minutos, revalidação e tentativa única; operações de estrutura exigem frase literal. |
| Operar por etapas | `whatsapp-registrar`, `lead-encerrar`, `negocio-perder`, `lead-arquivado-editar`, `operacao-aplicar` | Registro de mensagem já enviada ou prévia de workflow. A confirmação usa a identidade da prévia e deixa recibo. |
| Investigar e conservar histórico | `registro-ler`, `retencao-ler`, `retencao-configurar` | Consulta do diário e da política; gravação local com revisão, sem executar expurgo no salvamento. |

## Lista GET

* `/v1/leads/{uuid}`, `/v1/leads`, `/v1/leads/archived`; listas aceitam filter_id, limit (1–500), start.
* `/v1/dealFields`, `/v1/personFields`, `/v1/organizationFields`, `/v1/activityFields`, `/v1/noteFields`; limit/start.
* `/v1/filters` (type), `/v1/filters/{id}`, `/v1/leadLabels`, `/v1/activityTypes`, `/v1/users/me`.
* `/v1/notes/{id}`, `/v1/notes` (lead_id, deal_id, person_id, org_id, limit/start).
* `/api/v2/deals/{id}`, `/api/v2/persons/{id}`, `/api/v2/organizations/{id}`, `/api/v2/activities/{id}`.
* `/api/v2/deals`, `/api/v2/deals/archived`, `/api/v2/persons`, `/api/v2/organizations`, `/api/v2/pipelines` e `/api/v2/stages`: limit/cursor. `/api/v2/activities` aceita ainda lead_id/deal_id.

IDs de lead/etiqueta são UUID; os outros são inteiros positivos. Query deve vir em objeto separado. Nenhum caminho aceita URL absoluta, query embutida, encoding de barras, travessia ou merge. `ids`, token, headers e host não são entradas permitidas.

## Lista de escrita

| Classe | Método | Caminho |
|---|---|---|
| registro | PATCH | /v1/leads/{uuid} |
| registro | PUT | /v1/notes/{id} |
| registro | DELETE | /v1/leads/{uuid}, /v1/notes/{id}, /api/v2/persons/{id}, /api/v2/organizations/{id}, /api/v2/deals/{id}, /api/v2/activities/{id} |
| estrutura | POST | /v1/dealFields, /v1/personFields, /v1/organizationFields |
| estrutura | PUT, DELETE | /v1/dealFields/{id}, /v1/personFields/{id}, /v1/organizationFields/{id} |
| estrutura | POST | /v1/filters, /v1/leadLabels |
| estrutura | PUT, DELETE | /v1/filters/{id} |
| estrutura | PATCH, DELETE | /v1/leadLabels/{uuid} |

Os corpos também usam listas fechadas. Lead: title, owner_id, label_ids, person_id, organization_id, value, expected_close_date, visible_to, was_seen, is_archived, archive_reason, origin_id, channel, channel_id e chaves personalizadas de 40 hexadecimais (sufixos currency/start/end/until). Nota: content e pinned_to_deal_flag/person_flag/organization_flag/lead_flag. Campo novo: name, field_type, options; alteração: name, options, remover_opcoes. Filtro novo: name, type, conditions; alteração: name, conditions. Etiqueta: name, color. DELETE não recebe corpo.

Campos existentes e etiquetas são localizados no catálogo GET permitido; não se inventa GET de etiqueta individual. Campos usam até vinte páginas, parando quando localizados; paginação inválida/incompleta recusa. Não há busca ou escrita genérica fora dessas listas.

## Integridade

PUT com options compara IDs atuais e recebidos. IDs existentes omitidos exigem correspondência exata em remover_opcoes; a lista e os nomes aparecem na prévia. Esse controle local é removido do corpo enviado ao fornecedor. IDs desconhecidos/duplicados são recusados. Omitir integralmente options conserva as opções atuais (renomeação apenas). Não há substituição por uma lista parcial sem confirmação.

Estrutura exige frase literal devolvida pela prévia, com data America/Sao_Paulo, método/caminho, chaves e digest da prévia. A frase não comprova por si só que o dono autorizou: o operador deve ter a ordem antes de aplicá-la.

Prévia vinculada a administrador, site, conta, usuário Pipedrive e revisão do Core. Aplicação revalida autorização e estado; mudança exige nova prévia. O Core precisa validar revisao_esperada no despacho para fechar a janela de troca de conta. Alterações feitas por terceiros entre o último GET e a escrita continuam limitadas pela ausência de compare-and-swap remoto no fornecedor.

A exclusão não é desfeita por este plugin. Lixeira, prazo e tipos recuperáveis devem ser conferidos na conta; não se garante restauração de toda entidade. Exclusão de campo/opção destrói valores. Filtro/etiqueta excluídos não têm reversão automática.

Fora do escopo da API genérica: criação livre de registros, merge, exclusão em massa, webhooks, mailbox, arquivos, usuários/cobrança e escrita em funis/etapas/tipos de atividade. Os workflows têm rotas próprias, descritas em `fluxos`. A fila de cadência é calculada sob demanda; o plugin não agenda envios. Endpoints v2 de campos não são habilitados por suposição; a conta não foi homologada para essa migração.


## Retenção herdada da 0.2.0

Diário técnico permanente por padrão (diario_dias=0); prazo positivo configurável até 36.500 dias por painel/MCP com revisão e confirmação de expurgo futuro. Recibos comuns cifrados têm prazo ordinário de 180 dias; os protegidos por reconciliação pendente continuam preservados; recibos WhatsApp ficam sem expurgo automático e prévias com 900 segundos. Retencao-ler é observacional; retencao-configurar escreve somente política local. Status inclui retencao; registro-ler distingue prazo e sem_prazo. A atualização direta da 0.7.0 conserva as linhas e seus instantes. Sem alteração de schema de tabelas, sem cron e sem autorização comercial automática.

## Relatório agregado herdado da 0.3.0

Pedido 3: leitura agregada paginada com período, completude, custo operacao, dimensões e uso do plano. Sem persistir dados ou emitir textos livres. A semântica completa, limites, códigos, ausência de motivo nativo de ganho e comparação dependente de limite informado estão em USAGE.md.
