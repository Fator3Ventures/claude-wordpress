# Alterações — 0.4.1

- Tradução dos rótulos e estados de diagnóstico, cobertura e concessões; campos técnicos não catalogados usam rótulo em português e conservam a chave em dica técnica. Códigos de API continuam íntegros nos contratos.
- A 0.4.0 foi um marco intermediário instalado no Site-Teste. Seus ZIPs não foram reescritos. O patch 0.4.1 segue a orientação do dono para revisões dentro do mesmo ciclo. Esta entrega atualiza diretamente 0.3.0 e 0.4.0.

## Implementação da 0.4.0

# Alterações — 0.4.0

Atualização direta da 0.3.0, sem migração de tabela ou mudança de identidade.

- Meta 10: abas por assunto com URL própria; conexões locais na abertura; usuários, contas, objetos e formulários selecionados pelo nome; carregamento e falhas por seção; versão da API em Diagnóstico > configuração avançada.
- Agendas: nome, próxima execução em UTC e edição com revisão; edição preserva consulta, horário exato e último recibo quando não alterados.
- Nova operação administrativa `admin-options`, com seleção explícita e revalidação de autorização/revisão. Contratos de relatórios e SDK preservados.
- Meta 11: `page_views_total` aceito em `page_insights`, inclusive série diária; nenhuma substituição por visualização de mídia. Prova com fornecedor real depende de ativo/token e versão.

## Histórico da 0.3.0

# Alterações — 0.3.0

Atualização direta da 0.2.0; nenhuma migração de banco, seleção ou autorização.

- Pedido MCP Meta 1: Description exata com local de configuração.
- Pedido MCP Meta 9: erros Graph numéricos e subcódigos preservados em consultas/coletas; inspeção de permissões do token derivado de cada Página; fallback individual para grupos vazios; ausência e múltiplos buckets explicitados.

## Histórico da 0.2.0

# 0.2.0

- Gate manage_options em todas as entradas humanas e revalidação de tarefas.
- Documentação completa instalada, índice, paginação UTF-8 e revisão/hash.
- Catálogo versionado, séries diárias e grupos de métricas compatíveis.
- Canal Facebook, tokens de Página privados e propriedade de objetos.
- Histórico cifrado independente de jobs, retenção sem expiração, migração, deduplicação e exportação em partes.
- Backfill com início explícito, janela final congelada e retomada.
- Capturas periódicas de mídias/Stories e rotação validada de token.
- Desinstalação conserva dados.

Homologação de métricas reais, disponibilidade de dois anos e comportamento por tipo de mídia dependem dos ativos/escopos do dono; não são deduzidos dos testes simulados.
