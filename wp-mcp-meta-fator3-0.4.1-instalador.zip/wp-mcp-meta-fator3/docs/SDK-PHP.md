# Integração local — Meta 0.4.1

Não há SDK comercial de leads Meta neste plugin. Consumidores usam contratos públicos REST/abilities de relatórios e exportações, com administrador autorizado. Não leiam a tabela cifrada, opções internas ou tokens.

Core continua responsável por Pixel, CAPI, Lead Ads e ingestão comercial. Meta Ads permanece no MCP oficial Meta. Google permanece responsável por suas integrações; esta versão não exporta para Sheets/BigQuery e não migra Porter. A operação de documentação é meta/documentation, com índice e leitura paginada local.
