# Operações Meta — 0.4.1

## Relatórios e catálogo

Instagram: profile, media, stories, account_insights, media_insights, audience, stories_insights. Facebook: page_profile, page_insights, page_posts, post_insights, page_videos, video_insights, page_audience, page_ratings. Consulte list-fields com report e api_version. O catálogo é fechado, versionado e expõe disponibilidade condicional, período, tipo, breakdown, timeframe e horizonte histórico desconhecido. Métricas candidatas não são certificadas para todos os ativos: a API precisa aceitá-las. Demografia legada do Facebook pode estar indisponível; a resposta não a inventa.

account_insights/page_insights aceitam granularity=day ou interval. O comportamento interval preserva a coleta antiga por métrica. day consulta cada dia com limites UTC explícitos e agrupa métricas compatíveis. Cada linha contém data, entidade, métrica, valor ou indisponibilidade. Follows/unfollows usa grupo separado; follower_count e online_followers são condicionais/time_series. Valores únicos não são somados para fabricar total, totais de intervalo não são divididos entre dias e valores acumulados de mídia não são distribuídos retroativamente.

No contexto v24.0 observado no pedido 3, engaged_audience_demographics aceita somente this_month/this_week; last_30_days é recusado localmente com unsupported_timeframe antes de HTTP. A restrição não é generalizada a outra métrica/versão sem prova.

Uma seleção de 14 dias × 10 métricas produz 140 linhas em duas páginas de até 100 quando a origem responde dentro do orçamento. Latência, erros de grupo e quota podem exigir continuações adicionais; nenhum limite autoriza truncar linhas silenciosamente. Parâmetros since/until usam dias UTC; timezone preserva que o calendário da origem pode diferir. Não se certifica alinhamento de um fuso proprietário não documentado.

media_insights requer media_id ou iterate_media=true. stories_insights inventaria Stories ativas e lê métricas de cada objeto. Capturas guardam published_at e observed_at separados. Não há arquivo de imagem/vídeo, scraping, tentativa de recuperar Stories já desaparecidas ou garantia de captura de todas as Stories entre execuções. Recomenda-se agenda de 60 minutos para Stories. post_insights/video_insights requerem entity_id e pertencem ao canal facebook.

## Coletas, agendas e backfill

create-job admite uma seleção fechada e uma chave idempotente. run-job avança uma página; job-status/control-job/job-results permitem acompanhar, pausar, cancelar, retomar e ler. O cron usa os mesmos métodos. A página durável precede o checkpoint, permitindo retomada após interrupção. Limite de 10000 páginas; ao atingi-lo com continuação a coleta termina parcial, nunca completa.

create-backfill requer date_from e fixa date_to (padrão ontem UTC), máximo 3660 dias. A origem não comprova um horizonte universal. Métricas de conta usam day; mídia usa iterate_media para observar o acumulado disponível agora. O plano pode cobrir dois anos, mas a API pode limitar o que entrega: o aceite externo de dois anos exige evidência diária e permanece pendente até execução autorizada. Erros/supressão ficam como lacunas, não zeros.

Agendas mantêm a preferência enabled quando a execução fica bloqueada e registram last_code; nova tentativa ocorre após cinco minutos. Troca validada de token conserva agendas. Cursores remotos de inventário são reiniciados após troca validada, com deduplicação no histórico; exportação bruta do job pode conter observações repetidas da retomada. Cursores de partições diárias conservam a posição local. Alteração de autorização exige salvar novamente a agenda com sua revisão atual.

## Histórico e exportação

O histórico cifrado é independente da retenção do registro do job. Chave lógica considera principal, conexão, canal, conta, relatório, entidade, métrica, dia, temporalidade, API, timeframe e breakdown. Observações sobrepostas atualizam a mesma chave; first_seen/last_seen preservam a procedência. Snapshots guardam o último valor observado em cada dia, não todas as observações intradiárias.

history-query requer conexão/canal/conta, aceita relatório, período, limit e cursor. O cursor fixa seleção, principal, autorização e geração do conjunto. Mudanças do histórico invalidam a continuação com history_changed; reinicie para não misturar visões. Leitura local dispensa token válido, mas exige autorização atual e ativo habilitado.

history-export cria exportação CSV/JSON paginada. Execute history-export-step até state=complete; baixe history-export-read por part e offset_bytes. Concatene partes decodificadas em ordem, sem separador; cada parte tem SHA-256. Validade de 24 horas, limite de 64 MiB por exportação, nenhuma URL pública. CSV mantém row_json/coverage_json para não perder estruturas e neutraliza fórmulas. Exportação de job continua disponível via export/export-read, até 8 MiB de páginas/12 MiB finais.
