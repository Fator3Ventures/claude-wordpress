# Insights de Páginas — diagnóstico da 0.4.1

## Sequência para agentes

1. Ler contracts e este documento por meta/documentation. Não copiar tokens entre sites.
2. Consultar list-connections/get-connection e confirmar que o ID da Página consta em assets.facebook. Descoberta não concede acesso.
3. Executar meta/validate-connection com connection_id, channel=facebook e account_id da Página. Repetir para cada Página selecionada. A operação existente trabalha com um ativo por chamada; não varre ativos alheios.
4. Ler proof.page_permissions. status=verified confirma a inspeção do token derivado; read_insights_granted e pages_read_engagement_granted indicam as concessões efetivas para esse ID. Escopo granular concedido apenas a outra Página resulta false. status=unknown ou invalid_credential não comprova acesso. diagnostic_error contém a recusa sanitizada da inspeção quando existe.
5. Consultar page_insights com uma métrica e um intervalo conhecido; depois ampliar a seleção. Conferir errors e last_error, não apenas status/last_code. Comparações externas precisam da mesma definição, janela, fuso e end_time.

```json
{"connection_id":"minha-conexao","channel":"facebook","account_id":"123456789","report":"page_insights","fields":["page_follows"],"date_from":"2026-10-01","date_to":"2026-10-14","granularity":"day","limit":100}
```

Use meta/query para uma página de resultados ou meta/create-job com query e idempotency_key. Em coletas, execute run-job até estado terminal, respeitando retry/next_at, e leia job-results. max_pages e next_cursor continuam com os limites do schema instalado.

## Interpretação

| Situação | Evidência | Tratamento |
|---|---|---|
| Valor 0 | A origem retornou zero | Preservar como dado disponível. |
| Resposta 200 sem métrica/valor | empty_or_suppressed ou value_unavailable, cause=undetermined | Não afirmar ausência de permissão, falta de seguidores ou descontinuação sem outra prova. |
| Grupo vazio | Nova consulta individual limitada para cada métrica ausente | Usa o mesmo period=day, since e until. Não repete indefinidamente. |
| Recusa por métrica | cause=provider_rejected, reason, provider_code, provider_subcode | Consultar o erro exato do fornecedor. O código legado de indisponibilidade é preservado. |
| Token/ativo recusado | token_rejected/asset_access_denied e details; job pausado com last_error | Corrigir credencial/permissão e revalidar antes de retomar. |
| Mais de um bucket diário | multiple_source_buckets, source_values preservados | Não somar nem escolher um valor arbitrário. Conferir os end_time/fuso da origem. |

Exemplo sanitizado de recusa: `{"code":"unsupported_for_asset_or_version","cause":"provider_rejected","reason":"upstream_validation","http_status":400,"provider_code":100,"provider_subcode":33,"provider_is_transient":false}`. Números são exemplos; não garantem a mesma causa para toda métrica.

## Permissões, limites e privacidade

O token de Página é derivado somente de uma Página selecionada e armazenado cifrado. Sua inspeção usa /debug_token com a credencial de origem, ou App ID/client_secret existentes quando disponíveis. A resposta nunca expõe token de origem, token derivado, app secret, URL, mensagem bruta ou outros ativos. Se a Meta não permitir a inspeção, o resultado fica desconhecido com o erro recebido; não se reutilizam escopos de usuário como prova da Página.

page_profile com seguidores não prova que page_follows estará disponível em uma janela histórica. Permissão verificada também não certifica todos os produtos/métricas ou aprovação comercial. A API pode devolver vazio sem explicar a causa; o plugin preserva essa incerteza. Não preenche uma série com o total atual do perfil.

O intervalo usa since no início UTC e until no início do dia seguinte ao fim solicitado; o end_time original permanece no resultado. Esta correção isola grupos vazios e explicita múltiplos buckets, sem alterar silenciosamente os limites de datas. A comparação de 14 dias com o Porter na Página Fator3 exige execução no ativo autorizado e igualdade de definição/fuso; fixtures não encerram esse aceite.

Anúncios no cabeçalho referem-se às integrações de medição/captação mantidas pelo Core. Gestão de campanhas Meta Ads permanece fora deste plugin e segue no conector oficial da Meta.
