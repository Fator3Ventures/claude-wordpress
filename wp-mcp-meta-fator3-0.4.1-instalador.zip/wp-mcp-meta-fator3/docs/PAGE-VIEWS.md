# Visualizações do perfil da Página — Meta 11

A 0.4.0 inclui `page_views_total` no catálogo `page_insights`. A consulta diária é:

```json
{"connection_id":"conexao-selecionada","channel":"facebook","account_id":"ID_DA_PAGINA_AUTORIZADA","report":"page_insights","date_from":"2026-10-12","date_to":"2026-10-18","granularity":"day","fields":["page_views_total"]}
```

Na interface escolha esses valores pelos seletores e datas; IDs são apenas parte do contrato MCP. A Graph recebe `metric=page_views_total`, `period=day` e uma janela por dia. A versão efetiva da conexão acompanha a resposta. Zero remoto é conservado; ausência ou rejeição produzem valor null e cobertura incompleta, com diagnóstico sanitizado e código/subcódigo quando existentes. Não há substituição por `page_media_view` nem equivalência inferida com visualizações de mídia.

Estado do catálogo: `requires_remote_validation`, candidato em v24.0. A inclusão remove o bloqueio local unsupported_field, mas não é afirmação de disponibilidade universal ou de equivalência com o Porter. Não foi encontrada evidência primária suficiente para declarar aposentadoria global ou um substituto equivalente. A página oficial consultada em 21/10/2026, https://developers.facebook.com/docs/platforminsights/page/deprecated-metrics/ , respondeu HTTP 429 nesta sessão; esse bloqueio documental não prova nada sobre a métrica.

Aceite real pendente: o dono precisa consultar a Página CTO usando esta versão e comparar cada dia e soma de 12–18/10/2026 com o Porter, anotando fuso, versão, campo original e eventual recusa. A origem não foi consultada com uma credencial real nesta rodada: o site autorizado de testes está sem conexões. Nenhum número de fixture é prova do Porter. O pedido Meta 9 permanece como resolvido conforme o relato recebido de 21/10/2026; não foi reaberto.
