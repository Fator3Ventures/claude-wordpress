# Fator3 MCP 0.29.1

Revisão independente da 0.29.0: idempotência exige ausência de efeito explícita; pesquisa considera todos os termos; admin-post GET respeita nonce. Preserva M1–M7 da 0.29.0. Atualização direta de 0.29.0 ou 0.28.0 e instalação limpa. Mínimos WordPress 7.1.2/PHP 8.3.6.

Operação e contratos: docs/OPERACAO.md, RELEASE-0291.md, CONTRATO-EXTENSOES.md, MUTATION-SERVICE-AUDIT.md. Guia instalado via system/guide. Identidade wp-mcp-fator3/wp-mcp-fator3.php preservada.
