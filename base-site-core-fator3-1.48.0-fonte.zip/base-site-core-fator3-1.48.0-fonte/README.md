# Fator3 Site Core 1.48.0 — fonte

Runtime em `work/plugin/base-site-core-fator3`, idêntico ao instalador final. Este ZIP não é instalável. Base direta 1.47.0; contrato administrativo 8.13.0; pedidos 288–290. Instruções de reprodução em `build/README.md`; relatório na raiz, plano e impacto LinkedIn em `release/`.

`companions/` contém cópias intactas dos plugins usados nos testes: MCP 0.28.0, Google 0.17.0, LinkedIn 0.7.0 e Meta 0.6.0. Não entram no instalador do Core. `evidence/` contém provas da rodada e identifica separadamente a preparação de schemas realizada sobre a base. Os testes de regressão `forms-1470.php` e `pipedrive-1470.php` mantêm seus nomes e foram executados contra a 1.48.0. Relatórios anteriores ficam em `history/`.

Banco, runtime PHP/MySQL, WordPress, sessões, dependências baixadas e instalador-base são externos e não acompanham o ZIP. O helper `tests/site-qa-1480.php` é exclusivamente de homologação; foi removido do Site-Teste e não integra o instalador. O relatório externo canônico registra a identidade final deste fonte.
