<?php
/**
 * Gravador único de options do site-core.
 *
 * Regra dura do contrato: nenhuma chamada direta a `update_option`,
 * `update_site_option` ou `delete_option` fora desta classe. Todo módulo, a tela
 * de administração e o `uninstall.php` passam por aqui — o ponto único de escrita
 * é o que torna a leitura de volta e a procedência auditáveis.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Catálogo, sanitização, escrita com leitura de volta e procedência.
 */
require_once __DIR__ . '/trait-f3base-options-persistencia.php';
require_once __DIR__ . '/trait-f3base-options-efeitos.php';
require_once __DIR__ . '/trait-f3base-options-validacao.php';
require_once __DIR__ . '/trait-f3base-options-catalogo.php';
require_once __DIR__ . '/trait-f3base-options-complementacao.php';

final class F3Base_Options {
	use F3Base_Options_Persistencia;
	use F3Base_Options_Efeitos;
	use F3Base_Options_Validacao;
	use F3Base_Options_Catalogo;
    use F3Base_Options_Complementacao;

    private static array $proposta = array();
    private static int $validando = 0;
    public static function segredo_proposto(string $nome): ?string {return self::$validando&&array_key_exists($nome,self::$proposta)&&is_string(self::$proposta[$nome])?self::$proposta[$nome]:null;}
    public static function proposta_ou_ler(string $nome) {return self::$proposta[$nome]??self::ler($nome);}
    public static function com_proposta(array $proposta, callable $callback) { $antes=self::$proposta; self::$proposta=$proposta; try{return $callback();}finally{self::$proposta=$antes;} }
	private static array $escritas_em_curso = array();
	public static function gravando( string $nome ): bool {
		return ! empty( self::$escritas_em_curso[ $nome ] ); }

	/**
	 * Option onde o implantador registra a procedência de cada chave gravada.
	 */
	public const OPTION_PROVENIENCIA = 'f3base_proveniencia';
	public const OPTION_TENTATIVAS   = 'f3base_tentativas_recusadas';
	public const TETO_TENTATIVAS     = 100;
	public const TENTATIVAS_CAS      = 5;
	public const ORIGEM_DESCONHECIDA = 'desconhecida';
	/** Limites compartilhados pela normalização, recusa e contrato consultável. */
	public const FAIXAS                  = array(
		'ttl_dias'           => array( 1, 3650 ),
		'retencao_meses'     => array( 1, 120 ),
		'sessao_dias'        => array( 1, 365 ),
		'acessos_meses'      => array( 1, 120 ),
		'comportamento_dias' => array( 1, 730 ),
		'saltos'             => array( 1, 10 ),
		'hsts_segundos'      => array( 0, 63072000 ),
	);
	public const TAMANHOS                = array(
		'whatsapp'        => 15,
		'whatsapp_minimo' => 8,
		'partner_id'      => 20,
		'tag_id'          => 40,
		'segredo_opaco'   => 512,
		'padrao_log'      => 1024,
		'prefixo_log'     => 191,
		'prefixos_log'    => 100,
		'caminho'         => 500,
	);
	public const PERIODICIDADES          = array( 'nenhuma', 'semanal', 'quinzenal', 'mensal' );
	public const POLITICAS_CONSENTIMENTO = array( 'pre-aprovado', 'negado' );
	public static function limitar( string $faixa, int $valor ): int {
		return max( self::FAIXAS[ $faixa ][0], min( self::FAIXAS[ $faixa ][1], $valor ) ); }

	/**
	 * Option onde o implantador declara quais chaves são operáveis pelo operador.
	 */
	public const OPTION_OPERAVEIS = 'f3base_operaveis';

	/**
	 * Procedências fechadas.
	 */
	public const ORIGEM_IMPLANTADOR = 'implantador';
	public const ORIGEM_MANUAL      = 'edicao-manual';
	public const ORIGEM_ABILITY     = 'ability';
	public const ORIGEM_PADRAO      = 'padrao';
    public const ORIGEM_MIGRACAO = 'migracao';

	/**
	 * As SEÇÕES da tela, por assunto — e a ordem delas é a ordem de instalação.
	 */
	public const SECAO_CONTATO       = 'contato';
	public const SECAO_MEDICAO       = 'medicao';
	public const SECAO_CONSENTIMENTO = 'consentimento';
	public const SECAO_PRIVACIDADE   = 'privacidade';

	/**
	 * Catálogo resolvido (memoizado por requisição).
	 *
	 * @var array<string,array<string,mixed>>|null
	 */
	private static ?array $catalogo = null;

	/** Catálogo montado antes de `after_setup_theme`; provisório, nunca o definitivo (1.49.0). */
	private static ?array $catalogo_antecipado = null;

	/**
	 * As SEÇÕES da tela, na ORDEM em que ela as apresenta.
	 *
	 * POR QUE A ORDEM MORA AQUI. Até a 1.1.3 a tela apresentava as chaves na
	 * ordem do catálogo, que é a ordem em que elas foram escritas — e o
	 * catálogo é ordenado por quem construiu o pacote, não por quem opera o
	 * site. Quem abre esta tela quer resolver UMA coisa, e as coisas têm ordem:
	 * primeiro por onde falam com você, depois o que você mede, depois o que o
	 * visitante pode recusar, depois o que o site guarda e por quanto tempo.
	 * A ordem é declarada num lugar só porque ela é conferida: a tela renderiza
	 * daqui e a bancada mede o DOM contra esta mesma lista.
	 *
	 * @return array<string,array{titulo:string,resumo:string}>
	 */
	public static function secoes_da_tela(): array {
		return array(
			self::SECAO_CONTATO       => array(
				'titulo' => __( 'Contato', 'f3base' ),
				'resumo' => __( 'Por onde quem visita o site fala com você. Enquanto o número não estiver preenchido, o botão de contato não é publicado.', 'f3base' ),
			),
			self::SECAO_MEDICAO       => array(
				'titulo' => __( 'Medição e anúncios', 'f3base' ),
				'resumo' => __( 'As contas que recebem o que acontece no site. Cada campo vazio é uma conta que não recebe nada: o site continua funcionando, e aquela conta continua sem resposta.', 'f3base' ),
			),
			self::SECAO_CONSENTIMENTO => array(
				'titulo' => __( 'Consentimento', 'f3base' ),
				'resumo' => __( 'O que o site faz antes de o visitante decidir, e por onde ele muda de ideia depois. Esta escolha é jurídica antes de ser técnica, e ela muda os números de todos os relatórios.', 'f3base' ),
			),
			self::SECAO_PRIVACIDADE   => array(
				'titulo' => __( 'Privacidade e retenção', 'f3base' ),
				'resumo' => __( 'O que o site guarda, por quanto tempo, e o que ele oferece a leitores automáticos. Os prazos são definidos nesta configuração. A página de política de privacidade é opcional e sua ausência não bloqueia o plugin.', 'f3base' ),
			),
		);
	}

	/**
	 * As FOLHAS OPERÁVEIS do catálogo: o que a tela apresenta como campo.
	 *
	 * Uma folha é o que tem valor próprio — a option inteira quando ela não é
	 * grupo, e cada sub-campo declarado quando ela é. É esta lista que o
	 * detector `estatica.campo_operavel_tem_impacto_e_exemplo` cobra, e é ela
	 * que a tela percorre.
	 *
	 * @return array<int,array{option:string,chave:string,rotulo:string,declaracao:array<string,mixed>}>
	 */
	public static function folhas_operaveis(): array {
		$folhas = array();

		foreach ( self::catalogo() as $nome => $declaracao ) {
			if ( ! self::operavel( (string) $nome ) ) {
				continue;
			}

			$subcampos = isset( $declaracao['subcampos'] ) && is_array( $declaracao['subcampos'] )
				? $declaracao['subcampos']
				: array();

			if ( array() === $subcampos ) {
				$folhas[] = array(
					'option'     => (string) $nome,
					'chave'      => '',
					'rotulo'     => (string) $declaracao['rotulo'],
					'declaracao' => $declaracao,
				);
				continue;
			}

			foreach ( $subcampos as $chave => $sub ) {
				if ( ! is_array( $sub ) ) {
					continue;
				}

				$folhas[] = array(
					'option'     => (string) $nome,
					'chave'      => (string) $chave,
					'rotulo'     => isset( $sub['rotulo'] ) ? (string) $sub['rotulo'] : (string) $chave,
					'declaracao' => $sub,
				);
			}
		}

		return $folhas;
	}

	/** Catálogo público; a composição interna permanece na mesma fachada. */
	public static function catalogo(): array {
        if(class_exists('F3Base_Perfil_Publico',false)&&F3Base_Perfil_Publico::ativo()){do_action('f3base_perfil_catalogo');}
		return self::catalogo_interno();
	}

	/**
	 * Nomes das options gerenciadas.
	 *
	 * @return string[]
	 */
    public static function catalogo_ausentes(): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        global $wpdb;
        $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM %i WHERE option_name LIKE %s ORDER BY option_name LIMIT 1001",$wpdb->options,$wpdb->esc_like('f3base_').'%'));
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'catalogo_conferencia_indisponivel');}
        $known=array_fill_keys(self::proprias(),true);$missing=array();
        foreach(array_slice($names,0,1000) as $name){if(!isset($known[$name])){$missing[]=$name;}}
        return array('ok'=>true,'quantidade'=>count($missing),'nomes'=>array_slice($missing,0,10),'parcial'=>count($names)>1000||count($missing)>10);
    }
	public static function nomes(): array {
		return array_keys( self::catalogo() );
	}

	/**
	 * As options que este plugin POSSUI, catálogo mais as duas âncoras.
	 *
	 * `f3base_proveniencia` é interna; `f3base_operaveis` e `f3base_politica_canal` são catalogadas como operavel=false —
	 * elas não são configuração do site, são declarações SOBRE o catálogo: quem
	 * gravou cada chave e quais delas o implantador liberou na tela. Mas as duas
	 * são deste plugin, e o gravador único precisa poder removê-las: sem isso,
	 * `remover()` as recusaria e a desinstalação deixaria duas options órfãs no
	 * banco falando de um plugin que já não existe.
	 *
	 * @return string[]
	 */
	public static function proprias(): array {
		return array_merge(
			self::nomes(),
			array( self::OPTION_PROVENIENCIA, self::OPTION_OPERAVEIS, self::OPTION_TENTATIVAS )
		);
	}

	/**
	 * As options que são ESTADO DE EXECUÇÃO, e não configuração.
	 *
	 * A DISTINÇÃO GOVERNA A PROCEDÊNCIA. Procedência responde "quem escolheu
	 * este valor" — implantador, edição manual ou padrão embutido —, e a
	 * pergunta não faz sentido para um carimbo de cron: ninguém ESCOLHEU que a
	 * última limpeza foi às 3h12. Antes desta lista, todo `F3Base_Atividade::registrar()`
	 * — inclusive o disparado pela rota PÚBLICA do beacon de comportamento —
	 * reescrevia `f3base_proveniencia` inteira, com `autoload = true`,
	 * invalidando `alloptions` uma vez por visitante e carimbando "edição
	 * manual" sobre uma execução automática.
	 *
	 * @return string[]
	 */
	public static function estado_de_execucao(): array {
		$saida = array();

		foreach ( self::catalogo() as $nome => $declaracao ) {
			if ( ! empty( $declaracao['estado_execucao'] ) ) {
				$saida[] = (string) $nome;
			}
		}

		return $saida;
	}

	/**
	 * As options que a DESINSTALAÇÃO leva.
	 *
	 * DECLARADA NO CATÁLOGO, option a option, e não derivada de estado de
	 * execução: o journal de eliminação é estado de execução E fica, porque ele
	 * é a prova do que já foi apagado. As duas âncoras entram aqui pelo mesmo
	 * motivo por que entram em `proprias()`: são estado sobre este plugin, e
	 * nenhuma outra coisa as lê.
	 *
	 * O que NÃO está aqui está aqui por decisão: os registros de lead, o journal
	 * e as options de CONFIGURAÇÃO. Desinstalar plugin não é pedido de
	 * eliminação de dado pessoal, e reinstalar devolve o site ao que ele era.
	 *
	 * @return string[]
	 */
	public static function descartaveis_na_desinstalacao(): array {
		$saida = array();

		foreach ( self::catalogo() as $nome => $declaracao ) {
			if ( ! empty( $declaracao['descartavel'] ) ) {
				$saida[] = (string) $nome;
			}
		}

		$saida[] = self::OPTION_PROVENIENCIA;
		$saida[] = self::OPTION_OPERAVEIS;
		$saida[] = self::OPTION_TENTATIVAS;

		return $saida;
	}

	/**
	 * O TETO DE ENTRADAS declarado de uma option de lista.
	 *
	 * @param string $nome    Nome da option.
	 * @param int    $reserva Teto usado quando o catálogo não declara nenhum.
	 * @return int
	 */
	public static function teto_de_entradas( string $nome, int $reserva ): int {
		$declaracao = self::declaracao( $nome );
		$teto       = isset( $declaracao['teto_de_entradas'] ) ? (int) $declaracao['teto_de_entradas'] : $reserva;

		/**
		 * Permite ao site esticar ou encurtar o teto de uma lista gerenciada.
		 *
		 * @param int    $teto Teto declarado no catálogo.
		 * @param string $nome Nome da option.
		 */
		$teto = (int) apply_filters( 'f3base_teto_de_entradas', $teto, $nome );

		return max( 10, $teto );
	}

	/**
	 * As options que são SEGREDO DO SITE — ÂNCORA declarada.
	 *
	 * O QUE ISTO DECLARA, e por que uma lista é melhor que um comentário. O
	 * `config/site.json` viaja dentro do zip: ele é lido pela suíte, entra no
	 * bundle e chega inteiro a quem faz o upload. Um segredo declarado ali é um
	 * segredo copiado para todo lugar por onde o pacote passa — e a cópia
	 * sobrevive a qualquer rotação da credencial, porque ninguém volta ao zip
	 * para apagá-la.
	 *
	 * As options desta lista, portanto, têm duas invariantes que valem para
	 * TODAS elas e que um detector cobra a cada rodada
	 * (`estatica.segredo_fora_da_configuracao`):
	 *
	 * 1. o nome NÃO aparece no arquivo único nem no schema — a ausência é a
	 *    declaração, e é ela que o detector mede;
	 * 2. NENHUM lote do implantador as grava — quem as grava é o agente, pelo
	 *    canal, ou o próprio site-core quando o segredo é gerado aqui dentro.
	 *
	 * `f3base_endpoint_segredo` está aqui pelo mesmo motivo, embora nasça dentro
	 * deste plugin: ele nunca deve poder ser declarado de fora.
	 *
	 * @return string[]
	 */
	public static function segredos_do_site(): array {
		return array_merge(F3Base_Segredos::NOMES,array('f3base_endpoint_segredo'));
	}

	/**
	 * O MARCADOR que substitui um segredo em toda saída.
	 *
	 * DUAS RESPOSTAS, e nenhuma delas é o valor: existe ou não existe. Nem o
	 * valor, nem um prefixo dele, nem o tamanho — comprimento de credencial é
	 * informação sobre a credencial, e quem procura por uma sabe o que fazer com
	 * ele. O que quem opera o site precisa saber é se há algo gravado ali, e é
	 * isso que esta frase responde.
	 *
	 * @param mixed $valor Valor lido.
	 * @return string
	 */
	public static function marcador_de_segredo( $valor ): string {
		$tem = is_scalar( $valor ) && '' !== trim( (string) $valor );

		return $tem
			? __( 'Há um valor gravado neste campo. Ele nunca é exibido de volta — nem aqui, nem no relatório.', 'f3base' )
			: __( 'Nenhum valor gravado neste campo.', 'f3base' );
	}

	/**
	 * A option é um SEGREDO do site?
	 *
	 * @param string $nome Nome da option.
	 * @return bool
	 */
	public static function e_segredo( string $nome ): bool {
		$declaracao = self::declaracao( $nome );

		return null !== $declaracao
			&& isset( $declaracao['campo'] )
			&& 'segredo' === (string) $declaracao['campo'];
	}

	/**
	 * Declaração de uma option do catálogo.
	 *
	 * @param string $nome Nome da option.
	 * @return array<string,mixed>|null Declaração, ou null quando não gerenciada.
	 */
	public static function declaracao( string $nome ): ?array {
		$catalogo = self::catalogo();

		return isset( $catalogo[ $nome ] ) ? $catalogo[ $nome ] : null;
	}

	/**
	 * Uma option é operável pelo operador na tela?
	 *
	 * A declaração do catálogo é o teto; `f3base_operaveis`, quando presente,
	 * restringe — o implantador pode fechar o que não quer aberto, nunca abrir
	 * o que o catálogo declarou estrutural.
	 *
	 * @param string $nome Nome da option.
	 * @return bool
	 */
	public static function operavel( string $nome ): bool {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao || empty( $declaracao['operavel'] ) ) {
			return false;
		}

		return F3Base_Politica::permite($nome);
	}

	/**
	 * Lê uma option gerenciada já normalizada pelo sanitizador declarado.
	 *
	 * Ler pelo sanitizador garante forma: chave ausente ou valor corrompido não
	 * vira notice no consumidor.
	 *
	 * @param string $nome Nome da option.
	 * @return mixed Valor normalizado.
	 */
	public static function ler( string $nome ) {
        if(self::$validando&&array_key_exists($nome,self::$proposta)){return self::$proposta[$nome];}
        if(class_exists('F3Base_Perfil_Publico',false)&&F3Base_Perfil_Publico::ativo()){$found=false;$value=F3Base_Perfil_Publico::ler($nome,$found);if($found){return $value;}do_action('f3base_perfil_option_ausente',$nome);}
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return null;
		}

		$bruto = get_option( $nome, null );
		if ( null === $bruto ) {
			return $declaracao['padrao'];
		}

		return self::sanitizar( $nome, $bruto );
	}

	/**
	 * A option existe no banco?
	 *
	 * @param string $nome Nome da option.
	 * @return bool
	 */
	public static function existe( string $nome ): bool {
		return null !== get_option( $nome, null );
	}

	/**
	 * Sanitiza um valor com o sanitizador declarado da option.
	 *
	 * @param string $nome  Nome da option.
	 * @param mixed  $valor Valor bruto.
	 * @return mixed Valor normalizado.
	 */
	public static function sanitizar( string $nome, $valor ) {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return null;
		}

        if(F3Base_Segredos::gerenciado($nome)&&is_string($valor)&&str_starts_with($valor,F3Base_Segredos::PREFIXO)){return $valor;}
		$valor=F3Base_Retencao_Prazos::converter($nome,$valor);
		$sanitizador = isset( $declaracao['sanitiza'] ) ? $declaracao['sanitiza'] : null;
		if ( ! is_callable( $sanitizador ) ) {
			return $declaracao['padrao'];
		}

		return call_user_func( $sanitizador, $valor, $declaracao['padrao'] );
	}

	/**
	 * Grava uma option gerenciada e devolve a leitura de volta.
	 *
	 * @param string $nome   Nome da option.
	 * @param mixed  $valor  Valor bruto (será sanitizado).
	 * @param string $origem Procedência da escrita.
	 * @return array Resultado com persistência, efeito e verificação separados; ok mantém a semântica anterior.
	 */
	public static function gravar( string $nome, $valor, string $origem = self::ORIGEM_MANUAL, ?string $revisao_esperada = null, ?array $delta = null ): array {
        $avisos=F3Base_Segredos::gerenciado($nome)&&is_string($valor)?F3Base_Credenciais::avisos_formato($nome,$valor):array();
        $fn=static function()use($nome,$valor,$origem,$revisao_esperada,$delta,$avisos){F3Base_Credenciais::normalizacao_escrita($nome,$avisos);try{return self::gravar_interno($nome,$valor,$origem,$revisao_esperada,$delta);}finally{F3Base_Credenciais::normalizacao_escrita($nome,array());}};
        $r=F3Base_Pipedrive_Trava::protegida($nome)?F3Base_Pipedrive_Trava::executar($fn):$fn();
        $r=is_array($r)?$r:self::resultado_gravacao(false,null,'Outra operação Pipedrive está em andamento; releia antes de tentar.','pipedrive_ocupado');
        if($avisos){$r['avisos']=array_values(array_unique(array_merge($r['avisos']??array(),$avisos),SORT_REGULAR));$r['motivo']=trim(($r['motivo']??'').' '.implode(' ',array_column($avisos,'motivo')));}return $r;
    }
    private static function gravar_interno( string $nome, $valor, string $origem, ?string $revisao_esperada, ?array $delta ): array {
        if(in_array($nome,[F3Base_Meta_Monitoramento::OPTION,F3Base_Google_Acervo::OPTION,'f3base_gsc_consultas'],true)){$revisao_esperada=$revisao_esperada??self::revisao($nome);}
        if($nome===F3Base_Meta_Ads::OPTION){$revisao_esperada=$revisao_esperada??self::revisao($nome);}
        if($revisao_esperada!==null&&!hash_equals($revisao_esperada,self::revisao($nome))){return self::resultado_gravacao(false,null,'A configuração mudou; leia novamente antes de aplicar.','conflito');}
        if(F3Base_Segredos::gerenciado($nome)&&is_string($valor)){$seguro=F3Base_Segredos::recusar($nome,$valor);if($seguro!==''){return self::resultado_gravacao(false,null,$seguro,'valor_recusado');}$valor=trim($valor);$revisao_esperada=$revisao_esperada??self::revisao($nome);}
		$anterior_cache = self::ler( $nome );
		$declaracao     = self::declaracao( $nome );
		if ( null === $declaracao ) {
			self::registrar_tentativa_recusada( $nome, $origem, 'option_nao_gerenciada' );
			return self::resultado_gravacao(
				false,
				null,
				sprintf(
					/* translators: %s: nome da option. */
					__( 'Option %s não é gerenciada pelo site-core: escrita recusada.', 'f3base' ),
					$nome
				),
				'option_nao_gerenciada'
			);
		}

		/*
		 * A RECUSA VEM ANTES DA SANITIZAÇÃO, e é a diferença entre devolver a
		 * decisão a quem a tomou e decidir por ele. O valor recusado NÃO é
		 * reescrito nem gravado: o que estava no banco continua lá, e o motivo
		 * diz qual valor foi recusado e por quê. Só declara recusa a option cujo
		 * valor fora da faixa significaria o OPOSTO do que foi pedido — o caso
		 * medido é `f3base_retencao_meses = 0`, em que quem queria desligar a
		 * limpeza obtinha o prazo mais curto possível.
		 */
		if (null !== $delta && ('grupo' !== ($declaracao['campo'] ?? '') || !is_array($valor) || null === $revisao_esperada)) { return self::resultado_gravacao(false,null,'Mescla exige grupo e revisão.','mescla_nao_aplicavel'); }
        $avaliado = null === $delta ? $valor : F3Base_Config_Mescla::escopo($nome,$valor,$delta,$declaracao);
        $recusa = self::recusar( $nome, $avaliado, $declaracao );

		if ( '' !== $recusa ) {
			self::registrar_tentativa_recusada( $nome, $origem, 'valor_recusado' );
			$resultado = self::resultado_gravacao( false, self::ler( $nome ), $recusa, 'valor_recusado' );
			if ( 'f3base_seo_entidade' === $nome ) {
				$resultado['validacao'] = F3Base_Seo_Entidade::validar( $valor ); }
			return $resultado;
		}

        if(F3Base_Segredos::gerenciado($nome)&&is_string($valor)){
            $f=self::fotografia_bruta($nome);
            if(!$f['erro']&&$f['existe']&&hash_equals($revisao_esperada??'',$f['revisao'])&&hash_equals(F3Base_Segredos::abrir($nome,is_string($f['valor'])?$f['valor']:''),$valor)){
                return self::resultado_gravacao(true,$f['valor'],'Credencial mantida.','credencial_inalterada',array('status'=>'not_required','applied'=>false,'codigo'=>'credencial_inalterada','motivo'=>''))+array('revisao'=>$f['revisao']);
            }
        }
		$normalizado = self::sanitizar( $nome, $valor );

		/*
		 * OS AJUSTES DE ESCRITA ACONTECEM AQUI, e só aqui.
		 *
		 * A DIVISÃO É A REGRA DESTA CLASSE: o SANITIZADOR governa a leitura, e
		 * leitura que descarta apaga em silêncio o que alguém gravou; a ESCRITA
		 * é onde um valor novo pode ser recusado, porque ali existe alguém para
		 * receber o motivo. É esta divisão que faz o par de redirect que gira
		 * continuar legível na tela do site que já o tem, e não entrar no site
		 * que ainda não o tem.
		 */
		$ajuste      = self::ajustar_na_escrita( $nome, $normalizado, $declaracao );
		$normalizado = $ajuste['valor'];
        if (null !== $delta) { $normalizado=F3Base_Config_Mescla::preservar($valor,$normalizado,$delta,F3Base_Config_Contrato::schema_entrada($declaracao)); }
        if($nome===F3Base_Meta_Monitoramento::OPTION){$normalizado=F3Base_Meta_Monitoramento::preparar($normalizado);}
        if($nome===F3Base_Meta_Ads::OPTION){$normalizado=F3Base_Meta_Ads::preparar_escrita($normalizado);}
		$autoload    = array_key_exists( 'autoload', $declaracao ) ? (bool) $declaracao['autoload'] : true;
        if(F3Base_Segredos::gerenciado($nome)){
            if(!is_string($valor)||str_starts_with($valor,F3Base_Segredos::PREFIXO)){return self::resultado_gravacao(false,null,'Informe uma credencial nova, sem envelope cifrado.','segredo_entrada_invalida');}
            try{$normalizado=F3Base_Segredos::cifrar($nome,(string)$normalizado);if($valor!==''&&!hash_equals(trim($valor),F3Base_Segredos::abrir($nome,$normalizado))){throw new RuntimeException('cifra_nao_confirmada');}}catch(Throwable $e){return self::resultado_gravacao(false,null,'Cifra indisponível; a credencial anterior foi preservada.','cifra_indisponivel');}
            $autoload=false;
        }

		self::$escritas_em_curso[ $nome ] = ( self::$escritas_em_curso[ $nome ] ?? 0 ) + 1;
		try {
			if ( null === $revisao_esperada ) {
				self::escrever( $nome, $normalizado, $autoload );
			} elseif ( ! self::escrever_condicional( $nome, $normalizado, $autoload, $revisao_esperada ) ) {
				self::registrar_tentativa_recusada( $nome, $origem, 'conflito_ou_falha_de_escrita' );
				return self::resultado_gravacao( false, self::ler( $nome ), 'A configuração mudou desde a leitura ou o banco recusou a escrita. Leia novamente antes de reaplicar.', 'conflito_ou_falha_de_escrita' );
			}
		} finally {
			--self::$escritas_em_curso[ $nome ]; }

		$lido            = self::ler( $nome );
		$foto_confirmada = self::fotografia( $nome );

        $bruta_confirmada = null !== $delta ? self::fotografia_bruta($nome) : null;
		$conferiu = null !== $delta ? (!$bruta_confirmada['erro'] && $bruta_confirmada['existe'] && self::equivalente($normalizado,$bruta_confirmada['valor'])) : (self::existe($nome) && self::equivalente($normalizado,$lido));
		if ( null !== $foto_confirmada ) {
			$conferiu = $conferiu && ! $foto_confirmada['erro'] && $foto_confirmada['existe'] && self::equivalente( null !== $delta ? self::sanitizar($nome,$normalizado) : $normalizado, $foto_confirmada['valor'] );
		}
		$motivo = '';

		if ( ! $conferiu ) {
			self::registrar_tentativa_recusada( $nome, $origem, 'persistencia_divergente' );
			$motivo = sprintf(
				/* translators: %s: nome da option. */
				__( 'Leitura de volta divergiu do valor gravado em %s.', 'f3base' ),
				$nome
			);
		} else {
			$frases = $ajuste['avisos'];
			$aviso  = self::aviso_de_normalizacao( $nome, $valor, $lido );

			if ( '' !== $aviso ) {
				$frases[] = $aviso;
			}

			$motivo = implode( ' ', $frases );
		}

		/*
		 * PROCEDÊNCIA SÓ PARA CONFIGURAÇÃO. Carimbo de execução não tem
		 * procedência: ninguém ESCOLHEU que a última limpeza foi às 3h12, e
		 * gravá-la como "edição manual" era uma resposta falsa a uma pergunta
		 * que não se aplica. O efeito medido era pior que a mentira: cada
		 * `F3Base_Atividade::registrar()` — inclusive o disparado pela rota
		 * PÚBLICA do beacon — reescrevia a option de procedência inteira, uma
		 * vez por visitante.
		 */
		$auditoria = array(
			'status'    => 'not_required',
			'persisted' => null,
			'codigo'    => 'estado_interno',
		);
		if ( $conferiu && self::OPTION_PROVENIENCIA !== $nome && ! in_array( $nome, self::estado_de_execucao(), true ) ) {
				$auditoria = self::registrar_proveniencia( $nome, $origem, $foto_confirmada['revisao'], $foto_confirmada['valor'] );
		}

		if ( ! $conferiu ) {
			return self::resultado_gravacao( false, $lido, $motivo, 'persistencia_divergente' ); }
		// Uma falha posterior nunca transforma uma gravação confirmada em gravação recusada.
		$efeito = self::executar_efeito( $nome, $lido, $declaracao );
		if ( class_exists( 'F3Base_Cache_Pagina' ) && ! self::equivalente( $anterior_cache, $lido ) ) {
			if ( F3Base_Cache_Pagina::afeta( $nome ) ) {
				F3Base_Modulo_Cache_Publico::invalidar(); }
			$cache = F3Base_Cache_Pagina::apos_escrita( $nome );
			if ( null !== $cache && 'failed' !== $efeito['status'] ) {
				$efeito = $cache; }
		}

		$motivo      = trim( $motivo . ' ' . $efeito['motivo'] );
		$verificacao = self::verificar_configuracao( $nome, $lido );
		if ( null !== $foto_confirmada && ! hash_equals( $foto_confirmada['revisao'], self::revisao( $nome ) ) ) {
			$verificacao = self::resultado_verificacao( 'pending', 'runtime', 'configuracao_mudou', 'A gravação foi confirmada, mas a preferência mudou durante o efeito. Consulte o valor atual antes de verificar seu comportamento.' );
		}
		$r          = self::resultado_gravacao( true, $lido, $motivo, $efeito['codigo'], $efeito, $verificacao );
		$r['audit'] = $auditoria;
		// A revisão devolvida pertence ao valor confirmado, mesmo se outro escritor atuar durante o efeito.
		if ( null !== $foto_confirmada ) {
			$r['revisao'] = $foto_confirmada['revisao']; }
        return F3Base_Segredos::gerenciado($nome)?F3Base_Credenciais::completar_resultado($nome,$r):$r;
	}

	/** Resultado uniforme para PHP, painel e MCP. Uma simulação sobrepõe somente ok e simulado. */
	public static function resultado_gravacao( bool $persisted, $lido, string $motivo = '', string $codigo = '', array $effect = array(), array $verification = array() ): array {
		$effect       = $effect ? $effect : array(
			'status'  => 'not_attempted',
			'applied' => false,
			'codigo'  => 'nao_executado',
			'motivo'  => 'Efeito não executado.',
		);
		$verification = $verification ? $verification : self::resultado_verificacao( 'not_attempted', 'none', 'nao_executada', 'A operação não chegou à verificação.' );
		return array(
			'efeito_ate'   => gmdate('c',time()+3600),
            'efeitos_imediatos'=>array('captura','consentimento','cabecalhos_seguranca','redirecionamentos','retirada_conteudo_privado'),
			'ok'           => $persisted && ( in_array( $effect['status'], array( 'applied', 'not_required' ), true ) || ($effect['codigo'] ?? '') === 'cache_agendado' ),
			'persisted'    => $persisted,
			'effect'       => $effect,
			'verification' => $verification,
			'simulado'     => false,
			'lido'         => $lido,
			'motivo'       => $motivo,
			'codigo'       => $codigo,
		);
	}

	/** Vocabulário da verificação. O escopo impede confundir inspeção local com prova pública. */
	public static function resultado_verificacao( string $status, string $scope, string $codigo, string $motivo, int $checked_at = 0 ): array {
		return array(
			'status'     => $status,
			'pending'    => 'pending' === $status,
			'scope'      => $scope,
			'codigo'     => $codigo,
			'motivo'     => $motivo,
			'checked_at' => $checked_at,
		);
	}

	/** Consulta somente leitura. Na ausência de uma prova, não declara comportamento verificado. */
	public static function verificar_configuracao( string $nome, $valor = null ): array {
		return self::verificar_configuracao_interna( $nome, $valor );
	}

	/**
	 * A RECUSA DECLARADA de uma option, quando ela existe.
	 *
	 * @param string              $nome       Nome da option.
	 * @param mixed               $valor      Valor bruto.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @return string Motivo da recusa, ou vazio quando o valor é aceito.
	 */
	public static function recusar( string $nome, $valor, array $declaracao ): string {
        if(F3Base_Segredos::gerenciado($nome)){$e=F3Base_Segredos::recusar($nome,$valor);if($e!==''){return $e;}if(is_string($valor)){$valor=trim($valor);}}
        if(F3Base_Segredos::gerenciado($nome)&&is_string($valor)){$check=F3Base_Credenciais::verificar($nome,$valor);if(empty($check['ok'])){return $check['motivo']??'Credencial não verificada.';}}
		$regra = isset( $declaracao['recusa'] ) ? $declaracao['recusa'] : null;

		if ( ! is_callable( $regra ) ) {
			return '';
		}

		++self::$validando; try { return (string) call_user_func( $regra, $valor, $declaracao, $nome ); } finally { --self::$validando; }
	}

	/**
	 * O AVISO DE NORMALIZAÇÃO, e ele vale para GRUPO também.
	 *
	 * O DEFEITO MEDIDO: o aviso só saía para valor escalar (`is_scalar( $valor )`),
	 * e treze das options deste catálogo são grupo. Quem gravasse um grupo com um
	 * campo fora da forma — um modo de llms.txt inexistente, um COOP que o
	 * vocabulário não conhece, um prazo acima do teto — recebia `ok: true` e
	 * silêncio, e o campo voltava calado ao padrão. A leitura de volta CONFERIA,
	 * porque ela compara o normalizado com o normalizado; quem discordava era a
	 * ENTRADA, e ninguém a comparava.
	 *
	 * A COMPARAÇÃO É POR CAMPO, e o aviso NOMEIA os campos. "Algo foi
	 * normalizado" não serve a quem precisa descobrir qual dos oito campos do
	 * grupo não entrou como ele escreveu.
	 *
	 * @param string $nome  Nome da option.
	 * @param mixed  $valor Valor bruto, como chegou.
	 * @param mixed  $lido  Valor lido de volta.
	 * @return string Frase pronta, ou vazio quando nada foi normalizado.
	 */
	public static function aviso_de_normalizacao( string $nome, $valor, $lido ): string {
		if ( self::equivalente( $valor, $lido ) ) {
			return '';
		}

		if ( ! is_array( $valor ) || ! is_array( $lido ) ) {
			if ( ! is_scalar( $valor ) && ! is_array( $valor ) ) {
				return '';
			}

			return sprintf(
				/* translators: %s: nome da option. */
				__( 'Valor normalizado pela sanitização de %s antes da gravação.', 'f3base' ),
				$nome
			);
		}

		$campos = array();

		foreach ( $lido as $chave => $depois ) {
			if ( ! array_key_exists( $chave, $valor ) ) {
				continue;
			}

			if ( ! self::equivalente( $valor[ $chave ], $depois ) ) {
				$campos[] = (string) $chave;
			}
		}

		foreach ( $valor as $chave => $antes ) {
			if ( ! array_key_exists( $chave, $lido ) ) {
				$campos[] = (string) $chave;
			}
		}

		$campos = array_values( array_unique( $campos ) );

		if ( array() === $campos ) {
			/* A diferença está na ORDEM ou na profundidade, e não num campo do primeiro nível. */
			return sprintf(
				/* translators: %s: nome da option. */
				__( 'Valor normalizado pela sanitização de %s antes da gravação.', 'f3base' ),
				$nome
			);
		}

		return sprintf(
			/* translators: 1: nome da option, 2: nomes dos campos normalizados, separados por vírgula. */
			__( 'Gravado, e a sanitização de %1$s mudou o que você enviou nestes campos: %2$s. O valor que ficou é o que a tela mostra agora.', 'f3base' ),
			$nome,
			implode( ', ', $campos )
		);
	}

	/**
	 * Remove uma option deste plugin. Ponto único de `delete_option`.
	 *
	 * @param string $nome Nome da option.
	 * @return bool Verdadeiro quando a option deixou de existir.
	 */

	public static function remover( string $nome ): bool {
		return self::remover_persistencia( $nome );
	}

	/**
	 * Procedência conhecida de uma option gerenciada.
	 *
	 * @param string $nome Nome da option.
	 * @return string Uma das constantes de origem.
	 */
	public static function proveniencia( string $nome ): string {
		return self::procedencia( $nome )['origem'];
	}

	/** Origem vinculada à revisão, sem atribuir autoria a registros sem prova. */
	public static function procedencia( string $nome, ?array $foto = null ): array {
		$foto            = $foto ?? self::fotografia( $nome );
		$auditoria_foto  = self::fotografia( self::OPTION_PROVENIENCIA );
		$registro        = $auditoria_foto['valor'];
		$entrada         = is_array( $registro ) ? ( $registro[ $nome ] ?? null ) : null;
		$origem          = is_array( $entrada ) ? ( is_string( $entrada['origem'] ?? null ) ? $entrada['origem'] : '' ) : ( is_string( $entrada ) ? $entrada : '' );
		$permitida       = in_array( $origem, self::origens(), true );
		$confirmada      = ! $auditoria_foto['erro'] && ! $foto['erro'] && $permitida && is_array( $entrada ) && is_string( $entrada['revisao'] ?? null ) && hash_equals( $foto['revisao'], $entrada['revisao'] );
		$estado          = $confirmada ? 'confirmada' : ( null !== $entrada ? 'nao_confirmada' : ( $foto['erro'] || $auditoria_foto['erro'] || $foto['existe'] ? 'desconhecida' : 'padrao_embutido' ) );
		$hash_compativel = null;
		if ( is_array( $entrada ) && empty( $entrada['revisao'] ) && is_string( $entrada['valor_hash'] ?? null ) && preg_match( '/^[a-f0-9]{64}$/D', $entrada['valor_hash'] ) ) {
			$hash_compativel = self::comparar_hash_legado( $nome, $foto['revisao'], $entrada['valor_hash'] ); }
		$evidencia = F3Base_Auditoria::classificar( $foto, $entrada, $auditoria_foto['erro'], self::fotografia( 'f3base_auditoria_pendente' ), $hash_compativel );
		return array(
			'origem'             => $confirmada ? $origem : ( ! $foto['erro'] && ! $auditoria_foto['erro'] && ! $foto['existe'] && null === $entrada ? self::ORIGEM_PADRAO : self::ORIGEM_DESCONHECIDA ),
			'estado'             => $estado,
			'origem_registrada'  => $permitida ? $origem : '',
			'revisao'            => $foto['revisao'],
			'revisao_registrada' => is_array( $entrada ) && is_string( $entrada['revisao'] ?? null ) ? $entrada['revisao'] : '',
			'em'                 => is_array( $entrada ) && is_numeric( $entrada['em'] ?? null ) ? (int) $entrada['em'] : 0,
			'canal'              => is_array( $entrada ) && is_string( $entrada['canal'] ?? null ) ? $entrada['canal'] : 'desconhecido',
			'valor_preenchido'   => ! in_array( $foto['valor'], array( null, '', array() ), true ),
			'historico'          => null === $entrada ? 'desconhecido' : 'ultimo_registro',
			'existe_no_banco'    => $foto['existe'],
            'composicao'=>$confirmada?($entrada['composicao']??($origem===self::ORIGEM_PADRAO?'padrao_integral':'configurado')):($estado==='padrao_embutido'?'padrao_integral':'desconhecido'),
            'complementacoes'=>self::complementacoes($nome),
            'reparo'=>self::complementacoes($nome)['reparo'],
		) + $evidencia;
	}

	/**
	 * Carimbo da última escrita conhecida de uma option.
	 *
	 * @param string $nome Nome da option.
	 * @return int Timestamp UTC, ou 0 quando desconhecido.
	 */
	public static function carimbo( string $nome ): int {
		$registro = get_option( self::OPTION_PROVENIENCIA, array() );

		if ( is_array( $registro ) && isset( $registro[ $nome ] ) && is_array( $registro[ $nome ] ) && isset( $registro[ $nome ]['em'] ) ) {
			return (int) $registro[ $nome ]['em'];
		}

		return 0;
	}

	/**
	 * Rótulo humano de uma procedência.
	 *
	 * @param string $origem Constante de origem.
	 * @return string
	 */
	public static function rotulo_origem( string $origem ): string {
		switch ( $origem ) {
			case self::ORIGEM_IMPLANTADOR:
				return __( 'implantador', 'f3base' );
			case self::ORIGEM_ABILITY:
				return 'Habilidade do Core';
			case self::ORIGEM_MANUAL:
				return __( 'edição manual', 'f3base' );
			case self::ORIGEM_DESCONHECIDA:
				return __( 'procedência não confirmada', 'f3base' );
			default:
				return __( 'padrão registrado ou embutido — consulte a evidência', 'f3base' );
		}
	}

	/** Revisão opaca do valor físico; HMAC impede que a revisão exponha segredos curtos. */
	public static function revisao( string $nome ): string {
        if(class_exists('F3Base_Perfil_Publico',false)&&F3Base_Perfil_Publico::ativo()){$r=F3Base_Perfil_Publico::revisao($nome);if($r!==null){return $r;}}
		return self::revisao_persistida( $nome );
	}
	/** Valor e revisão vêm da mesma linha física, sem corrida com o cache de options. */
    /** Raw snapshot for mutation/diagnostics; callers must mask secrets before returning it. */
    public static function fotografia_bruta(string $nome): array {
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$nome),ARRAY_A);
        return self::decodificar_bruto($nome,$r,!empty($wpdb->last_error));
    }

    /**
     * Fotografias brutas de várias opções em UMA consulta (1.49.0).
     *
     * Mesmo resultado, nome a nome, de `fotografia_bruta()`: leitura direta do
     * banco, sem cache, com a mesma decodificação e a mesma revisão. Serve a
     * leitores que fotografam um conjunto fechado de opções a cada chamada (o
     * contexto de medição relia 23 opções com 23 consultas, duas vezes por
     * leitura). A coluna `option_name` é única e comparada sem caixa nem espaço
     * final pela colação do WordPress; o mapeamento abaixo segue a mesma regra.
     *
     * @param list<string> $nomes
     * @return array<string,array{valor:mixed,revisao:string,existe:bool,erro:bool}>
     */
    public static function fotografias_brutas(array $nomes): array {
        global $wpdb;
        $nomes=array_values(array_unique(array_map('strval',$nomes)));
        if(!$nomes){return array();}
        $rows=$wpdb->get_results($wpdb->prepare('SELECT option_name,option_value FROM %i WHERE option_name IN ('.implode(',',array_fill(0,count($nomes),'%s')).')',$wpdb->options,...$nomes),ARRAY_A);
        $erro=!empty($wpdb->last_error);$porChave=array();
        foreach(is_array($rows)?$rows:array() as $row){$porChave[strtolower(rtrim((string)$row['option_name'],' '))]=array('option_value'=>$row['option_value']);}
        $out=array();
        foreach($nomes as $nome){$out[$nome]=self::decodificar_bruto($nome,$porChave[strtolower(rtrim($nome,' '))]??null,$erro);}
        return $out;
    }

    /** Decodificação comum das fotografias brutas; nunca sanitiza composto inválido. */
    private static function decodificar_bruto(string $nome,?array $r,bool $erro): array {
        $valor=$r?maybe_unserialize($r['option_value']):null;$d=self::declaracao($nome);
        // WordPress stores primitive bools/ints as SQL strings. Decode only the
        // exact physical representations; never sanitize an invalid composite.
        if($r&&is_string($valor)){
            if(is_bool($d['padrao']??null)&&in_array($valor,array('','0','1'),true)){$valor=$valor==='1';}
            elseif(is_int($d['padrao']??null)&&preg_match('/^-?(?:0|[1-9][0-9]*)$/D',$valor)&&filter_var($valor,FILTER_VALIDATE_INT)!==false){$valor=(int)$valor;}
        }
        return array('valor'=>$valor,'revisao'=>self::revisao_do_bruto($nome,$r),'existe'=>null!==$r,'erro'=>$erro);
    }
	public static function fotografia( string $nome ): array {
		return self::fotografia_persistida( $nome );
	}

	/** Fotografias coerentes por linha, obtidas juntas para formulários e relatórios. */
	public static function fotografias( array $nomes ): array {
		return self::fotografias_persistidas( $nomes );
	}

	/**
	 * Registra a procedência de uma escrita de CONFIGURAÇÃO.
	 *
	 * `AUTOLOAD => FALSE`, e o `true` anterior era o defeito mais caro daqui. A
	 * procedência é lida por duas telas do wp-admin e pelo relatório, e por mais
	 * ninguém: nenhuma requisição de visitante a consulta. Com autoload ligado
	 * ela viajava dentro de `alloptions` — o objeto de cache que o núcleo monta
	 * uma vez por requisição —, e, pior, cada `update_option` dela INVALIDAVA
	 * esse cache para o site inteiro. Somado ao carimbo de atividade que a rota
	 * pública do beacon disparava, isso era uma invalidação de `alloptions` por
	 * visitante.
	 *
	 * AS CHAVES DO IMPLANTADOR SÃO PRESERVADAS quando o valor não mudou, e essa
	 * é a segunda metade. O implantador grava aqui campos próprios — `valor_hash`
	 * e `release` —, que são como ele sabe se a chave continua sendo a que ele
	 * escreveu. Reconstruir a entrada com `origem` e `em` apagava os dois a cada
	 * gravação, inclusive nas que não mudaram valor nenhum, e o implantador
	 * passava a tratar como "alterada à mão" uma chave que ele mesmo tinha
	 * escrito. Quando o valor MUDA, os dois saem: aí a marca dele deixou de
	 * valer, e mantê-la seria pior.
	 *
	 * @param string $nome   Nome da option.
	 * @param string $origem Procedência.
	 * @return void
	 */
	private static function registrar_proveniencia( string $nome, string $origem, string $revisao, $valor, string $operacao = 'gravar' ): array {
		if ( ! in_array( $origem, self::origens(), true ) ) {
			$origem = self::ORIGEM_MANUAL; }
		$r          = self::atualizar_estado(
			self::OPTION_PROVENIENCIA,
			static function ( $registro ) use ( $nome, $origem, $revisao, $valor, $operacao ) {
				if ( ! hash_equals( $revisao, self::revisao( $nome ) ) ) {
					throw new RuntimeException( 'revisao_mudou' ); }
				$registro = is_array( $registro ) ? $registro : array();
				$anterior = is_array( $registro[ $nome ] ?? null ) ? $registro[ $nome ] : array();
				$entrada  = array(
					'origem'   => $origem,
					'em'       => time(),
					'revisao'  => $revisao,
					'operacao' => $operacao,
					'canal'    => self::$canal_escrita,
				);
				$hash     = hash( 'sha256', (string) wp_json_encode( self::ordenar_qualquer( $valor ) ) );
				if ( isset( $anterior['valor_hash'] ) && hash_equals( (string) $anterior['valor_hash'], $hash ) ) {
					$entrada += $anterior; }
				// Campos desconhecidos são históricos; não revalidam o hash antigo.
				$entrada          += array_diff_key( $anterior, array_flip( array( 'valor_hash', 'release', 'revisao', 'origem', 'em', 'operacao', 'canal' ) ) );
				unset($entrada['complementacao_id'],$entrada['revisao_configuracao']);
                $entrada['composicao']=$origem===self::ORIGEM_PADRAO?'padrao_integral':'configurado';
                $registro[ $nome ] = $entrada;
				return $registro;
			}
		);
		$confirmada = $r['persisted'] && hash_equals( $revisao, self::revisao( $nome ) );
		if ( ! $confirmada ) {
			self::atualizar_estado(
				'f3base_auditoria_pendente',
				static function ( $estado ) use ( $nome, $revisao ) {
					if ( ! hash_equals( $revisao, self::revisao( $nome ) ) ) {
						return null; }
					$estado          = is_array( $estado ) ? $estado : array();
					$estado[ $nome ] = array(
						'codigo'    => 'auditoria_pendente',
						'revisao'   => $revisao,
						'em'        => time(),
						'resultado' => 'persistencia_confirmada_auditoria_falhou',
					);
					return array_slice( $estado, -100, null, true );
				}
			);
		}
		return array(
			'status'    => $confirmada ? 'recorded' : 'pending',
			'persisted' => $r['persisted'],
			'codigo'    => $confirmada ? 'auditoria_confirmada' : 'auditoria_pendente',
			'revisao'   => $revisao,
		);
	}

	private static string $canal_escrita = 'php';
	/** Identifica apenas o canal conhecido, sem inferir autoria humana. */
	public static function pelo_canal( string $canal, callable $operacao ): array {
		$anterior            = self::$canal_escrita;
		self::$canal_escrita = in_array( $canal, array( 'php', 'ability', 'admin', 'cli' ), true ) ? $canal : 'php';
		try {
			return $operacao();
		} finally {
			self::$canal_escrita = $anterior; }
	}

	/** CAS de estado interno; null recusa sem escrita. Callback puro repete até o limite declarado. */
	/** Vocabulário compartilhado de autoria declarada. */
	public static function origens(): array { return array(self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO, self::ORIGEM_ABILITY, self::ORIGEM_MIGRACAO); }

	public static function atualizar_estado( string $nome, callable $transformar, int $tentativas = self::TENTATIVAS_CAS ): array {
		if(F3Base_Pipedrive_Trava::protegida($nome)){$r=F3Base_Pipedrive_Trava::executar(static fn()=>self::atualizar_estado_condicional($nome,$transformar,$tentativas));return is_array($r)?$r:self::resultado_gravacao(false,null,'Estado Pipedrive ocupado.','pipedrive_ocupado');}
		return self::atualizar_estado_condicional( $nome, $transformar, $tentativas );
	}

	/** Tentativas recusadas não contêm valores nem mensagens livres. */
	public static function registrar_tentativa_recusada( string $nome, string $origem, string $codigo ): array {
		$evento = array(
			'option'  => substr( sanitize_key( $nome ), 0, 128 ),
			'origem'  => in_array( $origem, self::origens(), true ) ? $origem : self::ORIGEM_MANUAL,
			'codigo'  => sanitize_key( $codigo ),
			'em'      => time(),
			'usuario' => function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0,
		);
		return self::atualizar_estado(
			self::OPTION_TENTATIVAS,
			static function ( $registro ) use ( $evento ) {
				$registro   = is_array( $registro ) ? $registro : array();
				$registro[] = $evento;
				return array_slice( $registro, -self::TETO_TENTATIVAS );
			}
		);
	}

	/**
	 * O VALOR GRAVADO AGORA É O MESMO QUE O IMPLANTADOR CARIMBOU?
	 *
	 * A pergunta é respondida pelo `valor_hash` que ELE gravou, com a mesma
	 * conta que ele usa: `sha256` sobre a serialização estável do valor. Sem
	 * `valor_hash` na entrada anterior não há o que preservar, e a resposta é
	 * não — a preservação existe para as chaves dele, e não para inventar
	 * continuidade onde ninguém a declarou.
	 *
	 * @param string              $nome     Nome da option.
	 * @param array<string,mixed> $anterior Entrada anterior de procedência.
	 * @return bool
	 */
	private static function valor_inalterado( string $nome, array $anterior ): bool {
		if ( ! isset( $anterior['valor_hash'] ) || ! is_string( $anterior['valor_hash'] ) || '' === $anterior['valor_hash'] ) {
			return false;
		}

		return hash( 'sha256', (string) wp_json_encode( self::ordenar_qualquer( self::ler( $nome ) ) ) ) === $anterior['valor_hash'];
	}

	/**
	 * Serializa de forma estável qualquer valor, para comparação.
	 *
	 * @param mixed $valor Valor.
	 * @return mixed
	 */
    /** Canonical hash shared by public form revisions and persisted contacts. */
    public static function hash_estavel(array $valor): string {return hash('sha256',(string)wp_json_encode(self::ordenar_qualquer($valor)));}
	private static function ordenar_qualquer( $valor ) {
		return is_array( $valor ) ? self::ordenar( $valor ) : $valor;
	}

	/**
	 * Comparação tolerante a ordem de chaves para a leitura de volta.
	 *
	 * Pública porque a cadência do modo somente-relatório relê as options
	 * gravadas para saber se alguma passou a divergir depois da entrega: fossem
	 * duas implementações de equivalência, a releitura poderia acusar
	 * divergência onde a gravação tinha conferido, e vice-versa.
	 *
	 * @param mixed $a Valor gravado.
	 * @param mixed $b Valor lido.
	 * @return bool
	 */
	public static function equivalente( $a, $b ): bool {
		if ( is_array( $a ) && is_array( $b ) ) {
			return wp_json_encode( self::ordenar( $a ) ) === wp_json_encode( self::ordenar( $b ) );
		}

		return $a === $b;
	}

	/**
	 * Ordena arrays associativos recursivamente para comparação estável.
	 *
	 * @param array<mixed> $valor Array de entrada.
	 * @return array<mixed>
	 */
	private static function ordenar( array $valor ): array {
		ksort( $valor );

		foreach ( $valor as $chave => $item ) {
			if ( is_array( $item ) ) {
				$valor[ $chave ] = self::ordenar( $item );
			}
		}

		return $valor;
	}
}
