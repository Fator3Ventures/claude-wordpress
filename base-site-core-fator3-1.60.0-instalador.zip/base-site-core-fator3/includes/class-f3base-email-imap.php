<?php
/** Bounded IMAP4 client: TLS, UIDs, read-only fetch, MOVE and APPEND. No ext-imap. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Email_Imap {
    private $socket;
    private int $sequence=0;
    private float $deadline;
    private ?array $folders=null;
    const MAX_MESSAGE=2097152;
    public function __construct(array $cfg,string $password) {
        $host=(string)$cfg['imap_host'];$port=(int)$cfg['imap_porta'];
        if(!preg_match('/^[a-z0-9.-]+$/iD',$host)||$port!==993||!wp_http_validate_url('https://'.$host.'/')){throw new RuntimeException('imap_destino_invalido');}
        $ips=gethostbynamel($host)?:array();if(!$ips){throw new RuntimeException('imap_dns_indisponivel');}
        foreach($ips as $ip){if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)){throw new RuntimeException('imap_destino_invalido');}}
        $ctx=stream_context_create(array('ssl'=>array('verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>$host,'SNI_enabled'=>true,'allow_self_signed'=>false,'crypto_method'=>STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT|STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT)));
        $this->deadline=microtime(true)+20;
        $this->socket=@stream_socket_client('tls://'.$ips[0].':'.$port,$errno,$error,8,STREAM_CLIENT_CONNECT,$ctx);
        if(!$this->socket){throw new RuntimeException('imap_transporte_indisponivel');}stream_set_timeout($this->socket,8);
        try{if(!preg_match('/^\* OK\b/i',$this->line())){throw new RuntimeException('imap_saudacao_invalida');}$this->command('LOGIN '.self::quote($cfg['usuario']).' '.self::quote($password));}
        catch(Throwable $e){$this->close();throw $e;}
    }
    public function close(): void {if(is_resource($this->socket)){fclose($this->socket);}$this->socket=null;}
    public function __destruct() {$this->close();}
    private static function quote(string $s): string {if(preg_match('/[\x00-\x1f\x7f]/',$s)||strlen($s)>8192){throw new RuntimeException('imap_argumento_invalido');}return '"'.addcslashes($s,'\\"').'"';}
    private function line(): string {
        if(microtime(true)>$this->deadline){throw new RuntimeException('imap_prazo_excedido');}
        $line=fgets($this->socket,65538);if($line===false||!str_ends_with($line,"\r\n")){throw new RuntimeException('imap_resposta_incompleta');}return $line;
    }
    private function write(string $bytes): void {while($bytes!==''){if(microtime(true)>$this->deadline){throw new RuntimeException('imap_prazo_excedido');}$n=fwrite($this->socket,$bytes);if(!$n){throw new RuntimeException('imap_escrita_incompleta');}$bytes=substr($bytes,$n);}}
    private function command(string $command,?string $append=null): array {
        $tag='F'.(++$this->sequence);$this->write($tag.' '.$command."\r\n");$lines=array();$literals=array();$used=0;$sent=false;
        for($i=0;$i<2000;$i++){
            $line=$this->line();$used+=strlen($line);if($used>self::MAX_MESSAGE+131072){throw new RuntimeException('imap_resposta_excedida');}
            if(str_starts_with($line,'+')){if($append===null||$sent){throw new RuntimeException('imap_continuacao_inesperada');}$sent=true;$this->write($append."\r\n");continue;}
            $lines[]=$line;
            if(preg_match('/\{([0-9]+)\}\r\n$/D',$line,$m)){
                $size=(int)$m[1];if($size>self::MAX_MESSAGE||$used+$size>self::MAX_MESSAGE+131072){throw new RuntimeException('imap_mensagem_excedida');}$value='';
                while(strlen($value)<$size){if(microtime(true)>$this->deadline){throw new RuntimeException('imap_prazo_excedido');}$chunk=fread($this->socket,min(65536,$size-strlen($value)));if($chunk===false||$chunk===''){throw new RuntimeException('imap_literal_incompleto');}$value.=$chunk;}$literals[]=$value;$used+=$size;
            }
            if(str_starts_with($line,$tag.' ')){if(!preg_match('/^'.preg_quote($tag,'/').' OK\b/i',$line)){throw new RuntimeException(str_starts_with($command,'LOGIN ')?'imap_autenticacao_recusada':'imap_comando_recusado');}return array('lines'=>$lines,'literals'=>$literals);}
        }throw new RuntimeException('imap_resposta_excedida');
    }
    public function select(string $folder='INBOX',bool $readonly=true): array {
        $r=$this->command(($readonly?'EXAMINE ':'SELECT ').self::quote($folder));$text=implode('',$r['lines']);
        if(!preg_match('/\[UIDVALIDITY ([0-9]+)\]/i',$text,$v)||!preg_match('/\[UIDNEXT ([0-9]+)\]/i',$text,$n)){throw new RuntimeException('imap_identidade_indisponivel');}
        return array('uidvalidity'=>(int)$v[1],'uidnext'=>(int)$n[1]);
    }
    public function search(int $after,int $since=0): array {
        $r=$this->command('UID SEARCH UID '.max(1,$after+1).':*');$ids=array();
        foreach($r['lines'] as $line){if(preg_match('/^\* SEARCH(?: (.*))?\r\n$/D',$line,$m)){foreach(preg_split('/\s+/',trim($m[1]??'')) as $id){if(ctype_digit($id)&&(int)$id>$after){$ids[]=(int)$id;}}}}sort($ids,SORT_NUMERIC);return array_values(array_unique($ids));
    }
    public function fetch(int $uid): array {
        if($uid<1){throw new RuntimeException('imap_uid_invalido');}
        $r=$this->command('UID FETCH '.$uid.' (UID RFC822.SIZE INTERNALDATE)');$text=implode('',$r['lines']);
        if(!preg_match('/\bUID '.preg_quote((string)$uid,'/').'\b/',$text)||!preg_match('/RFC822\.SIZE ([0-9]+)/i',$text,$m)||!preg_match('/INTERNALDATE "([^"]+)"/i',$text,$d)){throw new RuntimeException('imap_mensagem_ausente');}
        $size=(int)$m[1];$date=strtotime($d[1]);if(!$date){throw new RuntimeException('imap_data_invalida');}if($size>self::MAX_MESSAGE){return array('uid'=>$uid,'recebida_em'=>$date,'bytes'=>$size,'excedida'=>true);}
        $r=$this->command('UID FETCH '.$uid.' (UID BODY.PEEK[])');if(count($r['literals'])!==1||strlen($r['literals'][0])!==$size){throw new RuntimeException('imap_corpo_incompleto');}
        return array('uid'=>$uid,'recebida_em'=>$date,'bytes'=>$size,'raw'=>$r['literals'][0]);
    }
    /** Resolve personal namespace, then inspect/create only the explicitly configured destinations. */
    public function pastas(array $configured,bool $create=false): array {
        if($this->folders===null){
            $caps=implode('',$this->command('CAPABILITY')['lines']);$prefix='';$delimiter=null;$namespace=false;
            if(preg_match('/\bNAMESPACE\b/i',$caps)){
                $n=implode('',$this->command('NAMESPACE')['lines']);
                if(preg_match('/^\* NAMESPACE \(\("((?:[^"\\\\]|\\\\.)*)" ("(?:[^"\\\\]|\\\\.)*"|NIL)/mi',$n,$m)){$prefix=self::unquote('"'.$m[1].'"');$delimiter=$m[2]==='NIL'?null:self::unquote($m[2]);$namespace=true;}
            }
            $list=$this->command('LIST "" "*"');$names=array();$literal=0;
            foreach($list['lines'] as $line){
                if(!preg_match('/^\* LIST \(([^)]*)\) (NIL|"(?:[^"\\\\]|\\\\.)*") (.*)\r\n$/Di',$line,$m)){continue;}
                if($delimiter===null&&strtoupper($m[2])!=='NIL'){$delimiter=self::unquote($m[2]);}
                $name=preg_match('/^\{[0-9]+\}$/D',$m[3])?($list['literals'][$literal++]??''):self::unquote($m[3]);
                $names[$name]=!preg_match('/\\\\Noselect\b/i',$m[1]);
            }
            if(!$namespace&&$delimiter){foreach(array_keys($names) as $name){if(str_starts_with($name,'INBOX'.$delimiter)){$prefix='INBOX'.$delimiter;break;}}}
            $this->folders=array('prefixo'=>$prefix,'separador'=>$delimiter,'namespace_confirmado'=>$namespace,'nomes'=>$names);
        }
        $out=array('prefixo'=>$this->folders['prefixo'],'separador'=>$this->folders['separador'],'pastas'=>array());
        foreach($configured as $key=>$name){
            $prefix=$this->folders['prefixo'];$d=$this->folders['separador'];
            $full=$prefix!==''&&!str_starts_with($name,$prefix)&&(!$d||!str_contains($name,$d))?$prefix.$name:$name;
            if(strcasecmp($full,'INBOX')===0){throw new RuntimeException('imap_pasta_invalida');}
            $existed=!empty($this->folders['nomes'][$full]);$created=false;
            if(!$existed&&$create){
                try{$this->command('CREATE '.self::quote($full));$created=true;}catch(RuntimeException $e){if($e->getMessage()!=='imap_comando_recusado'){throw $e;}}
                // Concurrent creation is allowed only if a fresh LIST proves the exact destination.
                $q=$this->command('LIST "" '.self::quote($full));$found=false;
                foreach($q['lines'] as $line){if(preg_match('/^\* LIST \(([^)]*)\) (?:NIL|"(?:[^"\\\\]|\\\\.)*") (.*)\r\n$/Di',$line,$m)&&!preg_match('/\\\\Noselect\b/i',$m[1])&&self::unquote($m[2])===$full){$found=true;}}
                if(!$found){throw new RuntimeException('imap_pasta_ausente');}$this->folders['nomes'][$full]=true;
            }
            $out['pastas'][$key]=array('configurada'=>$name,'efetiva'=>$full,'existia'=>$existed,'criada'=>$created,'disponivel'=>!empty($this->folders['nomes'][$full]));
        }
        return $out;
    }
    private static function unquote(string $value): string {
        return str_starts_with($value,'"')&&str_ends_with($value,'"')?preg_replace('/\\\\(["\\\\])/','$1',substr($value,1,-1)):$value;
    }
    public function exigir_uidplus(): void {
        if(!preg_match('/\bUIDPLUS\b/i',implode('',$this->command('CAPABILITY')['lines']))){throw new RuntimeException('imap_uidplus_indisponivel');}
    }
    public function buscar_message_id(string $mid): array {
        if(!preg_match('/^<f3c-[a-f0-9]{32}@[a-z0-9.-]+>$/D',$mid)){throw new RuntimeException('imap_message_id_invalido');}
        $r=$this->command('UID SEARCH HEADER Message-ID '.self::quote($mid));$ids=array();
        foreach($r['lines'] as $line){if(preg_match('/^\* SEARCH(?: (.*))?\r\n$/D',$line,$m)){foreach(preg_split('/\s+/',trim($m[1]??'')) as $id){if(ctype_digit($id)&&(int)$id>0){$ids[]=(int)$id;}}}}return array_values(array_unique($ids));
    }
    /** RFC 4315 §2.1: never issue mailbox-wide EXPUNGE, even as fallback. */
    public function apagar_uid(int $uid): void {
        if($uid<1){throw new RuntimeException('imap_uid_invalido');}$this->exigir_uidplus();
        $this->command('UID STORE '.$uid.' +FLAGS.SILENT (\\Deleted)');$this->command('UID EXPUNGE '.$uid);
    }
    public function move(int $uid,string $folder): void {
        if($uid<1){throw new RuntimeException('imap_uid_invalido');}$caps=implode('',$this->command('CAPABILITY')['lines']);if(!preg_match('/\bMOVE\b/i',$caps)){throw new RuntimeException('imap_move_indisponivel');}
        $p=$this->pastas(array('destino'=>$folder),true);$this->command('UID MOVE '.$uid.' '.self::quote($p['pastas']['destino']['efetiva']));
    }
    public function append(string $folder,string $mime): void {
        if(strlen($mime)>self::MAX_MESSAGE){throw new RuntimeException('imap_mensagem_excedida');}
        $p=$this->pastas(array('destino'=>$folder),true);
        $this->command('APPEND '.self::quote($p['pastas']['destino']['efetiva']).' (\\Seen) {'.strlen($mime).'}',$mime);
    }
}
