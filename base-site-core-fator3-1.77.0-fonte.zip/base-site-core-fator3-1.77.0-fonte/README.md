# Fator3 Site Core 1.77.0

O runtime instalável está em work/plugin/base-site-core-fator3. A base de migração é a 1.76.0. Os documentos instalados e as notas dos pedidos 386–388 estão em work/plugin/base-site-core-fator3/docs/. A cópia do relatório antecede o fechamento deste fonte.

## Reprodução

Com Python 3, execute a partir da raiz desta árvore, preservando seu nome.

```bash
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.77.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.77.0-fonte.zip
```

Para reproduzir os assets, execute npm ci em build/node. Rode python3 build/assets-1770.py para verificar os 84 JS e o catálogo PHP. Use a opção --output apenas em cópia de trabalho. O Terser do lockfile é 5.44.1. Os testes podem atualizar suas evidências.

## Testes desta rodada

Em um MySQL 8 local descartável, com acesso root local sem senha e porta indicada por F3BASE_LAB_PORT, execute os dois comandos com diretórios novos e o arquivo oficial do WordPress 7.1.4. O PHP CLI precisa de mysqli, mysqlnd, mbstring, sodium e das extensões do WordPress.

```bash
F3BASE_PHASE=fresh python3 tests/run-1770.py --wordpress-archive /caminho/wordpress-7.1.4.zip --lab /tmp/f3-1770-limpo --php /caminho/php
F3BASE_PHASE=upgrade python3 tests/run-1770.py --wordpress-archive /caminho/wordpress-7.1.4.zip --lab /tmp/f3-1770-migracao --php /caminho/php
```

O runner executa 29 verificações novas e 69 de regressão em cada fase. Consulte evidence/1770/ para os recibos e os ensaios de migração.

O roteiro tests/browser-1770.py requer Playwright para Python e Chromium. Os casos editor, native, form, contact e tracking rodam exclusivamente no Site-Teste com página e conta de editor temporárias preparadas pelo administrador. Forneça o recibo privado com --access, o arquivo de evidência com --output e os casos na linha de comando. Para o editor use uma senha provisória definida pela administração de usuários do WordPress. Remova a conta, a página, o arquivo PHP temporário e os contatos sintéticos após o teste. O instalador contém apenas o runtime.
