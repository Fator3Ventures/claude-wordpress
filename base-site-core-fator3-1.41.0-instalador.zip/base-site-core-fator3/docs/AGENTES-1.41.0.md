# Operação e recuperação — Core 1.41.0

Leia RELEASE-1.41.0.md e o catálogo antes de gravar. Configuração e leitura de registros exigem manage_options. A documentação não chama fornecedores.

1. Descobrir `f3base/documentacao-ler`; ler o índice e as páginas até `proxima_linha` nula, conferindo SHA-256 e versão.
2. Consultar `f3base/conversoes-entregas-ler` com record_id. Ler transporte, estado, código e destino_ref. Não enviar novamente um resultado incerto.
3. Se há `destino_alterado`, restaurar a configuração correta ou manter bloqueado. Não editar o banco para substituir a referência.
4. Se o histórico não tem referência, identificar o destino por evidência operacional. Consultar a capacidade atual do Google e copiar sua destination_ref. Confirmar que o contato não foi entregue.
5. Simular `f3base/conversoes-recuperar`, com `confirmar:false`, `nao_entregues_confirmados:["google_ads"]` e `vincular_destinos:{"google_ads":"referencia-exata-obtida-da-capacidade"}`. O valor do exemplo é apenas ilustrativo e deve ser substituído. A simulação não grava.
6. Conferir o resultado e repetir com `confirmar:true`. O vínculo só é aceito se a capacidade estiver pronta e a referência coincidir. O registro recebe usuário e horário da vinculação. Prazo, consentimento e transporte continuam obrigatórios.
7. Ler novamente a entrega. A operação agenda o worker; não comprova recepção externa. Para GA4 sem evidência temporal histórica, a vinculação do destino não cria uma sessão.

A extensão Google `sendBound` deve ser incorporada antes de habilitar servidor em novos sites. Não utilizar a pasta da dependência como instalador Google publicado. Não substituir o Google 0.14 com bytes alterados mantendo a mesma versão pública.
