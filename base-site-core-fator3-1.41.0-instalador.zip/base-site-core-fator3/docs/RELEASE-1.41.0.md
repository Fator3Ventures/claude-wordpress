# Fator3 Site Core 1.41.0

Atualização direta da 1.40.0 e instalação limpa. Contrato administrativo 8.6.0, aditivo: recuperação aceita vinculação explícita de destino. Identidades de plugin, options, tabelas e abilities preservadas.

## Conversões de contato

A escolha navegador/servidor e a referência opaca do destino são gravadas com o contato aceito. Reconciliação da fila usa esse snapshot. Uma troca posterior de conta ou ação não redireciona contatos antigos. Referência indisponível bloqueia somente a entrega servidor; o contato permanece salvo.

O método opcional `sendBound(array $payload, string $destinationRef)` é a extensão PHP negociada por presença do método, sobre `site-conversion-delivery/1.0.0`. O Core 1.41 exige esse método para ativar/despachar servidor. O método `send()` antigo permanece no adaptador Google para consumidores antigos. A dependência entregue modifica somente `ConversionDelivery.php` do Google 0.14.0, sem publicar outra versão Google. Até sua incorporação pelo mantenedor, Google 0.14.0 publicado produz `destination_binding_unsupported`; navegador permanece disponível. A configuração servidor existente não é silenciosamente convertida em navegador.

A dependência confere o destino sob o lock de configuração/envio e no guard de execução antes das chamadas. Envio recusado exige prova de não entrega para ser tentado novamente. Entrega e resultado incerto não são reenviados automaticamente.

## Diagnóstico

Estado (`bloqueado`, `recusado`, `entregue`, `incerto` etc.) e código de motivo permanecem separados. Motivos simbólicos seguros do adaptador são conservados. Respostas brutas e segredos não são gravados no diário.

| Código | Ação |
|---|---|
| destino_historico_ausente | Conferir o registro e vincular explicitamente o destino somente com confirmação de não entrega. |
| destino_alterado / destination_mismatch | Rever qual conta/ação pertence ao contato; não trocar a identidade da fila para forçar envio. |
| destination_binding_unsupported | Incorporar a dependência Google entregue ou usar navegador somente para novos contatos. |
| verification_required / grant_revoked | Rever a verificação ou autorização no Google. |
| ga4_prevalidation_failed | Rever identidade e parâmetros; a prevalidação impediu a coleta. |
| ga4_sessao_sem_evidencia | Não há evidência temporal suficiente; não inventar dados históricos. |
| ga4_sessao_tempo_invalido | Há inconsistência entre identificação e horários observados/recebidos. |
| ga4_sessao_expirada | A janela de atribuição de 24 horas terminou; não retimar nem reenviar pelo navegador. |

GA4 entregue comprova recepção HTTP, não processamento ou atribuição analítica. Ads conserva a confirmação individual do adaptador.

## Sessão GA4

A captura consulta `gtag('get', measurement_id, ...)` para client_id/session_id e confere os valores contra os cookies da mesma submissão. Somente o ID nativo coerente com timestamp desde 2020 e janela de 24 horas recebe procedência `google_tag_native`. O timestamp do ID nativo é documentado pelo Google; IDs históricos/opacos não são convertidos implicitamente. Cookies ausentes, formatos desconhecidos, tag indisponível, discordância e consentimento negado não recebem evidência.

A leitura local da tag espera no máximo 500 ms; não carrega um novo script nem envia uma conversão. A evidência fica na carga da submissão e não é renovada em repetição incerta. O servidor valida início <= observação, coerência do ID e desvio máximo de 30 segundos entre observação, recepção e aceite. A cada tentativa aplica início + 24 horas, além do limite de coleta. Não se inventa engagement_time_msec.

Limites: os dados do navegador são evidência validada, não atestação criptográfica do Google. A fonte pressupõe IDs nativos da tag; configuração customizada do identificador não é suportada. A observação da tag no envio não comprova por si só o horário final da sessão nem a atribuição no fornecedor. A homologação analítica de sessão original permanece necessária; não há garantia de associação para todos os cenários de inatividade, extensão de sessão ou relógio do visitante.

Referências oficiais:
- https://support.google.com/analytics/answer/9191807?hl=en
- https://developers.google.com/tag-platform/gtagjs/reference
- https://developers.google.com/analytics/devguides/collection/protocol/ga4/use-cases

## Configurações e ajuda

Treze descrições de páginas e 47 entradas de rótulo/descrição foram revisadas. A ajuda elimina frases genéricas e exemplos idênticos à descrição. Preservam-se explicações específicas já úteis, padrões, validações e dados configurados. O transporte GA4/Ads aparece em Tags e carregamento. O catálogo e a documentação são gerados do texto efetivamente usado pelo painel.

A revisão editorial não implementa as mudanças funcionais dos pedidos 238–241: histórico comercial Pipedrive, nova tela de e-mail automático, remoção de promessa no e-mail e migração dos identificadores/configuração independente continuam pendentes. O rótulo visível do grupo de e-mail foi melhorado; nomes técnicos legados permanecem nesta versão.

## Migração e reversão

Nenhuma tabela é removida ou renomeada. Referências existentes, configurações e estados são preservados. Filas antigas sem referência ficam bloqueadas; a configuração atual não prova seu destino histórico. O vínculo administrativo usa lock compartilhado com o worker, transação e comparação do snapshot anterior, registrando usuário/data/confirmação no contato.

Antes de voltar à 1.40, suspender o worker e preservar backup de registros/configuração/diário. Voltar arquivos reintroduz as lacunas anteriores e não desfaz envios externos.
