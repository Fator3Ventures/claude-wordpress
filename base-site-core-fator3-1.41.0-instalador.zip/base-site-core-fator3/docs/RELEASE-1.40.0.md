# Core 1.40.0 — transporte de conversão e C0

Pedidos 236 e 237. Atualização direta da 1.39 ou 1.38; navegador é o padrão para novos contatos em ambos os destinos. Meta e materiais conservam seu comportamento.

## Conversões de contato

`f3base_conversoes_transporte` é objeto fechado: `{"ga4":"navegador","google_ads":"navegador"}`. Cada valor aceita navegador/servidor. Escreva pelo painel ou `f3base/config-core-escrever`, com revisão/CAS. Servidor exige adaptador pronto, contrato `site-conversion-delivery/1.0.0` e identidade de destino. Nenhum HTTP ocorre ao validar a configuração. Ausência posterior pausa a fila, sem fallback.

A decisão é persistida junto ao registro e devolvida no POST. O script usa essa resposta, inclusive em páginas antigas em cache. Recuperação não transfere registros de transporte. Registros marcados pela 1.39 continuam servidor; históricos sem prova não são automaticamente recuperados. IDs de clique ambíguos bloqueiam Ads.

`f3base/conversoes-contexto-ler` aceita `contract: site-conversion-purposes/1.1.0` para incluir `transport` por destino de contato, com selected/effective/ready/reason. A resposta 1.0.0 mantém seu schema. `f3base/conversoes-entregas-ler` mostra a escolha do registro. Ambas exigem administração. A leitura não consulta Google.

GA4 entregue significa recepção HTTP, não inclusão nos relatórios. O adaptador Google valida o payload antes do envio e limita associação à sessão original a 24h desde session_id. Não fabrica client_id/session_id. HTTP incerto não é reenviado. Ads exige um único clique e resultado individual. Não foi introduzido Data Manager nem contrato assíncrono.

## C0

Configure `f3base_c0`: ativo (false por padrão), marca (Korvena/CTO Office), cota_destinatarios_hora (0 por padrão), alocacao_confirmada, textos_servicos (mapa 89–96,148,149) e homologacao_emails (caixas controladas explicitamente autorizadas). A senha fica somente em `f3base_c0_smtp_senha`, pelo campo de segredo cifrado/mascarado. SMTP fixo smtp.dreamhost.com:587 com STARTTLS, autenticação e validação de certificado. Remetente/Cco korvena@korvena.net.br; segundo Cco vem do cc_email do lead confirmado.

Ativação exige marca, senha e alocação de pelo menos três destinatários/hora. A soma das cotas dos sites e uso manual precisa caber no teto de 100 destinatários/hora da caixa compartilhada. O contador local não verifica a soma da frota; não ative sem essa alocação. Cada tentativa reserva todos os destinatários, incluindo Cco, em janela móvel de uma hora.

Somente contatos aceitos durante ativação geram intenção; somente lead novo confirmado pelo Pipedrive gera C0. Testes, e-mail inválido, lead reutilizado, negócio e reenvio são excluídos. `c0-homologar`, com record_id e confirmar=true, permite uma única intenção de teste por uma hora para caixa na allowlist, após comprovação de lead novo. Não reabre intenção existente nem libera outros testes. Há registro do administrador e expiração no snapshot cifrado.

A mensagem HTML/texto segue a copy aprovada de Korvena/CTO Office. Serviço com texto ausente permanece pendente: não inventa texto nem usa indevidamente o texto da unidade. O prazo usa o mesmo plano C1. Se a espera fizer o prazo vencer, mantém pendência `prazo_c1_vencido`; requer revisão operacional da promessa, sem envio automático de prazo falso.

A intenção é cifrada, única por site/conta/lead/C0. Todas as respostas RCPT precisam ser aceitas antes de DATA. Recusa de destinatário cancela o envelope antes do corpo; falha explícita permite nova tentativa; resultado DATA desconhecido fica incerto e não reenvia automaticamente. `f3base/c0-ler` consulta estado sem corpo/credenciais. O cron `f3base_c0_processar` processa até três intenções por passagem.

Depois da aceitação SMTP, registra hora e atividade C0 E-mail concluída. Falha abre atividade com código sanitizado e enfileira aviso no thread Slack existente. Falha ou ambiguidade ao criar atividade não repete o e-mail; consulta marcador antes de nova criação. Sem thread Slack configurado, o aviso permanece pendente. Eliminação local apaga o snapshot e cancela a intenção.

## Instalação e reversão

Instalar o ZIP Core pelo fluxo nativo WordPress; nenhuma conexão é ativada pela atualização. Google 0.13 permite usar navegador. Para servidor, aplicar a alteração Google entregue separadamente, configurar/verificar os ativos e então mudar o Core. A dependência não inclui o pedido Google 29.

Voltar arquivos para 1.39 é perigoso: aquela versão envia contatos pelo servidor incondicionalmente. Pausar execução antes de reversão e conservar banco/diários. Restaurar arquivos não desfaz conversões, e-mails ou atividades externos. Não apagar filas para reprocessar incertos.

## Limites da prova

Fixtures não comprovam entrega SMTP, Smart Bcc, atribuição GA4, conversão Ads ou WebView Android/Instagram. Essas provas exigem credenciais e ativos autorizados. C0 permanece desativado por padrão. Dados pessoais, senhas e fixtures não fazem parte do instalador.
