<?php
/** C0: durable intent, one SMTP envelope, independent CRM acknowledgement. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_C0 {
    const HOOK='f3base_c0_processar';
    const MAILBOX='korvena@korvena.net.br';
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_c0';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta('CREATE TABLE '.self::tabela()." (
 chave char(64) NOT NULL,
 record_id char(32) NOT NULL,
 conta varchar(191) NOT NULL,
 lead_id char(36) NOT NULL,
 estado varchar(24) NOT NULL DEFAULT 'pendente',
 codigo varchar(80) NOT NULL DEFAULT '',
 payload longtext NOT NULL,
 proxima bigint unsigned NOT NULL,
 enviado_em bigint unsigned NOT NULL DEFAULT 0,
 atualizado_em bigint unsigned NOT NULL,
 atividade_id bigint unsigned NOT NULL DEFAULT 0,
 atividade_estado varchar(24) NOT NULL DEFAULT '',
 slack_estado varchar(24) NOT NULL DEFAULT '',
 PRIMARY KEY  (chave),
 KEY agenda (estado,proxima),
 KEY registro (record_id)
) ENGINE=InnoDB ".$wpdb->get_charset_collate().';');return !$wpdb->last_error;
    }
    public static function catalogo(array $c): array {
        $p=array('ativo'=>false,'marca'=>'','cota_destinatarios_hora'=>0,'alocacao_confirmada'=>false,'textos_servicos'=>array(),'homologacao_emails'=>array());
        $props=array('homologacao_emails'=>array('type'=>'array','maxItems'=>5,'items'=>array('type'=>'string','format'=>'email')),'ativo'=>array('type'=>'boolean'),'marca'=>array('type'=>'string','enum'=>array('','Korvena','CTO Office')),'cota_destinatarios_hora'=>array('type'=>'integer','minimum'=>0,'maximum'=>100),'alocacao_confirmada'=>array('type'=>'boolean'),'textos_servicos'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array('89','90','91','92','93','94','95','96','148','149'),array('type'=>'string','maxLength'=>3000))));
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>$props,'required'=>array_keys($props));
        $c['f3base_c0']=array('rotulo'=>'C0 — e-mail ao novo lead','descricao'=>'SMTP DreamHost, caixa korvena@korvena.net.br. Cota conta destinatários e Cco; a soma das cotas dos sites e uso manual deve caber em 100/hora. Textos de serviço exigem aprovação prévia.','operavel'=>true,'secao'=>'conexoes','campo'=>'grupo','autoload'=>false,'padrao'=>$p,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static function($v){if(!is_array($v)){return 'Informe a configuração C0.';}foreach($v['homologacao_emails']??array() as $email){if(!is_email($email)){return 'Homologação exige endereço válido de caixa controlada.';}}if(!empty($v['ativo'])&&(empty($v['marca'])||empty($v['alocacao_confirmada'])||($v['cota_destinatarios_hora']??0)<3||F3Base_Segredos::abrir('f3base_c0_smtp_senha')==='')){return 'Ativação exige marca, senha SMTP e alocação confirmada de pelo menos três destinatários por hora neste site.';}return '';});
        $c['f3base_c0_cota']=array('rotulo'=>'Cota C0','descricao'=>'Reservas de destinatários na última hora.','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));
        return $c;
    }
    public static function iniciar(): void {
        add_action(self::HOOK,array(__CLASS__,'processar'));
        add_action('init',static function(){if(!wp_next_scheduled(self::HOOK)){wp_schedule_event(time()+90,'hourly',self::HOOK);}},98);
        add_action('f3base_lead_eliminando',static function($id){global $wpdb;$wpdb->update(self::tabela(),array('estado'=>'cancelado','codigo'=>'registro_eliminado','payload'=>''),array('record_id'=>$id));});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('c0-homologar','Autoriza uma única intenção C0 de teste por até uma hora; caixa deve constar na allowlist Fator3',array(__CLASS__,'homologar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'confirmar'=>array('type'=>'boolean')),array('record_id','confirmar'),false);F3Base_Servicos::ability('c0-ler','Estado privado do e-mail C0; sem corpo ou credenciais',array(__CLASS__,'ler'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),array('record_id'));});
    }
    public static function intencao(): array {$c=F3Base_Options::ler('f3base_c0');return array('solicitado'=>!empty($c['ativo']),'revisao'=>F3Base_Options::revisao('f3base_c0'));}
    public static function elegivel(array $lead,array $job): bool {
        $o=$job['journal']['oportunidade']??array();$company=(string)($lead['dados']['empresa']??'');
        return !empty($lead['dados']['c0_intencao']['solicitado'])&&($lead['captura']??'')==='aceito'&&empty($lead['lixeira'])&&empty($lead['eliminacao_pendente'])&&($lead['classe_trafego']??'')==='nao_marcado'&&empty($lead['dados']['contexto_teste'])&&!preg_match('/^Teste.*\(apagar\)/iu',$company)&&is_email($lead['email']??'')&&($o['tipo']??'')==='lead'&&!empty($o['nova'])&&empty($o['reenvio'])&&!empty($job['journal']['nucleo_confirmado_em']);
    }
    public static function enfileirar(array $lead,array $job,array $ctx,array $plan): bool {
        $company=$ctx['empresa']??'';if(is_array($company)){$company=$company['nome']??'';}if(!self::elegivel($lead,$job)||preg_match('/^Teste.*\(apagar\)/iu',(string)$company)){return true;}$ctx['c0_service_ids']=F3Base_Pipedrive_Comercial::servico($ctx,F3Base_Options::ler('f3base_pipedrive'))['ids'];
        global $wpdb;$key=hash('sha256',get_current_blog_id().'|'.$job['conta'].'|'.$job['journal']['oportunidade']['id'].'|C0');
        $payload=F3Base_Contato_Comunicacao::cifrar(array('ctx'=>$ctx,'plan'=>$plan,'config'=>F3Base_Options::ler('f3base_c0'),'person_id'=>$job['journal']['pessoa']??0));
        $n=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (chave,record_id,conta,lead_id,payload,proxima,atualizado_em) VALUES (%s,%s,%s,%s,%s,%d,%d)',self::tabela(),$key,$lead['record_id'],$job['conta'],$job['journal']['oportunidade']['id'],$payload,time(),time()));
        if($n!==false){F3Base_Fila::agendar(self::HOOK,time()+30);}return $n!==false;
    }
    public static function mensagem(array $ctx,array $cfg,array $plan,int $now): array {
        $brand=$cfg['marca']??'';if(!in_array($brand,array('Korvena','CTO Office'),true)){return array('ok'=>false,'codigo'=>'marca_ausente');}
        if(empty($plan['ok'])||empty($plan['prazo_em'])||$plan['prazo_em']<$now){return array('ok'=>false,'codigo'=>'prazo_c1_vencido');}
        $tz=new DateTimeZone($plan['fuso']);$today=(new DateTimeImmutable('@'.$now))->setTimezone($tz)->format('Y-m-d');$day=(new DateTimeImmutable('@'.$plan['prazo_em']))->setTimezone($tz)->format('Y-m-d');
        $deadline=$today===$day?'ainda hoje':'no próximo dia útil pela manhã';
        $ids=$ctx['c0_service_ids']??F3Base_Pipedrive_Comercial::servico($ctx,F3Base_Options::ler('f3base_pipedrive'))['ids'];$paragraphs=array();
        foreach(array_unique($ids) as $id){$text=trim((string)($cfg['textos_servicos'][(string)$id]??''));if($text===''){return array('ok'=>false,'codigo'=>'texto_servico_pendente');}$paragraphs[]=$text;}
        if(!$ids){$paragraphs[]=$brand==='Korvena'?'A Korvena desenvolve e moderniza sistemas com times seniores, por projeto fechado ou com profissionais alocados no time do cliente.':'A CTO Office organiza a área de tecnologia junto com a empresa: define prioridades, arquitetura, processos e quem executa, sem a necessidade de contratar um CTO em tempo integral.';}
        $signature=$brand==='Korvena'?'Korvena Desenvolvimento de Sistemas':'CTO Office';$first=explode(' ',trim($ctx['nome']??''))[0];if($first===''){return array('ok'=>false,'codigo'=>'nome_ausente');}
        $native=$ctx['origem_nativa']['origem']??'';$origin=$native==='meta'?'no Instagram':($native==='linkedin'?'no LinkedIn':($native==='google'?'no Google':'no nosso site'));
        $link='https://wa.me/5511936203481?text='.rawurlencode('Olá, Anderson. Recebi seu e-mail da '.$brand.'.');$phrase='falar com o Anderson no WhatsApp';
        $parts=array('Olá, '.$first.', tudo bem?','Aqui é o Anderson, da '.$brand.'. Recebi o formulário que você preencheu '.$origin.' e vou te chamar no WhatsApp '.$deadline.' para entender o que você precisa.',implode("\n\n",array_unique($paragraphs)),'Se preferir adiantar, é só me chamar no WhatsApp, no (11) 93620-3481, ou clicar em '.$phrase.'. Também pode responder este e-mail com o melhor dia e horário para conversarmos 20 minutos.',"Anderson Valtriani\n".$signature);
        $html=implode('',array_map(static fn($p)=>'<p>'.nl2br(esc_html($p)).'</p>',$parts));$html=str_replace($phrase,'<a href="'.esc_url($link).'">'.$phrase.'</a>',$html);
        $text=implode("\n\n",$parts);$text=str_replace($phrase,$phrase.' ('.$link.')',$text);
        return array('ok'=>true,'subject'=>$brand.' – Recebemos seu contato','html'=>$html,'text'=>$text,'brand'=>$brand);
    }
    public static function reservar_cota(int $count,int $limit): bool {
        $ok=false;$r=F3Base_Options::atualizar_estado('f3base_c0_cota',static function($s)use($count,$limit,&$ok){$rows=array_values(array_filter($s['reservas']??array(),static fn($x)=>$x['em']>time()-HOUR_IN_SECONDS));if(array_sum(array_column($rows,'n'))+$count>$limit){return null;}$rows[]=array('em'=>time(),'n'=>$count);$ok=true;return array('reservas'=>$rows);});return $ok&&!empty($r['persisted']);
    }
    /** All RCPTs must be accepted before DATA. No recipient receives a partial envelope. */
    public static function smtp(array $message,string $to,string $bcc): array {
        require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/SMTP.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';
        $mail=new \PHPMailer\PHPMailer\PHPMailer(true);$phase='preparar';
        try{
            $mail->isSMTP();$mail->Host='smtp.dreamhost.com';$mail->Port=587;$mail->SMTPSecure='tls';$mail->SMTPAuth=true;$mail->Username=self::MAILBOX;$mail->Password=F3Base_Segredos::abrir('f3base_c0_smtp_senha');$mail->Timeout=10;$mail->SMTPDebug=0;$mail->CharSet='UTF-8';$mail->setFrom(self::MAILBOX,$message['brand']);$mail->addAddress($to);foreach(array_unique(array(self::MAILBOX,$bcc)) as $address){if(strtolower($address)!==strtolower($to)){$mail->addBCC($address);}}$mail->Subject=$message['subject'];$mail->isHTML(true);$mail->Body=$message['html'];$mail->AltBody=$message['text'];
            if(!$mail->preSend()||!$mail->smtpConnect()){return array('estado'=>'pendente','codigo'=>'smtp_conexao_recusada');}
            return self::envelope($mail->getSMTPInstance(),$mail->getSentMIMEMessage(),array_unique(array_map('strtolower',array($to,self::MAILBOX,$bcc))));
        }catch(Throwable $e){return array('estado'=>$phase==='data'?'incerto':'pendente','codigo'=>'smtp_'.$phase.'_falhou');}finally{$mail->smtpClose();}
    }
    public static function envelope(\PHPMailer\PHPMailer\SMTP $smtp,string $mime,array $recipients): array {
        $phase='envelope';try{$smtp->Timelimit=15;
            if(!$smtp->mail(self::MAILBOX)){return array('estado'=>'pendente','codigo'=>'smtp_remetente_recusado');}
            foreach($recipients as $address){if(!$smtp->recipient($address)){$smtp->reset();return array('estado'=>'pendente','codigo'=>'smtp_destinatario_recusado');}}
            $phase='data';if(!$smtp->data($mime)){$code=(int)($smtp->getError()['smtp_code']??0);return array('estado'=>$code>=400&&$code<600?'pendente':'incerto','codigo'=>'smtp_data_sem_aceite');}
            return array('estado'=>'enviado','codigo'=>'smtp_aceito');
        }catch(Throwable $e){return array('estado'=>$phase==='data'?'incerto':'pendente','codigo'=>'smtp_'.$phase.'_falhou');}
    }
    private static function atualizar(array &$row,array $patch): bool {global $wpdb;$patch['atualizado_em']=time();$n=$wpdb->update(self::tabela(),$patch,array('chave'=>$row['chave'],'estado'=>$row['estado'],'atualizado_em'=>$row['atualizado_em']));if($n!==1){$fresh=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$row['chave']),ARRAY_A);if(!$fresh||array_filter($patch,static fn($v,$k)=>(string)($fresh[$k]??'')!==(string)$v,ARRAY_FILTER_USE_BOTH)){return false;}}$row=array_replace($row,$patch);return true;}
    public static function ler(array $e): array {if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;return array('ok'=>true,'linhas'=>$wpdb->get_results($wpdb->prepare('SELECT chave,record_id,estado,codigo,proxima,enviado_em,atividade_id,atividade_estado,slack_estado FROM %i WHERE record_id=%s',self::tabela(),$e['record_id']),ARRAY_A));}
    private static function reconciliar(): void {
        global $wpdb;$jobs=$wpdb->get_results($wpdb->prepare("SELECT q.* FROM %i q JOIN %i l ON l.record_id=q.record_id LEFT JOIN %i c ON c.record_id=l.record_id WHERE c.chave IS NULL AND JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.c0_intencao.solicitado'))='true' AND JSON_EXTRACT(q.journal,'$.nucleo_confirmado_em') IS NOT NULL ORDER BY q.atualizado_em DESC LIMIT 20",F3Base_Pipedrive_Fila::tabela(),F3Base_Leads_Repositorio::tabela(),self::tabela()),ARRAY_A);
        foreach($jobs as $job){$job['journal']=json_decode($job['journal'],true)?:array();$lead=F3Base_Leads_Repositorio::obter($job['record_id']);if($lead&&self::elegivel($lead,$job)){self::enfileirar($lead,$job,F3Base_Pipedrive_Fila::contexto($lead),$job['journal']['atividade_plano']??array());}}
    }
    public static function homologar(array $e): array {
        if(!current_user_can('manage_options')||($e['confirmar']??false)!==true){return array('ok'=>false,'codigo'=>'confirmacao_administrativa_necessaria');}
        global $wpdb;$lead=F3Base_Leads_Repositorio::obter($e['record_id']);$cfg=F3Base_Options::ler('f3base_c0');
        if(!$lead||$lead['classe_trafego']!=='teste'||$lead['lixeira']||$lead['eliminacao_pendente']||!in_array($lead['email'],$cfg['homologacao_emails']??array(),true)){return array('ok'=>false,'codigo'=>'teste_ou_caixa_nao_autorizada');}
        $job=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s ORDER BY atualizado_em DESC LIMIT 1',F3Base_Pipedrive_Fila::tabela(),$lead['record_id']),ARRAY_A);$j=json_decode($job['journal']??'{}',true);$o=$j['oportunidade']??array();
        if(($o['tipo']??'')!=='lead'||empty($o['nova'])||!empty($o['reenvio'])||empty($j['nucleo_confirmado_em'])){return array('ok'=>false,'codigo'=>'novo_lead_nao_confirmado');}
        $ctx=F3Base_Pipedrive_Fila::contexto($lead);$plan=$j['atividade_plano']??array();$key=hash('sha256',get_current_blog_id().'|'.$job['conta'].'|'.$o['id'].'|C0');
        $p=F3Base_Contato_Comunicacao::cifrar(array('ctx'=>$ctx,'plan'=>$plan,'config'=>$cfg,'person_id'=>$j['pessoa'],'homologacao'=>array('email'=>$lead['email'],'expires'=>time()+HOUR_IN_SECONDS,'by'=>get_current_user_id(),'authorized_at'=>time())));
        $n=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (chave,record_id,conta,lead_id,payload,proxima,atualizado_em) VALUES (%s,%s,%s,%s,%s,%d,%d)',self::tabela(),$key,$lead['record_id'],$job['conta'],$o['id'],$p,time(),time()));
        if($n===1){F3Base_Fila::agendar(self::HOOK,time()+10);}return array('ok'=>$n===1,'codigo'=>$n===1?'uma_intencao_autorizada':'intencao_ja_existe_ou_erro');
    }
    public static function processar(): array {
        global $wpdb;$lock=F3Base_Trava::adquirir('c0-worker',120);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}$count=0;
        try{
            $cfg=F3Base_Options::ler('f3base_c0');if(empty($cfg['ativo'])){return array('ok'=>true,'codigo'=>'desligado');}
            F3Base_Pipedrive_Api::iniciar_lote();$crm=F3Base_Pipedrive_Api::configuracao_lote();$state=get_option('f3base_pipedrive_estado',array());$account=($state['dominio']??'').'|'.($state['conta_id']??'').'|'.($state['instalacao']??'');
            self::reconciliar();
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado IN ('pendente','enviado','incerto') AND proxima<=%d ORDER BY proxima LIMIT 3",self::tabela(),time()),ARRAY_A);
            foreach($rows as $row){
                $lead=F3Base_Leads_Repositorio::obter($row['record_id']);$p=F3Base_Contato_Comunicacao::abrir($row['payload']);$authorization=$p['homologacao']??array();$testAllowed=$lead&&($authorization['email']??'')===$lead['email']&&($authorization['expires']??0)>time()&&in_array($lead['email'],$cfg['homologacao_emails']??array(),true);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||($lead['classe_trafego']!=='nao_marcado'&&!$testAllowed&&!$row['enviado_em'])){self::atualizar($row,array('estado'=>'cancelado','codigo'=>'registro_inelegivel'));continue;}
                if($row['conta']!==$account||empty($crm['ativo'])||!F3Base_Integracoes::pipedrive_verificado()){self::atualizar($row,array('codigo'=>'conta_indisponivel','proxima'=>time()+3600));continue;}
                $p=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!$p){self::atualizar($row,array('codigo'=>'snapshot_indisponivel','proxima'=>time()+3600));continue;}
                if($row['estado']==='pendente'){
                    $messageConfig=$p['config'];$messageConfig['textos_servicos']=($messageConfig['textos_servicos']??array())+($cfg['textos_servicos']??array());$message=$p['message']??self::mensagem($p['ctx'],$messageConfig,$p['plan'],time());if(($p['plan']['prazo_em']??0)<time()){$message=array('ok'=>false,'codigo'=>'prazo_c1_vencido');}if($testAllowed&&!empty($message['ok'])){$message['subject']='[TESTE] '.$message['subject'];}$remote=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$row['lead_id']);$bcc=$remote['data']['cc_email']??'';
                    $code=empty($message['ok'])?$message['codigo']:(empty($remote['ok'])?'smart_bcc_consulta_pendente':(!is_email($bcc)?'smart_bcc_ausente':((int)($remote['data']['person_id']??0)!==(int)$p['person_id']?'pessoa_divergente':'')));
                    if($code!==''){self::atualizar($row,array('codigo'=>$code,'proxima'=>time()+3600));self::complementar($row,$p,$lead,$crm);continue;}
                    if(F3Base_Segredos::abrir('f3base_c0_smtp_senha')===''||empty($cfg['alocacao_confirmada'])||!self::reservar_cota(count(array_unique(array_map('strtolower',array($lead['email'],self::MAILBOX,$bcc)))),(int)$cfg['cota_destinatarios_hora'])){self::atualizar($row,array('codigo'=>'smtp_credencial_ou_cota','proxima'=>time()+3600));continue;}
                    $p['message']=$message;if(!self::atualizar($row,array('estado'=>'incerto','codigo'=>'smtp_iniciado','payload'=>F3Base_Contato_Comunicacao::cifrar($p)))){continue;}
                    $result=self::smtp($message,$lead['email'],$bcc);$patch=$result+array('proxima'=>time()+3600);if($result['estado']==='enviado'){$patch['enviado_em']=time();}if(!self::atualizar($row,$patch)){continue;}++$count;
                }
                self::complementar($row,$p,$lead,$crm);
            }
            return array('ok'=>true,'processados'=>$count);
        }finally{F3Base_Trava::liberar($lock);}
    }
    private static function complementar(array &$row,array $p,array $lead,array $crm): void {
        $sent=$row['estado']==='enviado';$mark='f3base:c0:'.$row['chave'];
        // Unknown POSTs are reconciled by marker and never blindly repeated.
        if(!$row['atividade_id']){
            $list=F3Base_Pipedrive_Api::listar('v2/activities',array('person_id'=>$p['person_id']));if(!empty($list['ok'])){$matches=array_values(array_filter($list['data'],static fn($a)=>($a['lead_id']??'')===$row['lead_id']&&str_contains($a['note']??'',$mark)));if(count($matches)===1){self::atualizar($row,array('atividade_id'=>(int)$matches[0]['id'],'atividade_estado'=>!empty($matches[0]['done'])?'concluida':'aberta'));}elseif(!$matches&&$row['atividade_estado']!=='incerta'){
                if(self::atualizar($row,array('atividade_estado'=>'incerta'))){$at=$sent?(int)$row['enviado_em']:time();$data=array('subject'=>'C0 E-mail','type'=>'email','done'=>$sent,'due_date'=>gmdate('Y-m-d',$at),'due_time'=>gmdate('H:i',$at),'lead_id'=>$row['lead_id'],'owner_id'=>$crm['responsavel'],'participants'=>array(array('person_id'=>(int)$p['person_id'],'primary'=>true)),'note'=>'<p>'.esc_html($mark.' | '.$row['codigo'].' | SMTP: '.($sent?gmdate('c',$at):'sem confirmação')).'</p>');$res=F3Base_Pipedrive_Api::pedir('POST','v2/activities',$data);if(!empty($res['ok'])&&!empty($res['data']['id'])){self::atualizar($row,array('atividade_id'=>(int)$res['data']['id'],'atividade_estado'=>$sent?'concluida':'aberta'));}elseif(empty($res['incerto'])){self::atualizar($row,array('atividade_estado'=>'pendente'));}}}}
        }
        if($sent&&$row['atividade_id']&&$row['atividade_estado']!=='concluida'){$res=F3Base_Pipedrive_Api::pedir('PATCH','v2/activities/'.$row['atividade_id'],array('done'=>true,'note'=>'<p>'.esc_html($mark.' | SMTP aceito em '.gmdate('c',(int)$row['enviado_em'])).'</p>'));if(!empty($res['ok'])){self::atualizar($row,array('atividade_estado'=>'concluida'));}}
        if(!$sent&&!in_array($row['slack_estado'],array('enfileirado','entregue','incerto'),true)){$result=F3Base_Slack::retorno_pipedrive($lead,'c0-falha:'.$row['chave'],array('C0 E-mail'=>array('Estado'=>$row['estado'],'Motivo'=>$row['codigo'])),'');self::atualizar($row,array('slack_estado'=>$result['estado']??'pendente'));}
        if($sent&&$row['atividade_estado']==='concluida'){self::atualizar($row,array('estado'=>'concluido'));}else{self::atualizar($row,array('proxima'=>time()+3600));}
    }
}
