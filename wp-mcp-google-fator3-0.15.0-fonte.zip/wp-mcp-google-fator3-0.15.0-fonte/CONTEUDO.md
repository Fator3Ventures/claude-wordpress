# Fonte Google 0.15.0

Runtime, documentos editaveis, testes e scripts estao em plugin/wp-mcp-google-fator3/. Use tools/README.md para reproduzir a bancada com insumos declarados em evidence/015/inputs.json. Ferramentas PHP/MySQL/WordPress e ZIPs acompanhantes nao acompanham este fonte. build/close-release.py fecha somente bytes validados. A copia interna do relatorio antecede o fechamento; consulte o relatorio externo para o hash do fonte. Evidencias 014 e anteriores sao historicas.
