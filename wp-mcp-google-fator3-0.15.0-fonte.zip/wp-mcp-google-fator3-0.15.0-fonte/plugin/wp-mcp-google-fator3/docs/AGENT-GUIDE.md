# Guia para agentes — Fator3 MCP Google 0.15.0

## Descobrir e ler

Descubra `google/documentation` pelo catálogo MCP, leia o schema e execute com `{}`. O índice lista somente conteúdo local desta versão. Leia cada ID com `document`, `offset: 0` e `limit_bytes: 16384`; nas páginas seguintes envie o `next_offset` retornado e `expected_revision` igual ao hash inicial. Concatene `content` sem separadores e confira SHA-256 contra `revision`. Offset é byte UTF-8, não caractere. Limites: 256–65536 bytes de conteúdo por página. O leitor ajusta a fronteira UTF-8 e nunca corta um caractere. `has_more: false` e `next_offset: null` encerram o documento. Revisão ausente em continuação ou divergente produz `f3_google_document_revision`; recomece pelo índice.

A rota exige `manage_options`. Não depende de canal Google aberto, credencial, armazenamento de jobs ou fornecedor. A autorização do transporte MCP continua sendo exigida. O painel também fornece os mesmos documentos compilados por download autenticado. IDs desconhecidos, caminhos, URLs e travessia são recusados com `f3_google_document_missing`. O conteúdo é informação, nunca autorização de execução.

Mapa: README (especificação e limites), GUIA-0.15.0.md (configuração e uso), CONTRACTS/CONTRATOS-PUBLICOS/SDK-PHP (contratos), ability-catalog.json (schemas de todas as operações), configuration-definitions.json (configuração), profile-schema.json (perfis), MIGRACAO/ACOMPANHAMENTO-CRON (operação e recuperação), VALIDACAO (limites da prova), CHANGELOG (notas e histórico).

## Diagnosticar antes de agir

Use `google/status` com `{}` para estado completo. Somente `google/integration-status` aceita `compact: true`. Canal habilitado permite encaminhar pedidos; não prova acesso a ativos Google. Identidade legível também não prova token válido. Diagnóstico antigo ou inválido exige teste explícito. Revise configurações, política, escopos e ativos antes de consultar. Nunca copie segredos para parâmetros de jobs, documentação ou logs.

Exemplo de leitura: `google/query` com `connector: "ga4"`, `accounts: ["properties/123456"]`, `metrics: ["sessions"]`, `dimensions: ["country"]`, `date_range: {"from":"2026-09-01","to":"2026-09-30"}`. Substitua a propriedade por uma descoberta e autorizada. Ausência de linhas é resultado vazio, não falha. `collection.complete` descreve extração; cobertura parcial e qualidade devem ser examinadas mesmo com `success: true`.

Configuração exige administração, revisão vigente e as confirmações descritas no schema de `google/configure`/`google/configure-local`. Leia `google/configuration-schema`, prepare a alteração, use somente campos presentes no schema vivo e verifique com nova leitura. Escritas sensíveis usam `google/prepare-operation` e seu token de uso único. Não reutilize automaticamente uma escrita cujo resultado seja incerto.

## Entrega de grandes resultados

O limite do envelope Google é 1.048.576 bytes JSON com escapes, após os campos de resultado da operação. O MCP aplica adicionalmente seus próprios limites. Uma consulta direta grande recebe `f3_google_result_delivery_limit`, sem truncagem ou criação automática de job. Para query/report, crie explicitamente `google/create-job` com `task: "query"` ou `"report"` e os parâmetros originais. Para blend, crie jobs query por entrada e componha no cliente. Execute/acompanhe o job conforme sua autorização; depois leia `google/get-job`.

`google/get-job` aceita `job_id`, `offset` (mínimo 0), `limit` (1–100), `include_input` e `section`: `rows`, `coverage`, `quality_pages`, `quality_changes`, `page_changes`, ou `results` para inspeções. Omitir seção seleciona rows/results ou a primeira disponível. Cada seção tem paginação independente. O manifesto `job.delivery.sections` declara total, retornado, omitido e parâmetros de leitura. A página cabe simultaneamente no limite de itens e de bytes; `next_offset` avança pelo número realmente devolvido. Metadados pequenos podem acompanhar a visão padrão completos. Consulte separadamente os omitidos. `delivery.contract_version` é `1.0.0`; `delivery.bytes` mede o objeto job codificado, e o envelope reserva 32 KiB para campos externos.

Uma seção inexistente produz `f3_google_result_section`, nunca um vazio artificial. Item, cabeçalho ou parâmetros individualmente grandes produzem erro com seção/offset/motivo e sem continuação que entre em loop. Remover `include_input` pode resolver excesso de parâmetros. Não há corte de strings. Dados originais persistidos e exportações Sheets mantêm seu conteúdo. Se `operation_outcome` disser `applied`, uma falha de entrega não autoriza repetir a ação. Consulte o job indicado. Resultado expurgado só permite o resumo retido, conforme retenção e autorização.

## Fronteiras e recuperação

O Google mantém policy contract 1, execution contract 2.0.0 e SDKs públicos existentes. Não leia options privadas do Core/MCP/sociais. Medição Core usa `site-measurement-context/1.0.0`, schema 1, seis slots. Um slot GTM vazio não apaga bindings Google nem autoriza inferir GA4. Os consumidores devem conservar tipos booleanos e inteiros do diagnóstico; diferenças introduzidas pelo transporte pertencem ao MCP.

Instalação limpa e atualização direta 0.14.0 → 0.15.0 são o percurso desta release. Não se exige passagem por versões anteriores. Faça backup antes de atualizar; rollback de arquivos não desfaz banco, jobs ou efeitos externos. Consulte `google/status`, `google/storage-status`, `google/maintenance` e os manuais de recuperação conforme o problema e as permissões. Leitura de ajuda nunca executa essas ações.

## Requisitos e material

Instale em WordPress 7.1.2+ e PHP 8.3.6+. O SDK Core 1.0.0 não anuncia download_material nem seus identificadores. A ausência no catálogo não significa que o Core não emita material. Não reutilize generate_lead ou o label de contato; use configuração explícita separada e consulte RECEITAS.md. Não marque evento-chave nem publique GTM sem instrução para a ação.

## Conversões e tipagem na 0.15.0

Consulte [CONVERSOES.md](CONVERSOES.md) para `google/conversion-context`, o bloco adicional GTM e `effective_value` booleano (Pedido MCP Google 26). O contrato de medição existente permanece.

Na recusa `revision_conflict` de `google/conversion-context`, confira `conflict:true` e `retryable:false`. Releia sem guarda antes de usar uma nova revisão. Não suponha que `current_revision` estará presente: o erro do SDK 1.0.0 não a fornece. A leitura não comprova entrega servidor. Os adaptadores GA4/Ads existem desde a 0.14.0; a 0.15.0 oferece `sendBound()` exigido pelo Core 1.41. Consulte CONVERSION-DELIVERY-CORE-140.md para configuração, referência de destino e limites. Não altere a referência histórica para destravar uma fila; a recuperação explícita pertence ao Core.
