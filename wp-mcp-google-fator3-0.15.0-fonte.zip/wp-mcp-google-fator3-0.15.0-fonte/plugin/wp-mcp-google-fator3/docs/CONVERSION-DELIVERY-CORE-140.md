# Conversões servidor — Google 0.15.0 / Core 1.41.0

Contrato `site-conversion-delivery/1.0.0`; destinos `ga4` e `google_ads`. O Core mantém seleção navegador/servidor, elegibilidade, fila, trava, deduplicação e diário por registro. O Google preserva outro adaptador registrado e não cria fila paralela. A leitura `site-conversion-purposes/1.1.0` negocia transporte; o leitor anterior 1.0.0 continua disponível.

## Configurar e verificar

Abra Ferramentas → Fator3 MCP Google — Conversões. Selecione a conexão, habilite os serviços com perfil de escrita e configure o destino. Para GA4, informe Measurement ID, recurso `properties/123/dataStreams/456` e segredo MP obtido em Administrador → Fluxos de dados → fluxo Web → Segredos da API do Measurement Protocol. O segredo é cifrado por conexão; o campo vazio mantém o valor; remoção é explícita. A tela usa nonce e revisão de configuração.

As operações `google/conversion-delivery-status`, `google/configure-conversion-delivery` e `google/verify-conversion-delivery` exigem administração. Status é local e também integra `google/status`. Configurar exige `expected_revision` e um objeto `config` fechado: `enabled`, `measurement_id`, `stream`, `customer_id`, `conversion_action`. Valor e moeda são dados de cada conversão do Core, não da configuração.

Verificar exige `expected_revision` e `target` (`ga4`/`google_ads`). GA4 consulta o fluxo e seus segredos pela Admin API e compara Measurement ID e segredo exato; só então usa `/debug/mp/collect`. Debug sozinho não valida o segredo. Nenhum evento dessa verificação é coletado.

Ads usa UploadClickConversions para conta/token elegíveis. Exige declaração administrativa de upload anterior bem-sucedido em `eligibility_receipt`, com `customer_id`, `conversion_action`, `successful_upload_confirmed:true` e `request_id` real. Consulta a ação e exige `UPLOAD_CLICKS`/`ENABLED`. A origem da comprovação permanece `administrator_attestation_and_action_read`: o plugin não consulta um recibo histórico no fornecedor. Token configurado ou validateOnly não comprova elegibilidade. Data Manager não foi introduzido sem evidência concreta de necessidade. Não há troca automática de API.

A autorização de background liga administrador concedente, conexão, destino, credenciais, segredo, serviços, política e geração de recuperação. Verificação vale 24 horas. Mudança ou expiração revoga prontidão; requer nova verificação administrativa. Mais de uma conexão habilitada para o mesmo destino é ambiguidade explícita. `ready` local não afirma homologação analítica.

## Envio e resultado

`sendBound(array $payload, string $destinationRef)` é a extensão PHP usada pelo Core 1.41, tanto no cron nativo quanto no executor de tarefas. O Core captura `destination_ref` no aceite e negocia a extensão pela existência do método. O contrato básico continua 1.0.0; `send(array $payload)` permanece compatível com Core 1.40. A referência opaca inclui site, conexão, identidade de credencial e destino; não deve ser fabricada, inferida de registros antigos nem reescrita para liberar uma fila. Não há rota MCP/REST para enviar conversões diretamente. A autorização do administrador concedente é revalidada sem assumir sua identidade. A referência é comparada sob a trava comum de configuração/envio. Antes de cada HTTP, relê a identidade atual e revalida autorização e trava. Referência vazia, longa ou divergente antes do despacho resulta em `recusado`, `non_delivery_proven:true`, `code:destination_mismatch`. Se mudar depois do debug GA4, a coleta é impedida. Perda comprovada da concessão/trava no guard usa `authorization_changed`. Esses códigos não representam respostas Google. O cliente mantém política, admissão, recuperação e limite de tempo; não repete HTTP de conversão.

GA4 preserva `client_id`, `session_id`, `event_id` e `timestamp_micros`, verifica coerência com `occurred_at` e limite de 72 horas. Não interpreta session_id como timestamp e não inventa engagement_time_msec. Quando engagement real é fornecido, preserva-o. Valida cada payload em debug antes da coleta. HTTP 2xx retorna `entregue`, `evidence:http_received`, `processed:null`; não prova processamento nem atribuição à sessão original. A homologação em sessão/Android WebView continua necessária.

Ads exige exatamente um de gclid/gbraid/wbraid, consentimento GRANTED, data com fuso, valor/moeda do payload e `orderId=record_id`. Envia um item por chamada. Só aceita resultado individual com ação, clique e instante correspondentes. ACK apenas de lote/ação, resposta parcial, divergência e timeout ficam `incerto`; o Core não deve repetir automaticamente. Recusa antes do envio inclui `non_delivery_proven:true`.

## Transição e recuperação

Atualize Google 0.14→0.15 e verifique a configuração antes de habilitar servidor no Core 1.41. Core 1.41 com Google 0.14 bloqueia servidor com `destination_binding_unsupported`; o modo navegador permanece. Google 0.15 com Core 1.40 mantém `send()`, sem a proteção de vínculo no aceite trazida pelo Core 1.41. A atualização Google não altera o Core nem regrava os destinos de contatos. Retornar à 0.14 remove `sendBound()` e volta a bloquear servidor no Core 1.41; preserve fila/diário e reconcilie resultados incertos.

O Core 1.41 também valida procedência e janela temporal da sessão GA4. O adaptador Google preserva o payload recebido; não recria sessão nem comprova atribuição analítica.

## Limites das provas

Ensaios nativos usam WordPress/PHP/MySQL e HTTP MCP reais; respostas Google são fixtures. Evidência recebida no patch Core é referência histórica, não resultado próprio. Contagens executadas ficam no relatório externo e em `evidence/015`. Credenciais, quotas, APIs habilitadas, Android WebView, GA4 Realtime/DebugView e conversão Ads real permanecem pendentes. Nunca usar credenciais fictícias para declarar conta homologada.

Referências: [validação MP](https://developers.google.com/analytics/devguides/collection/protocol/ga4/validating-events), [resultado individual Ads](https://developers.google.com/google-ads/api/reference/rpc/v25/ClickConversionResult), [upload offline](https://developers.google.com/google-ads/api/docs/conversions/upload-offline).
