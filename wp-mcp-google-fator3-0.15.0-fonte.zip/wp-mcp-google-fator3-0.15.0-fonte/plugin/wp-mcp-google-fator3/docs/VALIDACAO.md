# Validação — 0.15.0

Escopo: dependência Core 1.41, vínculo de destino no envio, revisão da identidade antes do HTTP, atualização Google 0.14→0.15, instalação limpa, isolamento e transição com Core 1.40. Mínimos da bancada: WordPress 7.1.2/PHP 8.3.6. MCP 0.24.0; Meta/LinkedIn 0.3.0 como sentinelas de preservação no upgrade.

`tools/release015.py` verifica inventário exato do candidato e vincula testes/evidências por SHA-256. O laboratório usa PHP CLI server com quatro workers, MySQL isolado, HTTP MCP real e respostas Google simuladas; rede comercial bloqueada. As verificações recebidas do Core são referência, sem somá-las às próprias.

Resultados e contagens efetivos ficam no relatório externo e em `evidence/015`. As provas 014 e anteriores são históricas. A rodada não repete os ensaios de interrupção de cron, cujo código permanece igual, nem o gate integral PHPUnit/`tools/validate.py`/`build/build.py verify`.

Pendentes: ativos/credenciais comerciais, processamento e atribuição GA4, Android WebView, Ads real, ausência de duplicação no navegador e observação de três dias nos 12 sites. Sem validação visual, PHP-FPM, multisite/CDN ou matriz de outros runtimes. O estado remoto é o observado no relatório, sem inferir instalação a partir dos ZIPs recebidos.
