# Conversões por finalidade — Google 0.13.0

`google/conversion-context` lê a configuração local pública de **contato** e **material**. Usa o SDK opcional `F3Base_Conversoes_Contexto`, contrato `site-conversion-purposes/1.0.0`, provider `base-site-core-fator3`, `schema_revision:"1"`. A leitura funciona sem credencial Google; exige `manage_options`, capacidade adicional configurada, canal habilitado e perfil MCP autorizado. A chamada direta do callback aplica o mesmo gate administrativo.

## Descobrir e ler

1. Descubra `google/conversion-context` no catálogo e confira seu schema.
2. Execute `{}`. `connection_id` opcional usa as políticas daquela conexão, mas o contexto continua sendo do site. O seletor nunca é enviado ao Core.
3. Leia `success`, `core_conversion_context.ok` e `code`; somente `ok:true` contém `data` válida.
4. Para exigir a mesma fotografia, repita com `expected_revision` igual à revisão retornada. Não há `offset` nem `limit`.

A resposta conserva o envelope Google e aninha o envelope Core exato: `ok`, `code`, `contract`, `provider`, `data`. Decorações normais do executor/transportador continuam presentes. Falha desta operação produz `success:false` e `error_code:f3_google_core_conversion_<code>`, mantendo o código original e `data:null` no bloco. Recusa anterior de autorização não expõe o contexto.

Em sucesso, `data` contém `scope:site_configuration`, `revision`, `measurement_revision`, `observed_at`, `purposes` e as flags `runtime_verified:false` e `remote_access_verified:false`. São exatamente duas finalidades, identificadas pelo campo `purpose`, independentemente da ordem.

| Finalidade | Evento GA4 | Evento Meta | Google Ads / LinkedIn |
|---|---|---|---|
| contact | generate_lead | Lead | Identificadores locais de contato |
| material | download_material | MaterialDownload | Rótulo Ads e conversion_id LinkedIn próprios de material |

Cada finalidade contém os destinos `ga4`, `google_ads`, `meta`, `linkedin`, com `enabled`, `configured`, `identifiers` e `provenance`. Meta/LinkedIn são somente informação pública do Core nesta leitura. O Google não opera essas APIs.

`enabled:true/configured:false` é válido: o destino está ligado, mas faltam identificadores locais. String vazia e null permanecem distintos. Material não herda rótulo Ads ou ID LinkedIn de contato. Um mesmo Measurement ID ou AW-ID pode ser compartilhado entre finalidades; os eventos/rótulos as distinguem. `configured:true` não prova ação cadastrada na conta, permissão, consentimento, disparo nem entrega. Um rótulo web Ads não é um resource name de conversion action.

## Pedido MCP Google 27 — conflito de revisão

A recusa validada `revision_conflict` retorna `conflict:true` e `retryable:false`, tanto no callback administrativo quanto pelo MCP. O bloco Core permanece `ok:false/code:revision_conflict/data:null`. Outros erros não são classificados como conflito. Repetir a mesma guarda obsoleta não resolve a divergência: releia sem `expected_revision`, examine a fotografia e só então use a nova revisão.

O SDK 1.0.0 não traz a revisão atual no ramo de erro, portanto `current_revision` é omitida nesse caso. Se o produtor devolver uma fotografia de sucesso válida mas divergente da guarda, a defesa do consumidor recusa essa fotografia e informa sua `data.revision` como `current_revision`. Não existe uma segunda leitura, hash fabricado ou substituição por `measurement_revision`/revisão Google. A extensão não altera o schema Core. O parâmetro de saída opcional do adaptador interno é reinicializado em cada chamada.

Exemplo de recusa normal: `success:false`, `error_code:f3_google_core_conversion_revision_conflict`, `conflict:true`, `retryable:false`, sem `current_revision`.

## Falhas e ausência

| code | Tratamento |
|---|---|
| unavailable | Estado do consumidor: classe pública ausente; demais recursos Google continuam disponíveis |
| unsupported | Método/versão/schema incompatível, resposta malformada ou invariante inválida; não usar os dados |
| invalid_input | Entrada fora do contrato; corrigir parâmetros |
| unreadable | Produtor ilegível ou exceção sanitizada; diagnosticar sem converter em configuração vazia |
| revision_conflict | Configuração mudou; reiniciar a leitura, sem juntar fotografias |
| not_authorized | Recusa informada pelo produtor; não contornar o gate |

`unavailable` não foi adicionado ao enum do produtor. Os schemas originais são mantidos, e o schema de saída Google declara separadamente esse estado local. O consumidor valida descritor, métodos e payload contra cópias empacotadas: não importa classes internas, options privadas nem abre caminhos anunciados pelo produtor. Não busca schemas na rede.

## Diagnóstico GTM

`gtm/diagnostico` conserva `core_context`, `core_events`, seis slots e análise estática da versão publicada. Acrescenta `core_conversion_context`. O contexto de medição antigo continua usando `site-measurement-context/1.0.0`; `download_material` não foi incluído no catálogo antigo.

O diagnóstico obtém a fotografia de conversões antes da leitura GTM já existente, compara `measurement_revision` com o contexto de medição utilizado e revalida a revisão de conversões depois. Se somente o contexto adicional divergir ou ficar indisponível, o diagnóstico antigo válido permanece e o bloco adicional retorna falha com `data:null`. A alteração do contexto antigo mantém seu erro anterior. Não há repetição automática da chamada GTM por conflito.

A leitura GTM continua exigindo a credencial/serviço e acesso já previstos. Correspondência literal de identificadores permanece análise estática, sem prova de disparo.

## Efeitos, configuração e compatibilidade

O adaptador puro não grava nem acessa a rede. A operação é leitura local, `remote_effect:none`; auditoria sanitizada segue a política existente, inclusive falhas e `audit_local_reads:true`. Leituras não reparam storage, agendas ou configuração. Não são criados eventos-chave, ações Ads, tags, publicações, campanhas, grants, bindings ou jobs automaticamente.

O Core publica o contrato desde 1.36.0; a matriz da correção usa 1.38.0, o leitor de 1.39.0 e ausência do produtor. A instalação do Google não depende de versão/presença/ordem do Core. Não há nova credencial, opção, tabela ou migração nesta integração.

## Pedido MCP Google 26

`google/configuration-schema`, contrato 4.0.0, retorna true/false em `state.effective_value` das cinco opções declaradas booleanas: `enabled`, `ga_enabled`, `ads_enabled`, `audit_local_reads`, `purge_on_uninstall`. `persisted_value` continua representando o armazenamento WordPress e pode ser `""`/`"1"`. Campos textuais, null e dados de opções compostas não são convertidos por essa correção.

Para conferir `audit_local_reads:false`, use `google/configure-local` com o booleano false e `expected_revision` obrigatório obtido na leitura da configuração; leia `google/configuration-schema` em nova requisição. O resultado efetivo deve ser booleano false. A escrita continua sujeita aos gates e à revisão, sem mudança contratual nem migração de dados.

## Exemplos

Consulta local: `google/conversion-context {}`. Sucesso: `success:true`, bloco `ok:true/code:ok`; o material pode ter `enabled:true/configured:false` e IDs vazios. Ausência: `success:false`, `error_code:f3_google_core_conversion_unavailable`, bloco `ok:false/code:unavailable/data:null`.

Conflito: envie `expected_revision` de uma fotografia anterior após mudar a configuração de material; a resposta deve ser `revision_conflict`, com `data:null`. No diagnóstico GTM, esse mesmo bloco parcial não transforma uma análise antiga válida em prova de configuração ou entrega de material.

Os documentos instalados `core-conversions-capabilities.json`, `core-conversions-snapshot-input.json` e `core-conversions-snapshot.json` são cópias dos schemas do SDK PHP; o schema da operação Google está em `ability-catalog.json`. As fixtures do produtor e os testes adversários ficam no fonte, fora do runtime público.

## Core 1.39.0 — limite de prontidão

O novo `site-conversion-delivery/1.0.0` não é o contrato deste leitor. Google 0.13.0 não fornecia adaptador. A 0.14.0 fornece o adaptador separado descrito em [CONVERSION-DELIVERY-CORE-140.md](CONVERSION-DELIVERY-CORE-140.md). O contrato de leitura mantém `configured` como disponibilidade de identificadores locais; não representa transporte, segredo MP, permissão Ads ou entrega. A mudança operacional de contato no Core requer coordenação e homologação próprias; a análise técnica fica no impacto Google → Core da entrega. Material e o diagnóstico GTM preservam seus contratos.
