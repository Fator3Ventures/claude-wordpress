# Fonte do Fator3 Site Core 1.89.2

O runtime instalável está em `work/plugin/base-site-core-fator3/`. Os dados de pesquisa, a lista integral do Google Play usada no build, o registro das ambiguidades e o CSV distribuído estão em `reference/417/`. A base comercial de entrada está em `reference/415/`. As regras e os dados anteriores ficam em `reference/413/` e `reference/414/`.

## Reprodução

Na raiz deste fonte, com Python 3, execute os comandos abaixo. A compilação é local e dispensa rede. A versão utilizada de zlib foi 1.3.2.

```sh
python3 build/gerar-catalogo-aparelhos.py
python3 tests/catalogo-codinomes-417.py
python3 tests/gerador-417.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.89.2-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.89.2-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.89.2-fonte.zip
```

Para usar uma lista do Google Play mais recente, passe `--google-play /caminho/supported_devices.csv` ao gerador (UTF-16, quatro colunas). Para fechar uma revisão com essa lista, substitua a referência congelada, reveja os números e as fichas, execute a auditoria e atualize os manifestos. Os agregados deste pedido servem de controle da rodada.

## Verificações do pedido 417

A auditoria percorre todos os códigos e falha quando a ficha de um código com linha própria aponta para outro Device. O controle negativo `python3 tests/catalogo-codinomes-417.py reference/415/catalogo-aparelhos.csv` deve sair com status 1 e identificar 11 códigos. O teste padrão exige o delta exato das fichas aprovadas, o registro das ambiguidades sem linha própria e a preservação das demais entradas.

Em WordPress descartável, use o banco `core1892_417`, `WP_ENVIRONMENT_TYPE=local` e um administrador. Ative o pacote original 1.89.1, execute `wp --user=1 eval-file tests/pedido-417.php`, atualize para 1.89.2 e repita o comando. Os hashes das observações devem ser iguais. A única pendência inicial deve desaparecer na leitura. A seguir, execute `F3_QA_CATALOGO="$PWD/reference/417/catalogo-aparelhos.csv" wp --user=1 eval-file tests/catalogo-precos-413.php` para comparar a saída do resolvedor do WordPress com cada campo do CSV.

As evidências da rodada ficam em `evidence/1892/`. Resultado, limites e instruções de implantação estão em `RELATORIO-PRE-FECHAMENTO.md`. O relatório externo inclui tamanho e SHA-256 final do fonte. O empacotador impõe o limite de 100.000.000 bytes.
