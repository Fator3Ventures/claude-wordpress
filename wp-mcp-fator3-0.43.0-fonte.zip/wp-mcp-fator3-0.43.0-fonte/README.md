# Fator3 MCP 0.43.0

Servidor MCP para administração do WordPress. Em Ferramentas → Fator3 MCP, use Clientes conectados para definir o acesso de cada identidade. No Registro, filtre a atividade por conexão, habilidade ou período em UTC. Em Arquivos e banco, consulte o procedimento para revisar pré-imagens e acompanhar uma simulação de retenção com várias páginas.

Instalação limpa ou atualização direta da 0.42.0. Requisitos mínimos de WordPress 7.1.4 e PHP 8.3. Instale `wp-mcp-fator3-0.43.0-instalador.zip` e confira a versão em `system/health`. Em Ajuda, abra **Notas desta versão** para consultar as mudanças da versão ativa. Consulte os documentos `administracao`, `atualizacao` e `release-0430` na Ajuda ou por `system/guide`.

O fonte contém as ferramentas de reprodução em `tools/release0430/` e as evidências desta rodada em `evidencias/0430/`.
