# Instalação e atualização do Fator3 MCP 0.43.0

O plugin requer WordPress ≥ 7.1.4 e PHP ≥ 8.3. A atualização direta parte da 0.42.0. Os dados de conexões, concessões OAuth, sessões, recibos, prévias e backups continuam no mesmo banco. Esta release mantém o schema de dados 2.

1. Para instalação limpa, envie `wp-mcp-fator3-0.43.0-instalador.zip` pelo painel de plugins, ative e configure a conexão em Ferramentas → Fator3 MCP.
2. Na frota, confira o SHA-256 dos bytes servidos pela URL raw contra o relatório externo. Use `plugins/upload` com `expected_slug` igual a `wp-mcp-fator3`, o `expected_sha256` conferido, `overwrite` e `activate`. O Site-Teste também aceita `plugins/upload-base64` com a mesma conferência do arquivo local.
3. Em nova requisição, consulte `system/health` com `{"compact":true}`. Confira `plugin_version` igual a `0.43.0` e `healthy` igual a `true`. Abra **Ferramentas → Fator3 MCP → Ajuda → Notas desta versão** ou consulte `system/guide` com `{"document":"release-0430"}`. Um administrador com conexão de Manutenção pode verificar perfis com `connections/list`.
4. Se a instalação ficar pendente, consulte `plugins/operation-status` e reconcilie pelo ID. Para revisar a retenção de pacotes, siga o procedimento em `release-0420` e percorra o cursor de inventário.
5. Para recuperar dados, confira o estado observado e os backups correspondentes. As correções do software instalado seguem em uma nova versão. O procedimento de recuperação de linhas SQL com pré-imagem está em `release-0390`.

O relatório externo registra a identidade do instalador, os ambientes de teste e a situação da entrega.
