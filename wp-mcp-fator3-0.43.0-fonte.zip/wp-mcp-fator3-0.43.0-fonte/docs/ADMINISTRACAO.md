# Guia de administração do Fator3 MCP 0.41.0

Abra Ferramentas → Fator3 MCP com uma conta que tenha manage_options. O menu Configuração reúne acesso e preferências. Operação reúne planos, registros, diagnóstico e ajuda. No celular, use Menu para abrir a navegação.

## Consultar as mudanças da versão instalada

Em **Ferramentas → Fator3 MCP → Ajuda**, selecione **Notas desta versão**. O título do documento mostra a versão do MCP carregada pelo WordPress. Para consultar uma versão anterior, escolha o documento no seletor **Abrir documento**.

## Conectar o primeiro assistente

1. Abra Conexão do servidor e copie a URL principal. O estado local indica se o servidor e as ferramentas estão registrados neste WordPress.
2. Para OAuth, cole a URL no cliente e conclua a autorização da conta e do perfil. Para autenticação por senha de aplicação, escolha a conta e o perfil adequados e copie a senha gerada antes de sair.
3. Para outra conta, abra Clientes conectados → Emitir senha de aplicação → Escolher outra conta. Informe um nome identificável e a expiração desejada. A página de confirmação permite revelar a senha uma vez. Copie-a para o cliente autorizado antes de sair. O reenvio do mesmo formulário é recusado e o comprovante guarda apenas metadados.
4. Faça uma operação permitida a partir do próprio cliente e confira sua identidade no Registro. Testar comunicação HTTP executa um teste interno com credencial temporária. O resultado indica se este servidor respondeu ao próprio teste. A conexão real do cliente exige a verificação do passo anterior.

## Associar ou alterar um perfil

Use Associar identidade existente para vincular uma senha já emitida ou a integração que se identifica pelo usuário WordPress. A integração compartilha a política entre chamadas autenticadas como aquela conta. Clientes OAuth já autorizados aparecem na lista. Para uma identidade já configurada, use Editar. A lista mostra o perfil, a validade, o último acesso observado e as sessões ativas na página.

| Perfil | Uso e alcance |
|---|---|
| Leitura | Consultas de habilidades reconhecidas como leitura, sujeitas às permissões da conta. Há namespaces administrativos restritos. |
| Conteúdo | Consultas e edição de conteúdo conforme as capacidades do usuário. |
| Personalizado | Lista explícita de habilidades; cada alvo também verifica sua permissão. |
| Manutenção | Administração do site conforme as capacidades WordPress e as restrições efetivas do servidor. |

Em Perfil e validade, informe a expiração em UTC. Vazio deixa o perfil sem prazo adicional. A lista de habilidades se abre ao selecionar Personalizado; filtrar os nomes não altera as marcações. Habilidades e tipos temporariamente ausentes podem ser preservados. Em Restrições e permissões, configure tipos de conteúdo, chaves extras de metadados, diretórios, exportação de backups, escrita SQL e executor de leitura. O limite por arquivo do perfil Manutenção aceita de 1 MiB a 1 GiB, em bytes. Vazio herda o canal. Nos perfis restritos, diretórios vazios bloqueiam acesso a arquivos; tipos de conteúdo vazios permitem todos os tipos autorizados.

**Conflito ao salvar.** Abra novamente o cliente e compare a versão atual da política. Uma edição concorrente ou a tentativa de associar uma identidade existente não sobrescreve o perfil vigente. Se o servidor recusar um formulário incompleto, confira max_input_vars antes de repetir.

**Revogar acesso.** Abra o cliente, expanda Revogar acesso deste cliente, marque a confirmação e envie. A revogação bloqueia a identidade e encerra suas sessões. Para senhas de aplicação também remove a senha do WordPress. Uma concessão OAuth revogada interrompe a família correspondente. Para retomar, use outra credencial ou uma nova autorização. Uma credencial criada sem conseguir salvar seu perfil é descartada; se a exclusão não puder ser confirmada, o painel orienta a revisar a senha no perfil da conta.

## Consultar e alterar um cliente pelo MCP

Com uma conta que tenha `manage_options` e uma conexão de Manutenção, chame `connections/list` com `{"per_page":20}`. Cada item informa a identidade, o perfil, a revisão `policy_version` e se o acesso está ativo. “Sem acesso” também abrange credenciais indisponíveis, revogadas ou expiradas. Se `has_more` for verdadeiro, envie `next_before_id` como `before_id` na consulta seguinte. A consulta reflete o estado observado naquele momento. Cada execução verifica novamente sua autorização.

Para renomear a própria conexão, envie a `connections/update` o seu `connection_id`, a revisão lida em `expected_policy_version` e o novo `label`. Examine a prévia. Confirme com os mesmos parâmetros e o `confirm_token` recebido. Se a resposta se perder, repita a confirmação idêntica pela mesma credencial, enquanto ela conservar os privilégios. Um recibo concluído devolve `replayed:true` e a revisão daquela gravação. Consulte `connections/list` para saber a revisão atual.

Se receber `connection_policy_conflict` antes da aplicação, releia a política e prepare uma nova prévia. Diante de `operation_uncertain`, consulte `operations/status` com o `operation_id` antes de repetir a ação. Ao revogar ou reduzir o acesso da própria credencial, a nova política passa a valer para as chamadas seguintes.

## Configurar arquivos e banco

Em Arquivos e banco, cada formulário salva uma preferência. Acesso ao canal controla as chamadas de arquivos e banco. Escrita no banco libera as escritas SQL compatíveis com o perfil e a confirmação. O indicador mostra o estado efetivo. Com o canal fechado, a preferência de escrita continua armazenada; a próxima abertura volta a avaliá-la. Constantes e filtros do site podem limitar o resultado. Após um conflito, recarregue a tela para ver a preferência mais recente.

Em Transferência de arquivos, informe um limite em bytes. Um MiB equivale a 1.048.576 bytes. Abra Conferir alcance e restrições do servidor para ver diretórios, capacidades e filtros. Em Retenção dos backups SQL, informe idade, quantidade desejada e mínimo protegido. O mínimo precisa ser menor ou igual à quantidade máxima. A política seleciona candidatos; a remoção exige prévia e confirmação por backups/prune. Para escritas pontuais de até 200 linhas, consulte release-0390.

## Registro, diagnóstico e operação

No Registro de atividade, use **Identificar o evento** para informar o ID da conexão, o identificador exato da habilidade, o alvo ou caminho exato, ou o ID da operação. O campo Habilidade sugere os identificadores presentes na página. Para localizar uma habilidade removida, digite seu identificador completo.

Em **Resultado e período em UTC**, selecione o resultado e a janela desejada. “A partir de (UTC)” inclui o instante informado. “Antes de (UTC)” exclui o instante final. Para conferir as falhas de um dia, escolha “Falhou”, use 00:00 desse dia como início e 00:00 do dia seguinte como fim. Clique em **Filtrar**. **Próximos registros** mantém os critérios. **Limpar filtros** volta à consulta inicial.

Se o Registro indicar resultado incerto, consulte o ID da operação antes de repetir a ação. Operações mostra planos e permite solicitar cancelamento dos próximos passos. Diagnóstico apresenta rotas registradas, resultado recente do teste HTTP, auditoria e armazenamento. A Ajuda lê a documentação instalada.

## Configurar a fonte de atualização

A frota instala ZIPs versionados com expected_slug e expected_sha256. O fluxo habitual mantém a fonte de manifesto vazia. A aba Atualizações é de uso opcional, restrita à entrada do próprio MCP. Quando houver um manifesto aprovado, preencha a URL HTTPS e apenas os domínios adicionais de download autorizados. Uma URL simples armazenada por system/settings-update aparece como “A confirmar”. Verifique o valor e salve explicitamente para o canal usá-lo como descritor. Para desativar a fonte do MCP, limpe a URL e salve. A tela preserva as entradas dos demais plugins. Salvar a fonte não instala pacotes.

## Pesquisar no manual

Em Ajuda, pesquise duas ou mais letras, por exemplo “revogar acesso”. Clique no título da seção para abrir o texto no ponto encontrado. Para leitura sequencial, escolha um documento e use Continuar leitura. Pelo MCP, consulte system/guide com query, depois com document e cursor. O ID administracao contém este guia. O parâmetro ability retorna o contrato vigente da habilidade, após a verificação de acesso.

## Antes e depois de operações integradas (0.26.1)

No Registro, operation_id identifica a operação do produtor. Consultar antes e depois busca o diário público sob autorização. Ações do painel podem ser vistas pelo mesmo administrador; ações MCP exigem a conexão original. Snapshots são redigidos, não armazenados no MCP nem usados para restaurar. Estados incertos não significam sucesso. Consulte MUTATION-AUDIT.


## Falhas de autorização de clientes

A aba Diagnóstico mostra a mesma projeção de system/oauth-diagnostics: identificador opaco de 24 caracteres, categoria técnica e horário UTC, da mais recente para a mais antiga, até 128. Exige administrador. Compare com o identificador apresentado na página de autorização. Categorias: client_unavailable, metadata_fetch_failed, metadata_invalid, metadata_unsafe, metadata_method_unsupported e client_persistence_failed. Não exibe URL/identidade do cliente, tokens nem corpo da requisição. Falta de registro não é prova de conexão bem-sucedida; anel indisponível é erro explícito.

Nos eventos do Registro, habilidades presentes no catálogo exibem o rótulo público e o ID. Habilidades removidas aparecem como “Habilidade histórica” ao lado do identificador original.

## Revisar cópias de plugins

Em Arquivos e banco, abra **Pré-imagens de plugins**. O guia de retenção explica como simular a limpeza, continuar uma busca parcial e conferir os itens bloqueados. A política de backups SQL é configurada no formulário próprio da mesma tela.
