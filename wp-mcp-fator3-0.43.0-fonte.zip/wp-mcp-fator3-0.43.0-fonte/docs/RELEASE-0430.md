# Fator3 MCP 0.43.0 — Notas da versão instalada

## Pedidos MCP 79

Em **Ferramentas → Fator3 MCP → Ajuda**, clique em **Notas desta versão**. O atalho abre as notas da versão em execução. Na 0.42.0, ele ainda apontava para a 0.40.0.

Para conferir pelo MCP, consulte `system/health` com `{"compact":true}` e leia `plugin_version`. Para esta entrega, abra `system/guide` com `{"document":"release-0430"}`. A tela e o MCP leem o mesmo documento do pacote. O seletor da Ajuda permite consultar releases anteriores. Em **Arquivos e banco**, o exemplo sobre pré-imagens continua disponível nas notas da 0.42.0.

A atualização direta parte da 0.42.0. O atalho usa a versão já carregada pelo WordPress. Abrir as notas dispensa configuração adicional e consulta externa.
