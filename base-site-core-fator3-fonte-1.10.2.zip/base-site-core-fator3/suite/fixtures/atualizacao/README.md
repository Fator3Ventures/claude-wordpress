# Insumo anterior para a atualização real

A referência está em `suite/referencias/releases/base-site-core-fator3-1.0.0.zip`, com consumidor e hash declarados em `referencias.json`.

Cópia do ZIP instalável enviado pelo operador na sessão de evolução, sem alteração de bytes. Não é instalado em produção pela suíte. A bancada o instala apenas em um WordPress descartável, antes de trocar os arquivos pelo ZIP que está sendo testado.

SHA-256: `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f`.
