<?php
/* Plugin Name: Fixture de assets
Version: 0.0.0
*/
