<?php
/** Defeito: protege todo o prefixo e bloqueia o journal pertencente ao implantador. */
final class F3Base_Core_Config_Mcp {
    public static function registrar_protecao(): void {
        add_filter( 'wp_mcp_ultimate_protected_options', array( __CLASS__, 'proteger_options' ), 10, 2 );
    }
    public static function proteger_options( $protegidas, $nome = '' ): array {
        if ( str_starts_with( $nome, 'f3base_' ) ) { $protegidas[] = $nome; }
        return $protegidas;
    }
    public static function escrever( array $entrada ): array {
        return F3Base_Options::gravar( $entrada['nome'], $entrada['valor'], F3Base_Options::ORIGEM_MANUAL, $entrada['revisao_esperada'] );
    }
}
