<?php
$site=$argv[1]??'';$modo=$argv[2]??'';$arquivo=$argv[3]??'';
if(!is_file($site.'/.f3base-bancada-110'))exit(2);require $site.'/wp-load.php';wp_set_current_user(1);
$testes=[];
if($modo==='semear'){
 $testes['origem_1101']=F3BASE_PLUGIN_VERSAO==='1.10.1';
 $valores=['f3base_seo_entidade'=>['nome'=>'Empresa','autor_institucional'=>true,'legado'=>['pessoas'=>[['nome'=>'Pessoa legítima']]]],'f3base_ga4_measurement_id'=>'G-UPGRADE1102','f3base_google_ads'=>['conversion_id'=>'AW-123456','conversion_label'=>'fixture'],'f3base_sessao'=>['ligado'=>true,'dias'=>91],'f3base_consentimento'=>['padrao'=>'pre-aprovado','ttl_dias'=>100]];
 foreach($valores as$n=>$v)F3Base_Options::gravar($n,$v);
 $raw=[];foreach(array_keys($valores)as$n)$raw[$n]=get_option($n);$raw[F3Base_Options::OPTION_PROVENIENCIA]=get_option(F3Base_Options::OPTION_PROVENIENCIA);
 $id=wp_insert_post(['post_title'=>'Preservar upgrade 1.10.2','post_status'=>'publish','post_type'=>'post','post_author'=>1]);
 file_put_contents($arquivo,wp_json_encode(['raw'=>$raw,'id'=>$id]));
 file_put_contents(WP_CONTENT_DIR.'/mu-plugins/upgrade1102.php','<?php add_action("activated_plugin",static function($p){if(str_contains($p,"base-site-core"))file_put_contents(ABSPATH."reativou1102","1");});');
}else{
 $f=json_decode(file_get_contents($arquivo),true);$testes['destino_1102']=F3BASE_PLUGIN_VERSAO==='1.10.2';
 $testes['ativo_sem_reativar']=is_plugin_active('base-site-core-fator3/base-site-core-fator3.php')&&!is_file(ABSPATH.'reativou1102');
 foreach($f['raw']as$n=>$v)$testes['preserva_'.$n]=get_option($n)===$v;
 $testes['post_e_autor_preservados']=get_post($f['id'])->post_author==='1';
 $testes['autoria_legada_ativa']=F3Base_Autoria::modo($f['id'])==='organizacao';
 $testes['novos_padroes_sem_gravar']=get_option('f3base_google_carregamento',null)===null&&F3Base_Options::ler('f3base_google_carregamento')['modo']==='imediato';
 $testes['contrato_150']=F3Base_Config_Contrato::VERSAO==='1.5.0';
}
echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'testes'=>$testes,'falhas'=>array_keys(array_filter($testes,static fn($v)=>!$v))],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit(in_array(false,$testes,true)?1:0);
