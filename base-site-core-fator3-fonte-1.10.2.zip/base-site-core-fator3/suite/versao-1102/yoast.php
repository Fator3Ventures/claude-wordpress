<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110'))exit(2);$_SERVER['SERVER_NAME']='127.0.0.1';require $site.'/wp-load.php';wp_set_current_user(1);
$testes=[];$warnings=[];set_error_handler(static function($n,$m)use(&$warnings){if(error_reporting()&$n)$warnings[]=$m;return false;});
$v=get_option('wpseo_titles',[]);$v['company_or_person']='company';$v['company_name']='Organização Fixture';update_option('wpseo_titles',$v);
$aid=wp_insert_attachment(['post_title'=>'Logo fixture','post_mime_type'=>'image/png','guid'=>home_url('/logo-fixture.png'),'post_status'=>'inherit']);update_post_meta($aid,'_wp_attachment_metadata',['width'=>128,'height'=>128,'file'=>'logo-fixture.png','sizes'=>[]]);update_post_meta($aid,'_wp_attached_file','logo-fixture.png');
WPSEO_Options::set('company_or_person','company');WPSEO_Options::set('company_name','Organização Fixture');WPSEO_Options::set('company_logo_id',$aid);add_filter('wpseo_schema_company_logo_id',static fn()=> $aid);
F3Base_Options::gravar('f3base_seo_entidade',['autoria'=>'organizacao','razao_social'=>'Legal Core','descricao'=>'Descrição Core']);
$id=wp_insert_post(['post_type'=>'post','post_status'=>'publish','post_title'=>'Grafo integrado','post_content'=>'Artigo de bancada.','post_author'=>1]);
// Simula prioridades dos emissores citados; não substitui os arquivos dos temas reais.
add_filter('wpseo_schema_organization',static function($d){$d['legalName']='Legal do emissor';return$d;},25);
add_filter('wpseo_schema_article',static function($d){$d['author']=['@type'=>'Person','name'=>'Autor do emissor'];return$d;},30);
$grafo=[];add_filter('wpseo_schema_graph',static function($g)use(&$grafo){$grafo=$g;return$g;},PHP_INT_MAX);
$GLOBALS['wp_query']=new WP_Query(['p'=>$id,'post_type'=>'post']);$GLOBALS['wp_the_query']=$GLOBALS['wp_query'];$GLOBALS['post']=get_post($id);setup_postdata($GLOBALS['post']);
ob_start();wp_head();$html=ob_get_clean();
$org=null;$artigo=null;$pessoas=0;foreach($grafo as$n){$tipos=(array)($n['@type']??[]);if(in_array('Organization',$tipos,true))$org=$n;if(array_intersect($tipos,['Article','BlogPosting','NewsArticle']))$artigo=$n;if(in_array('Person',$tipos,true))$pessoas++;}
$testes['yoast_real_ativo']=defined('WPSEO_VERSION');$testes['organization_real']=$org!==null;$testes['emissor_anterior_preservado']=($org['legalName']??'')==='Legal do emissor';$testes['campo_ausente_complementado']=($org['description']??'')==='Descrição Core';
$testes['autoria_no_grafo_final']=$artigo!==null&&($artigo['author']['@id']??'')===($org['@id']??null);
$testes['pessoa_legitima_preservada']=$pessoas>0;$testes['usuario_wordpress_preservado']=(int)get_post($id)->post_author===1;
$testes['helper_coerente']=f3base_autor_exibido($id)===($org['name']??null);$testes['sem_avisos']=$warnings===[];
restore_error_handler();echo wp_json_encode(['yoast'=>defined('WPSEO_VERSION')?WPSEO_VERSION:null,'testes'=>$testes,'avisos'=>$warnings,'falhas'=>array_keys(array_filter($testes,static fn($v)=>!$v))],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit(in_array(false,$testes,true)?1:0);
