# Base Site Core Fator3 1.10.2 — implementação e homologação

**1.10.2 instalada no site de testes; homologação parcial. Liberação para produção ainda pendente.**
Não houve implantação em sites de produção. Os modos opcionais não foram ativados automaticamente.
O ensaio temporário de llms físico foi revertido ao modo dinâmico após detectar pendências HTTP.

## Identidade da entrega

- Instalador: `base-site-core-fator3-1.10.2.zip`.
- SHA-256 do instalador: `4a5adf03c370d9d8152bfe98c120624c483890dabf45449c75bf51292e9cc4ae`.
- Fontes: `base-site-core-fator3-fonte-1.10.2.zip`, com inclusão explícita, fontes legíveis,
  assets minificados, lockfiles, testes, guias e evidências.
- Contrato descritivo: `1.5.0`; rota `f3base/config-core-contrato-v1` preservada.
- Base: os pacotes 1.10.1 fornecidos nesta conversa. Plano consolidado: release 1.10.2.

## Alterações

| Área | Entrega |
|---|---|
| WhatsApp | Descrições/dependências coerentes com o runtime; botões editoriais permanecem sob controle do tema. |
| Auditoria | Origem histórica, revisão confirmada, legado, hash compatível/divergente, leitura indisponível e persistência sem auditoria distinguíveis. Leitura não regrava procedência; saúde da auditoria separada da operação. |
| Entidade | Razão social, CNPJ numérico/alfanumérico, contato, endereço, controladora e filhas; validação local, erros por campo, simulação/CAS e preservação de legado. Propriedades de outros emissores são conservadas. |
| Autoria | Política `usuario` ou `organizacao`, exceção por post, compatibilidade com `autor_institucional` e helper para temas. `post_author` e pessoas legítimas preservados. |
| Schema publicado | Inspeção limitada do HTML completo, referências, conflitos, logos e perfis; lotes retomáveis com reserva e contexto. Estados de rede e lacunas não equivalem a aprovação. |
| Google | Padrão imediato; opção após interação ou teto após load. Fila por categoria e descarte após revogação. GTM independente. Estado local de carga separado de entrega de eventos. |
| Consentimento | Mesmo CSS/handle em inline; filtro para manter arquivo externo em CSP restritiva. |
| llms.txt | Dinâmico por padrão; arquivo físico opcional com propriedade, lock, publicação atômica, atualização por eventos/intervalo/visita e retirada por mudança de acesso. Arquivo externo preservado. Verificação GET/HEAD/304, cabeçalhos e validade da prova. |
| Desempenho | Perfil PHP administrativo com nonce e sem cache público. O web-vitals mantém sua carga existente. |
| Documentação | Guia estável `docs/OPERACAO.md`, recuperação de código/banco/fila, desinstalação, modos de consentimento/sessão, acessos e CAPI atualizados. Gerador resolve métodos de uma linha e constantes locais/externas. |

## Evidências executadas

Bancada descartável com WordPress 6.9, PHP 8.3.6, SQLite Database Integration 3.0.2,
Yoast 28.4 e WP Super Cache 3.1.3. PHP com DOM/libxml e extensões da bancada. Dependências
PHPStan/WPCS instaladas pelo lockfile; não integram o instalador.

| Verificação | Resultado e escopo |
|---|---|
| Upgrade do ZIP 1.10.1 → ZIP final 1.10.2 | 12 verificações aprovadas, sem reativar; preferências, procedência, posts/autores e novos padrões preservados. |
| Regressão específica 1.10.2 | 78 verificações aprovadas, sem avisos PHP. Inclui CNPJ, legado, arquivo llms, prova antiga, permissões, schema nativo e confronto de todos os módulos com a tabela gerada. |
| Configuração existente | 25 verificações aprovadas. |
| Abilities nativas | 6 cenários aprovados: schemas, consultas sem efeitos, permissão, mescla, simulação e conflito. |
| Yoast real | 9 verificações aprovadas: organização efetiva, composição, autoria final e pessoas preservadas. Logo/metadados de fixture e filtros nas prioridades 25/30; não é homologação dos temas reais. |
| Lotes da verificação pública | 5 verificações aprovadas com HTTP controlado pela API WP e banco/CAS reais: limite, continuação, consulta sem HTTP, descarte do HTML e mudança de contexto. |
| Google, fontes e minificados | 20 verificações aprovadas em JavaScript executado em plataforma controlada: prazo, interação, revogação com Ads permitido, reaceite, idempotência, entrada tardia, GTM e ausência de destino. Não mede rede nem recebimento por Google. |
| PHPStan | Sem erros. |
| PHPCS/WPCS | Zero violações novas contra a baseline original, que não foi ampliada. As violações históricas permanecem explicitadas no JSON. |
| Suíte principal | 169 linhas OK, 0 WARN, 1 BLOCKED, 4 FALHA e 12 N/A. Rodada reprovada; nenhum selo de liberação foi fabricado. |
| Piso dos detectores | Rodada original: 186 OK e 7 FALHA. Três casos de teste corrigidos e aprovados em retestes dirigidos; quatro casos dependem do Chromium. Detalhes abaixo. |
| Reprodução dos pacotes | Aprovada: integridade por SHA-256, fontes independentes de mtime/resíduos e reconstrução do instalador com bytes idênticos após extrair o ZIP de fontes. |

Os quatro casos em FALHA são `wp.whatsapp_flutuante`, `wp.politica_opcional`,
`wp.ux_configuracao` e `wp.ux_medicao`: não conseguiram iniciar Chromium. A sonda
`navegador.comportamento_real` também ficou BLOCKED. O download do navegador gerenciado falhou;
um binário alternativo obtido do distribuidor não iniciou porque a abertura de socket foi
recusada pelo ambiente (`Operation not permitted`). Isso não foi convertido em aprovação.

O piso completo usou adicionalmente o WordPress 7.1.2 disponível no cache da bancada,
sob PHP 8.3.6; a rodada original e sua execução sem mutações foram preservadas. Foram corrigidos
somente os materiais de teste: a fixture de JavaScript precisava do quarto asset previsto pelo
build, e os patches de `debug_log_limpo` e `desinstalacao_limpa` precisavam do contexto atual.
Os três pares positivo/negativo passaram no reteste (os dois de WordPress sob 6.9).
O reteste não substitui nem reclassifica retroativamente o log original. Nos quatro casos que
exigem navegador, uma falha da variante defeituosa também não comprova que o detector reconheceu
o defeito: a falta de Chromium bloqueia ambos os ramos. A rodada integral permanece reprovada.

Logs e resultados estão em `suite/versao-1102/evidencias/`. Resultados históricos de outras
versões são mantidos nos diretórios originais e não contam como testes desta candidata.

## Homologação remota — 24/09/2026

Ambiente autorizado: `https://fator3-teste-mcp-1.dreamhosters.com`. Instalado o mesmo ZIP
de 579.006 bytes identificado acima, com ativação solicitada pelo instalador. A versão ativa
foi confirmada pelo catálogo de plugins, pela saúde do Core e pelo título do painel.
Não se atribui a este ensaio remoto a condição de upgrade sem reativação da bancada local.

WordPress 7.1.2, PHP 8.3.30, tema F3 Base 1.6.3, Yoast 28.5 e WP Super Cache 3.1.3.
As versões dos demais plugins foram preservadas. O levantamento prévio guardou as configurações
consultáveis e a saúde; não substitui backup integral do banco e dos arquivos.

| Verificação remota | Resultado |
|---|---|
| Preservação no upgrade | As 16 revisões consultadas permaneceram iguais imediatamente após instalar. O llms ganhou somente padrões na leitura normalizada, sem alteração da revisão persistida. |
| Schema publicado | `verified` na home (1 bloco, 10 nós) e em um artigo (1 bloco, 15 nós); logo respondeu 200. Inspeção do Core sobre HTML/recursos, sem aprovação pelo Rich Results Test. |
| llms dinâmico | GET 200, 2.251 bytes, `text/plain; charset=utf-8`, `no-cache, max-age=0, must-revalidate`; HEAD 200 sem corpo. |
| llms-full | GET 200, 56.495 bytes, texto UTF-8 e revalidação exigida. |
| robots | GET 200, arquivo gerenciado com sitemap do Yoast. A hospedagem envia `max-age=172800`; não foi alterado e pode conservar conteúdo antigo por dois dias. |
| llms físico temporário | Arquivo próprio de 2.251 bytes, modo 0644; duas gerações preservaram SHA-256 e mtime. GET/HEAD 200. Prova ficou `pending`: cache de dois dias e resposta condicional 200, sem confirmar 304. |
| Retirada do llms físico | Preferências originais restauradas; arquivo próprio removido e agendamento desativado. GET dinâmico novamente 200, mesmo conteúdo e cache com revalidação. |
| Painel desktop | Título 1.10.2, quatro formulários/seções, sem overflow horizontal em viewport de 1.363 px; ajuda abriu pelo teclado. |
| Salvamento por seção | Alteração de contato persistiu, enquanto retenção editada em outra seção permaneceu em 12 meses. Valor temporário de contato restaurado pelo contrato com revisão. |
| Consentimento | Controle do rodapé abriu o painel; “Desligar medição” fechou e devolveu o foco. Persistência após reload e envio de eventos não verificados. |

Após esses ensaios, o navegador remoto passou a exibir `502 Bad Gateway / [Errno 111]
Connection refused` tanto na home quanto no painel. Uma tentativa de recuperação não resolveu.
O conector WordPress e as verificações HTTP iniciadas pelo servidor continuaram funcionando;
isso não comprova indisponibilidade geral do site nem bloqueio por detecção de robô. A captura
`evidencias/homologacao-navegador-bloqueio.jpg` documenta a limitação. Os resultados parciais
não reclassificam os gates locais que continuaram bloqueados.

A lista configurada de opções operáveis do site não inclui `f3base_google_carregamento` nem
`f3base_seo_entidade`. O contrato as descreve, mas impede edição no painel/ability. A lista não
foi ampliada. Google permanece no padrão imediato; o site não tem IDs de GA4/Ads/GTM para
validar recebimento real. O WordPress não disponibilizou `debug.log`, portanto não há prova
remota de ausência de avisos PHP.

Ao final, as 16 preferências normalizadas consultadas coincidem com as originais. A restauração
de llms gravou explicitamente os novos campos padrão e mudou sua revisão. A auditoria de contato
e llms registra os ensaios/restaurações; os demais históricos não foram reatribuídos. Após a
limpeza solicitada ao provedor, a verificação assíncrona confirmou os cabeçalhos públicos da
geração atual (`cabecalhos_comprovados`). A última consulta não apresentou módulos degradados.

Evidências: `evidencias/homologacao-remota.json` e `evidencias/homologacao-ui.json`.
Nenhuma mudança adicional no código de execução foi necessária nesta etapa; o instalador e
seu SHA-256 permanecem idênticos. O pacote de fontes foi atualizado com este relatório e as provas.

## Pendências antes de liberar e ativar os novos modos

1. Reexecutar os gates em Chromium funcional: painel, consentimento/CSP, teclado, BFCache,
   primeira conversão, saída rápida, rede lenta e script bloqueado. Confirmar GA4/Ads reais,
   sequência, engajamento e perdas aceitáveis por site.
2. Validar os temas integrais citados no plano e suas prioridades. O helper de autoria exige
   adoção pelo tema; o Core não altera seus templates. Confirmar IDs das organizações relacionadas,
   relações e conteúdo no HTML final. Executar Rich Results Test/validador aplicáveis.
3. Ajustar a entrega HTTP antes de adotar llms físico nesta hospedagem: exigir revalidação,
   confirmar GET/HEAD/304 e diretivas de indexação. Geração, estabilidade e retirada passaram;
   cache/304 não passaram. Concorrência e revogação de acesso em todos os cenários ainda exigem
   ensaio. O Core não instala regras do servidor. Ambientes com restrição dinâmica devem conservar
   o modo dinâmico.
4. Medir PageSpeed e TTFB quente/frio/BYPASS em cenários pareados. Não foi demonstrado ganho
   de nota, TTFB inferior a um segundo nem melhoria universal. O perfil administrativo mede
   etapas PHP e não separa sozinho latência de rede ou todos os custos de plugins/servidor.
5. Completar a matriz de WordPress/PHP/Yoast e os testes de concorrência sob a hospedagem real.
   A amostra remota acima amplia a cobertura, mas não comprova todos os cenários R06/R11/R16.
6. Para editar Google/SEO neste site, o responsável pela implantação precisa revisar explicitamente
   a lista de opções operáveis. A release preserva o limite de acesso configurado.

## Atualização e recuperação

Faça backup consistente de arquivos/banco e preserve a fila CAPI. Instale primeiro em cópia de
homologação. Google permanece imediato e llms permanece dinâmico enquanto não houver escolha
explícita. Publicar o pacote não muda automaticamente essas preferências.

Rollback de código depende de compatibilidade com estados persistidos. Não executar consumidor
1.9.2 sobre a fila convertida; token vazio não comprova pausa. Não desinstalar para fazer rollback.
Restaurar banco antigo pode perder leads e ressuscitar conversões, exigindo reconciliação.
