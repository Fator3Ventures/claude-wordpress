<?php
/** HTTP determinístico via API WP; banco e CAS reais. Nunca acessa os destinos da fixture. */
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110'))exit(2);
require $site.'/wp-load.php';wp_set_current_user(1);
$antes=get_option('home');$home=static fn($url)=>str_replace('http://127.0.0.1:18110','https://8.8.8.8',$url);add_filter('home_url',$home);
$testes=[];$http=0;
$urls=[];for($i=0;$i<25;$i++)$urls[]='https://8.8.8.8/perfil-'.$i;
$html='<script type="application/ld+json">'.wp_json_encode(['@context'=>'https://schema.org','@type'=>'Organization','@id'=>'https://8.8.8.8/#org','name'=>'Fixture','url'=>'https://8.8.8.8/','sameAs'=>$urls,'logo'=>'https://8.8.8.8/logo.png']).'</script>';
$mock=static function($pre,$args,$url)use(&$http,$html){$http++;return ['headers'=>[],'body'=>$url==='https://8.8.8.8/'?$html:'fixture','response'=>['code'=>200,'message'=>'OK'],'cookies'=>[]];};
add_filter('pre_http_request',$mock,10,3);
$r=F3Base_Schema_Verificacao::verificar(['https://8.8.8.8/'],F3Base_Options::revisao('f3base_seo_entidade'));
$e=F3Base_Options::fotografia(F3Base_Schema_Verificacao::ESTADO)['valor'];
$testes['lote_limitado_e_retomavel']=isset($e['trabalho']['id'])&&$http===21&&$r['status']==='pendente';
$antesConsulta=$http;F3Base_Schema_Verificacao::consultar();$testes['consulta_sem_http']=$http===$antesConsulta;
$r=F3Base_Schema_Verificacao::continuar($e['trabalho']['id']);
$testes['continua_sem_repetir_paginas']=$http===27&&!isset(F3Base_Options::fotografia(F3Base_Schema_Verificacao::ESTADO)['valor']['trabalho'])&&$r['status']==='inconclusivo';
$testes['nao_persiste_html']=!str_contains(wp_json_encode(F3Base_Options::fotografia(F3Base_Schema_Verificacao::ESTADO)['valor']),'<script');
$r=F3Base_Schema_Verificacao::verificar(['https://8.8.8.8/'],F3Base_Options::revisao('f3base_seo_entidade'));$e=F3Base_Options::fotografia(F3Base_Schema_Verificacao::ESTADO)['valor'];
$c=F3Base_Options::ler('f3base_seo_entidade');$c['descricao']='Mudou durante a prova';F3Base_Options::gravar('f3base_seo_entidade',$c);$inicio=$http;
$r=F3Base_Schema_Verificacao::continuar($e['trabalho']['id']);$testes['contexto_alterado_nao_verifica']=$r['status']==='desatualizado'&&$http===$inicio;
remove_filter('pre_http_request',$mock,10);remove_filter('home_url',$home);
echo wp_json_encode(['testes'=>$testes,'falhas'=>array_keys(array_filter($testes,static fn($v)=>!$v))],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit(in_array(false,$testes,true)?1:0);
