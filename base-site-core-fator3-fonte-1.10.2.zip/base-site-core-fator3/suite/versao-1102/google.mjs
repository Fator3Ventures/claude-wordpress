/** Código entregue executado em plataforma controlada; não simula a rede do Google. */
import { readFileSync } from 'node:fs';
import { bancadaDeComportamento } from '../checagens/js.mjs';
const raiz = process.argv[2] || process.cwd();
const resultados = {};
function checar(nome, ok) { resultados[nome] = !!ok; }
function bancada(extensao = '.js', config = {}, extras = {}) {
 const scripts = [], timers = new Map(), permissoes = {medicao:true, publicidade:true, uso:true};
 let doc, win, od, ow, seq = 0;
 const dados = {caminho:'direto',ga4:'G-TESTE',ads:{id:'AW-123456'},origemGoogle:'https://www.googletagmanager.com/',googleCarregamento:{modo:'apos_interacao',teto_segundos:5}, ...config};
 const b = bancadaDeComportamento(readFileSync(raiz+'/fontes/plugin/assets/f3base-tracking'+extensao,'utf8'), dados, {readyState:'complete',preparar(w,d,a,o){
  win=w;doc=d;od=a;ow=o;
  w.removeEventListener=(nome,fn)=>{o[nome]=(o[nome]||[]).filter(x=>x!==fn);};
  d.removeEventListener=(nome,fn)=>{a[nome]=(a[nome]||[]).filter(x=>x!==fn);};
  d.getElementById=id=>scripts.find(s=>s.id===id)||null;
  d.head.appendChild=s=>{scripts.push(s);return s;};
  w.setTimeout=(fn,ms)=>{timers.set(++seq,{fn,ms});return seq;};w.clearTimeout=id=>timers.delete(id);
  w.performance.now=()=>extras.agora||100;
  w.performance.getEntriesByType=tipo=>tipo==='navigation'?[{responseStart:50,loadEventEnd:extras.load||0}]:[];
  w.f3baseConsentimento={permiteCategoria:c=>permissoes[c]===true,permiteTags:()=>permissoes.medicao,permiteGtm:()=>permissoes.medicao&&permissoes.publicidade};
  Object.assign(permissoes,extras.permissoes||{});
 }});
 return {...b,scripts,timers,win,doc,permissoes,gesto(nome='pointerdown'){for(const fn of [...(od[nome]||[])])fn({});},evento(nome){for(const fn of [...(ow[nome]||[])])fn({});},consentimento(valores){Object.assign(permissoes,valores);this.gesto('f3base-consentimento');},vencer(){for(const [id,t]of [...timers]){timers.delete(id);t.fn();}}};
}
for (const ext of ['.js','.min.js']) {
 let b=bancada(ext);checar(ext+' aguarda',b.scripts.length===0&&b.gtagChamadas.length===0&&[...b.timers.values()][0].ms<=5000);
 b.win.dataLayer.push({event:'terceiro'});b.win.f3baseGoogleEnviar('medicao',['event','antigo']);
 b.consentimento({medicao:false});b.gesto();
 checar(ext+' revogacao com Ads',b.scripts.length===1&&b.gtagChamadas.some(x=>x[0]==='config'&&x[1]==='AW-123456')&&!b.gtagChamadas.some(x=>x[1]==='G-TESTE'||x[1]==='antigo')&&b.win.dataLayer[0].event==='terceiro');
 b.consentimento({medicao:true});b.gesto('mousemove');b.win.f3baseTracking.carregar();
 checar(ext+' idempotencia',b.scripts.length===1&&b.gtagChamadas.filter(x=>x[0]==='js').length===1&&b.gtagChamadas.filter(x=>x[0]==='config'&&x[1]==='G-TESTE').length===1&&!b.gtagChamadas.some(x=>x[1]==='antigo'));
 b=bancada(ext);b.win.f3baseGoogleEnviar('medicao',['event','generate_lead',{method:'whatsapp'}]);b.vencer();
 checar(ext+' teto e fila',b.scripts.length===1&&b.gtagChamadas.filter(x=>x[1]==='generate_lead').length===1);
 b=bancada(ext,{}, {permissoes:{medicao:false,publicidade:false}});b.vencer();checar(ext+' prazo nao concede',b.scripts.length===0);b.consentimento({medicao:true});checar(ext+' aceite depois teto',b.scripts.length===1);
 b=bancada(ext,{}, {agora:9000,load:1000});checar(ext+' inicializacao tardia',b.scripts.length===1);
 b=bancada(ext,{googleCarregamento:{modo:'imediato',teto_segundos:5}});checar(ext+' padrao imediato',b.scripts.length===1);
 b=bancada(ext,{caminho:'gtm',gtm:'GTM-TESTE'});checar(ext+' GTM independente',b.scripts.length===1&&b.scripts[0].id==='f3base-gtm');
 b=bancada(ext,{ga4:'',ads:{id:''}});b.gesto();checar(ext+' sem destino',b.scripts.length===0);
}
console.log(JSON.stringify({testes:resultados,falhas:Object.keys(resultados).filter(k=>!resultados[k])},null,2));
process.exit(Object.values(resultados).every(Boolean)?0:1);
