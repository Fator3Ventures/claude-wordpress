# Candidata Base Site Core Fator3 1.10.2

Consulte `RELATORIO-HOMOLOGACAO.md` para evidências e bloqueios de liberação; este diretório não
transforma resultados históricos em aprovação atual. Manual estável: `docs/OPERACAO.md` na raiz.

Na bancada descartável preparada por `suite/versao-110/preparar-bancada.sh`:

```sh
F3BASE_SITE=/caminho/wordpress php suite/versao-1102/regressao.php
F3BASE_SITE=/caminho/wordpress php suite/versao-1102/schema-lotes.php
node suite/versao-1102/google.mjs "$PWD"
```

Esses testes alteram somente a bancada marcada. O teste de lotes usa respostas HTTP controladas
através da API do WordPress; não consulta perfis reais. Os testes de Google executam o JavaScript
legível e minificado em plataforma controlada e não comprovam recebimento por GA4/Ads.
