"""Confere que A4 altera apenas versão/empacotamento do canal, com PHP real."""
import argparse, hashlib, json, subprocess, zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('anterior',type=Path);p.add_argument('novo',type=Path);p.add_argument('--php',default='php');p.add_argument('--out',type=Path,required=True);a=p.parse_args()
r={'versao':'0.12.1-rc.2','arquivos_php_analisados':0,'php_funcional_inalterado':0,'novo_codigo':[],'sha256':hashlib.sha256(a.novo.read_bytes()).hexdigest()}
with zipfile.ZipFile(a.anterior) as antes,zipfile.ZipFile(a.novo) as depois:
    for name in depois.namelist():
        if not name.endswith('.php'):continue
        data=depois.read(name)
        lint=subprocess.run([a.php,'-l'],input=data,capture_output=True)
        assert lint.returncode==0,(name,lint.stdout,lint.stderr)
        r['arquivos_php_analisados']+=1
        if name in antes.namelist():
            assert data.replace(b'0.12.1-rc.2',b'0.12.1-rc.1')==antes.read(name),name
            r['php_funcional_inalterado']+=1
        else:
            assert data==b'<?php\n// Silence is golden.\n',name
            r['novo_codigo'].append(name)
a.out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='novo_codigo'}))
