<?php
/** Testes da evolução: núcleo, SQLite, HTTP e dados sintéticos conhecidos. */
declare( strict_types = 1 );
function f3b_e_exige( bool $ok, string $motivo ): void { if ( ! $ok ) { throw new RuntimeException( $motivo ); } }
function f3b_e_log( string $ua, string $caminho, int $status = 200, string $metodo = 'GET' ): string {
	$data = ( new DateTimeImmutable( 'yesterday 12:00:00', wp_timezone() ) )->format( 'd/M/Y:H:i:s O' );
	return '192.0.2.9 - - [' . $data . '] "' . $metodo . ' ' . $caminho . ' HTTP/1.1" ' . $status . ' 42 "https://exemplo.test/referer-privado" "' . $ua . '"' . "\n";
}
function f3b_e_fixture(): array {
	global $wpdb;
	f3b_e_exige( class_exists( 'F3Base_Modulo_Acessos_Servidor' ), 'Módulo acessos-servidor ausente.' );
	$modulo = new F3Base_Modulo_Acessos_Servidor();
	f3b_e_exige( $modulo->garantir_estrutura(), 'Tabela de acessos não criada.' );
	$wpdb->query( 'DELETE FROM ' . $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA );
	F3Base_Options::remover( 'f3base_acessos_estado' );
	$dir = get_temp_dir() . 'f3base-evolucao-' . wp_generate_uuid4(); mkdir( $dir );
	$antes = F3Base_Options::ler( 'f3base_acessos' );
	F3Base_Options::gravar( 'f3base_acessos', array( 'ligado' => true, 'padrao_do_log' => $dir . '/access.log.*' ) );
	register_shutdown_function( static function () use ( $dir, $antes ) { foreach ( (array) glob( $dir . '/*' ) as $p ) { if ( is_file( $p ) || is_link( $p ) ) { unlink( $p ); } } rmdir( $dir ); F3Base_Options::gravar( 'f3base_acessos', $antes ); } );
	$dia = ( new DateTimeImmutable( wp_date( 'Y-m-d' ) ) )->modify( '-1 day' )->format( 'Y-m-d' );
	$arquivo = $dir . '/access.log.' . $dia;
	$log = str_repeat( f3b_e_log( 'Googlebot', '/pagina-a/' ), 3 )
		. str_repeat( f3b_e_log( 'GPTBot', '/llms-full.txt' ), 2 )
		. str_repeat( f3b_e_log( 'Claude-User', '/wp-json/mcp/x' ), 5 )
		. str_repeat( f3b_e_log( 'Chrome', '/pagina-a/?email=nao-gravar' ), 4 )
		. f3b_e_log( 'HeadlessChrome', '/pagina-a/' )
		. str_repeat( f3b_e_log( 'Chrome', '/wp-content/x.css' ), 10 )
		. str_repeat( f3b_e_log( 'python-requests', '/scan/', 404 ), 3 );
	file_put_contents( $arquivo, $log );
	return array( $modulo, $arquivo, $dia, $log, $dir );
}
function f3b_e_rows(): array {
	global $wpdb;
	return (array) $wpdb->get_results( 'SELECT * FROM ' . $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA . ' ORDER BY dia,agente,classe_caminho,caminho,status,metodo', ARRAY_A );
}
function f3b_e_acessos_somados(): array {
	global $wpdb;
	[ $m ] = f3b_e_fixture(); $e = $m->somar();
	f3b_e_exige( empty( $e['erro'] ), 'Soma falhou: ' . ( $e['erro'] ?? '' ) );
	$rows = f3b_e_rows();
	f3b_e_exige( count( $rows ) === 7 && array_sum( array_column( $rows, 'contagem' ) ) === 28, 'Esperadas sete linhas e vinte e oito requisições: ' . wp_json_encode( $rows ) );
	$esperadas = array( 'googlebot' => array( 'pagina', '/pagina-a/', 3 ), 'gptbot' => array( 'descoberta', '/llms-full.txt', 2 ), 'claude-user' => array( 'excluido', '', 5 ) );
	foreach ( $rows as $r ) {
		if ( isset( $esperadas[ $r['agente'] ] ) ) { f3b_e_exige( array( $r['classe_caminho'], $r['caminho'], (int) $r['contagem'] ) === $esperadas[ $r['agente'] ], 'Classe/caminho/contagem errados para ' . $r['agente'] ); }
		f3b_e_exige( ! str_contains( $r['caminho'], '?' ), 'Query foi persistida.' );
	}
	f3b_e_exige( F3Base_Modulo_Acessos_Servidor::agente( 'Googlebot-Image' )[0] === 'googlebot-image', 'Googlebot-Image perdeu precedência.' );
	f3b_e_exige( F3Base_Modulo_Acessos_Servidor::agente( 'HeadlessChrome' )[0] === 'robo-generico', 'HeadlessChrome contado como humano.' );
	$colunas = $wpdb->get_col( 'SHOW COLUMNS FROM ' . $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA );
	f3b_e_exige( $colunas === array( 'dia','agente','classe_caminho','caminho','status','metodo','contagem' ), 'Colunas inesperadas no agregado.' );
	return array( 'OK', 'Contagens, famílias, ordem, classes e sete colunas conferidas; sem IP, referer ou agente bruto.' );
}
function f3b_e_acessos_dia_substituido(): array {
	[ $m, $f, $d, $log, $dir ] = f3b_e_fixture();
	copy( $f, $dir . '/access.log.0' ); copy( $f, $dir . '/access.log.' . wp_date( 'Y-m-d' ) );
	$m->somar(); $antes = f3b_e_rows(); $m->somar(); f3b_e_exige( $antes === f3b_e_rows(), 'Repetição somou em dobro.' );
	file_put_contents( $f, $log . f3b_e_log( 'Googlebot', '/pagina-a/' ) ); clearstatcache();
	$m->somar(); f3b_e_exige( array_sum( array_column( f3b_e_rows(), 'contagem' ) ) === 29, 'Arquivo alterado não substituiu o dia ou .0/hoje entrou na contagem.' );
	return array( 'OK', 'Reprocessamento idempotente, substituição após mudança e exclusão de .0 e dia corrente.' );
}
function f3b_e_acessos_sem_log_degradado(): array {
	[ $m, $f ] = f3b_e_fixture(); unlink( $f ); $e = $m->somar();
	f3b_e_exige( ! f3b_e_rows() && str_contains( $e['erro'], 'pastas vistas' ) && ( new F3Base_Modulo_Acessos_Servidor() )->estado()['estado'] === F3Base_Modulo::DEGRADADO, 'Pasta vazia não gerou diagnóstico degradado com diretórios.' );
	return array( 'OK', 'Sem log: degradado, padrão e pastas nomeados, nenhuma linha gravada.' );
}
function f3b_e_acessos_formato_desconhecido(): array {
	[ $m, $f ] = f3b_e_fixture(); $m->somar(); $antes = f3b_e_rows();
	file_put_contents( $f, "invalida\ninvalida\n" . f3b_e_log( 'Chrome', '/perdida/' ) ); clearstatcache(); $e = $m->somar();
	f3b_e_exige( $antes === f3b_e_rows() && str_contains( $e['erro'], '2 de 3' ) && str_contains( $e['erro'], basename( $f ) ), 'Formato inválido sobrescreveu dados ou perdeu diagnóstico medido.' );
	return array( 'OK', 'Maioria inválida preserva dia anterior e informa duas de três linhas ignoradas.' );
}
function f3b_e_acessos_limites(): array {
	global $wpdb;
	[ $m, $f, $dia, , $dir ] = f3b_e_fixture();
	$log = ''; for ( $i = 0; $i < 760; ++$i ) { $log .= f3b_e_log( 'scannerbot', '/scanner-' . $i, 404 ); }
	file_put_contents( $f, $log ); clearstatcache(); $m->somar();
	$rows = f3b_e_rows(); $outro = array_values( array_filter( $rows, static fn( $r ) => 'outro' === $r['classe_caminho'] ) );
	f3b_e_exige( count( $rows ) === 751 && count( $outro ) === 1 && (int) $outro[0]['contagem'] === 10 && '' === $outro[0]['caminho'], 'Teto de caminhos não preservou o excedente.' );
	foreach ( array( '/wp-admin','/wp-json/mcp','/wp-admin%2Findex.php','/?rest_route=%2Fmcp%2Fx' ) as $p ) { f3b_e_exige( F3Base_Modulo_Acessos_Servidor::caminho( $p, F3Base_Modulo_Acessos_Servidor::EXCLUIDOS )[0] === 'excluido', 'Rota administrativa escapou: ' . $p ); }
	$home = get_option( 'home' ); $trocar_home = static fn() => $home . '/sub'; add_filter( 'pre_option_home', $trocar_home );
	try { f3b_e_exige( F3Base_Modulo_Acessos_Servidor::caminho( '/sub/wp-admin/', F3Base_Modulo_Acessos_Servidor::EXCLUIDOS )[0] === 'excluido', 'Subdiretório escapou.' ); }
	finally { remove_filter( 'pre_option_home', $trocar_home ); }
	// Duas pastas de domínio não podem produzir uma estatística misturada.
	$vizinho = $dir . '-outro'; mkdir( $vizinho ); copy( $f, $vizinho . '/access.log.' . $dia );
	$recusou = false;
	try { F3Base_Modulo_Acessos_Servidor::arquivos( $dir . '*/access.log.*' ); }
	catch ( RuntimeException $e ) { $recusou = str_contains( $e->getMessage(), 'múltiplos diretórios' ); }
	finally { unlink( $vizinho . '/access.log.' . $dia ); rmdir( $vizinho ); }
	f3b_e_exige( $recusou, 'Padrão que mistura domínios foi aceito.' );
	// Falha SQL depois do DELETE precisa reverter o dia inteiro e seu checkpoint.
	$antes = f3b_e_rows(); $checkpoint = F3Base_Options::ler( 'f3base_acessos_estado' )['dias'];
	file_put_contents( $f, f3b_e_log( 'Chrome', '/nova/' ) ); clearstatcache();
	$tabela = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
	foreach ( array( false, true ) as $excecao ) {
		$quebrar = static function ( $sql ) use ( $tabela, $excecao ) {
			if ( ! str_starts_with( $sql, 'INSERT INTO ' . $tabela . ' ' ) ) { return $sql; }
			if ( $excecao ) { throw new RuntimeException( 'Exceção deliberada antes do INSERT.' ); }
			return str_replace( 'INSERT INTO ' . $tabela . ' ', 'INSERT INTO f3base_tabela_inexistente ', $sql );
		};
		$suprimido = $wpdb->suppress_errors( true ); add_filter( 'query', $quebrar );
		try { $falha = $m->somar(); }
		finally { remove_filter( 'query', $quebrar ); $wpdb->suppress_errors( $suprimido ); }
		// O driver SQLite pode reverter automaticamente um erro SQL; a exceção
		// anterior ao INSERT prova também o ROLLBACK explícito do plugin.
		f3b_e_exige( $antes === f3b_e_rows() && $checkpoint === $falha['dias'] && str_contains( $falha['erro'], $excecao ? 'Exceção deliberada' : 'Banco' ), 'Falha de escrita perdeu dados/checkpoint ou não foi relatada.' );
	}
	// Calendário fixo: fim de março menos um mês cai em fevereiro, sem transbordar.
	$relogio = static fn( $data, $formato ) => 'Y-m-d' === $formato ? '2026-03-31' : $data;
	add_filter( 'wp_date', $relogio, 10, 2 );
	try { f3b_e_exige( F3Base_Modulo_Acessos_Servidor::corte( 1 ) === '2026-02-28' && F3Base_Modulo_Acessos_Servidor::dia_anterior() === '2026-03-30', 'Corte mensal ou dia anterior transbordou o calendário.' ); }
	finally { remove_filter( 'wp_date', $relogio ); }
	// Um dia fora da retenção é eliminado; o dia recente continua sendo substituído.
	$antigo = ( new DateTimeImmutable( wp_date( 'Y-m-d' ) ) )->modify( '-2 months' )->format( 'Y-m-d' );
	$wpdb->insert( $tabela, array( 'dia' => $antigo, 'agente' => 'humano', 'classe_caminho' => 'pagina', 'caminho' => '/antiga/', 'status' => 200, 'metodo' => 'GET', 'contagem' => 1 ) );
	$config = F3Base_Options::ler( 'f3base_acessos' ); $config['retencao_meses'] = 1;
	F3Base_Options::gravar( 'f3base_acessos', $config ); $m->somar();
	$rows = f3b_e_rows(); f3b_e_exige( count( $rows ) === 1 && $rows[0]['dia'] === $dia && $rows[0]['caminho'] === '/nova/', 'Retenção perdeu o dia recente ou manteve o expirado.' );
	return array( 'OK', 'Teto, exclusões, isolamento de domínios, rollback SQL, calendário e retenção conferidos.' );
}
function f3b_e_acessos_atualizacao_sem_reativar(): array {
	f3b_e_exige( '1' === getenv( 'F3BASE_ATUALIZACAO_REAL' ), 'Este passo exige a instalação anterior real preparada por atualizacao.sh.' );
	f3b_e_exige( class_exists( 'F3Base_Modulo_Acessos_Servidor' ), 'Atualização não carregou o módulo novo.' );
	$res = f3b_bancada_get( '/' ); wp_cache_flush();
	f3b_e_exige( 200 === $res['codigo'] && wp_next_scheduled( F3Base_Modulo_Acessos_Servidor::EVENTO ) && wp_next_scheduled( F3Base_Modulo_Acessos_Servidor::CONTINUAR ) && ( ! F3Base_Modulo_Acessos_Servidor::tabela_pronta() || ! f3b_e_rows() ), 'Home sem reativação não criou agenda ou fez coleta bloqueante.' );
	do_action( F3Base_Modulo_Acessos_Servidor::CONTINUAR );
	f3b_e_exige( F3Base_Modulo_Acessos_Servidor::tabela_pronta() && count( f3b_e_rows() ) === 2 && array_sum( array_column( f3b_e_rows(), 'contagem' ) ) === 3, 'Worker agendado não produziu os dados de dois dias sem reativação.' );
	f3b_e_exige( ! file_exists( getenv( 'F3BASE_BANCADA_TMP' ) . '/ativacao-nova.txt' ), 'Houve ativação depois da troca dos arquivos.' );
	return array( 'OK', 'ZIP anterior instalado e ativo, arquivos substituídos pelo ZIP novo e home chamada: cron na home e estrutura/dois dias somados pelo worker, sem reativação.' );
}
function f3b_e_acessos_lidos_pela_habilidade(): array {
	[ $m ] = f3b_e_fixture(); $m->somar();
	$a = wp_get_ability( 'f3base/acessos-ler' ); f3b_e_exige( is_object( $a ), 'Habilidade ausente.' );
	wp_set_current_user( 0 ); f3b_e_exige( is_wp_error( $a->execute( array( 'dias' => 7 ) ) ), 'Anônimo teve acesso.' );
	wp_set_current_user( 1 ); $r = $a->execute( array( 'dias' => 7 ) );
	f3b_e_exige( ! is_wp_error( $r ) && count( $r['linhas'] ) === 6 && $r['totais']['excluido'] === 15, 'Leitura válida não retornou agregados: ' . wp_json_encode( $r ) );
	f3b_e_exige( is_wp_error( $a->execute( array( 'desconhecida' => 1 ) ) ) && is_wp_error( $a->execute( array( 'dias' => 91 ) ) ), 'Schema aceitou entrada inválida.' );
	$r = $a->execute( array( 'dias' => 7, 'incluir_erros' => true ) ); f3b_e_exige( count( $r['linhas'] ) === 7, 'Filtro de erros não inclui scanner.' );
	return array( 'OK', 'Habilidade executada pelo núcleo: autorização, schema, rodapé, filtro de status e saída válidos.' );
}
function f3b_e_tela_acessos(): array {
	require_once ABSPATH . 'wp-admin/includes/template.php';
	[ $m ] = f3b_e_fixture(); $m->somar(); wp_set_current_user( 1 ); $_GET['aba'] = 'acessos'; $_GET['mostrar_todos'] = '1';
	ob_start(); F3Base_Admin_Medicao::render(); $html = ob_get_clean();
	foreach ( array( 'declaração falsificável','Humanos estimados','Pessoas medidas','Cobertura por dia','/pagina-a/','Busca' ) as $frase ) { f3b_e_exige( str_contains( $html, $frase ), 'Tela não contém: ' . $frase ); }
	$x = f3b_c_dom( $html );
	f3b_e_exige( f3b_a_celula( $x, '/pagina-a/', 'Busca' ) === '3' && f3b_a_celula( $x, '/pagina-a/', 'Humanos estimados' ) === '4', 'Tela perdeu contagens das famílias medidas.' );
	return array( 'OK', 'Tela contém páginas, famílias, cobertura, aviso de identidade e métricas distintas.' );
}
function f3b_e_sessao_http(): array {
	f3b_e_exige( class_exists( 'F3Base_Modulo_Sessao_De_Login' ), 'Módulo de sessão ausente.' );
	foreach ( array( 90, 2 ) as $dias ) {
		F3Base_Options::gravar( 'f3base_sessao', array( 'ligado' => true, 'dias' => $dias ) );
		foreach ( array( true, false ) as $lembrar ) { f3b_e_exige( apply_filters( 'auth_cookie_expiration', ( $lembrar ? 14 : 2 ) * DAY_IN_SECONDS, 1, $lembrar ) === $dias * DAY_IN_SECONDS, 'O filtro deixou uma das formas de login com o prazo do núcleo.' ); }
		$antes = time();
		$r = wp_remote_post( f3b_bancada_url( '/wp-login.php' ), array( 'redirection' => 0, 'body' => array( 'log' => 'admin', 'pwd' => 'admin' ) ) );
		f3b_e_exige( ! is_wp_error( $r ), 'Login HTTP falhou.' );
		$cookies = wp_remote_retrieve_cookies( $r ); $achou = false;
		foreach ( $cookies as $c ) {
			if ( ! str_starts_with( $c->name, 'wordpress_logged_in_' ) ) { continue; }
			$achou = true; $partes = explode( '|', urldecode( $c->value ) );
			f3b_e_exige( abs( (int) $c->expires - ( $antes + $dias * DAY_IN_SECONDS + 12 * HOUR_IN_SECONDS ) ) <= 10, 'Expires do cookie não corresponde ao prazo + doze horas.' );
			f3b_e_exige( abs( (int) $partes[1] - ( $antes + $dias * DAY_IN_SECONDS ) ) <= 10, 'Prazo assinado diverge.' );
			clean_user_cache( 1 ); wp_cache_delete( 1, 'user_meta' );
			$token = WP_Session_Tokens::get_instance( 1 )->get( $partes[2] );
			f3b_e_exige( $token && (int) $token['expiration'] === (int) $partes[1], 'Token do núcleo diverge do prazo assinado.' );
		}
		f3b_e_exige( $achou, 'Login sem rememberme não emitiu cookie persistente.' );
	}
	F3Base_Options::gravar( 'f3base_sessao', array( 'ligado' => false, 'dias' => 90 ) );
	$antes = time(); $r = wp_remote_post( f3b_bancada_url( '/wp-login.php' ), array( 'redirection' => 0, 'body' => array( 'log' => 'admin', 'pwd' => 'admin' ) ) );
	$achou = false;
	foreach ( wp_remote_retrieve_cookies( $r ) as $c ) {
		if ( ! str_starts_with( $c->name, 'wordpress_logged_in_' ) ) { continue; }
		$achou = true; $partes = explode( '|', urldecode( $c->value ) );
		f3b_e_exige( (int) $c->expires === 0 && abs( (int) $partes[1] - ( $antes + 2 * DAY_IN_SECONDS ) ) <= 10, 'Desligado, o login não voltou ao cookie de sessão e prazo do núcleo.' );
	}
	f3b_e_exige( $achou, 'Login de controle com o módulo desligado falhou.' );
	F3Base_Options::gravar( 'f3base_sessao', array( 'ligado' => true, 'dias' => 90 ) );
	return array( 'OK', 'Login HTTP sem Lembrar-me: cookies e tokens conferidos com noventa dias e dois dias; módulo desligado restaura o comportamento do núcleo.' );
}
function f3b_e_prazo_concorrente( $v ): int { return DAY_IN_SECONDS; }
function f3b_e_sessao_conflito(): array {
	F3Base_Options::gravar( 'f3base_sessao', array( 'ligado' => true, 'dias' => 90 ) ); wp_set_current_user( 1 );
	add_filter( 'auth_cookie_expiration', 'f3b_e_prazo_concorrente', 10000, 3 );
	try {
		$e = ( new F3Base_Modulo_Sessao_De_Login() )->estado();
		f3b_e_exige( F3Base_Modulo::DEGRADADO === $e['estado'] && str_contains( $e['motivo'], 'f3b_e_prazo_concorrente' ) && str_contains( $e['motivo'], '1 dias' ), 'Conflito não identificado pelo valor efetivo.' );
	} finally { remove_filter( 'auth_cookie_expiration', 'f3b_e_prazo_concorrente', 10000 ); }
	$e = ( new F3Base_Modulo_Sessao_De_Login() )->estado();
	f3b_e_exige( F3Base_Modulo::ATIVO === $e['estado'] && str_contains( $e['motivo'], 'Sair de todos os outros dispositivos' ), 'Prazo/remédio ausentes.' );
	$r = F3Base_Options::gravar( 'f3base_sessao', array( 'dias' => 0 ) ); f3b_e_exige( ! $r['ok'] && 90 === F3Base_Options::ler( 'f3base_sessao' )['dias'], 'Sanitizador alterou prazo inválido.' );
	$r = apply_filters( 'wp_login_form_defaults', array() ); f3b_e_exige( ! empty( $r['value_remember'] ), 'wp_login_form não marcou Lembrar-me.' );
	return array( 'OK', 'Prazo efetivo, callback concorrente, defaults do formulário e rejeição de duração inválida conferidos.' );
}
function f3b_e_llms_indice(): array {
	wp_insert_post( array( 'post_type' => 'page', 'post_title' => 'Evolução llms', 'post_status' => 'publish', 'post_content' => 'Texto integral da bancada evolucao.' ) );
	foreach ( array( true, false ) as $full ) {
		$c = F3Base_Options::ler( 'f3base_llms' ); $c['ligado'] = true; $c['full'] = $full; F3Base_Options::gravar( 'f3base_llms', $c );
		$r = f3b_bancada_get( '/llms.txt' ); f3b_e_exige( $r['codigo'] === 200, 'Índice não respondeu.' );
		f3b_e_exige( str_contains( $r['corpo'], '## Optional' ) === $full, 'Optional diverge da disponibilidade do texto integral.' );
		if ( $full ) {
			f3b_e_exige( str_contains( $r['corpo'], home_url( '/llms-full.txt' ) ), 'Link não usa home_url.' );
			$f = f3b_bancada_get( '/llms-full.txt' ); f3b_e_exige( $f['codigo'] === 200 && str_contains( $f['corpo'], 'Texto integral da bancada evolucao.' ), 'Destino do índice não serve o texto integral.' );
		}
	}
	return array( 'OK', 'HTTP: índice aponta o texto integral disponível e remove Optional quando desligado.' );
}
require_once __DIR__ . '/correcoes.php';
require_once __DIR__ . '/atuais.php';
require_once __DIR__ . '/publicacao.php';
require_once __DIR__ . '/robots-full.php';
require_once __DIR__ . '/robots-entrega.php';
require_once __DIR__ . '/interface-medicao.php';
require_once __DIR__ . '/filtro-acessos.php';
require_once __DIR__ . '/evolucao-160.php';
require_once __DIR__ . '/evolucao-170.php';
require_once __DIR__ . '/evolucao-180.php';
return array(
	'contrato_sem_avisos' => 'f3b_180_contrato',
	'ux_configuracao' => 'f3b_180_configuracao',
	'ux_medicao' => 'f3b_180_medicao',
	'configuracao_resultados' => 'f3b_170_resultados',
	'configuracao_contrato' => 'f3b_170_contrato',
	'configuracao_verificacao' => 'f3b_170_verificacao',
	'politica_opcional' => 'f3b_170_privacidade',
	'configuracao_confirmada' => 'f3b_160_options', 'capi_fila_persistente' => 'f3b_160_capi', 'cache_incremental' => 'f3b_160_cache', 'vitais_percentil' => 'f3b_160_vitais', 'whatsapp_flutuante' => 'f3b_160_whatsapp',
	'acessos_filtro_conteudo' => 'f3b_a_filtro',
	'interface_configuracoes' => 'f3b_i_configuracao', 'medicao_intervalos' => 'f3b_i_intervalos', 'medicao_orcamentos' => 'f3b_i_orcamentos',
	'robots_entrega' => 'f3b_re_entrega', 'robots_entrega_falhas' => 'f3b_re_falhas',
	'robots_troca' => 'f3b_rf_troca', 'robots_falhas' => 'f3b_rf_falhas', 'robots_ciclo' => 'f3b_rf_ciclo', 'llms_full_estruturado' => 'f3b_rf_full',
	'publicacao_llms' => 'f3b_p_llms', 'publicacao_markdown' => 'f3b_p_markdown', 'publicacao_robots' => 'f3b_p_robots',
	'acessos_atuais' => 'f3b_a_atuais', 'acessos_cron_diario' => 'f3b_a_cron',
	'home_generico' => 'f3b_c_home_generico',
	'configuracao_independente' => 'f3b_c_configuracao_independente', 'log_sem_www' => 'f3b_c_log_sem_www',
	'acessos_somados' => 'f3b_e_acessos_somados', 'acessos_dia_substituido' => 'f3b_e_acessos_dia_substituido',
	'acessos_sem_log_degradado' => 'f3b_e_acessos_sem_log_degradado', 'acessos_formato_desconhecido' => 'f3b_e_acessos_formato_desconhecido',
	'acessos_limites' => 'f3b_e_acessos_limites', 'acessos_atualizacao_sem_reativar' => 'f3b_e_acessos_atualizacao_sem_reativar',
	'acessos_lidos_pela_habilidade' => 'f3b_e_acessos_lidos_pela_habilidade', 'tela_acessos_por_pagina' => 'f3b_e_tela_acessos',
	'sessao_dura_o_declarado' => 'f3b_e_sessao_http', 'sessao_diz_quem_venceu' => 'f3b_e_sessao_conflito', 'llms_indice_aponta_texto_integral' => 'f3b_e_llms_indice',
);
