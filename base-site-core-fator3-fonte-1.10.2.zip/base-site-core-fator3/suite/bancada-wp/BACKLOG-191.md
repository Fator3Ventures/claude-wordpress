# Homologação da tabela A — Core 1.9.1 e WP MCP Fator3 0.12.1-rc.2

A referência é o `backlog.txt` recebido em 15/09/2026. A tabela B fica com o implantador. Não há implantação remota nesta entrega.

## Reproduzir

1. Execute `bash suite/verificar.sh "$PWD"` na raiz do Core com PHP, Node, zip, unzip, faketime e Chromium disponíveis. O diretório `F3BASE_BANCADA_CACHE` deve conter os ZIPs oficiais do WordPress e do SQLite, além de `wp-cli.phar`.
2. Monte uma bancada separada com `python3 suite/bancada-wp/servidor-190.py --work DIRETORIO_NOVO --zip dist/base-site-core-fator3-<versao-atual>.zip --cache INSUMOS --plugins INSUMOS --apache RUNTIME_APACHE --php-ini DIRETORIO_INI --prepare-only`. Os plugins de integração usados são WP Super Cache 3.1.3 e Yoast 28.4; a bancada usa WordPress 6.9. Em namespace com somente UID 0 mapeado, acrescente `--single-uid-namespace`.
3. Execute `python3 suite/bancada-wp/backlog-191.py DIRETORIO_NOVO --mcp CAMINHO/wp-mcp-fator3-0.12.1-rc.2.zip --baseline-core suite/referencias/releases/base-site-core-fator3-1.9.0.zip`. O processo inicia e encerra seu Apache local. Ele habilita `mod_expires` com 48 horas e `mod_autoindex` apenas no fixture. Nunca aponte a bancada a um site real.
4. Os resultados ficam em `resultado-191.json`. A prova usa HTTP real inclusive para as operações de teste do Core. Os negativos interceptam somente as respostas HTTP da sonda, dentro do WordPress real. Não usam stubs da API de options ou das Abilities.

Para reconstruir o pacote do canal: `python3 suite/bancada-wp/pacotes-191.py --source CAMINHO/fontes/wp-mcp-fator3 --out CAMINHO/wp-mcp-fator3-0.12.1-rc.2.zip`. Para auditar os dois instaladores, passe seus caminhos como argumentos posicionais ao mesmo script.

## Cobertura

- As duas opções de rastreamento são necessárias; somente chave, somente lista, `gclid` ausente e `ref` presente são recusados pelo diagnóstico.
- A configuração do WPSC é aplicada pelas operações do próprio provedor e relida em outro pedido. A consulta do Core não altera o arquivo do provedor. Exclusões adicionais do operador sobrevivem.
- A função real do WPSC retira `gclid` e `fbclid` da chave e de `$_GET`, preservando `ref` e `produto`. Duas URLs com identificadores de clique diferentes recebem a mesma geração de HTML cacheado.
- Upgrade pelo instalador do WordPress, partindo da 1.9.0, preserva preferência e remove o manual antigo. O Apache da bancada acrescenta `max-age=172800` e `Expires` futuro na versão antiga; isso desaparece na 1.9.1. Neste Apache as diretivas ficam combinadas em um campo; a multiplicidade de campos também é testada separadamente no transporte real do WordPress.
- GET de token por URL amigável, `rest_route` normal e codificado, além de comportamento. `Expires` passado, um `Cache-Control` com `no-store`, corpos diferentes.
- Falhas controladas: corpo repetido, ausência de `no-store`, duplicidade, expiração futura e token inválido. Rede indisponível e 429 ficam pendentes; não são sucesso. Corpo repetido degrada `endpoint-leads`.
- Contrato executado por `wp_get_ability`, validado e sanitizado pelo núcleo, sem avisos e sem disparar HTTP. A versão do contrato vem de `F3Base_Config_Contrato::VERSAO` e preserva o nome da habilidade v1.
- A sonda compartilha a prova da verificação de cabeçalhos, faz até seis GETs, não cria leads e mantém um único cron horário. A repetição imediata com o mesmo contexto usa o resultado já obtido.
- Índices de silêncio em todas as pastas, documentação excluída e acesso HTTP aos dados negado. Mutantes sem índice e com documento recolocado são detectados. A conferência HTTP observa o corpo, inclusive respostas 200 vazias, com autoindex ativo na bancada.
- Canal carrega no WordPress sem seus documentos. Comparação com rc.1 comprova que os 117 PHP preexistentes mantêm seu código, exceto o número da versão; os 48 PHP novos são exclusivamente índices de silêncio.

## Limites da conclusão

A prova de presença de exclusões é literal: uma expressão regular diferente que pareça equivalente não é automaticamente aprovada. A presença da configuração e a prova de HIT são resultados separados.

O WP Super Cache 3.1.3 não declara `$wpsc_ignore_tracking_parameters` entre os globais de compatibilidade do carregador WP-CLI. Por isso uma consulta apenas nesse carregador pode não refletir a chave carregada na SAPI web. A evidência desta integração é obtida pela SAPI HTTP usada pelo painel, pelo canal e pelos pedidos públicos, sem modificar código do provedor.

O canal permanece candidato a release: o pacote anterior era rc.1 e tinha homologação pendente do cliente gladdia. Esta alteração de empacotamento não encerra essa pendência nem declara reexecução da matriz de autenticação anterior. Os testes e relatórios anteriores acompanham o pacote completo, identificados como históricos.

Os insumos binários de WordPress, Apache/PHP e Chromium não são redistribuídos nas fontes. As versões, os scripts e as evidências estão preservados. Não foi medida latência em produção nem feita afirmação de ganho universal com base na bancada local.
