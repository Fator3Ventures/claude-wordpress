#!/usr/bin/env bash
# Instala o ZIP anterior, troca os arquivos sem desativar/reativar e consulta a home.
set -uo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/bancada.sh"
NOVO="$(realpath "$1")"
ANTIGO="$AQUI/../referencias/releases/base-site-core-fator3-1.0.0.zip"
PASSO='acessos_atualizacao_sem_reativar'
faltam="$(insumos)"
if [ -n "$faltam" ]; then bloquear_todos "$faltam" "$PASSO"; exit 0; fi
if ! montar "$ANTIGO"; then bloquear_todos "$MOTIVO" "$PASSO"; exit 0; fi
if [ "$(wp plugin get base-site-core-fator3 --field=version 2>/dev/null)" != '1.0.0' ] || ! wp plugin is-active base-site-core-fator3 >/dev/null 2>&1; then
	linha FALHA "wp.$PASSO" 'A versão anterior não está instalada e ativa.'; exit 0
fi
if ! wp eval 'global $wpdb; if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $wpdb->esc_like($wpdb->prefix . "f3base_acessos"))) || wp_next_scheduled("f3base_acessos_somar")) { exit(1); }' >/dev/null 2>&1; then
	linha FALHA "wp.$PASSO" 'A instalação anterior já contém a estrutura nova; o cenário de atualização é inválido.'; exit 0
fi

# O MU-plugin configura somente a fonte sintética do teste e observa ativações.
# Não cria tabela, não soma dados e não agenda eventos.
php /dev/stdin "$TMP" "$SITE" <<'PHP'
<?php
$tmp = $argv[1]; $site = $argv[2];
mkdir($tmp . '/logs');
$linha = static fn($ua, $dias = 1) => '192.0.2.9 - - [' . gmdate('d/M/Y', strtotime('-' . $dias . ' days')) . ':12:00:00 +0000] "GET /atualizada/ HTTP/1.1" 200 42 "-" "' . $ua . '"' . "\n";
file_put_contents($tmp . '/logs/access.log.' . gmdate('Y-m-d', strtotime('-1 day')), str_repeat($linha('Chrome'), 2));
file_put_contents($tmp . '/logs/access.log.' . gmdate('Y-m-d', strtotime('-2 days')), $linha('Googlebot', 2));
file_put_contents($tmp . '/logs/access.log', $linha('Chrome', 0));
if (!is_dir($site . '/wp-content/mu-plugins')) { mkdir($site . '/wp-content/mu-plugins'); }
$mu = '<?php add_filter("pre_option_f3base_acessos", static fn() => array("ligado" => true, "padrao_do_log" => ' . var_export($tmp . '/logs/access.log.*', true) . '));'
    . ' add_action("activated_plugin", static function ($plugin) { if ($plugin === "base-site-core-fator3/base-site-core-fator3.php") { file_put_contents(' . var_export($tmp . '/ativacao-nova.txt', true) . ', "ativado"); } });';
file_put_contents($site . '/wp-content/mu-plugins/f3base-atualizacao.php', $mu);
PHP
if ! unzip -qo "$NOVO" -d "$SITE/wp-content/plugins"; then
	linha FALHA "wp.$PASSO" 'Não foi possível substituir os arquivos pelo ZIP novo.'; exit 0
fi
# A PRIMEIRA requisição após a troca é HTTP, antes de qualquer bootstrap de teste.
if [ "$(curl -s --max-time 30 -o "$TMP/home-atualizada.html" -w '%{http_code}' "http://127.0.0.1:$PORTA/")" != '200' ]; then
	linha FALHA "wp.$PASSO" 'A home não respondeu com sucesso após a substituição dos arquivos.'; exit 0
fi
export F3BASE_ATUALIZACAO_REAL=1
rodar_passo "$PASSO"

# Evidência opcional do botão real e da tela no navegador, fora da contagem do piso.
if [ -n "${F3BASE_EVIDENCIA_DIR:-}" ]; then
	F3BASE_LOG_ATUAL="$TMP/logs/access.log" F3BASE_BANCADA_PORTA="$PORTA" node "$AQUI/tela-acessos.cjs" || exit 1
	wp eval 'global $wpdb; if ((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}f3base_acessos WHERE dia = %s", wp_date("Y-m-d"))) !== 0) { throw new RuntimeException("Hoje foi armazenado pelo botão."); }' || exit 1
fi
