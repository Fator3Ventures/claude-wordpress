/* Navegador real: HTML envelhecido, transporte HTTP real e falhas controladas. */
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
(async()=>{
 const base=process.argv[2], tokenVelho=process.argv[3], destino=process.argv[4];
 const browser=await chromium.launch({executablePath:process.env.F3BASE_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--disable-gpu']});
 const evidencia={navegador:browser.version(),casos:[]};
 const aguardar=async(fn,msg)=>{for(let i=0;i<100;i++){if(await fn())return;await new Promise(r=>setTimeout(r,50));}throw Error(msg);};
 try {
  for(const modo of (process.argv[5]?[process.argv[5]]:['min','fonte'])) {
   for(const cenario of ['expirado','relogio-atrasado','relogio-adiantado','403-alheio','429','rede','sem-storage']) {
    const context=await browser.newContext(); const page=await context.newPage();
    const requisicoes=[], respostas=[], erros=[];
    page.on('pageerror',e=>erros.push(String(e)));
    await page.addInitScript(({atraso,semStorage})=>{
     if(atraso){const now=Date.now;Date.now=()=>now()+atraso;}
     window.open=()=>({opener:null});
     if(semStorage)for(const nome of ['localStorage','sessionStorage'])Object.defineProperty(window,nome,{get(){throw Error('Armazenamento bloqueado pelo visitante');}});
    },{atraso:cenario==='relogio-atrasado'?-86400000:cenario==='relogio-adiantado'?86400000:0,semStorage:cenario==='sem-storage'});
    await page.route('**/*',async route=>{
     const req=route.request(),u=new URL(req.url());
     if(u.origin!==base){await route.abort();return;}
     if(req.resourceType()==='document' && u.pathname==='/'){
      const r=await route.fetch();let html=await r.text();
      html=html.replace(/"token":"[0-9]+\.[a-f0-9]+"/g,'"token":"'+tokenVelho+'"');
      await route.fulfill({response:r,body:html});return;
     }
     if(u.pathname.includes('/f3base/v1/')){
      requisicoes.push({path:u.pathname,metodo:req.method(),corpo:req.postData()});
      if(u.pathname.endsWith('/lead') && ['403-alheio','429','rede'].includes(cenario)){
       if(cenario==='rede'){await route.abort('failed');return;}
       const status=cenario==='429'?429:403;
       respostas.push({path:u.pathname,status});
       await route.fulfill({status,contentType:'application/json',headers:{'Retry-After':'600','Cache-Control':'no-store, private'},body:JSON.stringify({ok:false,codigo:cenario==='429'?'f3base_rate_limit':'regra_do_operador'})});return;
      }
     }
     await route.continue();
    });
    page.on('response',async r=>{
     const u=new URL(r.url()); if(u.pathname.includes('/f3base/v1/'))respostas.push({path:u.pathname,status:r.status(),headers:await r.allHeaders()});
    });
    await page.goto(base+'/',{waitUntil:'domcontentloaded'});
    await page.waitForFunction(()=>!!window.f3baseTrackingDados && !!document.querySelector('[data-f3base-lead]'));
    const scripts=await page.locator('script[src]').evaluateAll(xs=>xs.map(x=>x.src).filter(x=>/f3base-(?:leads|tracking|consentimento)(?:\.min)?\.js/.test(x)));
    assert.equal(scripts.length,3);assert.ok(scripts.every(x=>modo==='min'?x.includes('.min.js'):!x.includes('.min.js')),JSON.stringify({modo,cenario,scripts}));
    // Dois cliques no mesmo instante, em CTAs diferentes, compartilham a renovação.
    await page.evaluate(()=>{
     for(const el of Array.from(document.querySelectorAll('main [data-f3base-lead]')).slice(0,2))el.click();
    });
    await aguardar(()=>requisicoes.some(r=>r.path.endsWith('/lead')),'Lead não despachado em '+cenario);
    await page.waitForTimeout(300);
    const renovacoes=requisicoes.filter(r=>r.path==='/wp-json/f3base/v1/token').length;
    assert.equal(renovacoes,1,JSON.stringify({modo,cenario,requisicoes}));
    const leads=respostas.filter(r=>r.path.endsWith('/lead'));
    if(['expirado','sem-storage','relogio-atrasado','relogio-adiantado'].includes(cenario)){
     await aguardar(()=>respostas.filter(r=>r.path.endsWith('/lead')&&r.status>=200&&r.status<300).length===2,'Leads sem confirmação: '+JSON.stringify(respostas));
     assert.equal(requisicoes.filter(r=>r.path.endsWith('/lead')).length,cenario==='relogio-atrasado'?4:2);
    }else{
     assert.ok(requisicoes.filter(r=>r.path.endsWith('/lead')).length<=2,'Repetiu POST sem recusa de token.');
    }
    if(cenario==='expirado'){
     await page.evaluate(()=>{Object.defineProperty(document,'visibilityState',{configurable:true,get:()=> 'hidden'});document.dispatchEvent(new Event('visibilitychange'));window.dispatchEvent(new Event('pagehide'));});
     await aguardar(()=>respostas.some(r=>r.path.endsWith('/comportamento')&&r.status>=200&&r.status<300),'Lote antigo não foi confirmado: '+JSON.stringify(respostas));
     assert.equal(requisicoes.filter(r=>r.path.endsWith('/comportamento/token')).length,1);
     const ps=requisicoes.filter(r=>r.path.endsWith('/comportamento')&&r.metodo==='POST');
     assert.equal(new Set(ps.map(r=>JSON.parse(r.corpo).lote)).size,ps.length,'Envios simultâneos duplicaram o lote.');
     // Recusa do visitante usa a operação real de consentimento; exclusão é confirmada.
     await page.evaluate(()=>window.f3baseConsentimento.definir('negado'));
     await aguardar(()=>respostas.some(r=>r.path.endsWith('/esquecer')&&r.status>=200&&r.status<300),'Esquecimento não confirmado.');
    }
    assert.deepEqual(erros,[]);
    evidencia.casos.push({modo,cenario,renovacoes,envios:requisicoes.map(({path,metodo})=>({path,metodo})),respostas});
    await context.close();
   }
  }
 }finally{await browser.close();fs.mkdirSync(path.dirname(destino),{recursive:true});fs.writeFileSync(destino,JSON.stringify(evidencia,null,2));}
 console.log(JSON.stringify({ok:true,casos:evidencia.casos.length}));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
