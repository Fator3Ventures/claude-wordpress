"""Teste HTTP real: evidência, Abilities, painel, leases concorrentes e disparadores do cron.
Uso: python3 suite/bancada-wp/cache-192.py BANCADA (criada por servidor-190.py).
"""
from pathlib import Path
import concurrent.futures, hashlib, json, os, re, subprocess, sys, time, urllib.request, urllib.error
work=Path(sys.argv[1]).resolve();info=json.loads((work/'ambiente.json').read_text());suite=Path(__file__).resolve().parent
site=Path(info['site']);url=info['url'];result={'zip_sha256':hashlib.sha256(Path(info['zip']).read_bytes()).hexdigest(),'casos':[],'falhas':[]}
def wp(*args):
 r=subprocess.run(info['wp_cli']+list(args),capture_output=True,text=True,timeout=90)
 assert r.returncode==0,r.stdout[-1500:]+r.stderr[-1500:]
 return r.stdout.strip()
def request(path,body=None):
 req=urllib.request.Request(url+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 try:r=urllib.request.urlopen(req,timeout=90)
 except urllib.error.HTTPError as ex:r=ex
 data=r.read().decode();return r.status,data

def core(action,**data):
 code,text=request('/wp-json/bancada/v1/cache192',{'acao':action,**data})
 try:r=json.loads(text)
 except ValueError:raise AssertionError(f'HTTP {code}: '+text[:1000])
 assert code==200 and r.get('ok'),r
 return r['resultado']
def case(name,fn):
 try:r=fn();result['casos'].append({'nome':name,'ok':True,'resultado':r});print('OK '+name,flush=True);return r
 except Exception as ex:result['falhas'].append({'nome':name,'erro':str(ex)[:4000]});raise

def current():return core('ler')['cache']
def proof():
 core('reset');r=core('verificar');p=r['sonda'];assert p['persisted'] and p['status']=='verified',p
 assert all(t['status']=='verified' for t in p['tokens'].values()),p['tokens']
 x=current();assert x['historico']['valida_geracao_atual'] and x['historico']['ultima_verificacao_bem_sucedida']==p['checked_at']
 assert x['agendamento']['ultima_execucao']['origem']=='verificar_publico'
 assert 3500<=x['proxima_verificacao']-int(time.time())<=3601
 return p

def concurrency():
 core('reset')
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
  first=ex.submit(core,'verificar',lenta=True)
  # Espera o início registrado antes de sobrepor a outra ação.
  limit=time.monotonic()+10
  while time.monotonic()<limit:
   if current()['agendamento']['ultima_execucao'].get('status')=='running':break
   time.sleep(.05)
  else:raise AssertionError('Primeira execução não iniciou.')
  second=ex.submit(core,'cron_manual');b=second.result();a=first.result()
 assert a['sonda']['persisted'],a['sonda']
 assert b['agendamento']['ultima_execucao']['id']==a['sonda']['id'],(a,b)
 assert b['verification']['codigo']=='verificacao_em_execucao',b['verification']
 return {'uma_execucao':True,'id':a['sonda']['id'],'origem_vencedora':a['sonda']['origem'],'concorrente':b['verification']['codigo']}

def cron(server=False):
 wp('config','set','DISABLE_WP_CRON','true','--raw')
 core('cron_preparar')
 before=0
 wp('config','set','DISABLE_WP_CRON','true' if server else 'false','--raw')
 if server:
  code,_=request('/wp-cron.php?doing_wp_cron');assert code==200
 else:
  # Com o disparo nativo habilitado, uma requisição normal provoca spawn no shutdown.
  code,_=request('/?cron_fixture_192='+str(time.time_ns()));assert code==200
 limit=time.monotonic()+20
 while time.monotonic()<limit:
  r=current()
  if r['historico']['ultima_verificacao']>before and r['agendamento']['ultima_execucao'].get('concluido_em',0):break
  time.sleep(.1)
 else:raise AssertionError('Cron não concluiu: '+json.dumps(r['agendamento']))
 primeira=r['agendamento']['ultima_execucao'];assert primeira['origem']=='cron' and primeira['concluido_em']>=primeira['iniciado_em'],primeira
 invalidacao=None
 if not r['historico']['valida_geracao_atual'] and r['estado']['geracao']!=primeira['geracao']:
  # Yoast pode ajustar seus índices no mesmo wp-cron.php, DEPOIS da sonda.
  # Isso é outra invalidação real. O Core deve preservar a prova e verificar a nova geração automaticamente.
  assert r['verification']['codigo']=='aguardando_verificacao_apos_limpeza',r['verification']
  # A consulta pode iniciar antes do shutdown do outro processo. Espere a fotografia da agenda convergir.
  settle=time.monotonic()+3
  while r['proxima_verificacao']-int(time.time())>121 and time.monotonic()<settle:
   time.sleep(.15);r=current()
  assert 0<r['proxima_verificacao']-int(time.time())<=121,r['agendamento']
  invalidacao={'primeira_execucao':primeira,'geracao_posterior':r['estado']['geracao'],'proxima_verificacao':r['proxima_verificacao']}
  print('Aguardando evento antecipado após invalidação independente do Yoast.',flush=True)
  limit=time.monotonic()+150
  while time.monotonic()<limit:
   time.sleep(2)
   if server and r['proxima_verificacao']<=int(time.time()):request('/wp-cron.php?doing_wp_cron')
   r=current()
   if r['historico']['valida_geracao_atual']:break
  else:raise AssertionError('Evento antecipado não verificou a nova geração: '+json.dumps(r['agendamento']))
 x=r['agendamento']['ultima_execucao']
 (work/('cron-servidor.json' if server else 'cron-nativo.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2))
 assert r['historico']['valida_geracao_atual'],r['verification']
 return {'disparador':'cron_servidor_http' if server else 'wp_cron_nativo','disparo_por_visitas':r['agendamento']['disparo_por_visitas'],'origem':x['origem'],'inicio':x['iniciado_em'],'fim':x['concluido_em'],'id':x['id'],'codigo':x['codigo'],'invalidacao_independente':invalidacao}

def desativacao():
 wp('plugin','deactivate','base-site-core-fator3')
 next_event=wp('eval','echo (int)wp_next_scheduled("f3base_cache_verificar");')
 assert next_event=='0',next_event
 wp('plugin','activate','base-site-core-fator3')
 next_event=wp('eval','echo (int)wp_next_scheduled("f3base_cache_verificar");')
 assert int(next_event)>0,next_event
 return {'desativar_remove_cron':True,'shutdown_nao_recria':True,'reativar_reagenda':True}

# O fixture fica fora do instalador, restrito ao loopback, e é removido ao terminar.
mu=site/'wp-content/mu-plugins/cache-192.php'
mu.write_text("<?php\ndefine('F3BASE_BANCADA_192',true);\nadd_action('rest_api_init',static function(){register_rest_route('bancada/v1','/cache192',['methods'=>'POST','permission_callback'=>static fn()=>($_SERVER['REMOTE_ADDR']??'')==='127.0.0.1','callback'=>static function($r){require_once "+repr(str(suite/'cache-192.php'))+";try{return ['ok'=>true,'resultado'=>c192_run($r->get_param('acao'),$r->get_json_params())];}catch(Throwable $e){return new WP_REST_Response(['ok'=>false,'erro'=>$e->getMessage(),'local'=>basename($e->getFile()).':'.$e->getLine()],500);}}]);});\n")
trace=site/'wp-content/mu-plugins/cache-192-trace.php'
trace.write_text("<?php add_action('updated_option',static function($n){if(str_starts_with($n,'wpseo')||$n==='f3base_cache_estado'){file_put_contents("+repr(str(work/'origens-opcoes.ndjson'))+",json_encode(['em'=>microtime(true),'option'=>$n,'pid'=>getmypid(),'uri'=>$_SERVER['REQUEST_URI']??'cli','cron'=>defined('DOING_CRON')&&DOING_CRON,'pilha'=>array_map(static fn($f)=>($f['class']??'').($f['type']??'').$f['function'],debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,12))]).\"\\n\",FILE_APPEND|LOCK_EX);}},99);")
# Rota de configuração nativa já usada na homologação anterior.
muold=site/'wp-content/mu-plugins/backlog-191.php'
muold.write_text("<?php\ndefine('F3BASE_BANCADA_191',true);\nadd_action('rest_api_init',static function(){register_rest_route('bancada/v1','/backlog',['methods'=>'POST','permission_callback'=>static fn()=>($_SERVER['REMOTE_ADDR']??'')==='127.0.0.1','callback'=>static function($r){require_once "+repr(str(suite/'backlog-191.php'))+";return ['ok'=>true,'resultado'=>b191_run($r->get_param('acao'),[])];}]);});")
(work/'httpd.pid').unlink(missing_ok=True)
server=subprocess.Popen(info['apache']+['-DFOREGROUND'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,start_new_session=True)
try:
 for _ in range(40):
  try:request('/');break
  except urllib.error.URLError:time.sleep(.1)
 else:raise RuntimeError('Apache não iniciou.')
 wp('config','set','DISABLE_WP_CRON','true','--raw')
 wp('plugin','activate','wp-super-cache','wordpress-seo')
 code,text=request('/wp-json/bancada/v1/backlog',{'acao':'configurar'});assert code==200,text[:700]
 case('consultas_abilities_e_painel_sem_efeitos',lambda:core('consultas'))
 case('historico_preservado_e_limpezas_agrupadas',lambda:core('preservar'))
 case('migracao_fora_da_consulta',lambda:core('migrar'))
 case('recusas_de_agenda_purga_http_e_persistencia',lambda:core('falhas'))
 case('sonda_http_real_e_retorno_cadencia_horaria',proof)
 case('concorrencia_cron_e_acao_explicita',concurrency)
 case('geracao_alterada_durante_sonda',lambda:core('mudanca_durante_sonda'))
 case('recuperacao_de_lease_expirada',lambda:core('lease_expirada'))
 case('wp_cron_disparador_real',lambda:cron(False))
 case('cron_servidor_com_disparo_por_visitas_desligado',lambda:cron(True))
 case('desativar_e_reativar',desativacao)
finally:
 wp('config','set','DISABLE_WP_CRON','true','--raw');mu.unlink(missing_ok=True);muold.unlink(missing_ok=True);trace.unlink(missing_ok=True)
 server.terminate()
 try:server.wait(timeout=5)
 except subprocess.TimeoutExpired:server.kill();server.wait(timeout=5)
 result['total']=len(result['casos']);(work/'cache-192.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'ok':not result['falhas'],'casos':result['total']}))
