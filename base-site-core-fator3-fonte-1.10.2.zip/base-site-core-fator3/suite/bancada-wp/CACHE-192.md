# Evidência e agendamento — homologação 1.9.2

Escopo: Core. Os fixtures de teste ficam fora do instalador, usam apenas loopback e são removidos ao terminar. WP Super Cache e Yoast são instalados a partir dos ZIPs oficiais; o Core não altera seus arquivos/configurações. A preparação do perfil de teste usa a API do provedor.

## Execução

1. `bash suite/verificar.sh "$PWD"` constrói e executa a regressão geral.
2. Prepare uma bancada nova com `servidor-190.py --prepare-only` usando o ZIP atual. Veja `COMPATIBILIDADE-190.md` para os parâmetros de Apache, PHP, WordPress, SQLite e plugins. Nunca reutilize banco de uma execução concorrente. A opção `--sqlite-journal-mode DELETE` usa o journal nativo em disco, dispensando a memória compartilhada de WAL em ambientes isolados; ela altera somente a bancada.
3. `python3 suite/bancada-wp/cache-192.py DIRETORIO_DA_BANCADA` inicia e termina o Apache e registra `cache-192.json`, as fotografias do cron e o rastreamento das invalidações. PHP, Apache e seus clientes precisam compartilhar a rede local.
4. `backlog-191.py` continua disponível com os treze cenários anteriores; seu parâmetro MCP é um insumo externo, mantido no release próprio do canal, e não faz parte das fontes do Core.
5. `python3 suite/testar-fontes.py` extrai uma fonte limpa, confere os hashes e reconstrói o instalador. Execute também o comando único dentro da fonte extraída.

## Evidência coberta

- Contrato, consultar e painel: zero HTTP, zero purga, evidência/estado/leases/cron idênticos, com prova ausente, válida, expirada, de contexto diferente, agenda ausente e agenda vencida.
- Validação e sanitização nativas via `wp_get_ability`/`WP_Ability`, incluindo campos novos, sem avisos.
- Última tentativa e último sucesso preservados após limpeza. A geração nova fica pendente. Limpezas próximas mantêm um só evento antecipado.
- Migração explícita: aproveita transiente legado existente; declara histórico indisponível quando a versão anterior já o apagou. Consulta não migra.
- Recusa de agenda preserva o evento anterior; falha de purga, HTTP, falta de HIT e recusa de persistência têm diagnóstico próprio. Nenhuma repetição imediata da sonda. O recuo progressivo tem teto.
- A prova positiva usa HTTP real com WP Super Cache. Falhas deliberadas usam filtros do WordPress apenas no fixture; não são evidência de sucesso público.
- Cron e ação explícita sobrepostos compartilham a lease; mudança de geração durante a rede impede promoção do resultado antigo. Lease vencida permite recuperação.
- Disparador nativo do WordPress, com WP-Cron por visitas habilitado; disparador de servidor por HTTP a `wp-cron.php`, com `DISABLE_WP_CRON=true`. Ambos registram origem cron e início/fim. Este ensaio não certifica um executor remoto ou WP-CLI na hospedagem.
- Desativar remove o evento, inclusive após o shutdown; reativar registra novamente a tarefa.

No WordPress 6.9, o disparador nativo roda no encerramento da requisição. A coincidência de uma consulta com uma execução de cron deve ser interpretada pelas origens e gerações registradas. Se outro componente invalida o cache depois de uma sonda bem-sucedida, a prova fica histórica e a nova geração permanece pendente; não é correto manter `verified` apenas porque os horários são próximos.

Referência oficial: [wp_cron e a mudança para shutdown](https://developer.wordpress.org/reference/functions/wp_cron/). Versões e hashes efetivamente ensaiados ficam nas evidências do release.
