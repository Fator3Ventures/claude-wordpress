<?php
require_once __DIR__ . '/cache-fixture.php';
/** Casos da tabela A. Somente WordPress real, local e descartável. */
if ((!defined('WP_CLI') || !WP_CLI) && !defined('F3BASE_BANCADA_191') || wp_parse_url(home_url(), PHP_URL_HOST) !== '127.0.0.1') { throw new RuntimeException('Exige bancada local.'); }
function b191_assert($ok, $motivo) { if (!$ok) { throw new RuntimeException($motivo); } }
function b191_gravar($nome, $valor) {
    $r=F3Base_Options::gravar($nome,array_replace(F3Base_Options::ler($nome),$valor),F3Base_Options::ORIGEM_PADRAO);
    b191_assert($r['persisted'], 'Core recusou '.$nome);return $r;
}
function b191_run($acao,$dados) {
    global $cache_rejected_uri,$wpsc_tracking_parameters,$wpsc_ignore_tracking_parameters,$wp_cache_config_file,$wpdb;
    wp_set_current_user(1);
    if ($acao==='configurar') {
        require_once ABSPATH.'wp-admin/includes/file.php';
        require_once ABSPATH.'wp-admin/includes/misc.php';
        // Operações do próprio provedor. Nenhuma escrita direta em seu arquivo.
        $r=new WP_REST_Request('POST','/wp-super-cache/v1/settings');
        $r->set_header('Content-Type','application/json');$r->set_body(wp_json_encode(['is_cache_enabled'=>true,'is_super_cache_enabled'=>2,'wpsc_save_headers'=>1,'dont_cache_logged_in'=>1,'cache_rebuild'=>0,'cache_compression'=>0,'cache_rejected_uri'=>array_merge(F3Base_Cache_Pagina::exclusoes(),['/reserva-operador/'])]));
        $resp=rest_do_request($r);b191_assert($resp->get_status()===200,'REST do provedor recusou.');
        wp_cache_setting('wpsc_ignore_tracking_parameters',1);
        wp_cache_setting('wpsc_tracking_parameters',F3Base_Cache_Pagina::parametros_rastreio());
        b191_gravar('f3base_comportamento',['ligado'=>true]);
        F3Base_Cache_Pagina::solicitar();F3Base_Cache_Pagina::limpar();
        return ['perfil'=>F3Base_Cache_Pagina::perfil(),'requisitos'=>F3Base_Cache_Pagina::requisitos()];
    }
    if ($acao==='perfil') {
        $antes=hash_file('sha256',$wp_cache_config_file);
        $base=F3Base_Cache_Pagina::requisitos();
        b191_assert($base['status']==='verified','Configuração do dono não sobreviveu ao novo processo.');
        b191_assert(count($base['rastreamento']['observados'])===22,'Lista deve ter 22 nomes.');
        $saidas=['correto'=>$base];
        $ignore=$wpsc_ignore_tracking_parameters;$params=$wpsc_tracking_parameters;$uris=$cache_rejected_uri;
        $wpsc_ignore_tracking_parameters=0;$saidas['so_lista']=F3Base_Cache_Pagina::requisitos();
        b191_assert($saidas['so_lista']['status']==='failed','Lista sem ativação aprovada.');
        $wpsc_ignore_tracking_parameters=1;$wpsc_tracking_parameters=[];$saidas['so_chave']=F3Base_Cache_Pagina::requisitos();
        b191_assert(count($saidas['so_chave']['rastreamento']['faltantes'])===22,'Só chave foi aprovada.');
        $wpsc_tracking_parameters=array_merge($params,['ref']);$saidas['ref']=F3Base_Cache_Pagina::requisitos();
        b191_assert($saidas['ref']['rastreamento']['proibidos_presentes']===['ref'],'ref não foi acusado.');
        $wpsc_tracking_parameters=array_values(array_diff($params,['gclid']));
        $cache_rejected_uri=array_values(array_diff($uris,['/llms-full.txt']));
        $saidas['faltantes']=F3Base_Cache_Pagina::requisitos();
        b191_assert($saidas['faltantes']['rastreamento']['faltantes']===['gclid'] && $saidas['faltantes']['exclusoes']['faltantes']===['/llms-full.txt'],'Não nomeou precisamente os faltantes.');
        $cache_rejected_uri=$uris;$wpsc_tracking_parameters=$params;$wpsc_ignore_tracking_parameters=$ignore;
        b191_assert(hash_file('sha256',$wp_cache_config_file)===$antes,'Diagnóstico escreveu no provedor.');
        b191_assert(in_array('/reserva-operador/',$cache_rejected_uri,true),'Regra do operador perdida.');
        return $saidas;
    }
    if ($acao==='chave') {
        $_GET=['gclid'=>'clique-unico','fbclid'=>'outro-clique','ref'=>'parceiro','produto'=>'42'];
        $_SERVER['REQUEST_URI']='/?'.http_build_query($_GET);
        $uri=wpsc_remove_tracking_params_from_uri($_SERVER['REQUEST_URI']);
        b191_assert($_GET===['ref'=>'parceiro','produto'=>'42'],'Rastreio não foi retirado ou parâmetro funcional foi perdido.');
        b191_assert(!str_contains($uri,'gclid')&&!str_contains($uri,'fbclid')&&str_contains($uri,'ref=parceiro'),'Chave não normalizada.');
        return ['uri'=>$uri,'get'=>$_GET];
    }
    if ($acao==='ler') {
        $n=0;$f=static function($r)use(&$n){++$n;return $r;};add_filter('pre_http_request',$f,99);
        $avisos=[];set_error_handler(static function($n,$m)use(&$avisos){$avisos[]=$m;return true;});
        try {
            $a=wp_get_ability('f3base/config-core-contrato-v1');b191_assert($a instanceof WP_Ability,'Habilidade real ausente.');
            $r=$a->execute([]);b191_assert(!is_wp_error($r),'Contrato recusado.');
            b191_assert(rest_validate_value_from_schema($r,$a->get_output_schema())===true,'Schema inválido.');
            b191_assert(rest_sanitize_value_from_schema($r,$a->get_output_schema())===$r,'Sanitização alterou saída.');
        }finally{restore_error_handler();remove_filter('pre_http_request',$f,99);}
        b191_assert(!$avisos && $n===0,'Leitura emitiu avisos ou HTTP.');
        return ['versao'=>$r['contract_version'],'http'=>$n,'avisos'=>$avisos,'cache'=>$r['integracoes']['cache']];
    }
    if ($acao==='prova') {f3b_fixture_cache();return F3Base_Cache_Pagina::verificar_publico();}
    if ($acao==='cabecalhos_reais') {
        $r=wp_remote_get(home_url('/fixture-cache-control.php'));
        b191_assert(!is_wp_error($r),'Fixture HTTP indisponível.');
        $campos=F3Base_Cache_Pagina::campos_cache_control($r);
        b191_assert(count($campos)===2,'Perdeu multiplicidade no transporte WordPress real.');return $campos;
    }
    if ($acao==='sondas_negativas') {
        $saidas=[];$token=F3Base_Modulo_Endpoint_Leads::emitir_token();
        foreach(['correto','repetido','sem_no_store','duplicado','futuro','token_invalido','rede','cota'] as $cenario) {
            $n=0;
            $f=static function($r,$args,$url)use($cenario,$token,&$n){
                ++$n;if($cenario==='rede')return new WP_Error('http_request_failed','Fixture de falha.');
                $headers=['cache-control'=>($cenario==='sem_no_store'?'private':($cenario==='duplicado'?['no-store, private','max-age=172800']:'no-store, private')),'expires'=>$cenario==='futuro'?gmdate('D, d M Y H:i:s \G\M\T',time()+172800):F3Base_Cache_Pagina::EXPIRES_PASSADO];
                return ['headers'=>$headers,'body'=>wp_json_encode(['ok'=>true,'token'=>$cenario==='token_invalido'?'velho':$token,'emissao_id'=>$cenario==='repetido'?'repetido':(string)$n]),'response'=>['code'=>$cenario==='cota'?429:200,'message'=>'Fixture']];
            };
            add_filter('pre_http_request',$f,99,3);
            try{$rs=F3Base_Cache_Pagina::sondar_tokens();}finally{remove_filter('pre_http_request',$f,99);}
            $p=$rs['endpoint-leads'];$esperado=$cenario==='correto'?'verified':(in_array($cenario,['rede','cota'],true)?'pending':'failed');
            b191_assert($p['status']===$esperado,$cenario.' devolveu '.wp_json_encode($p));
            b191_assert($n===4,'Esperados dois GET em cada uma das duas rotas.');
            if($cenario==='repetido') {
                f3b_fixture_cache(['contexto'=>F3Base_Cache_Pagina::contexto(),'checked_at'=>time(),'status'=>'verified','codigo'=>'fixture','motivo'=>'Fixture','tokens'=>$rs]);
                $estado=(new F3Base_Modulo_Endpoint_Leads())->estado();
                b191_assert($estado['estado']==='degradado' && str_contains($estado['motivo'],'corpo_repetido'),'Módulo não degradou com corpo repetido.');
            }
            b191_assert(!str_contains(wp_json_encode($p),$token),'Sonda expôs o token.');$saidas[$cenario]=$p;
        }
        f3b_fixture_cache();return $saidas;
    }
    if ($acao==='cadencia') {
        f3b_fixture_cache();
        F3Base_Cache_Pagina::limpar();$antes=(array)wp_count_posts('f3base_lead');
        $n=0;$f=static function($r)use(&$n){++$n;return $r;};add_filter('pre_http_request',$f,99);
        try{$a=F3Base_Cache_Pagina::verificar_publico();$primeiro=$n;$b=F3Base_Cache_Pagina::verificar_publico();F3Base_Cache_Pagina::resumo();}
        finally{remove_filter('pre_http_request',$f,99);}
        b191_assert($primeiro===6 && $n===6 && $a===$b,'Cadência não compartilha prova ou leitura disparou HTTP.');
        b191_assert((array)wp_count_posts('f3base_lead')===$antes,'Sonda criou leads.');
        $eventos=0;foreach(_get_cron_array() as $hooks){if(isset($hooks[F3Base_Cache_Pagina::CRON]))$eventos+=count($hooks[F3Base_Cache_Pagina::CRON]);}
        b191_assert($eventos===1,'Cron duplicado.');
        return ['gets_primeira'=>$primeiro,'gets_apos_repetir'=>$n,'cron_eventos'=>$eventos,'leads_inalterados'=>true,'prova'=>$a];
    }
    throw new RuntimeException('Ação desconhecida.');
}
if (defined('F3BASE_BANCADA_191')) { return; }
try {echo 'B191:'.wp_json_encode(['ok'=>true,'resultado'=>b191_run($args[0]??'',json_decode($args[1]??'{}',true))],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";}
catch(Throwable $e){echo 'B191:'.wp_json_encode(['ok'=>false,'erro'=>$e->getMessage()])."\n";WP_CLI::halt(1);}
