import argparse, concurrent.futures, hashlib, json, re, urllib.request
from pathlib import Path
parser=argparse.ArgumentParser(description='Leituras públicas para homologar o Core 1.9.0; não cria leads nem altera configurações.')
parser.add_argument('--site', required=True)
parser.add_argument('--output', type=Path, required=True)
args=parser.parse_args()
site=args.site.rstrip('/')
assert site.startswith(('http://','https://')), 'Informe a URL do site.'
paths=['/','/robots.txt','/llms.txt','/llms-full.txt','/sitemap_index.xml','/index.md','/wp-json/f3base/v1/token','/wp-json/f3base/v1/comportamento/token']
def get(path):
 r=urllib.request.urlopen(urllib.request.Request(site+path,headers={'User-Agent':'Mozilla/5.0 Release Core 1.9.0'}),timeout=25)
 with r:
  b=r.read(2*1024*1024)
  t=b.decode('utf-8','replace')
  d={'caminho':path,'status':r.status,'url_final':r.url,'cabecalhos':dict(r.headers),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  assert r.status==200,(path,r.status)
  assert not re.search(r'(?:PHP (?:Fatal error|Warning)|Undefined array key|<b>Warning</b>)',t),path
  if path=='/':
   d['assets_core']=re.findall(r'<script[^>]+src=[\'\"]([^\'\"]*f3base-(?:leads|tracking|consentimento)[^\'\"]*)',t)
   assert d['assets_core'] and all('.min.js' in x and 'ver=1.9.0' in x for x in d['assets_core']),d
  elif '/token' in path:
   j=json.loads(t);assert j['token'] and 'no-store' in r.headers.get('Cache-Control',''),d
   d['chaves_resposta']=list(j)
  elif path in ['/llms.txt','/llms-full.txt','/index.md']:
   assert t.startswith('# '),(path,t[:150])
   d['primeira_linha']=t.splitlines()[0]
   d['links_markdown']=re.findall(r'\]\((https?://[^)]+\.md)\)',t)[:3]
  elif path=='/robots.txt':
   d['conteudo']=t;assert site+'/sitemap_index.xml' in t
  elif path=='/sitemap_index.xml':assert '<sitemapindex' in t
  return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: rows=list(pool.map(get,paths))
p=args.output
p.write_text(json.dumps({'site':site,'respostas':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['caminho','status','bytes']} for r in rows],ensure_ascii=False))
