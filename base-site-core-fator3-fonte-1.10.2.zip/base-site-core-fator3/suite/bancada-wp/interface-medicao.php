<?php
/** Interação administrativa, cronologia real no banco e orçamentos da medição. */
declare( strict_types = 1 );

function f3b_i_configuracao(): array {
	$antes = F3Base_Options::ler( 'f3base_llms' );
	$fixture = WPMU_PLUGIN_DIR . '/f3base-tipos-fixture.php';
	$codigo = "<?php add_action('init', static function () { register_post_type('f3b_publico', array('public'=>true,'label'=>'Projetos públicos')); register_post_type('f3b_privado', array('public'=>false,'label'=>'Projetos privados')); });";
	wp_mkdir_p( WPMU_PLUGIN_DIR ); file_put_contents( $fixture, $codigo );
	register_post_type( 'f3b_publico', array( 'public' => true, 'label' => 'Projetos públicos' ) );
	register_post_type( 'f3b_privado', array( 'public' => false, 'label' => 'Projetos privados' ) );
	try {
		$config = $antes; $config['tipos'] = array( 'page', 'f3b_publico' ); $config['futuro_preservado'] = 'sim';
		F3Base_Options::gravar( 'f3base_llms', $config );
		$login = wp_remote_post( f3b_bancada_url( '/wp-login.php' ), array( 'redirection' => 0, 'body' => array( 'log' => 'admin', 'pwd' => 'admin' ) ) );
		$cookies = wp_remote_retrieve_cookies( $login );
		$url = f3b_bancada_url( '/wp-admin/admin.php?page=base-site-core-fator3' );
		$get = static function ( string $aba = '' ) use ( $url, $cookies ): string { return wp_remote_retrieve_body( wp_remote_get( $url . $aba, array( 'cookies' => $cookies, 'timeout' => 20 ) ) ); };
		$html = $get(); $x = f3b_c_dom( $html );
		f3b_p_evidencia( 'interface-configuracoes', array( 'codigo' => 200, 'cabecalhos' => array(), 'corpo' => $html ) );
		$caixas = '//input[@type="checkbox" and @name="f3base[f3base_llms][tipos][]"]';
		f3b_e_exige( $x->query( $caixas )->length >= 3 && $x->query( $caixas . '[@value="f3b_publico" and @checked]' )->length === 1 && $x->query( $caixas . '[@value="page" and @checked]' )->length === 1 && $x->query( $caixas . '[@value="f3b_privado"]' )->length === 0, 'Tipos públicos, privados ou seleção atual incorretos: ' . $x->query( $caixas )->length . ' caixas; selecionadas: ' . $x->evaluate( 'string(//input[@type="checkbox" and @checked]/@name)' ) );
		$secoes = array();
		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) { if ( F3Base_Options::operavel( $nome ) && isset( F3Base_Options::secoes_da_tela()[ $declaracao['secao'] ?? '' ] ) ) { $secoes[ $declaracao['secao'] ] = true; } }
		f3b_e_exige( ! str_contains( $html, 'Estado das partes do plugin' ) && $x->query( '//form[@class="f3base-form"]' )->length === count( $secoes ) && count( $secoes ) > 1, 'Configuração principal contém diagnóstico ou perdeu os formulários independentes por seção.' );
		foreach ( $x->query( '//form[@class="f3base-form"]' ) as $formulario ) {
			f3b_e_exige( 1 === $x->query( './/section[@data-f3base-bloco]', $formulario )->length && 1 === $x->query( './/input[@name="_wpnonce"]', $formulario )->length && 1 === $x->query( './/input[@type="submit" and @value="Salvar"]', $formulario )->length, 'Seção sem seu formulário, nonce ou botão Salvar.' );
		}
		$tecnica = $get( '&aba=tecnica' ); $xt = f3b_c_dom( $tecnica );
		f3b_e_exige( str_contains( $tecnica, 'Estado das partes do plugin' ) && str_contains( $tecnica, 'f3base-hooks' ) && $xt->query( '//form[@class="f3base-form"]' )->length === 0 && $xt->query( '//nav//a[@aria-current="page" and contains(@href,"tecnica")]' )->length === 1, 'Aba técnica incompleta ou formulário duplicado.' );
		foreach ( array( array( '', 'post', 'f3b_publico', 'f3b_privado' ), array( '' ) ) as $selecao ) {
			$html = $get(); $x = f3b_c_dom( $html );
			$formulario = '//form[@class="f3base-form"][.//input[@name="f3base_revisao[f3base_llms]"]]';
			$revisao = $x->evaluate( 'string(' . $formulario . '//input[@name="f3base_revisao[f3base_llms]"]/@value)' );
			f3b_e_exige( 1 === $x->query( $formulario )->length && '' !== $revisao, 'LLMS sem formulário próprio ou revisão de concorrência.' );
			$body = array( 'action' => $x->evaluate( 'string(' . $formulario . '//input[@name="action"]/@value)' ), '_wpnonce' => $x->evaluate( 'string(' . $formulario . '//input[@name="_wpnonce"]/@value)' ), 'f3base_revisao' => array( 'f3base_llms' => $revisao ), 'f3base' => array( 'f3base_llms' => array( 'tipos' => $selecao ) ) );
			$r = wp_remote_post( f3b_bancada_url( '/wp-admin/admin-post.php' ), array( 'cookies' => $cookies, 'redirection' => 0, 'body' => $body ) );
			f3b_e_exige( wp_remote_retrieve_response_code( $r ) === 302, 'Gravação de caixas não redirecionou.' );
			wp_cache_delete( 'f3base_llms', 'options' ); wp_cache_delete( 'alloptions', 'options' );
			$lido = get_option( 'f3base_llms' );
			$esperado = count( $selecao ) > 1 ? array( 'post', 'f3b_publico' ) : array();
			f3b_e_exige( $lido['tipos'] === $esperado && $lido['futuro_preservado'] === 'sim', 'Caixas, seleção vazia ou campo não exibido não foram preservados.' );
			$reaberta = f3b_c_dom( $get() );
			f3b_e_exige( $reaberta->query( $caixas . '[@checked]' )->length === count( $esperado ), 'Caixas não refletem a leitura de volta.' );
		}
	} finally {
		unlink( $fixture ); unregister_post_type( 'f3b_publico' ); unregister_post_type( 'f3b_privado' ); F3Base_Options::gravar( 'f3base_llms', $antes );
	}
	return array( 'OK', 'HTTP administrativo: duas abas, formulários independentes por seção com revisão CAS, tipos públicos registrados, seleção múltipla, desmarcar todos, sanitização e preservação de opções não expostas.' );
}

function f3b_i_intervalos(): array {
	global $wpdb;
	F3Base_Modulo_Comportamento::criar_tabela();
	$t = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA_EVENTOS;
	$visitante = f3b_bancada_apelido( 'intervalos' ); $sessao = f3b_bancada_apelido( 'intervalos-visita' );
	$base = time() - 300;
	$ids = array();
	$inserir = static function ( int $deslocamento, array $extras = array() ) use ( $wpdb, $t, $visitante, $sessao, $base, &$ids ): int {
		$dados = array_merge( array( 'visitante' => $visitante, 'sessao' => $sessao, 'dia' => gmdate( 'Y-m-d', $base + intdiv( $deslocamento, 1000 ) ), 'criado_em' => $base + intdiv( $deslocamento, 1000 ), 'ms' => $deslocamento, 'ancora' => 'visitante', 'caminho' => '/pagina-a/', 'metrica' => 'f3base_secao_vista', 'detalhe' => 'abertura', 'valor' => 0, 'ocorrencia' => 1 ), $extras );
		f3b_e_exige( false !== $wpdb->insert( $t, $dados ), 'Fixture de intervalo não entrou no banco.' ); $ids[] = (int) $wpdb->insert_id; return (int) $wpdb->insert_id;
	};
	$antes = F3Base_Options::ler( 'f3base_comportamento' );
	try {
		$primeiro = $inserir( 1500 );
		$atrasado = $inserir( 11750, array( 'caminho' => '/pagina-b/' ) );
		$previo = $inserir( 11350 ); // Inserido depois, mas ocorrido antes, no mesmo segundo.
		$inserir( 11600, array( 'metrica' => 'f3base_web_vital', 'detalhe' => 'LCP' ) );
		$inserir( 11700, array( 'visitante' => f3b_bancada_apelido( 'outro' ) ) );
		$inserir( 11725, array( 'sessao' => f3b_bancada_apelido( 'outra-visita' ) ) );
		$ultimo = $inserir( 14100 ); $simultaneo = $inserir( 14100 );
		$r = F3Base_Modulo_Comportamento::acionamentos( array( 'visitante' => $visitante, 'sessao' => $sessao, 'limite' => 1, 'salto' => 2 ) );
		f3b_e_exige( count( $r['linhas'] ) === 1 && $r['linhas'][0]['id'] === $atrasado && $r['linhas'][0]['anterior_id'] === $previo && $r['linhas'][0]['intervalo_ms'] === 400, 'Intervalo misturou visitas, técnica, paginação ou milissegundos.' );
		$mapa = array_column( F3Base_Modulo_Comportamento::acionamentos( array( 'visitante' => $visitante, 'sessao' => $sessao ) )['linhas'], null, 'id' );
		f3b_e_exige( $mapa[$primeiro]['intervalo_ms'] === null && $mapa[$primeiro]['anterior_id'] === null && $mapa[$previo]['intervalo_ms'] === 9850 && $mapa[$ultimo]['intervalo_ms'] === 2350 && $mapa[$simultaneo]['intervalo_ms'] === 0, 'Primeiro evento, travessia entre páginas ou simultaneidade incorretos.' );
		$estimado = $inserir( 17000, array( 'ancora' => 'servidor' ) );
		$legado = $inserir( 18000, array( 'ancora' => '' ) );
		$mapa = array_column( F3Base_Modulo_Comportamento::acionamentos( array( 'visitante' => $visitante, 'sessao' => $sessao ) )['linhas'], null, 'id' );
		f3b_e_exige( $mapa[$estimado]['intervalo_ms'] === null && $mapa[$legado]['intervalo_ms'] === null, 'Horário estimado ou legado virou duração exata.' );
		// O primeiro evento do período deve alcançar o predecessor retido fora dele.
		$meia_noite = strtotime( gmdate( 'Y-m-d' ) . ' 00:00:00 UTC' );
		$outra = f3b_bancada_apelido( 'virada' );
		$antigo = $inserir( 0, array( 'sessao' => $outra, 'dia' => gmdate( 'Y-m-d', $meia_noite - 1 ), 'criado_em' => $meia_noite - 1, 'ms' => 700 ) );
		$novo = $inserir( 0, array( 'sessao' => $outra, 'dia' => gmdate( 'Y-m-d' ), 'criado_em' => $meia_noite + 1, 'ms' => 200 ) );
		$config = $antes; $config['dias_no_painel'] = 1; F3Base_Options::gravar( 'f3base_comportamento', $config );
		$r = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => $outra ) );
		f3b_e_exige( count( $r['linhas'] ) === 1 && $r['linhas'][0]['id'] === $novo && $r['linhas'][0]['anterior_id'] === $antigo && $r['linhas'][0]['intervalo_ms'] === 1500, 'Período cortou a referência do intervalo.' );
		F3Base_Modulo_Comportamento::somar( gmdate( 'Y-m-d' ), '/pagina-a/', 'f3base_pagina_vista', '', 1, 0.0 );
		wp_set_current_user( 1 ); $_GET['sessao'] = $sessao; ob_start(); F3Base_Admin_Medicao::render(); $html = ob_get_clean(); unset( $_GET['sessao'] );
		f3b_p_evidencia( 'interface-intervalos', array( 'codigo' => 200, 'cabecalhos' => array(), 'corpo' => $html ) );
		f3b_e_exige( 1 === f3b_c_dom( $html )->query( '//th[@scope="col" and normalize-space(.)="Desde o anterior"]' )->length && str_contains( $html, '400 ms' ) && str_contains( $html, 'inatividade' ), 'Coluna, precisão ou explicação ausentes na tabela.' );
	} finally {
		foreach ( $ids as $id ) { $wpdb->delete( $t, array( 'id' => $id ) ); } F3Base_Options::gravar( 'f3base_comportamento', $antes );
	}
	return array( 'OK', 'Intervalos reais no banco: mesma visita e visitante, paginação, virada de período, milissegundos fora de ordem, simultaneidade, outras páginas e horários não confiáveis.' );
}

function f3b_i_orcamentos(): array {
	f3b_e_exige( F3Base_Modulo_Comportamento::MAX_POR_VISITA === 300 && F3Base_Modulo_Comportamento::MAX_EVENTOS === 180 && F3Base_Modulo_Comportamento::MAX_BYTES === 12288, 'Orçamento de visita, lote ou bytes não aumentou em cinquenta por cento.' );
	f3b_e_exige( F3Base_Modulo_Acessos_Servidor::MAX_BYTES_ARQUIVO === 100663296 && F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA === 12 && F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_LOTE === 15 && F3Base_Modulo_Acessos_Servidor::TETO_CAMINHOS_POR_DIA === 750 && F3Base_Modulo_Acessos_Servidor::TETO_AGREGADOS === 75000 && F3Base_Modulo_Acessos_Servidor::TETO_LINHAS === 1500 && F3Base_Admin_Acessos::TETO_PAGINAS === 300, 'Orçamentos de logs incompletos.' );
	$eventos = F3Base_Modulo_Tracking::eventos_de_comportamento();
	foreach ( array( 'f3base_pagina_vista' => 2, 'f3base_rolagem' => 6, 'f3base_secao_vista' => 18, 'f3base_link_externo' => 15, 'f3base_friccao' => 5, 'f3base_erro_js' => 5, 'f3base_web_vital' => 6 ) as $nome => $teto ) { f3b_e_exige( (int) $eventos[$nome]['teto'] === $teto, 'Teto por página incorreto: ' . $nome ); }
	foreach ( array( 'f3base_rolagem', 'f3base_secao_vista' ) as $nome ) { f3b_e_exige( (int) $eventos[$nome]['limiar']['travessias_por_sessao'][0] === 30, 'Releitura mantém teto anterior.' ); }
	// A fixture declara uma decisão aceita; autorização não é parte do orçamento medido.
	$politica = F3Base_Options::ler( 'f3base_consentimento' );
	F3Base_Options::gravar( 'f3base_consentimento', array_merge( $politica, array( 'modo' => 'legado', 'padrao' => 'pre-aprovado' ) ) );
	$cookie = static function ( $args, $url ) {
		if ( $url === f3b_bancada_rest( '/f3base/v1/comportamento' ) ) {
			$args['cookies'] = array( F3Base_Modulo_Consentimento::COOKIE => 'granted' );
		}
		return $args;
	};
	add_filter( 'http_request_args', $cookie, 10, 2 );
	try {
		$apelido = f3b_bancada_apelido( 'novo-orcamento' );
		$lote = f3b_bancada_lote( $apelido, array() ); $lote['eventos'] = array_fill( 0, 180, array( 'gatilho' => 'pagina', 'ms' => 0 ) );
		$r = f3b_bancada_post( f3b_bancada_rest( '/f3base/v1/comportamento' ), $lote );
		f3b_e_exige( $r['codigo'] === 201 && (int) ( $r['json']['registro'] ?? 0 ) === 180, 'Lote ampliado não gravou os cento e oitenta eventos: ' . $r['corpo'] );
		$lote = f3b_bancada_lote( $apelido, array() ); $lote['eventos'] = array(); $lote['cortados'] = 7; $lote['caminho'] = '/cortes-isolados/';
		global $wpdb; $t = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA;
		$contar = static fn() => (int) $wpdb->get_var( "SELECT SUM(contagem) FROM {$t} WHERE caminho = '/cortes-isolados/' AND metrica = 'f3base_cortadas'" );
		$antes = $contar();
		$r = f3b_bancada_post( f3b_bancada_rest( '/f3base/v1/comportamento' ), $lote );
		f3b_e_exige( $r['codigo'] === 201 && $contar() === $antes + 7, 'Lote só de descartes não foi armazenado.' );
		$r = f3b_bancada_post( f3b_bancada_rest( '/f3base/v1/comportamento' ), $lote );
		f3b_e_exige( $r['codigo'] === 200 && $contar() === $antes + 7, 'Reenvio duplicou descartes.' );
	} finally {
		remove_filter( 'http_request_args', $cookie, 10 );
		F3Base_Options::gravar( 'f3base_consentimento', $politica );
	}
	return array( 'OK', 'Orçamentos ampliados e arredondados, lote maior aceito, descartes isolados persistidos e reenvio deduplicado.' );
}
