# Homologação de cache e Yoast

`suite/release-190.sh` acrescenta à regressão obrigatória uma instalação descartável com Apache real, WP Super Cache e Yoast. O código instalado é comparado, arquivo por arquivo, com o ZIP. O relatório contém o SHA-256 do artefato, versões observadas, respostas públicas e resultados adversos.

Pré-requisitos: PHP CLI de 64 bits com extensões usadas pela bancada, Node/npm, Playwright com Chromium, Apache com PHP e mod_rewrite, ZIPs oficiais de WordPress, SQLite, WP Super Cache e Yoast. O minificador usa somente as dependências fixadas em `suite/build-assets/package-lock.json`; o servidor WordPress não instala Node.

Defina:

| Variável | Conteúdo |
|---|---|
| `F3BASE_BANCADA_CACHE` | `wordpress.zip`, `sqlite-database-integration.zip` e `wp-cli.phar` já obtidos pela bancada existente. |
| `F3BASE_PLUGINS_COMPATIBILIDADE` | `wp-super-cache.3.1.3.zip` e `wordpress-seo.zip`; conservar os hashes dos insumos usados. |
| `F3BASE_APACHE_ROOT` | Raiz com `usr/sbin/apache2` e `usr/lib/apache2/modules`, incluindo `libphp8.3.so`. Em instalação padrão pode ser `/`. |
| `F3BASE_PHP_INI` | Diretório do `php.ini` do módulo PHP. |
| `F3BASE_HOMOLOGACAO_DIR` | Diretório ainda inexistente para preservar a evidência anterior. |
| `F3BASE_CHROMIUM` | Executável Chromium instalado. `playwright` deve resolver no Node. |
| `F3BASE_ROLLBACK_ZIP` | Instalador anterior validado. O padrão é `suite/referencias/releases/base-site-core-fator3-1.9.1.zip`, incluído no pacote completo. Necessário também em checkout Git limpo. |

Execute a partir do pacote: `bash suite/release-190.sh`. Binários portáteis podem precisar de `PATH` e `LD_LIBRARY_PATH` próprios. Ambientes isolados com apenas o UID atual mapeado podem usar `F3BASE_SINGLE_UID_NAMESPACE=1`; o preparador verifica esse requisito. Em sistemas normais o servidor usa www-data.

As configurações dos plugins externos são feitas por suas APIs: REST nativa do WP Super Cache e `WPSEO_Options` do Yoast. A bancada configura somente seu Apache descartável para provar o caso Expert com cabeçalhos. O Core não escreve regras gerais do servidor.

A leitura pública não usa autenticação, cookies administrativos nem cache-busting. Uma identificação por geração é combinada com cabeçalho de HIT ou arquivo efetivo do provedor. Não basta comparar dois corpos. Os cenários negativos devem diagnosticar a ausência de cabeçalhos; sua reprovação esperada é sucesso do teste, não aprovação do ambiente inseguro.

Os testes de browser recebem HTML com token assinado já vencido. O transporte e a persistência de leads e comportamento são reais. Somente falhas de rede, respostas 403 alheias ao token, 429 e desvios de relógio/armazenamento são controlados pelo teste. Não se espera o TTL transcorrer nem se altera o relógio do servidor. SCRIPT_DEBUG é alterado pelo WP-CLI no fixture, seguido de limpeza do cache e recarga do servidor. Nenhum contato é enviado ao WhatsApp ou a fornecedores externos.

O modo `--browser` do verificador Python serve ao diagnóstico em uma bancada já preparada. Para resultado de release, use sempre a execução completa em diretório novo: reaproveitar o banco acumula as cotas por origem e os conteúdos alterados pelos cenários adversos.

Também estão disponíveis `node suite/build-assets/verificar.cjs fontes/plugin` para os casos de minificado ausente, antigo e corrompido, e `suite/bancada-wp/piso-publicacao.py` para os mutantes declarados de uma funcionalidade. Não trate cenários não executados como aprovados.

A matriz inclui um bloco FAQ real do Yoast junto de `core/details`, uma Organization com logo e serviços repetidos: verifica um único grafo, a ausência de duplicação e as referências por `@id`. Também instala a versão anterior, limpa o cache pelo provedor, confere preferências e leads e reinstala o ZIP atual, verificando o HTML de ambas as versões. `--schema-only` e `--retorno-only` executam essas duas verificações isoladas e gravam relatórios separados, preservando o resultado da matriz principal.
