#!/usr/bin/env bash
#
# BANCADA WORDPRESS REAL — a classe de evidência que faltava.
#
# Toda a suíte até aqui mede a ÁRVORE do pacote: análise estática sobre a fonte,
# sondas que rodam o código real contra um `wpdb` de mentira e stubs do núcleo, e
# um Chromium de verdade para o cliente. Nenhuma delas carrega o WordPress. Foi
# nessa fresta que passaram os defeitos que esta bancada existe para acusar: um
# `uninstall.php` que morre em fatal, uma rota pública que responde 500 assim que
# é ligada, um par de redirect que gira para sempre, três habilidades que o
# núcleo recusa por falta de categoria e um lote de medição descartado com 200.
# Todos eles têm uma coisa em comum: só aparecem com o núcleo carregado.
#
# O QUE ESTE ARQUIVO FAZ, e nada além disso:
#
#   1. Garante os insumos (core, drop-in de SQLite, wp-cli) num CACHE. Sem cache
#      e sem rede a etapa inteira fecha BLOCKED com o recurso nomeado — nunca OK,
#      nunca N/A. Ambiente que não pôde medir não aprova pacote nenhum.
#   2. Monta um WordPress DESCARTÁVEL em `mktemp -d`, instala o plugin A PARTIR
#      DO ZIP que a rodada acabou de montar — não da fonte: o visitante recebe o
#      zip — e sobe `php -S` numa porta livre só durante a rodada.
#   3. Roda cada passo do roteiro em SEU PRÓPRIO processo. Passo que falha não
#      impede o seguinte, e passo que não pôde ser medido fecha BLOCKED.
#   4. Derruba tudo ao final, inclusive em falha, inclusive em interrupção.
#
# Saída: uma linha JSON por veredito, em stdout. Quem imprime estado é a suíte,
# por `estado()`, e é lá que o contador mora — este arquivo não conta nada.
#
#   bash bancada.sh rodada <zip> [passo...]   monta, roda o roteiro, derruba
#   bash bancada.sh piso <raiz-do-pacote>     ramo negativo e positivo de cada passo
#   bash bancada.sh cache [origem]            semeia o cache (copia ou baixa)
#
# @package F3Base\Suite

set -uo pipefail

AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CACHE="${F3BASE_BANCADA_CACHE:-$HOME/.cache/f3base-bancada}"

# Versão do núcleo que a bancada pede quando precisa baixar. O endereço `latest`
# é o que a documentação do WordPress publica; a versão fixada existe para que
# uma rodada de hoje possa ser repetida amanhã contra o mesmo núcleo.
WP_URL_FIXA="${F3BASE_BANCADA_WP_URL:-https://wordpress.org/latest.zip}"
SQLITE_URL="https://downloads.wordpress.org/plugin/sqlite-database-integration.latest-stable.zip"
WPCLI_URL="https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar"

# A LISTA DE PASSOS NÃO MORA AQUI. Ela mora em `pisos.tsv`, que é a mesma
# tabela que a suíte lê para saber o que esperar emitido e qual mutante prova
# cada passo. Uma segunda lista escrita neste arquivo divergiria dela no
# primeiro passo acrescentado, e o passo novo sumiria do relatório em silêncio.
passos_declarados() {
	awk -F '\t' '$1 !~ /^#/ && NF >= 3 && $1 != "" { printf "%s ", $1 }' "$AQUI/pisos.tsv"
}

TMP=""
SRV_PID=""

# ---------------------------------------------------------------------------
# Emissão. Uma linha JSON por veredito — nunca texto solto, nunca contagem.
# ---------------------------------------------------------------------------

linha() {
	php -r 'echo json_encode(array("estado" => $argv[1], "nome" => $argv[2], "mensagem" => $argv[3]), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), "\n";' -- "$1" "$2" "$3"
}

# Fecha BLOCKED em TODO passo pedido, com o mesmo motivo. Usado quando o
# ambiente não permitiu montar a bancada: o que não foi medido não é OK e não é
# N/A — é pendência de ambiente, com o recurso nomeado.
bloquear_todos() {
	local motivo="$1"
	shift
	local passo
	for passo in "$@"; do
		linha 'BLOCKED' "wp.$passo" "não medido: a bancada WordPress não pôde ser montada. $motivo"
	done
}

derrubar() {
	if [ -n "$SRV_PID" ] && kill -0 "$SRV_PID" 2>/dev/null; then
		kill "$SRV_PID" 2>/dev/null
		wait "$SRV_PID" 2>/dev/null
	fi
	SRV_PID=""

	if [ -n "$TMP" ] && [ -d "$TMP" ]; then
		rm -rf "$TMP"
	fi
	TMP=""
}

trap derrubar EXIT INT TERM

# ---------------------------------------------------------------------------
# Insumos. Cache primeiro, rede depois, BLOCKED se nenhum dos dois.
# ---------------------------------------------------------------------------

baixar() {
	local url="$1"
	local destino="$2"
	local parcial="$destino.parcial"

	if command -v curl >/dev/null 2>&1; then
		curl -fsSL --max-time 180 -o "$parcial" "$url" 2>/dev/null
	elif command -v wget >/dev/null 2>&1; then
		wget -q -T 180 -O "$parcial" "$url" 2>/dev/null
	else
		return 1
	fi

	if [ ! -s "$parcial" ]; then
		rm -f "$parcial"
		return 1
	fi

	mv "$parcial" "$destino"
	return 0
}

# Garante um insumo no cache. Devolve 0 quando o arquivo está lá ao final.
garantir() {
	local arquivo="$1"
	local url="$2"
	local origem="${3:-}"

	mkdir -p "$CACHE"

	if [ -s "$CACHE/$arquivo" ]; then
		return 0
	fi

	if [ -n "$origem" ] && [ -s "$origem" ]; then
		cp "$origem" "$CACHE/$arquivo"
		return 0
	fi

	baixar "$url" "$CACHE/$arquivo"
}

insumos() {
	local faltam=""

	garantir 'wordpress.zip' "$WP_URL_FIXA" || faltam="$faltam wordpress.zip (<$WP_URL_FIXA>)"
	garantir 'sqlite-database-integration.zip' "$SQLITE_URL" || faltam="$faltam sqlite-database-integration.zip (<$SQLITE_URL>)"
	garantir 'wp-cli.phar' "$WPCLI_URL" || faltam="$faltam wp-cli.phar (<$WPCLI_URL>)"

	if [ -n "$faltam" ]; then
		echo "$faltam"
		return 1
	fi

	return 0
}

# ---------------------------------------------------------------------------
# Montagem.
# ---------------------------------------------------------------------------

porta_livre() {
	php -r '$s = @stream_socket_server("tcp://127.0.0.1:0", $e, $m); if (false === $s) { exit(1); } $n = stream_socket_get_name($s, false); fclose($s); echo (int) substr($n, strrpos($n, ":") + 1);'
}

wp() {
	php "$CACHE/wp-cli.phar" --path="$SITE" --allow-root "$@"
}

# Monta o WordPress descartável e instala o plugin a partir do zip.
# Preenche TMP, SITE, PORTA, SRV_PID. Devolve 1 e o motivo em `MOTIVO`.
MOTIVO=""
SITE=""
PORTA=""

montar() {
	local zip="$1"

	if [ ! -s "$zip" ]; then
		MOTIVO="Recurso ausente: o zip do plugin montado por esta rodada ($zip)."
		return 1
	fi

	TMP="$(mktemp -d "${TMPDIR:-/tmp}/f3base-bancada-XXXXXXXX")" || {
		MOTIVO='Recurso ausente: diretório temporário gravável (mktemp -d).'
		return 1
	}

	SITE="$TMP/site"
	mkdir -p "$SITE" "$TMP/desempacotado"

	unzip -q "$CACHE/wordpress.zip" -d "$TMP/desempacotado" || {
		MOTIVO="Recurso ausente: núcleo do WordPress legível em $CACHE/wordpress.zip."
		return 1
	}

	if [ -d "$TMP/desempacotado/wordpress" ]; then
		mv "$TMP/desempacotado/wordpress/"* "$SITE/"
	else
		mv "$TMP/desempacotado/"* "$SITE/"
	fi
	rm -rf "$TMP/desempacotado"

	mkdir -p "$SITE/wp-content/plugins"
	# O insumo WordPress pode vir sem temas; a fixture precisa exercitar wp_head/wp_footer reais.
	mkdir -p "$SITE/wp-content/themes/f3base-bancada"
	cp "$AQUI/tema-bancada/style.css" "$AQUI/tema-bancada/index.php" "$SITE/wp-content/themes/f3base-bancada/"
	unzip -q "$CACHE/sqlite-database-integration.zip" -d "$SITE/wp-content/plugins" || {
		MOTIVO="Recurso ausente: drop-in de SQLite legível em $CACHE/sqlite-database-integration.zip."
		return 1
	}

	if [ ! -f "$SITE/wp-content/plugins/sqlite-database-integration/db.copy" ]; then
		MOTIVO='Recurso ausente: db.copy dentro do sqlite-database-integration — sem o drop-in não há banco.'
		return 1
	fi

	cp "$SITE/wp-content/plugins/sqlite-database-integration/db.copy" "$SITE/wp-content/db.php"

	PORTA="$(porta_livre)"
	if [ -z "$PORTA" ]; then
		MOTIVO='Recurso ausente: porta TCP livre em 127.0.0.1 para o servidor da rodada.'
		return 1
	fi

	wp config create --dbname=bancada --dbuser=bancada --dbpass=bancada --dbhost=localhost --skip-check --force >/dev/null 2>&1 || {
		MOTIVO='Recurso ausente: wp-cli operante (wp config create falhou).'
		return 1
	}

	# Jobs são despachados explicitamente pelos cenários para evitar concorrência incidental.
	wp config set SQLITE_JOURNAL_MODE DELETE --type=constant >/dev/null 2>&1
	wp config set DISABLE_WP_CRON true --raw --type=constant >/dev/null 2>&1
	# A bancada mede somente HTTP local; consultas de atualização externas não pertencem ao ensaio.
	wp config set WP_HTTP_BLOCK_EXTERNAL true --raw --type=constant >/dev/null 2>&1
	wp config set WP_ACCESSIBLE_HOSTS 127.0.0.1,localhost --type=constant >/dev/null 2>&1
	wp config set WP_DEBUG true --raw --type=constant >/dev/null 2>&1
	wp config set WP_DEBUG_LOG true --raw --type=constant >/dev/null 2>&1
	wp config set WP_DEBUG_DISPLAY false --raw --type=constant >/dev/null 2>&1

	wp core install --url="http://127.0.0.1:$PORTA" --title='Bancada F3Base' \
		--admin_user=admin --admin_password=admin --admin_email=admin@example.com --skip-email >/dev/null 2>&1 || {
		MOTIVO='Recurso ausente: instalação do núcleo (wp core install falhou — banco SQLite ou núcleo incompatível).'
		return 1
	}

	wp theme activate f3base-bancada >/dev/null 2>&1 || {
		MOTIVO='Recurso ausente: ativação do tema mínimo da bancada.'
		return 1
	}

	# A ATIVAÇÃO É MEDIDA, e por isso o log nasce vazio aqui: o que o passo
	# `ativacao_sem_aviso` lê é o que a ativação escreveu, e mais nada.
	: > "$SITE/wp-content/debug.log"

	wp plugin install "$zip" >"$TMP/instalacao.txt" 2>&1 || {
		MOTIVO="Recurso ausente: instalação do plugin a partir do zip — $(tr '\n' ' ' < "$TMP/instalacao.txt")"
		return 1
	}

	# Separar instalação de ativação impede avisos da rede de atualização do núcleo
	# de serem atribuídos ao código do plugin. A ativação mantém o log inteiro.
	: > "$SITE/wp-content/debug.log"
	wp plugin activate base-site-core-fator3 >"$TMP/ativacao.txt" 2>&1 || {
		MOTIVO="Falha ao ativar o plugin instalado: $(tr '\n' ' ' < "$TMP/ativacao.txt")"
		return 1
	}

	cp "$SITE/wp-content/debug.log" "$TMP/ativacao.log" 2>/dev/null || : > "$TMP/ativacao.log"

	F3BASE_DOCROOT="$SITE" php -S "127.0.0.1:$PORTA" -t "$SITE" "$AQUI/roteador.php" >"$TMP/servidor.log" 2>&1 &
	SRV_PID=$!

	local tentativa=0
	while [ "$tentativa" -lt 40 ]; do
		if curl -s -o /dev/null --max-time 2 "http://127.0.0.1:$PORTA/" 2>/dev/null; then
			break
		fi
		tentativa=$((tentativa + 1))
		sleep 0.25
	done

	if [ "$tentativa" -ge 40 ]; then
		MOTIVO="Recurso ausente: servidor HTTP embutido respondendo em 127.0.0.1:$PORTA."
		return 1
	fi

	return 0
}

# ---------------------------------------------------------------------------
# Execução dos passos.
# ---------------------------------------------------------------------------

# Roda UM passo do roteiro, em processo próprio, e imprime a linha que ele
# gravou. Roteiro que não gravou nada fecha BLOCKED: silêncio não é aprovação.
rodar_passo() {
	local passo="$1"
	if [ "$passo" = 'acessos_atualizacao_sem_reativar' ] && [ "${F3BASE_ATUALIZACAO_REAL:-}" != '1' ]; then
		bash "$AQUI/atualizacao.sh" "$ZIP_DA_RODADA"
		return
	fi
	local saida="$TMP/veredito-$passo.json"

	rm -f "$saida"

	F3BASE_SITE="$SITE" F3BASE_BANCADA_PORTA="$PORTA" F3BASE_BANCADA_TMP="$TMP" \
		php "$AQUI/roteiro.php" "$saida" "$passo" >"$TMP/passo-$passo.txt" 2>&1

	if [ -s "$saida" ]; then
		cat "$saida"
		return 0
	fi

	linha 'BLOCKED' "wp.$passo" "o passo não devolveu veredito: o processo do roteiro terminou sem gravar linha. Recurso ausente: PHP capaz de carregar o wp-load.php da bancada. Saída: $(tr '\n' ' ' < "$TMP/passo-$passo.txt" | cut -c1-400)"
	return 0
}

# A desinstalação é o único passo que precisa do que o WordPress faz por fora:
# plugin INATIVO e um processo NOVO que define WP_UNINSTALL_PLUGIN e inclui o
# arquivo. Fazer isso dentro do processo do roteiro mediria outra coisa — com o
# plugin carregado, as classes que faltam ao uninstall estariam todas presentes.
preparar_desinstalacao() {
	wp plugin deactivate base-site-core-fator3 >/dev/null 2>&1

	F3BASE_SITE="$SITE" php "$AQUI/desinstalador.php" >"$TMP/uninstall.txt" 2>&1
	echo "$?" > "$TMP/uninstall.codigo"
}

rodada() {
	local zip="$1"
	ZIP_DA_RODADA="$zip"
	shift
	local pedidos="${*:-$(passos_declarados)}"

	local faltam
	faltam="$(insumos)"

	if [ -n "$faltam" ]; then
		linha 'BLOCKED' 'bancada.ambiente' "a bancada WordPress não pôde ser montada: o cache em $CACHE não tem o insumo e a rede não o entregou. Recurso ausente:$faltam."
		bloquear_todos "Recurso ausente:$faltam." $pedidos
		return 0
	fi

	if ! montar "$zip"; then
		linha 'BLOCKED' 'bancada.ambiente' "a bancada WordPress não pôde ser montada. $MOTIVO"
		bloquear_todos "$MOTIVO" $pedidos
		derrubar
		return 0
	fi

	local versao_wp
	local versao_php
	versao_wp="$(wp core version 2>/dev/null | tr -d '\r\n')"
	versao_php="$(php -r 'echo PHP_VERSION;')"

	linha 'OK' 'bancada.ambiente' "WordPress $versao_wp montado em diretório descartável com banco SQLite pelo drop-in, servido por php -S em 127.0.0.1:$PORTA sob PHP $versao_php; o plugin foi instalado A PARTIR DO ZIP desta rodada e ativado por wp-cli. Tudo é derrubado ao final, inclusive em falha."

	local passo
	for passo in $pedidos; do
		if [ "$passo" = 'desinstalacao_limpa' ]; then
			preparar_desinstalacao
		fi
		rodar_passo "$passo"
	done

	derrubar
	return 0
}

# ---------------------------------------------------------------------------
# Piso: cada passo contra a árvore mutante que reproduz o defeito.
# ---------------------------------------------------------------------------

# Monta o zip instalável de uma árvore de plugin. É a mesma forma que `dist/`
# publica — um diretório de topo com o slug —, montada aqui para que o piso não
# dependa de uma rodada anterior ter deixado `dist/entregue/` em disco.
empacotar_mutante() {
	local fonte="$1"
	local destino="$2"
	local berco="$3"

	rm -rf "$berco"
	mkdir -p "$berco"
	cp -r "$fonte" "$berco/base-site-core-fator3"
	( cd "$berco" && zip -q -r -X "$destino" base-site-core-fator3 )
}

piso() {
	local raiz="$1"
	local tabela="$AQUI/pisos.tsv"

	if [ ! -f "$tabela" ]; then
		linha 'FALHA' 'bancada.piso' "a tabela de pisos da bancada não existe: $tabela. Sem ela nenhum passo declara qual defeito ele sabe acusar."
		return 0
	fi

	local faltam
	faltam="$(insumos)"

	if [ -n "$faltam" ]; then
		linha 'BLOCKED' 'bancada.ambiente' "o piso da bancada não pôde rodar: o cache em $CACHE não tem o insumo e a rede não o entregou. Recurso ausente:$faltam."
		return 0
	fi

	local base="$(mktemp -d "${TMPDIR:-/tmp}/f3base-piso-XXXXXXXX")"
	local zip_pristino="$base/pristino.zip"

	empacotar_mutante "$raiz/fontes/plugin" "$zip_pristino" "$base/berco-pristino"

	# RODADA PRISTINA: ela é o ramo NEGATIVO dos passos cujo defeito ainda mora
	# na fonte, e o ramo POSITIVO dos passos que já fecham OK hoje.
	local pristina="$base/pristina.ndjson"
	rodada "$zip_pristino" > "$pristina"

	# A TABELA É LIDA POR UM DESCRITOR PRÓPRIO. Com ela na entrada padrão, o
	# primeiro comando de dentro do laço que lesse stdin — e há vários, entre
	# unzip, php e wp-cli — comeria as linhas restantes e o piso mediria menos
	# passos do que declara, em silêncio.
	local nome situacao mutante motivo esperado observado
	while IFS=$'\t' read -r nome mutante situacao motivo <&3; do
		case "$nome" in ''|'#'*) continue;; esac

		observado="$(php -r 'foreach ((array) file($argv[1]) as $l) { $j = json_decode((string) $l, true); if (is_array($j) && ($j["nome"] ?? "") === $argv[2]) { echo (string) $j["estado"]; return; } } echo "AUSENTE";' -- "$pristina" "wp.$nome")"

		if [ "$situacao" = 'positivo-pendente-de-correcao' ]; then
			if [ "$observado" = 'FALHA' ]; then
				linha 'OK' "wp.$nome" "piso negativo: o defeito ainda mora na fonte e o passo o acusou na rodada pristina — mutante declarado como a própria fonte. $motivo"
			else
				linha 'FALHA' "wp.$nome" "piso negativo: a fonte carrega o defeito declarado e o passo NÃO o acusou (fechou $observado) — detector cego."
			fi

			linha 'N/A' "wp.$nome" "piso positivo: condição declarada — o ramo correto ainda não existe na fonte, e um ramo positivo montado sobre a fonte defeituosa mediria o defeito de novo. $motivo"
			continue
		fi

		if [ "$observado" != 'OK' ]; then
			linha 'FALHA' "wp.$nome" "piso positivo: o passo acusou o caso correto na rodada pristina (fechou $observado)."
		else
			linha 'OK' "wp.$nome" "piso positivo: ficou em silêncio sobre a fonte sem o defeito plantado."
		fi

		# UM PASSO PODE TER MAIS DE UM MUTANTE, separados por vírgula, e a razão
		# é que um passo pode acusar DEFEITOS INDEPENDENTES. `habilidades_registradas`
		# é o caso: o gancho sem o prefixo `wp_` e a `category` ausente derrubam
		# o registro das habilidades por caminhos diferentes, e um mutante que
		# planta os dois juntos não prova que o passo enxerga cada um. Uma LINHA
		# por passo continua sendo a regra — quem lista os passos a rodar lê a
		# coluna 1 —, e é a coluna do mutante que passa a aceitar a lista.
		local caminho_do_mutante
		local n=0

		for caminho_do_mutante in $( echo "$mutante" | tr ',' ' ' ); do
			n=$((n + 1))

			if [ ! -f "$AQUI/$caminho_do_mutante" ]; then
				linha 'FALHA' "wp.$nome" "piso negativo: o mutante declarado não existe em $AQUI/$caminho_do_mutante."
				continue
			fi

			local arvore="$base/mutante-$nome-$n"
			rm -rf "$arvore"
			cp -r "$raiz/fontes/plugin" "$arvore"

			if ! ( cd "$arvore" && patch -p1 --silent < "$AQUI/$caminho_do_mutante" ); then
				linha 'FALHA' "wp.$nome" "piso negativo: o mutante $caminho_do_mutante não aplicou sobre fontes/plugin/ — patch que não aplica não planta defeito nenhum."
				continue
			fi

			local zip_mutante="$base/mutante-$nome-$n.zip"
			empacotar_mutante "$arvore" "$zip_mutante" "$base/berco-$nome-$n"

			esperado="$(rodada "$zip_mutante" "$nome" | php -r 'foreach ((array) file("php://stdin") as $l) { $j = json_decode((string) $l, true); if (is_array($j) && ($j["nome"] ?? "") === $argv[1]) { echo (string) $j["estado"]; return; } } echo "AUSENTE";' -- "wp.$nome")"

			if [ "$esperado" = 'FALHA' ]; then
				linha 'OK' "wp.$nome" "piso negativo: acusou o defeito plantado por $caminho_do_mutante. $motivo"
			else
				linha 'FALHA' "wp.$nome" "piso negativo: o defeito plantado por $caminho_do_mutante NÃO foi acusado (fechou $esperado) — detector cego."
			fi
		done
	done 3< "$tabela"

	rm -rf "$base"
	return 0
}

# ---------------------------------------------------------------------------

# Permite reutilizar a montagem descartável na prova de troca real de arquivos.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then return 0; fi

case "${1:-}" in
	rodada)
		shift
		if [ "$#" -lt 1 ]; then
			echo 'uso: bancada.sh rodada <zip> [passo...]' >&2
			exit 2
		fi
		rodada "$@"
		;;
	piso)
		shift
		if [ "$#" -lt 1 ]; then
			echo 'uso: bancada.sh piso <raiz-do-pacote>' >&2
			exit 2
		fi
		piso "$1"
		;;
	cache)
		shift
		origem="${1:-}"
		mkdir -p "$CACHE"
		garantir 'wordpress.zip' "$WP_URL_FIXA" "${origem:+$origem/wordpress.zip}"
		garantir 'sqlite-database-integration.zip' "$SQLITE_URL" "${origem:+$origem/sqlite-plugin.zip}"
		garantir 'wp-cli.phar' "$WPCLI_URL" "${origem:+$origem/wp}"
		ls -l "$CACHE"
		;;
	*)
		echo 'uso: bancada.sh rodada <zip> [passo...] | piso <raiz> | cache [origem]' >&2
		exit 2
		;;
esac

exit 0
