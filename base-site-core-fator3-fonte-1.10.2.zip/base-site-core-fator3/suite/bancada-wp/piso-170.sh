#!/usr/bin/env bash
# Pisos das correções: cada mutante roda isolado contra o caso que deve recusá-lo.
set -euo pipefail
RAIZ="${1:?informe a raiz do pacote}"
PRISTINA="${2:-}"
CASOS=(configuracao_resultados configuracao_contrato configuracao_verificacao politica_opcional)
TEMPORARIO="$(mktemp -d /tmp/f3base-pisos170-XXXXXXXX)"
trap 'rm -rf "$TEMPORARIO"' EXIT
if [ -z "$PRISTINA" ]; then
 PRISTINA="$TEMPORARIO/pristina.log"
 bash "$RAIZ/suite/bancada-wp/bancada.sh" rodada "$(python3 "$RAIZ/suite/versao.py" --zip)" "${CASOS[@]}" > "$PRISTINA"
fi
python3 - "$PRISTINA" "${CASOS[@]}" <<'PY'
import sys,json
r=[json.loads(l) for l in open(sys.argv[1]) if l.startswith('{')]
for n in sys.argv[2:]:
 assert any(x.get('nome')=='wp.'+n and x.get('estado')=='OK' for x in r), 'Caso correto não aprovado: '+n
PY
for CASO in "${CASOS[@]}"; do
 ARVORE="$TEMPORARIO/$CASO/base-site-core-fator3"
 mkdir -p "$ARVORE"
 cp -R "$RAIZ/fontes/plugin/." "$ARVORE/"
 (cd "$ARVORE" && patch -p1 --silent < "$RAIZ/suite/bancada-wp/mutantes/$CASO.patch")
 (cd "$TEMPORARIO/$CASO" && zip -qr "$TEMPORARIO/$CASO.zip" base-site-core-fator3)
 bash "$RAIZ/suite/bancada-wp/bancada.sh" rodada "$TEMPORARIO/$CASO.zip" "$CASO" > "$TEMPORARIO/$CASO.log"
 python3 - "$TEMPORARIO/$CASO.log" "$CASO" <<'PY'
import sys,json
r=[json.loads(l) for l in open(sys.argv[1]) if l.startswith('{')]
x=next(x for x in r if x.get('nome')=='wp.'+sys.argv[2]); assert x['estado']=='FALHA',x
print(json.dumps({'mutante':sys.argv[2],'estado':'OK','defeito_detectado':x['mensagem']},ensure_ascii=False))
PY
done
