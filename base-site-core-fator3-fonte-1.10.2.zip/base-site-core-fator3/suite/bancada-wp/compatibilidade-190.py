"""Homologação HTTP real no Apache descartável; grava evidências e falha ao divergir.

Uso: python compatibilidade-190.py DIRETORIO_DA_BANCADA [--debug]
Requer PATH do PHP e LD_LIBRARY_PATH do Apache usados no servidor-190.py.
"""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile

work = Path(sys.argv[1]).resolve()
info = json.loads((work / 'ambiente.json').read_text())
suite = Path(__file__).resolve().parent
url = info['url']
evidencias = {'ambiente': {}, 'casos': [], 'falhas': []}
if 'zip' in info:
    with zipfile.ZipFile(info['zip']) as z:
        for item in z.infolist():
            if not item.is_dir():
                assert (Path(info['site'])/'wp-content/plugins'/item.filename).read_bytes()==z.read(item), 'Plugin instalado diverge do ZIP: '+item.filename
    evidencias['zip_sha256']=hashlib.sha256(Path(info['zip']).read_bytes()).hexdigest()
    assert evidencias['zip_sha256']==info['zip_sha256'], 'Artefato mudou após preparar a bancada.'

def wp(*args):
    p = subprocess.run(info['wp_cli'] + list(args), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=90)
    with (work / 'execucoes-190.log').open('a') as f:
        f.write(p.stdout)
    if p.returncode:
        raise AssertionError(p.stdout[-3000:])
    return p.stdout

def core(acao, **dados):
    s = wp('eval-file', str(suite / 'compatibilidade-190.php'), acao, json.dumps(dados))
    lines = [x[len('F3B190:'):] for x in s.splitlines() if x.startswith('F3B190:')]
    r = json.loads(lines[-1])
    assert r['ok'], r
    return r['resultado']

def http(path='/', data=None):
    start = time.perf_counter()
    req = urllib.request.Request(url + path, data=json.dumps(data).encode() if data is not None else None,
                                 headers={'User-Agent': 'Mozilla/5.0 Core190 Fixture', **({'Content-Type': 'application/json'} if data is not None else {})})
    try:
        r = urllib.request.urlopen(req, timeout=15)
    except urllib.error.HTTPError as e:
        r = e
    with r:
        body = r.read().decode('utf-8', errors='replace')
        return {'status': r.status, 'headers': dict(r.headers), 'body': body, 'ms': round((time.perf_counter()-start)*1000, 2)}

def caso(nome, fn):
    try:
        r = fn()
        evidencias['casos'].append({'nome': nome, 'ok': True, 'resultado': r})
        print('OK ' + nome, flush=True)
        return r
    except Exception as e:
        evidencias['falhas'].append({'nome': nome, 'erro': str(e)})
        print('FALHA ' + nome + ': ' + str(e)[:1500], flush=True)
        raise

def modo(m):
    core('modo', modo=m)
    perfil = core('estado')['perfil']
    assert perfil['modo'] == {'cabecalhos': 'wp-cache-cabecalhos'}.get(m,m), perfil
    a, b = http(), http()
    assert a['status'] == b['status'] == 200, (a,b)
    prova = core('prova')
    if m in ('cabecalhos','desligado'):
        assert prova['status'] == 'verified', prova
    else:
        assert prova['status'] == 'failed' and prova['hit'] and prova['faltantes'], prova
    assert m == 'desligado' or prova['hit'], prova
    return {'perfil': perfil, 'primeiro': {k:v for k,v in a.items() if k!='body'}, 'segundo': {k:v for k,v in b.items() if k!='body'}, 'prova': prova}

def rotas():
    caminhos = ['/wp-json/f3base/v1/token', '/?rest_route=/f3base/v1/token', '/?rest_route=%2Ff3base%2Fv1%2Ftoken', '/wp-json/f3base/v1/comportamento/token']
    r = []
    for path in caminhos:
        x = http(path)
        assert x['status']==200 and json.loads(x['body'])['token'], x
        assert 'no-store' in x['headers'].get('Cache-Control',''), x
        r.append({k:v for k,v in x.items() if k!='body'})
    for path, data, status in [('/wp-json/f3base/v1/lead', {'token':'invalido','correlation_id':'teste190invalido'},403),('/wp-json/f3base/v1/comportamento',{'token':'invalido'},403),('/wp-json/f3base/v1/comportamento/esquecer',{'token':'invalido'},403)]:
        x=http(path,data)
        assert x['status']==status and 'no-store' in x['headers'].get('Cache-Control',''), x
        r.append({'status':x['status'],'headers':x['headers']})
    return r

def concorrencia():
    # Mesma origem real (loopback), oito emissores simultâneos, vinte solicitações.
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        rs=list(pool.map(lambda _:http('/wp-json/f3base/v1/token?pagina=/'),range(20)))
    assert all(r['status']==200 for r in rs), [r['status'] for r in rs]
    ms=sorted(r['ms'] for r in rs)
    return {'simultaneidade':8,'pedidos':20,'erros':0,'latencia_mediana_ms':ms[len(ms)//2], 'latencia_maxima_ms':max(ms)}

def publicacao(ids):
    r=[]
    for slug,tipo in [('publico','privado'),('publico','senha'),('publico','excluir'),('noindex','noindex'),('alias','alias')]:
        if tipo in ('senha','excluir'):
            core('publicacao',id=ids[slug],tipo='publicar')
        # Aquecer as representações antes de retirar o conteúdo.
        before=http('/llms-full.txt'); assert before['status']==200, before
        assert 'Texto integral verificável '+slug in before['body'], ('fixture não estava público',slug,before)
        x=core('publicacao',id=ids[slug],tipo=tipo,destino=ids['inicio'])
        for path in ['/llms.txt','/llms-full.txt',f'/{slug}/index.md']:
            y=http(path)
            assert ('Texto integral verificável '+slug) not in y['body'], (tipo,path,y)
            if path in ('/llms.txt','/llms-full.txt'):
                assert (url+'/'+slug+'/') not in y['body'], (tipo,path,y)
        r.append({'tipo':tipo,'slug':slug,'seo':x['seo']})
    sitemap=http('/sitemap_index.xml')
    assert sitemap['status']==200 and '<sitemapindex' in sitemap['body'], sitemap
    assert '/sitemap_index.xml' in http('/robots.txt')['body']
    return r

def navegador(modo):
    wp('config','set','SCRIPT_DEBUG','true' if modo=='fonte' else 'false','--raw')
    core('limpar')
    # PHP pode manter o wp-config em OPcache; recarregar é responsabilidade do fixture.
    subprocess.run(info['apache']+['-k','graceful'],check=True)
    token=core('token_velho')['token']
    p=subprocess.run(['node',str(suite/'tokens-190.cjs'),url,token,str(work/f'tokens-{modo}-190.json'),modo],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    assert p.returncode==0,p.stdout
    return json.loads((work/f'tokens-{modo}-190.json').read_text())

def schema_yoast():
    fixture=core('schema_yoast')
    response=http('/faq-190/')
    assert response['status']==200, response
    scripts=re.findall(r'<script[^>]*class="yoast-schema-graph"[^>]*>(.*?)</script>',response['body'],re.S)
    assert len(scripts)==1, 'Esperado um único grafo publicado pelo Yoast.'
    graph=json.loads(scripts[0])['@graph']
    def typed(t):
        return [n for n in graph if t in (n.get('@type',[]) if isinstance(n.get('@type'),list) else [n.get('@type')])]
    ids=[n['@id'] for n in graph if '@id' in n]
    assert len(ids)==len(set(ids)), 'Nós com @id duplicado.'
    assert len(typed('FAQPage'))==len(typed('Organization'))==len(typed('Service'))==1, graph
    assert typed('Service')[0]['provider']['@id']==typed('Organization')[0]['@id'], graph
    faq=typed('FAQPage')[0]
    assert any(n.get('@id','').endswith('#faq-question-190') for n in faq['mainEntity']), graph
    return {'yoast':fixture['yoast'],'grafos':len(scripts),'faq':1,'organizacao':1,'servico':1,'referencias_validas':True,'grafo':graph}

def retorno():
    anterior=Path(os.environ.get('F3BASE_ROLLBACK_ZIP',str(suite.parent.parent/'suite/referencias/releases/base-site-core-fator3-1.9.1.zip')))
    assert anterior.is_file(), 'Informe F3BASE_ROLLBACK_ZIP ou preserve a referência declarada.'
    def versao_zip(arquivo):
        with zipfile.ZipFile(arquivo) as z:return re.search(r'Version:\s*(\S+)',z.read('base-site-core-fator3/base-site-core-fator3.php').decode()).group(1)
    esperada=versao_zip(anterior);atual=versao_zip(info['zip'])
    antes=core('snapshot')
    try:
        wp('plugin','install',str(anterior),'--force','--activate')
        core('limpar_nativo')
        versao=wp('plugin','get','base-site-core-fator3','--field=version').strip()
        assert versao==esperada, versao
        volta=core('snapshot')
        assert all(volta['preferencias'][k]==v for k,v in antes['preferencias'].items() if k in volta['preferencias']), 'Preferência mudou no retorno.'
        assert antes['leads']==volta['leads'], 'Dados de leads alterados.'
        pagina=http(); assert pagina['status']==200 and ('ver='+esperada) in pagina['body'], pagina['status']
    finally:
        wp('plugin','install',info['zip'],'--force','--activate')
        core('limpar_nativo')
    depois=core('snapshot')
    assert antes==depois, 'Nova atualização alterou preferências ou leads.'
    pagina=http(); assert pagina['status']==200 and ('ver='+atual) in pagina['body'], pagina['status']
    return {'sequencia':[atual,esperada,atual],'preferencias':len(antes['preferencias']),'leads_preservados':True,'respostas_publicas':200,'snapshot_antes':antes,'snapshot_depois':depois}

conf=work/'httpd.conf'
original=conf.read_text()
# O servidor e seus clientes vivem no mesmo processo de homologação/rede local.
(work/'httpd.pid').unlink(missing_ok=True)
server=subprocess.Popen(info['apache']+['-DFOREGROUND'], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=os.environ, start_new_session=True)
try:
    for _ in range(30):
        try:
            http(); break
        except urllib.error.URLError:
            time.sleep(.1)
    else:
        raise RuntimeError('Apache não iniciou.')
    if '--browser' in sys.argv:
        for m in ['min','fonte']:
            caso('navegador_'+m,lambda m=m:navegador(m))
        wp('config','set','SCRIPT_DEBUG','false','--raw');core('limpar')
    elif '--schema-only' in sys.argv:
        caso('schema_blocos_yoast',schema_yoast)
    elif '--retorno-only' in sys.argv:
        caso('atualizacao_e_retorno',retorno)
    elif '--debug' in sys.argv:
        print(json.dumps({'http':http(),'prova':core('prova')},ensure_ascii=False,indent=2))
    else:
        base=caso('preparacao', lambda:core('preparar'))
        # Preferências do WordPress pela sua operação nativa, fora do catálogo do Core.
        for name,value in [('show_on_front','page'),('page_on_front',str(base['ids']['inicio'])),('blog_public','1'),('wp_page_for_privacy_policy','0')]:
            wp('option','update',name,value)
        evidencias['ambiente']=base
        def isolado():
            x=http(); assert x['status']==200 and 'Texto integral verificável inicio' in x['body'],x
            assert http('/llms-full.txt')['status']==200
            return {'status':x['status'],'perfil':core('estado')['perfil']}
        caso('core_isolado',isolado)
        wp('plugin','activate','wordpress-seo')
        core('preparar');caso('core_yoast',isolado)
        wp('plugin','deactivate','wordpress-seo')
        wp('plugin','activate','wp-super-cache')
        core('modo',modo='simple');caso('core_cache',isolado)
        wp('plugin','activate','wordpress-seo')
        base=core('preparar');evidencias['ambiente']=base
        caso('cotas_separadas', lambda:core('quota'))
        caso('prefixo_e_subdiretorio', lambda:core('exclusoes'))
        for m in ['desligado','simple','cabecalhos','expert']:
            caso('cache_'+m, lambda m=m:modo(m))
            caso('rotas_'+m, rotas)
        # Apenas o fixture configura Apache. O Core jamais escreve estas regras.
        conf.write_text(original+'\nHeader always set X-Content-Type-Options "nosniff"\nHeader always set Referrer-Policy "strict-origin-when-cross-origin"\nHeader always set X-Frame-Options "SAMEORIGIN"\nHeader always set Cross-Origin-Opener-Policy "same-origin-allow-popups"\nHeader always set Content-Security-Policy "frame-ancestors \'self\'"\nHeader always set Permissions-Policy "geolocation=(), camera=(), microphone=()"\n')
        subprocess.run(info['apache']+['-k','graceful'],check=True)
        core('limpar'); http(); http()
        def prova_expert():
            p=core('prova'); assert p['status']=='verified' and p['hit'],p
            return p
        caso('expert_com_cabecalhos_da_infraestrutura',prova_expert)
        conf.write_text(original); subprocess.run(info['apache']+['-k','graceful'],check=True)
        core('modo',modo='cabecalhos')
        caso('contrato_e_invalidação',lambda:core('cache_contrato'))
        caso('concorrencia_origem_compartilhada',concorrencia)
        caso('publicacao_yoast',lambda:publicacao(base['ids']))
        caso('schema_blocos_yoast',schema_yoast)
        for m in ['min','fonte']:
            caso('navegador_'+m,lambda m=m:navegador(m))
        wp('config','set','SCRIPT_DEBUG','false','--raw');core('limpar')
        caso('atualizacao_e_retorno',retorno)
finally:
    conf.write_text(original)
    server.terminate()
    try: server.wait(timeout=8)
    except subprocess.TimeoutExpired: server.kill(); server.wait()
    destino='schema-190.json' if '--schema-only' in sys.argv else ('retorno-190.json' if '--retorno-only' in sys.argv else 'compatibilidade-190.json')
    (work/destino).write_text(json.dumps(evidencias,indent=2,ensure_ascii=False)+'\n')
sys.exit(bool(evidencias['falhas']))
