<?php
/** Compatibilidade da serialização nativa e interação com a administração. */
declare( strict_types = 1 );

function f3b_180_contrato(): array {
	global $wp_version;
	wp_set_current_user( 1 );
	F3Base_Options::gravar( 'f3base_meta_capi_token', 'SEGREDO-180-NAO-PUBLICAR' );
	$avisos = array(); $saidas = array(); $antes = ini_get( 'display_errors' );
	ini_set( 'display_errors', '1' );
	set_error_handler( static function( $nivel, $mensagem, $arquivo, $linha ) use ( &$avisos ) {
		$avisos[] = array( 'nivel' => $nivel, 'mensagem' => $mensagem, 'arquivo' => basename( $arquivo ), 'linha' => $linha );
		return false; // O teste captura e também deixa o PHP emitir o aviso; não mascara o defeito.
	} );
	ob_start();
	try {
		$habilidade = wp_get_ability( 'f3base/config-core-contrato-v1' );
		f3b_e_exige( $habilidade instanceof WP_Ability, 'Contrato não existe no registro real de abilities.' );
		$r = $habilidade->execute( array() );
		f3b_e_exige( ! is_wp_error( $r ) && $r['ok'], 'Execução nativa do contrato falhou.' );
		$saidas[] = rest_sanitize_value_from_schema( $r, $habilidade->get_output_schema(), 'output' );
		f3b_e_exige( $saidas[0] === $r, 'Sanitização alterou os valores ou o marcador de segredo do contrato.' );
		$itens = array_column( $r['opcoes'], null, 'nome' );
		f3b_e_exige( array( 'configurado' => true, 'mascarado' => true ) === $itens['f3base_meta_capi_token']['valor'], 'Marcador de segredo incorreto.' );
		foreach ( array( 'valor', 'padrao' ) as $campo ) {
			$schema = $habilidade->get_output_schema()['properties']['opcoes']['items']['properties'][ $campo ];
			foreach ( array( null, false, true, 0, 1, 12, 1.5, '', '00123', array(), array( 'post', 'page' ), array( 'configurado' => true, 'mascarado' => true ), array( 'grupo' => array( 'numero' => 8, 'ligado' => false ) ) ) as $valor ) {
				f3b_e_exige( true === rest_validate_value_from_schema( $valor, $schema ) && $valor === rest_sanitize_value_from_schema( $valor, $schema ), 'Schema polimórfico alterou o tipo ou rejeitou valor JSON.' );
			}
		}
		$op = $itens['f3base_sessao'];
		$escrita = wp_get_ability( 'f3base/config-core-escrever' );
		$entrada = array( 'nome' => $op['nome'], 'valor' => $op['valor'], 'revisao_esperada' => $op['revisao'] );
		$p = $escrita->execute( $entrada );
		f3b_e_exige( ! is_wp_error( $p ) && $p['ok'] && ! $p['persisted'] && $p['simulado'], 'Simulação pela ability falhou.' );
		f3b_e_exige( $entrada === rest_sanitize_value_from_schema( $entrada, $escrita->get_input_schema() ), 'Schema de entrada alterou o valor da simulação.' );
		$saidas[] = rest_sanitize_value_from_schema( $p, $escrita->get_output_schema(), 'output' );
		f3b_e_exige( $saidas[1] === $p, 'Schema de gravação alterou a resposta.' );
	} finally {
		$emitido = ob_get_clean(); restore_error_handler(); ini_set( 'display_errors', (string) $antes );
		$evidencia = array( 'wordpress' => $wp_version, 'avisos' => $avisos, 'quantidade' => count( $avisos ), 'bytes_emitidos' => strlen( $emitido ) );
		$dir = getenv( 'F3BASE_EVIDENCIA_DIR' );
		if ( $dir ) { wp_mkdir_p( $dir ); file_put_contents( $dir . '/contrato-sem-avisos.json', wp_json_encode( $evidencia, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ); }
	}
	f3b_e_exige( ! $avisos && '' === $emitido, 'Abilities/schema emitiram ' . count( $avisos ) . ' avisos e ' . strlen( $emitido ) . ' bytes com display_errors ativo.' );
	f3b_e_exige( ! str_contains( wp_json_encode( $saidas ), 'SEGREDO-180-NAO-PUBLICAR' ), 'Contrato expôs o segredo.' );
	return array( 'OK', 'WordPress ' . $wp_version . ': registro real de abilities e sanitização nativa sem avisos; tipos, dados e marcador de segredo preservados.' );
}

function f3b_180_navegador( string $modo ): void {
	$saida = array(); $codigo = 0;
	exec( 'node ' . escapeshellarg( __DIR__ . '/ux-admin-180.cjs' ) . ' ' . escapeshellarg( home_url( '/' ) ) . ' ' . escapeshellarg( $modo ) . ' 2>&1', $saida, $codigo );
	f3b_e_exige( 0 === $codigo, 'Administração no navegador: ' . implode( "\n", $saida ) );
}
function f3b_180_configuracao(): array {
	wp_set_current_user( 1 );
	F3Base_Options::gravar( 'f3base_meta_capi_token', 'SEGREDO-UX-180' );
	$c = F3Base_Options::ler( 'f3base_llms' ); $c['futuro_preservado'] = 'sim'; F3Base_Options::gravar( 'f3base_llms', $c );
	f3b_180_navegador( 'configuracao' );
	foreach ( array( 'alloptions', 'f3base_meta_capi_token', 'f3base_llms' ) as $n ) { wp_cache_delete( $n, 'options' ); }
	f3b_e_exige( 'SEGREDO-UX-180' === F3Base_Options::ler( 'f3base_meta_capi_token' ) && 'sim' === F3Base_Options::ler( 'f3base_llms' )['futuro_preservado'], 'Salvar a tela apagou segredo ou campo não exposto.' );
	$recusa = F3Base_Options::gravar( 'f3base_retencao_meses', 0 ); $recusa['rotulo'] = 'Prazo de guarda';
	f3b_e_exige( 'error' === F3Base_Admin_Tela::confirmacao( array( $recusa ) )['nivel'], 'Falha de persistência foi apresentada como confirmação.' );
	$filtro = static function( $c ) { $c['f3base_contato']['apos_escrita'] = static fn() => array( 'ok' => false, 'motivo' => 'Efeito controlado.' ); return $c; };
	add_filter( 'f3base_options_catalogo', $filtro ); f3b_170_reset_catalogo();
	try {
		$r = F3Base_Options::gravar( 'f3base_contato', F3Base_Options::ler( 'f3base_contato' ) ); $r['rotulo'] = 'Contato';
		f3b_e_exige( $r['persisted'] && 'warning' === F3Base_Admin_Tela::confirmacao( array( $r ) )['nivel'], 'Falha do efeito foi escondida pela confirmação simples.' );
	} finally { remove_filter( 'f3base_options_catalogo', $filtro ); f3b_170_reset_catalogo(); }
	wp_set_current_user( 0 ); $links = array( 'teste' => 'Ação existente' );
	f3b_e_exige( $links === F3Base_Admin_Tela::links_de_acao( $links ), 'Atalho de configuração foi oferecido sem permissão.' );
	return array( 'OK', 'Plugins instalados, atalhos, Salvar em cada seção, persistência entre seções, confirmação concisa, recusa, segredo e navegação móvel conferidos.' );
}
function f3b_180_medicao(): array {
	global $wpdb;
	[ $m, , , , $dir ] = f3b_e_fixture(); $m->somar();
	$agora = '[' . gmdate( 'd/M/Y:H:i:s' ) . ' +0000]';
	file_put_contents( $dir . '/access.log', str_replace( '[06/Sep/2026:12:00:00 +0000]', $agora, f3b_e_log( 'Chrome', '/' ) ) );
	F3Base_Options::gravar( 'f3base_comportamento', array_replace( F3Base_Options::ler( 'f3base_comportamento' ), array( 'ligado' => true ) ) );
	F3Base_Modulo_Comportamento::criar_tabela();
	F3Base_Modulo_Comportamento::somar( gmdate( 'Y-m-d' ), '/', 'f3base_pagina_vista', '', 1, 0.0 );
	$apelido = f3b_bancada_apelido( 'ux-180' ); $base = time() - 120;
	foreach ( array( 1, 2 ) as $n ) {
		f3b_e_exige( false !== $wpdb->insert( $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA_EVENTOS, array( 'visitante' => $apelido, 'sessao' => $apelido, 'dia' => gmdate( 'Y-m-d', $base ), 'criado_em' => $base + $n, 'ms' => $n * 1000, 'ancora' => 'visitante', 'caminho' => '/' . str_repeat( 'caminho-longo-', 12 ), 'metrica' => 'f3base_secao_vista', 'detalhe' => 'abertura', 'valor' => 0, 'ocorrencia' => $n ) ), 'Dados da tela não foram preparados: ' . $wpdb->last_error );
	}
	f3b_180_navegador( 'medicao' );
	return array( 'OK', 'Medição em desktop e celular: largura integral, tabelas com rolagem interna, filtros, classificação e coleta preservados.' );
}
