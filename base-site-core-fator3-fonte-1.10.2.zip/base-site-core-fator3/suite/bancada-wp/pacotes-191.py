"""Build de produção do canal + auditoria estrutural dos dois ZIPs. Sem dependência externa."""
from pathlib import Path, PurePosixPath
import argparse, json, zipfile
SILENCE=b'<?php\n// Silence is golden.\n'
def allowed(name):
    parts=PurePosixPath(name.lower()).parts
    return not set(parts)&{'docs','maintenance'} and parts[-1] not in {'readme.md','changelog.md','instrucoes-do-plugin.md'}
def build(source, archive):
    files={p.relative_to(source).as_posix():p.read_bytes() for p in source.rglob('*') if p.is_file() and allowed(p.relative_to(source).as_posix())}
    dirs={PurePosixPath('.')}
    for name in files:
        dirs.update(PurePosixPath(name).parents)
    for d in dirs:files.setdefault(str(d/'index.php'),SILENCE)
    archive.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(files.items()):
            i=zipfile.ZipInfo(source.name+'/'+name,date_time=(2020,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16
            z.writestr(i,data,compresslevel=9)
def audit(archive):
    with zipfile.ZipFile(archive) as z:
        files={x for x in z.namelist() if not x.endswith('/')}
        roots={PurePosixPath(x).parts[0] for x in files}
        assert len(roots)==1,roots
        root=next(iter(roots));dirs=set()
        for f in files:
            assert allowed(f),'Documento de produção proibido: '+f
            dirs.update(str(x) for x in PurePosixPath(f).parents if str(x)!='.')
        for d in dirs:
            assert d+'/index.php' in files,'Diretório sem silêncio: '+d
            assert z.read(d+'/index.php').strip()==SILENCE.strip(),'Índice não é de silêncio: '+d
        if root=='base-site-core-fator3':
            deny=z.read(root+'/dados/.htaccess').decode()
            assert 'Require all denied' in deny and 'Deny from all' in deny and 'php_flag' not in deny and 'Options' not in deny
        return {'arquivo':archive.name,'arquivos':len(files),'pastas_com_index':len(dirs),'documentos_excluidos':True}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archives',nargs='*',type=Path);p.add_argument('--source',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
    if a.source:build(a.source.resolve(),a.out.resolve());a.archives.append(a.out)
    print(json.dumps([audit(x) for x in a.archives],ensure_ascii=False,indent=2))
