<?php
/** Casos novos em WordPress real. Só o fixture local pode incluir este arquivo. */
if (!defined('F3BASE_BANCADA_192') || wp_parse_url(home_url(), PHP_URL_HOST)!=='127.0.0.1') {throw new RuntimeException('Exige fixture local.');}
require_once __DIR__.'/cache-fixture.php';
function c192_assert($ok,$msg) {if(!$ok)throw new RuntimeException($msg);}
function c192_write($key,$value) {$f=F3Base_Options::fotografia($key);$r=F3Base_Options::gravar($key,$value,F3Base_Options::ORIGEM_PADRAO,$f['revisao']);c192_assert($r['persisted'],'Fixture recusada: '.$key);return $r;}
function c192_agenda($ts) {wp_clear_scheduled_hook(F3Base_Cache_Pagina::CRON);if($ts)wp_schedule_event($ts,'hourly',F3Base_Cache_Pagina::CRON);}
function c192_num_eventos() {$n=0;foreach(_get_cron_array() as $h){$n+=count($h[F3Base_Cache_Pagina::CRON]??array());}return $n;}
function c192_reset() {
    F3Base_Cache_Pagina::concluir();
    $e=F3Base_Cache_Pagina::estado();$e['versao']=F3BASE_PLUGIN_VERSAO;$e['geracao']=wp_generate_uuid4();$e['pendente']=false;$e['limpo_em']=0;$e['codigo']='';c192_write(F3Base_Cache_Pagina::ESTADO,$e);
    c192_write(F3Base_Cache_Evidencia::OPTION,array());c192_write(F3Base_Cache_Evidencia::TRAVAS,array());c192_agenda(time()+3600);
}
function c192_seed($age=90) {
    $p=array('contexto'=>F3Base_Cache_Pagina::contexto(),'geracao'=>F3Base_Cache_Pagina::estado()['geracao'],'plugin_version'=>F3BASE_PLUGIN_VERSAO,'origem'=>'fixture_de_estado','checked_at'=>time()-$age,'status'=>'verified','codigo'=>'fixture_de_estado','motivo'=>'Estado sem prova HTTP para testar leitura e invalidação.','persisted'=>true);
    c192_write(F3Base_Cache_Evidencia::OPTION,array('ultima_tentativa'=>$p,'ultimo_sucesso'=>$p));return F3Base_Cache_Evidencia::ler()['ultima_tentativa'];
}
function c192_snapshot() {$r=array();foreach(array(F3Base_Cache_Evidencia::OPTION,F3Base_Cache_Evidencia::TRAVAS,F3Base_Cache_Pagina::ESTADO) as $k){$r[$k]=F3Base_Options::fotografia($k);} $r['cron']=_get_cron_array();return $r;}
function c192_ability($name,$args) {
    $a=wp_get_ability($name);c192_assert($a instanceof WP_Ability,'Habilidade não registrada.');$avisos=array();
    set_error_handler(static function($n,$m)use(&$avisos){$avisos[]=$m;return true;});
    try{$r=$a->execute($args);c192_assert(!is_wp_error($r),'Habilidade recusou: '.(is_wp_error($r)?$r->get_error_message():''));c192_assert(true===rest_validate_value_from_schema($r,$a->get_output_schema()),'Schema nativo recusou.');$s=rest_sanitize_value_from_schema($r,$a->get_output_schema());c192_assert($r===$s,'Sanitização mudou saída.');}finally{restore_error_handler();}
    c192_assert(!$avisos,'Avisos: '.implode('; ',$avisos));return $r;
}
function c192_readonly() {
    $result=array();
    foreach(array('ausente','valida','expirada','configuracao','sem_agenda','cron_atrasado') as $cenario){
        c192_reset();if($cenario!=='ausente')c192_seed($cenario==='expirada'?3700:90);
        if($cenario==='configuracao'){F3Base_Cache_Evidencia::alterar(static function($v){$v['ultima_tentativa']['contexto']=str_repeat('0',64);return $v;});}
        if($cenario==='sem_agenda'){c192_write(F3Base_Cache_Evidencia::OPTION,array());c192_agenda(0);}
        if($cenario==='cron_atrasado'){c192_write(F3Base_Cache_Evidencia::OPTION,array());c192_agenda(time()-601);}
        $antes=c192_snapshot();$http=0;$purga=0;
        $hf=static function($r)use(&$http){++$http;return new WP_Error('fixture_bloqueou','Leitura não pode fazer HTTP.');};$pf=static function()use(&$purga){++$purga;};
        add_filter('pre_http_request',$hf,999);add_action('wp_cache_cleared',$pf);
        try{
            $contrato=c192_ability(F3Base_Config_Contrato::HABILIDADE,array());
            $consulta=c192_ability(F3Base_Config_Contrato::VERIFICAR,array('nome'=>'f3base_cabecalhos','acao'=>'consultar'));
            $metodo=new ReflectionMethod('F3Base_Admin_Tela','render_cache');$metodo->setAccessible(true);$met=$_SERVER['REQUEST_METHOD'];$_SERVER['REQUEST_METHOD']='GET';ob_start();try{$metodo->invoke(null);$html=ob_get_contents();}finally{ob_end_clean();$_SERVER['REQUEST_METHOD']=$met;}
        }finally{remove_filter('pre_http_request',$hf,999);remove_action('wp_cache_cleared',$pf);}
        c192_assert($http===0&&$purga===0&&$antes===c192_snapshot(),'Consulta modificou estado em '.$cenario);
        $esperados=array('ausente'=>'nunca_verificado','valida'=>'fixture_de_estado','expirada'=>'evidencia_expirada','configuracao'=>'configuracao_alterada','sem_agenda'=>'agendamento_ausente','cron_atrasado'=>'cron_atrasado');
        c192_assert($consulta['verification']['codigo']===$esperados[$cenario],$cenario.': '.$consulta['verification']['codigo']);
        $result[$cenario]=array('http'=>0,'purgas'=>0,'estado_e_agenda_inalterados'=>true,'codigo'=>$consulta['verification']['codigo'],'tela_renderizada'=>str_contains($html,'Última tentativa registrada'),'contract_version'=>$contrato['contract_version']);
    }
    c192_reset();return $result;
}
function c192_run($action,$d) {
    wp_set_current_user(1);
    if($action==='ler')return c192_ability(F3Base_Config_Contrato::VERIFICAR,array('nome'=>'f3base_cabecalhos','acao'=>'consultar'));
    if($action==='consultas')return c192_readonly();
    if($action==='reset'){c192_reset();F3Base_Cache_Pagina::limpar(false);return F3Base_Cache_Pagina::resumo();}
    if($action==='verificar'){
        if(!empty($d['lenta'])){add_filter('pre_http_request',static function($r){static $n=0;if(++$n===1){usleep(1500000);}return $r;},1);}
        $a=array('nome'=>'f3base_cabecalhos','acao'=>$d['acao_habilidade']??'verificar_publico','revisao_esperada'=>F3Base_Options::revisao('f3base_cabecalhos'));
        return c192_ability(F3Base_Config_Contrato::VERIFICAR,$a);
    }
    if($action==='preservar'){
        c192_reset();$p=c192_seed();$hash=hash('sha256',serialize($p));F3Base_Cache_Pagina::solicitar();$r=F3Base_Cache_Pagina::limpar();$v=F3Base_Cache_Pagina::resumo();
        c192_assert($r['ok']&&!$v['evidencia']&&$v['verification']['codigo']==='aguardando_verificacao_apos_limpeza','Não invalidou prova atual.');
        c192_assert(hash('sha256',serialize($v['historico']['ultima_tentativa']))===$hash&&$v['historico']['ultimo_sucesso']===$p,'Histórico apagado.');
        $ts=wp_next_scheduled(F3Base_Cache_Pagina::CRON);
        for($i=0;$i<4;++$i){F3Base_Cache_Pagina::solicitar();F3Base_Cache_Pagina::limpar();}
        c192_assert(c192_num_eventos()===1&&wp_next_scheduled(F3Base_Cache_Pagina::CRON)===$ts&&$ts<=time()+F3Base_Cache_Evidencia::JANELA,'Não agrupou limpezas.');
        return array('historico_preservado'=>true,'geracao_atual_validada'=>false,'codigo'=>$v['verification']['codigo'],'eventos'=>c192_num_eventos(),'ate_execucao'=>$ts-time());
    }
    if($action==='migrar'){
        c192_reset();$p=c192_seed();F3Base_Options::remover(F3Base_Cache_Evidencia::OPTION);set_transient(F3Base_Cache_Pagina::PROVA,$p,3600);
        $antes=c192_snapshot();c192_ability(F3Base_Config_Contrato::HABILIDADE,array());c192_assert($antes===c192_snapshot(),'Consulta migrou.');
        c192_assert(F3Base_Cache_Evidencia::migrar(),'Migração recusou.');$v=F3Base_Cache_Evidencia::ler();c192_assert($v['ultima_tentativa']['checked_at']===$p['checked_at']&&$v['migracao']['codigo']==='evidencia_legada_preservada','Legado disponível perdido.');
        c192_write(F3Base_Cache_Evidencia::OPTION,array());set_transient(F3Base_Cache_Pagina::PROVA,$p,3600);F3Base_Cache_Evidencia::migrar();$v=F3Base_Cache_Evidencia::ler();c192_assert($v['ultima_tentativa']['checked_at']===$p['checked_at']&&$v['migracao']['codigo']==='evidencia_legada_preservada','Padrão semeado na ativação impediu migração.');
        F3Base_Options::remover(F3Base_Cache_Evidencia::OPTION);delete_transient(F3Base_Cache_Pagina::PROVA);F3Base_Cache_Evidencia::migrar();$v=F3Base_Cache_Evidencia::ler();c192_assert(!$v['ultima_tentativa']&&$v['migracao']['codigo']==='historico_anterior_indisponivel','Histórico foi inventado.');
        return array('consulta_nao_migra'=>true,'legado_preservado'=>true,'padrao_semeado_migra'=>true,'ausencia_declarada'=>true);
    }
    if($action==='falhas'){
        $out=array();c192_reset();$p=c192_seed();
        $refusar=static fn()=>new WP_Error('fixture_agenda','Recusa controlada');add_filter('pre_schedule_event',$refusar,99);
        try{$ok=F3Base_Cache_Evidencia::agendar(time()+2,'fixture',false);}finally{remove_filter('pre_schedule_event',$refusar,99);}
        c192_assert(!$ok&&F3Base_Cache_Evidencia::agenda()['codigo']==='agendamento_falhou'&&c192_num_eventos()===1,'Recusa não diagnosticada ou apagou agenda anterior.');$out['agendamento']=F3Base_Cache_Evidencia::agenda()['codigo'];
        c192_reset();c192_seed();$f=static function(){throw new RuntimeException('Falha controlada do provedor.');};add_action('wp_cache_cleared',$f);
        try{F3Base_Cache_Pagina::solicitar();$r=F3Base_Cache_Pagina::limpar();}finally{remove_action('wp_cache_cleared',$f);}
        c192_assert(!$r['ok']&&!$r['applied']&&F3Base_Cache_Pagina::estado()['pendente']&&F3Base_Cache_Evidencia::ler()['ultimo_sucesso'],'Purga não preservou diagnóstico/histórico.');$out['purga']=$r['codigo'];
        c192_reset();$p=c192_seed();$n=0;$f=static function($r)use(&$n){++$n;return new WP_Error('http_request_failed','Rede indisponível controlada.');};add_filter('pre_http_request',$f,99);
        try{$r=F3Base_Cache_Pagina::verificar_publico();$n1=$n;F3Base_Cache_Pagina::verificar_publico();}finally{remove_filter('pre_http_request',$f,99);}
        c192_assert($r['codigo']==='http_indisponivel'&&$r['persisted']&&$n1===$n&&F3Base_Cache_Evidencia::ler()['ultimo_sucesso']===$p,'Falha HTTP apagou histórico ou disparou laço.');$out['http']=array('codigo'=>$r['codigo'],'chamadas'=>$n,'sem_repeticao_imediata'=>true);
        c192_reset();c192_seed();$f=static function($r,$args,$url){
            if($url!==home_url('/'))return $r;
            return array('headers'=>new \WpOrg\Requests\Utility\CaseInsensitiveDictionary((new F3Base_Modulo_Cabecalhos())->lista_de_cabecalhos()),'body'=>'<!-- F3BASE-CACHE-PROBE:'.wp_generate_uuid4().' F3BASE-CONFIG:'.F3Base_Cache_Pagina::contexto().' -->','response'=>array('code'=>200,'message'=>'Fixture sem HIT'));
        };add_filter('pre_http_request',$f,99,3);
        try{$r=F3Base_Cache_Pagina::verificar_publico();}finally{remove_filter('pre_http_request',$f,99);}
        c192_assert($r['codigo']==='hit_nao_comprovado'&&$r['status']==='pending'&&$r['persisted'],'Ausência de HIT: '.wp_json_encode(array_intersect_key($r,array_flip(array('status','codigo','persisted','motivo')))));$out['sem_hit']=$r['codigo'];
        c192_reset();
        // Recusa real pelo filtro WordPress antes da API de options persistir o início.
        $bloquear=static fn($new,$old)=>$old;add_filter('pre_update_option_'.F3Base_Cache_Evidencia::OPTION,$bloquear,99,2);$n=0;$hf=static function($r)use(&$n){++$n;return $r;};add_filter('pre_http_request',$hf,99);
        try{$r=F3Base_Cache_Pagina::verificar_publico();}finally{remove_filter('pre_update_option_'.F3Base_Cache_Evidencia::OPTION,$bloquear,99);remove_filter('pre_http_request',$hf,99);}
        c192_assert(!$r['persisted']&&$n===0,'Sonda executada apesar da recusa do início.');$out['persistencia']=array('codigo'=>$r['codigo'],'http'=>$n);
        c192_reset();c192_seed();F3Base_Cache_Evidencia::alterar(static function($v){$v['execucao']['falhas']=9;return $v;});
        $f=static fn()=>new WP_Error('rede_controlada','Sem transporte');add_filter('pre_http_request',$f,99);
        try{F3Base_Cache_Pagina::verificar_publico();}finally{remove_filter('pre_http_request',$f,99);}
        $v=F3Base_Cache_Evidencia::ler();$espera=$v['execucao']['proxima_tentativa']-time();
        c192_assert($espera<=F3Base_Cache_Evidencia::MAX_RECUO&&$espera>=F3Base_Cache_Evidencia::MAX_RECUO-2,'Recuo não limitado.');$out['recuo_maximo_segundos']=$espera;
        c192_reset();return $out;
    }
    if($action==='mudanca_durante_sonda'){
        c192_reset();c192_seed();$old=F3Base_Cache_Evidencia::ler()['ultimo_sucesso'];
        $f=static function($r){static $n=0;if(++$n===2){F3Base_Cache_Pagina::solicitar();F3Base_Cache_Pagina::limpar();}return $r;};add_filter('pre_http_request',$f,99);
        try{$p=F3Base_Cache_Pagina::verificar_publico();}finally{remove_filter('pre_http_request',$f,99);}
        c192_assert($p['status']==='pending'&&!F3Base_Cache_Pagina::prova()&&F3Base_Cache_Evidencia::ler()['ultimo_sucesso']===$old,'Publicou sucesso de geração obsoleta.');return array('codigo'=>$p['codigo'],'geracao_obsoleta_nao_promovida'=>true,'eventos'=>c192_num_eventos());
    }
    if($action==='lease_expirada'){
        c192_reset();c192_write(F3Base_Cache_Evidencia::TRAVAS,array('sonda'=>array('id'=>'processo_morto','ate'=>time()-1)));
        $p=F3Base_Cache_Pagina::verificar_publico();c192_assert($p['persisted']&&$p['id']!=='processo_morto'&&empty(F3Base_Cache_Evidencia::trava('sonda')['id']),'Lease antiga bloqueou execução.');return array('persisted'=>true,'codigo'=>$p['codigo'],'trava_liberada'=>true);
    }
    if($action==='cron_preparar'){
        c192_reset();F3Base_Cache_Pagina::limpar(false);
        foreach(_get_cron_array() as $ts=>$hooks){foreach($hooks as $h=>$events){foreach($events as $ev){wp_unschedule_event($ts,$h,$ev['args']);}}}
        c192_agenda(time()-10);delete_transient('doing_cron');return array('eventos'=>c192_num_eventos(),'disabled'=>defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON);
    }
    if($action==='cron_manual'){do_action(F3Base_Cache_Pagina::CRON);return F3Base_Cache_Pagina::resumo();}
    throw new RuntimeException('Ação desconhecida.');
}
