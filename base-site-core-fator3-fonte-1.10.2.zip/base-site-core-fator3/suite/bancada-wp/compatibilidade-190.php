<?php
require_once __DIR__ . '/cache-fixture.php';
/** Operações da homologação: executar apenas no WordPress descartável da bancada. */
if ( ! defined( 'WP_CLI' ) || ! WP_CLI || '127.0.0.1' !== wp_parse_url( home_url(), PHP_URL_HOST ) ) { throw new RuntimeException( 'Exige bancada local descartável.' ); }
function f3b190_exige( $ok, string $mensagem ): void { if ( ! $ok ) { throw new RuntimeException( $mensagem ); } }
function f3b190_gravar( string $nome, array $v ): array {
	$r = F3Base_Options::gravar( $nome, array_replace( F3Base_Options::ler( $nome ), $v ), F3Base_Options::ORIGEM_PADRAO );
	f3b190_exige( $r['persisted'], 'Gravação recusada: ' . $nome . ' ' . wp_json_encode( $r ) ); return $r;
}
function f3b190_rest( string $rota, string $metodo = 'GET', array $corpo = array() ): WP_REST_Response {
	$p = new WP_REST_Request( $metodo, $rota );
	if ( 'GET' === $metodo ) { $p->set_query_params( $corpo ); } else { $p->set_header( 'Content-Type', 'application/json' ); $p->set_body( wp_json_encode( $corpo ) ); }
	return rest_do_request( $p );
}
function f3b190_executar( string $acao, array $dados ): array {
	global $wpdb, $wp_version;
	wp_set_current_user( 1 );
	if ( 'snapshot' === $acao ) {
		$valores = array();
		foreach ( F3Base_Options::catalogo() as $nome => $def ) {
			if ( ! empty( $def['interno'] ) || str_starts_with( $nome, 'f3base_cache_' ) ) { continue; }
			$valores[ $nome ] = F3Base_Options::revisao( $nome );
		}
		return array( 'preferencias' => $valores, 'leads' => (array) wp_count_posts( 'f3base_lead' ) );
	}
	if ( 'limpar_nativo' === $acao ) {
		f3b190_exige( function_exists( 'wp_cache_clear_cache' ), 'Provedor não oferece limpeza.' );
		wp_cache_clear_cache(); return array( 'solicitada' => true );
	}
	if ( 'preparar' === $acao ) {
		$ids = array();
		foreach ( array( 'inicio', 'publico', 'excluir', 'noindex', 'alias' ) as $slug ) {
			$p = get_page_by_path( $slug );
			$ids[ $slug ] = $p ? $p->ID : wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => 'Conteúdo ' . $slug, 'post_content' => '<p>Texto integral verificável ' . $slug . '.</p><section id="atencao"><a href="#" data-f3base-lead="primeiro">Conversar</a><a href="#" data-f3base-lead="segundo">Outro contato</a></section>' ), true );
			f3b190_exige( ! is_wp_error( $ids[ $slug ] ), 'Não criou a página ' . $slug );
			wp_update_post( array( 'ID' => $ids[ $slug ], 'post_status' => 'publish', 'post_password' => '' ) );
			delete_post_meta( $ids[ $slug ], '_yoast_wpseo_meta-robots-noindex' ); delete_post_meta( $ids[ $slug ], '_yoast_wpseo_canonical' );
		}
		f3b190_gravar( 'f3base_contato', array( 'whatsapp_e164' => '5511999999999', 'flutuante' => true ) );
		f3b190_gravar( 'f3base_llms', array( 'ligado' => true, 'full' => true, 'markdown' => true ) );
		f3b190_gravar( 'f3base_comportamento', array( 'ligado' => true ) );
		if ( class_exists( 'WPSEO_Options' ) ) { WPSEO_Options::set( 'enable_llms_txt', false ); WPSEO_Options::set( 'enable_xml_sitemap', true ); }
		if ( function_exists( 'YoastSEO' ) ) { foreach ( $ids as $id ) { YoastSEO()->classes->get( Yoast\WP\SEO\Builders\Indexable_Builder::class )->build_for_id_and_type( $id, 'post' ); } }
		F3Base_Cache_Pagina::limpar();
		return array( 'ids' => $ids, 'wp' => $wp_version, 'php' => PHP_VERSION, 'core' => F3BASE_PLUGIN_VERSAO, 'yoast' => defined( 'WPSEO_VERSION' ) ? WPSEO_VERSION : '', 'cache' => is_plugin_active( 'wp-super-cache/wp-cache.php' ) ? get_plugin_data( WP_PLUGIN_DIR . '/wp-super-cache/wp-cache.php' )['Version'] : '', 'perfil' => F3Base_Cache_Pagina::perfil() );
	}
	if ( 'modo' === $acao ) {
		global $cache_rejected_uri;
		$modo = $dados['modo'];
		$exclusoes = array_values( array_unique( array_merge( (array) $cache_rejected_uri, array( '/reserva-operador/' ), F3Base_Cache_Pagina::exclusoes() ) ) );
		$r = f3b190_rest( '/wp-super-cache/v1/settings', 'POST', array( 'is_cache_enabled' => $modo !== 'desligado', 'is_super_cache_enabled' => 'expert' === $modo ? 1 : 2, 'wpsc_save_headers' => 'cabecalhos' === $modo ? 1 : 0, 'dont_cache_logged_in' => 1, 'cache_rebuild' => 0, 'cache_compression' => 0, 'cache_rejected_uri' => $exclusoes ) );
		f3b190_exige( 200 === $r->get_status(), 'API nativa recusou modo.' );
		f3b190_exige( ! array_diff( $exclusoes, (array) $cache_rejected_uri ), 'Exclusões não foram persistidas pelo dono.' );
		F3Base_Cache_Pagina::solicitar(); $limpeza = F3Base_Cache_Pagina::limpar();
		return array( 'resposta' => $r->get_data(), 'limpeza' => $limpeza, 'perfil' => F3Base_Cache_Pagina::perfil() );
	}
	if ( 'prova' === $acao ) { f3b_fixture_cache(); return F3Base_Cache_Pagina::verificar_publico(); }
	if ( 'estado' === $acao ) { return F3Base_Cache_Pagina::resumo(); }
	if ( 'token_velho' === $acao ) {
		$expira = time() - 7200;
		$m = new ReflectionMethod( F3Base_Modulo_Endpoint_Leads::class, 'assinar' );
		return array( 'token' => $expira . '.' . $m->invoke( null, $expira . '|' . F3Base_Modulo_Endpoint_Leads::escopo_do_token( '/' ) ) );
	}
	if ( 'limpar' === $acao ) { F3Base_Cache_Pagina::solicitar(); return F3Base_Cache_Pagina::limpar(); }
	if ( 'schema_yoast' === $acao ) {
		f3b190_exige( function_exists( 'YoastSEO' ), 'O teste exige o Yoast real.' );
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$logo = wp_upload_bits( 'logo-bancada-190.png', null, file_get_contents( ABSPATH . WPINC . '/images/w-logo-blue.png' ) );
		f3b190_exige( empty( $logo['error'] ), 'Não criou o logo exigido pelo Yoast.' );
		$anexo = wp_insert_attachment( array( 'post_mime_type' => 'image/png', 'post_title' => 'Logo da bancada', 'post_status' => 'inherit' ), $logo['file'] );
		wp_update_attachment_metadata( $anexo, wp_generate_attachment_metadata( $anexo, $logo['file'] ) );
		WPSEO_Options::set( 'company_logo_id', $anexo ); WPSEO_Options::set( 'company_logo', $logo['url'] );
		WPSEO_Options::set( 'company_or_person', 'company' ); WPSEO_Options::set( 'company_name', 'Organização da bancada' );
		$servico = array( 'nome' => 'Serviço da bancada', 'descricao' => 'Descrição pública.' );
		f3b190_gravar( 'f3base_seo_entidade', array( 'faq_schema' => true, 'servicos' => array( $servico, $servico ) ) );
		$conteudo = '<!-- wp:yoast/faq-block {"questions":[{"id":"faq-question-190","jsonQuestion":"Pergunta do Yoast?","jsonAnswer":"Resposta do Yoast."}]} --><div class="schema-faq"><p>Pergunta do Yoast?</p><p>Resposta do Yoast.</p></div><!-- /wp:yoast/faq-block -->';
		$conteudo .= '<!-- wp:details {"summary":"Pergunta do Core?"} --><details><summary>Pergunta do Core?</summary><!-- wp:paragraph --><p>Resposta do Core.</p><!-- /wp:paragraph --></details><!-- /wp:details -->';
		$p = get_page_by_path( 'faq-190' );
		$id = wp_insert_post( array( 'ID' => $p ? $p->ID : 0, 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'faq-190', 'post_title' => 'FAQ dos dois plugins', 'post_content' => $conteudo ), true );
		f3b190_exige( ! is_wp_error( $id ) && count( F3Base_Modulo_Schema_Extensao::faq_da_pagina( $id ) ) === 1, 'Fixture não exercita o FAQ do Core.' );
		YoastSEO()->classes->get( Yoast\WP\SEO\Builders\Indexable_Builder::class )->build_for_id_and_type( $id, 'post' );
		F3Base_Cache_Pagina::limpar();
		return array( 'url' => get_permalink( $id ), 'yoast' => WPSEO_VERSION );
	}
	if ( 'contato' === $acao ) { return f3b190_gravar( 'f3base_contato', $dados ); }
	if ( 'quota' === $acao ) {
		// Origem exclusiva desta rodada: os limites continuam sendo os padrões do plugin.
		$_SERVER['REMOTE_ADDR'] = '192.0.2.' . random_int( 1, 254 );
		wp_set_current_user( 0 ); $codigos = array(); $inicio = microtime( true );
		for ( $i = 0; $i < 20; ++$i ) {
			$r = f3b190_rest( '/f3base/v1/token', 'GET', array( 'pagina' => '/' ) );
			f3b190_exige( 200 === $r->get_status(), 'Renovação recusada antes dos 20 registros.' ); $token = $r->get_data()['token'];
			$p = f3b190_rest( '/f3base/v1/lead', 'POST', array( 'token' => $token, 'correlation_id' => 'c190_' . bin2hex( random_bytes( 8 ) ), 'pagina' => '/' ) );
			$codigos[] = $p->get_status(); f3b190_exige( $p->get_status() < 300, 'Renovação consumiu cota: ' . wp_json_encode( $p->get_data() ) );
		}
		$p = f3b190_rest( '/f3base/v1/lead', 'POST', array( 'token' => $token, 'correlation_id' => 'c190_' . bin2hex( random_bytes( 8 ) ), 'pagina' => '/' ) );
		f3b190_exige( 429 === $p->get_status(), '21º registro não respeitou o limite.' );
		for ( $i = 20; $i < 60; ++$i ) { f3b190_exige( 200 === f3b190_rest( '/f3base/v1/token' )->get_status(), 'Emissão não respeita sua própria cota.' ); }
		$t = f3b190_rest( '/f3base/v1/token' ); f3b190_exige( 429 === $t->get_status(), '61ª emissão não foi limitada.' );
		return array( 'registros' => $codigos, 'registro_seguinte' => $p->get_status(), 'emissao_seguinte' => $t->get_status(), 'limite' => F3Base_Modulo_Endpoint_Leads::limite_token(), 'segundos' => microtime( true ) - $inicio );
	}
	if ( 'cache_contrato' === $acao ) {
		F3Base_Cache_Pagina::limpar(); $antes = F3Base_Cache_Pagina::estado()['geracao'];
		$lead = wp_insert_post( array( 'post_type' => 'f3base_lead', 'post_status' => 'private', 'post_title' => 'Fixture interno' ) ); update_post_meta( $lead, 'teste190', 'privado' );
		F3Base_Modulo_Comportamento::somar( gmdate( 'Y-m-d' ), '/', 'f3base_pagina_vista', '', 1, 0 );
		f3b190_exige( $antes === F3Base_Cache_Pagina::estado()['geracao'] && ! F3Base_Cache_Pagina::estado()['pendente'], 'Lead/métrica invalidou páginas.' );
		$anterior = F3Base_Options::ler( 'f3base_contato' );
		$filtro = static fn() => $anterior;
		add_filter( 'pre_update_option_f3base_contato', $filtro );
		try { $r = F3Base_Options::gravar( 'f3base_contato', array_replace( $anterior, array( 'whatsapp_e164' => '5511888888888' ) ) ); } finally { remove_filter( 'pre_update_option_f3base_contato', $filtro ); }
		f3b190_exige( ! $r['persisted'] && $antes === F3Base_Cache_Pagina::estado()['geracao'], 'Recusa disparou efeito de cache.' );
		$novo = f3b190_gravar( 'f3base_contato', array( 'mensagem_padrao' => 'Alteração ' . wp_generate_uuid4() ) );
		if ( F3Base_Cache_Pagina::perfil()['ativo'] ) { f3b190_exige( $novo['persisted'] && ! $novo['effect']['applied'] && $novo['verification']['pending'], 'Persistência/efeito/verificação misturados.' ); }
		$avisos = array(); $contrato = null;
		set_error_handler( static function( $n, $m ) use ( &$avisos ) { $avisos[] = $m; return false; } );
		try {
			foreach ( array( 'f3base/config-core-contrato-v1' => array(), 'f3base/config-core-verificar' => array( 'nome' => 'f3base_cabecalhos' ) ) as $nome => $entrada ) {
				$a = wp_get_ability( $nome ); f3b190_exige( $a instanceof WP_Ability, 'Habilidade não registrada: ' . $nome );
				$x = $a->execute( $entrada ); f3b190_exige( ! is_wp_error( $x ), 'Habilidade falhou: ' . $nome );
				f3b190_exige( true === rest_validate_value_from_schema( $x, $a->get_output_schema() ), 'Saída viola schema.' );
				f3b190_exige( $x === rest_sanitize_value_from_schema( $x, $a->get_output_schema() ), 'Sanitização altera tipos.' );
				if ( isset( $x['contract_version'] ) ) { $contrato = $x['contract_version']; }
			}
			$revisao = F3Base_Options::revisao( 'f3base_cabecalhos' );
			$a = wp_get_ability( 'f3base/config-core-verificar' );
			$x = $a->execute( array( 'nome' => 'f3base_cabecalhos', 'acao' => 'atualizar_cache', 'revisao_esperada' => $revisao ) );
			f3b190_exige( ! is_wp_error( $x ) && $x['ok'] && $x['efeito_repetido'] && ! $x['configuracao_alterada'] && 'verified' === $x['verification']['status'], 'Operação ativa não confirmou a entrega: ' . wp_json_encode( $x ) );
			f3b190_exige( $revisao === F3Base_Options::revisao( 'f3base_cabecalhos' ) && $x === rest_sanitize_value_from_schema( $x, $a->get_output_schema() ), 'Verificação regravou preferência ou perdeu tipos.' );
		} finally { restore_error_handler(); }
		f3b190_exige( ! $avisos, 'Avisos nativos: ' . implode( '; ', $avisos ) );
		return array( 'sem_purge_de_eventos' => true, 'recusa_sem_purge' => true, 'escrita' => $novo, 'contrato' => $contrato, 'avisos' => $avisos );
	}
	if ( 'exclusoes' === $acao ) {
		$f = static fn() => 'api-personalizada'; add_filter( 'rest_url_prefix', $f );
		$home = static fn( $v ) => $v . '/subsite'; add_filter( 'option_home', $home ); add_filter( 'option_siteurl', $home );
		try { $r = F3Base_Cache_Pagina::exclusoes(); } finally { remove_filter( 'rest_url_prefix', $f ); remove_filter( 'option_home', $home ); remove_filter( 'option_siteurl', $home ); }
		f3b190_exige( in_array( '/subsite/api-personalizada/f3base/v1/', $r, true ), 'Prefixo ou subdiretório perdido.' );
		$simples = static fn() => ''; add_filter( 'option_permalink_structure', $simples );
		try { $q = F3Base_Cache_Pagina::exclusoes(); } finally { remove_filter( 'option_permalink_structure', $simples ); }
		f3b190_exige( ! in_array( '/', $q, true ) && in_array( 'rest_route=/f3base/v1', $q, true ), 'Exclusão REST simples desliga o cache inteiro.' );
		return array( 'caminhos' => $r, 'permalinks_simples' => $q );
	}
	if ( 'publicacao' === $acao ) {
		$id = (int) $dados['id']; $tipo = $dados['tipo'];
		if ( 'privado' === $tipo ) { wp_update_post( array( 'ID' => $id, 'post_status' => 'private' ) ); }
		elseif ( 'senha' === $tipo ) { wp_update_post( array( 'ID' => $id, 'post_password' => 'fixture' ) ); }
		elseif ( 'excluir' === $tipo ) { wp_delete_post( $id, true ); }
		elseif ( 'noindex' === $tipo ) { update_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', '1' ); }
		elseif ( 'alias' === $tipo ) { update_post_meta( $id, '_yoast_wpseo_canonical', get_permalink( (int) $dados['destino'] ) ); }
		else { wp_update_post( array( 'ID' => $id, 'post_status' => 'publish', 'post_password' => '' ) ); }
		if ( function_exists( 'YoastSEO' ) && get_post( $id ) ) { YoastSEO()->classes->get( Yoast\WP\SEO\Builders\Indexable_Builder::class )->build_for_id_and_type( $id, 'post' ); }
		F3Base_Cache_Pagina::concluir();
		return array( 'cache' => F3Base_Cache_Pagina::resumo(), 'seo' => get_post( $id ) ? F3Base_Llms::seo_do_post( $id ) : array() );
	}
	throw new RuntimeException( 'Operação desconhecida: ' . $acao );
}
try {
	$resultado = f3b190_executar( $args[0] ?? '', json_decode( $args[1] ?? '{}', true ) ?: array() );
	echo 'F3B190:' . wp_json_encode( array( 'ok' => true, 'resultado' => $resultado ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n";
} catch ( Throwable $e ) { echo 'F3B190:' . wp_json_encode( array( 'ok' => false, 'erro' => $e->getMessage() ), JSON_UNESCAPED_UNICODE ) . "\n"; WP_CLI::halt( 1 ); }
