<?php
/** Contratos do dono medidos com WordPress real, incluindo persistência seguida de falha. */
declare( strict_types = 1 );

function f3b_170_reset_catalogo(): void {
	$p = new ReflectionProperty( F3Base_Options::class, 'catalogo' ); $p->setAccessible( true ); $p->setValue( null, null );
}
function f3b_170_resultados(): array {
	wp_set_current_user( 1 );
	$n = 'f3base_contato'; $modo = 'ok'; $chamadas = 0;
	$filtro = static function( $c ) use ( &$modo, &$chamadas, $n ) {
		$c[ $n ]['apos_escrita'] = static function() use ( &$modo, &$chamadas ) {
			++$chamadas;
			if ( 'throw' === $modo ) { throw new RuntimeException( 'SEGREDO-QUE-NAO-PODE-SAIR' ); }
			if ( 'invalid' === $modo ) { return null; }
			if ( 'concurrent' === $modo ) { $modo = 'ok'; F3Base_Options::gravar( 'f3base_contato', array( 'mensagem_padrao' => 'outro-escritor' ) ); }
			return array( 'ok' => 'ok' === $modo, 'motivo' => 'Efeito controlado da bancada.' );
		}; return $c;
	};
	add_filter( 'f3base_options_catalogo', $filtro ); f3b_170_reset_catalogo();
	try {
		foreach ( array( 'ok', 'failed', 'throw', 'invalid' ) as $modo ) {
			$foto = F3Base_Options::fotografia( $n ); $valor = $foto['valor']; $valor['mensagem_padrao'] = $modo;
			$r = F3Base_Core_Config_Mcp::escrever( array( 'nome' => $n, 'valor' => $valor, 'revisao_esperada' => $foto['revisao'], 'simular' => false ) );
			f3b_e_exige( true === $r['persisted'] && F3Base_Options::ler( $n )['mensagem_padrao'] === $modo, 'Efeito posterior apagou a confirmação da persistência.' );
			f3b_e_exige( $r['ok'] === ( 'ok' === $modo ) && $r['effect']['applied'] === ( 'ok' === $modo ), 'Compatibilidade de ok ou efeito incorreto.' );
			f3b_e_exige( 'pending' === $r['verification']['status'] && ! str_contains( wp_json_encode( $r ), 'SEGREDO-QUE-NAO-PODE-SAIR' ), 'Prova inventada ou exceção exposta.' );
			if ( 'ok' !== $modo ) { f3b_e_exige( str_contains( F3Base_Admin_Tela::rotulo_da_gravacao( $r ), 'configuração gravada; falha' ), 'Painel confunde efeito com falha de gravação.' ); }
		}
		$antes = F3Base_Options::fotografia( $n ); $proveniencia = get_option( F3Base_Options::OPTION_PROVENIENCIA ); $contador = $chamadas;
		$r = F3Base_Core_Config_Mcp::escrever( array( 'nome' => $n, 'valor' => $antes['valor'], 'revisao_esperada' => $antes['revisao'] ) );
		f3b_e_exige( $r['ok'] && $r['simulado'] && ! $r['persisted'] && 'not_attempted' === $r['effect']['status'] && $chamadas === $contador, 'Simulação aplicou efeito ou disse persistido.' );
		$r = F3Base_Config_Contrato::verificar( array( 'nome' => $n, 'revisao_esperada' => $antes['revisao'] ) );
		f3b_e_exige( $r['ok'] && ! $r['configuracao_alterada'] && ! $r['efeito_repetido'] && $chamadas === $contador && get_option( F3Base_Options::OPTION_PROVENIENCIA ) === $proveniencia, 'Consulta repetiu efeito ou carimbou procedência.' );
		$negar = static fn( $novo, $velho ) => $velho; add_filter( 'pre_update_option_' . $n, $negar, 10, 2 );
		try { $r = F3Base_Options::gravar( $n, array( 'mensagem_padrao' => 'recusado' ) ); } finally { remove_filter( 'pre_update_option_' . $n, $negar ); }
		f3b_e_exige( ! $r['persisted'] && ! $r['ok'] && 'not_attempted' === $r['effect']['status'] && $chamadas === $contador, 'Falha de gravação executou efeito.' );
		$r = F3Base_Options::gravar( 'f3base_retencao_meses', 0 );
		f3b_e_exige( ! $r['persisted'] && 'valor_recusado' === $r['codigo'], 'Recusa do dono foi convertida em sucesso.' );
		$modo = 'concurrent'; $foto = F3Base_Options::fotografia( $n ); $valor = $foto['valor']; $valor['mensagem_padrao'] = 'primeiro-escritor';
		$r = F3Base_Core_Config_Mcp::escrever( array( 'nome' => $n, 'valor' => $valor, 'revisao_esperada' => $foto['revisao'], 'simular' => false ) );
		f3b_e_exige( $r['persisted'] && 'primeiro-escritor' === $r['lido']['mensagem_padrao'] && ! hash_equals( $r['revisao'], F3Base_Options::revisao( $n ) ) && 'configuracao_mudou' === $r['verification']['codigo'], 'Escrita posterior foi atribuída à revisão do primeiro escritor.' );
	} finally { remove_filter( 'f3base_options_catalogo', $filtro ); f3b_170_reset_catalogo(); }
	return array( 'OK', 'Persistência, efeito, exceção, preview e consulta separados; ok compatível e recusa final do dono preservada.' );
}

function f3b_170_contrato(): array {
	wp_set_current_user( 1 ); register_post_type( 'livro_bancada', array( 'public' => true, 'label' => 'Livros da bancada' ) );
	F3Base_Options::gravar( 'f3base_meta_capi_token', 'SEGREDO-DO-CONTRATO' );
	F3Base_Options::gravar( 'f3base_seo_entidade', array( 'ponto_de_contato' => array( array( 'telefone' => '+5511999999999', 'idiomas' => array( 'pt' ) ) ), 'servicos' => array( array( 'nome' => 'Consultoria', 'area_servida' => array( 'Brasil' ) ) ) ) );
	F3Base_Options::gravar( 'f3base_llms', array( 'politica_privacidade' => array( 'url' => home_url( '/privacidade/' ) ), 'livres' => array( array( 'url' => home_url( '/servicos/' ), 'titulo' => 'Serviços' ) ) ) );
	F3Base_Options::gravar( 'f3base_redirects', array( '/antigo/' => '/novo/' ) );
	$habilidade = wp_get_ability( F3Base_Config_Contrato::HABILIDADE );
	f3b_e_exige( is_object( $habilidade ), 'Contrato versionado não registrado.' );
	$r = $habilidade->execute( array() ); f3b_e_exige( ! is_wp_error( $r ) && $r['ok'] && F3Base_Config_Contrato::VERSAO === $r['contract_version'], 'Contrato não executa ou versão incorreta: ' . wp_json_encode( $r ) );
	$opcoes = array_column( $r['opcoes'], null, 'nome' );
	f3b_e_exige( $opcoes['f3base_retencao_meses']['schema']['maximum'] === F3Base_Options::FAIXAS['retencao_meses'][1], 'Limite máximo ausente do contrato.' );
	f3b_e_exige( $opcoes['f3base_atribuicao']['schema']['properties']['modelo']['enum'] === F3Base_Vocabulario::modelos_de_atribuicao(), 'Enum não deriva do catálogo.' );
	f3b_e_exige( in_array( 'livro_bancada', $opcoes['f3base_llms']['schema']['properties']['tipos']['items']['enum'], true ), 'Tipos públicos dinâmicos ausentes.' );
	f3b_e_exige( ! str_contains( wp_json_encode( $r ), 'SEGREDO-DO-CONTRATO' ) && ! isset( $opcoes['f3base_endpoint_segredo'] ) && $opcoes['f3base_meta_capi_token']['valor']['mascarado'], 'Contrato expôs segredo ou estado interno.' );
	f3b_e_exige( ! $opcoes['f3base_nav_id']['escrita']['permitida'] && ! in_array( 'gravar', $opcoes['f3base_nav_id']['operacoes_permitidas'], true ), 'Catálogo abriu opção estrutural.' );
	f3b_e_exige( ! empty( $opcoes['f3base_contato']['modulos'] ) && ! empty( $opcoes['f3base_comportamento']['dependencias'] ), 'Dependências e módulos ausentes.' );
	foreach ( $opcoes as $nome => $item ) {
		if ( $item['segredo'] ) { continue; }
		$validacao = rest_validate_value_from_schema( $item['valor'], $item['schema'], $nome );
		f3b_e_exige( ! is_wp_error( $validacao ), 'O schema canônico rejeita seu próprio valor: ' . $nome . ' ' . wp_json_encode( $validacao ) );
	}
	$n = 'f3base_comportamento'; $foto = F3Base_Options::fotografia( $n );
	$p = F3Base_Core_Config_Mcp::escrever( array( 'nome' => $n, 'valor' => array( 'retencao_dias' => 10, 'retencao_eventos_dias' => 500, 'dias_no_painel' => 500 ), 'revisao_esperada' => $foto['revisao'] ) );
	f3b_e_exige( $p['ok'] && ! $p['persisted'] && 10 === $p['depois']['retencao_eventos_dias'] && 10 === $p['depois']['dias_no_painel'], 'Contrato mudou normalização histórica ou ignorou dependência.' );
	$manual = F3Base_Como_Usar::responder();
	f3b_e_exige( str_contains( $manual['como_mudar'], 'F3Base_Options::gravar' ) && ! str_contains( $manual['como_mudar'], 'pela API de options do WordPress' ) && false === $manual['configuracao']['implantador']['aplica_no_site'], 'Manual aponta para operação ou escopo incorreto.' );
	$json = F3Base_Config_Mcp::escrever( array( 'arquivo' => 'inexistente', 'conteudo' => array() ) );
	f3b_e_exige( 'installer_json' === $json['scope'] && false === $json['site_config_applied'], 'JSON do implantador se apresentou como estado aplicado.' );
	wp_set_current_user( 0 );
	f3b_e_exige( is_wp_error( $habilidade->execute( array() ) ) && ! F3Base_Config_Contrato::consultar()['ok'] && ! F3Base_Config_Contrato::verificar( array( 'nome' => $n ) )['ok'], 'Contrato ou verificação acessíveis sem permissão.' );
	return array( 'OK', 'Contrato versionado executa: limites, enums e tipos públicos reais, dependências, escopos, permissões e segredos conferidos.' );
}

function f3b_170_verificacao(): array {
	wp_set_current_user( 1 );
	$n = 'f3base_robots'; $r = F3Base_Options::gravar( $n, array( 'ligado' => true ) );
	f3b_e_exige( $r['persisted'] && $r['effect']['applied'] && $r['verification']['pending'], 'Preparar rota local declarou entrega pública verificada.' );
	$foto = F3Base_Options::fotografia( $n ); $backup = F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION );
	$d = array( 'ok' => true, 'assinatura' => F3Base_Robots_Entrega::assinatura(), 'verificado_em' => time(), 'modo' => 'virtual', 'codigo' => 200 );
	F3Base_Robots_Arquivo::diagnostico( $d, F3Base_Robots_Arquivo::contexto() );
	$r = wp_get_ability( F3Base_Config_Contrato::VERIFICAR )->execute( array( 'nome' => $n, 'revisao_esperada' => $foto['revisao'] ) );
	f3b_e_exige( ! is_wp_error( $r ) && $r['ok'] && 'verified' === $r['verification']['status'] && 'public_http' === $r['verification']['scope'], 'Consulta não distingue a prova HTTP registrada pelo dono.' );
	$d['verificado_em'] = time() - F3Base_Robots_Entrega::INTERVALO - 1;
	F3Base_Robots_Arquivo::diagnostico( $d, F3Base_Robots_Arquivo::contexto() );
	$r = F3Base_Config_Contrato::verificar( array( 'nome' => $n ) );
	f3b_e_exige( $r['verification']['pending'], 'Evidência vencida continuou aprovada.' );
	$d['verificado_em'] = time(); $d['ok'] = false;
	F3Base_Robots_Arquivo::diagnostico( $d, F3Base_Robots_Arquivo::contexto() );
	$r = F3Base_Config_Contrato::verificar( array( 'nome' => $n ) );
	f3b_e_exige( $r['ok'] && 'failed' === $r['verification']['status'] && F3Base_Options::revisao( $n ) === $foto['revisao'], 'Consulta confundiu execução, aprovação ou alterou preferência.' );
	$r = F3Base_Config_Contrato::verificar( array( 'nome' => $n, 'revisao_esperada' => str_repeat( '0', 64 ) ) );
	f3b_e_exige( ! $r['ok'] && 'conflito' === $r['codigo'], 'Verificação foi atribuída à revisão errada.' );
	F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $backup );
	return array( 'OK', 'Prova HTTP separada da gravação; consulta não repete efeito, recusa revisão antiga e invalida evidência vencida.' );
}

/** A página selecionada pertence ao WordPress; preparação pelo comando oficial no site descartável. */
function f3b_170_politica_wordpress( int $id ): void {
	$cache = getenv( 'F3BASE_BANCADA_CACHE' ) ?: getenv( 'HOME' ) . '/.cache/f3base-bancada';
	$cli = rtrim( $cache, '/' ) . '/wp-cli.phar'; $saida = array(); $codigo = 0;
	exec( escapeshellarg( PHP_BINARY ) . ' ' . escapeshellarg( $cli ) . ' --allow-root --path=' . escapeshellarg( ABSPATH ) . ' option update wp_page_for_privacy_policy ' . $id . ' 2>&1', $saida, $codigo );
	f3b_e_exige( 0 === $codigo, 'A preparação da política pelo WordPress falhou: ' . implode( "\n", $saida ) );
	foreach ( array( 'wp_page_for_privacy_policy', 'alloptions', 'notoptions' ) as $chave ) { wp_cache_delete( $chave, 'options' ); }
}
function f3b_170_privacidade(): array {
	wp_set_current_user( 1 );
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Política da bancada', 'post_content' => 'Referência opcional.' ) );
	f3b_170_politica_wordpress( (int) $id );
	f3b_e_exige( '' !== F3Base_Modulo_Consentimento::url_politica_opcional(), 'Política pública deixou de aparecer.' );
	foreach ( array( 'draft', 'private', 'trash' ) as $status ) {
		wp_update_post( array( 'ID' => $id, 'post_status' => $status ) );
		f3b_e_exige( '' === F3Base_Modulo_Consentimento::url_politica_opcional(), 'Link para política indisponível foi publicado.' );
	}
	wp_update_post( array( 'ID' => $id, 'post_status' => 'publish', 'post_password' => 'privada' ) );
	f3b_e_exige( '' === F3Base_Modulo_Consentimento::url_politica_opcional(), 'Link para política protegida foi publicado.' );
	wp_delete_post( $id, true ); f3b_170_politica_wordpress( 0 );
	F3Base_Options::gravar( 'f3base_llms', array( 'ligado' => true, 'full' => true, 'politica_privacidade' => array() ) );
	F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => true ) );
	foreach ( array( 'pre-aprovado', 'negado' ) as $modo ) {
		F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => $modo, 'controle_rodape' => true, 'aviso_primeira_visita' => true ) );
		f3b_e_exige( 'ativo' === ( new F3Base_Modulo_Consentimento() )->estado()['estado'], 'Ausência da política degradou consentimento.' );
		$saida = array(); $codigo = 0;
		exec( 'node ' . escapeshellarg( __DIR__ . '/privacidade-170.cjs' ) . ' ' . escapeshellarg( home_url( '/' ) ) . ' ' . escapeshellarg( $modo ) . ' 2>&1', $saida, $codigo );
		f3b_e_exige( 0 === $codigo, 'Navegador sem política: ' . implode( "\n", $saida ) );
	}
	foreach ( array( '/llms.txt', '/llms-full.txt' ) as $caminho ) { $r = f3b_bancada_get( $caminho ); f3b_e_exige( 200 === $r['codigo'] && ! str_contains( $r['corpo'], 'Política da bancada' ), 'LLMS depende de política ou reteve referência inexistente.' ); }
	f3b_e_exige( 0 === (int) get_option( 'wp_page_for_privacy_policy' ) && '' === F3Base_Modulo_Consentimento::url_politica_opcional(), 'Plugin criou ou exigiu política.' );
	return array( 'OK', 'Política opcional: ausente, privada, protegida e removida; consentimento e llms funcionam, com aceite/recusa no navegador.' );
}
