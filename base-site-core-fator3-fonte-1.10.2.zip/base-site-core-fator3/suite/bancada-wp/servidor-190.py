"""Monta bancada local em Apache real. Insumos são ZIPs oficiais externos ao pacote."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import time
import urllib.request
import zipfile

p = argparse.ArgumentParser()
p.add_argument('--work', required=True)
p.add_argument('--zip', required=True)
p.add_argument('--cache', required=True)
p.add_argument('--plugins', required=True)
p.add_argument('--apache', required=True)
p.add_argument('--php-ini', required=True)
p.add_argument('--single-uid-namespace', action='store_true', help='Bancada isolada com apenas o UID atual mapeado; mantém a identidade do processo.')
p.add_argument('--prepare-only', action='store_true', help='Prepara os arquivos; a homologação inicia e encerra o servidor.')
p.add_argument('--sqlite-journal-mode', choices=['WAL', 'DELETE'], default='WAL', help='Modo nativo do driver SQLite; DELETE dispensa memória compartilhada em bancadas isoladas.')
a = p.parse_args()
work, cache, plugins, apache = map(lambda v: Path(v).resolve(), [a.work, a.cache, a.plugins, a.apache])
if work.exists():
    raise SystemExit('O diretório da bancada já existe; escolha outro para preservar as evidências.')
work.mkdir(parents=True)
site = work / 'site'
with zipfile.ZipFile(cache / 'wordpress.zip') as z:
    z.extractall(work)
(work / 'wordpress').rename(site)
dest = site / 'wp-content/plugins'
for archive in [cache / 'sqlite-database-integration.zip', Path(a.zip), plugins / 'wp-super-cache.3.1.3.zip', plugins / 'wordpress-seo.zip']:
    with zipfile.ZipFile(archive) as z:
        z.extractall(dest)
shutil.copyfile(dest / 'sqlite-database-integration/db.copy', site / 'wp-content/db.php')
mu = site / 'wp-content/mu-plugins'
mu.mkdir(exist_ok=True)
(mu / 'bancada-rede.php').write_text("""<?php
// O fixture só permite HTTP para o próprio servidor local.
add_filter('pre_http_request', static function($r,$a,$url) {
    return wp_parse_url($url,PHP_URL_HOST)==='127.0.0.1' ? $r : new WP_Error('bancada_offline','Fornecedor externo fora da bancada.');
},10,3);
""")
with socket.socket() as sock:
    sock.bind(('127.0.0.1', 0))
    port = sock.getsockname()[1]
url = f'http://127.0.0.1:{port}'
cli = ['php', str(cache / 'wp-cli.phar'), '--allow-root', '--path=' + str(site)]
def wp(*args):
    result = subprocess.run(cli + list(args), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=90)
    with (work / 'preparacao.log').open('a') as log:
        log.write(result.stdout)
    if result.returncode:
        raise RuntimeError(result.stdout[-2500:])

wp('config', 'create', '--dbname=bancada', '--dbuser=bancada', '--dbpass=bancada', '--skip-check', '--force')
wp('config', 'set', 'SQLITE_JOURNAL_MODE', a.sqlite_journal_mode)
for key, value in [('DISABLE_WP_CRON', 'true'), ('WP_DEBUG', 'true'), ('WP_DEBUG_LOG', 'true'), ('WP_DEBUG_DISPLAY', 'false')]:
    wp('config', 'set', key, value, '--raw')
wp('core', 'install', '--url=' + url, '--title=Homologação Core', '--admin_user=admin', '--admin_password=fixture-local-190', '--admin_email=admin@example.com', '--skip-email')
theme = site / 'wp-content/themes/bancada-190'
theme.mkdir()
(theme / 'style.css').write_text('/* Theme Name: Bancada Core 190 */\n')
(theme / 'index.php').write_text('''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><?php wp_head(); ?></head><body><main><?php while(have_posts()){the_post();?><h1><?php the_title(); ?></h1><?php the_content();} ?></main><?php wp_footer(); ?></body></html>''')
wp('theme', 'activate', 'bancada-190')
wp('rewrite', 'structure', '/%postname%/')
wp('plugin', 'activate', 'base-site-core-fator3')
# Yoast e o cache são ativados pelos cenários para também medir o Core isolado.
conf = work / 'httpd.conf'
modules = apache / 'usr/lib/apache2/modules'
lines = [f'ServerRoot "{work}"', f'Listen 127.0.0.1:{port}', f'ServerName 127.0.0.1:{port}', f'PidFile "{work}/httpd.pid"']
for mod in ['mpm_prefork', 'authz_core', 'authz_host', 'unixd', 'dir', 'mime', 'rewrite', 'headers', 'alias', 'access_compat']:
    if mod == 'unixd' and a.single_uid_namespace:
        continue
    lines.append(f'LoadModule {mod}_module "{modules}/mod_{mod}.so"')
lines += [f'LoadModule php_module "{modules}/libphp8.3.so"', f'PHPIniDir "{Path(a.php_ini).resolve()}"', 'User www-data', 'Group www-data',
          f'ErrorLog "{work}/apache-error.log"', f'CustomLog "{work}/apache-access.log" "%h %t %r %>s"',
          'StartServers 2', 'MinSpareServers 2', 'MaxSpareServers 4', 'MaxRequestWorkers 8', 'MaxConnectionsPerChild 200',
          f'DocumentRoot "{site}"', 'DirectoryIndex index.php index.html', 'TypesConfig /etc/mime.types',
          '<FilesMatch "\\.php$">', 'SetHandler application/x-httpd-php', '</FilesMatch>',
          f'<Directory "{site}">', 'Require all granted', 'AllowOverride All', 'Options FollowSymLinks', '</Directory>']
conf.write_text('\n'.join(lines) + '\n')
(site / '.htaccess').write_text('''# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
''')
if a.single_uid_namespace:
    mapping = Path('/proc/self/uid_map').read_text().split()
    if mapping != ['0', '0', '1']:
        raise RuntimeError('A opção single-uid exige namespace isolado com somente o UID atual mapeado.')
    conf.write_text('\n'.join(line for line in conf.read_text().splitlines() if not line.startswith(('User ', 'Group '))) + '\n')
else:
    subprocess.run(['chown', '-R', 'www-data:www-data', str(site)], check=True)
env = dict(os.environ)
env['LD_LIBRARY_PATH'] = str(apache / 'usr/lib/x86_64-linux-gnu') + ':' + env.get('LD_LIBRARY_PATH', '')
cmd = [str(apache / 'usr/sbin/apache2'), '-f', str(conf)]
info = {'site': str(site), 'url': url, 'wp_cli': cli, 'apache': cmd, 'php_ini': a.php_ini, 'sqlite_journal_mode': a.sqlite_journal_mode, 'zip': str(Path(a.zip).resolve()), 'zip_sha256': hashlib.sha256(Path(a.zip).read_bytes()).hexdigest()}
(work / 'ambiente.json').write_text(json.dumps(info, indent=2) + '\n')
if a.prepare_only:
    print(json.dumps(info))
    raise SystemExit(0)
subprocess.run(cmd + ['-t'], env=env, check=True)
subprocess.run(cmd + ['-k', 'start'], env=env, check=True)
for attempt in range(30):
    try:
        with urllib.request.urlopen(url, timeout=3) as response:
            assert response.status == 200
        break
    except Exception:
        time.sleep(.2)
else:
    raise RuntimeError('Apache não respondeu; consulte os logs da bancada.')
(work / 'ambiente.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info))
