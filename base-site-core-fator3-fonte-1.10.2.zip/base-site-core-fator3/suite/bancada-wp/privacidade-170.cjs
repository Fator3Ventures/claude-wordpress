const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async () => {
 const browser = await chromium.launch({executablePath:process.env.F3BASE_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--disable-gpu']});
 try {
  const page = await browser.newPage(); const errors=[];
  page.on('pageerror',e=>errors.push(String(e)));
  await page.route('**/*',route=>new URL(route.request().url()).origin===new URL(process.argv[2]).origin ? route.continue() : route.abort());
  await page.goto(process.argv[2],{waitUntil:'networkidle'});
  assert.equal(await page.evaluate(()=>f3baseConsentimentoDados.politicaUrl),'');
  assert.equal(await page.evaluate(()=>f3baseConsentimento.permiteTags()),process.argv[3]==='pre-aprovado');
  await page.evaluate(()=>f3baseConsentimento.abrir());
  assert.equal(await page.locator('.f3base-consentimento-politica').count(),0);
  await page.locator('.f3base-consentimento-recusar').first().click();
  assert.equal(await page.evaluate(()=>f3baseConsentimento.permiteTags()),false);
  await page.reload({waitUntil:'networkidle'});
  assert.equal(await page.evaluate(()=>f3baseConsentimento.permiteTags()),false);
  await page.evaluate(()=>f3baseConsentimento.abrir());
  await page.locator('.f3base-consentimento-aceitar').click();
  assert.equal(await page.evaluate(()=>f3baseConsentimento.permiteTags()),true);
  assert.deepEqual(errors,[]);
  console.log(JSON.stringify({browser:browser.version(),modo:process.argv[3],politicaOpcional:true,recusaPersistida:true,reaceite:true}));
 } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1;});
