"""Homologação da tabela A em Apache + WordPress reais; fixtures fora do ZIP de produção.
Uso: python backlog-191.py BANCADA --mcp ZIP --baseline-core ZIP_1.9.0
Bancada criada por servidor-190.py --prepare-only. PATH e LD_LIBRARY_PATH devem apontar ao runtime.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, re, subprocess, time, urllib.request, urllib.error, zipfile
from email.utils import parsedate_to_datetime
p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('--mcp',type=Path,required=True);p.add_argument('--baseline-core',type=Path,required=True);a=p.parse_args()
work=a.work.resolve();info=json.loads((work/'ambiente.json').read_text());suite=Path(__file__).resolve().parent
site=Path(info['site']);url=info['url'];e={'casos':[],'falhas':[],'zip_sha256':{}}
for archive in [Path(info['zip']),a.mcp]:e['zip_sha256'][archive.name]=hashlib.sha256(archive.read_bytes()).hexdigest()
def wp(*args):
    r=subprocess.run(info['wp_cli']+list(args),capture_output=True,text=True,timeout=90)
    with (work/'execucoes-191.log').open('a') as log:log.write(r.stdout+r.stderr)
    assert r.returncode==0,r.stdout[-3000:]+r.stderr[-1000:]
    return r.stdout

def core(action):
    req=urllib.request.Request(url+'/wp-json/bancada/v1/backlog',data=json.dumps({'acao':action}).encode(),headers={'Content-Type':'application/json'})
    try:r=urllib.request.urlopen(req,timeout=90)
    except urllib.error.HTTPError as ex:r=ex
    data=json.loads(r.read());assert data['ok'],data
    return data['resultado']

def http(path):
    req=urllib.request.Request(url+path,headers={'User-Agent':'Mozilla/5.0 Core191 Fixture'})
    try:r=urllib.request.urlopen(req,timeout=15)
    except urllib.error.HTTPError as ex:r=ex
    with r:return {'status':r.status,'headers':list(r.headers.raw_items()),'cache_control':r.headers.get_all('Cache-Control',[]),'expires':r.headers.get('Expires',''),'body':r.read().decode(errors='replace')}
def public(x):return {k:v for k,v in x.items() if k!='body'}
def case(name,fn):
    try:r=fn();e['casos'].append({'nome':name,'ok':True,'resultado':r});print('OK '+name,flush=True);return r
    except Exception as ex:e['falhas'].append({'nome':name,'erro':str(ex)});raise

def packages():
    spec=importlib.util.spec_from_file_location('packages',suite/'pacotes-191.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    results=[m.audit(Path(info['zip'])),m.audit(a.mcp)]
    # Mutantes comprovam que a auditoria acusa ausência de silêncio/documento reinserido.
    for kind in ['sem_index','com_documento']:
        bad=work/(kind+'.zip')
        with zipfile.ZipFile(info['zip']) as src,zipfile.ZipFile(bad,'w') as dst:
            for f in src.namelist():
                if kind=='sem_index' and f.endswith('/assets/index.php'):continue
                dst.writestr(f,src.read(f))
            if kind=='com_documento':dst.writestr('base-site-core-fator3/docs/INSTALACAO.md','fixture')
        try:m.audit(bad)
        except AssertionError:pass
        else:raise AssertionError('Auditoria aprovou mutante '+kind)
    return {'pacotes':results,'mutantes_detectados':2}
def upgrade():
    wp('plugin','install',str(a.baseline_core.resolve()),'--force','--activate')
    assert (site/'wp-content/plugins/base-site-core-fator3/INSTRUCOES-DO-PLUGIN.md').is_file()
    before=wp('eval','echo hash("sha256", serialize(F3Base_Options::ler("f3base_contato")));').strip()
    old=http('/wp-json/f3base/v1/token')
    wp('plugin','install',info['zip'],'--force','--activate')
    after=wp('eval','echo hash("sha256", serialize(F3Base_Options::ler("f3base_contato")));').strip()
    assert before==after,'Upgrade alterou preferência.'
    assert not (site/'wp-content/plugins/base-site-core-fator3/INSTRUCOES-DO-PLUGIN.md').exists()
    new=http('/wp-json/f3base/v1/token')
    assert old['status']==new['status']==200
    assert 'max-age=172800' in ','.join(old['cache_control']) and len(new['cache_control'])==1 and 'max-age' not in new['cache_control'][0], (public(old),public(new))
    return {'de':'1.9.0','para':wp('plugin','get','base-site-core-fator3','--field=version').strip(),'preferencia_preservada':True,'antes':public(old),'depois':public(new),'documentacao_antiga_removida':True}
def tokens():
    results=[]
    for path in ['/wp-json/f3base/v1/token','/?rest_route=/f3base/v1/token','/?rest_route=%2Ff3base%2Fv1%2Ftoken','/wp-json/f3base/v1/comportamento/token']:
        x,y=http(path),http(path)
        assert x['status']==y['status']==200, (path,public(x),public(y))
        assert all(len(v['cache_control'])==1 and 'no-store' in v['cache_control'][0] and parsedate_to_datetime(v['expires']).timestamp()<time.time() for v in [x,y]),(x,y)
        assert x['body']!=y['body'] and json.loads(x['body'])['emissao_id']!=json.loads(y['body'])['emissao_id']
        results.append({'rota':path,'primeiro':public(x),'segundo':public(y),'corpos_distintos':True})
    return results

def directories():
    rs=[]
    for archive in [Path(info['zip']),a.mcp]:
        with zipfile.ZipFile(archive) as z:dirs=sorted({str(Path(f).parent) for f in z.namelist() if f.endswith('/index.php')})
        for d in dirs:
            r=http('/wp-content/plugins/'+d+'/')
            assert 'Index of' not in r['body'],d
            # 200 com corpo vazio é o resultado válido de um index de silêncio.
            assert r['body']=='' or (d.endswith('/dados') and r['status']>=400),(d,public(r),r['body'][:200])
        rs.append({'pacote':archive.name,'pastas_sem_listagem':len(dirs)})
    data=http('/wp-content/plugins/base-site-core-fator3/dados/eventos-comportamento.tsv')
    assert data['status']>=400 and 'gatilho' not in data['body'] and 'Index of' not in data['body']
    for path in ['/wp-content/plugins/wp-mcp-fator3/docs/INSTALACAO.md','/wp-content/plugins/base-site-core-fator3/INSTRUCOES-DO-PLUGIN.md']:
        assert http(path)['status']==404
    return {'pastas':rs,'dados_http':data['status'],'apache_autoindex_ativo':True}

def advertising():
    x=http('/?gclid=clique-um&fbclid=facebook-um');y=http('/?gclid=clique-dois&fbclid=facebook-dois')
    assert x['status']==y['status']==200
    marker=lambda r:re.search(r'F3BASE-CACHE-PROBE:([a-f0-9-]{36})',r['body']).group(1)
    assert marker(x)==marker(y),'Anúncios diferentes renderizaram gerações diferentes.'
    return {'primeiro':public(x),'segundo':public(y),'mesma_geracao_cache':True}

def mcp_smoke():
    # O escopo deste release do canal é empacotamento; não altera autenticação.
    version=wp('plugin','get','wp-mcp-fator3','--field=version').strip();assert version=='0.12.1-rc.2'
    home=http('/');assert home['status']==200
    assert 'Fatal error' not in home['body']
    r=wp('eval','echo json_encode(["versao"=>F3_MCP_FILES_VERSION,"rotas"=>array_values(array_filter(array_keys(rest_get_server()->get_routes()),static fn($s)=>str_contains($s,"mcp")))]);')
    data=json.loads(r.strip());assert data['rotas']
    return data

conf=work/'httpd.conf';original=conf.read_text();modules=Path(info['apache'][0]).parent.parent/'lib/apache2/modules'
# Simula a configuração da hospedagem, só no fixture descartável.
conf.write_text(original.replace('Options FollowSymLinks','Options FollowSymLinks Indexes')+f'\nLoadModule expires_module "{modules}/mod_expires.so"\nLoadModule autoindex_module "{modules}/mod_autoindex.so"\nExpiresActive On\nExpiresDefault "access plus 2 days"\n')
(site/'fixture-cache-control.php').write_text('<?php header("Cache-Control: no-store, private"); header("Cache-Control: max-age=172800",false); header("Expires: Wed, 11 Jan 1984 05:00:00 GMT"); echo "fixture";')
# WPSC 3.1.3 não exporta a chave ignore_tracking no carregador WP-CLI.
# As verificações usam SAPI HTTP real, o mesmo contexto do painel/MCP/cron público.
mu=site/'wp-content/mu-plugins/backlog-191.php'
mu.write_text("<?php\ndefine('F3BASE_BANCADA_191',true);\nadd_action('rest_api_init',static function(){register_rest_route('bancada/v1','/backlog',['methods'=>'POST','permission_callback'=>static fn()=>($_SERVER['REMOTE_ADDR']??'')==='127.0.0.1','callback'=>static function($r){require_once "+repr(str(suite/'backlog-191.php'))+";try{return ['ok'=>true,'resultado'=>b191_run($r->get_param('acao'),[])];}catch(Throwable $e){return new WP_REST_Response(['ok'=>false,'erro'=>$e->getMessage()],500);}}]);});\n")
(work/'httpd.pid').unlink(missing_ok=True)
server=subprocess.Popen(info['apache']+['-DFOREGROUND'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,start_new_session=True)
try:
    for _ in range(40):
        try:http('/');break
        except urllib.error.URLError:time.sleep(.1)
    else:raise RuntimeError('Apache indisponível: '+server.stderr.read().decode())
    case('pacotes_e_mutantes',packages)
    case('upgrade_remove_documentacao_e_corrige_mod_expires',upgrade)
    wp('plugin','activate','wp-super-cache','wordpress-seo')
    wp('plugin','install',str(a.mcp.resolve()),'--activate','--force')
    case('configuracao_pela_api_do_provedor',lambda:core('configurar'))
    case('perfil_e_faltantes_exatos',lambda:core('perfil'))
    case('chave_preserva_parametros_funcionais',lambda:core('chave'))
    case('tokens_http_com_mod_expires',tokens)
    case('multiplicidade_no_transporte_wordpress',lambda:core('cabecalhos_reais'))
    case('sondas_negativas',lambda:core('sondas_negativas'))
    case('contrato_real_sem_avisos_ou_http',lambda:core('ler'))
    case('cadencia_e_ausencia_de_leads',lambda:core('cadencia'))
    case('anuncios_reutilizam_cache',advertising)
    case('listagens_e_dados_bloqueados',directories)
    case('canal_mcp_carrega_sem_documentacao',mcp_smoke)
finally:
    conf.write_text(original);mu.unlink(missing_ok=True);(site/'fixture-cache-control.php').unlink(missing_ok=True);server.terminate()
    try:server.wait(timeout=5)
    except subprocess.TimeoutExpired:server.kill();server.wait(timeout=5)
    e['total']=len(e['casos']);(work/'resultado-191.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'ok':not e['falhas'],'casos':e['total']},ensure_ascii=False))
