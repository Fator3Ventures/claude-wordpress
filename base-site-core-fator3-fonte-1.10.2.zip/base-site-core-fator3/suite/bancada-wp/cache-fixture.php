<?php
/** Controle de evidência só na bancada local; não é incluído no plugin. */
if (wp_parse_url(home_url(), PHP_URL_HOST)!=='127.0.0.1') {throw new RuntimeException('Bancada local obrigatória.');}
function f3b_fixture_cache(array $prova = array()): void {
    if (class_exists('F3Base_Cache_Evidencia')) {
        $f=F3Base_Options::fotografia(F3Base_Cache_Evidencia::OPTION);
        $r=F3Base_Options::gravar(F3Base_Cache_Evidencia::OPTION,array('ultima_tentativa'=>$prova),F3Base_Options::ORIGEM_PADRAO,$f['revisao']);
        if (!$r['persisted']) {throw new RuntimeException('Fixture não persistida.');}
    } elseif ($prova) {set_transient(F3Base_Cache_Pagina::PROVA,$prova,F3Base_Cache_Pagina::VALIDADE);}
    else {delete_transient(F3Base_Cache_Pagina::PROVA);}
}
