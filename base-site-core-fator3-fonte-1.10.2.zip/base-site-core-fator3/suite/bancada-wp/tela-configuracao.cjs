/* Prova visual complementar: clique no menu e gravação no formulário nativo. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const out = process.env.F3BASE_EVIDENCIA_DIR;
  if (!out) throw new Error('F3BASE_EVIDENCIA_DIR ausente');
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: process.env.F3BASE_CHROMIUM, headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    const base = `http://127.0.0.1:${process.env.F3BASE_BANCADA_PORTA}`;
    await page.goto(`${base}/wp-login.php`);
    await page.locator('#user_login').fill('admin');
    await page.locator('#user_pass').fill('admin');
    await Promise.all([page.waitForURL('**/wp-admin/**'), page.locator('#wp-submit').click()]);
    await Promise.all([page.waitForURL('**/admin.php?page=base-site-core-fator3'), page.locator('#toplevel_page_base-site-core-fator3 > a').click()]);
    const days = page.locator('[name="f3base[f3base_sessao][dias]"]');
    await days.fill('77');
    await Promise.all([page.waitForNavigation(), page.getByRole('button', { name: 'Salvar', exact: true }).first().click()]);
    if (await days.inputValue() !== '77') throw new Error('Configuração não persistiu');
    const leadLink = page.locator('#toplevel_page_base-site-core-fator3 ul a[href*="post_type=f3base_lead"]');
    if (await leadLink.count() !== 1) throw new Error('Contingência não está acessível');
    await page.screenshot({ path: path.join(out, 'configuracao-plugin-sozinho.png') });
    await Promise.all([page.waitForURL('**/edit.php?post_type=f3base_lead'), leadLink.click()]);
    if (!(await page.locator('#wpbody-content').innerText()).includes('Leads (contingência)')) throw new Error('Lista de contingência não abriu');
    if (errors.length) throw new Error(errors.join('\n'));
    fs.writeFileSync(path.join(out, 'tela-configuracao.txt'), 'Somente site-core instalado. Login nativo; clique em F3 Base; configuração de sessão alterada para 77 dias, enviada e lida de volta; lista de contingência acessada separadamente. Nenhum erro de JavaScript.\n');
    process.stdout.write('OK: configuração, gravação e contingência no Chromium.\n');
  } finally { await browser.close(); }
})().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
