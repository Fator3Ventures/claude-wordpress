<?php
/** Executar somente na bancada isolada: wp eval-file suite/bancada-wp/capi-110.php. */
if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) { throw new RuntimeException( 'Somente bancada WP-CLI.' ); }
require_once WP_PLUGIN_DIR . '/base-site-core-fator3/includes/class-f3base-consentimento-decisoes.php';
global $wpdb;
$checks = array();
$check = static function ( string $id, bool $ok, $evidencia = null ) use ( &$checks ): void { $checks[] = array( 'id' => $id, 'ok' => $ok, 'evidencia' => $evidencia ); };
$payload = array( 'data' => array( array( 'event_name' => 'Lead', 'event_id' => 'evento-estavel', 'user_data' => array( 'em' => array( 'hash-fixture' ) ) ) ) );
update_option( 'f3base_meta_pixel_id', '111111' ); update_option( 'f3base_meta_capi_token', 'token-fixture' );
$config = F3Base_Options::ler( 'f3base_consentimento' ); $config['modo'] = 'legado'; update_option( 'f3base_consentimento', $config );
$decisao = array( 'politica_versao' => 'legado:' . F3Base_Modulo_Consentimento::politica_versao() );
$http = 0; $status = 200; $cancelar_no_http = ''; $recusar_conclusao = false;
add_filter( 'pre_http_request', static function ( $pre, $args, $url ) use ( &$http, &$status, &$cancelar_no_http ) {
	if ( ! str_starts_with( $url, F3Base_Modulo_Meta_Capi::HOST ) ) { return new WP_Error( 'fixture_sem_rede', 'Rede desabilitada nesta bancada.' ); }
	++$http;
	if ( $cancelar_no_http ) { F3Base_Capi_Fila::cancelar( $cancelar_no_http ); }
	return array( 'headers' => array( 'retry-after' => '5000' ), 'body' => wp_json_encode( 200 === $status ? array( 'events_received' => 1 ) : array( 'error' => array( 'is_transient' => true ) ) ), 'response' => array( 'code' => $status, 'message' => 'fixture' ), 'cookies' => array() );
}, 10, 3 );
add_filter( 'query', static function ( $sql ) use ( &$recusar_conclusao ) { return $recusar_conclusao && str_contains( $sql, "SET estado=CASE WHEN cancelado>0 THEN 'cancelado' ELSE" ) ? 'UPDATE tabela_inexistente_capi SET x=1' : $sql; } );

// Migração de tabela existente, parcialmente alterada, não renova a expiração.
F3Base_Capi_Fila::remover(); $t = F3Base_Capi_Fila::tabela();
$wpdb->query( "CREATE TABLE {$t} (record_id varchar(128) NOT NULL PRIMARY KEY,payload longtext NOT NULL,estado varchar(16) NOT NULL,tentativas int NOT NULL DEFAULT 0,proxima bigint NOT NULL DEFAULT 0,expira bigint NOT NULL,atualizado bigint NOT NULL,reserva varchar(64) NOT NULL DEFAULT '',http int NOT NULL DEFAULT 0,pixel_id varchar(64) NOT NULL DEFAULT '')" );
$expira = time() + 1800;
$wpdb->insert( $t, array( 'record_id' => 'legado', 'payload' => wp_json_encode( $payload ), 'estado' => 'pendente', 'expira' => $expira, 'atualizado' => time() ) );
$migrado = F3Base_Capi_Fila::instalar(); $r = F3Base_Capi_Fila::ler( 'legado' );
$check( 'migracao_retomavel_destino_desconhecido', $migrado && 'suspenso' === $r['estado'] && '' === $r['pixel_id'] && $expira === (int) $r['expira'] );

$novo = static function ( $id ) use ( $payload, $decisao ) { return F3Base_Capi_Fila::inserir( $id, $payload, 3600, '111111', $decisao ); };
$novo( 'pixel-A' ); update_option( 'f3base_meta_pixel_id', '222222' ); $envio = F3Base_Modulo_Meta_Capi::enviar( 'pixel-A' );
$check( 'pixel_trocado_suspende', 0 === $http && 'destino_incompativel' === $envio['codigo'] );
update_option( 'f3base_meta_pixel_id', '111111' );
$novo( 'apagado' ); F3Base_Capi_Fila::cancelar( 'apagado' ); $antes = $http; F3Base_Modulo_Meta_Capi::enviar( 'apagado' );
$check( 'cancelar_antes_nao_envia', $antes === $http && '' === F3Base_Capi_Fila::ler( 'apagado' )['payload'] );
$novo( 'reserva-cancelada' ); $r = F3Base_Capi_Fila::reservar( 'reserva-cancelada' ); F3Base_Capi_Fila::cancelar( 'reserva-cancelada' );
$check( 'cancelamento_vence_reserva', ! F3Base_Capi_Fila::iniciar_envio( $r )['ok'] );
$novo( 'http-em-curso' ); $cancelar_no_http = 'http-em-curso'; $envio = F3Base_Modulo_Meta_Capi::enviar( 'http-em-curso' ); $cancelar_no_http = '';
$check( 'cancelar_durante_http_informa_aceitacao', $envio['ok'] && $envio['local_confirmado'] && 'cancelado' === $envio['estado'] && 'entregue_apos_cancelamento' === F3Base_Capi_Fila::ler( 'http-em-curso' )['motivo'], $envio );
$novo( 'falha-local' ); $recusar_conclusao = true; $anterior = $wpdb->suppress_errors( true ); $envio = F3Base_Modulo_Meta_Capi::enviar( 'falha-local' ); $wpdb->suppress_errors( $anterior ); $recusar_conclusao = false;
$check( 'aceitacao_externa_nao_mascara_falha_local', $envio['ok'] && ! $envio['local_confirmado'] && $envio['reconciliacao_pendente'], $envio );
$wpdb->update( $t, array( 'proxima' => time() - 1 ), array( 'record_id' => 'falha-local' ) );
F3Base_Capi_Fila::recuperar(); $r = F3Base_Capi_Fila::ler( 'falha-local' );
$check( 'recuperacao_nao_repete_aceitacao_incerta', 'incerto' === $r['estado'] && '' === $r['payload'] );
$novo( 'lease-antiga' ); $r = F3Base_Capi_Fila::reservar( 'lease-antiga' ); $inicio = F3Base_Capi_Fila::iniciar_envio( $r );
$wpdb->update( $t, array( 'reserva' => 'outro-processo' ), array( 'record_id' => 'lease-antiga' ) );
$conclusao = F3Base_Capi_Fila::concluir( $inicio['registro'], 200, true, false );
$check( 'reserva_substituida_nao_conclui', ! $conclusao['local_confirmado'] && 'reserva_perdida' === $conclusao['codigo'] );
$novo( 'retry-longo' ); $status = 429; $envio = F3Base_Modulo_Meta_Capi::enviar( 'retry-longo' ); $status = 200;
$check( 'retry_after_respeita_ttl', 'falhou' === $envio['estado'] && null === $envio['proxima_tentativa'] );
$antes = $http;
for ( $i = 0; $i < 25; ++$i ) { $novo( 'lote-' . $i ); }
$primeiro = F3Base_Capi_Fila::processar_lote(); $segundo = F3Base_Capi_Fila::processar_lote();
$check( 'continuacao_acima_de_20', 20 === $primeiro['processados'] && 5 === $segundo['processados'] && 25 === $http - $antes );

// Recusa de agendamento fica observável e o próximo carregamento recupera antes do TTL.
wp_clear_scheduled_hook( F3Base_Capi_Fila::EVENTO );
$recusar_cron = static function ( $pre, $evento ) { return F3Base_Capi_Fila::EVENTO === $evento->hook ? false : $pre; };
add_filter( 'pre_schedule_event', $recusar_cron, 10, 2 ); $novo( 'cron-recusado' );
$check( 'recusa_agendamento_registrada', 1 === (int) F3Base_Capi_Fila::ler( 'cron-recusado' )['agendamento_falhou'] );
remove_filter( 'pre_schedule_event', $recusar_cron, 10 ); F3Base_Capi_Fila::planejar();
$check( 'agendamento_recuperado_antes_ttl', wp_next_scheduled( F3Base_Capi_Fila::EVENTO ) <= time() + 60 && 0 === (int) F3Base_Capi_Fila::ler( 'cron-recusado' )['agendamento_falhou'] );
$wpdb->update( $t, array( 'expira' => time() - 1 ), array( 'record_id' => 'cron-recusado' ) ); F3Base_Capi_Fila::recuperar();
$check( 'expiracao_remove_payload', 'expirado' === F3Base_Capi_Fila::ler( 'cron-recusado' )['estado'] && '' === F3Base_Capi_Fila::ler( 'cron-recusado' )['payload'] );

// Privacy eraser informa qualquer retenção parcial; inclui também posts na lixeira.
$retencao = new F3Base_Modulo_Retencao_Eliminacao();
$p1 = wp_insert_post( array( 'post_type' => F3Base_Modulo_Endpoint_Leads::CPT, 'post_status' => 'private', 'post_title' => 'Fixture' ) );
$p2 = wp_insert_post( array( 'post_type' => F3Base_Modulo_Endpoint_Leads::CPT, 'post_status' => 'trash', 'post_title' => 'Fixture' ) );
foreach ( array( $p1, $p2 ) as $post_id ) { update_post_meta( $post_id, '_f3base_email', 'teste-capi@example.test' ); update_post_meta( $post_id, '_f3base_record_id', 'postfixture-' . $post_id ); $novo( 'postfixture-' . $post_id ); }
$recusa = static function ( $valor, $post ) use ( $p2 ) { return (int) $post->ID === $p2 ? false : $valor; };
add_filter( 'pre_delete_post', $recusa, 99, 2 );
$resultado = $retencao->apagar( 'teste-capi@example.test' );
$check( 'privacy_parcial_em_lote_misto', $resultado['items_removed'] && $resultado['items_retained'] && $resultado['done'] && get_post( $p2 ) && ! get_post( $p1 ), $resultado );
remove_filter( 'pre_delete_post', $recusa, 99 ); F3Base_Capi_Fila::recuperar();
$check( 'limpeza_pendente_independe_post_meta', ! get_post( $p2 ) );

// Abilities registradas de verdade, incluindo schema e permissões nativos do WP 6.9.
wp_set_current_user( 1 );
if ( ! has_action( 'wp_abilities_api_init', array( 'F3Base_Capi_Fila', 'registrar_habilidades' ) ) ) { add_action( 'wp_abilities_api_init', array( 'F3Base_Capi_Fila', 'registrar_habilidades' ) ); }
$avisos = array();
set_error_handler( static function ( $nivel, $mensagem ) use ( &$avisos ) { if ( error_reporting() & $nivel ) { $avisos[] = $mensagem; } return true; } );
$habilidade = wp_get_ability( 'f3base/capi-pendencias-ler' );
$consulta = $habilidade->execute( array( 'limite' => 100 ) );
$legado = array_values( array_filter( $consulta['linhas'], static fn( $r ) => 'legado' === $r['record_id'] ) )[0];
$resolver = wp_get_ability( 'f3base/capi-resolver-destino' );
$invalida = $resolver->execute( array( 'record_id' => 'legado', 'pixel_id' => '111111', 'revisao_esperada' => str_repeat( '0', 64 ) ) );
$valida = $resolver->execute( array( 'record_id' => 'legado', 'pixel_id' => '111111', 'revisao_esperada' => $legado['revisao'] ) );
$check( 'ability_destino_revisao_real', ! is_wp_error( $invalida ) && ! $invalida['ok'] && ! is_wp_error( $valida ) && $valida['ok'], array( $invalida, $valida ) );
$antes = $http; F3Base_Modulo_Meta_Capi::enviar( 'legado' );
$check( 'destino_resolvido_nao_inventa_decisao', $antes === $http && 'consentimento_indisponivel' === F3Base_Capi_Fila::ler( 'legado' )['motivo'] );
$consulta = $habilidade->execute( array( 'limite' => 100 ) );
$incerto = array_values( array_filter( $consulta['linhas'], static fn( $r ) => 'falha-local' === $r['record_id'] ) )[0];
$reconciliado = wp_get_ability( 'f3base/capi-reconciliar' )->execute( array( 'record_id' => 'falha-local', 'revisao_esperada' => $incerto['revisao'], 'desfecho' => 'aceita' ) );
$check( 'ability_reconciliacao_sem_reenvio', ! is_wp_error( $reconciliado ) && $reconciliado['ok'] && false === $reconciliado['envio_realizado'] && $antes === $http );
wp_set_current_user( 0 ); $negada = $habilidade->execute( array() );
$check( 'ability_sem_permissao_recusa', is_wp_error( $negada ) ); wp_set_current_user( 1 );
restore_error_handler(); $check( 'abilities_sem_avisos_schema', array() === $avisos, $avisos );

// Recusas do endpoint não persistem conteúdo arbitrário e não geram array-to-string.
$t_recusas = $wpdb->prefix . F3Base_Modulo_Endpoint_Leads::TABELA_RECUSAS;
$wpdb->query( "DROP TABLE IF EXISTS {$t_recusas}" );
$wpdb->query( "CREATE TABLE {$t_recusas} (dia date NOT NULL,motivo varchar(40) NOT NULL,PRIMARY KEY (dia,motivo))" );
F3Base_Modulo_Endpoint_Leads::instalar_recusas();
$check( 'recusas_schema_parcial_retomado', ! array_diff( array( 'dia', 'motivo', 'total', 'primeiro', 'ultimo' ), (array) $wpdb->get_col( "SHOW COLUMNS FROM {$t_recusas}" ) ) );
$endpoint = new F3Base_Modulo_Endpoint_Leads(); F3Base_Modulo_Endpoint_Leads::instalar_recusas();
$req = new WP_REST_Request( 'POST', '/f3base/v1/leads' ); $req->set_header( 'content-type', 'application/json' ); $req->set_body( wp_json_encode( array( 'campo-identificavel@example.test' => 'corpo-secreto-fixture' ) ) ); $endpoint->receber( $req );
$req->set_body( wp_json_encode( array( 'website' => array( 'incorreto' ) ) ) ); $malformado = $endpoint->receber( $req );
$recusas = F3Base_Modulo_Endpoint_Leads::resumo_recusas(); $texto = wp_json_encode( $recusas );
$check( 'contadores_recusas_sem_pii', 400 === $malformado->get_status() && count( $recusas['linhas'] ) >= 2 && ! str_contains( $texto, 'example.test' ) && ! str_contains( $texto, 'corpo-secreto' ) );

// Limite em única instrução; o 1001º payload é recusado e marcadores não consomem vagas.
$wpdb->query( "DELETE FROM {$t}" );
for ( $i = 0; $i < F3Base_Capi_Fila::TETO_PENDENTES; ++$i ) { $wpdb->insert( $t, array( 'record_id' => 'limite-' . $i, 'payload' => '{}', 'estado' => 'suspenso', 'expira' => time() + 600, 'atualizado' => time(), 'schema_versao' => 2 ) ); }
$check( 'teto_atomicamente_aplicado', ! $novo( 'limite-excedido' ) && 1000 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE payload<>''" ) );
$check( 'marcador_mesmo_no_teto', F3Base_Capi_Fila::cancelar( 'marcador' )['persisted'] );
F3Base_Capi_Fila::cancelar( 'limite-0' ); $check( 'vaga_reaberta_sem_payload', $novo( 'limite-excedido' ) );
$wpdb->query( "DELETE FROM {$t}" );
$falhas = array_values( array_filter( $checks, static function ( $r ) { return ! $r['ok']; } ) );
echo wp_json_encode( array( 'testes' => $checks, 'total' => count( $checks ), 'falhas' => count( $falhas ) ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
if ( $falhas ) { WP_CLI::error( 'Falhas na fila/privacidade 1.10.0.' ); }
