"""Versão do cabeçalho do plugin, usada pelos executores de release e teste."""
from pathlib import Path
import re,sys
raiz=Path(__file__).resolve().parent.parent
versao=re.search(r'Version:\s*(\S+)',(raiz/'fontes/plugin/base-site-core-fator3.php').read_text()).group(1)
print(raiz/'dist'/f'base-site-core-fator3-{versao}.zip' if '--zip' in sys.argv else versao)
