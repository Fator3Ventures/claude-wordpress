<?php
/** Registro nativo + controller REST WP 6.9, em bancada local isolada sem conector MCP. */
if ( ! defined( 'ABSPATH' ) || 'local' !== wp_get_environment_type() ) { throw new RuntimeException( 'Bancada local obrigatória.' ); }
$checks = array(); $avisos = array(); $executadas = array(); $http = array(); $respostas = array();
$ok = static function( bool $v, string $nome ) use ( &$checks ): void { $checks[$nome] = $v; if ( ! $v ) { throw new RuntimeException( $nome ); } };
set_error_handler( static function( $n, $m ) use ( &$avisos ) { if ( $n & ( E_WARNING | E_NOTICE | E_USER_WARNING | E_USER_NOTICE ) ) { $avisos[] = $m; } return false; } );
add_action( 'wp_before_execute_ability', static function( $nome ) use ( &$executadas ) { $executadas[] = $nome; } );
add_filter( 'pre_http_request', static function( $pre, $args, $url ) use ( &$http ) { $http[] = $url; return new WP_Error( 'bancada_sem_transporte', 'Teste somente local, transporte externo bloqueado.' ); }, PHP_INT_MAX, 3 );
$ativos = get_option( 'active_plugins', array() );
$ok( ! preg_grep( '/mcp/i', $ativos ), 'nenhum_conector_mcp_ativo' );
wp_set_current_user( 1 );
$servidor = rest_get_server();
$ok( isset( $servidor->get_routes()['/wp-abilities/v1/abilities/(?P<name>[a-zA-Z0-9\\-\\/]+?)/run'] ), 'controller_nativo_registrado' );
$consultas = array(
 'f3base/config-core-ler' => array(),
 'f3base/config-core-contrato-v1' => array(),
 'f3base/config-core-perfil-avaliar' => array( 'perfil' => array( 'id'=>'bancada-rest', 'revisao'=>'1', 'condicoes'=>array( array( 'id'=>'nome', 'nome'=>'f3base_ga4_measurement_id', 'comparacao'=>'igual', 'esperado'=>F3Base_Options::ler('f3base_ga4_measurement_id') ) ) ) ),
 'f3base/config-ler' => array( 'arquivo'=>'projeto' ),
 'f3base/como-usar' => array(),
 'f3base/saude-ler' => array(),
);
$operacoes = array(
 'f3base/config-core-escrever'=>array( 'nome'=>'f3base_ga4_measurement_id', 'valor'=>'G-REST123456', 'revisao_esperada'=>F3Base_Options::revisao('f3base_ga4_measurement_id'), 'simular'=>true ),
 'f3base/config-core-verificar'=>array( 'nome'=>'f3base_ga4_measurement_id', 'acao'=>'consultar' ),
 'f3base/config-escrever'=>array( 'arquivo'=>'projeto', 'conteudo'=>array() ),
 'f3base/executar-pendentes'=>array( 'tarefas'=>array(), 'limite'=>1 ),
);
$pedir = static function( string $nome, string $metodo, array $entrada ) use ( $servidor, &$respostas ): WP_REST_Response {
 $p = new WP_REST_Request( $metodo, '/wp-abilities/v1/abilities/' . $nome . '/run' );
 if ( 'GET' === $metodo ) { $p->set_query_params( array( 'input'=> $entrada ?: new stdClass() ) ); }
 else { $p->set_header('content-type','application/json'); $p->set_body( wp_json_encode( array( 'input'=> $entrada ?: new stdClass() ) ) ); }
 $r = $servidor->dispatch( $p ); $respostas[] = array('nome'=>$nome,'metodo'=>$metodo,'usuario'=>get_current_user_id(),'http'=>$r->get_status(),'codigo'=>$r->get_data()['code'] ?? ''); return $r;
};
foreach ( $consultas + $operacoes as $nome=>$entrada ) {
 $a=wp_get_ability($nome); $ok( (bool)$a, 'registro:' . $nome );
 $ok( true === $a->get_meta_item('show_in_rest'), 'rest_exposto:' . $nome );
 $mcp=$a->get_meta_item('mcp'); $ok( true === $mcp['public'] && 'tool' === $mcp['type'], 'mcp_metadata:' . $nome );
}
$ok( false === wp_get_ability('f3base/config-core-verificar')->get_meta_item('annotations')['readonly'], 'verificacao_mista_exige_post' );
global $wpdb;
$antes=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3base_%' OR option_name='cron' ORDER BY option_name", ARRAY_A);
$contrato=array();
foreach ( $consultas as $nome=>$entrada ) {
 $r=$pedir($nome,'GET',$entrada); $ok( 200 === $r->get_status(), 'admin_get:' . $nome . ':' . $r->get_status() );
 if ('f3base/config-core-contrato-v1'===$nome) { $contrato=$r->get_data(); }
 $n=count($executadas); $err=$pedir($nome,'POST',$entrada); $ok( 405===$err->get_status() && $n===count($executadas), 'post_recusado_sem_executar:' . $nome );
}
$ok( ! empty($contrato['ok']) && count($contrato['opcoes']) > 20, 'contrato_completo_sanitizado' );
$schema_contrato=wp_get_ability('f3base/config-core-contrato-v1')->get_output_schema();
$sanitizado=rest_sanitize_value_from_schema($contrato,$schema_contrato);
$ok(!is_wp_error($sanitizado),'sanitizador_nativo_aceita_contrato_registrado');
$schema_valor=$schema_contrato['properties']['opcoes']['items']['properties']['valor'];
foreach (array('007',7,1.5,true,false,array('a','b'),array('configurado'=>true,'mascarado'=>true),null) as $i=>$valor) { $ok($valor===rest_sanitize_value_from_schema($valor,$schema_valor),'sanitizador_polimorfico_tipo_' . $i); }
$tipos=array(); $segredos=0;
foreach ( $contrato['opcoes'] as $item ) {
 $foto=F3Base_Options::fotografia($item['nome']); $esperado=F3Base_Config_Contrato::visivel($item['nome'],$foto['valor']);
 $ok( $item['valor'] === $esperado && $sanitizado['opcoes'][array_search($item['nome'],array_column($contrato['opcoes'],'nome'),true)]['valor'] === $esperado, 'valor_tipo_preservado:' . $item['nome'] ); $tipos[gettype($item['valor'])]=true;
 if (F3Base_Options::e_segredo($item['nome'])) { ++$segredos; $ok( is_array($item['valor']) && true===$item['valor']['mascarado'] && is_bool($item['valor']['configurado']), 'marcador_segredo:' . $item['nome'] ); }
}
$ok( $segredos>0 && count($tipos)>=3, 'contrato_polimorfico_e_segredos' );
foreach ($operacoes as $nome=>$entrada) {
 $n=count($executadas); $err=$pedir($nome,'GET',$entrada); $ok(405===$err->get_status() && $n===count($executadas), 'get_recusado_sem_executar:' . $nome);
 if (in_array($nome,array('f3base/config-core-escrever','f3base/config-core-verificar'),true)) {
  $r=$pedir($nome,'POST',$entrada); $ok(200===$r->get_status() && !empty($r->get_data()['ok']), 'admin_post:' . $nome . ':' . $r->get_status());
  if ('f3base/config-core-escrever'===$nome) { $d=$r->get_data(); $ok(!empty($d['simulado']) && false===$d['persisted'], 'post_json_simula_sem_persistir'); }
 }
}
$depois=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3base_%' OR option_name='cron' ORDER BY option_name", ARRAY_A);
$ok($antes===$depois,'consultas_e_simulacao_preservam_options_e_cron');
wp_set_current_user(0);
foreach ($consultas + $operacoes as $nome=>$entrada) { $n=count($executadas); $r=$pedir($nome,isset($consultas[$nome])?'GET':'POST',$entrada); $ok(in_array($r->get_status(),array(401,403),true) && $n===count($executadas),'anonimo_recusado_sem_executar:' . $nome); }
wp_set_current_user(1);
$ok(!$http,'nenhum_transporte_externo');
$ok(!$avisos,'nenhum_warning_notice');
restore_error_handler();
echo wp_json_encode(array('ok'=>true,'wordpress'=>get_bloginfo('version'),'plugin'=>F3BASE_PLUGIN_VERSAO,'controller'=>'WP_REST_Abilities_V1_Run_Controller','transporte'=>'rest_get_server()->dispatch; controller e registro nativos, sem HTTP externo','active_plugins'=>$ativos,'checks'=>$checks,'respostas'=>$respostas,'opcoes'=>count($contrato['opcoes']),'tipos'=>array_keys($tipos),'segredos'=>$segredos,'warnings'=>$avisos,'http_externo'=>count($http)), JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
