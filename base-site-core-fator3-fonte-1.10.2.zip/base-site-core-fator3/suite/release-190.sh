#!/usr/bin/env bash
# Gate adicional da release: regressão, build adverso e convivência HTTP real.
set -euo pipefail
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${F3BASE_BANCADA_CACHE:?cache com WordPress, SQLite e wp-cli}"
: "${F3BASE_PLUGINS_COMPATIBILIDADE:?diretório com os ZIPs oficiais dos dois plugins}"
: "${F3BASE_APACHE_ROOT:?raiz dos binários do Apache e módulo PHP}"
: "${F3BASE_PHP_INI:?diretório do php.ini do módulo Apache}"
: "${F3BASE_HOMOLOGACAO_DIR:?diretório NOVO para a bancada e evidências}"
test ! -e "$F3BASE_HOMOLOGACAO_DIR" || { echo 'Use um diretório novo para preservar a rodada anterior.' >&2; exit 2; }
bash "$RAIZ/suite/verificar.sh" "$RAIZ"
VERSAO="$(python3 "$RAIZ/suite/versao.py")"
mkdir -p "$RAIZ/dist/evidencias/$VERSAO"
node "$RAIZ/suite/build-assets/verificar.cjs" "$RAIZ/fontes/plugin" > "$RAIZ/dist/evidencias/$VERSAO/build-negativos.json"
OPCOES=()
if [ "${F3BASE_SINGLE_UID_NAMESPACE:-0}" = '1' ]; then OPCOES+=(--single-uid-namespace); fi
python3 "$RAIZ/suite/bancada-wp/servidor-190.py" \
 --work "$F3BASE_HOMOLOGACAO_DIR" --zip "$RAIZ/dist/base-site-core-fator3-$VERSAO.zip" \
 --cache "$F3BASE_BANCADA_CACHE" --plugins "$F3BASE_PLUGINS_COMPATIBILIDADE" \
 --apache "$F3BASE_APACHE_ROOT" --php-ini "$F3BASE_PHP_INI" --prepare-only "${OPCOES[@]}"
python3 "$RAIZ/suite/bancada-wp/compatibilidade-190.py" "$F3BASE_HOMOLOGACAO_DIR"
cp "$F3BASE_HOMOLOGACAO_DIR/compatibilidade-190.json" "$RAIZ/dist/evidencias/$VERSAO/"
cp "$F3BASE_HOMOLOGACAO_DIR"/tokens-*-190.json "$RAIZ/dist/evidencias/$VERSAO/"
echo 'Regressão, build e compatibilidade aprovados para o mesmo ZIP.'
