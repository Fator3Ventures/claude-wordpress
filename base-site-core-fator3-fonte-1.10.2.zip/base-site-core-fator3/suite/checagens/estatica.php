<?php
/**
 * Checagens estáticas — rodam neste ambiente (PHP 8.4, Node 22, sem WordPress).
 *
 * Cada checagem é uma FUNÇÃO PURA que devolve `array( 'ok' => bool,
 * 'achados' => array<string> )` a partir de uma raiz. O runner e o piso chamam a
 * MESMA função: o piso aponta a fixture, o runner aponta o pacote. Nenhuma
 * regra é reimplementada no piso.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/*
 * A REGRA DO QUE A RENOMEAÇÃO NÃO REESCREVE NÃO ENTROU NESTE REPOSITÓRIO, e com
 * ela saiu `estatica.sem_residuo_de_prefixo`. A renomeação de prefixo é
 * ferramenta do IMPLANTADOR — `ferramentas/renomear-prefixo.php` e a regra
 * compartilhada `ferramentas/nomes-preservados.php` moram lá —, e o invariante
 * que ela persegue é exatamente que o PLUGIN não seja renomeado. Um detector de
 * resíduo de prefixo apontado para a árvore do plugin mediria a ausência de um
 * evento que, aqui, não pode acontecer. Está declarado em suite/excluidas.tsv.
 */

/* -------------------------------------------------------------------------
 * estatica.php_lint
 * ---------------------------------------------------------------------- */

/**
 * `php -l` em todo `.php` da raiz.
 *
 * Defeito medido que esta checagem existe para não repetir: a versão anterior
 * imprimia FALHA e saía com código 0. Aqui o resultado volta ao runner, que
 * conta pela `estado()` e devolve código de saída diferente de zero.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_php_lint( string $raiz ): array {
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$saida  = array();
		$codigo = 0;
		exec( 'php -l ' . escapeshellarg( $raiz . '/' . $rel ) . ' 2>&1', $saida, $codigo );

		if ( 0 !== $codigo ) {
			$achados[] = $rel . ': ' . trim( preg_replace( '/\s+/', ' ', implode( ' ', $saida ) ) ?? '' );
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.json_valido
 * ---------------------------------------------------------------------- */

/**
 * Todo `.json` da raiz analisa.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_json_valido( string $raiz ): array {
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'json' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$bruto = (string) file_get_contents( $raiz . '/' . $rel );
		json_decode( $bruto, true );

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			$achados[] = $rel . ': ' . json_last_error_msg();
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.js_lint
 * ---------------------------------------------------------------------- */

/**
 * `node --check` em todo `.js` e `.mjs` da raiz.
 *
 * A análise roda na sonda `checagens/js.mjs`, sob o Node de verdade: analisar
 * JavaScript com expressão regular de PHP seria inferência disfarçada de
 * medição. A sonda devolve JSON; quem imprime e conta continua sendo `estado()`.
 *
 * @param string $raiz  Raiz a varrer.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_lint( string $raiz, string $suite ): array {
	$cmd = 'node ' . escapeshellarg( $suite . '/checagens/js.mjs' ) . ' lint ' . escapeshellarg( $raiz ) . ' 2>&1';

	$saida  = array();
	$codigo = 0;
	exec( $cmd, $saida, $codigo );

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) || ! isset( $json['achados'] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'sonda js.mjs não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
		);
	}

	return array(
		'ok'      => array() === $json['achados'],
		'achados' => array_map( 'strval', $json['achados'] ),
		'medidas' => (int) ( $json['medidas'] ?? 0 ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.wp_comentarios_balanceados
 * ---------------------------------------------------------------------- */

/**
 * Analisa um documento de blocos: balanceamento e JSON de atributo.
 *
 * @param string $rotulo Nome que aparece no achado.
 * @param string $texto  Markup.
 * @return array<int,string> Achados.
 */
function f3b_blocos_analisar( string $rotulo, string $texto ): array {
	$achados = array();
	$pilha   = array();
	$re      = '/<!--\s*(\/?)wp:([a-z0-9-]+(?:\/[a-z0-9-]+)?)\s*(\{.*?\})?\s*(\/?)-->/s';

	if ( preg_match_all( $re, $texto, $ms, PREG_SET_ORDER ) ) {
		foreach ( $ms as $m ) {
			$fechando = '' !== $m[1];
			$bloco    = $m[2];
			$attrs    = $m[3] ?? '';
			$sozinho  = '' !== ( $m[4] ?? '' );

			if ( '' !== $attrs ) {
				json_decode( $attrs, true );

				if ( JSON_ERROR_NONE !== json_last_error() ) {
					$achados[] = $rotulo . ': JSON de atributo inválido em wp:' . $bloco . ' (' . json_last_error_msg() . ')';
				}
			}

			if ( $fechando ) {
				if ( array() === $pilha ) {
					$achados[] = $rotulo . ': fechamento sem abertura /wp:' . $bloco;
					continue;
				}

				$topo = array_pop( $pilha );

				if ( $topo !== $bloco ) {
					$achados[] = $rotulo . ': fechamento fora de ordem, esperava /wp:' . $topo . ' e veio /wp:' . $bloco;
				}

				continue;
			}

			if ( $sozinho ) {
				continue;
			}

			$pilha[] = $bloco;
		}
	}

	if ( array() !== $pilha ) {
		$achados[] = $rotulo . ': bloco aberto sem fechamento: wp:' . implode( ', wp:', $pilha );
	}

	return $achados;
}

/**
 * `wp:` balanceados e JSON de atributo válido em todo markup de bloco.
 *
 * Cobre `templates/`, `parts/` e `content/` no arquivo cru, e os
 * `patterns/*.php` DEPOIS DE EXECUTADOS: o defeito que importa nasce na saída,
 * não no arquivo antes das chamadas de i18n.
 *
 * @param string $raiz  Raiz a varrer.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_wp_comentarios( string $raiz, string $suite ): array {
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'html' ), f3b_excluidos() ) as $rel ) {
		if ( ! preg_match( '#(^|/)(templates|parts|content)/#', '/' . $rel ) ) {
			continue;
		}

		$medidas++;
		$achados = array_merge( $achados, f3b_blocos_analisar( $rel, (string) file_get_contents( $raiz . '/' . $rel ) ) );
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		if ( ! preg_match( '#(^|/)patterns/#', '/' . $rel ) ) {
			continue;
		}

		$saida  = array();
		$codigo = 0;
		exec(
			'php ' . escapeshellarg( $suite . '/lib/render-pattern.php' ) . ' ' . escapeshellarg( $raiz . '/' . $rel ) . ' 2>&1',
			$saida,
			$codigo
		);

		$render = implode( "\n", $saida );

		if ( 0 !== $codigo ) {
			$achados[] = $rel . ' (executado): o pattern não renderizou — ' . f3b_amostra( $saida, 2 );
			continue;
		}

		$medidas++;
		$achados = array_merge( $achados, f3b_blocos_analisar( $rel . ' (executado)', $render ) );
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_escrita_unica
 * ---------------------------------------------------------------------- */

/**
 * Nenhuma escrita direta de option fora do gravador único.
 *
 * Varre as fontes e ferramentas; bancadas WordPress isoladas ficam fora porque
 * precisam plantar gravações recusadas. A fachada e seu trait privado de
 * persistência compõem o mesmo gravador; módulos permanecem cobertos.
 *
 * Comentário não conta: a varredura mede o que EXECUTA (ver `f3b_codigo_php()`).
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_escrita_unica( string $raiz ): array {
	/*
	 * UM GRAVADOR SÓ, e a lista encolheu junto com o repositório. No implantador
	 * eram dois — o dele, em `includes/`, e o do plugin — porque a árvore tinha
	 * os dois runtimes. Aqui existe o do PLUGIN e mais nenhum: qualquer
	 * `update_option()` fora dele tira a escrita do catálogo, da sanitização que
	 * preserva a chave desconhecida e da procedência.
	 */
	$gravadores = array(
		'fontes/plugin/includes/class-f3base-options.php',
		'fontes/plugin/includes/trait-f3base-options-persistencia.php',
	);

	$nomes = array(
		'update_option',
		'add_option',
		'delete_option',
		'update_site_option',
		'add_site_option',
		'delete_site_option',
		'set_theme_mod',
		'remove_theme_mod',
	);

	$re      = '/(?<![A-Za-z0-9_$>])(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '/';
	$achados = array();
	$medidas = 0;

	/*
	 * DEFINIR a função do núcleo não é ESCREVER uma option. A regra fala de
	 * chamada: `update_option( ... )` fora do gravador tira a escrita do journal
	 * e da procedência. Uma bancada de sonda, que roda fora do WordPress, PRECISA
	 * declarar `function update_option()` para que o código real do pacote tenha
	 * onde cair — e num WordPress de verdade essa declaração nem existiria, porque
	 * redeclarar função do núcleo é erro fatal. A definição sai da linha antes do
	 * teste, e o que sobrar dela continua sendo medido: `function f( ... ) {
	 * update_option( ... ); }` na mesma linha continua sendo achado.
	 */
	$re_definicao = '/(?<![A-Za-z0-9_$>])function\s+&?\s*(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '/';

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/110/', 'suite/bancada-wp/', 'suite/medicao-110/', 'suite/versao-110/', 'suite/versao-1102/' ) ) ) as $rel ) {
		if ( in_array( $rel, $gravadores, true ) ) {
			continue;
		}

		$medidas++;

		$linhas = preg_split( '/\R/', f3b_codigo_php( $raiz . '/' . $rel ) ) ?: array();

		foreach ( $linhas as $n => $linha ) {
			$sem_definicao = preg_replace( $re_definicao, '', $linha );
			$sem_definicao = is_string( $sem_definicao ) ? $sem_definicao : $linha;

			if ( preg_match( $re, $sem_definicao, $m ) ) {
				$achados[] = $rel . ':' . ( $n + 1 ) . ' ' . $m[1] . '()';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_version_compare
 * ---------------------------------------------------------------------- */

/**
 * `version_compare()` só com operador da lista fechada.
 *
 * `===` não é operador de `version_compare()`: em PHP 8 ele explode em runtime,
 * e o defeito só aparece no caminho que executa aquela linha. Operador ausente
 * também é achado — sem operador a função devolve int, nunca bool.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_version_compare( string $raiz ): array {
	$permitidos = array( '<', 'lt', '<=', 'le', '>', 'gt', '>=', 'ge', '==', '=', 'eq', '!=', '<>', 'ne' );
	$achados    = array();
	$medidas    = 0;

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		foreach ( f3b_chamadas( f3b_codigo_php( $raiz . '/' . $rel ), 'version_compare' ) as $args ) {
			$medidas++;
			$partes = array_map( 'trim', explode( ',', $args ) );

			if ( count( $partes ) < 3 ) {
				$achados[] = $rel . ': operador ausente (sem operador a função devolve int, nunca bool)';
				continue;
			}

			$operador = trim( (string) end( $partes ), " '\"" );

			if ( ! in_array( $operador, $permitidos, true ) ) {
				$achados[] = $rel . ": operador '" . $operador . "' fora da lista fechada";
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_condicao_literal
 * ---------------------------------------------------------------------- */

/**
 * Bloco `{ ... }` que contém a posição dada.
 *
 * @param string $src Código.
 * @param int    $pos Posição.
 * @return array{0:int,1:int}|null Abertura e fechamento, ou null.
 */
function f3b_bloco_envolvente( string $src, int $pos ): ?array {
	$pilha = array();
	$abre  = null;

	for ( $i = 0; $i < strlen( $src ); $i++ ) {
		if ( '{' === $src[ $i ] ) {
			$pilha[] = $i;
		} elseif ( '}' === $src[ $i ] ) {
			$ini = array_pop( $pilha );

			if ( null !== $ini && $ini < $pos && $i > $pos ) {
				if ( null === $abre || $ini > $abre[0] ) {
					$abre = array( $ini, $i );
				}
			}
		}
	}

	return $abre;
}

/**
 * Condição literal em checagem, COM ESCOPO.
 *
 * `check(true, …)`, `estado(true, …)` e `assert(1, …)` são proibidos: a linha
 * imprime um veredito decidido no código-fonte, não observado.
 *
 * O escopo é o que separa o defeito do idioma legítimo: literal dentro de um
 * ramo de `if`/`else` cujo ramo IRMÃO emite outro veredito não é condição
 * constante — o que decide ali é o `if`, e o literal só nomeia qual dos dois
 * lados aquele ramo é. Por isso o piso desta checagem tem os dois lados.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_condicao_literal( string $raiz ): array {
	$nomes   = array( 'check', 'estado', 'assert', 'avaliar', 'afirmar', 'condicional', 'verificar' );
	$re      = '/(?<![A-Za-z0-9_$>])(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '\s*(true|false|TRUE|FALSE|1|0)\s*,/';
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! preg_match_all( $re, $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			continue;
		}

		foreach ( $ms as $m ) {
			$pos     = (int) $m[0][1];
			$chamada = $m[1][0] . '(' . $m[2][0] . ', …)';
			$linha   = substr_count( substr( $src, 0, $pos ), "\n" ) + 1;

			if ( f3b_literal_legitimo( $src, $pos, $nomes, $m[2][0] ) ) {
				continue;
			}

			$achados[] = $rel . ':' . $linha . ' ' . $chamada;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/**
 * O literal está num ramo cujo IRMÃO emite outro veredito?
 *
 * @param string            $src     Código.
 * @param int               $pos     Posição do literal.
 * @param array<int,string> $nomes   Nomes de função de checagem.
 * @param string            $literal Literal encontrado.
 * @return bool
 */
function f3b_literal_legitimo( string $src, int $pos, array $nomes, string $literal ): bool {
	$bloco = f3b_bloco_envolvente( $src, $pos );

	if ( null === $bloco ) {
		return false;
	}

	list( $abre, $fecha ) = $bloco;

	$antes  = rtrim( substr( $src, 0, $abre ) );
	$depois = ltrim( substr( $src, $fecha + 1 ) );

	$e_if   = (bool) preg_match( '/(?<![A-Za-z0-9_])(if|elseif)\s*\)?\s*$/', $antes ) || (bool) preg_match( '/\)\s*$/', $antes ) && (bool) preg_match( '/(?<![A-Za-z0-9_])(if|elseif)\s*\(/', $antes );
	$e_else = (bool) preg_match( '/(?<![A-Za-z0-9_])else\s*$/', $antes );

	if ( ! $e_if && ! $e_else ) {
		return false;
	}

	$irmao = '';

	if ( $e_if && preg_match( '/^else\b/', $depois ) ) {
		$sub = f3b_bloco_envolvente( $depois . '}', strpos( $depois, '{' ) + 1 );

		if ( null !== $sub ) {
			$irmao = substr( $depois, $sub[0], $sub[1] - $sub[0] );
		}
	}

	if ( $e_else ) {
		$corte = substr( $src, 0, $abre );
		$ini   = strrpos( $corte, '}' );

		if ( false !== $ini ) {
			$par = f3b_bloco_envolvente( substr( $src, 0, $ini + 1 ), $ini - 1 );

			if ( null !== $par ) {
				$irmao = substr( $src, $par[0], $par[1] - $par[0] );
			}
		}
	}

	if ( '' === $irmao ) {
		return false;
	}

	$re = '/(?<![A-Za-z0-9_$>])(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '\s*(true|false|TRUE|FALSE|1|0)\s*,/';

	if ( ! preg_match_all( $re, $irmao, $ms, PREG_SET_ORDER ) ) {
		return false;
	}

	$normaliza = static function ( string $v ): string {
		return in_array( strtolower( $v ), array( 'true', '1' ), true ) ? 'v' : 'f';
	};

	foreach ( $ms as $m ) {
		if ( $normaliza( $m[2] ) !== $normaliza( $literal ) ) {
			return true;
		}
	}

	return false;
}

/* -------------------------------------------------------------------------
 * estatica.detector_codigo_em_string
 * ---------------------------------------------------------------------- */

/**
 * O texto parece JavaScript, SQL ou shell?
 *
 * @param string $texto Texto.
 * @return string Linguagem detectada, ou string vazia.
 */
function f3b_linguagem_em_texto( string $texto ): string {
	$js = array( '<script', 'document.', 'window.', 'addEventListener', 'querySelector', 'function (', 'function(', '=>', 'console.log' );

	foreach ( $js as $marca ) {
		if ( false !== stripos( $texto, $marca ) ) {
			return 'javascript';
		}
	}

	if ( preg_match( '/\b(SELECT\b.+\bFROM|INSERT\s+INTO|DELETE\s+FROM|UPDATE\b.+\bSET|DROP\s+TABLE|CREATE\s+TABLE)\b/is', $texto ) ) {
		return 'sql';
	}

	if ( preg_match( '/(#!\/bin\/|\brm\s+-rf\b|\bshell_exec\b|\bpassthru\b|\bsudo\s|\|\s*grep\b|&&\s*\w+\s)/i', $texto ) ) {
		return 'shell';
	}

	return '';
}

/**
 * Nenhum JS, SQL ou shell dentro de heredoc ou de concatenação PHP.
 *
 * Escopo declarado: heredoc/nowdoc de qualquer conteúdo executável, string
 * literal montada por CONCATENAÇÃO (`.`) e `<script>` inline com corpo.
 * `<script src="…">` sem corpo fica de fora — é referência a arquivo, que é
 * exatamente o que a regra manda fazer. SQL entregue direto a
 * `$wpdb->prepare()` também fica de fora: é a forma sancionada, e o que a regra
 * proíbe é a montagem por pedaços.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_codigo_em_string( string $raiz ): array {
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/110/', 'suite/bancada-wp/', 'suite/medicao-110/', 'suite/versao-110/', 'suite/versao-1102/' ) ) );

	foreach ( $alvos as $rel ) {
		$tokens   = token_get_all( (string) file_get_contents( $raiz . '/' . $rel ) );
		$heredoc  = false;
		$corpo    = '';
		$linha_hd = 0;
		$anterior = null;

		foreach ( $tokens as $token ) {
			if ( is_array( $token ) && T_START_HEREDOC === $token[0] ) {
				$heredoc  = true;
				$corpo    = '';
				$linha_hd = $token[2];
				continue;
			}

			if ( is_array( $token ) && T_END_HEREDOC === $token[0] ) {
				$lingua = f3b_linguagem_em_texto( $corpo );

				if ( '' !== $lingua ) {
					$achados[] = $rel . ':' . $linha_hd . ' heredoc com ' . $lingua;
				}

				$heredoc = false;
				continue;
			}

			if ( $heredoc ) {
				$corpo .= is_array( $token ) ? $token[1] : $token;
				continue;
			}

			if ( is_array( $token ) && in_array( $token[0], array( T_COMMENT, T_DOC_COMMENT, T_WHITESPACE ), true ) ) {
				continue;
			}

			if ( is_array( $token ) && T_CONSTANT_ENCAPSED_STRING === $token[0] ) {
				$conteudo = substr( $token[1], 1, -1 );
				$lingua   = f3b_linguagem_em_texto( $conteudo );

				if ( '' !== $lingua && '.' === $anterior ) {
					$achados[] = $rel . ':' . $token[2] . ' concatenação com ' . $lingua;
				}

				/*
				 * A expressão e a mensagem são montadas por pedaços de propósito:
				 * escritas inteiras, elas conteriam o próprio marcador e este
				 * detector reprovaria a si mesmo — o detector que grita por
				 * causa de si é tão inútil quanto o que nunca grita.
				 */
				$re_inline = '/<' . 'script(?![^>]*\bsrc=)[^>]*>\s*\S/i';

				if ( 'javascript' === $lingua && preg_match( $re_inline, $conteudo ) ) {
					$achados[] = $rel . ':' . $token[2] . ' tag de script inline com corpo';
				}
			}

			$anterior = is_array( $token ) ? $token[1] : $token;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_chave_sem_consumidor
 * ---------------------------------------------------------------------- */

/**
 * Cabeçalho de uma leitura de configuração: qualquer classe terminada em
 * `Config`, seguida de `::obter`, `::lista` ou `::existe` e do parêntese.
 */
const F3B_RE_CONFIG = '/(?<![A-Za-z0-9_])[A-Za-z0-9_\\\\]*Config::(?:obter|lista|existe)\s*\(/';

/**
 * Caminhos de configuração lidos por código, na raiz inteira.
 *
 * Resolve três formas: literal puro, literal concatenado com variável (o índice
 * dinâmico vira `*`) e a função intermediária — aquela que recebe um caminho
 * por parâmetro e lê sufixos a partir dele. A terceira forma é resolvida pelos
 * literais dos CHAMADORES, senão a chave lida por dentro de um agrupador ficaria
 * eternamente órfã.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<int,string>
 */
function f3b_caminhos_lidos( string $raiz ): array {
	$lidas = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_chamadas_regex( $src, F3B_RE_CONFIG ) as $args ) {
			$caminho = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args ) ) );

			if ( '' !== $caminho && ! str_starts_with( $caminho, '*' ) ) {
				$lidas[ $caminho ] = true;
			}
		}

		/* Funções intermediárias: parâmetro de caminho + sufixos literais. */
		if ( preg_match_all( '/function\s+(\w+)\s*\(\s*string\s+(\$\w+)[^)]*\)\s*:\s*\w+\s*\{/', $src, $fs, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			foreach ( $fs as $f ) {
				$nome  = $f[1][0];
				$param = $f[2][0];
				$bloco = f3b_bloco_envolvente( $src, (int) $f[0][1] + strlen( $f[0][0] ) );

				if ( null === $bloco ) {
					continue;
				}

				$corpo    = substr( $src, $bloco[0], $bloco[1] - $bloco[0] );
				$sufixos  = array();

				foreach ( f3b_chamadas_regex( $corpo, F3B_RE_CONFIG ) as $args ) {
					$primeiro = trim( f3b_primeiro_argumento( $args ) );

					if ( ! str_starts_with( $primeiro, $param ) ) {
						continue;
					}

					$resto     = trim( substr( $primeiro, strlen( $param ) ) );
					$sufixos[] = f3b_expressao_para_caminho( $resto );
				}

				if ( array() === $sufixos ) {
					continue;
				}

				foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel2 ) {
					$src2 = f3b_codigo_php( $raiz . '/' . $rel2 );

					$re_sitio = '/(?<![A-Za-z0-9_])(?:(?:self|static|parent|[A-Za-z0-9_\\\\]+)::)?' . preg_quote( $nome, '/' ) . '\s*\(/';

					foreach ( f3b_chamadas_regex( $src2, $re_sitio ) as $args2 ) {
						$base = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args2 ) ) );

						if ( '' === $base || str_starts_with( $base, '*' ) ) {
							continue;
						}

						foreach ( $sufixos as $sufixo ) {
							$lidas[ f3b_caminho_normalizado( $base . $sufixo ) ] = true;
						}
					}
				}
			}
		}
	}

	return array_keys( $lidas );
}

/**
 * Primeiro argumento de uma lista de argumentos, respeitando aninhamento.
 *
 * @param string $args Argumentos.
 * @return string
 */
function f3b_primeiro_argumento( string $args ): string {
	$nivel = 0;
	$saida = '';

	for ( $i = 0; $i < strlen( $args ); $i++ ) {
		$c = $args[ $i ];

		if ( '(' === $c || '[' === $c ) {
			$nivel++;
		}

		if ( ')' === $c || ']' === $c ) {
			$nivel--;
		}

		if ( ',' === $c && 0 === $nivel ) {
			break;
		}

		$saida .= $c;
	}

	return trim( $saida );
}

/**
 * Converte uma expressão de caminho em caminho pontilhado, com `*` no dinâmico.
 *
 * Anda caractere a caractere e respeita as aspas: o ponto DENTRO de um literal
 * (`'consentimento.ttl_dias'`) faz parte do caminho, e o ponto FORA dele é o
 * operador de concatenação. Tratar os dois igual apagava todo caminho com mais
 * de um segmento — e o cruzamento passava a acusar como órfã a chave que o
 * código lê na linha de cima.
 *
 * A borda NÃO é aparada aqui: um sufixo legítimo começa por ponto
 * (`.*.id`), e apará-lo colaria o índice no nome da chave-pai. Quem monta o
 * caminho final apara.
 *
 * @param string $expr Expressão.
 * @return string
 */
function f3b_expressao_para_caminho( string $expr ): string {
	$expr = trim( $expr );
	$tam  = strlen( $expr );
	$i    = 0;
	$saida = '';

	while ( $i < $tam ) {
		$c = $expr[ $i ];

		if ( ' ' === $c || "\t" === $c || "\n" === $c || "\r" === $c || '.' === $c ) {
			$i++;
			continue;
		}

		if ( "'" === $c || '"' === $c ) {
			$aspas = $c;
			$i++;
			$buf = '';

			while ( $i < $tam ) {
				if ( '\\' === $expr[ $i ] && $i + 1 < $tam ) {
					$buf .= $expr[ $i + 1 ];
					$i   += 2;
					continue;
				}

				if ( $expr[ $i ] === $aspas ) {
					$i++;
					break;
				}

				$buf .= $expr[ $i ];
				$i++;
			}

			$saida .= $buf;
			continue;
		}

		/* Variável, chamada ou constante: índice que só existe em execução. */
		$saida .= '*';
		$nivel  = 0;

		while ( $i < $tam ) {
			$c2 = $expr[ $i ];

			if ( '(' === $c2 || '[' === $c2 ) {
				$nivel++;
			}

			if ( ')' === $c2 || ']' === $c2 ) {
				$nivel--;
			}

			if ( 0 === $nivel && '.' === $c2 ) {
				break;
			}

			$i++;
		}
	}

	return (string) preg_replace( '/\.{2,}/', '.', $saida );
}

/**
 * Normaliza um caminho montado, apando as bordas.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function f3b_caminho_normalizado( string $caminho ): string {
	return trim( (string) preg_replace( '/\.{2,}/', '.', $caminho ), '.' );
}

/**
 * Caminhos de configuração consumidos PELA PRÓPRIA SUÍTE. ÂNCORA DECLARADA.
 *
 * POR QUE ESTA ÂNCORA EXISTE. O cruzamento de consumidores enxerga UMA forma de
 * leitura: `Config::obter|lista|existe`, que é a do implantador. Enquanto toda
 * chave do arquivo único tivesse também um leitor no implantador, isso bastava —
 * e bastou por acaso, não por desenho. Na 1.1.0 `f3base_copy_contrato` saiu do
 * catálogo do site-core e a escrita da option saiu do implantador (decisão 56):
 * o contrato de copy passou a ser o que sempre foi, ARTEFATO DE BUILD DA SUÍTE,
 * lido por `copy.contrato` direto do JSON decodificado. Sem esta âncora, a saída
 * de uma option morta faria o detector acusar como órfã uma chave que TEM
 * consumidor — e a correção óbvia seria devolver a option morta.
 *
 * A DECLARAÇÃO NÃO ABSOLVE SOZINHA, e é isso que a separa de uma lista de
 * exceções: cada caminho declarado precisa aparecer, LITERALMENTE, no arquivo da
 * suíte que se diz o consumidor. Caminho declarado que ninguém menciona é achado
 * com o mesmo peso de uma chave órfã — declaração que absolve sem medir é pior
 * que a ausência dela.
 *
 * @return array<string,string> Caminho pontilhado => arquivo da suíte que o lê.
 */
function f3b_config_lida_pela_suite(): array {
	return array(
		'copy_contrato' => 'checagens/copy.php',
	);
}

/**
 * Toda chave declarada em `config/site.json` tem alguma linha que a lê.
 *
 * Cruzamento GERAL, nunca por seção: a cobertura é bidirecional — chave-pai
 * lida cobre os filhos, e caminho lido mais fundo que a chave também a cobre.
 * A própria `consumidores_declarados` entra na varredura como qualquer outra.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_chave_sem_consumidor( string $raiz ): array {
	$arquivo = $raiz . '/config/site.json';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente na raiz varrida' ),
		);
	}

	$json = json_decode( (string) file_get_contents( $arquivo ), true );

	if ( ! is_array( $json ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json não analisa' ),
		);
	}

	$declaradas = array();
	f3b_achatar( $json, '', $declaradas );
	$declaradas = array_keys( $declaradas );

	$lidas   = f3b_caminhos_lidos( $raiz );
	$achados = array();

	/*
	 * A CONSUMIÇÃO DA SUÍTE ENTRA MEDIDA, nunca declarada e pronto. A âncora é
	 * conferida contra a SUÍTE QUE ESTÁ RODANDO — `dirname( __DIR__ )` —, e não
	 * contra a raiz varrida: quando o piso roda este detector sobre uma fixture,
	 * a fixture não tem suíte, e cobrar o arquivo dela ali reprovaria o caso
	 * correto por uma condição que nada tem a ver com o defeito plantado.
	 */
	$suite_da_rodada = dirname( __DIR__ );

	foreach ( f3b_config_lida_pela_suite() as $caminho => $arquivo ) {
		$absoluto = $suite_da_rodada . '/' . $arquivo;

		if ( ! is_file( $absoluto ) || ! str_contains( (string) file_get_contents( $absoluto ), "'" . $caminho . "'" ) ) {
			$achados[] = 'f3b_config_lida_pela_suite() declara que "' . $caminho . '" é lida por suite/' . $arquivo
				. ', e esse arquivo não existe ou não menciona o caminho: declaração que absolve sem medir é pior que '
				. 'a ausência dela, porque ela silencia o cruzamento sem que nada tenha sido conferido';
			continue;
		}

		$lidas[] = $caminho;
	}

	foreach ( $declaradas as $chave ) {
		if ( str_starts_with( $chave, '$schema' ) ) {
			$chave_busca = $chave;
		} else {
			$chave_busca = $chave;
		}

		if ( in_array( $chave_busca, $lidas, true ) ) {
			continue;
		}

		$coberta = false;

		foreach ( $lidas as $lida ) {
			if ( str_starts_with( $chave_busca, $lida . '.' ) || str_starts_with( $lida, $chave_busca . '.' ) ) {
				$coberta = true;
				break;
			}
		}

		if ( ! $coberta ) {
			$achados[] = $chave_busca;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $declaradas ),
		'lidos'   => count( $lidas ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.destino_de_formulario_resolve
 * ---------------------------------------------------------------------- */

/**
 * O `destino` de cada regime de formulário APONTA PARA UMA CHAVE QUE EXISTE.
 *
 * POR QUE ESTE DETECTOR EXISTE, e o que mudou na 1.1.0. `formularios[].destino`
 * é um CAMINHO — o código o resolve com `Config::obter( $destino, '' )` — e
 * caminho que não resolve devolve string vazia, calado. Vazio é exatamente o
 * valor que faz o regime "não existir": um destino digitado errado produziria
 * um N/A perfeitamente redigido, apontando para uma chave que ninguém pode
 * preencher porque ela não está no arquivo. O estado seria verde e a mensagem,
 * uma instrução impossível.
 *
 * Enquanto todo destino apontava para `contato.*` isso era teoria. Na 1.1.0 a
 * caixa de leads do regime `cf7-email` passou a morar DENTRO da entrada dele, e
 * o caminho ficou `formularios.<indice>.caixa_de_leads` — com um ÍNDICE dentro.
 * Índice em caminho quebra quando alguém reordena a lista, e quebra em silêncio:
 * a entrada 1 passa a ler a chave da entrada 0. É esse preço, criado por esta
 * release, que este detector cobra.
 *
 * Três achados, e cada um fecha um caminho de volta:
 *
 * 1. **Entrada sem `destino`**: sem caminho não há nem o que preencher.
 * 2. **`destino` que não resolve em `config/site.json`**: a instrução do N/A
 *    aponta para uma chave que não existe.
 * 3. **`destino` que entra em `formularios` pelo índice de OUTRA entrada**: o
 *    regime lê o destino do vizinho, e os dois estados ficam trocados.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_destino_de_formulario_resolve( string $raiz ): array {
	/*
	 * O BLOCO E O ALVO DO PONTEIRO MORAM NO MESMO ARQUIVO, e é isso que esta
	 * checagem confere. `formularios` é uma trinca — decisão do pacote,
	 * referência interna e dado do operador no mesmo registro — e `destino`
	 * guarda o CAMINHO PONTILHADO de outra chave de `config/projeto.json`.
	 * Partido entre dois arquivos, o ponteiro apontaria para um registro que já
	 * não existe inteiro: a leitura devolveria vazio em silêncio e o regime
	 * fecharia N/A dizendo que falta preencher uma chave que está preenchida.
	 */
	$config = json_decode( (string) @file_get_contents( $raiz . '/config/projeto.json' ), true );

	if ( ! is_array( $config ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/projeto.json ausente ou inválido na raiz varrida: sem formularios[] não há destino a resolver' ),
			'medidas' => 0,
		);
	}

	$entradas = (array) ( $config['formularios'] ?? array() );
	$achados  = array();
	$medidas  = 0;

	foreach ( $entradas as $indice => $entrada ) {
		if ( ! is_array( $entrada ) ) {
			continue;
		}

		$id      = (string) ( $entrada['id'] ?? ( 'formularios[' . $indice . ']' ) );
		$caminho = trim( (string) ( $entrada['destino'] ?? '' ) );

		++$medidas;

		if ( '' === $caminho ) {
			$achados[] = 'a entrada "' . $id . '" não declara "destino": sem caminho de configuração não existe nem o que '
				. 'preencher, e o regime nunca pode passar a existir';
			continue;
		}

		++$medidas;

		$segmentos = explode( '.', $caminho );
		$valor     = $config;
		$resolveu  = true;

		foreach ( $segmentos as $segmento ) {
			if ( ! is_array( $valor ) || ! array_key_exists( $segmento, $valor ) ) {
				$resolveu = false;
				break;
			}

			$valor = $valor[ $segmento ];
		}

		if ( ! $resolveu ) {
			$achados[] = 'a entrada "' . $id . '" aponta destino para "' . $caminho . '", que NÃO existe em '
				. 'config/site.json: o caminho devolve vazio em silêncio, o regime fecha N/A nomeando uma chave que '
				. 'ninguém pode preencher, e o relatório sai verde com uma instrução impossível';
			continue;
		}

		++$medidas;

		if ( 'formularios' === ( $segmentos[0] ?? '' ) && (string) $indice !== (string) ( $segmentos[1] ?? '' ) ) {
			$achados[] = 'a entrada "' . $id . '" é a de índice ' . $indice . ' e aponta destino para "' . $caminho
				. '", que entra em formularios pelo índice ' . (string) ( $segmentos[1] ?? '' ) . ': o regime leria o '
				. 'destino da entrada vizinha, e os dois estados sairiam trocados sem que nada acusasse';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.gate_de_fase_do_metadado
 * ---------------------------------------------------------------------- */

/**
 * A lista de gates de FASE sai do METADADO, e não existe uma segunda fonte.
 *
 * O defeito medido na 1.0.17: havia DUAS fontes para o mesmo fato — uma lista
 * literal em `gates_de_fase()`, com UM nome, e o metadado `gate` por checagem,
 * com DOIS emissores. Duas fontes divergem, e a divergência saiu impressa dentro
 * de UMA linha do log, unidade `entrega`: "Nenhuma pendência de fase em aberto"
 * ao lado de "Pendência(s) de FASE dentro desta unidade — 1 …
 * orcamento.medicao_de_pagina (BLOCKED)".
 *
 * Três achados, e cada um fecha um caminho de volta:
 *
 * 1. **Nome de checagem literal dentro de `gates_de_fase()`**: a lista paralela
 *    voltou, e o próximo emissor de `gate=fase` que ninguém acrescentar a ela
 *    reabre a divergência.
 * 2. **O mesmo nome nos dois gates**: um nome que é entregável do gate de
 *    aplicação E emite `gate=fase` decide e não decide a autodesativação ao
 *    mesmo tempo.
 * 3. **Emissor de `gate=fase` sem nome literal**: o nome entra na lista derivada
 *    valendo o que a variável tiver, e o operador não consegue achá-lo na fonte.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_gate_de_fase_do_metadado( string $raiz ): array {
	$forma_de_nome = '/^[a-z][a-z0-9_]*\.[a-z0-9_.-]+$/';
	$emissoras     = array( 'emitir', 'avaliar', 'condicional', 'emitir_unidade' );

	$achados     = array();
	$medidas     = 0;
	$de_fase     = array();
	$corpo_fase  = '';
	$corpo_gate  = '';

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( 'gates_de_fase' === $funcao['nome'] ) {
				$corpo_fase = $funcao['corpo'];
			}

			if ( 'entregaveis_do_gate_de_aplicacao' === $funcao['nome'] ) {
				$corpo_gate = $funcao['corpo'];
			}
		}

		$posicao = 0;

		while ( true ) {
			$onde = strpos( $src, "'gate'", $posicao );

			if ( false === $onde ) {
				break;
			}

			$posicao = $onde + 1;

			if ( 1 !== preg_match( '/^\'gate\'\s*=>\s*\'fase\'/', substr( $src, $onde, 40 ) ) ) {
				continue;
			}

			++$medidas;

			$inicio = max( 0, $onde - 4000 );
			$antes  = substr( $src, $inicio, $onde - $inicio );
			$nome   = '';

			foreach ( $emissoras as $emissora ) {
				$abre = strrpos( $antes, $emissora . '(' );

				if ( false === $abre ) {
					continue;
				}

				if ( preg_match_all( '/\'([a-z][a-z0-9_]*\.[a-z0-9_.-]+)\'/', substr( $antes, $abre ), $ms ) ) {
					$nome = (string) $ms[1][0];
				}

				break;
			}

			if ( '' === $nome ) {
				$achados[] = $rel . ': emissor com gate=fase sem NOME LITERAL de checagem no argumento — a lista de gates de fase sai do metadado, '
					. 'e um emissor cujo nome vem de variável entra nela valendo o que a variável tiver, sem que o operador consiga achá-lo na fonte';
				continue;
			}

			$de_fase[ $nome ] = $rel;
		}
	}

	if ( '' === $corpo_fase ) {
		return array(
			'ok'      => false,
			'achados' => array( 'nenhuma função gates_de_fase() foi encontrada fora de suite/: sem a âncora não há como saber se a lista é derivada ou literal' ),
			'medidas' => max( 1, $medidas ),
		);
	}

	foreach ( array( 'gates_de_fase()' => $corpo_fase ) as $funcao => $corpo ) {
		if ( ! preg_match_all( '/\'([^\']+)\'/', $corpo, $ms ) ) {
			continue;
		}

		foreach ( $ms[1] as $literal ) {
			if ( 1 === preg_match( $forma_de_nome, $literal ) ) {
				$achados[] = $funcao . ' traz o nome de checagem literal "' . $literal . '": a lista paralela voltou. '
					. 'Duas fontes para o mesmo fato divergem, e a divergência da 1.0.17 saiu impressa dentro de uma linha só do log — '
					. '"Nenhuma pendência de fase em aberto" ao lado de "Pendência(s) de FASE dentro desta unidade — 1". A lista sai do metadado gate=fase';
			}
		}
	}

	if ( '' !== $corpo_gate && preg_match_all( '/\'([^\']+)\'/', $corpo_gate, $ms ) ) {
		foreach ( $ms[1] as $literal ) {
			if ( isset( $de_fase[ $literal ] ) ) {
				$achados[] = '"' . $literal . '" é entregável do gate de APLICAÇÃO e emite gate=fase em ' . $de_fase[ $literal ]
					. ': o mesmo nome decide e não decide a autodesativação, e o gate que ganhar depende de qual lista for consultada primeiro';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => max( 1, $medidas ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.sem_residuo_de_chave_removida
 * ---------------------------------------------------------------------- */

/**
 * Chaves de configuração REMOVIDAS, declaradas em `suite/chaves-removidas.tsv`.
 *
 * Cinco campos: a chave no caminho pontilhado (com `*` no índice de lista), os
 * TOKENS literais que não podem sobreviver no código nem nos documentos
 * (separados por `|`), a release que a removeu, os arquivos onde a REMOÇÃO é
 * narrada — e só eles podem nomear a chave — e o motivo.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<int,array{chave:string,tokens:array<int,string>,release:string,narrativa:array<int,string>,motivo:string}>
 */
function f3b_chaves_removidas( string $raiz ): array {
	$saida = array();

	foreach ( f3b_tsv( $raiz . '/suite/chaves-removidas.tsv' ) as $linha ) {
		$chave = trim( $linha[0] ?? '' );

		if ( '' === $chave ) {
			continue;
		}

		$saida[] = array(
			'chave'     => $chave,
			'tokens'    => array_values( array_filter( array_map( 'trim', explode( '|', (string) ( $linha[1] ?? '' ) ) ) ) ),
			'release'   => trim( $linha[2] ?? '' ),
			'narrativa' => array_values( array_filter( array_map( 'trim', explode( '|', (string) ( $linha[3] ?? '' ) ) ) ) ),
			'motivo'    => trim( $linha[4] ?? '' ),
		);
	}

	return $saida;
}

/**
 * Caminhos que um schema JSON declara, na mesma forma pontilhada do config.
 *
 * @param mixed              $no      Nó do schema.
 * @param string             $prefixo Prefixo acumulado.
 * @param array<string,bool> $acumula Acumulador por referência.
 * @return void
 */
function f3b_caminhos_do_schema( $no, string $prefixo, array &$acumula ): void {
	if ( ! is_array( $no ) ) {
		return;
	}

	if ( isset( $no['properties'] ) && is_array( $no['properties'] ) ) {
		foreach ( $no['properties'] as $nome => $filho ) {
			$caminho             = '' === $prefixo ? (string) $nome : $prefixo . '.' . $nome;
			$acumula[ $caminho ] = true;
			f3b_caminhos_do_schema( $filho, $caminho, $acumula );
		}
	}

	if ( isset( $no['items'] ) ) {
		f3b_caminhos_do_schema( $no['items'], '' === $prefixo ? '*' : $prefixo . '.*', $acumula );
	}

	foreach ( array( 'oneOf', 'anyOf', 'allOf' ) as $composicao ) {
		if ( ! isset( $no[ $composicao ] ) || ! is_array( $no[ $composicao ] ) ) {
			continue;
		}

		foreach ( $no[ $composicao ] as $ramo ) {
			f3b_caminhos_do_schema( $ramo, $prefixo, $acumula );
		}
	}
}

/**
 * Chave REMOVIDA não deixa resíduo em configuração, schema, código nem documento.
 *
 * POR QUE ESTE DETECTOR EXISTE. Remover uma chave é fácil no arquivo de
 * configuração e difícil no resto: o schema continua exigindo-a, uma linha de
 * código continua lendo-a — e lendo vazio, calada —, e o README continua
 * ensinando o operador a preenchê-la. O resultado é pior do que não ter
 * removido: a configuração diz uma coisa, o documento diz outra, e o código não
 * faz nenhuma das duas. `estatica.detector_chave_sem_consumidor` cruza no
 * sentido declarada → lida e não enxerga nada disso, porque a chave deixou de
 * ser declarada.
 *
 * Três medições por chave removida, e as três com o nome do arquivo:
 *
 * 1. **Configuração**: o caminho não pode reaparecer em `config/site.json`.
 * 2. **Schema**: nem em `config/site.schema.json`, em `properties` nem em
 *    `required` — schema que ainda exige a chave reprova todo config correto.
 * 3. **Código e documento**: nenhum TOKEN declarado pode sobreviver fora dos
 *    arquivos onde a REMOÇÃO é narrada. A narrativa é declarada, e é ela que
 *    permite à memória de decisões explicar por que a chave saiu sem que a
 *    explicação vire resíduo.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_sem_residuo_de_chave_removida( string $raiz ): array {
	$removidas = f3b_chaves_removidas( $raiz );
	$achados   = array();
	$medidas   = 0;

	if ( array() === $removidas ) {
		return array(
			'ok'      => true,
			'achados' => array(),
			'medidas' => 0,
		);
	}

	$config      = f3b_config( $raiz ) ?? array();
	$declaradas  = array();
	f3b_achatar( $config, '', $declaradas );

	$schema  = json_decode( (string) @file_get_contents( $raiz . '/config/site.schema.json' ), true );
	$no_schema = array();

	if ( is_array( $schema ) ) {
		f3b_caminhos_do_schema( $schema, '', $no_schema );
	}

	$exigidas = array();

	if ( is_array( $schema ) ) {
		$pilha = array( $schema );

		while ( array() !== $pilha ) {
			$no = array_pop( $pilha );

			if ( ! is_array( $no ) ) {
				continue;
			}

			foreach ( (array) ( $no['required'] ?? array() ) as $obrigatoria ) {
				$exigidas[ (string) $obrigatoria ] = true;
			}

			foreach ( $no as $filho ) {
				if ( is_array( $filho ) ) {
					$pilha[] = $filho;
				}
			}
		}
	}

	$arquivos = f3b_arquivos( $raiz, array( 'php', 'js', 'mjs', 'json', 'md', 'tsv', 'html', 'css', 'txt' ), f3b_excluidos() );

	foreach ( $removidas as $removida ) {
		$chave = $removida['chave'];
		$folha = (string) substr( strrchr( '.' . $chave, '.' ), 1 );

		++$medidas;

		if ( isset( $declaradas[ $chave ] ) ) {
			$achados[] = 'config/site.json ainda declara "' . $chave . '", removida na ' . $removida['release']
				. ': ' . $removida['motivo'];
		}

		++$medidas;

		if ( isset( $no_schema[ $chave ] ) || isset( $exigidas[ $folha ] ) ) {
			$achados[] = 'config/site.schema.json ainda ' . ( isset( $no_schema[ $chave ] ) ? 'declara' : 'EXIGE' )
				. ' "' . $chave . '", removida na ' . $removida['release']
				. ': schema que ainda conhece a chave reprova toda configuração correta, ou a devolve por outra porta';
		}

		foreach ( $removida['tokens'] as $token ) {
			++$medidas;

			foreach ( $arquivos as $rel ) {
				if ( 'suite/chaves-removidas.tsv' === $rel || in_array( $rel, $removida['narrativa'], true ) ) {
					continue;
				}

				$conteudo = (string) file_get_contents( $raiz . '/' . $rel );

				if ( ! str_contains( $conteudo, $token ) ) {
					continue;
				}

				$linha = substr_count( substr( $conteudo, 0, (int) strpos( $conteudo, $token ) ), "\n" ) + 1;

				$achados[] = $rel . ':' . $linha . ' ainda menciona "' . $token . '", da chave "' . $chave
					. '" removida na ' . $removida['release'] . ': consumidor órfão lê vazio em silêncio e documento órfão'
					. ' ensina a preencher o que não existe mais. A remoção é narrada em '
					. ( array() === $removida['narrativa'] ? 'nenhum arquivo declarado' : implode( ', ', $removida['narrativa'] ) );
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.gate_de_fase_sem_ramo_de_falha
 * ---------------------------------------------------------------------- */

/**
 * A LISTA DE ARGUMENTOS de uma chamada, com parênteses e aspas respeitados.
 *
 * Existe porque o corte precisa atravessar `'…, …'` sem contar a vírgula de
 * dentro do literal, e precisa parar no parêntese que fecha ESTA chamada e não
 * numa das aninhadas.
 *
 * @param string $src  Código sem comentário.
 * @param int    $abre Posição do parêntese de abertura.
 * @return string Texto entre os parênteses.
 */
function f3b_lista_de_argumentos( string $src, int $abre ): string {
	$prof = 0;
	$i    = $abre;
	$n    = strlen( $src );

	while ( $i < $n ) {
		$c = $src[ $i ];

		if ( "'" === $c || '"' === $c ) {
			$aspa = $c;
			++$i;

			while ( $i < $n ) {
				if ( '\\' === $src[ $i ] ) {
					$i += 2;
					continue;
				}

				if ( $aspa === $src[ $i ] ) {
					break;
				}

				++$i;
			}

			++$i;
			continue;
		}

		if ( '(' === $c || '[' === $c ) {
			++$prof;
		}

		if ( ')' === $c || ']' === $c ) {
			--$prof;

			if ( 0 === $prof ) {
				return substr( $src, $abre + 1, $i - $abre - 1 );
			}
		}

		++$i;
	}

	return '';
}

/**
 * NENHUMA LINHA DE GATE DE FASE TEM RAMO CAPAZ DE FECHAR FALHA.
 *
 * O DEFEITO QUE ELE FECHA, medido em produção na 1.7.2. O relatório imprimia,
 * na mesma tela, duas afirmações incompatíveis:
 *
 * - "GATE(S) DE FASE em aberto, declarado(s) e NÃO somado(s) a este gate:
 *   release.versao_site_core (FALHA) — evidência que este host não produz trava
 *   o gate da fase, não a ferramenta";
 * - e, três linhas acima, `estado da aplicação: FALHA_PARCIAL`, derivado de uma
 *   contagem CRUA de FALHA que conta aquela mesma linha.
 *
 * O estado é a PRIMEIRA das três condições do gate da autodesativação. Uma
 * linha declarada como não somada ao gate e que derruba o estado decide o gate
 * por dentro enquanto o texto diz que não decide.
 *
 * POR QUE ESTE DETECTOR EXISTE ao lado de `lotes.gate_de_fase_nao_derruba_estado`.
 * Aquela bancada exercita a REGRA — `contradicao_de_gate_nao_somado()` — contra
 * linhas que a própria sonda monta. Ela prova que a função reconhece a
 * contradição quando alguém a entrega, e não prova que as DECLARAÇÕES deste
 * pacote não contêm nenhuma. É a bancada que mede o instrumento e não mede o
 * objeto — a mesma forma que custou quatro releases na medição de comportamento,
 * quando a bancada simulava o `IntersectionObserver` que o navegador tem. Este
 * detector mede o objeto: as emissões que estão escritas em `includes/`.
 *
 * A REGRA, e ela é decidível — não há heurística. Para cada emissão que declara
 * `gate => 'fase'`:
 *
 * 1. `avaliar()` e `condicional()` são acusadas SEMPRE. Elas emitem nos dois
 *    ramos por construção, e o ramo falso é FALHA: não existe forma de uma delas
 *    não poder fechar FALHA.
 * 2. `emitir()` e `emitir_unidade()` têm o estado no PRIMEIRO argumento, e ele é
 *    resolvido em um salto:
 *    - constante de estado literal (`F3Base_Imp_Relatorio::BLOCKED`): decide
 *      sozinha;
 *    - variável (`$v` ou `$v['estado']`): a atribuição dela dentro da mesma
 *      função nomeia a PRODUTORA, e os estados que a produtora pode devolver
 *      são as constantes de estado que aparecem no corpo dela;
 *    - qualquer outra forma — ternário, concatenação, chamada embutida — é
 *      ACUSADA dizendo que não foi possível provar. O erro seguro é cobrar: uma
 *      emissão de fase cujo estado ninguém consegue provar é exatamente aquela
 *      em que a FALHA passa despercebida.
 *
 * ESCOPO VAZIO NÃO APROVA: uma árvore sem nenhuma emissão de `gate => 'fase'`
 * perdeu a âncora, e aprovar por ausência é o que este pacote recusa em todo
 * lugar.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_gate_de_fase_sem_ramo_de_falha( string $raiz ): array {
	$emissoras  = array( 'emitir_unidade', 'emitir', 'condicional', 'avaliar' );
	$dois_ramos = array( 'avaliar', 'condicional' );
	$achados    = array();
	$medidas    = 0;
	$fontes     = array();
	$produtoras = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src            = f3b_codigo_php( $raiz . '/' . $rel );
		$fontes[ $rel ] = $src;

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			$nome = (string) $funcao['nome'];

			/*
			 * Corpos de mesmo nome são SOMADOS, e a soma é o lado seguro: mais
			 * estados possíveis significa mais chance de acusar, nunca menos.
			 */
			$produtoras[ $nome ] = (string) ( $produtoras[ $nome ] ?? '' ) . "\n" . (string) $funcao['corpo'];
		}
	}

	foreach ( $fontes as $rel => $src ) {
		$posicao = 0;

		while ( true ) {
			$onde = strpos( $src, "'gate'", $posicao );

			if ( false === $onde ) {
				break;
			}

			$posicao = $onde + 1;

			if ( 1 !== preg_match( '/^\'gate\'\s*=>\s*\'fase\'/', substr( $src, $onde, 40 ) ) ) {
				continue;
			}

			++$medidas;

			$linha  = substr_count( substr( $src, 0, $onde ), "\n" ) + 1;
			$antes  = substr( $src, 0, $onde );
			$abre   = -1;
			$qual   = '';

			foreach ( $emissoras as $emissora ) {
				$candidato = strrpos( $antes, 'F3Base_Imp_Relatorio::' . $emissora . '(' );

				if ( false === $candidato ) {
					continue;
				}

				if ( $candidato > $abre ) {
					$abre = (int) $candidato + strlen( 'F3Base_Imp_Relatorio::' . $emissora );
					$qual = $emissora;
				}
			}

			if ( '' === $qual ) {
				$achados[] = $rel . ':' . $linha . ' declara gate=fase sem emissora do relatório antes dela: '
					. 'sem saber por qual função a linha sai, não há como provar quais estados ela pode fechar';
				continue;
			}

			$depois = substr( $src, $abre, 4000 );
			$nome   = preg_match( '/\'([a-z][a-z0-9_]*\.[a-z0-9_.-]+)\'/', $depois, $ms ) ? (string) $ms[1] : '(sem nome literal)';

			if ( in_array( $qual, $dois_ramos, true ) ) {
				$achados[] = $rel . ':' . $linha . ' ' . $nome . ' declara gate=fase e sai por ' . $qual . '(), que emite NOS DOIS RAMOS '
					. 'e cujo ramo adverso é FALHA. Uma linha de gate de fase que fecha FALHA entra na contagem que derruba o estado da aplicação — '
					. 'e o estado é a primeira condição do gate que o relatório afirma que ela não decide. Classifique-a pelo que ela é: '
					. 'relato quando o host mede e a resposta não impede o site de funcionar, aplicacao quando impede';
				continue;
			}

			$argumento = f3b_primeiro_argumento( f3b_lista_de_argumentos( $src, $abre ) );
			$possiveis = array();
			$origem    = '';

			if ( preg_match( '/^F3Base_Imp_Relatorio::(OK|FALHA|BLOCKED|NA|WARN|WAIVED)$/', $argumento, $ms ) ) {
				$possiveis = array( (string) $ms[1] );
				$origem    = 'constante literal';
			} elseif ( preg_match( '/^\$([A-Za-z_]\w*)\s*(?:\[\s*\'estado\'\s*\]\s*)?$/', $argumento, $ms ) ) {
				$variavel = (string) $ms[1];
				$funcao   = '';

				$corte = strrpos( $antes, 'function ' );
				$bloco = false === $corte ? $antes : substr( $antes, (int) $corte );

				if ( preg_match( '/\$' . preg_quote( $variavel, '/' ) . '\s*=\s*(?:self|static|F3Base_[A-Za-z_]+)::(\w+)\s*\(/', $bloco, $mp ) ) {
					$funcao = (string) $mp[1];
				}

				if ( '' === $funcao || ! isset( $produtoras[ $funcao ] ) ) {
					$achados[] = $rel . ':' . $linha . ' ' . $nome . ' declara gate=fase e recebe o estado da variável $' . $variavel
						. ', cuja produtora não foi encontrada na árvore: sem a produtora não há como provar que esta linha não fecha FALHA, '
						. 'e uma emissão de fase cujo estado ninguém consegue provar é justamente aquela em que a FALHA passa despercebida';
					continue;
				}

				preg_match_all( '/(?:self|static|F3Base_[A-Za-z_]+)::(OK|FALHA|BLOCKED|NA|WARN|WAIVED)\b/', $produtoras[ $funcao ], $me );
				$possiveis = array_values( array_unique( (array) $me[1] ) );

				if ( str_contains( $produtoras[ $funcao ], "'FALHA'" ) ) {
					$possiveis[] = 'FALHA';
				}

				$origem = $funcao . '()';
			} else {
				$achados[] = $rel . ':' . $linha . ' ' . $nome . ' declara gate=fase e o estado vem de uma expressão que este detector NÃO sabe resolver ('
					. trim( preg_replace( '/\s+/', ' ', substr( $argumento, 0, 120 ) ) ?? '' ) . '). O erro seguro é cobrar: '
					. 'escreva o estado como constante literal, ou tire-o de uma produtora nomeada, para que a ausência de ramo de FALHA possa ser PROVADA';
				continue;
			}

			if ( array() === $possiveis ) {
				$achados[] = $rel . ':' . $linha . ' ' . $nome . ' declara gate=fase e a produtora ' . $origem
					. ' não traz nenhuma constante de estado: escopo vazio não aprova, porque a ausência de prova não é prova de ausência';
				continue;
			}

			if ( in_array( 'FALHA', $possiveis, true ) ) {
				$achados[] = $rel . ':' . $linha . ' ' . $nome . ' declara gate=fase e PODE fechar FALHA (estado vindo de ' . $origem
					. ', que devolve ' . implode( '/', $possiveis ) . '). O relatório afirma, sobre cada gate de fase, que a evidência é de algo que '
					. 'ESTE HOST NÃO PRODUZ e que ela não é somada ao gate da autodesativação — e a FALHA entra na contagem que derruba o estado da '
					. 'aplicação, que é a primeira condição daquele gate. As duas coisas não podem ser verdade. Se o host mede a evidência, o gate é '
					. 'relato (não decide, e a FALHA derruba o estado com a frase certa) ou aplicacao (decide e suspende o que depende dela)';
			}
		}
	}

	if ( 0 === $medidas ) {
		$achados[] = 'nenhuma emissão com gate=fase foi encontrada na árvore varrida: a âncora sumiu, e um detector que aprova por ausência '
			. 'de alvo não mede nada — o gate de fase existe para a evidência que este host não produz, e ela não pode ter desaparecido em silêncio';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => max( 1, $medidas ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.precondicao_no_eixo
 * ---------------------------------------------------------------------- */

/**
 * PRÉ-CONDIÇÃO DECLARADA MORA NO EIXO DE CONVERGÊNCIA, e em nenhum outro gate.
 *
 * O DEFEITO QUE ELE FECHA, medido na 1.0.18: `precondicao` e `gate` eram dois
 * metadados independentes, e uma linha podia ser as duas coisas ao mesmo tempo —
 * dado que só o operador tem E gate de APLICAÇÃO. Era o caso de
 * `privacidade.controlador_identificado` e de `cadencia.mecanismo_declarado`, e
 * o efeito estava medido: uma implantação de template limpo, que tinha dado
 * certo, terminava com dois BLOCKED de gate de aplicação cuja única causa era
 * dado que o pacote não tem como ter. A tela dizia que algo estava errado numa
 * implantação que deu certo — o mesmo defeito do WARN informativo que a 1.0.15
 * eliminou.
 *
 * Duas medições, e as duas são sobre a MESMA regra vista de dois lados:
 *
 * 1. **Uma condição, um lugar.** Existe um ponto — e um só, fora de `suite/` —
 *    onde o gate é DERIVADO de `precondicao`. Sem ele, os dois metadados voltam
 *    a ser independentes e voltam a discordar.
 * 2. **Nenhum emissor declara os dois.** Chamada que passa `'precondicao'` e
 *    `'gate'` no mesmo argumento está escolhendo à mão o que a derivação decide,
 *    e é por aí que a divergência volta.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_precondicao_no_eixo( string $raiz ): array {
	$achados   = array();
	$medidas   = 0;
	$derivacao = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( preg_match( '/GATE_CONVERGENCIA\s*(?:\)|:|;)?/', $src ) && str_contains( $src, '$precondicao' ) ) {
			$derivacao[] = $rel;
		}

		$posicao = 0;

		while ( true ) {
			$onde = strpos( $src, "'precondicao'", $posicao );

			if ( false === $onde ) {
				break;
			}

			$posicao = $onde + 1;

			if ( 1 !== preg_match( '/^\'precondicao\'\s*=>\s*true/', substr( $src, $onde, 40 ) ) ) {
				continue;
			}

			++$medidas;

			$bloco = f3b_argumento_envolvente( $src, $onde );

			if ( '' !== $bloco && str_contains( $bloco, "'gate'" ) ) {
				$linha = substr_count( substr( $src, 0, $onde ), "\n" ) + 1;

				$achados[] = $rel . ':' . $linha . ' declara precondicao=true E gate no mesmo argumento: '
					. 'o gate de uma pré-condição declarada é DERIVADO dela — convergência, nunca aplicação —, '
					. 'e escolher os dois à mão é o caminho de volta para os dois discordarem';
			}
		}
	}

	++$medidas;

	if ( array() === $derivacao ) {
		$achados[] = 'nenhum lugar fora de suite/ deriva o gate de convergência a partir de precondicao: '
			. 'sem a derivação os dois metadados voltam a ser independentes, e uma linha volta a ser '
			. 'dado que só o operador tem E gate de aplicação ao mesmo tempo';
	}

	if ( count( $derivacao ) > 1 ) {
		$achados[] = 'a derivação do gate a partir de precondicao aparece em ' . count( $derivacao ) . ' arquivos ('
			. implode( ', ', $derivacao ) . '): duas derivações divergem, e a divergência sai como um relatório '
			. 'que classifica a mesma linha de dois jeitos';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * O ARGUMENTO (array literal) que envolve uma posição do código.
 *
 * Anda para trás até o `array(` ou `[` que abre o nível, e para a frente até
 * fechá-lo. Sem isso a varredura leria `'gate'` de uma chamada vizinha e
 * acusaria quem não declarou nada.
 *
 * @param string $src  Código.
 * @param int    $onde Posição dentro do argumento.
 * @return string Trecho do argumento, ou vazio quando não há um.
 */
function f3b_argumento_envolvente( string $src, int $onde ): string {
	$nivel  = 0;
	$inicio = -1;

	for ( $i = $onde; $i >= 0; $i-- ) {
		$c = $src[ $i ];

		if ( ')' === $c || ']' === $c ) {
			$nivel++;
			continue;
		}

		if ( '(' === $c || '[' === $c ) {
			if ( 0 === $nivel ) {
				$inicio = $i;
				break;
			}

			$nivel--;
		}
	}

	if ( $inicio < 0 ) {
		return '';
	}

	$nivel = 0;
	$tam   = strlen( $src );

	for ( $j = $inicio; $j < $tam; $j++ ) {
		$c = $src[ $j ];

		if ( '(' === $c || '[' === $c ) {
			$nivel++;
			continue;
		}

		if ( ')' === $c || ']' === $c ) {
			$nivel--;

			if ( 0 === $nivel ) {
				return substr( $src, $inicio, $j - $inicio + 1 );
			}
		}
	}

	return substr( $src, $inicio );
}

/* -------------------------------------------------------------------------
 * estatica.option_gravada_sem_leitor
 * ---------------------------------------------------------------------- */

/*
 * `estatica.option_gravada_sem_leitor` NÃO ENTROU NESTE REPOSITÓRIO, e o motivo
 * é o que ela mede — não o que ela afirma. O lado da ESCRITA dela é um
 * vocabulário fechado: `Gravador::gravar(...)`, `update_option`, `add_option` e
 * `update_site_option` com literal ou constante. `Gravador::` é o gravador do
 * IMPLANTADOR; o gravador deste plugin é `F3Base_Options::gravar()`, que a
 * MESMA função classifica como LEITURA (`Options::(obter|ler|gravar|salvar)`).
 * Apontada para a árvore do plugin ela encontra ZERO escrita, e escopo vazio
 * fecha BLOCKED — que é o instrumento dizendo a verdade sobre si mesmo.
 *
 * Ensinar o detector a reconhecer o gravador do plugin é MUDAR o detector, e
 * mudar detector não é tarefa de extração: é a tarefa seguinte, e ela tem de
 * vir com o piso que prova a mudança. Está declarada em suite/excluidas.tsv.
 */


/* -------------------------------------------------------------------------
 * estatica.plano_dependencias
 * ---------------------------------------------------------------------- */

/**
 * O grafo de dependências do plano se sustenta.
 *
 * A regra que não pode ser afrouxada: **unidade que declara dependência de uma
 * que não existe é defeito de configuração**. Sem detector, uma aresta apontando
 * para um grupo inexistente simplesmente não se forma — a dependência some em
 * silêncio, a unidade dependente passa a rodar quando não deveria, e ninguém
 * fica sabendo. O modo de falha é o mesmo do preset inexistente que resolve para
 * vazio: nada quebra, e a promessa deixa de valer.
 *
 * Roda a MESMA função que o runtime usa — `F3Base_Imp_Plano::conferir()` — em
 * SUBPROCESSO, porque o piso executa esta checagem duas vezes (fixture negativa
 * e positiva) e duas declarações da mesma classe no mesmo processo seriam erro
 * fatal. Reimplementar a regra aqui provaria que a cópia funciona, não que o
 * grafo está de pé.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_plano_dependencias( string $raiz ): array {
	$arquivo = $raiz . '/includes/class-f3base-imp-plano.php';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'includes/class-f3base-imp-plano.php ausente na raiz varrida: sem a tabela declarada não existe grafo a conferir' ),
			'medidas' => 1,
		);
	}

	$codigo = 'define("ABSPATH","/"); require ' . var_export( $arquivo, true ) . '; '
		. 'echo json_encode(F3Base_Imp_Plano::conferir(), JSON_UNESCAPED_UNICODE);';

	$saida  = array();
	$estado = 0;
	exec( 'php -r ' . escapeshellarg( $codigo ) . ' 2>&1', $saida, $estado );

	$bruto = implode( '', $saida );
	$json  = json_decode( $bruto, true );

	if ( 0 !== $estado || ! is_array( $json ) || ! isset( $json['achados'], $json['medidas'] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'a tabela não pôde ser lida em subprocesso (código ' . $estado . '): ' . substr( $bruto, 0, 300 ) ),
			'medidas' => 1,
		);
	}

	return array(
		'ok'      => array() === $json['achados'],
		'achados' => array_map( 'strval', (array) $json['achados'] ),
		'medidas' => (int) $json['medidas'],
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_placeholder
 * ---------------------------------------------------------------------- */

/**
 * Regiões que não são prosa publicada: código, atributo de bloco e mail-tag.
 *
 * @param string $texto Texto.
 * @return array<int,array{0:int,1:int}> Intervalos a ignorar.
 */
function f3b_regioes_isentas( string $texto ): array {
	$isentas = array();
	$padroes = array(
		'/<!--.*?-->/s',
		'#<code\b.*?</code>#is',
		'#<pre\b.*?</pre>#is',
		'/`[^`]*`/',
		'/\[contact-form-7\b.*?\]/is',
		'#<form\b.*?</form>#is',
		'#class="[^"]*f3base-formulario[^"]*".*?</div>#is',
	);

	foreach ( $padroes as $re ) {
		if ( preg_match_all( $re, $texto, $ms, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $ms[0] as $m ) {
				$isentas[] = array( (int) $m[1], (int) $m[1] + strlen( $m[0] ) );
			}
		}
	}

	return $isentas;
}

/**
 * A posição cai numa região isenta?
 *
 * @param int                             $pos     Posição.
 * @param array<int,array{0:int,1:int}>   $isentas Intervalos.
 * @return bool
 */
function f3b_isento( int $pos, array $isentas ): bool {
	foreach ( $isentas as $faixa ) {
		if ( $pos >= $faixa[0] && $pos < $faixa[1] ) {
			return true;
		}
	}

	return false;
}

/**
 * Nenhum placeholder no CONTEÚDO PUBLICADO.
 *
 * Escopo: `content/`, `fontes/tema/patterns`, `fontes/tema/templates`, `fontes/tema/parts` — o que
 * chega ao visitante. As formas são as do contrato: `{{X}}`, `[[X]]`, `[texto]`,
 * `«texto»`, TODO, TBD, XXX, LOREM e EXEMPLO.
 *
 * O colchete tem regra de exceção declarada, e é a parte que o piso positivo
 * cobre: link de markdown (`[texto](url)`), imagem de markdown, colchete dentro
 * de código (`<code>`, `<pre>`, crase) ou de atributo de bloco, e mail-tag de
 * formulário não são placeholder — são sintaxe legítima.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_placeholder( string $raiz ): array {
	$formas = array(
		'chaves_duplas'    => '/\{\{[^}\n]{1,80}\}\}/',
		'colchetes_duplos' => '/\[\[[^\]\n]{1,80}\]\]/',
		'aspas_angulares'  => '/«[^»\n]{1,80}»/u',
		'todo'             => '/(?<![A-Za-z])TODO(?![A-Za-z])/',
		'tbd'              => '/(?<![A-Za-z])TBD(?![A-Za-z])/',
		'xxx'              => '/(?<![A-Za-z])XXX(?![A-Za-z])/',
		'lorem'            => '/(?<![A-Za-z])LOREM(?![A-Za-z])/i',
		'exemplo'          => '/(?<![A-Za-z])EXEMPLO(?![A-Za-z])/',
	);

	$escopos = array( 'content/', 'fontes/tema/patterns/', 'fontes/tema/templates/', 'fontes/tema/parts/' );
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'html', 'php' ), f3b_excluidos() ) as $rel ) {
		$dentro = false;

		foreach ( $escopos as $escopo ) {
			if ( str_starts_with( $rel, $escopo ) || str_contains( '/' . $rel, '/' . $escopo ) ) {
				$dentro = true;
				break;
			}
		}

		if ( ! $dentro ) {
			continue;
		}

		$medidas++;
		$texto   = (string) file_get_contents( $raiz . '/' . $rel );
		$isentas = f3b_regioes_isentas( $texto );

		foreach ( $formas as $rotulo => $re ) {
			if ( ! preg_match_all( $re, $texto, $ms, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $ms[0] as $m ) {
				if ( f3b_isento( (int) $m[1], $isentas ) ) {
					continue;
				}

				$achados[] = $rel . ': ' . $rotulo . ' ' . trim( substr( $m[0], 0, 40 ) );
			}
		}

		/* `[texto]`: colchete simples, com as exceções declaradas. */
		if ( preg_match_all( '/\[([^\]\[\n]{1,60})\]/', $texto, $ms, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$pos     = (int) $m[0][1];
				$inteiro = $m[0][0];
				$dentro2 = $m[1][0];
				$fim     = $pos + strlen( $inteiro );

				if ( f3b_isento( $pos, $isentas ) ) {
					continue;
				}

				if ( $pos > 0 && '!' === $texto[ $pos - 1 ] ) {
					continue;
				}

				if ( isset( $texto[ $fim ] ) && '(' === $texto[ $fim ] ) {
					continue;
				}

				if ( preg_match( '/^\s*[\d\'"$]/', $dentro2 ) ) {
					continue;
				}

				$achados[] = $rel . ': colchetes ' . trim( substr( $inteiro, 0, 40 ) );
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.simbolos_resolvem
 * ---------------------------------------------------------------------- */

/**
 * Todo método e constante `F3Base_*::` chamados existem na classe.
 *
 * Sem WordPress não dá para executar os caminhos; o que dá para provar sem
 * executar é que nenhuma chamada aponta para um símbolo que não existe — o erro
 * fatal que só aparece no ramo raro, em produção, no meio da aplicação.
 *
 * @param string $raiz Raiz.
 * @return array{ok:bool,achados:array<int,string>}
 */
/** Tipos nomeados por tokens: um método de classe vizinha não resolve o símbolo. */
function f3b_tipos_com_corpo( string $src ): array {
	$tokens = token_get_all( $src );
	$tipos = array();
	$total = count( $tokens );
	for ( $i = 0; $i < $total; $i++ ) {
		if ( ! is_array( $tokens[ $i ] ) || ! in_array( $tokens[ $i ][0], array( T_CLASS, T_TRAIT ), true ) ) { continue; }
		$e_trait = T_TRAIT === $tokens[ $i ][0];
		$j = $i + 1;
		while ( isset( $tokens[ $j ] ) && is_array( $tokens[ $j ] ) && in_array( $tokens[ $j ][0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) { $j++; }
		if ( ! isset( $tokens[ $j ] ) || ! is_array( $tokens[ $j ] ) || T_STRING !== $tokens[ $j ][0] || ! str_starts_with( $tokens[ $j ][1], 'F3Base_' ) ) { continue; }
		$nome = $tokens[ $j ][1];
		while ( isset( $tokens[ $j ] ) && '{' !== $tokens[ $j ] ) { $j++; }
		$nivel = 1; $corpo = '';
		for ( $j++; $j < $total; $j++ ) {
			$t = $tokens[ $j ];
			if ( '{' === $t || ( is_array( $t ) && in_array( $t[0], array( T_CURLY_OPEN, T_DOLLAR_OPEN_CURLY_BRACES ), true ) ) ) { $nivel++; }
			if ( '}' === $t && 0 === --$nivel ) { break; }
			$corpo .= is_array( $t ) ? $t[1] : $t;
		}
		if ( 0 === $nivel ) { $tipos[] = array( 'nome' => $nome, 'trait' => $e_trait, 'corpo' => $corpo ); }
		$i = $j;
	}
	return $tipos;
}

function f3b_ck_simbolos_resolvem( string $raiz ): array {
	$metodos    = array();
	$constantes = array();
	$fontes     = array();
	$traits     = array();
	$usos       = array();
	$arquivos   = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$src            = f3b_codigo_php( $raiz . '/' . $rel );
		$fontes[ $rel ] = $src;

		foreach ( f3b_tipos_com_corpo( $src ) as $tipo ) {
			$classe = $tipo['nome'];
			preg_match_all( '/function\s+(\w+)\s*\(/', $tipo['corpo'], $fs );
			preg_match_all( '/const\s+([A-Z][A-Z0-9_]*)/', $tipo['corpo'], $ks );
			if ( $tipo['trait'] ) {
				$traits[ $classe ] = array( 'metodos' => $fs[1], 'constantes' => $ks[1], 'arquivo' => $rel );
				continue;
			}
			$metodos[ $classe ] = array_merge( $metodos[ $classe ] ?? array(), $fs[1] );
			$constantes[ $classe ] = array_merge( $constantes[ $classe ] ?? array(), $ks[1] );
			$arquivos[ $classe ] = $rel;
			preg_match_all( '/\buse\s+(F3Base_\w+)\s*;/', $tipo['corpo'], $uses );
			$usos[ $classe ] = $uses[1];
		}
	}

	$achados = array();
	foreach ( $usos as $classe => $lista ) {
		foreach ( $lista as $trait ) {
			if ( ! isset( $traits[ $trait ] ) ) {
				$achados[] = $arquivos[ $classe ] . ': trait ' . $trait . ' não existe';
				continue;
			}
			$t = $traits[ $trait ];
			$arquivo_classe = $arquivos[ $classe ];
			$carregada = $arquivo_classe === $t['arquivo'];
			if ( ! $carregada ) {
				$carregada = 1 === preg_match( "/\\b(?:require|require_once|include|include_once)\\s*(?:\\(\\s*)?__DIR__\\s*\\.\\s*['\"]\\/" . preg_quote( basename( $t['arquivo'] ), '/' ) . "['\"]/", $fontes[ $arquivo_classe ] );
			}
			if ( ! $carregada ) {
				$achados[] = $arquivo_classe . ': trait ' . $trait . ' sem carregamento local explícito';
				continue;
			}
			$metodos[ $classe ] = array_merge( $metodos[ $classe ], $t['metodos'] );
			$constantes[ $classe ] = array_merge( $constantes[ $classe ], $t['constantes'] );
		}
	}

	foreach ( $fontes as $rel => $src ) {
		if ( preg_match_all( '/(F3Base_\w+)::(\w+)\s*\(/', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				if ( ! isset( $metodos[ $m[1] ] ) ) {
					continue;
				}

				if ( ! in_array( $m[2], $metodos[ $m[1] ], true ) ) {
					$achados[] = $rel . ': ' . $m[1] . '::' . $m[2] . '() não existe';
				}
			}
		}

		if ( preg_match_all( '/(F3Base_\w+)::([A-Z][A-Z0-9_]*)(?!\s*\()/', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				if ( ! isset( $constantes[ $m[1] ] ) ) {
					continue;
				}

				if ( ! in_array( $m[2], $constantes[ $m[1] ], true ) ) {
					$achados[] = $rel . ': constante ' . $m[1] . '::' . $m[2] . ' não existe';
				}
			}
		}
	}

	return array(
		'ok'      => array() === array_unique( $achados ),
		'achados' => array_values( array_unique( $achados ) ),
		'medidas' => count( $fontes ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.estados_fechados
 * ---------------------------------------------------------------------- */

/**
 * Estados de relatório usam o enum da suíte; estados de negócio têm outro contrato.
 *
 * Qualquer literal passado aos emissores estado()/saida() é verificado. Nos
 * arrays, o vocabulário em maiúsculas identifica o contrato de relatório; os
 * avisos dos módulos também pertencem a esse contrato, inclusive erros de caixa.
 * Estados de fila, configuração e sonda HTTP não são vereditos da suíte.
 *
 * @param string $raiz Raiz.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_estados_fechados( string $raiz ): array {
	$achados = array();
	$alvos = f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() );
	foreach ( $alvos as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );
		$valores = array();
		// Nomes globais dos emissores: métodos estado() de módulos não são emissores.
		foreach ( array( "/(?<![A-Za-z0-9_:>])(?:saida|estado)\\(\\s*['\"]([^'\"]+)['\"]/", "/['\"]estado['\"]\\s*=>\\s*['\"]([A-Z][A-Z0-9_\\/-]*)['\"]/" ) as $padrao ) {
			if ( preg_match_all( $padrao, $src, $ms ) ) { $valores = array_merge( $valores, $ms[1] ); }
		}
		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( in_array( $funcao['nome'], array( 'avisos', 'avisos_do' ), true ) && preg_match_all( "/['\"]estado['\"]\\s*=>\\s*['\"]([^'\"]+)['\"]/", $funcao['corpo'], $ms ) ) {
				$valores = array_merge( $valores, $ms[1] );
			}
		}
		foreach ( $valores as $valor ) {
			if ( ! in_array( $valor, F3Base_Suite::ESTADOS, true ) ) { $achados[] = $rel . ": '" . $valor . "'"; }
		}
	}
	return array( 'ok' => array() === array_unique( $achados ), 'achados' => array_values( array_unique( $achados ) ), 'medidas' => count( $alvos ) );
}

/* -------------------------------------------------------------------------
 * config.slug_declarado
 * ---------------------------------------------------------------------- */

/**
 * Toda entrada de `paginas` e `posts` declara slug, e nenhum se repete.
 *
 * PISO DOS DOIS LADOS, porque a armadilha tem duas caras e uma só delas
 * reprovando deixaria a outra viva:
 *
 * - **Slug vazio.** Sem `post_name` declarado, o núcleo deriva do título,
 *   encontra o que já ocupa aquele slug — para tipo hierárquico
 *   `wp_unique_post_slug()` consulta `post_type IN ('page','attachment')` —,
 *   desambigua em silêncio para `<slug>-2` e a leitura de volta da etapa de
 *   conteúdo fecha FALHA. Foi exatamente o que aconteceu: `attachment #10
 *   post_name=metodo-f3` (o logo, importado antes) e `page #11
 *   post_name=metodo-f3-2` (a home, com `slug: ""`).
 * - **Slug repetido entre entradas declaradas.** Duas entradas pedindo o mesmo
 *   `post_name` produzem a mesma desambiguação, com a diferença de que aqui o
 *   defeito está na configuração e é legível antes de qualquer execução.
 *
 * A varredura é da configuração, não do banco: é o que se pode provar em build.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_slug_declarado( string $raiz ): array {
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou não analisa na raiz varrida: sem configuração não há slug declarado a conferir' ),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 0;
	$vistos  = array();

	foreach ( array( 'paginas', 'posts' ) as $lista ) {
		foreach ( (array) ( $config[ $lista ] ?? array() ) as $indice => $entrada ) {
			if ( ! is_array( $entrada ) ) {
				continue;
			}

			$medidas++;

			/* A identidade que a mensagem usa: `ref` nas páginas, `slug` nos posts. */
			$nome = isset( $entrada['ref'] ) ? (string) $entrada['ref'] : (string) ( $entrada['titulo'] ?? '' );
			$onde = $lista . '[' . (string) $indice . ']' . ( '' !== $nome ? ' (' . $nome . ')' : '' );
			$slug = isset( $entrada['slug'] ) ? (string) $entrada['slug'] : '';

			if ( '' === trim( $slug ) ) {
				$achados[] = $onde . ': slug vazio — slug vazio delega ao núcleo a decisão que a leitura de volta depois cobra: '
					. 'ele deriva do título, encontra quem já ocupa (para tipo hierárquico wp_unique_post_slug() '
					. 'confere post_type IN (\'page\',\'attachment\')), desambigua para <slug>-2 em silêncio e a etapa de conteúdo fecha FALHA';
				continue;
			}

			if ( isset( $vistos[ $slug ] ) ) {
				$achados[] = $onde . ' e ' . $vistos[ $slug ] . ': declaram o MESMO slug "' . $slug
					. '" — duas entradas pedindo o mesmo post_name produzem a mesma desambiguação silenciosa, '
					. 'com a diferença de que este defeito é legível na configuração antes de qualquer execução';
				continue;
			}

			$vistos[ $slug ] = $onde;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.gate_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * Nomes de estado de gate declarados pela função âncora `gates_do_canal()`.
 *
 * Os nomes NÃO são escritos aqui: eles saem da função do próprio pacote que os
 * declara. Uma lista literal na suíte seria uma terceira fonte para o mesmo
 * fato — precisamente o que este detector existe para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{nomes:array<int,string>,ancora:string}
 */
function f3b_gates_declarados( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src   = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = f3b_corpo_de_funcao( $src, 'gates_do_canal' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'/", $corpo, $ms );

		return array(
			'nomes'  => array_values( array_unique( $ms[1] ) ),
			'ancora' => $rel,
		);
	}

	return array(
		'nomes'  => array(),
		'ancora' => '',
	);
}

/**
 * Nomes de veredito que a função âncora `vereditos_da_suite()` declara.
 *
 * Como em `f3b_gates_declarados()`, os nomes saem do PRÓPRIO PACOTE: uma lista
 * literal escrita aqui seria a segunda fonte para o mesmo fato, que é
 * exatamente o que este detector existe para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{nomes:array<int,string>,ancora:string}
 */
function f3b_vereditos_da_suite( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src   = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = f3b_corpo_de_funcao( $src, 'vereditos_da_suite' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'/", $corpo, $ms );

		return array(
			'nomes'  => array_values( array_unique( $ms[1] ) ),
			'ancora' => $rel,
		);
	}

	return array(
		'nomes'  => array(),
		'ancora' => '',
	);
}

/**
 * Corpo de uma função pelo nome, com chaves balanceadas.
 *
 * @param string $src  Código sem comentário.
 * @param string $nome Nome da função.
 * @return string|null Corpo entre as chaves, ou null quando a função não existe.
 */
function f3b_corpo_de_funcao( string $src, string $nome ): ?string {
	if ( 1 !== preg_match( '/function\s+' . preg_quote( $nome, '/' ) . '\s*\(/', $src, $m, PREG_OFFSET_CAPTURE ) ) {
		return null;
	}

	$abre = strpos( $src, '{', (int) $m[0][1] );

	if ( false === $abre ) {
		return null;
	}

	$nivel = 0;
	$tam   = strlen( $src );

	for ( $i = $abre; $i < $tam; $i++ ) {
		if ( '{' === $src[ $i ] ) {
			$nivel++;
		}

		if ( '}' === $src[ $i ] ) {
			$nivel--;

			if ( 0 === $nivel ) {
				return substr( $src, $abre + 1, $i - $abre - 1 );
			}
		}
	}

	return null;
}

/**
 * Todas as funções de um arquivo, com nome e corpo.
 *
 * @param string $src Código sem comentário.
 * @return array<int,array{nome:string,corpo:string,linha:int}>
 */
function f3b_funcoes_do_arquivo( string $src ): array {
	$saida = array();

	if ( ! preg_match_all( '/function\s+(\w+)\s*\(/', $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
		return $saida;
	}

	foreach ( $ms as $m ) {
		$corpo = f3b_corpo_de_funcao( substr( $src, (int) $m[0][1] ), $m[1][0] );

		if ( null === $corpo ) {
			continue;
		}

		$saida[] = array(
			'nome'  => (string) $m[1][0],
			'corpo' => $corpo,
			'linha' => substr_count( substr( $src, 0, (int) $m[0][1] ), "\n" ) + 1,
		);
	}

	return $saida;
}

/**
 * OS REGISTROS DA SUÍTE são produzidos por UM lugar só — o comando único.
 *
 * Corolário da regra de fonte única, aplicado a um ARTEFATO em vez de a um
 * veredito. São DOIS os registros que a suíte grava dentro do pacote, e os dois
 * passam por aqui pela mesma razão:
 *
 * - `suite/rodada.json` é a evidência importada que o host aceita como prova da
 *   rodada integral.
 * - `suite/fases.json` é o registro DURÁVEL de quando cada fase rodou pela
 *   última vez — o contrapeso da regra de aplicabilidade da 1.1.6, sem o qual
 *   uma checagem em N/A eterno vira aprovação por omissão.
 *
 * Se qualquer um dos dois puder ser escrito de dois lugares — ou de nenhum, ou
 * seja, à mão — a evidência deixa de ser evidência: passa a ser uma afirmação
 * que qualquer um coloca no pacote. Um registro de fases forjado é pior que a
 * ausência dele: ele diz que a fase de navegador rodou.
 *
 * A regra é inerte quando o nome não aparece no pacote varrido: uma árvore que
 * não conhece o registro não tem o que provar sobre ele.
 *
 * @param string $raiz  Raiz a varrer.
 * @param string $marca Nome do registro procurado, montado por quem chama.
 * @param string $rotulo Como o achado nomeia o registro.
 * @return array<int,string> Achados.
 */
function f3b_produtores_do_registro_da_rodada( string $raiz, string $marca = '', string $rotulo = '' ): array {
	/*
	 * O nome do registro é montado por pedaços de propósito: escrito inteiro,
	 * ESTA função conteria a marca que ela procura ao lado de uma primitiva de
	 * escrita e o detector se acusaria de ser o segundo produtor — o detector
	 * que grita por causa de si é tão inútil quanto o que nunca grita.
	 */
	$marca    = '' !== $marca ? $marca : 'rodada' . '.json';
	$rotulo   = '' !== $rotulo ? $rotulo : 'o registro da rodada limpa';
	$escritas = array( 'file_put_contents(', 'fwrite(', 'fputs(', 'fopen(' );

	$produtores = array();
	$mencionado = false;

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! str_contains( $src, $marca ) ) {
			continue;
		}

		$mencionado = true;

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( ! str_contains( $funcao['corpo'], $marca ) ) {
				continue;
			}

			foreach ( $escritas as $primitiva ) {
				if ( str_contains( $funcao['corpo'], $primitiva ) ) {
					$produtores[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()';
					break;
				}
			}
		}
	}

	if ( ! $mencionado ) {
		return array();
	}

	$produtores = array_values( array_unique( $produtores ) );

	if ( array() === $produtores ) {
		return array(
			$rotulo . ' (' . $marca . ') é MENCIONADO no pacote e não tem produtor: '
				. 'nenhuma função o escreve. Registro que ninguém grava só pode chegar ali à mão, '
				. 'e registro da suíte gravado à mão é uma afirmação sem medição por trás',
		);
	}

	if ( count( $produtores ) > 1 ) {
		return array(
			$rotulo . ' (' . $marca . ') é gravado em ' . count( $produtores ) . ' lugares: '
				. implode( ' E ', $produtores )
				. ' — só o COMANDO ÚNICO pode produzi-lo; um segundo produtor é a porta pela qual '
				. 'o registro passa a existir sem a rodada que ele afirma ter havido',
		);
	}

	if ( ! str_starts_with( $produtores[0], 'suite/lib/' ) ) {
		return array(
			'o único produtor de ' . $rotulo . ' está fora de suite/lib/: ' . $produtores[0]
				. ' — quem grava o registro é o comando único, e mais ninguém',
		);
	}

	return array();
}

/**
 * Veredito da SUÍTE derivado no runtime — ou sumido da suíte.
 *
 * Os dois sentidos reprovam, e é preciso que reprovem:
 *
 * - **Derivado aqui também**: uma função do implantador contém o literal do nome
 *   E produz um estado fechado. É a duplicação medida na 1.0.7, em que a mesma
 *   pergunta recebia duas respostas produzidas por caminhos diferentes.
 * - **Sumido de lá**: o nome não aparece em lugar nenhum de `suite/`. Tirar o
 *   veredito do runtime e não o ter na suíte não é fonte única — é fonte
 *   nenhuma, e a pergunta deixa de ser respondida sem que ninguém perceba.
 *
 * A regra é inerte quando a árvore varrida não declara a âncora: uma árvore que
 * não diz quais vereditos são da suíte não tem o que provar sobre eles.
 *
 * @param string                                        $raiz       Raiz a varrer.
 * @param array{nomes:array<int,string>,ancora:string}  $da_suite   Âncora `vereditos_da_suite()`.
 * @param array<string,array<int,string>>               $derivacoes Derivações achadas no implantador, por nome.
 * @return array<int,string> Achados.
 */
function f3b_vereditos_fora_do_lugar( string $raiz, array $da_suite, array $derivacoes ): array {
	if ( array() === $da_suite['nomes'] ) {
		return array();
	}

	$achados = array();

	foreach ( $da_suite['nomes'] as $veredito ) {
		$lugares = array_values( array_unique( $derivacoes[ $veredito ] ?? array() ) );

		if ( array() !== $lugares ) {
			$achados[] = 'o veredito "' . $veredito . '", declarado em ' . $da_suite['ancora']
				. ' como sendo da SUÍTE, é derivado no implantador: ' . implode( ' E ', $lugares )
				. ' — duas implementações da mesma pergunta, medindo coisas diferentes, é a duplicação de fonte '
				. 'de verdade voltando por outra porta; o runtime pode RELATAR o que mediu, com nome próprio e '
				. 'sem produzir estado fechado para este nome';
		}

		$mencionado = false;

		foreach ( f3b_arquivos( $raiz . '/suite', array( 'php', 'mjs', 'js', 'tsv', 'sh' ) ) as $rel ) {
			if ( str_contains( (string) file_get_contents( $raiz . '/suite/' . $rel ), $veredito ) ) {
				$mencionado = true;
				break;
			}
		}

		if ( ! $mencionado ) {
			$achados[] = 'o veredito "' . $veredito . '", declarado em ' . $da_suite['ancora']
				. ' como sendo da SUÍTE, não aparece em lugar nenhum de suite/: tirar a derivação do runtime e '
				. 'não ter a checagem na suíte não é fonte única, é fonte nenhuma — a pergunta deixa de ser '
				. 'respondida e ninguém percebe';
		}
	}

	return $achados;
}

/**
 * Nenhum estado de gate da autodesativação é DERIVADO em mais de um lugar.
 *
 * O corolário da correção que acabou com o relatório contradizendo a si mesmo:
 * a linha 14 dizia "as 12 rotas estão registradas E há servidor MCP ativo
 * expondo-as" (OK) e a linha 41 do MESMO relatório dizia "o canal MCP não
 * fechou em OK; o canal não está EXPOSTO" (FALHA). Não era o site oscilando:
 * eram duas implementações do mesmo veredito, cada uma medindo por um caminho.
 *
 * A regra que este detector executa, e o que cada palavra significa:
 *
 * - **Estado de gate** é um nome declarado pela função âncora `gates_do_canal()`
 *   — os nomes que a decisão de autodesativação consulta. Eles saem do pacote,
 *   nunca de uma lista escrita aqui.
 * - **Derivação** é uma função que contém o literal daquele nome E produz um
 *   estado fechado. Quem apenas LÊ o veredito recebe o nome por parâmetro e por
 *   isso não aparece: a construção da leitura é o que a mantém fora da conta.
 * - **No máximo uma** derivação por nome. Duas são acusadas NOMEANDO as duas,
 *   com arquivo e função de cada uma.
 * - **E o REGISTRO DA RODADA LIMPA tem um produtor só**, que é o comando único:
 *   evidência importada que qualquer arquivo do pacote pudesse gravar deixaria
 *   de ser evidência. É a linha que `f3b_produtores_do_registro_da_rodada()`
 *   acrescenta.
 * - **E NENHUM VEREDITO É DERIVADO NOS DOIS LUGARES.** Linha nova na 1.0.8, e
 *   ela vem de um defeito medido: `config.toda_chave_tem_consumidor` reprovou no
 *   host nomeando vinte chaves que TÊM consumidor — a suíte, o site-core, um
 *   caminho de execução que aquele lote não percorreu. O detector estático
 *   `estatica.detector_chave_sem_consumidor` cruza toda chave contra TODO o
 *   código do pacote e fecha OK; a versão de runtime cruzava contra o que o
 *   implantador leu NAQUELA execução, que é outra pergunta, e respondia como se
 *   fosse a mesma. A regra: veredito declarado em `vereditos_da_suite()` é da
 *   SUÍTE, e o implantador não pode derivar estado fechado para aquele nome —
 *   nem pode deixá-lo desaparecer da suíte, que seria a outra metade do erro.
 *
 * Escopo: o código do implantador. `suite/` fica de fora da regra de derivação,
 * por desenho — a suíte NOMEIA checagens que não pode medir (é o que
 * `bloqueadas.php` faz), e isso é declaração de pendência, nunca derivação de
 * veredito. A regra do produtor, ao contrário, varre o pacote INTEIRO: é
 * justamente dentro de `suite/lib/` que o produtor legítimo mora.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_gate_fonte_unica( string $raiz ): array {
	$ancora = f3b_gates_declarados( $raiz );

	if ( array() === $ancora['nomes'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função gates_do_canal() foi encontrada fora de suite/: sem a âncora que declara quais estados '
					. 'decidem a autodesativação, não há como saber o que precisa ter fonte única — e um gate sem âncora '
					. 'é exatamente o terreno em que a segunda derivação passa despercebida',
			),
			'medidas' => 1,
		);
	}

	$estados = array(
		'F3Base_Imp_Relatorio::OK',
		'F3Base_Imp_Relatorio::FALHA',
		'F3Base_Imp_Relatorio::BLOCKED',
		'F3Base_Imp_Relatorio::WARN',
		'F3Base_Imp_Relatorio::NA',
		'F3Base_Imp_Relatorio::WAIVED',
	);

	$literais = array_map( static fn( string $e ): string => "'" . $e . "'", F3Base_Suite::ESTADOS );

	/*
	 * Derivar também acontece por delegação: `avaliar()` e `condicional()`
	 * decidem entre dois estados fechados sem que a palavra OK ou FALHA apareça
	 * na função que as chama. Sem estas marcas, a segunda derivação escaparia
	 * exatamente por ser bem escrita.
	 */
	$emissoras = array(
		'F3Base_Imp_Relatorio::avaliar(',
		'F3Base_Imp_Relatorio::condicional(',
		'F3Base_Imp_Relatorio::emitir(',
		'F3Base_Imp_Relatorio::emitir_unidade(',
	);

	$da_suite   = f3b_vereditos_da_suite( $raiz );
	$procurados = array_values( array_unique( array_merge( $ancora['nomes'], $da_suite['nomes'] ) ) );
	$derivacoes = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			$produz = false;

			foreach ( array_merge( $estados, $literais, $emissoras ) as $marca ) {
				if ( str_contains( $funcao['corpo'], $marca ) ) {
					$produz = true;
					break;
				}
			}

			if ( ! $produz ) {
				continue;
			}

			foreach ( $procurados as $gate ) {
				if ( ! str_contains( $funcao['corpo'], "'" . $gate . "'" ) ) {
					continue;
				}

				$derivacoes[ $gate ]   = $derivacoes[ $gate ] ?? array();
				$derivacoes[ $gate ][] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()';
			}
		}
	}

	/*
	 * OS DOIS REGISTROS DA SUÍTE, pela MESMA regra de produtor único. As marcas
	 * são montadas por pedaços aqui, e não dentro da função que as procura, pelo
	 * motivo escrito lá: escritas inteiras, elas apareceriam ao lado de uma
	 * primitiva de escrita e o detector se acusaria de ser o segundo produtor.
	 */
	$achados = array_merge(
		array(),
		f3b_produtores_do_registro_da_rodada( $raiz, 'rodada' . '.json', 'o registro da rodada limpa' ),
		f3b_produtores_do_registro_da_rodada( $raiz, 'fases' . '.json', 'o registro durável de fases' ),
		f3b_vereditos_fora_do_lugar( $raiz, $da_suite, $derivacoes )
	);

	foreach ( $ancora['nomes'] as $gate ) {
		$lugares = array_values( array_unique( $derivacoes[ $gate ] ?? array() ) );

		if ( count( $lugares ) > 1 ) {
			$achados[] = 'o estado de gate "' . $gate . '" é derivado em ' . count( $lugares ) . ' lugares: '
				. implode( ' E ', $lugares )
				. ' — duas implementações do mesmo veredito produzem duas respostas para a mesma pergunta no mesmo relatório; '
				. 'quem precisar do veredito depois precisa LER o que a unidade gravou, recebendo o nome por parâmetro';
			continue;
		}

		if ( array() === $lugares ) {
			$achados[] = 'o estado de gate "' . $gate . '" declarado em ' . $ancora['ancora']
				. ' não é derivado em lugar nenhum: gate sem quem o meça fecha sempre pelo caminho da ausência, '
				. 'e ninguém percebe que a medição não existe';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $procurados ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.contagem_com_nomes
 * ---------------------------------------------------------------------- */

/**
 * Fontes de CONTAGEM por estado — quem lê um número de estado do relatório.
 *
 * São chamadas de acessor (`::contagem(`, `::checagens_em_falha(` …), nunca as
 * definições: a definição devolve a propriedade, o acessor é o call-site. E as
 * chaves que a resposta do lote carrega para a tela, que são o mesmo número
 * atravessando a rede.
 *
 * @return array{php:array<int,string>,js:array<int,string>}
 */
function f3b_fontes_de_contagem(): array {
	/*
	 * As marcas de PHP são montadas por pedaços de propósito: escritas inteiras,
	 * esta função conteria as próprias marcas e o detector reprovaria a si
	 * mesmo — o detector que grita por causa de si é tão inútil quanto o que
	 * nunca grita. As de JS não precisam: elas são nomes de chave, e a lista de
	 * nomes logo abaixo já é o que a regra exige na mesma saída.
	 */
	$acessores = array(
		'contagem(',
		'contagem_unidades(',
		'checagens_em_falha(',
		'checagens_em_blocked(',
		'unidades_em_falha(',
		'unidades_em_blocked(',
		'falhas(',
	);

	return array(
		'php' => array_map( static fn( string $acessor ): string => ':' . ':' . $acessor, $acessores ),
		'js'  => array(
			'renderizadas[',
			'renderizadas.',
			'checagens_falha',
			'checagens_blocked',
			'unidades_falha',
			'unidades_blocked',
		),
	);
}

/**
 * Fontes de NOMES por estado — quem devolve a lista que a contagem exige.
 *
 * @return array<int,string>
 */
function f3b_fontes_de_nomes(): array {
	return array(
		'::nomes_por_estado(',
		'::resumo_por_estado(',
		'::nomes_em(',
		'f3b_resumo_por_estado(',
		'nomesPorEstado',
		'nomesRenderizados',
		'checagens_nomes',
		'unidades_nomes',
	);
}

/**
 * Literal que imprime um ESTADO ao lado de um NÚMERO.
 *
 * `%d` e `%1$d` são contagem por construção. `%s` fica de fora: ele carrega
 * tanto número quanto lista de nomes, e acusar por ele transformaria o
 * detector em ruído — o que a regra cobra é que a lista exista, não que o
 * marcador seja de um tipo.
 *
 * @param string $literal Conteúdo do literal.
 * @return bool
 */
function f3b_literal_conta_estado( string $literal ): bool {
	$estados = implode( '|', array_map( static fn( string $e ): string => preg_quote( $e, '/' ), F3Base_Suite::ESTADOS ) );

	$antes  = '/%[0-9]*\$?d\s*(?:[a-zçãáéíóúâêô]+\s+){0,2}(' . $estados . ')(?![A-Za-z0-9_])/u';
	$depois = '/(?<![A-Za-z0-9_])(' . $estados . ')\s*[:=]?\s*%[0-9]*\$?d/u';

	return 1 === preg_match( $antes, $literal ) || 1 === preg_match( $depois, $literal );
}

/**
 * Unidades de saída de um arquivo: cada função nomeada, mais o RESTO do arquivo.
 *
 * O resto existe porque os dois runners da suíte imprimem o resumo em escopo de
 * arquivo, fora de qualquer função — e um detector que só olhasse funções
 * deixaria justamente o rodapé da rodada de fora.
 *
 * @param string $src Código já sem comentário.
 * @return array<int,array{nome:string,corpo:string,linha:int}>
 */
function f3b_unidades_de_saida( string $src ): array {
	$funcoes = f3b_funcoes_do_arquivo( $src );
	$resto   = $src;

	foreach ( $funcoes as $funcao ) {
		$pos = strpos( $resto, $funcao['corpo'] );

		if ( false !== $pos && '' !== $funcao['corpo'] ) {
			$resto = substr_replace( $resto, "\n", $pos, strlen( $funcao['corpo'] ) );
		}
	}

	$funcoes[] = array(
		'nome'  => '(escopo de arquivo)',
		'corpo' => $resto,
		'linha' => 1,
	);

	return $funcoes;
}

/**
 * Nenhuma contagem de estado sai sem a LISTA DE NOMES na mesma saída.
 *
 * O defeito medido, e ele é de instrumento: o cabeçalho do log dizia
 * "checagens do relatório: 5 FALHA e 6 BLOCKED · unidades do plano: 1 FALHA e 2
 * BLOCKED" e as linhas renderizadas mostravam UMA unidade em FALHA. As outras
 * rodavam DENTRO de unidades que fecharam OK e não tinham linha nenhuma. O
 * operador ficava com um número e nenhum nome — nada que ele pudesse abrir,
 * procurar ou corrigir. Contagem sem nome não responde à pergunta que ele faz
 * em seguida, que é sempre "quais?".
 *
 * A regra, executável: toda unidade de saída (função nomeada, ou o escopo de
 * arquivo) que LEIA uma contagem por estado — ou que imprima um literal com um
 * estado ao lado de um número — precisa referenciar, no mesmo corpo, uma fonte
 * de NOMES por estado. Estado OK continua podendo sair resumido: o que a regra
 * proíbe é estado ruim invisível.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_contagem_com_nomes( string $raiz ): array {
	$fontes  = f3b_fontes_de_contagem();
	$nomes   = f3b_fontes_de_nomes();
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'php', 'js', 'mjs' ), f3b_excluidos() ) as $rel ) {
		$extensao = strtolower( (string) pathinfo( $rel, PATHINFO_EXTENSION ) );
		$caminho  = $raiz . '/' . $rel;
		$src      = 'php' === $extensao ? f3b_codigo_php( $caminho ) : f3b_codigo_js( $caminho );
		$contam   = 'php' === $extensao ? $fontes['php'] : $fontes['js'];

		foreach ( f3b_unidades_de_saida( $src ) as $unidade ) {
			$corpo = $unidade['corpo'];

			if ( '' === trim( $corpo ) ) {
				continue;
			}

			++$medidas;

			$motivo = '';

			foreach ( $contam as $marca ) {
				if ( str_contains( $corpo, $marca ) ) {
					$motivo = 'lê a contagem por estado em "' . $marca . '"';
					break;
				}
			}

			if ( '' === $motivo && preg_match_all( '/([\'"])((?:\\\\.|(?!\1).)*)\1/s', $corpo, $ms ) ) {
				foreach ( $ms[2] as $literal ) {
					if ( f3b_literal_conta_estado( $literal ) ) {
						$motivo = 'imprime um estado ao lado de um número em "' . trim( mb_substr( $literal, 0, 60 ) ) . '…"';
						break;
					}
				}
			}

			if ( '' === $motivo ) {
				continue;
			}

			$nomeia = false;

			foreach ( $nomes as $marca ) {
				if ( str_contains( $corpo, $marca ) ) {
					$nomeia = true;
					break;
				}
			}

			if ( $nomeia ) {
				continue;
			}

			$achados[] = $rel . ':' . $unidade['linha'] . ' ' . $unidade['nome']
				. ' ' . $motivo . ' e NÃO produz a lista de nomes correspondente na mesma saída: '
				. 'contagem de estado sem nome responde "quantos?" e a pergunta do operador é "quais?". '
				. 'Use uma das fontes de nomes declaradas (' . implode( ', ', $nomes ) . ')';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Fonte JavaScript sem comentário, com as linhas preservadas.
 *
 * A varredura mede o que EXECUTA, aqui pela mesma razão que em PHP: a prosa que
 * explica a armadilha cita a armadilha, e reprovar o arquivo correto por causa
 * do comentário que o explica é o detector gritando por causa de si mesmo.
 *
 * @param string $caminho Caminho absoluto.
 * @return string
 */
function f3b_codigo_js( string $caminho ): string {
	$src   = (string) file_get_contents( $caminho );
	$saida = '';
	$tam   = strlen( $src );
	$i     = 0;

	while ( $i < $tam ) {
		$par = substr( $src, $i, 2 );

		if ( '/*' === $par ) {
			$fim    = strpos( $src, '*/', $i + 2 );
			$fim    = false === $fim ? $tam : $fim + 2;
			$saida .= str_repeat( "\n", substr_count( substr( $src, $i, $fim - $i ), "\n" ) );
			$i      = $fim;
			continue;
		}

		if ( '//' === $par ) {
			$fim = strpos( $src, "\n", $i );
			$i   = false === $fim ? $tam : $fim;
			continue;
		}

		if ( '\'' === $src[ $i ] || '"' === $src[ $i ] ) {
			$aspas  = $src[ $i ];
			$saida .= $aspas;
			++$i;

			while ( $i < $tam && $src[ $i ] !== $aspas ) {
				if ( '\\' === $src[ $i ] && $i + 1 < $tam ) {
					$saida .= substr( $src, $i, 2 );
					$i     += 2;
					continue;
				}

				$saida .= $src[ $i ];
				++$i;
			}

			if ( $i < $tam ) {
				$saida .= $aspas;
				++$i;
			}

			continue;
		}

		$saida .= $src[ $i ];
		++$i;
	}

	return $saida;
}

/* -------------------------------------------------------------------------
 * estatica.unidade_reflete_internas
 * ---------------------------------------------------------------------- */

/**
 * Estados fechados como o código do implantador os escreve, normalizados.
 *
 * `self::NA` e `F3Base_Imp_Relatorio::NA` valem pelo estado `N/A`; o literal
 * entre aspas vale por si. A tabela mora aqui porque é tradução de GRAFIA, não
 * declaração de ordem — a ordem sai do pacote varrido, e é isso que este
 * detector confere.
 *
 * @return array<string,string> Sufixo da constante => estado fechado.
 */
function f3b_grafias_de_estado(): array {
	return array(
		'OK'      => 'OK',
		'FALHA'   => 'FALHA',
		'BLOCKED' => 'BLOCKED',
		'NA'      => 'N/A',
		'WAIVED'  => 'WAIVED',
		'WARN'    => 'WARN',
	);
}

/**
 * ONDE o pacote declara a ordem de severidade, e qual ordem ele declara.
 *
 * Uma DECLARAÇÃO DE ORDEM é um bloco em que ao menos quatro dos seis estados
 * fechados recebem um inteiro, e em que esses inteiros não são todos iguais. A
 * segunda condição é o que separa a ordem do CONTADOR: `array( OK => 0, FALHA
 * => 0, … )` mapeia os seis estados a um inteiro e não ordena coisa alguma.
 *
 * A ordem sai do PACOTE VARRIDO, nunca de uma lista escrita aqui — pelo mesmo
 * motivo que os nomes de gate saem da função âncora: uma segunda declaração na
 * suíte seria a segunda fonte para o fato que este detector existe para manter
 * único.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{lugares:array<int,string>,ordem:array<string,int>}
 */
function f3b_declaracoes_de_severidade( string $raiz ): array {
	$grafias = f3b_grafias_de_estado();

	/*
	 * A expressão é montada por `sprintf()`, e não por concatenação: um literal
	 * PHP com `=>` colado a um ponto de concatenação é acusado por
	 * `estatica.detector_codigo_em_string`, que lê `=>` como arrow function.
	 * Reescrever o outro detector para abrir exceção a este seria enfraquecer a
	 * regra por conveniência de quem a viola.
	 */
	$re = sprintf(
		'/(?:self|F3Base_Imp_Relatorio)::(%1$s)\s*%2$s\s*(\d+)|\'(%3$s)\'\s*%2$s\s*(\d+)/',
		implode( '|', array_keys( $grafias ) ),
		preg_quote( '=>', '/' ),
		implode( '|', array_map( static fn( string $e ): string => preg_quote( $e, '/' ), array_values( $grafias ) ) )
	);

	$lugares = array();
	$ordem   = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! preg_match_all( $re, $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			continue;
		}

		$grupo    = array();
		$primeira = 0;
		$anterior = -10;

		/* Fecha o grupo corrente e o registra quando ele for uma ordem. */
		$fechar = static function () use ( &$grupo, &$primeira, &$lugares, &$ordem, $rel ): void {
			if ( count( $grupo ) < 4 || count( array_unique( array_values( $grupo ) ) ) < 2 ) {
				$grupo = array();
				return;
			}

			$lugares[] = $rel . ':' . $primeira;

			if ( array() === $ordem ) {
				$ordem = $grupo;
			}

			$grupo = array();
		};

		foreach ( $ms as $m ) {
			$pos   = (int) $m[0][1];
			$linha = substr_count( substr( $src, 0, $pos ), "\n" ) + 1;

			if ( $linha - $anterior > 3 ) {
				$fechar();
				$primeira = $linha;
			}

			$anterior = $linha;

			$estado = '' !== (string) $m[1][0] ? $grafias[ (string) $m[1][0] ] : (string) ( $m[3][0] ?? '' );
			$peso   = '' !== (string) $m[1][0] ? (int) $m[2][0] : (int) ( $m[4][0] ?? 0 );

			if ( '' !== $estado ) {
				$grupo[ $estado ] = $peso;
			}
		}

		$fechar();
	}

	return array(
		'lugares' => $lugares,
		'ordem'   => $ordem,
	);
}

/**
 * Funções do pacote que APLICAM o helper único de severidade.
 *
 * Existe porque a aplicação é de DOIS SALTOS por desenho: `processar()` chama
 * `veredito_da_unidade()`, e é esta que compara. Exigir a marca literal dentro
 * de quem emite a linha da unidade obrigaria a promoção a morar no orquestrador
 * inteiro em vez de numa função que o piso consegue exercitar.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<string,bool> Nome da função => ela consulta o gate que decide?
 */
function f3b_promotoras_de_severidade( string $raiz ): array {
	$funcoes = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		foreach ( f3b_funcoes_do_arquivo( f3b_codigo_php( $raiz . '/' . $rel ) ) as $funcao ) {
			$funcoes[ $funcao['nome'] ] = ( $funcoes[ $funcao['nome'] ] ?? '' ) . $funcao['corpo'];
		}
	}

	/*
	 * CIÊNCIA DO GATE É TRANSITIVA, como a aplicação do helper: a função que
	 * compara pode delegar o teste de gate a uma função de uma linha — e é o que
	 * o pacote faz, porque a regra tem um caso de borda (gate vazio) que uma
	 * comparação repetida em três pontos erra. Exigir a marca literal dentro de
	 * quem compara obrigaria a regra a morar inline, que é o contrário do que a
	 * própria borda ensinou.
	 */
	$cientes = array();

	foreach ( $funcoes as $nome_da_funcao => $corpo ) {
		if ( str_contains( $corpo, 'GATE_QUE_DECIDE' ) ) {
			$cientes[ $nome_da_funcao ] = true;
		}
	}

	$nomes = array();

	foreach ( $funcoes as $nome_da_funcao => $corpo ) {
		if ( ! str_contains( $corpo, 'estado_mais_severo(' ) ) {
			continue;
		}

		$ciente = isset( $cientes[ $nome_da_funcao ] );

		foreach ( array_keys( $cientes ) as $delegada ) {
			$ciente = $ciente || str_contains( $corpo, $delegada . '(' );
		}

		$nomes[ $nome_da_funcao ] = $ciente;
	}

	return $nomes;
}

/**
 * Listas de linhas de relatório dentro de uma estrutura já analisada.
 *
 * Uma lista de linhas é uma lista cujos itens todos têm `estado` e `nome`, e em
 * que ao menos um está marcado como `unidade`. É a forma exata do acumulador do
 * relatório, e é o registro que o operador baixa da tela.
 *
 * @param array<mixed> $valor Estrutura analisada.
 * @return array<int,array<int,array<string,mixed>>>
 */
function f3b_listas_de_linhas( array $valor ): array {
	$saida       = array();
	$e_lista     = array() !== $valor;
	$tem_unidade = false;

	foreach ( $valor as $item ) {
		if ( ! is_array( $item ) || ! isset( $item['estado'] ) || ! isset( $item['nome'] ) ) {
			$e_lista = false;
			break;
		}

		$tem_unidade = $tem_unidade || ! empty( $item['unidade'] );
	}

	if ( $e_lista && $tem_unidade ) {
		$saida[] = array_values( $valor );
	}

	foreach ( $valor as $filho ) {
		if ( is_array( $filho ) ) {
			$saida = array_merge( $saida, f3b_listas_de_linhas( $filho ) );
		}
	}

	return $saida;
}

/**
 * Unidades que fecharam em estado MENOS severo do que uma checagem SUA E DO
 * GATE QUE DECIDE.
 *
 * A varredura reproduz a ordem real de emissão: as checagens saem primeiro, a
 * linha da unidade sai depois e fecha o bloco. Cada achado NOMEIA AS DUAS — a
 * unidade e a checagem —, porque "há incoerência no relatório" não é coisa que
 * o operador possa abrir.
 *
 * A DISTINÇÃO DE GATE, e por que ela não é uma exceção conveniente: checagem
 * cuja evidência este host não produz — navegador, campo, suíte externa — é
 * relatada e não decide, exatamente como no gate da autodesativação. Sem isso a
 * unidade `entrega`, que emite `orcamento.medicao_de_pagina` em BLOCKED por
 * natureza, fecharia BLOCKED em toda instalação, para sempre, por desenho.
 *
 * O gate que decide sai do PACOTE VARRIDO, não de uma constante escrita aqui, e
 * gate AUSENTE conta como gate que decide: a omissão não pode ser o caminho
 * barato para escapar da promoção.
 *
 * @param array<int,array<string,mixed>> $linhas  Linhas do registro, na ordem.
 * @param array<string,int>              $ordem   Ordem de severidade do pacote.
 * @param string                         $arquivo Arquivo do registro, para o achado.
 * @param string                         $decide  Gate cuja checagem decide o veredito.
 * @return array<int,string> Achados.
 */
function f3b_unidades_menos_severas( array $linhas, array $ordem, string $arquivo, string $decide ): array {
	$achados = array();
	$bloco   = array();

	foreach ( $linhas as $linha ) {
		$estado = (string) ( $linha['estado'] ?? '' );
		$nome   = (string) ( $linha['nome'] ?? '' );
		/* Gate ausente OU VAZIO conta como o gate que decide: a omissão não absolve. */
		$gate   = '' !== (string) ( $linha['gate'] ?? '' ) ? (string) $linha['gate'] : $decide;

		if ( empty( $linha['unidade'] ) ) {
			$bloco[] = array( $nome, $estado, $gate );
			continue;
		}

		$peso_da_unidade = $ordem[ $estado ] ?? -1;

		foreach ( $bloco as $interna ) {
			if ( $decide !== $interna[2] ) {
				continue;
			}

			$peso_da_interna = $ordem[ $interna[1] ] ?? -1;

			if ( $peso_da_interna > $peso_da_unidade ) {
				$achados[] = $arquivo . ': a unidade "' . $nome . '" fechou ' . $estado
					. ' contendo a checagem "' . $interna[0] . '" em ' . $interna[1]
					. ', do gate ' . $decide . ' — quem lê o resumo por unidade vê verde onde há vermelho';
			}
		}

		$bloco = array();
	}

	return $achados;
}

/**
 * O GATE QUE DECIDE o veredito da unidade, declarado pelo pacote varrido.
 *
 * Como a ordem de severidade e como os nomes de gate do canal: o valor sai da
 * âncora do próprio pacote. Uma constante escrita na suíte seria a segunda
 * declaração do mesmo fato — e um pacote que mudasse a sua passaria a ser
 * medido pela régua errada, calada.
 *
 * @param string $raiz Raiz a varrer.
 * @return string Gate declarado, ou vazio quando o pacote não declara nenhum.
 */
function f3b_gate_que_decide( string $raiz ): string {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( preg_match( '/const\s+GATE_QUE_DECIDE\s*=\s*\'([a-z_]+)\'/', $src, $m ) ) {
			return (string) $m[1];
		}
	}

	return '';
}

/**
 * NENHUMA UNIDADE FECHA EM ESTADO MENOS SEVERO DO QUE O QUE ELA MEDIU.
 *
 * O defeito medido na 1.0.8, com as duas linhas verbatim: a linha 48 do
 * relatório era `OK entrega — "todos os entregáveis do gate de aplicação
 * fecharam sem BLOCKED"` e a linha 49, DENTRO dela, era
 * `FALHA ↳ mcp.canal_unico`. Quem lê o resumo por unidade vê verde onde há
 * vermelho, e foi essa mesma discrepância que escondeu as FALHAs até a 1.0.7.
 *
 * Três regras, e cada uma fecha uma porta diferente:
 *
 * 1. **Quem emite a linha de uma unidade aplica a promoção.** Toda função que
 *    chama `emitir_unidade()` precisa passar por `estado_mais_severo()`, direta
 *    ou pela função que o aplica. Sem isso a regra vira convenção, e convenção
 *    é o que a próxima etapa esquece.
 * 2. **A ordem de severidade é declarada em UM lugar.** Duas declarações
 *    divergem, e a divergência sai como um relatório que se contradiz — foi
 *    exatamente assim que a ordem viveu em `F3Base_Imp_Plugins` enquanto o
 *    orquestrador não tinha nenhuma.
 * 3. **A promoção é POR GATE, e o gate que decide é declarado.** Sem a âncora
 *    `GATE_QUE_DECIDE` e sem uma promotora que a consulte, a promoção é cega: a
 *    unidade `entrega`, que emite `orcamento.medicao_de_pagina` em BLOCKED por
 *    natureza, fecharia BLOCKED em toda instalação, para sempre, por desenho —
 *    a mesma armadilha que a 1.0.7 desfez no gate da autodesativação.
 * 4. **Nenhum registro de relatório do pacote contém unidade menos severa que
 *    uma checagem sua DO GATE QUE DECIDE.** É a regra medida sobre DADOS, e é
 *    ela que acusa nomeando as duas linhas. Fica inerte quando o pacote não
 *    carrega registro nenhum — o log de execução mora em option, no host —, e é
 *    no piso que ela prova saber acusar, dos dois lados: acusa a interna de
 *    aplicação e cala sobre a de fase, para que a distinção de gate não vire a
 *    porta de escape que absolve qualquer coisa marcada como fase.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_unidade_reflete_internas( string $raiz ): array {
	$achados    = array();
	$declaracao = f3b_declaracoes_de_severidade( $raiz );
	$promotoras = f3b_promotoras_de_severidade( $raiz );
	$decide     = f3b_gate_que_decide( $raiz );
	$medidas    = 0;

	if ( array() === $declaracao['lugares'] ) {
		$achados[] = 'nenhuma declaração de ordem de severidade foi encontrada fora de suite/: sem a ordem, '
			. '"estado mais severo" não quer dizer nada e a promoção do veredito da unidade não pode ser conferida';
	}

	if ( '' === $decide ) {
		$achados[] = 'nenhuma âncora GATE_QUE_DECIDE foi encontrada fora de suite/: sem declarar QUAL gate decide o '
			. 'veredito da unidade, a promoção é cega — ou engole a evidência de fase que o host não produz e trava a '
			. 'unidade em BLOCKED para sempre, ou não promove nada';
	}

	if ( count( $declaracao['lugares'] ) > 1 ) {
		$achados[] = 'a ordem de severidade é declarada em ' . count( $declaracao['lugares'] ) . ' lugares: '
			. implode( ' E ', $declaracao['lugares'] )
			. ' — duas ordens divergem, e a divergência sai como um relatório que se contradiz; a ordem mora em um lugar só';
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( ! str_contains( $funcao['corpo'], 'emitir_unidade(' ) ) {
				continue;
			}

			++$medidas;


			$aplica         = false;
			$ciente_do_gate = str_contains( $funcao['corpo'], 'GATE_QUE_DECIDE' );

			foreach ( $promotoras as $promotora => $olha_o_gate ) {
				if ( str_contains( $funcao['corpo'], $promotora . '(' ) ) {
					$aplica         = true;
					$ciente_do_gate = $ciente_do_gate || $olha_o_gate;
				}
			}

			if ( ! $aplica ) {
				$achados[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome']
					. '() emite a linha de uma unidade sem passar o estado por estado_mais_severo(), nem direta '
					. 'nem por quem o aplica: a unidade pode fechar em estado menos severo do que a checagem que '
					. 'ela mesma emitiu, que é o OK por cima de uma FALHA';
				continue;
			}

			if ( '' !== $decide && ! $ciente_do_gate ) {
				$achados[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome']
					. '() promove o veredito da unidade sem olhar o GATE da checagem: promoção cega engole a '
					. 'evidência que este host não produz — a medição de página, de navegador, é BLOCKED por '
					. 'natureza — e trava a unidade em BLOCKED em toda instalação, para sempre, por desenho';
			}
		}
	}

	if ( array() !== $declaracao['ordem'] && '' !== $decide ) {
		foreach ( f3b_arquivos( $raiz, array( 'json' ), f3b_excluidos() ) as $rel ) {
			$json = json_decode( (string) file_get_contents( $raiz . '/' . $rel ), true );

			if ( ! is_array( $json ) ) {
				continue;
			}

			foreach ( f3b_listas_de_linhas( $json ) as $linhas ) {
				++$medidas;
				$achados = array_merge( $achados, f3b_unidades_menos_severas( $linhas, $declaracao['ordem'], $rel, $decide ) );
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.option_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * Prefixos que ficam FORA da varredura de produtores de option.
 *
 * O escopo é o código do IMPLANTADOR — a raiz e `includes/`. `fontes/` traz o
 * catálogo de options do `site-core`, que DECLARA a forma e o padrão de cada
 * uma (`'f3base_redirects' => array( 'padrao' => …, 'sanitiza' => … )`) e não
 * produz valor desejado de implantação nenhum; contá-lo como produtor faria o
 * detector acusar a declaração do dono da option. `suite/` e `content/` não
 * gravam options.
 *
 * @return array<int,string>
 */
function f3b_fora_do_escopo_de_option(): array {
	return array_merge( f3b_excluidos(), array( 'fontes/', 'suite/', 'content/' ) );
}

/**
 * Nomes de option GERENCIADA, lidos da âncora `options_gerenciadas()`.
 *
 * Como em `f3b_gates_declarados()`, a lista sai do PRÓPRIO PACOTE: escrevê-la
 * na suíte seria a segunda fonte para o mesmo fato — precisamente o que este
 * detector existe para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{nomes:array<int,string>,ancora:string}
 */
function f3b_options_gerenciadas_declaradas( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), 'options_gerenciadas' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([A-Za-z_][A-Za-z0-9_]*)'/", $corpo, $ms );

		return array(
			'nomes'  => array_values( array_unique( $ms[1] ) ),
			'ancora' => $rel,
		);
	}

	return array(
		'nomes'  => array(),
		'ancora' => '',
	);
}

/**
 * O mapa option => função de união, lido da âncora `uniao_declarada()`.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{mapa:array<string,string>,ancora:string}
 */
function f3b_uniao_declarada( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), 'uniao_declarada' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'\s*=>\s*'([^']+)'/", $corpo, $ms, PREG_SET_ORDER );

		$mapa = array();

		foreach ( $ms as $m ) {
			$mapa[ $m[1] ] = $m[2];
		}

		return array(
			'mapa'   => $mapa,
			'ancora' => $rel,
		);
	}

	return array(
		'mapa'   => array(),
		'ancora' => '',
	);
}

/**
 * A expressão de VALOR que começa em `$pos`, até a vírgula ou o fecho do nível.
 *
 * Lê com parênteses, colchetes e chaves balanceados, para que
 * `array( 'a' => b( 1, 2 ) )` não seja cortado na vírgula de dentro.
 *
 * @param string $src Código.
 * @param int    $pos Posição do primeiro caractere da expressão.
 * @return string
 */
function f3b_expressao_de_valor( string $src, int $pos ): string {
	$tam   = strlen( $src );
	$nivel = 0;
	$buf   = '';

	for ( $i = $pos; $i < $tam; $i++ ) {
		$c = $src[ $i ];

		if ( '(' === $c || '[' === $c || '{' === $c ) {
			$nivel++;
		}

		if ( ')' === $c || ']' === $c || '}' === $c ) {
			if ( 0 === $nivel ) {
				break;
			}

			$nivel--;
		}

		if ( 0 === $nivel && ( ',' === $c || ';' === $c ) ) {
			break;
		}

		$buf .= $c;
	}

	return trim( preg_replace( '/\s+/', ' ', $buf ) ?? '' );
}

/**
 * O nome da função que envolve uma posição do código.
 *
 * @param string $src Código.
 * @param int    $pos Posição.
 * @return string
 */
function f3b_funcao_envolvente( string $src, int $pos ): string {
	if ( ! preg_match_all( '/function\s+(\w+)\s*\(/', substr( $src, 0, $pos ), $ms, PREG_SET_ORDER ) ) {
		return '(escopo de arquivo)';
	}

	$ultimo = end( $ms );

	return (string) $ultimo[1];
}

/**
 * Constantes de classe que valem uma cadeia literal, no escopo do implantador.
 *
 * Existe porque o nome da option NEM SEMPRE aparece como literal no ponto da
 * gravação: `F3Base_Imp_Navegacao::OPTION` é o nome de uma option gerenciada
 * escrito de outro jeito, e um detector que só enxergasse aspas contaria um
 * produtor onde há dois — que é o buraco por onde este defeito entrou.
 *
 * A resolução é POR CLASSE, nunca por nome solto de constante: duas classes
 * deste pacote declaram `const OPTION`, com valores diferentes, e um mapa
 * global as confundiria — ou, o que é pior, descartaria as duas e voltaria a
 * não enxergar a forma que importa.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{por_arquivo:array<string,array<string,string>>,qualificadas:array<string,string>}
 */
function f3b_constantes_de_classe( string $raiz ): array {
	$por_arquivo  = array();
	$qualificadas = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! preg_match_all( "/const\s+([A-Z][A-Z0-9_]*)\s*=\s*'([^']*)'/", $src, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		$classe                = preg_match( '/\bclass\s+(\w+)/', $src, $mc ) ? (string) $mc[1] : '';
		$por_arquivo[ $rel ]   = array();

		foreach ( $ms as $m ) {
			$por_arquivo[ $rel ][ $m[1] ] = $m[2];

			if ( '' !== $classe ) {
				$qualificadas[ $classe . '::' . $m[1] ] = $m[2];
			}
		}
	}

	return array(
		'por_arquivo'  => $por_arquivo,
		'qualificadas' => $qualificadas,
	);
}

/**
 * Pontos do código que PRODUZEM o valor desejado de uma option.
 *
 * Duas formas, e as duas precisam contar — foi justamente a diferença entre
 * elas que escondeu o defeito medido: a etapa de permalinks passava o valor
 * DIRETO ao gravador, e a etapa de options do `site-core` o passava dentro de
 * um mapa `option => valor` que um laço grava depois. Procurar só a chamada
 * direta enxergaria um produtor onde havia dois.
 *
 * Menção não é produção: `get_option( 'nome' )`, `in_array( 'nome', … )` e a
 * lista de nomes da âncora não ligam o nome a um valor desejado, e não entram.
 *
 * @param string            $raiz  Raiz a varrer.
 * @param array<int,string> $nomes Options gerenciadas.
 * @return array<string,array<int,array{onde:string,expr:string}>>
 */
function f3b_produtores_de_option( string $raiz, array $nomes ): array {
	$produtores = array();
	/*
	 * ÂNCORAS não são produtores. Elas DECLARAM, em pares `chave => valor`, o
	 * que o pacote afirma sobre si — e o nome de uma option dentro de uma delas
	 * é declaração, não gravação. Sem esta lista, a âncora que nomeia o produtor
	 * de cada seleção de llms.txt seria contada como um segundo ponto produzindo
	 * o valor de `f3base_llms`, e o detector acusaria a própria declaração.
	 */
	$ancoras    = array( 'uniao_declarada', 'options_gerenciadas', 'produtor_de_item_llms' );
	$constantes = f3b_constantes_de_classe( $raiz );

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src     = f3b_codigo_php( $raiz . '/' . $rel );
		$achados = array();

		foreach ( $nomes as $nome ) {
			$literal = preg_quote( $nome, '/' );

			/*
			 * As duas expressões são montadas por `sprintf()`, e não por
			 * concatenação: a seta do elemento de array é uma das marcas de
			 * JavaScript de `f3b_linguagem_em_texto()`, e um literal com ela
			 * colado por `.` faria `estatica.detector_codigo_em_string`
			 * reprovar ESTE detector. É a mesma saída que `$re_inline` já usa
			 * lá — o detector que grita por causa de si é tão inútil quanto o
			 * que nunca grita.
			 */
			foreach (
				array(
					sprintf( '/F3Base_Imp_Gravador::gravar(?:_chaves)?\(\s*\'%s\'\s*,\s*/', $literal ),
					sprintf( '/\'%s\'\s*=>\s*/', $literal ),
				) as $re
			) {
				if ( ! preg_match_all( $re, $src, $ms, PREG_OFFSET_CAPTURE ) ) {
					continue;
				}

				foreach ( $ms[0] as $m ) {
					$achados[] = array(
						'nome' => $nome,
						'pos'  => (int) $m[1],
						'fim'  => (int) $m[1] + strlen( (string) $m[0] ),
					);
				}
			}
		}

		/* A MESMA option escrita pelo nome de uma constante de classe. */
		foreach (
			array(
				'/F3Base_Imp_Gravador::gravar(?:_chaves)?\(\s*(self|static|[A-Za-z_][A-Za-z0-9_]*)::([A-Z][A-Z0-9_]*)\s*,\s*/',
				'/(self|static|[A-Za-z_][A-Za-z0-9_]*)::([A-Z][A-Z0-9_]*)\s*=>\s*/',
			) as $re
		) {
			if ( ! preg_match_all( $re, $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $ms as $m ) {
				$escopo    = (string) $m[1][0];
				$resolvida = in_array( $escopo, array( 'self', 'static' ), true )
					? (string) ( $constantes['por_arquivo'][ $rel ][ $m[2][0] ] ?? '' )
					: (string) ( $constantes['qualificadas'][ $escopo . '::' . $m[2][0] ] ?? '' );

				if ( ! in_array( $resolvida, $nomes, true ) ) {
					continue;
				}

				$achados[] = array(
					'nome' => $resolvida,
					'pos'  => (int) $m[0][1],
					'fim'  => (int) $m[0][1] + strlen( (string) $m[0][0] ),
				);
			}
		}

		foreach ( $achados as $achado ) {
			$funcao = f3b_funcao_envolvente( $src, $achado['pos'] );

			if ( in_array( $funcao, $ancoras, true ) ) {
				continue;
			}

			$produtores[ $achado['nome'] ][] = array(
				'onde' => $rel . ':' . ( substr_count( substr( $src, 0, $achado['pos'] ), "\n" ) + 1 ) . ' ' . $funcao . '()',
				'expr' => f3b_expressao_de_valor( $src, $achado['fim'] ),
			);
		}
	}

	return $produtores;
}

/**
 * Nenhuma option gerenciada com dois produtores de valor desejado fora da união.
 *
 * O DEFEITO MEDIDO NO BANCO DEPOIS DA 1.0.11. `f3base_redirects` ficou em
 * `a:0:{}` e o log da mesma execução afirmava "permalinks aplicada para
 * /%postname%/, com 2 URL(s) antiga(s) respondendo por redirecionamento
 * declarado". As duas coisas eram verdadeiras: a etapa de permalinks computou
 * os pares, gravou e leu de volta; mais adiante, a etapa `site_core.options`
 * gravou a MESMA option a partir de `redirects: []` do arquivo de configuração,
 * gravou e leu de volta. Duas fontes de valor desejado, duas mensagens
 * verdadeiras, um artefato que contradiz a primeira — e as URLs antigas dos
 * dois posts respondendo 404 em vez de 301.
 *
 * A regra: option gerenciada pode ter quantas FONTES o projeto precisar, e um
 * ponto só produzindo o valor desejado. Havendo dois, os dois precisam passar
 * pela função de UNIÃO declarada em `uniao_declarada()` — e, quando passam,
 * este detector fica em silêncio, porque aí não existem duas respostas: existe
 * uma resposta com várias parcelas.
 *
 * É a terceira vez neste ciclo que duas fontes para o mesmo fato produzem
 * relatório contraditório — `estatica.gate_fonte_unica` cobre o veredito e o
 * artefato da rodada; esta cobre a OPTION. A prosa não segurou nas duas
 * anteriores.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_option_fonte_unica( string $raiz ): array {
	$gerenciadas = f3b_options_gerenciadas_declaradas( $raiz );
	$uniao       = f3b_uniao_declarada( $raiz );

	if ( array() === $gerenciadas['nomes'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função options_gerenciadas() foi encontrada no código do implantador: sem a âncora que declara '
					. 'QUAIS options são gerenciadas por este pacote, não há como saber sobre o que a regra de fonte '
					. 'única vale — e uma regra sem escopo é uma regra que nunca acusa nada',
			),
			'medidas' => 1,
		);
	}

	$produtores = f3b_produtores_de_option( $raiz, $gerenciadas['nomes'] );
	$achados    = array();

	foreach ( $gerenciadas['nomes'] as $nome ) {
		$lugares = $produtores[ $nome ] ?? array();
		$funcao  = (string) ( $uniao['mapa'][ $nome ] ?? '' );

		if ( count( $lugares ) < 2 ) {
			continue;
		}

		$fora = array();

		foreach ( $lugares as $lugar ) {
			if ( '' === $funcao || ! str_contains( $lugar['expr'], $funcao . '(' ) ) {
				$fora[] = $lugar['onde'] . ' produz «' . $lugar['expr'] . '»';
			}
		}

		if ( array() === $fora ) {
			continue;
		}

		$achados[] = 'a option gerenciada "' . $nome . '" tem ' . count( $lugares ) . ' ponto(s) do código produzindo o '
			. 'valor desejado, e ' . count( $fora ) . ' dele(s) NÃO passa(m) pela função de união declarada'
			. ( '' === $funcao ? ' (nenhuma união está declarada para esta option em uniao_declarada())' : ' ' . $funcao . '()' )
			. ': ' . implode( ' E ', array_map( static fn( array $l ): string => $l['onde'] . ' produz «' . $l['expr'] . '»', $lugares ) )
			. ' — a segunda a rodar apaga o que a primeira gravou, as duas leem de volta, as duas conferem, e o relatório '
			. 'sai com duas mensagens verdadeiras e contraditórias sobre o mesmo artefato';
	}

	/*
	 * União declarada para option que não existe, ou apontando para função que
	 * ninguém definiu: a declaração passaria a absolver sozinha, e o detector
	 * ficaria em silêncio por não ter o que medir.
	 */
	foreach ( $uniao['mapa'] as $nome => $funcao ) {
		if ( ! in_array( $nome, $gerenciadas['nomes'], true ) ) {
			$achados[] = 'uniao_declarada() declara união para "' . $nome . '", que não consta das options gerenciadas '
				. 'declaradas em ' . $gerenciadas['ancora'] . ': declaração sem alvo absolve sem medir';
			continue;
		}

		$definida = false;

		foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
			if ( null !== f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $funcao ) ) {
				$definida = true;
				break;
			}
		}

		if ( ! $definida ) {
			$achados[] = 'uniao_declarada() aponta "' . $nome . '" para ' . $funcao . '(), que não está definida em '
				. 'lugar nenhum do código do implantador: a união declarada e ausente é pior que a união inexistente, '
				. 'porque ela faz o detector calar';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $gerenciadas['nomes'] ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.pagina_status_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * Mapa `chave => valor` declarado por uma função-ÂNCORA do pacote.
 *
 * Mesma construção de `f3b_uniao_declarada()`, generalizada: a suíte LÊ do
 * próprio pacote o que ele declara sobre si, em vez de manter uma cópia. Cópia
 * é a segunda fonte para o mesmo fato, que é o defeito que estas regras
 * existem para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @param string $nome Nome da função-âncora.
 * @return array{mapa:array<string,string>,ancora:string}
 */
function f3b_ancora_mapa( string $raiz, string $nome ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $nome );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'\s*=>\s*'([^']*)'/", $corpo, $ms, PREG_SET_ORDER );

		$mapa = array();

		foreach ( $ms as $m ) {
			$mapa[ $m[1] ] = $m[2];
		}

		return array(
			'mapa'   => $mapa,
			'ancora' => $rel,
		);
	}

	return array(
		'mapa'   => array(),
		'ancora' => '',
	);
}

/**
 * A função existe em algum arquivo do implantador?
 *
 * @param string $raiz Raiz a varrer.
 * @param string $nome Nome da função.
 * @return bool
 */
function f3b_funcao_existe( string $raiz, string $nome ): bool {
	if ( '' === $nome ) {
		return false;
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		if ( null !== f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $nome ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Funções que LEEM um caminho de configuração, atribuídas por função.
 *
 * O caminho é normalizado do jeito que `estatica.detector_chave_sem_consumidor`
 * já normaliza — índice dinâmico vira `*` —, para que `'paginas.' . $indice .
 * '.status'` e `'paginas.0.status'` sejam o mesmo caminho.
 *
 * @param string $raiz Raiz a varrer.
 * @param string $alvo Caminho normalizado procurado.
 * @return array<int,array{onde:string,nome:string,corpo:string}>
 */
function f3b_leitores_de_caminho( string $raiz, string $alvo ): array {
	$leitores = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			foreach ( f3b_chamadas_regex( $funcao['corpo'], F3B_RE_CONFIG ) as $args ) {
				$caminho = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args ) ) );

				if ( $caminho !== $alvo ) {
					continue;
				}

				$leitores[] = array(
					'onde'  => $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()',
					'nome'  => $funcao['nome'],
					'corpo' => $funcao['corpo'],
				);
				continue 2;
			}
		}
	}

	return $leitores;
}

/**
 * Funções que produzem o `post_status` DESEJADO de uma página gerenciada.
 *
 * A discriminação é dupla e as duas metades importam:
 *
 * - **`'post_type' => 'page'` literal** no corpo, que é o que separa página de
 *   `wp_navigation` e dos outros tipos — o menu é post e o status dele nunca
 *   foi decisão editorial deste pacote.
 * - **`post_status` com valor que NÃO é `array(`**, que é o que separa valor
 *   DESEJADO de filtro de consulta: toda busca deste pacote passa uma lista de
 *   status, e contar uma consulta como decisão de publicação faria o detector
 *   acusar `get_posts()`.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<int,array{onde:string,nome:string,corpo:string,expr:string}>
 */
function f3b_produtores_de_status_de_pagina( string $raiz ): array {
	$produtores = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( ! preg_match( "/'post_type'\s*=>\s*'page'/", $funcao['corpo'] ) ) {
				continue;
			}

			if ( ! preg_match_all( "/'post_status'\s*=>\s*/", $funcao['corpo'], $ms, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $ms[0] as $m ) {
				$expr = f3b_expressao_de_valor( $funcao['corpo'], (int) $m[1] + strlen( (string) $m[0] ) );

				if ( str_starts_with( $expr, 'array(' ) || str_starts_with( $expr, '[' ) ) {
					continue;
				}

				$produtores[] = array(
					'onde'  => $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()',
					'nome'  => $funcao['nome'],
					'corpo' => $funcao['corpo'],
					'expr'  => $expr,
				);
			}
		}
	}

	return $produtores;
}

/**
 * O status efetivo de página sai de um PRODUTOR SÓ.
 *
 * O DEFEITO MEDIDO NA 1.0.12. A página da política de privacidade nasceu em
 * `draft` porque a configuração declarava `draft`, e a decisão de não publicá-la
 * — tomada pelo pacote, por um motivo real que ninguém tinha ratificado — não
 * aparecia em lugar nenhum do relatório. A correção não foi publicar assim
 * mesmo: foi inverter o ônus como na indexação da 1.0.12. A intenção declarada
 * é produção, e uma GUARDA MEDIDA segura a publicação nomeando a si mesma, as
 * chaves vazias e a saída.
 *
 * Isso só se sustenta com fonte única. Enquanto o status vier de dois lugares —
 * um lendo o declarado, outro escrevendo um literal —, o segundo a rodar
 * contradiz o primeiro, e o relatório sai com duas afirmações verdadeiras sobre
 * o que está publicado. É a mesma família de `estatica.option_fonte_unica`.
 *
 * Três cláusulas, e as três reprovam:
 *
 * 1. **Âncora presente e com alvo.** `produtor_de_status_de_pagina()` precisa
 *    existir e nomear uma função que existe: declaração sem alvo absolve sem
 *    medir, que é pior do que nenhuma declaração.
 * 2. **Um leitor só do caminho declarado, e ele passa pelo produtor.** Duas
 *    funções lendo `paginas.*.status` são duas decisões esperando para divergir.
 * 3. **Todo `post_status` desejado de página chama o produtor.** É a cláusula
 *    que pega o literal `'publish'` escrito direto num `wp_insert_post()`.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_pagina_status_fonte_unica( string $raiz ): array {
	$ancora  = f3b_ancora_mapa( $raiz, 'produtor_de_status_de_pagina' );
	$funcao  = (string) ( $ancora['mapa']['funcao'] ?? '' );
	$caminho = (string) ( $ancora['mapa']['caminho'] ?? '' );

	if ( '' === $ancora['ancora'] || '' === $funcao || '' === $caminho ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função produtor_de_status_de_pagina() declarando "funcao" e "caminho" foi encontrada no '
					. 'código do implantador: sem a âncora que diz QUEM produz o status efetivo de uma página e QUAL '
					. 'caminho da configuração só ele pode ler, não há sobre o que a regra de fonte única valha — e '
					. 'regra sem escopo é regra que nunca acusa nada',
			),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 1;

	if ( ! f3b_funcao_existe( $raiz, $funcao ) ) {
		$achados[] = 'produtor_de_status_de_pagina(), em ' . $ancora['ancora'] . ', aponta o produtor para ' . $funcao
			. '(), que não está definida em lugar nenhum do código do implantador: produtor declarado e ausente é pior '
			. 'que produtor inexistente, porque ele faz o detector calar';
	}

	$leitores = f3b_leitores_de_caminho( $raiz, $caminho );
	$medidas += count( $leitores );

	foreach ( $leitores as $leitor ) {
		if ( $leitor['nome'] === $funcao || str_contains( $leitor['corpo'], $funcao . '(' ) ) {
			continue;
		}

		$achados[] = $leitor['onde'] . ' lê "' . $caminho . '" e NÃO passa por ' . $funcao . '(): quem lê a intenção '
			. 'declarada sem consultar o produtor está decidindo o status de uma página por conta própria, e a decisão '
			. 'que o produtor tomar no mesmo relatório vai contradizê-la';
	}

	if ( count( $leitores ) > 1 ) {
		$achados[] = '"' . $caminho . '" é lido em ' . count( $leitores ) . ' funções: '
			. implode( ' E ', array_map( static fn( array $l ): string => $l['onde'], $leitores ) )
			. ' — a intenção declarada tem um leitor só, que é o produtor; um segundo leitor é a segunda resposta '
			. 'para a mesma pergunta esperando para divergir';
	}

	if ( array() === $leitores ) {
		$achados[] = '"' . $caminho . '", declarado em ' . $ancora['ancora'] . ' como o caminho da intenção de status, '
			. 'não é lido por função nenhuma do implantador: caminho que ninguém lê é a configuração prometendo o que '
			. 'o código não faz, e o produtor passa a decidir sobre um valor que não existe';
	}

	$produtores = f3b_produtores_de_status_de_pagina( $raiz );
	$medidas   += count( $produtores );

	foreach ( $produtores as $produtor ) {
		if ( $produtor['nome'] === $funcao || str_contains( $produtor['corpo'], $funcao . '(' ) ) {
			continue;
		}

		$achados[] = $produtor['onde'] . ' produz o post_status de uma página com «' . $produtor['expr'] . '» sem passar '
			. 'por ' . $funcao . '(): é o segundo lugar decidindo o que este pacote publica, e é por ele que uma página '
			. 'volta a nascer fora do ar sem que uma linha do relatório diga por quê';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}


/* -------------------------------------------------------------------------
 * estatica.llms_so_pagina_publicada
 * ---------------------------------------------------------------------- */

/**
 * Corpo de uma função do implantador, pelo nome, com o arquivo onde ela mora.
 *
 * @param string $raiz Raiz a varrer.
 * @param string $nome Nome da função.
 * @return array{corpo:string,onde:string}|null
 */
function f3b_funcao_do_implantador( string $raiz, string $nome ): ?array {
	if ( '' === $nome ) {
		return null;
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $nome );

		if ( null !== $corpo ) {
			return array(
				'corpo' => $corpo,
				'onde'  => $rel,
			);
		}
	}

	return null;
}

/**
 * Toda seleção de `llms.txt` só nasce de página PUBLICADA — nos DOIS produtores.
 *
 * O DEFEITO MEDIDO NA 1.0.12 e o que sobrou dele na 1.0.13.
 *
 * Na 1.0.12, o item da política era montado de `localizar_gerenciado()` sem
 * conferir o status: com a página em rascunho, `get_permalink()` devolvia o
 * endereço de um rascunho — que só responde a quem está logado e com permissão
 * — e o `llms.txt`, que é público, anunciava aquele endereço como a política do
 * site.
 *
 * A 1.0.13 fechou UM produtor, `f3base_llms`, e deixou o outro passar:
 * `wpseo_llmstxt` continuava recebendo `privacy_policy => <id da página>` sem
 * gate nenhum. O detector prometia, pelo nome, mais do que media — e detector
 * cujo nome promete mais do que ele mede é pior que detector nenhum, porque
 * compra silêncio.
 *
 * O critério NÃO é o que o consumidor de terceiro faz com o identificador de um
 * rascunho. É se este pacote deve entregá-lo a um slot que alimenta arquivo
 * publicado. Não deve, faça o consumidor o que fizer: a escrita está errada na
 * origem.
 *
 * Quatro cláusulas, e as quatro reprovam:
 *
 * 1. **Âncora presente**, declarando o `gate` e ao menos um par
 *    `option => produtor`.
 * 2. **O gate existe e mede o ARTEFATO** — `get_post_status()` contra `publish`.
 *    Gate que não olha o status centraliza a montagem e deixa o defeito onde
 *    estava.
 * 3. **Cada produtor declarado existe e passa pelo gate.**
 * 4. **Quem monta o valor de cada option chama o produtor daquela option, e não
 *    resolve página por fora** — nem `localizar_gerenciado()`, nem
 *    `get_permalink()`, que são os dois caminhos paralelos que devolvem
 *    identificador e endereço sem passar pela conferência de status.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_llms_so_pagina_publicada( string $raiz ): array {
	$ancora  = f3b_ancora_mapa( $raiz, 'produtor_de_item_llms' );
	$gate    = (string) ( $ancora['mapa']['gate'] ?? '' );
	$por_opt = $ancora['mapa'];
	unset( $por_opt['gate'] );

	if ( '' === $ancora['ancora'] || '' === $gate || array() === $por_opt ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função produtor_de_item_llms() declarando "gate" e ao menos um par option => produtor foi '
					. 'encontrada no código do implantador: sem a âncora que diz QUEM mede o status e QUEM monta a '
					. 'seleção de cada option, não há sobre o que a regra valha — e uma âncora que declarasse um '
					. 'produtor só voltaria a prometer, pelo nome, mais do que mede',
			),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 1;

	$corpo_gate = f3b_funcao_do_implantador( $raiz, $gate );

	if ( null === $corpo_gate ) {
		$achados[] = 'produtor_de_item_llms(), em ' . $ancora['ancora'] . ', declara o gate ' . $gate . '(), que não '
			. 'está definido em lugar nenhum do implantador: gate declarado e ausente absolve sem medir';
	} else {
		$medidas++;

		if ( ! str_contains( $corpo_gate['corpo'], 'get_post_status(' ) || ! str_contains( $corpo_gate['corpo'], "'publish'" ) ) {
			$achados[] = $corpo_gate['onde'] . ' ' . $gate . '() é o gate declarado e NÃO confere o status do artefato '
				. '(get_post_status() contra publish): gate que não olha o status centraliza a montagem e deixa o '
				. 'defeito onde estava — o rascunho continua indo para um arquivo público';
		}
	}

	foreach ( $por_opt as $option => $produtor ) {
		$medidas++;
		$corpo_produtor = f3b_funcao_do_implantador( $raiz, $produtor );

		if ( null === $corpo_produtor ) {
			$achados[] = 'produtor_de_item_llms() declara ' . $produtor . '() como produtor de "' . $option . '", e essa '
				. 'função não está definida em lugar nenhum do implantador: produtor declarado e ausente absolve sem medir';
			continue;
		}

		if ( '' !== $gate && ! str_contains( $corpo_produtor['corpo'], $gate . '(' ) ) {
			$achados[] = $corpo_produtor['onde'] . ' ' . $produtor . '(), produtor de "' . $option . '", não passa pelo '
				. 'gate ' . $gate . '(): produtor que resolve a página por conta própria é o segundo lugar decidindo o '
				. 'que vai para um arquivo público';
		}
	}

	$paralelos = array( 'localizar_gerenciado(', 'get_permalink(' );

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $montador ) {
			if ( 'produtor_de_item_llms' === $montador['nome'] || $montador['nome'] === $gate ) {
				continue;
			}

			foreach ( $por_opt as $option => $produtor ) {
				if ( $montador['nome'] === $produtor ) {
					continue;
				}

				/*
				 * As duas formas de PRODUZIR o valor de uma option: o nome dentro
				 * do mapa que um laço grava depois, e o nome entregue direto ao
				 * gravador. Procurar só a primeira enxergaria um produtor onde
				 * há dois — foi assim que o lado do plugin de SEO passou livre.
				 * Montadas por sprintf() porque a seta colada por concatenação
				 * faria `estatica.detector_codigo_em_string` reprovar ESTE
				 * detector.
				 */
				$formas = array(
					sprintf( "/'%s'\s*=>\s*/", preg_quote( (string) $option, '/' ) ),
					sprintf( "/gravar(?:_chaves)?\(\s*'%s'\s*,/", preg_quote( (string) $option, '/' ) ),
				);

				$monta = false;

				foreach ( $formas as $re ) {
					if ( preg_match( $re, $montador['corpo'] ) ) {
						$monta = true;
						break;
					}
				}

				if ( ! $monta ) {
					continue;
				}

				$medidas++;
				$onde = $rel . ':' . $montador['linha'] . ' ' . $montador['nome'] . '()';

				if ( ! str_contains( $montador['corpo'], $produtor . '(' ) ) {
					$achados[] = $onde . ' monta o valor de "' . $option . '" sem chamar ' . $produtor . '(): a seleção '
						. 'volta a ser montada por fora do único ponto que confere se a página está publicada';
				}

				foreach ( $paralelos as $paralelo ) {
					if ( str_contains( $montador['corpo'], $paralelo ) ) {
						$achados[] = $onde . ' resolve página com ' . $paralelo . ') dentro do montador de "' . $option
							. '": é o caminho paralelo que devolve identificador ou endereço sem passar pela '
							. 'conferência de status, e foi exatamente por ele que o rascunho chegou a um arquivo público';
					}
				}
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.politica_privacidade_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * A identidade da política de privacidade tem UM produtor, e ele não depende
 * de chave que não a nomeia.
 *
 * O DEFEITO CORRIGIDO NA 1.0.14. A 1.0.13 acertou em matar o literal
 * `'privacidade' === $ref` espalhado pelas etapas — lista fechada no código
 * decidindo o que a configuração declara — e errou o destino: pendurou a
 * identidade em `seo.llms_selecao.politica_privacidade`, uma chave que nomeia
 * uma seleção de llms.txt.
 *
 * A consequência é medível e é séria. Desligar `bots_ia.llms_txt` e limpar a
 * seleção é operação legítima — o nome da chave convida a ela — e fazia o
 * pacote parar de gravar `wp_page_for_privacy_policy` E derrubava
 * `privacidade.controlador_identificado` em "condição de aplicabilidade falsa".
 * Uma chave de SEO silenciava uma checagem exigida pelo art. 9º da LGPD, sem
 * nada acusar: o pior modo de falha possível, porque o relatório fica verde.
 *
 * O fato passa a morar onde ele se chama pelo próprio nome — `papel` na entrada
 * de `paginas` que descreve a página —, e a regra que impede a recorrência não
 * é o nome da chave: é a CLÁUSULA 3, que proíbe o produtor de ler qualquer
 * caminho fora da raiz declarada.
 *
 * Cinco cláusulas, e as cinco reprovam:
 *
 * 1. **Âncora presente e com alvo**: `produtor_da_politica_de_privacidade()`
 *    declara `funcao`, `papel`, `caminho` e `raiz`, e a função existe.
 * 2. **Um leitor só do caminho do papel**, e ele é o produtor.
 * 3. **O produtor não lê caminho fora da raiz declarada.** É a cláusula que
 *    encoda o defeito: identidade legal pendurada em seção alheia.
 * 4. **O valor do papel não aparece em função nenhuma além do produtor e da
 *    âncora** — senão volta a existir um segundo lugar respondendo QUAL página
 *    é a política.
 * 5. **Ninguém lê o caminho aposentado** `seo.llms_selecao.politica_privacidade`:
 *    a seleção do llms.txt REFERENCIA o produtor, nunca possui o fato.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_politica_privacidade_fonte_unica( string $raiz ): array {
	$ancora  = f3b_ancora_mapa( $raiz, 'produtor_da_politica_de_privacidade' );
	$funcao  = (string) ( $ancora['mapa']['funcao'] ?? '' );
	$papel   = (string) ( $ancora['mapa']['papel'] ?? '' );
	$caminho = (string) ( $ancora['mapa']['caminho'] ?? '' );
	$raiz_ok = (string) ( $ancora['mapa']['raiz'] ?? '' );

	if ( '' === $ancora['ancora'] || '' === $funcao || '' === $papel || '' === $caminho || '' === $raiz_ok ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função produtor_da_politica_de_privacidade() declarando "funcao", "papel", "caminho" e "raiz" '
					. 'foi encontrada no código do implantador: sem a âncora que diz QUEM responde qual página é a '
					. 'política e QUAL raiz de configuração ele tem permissão de ler, a identidade legal volta a poder '
					. 'ser pendurada em qualquer chave, e o relatório continua verde',
			),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 1;

	$produtor = f3b_funcao_do_implantador( $raiz, $funcao );

	if ( null === $produtor ) {
		$achados[] = 'produtor_da_politica_de_privacidade(), em ' . $ancora['ancora'] . ', aponta para ' . $funcao
			. '(), que não está definida em lugar nenhum do implantador: produtor declarado e ausente absolve sem medir';
	} else {
		$medidas++;

		/* CLÁUSULA 3: o produtor só pode ler a raiz declarada. */
		foreach ( f3b_chamadas_regex( $produtor['corpo'], F3B_RE_CONFIG ) as $args ) {
			$lido = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args ) ) );

			if ( '' === $lido || str_starts_with( $lido, '*' ) ) {
				continue;
			}

			if ( $lido === $raiz_ok || str_starts_with( $lido, $raiz_ok . '.' ) ) {
				continue;
			}

			$achados[] = $produtor['onde'] . ' ' . $funcao . '() lê "' . $lido . '", fora da raiz declarada "' . $raiz_ok
				. '": a identidade da política é fato do SITE, exigido pelo art. 9º da LGPD, e pendurá-la em outra seção '
				. 'faz uma chave alheia poder silenciar a checagem legal — desligar aquela seção derruba esta medição '
				. 'sem nada acusar';
		}
	}

	/* CLÁUSULA 2: um leitor só do caminho do papel, e ele é o produtor. */
	$leitores = f3b_leitores_de_caminho( $raiz, $caminho );
	$medidas += count( $leitores );

	foreach ( $leitores as $leitor ) {
		if ( $leitor['nome'] === $funcao ) {
			continue;
		}

		$achados[] = $leitor['onde'] . ' lê "' . $caminho . '" e não é o produtor declarado ' . $funcao . '(): duas '
			. 'funções respondendo QUAL página é a política são duas respostas esperando para divergir';
	}

	if ( array() === $leitores ) {
		$achados[] = '"' . $caminho . '", declarado em ' . $ancora['ancora'] . ' como o caminho do papel, não é lido por '
			. 'função nenhuma do implantador: papel que ninguém lê é a configuração prometendo o que o código não faz';
	}

	/* CLÁUSULA 4: o valor do papel não aparece fora do produtor e da âncora. */
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $f ) {
			if ( $f['nome'] === $funcao || 'produtor_da_politica_de_privacidade' === $f['nome'] ) {
				continue;
			}

			if ( ! str_contains( $f['corpo'], "'" . $papel . "'" ) ) {
				continue;
			}

			$medidas++;
			$achados[] = $rel . ':' . $f['linha'] . ' ' . $f['nome'] . '() traz o literal "' . $papel . '" fora do '
				. 'produtor: é o segundo lugar respondendo qual página é a política, e é por ele que o literal de '
				. 'referência lógica no código volta a decidir o que a configuração declara';
		}
	}

	/* CLÁUSULA 5: o caminho aposentado não tem leitor. */
	$aposentado = 'seo.llms_selecao.politica_privacidade';
	$antigos    = f3b_leitores_de_caminho( $raiz, $aposentado );
	$medidas++;

	foreach ( $antigos as $antigo ) {
		$achados[] = $antigo['onde'] . ' lê "' . $aposentado . '": esse caminho foi APOSENTADO na 1.0.14 porque '
			. 'pendurava a identidade da política numa chave que nomeia uma seleção de llms.txt. A seleção referencia '
			. 'o produtor; ela não possui o fato';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.warn_tem_ramo_adverso
 * ---------------------------------------------------------------------- */

/**
 * Funções pelas quais um estado chega ao relatório do RUNTIME.
 *
 * ÂNCORA declarada num lugar só, como as outras da suíte. O detector abaixo só
 * olha para o literal `WARN` que é ARGUMENTO de uma destas — ou valor de uma
 * chave `'estado'` de array de veredito. Com isso a lista fechada de estados, o
 * mapa de severidade e a constante `const WARN = 'WARN'` ficam fora por
 * construção, sem precisar de exceção por arquivo: eles não emitem nada.
 *
 * @return array<int,string>
 */
function f3b_emissoras_de_estado(): array {
	return array( 'emitir', 'emitir_unidade', 'saida', 'estado', 'estado_mais_severo' );
}

/**
 * Escopo do detector: o RUNTIME do pacote.
 *
 * `includes/` é o implantador; `fontes/` é o tema e o site-core. É esse código
 * que escreve o relatório que o operador lê. A suíte fica fora porque o WARN
 * dela nasce da tabela de ORIGENS (`terceiro` → WARN) em `estado_por_origem()`,
 * que é maquinaria de classificação e não checagem, e porque a sonda funcional
 * PRECISA emitir estados fabricados para exercitar o próprio relatório.
 *
 * @return array<int,string>
 */
function f3b_escopo_de_runtime(): array {
	return array( 'includes/', 'fontes/' );
}

/**
 * Nome da função da chamada que ENVOLVE a posição dada.
 *
 * Sobe pelos parênteses não fechados e devolve o identificador imediatamente
 * anterior ao `(` que abriu a chamada. Vazio quando a posição não está dentro
 * de chamada nenhuma.
 *
 * @param array<int,array{0:int,1:string,2:int}|string> $tokens Tokens.
 * @param int                                           $n      Índice do token.
 * @return string
 */
function f3b_chamada_envolvente( array $tokens, int $n ): string {
	$nivel = 0;

	for ( $i = $n - 1; $i >= 0; $i-- ) {
		$bruto = is_array( $tokens[ $i ] ) ? $tokens[ $i ][1] : $tokens[ $i ];

		if ( ')' === $bruto ) {
			$nivel++;
			continue;
		}

		if ( '(' !== $bruto ) {
			continue;
		}

		if ( $nivel > 0 ) {
			$nivel--;
			continue;
		}

		/* Achou o `(` da chamada que envolve: o nome é o identificador antes. */
		for ( $j = $i - 1; $j >= 0; $j-- ) {
			if ( is_array( $tokens[ $j ] ) && T_WHITESPACE === $tokens[ $j ][0] ) {
				continue;
			}

			return is_array( $tokens[ $j ] ) ? (string) $tokens[ $j ][1] : (string) $tokens[ $j ];
		}

		return '';
	}

	return '';
}

/**
 * Vizinho significativo antes da posição, pulando espaço em branco.
 *
 * @param array<int,array{0:int,1:string,2:int}|string> $tokens Tokens.
 * @param int                                           $n      Índice.
 * @param int                                           $salto  Quantos vizinhos voltar (1 = o imediatamente anterior).
 * @return string
 */
function f3b_vizinho_anterior( array $tokens, int $n, int $salto = 1 ): string {
	$vistos = 0;

	for ( $i = $n - 1; $i >= 0; $i-- ) {
		if ( is_array( $tokens[ $i ] ) && T_WHITESPACE === $tokens[ $i ][0] ) {
			continue;
		}

		$vistos++;

		if ( $vistos >= $salto ) {
			return is_array( $tokens[ $i ] ) ? (string) $tokens[ $i ][1] : (string) $tokens[ $i ];
		}
	}

	return '';
}

/**
 * Todo WARN do runtime mora num ramo que MEDIU alguma coisa.
 *
 * A regra, e o defeito que a produziu. Na execução real da 1.0.14 nove
 * checagens fecharam WARN sem achado adverso nenhum, e cada uma promoveu a
 * unidade dela: `config.schema_declarado` avisando que "a configuração declara
 * o schema e validou contra ele"; `plugins.politica_versao` avisando que a
 * política declarada foi aplicada; `tema.declaracoes` avisando que a lista
 * vazia é estado válido; `preflight.limites` dizendo de si mesma "fato de
 * ambiente, relatado sem decidir gate" e promovendo a unidade assim mesmo.
 * Quatro unidades amarelas numa execução em que nada estava errado — a mesma
 * família da checagem que acusava o próprio pacote e das 24 FALHA por ausência
 * de terceiro. Relatório que grita treina o leitor a ignorar o grito.
 *
 * A correção NÃO é um sétimo estado: os seis são regra do contrato. É a
 * checagem DERIVAR o estado da medição — validou, aplicou, declarou, mediu
 * dentro do esperado fecha OK com o detalhe no texto; mediu algo ADVERSO que
 * não bloqueia fecha WARN nomeando o que está adverso e a consequência.
 *
 * O detector cobra o piso disso, e o piso é sintático porque é o que dá para
 * medir sem executar: **nenhum WARN pode ser retorno incondicional ou único de
 * uma checagem**. Um WARN passa quando está dentro de `if`, `elseif`, `else`,
 * `foreach`, `for`, `while`, `switch`, `match` ou de um ternário — ramo cuja
 * condição mediu alguma coisa — ou quando a função já saiu por uma CLÁUSULA DE
 * GUARDA antes dele: um `return`, `throw` ou `exit` dentro de um ramo, mais
 * acima na mesma função. A guarda é o que torna o WARN nem incondicional (a
 * guarda pode impedi-lo) nem único (a guarda é outra saída). WARN no corpo raso
 * de uma função sem nenhuma das duas coisas é acusado com arquivo, linha e nome
 * da função.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_warn_tem_ramo_adverso( string $raiz ): array {
	$emissoras = f3b_emissoras_de_estado();
	$escopo    = f3b_escopo_de_runtime();
	$achados   = array();
	$medidas   = 0;

	$abre_controle = array( T_IF, T_ELSEIF, T_ELSE, T_FOREACH, T_FOR, T_WHILE, T_DO, T_SWITCH, T_MATCH );

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$dentro = false;

		foreach ( $escopo as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$dentro = true;
				break;
			}
		}

		if ( ! $dentro ) {
			continue;
		}

		$medidas++;

		$tokens = token_get_all( f3b_codigo_php( $raiz . '/' . $rel ) );
		$total  = count( $tokens );

		/*
		 * Pilha de chaves: cada quadro sabe por que foi aberto — `funcao`,
		 * `controle` ou `outro` — e o quadro de função guarda se já houve
		 * cláusula de guarda (saída dentro de ramo) antes da posição atual.
		 */
		$pilha    = array();
		$pendente = '';
		$funcao   = '';
		$ternario = false;

		for ( $n = 0; $n < $total; $n++ ) {
			$token = $tokens[ $n ];

			if ( is_array( $token ) ) {
				if ( T_FUNCTION === $token[0] ) {
					$pendente = 'funcao';
					$funcao   = f3b_nome_da_funcao( $tokens, $n );
					continue;
				}

				if ( in_array( $token[0], $abre_controle, true ) ) {
					$pendente = 'controle';
					continue;
				}

				if ( T_WHITESPACE === $token[0] ) {
					continue;
				}
			}

			$bruto = is_array( $token ) ? $token[1] : $token;

			if ( '{' === $bruto ) {
				$pilha[]  = array(
					'tipo'   => '' !== $pendente ? $pendente : 'outro',
					'guarda' => false,
				);
				$pendente = '';
				continue;
			}

			if ( '}' === $bruto ) {
				array_pop( $pilha );
				continue;
			}

			/* `?` nu é ternário: `??` é T_COALESCE e `?->` é T_NULLSAFE_OBJECT_OPERATOR. */
			if ( '?' === $bruto ) {
				$ternario = true;
				continue;
			}

			if ( ';' === $bruto ) {
				$ternario = false;
				continue;
			}

			/* Quadro de função mais interno, e se estamos dentro de um ramo dele. */
			$nivel_funcao = -1;

			for ( $k = count( $pilha ) - 1; $k >= 0; $k-- ) {
				if ( 'funcao' === $pilha[ $k ]['tipo'] ) {
					$nivel_funcao = $k;
					break;
				}
			}

			$em_ramo = false;

			for ( $k = $nivel_funcao + 1; $k < count( $pilha ); $k++ ) {
				if ( 'controle' === $pilha[ $k ]['tipo'] ) {
					$em_ramo = true;
					break;
				}
			}

			/*
			 * CLÁUSULA DE GUARDA: saída dentro de um ramo. Quem sai ali pode
			 * impedir que o resto da função rode, e é isso que faz o que vem
			 * depois deixar de ser incondicional.
			 */
			if ( is_array( $token ) && in_array( $token[0], array( T_RETURN, T_THROW, T_EXIT ), true ) && $em_ramo && $nivel_funcao >= 0 ) {
				$pilha[ $nivel_funcao ]['guarda'] = true;
				continue;
			}

			$e_warn = ( is_array( $token ) && T_STRING === $token[0] && 'WARN' === $token[1] && '::' === f3b_vizinho_anterior( $tokens, $n ) )
				|| ( is_array( $token ) && T_CONSTANT_ENCAPSED_STRING === $token[0] && in_array( trim( $token[1], "'\"" ), array( 'WARN' ), true ) );

			if ( ! $e_warn ) {
				continue;
			}

			/* Posição de EMISSÃO: argumento de emissora, ou valor de `'estado' =>`. */
			$chamada  = f3b_chamada_envolvente( $tokens, $n );
			$por_seta = '=>' === f3b_vizinho_anterior( $tokens, $n ) && in_array( trim( f3b_vizinho_anterior( $tokens, $n, 2 ), "'\"" ), array( 'estado' ), true );

			if ( ! in_array( $chamada, $emissoras, true ) && ! $por_seta ) {
				continue;
			}

			if ( $em_ramo || $ternario ) {
				continue;
			}

			if ( $nivel_funcao >= 0 && $pilha[ $nivel_funcao ]['guarda'] ) {
				continue;
			}

			/*
			 * A linha vai como `%s` de propósito: `%d` colado a um nome de
			 * estado é exatamente o padrão que `estatica.contagem_com_nomes`
			 * acusa, e um detector novo não pode nascer disparando outro.
			 */
			$achados[] = sprintf(
				'%s:%s — o estado adverso é retorno incondicional de %s(), fora de qualquer ramo e sem cláusula de guarda antes dele. '
					. 'Todo aviso mora num ramo cuja condição mediu alguma coisa: medição sem achado adverso fecha OK com o detalhe no texto, '
					. 'e aviso que sai sempre treina o operador a ignorar aviso.',
				$rel,
				(string) ( is_array( $token ) ? (int) $token[2] : 0 ),
				'' !== $funcao ? $funcao : '(escopo de arquivo)'
			);
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Nome da função declarada no token `T_FUNCTION` da posição.
 *
 * @param array<int,array{0:int,1:string,2:int}|string> $tokens Tokens.
 * @param int                                           $n      Índice do T_FUNCTION.
 * @return string
 */
function f3b_nome_da_funcao( array $tokens, int $n ): string {
	$total = count( $tokens );

	for ( $i = $n + 1; $i < $total; $i++ ) {
		if ( is_array( $tokens[ $i ] ) && T_WHITESPACE === $tokens[ $i ][0] ) {
			continue;
		}

		if ( is_array( $tokens[ $i ] ) && T_STRING === $tokens[ $i ][0] ) {
			return (string) $tokens[ $i ][1];
		}

		return '';
	}

	return '';
}

/* -------------------------------------------------------------------------
 * plugins.serie_de_backup_normalizada
 * ---------------------------------------------------------------------- */

/**
 * Nomes de cópia preservada medidos, e a série que cada um pertence.
 *
 * TABELA ÚNICA: o runner e o piso leem esta mesma lista, e o que muda entre
 * eles é só a implementação que a atende. Os nomes são montados a partir das
 * constantes do pacote — nunca escritos por extenso, porque um literal com a
 * marca sem o ponto na frente é exatamente o que `pacote.backup_sempre_oculto`
 * proíbe, e com razão.
 *
 * O segundo caso é o NOME MEDIDO NO SITE REAL depois da 1.0.14: backup de um
 * diretório que já era backup.
 *
 * @param string $prefixo Prefixo de construção (`PREFIXO_BACKUP`).
 * @param string $marca   Marca de reconhecimento (`MARCA_ANTERIOR`).
 * @param string $slug    Slug do artefato.
 * @return array<int,array{rotulo:string,nome:string,slug:string,quando:int}>
 */
function f3b_series_de_backup_medidas( string $prefixo, string $marca, string $slug ): array {
	return array(
		array(
			'rotulo' => 'cópia simples',
			'nome'   => $prefixo . $slug . '-1788152131',
			'slug'   => $slug,
			'quando' => 1788152131,
		),
		array(
			'rotulo' => 'cópia de cópia, o nome medido no site',
			'nome'   => $prefixo . $slug . $marca . '1788152131-1788156801',
			'slug'   => $slug,
			'quando' => 1788156801,
		),
		array(
			'rotulo' => 'aninhamento duplo',
			'nome'   => $prefixo . $prefixo . $slug . $marca . '1788152131-1788156801-1788160000',
			'slug'   => $slug,
			'quando' => 1788160000,
		),
		array(
			'rotulo' => 'plugin de terceiro',
			'nome'   => $prefixo . 'wordpress-seo-1788100000',
			'slug'   => 'wordpress-seo',
			'quando' => 1788100000,
		),
	);
}

/**
 * A chave da série colapsa a marca de backup embutida.
 *
 * O DEFEITO MEDIDO, com o nome literal que estava em `wp-content/plugins/`:
 * `.f3base-anterior-f3base-site-core-f3base-anterior-1788152131-1788156801` —
 * backup de um diretório que já era backup. Cortando o slug no último traço, a
 * chave virava `f3base-site-core-f3base-anterior-1788152131`: série PRÓPRIA,
 * com uma cópia só, que nunca alcança o teto de 2 e portanto nunca poda. O log
 * fechou com sete cópias preservadas e a frase "nada acima do teto" — cada
 * palavra verdadeira e a conclusão errada.
 *
 * Roda a MESMA função do runtime — `F3Base_Imp_Plugins::serie_do_nome()` — em
 * SUBPROCESSO, pela mesma razão de `estatica.plano_dependencias`: o piso a
 * executa duas vezes, contra a fixture com o corte ingênuo e contra a correta, e
 * duas declarações da mesma classe no mesmo processo seriam erro fatal.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_serie_de_backup( string $raiz, string $suite ): array {
	$arquivo = $raiz . '/includes/class-f3base-imp-plugins.php';
	$sonda   = $suite . '/lib/sonda-serie.php';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'includes/class-f3base-imp-plugins.php ausente na raiz varrida: sem ele não existe função de série a exercitar' ),
			'medidas' => 1,
		);
	}

	$marcas = f3b_linhas_da_sonda( $sonda, $arquivo, array() );

	if ( 1 !== count( $marcas ) || 2 > count( $marcas[0] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'as marcas de cópia preservada não puderam ser lidas em subprocesso: ' . f3b_amostra( array_map( 'implode', $marcas ), 2 ) ),
			'medidas' => 1,
		);
	}

	$casos = f3b_series_de_backup_medidas( $marcas[0][0], $marcas[0][1], 'base-site-core-fator3' );
	$fora  = array( 'base-site-core-fator3', 'wordpress-seo', $marcas[0][0], $marcas[0][0] . 'semcarimbo' );

	$nomes = array_merge( array_map( static fn( array $c ): string => $c['nome'], $casos ), $fora );
	$lidas = array();

	foreach ( f3b_linhas_da_sonda( $sonda, $arquivo, $nomes ) as $linha ) {
		$lidas[ (string) ( $linha[0] ?? '' ) ] = array(
			'slug'   => (string) ( $linha[1] ?? '' ),
			'quando' => (int) ( $linha[2] ?? 0 ),
		);
	}

	if ( count( $lidas ) !== count( array_unique( $nomes ) ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'a sonda da série devolveu ' . count( $lidas ) . ' linha(s) para ' . count( array_unique( $nomes ) ) . ' nome(s) medido(s)' ),
			'medidas' => 1,
		);
	}

	$achados   = array();
	$agrupadas = array();

	foreach ( $casos as $caso ) {
		$slug   = (string) ( $lidas[ $caso['nome'] ]['slug'] ?? '' );
		$quando = (int) ( $lidas[ $caso['nome'] ]['quando'] ?? 0 );

		if ( $slug !== $caso['slug'] ) {
			$achados[] = $caso['rotulo'] . ': ' . $caso['nome'] . ' caiu na série "' . ( '' !== $slug ? $slug : '(nenhuma)' )
				. '" e a série do artefato real é "' . $caso['slug'] . '" — série fantasma nunca alcança o teto declarado e portanto nunca poda';
		}

		if ( $quando !== $caso['quando'] ) {
			$achados[] = $caso['rotulo'] . ': o carimbo lido foi ' . $quando
				. ' e o carimbo EXTERNO, que é quando esta cópia foi criada, é ' . $caso['quando'];
		}

		if ( '' !== $slug ) {
			$agrupadas[ $slug ] = ( $agrupadas[ $slug ] ?? 0 ) + 1;
		}
	}

	if ( 2 !== count( $agrupadas ) ) {
		$achados[] = 'as ' . count( $casos ) . ' cópias medidas produziram ' . count( $agrupadas )
			. ' série(s) e precisam produzir 2: o artefato do pacote, com três cópias, e o plugin de terceiro, com uma';
	}

	if ( 3 !== ( $agrupadas['base-site-core-fator3'] ?? 0 ) ) {
		$achados[] = 'a série do artefato do pacote ficou com ' . (string) ( $agrupadas['base-site-core-fator3'] ?? 0 )
			. ' cópia(s) e precisa ficar com 3 — é essa contagem que o teto de plugins.backups_preservados compara';
	}

	foreach ( $fora as $nome ) {
		if ( '' !== (string) ( $lidas[ $nome ]['slug'] ?? '' ) ) {
			$achados[] = 'piso do falso positivo: "' . $nome . '" não é cópia preservada deste pacote e virou série assim mesmo';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $casos ) + count( $fora ),
	);
}

/**
 * Roda a sonda de série e devolve as linhas do TSV já separadas.
 *
 * @param string            $sonda   Caminho da sonda.
 * @param string            $arquivo Classe a carregar.
 * @param array<int,string> $nomes   Nomes a medir; vazio pede as marcas.
 * @return array<int,array<int,string>>
 */
function f3b_linhas_da_sonda( string $sonda, string $arquivo, array $nomes ): array {
	$comando = 'php ' . escapeshellarg( $sonda ) . ' ' . escapeshellarg( $arquivo );

	foreach ( $nomes as $nome ) {
		$comando .= ' ' . escapeshellarg( (string) $nome );
	}

	$saida  = array();
	$estado = 0;
	exec( $comando . ' 2>&1', $saida, $estado );

	if ( 0 !== $estado ) {
		return array();
	}

	$linhas = array();

	foreach ( $saida as $linha ) {
		if ( '' === trim( (string) $linha ) ) {
			continue;
		}

		$linhas[] = explode( "\t", (string) $linha );
	}

	return $linhas;
}

/* -------------------------------------------------------------------------
 * estatica.troca_invalida_cache
 * ---------------------------------------------------------------------- */

/**
 * A INVALIDAÇÃO DE CACHE PERTENCE A QUEM TROCOU O DIRETÓRIO.
 *
 * O DEFEITO MEDIDO, e ele custou uma instalação limpa inteira na 1.0.15.
 * `Theme_Upgrader::install()` chama `wp_clean_themes_cache()` e
 * `Plugin_Upgrader::install()` chama `wp_clean_plugins_cache()`. A troca
 * controlada de diretório do pacote não passa pelo upgrader e não chamava nem
 * um nem outro — `wp_clean_themes_cache` não aparecia UMA VEZ no pacote. Num
 * WordPress recém-criado a etapa consulta o estado antes da troca, o núcleo
 * memoriza o NEGATIVO na mesma requisição, a troca acontece, e a leitura de
 * volta relê o cache: a unidade fechava FALHA dizendo "não apareceu no disco"
 * sobre um diretório que estava lá, enquanto outra unidade da MESMA rodada
 * enumerava o artefato entre os instalados.
 *
 * Por que a regra é "de quem trocou" e não "de quem chamou": há TRÊS chamadores
 * da troca — tema, site-core e embarcado —, e chamador que esquece é o defeito
 * voltando. A regra, executável:
 *
 * 1. a âncora do pacote declara trocador, invalidador, leitura de volta e as
 *    duas funções de limpeza do núcleo;
 * 2. o corpo do trocador chama o invalidador;
 * 3. o corpo do invalidador chama as DUAS limpezas declaradas;
 * 4. toda função que chama o trocador também chama a leitura de volta
 *    declarada — reler o estado por fora dela é reintroduzir a mensagem que
 *    confunde disco com cache.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_troca_invalida_cache( string $raiz ): array {
	$ancora = f3b_ancora_mapa( $raiz, 'troca_de_diretorio_declarada' );
	$mapa   = $ancora['mapa'];

	if ( array() === $mapa ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função troca_de_diretorio_declarada() foi encontrada no código: sem a âncora que nomeia '
					. 'quem troca o diretório, quem invalida o cache e quem relê o artefato, esta regra não tem o que medir — '
					. 'e foi a ausência dela que deixou a troca de diretório atravessar quinze releases sem derrubar cache nenhum',
			),
			'medidas' => 1,
		);
	}

	$trocador    = (string) ( $mapa['trocador'] ?? '' );
	$invalidador = (string) ( $mapa['invalidador'] ?? '' );
	$leitura     = (string) ( $mapa['leitura'] ?? '' );
	$limpezas    = array_values( array_filter( array( (string) ( $mapa['tema'] ?? '' ), (string) ( $mapa['plugin'] ?? '' ) ) ) );

	$achados = array();
	$medidas = 0;

	foreach ( array( 'trocador' => $trocador, 'invalidador' => $invalidador, 'leitura' => $leitura ) as $papel => $nome ) {
		++$medidas;

		if ( '' === $nome ) {
			$achados[] = 'a âncora em ' . $ancora['ancora'] . ' não declara o papel "' . $papel . '"';
			continue;
		}

		if ( ! f3b_funcao_existe( $raiz, $nome ) ) {
			$achados[] = 'a âncora em ' . $ancora['ancora'] . ' declara ' . $papel . ' = ' . $nome . '() e essa função não existe no pacote: declaração que absolve sem medir é pior que nenhuma';
		}
	}

	++$medidas;

	if ( array() === $limpezas ) {
		$achados[] = 'a âncora em ' . $ancora['ancora'] . ' não declara as funções de limpeza do núcleo (tema e plugin)';
	}

	/* 2 e 3: o trocador chama o invalidador, e o invalidador chama as limpezas. */
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		$corpo_trocador = '' === $trocador ? null : f3b_corpo_de_funcao( $src, $trocador );

		if ( null !== $corpo_trocador ) {
			++$medidas;

			if ( ! str_contains( $corpo_trocador, $invalidador . '(' ) ) {
				$achados[] = $rel . ': ' . $trocador . '() troca o diretório e NÃO chama ' . $invalidador
					. '(): o cache do núcleo continua respondendo pelo estado anterior, e a leitura de volta de uma '
					. 'instalação limpa relê o negativo que a consulta prévia memorizou';
			}
		}

		$corpo_invalidador = '' === $invalidador ? null : f3b_corpo_de_funcao( $src, $invalidador );

		if ( null !== $corpo_invalidador ) {
			foreach ( $limpezas as $limpeza ) {
				++$medidas;

				if ( ! str_contains( $corpo_invalidador, $limpeza . '(' ) ) {
					$achados[] = $rel . ': ' . $invalidador . '() não chama ' . $limpeza
						. '(), que é a limpeza que o upgrader do núcleo faz para este tipo de artefato';
				}
			}
		}

		/* 4: quem chama o trocador passa pela leitura de volta declarada. */
		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( $funcao['nome'] === $trocador || '' === $trocador ) {
				continue;
			}

			if ( ! str_contains( $funcao['corpo'], $trocador . '(' ) ) {
				continue;
			}

			++$medidas;

			if ( ! str_contains( $funcao['corpo'], $leitura . '(' ) ) {
				$achados[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '() chama ' . $trocador
					. '() e NÃO passa por ' . $leitura . '(): a leitura de volta por fora dela volta a dizer '
					. '"não apareceu no disco" sobre diretório que está no disco, que é o relatório que mandou o operador procurar no lugar errado';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.artefato_do_pacote_e_lido
 * ---------------------------------------------------------------------- */

/**
 * Prefixos de zip embutido, lidos da constante do PRÓPRIO pacote.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{prefixos:array<int,string>,ancora:string}
 */
function f3b_prefixos_de_zip( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( 1 !== preg_match( '/const\s+PREFIXOS_DE_ZIP\s*=\s*array\(([^)]*)\)/', $src, $m ) ) {
			continue;
		}

		preg_match_all( "/'([^']*)'/", $m[1], $ms );

		return array(
			'prefixos' => array_values( array_unique( $ms[1] ) ),
			'ancora'   => $rel,
		);
	}

	return array(
		'prefixos' => array(),
		'ancora'   => '',
	);
}

/**
 * ARTEFATO QUE VIAJA NO PACOTE E NINGUÉM LÊ É DEFEITO.
 *
 * O DEFEITO MEDIDO, da 1.0.14 à 1.0.15: o empacotamento montava `f3base.zip`
 * (27.607 bytes) e `f3base-site-core.zip` (76.414 bytes) e os copiava para a
 * RAIZ do bundle. Nenhum caminho de instalação os abria — a resolução de zip
 * embutido só procura sob os prefixos declarados, e a instalação de tema e
 * site-core lê `fontes/`. Eram 104.021 bytes dentro do hash do pacote servindo
 * de PROVA FALSA DE ENTREGA: um relatório podia dizer "o tema viaja no pacote"
 * apontando para um artefato que a instalação nunca abriria.
 *
 * Duas medições:
 *
 * 1. todo `.zip` que viaja no pacote está sob um dos prefixos que a constante
 *    do pacote declara — fora deles, ninguém o lê;
 * 2. quem INSTALA e quem PROVA o entregável passam pelo MESMO resolvedor, e
 *    nenhum dos dois monta caminho de artefato por conta própria. Foi a segunda
 *    lista, escrita à mão em `F3Base_Imp_Entrega`, que fez o entregável provar
 *    um artefato enquanto a instalação usava outro.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_artefato_do_pacote_e_lido( string $raiz ): array {
	$zip    = f3b_prefixos_de_zip( $raiz );
	$ancora = f3b_ancora_mapa( $raiz, 'artefato_fonte_unica_declarada' );

	$achados = array();
	$medidas = 0;

	++$medidas;

	if ( array() === $zip['prefixos'] ) {
		$achados[] = 'nenhuma constante PREFIXOS_DE_ZIP foi encontrada no código: sem a lista declarada de onde um zip '
			. 'embutido pode estar, não há como dizer se um artefato do pacote é lido por alguém';
	}

	/* 1: todo zip do pacote sob um prefixo declarado. */
	foreach ( f3b_arquivos( $raiz, array( 'zip' ), f3b_excluidos() ) as $rel ) {
		++$medidas;

		$sob_prefixo = false;

		foreach ( $zip['prefixos'] as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) && ! str_contains( substr( $rel, strlen( $prefixo ) ), '/' ) ) {
				$sob_prefixo = true;
				break;
			}
		}

		if ( ! $sob_prefixo ) {
			$achados[] = $rel . ': artefato instalável viaja no pacote e NENHUM caminho de instalação o lê — a resolução '
				. 'de zip embutido só procura em ' . implode( ', ', $zip['prefixos'] ) . ' (declarado em ' . $zip['ancora'] . '). '
				. 'Peso morto que ainda por cima serve de prova falsa de entrega: ou ele é ligado ao caminho que instala, ou para de viajar';
		}
	}

	/* 2: quem instala e quem prova passam pelo mesmo resolvedor. */
	++$medidas;

	if ( array() === $ancora['mapa'] ) {
		$achados[] = 'nenhuma função artefato_fonte_unica_declarada() foi encontrada no código: sem a âncora que nomeia '
			. 'o resolvedor, quem instala e quem prova, a fonte única não é verificável';

		return array(
			'ok'      => array() === $achados,
			'achados' => $achados,
			'medidas' => $medidas,
		);
	}

	$resolvedor = (string) ( $ancora['mapa']['resolvedor'] ?? '' );
	$obrigadas  = array();

	foreach ( array( 'instala', 'prova' ) as $papel ) {
		foreach ( explode( ',', (string) ( $ancora['mapa'][ $papel ] ?? '' ) ) as $nome ) {
			$nome = trim( $nome );

			if ( '' !== $nome ) {
				$obrigadas[ $nome ] = $papel;
			}
		}
	}

	++$medidas;

	if ( '' === $resolvedor || ! f3b_funcao_existe( $raiz, $resolvedor ) ) {
		$achados[] = 'a âncora em ' . $ancora['ancora'] . ' declara resolvedor = ' . $resolvedor . '() e essa função não existe no pacote';
	}

	$vistas = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( $obrigadas as $nome => $papel ) {
			$corpo = f3b_corpo_de_funcao( $src, $nome );

			if ( null === $corpo ) {
				continue;
			}

			$vistas[ $nome ] = true;
			++$medidas;

			if ( '' !== $resolvedor && ! str_contains( $corpo, $resolvedor . '(' ) ) {
				$achados[] = $rel . ': ' . $nome . '() (' . $papel . ') não passa por ' . $resolvedor
					. '(): quem instala e quem prova o entregável precisam ler o MESMO artefato, ou o relatório prova um e a instalação usa outro';
			}

			if ( 1 === preg_match( "/'[^']*\\.zip'/", $corpo ) || 1 === preg_match( "/'fontes\\/[^']*'/", $corpo ) ) {
				$achados[] = $rel . ': ' . $nome . '() (' . $papel . ') monta caminho de artefato por conta própria — '
					. 'a segunda lista é o defeito, e é ela que produz entregável provado num caminho e instalação feita em outro';
			}
		}
	}

	foreach ( $obrigadas as $nome => $papel ) {
		++$medidas;

		if ( ! isset( $vistas[ $nome ] ) ) {
			$achados[] = 'a âncora em ' . $ancora['ancora'] . ' declara ' . $papel . ' = ' . $nome . '() e essa função não existe no pacote';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.resposta_de_lote_nomeada
 * ---------------------------------------------------------------------- */

/**
 * TODA RESPOSTA DE LOTE É NOMEADA E FECHA NUM ESTADO.
 *
 * O DEFEITO MEDIDO na 1.0.15: a rejeição de lock voltava como
 * `{ok:false, estado:BLOCKED, motivo:"…"}` — sem `rotulo` e sem `aplicacao`. Na
 * tela, 163 linhas anônimas: o rodapé dizia "linhas desta tela: 163 BLOCKED" e,
 * na lista por nome do MESMO escopo, "BLOCKED: nenhum"; e `estado da aplicação:`
 * saía vazio, que não é estado fechado.
 *
 * A regra: toda resposta que a tela renderiza traz as chaves que a âncora do
 * pacote declara, e o emissor só recebe carga do produtor declarado ou do
 * produtor de reserva — que é o único lugar onde uma resposta "não rodou" é
 * montada.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_resposta_de_lote_nomeada( string $raiz ): array {
	$ancora = f3b_ancora_mapa( $raiz, 'resposta_declarada' );

	if ( array() === $ancora['mapa'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função resposta_declarada() foi encontrada no código: sem a âncora que nomeia o emissor, o '
					. 'produtor e as chaves obrigatórias, não há como cobrar que a linha da tela tenha nome e estado fechado',
			),
			'medidas' => 1,
		);
	}

	$emissor  = (string) ( $ancora['mapa']['emissor'] ?? '' );
	$produtor = (string) ( $ancora['mapa']['produtor'] ?? '' );
	$reserva  = (string) ( $ancora['mapa']['reserva'] ?? '' );
	$exigidas = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $ancora['mapa']['exigidas'] ?? '' ) ) ) ) );

	$achados = array();
	$medidas = 0;

	++$medidas;

	if ( array() === $exigidas ) {
		$achados[] = 'a âncora em ' . $ancora['ancora'] . ' não declara nenhuma chave obrigatória na resposta do lote';
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src   = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = '' === $produtor ? null : f3b_corpo_de_funcao( $src, $produtor );

		if ( null !== $corpo ) {
			foreach ( f3b_retornos_de_array( $corpo ) as $retorno ) {
				++$medidas;

				if ( ! str_contains( $retorno, "'estado'" ) ) {
					continue;
				}

				foreach ( $exigidas as $chave ) {
					if ( ! str_contains( $retorno, "'" . $chave . "'" ) ) {
						$achados[] = $rel . ': ' . $produtor . '() devolve uma resposta com estado e SEM a chave "' . $chave
							. '" — linha sem rótulo sai anônima da tela e a contagem por estado fica sem a lista de nomes; '
							. 'resposta sem estado da aplicação fecha o rodapé em branco, e vazio não é estado fechado. '
							. 'Resposta que não rodou se monta em ' . $reserva . '()';
					}
				}
			}
		}

		/* O emissor só recebe carga do produtor declarado ou do de reserva. */
		if ( '' === $emissor || ! str_contains( $src, $emissor . '(' ) ) {
			continue;
		}

		if ( null === f3b_corpo_de_funcao( $src, $emissor ) ) {
			continue;
		}

		foreach ( f3b_chamadas_de( $src, $emissor ) as $chamada ) {
			++$medidas;

			if ( str_contains( $chamada, $produtor . '(' ) || str_contains( $chamada, $reserva . '(' ) ) {
				continue;
			}

			$achados[] = $rel . ': ' . $emissor . '() recebe uma carga montada fora de ' . $produtor . '() e de '
				. $reserva . '(): resposta montada à mão volta a sair sem nome e sem estado da aplicação — '
				. 'trecho: ' . trim( preg_replace( '/\s+/', ' ', mb_substr( $chamada, 0, 90 ) ) ?? '' );
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Blocos `return array( … );` de um corpo de função, com parênteses balanceados.
 *
 * @param string $corpo Corpo já sem comentário.
 * @return array<int,string>
 */
function f3b_retornos_de_array( string $corpo ): array {
	$saida = array();
	$pos   = 0;

	while ( true ) {
		$inicio = strpos( $corpo, 'return array(', $pos );

		if ( false === $inicio ) {
			return $saida;
		}

		$abre = strpos( $corpo, '(', $inicio );

		if ( false === $abre ) {
			return $saida;
		}

		$saida[] = f3b_bloco_balanceado( $corpo, $abre );
		$pos     = $abre + 1;
	}
}

/**
 * Chamadas de uma função pelo nome, com os argumentos balanceados.
 *
 * @param string $src  Código já sem comentário.
 * @param string $nome Nome da função.
 * @return array<int,string>
 */
function f3b_chamadas_de( string $src, string $nome ): array {
	$saida = array();
	$pos   = 0;
	$alvo  = '::' . $nome . '(';

	while ( true ) {
		$inicio = strpos( $src, $alvo, $pos );

		if ( false === $inicio ) {
			return $saida;
		}

		$abre    = $inicio + strlen( $alvo ) - 1;
		$saida[] = f3b_bloco_balanceado( $src, $abre );
		$pos     = $abre + 1;
	}
}

/**
 * O trecho entre um `(` e o `)` que o fecha.
 *
 * @param string $src Código.
 * @param int    $pos Posição do parêntese de abertura.
 * @return string
 */
function f3b_bloco_balanceado( string $src, int $pos ): string {
	$nivel = 0;
	$tam   = strlen( $src );

	for ( $i = $pos; $i < $tam; $i++ ) {
		if ( '(' === $src[ $i ] ) {
			++$nivel;
		}

		if ( ')' === $src[ $i ] ) {
			--$nivel;

			if ( 0 === $nivel ) {
				return substr( $src, $pos, $i - $pos + 1 );
			}
		}
	}

	return substr( $src, $pos );
}

/* -------------------------------------------------------------------------
 * estatica.identidade_do_implantador
 * ---------------------------------------------------------------------- */

/**
 * O CONTEÚDO ENTREGUE DECLARA AS SEÇÕES QUE O SITE MEDE.
 *
 * POR QUE ESTA CHECAGEM EXISTE. `f3base_secao_vista` é um dos seis eventos
 * declarados do pacote, é dirigido por rolagem como o de profundidade — que
 * funciona — e ficou com ZERO LINHA no site do usuário. A causa, medida: o
 * coletor só observa elemento que carrega a classe `f3base-secao-<nome>`, a
 * classe existia apenas nos PATTERNS do tema — modelos que uma pessoa insere à
 * mão no editor — e nenhuma das páginas entregues a carregava. O observador era
 * instalado, não recebia alvo nenhum, e o evento não podia disparar em site
 * nenhum construído por este pacote.
 *
 * Um evento declarado que nunca dispara em nenhum site entregue é um evento que
 * não existe: ele ocupa linha na declaração, coluna no relatório e espaço na
 * tela, e responde sempre a mesma coisa — nada. Ou o conteúdo do template o
 * alimenta, ou ele sai da declaração.
 *
 * A regra vale para o CONTEÚDO PUBLICADO, e não para os patterns: são os
 * arquivos de `content/` que viram as páginas do site.
 *
 * @param string $raiz Raiz varrida.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_conteudo_declara_secoes( string $raiz ): array {
	$prefixo = 'f3base-secao-';
	$achados = array();
	$medidas = 0;

	$paginas = glob( $raiz . '/content/pages/*.html' ) ?: array();

	++$medidas;

	if ( array() === $paginas ) {
		return array(
			'ok'      => false,
			'achados' => array( 'nenhuma página em content/pages/ na raiz varrida: sem conteúdo entregue não há o que medir' ),
			'medidas' => $medidas,
		);
	}

	$nomes_vistos = array();

	foreach ( $paginas as $arquivo ) {
		$curto = str_replace( $raiz . '/', '', $arquivo );
		$fonte = (string) file_get_contents( $arquivo );

		++$medidas;

		preg_match_all( '/' . preg_quote( $prefixo, '/' ) . '([a-z0-9-]+)/', $fonte, $marcados );

		$nomes = array_values( array_unique( $marcados[1] ) );

		if ( array() === $nomes ) {
			$achados[] = $curto . ': nenhuma seção medida declarada. O coletor de seção vista observa quem carrega a classe '
				. $prefixo . '<nome>, e uma página sem nenhuma não dá alvo nenhum ao observador — o evento declarado nunca dispara, '
				. 'e a linha dele no relatório responde "nada" para sempre';

			continue;
		}

		foreach ( $nomes as $nome ) {
			$nomes_vistos[ $nome ] = true;
		}

		/*
		 * A CLASSE PRECISA CHEGAR AO DOM, e não só ao atributo do bloco. O
		 * WordPress só imprime `className` no HTML servido quando ele está no
		 * comentário do bloco E na `<div>`: escrito num só dos dois, o editor
		 * reescreve o outro na primeira edição e a marca some sem aviso.
		 */
		foreach ( $nomes as $nome ) {
			$marca = $prefixo . $nome;

			$no_comentario = preg_match( '/<!-- wp:[a-z\/-]+ \{[^\n]*"className":"[^"]*' . preg_quote( $marca, '/' ) . '[^"]*"/', $fonte );
			$na_div        = preg_match( '/<div class="[^"]*' . preg_quote( $marca, '/' ) . '[^"]*"/', $fonte );

			++$medidas;

			if ( 1 !== $no_comentario || 1 !== $na_div ) {
				$achados[] = $curto . ': a seção "' . $nome . '" aparece em um só lugar ('
					. ( 1 === $no_comentario ? 'atributo do bloco' : 'classe da div' )
					. '). O WordPress só serve a classe quando ela está nos DOIS: escrita em um só, o editor reescreve o outro na '
					. 'primeira edição e a marca de medição some sem aviso nenhum';
			}
		}
	}

	++$medidas;

	/*
	 * NOME REPETIDO ENTRE PÁGINAS É LEGÍTIMO — "faq" existe em mais de uma —,
	 * mas um nome só é útil se distinguir alguma coisa. Uma entrega em que
	 * TODAS as seções têm o mesmo nome não mede seção nenhuma.
	 */
	if ( count( $nomes_vistos ) < 2 ) {
		$achados[] = 'o conteúdo entregue usa ' . count( $nomes_vistos ) . ' nome(s) de seção distinto(s) em todas as páginas: '
			. 'sem nomes que distingam, o evento de seção vista responde a mesma coisa em toda página e não mede nada';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * TODO EMISSOR LIGADO A MAIS DE UM EVENTO DE SAÍDA TEM TRAVA DE UMA VEZ.
 *
 * POR QUE ESTA CHECAGEM EXISTE. Sair de uma página não é um evento: numa
 * navegação normal o navegador emite `visibilitychange` para hidden E
 * `pagehide`, no mesmo carregamento. Os dois ouvintes existem de propósito —
 * há navegador em que só um deles dispara, e remover um perde a sessão inteira
 * ali. A duplicidade é a resposta certa; o que ela exige é que a FUNÇÃO
 * chamada pelos dois só faça o trabalho uma vez.
 *
 * Sem essa disciplina, cada métrica entra duas vezes no resumo da sessão, o
 * resumo é despachado uma vez só, e o relatório mostra o dobro do que
 * aconteceu — sem erro em lugar nenhum, sem log, sem nada a estranhar exceto
 * um número que parece bom demais.
 *
 * A REGRA É ESTRUTURAL, e é por isso que ela é detector e não revisão: quem
 * escrever o próximo coletor vai ligá-lo aos dois eventos, porque é o certo, e
 * a trava é fácil de esquecer. A varredura acha os alvos dos ouvintes de saída
 * e exige de cada um uma bandeira que ele testa e levanta.
 *
 * @param string $raiz Raiz varrida.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
/**
 * Delimita o corpo de um callback JS; strings e comentários não fecham o escopo.
 *
 * @param string $fonte Código JavaScript.
 * @param int    $abre Posição da chave de abertura.
 * @return string|null
 */
function f3b_corpo_callback_js( string $fonte, int $abre ): ?string {
	$nivel = 0;
	$aspas = '';
	$comentario = '';
	$limite = strlen( $fonte );
	for ( $i = $abre; $i < $limite; ++$i ) {
		$atual = $fonte[ $i ];
		$proximo = $i + 1 < $limite ? $fonte[ $i + 1 ] : '';
		if ( 'linha' === $comentario ) {
			if ( "\n" === $atual ) { $comentario = ''; }
			continue;
		}
		if ( 'bloco' === $comentario ) {
			if ( '*' === $atual && '/' === $proximo ) { $comentario = ''; ++$i; }
			continue;
		}
		if ( '' !== $aspas ) {
			if ( '\\' === $atual ) { ++$i; continue; }
			if ( $aspas === $atual ) { $aspas = ''; }
			continue;
		}
		if ( '/' === $atual && '/' === $proximo ) { $comentario = 'linha'; ++$i; continue; }
		if ( '/' === $atual && '*' === $proximo ) { $comentario = 'bloco'; ++$i; continue; }
		if ( '"' === $atual || "'" === $atual || '`' === $atual ) { $aspas = $atual; continue; }
		if ( '{' === $atual ) { ++$nivel; }
		if ( '}' === $atual && 0 === --$nivel ) { return substr( $fonte, $abre + 1, $i - $abre - 1 ); }
	}
	return null;
}

function f3b_ck_saida_com_trava_de_uma_vez( string $raiz ): array {
	$achados = array();
	$medidas = 0;
	$alvos   = array();

	foreach ( glob( $raiz . '/fontes/plugin/assets/*.js' ) ?: array() as $arquivo ) {
		$fonte = (string) file_get_contents( $arquivo );
		$curto = str_replace( $raiz . '/', '', $arquivo );

		/*
		 * OS DOIS EVENTOS DE SAÍDA, e só eles: `pagehide` e o
		 * `visibilitychange` que testa `hidden`. `beforeunload` não entra
		 * porque este pacote não o usa e não deve — ele quebra o cache de
		 * retrocesso do navegador em troca de nada que os outros dois não
		 * deem.
		 */
		preg_match_all( "/addEventListener\(\s*'pagehide'\s*,\s*([A-Za-z_\$][A-Za-z0-9_\$]*)\s*\)/", $fonte, $diretos );

		foreach ( $diretos[1] as $alvo ) {
			$alvos[ $curto . '::' . $alvo ] = array( $curto, $alvo, 'pagehide' );
		}

		/* Delimitar o callback impede que um ouvinte curto capture funções vizinhas. */
		if ( preg_match_all( "/addEventListener\(\s*'visibilitychange'\s*,\s*function\s*\([^)]*\)\s*\{/", $fonte, $anonimos, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $anonimos[0] as $cabecalho ) {
				$abre = (int) $cabecalho[1] + strlen( $cabecalho[0] ) - 1;
				$corpo = f3b_corpo_callback_js( $fonte, $abre );
				if ( null === $corpo || ! str_contains( $corpo, 'hidden' ) ) {
					continue;
				}

				// Chamadas de métodos auxiliares não são funções locais de despacho.
				preg_match_all( '/(?<![.A-Za-z0-9_$])([A-Za-z_$][A-Za-z0-9_$]*)\(\s*\)/', $corpo, $chamados );
				foreach ( $chamados[1] as $alvo ) {
					if ( in_array( $alvo, array( 'if', 'for', 'while', 'switch', 'function', 'return' ), true ) ) {
						continue;
					}
					$alvos[ $curto . '::' . $alvo ] = array( $curto, $alvo, 'visibilitychange' );
				}
			}
		}
	}

	++$medidas;

	/*
	 * NENHUM ALVO É ACHADO ADVERSO, e sai nomeado: um cliente que deixou de
	 * ouvir a saída da página deixou de despachar a sessão, e o relatório fica
	 * vazio sem que nada acuse. A regra vale nos dois sentidos.
	 */
	if ( array() === $alvos ) {
		return array(
			'ok'      => false,
			'achados' => array( 'nenhum ouvinte de saída de página encontrado em fontes/plugin/assets/*.js — sem eles a sessão nunca é despachada, e a tabela do resumo fica vazia para sempre' ),
			'medidas' => $medidas,
		);
	}

	foreach ( $alvos as $registro ) {
		list( $curto, $alvo ) = $registro;

		++$medidas;

		$fonte = (string) file_get_contents( $raiz . '/' . $curto );

		if ( 1 !== preg_match( '/function\s+' . preg_quote( $alvo, '/' ) . '\s*\([^)]*\)\s*\{/', $fonte, $cabecalho, PREG_OFFSET_CAPTURE ) ) {
			$achados[] = $curto . ': o ouvinte de saída aponta para "' . $alvo
				. '", e não há função com esse nome no arquivo — ouvinte que aponta para o que não existe não despacha nada';

			continue;
		}

		/*
		 * O CORPO É DELIMITADO POR CHAVES, e não por um número de caracteres.
		 * Uma janela fixa transborda para a função seguinte e passa a enxergar
		 * a trava do vizinho — foi assim que a primeira versão deste detector
		 * absolveu um relator sem trava porque o despachante logo abaixo tinha
		 * a dele. Detector que lê fora do escopo mede outra coisa.
		 */
		$abre = (int) $cabecalho[0][1] + strlen( $cabecalho[0][0] ) - 1;
		$corpo = f3b_corpo_callback_js( $fonte, $abre );
		if ( null === $corpo ) {
			$achados[] = $curto . ': corpo do ouvinte "' . $alvo . '" não pôde ser delimitado';
			continue;
		}

		/*
		 * A TRAVA É UMA BANDEIRA QUE A FUNÇÃO TESTA E LEVANTA. Testar sem
		 * levantar não trava nada, e levantar sem testar também não: as duas
		 * metades são exigidas, e sobre a MESMA bandeira.
		 */
		$tem_trava = false;

		/*
		 * A CONDIÇÃO PODE SER COMPOSTA, e a trava continua valendo: o despachante
		 * do resumo sai por `resumoEnviado` OU por não haver destino, numa
		 * condição só. Exigir a bandeira sozinha reprovaria a trava correta e
		 * ensinaria a contorná-la — que é o pior desfecho possível para um
		 * detector. O que se exige é a bandeira TESTADA em alguma saída e
		 * LEVANTADA no corpo; as duas metades, sobre o mesmo nome.
		 */
		if ( preg_match_all( '/if\\s*\\(([^)]*)\\)\\s*\\{\\s*return;/', $corpo, $testadas ) ) {
			foreach ( $testadas[1] as $condicao ) {
				preg_match_all( '/[A-Za-z_$][A-Za-z0-9_$]*/', $condicao, $identificadores );

				foreach ( $identificadores[0] as $bandeira ) {
					if ( preg_match( '/\\b' . preg_quote( $bandeira, '/' ) . '\\s*=\\s*true\\s*;/', $corpo ) ) {
						$tem_trava = true;
						break 2;
					}
				}
			}
		}

		if ( ! $tem_trava ) {
			$achados[] = $curto . ': "' . $alvo . '" está ligada a evento de saída de página e NÃO tem guarda de reentrância —'
				. ' ela precisa testar uma bandeira, sair se ela estiver levantada, e levantá-la. Numa navegação normal o navegador'
				. ' emite visibilitychange para hidden E pagehide no mesmo carregamento, e sem a guarda o mesmo trabalho é feito'
				. ' duas vezes.'
				. ' A GUARDA NÃO É TRAVA PERMANENTE: quem despacha o lote a levanta durante o envio e a BAIXA depois, porque'
				. ' visibilitychange dispara toda vez que a aba perde o foco, e uma trava que nunca baixa deixa a página surda'
				. ' pelo resto da visita — foi assim que visitas inteiras registraram só o primeiro segundo de cada página.'
				. ' O que impede o reenvio ali é o lote esvaziado, e não a bandeira. Quem relata valor final único por'
				. ' carregamento — as medidas de carregamento — mantém a trava permanente, e é a exceção declarada.';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * A RELEASE ATUAL DECLARA A ANTERIOR na matriz de origens suportadas?
 *
 * POR QUE ESTA CHECAGEM EXISTE. A 1.3.2 foi cortada com a matriz parada na
 * 1.1.5. No site do usuário, rodando 1.3.1, `preflight.contrato_de_caminho`
 * fechou FALHA — "a release aplicada neste site não consta da lista fechada de
 * origens aceitas" —, a unidade preflight foi promovida e 39 unidades foram
 * suspensas: o site não recebeu nada. Nada estava quebrado no site; o que
 * faltava era uma linha de três colunas num arquivo nosso.
 *
 * Acrescentar a linha que faltava conserta uma release. Esta checagem conserta
 * o processo: nenhuma release passa pelo build sem declarar de onde sabe subir,
 * e a cobrança sai do site do cliente e volta para a nossa bancada, que é onde
 * um esquecimento nosso deve doer.
 *
 * A REGRA, e ela não envelhece. A maior origem declarada para o componente
 * `implantador` tem de ser ADJACENTE à identidade da release: a identidade é
 * exatamente um passo de patch, de minor ou de major acima dela. Adjacência é a
 * única definição de "a anterior" que se sustenta sem um segundo arquivo de
 * histórico para manter — e ela pega o caso real: de 1.1.5 nenhum passo leva a
 * 1.3.2, e a matriz teria acusado a lacuna já na 1.3.0.
 *
 * @param string $raiz Raiz varrida.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_release_declara_a_anterior( string $raiz ): array {
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou inválido na raiz varrida: sem release.identidade não há o que confrontar com a matriz' ),
			'medidas' => 0,
		);
	}

	$identidade = (string) ( $config['release']['identidade'] ?? '' );
	$achados    = array();
	$medidas    = 0;

	++$medidas;

	if ( 1 !== preg_match( '/^\d+\.\d+\.\d+$/', $identidade ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'release.identidade "' . $identidade . '" não tem a forma X.Y.Z: sem ela não há passo a medir contra a matriz' ),
			'medidas' => $medidas,
		);
	}

	$declaradas = array();

	foreach ( f3b_tsv( $raiz . '/config/releases-suportadas.tsv' ) as $linha ) {
		$componente = trim( (string) ( $linha[0] ?? '' ) );
		$versao     = trim( (string) ( $linha[1] ?? '' ) );

		if ( 'implantador' !== $componente || 1 !== preg_match( '/^\d+\.\d+\.\d+$/', $versao ) ) {
			continue;
		}

		$declaradas[] = $versao;
	}

	++$medidas;

	if ( array() === $declaradas ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'config/releases-suportadas.tsv não declara NENHUMA origem do componente implantador: toda instalação que não seja limpa chega a este pacote como origem não suportada',
			),
			'medidas' => $medidas,
		);
	}

	/*
	 * A ORDENAÇÃO COMPARA COM OPERADOR EXPLÍCITO. `version_compare()` de dois
	 * argumentos devolve int e serviria aqui, mas o detector do contrato recusa
	 * a forma sem operador — e ele está certo: é a mesma chamada que, usada em
	 * contexto booleano, devolve -1 e 0 onde alguém esperava true e false.
	 */
	usort(
		$declaradas,
		static function ( string $a, string $b ): int {
			if ( version_compare( $a, $b, '<' ) ) {
				return -1;
			}

			return version_compare( $a, $b, '>' ) ? 1 : 0;
		}
	);

	$maior = (string) end( $declaradas );

	++$medidas;

	if ( version_compare( $maior, $identidade, '>=' ) ) {
		$achados[] = 'a maior origem declarada é ' . $maior . ' e a identidade desta release é ' . $identidade
			. ': a matriz não pode conter a própria release nem uma posterior a ela — origem é de onde se SOBE, e ninguém sobe do lugar onde já está';
	}

	++$medidas;

	$partes = array_map( 'intval', explode( '.', $maior ) );

	$adjacentes = array(
		$partes[0] . '.' . $partes[1] . '.' . ( $partes[2] + 1 ),
		$partes[0] . '.' . ( $partes[1] + 1 ) . '.0',
		( $partes[0] + 1 ) . '.0.0',
	);

	if ( version_compare( $maior, $identidade, '<' ) && ! in_array( $identidade, $adjacentes, true ) ) {
		$achados[] = 'a maior origem declarada é ' . $maior . ' e esta release é ' . $identidade
			. ': há um vão entre as duas, e toda versão dentro dele chega ao site como origem NÃO SUPORTADA — foi assim que a 1.3.2 não instalou nada num site que rodava 1.3.1. '
			. 'Acrescente a linha que falta em config/releases-suportadas.tsv, com a determinação que a sustenta. '
			. 'Passos aceitos a partir de ' . $maior . ': ' . implode( ', ', $adjacentes );
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * A IDENTIDADE da release é a mesma nos três lugares que a carregam.
 *
 * O defeito que produziu este detector foi medido na 1.0.17, e ele é do mesmo
 * tipo que o carimbo velho em documento entregável — só que pior, porque o
 * `MANIFESTO.md` afirmava, em linha própria, que "`release.identidade` e o
 * cabeçalho do implantador são a mesma coisa" e NENHUMA checagem media isso. A
 * afirmação era verdadeira por hábito: alguém lembrava de bumpar o cabeçalho a
 * cada release. Na 1.0.17 o `config/site.json` foi para `1.0.17` e o cabeçalho
 * ficou em `1.0.16`, com a constante de bootstrap ainda em `1.0.15` — três
 * respostas para "qual release é esta?", e o relatório do site imprimiria a do
 * cabeçalho, que é a que o WordPress mostra na lista de plugins.
 *
 * Os três lugares, e por que cada um existe:
 *
 * - `release.identidade` e `release.implantador` em `config/site.json` — o que
 *   o pacote DECLARA ser.
 * - `Version:` no cabeçalho de `implantador-base.php` — o que o WordPress LÊ, e
 *   a fonte de verdade em execução (`f3base_imp_versao()` a prefere).
 * - `F3BASE_IMP_VERSAO_DECLARADA` — o fallback de bootstrap, usado antes de
 *   `get_plugin_data()` existir. Divergir dele é o caso medido em 3.0.4: a
 *   constante fica para trás e o número que aparece antes do admin carregar não
 *   é o da release.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_identidade_do_implantador( string $raiz ): array {
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou inválido na raiz varrida: sem release.identidade não há identidade a conferir' ),
			'medidas' => 0,
		);
	}

	$arquivo = $raiz . '/implantador-base.php';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'implantador-base.php ausente na raiz varrida: o cabeçalho que o WordPress lê não existe' ),
			'medidas' => 0,
		);
	}

	$fonte      = (string) file_get_contents( $arquivo );
	$declarada  = (string) ( $config['release']['identidade'] ?? '' );
	$implantada = (string) ( $config['release']['implantador'] ?? '' );
	$achados    = array();
	$medidas    = 0;

	++$medidas;

	if ( '' === $declarada ) {
		$achados[] = 'config/site.json não declara release.identidade';
	}

	++$medidas;

	if ( '' !== $declarada && $implantada !== $declarada ) {
		$achados[] = 'release.implantador ("' . $implantada . '") diverge de release.identidade ("' . $declarada
			. '"): nesta base os dois são o mesmo número, e duas respostas para a mesma pergunta é o defeito que a identidade única existe para impedir';
	}

	++$medidas;

	if ( 1 !== preg_match( '/^\s*\*\s*Version:\s*(\S+)\s*$/mi', $fonte, $cabecalho ) ) {
		$achados[] = 'implantador-base.php sem cabeçalho Version: — é ele que o WordPress mostra na lista de plugins e o que f3base_imp_versao() prefere';
	} elseif ( '' !== $declarada && $cabecalho[1] !== $declarada ) {
		$achados[] = 'o cabeçalho Version: de implantador-base.php é "' . $cabecalho[1] . '" e release.identidade é "' . $declarada
			. '": o número que o WordPress mostra não é o da release que o pacote declara ser';
	}

	++$medidas;

	if ( 1 !== preg_match( "/define\(\s*'F3BASE_IMP_VERSAO_DECLARADA'\s*,\s*'([^']+)'\s*\)/", $fonte, $constante ) ) {
		$achados[] = 'implantador-base.php não define F3BASE_IMP_VERSAO_DECLARADA: sem o fallback de bootstrap, a versão fica indefinida antes de get_plugin_data() existir';
	} elseif ( '' !== $declarada && $constante[1] !== $declarada ) {
		$achados[] = 'F3BASE_IMP_VERSAO_DECLARADA é "' . $constante[1] . '" e release.identidade é "' . $declarada
			. '": o fallback de bootstrap ficou para trás, e é ele que responde antes do admin carregar';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.sem_recusa_de_escrita_do_agente
 * ---------------------------------------------------------------------- */

/**
 * Proteção MCP específica de propriedade, com a API de configuração do dono disponível.
 *
 * Mantém o identificador histórico do detector. O plano da release autoriza o
 * filtro real do conector, usando exclusivamente proprias() e preservando a
 * lista recebida. Filtros supostos, guarda por prefixo e bloqueio global de
 * update_option continuam sendo defeitos. A execução real das duas APIs é
 * coberta em suite/versao-110/abilities.php e mcp-options.php.
 */
function f3b_ck_sem_recusa_de_escrita_do_agente( string $raiz ): array {
	$achados = array(); $medidas = 0;
	$escopo = f3b_escopo_de_runtime();
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$dentro = false;
		foreach ( $escopo as $prefixo ) { if ( str_starts_with( $rel, $prefixo ) ) { $dentro = true; break; } }
		if ( ! $dentro ) { continue; }
		$medidas++; $src = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = f3b_corpo_de_funcao( $src, 'proteger_options' );
		$registro = f3b_corpo_de_funcao( $src, 'registrar_protecao' );
		$callback_ok = false;
		if ( null !== $corpo && preg_match( '/function\s+proteger_options\s*\(\s*(?:array\s+)?(\$[A-Za-z_][A-Za-z0-9_]*)/', $src, $parametro ) ) {
			// Gramática limitada de retorno: nenhuma escrita, literal de option ou condição por prefixo.
			$expr = preg_replace( '/\s+/', '', $corpo );
			if ( preg_match( '/^return(.+);$/D', (string) $expr, $retorno ) ) {
				$expr = $retorno[1];
				while ( preg_match( '/^array_(?:values|unique)\((.*)\)$/D', $expr, $envoltoria ) ) { $expr = $envoltoria[1]; }
				$lista = $parametro[1]; $guardada = 'is_array(' . $lista . ')?' . $lista . ':array()';
				$callback_ok = in_array( $expr, array( 'array_merge(' . $lista . ',F3Base_Options::proprias())', 'array_merge(' . $guardada . ',F3Base_Options::proprias())' ), true );
			}
		}
		$registro_ok = null !== $registro && preg_match( "/add_filter\s*\(\s*'wp_mcp_ultimate_protected_options'\s*,\s*array\s*\(\s*__CLASS__\s*,\s*'proteger_options'\s*\)\s*,\s*10\s*,\s*2\s*\)/", $registro );
		$api = f3b_corpo_de_funcao( $src, 'escrever' );
		$api_ok = null !== $api && preg_match( '/F3Base_Options\s*::\s*gravar\s*\(/', $api );
		foreach ( token_get_all( '<?php ' . $src ) as $token ) {
			if ( ! is_array( $token ) || T_CONSTANT_ENCAPSED_STRING !== $token[0] ) { continue; }
			$literal = trim( (string) $token[1], "'\"" );
			if ( ! preg_match( '/[A-Za-z0-9_]*(?:protected_options|options_protegidas)[A-Za-z0-9_]*/i', $literal ) ) { continue; }
			if ( 'wp_mcp_ultimate_protected_options' !== $literal || ! $registro_ok || ! $callback_ok || ! $api_ok ) {
				$achados[] = $rel . ':' . $token[2] . ' guarda MCP fora do contrato: use somente o filtro real, mescle a lista recebida com F3Base_Options::proprias() e mantenha a escrita pela fachada disponível.';
			}
		}
		if ( preg_match( "/add_filter\s*\(\s*['\"]pre_update_option['\"]/", $src ) ) {
			$achados[] = $rel . ' registra bloqueio global de update_option: a proteção pertence ao canal genérico MCP e à lista fechada do catálogo.';
		}
	}
	return array( 'ok' => array() === $achados, 'achados' => $achados, 'medidas' => $medidas );
}

/* -------------------------------------------------------------------------
 * estatica.segredo_fora_da_configuracao
 * ---------------------------------------------------------------------- */

/**
 * As options declaradas como SEGREDO, lidas da âncora do próprio pacote.
 *
 * A lista sai do pacote, nunca da suíte: escrevê-la aqui seria a segunda fonte
 * para o mesmo fato, e acrescentar um segredo passaria a exigir editar dois
 * lugares — que é como um deles fica para trás.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{nomes:array<int,string>,ancora:string}
 */
function f3b_segredos_declarados( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), 'segredos_do_site' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([A-Za-z_][A-Za-z0-9_]*)'/", $corpo, $ms );

		return array(
			'nomes'  => array_values( array_unique( $ms[1] ) ),
			'ancora' => $rel,
		);
	}

	return array(
		'nomes'  => array(),
		'ancora' => '',
	);
}

/**
 * SEGREDO DO SITE NÃO VIAJA NO PACOTE — nem no arquivo único, nem no schema.
 *
 * POR QUE ESTE DETECTOR EXISTE. `config/site.json` viaja dentro do zip: a suíte
 * o lê, o empacotador o embute, o bundle vai para quem faz o upload, e a cópia
 * fica no repositório de artefatos. Um token de acesso declarado ali é um token
 * copiado para todo lugar por onde o pacote passou — e a cópia sobrevive a
 * qualquer rotação da credencial, porque ninguém volta ao zip para apagá-la.
 *
 * A DECISÃO É "DECLARAR POR AUSÊNCIA", e ausência sem detector é só esquecimento
 * com boa intenção. Este detector é o que dá dentes a ela, medindo três coisas
 * por segredo declarado:
 *
 * 1. o nome não aparece em `config/site.json`;
 * 2. o nome não aparece em `config/site.schema.json` — schema que conhece a
 *    chave é convite para preenchê-la;
 * 3. NENHUMA linha do implantador o grava. O implantador escreve a partir do
 *    arquivo único; se ele grava um segredo, o segredo veio de algum lugar que
 *    viaja no pacote.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_segredo_fora_da_configuracao( string $raiz ): array {
	$declarados = f3b_segredos_declarados( $raiz );

	if ( array() === $declarados['nomes'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função segredos_do_site() foi encontrada no pacote: sem a âncora que declara QUAIS options são segredo do site, '
					. 'não há sobre o que a regra valer — e uma regra sem escopo nunca acusa nada',
			),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 0;

	$config = (string) @file_get_contents( $raiz . '/config/site.json' );
	$schema = (string) @file_get_contents( $raiz . '/config/site.schema.json' );

	$escritas = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'fontes/', 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! preg_match_all( '/(?:Gravador::(?:gravar|gravar_chaves|persistir_infra|criar_atomico|trocar_atomico)|update_option|add_option|update_site_option)\s*\(\s*\'([A-Za-z_][A-Za-z0-9_]*)\'/s', $src, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		foreach ( $ms as $m ) {
			$escritas[ $m[1] ][ $rel ] = true;
		}
	}

	foreach ( $declarados['nomes'] as $segredo ) {
		++$medidas;

		if ( str_contains( $config, $segredo ) ) {
			$achados[] = 'config/site.json menciona "' . $segredo . '", declarada como SEGREDO DO SITE em ' . $declarados['ancora']
				. ': o arquivo único viaja dentro do zip, é lido pela suíte e chega a quem faz o upload — segredo em arquivo que viaja é segredo copiado, '
				. 'e a cópia sobrevive à rotação da credencial porque ninguém volta ao zip para apagá-la';
		}

		++$medidas;

		if ( str_contains( $schema, $segredo ) ) {
			$achados[] = 'config/site.schema.json menciona "' . $segredo . '", declarada como SEGREDO DO SITE em ' . $declarados['ancora']
				. ': schema que conhece a chave é convite para preenchê-la, e o preenchimento é que põe o segredo no pacote';
		}

		++$medidas;

		if ( isset( $escritas[ $segredo ] ) ) {
			$achados[] = 'o implantador GRAVA "' . $segredo . '" em ' . implode( ', ', array_keys( $escritas[ $segredo ] ) )
				. ', e ela é declarada como SEGREDO DO SITE em ' . $declarados['ancora'] . ': o implantador escreve a partir do arquivo único, '
				. 'então um segredo que ele grava veio de algum lugar que viaja no pacote. Quem grava segredo é o agente, pelo canal';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* =========================================================================
 * tracking.emissor_unico_discrimina
 *
 * O BURACO QUE ESTA REGRA FECHA, dito com a medida que o abriu.
 * `tracking.caminho_unico` prova que o módulo não emite pelos DOIS caminhos
 * dele mesmo — container × direto. Ela não vê um emissor DE FORA. Um plugin de
 * console imprimindo `gtag.js` ao lado do `site-core` é contagem em dobro que
 * nenhuma configuração declarou, e conversão em dobro reescreve o lance do
 * leilão.
 *
 * O DISCRIMINANTE, e ele é a metade que faz a regra existir: "handle" NÃO
 * EXISTE no HTML servido. O que existe é o `id` que o WordPress imprime a
 * partir do handle — `id="<handle>-js"` para `wp_enqueue_script` e
 * `id="<handle>-js-extra"`/`-before`/`-after` para o inline —, e o `id` que o
 * carregador do `site-core` põe em cada tag que ele cria no navegador. Sem essa
 * marca a checagem não consegue separar a emissão do pacote da emissão de fora,
 * e aprova por acaso.
 *
 * As duas marcas saem MEDIDAS das fontes, nunca escritas aqui: o handle vem da
 * constante do módulo, os ids do navegador vêm das chamadas de `inserir()` no
 * carregador. Trocar o prefixo do template muda as duas ao mesmo tempo.
 *
 * AS DUAS SUPERFÍCIES SÃO DIFERENTES, e isto foi MEDIDO neste pacote:
 *
 * - `servido` — o que a rota de origem e uma requisição externa devolvem. Aqui
 *   o `site-core` emite UM script: o carregador, marcado. Ele NÃO imprime
 *   `gtag/js`, `gtm.js`, `fbevents.js` nem `insight.min.js` no HTML — as quatro
 *   tags são criadas no navegador, por `document.createElement('script')` em
 *   `assets/f3base-tracking.js`. Logo, no HTML servido a contagem marcada de
 *   carregador de fornecedor é ZERO, e QUALQUER carregador de fornecedor ali é
 *   emissão de fora.
 * - `renderizado` — o DOM depois do JavaScript. Aqui as tags do `site-core`
 *   existem, cada uma com o `id` que o carregador lhe deu, e a contagem
 *   esperada é a que o caminho e os slots determinam.
 * ====================================================================== */

/**
 * As MARCAS do site-core, medidas nas fontes dele.
 *
 * @param string $raiz Raiz varrida.
 * @return array{ids:string[],handle:string,origens:array<string,string>,faltou:string[]}
 */
function f3b_marcas_do_site_core( string $raiz ): array {
	$php = $raiz . '/fontes/plugin/includes/class-f3base-modulo-tracking.php';
	$js  = $raiz . '/fontes/plugin/assets/f3base-tracking.js';

	$ids     = array();
	$handle  = '';
	$origens = array();
	$faltou  = array();

	if ( is_file( $php ) ) {
		$fonte = (string) file_get_contents( $php );

		if ( 1 === preg_match( "/const\s+HANDLE\s*=\s*'([^']+)'/", $fonte, $m ) ) {
			$handle = $m[1];

			/* As quatro formas que o núcleo dá ao id a partir de um handle. */
			foreach ( array( '-js', '-js-extra', '-js-before', '-js-after', '-js-translations' ) as $sufixo ) {
				$ids[] = $handle . $sufixo;
			}
		} else {
			$faltou[] = 'a constante HANDLE não foi encontrada em class-f3base-modulo-tracking.php: sem ela não há marca de enfileiramento a procurar no HTML';
		}

		foreach ( array( 'ORIGEM_GOOGLE', 'ORIGEM_META', 'ORIGEM_LINKEDIN' ) as $constante ) {
			if ( 1 === preg_match( '/const\s+' . $constante . "\s*=\s*'([^']+)'/", $fonte, $m ) ) {
				$origens[ $constante ] = $m[1];
			} else {
				$faltou[] = 'a constante ' . $constante . ' não foi encontrada: sem ela a origem do fornecedor seria literal desta checagem';
			}
		}
	} else {
		$faltou[] = 'fontes/plugin/includes/class-f3base-modulo-tracking.php ausente na raiz varrida';
	}

	if ( is_file( $js ) ) {
		$fonte = (string) file_get_contents( $js );

		if ( 0 === preg_match_all( "/inserir\(\s*'([^']+)'/", $fonte, $m ) ) {
			$faltou[] = 'nenhuma chamada de inserir() com id literal em assets/f3base-tracking.js: sem elas as tags criadas no navegador não teriam marca nenhuma';
		}

		foreach ( (array) ( $m[1] ?? array() ) as $id ) {
			$ids[] = (string) $id;
		}
	} else {
		$faltou[] = 'fontes/plugin/assets/f3base-tracking.js ausente na raiz varrida';
	}

	return array(
		'ids'     => array_values( array_unique( $ids ) ),
		'handle'  => $handle,
		'origens' => $origens,
		'faltou'  => $faltou,
	);
}

/**
 * O caminho de emissão a partir dos slots — a MESMA regra do módulo.
 *
 * @param array<string,string> $slots Slots preenchidos.
 * @return string gtm, direto ou nenhum.
 */
function f3b_caminho_de_emissao( array $slots ): string {
	if ( '' !== (string) ( $slots['gtm'] ?? '' ) ) {
		return 'gtm';
	}

	foreach ( $slots as $valor ) {
		if ( '' !== (string) $valor ) {
			return 'direto';
		}
	}

	return 'nenhum';
}

/**
 * Quantos carregadores de fornecedor o MÓDULO emite, por superfície.
 *
 * Espelha `carregarGtm()`, `carregarGoogleDireto()`, `carregarMeta()` e
 * `carregarLinkedin()` do carregador. Na superfície `servido` a resposta é
 * ZERO para os quatro, e não por convenção: nenhuma das quatro é impressa no
 * HTML — todas nascem de `document.createElement('script')`.
 *
 * @param array<string,string> $slots      Slots preenchidos.
 * @param string               $superficie servido ou renderizado.
 * @return array<string,int>
 */
function f3b_emissao_esperada_do_site_core( array $slots, string $superficie ): array {
	$zero = array( 'gtag/js' => 0, 'gtm.js' => 0, 'fbevents.js' => 0, 'insight.min.js' => 0 );

	if ( 'servido' === $superficie ) {
		return $zero;
	}

	$caminho = f3b_caminho_de_emissao( $slots );

	if ( 'gtm' === $caminho ) {
		return array_merge( $zero, array( 'gtm.js' => 1 ) );
	}

	if ( 'direto' !== $caminho ) {
		return $zero;
	}

	return array(
		'gtag/js'        => ( '' !== (string) ( $slots['ga4'] ?? '' ) || '' !== (string) ( $slots['ads_id'] ?? '' ) ) ? 1 : 0,
		'gtm.js'         => 0,
		'fbevents.js'    => '' !== (string) ( $slots['meta'] ?? '' ) ? 1 : 0,
		'insight.min.js' => '' !== (string) ( $slots['linkedin_partner'] ?? '' ) ? 1 : 0,
	);
}

/**
 * Todo `<script>` do HTML, com o `src`, o `id` e o corpo inline.
 *
 * @param string $html HTML medido.
 * @return array<int,array{src:string,id:string,corpo:string}>
 */
function f3b_scripts_do_html( string $html ): array {
	$saida = array();

	/*
	 * A expressão é montada por PEDAÇOS pela mesma razão que a de
	 * `f3b_ck_codigo_em_string()`: escrita inteira, ela conteria o próprio
	 * marcador que aquele detector procura, e a suíte reprovaria a si mesma.
	 */
	$re_script = '#<' . 'script\b([^>]*)>(.*?)</' . 'script>#is';

	if ( 0 === preg_match_all( $re_script, $html, $todos, PREG_SET_ORDER ) ) {
		return $saida;
	}

	foreach ( $todos as $script ) {
		$atributos = (string) $script[1];
		$src       = '';
		$id        = '';

		if ( 1 === preg_match( '/\bsrc\s*=\s*(["\'])(.*?)\1/i', $atributos, $m ) ) {
			$src = (string) $m[2];
		}

		if ( 1 === preg_match( '/\bid\s*=\s*(["\'])(.*?)\1/i', $atributos, $m ) ) {
			$id = (string) $m[2];
		}

		$saida[] = array(
			'src'   => $src,
			'id'    => $id,
			'corpo' => (string) $script[2],
		);
	}

	return $saida;
}

/**
 * O VEREDITO do emissor único sobre um HTML — função pura.
 *
 * Os quatro ramos, e cada um sai NOMEANDO quem emitiu:
 *
 * 1. contagem MARCADA diferente da que o módulo emite → FALHA (o próprio
 *    pacote emitindo duas vezes, ou deixando de emitir o que declarou);
 * 2. carregador de fornecedor SEM marca, com algum slot preenchido → FALHA,
 *    nomeando o emissor do pacote e o de fora;
 * 3. carregador de fornecedor sem marca, com TODOS os slots vazios → WARN,
 *    nomeando o emissor: não é dobro, é medição fora do `site-core`, e sob a
 *    premissa do agente a decisão é do projeto;
 * 4. `gtag("config", …)` inline em script sem marca → FALHA: a configuração da
 *    conta é a metade que decide para onde a medição vai.
 *
 * @param string               $html       HTML medido.
 * @param string               $rotulo     Nome do que foi medido, para o achado.
 * @param array<int,string>    $marcas     Ids que só o site-core usa.
 * @param array<string,string> $origens    Origens declaradas pelo módulo.
 * @param array<string,string> $slots      Slots preenchidos.
 * @param string               $superficie servido ou renderizado.
 * @return array{estado:string,achados:array<int,string>}
 */
function f3b_veredito_emissor_unico( string $html, string $rotulo, array $marcas, array $origens, array $slots, string $superficie ): array {
	$google   = (string) ( $origens['ORIGEM_GOOGLE'] ?? '' );
	$meta     = (string) ( $origens['ORIGEM_META'] ?? '' );
	$linkedin = (string) ( $origens['ORIGEM_LINKEDIN'] ?? '' );

	$fornecedores = array(
		'gtag/js'        => $google . 'gtag/js',
		'gtm.js'         => $google . 'gtm.js',
		'fbevents.js'    => $meta,
		'insight.min.js' => $linkedin,
	);

	$esperado = f3b_emissao_esperada_do_site_core( $slots, $superficie );
	$caminho  = f3b_caminho_de_emissao( $slots );
	$marcado  = array_fill_keys( array_keys( $fornecedores ), 0 );
	$de_fora  = array();
	$nossos   = array();
	$achados  = array();

	foreach ( f3b_scripts_do_html( $html ) as $script ) {
		$e_nosso = '' !== $script['id'] && in_array( $script['id'], $marcas, true );

		foreach ( $fornecedores as $vendor => $prefixo ) {
			if ( '' === $prefixo || ! str_starts_with( $script['src'], $prefixo ) ) {
				continue;
			}

			if ( $e_nosso ) {
				++$marcado[ $vendor ];
				$nossos[] = $vendor . ' com a marca id="' . $script['id'] . '"';
				continue;
			}

			$de_fora[] = $vendor . ' em ' . $script['src'] . ' '
				. ( '' === $script['id'] ? 'SEM atributo id' : 'com id="' . $script['id'] . '", que não é marca do site-core' );
		}

		/* Ramo 4: a configuração da conta vindo de emissão que não é a nossa. */
		if ( ! $e_nosso && '' === $script['src'] && 1 === preg_match( '/gtag\s*\(\s*(["\'])config\1/', $script['corpo'] ) ) {
			$de_fora[] = 'gtag("config", …) inline '
				. ( '' === $script['id'] ? 'SEM atributo id' : 'com id="' . $script['id'] . '"' )
				. ': a configuração da conta decide para onde a medição vai, e ela não saiu do site-core';
		}
	}

	foreach ( $esperado as $vendor => $quantos ) {
		if ( $marcado[ $vendor ] === $quantos ) {
			continue;
		}

		$achados[] = $rotulo . ': o site-core emitiu ' . $marcado[ $vendor ] . ' ' . $vendor . ' marcado(s) na superfície "'
			. $superficie . '" e o caminho "' . $caminho . '" com estes slots emite ' . $quantos
			. '. Emissão do pacote diferente da declarada é o disparo em dobro nascendo dentro de casa.';
	}

	$algum_slot = 'nenhum' !== $caminho;

	if ( array() !== $de_fora && $algum_slot ) {
		$achados[] = $rotulo . ': DOIS EMISSORES na mesma página. Do site-core: '
			. ( array() === $nossos ? 'nenhum carregador marcado (a emissão dele nesta superfície é ' . implode( ', ', array_map( static fn( string $v, int $q ): string => $v . '=' . $q, array_keys( $esperado ), array_values( $esperado ) ) ) . ')' : implode( ', ', $nossos ) )
			. '. De fora: ' . implode( '; ', $de_fora )
			. '. Com slot preenchido isto é contagem em dobro, e conversão em dobro reescreve o lance do leilão.';
	}

	if ( array() !== $achados ) {
		return array( 'estado' => 'FALHA', 'achados' => $achados );
	}

	if ( array() !== $de_fora ) {
		return array(
			'estado'  => 'WARN',
			'achados' => array(
				$rotulo . ': emissor fora do site-core com TODOS os slots vazios — ' . implode( '; ', $de_fora )
					. '. Não é contagem em dobro: é medição que este pacote não emitiu e não governa. Sob a premissa do agente a decisão é do projeto, e o pacote nomeia em vez de decidir.',
			),
		);
	}

	return array( 'estado' => 'OK', 'achados' => array() );
}

/**
 * Os SLOTS declarados na configuração, na forma que a regra consome.
 *
 * @param array<string,mixed>|null $config Configuração decodificada.
 * @return array<string,string>
 */
function f3b_slots_de_tracking( ?array $config ): array {
	$t = (array) ( $config['tracking'] ?? array() );

	return array(
		'gtm'                 => (string) ( $t['gtm_container_id'] ?? '' ),
		'ga4'                 => (string) ( $t['ga4_measurement_id'] ?? '' ),
		'ads_id'              => (string) ( ( (array) ( $t['google_ads'] ?? array() ) )['conversion_id'] ?? '' ),
		'ads_label'           => (string) ( ( (array) ( $t['google_ads'] ?? array() ) )['conversion_label'] ?? '' ),
		'meta'                => (string) ( $t['meta_pixel_id'] ?? '' ),
		'linkedin_partner'    => (string) ( $t['linkedin_partner_id'] ?? '' ),
		'linkedin_conversion' => (string) ( $t['linkedin_conversion_id'] ?? '' ),
	);
}

/**
 * Lê a tabela declarada de casos do discriminante.
 *
 * @param string $suite Diretório da suíte REAL.
 * @return array<int,array{arquivo:string,superficie:string,slots:array<string,string>,esperado:string}>
 */
function f3b_casos_de_emissor( string $suite ): array {
	$arquivo = $suite . '/casos-de-emissor.tsv';

	if ( ! is_file( $arquivo ) ) {
		return array();
	}

	$saida = array();

	foreach ( (array) file( $arquivo, FILE_IGNORE_NEW_LINES ) as $linha ) {
		$linha = (string) $linha;

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$colunas = explode( "\t", $linha );

		if ( count( $colunas ) < 5 ) {
			continue;
		}

		$slots = array();

		foreach ( explode( ';', trim( $colunas[2] ) ) as $par ) {
			if ( '' === trim( $par ) || ! str_contains( $par, ':' ) ) {
				continue;
			}

			[ $chave, $valor ] = explode( ':', $par, 2 );

			$slots[ trim( $chave ) ] = trim( $valor );
		}

		$saida[] = array(
			'arquivo'    => trim( $colunas[0] ),
			'superficie' => trim( $colunas[1] ),
			'slots'      => $slots,
			'esperado'   => trim( $colunas[3] ),
		);
	}

	return $saida;
}

/**
 * tracking.emissor_unico_discrimina — a regra, medida nos dois lugares.
 *
 * (a) contra o HTML que ESTE pacote publica, com os slots da configuração
 *     dele: um pacote que embarcasse um `gtag.js` no próprio conteúdo seria o
 *     segundo emissor nascendo dentro de casa;
 * (b) contra a TABELA DECLARADA de casos, que é onde os quatro ramos moram —
 *     inclusive o WARN e o caminho do container, que a árvore do pacote não
 *     produz sozinha. Tabela ausente é achado, nunca silêncio: uma regra cujos
 *     ramos deixam de ser exercitados sem que nada reprove é uma regra que
 *     ninguém está medindo.
 *
 * @param string $raiz  Raiz varrida.
 * @param string $suite Diretório da suíte REAL.
 * @return array{ok:bool,achados:array<int,string>,medidas:int,estado:string,motivo:string}
 */
function f3b_ck_emissor_unico_discrimina( string $raiz, string $suite ): array {
	$marcas  = f3b_marcas_do_site_core( $raiz );
	$achados = array();
	$avisos  = array();
	$medidas = 0;

	if ( array() !== $marcas['faltou'] ) {
		foreach ( $marcas['faltou'] as $falta ) {
			$achados[] = 'o discriminante não pôde ser medido: ' . $falta;
		}
	}

	$slots_do_pacote = f3b_slots_de_tracking( f3b_config( $raiz ) );

	/* (a) O HTML que este pacote publica. */
	foreach ( array( 'content/pages', 'content/posts', 'fontes/tema/parts', 'fontes/tema/templates' ) as $pasta ) {
		foreach ( (array) glob( $raiz . '/' . $pasta . '/*.html' ) as $arquivo ) {
			++$medidas;

			$veredito = f3b_veredito_emissor_unico(
				(string) file_get_contents( (string) $arquivo ),
				$pasta . '/' . basename( (string) $arquivo ),
				$marcas['ids'],
				$marcas['origens'],
				$slots_do_pacote,
				'servido'
			);

			if ( 'FALHA' === $veredito['estado'] ) {
				$achados = array_merge( $achados, $veredito['achados'] );
			} elseif ( 'WARN' === $veredito['estado'] ) {
				$avisos = array_merge( $avisos, $veredito['achados'] );
			}
		}
	}

	/* (b) A tabela declarada: é dela que vêm os quatro ramos. */
	$casos = f3b_casos_de_emissor( $suite );

	if ( array() === $casos ) {
		$achados[] = 'suite/casos-de-emissor.tsv ausente ou vazio: sem a tabela declarada, os ramos WARN e do container não são exercitados por rodada nenhuma';
	}

	foreach ( $casos as $caso ) {
		++$medidas;

		$amostra = $suite . '/casos-de-emissor/' . $caso['arquivo'];

		if ( ! is_file( $amostra ) ) {
			$achados[] = 'caso declarado sem amostra em disco: suite/casos-de-emissor/' . $caso['arquivo'];
			continue;
		}

		$veredito = f3b_veredito_emissor_unico(
			(string) file_get_contents( $amostra ),
			'caso ' . $caso['arquivo'],
			$marcas['ids'],
			$marcas['origens'],
			$caso['slots'],
			$caso['superficie']
		);

		if ( $veredito['estado'] === $caso['esperado'] ) {
			continue;
		}

		$achados[] = 'caso ' . $caso['arquivo'] . ' (' . $caso['superficie'] . '): a regra devolveu ' . $veredito['estado']
			. ' e a tabela declara ' . $caso['esperado'] . '. ' . f3b_amostra( $veredito['achados'], 2 );
	}

	if ( array() !== $achados ) {
		return array(
			'ok'      => false,
			'achados' => $achados,
			'medidas' => $medidas,
			'estado'  => 'FALHA',
			'motivo'  => count( $achados ) . ' achado(s): ' . f3b_amostra( $achados ),
		);
	}

	if ( array() !== $avisos ) {
		return array(
			'ok'      => true,
			'achados' => array(),
			'medidas' => $medidas,
			'estado'  => 'WARN',
			'motivo'  => count( $avisos ) . ' aviso(s): ' . f3b_amostra( $avisos ),
		);
	}

	return array(
		'ok'      => true,
		'achados' => array(),
		'medidas' => $medidas,
		'estado'  => 'OK',
		'motivo'  => 'o discriminante é o id que o site-core imprime e só ele — ' . implode( ', ', $marcas['ids'] )
			. ' —, medido nas fontes e não escrito na checagem. Nenhum HTML publicado por este pacote carrega carregador de fornecedor, e a tabela declarada de casos reproduz os quatro ramos: emissão marcada diferente da declarada, emissor de fora com slot preenchido, emissor de fora com slot vazio e gtag("config", …) fora do site-core.',
	);
}

/* -------------------------------------------------------------------------
 * estatica.hidden_governa_visibilidade
 * ---------------------------------------------------------------------- */

/**
 * Regras de AUTOR que declaram `display`, por seletor.
 *
 * O parser é deliberadamente simples — ele não resolve `@media` aninhado nem
 * `:is()`, e não precisa: a pergunta é "existe alguma declaração de autor que
 * ponha `display` nesta classe?", e uma regra dentro de `@media` também põe.
 * Comentário fora antes de qualquer coisa, senão um `display` citado em prosa
 * viraria regra.
 *
 * @param string $css Conteúdo do arquivo.
 * @return array<int,array{seletor:string,display:string,importante:bool}>
 */
function f3b_regras_de_display( string $css ): array {
	$limpo = (string) preg_replace( '#/\*.*?\*/#s', '', $css );
	$saida = array();
	$casos = array();

	if ( ! preg_match_all( '/([^{}]+)\{([^{}]*)\}/s', $limpo, $casos, PREG_SET_ORDER ) ) {
		return array();
	}

	foreach ( $casos as $caso ) {
		$corpo = (string) $caso[2];
		$achou = array();

		if ( ! preg_match( '/(?:^|[;\s])display\s*:\s*([^;]+)/i', $corpo, $achou ) ) {
			continue;
		}

		$valor = trim( (string) $achou[1] );

		foreach ( explode( ',', (string) $caso[1] ) as $seletor ) {
			$seletor = trim( preg_replace( '/\s+/', ' ', $seletor ) ?? '' );

			if ( '' === $seletor || str_starts_with( $seletor, '@' ) ) {
				continue;
			}

			$saida[] = array(
				'seletor'    => $seletor,
				'display'    => $valor,
				'importante' => false !== stripos( $valor, '!important' ),
			);
		}
	}

	return $saida;
}

/**
 * As classes que um seletor exige do MESMO elemento, no último combinador.
 *
 * `.a .b` exige `b`; `.a.b` exige `a` e `b`. O que interessa é o elemento em
 * que a declaração pousa, e ele é sempre o último passo do seletor.
 *
 * @param string $seletor Seletor simples já normalizado.
 * @return array<int,string>
 */
function f3b_classes_do_alvo( string $seletor ): array {
	$passos = preg_split( '/\s*[ >+~]\s*/', trim( $seletor ) ) ?: array();
	$alvo   = (string) end( $passos );
	$achou  = array();

	if ( ! preg_match_all( '/\.([A-Za-z0-9_-]+)/', $alvo, $achou ) ) {
		return array();
	}

	return array_values( array_unique( $achou[1] ) );
}

/**
 * ELEMENTO COMANDADO POR `hidden`: qual classe cada um carrega.
 *
 * As duas superfícies em que o pacote comanda visibilidade por `hidden`:
 *
 * - JavaScript: `x.hidden = …`, `x.setAttribute('hidden' …)` e
 *   `x.removeAttribute('hidden')`. A classe do elemento sai da atribuição
 *   `x.className = '…'` no MESMO arquivo, que é como todo cliente deste pacote
 *   monta os nós que ele cria.
 * - Markup: um elemento com o atributo `hidden` literal e uma `class`.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<string,array<int,string>> Classe => arquivos que a comandam.
 */
function f3b_classes_comandadas_por_hidden( string $raiz ): array {
	$saida = array();

	foreach ( f3b_arquivos( $raiz, array( 'js', 'mjs' ), f3b_excluidos() ) as $rel ) {
		/*
		 * COMENTÁRIO DE BLOCO FORA, e a razão é medida: o cabeçalho de
		 * `f3base-consentimento.js` narra o defeito da 1.1.2 citando
		 * `caixa.hidden = true`. Sem esta remoção o detector leria a prosa
		 * como código e passaria a cobrar um par `[hidden]` para uma classe
		 * que ninguém esconde — regra acusando o texto que a explica.
		 */
		$fonte     = (string) preg_replace( '#/\*.*?\*/#s', '', (string) file_get_contents( $raiz . '/' . $rel ) );
		$variaveis = array();
		$achou     = array();

		if ( preg_match_all( '/([A-Za-z_$][A-Za-z0-9_$]*)\s*\.\s*hidden\s*=/', $fonte, $achou ) ) {
			$variaveis = array_merge( $variaveis, $achou[1] );
		}

		if ( preg_match_all( '/([A-Za-z_$][A-Za-z0-9_$]*)\s*\.\s*(?:set|remove)Attribute\s*\(\s*[\'"]hidden[\'"]/', $fonte, $achou ) ) {
			$variaveis = array_merge( $variaveis, $achou[1] );
		}

		foreach ( array_unique( $variaveis ) as $variavel ) {
			$classes = array();

			if ( ! preg_match_all( '/\b' . preg_quote( (string) $variavel, '/' ) . '\s*\.\s*className\s*=\s*[\'"]([^\'"]+)[\'"]/', $fonte, $classes ) ) {
				continue;
			}

			foreach ( $classes[1] as $lista ) {
				foreach ( preg_split( '/\s+/', trim( (string) $lista ) ) ?: array() as $classe ) {
					if ( '' !== $classe ) {
						$saida[ $classe ][] = $rel;
					}
				}
			}
		}
	}

	foreach ( f3b_arquivos( $raiz, array( 'html', 'php' ), f3b_excluidos() ) as $rel ) {
		$fonte = (string) file_get_contents( $raiz . '/' . $rel );
		$achou = array();

		if ( ! preg_match_all( '/<[a-zA-Z][^>]*\shidden(?:\s|=|>|\/)[^>]*>/', $fonte, $achou ) ) {
			continue;
		}

		foreach ( $achou[0] as $tag ) {
			$classe = array();

			if ( ! preg_match( '/\sclass\s*=\s*[\'"]([^\'"]+)[\'"]/', (string) $tag, $classe ) ) {
				continue;
			}

			foreach ( preg_split( '/\s+/', trim( (string) $classe[1] ) ) ?: array() as $nome ) {
				if ( '' !== $nome ) {
					$saida[ $nome ][] = $rel;
				}
			}
		}
	}

	foreach ( $saida as $classe => $arquivos ) {
		$saida[ $classe ] = array_values( array_unique( $arquivos ) );
	}

	return $saida;
}

/**
 * `hidden` GOVERNA a visibilidade, ou o `display` de autor tem par declarado.
 *
 * O DEFEITO QUE PRODUZIU ESTA REGRA, medido na 1.1.2 e em dois lugares ao mesmo
 * tempo. `style.css` declarava `.f3base-consentimento-painel { display: grid }`
 * e o `site-core` alternava `caixa.hidden` para abrir e fechar o painel;
 * `implantador.css` declarava `.f3base-imp-encerramento { display: block }` e o
 * cliente do implantador alternava `encerramento.hidden` para revelar o resumo
 * final. Nos dois, o `hidden` NÃO TINHA EFEITO NENHUM: `[hidden] { display:
 * none }` é regra da folha do USER AGENT, e qualquer declaração de autor a
 * vence — a especificidade nem chega a ser consultada, porque a origem decide
 * antes. O resultado na tela: o painel de consentimento cobria a página e o
 * botão "Fechar" não fechava; a caixa do resumo final ficava aberta e vazia do
 * primeiro lote ao último.
 *
 * A REGRA, e ela é de par: elemento cuja visibilidade é comandada por `hidden`
 * não pode ter `display` declarado por regra de autor — a menos que o `display`
 * venha ACOMPANHADO de um `[hidden] { display: none }` que o vença. Dois pares
 * são aceitos, e os dois foram escolhidos por especificidade medida:
 *
 * - `.classe[hidden] { display: none }` — 0,2,0 contra 0,1,0 da regra da
 *   classe. Vence sem `!important`, e é o par preferido.
 * - `[hidden] { display: none !important }` — regra global. Ela vence qualquer
 *   coisa, inclusive o que ainda não foi escrito, e por isso é aceita; o preço
 *   é que `!important` de escopo aberto alcança markup de bloco e de plugin.
 *
 * O que NÃO é aceito: um `[hidden]` global sem `!important`. Ele empata em
 * especificidade com a regra da classe (0,1,0 contra 0,1,0) e perde na ordem
 * sempre que a regra da classe vier depois — o que é indecidível de fora do
 * arquivo, e regra cuja correção depende da ordem de escrita não é regra.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_hidden_governa_visibilidade( string $raiz ): array {
	$comandadas = f3b_classes_comandadas_por_hidden( $raiz );
	$folhas     = f3b_arquivos( $raiz, array( 'css' ), f3b_excluidos() );

	$displays = array();
	$pares    = array();
	$global   = '';

	foreach ( $folhas as $rel ) {
		foreach ( f3b_regras_de_display( (string) file_get_contents( $raiz . '/' . $rel ) ) as $regra ) {
			$seletor = $regra['seletor'];
			$tem     = str_contains( $seletor, '[hidden]' );
			$none    = 'none' === strtolower( trim( str_ireplace( '!important', '', $regra['display'] ) ) );

			if ( $tem && $none ) {
				if ( '[hidden]' === $seletor && $regra['importante'] ) {
					$global = $rel;
				}

				foreach ( f3b_classes_do_alvo( $seletor ) as $classe ) {
					$pares[ $classe ] = $rel;
				}

				continue;
			}

			if ( $tem ) {
				continue;
			}

			foreach ( f3b_classes_do_alvo( $seletor ) as $classe ) {
				$displays[ $classe ][] = $rel . ' (' . $seletor . ' { display: ' . $regra['display'] . ' })';
			}
		}
	}

	$achados = array();
	$medidas = 0;

	foreach ( $comandadas as $classe => $arquivos ) {
		++$medidas;

		if ( ! isset( $displays[ $classe ] ) ) {
			continue;
		}

		if ( '' !== $global || isset( $pares[ $classe ] ) ) {
			continue;
		}

		$achados[] = '.' . $classe . ' tem a visibilidade comandada por `hidden` em ' . implode( ', ', $arquivos )
			. ' e recebe `display` de regra de autor em ' . implode( '; ', $displays[ $classe ] )
			. '. Regra de autor vence o `[hidden] { display: none }` da folha do user agent — a origem decide antes da'
			. ' especificidade —, então o `hidden` não tem efeito nenhum e o elemento fica visível quando o código o'
			. ' esconde. Declare `.' . $classe . '[hidden] { display: none }` na mesma folha (0,2,0 contra 0,1,0), ou'
			. ' tire o `display` da regra da classe.';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * tracking.eventos_de_comportamento_declarados
 * ---------------------------------------------------------------------- */

/**
 * A declaração de eventos de comportamento, lida da ÁRVORE VARRIDA.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<int,array<int,string>> Linhas da declaração.
 */
function f3b_eventos_de_comportamento( string $raiz ): array {
	return f3b_tsv( $raiz . '/fontes/plugin/dados/eventos-comportamento.tsv' );
}

/**
 * NOME DE EVENTO E DE PARÂMETRO MORAM NUM LUGAR SÓ.
 *
 * A REGRA, e por que ela é dura. Quem vai ler a série de comportamento é um
 * agente comparando períodos. Para ele, nome de evento que muda entre releases
 * não é um erro visível: é um relatório que fica vazio no mês seguinte, sem
 * ninguém saber se o site parou de medir ou se os visitantes pararam de rolar.
 * Um nome escrito no cliente ao lado do nome declarado no TSV são duas fontes
 * de verdade sobre a mesma série, e elas divergem na primeira edição apressada.
 *
 * Então: **o cliente não escreve nome de evento nem de parâmetro declarado.**
 * Ele os recebe do servidor, que os lê do arquivo único. O detector procura
 * cada nome declarado como LITERAL dentro do JavaScript do pacote — achou,
 * reprova, nomeando o arquivo e o nome.
 *
 * O QUE O DETECTOR **NÃO** PROÍBE, e o limite está escrito para não virar
 * folclore: os valores da coluna `limiar` podem aparecer no cliente. `LCP`,
 * `CLS`, `INP` e `TTFB` são identificadores de métrica da própria plataforma —
 * o cliente precisa deles para saber qual coletor nativo alimentar —, e proibi-los
 * exigiria um mapeamento de nome para tipo de entrada que só existiria para
 * satisfazer o detector. O que o detector cobra deles é COBERTURA: todo vital
 * declarado precisa estar sendo coletado.
 *
 * As outras quatro asserções são de forma da própria declaração: teto positivo
 * (teto zero é evento declarado que nunca sai), parâmetro presente, gatilho
 * nomeado, e o consumidor do arquivo existindo no servidor — uma declaração que
 * ninguém lê é pior que declaração nenhuma, porque ela dá ao próximo leitor a
 * impressão de que alguma coisa está sendo governada ali.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_eventos_de_comportamento_declarados( string $raiz ): array {
	$linhas  = f3b_eventos_de_comportamento( $raiz );
	$achados = array();
	$medidas = 0;

	if ( array() === $linhas ) {
		return array(
			'ok'      => false,
			'achados' => array( 'fontes/plugin/dados/eventos-comportamento.tsv ausente ou vazio na raiz varrida: sem a declaração única, cada coletor passa a nomear o próprio evento e a série histórica deixa de ter dono' ),
			'medidas' => 0,
		);
	}

	$nomes  = array();
	$vitais = array();

	foreach ( $linhas as $linha ) {
		$evento     = trim( $linha[0] ?? '' );
		$parametros = array_values( array_filter( array_map( 'trim', explode( ',', $linha[1] ?? '' ) ) ) );
		$teto       = (int) trim( $linha[2] ?? '' );
		$gatilho    = trim( $linha[3] ?? '' );
		$limiar     = trim( $linha[4] ?? '' );

		if ( '' === $evento ) {
			continue;
		}

		++$medidas;

		$nomes[] = $evento;
		$nomes   = array_merge( $nomes, $parametros );

		if ( 'pagina' === $gatilho && array() !== $parametros ) {
			$achados[] = $evento . ': o gatilho "pagina" declarou parâmetro (' . implode( ', ', $parametros )
				. '). O discriminante dele é o CAMINHO, que a tabela já guarda em coluna própria; um parâmetro ali só pode repetir o que a linha diz, e repetição em declaração é a segunda verdade de sempre';
		}

		if ( $teto < 1 ) {
			$achados[] = $evento . ': teto por página declarado como "' . trim( $linha[2] ?? '' ) . '". Teto ausente ou zero é evento declarado que nunca sai — e um evento que nunca sai é uma linha de tabela afirmando cobertura que não existe';
		}

		/*
		 * A EXCEÇÃO É DECLARADA E É UMA SÓ: o evento cujo discriminante já é o
		 * CAMINHO, que toda linha da tabela carrega numa coluna própria. O
		 * contador de carregamentos é assim — a pergunta dele é "quantas vezes
		 * esta página foi aberta", e a página é a coluna, não um parâmetro. Um
		 * parâmetro constante ali seria peso morto: ele só poderia repetir o
		 * que a linha já diz. A exceção mora no GATILHO, e não numa lista de
		 * nomes de evento, porque é o gatilho que o cliente conhece e é ele que
		 * sobrevive a uma renomeação do evento.
		 */
		if ( array() === $parametros && 'pagina' !== $gatilho ) {
			$achados[] = $evento . ': nenhum parâmetro declarado. Evento sem parâmetro não responde nada — quem lê o relatório precisa saber QUAL marco, QUAL seção, QUAL domínio';
		}

		if ( '' === $gatilho ) {
			$achados[] = $evento . ': gatilho não declarado. Sem ele ninguém sabe o que faz o evento sair, e a série vira número sem procedência';
		}

		if ( str_contains( $limiar, 'vitais=' ) ) {
			$partes = array();

			if ( preg_match( '/vitais=([^;]+)/', $limiar, $partes ) ) {
				$vitais = array_values( array_filter( array_map( 'trim', explode( ',', $partes[1] ) ) ) );
			}
		}
	}

	$nomes = array_values( array_unique( array_filter( $nomes ) ) );

	foreach ( f3b_arquivos( $raiz, array( 'js' ), f3b_excluidos() ) as $rel ) {
		$fonte = (string) preg_replace( '#/\*.*?\*/#s', '', (string) file_get_contents( $raiz . '/' . $rel ) );

		foreach ( $nomes as $nome ) {
			if ( ! str_contains( $fonte, "'" . $nome . "'" ) && ! str_contains( $fonte, '"' . $nome . '"' ) ) {
				continue;
			}

			$achados[] = $rel . ' escreve o nome declarado "' . $nome . '" como literal. Ele mora em'
				. ' fontes/plugin/dados/eventos-comportamento.tsv e chega ao cliente pelo servidor; um segundo'
				. ' lugar declarando o mesmo nome são duas fontes de verdade sobre a mesma série histórica, e elas'
				. ' divergem na primeira edição apressada — sem erro, e com o relatório do mês seguinte vazio';
		}
	}

	$cliente = $raiz . '/fontes/plugin/assets/f3base-tracking.js';
	$fonte   = is_file( $cliente ) ? (string) file_get_contents( $cliente ) : '';

	foreach ( $vitais as $vital ) {
		++$medidas;

		if ( '' === $fonte || str_contains( $fonte, "'" . $vital . "'" ) || str_contains( $fonte, $vital . ':' ) || ( str_contains( $fonte, "biblioteca['on' + nome]" ) && str_contains( (string) @file_get_contents( $raiz . '/fontes/plugin/assets/vendor/web-vitals.js' ), 'on' . $vital ) ) ) {
			continue;
		}

		$achados[] = 'o vital "' . $vital . '" está declarado e o cliente não o coleta: declaração que promete métrica'
			. ' que ninguém mede é a mesma doença da chave sem consumidor, um nível acima';
	}

	/*
	 * O NOME CABE NA COLUNA QUE O GUARDA, e o número não é digitado aqui: ele é
	 * LIDO do próprio DDL do módulo. `metrica varchar(64)` é o que as duas
	 * tabelas declaram, e um nome maior que isso não é recusado por ninguém — o
	 * MySQL o TRUNCA em modo permissivo e grava um nome que não existe na
	 * declaração. A série histórica ganha uma linha órfã, a tela mostra um evento
	 * que ninguém declarou, e o relatório do período seguinte não bate com o
	 * anterior — sem erro em lugar nenhum.
	 *
	 * SEM O DDL LEGÍVEL NÃO HÁ REGRA. Inventar um comprimento aqui seria a
	 * segunda verdade que este detector existe para impedir, um nível acima.
	 */
	$modulo_do_registro = $raiz . '/fontes/plugin/includes/class-f3base-modulo-comportamento.php';
	$largura_da_metrica = 0;

	if ( is_file( $modulo_do_registro ) && preg_match_all( '/metrica\s+varchar\((\d+)\)/', (string) file_get_contents( $modulo_do_registro ), $larguras ) ) {
		$largura_da_metrica = (int) min( array_map( 'intval', $larguras[1] ) );
	}

	if ( $largura_da_metrica > 0 ) {
		foreach ( $linhas as $linha ) {
			$evento_medido = trim( $linha[0] ?? '' );

			if ( '' === $evento_medido ) {
				continue;
			}

			++$medidas;

			if ( strlen( $evento_medido ) <= $largura_da_metrica ) {
				continue;
			}

			$achados[] = 'o nome "' . $evento_medido . '" tem ' . strlen( $evento_medido )
				. ' caracteres e a coluna que o guarda aceita ' . $largura_da_metrica
				. '. O banco não recusa: ele TRUNCA, e passa a existir na tabela um nome de evento que não está na declaração —'
				. ' a tela mostra um evento que ninguém declarou e o relatório do período seguinte não bate com o anterior, sem erro em lugar nenhum';
		}
	}

	/*
	 * RESERVA É IGUAL À DECLARAÇÃO, e o dia em que a reserva é usada é o dia em
	 * que o arquivo se corrompeu — que é exatamente quando os dois lados
	 * precisam continuar concordando.
	 *
	 * O DEFEITO MEDIDO. `histerese_pp` chegava ao cliente com a reserva ZERO, e
	 * zero é a reserva MENOS conservadora possível para essa chave: ela REMOVE a
	 * banda da fronteira, e o tremor de um pixel na linha dos 50% passa a
	 * fabricar travessia que ninguém fez. `cliques`, `janela_ms` e `raio_px`
	 * chegavam com zero também, e ali zero não é conservador nem agressivo: é
	 * DESLIGADO — a guarda do coletor recusa `cliques < 1`, e um TSV truncado
	 * apagava o coletor de fricção inteiro em silêncio.
	 *
	 * A REGRA VALE PARA O NÚMERO, e não para a lista: `limiar()` devolve lista e
	 * a reserva vazia dele é a decisão declarada de NÃO EMITIR, que é outra
	 * coisa. O que se cobra aqui é o número que substitui um número.
	 */
	$limiares_declarados = array();

	foreach ( $linhas as $linha ) {
		$gatilho_declarado = trim( $linha[3] ?? '' );
		$limiar_declarado  = trim( $linha[4] ?? '' );

		if ( '' === $gatilho_declarado || '' === $limiar_declarado || '—' === $limiar_declarado ) {
			continue;
		}

		foreach ( explode( ';', $limiar_declarado ) as $par_declarado ) {
			$partes_do_par = explode( '=', $par_declarado, 2 );

			if ( count( $partes_do_par ) < 2 ) {
				continue;
			}

			$valores_do_par = explode( ',', trim( $partes_do_par[1] ) );

			$limiares_declarados[ $gatilho_declarado ][ trim( $partes_do_par[0] ) ] = trim( (string) $valores_do_par[0] );
		}
	}

	foreach ( f3b_arquivos( $raiz, array( 'js' ), f3b_excluidos() ) as $rel ) {
		$fonte_do_cliente = f3b_js_sem_comentario( (string) file_get_contents( $raiz . '/' . $rel ) );

		if ( ! preg_match_all( '/numeroDoLimiar\(\s*([A-Za-z_$][A-Za-z0-9_$]*|\'[a-z-]+\')\s*,\s*\'([A-Za-z0-9_]+)\'\s*,\s*([^),]+?)\s*\)/', $fonte_do_cliente, $chamadas, PREG_OFFSET_CAPTURE ) ) {
			continue;
		}

		foreach ( $chamadas[2] as $indice_da_chamada => $chave_capturada ) {
			$chave_do_limiar = (string) $chave_capturada[0];
			$reserva_escrita = trim( (string) $chamadas[3][ $indice_da_chamada ][0] );
			$argumento       = trim( (string) $chamadas[1][ $indice_da_chamada ][0] );
			$posicao         = (int) $chamadas[0][ $indice_da_chamada ][1];

			if ( ! is_numeric( $reserva_escrita ) ) {
				continue;
			}

			$gatilho_da_chamada = '';

			if ( 1 === preg_match( "/^'([a-z-]+)'$/", $argumento, $literal_do_gatilho ) ) {
				$gatilho_da_chamada = (string) $literal_do_gatilho[1];
			} elseif ( preg_match_all( '/\b' . preg_quote( $argumento, '/' ) . "\s*=\s*'([a-z-]+)'/", substr( $fonte_do_cliente, 0, $posicao ), $atribuicoes ) ) {
				$gatilho_da_chamada = (string) end( $atribuicoes[1] );
			}

			if ( '' === $gatilho_da_chamada || ! isset( $limiares_declarados[ $gatilho_da_chamada ][ $chave_do_limiar ] ) ) {
				continue;
			}

			++$medidas;

			$declarado_do_limiar = $limiares_declarados[ $gatilho_da_chamada ][ $chave_do_limiar ];

			if ( is_numeric( $declarado_do_limiar ) && (float) $declarado_do_limiar === (float) $reserva_escrita ) {
				continue;
			}

			$achados[] = $rel . ': a reserva de "' . $chave_do_limiar . '" do gatilho "' . $gatilho_da_chamada
				. '" é ' . $reserva_escrita . ' e a declaração diz ' . $declarado_do_limiar
				. '. A reserva só é usada quando a declaração chega truncada — é exatamente o dia em que os dois lados'
				. ' precisam continuar concordando, e um número diferente aqui aperta ou remove o limiar em silêncio';
		}
	}

	$servidor = $raiz . '/fontes/plugin/includes/class-f3base-modulo-tracking.php';

	++$medidas;

	if ( ! is_file( $servidor ) || ! str_contains( (string) file_get_contents( $servidor ), 'eventos-comportamento.tsv' ) ) {
		$achados[] = 'nenhum consumidor da declaração no servidor: o módulo de tracking precisa LER'
			. ' dados/eventos-comportamento.tsv e publicá-la ao navegador. Declaração que ninguém lê dá ao próximo'
			. ' leitor a impressão de que alguma coisa está sendo governada ali dentro';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* =========================================================================
 * estatica.campo_operavel_tem_impacto_e_exemplo
 *
 * O BURACO QUE ESTA REGRA FECHA, dito com a medida que o abriu. Até a 1.1.3 o
 * catálogo do site-core declarava `rotulo` para toda option e `descricao` para
 * ALGUMAS. Nenhuma folha operável dizia o que MUDA no site quando o campo é
 * preenchido, e nenhuma trazia um valor de exemplo. Rótulo é o nome da coisa;
 * descrição é a definição dela. "Número de WhatsApp em E.164" é definição — ela
 * não diz que, enquanto o campo estiver vazio, o botão de contato não é
 * publicado em página nenhuma. Quem opera o site lê a tela para decidir se
 * preenche, e a decisão depende exatamente da frase que não existia.
 *
 * A ÂNCORA É O PRÓPRIO CATÁLOGO — a mesma família de
 * `estatica.detector_chave_sem_consumidor`. Nada aqui declara quais campos
 * existem: a lista sai do arquivo do pacote, e um campo novo entra na cobrança
 * sozinho, no mesmo commit em que nasce.
 *
 * O EXEMPLO TEM DUAS RECUSAS, e as duas são medidas:
 *
 * 1. SEGREDO NÃO TEM EXEMPLO DE VALOR. Um valor plausível no lugar de um token
 *    é uma credencial impressa na tela de administração de todo site que
 *    instalar este pacote. A medida é a forma: nenhuma corrida de 16 ou mais
 *    caracteres alfanuméricos no exemplo de uma option declarada em
 *    `segredos_do_site()` — que é o comprimento a partir do qual o texto deixa
 *    de parecer prosa e passa a parecer valor.
 * 2. IDENTIFICADOR DE FORNECEDOR SAI NA FORMA DA DOCUMENTAÇÃO DELE. O pacote
 *    já declara essa forma em `F3Base_Modulo_Tracking::formas()`, e é dela que
 *    o exemplo tem de sair. Copiar um ID de medição real para dentro do pacote
 *    mandaria dados do cliente para a conta de outra pessoa; inventar um ID que
 *    FUNCIONA é a mesma coisa com mais passos.
 * ====================================================================== */

/**
 * Avança até a vírgula de nível zero, respeitando parênteses e aspas.
 *
 * @param string $texto Texto.
 * @param int    $i     Posição inicial.
 * @return int Posição da vírgula, ou o fim do texto.
 */
function f3b_ate_virgula( string $texto, int $i ): int {
	$n     = strlen( $texto );
	$nivel = 0;

	while ( $i < $n ) {
		$c = $texto[ $i ];

		if ( "'" === $c || '"' === $c ) {
			$aspas = $c;
			$i++;

			while ( $i < $n ) {
				if ( '\\' === $texto[ $i ] ) {
					$i += 2;
					continue;
				}

				if ( $texto[ $i ] === $aspas ) {
					break;
				}

				$i++;
			}

			$i++;
			continue;
		}

		if ( '(' === $c || '[' === $c ) {
			$nivel++;
		}

		if ( ')' === $c || ']' === $c ) {
			if ( 0 === $nivel ) {
				return $i;
			}

			$nivel--;
		}

		if ( ',' === $c && 0 === $nivel ) {
			return $i;
		}

		$i++;
	}

	return $n;
}

/**
 * A posição do `)` que fecha um `array(` já aberto.
 *
 * @param string $texto Texto.
 * @param int    $i     Posição logo DEPOIS do parêntese de abertura.
 * @return int Posição do fecho, ou o fim do texto.
 */
function f3b_fecha_parenteses( string $texto, int $i ): int {
	$n     = strlen( $texto );
	$nivel = 0;

	while ( $i < $n ) {
		$c = $texto[ $i ];

		if ( "'" === $c || '"' === $c ) {
			$aspas = $c;
			$i++;

			while ( $i < $n ) {
				if ( '\\' === $texto[ $i ] ) {
					$i += 2;
					continue;
				}

				if ( $texto[ $i ] === $aspas ) {
					break;
				}

				$i++;
			}

			$i++;
			continue;
		}

		if ( '(' === $c ) {
			$nivel++;
		}

		if ( ')' === $c ) {
			if ( 0 === $nivel ) {
				return $i;
			}

			$nivel--;
		}

		$i++;
	}

	return $n;
}

/**
 * Entradas `'chave' => valor` de um literal de array PHP, sem executar nada.
 *
 * @param string $texto Conteúdo INTERNO do array.
 * @return array<string,string> Chave para o texto bruto do valor.
 */
function f3b_entradas_de_array( string $texto ): array {
	$saida = array();
	$i     = 0;
	$n     = strlen( $texto );

	while ( $i < $n ) {
		while ( $i < $n && ( ctype_space( $texto[ $i ] ) || ',' === $texto[ $i ] ) ) {
			$i++;
		}

		if ( $i >= $n ) {
			break;
		}

		if ( "'" !== $texto[ $i ] ) {
			$i = f3b_ate_virgula( $texto, $i ) + 1;
			continue;
		}

		$j     = $i + 1;
		$chave = '';

		while ( $j < $n && "'" !== $texto[ $j ] ) {
			if ( '\\' === $texto[ $j ] ) {
				$chave .= $texto[ $j + 1 ] ?? '';
				$j     += 2;
				continue;
			}

			$chave .= $texto[ $j ];
			$j++;
		}

		$j++;

		while ( $j < $n && ctype_space( $texto[ $j ] ) ) {
			$j++;
		}

		if ( '=' !== ( $texto[ $j ] ?? '' ) || '>' !== ( $texto[ $j + 1 ] ?? '' ) ) {
			$i = f3b_ate_virgula( $texto, $i ) + 1;
			continue;
		}

		$j += 2;

		while ( $j < $n && ctype_space( $texto[ $j ] ) ) {
			$j++;
		}

		$fim             = f3b_ate_virgula( $texto, $j );
		$saida[ $chave ] = trim( substr( $texto, $j, $fim - $j ) );
		$i               = $fim + 1;
	}

	return $saida;
}

/**
 * O interior de um `array( … )` escrito como valor, ou null quando não é array.
 *
 * @param string $valor Texto bruto do valor.
 * @return string|null
 */
function f3b_interior_de_array( string $valor ): ?string {
	$valor = trim( $valor );

	foreach ( array( 'array(' => ')', '[' => ']' ) as $abre => $fecha ) {
		if ( str_starts_with( $valor, $abre ) && str_ends_with( $valor, $fecha ) ) {
			return substr( $valor, strlen( $abre ), -1 );
		}
	}

	return null;
}

/**
 * A primeira string literal de um valor — o texto de `__( '…', 'f3base' )`.
 *
 * @param string $valor Texto bruto do valor.
 * @return string
 */
function f3b_texto_literal( string $valor ): string {
	if ( 1 === preg_match( "/'((?:[^'\\\\]|\\\\.)*)'/s", $valor, $m ) ) {
		return str_replace( array( "\\'", '\\\\' ), array( "'", '\\' ), $m[1] );
	}

	return '';
}

/**
 * O catálogo do site-core, lido do arquivo — nunca executado.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{entradas:array<string,array<string,string>>,ancora:string,secoes:array<int,string>}
 */
/** Lê um literal de array atribuído à variável, sem executar PHP. */
function f3b_catalogo_array_atribuido( string $corpo, string $variavel ): ?array {
	if ( ! preg_match( '/\$' . preg_quote( $variavel, '/' ) . '\s*=\s*array\s*\(/', $corpo, $m, PREG_OFFSET_CAPTURE ) ) { return null; }
	$inicio = $m[0][1] + strlen( $m[0][0] );
	$fim = f3b_fecha_parenteses( $corpo, $inicio );
	if ( $fim >= strlen( $corpo ) ) { return null; }
	return f3b_entradas_de_array( substr( $corpo, $inicio, $fim - $inicio ) );
}

/** Divide argumentos ou itens posicionais respeitando os literais aninhados. */
function f3b_catalogo_itens_posicionais( string $texto ): array {
	$itens = array();
	for ( $i = 0, $n = strlen( $texto ); $i < $n; $i = $fim + 1 ) {
		$fim = f3b_ate_virgula( $texto, $i );
		$item = trim( substr( $texto, $i, $fim - $i ) );
		if ( '' !== $item ) { $itens[] = $item; }
	}
	return $itens;
}

/** Reconstrói somente a representação literal, jamais avalia o código lido. */
function f3b_catalogo_literal( array $entradas ): string {
	$partes = array();
	foreach ( $entradas as $nome => $valor ) {
		// Tokens de array PHP; não é arrow function JavaScript montada por concatenação.
		$partes[] = implode( ' ', array( var_export( $nome, true ), '=>', $valor ) );
	}
	return 'array(' . implode( ',', $partes ) . ')';
}

/** Confirma a incorporação da trait no corpo da fachada, não num import de namespace. */
function f3b_catalogo_usa_trait( string $fonte, string $trait ): bool {
	$classe = false; $nivel = 0; $espera = false; $uso = null;
	foreach ( token_get_all( $fonte ) as $token ) {
		$texto = is_array( $token ) ? $token[1] : $token;
		if ( ! $classe ) {
			if ( is_array( $token ) && T_CLASS === $token[0] ) { $espera = true; continue; }
			if ( $espera && is_array( $token ) && T_STRING === $token[0] ) { $classe = 'F3Base_Options' === $texto; $espera = false; }
			continue;
		}
		if ( '{' === $token ) { ++$nivel; }
		if ( '}' === $token && 0 === --$nivel ) { return false; }
		if ( 1 === $nivel && is_array( $token ) && T_USE === $token[0] ) { $uso = ''; continue; }
		if ( null !== $uso ) {
			if ( ';' === $token ) { if ( trim( $uso ) === $trait ) { return true; } $uso = null; }
			else { $uso .= $texto; }
		}
	}
	return false;
}

/** Resolve o catálogo legado ou sua delegação explícita para uma trait local. */
function f3b_catalogo_declarado( string $raiz ): array {
	$vazio = array( 'entradas' => array(), 'ancora' => '', 'secoes' => array() );
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$fachada = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = f3b_corpo_de_funcao( $fachada, 'catalogo' );
		if ( null === $corpo ) { continue; }
		$src = $fachada;
		$ancora = $rel;
		if ( preg_match( '/^\s*return\s+self::catalogo_interno\s*\(\s*\)\s*;\s*$/', $corpo ) ) {
			$encontrado = false;
			preg_match_all( '/require_once\s+__DIR__\s*\.\s*\x27(\/[A-Za-z0-9_.-]+\.php)\x27\s*;/', $fachada, $imports );
			foreach ( $imports[1] as $import ) {
				$candidato = dirname( $raiz . '/' . $rel ) . $import;
				if ( ! is_file( $candidato ) ) { continue; }
				$trait = f3b_codigo_php( $candidato );
				if ( ! preg_match( '/\btrait\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{/', $trait, $nome )
					|| ! f3b_catalogo_usa_trait( $fachada, $nome[1] ) ) { continue; }
				$implementacao = f3b_corpo_de_funcao( $trait, 'catalogo_interno' );
				if ( null === $implementacao ) { continue; }
				$src = $trait; $corpo = $implementacao; $ancora .= ' + ' . dirname( $rel ) . $import;
				$encontrado = true; break;
			}
			if ( ! $encontrado ) { return $vazio + array( 'erro' => 'delegação do catálogo sem require/use/implementação confirmados: ' . $rel ); }
		}
		$entradas = f3b_catalogo_array_atribuido( $corpo, 'catalogo' );
		if ( null === $entradas ) {
			if ( str_contains( $corpo, 'catalogo_interno' ) ) { return $vazio + array( 'erro' => 'wrapper de catálogo não reconhecido: ' . $rel ); }
			continue;
		}
		$secoes = array();
		preg_match_all( "/const\s+(SECAO_[A-Z_]+)\s*=\s*'([^']+)'/", $fachada, $constantes, PREG_SET_ORDER );
		foreach ( $constantes as $m ) { $secoes[ $m[1] ] = $m[2]; }
		$evolucao = f3b_corpo_de_funcao( $src, 'catalogo_evolucao' );
		if ( null !== $evolucao || str_contains( $corpo, 'catalogo_evolucao' ) ) {
			if ( null === $evolucao || ! preg_match( '/\$catalogo\s*=\s*self::catalogo_evolucao\s*\(\s*\$catalogo\s*\)/', $corpo ) ) {
				return $vazio + array( 'erro' => 'evolução do catálogo sem chamada e implementação confirmadas: ' . $ancora );
			}
			$novos = f3b_catalogo_array_atribuido( $evolucao, 'novos' );
			if ( null === $novos || ! preg_match( '/\$campo\s*=\s*static\s+fn\s*\(([^)]*)\)\s*=>\s*array\s*\(/', $evolucao, $funcao, PREG_OFFSET_CAPTURE ) ) {
				return $vazio + array( 'erro' => 'declaração aditiva do catálogo não reconhecida: ' . $ancora );
			}
			$inicio = $funcao[0][1] + strlen( $funcao[0][0] );
			$campos = f3b_entradas_de_array( substr( $evolucao, $inicio, f3b_fecha_parenteses( $evolucao, $inicio ) - $inicio ) );
			preg_match_all( '/\$([A-Za-z_][A-Za-z0-9_]*)/', $funcao[1][0], $parametros );
			$compacto = preg_replace( '/\s+/', '', $evolucao );
			if ( ! str_contains( $compacto, "\$catalogo[\$nome]['padrao'][\$chave]=\$item[0];" ) || ! str_contains( $compacto, "\$catalogo[\$nome]['subcampos'][\$chave]=\$item[1];" ) ) {
				return $vazio + array( 'erro' => 'aplicação dos campos aditivos não reconhecida: ' . $ancora );
			}
			foreach ( $novos as $option => $campos_brutos ) {
				$base = f3b_interior_de_array( $entradas[ $option ] ?? '' );
				$lista = f3b_interior_de_array( $campos_brutos );
				if ( null === $base || null === $lista ) { return $vazio + array( 'erro' => 'option aditiva sem base literal: ' . $option ); }
				$declaracao = f3b_entradas_de_array( $base );
				$sub = f3b_entradas_de_array( f3b_interior_de_array( $declaracao['subcampos'] ?? '' ) ?? '' );
				$padrao = f3b_entradas_de_array( f3b_interior_de_array( $declaracao['padrao'] ?? '' ) ?? '' );
				foreach ( f3b_entradas_de_array( $lista ) as $chave => $dupla_bruta ) {
					$dupla = f3b_catalogo_itens_posicionais( f3b_interior_de_array( $dupla_bruta ) ?? '' );
					if ( count( $dupla ) === 2 && null !== f3b_interior_de_array( $dupla[1] ) ) {
						$sub[ $chave ] = $dupla[1]; $padrao[ $chave ] = $dupla[0]; continue;
					}
					if ( count( $dupla ) !== 2 || ! preg_match( '/^\$campo\s*\(/', $dupla[1], $chamada ) ) { return $vazio + array( 'erro' => 'campo aditivo ilegível: ' . $option . '.' . $chave ); }
					$inicio = strlen( $chamada[0] ); $fim = f3b_fecha_parenteses( $dupla[1], $inicio );
					$args = f3b_catalogo_itens_posicionais( substr( $dupla[1], $inicio, $fim - $inicio ) );
					if ( count( $args ) !== count( $parametros[1] ) ) { return $vazio + array( 'erro' => 'argumentos incompletos: ' . $option . '.' . $chave ); }
					$argumentos = array_combine( array_map( static fn( $p ) => '$' . $p, $parametros[1] ), $args );
					$campo = array();
					foreach ( $campos as $propriedade => $valor ) { $campo[ $propriedade ] = $argumentos[ trim( $valor ) ] ?? $valor; }
					$extra = trim( substr( $dupla[1], $fim + 1 ) );
					if ( '' !== $extra ) {
						$mais = str_starts_with( $extra, '+' ) ? f3b_interior_de_array( trim( substr( $extra, 1 ) ) ) : null;
						if ( null === $mais ) { return $vazio + array( 'erro' => 'complemento do campo não reconhecido: ' . $option . '.' . $chave ); }
						$campo += f3b_entradas_de_array( $mais );
					}
					$sub[ $chave ] = f3b_catalogo_literal( $campo ); $padrao[ $chave ] = $dupla[0];
				}
				$declaracao['subcampos'] = f3b_catalogo_literal( $sub ); $declaracao['padrao'] = f3b_catalogo_literal( $padrao );
				$entradas[ $option ] = f3b_catalogo_literal( $declaracao );
			}
			preg_match_all( '/\$catalogo\s*\[\s*\x27([^\x27]+)\x27\s*\]\s*=\s*array\s*\(/', $evolucao, $adicionais, PREG_SET_ORDER | PREG_OFFSET_CAPTURE );
			preg_match_all( '/\$catalogo\s*\[\s*\x27([^\x27]+)\x27\s*\]\s*=\s*(?!=)/', $evolucao, $atribuicoes );
			if ( count( $atribuicoes[0] ) !== count( $adicionais ) ) { return $vazio + array( 'erro' => 'option adicional sem declaração literal: ' . $ancora ); }
			foreach ( $adicionais as $adicional ) {
				$inicio = $adicional[0][1] + strlen( $adicional[0][0] );
				$entradas[ $adicional[1][0] ] = 'array(' . substr( $evolucao, $inicio, f3b_fecha_parenteses( $evolucao, $inicio ) - $inicio ) . ')';
			}
		}
		return array( 'entradas' => $entradas, 'ancora' => $ancora, 'secoes' => $secoes );
	}
	return $vazio;
}

/**
 * As FORMAS ilustrativas declaradas pelo pacote para cada identificador.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<string,string> Chave da folha para a forma declarada.
 */
function f3b_formas_declaradas( string $raiz ): array {
	$saida = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), 'formas' );

		if ( null === $corpo || ! str_contains( $corpo, "'forma'" ) ) {
			continue;
		}

		if ( preg_match_all( "/'([A-Za-z0-9_.]+)'\s*=>\s*array\(\s*'regex'\s*=>\s*'[^']*',\s*'forma'\s*=>\s*'([^']*)'/s", $corpo, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$saida[ $m[1] ] = $m[2];
			}
		}
	}

	return $saida;
}

/**
 * Toda folha operável do catálogo declara IMPACTO e EXEMPLO.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_campo_operavel_documentado( string $raiz ): array {
	$catalogo = f3b_catalogo_declarado( $raiz );

	if ( array() === $catalogo['entradas'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhum catálogo de options foi encontrado no pacote: sem a âncora que declara os campos operáveis não há sobre o que a regra valer, '
					. 'e uma regra sem escopo nunca acusa nada',
			),
			'medidas' => 1,
		);
	}

	$achados  = array();
	$medidas  = 0;
	$segredos = f3b_segredos_declarados( $raiz )['nomes'];
	$formas   = f3b_formas_declaradas( $raiz );
	$ancora   = $catalogo['ancora'];

	foreach ( $catalogo['entradas'] as $option => $bruto ) {
		$interior = f3b_interior_de_array( $bruto );

		if ( null === $interior ) {
			continue;
		}

		$declaracao = f3b_entradas_de_array( $interior );

		if ( 'true' !== strtolower( trim( $declaracao['operavel'] ?? '' ) ) ) {
			continue;
		}

		++$medidas;

		$secao = trim( $declaracao['secao'] ?? '' );

		if ( '' === $secao ) {
			$achados[] = $ancora . ': a option operável "' . $option . '" não declara "secao". A tela agrupa por assunto, '
				. 'e campo sem seção declarada só pode ser apresentado na ordem em que alguém o escreveu no catálogo';
		} elseif ( 1 !== preg_match( '/self::(SECAO_[A-Z_]+)/', $secao, $m ) || ! isset( $catalogo['secoes'][ $m[1] ] ) ) {
			$achados[] = $ancora . ': a option operável "' . $option . '" declara a seção ' . $secao
				. ', que não é uma das constantes de seção declaradas neste arquivo';
		}

		$subcampos = null !== ( $sub = f3b_interior_de_array( $declaracao['subcampos'] ?? '' ) )
			? f3b_entradas_de_array( $sub )
			: array();

		$folhas = array();

		if ( array() === $subcampos ) {
			$folhas[ $option ] = $declaracao;
		} else {
			foreach ( $subcampos as $chave => $cru ) {
				$dentro = f3b_interior_de_array( $cru );

				if ( null === $dentro ) {
					continue;
				}

				$folhas[ $option . '.' . $chave ] = f3b_entradas_de_array( $dentro );
			}
		}

		foreach ( $folhas as $folha => $campo ) {
			foreach ( array( 'impacto', 'exemplo' ) as $exigida ) {
				++$medidas;

				if ( '' === f3b_texto_literal( $campo[ $exigida ] ?? '' ) ) {
					$achados[] = $ancora . ': o campo operável "' . $folha . '" não declara "' . $exigida . '". '
						. ( 'impacto' === $exigida
							? 'Rótulo é o nome do campo e descrição é a definição dele; nenhum dos dois diz o que MUDA no site quando ele é preenchido, nem o que acontece enquanto está vazio'
							: 'Sem um valor ilustrativo, quem opera o site descobre a forma esperada errando e lendo a mensagem de recusa' );
				}
			}

			$exemplo = f3b_texto_literal( $campo['exemplo'] ?? '' );

			if ( in_array( $option, $segredos, true ) ) {
				++$medidas;

				if ( 1 === preg_match( '/[A-Za-z0-9]{16,}/', $exemplo, $m ) ) {
					$achados[] = $ancora . ': o campo "' . $folha . '" é declarado SEGREDO DO SITE e o exemplo dele carrega "'
						. substr( $m[0], 0, 24 ) . '", que tem forma de valor. Segredo não tem exemplo de valor: '
						. 'um valor plausível ali é uma credencial impressa na tela de administração de todo site que instalar este pacote';
				}
			}

			if ( isset( $formas[ $folha ] ) ) {
				++$medidas;

				if ( '' !== $exemplo && ! str_contains( $exemplo, $formas[ $folha ] ) ) {
					$achados[] = $ancora . ': o campo "' . $folha . '" tem a forma "' . $formas[ $folha ]
						. '" declarada pelo pacote, e o exemplo dele não a contém. O exemplo de identificador de fornecedor sai na forma '
						. 'da documentação do próprio fornecedor: um exemplo que PARECE um identificador real é um identificador real esperando para ser colado';
				}
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * decisoes.fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * O VOCABULÁRIO COMPARTILHADO, carregado do PACOTE QUE RODA A SUÍTE.
 *
 * NÃO da raiz varrida, e a distinção é o que dá piso a este cruzamento. Uma
 * classe PHP carregada por `require_once` entra no processo UMA vez: com o
 * vocabulário vindo da fixture, a primeira a ser medida definiria a classe e a
 * segunda receberia a da primeira — e o piso mediria uma coisa no ramo negativo
 * e outra no positivo, sem que nada dissesse isso. Pior, fixture sem o arquivo
 * faria o cruzamento inteiro ser PULADO, verde por não ter medido nada, que é a
 * forma mais silenciosa de um piso não existir.
 *
 * O vocabulário é fato DESTE pacote, como o validador de schema é: o que varia
 * de raiz para raiz é o CATÁLOGO, e é ele que a checagem confere contra o
 * vocabulário fixo.
 *
 * @return bool Verdadeiro quando a classe está disponível.
 */
function f3b_vocabulario_disponivel(): bool {
	if ( class_exists( 'F3Base_Vocabulario' ) ) {
		return true;
	}

	$arquivo = dirname( __DIR__, 2 ) . '/partilhado/includes/class-f3base-vocabulario.php';

	if ( ! is_file( $arquivo ) ) {
		return false;
	}

	/*
	 * `ABSPATH` PRECISA EXISTIR ANTES DO REQUIRE, e isto não é cerimônia.
	 *
	 * Todo arquivo de origem do `site-core` abre com a guarda
	 * `if ( ! defined( 'ABSPATH' ) ) { exit; }`, que existe para impedir que
	 * alguém alcance o arquivo direto pelo servidor web. Num processo de linha
	 * de comando sem a constante, esse `exit` NÃO lança exceção e NÃO imprime
	 * nada: ele encerra o processo inteiro com status zero, no meio da rodada.
	 * Foi exatamente o que aconteceu quando este cruzamento nasceu — a suíte e o
	 * piso paravam calados na checagem anterior à que carrega a classe, e a
	 * saída terminava sem resumo, sem erro e sem FALHA. Sucesso silencioso pela
	 * metade é pior que falha barulhenta, e este comentário existe para a
	 * próxima classe compartilhada não repetir o caminho.
	 *
	 * O valor não é usado para nada: a classe não toca no WordPress.
	 */
	if ( ! defined( 'ABSPATH' ) ) {
		define( 'ABSPATH', '/tmp/f3base-sem-wordpress/' );
	}

	require_once $arquivo;

	return class_exists( 'F3Base_Vocabulario' );
}

/**
 * A DECISÃO DO PACOTE TEM UMA FONTE SÓ, e o motivo dela está escrito.
 *
 * A regra 29 do contrato tirou da configuração todo valor com uma resposta
 * certa. O risco de fazer isso é trocar uma pergunta ao operador por um número
 * escondido: o valor sai do arquivo que alguém abre e vai para um catálogo que
 * ninguém lê, e daí a um mês está repetido como literal em três lugares — que é
 * exatamente o estado de antes, com uma casa a mais.
 *
 * ESTE DETECTOR É O QUE IMPEDE ISSO, e mede quatro coisas:
 *
 * 1. **A chave não voltou para a configuração.** Nem em `config/site.json`, nem
 *    declarada em `config/site.schema.json`. Decisão em dois arquivos é a
 *    divergência que a migração existia para fechar.
 * 2. **A chave só é lida pelo produtor.** Toda linha de código que nomeia a
 *    chave precisa chamar `F3Base_Imp_Decisoes::` na mesma linha. Um
 *    `F3Base_Imp_Config::obter()` sobrevivente leria vazio em silêncio.
 * 3. **Nenhum chamador repete o valor como PADRÃO.** `valor( 'x', <o valor> )`
 *    é uma segunda cópia da decisão dentro do código, e foi o estado real desta
 *    árvore antes da migração: 42 chamadas de leitura carregavam o valor
 *    declarado como default, e uma edição do arquivo deixaria as duas fontes
 *    discordando sem que nada acusasse.
 * 4. **Valor distintivo não vira constante.** Valor de texto com 8 caracteres ou
 *    mais não pode aparecer em `const X = '…'` nem em `define()` no implantador.
 *
 * O QUE ELE NÃO MEDE, e é declarado de propósito: literal usado em COMPARAÇÃO
 * (`'url' === $origem`) não é segunda fonte — é o código reconhecendo o
 * vocabulário em que a resposta vem, e proibi-lo tornaria impossível ramificar
 * sobre a própria decisão. E o `site-core` é OUTRO runtime: ele recebe os
 * valores por option e tem sanitizador próprio, que precisa conhecer o
 * vocabulário para recusar lixo — o catálogo do implantador não viaja com ele.
 *
 * A LEITURA DA SUÍTE (`f3b_decisoes()`) é a única segunda leitura permitida, e
 * ela é deliberada: auditor que usa o leitor do auditado não consegue acusar
 * defeito do leitor.
 *
 * SOBRE O MOTIVO, o que ele prova e o que não prova. Ele cobra que o motivo
 * exista, que tenha corpo e que não seja palavra por palavra o de outra
 * decisão. Julgar se a prosa diz o que aconteceria com outro valor é
 * conferência de quem lê — e afirmar que este código julga isso seria afirmar
 * mais do que ele mede, que é o defeito que este pacote persegue em todo lugar.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_decisoes_fonte_unica( string $raiz ): array {
	$decisoes       = f3b_decisoes( $raiz );
	$achados        = array();
	$medidas        = 0;
	$motivos_vistos = array();

	if ( array() === $decisoes ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/decisoes.tsv não entregou nenhuma decisão: catálogo ausente, ilegível ou sem uma única linha de três colunas — sem ele todo consumidor cai no lado seguro e o pacote entrega o contrário do que decidiu' ),
			'medidas' => 1,
		);
	}

	$config     = f3b_config( $raiz ) ?? array();
	$declaradas = array();
	f3b_achatar( $config, '', $declaradas );

	$schema    = json_decode( (string) @file_get_contents( $raiz . '/config/site.schema.json' ), true );
	$no_schema = array();

	if ( is_array( $schema ) ) {
		f3b_caminhos_do_schema( $schema, '', $no_schema );
	}

	/*
	 * O PRODUTOR e a LEITURA DA SUÍTE são os dois arquivos autorizados a nomear
	 * o caminho do catálogo; qualquer outro que o abra é um terceiro leitor.
	 */
	$autorizados = array(
		'includes/class-f3base-imp-decisoes.php',
		'suite/lib/regra.php',
		'config/decisoes.tsv',
		'ferramentas/classificacao-config.tsv',
		'suite/inventario.tsv',
		'suite/manifesto.tsv',
		'suite/afirmacoes.tsv',
		'suite/checagens/estatica.php',
		'MEMORIA-DECISOES.md',
		'README.md',
		'MANIFESTO.md',
	);

	$fontes = array();

	foreach ( f3b_arquivos( $raiz, array( 'php', 'js', 'mjs' ), f3b_excluidos() ) as $rel ) {
		if ( in_array( $rel, $autorizados, true ) ) {
			continue;
		}

		$fontes[ $rel ] = (string) file_get_contents( $raiz . '/' . $rel );
	}

	foreach ( $decisoes as $decisao ) {
		$chave = $decisao['chave'];

		/*
		 * 0. A CHAVE TEM FORMA DE CAMINHO PONTILHADO, e isto é o piso da guarda
		 * de comentário do produtor. O modo real de o catálogo ganhar uma linha
		 * fantasma é alguém DESLIGAR uma decisão pondo `#` na frente dela: a
		 * linha continua com as três colunas, com JSON válido e com motivo, e a
		 * única coisa que a mantém fora do catálogo é aquela guarda. Sem esta
		 * medição, derrubar a guarda não mudaria resultado nenhum — o cabeçalho
		 * de colunas cairia sozinho pela coluna de JSON — e o piso passaria a
		 * aprovar por acidente, que é pior do que piso nenhum porque continua
		 * verde.
		 */
		++$medidas;

		if ( 1 !== preg_match( '/^[a-z][a-z0-9_]*(?:\.[a-z0-9_-]+)*$/', $chave ) ) {
			$achados[] = 'a decisão "' . $chave . '" não tem forma de caminho pontilhado: linha de comentário ou lixo virou decisão, e decisão que ninguém escreveu de propósito é a pior de todas — ela responde e não tem dono';
		}

		/* 1. A chave não voltou para a configuração. */
		++$medidas;

		if ( isset( $declaradas[ $chave ] ) || isset( $no_schema[ $chave ] ) ) {
			$achados[] = 'a decisão "' . $chave . '" voltou a ser declarada em '
				. ( isset( $declaradas[ $chave ] ) ? 'config/site.json' : 'config/site.schema.json' )
				. ': decisão em dois arquivos é a divergência que a migração fechou, e o operador volta a ser perguntado por algo que só tem uma resposta certa';
		}

		/* 2 e 3. Quem nomeia a chave passa pelo produtor, e sem repetir o valor. */
		foreach ( $fontes as $rel => $src ) {
			foreach ( explode( "\n", $src ) as $numero => $linha ) {
				if ( ! str_contains( $linha, "'" . $chave . "'" ) && ! str_contains( $linha, '"' . $chave . '"' ) ) {
					continue;
				}

				++$medidas;

				/*
				 * NOMEAR a chave é legítimo: rótulo de checagem e mensagem ao
				 * operador precisam dizer de que decisão falam, e proibi-lo
				 * deixaria toda mensagem anônima. O que não pode é PASSAR a
				 * chave a outro leitor — é isso, e só isso, que cria a segunda
				 * fonte que lê vazio em silêncio.
				 */
				if ( str_contains( $linha, 'F3Base_Imp_Config::' ) ) {
					$achados[] = $rel . ':' . ( $numero + 1 ) . ' lê a decisão "' . $chave
						. '" por F3Base_Imp_Config: a chave saiu da configuração, então esta leitura devolve vazio em silêncio e o consumidor entrega o lado seguro achando que entregou a decisão';
					continue;
				}

				if ( 1 === preg_match( '/F3Base_Imp_Decisoes::valor\(\s*[\'"]' . preg_quote( $chave, '/' ) . '[\'"]\s*,/', $linha ) ) {
					$achados[] = $rel . ':' . ( $numero + 1 ) . ' repete um PADRÃO ao ler a decisão "' . $chave
						. '": o padrão é uma segunda cópia do valor dentro do código, e uma edição do catálogo deixaria as duas fontes discordando sem nada acusar. O lado seguro sai do cast, não de um literal';
				}
			}
		}

		/* 4. Valor de texto distintivo não vira constante em lugar nenhum. */
		foreach ( f3b_literais_da_decisao( $decisao['valor'] ) as $literal ) {
			++$medidas;

			foreach ( $fontes as $rel => $src ) {
				if ( ! str_starts_with( $rel, 'includes/' ) ) {
					continue;
				}

				if ( 1 === preg_match( '/(?:const\s+\w+\s*=|define\(\s*[\'"][^\'"]+[\'"]\s*,)\s*[\'"]' . preg_quote( $literal, '/' ) . '[\'"]/', $src ) ) {
					$achados[] = $rel . ' declara uma CONSTANTE com o valor "' . $literal . '", que é o valor da decisão "'
						. $chave . '": constante e catálogo concordam por coincidência, e trocar o catálogo deixaria a constante escrevendo no lugar antigo — sem erro nenhum, porque a gravação funciona';
				}
			}
		}

		/* O motivo é obrigatório e não pode ser o valor repetido em prosa. */
		++$medidas;

		if ( mb_strlen( $decisao['motivo'] ) < 80 ) {
			$achados[] = 'o motivo da decisão "' . $chave . '" tem ' . mb_strlen( $decisao['motivo'] )
				. ' caracteres: motivo curto não diz o que aconteceria se o valor fosse outro, e decisão sem o que a sustenta é um número que ninguém mais sabe explicar';
		}

		/*
		 * MOTIVO REPETIDO ENTRE DECISÕES é o modo real de este catálogo apodrecer.
		 * Um motivo copiado de uma linha para a outra não explica nenhuma das
		 * duas: ele descreve o bloco, e a pergunta que o catálogo faz é sobre o
		 * VALOR daquela linha. O detector não sabe julgar se a prosa diz o que
		 * aconteceria com outro valor — isso é conferência de quem lê —, mas
		 * sabe dizer que a mesma frase não pode sustentar duas decisões.
		 */
		++$medidas;

		if ( isset( $motivos_vistos[ $decisao['motivo'] ] ) ) {
			$achados[] = 'o motivo da decisão "' . $chave . '" é palavra por palavra o de "'
				. $motivos_vistos[ $decisao['motivo'] ]
				. '": motivo repetido descreve o bloco e não o valor, e nenhuma das duas decisões fica explicada';
		}

		$motivos_vistos[ $decisao['motivo'] ] = $chave;
	}

	/*
	 * O CRUZAMENTO COM O VOCABULÁRIO COMPARTILHADO, e é ele que torna duas
	 * fontes seguras.
	 *
	 * O `site-core` é outro runtime: ele recebe os valores por option e precisa
	 * conhecer o conjunto aceito para recusar lixo, e o catálogo do implantador
	 * não viaja com ele. Enquanto os dois lados escreviam o mesmo literal cada um
	 * por sua conta, eles concordavam por COINCIDÊNCIA: o catálogo podia trocar de
	 * modelo de atribuição e o sanitizador continuaria devolvendo o antigo como
	 * padrão, sem erro nenhum — a medição só passaria a guardar o toque errado.
	 *
	 * `F3Base_Vocabulario` passou a ser a fonte do CONJUNTO, e o catálogo continua
	 * sendo a fonte da ESCOLHA. Duas fontes com papéis diferentes só são seguras
	 * quando alguém as cruza, e é esta medição: toda decisão que o vocabulário
	 * declara governar precisa valer um dos valores que ele declara, e todo papel
	 * que ele fixa precisa achar no catálogo uma entrada com EXATAMENTE aquele
	 * slug.
	 */
	if ( f3b_vocabulario_disponivel() ) {
		$por_chave = array();

		foreach ( $decisoes as $decisao ) {
			$por_chave[ $decisao['chave'] ] = $decisao['valor'];
		}

		foreach ( F3Base_Vocabulario::decisoes_governadas() as $chave_governada => $aceitos ) {
			++$medidas;

			if ( ! array_key_exists( $chave_governada, $por_chave ) ) {
				$achados[] = 'F3Base_Vocabulario governa "' . $chave_governada . '" e o catálogo não a declara: o site-core reconhece um valor que ninguém escolhe, e o vocabulário passa a descrever um conjunto vazio';
				continue;
			}

			if ( ! in_array( $por_chave[ $chave_governada ], $aceitos, true ) ) {
				$achados[] = 'a decisão "' . $chave_governada . '" vale ' . json_encode( $por_chave[ $chave_governada ] )
					. ', que NÃO está no vocabulário que o site-core reconhece (' . json_encode( $aceitos ) . '): o implantador grava um valor que o sanitizador do outro runtime vai recusar ou trocar, e nenhum dos dois lados falha — o site só passa a servir outra coisa';
			}
		}

		foreach ( F3Base_Vocabulario::papeis_governados() as $papel => $slug_exigido ) {
			++$medidas;

			$achou_o_papel = false;

			foreach ( $decisoes as $decisao ) {
				if ( ! is_array( $decisao['valor'] ) || $papel !== ( $decisao['valor']['papel'] ?? null ) ) {
					continue;
				}

				$achou_o_papel = true;

				if ( $slug_exigido !== ( $decisao['valor']['slug'] ?? null ) ) {
					$achados[] = 'a entrada "' . $decisao['chave'] . '" ocupa o papel "' . $papel . '" com o slug "'
						. (string) ( $decisao['valor']['slug'] ?? '' ) . '", e o site-core procura "' . $slug_exigido
						. '": trocar o plugin no catálogo sem trocar o vocabulário deixa o módulo do outro runtime procurando o plugin antigo — e ele não falha, só nunca encontra';
				}
			}

			if ( ! $achou_o_papel ) {
				$achados[] = 'F3Base_Vocabulario fixa o slug do papel "' . $papel . '" e NENHUMA entrada do catálogo declara esse papel: o site-core procura um plugin que este pacote não instala';
			}
		}
	}

	/*
	 * REGISTROS: as três regras que o schema cobrava de `plugins.instalaveis`
	 * antes de ele sair da configuração, medidas onde o valor mora agora.
	 * Migração que deixa uma regra para trás é pior que migração nenhuma,
	 * porque o arquivo fica menor e a defesa some junto.
	 */
	foreach ( $decisoes as $decisao ) {
		if ( ! is_array( $decisao['valor'] ) || ! isset( $decisao['valor']['slug'] ) ) {
			continue;
		}

		$registro = $decisao['valor'];

		foreach ( array( 'slug', 'papel', 'origem' ) as $obrigatorio ) {
			++$medidas;

			if ( '' === trim( (string) ( $registro[ $obrigatorio ] ?? '' ) ) ) {
				$achados[] = 'a entrada "' . $decisao['chave'] . '" não declara ' . $obrigatorio
					. ': entrada de plugin sem slug, sem papel ou sem origem não resolve, e o laço a percorre em silêncio';
			}
		}

		$digesto = trim( (string) ( $registro['sha256'] ?? '' ) );

		if ( '' === $digesto ) {
			continue;
		}

		++$medidas;

		if ( 1 !== preg_match( '/^[0-9a-f]{64}$/', $digesto ) ) {
			$achados[] = 'o sha256 de "' . $decisao['chave'] . '" não são 64 hexadecimais minúsculos: digesto fora da forma não confere nada e promete conferência que não acontece';
		}

		++$medidas;

		if ( 'url' !== (string) ( $registro['origem'] ?? '' ) ) {
			$achados[] = 'a entrada "' . $decisao['chave'] . '" declara sha256 com origem "'
				. (string) ( $registro['origem'] ?? '' ) . '": digesto só faz sentido no artefato que ESTE pacote escolhe pela URL — prometê-lo sobre o que o WordPress.org serve é conferir o que ninguém controla';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Os literais de TEXTO distintivos de um valor de decisão.
 *
 * Só texto, e só com 8 caracteres ou mais. Número e booleano são ambíguos por
 * natureza — `2` e `true` aparecem em toda linha de código —, e palavra curta
 * como `post` ou `page` é vocabulário do WordPress antes de ser valor de
 * decisão. Um detector que os perseguisse produziria dezenas de achados falsos,
 * e detector com achado falso é desligado pelo primeiro que se cansa dele.
 *
 * @param mixed $valor Valor da decisão.
 * @return array<int,string>
 */
function f3b_literais_da_decisao( $valor ): array {
	if ( is_string( $valor ) ) {
		return mb_strlen( $valor ) >= 8 ? array( $valor ) : array();
	}

	if ( ! is_array( $valor ) ) {
		return array();
	}

	$saida = array();

	foreach ( $valor as $item ) {
		$saida = array_merge( $saida, f3b_literais_da_decisao( $item ) );
	}

	return $saida;
}

/* -------------------------------------------------------------------------
 * tela.fala_portugues_comum
 * ---------------------------------------------------------------------- */

/**
 * A TELA FALA PORTUGUÊS COMUM, e o vocabulário interno fica no log.
 *
 * Quem abre a página do implantador quer três respostas: o site está no ar? o
 * que falhou? o que falta eu fazer? Nada mais. Palavra que só faz sentido para
 * quem escreveu este pacote — gate, veredito, teto e piso, pendência de fase,
 * eixo de convergência, condição de aplicabilidade — não responde a nenhuma das
 * três, e na tela ela só serve para o leitor achar que o problema é dele.
 *
 * O QUE ESTE DETECTOR MEDE: nenhuma frase destinada à TELA — as passadas em
 * `tela` e em `operador` — carrega o vocabulário interno, e nenhuma delas é um
 * parágrafo. O log continua com o texto completo, e é lá que essas palavras
 * moram.
 *
 * O que ele NÃO mede: a mensagem completa da linha. Ela é o log, e o log é para
 * quem está depurando — restringir o vocabulário dele empobreceria a única
 * fonte que explica POR QUE algo aconteceu.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_tela_fala_portugues_comum( string $raiz ): array {
	$proibidas = array(
		'gate',
		'veredito',
		'teto e piso',
		'pendência de fase',
		'pré-condição',
		'convergência',
		'condição de aplicabilidade',
		'autodesativação',
		'idempotência',
		'leitura de volta',
		'BLOCKED',
		'WAIVED',
		'N/A',
	);

	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$fonte = (string) file_get_contents( $raiz . '/' . $rel );

		/*
		 * A frase da tela é o que vem depois de `'tela' =>` ou `'operador' =>`,
		 * até o fim da chamada de tradução. Só as literais são medidas: o que
		 * chega por variável não dá para ler aqui, e afirmar sobre ele seria
		 * afirmar mais do que se mede.
		 */
		/*
		 * A JANELA depois de `'tela' =>` ou `'operador' =>` é lida inteira, e
		 * TODAS as literais traduzíveis dentro dela entram na medição. Uma
		 * expressão ternária tem duas frases e um `sprintf` tem a sua depois de
		 * um comentário de tradutor: uma expressão regular que só casasse a
		 * forma simples mediria a minoria dos casos e ficaria verde por não
		 * enxergar o resto.
		 */
		$frases = array();

		if ( preg_match_all( "/'(?:tela|operador)'\s*=>/u", $fonte, $marcas, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $marcas[0] as $marca ) {
				$janela = mb_substr( $fonte, 0, 0 ) . substr( $fonte, (int) $marca[1], 900 );

				if ( preg_match_all( "/__\(\s*'((?:[^'\\\\]|\\\\.)*)'\s*,\s*'f3base'\s*\)/u", $janela, $literais ) ) {
					foreach ( $literais[1] as $literal ) {
						$frases[] = $literal;
					}
				}
			}
		}

		foreach ( $frases as $frase ) {
			++$medidas;

			foreach ( $proibidas as $palavra ) {
				if ( false !== mb_stripos( $frase, $palavra ) ) {
					$achados[] = $rel . ': a frase da tela usa "' . $palavra . '" — «' . mb_substr( $frase, 0, 70 )
						. '». Quem lê quer saber se o site está no ar e o que falta fazer; esta palavra só faz sentido para quem escreveu o pacote, e o lugar dela é o log';
				}
			}

			++$medidas;

			if ( mb_strlen( $frase ) > 200 ) {
				$achados[] = $rel . ': a frase da tela tem ' . mb_strlen( $frase ) . ' caracteres — «'
					. mb_substr( $frase, 0, 60 ) . '…». Uma linha por assunto: o parágrafo inteiro é o log';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* =========================================================================
 * estatica.residencia_de_chave_derivada
 *
 * O DEFEITO MEDIDO, num log de implantação real. Numa instalação limpa o
 * relatório imprimiu: *"pré-condição ausente: 3 chave(s) de
 * `contato.controlador` está(ão) vazia(s) EM CONFIG/SITE.JSON — … Caminho de
 * saída: preencha … em config/site.json e execute de novo"*. E
 * `contato.controlador` não existe em `config/site.json`: ele mora em
 * `config/projeto.json`. Quem seguisse a instrução editava o arquivo errado, as
 * chaves não passavam a existir, a política ficava em `draft` para sempre e a
 * convergência nunca fechava — a mensagem que existe para desbloquear o
 * operador era a que o prendia.
 *
 * A CAUSA NÃO ERA A FRASE. O nome do arquivo estava DIGITADO dentro da
 * mensagem: um fato sobre o pacote escrito à mão num texto que nada revalida —
 * a mesma família de defeito que esta suíte já recusa em versão repetida em
 * constante, em decisão copiada como padrão de leitura e em contrato de copy
 * congelado no banco. Migrar uma chave de arquivo é uma edição de JSON, e toda
 * mensagem que a citasse continuaria dizendo o arquivo antigo, verde, para
 * sempre. Corrigir só a frase deixaria a próxima migração reabrir o buraco.
 *
 * AS DUAS CLÁUSULAS, e cada uma vale onde a outra não alcança:
 *
 * 1. **No implantador, o nome do arquivo é DERIVADO.** Nenhuma string
 *    traduzível de `includes/` pode conter o caminho de um arquivo de
 *    configuração: quem responde onde uma chave mora é
 *    `F3Base_Imp_Residencia`, que cruza o que cada leitor declara. Esta é a
 *    cláusula que pega o defeito medido — nele a chave chegava por `%s` e não
 *    aparecia na string, então uma regra que só comparasse "chave citada" com
 *    "arquivo citado" seria CEGA justamente para o caso real.
 * 2. **Fora do implantador, a chave citada precisa MORAR no arquivo citado.**
 *    O `site-core` é outro runtime e não carrega o derivador — ele fala dos
 *    arquivos do implantador de fora. A regra que sobra ali é a verificável:
 *    string que nomeia um arquivo de configuração E um caminho pontilhado que
 *    é chave declarada precisa nomear o arquivo em que essa chave está.
 *
 * OS ARQUIVOS NÃO SÃO ESCRITOS AQUI. Eles saem da constante `ARQUIVO` de cada
 * leitor — `F3Base_Imp_Config` e `F3Base_Imp_Projeto` —, lida do código. Um
 * detector que digitasse os nomes seria a terceira cópia do fato que ele existe
 * para proibir.
 *
 * O QUE ELE NÃO MEDE, declarado: caminho pontilhado que NÃO é chave declarada
 * de nenhum dos dois arquivos é ignorado — `mcp.autoteste` e
 * `privacidade.controlador_identificado` são nomes de checagem, e proibi-los
 * calaria toda mensagem que diz de qual linha fala. E a cláusula 2 não lê
 * negação: uma frase que dissesse "a chave X não existe em config/site.json"
 * seria acusada mesmo estando certa. Ela não existe nesta árvore, e a saída,
 * se um dia existir, é nomear o arquivo em que a chave ESTÁ.
 * ====================================================================== */

/**
 * Os arquivos de configuração do pacote, LIDOS da constante de cada leitor.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<string,string> Caminho do arquivo => leitor que o declara.
 */
function f3b_arquivos_de_config( string $raiz ): array {
	$saida = array();

	foreach ( array( 'includes/class-f3base-imp-projeto.php', 'includes/class-f3base-imp-config.php' ) as $leitor ) {
		if ( ! is_file( $raiz . '/' . $leitor ) ) {
			continue;
		}

		if ( 1 === preg_match( '/const\s+ARQUIVO\s*=\s*\'([^\']+\.json)\'/', f3b_codigo_php( $raiz . '/' . $leitor ), $casamento ) ) {
			$saida[ $casamento[1] ] = $leitor;
		}
	}

	return $saida;
}

/**
 * As STRINGS TRADUZÍVEIS de um código PHP já sem comentário.
 *
 * @param string $src Código PHP.
 * @return array<int,string> Literais, sem as aspas.
 */
function f3b_literais_traduziveis( string $src ): array {
	$re = '/\b(?:__|_e|_x|_n|esc_html__|esc_attr__|esc_html_e|esc_attr_e)\(\s*(\'(?:[^\'\\\\]|\\\\.)*\'|"(?:[^"\\\\]|\\\\.)*")/s';

	if ( ! preg_match_all( $re, $src, $casamentos ) ) {
		return array();
	}

	$saida = array();

	foreach ( $casamentos[1] as $bruto ) {
		$saida[] = substr( $bruto, 1, -1 );
	}

	return $saida;
}

/**
 * Nenhuma mensagem de runtime AFIRMA em que arquivo uma chave mora.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_residencia_de_chave_derivada( string $raiz ): array {
	$leitores = f3b_arquivos_de_config( $raiz );

	if ( count( $leitores ) < 2 ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'âncora ausente: não foi possível LER os dois arquivos de configuração da constante ARQUIVO dos leitores '
					. '(includes/class-f3base-imp-projeto.php e includes/class-f3base-imp-config.php). Sem eles não há o que derivar '
					. 'nem o que comparar, e um detector sem escopo nunca acusa nada — que é pior que detector nenhum, porque continua verde',
			),
			'medidas' => 1,
		);
	}

	$arquivos  = array_keys( $leitores );
	$residente = array();

	foreach ( $arquivos as $arquivo ) {
		$dados  = json_decode( (string) @file_get_contents( $raiz . '/' . $arquivo ), true );
		$chaves = array();

		if ( is_array( $dados ) ) {
			f3b_achatar( $dados, '', $chaves );
		}

		foreach ( array_keys( $chaves ) as $chave ) {
			$residente[ $chave ]   = $residente[ $chave ] ?? array();
			$residente[ $chave ][] = $arquivo;
		}
	}

	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$no_implantador = str_starts_with( $rel, 'includes/' );

		if ( ! $no_implantador && ! str_starts_with( $rel, 'fontes/' ) && ! str_starts_with( $rel, 'partilhado/' ) ) {
			continue;
		}

		foreach ( f3b_literais_traduziveis( f3b_codigo_php( $raiz . '/' . $rel ) ) as $literal ) {
			/*
			 * TODA mensagem de runtime CONTA como unidade medida, e não só as
			 * que nomeiam um arquivo. No pacote correto nenhuma nomeia, e um
			 * denominador que só contasse essas fecharia em zero — que a suíte
			 * lê como escopo vazio e reprova, com razão: "nada foi medido" e
			 * "nada estava errado" não podem sair com o mesmo número.
			 */
			++$medidas;

			$citados = array();

			foreach ( $arquivos as $arquivo ) {
				if ( str_contains( $literal, $arquivo ) ) {
					$citados[] = $arquivo;
				}
			}

			if ( array() === $citados ) {
				continue;
			}

			/* 1. No implantador, o arquivo é derivado da chave — nunca digitado. */
			if ( $no_implantador ) {
				$achados[] = $rel . ': uma mensagem de runtime traz "' . implode( '", "', $citados )
					. '" DIGITADO — «' . mb_substr( $literal, 0, 90 ) . '…». O arquivo em que uma chave mora é fato do pacote e muda com uma edição de JSON: '
					. 'quem responde é F3Base_Imp_Residencia, cruzando o que cada leitor declara. Foi assim que a guarda do controlador passou a mandar preencher '
					. 'contato.controlador em config/site.json, onde essa chave não existe';
				continue;
			}

			/* 2. Fora dele, a chave citada precisa morar no arquivo citado. */
			$sem_arquivo = str_replace( $arquivos, ' ', $literal );

			if ( ! preg_match_all( '/[a-z_][a-z0-9_]*(?:\.[a-z0-9_*-]+)+/i', $sem_arquivo, $tokens ) ) {
				continue;
			}

			foreach ( array_unique( $tokens[0] ) as $token ) {
				$chave = implode( '.', array_map( static fn( string $s ): string => ctype_digit( $s ) ? '*' : $s, explode( '.', $token ) ) );

				if ( ! isset( $residente[ $chave ] ) ) {
					continue;
				}

				foreach ( $citados as $arquivo ) {
					++$medidas;

					if ( in_array( $arquivo, $residente[ $chave ], true ) ) {
						continue;
					}

					$achados[] = $rel . ': a mensagem cita a chave "' . $token . '" ao lado de "' . $arquivo
						. '", e essa chave não é declarada nesse arquivo — ela mora em ' . implode( ', ', $residente[ $chave ] )
						. '. Quem seguir a instrução abre o arquivo errado, não acha a chave e não tem como sair';
				}
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * TODA OPTION CITADA NO MANUAL DO AGENTE EXISTE NO CATÁLOGO.
 *
 * O DEFEITO MEDIDO: `F3Base_Como_Usar::nao_faca()` mandava gravar
 * `f3base_tracking` e `f3base_leads`, e NENHUMA DAS DUAS EXISTE. O manual é a
 * primeira coisa que um agente de manutenção lê antes de mexer no site, e o
 * caminho que ele dá é o caminho que o agente toma: gravar uma option que módulo
 * nenhum lê não falha, não avisa e não muda nada. O que o agente conclui é que o
 * plugin não faz o que o próprio manual dele afirma — e a partir daí ele resolve
 * por fora, que é exatamente o que o manual existe para impedir.
 *
 * O QUE ESTE DETECTOR MEDE, e por que ele não é a mesma coisa que a sonda. A
 * sonda `mcp.como_usar_sai_do_registro` exige que a LISTA DE ASSUNTOS venha do
 * registro de módulos; ela não olha para o texto do "não faça", que é prosa. Um
 * nome de option digitado dentro de uma frase passa por ela inteiro. Aqui o
 * cruzamento é com o CATÁLOGO: toda grafia `f3base_*` que aparecer no arquivo do
 * manual precisa ser uma option declarada, ou uma âncora que o próprio pacote
 * publica.
 *
 * ESCOPO VAZIO NÃO APROVA: sem o manual ou sem o catálogo, a linha reprova
 * dizendo qual dos dois faltou.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_options_citadas_existem( string $raiz ): array {
	$catalogo = f3b_catalogo_declarado( $raiz );
	$manuais  = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		if ( ! str_contains( basename( $rel ), 'como-usar' ) ) {
			continue;
		}

		$manuais[ $rel ] = f3b_codigo_php( $raiz . '/' . $rel );
	}

	if ( array() === $manuais ) {
		return array(
			'ok'      => false,
			'achados' => array( 'nenhum arquivo de manual (`*como-usar*.php`) foi encontrado no pacote: sem ele esta regra não tem sobre o que valer, e escopo vazio não é aprovação' ),
			'medidas' => 1,
		);
	}

	if ( array() === $catalogo['entradas'] ) {
		return array(
			'ok'      => false,
			'achados' => array( 'nenhum catálogo de options foi encontrado no pacote: sem a âncora não há contra o que cruzar os nomes citados no manual' ),
			'medidas' => 1,
		);
	}

	/*
	 * AS DUAS ÂNCORAS QUE NÃO ESTÃO NO CATÁLOGO são declarações SOBRE ele —
	 * quem gravou cada chave e quais delas estão liberadas na tela —, e o
	 * próprio gravador único as publica em `proprias()`. Citá-las no manual é
	 * legítimo, e uma lista escrita aqui divergiria da de lá.
	 */
	$conhecidas = array_keys( $catalogo['entradas'] );

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( preg_match_all( "/const\s+OPTION_[A-Z_]+\s*=\s*'(f3base_[a-z0-9_]+)'/", $src, $ms ) ) {
			$conhecidas = array_merge( $conhecidas, $ms[1] );
		}
	}

	$conhecidas = array_values( array_unique( array_map( 'strval', $conhecidas ) ) );
	$achados    = array();
	$medidas    = 0;
	$deriva     = false;

	foreach ( $manuais as $rel => $src ) {
		/*
		 * A DERIVAÇÃO CONTA COMO MEDIDA, e é a saída CERTA para este defeito: um
		 * manual que lê `options_que_controlam()` do registro não pode citar uma
		 * option que não existe, porque quem declara o nome é quem o consome.
		 * Sem esta cláusula, corrigir o defeito faria a linha reprovar por
		 * "escopo vazio" — o detector cobraria de volta justamente o literal que
		 * ele existe para tirar.
		 */
		if ( str_contains( $src, 'options_que_controlam()' ) ) {
			$deriva = true;
			++$medidas;
		}

		if ( ! preg_match_all( '/\bf3base_[a-z0-9_]+\b/', $src, $citadas ) ) {
			continue;
		}

		foreach ( array_unique( $citadas[0] ) as $citada ) {
			++$medidas;

			if ( in_array( $citada, $conhecidas, true ) ) {
				continue;
			}

			$achados[] = $rel . ': o manual que o agente lê antes de mexer no site cita a option "' . $citada
				. '", e ela NÃO existe no catálogo declarado em ' . $catalogo['ancora']
				. '. Gravar uma option que módulo nenhum lê não falha, não avisa e não muda nada — e quem seguiu a instrução conclui que o plugin não faz o que o manual dele afirma. Derive o nome do registro (options_que_controlam) em vez de digitá-lo';
		}
	}

	if ( 0 === $medidas && ! $deriva ) {
		return array(
			'ok'      => false,
			'achados' => array(
				implode( ', ', array_keys( $manuais ) ) . ': o manual não cita option nenhuma e não deriva nome nenhum do registro. '
					. 'Ele existe para dizer POR ONDE mudar cada coisa, e um manual sem o nome do ajuste manda o agente procurar sozinho',
			),
			'medidas' => 1,
		);
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/** Ordem de marcas e conjunto fechado; o mesmo detector roda nos dois ramos de fixture. */
function f3b_ck_robos_conhecidos_ordenados( string $raiz ): array {
	$arquivo = $raiz . '/fontes/plugin/dados/robos-conhecidos.tsv';
	$achados = array(); $linhas = array(); $familias = array();
	foreach ( is_file( $arquivo ) ? (array) file( $arquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ) : array() as $l ) {
		if ( str_starts_with( $l, '#' ) ) { continue; }
		$v = explode( "\t", $l );
		if ( count( $v ) < 4 || ! in_array( $v[2], array( 'busca','treino-ia','resposta-ia','social','seo','monitor','generico' ), true ) ) { $achados[] = 'Linha ou classe inválida: ' . $l; continue; }
		if ( isset( $familias[ $v[0] ] ) ) { $achados[] = 'Família repetida: ' . $v[0]; }
		$familias[ $v[0] ] = true;
		foreach ( $linhas as $anterior ) { if ( false !== stripos( $v[1], $anterior[1] ) ) { $achados[] = $anterior[1] . ' precisa vir depois de ' . $v[1]; } }
		$linhas[] = $v;
	}
	if ( ! $linhas ) { $achados[] = 'Sem declaração de robôs.'; }
	return array( 'ok' => ! $achados, 'achados' => $achados, 'medidas' => count( $linhas ) );
}
