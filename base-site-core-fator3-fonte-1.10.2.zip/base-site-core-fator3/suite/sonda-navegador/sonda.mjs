/**
 * SONDA DE NAVEGADOR: o cliente REAL, num Chromium REAL, dirigido só por rolagem.
 *
 * POR QUE ELA EXISTE, e a resposta é uma contagem. Quatro releases seguidas a
 * bancada de JavaScript aprovou o que o navegador reprovou:
 *
 * - **1.3.3** — o retorno intermediário do observador. A bancada disparava
 *   `{ isIntersecting: true|false }` à mão, sem razão de interseção; o navegador
 *   entrega uma RAZÃO e avisa quando ela cruza uma linha declarada, inclusive
 *   caindo abaixo dela com o alvo ainda sobreposto. A bancada nunca produzia
 *   esse retorno, e por isso aprovou um rearme que o navegador quase nunca
 *   alcançava: 80 linhas em produção, todas com `ocorrencia = 1`.
 * - **1.3.4** — o contador entre carregamentos. O contador virou durável e a
 *   linha ficou volátil; a bancada media um carregamento só e não via o buraco.
 * - **1.3.5** — o envio confirmando enfileiramento em vez de entrega, com três
 *   lacunas listadas na própria release.
 * - **1.3.6** — esta.
 *
 * A bancada SIMULA `IntersectionObserver`. O navegador TEM um. Nenhum
 * comentário conserta essa diferença, e nenhuma quantidade de asserção sobre uma
 * simulação prova o que a implementação de verdade faz. Só medir no navegador.
 *
 * COMO ELA RODA À MÃO:
 *
 *   cd suite/sonda-navegador
 *   node servidor.mjs <diretorio-pub> <porta> &
 *   node sonda.mjs <porta> [caminho-do-chromium]
 *
 * O `<diretorio-pub>` traz `dados.json` — a declaração GERADA do TSV na hora,
 * nunca versionada — e `f3base-tracking.js`, que é o arquivo ENTREGUE. Quem
 * monta os dois na suíte é `navegador.comportamento_real`.
 *
 * A DECLARAÇÃO DA PÁGINA MORA AQUI, e `servidor.mjs` a importa. Ela é geometria
 * de site real: seções de uma tela cada, documento de quatro telas, faixa
 * rolável de três. Duas cópias dela — uma no servidor, outra na sonda — fariam a
 * afirmação da sonda descrever uma página que o servidor não serve.
 *
 * @package F3Base\Suite
 */

import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

/**
 * A PÁGINA SERVIDA, declarada.
 *
 * `secoes` são os NOMES, e a classe de cada uma é `prefixoSecao + nome` — o
 * prefixo vem de `dados.json`, que é o mesmo campo que o cliente lê. Escrever a
 * classe aqui faria a sonda medir uma página que o tema não carimba.
 */
export const PAGINA = {
	secoes: [ 'abertura', 'pecas', 'comando-unico', 'faq' ],
	alturaDaSecao: 820,
	preenchimento: 40,
	janela: { largura: 1280, altura: 900 }
};

/** A altura total de uma seção, com o preenchimento: exatamente uma tela. */
export const TELA = PAGINA.alturaDaSecao + ( 2 * PAGINA.preenchimento );

/** A faixa rolável: o documento menos a janela. */
export const ROLAVEL = TELA * ( PAGINA.secoes.length - 1 );

/**
 * Uma fração exata da faixa rolável, em pixels.
 *
 * OS PERCURSOS SÃO EM PIXELS, e não em percentual arredondado, porque um pixel
 * de diferença muda `isIntersecting` de falso para verdadeiro na borda de uma
 * seção — e é justamente esse par que a sonda mede. Percentual arredondado
 * transformaria a afirmação em sorteio.
 *
 * @param {number} n Numerador.
 * @param {number} d Denominador.
 * @return {number} Deslocamento em pixels.
 */
function fracao( n, d ) {
	const px = ( ROLAVEL * n ) / d;

	if ( ! Number.isInteger( px ) ) {
		throw new Error( 'percurso com fração não exata: ' + n + '/' + d + ' de ' + ROLAVEL );
	}

	return px;
}

/**
 * OS DOIS PERCURSOS, e cada um responde uma pergunta diferente.
 *
 * `longo` é a leitura inteira: desce até o fim, volta ao topo e desce de novo,
 * com um ocultamento no meio. Ele exercita o ciclo completo — todas as seções
 * saem inteiras do campo de visão e voltam — e é o percurso em que a sequência
 * de ocorrências fica rica.
 *
 * `curto` é o percurso que o usuário descreveu e que o site dele mostrou: sobe
 * três passos perto do fim e desce de novo. Nele as seções do topo NUNCA
 * reentram — e é correto que não reentrem, porque ninguém voltou a elas —, e as
 * duas de baixo reentram. É o percurso em que a assimetria da 1.3.3 aparece:
 * `faq` desce até a razão 0,1 sem nunca sair inteira da tela, e um código que
 * decide a saída por `isIntersecting` a prende em uma ocorrência só.
 */
export const PERCURSOS = {
	longo: [
		{ ir: [ 0, fracao( 1, 5 ), fracao( 2, 5 ), fracao( 3, 5 ), fracao( 4, 5 ), ROLAVEL ] },
		{ ocultar: true },
		{ ir: [ fracao( 7, 10 ), fracao( 4, 10 ), fracao( 1, 10 ), 0 ] },
		{ ir: [ fracao( 2, 10 ), fracao( 5, 10 ), fracao( 8, 10 ), ROLAVEL ] },
		{ ocultar: true }
	],
	curto: [
		{ ir: [ 0, TELA, 2 * TELA, ROLAVEL ] },
		{ ir: [ fracao( 9, 10 ), fracao( 8, 10 ), fracao( 7, 10 ) ] },
		{ ir: [ ROLAVEL ] },
		{ ocultar: true }
	]
};

/**
 * Onde o Chromium pode estar. Ausência fecha N/A com a condição declarada, e
 * nunca OK: um ambiente sem navegador não é um pacote aprovado.
 */
export const CHROMIUM_CANDIDATOS = [
	'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
	'/opt/pw-browsers/chromium/chrome-linux/chrome'
];

/**
 * Roda os dois percursos e devolve o que chegou ao servidor.
 *
 * @param {number} porta    Porta do servidor da sonda.
 * @param {string} chromium Caminho do executável.
 * @return {Promise<Object>} Veredito bruto, por percurso.
 */
export async function medir( porta, chromium ) {
	const { chromium: motor } = createRequire( import.meta.url )( 'playwright' );
	const base = 'http://127.0.0.1:' + porta;
	const nav = await motor.launch( { executablePath: chromium } );
	const saida = {};
	// Dependência real: cookie negado fecha a coleta; aceite explícito reabre na mesma página.
	const privacidade = await nav.newContext( { viewport: { width: PAGINA.janela.largura, height: PAGINA.janela.altura } } );
	await privacidade.addCookies( [ { name: 'f3base_consentimento', value: 'denied', url: base } ] );
	const teste = await privacidade.newPage();
	await fetch( base + '/zerar' );
	await teste.goto( base + '/', { waitUntil: 'load' } );
	await teste.evaluate( () => {
		window.scrollTo( 0, document.documentElement.scrollHeight );
		window.dispatchEvent( new Event( 'pagehide' ) );
	} );
	await teste.waitForTimeout( 450 );
	const negado = await ( await fetch( base + '/recebidos' ) ).json();
	const semIdentificador = await teste.evaluate( () => ! localStorage.getItem( 'f3base_visitante' ) );
	await teste.evaluate( () => window.f3baseConsentimento.definir( 'granted' ) );
	await teste.waitForTimeout( 350 );
	await teste.evaluate( () => window.dispatchEvent( new Event( 'pagehide' ) ) );
	await teste.waitForTimeout( 450 );
	const aceito = await ( await fetch( base + '/recebidos' ) ).json();
	saida.consentimento = { negado_sem_lotes: negado.length === 0, negado_sem_identificador: semIdentificador, aceite_coleta: aceito.some( ( lote ) => lote.metricas && lote.eventos?.length ) };
	await privacidade.close();

	for ( const [ nome, passos ] of Object.entries( PERCURSOS ) ) {
		await fetch( base + '/zerar' );

		/*
		 * CONTEXTO NOVO A CADA PERCURSO, e ele não é higiene: o contador de
		 * travessias vive no `localStorage` e ATRAVESSA carregamentos de
		 * propósito desde a 1.3.4. Reaproveitar o contexto faria o segundo
		 * percurso começar com o orçamento e as ocorrências do primeiro, e a
		 * sequência afirmada aqui descreveria a soma dos dois.
		 */
		const ctx = await nav.newContext( { viewport: { width: PAGINA.janela.largura, height: PAGINA.janela.altura } } );
		const pag = await ctx.newPage();
		const erros = [];

		pag.on( 'pageerror', ( e ) => erros.push( 'PAGEERROR: ' + String( e ).slice( 0, 300 ) ) );
		pag.on( 'console', ( m ) => {
			if ( 'error' === m.type() ) {
				erros.push( 'CONSOLE: ' + m.text().slice( 0, 250 ) );
			}
		} );

		await pag.goto( base + '/', { waitUntil: 'load' } );
		await pag.waitForTimeout( 900 );

		const geometria = await pag.evaluate( () => ( {
			documento: document.documentElement.scrollHeight,
			janela: window.innerHeight,
			secoes: Array.from( document.querySelectorAll( 'section' ) ).map( ( s ) => ( {
				classe: s.className,
				topo: s.offsetTop,
				altura: s.offsetHeight
			} ) )
		} ) );

		for ( const passo of passos ) {
			if ( passo.ocultar ) {
				await pag.evaluate( () => {
					Object.defineProperty( document, 'visibilityState', { value: 'hidden', configurable: true } );
					document.dispatchEvent( new Event( 'visibilitychange' ) );
				} );
				await pag.waitForTimeout( 450 );
				await pag.evaluate( () => {
					Object.defineProperty( document, 'visibilityState', { value: 'visible', configurable: true } );
					document.dispatchEvent( new Event( 'visibilitychange' ) );
				} );
				await pag.waitForTimeout( 200 );
				continue;
			}

			for ( const px of passo.ir ) {
				await pag.evaluate( ( y ) => window.scrollTo( { top: y, behavior: 'instant' } ), px );
				await pag.waitForTimeout( 320 );
			}
		}

		const guardado = await pag.evaluate( () => {
			try {
				return JSON.parse( window.localStorage.getItem( 'f3base_sessao' ) || 'null' );
			} catch ( e ) {
				return null;
			}
		} );

		const recebidos = await ( await fetch( base + '/recebidos' ) ).json();
		const ocorrencias = {};

		for ( const lote of recebidos ) {
			for ( const e of lote.eventos || [] ) {
				const chave = e.gatilho + '|' + ( e.detalhe || '' );

				( ocorrencias[ chave ] = ocorrencias[ chave ] || [] ).push( Number( e.ocorrencia ) );
			}
		}

		for ( const chave of Object.keys( ocorrencias ) ) {
			ocorrencias[ chave ].sort( ( a, b ) => a - b );
		}

		saida[ nome ] = {
			erros,
			geometria,
			lotes: recebidos.length,
			linhas: recebidos.reduce( ( t, l ) => t + ( l.eventos || [] ).length, 0 ),
			cortadas: recebidos.map( ( l ) => Number( l.cortados || 0 ) ),
			ocorrencias,
			visita: guardado ? { gastas: guardado.gastas, cortadas: guardado.cortadas, pendentes: ( guardado.pendentes || [] ).length } : null
		};

		await ctx.close();
	}

	await nav.close();

	return saida;
}

/*
 * ENTRADA DE LINHA DE COMANDO, e o guarda existe porque `servidor.mjs` IMPORTA
 * este arquivo pela declaração da página. Sem ele, subir o servidor abriria um
 * Chromium.
 */
if ( process.argv[ 1 ] && import.meta.url === pathToFileURL( process.argv[ 1 ] ).href ) {
	const porta = Number( process.argv[ 2 ] || 8731 );
	const chromium = process.argv[ 3 ] || CHROMIUM_CANDIDATOS[ 0 ];

	medir( porta, chromium )
		.then( ( r ) => process.stdout.write( JSON.stringify( r, null, 1 ) ) )
		.catch( ( e ) => {
			process.stdout.write( JSON.stringify( { falha: String( e && e.message ? e.message : e ) } ) );
			process.exitCode = 1;
		} );
}

/* Mantém `fileURLToPath` referenciado para quem importe o módulo como caminho. */
export const ARQUIVO_DESTA_SONDA = fileURLToPath( import.meta.url );
