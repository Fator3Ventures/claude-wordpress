<?php
/** Conteúdo sintético idêntico para comparar custos em instalações descartáveis. */
declare(strict_types=1);
$site=(string)getenv('F3BASE_SITE');
if(!$site||!is_file($site.'/.f3base-bancada-110'))throw new RuntimeException('Exige bancada marcada');
require $site.'/wp-load.php';
wp_set_current_user(1);
$target=(int)($argv[1]??0);
if(!in_array($target,[10,100,1000],true))throw new RuntimeException('Acervo deve ser 10, 100 ou 1000');
$current=(int)$GLOBALS['wpdb']->get_var("SELECT COUNT(*) FROM {$GLOBALS['wpdb']->posts} WHERE post_status='publish' AND post_type IN ('post','page')");
if($current>$target)throw new RuntimeException('O acervo já supera o alvo; use uma instalação nova para a sequência crescente');
for($i=$current+1;$i<=$target;$i++){
 $id=wp_insert_post(['post_title'=>'Acervo sintético '.$i,'post_name'=>'acervo-'.$i,'post_type'=>$i%2?'post':'page','post_status'=>'publish','post_content'=>'Conteúdo sintético para medir consultas, bytes e tempo. Nenhum dado de visitante.'],true);
 if(is_wp_error($id))throw new RuntimeException($id->get_error_message());
}
echo wp_json_encode(['alvo'=>$target,'antes'=>$current,'publicados'=>(int)$GLOBALS['wpdb']->get_var("SELECT COUNT(*) FROM {$GLOBALS['wpdb']->posts} WHERE post_status='publish' AND post_type IN ('post','page')")])."\n";
