#!/usr/bin/env bash
# Monta um site descartável usando insumos explícitos; instala o zip, não a árvore de fontes.
set -euo pipefail
if [ "$#" -ne 2 ]; then echo 'Uso: preparar-bancada.sh <cache-insumos> <plugin.zip>' >&2; exit 2; fi
CACHE_110="$(cd "$1" && pwd)"
ZIP_110="$(realpath "$2")"
for recurso_110 in php unzip curl; do command -v "$recurso_110" >/dev/null || { echo "BLOCKED: $recurso_110 ausente" >&2; exit 2; }; done
for insumo_110 in wordpress.zip sqlite-database-integration.zip wordpress-seo.zip wp-super-cache.zip; do
  test -s "$CACHE_110/$insumo_110" || { echo "BLOCKED: $insumo_110 ausente" >&2; exit 2; }
done
TMP_110="$(mktemp -d "${TMPDIR:-/tmp}/f3base-110-XXXXXXXX")"
unzip -q "$CACHE_110/wordpress.zip" -d "$TMP_110"
export F3BASE_SITE="$TMP_110/wordpress"
test -f "$F3BASE_SITE/wp-load.php" || { echo 'BLOCKED: ZIP WordPress sem núcleo' >&2; exit 2; }
mkdir -p "$F3BASE_SITE/wp-content/plugins" "$F3BASE_SITE/wp-content/mu-plugins" "$F3BASE_SITE/wp-content/themes/f3base-bancada"
for insumo_110 in sqlite-database-integration.zip wordpress-seo.zip wp-super-cache.zip; do unzip -q "$CACHE_110/$insumo_110" -d "$F3BASE_SITE/wp-content/plugins"; done
unzip -q "$ZIP_110" -d "$F3BASE_SITE/wp-content/plugins"
cp "$F3BASE_SITE/wp-content/plugins/sqlite-database-integration/db.copy" "$F3BASE_SITE/wp-content/db.php"
touch "$F3BASE_SITE/.f3base-bancada-110"
cat > "$F3BASE_SITE/wp-config.php" <<'PHP'
<?php
 define('DB_NAME','bancada');define('DB_USER','bancada');define('DB_PASSWORD','bancada');define('DB_HOST','localhost');
 define('SQLITE_JOURNAL_MODE','DELETE');define('DB_CHARSET','utf8');define('DB_COLLATE','');$table_prefix='wp_';
 define('AUTH_KEY','f3base-bancada-local-auth');define('SECURE_AUTH_KEY','f3base-bancada-local-secure');
 define('LOGGED_IN_KEY','f3base-bancada-local-logged');define('NONCE_KEY','f3base-bancada-local-nonce');
 define('AUTH_SALT','f3base-bancada-local-auth-salt');define('SECURE_AUTH_SALT','f3base-bancada-local-secure-salt');
 define('LOGGED_IN_SALT','f3base-bancada-local-logged-salt');define('NONCE_SALT','f3base-bancada-local-nonce-salt');
 define('WP_DEBUG',true);define('WP_DEBUG_LOG',true);define('WP_DEBUG_DISPLAY',true);define('DISABLE_WP_CRON',true);
 define('WP_CACHE',true);define('WP_ENVIRONMENT_TYPE','local');define('WP_MEMORY_LIMIT','256M');
 define('WPCACHEHOME',__DIR__.'/wp-content/plugins/wp-super-cache/');
 define('WP_HOME','http://127.0.0.1:'.(getenv('F3BASE_BANCADA_PORTA')?:18110));define('WP_SITEURL',WP_HOME);
 if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/'); require_once ABSPATH.'wp-settings.php';
PHP
cat > "$F3BASE_SITE/wp-content/mu-plugins/bancada-offline.php" <<'PHP'
<?php
add_filter('pre_http_request', static function($r,$a,$u){return str_starts_with($u,'http://127.0.0.1:')?$r:new WP_Error('bancada_rede_externa','HTTP externo desativado na bancada');},1,3);
add_filter('pre_wp_mail', static function(){return true;});
PHP
cat > "$F3BASE_SITE/wp-content/themes/f3base-bancada/style.css" <<'CSS'
/*
Theme Name: Bancada Core
Version: 1.0.0
*/
CSS
cat > "$F3BASE_SITE/wp-content/themes/f3base-bancada/index.php" <<'PHP'
<!doctype html><html><head><?php wp_head(); ?></head><body><main><?php while(have_posts()){the_post();the_content();} ?></main><?php wp_footer(); ?></body></html>
PHP
php "$(dirname "${BASH_SOURCE[0]}")/instalar-wp.php" > "$TMP_110/ambiente.json"
printf 'Site: %s\nPerfil: %s\n' "$F3BASE_SITE" "$TMP_110/ambiente.json"
