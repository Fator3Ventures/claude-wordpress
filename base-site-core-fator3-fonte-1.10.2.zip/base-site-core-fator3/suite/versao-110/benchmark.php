<?php
/** Custo do contrato e achados E0, executados pelo registro real de abilities. */
declare(strict_types=1);
$site=(string)getenv('F3BASE_SITE');
if(!$site || !is_file($site.'/wp-load.php')){fwrite(STDERR,"F3BASE_SITE ausente\n");exit(2);}
require $site.'/wp-load.php';
wp_set_current_user(1);
if(!function_exists('wp_get_ability')){fwrite(STDERR,"Abilities API ausente\n");exit(2);}
$alerts=[];
set_error_handler(static function($n,$s,$f,$l) use (&$alerts){if(error_reporting()&$n)$alerts[]=[$n,$s,basename($f),$l];return false;});
$results=[];
foreach(['f3base/como-usar','f3base/config-core-contrato-v1'] as $name){
 $ability=wp_get_ability($name);
 if(!$ability){$results[$name]=['estado'=>'BLOCKED'];continue;}
 $variants=['completo'=>array()];
 if(version_compare(F3BASE_PLUGIN_VERSAO,'1.10.0','>='))$variants['compacto']=['compacto'=>true];
 foreach($variants as $variant=>$input){
 for($i=0;$i<3;$i++){
  $queries=$GLOBALS['wpdb']->num_queries;$memory=memory_get_usage();$time=hrtime(true);
  $output=$ability->execute($input);
  $results[$name][$variant][]=array('ms'=>round((hrtime(true)-$time)/1e6,3),'queries'=>$GLOBALS['wpdb']->num_queries-$queries,'memory_delta'=>memory_get_usage()-$memory,'bytes'=>strlen(wp_json_encode($output)),'erro'=>is_wp_error($output)?$output->get_error_code():null);
 }
 }
}
$llms=F3Base_Options::ler('f3base_llms');
$saved=F3Base_Options::gravar('f3base_llms',array_merge($llms,['ligado'=>false]),F3Base_Options::ORIGEM_MANUAL);
if(empty($saved['persisted']))throw new RuntimeException('A fixture llms desligado não persistiu');
$resp=F3Base_Llms::responsaveis();
F3Base_Options::gravar('f3base_llms',$llms,F3Base_Options::ORIGEM_MANUAL);
$ua='WordPress/'.$GLOBALS['wp_version'].'; '.home_url('/');
$results['reproducoes']=['ua_proprio'=>F3Base_Modulo_Acessos_Servidor::agente($ua),'llms_desligado_responsaveis'=>$resp];
restore_error_handler();
$results['avisos']=$alerts;$results['wordpress']=$GLOBALS['wp_version'];$results['php']=PHP_VERSION;$results['core']=F3BASE_PLUGIN_VERSAO;
$results['posts_publicados']=(int)$GLOBALS['wpdb']->get_var("SELECT COUNT(*) FROM {$GLOBALS['wpdb']->posts} WHERE post_status='publish' AND post_type IN ('post','page')");
echo wp_json_encode($results,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
