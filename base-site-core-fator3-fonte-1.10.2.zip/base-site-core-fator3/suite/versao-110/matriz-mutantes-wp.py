#!/usr/bin/env python3
"""Executa cada patch histórico isoladamente como ZIP em WordPress real descartável."""
from pathlib import Path
import argparse,concurrent.futures,hashlib,json,os,re,shutil,subprocess,tempfile,time,zipfile
p=argparse.ArgumentParser();p.add_argument('--php',required=True,type=Path);p.add_argument('--cache',required=True,type=Path);p.add_argument('--saida',required=True,type=Path);p.add_argument('--paralelos',type=int,default=3);p.add_argument('--somente',default='');p.add_argument('--retomar',action='store_true');p.add_argument('--fonte',type=Path);p.add_argument('--chromium',type=Path);p.add_argument('--pacote-referencia',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[2];todos=[]
for line in (root/'suite/bancada-wp/pisos.tsv').read_text().splitlines():
 if not line.strip() or line.startswith('#'):continue
 case,patches,state,reason=line.split('\t',3)
 for patch in patches.split(','):todos.append({'caso':case,'patch':patch,'situacao':state,'defeito':reason})
wanted=set(filter(None,a.somente.split(',')));selected=[r for r in todos if not wanted or r['caso'] in wanted or Path(r['patch']).stem in wanted]
if not selected:raise SystemExit('Nenhum caso selecionado')
chromium=a.chromium or (Path(os.environ['F3BASE_CHROMIUM']) if os.environ.get('F3BASE_CHROMIUM') else None)
if any(r['caso'] in ('ux_configuracao','ux_medicao') for r in selected):
 if not chromium or not chromium.is_file() or not os.access(chromium,os.X_OK):raise SystemExit('Bancada UX requer --chromium ou F3BASE_CHROMIUM apontando para executável local.')

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def manifest(path):return {str(f.relative_to(path)):digest(f) for f in sorted(path.rglob('*')) if f.is_file()}
def compact(result):
 for key in ('aplicacao','stderr','lint'):
  value=result.get(key,'')
  if isinstance(value,str) and len(value)>2000:
   result[key]=value[:2000]+' [diagnóstico truncado]';result[key+'_bytes']=len(value.encode());result[key+'_sha256']=hashlib.sha256(value.encode()).hexdigest()
 if len(result.get('saida_adicional',[]))>5:
  original='\n'.join(result['saida_adicional']);result['saida_adicional']=result['saida_adicional'][:5];result['saida_adicional_linhas']=len(original.splitlines());result['saida_adicional_sha256']=hashlib.sha256(original.encode()).hexdigest()
 if isinstance(result.get('veredito'),dict):
  message=result['veredito'].get('mensagem','')
  if len(message)>2400:
   result['veredito']['mensagem']=message[:2400]+' [diagnóstico truncado]';result['veredito']['mensagem_sha256']=hashlib.sha256(message.encode()).hexdigest();result['veredito']['mensagem_bytes']=len(message.encode())
 return result
with tempfile.TemporaryDirectory(prefix='f3base-matriz-mutantes-') as td:
 base=Path(td);snapshot=base/'fonte-pristina';shutil.copytree(a.fonte or root/'fontes/plugin',snapshot);sha=digest(root/'suite/bancada-wp/pisos.tsv');source_manifest=manifest(snapshot)
 reference=None
 if a.pacote_referencia:
  with zipfile.ZipFile(a.pacote_referencia) as package:
   packaged={name.split('/',1)[1]:package.read(name) for name in package.namelist() if not name.endswith('/')}
  packaged_hashes={name:hashlib.sha256(content).hexdigest() for name,content in packaged.items()}
  documentation=sorted(set(source_manifest)-set(packaged_hashes));guards=sorted(set(packaged_hashes)-set(source_manifest))
  mismatch=sorted(name for name in source_manifest.keys() & packaged_hashes.keys() if source_manifest[name]!=packaged_hashes[name])
  if mismatch or documentation!=['INSTRUCOES-DO-PLUGIN.md'] or any(not name.endswith('index.php') or packaged[name]!=b'<?php\n// Silence is golden.\n' for name in guards):raise RuntimeError('ZIP de referência diverge do runtime testado: '+repr(mismatch+documentation+guards))
  reference={'arquivo':a.pacote_referencia.name,'sha256':digest(a.pacote_referencia),'arquivos':len(packaged),'arquivos_funcionais_identicos':len(source_manifest.keys() & packaged_hashes.keys()),'paridade_funcional':True,'documentacao_fora_zip':documentation,'indices_protetores_gerados':guards}
 env=os.environ.copy();env['PATH']=str(a.php.resolve().parent)+os.pathsep+env['PATH'];env['F3BASE_BANCADA_CACHE']=str(a.cache.resolve())
 if chromium:env['F3BASE_CHROMIUM']=str(chromium.resolve())
 def run(row):
  result=dict(row);start=time.monotonic();patch=root/'suite/bancada-wp'/row['patch'];result['patch_sha256']=digest(patch)
  with tempfile.TemporaryDirectory(prefix='caso-',dir=base) as temp:
   temp=Path(temp);tree=temp/'base-site-core-fator3';shutil.copytree(snapshot,tree)
   proc=subprocess.run(['patch','--batch','-p1'],cwd=tree,input=patch.read_bytes(),capture_output=True)
   result['aplicacao']=(proc.stdout+proc.stderr).decode(errors='replace').strip()
   if proc.returncode:result['resultado']='patch_nao_aplica';return result
   modified=re.findall(r'^\+\+\+ b/([^\t\n]+)',patch.read_text(),re.M)
   for relative in modified:
    if relative.endswith('.php'):
     lint=subprocess.run([str(a.php.resolve()),'-l',str(tree/relative)],capture_output=True,text=True)
     if lint.returncode:result.update(resultado='mutante_php_invalido',lint=lint.stdout+lint.stderr);return result
   zpath=temp/'plugin-mutante.zip'
   with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    for f in tree.rglob('*'):
     if f.is_file():z.write(f,Path('base-site-core-fator3')/f.relative_to(tree))
   try:
    proc=subprocess.run(['bash',str(root/'suite/bancada-wp/bancada.sh'),'rodada',str(zpath),row['caso']],cwd=root,env=env,capture_output=True,text=True,timeout=240)
   except subprocess.TimeoutExpired as e:result.update(resultado='timeout',segundos=round(time.monotonic()-start,2));return result
   records=[];extraneous=[]
   for line in proc.stdout.splitlines():
    try:records.append(json.loads(line))
    except json.JSONDecodeError:extraneous.append(line)
   case=next((r for r in records if r.get('nome')=='wp.'+row['caso']),None);environment=next((r for r in records if r.get('nome')=='bancada.ambiente'),None)
   infra_error=case and any(marker in case.get('mensagem','') for marker in ('browserType.launch:',"Cannot find module 'playwright'",'Executable doesn\'t exist at'))
   result.update(resultado='ambiente_incompleto' if infra_error else 'defeito_detectado' if environment and environment.get('estado')=='OK' and case and case.get('estado')=='FALHA' else 'negativo_nao_comprovado',veredito=case,ambiente=environment,exit=proc.returncode,stderr=proc.stderr,saida_adicional=extraneous,segundos=round(time.monotonic()-start,2))
   return result
 results=[];historico=[]
 if a.retomar and a.saida.exists():
  previous=json.loads(a.saida.read_text())
  if previous.get('fonte_manifesto')!=source_manifest:raise RuntimeError('Fonte mudou: retomada recusada para não misturar evidências de runtimes distintos.')
  for old in previous.get('casos',[]):
   patch=root/'suite/bancada-wp'/old['patch']
   if old.get('resultado')=='defeito_detectado' and patch.is_file() and old.get('patch_sha256')==digest(patch):results.append(compact(old))
   else:historico.append({'patch':old['patch'],'patch_sha256':old.get('patch_sha256'),'resultado':old.get('resultado'),'veredito':old.get('veredito')})
  historico=previous.get('historico_retestes',[])+historico
 def save():
  counts={};
  for r in results:counts[r['resultado']]=counts.get(r['resultado'],0)+1
  report={'pacote_referencia':reference,'total_declarado':len(todos),'total_selecionado':len(selected),'executados':len(results),'completo':len(results)==len(selected),'ok':len(results)==len(selected) and counts.get('defeito_detectado',0)==len(selected),'contagens':counts,'pisos_tsv_sha256':sha,'fonte_manifesto_sha256':hashlib.sha256(json.dumps(source_manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'fonte_manifesto':source_manifest,'fixture_bancada_sha256':digest(root/'suite/bancada-wp/bancada.sh'),'chromium':str(chromium.resolve()) if chromium else None,'historico_retestes':historico,'casos':sorted(results,key=lambda x:x['patch'])}
  a.saida.parent.mkdir(parents=True,exist_ok=True);a.saida.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,min(4,a.paralelos))) as pool:
  done={r['patch'] for r in results};tasks=[pool.submit(run,r) for r in selected if r['patch'] not in done]
  for task in concurrent.futures.as_completed(tasks):
   result=compact(task.result());results.append(result);save();print(json.dumps({'patch':result['patch'],'resultado':result['resultado'],'executados':len(results),'total':len(selected),'veredito':result.get('veredito')},ensure_ascii=False),flush=True)
 save()
 if not all(r['resultado']=='defeito_detectado' for r in results):raise SystemExit(1)
