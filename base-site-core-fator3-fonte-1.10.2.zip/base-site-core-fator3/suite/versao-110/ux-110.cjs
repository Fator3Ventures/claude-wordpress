/* Navegador real: configurações por seção, navegação e atualização de acessos. */
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
(async () => {
 const base = new URL(process.argv[2]).origin;
 const out = process.env.F3BASE_EVIDENCIA_DIR;
 if (out) fs.mkdirSync(out, {recursive:true});
 const browser = await chromium.launch({executablePath:process.env.F3BASE_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const report={browser:browser.version(),checks:[],javascriptErrors:[]};
 const check=(nome)=>report.checks.push({nome,ok:true});
 try {
  const page=await browser.newPage({viewport:{width:1440,height:1000}});
  page.on('pageerror',e=>report.javascriptErrors.push(String(e)));
  await page.route('**/*',r=>new URL(r.request().url()).origin===base?r.continue():r.abort());
  const shot=async name=>{if(out)await page.screenshot({path:path.join(out,name+'.png')});};
  const overflow=async()=>{const x=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,offenders:[...document.querySelectorAll('.f3base-tela *')].filter(el=>el.getBoundingClientRect().right>innerWidth+2).slice(0,15).map(el=>({tag:el.tagName,cls:el.className,id:el.id,text:el.innerText?.slice(0,150),right:el.getBoundingClientRect().right}))}));if(x.scroll>x.width+2){await shot('overflow-110');assert.fail('Rolagem horizontal: '+JSON.stringify(x));}};
  await page.goto(base+'/wp-login.php');
  await page.locator('#user_login').fill('admin');
  await page.locator('#user_pass').fill(process.env.F3BASE_ADMIN_PASSWORD||'f3base-local-test-only');
  await Promise.all([page.waitForURL('**/wp-admin/**'),page.locator('#wp-submit').click()]);
  await page.goto(base+'/wp-admin/plugins.php');
  const link=page.locator('tr[data-plugin="base-site-core-fator3/base-site-core-fator3.php"]').getByRole('link',{name:'Configurações',exact:true});
  assert.equal(await link.count(),1);
  await Promise.all([page.waitForURL('**/admin.php?page=base-site-core-fator3'),link.click()]);
  check('Atalho de configurações na lista de plugins');
  const forms=page.locator('form.f3base-form');
  assert.ok(await forms.count()>=4);
  for(let i=0;i<await forms.count();i++){
   assert.equal(await forms.nth(i).locator('section[data-f3base-bloco]').count(),1);
   assert.equal(await forms.nth(i).getByRole('button',{name:'Salvar',exact:true}).count(),1);
   assert.equal(await forms.nth(i).locator('input[name="_wpnonce"]').count(),1);
  }
  check('Formulários independentes com Salvar e nonce por seção');
  assert.equal(await forms.locator('details[open]').count(),0);
  const help=forms.locator('details.f3base-ajuda > summary').first();
  await help.focus();await page.keyboard.press('Enter');
  assert.equal(await forms.locator('details[open]').count(),1);check('Ajuda acessível por teclado');
  const session=page.locator('[name="f3base[f3base_sessao][dias]"]');
  const contact=page.locator('[name="f3base[f3base_contato][mensagem_padrao]"]');
  const original=await session.inputValue();
  await session.fill(original==='77'?'78':'77');await contact.fill('Mensagem sintética UX 1.10');
  await Promise.all([page.waitForNavigation(),contact.locator('xpath=ancestor::form').getByRole('button',{name:'Salvar',exact:true}).click()]);
  assert.equal(await session.inputValue(),original);
  assert.equal(await contact.inputValue(),'Mensagem sintética UX 1.10');
  assert.match(await page.locator('.f3base-leitura').innerText(),/^Configurações salvas\.( Verificação do cache pendente\.)?$/);
  assert.equal(await page.locator('.f3base-leitura code,.f3base-leitura li,.f3base-leitura pre').count(),0);
  check('Salvar grava apenas a seção enviada e confirma sem inventário');
  await overflow();await shot('configuracao-desktop-110');
  await Promise.all([page.waitForURL('**/admin.php?page=base-site-core-fator3&aba=tecnica'),page.getByRole('link',{name:'Informações técnicas',exact:true}).click()]);
  await page.waitForLoadState('domcontentloaded');
  assert.equal(await page.locator('form.f3base-form').count(),0);
  assert.equal(await page.getByRole('heading',{name:'Estado operacional',exact:true}).count(),1);
  await overflow();await shot('informacoes-tecnicas-110');check('Aba técnica separada');
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:width===1440?1000:844});
   await page.goto(base+'/wp-admin/admin.php?page=base-site-core-fator3');await overflow();await shot('configuracao-'+width+'-110');
   await page.goto(base+'/wp-admin/admin.php?page=f3base-medicao');await overflow();await shot('medicao-'+width+'-110');
   await page.goto(base+'/wp-admin/admin.php?page=f3base-medicao&aba=acessos');
   assert.equal(await page.getByRole('checkbox',{name:'Mostrar todos',exact:true}).isChecked(),false);
   const today=page.getByRole('checkbox',{name:'Incluir hoje na comparação (parcial)',exact:true});
   assert.equal(await today.isChecked(),false);await today.check();
   const periods=await page.locator('select[name="dias"] option').evaluateAll(xs=>xs.map(x=>x.value));
   for(const n of ['1','2','3','4','5','6','15','60'])assert.ok(periods.includes(n));
   await page.locator('select[name="dias"]').selectOption('15');
   await page.locator('select[name="classificacao"]').selectOption('inexistentes');
   const response=page.waitForResponse(r=>r.url().includes('admin-ajax.php')&&r.request().method()==='POST');
   await page.getByRole('button',{name:'Atualizar',exact:true}).click();
   const data=await(await response).json();assert.equal(data.success,true);
   await page.waitForFunction(()=>document.querySelector('#f3base-acessos-status').textContent.startsWith('Atualizado')||document.querySelector('#f3base-acessos-status').textContent.startsWith('Atualização parcial'));
   assert.equal(new URL(page.url()).searchParams.get('dias'),'15');
   assert.equal(new URL(page.url()).searchParams.get('classificacao'),'inexistentes');
   assert.equal(new URL(page.url()).searchParams.get('comparacao_hoje'),'1');
   assert.equal(await page.getByRole('checkbox',{name:'Incluir 4xx/5xx',exact:true}).isChecked(),true);
   assert.equal(await page.locator('#f3base-acessos-csv [name="comparacao_hoje"]').inputValue(),'1');
   assert.equal(await page.getByRole('button',{name:'Coletar e Armazenar Logs',exact:true}).count(),1);
   assert.equal(await page.locator('#f3base-acessos-auto').isChecked(),false);
   await overflow();await shot('acessos-'+width+'-110');check('Layout e atualização AJAX em '+width+'px');
  }
  assert.deepEqual(report.javascriptErrors,[]);check('Sem exceções JavaScript nas telas exercitadas');
  report.ok=true;
 }catch(e){report.ok=false;report.falha=String(e.stack||e);throw e;}
 finally{
  if(out)fs.writeFileSync(path.join(out,'ux-110.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report));await browser.close();
 }
})().catch(e=>{console.error(e);process.exitCode=1;});
