<?php
/** Testes dirigidos de persistência, procedência, mescla e políticas no WordPress real. */
declare( strict_types = 1 );
$site = getenv( 'F3BASE_SITE' );
if ( ! $site || ! is_file( $site . '/wp-load.php' ) ) { fwrite( STDERR, "Defina F3BASE_SITE para a bancada isolada.\n" ); exit( 2 ); }
require $site . '/wp-load.php';
wp_set_current_user( 1 );
$falhas = array(); $provas = array();
function config110( bool $ok, string $nome ): void { global $falhas, $provas; $provas[ $nome ] = $ok; if ( ! $ok ) { $falhas[] = $nome; } }
add_filter( 'pre_http_request', static fn() => new WP_Error( 'bancada_sem_rede', 'Teste sem entrega externa.' ), 1 );
set_error_handler( static function ( $n, $m, $f, $l ) { if ( error_reporting() & $n ) { throw new ErrorException( $m, 0, $n, $f, $l ); } return false; } );
try {
	$nome = 'f3base_contato';
	$r = F3Base_Options::gravar( $nome, array( 'whatsapp_e164' => '5511999999999', 'mensagem_padrao' => 'Antes', 'flutuante' => false, 'legado_extra' => 'preservar' ), F3Base_Options::ORIGEM_IMPLANTADOR );
	config110( $r['persisted'] && 'recorded' === $r['audit']['status'], 'persistencia_e_auditoria_confirmadas' );
	$foto = F3Base_Options::fotografia( $nome );
	$pedido = array( 'nome' => $nome, 'valor' => array( 'flutuante' => true ), 'mesclar' => true, 'revisao_esperada' => $foto['revisao'] );
	$previa = F3Base_Core_Config_Mcp::escrever( $pedido );
	config110( $previa['ok'] && $previa['simulado'] && ! $previa['persisted'] && 'preservar' === $previa['depois']['legado_extra'] && $foto['revisao'] === F3Base_Options::revisao( $nome ), 'mescla_previa_preserva_extensao_sem_gravar' );
	$aplicado = F3Base_Core_Config_Mcp::escrever( $pedido + array( 'simular' => false ) );
	$p = F3Base_Options::procedencia( $nome );
	config110( $aplicado['persisted'] && $aplicado['lido']['flutuante'] && 'Antes' === $aplicado['lido']['mensagem_padrao'] && 'ability' === $p['canal'] && 'confirmada' === $p['estado'], 'mescla_grava_pela_fachada_e_registra_canal' );
	$config = F3Base_Core_Config_Mcp::escrever( $pedido + array( 'simular' => false ) );
	config110( ! $config['persisted'] && 'conflito' === $config['codigo'], 'mescla_nao_sobrescreve_revisao_antiga' );
	foreach ( array( array( 'nova_chave' => true ), array( 'flutuante' => null ), array( 'flutuante' => array( 'mascarado' => true ) ) ) as $valor ) {
		$bad = F3Base_Core_Config_Mcp::escrever( array_replace( $pedido, array( 'valor' => $valor, 'revisao_esperada' => F3Base_Options::revisao( $nome ) ) ) );
		config110( ! $bad['ok'], 'mescla_recusa_' . count( $provas ) );
	}
	$llms = F3Base_Options::declaracao( 'f3base_llms' ); $llms_atual = $llms['padrao'];
	$llms_atual['politica_privacidade'] = array( 'id' => 12, 'url' => 'https://example.invalid/privacidade', 'titulo' => 'Anterior', 'descricao' => 'Manter' );
	$llms_mescla = F3Base_Config_Mescla::preparar( $llms, $llms_atual, array( 'politica_privacidade' => array( 'titulo' => 'Novo' ) ) );
	config110( $llms_mescla['ok'] && 12 === $llms_mescla['valor']['politica_privacidade']['id'] && 'Novo' === $llms_mescla['valor']['politica_privacidade']['titulo'], 'mescla_mapa_polimorfico_preserva_campos' );
	$llms_vazio = F3Base_Config_Mescla::preparar( $llms, $llms_atual, array( 'politica_privacidade' => array() ) );
	config110( $llms_vazio['ok'] && array() === $llms_vazio['valor']['politica_privacidade'], 'mescla_lista_vazia_substitui_slot_opcional' );
	// Interleaving em DB real: outra opção carimba procedência entre leitura e CAS.
	$interrompido = false;
	$concorrente = static function ( $novo, $anterior ) use ( &$interrompido ) { if ( ! $interrompido ) { $interrompido = true; F3Base_Options::gravar( 'f3base_linkedin_partner_id', '12345', F3Base_Options::ORIGEM_IMPLANTADOR ); } return $novo; };
	add_filter( 'pre_update_option_f3base_proveniencia', $concorrente, 10, 2 );
	$principal = F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-CONFIG110', F3Base_Options::ORIGEM_MANUAL );
	remove_filter( 'pre_update_option_f3base_proveniencia', $concorrente, 10 );
	config110( $principal['persisted'] && 'confirmada' === F3Base_Options::procedencia( 'f3base_linkedin_partner_id' )['estado'] && 'confirmada' === F3Base_Options::procedencia( 'f3base_ga4_measurement_id' )['estado'], 'cas_preserva_procedencias_concorrentes' );
	$negar = static fn( $novo, $anterior ) => $anterior;
	add_filter( 'pre_update_option_f3base_proveniencia', $negar, 10, 2 );
	$sem_auditoria = F3Base_Options::gravar( 'f3base_linkedin_partner_id', '45678' );
	remove_filter( 'pre_update_option_f3base_proveniencia', $negar, 10 );
	config110( $sem_auditoria['persisted'] && 'pending' === $sem_auditoria['audit']['status'] && 'nao_confirmada' === F3Base_Options::procedencia( 'f3base_linkedin_partner_id' )['estado'], 'auditoria_pendente_nao_desfaz_persistencia' );
	$antes = get_option( F3Base_Options::OPTION_TENTATIVAS, array() ); $uma = false;
	$recusa_concorrente = static function ( $novo, $anterior ) use ( &$uma ) { if ( ! $uma ) { $uma = true; F3Base_Options::registrar_tentativa_recusada( 'f3base_contato', 'edicao-manual', 'recusa_b' ); } return $novo; };
	add_filter( 'pre_update_option_f3base_tentativas_recusadas', $recusa_concorrente, 10, 2 );
	F3Base_Options::registrar_tentativa_recusada( 'f3base_contato', 'edicao-manual', 'recusa_a' );
	remove_filter( 'pre_update_option_f3base_tentativas_recusadas', $recusa_concorrente, 10 );
	$ultimas = array_column( array_slice( get_option( F3Base_Options::OPTION_TENTATIVAS ), -2 ), 'codigo' );
	config110( in_array( 'recusa_a', $ultimas, true ) && in_array( 'recusa_b', $ultimas, true ), 'cas_preserva_recusas_concorrentes' );
	$foto_recusas = F3Base_Options::fotografia( F3Base_Options::OPTION_TENTATIVAS );
	$recusada = F3Base_Options::atualizar_estado( F3Base_Options::OPTION_TENTATIVAS, static fn( $v ) => null );
	config110( ! $recusada['persisted'] && 'transformacao_recusada' === $recusada['codigo'] && $foto_recusas['revisao'] === F3Base_Options::revisao( F3Base_Options::OPTION_TENTATIVAS ), 'cas_null_recusa_sem_apagar_estado' );
	$protegidas = F3Base_Core_Config_Mcp::proteger_options( array( 'outra_option' ) );
	config110( in_array( 'outra_option', $protegidas, true ) && in_array( F3Base_Options::OPTION_TENTATIVAS, $protegidas, true ) && ! in_array( 'f3base_journal', $protegidas, true ), 'protecao_respeita_propriedade' );
	// Login: múltiplos papéis e capacidades próprias, com checkbox respeitado.
	$login = 'config110-' . wp_generate_password( 8, false );
	$id = wp_create_user( $login, wp_generate_password( 24 ), $login . '@example.invalid' );
	if ( is_wp_error( $id ) ) { throw new RuntimeException( 'Falha na fixture de usuário.' ); }
	$user = get_userdata( $id ); $user->set_role( 'author' ); $user->add_role( 'editor' );
	$c = F3Base_Options::declaracao( 'f3base_sessao' )['padrao']; $c['modo'] = 'por-perfil';
	$p = F3Base_Modulo_Sessao_De_Login::politica( $c, $id, true, 14 * DAY_IN_SECONDS );
	config110( 14 * DAY_IN_SECONDS === $p['segundos'], 'sessao_multiplos_papeis_mais_restritiva' );
	$user->set_role( 'author' );
	config110( 90 * DAY_IN_SECONDS === F3Base_Modulo_Sessao_De_Login::politica( $c, $id, true, 14 * DAY_IN_SECONDS )['segundos'] && 2 * DAY_IN_SECONDS === F3Base_Modulo_Sessao_De_Login::politica( $c, $id, false, 2 * DAY_IN_SECONDS )['segundos'], 'sessao_respeita_lembrar' );
	$user->add_cap( 'manage_options' );
	config110( 14 * DAY_IN_SECONDS === F3Base_Modulo_Sessao_De_Login::politica( $c, $id, true, 14 * DAY_IN_SECONDS )['segundos'], 'sessao_admin_personalizado_respeita_nucleo' );
	$c['modo'] = 'legado';
	config110( 90 * DAY_IN_SECONDS === F3Base_Modulo_Sessao_De_Login::politica( $c, $id, false, 2 * DAY_IN_SECONDS )['segundos'], 'sessao_modo_legado_preservado' );
	require_once ABSPATH . 'wp-admin/includes/user.php'; wp_delete_user( $id );
	$perfil = array( 'id' => 'teste', 'revisao' => 'v1', 'condicoes' => array( array( 'id' => 'contato', 'nome' => 'f3base_contato', 'campo' => array( 'flutuante' ), 'esperado' => true ) ) );
	$avaliado = F3Base_Config_Perfil::avaliar( array( 'perfil' => $perfil ) );
	config110( 'conforme' === $avaliado['estado'], 'perfil_confere_fotografia_atual' );
	$perfil['condicoes'][0]['esperado'] = false;
	$perfil['excecoes'] = array( array( 'condicao' => 'contato', 'responsavel' => 'operador', 'motivo' => 'Teste declarado', 'expira_em' => time() + 100, 'perfil_id' => 'teste', 'perfil_revisao' => 'v1' ) );
	config110( 'excecao_valida' === F3Base_Config_Perfil::avaliar( array( 'perfil' => $perfil ) )['estado'], 'perfil_excecao_versionada' );
	$perfil['excecoes'][0]['expira_em'] = time() - 1;
	config110( 'divergente' === F3Base_Config_Perfil::avaliar( array( 'perfil' => $perfil ) )['estado'], 'perfil_excecao_expirada_nao_aprova' );
	config110( 'indeterminado' === F3Base_Config_Perfil::avaliar()['estado'], 'perfil_ausente_indeterminado' );
	$segredo_teste = 'segredo-config-110-nao-retornar';
	F3Base_Options::gravar( 'f3base_meta_capi_token', $segredo_teste );
	$perfil_segredo = array( 'id' => 'segredo', 'revisao' => 'v1', 'condicoes' => array( array( 'id' => 'token', 'nome' => 'f3base_meta_capi_token', 'comparacao' => 'configurado', 'esperado' => true ) ) );
	$presenca = F3Base_Config_Perfil::avaliar( array( 'perfil' => $perfil_segredo ) );
	config110( 'conforme' === $presenca['estado'] && true === $presenca['itens'][0]['observado']['mascarado'] && ! str_contains( wp_json_encode( $presenca ), $segredo_teste ), 'perfil_segredo_somente_presenca_mascarada' );
	$perfil_segredo['condicoes'][0]['comparacao'] = 'igual'; $perfil_segredo['condicoes'][0]['esperado'] = $segredo_teste;
	$recusa_segredo = F3Base_Config_Perfil::avaliar( array( 'perfil' => $perfil_segredo ) );
	config110( 'indeterminado' === $recusa_segredo['estado'] && ! str_contains( wp_json_encode( $recusa_segredo ), $segredo_teste ), 'perfil_recusa_valor_secreto_sem_repetir_entrada' );
	$perfil_segredo['condicoes'][0]['nome'] = 'wp_outro_plugin_segredo';
	config110( 'indeterminado' === F3Base_Config_Perfil::avaliar( array( 'perfil' => $perfil_segredo ) )['estado'], 'perfil_nao_le_options_arbitrarias' );
	F3Base_Options::gravar( 'f3base_meta_capi_token', '' );

} catch ( Throwable $erro ) { $falhas[] = $erro->getMessage() . ' em ' . basename( $erro->getFile() ) . ':' . $erro->getLine(); }
restore_error_handler();
echo wp_json_encode( array( 'ok' => ! $falhas, 'testes' => $provas, 'falhas' => $falhas ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
exit( $falhas ? 1 : 0 );
