<?php
/** Catálogo documentado conferido contra WordPress real e fontes adversariais. */
declare( strict_types = 1 );
$raiz = dirname( __DIR__, 2 );
$site = getenv( 'F3BASE_SITE' );
if ( ! $site || ! is_file( $site . '/wp-load.php' ) ) { fwrite( STDERR, "Defina F3BASE_SITE para a bancada isolada.\n" ); exit( 2 ); }
require $site . '/wp-load.php';
require $raiz . '/suite/lib/regra.php';
require $raiz . '/suite/lib/documentos.php';
$real = F3Base_Options::catalogo();
$documentado = array_column( f3b_catalogo_do_plugin( $raiz ), null, 'nome' );
$nomes_reais = array_keys( $real ); $nomes_documentados = array_keys( $documentado );
sort( $nomes_reais ); sort( $nomes_documentados );
$provas = array( 'nomes_iguais_catalogo_real' => $nomes_reais === $nomes_documentados );
$campos_corretos = true;
foreach ( $real as $nome => $declaracao ) {
	$campos_corretos = $campos_corretos && isset( $documentado[ $nome ] ) && count( $declaracao['subcampos'] ?? array() ) === $documentado[ $nome ]['subcampos'];
}
$provas['todos_subcampos_conferem'] = $campos_corretos;
$fixture = <<<'FONTE'
<?php
class Exemplo {
 public static function catalogo(): array {
  $catalogo = [
    // Apenas esse nível é option.
    'f3base_um' => [ 'secao'=>self::SECAO_GERAL, 'operavel'=>true, 'campo'=>'json', 'sanitiza'=>[__CLASS__, 'sanitizar'],
      'subcampos'=>['antes'=>['type'=>'string', 'properties'=>['nunca_option'=>['type'=>'string']]]],
      'descricao'=>"Separadores em string: ) ] , {$texto['valor']}" ],
    'f3base_dois' => [ 'campo'=>'text' ]
  ];
  return self::catalogo_evolucao( $catalogo );
 }
 private static function catalogo_evolucao( array $catalogo ): array {
  $novos = ['f3base_um'=>['depois'=>['type'=>'boolean'], 'antes'=>['type'=>'string']]];
  foreach ($novos as $nome=>$campos) { $catalogo[$nome]['subcampos']=array_merge($catalogo[$nome]['subcampos'],$campos); }
  $catalogo['f3base_tres'] = ['campo'=>'json', 'subcampos'=>['estado'=>['type'=>'string']]];
  return $catalogo;
 }
 public static function outro(): array { return ['f3base_falsa'=>['campo'=>'text']]; }
}
FONTE;
$tmp = sys_get_temp_dir() . '/f3base-catalogo110-' . bin2hex( random_bytes( 6 ) );
mkdir( $tmp . '/fontes/plugin/includes', 0700, true );
$arquivo = $tmp . '/fontes/plugin/includes/class-exemplo-options.php';
$arquivo_trait = $tmp . '/fontes/plugin/includes/trait-exemplo-options-catalogo.php';
try {
	file_put_contents( $arquivo, $fixture );
	$medido = array_column( f3b_catalogo_do_plugin( $tmp ), null, 'nome' );
	$provas['somente_options_do_nivel_correto'] = array_keys( $medido ) === array( 'f3base_um', 'f3base_dois', 'f3base_tres' );
	$provas['mescla_de_campos_sem_duplicar'] = 2 === ( $medido['f3base_um']['subcampos'] ?? -1 ) && 1 === ( $medido['f3base_tres']['subcampos'] ?? -1 );
	file_put_contents( $arquivo, str_replace( 'return self::catalogo_evolucao( $catalogo );', 'return $catalogo;', $fixture ) );
	$sem_helper = array_column( f3b_catalogo_do_plugin( $tmp ), null, 'nome' );
	$provas['helper_nao_chamado_nao_aumenta_contagem'] = 2 === count( $sem_helper ) && 1 === $sem_helper['f3base_um']['subcampos'];
	file_put_contents( $arquivo, str_replace( 'function catalogo_evolucao(', 'function helper_ausente(', $fixture ) );
	$provas['helper_ausente_nao_publica_contagem_parcial'] = array() === f3b_catalogo_do_plugin( $tmp );
	$trait = str_replace( array( 'class Exemplo {', 'public static function catalogo()' ), array( 'trait Exemplo_Catalogo {', 'private static function catalogo_interno()' ), $fixture );
	$fachada = "<?php require_once __DIR__ . '/trait-exemplo-options-catalogo.php'; class Exemplo { use Exemplo_Catalogo; public static function catalogo(): array { return self::catalogo_interno(); } }";
	file_put_contents( $arquivo_trait, $trait );
	file_put_contents( $arquivo, $fachada );
	$provas['trait_ligada_mantem_catalogo_integral'] = $medido === array_column( f3b_catalogo_do_plugin( $tmp ), null, 'nome' );
	file_put_contents( $arquivo, str_replace( 'use Exemplo_Catalogo;', '', $fachada ) );
	$provas['trait_sem_use_nao_e_contada'] = array() === f3b_catalogo_do_plugin( $tmp );
	file_put_contents( $arquivo, str_replace( "require_once __DIR__ . '/trait-exemplo-options-catalogo.php';", '', $fachada ) );
	$provas['trait_sem_require_nao_e_contada'] = array() === f3b_catalogo_do_plugin( $tmp );
	file_put_contents( $arquivo, $fachada );
	unlink( $arquivo_trait );
	$provas['trait_ausente_nao_publica_contagem_parcial'] = array() === f3b_catalogo_do_plugin( $tmp );
	$callbacks_da_fachada = true;
	foreach ( $real as $declaracao ) {
		foreach ( array( 'sanitiza', 'recusa', 'na_escrita' ) as $callback ) {
			if ( isset( $declaracao[ $callback ] ) ) { $callbacks_da_fachada = $callbacks_da_fachada && is_callable( $declaracao[ $callback ] ); }
		}
	}
	$provas['callbacks_publicos_preservados_apos_extracao'] = $callbacks_da_fachada;

} finally {
	if ( is_file( $arquivo_trait ) ) { unlink( $arquivo_trait ); }
	unlink( $arquivo ); rmdir( dirname( $arquivo ) ); rmdir( $tmp . '/fontes/plugin' ); rmdir( $tmp . '/fontes' ); rmdir( $tmp );
}
$ok = ! in_array( false, $provas, true );
echo json_encode( array( 'ok' => $ok, 'options_reais' => count( $real ), 'options_documentadas' => count( $documentado ), 'testes' => $provas ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
exit( $ok ? 0 : 1 );
