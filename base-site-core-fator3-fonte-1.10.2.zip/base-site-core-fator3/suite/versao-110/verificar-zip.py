#!/usr/bin/env python3
"""Verifica o instalador em clones íntegros; bancos e insumos permanecem fora da fonte."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, sqlite3, subprocess, time, zipfile
ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser()
p.add_argument('--template',required=True,type=Path)
p.add_argument('--zip',required=True,type=Path)
p.add_argument('--php',required=True)
p.add_argument('--wp-cli',required=True)
p.add_argument('--saida',required=True,type=Path)
a=p.parse_args();a.saida=a.saida.resolve();a.saida.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.zip) as z:
 names=z.namelist()
 if any(not n.startswith('base-site-core-fator3/') or '..' in Path(n).parts for n in names):raise SystemExit('Instalador com caminho não permitido.')
 hash_zip=hashlib.sha256(a.zip.read_bytes()).hexdigest()
results=[]
def run(name,commands):
 site=a.saida/('wp-'+name)
 subprocess.run(['python3',str(ROOT/'suite/versao-110/clonar-bancada.py'),str(a.template),str(site)],check=True,capture_output=True)
 target=site/'wp-content/plugins/base-site-core-fator3';shutil.rmtree(target)
 with zipfile.ZipFile(a.zip) as z:z.extractall(site/'wp-content/plugins')
 env=dict(os.environ,F3BASE_SITE=str(site),F3BASE_PHP=a.php,F3BASE_WPCLI=a.wp_cli,PATH=str(Path(a.php).parent)+':'+os.environ['PATH'])
 started=time.monotonic();code=0;log=[]
 for command in commands:
  command=[str(x).replace('{site}',str(site)) for x in command]
  try:
   done=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=180)
   log.append({'comando':command,'exit_code':done.returncode,'stdout':done.stdout,'stderr':done.stderr})
   if done.returncode:code=done.returncode;break
  except subprocess.TimeoutExpired:
   code=124;log.append({'comando':command,'erro':'timeout'});break
 with sqlite3.connect(site/'wp-content/database/.ht.sqlite') as db:
  integrity=[r[0] for r in db.execute('PRAGMA integrity_check')]
  journal=db.execute('PRAGMA journal_mode').fetchone()[0]
 result={'grupo':name,'estado':'OK' if code==0 and integrity==['ok'] and journal=='delete' else 'FALHA','exit_code':code,'integrity_check':integrity,'journal_mode':journal,'segundos':round(time.monotonic()-started,3),'execucoes':log}
 (a.saida/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 results.append({k:v for k,v in result.items() if k!='execucoes'})
 print(json.dumps(results[-1],ensure_ascii=False),flush=True)
php=lambda path,*args:[a.php,str(ROOT/path),*args]
wp=lambda path:[a.php,a.wp_cli,'--allow-root','--path={site}','eval-file',str(ROOT/path)]
run('abilities',[php('suite/versao-110/abilities.php')])
run('abilities-rest',[wp('suite/abilities-rest-110/integracao.php')])
run('configuracao',[php('suite/versao-110/config-110.php'),php('suite/versao-110/config-110-concorrencia.php')])
run('admin-saude',[php('suite/110/admin-operacao.php','{site}')])
run('consentimento',[php('suite/110/consentimento-real.php','{site}')])
run('medicao',[wp('suite/medicao-110/integracao.php')])
run('comparacao-hoje',[php('suite/110/comparacao-hoje.php','{site}')])
run('fotografias-lote',[php('suite/110/fotografias-lote.php','{site}')])
run('capi',[wp('suite/bancada-wp/capi-110.php'),['python3',str(ROOT/'suite/110/capi-concorrencia.py'),'--php',a.php,'--wp-cli',a.wp_cli,'--site','{site}']])
run('operacao',[wp('suite/110/operacao-revisao.php'),wp('suite/110/atualizacao-revisao.php'),['python3',str(ROOT/'suite/110/operacao-morte.py'),'--php',a.php,'--wp-cli',a.wp_cli,'--site','{site}']])
run('publicacao',[php('suite/110/publicacao.php')])
run('cli',[['python3',str(ROOT/'suite/110/cli.py')]])
manifest={'instalador':a.zip.name,'sha256':hash_zip,'grupos':results,'estado':'OK' if all(r['estado']=='OK' for r in results) else 'FALHA','escopo':'Instalador extraído; WordPress real em clones SQLite backup API. Ensaios HTTP, navegador e atualização possuem evidências específicas.'}
(a.saida/'resultado.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
raise SystemExit(0 if manifest['estado']=='OK' else 1)
