#!/usr/bin/env python3
"""Prova que as ferramentas reais recusam símbolo inexistente e saída sem escape."""
import argparse,json,subprocess,tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--php',default='php');p.add_argument('--output',type=Path);a=p.parse_args()
result={'estado':'OK','casos':[]}
with tempfile.TemporaryDirectory(prefix='f3base-qualidade-negativo-') as directory:
 file=Path(directory)/'novo.php'
 file.write_text('<?php\nf3base_funcao_que_nao_existe_no_plugin();\n')
 run=subprocess.run([a.php,'vendor/bin/phpstan','analyse','-c','suite/versao-110/phpstan.neon','--memory-limit=2G','--no-progress','--error-format=json',str(file)],cwd=ROOT,capture_output=True,text=True)
 report=json.loads(run.stdout);assert run.returncode and report['totals']['file_errors']>0
 result['casos'].append({'nome':'phpstan_funcao_inexistente','estado':'OK','erros':report['totals']['file_errors']})
 file.write_text("<?php\nfunction exemplo() { echo $_GET['nao_escapado']; }\n")
 run=subprocess.run([a.php,'vendor/bin/phpcs','--standard=suite/versao-110/phpcs.xml','--report=json',str(file)],cwd=ROOT,capture_output=True,text=True)
 report=json.loads(run.stdout);rules=[m['source'] for f in report['files'].values() for m in f['messages']]
 assert run.returncode and 'WordPress.Security.EscapeOutput.OutputNotEscaped' in rules
 result['casos'].append({'nome':'wpcs_saida_sem_escape','estado':'OK','regras':sorted(set(rules))})
if a.output:a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
