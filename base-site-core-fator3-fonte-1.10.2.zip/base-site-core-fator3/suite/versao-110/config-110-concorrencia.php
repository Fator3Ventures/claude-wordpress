<?php
/** Dois processos reais disputam CAS e preservam ambas as contribuições no journal de recusas. */
declare( strict_types = 1 );
$site = getenv( 'F3BASE_SITE' );
if ( ! $site || ! is_file( $site . '/wp-load.php' ) ) { fwrite( STDERR, "Defina F3BASE_SITE da bancada isolada.\n" ); exit( 2 ); }
require $site . '/wp-load.php';
wp_set_current_user( 1 );
if ( '--filho' === ( $argv[1] ?? '' ) ) {
	$barreira = $argv[2]; $id = $argv[3];
	$sincronizado = false;
	add_filter( 'pre_update_option_f3base_tentativas_recusadas', static function ( $novo ) use ( $barreira, $id, &$sincronizado ) {
		if ( ! $sincronizado ) {
			$sincronizado = true; file_put_contents( $barreira . '.' . $id, 'fotografia_lida' ); $ate = microtime( true ) + 10;
			while ( ! is_file( $barreira ) && microtime( true ) < $ate ) { usleep( 1000 ); }
			if ( ! is_file( $barreira ) ) { throw new RuntimeException( 'Barreira sem segundo escritor.' ); }
		}
		return $novo;
	} );
	$r = F3Base_Options::registrar_tentativa_recusada( 'f3base_contato', F3Base_Options::ORIGEM_MANUAL, 'processo_' . $id );
	echo wp_json_encode( $r ); exit( $r['persisted'] || 'escrita_sem_confirmacao' === $r['codigo'] ? 0 : 1 );
}
$marca = tempnam( sys_get_temp_dir(), 'f3base-config110-' ); unlink( $marca );
$id = bin2hex( random_bytes( 4 ) ); $filhos = array();
foreach ( array( 'a', 'b' ) as $sufixo ) {
	$pipes = array(); $p = proc_open( array( PHP_BINARY, __FILE__, '--filho', $marca, $id . $sufixo ), array( 0 => array( 'pipe', 'r' ), 1 => array( 'pipe', 'w' ), 2 => array( 'pipe', 'w' ) ), $pipes );
	if ( ! is_resource( $p ) ) { throw new RuntimeException( 'Não foi possível iniciar a concorrência real.' ); }
	fclose( $pipes[0] ); $filhos[] = array( $p, $pipes, $sufixo );
}
$ate = microtime( true ) + 10;
while ( ( ! is_file( $marca . '.' . $id . 'a' ) || ! is_file( $marca . '.' . $id . 'b' ) ) && microtime( true ) < $ate ) { usleep( 1000 ); }
file_put_contents( $marca, 'iniciar' ); $resultados = array();
foreach ( $filhos as [ $p, $pipes, $sufixo ] ) { $out = stream_get_contents( $pipes[1] ); $err = stream_get_contents( $pipes[2] ); fclose( $pipes[1] ); fclose( $pipes[2] ); $resultados[ $sufixo ] = array( 'exit' => proc_close( $p ), 'resultado' => json_decode( $out, true ), 'stderr' => $err ); }
unlink( $marca ); foreach ( array( 'a', 'b' ) as $sufixo ) { if ( is_file( $marca . '.' . $id . $sufixo ) ) { unlink( $marca . '.' . $id . $sufixo ); } }
$foto = F3Base_Options::fotografia( F3Base_Options::OPTION_TENTATIVAS ); $codigos = array_column( $foto['valor'], 'codigo' );
$ok = 1 === count( array_keys( $codigos, 'processo_' . $id . 'a', true ) ) && 1 === count( array_keys( $codigos, 'processo_' . $id . 'b', true ) );
echo wp_json_encode( array( 'ok' => $ok, 'cas_concorrencia_real' => $ok, 'processos' => array_map( static fn( $r ) => array( 'exit' => $r['exit'], 'persisted' => $r['resultado']['persisted'] ?? false, 'codigo' => $r['resultado']['codigo'] ?? 'saida_invalida', 'stderr' => $r['stderr'] ), $resultados ) ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
exit( $ok ? 0 : 1 );
