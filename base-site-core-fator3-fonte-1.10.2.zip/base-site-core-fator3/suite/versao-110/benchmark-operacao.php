<?php
/** Custo real de telas, classificação observada e lote de purgas; somente bancada marcada. */
declare(strict_types=1);
$site=(string)getenv('F3BASE_SITE');
if(!$site||!is_file($site.'/.f3base-bancada-110'))throw new RuntimeException('Exige bancada marcada');
require $site.'/wp-load.php';require_once ABSPATH.'wp-admin/includes/admin.php';wp_set_current_user(1);
$op=$argv[1]??'';$purges=0;$avisos=[];$sql=[];$traces=[];
add_action('wp_cache_cleared',static function()use(&$purges){++$purges;});
add_filter('query',static function($q)use(&$sql,&$traces){$sql[]=$q;if(getenv('F3BASE_PROFILE_SQL')){$stack=[];foreach(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,24) as $x){if(str_contains($x['file']??'','/base-site-core-fator3/')){$stack[]=basename($x['file']).':'.$x['line'].' '.($x['class']??'').($x['function']??'');if(count($stack)===6)break;}}$key=implode(' ← ',$stack);$traces[$key]=($traces[$key]??0)+1;}return $q;});
set_error_handler(static function($n,$s,$f,$l)use(&$avisos){if(error_reporting()&$n)$avisos[]=[$n,$s,basename($f),$l];return false;});
$run=static function()use($op){
 if($op==='classificacao'){
  $paths=['/','/acervo-3/','/acervo-4/','/acervo-5/','/acervo-6/','/acervo-7/','/acervo-8/','/robots.txt','/inexistente-404/','/wp-json/'];$classes=[];
  if(class_exists('F3Base_Acessos_Relatorio')){foreach($paths as $p)$classes[$p]=F3Base_Acessos_Relatorio::classe($p,$p==='/wp-json/'?'api':'pagina',$p==='/inexistente-404/'?404:200);}
  else{
   $m=new ReflectionMethod(F3Base_Admin_Acessos::class,'caminhos_publicados');$map=$m->invoke(null);$file=new ReflectionMethod(F3Base_Admin_Acessos::class,'classe_de_arquivo');
   foreach($paths as $p)$classes[$p]=$p==='/inexistente-404/'?'inexistentes':($p==='/wp-json/'?'apis':(isset($map[$p])?'paginas':($file->invoke(null,$p)?:'outros')));
  }
  return $classes;
 }
 if($op==='purgas_lote20'){
  for($i=0;$i<20;$i++){$v=F3Base_Options::ler('f3base_contato');$v['mensagem_padrao']='Benchmark sintético '.wp_generate_uuid4();$r=F3Base_Options::gravar('f3base_contato',$v);if(empty($r['persisted']))throw new RuntimeException('Lote não persistiu');}
  F3Base_Cache_Pagina::concluir();return ['persistidas'=>20];
 }
 $_GET=[];$_REQUEST=[];ob_start();
 if($op==='configuracao')F3Base_Admin_Tela::render();
 elseif($op==='tecnica'){$_GET['aba']='tecnica';F3Base_Admin_Tela::render();}
 elseif($op==='medicao')F3Base_Admin_Medicao::render();
 elseif($op==='acessos')F3Base_Admin_Acessos::render();
 else throw new RuntimeException('Operação desconhecida');
 return ['bytes_html'=>strlen(ob_get_clean())];
};
$samples=[];
for($i=0;$i<3;$i++){
 $queries=$GLOBALS['wpdb']->num_queries;$memory=memory_get_usage();memory_reset_peak_usage();$start=hrtime(true);$before=$purges;$sql=[];
 $output=$run();
 $samples[]=['ms'=>round((hrtime(true)-$start)/1e6,3),'queries'=>$GLOBALS['wpdb']->num_queries-$queries,'memory_delta'=>memory_get_usage()-$memory,'memory_peak_delta'=>memory_get_peak_usage()-$memory,'purgas'=>$purges-$before,'sql_max_bytes'=>$sql?max(array_map('strlen',$sql)):0,'resultado'=>$output];
 if(getenv('F3BASE_PROFILE_SQL'))$samples[count($samples)-1]['sql']=$sql;
}
restore_error_handler();
echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'operacao'=>$op,'amostras'=>$samples,'avisos'=>$avisos,'consultas_por_chamador'=>$traces],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
