#!/usr/bin/env bash
set -euo pipefail
: "${F3BASE_SITE:?Informe WordPress local descartável}"
: "${F3BASE_BANCADA_TMP:?Informe diretório de evidências temporárias}"
export F3BASE_BANCADA_PORTA="${F3BASE_BANCADA_PORTA:-18110}"
mkdir -p "$F3BASE_BANCADA_TMP"
SUITE_110="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
F3BASE_DOCROOT="$F3BASE_SITE" PHP_CLI_SERVER_WORKERS=4 php -S "127.0.0.1:$F3BASE_BANCADA_PORTA" -t "$F3BASE_SITE" "$SUITE_110/bancada-wp/roteador.php" >"$F3BASE_BANCADA_TMP/servidor.log" 2>&1 &
SERVIDOR_110=$!
trap 'kill "$SERVIDOR_110" 2>/dev/null || true' EXIT
for tentativa_110 in {1..30}; do
  if curl -s --max-time 2 "http://127.0.0.1:$F3BASE_BANCADA_PORTA/" -o "$F3BASE_BANCADA_TMP/home.html"; then break; fi
  sleep 0.1
done
for passo_110 in "$@"; do
  php "$SUITE_110/bancada-wp/roteiro.php" "$F3BASE_BANCADA_TMP/$passo_110.json" "$passo_110" >"$F3BASE_BANCADA_TMP/$passo_110.log" 2>&1 || true
  if test -s "$F3BASE_BANCADA_TMP/$passo_110.json"; then cat "$F3BASE_BANCADA_TMP/$passo_110.json"; else printf '{"estado":"BLOCKED","nome":"wp.%s","mensagem":"Veredito ausente; confira log da bancada"}\n' "$passo_110"; fi
done
