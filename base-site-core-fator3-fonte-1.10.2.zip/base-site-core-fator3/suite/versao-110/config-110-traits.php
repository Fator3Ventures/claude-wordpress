<?php
/** O detector de símbolos acompanha traits usadas e carregadas pela classe. */
declare( strict_types = 1 );
$raiz = dirname( __DIR__, 2 );
require $raiz . '/suite/lib/regra.php';
require $raiz . '/suite/checagens/estatica.php';
$tmp = sys_get_temp_dir() . '/f3base-traits110-' . bin2hex( random_bytes( 6 ) ); mkdir( $tmp, 0700 );
$trait = "<?php trait F3Base_Trait_Prova { public static function validar() {} }";
$classe = "<?php require_once __DIR__ . '/trait.php'; class F3Base_Prova { use F3Base_Trait_Prova; } F3Base_Prova::validar();";
$casos = array(
 'trait_ligada' => array( $classe, $trait, true ),
 'trait_sem_require' => array( str_replace( "require_once __DIR__ . '/trait.php';", '', $classe ), $trait, false ),
 'trait_sem_use' => array( str_replace( 'use F3Base_Trait_Prova;', '', $classe ), $trait, false ),
 'trait_sem_metodo' => array( $classe, str_replace( 'validar()', 'outro()', $trait ), false ),
 'metodo_em_vizinha_nao_resolve' => array( str_replace( 'use F3Base_Trait_Prova;', '', $classe ) . ' class F3Base_Vizinha { public static function validar() {} }', $trait, false ),
 'trait_ausente' => array( $classe, '<?php', false ),
);
$provas = array();
try {
 foreach ( $casos as $nome => [$codigo, $trait_codigo, $esperado] ) {
  file_put_contents( $tmp . '/classe.php', $codigo ); file_put_contents( $tmp . '/trait.php', $trait_codigo );
  $r = f3b_ck_simbolos_resolvem( $tmp );
  $provas[$nome] = $r['ok'] === $esperado && 2 === $r['medidas'];
 }
 foreach ( array( 'positiva' => true, 'negativa' => false ) as $piso => $esperado ) {
  $provas['piso_' . $piso] = $esperado === f3b_ck_simbolos_resolvem( $raiz . '/suite/fixtures/estatica.simbolos_resolvem/' . $piso )['ok'];
 }
} finally { unlink( $tmp . '/classe.php' ); unlink( $tmp . '/trait.php' ); rmdir( $tmp ); }
$ok = ! in_array( false, $provas, true );
echo json_encode( array( 'ok' => $ok, 'testes' => $provas ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
exit( $ok ? 0 : 1 );
