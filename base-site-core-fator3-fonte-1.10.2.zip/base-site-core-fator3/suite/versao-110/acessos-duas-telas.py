#!/usr/bin/env python3
"""Dois clientes HTTP autenticados, sobreposição determinística no flock real e append."""
import argparse,concurrent.futures,hashlib,json,os,signal,sqlite3,subprocess,time
from html.parser import HTMLParser
from http.cookiejar import CookieJar
from pathlib import Path
from urllib import request,parse,error

class Client:
 def __init__(self):self.cookies=CookieJar();self.opener=request.build_opener(request.HTTPCookieProcessor(self.cookies))
 def get(self,url,timeout=25):return self.send(url,None,{},timeout)
 def post(self,url,data,headers=None,timeout=25):return self.send(url,parse.urlencode(data).encode(),headers or {},timeout)
 def send(self,url,data,headers,timeout):
  with self.opener.open(request.Request(url,data=data,headers=headers),timeout=timeout) as r:
   body=r.read().decode();return type('Response',(),{'status_code':r.status,'url':r.url,'headers':r.headers,'text':body,'json':lambda self:json.loads(body)})()

ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--php',default='php');p.add_argument('--site',type=Path,required=True);p.add_argument('--zip',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();site=a.site.resolve()
assert (site/'.f3base-bancada-110').is_file()
def php(mode):
 r=subprocess.run([a.php,str(ROOT/'suite/versao-110/acessos-duas-telas.php'),str(site),mode],capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr+r.stdout)
 return json.loads(r.stdout)
prep=php('preparar');sync=site/'wp-content/f3base-test-sync';sync.mkdir(exist_ok=True)
quoted="'"+str(sync).replace('\\','\\\\').replace("'","\\'")+"'"
mu=site/'wp-content/mu-plugins/duas-telas-barreira.php'
mu.write_text("""<?php
if(!is_file(ABSPATH.'.f3base-bancada-110'))return;
add_action('wp_ajax_f3base_acessos_atualizar',static function(){header('X-F3Base-Fixture-Pid: '.getmypid());},0);
add_filter('pre_set_transient_f3base_acessos_fotografia',static function($value){
 if(($_SERVER['HTTP_X_F3BASE_TESTE_ESPERAR']??'')!=='1')return $value;
 $dir=F3BASE_FIXTURE_SYNC;file_put_contents($dir.'/lock-retido',(string)getmypid());$deadline=microtime(true)+15;
 while(!is_file($dir.'/liberar-lock')&&microtime(true)<$deadline){usleep(10000);clearstatcache();}
 if(!is_file($dir.'/liberar-lock'))throw new RuntimeException('Timeout da barreira de teste');
 return $value;
});
""".replace('F3BASE_FIXTURE_SYNC',quoted))
env=dict(os.environ,F3BASE_DOCROOT=str(site),PHP_CLI_SERVER_WORKERS='4');base='http://127.0.0.1:18110';log=(site.parent/'duas-telas-servidor.log').open('w');server=subprocess.Popen([a.php,'-S','127.0.0.1:18110','-t',str(site),str(ROOT/'suite/bancada-wp/roteador.php')],env=env,stdout=log,stderr=log,start_new_session=True)
class Form(HTMLParser):
 def __init__(self):super().__init__();self.active=False;self.nonce=''
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if tag=='form':self.active=d.get('id')=='f3base-acessos-filtros'
  if tag=='input' and self.active and d.get('name')=='_wpnonce':self.nonce=d['value']
 def handle_endtag(self,tag):
  if tag=='form':self.active=False
class Rows(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.row=None;self.cell=None
 def handle_starttag(self,t,a):
  if t=='tr':self.row=[]
  if t=='td' and self.row is not None:self.cell=''
 def handle_data(self,d):
  if self.cell is not None:self.cell+=d
 def handle_endtag(self,t):
  if t=='td' and self.cell is not None:self.row.append(self.cell.strip());self.cell=None
  if t=='tr' and self.row is not None:self.rows.append(self.row);self.row=None
def total(html):
 r=Rows();r.feed(html)
 for row in r.rows:
  if row and row[0]=='/' and len(row)>=11:return int(row[3].replace('.','').replace(',',''))
 raise AssertionError('Linha de / ausente no HTML da resposta')
def ajax(session,nonce,pause=False):
 start=time.monotonic();r=session.post(base+'/wp-admin/admin-ajax.php',data={'action':'f3base_acessos_atualizar','_wpnonce':nonce,'dias':'1','classificacao':'conteudo','mostrar_todos':'0'},headers={'X-F3Base-Teste-Esperar':'1' if pause else '0'},timeout=25)
 j=r.json();assert r.status_code==200 and j.get('success'),r.text
 return {'pid':r.headers.get('X-F3Base-Fixture-Pid'),'inicio':start,'fim':time.monotonic(),'erro':j['data']['erro'],'total':None if j['data']['erro'] else total(j['data']['html'])}
report={'estado':'FALHA','zip_sha256':hashlib.sha256(a.zip.read_bytes()).hexdigest(),'wordpress':'6.9','rodadas':[]}
try:
 for _ in range(100):
  try:
   if Client().get(base+'/wp-login.php',timeout=1).status_code==200:break
  except (OSError,error.URLError):time.sleep(.05)
 sessions=[];nonces=[]
 for _ in range(2):
  s=Client();s.get(base+'/wp-login.php');r=s.post(base+'/wp-login.php',data={'log':'admin','pwd':'f3base-local-test-only','wp-submit':'Log In','redirect_to':base+'/wp-admin/','testcookie':'1'});assert '/wp-admin/' in r.url
  f=Form();f.feed(s.get(base+'/wp-admin/admin.php?page=f3base-medicao&aba=acessos').text);assert f.nonce;sessions.append(s);nonces.append(f.nonce)
 report['sessoes_distintas']={c.name:c.value for c in sessions[0].cookies}!={c.name:c.value for c in sessions[1].cookies};assert report['sessoes_distintas']
 with sqlite3.connect(site/'wp-content/database/.ht.sqlite') as c:report['integridade_antes']=c.execute('PRAGMA integrity_check').fetchall();assert report['integridade_antes']==[('ok',)]
 for expected,append in [(20,0),(27,7)]:
  if append:
   with (Path(prep['diretorio'])/'access.log').open('ab') as f:f.write((Path(prep['diretorio'])/'linha-append.txt').read_bytes()*append)
  for n in ['lock-retido','liberar-lock']:(sync/n).unlink(missing_ok=True)
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
   first=pool.submit(ajax,sessions[0],nonces[0],True);deadline=time.monotonic()+12
   while not (sync/'lock-retido').exists() and time.monotonic()<deadline:time.sleep(.01)
   assert (sync/'lock-retido').exists(),'Primeiro leitor não atingiu a seção crítica'
   second=pool.submit(ajax,sessions[1],nonces[1]);b=second.result();assert 'Atualização em curso' in b['erro'],b
   (sync/'liberar-lock').write_text('1');x=first.result()
  assert x['pid']!=b['pid'] and x['inicio']<b['fim']<x['fim'];assert x['total']==expected
  checkpoint=php('checkpoint');assert checkpoint['total']==expected and checkpoint['linhas_processadas']==expected and checkpoint['offset']==checkpoint['arquivo_bytes'] and checkpoint['historico_hoje']==0 and checkpoint['ignoradas']==0,checkpoint
  converged=[ajax(sessions[i],nonces[i]) for i in range(2)];assert all(r['total']==expected and not r['erro'] for r in converged)
  report['rodadas'].append({'linhas_esperadas':expected,'append':append,'primeiro':x,'segundo':b,'checkpoint':checkpoint,'convergencia_totais':[r['total'] for r in converged]})
 report['dst']=php('dst')
 with sqlite3.connect(site/'wp-content/database/.ht.sqlite') as c:report['integridade_depois']=c.execute('PRAGMA integrity_check').fetchall();report['journal_mode']=c.execute('PRAGMA journal_mode').fetchone()[0]
 assert report['integridade_depois']==[('ok',)] and report['journal_mode']=='delete'
 report['metodo']='Dois clientes HTTP autenticados e processos distintos. Barreira apenas na fixture pre_set_transient segura o primeiro leitor dentro do flock real para sobrepor a segunda requisição; nenhuma linha de produção alterada.';report['estado']='OK'
finally:
 (sync/'liberar-lock').write_text('1');os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=10);log.close();mu.unlink(missing_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'estado':report['estado'],'rodadas':len(report['rodadas']),'convergencia':[r['convergencia_totais'] for r in report['rodadas']],'dst':report.get('dst',{}).get('estado')}))
