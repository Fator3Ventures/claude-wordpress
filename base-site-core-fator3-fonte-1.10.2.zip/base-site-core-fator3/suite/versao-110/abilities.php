<?php
/** Verifica consultas/mescla pelo registro real de abilities e schema nativo WP. */
declare(strict_types=1);
$site=(string)getenv('F3BASE_SITE');
if(!$site || !is_file($site.'/wp-load.php')){fwrite(STDERR,"BLOCKED: F3BASE_SITE sem WP real\n");exit(2);}
require $site.'/wp-load.php';
wp_set_current_user(1);
if(!function_exists('wp_get_ability')){fwrite(STDERR,"BLOCKED: Abilities API ausente\n");exit(2);}
$warnings=[];$cases=[];
set_error_handler(static function($n,$s,$f,$l)use(&$warnings){if(error_reporting()&$n)$warnings[]=['tipo'=>$n,'mensagem'=>$s,'arquivo'=>basename($f),'linha'=>$l];return false;});
function a110_assert(bool $yes,string $message):void{if(!$yes)throw new RuntimeException($message);}
function a110_run(string $name,array $input=[]):array {
 $ability=wp_get_ability($name);a110_assert(null!==$ability,'Ability não registrada: '.$name);
 $result=$ability->execute($input);
 a110_assert(!is_wp_error($result),'Execução recusada: '.$name.(is_wp_error($result)?': '.$result->get_error_message():''));
 $valid=rest_validate_value_from_schema($result,$ability->get_output_schema(),$name);
 a110_assert(!is_wp_error($valid),'Schema de saída inválido: '.$name.(is_wp_error($valid)?': '.$valid->get_error_message():''));
 $sanitized=rest_sanitize_value_from_schema($result,$ability->get_output_schema(),$name);
 a110_assert(!is_wp_error($sanitized),'Sanitização recusada: '.$name);
 a110_assert(wp_json_encode($result)===wp_json_encode($sanitized),'Sanitização alterou resultado: '.$name);
 return $result;
}
function a110_case(string $name,callable $fn):void{global $cases;try{$detail=$fn();$cases[]=['nome'=>$name,'estado'=>'OK','evidencia'=>$detail];}catch(Throwable $e){$cases[]=['nome'=>$name,'estado'=>'FALHA','mensagem'=>$e->getMessage()];}}
a110_case('consultas_compactas_schema',static function(){
 $full=a110_run('f3base/como-usar');$compact=a110_run('f3base/como-usar',['compacto'=>true]);
 $bytes=strlen(wp_json_encode($full));$small=strlen(wp_json_encode($compact));
 a110_assert($small<($bytes*0.2),'Compactação não atingiu 20% na mesma fixture');
 a110_run('f3base/como-usar',['compacto'=>true,'assuntos'=>['consentimento'],'incluir'=>['procedencia']]);
 a110_run('f3base/config-core-contrato-v1',['compacto'=>true,'nome'=>'f3base_consentimento']);
 a110_run('f3base/config-core-contrato-v1');
 return ['bytes_completa'=>$bytes,'bytes_compacta'=>$small,'fracao'=>round($small/$bytes,4)];
});
a110_case('consultas_readonly',static function(){
 global $wpdb;
 $hash=static fn()=>hash('sha256',wp_json_encode($wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name",ARRAY_A)));
 $before=$hash();$http=0;$observer=static function($r)use(&$http){$http++;return $r;};add_filter('pre_http_request',$observer);
 foreach(['f3base/como-usar','f3base/config-core-ler','f3base/config-core-contrato-v1'] as $name)a110_run($name);
 a110_run('f3base/config-core-perfil-avaliar');
 remove_filter('pre_http_request',$observer);
 a110_assert($http===0,'Consulta iniciou HTTP');a110_assert($before===$hash(),'Consulta alterou options/cron');
 return ['http'=>$http,'options_inalteradas'=>true];
});
a110_case('permissao_nativa',static function(){
 wp_set_current_user(0);
 try{foreach(['f3base/como-usar','f3base/config-core-ler','f3base/config-core-contrato-v1','f3base/config-core-perfil-avaliar']as$name){$a=wp_get_ability($name);a110_assert($a!==null,'Ability ausente');$r=$a->execute([]);a110_assert(is_wp_error($r),'Consulta anônima autorizada: '.$name);}}finally{wp_set_current_user(1);}
 return ['anonimo_recusado'=>true];
});
a110_case('mescla_simulacao_aplicacao_conflito',static function(){
 $name='f3base_contato';$original=F3Base_Options::fotografia($name);$restaurar=false;
 try{
  $read=a110_run('f3base/config-core-ler',['nome'=>$name]);$revision=$read['opcoes'][$name]['revisao'];
  $input=['nome'=>$name,'valor'=>['whatsapp_e164'=>'5511999988776'],'mesclar'=>true,'revisao_esperada'=>$revision];
  $preview=a110_run('f3base/config-core-escrever',$input);
  a110_assert(!empty($preview['ok'])&&empty($preview['persisted'])&&!empty($preview['simulado']),'Simulação não distingue persistência');
  a110_assert(F3Base_Options::revisao($name)===$revision,'Simulação gravou option');
  $apply=a110_run('f3base/config-core-escrever',$input+['simular'=>false]);$restaurar=true;
  a110_assert(!empty($apply['persisted']),'Aplicação não persistiu');
  $conflict=a110_run('f3base/config-core-escrever',$input+['simular'=>false]);
  a110_assert(empty($conflict['persisted'])&&($conflict['codigo']??'')==='conflito','Revisão obsoleta não foi recusada');
  $now=F3Base_Options::ler($name);foreach($original['valor'] as$key=>$value)if($key!=='whatsapp_e164')a110_assert(($now[$key]??null)===$value,'Mescla perdeu campo '.$key);
  return ['persisted'=>$apply['persisted'],'efeito'=>$apply['effect']['status']??null,'verificacao'=>$apply['verification']['status']??null];
 }finally{if($restaurar)F3Base_Options::gravar($name,$original['valor'],F3Base_Options::ORIGEM_MANUAL,F3Base_Options::revisao($name));}
});
a110_case('perfil_sem_documento_indeterminado',static function(){
 $r=a110_run('f3base/config-core-perfil-avaliar');
 a110_assert(str_contains(wp_json_encode($r),'indeterminado'),'Perfil ausente não devolveu indeterminado');
 return ['resposta'=>$r];
});
restore_error_handler();
$cases[]=['nome'=>'sem_avisos_nativos','estado'=>$warnings?'FALHA':'OK','avisos'=>$warnings];
echo wp_json_encode(['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'casos'=>$cases],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
exit(count(array_filter($cases,static fn($c)=>$c['estado']!=='OK'))?1:0);
