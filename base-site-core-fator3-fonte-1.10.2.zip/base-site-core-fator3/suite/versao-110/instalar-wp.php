<?php
/** Instala somente a bancada descartável; nunca recebe credenciais de um site remoto. */
declare(strict_types=1);
$site = getenv('F3BASE_SITE');
if (!$site || !is_file($site.'/wp-config.php') || !is_file($site.'/.f3base-bancada-110')) {
    fwrite(STDERR, "F3BASE_SITE deve apontar para uma bancada descartável marcada pelo preparador.\n"); exit(2);
}
define('WP_INSTALLING', true);
require $site.'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/upgrade.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
if (!is_blog_installed()) {
    wp_install('Bancada Core 1.10.0', 'admin', 'admin@example.invalid', true, '', 'f3base-local-test-only');
}
wp_set_current_user(1);
if(is_dir(WP_CONTENT_DIR.'/themes/f3base-bancada'))switch_theme('f3base-bancada');
update_option('blog_public', 1);
update_option('timezone_string', 'America/Sao_Paulo');
update_option('permalink_structure', '/%postname%/');
foreach (['wordpress-seo/wp-seo.php', 'wp-super-cache/wp-cache.php', 'base-site-core-fator3/base-site-core-fator3.php'] as $plugin) {
    $r=activate_plugin($plugin);
    if (is_wp_error($r)) {fwrite(STDERR, $plugin.': '.$r->get_error_message()."\n");exit(1);}
}
$config = str_replace('?>', '', file_get_contents(WP_CONTENT_DIR.'/plugins/wp-super-cache/wp-cache-config-sample.php'))."\n";
foreach(['cache_enabled'=>true,'super_cache_enabled'=>false,'wp_cache_mod_rewrite'=>0,'wp_cache_not_logged_in'=>2,'wp_cache_save_headers'=>1,'cache_max_time'=>3600,'wp_cache_preload_on'=>0,'wp_cache_ignore_tracking_parameters'=>1,'cache_path'=>WP_CONTENT_DIR.'/cache/'] as $key=>$value) {
    $config.='$'.$key.' = '.var_export($value,true).";\n";
}
file_put_contents(WP_CONTENT_DIR.'/wp-cache-config.php', $config);
$advanced=WP_CONTENT_DIR.'/plugins/wp-super-cache/advanced-cache.php';
if(is_file($advanced))copy($advanced, WP_CONTENT_DIR.'/advanced-cache.php');
flush_rewrite_rules(false);
$manifest = ['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'sqlite'=>SQLite3::version()['versionString'],'driver'=>get_class($GLOBALS['wpdb']),'plugins'=>get_option('active_plugins'),'executor'=>'cron manual; DISABLE_WP_CRON=true','cache'=>'WP Super Cache, Simple, supercache off','bancada'=>'localhost HTTP, sem serviços de anúncios externos'];
echo wp_json_encode($manifest, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
