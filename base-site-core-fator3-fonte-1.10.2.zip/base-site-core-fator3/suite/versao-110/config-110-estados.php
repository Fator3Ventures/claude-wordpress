<?php
/** Estados de negócio e os vereditos da suíte têm contratos distintos. */
declare( strict_types = 1 );
$raiz = dirname( __DIR__, 2 );
require $raiz . '/suite/lib/regra.php';
require $raiz . '/suite/checagens/estatica.php';
$chave = 'es' . 'tado';
$casos = array(
 'negocio' => array( "<?php function avaliar() { return ['$chave'=>'indeterminado']; } function fila() { return ['$chave'=>'pendente']; }", true ),
 'relatorio_valido' => array( "<?php return ['$chave'=>'WARN'];", true ),
 'relatorio_inventado' => array( "<?php return ['$chave'=>'QUASE_OK'];", false ),
 'emissor_com_estado_de_fila' => array( "<?php $chave('pendente', 'caso', '', '', '');", false ),
 'aviso_com_caixa_invalida' => array( "<?php class Modulo { function avisos() { return [['$chave'=>'warn']]; } }", false ),
 'metodo_estado_de_negocio' => array( "<?php \$fila->$chave('pendente');", true ),
);
$tmp = sys_get_temp_dir() . '/f3base-estados110-' . bin2hex( random_bytes( 6 ) ); mkdir( $tmp, 0700 );
$provas = array();
try {
 foreach ( $casos as $nome => [$codigo, $esperado] ) {
  file_put_contents( $tmp . '/relatorio.php', $codigo );
  $r = f3b_ck_estados_fechados( $tmp );
  $provas[$nome] = $r['ok'] === $esperado && 1 === $r['medidas'];
 }
 foreach ( array( 'positiva' => true, 'negativa' => false ) as $piso => $esperado ) {
  $provas['piso_' . $piso] = $esperado === f3b_ck_estados_fechados( $raiz . '/suite/fixtures/estatica.estados_fechados/' . $piso )['ok'];
 }
} finally { unlink( $tmp . '/relatorio.php' ); rmdir( $tmp ); }
$ok = ! in_array( false, $provas, true );
echo json_encode( array( 'ok' => $ok, 'testes' => $provas ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
exit( $ok ? 0 : 1 );
