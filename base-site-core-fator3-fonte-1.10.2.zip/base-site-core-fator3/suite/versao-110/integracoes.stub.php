<?php
/** Assinaturas observadas nas integrações opcionais do perfil; sem implementações para teste. */
function wp_cache_clear_cache() {}
class WPSEO_Sitemaps_Router { public static function get_base_url($page = '') {} }
class Flamingo_Inbound_Message { public static function add($args = array()) {} }
class WP_CLI {
 public static function add_command($name, $callable, $args = array()) {}
 public static function line($message = '') {}
 public static function error($message, $exit = true) {}
 public static function halt($code = 0) {}
 public static function success($message) {}
}
