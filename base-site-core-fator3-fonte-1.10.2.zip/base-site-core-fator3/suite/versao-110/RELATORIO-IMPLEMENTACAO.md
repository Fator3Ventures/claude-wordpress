# Base Site Core Fator3 1.10.0 — relatório de implementação

Estado: implementação concluída e validada na bancada local. Versão 1.10.0, em 22/09/2026.

## Alterações implementadas

Os 35 itens C01–C11, F01–F07, M01–M07 e N01–N10 estão relacionados a fontes e provas em [RASTREABILIDADE.md](RASTREABILIDADE.md). O plano usado está em [PLANO-IMPLEMENTACAO.md](PLANO-IMPLEMENTACAO.md).

- Configuração com revisão esperada, confirmação da persistência, procedência independente e tentativas recusadas separadas; mesclagem tipada e consultas compactas por contrato.
- Consentimento granular opcional, revogação verificável, inicialização ordenada do tracking e política opcional de sessão por perfil. Os modos legados são preservados.
- Fila CAPI com destino e TTL estáveis, reservas, cancelamento e eliminação coordenados; entrega incerta exige reconciliação e não é reenviada automaticamente.
- Coleta reservada de logs fechados, histórico por contribuições de arquivos, cobertura e classificação versionadas. Hoje permanece temporário; atualização automática é opcional.
- Comparação de períodos e CSV, inclusão explícita de hoje como parcial, consultas administrativas paginadas e tempo ativo estimado opcional.
- Publicação de robots/llms com inspeções e provas separadas da configuração; conversão editorial conservadora; convivência com Yoast e WP Super Cache.
- Saúde operacional e agenda unificada, com última tentativa, último sucesso, saldo conhecido ou não medido, recuperação de tarefas e comandos WP-CLI limitados.
- Configuração por seção, abas separadas, campos mais fáceis de usar, preservação dos filtros e tabelas acessíveis em telas pequenas.
- Separação interna do catálogo, validação, persistência e efeitos, preservando a fachada pública; fontes reproduzíveis, dependências fixadas e remoção de artefatos antigos sem consumidor.

## Ambiente e escopo das provas

WordPress 6.9, PHP 8.3.6, SQLite Database Integration 3.0.2, SQLite do PHP 3.45.1 com journal DELETE, Yoast 28.4 e WP Super Cache 3.1.3. Navegador Chromium 153.0.8010.52. Clones de banco usam a API de backup SQLite e conferência de integridade; bancos, dependências instaladas e caches não entram nas fontes.

Os registros finais ficam em `suite/evidencias-110`. Os testes novos estão em `suite/110`, `suite/versao-110`, `suite/medicao-110` e `suite/abilities-rest-110`. A matriz final confirmou 78/78 mutantes aplicados e detectados no WordPress real, com comparação dos arquivos funcionais do instalador; os retestes de três casos ficaram registrados. A suíte legada mantém seus cenários adversariais; adaptações das fixtures acompanham o contrato atual e não dispensam defeitos detectáveis.

A validação da Abilities API usa o registro e o controller reais do WordPress, sem depender do conector MCP para expor as operações. As permissões administrativas e a sanitização do schema polimórfico permanecem verificadas. Testes de publicação, cron e CSV usam HTTP local; envios para os fornecedores de anúncios são interceptados.

## Validação do instalador final

O ZIP `base-site-core-fator3-1.10.0.zip`, SHA256 `61f631d20ff69e977ea341897e4aa90594acfb29ca9ef1143ee427949eea4bf3`, foi extraído em doze instalações isoladas da bancada. Os doze grupos passaram: abilities, controller REST nativo, configuração e concorrência, administração/saúde, consentimento, medição, comparação com hoje, fotografias em lote, CAPI, execução/migração/recuperação de processo, publicação e WP-CLI. Todos os bancos terminaram íntegros em journal DELETE. A atualização do ZIP anterior 1.9.2 para este instalador passou em 72 verificações, sem desativar/reativar e com integridade confirmada. A suíte completa final terminou com 174 OK, zero falhas/bloqueios e 12 N/A explicitamente condicionados; o selo vincula essa rodada ao mesmo SHA256. Os resultados completos desse ZIP estão em `suite/evidencias-110/zip-final/resultado.json` e nos arquivos de cada grupo.

A exportação CSV foi conferida via HTTP autenticado em 182 verificações: agregados e comparações, conciliação com tabelas e consultas, períodos completos/parciais, filtros, fórmulas, corte, ausência de dados, base zero e controles de acesso. O registro REST nativo teve 101 verificações sem avisos. Estes números representam grupos sobrepostos e não devem ser somados como uma contagem de testes distintos.

O teste de duas sessões HTTP simultâneas confirmou reserva e convergência da contagem, inclusive após acrescentar linhas ao log, sem duplicação nem inclusão de hoje no histórico. O parser real também passou nas transições históricas de dias com 23 e 25 horas. A sincronização determinística entre processos foi feita apenas na fixture de teste.

## Desempenho e qualidade

O benchmark pareado usou acervos de 10, 100 e 1.000 conteúdos, com os limites de aceite declarados antes da execução. Os 64 critérios passaram após as correções. Na versão final medida, a tela de configuração fez 5 consultas frias e 2 aquecidas; a aba técnica, 42 e 38; Acessos, 6 e 3. A classificação dos dez caminhos observados ficou em 16 consultas frias, sem crescer com o acervo testado. Leituras não provocaram purgas; vinte gravações relevantes resultaram em uma purga.

O benchmark encontrou e documentou uma regressão intermediária de até 1.500 consultas na aba técnica. Ela foi corrigida removendo a enumeração de conteúdo do diagnóstico e reunindo fotografias de configuração. O resultado anterior permanece identificado como pré-correção nas evidências. A escrita condicional exige mais consultas para conferir persistência e auditoria; o relatório não promete aceleração de todas as operações.

As projeções compactas finais mediram 2.389 bytes para como-usar e 9.687 bytes para o contrato, aproximadamente 7,7% e 8,3% das respostas completas respectivas. São resultados do acervo e das preferências da bancada, não limites universais de tamanho ou latência.

PHPStan concluiu sem erros. O gate incremental PHPCS/WPCS não encontrou violações novas; a dívida anterior medida continua explicitamente na baseline. Mutações de teste confirmaram que as ferramentas detectam uma chamada inexistente e uma saída sem escape. A auditoria das dependências de desenvolvimento fixadas não indicou vulnerabilidades aplicáveis na consulta realizada.

## Fontes e reprodução

O pacote de fontes contém o código completo, testes, fixtures declaradas, documentação, licenças, dependências fixadas e evidências. Foram retirados 23 artefatos antigos sem consumidor; não entram bancos, caches, dependências instaladas nem o instalador atual embutido. Referências de versões anteriores permanecem apenas quando consumidas pelos testes.

A conferência executou dois empacotamentos idênticos, mesmo com um ZIP residual e datas de arquivo diferentes, verificou os hashes individuais, extraiu as fontes e reconstruiu o mesmo instalador aprovado. São 695 arquivos com hash no manifesto interno. As instruções de reprodução estão em `suite/versao-110/LEIA-ME.md`.

## Recuperação

O ensaio de código 1.10.0 → 1.9.2 → 1.10.0 preservou os registros, cancelamentos, destinos e TTLs, sem restauração de banco, mantendo consumidores pausados. Ele também comprovou que o consumidor antigo não interpreta os novos estados com segurança. Portanto, o retorno operacional à 1.9.2 não é suportado; a recuperação validada é reinstalar o código compatível e reconciliar a fila antes de retomar os envios. A guarda usada para pausar o consumidor antigo é uma fixture do ensaio, não um mecanismo que o plugin antigo ofereça automaticamente.

## Limites da validação

Não houve implantação nem validação no WordPress remoto do usuário. Os ensaios locais não certificam a configuração real de HTTPS/HSTS, CDN, servidor web, cron da hospedagem ou recebimento por GA4, GTM e Meta. WP-Cron depende do executor disponível; o Core não cria tarefas no sistema operacional. A estimativa de tempo ativo não comprova atenção humana.

PHPStan foi executado no nível 1, e o gate PHPCS/WPCS compara com uma baseline explícita da versão anterior; isso não significa que toda a dívida de estilo legada tenha sido eliminada. Multisite, matriz MySQL, atualizador próprio, coletor CSP e alterações no journal do implantador ficaram fora do escopo aprovado.
