<?php
/** Preparação/inspeção local para a prova HTTP concorrente; não integra o produto. */
declare(strict_types=1);
$site=rtrim($argv[1]??'','/');
if(!is_file($site.'/.f3base-bancada-110'))throw new RuntimeException('Bancada marcada obrigatória');
require $site.'/wp-load.php';wp_set_current_user(1);
$dir=dirname($site).'/logs-duas-telas';$mode=$argv[2]??'';
if($mode==='preparar'){
 wp_mkdir_p($dir);update_option('timezone_string','America/Sao_Paulo');
 $line='127.0.0.1 - - ['.gmdate('d/M/Y:H:i:s O').'] "GET / HTTP/1.1" 200 10 "-" "Mozilla/5.0"'."\n";
 file_put_contents($dir.'/access.log',str_repeat($line,20));file_put_contents($dir.'/linha-append.txt',$line);
 $c=F3Base_Modulo_Acessos_Servidor::config();$c['ligado']=true;$c['padrao_do_log']=$dir.'/access.log.*';
 $r=F3Base_Options::gravar('f3base_acessos',$c);if(empty($r['persisted']))throw new RuntimeException('Configuração não persistiu');
 if(!(new F3Base_Modulo_Acessos_Servidor())->garantir_estrutura())throw new RuntimeException('Tabela de acessos ausente');delete_transient(F3Base_Acessos_Atuais::CACHE);
 echo wp_json_encode(['diretorio'=>$dir,'linhas_iniciais'=>20,'bytes'=>filesize($dir.'/access.log'),'versao'=>F3BASE_PLUGIN_VERSAO])."\n";exit;
}
if($mode==='checkpoint'){
 $e=get_transient(F3Base_Acessos_Atuais::CACHE);$t=$GLOBALS['wpdb']->prefix.F3Base_Modulo_Acessos_Servidor::TABELA;
 echo wp_json_encode(['dia'=>wp_date('Y-m-d'),'linhas_processadas'=>$e['n']??0,'total'=>array_sum(array_column($e['agregados']??[],'contagem')),'offset'=>$e['offset']??0,'arquivo_bytes'=>filesize($dir.'/access.log'),'historico_hoje'=>(int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare('SELECT SUM(contagem) FROM %i WHERE dia=%s',$t,wp_date('Y-m-d'))),'ignoradas'=>$e['ignoradas']??0])."\n";exit;
}
if($mode==='dst'){
 $before=get_option('timezone_string');update_option('timezone_string','America/New_York');$results=[];
 try{
  $cases=[
   'primavera'=>['2026-03-08',['2026-03-08 04:59:59','2026-03-08 05:00:00','2026-03-08 06:59:59','2026-03-08 07:00:00','2026-03-09 03:59:59','2026-03-09 04:00:00'],['2026-03-07'=>1,'2026-03-08'=>4,'2026-03-09'=>1],23],
   'outono'=>['2025-11-02',['2025-11-02 03:59:59','2025-11-02 04:00:00','2025-11-02 05:30:00','2025-11-02 06:30:00','2025-11-03 04:59:59','2025-11-03 05:00:00'],['2025-11-01'=>1,'2025-11-02'=>4,'2025-11-03'=>1],25],
  ];
  foreach($cases as $name=>[$day,$dates,$expected,$hours]){
   $file=$dir.'/dst-'.$name.'.log';$body='';foreach($dates as $date)$body.='127.0.0.1 - - ['.(new DateTimeImmutable($date,new DateTimeZone('UTC')))->format('d/M/Y:H:i:s O').'] "GET / HTTP/1.1" 200 10 "-" "Mozilla/5.0"'."\n";
   file_put_contents($file,$body);clearstatcache();$r=F3Base_Acessos_Coleta::ler_arquivo(['nome'=>$file,'tamanho'=>filesize($file),'mtime'=>filemtime($file)],[],'2026-03-11');$totals=[];
   foreach($r['linhas'] as $row)$totals[$row['dia']]=($totals[$row['dia']]??0)+(int)$row['contagem'];ksort($totals);if($totals!==$expected)throw new RuntimeException('Distribuição DST incorreta');
   $start=new DateTimeImmutable($day,wp_timezone());$duration=($start->modify('+1 day')->getTimestamp()-$start->getTimestamp())/3600;if($duration!=$hours)throw new RuntimeException('Duração civil incorreta');
   $results[$name]=['estado'=>'OK','fuso'=>wp_timezone_string(),'dia'=>$day,'horas'=>$hours,'totais'=>$totals,'linhas'=>$r['lidas'],'ignoradas'=>$r['ignoradas']];
  }
 }finally{update_option('timezone_string',$before);}
 echo wp_json_encode(['estado'=>'OK','casos'=>$results,'escopo'=>'Parser real de arquivos históricos no fuso controlado; não altera o relógio nem executa cron.'])."\n";exit;
}
throw new RuntimeException('Modo inválido');
