<?php
/** Prova adversarial do detector da guarda MCP, com a mesma função usada no build. */
declare( strict_types = 1 );
$raiz = dirname( __DIR__, 2 );
require $raiz . '/suite/lib/regra.php';
require $raiz . '/suite/checagens/estatica.php';
$arquivo = '/fontes/plugin/includes/class-f3base-modulo-guarda.php';
$positivo = (string) file_get_contents( $raiz . '/suite/fixtures/estatica.sem_recusa_de_escrita_do_agente/positiva' . $arquivo );
$retorno = 'return array_values( array_unique( array_merge( is_array( $protegidas ) ? $protegidas : array(), F3Base_Options::proprias() ) ) );';
$casos = array(
	'catalogo_e_api' => array( $positivo, true ),
	'perde_lista_do_outro_dono' => array( str_replace( $retorno, 'return F3Base_Options::proprias();', $positivo ), false ),
	'lista_digitada_sem_catalogo' => array( str_replace( $retorno, "return array_merge( \$protegidas, array( 'f3base_contato' ) );", $positivo ), false ),
	'prefixo_generico' => array( str_replace( $retorno, "if ( str_starts_with( \$nome, 'f3base_' ) ) { \$protegidas[] = \$nome; } return \$protegidas;", $positivo ), false ),
	'filtro_nao_confirmado' => array( str_replace( 'wp_mcp_ultimate_protected_options', 'mcp_protected_options', $positivo ), false ),
	'api_do_dono_removida' => array( str_replace( 'F3Base_Options::gravar', 'outro_gravador', $positivo ), false ),
	'bloqueio_global' => array( $positivo . "\nadd_filter( 'pre_update_option', 'bloquear_todas' );\n", false ),
);
$tmp = sys_get_temp_dir() . '/f3base-gate110-' . bin2hex( random_bytes( 6 ) );
mkdir( $tmp . '/fontes/plugin/includes', 0700, true );
$resultados = array(); $ok = true;
try {
	foreach ( $casos as $nome => [ $codigo, $esperado ] ) {
		file_put_contents( $tmp . $arquivo, $codigo );
		$r = f3b_ck_sem_recusa_de_escrita_do_agente( $tmp );
		$resultados[ $nome ] = $r['ok'] === $esperado && $r['medidas'] > 0;
		$ok = $ok && $resultados[ $nome ];
	}
} finally {
	unlink( $tmp . $arquivo );
	rmdir( $tmp . '/fontes/plugin/includes' ); rmdir( $tmp . '/fontes/plugin' ); rmdir( $tmp . '/fontes' ); rmdir( $tmp );
}
echo json_encode( array( 'ok' => $ok, 'testes' => $resultados ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
exit( $ok ? 0 : 1 );
