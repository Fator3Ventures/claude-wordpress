#!/usr/bin/env python3
"""Troca somente código 1.10→1.9.2→1.10 em clone SQLite DELETE; nunca restaura banco antigo."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,sqlite3,subprocess,tempfile,zipfile
p=argparse.ArgumentParser()
p.add_argument('--template',required=True,type=Path)
p.add_argument('--plugin-192',required=True,type=Path)
p.add_argument('--fonte-110',required=True,type=Path)
p.add_argument('--php',required=True,type=Path)
p.add_argument('--saida',required=True,type=Path)
a=p.parse_args();here=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def tree_manifest(path):return {str(f.relative_to(path)):sha(f) for f in sorted(path.rglob('*')) if f.is_file()}
def clone(source,target):
 r=subprocess.run(['python3',str(here/'clonar-bancada.py'),str(source),str(target)],capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stdout+r.stderr)
def install(source,site):
 target=site/'wp-content/plugins/base-site-core-fator3'
 if target.exists():shutil.rmtree(target)
 shutil.copytree(source,target)
def integrity(site):
 with sqlite3.connect(site/'wp-content/database/.ht.sqlite') as c:
  return {'integrity_check':[r[0] for r in c.execute('pragma integrity_check')],'journal_mode':c.execute('pragma journal_mode').fetchone()[0]}
def run(site,phase):
 env=os.environ.copy();env['F3BASE_SITE']=str(site)
 r=subprocess.run([str(a.php),str(here/'rollback-recuperacao-worker.php'),phase],capture_output=True,text=True,env=env,timeout=120)
 try:out=json.loads(r.stdout)
 except json.JSONDecodeError:raise RuntimeError(phase+': resposta nãoJSON: '+r.stdout+r.stderr)
 if r.returncode or not out.get('ok') or r.stderr:raise RuntimeError(phase+': '+r.stdout+r.stderr)
 return out

mu=r'''<?php
/** Somente fixture de manutenção local; não faz parte do plugin distribuído. */
$GLOBALS['rb110_http_tentativas']=0;
add_filter('pre_http_request',static function(){++$GLOBALS['rb110_http_tentativas'];return new WP_Error('rollback_sem_rede','Ensaio local sem transporte externo.');},PHP_INT_MIN,3);
add_filter('pre_schedule_event',static function($pre,$evento){return in_array($evento->hook,array('f3base_capi_recuperar','f3base_meta_capi_enviar'),true)?false:$pre;},PHP_INT_MIN,2);
add_action('init',static function(){foreach(array('f3base_capi_recuperar','f3base_meta_capi_enviar') as $hook){wp_unschedule_hook($hook);remove_all_actions($hook);}},PHP_INT_MAX);
'''
with tempfile.TemporaryDirectory(prefix='f3base-rollback110-') as td:
 base=Path(td);source110=base/'fonte-110';shutil.copytree(a.fonte_110,source110)
 manifest=tree_manifest(source110)
 old=base/'codigo-192';old.mkdir()
 with zipfile.ZipFile(a.plugin_192) as z:
  for info in z.infolist():
   rel=Path(info.filename)
   if rel.is_absolute() or '..' in rel.parts:raise RuntimeError('Zip antigo contém caminho inválido')
  z.extractall(old)
 mains=list(old.rglob('base-site-core-fator3.php'))
 if len(mains)!=1:raise RuntimeError('Não foi encontrado um único plugin antigo')
 source192=mains[0].parent
 site=base/'percurso';clone(a.template.resolve(),site);install(source110,site)
 mudir=site/'wp-content/mu-plugins';mudir.mkdir(exist_ok=True);(mudir/'rollback-pausa.php').write_text(mu)
 preparado=run(site,'preparar');before=integrity(site)
 install(source192,site);legado=run(site,'legado')
 # Sonda destrutiva fica em OUTRO clone, sem tocar o banco do percurso de recuperação.
 probe=base/'sonda-legada';clone(site,probe);sonda=run(probe,'sonda_legada')
 install(source110,site);recuperado=run(site,'recuperar');after=integrity(site)
 preserved=preparado['linhas']==legado['linhas']==recuperado['linhas']
 ttl=all(preparado['linhas'][k]['expira']==recuperado['linhas'][k]['expira'] for k in preparado['linhas'])
 checks={'codigo_192_real':legado['versao']=='1.9.2','codigo_110_recuperado':recuperado['versao']=='1.10.0','registros_preservados_no_percurso_pausado':preserved,'ttl_sem_renovacao':ttl,'nenhuma_tentativa_http':all(x['http_tentativas']==0 for x in (preparado,legado,sonda,recuperado)),'integridade_antes_depois':before['integrity_check']==after['integrity_check']==['ok'],'journal_delete':before['journal_mode']==after['journal_mode']=='delete'}
 result={'ok':all(checks.values()),'escopo':'WordPress real local; troca somente de arquivos, sem restaurar banco e sem HTTP externo. Sonda destrutiva em clone separado.','fontes':{'plugin_192_sha256':sha(a.plugin_192),'fonte_110_manifest_sha256':hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'fonte_110_arquivos':len(manifest),'manifesto_110':manifest},'provas':checks,'integridade':{'antes':before,'depois':after},'preparado':preparado,'legado_pausado':legado,'sonda_legada_isolada':sonda,'recuperacao_adiante':recuperado,'conclusao':{'rollback_operacional_suportado':False,'recuperacao_adiante_pausada_comprovada':preserved,'limites':['1.9.2 lê a tabela ampliada, mas não implementa cancelar, resolver_destino ou reconciliar.','1.9.2 reserva novamente estado enviando com lease vencida; não conhece a evidência iniciado da1.10.','1.9.2 não expira payload no novo estado suspenso, mesmo após TTL.','Token vazio evita HTTP, mas a chamada direta do consumidor1.9.2 pode apagar payload como falhou. Pausar também callbacks/agendamento e cron externo.','No percurso ensaiado, agenda e callbacks permaneceram pausados por guarda local de manutenção além do token vazio e DISABLE_WP_CRON. Esta guarda é fixture, não recurso automático de rollback do Core.','A recuperação reinstalou o mesmo código1.10 capturado no início e confirmou schema sem perda de registros nem renovação de TTL. Consumidores não foram reativados.','Envio externo, retomada de conversões e ativação em produção não foram executados. Revisar destinos, consentimentos, expiração e casos incertos antes de qualquer retomada.']}}
 a.saida.parent.mkdir(parents=True,exist_ok=True);a.saida.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'ok':result['ok'],'provas':checks,'evidencia':str(a.saida),'rollback_operacional_suportado':False},ensure_ascii=False,indent=2))
 if not result['ok']:raise SystemExit(1)
