#!/usr/bin/env python3
"""Executa as operações com acervos crescentes e aplica a régua anterior aos resultados."""
import argparse,json,os,sqlite3,statistics,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--php',default='php');p.add_argument('--site-atual',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
report=json.loads(a.baseline.read_text());report.pop('checks',None);report.pop('estado',None)
site=a.site_atual.resolve();assert (site/'.f3base-bancada-110').is_file()
db=site/'wp-content/database/.ht.sqlite'
def integrity():
 with sqlite3.connect(db) as c:return c.execute('PRAGMA integrity_check').fetchall(),c.execute('PRAGMA journal_mode').fetchone()[0]
before,mode=integrity();assert before==[('ok',)] and mode=='delete'
current={'integridade_antes':before,'journal_mode':mode,'acervos':{}};env=dict(os.environ,F3BASE_SITE=str(site));env.pop('F3BASE_PROFILE_SQL',None)
def php(file,*args):
 r=subprocess.run([a.php,str(ROOT/'suite/versao-110'/file),*args],capture_output=True,text=True,env=env,cwd=ROOT)
 if r.returncode:raise RuntimeError(r.stderr+r.stdout)
 return json.loads(r.stdout)
compact={}
for size in [10,100,1000]:
 seed=php('benchmark-acervo.php',str(size));assert seed['publicados']==size
 current['acervos'][str(size)]={op:php('benchmark-operacao.php',op) for op in ['classificacao','configuracao','tecnica','medicao','acessos','purgas_lote20']}
 compact[str(size)]=php('benchmark.php')
 print(json.dumps({'acervo':size,'medido':True}),flush=True)
after,_=integrity();assert after==[('ok',)];current['integridade_depois']=after;report['versoes']['110']=current
checks=[]
for size,operations in current['acervos'].items():
 previous=report['versoes']['192']['acervos'][size]
 for op,r in operations.items():
  samples=r['amostras'];checks.append({'acervo':int(size),'operacao':op,'regra':'sem_avisos','ok':not r['avisos']})
  checks.append({'acervo':int(size),'operacao':op,'regra':'purgas','ok':all(s['purgas']<=(1 if op=='purgas_lote20' else 0) for s in samples)})
  if op in ['configuracao','tecnica','medicao','acessos']:
   checks.append({'acervo':int(size),'operacao':op,'regra':'teto_absoluto','ok':all(s['queries']<=500 and s['memory_peak_delta']<=33554432 and s['ms']<=2000 for s in samples)})
   median=statistics.median(s['queries'] for s in samples);old=statistics.median(s['queries'] for s in previous[op]['amostras'])
   checks.append({'acervo':int(size),'operacao':op,'regra':'alerta_relativo_consultas','ok':median<=old*1.25+20,'observado':median,'baseline':old})
  if op=='classificacao':checks.append({'acervo':int(size),'operacao':op,'regra':'paridade_funcional','ok':samples[0]['resultado']==previous[op]['amostras'][0]['resultado']})
cold=[x['classificacao']['amostras'][0]['queries'] for x in current['acervos'].values()]
checks.append({'operacao':'classificacao','regra':'crescimento_consultas','ok':max(cold)-min(cold)<=10})
report['checks']=checks;report['estado']='OK' if all(x['ok'] for x in checks) else 'FALHA'
a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
a.output.with_name('benchmark-compacto-final.json').write_text(json.dumps({'core':'1.10.0','acervos':compact,'integridade_antes':before,'integridade_depois':after,'journal_mode':mode},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'estado':report['estado'],'checks':len(checks),'falhas':[x for x in checks if not x['ok']]},ensure_ascii=False));raise SystemExit(0 if report['estado']=='OK' else 1)
