# Operação e desenvolvimento — Base Site Core Fator3 1.10.0

## Instalação e atualização

O instalador contém o runtime completo. O implantador não precisa estar ativo. Faça backup do banco e do robots físico antes de atualizar; instale o ZIP pelo WordPress. A atualização agenda a migração e a executa também na entrada administrativa. A conclusão exige confirmação da estrutura no banco. Preferências de consentimento e de sessão existentes são preservadas. Os modos granular e por perfil só são ativados por escolha explícita.

O ensaio de recuperação confirmou que o retorno operacional para 1.9.2 não é suportado: o consumidor antigo não interpreta com segurança os estados de envio, suspensão e reconciliação da fila nova. Token vazio, isoladamente, não é uma pausa segura contra a invocação desse consumidor. Não execute consumidores de uma versão antiga sobre a fila convertida. Para recuperação, pause os envios, preserve a fila e prefira correção para frente. Um retorno de código requer validar a compatibilidade com o schema e os estados novos; não apague tabelas ou opções para forçar a ativação.

A ausência de página de política de privacidade não impede o funcionamento. Ela não representa consentimento. O Core mantém sua política configurada e omite o link quando não há página pública válida.

## Configuração e agentes

Use a tela do plugin ou a operação de configuração do Core. A gravação exige uma revisão atual quando realizada por canal condicionado. O formulário guarda valores não secretos recusados para correção, sem ocultar o que permanece aplicado. Os botões **Salvar** atuam somente na seção enviada.

- `persisted`: preferência gravada e conferida.
- `audit.status`: procedência confirmada, pendente ou não necessária.
- `effect.status`: efeito síncrono aplicado, falhou, não necessário ou não tentado.
- `verification.status`: comportamento verificado, pendente ou falhou, com escopo e data.
- `ok`: compatibilidade com consumidores existentes; não equivale à prova de publicação pública.

Após uma gravação confirmada, consulte a verificação antes de repetir a escrita. Uma falha no efeito pertence ao módulo responsável. Não a contorne no tema ou pela API genérica de options. Editar os JSONs do implantador prepara uma execução futura e não muda a configuração efetiva do WordPress.

As consultas `f3base/como-usar` e `f3base/config-core-contrato-v1` aceitam projeção compacta. O contrato é aditivo e mantém a resposta completa padrão. A operação `f3base/config-core-escrever` com `mesclar=true` preserva os campos omitidos, exige revisão e respeita a semântica de mapas/listas/nulos do catálogo. O avaliador de perfil compara um perfil fornecido pelo consumidor; não inventa a política da frota.

Consultas administrativas continuam exigindo `manage_options`. `readonly` descreve ausência de efeitos, não permissão pública. O registro real de abilities é a fonte dos schemas. O histórico estruturado está em `fontes/plugin/dados/mudancas.json`; o diretório de dados é protegido por regra HTTP no pacote.

## Consentimento e medição

O modo legado conserva a política existente. No modo granular, medição e publicidade têm decisões separadas. Cookies inválidos não valem como aceite. Uma decisão antiga não é convertida automaticamente em aceite granular. A revogação local e a confirmação recebida pelo servidor aparecem como estados diferentes.

A CAPI usa uma referência opaca à decisão e à versão da política. Uma revogação confirmada bloqueia trabalhos ainda não enviados; não desfaz uma requisição já iniciada. GTM requer configuração correspondente do contêiner e a declaração de separação verificada: o Core não consegue validar por inspeção local a política interna de um contêiner externo.

**Desde o anterior** continua sendo intervalo entre acionamentos. **Tempo ativo estimado** é opcional e não comprova atenção humana: considera seção predominante, visibilidade da página e atividade recente, com relógio monotônico. Não coleta texto digitado e usa os lotes de medição existentes.

## Acessos e relatórios

**Atualizar** processa explicitamente a fotografia temporária do dia atual. A atualização automática é opcional, com intervalos de 15, 30 ou 60 segundos, pausa em aba oculta e espera progressiva após falha. Abrir uma consulta não coleta histórico.

**Coletar e Armazenar Logs** solicita processamento de arquivos datados fechados. O dia atual não entra no histórico. O cron diário e as continuações usam o mesmo serviço e checkpoints. Cada arquivo contribui separadamente; releitura, rotação e interrupção não devem duplicar a soma.

A cobertura distingue ausência, leitura parcial e fonte indisponível. Tráfego próprio e de hospedagem fica separado dos humanos, sem desaparecer dos totais. A classificação de agente é independente da classificação do caminho.

Comparações usam períodos completos por padrão. A opção Incluir hoje na comparação marca o período como parcial; em Acessos ela usa somente a fotografia disponível do arquivo ativo e não grava histórico. Fotografia ausente, com erro, bytes pendentes ou regra incompatível fica fora da comparação. Base zero não produz percentual infinito. Mudança de calendário, classificação ou cobertura limita a comparação e deve aparecer no resultado. CSVs representam agregados filtrados, informam corte e protegem células contra fórmulas; não são exportação de identificadores pessoais.

## Fila CAPI e privacidade

Os trabalhos guardam destino, TTL e identificação estáveis. Alterar o Pixel não redireciona uma conversão já enfileirada. Trabalhos legados sem destino comprovado ficam pendentes de decisão administrativa. Uma aceitação externa seguida de falha de persistência local aparece como resultado incerto; não é reenviada cegamente.

Eliminação e revogação coordenam a reserva da fila. A limpeza pendente pode continuar após o post de lead ter sido removido. Tombstones impedem ressuscitar trabalhos cancelados; marcadores técnicos seguem retenção limitada. As abilities de reconciliação exigem revisão e declaração explícita da decisão.

## Publicação e convivência com Yoast e WP Super Cache

O Yoast continua responsável pelo seu sitemap e grafo SEO. O Core usa os adaptadores e regras de exclusão existentes, sem duplicar o emissor. Edição de metadados internos que não muda publicação não deve purgar cache; tornar conteúdo privado ou protegido exige invalidação relevante imediata.

As prévias de robots, índice, full e Markdown são leituras. **Verificar publicação** faz uma sonda limitada e guarda evidência. **Reconciliar robots** é uma ação separada que pode gravar o arquivo gerenciado. Ao desligar o gerenciamento, o backup original só é restaurado quando não sobrescreve um arquivo externo.

`llms.txt` é um índice; `llms-full.txt` preserva o propósito de texto integral. Referências sincronizadas são resolvidas com limites e validação de acesso. Conteúdo dinâmico ou conversão incompleta impede apresentar um full truncado como completo. HEAD, 304 sem prova anterior vinculada, redirecionamento e corpo truncado não confirmam conteúdo.

A indicação de plugin concorrente potencial não comprova quem respondeu pela URL. A prova de proteção de cache usa um artefato público existente e uma expectativa explícita; um 404 inventado não comprova proteção. Nginx ou outro servidor que não interprete `.htaccess` exige regra equivalente da hospedagem.

## Saúde e tarefas

O painel técnico, a Saúde do Site e a consulta `f3base/saude-ler` mostram o mesmo estado. A consulta não inicia coleta, envio, purga ou sonda. A agenda usa os eventos existentes, com último resultado, atraso e situação de recuperação.

`f3base/executar-pendentes` aceita somente tarefas conhecidas e elegíveis. Seu limite é de três tarefas e trinta segundos entre inícios de trabalhos; não é interrupção forçada de uma chamada já iniciada. Leases protegem sobreposição e possuem expiração. A recuperação repõe o evento de um trabalho interrompido sem executar o trabalho na requisição comum.

WP-Cron depende de visitas quando a hospedagem não possui executor externo. Para sites com poucas visitas, configure a chamada regular ao cron do WordPress na hospedagem. O Core não instala um agendador no sistema operacional.

Com WP-CLI disponível:

```sh
wp f3base status --format=json
wp f3base acessos coletar --format=json
wp f3base capi processar --format=json
wp f3base pendentes executar --limite=3 --format=json
wp f3base publicacao verificar --caminho=/llms.txt --format=json
```

Os comandos usam os mesmos serviços do painel e das abilities. Saídas distinguem sucesso, falha e pendência; confira o saldo e o escopo no JSON. A instalação comum não depende de WP-CLI.

## Desenvolvimento e evidências

O ambiente de referência é WordPress 6.9, PHP 8.3.6, SQLite Database Integration 3.0.2, Yoast 28.4 e WP Super Cache 3.1.3. O journal SQLite da bancada é DELETE. Clones são criados pela API de backup SQLite, com `integrity_check` antes/depois; cópia crua de banco aberto não é um snapshot aprovado.

As dependências de análise estão fixadas em `composer.lock` e não entram no instalador. PHPStan e PHPCS/WPCS têm baseline derivada da fonte anterior, sem incluir violações novas para fazê-las passar.

```sh
composer install
composer analyse
python3 suite/versao-110/phpcs-gate.py
node suite/build-assets/build.cjs fontes/plugin
bash suite/verificar.sh "$PWD"
python3 suite/empacotar-fontes.py
```

Os testes da implementação estão em `suite/110`, `suite/versao-110` e `suite/medicao-110`; a fila também usa `suite/bancada-wp/capi-110.php`. Evidências finais ficam em `suite/evidencias-110`. Consulte o relatório de entrega para o estado de cada gate; a presença de um script não prova que ele foi executado.

O pacote fonte usa inclusão explícita e exclui `.git`, dependências instaladas, caches de ferramentas, bancos e ZIPs não declarados. Fixtures, referências com consumidor, lockfiles, fontes legíveis e licenças são preservados. O instalador usa staging vazio e pode ser reconstruído do pacote de fontes.
