<?php
/** Ensaio local de troca de código, com fila sintética e consumidores CAPI pausados. */
declare( strict_types = 1 );
$site = getenv( 'F3BASE_SITE' );
$fase = $argv[1] ?? '';
if ( ! $site || ! is_file( $site . '/.f3base-bancada-110' ) ) { throw new RuntimeException( 'Somente bancada descartável identificada.' ); }
require $site . '/wp-load.php';
wp_set_current_user( 1 );
global $wpdb;
$provas = array();
function rb110_exigir( bool $ok, string $nome ): void { global $provas; $provas[ $nome ] = $ok; if ( ! $ok ) { throw new RuntimeException( $nome ); } }
function rb110_linhas(): array {
 global $wpdb;
 $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE record_id LIKE %s ORDER BY record_id', F3Base_Capi_Fila::tabela(), 'rb110-%' ), ARRAY_A );
 $out = array();
 foreach ( $rows as $r ) {
  $raw = $r; ksort( $raw );
  $out[$r['record_id']] = array( 'estado'=>$r['estado'], 'expira'=>(int)$r['expira'], 'destino'=>$r['pixel_id'], 'cancelado'=>(int)$r['cancelado'], 'iniciado'=>(int)$r['iniciado'], 'lead_id'=>(int)$r['lead_id'], 'lead_existe'=>!empty($r['lead_id']) && (bool)get_post((int)$r['lead_id']), 'payload_presente'=>''!==$r['payload'], 'payload_sha256'=>hash('sha256',$r['payload']), 'schema_versao'=>(int)$r['schema_versao'], 'registro_sha256'=>hash('sha256',wp_json_encode($raw)) );
 }
 return $out;
}
function rb110_pausa(): array {
 $out=array('token_vazio'=>''===F3Base_Modulo_Meta_Capi::token(),'wp_cron_desabilitado'=>defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON);
 foreach(array(F3Base_Capi_Fila::EVENTO,F3Base_Modulo_Meta_Capi::HOOK) as $hook){$out[$hook]=array('agendado'=>false!==wp_next_scheduled($hook),'callback'=>false!==has_action($hook));}
 return $out;
}
try {
 if ( 'preparar' === $fase ) {
  rb110_exigir( ! empty( F3Base_Options::gravar( 'f3base_meta_capi_token', '' )['persisted'] ), 'token_pausado_pela_fachada' );
  rb110_exigir( ! empty( F3Base_Options::gravar( 'f3base_meta_pixel_id', '111111' )['persisted'] ), 'destino_sintetico_gravado' );
  rb110_exigir( ! empty( F3Base_Atualizacao::migrar()['ok'] ) && F3Base_Capi_Fila::instalar(), 'schema_110_confirmado' );
  $payload=array('data'=>array(array('event_name'=>'Lead','event_id'=>'rollback-sintetico','user_data'=>array())));
  foreach(array('pendente','reservado','enviando','incerto','cancelado','cancelando','suspenso','ttl_suspenso','lead_removido') as $nome){
   $pixel=in_array($nome,array('suspenso','ttl_suspenso'),true)?'':'111111';
   rb110_exigir(F3Base_Capi_Fila::inserir('rb110-'.$nome,$payload,3600,$pixel,array()),'fixture_'.$nome);
  }
  rb110_exigir(null!==F3Base_Capi_Fila::reservar('rb110-reservado'),'reserva_criada');
  foreach(array('enviando','cancelando') as $nome){ $wpdb->update(F3Base_Capi_Fila::tabela(),array('estado'=>'enviando','iniciado'=>time()-2,'reserva'=>'lease-sintetico','proxima'=>time()-1),array('record_id'=>'rb110-'.$nome)); }
  F3Base_Capi_Fila::cancelar('rb110-cancelando'); F3Base_Capi_Fila::cancelar('rb110-cancelado');
  $wpdb->update(F3Base_Capi_Fila::tabela(),array('estado'=>'incerto','payload'=>'','motivo'=>'conclusao_local_ausente','iniciado'=>time()-2),array('record_id'=>'rb110-incerto'));
  $wpdb->update(F3Base_Capi_Fila::tabela(),array('expira'=>time()-10),array('record_id'=>'rb110-ttl_suspenso'));
  $lead=wp_insert_post(array('post_type'=>F3Base_Modulo_Endpoint_Leads::CPT,'post_status'=>'private','post_title'=>'Rollback sintético'));
  rb110_exigir(is_int($lead)&&$lead>0,'lead_sintetico_criado');
  $cancelamento=F3Base_Capi_Fila::cancelar('rb110-lead_removido',$lead,true);
  rb110_exigir(!empty($cancelamento['persisted'])&&!empty(F3Base_Capi_Fila::limpar_cancelado('rb110-lead_removido')['ok'])&&!get_post($lead),'lead_eliminado_com_marcador');
  foreach(array(F3Base_Capi_Fila::EVENTO,F3Base_Modulo_Meta_Capi::HOOK) as $hook){wp_unschedule_hook($hook);remove_all_actions($hook);}
 }
 $antes=rb110_linhas();
 if ('legado'===$fase || 'recuperar'===$fase) {
  rb110_exigir(''===F3Base_Modulo_Meta_Capi::token(),'preferencia_de_pausa_preservada');
  if('recuperar'===$fase){rb110_exigir(!empty(F3Base_Atualizacao::migrar()['ok'])&&F3Base_Capi_Fila::instalar(),'reinstalacao_adiante_schema_confirmado');}
  $resumo=F3Base_Capi_Fila::resumo();
  // Disparo de um trabalho atrasado precisa permanecer sem consumidor durante manutenção.
  do_action(F3Base_Modulo_Meta_Capi::HOOK,'rb110-enviando');do_action(F3Base_Capi_Fila::EVENTO);
  rb110_exigir($antes===rb110_linhas(),'fila_inteira_preservada_com_consumidores_pausados');
  foreach(array('cancelado','cancelando','incerto','lead_removido') as $nome){rb110_exigir($antes['rb110-'.$nome]===rb110_linhas()['rb110-'.$nome],'nao_reativa_'.$nome);}
 }
 $extras=array();
 if('sonda_legada'===$fase){
  // Banco separado do percurso de recuperação; chama somente métodos locais sem transporte.
  $reservaveis=array();foreach(array_keys($antes) as $id){$reservaveis[$id]=null!==F3Base_Capi_Fila::reservar($id);}
  rb110_exigir($reservaveis['rb110-pendente']&&$reservaveis['rb110-enviando'],'legado_reserva_pendente_e_envio_ja_iniciado');
  foreach(array('reservado','incerto','cancelado','cancelando','suspenso','lead_removido') as $nome){rb110_exigir(!$reservaveis['rb110-'.$nome],'legado_nao_reserva_'.$nome);}
  F3Base_Capi_Fila::recuperar();
  rb110_exigir('suspenso'===F3Base_Capi_Fila::ler('rb110-ttl_suspenso')['estado']&&''!==F3Base_Capi_Fila::ler('rb110-ttl_suspenso')['payload'],'legado_nao_expira_payload_do_novo_estado_suspenso');
  $payload=array('data'=>array(array('event_name'=>'Lead','event_id'=>'canario-local','user_data'=>array())));
  F3Base_Capi_Fila::inserir('rb110-canario-token-vazio',$payload,3600);
  F3Base_Modulo_Meta_Capi::enviar('rb110-canario-token-vazio');$canario=F3Base_Capi_Fila::ler('rb110-canario-token-vazio');
  rb110_exigir('falhou'===$canario['estado']&&''===$canario['payload'],'token_vazio_sozinho_nao_preserva_payload_se_callback_antigo_for_chamado');
  $extras=array('reservaveis_pelo_codigo_192'=>$reservaveis,'canario'=>array('estado'=>$canario['estado'],'payload_presente'=>''!==$canario['payload']),'novas_operacoes_ausentes'=>array('cancelar'=>!method_exists(F3Base_Capi_Fila::class,'cancelar'),'resolver_destino'=>!method_exists(F3Base_Capi_Fila::class,'resolver_destino'),'reconciliar'=>!method_exists(F3Base_Capi_Fila::class,'reconciliar')));
 }
 rb110_exigir(0===(int)($GLOBALS['rb110_http_tentativas']??0),'nenhuma_tentativa_http');
 $pausa=rb110_pausa();rb110_exigir($pausa['token_vazio']&&$pausa['wp_cron_desabilitado'],'preferencias_de_pausa_confirmadas');
 foreach(array(F3Base_Capi_Fila::EVENTO,F3Base_Modulo_Meta_Capi::HOOK) as $hook){rb110_exigir(!$pausa[$hook]['agendado']&&!$pausa[$hook]['callback'],'agenda_e_callback_pausados_'.$hook);}
 echo wp_json_encode(array('ok'=>true,'fase'=>$fase,'versao'=>F3BASE_PLUGIN_VERSAO,'http_tentativas'=>0,'pausa'=>$pausa,'linhas'=>rb110_linhas(),'provas'=>$provas,'diagnostico'=>$extras),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
} catch(Throwable $e){echo wp_json_encode(array('ok'=>false,'fase'=>$fase,'provas'=>$provas,'erro'=>$e->getMessage()),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit(1);}
