<?php
/** Constantes de análise: assinaturas do ambiente, sem carregar WordPress ou executar o plugin. */
define('ABSPATH', '/wordpress/');
define('WP_PLUGIN_DIR', '/wordpress/wp-content/plugins');
define('WP_CONTENT_DIR', '/wordpress/wp-content');
define('F3BASE_PLUGIN_DIR', '/wordpress/wp-content/plugins/base-site-core-fator3/');
define('F3BASE_PLUGIN_URL', 'https://example.invalid/wp-content/plugins/base-site-core-fator3/');
define('ARRAY_A', 'ARRAY_A');
define('ARRAY_N', 'ARRAY_N');
define('OBJECT', 'OBJECT');
define('MINUTE_IN_SECONDS', 60);
define('HOUR_IN_SECONDS', 3600);
define('DAY_IN_SECONDS', 86400);
define('WEEK_IN_SECONDS', 604800);
define('MONTH_IN_SECONDS', 2592000);
define('YEAR_IN_SECONDS', 31536000);
