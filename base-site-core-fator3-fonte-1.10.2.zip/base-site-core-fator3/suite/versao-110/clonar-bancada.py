#!/usr/bin/env python3
"""Clona uma bancada local somente após validar e copiar SQLite pela API backup."""
from pathlib import Path
import argparse
import json
import shutil
import sqlite3

p=argparse.ArgumentParser()
p.add_argument('origem',type=Path)
p.add_argument('destino',type=Path)
a=p.parse_args()
source=a.origem.resolve()
target=a.destino.resolve()
if target.exists():
    raise SystemExit('Destino deve ser novo; nenhuma bancada existente foi sobrescrita.')
if not (source/'.f3base-bancada-110').is_file():
    raise SystemExit('Origem não tem marcador de bancada descartável.')
source_db=source/'wp-content/database/.ht.sqlite'
with sqlite3.connect(f'file:{source_db}?mode=ro',uri=True) as con:
    before=[r[0] for r in con.execute('PRAGMA integrity_check')]
    if before!=['ok']:
        raise SystemExit('BLOCKED: origem sem integridade: '+json.dumps(before,ensure_ascii=False))
    shutil.copytree(source,target,ignore=lambda directory,names:[n for n in names if n.startswith('.ht.sqlite')])
    target_db=target/'wp-content/database/.ht.sqlite'
    with sqlite3.connect(target_db) as dest:
        con.backup(dest)
        dest.execute('PRAGMA journal_mode=DELETE')
        after=[r[0] for r in dest.execute('PRAGMA integrity_check')]
        if after!=['ok']:
            raise SystemExit('BLOCKED: backup sem integridade')
for name in ('wp-config.php','wp-content/wp-cache-config.php'):
    path=target/name
    if path.exists():
        path.write_text(path.read_text().replace(str(source),str(target)))
print(json.dumps({'origem':str(source),'destino':str(target),'integrity_check':after,'journal_mode':'DELETE'},ensure_ascii=False))
