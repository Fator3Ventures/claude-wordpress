#!/usr/bin/env python3
"""Rejeita violações novas por regra/mensagem/linha de código; baseline só da 1.9.2."""
from pathlib import Path
import argparse
import bisect
from collections import Counter
import hashlib
import json
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
BASELINE=Path(__file__).with_name('phpcs-baseline.json')

TOKEN=re.compile(r"(?:'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"|//[^\n]*|/\*[\s\S]*?\*/|\$[A-Za-z_][A-Za-z_0-9]*|[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[^\s])")

def fingerprint(message,source,lines,tokens,starts):
    number=message['line']
    prefix=sum(len(x)+1 for x in lines[:number-1])
    column=max(0,message.get('column',1)-1)
    point=prefix+column
    i=bisect.bisect_right(starts,point)-1
    i=max(0,i)
    # Tokens vizinhos identificam o comando, sem tornar uma quebra de linha uma dívida nova.
    semantic='\0'.join(tokens[max(0,i-8):i+9])
    return hashlib.sha256((message['source']+'\0'+message['message']+'\0'+semantic).encode()).hexdigest()

def normalize(report,base):
    entries={}
    detail=[]
    for raw,info in report['files'].items():
        path=Path(raw)
        if not path.is_absolute():
            rooted=Path('/')/path
            path=rooted if rooted.is_file() and rooted.is_relative_to(base) else base/path
        relative=path.relative_to(base).as_posix()
        source=path.read_text()
        lines=source.splitlines()
        found=[m for m in TOKEN.finditer(source) if not m.group().startswith(('//','/*'))]
        tokens=[m.group() for m in found]
        starts=[m.start() for m in found]
        counts=Counter()
        for message in info['messages']:
            number=message['line']
            line=lines[number-1] if 0<number<=len(lines) else ''
            key=fingerprint(message,source,lines,tokens,starts)
            counts[key]+=1
            detail.append({'arquivo':relative,'linha':number,'regra':message['source'],'mensagem':message['message'],'chave':key})
        entries[relative]=dict(counts)
    return entries,detail

p=argparse.ArgumentParser()
p.add_argument('--php',default='php')
p.add_argument('--baseline-report',type=Path)
p.add_argument('--baseline-root',type=Path)
p.add_argument('--report',type=Path)
a=p.parse_args()
if a.baseline_report:
    if not a.baseline_root:raise SystemExit('--baseline-root obrigatório')
    report=json.loads(a.baseline_report.read_text())
    entries,_=normalize(report,a.baseline_root.resolve())
    BASELINE.write_text(json.dumps({'origem':'fonte 1.9.2 intocada','ferramentas':{'phpcs':'3.13.6','wpcs':'3.4.1'},'totais':report['totals'],'arquivos':entries},ensure_ascii=False,separators=(',',':'))+'\n')
    print(json.dumps({'baseline':str(BASELINE),'totais':report['totals']}))
    raise SystemExit(0)
proc=subprocess.run([a.php,str(ROOT/'vendor/bin/phpcs'),'--standard='+str(Path(__file__).with_name('phpcs.xml')),'--report=json',str(ROOT/'fontes/plugin')],capture_output=True,text=True,cwd=ROOT)
try:report=json.loads(proc.stdout)
except ValueError:raise SystemExit('BLOCKED: PHPCS não produziu JSON: '+proc.stderr+proc.stdout[:500])
old=json.loads(BASELINE.read_text())['arquivos']
new,detail=normalize(report,ROOT)
allowed={name:Counter(values) for name,values in old.items()}
added=[]
for item in detail:
    count=allowed.setdefault(item['arquivo'],Counter())
    if count[item['chave']]>0:count[item['chave']]-=1
    else:added.append({k:v for k,v in item.items() if k!='chave'})
result={'estado':'FALHA' if added else 'OK','total_atual':report['totals'],'novas_violacoes':len(added),'achados':added}
if a.report:a.report.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='achados'},ensure_ascii=False))
sys.exit(1 if added else 0)
