<?php
/** Guarda de propriedade exercitada pelo Options real do WP MCP Fator3, sem substituir a habilidade. */
declare(strict_types=1);
$site=(string)getenv('F3BASE_SITE');
if(!$site||!is_file($site.'/wp-load.php')){fwrite(STDERR,"BLOCKED: F3BASE_SITE ausente\n");exit(2);}
require $site.'/wp-load.php';wp_set_current_user(1);
$warnings=[];set_error_handler(static function($n,$s,$f,$l)use(&$warnings){if(error_reporting()&$n)$warnings[]=[$n,$s,basename($f),$l];return false;});
$ability=wp_get_ability('options/update');
if(!$ability){echo json_encode(['estado'=>'BLOCKED','mensagem'=>'WP MCP options/update não registrada']);exit(2);}
$before=F3Base_Options::fotografia('f3base_consentimento');
$r=$ability->execute(['name'=>'f3base_consentimento','value'=>['preaprovado'=>false]]);
$after=F3Base_Options::fotografia('f3base_consentimento');
$case1=!is_wp_error($r)&&empty($r['success'])&&$before['revisao']===$after['revisao'];
$allowed=wp_get_ability('f3base/config-core-escrever')->execute(['nome'=>'f3base_consentimento','valor'=>$before['valor'],'revisao_esperada'=>$before['revisao'],'simular'=>false]);
$case2=!is_wp_error($allowed)&&!empty($allowed['persisted']);
$all=apply_filters('wp_mcp_ultimate_protected_options',['protected-by-other-owner'],'f3base_consentimento');
$case3=in_array('protected-by-other-owner',$all,true)&&!array_diff(F3Base_Options::proprias(),$all);
restore_error_handler();
$plugin=get_file_data(WP_PLUGIN_DIR.'/wp-mcp-fator3/wp-mcp-fator3.php',['Version'=>'Version']);
echo wp_json_encode(['estado'=>($case1&&$case2&&$case3&&!$warnings)?'OK':'FALHA','conector'=>$plugin['Version'],'canal_generico_recusa_sem_gravar'=>$case1,'api_core_persiste'=>$case2,'catalogo_completo_e_outros_donos_preservados'=>$case3,'avisos'=>$warnings],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
exit($case1&&$case2&&$case3&&!$warnings?0:1);
