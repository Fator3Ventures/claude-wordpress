# Plano de implementação — Base Site Core Fator3 1.10.0

Data: 21/09/2026. **Revisão 2:** incorporação crítica dos relatórios adicionais sobre 1.9.0 e 1.9.1. Base do código conferido: **1.9.2**, além da análise `analise-base-site-core-1.9.2.md`.

**Objetivo:** implementar os 11 ajustes identificados, as sete evoluções funcionais, as melhorias de manutenção e os complementos N01–N10 desta revisão, preservando a operação independente do Core e sua convivência com Yoast e WP Super Cache. A avaliação das 23 sugestões adicionais está na seção 14; os requisitos novos, na seção 15.

**Versão-alvo proposta: 1.10.0.** As etapas abaixo são marcos internos dessa entrega. Este documento é o plano; não registra funcionalidades implementadas nem uma implantação realizada.

## 1. Escopo e decisões

| Tema | Decisão |
|---|---|
| Ambiente | Usar o perfil padronizado da operação e registrar suas versões no manifesto da homologação |
| Multisite | Fora do escopo; conservar a restrição já declarada pelo Core |
| Banco de dados | Usar o banco/driver do ambiente padronizado; excluir ampliação de suporte e matriz de testes MySQL/MariaDB |
| Compatibilidade | Preservar as APIs públicas, options, nomes de eventos existentes e contratos usados pelo implantador |
| Configuração | Toda preferência aplicada ao site passa pela operação do Core; JSON do implantador continua distinto da configuração persistida |
| Concorrência | Manter testes de gravações simultâneas, reservas, bloqueios e falhas no banco do ambiente padronizado |
| Refatoração | Extrair componentes conforme as correções avançarem, mantendo as fachadas públicas |
| Consultas | Ler estado, validade e evidências existentes; ações e sondagens têm execução explícita separada |
| Privacidade | Política de privacidade continua opcional; eliminação, consentimento e demais funções continuam operacionais |
| Medição | Preservar os limites atuais do orçamento; recursos adicionais terão custo limitado e documentado |
| Implantação | Homologar no site de teste antes de distribuir para os demais sites |
| Relatórios adicionais | Usar seus achados como hipóteses confrontadas com os fontes 1.9.2; esta revisão não refez os testes remotos nem confirmou o estado atual da frota |
| Políticas da operação | Perfil esperado da frota e journal de implantação pertencem ao implantador; o Core fornece seu contrato, estado observado e operações próprias |
| Novas políticas opcionais | Consentimento por categoria e sessão por perfil exigem configuração explícita; atualização do pacote não substitui silenciosamente escolhas existentes |

A homologação anterior registra WordPress 6.9, PHP 8.3.6, WP Super Cache 3.1.3, Yoast 28.4 e SQLite Database Integration 3.0.2, com journal DELETE. Esses dados são a referência inicial. A etapa de preparação deve conferir o perfil efetivamente adotado; o plano não presume que a evidência antiga descreve todas as instalações atuais. Não será criada uma matriz de ambientes alternativos.

## 2. Ordem de execução

| Etapa | Entrega | Depende de | Condição de conclusão |
|---|---|---|---|
| E0 | Base reproduzível e testes dirigidos dos achados | — | Perfil registrado e regressões demonstradas no ambiente de teste |
| E1 | Persistência, auditoria, formulário e políticas | E0 | C03/C05/C06 e base de N01–N05; escrita parcial validada, políticas opcionais e tracking ordenado |
| E2 | Eliminação e fila CAPI | E1 | Cancelamento, destino, confirmação local e recuperação coerentes |
| E3 | Cache, coleta de logs e execução de tarefas | E1 | Invalidação relevante, coleta assíncrona e serviços comuns de N08/N09 |
| E4 | Calendário e consultas da medição | E3 | Agregados corretos, cobertura por dia e classificação de tráfego de N06 |
| E5 | Novas telas, indicadores, consultas e comandos | Serviços correspondentes de E2–E4 | F01–F07 e interfaces N01/N07–N10 consumindo as mesmas regras e contratos |
| E6 | Homologação, migração e distribuição | E1–E5 | Instalação/atualização aprovadas e pacotes finais reproduzíveis |

E2 e E3 admitem desenvolvimento em paralelo depois da base de E1. A conversão editorial de llms também admite uma frente própria. Comparação/exportação depende de E4; atualização automática de hoje depende da separação de coleta em E3 e da semântica temporal de E4.

Dentro de E1, concluir C05/C06 antes de N02. N03 define a política usada pelos destinos de N04; a implantação dos dois exige testes conjuntos. N08 corrige primeiro o diagnóstico do responsável por llms e o significado da sonda HTTP; a interface de inspeção vem depois. N10 usa um perfil fornecido pelo consumidor: a criação do perfil da frota não bloqueia a entrega do avaliador genérico.

## 3. E0 — Preparação e critérios de referência

1. Partir dos fontes 1.9.2, conferindo o manifesto e os hashes do instalador e dos assets.
2. Preparar uma bancada com o perfil padronizado e Yoast/WP Super Cache ativos. Registrar versões, driver, modo de cache e executor das tarefas.
3. Reexecutar a suíte existente para estabelecer a referência. A revisão anterior reproduziu somente a falha do cookie; os demais achados possuem evidência estática e precisam de reprodução dirigida.
4. Acrescentar casos de falha do banco, sobreposição de processos, fila pendente durante eliminação, edição simultânea e coleta atrasada.
5. Registrar custo das consultas do contrato e das telas: número de consultas SQL, tempo, memória e quantidade de purgas. Usar acervos fixos pequeno, representativo da operação e de estresse no mesmo ambiente.
6. Definir os limites de desempenho a partir dessas medidas e registrá-los antes das otimizações. Nenhuma meta de latência será apresentada como resultado já obtido.
7. Registrar tamanhos das respostas das abilities e reproduzir a ordem da fila Google/GTM, o falso `core_serve` com llms desligado e a classificação de sondagens como humanos. Conferir a API real de proteção de options do conector instalado antes de implementar seu adaptador.

**Entrega:** manifesto do ambiente, casos reproduzíveis e medições de referência. Estes arquivos passam a compor as evidências da nova versão.

## 4. E1 — Persistência, auditoria e controles da interface

### C06 — Procedência e registros concorrentes

- Criar uma operação interna de atualização condicional de estado com repetição limitada, aproveitando a revisão já existente no Core.
- Aplicá-la ao mapa de procedência, às tentativas recusadas e ao journal de eliminação. Manter os limites de retenção desses registros.
- Associar a origem à revisão confirmada da preferência. Se a auditoria falhar, manter a distinção entre configuração persistida e registro de auditoria pendente.
- Quando houver duas alterações da mesma option, a origem exibida deve corresponder ao valor/revisão atual. Em caso de divergência, declarar a procedência como não confirmada.
- Não registrar valores de segredos nem payloads pessoais nos eventos de auditoria.
- Distinguir origem registrada de inferência legada. O fallback atual `implantador` para option existente sem registro não comprova quem gravou. Expor essa incerteza sem reescrever a história; origem atual não prova que um valor nunca existiu ou foi apagado. N01 acrescenta essa distinção às consultas.

**Aceite:** alterações simultâneas em opções diferentes preservam ambas as origens; recusas e eliminações simultâneas preservam os registros; falha do journal não é convertida em confirmação fictícia.

### C05 — Formulário com revisão esperada

- Renderizar a revisão da option junto de cada grupo de configuração e enviá-la a `F3Base_Options::gravar()` no salvamento.
- Para uma seção com várias options, devolver resultado por option. Uma gravação parcial deve identificar exatamente o que foi salvo e o que entrou em conflito; não prometer atomicidade da seção inteira.
- Em conflito, preservar os valores não secretos digitados, indicar o valor atual e permitir nova edição. Segredos continuam mascarados e não voltam ao HTML.
- Manter o botão **Salvar** por seção e uma confirmação curta. Explicações detalhadas aparecem somente quando houver conflito, normalização ou falha.

**Aceite:** duas abas administrativas e uma alteração por agente entre abertura/envio do formulário não causam sobrescrita silenciosa.

### C03 — Cookie de consentimento inválido

- Proteger a decodificação e auditar os demais leitores de cookie do plugin.
- Tratar valor malformado como ausência de decisão, seguindo a política configurada. Esta correção não altera o padrão adotado pela operação; o novo modo por categorias de N03 é uma opção com migração explícita.
- Garantir que o controle continue disponível e que aceitar/recusar volte a persistir uma decisão válida.
- Regenerar os assets pelo build existente.

**Aceite:** cookie ausente, `granted`, `denied`, escape inválido e UTF-8 incompleto funcionam no fonte e no bundle. Testar também o controle no navegador, inclusive sem página de política de privacidade.

## 5. E2 — Eliminação e confiabilidade da CAPI

C01, C02, C08 e C11 serão implementados sob um único desenho de fila, com migração versionada e estados documentados.

### C01 — Cancelamento e eliminação coordenados

- Centralizar a operação por `record_id`, abrangendo o lead, a fila, os eventos agendados e os transientes legados.
- Persistir o cancelamento e coordená-lo atomicamente com o início do envio. Cancelar somente o cron não impede um processo que já obteve a reserva.
- Eliminar o payload e manter apenas o marcador técnico mínimo necessário para impedir reenvio, com prazo de retenção explícito.
- Se a requisição externa já começou, registrar essa condição e acompanhar seu resultado. A resposta não promete desfazer uma entrega externa.
- Informar remoção por armazenamento e exclusão parcial, inclusive nas interfaces nativas de privacidade.
- Registrar pendências suficientes para retomar a limpeza mesmo se o post do lead já tiver sido removido. Não deixar a recuperação dependente de metadados que a própria operação apagou.
- Reutilizar a coordenação de cancelamento para a revogação de consentimento de N03: a fila consulta a decisão confirmada no servidor antes de iniciar o envio, sem prometer desfazer requisição já iniciada.

**Aceite:** enfileirar → apagar → executar tarefa não envia o evento; um apagamento parcialmente recusado informa dados retidos; cancelamento concorrente ao envio apresenta resultado coerente; transientes antigos não recriam payload eliminado.

### C02 — Entrega externa e persistência local

- Fazer a conclusão da fila retornar resultado estruturado: estado da entrega, confirmação local, falha/conflito e próxima tentativa.
- Manter `event_id` estável. Uma aceitação externa seguida de falha local exige reconciliação explícita, sem garantir entrega “exatamente uma vez”.
- Detectar reserva vencida/substituída e impedir que o processo antigo conclua o trabalho de outro processo.
- Documentar a semântica de `ok` por operação e preservar o comportamento de compatibilidade já exposto aos consumidores. Novos campos expressam as distinções necessárias.

**Aceite:** falha de banco após resposta aceita da Meta não aparece como conclusão local; perda da reserva é detectada; HTTP incerto e falha permanente têm resultados distintos.

### C08 — Destino estável

- Registrar o Pixel no enfileiramento, sem copiar o token para cada evento.
- Permitir rotação do token para o mesmo Pixel. Troca de Pixel suspende os eventos incompatíveis e produz diagnóstico.
- Eventos legados sem destino verificável entram como **destino não identificado**. Não atribuir automaticamente o Pixel atual. Permitir resolução explícita enquanto o TTL original ainda estiver válido; após o prazo, expirar e limpar o payload.

**Aceite:** um evento criado para A não segue automaticamente para B; token novo do mesmo destino continua operacional; a migração não inventa a origem de eventos antigos.

### C11 — Recuperação e limites

- Programar o próximo trabalho com base na pendência mais próxima e continuar lotes limitados enquanto houver saldo.
- Manter expiração e limite de tentativas; considerar `Retry-After` em falhas transitórias dentro do prazo permitido e distribuir as novas tentativas para evitar rajadas.
- Proteger o teto da fila contra inserções simultâneas, substituindo a decisão isolada `COUNT` → `INSERT` por uma operação coordenada no banco do ambiente.
- Registrar recusa de agendamento, atraso do executor, expiração e falha de confirmação. Separar evento agendado de tarefa efetivamente executada.

**Aceite:** mais de 20 eventos progridem por continuação de lotes; recusa inicial de agendamento é recuperada antes do TTL quando o executor está operacional; atraso que excede o TTL registra a perda e remove o payload.

### Migração da fila

A rotina atual de instalação retorna quando a tabela já existe. Acrescentar colunas exige um migrador com versão, verificação e retomada; alterar apenas o `CREATE TABLE` é insuficiente. Liberar o novo consumidor somente após confirmar o schema. Preservar TTL e identificadores dos registros existentes.

## 6. E3 — Cache e processamento de logs

### C04 — Invalidação relevante

- Receber a chave e os valores pertinentes dos metadados; ignorar bloqueios de edição e outros metadados internos conhecidos.
- Comparar os campos efetivamente alterados nas opções do Yoast, centralizando as chaves relevantes no adaptador existente.
- Preservar a invalidação de conteúdo, senha, estado de publicação, `noindex`, canonical e campos públicos do tema. Metadados desconhecidos mantêm tratamento conservador, com extensão documentada.
- Reutilizar o agrupamento já existente dentro da requisição. Só adotar agrupamento entre requisições para alterações elegíveis, com prazo máximo documentado; mudanças de acesso público não esperam esse prazo.
- Preservar geração, última tentativa, último sucesso e separação entre limpeza e prova HTTP.

**Aceite:** renovar `_edit_lock` não purga; alterar conteúdo público invalida; tornar conteúdo privado impede exposição pelo cache; uma sonda antiga não confirma uma geração nova.

### C07 — Coleta fora da requisição comum

- O `init` apenas identifica necessidade e garante uma tarefa única. Não lê arquivos de log nem importa dias.
- Unificar execução manual, cron e WP-CLI no mesmo serviço de coleta, com reserva, checkpoint, orçamento por lote e continuação.
- O botão **Coletar e Armazenar Logs** solicita a coleta e informa progresso, última conclusão e falha. Permanecem elegíveis somente logs datados fechados; o dia atual permanece fora do histórico.
- Migrar/verificar estrutura por versão, evitando inspeções completas em cada visita.
- Manter descoberta genérica do diretório, normalização de `www` e diagnóstico de permissões/HOME já existentes.

**Aceite:** uma visita com coleta atrasada não processa logs; solicitações sobrepostas compartilham o mesmo trabalho; interrupção retoma sem duplicar; desligar a coleta retira suas tarefas; atualização sem reativação agenda corretamente.

## 7. E4 — Calendário e desempenho da medição

### C09 — Calendário coerente e histórico rastreável

**Modelo escolhido:** usar o fuso configurado no WordPress para as janelas exibidas ao operador. Timestamps de eventos preservam sua referência UTC; cada geração de agregados registra fuso, versão da regra e cobertura.

- Separar data de rotação do arquivo, instante do evento e dia usado no relatório.
- Em novos agregados, aplicar a mesma regra temporal a acessos e comportamento. Tratar a leitura de hoje como parcial.
- Guardar contribuições por arquivo/fingerprint e versão de processamento, ou usar estágio equivalente que permita reconstruir o total a partir de todas as contribuições. Dois arquivos que contribuem para o mesmo dia não podem sobrescrever um ao outro.
- Quando um arquivo fechado contiver eventos de um dia ainda aberto, adiar essas contribuições. O checkpoint deve permitir revisitá-las depois, mesmo que tamanho e assinatura do arquivo não mudem. Se o host apagar o arquivo antes da revisita, registrar perda de cobertura; o checkpoint não permite reconstruir dados ausentes. Manter o compromisso de não armazenar eventos de hoje no histórico.
- Para hoje, declarar quais arquivos cobrem a janela. Se a rotação já retirou parte dos eventos do arquivo ativo e não houver leitura temporária dos segmentos necessários, manter o indicador de cobertura parcial.
- Reprocessar histórico somente com fonte completa disponível. Preservar os demais períodos como **legado com calendário anterior**; não redistribuir contagens por estimativa.
- Mudança posterior do fuso cria nova versão da regra. Reprocessar fontes disponíveis por tarefa; manter identificado o histórico sem reconstrução possível.
- Para comparar janelas consecutivas, parear o primeiro dia de cada janela, depois o segundo e assim por diante. Calcular a variação somente nos pares com cobertura válida em ambos os lados, informar quantos dias foram comparados e quais ficaram de fora. A correspondência é pela posição na janela, não pela coincidência de datas. Zero observado, ausência de cobertura e período parcial têm representações diferentes.
- Informar primeiro/último dia coberto e cobertura por dia, com motivo e data da inspeção. Ausência de agregado não prova ausência de arquivo. N06 especifica os estados e sua exposição na tela e na ability.

**Aceite:** meia-noite, diferenças entre fuso do servidor/site, mudança de fuso, horário sazonal quando presente, dois arquivos no mesmo dia e reprocessamento repetido mantêm contagens corretas e idempotentes.

### C10 — Classificação e consultas

- Evitar carregar todo o acervo para classificar um recorte pequeno. Resolver os caminhos observados em lotes e manter cache/índice de classificação invalidado por publicação e mudança de permalink.
- Caso a medição E0 indique necessidade de índice persistido, criá-lo com reconstrução por cursor e geração publicada apenas após conclusão.
- Remover cláusulas `IN` extensas baseadas no catálogo completo. Usar consultas paginadas e os índices necessários ao perfil medido.
- Preservar as classificações existentes, o padrão de páginas/artigos e os arquivos de descoberta relevantes. A classificação “inexistente” não deve ser inferida apenas da ausência de um post.
- Otimizar também a consulta do contrato e das telas com fotografias compartilhadas dentro da leitura; escritas e reservas continuam usando estado atual.
- Tratar classificação de caminho e de agente como dimensões separadas. N06 acrescenta tráfego próprio/hospedagem sem alterar o filtro de páginas/artigos nem descartar esses acessos do total geral.

**Aceite:** mesmo resultado funcional nos acervos de referência; memória e consultas proporcionais ao trabalho requerido; comparação antes/depois documentada, com regressões justificadas ou corrigidas.

## 8. E5 — Funcionalidades e UX

Todos os valores iniciais abaixo são decisões propostas para a nova versão, sujeitos aos limites medidos em E0. Devem existir em uma declaração única, usada pelo código e pelo contrato.

### F01 — Painel unificado de saúde

- Evoluir a aba **Estado técnico** e integrar os mesmos dados à Saúde do Site.
- Mostrar coleta, fila CAPI, consentimento, publicação de arquivos e cache com último resultado, data, validade e pendência.
- Distinguir **configuração salva**, **efeito aplicado** e **verificação pendente** em linguagem operacional.
- Usar links para ações específicas. Abrir ou atualizar o diagnóstico não executa correções, envios, purgas ou sondagens.
- Reutilizar o estado das tarefas existentes; não criar monitor duplicado por módulo.
- Consolidar próxima execução, atraso e último resultado por tarefa, conforme N09. A agenda do cache já existe e será reutilizada.

**Aceite:** painel, contrato e Saúde do Site concordam; consultas não alteram estado, leases ou agenda nem iniciam HTTP externo.

### F02 — Acompanhamento automático de hoje

- Adicionar checkbox **Atualizar automaticamente**, inicialmente desligado, com intervalo inicial de 30 segundos e opções de 15, 30 e 60 segundos.
- Guardar a preferência de visualização por administrador. Manter filtros e posição da tabela durante a atualização.
- Usar uma operação explícita e autenticada para a leitura incremental, com nonce, orçamento e reserva. Ela pode atualizar o estado temporário da leitura; não importa histórico nem dispara a fila geral.
- Pausar com aba oculta, impedir solicitações sobrepostas e aumentar o intervalo após falha. Mostrar atualização, pausa, atraso e cobertura parcial.

**Aceite:** ativar/desativar é imediato; duas telas não duplicam o processamento; ausência de novos bytes não reprocessa o arquivo inteiro; nenhuma leitura de hoje vira histórico.

### F03 — Comparação de períodos e exportação

- Comparar o período selecionado com a janela anterior de mesma duração, por página e evento, mantendo os filtros.
- Excluir hoje da comparação padrão de dias completos; a inclusão explícita indica período parcial.
- Exibir volume, diferença absoluta, variação percentual quando o denominador permitir e cobertura. Base zero usa indicação própria, sem percentual infinito.
- Exportar agregados em CSV com intervalo, fuso, filtros, versão da regra, cobertura e data da extração. A exportação deve corresponder ao conjunto filtrado, com limite/paginação e indicação de qualquer corte.
- Proteger células contra fórmulas e aplicar permissão administrativa. Não incluir identificadores de visitantes, leads ou segredos na exportação agregada.

**Aceite:** valores da tela e do CSV conciliam; faltas de cobertura não viram zero; períodos legados incompatíveis não apresentam variação enganosa.

### F04 — Tempo ativo estimado por bloco

- Adicionar métrica opcional, inicialmente desligada, chamada **Tempo ativo estimado**. Preservar a coluna **Desde o anterior**.
- Reutilizar a identificação de seções e medir com relógio monotônico, considerando página visível, bloco elegível e atividade recente. Proposta inicial: interromper a soma após 30 segundos sem interação.
- Usar uma seção predominante por instante, definida pela área visível; desempatar por ordem no documento. Isso evita atribuir o mesmo intervalo integral a vários blocos.
- Pausar ao ocultar a página, sair da seção ou atingir o limite de inatividade; retomar somente quando as condições forem atendidas.
- Acrescentar o evento e os parâmetros ao vocabulário único. Acumular localmente e enviar nos lotes já existentes, sem beacon periódico próprio. Respeitar consentimento, descarte, retenção e orçamento da visita.
- Validar duração e limites no servidor. Sem dados, apresentar ausência de medição, não duração zero.

**Aceite:** alternar abas, ficar inativo, atravessar blocos e receber callbacks atrasados não inflaciona o tempo; a soma não supera o intervalo ativo observado; não são coletados textos digitados nem novos identificadores pessoais.

### F05 — Inspeção dos arquivos públicos

- Acrescentar diagnóstico para robots, llms, full e Markdown: responsável efetivo, conflito com arquivo físico, configuração e última resposta observada.
- Oferecer ação **Verificar publicação** e prévia/diferença editorial. Consultas apresentam a evidência já armazenada.
- Reutilizar controle de geração, validade, timeout e limites de sondagem existentes. Validar destinos antes da requisição e não permitir inspeção arbitrária de hosts ou caminhos privados.
- Exibir por que um conteúdo entrou ou saiu da seleção: curadoria, tipo, exclusão, senha, visibilidade e `noindex`.
- Respeitar a escolha de responsável e o mecanismo de backup/restauração de robots. A inspeção observa e registra evidência; não remove nem republica arquivos e não altera Yoast. Reconciliação que escreve o robots permanece na rotina própria ou em ação explícita identificada como tal.
- Incorporar N08: corrigir a declaração de emissor llms, explicar a sincronização já existente do robots gerenciado e oferecer sondas limitadas com evidência suficiente. A publicação observada e a configuração declarada permanecem campos distintos.

**Aceite:** conflito físico/virtual é explicado; `HEAD`, `ETag`, `304`, tipo de conteúdo e resposta observada têm evidência; alterações de geração tornam resultados anteriores históricos.

### F06 — Conversão editorial para llms

- Acrescentar suporte conservador a blocos reutilizáveis/sincronizados permitidos, tabelas e listas complexas.
- Resolver referências com controle de ciclos, profundidade e volume. Revalidar acesso do conteúdo referenciado.
- Identificar blocos dinâmicos ou formatos que não foram convertidos. Não executar shortcodes, consultas dinâmicas ou efeitos do tema durante a conversão.
- Usar o mesmo conversor no `llms-full.txt` e nas alternativas Markdown.
- Preservar o texto integral da seleção no full. Caso um limite impeça a geração completa, informar falha/incompletude explicitamente; nunca publicar conteúdo truncado como completo.
- Manter a descoberta Markdown e os cabeçalhos HTTP já existentes.

**Aceite:** fixtures com tabelas, listas, referência circular, conteúdo protegido e bloco desconhecido têm saída previsível; nenhum conteúdo privado aparece; conversão não provoca mutações.

### F07 — Operação por WP-CLI

Comandos propostos:

| Comando | Comportamento |
|---|---|
| `wp f3base status --format=json` | Consulta saúde e evidências existentes |
| `wp f3base acessos coletar` | Executa um lote de logs fechados e informa saldo |
| `wp f3base capi processar` | Processa um lote elegível sob a mesma reserva e limites |
| `wp f3base publicacao verificar` | Executa a inspeção pública limitada e registra resultado |

Todos chamam os mesmos serviços da interface e das habilidades. Documentar códigos de saída para sucesso, pendência/conflito e falha. O registro dos comandos deve ser condicionado à disponibilidade do WP-CLI, sem criar dependência para o plugin funcionar.

**Aceite:** cron, CLI e ação administrativa sobrepostos não duplicam tarefas; saída JSON é íntegra; nenhum comando exige o implantador ativo. Provisionar o executor externo permanece com a hospedagem/implantador.

## 9. Melhorias estruturais do código

| ID | Alteração | Aplicação e verificação |
|---|---|---|
| M01 | Separar responsabilidades | Extrair catálogo/validação, persistência e efeitos; `F3Base_Options` mantém a fachada pública. Separar repositórios e consultas de medição conforme E2–E4 |
| M02 | Resultados consistentes | Documentar tipos de retorno; confirmar estado/auditoria/agendamento; preservar distinções de persistência e efeito |
| M03 | Concorrência reutilizável | Auxiliares para CAS, repetição limitada, relógio e reservas; aplicar testes com processos simultâneos no ambiente padrão |
| M04 | Consultas mensuráveis | Registrar custo e reduzir leituras repetidas; manter leitura atual nas operações condicionais |
| M05 | Análise estática | Introduzir PHPStan com stubs WordPress e PHPCS/WPCS como dependências de desenvolvimento fixadas em lockfile; baseline explícita, sem novas violações no código alterado |
| M06 | Documentação atual | Corrigir comentários e retornos obsoletos; concentrar histórico em memória de decisões; atualizar como-usar, contratos e instruções de operação |
| M07 | Pacotes e evidências | Manter fontes reproduzíveis; retirar somente artefatos comprovadamente sem função; preservar fixtures, bibliotecas, licenças e locks |

M05 será configurado para as versões do ambiente padronizado. Cache persistente de objetos só entra na bancada se fizer parte desse perfil. Não haverá ampliação para multisite, outros bancos ou uma matriz genérica de plataformas.

O build deve impedir inclusão acidental de caches de ferramentas, dependências de desenvolvimento, arquivos temporários, credenciais e pacotes antigos aninhados. Registrar crescimento do ZIP por componente; um aumento explicado por funcionalidades, fontes ou testes úteis não será removido para atingir um número arbitrário.

## 10. Contratos e integração com agentes

- Evoluir `contract_version` de 1.3.0 para **1.4.0**, mantendo `f3base/config-core-contrato-v1` e as operações atuais compatíveis.
- Declarar novas preferências e limites no catálogo do Core. A interface, o contrato e o sanitizador usam a mesma fonte.
- Campos novos são aditivos; não mudar o significado de `ok`, `persisted`, `effect` e `verification`. Resultados específicos de fila/auditoria ganham campos próprios.
- Manter respostas padrão da v1. Projeções compactas e filtros serão opt-in; não remover `integracoes` dos consumidores existentes. Dados atuais e evidência histórica só compartilham referência quando pertencerem à mesma geração identificada.
- Dar schema tipado a todos os valores novos, incluindo uniões, nulos, arrays e marcadores de segredo. Validar pela execução real das abilities registradas, com avisos visíveis na bancada.
- Manter separadas consulta e execução. Preferir operações de leitura com metadados `readonly` próprios, sem incluir mutações sob essa classificação.
- Atualizar como-usar com exemplos de conflito, persistência confirmada/efeito pendente, auditoria pendente e tarefa em andamento. Indicar que repetir uma gravação já confirmada não é o procedimento de verificação.
- Preservar a autonomia do Core. A recusa da operação do dono não autoriza o implantador a forçar valores diretamente ou compensar a falha no tema.
- N01/N02/N07–N10 detalham as novas consultas, a mesclagem condicional e as ações. Todas as interfaces administrativas mantêm `manage_options`; `readonly` não concede acesso anônimo. Os nomes novos de abilities são propostos e devem ser conferidos contra o registro existente em E0.

## 11. Migração, homologação e distribuição

### Migração

1. Usar alterações aditivas de schema, com versão, confirmação e checkpoints. Não exigir desativação/reativação para atualizar.
2. Coordenar os consumidores durante migrações de fila e agregados. O novo consumidor só opera após sua estrutura ser confirmada.
3. Preservar IDs, TTLs e cancelamentos. Eventos antigos sem destino seguem a política de C08.
4. Construir os agregados novos em estágio; publicar uma geração somente quando sua cobertura estiver conhecida. Falha de processamento mantém a geração anterior identificada.
5. Desativar as tarefas do Core na desativação e garantir registro único na reativação. Evitar que o shutdown recrie tarefas após a desativação.
6. Preservar as políticas atuais de consentimento e sessão. Novos modos só entram em vigor após configuração explícita; decisões de consentimento recebem versão da política, sem inventar consentimento por categoria a partir do cookie antigo.
7. Versionar a classificação dos agentes. Reprocessar somente fontes disponíveis e identificar histórico que permanece na classificação anterior; não redistribuir totais antigos por estimativa.

### Homologação obrigatória no perfil padronizado

| Área | Cenários que bloqueiam a entrega se falharem |
|---|---|
| Instalação | Instalação limpa e atualização a partir da 1.9.2; operação sem implantador; política de privacidade ausente |
| Preferências | Revisão, conflito, falha de banco, auditoria concorrente, segredo mascarado e resultado parcial por seção |
| Configuração parcial | Omissão, listas, nulo, chave inválida, simulação/aplicação e CAS concorrente; recusa pela escrita genérica e sucesso pela operação própria |
| Consentimento e login | Modos legado/granular, categorias e destinos JS/PHP/CAPI; troca de decisão; perfil de sessão, múltiplos papéis e escolha de lembrar login |
| Tracking | Configuração antes do evento inicial, Google direto/GTM, destinos combinados e ausência de destino; nenhum envio adicional por reinicialização |
| CAPI | Cancelamento, HTTP em curso, aceitação externa/falha local, troca de Pixel, fila legada, TTL e recuperação |
| Cache | Edição interna sem purga; conteúdo público invalidado; conteúdo privado retirado; evidência de geração correta |
| Logs | Coleta fora do init; rotação, fuso, contribuição de múltiplos arquivos, retomada e não duplicação |
| Medição | Zero/ausência/parcial, comparação, CSV, atualização automática, tempo ativo e orçamento |
| Classificação e consultas | Sondas próprias/hospedagem separadas; totais conciliados; paginação, cobertura/retenção efetivas e ausência de segredos nos retornos |
| Arquivos | Responsável único, restauração de robots, llms/full/Markdown, proteção de conteúdo e respostas HTTP |
| Interfaces | Desktop e celular, teclado/foco, mensagens compreensíveis e filtros preservados |
| Agentes e CLI | Abilities nativas sem avisos, consultas sem efeitos e comandos sobrepostos |
| Diagnóstico público | Core llms desligado, concorrente potencial/confirmado, hash de robots e sonda truncada; arquivo de cache elegível versus caminho inexistente |
| Contrato e políticas | Chamadas antigas compatíveis; compactação medida; perfil ausente não vira conformidade; proteção do conector testada no registro real |
| Build | Instalador reproduzível, fontes completas e limpas, manifesto, hashes e licenças |

### Distribuição

1. Gerar um candidato a release a partir dos commits concluídos.
2. Instalar no WordPress de teste e executar os cenários com o perfil de cache e Yoast da operação.
3. Ensaiar tarefas agendadas por relógio controlado e observar ao menos uma execução real do executor configurado, incluindo coleta de um log fechado e verificação pública.
4. Publicar o pacote estável somente após concluir os gates. Distribuir inicialmente a um site representativo; observar fila, erros, coleta, cache e cobertura antes dos demais.

### Recuperação e rollback

Preparar backup antes da atualização e ensaiar recuperação. Preferir correção para frente ou retorno de código compatível com o schema aditivo, pausando os consumidores afetados.

O retorno para a 1.9.2 precisa ser testado expressamente. Se essa versão não interpretar com segurança os estados novos, manter o componente afetado parado e usar um pacote de recuperação compatível. Restaurar indiscriminadamente um banco anterior recria leads eliminados e pendências já enviadas. Recuperação de dados deve preservar cancelamentos e reconciliar entregas posteriores ao backup; efeitos externos não são desfeitos pela restauração local.

## 12. Entregáveis e rastreabilidade

Ao implementar o plano, entregar:

- `base-site-core-fator3-1.10.0.zip` instalável.
- `base-site-core-fator3-fonte-1.10.0.zip`, com fontes, testes, instruções e insumos necessários à reprodução.
- Changelog, guia de atualização/recuperação e instruções atualizadas para operadores e agentes.
- Manifesto do ambiente, hashes dos pacotes, evidências dos testes e comparação de desempenho.
- Lista explícita de qualquer pendência de homologação. Nenhum item sem evidência será descrito como concluído.

| Itens da revisão | Etapa do plano |
|---|---|
| C03, C05, C06 | E1 |
| C01, C02, C08, C11 | E2 |
| C04, C07 | E3 |
| C09, C10 | E4 |
| F01–F07 | E5, após os serviços correspondentes |
| M01–M07 | Aplicação incremental em E0–E6 |
| N01–N05 | Base em E1; integração com E2 e interfaces em E5 conforme seção 15 |
| N06 | E4, complementando C09/C10 e F03 |
| N07–N10 | Serviços em E2–E4 e interfaces em E5, conforme seção 15 |

## 13. Fundamentação da sequência

1. A revisão contém problemas que atravessam mais de um módulo; por isso, fila e eliminação compartilham um único marco de migração.
2. Auditoria e escrita condicional servem de base aos operadores humanos e aos agentes; sua correção precede a ampliação das interfaces.
3. A coleta e o calendário determinam o significado dos números. Comparação, exportação e atualização contínua dependem dessa base estabilizada.
4. As novas telas e comandos reaproveitam os mesmos serviços para evitar regras divergentes.
5. O ambiente padronizado concentra a homologação. Ele reduz o escopo de compatibilidade, mantendo necessários os testes de falhas, concorrência, recuperação e integração que ocorrem nesse próprio ambiente.

Fonte principal: [analise-base-site-core-1.9.2.md](sandbox:/workspace/scratch/fa8872bf822c/revisao-core/analise-base-site-core-1.9.2.md). Os comportamentos novos e valores iniciais deste documento são decisões propostas de implementação, não resultados já medidos.

## 14. Avaliação dos relatórios adicionais

**R1:** `relatorio-base-site-core-fator3-1.9.0.md`, nove sugestões. **R2:** `relatorio 1 base-site-core-fator3.md`, relatório sobre 1.9.1, itens A1–C3 e pendência sobre exposição de cache. Ambos foram confrontados com os fontes locais **1.9.2**. Os resultados remotos e as decisões históricas mencionadas nos relatórios continuam atribuídos aos seus autores; esta revisão não confirmou versões instaladas, titularidade atual de endpoints ou entrega de eventos aos fornecedores.

Os identificadores abaixo são locais a esta seção: por exemplo, **R2.B1** não se confunde com tabelas A/B de backlogs anteriores. A responsabilidade é determinada pelo componente, não pela letra do grupo.

| Referência | Decisão | Inclusão ou ajuste no plano |
|---|---|---|
| R1.1 — Consentimento por categoria | Incluir com migração explícita | N03 separa medição e publicidade; não troca a política vigente durante a atualização |
| R1.2 — Tráfego próprio/hospedagem | Incluir | N06 complementa C10 com classes de agente e UA próprio nas sondas |
| R1.3 — Prazo de sessão por perfil | Incluir como opção | N05 preserva a política atual e oferece regras por papel/capacidade |
| R1.4 — Journal do implantador | Encaminhar ao implantador | A migração de `f3base_journal` não pertence ao Core; C06 trata o journal de eliminação do Core |
| R1.5 — `como-usar` repetitivo | Incluir | N01 acrescenta filtros e projeção compacta, mantendo a chamada atual |
| R1.6 — Regeneração do robots físico | Já implementada; reforçar | N08/F05 explicam o mecanismo existente e acrescentam regressão com Yoast e falhas de publicação |
| R1.7 — Cobertura dos acessos | Ampliar item existente | N06/C09/F03 informam dias e motivos; ausência de agregado não significa ausência de log |
| R1.8 — Procedência no diagnóstico | Incluir com ressalva | N01/C06 distinguem registro, inferência e histórico desconhecido |
| R1.9 — CSP Report-Only | Backlog posterior | Exige coletor próprio, inventário e limites; não misturar relatórios CSP com eventos de comportamento |
| R2.A1 — `como-usar` compacto | Unificar com R1.5 | N01, com redução de bytes medida sobre fixture |
| R2.A2 — Integrações sob demanda | Incluir com compatibilidade | N01 oferece projeção opt-in; rejeitar remoção dos campos padrão da v1 e deduplicação entre gerações diferentes |
| R2.A3 — Escrita parcial | Incluir | N02 mescla campos tipados e grava o valor completo pela API do Core, com revisão obrigatória |
| R2.A4 — Perfil de frota | Dividir responsabilidades | N10 fornece avaliador genérico; perfil esperado, exceções e gestão da frota ficam no implantador |
| R2.A5 — Consultas internas | Incluir | N07 oferece consultas limitadas de comportamento, eventos e leads, sem SQL arbitrário |
| R2.A6 — Sondas por ability | Incluir com escopo delimitado | N08 aceita GET/HEAD e asserções limitadas; não aceita métodos, destinos ou credenciais arbitrários |
| R2.B1 — Proteção de options | Incluir no Core | N02 usa o catálogo de propriedade e a API real do conector; mescla proteções de outros plugins |
| R2.B2 — `readonly` | Incluir | N01 anota consultas após confirmar ausência de efeitos; sondas e executores permanecem ações |
| R2.B3 — Agenda e acionamento | Ampliar F01/F07 | N09 reutiliza agenda existente do cache e executa somente tarefas elegíveis do Core |
| R2.B4 — Mudanças consultáveis | Incluir | N01/M06 acrescentam histórico estruturado, filtrado por versão e mantido pelo release |
| R2.C1 — Ordem do tracking | Corrigir e testar | N04 trata a emissão antecipada confirmada; perda efetiva no GA4 ainda requer comprovação |
| R2.C2 — Responsável pelo llms | Corrigir e ampliar | N08 corrige `core_serve` com Core desligado e distingue concorrente potencial de emissor confirmado |
| R2.C3 — Canal de atualização | Entrega posterior | Manter `Update URI: false` até existir distribuição confiável; troca de cabeçalho isolada não resolve |
| R2.Backlog — Exposição de cache | Incluir diagnóstico | N08 testa artefato elegível e existente; não infere proteção a partir de um 404 de caminho inventado |

### Evidências e premissas corrigidas

Referências relativas a `revisao-core/fontes/base-site-core-fator3/fontes/plugin/`, verificadas estaticamente na 1.9.2:

| Evidência no código | Consequência para o plano |
|---|---|
| `class-f3base-robots-entrega.php::verificar()` e `class-f3base-robots-arquivo.php::gravar_gerenciado()` | A revalidação já consulta a rota virtual com prova, reconcilia o físico gerenciado e compara a resposta pública. Reutilizar; não recriar por captura local de `do_robots()` |
| `class-f3base-modulo-acessos-servidor.php::agente()` e `linha()` | UAs não reconhecidos terminam como humanos; a linha usa UA, não cabeçalhos HTTP arbitrários. `X-F3Base-Verificacao` não basta no log combined |
| `class-f3base-options.php::proveniencia()` | Option existente sem registro recebe fallback `implantador`; esse valor precisa ser identificado como inferência legada |
| `dados/contrato-de-nomes.tsv`, registros do journal | `f3base_journal` pertence ao implantador. Prefixo compartilhado não transfere sua propriedade ao Core |
| `class-f3base-como-usar.php::resposta()` e `class-f3base-config-contrato.php::consultar()` | São pontos que acrescentam `integracoes`; a generalização de que todas as rotas o fazem não se confirma |
| `class-f3base-cache-evidencia.php::agenda()` | Já informa atraso, próxima verificação e última execução. Ampliar a cobertura dos módulos, sem agenda paralela |
| `assets/f3base-tracking.js::carregar()`, `instrumentarPaginaVista()` e `carregarGoogleDireto()` | Evento customizado entra antes da configuração Google. A ordem é verificável; descarte pelo fornecedor não foi medido nesta revisão |
| `class-f3base-llms.php::responsaveis()` e `class-f3base-modulo-llms-txt-reserva.php::emissor()` | O diagnóstico usa elegibilidade de emissão sem considerar ali a ativação/visibilidade efetiva; pode declarar `core_serve` com o recurso desligado |
| `class-f3base-modulo-rota-origem.php::ler()` | A requisição usa a URL pública e limita o corpo depois do download. Não comprova bypass de CDN/cache e precisa de limite no transporte |

As referências `class-*.php` da tabela estão em `includes/`. Não serão adotadas como fatos atuais a alegação de que 1.9.1 é a última versão, a configuração descrita dos treze sites ou a preferência histórica por Indexe em um site. Tampouco serão apresentados como ganhos alcançados as estimativas de chamadas/tokens dos relatórios.

## 15. Complementos de implementação

### N01 — Consultas compactas, procedência e documentação versionada

**Origem:** R1.5/R1.8, R2.A1/A2/B2/B4. **Etapas:** E1 para contratos; E5 para projeções e documentação. **Dependências:** C06/M06.

- Acrescentar `assuntos`, `compacto` e seleção limitada de blocos em `como-usar`; disponibilizar projeção equivalente no contrato. Ausência dos parâmetros preserva estrutura e semântica atuais. Rejeitar filtros desconhecidos com erro compreensível.
- No compacto, priorizar ID, estado, código, opções pertinentes e referência da evidência. Integrações e instruções extensas entram quando pedidas; a documentação completa continua acessível.
- Evitar leituras e montagem de blocos não solicitados, além de reduzir a serialização. Medir tamanho, tempo e consultas no mesmo acervo. Meta de compacto abaixo de 20% do tamanho integral em fixture representativa, preservando os campos definidos; registrar o resultado, sem alegar redução automática do número de chamadas.
- Distinguir tokens/estado atuais de evidência histórica. Referências usam ID e geração, não somente `checked_at`; compactar cópias equivalentes na projeção sem apagar o registro durável.
- Expor procedência registrada ou inferida, revisão, horário disponível e estado preenchido/vazio. Não retornar segredos. Histórico ausente significa desconhecido. Registrar limpezas futuras pela auditoria de C06, sem deduzir exclusões passadas do valor vazio atual.
- Anotar `como-usar`, `config-core-ler` e `config-ler` como `readonly` somente após testar os callbacks. Remover qualquer migração ou agendamento implícito do caminho de leitura; manter sondas/verificadores como ações.
- Acrescentar bloco de mudanças sob demanda, com `desde_versao`, módulo, tipo e impacto de migração. Ordenar versões semanticamente, limitar/paginar resultados e gerar os dados junto do changelog do release. Não inserir todo o histórico em cada resposta nem presumir proteção HTTP só por usar TSV.

**Aceite:** chamadas antigas preservadas; filtros e compactação funcionam pelo registro real de abilities, sem avisos; consultas não gravam nem disparam HTTP; todas as respostas mascaram segredos; origem inferida e histórico desconhecido aparecem corretamente; changelog e catálogo de mudanças concordam.

### N02 — Alteração parcial e proteção da API do proprietário

**Origem:** R2.A3/B1. **Etapa:** E1 após C05/C06. **Dependências:** catálogo, fotografia/revisão e API real do conector.

- Acrescentar `mesclar: true` à operação de escrita para options compostas elegíveis, mantendo o comportamento de valor completo e `simular: true` por padrão. Revisão esperada continua obrigatória.
- Omissão preserva campos; mapas conhecidos podem receber mesclagem pelas chaves declaradas; listas são substituídas integralmente. `null` só é aceito quando permitido pelo schema e não representa exclusão implícita. Campos de entrada desconhecidos são recusados; extensões legadas existentes seguem a regra de preservação já declarada pelo catálogo, sem liberação genérica de novas chaves.
- Formar o valor completo a partir da fotografia correspondente à revisão, validar/normalizar o conjunto e aplicar por `F3Base_Options::gravar()`. A aplicação usa CAS e a mesma revisão da prévia; conflito exige nova leitura e revisão da prévia. Não criar caminho de escrita direta.
- Retornar prévia e resultado com segredos mascarados. Marcador de segredo é somente saída, nunca um valor a persistir. `persisted`, efeito e verificação conservam significados separados. Não forçar procedência humana: o rótulo de compatibilidade `edicao-manual` não prova que uma pessoa executou a chamada; documentar o canal efetivamente conhecido.
- Integrar a lista fechada de `F3Base_Options::proprias()` ao filtro de proteção do conector, incluindo registros internos pertencentes ao Core. Mesclar listas já existentes. Não bloquear todo `f3base_*`, pois há opções do implantador com o mesmo prefixo.
- Testar o contrato real de `wp_mcp_ultimate_protected_options`. Quando o canal permitir, sua recusa orienta o uso da operação do dono. Não introduzir bloqueio global de `update_option` nem declarar que o filtro impede acesso direto ao banco por canais administrativos independentes.

**Aceite:** alteração de uma chave preserva as demais; normalização aparece na prévia; listas/nulos/segredos/chaves inválidas seguem o schema; alteração concorrente não é sobrescrita; escrita genérica protegida é recusada e a API do Core continua funcionando, inclusive sem conector ou implantador ativo.

### N03 — Consentimento opcional por categoria

**Origem:** R1.1. **Etapas:** política em E1, cobertura CAPI em E2 e interface em E5. **Dependências:** C03, N04 e catálogo.

- Introduzir modo granular com categorias de medição e publicidade e decisão versionada. Mapear explicitamente comportamento local, Web Vitals, GA4, Ads, Meta, LinkedIn, GTM e CAPI às categorias e às regras de envio; funções essenciais permanecem descritas separadamente.
- Preservar o modo legado nos sites existentes. Oferecer perfil opt-in em que categorias baseadas em consentimento começam negadas, com publicidade liberada somente após escolha correspondente. A operação define a política aplicável; o plugin não declara conformidade jurídica automática.
- Ao migrar explicitamente, um `granted` legado não vira prova de escolha granular: solicitar as decisões necessárias conforme a nova política. Manter negativas válidas e não inventar origem, horário ou base jurídica. Mudança de versão invalida somente decisões incompatíveis, segundo regra documentada.
- Aplicar a regra antes de carregar tags e antes dos envios JS/PHP/CAPI, inclusive após revogação. Tratar eventos ainda não enviados de acordo com a política; informar que revogação não desfaz entregas externas anteriores. Não reproduzir retroativamente eventos coletados sem autorização para publicidade.
- Vincular eventos CAPI à decisão e à versão da política por referência técnica mínima. Definir operação de revogação com comprovante opaco verificável, escopo limitado à decisão correspondente e confirmação pelo servidor. Coordenar a checagem com a reserva/cancelamento de C01 antes do HTTP; reter somente o marcador necessário durante a vida dos trabalhos afetados. Revogação local ainda não recebida pelo servidor não aparece como cancelamento confirmado da fila.
- Definir comportamento de GTM: bits de Consent Mode isolados não garantem bloqueio de tags personalizadas. O contrato deve descrever o requisito do contêiner e usar uma política conservadora para carregá-lo quando essa separação não estiver comprovada. Não prometer controle sobre tags inseridas fora do Core.
- Interface acessível para escolher, revisar e revogar categorias, operante sem página de política de privacidade. Manter as métricas de consentimento limitadas e sem cópia de conteúdo pessoal.

**Aceite:** modos legado/granular, cookie inválido, ausência de escolha, aceitar parcialmente, revogar e voltar a aceitar; matriz por fornecedor e canal, sem duplicação por reinicialização. Testar revogação entre enfileiramento/execução, durante reserva e com falha de comunicação ao servidor. Nenhum envio novo pode ignorar a decisão vigente conhecida pelo componente; distinguir decisão local, confirmação no servidor e requisição já iniciada. Testes usam destinos simulados e ambiente de homologação autorizado quando houver comprovação externa.

**Referência de desenho:** o [guia de cookies da ANPD](https://www.gov.br/anpd/pt-br/centrais-de-conteudo/materiais-educativos-e-publicacoes/guia-orientativo-cookies-e-protecao-de-dados-pessoais.pdf/@@display-file/file) orienta granularidade e desativação inicial dos cookies baseados em consentimento. Isso fundamenta o perfil opcional, sem transformar a revisão técnica em determinação de uma base jurídica única para todos os sites.

### N04 — Inicialização e emissão do tracking

**Origem:** R2.C1. **Etapa:** E1 em conjunto com N03; confirmação em E5/E6.

- Separar instalação dos coletores locais, configuração dos destinos e emissão inicial. No Google direto, comandos necessários de consentimento/inicialização/configuração precedem o evento customizado correspondente.
- Manter o caminho GTM e a medição local independentes da configuração Google direta. Usar fila limitada por destino, com descarte por mudança de política e prevenção de reemissão local; não aguardar indefinidamente um fornecedor bloqueado.
- Documentar `f3base_pagina_vista` e `page_view` automático como eventos diferentes, definindo quais são emitidos em cada modo. Evitar introduzir dupla contagem ao corrigir a ordem.
- Testar a fila com relógio/destinos controlados e observar a requisição elegível. Se houver propriedade de teste disponível e autorizada, comprovar recepção pelo fornecedor; caso contrário, registrar esse limite da homologação. Ordem correta da fila não prova, por si, entrega externa.

**Aceite:** direto, GTM, GA4/Ads combinados, nenhum fornecedor e ciclos de consentimento produzem a sequência definida e nenhum evento adicional por reinicialização. A correção não transforma a suspeita de perda no GA4 em fato já demonstrado.

### N05 — Política opcional de duração de login

**Origem:** R1.3. **Etapa:** E1; interface em E5.

- Manter a política atual até mudança explícita. Oferecer regras por papel/capacidade, com perfil sugerido: autores/assinantes até 90 dias, editores até 14 e administradores conforme o núcleo, respeitando a escolha de lembrar login. Esses valores são proposta de configuração, não migração automática.
- Tratar múltiplos papéis pela regra mais restritiva e contemplar papéis personalizados com capacidades privilegiadas. Não identificar privilégio somente pelo nome `administrator`.
- No novo modo, não forçar `rememberme`. Informar prazo efetivo, regra aplicada e procedência, aproveitando os parâmetros do filtro nativo.
- Aplicar a mudança às novas sessões. Revogar sessões existentes é uma ação distinta e explícita, com resultado próprio; não desconectar usuários durante a atualização.
- Distinguir cookies de login de Application Passwords e demais autenticações do conector. O prazo de cookie não determina o TTL de todas as credenciais MCP; a razão entre prazos não quantifica probabilidade de comprometimento.

**Aceite:** lembrar/desmarcar login, papéis simples/múltiplos e administrador personalizado recebem o prazo esperado; modo legado preservado; demais mecanismos de autenticação não são alterados.

Referências: [filtro `auth_cookie_expiration`](https://developer.wordpress.org/reference/hooks/auth_cookie_expiration/) e [autenticação da REST API](https://developer.wordpress.org/rest-api/using-the-rest-api/authentication/).

### N06 — Tráfego automático e cobertura por dia

**Origem:** R1.2/R1.7. **Etapa:** E4, ampliando C09/C10/F03.

- Acrescentar classes de agente `proprio` e `hospedagem`, preservando total geral e classes existentes. Diferenciar tráfego humano estimado de identidade humana comprovada; User-Agent é uma declaração falsificável.
- Emitir UA próprio nas sondas do Core. Reconhecer o formato legado WordPress associado ao host canônico/aliases conhecidos do site e identificar WordPress de outro host como automação declarada, sem classificá-lo como tráfego próprio. Normalizar `www` apenas nas equivalências do site.
- Incluir padrões conhecidos do provedor e permitir padrões adicionais limitados/validados, preferindo correspondências literais. IP coincidente e cabeçalho ausente do log não são prova de origem. Aplicar a mesma regra em UI, totais, exportações e abilities.
- Versionar classificação e incluir padrões personalizados no hash de processamento. Reclassificar apenas logs ainda disponíveis; histórico irrecuperável permanece identificado como legado. Preservar as somas ao redistribuir as classes.
- Informar primeiro/último dia coberto e mapa por dia: completo, parcial, processamento pendente, falha, ausência de fonte observada ou desconhecido. Acrescentar origem, versão e momento da inspeção; hoje permanece parcial e separado do histórico fechado.
- `dias_sem_arquivo` só contabiliza dias efetivamente inspecionados sem fonte elegível. Não inferir remoção pela hospedagem, falha de coleta ou zero acessos sem evidência. Taxas e comparações declaram os dias usados no denominador.

**Aceite:** WordPress próprio/outro host, UA da hospedagem, bot conhecido, humano estimado e UA forjado são classificados conforme regras declaradas; totais conciliam; janela de 90 dias com 20 cobertos mostra explicitamente essa diferença; zero observado não se confunde com lacuna.

### N07 — Consultas de comportamento, eventos e leads

**Origem:** R2.A5. **Etapa:** E5 após serviços de E2/E4; interfaces `f3base/comportamento-ler`, `f3base/eventos-ler` e `f3base/leads-ler` propostas.

- Reutilizar serviços das telas e o padrão administrativo de `acessos-ler`, com prefixo de tabela resolvido internamente, schemas tipados, filtros permitidos, limite máximo e paginação por cursor. Não aceitar SQL ou nomes de tabelas fornecidos pelo consumidor.
- `comportamento-ler` aceita caminho, janela e métrica; retorna seções/eventos, `cortadas` por caminho/dia, `erro_js`, visitantes/sessões distintos da janela e maior `ocorrencia` por métrica. `eventos-ler` oferece a sequência ordenada por sessão/caminho, com desempate estável e sinalização de corte. `leads-ler` oferece contagens por dia/origem no armazenamento efetivo, Flamingo ou contingência, além dos novos contadores de recusas por motivo.
- Separar agregados, consultas de sessão e contagens de leads. Retornar fuso, cobertura, retenção efetiva, data da fotografia, corte/amostragem quando houver e próxima página. Contagens exatas são identificadas como tais; distintos do período não são soma de distintos diários.
- Não retornar corpos dos leads nestas consultas; os resumos contêm contagens, sem dados pessoais dos formulários. Detalhes de eventos mantêm permissão e minimização, pois identificadores pseudônimos também permitem correlação.
- Para recusas de leads, criar contadores limitados por motivo sem payload pessoal. O registro atual da última recusa não sustenta uma série histórica; informar início de cobertura dos novos contadores.
- Não descrever contagens independentes de páginas, eventos e leads como funil de conversão por coorte sem ligação temporal/identificadores suficientes. Reutilizar a retenção configurada, sem fixar em 30 dias a informação retornada.

**Aceite:** resultados conciliam com consultas de referência na mesma fotografia dos dados; filtros/cursor não duplicam nem omitem registros no recorte estável; ausência de fonte e retenção aparecem; permissões e ausência de segredos são verificadas pelo registro real das abilities. Limites de consulta definidos em E0 integram o catálogo.

### N08 — Publicação observada e sondas administrativas

**Origem:** R1.6, R2.A6/C2/Backlog. **Etapas:** serviços em E3; interface F05 em E5. **Prioridade:** corrigir os diagnósticos antes de ampliar as sondas.

- Separar elegibilidade, configuração ligada/desligada, hooks registrados e resposta pública observada. Core desligado ou site sem visibilidade pública não pode aparecer como emissor ativo de llms. A última observação fica datada e perde validade com mudança relevante.
- Adotar registro extensível de emissores. Yoast/Indexe exigem adaptador fundamentado em API/configuração conhecida; ativação do plugin sozinha indica concorrente potencial. Se o Indexe não puder ser inspecionado na bancada, reportar responsável não determinado, sem inventar compatibilidade nem alterar a preferência do site. HTTP 429 não confirma proprietário.
- Reutilizar a reconciliação existente do robots gerenciado na rotina agendada ou em ação explícita de reconciliação. A nova sonda de inspeção não chama diretamente esse método que pode escrever arquivos: apenas observa e registra evidência. Mostrar conteúdo sincronizado/divergente/desconhecido, geração, hashes pertinentes, última execução e validade. Testar mudança de regra Yoast, permissão, cache e edição externa sem destruir backup. A cadência prevista não é garantia de execução pontual.
- Expor sonda por ability administrativa com GET/HEAD, destinos públicos explicitamente permitidos no próprio site, timeout, limite de bytes no transporte e de retorno. Não seguir redirecionamentos automaticamente; registrar o destino e só oferecer nova sonda após validação da mesma allowlist. Bloquear redirecionamento a outros hosts, portas ou destinos privados.
- Não herdar cookies ou credenciais, nem aceitar cabeçalhos livres de autorização/Host ou métodos de mutação. Teste de autenticação negativa, quando necessário, usa fixture sintética fechada e revisada. Permitir somente asserções literais/limitadas de status, cabeçalho e conteúdo; nenhuma expressão regular arbitrária.
- Resultados por asserção: aprovado, reprovado ou inconclusivo, com motivo. Corpo truncado impede confirmar ausência de trecho no conteúdo integral; SHA identifica os bytes efetivamente observados e sua completude. GET feito pelo servidor pela URL pública não é prova de acesso direto à origem: corrigir essa descrição na rota existente.
- Asserções de conteúdo em HEAD são inconclusivas por não aplicabilidade; corpo vazio não demonstra ausência no recurso. Um 304 só revalida conteúdo previamente observado se URL, representação, geração e validador estiverem vinculados. Sem esse vínculo, não confirmar conteúdo nem atribuir ao recurso o hash de uma resposta vazia.
- Diagnóstico de exposição do cache usa artefato elegível cuja existência local esteja comprovada, conforme modo e expectativa de acesso do WP Super Cache/provedor. Não usar cache com conteúdo privado como isca; não guardar seu conteúdo na evidência. Ausência de artefato elegível gera pendência/não aplicável. Um 404 de caminho inexistente ou ausência de `Index of` não comprova proteção geral.
- Sondas são ações com registro e orçamento; consultas apenas leem evidência. Não escrever regras de servidor, reinstalar módulo de índices nem mudar o responsável por publicação automaticamente.

**Aceite:** Core llms desligado, site privado, arquivo físico e emissores concorrentes produzem diagnóstico coerente; mudanças no Yoast reconciliam robots pela rotina própria; inspeção não grava arquivos; truncamento, HEAD sem corpo, 304 sem evidência vinculada, redirect, falha HTTP e evidência vencida não viram confirmação de conteúdo; proteção de cache é avaliada contra expectativa explícita e arquivo existente. Preservar regras de descoberta/full de F05/F06.

### N09 — Agenda unificada e execução externa limitada

**Origem:** R2.B3. **Etapas:** serviços em E3; F01/F07 e ability em E5.

- Consolidar por tarefa do Core: próxima execução, última tentativa, último sucesso, atraso, estado da reserva e saldo. Reutilizar `Cache_Evidencia::agenda()` e os serviços de coleta, CAPI, publicação e retenção; não criar segunda agenda.
- Oferecer `f3base/executar-pendentes` como ação administrativa e comando CLI equivalente. Permitir somente tarefas conhecidas e elegíveis do Core, com teto de trabalhos/tempo, reservas e continuação; não despachar callbacks ou todos os hooks do cron fornecidos pelo cliente.
- Devolver concluído, parcial, reservado por outro processo, reagendado e falha, com próximo trabalho. Agendamento existente não significa execução concluída.
- Corrigir a documentação do mecanismo: no WordPress 6.9, o caminho normal de `wp_cron()` usa shutdown; há comportamento específico com `ALTERNATE_WP_CRON`. Uma consulta MCP não garante processamento completo das pendências. Conferir o executor real na bancada e informar atrasos.
- Provisionamento, credenciais e agenda externa pertencem à hospedagem/implantador. O Core permanece funcional com seu executor configurado e não cria tarefas externas automaticamente.

**Aceite:** cron, CLI e ability concorrentes respeitam reservas; trabalhos excedentes continuam em lotes; consultas de agenda não executam tarefas; horário vencido e falha de executor ficam visíveis. Referência: [implementação de `wp_cron()`](https://developer.wordpress.org/reference/functions/wp_cron/).

### N10 — Avaliação de configuração contra perfil declarado

**Origem:** R2.A4. **Etapa:** E5, após N01/N08.

- O implantador fornece o perfil esperado e administra versões/exceções. O Core oferece avaliação somente de leitura contra perfil declarativo versionado fornecido na operação ou referência previamente validada. Não embutir no pacote as decisões particulares dos treze sites.
- Perfil informa ID, revisão e condições conhecidas; aceitar somente opções do catálogo e observações de terceiros expostas por adaptadores permitidos. Não transformar a consulta em leitura genérica de qualquer option nem assumir que o vocabulário de metadados SEO já lê todas as preferências do Yoast.
- Opções secretas admitem somente avaliação de presença/configuração, com marcador mascarado na resposta. Perfil, comparações e divergências não recebem nem devolvem valores secretos.
- Devolver esperado, observado, procedência, revisão/evidência e estado: conforme, divergente, exceção válida ou indeterminado. Ausência de perfil, evidência vencida e campo não suportado não produzem lista vazia interpretável como conformidade.
- Exceções identificam responsável, razão, vigência e versão do perfil. O Core valida a estrutura; a autoridade do perfil vem do fluxo administrativo do implantador. Não criar exceções para esconder uma divergência nem assumir a decisão antiga sobre Indexe como vigente.
- Retornar contadores de verificações e itens indeterminados mesmo quando forem solicitadas somente divergências. O relatório não grava valores, remove arquivos, purga cache nem executa sondas; oferece referência à ação correspondente.

**Aceite:** perfil válido com dados atuais concordantes informa conformidade; perfil ausente, opção desconhecida ou publicação sem prova informa indeterminado; exceção expirada não aprova; alteração de revisão invalida a comparação anterior; nenhuma mudança é aplicada durante a consulta.

## 16. Itens encaminhados ou adiados

| Item | Responsável / motivo | Condição para entrada futura |
|---|---|---|
| Journal de implantação (R1.4) | Implantador: dono de `f3base_journal`, sua retenção, reversibilidade e formato | Planejar armazenamento incremental/paginado e migração no implantador; Core não move nem apaga esses registros. C06 permanece dedicado aos registros próprios |
| Perfil esperado da frota e executor externo (R2.A4/B3) | Implantador/hospedagem: parâmetros por site, exceções e agendamento | Consumir o contrato e as ações do Core; fornecer perfil vigente e executor com evidência de execução, sem forçar valores após recusa |
| CSP Report-Only (R1.9) | Nova função de coleta pública, além de simples emissão de cabeçalho | Inventariar recursos e desenhar coletor próprio com tamanho/frequência/retenção limitados, remoção de query/segredos e deduplicação. Não usar a tabela de comportamento como depósito de relatórios arbitrários. Recurso opt-in, separado do orçamento de eventos |
| Atualizador próprio (R2.C3) | Depende de serviço/processo de distribuição confiável para os pacotes | Definir manifesto, origem autenticada, política de versões/downgrade, pacote correto, integridade e recuperação. Hash vindo do mesmo manifesto não autentica sua origem. Manter `Update URI: false` enquanto essa cadeia não existir |

Para CSP, uma proposta futura deve definir `Reporting-Endpoints`/`report-to` e a compatibilidade desejada; emissão em report-only observa violações, sem bloquear recursos. A diretiva atual `frame-ancestors` não constitui, por si, defeito a corrigir nesta versão. Referência: [documentação de CSP Report-Only](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy-Report-Only).

O atualizador futuro deve respeitar `DISALLOW_FILE_MODS`, permissões de atualização e escolha explícita de autoatualização por site. Este plano não cria um endpoint de distribuição, não publica pacotes e não autoriza atualizações automáticas da frota.

## 17. Prioridades e conclusão desta revisão

1. **Estabilizar o comportamento existente:** C01–C11, diagnóstico de emissor/sonda em N08 e sequenciamento de N04. Manter distinção entre evidência estática, reprodução e confirmação externa.
2. **Fortalecer o contrato de configuração:** N01/N02, políticas opcionais N03/N05 e teste do registro real das abilities. Evolução aditiva; nenhuma migração silenciosa das preferências atuais.
3. **Melhorar a qualidade da medição e operação:** N06/N07/N09, reutilizando calendário, filas, limites e serviços já planejados.
4. **Entregar a experiência de uso e avaliação:** F01–F07 e N10 sobre serviços estabilizados; priorizar diagnóstico que explica pendências e evita ações repetidas.

A 1.10.0 planejada inclui N01–N10 no escopo descrito; as partes dependentes de terceiros têm critérios explícitos de suporte ou estado indeterminado. CSP, migração do journal do implantador e canal de atualização próprio não integram a implementação do Core nesta entrega. O perfil padronizado continua sendo o único alvo: nenhuma demanda de multisite ou ampliação de banco foi acrescentada.
