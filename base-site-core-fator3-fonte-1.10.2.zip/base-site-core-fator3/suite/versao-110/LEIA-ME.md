# Bancada da versão 1.10.0

O perfil é WordPress 6.9, PHP 8.3.6, SQLite Database Integration 3.0.2 com journal **DELETE**, Yoast 28.4 e WP Super Cache 3.1.3 no modo Simple. O cron é despachado explicitamente; HTTP externo e e-mail são recusados pela fixture. A bancada usa somente conteúdo sintético e endereços localhost. As versões efetivamente executadas ficam em `suite/evidencias-110/ambiente.json`.

## Preparação

Requer PHP com sqlite3/pdo_sqlite, curl, mbstring, phar, dom, SimpleXML, xml, xmlreader, xmlwriter, zip e tokenizer; Python, Node, curl e unzip. A suíte geral também exige faketime e navegador Chromium. A ausência de um desses insumos não aprova o respectivo gate.

Forneça um diretório com `wordpress.zip`, `sqlite-database-integration.zip`, `wordpress-seo.zip` e `wp-super-cache.zip`. Os ZIPs devem conter as versões acima. O núcleo de WordPress da execução inicial foi reaproveitado de uma bancada local e seu SHA foi registrado; isso não equivale a nova conferência com os checksums públicos do WordPress. WP-CLI fica no mesmo cache quando os testes legados o utilizam.

```bash
bash suite/versao-110/preparar-bancada.sh /cache/insumos /pacotes/base-site-core-fator3-1.10.0.zip
```

O comando imprime o caminho de um WordPress descartável, instalado a partir do ZIP informado. A instalação pede um marcador local específico, define `SQLITE_JOURNAL_MODE=DELETE` antes do carregamento do núcleo e gera um tema mínimo. Esse tema é uma fixture; o layout do site real não é avaliado aqui.

Para testar frentes em paralelo, use um destino novo por processo:

```bash
python3 suite/versao-110/clonar-bancada.py /bancada/template /bancada/caso-novo
```

O clonador exige `PRAGMA integrity_check=ok`, copia o banco pela API SQLite `backup`, confirma novamente a integridade e reescreve os caminhos locais do cache. Não copie diretamente arquivos de banco abertos nem compartilhe uma mesma base entre cenários mutantes. Ao encerrar testes de concorrência, repita `integrity_check` e confira o journal.

## Gates novos

Os testes abaixo usam o registro **real** de abilities e a validação/sanitização do WordPress. Configuração direta, dublês de wpdb e mera inspeção de schema não substituem este gate.

```bash
F3BASE_SITE=/bancada/caso-novo php suite/versao-110/abilities.php
F3BASE_SITE=/bancada/caso-com-mcp php suite/versao-110/mcp-options.php
F3BASE_SITE=/bancada/caso-novo php suite/versao-110/config-110.php
F3BASE_SITE=/bancada/caso-novo php suite/versao-110/config-110-concorrencia.php
F3BASE_SITE=/bancada/caso-novo php suite/versao-110/benchmark.php
```

`mcp-options.php` exige o conector WP MCP Fator3 0.12.1 ativo e chama `options/update` de sua implementação real. Confere recusa pelo canal genérico, preservação das proteções de outros donos e funcionamento da API Core.

`rodar-roteiro.sh` inicia HTTP local e executa os passos solicitados da bancada legada no mesmo contexto de processo/rede. Exemplo:

```bash
F3BASE_SITE=/bancada/caso-novo F3BASE_BANCADA_TMP=/tmp/evidencias \
  F3BASE_BANCADA_CACHE=/cache/insumos \
  bash suite/versao-110/rodar-roteiro.sh home_servida contrato_sem_avisos
```

Os testes legados que exigem Core isolado devem usar uma fixture própria. Um teste que exige ausência de Yoast não certifica o perfil integrado. O benchmark emite bytes, consultas, tempo, memória e tamanho do acervo; compare execuções com o mesmo acervo e plugins.

## Análise estática

`composer.json` e `composer.lock` fixam ferramentas somente de desenvolvimento. `vendor/` e caches das ferramentas não pertencem ao instalador nem ao ZIP de fontes. Execute `composer install` para restaurá-las.

```bash
composer analyse
composer style
composer style:full
```

PHPStan usa nível 1, stubs WordPress 6.9 e assinaturas das integrações opcionais. A baseline gerada da fonte 1.9.2 é vazia após declarar corretamente constantes e assinaturas; caminhos de instalação são constantes dinâmicas. Essa análise encontra símbolos/chamadas inválidas, mas não oferece o rigor de níveis superiores nem substitui os testes de execução.

WPCS mantém sua dívida anterior em `phpcs-baseline.json`, derivada exclusivamente da fonte 1.9.2. O gate compara regra, mensagem e tokens próximos ao achado, com contagem por arquivo: mover ou quebrar o mesmo comando em várias linhas não cria uma dívida nova; comandos adicionais precisam satisfazer o padrão. `style:full` mostra a dívida total, enquanto `style` recusa novos achados. Nunca regenere a baseline a partir da versão alterada para aprovar a entrega. Alterações na regra de comparação devem ser verificadas contra a fonte original e um caso com uma violação adicional.

## Limites e incidente de preparação

A primeira bancada foi criada inadvertidamente em WAL, padrão do drop-in. A verificação posterior encontrou corrupção estrutural em `wp_f3base_eventos`, herdada pelas primeiras cópias. Essas saídas foram retiradas da evidência de aprovação. Não foi demonstrada causalidade com uma alteração do plugin. A bancada foi reconstruída desde a instalação com DELETE; clones passaram a usar backup API e verificação de integridade antes/depois. Os gates finais precisam corresponder exclusivamente à bancada íntegra.

A bancada local não mede HTTPS real, a entrega recebida por fornecedores de anúncios, o estado da frota ou homologação remota. Os testes de navegador usam Chromium 153.0.8010.52 real; o executável é informado por `F3BASE_CHROMIUM`. `ux-110.cjs` verifica os formulários independentes, salvamento por seção, navegação por teclado, abas e atualização AJAX em 1440 e 390 pixels. Execute o servidor HTTP e o navegador no mesmo contexto de rede. As capturas representam o tema mínimo da bancada, não o layout de um site externo.

## Comparação de custo

`benchmark-acervo.php` prepara acervos sintéticos de 10, 100 e 1.000 posts/páginas por API WordPress. `benchmark-comparativo.json` registra a primeira comparação; `benchmark-compacto-final.json` repete os custos na fonte final. A comparação usa instalações novas de 1.9.2 e 1.10.0 com PHP/SQLite/Yoast/cache idênticos, três amostras por consulta e integridade antes/depois. O tamanho final de como-usar compacto é 7,69% do completo; o contrato compacto é cerca de 8,26%. O contrato completo cresceu com os novos campos; não se afirma redução geral de bytes. Consultas aquecidas do contrato passam de 60 (completo) para 48 (compacto), e como-usar de 12 para zero. Tempos desta bancada são observações locais, não garantias de latência.

`benchmark-operacao.php <classificacao|configuracao|tecnica|medicao|acessos|purgas_lote20>` mede as telas e um lote de vinte gravações efetivas, contando o hook real `wp_cache_cleared`. Leituras têm teto de zero purgas; um lote de vinte escritas tem teto de uma purga ao concluir. Para as telas, os limites declarados antes da execução são 500 consultas, 32 MiB de pico incremental e 2 segundos por render nesta bancada. Mediana de consultas acima de `baseline × 1,25 + 20` exige correção ou justificativa explícita. Dez caminhos observados devem preservar a classificação e crescer no máximo dez consultas entre acervos de 10 e 1.000 conteúdos. O relatório `benchmark-operacoes-antes-correcao.json` preserva os achados que motivaram a remoção da enumeração LLMS em estados, leituras agrupadas e a dispensa do carregamento de metadados/termos na classificação. O relatório sem o sufixo contém a execução final. Use `F3BASE_PROFILE_SQL=1` somente para diagnóstico: o rastreamento adiciona custo e não deve produzir o número de referência.

Na repetição final, `benchmark-operacoes.json` aprovou 64 verificações sem reajustar a régua: classificação manteve 16 consultas frias/zero aquecidas em todos os acervos; configurações 5/2; aba técnica 42/38; acessos 6/3. As leituras não purgaram cache e cada lote de vinte escritas gerou uma purga. O lote de escrita passou de cerca de 150 para 350 consultas: persistência condicional, auditoria e evidência de efeitos têm custo real e são preservadas. Nesta bancada isso ficou em aproximadamente 113–124 ms de mediana por vinte escritas; não se afirma aceleração da escrita.

## Pacote instalável, atualização e integridade

A referência 1.9.2 consumida pelo ensaio de atualização está preservada em `suite/referencias/releases/`, com hash e finalidade no manifesto. Ela é uma fixture de regressão; não deve substituir o instalador atual.

```bash
python3 suite/versao-110/verificar-zip.py \
  --template /bancada/template --zip dist/base-site-core-fator3-1.10.0.zip \
  --php "$(command -v php)" --wp-cli /cache/insumos/wp-cli.phar --saida /tmp/verificacao-zip-nova
bash suite/110/upgrade-zip.sh /cache/insumos \
  suite/referencias/releases/base-site-core-fator3-1.9.2.zip \
  dist/base-site-core-fator3-1.10.0.zip /tmp/upgrade-core-novo
python3 suite/testar-fontes.py
```

O verificador do ZIP cria clones separados e confere a integridade de cada banco. Ensaios HTTP, navegador, cron, recuperação e mutantes têm drivers específicos; consulte os respectivos registros de evidência. Os ZIPs de WordPress, Yoast, cache e SQLite e as ferramentas instaladas são insumos externos versionados, não cópias dentro do pacote de fontes.

## Duas sessões de acessos e mudança sazonal

`acessos-duas-telas.py --php /caminho/php --site /bancada/nova --zip /pacotes/base-site-core-fator3-1.10.0.zip --output /evidencias/acessos-duas-telas.json` inicia o servidor PHP com quatro workers e autentica duas sessões HTTP distintas. Uma barreira temporária da fixture segura a primeira requisição no filtro anterior à gravação do transient, enquanto o `flock` real continua adquirido; a segunda requisição precisa informar atualização em curso. Após liberar, ambas as sessões convergem para 20 acessos e, após acrescentar sete linhas, para 27. O teste verifica contador, offset, ausência de dados de hoje no histórico e integridade SQLite. A barreira fica exclusivamente no mu-plugin da bancada e é removida no encerramento. O mesmo roteiro verifica o parser real de arquivos nas transições históricas de 23 e 25 horas em America/New_York, sem alterar o relógio do sistema. Não representa execução de um navegador gráfico nem cron nas datas históricas.
