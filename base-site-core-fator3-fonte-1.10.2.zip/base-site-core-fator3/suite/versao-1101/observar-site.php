<?php
/** Homologação dirigida no WordPress carregado. Não altera conteúdo/preferências; atualiza a fotografia de hoje. */
function f3base1101_observar_site(string $backup): array {
 global $wpdb;
 if(!current_user_can('manage_options')){throw new RuntimeException('Permissão administrativa obrigatória.');}
 $out=array('plugin'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'estrutura_confirmada'=>F3Base_Atualizacao::pronta());
 $warnings=array(); $uid=get_current_user_id(); $get=$_GET;
 set_error_handler(static function($n,$m) use (&$warnings){if($n & (E_WARNING|E_NOTICE|E_USER_WARNING|E_USER_NOTICE)){$warnings[]=$m;}return false;});
 try {
  $server=rest_get_server(); $req=new WP_REST_Request('GET','/wp-abilities/v1/abilities/f3base/config-core-contrato-v1/run');$req->set_query_params(array('input'=>new stdClass()));
  $res=$server->dispatch($req);$data=$res->get_data();$schema=wp_get_ability('f3base/config-core-contrato-v1')->get_output_schema();
  $san=rest_sanitize_value_from_schema($data,$schema);$out['contrato_rest']=array('status'=>$res->get_status(),'ok'=>!empty($data['ok']),'opcoes'=>count($data['opcoes']??array()),'sanitizacao_ok'=>!is_wp_error($san),'segredo_mascarado'=>false);
  foreach($data['opcoes']??array() as $option){if('f3base_meta_capi_token'===($option['nome']??'')){$out['contrato_rest']['segredo_mascarado']=true===($option['valor']['mascarado']??false);}}
  wp_set_current_user(0);$anon=$server->dispatch($req);$out['contrato_rest']['anonimo_status']=$anon->get_status();wp_set_current_user($uid);
  require_once ABSPATH.'wp-admin/includes/template.php';
  foreach(array('saude','acessos','medicao','tela') as $f){$path=F3BASE_PLUGIN_DIR.'admin/class-f3base-admin-'.$f.'.php';if(is_file($path)){require_once $path;}}
  $telas=array('configuracao'=>array('F3Base_Admin_Tela',array('aba'=>'configuracoes')),'tecnica'=>array('F3Base_Admin_Tela',array('aba'=>'tecnica')),'medicao'=>array('F3Base_Admin_Medicao',array()),'acessos'=>array('F3Base_Admin_Medicao',array('aba'=>'acessos')));
  foreach($telas as $nome=>$spec){$_GET=$spec[1];ob_start();try{$spec[0]::render();$html=ob_get_contents();}finally{ob_end_clean();}$out['telas'][$nome]=array('bytes'=>strlen($html),'h1'=>str_contains($html,'<h1>'),'formularios'=>substr_count($html,'<form'),'sem_fatal'=>!str_contains($html,'Fatal error'));}
  $_GET=$get;
  $antes=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE dia=%s',$wpdb->prefix.'f3base_acessos',wp_date('Y-m-d')));
  $foto=F3Base_Acessos_Atuais::ler();$depois=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE dia=%s',$wpdb->prefix.'f3base_acessos',wp_date('Y-m-d')));
  $out['hoje']=array('dia'=>$foto['dia'],'erro'=>$foto['erro'],'bytes_lidos'=>$foto['bytes_lidos'],'bytes_pendentes'=>$foto['bytes_pendentes'],'grupos'=>count($foto['linhas']),'historico_antes'=>$antes,'historico_depois'=>$depois,'padrao_resolvido'=>F3Base_Modulo_Acessos_Servidor::resolver_padrao(F3Base_Modulo_Acessos_Servidor::config()['padrao_do_log']));
  $out['configuracoes_backup']=array('comparadas'=>0,'divergentes'=>array());$out['conteudo_backup']=array('comparadas'=>0,'divergentes'=>0);
  $operaveis=array_column($data['opcoes']??array(),'nome');
  $fp=gzopen($backup,'rb');if(!$fp){throw new RuntimeException('Cópia anterior indisponível.');}
  try {while(false!==($line=gzgets($fp))){$item=json_decode($line,true,512,JSON_THROW_ON_ERROR);if('row'!==($item['kind']??'')){continue;}$row=array();foreach($item['values_base64'] as $k=>$v){$row[$k]=null===$v?null:base64_decode($v,true);}
   if($item['table']===$wpdb->options && in_array($row['option_name'],$operaveis,true)){$atual_linha=$wpdb->get_row($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$row['option_name']),ARRAY_A);$atual=is_array($atual_linha)?$atual_linha['option_value']:null;$out['configuracoes_backup']['comparadas']++;if($atual!==$row['option_value']){$out['configuracoes_backup']['divergentes'][]=$row['option_name'];}}
   if($item['table']===$wpdb->posts){$atual=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE ID=%d',$wpdb->posts,(int)$row['ID']),ARRAY_A);$out['conteudo_backup']['comparadas']++;if($atual!==$row){$out['conteudo_backup']['divergentes']++;}}
  } if(!gzeof($fp)){throw new RuntimeException('Leitura de backup incompleta.');}}finally{gzclose($fp);}
  $out['warnings']=$warnings;
  $out['ok']=$out['estrutura_confirmada'] && 200===$out['contrato_rest']['status'] && $out['contrato_rest']['ok'] && $out['contrato_rest']['sanitizacao_ok'] && $out['contrato_rest']['segredo_mascarado'] && in_array($out['contrato_rest']['anonimo_status'],array(401,403),true) && ''===$foto['erro'] && 0===$antes && 0===$depois && !$out['configuracoes_backup']['divergentes'] && 0===$out['conteudo_backup']['divergentes'] && !$warnings;
  foreach($out['telas'] as $t){$out['ok']=$out['ok'] && $t['h1'] && $t['sem_fatal'];}
  return $out;
 }finally{wp_set_current_user($uid);$_GET=$get;restore_error_handler();}
}
