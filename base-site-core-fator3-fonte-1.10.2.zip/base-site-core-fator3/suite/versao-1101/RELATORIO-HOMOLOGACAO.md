# Base Site Core Fator3 1.10.1 — atualização e homologação

Concluída em 22/09/2026 no site https://fator3-teste-mcp-1.dreamhosters.com/.

O Core passou da versão 1.9.0 para 1.10.0. A homologação identificou uma falha na conversão de botões editoriais e um formulário interativo que impediam a entrega de `llms-full.txt`. O ajuste foi publicado e instalado como **1.10.1**. A instalação final está ativa e sua estrutura de dados foi confirmada.

## Correção aplicada

O conversor preserva texto e links armazenados dos blocos de botão, sem executar seus callbacks. Botões com bindings permanecem recusados. Formulários Contact Form 7 reconhecidos recebem uma nota explícita orientando o preenchimento na página original, sem execução do shortcode nem cópia de dados de formulário. Blocos dinâmicos desconhecidos, shortcodes arbitrários e combinações ambíguas continuam bloqueados como conversão incompleta.

A mesma correção atende ao full e às páginas Markdown. Apenas três arquivos funcionais mudaram frente ao ZIP 1.10.0: conversor, cabeçalho de versão e catálogo de mudanças. Não houve alteração de tema, conteúdo ou preferência para contornar a falha.

## Resultados observados

| Verificação | Resultado |
|---|---|
| Core e migração | 1.10.1 ativo; estrutura confirmada |
| Preferências persistidas | 24 comparadas com a cópia anterior, sem divergências |
| Conteúdos | 26 registros comparados integralmente, sem divergências |
| Contrato pela Abilities REST nativa | HTTP 200, 24 opções, schema sanitizado e segredo mascarado; acesso anônimo HTTP 401 |
| Avisos PHP na observação dirigida | Nenhum warning/notice capturado |
| Telas administrativas | Configuração, informações técnicas, medição e acessos renderizadas em PHP |
| Leitura do log de hoje | Sem erro; leitura incremental; zero bytes pendentes ao conferir; histórico de hoje permaneceu vazio |
| Coleta de logs fechados | Execução automática observada pelo WP-Cron; saldo de arquivos pendentes igual a zero na inspeção registrada; próxima coleta diária agendada |
| Robots | HTTP 200; conteúdo gerenciado confirmado; sitemap do Yoast presente |
| llms.txt | HTTP 200, 2.235 bytes |
| llms-full.txt | HTTP 200, 56.479 bytes; sem truncamento |
| Markdown de contato | HTTP 200, 5.463 bytes; nota do formulário presente |
| Sitemap do Yoast | HTTP 200 |
| Conversor | 11 verificações dirigidas aprovadas; nove conteúdos selecionados convertidos; nenhum callback/shortcode executado |
| Sintaxe PHP | 69 arquivos verificados, sem erro |
| Diagnóstico final | Nenhum módulo em estado degradado/falha; cabeçalhos públicos verificados |
| Ferramentas temporárias | Removidas ao concluir; diretório de MU-plugins sem esses arquivos |

O caminho resolvido dos logs usa o domínio sem `www` e a pasta real da hospedagem. A leitura de hoje continua separada do histórico de arquivos datados. As novas opções de consentimento e tempo ativo assumem os padrões compatíveis sem regravar as escolhas anteriores.

## Ambiente e limites

WordPress 7.1.1, PHP 8.3.30, MySQL 8.0.41 e Yoast 28.5. WP Super Cache está ausente e não foi instalado nesta atualização. Portanto, a homologação remota não comprova HIT desse provedor; sua convivência permanece coberta pela bancada local anterior.

A verificação das telas exercitou a renderização PHP no usuário administrativo; não foi uma sessão visual no navegador autenticado. As sondas públicas partiram do servidor pela URL HTTPS do site. O transporte nativo REST foi chamado pelo controller real, dentro da requisição administrativa. O debug.log não existe nesse ambiente; a afirmação de ausência de avisos limita-se aos avisos capturados nas operações testadas e às respostas observadas.

Não houve envio de conversões aos fornecedores, criação de leads de teste ou alteração de páginas para homologar. O cron foi observado funcionando; isso não comprova a existência de um agendador externo da hospedagem. O robots físico gerenciado recebe Cache-Control de 172.800 segundos do servidor, de modo que clientes podem manter uma cópia em cache. O plugin conserva a revalidação própria; a política HTTP estática da hospedagem não foi alterada.

As evidências locais completas da 1.10.0 permanecem nos fontes com o hash correspondente. Na 1.10.1 foram executadas as regressões dirigidas, a comparação das alterações, a sintaxe e a homologação descritas aqui; não se declara uma repetição integral da matriz anterior.

## Cópia de recuperação

Antes da primeira atualização foi criada uma cópia privada do banco, do código instalado e do robots físico em:

`/home/dh_n8gwyj/.f3base-recuperacao-96d06d1c7cda/20260922-120220-uyimDIdd/`

- `banco.ndjson.gz`: exportação consistente das 23 tabelas do site, com schema e valores em base64; SHA256 `567680be6a7238c027f2b84a137a10a4d45c1d2292aa304ac7f727acffba7c56`.
- `core-e-robots-antes.zip`: 64 arquivos do Core anterior e robots físico; SHA256 `243feaf06b352e3731c60dc51205eb0e2ba2dec16d6378e8de66439c20b661c0`.
- `manifesto.json`: contagens e identificação da cópia.

O diretório está fora da raiz pública, com permissão 0700, e os arquivos têm permissão 0600. A cópia foi lida para a comparação, mas não foi restaurada no site ativo. É uma cópia técnica para recuperação controlada, não um pacote de restauração automática da hospedagem. O retorno apenas do código a versões anteriores à 1.10 continua inadequado para os novos estados da fila; a recuperação preferencial é por código compatível.

## Arquivos da entrega

O instalador corresponde ao código aplicado ao site. Os fontes incluem os scripts, a documentação e as evidências da 1.10.1, além das referências anteriores identificadas. Consulte `suite/versao-1101/LEIA-ME.md` para reproduzir os testes.
