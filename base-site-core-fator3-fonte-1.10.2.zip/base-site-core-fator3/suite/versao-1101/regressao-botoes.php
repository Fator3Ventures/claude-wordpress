<?php
/** Regressão dirigida, sem gravar conteúdo ou preferências; requer WordPress carregado. */
function f3base1101_regressao_botoes(string $classe = 'F3Base_Llms_Conversor'): array {
 $resultados=array(); $executou=0;
 $registrado=WP_Block_Type_Registry::get_instance()->get_registered('core/button');
 $original=$registrado ? $registrado->render_callback : null;
 if ($registrado) {$registrado->render_callback=static function() use (&$executou) {$executou++;return 'CALLBACK_EXECUTADO';};}
 register_block_type('f3base1101/dinamico',array('render_callback'=>static function() use (&$executou) {$executou++;return 'CALLBACK_EXECUTADO';}));
 add_shortcode('f3base1101_probe',static function() use (&$executou) {$executou++;return 'SHORTCODE_EXECUTADO';});
 $base=home_url('/');
 $testar=static function(string $nome, bool $ok, array $erros=array()) use (&$resultados) {$resultados[]=array('teste'=>$nome,'ok'=>$ok,'erros'=>$erros);};
 try {
  $conteudo='<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contato/">Fale com a equipe</a></div><!-- /wp:button --></div><!-- /wp:buttons -->';
  $r=$classe::converter($conteudo,$base);
  $testar('botao_nativo_com_callback_preserva_texto_e_url',$r['completo'] && str_contains($r['texto'],'Fale com a equipe') && str_contains($r['texto'],home_url('/contato/')),$r['erros']);
  $r=$classe::converter('<!-- wp:button {"metadata":{"bindings":{"text":{"source":"core/post-meta","args":{"key":"titulo"}}}}} --><div class="wp-block-button"><a href="/contato/">Texto salvo</a></div><!-- /wp:button -->',$base);
  $testar('binding_recusado_sem_publicar_fotografia_desatualizada',!$r['completo'] && ''===$r['texto'] && in_array('bloco_vinculado_nao_convertido:core/button',$r['erros'],true),$r['erros']);
  $r=$classe::converter('<!-- wp:f3base1101/dinamico --><p>HTML antigo</p><!-- /wp:f3base1101/dinamico -->',$base);
  $testar('dinamico_desconhecido_continua_recusado',!$r['completo'] && ''===$r['texto'] && in_array('bloco_dinamico_nao_convertido:f3base1101/dinamico',$r['erros'],true),$r['erros']);
  $r=$classe::converter('<!-- wp:shortcode -->[f3base1101_probe]<!-- /wp:shortcode -->',$base);
  $testar('shortcode_continua_recusado',!$r['completo'] && ''===$r['texto'],$r['erros']);
  $r=$classe::converter('<!-- wp:f3base1101/estatico --><p>Texto editorial</p><!-- /wp:f3base1101/estatico -->',$base);
  $testar('estatico_desconhecido_preserva_aviso',$r['completo'] && str_contains($r['texto'],'Texto editorial') && !empty($r['avisos']),$r['erros']);
  $cf7_anterior=$GLOBALS['shortcode_tags']['contact-form-7']??null;
  add_shortcode('contact-form-7',static function() use (&$executou) {$executou++;return 'FORMULARIO_EXECUTADO';});
  try {
   $r=$classe::converter('<!-- wp:paragraph --><p>Entre em contato.</p><!-- /wp:paragraph --><!-- wp:shortcode -->[contact-form-7 id="24" title="Contato"]<!-- /wp:shortcode -->',$base);
   $testar('formulario_conhecido_referenciado_sem_executar',$r['completo'] && str_contains($r['texto'],'Entre em contato.') && str_contains($r['texto'],'Formulário interativo: consulte a página original') && in_array('formulario_interativo_referenciado:contact-form-7',$r['avisos'],true),$r['erros']);
   foreach (array('[contact-form-7 id="24"] Texto extra','[[contact-form-7 id="24"]]','[contact-form-7 id="24"][f3base1101_probe]','[contact-form-7]') as $i=>$entrada) {
    $r=$classe::converter('<!-- wp:shortcode -->'.$entrada.'<!-- /wp:shortcode -->',$base);
    $testar('formulario_misto_escapado_ou_invalido_recusado_'.$i,!$r['completo'] && ''===$r['texto'],$r['erros']);
   }
  } finally {if(null===$cf7_anterior){remove_shortcode('contact-form-7');}else{$GLOBALS['shortcode_tags']['contact-form-7']=$cf7_anterior;}}
  $testar('nenhum_callback_ou_shortcode_executado',0===$executou);
 } finally {
  if($registrado){$registrado->render_callback=$original;}
  unregister_block_type('f3base1101/dinamico'); remove_shortcode('f3base1101_probe');
 }
 return array('ok'=>!in_array(false,array_column($resultados,'ok'),true),'classe'=>$classe,'testes'=>$resultados,'executados'=>$executou);
}
