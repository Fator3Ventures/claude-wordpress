# Core 1.10.1 — correção encontrada na homologação remota

A versão 1.10.0 foi atualizada no site autorizado em 22/09/2026. A inspeção real encontrou resposta 503 no full: `core/button` possui HTML editorial persistido, embora o WordPress o registre com callback de renderização. A conversão também encontrava um formulário Contact Form 7 na página de contato.

A 1.10.1 altera somente o conversor, o cabeçalho da versão e o catálogo de mudanças. `core/buttons` e `core/button` usam seu HTML persistido sem executar callbacks. Um botão com bindings continua recusado. Um bloco de shortcode que contenha exclusivamente um formulário Contact Form 7 reconhecido, com ID e shortcode registrado, é representado pela nota visível “Formulário interativo: consulte a página original para preencher e enviar.” Nenhum campo ou ação do formulário é executado. Outros shortcodes e blocos dinâmicos continuam gerando conversão incompleta; não foram habilitados por aproximação.

O full preserva o corpo editorial e seus links; uma interface interativa não é convertida em texto editorial nem silenciosamente expandida. A mesma regra é usada pelas páginas Markdown. Não há mudança de schema ou de preferências nesta correção.

## Reproduzir os testes dirigidos

Com WordPress carregado e usuário administrativo, inclua `regressao-botoes.php` e execute `f3base1101_regressao_botoes()`. São 11 verificações: botão, bindings, dinâmica desconhecida, shortcode desconhecido, estático desconhecido, formulário conhecido, quatro entradas recusadas e ausência de execução de callbacks. Alterações dos registros de blocos/shortcodes são locais à requisição e restauradas em finally. Nenhum conteúdo ou opção é gravado.

`observar-site.php` oferece `f3base1101_observar_site($caminho_da_copia)`: renderiza as quatro telas administrativas em PHP, consulta o controller nativo de abilities, testa a recusa anônima, atualiza explicitamente a fotografia temporária de hoje e compara preferências e conteúdos com uma cópia anterior do banco em NDJSON/gzip. Não é ensaio visual de navegador. O formato da cópia contém registros `header`, `schema`, `row` com `values_base64`, e `footer`; valores nulos permanecem nulos. A cópia deve permanecer privada, fora da raiz pública.

Os testes foram chamados por abilities temporárias protegidas por `manage_options`. Esses arquivos foram removidos ao final; não integram o instalador. A fixture administrativa carrega `wp-admin/includes/template.php`; a comparação usa `get_row` para distinguir option_value vazio de opção ausente.

## Alcance das evidências

`suite/evidencias-1101` contém os resultados novos e os hashes. `suite/evidencias-110` conserva a homologação local anterior da 1.10.0, com seu próprio hash; não representa uma repetição integral da suíte na 1.10.1. O código de produção do patch foi comparado byte a byte com o instalador anterior, e os três arquivos alterados estão declarados. O pacote de fontes pode reconstruir o instalador com `python3 suite/testar-fontes.py`, usando PHP e Node disponíveis no PATH.

O ambiente remoto é WordPress 7.1.1, PHP 8.3.30, MySQL 8.0.41 e Yoast 28.5. WP Super Cache não está instalado nesse site e não foi acrescentado por esta atualização do Core. A integração com esse provedor tem a evidência local anterior; não há prova de HIT remoto desse provedor. Não foram enviados eventos a fornecedores de anúncios, alterados temas/conteúdos ou restaurado o banco do site ativo.
