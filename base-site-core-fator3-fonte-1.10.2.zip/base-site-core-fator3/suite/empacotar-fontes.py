#!/usr/bin/env python3
"""Distribuição reproduzível por caminhos explícitos, sem depender de Git ou resíduos.
Uso: python3 suite/empacotar-fontes.py [--saida ARQUIVO.zip]
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, re, tempfile, zipfile

ROOT=Path(__file__).resolve().parent.parent
MANIFEST='suite/fontes-inclusao.json'
EPOCH=(2020,1,1,0,0,0)
def digest(data):return hashlib.sha256(data).hexdigest()
def build(output=None):
 spec=json.loads((ROOT/MANIFEST).read_text())
 assert spec['formato']==1,'Formato de inclusão desconhecido.'
 version=re.search(r'Version:\s*(\S+)',(ROOT/'fontes/plugin/base-site-core-fator3.php').read_text()).group(1)
 paths=sorted(set(spec['arquivos']+[MANIFEST]))
 assert len(paths)==len(spec['arquivos'])+1,'Entradas repetidas ou manifesto incluído em si mesmo.'
 refs=json.loads((ROOT/'suite/referencias/releases/referencias.json').read_text())
 allowed_zips={'suite/referencias/releases/'+x['arquivo']:x for x in refs}
 fixtures=json.loads((ROOT/'suite/referencias/fixtures-binarios.json').read_text())
 allowed_zips.update({x['caminho']:x for x in fixtures})
 data={}
 for name in paths:
  p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and str(p)==name,name
  src=ROOT/name;assert src.is_file() and not src.is_symlink(),f'Arquivo ausente ou link: {name}'
  assert src.resolve().is_relative_to(ROOT.resolve()),f'Arquivo fora da fonte: {name}'
  assert '.git' not in p.parts and not name.endswith(('.bundle','.pyc')) and not name.startswith('dist/entregue/'),name
  if name.endswith('.zip'):assert name in allowed_zips,f'Instalador sem consumidor declarado: {name}'
  data[name]=src.read_bytes()
  if name in allowed_zips:assert digest(data[name])==allowed_zips[name]['sha256'],f'Referência alterada: {name}'
 # Fonte nova esquecida deve ser declarada; saídas de build não são entradas.
 for folder in ['fontes','suite']:
  for src in (ROOT/folder).rglob('*'):
   if not src.is_file() or '__pycache__' in src.parts or src.suffix in ['.pyc','.zip','.bundle'] or src==ROOT/'suite/rodada.json':continue
   assert str(src.relative_to(ROOT)) in data,f'Fonte sem inclusão explícita: {src.relative_to(ROOT)}'
 meta={'formato':1,'plugin':'base-site-core-fator3','versao':version,'instalador_reconstruivel':'base-site-core-fator3-'+version+'.zip','arquivos':[{'caminho':p,'bytes':len(b),'sha256':digest(b)} for p,b in data.items()]}
 data['dist/fontes-manifesto.json']=(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode()
 out=Path(output).resolve() if output else ROOT/'dist'/f'base-site-core-fator3-fonte-{version}.zip';out.parent.mkdir(parents=True,exist_ok=True)
 # Staging vazio impede herança de arquivos antigos, mesmo se dist/ acumular saídas.
 with tempfile.TemporaryDirectory(prefix='f3base-fontes-') as tmp:
  stage=Path(tmp)/'base-site-core-fator3';stage.mkdir()
  for name,content in data.items():
   dst=stage/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(content)
  packed=Path(tmp)/'fontes.zip'
  with zipfile.ZipFile(packed,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
   for name in sorted(data):
    entry=zipfile.ZipInfo('base-site-core-fator3/'+name,date_time=EPOCH);entry.create_system=3
    entry.external_attr=(0o100755 if name.endswith('.sh') else 0o100644)<<16;entry.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(entry,(stage/name).read_bytes(),compresslevel=9)
  # Detecta uma alteração concorrente das entradas antes da publicação.
  for name,content in data.items():
   if name!='dist/fontes-manifesto.json':assert (ROOT/name).read_bytes()==content,f'Entrada mudou durante o empacotamento: {name}'
  with tempfile.NamedTemporaryFile(dir=out.parent,prefix='.fontes-',delete=False) as target:target.write(packed.read_bytes());target_name=target.name
  os.replace(target_name,out)
 return {'arquivo':str(out),'versao':version,'arquivos':len(data),'bytes':out.stat().st_size,'sha256':digest(out.read_bytes())}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--saida');args=p.parse_args();print(json.dumps(build(args.saida),ensure_ascii=False))
