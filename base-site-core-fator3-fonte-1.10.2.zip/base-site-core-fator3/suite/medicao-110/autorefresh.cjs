/* Relógio e transporte determinísticos; executa o asset de produção. */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const fonte = fs.readFileSync(path.join(__dirname, '../../fontes/plugin/assets/js/medicao-acessos.js'), 'utf8');
function element(attrs = {}) { return Object.assign({handlers: {}, addEventListener(name, fn) { this.handlers[name] = fn; }}, attrs); }
function fixture() {
  const timers = new Map(); let seq = 0; const requests = [];
  const auto = element({checked: false}); const intervalo = element({value: '30'}); const status = element({textContent: ''});
  const form = element({dataset: {ajax: '/wp-admin/admin-ajax.php'}, elements: {dias: {value: '3'}, classificacao: {value: 'conteudo'}, mostrar_todos: {type: 'checkbox', checked: false}, incluir_erros: {type: 'checkbox', checked: false}, comparacao_hoje: {type: 'checkbox', checked: false}}});
  const csv = {elements: {dias: {}, classificacao: {}, mostrar_todos: {}, incluir_erros: {}, comparacao_hoje: {}}};
  const coleta = {elements: {dias: {}, classificacao: {}, mostrar_todos: {}, incluir_erros: {}, comparacao_hoje: {}}};
  let regions = [{scrollLeft: 54}], details = [{open: true}], html = '';
  const result = {querySelectorAll(type) { return type === 'details' ? details : regions; }, get innerHTML() { return html; }, set innerHTML(value) { html = value; regions = [{scrollLeft: 0}]; details = [{open: false}]; }};
  const els = {'f3base-acessos-filtros': form, 'f3base-acessos-auto': auto, 'f3base-acessos-intervalo': intervalo, 'f3base-acessos-status': status, 'f3base-acessos-resultado': result, 'f3base-acessos-csv': csv, 'f3base-acessos-coleta': coleta};
  const document = element({hidden: false, getElementById(name) { return els[name]; }});
  const window = {scrollX: 4, scrollY: 900, scrollTo(x, y) { this.scrollX = x; this.scrollY = y; }};
  const history = {replaceState(a, b, c) { this.url = c; }};
  const context = {document, window, history, location: {href: 'https://example.test/wp-admin/admin.php?page=f3base-medicao&aba=acessos'}, URL, Array, Date, Math, Number, AbortController,
    FormData: class { constructor() { this.values = {}; } set(k, v) { this.values[k] = v; } },
    setTimeout(fn, ms) { const id = ++seq; timers.set(id, {fn, ms}); return id; }, clearTimeout(id) { timers.delete(id); },
    fetch(url, options) { if (options.body.values.somente_preferencia) return Promise.resolve({ok: true}); return new Promise((resolve, reject) => requests.push({resolve, reject, options})); }
  };
  vm.runInNewContext(fonte, context);
  return {timers, requests, auto, intervalo, form, csv, coleta, document, result, window, status, history, run(ms) { const found = [...timers].find(([id, t]) => t.ms === ms); assert.ok(found, 'timer ' + ms); timers.delete(found[0]); found[1].fn(); }};
}
async function flush() { for (let i=0; i<12; i++) await Promise.resolve(); }
(async function () {
  const checks = {};
  const f = fixture(); assert.equal(f.timers.size, 0); checks.inicial_desligado = true;
  f.auto.checked = true; f.auto.handlers.change(); assert.equal([...f.timers.values()][0].ms, 30000); checks.intervalo30 = true;
  f.document.hidden = true; f.document.handlers.visibilitychange(); assert.equal(f.timers.size, 0); assert.match(f.status.textContent, /oculta/); checks.pausa_aba_oculta = true;
  f.document.hidden = false; f.document.handlers.visibilitychange(); f.run(30000); assert.equal(f.requests.length, 1);
  f.form.handlers.submit({preventDefault() {}}); assert.equal(f.requests.length, 1); checks.sem_solicitacoes_sobrepostas = true;
  f.requests[0].resolve({ok: true, json: () => Promise.resolve({success: true, data: {html: '<table>novo</table>', atualizado: 123, erro: ''}})}); await flush();
  assert.equal(f.result.innerHTML, '<table>novo</table>'); assert.equal(f.result.querySelectorAll('[role=region]')[0].scrollLeft, 54); assert.equal(f.result.querySelectorAll('details')[0].open, true); assert.equal(f.window.scrollY, 900); checks.preservacao_posicao = true;
  assert.match(f.history.url, /dias=3/); assert.equal(f.csv.elements.dias.value, '3'); checks.csv_e_url_preservam_filtros = true; assert.equal(f.coleta.elements.dias.value, '3'); assert.equal(f.coleta.elements.comparacao_hoje.value, '0'); checks.coleta_preserva_filtros = true;
  f.run(30000); f.requests[1].reject(new Error('offline')); await flush(); assert.ok([...f.timers.values()].some(t => t.ms === 60000)); checks.backoff_falha = true;
  f.intervalo.value = '15'; f.intervalo.handlers.change(); assert.ok([...f.timers.values()].some(t => t.ms === 15000)); checks.intervalo15 = true;
  f.intervalo.value = '60'; f.intervalo.handlers.change(); assert.ok([...f.timers.values()].some(t => t.ms === 60000)); checks.intervalo60 = true;
  f.auto.checked = false; f.auto.handlers.change(); assert.equal(f.timers.size, 0); checks.desligar_cancela_timer = true;
  process.stdout.write(JSON.stringify({ok:true,checks},null,2)+'\n');
})().catch(error => { console.error(error); process.exitCode=1; });
