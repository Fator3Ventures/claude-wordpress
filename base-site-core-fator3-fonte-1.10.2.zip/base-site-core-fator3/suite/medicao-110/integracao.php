<?php
/** Executar por wp eval-file em bancada isolada; altera exclusivamente fixtures locais. */
if ( ! defined( 'ABSPATH' ) || 'local' !== wp_get_environment_type() ) { throw new RuntimeException( 'Bancada local obrigatória.' ); }
wp_set_current_user( 1 );
$checks = array();
$ok = static function( bool $v, string $nome ) use ( &$checks ): void { $checks[ $nome ] = $v; if ( ! $v ) { throw new RuntimeException( $nome ); } };
$avisos = array();
set_error_handler( static function( $n, $m ) use ( &$avisos ) { if ( $n & ( E_WARNING | E_NOTICE | E_USER_WARNING | E_USER_NOTICE ) ) { $avisos[] = $m; } return false; } );
update_option( 'timezone_string', 'America/Sao_Paulo' );
$root = sys_get_temp_dir() . '/f3base-medicao-110-' . getmypid(); wp_mkdir_p( $root );
$fmt = static fn( string $data, string $hora, string $path = '/teste/', string $ua = 'Mozilla/5.0' ) => '127.0.0.1 - - [' . ( new DateTimeImmutable( $data . ' ' . $hora, new DateTimeZone( 'UTC' ) ) )->format( 'd/M/Y:H:i:s O' ) . '] "GET ' . $path . ' HTTP/1.1" 200 10 "-" "' . $ua . '"' . "\n";
$hoje = wp_date( 'Y-m-d' ); $d = new DateTimeImmutable( $hoje, wp_timezone() ); $datas = array();
for ( $i = 3; $i > 0; --$i ) { $dia = $d->modify( '-' . $i . ' days' )->format( 'Y-m-d' ); $datas[] = $dia; file_put_contents( $root . '/access.log.' . $dia, $fmt( $dia,'00:30:00' ) . $fmt( $dia,'20:00:00' ) ); }
file_put_contents( $root . '/access.log', $fmt( $hoje, '20:00:00' ) );
$c = F3Base_Modulo_Acessos_Servidor::config(); $c['padrao_do_log'] = $root . '/access.log.*'; $c['ligado'] = true; $c['padroes_hospedagem'] = array( 'DreamHost-Healthcheck/' );
$write = F3Base_Options::gravar( 'f3base_acessos', $c ); $ok( ! empty( $write['persisted'] ), 'config_aplicada' );
F3Base_Options::gravar( 'f3base_acessos_estado', array() );
$before = F3Base_Options::ler( 'f3base_acessos_estado' ); ( new F3Base_Modulo_Acessos_Servidor() )->inicializar(); $after = F3Base_Options::ler( 'f3base_acessos_estado' );
$ok( $before === $after && wp_next_scheduled( F3Base_Modulo_Acessos_Servidor::CONTINUAR ) > 0, 'init_apenas_agenda' );
$r = F3Base_Acessos_Coleta::executar(); $ok( empty( $r['erro'] ), 'coleta_sem_falha:' . ( $r['erro'] ?? '' ) );
global $wpdb; $t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
$contar = static fn( $dia ) => (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(contagem) FROM {$t} WHERE dia=%s", $dia ) );
$ok( 2 === $contar( $datas[1] ), 'dois_arquivos_contribuem_mesmo_dia' );
F3Base_Acessos_Coleta::executar(); $ok( 2 === $contar( $datas[1] ), 'reexecucao_idempotente' );
file_put_contents( $root . '/access.log.' . $datas[1], $fmt( $datas[1],'00:30:00' ) . $fmt( $datas[1],'20:00:00' ) . $fmt( $datas[1],'21:00:00' ) ); clearstatcache(); F3Base_Acessos_Coleta::executar();
$ok( 3 === $contar( $datas[1] ), 'alteracao_fonte_preserva_outra_contribuicao' );
$coverage = F3Base_Acessos_Coleta::cobertura( $datas[0], $hoje ); $estados = array_column( $coverage, 'estado', 'dia' );
$ok( 'completo' === $estados[ $datas[1] ] && 'parcial' === $estados[ $datas[2] ] && 'parcial' === $estados[ $hoje ], 'cobertura_exige_fontes_adjacentes' );
$ok( 'proprio' === F3Base_Modulo_Acessos_Servidor::agente( 'WordPress/6.9; ' . home_url() )[0], 'wordpress_proprio' );
$ok( 'wordpress-externo' === F3Base_Modulo_Acessos_Servidor::agente( 'WordPress/6.9; https://outro.example/' )[0], 'wordpress_externo' );
$ok( 'hospedagem' === F3Base_Modulo_Acessos_Servidor::agente( 'DreamHost-Healthcheck/1' )[0], 'hospedagem_literal' );
$ok( 'proprio' === F3Base_Modulo_Acessos_Servidor::agente( 'F3Base-Sonda/1.10.0 (+' . home_url() . '; publicacao)' )[0], 'sonda_propria' );
$live = F3Base_Acessos_Atuais::ler(); $ok( empty( $live['erro'] ) && 1 === array_sum( array_column( $live['linhas'], 'contagem' ) ), 'hoje_temporario' );
$live2 = F3Base_Acessos_Atuais::ler(); $ok( 0 === $live2['bytes_lidos'] && true === $live2['incremental'], 'hoje_sem_bytes_nao_reprocessa' );
$ok( 0 === $contar( $hoje ), 'hoje_nao_historico' );
$foto = F3Base_Acessos_Atuais::fotografia(); $ok( $foto['linhas'] === $live['linhas'], 'consulta_foto_nao_coleta' );
update_option( 'timezone_string', 'Pacific/Kiritimati' );
$deferir = $root . '/access.log.' . wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ); $dia = substr( basename( $deferir ), -10 ); file_put_contents( $deferir, $fmt( $dia, '23:00:00' ) ); clearstatcache();
$lido = F3Base_Acessos_Coleta::ler_arquivo( array( 'nome' => $deferir, 'tamanho' => filesize( $deferir ), 'mtime' => filemtime( $deferir ) ), array(), wp_date( 'Y-m-d' ) );
$ok( ! $lido['linhas'] && $lido['adiados'], 'arquivo_fechado_com_hoje_adiado' );
update_option( 'timezone_string', 'America/Sao_Paulo' );
F3Base_Modulo_Comportamento::criar_tabela();
$ag = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA; $ev = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA_EVENTOS; $wpdb->query( "DELETE FROM {$ag}" ); $wpdb->query( "DELETE FROM {$ev}" );
$origem = ( new DateTimeImmutable( $datas[1] . ' 23:59:59', wp_timezone() ) )->getTimestamp();
$eventos = array( array( 'metrica' => 'f3base_pagina', 'detalhe' => '', 'valor' => 0, 'ms' => 0 ), array( 'metrica' => 'f3base_pagina', 'detalhe' => '', 'valor' => 0, 'ms' => 2000 ) );
$distribuidos = F3Base_Modulo_Comportamento::distribuir_metricas( array( array( 'metrica' => 'f3base_pagina', 'detalhe' => '', 'contagem' => 2, 'soma' => 0 ) ), $eventos, array( 'segundo' => $origem ) );
$ok( count( $distribuidos ) === 2 && $distribuidos[0]['dia'] !== $distribuidos[1]['dia'], 'comportamento_reparte_virada_local' );
foreach ( $distribuidos as $m ) { $ok( F3Base_Modulo_Comportamento::somar( $m['dia'], '/teste/', $m['metrica'], $m['detalhe'], $m['contagem'], $m['soma'] ), 'agregado_calendario_' . $m['dia'] ); }
foreach ( $eventos as $i => $evm ) { $evm += array( 'visitante' => str_repeat( 'a',32 ), 'sessao' => str_repeat( 'b',32 ), 'caminho' => '/teste/', 'ocorrencia' => $i + 1 ); $ok( F3Base_Modulo_Comportamento::registrar_evento( $evm, array( 'segundo' => $origem, 'de' => 'visitante' ) ), 'evento_' . $i ); }
$post = wp_insert_post( array( 'post_type' => F3Base_Modulo_Endpoint_Leads::CPT, 'post_status' => 'private', 'post_title' => 'Fixture', 'post_content' => 'SEGREDO_NAO_EXPORTAR', 'post_date' => wp_date( 'Y-m-d H:i:s' ), 'post_date_gmt' => gmdate( 'Y-m-d H:i:s' ) ) );
foreach ( array( 'comportamento','eventos','leads' ) as $tipo ) {
	$a = wp_get_ability( 'f3base/' . $tipo . '-ler' ); $ok( (bool) $a, 'ability_registrada_' . $tipo ); $v = $a->execute( array( 'dias' => 7, 'limite' => 1 ) );
	$ok( ! is_wp_error( $v ), 'ability_executa_' . $tipo . ( is_wp_error( $v ) ? ':' . $v->get_error_message() : '' ) );
	$ok( false === strpos( wp_json_encode( $v ), 'SEGREDO_NAO_EXPORTAR' ), 'sem_corpo_' . $tipo );
	if ( 'eventos' === $tipo ) { $ok( 2 === $v['totais']['eventos'] && 1 === $v['totais']['visitantes'] && '' !== $v['proximo_cursor'], 'totais_janela_e_cursor' ); $v2 = $a->execute( array( 'dias' => 7, 'limite' => 1, 'cursor' => $v['proximo_cursor'] ) ); $ok( $v2['linhas'][0]['id'] !== $v['linhas'][0]['id'], 'cursor_nao_repete_eventos' ); }
}
wp_set_current_user( 0 ); $negado = F3Base_Medicao_Consultas::consultar( 'eventos' ); $ok( is_wp_error( $negado ), 'consulta_sem_permissao_recusada' ); wp_set_current_user( 1 );
$ok( "'=1+1" === F3Base_Acessos_Relatorio::celula_csv( '=1+1' ), 'csv_formula_neutralizada' );
$antes_options = $wpdb->get_results( "SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name", ARRAY_A );
foreach ( array( 'comportamento','eventos','leads' ) as $tipo ) { wp_get_ability( 'f3base/' . $tipo . '-ler' )->execute( array( 'dias' => 7 ) ); }
$depois_options = $wpdb->get_results( "SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name", ARRAY_A );
$ok( $antes_options === $depois_options, 'abilities_readonly_nao_gravam_options_ou_agenda' );
$comparacao = F3Base_Medicao_Consultas::comparar_comportamento( 1 ); $ok( 1 === $comparacao['dias_comparados'] && 1 === $comparacao['linhas'][0]['atual'] && 1 === $comparacao['linhas'][0]['anterior'], 'comparacao_pareia_posicao_dias' );
$conf = F3Base_Options::ler( 'f3base_comportamento' ); $conf['tempo_ativo'] = true; $ok( ! empty( F3Base_Options::gravar( 'f3base_comportamento', $conf )['persisted'] ), 'tempo_ativo_habilitado' );
$ativo = array( array( 'gatilho' => 'tempo-ativo','detalhe' => 'bloco','valor' => 1000,'ocorrencia' => 1,'ms' => 1200 ) );
$ok( empty( F3Base_Modulo_Comportamento::validar_eventos( $ativo,str_repeat( 'a',32 ),str_repeat( 'b',32 ),'/teste/' )['erro'] ), 'tempo_ativo_valido' );
$ativo[0]['valor'] = 30001; $ok( ! empty( F3Base_Modulo_Comportamento::validar_eventos( $ativo,str_repeat( 'a',32 ),str_repeat( 'b',32 ),'/teste/' )['erro'] ), 'tempo_ativo_excedente_recusado' );
$invalido = F3Base_Modulo_Comportamento::validar_metricas( array( array( 'gatilho' => 'tempo-ativo','detalhe' => 'bloco','contagem' => 1,'soma' => 30001 ) ) ); $ok( ! empty( $invalido['erro'] ), 'tempo_ativo_soma_excedente_recusada' );
$_GET = array( 'dias' => '3','aba' => 'acessos','mostrar_todos' => '1' ); ob_start(); F3Base_Admin_Acessos::render(); $html = ob_get_clean();
$ok( false !== strpos( $html,'Atualizar automaticamente' ) && false !== strpos( $html,'Hospedagem' ) && false !== strpos( $html,'Pessoas medidas' ) && false !== strpos( $html,'Coletar e Armazenar Logs' ), 'tela_acessos_conserva_colunas_e_controles' );
$ok( 1 === preg_match( '~value="30"\s+selected~', $html ) && false === strpos( $html,'id="f3base-acessos-auto" name="automatico" type="checkbox" value="1" checked' ), 'autorefresh_inicial_desligado30' );
$agregado_antes = $contar( $datas[1] ); $estado = F3Base_Options::ler( 'f3base_acessos_estado' ); $legado = $estado['dias'][ $datas[1] ];
unlink( $root . '/access.log.' . $datas[1] );
$c = F3Base_Modulo_Acessos_Servidor::config(); $c['padroes_hospedagem'][] = 'Monitor-Extra/'; F3Base_Options::gravar( 'f3base_acessos',$c ); F3Base_Acessos_Coleta::executar();
$ok( $agregado_antes === $contar( $datas[1] ), 'fonte_incompleta_preserva_legado' );
$cob = F3Base_Acessos_Coleta::cobertura( $datas[1],$datas[1] ); $ok( 'legado' === $cob[0]['estado'], 'legado_calendario_ou_regra_explicito' );
$ok( empty( $avisos ), 'sem_avisos:' . implode( '; ', $avisos ) );
restore_error_handler(); echo wp_json_encode( array( 'ok' => true, 'checks' => $checks ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
