<?php
/**
 * Sonda do CONTRATO DE NOMES do plugin, em subprocesso.
 *
 * O QUE SOBROU AO SAIR DO IMPLANTADOR, e a subtração é de posse. Esta sonda
 * media três checagens, e duas delas — `renomeacao.plugin_intacto` e
 * `renomeacao.secao_medida_apos_renomear` — mediam a FERRAMENTA DE RENOMEAÇÃO,
 * que é do implantador: elas copiam a árvore do pacote três vezes, chamam
 * `ferramentas/renomear-prefixo.php` e comparam o antes com o depois. A
 * ferramenta não existe aqui, e o invariante que ela precisa respeitar — não
 * tocar no plugin — só pode ser medido de onde ela roda.
 *
 * O QUE FICOU É A METADE DO PLUGIN: `renomeacao.contrato_de_nomes_completo`.
 * Ela não renomeia nada e não precisa da ferramenta — ela confere que
 * `fontes/plugin/dados/contrato-de-nomes.tsv` COBRE toda grafia que as
 * declarações do próprio plugin exigem: toda option do catálogo, todo evento
 * declarado e o prefixo de seção. Nada disso é lista escrita à mão dos dois
 * lados; o que o contrato precisa cobrir é LIDO do catálogo, da tabela de
 * eventos e da constante do módulo que publica o prefixo.
 *
 * POR QUE ISSO IMPORTA AQUI, mesmo sem ferramenta. O contrato é o que um
 * renomeador — este ou outro — precisa ler para não quebrar o site derivado: as
 * classes de seção são carimbadas pelo TEMA, que é renomeado, e procuradas pelo
 * coletor do PLUGIN, que não é. Grafia que o plugin exige e o contrato não
 * declara é a medição de seção morrendo calada em todo site renomeado. Publicar
 * o contrato completo é obrigação de quem publica o plugin.
 *
 * O PISO ESTÁ AQUI DENTRO: a MESMA função roda contra um contrato de onde uma
 * grafia exigida foi retirada, e precisa acusar.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );
$suite = dirname( __DIR__ );

require_once $suite . '/lib/regra.php';
require_once $suite . '/lib/empacotar.php';
require_once $suite . '/lib/documentos.php';


/**
 * O prefixo de seção que o PLUGIN publica ao navegador.
 *
 * @param string $raiz Raiz.
 * @return string
 */
function f3b_sr_prefixo_de_secao( string $raiz ): string {
	$fonte = (string) @file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-tracking.php' );

	return 1 === preg_match( "/const\s+PREFIXO_SECAO\s*=\s*'([^']+)'/", $fonte, $achou ) ? $achou[1] : '';
}

/**
 * As grafias declaradas no contrato de nomes do plugin.
 *
 * @param string $raiz Raiz.
 * @return array<int,string>
 */
function f3b_sr_contrato( string $raiz ): array {
	$saida = array();

	foreach ( explode( "\n", (string) @file_get_contents( $raiz . '/fontes/plugin/dados/contrato-de-nomes.tsv' ) ) as $linha ) {
		$linha = rtrim( $linha, "\r" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$colunas = explode( "\t", $linha );
		$grafia  = trim( $colunas[1] ?? '' );

		if ( '' !== $grafia ) {
			$saida[] = $grafia;
		}
	}

	return array_values( array_unique( $saida ) );
}

/**
 * O QUE O CONTRATO PRECISA COBRIR, lido das declarações que já existem.
 *
 * Nada aqui é escrito à mão: as options saem do catálogo do próprio plugin, os
 * eventos saem da declaração de comportamento e o prefixo de seção sai da
 * constante do módulo que o publica. É o que impede a tabela de envelhecer —
 * uma lista escrita à mão que ninguém confere fica para trás na primeira option
 * nova, e o defeito volta calado exatamente onde ele estava.
 *
 * @param string $raiz Raiz.
 * @return array<string,string> grafia => de onde ela veio.
 */
function f3b_sr_exigido_pelo_contrato( string $raiz ): array {
	$exigido = array();

	foreach ( f3b_catalogo_do_plugin( $raiz ) as $declaracao ) {
		$exigido[ $declaracao['nome'] ] = 'catálogo completo de options do plugin';
	}

	foreach ( explode( "\n", (string) @file_get_contents( $raiz . '/fontes/plugin/dados/eventos-comportamento.tsv' ) ) as $linha ) {
		$linha = rtrim( $linha, "\r" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$nome = trim( explode( "\t", $linha )[0] ?? '' );

		if ( '' !== $nome ) {
			$exigido[ $nome ] = 'declaração de eventos de comportamento';
		}
	}

	$prefixo = f3b_sr_prefixo_de_secao( $raiz );

	if ( '' !== $prefixo ) {
		$exigido[ $prefixo ] = 'constante PREFIXO_SECAO do módulo de tracking';
	}

	return $exigido;
}

/**
 * REGRA PURA: o que o contrato exige e não declara.
 *
 * @param array<string,string> $exigido  Grafia => origem.
 * @param array<int,string>    $contrato Grafias declaradas.
 * @return array<int,string>
 */
function f3b_sr_faltando( array $exigido, array $contrato ): array {
	$achados = array();

	foreach ( $exigido as $grafia => $origem ) {
		if ( ! in_array( (string) $grafia, $contrato, true ) ) {
			$achados[] = '"' . $grafia . '" vem de ' . $origem . ' e NÃO consta de fontes/plugin/dados/contrato-de-nomes.tsv: '
				. 'a renomeação de prefixo vai reescrevê-la do lado de quem grava e não do lado de quem lê, e o site fica com o implantador escrevendo '
				. 'um nome e o plugin lendo outro — sem erro nenhum';
		}
	}

	return $achados;
}

/* =========================================================================
 * EXECUÇÃO
 * ====================================================================== */

$veredito = array(
	'renomeacao.contrato_de_nomes_completo' => array( 'achados' => array(), 'medidas' => 0 ),
);

/* ---- O CONTRATO COBRE O QUE AS DECLARAÇÕES EXIGEM ---- */
$exigido  = f3b_sr_exigido_pelo_contrato( $raiz );
$contrato = f3b_sr_contrato( $raiz );

$veredito['renomeacao.contrato_de_nomes_completo']['medidas'] = count( $exigido );

if ( array() === $exigido ) {
	$veredito['renomeacao.contrato_de_nomes_completo']['achados'][] = 'não foi possível ler nem o catálogo de options nem a declaração de eventos do plugin: '
		. 'sem elas esta linha não tem contra o que conferir o contrato, e escopo vazio não pode aprovar';
} else {
	/*
	 * TETO: sobre o contrato REAL, a regra tem de ficar em silêncio. O rótulo do
	 * ramo entra no achado porque ele é o que separa esta chamada da de baixo —
	 * as duas rodam a MESMA função, e sem o rótulo o log não diria qual delas
	 * falou.
	 */
	foreach ( f3b_sr_faltando( $exigido, $contrato ) as $achado ) {
		$veredito['renomeacao.contrato_de_nomes_completo']['achados'][] = 'teto: ' . $achado;
	}

	/* PISO: a MESMA função, contra um contrato de onde uma grafia foi tirada. */
	$mutilado = array_values( array_diff( $contrato, array( (string) array_key_first( $exigido ) ) ) );

	if ( array() === f3b_sr_faltando( $exigido, $mutilado ) ) {
		$veredito['renomeacao.contrato_de_nomes_completo']['achados'][] = 'piso cego: removida do contrato a grafia "' . (string) array_key_first( $exigido )
			. '", que o catálogo exige, a regra continuou em silêncio';
	}

	++$veredito['renomeacao.contrato_de_nomes_completo']['medidas'];
}

echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
