<?php
/**
 * Sonda do ARTEFATO em subprocesso: o que viaja dentro do zip do plugin.
 *
 * DUAS AFIRMAÇÕES, e as duas só podem ser medidas no artefato montado — não na
 * árvore de origem, que tem tudo, e não no código do empacotamento, que descreve
 * a intenção. O que se publica é o zip.
 *
 * 1. `pacote.plugin_completo_no_zip` — o zip do plugin contém TODO arquivo que a
 *    lista de autoload dele exige. Um arquivo esquecido na montagem não aparece
 *    como erro de build: aparece como erro fatal no `require_once` da ativação,
 *    no site do cliente.
 * 2. `pacote.instrucoes_do_plugin_no_zip` — o documento de instruções viaja
 *    dentro do zip, não traz número digitado fora dos blocos gerados, e descreve
 *    TODO módulo que existe em `includes/`. As duas primeiras cláusulas guardam
 *    o artefato entregue; a terceira é a que impede o documento de envelhecer,
 *    porque as tabelas dele são geradas e a prosa não.
 *
 * O QUE SAIU COM O IMPLANTADOR. `pacote.plugin_so_como_zip` e
 * `pacote.reserva_identica_ao_avulso` mediam o BUNDLE dele — a fonte do plugin
 * não viajar dentro do bundle, e a reserva embutida ser byte a byte o avulso.
 * Não há bundle aqui, e as duas afirmações são sobre o pacote que EMBUTE este
 * artefato, não sobre o artefato. Com elas saiu também a condição de abortar
 * quando o bundle não é encontrado: neste repositório o que precisa existir é o
 * zip do plugin, e é a ausência DELE que aborta.
 *
 * O PISO DAS DUAS É A LISTA MUTANTE. As regras são funções puras sobre a lista
 * de entradas do zip, e o piso passa a elas a lista com o defeito plantado: um
 * arquivo do autoload a menos, o documento a menos, um número digitado a mais.
 * É a única forma honesta aqui — plantar o defeito no build de verdade
 * significaria montar um segundo zip defeituoso a cada rodada, e o defeito está
 * na LISTA, não no zip.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/*
 * A REGRA COMPARTILHADA É IMPORTADA, e não reimplementada: `f3b_arquivos()` e
 * companhia são de lá.
 *
 * O EMPACOTAMENTO VOLTOU, e a volta tem uma razão de objeto. Ao sair do
 * implantador esta sonda perdeu a checagem da reserva embutida — que é sobre o
 * bundle DELE — e, junto com ela, a única leitora da época declarada do zip.
 * O que ficou órfão não foi a checagem: foi a AFIRMAÇÃO de que o zip é
 * reprodutível, que continuou valendo, continuou sendo o contrato que o
 * catálogo publica, e passou a não ter ninguém medindo. `faketime` seguiu como
 * pré-condição declarada do comando único sem nenhuma linha que o usasse.
 * `pacote.zip_reprodutivel` é essa linha, e ela precisa da época declarada e da
 * remontagem — as duas moram aqui.
 */
require_once __DIR__ . '/regra.php';
require_once __DIR__ . '/empacotar.php';

$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );
$suite = dirname( __DIR__ );

/**
 * Apaga uma árvore inteira, em PHP.
 *
 * Sem `rm -rf` montado em string: além de `estatica.detector_codigo_em_string`
 * acusar shell por concatenação — e acusar com razão —, um `rm -rf` cujo
 * argumento venha de uma variável é a linha em que um erro de escape apaga o
 * que ninguém pediu.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_sb_apagar( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	foreach ( (array) scandir( $dir ) as $nome ) {
		$nome = (string) $nome;

		if ( '.' === $nome || '..' === $nome ) {
			continue;
		}

		$alvo = $dir . '/' . $nome;

		if ( is_dir( $alvo ) && ! is_link( $alvo ) ) {
			f3b_sb_apagar( $alvo );
			continue;
		}

		unlink( $alvo );
	}

	rmdir( $dir );
}

/**
 * As entradas de um zip, pelo nome.
 *
 * @param string $zip Caminho do zip.
 * @return array<int,string>
 */
function f3b_sb_entradas( string $zip ): array {
	$saida  = array();
	$codigo = 0;
	exec( 'unzip -Z1 ' . escapeshellarg( $zip ) . ' 2>/dev/null', $saida, $codigo );

	if ( 0 !== $codigo ) {
		return array();
	}

	return array_values( array_filter( array_map( 'strval', $saida ) ) );
}

/**
 * REGRA PURA: todo arquivo do autoload do plugin está no zip dele.
 *
 * @param array<int,string> $entradas Entradas do zip do plugin.
 * @param array<int,string> $autoload Caminhos relativos exigidos pelo autoload.
 * @param string            $pasta    Nome da pasta raiz dentro do zip.
 * @return array<int,string>
 */
function f3b_sb_plugin_completo( array $entradas, array $autoload, string $pasta ): array {
	$achados = array();

	if ( array() === $autoload ) {
		return array( 'não foi possível ler a lista de autoload do plugin: sem ela esta checagem não mede nada, e uma checagem que não encontra o que mede não pode fechar OK' );
	}

	foreach ( $autoload as $rel ) {
		if ( ! in_array( $pasta . '/' . $rel, $entradas, true ) ) {
			$achados[] = $rel . ': está na lista de autoload do plugin e NÃO está dentro do zip. O plugin morre no require_once da ativação, no site do cliente, '
				. 'com erro fatal e sem nada no build tendo acusado. Cinco arquivos desta lista vêm de partilhado/ e só entram no zip pela cópia do empacotamento';
		}
	}

	return $achados;
}

/**
 * A lista de autoload declarada no arquivo principal do plugin.
 *
 * @param string $principal Caminho do arquivo principal.
 * @return array<int,string>
 */
function f3b_sb_autoload( string $principal ): array {
	if ( ! is_file( $principal ) ) {
		return array();
	}

	$fonte = (string) file_get_contents( $principal );
	$ini   = strpos( $fonte, '$arquivos = array(' );

	if ( false === $ini ) {
		return array();
	}

	$fim = strpos( $fonte, ');', $ini );

	if ( false === $fim ) {
		return array();
	}

	$bloco = substr( $fonte, $ini, $fim - $ini );
	$saida = array();

	if ( preg_match_all( "/'([^']+\.php)'/", $bloco, $achou ) ) {
		$saida = array_values( array_unique( $achou[1] ) );
	}

	return $saida;
}


/**
 * O nome do documento que viaja dentro do zip do plugin.
 *
 * Escrito uma vez e lido pelas três cláusulas: o nome do arquivo é a única
 * coisa que elas têm em comum, e repeti-lo faria uma delas continuar medindo o
 * arquivo antigo no dia em que ele fosse renomeado.
 */
const F3B_SB_INSTRUCOES = 'INSTRUCOES-DO-PLUGIN.md';

/**
 * REGRA PURA: o documento de instruções está dentro do zip do plugin.
 *
 * @param array<int,string> $entradas Entradas do zip do plugin.
 * @param string            $pasta    Nome da pasta raiz dentro do zip.
 * @return array<int,string>
 */
function f3b_sb_instrucoes_no_zip( array $entradas, string $pasta ): array {
	$achados = array();
	foreach ( $entradas as $entrada ) {
		if ( str_starts_with( $entrada, $pasta . '/' ) && ! f3b_arquivo_de_producao( substr( $entrada, strlen( $pasta ) + 1 ) ) ) { $achados[] = 'Documento ou manutenção presente no instalador: ' . $entrada; }
	}
	return $achados;
}

/**
 * A PROSA do documento: o que sobra fora das regiões geradas e dos blocos cercados.
 *
 * @param string $texto Documento inteiro.
 * @return string
 */
function f3b_sb_prosa( string $texto ): string {
	$prosa = (string) preg_replace( '/<!-- gerado:inicio=.*?-->.*?<!-- gerado:fim=.*?-->/s', '', $texto );

	return (string) preg_replace( '/```.*?```/s', '', $prosa );
}

/**
 * REGRA PURA: nenhum número DIGITADO À MÃO fora dos blocos gerados.
 *
 * O DEFEITO QUE ISTO IMPEDE é o mesmo que produziu `f3b_ck_carimbo_de_release_nos_documentos`,
 * um nível abaixo: contagem escrita em documento entregável está correta no dia em
 * que foi escrita e é contradita pela rodada seguinte, sem nada acusando. Aqui o
 * documento viaja DENTRO do artefato, e quem o lê não tem como conferir.
 *
 * TRÊS ISENÇÕES, e cada uma tem razão:
 *
 * 1. **Marcador de lista ordenada.** Ele é estrutura do markdown, não afirmação
 *    sobre o pacote — proibi-lo obrigaria a escrever procedimento em lista solta.
 * 2. **Dígito colado a letra**, direta ou por hífen ou sublinhado. Isso é NOME —
 *    o nome do artefato, o nome de uma tag de fornecedor, o nome de uma option.
 *    Nome não envelhece por contagem, e quem o renomeia é acusado por outros
 *    detectores.
 * 3. **Vão de código cujo conteúdo aparece VERBATIM na fonte do plugin.** É a
 *    isenção que carrega o peso: `8192` passa porque o teto está no código,
 *    `403` passa porque a rota o emite, e uma contagem de módulos escrita à mão
 *    NÃO passa, porque ela não é literal de lugar nenhum. É por isso que a
 *    isenção compara com a fonte, e não com uma lista escrita aqui: lista
 *    escrita aqui seria o número digitado voltando por outra porta.
 *
 * Bloco de código CERCADO fica de fora da varredura por inteiro, e o limite é
 * declarado: ali o número é argumento de consulta — um intervalo de dias, um
 * limite de linhas —, e não afirmação sobre este pacote.
 *
 * @param string $texto Documento inteiro.
 * @param string $fonte Fonte do plugin, concatenada.
 * @return array<int,string>
 */
function f3b_sb_numero_digitado( string $texto, string $fonte ): array {
	$achados = array();

	foreach ( preg_split( '/\R/', f3b_sb_prosa( $texto ) ) ?: array() as $n => $linha ) {
		$linha = (string) preg_replace( '/^(\s*)[0-9]+\.(\s)/', '$1$2', (string) $linha );

		$linha = (string) preg_replace_callback(
			'/`([^`]*)`/',
			static fn( array $achou ): string => str_contains( $fonte, (string) $achou[1] ) ? '' : (string) $achou[0],
			$linha
		);

		if ( ! preg_match_all( '/[0-9]+(?:[.,][0-9]+)*/', $linha, $numeros, PREG_OFFSET_CAPTURE ) ) {
			continue;
		}

		foreach ( $numeros[0] as $numero ) {
			$valor  = (string) $numero[0];
			$onde   = (int) $numero[1];
			$antes  = substr( $linha, max( 0, $onde - 2 ), min( 2, $onde ) );
			$depois = substr( $linha, $onde + strlen( $valor ), 2 );

			/* Dígito colado a letra, direta ou por hífen/sublinhado, é NOME. */
			if ( 1 === preg_match( '/[A-Za-z][-_]?$/', $antes ) || 1 === preg_match( '/^[-_]?[A-Za-z]/', $depois ) ) {
				continue;
			}

			$achados[] = 'teto: linha ' . ( $n + 1 ) . ' do documento traz o número "' . $valor . '" digitado fora de bloco gerado: "'
				. trim( $linha ) . '". Número em documento entregável é GERADO por leitura de disco, nunca digitado — digitado, ele está certo '
				. 'no dia em que foi escrito e é contradito pela rodada seguinte, sem nada acusando. Se ele é um limite do código, escreva-o '
				. 'em vão de código com a mesma grafia que a fonte usa; se é uma contagem, ela pertence a um bloco gerado';
		}
	}

	return $achados;
}

/**
 * REGRA PURA: todo módulo que existe em `includes/` está DESCRITO no documento.
 *
 * ESTA É A CLÁUSULA QUE IMPEDE O DOCUMENTO DE ENVELHECER. As tabelas dele são
 * geradas e acompanham o código sozinhas; a PROSA não. Um módulo acrescentado
 * ao registro sem uma entrada escrita aqui entraria na tabela gerada e ficaria
 * sem a única coisa que a tabela não sabe dizer — a pergunta de negócio, quando
 * ele fica inativo, e o que quebra se alguém mexer nele errado.
 *
 * A busca é pelo NOME DA CLASSE e fora das regiões geradas, de propósito: a
 * classe é o que outro agente procura, e procurar dentro do bloco gerado
 * aprovaria o documento pela própria tabela que a geração acabou de escrever.
 *
 * @param string            $texto   Documento inteiro.
 * @param array<int,string> $classes Nomes de classe dos módulos existentes.
 * @return array<int,string>
 */
function f3b_sb_modulos_descritos( string $texto, array $classes ): array {
	if ( array() === $classes ) {
		return array( 'não foi possível ler nenhuma classe de módulo em includes/: sem escopo esta cláusula não mede nada, e escopo vazio não é aprovação' );
	}

	$prosa   = f3b_sb_prosa( $texto );
	$achados = array();

	foreach ( $classes as $classe ) {
		if ( str_contains( $prosa, $classe ) ) {
			continue;
		}

		$achados[] = 'teto: o módulo ' . $classe . ' existe em includes/ e NÃO está descrito na prosa de ' . F3B_SB_INSTRUCOES
			. '. As tabelas do documento são geradas e acompanham o código sozinhas; a prosa não — e é ela que diz a pergunta de negócio, '
			. 'quando o módulo fica inativo e o que quebra se alguém mexer nele errado. Sem esta linha o documento envelhece calado';
	}

	return $achados;
}

/**
 * As classes de módulo declaradas em `includes/`, por FORMA e não por prefixo.
 *
 * `class-*-modulo-<nome>.php` é módulo; `class-*-modulo.php` é o CONTRATO deles.
 * Nenhum prefixo é escrito aqui: esta sonda roda também contra pacotes já
 * renomeados, e a fonte do plugin não é renomeada.
 *
 * @param string $fonte_do_plugin Caminho da fonte do plugin.
 * @return array<int,string>
 */
function f3b_sb_classes_de_modulo( string $fonte_do_plugin ): array {
	$saida = array();

	foreach ( glob( $fonte_do_plugin . '/includes/class-*-modulo-*.php' ) ?: array() as $caminho ) {
		$codigo = (string) @file_get_contents( (string) $caminho );

		if ( 1 === preg_match( '/^\s*(?:final\s+)?class\s+([A-Za-z0-9_]+)/m', $codigo, $achou ) ) {
			$saida[] = (string) $achou[1];
		}
	}

	sort( $saida );

	return $saida;
}

/**
 * A fonte do plugin concatenada, sem o próprio documento.
 *
 * O documento é EXCLUÍDO de propósito: com ele dentro, todo número que ele
 * mesmo traz passaria a existir "na fonte", e a regra se autoaprovaria.
 *
 * @param string $raiz Raiz do pacote.
 * @return string
 */
function f3b_sb_fonte_concatenada( string $raiz ): string {
	$fonte = '';

	foreach ( array( '/fontes/plugin', '/partilhado' ) as $dir ) {
		if ( ! is_dir( $raiz . $dir ) ) {
			continue;
		}

		$iterador = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $raiz . $dir, FilesystemIterator::SKIP_DOTS )
		);

		foreach ( $iterador as $arquivo ) {
			if ( ! $arquivo->isFile() || F3B_SB_INSTRUCOES === $arquivo->getFilename() ) {
				continue;
			}

			$fonte .= (string) file_get_contents( $arquivo->getPathname() ) . "\n";
		}
	}

	return $fonte;
}

/**
 * REGRA PURA: toda entrada do zip está carimbada com a ÉPOCA DECLARADA.
 *
 * O DEFEITO MEDIDO, e ele foi medido com a árvore arquivada: até a 1.7.3 o
 * carimbo das entradas era o RELÓGIO arredondado ao dia, e a mesma árvore, byte
 * a byte idêntica, empacotada em dois dias, deu dois arquivos diferentes —
 * `693ca754…` num dia e `aeb40cad…` no outro, com `diff -r` limpo entre as duas
 * extrações.
 *
 * ISSO É MAIS GRAVE DO QUE "o hash não fecha duas vezes". Este zip é publicado
 * no catálogo e o implantador FIXA o digesto dele na primeira observação:
 * republicar amanhã um artefato de conteúdo idêntico, reconstruído da mesma
 * fonte, faria toda implantação seguinte falhar acusando troca de artefato que
 * não houve.
 *
 * @param array<int,string> $carimbos Carimbos lidos do zip.
 * @param string            $epoca    Época declarada, em `YYYY-MM-DD HH:MM`.
 * @return array<int,string>
 */
function f3b_sb_carimbos_na_epoca( array $carimbos, string $epoca ): array {
	if ( array() === $carimbos ) {
		return array( 'teto: nenhuma entrada do zip do plugin trouxe carimbo de tempo legível, e escopo vazio não aprova' );
	}

	$distintos = array_values( array_unique( $carimbos ) );
	$achados   = array();

	if ( count( $distintos ) > 1 ) {
		$achados[] = 'teto: as entradas do zip do plugin têm carimbos de tempo DIFERENTES (' . implode( ', ', array_slice( $distintos, 0, 5 ) )
			. '): o arquivo deixa de ser reprodutível e os bytes mudam a cada montagem sem que o conteúdo mude';
	}

	if ( 1 === count( $distintos ) && $epoca !== $distintos[0] ) {
		$achados[] = 'teto: o carimbo das entradas do zip do plugin é ' . $distintos[0] . ' e a época DECLARADA é ' . $epoca
			. ': este carimbo veio do RELÓGIO, e não da declaração. A mesma árvore empacotada em outro dia produz outros bytes, '
			. 'e o pacote passa a ter dois digestos LEGÍTIMOS para o MESMO conteúdo — com o digesto fixado no host na primeira '
			. 'observação, republicar o artefato reconstruído faz a implantação SEGUINTE falhar acusando troca que não houve';
	}

	return $achados;
}

/**
 * REGRA PURA: a ORDEM das entradas é a declarada, e não a do sistema de arquivos.
 *
 * O SEGUNDO DEFEITO DA MESMA FAMÍLIA. `zip -r` grava as entradas na ordem em
 * que o diretório as devolve, e essa ordem é do SISTEMA DE ARQUIVOS: no ext4
 * ela vem do hash do nome com a semente do volume, no tmpfs vem da ordem de
 * criação. Mesma árvore, MESMO dia, dois volumes da mesma máquina: `693ca754…`
 * num e `855fabbb…` no outro. Por isso a lista é montada pelo empacotamento,
 * ordenada por byte, e entregue ao `zip` por `-@`.
 *
 * @param array<int,string> $entradas Entradas do zip, na ordem em que ele as guarda.
 * @return array<int,string>
 */
function f3b_sb_ordem_declarada( array $entradas ): array {
	if ( array() === $entradas ) {
		return array( 'teto: o zip do plugin não trouxe entrada nenhuma para conferir a ordem, e escopo vazio não aprova' );
	}

	$ordenadas = $entradas;
	sort( $ordenadas, SORT_STRING );

	if ( $ordenadas === $entradas ) {
		return array();
	}

	$primeira = '';

	foreach ( $entradas as $i => $nome ) {
		if ( $nome !== $ordenadas[ $i ] ) {
			$primeira = 'na posição ' . $i . ' o zip guarda "' . $nome . '" e a ordem declarada põe "' . $ordenadas[ $i ] . '"';
			break;
		}
	}

	return array(
		'teto: as entradas do zip do plugin NÃO estão na ordem declarada (' . $primeira . '): a ordem está vindo do sistema '
			. 'de arquivos, e não do empacotamento. A mesma árvore montada noutro volume ou noutra máquina produz outros '
			. 'bytes com o mesmo conteúdo',
	);
}

/**
 * Lê `unzip -l` e devolve o carimbo de cada entrada, em `YYYY-MM-DD HH:MM`.
 *
 * @param string $zip Caminho do zip.
 * @return array<int,string>
 */
function f3b_sb_carimbos_de( string $zip ): array {
	$listagem = array();
	$codigo   = 0;

	exec( sprintf( 'TZ=UTC unzip -l %s 2>&1', escapeshellarg( $zip ) ), $listagem, $codigo );

	$carimbos = array();

	foreach ( $listagem as $linha ) {
		if ( 1 === preg_match( '/^\s*\d+\s+([\d-]{8,10})\s+(\d\d:\d\d)\s+\S/', (string) $linha, $ms ) ) {
			$carimbos[] = (string) $ms[1] . ' ' . (string) $ms[2];
		}
	}

	return $carimbos;
}

/**
 * Monta o zip do plugin num subprocesso, com o RELÓGIO e o VOLUME escolhidos.
 *
 * As duas alavancas só existem de FORA do processo: o relógio se move
 * envolvendo o processo em `faketime`, e o volume se move apontando a saída
 * para outro sistema de arquivos. Um piso que chamasse a função no mesmo
 * processo provaria que uma função pura devolve o mesmo valor para o mesmo
 * argumento — verdade por construção, e que não diz nada sobre o artefato.
 *
 * @param string $lib  Diretório com `empacotar.php` (o do pacote, ou o do mutante).
 * @param string $raiz Raiz de onde as fontes do plugin saem.
 * @param string $dist Diretório de saída — é ele que escolhe o VOLUME.
 * @param string $dia  Instante para o `faketime`.
 * @return array{ok:bool,sha256:string,erro:string}
 */
function f3b_sb_montar_com_relogio( string $lib, string $raiz, string $dist, string $dia ): array {
	$saida  = array();
	$codigo = 0;

	exec(
		sprintf(
			'faketime %s php %s %s %s %s 2>&1',
			escapeshellarg( $dia ),
			escapeshellarg( __DIR__ . '/sonda-montagem.php' ),
			escapeshellarg( $lib ),
			escapeshellarg( $raiz ),
			escapeshellarg( $dist )
		),
		$saida,
		$codigo
	);

	/*
	 * A SAÍDA É GARIMPADA, e não lida pela primeira linha: o `faketime` escreve
	 * avisos próprios em stdout, e um piso que lesse a linha zero confundiria um
	 * aviso com falha de montagem — alarme falso por barulho do instrumento.
	 */
	$linhas = array_values( array_filter( array_map( 'trim', array_map( 'strval', $saida ) ), static fn( string $l ): bool => '' !== $l ) );
	$sha    = '';

	foreach ( $linhas as $linha ) {
		if ( 1 === preg_match( '/^[0-9a-f]{64}$/', $linha ) ) {
			$sha = $linha;
		}
	}

	if ( 0 !== $codigo || '' === $sha ) {
		return array( 'ok' => false, 'sha256' => '', 'erro' => implode( ' | ', array_slice( $linhas, 0, 2 ) ) );
	}

	return array( 'ok' => true, 'sha256' => $sha, 'erro' => '' );
}

/**
 * O MUTANTE: uma cópia do empacotamento com UMA linha trocada.
 *
 * A cópia é do arquivo REAL — o mutante não pode ser uma reescrita, senão o
 * piso mede um empacotamento que não é o do pacote. Os irmãos que
 * `empacotar.php` resolve por `__DIR__` viajam junto, pelo mesmo motivo.
 *
 * @param string $raiz Raiz do pacote.
 * @param string $onde Diretório temporário a preparar.
 * @param string $de   Trecho a trocar dentro de `empacotar.php`.
 * @param string $para Trecho que entra no lugar.
 * @return string Diretório com o `empacotar.php` mutante, ou vazio quando o trecho não foi achado uma única vez.
 */
function f3b_sb_mutante( string $raiz, string $onde, string $de, string $para ): string {
	if ( ! is_dir( $onde ) && ! mkdir( $onde, 0755, true ) && ! is_dir( $onde ) ) {
		return '';
	}

	foreach ( array( 'regra.php', 'tokenizador-js.php' ) as $irmao ) {
		copy( $raiz . '/suite/lib/' . $irmao, $onde . '/' . $irmao );
	}

	$assets = dirname( $onde ) . '/build-assets';
	if ( ! is_dir( $assets ) ) { mkdir( $assets, 0755, true ); }
	foreach ( array( 'build.cjs', 'package.json', 'package-lock.json' ) as $arquivo ) { copy( $raiz . '/suite/build-assets/' . $arquivo, $assets . '/' . $arquivo ); }

	$fonte = (string) file_get_contents( $raiz . '/suite/lib/empacotar.php' );

	if ( 1 !== substr_count( $fonte, $de ) ) {
		return '';
	}

	file_put_contents( $onde . '/empacotar.php', str_replace( $de, $para, $fonte ) );

	return $onde;
}

/**
 * Um diretório num VOLUME diferente do da árvore, ou vazio quando não há.
 *
 * @param string $raiz Raiz do pacote, para comparar o dispositivo.
 * @return string
 */
function f3b_sb_outro_volume( string $raiz ): string {
	$daqui = stat( $raiz );

	if ( ! is_array( $daqui ) ) {
		return '';
	}

	foreach ( array( '/dev/shm', '/run/shm', sys_get_temp_dir() ) as $candidato ) {
		if ( ! is_dir( $candidato ) || ! is_writable( $candidato ) ) {
			continue;
		}

		$la = stat( $candidato );

		if ( is_array( $la ) && $la['dev'] !== $daqui['dev'] ) {
			return $candidato;
		}
	}

	return '';
}

$veredito = array(
	'pacote.plugin_completo_no_zip'      => array( 'achados' => array(), 'medidas' => 0 ),
	'pacote.instrucoes_do_plugin_no_zip' => array( 'achados' => array(), 'medidas' => 0 ),
	'pacote.zip_reprodutivel'            => array( 'achados' => array(), 'medidas' => 0 ),
);

$avulso = f3b_zip_atual( $raiz );

if ( '' === $avulso || ! is_file( $avulso ) ) {
	foreach ( array_keys( $veredito ) as $nome ) {
		$veredito[ $nome ]['achados'][] = 'o zip do plugin não foi encontrado em dist/base-site-core-fator3-*.zip: '
			. 'esta sonda mede o ARTEFATO montado, e sem artefato não há o que medir';
	}

	echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	exit( 0 );
}

$do_zip = f3b_sb_entradas( $avulso );

/* ---- 1. o zip do plugin está completo ---- */
$autoload = f3b_sb_autoload( $raiz . '/fontes/plugin/base-site-core-fator3.php' );

$veredito['pacote.plugin_completo_no_zip']['medidas'] = count( $autoload );
$veredito['pacote.plugin_completo_no_zip']['achados'] = f3b_sb_plugin_completo( $do_zip, $autoload, 'base-site-core-fator3' );

/* PISO: tirar do zip UM arquivo que o autoload exige. */
if ( array() !== $autoload ) {
	$mutilado = array_values( array_diff( $do_zip, array( 'base-site-core-fator3/' . $autoload[0] ) ) );

	if ( array() === f3b_sb_plugin_completo( $mutilado, $autoload, 'base-site-core-fator3' ) ) {
		$veredito['pacote.plugin_completo_no_zip']['achados'][] = 'piso cego: removida do zip a entrada ' . $autoload[0] . ', que o autoload exige, a regra continuou em silêncio';
	}

	if ( array() === f3b_sb_plugin_completo( $do_zip, array(), 'base-site-core-fator3' ) ) {
		$veredito['pacote.plugin_completo_no_zip']['achados'][] = 'piso cego: com a lista de autoload vazia a regra continuou em silêncio, e escopo vazio não pode aprovar';
	}

	$veredito['pacote.plugin_completo_no_zip']['medidas'] += 2;
}

/* ---- 4. o documento de instruções viaja, não traz número digitado e cobre todo módulo ---- */
$fonte_do_plugin = $raiz . '/fontes/plugin';
$documento       = $fonte_do_plugin . '/' . F3B_SB_INSTRUCOES;
$texto_do_doc    = is_file( $documento ) ? (string) file_get_contents( $documento ) : '';
$classes         = f3b_sb_classes_de_modulo( $fonte_do_plugin );
$fonte_do_zip    = f3b_sb_fonte_concatenada( $raiz );

$veredito['pacote.instrucoes_do_plugin_no_zip']['medidas'] = 1 + count( $classes );
$veredito['pacote.instrucoes_do_plugin_no_zip']['achados'] = array_merge(
	f3b_sb_instrucoes_no_zip( $do_zip, 'base-site-core-fator3' ),
	f3b_sb_numero_digitado( $texto_do_doc, $fonte_do_zip ),
	f3b_sb_modulos_descritos( $texto_do_doc, $classes )
);

if ( '' === $texto_do_doc ) {
	$veredito['pacote.instrucoes_do_plugin_no_zip']['achados'][] = 'teto: ' . F3B_SB_INSTRUCOES
		. ' não existe na fonte do plugin: não há documento para conferir, e ausência de escopo não é aprovação';
}

/*
 * PISO: as MESMAS funções puras, contra entradas com o defeito plantado. Uma
 * regra que nunca foi chamada sobre o defeito que ela existe para acusar é uma
 * afirmação sobre a intenção de quem a escreveu.
 */
$com_documento = array_merge( $do_zip, array( 'base-site-core-fator3/' . F3B_SB_INSTRUCOES ) );

if ( array() === f3b_sb_instrucoes_no_zip( $com_documento, 'base-site-core-fator3' ) ) {
	$veredito['pacote.instrucoes_do_plugin_no_zip']['achados'][] = 'piso cego: recolocado no instalador o documento de instruções, a regra continuou em silêncio';
}

/*
 * O NÚMERO PLANTADO É UMA CONTAGEM EM PROSA, que é exatamente a forma que
 * envelhece: uma frase afirmando quantos módulos existem, escrita num dia e
 * contradita na release seguinte.
 */
if ( array() === f3b_sb_numero_digitado( $texto_do_doc . "\n\nO plugin tem 42 módulos.\n", $fonte_do_zip ) ) {
	$veredito['pacote.instrucoes_do_plugin_no_zip']['achados'][] = 'piso cego: com uma contagem digitada em prosa acrescentada ao documento, a regra continuou em silêncio';
}

/*
 * E O NÚMERO PLANTADO DENTRO DE VÃO DE CÓDIGO, que é a forma pela qual a
 * isenção poderia ser contornada: só passa o que a fonte do plugin tem.
 */
if ( array() === f3b_sb_numero_digitado( $texto_do_doc . "\n\nO teto é de `987654321` linhas.\n", $fonte_do_zip ) ) {
	$veredito['pacote.instrucoes_do_plugin_no_zip']['achados'][] = 'piso cego: com um número que a fonte do plugin não tem escrito em vão de código, a regra continuou em silêncio';
}

if ( array() === f3b_sb_modulos_descritos( $texto_do_doc, array_merge( $classes, array( 'F3Base_Modulo_Que_Ninguem_Descreveu' ) ) ) ) {
	$veredito['pacote.instrucoes_do_plugin_no_zip']['achados'][] = 'piso cego: com um módulo a mais no escopo e nenhuma entrada para ele no documento, a regra continuou em silêncio';
}

if ( array() === f3b_sb_modulos_descritos( $texto_do_doc, array() ) ) {
	$veredito['pacote.instrucoes_do_plugin_no_zip']['achados'][] = 'piso cego: com a lista de módulos vazia a regra continuou em silêncio, e escopo vazio não pode aprovar';
}

$veredito['pacote.instrucoes_do_plugin_no_zip']['medidas'] += 5;

/* ---- 3. o zip é REPRODUTÍVEL: mesma árvore, mesmos bytes ---- */

/*
 * TETO — duas afirmações sobre o ARTEFATO montado, e as duas saem dele, não do
 * código que o montou: o carimbo de cada entrada é a ÉPOCA DECLARADA — a mesma
 * função que o empacotamento chama — e a ordem das entradas é a declarada.
 */
$epoca_declarada = gmdate( 'Y-m-d H:i', (int) strtotime( f3b_epoca_do_zip() ) );

$veredito['pacote.zip_reprodutivel']['medidas'] = 2;
$veredito['pacote.zip_reprodutivel']['achados'] = array_merge(
	f3b_sb_carimbos_na_epoca( f3b_sb_carimbos_de( $avulso ), $epoca_declarada ),
	f3b_sb_ordem_declarada( $do_zip )
);

/* PISO das duas regras puras: as listas mutantes, e a lista vazia. */
$veredito['pacote.zip_reprodutivel']['medidas'] += 4;

if ( array() === f3b_sb_carimbos_na_epoca( array( $epoca_declarada, $epoca_declarada, '2026-09-05 17:42' ), $epoca_declarada ) ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'piso cego: com uma entrada carimbada fora da época declarada, a regra do carimbo continuou em silêncio';
}

if ( array() === f3b_sb_carimbos_na_epoca( array(), $epoca_declarada ) ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'piso cego: com a lista de carimbos vazia a regra do carimbo aprovou, e escopo vazio não pode aprovar';
}

if ( array() === f3b_sb_ordem_declarada( array( 'b/', 'a.txt' ) ) ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'piso cego: com as entradas fora da ordem declarada, a regra da ordem continuou em silêncio';
}

if ( array() === f3b_sb_ordem_declarada( array() ) ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'piso cego: com a lista de entradas vazia a regra da ordem aprovou, e escopo vazio não pode aprovar';
}

/*
 * O PISO QUE MOVE O MUNDO EM VOLTA DO BUILD.
 *
 * As regras acima são puras, e o piso delas é uma lista mutante: isso prova que
 * elas sabem reprovar, e NÃO prova que o empacotamento sabe montar. Esta parte
 * mede o objeto — o empacotamento REAL, rodado de novo, com o RELÓGIO movido de
 * verdade e com o VOLUME trocado —, e é ela que sustenta a frase que o
 * `MANIFESTO.md` declara como contrato: duas montagens sobre a mesma árvore dão
 * o mesmo `sha256`, e hash diferente sobre árvore idêntica é adulteração.
 */
$trabalho = sys_get_temp_dir() . '/f3b-repro-' . getmypid();

f3b_sb_apagar( $trabalho );

$lib_do_pacote = $raiz . '/suite/lib';

/* Dois dias, o mesmo volume: os bytes têm de ser os mesmos. */
$veredito['pacote.zip_reprodutivel']['medidas'] += 1;

$dia_a = f3b_sb_montar_com_relogio( $lib_do_pacote, $raiz, $trabalho . '/dia-a', '2026-09-05 11:00:00' );
$dia_b = f3b_sb_montar_com_relogio( $lib_do_pacote, $raiz, $trabalho . '/dia-b', '2029-02-17 23:58:00' );

if ( ! $dia_a['ok'] || ! $dia_b['ok'] ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'o piso da reprodutibilidade não pôde montar o plugin com o relógio movido: '
		. ( '' !== $dia_a['erro'] ? $dia_a['erro'] : $dia_b['erro'] )
		. '. Sem as duas montagens não há piso, e piso ausente não aprova';
} elseif ( $dia_a['sha256'] !== $dia_b['sha256'] ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'teto: a MESMA árvore empacotada em dois dias deu bytes diferentes ('
		. substr( $dia_a['sha256'], 0, 12 ) . '… e ' . substr( $dia_b['sha256'], 0, 12 ) . '…): o carimbo voltou a sair do relógio, '
		. 'o pacote passa a ter dois digestos legítimos para o mesmo conteúdo e a implantação seguinte falha acusando troca de artefato que não houve';
}

/* Outro volume, o mesmo dia: os bytes têm de ser os mesmos. */
$veredito['pacote.zip_reprodutivel']['medidas'] += 1;
$outro_volume = f3b_sb_outro_volume( $raiz );

if ( '' === $outro_volume ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'esta máquina não tem um segundo sistema de arquivos gravável (procurados: /dev/shm, /run/shm, '
		. sys_get_temp_dir() . '): a metade do piso que mede a ORDEM das entradas entre volumes NÃO rodou, e ela é a que acusa a ordem vinda do readdir';
} else {
	$noutro = f3b_sb_montar_com_relogio( $lib_do_pacote, $raiz, $outro_volume . '/f3b-repro-' . getmypid(), '2026-09-05 11:00:00' );

	if ( ! $noutro['ok'] ) {
		$veredito['pacote.zip_reprodutivel']['achados'][] = 'o piso da reprodutibilidade não pôde montar o plugin no outro volume (' . $outro_volume . '): ' . $noutro['erro'];
	} elseif ( $dia_a['ok'] && $noutro['sha256'] !== $dia_a['sha256'] ) {
		$veredito['pacote.zip_reprodutivel']['achados'][] = 'teto: a MESMA árvore empacotada em outro volume (' . $outro_volume . ') deu bytes diferentes ('
			. substr( $dia_a['sha256'], 0, 12 ) . '… e ' . substr( $noutro['sha256'], 0, 12 ) . '…): a ORDEM das entradas voltou a vir do sistema de arquivos, '
			. 'e a mesma árvore montada noutra máquina passa a produzir outro digesto com o mesmo conteúdo';
	}

	f3b_sb_apagar( $outro_volume . '/f3b-repro-' . getmypid() );
}

/*
 * MUTANTE — o carimbo volta ao relógio. É a linha que o implantador tinha até a
 * 1.7.3, e o que ela produzia está medido. Com ela de volta, as duas montagens
 * PRECISAM divergir e a comparação PRECISA acusá-las: um piso em que o mutante
 * também passa mede o instrumento, e não o objeto.
 */
$veredito['pacote.zip_reprodutivel']['medidas'] += 1;

$mutante = f3b_sb_mutante(
	$raiz,
	$trabalho . '/mutante-relogio',
	'escapeshellarg( f3b_epoca_do_zip() )',
	"escapeshellarg( gmdate( 'Y-m-d', (int) ( floor( time() / 86400 ) * 86400 ) ) . ' 00:00:00 UTC' )"
);

if ( '' === $mutante ) {
	$veredito['pacote.zip_reprodutivel']['achados'][] = 'o mutante do carimbo não pôde ser preparado: a chamada da época declarada não foi encontrada '
		. 'uma única vez em suite/lib/empacotar.php, e sem o mutante o piso não prova que a alavanca do relógio tem dente';
} else {
	$mut_a = f3b_sb_montar_com_relogio( $mutante, $raiz, $trabalho . '/mut-dia-a', '2026-09-05 11:00:00' );
	$mut_b = f3b_sb_montar_com_relogio( $mutante, $raiz, $trabalho . '/mut-dia-b', '2029-02-17 23:58:00' );

	if ( ! $mut_a['ok'] || ! $mut_b['ok'] ) {
		$veredito['pacote.zip_reprodutivel']['achados'][] = 'o mutante do carimbo não pôde ser montado: '
			. ( '' !== $mut_a['erro'] ? $mut_a['erro'] : $mut_b['erro'] );
	} elseif ( $mut_a['sha256'] === $mut_b['sha256'] ) {
		$veredito['pacote.zip_reprodutivel']['achados'][] = 'piso cego: com o carimbo de volta ao relógio, as duas montagens em dias diferentes '
			. 'continuaram dando os mesmos bytes. A alavanca do relógio não move nada nesta bancada, e a comparação acima não prova coisa nenhuma';
	}
}

f3b_sb_apagar( $trabalho );

echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
