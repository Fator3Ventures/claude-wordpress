#!/usr/bin/env python3
"""Uma invocação HTTP real de wp-cron.php em clone SQLite isolado, sem cron remoto."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sqlite3
import subprocess
import time
import urllib.request

p = argparse.ArgumentParser()
p.add_argument('--php', required=True)
p.add_argument('--template', required=True, type=Path)
p.add_argument('--site', required=True, type=Path)
p.add_argument('--port', type=int, default=18117)
p.add_argument('--report', type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parents[2]
site = a.site.resolve()
subprocess.run(['python3', str(root/'suite/versao-110/clonar-bancada.py'), str(a.template), str(site)], check=True, capture_output=True)
shutil.copytree(root/'fontes/plugin', site/'wp-content/plugins/base-site-core-fator3', dirs_exist_ok=True)
config = site/'wp-content/wp-cache-config.php'
with config.open('a') as f:
    f.write('\n$wpsc_save_headers = 1;\n')
# Only the exact local fixture origin is admitted by the safe HTTP transport.
# Observer records outcomes without replacing HTTP responses or calling task hooks.
mu = site/'wp-content/mu-plugins/cron-real-observador.php'
mu.write_text('''<?php
add_filter('http_request_host_is_external',static fn($external,$host)=>'127.0.0.1'===$host?true:$external,10,2);
add_filter('http_allowed_safe_ports',static function($ports){$ports[]=(int)getenv('F3BASE_BANCADA_PORTA');return $ports;});
add_action('http_api_debug',static function($response,$context,$class,$args,$url){
 if('response'!==$context || !str_starts_with($url,home_url('/')))return;
 $v=['em'=>time(),'origem_cron'=>wp_doing_cron(),'caminho'=>wp_parse_url($url,PHP_URL_PATH),'status'=>is_wp_error($response)?0:wp_remote_retrieve_response_code($response),'erro'=>is_wp_error($response)?$response->get_error_code():'','ua'=>substr((string)($args['user-agent']??''),0,160)];
 file_put_contents(ABSPATH.'fixture-cron-http.jsonl',wp_json_encode($v)."\\n",FILE_APPEND|LOCK_EX);
},10,5);
add_action('shutdown',static function(){if(wp_doing_cron())file_put_contents(ABSPATH.'fixture-cron-execucao.jsonl',wp_json_encode(['em'=>time(),'doing_cron'=>true,'sapi'=>PHP_SAPI,'uri'=>wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH),'perfil_cache_http'=>F3Base_Cache_Pagina::perfil()])."\\n",FILE_APPEND|LOCK_EX);});
''')
env = os.environ | {'F3BASE_SITE': str(site), 'F3BASE_DOCROOT': str(site), 'F3BASE_BANCADA_PORTA': str(a.port), 'PHP_CLI_SERVER_WORKERS': '4'}
def worker(mode):
    r = subprocess.run([a.php, str(root/'suite/110/cron-real-worker.php'), mode], env=env, text=True, capture_output=True, timeout=45)
    assert r.returncode == 0 and not r.stderr.strip(), (mode, r.returncode, r.stdout, r.stderr)
    return json.loads(r.stdout)
base = f'http://127.0.0.1:{a.port}'
def http(path):
    with urllib.request.urlopen(base+path, timeout=55) as r:
        body = r.read()
        return {'status': r.status, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(), 'headers': dict(r.headers), 'body': body}
def lines(name):
    path = site/name
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []
report = {}
log = (site/'fixture-cron-servidor.log').open('w')
server = subprocess.Popen([a.php, '-S', f'127.0.0.1:{a.port}', '-t', str(site), str(root/'suite/bancada-wp/roteador.php')], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
try:
    for _ in range(80):
        try:
            http('/wp-includes/images/blank.gif')
            break
        except Exception:
            assert server.poll() is None, 'Servidor PHP encerrado'
            time.sleep(.1)
    prepared = worker('preparar')
    # Warm anonymous home through the real provider. This does not run cron.
    http('/'); http('/')
    scheduled = worker('agendar')
    before = worker('inspecionar')
    assert before['contagens'] == {'ontem': 0, 'hoje': 0}, before
    start = int(time.time())
    fired = http('/wp-cron.php')
    assert fired['status'] == 200 and fired['bytes'] == 0, fired
    after = worker('inspecionar')
    public_robots = http('/robots.txt')
    cron_http = [r for r in lines('fixture-cron-http.jsonl') if r['origem_cron'] and r['em'] >= start]
    real_cron = lines('fixture-cron-execucao.jsonl')
    assert after['contagens'] == {'ontem': 3, 'hoje': 0}, after
    assert not after['acessos'].get('erro') and after['acessos']['ultima_soma'] >= start, after
    assert len(real_cron) == 1 and real_cron[0]['uri'] == '/wp-cron.php', real_cron
    assert real_cron[0]['perfil_cache_http']['ativo'] and real_cron[0]['perfil_cache_http']['modo'] == 'wp-cache-cabecalhos', real_cron
    assert after['robots']['ok'] and after['robots']['codigo'] == 200 and after['robots']['verificado_em'] >= start, after['robots']
    assert public_robots['status'] == 200 and public_robots['sha256'] == after['robots']['recebido_sha256'] == after['robots']['esperado_sha256'], public_robots
    proof = after['cache']['ultima_tentativa']
    assert proof['origem'] == 'cron' and proof['checked_at'] >= start and proof['persisted'] and proof['concluido_em'] >= proof['iniciado_em'], proof
    assert proof['codigo'] in ('cabecalhos_comprovados','hit_nao_comprovado'), proof
    assert not proof.get('faltantes'), proof
    assert any(r['caminho'] == '/robots.txt' and r['status'] == 200 and '; robots)' in r['ua'] for r in cron_http), cron_http
    assert sum(r['caminho'] == '/' and r['status'] == 200 and '; cache)' in r['ua'] for r in cron_http) >= 2, cron_http
    for name in ('acessos','robots','cache'):
        run = after['agenda'][name]['ultima_execucao']
        assert run['origem'] == 'wp-cron' and run['inicio'] >= start and run['fim'] >= run['inicio'], (name,run)
        success = after['agenda'][name]['ultimo_sucesso']
        assert success['origem'] == 'wp-cron' and success['fim'] >= start and success['escopo'] in ('coleta_fechada_confirmada','robots_http_confirmado','cache_http_confirmado'), (name,success)
        assert after['agenda'][name]['proxima_execucao'] > start, (name,after['agenda'][name])
    assert after['disable_wp_cron'] is True
    assert after['coleta_diaria']['quando'] > start and after['coleta_diaria']['recorrencia'] == 'daily' and after['coleta_diaria']['intervalo'] == 86400, after['coleta_diaria']
    with sqlite3.connect(site/'wp-content/database/.ht.sqlite') as db:
        integrity = [r[0] for r in db.execute('PRAGMA integrity_check')]
        journal = db.execute('PRAGMA journal_mode').fetchone()[0]
    assert integrity == ['ok'] and journal == 'delete'
    runtime = site/'wp-content/plugins/base-site-core-fator3'
    manifest = {str(f.relative_to(runtime)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(runtime.rglob('*')) if f.is_file()}
    report = {'ok':True, 'executado_em_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'metodo':'Uma chamada HTTP real a /wp-cron.php; nenhum do_action ou callback de tarefa chamado pela fixture.', 'executor':'DISABLE_WP_CRON=true; disparo manual local que reproduz o executor da hospedagem, sem agendador externo criado.', 'fixture':prepared, 'eventos_vencidos':scheduled, 'inicio':start, 'cron_http':{'status':fired['status'],'bytes':fired['bytes']}, 'execucao_real':real_cron, 'antes_contagens':before['contagens'], 'depois':after, 'http_observado_do_cron':cron_http, 'robots_http':{k:v for k,v in public_robots.items() if k!='body'}, 'sqlite':{'journal_mode':journal,'integrity_check':integrity}, 'fontes_sha256':manifest, 'limitacoes':'Servidor PHP local com WP Super Cache e Yoast reais. O perfil HTTP foi registrado no próprio wp-cron; o perfil de inspeção CLI pode desligar o cache. A prova informa HIT apenas se comprovado; não certifica CDN nem executor remoto de produção.'}
finally:
    os.killpg(server.pid, signal.SIGTERM)
    server.wait(timeout=10)
    log.close()
if a.report:
    a.report.parent.mkdir(parents=True,exist_ok=True)
    a.report.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
