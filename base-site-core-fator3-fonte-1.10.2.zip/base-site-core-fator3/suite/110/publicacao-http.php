<?php
/** Regressão HTTP local: executar com servidor da bancada no mesmo namespace de rede. */
declare( strict_types = 1 );
$site = getenv( 'F3BASE_SITE' );
if ( ! $site || ! is_file( $site . '/.f3base-bancada-110' ) ) { exit( 2 ); }
require $site . '/wp-load.php';
wp_set_current_user( 1 );
function phttp_exigir( bool $ok, string $mensagem ): void { if ( ! $ok ) { throw new RuntimeException( $mensagem ); } }
function phttp_get( string $caminho, array $args = array() ) { return wp_remote_get( home_url( $caminho ), array_merge( array( 'timeout' => 8, 'redirection' => 0 ), $args ) ); }
function phttp_reset_sonda(): void { $f = F3Base_Options::fotografia( F3Base_Publicacao_Sonda::OPTION ); $v = $f['valor']; $v['last_attempt'] = 0; $v['lease'] = array(); F3Base_Options::gravar( F3Base_Publicacao_Sonda::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] ); }
$cfg = F3Base_Options::ler( 'f3base_llms' ); $seo = get_option( 'wpseo', array() ); $ids = array(); $artefato = '';
try {
	$novo_seo = $seo; $novo_seo['enable_llms_txt'] = false; update_option( 'wpseo', $novo_seo );
	$idref = wp_insert_post( array( 'post_type' => 'wp_block', 'post_status' => 'publish', 'post_title' => 'RefHTTP', 'post_content' => '<!-- wp:paragraph --><p>REFERENCIA PUBLICA</p><!-- /wp:paragraph -->' ) ); $ids[] = $idref;
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'f3p-http-editorial', 'post_title' => 'EditorialHTTP', 'post_content' => '<!-- wp:table --><figure><table><tr><th>A</th><th>B</th></tr><tr><td>Um</td><td>Dois</td></tr></table></figure><!-- /wp:table --><!-- wp:block {"ref":' . $idref . '} /-->' ) ); $ids[] = $id;
	update_post_meta( $id, F3Base_Chaves_Seo::NOINDEX, '2' );
	$c = array_replace( $cfg, array( 'ligado' => true, 'full' => true, 'markdown' => true, 'modo' => 'curada', 'politica_privacidade' => array(), 'livres' => array( array( 'id' => $id, 'url' => get_permalink( $id ), 'titulo' => 'EditorialHTTP' ) ) ) );
	phttp_exigir( ! empty( F3Base_Options::gravar( 'f3base_llms', $c )['persisted'] ), 'Configuração não gravada.' );
	$r = phttp_get( '/llms-full.txt' );
	phttp_exigir( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) && str_contains( wp_remote_retrieve_body( $r ), 'REFERENCIA PUBLICA' ) && str_contains( wp_remote_retrieve_body( $r ), '| --- | --- |' ), 'Full HTTP não preservou tabela/referência: ' . wp_json_encode( $r ) );
	$etag = wp_remote_retrieve_header( $r, 'etag' );
	$head = wp_remote_head( home_url( '/llms-full.txt' ) );
	phttp_exigir( 200 === wp_remote_retrieve_response_code( $head ) && '' === wp_remote_retrieve_body( $head ), 'HEAD não respeita representação sem corpo.' );
	$condicional = phttp_get( '/llms-full.txt', array( 'headers' => array( 'If-None-Match' => $etag ) ) );
	phttp_exigir( 304 === wp_remote_retrieve_response_code( $condicional ) && '' === wp_remote_retrieve_body( $condicional ), 'Revalidação ETag não retorna 304.' );
	echo wp_json_encode( array( 'teste' => 'F06_full_HTTP_tabela_referencia_HEAD_ETag_304', 'ok' => true ) ) . "\n";
	wp_update_post( array( 'ID' => $idref, 'post_status' => 'private', 'post_content' => 'REFERENCIA PRIVADA' ) );
	$r = phttp_get( '/llms-full.txt' );
	phttp_exigir( 200 === wp_remote_retrieve_response_code( $r ) && ! str_contains( wp_remote_retrieve_body( $r ), 'REFERENCIA PRIVADA' ) && ! str_contains( wp_remote_retrieve_body( $r ), 'REFERENCIA PUBLICA' ), 'Cache vazou referência que perdeu visibilidade.' );
	echo wp_json_encode( array( 'teste' => 'C04_referencia_privada_invalida_full_HTTP', 'ok' => true ) ) . "\n";
	wp_update_post( array( 'ID' => $id, 'post_content' => '<!-- wp:latest-posts /-->' ) );
	$r = phttp_get( '/llms-full.txt' );
	phttp_exigir( 503 === wp_remote_retrieve_response_code( $r ) && 'incompleta' === wp_remote_retrieve_header( $r, 'x-f3base-conversao' ), 'Bloco dinâmico foi publicado como full completo.' );
	echo wp_json_encode( array( 'teste' => 'F06_full_HTTP_incompleto_503', 'ok' => true ) ) . "\n";
	phttp_reset_sonda(); $robots = F3Base_Llms::arquivo_publico( 'robots.txt' ); $sha = $robots ? hash_file( 'sha256', $robots ) : '';
	$r = F3Base_Publicacao_Sonda::verificar( array( 'caminho' => '/robots.txt', 'metodo' => 'GET', 'assercoes' => array( array( 'tipo' => 'status', 'valor' => 200 ) ) ) );
	$apos = F3Base_Llms::arquivo_publico( 'robots.txt' );
	phttp_exigir( ! is_wp_error( $r ) && ! empty( $r['persisted'] ) && ( $apos ? hash_file( 'sha256', $apos ) : '' ) === $sha, 'Inspeção alterou robots ou não gravou evidência.' );
	echo wp_json_encode( array( 'teste' => 'F05_sonda_robots_HTTP_sem_reconciliar_arquivo', 'ok' => true, 'status_http' => $r['status'] ) ) . "\n";
	// Perfil declarado da fixture: WPSC carregado, cache de cabeçalhos, sem supercache.
	$GLOBALS['cache_enabled'] = true; $GLOBALS['super_cache_enabled'] = false; $GLOBALS['wpsc_save_headers'] = 1;
	$host = (string) wp_parse_url( home_url(), PHP_URL_HOST ); $rel = 'f3p-http-editorial/index.html';
	$artefato = WP_CONTENT_DIR . '/cache/supercache/' . $host . '/' . $rel;
	if ( ! is_dir( dirname( $artefato ) ) ) { mkdir( dirname( $artefato ), 0700, true ); }
	phttp_exigir( ! file_exists( $artefato ), 'Fixture de cache já existe.' ); file_put_contents( $artefato, 'TESTE PUBLICO SEM DADOS PRIVADOS' );
	phttp_reset_sonda(); $r = F3Base_Publicacao_Sonda::verificar( array( 'cache_artefato' => $rel, 'corpo' => true ) );
	phttp_exigir( ! is_wp_error( $r ) && 'protegido' === $r['cache_expectativa'] && 'reprovado' === $r['cache_exposicao'] && ! isset( $r['corpo'] ), 'Cache existente não foi diagnosticado contra perfil ou corpo vazou: ' . wp_json_encode( $r ) );
	unlink( $artefato ); $artefato = '';
	phttp_exigir( ! F3Base_Publicacao_Sonda::resolver_cache( $rel )['ok'], 'Artefato inexistente confirmou proteção.' );
	echo wp_json_encode( array( 'teste' => 'N08_cache_HTTP_existente_exposto_no_perfil_headers', 'ok' => true ) ) . "\n";
} catch ( Throwable $erro ) { fwrite( STDERR, $erro->getMessage() . "\n" ); $falhou = true; }
finally {
	if ( $artefato && is_file( $artefato ) ) { unlink( $artefato ); }
	foreach ( $ids as $id ) { wp_delete_post( $id, true ); }
	F3Base_Options::gravar( 'f3base_llms', $cfg ); update_option( 'wpseo', $seo );
}
exit( ! empty( $falhou ) ? 1 : 0 );
