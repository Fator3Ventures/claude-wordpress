<?php
/** Revisão negativa do executor; executar somente no WordPress isolado de bancada. */
if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) { exit( 1 ); }
wp_set_current_user( 1 );
$testes = array(); $anotar = static function ( $id, $ok, $r = null ) use ( &$testes ) { $testes[] = array( 'id' => $id, 'ok' => (bool) $ok, 'evidencia' => $r ); };
$original = F3Base_Options::ler( F3Base_Operacao::OPTION );
$hook = 'f3base_acessos_continuar'; $chamadas = 0;
F3Base_Operacao::callback( $hook, static function () use ( &$chamadas ) { ++$chamadas; return array( 'ok' => true ); } );
$negada = F3Base_Operacao::executar_pendentes( array( 'tarefas' => array( 'hook_inventado_por_cliente' ) ) );
$anotar( 'tarefa_arbitraria_recusada', ! $negada['ok'] && 0 === $chamadas );
$ate = time() + 60;
F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function () use ( $ate ) { return array( 'acessos' => array( 'lease' => array( 'id' => 'dono-anterior', 'ate' => $ate ) ), 'capi' => array( 'lease' => array( 'id' => 'outra-tarefa', 'ate' => $ate ) ) ); } );
wp_clear_scheduled_hook( $hook );
$r = F3Base_Operacao::executar_uma( 'acessos', 'wp-cron', false, $hook );
$estado = F3Base_Options::ler( F3Base_Operacao::OPTION );
$anotar( 'recusa_lease_nao_apaga_reservas', ! $r['ok'] && 0 === $chamadas && 'dono-anterior' === ( $estado['acessos']['lease']['id'] ?? '' ) && 'outra-tarefa' === ( $estado['capi']['lease']['id'] ?? '' ), $r );
$anotar( 'cron_consumido_lease_ocupado_reagenda', wp_next_scheduled( $hook ) >= $ate, array( 'proxima' => wp_next_scheduled( $hook ), 'lease_ate' => $ate ) );
F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function () { return array(); } );
wp_clear_scheduled_hook( $hook ); wp_schedule_single_event( time() - 10, $hook );
F3Base_Operacao::callback( $hook, static function () use ( &$chamadas ) { ++$chamadas; throw new RuntimeException( 'falha-fixture' ); } );
$r = F3Base_Operacao::executar_uma( 'acessos', 'executor_externo', true, $hook );
$anotar( 'excecao_nao_perde_evento_unico', ! $r['ok'] && $chamadas > 0 && wp_next_scheduled( $hook ) > time(), $r );
wp_clear_scheduled_hook( $hook ); wp_schedule_single_event( time() - 10, $hook );
$antes = $chamadas;
$recusa = static function ( $pre, $timestamp, $nome ) use ( $hook ) { return $nome === $hook ? new WP_Error( 'recusa_fixture', 'Não remover evento.' ) : $pre; };
add_filter( 'pre_unschedule_event', $recusa, 10, 3 );
$r = F3Base_Operacao::executar_uma( 'acessos', 'executor_externo', true, $hook );
remove_filter( 'pre_unschedule_event', $recusa, 10 );
$anotar( 'recusa_consumo_nao_executa_nem_perde', ! $r['ok'] && $antes === $chamadas && wp_next_scheduled( $hook ), $r );
// Processo substituído não conclui nem limpa a reserva do novo dono.
wp_clear_scheduled_hook( $hook );
F3Base_Operacao::callback( $hook, static function () {
	F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function ( $v ) { $v['acessos']['lease'] = array( 'id' => 'novo-dono', 'ate' => time() + 120 ); return $v; } );
	return array( 'ok' => true );
} );
$r = F3Base_Operacao::executar_uma( 'acessos', 'administracao', false, $hook );
$anotar( 'reserva_substituida_preservada', ! $r['ok'] && ! $r['confirmado_localmente'] && 'novo-dono' === F3Base_Options::ler( F3Base_Operacao::OPTION )['acessos']['lease']['id'], $r );
F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function () { return array(); } );
// Expiração da reserva durante o callback não pode ser promovida a conclusão local.
wp_clear_scheduled_hook( $hook );
F3Base_Operacao::callback( $hook, static function () {
	F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function ( $v ) { $v['acessos']['lease']['ate'] = time() - 1; return $v; } );
	return array( 'ok' => true );
} );
$r = F3Base_Operacao::executar_uma( 'acessos', 'administracao', false, $hook );
$anotar( 'lease_vencida_nao_confirma', ! $r['ok'] && ! $r['confirmado_localmente'] && 'confirmacao_local_pendente' === $r['codigo'], $r );
wp_clear_scheduled_hook( $hook );
F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function () { return array(); } );
F3Base_Operacao::callback( $hook, static function () { return array( 'ok' => true, 'restantes' => 4, 'payload' => 'segredo-nao-propagar' ); } );
$r = F3Base_Operacao::executar_uma( 'acessos', 'administracao', false, $hook );
$anotar( 'saldo_parcial_sem_payload', $r['ok'] && $r['parcial'] && 'parcial' === $r['status'] && 4 === $r['resultado_modulo']['restantes'] && ! str_contains( wp_json_encode( $r ), 'segredo-nao-propagar' ), $r );
wp_clear_scheduled_hook( $hook );
$negar_agenda = static function ( $pre, $evento ) use ( $hook ) { return $evento->hook === $hook ? false : $pre; };
add_filter( 'pre_schedule_event', $negar_agenda, 10, 2 );
$r = F3Base_Operacao::executar_uma( 'acessos', 'administracao', false, $hook );
$estado = F3Base_Options::ler( F3Base_Operacao::OPTION );
$anotar( 'recusa_agendamento_recuperacao_persistida', ! $r['ok'] && ! $r['recuperacao']['agendado'] && $estado['acessos']['recuperacao']['pendente'] && ! $estado['acessos']['recuperacao']['agendamento_confirmado'], $r );
remove_filter( 'pre_schedule_event', $negar_agenda, 10 );
F3Base_Operacao::recuperar_agendamentos();
$anotar( 'bootstrap_recupera_sem_executar', wp_next_scheduled( $hook ) > time() );
// Último sucesso é durável; tentativa posterior recusada não apaga esse histórico.
F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function () { return array(); } );
F3Base_Operacao::callback( $hook, static fn() => array( 'ok' => true, 'restantes' => 0 ) );
$r = F3Base_Operacao::executar_uma( 'acessos', 'administracao', false, $hook );
$sucesso = F3Base_Operacao::agenda()['acessos']['ultimo_sucesso'];
$anotar( 'ultimo_sucesso_confirmado_persistido', $r['confirmado_localmente'] && ! empty( $sucesso['fim'] ) && 'lote_local_confirmado' === $sucesso['escopo'], $sucesso );
F3Base_Operacao::callback( $hook, static fn() => array( 'ok' => false, 'codigo' => 'falha_posterior', 'restantes' => 2 ) );
F3Base_Operacao::executar_uma( 'acessos', 'administracao', false, $hook );
$apos = F3Base_Operacao::agenda();
$anotar( 'falha_posterior_preserva_ultimo_sucesso', $apos['acessos']['ultimo_sucesso'] === $sucesso && 'pendente' === $apos['acessos']['ultima_execucao']['status'], $apos['acessos']['ultimo_sucesso'] );
$anotar( 'saldo_desconhecido_nao_inventa_zero', false === $apos['robots']['saldo']['conhecido'] && null === $apos['robots']['saldo']['quantidade'] && null === $apos['robots']['saldo']['observado_em'], $apos['robots']['saldo'] );
$hook_retencao = F3Base_Modulo_Retencao_Eliminacao::EVENTO;
F3Base_Operacao::callback( $hook_retencao, static fn() => array( 'ok' => true, 'restantes' => 4 ) );
$parcial = F3Base_Operacao::executar_uma( 'retencao', 'administracao', false, $hook_retencao );
$saldo = F3Base_Operacao::agenda()['retencao']['saldo'];
$anotar( 'saldo_conhecido_preserva_escopo_e_fotografia', $parcial['parcial'] && $saldo['conhecido'] && 4 === $saldo['quantidade'] && $saldo['observado_em'] > 0 && 'ultimo_lote_restantes' === $saldo['escopo'], $saldo );
$antes = $GLOBALS['wpdb']->get_results( "SELECT option_name,option_value FROM {$GLOBALS['wpdb']->options} ORDER BY option_name", ARRAY_A );
$agenda = F3Base_Operacao::agenda();
$depois = $GLOBALS['wpdb']->get_results( "SELECT option_name,option_value FROM {$GLOBALS['wpdb']->options} ORDER BY option_name", ARRAY_A );
$anotar( 'agenda_saldo_sucesso_apenas_leitura', $antes === $depois );
wp_clear_scheduled_hook( $hook );
F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static fn() => $original );
$falhas = count( array_filter( $testes, static fn( $t ) => ! $t['ok'] ) );
echo wp_json_encode( array( 'testes' => $testes, 'falhas' => $falhas ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . "\n";
if ( $falhas ) { WP_CLI::error( 'Revisão negativa do executor reprovada.' ); }
