<?php
/** Captura dados reais publicados pelo Core para exercitar os clientes JavaScript. */
declare(strict_types=1);
$site = rtrim($argv[1], '/');
if (!is_file($site . '/.f3base-bancada-110')) { throw new RuntimeException('Somente bancada descartável.'); }
require $site . '/wp-load.php';
add_filter('pre_http_request', static fn() => new WP_Error('fixture_sem_rede', 'Somente teste local.'));
$avisos = [];
set_error_handler(static function($n, $m, $f, $l) use (&$avisos) { $avisos[] = "$n $m $f:$l"; return false; });
$preferencias = [
 'f3base_contato' => array_merge(F3Base_Options::ler('f3base_contato'), ['whatsapp_e164'=>'5511999999999']),
 'f3base_ga4_measurement_id' => 'G-ABCDEF1234',
 'f3base_google_ads' => ['conversion_id'=>'AW-123456789','conversion_label'=>'AbC-D_efGhIjKlM'],
 'f3base_gtm_container_id' => '',
 'f3base_consentimento' => array_merge(F3Base_Options::ler('f3base_consentimento'), ['modo'=>'legado','padrao'=>'pre-aprovado','controle_rodape'=>true,'aviso_primeira_visita'=>false]),
 'f3base_comportamento' => array_merge(F3Base_Options::ler('f3base_comportamento'), ['ligado'=>true,'tempo_ativo'=>false]),
];
$anteriores = [];
foreach ($preferencias as $chave=>$valor) { $anteriores[$chave]=F3Base_Options::ler($chave); }
$capturas=[];
try {
 foreach ($preferencias as $chave=>$valor) {
  $r=F3Base_Options::gravar($chave,$valor);
  if (empty($r['persisted'])) { throw new RuntimeException('Falhou '.$chave.': '.wp_json_encode($r)); }
 }
 foreach (['direto','gtm','granular'] as $cenario) {
  if ($cenario==='gtm') { F3Base_Options::gravar('f3base_gtm_container_id','GTM-ABC1234'); }
  if ($cenario==='granular') { F3Base_Options::gravar('f3base_consentimento',array_merge($preferencias['f3base_consentimento'],['modo'=>'granular'])); }
  $GLOBALS['wp_scripts'] = new WP_Scripts();
  (new F3Base_Modulo_Consentimento())->enfileirar();
  (new F3Base_Modulo_Tracking())->enfileirar();
  (new F3Base_Modulo_Leads_WhatsApp())->enfileirar();
  $captura=['cenario'=>$cenario,'estrategia'=>F3Base_Modulo_Consentimento::estrategia_de_carga()];
  foreach (['consentimento'=>[F3Base_Modulo_Consentimento::HANDLE,'f3baseConsentimentoDados'],'tracking'=>[F3Base_Modulo_Tracking::HANDLE,'f3baseTrackingDados'],'leads'=>[F3Base_Modulo_Leads_WhatsApp::HANDLE,'f3baseLeadsDados']] as $nome=>$alvo) {
   $bruto=(string)wp_scripts()->get_data($alvo[0],'data');
   if (!preg_match('/var '.preg_quote($alvo[1],'/').' = (\{.*\});/',$bruto,$m)) { throw new RuntimeException('Objeto não publicado: '.$alvo[1]); }
   $captura[$nome]=json_decode($m[1],true,512,JSON_THROW_ON_ERROR);
  }
  $capturas[]=$captura;
 }
 if ($avisos) { throw new RuntimeException(implode("\n",$avisos)); }
 file_put_contents($argv[2],wp_json_encode($capturas,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");
 echo "PASS produtor PHP: três configurações capturadas de wp_localize_script, sem avisos.\n";
} finally {
 foreach ($anteriores as $chave=>$valor) { F3Base_Options::gravar($chave,$valor); }
 restore_error_handler();
}
