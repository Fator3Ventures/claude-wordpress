#!/usr/bin/env python3
"""Morte de subprocesso PHP antes de finally, seguida de recuperação em processo distinto."""
import argparse,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('--php',required=True);p.add_argument('--wp-cli',required=True);p.add_argument('--site',required=True);a=p.parse_args()
worker=pathlib.Path(__file__).with_name('operacao-morte-worker.php')
def run(mode, code=0):
    r=subprocess.run([a.php,a.wp_cli,'--allow-root','--path='+a.site,'eval-file',str(worker),mode],text=True,capture_output=True,timeout=30)
    assert r.returncode==code,(r.returncode,r.stderr,r.stdout)
    return json.loads(r.stdout) if r.stdout.strip() else None
run('preparar');run('morrer',23);before=run('inspecionar')
assert before['pendente'] and before['lease_ativa'] and before['fim']==0,before
run('avancar_prazo');after=run('recuperar')
assert after['agendada'] and after['confirmada'] and after['pendente'] and after['fim']==0,after
run('limpar');print(json.dumps({'morte_real_subprocesso':True,'prazo_avancado_por_fixture':True,'antes':before,'depois':after,'ok':True},ensure_ascii=False))
