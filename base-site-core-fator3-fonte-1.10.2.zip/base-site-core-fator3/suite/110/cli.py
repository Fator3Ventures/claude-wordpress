#!/usr/bin/env python3
"""Testa comandos reais WP-CLI; as respostas HTTP são fixtures locais e explícitas."""
import os,json,subprocess,tempfile,pathlib,sqlite3
site=pathlib.Path(os.environ['F3BASE_SITE']).resolve()
php=os.environ['F3BASE_PHP']; cli=os.environ['F3BASE_WPCLI']
if not (site/'.f3base-bancada-110').is_file(): raise SystemExit('Bancada marcada obrigatória')
fixture=pathlib.Path(__file__).with_name('fixture-cli.php');mu=site/'wp-content/mu-plugins/f3base-cli-fixture.php';mu.parent.mkdir(exist_ok=True);mu.write_bytes(fixture.read_bytes())
evidencias=[]
def testar(nome,scenario,args,esperado,condicao=lambda r:True,calls=None):
 with tempfile.TemporaryDirectory(prefix='f3base-cli-') as tmp:
  marker=pathlib.Path(tmp)/'calls'
  env=dict(os.environ,F3BASE_CLI_SCENARIO=scenario,F3BASE_CLI_MARKER=str(marker),PATH=str(pathlib.Path(php).parent)+':'+os.environ['PATH'])
  p=subprocess.run([php,cli,'--allow-root','--path='+str(site),'f3base',*args],capture_output=True,text=True,env=env,timeout=45)
  try:r=json.loads(p.stdout)
  except Exception:raise AssertionError(nome+': JSON inválido '+p.stdout+' '+p.stderr)
  n=len(marker.read_text().splitlines()) if marker.exists() else 0
  assert p.returncode==esperado,(nome,p.returncode,p.stdout,p.stderr)
  assert condicao(r),(nome,r)
  assert not p.stderr,(nome,p.stderr)
  if calls is not None:assert n==calls,(nome,n)
  evidencia={'teste':nome,'ok':True,'exit_code':p.returncode,'json_valido':True,'acoes_fixture':n};evidencias.append(evidencia);print(json.dumps(evidencia))
try:
 testar('CLI_status_json','',['status','--format=json'],0,lambda r:'modulos'in r)
 testar('CLI_limite_recusado_antes_da_acao','limite',['pendentes','executar','--limite=99','--format=json'],1,lambda r:r['codigo']=='limite_invalido',0)
 testar('CLI_formato_recusado_antes_da_rede','validacao',['publicacao','verificar','--format=yaml'],1,lambda r:r['codigo']=='formato_invalido',0)
 testar('CLI_publicacao_permitida','publicacao',['publicacao','verificar','--caminho=/llms.txt','--format=json'],0,lambda r:r['persisted'] and r['status']==200,1)
 testar('CLI_publicacao404_falha','publicacao404',['publicacao','verificar','--caminho=/llms.txt'],1,lambda r:r['status']==404,1)
 testar('CLI_intervalo_pendente','intervalo',['publicacao','verificar'],2,lambda r:r['codigo']=='f3base_sonda_intervalo',0)
 testar('CLI_limite_1_saldo_pendente','limite',['pendentes','executar','--limite=1'],2,lambda r:len(r['resultados'])==1 and r['tarefas_vencidas_restantes']>=1,1)
 testar('CLI_reserva_impede_duplicar','reservado',['acessos','coletar'],2,lambda r:r['codigo']=='reserva_indisponivel',0)
 testar('CLI_excecao_falha','falha',['acessos','coletar'],1,lambda r:r['status']=='falha',1)
finally:mu.unlink(missing_ok=True)
