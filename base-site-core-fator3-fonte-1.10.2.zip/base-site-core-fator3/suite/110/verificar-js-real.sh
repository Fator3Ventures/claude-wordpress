#!/usr/bin/env bash
# Execute em bancada descartável; PHP deve estar no PATH.
set -euo pipefail
SITE_JS_110="$(realpath "$1")"
ROOT_JS_110="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT_JS_110="$(realpath -m "${2:-$ROOT_JS_110/suite/evidencias-110}")"
mkdir -p "$OUT_JS_110"
php "$ROOT_JS_110/suite/110/produtor-js-real.php" "$SITE_JS_110" "$OUT_JS_110/produtor-js-dados.json"
python - "$ROOT_JS_110" "$OUT_JS_110" <<'PY'
from pathlib import Path
import json,subprocess,sys
root,out=map(Path,sys.argv[1:]); results=[]
for mode in ['leads','conversao','comportamento','resumo','ciclo','releitura','ordem','produtor']:
 cmd=['node',str(root/'suite/checagens/js.mjs'),mode,str(root)]
 if mode=='produtor':cmd.append(str(out/'produtor-js-dados.json'))
 p=subprocess.run(cmd,capture_output=True,text=True)
 try: result=json.loads(p.stdout)
 except ValueError:result={'achados':['Saída inválida: '+p.stdout+p.stderr]}
 results.append({'modo':mode,'exit':p.returncode,**result})
(out/'js-legado-110.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
if any(row['exit'] or row['achados'] for row in results):raise SystemExit(1)
print('PASS: oito modos JS, incluindo produtor PHP real.')
PY
php "$ROOT_JS_110/suite/110/detector-saida.php" > "$OUT_JS_110/detector-saida-110.json"
node "$ROOT_JS_110/suite/110/consentimento-tracking.cjs" > "$OUT_JS_110/consentimento-tracking.txt"
