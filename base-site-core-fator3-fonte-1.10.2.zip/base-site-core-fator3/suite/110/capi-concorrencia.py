#!/usr/bin/env python3
"""Disputa real entre processos PHP distintos no mesmo WordPress/SQLite isolado."""
import argparse, concurrent.futures, json, pathlib, subprocess
p=argparse.ArgumentParser();p.add_argument('--php',required=True);p.add_argument('--wp-cli',required=True);p.add_argument('--site',required=True);a=p.parse_args()
worker=pathlib.Path(__file__).with_name('capi-concorrencia-worker.php')
def run(action, identifier=''):
    cmd=[a.php,a.wp_cli,'--allow-root','--path='+a.site,'eval-file',str(worker),action,identifier]
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
    if r.returncode: raise RuntimeError(r.stderr+r.stdout)
    return json.loads(r.stdout)
run('preparar')
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    writes=list(pool.map(lambda i: run('inserir',str(i)),range(8)))
total=run('contar')['total'];accepted=sum(x['ok'] for x in writes)
assert total==1000 and accepted==3, (total,accepted,writes)
run('preparar-reserva')
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    reservations=list(pool.map(lambda i: run('reservar',str(i)),range(8)))
assert sum(x['reservado'] for x in reservations)==1, reservations
assert sum(x['iniciado'] for x in reservations)==1, reservations
run('limpar')
print(json.dumps({'processos':8,'limite_total':total,'insercoes_aceitas':accepted,'reservas_aceitas':1,'envios_autorizados':1,'ok':True},ensure_ascii=False))
