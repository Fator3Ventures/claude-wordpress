<?php
/** Banco real isolado: falha parcial de DDL e recusa de agendamento são observáveis. */
if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) { exit( 1 ); }
global $wpdb; $testes = array();
$anotar = static function ( $id, $ok, $r = null ) use ( &$testes ) { $testes[] = array( 'id' => $id, 'ok' => (bool) $ok, 'evidencia' => $r ); };
$orig = F3Base_Options::ler( F3Base_Atualizacao::OPTION );
$t = $wpdb->prefix . F3Base_Modulo_Endpoint_Leads::TABELA_RECUSAS;
$wpdb->query( "DROP TABLE IF EXISTS {$t}" );
$wpdb->query( "CREATE TABLE {$t} (dia date NOT NULL,motivo varchar(40) NOT NULL,PRIMARY KEY (dia,motivo))" );
F3Base_Options::atualizar_estado( F3Base_Atualizacao::OPTION, static function () { return array( 'versao' => F3Base_Atualizacao::VERSAO ); } );
$anotar( 'versao_nao_mascara_schema_incompleto', ! F3Base_Atualizacao::pronta() );
$recusar = static function ( $sql ) use ( $t ) { return str_starts_with( $sql, 'ALTER TABLE ' . $t ) ? 'UPDATE tabela_fixture_inexistente SET x=1' : $sql; };
add_filter( 'query', $recusar );
$r = F3Base_Atualizacao::migrar();
$anotar( 'ddl_recusado_nao_confirma_versao', ! $r['ok'] && '' === F3Base_Options::ler( F3Base_Atualizacao::OPTION )['versao'], $r );
remove_filter( 'query', $recusar );
wp_clear_scheduled_hook( F3Base_Atualizacao::EVENTO );
$recusar_cron = static function ( $pre, $evento ) { return F3Base_Atualizacao::EVENTO === $evento->hook ? false : $pre; };
add_filter( 'pre_schedule_event', $recusar_cron, 10, 2 );
$r = F3Base_Atualizacao::agendar();
$anotar( 'recusa_cron_migracao_visivel', ! $r['ok'] && 'agendamento_recusado' === F3Base_Options::ler( F3Base_Atualizacao::OPTION )['codigo'], $r );
remove_filter( 'pre_schedule_event', $recusar_cron, 10 );
$r = F3Base_Atualizacao::migrar();
$anotar( 'migracao_retomada_schema_confirmado', $r['ok'] && F3Base_Atualizacao::pronta(), $r );
$estado = F3Base_Options::ler( F3Base_Atualizacao::OPTION );
$anotar( 'agenda_removida_estado_zerado', ! $estado['agendamento_confirmado'] && 0 === $estado['proxima_execucao'] && ! empty( $r['agenda_confirmada_localmente'] ) && false === wp_next_scheduled( F3Base_Atualizacao::EVENTO ), $estado );
$falhas = count( array_filter( $testes, static fn( $t ) => ! $t['ok'] ) );
echo wp_json_encode( array( 'testes' => $testes, 'falhas' => $falhas ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . "\n";
if ( $falhas ) { WP_CLI::error( 'Revisão de migração reprovada.' ); }
