<?php
/** F03: períodos opcionais com hoje, fotografias explícitas e consultas sem efeitos. */
declare(strict_types=1);
$site=rtrim($argv[1],'/');
if(!is_file($site.'/.f3base-bancada-110')){throw new RuntimeException('Somente bancada descartável.');}
require $site.'/wp-load.php';
wp_set_current_user(1);update_option('timezone_string','America/Sao_Paulo');
$checks=[];$detalhes=[];$avisos=[];
$ok=static function($v,$nome,$detalhe=null)use(&$checks,&$detalhes){$checks[$nome]=(bool)$v;if(!$v&&$detalhe!==null){$detalhes[$nome]=$detalhe;}};
set_error_handler(static function($n,$m,$f,$l)use(&$avisos){$avisos[]="$n $m $f:$l";return false;});
$raiz=sys_get_temp_dir().'/f3base-comparacao-hoje-'.getmypid();wp_mkdir_p($raiz);$log=$raiz.'/access.log';file_put_contents($log,"SENTINELA: comparação não lê o arquivo ativo.\n");
$c=F3Base_Modulo_Acessos_Servidor::config();$c['ligado']=true;$c['padrao_do_log']=$raiz.'/access.log.*';F3Base_Options::gravar('f3base_acessos',$c);
(new F3Base_Modulo_Acessos_Servidor())->garantir_estrutura();F3Base_Modulo_Comportamento::criar_tabela();
global $wpdb;$tc=$wpdb->prefix.F3Base_Modulo_Comportamento::TABELA;$ta=$wpdb->prefix.F3Base_Modulo_Acessos_Servidor::TABELA;
// Fixtures exclusivas desta cópia de teste; nenhuma instalação externa é usada.
$wpdb->query("DELETE FROM $tc");$wpdb->query("DELETE FROM $ta");
$hoje=wp_date('Y-m-d');$data=new DateTimeImmutable($hoje,wp_timezone());$ontem=$data->modify('-1 day')->format('Y-m-d');$anteontem=$data->modify('-2 days')->format('Y-m-d');
$regra=F3Base_Modulo_Acessos_Servidor::config_hash();$estado=['dias'=>[],'fontes'=>[],'inspecionado_em'=>time(),'config_hash'=>$regra];
foreach([$anteontem,$ontem]as$dia){$estado['dias'][$dia]=['regra'=>$regra,'fuso'=>wp_timezone_string()];$estado['fontes'][$dia]=['regra'=>$regra,'rotacao'=>$dia,'datas_origem'=>[$dia],'offsets'=>['-03:00'],'dias'=>[$dia],'adiados'=>[],'disponivel'=>true,'erro'=>''];}
F3Base_Options::gravar('f3base_acessos_estado',$estado);
foreach([$anteontem=>2,$ontem=>4,$hoje=>8]as$dia=>$n){
 F3Base_Modulo_Comportamento::somar($dia,'/','f3base_pagina_vista','',$n,0);
 F3Base_Modulo_Comportamento::somar($dia,'/outra/','f3base_pagina_vista','',$n*10,0);
 F3Base_Modulo_Comportamento::somar($dia,'/','f3base_rolagem','25',$n*3,0);
 if($dia!==$hoje){foreach([['/','pagina',200,$n],['/robots.txt','arquivo',200,$n*2],['/ausente/','pagina',404,$n*4]]as[$path,$classe,$status,$contagem]){$wpdb->insert($ta,['dia'=>$dia,'agente'=>'humano','classe_caminho'=>$classe,'caminho'=>$path,'status'=>$status,'metodo'=>'GET','contagem'=>$contagem]);}}
}
$foto=['dia'=>$hoje,'regra'=>$regra,'fuso'=>wp_timezone_string(),'atualizado'=>time(),'erro'=>'','corte'=>false,'bytes_pendentes'=>0,'ignoradas'=>0,'linhas'=>[
 ['caminho'=>'/','classe_caminho'=>'pagina','agente'=>'humano','status'=>200,'metodo'=>'GET','contagem'=>9],
 ['caminho'=>'/robots.txt','classe_caminho'=>'arquivo','agente'=>'humano','status'=>200,'metodo'=>'GET','contagem'=>3],
 ['caminho'=>'/ausente/','classe_caminho'=>'pagina','agente'=>'humano','status'=>404,'metodo'=>'GET','contagem'=>5],
]];
$obter=static function($r,$caminho,$metrica=null){foreach($r['linhas']as$l){if($l['caminho']===$caminho&&($metrica===null||$l['metrica']===$metrica)){return $l;}}return[];};
$escritas=[];$http=0;$query=static function($q)use(&$escritas){if(preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE|CREATE|ALTER|DROP)\b/i',$q)){$escritas[]=$q;}return$q;};
$semRede=static function()use(&$http){++$http;return new WP_Error('sem_http','Consulta não deve usar HTTP.');};
$antes=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name",ARRAY_A);$cron=get_option('cron');$estadoAntes=F3Base_Options::ler('f3base_acessos_estado');touch($log,time()-200,time()-300);clearstatcache(true,$log);$stat=stat($log);
add_filter('query',$query);add_filter('pre_http_request',$semRede);
try{
 $r=F3Base_Medicao_Consultas::comparar_comportamento(1,'/','f3base_pagina_vista');$l=$obter($r,'/','f3base_pagina_vista');$ok($r['fim']===$ontem&&($l['atual']??null)===4&&($l['anterior']??null)===2,'comportamento_default_exclui_hoje',$r);
 $r=F3Base_Medicao_Consultas::comparar_comportamento(1,'/','f3base_pagina_vista',true);$l=$obter($r,'/','f3base_pagina_vista');$ok($r['inicio']===$hoje&&$r['fim']===$hoje&&$r['anterior_fim']===$ontem&&($l['atual']??null)===8&&($l['anterior']??null)===4,'comportamento_hoje_versus_ontem',$r);$ok(!empty($r['hoje_incluido'])&&!empty($r['periodo_parcial']),'comportamento_rotulo_parcial',$r);$ok(count($r['linhas'])===1,'comportamento_filtra_caminho_metrica',$r);
 $r=F3Base_Medicao_Consultas::comparar_comportamento(1,'/','f3base_rolagem',true);$l=$obter($r,'/','f3base_rolagem');$ok(($l['atual']??null)===24&&($l['anterior']??null)===12,'comportamento_outro_evento',$r);
 $r=F3Base_Acessos_Relatorio::comparar(1,'todos',false);$l=$obter($r,'/');$ok($r['fim']===$ontem&&($l['atual']??null)===4&&($l['anterior']??null)===2,'acessos_default_exclui_hoje',$r);
 $r=F3Base_Acessos_Relatorio::comparar(1,'conteudo',false,true,$foto);$l=$obter($r,'/');$ok($r['inicio']===$hoje&&$r['anterior_fim']===$ontem&&($l['atual']??null)===9&&($l['anterior']??null)===4,'acessos_hoje_versus_ontem',$r);$ok(!empty($r['periodo_parcial'])&&!empty($r['hoje_incluido']),'acessos_rotulo_parcial',$r);$ok(count($r['linhas'])===2&&$obter($r,'/robots.txt')&& !$obter($r,'/ausente/'),'acessos_filtra_conteudo_descoberta',$r);
 $r=F3Base_Acessos_Relatorio::comparar(1,'inexistentes',true,true,$foto);$l=$obter($r,'/ausente/');$ok(count($r['linhas'])===1&&($l['atual']??null)===5&&($l['anterior']??null)===16,'acessos_filtro_404_e_erros',$r);
 $r=F3Base_Acessos_Relatorio::comparar(1,'todos',false,true,null);$ok($r['dias_comparados']===0&&$r['linhas']===[]&&!empty($r['pares_excluidos']),'ausencia_fotografia_nao_vira_zero',$r);
 foreach(['data_antiga'=>['dia'=>$ontem],'sem_atualizacao'=>['atualizado'=>0],'atualizacao_anterior'=>['atualizado'=>(new DateTimeImmutable($ontem.' 12:00:00',wp_timezone()))->getTimestamp()],'linhas_ignoradas'=>['ignoradas'=>1],'erro'=>['erro'=>'indisponível'],'corte'=>['corte'=>true],'bytes_pendentes'=>['bytes_pendentes'=>10],'regra_incompativel'=>['regra'=>'outra'],'fuso_incompativel'=>['fuso'=>'UTC']]as$nome=>$m){$r=F3Base_Acessos_Relatorio::comparar(1,'todos',false,true,array_merge($foto,$m));$ok($r['dias_comparados']===0&&$r['linhas']===[],'fotografia_recusada_'.$nome,$r);}
 $vazia=array_merge($foto,['linhas'=>[]]);$r=F3Base_Acessos_Relatorio::comparar(1,'conteudo',false,true,$vazia);$l=$obter($r,'/');$ok($r['dias_comparados']===1&&($l['atual']??null)===0&&($l['anterior']??null)===4,'fotografia_atual_vazia_diferente_de_ausente',$r);
}finally{remove_filter('query',$query);remove_filter('pre_http_request',$semRede);}
$depois=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name",ARRAY_A);clearstatcache(true,$log);$statDepois=stat($log);
$ok($escritas===[],'consultas_sem_sql_de_escrita',$escritas);$ok($antes===$depois&&$cron===get_option('cron')&&$estadoAntes===F3Base_Options::ler('f3base_acessos_estado'),'consultas_sem_options_cron_coleta');$ok($stat['atime']===$statDepois['atime']&&$stat['mtime']===$statDepois['mtime']&&$stat['size']===$statDepois['size'],'consulta_nao_abre_nem_altera_log');$ok($http===0,'consulta_sem_http');$ok($avisos===[],'sem_avisos_php',$avisos);
// Alterações abaixo pertencem somente à fixture; as consultas continuam usando o leitor real.
$wpdb->update($tc,['fuso'=>'UTC'],['dia'=>$hoje,'caminho'=>'/','metrica'=>'f3base_pagina_vista']);
$r=F3Base_Medicao_Consultas::comparar_comportamento(1,'/','f3base_pagina_vista',true);
$ok($r['dias_comparados']===0&&$r['linhas']===[],'comportamento_fuso_divergente_exclui_par',$r);
$wpdb->update($tc,['fuso'=>wp_timezone_string(),'regra'=>'legado'],['dia'=>$hoje,'caminho'=>'/','metrica'=>'f3base_pagina_vista']);
$r=F3Base_Medicao_Consultas::comparar_comportamento(1,'/','f3base_pagina_vista',true);
$ok($r['dias_comparados']===0&&$r['linhas']===[],'comportamento_regra_divergente_exclui_par',$r);
$wpdb->update($tc,['regra'=>F3Base_Modulo_Comportamento::regra_calendario()],['dia'=>$hoje,'caminho'=>'/','metrica'=>'f3base_pagina_vista']);
F3Base_Modulo_Comportamento::somar($hoje,'/',F3Base_Modulo_Comportamento::METRICA_CORTADAS,'',1,0);
$r=F3Base_Medicao_Consultas::comparar_comportamento(1,'/','f3base_pagina_vista',true);
$ok($r['dias_comparados']===0&&$r['linhas']===[],'comportamento_corte_exclui_par',$r);
$wpdb->delete($tc,['dia'=>$hoje]);
$r=F3Base_Medicao_Consultas::comparar_comportamento(1,'/','f3base_pagina_vista',true);
$ok($r['dias_comparados']===0&&$r['linhas']===[]&&!empty($r['pares_excluidos']),'comportamento_dia_ausente_nao_vira_zero',$r);
// Leitura da fotografia válida armazenada também preserva o prazo e não grava estado.
set_transient(F3Base_Acessos_Atuais::CACHE,array_merge($foto,['agregados'=>$foto['linhas']]),3600);
$prazoAntes=get_option('_transient_timeout_'.F3Base_Acessos_Atuais::CACHE);$escritas=[];add_filter('query',$query);
try{$r=F3Base_Acessos_Relatorio::comparar(1,'conteudo',false,true);}finally{remove_filter('query',$query);}
$l=$obter($r,'/');$ok($r['dias_comparados']===1&&($l['atual']??null)===9,'fotografia_armazenada_lida_sem_parametro',$r);
$ok($escritas===[]&&$prazoAntes===get_option('_transient_timeout_'.F3Base_Acessos_Atuais::CACHE),'fotografia_armazenada_nao_renova_prazo',$escritas);
// Expiração lógica não autoriza o leitor a expurgar options durante uma consulta.
set_transient(F3Base_Acessos_Atuais::CACHE,array_merge($foto,['agregados'=>$foto['linhas']]),3600);
update_option('_transient_timeout_'.F3Base_Acessos_Atuais::CACHE,time()-1);
$escritas=[];add_filter('query',$query);
try{$r=F3Base_Acessos_Relatorio::comparar(1,'todos',false,true);}finally{remove_filter('query',$query);}
$ok($r['dias_comparados']===0&&$r['linhas']===[],'fotografia_expirada_indisponivel',$r);
$ok($escritas===[],'fotografia_expirada_sem_escrita',$escritas);
$ok($avisos===[],'sem_avisos_php',$avisos);
restore_error_handler();unlink($log);rmdir($raiz);
echo wp_json_encode(['ok'=>!in_array(false,$checks,true),'total'=>count($checks),'checks'=>$checks,'detalhes'=>$detalhes],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";exit(in_array(false,$checks,true)?1:0);
