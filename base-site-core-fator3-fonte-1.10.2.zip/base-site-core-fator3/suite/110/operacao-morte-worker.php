<?php
/** Simula morte real do processo e avanço controlado do prazo na bancada. */
if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) { exit( 1 ); }
$modo = $args[0] ?? ''; $hook = 'f3base_acessos_continuar';
if ( 'preparar' === $modo ) {
	F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static fn() => array() );
	wp_clear_scheduled_hook( $hook ); echo '{}';
} elseif ( 'morrer' === $modo ) {
	F3Base_Operacao::callback( $hook, static function () { exit( 23 ); } );
	F3Base_Operacao::executar_uma( 'acessos', 'administracao', false, $hook );
	throw new RuntimeException( 'Callback não morreu.' );
} elseif ( 'inspecionar' === $modo ) {
	$v = F3Base_Options::ler( F3Base_Operacao::OPTION );
	echo wp_json_encode( array( 'pendente' => $v['acessos']['recuperacao']['pendente'], 'lease_ativa' => $v['acessos']['lease']['ate'] > time(), 'fim' => $v['acessos']['ultima']['fim'] ) );
} elseif ( 'avancar_prazo' === $modo ) {
	F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static function ( $v ) { $v['acessos']['lease']['ate'] = time() - 1; $v['acessos']['recuperacao']['quando'] = time() - 1; return $v; } );
	wp_clear_scheduled_hook( $hook ); echo '{}';
} elseif ( 'recuperar' === $modo ) {
	F3Base_Operacao::recuperar_agendamentos();
	$v = F3Base_Options::ler( F3Base_Operacao::OPTION );
	echo wp_json_encode( array( 'agendada' => wp_next_scheduled( $hook ) > time(), 'fim' => $v['acessos']['ultima']['fim'], 'pendente' => $v['acessos']['recuperacao']['pendente'], 'confirmada' => $v['acessos']['recuperacao']['agendamento_confirmado'] ) );
} elseif ( 'limpar' === $modo ) {
	F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static fn() => array() ); wp_clear_scheduled_hook( $hook ); echo '{}';
}
