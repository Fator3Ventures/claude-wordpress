<?php
/** Regressão de escopo e mutantes do detector dos ouvintes de saída. */
declare(strict_types=1);
require dirname(__DIR__).'/checagens/estatica.php';
$base=dirname(__DIR__).'/fixtures/estatica.saida_com_trava_de_uma_vez';
$raiz=sys_get_temp_dir().'/f3base-saida-'.bin2hex(random_bytes(6));
$assets=$raiz.'/fontes/plugin/assets';mkdir($assets,0700,true);
$arquivo=$assets.'/f3base-tracking.js';
$positivo=(string)file_get_contents($base.'/positiva/fontes/plugin/assets/f3base-tracking.js');
$casos=[];
try {
 $casos['fixture_positiva']=f3b_ck_saida_com_trava_de_uma_vez($base.'/positiva')['ok'];
 $casos['fixture_mutante_sem_trava']=!f3b_ck_saida_com_trava_de_uma_vez($base.'/negativa')['ok'];
 $prefixo=<<<'JS'
 document.addEventListener('visibilitychange', function () { acumulador.atualizar(); });
 function instrumentarVizinho() {
  var literal = "} hidden intruso()"; // } intruso()
  /* } intruso() */
  if ('hidden' === document.visibilityState) { intruso(); }
 }
JS;
 file_put_contents($arquivo,$prefixo."\n".$positivo);
 $casos['callback_inline_nao_invade_vizinho']=f3b_ck_saida_com_trava_de_uma_vez($raiz)['ok'];
 $mutante=str_replace('if (relatado) {','if (false) {',$positivo);
 file_put_contents($arquivo,$prefixo."\n".$mutante);
 $r=f3b_ck_saida_com_trava_de_uma_vez($raiz);
 $casos['callback_inline_nao_esconde_mutante']=!$r['ok']&&count($r['achados'])===1&&str_contains($r['achados'][0],'"relatar"');
 $literal=<<<'JS'
{ var x="} escaped\" {"; /* } */ if (true) { enviarResumo(); } } vizinho()
JS;
 $corpo=f3b_corpo_callback_js($literal,0);
 $casos['delimitacao_strings_comentarios']=$corpo!==null&&str_contains($corpo,'enviarResumo')&&!str_contains($corpo,'vizinho');
 echo json_encode(['ok'=>!in_array(false,$casos,true),'casos'=>$casos],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),"\n";
} finally {
 unlink($arquivo);rmdir($assets);rmdir(dirname($assets));rmdir(dirname(dirname($assets)));rmdir($raiz);
}
exit(in_array(false,$casos,true)?1:0);
