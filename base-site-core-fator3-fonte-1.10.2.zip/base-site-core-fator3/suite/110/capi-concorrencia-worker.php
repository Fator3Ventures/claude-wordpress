<?php
/** Auxiliar da bancada concorrente; somente WP-CLI. */
if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) { exit( 1 ); }
$acao = $args[0] ?? ''; $id = $args[1] ?? ''; global $wpdb;
$t = F3Base_Capi_Fila::tabela();
if ( 'preparar' === $acao ) {
	$wpdb->query( "DELETE FROM {$t}" );
	for ( $i = 0; $i < 997; ++$i ) { $wpdb->insert( $t, array( 'record_id' => 'concorrencia-' . $i, 'payload' => '{}', 'estado' => 'suspenso', 'expira' => time() + 600, 'atualizado' => time(), 'schema_versao' => 2 ) ); }
	echo wp_json_encode( array( 'preparado' => true ) );
} elseif ( 'inserir' === $acao ) {
	$ok = F3Base_Capi_Fila::inserir( 'disputa-' . $id, array( 'data' => array() ), 600, '111111', array( 'politica_versao' => 'legado:' . F3Base_Modulo_Consentimento::politica_versao() ) );
	echo wp_json_encode( array( 'ok' => $ok ) );
} elseif ( 'contar' === $acao ) {
	echo wp_json_encode( array( 'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE payload<>''" ) ) );
} elseif ( 'preparar-reserva' === $acao ) {
	$wpdb->query( "DELETE FROM {$t}" );
	F3Base_Capi_Fila::inserir( 'reserva-simultanea', array( 'data' => array() ), 600, '111111', array( 'politica_versao' => 'legado:' . F3Base_Modulo_Consentimento::politica_versao() ) );
	echo '{}';
} elseif ( 'reservar' === $acao ) {
	$r = F3Base_Capi_Fila::reservar( 'reserva-simultanea' );
	$inicio = $r ? F3Base_Capi_Fila::iniciar_envio( $r ) : array( 'ok' => false );
	echo wp_json_encode( array( 'reservado' => (bool) $r, 'iniciado' => $inicio['ok'] ) );
} elseif ( 'limpar' === $acao ) { $wpdb->query( "DELETE FROM {$t}" ); echo '{}'; }
