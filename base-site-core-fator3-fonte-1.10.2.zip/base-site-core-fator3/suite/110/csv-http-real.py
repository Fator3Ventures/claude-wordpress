#!/usr/bin/env python3
"""CSV real: login nativo, forms/nonces publicados e admin-post autenticado."""
import csv,io,json,os,pathlib,subprocess,sys,socket,time,urllib.request,urllib.parse,urllib.error,http.cookiejar,sqlite3,re,datetime
from lxml import html as htmlparser
site=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve();php=os.environ.get('F3BASE_PHP','php');root=pathlib.Path(__file__).resolve().parents[2];fixture=pathlib.Path(__file__).with_name('csv-http-fixture.php')
assert (site/'.f3base-bancada-110').is_file()
with sqlite3.connect(site/'wp-content/database/.ht.sqlite') as c:assert c.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and c.execute('PRAGMA journal_mode').fetchone()[0]=='delete'
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();base=f'http://127.0.0.1:{port}';env=dict(os.environ,F3BASE_BANCADA_PORTA=str(port));checks=[]
def ck(ok,name,detail=None):
 checks.append({'nome':name,'ok':bool(ok),**({'detalhe':detail} if not ok and detail else {})})
def projection(kind,filters):
 p=subprocess.run([php,str(fixture),str(site),kind,json.dumps(filters)],env=env,capture_output=True,text=True,timeout=30)
 assert p.returncode==0 and not p.stderr,(p.stdout,p.stderr)
 return json.loads(p.stdout)
def opener():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(client,path,data=None):
 try:
  r=client.open(base+path,data=None if data is None else urllib.parse.urlencode(data).encode(),timeout=30)
 except urllib.error.HTTPError as e:r=e
 return r.status,dict(r.headers),r.read().decode('utf-8-sig')
def login(client,user):
 req(client,'/wp-login.php');status,headers,body=req(client,'/wp-login.php',{'log':user,'pwd':'f3base-local-test-only','wp-submit':'Log In','redirect_to':base+'/wp-admin/','testcookie':'1'})
 assert 'id="wpadminbar"' in body or 'wp-admin' in body,(status,body[:300])
def safe(v):
 s=str(v)
 return "'"+s if re.match(r'^[\s]*[=+@\-\t\r]',s) else s
p=subprocess.run([php,str(fixture),str(site),'seed'],env=env,capture_output=True,text=True,timeout=30);assert p.returncode==0 and not p.stderr,(p.stdout,p.stderr);seed=json.loads(p.stdout)
log=out.with_suffix('.server.log');serverlog=log.open('w');server=subprocess.Popen([php,'-S',f'127.0.0.1:{port}','-t',str(site)],env=env,stdout=serverlog,stderr=serverlog)
try:
 for _ in range(80):
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.1):break
  except OSError:time.sleep(.1)
 admin=opener();login(admin,'admin');subscriber=opener();login(subscriber,'csv_assinante');anon=opener();nonce_by_action={}
 cases=[('comportamento',{'comparacao_dias':'1','comparacao_caminho':'/','comparacao_metrica':'f3base_pagina_vista'}),('comportamento',{'comparacao_dias':'1','comparacao_caminho':'/','comparacao_metrica':'f3base_pagina_vista','comparacao_hoje':'1'}),('comportamento',{'comparacao_dias':'1','comparacao_caminho':'/','comparacao_metrica':'f3base_secao_vista','comparacao_hoje':'1'}),('acessos',{'dias':'1','classificacao':'conteudo'}),('acessos',{'dias':'1','classificacao':'conteudo','comparacao_hoje':'1'}),('acessos',{'dias':'1','classificacao':'inexistentes','comparacao_hoje':'1'}),('acessos',{'dias':'1','mostrar_todos':'1','incluir_erros':'1','comparacao_hoje':'1'}),('comportamento',{'comparacao_dias':'1','comparacao_caminho':'/sem-dados-csv/','comparacao_metrica':'f3base_pagina_vista','comparacao_hoje':'1'}),('acessos',{'dias':'1','classificacao':'feeds','comparacao_hoje':'1'}),('comportamento',{'comparacao_dias':'1','comparacao_caminho':'/novo-csv/','comparacao_metrica':'f3base_pagina_vista','comparacao_hoje':'1'})]
 for i,(kind,filters) in enumerate(cases):
  name=f'{kind}_{i}';action=f'f3base_{kind}_csv';args={'page':'f3base-medicao',**({'aba':'acessos'}if kind=='acessos'else{}),**filters}
  status,headers,html=req(admin,'/wp-admin/admin.php?'+urllib.parse.urlencode(args));ck(status==200,name+'_tela_http_200')
  dom=htmlparser.fromstring(html);targets=dom.xpath('//input[@name="action" and @value="'+action+'"]');assert targets,name+' form ausente';form=targets[0].xpath('ancestor::form')[0];posted={x.get('name'):x.get('value','') for x in form.xpath('.//input[@name]')};nonce_by_action[action]=posted['_wpnonce'];ck(all(posted.get(k)==v for k,v in filters.items()),name+'_form_preserva_filtros')
  expected=projection(kind,filters);status,headers,body=req(admin,'/wp-admin/admin-post.php',posted);rows=list(csv.DictReader(io.StringIO(body)))
  ck(status==200 and 'text/csv' in headers.get('Content-Type','') and 'attachment;' in headers.get('Content-Disposition',''),name+'_download_real')
  ck(all(x not in body for x in ['PII_CSV_','contato-pii@example.invalid','551199998888','visitante','sessao','Warning:','Fatal error']),name+'_sem_pii_avisos')
  ck(bool(rows),name+'_csv_tem_linhas')
  if kind=='comportamento':
   keys=['dia','caminho','metrica','detalhe','contagem','soma','regra_linha','fuso_linha','qualidade_temporal'];expected_rows=[dict(zip(keys,[safe(l[k]) for k in ['dia','caminho','metrica','detalhe','contagem','soma','regra','fuso','qualidade']]))for l in expected['agregados']]
   actual_rows=[{k:r[k]for k in keys}for r in rows if r['tipo_linha']=='dado'];ck(actual_rows==expected_rows,name+'_linhas_iguais_projecao',{'actual':actual_rows,'expected':expected_rows})
   ck(all(r['inicio']==expected['inicio'] and r['fim']==expected['fim'] and r['fuso_janela']==expected['fuso'] and r['regra_janela']==expected['regra'] and r['corte']==str(int(expected['corte'])) and int(r['dias_comparados'])==expected['dias_comparados'] and json.loads(r['pares_excluidos'])==expected['pares_excluidos'] and r['hoje_incluido']==str(int(expected['hoje_incluido'])) and r['periodo_parcial']==str(int(expected['periodo_parcial'])) for r in rows),name+'_metadados_periodo_fuso_regra_corte')
   table=dom.xpath('//*[@aria-label="Comparação de atividade"]//table')[0];ui=[[''.join(c.itertext()).strip()for c in tr.xpath('./td')]for tr in table.xpath('./tbody/tr')];ck(([r[:5]for r in ui]==[[l['caminho'],l['metrica'],str(l['atual']),str(l['anterior']),str(l['diferenca'])]for l in expected['linhas']]) if expected['linhas'] else ('Sem pares comparáveis' in ''.join(ui[0])),name+'_ui_comparacao_igual_projecao')
   ck(all(r['filtro_caminho']==filters['comparacao_caminho'] and r['filtro_metrica']==filters['comparacao_metrica'] for r in rows),name+'_filtros_csv')
   if filters['comparacao_metrica']=='f3base_secao_vista':ck(all(r['detalhe']=="'=1+1" for r in rows),name+'_formula_neutralizada')
  else:
   keys=['caminho','classificacao','total','humano','busca','treino_ia','resposta_ia','proprio','hospedagem','outros'];sourcekeys=['caminho','classificacao','total','humano','busca','treino-ia','resposta-ia','proprio','hospedagem','outros'];expected_rows=[dict(zip(keys,[safe(l[k])for k in sourcekeys]))for l in expected['linhas']];actual_rows=[{k:r[k]for k in keys}for r in rows if r['tipo_linha']=='dado'];ck(actual_rows==expected_rows,name+'_linhas_iguais_projecao',{'actual':actual_rows,'expected':expected_rows})
   coverage=expected['cobertura'];ck(all(r['inicio']==expected['inicio'] and r['fim']==expected['fim'] and r['fuso']==expected['fuso'] and r['regra']==expected['regra'] and r['corte']==str(int(expected['corte'])) and json.loads(r['cobertura'])==coverage for r in rows),name+'_metadados_periodo_fuso_regra_corte')
   ck(all(r['filtro']==expected['classificacao'] and r['incluir_erros']==str(int(expected['incluir_erros'])) for r in rows),name+'_filtros_csv')
   ck(all(r['escopo']=='agregados_filtrados' and r['tipo_linha']==('dado' if expected['linhas'] else 'metadados') for r in rows),name+'_escopo_agregados_explicito')
   if filters.get('mostrar_todos')=='1':ck(any(r['caminho']=="'=1+1"for r in rows),name+'_formula_neutralizada')
  ck(all(abs(datetime.datetime.now(datetime.timezone.utc).timestamp()-datetime.datetime.fromisoformat(r['extraido_em']).timestamp())<60 for r in rows),name+'_carimbo_extracao_http')
  ck(len(form.xpath('.//button[@name="tipo" and @value="comparacao"]'))==1,name+'_botao_comparacao_mesmo_form')
  status,h,b=req(admin,'/wp-admin/admin-post.php',{**posted,'tipo':'comparacao'});comparison=list(csv.DictReader(io.StringIO(b)));c=expected if kind=='comportamento' else expected['comparacao'];fields=['caminho']+(['metrica']if kind=='comportamento'else[])+['atual','anterior','diferenca','variacao']
  def cv(v):return ''if v is None else safe(v)
  wanted=[{k:cv(l[k])for k in fields}for l in c['linhas']];observed=[{k:r[k]for k in fields}for r in comparison if r['tipo_linha']=='dado'];ck(observed==wanted,name+'_csv_comparacao_igual_ui_projecao',{'actual':observed,'expected':wanted})
  ck(status==200 and all(r['escopo']=='comparacao_periodos' and r['inicio']==c['inicio'] and r['fim']==c['fim'] and r['anterior_inicio']==c['anterior_inicio'] and r['anterior_fim']==c['anterior_fim'] and r['hoje_incluido']==str(int(c['hoje_incluido'])) and r['periodo_parcial']==str(int(c['periodo_parcial'])) and r['corte']==str(int(c['corte'])) and json.loads(r['pares_excluidos'])==c['pares_excluidos'] and int(r['dias_comparados'])==c['dias_comparados'] for r in comparison),name+'_comparacao_metadados_filtros_parcial')
  if kind=='acessos':
   ck(all(all(c['inicio']<=d['dia']<=c['fim'] for d in json.loads(r['cobertura'])) and all(c['anterior_inicio']<=d['dia']<=c['anterior_fim']for d in json.loads(r['cobertura_anterior']))for r in comparison),name+'_cobertura_das_duas_janelas')
  ck(all(x not in b for x in ['PII_CSV_','contato-pii@example.invalid','551199998888','Warning:','Fatal error']),name+'_comparacao_sem_pii')
  fk,rk=('fuso_janela','regra_janela')if kind=='comportamento'else('fuso','regra')
  ck(all(r[fk]==expected['fuso'] and r[rk]==expected['regra'] and r['limite']=='300'for r in comparison),name+'_comparacao_regra_fuso_limite')
  if kind=='acessos':
   tab=dom.xpath('//*[@aria-label="Comparação de períodos"]//table')[0];ui=[[''.join(td.itertext()).strip()for td in tr.xpath('./td')]for tr in tab.xpath('./tbody/tr')]
   ck(([r[:4]for r in ui]==[[l['caminho'],str(l['atual']),str(l['anterior']),str(l['diferenca'])]for l in c['linhas']]) if c['linhas'] else ('Comparação indisponível' in ''.join(ui[0])),name+'_ui_comparacao_igual_projecao')
   tab=dom.xpath('//*[@aria-label="Acessos por caminho"]//table')[0];ui=[[''.join(td.itertext()).strip()for td in tr.xpath('./td')]for tr in tab.xpath('./tbody/tr')]
   ck(([[r[0],r[3]]for r in ui]==[[l['caminho'],str(l['total'])]for l in expected['linhas']])if expected['linhas']else('Nenhum dado disponível'in''.join(ui[0])),name+'_ui_principal_igual_csv')

  if any(l['variacao'] is None for l in c['linhas']):
   ck(any(r['variacao']=='' and r['anterior']=='0' for r in comparison),name+'_base_zero_sem_percentual_inventado')
  if not c['linhas']:
   ck(len(comparison)==1 and comparison[0]['tipo_linha']=='metadados' and comparison[0]['atual']==comparison[0]['anterior']=='',name+'_sem_linhas_preserva_metadados_sem_inventar_zero')
  if kind=='acessos' and filters.get('mostrar_todos')=='1':
   ck(len(rows)==expected['limite']==300 and all(r['corte']=='1' for r in rows) and c['corte'] and all(r['corte']=='1'for r in comparison),name+'_corte_real_declarado_ambos_formatos')


 for action,nonce in nonce_by_action.items():
  for client,label,data in [(admin,'sem_nonce',{'action':action}),(anon,'anonimo',{'action':action,'_wpnonce':nonce}),(subscriber,'sem_capacidade',{'action':action,'_wpnonce':nonce}),(admin,'tipo_invalido',{'action':action,'_wpnonce':nonce,'tipo':'nao-permitido'}),(admin,'tipo_array',{'action':action,'_wpnonce':nonce,'tipo[]':'comparacao'})]:
   status,headers,body=req(client,'/wp-admin/admin-post.php',data);ck(status>=400 and 'text/csv'not in headers.get('Content-Type',''),action+'_'+label+'_recusado',{'status':status})
finally:
 server.terminate();server.wait(timeout=5);serverlog.close()
result={'ok':all(x['ok']for x in checks),'total':len(checks),'checks':checks,'ambiente':'WordPress 6.9, SQLite DELETE, Yoast e WP Super Cache ativos, HTTP localhost autenticado'};out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':result['ok'],'total':len(checks),'falhas':[x['nome']for x in checks if not x['ok']]}));sys.exit(0 if result['ok']else 1)
