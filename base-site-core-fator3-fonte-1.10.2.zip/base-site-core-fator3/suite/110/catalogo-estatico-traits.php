<?php
/** Catálogo estático completo: fachada, trait vinculada, evolução e pisos legados. */
declare(strict_types=1);
require dirname(__DIR__).'/lib/regra.php';require dirname(__DIR__).'/checagens/estatica.php';
$projeto=dirname(__DIR__,2);$origem=$projeto.'/fontes/plugin/includes';
$temp=sys_get_temp_dir().'/f3base-catalogo-'.bin2hex(random_bytes(5));mkdir($temp.'/fontes/plugin/includes',0700,true);
$destino=$temp.'/fontes/plugin/includes';$fachada=(string)file_get_contents($origem.'/class-f3base-options.php');$trait=(string)file_get_contents($origem.'/trait-f3base-options-catalogo.php');$casos=[];
$preparar=static function($f,$t)use($destino){file_put_contents($destino.'/class-f3base-options.php',$f);file_put_contents($destino.'/trait-f3base-options-catalogo.php',$t);};
$ver=static function($nome,$ok)use(&$casos){$casos[$nome]=(bool)$ok;};
try {
 $preparar($fachada,$trait);$completo=f3b_catalogo_declarado($temp);
 $ver('fachada_trait_confirmadas',count($completo['entradas'])===37&&str_contains($completo['ancora'],'trait-f3base-options-catalogo.php'));
 $ver('constantes_da_fachada',isset($completo['secoes']['SECAO_CONSENTIMENTO']));
 foreach(['f3base_estrutura_estado','f3base_operacao_estado','f3base_publicacao_evidencias'] as $option){$ver('option_aditiva_'.$option,isset($completo['entradas'][$option]));}
 $c=f3b_entradas_de_array(f3b_interior_de_array($completo['entradas']['f3base_consentimento']));
 $subs=f3b_entradas_de_array(f3b_interior_de_array($c['subcampos']));
 foreach(['modo','politica_versao','gtm_separacao_verificada'] as $campo){$ver('subcampo_aditivo_'.$campo,isset($subs[$campo]));}
 $ver('gate_completo',f3b_ck_campo_operavel_documentado($temp)['ok']);
 $mutações=[
  'sem_require'=>[str_replace("require_once __DIR__ . '/trait-f3base-options-catalogo.php';",'', $fachada),$trait],
  'sem_use'=>[str_replace('use F3Base_Options_Catalogo;','',$fachada),$trait],
  'use_fora_da_classe'=>[str_replace('final class F3Base_Options {','use F3Base_Options_Catalogo; final class F3Base_Options {',str_replace('use F3Base_Options_Catalogo;','',$fachada)),$trait],
  'sem_implementacao'=>[$fachada,str_replace('function catalogo_interno(','function catalogo_interno_ausente(',$trait)],
  'sem_metodo_evolucao'=>[$fachada,str_replace('function catalogo_evolucao(','function catalogo_evolucao_ausente(',$trait)],
  'sem_chamada_evolucao'=>[$fachada,str_replace('$catalogo = self::catalogo_evolucao( $catalogo );','',$trait)],
  'item_aditivo_nao_aplicado'=>[$fachada,str_replace("\$catalogo[ \$nome ]['subcampos'][ \$chave ] = \$item[1];",'', $trait)],
  'option_aditiva_ilegivel'=>[$fachada,str_replace("\$catalogo['f3base_estrutura_estado']        = array(","\$catalogo['f3base_estrutura_estado']        = desconhecido(",$trait)],
 ];
 foreach($mutações as $nome=>[$f,$t]){$ver('mutante_modificou_'.$nome,$f!==$fachada||$t!==$trait);$preparar($f,$t);$r=f3b_catalogo_declarado($temp);$ver('recusa_sem_contagem_parcial_'.$nome,$r['entradas']===[]&&!empty($r['erro']));}
 $semImpacto=str_replace("'impacto'   => \$impacto,",'', $trait);$preparar($fachada,$semImpacto);$r=f3b_ck_campo_operavel_documentado($temp);
 $ver('subcampo_aditivo_sem_impacto_reprova',$semImpacto!==$trait&&!$r['ok']&&str_contains(implode(';',$r['achados']),'f3base_consentimento.modo'));
 foreach(['estatica.campo_operavel_tem_impacto_e_exemplo'=>'f3b_ck_campo_operavel_documentado','mcp.options_citadas_existem'=>'f3b_ck_options_citadas_existem'] as $piso=>$fn){foreach(['positiva'=>true,'negativa'=>false] as $ramo=>$esperado){$ver('piso_legado_'.$piso.'_'.$ramo,$fn(dirname(__DIR__).'/fixtures/'.$piso.'/'.$ramo)['ok']===$esperado);}}
 $preparar($fachada,$trait);
 if(!empty($argv[1])){
  require rtrim($argv[1],'/').'/wp-load.php';$runtime=F3Base_Options::catalogo();$estatico=f3b_catalogo_declarado($temp);
  $a=array_keys($runtime);$b=array_keys($estatico['entradas']);sort($a);sort($b);$ver('mesmas_options_do_wordpress_real',$a===$b);
  foreach($runtime as $option=>$dados){$d=f3b_entradas_de_array(f3b_interior_de_array($estatico['entradas'][$option]));$sub=f3b_entradas_de_array(f3b_interior_de_array($d['subcampos']??'')??'');$a=array_keys($dados['subcampos']??[]);$b=array_keys($sub);sort($a);sort($b);$ver('mesmos_subcampos_'.$option,$a===$b);}
 }
 echo json_encode(['ok'=>!in_array(false,$casos,true),'total'=>count($casos),'casos'=>$casos],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),"\n";
}finally{foreach(glob($destino.'/*')as$f){unlink($f);}rmdir($destino);rmdir(dirname($destino));rmdir(dirname(dirname($destino)));rmdir($temp);}
exit(in_array(false,$casos,true)?1:0);
