<?php
/** Fixture exclusiva de bancada e leitura da mesma projeção usada pela administração. */
declare(strict_types=1);
$site=rtrim($argv[1],'/');if(!is_file($site.'/.f3base-bancada-110')){throw new RuntimeException('Somente bancada descartável.');}require $site.'/wp-load.php';wp_set_current_user(1);
if(($argv[2]??'')==='seed'){
 require_once ABSPATH.'wp-admin/includes/plugin.php';
 // A bancada não consulta servidores de atualização; uma inspeção recente evita esse trabalho alheio ao CSV.
 global $wp_version;set_site_transient('update_core',(object)['updates'=>[],'last_checked'=>time(),'version_checked'=>$wp_version]);
 $versoes=[];foreach(get_plugins()as$arquivo=>$plugin){$versoes[$arquivo]=$plugin['Version'];}set_site_transient('update_plugins',(object)['last_checked'=>time(),'checked'=>$versoes,'response'=>[],'no_update'=>[]]);
 $versoes=[];foreach(wp_get_themes()as$slug=>$tema){$versoes[$slug]=$tema->get('Version');}set_site_transient('update_themes',(object)['last_checked'=>time(),'checked'=>$versoes,'response'=>[],'no_update'=>[]]);
 update_option('timezone_string','America/Sao_Paulo');wp_update_user(['ID'=>1,'user_pass'=>'f3base-local-test-only']);
 $user=get_user_by('login','csv_assinante');$uid=$user?$user->ID:wp_create_user('csv_assinante','f3base-local-test-only','csv-assinante@example.invalid');(new WP_User($uid))->set_role('subscriber');
 F3Base_Atualizacao::migrar();(new F3Base_Modulo_Acessos_Servidor())->garantir_estrutura();F3Base_Modulo_Comportamento::criar_tabela();
 $c=F3Base_Modulo_Acessos_Servidor::config();$c['ligado']=true;F3Base_Options::gravar('f3base_acessos',$c);
 global$wpdb;$tc=$wpdb->prefix.F3Base_Modulo_Comportamento::TABELA;$ta=$wpdb->prefix.F3Base_Modulo_Acessos_Servidor::TABELA;$wpdb->query("DELETE FROM $tc");$wpdb->query("DELETE FROM $ta");
 $hoje=wp_date('Y-m-d');$d=new DateTimeImmutable($hoje,wp_timezone());$ontem=$d->modify('-1 day')->format('Y-m-d');$anteontem=$d->modify('-2 days')->format('Y-m-d');$regra=F3Base_Modulo_Acessos_Servidor::config_hash();$estado=['dias'=>[],'fontes'=>[],'inspecionado_em'=>time(),'config_hash'=>$regra];
 foreach([$anteontem=>2,$ontem=>4,$hoje=>8]as$dia=>$n){
  F3Base_Modulo_Comportamento::somar($dia,'/','f3base_pagina_vista','',$n,0);
  F3Base_Modulo_Comportamento::somar($dia,'/outra/','f3base_pagina_vista','',$n*2,0);
  F3Base_Modulo_Comportamento::somar($dia,'/','f3base_secao_vista','=1+1',$n*3,0);
  if($dia!==$hoje){$estado['dias'][$dia]=['regra'=>$regra,'fuso'=>wp_timezone_string()];$estado['fontes'][$dia]=['regra'=>$regra,'rotacao'=>$dia,'datas_origem'=>[$dia],'offsets'=>['-03:00'],'dias'=>[$dia],'adiados'=>[],'disponivel'=>true,'erro'=>''];foreach([['/','pagina',200,$n],['/robots.txt','arquivo',200,$n*2],['/ausente/','pagina',404,$n*4],['=1+1','arquivo',200,$n]]as[$path,$classe,$status,$contagem]){$wpdb->insert($ta,['dia'=>$dia,'agente'=>'humano','classe_caminho'=>$classe,'caminho'=>$path,'status'=>$status,'metodo'=>'GET','contagem'=>$contagem]);}}
 }
 F3Base_Modulo_Comportamento::somar($hoje,'/novo-csv/','f3base_pagina_vista','',3,0);
 F3Base_Options::gravar('f3base_acessos_estado',$estado);
 $foto=['dia'=>$hoje,'regra'=>$regra,'fuso'=>wp_timezone_string(),'atualizado'=>time(),'erro'=>'','bytes_pendentes'=>0,'ignoradas'=>0,'agregados'=>[
 ['caminho'=>'/','classe_caminho'=>'pagina','agente'=>'humano','status'=>200,'metodo'=>'GET','contagem'=>9],['caminho'=>'/robots.txt','classe_caminho'=>'arquivo','agente'=>'humano','status'=>200,'metodo'=>'GET','contagem'=>3],['caminho'=>'/ausente/','classe_caminho'=>'pagina','agente'=>'humano','status'=>404,'metodo'=>'GET','contagem'=>5],['caminho'=>'=1+1','classe_caminho'=>'arquivo','agente'=>'humano','status'=>200,'metodo'=>'GET','contagem'=>1]]];// Mais caminhos que o limite de apresentação: o CSV precisa declarar o corte real.
 for($i=0;$i<305;$i++){$path='/corte-csv-'.$i.'/';$foto['agregados'][]=['caminho'=>$path,'classe_caminho'=>'arquivo','agente'=>'humano','status'=>200,'metodo'=>'GET','contagem'=>1];foreach([$ontem,$anteontem]as$dia){$wpdb->insert($ta,['dia'=>$dia,'agente'=>'humano','classe_caminho'=>'arquivo','caminho'=>$path,'status'=>200,'metodo'=>'GET','contagem'=>1]);}}
 $foto['agregados'][3]['contagem']=77;
 $foto['agregados'][]=['caminho'=>'/sem-base-csv/','classe_caminho'=>'arquivo','agente'=>'humano','status'=>200,'metodo'=>'GET','contagem'=>99];
 set_transient(F3Base_Acessos_Atuais::CACHE,$foto,3600);
 $post=wp_insert_post(['post_type'=>F3Base_Modulo_Endpoint_Leads::CPT,'post_status'=>'private','post_title'=>'PII_CSV_NOME_PRIVADO','post_content'=>'PII_CSV_CORPO_PRIVADO contato-pii@example.invalid +551199998888']);update_post_meta($post,'email','contato-pii@example.invalid');
 echo wp_json_encode(['hoje'=>$hoje,'ontem'=>$ontem,'anteontem'=>$anteontem,'fuso'=>wp_timezone_string(),'regra'=>$regra]);
}else{
 $f=json_decode($argv[3]??'{}',true,512,JSON_THROW_ON_ERROR);
 if($argv[2]==='comportamento'){$r=F3Base_Medicao_Consultas::comparar_comportamento((int)$f['comparacao_dias'],$f['comparacao_caminho']??'',$f['comparacao_metrica']??'',($f['comparacao_hoje']??'0')==='1');}
 else{$modo=($f['mostrar_todos']??'0')==='1'?'todos':($f['classificacao']??'conteudo');$r=F3Base_Acessos_Relatorio::consultar((int)$f['dias'],$modo,$modo==='inexistentes'||($f['incluir_erros']??'0')==='1',F3Base_Acessos_Atuais::fotografia(),($f['comparacao_hoje']??'0')==='1');}
 echo wp_json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}
