#!/usr/bin/env bash
# Banco novo, pacote anterior real e substituição por ZIP sem reativação.
set -euo pipefail
CACHE_UPGRADE_110="$(realpath "$1")"
OLD_UPGRADE_110="$(realpath "$2")"
NEW_UPGRADE_110="$(realpath "$3")"
OUT_UPGRADE_110="$(realpath -m "$4")"
HERE_UPGRADE_110="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$OUT_UPGRADE_110"
bash "$HERE_UPGRADE_110/../versao-110/preparar-bancada.sh" "$CACHE_UPGRADE_110" "$OLD_UPGRADE_110" > "$OUT_UPGRADE_110/preparacao.txt"
SITE_UPGRADE_110="$(sed -n 's/^Site: //p' "$OUT_UPGRADE_110/preparacao.txt")"
php "$HERE_UPGRADE_110/upgrade-real.php" "$SITE_UPGRADE_110" semear "$OUT_UPGRADE_110/fixture.json" > "$OUT_UPGRADE_110/01-semente.json"
unzip -qo "$NEW_UPGRADE_110" -d "$SITE_UPGRADE_110/wp-content/plugins"
for PHASE_UPGRADE_110 in upgrade desativar inativo reativar verificar_reativada; do
 php "$HERE_UPGRADE_110/upgrade-real.php" "$SITE_UPGRADE_110" "$PHASE_UPGRADE_110" "$OUT_UPGRADE_110/fixture.json" > "$OUT_UPGRADE_110/$PHASE_UPGRADE_110.json"
done
python - "$OUT_UPGRADE_110" "$OLD_UPGRADE_110" "$NEW_UPGRADE_110" <<'PY'
import sys,json,hashlib
from pathlib import Path
out=Path(sys.argv[1]);phases=[]
for name in ['01-semente','upgrade','desativar','inativo','reativar','verificar_reativada']:
 row=json.loads((out/(name+'.json')).read_text());phases.append(row)
result={'versao':'1.10.0','origem_zip_sha256':hashlib.sha256(Path(sys.argv[2]).read_bytes()).hexdigest(),'destino_zip_sha256':hashlib.sha256(Path(sys.argv[3]).read_bytes()).hexdigest(),'total':sum(len(x['casos']) for x in phases),'falhas':sum(sum(not c['ok'] for c in x['casos']) for x in phases),'fases':phases}
(out/'resultado.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='fases'}))
PY
