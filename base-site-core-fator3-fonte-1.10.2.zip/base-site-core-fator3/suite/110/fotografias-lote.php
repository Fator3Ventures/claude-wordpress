<?php
/** Fotografias administrativas em lote não substituem a leitura física da escrita CAS. */
declare(strict_types=1);
$site=rtrim($argv[1],'/');if(!is_file($site.'/.f3base-bancada-110')){throw new RuntimeException('Somente bancada descartável.');}
require $site.'/wp-load.php';
$checks=[];$erros=[];$detalhes=[];
set_error_handler(static function($n,$m,$f,$l)use(&$erros){$erros[]="$n $m $f:$l";return false;});
$ok=static function($v,$nome,$d=null)use(&$checks,&$detalhes){$checks[$nome]=(bool)$v;if(!$v&&$d!==null){$detalhes[$nome]=$d;}};
$escrever=static function($nome,$valor){$r=F3Base_Options::gravar($nome,$valor);if(empty($r['persisted'])){throw new RuntimeException('Fixture não persistiu: '.$nome);}};
$escrever('f3base_ga4_measurement_id','G-LOTE110');
$escrever('f3base_contato',array_merge(F3Base_Options::ler('f3base_contato'),['mensagem_padrao'=>'Fotografia de teste']));
$escrever('f3base_meta_capi_token','segredo-local-descartavel-fotografia');
F3Base_Options::remover('f3base_linkedin_conversion_id');
$nomes=['f3base_ga4_measurement_id','f3base_contato','f3base_meta_capi_token','f3base_linkedin_conversion_id',F3Base_Options::OPTION_PROVENIENCIA];
$individual=[];foreach($nomes as$nome){$individual[$nome]=F3Base_Options::fotografia($nome);}
$queries=[];$medir=static function($q)use(&$queries){$queries[]=$q;return$q;};global$wpdb;
$antes=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name",ARRAY_A);
add_filter('query',$medir);
try{$lote=F3Base_Options::fotografias(array_merge($nomes,['f3base_ga4_measurement_id','siteurl','wp_users',"x' OR 1=1 --",42,false,['f3base_contato']]));}finally{remove_filter('query',$medir);}
$ok(count($queries)===1&&preg_match('/^SELECT option_name,option_value FROM /',$queries[0]??'')===1,'um_select_para_o_lote',$queries);
$ok(count($lote)===count($nomes)&&array_keys($lote)===$nomes,'somente_nomes_proprios_sem_duplicatas');
foreach($nomes as$nome){$ok($lote[$nome]===$individual[$nome],'igual_fotografia_individual_'.$nome);}
$ok(!$lote['f3base_linkedin_conversion_id']['existe']&&$lote['f3base_linkedin_conversion_id']['valor']==='','padrao_ausente_com_revisao');
$ok($lote['f3base_meta_capi_token']['valor']===$individual['f3base_meta_capi_token']['valor']&&strlen($lote['f3base_meta_capi_token']['revisao'])===64&&!str_contains($lote['f3base_meta_capi_token']['revisao'],'segredo'),'segredo_preserva_contrato_interno_sem_vazar_na_revisao');
$ok(!preg_match('/\b(INSERT|UPDATE|DELETE|REPLACE|CREATE|ALTER|DROP)\b/i',implode(';',$queries)),'lote_sem_escrita');
$ok(str_contains($queries[0]??'',$wpdb->options)&&!str_contains(implode(';',$queries),'wp_users')&&!str_contains(implode(';',$queries),'OR 1=1')&&!str_contains(implode(';',$queries),'siteurl'),'tabela_options_fixa_e_nomes_filtrados');
$depois=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name",ARRAY_A);$ok($antes===$depois,'lote_nao_altera_options_cron_procedencia');
$queries=[];add_filter('query',$medir);try{$vazio=F3Base_Options::fotografias(['siteurl',null,42]);}finally{remove_filter('query',$medir);}$ok($vazio===[]&&$queries===[],'lote_sem_nomes_proprios_nao_consulta');
// Mudança física concorrente após a tela, deixando deliberadamente o cache de options antigo.
$antiga=$lote['f3base_ga4_measurement_id'];
$wpdb->update($wpdb->options,['option_value'=>'G-CONCORRENTE110'],['option_name'=>'f3base_ga4_measurement_id']);
$queries=[];add_filter('query',$medir);
try{$recusada=F3Base_Options::gravar('f3base_ga4_measurement_id','G-OBSOLETO110',F3Base_Options::ORIGEM_MANUAL,$antiga['revisao']);}finally{remove_filter('query',$medir);}
$nova=F3Base_Options::fotografia('f3base_ga4_measurement_id');
$ok(empty($recusada['persisted'])&&$recusada['codigo']==='conflito_ou_falha_de_escrita','cas_recusa_revisao_obsoleta');
$ok($nova['valor']==='G-CONCORRENTE110'&&$nova['revisao']!==$antiga['revisao'],'cas_preserva_valor_concorrente_apos_lote');
$ok((bool)array_filter($queries,static fn($q)=>str_starts_with($q,'SELECT option_value FROM ')&&str_contains($q,"option_name = 'f3base_ga4_measurement_id'")),'cas_rele_linha_fisica_apos_lote');
$relido=F3Base_Options::fotografias(['f3base_ga4_measurement_id']);$ok($relido['f3base_ga4_measurement_id']===$nova,'segundo_lote_nao_reutiliza_cache_anterior');
wp_cache_delete('f3base_ga4_measurement_id','options');wp_cache_delete('alloptions','options');
$gravada=F3Base_Options::gravar('f3base_ga4_measurement_id','G-NOVO110',F3Base_Options::ORIGEM_MANUAL,$nova['revisao']);$confirmada=F3Base_Options::fotografia('f3base_ga4_measurement_id');
$ok(!empty($gravada['persisted'])&&$confirmada['valor']==='G-NOVO110'&&$confirmada['revisao']!==$nova['revisao'],'cas_nova_revisao_grava_e_confirma');
$ok($erros===[],'sem_avisos_php',$erros);restore_error_handler();
echo wp_json_encode(['ok'=>!in_array(false,$checks,true),'total'=>count($checks),'checks'=>$checks,'detalhes'=>$detalhes],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit(in_array(false,$checks,true)?1:0);
