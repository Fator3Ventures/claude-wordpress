<?php
/** Fixture para WP-CLI real, somente na bancada local marcada. */
if ( ! is_file( ABSPATH . '/.f3base-bancada-110' ) ) { return; }
add_action( 'init', static function () {
	$caso = getenv( 'F3BASE_CLI_SCENARIO' );
	if ( ! $caso ) { return; }
	$marcador = getenv( 'F3BASE_CLI_MARKER' );
	$registrar = static function () use ( $marcador ) { if ( $marcador ) { file_put_contents( $marcador, "executado\n", FILE_APPEND | LOCK_EX ); } };
	if ( in_array( $caso, array( 'publicacao', 'publicacao404', 'validacao' ), true ) ) {
		$f = F3Base_Options::fotografia( F3Base_Publicacao_Sonda::OPTION ); $v = $f['valor']; $v['last_attempt'] = 0; $v['lease'] = array(); F3Base_Options::gravar( F3Base_Publicacao_Sonda::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
		add_filter( 'pre_http_request', static function () use ( $caso, $registrar ) { $registrar(); return array( 'response' => array( 'code' => 'publicacao404' === $caso ? 404 : 200, 'message' => '' ), 'headers' => array( 'content-type' => 'text/plain' ), 'body' => "# Documento\n", 'cookies' => array() ); }, 1, 3 );
	}
	if ( 'intervalo' === $caso ) {
		$f = F3Base_Options::fotografia( F3Base_Publicacao_Sonda::OPTION ); $v = $f['valor']; $v['last_attempt'] = time(); $v['lease'] = array(); F3Base_Options::gravar( F3Base_Publicacao_Sonda::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
	}
	if ( in_array( $caso, array( 'limite', 'falha', 'reservado' ), true ) ) {
		foreach ( F3Base_Operacao::tarefas() as $t ) { foreach ( $t['hooks'] as $hook ) { wp_clear_scheduled_hook( $hook ); } }
		F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static fn() => array() );
		foreach ( array( F3Base_Modulo_Acessos_Servidor::EVENTO, F3Base_Capi_Fila::EVENTO, F3Base_Robots_Entrega::EVENTO ) as $hook ) {
			F3Base_Operacao::callback( $hook, static function () use ( $caso, $registrar ) { $registrar(); if ( 'falha' === $caso ) { throw new RuntimeException( 'fixture' ); } return array( 'ok' => true ); } );
			wp_schedule_single_event( time() - 5, $hook );
		}
		if ( 'reservado' === $caso ) { F3Base_Options::atualizar_estado( F3Base_Operacao::OPTION, static fn() => array( 'acessos' => array( 'lease' => array( 'id' => 'outro-processo', 'ate' => time() + 120 ), 'ultima' => array() ) ) ); }
	}
}, PHP_INT_MAX );
