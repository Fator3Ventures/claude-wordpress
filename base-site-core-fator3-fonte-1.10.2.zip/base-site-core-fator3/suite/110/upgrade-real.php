<?php
/** Fases do gate de ZIP. Executar apenas sobre bancada descartável e processos independentes. */
declare(strict_types=1);
$site=$argv[1];$fase=$argv[2];$fixture=$argv[3];
if(!is_file($site.'/.f3base-bancada-110'))throw new RuntimeException('Bancada local obrigatória.');
require $site.'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';wp_set_current_user(1);
$checks=[];$warnings=[];
set_error_handler(static function($n,$m,$f,$l)use(&$warnings){if(error_reporting()&$n)$warnings[]=basename($f).':'.$l.' '.$m;return false;});
function ug_check(string $nome,bool $ok):void{global$checks;$checks[]=['caso'=>$nome,'ok'=>$ok];if(!$ok)throw new RuntimeException($nome);}
function ug_cron():array{$r=[];foreach(_get_cron_array() as$t=>$hooks){foreach($hooks as$hook=>$instancias){if(!str_starts_with($hook,'f3base_'))continue;foreach($instancias as$key=>$v)$r[]=['hook'=>$hook,'argumentos'=>$key,'quando'=>(int)$t];}}return$r;}
function ug_gravar(string $nome,$valor):void{$r=F3Base_Options::gravar($nome,$valor);ug_check('persistiu_'.$nome,!empty($r['persisted']));}
function ug_pref(array $f):void{foreach($f['preferencias'] as$k=>$v)ug_check('preservou_'.$k,get_option($k)===$v);}
function ug_emitir():void{global$checks,$warnings,$fase;restore_error_handler();echo wp_json_encode(['fase'=>$fase,'wordpress'=>$GLOBALS['wp_version'],'plugin'=>defined('F3BASE_PLUGIN_VERSAO')?F3BASE_PLUGIN_VERSAO:'inativo','casos'=>$checks,'warnings'=>$warnings],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";}
try{
 if($fase==='semear'){
  ug_check('origem_192',F3BASE_PLUGIN_VERSAO==='1.9.2');
  global$wpdb;ug_check('fila_192_instalada_pela_propria_versao',F3Base_Capi_Fila::instalar());$cols=$wpdb->get_col('SHOW COLUMNS FROM '.F3Base_Capi_Fila::tabela());ug_check('schema_legado_autentico',!in_array('schema_versao',$cols,true));
  $privacy=(int)get_option('wp_page_for_privacy_policy');if($privacy)wp_delete_post($privacy,true);update_option('wp_page_for_privacy_policy',0);
  $prefs=['f3base_contato'=>array_merge(F3Base_Options::ler('f3base_contato'),['whatsapp_e164'=>'5511999999999','mensagem_padrao'=>'Fixture upgrade','flutuante'=>false]),'f3base_ga4_measurement_id'=>'G-UPGRADE110','f3base_meta_pixel_id'=>'111111','f3base_meta_capi_token'=>'fixture-local-sem-envio','f3base_consentimento'=>array_merge(F3Base_Options::ler('f3base_consentimento'),['padrao'=>'pre-aprovado','ttl_dias'=>91]),'f3base_sessao'=>F3Base_Options::ler('f3base_sessao')];
  foreach($prefs as$k=>$v)ug_gravar($k,$v);
  $_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='granted';ug_check('cookie_granted_192',F3Base_Modulo_Consentimento::permite_tags());$_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='denied';ug_check('cookie_denied_192',!F3Base_Modulo_Consentimento::permite_tags());unset($_COOKIE[F3Base_Modulo_Consentimento::COOKIE]);
  $post=wp_insert_post(['post_title'=>'Fixture permanente upgrade','post_status'=>'publish','post_type'=>'page','post_content'=>'Preservar ID e conteúdo.']);
  ug_check('post_fixture_criado',is_int($post)&&$post>0);
  $payload=['data'=>[['event_name'=>'Lead','event_id'=>'upgrade-event-id','user_data'=>['em'=>['fixture-hash']]]]];
  ug_check('fila_legada_criada',F3Base_Capi_Fila::inserir('upgrade-record-id',$payload,3600));$fila=F3Base_Capi_Fila::ler('upgrade-record-id');
  $prefs=array_combine(array_keys($prefs),array_map('get_option',array_keys($prefs)));
  file_put_contents($fixture,wp_json_encode(['preferencias'=>$prefs,'post_id'=>$post,'fila'=>$fila,'plugins'=>get_option('active_plugins')]));
  file_put_contents(WP_CONTENT_DIR.'/mu-plugins/upgrade-observar.php','<?php add_action("activated_plugin",static function($p){if($p==="base-site-core-fator3/base-site-core-fator3.php")file_put_contents(ABSPATH."ativacoes-upgrade.txt","1",FILE_APPEND);});');
 }else{
  $f=json_decode(file_get_contents($fixture),true);
  if($fase==='upgrade'){
   ug_check('versao_110',F3BASE_PLUGIN_VERSAO==='1.10.0');ug_check('permanece_ativo',is_plugin_active('base-site-core-fator3/base-site-core-fator3.php'));
   ug_check('sem_reativacao',!is_file(ABSPATH.'ativacoes-upgrade.txt'));ug_check('migracao_agendada',F3Base_Atualizacao::pronta()||false!==wp_next_scheduled(F3Base_Atualizacao::EVENTO));
   do_action(F3Base_Atualizacao::EVENTO);ug_check('migracao_pelo_hook_real_do_cron',F3Base_Atualizacao::pronta());ug_check('evento_migracao_concluido',false===wp_next_scheduled(F3Base_Atualizacao::EVENTO));
   ug_pref($f);ug_check('post_id_preservado',(bool)get_post($f['post_id']));ug_check('sem_politica_privacidade',F3Base_Modulo_Consentimento::url_politica_opcional()==='');ug_check('sem_implantador',count(array_filter(get_option('active_plugins'),static fn($p)=>str_contains($p,'implantador')))===0);
   ug_check('modo_legado_preservado',!F3Base_Modulo_Consentimento::modo_granular());$_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='granted';ug_check('cookie_granted_preservado',F3Base_Modulo_Consentimento::permite_tags());$_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='denied';ug_check('cookie_denied_preservado',!F3Base_Modulo_Consentimento::permite_tags());unset($_COOKIE[F3Base_Modulo_Consentimento::COOKIE]);
   $r=F3Base_Capi_Fila::ler('upgrade-record-id');ug_check('record_id_event_id_preservados',$r['record_id']===$f['fila']['record_id']&&$r['payload']===$f['fila']['payload']);ug_check('prazo_original_preservado',(int)$r['expira']===(int)$f['fila']['expira']);ug_check('destino_desconhecido_nao_inferido',$r['pixel_id']===''&&$r['estado']==='suspenso');ug_check('sem_autorizacao_capi_inventada',$r['decisao_ref']===''&&$r['politica_versao']==='');
   ug_check('todas_novas_estruturas',F3Base_Atualizacao::verificar_estrutura());
   ug_check('configuracoes_autocontidas',class_exists('F3Base_Admin_Tela')&&wp_get_ability('f3base/config-core-contrato-v1')!==null);
  }elseif($fase==='desativar'){
   F3Base_Cache_Pagina::solicitar();deactivate_plugins('base-site-core-fator3/base-site-core-fator3.php');ug_check('plugin_desativado',!is_plugin_active('base-site-core-fator3/base-site-core-fator3.php'));
   register_shutdown_function(static function(){try{ug_check('shutdown_nao_recriou_agendas',ug_cron()===[]);ug_emitir();}catch(Throwable$e){fwrite(STDERR,$e->getMessage()."\n");exit(1);}});return;
  }elseif($fase==='inativo'){
   ug_check('nenhuma_classe_carregada',!class_exists('F3Base_Site_Core'));ug_check('nenhuma_agenda_apos_nova_requisicao',ug_cron()===[]);ug_pref($f);ug_check('post_existe_desativado',(bool)get_post($f['post_id']));
  }elseif($fase==='reativar'){
   $r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');ug_check('reativacao_sem_erro',!is_wp_error($r));ug_check('estrutura_reativada',F3Base_Atualizacao::pronta());ug_pref($f);
  }elseif($fase==='verificar_reativada'){
   ug_check('ativa_apos_reativar',is_plugin_active('base-site-core-fator3/base-site-core-fator3.php'));ug_pref($f);
   $agenda=ug_cron();$unicos=[];foreach($agenda as$item)$unicos[]=$item['hook'].'|'.$item['argumentos'];ug_check('agendas_sem_duplicacao',count($unicos)===count(array_unique($unicos)));ug_check('agenda_retoma',count($agenda)>0);ug_check('reativacao_unica',file_get_contents(ABSPATH.'ativacoes-upgrade.txt')==='1');
   $r=F3Base_Capi_Fila::ler('upgrade-record-id');ug_check('fila_nao_sumiu',(bool)$r&&$r['estado']==='suspenso');
  }else throw new RuntimeException('Fase desconhecida');
 }
 ug_check('zero_avisos_php',!$warnings);ug_emitir();
}catch(Throwable$e){ug_emitir();fwrite(STDERR,$e->getMessage()."\n");exit(1);}
