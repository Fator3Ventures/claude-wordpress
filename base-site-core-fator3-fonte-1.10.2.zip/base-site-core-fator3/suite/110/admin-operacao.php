<?php
/** Regressões de interface, CAS e operação pelo WordPress real. */
declare(strict_types=1);
require rtrim($argv[1],'/').'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/template.php';
wp_set_current_user(1);
$cases=[];$warnings=[];
set_error_handler(static function($n,$m,$f,$l)use(&$warnings){if(error_reporting()&$n)$warnings[]=basename($f).':'.$l.' '.$m;return false;});
function ao_assert(bool $ok,string $msg):void{if(!$ok)throw new RuntimeException($msg);}
function ao_case(string $name,callable $test):void{global$cases;try{$test();$cases[]=['caso'=>$name,'estado'=>'OK'];}catch(Throwable$e){$cases[]=['caso'=>$name,'estado'=>'FALHA','motivo'=>$e->getMessage()];}}
add_filter('pre_http_request',static fn()=>new WP_Error('teste_sem_rede','HTTP externo bloqueado na bancada.'),1);
ao_case('admin_conflito_por_option_e_resultado_parcial',static function(){
 $a='f3base_contato';$b='f3base_ga4_measurement_id';$fa=F3Base_Options::fotografia($a);$fb=F3Base_Options::fotografia($b);
 F3Base_Options::gravar($a,array_merge($fa['valor'],['mensagem_padrao'=>'Alteração concorrente']));
 $r=F3Base_Admin_Tela::processar_envio([$a=>array_merge($fa['valor'],['mensagem_padrao'=>'Minha edição']),$b=>'G-ADMIN110'],[$a=>$fa['revisao'],$b=>$fb['revisao']]);
 $r=array_column($r,null,'nome');ao_assert(!$r[$a]['persisted']&&$r[$b]['persisted'],'Seção parcial não distingue resultados');
 ao_assert(F3Base_Options::ler($a)['mensagem_padrao']==='Alteração concorrente','Sobrescreveu valor concorrente');
 ao_assert(F3Base_Options::procedencia($b)['canal']==='admin','Canal administrativo não registrado');
 ao_assert(!array_key_exists('lido',$r[$b]),'Confirmação inclui valor salvo');
 $r=F3Base_Admin_Tela::processar_envio([$b=>'G-SEMREVISAO'],[]);
 ao_assert(!$r[0]['persisted'],'Envio sem revisão foi gravado');
 F3Base_Options::gravar($a,$fa['valor']);F3Base_Options::gravar($b,$fb['valor']);
});
ao_case('admin_json_recusado_sem_gravacao',static function(){
 $f=F3Base_Options::fotografia('f3base_sessao');
 $r=F3Base_Admin_Tela::processar_envio(['f3base_sessao'=>['regras'=>'[invalido']],['f3base_sessao'=>$f['revisao']]);
 ao_assert(!$r[0]['persisted']&&$r[0]['codigo']==='json_invalido','JSON inválido não recusado');
 ao_assert($f['revisao']===F3Base_Options::revisao('f3base_sessao'),'JSON inválido alterou a opção');
});
ao_case('formularios_por_secao_e_revisoes',static function(){
 unset($_GET['aba']);ob_start();try{F3Base_Admin_Tela::render();$html=ob_get_contents();}finally{ob_end_clean();}
 $dom=new DOMDocument();@$dom->loadHTML('<?xml encoding="UTF-8">'.$html);$xp=new DOMXPath($dom);
 $forms=$xp->query('//form[contains(concat(" ",normalize-space(@class)," ")," f3base-form ")]');
 ao_assert($forms->length>=4,'Formulários não separados por seção');
 foreach($forms as$form){ao_assert($xp->query('.//section',$form)->length===1,'Formulário salva várias seções');ao_assert($xp->query('.//input[starts-with(@name,"f3base_revisao[")]',$form)->length>0,'Revisão ausente');ao_assert($xp->query('.//input[@name="_wpnonce"]',$form)->length===1,'Nonce ausente ou duplicado');}
});
ao_case('saude_readonly_e_site_health',static function(){
 global $wpdb;
 $foto=static fn()=>array_column($wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} ORDER BY option_name",ARRAY_A),'option_value','option_name');
 $llms=F3Base_Options::ler('f3base_llms');
 F3Base_Options::gravar('f3base_llms',array_merge($llms,['ligado'=>true,'full'=>true]));
 try {
  $a=wp_get_ability('f3base/saude-ler');ao_assert($a!==null,'Saúde não registrada');
  ao_assert(($a->get_meta()['annotations']['readonly']??false)===true,'Habilidade não declara readonly');
  $testes=apply_filters('site_status_tests',[]);ao_assert(isset($testes['direct']['f3base_estado']),'Saúde do Site não integrada');
  $consultas=[
   'ability'=>static fn()=>$a->execute([]),
   'site_health'=>static fn()=>call_user_func($testes['direct']['f3base_estado']['test']),
   'debug_information'=>static fn()=>apply_filters('debug_information',[]),
  ];
  foreach($consultas as $nome=>$consultar){
   // Cada entrada começa fria, para não esconder gravação por aquecimento anterior.
   foreach($wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '_transient_f3base_publico_%'") as $chave){delete_transient(substr($chave,11));}
   $before=$foto();$mutacoes=[];$http=0;
   $vigiar=static function($sql)use(&$mutacoes){if(preg_match('/^\s*(INSERT|REPLACE|UPDATE|DELETE|CREATE|ALTER|DROP)/i',$sql))$mutacoes[]=array_map(static fn($t)=>($t['class']??'').($t['type']??'').$t['function'],debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,14));return$sql;};
   $rede=static function($pre)use(&$http){++$http;return new WP_Error('saude_nao_deve_sondar','Saúde não deve executar HTTP.');};
   add_filter('query',$vigiar);add_filter('pre_http_request',$rede,0);
   try{$r=$consultar();}finally{remove_filter('query',$vigiar);remove_filter('pre_http_request',$rede,0);}
   $after=$foto();$changed=[];foreach(array_unique(array_merge(array_keys($before),array_keys($after)))as$k){if(($before[$k]??null)!==($after[$k]??null))$changed[]=$k;}
   ao_assert(!$changed&&!$mutacoes,$nome.' alterou estado: '.wp_json_encode(['options'=>$changed,'mutacoes'=>$mutacoes]));ao_assert($http===0,$nome.' tentou HTTP');
   if($nome==='ability'){
    ao_assert(!is_wp_error($r)&&isset($r['agenda'],$r['modulos']),'Saúde inválida');
    $valid=rest_validate_value_from_schema($r,$a->get_output_schema());ao_assert(!is_wp_error($valid),'Schema da saúde inválido');rest_sanitize_value_from_schema($r,$a->get_output_schema());
   }elseif($nome==='site_health'){ao_assert(in_array($r['status'],['good','recommended'],true),'Estado de saúde inválido');}
   else{ao_assert(isset($r['f3base']),'Informações técnicas não integradas');}
  }
 }finally{F3Base_Options::gravar('f3base_llms',$llms);}
});
ao_case('operacao_reserva_limite_e_allowlist',static function(){
 $count=0;$hook=F3Base_Modulo_Cadencia_Relatorio::HOOK;
 $wrapper=F3Base_Operacao::callback($hook,static function()use(&$count){++$count;});
 $estado=F3Base_Options::fotografia(F3Base_Operacao::OPTION);$v=(array)$estado['valor'];$v['cadencia']['lease']=['id'=>'outro-processo','ate'=>time()+60];
 F3Base_Options::gravar(F3Base_Operacao::OPTION,$v,F3Base_Options::ORIGEM_PADRAO);
 $r=F3Base_Operacao::executar_uma('cadencia','teste',false);ao_assert($r['status']==='reservado'&&$count===0,'Reserva alheia ignorada');
 F3Base_Options::gravar(F3Base_Operacao::OPTION,$estado['valor'],F3Base_Options::ORIGEM_PADRAO);
 $r=F3Base_Operacao::executar_uma('cadencia','teste',false);ao_assert($r['ok']&&$r['confirmado_localmente']&&$count===1,'Executor não confirmou lote');
 ao_assert(!F3Base_Operacao::executar_pendentes(['tarefas'=>['delete_everything']])['ok'],'Tarefa arbitrária aceita');
 wp_set_current_user(0);$r=wp_get_ability('f3base/executar-pendentes')->execute([]);wp_set_current_user(1);ao_assert(is_wp_error($r),'Executor anônimo autorizado');
});
ao_case('migracao_com_prova_local',static function(){
 $r=F3Base_Atualizacao::migrar();ao_assert($r['ok']&&F3Base_Atualizacao::pronta(),'Estrutura não confirmada');
});
restore_error_handler();$cases[]=['caso'=>'avisos_php','estado'=>$warnings?'FALHA':'OK','avisos'=>$warnings];
echo wp_json_encode(['wordpress'=>$GLOBALS['wp_version'],'casos'=>$cases],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
exit(count(array_filter($cases,static fn($c)=>$c['estado']!=='OK'))?1:0);
