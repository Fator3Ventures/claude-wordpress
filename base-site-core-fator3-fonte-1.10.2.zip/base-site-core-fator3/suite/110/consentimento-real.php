<?php
/** Integração executada em cópia local do WordPress 6.9 com o driver da operação. */
declare(strict_types=1);
require rtrim($argv[1],'/').'/wp-load.php';
function verificar($condicao,string $mensagem):void{ if(!$condicao){throw new RuntimeException($mensagem);} }
$erros=[];
set_error_handler(static function($n,$m,$f,$l)use(&$erros){$erros[]="$n $m $f:$l";return false;});
add_filter('pre_http_request',static function(){return new WP_Error('fixture_sem_rede','Testes locais não enviam requisições externas.');});
$antes=F3Base_Options::ler('f3base_consentimento');
$config=array_merge($antes,['modo'=>'granular','politica_versao'=>'teste-110','gtm_separacao_verificada'=>false]);
$ids=[];$pixel_antes=F3Base_Options::ler('f3base_meta_pixel_id');$token_antes=F3Base_Options::ler('f3base_meta_capi_token');
try {
 F3Base_Consentimento_Decisoes::instalar();F3Base_Capi_Fila::instalar();
 $r=F3Base_Options::gravar('f3base_consentimento',$config);verificar(!empty($r['persisted']),'configuração granular não persistiu');
 $v=F3Base_Modulo_Consentimento::politica_versao();
 $chamar=static function(array $dados,string $origem=''){
  $request=new WP_REST_Request('POST','/'.F3BASE_REST_NAMESPACE.'/consentimento');
  $request->set_header('Content-Type','application/json');$request->set_header('X-F3Base-Consentimento','1');$request->set_header('Origin',$origem?:home_url());$request->set_body(wp_json_encode($dados));
  return rest_do_request($request);
 };
 $base=['medicao'=>true,'publicidade'=>false,'politica_versao'=>$v];
 verificar(403===$chamar($base,'https://outro.example')->get_status(),'origem estrangeira aceita');
 verificar(400===$chamar(array_merge($base,['medicao'=>'true']))->get_status(),'booleano inválido aceito');
 $_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='granted';verificar(!F3Base_Modulo_Consentimento::permite_categoria('publicidade'),'granted legado promovido');
 $_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='%E0%A4%A';verificar(!F3Base_Modulo_Consentimento::permite_categoria('medicao'),'cookie malformado autorizado');
 $r=$chamar($base);verificar(200===$r->get_status(),'decisão parcial falhou: '.wp_json_encode($r->get_data()));$parcial=$r->get_data();
 $_COOKIE[F3Base_Modulo_Consentimento::COOKIE]=wp_json_encode(['v'=>$v,'comprovante'=>$parcial['comprovante'],'medicao'=>true,'publicidade'=>false]);
 verificar(F3Base_Modulo_Consentimento::permite_categoria('medicao'),'medição não autorizada');verificar(!F3Base_Modulo_Consentimento::permite_categoria('publicidade'),'publicidade indevida');
 $ref=F3Base_Modulo_Consentimento::referencia_confirmada();verificar(strlen($ref['decisao_ref'])===64,'referência incorreta');
 global $wpdb;$t=$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA;
 verificar($wpdb->get_var($wpdb->prepare("SELECT ref FROM $t WHERE ref=%s",$parcial['comprovante']))===null,'comprovante bruto guardado');
 $r=$chamar(['medicao'=>true,'publicidade'=>true,'politica_versao'=>$v,'comprovante_anterior'=>$parcial['comprovante']]);$total=$r->get_data();verificar(!empty($total['persisted']),'nova decisão falhou');
 verificar(!F3Base_Consentimento_Decisoes::permite($ref['decisao_ref'],$v,'medicao'),'decisão anterior não revogada');
 $ref=['decisao_ref'=>F3Base_Consentimento_Decisoes::referencia($total['comprovante']),'politica_versao'=>$v];
 verificar(F3Base_Consentimento_Decisoes::permite_capi($ref['decisao_ref'],$v),'CAPI não permitido por decisão');
 $id='consentimento-teste-'.wp_generate_uuid4();$ids[]=$id;
 verificar(F3Base_Capi_Fila::inserir($id,['teste'=>true],3600,'123',$ref),'fila não inseriu');
 $reserva=F3Base_Capi_Fila::reservar($id);verificar(is_array($reserva),'reserva não concedida');
 $r=$chamar(['medicao'=>false,'publicidade'=>false,'politica_versao'=>$v,'comprovante_anterior'=>$total['comprovante']]);$revogado=$r->get_data();
 verificar(!empty($revogado['persisted'])&&!empty($revogado['revogacao_confirmada']),'revogação não confirmada');
 verificar(!F3Base_Consentimento_Decisoes::permite_capi($ref['decisao_ref'],$v),'CAPI autorizado após revogação');
 $fila=F3Base_Capi_Fila::ler($id);verificar((int)$fila['cancelado']>0&&''===$fila['payload'],'reserva não cancelada/limpa');
 verificar(!F3Base_Consentimento_Decisoes::permite_capi('',''),'fila antiga sem decisão autorizada');

 // A revogação depois da reserva de envio informa HTTP já iniciado, sem prometer desfazer entrega.
 F3Base_Options::gravar('f3base_meta_pixel_id','123');F3Base_Options::gravar('f3base_meta_capi_token','fixture-local-sem-rede');
 $novo=$chamar(['medicao'=>false,'publicidade'=>true,'politica_versao'=>$v])->get_data();
 $ref2=['decisao_ref'=>F3Base_Consentimento_Decisoes::referencia($novo['comprovante']),'politica_versao'=>$v];
 $id2='consentimento-http-'.wp_generate_uuid4();$ids[]=$id2;verificar(F3Base_Capi_Fila::inserir($id2,['teste'=>true],3600,'123',$ref2),'fila HTTP não inseriu');
 $reservado=F3Base_Capi_Fila::reservar($id2);$iniciado=F3Base_Capi_Fila::iniciar_envio($reservado);verificar(!empty($iniciado['ok']),'envio elegível não reservado');
 $retorno=$chamar(['medicao'=>false,'publicidade'=>false,'politica_versao'=>$v,'comprovante_anterior'=>$novo['comprovante']])->get_data();
 verificar(1===$retorno['http_iniciado'],'revogação omitiu HTTP iniciado');verificar('cancelando'===F3Base_Capi_Fila::ler($id2)['estado'],'estado em curso perdido');
 $config['gtm_separacao_verificada']=true;F3Base_Options::gravar('f3base_consentimento',$config);verificar($v!==F3Base_Modulo_Consentimento::politica_versao(),'mudança de política não altera assinatura efetiva');
 verificar(!$erros,'avisos PHP: '.implode(';',$erros));
 echo "PASS N03: WordPress real, SQLite, grant parcial, origem, schema, recibo hash, revogação com reserva CAPI e versão efetiva.\n";
} finally {
 F3Base_Options::gravar('f3base_consentimento',$antes);F3Base_Options::gravar('f3base_meta_pixel_id',$pixel_antes);F3Base_Options::gravar('f3base_meta_capi_token',$token_antes);
 foreach($ids as $id){$wpdb->delete(F3Base_Capi_Fila::tabela(),['record_id'=>$id]);}
 unset($_COOKIE[F3Base_Modulo_Consentimento::COOKIE]);restore_error_handler();
}
