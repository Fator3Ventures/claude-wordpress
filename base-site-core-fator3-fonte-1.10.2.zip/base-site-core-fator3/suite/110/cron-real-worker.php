<?php
/** Fixtures e inspeção; o trabalho propriamente dito só roda em /wp-cron.php por HTTP. */
declare( strict_types = 1 );
$site = getenv( 'F3BASE_SITE' );
if ( ! $site || ! is_file( $site . '/.f3base-bancada-110' ) ) { exit( 2 ); }
require $site . '/wp-load.php';
if ( 'local' !== wp_get_environment_type() || ! defined( 'DISABLE_WP_CRON' ) || ! DISABLE_WP_CRON ) { exit( 3 ); }
wp_set_current_user( 1 );
$mode = $argv[1] ?? '';
function cron_real_require( bool $ok, string $message ): void { if ( ! $ok ) { throw new RuntimeException( $message ); } }
if ( 'preparar' === $mode ) {
	update_option( 'timezone_string', 'America/Sao_Paulo' );
	update_option( 'blog_public', 1 );
	F3Base_Atualizacao::migrar();
	cron_real_require( F3Base_Atualizacao::pronta(), 'Migração da bancada incompleta.' );
	$today = new DateTimeImmutable( 'today', wp_timezone() );
	$yesterday = $today->modify( '-1 day' );
	$folder = $site . '/fixture-cron-logs';
	wp_mkdir_p( $folder );
	$line = static function( DateTimeImmutable $day, string $path ): string {
		return '127.0.0.1 - - [' . $day->setTime( 12, 0 )->format( 'd/M/Y:H:i:s O' ) . '] "GET ' . $path . ' HTTP/1.1" 200 123 "-" "Mozilla/5.0"' . "\n";
	};
	file_put_contents( $folder . '/access.log.' . $yesterday->format( 'Y-m-d' ), str_repeat( $line( $yesterday, '/fixture-cron-ontem/' ), 3 ) );
	file_put_contents( $folder . '/access.log.' . $today->format( 'Y-m-d' ), str_repeat( $line( $today, '/fixture-cron-hoje/' ), 7 ) );
	file_put_contents( $folder . '/access.log', str_repeat( $line( $today, '/fixture-cron-atual/' ), 11 ) );
	$c = F3Base_Modulo_Acessos_Servidor::config();
	$c['ligado'] = true; $c['padrao_do_log'] = $folder . '/access.log.*';
	cron_real_require( ! empty( F3Base_Options::gravar( 'f3base_acessos', $c )['persisted'] ), 'Configuração de acessos recusada.' );
	cron_real_require( ! empty( F3Base_Options::gravar( 'f3base_acessos_estado', array() )['persisted'] ), 'Estado de acessos não zerado.' );
	// O clone tem outra raiz: inicia um ciclo próprio, sem reutilizar a identidade do template.
	cron_real_require( ! file_exists( $site . '/robots.txt' ), 'Fixture exige raiz sem robots físico prévio.' );
	cron_real_require( ! empty( F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, array() )['persisted'] ), 'Ciclo de robots não inicializado.' );
	cron_real_require( ! empty( F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) )['persisted'] ), 'Configuração de robots recusada.' );
	F3Base_Options::gravar( F3Base_Operacao::OPTION, array() );
	F3Base_Options::gravar( F3Base_Cache_Evidencia::OPTION, array() );
	F3Base_Options::gravar( F3Base_Cache_Evidencia::TRAVAS, array() );
	delete_transient( 'doing_cron' );
	$fixture = array( 'hoje' => $today->format( 'Y-m-d' ), 'ontem' => $yesterday->format( 'Y-m-d' ), 'configurado_em' => time() );
	file_put_contents( $site . '/fixture-cron.json', wp_json_encode( $fixture ) );
	echo wp_json_encode( array( 'ok' => true, 'fixture' => $fixture, 'perfil_cache_cli' => F3Base_Cache_Pagina::perfil() ) ) . "\n";
	return;
}
if ( 'agendar' === $mode ) {
	$due = time() - 10;
	foreach ( array( F3Base_Modulo_Acessos_Servidor::EVENTO, F3Base_Modulo_Acessos_Servidor::CONTINUAR, F3Base_Robots_Entrega::EVENTO, F3Base_Cache_Pagina::CRON ) as $hook ) { wp_clear_scheduled_hook( $hook ); }
	// Adia somente na bancada os demais eventos vencidos, que poderiam consultar wordpress.org.
	// Não altera DISABLE_WP_CRON, callbacks nem o comportamento dos três eventos sob teste.
	foreach ( _get_cron_array() as $timestamp => $hooks ) {
		if ( $timestamp > time() ) { continue; }
		foreach ( $hooks as $hook => $instances ) {
			foreach ( $instances as $event ) {
				wp_unschedule_event( $timestamp, $hook, $event['args'] );
				if ( $event['schedule'] ) { wp_schedule_event( time() + DAY_IN_SECONDS, $event['schedule'], $hook, $event['args'] ); }
				else { wp_schedule_single_event( time() + DAY_IN_SECONDS, $hook, $event['args'] ); }
			}
		}
	}
	$events = array( F3Base_Modulo_Acessos_Servidor::EVENTO => 'daily', F3Base_Robots_Entrega::EVENTO => '', F3Base_Cache_Pagina::CRON => 'hourly' );
	foreach ( $events as $hook => $recurrence ) {
		$r = $recurrence ? wp_schedule_event( $due, $recurrence, $hook, array(), true ) : wp_schedule_single_event( $due, $hook, array(), true );
		cron_real_require( ! is_wp_error( $r ) && $r && wp_next_scheduled( $hook ) === $due, 'Evento não confirmado: ' . $hook );
	}
	echo wp_json_encode( array( 'ok' => true, 'vencido_em' => $due, 'hooks' => array_keys( $events ) ) ) . "\n";
	return;
}
if ( 'inspecionar' === $mode ) {
	global $wpdb;
	$f = json_decode( file_get_contents( $site . '/fixture-cron.json' ), true );
	$t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
	$counts = array();
	foreach ( array( 'ontem', 'hoje' ) as $key ) { $counts[ $key ] = F3Base_Modulo_Acessos_Servidor::tabela_pronta() ? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT SUM(contagem) FROM %i WHERE dia=%s AND caminho LIKE %s', $t, $f[ $key ], '/fixture-cron-%' ) ) : 0; }
	$robots = F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION )['entrega'] ?? array();
	$cache = F3Base_Cache_Evidencia::ler();
	$access = F3Base_Options::ler( 'f3base_acessos_estado' );
	$agenda = array_intersect_key( F3Base_Operacao::agenda(), array_flip( array( 'acessos', 'robots', 'cache' ) ) );
	$daily = wp_get_scheduled_event( F3Base_Modulo_Acessos_Servidor::EVENTO );
	echo wp_json_encode( array( 'contagens' => $counts, 'robots' => $robots, 'cache' => $cache, 'acessos' => array_intersect_key( $access, array_flip( array( 'tentativa', 'ultima_soma', 'erro', 'pendentes', 'ultima' ) ) ), 'agenda' => $agenda, 'coleta_diaria' => $daily ? array( 'quando' => $daily->timestamp, 'recorrencia' => $daily->schedule, 'intervalo' => $daily->interval ) : array(), 'perfil_cache_cli' => F3Base_Cache_Pagina::perfil(), 'versao_core' => F3BASE_PLUGIN_VERSAO, 'wordpress' => $GLOBALS['wp_version'], 'php' => PHP_VERSION, 'disable_wp_cron' => DISABLE_WP_CRON ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n";
	return;
}
throw new RuntimeException( 'Modo de fixture desconhecido.' );
