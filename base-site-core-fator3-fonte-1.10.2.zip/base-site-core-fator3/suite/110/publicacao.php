<?php
/** Regressões C04/F05/F06/N08 em WordPress real; exclusivamente na bancada marcada. */
declare( strict_types = 1 );
$site = getenv( 'F3BASE_SITE' );
if ( ! $site || ! is_file( $site . '/.f3base-bancada-110' ) ) { fwrite( STDERR, "Bancada descartável obrigatória.\n" ); exit( 2 ); }
require $site . '/wp-load.php';
foreach ( array( 'adaptador-yoast' => 'F3Base_Adaptador_Yoast', 'llms-conversor' => 'F3Base_Llms_Conversor', 'publicacao-sonda' => 'F3Base_Publicacao_Sonda' ) as $c => $classe ) { if ( ! class_exists( $classe ) ) { require_once dirname( __DIR__, 2 ) . '/fontes/plugin/includes/class-f3base-' . $c . '.php'; } }
wp_set_current_user( 1 );
$falhas = 0;
function f3p_exigir( bool $ok, string $motivo ): void { if ( ! $ok ) { throw new RuntimeException( $motivo ); } }
function f3p_teste( string $nome, callable $teste ): void { global $falhas; try { $teste(); echo wp_json_encode( array( 'teste' => $nome, 'ok' => true ) ) . "\n"; } catch ( Throwable $e ) { ++$falhas; echo wp_json_encode( array( 'teste' => $nome, 'ok' => false, 'erro' => $e->getMessage() ) ) . "\n"; } }
function f3p_resposta( int $status, string $body = '', array $headers = array() ): array { return array( 'response' => array( 'code' => $status, 'message' => '' ), 'headers' => $headers, 'body' => $body, 'cookies' => array(), 'filename' => null ); }

f3p_teste( 'C04_edit_lock_nao_invalida_geracao', function () {
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'C04 edit lock', 'post_content' => 'Visível' ) );
	$modulo = new F3Base_Modulo_Cache_Publico(); $antes = get_transient( F3Base_Modulo_Cache_Publico::GERACAO );
	$modulo->meta_alterado( 1, $id, '_edit_lock', '123:1' );
	f3p_exigir( $antes === get_transient( F3Base_Modulo_Cache_Publico::GERACAO ), 'Edit lock invalidou geração.' );
	$modulo->meta_alterado( 1, $id, '_tema_titulo', 'Novo' );
	f3p_exigir( $antes !== get_transient( F3Base_Modulo_Cache_Publico::GERACAO ), 'Meta pública desconhecida ignorada.' );
	wp_delete_post( $id, true );
} );
f3p_teste( 'C04_privacidade_purga_WPSC_antes_de_retornar', function () {
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Purga imediata' ) );
	$depois = get_post( $id ); $depois->post_status = 'private';
	$chamadas = 0; $capturar = function () use ( &$chamadas ) { ++$chamadas; }; add_action( 'wp_cache_cleared', $capturar );
	try {
		( new F3Base_Modulo_Cache_Publico() )->visibilidade_alterada( 'private', 'publish', $depois );
		f3p_exigir( $chamadas > 0 && empty( F3Base_Cache_Pagina::estado()['pendente'] ), 'Mudança de visibilidade adiou a limpeza do provedor.' );
	} finally { remove_action( 'wp_cache_cleared', $capturar ); wp_delete_post( $id, true ); }
} );
f3p_teste( 'C04_diff_yoast_operacional_e_publico', function () {
	f3p_exigir( ! F3Base_Adaptador_Yoast::opcao_publica_alterada( 'wpseo', array( 'version' => '1', 'enable_llms_txt' => true ), array( 'version' => '2', 'enable_llms_txt' => true ) ), 'Versão purga conteúdo.' );
	f3p_exigir( F3Base_Adaptador_Yoast::opcao_publica_alterada( 'wpseo', array( 'enable_llms_txt' => false ), array( 'enable_llms_txt' => true ) ), 'Publicação llms ignorada.' );
	f3p_exigir( F3Base_Adaptador_Yoast::opcao_publica_alterada( 'wpseo_titles', array( 'noindex-page' => false ), array( 'noindex-page' => true ) ), 'Noindex ignorado.' );
	f3p_exigir( F3Base_Adaptador_Yoast::opcao_publica_alterada( 'wpseo', array( 'novo-campo' => 'a' ), array( 'novo-campo' => 'b' ) ), 'Chave desconhecida não foi conservadora.' );
} );
f3p_teste( 'F06_tabela_lista_shortcodes_sem_efeito', function () {
	$executou = false; add_shortcode( 'f3p_efeito', function () use ( &$executou ) { $executou = true; return 'MUTAÇÃO'; } );
	$r = F3Base_Llms_Conversor::converter( '<table><thead><tr><th>A</th><th>B</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr></tbody></table><ol start="3"><li>Maior<ul><li>Menor</li></ul></li></ol>[f3p_efeito]<script>SEGREDO</script>', home_url( '/' ) );
	remove_shortcode( 'f3p_efeito' );
	$complexa = F3Base_Llms_Conversor::converter( '<table><caption>Legenda</caption><tr><th>Pai</th><th>Valor</th></tr><tr><td rowspan="2">Grupo</td><td>1</td></tr><tr><td>2</td></tr></table>', home_url( '/' ) );
	f3p_exigir( $complexa['completo'] && str_contains( $complexa['texto'], 'Legenda' ) && str_contains( $complexa['texto'], '| Grupo | 2 |' ), 'Tabela com rowspan/caption perdeu associação.' );
	f3p_exigir( $r['completo'] && ! $executou && str_contains( $r['texto'], '| --- | --- |' ) && str_contains( $r['texto'], '3. Maior' ) && str_contains( $r['texto'], '- Menor' ) && ! str_contains( $r['texto'], 'SEGREDO' ), 'Tabela/lista/conversão sem efeitos falhou: ' . wp_json_encode( $r ) );
} );
f3p_teste( 'F06_referencia_privada_ciclo_e_volume', function () {
	$publico = get_option( 'blog_public' ); update_option( 'blog_public', '1' );
	$id = wp_insert_post( array( 'post_type' => 'wp_block', 'post_status' => 'publish', 'post_title' => 'Bloco de teste', 'post_content' => '<!-- wp:paragraph --><p>PUBLICOREF</p><!-- /wp:paragraph -->' ) );
	try {
		$ref = '<!-- wp:block {"ref":' . $id . '} /-->';
		$r = F3Base_Llms_Conversor::converter( $ref, home_url( '/' ) );
		f3p_exigir( $r['completo'] && str_contains( $r['texto'], 'PUBLICOREF' ), 'Referência publicada não resolvida: ' . wp_json_encode( array( $r, get_post( $id ), get_option( 'blog_public' ) ) ) );
		update_post_meta( $id, F3Base_Chaves_Seo::NOINDEX, '1' );
		$bloqueado = F3Base_Llms_Conversor::converter( $ref, home_url( '/' ) );
		f3p_exigir( ! str_contains( $bloqueado['texto'], 'PUBLICOREF' ), 'Referência noindex explícita vazou.' );
		delete_post_meta( $id, F3Base_Chaves_Seo::NOINDEX );
		wp_update_post( array( 'ID' => $id, 'post_status' => 'private', 'post_content' => 'SEGREDOREF' ) );
		$r = F3Base_Llms_Conversor::converter( $ref, home_url( '/' ) );
		f3p_exigir( ! str_contains( $r['texto'], 'SEGREDOREF' ) && ! empty( $r['avisos'] ), 'Conteúdo protegido vazou ou omissão foi silenciosa.' );
		wp_update_post( array( 'ID' => $id, 'post_status' => 'publish', 'post_content' => $ref ) );
		$r = F3Base_Llms_Conversor::converter( $ref, home_url( '/' ) );
		f3p_exigir( ! $r['completo'] && '' === $r['texto'] && in_array( 'referencia_circular_ou_invalida', $r['erros'], true ), 'Ciclo não explicitou documento incompleto.' );
		$r = F3Base_Llms_Conversor::converter( str_repeat( 'x', F3Base_Llms_Conversor::MAX_BYTES + 1 ), home_url( '/' ) );
		f3p_exigir( ! $r['completo'] && '' === $r['texto'], 'Documento truncado foi publicado como completo.' );
	} finally { wp_delete_post( $id, true ); update_option( 'blog_public', $publico ); }
} );
f3p_teste( 'F06_bloco_dinamico_desconhecido', function () {
	$rodou = false;
	register_block_type( 'f3p/dinamico', array( 'render_callback' => function () use ( &$rodou ) { $rodou = true; return 'EFEITO'; } ) );
	$r = F3Base_Llms_Conversor::converter( '<!-- wp:f3p/dinamico /-->', home_url( '/' ) );
	unregister_block_type( 'f3p/dinamico' );
	f3p_exigir( ! $r['completo'] && ! $rodou && '' === $r['texto'], 'Bloco dinâmico foi executado ou omitido como completo.' );
	$r = F3Base_Llms_Conversor::converter( '<!-- wp:f3p/estatico --><p>TEXTO SALVO</p><!-- /wp:f3p/estatico -->', home_url( '/' ) );
	f3p_exigir( $r['completo'] && str_contains( $r['texto'], 'TEXTO SALVO' ) && $r['avisos'], 'Bloco desconhecido não preservou HTML com aviso.' );
} );
f3p_teste( 'N08_HEAD_304_truncado_assercoes', function () {
	$a = array( array( 'tipo' => 'nao_contem', 'valor' => 'SEGREDO' ) );
	foreach ( array( array( 'HEAD', 200 ), array( 'GET', 304 ) ) as $caso ) {
		$r = F3Base_Publicacao_Sonda::resultado( f3p_resposta( $caso[1] ), $caso[0], 1024, $a );
		f3p_exigir( 'inconclusivo' === $r['assercoes'][0]['estado'] && '' === $r['sha256'] && ! $r['completa'], 'Ausência de representação confirmou conteúdo.' );
	}
	$r = F3Base_Publicacao_Sonda::resultado( f3p_resposta( 200, str_repeat( 'x', 1025 ) ), 'GET', 1024, $a );
	f3p_exigir( $r['truncado'] && 'inconclusivo' === $r['assercoes'][0]['estado'] && hash( 'sha256', str_repeat( 'x', 1024 ) ) === $r['sha256'], 'Truncamento ou escopo do hash incorreto.' );
	$r = F3Base_Publicacao_Sonda::resultado( f3p_resposta( 200, 'DOCUMENTO' ), 'GET', 1024, $a );
	f3p_exigir( $r['completa'] && 'aprovado' === $r['assercoes'][0]['estado'], 'GET completo não verificou ausência.' );
} );
f3p_teste( 'N08_destinos_bloqueados', function () {
	foreach ( array( 'https://externo.test/llms.txt', '/wp-admin/', '/wp-config.php', '/wp-content/cache/', '/%252e%252e/wp-config.php', '/llms.txt?token=segredo', '/llms.txt#fragmento' ) as $url ) { f3p_exigir( ! F3Base_Publicacao_Sonda::resolver( $url )['ok'], 'Destino aceito: ' . $url ); }
	f3p_exigir( F3Base_Publicacao_Sonda::resolver( '/llms.txt' )['ok'], 'llms público foi recusado.' );
	f3p_exigir( ! F3Base_Publicacao_Sonda::resolver_cache( 'arquivo-inexistente/index.html' )['ok'], '404 de caminho inventado tratado como evidência.' );
} );
f3p_teste( 'N08_core_desligado_site_privado_potencial_indexe', function () {
	$cfg = F3Base_Options::ler( 'f3base_llms' ); $blog = get_option( 'blog_public' ); $privado = static fn() => '0';
	try {
		$c = $cfg; $c['ligado'] = false; F3Base_Options::gravar( 'f3base_llms', $c );
		f3p_exigir( ! F3Base_Llms::responsaveis()['llms']['core_serve'], 'Core desligado diz servir llms.' );
		$c['ligado'] = true; F3Base_Options::gravar( 'f3base_llms', $c ); update_option( 'blog_public', '0' ); add_filter( 'pre_option_blog_public', $privado, PHP_INT_MAX );
		f3p_exigir( ! F3Base_Llms::responsaveis()['llms']['core_serve'], 'Site privado diz servir llms.' );
	} finally { remove_filter( 'pre_option_blog_public', $privado, PHP_INT_MAX ); F3Base_Options::gravar( 'f3base_llms', $cfg ); update_option( 'blog_public', $blog ); }
} );
f3p_teste( 'F05_consulta_nao_faz_rede_ou_grava_evidencia', function () {
	$antes = F3Base_Options::fotografia( F3Base_Publicacao_Sonda::OPTION );
	$sondou = false; $bloquear = function () use ( &$sondou ) { $sondou = true; return new WP_Error( 'f3p_rede_proibida', 'Leitura não deve sondar.' ); }; add_filter( 'pre_http_request', $bloquear, 1 );
	try { F3Base_Publicacao_Sonda::resumo(); F3Base_Publicacao_Sonda::consultar(); } finally { remove_filter( 'pre_http_request', $bloquear, 1 ); }
	$depois = F3Base_Options::fotografia( F3Base_Publicacao_Sonda::OPTION );
	f3p_exigir( ! $sondou && $antes['revisao'] === $depois['revisao'], 'Consulta executou rede ou persistiu evidência.' );
} );
f3p_teste( 'N08_ability_real_sonda_sem_credenciais_com_limite', function () {
	$ability = function_exists( 'wp_get_ability' ) ? wp_get_ability( 'f3base/publicacao-verificar' ) : null;
	f3p_exigir( null !== $ability, 'Ability não registrada no WordPress real.' );
	$f = F3Base_Options::fotografia( F3Base_Publicacao_Sonda::OPTION ); $v = $f['valor']; $v['last_attempt'] = 0; $v['lease'] = array(); F3Base_Options::gravar( F3Base_Publicacao_Sonda::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
	$args = null; $mock = function ( $pre, $a, $url ) use ( &$args ) { $args = $a; return f3p_resposta( 200, "# Documento\n", array( 'content-type' => 'text/plain', 'set-cookie' => 'segredo=x', 'x-f3base-mecanismo' => 'llms-rota' ) ); }; add_filter( 'pre_http_request', $mock, 10, 3 );
	$avisos = array(); set_error_handler( function ( $nivel, $mensagem ) use ( &$avisos ) { if ( E_WARNING === $nivel || E_NOTICE === $nivel ) { $avisos[] = $mensagem; } return false; } );
	try { $r = $ability->execute( array( 'caminho' => '/llms.txt', 'metodo' => 'GET', 'assercoes' => array( array( 'tipo' => 'status', 'valor' => 200 ) ) ) ); } finally { restore_error_handler(); remove_filter( 'pre_http_request', $mock, 10 ); }
	f3p_exigir( ! is_wp_error( $r ) && ! empty( $r['persisted'] ), 'Ability recusou sonda ou evidência não foi persistida: ' . wp_json_encode( $r ) );
	f3p_exigir( empty( $avisos ), 'Avisos na serialização real: ' . implode( ';', $avisos ) );
	f3p_exigir( null !== $args && 0 === $args['redirection'] && F3Base_Publicacao_Sonda::MAX_BYTES + 1 === $args['limit_response_size'] && empty( $args['cookies'] ) && empty( $args['headers']['Authorization'] ) && str_starts_with( $args['user-agent'], 'F3Base-Sonda/' ), 'Transporte sem limites/credenciais isoladas/UA próprio.' );
	f3p_exigir( ! isset( $r['cabecalhos']['set-cookie'] ), 'Cookie retornado na evidência.' );
	$anterior = F3Base_Publicacao_Sonda::consultar(); f3p_exigir( $anterior['valida'], 'Evidência nova não é válida.' ); F3Base_Modulo_Cache_Publico::invalidar();
	f3p_exigir( ! F3Base_Publicacao_Sonda::consultar()['valida'], 'Evidência antiga confirmou geração nova.' );
} );
f3p_teste( 'N03_cache_protege_consentimento', function () {
	$req = new WP_REST_Request( 'POST', '/' . F3BASE_REST_NAMESPACE . '/consentimento' );
	$r = F3Base_Cache_Pagina::proteger_resposta( new WP_REST_Response( array( 'ok' => true ) ), null, $req );
	f3p_exigir( 'no-store, private' === $r->get_headers()['Cache-Control'], 'Nova rota sem proteção de cache.' );
} );
f3p_teste( 'N08_estado_llms_limitado_sem_enumeracao_ou_efeitos', function () {
	global $wpdb;
	$config = F3Base_Options::ler( 'f3base_llms' ); $blog = get_option( 'blog_public' );
	$medidas = array(); $http = 0;
	try {
		update_option( 'blog_public', '1' );
		$c = $config; $c['ligado'] = true; $c['full'] = true;
		F3Base_Options::gravar( 'f3base_llms', $c );
		$capturar = static function ( $sql ) use ( &$medidas ) { $medidas[] = $sql; return $sql; };
		$transporte = static function ( $pre ) use ( &$http ) { ++$http; return new WP_Error( 'sonda_nao_permitida' ); };
		add_filter( 'query', $capturar ); add_filter( 'pre_http_request', $transporte );
		try {
			foreach ( array( new F3Base_Modulo_Llms_Txt_Reserva(), new F3Base_Modulo_Llms_Full_Txt() ) as $m ) { $m->estado(); }
		} finally { remove_filter( 'query', $capturar ); remove_filter( 'pre_http_request', $transporte ); }
		foreach ( $medidas as $sql ) {
			f3p_exigir( ! preg_match( '/^\s*(INSERT|UPDATE|DELETE|REPLACE|CREATE|ALTER|DROP)\b/i', $sql ), 'Estado gravou no banco: ' . $sql );
			f3p_exigir( ! preg_match( '/\b(?:FROM|JOIN)\s+[`"]?' . preg_quote( $wpdb->posts, '/' ) . '[`"]?\b/i', $sql ), 'Estado enumerou o acervo: ' . $sql );
			f3p_exigir( ! str_contains( strtolower( $sql ), 'yoast_indexable' ), 'Estado resolveu apresentação SEO de conteúdos.' );
		}
		f3p_exigir( 0 === $http, 'Estado executou uma sonda HTTP.' );
	} finally { F3Base_Options::gravar( 'f3base_llms', $config ); update_option( 'blog_public', $blog ); }
} );
exit( $falhas ? 1 : 0 );
