'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assets = path.resolve(__dirname, '../../fontes/plugin/assets');
function ambiente(cookie = '', dados = {}) {
 const handlers={},whandlers={},scripts={}; let jar=cookie; const storage = new Map();
 const document = {readyState:'loading',visibilityState:'visible',addEventListener:(e,f)=>(handlers[e] ||= []).push(f),dispatchEvent:e=>(handlers[e.type]||[]).forEach(f=>f(e)),getElementById:id=>scripts[id],getElementsByTagName:()=>[],head:{appendChild:el=>{scripts[el.id]=el}},createElement:()=>({}),querySelectorAll:()=>[],documentElement:{},body:{}};
 Object.defineProperty(document,'cookie',{get:()=>jar,set:v=>{jar=v.split(';')[0]}});
 const window = {document,location:{protocol:'https:',hostname:'example.test',pathname:'/',href:'https://example.test/'},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)},addEventListener:(e,f)=>(whandlers[e] ||= []).push(f),dataLayer:[],performance:{now:()=>0,timeOrigin:Date.now()},f3baseConsentimentoDados:{padrao:'pre-aprovado',controleRodape:false,avisoPrimeiraVisita:false,...dados}};
 const ctx = vm.createContext({window,document,CustomEvent:class{constructor(type,o){this.type=type;this.detail=o.detail}},URL,Date,Promise,setTimeout,clearTimeout,Uint8Array,console});
 vm.runInContext(fs.readFileSync(path.join(assets,'f3base-consentimento.js'),'utf8'),ctx);
 return {window,document,ctx,handlers,scripts,storage,load:()=>document.dispatchEvent({type:'DOMContentLoaded'})};
}
function tracking(a, caminho='direto', overrides={}) {
 a.window.f3baseTrackingDados={caminho,ga4:'G-TEST',ads:{id:'AW-TEST'},meta:{pixelId:'42',origem:'https://meta.test/pixel'},linkedin:{partnerId:'42',origem:'https://linkedin.test/script'},gtm:'GTM-TEST',origemGoogle:'https://google.test/',resumo:{ativo:false},comportamento:{eventos:{f3base_pagina_vista:{gatilho:'pagina',parametros:[],teto:1,limiar:{}}}}};
 Object.assign(a.window.f3baseTrackingDados,overrides);
 vm.runInContext(fs.readFileSync(path.join(assets,'f3base-tracking.js'),'utf8'),a.ctx);a.load();
}
function commands(a,n) { return a.window.dataLayer.filter(c=>c[0]===n); }
(async()=>{
 const malformed=ambiente('f3base_consentimento=%E0%A4%A'); assert.equal(malformed.window.f3baseConsentimento.permiteTags(),true);
 const negado=ambiente('f3base_consentimento=%E0%A4%A',{padrao:'negado'});assert.equal(negado.window.f3baseConsentimento.permiteTags(),false);
 const migrated=ambiente('f3base_consentimento=granted',{modo:'granular',politicaVersao:'2'});assert.equal(migrated.window.f3baseConsentimento.permiteCategoria('publicidade'),false);
 const denied=ambiente('f3base_consentimento=denied',{modo:'granular',politicaVersao:'2'});assert.equal(denied.window.f3baseConsentimento.permiteCategoria('medicao'),false);
 const direct=ambiente();tracking(direct);const cmds=direct.window.dataLayer;const conf=cmds.findIndex(c=>c[0]==='config'&&c[1]==='G-TEST');const event=cmds.findIndex(c=>c[0]==='event'&&c[1]==='f3base_pagina_vista');assert.ok(conf>=0&&event>conf);assert.equal(commands(direct,'event').length,1);assert.equal(cmds.filter(c=>c.event==='f3base_pagina_vista').length,0);direct.window.f3baseTracking.carregar();assert.equal(commands(direct,'config').length,2);assert.equal(commands(direct,'event').length,1);
 direct.window.f3baseConsentimento.definir('denied');direct.window.f3baseConsentimento.definir('granted');assert.equal(commands(direct,'config').length,2);assert.equal(commands(direct,'event').length,1);
 const gtm=ambiente();tracking(gtm,'gtm');assert.equal(commands(gtm,'config').length,0);assert.equal(commands(gtm,'event').length,0);assert.equal(gtm.window.dataLayer.filter(c=>c.event==='f3base_pagina_vista').length,1);
 const cookie=encodeURIComponent(JSON.stringify({v:'2',medicao:true,publicidade:false}));const partial=ambiente('f3base_consentimento='+cookie,{modo:'granular',politicaVersao:'2'});tracking(partial);assert.ok(partial.scripts['f3base-gtag']);assert.equal(partial.scripts['f3base-meta-pixel'],undefined);assert.equal(commands(partial,'config').length,1);assert.equal(commands(partial,'event')[0][2].send_to,'G-TEST');assert.equal(partial.window.f3baseConsentimento.permiteGtm(),false);
 const block=ambiente('f3base_consentimento='+cookie,{modo:'granular',politicaVersao:'2'});tracking(block,'gtm');assert.equal(block.scripts['f3base-gtm'],undefined);assert.equal(block.window.dataLayer.filter(c=>c.event==='f3base_pagina_vista').length,0);
 const onlyAds=ambiente();tracking(onlyAds,'direto',{ga4:''});assert.equal(commands(onlyAds,'config').length,1);assert.equal(commands(onlyAds,'event').length,0);
 const none=ambiente();tracking(none,'nenhum');assert.equal(commands(none,'config').length,0);assert.equal(commands(none,'event').length,0);
 const analyticsGtm=ambiente('f3base_consentimento='+cookie,{modo:'granular',politicaVersao:'2',gtmSeparacaoVerificada:true});tracking(analyticsGtm,'gtm');assert.ok(analyticsGtm.scripts['f3base-gtm']);assert.equal(analyticsGtm.window.dataLayer.filter(c=>c.event==='f3base_pagina_vista').length,1);
 const adsCookie=encodeURIComponent(JSON.stringify({v:'2',medicao:false,publicidade:true}));const adsOnly=ambiente('f3base_consentimento='+adsCookie,{modo:'granular',politicaVersao:'2'});tracking(adsOnly);assert.ok(adsOnly.scripts['f3base-meta-pixel']);assert.equal(commands(adsOnly,'config').length,1);assert.equal(commands(adsOnly,'event').length,0);
 const stale=ambiente('f3base_consentimento='+cookie,{modo:'granular',politicaVersao:'3'});assert.equal(stale.window.f3baseConsentimento.permiteCategoria('medicao'),false);
 const sync=ambiente('',{modo:'granular',politicaVersao:'2',endpoint:'/consentimento'});const req=[];sync.window.fetch=async(u,o)=>{req.push(JSON.parse(o.body));return {ok:true,json:async()=>({persisted:true,comprovante:req.length===1?'a'.repeat(64):''})}};
 sync.window.f3baseConsentimento.definirCategorias(true,true);sync.window.f3baseConsentimento.definirCategorias(false,false);await new Promise(r=>setTimeout(r,0));await new Promise(r=>setTimeout(r,0));assert.equal(req.length,2);assert.equal(req[1].comprovante_anterior,'a'.repeat(64));assert.equal(sync.window.f3baseConsentimento.permiteCategoria('publicidade'),false);assert.equal(sync.window.f3baseConsentimento.servidorPendente(),false);
 const fail=ambiente('f3base_consentimento='+encodeURIComponent(JSON.stringify({v:'2',medicao:true,publicidade:true,comprovante:'b'.repeat(64)})),{modo:'granular',politicaVersao:'2',endpoint:'/consentimento'});fail.window.fetch=async()=>{throw Error('offline')};fail.window.f3baseConsentimento.definirCategorias(false,false);await new Promise(r=>setTimeout(r,0));assert.equal(fail.window.f3baseConsentimento.servidorPendente(),true);assert.equal(fail.window.f3baseConsentimento.permiteTags(),false);assert.ok(fail.storage.get('f3base_consentimento_pendente').includes('b'.repeat(64)));
 const ativo=require(path.join(assets,'f3base-tempo-ativo.js'));let time=0,sec='a',visible=true,allowed=true,events=[];const t=ativo({agora:()=>time,visivel:()=>visible,permitido:()=>allowed,predominante:()=>sec,emitir:(s,ms)=>events.push([s,ms])});time=10000;sec='b';t.atividade();time=20000;visible=false;t.atualizar();time=600000;visible=true;t.atualizar();time=610000;t.flush();assert.deepEqual(events,[['a',10000],['b',10000]]);events=[];t.atividade();time=900000;t.flush();assert.deepEqual(events,[['b',30000]]);events=[];time=910000;t.atividade();time=920000;allowed=false;t.descartar();allowed=true;time=940000;t.atividade();time=945000;t.flush();assert.deepEqual(events,[['b',5000]]);
 console.log('PASS C03/N03/N04/F04: malformed cookies, legacy/granular migration, category/vendor gates, initialization order, no duplicate page events, revocation race/offline and monotonic active time.');
})().catch(e=>{console.error(e);process.exitCode=1});
