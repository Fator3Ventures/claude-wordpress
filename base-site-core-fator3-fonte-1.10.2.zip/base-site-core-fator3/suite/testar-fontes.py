#!/usr/bin/env python3
"""Piso da distribuição: resíduo, mtime, integridade, extração e rebuild idêntico.
A suíte completa é executada à parte contra a fonte extraída.
"""
from pathlib import Path
import hashlib,json,os,subprocess,tempfile,zipfile
ROOT=Path(__file__).resolve().parent.parent
def run(*args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix='f3base-fontes-teste-') as tmp:
 tmp=Path(tmp);a=tmp/'a.zip';b=tmp/'b.zip'
 run('python3','suite/empacotar-fontes.py','--saida',str(a))
 residue=ROOT/'dist/instalador-obsoleto-teste.zip';assert not residue.exists();residue.write_bytes(b'artefato residual que nao e fonte')
 source=ROOT/'fontes/plugin/base-site-core-fator3.php';st=source.stat()
 try:
  os.utime(source,(946684800,946684800));run('python3','suite/empacotar-fontes.py','--saida',str(b))
 finally:residue.unlink();os.utime(source,ns=(st.st_atime_ns,st.st_mtime_ns))
 assert a.read_bytes()==b.read_bytes(),'Resíduo ou mtime alterou o pacote.'
 with zipfile.ZipFile(a) as z:
  assert not any('instalador-obsoleto' in p or p.endswith('.bundle') or p.startswith('base-site-core-fator3/dist/entregue/') for p in z.namelist())
  z.extractall(tmp/'extraido')
 base=tmp/'extraido/base-site-core-fator3';meta=json.loads((base/'dist/fontes-manifesto.json').read_text())
 for entry in meta['arquivos']:assert sha(base/entry['caminho'])==entry['sha256'],entry['caminho']
 # Mesmo build de produção, a partir das fontes sem .git, cache ou instalador atual embutido.
 php='require "suite/lib/regra.php"; require "suite/lib/empacotar.php"; foreach (["estatica","entrega","funcional","bloqueadas","meta"] as $m) {require "suite/checagens/$m.php";} require "suite/lib/documentos.php"; $r=f3b_empacotar(getcwd(),getcwd()."/suite"); if(!$r["ok"]){fwrite(STDERR,json_encode($r["achados"]));exit(1);} echo $r["artefato"];'
 rebuilt=Path(run('php','-r',php,cwd=base).strip());original=ROOT/'dist'/meta['instalador_reconstruivel']
 assert sha(rebuilt)==sha(original),'Instalador reconstruído diverge.'
 print(json.dumps({'ok':True,'fontes_bytes':a.stat().st_size,'fontes_sha256':sha(a),'instalador_sha256':sha(original),'arquivos_com_hash':len(meta['arquivos']),'residuo_excluido':True,'independente_de_mtime':True,'rebuild_identico':True},ensure_ascii=False))
