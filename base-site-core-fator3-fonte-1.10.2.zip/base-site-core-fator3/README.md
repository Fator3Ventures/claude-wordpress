<!-- gerado:inicio=carimbo -->
# Base Site Core Fator3 1.10.2 — leia-me do operador

> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip ser
> montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número destes documentos
> é digitado à mão: número digitado está certo no dia em que foi escrito e é contradito pela rodada
> seguinte, sem nada acusando. O que não pode ser medido no momento da escrita sai como pendência
> nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `1.10.2` |
| Pasta instalada | `base-site-core-fator3` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Plataforma declarada no cabeçalho | `EXIGE PHP DE 64 BITS` |
| Escopo de instalação declarado no cabeçalho | `INSTALAÇÃO ÚNICA, NÃO MULTISITE` |
| Arquivos na fonte do plugin | 93 |
| Arquivos vindos de `partilhado/` | 5 |
| Arquivos no repositório (fora de `dist/` e dos produtos da rodada) | 739 |
| Checagens declaradas por classe de evidência | `analise-estatica/build` 34 · `leitura-de-volta/producao` 1 · `medida/build` 1 · `medida/campo` 1 · `medida/producao` 2 · `pendencia-externa/local` 3 · `pendencia-externa/producao` 2 · `teste-funcional/build` 82 · `wp-real/build` 60 |
| Detectores com piso em disco | 28 |
| Ramos de piso em disco (negativa + positiva) | 56 |
| Passos da bancada WordPress com mutante declarado | 59 |
| Checagens com piso declarado em sonda | 138 |
| Artefato publicado | `base-site-core-fator3-1.10.2.zip` |
| Época declarada de cada entrada do zip | `1980-01-01 00:00:00 UTC` |
<!-- gerado:fim=carimbo -->

Plugin persistente do Método F3: o que fica no site depois que a ferramenta de implantação
se desativa. Ele mede o comportamento das páginas no próprio site, recebe e registra os
leads, decide o consentimento e gateia por ele todas as tags de fornecedor, serve o
`llms.txt`, honra `noindex`, redireciona slug antigo, emite os cabeçalhos de resposta,
cumpre os prazos de retenção com journal de eliminação e ouve a cadência do relatório —
tudo declarado num registro único de módulos que alimenta os hooks, a tela e o relatório.

**Este arquivo é para quem OPERA: instalar, rodar a suíte, publicar, atualizar, reverter e
desinstalar.** Ele não descreve o produto por dentro, e a subtração é deliberada: quem
precisa saber o que cada módulo faz, o que acontece com cada option vazia, quais são as
colunas das tabelas, as rotas REST com os limites e as recusas, e o que nunca se toca, lê
`fontes/plugin/INSTRUCOES-DO-PLUGIN.md` — preservado no pacote completo de fontes e excluído do instalador de produção. É a
única coisa que outro agente precisa ler para entender e MUDAR este plugin. O porquê de
cada decisão está em `MEMORIA-DECISOES.md`; a identidade, o inventário e o que é contrato
estão em `MANIFESTO.md`.

Nenhum número deste arquivo é digitado à mão. Os que existem estão nas regiões geradas, e
quem confere que elas batem com o disco é `estatica.carimbo_de_release_nos_documentos`;
quem recusa um número digitado fora delas é `doc.numero_digitado`.

<!-- gerado:inicio=arvore -->
### Árvore do repositório

Gerada de `suite/inventario.tsv`, que é a allow-list executável do empacotamento: arquivo em disco fora
dela **aborta o build com o nome**. Diretório declarado como prefixo sai como um nó só, porque é assim
que ele está declarado. O papel de cada caminho sai aqui até o primeiro ponto final; ele está inteiro
no inventário de `MANIFESTO.md`.

```
base-site-core-fator3/
  MANIFESTO.md   — IDENTIDADE E INVENTÁRIO DA RELEASE: o que é CONTRATO (o zip reprodutível e o digesto dele, o lock) e o que é fato observado, mais o inventário caminho a caminho, a tabela requisito -> checagem -> evidência, as três formas de piso e o que a suíte da referência media e esta nao mede
  MEMORIA-DECISOES.md   — O PORQUÊ, a partir de defeito medido
  README.md   — LEIA-ME DO OPERADOR, e o primeiro arquivo que alguém abre neste repositório
  composer.json   — Dependências de desenvolvimento e comandos de análise; fora do instalador
  composer.lock   — Versões e hashes fixados das dependências de desenvolvimento; fora do instalador
  dist/   — SAÍDA DE BUILD: o zip do plugin publicado, a cópia de conferência do que foi entregue (dist/entregue/) e o lock de sha256
  docs/   — Manual operacional atual, separado das evidências históricas de versões
  fontes/
    plugin/
      INSTRUCOES-DO-PLUGIN.md   — INSTRUCOES DO PLUGIN, preservadas no pacote completo de fontes e excluídas do instalador de produção
      admin/
        assets/
          f3base-admin.css   — Estilo da tela de administração
        class-f3base-admin-acessos.php   — Aba de acessos por pagina e familia
        class-f3base-admin-medicao.php   — Menu Medição: o que os visitantes fizeram, por evento declarado e por página, com estado vazio que diz desde quando o site coleta e o que falta — e o que o site DESCARTOU, dito antes de qualquer tabela, para que ninguém some achando que tem tudo
        class-f3base-admin-saude.php   — Painel técnico de saúde e ações explícitas de operação e publicação
        class-f3base-admin-tela.php   — Tela do wp-admin, renderizada a partir do registro único de módulos — nunca de lista escrita à mão
      assets/
        f3base-consentimento.css   — Estilo autônomo do controle de consentimento, com foco e responsividade
        f3base-consentimento.js   — Comportamento do consentimento pré-aprovado e do controle de revisão do rodapé
        f3base-consentimento.min.js   — JavaScript minificado regenerado pelo build fixado
        f3base-leads.js   — Comportamento do CTA de leads: preserva o destino explícito, monta a URL do WhatsApp só quando o href é do modelo, registra a interação por fetch com confirmação e sendBeacon de reserva, transporta a atribuição com os identificadores de clique e dispara a conversão nos quatro canais
        f3base-leads.min.js   — JavaScript minificado regenerado pelo build fixado
        f3base-tempo-ativo.js   — Relógio monotônico e seção predominante para tempo ativo opcional
        f3base-tempo-ativo.min.js   — Asset gerado pelo build fixado do tempo ativo opcional
        f3base-tracking.js   — Carregador único das tags de GA4, Google Ads, Meta e LinkedIn: um caminho só — container do GTM ou tags diretas —, sempre sob o mesmo portão de consentimento
        f3base-tracking.min.js   — JavaScript minificado regenerado pelo build fixado
        f3base-whatsapp.css   — Apresentação do ícone flutuante de WhatsApp opcional, com foco visível e áreas seguras
        js/
          medicao-acessos.js   — Atualização administrativa opcional com pausa, proteção contra sobreposição e backoff
        manifesto-assets.json   — Manifesto reprodutível dos JavaScripts gerados e hashes dos fontes
        vendor/
          web-vitals-LICENSE.txt   — Licença Apache da biblioteca web-vitals redistribuída no plugin
          web-vitals.js   — Biblioteca oficial web-vitals vendorizada localmente; origem, versão e fontes disponíveis na suíte
      base-site-core-fator3.php   — Bootstrap do PLUGIN Base Site Core Fator3: cabeçalho, constantes, guarda de versão de PHP e carregamento do registro único
      dados/
        .htaccess   — Nega acesso HTTP aos dados internos do Core; não altera PHP nem opções da hospedagem
        contrato-de-nomes.tsv   — CONTRATO DE NOMES DO PLUGIN: as grafias que a renomeacao de prefixo NAO reescreve — options, tabelas, eventos, namespace REST, classes compartilhadas, hook da cadencia e o prefixo da classe que marca secao medida
        emissores-conhecidos.tsv   — Declaração ÚNICA dos emissores de tag conhecidos, com a condição de emissão medida quando há option conhecida
        eventos-comportamento.tsv   — Declaração ÚNICA dos eventos de COMPORTAMENTO: nome, parâmetros (na ordem em que o coletor os entrega), teto por página, gatilho e limiar
        mudancas.json   — Histórico estruturado consumido por consulta autenticada; protegido contra leitura HTTP pelo diretório de dados
        robos-conhecidos.tsv   — Marcas HTTP e classes de agentes declarados
        vitais.tsv   — Declaração única das medidas de carregamento: o que cada sigla diz, em português comum, e o limiar de "bom" que a tela mostra ao lado do valor medido
      includes/
        class-f3base-acessos-atuais.php   — Leitura temporária do dia atual sem armazenamento histórico
        class-f3base-acessos-coleta.php   — Coleta retomável de logs fechados, com contribuições por arquivo e cobertura versionada
        class-f3base-acessos-mcp.php   — Habilidade administrativa de leitura de acessos
        class-f3base-acessos-relatorio.php   — Projeção de acessos, comparação de períodos e CSV sem identificadores pessoais
        class-f3base-adaptador-yoast.php   — Adaptação explícita das opções e mudanças relevantes do Yoast
        class-f3base-atividade.php   — Última atividade relevante por módulo, exibida na tela
        class-f3base-atualizacao.php   — Migração aditiva com prova da estrutura e recuperação de falha de agendamento
        class-f3base-auditoria.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-autoria.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-cache-evidencia.php   — Registro durável de tentativas, lease concorrente e agendamento limitado do cache
        class-f3base-cache-pagina.php   — Integração com cache de página, invalidação e prova HTTP de cabeçalhos
        class-f3base-capi-fila.php   — Fila persistente de conversões com reservas concorrentes, expiração e retentativas limitadas
        class-f3base-censo-demonstrativo.php   — Regra COMPARTILHADA do censo de conteudo demonstrativo: conta, NO BANCO, as paginas publicadas que ainda carregam a marca do template e as NOMEIA
        class-f3base-chaves-seo.php   — VOCABULARIO do plugin de SEO — os nomes de meta e de option do fornecedor, num lugar so
        class-f3base-cli.php   — Comandos opcionais WP-CLI, validação prévia e códigos distintos para sucesso, falha e pendência
        class-f3base-como-usar.php   — A habilidade f3base/como-usar: diz ao agente MCP o que o plugin ja faz por assunto, a option exata para mudar cada coisa e o que NAO fazer por outro caminho, com o preco de cada atalho
        class-f3base-config-consultas.php   — Projeções compactas e histórico versionado sem efeitos
        class-f3base-config-contrato.php   — Contrato versionado do catálogo e consulta de verificação independente da persistência
        class-f3base-config-mcp.php   — As habilidades f3base/config-ler e f3base/config-escrever: o agente MCP le a configuracao do implantador e o schema dela, altera e grava
        class-f3base-config-mescla.php   — Mesclagem tipada de mapas/listas/campos opcionais sem duplicar persistência
        class-f3base-config-perfil.php   — Avaliação somente leitura de perfil declarado, exceções e indeterminações
        class-f3base-consentimento-decisoes.php   — Decisões granulares verificáveis e revogação coordenada com a fila
        class-f3base-core-config-mcp.php   — Habilidades de configuração persistente, simulação e revisão atômica independentes do implantador
        class-f3base-emissores.php   — Regra COMPARTILHADA do segundo emissor: lê a declaração e devolve o veredito de emissão (leitor, concorrente, nao-medido)
        class-f3base-http-publico.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-llms-arquivo.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-llms-conversor.php   — Conversão editorial conservadora, com acesso, ciclos e limites explícitos
        class-f3base-llms.php   — Regra COMPARTILHADA do arquivo llms.txt: precedencia de emissor, selecao com as exclusoes, ordem, origem de cada descricao, limpeza do resumo e endereco medido do sitemap
        class-f3base-medicao-consultas.php   — Consultas administrativas limitadas de eventos, comportamento e contadores de leads
        class-f3base-modulo-acessos-servidor.php   — Coleta e leitura dos logs fechados
        class-f3base-modulo-cabecalhos.php   — Módulo: emite os cabeçalhos de resposta com o valor GRAVADO em cada chave, e avisa em WARN quando o valor custa a atribuição dos canais pagos
        class-f3base-modulo-cache-publico.php   — Cache de conteúdo público com invalidação por mudanças de publicação, metadados, taxonomia e configuração
        class-f3base-modulo-cadencia-relatorio.php   — Módulo: OUVINTE do evento f3base_cadencia_relatorio, registro das recorrências quinzenal e mensal que o núcleo não tem, execução do modo somente-relatório com última execução, próxima, duração, resultado, erro e atraso, e o contador de ajustes que dispara
        class-f3base-modulo-comportamento.php   — Modulo: recebe, a cada ocultamento de pagina, o LOTE selado com os totais agregados e o registro daquela visita e os soma numa tabela propria — uma linha por dia, caminho, evento e detalhe, com contagem e soma
        class-f3base-modulo-consentimento.php   — Módulo: política de consentimento e o controle permanente do rodapé
        class-f3base-modulo-endpoint-leads.php   — Módulo: rota REST pública e endurecida que recebe o registro de lead
        class-f3base-modulo-leads-whatsapp.php   — Módulo: publica ícone flutuante opcional e enfileira leads; JavaScript troca href somente com data-f3base-numero explícito
        class-f3base-modulo-llms-full-txt.php   — Módulo: rota virtual de llms-full.txt com o texto integral dos mesmos itens
        class-f3base-modulo-llms-markdown.php   — Alternativas Markdown e descoberta do índice
        class-f3base-modulo-llms-txt-reserva.php   — Módulo: rota virtual de llms.txt, servida quando ela e a responsavel pelo endereco — arquivo fisico vence, emissor concorrente medido vem depois
        class-f3base-modulo-meta-capi.php   — Modulo: envia o evento Lead de SERVIDOR para a Conversions API da Meta depois da persistencia confirmada, com o mesmo event_id do navegador — e-mail e telefone em SHA-256 sobre o valor normalizado pela regra da Meta, nunca em claro
        class-f3base-modulo-noindex-honrado.php   — Módulo: honra o noindex gravado nas chaves do plugin de SEO mesmo sem o plugin ativo
        class-f3base-modulo-redirects.php   — Módulo: redirecionamento de slug antigo, cobrindo o que o núcleo não cobre
        class-f3base-modulo-retencao-eliminacao.php   — Módulo: limpeza por prazo, exportador e eliminador do núcleo, e journal de eliminação
        class-f3base-modulo-robots-txt.php   — Gerador de robots.txt com troca reversível do arquivo físico
        class-f3base-modulo-rota-origem.php   — Módulo: rota de leitura de volta pela origem, restrita a caminhos do próprio home_url()
        class-f3base-modulo-schema-extensao.php   — Módulo: estende o schema do plugin de SEO sem duplicar nó existente
        class-f3base-modulo-sessao-de-login.php   — Prazo e diagnostico de sessoes do nucleo
        class-f3base-modulo-tracking.php   — Módulo: emite GA4, Google Ads, Meta e LinkedIn a partir dos IDs gravados, por um caminho só — container do GTM ou tags diretas — e sob um portão de consentimento só; slot vazio é inerte
        class-f3base-modulo-verificacao-dominio.php   — Modulo: emite no head a metatag de verificacao de posse do dominio de cada token gravado
        class-f3base-modulo.php   — Contrato de um módulo: identidade, dependências, options que o controlam, hooks e estado com motivo
        class-f3base-operacao.php   — Agenda unificada e execução de tarefas permitidas com reservas e recuperação
        class-f3base-options.php   — Gravador ÚNICO de options do site-core, com catálogo, sanitização que normaliza o conhecido e PRESERVA o desconhecido, e procedência
        class-f3base-perfil-desempenho.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-plugin.php   — Orquestrador: registra os hooks lendo o registro único
        class-f3base-publicacao-sonda.php   — Inspeção limitada de publicação, evidência HTTP e prévias sem republicação
        class-f3base-registro.php   — Registro ÚNICO de módulos: alimenta hooks, tela e relatório
        class-f3base-release-configuracao.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-robots-arquivo.php   — Troca reversível do robots físico com backup e restauração atômica
        class-f3base-robots-entrega.php   — Verificação da entrega pública e manutenção automática do robots gerenciado
        class-f3base-saude.php   — Fotografia operacional comum à interface, Saúde do Site, CLI e abilities
        class-f3base-schema-verificacao.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-seo-entidade.php   — Suporte à configuração, evidência e entrega da release corrente
        class-f3base-vitais.php   — Amostras revisáveis e percentil das métricas oficiais
        class-f3base-vocabulario.php   — VOCABULARIO compartilhado pelos dois runtimes: o CONJUNTO de valores que existem — modelos de atribuicao, modos da lista do llms.txt, politicas de frame, COOP, referrer e permissoes, e o slug do plugin de cada papel
        trait-f3base-options-catalogo.php   — Catálogo declarativo interno, preservando a interface pública e os limites das opções
        trait-f3base-options-efeitos.php   — Implementação interna de efeitos e verificação, mantendo a fachada pública Options
        trait-f3base-options-persistencia.php   — Implementação interna de persistência condicional e CAS da fachada Options
        trait-f3base-options-validacao.php   — Validação e sanitização interna, preservando a interface pública e os resultados legados
      uninstall.php   — Desinstalação: declara o destino de cada conjunto de dados, passando pelo gravador único
  suite/   — A SUÍTE inteira: o comando único, as regras compartilhadas, as sondas em subprocesso, as tabelas declaradas e as fixtures de piso
    bancada-wp/   — A BANCADA WORDPRESS REAL, e ela vem ANTES do prefixo da suíte de propósito: o papel dela não é o do resto do instrumento
```
<!-- gerado:fim=arvore -->

## Pré-requisitos

### Do site que vai receber o plugin

Os mínimos de WordPress e de PHP estão no carimbo gerado no topo deste arquivo, lidos do
cabeçalho do arquivo principal do plugin — que é o mesmo lugar de onde o WordPress os lê
para barrar a instalação. Não são repetidos aqui, porque número repetido sai de sincronia
na primeira release em que alguém mexe em só um dos dois.

Além deles, duas exigências que também estão no carimbo porque são declaradas no cabeçalho:

- **PHP de sessenta e quatro bits.** O carimbo de milissegundo de cada acionamento do
  registro de comportamento é um inteiro que não cabe num inteiro de trinta e dois bits.
  Num PHP menor ele estoura em silêncio — sem aviso, sem erro — e a série de tempo passa a
  mentir. A decisão de exigir a plataforma em vez de carregar uma segunda representação do
  instante por dentro está na memória.
- **Instalação única, não multisite.** A ativação em rede é RECUSADA, com `wp_die()`
  nomeando o motivo; a ativação site a site continua funcionando. Tudo o que o plugin
  guarda é do site corrente e por site, não há laço por blog nem `wpmu_drop_tables()`, e a
  desinstalação que o núcleo roda uma vez limparia só um dos sites. Recusar a ativação foi
  mais barato do que prometer uma limpeza que ela não sabe fazer.

### Da máquina que roda o comando único

Cinco executáveis no `PATH`: `php`, `node`, `zip`, `unzip` e `faketime`. O comando único
confere os cinco antes de qualquer coisa e, na ausência de qualquer um, fecha
`suite.ambiente` em **BLOCKED nomeando o recurso que falta** e sai com código de erro. Não
é FALHA: pré-condição ausente e defeito são coisas diferentes e pedem ações diferentes de
quem lê.

A bancada WordPress pede o seu próprio conjunto, e ele está declarado em
`suite/bancada-wp/LEIA-ME.md`: um `php` com SQLite, `patch`, e os insumos em cache.

Um sexto executável não é obrigatório e o preço da ausência está declarado: um Chromium
alcançável pelo `playwright`. É o que a sonda de navegador dirige. Sem ele a rodada
continua fechando sem FALHA, mas `navegador.comportamento_real` fecha **N/A com a condição
declarada** — e um pacote verificado sem navegador não é um pacote aprovado, porque a única
checagem que mede o cliente entregue fora de uma simulação não rodou.

## O comando único

```
bash suite/verificar.sh <caminho-do-repositorio>   empacota, verifica, roda a bancada e sela
bash suite/verificar.sh piso                       roda só o piso, a partir da raiz
bash suite/verificar.sh piso <caminho>             roda o piso contra outro caminho
```

Quatro regras que o próprio script existe para ninguém contornar:

- **Rodar sem argumento reprova.** Sem caminho não há artefato, e uma rodada sem artefato
  que terminasse em zero seria a pior aprovação possível.
- **Empacotar é a primeira etapa, sempre.** É nela que as regiões geradas dos quatro
  documentos são reescritas por leitura de disco — antes de o zip ser montado, para que o
  que viaja seja o documento atualizado — e é nela que um arquivo fora de
  `suite/inventario.tsv` ABORTA o build com o nome dele.
- **O código de saída vem da contagem que a função de emissão acumulou.** Nenhuma etapa do
  script corrige o resultado do PHP.
- **Selar é a última etapa.** Só dela sai `suite/rodada.json`, com o veredito declarado e o
  digesto do zip que ESTA rodada montou. Rodada com FALHA não sela, e apaga o registro
  anterior: registro que sobrevive a uma rodada reprovada é uma afirmação de limpeza sem
  medição por trás.

`suite/rodada.json` e `dist/` são produto da rodada e não viajam no repositório. É por isso
que, num checkout novo, a linha do digesto no carimbo sai como pendência nomeada até a
primeira rodada acontecer.

### O piso, e por que ele é subcomando próprio

O piso roda a MESMA função que roda contra o pacote, com a raiz trocada: a fixture negativa
reproduz o defeito e a checagem precisa acusá-lo; a positiva preserva o caso correto e ela
precisa ficar em silêncio. Detector que nunca foi visto acusando é uma afirmação sobre a
intenção de quem o escreveu.

Ele é subcomando próprio porque mede o INSTRUMENTO, não o produto: misturar as duas coisas
numa saída só faria a linha verde de um detector cego parecer com a linha verde de um
detector que enxerga. As três formas de piso — em disco, na bancada e dentro da sonda —
estão listadas, uma a uma, na região gerada `fixtures` do `MANIFESTO.md`.

### A bancada WordPress, e o interruptor que a desliga

A bancada instala o zip recém-montado num WordPress descartável de verdade, com SQLite pelo
drop-in, e pergunta ao produto o que ele faz. Ela existe porque há uma classe inteira de
defeito que só aparece com o núcleo carregado — a desinstalação como o WordPress a executa,
a Abilities API aceitando ou recusando o registro, o cron real na ordem real, o `dbDelta`,
uma rota pública respondendo erro de servidor porque uma função do núcleo estourou. Cada
passo sai como uma linha `wp.<passo>`, na classe de evidência `wp-real`.

Nada é instalado no sistema e nada é gravado no repositório: o WordPress inteiro nasce num
temporário e tudo é derrubado ao final, inclusive em falha e em interrupção.

**O cache dos insumos mora fora do repositório**, em `${F3BASE_BANCADA_CACHE}` — por padrão
`~/.cache/f3base-bancada`. Ele guarda o núcleo do WordPress, o drop-in de SQLite e o
`wp-cli.phar`. Semear ou completar:

```bash
bash suite/bancada-wp/bancada.sh cache                     # baixa o que faltar
bash suite/bancada-wp/bancada.sh cache /caminho/da/copia   # copia de uma bancada montada à mão
```

Sem cache e sem rede a etapa **não** fecha OK e **não** fecha N/A: ela fecha
`BLOCKED bancada.ambiente` nomeando o recurso que faltou. Ambiente que não pôde medir não
aprova pacote.

**`F3BASE_SEM_BANCADA=1` desliga a etapa**, e existe para quem precisa de uma rodada sem
rede:

```bash
F3BASE_SEM_BANCADA=1 bash suite/verificar.sh <caminho-do-repositorio>
```

Ele nunca produz OK. Cada `wp.*` sai em N/A dizendo, com todas as letras, que a etapa foi
desligada por quem chamou o comando — a diferença entre "medi e está certo" e "não medi"
não pode viver dentro do código.

## Como se instala num site

O plugin funciona sozinho. Depois de ativá-lo, clique em **F3 Base → Configurações**. A tela completa e a gravação dos campos não dependem do implantador nem do Flamingo. Sem Flamingo, **Leads (contingência)** continua disponível como submenu separado.

O artefato é um zip só, e o nome dele está no carimbo gerado no topo. Há dois caminhos, e
eles não são intercambiáveis.

**À mão, para um site avulso.** Em **Plugins › Adicionar novo › Enviar plugin**, envie
`dist/base-site-core-fator3-<versão>.zip` e ative. Não copie arquivo a arquivo por cima de
código ativo: a troca de diretório precisa ser atômica do ponto de vista do WordPress, e
uma cópia parcial deixa o autoload apontando para metade de uma release e metade de outra.

**Pelo implantador, para um site da operação.** O implantador instala este plugin como
qualquer plugin de catálogo, pela entrada de `plugins.instalaveis` com origem `url`. Duas
coisas precisam estar certas nessa entrada, e as duas são responsabilidade de quem publica:

- o arquivo publicado no endereço declarado se chama **`base-site-core-fator3.zip`** — o
  nome de catálogo, sem versão, porque o endereço é estável e o conteúdo é que muda;
- o **`sha256` declarado** na entrada é o digesto do zip que a rodada selou, que sai no
  carimbo gerado no topo deste arquivo e em `suite/rodada.json`.

Com o digesto declarado e batendo, o implantador instala. Declarado e divergindo, ele
**reprova nomeando os dois valores e não instala nada**. Ausente, ele FIXA o que observou na
primeira execução e passa a reprovar toda execução seguinte em que o arquivo mudar — que é
a razão pela qual o zip precisa ser reprodutível byte a byte, e é o que `MANIFESTO.md`
declara como contrato.

Publicar é, então, três passos: rodar o comando único até fechar sem FALHA, copiar
`dist/base-site-core-fator3-<versão>.zip` para o endereço do catálogo com o nome
`base-site-core-fator3.zip`, e declarar ali o `sha256` que a rodada selou.

## Como se atualiza

**O atualizador do WordPress não atualiza este plugin, e isso é deliberado.** O cabeçalho
declara `Update URI: false`, que desliga a consulta ao diretório público inteira: sem ela,
o atualizador conferiria o SLUG da pasta contra o wordpress.org e — com atualização
automática ligada — instalaria por cima deste qualquer plugin publicado lá com o mesmo
slug.

Quem troca a versão instalada é o implantador, ou o operador enviando o zip à mão.

**E aqui a frase que precisa ser dita com todas as letras: uma release nova com o MESMO
número de versão e bytes diferentes só é trocada pelo implantador.** `version_compare()` não
distingue duas releases de mesmo número, e o gate do WordPress é a versão. O implantador
troca assim mesmo porque a condição dele para pular a troca é mais forte: ele exige versão
igual **E** o hash do diretório instalado igual ao do artefato: bytes diferentes fazem a
troca acontecer. A consequência que se paga por isso está declarada na memória de decisões:
a linha que compara a versão instalada com a que o pacote carrega deixa de ser capaz de
acusar uma instalação de teste que tenha o mesmo número.

Num site que já rodou o implantador antes, o digesto anterior está FIXADO. Publicar bytes
novos sem declarar o `sha256` novo faz a execução seguinte reprovar com "digesto divergente
do fixado" — o que é o comportamento certo, e o conserto é declarar o digesto novo na
entrada do catálogo.

## Como se reverte

A reversão depende da compatibilidade do código anterior com o banco e os trabalhos pendentes.
Antes da atualização, preserve backup consistente de arquivos e banco e o ZIP/hash da versão instalada.
Valide a recuperação em cópia isolada; uma troca de ZIP não reverte migrações nem dados já gravados.

A fila persistente de CAPI não pode voltar ao consumidor `1.9.2`. Preserve a fila e pause seus
consumidores no executor antes de uma recuperação, verificando reservas em curso. Token vazio
isoladamente não comprova pausa. Prefira correção compatível com o estado atual. Restaurar banco
antigo pode perder leads novos e ressuscitar conversões já enviadas: exige reconciliação explícita.

Reverter somente a opção Google para `imediato` usa o canal oficial, revisão atual e o fluxo de
cache. Para voltar o llms à entrega dinâmica, retire apenas o arquivo comprovadamente pertencente
ao Core e confira a URL pública. Consulte [Operação atual](docs/OPERACAO.md).

## Como se desinstala, e o que fica

Apagar o plugin pelo painel executa `uninstall.php`, e ele roda como o WordPress o roda: com
o plugin **inativo**, num processo novo, com `WP_UNINSTALL_PLUGIN` definida. Quem prova isso
a cada rodada é `wp.desinstalacao_limpa`, na bancada real — e provar isso importa porque a
desinstalação já morreu em erro fatal antes de remover coisa nenhuma.

**Sai tudo o que é estado de execução** — coisa que o plugin produziu sozinho e sabe
recriar: os carimbos de atividade, o segredo do endpoint, o estado da cadência, a auditoria
de escritas do canal, a procedência das gravações, a lista de chaves operáveis, os
agendamentos, transientes e tabelas próprias: deduplicação e recusas de leads, comportamento,
eventos, acessos, contribuições de logs, decisões de consentimento, vitais e fila CAPI.
O llms físico só é retirado quando sua propriedade está comprovada; se a retirada falhar, sua prova
de propriedade permanece para recuperação. O robots gerenciado segue sua restauração com backup.

**Fica, por decisão declarada:**

- os **registros de lead** — o tipo de conteúdo de contingência e a caixa do Flamingo.
  Desinstalar um plugin não é um pedido de eliminação de dado pessoal, e esses registros são
  o histórico comercial de quem opera o site;
- o **journal de eliminação**, que é a prova do que já foi apagado e quando. Apagá-lo junto
  destruiria exatamente o registro que uma auditoria procuraria depois;
- as **options de configuração** — identificadores de conta, número de contato, prazos,
  `llms.txt`, cabeçalhos. Reinstalar devolve o site ao que ele era; apagá-las obrigaria a
  reconfigurar tudo à mão depois de uma desinstalação feita por engano.

A remoção do que fica tem rota própria, com capability, journal e regime declarado. Toda
escrita passa pelo gravador único, inclusive na desinstalação.

## A fronteira com o implantador

Quatro classes de regra e uma tabela de dados são lidas pelos DOIS runtimes: o contrato de
chaves de SEO, o vocabulário comum, a regra do emissor concorrente, o censo de conteúdo
demonstrativo e a declaração de emissores conhecidos. **Elas moram AQUI.** Este repositório
é o dono delas; a fonte é esta, e o zip do plugin as leva dentro.

O implantador **vendoriza uma cópia** delas, porque precisa lê-las antes de o plugin existir
na instalação — o preflight roda antes de qualquer plugin ser instalado, e o modo
somente-relatório roda em site que talvez nunca tenha recebido o plugin. Cópia vendorizada
diverge se ninguém a conferir, e conferi-la contra o zip publicado é trabalho do repositório
do implantador, não deste.

Quem **publica** o zip é quem opera a release: este repositório o MONTA e o sela, e a
publicação no catálogo é o passo do operador descrito acima. O implantador **instala** o que
o catálogo publicou, e não constrói nada.

## Onde reportar

Abra a questão no repositório declarado em `Plugin URI`, no cabeçalho do arquivo principal
do plugin — é o mesmo endereço que o WordPress mostra na tela de plugins.

Um relato útil traz três coisas, e a suíte as produz sozinha: a saída completa do comando
único, a saída do piso, e o `sha256` do artefato que estava instalado. Defeito de produto
que a suíte não acusa é, antes de tudo, uma checagem que falta — e o caminho para consertá-lo
é o que está escrito em `fontes/plugin/INSTRUCOES-DO-PLUGIN.md`, na seção que diz o que a
suíte cobra de quem mexer: primeiro a checagem que acusa com a frase do caso real, depois a
correção, e o piso que prova que a checagem sabe reprovar.

## Operação dos acessos e da sessão

O padrão dos logs usa `~/logs/exemplo.com/https/access.log.*` mesmo quando a home pública é `www.exemplo.com`. Apenas o prefixo `www.` é removido; outros subdomínios são preservados. Na atualização, o antigo padrão exato é corrigido automaticamente. Caminhos personalizados permanecem como foram gravados.

A atualização adiciona **Medição → Acessos**. Confira o domínio no padrão de log e use **Somar agora**; o estado informa fonte indisponível e importação parcial. Apenas dias ainda disponíveis no servidor entram na primeira importação. A configuração dos dois módulos aparece no catálogo normal do plugin, com impacto e exemplo em cada campo.

Na desinstalação, `f3base_acessos` é derrubada, `f3base_acessos_estado` é removida e os eventos de soma e continuação são desagendados. As configurações `f3base_acessos` e `f3base_sessao` ficam preservadas. A duração nova vale para os próximos logins; mudar a configuração não revoga sessões existentes. A recuperação do código segue o procedimento de compatibilidade e backup acima; para revogar sessões, use o controle do perfil do WordPress.

A resolução de `~/` consulta o ambiente, os diretórios de usuário disponíveis via POSIX e até dezesseis níveis acima da instalação. O diretório completo dos logs deve existir e ser único; aliases para a mesma pasta são deduplicados. Não há usuário, domínio nem fornecedor fixo no código. Ausência, ambiguidade e falta de arquivos datados têm diagnósticos separados. Um caminho absoluto continua disponível para outras disposições de diretórios.

## Revisão da publicação para leitores automáticos

O índice llms.txt escapa Markdown, aplica a mesma validação a itens manuais e automáticos e oferece alternativas Markdown do conteúdo editorial público. A descoberta aparece no HTML e os arquivos respeitam a visibilidade do site. O gerador de robots.txt preserva as regras virtuais do WordPress e anuncia o sitemap disponível. Ao ativar sua opção, guarda o original físico e retira seu nome público; ao desligar, restaura o original se nenhum arquivo ocupa o caminho. O relatório de entrega documenta as fontes oficiais e os limites da publicação.

## Entrega pública do robots.txt

A publicação é confirmada pelo conteúdo da resposta HTTP. O gerador preserva os filtros tardios do Yoast e deduplica referências ao mesmo sitemap. Hospedagens que interceptam a rota virtual recebem um arquivo gerenciado, atualizado automaticamente pelo WP-Cron. O original permanece em backup, e edições externas são preservadas na atualização e na desativação. A ausência de arquivo físico, isoladamente, deixa o diagnóstico pendente. Consulte as instruções do plugin para periodicidade, recuperação e limites operacionais.


## Configuração e medição atualizadas

As opções editáveis abrem na aba Configurações; o estado das partes fica em Informações técnicas.
O campo de tipos do llms.txt permite marcar os tipos públicos disponíveis. A medição apresenta
Desde o anterior entre acionamentos da mesma visita, com limites de interpretação descritos na tela.
Os orçamentos foram ampliados em cinquenta por cento. O relatório de entrega detalha os valores.

## Filtro de acessos

Mostrar todos começa desmarcado em Medição → Acessos. A visão padrão mostra a home,
páginas e artigos publicados e os arquivos robots.txt, sitemap, llms.txt e llms-full.txt.
Marcar e clicar em Atualizar inclui os demais caminhos disponíveis. O filtro vale
para histórico e hoje, antes do ranking, e preserva a coleta. Consulte o manual
`fontes/plugin/INSTRUCOES-DO-PLUGIN.md`.

O campo Classificação permite selecionar somente conteúdo, arquivos de descoberta,
feeds, APIs, caminhos inexistentes ou outros caminhos. A classificação de inexistência
considera as respostas `404` e `410` registradas no log. Mostrar todos prevalece sobre
a seleção e mantém os filtros de período e status.


## Evolução da confiabilidade e do contato

A configuração carimba somente escritas confirmadas e registra recusas separadamente. O WhatsApp
flutuante é uma escolha explícita, desligada por padrão; os botões do tema pertencem ao layout.
A entrega acrescenta métricas oficiais com percentil e amostras, fila persistente de conversões,
configuração nativa pelo MCP, leitura incremental dos acessos e cache invalidável dos arquivos
llms. O navegador é exigido na validação. Consulte o manual do plugin e o relatório desta entrega.

## Distribuição das fontes

A evidência de cache guarda a última tentativa e o último
sucesso, mesmo depois de uma limpeza. A geração atual só é considerada
verificada quando a prova corresponde ao seu contexto e está dentro da
validade. O contrato acrescenta histórico, motivo da pendência, origem
da execução e situação do agendamento, preservando a habilidade v1.

O mesmo evento horário é antecipado após a limpeza;
executá-lo depende de WP-Cron por visitas ou do executor da hospedagem.
Consultas do contrato, da verificação e do painel não iniciam a sonda nem
reagendam eventos. Leases com validade, revisões condicionais e intervalos
limitam concorrência e repetição de tentativas.

O instalador continua sendo produzido por `bash suite/verificar.sh "$PWD"`.
Para distribuir o desenvolvimento, use `python3 suite/empacotar-fontes.py` após
validar a release. O comando lê `suite/fontes-inclusao.json`, copia somente os
caminhos declarados para um diretório vazio e acrescenta o manifesto de hashes.
Não exige Git no ambiente de quem reconstrói o pacote. Arquivos novos devem ser
incluídos explicitamente nesse manifesto.

`python3 suite/testar-fontes.py` verifica exclusão de resíduos, independência dos
horários dos arquivos e reconstrução idêntica do instalador. As referências de
regressão ficam em `suite/referencias/releases/referencias.json`, com finalidade,
consumidor e hash. As evidências da implementação atual ficam em `suite/evidencias-110/`; os ensaios antigos
são identificados como regressões, não como aprovação atual. O pacote de fontes não inclui
Git, dependências instaladas de desenvolvimento, bancos de bancada ou instaladores sem consumidor.
As instruções atuais de operação e homologação estão em `docs/OPERACAO.md`.
