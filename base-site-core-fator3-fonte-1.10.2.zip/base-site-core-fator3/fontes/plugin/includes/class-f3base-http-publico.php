<?php
/** Transporte limitado a destinos HTTP públicos; cada redirecionamento é revalidado. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Http_Publico {
	public static function buscar( string $url, int $limite = 2097152, float $fim = 0, string $metodo = 'GET', array $headers = array() ): array {
		$inicio   = microtime( true );
		$original = $url;
		$cadeia   = array();
		$fim      = $fim ? $fim : $inicio + 10;
		for ( $salto = 0; $salto <= 3; ++$salto ) {
			$p    = wp_parse_url( $url );
			$host = (string) ( $p['host'] ?? '' );
			if ( ! in_array( $p['scheme'] ?? '', array( 'http', 'https' ), true ) || isset( $p['user'] ) || isset( $p['pass'] ) || ! wp_http_validate_url( $url ) || ! self::host_publico( $host ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'destino_nao_publico',
					'status' => 0,
				); }
			$restante = $fim - microtime( true );
			if ( $restante <= 0 ) {
				return array(
					'ok'     => false,
					'codigo' => 'orcamento_esgotado',
					'status' => 0,
				); }
			$r = wp_safe_remote_request(
				$url,
				array(
					'method'              => 'HEAD' === $metodo ? 'HEAD' : 'GET',
					'timeout'             => min( 10, $restante ),
					'redirection'         => 0,
					'limit_response_size' => $limite + 1,
					'cookies'             => array(),
					'headers'             => array( 'Accept' => '*/*' ) + array_intersect_key( $headers, array_flip( array( 'If-None-Match', 'If-Modified-Since' ) ) ),
					'reject_unsafe_urls'  => true,
				)
			);
			if ( is_wp_error( $r ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'http_indisponivel',
					'status' => 0,
				); }
			$status   = wp_remote_retrieve_response_code( $r );
			$cadeia[] = array(
				'url'    => $url,
				'status' => $status,
			);
			if ( in_array( $status, array( 301, 302, 303, 307, 308 ), true ) ) {
				$destino = wp_remote_retrieve_header( $r, 'location' );
				if ( ! $destino || 3 === $salto ) {
					return array(
						'ok'     => false,
						'codigo' => 'redirecionamento_limite',
						'status' => $status,
					); }
				$url = WP_Http::make_absolute_url( $destino, $url );
				continue;
			}
			$corpo = wp_remote_retrieve_body( $r );
			if ( strlen( $corpo ) > $limite ) {
				return array(
					'ok'     => false,
					'codigo' => 'resposta_truncada',
					'status' => $status,
				); }
			$cabecalhos = array();
			foreach ( array( 'content-type', 'cache-control', 'x-robots-tag', 'etag', 'last-modified' ) as $h ) {
				$cabecalhos[ $h ] = (string) wp_remote_retrieve_header( $r, $h ); }
			return array(
				'ok'           => 200 === $status,
				'codigo'       => 200 === $status ? 'http_200' : 'http_status',
				'status'       => $status,
				'url_final'    => $url,
				'cadeia'       => $cadeia,
				'redirecionou' => $url !== $original,
				'corpo'        => $corpo,
				'cabecalhos'   => $cabecalhos,
				'duracao_ms'   => round( ( microtime( true ) - $inicio ) * 1000, 1 ),
			);
		}
		return array(
			'ok'     => false,
			'codigo' => 'http_indisponivel',
			'status' => 0,
		);
	}
	private static function host_publico( string $host ): bool {
		$host = trim( $host, '[]' );
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			$ips = array( $host ); } else {
			$v4  = gethostbynamel( $host );
			$v6  = @dns_get_record( $host, DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de resolução produz destino recusado, sem expor aviso ao cliente.
			$ips = array_merge( is_array( $v4 ) ? $v4 : array(), array_column( is_array( $v6 ) ? $v6 : array(), 'ipv6' ) );
			}
			if ( ! $ips ) {
				return false; }
			foreach ( $ips as $ip ) {
				if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) || str_starts_with( strtolower( $ip ), '::ffff:' ) ) {
					return false; }
			}
			return true;
	}
}
