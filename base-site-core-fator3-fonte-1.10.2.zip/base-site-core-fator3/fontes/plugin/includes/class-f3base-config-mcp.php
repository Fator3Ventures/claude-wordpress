<?php
/**
 * A configuração do implantador, lida e escrita pelo agente MCP.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LER E ESCREVER A CONFIGURAÇÃO SEM EDITAR ARQUIVO ÀS CEGAS.
 *
 * POR QUE ISTO MORA NO PLUGIN, e não no implantador. O implantador se
 * autodesativa quando termina, e plugin desativado não registra habilidade
 * nenhuma. O momento em que o agente mais precisa preencher a configuração é
 * justamente DEPOIS disso — para a próxima execução. Uma habilidade que só
 * funcionasse antes de a ferramenta terminar não serviria para a hora em que ela
 * é necessária.
 *
 * A alternativa seria o plugin guardar a configuração numa option e o
 * implantador ler as duas fontes. Isso cria duas respostas para o mesmo valor, e
 * é o defeito que este pacote passa a vida fechando. Um plugin nosso escrevendo
 * no arquivo de outro plugin nosso, num caminho declarado, é o preço menor.
 *
 * ESCRITA É TUDO OU NADA. Configuração que não passa no schema é recusada com o
 * campo nomeado e NADA é gravado: meia configuração no disco é pior que nenhuma,
 * porque a execução seguinte parte de um estado que ninguém escolheu.
 */
final class F3Base_Config_Mcp {

	/**
	 * Arquivos que a habilidade conhece, e o schema de cada um.
	 *
	 * @var array<string,array<string,string>>
	 */
	private const ARQUIVOS = array(
		'projeto' => array(
			'config' => 'config/projeto.json',
			'schema' => 'config/projeto.schema.json',
		),
		'site'    => array(
			'config' => 'config/site.json',
			'schema' => 'config/site.schema.json',
		),
	);

	/**
	 * Registra as habilidades quando a API existir.
	 *
	 * O GANCHO E A CATEGORIA MORAM EM `F3Base_Site_Core::iniciar()`:
	 * `wp_abilities_api_init` (com o prefixo `wp_`, que é a grafia que o núcleo
	 * dispara) e `wp_abilities_api_categories_init`, que registra `f3base` antes.
	 * As duas coisas foram medidas num WordPress real: sem a categoria o núcleo
	 * recusa a habilidade, e no gancho sem prefixo nada é sequer chamado.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			'f3base/config-ler',
			array(
				'label'               => __( 'Ler a configuração do implantador', 'f3base' ),
				'description'         => __( 'Lê os JSONs de entrada do implantador e seus schemas. Estes arquivos descrevem uma implantação futura; o estado aplicado no site é consultado por f3base/config-core-ler e pelo contrato do Core.', 'f3base' ),
				'category'            => F3BASE_PREFIXO,
				/*
				 * `PROPERTIES` É ARRAY PHP, e isso não é descuido de serialização: um
				 * mapa com chaves de texto já sai como `{}` no JSON. O DEFEITO MEDIDO
				 * era `(object) array(...)` aqui e em `config-escrever`: o núcleo
				 * indexa `properties` como array ao validar cada campo da entrada
				 * (`rest_validate_object_value_from_schema`), e um `stdClass` derruba
				 * a chamada com Error antes de o callback existir — a habilidade
				 * estava no registro e morria com a entrada que o próprio schema pede.
				 * Medido em `wp.habilidades_de_config_executam`.
				 */
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'arquivo' => array(
							'type'        => 'string',
							'enum'        => array( 'projeto', 'site' ),
							'description' => __( '"projeto" é o arquivo que o operador preenche; "site" guarda conteúdo e referências internas.', 'f3base' ),
						),
					),
					'required'             => array( 'arquivo' ),
					'additionalProperties' => false,
				),
				'output_schema'       => self::schema_da_leitura(),
				'execute_callback'    => array( __CLASS__, 'ler' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
				'permission_callback' => static function ( $entrada = null ): bool {
					unset( $entrada );

					return current_user_can( 'manage_options' );
				},
			)
		);

		wp_register_ability(
			'f3base/config-escrever',
			array(
				'label'               => __( 'Escrever a configuração do implantador', 'f3base' ),
				'description'         => __( 'Edita somente o JSON do implantador, após validar o schema. Não aplica opções ao site. A execução do implantador deve usar a API do dono e respeitar sua recusa; para configuração imediata do Core use f3base/config-core-escrever.', 'f3base' ),
				'category'            => F3BASE_PREFIXO,
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'arquivo'  => array(
							'type'        => 'string',
							'enum'        => array( 'projeto', 'site' ),
							'description' => __( 'Qual dos dois pares de arquivo e schema será gravado.', 'f3base' ),
						),
						'conteudo' => array(
							'type'        => 'object',
							'description' => __( 'O arquivo INTEIRO, não um pedaço: leia antes, altere o que precisa e devolva o todo.', 'f3base' ),
						),
					),
					'required'             => array( 'arquivo', 'conteudo' ),
					'additionalProperties' => false,
				),
				'output_schema'       => self::schema_da_escrita(),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
				'execute_callback'    => array( __CLASS__, 'escrever' ),
				'permission_callback' => static function ( $entrada = null ): bool {
					unset( $entrada );

					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * O QUE `config-ler` DEVOLVE, campo a campo.
	 *
	 * `ok` é o campo que decide, e ele existe nos dois desfechos: a resposta de
	 * erro traz `ok: false` e `erro`, e nunca conteúdo pela metade.
	 *
	 * @return array<string,mixed>
	 */
	public static function schema_da_leitura(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'scope'               => array(
					'type' => 'string',
					'enum' => array( 'installer_json' ),
				),
				'site_config_applied' => array(
					'type'        => 'boolean',
					'description' => 'Sempre false: esta operação edita apenas o arquivo de entrada do implantador.',
				),
				'ok'                  => array(
					'type'        => 'boolean',
					'description' => __( 'Falso quando não houve leitura: o motivo está em "erro" e nenhum outro campo é confiável.', 'f3base' ),
				),
				'erro'                => array(
					'type'        => 'string',
					'description' => __( 'O que impediu a leitura, em português: implantador ausente, arquivo inexistente ou JSON ilegível.', 'f3base' ),
				),
				'arquivo'             => array(
					'type'        => 'string',
					'description' => __( 'Caminho relativo lido, dentro do diretório do implantador.', 'f3base' ),
				),
				'conteudo'            => array(
					'type'        => 'object',
					'description' => __( 'O arquivo de configuração inteiro, decodificado.', 'f3base' ),
				),
				'schema'              => array(
					'type'        => 'object',
					'description' => __( 'O schema correspondente, com um $comment por campo dizendo o que preencher e onde obter o valor.', 'f3base' ),
				),
				'como'                => array(
					'type'        => 'string',
					'description' => __( 'Como gravar de volta o que foi lido.', 'f3base' ),
				),
			),
			'required'   => array( 'ok' ),
		);
	}

	/**
	 * O QUE `config-escrever` DEVOLVE, campo a campo.
	 *
	 * @return array<string,mixed>
	 */
	public static function schema_da_escrita(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'scope'               => array(
					'type' => 'string',
					'enum' => array( 'installer_json' ),
				),
				'site_config_applied' => array(
					'type'        => 'boolean',
					'description' => 'Sempre false: esta operação edita apenas o arquivo de entrada do implantador.',
				),
				'ok'                  => array(
					'type'        => 'boolean',
					'description' => __( 'Falso quando nada foi gravado.', 'f3base' ),
				),
				'gravou'              => array(
					'type'        => 'boolean',
					'description' => __( 'Verdadeiro só quando o arquivo foi substituído por inteiro e a contagem de bytes conferiu.', 'f3base' ),
				),
				'erro'                => array(
					'type'        => 'string',
					'description' => __( 'O que impediu a gravação. Escrita é tudo ou nada: com erro, o arquivo continua exatamente como estava.', 'f3base' ),
				),
				'campos'              => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => __( 'Os campos que não passaram no schema, um por item.', 'f3base' ),
				),
				'arquivo'             => array(
					'type'        => 'string',
					'description' => __( 'Caminho relativo gravado.', 'f3base' ),
				),
				'bytes'               => array(
					'type'        => 'integer',
					'description' => __( 'Tamanho conferido do arquivo depois da substituição.', 'f3base' ),
				),
				'aviso'               => array(
					'type'        => 'string',
					'description' => __( 'Quando o valor gravado passa a valer.', 'f3base' ),
				),
			),
			'required'   => array( 'ok' ),
		);
	}

	/**
	 * OS DIRETÓRIOS QUE PARECEM O IMPLANTADOR, todos eles.
	 *
	 * A busca é pelo SCHEMA do projeto, não pelo nome da pasta: o implantador é
	 * renomeado a cada site — o prefixo técnico é do projeto —, e procurar por
	 * um slug fixo encontraria o pacote de um site e não o de outro.
	 *
	 * DEVOLVE A LISTA INTEIRA porque a quantidade é a informação: `glob()[0]`
	 * escolhia o primeiro em ordem alfabética e escrevia nele em silêncio. Com
	 * duas cópias instaladas — o caso real é uma pasta antiga deixada para trás
	 * na renomeação —, a configuração ia para a que não roda, e a execução
	 * seguinte partia do arquivo que ninguém tinha alterado.
	 *
	 * @return array<int,string> Caminhos absolutos com barra final, em ordem.
	 */
	public static function diretorios(): array {
		if ( ! defined( 'WP_PLUGIN_DIR' ) || ! is_dir( WP_PLUGIN_DIR ) ) {
			return array();
		}

		$pastas = glob( WP_PLUGIN_DIR . '/*/config/projeto.schema.json' );

		if ( ! is_array( $pastas ) ) {
			return array();
		}

		$saida = array();

		foreach ( $pastas as $schema ) {
			$saida[] = dirname( dirname( (string) $schema ) ) . '/';
		}

		sort( $saida );

		return $saida;
	}

	/**
	 * O DIRETÓRIO DO IMPLANTADOR, quando há exatamente um.
	 *
	 * @return string Caminho absoluto com barra final, ou vazio quando não há um
	 *                único candidato.
	 */
	public static function diretorio(): string {
		$candidatos = self::diretorios();

		return 1 === count( $candidatos ) ? $candidatos[0] : '';
	}

	/**
	 * Lê um arquivo de configuração e o schema dele.
	 *
	 * A ENTRADA PODE CHEGAR `NULL`, e com `strict_types=1` um parâmetro tipado
	 * `array` sem padrão seguro derruba a chamada com TypeError. Uma habilidade
	 * que existe no registro e falha ao executar é pior que uma que não existe:
	 * o agente a encontra, confia nela e recebe erro de tipo.
	 *
	 * @param mixed $entrada Entrada da habilidade.
	 * @return array<string,mixed>
	 */
	public static function ler( $entrada = null ): array {
		$entrada = is_array( $entrada ) ? $entrada : array();
		$qual    = (string) ( $entrada['arquivo'] ?? 'projeto' );
		$onde    = self::localizar( $qual );

		if ( '' !== $onde['erro'] ) {
			return array(
				'ok'   => false,
				'erro' => $onde['erro'],
			);
		}

		/*
		 * JSON QUEBRADO É ERRO, e não `conteudo: null`.
		 *
		 * O DEFEITO MEDIDO: `json_decode()` de um arquivo corrompido devolve
		 * `null`, e a resposta saía `ok: true, conteudo: null`. Para o agente
		 * isso é indistinguível de "a configuração está vazia" — e o passo
		 * natural dele a partir daí é gravar o arquivo INTEIRO a partir do nada,
		 * apagando uma configuração que ainda estava lá em disco, ilegível mas
		 * inteira. `ok: false` com o nome do arquivo e o erro do parser é o que
		 * manda alguém olhar o disco em vez de reescrevê-lo.
		 */
		$lidos = array();

		foreach ( array( 'config', 'schema' ) as $parte ) {
			$bruto = file_get_contents( $onde[ $parte ] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo local do próprio pacote, sem rede.

			if ( ! is_string( $bruto ) ) {
				return array(
					'ok'   => false,
					'erro' => sprintf(
						/* translators: %s: caminho relativo do arquivo. */
						__( 'O arquivo %s existe e não pôde ser lido. Confira a permissão de leitura da pasta do implantador; nada foi alterado.', 'f3base' ),
						self::ARQUIVOS[ $qual ][ $parte ]
					),
				);
			}

			$decodificado = json_decode( $bruto, true );

			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decodificado ) ) {
				return array(
					'ok'   => false,
					'erro' => sprintf(
						/* translators: 1: caminho relativo do arquivo, 2: erro do decodificador JSON. */
						__( 'O arquivo %1$s está em disco e NÃO é um JSON de objeto legível: %2$s. Nada foi lido e nada deve ser gravado por cima — reescrevê-lo a partir do nada apagaria a configuração que ainda está ali. Corrija o arquivo no disco e leia de novo.', 'f3base' ),
						self::ARQUIVOS[ $qual ][ $parte ],
						json_last_error_msg()
					),
				);
			}

			$lidos[ $parte ] = $decodificado;
		}

		return array(
			'ok'                  => true,
			'arquivo'             => self::ARQUIVOS[ $qual ]['config'],
			'conteudo'            => $lidos['config'],
			'schema'              => $lidos['schema'],
			'como'                => __( 'Edite o JSON inteiro por f3base/config-escrever. Isso prepara a próxima execução do implantador; não aplica configuração ao site. Consulte o estado efetivo por f3base/config-core-ler.', 'f3base' ),
			'scope'               => 'installer_json',
			'site_config_applied' => false,
		);
	}

	/**
	 * Grava um arquivo de configuração, depois de validá-lo.
	 *
	 * @param array<string,mixed> $entrada Entrada da habilidade.
	 * @return array<string,mixed>
	 */
	public static function escrever( $entrada = null ): array {
		$r                        = self::escrever_json( $entrada );
		$r['scope']               = 'installer_json';
		$r['site_config_applied'] = false;
		return $r;
	}
	private static function escrever_json( $entrada = null ): array {
		$entrada  = is_array( $entrada ) ? $entrada : array();
		$qual     = (string) ( $entrada['arquivo'] ?? 'projeto' );
		$conteudo = $entrada['conteudo'] ?? null;

		/*
		 * `DISALLOW_FILE_MODS` É RECUSA, e ela vem antes de tudo. A constante é
		 * como um site declara que o código dele não se altera por dentro — é o
		 * que o núcleo obedece para esconder instalação e edição de plugin. Um
		 * plugin que escreve no diretório de plugins ignorando essa declaração
		 * está fazendo exatamente o que ela proíbe, pela porta dos fundos.
		 */
		if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
			return array(
				'ok'     => false,
				'gravou' => false,
				'erro'   => __( 'Este site declara DISALLOW_FILE_MODS: nenhuma escrita no diretório de plugins é permitida, e esta habilidade obedece à declaração. Nada foi gravado. Quem quiser gravar a configuração por aqui precisa retirar a constante do wp-config.php — e essa é uma decisão de quem opera a hospedagem.', 'f3base' ),
			);
		}

		$onde = self::localizar( $qual );

		if ( '' !== $onde['erro'] ) {
			return array(
				'ok'   => false,
				'erro' => $onde['erro'],
			);
		}

		if ( ! is_array( $conteudo ) ) {
			return array(
				'ok'   => false,
				'erro' => __( 'O conteúdo precisa ser um objeto com o arquivo inteiro. Leia com f3base/config-ler, altere o que precisa e devolva o todo.', 'f3base' ),
			);
		}

		$erros = self::validar( $conteudo, $onde['schema'] );

		if ( array() !== $erros ) {
			return array(
				'ok'     => false,
				'gravou' => false,
				'erro'   => __( 'A configuração não passou no schema e NADA foi gravado. O arquivo continua como estava.', 'f3base' ),
				'campos' => $erros,
			);
		}

		$json = wp_json_encode( $conteudo, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		if ( ! is_string( $json ) ) {
			return array(
				'ok'   => false,
				'erro' => __( 'O conteúdo não pôde ser convertido para JSON e nada foi gravado.', 'f3base' ),
			);
		}

		return self::gravar_arquivo( $onde['config'], self::ARQUIVOS[ $qual ]['config'], $json . "\n" );
	}

	/**
	 * A GRAVAÇÃO FÍSICA: duas fases, trava exclusiva e bytes conferidos.
	 *
	 * GRAVAÇÃO EM DUAS FASES: escreve ao lado e renomeia por cima. Uma escrita
	 * interrompida no meio do arquivo deixaria a configuração truncada, e a
	 * execução seguinte partiria de um JSON quebrado. `rename()` no mesmo
	 * sistema de arquivos é atômico: ou o arquivo é o novo, ou é o velho.
	 *
	 * `LOCK_EX` NA ESCRITA DO TEMPORÁRIO, e ele não é redundante com o rename.
	 * O canal MCP não serializa chamadas: duas gravações simultâneas do mesmo
	 * par escreveriam no MESMO arquivo `.novo` ao mesmo tempo e o rename
	 * publicaria a intercalação dos dois JSON — um arquivo que nenhuma das duas
	 * chamadas escreveu.
	 *
	 * OS BYTES SÃO CONFERIDOS DEPOIS DO RENAME. `file_put_contents()` devolve a
	 * contagem que ELE escreveu, e um disco cheio devolve um número menor sem
	 * erro nenhum; o que interessa é o que ficou em disco no caminho final. É a
	 * mesma leitura de volta que o gravador de options faz, pelo mesmo motivo.
	 *
	 * `WP_FILESYSTEM` FOI CONSIDERADO E ESTÁ AQUI PELO QUE ELE RESPONDE: a
	 * pergunta "este site permite escrita direta?". `get_filesystem_method()`
	 * devolve `direct` quando o PHP escreve com o próprio usuário — e é só nesse
	 * caso que esta habilidade grava. Quando a resposta é `ftp`/`ssh`, a escrita
	 * exigiria CREDENCIAL do operador, que uma chamada de agente não tem e não
	 * deve pedir: ali a gravação é recusada dizendo o método que o site exige.
	 * A escrita em si continua sendo do PHP, porque o alvo é um arquivo do
	 * próprio diretório de plugins e o método já foi confirmado como direto.
	 *
	 * @param string $absoluto Caminho absoluto do arquivo final.
	 * @param string $relativo Caminho relativo, para as frases.
	 * @param string $json     Conteúdo já serializado.
	 * @return array<string,mixed>
	 */
	private static function gravar_arquivo( string $absoluto, string $relativo, string $json ): array {
		if ( ! function_exists( 'get_filesystem_method' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$metodo = get_filesystem_method( array(), dirname( $absoluto ), false );

		if ( 'direct' !== $metodo ) {
			return array(
				'ok'     => false,
				'gravou' => false,
				'erro'   => sprintf(
					/* translators: %s: método de sistema de arquivos que o WordPress exige neste site. */
					__( 'Este site não permite escrita direta em arquivo: o WordPress exige o método "%s", que pede credencial do operador. Uma chamada de agente não tem essa credencial e não deve pedi-la, e por isso nada foi gravado. A configuração precisa ser editada por quem tem acesso ao disco.', 'f3base' ),
					(string) $metodo
				),
			);
		}

		$temporario = $absoluto . '.novo';
		$escritos   = file_put_contents( $temporario, $json, LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- arquivo do próprio pacote, escrita direta já confirmada por get_filesystem_method().

		if ( false === $escritos || strlen( $json ) !== (int) $escritos ) {
			if ( is_file( $temporario ) ) {
				unlink( $temporario ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- arquivo temporário criado por esta função.
			}

			return array(
				'ok'     => false,
				'gravou' => false,
				'erro'   => sprintf(
					/* translators: 1: bytes escritos, 2: bytes esperados. */
					__( 'A escrita do arquivo temporário saiu incompleta: %1$d de %2$d bytes. O arquivo de configuração NÃO foi tocado e continua como estava. Disco cheio ou cota da hospedagem estourada são as causas comuns.', 'f3base' ),
					(int) $escritos,
					strlen( $json )
				),
			);
		}

		if ( ! rename( $temporario, $absoluto ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- troca atômica no mesmo diretório; WP_Filesystem::move não garante esse contrato.
			unlink( $temporario ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- arquivo temporário criado por esta função.

			return array(
				'ok'     => false,
				'gravou' => false,
				'erro'   => __( 'Não foi possível substituir o arquivo de configuração, e nada foi gravado.', 'f3base' ),
			);
		}

		clearstatcache( true, $absoluto );

		$em_disco = (int) filesize( $absoluto );

		if ( strlen( $json ) !== $em_disco ) {
			return array(
				'ok'     => false,
				'gravou' => false,
				'bytes'  => $em_disco,
				'erro'   => sprintf(
					/* translators: 1: bytes em disco, 2: bytes esperados, 3: caminho relativo. */
					__( 'O arquivo foi substituído e a leitura de volta não confere: %1$d bytes em disco contra %2$d gravados em %3$s. Leia a configuração com f3base/config-ler antes de qualquer outra escrita.', 'f3base' ),
					$em_disco,
					strlen( $json ),
					$relativo
				),
			);
		}

		return array(
			'ok'      => true,
			'gravou'  => true,
			'arquivo' => $relativo,
			'bytes'   => $em_disco,
			'aviso'   => __( 'Gravado, e o tamanho foi conferido em disco depois da substituição. O valor só chega ao site na próxima execução do implantador.', 'f3base' ),
		);
	}

	/**
	 * Valida contra o schema, pelo validador do implantador.
	 *
	 * UM VALIDADOR SÓ. Escrever um segundo aqui seria um segundo conjunto de
	 * regras divergindo do primeiro, e o piso de mutantes que o do implantador
	 * tem não valeria para este.
	 *
	 * @param array<string,mixed> $dados  Conteúdo a validar.
	 * @param string              $schema Caminho absoluto do schema.
	 * @return array<int,string> Erros; vazio quando válido.
	 */
	public static function validar( array $dados, string $schema ): array {
		if ( ! class_exists( 'F3Base_Imp_Config' ) ) {
			$classe = self::diretorio() . 'includes/class-f3base-imp-config.php';

			if ( is_file( $classe ) ) {
				require_once $classe;
			}
		}

		if ( ! class_exists( 'F3Base_Imp_Config' ) ) {
			return array( __( 'O validador do implantador não está disponível, e gravar sem validar seria pior: nada foi gravado.', 'f3base' ) );
		}

		return F3Base_Imp_Config::validar_com_schema( $dados, $schema );
	}

	/**
	 * Localiza os dois arquivos de um par declarado.
	 *
	 * @param string $qual Nome do par.
	 * @return array{config:string,schema:string,erro:string}
	 */
	private static function localizar( string $qual ): array {
		$vazio = array(
			'config' => '',
			'schema' => '',
			'erro'   => '',
		);

		if ( ! isset( self::ARQUIVOS[ $qual ] ) ) {
			$vazio['erro'] = sprintf(
				/* translators: %s: nomes aceitos. */
				__( 'Arquivo desconhecido. Os aceitos são: %s.', 'f3base' ),
				implode( ', ', array_keys( self::ARQUIVOS ) )
			);

			return $vazio;
		}

		$candidatos = self::diretorios();

		if ( array() === $candidatos ) {
			$vazio['erro'] = __( 'O implantador não está instalado neste site: não há configuração para ler nem para escrever. Instale o plugin do implantador e tente de novo.', 'f3base' );

			return $vazio;
		}

		/*
		 * DOIS IMPLANTADORES É RECUSA COM OS DOIS NOMES.
		 *
		 * O DEFEITO MEDIDO era `glob()[0]`: com duas cópias instaladas — o caso
		 * real é a pasta antiga deixada para trás por uma renomeação de prefixo —
		 * a escrita ia para a PRIMEIRA em ordem alfabética, que não é
		 * necessariamente a que roda. A configuração era gravada com sucesso, a
		 * resposta dizia "gravado", e a execução seguinte partia do outro
		 * arquivo, intocado. Escolher em silêncio entre dois candidatos é a
		 * forma mais cara de errar: ninguém procura o erro, porque não houve um.
		 */
		if ( count( $candidatos ) > 1 ) {
			$nomes = array_map( 'basename', array_map( static fn ( string $c ): string => rtrim( $c, '/' ), $candidatos ) );

			$vazio['erro'] = sprintf(
				/* translators: %s: nomes das pastas encontradas, separados por vírgula. */
				__( 'Há mais de um implantador instalado neste site e esta habilidade não escolhe entre eles: %s. Escrever em um dos dois em silêncio gravaria a configuração na cópia que talvez não seja a que roda, e a execução seguinte partiria do arquivo intocado. Remova ou renomeie a cópia que não é mais usada e tente de novo. Nada foi lido e nada foi gravado.', 'f3base' ),
				implode( ', ', $nomes )
			);

			return $vazio;
		}

		$dir = $candidatos[0];

		$config = $dir . self::ARQUIVOS[ $qual ]['config'];
		$schema = $dir . self::ARQUIVOS[ $qual ]['schema'];

		if ( ! is_file( $config ) || ! is_file( $schema ) ) {
			$vazio['erro'] = sprintf(
				/* translators: %s: caminho do arquivo procurado. */
				__( 'O implantador está instalado, mas %s não existe nele.', 'f3base' ),
				self::ARQUIVOS[ $qual ]['config']
			);

			return $vazio;
		}

		return array(
			'config' => $config,
			'schema' => $schema,
			'erro'   => '',
		);
	}
}
