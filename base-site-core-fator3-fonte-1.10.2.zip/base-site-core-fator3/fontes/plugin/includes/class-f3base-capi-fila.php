<?php
/** Fila persistente. A confirmação externa e a persistência local são resultados distintos. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Capi_Fila {
	public const TABELA                    = 'f3base_capi_fila';
	public const EVENTO                    = 'f3base_capi_recuperar';
	public const TETO_PENDENTES            = 1000;
	public const MAX_TENTATIVAS            = 6;
	public const PRAZO_RESERVA             = 120;
	public const HISTORICO_DIAS            = 7;
	public const SCHEMA                    = 2;
	private static bool $schema_confirmado = false;
	public static function tabela(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABELA; }
	public static function pronta(): bool {
		global $wpdb;
		$t = self::tabela();
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) === $t;
	}
	/** Cada passo é verificável e repetível; consumidores não usam schema incompleto. */
	public static function instalar(): bool {
		if ( self::$schema_confirmado ) {
			return true; }
		global $wpdb;
		$t = self::tabela();
		if ( ! self::pronta() ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta(
				"CREATE TABLE {$t} (
				record_id varchar(128) NOT NULL,
				payload longtext NOT NULL,
				estado varchar(16) NOT NULL,
				tentativas int unsigned NOT NULL DEFAULT 0,
				proxima bigint unsigned NOT NULL DEFAULT 0,
				expira bigint unsigned NOT NULL,
				atualizado bigint unsigned NOT NULL,
				reserva varchar(64) NOT NULL DEFAULT '',
				http int NOT NULL DEFAULT 0,
				PRIMARY KEY  (record_id),
				KEY pendentes (estado,proxima),
				KEY expiracao (expira)
			) {$wpdb->get_charset_collate()};"
			);
		}
		if ( ! self::pronta() ) {
			return false; }
		$novas   = array(
			'pixel_id'           => "varchar(64) NOT NULL DEFAULT ''",
			'decisao_ref'        => "varchar(64) NOT NULL DEFAULT ''",
			'politica_versao'    => "varchar(64) NOT NULL DEFAULT ''",
			'iniciado'           => 'bigint unsigned NOT NULL DEFAULT 0',
			'cancelado'          => 'bigint unsigned NOT NULL DEFAULT 0',
			'lead_id'            => 'bigint unsigned NOT NULL DEFAULT 0',
			'eliminar_lead'      => 'int NOT NULL DEFAULT 0',
			'limpeza_pendente'   => 'int NOT NULL DEFAULT 0',
			'motivo'             => "varchar(64) NOT NULL DEFAULT ''",
			'agendamento_falhou' => 'int NOT NULL DEFAULT 0',
			'schema_versao'      => 'int NOT NULL DEFAULT 1',
		);
		$colunas = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $t ) );
		foreach ( $novas as $nome => $tipo ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Tabela deriva do prefixo WordPress; coluna e tipo pertencem ao mapa fechado de migração acima.
			if ( ! in_array( $nome, $colunas, true ) && false === $wpdb->query( "ALTER TABLE {$t} ADD COLUMN {$nome} {$tipo}" ) ) {
				return false; }
		}
		$colunas = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $t ) );
		if ( array_diff( array_keys( $novas ), $colunas ) ) {
			return false; }
		// O destino e a decisão antigos não são inferidos da preferência atual.
		if ( false === $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado=CASE WHEN payload<>'' THEN 'suspenso' ELSE estado END,motivo=CASE WHEN payload<>'' THEN 'destino_nao_identificado' ELSE motivo END,schema_versao=2 WHERE schema_versao<2", $t ) ) ) {
			return false; }
		$restantes               = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE schema_versao<2', $t ) );
		self::$schema_confirmado = null !== $restantes && '' === $wpdb->last_error && 0 === (int) $restantes;
		return self::$schema_confirmado;
	}
	/** Próximo trabalho em até um minuto; falhas de agendamento ficam na própria fila. */
	public static function planejar(): bool {
		if ( ! self::pronta() ) {
			return false; }
		global $wpdb;
		$t         = self::tabela();
		$agora     = time();
		$mais_cedo = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MIN(proxima) FROM %i WHERE estado IN ('pendente','reservado','enviando','cancelando') OR limpeza_pendente=1", $t ) );
		$expira    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MIN(expira) FROM %i WHERE payload<>''", $t ) );
		$quando    = ( $mais_cedo || $expira ) ? max( $agora + 1, min( $agora + 60, $mais_cedo > 0 ? $mais_cedo : $agora + 60, $expira > 0 ? $expira : $agora + 60 ) ) : $agora + DAY_IN_SECONDS;
		$atual     = wp_next_scheduled( self::EVENTO );
		if ( $atual && (int) $atual <= $quando ) {
			return true; }
		if ( $atual && false === wp_unschedule_event( (int) $atual, self::EVENTO ) ) {
			return false; }
		$ok = true === wp_schedule_single_event( $quando, self::EVENTO );
		$wpdb->query( $wpdb->prepare( "UPDATE %i SET agendamento_falhou=%d WHERE payload<>'' OR limpeza_pendente=1", $t, $ok ? 0 : 1 ) );
		return $ok;
	}
	/** A única instrução INSERT…SELECT serializa o limite junto da inserção no SQLite. */
	public static function inserir( string $id, array $payload, int $ttl, string $pixel = '', array $consentimento = array() ): bool {
		if ( '' === $id || strlen( $id ) > 128 || $ttl <= 0 || ! self::instalar() ) {
			return false; }
		global $wpdb;
		$t         = self::tabela();
		$agora     = time();
		$existente = self::ler( $id );
		if ( $existente ) {
			return 0 === (int) $existente['cancelado'] && '' !== $existente['payload']; }
		$estado = '' === $pixel ? 'suspenso' : 'pendente';
		$motivo = '' === $pixel ? 'destino_nao_identificado' : '';
		$ok     = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO %i (record_id,payload,estado,tentativas,proxima,expira,atualizado,reserva,http,pixel_id,decisao_ref,politica_versao,motivo,schema_versao) SELECT %s,%s,%s,0,%d,%d,%d,'',0,%s,%s,%s,%s,2 WHERE (SELECT COUNT(*) FROM %i WHERE payload<>'')<%d", $t, $id, wp_json_encode( $payload ), $estado, $agora, $agora + min( DAY_IN_SECONDS, $ttl ), $agora, $pixel, (string) ( $consentimento['decisao_ref'] ?? '' ), (string) ( $consentimento['politica_versao'] ?? '' ), $motivo, $t, self::TETO_PENDENTES ) );
		if ( 1 === $ok ) {
			self::planejar();
			return true; }
		$r = self::ler( $id );
		return $r && 0 === (int) $r['cancelado'] && '' !== $r['payload'];
	}
	public static function ler( string $id ): ?array {
		if ( ! self::pronta() ) {
			return null; }
		global $wpdb;
		$registro = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE record_id=%s', self::tabela(), $id ), ARRAY_A );
		return is_array( $registro ) ? $registro : null;
	}
	public static function reservar( string $id ): ?array {
		if ( ! self::instalar() ) {
			return null; }
		global $wpdb;
		$t       = self::tabela();
		$agora   = time();
		$reserva = wp_generate_uuid4();
		$ok      = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado='reservado',reserva=%s,proxima=%d,atualizado=%d WHERE record_id=%s AND estado IN ('pendente','reservado') AND cancelado=0 AND proxima<=%d AND expira>%d AND tentativas<%d AND payload<>''", $t, $reserva, $agora + self::PRAZO_RESERVA, $agora, $id, $agora, $agora, self::MAX_TENTATIVAS ) );
		if ( 1 !== $ok ) {
			return null; }
		$r = self::ler( $id );
		return $r && hash_equals( $reserva, $r['reserva'] ) ? $r : null;
	}
	/** Ponto de ordenação entre cancelamento/revogação e despacho HTTP. Nunca mantém transação durante rede. */
	public static function iniciar_envio( array $r ): array {
		global $wpdb;
		$t     = self::tabela();
		$agora = time();
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'banco_indisponivel',
			); }
		try {
			$ok = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado='enviando',iniciado=%d,tentativas=tentativas+1,atualizado=%d WHERE record_id=%s AND estado='reservado' AND reserva=%s AND proxima>%d AND expira>%d AND cancelado=0", $t, $agora, $agora, $r['record_id'], $r['reserva'], $agora, $agora ) );
			if ( 1 !== $ok ) {
				throw new RuntimeException( 'reserva_perdida' ); }
			$motivo = '';
			if ( '' === $r['pixel_id'] || ! hash_equals( $r['pixel_id'], F3Base_Modulo_Meta_Capi::pixel_id() ) ) {
				$motivo = 'destino_incompativel'; }
			if ( '' === F3Base_Modulo_Meta_Capi::token() ) {
				$motivo = 'token_ausente'; }
			if ( class_exists( 'F3Base_Consentimento_Decisoes' ) && ! F3Base_Consentimento_Decisoes::permite_capi( (string) $r['decisao_ref'], (string) $r['politica_versao'] ) ) {
				$motivo = 'consentimento_indisponivel'; }
			if ( '' !== $motivo ) {
				if ( false === $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado='suspenso',motivo=%s,reserva='',iniciado=0,tentativas=tentativas-1 WHERE record_id=%s AND reserva=%s", $t, $motivo, $r['record_id'], $r['reserva'] ) ) ) {
					throw new RuntimeException( 'banco_indisponivel' ); }
			}
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				throw new RuntimeException( 'confirmacao_falhou' ); }
			return array(
				'ok'       => '' === $motivo,
				'codigo'   => '' !== $motivo ? $motivo : 'iniciado',
				'registro' => self::ler( $r['record_id'] ),
			);
		} catch ( Throwable $erro ) {
			$wpdb->query( 'ROLLBACK' );
			return array(
				'ok'     => false,
				'codigo' => $erro->getMessage(),
			); }
	}
	/** ok continua significando aceitação externa; local_confirmado informa a gravação. */
	public static function concluir( array $r, int $http, bool $aceito, bool $temporario, int $retry_after = 0 ): array {
		global $wpdb;
		$t          = self::tabela();
		$agora      = time();
		$espera     = max( 30 * ( 2 ** max( 0, (int) $r['tentativas'] - 1 ) ) + random_int( 0, 15 ), $retry_after );
		$proxima    = $agora + $espera;
		$repetir    = ! $aceito && $temporario && (int) $r['tentativas'] < self::MAX_TENTATIVAS && $proxima < (int) $r['expira'];
		$estado     = $aceito ? 'entregue' : ( $repetir ? 'pendente' : 'falhou' );
		$ok         = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado=CASE WHEN cancelado>0 THEN 'cancelado' ELSE %s END,payload=CASE WHEN cancelado>0 THEN '' ELSE %s END,proxima=%d,atualizado=%d,http=%d,reserva='',motivo=CASE WHEN cancelado>0 AND %d=1 THEN 'entregue_apos_cancelamento' WHEN cancelado>0 THEN 'cancelado' ELSE '' END WHERE record_id=%s AND estado IN ('enviando','cancelando') AND reserva=%s AND proxima>%d", $t, $estado, $repetir ? $r['payload'] : '', $proxima, $agora, $http, $aceito ? 1 : 0, $r['record_id'], $r['reserva'], $agora ) );
		$lido       = self::ler( $r['record_id'] );
		$confirmado = 1 === $ok && $lido && '' === $lido['reserva'] && $http === (int) $lido['http'];
		if ( $confirmado && $repetir && 0 === (int) $lido['cancelado'] ) {
			self::planejar(); }
		return array(
			'ok'                     => $aceito,
			'http'                   => $http,
			'entrega'                => $aceito ? 'aceita' : ( $temporario ? 'incerta' : 'recusada' ),
			'local_confirmado'       => (bool) $confirmado,
			'persisted'              => (bool) $confirmado,
			'codigo'                 => $confirmado ? 'conclusao_gravada' : ( false === $ok ? 'persistencia_falhou' : 'reserva_perdida' ),
			'estado'                 => $lido['estado'] ?? 'desconhecido',
			'reconciliacao_pendente' => ! $confirmado,
			'proxima_tentativa'      => $confirmado && 'pendente' === $lido['estado'] ? $proxima : null,
		);
	}
	/** Marcador sem payload impede que cron/transiente antigo recrie o trabalho. */
	public static function cancelar( string $id, int $lead_id = 0, bool $eliminar = false ): array {
		if ( '' === $id || strlen( $id ) > 128 || ! self::instalar() ) {
			return array(
				'persisted' => false,
				'codigo'    => 'fila_indisponivel',
			); }
		global $wpdb;
		$t     = self::tabela();
		$agora = time();
		if ( false === $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO %i (record_id,payload,estado,proxima,expira,atualizado,cancelado,lead_id,eliminar_lead,limpeza_pendente,schema_versao) VALUES (%s,'','cancelado',%d,%d,%d,%d,%d,%d,1,2)", $t, $id, $agora, $agora + DAY_IN_SECONDS, $agora, $agora, $lead_id, $eliminar ? 1 : 0 ) ) ) {
			return array(
				'persisted' => false,
				'codigo'    => 'marcador_recusado',
			); }
		$ok        = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado=CASE WHEN estado IN ('enviando','cancelando') THEN 'cancelando' ELSE 'cancelado' END,payload='',cancelado=%d,atualizado=%d,lead_id=CASE WHEN %d>0 THEN %d ELSE lead_id END,eliminar_lead=CASE WHEN %d=1 THEN 1 ELSE eliminar_lead END,limpeza_pendente=1 WHERE record_id=%s", $t, $agora, $agora, $lead_id, $lead_id, $eliminar ? 1 : 0, $id ) );
		$r         = self::ler( $id );
		$persisted = false !== $ok && $r && (int) $r['cancelado'] > 0 && '' === $r['payload'];
		if ( $persisted ) {
			self::planejar(); }
		return array(
			'persisted'        => (bool) $persisted,
			'codigo'           => $persisted ? 'cancelamento_confirmado' : 'cancelamento_falhou',
			'http_iniciado'    => $r && 'cancelando' === $r['estado'],
			'entrega_anterior' => $r && (int) $r['http'] >= 200 && (int) $r['http'] < 300,
		);
	}
	/** Callback grava somente a decisão na mesma conexão/transação, sem rede. */
	public static function revogar_decisao( string $ref, callable $persistir ): array {
		if ( '' === $ref || ! self::instalar() ) {
			return array(
				'ok'        => false,
				'persisted' => false,
				'codigo'    => 'fila_indisponivel',
			); }
		global $wpdb;
		$t     = self::tabela();
		$agora = time();
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			return array(
				'ok'        => false,
				'persisted' => false,
				'codigo'    => 'banco_indisponivel',
			); }
		try {
			if ( true !== $persistir() ) {
				throw new RuntimeException( 'decisao_nao_gravada' ); }
			$iniciados = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE decisao_ref=%s AND estado IN ('enviando','cancelando')", $t, $ref ) );
			$n         = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado=CASE WHEN estado IN ('enviando','cancelando') THEN 'cancelando' ELSE 'cancelado' END,payload='',cancelado=%d,atualizado=%d,limpeza_pendente=1,motivo='consentimento_revogado' WHERE decisao_ref=%s", $t, $agora, $agora, $ref ) );
			if ( false === $n || false === $wpdb->query( 'COMMIT' ) ) {
				throw new RuntimeException( 'revogacao_nao_confirmada' ); }
			self::planejar();
			return array(
				'ok'            => true,
				'persisted'     => true,
				'codigo'        => 'revogacao_confirmada',
				'cancelados'    => $n,
				'http_iniciado' => $iniciados,
			);
		} catch ( Throwable $erro ) {
			$wpdb->query( 'ROLLBACK' );
			return array(
				'ok'        => false,
				'persisted' => false,
				'codigo'    => $erro->getMessage(),
			); }
	}
	/** Limpeza retomável independente dos metadados removidos do post. */
	public static function limpar_cancelado( string $id ): array {
		$r = self::ler( $id );
		if ( ! $r || empty( $r['cancelado'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'cancelamento_ausente',
			); }
		$transiente = F3Base_Modulo_Meta_Capi::TRANSIENTE . $id;
		delete_transient( $transiente );
		wp_clear_scheduled_hook( F3Base_Modulo_Meta_Capi::HOOK, array( $id ) );
		$transiente_ok = false === get_transient( $transiente );
		$cron_ok       = false === wp_next_scheduled( F3Base_Modulo_Meta_Capi::HOOK, array( $id ) );
		$lead_ok       = true;
		if ( ! empty( $r['eliminar_lead'] ) && (int) $r['lead_id'] > 0 ) {
			if ( get_post( (int) $r['lead_id'] ) ) {
				wp_delete_post( (int) $r['lead_id'], true ); }
			$lead_ok = ! get_post( (int) $r['lead_id'] );
		}
		$ok = $transiente_ok && $cron_ok && $lead_ok;
		global $wpdb;
		$gravado = false !== $wpdb->query( $wpdb->prepare( 'UPDATE %i SET limpeza_pendente=%d WHERE record_id=%s AND cancelado>0', self::tabela(), $ok ? 0 : 1, $id ) );
		return array(
			'ok'             => $ok && $gravado,
			'parcial'        => ! $ok || ! $gravado,
			'armazenamentos' => array(
				'fila'       => '' === $r['payload'],
				'lead'       => $lead_ok,
				'transiente' => $transiente_ok,
				'cron'       => $cron_ok,
			),
			'http_iniciado'  => 'cancelando' === $r['estado'],
		);
	}
	/** Resolução administrativa explícita do destino legado; nunca renova TTL. */
	public static function resolver_destino( string $id, string $pixel ): array {
		if ( ! preg_match( '/^[0-9]{1,64}$/', $pixel ) || ! hash_equals( F3Base_Modulo_Meta_Capi::pixel_id(), $pixel ) || ! self::instalar() ) {
			return array(
				'ok'     => false,
				'codigo' => 'destino_invalido',
			); }
		global $wpdb;
		$ok = $wpdb->query( $wpdb->prepare( "UPDATE %i SET pixel_id=%s,estado='pendente',motivo='',proxima=%d WHERE record_id=%s AND estado='suspenso' AND pixel_id='' AND expira>%d AND cancelado=0", self::tabela(), $pixel, time(), $id, time() ) );
		if ( 1 === $ok ) {
			self::planejar(); }
		return array(
			'ok'        => 1 === $ok,
			'persisted' => 1 === $ok,
			'codigo'    => 1 === $ok ? 'destino_resolvido' : 'registro_nao_elegivel',
		);
	}
	/** Operação administrativa explícita; não recria payload e não produz outro HTTP. */
	public static function reconciliar( string $id, string $desfecho ): array {
		if ( ! in_array( $desfecho, array( 'aceita', 'encerrada' ), true ) || ! self::instalar() ) {
			return array(
				'ok'     => false,
				'codigo' => 'reconciliacao_invalida',
			); }
		global $wpdb;
		$ok = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado=%s,payload='',reserva='',atualizado=%d,motivo=%s WHERE record_id=%s AND estado='incerto' AND cancelado=0", self::tabela(), 'aceita' === $desfecho ? 'entregue' : 'falhou', time(), 'reconciliado_por_operador', $id ) );
		return array(
			'ok'               => 1 === $ok,
			'persisted'        => 1 === $ok,
			'codigo'           => 1 === $ok ? 'reconciliado' : 'registro_nao_elegivel',
			'origem_evidencia' => 'declaracao_administrativa',
			'envio_realizado'  => false,
		);
	}

	/** Um HTTP iniciado sem conclusão não é reenviado automaticamente após perda da reserva. */
	public static function recuperar(): array {
		if ( ! self::instalar() ) {
			return array(
				'ok'     => false,
				'codigo' => 'schema_indisponivel',
			); }
		global $wpdb;
		$t         = self::tabela();
		$agora     = time();
		$incertos  = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado=CASE WHEN cancelado>0 THEN 'cancelado' ELSE 'incerto' END,payload='',reserva='',motivo='conclusao_local_ausente',atualizado=%d WHERE estado IN ('enviando','cancelando') AND proxima<=%d", $t, $agora, $agora ) );
		$expirados = $wpdb->query( $wpdb->prepare( "UPDATE %i SET estado='expirado',payload='',reserva='',motivo='prazo_ou_tentativas',atualizado=%d WHERE payload<>'' AND estado NOT IN ('enviando','cancelando') AND (expira<=%d OR tentativas>=%d)", $t, $agora, $agora, self::MAX_TENTATIVAS ) );
		// Restaurar o mesmo Pixel/token permite retomar; nunca adotar outro destino.
		if ( '' !== F3Base_Modulo_Meta_Capi::token() ) {
			$wpdb->query( $wpdb->prepare( "UPDATE %i SET estado='pendente',proxima=%d,motivo='' WHERE estado='suspenso' AND motivo IN ('destino_incompativel','token_ausente') AND pixel_id=%s AND pixel_id<>'' AND cancelado=0 AND expira>%d", $t, $agora, F3Base_Modulo_Meta_Capi::pixel_id(), $agora ) );
		}
		$limpezas_pendentes = 0;
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SELECT record_id FROM %i WHERE limpeza_pendente=1 LIMIT 20', $t ) ) as $id ) {
			if ( empty( self::limpar_cancelado( $id )['ok'] ) ) {
				++$limpezas_pendentes; }
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE payload='' AND limpeza_pendente=0 AND estado NOT IN ('enviando','cancelando') AND atualizado<%d AND expira<%d", $t, $agora - self::HISTORICO_DIAS * DAY_IN_SECONDS, $agora ) );
		$r              = self::processar_lote();
		$r['expirados'] = false === $expirados ? null : $expirados;
		if ( false === $expirados || false === $incertos || $limpezas_pendentes ) {
			$r['ok']     = false;
			$r['codigo'] = 'limpeza_ou_confirmacao_pendente'; }
		$r['limpezas_pendentes'] = $limpezas_pendentes;
		return $r;
	}
	public static function processar_lote( int $limite = 20, int $segundos = 15 ): array {
		if ( ! self::instalar() ) {
			return array(
				'ok'     => false,
				'codigo' => 'schema_indisponivel',
			); }
		global $wpdb;
		$inicio      = microtime( true );
		$processados = 0;
		$falhas      = 0;
		$ids         = (array) $wpdb->get_col( $wpdb->prepare( "SELECT record_id FROM %i WHERE estado IN ('pendente','reservado') AND cancelado=0 AND proxima<=%d AND expira>%d ORDER BY proxima,record_id LIMIT %d", self::tabela(), time(), time(), min( 20, max( 1, $limite ) ) ) );
		foreach ( $ids as $id ) {
			if ( microtime( true ) - $inicio >= min( 30, max( 1, $segundos ) ) ) {
				break; }
			$r = F3Base_Modulo_Meta_Capi::enviar( $id, max( 1, (int) floor( min( 30, max( 1, $segundos ) ) - ( microtime( true ) - $inicio ) ) ) );
			++$processados;
			if ( ! empty( $r['reconciliacao_pendente'] ) ) {
				++$falhas; }
		}
		$agendado = self::planejar();
		return array(
			'ok'                 => 0 === $falhas && $agendado,
			'codigo'             => $agendado ? ( $falhas ? 'confirmacao_pendente' : 'lote_processado' ) : 'agendamento_recusado',
			'processados'        => $processados,
			'falhas_confirmacao' => $falhas,
			'reagendado'         => $agendado,
			'agenda'             => self::agenda(),
		);
	}
	public static function agenda(): array {
		if ( ! self::pronta() ) {
			return array( 'instalada' => false ); }
		global $wpdb;
		$t = self::tabela();
		if ( ! in_array( 'agendamento_falhou', (array) $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $t ) ), true ) ) {
			return array(
				'instalada'         => true,
				'migracao_pendente' => true,
			); }
		return array(
			'instalada'          => true,
			'proxima_execucao'   => ( wp_next_scheduled( self::EVENTO ) ? wp_next_scheduled( self::EVENTO ) : null ),
			'saldo'              => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE payload<>'' OR limpeza_pendente=1", $t ) ),
			'ultima_atividade'   => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(atualizado) FROM %i', $t ) ),
			'primeira_pendencia' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT MIN(proxima) FROM %i WHERE estado='pendente'", $t ) ),
			'falhas_agendamento' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE agendamento_falhou=1', $t ) ),
		);
	}
	public static function resumo(): array {
		if ( ! self::pronta() ) {
			return array(); }
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT estado,COUNT(*) AS eventos,MAX(atualizado) AS ultima_atividade FROM %i GROUP BY estado', self::tabela() ), ARRAY_A );
	}
	/** Contratos administrativos: consulta sem efeito e mutações com revisão obrigatória. */
	public static function registrar_habilidades(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		$identificacao = array(
			'record_id'        => array(
				'type'      => 'string',
				'minLength' => 1,
				'maxLength' => 128,
			),
			'revisao_esperada' => array(
				'type'    => 'string',
				'pattern' => '^[a-f0-9]{64}$',
			),
		);
		$base          = array(
			'category'            => F3BASE_PREFIXO,
			'permission_callback' => static fn(): bool => current_user_can( 'manage_options' ),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'ok'               => array( 'type' => 'boolean' ),
					'persisted'        => array( 'type' => 'boolean' ),
					'codigo'           => array( 'type' => 'string' ),
					'origem_evidencia' => array( 'type' => 'string' ),
					'envio_realizado'  => array( 'type' => 'boolean' ),
				),
			),
			'meta'                => array(
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
				'annotations'  => array(
					'readonly'    => false,
					'destructive' => false,
					'idempotent'  => true,
				),
			),
		);
		wp_register_ability(
			'f3base/capi-resolver-destino',
			array_merge(
				$base,
				array(
					'label'            => 'Resolver destino CAPI legado',
					'description'      => 'Atribui explicitamente o Pixel atual a um registro legado ainda válido. Não atribui consentimento ausente e não renova a expiração. Exige a revisão retornada pela consulta de pendências.',
					'input_schema'     => array(
						'type'                 => 'object',
						'additionalProperties' => false,
						'required'             => array( 'record_id', 'revisao_esperada', 'pixel_id' ),
						'properties'           => array_merge(
							$identificacao,
							array(
								'pixel_id' => array(
									'type'    => 'string',
									'pattern' => '^[0-9]{1,64}$',
								),
							)
						),
					),
					'execute_callback' => static function ( $e ) {
							return self::mutacao_administrativa( $e, 'destino' );
					},
				)
			)
		);
		wp_register_ability(
			'f3base/capi-reconciliar',
			array_merge(
				$base,
				array(
					'label'            => 'Reconciliar conclusão CAPI',
					'description'      => 'Encerra um resultado externo incerto por declaração administrativa: aceita ou encerrada. Não reenvia payload e não substitui evidência do fornecedor.',
					'input_schema'     => array(
						'type'                 => 'object',
						'additionalProperties' => false,
						'required'             => array( 'record_id', 'revisao_esperada', 'desfecho' ),
						'properties'           => array_merge(
							$identificacao,
							array(
								'desfecho' => array(
									'type' => 'string',
									'enum' => array( 'aceita', 'encerrada' ),
								),
							)
						),
					),
					'execute_callback' => static function ( $e ) {
							return self::mutacao_administrativa( $e, 'reconciliar' );
					},
				)
			)
		);
		wp_register_ability(
			'f3base/capi-pendencias-ler',
			array(
				'category'            => F3BASE_PREFIXO,
				'label'               => 'Consultar pendências CAPI',
				'description'         => 'Lista estados e revisões técnicas sem payload, token, reserva ou dados do visitante. Esta consulta não executa migração, coleta ou envio.',
				'input_schema'        => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'properties'           => array(
						'limite' => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
							'default' => 20,
						),
						'apos'   => array(
							'type'      => 'string',
							'maxLength' => 128,
							'default'   => '',
						),
					),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'migracao_pendente' => array( 'type' => 'boolean' ),
						'linhas'            => array(
							'type'  => 'array',
							'items' => array( 'type' => 'object' ),
						),
						'proximo_cursor'    => array( 'type' => array( 'string', 'null' ) ),
					),
				),
				'permission_callback' => static fn(): bool => current_user_can( 'manage_options' ),
				'execute_callback'    => static function ( $e = null ) {
							return self::consultar_pendencias( is_array( $e ) ? $e : array() );
				},
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}
	private static function revisao( array $r ): string {
		return hash( 'sha256', (string) wp_json_encode( $r ) ); }
	public static function consultar_pendencias( array $entrada = array() ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'f3base_sem_permissao', 'Sem permissão para consultar a fila.' ); }
		global $wpdb;
		$t = self::tabela();
		if ( ! self::pronta() || ! in_array( 'schema_versao', (array) $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $t ) ), true ) ) {
			return array(
				'migracao_pendente' => true,
				'linhas'            => array(),
				'proximo_cursor'    => null,
			); }
		$limite = min( 100, max( 1, (int) ( $entrada['limite'] ?? 20 ) ) );
		$linhas = array();
		$rows   = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE record_id>%s AND estado IN ('suspenso','incerto','pendente','reservado','enviando','cancelando') ORDER BY record_id LIMIT %d", $t, (string) ( $entrada['apos'] ?? '' ), $limite + 1 ), ARRAY_A );
		foreach ( array_slice( $rows, 0, $limite ) as $r ) {
			$linhas[] = array(
				'record_id'  => $r['record_id'],
				'revisao'    => self::revisao( $r ),
				'estado'     => $r['estado'],
				'motivo'     => $r['motivo'],
				'pixel_id'   => $r['pixel_id'],
				'expira'     => (int) $r['expira'],
				'tentativas' => (int) $r['tentativas'],
				'proxima'    => (int) $r['proxima'],
				'http'       => (int) $r['http'],
				'atualizado' => (int) $r['atualizado'],
			);
		}
		return array(
			'migracao_pendente' => false,
			'linhas'            => $linhas,
			'proximo_cursor'    => count( $rows ) > $limite ? $linhas[ count( $linhas ) - 1 ]['record_id'] : null,
		);
	}
	public static function mutacao_administrativa( array $entrada, string $acao ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'f3base_sem_permissao', 'Sem permissão para alterar a fila.' ); }
		$r = self::ler( (string) ( $entrada['record_id'] ?? '' ) );
		if ( ! $r || ! hash_equals( self::revisao( $r ), (string) ( $entrada['revisao_esperada'] ?? '' ) ) ) {
			return array(
				'ok'        => false,
				'persisted' => false,
				'codigo'    => 'revisao_divergente',
			); }
		return 'destino' === $acao ? self::resolver_destino( $r['record_id'], (string) ( $entrada['pixel_id'] ?? '' ) ) : self::reconciliar( $r['record_id'], (string) ( $entrada['desfecho'] ?? '' ) );
	}

	public static function remover(): void {
		wp_unschedule_hook( self::EVENTO );
		wp_unschedule_hook( F3Base_Modulo_Meta_Capi::HOOK );
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', self::tabela() ) );
		self::$schema_confirmado = false;
	}
}
