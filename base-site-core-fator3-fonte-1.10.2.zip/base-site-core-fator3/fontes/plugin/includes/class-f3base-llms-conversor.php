<?php
/** Conversão editorial de blocos armazenados. Nunca renderiza blocos, shortcodes ou consultas. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Llms_Conversor {
	public const MAX_BYTES        = 4194304;
	public const MAX_BLOCOS       = 10000;
	public const MAX_PROFUNDIDADE = 12;
	private int $bytes            = 0;
	private int $blocos           = 0;
	private array $avisos         = array();
	private array $erros          = array();
	private array $referencias    = array();

	public static function converter( string $conteudo, string $base, int $nivel = 2 ): array {
		$c    = new self();
		$html = $c->conteudo( $conteudo, array(), 0 );
		try {
			$texto = F3Base_Llms::html_markdown( $html, $base, $nivel );
		} catch ( RuntimeException $erro ) {
			$texto      = '';
			$c->erros[] = $erro->getMessage(); }
		if ( ! class_exists( 'DOMDocument' ) ) {
			$c->avisos[] = 'dom_indisponivel: formato convertido como texto simples'; }
		if ( strlen( $texto ) > self::MAX_BYTES ) {
			$c->erros[] = 'volume_markdown_excedido'; }
		return array(
			'texto'       => $c->erros ? '' : $texto,
			'completo'    => ! $c->erros,
			'avisos'      => array_values( array_unique( $c->avisos ) ),
			'erros'       => array_values( array_unique( $c->erros ) ),
			'referencias' => array_values( array_unique( $c->referencias ) ),
			'bytes_fonte' => $c->bytes,
			'blocos'      => $c->blocos,
		);
	}
	private function conteudo( string $texto, array $pilha, int $nivel ): string {
		$this->bytes += strlen( $texto );
		if ( $nivel > self::MAX_PROFUNDIDADE || $this->bytes > self::MAX_BYTES ) {
			$this->erros[] = 'limite_de_conversao';
			return ''; }
		if ( ! function_exists( 'parse_blocks' ) ) {
			return $texto; }
		$html = '';
		foreach ( parse_blocks( $texto ) as $bloco ) {
			$html .= $this->bloco( $bloco, $pilha, $nivel ); }
		return $html;
	}
	private function bloco( array $bloco, array $pilha, int $nivel ): string {
		if ( ++$this->blocos > self::MAX_BLOCOS || $nivel > self::MAX_PROFUNDIDADE ) {
			$this->erros[] = 'limite_de_conversao';
			return ''; }
		$nome = (string) ( $bloco['blockName'] ?? '' );
		if ( 'core/block' === $nome ) {
			$id = (int) ( $bloco['attrs']['ref'] ?? 0 );
			if ( $id < 1 || in_array( $id, $pilha, true ) ) {
				$this->erros[] = 'referencia_circular_ou_invalida';
				return ''; }
			// wp_block não tem permalink indexável; o noindex implícito do tipo não proíbe a incorporação.
			// Status, senha e uma exclusão noindex explícita continuam sendo restrições de conteúdo.
			$post = get_post( $id );
			if ( ! $post instanceof WP_Post || 'wp_block' !== $post->post_type || 'publish' !== $post->post_status || '' !== $post->post_password || ! F3Base_Llms::site_publico() || '1' === (string) get_post_meta( $id, F3Base_Chaves_Seo::NOINDEX, true ) ) {
				$this->avisos[] = 'referencia_protegida_omitida:' . $id;
				return ''; }
			$this->referencias[] = $id;
			return $this->conteudo( $post->post_content, array_merge( $pilha, array( $id ) ), $nivel + 1 );
		}
		// Um formulário conhecido é interface, não corpo editorial. Não expandir seu shortcode.
		// A nota permanece visível no Markdown; outros shortcodes continuam incompletos.
		if ( 'core/shortcode' === $nome && shortcode_exists( 'contact-form-7' ) ) {
			$texto = trim( (string) ( $bloco['innerHTML'] ?? '' ) );
			if ( preg_match( '/^' . get_shortcode_regex( array( 'contact-form-7' ) ) . '$/sD', $texto, $partes ) && '' === $partes[1] && '' === $partes[6] && empty( $partes[5] ) ) {
				$atributos = shortcode_parse_atts( $partes[3] );
				if ( is_array( $atributos ) && preg_match( '/^[a-zA-Z0-9_-]{1,64}$/D', (string) ( $atributos['id'] ?? '' ) ) ) {
					$this->avisos[] = 'formulario_interativo_referenciado:contact-form-7';
					return '<p><em>Formulário interativo: consulte a página original para preencher e enviar.</em></p>'; }
			}
		}
		// O botão possui HTML editorial salvo mesmo quando o WordPress registra um render_callback.
		// Bindings podem substituir texto/URL em runtime e não são resolvidos por esta conversão.
		if ( 'core/button' === $nome && ! empty( $bloco['attrs']['metadata']['bindings'] ) ) {
			$this->erros[] = 'bloco_vinculado_nao_convertido:' . $nome;
			return ''; }
		// Estes nomes têm representação editorial persistida. Nenhum callback de renderização é executado.
		$estaticos = array( '', 'core/paragraph', 'core/heading', 'core/list', 'core/list-item', 'core/table', 'core/quote', 'core/pullquote', 'core/code', 'core/preformatted', 'core/verse', 'core/image', 'core/gallery', 'core/group', 'core/columns', 'core/column', 'core/cover', 'core/media-text', 'core/separator', 'core/spacer', 'core/html', 'core/freeform', 'core/details', 'core/more', 'core/nextpage', 'core/buttons', 'core/button' );
		if ( ! in_array( $nome, $estaticos, true ) ) {
			$registrado = class_exists( 'WP_Block_Type_Registry' ) ? WP_Block_Type_Registry::get_instance()->get_registered( $nome ) : null;
			if ( 'core/shortcode' === $nome || ( $registrado && $registrado->is_dynamic() ) ) {
				$this->erros[] = 'bloco_dinamico_nao_convertido:' . $nome;
				return ''; }
			$this->avisos[] = 'bloco_desconhecido_html_armazenado:' . $nome;
			if ( '' === trim( (string) ( $bloco['innerHTML'] ?? '' ) ) && empty( $bloco['innerBlocks'] ) ) {
				$this->erros[] = 'bloco_sem_representacao:' . $nome;
				return ''; }
		}
		if ( empty( $bloco['innerBlocks'] ) ) {
			return (string) ( $bloco['innerHTML'] ?? '' ); }
		$html = '';
		$i    = 0;
		foreach ( $bloco['innerContent'] ?? array() as $parte ) {
			$html .= null === $parte ? $this->bloco( (array) ( $bloco['innerBlocks'][ $i++ ] ?? array() ), $pilha, $nivel + 1 ) : (string) $parte;
		}
		return $html;
	}
}
