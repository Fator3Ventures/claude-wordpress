<?php
/**
 * Validação e normalização dos valores de configuração. Parte interna da fachada F3Base_Options.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Implementação interna; somente F3Base_Options deve incorporar esta trait. */
trait F3Base_Options_Validacao {
	/* ------------------------------------------------------------------ *
	 * Sanitizadores declarados
	 * ------------------------------------------------------------------ */

	/**
	 * PRESERVA as chaves que este pacote não conhece.
	 *
	 * A REGRA DA 1.1.0, e ela tem um lado só: **normaliza o conhecido, preserva
	 * o desconhecido.** Até a 1.0.19 todo sanitizador de grupo RECONSTRUÍA o
	 * array a partir das chaves declaradas, e o efeito estava medido: o agente
	 * de manutenção acrescentava `telefone` a `f3base_contato` pelo canal MCP, a
	 * escrita entrava no banco, e a primeira LEITURA a devolvia sem a chave —
	 * apagada em silêncio, sem erro, sem log, sem ninguém para acusar. Sob a
	 * premissa de que toda modificação futura é do agente, um sanitizador que
	 * descarta o que não conhece é um sanitizador que desfaz trabalho alheio.
	 *
	 * O que NÃO muda: a chave conhecida continua passando pela normalização
	 * declarada. Preservar o desconhecido não é aceitar qualquer coisa — o valor
	 * desconhecido é sanitizado como dado (texto, número, booleano ou lista
	 * deles), e a chave é reduzida ao alfabeto de um nome de chave.
	 *
	 * @param array<string,mixed> $normalizado Valor já normalizado pelo sanitizador.
	 * @param mixed               $bruto       Valor bruto, como chegou.
	 * @return array<string,mixed>
	 */
	public static function preservar_desconhecidas( array $normalizado, $bruto ): array {
		if ( ! is_array( $bruto ) ) {
			return $normalizado;
		}

		foreach ( $bruto as $chave => $valor ) {
			$chave = self::chave_preservavel( (string) $chave );

			if ( '' === $chave || array_key_exists( $chave, $normalizado ) ) {
				continue;
			}

			$normalizado[ $chave ] = self::sanitiza_desconhecido( $valor );
		}

		return $normalizado;
	}

	/**
	 * Reduz uma chave desconhecida ao alfabeto de um nome de chave.
	 *
	 * Chave vazia depois da redução não é preservada: nome que não sobrou não é
	 * nome, e gravar sob `''` é perder o valor de outro jeito.
	 *
	 * @param string $chave Chave bruta.
	 * @return string Chave reduzida, ou vazia quando não sobrou nome.
	 */
	private static function chave_preservavel( string $chave ): string {
		$limpo = preg_replace( '/[^A-Za-z0-9_.:\-]/', '', $chave );

		return is_string( $limpo ) ? substr( $limpo, 0, 120 ) : '';
	}

	/**
	 * Sanitiza um valor DESCONHECIDO como dado.
	 *
	 * Escalares mantêm o tipo; texto com quebra de linha passa pelo sanitizador
	 * de área de texto, e o de uma linha pelo de campo. Lista é percorrida até a
	 * profundidade declarada — estrutura mais funda que isso deixa de ser
	 * configuração e vira arquivo, e arquivo tem outro lugar.
	 *
	 * @param mixed $valor      Valor bruto.
	 * @param int   $profundeza Profundidade restante.
	 * @return mixed
	 */
	private static function sanitiza_desconhecido( $valor, int $profundeza = 6 ) {
		if ( is_bool( $valor ) || is_int( $valor ) || is_float( $valor ) ) {
			return $valor;
		}

		if ( is_array( $valor ) ) {
			if ( $profundeza <= 0 ) {
				return array();
			}

			$saida = array();

			foreach ( $valor as $chave => $item ) {
				$limpa = is_int( $chave ) ? $chave : self::chave_preservavel( (string) $chave );

				if ( '' === $limpa ) {
					continue;
				}

				$saida[ $limpa ] = self::sanitiza_desconhecido( $item, $profundeza - 1 );
			}

			return $saida;
		}

		if ( null === $valor || is_object( $valor ) ) {
			return '';
		}

		$texto = (string) $valor;

		return str_contains( $texto, "\n" ) ? sanitize_textarea_field( $texto ) : sanitize_text_field( $texto );
	}

	/**
	 * Sanitiza `f3base_contato`.
	 *
	 * @param mixed                $valor  Valor bruto.
	 * @param array<string,string> $padrao Padrão declarado.
	 * @return array<string,string>
	 */
	public static function sanitiza_contato( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$e164 = isset( $valor['whatsapp_e164'] ) ? preg_replace( '/[^0-9]/', '', (string) $valor['whatsapp_e164'] ) : '';
		$e164 = is_string( $e164 ) ? substr( $e164, 0, self::TAMANHOS['whatsapp'] ) : '';

		if ( '' !== $e164 && strlen( $e164 ) < self::TAMANHOS['whatsapp_minimo'] ) {
			$e164 = '';
		}

		return self::preservar_desconhecidas(
			array(
				'whatsapp_e164'   => $e164,
				'flutuante'       => ! empty( $valor['flutuante'] ),
				'email_leads'     => isset( $valor['email_leads'] ) ? sanitize_email( (string) $valor['email_leads'] ) : $padrao['email_leads'],
				'mensagem_padrao' => isset( $valor['mensagem_padrao'] ) ? sanitize_textarea_field( (string) $valor['mensagem_padrao'] ) : $padrao['mensagem_padrao'],
			),
			$valor
		);
	}

	/**
	 * Sanitiza `f3base_consentimento`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_consentimento( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$politica = isset( $valor['padrao'] ) ? sanitize_key( (string) $valor['padrao'] ) : $padrao['padrao'];
		if ( ! in_array( $politica, self::POLITICAS_CONSENTIMENTO, true ) ) {
			$politica = 'pre-aprovado';
		}

		$ttl = isset( $valor['ttl_dias'] ) ? (int) $valor['ttl_dias'] : (int) $padrao['ttl_dias'];
		$ttl = self::limitar( 'ttl_dias', $ttl );

		return self::preservar_desconhecidas(
			array(
				'modo'                     => in_array( $valor['modo'] ?? '', array( 'legado', 'granular' ), true ) ? $valor['modo'] : 'legado',
				'politica_versao'          => is_string( $valor['politica_versao'] ?? null ) && preg_match( '/^[A-Za-z0-9._-]{1,64}$/D', $valor['politica_versao'] ) ? $valor['politica_versao'] : '1',
				'gtm_separacao_verificada' => ! empty( $valor['gtm_separacao_verificada'] ),
				'padrao'                   => $politica,
				'controle_rodape'          => isset( $valor['controle_rodape'] ) ? (bool) $valor['controle_rodape'] : (bool) $padrao['controle_rodape'],
				'aviso_primeira_visita'    => isset( $valor['aviso_primeira_visita'] ) ? (bool) $valor['aviso_primeira_visita'] : (bool) $padrao['aviso_primeira_visita'],
				'ttl_dias'                 => $ttl,
			),
			$valor
		);
	}

	public static function recusa_consentimento( $valor, array $declaracao, string $nome ): string {
		unset( $declaracao, $nome );
		if ( ! is_array( $valor ) ) {
			return 'Envie um grupo de configuração de consentimento.'; }
		if ( isset( $valor['modo'] ) && ! in_array( $valor['modo'], array( 'legado', 'granular' ), true ) ) {
			return 'Modo de consentimento desconhecido.'; }
		if ( 'granular' === ( $valor['modo'] ?? '' ) && isset( $valor['controle_rodape'] ) && ! $valor['controle_rodape'] ) {
			return 'O modo granular exige controle de consentimento no rodapé para permitir revisar e revogar escolhas.'; }
		if ( isset( $valor['politica_versao'] ) && ( ! is_string( $valor['politica_versao'] ) || ! preg_match( '/^[A-Za-z0-9._-]{1,64}$/D', $valor['politica_versao'] ) ) ) {
			return 'Versão de política inválida.'; }
		return '';
	}

	/**
	 * Sanitiza `f3base_atribuicao`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_atribuicao( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$modelo = isset( $valor['modelo'] ) ? sanitize_key( (string) $valor['modelo'] ) : (string) $padrao['modelo'];
		if ( ! in_array( $modelo, F3Base_Vocabulario::modelos_de_atribuicao(), true ) ) {
			$modelo = F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE;
		}

		$ttl = isset( $valor['ttl_dias'] ) ? (int) $valor['ttl_dias'] : (int) $padrao['ttl_dias'];

		return self::preservar_desconhecidas(
			array(
				'modelo'   => $modelo,
				'ttl_dias' => self::limitar( 'ttl_dias', $ttl ),
			),
			$valor
		);
	}

	/**
	 * RECUSA o prazo de retenção fora da faixa, em vez de reescrevê-lo.
	 *
	 * O DEFEITO MEDIDO, e ele apagava lead: a tela oferecia `min="0"`, alguém
	 * digitava `0` para desligar a limpeza automática, e o sanitizador ELEVAVA o
	 * valor a 1 em silêncio. O prazo mais curto possível é o oposto exato do que
	 * o zero pedia, e a rotina do dia seguinte apagava todo registro de contato
	 * com mais de um mês. Recusar devolve a decisão a quem a tomou; normalizar
	 * decide por ele e não conta.
	 *
	 * @param mixed               $valor      Valor bruto.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @return string Motivo da recusa, ou vazio.
	 */
	public static function recusa_retencao_meses( $valor, array $declaracao ): string {
		unset( $declaracao );

		if ( ! is_scalar( $valor ) || '' === (string) $valor ) {
			return __( 'O prazo de guarda dos contatos precisa ser um número de meses, e o valor enviado não é um. Nada foi gravado e o prazo anterior continua valendo.', 'f3base' );
		}

		$meses = (int) $valor;

		if ( $meses < self::FAIXAS['retencao_meses'][0] ) {
			return sprintf(
				/* translators: %d: número de meses enviado. */
				__( 'O prazo de guarda dos contatos foi enviado como %d e a gravação foi RECUSADA: o prazo anterior continua valendo. O mínimo é 1 mês. Zero não desliga a limpeza automática — ele seria o prazo mais curto possível, e a rotina do dia seguinte apagaria todo contato com mais de um mês. Este campo não tem valor para "nunca apagar": a retenção usa o prazo configurado, independentemente da existência de uma página de política de privacidade.', 'f3base' ),
				$meses
			);
		}

		if ( $meses > self::FAIXAS['retencao_meses'][1] ) {
			return sprintf(
				/* translators: %d: número de meses enviado. */
				__( 'O prazo de guarda dos contatos foi enviado como %d meses e a gravação foi RECUSADA: o prazo anterior continua valendo. O máximo é 600 meses — cinquenta anos —, e um prazo acima disso é a mesma coisa que nunca apagar, escrita de outro jeito.', 'f3base' ),
				$meses
			);
		}

		return '';
	}

	/**
	 * Sanitiza `f3base_retencao_meses`.
	 *
	 * A FAIXA CONTINUA AQUI, e ela não é a mesma coisa que a recusa acima. A
	 * recusa governa a ESCRITA, e devolve a decisão a quem grava. Este
	 * sanitizador governa a LEITURA, e um valor fora da faixa em disco — gravado
	 * por outra release, ou direto no banco — precisa virar um prazo usável em
	 * vez de fazer a rotina de retenção calcular com zero.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return int
	 */
	public static function sanitiza_retencao_meses( $valor, $padrao ): int {
		$meses = is_scalar( $valor ) ? (int) $valor : (int) $padrao;

		return self::limitar( 'retencao_meses', $meses );
	}

	/**
	 * Sanitiza o Partner ID do LinkedIn.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_partner_id( $valor, $padrao ): string {
		unset( $padrao );

		$id = is_scalar( $valor ) ? preg_replace( '/[^0-9]/', '', (string) $valor ) : '';

		return is_string( $id ) ? substr( $id, 0, self::TAMANHOS['partner_id'] ) : '';
	}

	/**
	 * Sanitiza um IDENTIFICADOR DE TAG de terceiro.
	 *
	 * Reduz ao alfabeto que os quatro fornecedores usam nos próprios
	 * identificadores — letra, dígito, hífen e sublinhado — e corta no limite
	 * declarado. NÃO recusa por formato: um `G-` faltando não é motivo para o
	 * pacote apagar o que alguém gravou, e apagar em silêncio é justamente o que
	 * esta release parou de fazer. Quem NOMEIA o formato errado é o módulo de
	 * tracking, no estado que o operador lê.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_id_de_tag( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		$limpo = preg_replace( '/[^A-Za-z0-9_-]/', '', trim( (string) $valor ) );

		return is_string( $limpo ) ? substr( $limpo, 0, self::TAMANHOS['tag_id'] ) : '';
	}

	/**
	 * Sanitiza `f3base_google_ads`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_google_ads( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return self::preservar_desconhecidas(
			array(
				'conversion_id'    => isset( $valor['conversion_id'] ) ? self::sanitiza_id_de_tag( $valor['conversion_id'], '' ) : (string) $padrao['conversion_id'],
				'conversion_label' => isset( $valor['conversion_label'] ) ? self::sanitiza_id_de_tag( $valor['conversion_label'], '' ) : (string) $padrao['conversion_label'],
			),
			$valor
		);
	}

	/**
	 * Sanitiza um SEGREDO OPACO — hoje, o token da Conversions API da Meta.
	 *
	 * Distinto de `sanitiza_segredo()`, que trata do HMAC hexadecimal gerado
	 * por este pacote e pode reduzir ao alfabeto que ele mesmo produz. Este
	 * valor vem de FORA e o alfabeto é do fornecedor.
	 *
	 * Ele não tem forma pública declarada pelo fornecedor, e inventar uma seria
	 * pior que não ter nenhuma: um token legítimo recusado por um formato que
	 * este pacote imaginou é uma medição que some sem ninguém saber por quê. O
	 * que a sanitização faz é o que dá para fazer com segurança — tirar espaço
	 * das pontas e cortar no teto declarado — e nada além disso.
	 *
	 * O valor NÃO é impresso em página nenhuma: ele viaja no corpo da chamada à
	 * Meta e no dump sanitizado do relatório, que já reduz segredo a marcador.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_segredo_opaco( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		return substr( trim( (string) $valor ), 0, self::TAMANHOS['segredo_opaco'] );
	}

	/**
	 * Sanitiza um token de VERIFICAÇÃO DE DOMÍNIO.
	 *
	 * NÃO REDUZ O ALFABETO, e essa é a diferença deliberada em relação a
	 * `sanitiza_id_de_tag()`. Um ID de tag tem forma pública e conhecida; um
	 * token de verificação é opaco, e o fornecedor pode mudar o alfabeto dele
	 * sem avisar ninguém. Filtrar caractere aqui seria apagar em silêncio metade
	 * de um valor válido — e produzir uma verificação que nunca fecha sem uma
	 * linha dizendo por quê. O que sai fora da forma é PRESERVADO e avisado pelo
	 * módulo, e a saída passa por `esc_attr()` no ponto em que vira atributo.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_token_de_verificacao( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		return substr( trim( (string) $valor ), 0, F3Base_Modulo_Verificacao_Dominio::TETO );
	}

	/**
	 * Sanitiza `f3base_robots`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_robots_backup( $valor, array $padrao ): array {
		return array_replace( $padrao, is_array( $valor ) ? $valor : array() );
	}

	public static function sanitiza_robots( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();
		return self::preservar_desconhecidas( array( 'ligado' => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : (bool) $padrao['ligado'] ), $valor );
	}

	/** Sanitiza os controles de seleção e publicação do llms.txt. */
	public static function sanitiza_llms( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return self::preservar_desconhecidas(
			array(
				'ligado'                         => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : (bool) $padrao['ligado'],
				'entrega'                        => 'arquivo_gerado' === ( $valor['entrega'] ?? 'dinamica' ) ? 'arquivo_gerado' : 'dinamica',
				'atualizacao_intervalo_segundos' => max( 60, min( 86400, (int) ( $valor['atualizacao_intervalo_segundos'] ?? 3600 ) ) ),
				'atualizar_por_visita'           => (bool) ( $valor['atualizar_por_visita'] ?? true ),
				'introducao'                     => isset( $valor['introducao'] ) ? sanitize_textarea_field( (string) $valor['introducao'] ) : '',
				'apresentacao'                   => isset( $valor['apresentacao'] ) ? sanitize_textarea_field( (string) $valor['apresentacao'] ) : (string) ( $padrao['apresentacao'] ?? '' ),
				/*
				 * O MODO É VALIDADO CONTRA OS SÍMBOLOS DECLARADOS, e a lista sai
				 * de `F3Base_Llms::modos()`: valor fora do vocabulário volta ao
				 * padrão em vez de virar um modo que ninguém implementou.
				 */
				'modo'                           => self::sanitiza_modo_llms( $valor['modo'] ?? null, (string) ( $padrao['modo'] ?? F3Base_Llms::MODO_MISTO ) ),
				/*
				 * OS TIPOS SÃO VALIDADOS CONTRA A INSTALAÇÃO, nunca contra uma
				 * lista literal: o conjunto válido é o dos tipos públicos que
				 * este site tem agora, e tipo que o agente criar depois passa a
				 * ser aceito sem release nova.
				 */
				'tipos'                          => self::sanitiza_tipos_llms( $valor['tipos'] ?? null, (array) ( $padrao['tipos'] ?? array() ) ),
				'markdown'                       => isset( $valor['markdown'] ) ? (bool) $valor['markdown'] : (bool) ( $padrao['markdown'] ?? true ),
				'full'                           => isset( $valor['full'] ) ? (bool) $valor['full'] : (bool) ( $padrao['full'] ?? false ),
				'indexavel'                      => isset( $valor['indexavel'] ) ? (bool) $valor['indexavel'] : (bool) ( $padrao['indexavel'] ?? true ),
				/*
				 * O ITEM SEM ENDEREÇO NÃO É ITEM, e essa é a regra que faz este
				 * sanitizador ser IDEMPOTENTE.
				 *
				 * O DEFEITO MEDIDO: `politica_privacidade` ausente virava
				 * `array()` na primeira passagem; na segunda, a chave EXISTIA e
				 * era um array, e `sanitiza_item_llms( array() )` a transformava
				 * no objeto de quatro campos vazios. Sanitizar duas vezes dava
				 * resultado diferente de sanitizar uma, e a leitura de volta de
				 * `gravar()` — que compara o normalizado com o relido — acusava
				 * divergência numa gravação que não tinha nada de errado.
				 * `livres` já se comportava assim, porque ele filtra item de URL
				 * vazia; aqui a mesma regra passa a valer.
				 */
				'politica_privacidade'           => self::sanitiza_referencia_llms( $valor['politica_privacidade'] ?? null ),
				'livres'                         => isset( $valor['livres'] ) && is_array( $valor['livres'] )
					? array_values(
						array_filter(
							array_map( array( __CLASS__, 'sanitiza_item_llms' ), $valor['livres'] ),
							static fn ( array $item ): bool => '' !== $item['url']
						)
					)
					: array(),
			),
			$valor
		);
	}

	/**
	 * Uma referência OPCIONAL do llms.txt: item completo, ou nada.
	 *
	 * @param mixed $item Item bruto.
	 * @return array<string,mixed> Item sanitizado, ou array vazio.
	 */
	public static function sanitiza_referencia_llms( $item ): array {
		if ( ! is_array( $item ) || array() === $item ) {
			return array();
		}

		$limpo = self::sanitiza_item_llms( $item );

		return '' === $limpo['url'] ? array() : $limpo;
	}

	/**
	 * Sanitiza um item de listagem do llms.txt.
	 *
	 * O `id` viaja junto porque o dedupe entre a curadoria e a enumeração é POR
	 * ID: URL muda quando o slug muda, e o mesmo conteúdo sairia duas vezes no
	 * arquivo sem que nada acusasse.
	 *
	 * A CHAVE DESCONHECIDA DE DENTRO DO ITEM SOBREVIVE. Reconstruir a entrada a
	 * partir dos quatro campos declarados era o apagamento silencioso da 1.0.19
	 * acontecendo um nível abaixo: a regra da 1.1.0 vale para o item da lista,
	 * não só para o primeiro nível da option.
	 *
	 * @param mixed $item Item bruto.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_item_llms( $item ): array {
		$item = is_array( $item ) ? $item : array();

		return self::preservar_desconhecidas(
			array(
				'id'        => isset( $item['id'] ) ? max( 0, (int) $item['id'] ) : 0,
				'titulo'    => isset( $item['titulo'] ) ? sanitize_text_field( (string) $item['titulo'] ) : '',
				'url'       => isset( $item['url'] ) ? esc_url_raw( (string) $item['url'] ) : '',
				'descricao' => isset( $item['descricao'] ) ? sanitize_text_field( (string) $item['descricao'] ) : '',
			),
			$item
		);
	}

	/**
	 * As OPÇÕES do modo de seleção, com o rótulo que a tela mostra.
	 *
	 * As chaves saem de `F3Base_Llms::modos()` — o vocabulário fechado mora num
	 * lugar só, e uma lista escrita aqui seria a segunda declaração do mesmo
	 * conjunto, divergindo no dia em que um modo entrar ou sair.
	 *
	 * @return array<string,string>
	 */
	public static function opcoes_de_modo_llms(): array {
		$rotulos = array(
			F3Base_Llms::MODO_CURADA     => __( 'apenas a lista escolhida na entrega', 'f3base' ),
			F3Base_Llms::MODO_AUTOMATICA => __( 'apenas o conteúdo publicado dos tipos abaixo', 'f3base' ),
			F3Base_Llms::MODO_MISTO      => __( 'os dois: a lista escolhida primeiro, o publicado em seguida', 'f3base' ),
		);

		$opcoes = array();

		foreach ( F3Base_Llms::modos() as $modo ) {
			$opcoes[ $modo ] = $rotulos[ $modo ] ?? $modo;
		}

		return $opcoes;
	}

	/**
	 * MODO de seleção do llms.txt, contra o vocabulário declarado.
	 *
	 * @param mixed  $valor  Valor bruto.
	 * @param string $padrao Modo padrão.
	 * @return string
	 */
	public static function sanitiza_modo_llms( $valor, string $padrao ): string {
		$modo  = is_scalar( $valor ) ? trim( (string) $valor ) : '';
		$modos = F3Base_Llms::modos();

		if ( in_array( $modo, $modos, true ) ) {
			return $modo;
		}

		return in_array( $padrao, $modos, true ) ? $padrao : F3Base_Llms::MODO_MISTO;
	}

	/**
	 * TIPOS enumerados do llms.txt, contra os tipos públicos desta instalação.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Tipos padrão.
	 * @return array<int,string>
	 */
	public static function sanitiza_tipos_llms( $valor, array $padrao ): array {
		if ( is_string( $valor ) ) {
			/* A TELA ENTREGA UMA LINHA, e a configuração entrega uma lista: as duas formas chegam aqui. */
			$valor = array_map( 'trim', explode( ',', $valor ) );
		}

		$declarados = is_array( $valor ) ? $valor : $padrao;
		$publicos   = array_values( (array) get_post_types( array( 'public' => true ), 'names' ) );

		return F3Base_Llms::tipos_validos( array_map( 'strval', $declarados ), array_map( 'strval', $publicos ) )['tipos'];
	}

	/** Tipos públicos atuais; acompanha registros feitos por temas e plugins. */
	public static function opcoes_de_tipos_llms(): array {
		$opcoes = array();
		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $nome => $tipo ) {
			$opcoes[ (string) $nome ] = (string) $tipo->labels->name . ' (' . $nome . ')';
		}
		natcasesort( $opcoes );
		return $opcoes;
	}

	/**
	 * Sanitiza `f3base_redirects`.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<int,array{de:string,para:string,status:int}>
	 */
	public static function sanitiza_redirects( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $regra ) {
			if ( ! is_array( $regra ) ) {
				continue;
			}

			$de   = isset( $regra['de'] ) ? self::sanitiza_caminho( (string) $regra['de'] ) : '';
			$para = isset( $regra['para'] ) ? self::sanitiza_caminho( (string) $regra['para'] ) : '';

			if ( '' === $de || '' === $para ) {
				continue;
			}

			$status = isset( $regra['status'] ) ? (int) $regra['status'] : 301;
			if ( ! in_array( $status, array( 301, 302, 307, 308, 410 ), true ) ) {
				$status = 301;
			}

			/*
			 * O PAR QUE GIRA NÃO É DESCARTADO AQUI, e a razão é a regra desta
			 * classe: o sanitizador governa a LEITURA, e leitura que descarta
			 * apaga em silêncio o que alguém gravou. O par cuja origem e destino
			 * NORMALIZAM iguais é recusado na ESCRITA, por
			 * `escrita_de_redirects()`, com o par NOMEADO no motivo da gravação;
			 * o que já está no banco continua legível na tela e é o módulo que
			 * se recusa a servi-lo, dizendo qual é.
			 */
			$saida[] = self::preservar_desconhecidas(
				array(
					'de'     => $de,
					'para'   => $para,
					'status' => $status,
				),
				$regra
			);
		}

		return $saida;
	}

	/**
	 * Normaliza um caminho relativo do próprio site.
	 *
	 * @param string $caminho Caminho bruto.
	 * @return string Caminho começando por barra, ou vazio quando inválido.
	 */
	public static function sanitiza_caminho( string $caminho ): string {
		$caminho = trim( $caminho );
		if ( '' === $caminho ) {
			return '';
		}

		if ( str_contains( $caminho, '://' ) || str_starts_with( $caminho, '//' ) ) {
			return '';
		}

		if ( str_contains( $caminho, '..' ) ) {
			return '';
		}

		$partes = wp_parse_url( $caminho );
		if ( ! is_array( $partes ) || isset( $partes['host'] ) ) {
			return '';
		}

		$limpo = isset( $partes['path'] ) ? (string) $partes['path'] : '';
		if ( '' === $limpo ) {
			return '';
		}

		$limpo = '/' . ltrim( sanitize_text_field( rawurldecode( $limpo ) ), '/' );

		if ( isset( $partes['query'] ) && '' !== $partes['query'] ) {
			$limpo .= '?' . sanitize_text_field( (string) $partes['query'] );
		}

		return substr( $limpo, 0, self::TAMANHOS['caminho'] );
	}

	/**
	 * Sanitiza `f3base_seo_entidade`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_seo_entidade( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();
		if ( ! array_key_exists( 'autoria', $valor ) && ! empty( $valor['autor_institucional'] ) ) {
			$valor['autoria'] = 'organizacao'; }

		$texto_lista = static function ( $lista ): array {
			if ( ! is_array( $lista ) ) {
				return array();
			}

			return array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', $lista ) ), static fn ( string $item ): bool => '' !== $item ) );
		};

		$urls = array();
		if ( isset( $valor['same_as'] ) && is_array( $valor['same_as'] ) ) {
			foreach ( $valor['same_as'] as $url ) {
				$limpa = esc_url_raw( (string) $url );
				if ( '' !== $limpa ) {
					$urls[] = $limpa;
				}
			}
		}

		/*
		 * A CHAVE DESCONHECIDA SOBREVIVE DENTRO DO ITEM, e não só no primeiro
		 * nível da option. O defeito era o mesmo da 1.0.19, um nível abaixo:
		 * `preservar_desconhecidas()` cobria a option inteira, e cada item de
		 * `ponto_de_contato[]` e de `servicos[]` continuava sendo RECONSTRUÍDO a
		 * partir das chaves declaradas. O agente que acrescentasse `whatsapp` a
		 * um ponto de contato, ou `preco_a_partir_de` a um serviço, via a
		 * escrita entrar no banco e a primeira leitura devolvê-la sem a chave.
		 */
		$contato = array();
		if ( isset( $valor['ponto_de_contato'] ) && is_array( $valor['ponto_de_contato'] ) ) {
			foreach ( $valor['ponto_de_contato'] as $ponto ) {
				if ( ! is_array( $ponto ) ) {
					continue;
				}
				$contato[] = self::preservar_desconhecidas(
					array(
						'tipo'     => isset( $ponto['tipo'] ) ? sanitize_text_field( (string) $ponto['tipo'] ) : 'customer support',
						'telefone' => isset( $ponto['telefone'] ) ? sanitize_text_field( (string) $ponto['telefone'] ) : '',
						'email'    => isset( $ponto['email'] ) ? sanitize_email( (string) $ponto['email'] ) : '',
						'idiomas'  => isset( $ponto['idiomas'] ) ? $texto_lista( $ponto['idiomas'] ) : array(),
					),
					$ponto
				);
			}
		}

		$servicos = array();
		if ( isset( $valor['servicos'] ) && is_array( $valor['servicos'] ) ) {
			foreach ( $valor['servicos'] as $servico ) {
				if ( ! is_array( $servico ) ) {
					continue;
				}
				$nome = isset( $servico['nome'] ) ? sanitize_text_field( (string) $servico['nome'] ) : '';
				if ( '' === $nome ) {
					continue;
				}
				$servicos[] = self::preservar_desconhecidas(
					array(
						'nome'         => $nome,
						'descricao'    => isset( $servico['descricao'] ) ? sanitize_text_field( (string) $servico['descricao'] ) : '',
						'url'          => isset( $servico['url'] ) ? esc_url_raw( (string) $servico['url'] ) : '',
						'tipo_servico' => isset( $servico['tipo_servico'] ) ? sanitize_text_field( (string) $servico['tipo_servico'] ) : '',
						'area_servida' => isset( $servico['area_servida'] ) ? $texto_lista( $servico['area_servida'] ) : array(),
					),
					$servico
				);
			}
		}

		return F3Base_Seo_Entidade::normalizar(
			self::preservar_desconhecidas(
				array(
					'nome'             => isset( $valor['nome'] ) ? sanitize_text_field( (string) $valor['nome'] ) : (string) $padrao['nome'],
					'same_as'          => $urls,
					'area_servida'     => isset( $valor['area_servida'] ) ? $texto_lista( $valor['area_servida'] ) : array(),
					'conhece_sobre'    => isset( $valor['conhece_sobre'] ) ? $texto_lista( $valor['conhece_sobre'] ) : array(),
					'ponto_de_contato' => $contato,
					'organizacao_mae'  => is_array( $valor['organizacao_mae'] ?? null ) ? F3Base_Seo_Entidade::relacao( $valor['organizacao_mae'] ) : sanitize_text_field( (string) ( $valor['organizacao_mae'] ?? '' ) ),
					'servicos'         => $servicos,
					'faq_schema'       => isset( $valor['faq_schema'] ) ? (bool) $valor['faq_schema'] : (bool) $padrao['faq_schema'],
				),
				$valor
			)
		);
	}

	/**
	 * Sanitiza `f3base_cabecalhos`.
	 *
	 * COOP DEIXOU DE SER LITERAL NA 1.1.0. Até a 1.0.19 esta função devolvia
	 * `coop` escrito à mão no catálogo, IGNORANDO o valor
	 * armazenado: quem gravasse outro valor pelo canal lia de volta o valor do
	 * pacote e ficava sem saber por quê — a leitura de volta conferia contra o
	 * que a própria sanitização tinha imposto. Agora o valor gravado é o que
	 * sai, dentro do vocabulário fechado do cabeçalho.
	 *
	 * O que o pacote continua a fazer: `same-origin` corta a janela aberta pelo
	 * fluxo de leads do WhatsApp, e o módulo de cabeçalhos fecha DEGRADADO
	 * nomeando essa consequência. Nomear a consequência é o instrumento; recusar
	 * a escrita não é.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_cabecalhos( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$frame = isset( $valor['x_frame_options'] ) ? strtoupper( sanitize_text_field( (string) $valor['x_frame_options'] ) ) : (string) $padrao['x_frame_options'];
		if ( ! in_array( $frame, F3Base_Vocabulario::politicas_de_frame(), true ) ) {
			$frame = F3Base_Vocabulario::FRAME_MESMA_ORIGEM;
		}

		$referrer = isset( $valor['referrer_policy'] ) ? sanitize_text_field( (string) $valor['referrer_policy'] ) : (string) $padrao['referrer_policy'];
		$aceitos  = F3Base_Vocabulario::politicas_de_referrer();
		$referrer = in_array( $referrer, $aceitos, true ) ? $referrer : (string) $padrao['referrer_policy'];
		$max_age  = isset( $valor['hsts_max_age'] ) ? (int) $valor['hsts_max_age'] : (int) $padrao['hsts_max_age'];
		$max_age  = self::limitar( 'hsts_segundos', $max_age );

		/*
		 * O CONJUNTO É O DO VOCABULÁRIO COMPARTILHADO, como já acontece com
		 * frame, referrer e COOP. `F3Base_Vocabulario::decisoes_governadas()`
		 * declarava governar `cabecalhos.permissions_policy`, e o sanitizador a
		 * aceitava por `sanitize_text_field()` — isto é, aceitava qualquer
		 * coisa: governar no vocabulário e não reconhecer no runtime é pior que
		 * não governar, porque a linha da tabela afirma uma recusa que não
		 * acontece. Cada capacidade acrescentada a uma `Permissions-Policy`
		 * desliga um recurso do navegador para o site inteiro, e a escolha entre
		 * listas é decisão declarada, com o motivo escrito ao lado.
		 */
		$permissoes = isset( $valor['permissions_policy'] ) ? sanitize_text_field( (string) $valor['permissions_policy'] ) : (string) $padrao['permissions_policy'];
		$permissoes = in_array( $permissoes, F3Base_Vocabulario::politicas_de_permissoes(), true )
			? $permissoes
			: (string) $padrao['permissions_policy'];

		$coop = isset( $valor['coop'] ) ? strtolower( sanitize_text_field( (string) $valor['coop'] ) ) : (string) $padrao['coop'];
		$coop = in_array( $coop, self::coop_aceitos(), true ) ? $coop : (string) $padrao['coop'];

		/*
		 * O VALOR FORA DA FORMA É PRESERVADO NA LEITURA, e recusado na ESCRITA.
		 *
		 * `sanitize_text_field()` preserva o ponto e vírgula, e o ponto e
		 * vírgula ENCERRA a diretiva: `frame-ancestors 'self'; script-src
		 * 'unsafe-inline'` é um CSP inteiro injetado pelo campo da moldura, com
		 * efeito sobre o carregamento de todo script da página. Mas este
		 * sanitizador roda também na LEITURA, e apagar aqui o que já está
		 * gravado seria a troca silenciosa que este pacote parou de fazer: quem
		 * se recusa a EMITIR o valor fora da forma é o módulo, que o nomeia em
		 * `avisos()`. Quem impede o valor NOVO de entrar no lugar de um valor
		 * bom é `escrita_de_cabecalhos()`, na gravação, com o campo nomeado.
		 */
		$ancestrais = isset( $valor['csp_frame_ancestors'] )
			? sanitize_text_field( (string) $valor['csp_frame_ancestors'] )
			: (string) $padrao['csp_frame_ancestors'];

		return self::preservar_desconhecidas(
			array(
				'x_content_type_options' => isset( $valor['x_content_type_options'] ) ? (bool) $valor['x_content_type_options'] : (bool) $padrao['x_content_type_options'],
				'x_frame_options'        => $frame,
				'csp_frame_ancestors'    => $ancestrais,
				'referrer_policy'        => $referrer,
				'coop'                   => $coop,
				'permissions_policy'     => $permissoes,
				'hsts'                   => isset( $valor['hsts'] ) ? (bool) $valor['hsts'] : (bool) $padrao['hsts'],
				'hsts_max_age'           => $max_age,
			),
			$valor
		);
	}

	/**
	 * Vocabulário fechado do `Cross-Origin-Opener-Policy`.
	 *
	 * Fechado porque cabeçalho com valor que o navegador não conhece é
	 * cabeçalho ignorado — e ignorado em silêncio é pior que ausente. O que a
	 * lista NÃO faz é escolher por quem grava: `same-origin` está nela, e o
	 * preço dele para o fluxo de leads sai nomeado no estado do módulo.
	 *
	 * @return array<int,string>
	 */
	public static function coop_aceitos(): array {
		return F3Base_Vocabulario::politicas_de_coop();
	}

	/**
	 * Sanitiza um ID de post.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return int
	 */
	public static function sanitiza_id_post( $valor, $padrao ): int {
		unset( $padrao );

		return is_scalar( $valor ) ? max( 0, (int) $valor ) : 0;
	}

	/**
	 * Sanitiza uma lista genérica gravada por outro artefato do pacote.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<mixed>
	 */
	public static function sanitiza_lista_generica( $valor, array $padrao ): array {
		unset( $padrao );

		return is_array( $valor ) ? $valor : array();
	}

	/**
	 * Sanitiza `f3base_atividade`.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<string,array<string,mixed>>
	 */
	public static function sanitiza_atividade( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $chave => $dados ) {
			$chave_limpa = sanitize_key( (string) $chave );
			if ( '' === $chave_limpa || ! is_array( $dados ) ) {
				continue;
			}

			$entrada = array();
			foreach ( $dados as $campo => $conteudo ) {
				$campo_limpo = sanitize_key( (string) $campo );
				if ( '' === $campo_limpo ) {
					continue;
				}
				if ( is_int( $conteudo ) || is_float( $conteudo ) ) {
					$entrada[ $campo_limpo ] = $conteudo + 0;
				} elseif ( is_bool( $conteudo ) ) {
					$entrada[ $campo_limpo ] = $conteudo;
				} elseif ( is_array( $conteudo ) ) {
					/*
					 * SUB-ARRAY RECURSA, E NÃO VIRA A PALAVRA "ARRAY".
					 *
					 * O DEFEITO MEDIDO: o ramo final fazia
					 * `sanitize_text_field( (string) $conteudo )`, e a conversão
					 * de array para string em PHP produz literalmente `Array`
					 * (com um aviso `Array to string conversion` no log). Um
					 * módulo que carimbasse uma estrutura — a lista de faixas
					 * que recusaram uma leitura, os campos de um erro de
					 * fornecedor — perdia o carimbo inteiro e ganhava a palavra
					 * `Array` na tela, ao lado da data. Recursar preserva o
					 * dado; descartá-lo perderia a única prova daquela
					 * execução.
					 */
					$entrada[ $campo_limpo ] = self::sanitiza_desconhecido( $conteudo );
				} else {
					$entrada[ $campo_limpo ] = sanitize_text_field( (string) $conteudo );
				}
			}

			$saida[ $chave_limpa ] = $entrada;
		}

		return $saida;
	}

	/**
	 * Sanitiza `f3base_mcp_files_audit`.
	 *
	 * Antes desta função a option passava por `sanitiza_lista_generica()`, que
	 * devolve o array como veio — sem forma, sem teto e com autoload ligado. O
	 * teto agora é declarado no catálogo e aplicado na ESCRITA, por
	 * `cortar_na_escrita()`; aqui fica só a forma.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<mixed>
	 */
	public static function sanitiza_auditoria_do_canal( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( array_values( $valor ) as $entrada ) {
			$saida[] = self::sanitiza_desconhecido( $entrada );
		}

		return $saida;
	}

	/**
	 * OS AJUSTES QUE SÓ ACONTECEM NA ESCRITA, e o que eles têm a dizer.
	 *
	 * Dois deles: o corte no teto declarado, e a recusa declarada da option —
	 * um valor novo que este pacote sabe que nunca vai funcionar não entra no
	 * lugar do que já está gravado. Os dois devolvem FRASE, e a frase vai para o
	 * motivo da gravação: recusar em silêncio é o mesmo defeito que normalizar
	 * em silêncio, com outro nome.
	 *
	 * @param string              $nome        Nome da option.
	 * @param mixed               $normalizado Valor já sanitizado.
	 * @param array<string,mixed> $declaracao  Declaração do catálogo.
	 * @return array{valor:mixed,avisos:array<int,string>}
	 */
	public static function ajustar_na_escrita( string $nome, $normalizado, array $declaracao ): array {
		$normalizado = self::cortar_na_escrita( $nome, $normalizado, $declaracao );
		$avisos      = array();

		$regra = isset( $declaracao['na_escrita'] ) ? $declaracao['na_escrita'] : null;

		if ( is_callable( $regra ) ) {
			$resultado = call_user_func( $regra, $normalizado, self::ler( $nome ), $nome );

			if ( is_array( $resultado ) && array_key_exists( 'valor', $resultado ) ) {
				$normalizado = $resultado['valor'];
				$avisos      = isset( $resultado['avisos'] ) && is_array( $resultado['avisos'] )
					? array_values( array_filter( array_map( 'strval', $resultado['avisos'] ) ) )
					: array();
			}
		}

		return array(
			'valor'  => $normalizado,
			'avisos' => $avisos,
		);
	}

	/**
	 * ESCRITA de `f3base_redirects`: o par que gira não entra.
	 *
	 * O DEFEITO MEDIDO numa bancada WordPress real: o sanitizador recusava
	 * `de === para` comparando o TEXTO CRU, e quem casa a requisição com o par é
	 * `F3Base_Modulo_Redirects::casar_declarado()`, que NORMALIZA barra final e
	 * query dos dois lados antes de comparar. O par `/servicos/ → /servicos`
	 * passava na gravação e casava ao servir: o visitante recebia 301 para o
	 * mesmo endereço, para sempre — foram medidas quatro respostas 3xx seguidas,
	 * que é o ERR_TOO_MANY_REDIRECTS do navegador.
	 *
	 * O 410 É A EXCEÇÃO DECLARADA: ali o destino não é para onde se vai, é só o
	 * que sobra do par.
	 *
	 * @param mixed  $novo     Valor sanitizado que se quer gravar.
	 * @param mixed  $anterior Valor lido do banco antes desta escrita.
	 * @param string $nome     Nome da option.
	 * @return array{valor:mixed,avisos:array<int,string>}
	 */
	public static function escrita_de_redirects( $novo, $anterior, string $nome ) {
		unset( $anterior, $nome );

		if ( ! is_array( $novo ) || ! class_exists( 'F3Base_Modulo_Redirects' ) ) {
			return array(
				'valor'  => $novo,
				'avisos' => array(),
			);
		}

		$aceitos   = array();
		$recusados = array();

		foreach ( $novo as $regra ) {
			$de     = isset( $regra['de'] ) ? (string) $regra['de'] : '';
			$para   = isset( $regra['para'] ) ? (string) $regra['para'] : '';
			$status = isset( $regra['status'] ) ? (int) $regra['status'] : 301;

			if ( 410 !== $status && F3Base_Modulo_Redirects::par_gira( $de, $para ) ) {
				$recusados[] = $de . ' → ' . $para;
				continue;
			}

			$aceitos[] = $regra;
		}

		if ( array() === $recusados ) {
			return array(
				'valor'  => $novo,
				'avisos' => array(),
			);
		}

		return array(
			'valor'  => array_values( $aceitos ),
			'avisos' => array(
				sprintf(
					/* translators: %s: pares recusados, separados por ponto e vírgula. */
					__( 'Estes pares NÃO foram gravados porque origem e destino normalizam para o mesmo endereço, e o visitante voltaria ao mesmo lugar para sempre: %s. Os demais pares foram gravados.', 'f3base' ),
					implode( '; ', $recusados )
				),
			),
		);
	}

	/**
	 * ESCRITA de `f3base_cabecalhos`: o valor fora da forma não substitui um bom.
	 *
	 * `sanitize_text_field()` preserva o ponto e vírgula, e o ponto e vírgula
	 * ENCERRA a diretiva do CSP: `'self'; script-src 'unsafe-inline'` gravado no
	 * campo da moldura é uma política inteira escrita pelo campo errado. O que
	 * JÁ ESTÁ gravado é preservado — a leitura não apaga nada, e o módulo se
	 * recusa a emiti-lo nomeando o motivo. O que esta função impede é o valor
	 * NOVO fora da forma entrar no lugar de um valor que funciona.
	 *
	 * @param mixed  $novo     Valor sanitizado que se quer gravar.
	 * @param mixed  $anterior Valor lido do banco antes desta escrita.
	 * @param string $nome     Nome da option.
	 * @return array{valor:mixed,avisos:array<int,string>}
	 */
	public static function escrita_de_cabecalhos( $novo, $anterior, string $nome ) {
		unset( $nome );

		if ( ! is_array( $novo ) || ! class_exists( 'F3Base_Modulo_Cabecalhos' ) ) {
			return array(
				'valor'  => $novo,
				'avisos' => array(),
			);
		}

		$candidato = (string) ( $novo['csp_frame_ancestors'] ?? '' );

		if ( '' === $candidato || F3Base_Modulo_Cabecalhos::frame_ancestors_na_forma( $candidato ) ) {
			return array(
				'valor'  => $novo,
				'avisos' => array(),
			);
		}

		$guardado = is_array( $anterior ) ? (string) ( $anterior['csp_frame_ancestors'] ?? '' ) : '';

		if ( $guardado === $candidato ) {
			/* O valor já estava assim: preservá-lo é a regra, e não há troca a avisar. */
			return array(
				'valor'  => $novo,
				'avisos' => array(),
			);
		}

		$novo['csp_frame_ancestors'] = $guardado;

		return array(
			'valor'  => $novo,
			'avisos' => array(
				sprintf(
					/* translators: %s: valor recusado. */
					__( 'O campo csp_frame_ancestors NÃO foi gravado com "%s": esse texto está fora da forma que o cabeçalho aceita, e o ponto e vírgula dentro dele encerraria a diretiva e abriria uma política nova para todo script da página. O valor anterior continua valendo.', 'f3base' ),
					$candidato
				),
			),
		);
	}

	/**
	 * CORTA UMA LISTA NO TETO DECLARADO, e só na ESCRITA.
	 *
	 * O DEFEITO MEDIDO era duplo, e a segunda metade é a pior. O corte do
	 * journal acontecia dentro do SANITIZADOR — que roda também na LEITURA —,
	 * então a option inteira continuava no banco e o que a tela mostrava era um
	 * recorte dela; e ele descartava as entradas MAIS ANTIGAS, em silêncio. Um
	 * journal de eliminação existe para provar o que foi apagado e quando:
	 * cortar o começo dele é apagar a prova mais velha primeiro, que é
	 * justamente a que alguém procuraria numa auditoria.
	 *
	 * A ENTRADA DE CORTE DIZ QUANTAS SAÍRAM E DESDE QUANDO, e ela ocupa uma
	 * posição da lista. Sem esses dois números, quem lê não sabe se está vendo
	 * tudo — e "vi tudo o que havia" é a única conclusão que uma lista truncada
	 * em silêncio permite.
	 *
	 * @param string              $nome        Nome da option.
	 * @param mixed               $normalizado Valor já sanitizado.
	 * @param array<string,mixed> $declaracao  Declaração do catálogo.
	 * @return mixed Valor a gravar.
	 */
	private static function cortar_na_escrita( string $nome, $normalizado, array $declaracao ) {
		if ( ! isset( $declaracao['teto_de_entradas'] ) || ! is_array( $normalizado ) ) {
			return $normalizado;
		}

		$entradas = array_values( $normalizado );
		$teto     = self::teto_de_entradas( $nome, (int) $declaracao['teto_de_entradas'] );

		if ( count( $entradas ) <= $teto ) {
			return $entradas;
		}

		/* A marca do corte ocupa uma posição: o que sobra de entrada é o teto menos ela. */
		$sobram   = max( 1, $teto - 1 );
		$saiu     = count( $entradas ) - $sobram;
		$restante = array_slice( $entradas, $saiu );
		$primeira = $entradas[0];
		$desde    = is_array( $primeira ) && isset( $primeira['em'] ) ? (int) $primeira['em'] : 0;

		array_unshift(
			$restante,
			array(
				/*
				 * A MARCA É UMA ENTRADA VÁLIDA DA PRÓPRIA LISTA, e por isso ela
				 * traz `regime` e os campos que o sanitizador do journal conhece:
				 * uma marca que o sanitizador descartasse na leitura seguinte
				 * seria um corte que voltou a ser silencioso.
				 */
				'regime'         => 'operacional',
				'operador'       => __( 'corte automático da lista', 'f3base' ),
				'identificador'  => $nome,
				'contagem'       => $saiu,
				'em'             => time(),
				'reversivel_ate' => 0,
				'corte'          => true,
				'saiu'           => $saiu,
				'desde'          => $desde,
			)
		);

		/*
		 * A LISTA CORTADA VOLTA A PASSAR PELO SANITIZADOR, e isso não é zelo: o
		 * que `gravar()` grava tem de ser exatamente o que `ler()` devolve, e a
		 * marca do corte é montada aqui, fora do sanitizador. Sem esta passagem,
		 * um campo que o sanitizador acrescenta e a marca não traz faria a
		 * leitura de volta divergir — e a gravação sairia como falha por causa
		 * do próprio corte.
		 */
		return self::sanitizar( $nome, array_values( $restante ) );
	}

	/**
	 * Sanitiza `f3base_origem_confiavel`.
	 *
	 * O nome do cabeçalho é reduzido ao alfabeto de um nome de cabeçalho HTTP e
	 * os saltos ficam entre 1 e 10: cabeçalho não é caminho nem expressão, e
	 * salto zero significaria ler a ponta que o próprio cliente escreveu.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_origem_confiavel( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$cabecalho = isset( $valor['cabecalho'] ) ? trim( sanitize_text_field( (string) $valor['cabecalho'] ) ) : (string) $padrao['cabecalho'];
		$cabecalho = preg_replace( '/[^A-Za-z0-9_-]/', '', $cabecalho );
		$cabecalho = is_string( $cabecalho ) ? $cabecalho : '';

		$saltos = isset( $valor['saltos'] ) ? (int) $valor['saltos'] : (int) $padrao['saltos'];

		/*
		 * A LEITURA DAS FAIXAS É A DO CONSUMIDOR, e há uma implementação só.
		 * `F3Base_Modulo_Endpoint_Leads::redes_declaradas()` aceita lista ou
		 * texto separado por vírgula, quebra de linha ou espaço, e DESCARTA o
		 * que não casa com IP nem com CIDR — faixa ilegível não pode virar faixa
		 * que aceita tudo. Reescrever a leitura aqui seria a segunda regra para
		 * o mesmo risco, e as duas divergiriam na primeira notação aceita a
		 * mais. Sem a classe do módulo — o caso da desinstalação, em que só o
		 * catálogo é carregado —, a lista fica VAZIA, que é a posição segura:
		 * nunca confiar no cabeçalho.
		 */
		$redes = class_exists( 'F3Base_Modulo_Endpoint_Leads' )
			? F3Base_Modulo_Endpoint_Leads::redes_declaradas( $valor['redes_confiaveis'] ?? ( $padrao['redes_confiaveis'] ?? array() ) )
			: array();

		return self::preservar_desconhecidas(
			array(
				'cabecalho'        => $cabecalho,
				'saltos'           => self::limitar( 'saltos', $saltos ),
				'redes_confiaveis' => $redes,
			),
			$valor
		);
	}

	/**
	 * Sanitiza o resumo de comportamento guardado no próprio site.
	 *
	 * OS DOIS PRAZOS TÊM TETO, e o teto não é enfeite. `retencao_dias` governa
	 * o que a limpeza automática apaga: um prazo sem limite superior faria a
	 * tabela crescer sem fim numa instalação em que ninguém revisa esta tela, e
	 * este resumo não é arquivo histórico — quem precisa de série longa a tem
	 * na conta de medição. `dias_no_painel` governa só a leitura, e é limitado
	 * pelo que existe: pedir mais dias do que a retenção guarda mostraria um
	 * período cujo começo foi apagado, com o total parecendo queda de tráfego.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_comportamento( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$retencao = isset( $valor['retencao_dias'] ) ? (int) $valor['retencao_dias'] : (int) $padrao['retencao_dias'];
		$retencao = self::limitar( 'comportamento_dias', $retencao );

		$painel = isset( $valor['dias_no_painel'] ) ? (int) $valor['dias_no_painel'] : (int) $padrao['dias_no_painel'];
		$painel = max( 1, min( $retencao, $painel ) );

		/*
		 * O PRAZO DO REGISTRO BRUTO NUNCA PASSA O DO AGREGADO, e o teto é
		 * estrutural. O registro é dado pessoal pseudonimizado — visitante,
		 * sessão e carimbo de milissegundo —; o agregado não identifica
		 * ninguém. Guardar o identificável por MAIS tempo que o anônimo
		 * inverteria a única razão de as duas tabelas existirem, e o operador
		 * conseguiria fazê-lo digitando um número maior num campo.
		 */
		$eventos = isset( $valor['retencao_eventos_dias'] ) ? (int) $valor['retencao_eventos_dias'] : (int) $padrao['retencao_eventos_dias'];
		$eventos = max( 1, min( $retencao, $eventos ) );

		return self::preservar_desconhecidas(
			array(
				'ligado'                => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : (bool) $padrao['ligado'],
				'tempo_ativo'           => ! empty( $valor['tempo_ativo'] ),
				'retencao_dias'         => $retencao,
				'retencao_eventos_dias' => $eventos,
				'dias_no_painel'        => $painel,
			),
			$valor
		);
	}

	/**
	 * Sanitiza a cadência declarada.
	 *
	 * @param mixed                $valor  Valor bruto.
	 * @param array<string,mixed>  $padrao Padrão embutido.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_cadencia( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$periodicidade = isset( $valor['periodicidade'] ) ? sanitize_key( (string) $valor['periodicidade'] ) : (string) $padrao['periodicidade'];

		if ( ! in_array( $periodicidade, self::PERIODICIDADES, true ) ) {
			$periodicidade = (string) $padrao['periodicidade'];
		}

		return self::preservar_desconhecidas(
			array(
				'periodicidade'  => $periodicidade,
				'apos_n_ajustes' => max( 0, isset( $valor['apos_n_ajustes'] ) ? (int) $valor['apos_n_ajustes'] : (int) $padrao['apos_n_ajustes'] ),
				'mecanismo'      => isset( $valor['mecanismo'] ) ? sanitize_text_field( (string) $valor['mecanismo'] ) : (string) $padrao['mecanismo'],
				'hook'           => isset( $valor['hook'] ) ? sanitize_key( (string) $valor['hook'] ) : (string) $padrao['hook'],
			),
			$valor
		);
	}

	/**
	 * Sanitiza o estado de execução da cadência.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<string,int>
	 */
	public static function sanitiza_cadencia_estado( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return self::preservar_desconhecidas(
			array(
				'ajustes'  => max( 0, isset( $valor['ajustes'] ) ? (int) $valor['ajustes'] : (int) $padrao['ajustes'] ),
				'previsto' => max( 0, isset( $valor['previsto'] ) ? (int) $valor['previsto'] : (int) $padrao['previsto'] ),
			),
			$valor
		);
	}

	/**
	 * Sanitiza `f3base_journal_eliminacao`.
	 *
	 * O journal guarda identificador, contagem, carimbo, operador, regime e o
	 * MOTIVO da janela zerada. Nenhum campo de conteúdo é aceito: CAMPO
	 * DESCONHECIDO É DESCARTADO — e isto é a exceção declarada à regra da 1.1.0,
	 * que manda preservar o que o pacote não conhece.
	 *
	 * O MOTIVO DIZ POR QUE, NUNCA O QUÊ. `reversivel_ate` em zero significa duas
	 * coisas diferentes — a janela venceu e o lote foi eliminado, ou este host
	 * nunca teve janela porque a lixeira do WordPress está desligada —, e um zero
	 * não distingue as duas para quem lê o journal meses depois. O campo é texto
	 * curto e sanitizado, e ele é escrito por um produtor só, no módulo de
	 * retenção.
	 *
	 * POR QUE A EXCEÇÃO EXISTE AQUI. A regra da 1.1.0 protege CONFIGURAÇÃO: o
	 * agente acrescenta uma chave a um ajuste do site e o pacote não a apaga. O
	 * journal não é configuração — é o registro do que já foi eliminado, e a
	 * frase deste docblock é a promessa de que ele NUNCA guarda o conteúdo
	 * eliminado. Preservar campo desconhecido aqui é abrir a porta para o
	 * conteúdo do lead voltar para dentro da option que existe justamente para
	 * provar que ele saiu. O defeito medido era esta função PRESERVAR enquanto o
	 * próprio docblock dela prometia descartar; das duas, a promessa é a que
	 * está certa.
	 *
	 * O CORTE SAIU DAQUI. Ele acontecia na leitura e descartava as entradas mais
	 * antigas em silêncio; agora é `cortar_na_escrita()`, com o teto declarado
	 * no catálogo e uma entrada de corte dizendo quantas saíram e desde quando.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<int,array<string,mixed>>
	 */
	public static function sanitiza_journal( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $entrada ) {
			if ( ! is_array( $entrada ) ) {
				continue;
			}

			$regime = isset( $entrada['regime'] ) ? sanitize_key( (string) $entrada['regime'] ) : '';
			if ( ! in_array( $regime, array( 'operacional', 'titular' ), true ) ) {
				continue;
			}

			$limpa = array(
				'regime'             => $regime,
				'identificador'      => isset( $entrada['identificador'] ) ? sanitize_text_field( (string) $entrada['identificador'] ) : '',
				'identificador_hash' => isset( $entrada['identificador_hash'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $entrada['identificador_hash'] ) ) : '',
				'contagem'           => isset( $entrada['contagem'] ) ? max( 0, (int) $entrada['contagem'] ) : 0,
				'em'                 => isset( $entrada['em'] ) ? max( 0, (int) $entrada['em'] ) : 0,
				'operador'           => isset( $entrada['operador'] ) ? sanitize_text_field( (string) $entrada['operador'] ) : '',
				'reversivel_ate'     => isset( $entrada['reversivel_ate'] ) ? max( 0, (int) $entrada['reversivel_ate'] ) : 0,
				'motivo'             => isset( $entrada['motivo'] ) ? sanitize_text_field( (string) $entrada['motivo'] ) : '',
			);

			/*
			 * OS TRÊS CAMPOS DA ENTRADA DE CORTE SÃO DECLARADOS, e por isso ela
			 * sobrevive à leitura seguinte. Eles só existem na entrada que
			 * registra um corte: acrescentá-los a todas as outras encheria o
			 * journal de zeros que não dizem nada.
			 */
			if ( ! empty( $entrada['corte'] ) ) {
				$limpa['corte'] = true;
				$limpa['saiu']  = isset( $entrada['saiu'] ) ? max( 0, (int) $entrada['saiu'] ) : 0;
				$limpa['desde'] = isset( $entrada['desde'] ) ? max( 0, (int) $entrada['desde'] ) : 0;
			}

			$saida[] = $limpa;
		}

		return array_values( $saida );
	}

	/**
	 * Sanitiza um segredo hexadecimal.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_segredo( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		$limpo = preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $valor ) );

		return is_string( $limpo ) ? substr( $limpo, 0, 128 ) : '';
	}

	public static function sanitiza_sessao( $valor, array $padrao ): array {
		$valor  = is_array( $valor ) ? $valor : array();
		$regras = array();
		foreach ( array_slice( is_array( $valor['regras'] ?? null ) ? $valor['regras'] : ( $padrao['regras'] ?? array() ), 0, 30 ) as $regra ) {
			if ( ! is_array( $regra ) ) {
				continue; }
			$regras[] = array(
				'papel'      => sanitize_key( (string) ( $regra['papel'] ?? '' ) ),
				'capacidade' => sanitize_key( (string) ( $regra['capacidade'] ?? '' ) ),
				'dias'       => self::limitar( 'sessao_dias', (int) ( $regra['dias'] ?? 14 ) ),
				'nucleo'     => ! empty( $regra['nucleo'] ),
			);
		}
		return self::preservar_desconhecidas(
			array(
				'ligado' => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : $padrao['ligado'],
				'dias'   => self::limitar( 'sessao_dias', (int) ( $valor['dias'] ?? $padrao['dias'] ) ),
				'modo'   => 'por-perfil' === ( $valor['modo'] ?? '' ) ? 'por-perfil' : 'legado',
				'regras' => $regras,
			),
			$valor
		);
	}
	public static function recusa_sessao( $valor, array $declaracao, string $nome ): string {
		if ( ! is_array( $valor ) ) {
			return $nome . ': envie um grupo de configuração.'; }
		if ( isset( $valor['modo'] ) && ! in_array( $valor['modo'], array( 'legado', 'por-perfil' ), true ) ) {
			return 'Modo de sessão desconhecido.'; }
		if ( isset( $valor['dias'] ) && ( false === filter_var( $valor['dias'], FILTER_VALIDATE_INT ) || (int) $valor['dias'] < 1 || (int) $valor['dias'] > 365 ) ) {
			return 'Duração recusada; use um inteiro entre 1 e 365 dias.'; }
		if ( isset( $valor['regras'] ) ) {
			if ( ! is_array( $valor['regras'] ) || count( $valor['regras'] ) > 30 ) {
				return 'Envie uma lista de até 30 regras.'; }
			foreach ( $valor['regras'] as $r ) {
				if ( ! is_array( $r ) || ( empty( $r['papel'] ) === empty( $r['capacidade'] ) ) ) {
					return 'Cada regra deve declarar exatamente um papel ou uma capacidade.'; }
				foreach ( array( 'papel', 'capacidade' ) as $k ) {
					if ( isset( $r[ $k ] ) && ( ! is_string( $r[ $k ] ) || ( '' !== $r[ $k ] && ! preg_match( '/^[a-z0-9_-]{1,80}$/D', $r[ $k ] ) ) ) ) {
						return 'Identificador de perfil inválido.'; }
				}
				if ( ! is_int( $r['dias'] ?? null ) || $r['dias'] < 1 || $r['dias'] > 365 || ! is_bool( $r['nucleo'] ?? null ) ) {
					return 'Cada regra exige dias entre 1 e 365 e nucleo booleano.'; }
			}
		}
		return '';
	}

	public static function padrao_log_valido( $valor ): bool {
		return is_string( $valor ) && strlen( $valor ) <= self::TAMANHOS['padrao_log'] && ! str_contains( $valor, '..' ) && 1 === preg_match( '~^(?:/|\~/)[a-zA-Z0-9_./* -]+$~D', $valor );
	}
	public static function recusa_acessos( $valor, array $declaracao, string $nome ): string {
		if ( ! is_array( $valor ) ) {
			return $nome . ': envie um grupo de configuração.'; }
		if ( isset( $valor['padrao_do_log'] ) && ! self::padrao_log_valido( $valor['padrao_do_log'] ) ) {
			return $nome . '.padrao_do_log: use caminho absoluto ou ~/ com caracteres de caminho e *, sem .., URLs ou comandos. O valor anterior foi preservado.'; }
		if ( isset( $valor['retencao_meses'] ) && ( false === filter_var( $valor['retencao_meses'], FILTER_VALIDATE_INT ) || (int) $valor['retencao_meses'] < self::FAIXAS['acessos_meses'][0] || (int) $valor['retencao_meses'] > self::FAIXAS['acessos_meses'][1] ) ) {
			return $nome . '.retencao_meses: use inteiro entre 1 e 120; zero apagaria o histórico e prazo superior a dez anos excede o limite de armazenamento declarado.'; }
		if ( isset( $valor['caminhos_excluidos'] ) ) {
			$lista = is_array( $valor['caminhos_excluidos'] ) ? $valor['caminhos_excluidos'] : explode( ',', (string) $valor['caminhos_excluidos'] );
			if ( count( $lista ) > self::TAMANHOS['prefixos_log'] ) {
				return $nome . ': máximo de cem prefixos excluídos.'; }
			foreach ( $lista as $prefixo ) {
				if ( ! is_string( $prefixo ) || ( '' !== trim( $prefixo ) && ( ! str_starts_with( trim( $prefixo ), '/' ) || strlen( $prefixo ) > self::TAMANHOS['prefixo_log'] || preg_match( '/[?\x00-\x20#]/', trim( $prefixo ) ) ) ) ) {
					return $nome . '.caminhos_excluidos: use prefixos começando por /, sem query, fragmento ou espaço.'; }
			}
		}
		return '';
	}
	public static function sanitiza_acessos( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();
		$lista = $valor['caminhos_excluidos'] ?? $padrao['caminhos_excluidos'];
		$lista = is_array( $lista ) ? $lista : explode( ',', (string) $lista );
		$lista = array_values( array_unique( array_filter( array_map( static fn( $p ) => is_string( $p ) ? trim( $p ) : '', $lista ) ) ) );
		return self::preservar_desconhecidas(
			array(
				'ligado'             => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : $padrao['ligado'],
				'padrao_do_log'      => self::padrao_log_valido( $valor['padrao_do_log'] ?? null ) ? $valor['padrao_do_log'] : $padrao['padrao_do_log'],
				'caminhos_excluidos' => array_slice( $lista, 0, self::TAMANHOS['prefixos_log'] ),
				'padroes_hospedagem' => array_slice( array_values( array_unique( array_filter( array_map( static fn( $v ) => is_string( $v ) && strlen( trim( $v ) ) >= 3 ? substr( sanitize_text_field( trim( $v ) ), 0, 80 ) : '', is_array( $valor['padroes_hospedagem'] ?? null ) ? $valor['padroes_hospedagem'] : array() ) ) ) ), 0, 8 ),
				'retencao_meses'     => self::limitar( 'acessos_meses', (int) ( $valor['retencao_meses'] ?? $padrao['retencao_meses'] ) ),
			),
			$valor
		);
	}
}
