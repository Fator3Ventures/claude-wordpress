<?php
/** Snapshot público com propriedade, atualização agrupada e retirada prioritária. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Llms_Arquivo {
	public const ESTADO = 'f3base_llms_arquivo_estado';
	public const EVENTO = 'f3base_llms_regenerar';
	public static function iniciar(): void {
		add_action( self::EVENTO, array( __CLASS__, 'gerar' ) );
		add_action( 'wp_loaded', array( __CLASS__, 'visita' ), 30 );
		add_action( 'save_post', array( __CLASS__, 'post' ), 99, 2 );
		add_action( 'before_delete_post', array( __CLASS__, 'revogar' ) );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( __CLASS__, 'meta' ), 99, 4 ); }
		add_action( 'updated_option', array( __CLASS__, 'opcao' ), 99, 3 );
		add_action(
			'added_option',
			static function ( $n, $v ): void {
				self::opcao( $n, null, $v );
			},
			99,
			2
		);
		add_action(
			'deleted_option',
			static function ( $n ): void {
				self::opcao( $n, null, null );
			},
			99
		);
		foreach ( array( 'wpseo_saved_postdata', 'wpseo_saved_indexable', 'switch_theme', 'set_object_terms', 'edited_term', 'delete_term' ) as $hook ) {
			add_action( $hook, array( __CLASS__, 'revogar' ), 99 ); }
	}
	public static function caminho(): string {
		if ( ! function_exists( 'get_home_path' ) && is_file( ABSPATH . 'wp-admin/includes/file.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php'; }
		return trailingslashit( function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH ) . 'llms.txt';
	}
	private static function lock() {
		$f = @fopen( get_temp_dir() . 'f3base-llms-' . hash( 'sha256', ABSPATH ) . '.lock', 'c' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen,WordPress.PHP.NoSilencedErrors.Discouraged -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
		if ( ! $f || ! flock( $f, LOCK_EX ) ) {
			if ( $f ) {
				fclose( $f ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
			} return false; }
		return $f;
	}
	private static function soltar( $f ): void {
		flock( $f, LOCK_UN );
		fclose( $f ); } // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
	private static function estado(): array {
		return (array) F3Base_Options::fotografia( self::ESTADO )['valor']; }
	private static function guardar( array $dados ): bool {
		return F3Base_Options::atualizar_estado( self::ESTADO, static fn( $v ) => array_replace( is_array( $v ) ? $v : array(), $dados ) )['persisted']; }
	public static function ativo(): bool {
		$c = F3Base_Options::ler( 'f3base_llms' );
		return ! empty( $c['ligado'] ) && 'arquivo_gerado' === ( $c['entrega'] ?? 'dinamica' ) && F3Base_Llms::site_publico() && ! F3Base_Llms::concorrente_de_llms()['ligado'] && ! apply_filters( 'f3base_llms_acesso_dinamico', false );
	}
	private static bool $gerando      = false;
	private static bool $retirar_apos = false;
	private static array $propriedade = array();
	public static function proprio( bool $forcar = false ): bool {
		$p = self::caminho();
		$e = (array) get_option( self::ESTADO, array() );
		if ( ! is_file( $p ) || is_link( $p ) ) {
			return false; }
		clearstatcache( true, $p );
		$chave = implode( ':', array( $e['sha256'] ?? '', $e['publicando_sha256'] ?? '', filemtime( $p ), filesize( $p ) ) );
		if ( ! $forcar && isset( self::$propriedade[ $chave ] ) ) {
			return self::$propriedade[ $chave ]; }
		$hash                        = hash_file( 'sha256', $p );
		$proprio                     = is_string( $hash ) && in_array( $hash, array_filter( array( $e['sha256'] ?? '', $e['publicando_sha256'] ?? '' ) ), true );
		self::$propriedade[ $chave ] = $proprio;
		return $proprio;
	}
	private static function agendar( int $quando ): void {
		$atual = wp_next_scheduled( self::EVENTO );
		if ( $atual && $atual > $quando ) {
			wp_clear_scheduled_hook( self::EVENTO ); }
		if ( ! wp_next_scheduled( self::EVENTO ) ) {
			wp_schedule_single_event( max( time() + 1, $quando ), self::EVENTO ); } }
	public static function visita(): void {
		if ( ! self::ativo() ) {
			return; }
		$c = F3Base_Options::ler( 'f3base_llms' );
		$e = self::estado();
		if ( ! empty( $c['atualizar_por_visita'] ) && ( ! empty( $e['pendente'] ) || (int) ( $e['proxima'] ?? 0 ) <= time() ) ) {
			self::agendar( time() + 5 ); }
	}
	public static function alterar( bool $revogar = false ): void {
		$e = self::estado();
		if ( ! self::ativo() && empty( $e['sha256'] ) && empty( $e['publicando_sha256'] ) ) {
			return; }
		self::guardar(
			array(
				'geracao'  => wp_generate_uuid4(),
				'pendente' => true,
			)
		);
		if ( $revogar || ! self::ativo() ) {
			if ( self::$gerando ) {
				self::$retirar_apos = true;
			} else {
				self::remover(); }
		}
		if ( self::ativo() ) {
			self::agendar( time() + 5 ); } else {
			wp_clear_scheduled_hook( self::EVENTO ); }
	}
	public static function revogar(): void {
		self::alterar( true ); }
	public static function post( int $id, $post ): void {
		if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) ) {
			return; }
		self::alterar( 'publish' !== $post->post_status || '' !== $post->post_password || F3Base_Modulo_Noindex_Honrado::post_e_noindex( $id ) );
	}
	public static function meta( $meta_id, $id, $chave, $valor ): void {
		unset( $meta_id, $id, $valor );
		if ( str_starts_with( (string) $chave, '_yoast_wpseo_' ) || '_f3base_autoria' === $chave ) {
			self::revogar(); }
	}
	public static function opcao( string $nome, $antes, $depois ): void {
		if ( in_array( $nome, array( 'f3base_llms', 'blog_public', 'home', 'siteurl', 'active_plugins', 'page_on_front', 'show_on_front', 'permalink_structure', 'f3base_robots' ), true ) || F3Base_Adaptador_Yoast::opcao_publica_alterada( $nome, $antes, $depois ) ) {
			self::alterar( true ); } elseif ( in_array( $nome, array( 'blogname', 'blogdescription' ), true ) ) {
			self::alterar(); }
	}
	public static function remover(): bool {
		$l = self::lock();
		if ( ! $l ) {
			self::guardar( array( 'erro' => 'trava_indisponivel' ) );
			return false; }
		try {
			$p = self::caminho();
			if ( ! file_exists( $p ) && ! is_link( $p ) ) {
				return true; }
			if ( ! self::proprio( true ) ) {
				self::guardar( array( 'erro' => 'arquivo_externo_preservado' ) );
				return false; }
			if ( ! @unlink( $p ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink,WordPress.PHP.NoSilencedErrors.Discouraged -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
				self::guardar( array( 'erro' => 'retirada_falhou' ) );
				return false; }
			self::guardar(
				array(
					'sha256'            => '',
					'publicando_sha256' => '',
					'erro'              => '',
					'retirado_em'       => time(),
				)
			);
			return true;
		} finally {
			self::soltar( $l ); }
	}
	public static function gerar(): array {
		if ( ! self::ativo() ) {
			self::remover();
			return self::consultar(); }
		$l = self::lock();
		if ( ! $l ) {
			self::guardar( array( 'erro' => 'trava_indisponivel' ) );
			return self::consultar(); }
		self::$gerando = true;
		$tmp           = '';
		try {
			$e       = self::estado();
			$geracao = $e['geracao'] ?? '';
			$revisao = F3Base_Options::revisao( 'f3base_llms' );
			$p       = self::caminho();
			if ( ( file_exists( $p ) || is_link( $p ) ) && ! self::proprio( true ) ) {
				self::guardar(
					array(
						'erro'     => 'arquivo_externo_preservado',
						'pendente' => true,
					)
				);
				return self::consultar(); }
			$m      = new F3Base_Modulo_Llms_Txt_Reserva();
			$config = F3Base_Options::ler( 'f3base_llms' );
			$itens  = F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache( $config );
			$texto  = $m->montar( $itens );
			$hash   = hash( 'sha256', $texto );
			$tmp    = tempnam( dirname( $p ), '.f3base-llms-' );
			if ( ! $tmp || dirname( $tmp ) !== dirname( $p ) || strlen( $texto ) !== file_put_contents( $tmp, $texto ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
				throw new RuntimeException( 'escrita_temporaria_falhou' ); }
			if ( ! self::ativo() || ! hash_equals( $revisao, F3Base_Options::revisao( 'f3base_llms' ) ) || ( self::estado()['geracao'] ?? '' ) !== $geracao ) {
				throw new RuntimeException( 'contexto_alterado' ); }
			// A seleção final repete os critérios de acesso imediatamente antes da publicação.
			if ( F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache( $config ) !== $itens ) {
				throw new RuntimeException( 'selecao_alterada' ); }
			if ( ! self::guardar( array( 'publicando_sha256' => $hash ) ) ) {
				throw new RuntimeException( 'propriedade_nao_registrada' ); }
			$identico = is_file( $p ) && hash_equals( $hash, (string) hash_file( 'sha256', $p ) );
			if ( ! $identico && ( file_exists( $p ) ? ! self::proprio( true ) || ! @rename( $tmp, $p ) : ! @link( $tmp, $p ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename,WordPress.PHP.NoSilencedErrors.Discouraged -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
				throw new RuntimeException( 'publicacao_atomica_falhou' ); }
				@chmod( $p, 0644 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod,WordPress.PHP.NoSilencedErrors.Discouraged -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
				$intervalo = max( 60, min( 86400, (int) ( $config['atualizacao_intervalo_segundos'] ?? 3600 ) ) );
				self::guardar(
					array(
						'sha256'            => $hash,
						'publicando_sha256' => '',
						'ultima'            => time(),
						'proxima'           => time() + $intervalo,
						'pendente'          => false,
						'erro'              => '',
						'revisao'           => $revisao,
					)
				);
			self::agendar( time() + $intervalo );
		} catch ( Throwable $erro ) {
			self::guardar(
				array(
					'erro'     => in_array( $erro->getMessage(), array( 'escrita_temporaria_falhou', 'contexto_alterado', 'selecao_alterada', 'propriedade_nao_registrada', 'publicacao_atomica_falhou' ), true ) ? $erro->getMessage() : 'geracao_falhou',
					'pendente' => true,
				)
			);
			self::agendar( time() + 60 );
		} finally {
			if ( $tmp && is_file( $tmp ) ) {
				@unlink( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink,WordPress.PHP.NoSilencedErrors.Discouraged -- Operação local atômica sob flock; retorno conferido e falha registrada, sem transporte FTP.
			} self::soltar( $l );
			self::$gerando = false;
			if ( self::$retirar_apos ) {
				self::$retirar_apos = false;
				self::remover(); }
		}
		return self::consultar();
	}
	public static function consultar(): array {
		$e = self::estado();
		$v = $e['verificacao'] ?? array();
		if ( 'verified' === ( $v['status'] ?? '' ) && ( ( $v['arquivo_sha256'] ?? '' ) !== ( $e['sha256'] ?? '' ) || ( $v['revisao'] ?? '' ) !== F3Base_Options::revisao( 'f3base_llms' ) || (int) ( $v['checked_at'] ?? 0 ) < time() - DAY_IN_SECONDS || ! self::proprio() ) ) {
			$e['verificacao']['status']    = 'pending';
			$e['verificacao']['motivos'][] = 'evidencia_desatualizada'; }
		unset( $e['verificacao']['arquivo_sha256'], $e['verificacao']['revisao'] );
		unset( $e['sha256'], $e['publicando_sha256'], $e['geracao'] );
		return array(
			'ativo'               => self::ativo(),
			'arquivo_proprio'     => self::proprio(),
			'estado'              => $e,
			'proximo_agendamento' => wp_next_scheduled( self::EVENTO ) ? wp_next_scheduled( self::EVENTO ) : null,
			'cabecalhos'          => 'Servidor deve emitir text/plain, X-Robots-Tag e Cache-Control: no-cache; verificar publicamente após configurar.',
		);
	}
	public static function desativar(): void {
		self::guardar( array( 'geracao' => wp_generate_uuid4() ) );
		wp_clear_scheduled_hook( self::EVENTO );
		self::remover(); }
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		wp_register_ability(
			'f3base/llms-arquivo',
			array(
				'label'               => 'Arquivo llms gerenciado',
				'description'         => 'Consultar não tem efeitos. Regenerar publica arquivo e verifica HTTP; exige revisão atual.',
				'category'            => 'f3base',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'acao'             => array(
							'type' => 'string',
							'enum' => array( 'consultar', 'regenerar' ),
						),
						'revisao_esperada' => array( 'type' => 'string' ),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
				'permission_callback' => static fn() => current_user_can( 'manage_options' ),
				'execute_callback'    => array( __CLASS__, 'executar' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}
	public static function executar( array $v ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array( 'codigo' => 'sem_permissao' ); }
		if ( 'regenerar' !== ( $v['acao'] ?? 'consultar' ) ) {
			return self::consultar(); }
		if ( ! hash_equals( F3Base_Options::revisao( 'f3base_llms' ), (string) ( $v['revisao_esperada'] ?? '' ) ) ) {
			return array( 'codigo' => 'revisao_divergente' ); }
		$r                                  = self::gerar();
		$e                                  = self::estado();
		$revisao                            = F3Base_Options::revisao( 'f3base_llms' );
		$fim                                = microtime( true ) + 20;
		$http                               = F3Base_Http_Publico::buscar( home_url( '/llms.txt' ), 2097152, $fim );
		$head                               = F3Base_Http_Publico::buscar( home_url( '/llms.txt' ), 0, $fim, 'HEAD' );
		$h                                  = $http['cabecalhos'] ?? array();
		$condicao                           = ! empty( $h['etag'] ) ? array( 'If-None-Match' => $h['etag'] ) : ( ! empty( $h['last-modified'] ) ? array( 'If-Modified-Since' => $h['last-modified'] ) : array() );
		$condicional                        = $condicao ? F3Base_Http_Publico::buscar( home_url( '/llms.txt' ), 2097152, $fim, 'GET', $condicao ) : array( 'status' => 0 );
		$r['verificacao']                   = self::avaliar_http( $http, $head, $condicional, $e['sha256'] ?? '', ! empty( F3Base_Options::ler( 'f3base_llms' )['indexavel'] ) );
		$r['verificacao']['arquivo_sha256'] = $e['sha256'] ?? '';
		$r['verificacao']['revisao']        = $revisao;
		if ( F3Base_Options::revisao( 'f3base_llms' ) !== $revisao || ! self::proprio( true ) ) {
			$r['verificacao']['status']    = 'pending';
			$r['verificacao']['motivos'][] = 'contexto_alterado'; }
		F3Base_Options::atualizar_estado( self::ESTADO, static fn( $atual ) => ( $atual['sha256'] ?? '' ) === ( $e['sha256'] ?? '' ) ? array_replace( $atual, array( 'verificacao' => $r['verificacao'] ) ) : null );
		return $r;
	}
	/** Propriedade local e corpo publicado não bastam para aprovar cache do servidor. */
	public static function avaliar_http( array $get, array $head, array $condicional, string $hash, bool $indexavel ): array {
		$h       = $get['cabecalhos'] ?? array();
		$motivos = array();
		if ( empty( $get['ok'] ) || ! $hash || ! hash_equals( $hash, hash( 'sha256', $get['corpo'] ?? '' ) ) ) {
			$motivos[] = 'corpo_publico_nao_confirmado'; }
		if ( ! str_starts_with( strtolower( $h['content-type'] ?? '' ), 'text/plain' ) ) {
			$motivos[] = 'content_type_inadequado'; }
		$cache = strtolower( $h['cache-control'] ?? '' );
		if ( ! str_contains( $cache, 'no-cache' ) && ! str_contains( $cache, 'no-store' ) && ! ( preg_match( '/(?:^|,)\s*max-age\s*=\s*0(?:\s*,|$)/', $cache ) && str_contains( $cache, 'must-revalidate' ) ) ) {
			$motivos[] = 'cache_sem_revalidacao'; }
		$noindex = str_contains( strtolower( $h['x-robots-tag'] ?? '' ), 'noindex' );
		if ( $noindex === $indexavel ) {
			$motivos[] = 'indexacao_divergente'; }
		if ( empty( $head['ok'] ) || '' !== ( $head['corpo'] ?? '' ) ) {
			$motivos[] = 'head_nao_confirmado'; }
		if ( empty( $h['etag'] ) && empty( $h['last-modified'] ) ) {
			$motivos[] = 'validador_http_ausente'; } elseif ( 304 !== ( $condicional['status'] ?? 0 ) ) {
			$motivos[] = 'revalidacao_304_nao_confirmada'; }
			return array(
				'status'           => $motivos ? 'pending' : 'verified',
				'checked_at'       => time(),
				'motivos'          => $motivos,
				'http'             => $get['status'] ?? 0,
				'head_http'        => $head['status'] ?? 0,
				'condicional_http' => $condicional['status'] ?? 0,
				'cache_control'    => $h['cache-control'] ?? '',
				'content_type'     => $h['content-type'] ?? '',
				'x_robots_tag'     => $h['x-robots-tag'] ?? '',
			);
	}
}
