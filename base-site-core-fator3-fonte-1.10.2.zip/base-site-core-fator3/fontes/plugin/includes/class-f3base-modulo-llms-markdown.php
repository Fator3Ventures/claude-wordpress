<?php
/** Alternativas Markdown das páginas selecionadas e descoberta conforme llms.txt v2. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Modulo_Llms_Markdown extends F3Base_Modulo {
	public function id(): string {
		return 'llms-markdown';
	}
	public function nome(): string {
		return 'Páginas em Markdown e descoberta do llms.txt';
	}
	public function descricao(): string {
		return 'Publica alternativas Markdown apenas para conteúdos públicos selecionados no llms.txt e anuncia os endereços no HTML e no cabeçalho Link.';
	}
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'template_redirect',
				'metodo'     => 'talvez_servir',
				'prioridade' => 0,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_head',
				'metodo'     => 'descoberta',
				'prioridade' => 3,
				'args'       => 0,
			),
		);
	}
	protected function calcular_estado(): array {
		$c = F3Base_Options::ler( 'f3base_llms' );
		if ( empty( $c['ligado'] ) || ! F3Base_Llms::site_publico() ) {
			return $this->inativo( 'Descoberta suspensa pela configuração de llms ou pela visibilidade do site.' ); }
		return $this->ativo( empty( $c['markdown'] ) ? 'Anuncia o índice; alternativas Markdown desligadas.' : 'Anuncia o índice e alternativas Markdown para a seleção pública.' );
	}
	public static function url_do_item( array $item ): string {
		$c   = F3Base_Options::ler( 'f3base_llms' );
		$id  = (int) ( $item['id'] ?? 0 );
		$url = (string) ( $item['url'] ?? '' );
		if ( $id < 1 || empty( $c['ligado'] ) || empty( $c['markdown'] ) || ! F3Base_Llms::site_publico() || ! F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'] ) {
			return ''; }
		$p    = wp_parse_url( $url );
		$home = wp_parse_url( home_url( '/' ) );
		if ( ! is_array( $p ) || strtolower( $p['host'] ?? '' ) !== strtolower( $home['host'] ?? '' ) || ! str_starts_with( $p['path'] ?? '/', $home['path'] ?? '/' ) ) {
			return ''; }
		if ( ! is_array( $p ) || ! empty( $p['query'] ) ) {
			return add_query_arg( 'f3base_markdown', $id, home_url( '/' ) ); }
		$path = $p['path'] ?? '/';
		$md   = preg_match( '~\.[a-z0-9]+$~i', $path ) ? $url . '.md' : trailingslashit( $url ) . 'index.md';
		// Uma alternativa física pode pertencer a outro emissor. Não a anunciamos como nossa.
		$prefixo = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$rel     = substr( (string) wp_parse_url( $md, PHP_URL_PATH ), strlen( $prefixo ) );
		return '' !== F3Base_Llms::arquivo_publico( $rel ) ? '' : $md;
	}
	public function descoberta(): void {
		if ( ! F3Base_Llms::site_publico() || ! F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'] || is_404() || is_search() ) {
			return; }
		$c = F3Base_Options::ler( 'f3base_llms' );
		if ( empty( $c['ligado'] ) ) {
			return; }
		printf( '<link rel="describedby" href="%s">' . "\n", esc_url( home_url( F3Base_Modulo_Llms_Txt_Reserva::CAMINHO ) ) );
		if ( ! is_singular() ) {
			return; }
		$id = get_queried_object_id();
		foreach ( F3Base_Modulo_Llms_Txt_Reserva::selecao( $c ) as $item ) {
			if ( (int) ( $item['id'] ?? 0 ) !== $id ) {
				continue; }
			$url = self::url_do_item( $item );
			if ( '' !== $url ) {
				printf( '<link rel="alternate" type="text/markdown" href="%s">' . "\n", esc_url( $url ) ); }
			break;
		}
	}
	public function talvez_servir(): void {
		if ( ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', array( 'GET', 'HEAD' ), true ) ) {
			return; }
		$uri  = (string) ( $_SERVER['REQUEST_URI'] ?? '' );
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		if ( ! isset( $_GET['f3base_markdown'] ) && ! str_ends_with( $path, '.md' ) ) {
			return; }
		$c = F3Base_Options::ler( 'f3base_llms' );
		if ( empty( $c['ligado'] ) || empty( $c['markdown'] ) || ! F3Base_Llms::site_publico() || ! F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'] ) {
			return; }
		foreach ( F3Base_Modulo_Llms_Txt_Reserva::selecao( $c ) as $item ) {
			$url = self::url_do_item( $item );
			if ( '' === $url ) {
				continue; }
			$p = wp_parse_url( $url );
			if ( $path !== ( $p['path'] ?? '/' ) ) {
				continue; }
			if ( ! empty( $p['query'] ) && ( ! isset( $_GET['f3base_markdown'] ) || ! is_scalar( $_GET['f3base_markdown'] ) || (string) $_GET['f3base_markdown'] !== (string) $item['id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Rota pública GET/HEAD, somente leitura; confere o ID contra a seleção editorial pública.
				continue; }
			if ( ! empty( $p['query'] ) || ! isset( $_GET['f3base_markdown'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Escolhe uma representação pública GET/HEAD, sem alterar estado.
				try {
					$texto = '# ' . F3Base_Llms::texto_markdown( (string) $item['titulo'] ) . "\n\n" . 'Fonte: ' . F3Base_Llms::url_markdown( $item['url'] ) . "\n\n" . F3Base_Llms::markdown( (string) ( $item['conteudo'] ?? '' ), $item['url'] ) . "\n";
				} catch ( RuntimeException $erro ) {
					F3Base_Modulo_Llms_Txt_Reserva::responder_incompleto( $erro->getMessage() );
					return; }
				if ( ! headers_sent() ) {
					header( 'Link: <' . F3Base_Llms::url_markdown( $item['url'] ) . '>; rel="canonical", <' . F3Base_Llms::url_markdown( home_url( '/llms.txt' ) ) . '>; rel="describedby"', false ); }
				F3Base_Modulo_Llms_Txt_Reserva::responder( $texto, array( 'indexavel' => false ), 'llms-markdown', 'text/markdown' );
			}
		}
	}
}
