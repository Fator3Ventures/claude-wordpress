<?php
/** Administrator forms for the public conversion configuration service. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{
    ConversionDelivery as Delivery,Connections,Options
};
if (!defined('ABSPATH')) {
    exit;
}
final class ConversionScreen {
    public static function render(): void {
        if (!Options::authorized()) {
            wp_die(esc_html__('Permissão insuficiente.','wp-mcp-google-fator3'));
        }
        $id=sanitize_key(wp_unslash($_POST['connection_id']??$_GET['connection_id']??'default'));
        Connections::run($id,static function() use($id) {
            $result=null;
            if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
                check_admin_referer('f3-google-conversions');
                $revision=sanitize_text_field(wp_unslash($_POST['revision']??''));
                if (($_POST['action_kind']??'configure')==='verify') {
                    $target=sanitize_key($_POST['target']??'');
                    $s=Delivery::status();
                    $c=$s['config']??[];
                    $result=Delivery::verify(['expected_revision'=>$revision,'target'=>$target,'eligibility_receipt'=>[
                                'customer_id'=>$c['customer_id']??'','conversion_action'=>$c['conversion_action']??'',
                                'successful_upload_confirmed'=>isset($_POST['successful_upload_confirmed']),
                                'request_id'=>sanitize_text_field(wp_unslash($_POST['request_id']??''))]]);
                }
                else {
                    $c=['enabled'=>isset($_POST['enabled'])];
                    foreach (['measurement_id','stream','customer_id','conversion_action'] as $key) $c[$key]=sanitize_text_field(wp_unslash($_POST[$key]??''));
                    $result=Delivery::configure(['expected_revision'=>$revision,'config'=>$c,'mp_secret'=>wp_unslash($_POST['mp_secret']??''),'clear_mp_secret'=>isset($_POST['clear_mp_secret'])]);
                }
            }
            $s=Delivery::status();
            $c=$s['config']??Delivery::defaults();
            echo '<div class="wrap"><h1>Fator3 MCP Google — Conversões</h1><p>Configure o destino nesta conexão, verifique o acesso e depois selecione servidor no Core. A ativação vale para os contatos elegíveis definidos pelo Core.</p>';
            echo '<form method="get"><input type="hidden" name="page" value="f3-google-conversions"><label>Conexão <select name="connection_id">';
            foreach (Connections::registry() as $cid=>$meta) echo '<option value="'.esc_attr($cid).'" '.selected($id,$cid,false).'>'.esc_html($meta['label']).'</option>';
            echo '</select></label> <button class="button">Selecionar</button></form>';
            if ($result) echo '<div class="notice '.(!empty($result['success'])?'notice-success':'notice-error').'"><p>'.esc_html(!empty($result['success'])?'Operação confirmada.':($result['message']??'Operação não confirmada.')).'</p></div>';
            echo '<table class="widefat striped"><thead><tr><th>Destino</th><th>Prontidão</th><th>Motivo</th><th>Confirmação do fornecedor</th></tr></thead><tbody>';
            $reasons=['ambiguous_connection'=>'Mais de uma conexão habilitada para este destino','connections_unreadable'=>'Registro de conexões ilegível','configuration_unreadable'=>'Configuração ilegível','ok'=>'Verificação vigente','channel_disabled'=>'Canal Google fechado','integration_disabled'=>'Integração desabilitada','grant_revoked'=>'Autorização administrativa revogada','service_disabled'=>'Serviço desabilitado','service_read_only'=>'Serviço permitido somente para leitura','credential_unavailable'=>'Credencial indisponível','destination_missing'=>'Destino não preenchido','mp_secret_missing'=>'Segredo MP ausente','ads_developer_token_missing'=>'Developer token ausente','resource_not_permitted'=>'Recurso fora da política','verification_required'=>'Verificação necessária ou expirada','storage_or_recovery_unavailable'=>'Armazenamento ou recuperação indisponível'];
            foreach (['ga4'=>'GA4','google_ads'=>'Google Ads'] as $key=>$name) {
                $cap=$s[$key]??[];
                echo '<tr><td>'.esc_html($name).'</td><td>'.(!empty($cap['ready'])?'Pronto para envio':'Indisponível').'</td><td>'.esc_html($reasons[$cap['reason']??'']??($cap['reason']??'Configuração ilegível')).'</td><td>'.($key==='ga4'?'Recebimento HTTP; processamento não confirmado':'Resultado individual de importação').'</td></tr>';
            }
            echo '</tbody></table><h2>Configuração</h2><form method="post">';
            self::hidden($id,$s['revision']??'');
            echo '<p><label><input type="checkbox" name="enabled" '.checked(!empty($c['enabled']),true,false).'> Autorizar o Core a enviar conversões por esta conexão após verificação</label></p><table class="form-table">';
            foreach (['measurement_id'=>['Measurement ID GA4','G-ABC123'], 'stream'=>['Stream da propriedade','properties/123/dataStreams/456'],'customer_id'=>['Conta de conversão Google Ads','1234567890'],'conversion_action'=>['Ação de importação Google Ads','customers/1234567890/conversionActions/789']] as $key=>$field) {
                echo '<tr><th><label for="'.esc_attr($key).'">'.esc_html($field[0]).'</label></th><td><input class="regular-text" id="'.esc_attr($key).'" name="'.esc_attr($key).'" value="'.esc_attr($c[$key]).'" placeholder="'.esc_attr($field[1]).'"></td></tr>';
            }
            echo '<tr><th><label for="mp_secret">Segredo Measurement Protocol</label></th><td><input id="mp_secret" type="password" name="mp_secret" autocomplete="new-password"><p class="description">GA4 → Administrador → Fluxos de dados → seu fluxo → Segredos da API do Measurement Protocol. Vazio mantém o segredo atual. Estado: '.(!empty($s['mp_secret_present'])?'presente':'ausente').'.</p><label><input type="checkbox" name="clear_mp_secret"> Remover o segredo e invalidar a verificação</label></td></tr></table><p>Valor e moeda vêm do contato entregue pelo Core. O Google não cria ações ou metas. Para cada destino, habilite somente uma conexão.</p><button class="button button-primary">Salvar configuração</button></form>';
            echo '<h2>Verificar acesso</h2><p>Esta ação consulta as APIs. GA4 verifica propriedade, segredo e depura um evento sintético sem ingestão. A comprovação local vence em 24 horas; uma alteração relevante exige nova verificação.</p><form method="post">';
            self::hidden($id,$s['revision']??'');
            echo '<input type="hidden" name="action_kind" value="verify"><p><label>Destino <select name="target"><option value="ga4">GA4</option><option value="google_ads">Google Ads</option></select></label></p><p>Para Ads: informe o request ID de um upload anterior bem-sucedido com esta conta, ação e credencial. A declaração será registrada; o request ID não possui consulta de confirmação nesta integração.</p><p><label>Request ID <input class="regular-text" name="request_id" maxlength="200"></label></p><p><label><input type="checkbox" name="successful_upload_confirmed"> Conferi o comprovante de upload anterior desta integração</label></p><button class="button">Verificar destino</button></form><p>A homologação deve conferir um contato recente na sessão GA4 e na ação Ads autorizada. Recebimento HTTP e validação não comprovam atribuição analítica.</p></div>';
            });
    }
    private static function hidden(string $id,string $revision): void {
        wp_nonce_field('f3-google-conversions');
        echo '<input type="hidden" name="connection_id" value="'.esc_attr($id).'"><input type="hidden" name="revision" value="'.esc_attr($revision).'">';
    }
}
