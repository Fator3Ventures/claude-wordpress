# Reprodução — Core 1.57.1

Base direta Core 1.57.0 canônica: instalador 2696212 bytes, SHA-256 `5a829a78b3a2265560a88a0dde969fd435fd502ea2072e21ae8f47aeabf13ca6`. Contrato 8.22.1, 164 abilities; WordPress >=7.1.2 e PHP >=8.3.6 de 64 bits. Não usar o candidato paralelo 1.57.0 como base. A árvore final em `work/plugin` já contém todas as alterações; não depende de reaplicar transformações sobre o fonte anterior.

## Laboratório descartável

Forneça `F3BASE_WORDPRESS_CORE` (diretório/ZIP original), `F3BASE_RUNTIME` (árvore PHP/MySQL), `F3BASE_LAB_DB` começando com `core_`, `F3BASE_LAB_DIR` e `F3BASE_EVIDENCE_DIR=evidence/1571`. Execute a partir da raiz do fonte:

```bash
python3 build/setup-lab.py
python3 tests/run-lab.py tests/install.php
```

Não use banco real. O runner inicia MySQL descartável na porta 33436; `F3BASE_MYSQL_DATA` permite escolher outro diretório de dados. Nunca sobreponha runners. Cada suite e ciclo deve usar laboratório/banco próprios; em filesystem sem suporte adequado a InnoDB, use diretório temporário local. A prova desta entrega usou PHP 8.3.6 e MySQL 8.0.46. `build/php` aceita `F3BASE_PHP_BIN`, ou PHP em `F3BASE_RUNTIME/usr/bin/php8.3`; `setup-lab.py` configura extensões da ABI 20230831. Não inclua binários, laboratórios ou bancos nos pacotes.

Copie os acompanhantes originais de `COMPANIONS.md` para os plugins do laboratório. Meta/Google são ativados por `prepare157.php`. Execute sequencialmente:

```bash
python3 tests/run-lab.py tests/prepare157.php tests/request-312-1571.php tests/request-313.php tests/review-1571.php tests/hardening-1571.php tests/permissions-1571.php
python3 tests/run-lab.py tests/activate-mcp1540.php tests/permissions-1571.php tests/docs-1571.php
python3 tests/run-lab.py tests/core-only.php tests/sdk-unavailable-1571.php
```

Esses testes são mutáveis e exclusivos do laboratório descartável. Não execute `core-only.php` no site compartilhado. As evidências de permissões se chamam `permissions-native-1571.json` e `permissions-mcp-1571.json`. Google/Meta são SDKs originais com transporte controlado: os 30 dias GA4 são sintéticos, não certificam uma propriedade real. O teste de Instagram exerce SQL real, falha parcial e retomada com a requisição original. A suite de documentação percorre 136 documentos/630 páginas, com 928 verificações de conteúdo, hash, paginação e autorização; total depende da árvore final. Runners históricos numerados continuam disponíveis como histórico, sem afirmar nova execução nesta rodada.

## Instalação limpa e atualização nativa

Forneça estas variáveis além das do laboratório, usando caminhos absolutos existentes:

```bash
export F3BASE_BASE_VERSION=1.57.0
export F3BASE_BASE_SHA256=5a829a78b3a2265560a88a0dde969fd435fd502ea2072e21ae8f47aeabf13ca6
export F3BASE_TARGET_VERSION=1.57.1
export F3BASE_TARGET_CONTRACT=8.22.1
# F3BASE_BASE_ZIP: instalador canônico 1.57.0 fornecido separadamente
# F3BASE_CANDIDATE: release/base-site-core-fator3-1.57.1-instalador.zip
python3 tests/run-lab.py tests/native-cycles.py
```

O runner exige `F3BASE_BASE_ZIP` e confere seu hash. Usa o ZIP candidato exato, WordPress real, banco/conteúdo separados para `fresh` e `upgrade`, processos novos para cada etapa e `Plugin_Upgrader` na troca. Somente o atraso de confirmação final é acelerado no banco descartável. Semeia fotografia GA4, pendência Instagram cifrada, contatos, configurações e cursores; compara hashes antes/depois, permitindo apenas novos defaults aditivos. Repetir migração deve responder `atual`. Repita com WordPress 7.1.3 e 7.1.2/PHP 8.3.6 em laboratórios independentes. Evidências finais: `evidence/1571/native-cycles-1571.json` e `evidence/1571/min/native-cycles-1571.json`.

## Dependências, contratos e assets

Parser MIME/transitivas preservados, versões em `mime/composer.lock`. Para reconstruir o parser, forneça Composer/PHP-Scoper 0.18.20 por `F3BASE_COMPOSER`/`F3BASE_SCOPER`, instale o Scoper com `scoper-composer.json`/lock isoladamente e execute `python3 build/mime/build.py`. Classes prefixadas; apenas runtime/licenças entram no instalador. Consulte `docs/DEPENDENCIAS-EMAIL-1.53.md`. Não há dependência nova nesta rodada. Terser 5.44.1 está travado em `terser-package.json`/lock; `F3BASE_TERSER` aponta ao binário; `python3 build/assets.py` recompõe JS/hashes se houver alteração de assets.

Geradores `tests/base-1330/gerar-inventario.php` e `gerar-contratos.php` usam `F3BASE_INVENTORY_OUTPUT`/`F3BASE_DOCS_OUTPUT` dirigidos ao runtime. Gere schemas com Core sozinho, antes do fechamento. Schemas/documentação atualizados já estão incluídos nesta árvore; regenerar sem mudanças não é requisito para instalar o ZIP.

## Site-Teste e fechamento

`site-1571-bundle.py` cria controlador temporário limitado ao host/versão, com operações fechadas. `setup` copia Core/SDKs instalados para prefixo SQL aleatório e diretório privado, bloqueando fornecedores. Não copia dados/credenciais do site. `suite` aceita somente a allowlist; `site-read` lê a instalação compartilhada, renderiza configurações, compara opções e hashes. `cleanup` remove as fixtures. Remova também o controlador temporário. Estas operações só se aplicam ao ambiente autorizado, nunca automaticamente a outro site.

O Site-Teste desta rodada concluiu as 17 etapas da atualização, confirmou runtime de 748 arquivos, aprovou home/REST e removeu 89 tabelas de fixture, diretório e controlador. ZIP temporário consumido pelo instalador; leitura posterior comprovou ausência. Metadados de backup privado constam da evidência, sem dump. O instalador remoto usou `plugins/upload-base64` com `zip_path`, após envio multipart e verificação do SHA-256; não houve publicação no repositório/frota.

Feche primeiro o instalador, com `F3BASE_EVIDENCE_DIR=evidence/1571 python3 build/package-installer.py`; o script faz lint de todo PHP e ZIP determinístico. A data fixa interna do instalador permanece 26/10/2026 por continuidade do empacotador, não indica a data de entrega. Não altere runtime após a homologação. A identidade testada está em `evidence/1571/installer.json`.

Prepare `release/base-site-core-fator3-1.57.1-relatorio.md` com a identidade do instalador e marcadores `{{SOURCE_BYTES}}`/`{{SOURCE_SHA256}}`. Execute `python3 build/package-source.py` uma vez: compara os bytes com o instalador, inclui testes/evidências/locks, exclui laboratórios, dumps e ZIPs aninhados, gera fonte e completa o relatório externo. A cópia interna marcada anterior ao fechamento evita hash circular. Para reproduzir depois, copie o relatório interno ao caminho de release e substitua apenas os dois campos da identidade do fonte pelos marcadores; o cabeçalho de cópia interna não faz parte do relatório externo canônico. Reempacotamento posterior é reprodução, não substituição silenciosa da entrega certificada.
