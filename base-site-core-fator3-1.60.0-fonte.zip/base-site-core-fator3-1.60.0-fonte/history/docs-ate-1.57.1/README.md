# Fonte Core 1.57.1

Consolidação solicitada pelo dono entre a versão 1.57.0 canônica instalada e o candidato paralelo 1.57.0 não publicado. Base direta suportada: canônica, instalador SHA-256 `5a829a78b3a2265560a88a0dde969fd435fd502ea2072e21ae8f47aeabf13ca6`. O candidato paralelo não é base de atualização.

Runtime canônico em `work/plugin/base-site-core-fator3`, idêntico byte a byte ao instalador 1.57.1 testado. Contrato administrativo 8.22.1, 164 abilities. Preserva o schema GA4 da instalação e integra as proteções de transação, repetição da exclusão Instagram, validação estrita e continuidade do acervo. Leia `docs/RELEASE-1.57.1.md`, `ACERVO-GA4-1.57.md`, `INSTAGRAM-EXCLUSAO-1.57.md` e `DOCUMENTACAO.md` no runtime.

O plano está em `history/1571/PLANO.md`; bases e instrução da rodada em `inputs/1571`; comparação e provas em `evidence/1571`. Demais diretórios numerados são histórico, não novas homologações. Pedidos core 312/313 e documentos dos acompanhantes estão em `inputs/1570`; as normas canônicas estão instaladas em `docs/NORMA-01-...` e `docs/NORMA-02-...` (revisões 4 e 5).

Reprodução: `build/README.md`. Build: `build/package-installer.py`, seguido, após testes e relatório pré-fechamento, de `build/package-source.py`. A árvore pronta é a entrada do build; scripts transitórios usados para transformar a base durante o desenvolvimento não são necessários nem distribuídos como etapas de reprodução. Os acompanhantes originais são fornecidos separadamente conforme `build/COMPANIONS.md`.

Instalação limpa e atualização nativa 1.57.0 → 1.57.1 passaram em WordPress 7.1.2 e 7.1.3/PHP 8.3.6. Site-Teste atualizado e verificado em WordPress 7.1.3/PHP 8.3.36. SDKs Google/Meta reais com transporte controlado não equivalem à homologação de contas reais. A coleta real GA4 de 30 dias permanece pendente de credencial e concessão do dono.

O relatório externo `base-site-core-fator3-1.57.1-relatorio.md` é canônico. A cópia incluída neste ZIP é anterior ao fechamento do fonte: contém a identidade final do instalador, mas remete ao relatório externo para tamanho/hash deste próprio ZIP, evitando circularidade.
