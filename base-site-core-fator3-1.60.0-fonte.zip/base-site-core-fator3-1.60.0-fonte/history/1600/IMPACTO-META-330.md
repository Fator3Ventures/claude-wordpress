# Encaminhamento técnico — revisão de acesso Core / Meta Ads

Emissor: Core 1.60.0. Destinatário: responsável MCP Meta e frota. Pedido Core 330. Base Meta 0.14.0, meta-ads-reader/1.0.0.

A revisão do consumidor passará a cobrir conexão, conta, ativo e geração de acesso monotônica, separada do mapa editorial de parceiros. A geração muda atomicamente somente em troca de acesso; desligar/religar ou trocar/restaurar conta não revive concessão antiga. O mapa e o parceiro padrão continuam vinculando o cursor Core, sem mudar a concessão.

Consequência de implantação: o hash antigo abrangia toda a configuração. A primeira atualização exige renovar explicitamente a concessão para a nova revisão retornada por f3base/meta-ads-status; não há migração silenciosa de autorização. Após essa reconcessão, alterações somente de parceiros preservam o acesso. Nenhuma mudança de API é exigida do Meta. Frota deve renovar por meta/save-ads-grant na conta escolhida e confirmar pronto. Não criar concessões durante instalação ou teste automático.

Este encaminhamento registra consequência operacional antes da implementação; os resultados e encerramento serão registrados no relatório principal.
