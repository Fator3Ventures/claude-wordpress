# Plano anterior à implementação — Core 1.60.0

Base: fonte/instalador canônicos 1.59.0, imutáveis. Normas 01 e 02 revisão 5 (23/10/2026), lidas integralmente; regra do dono de 28/10 prevalece para credenciais. Entradas: Pedidos Core 322, 330–334; MCP 0.36.0 e Meta 0.14.0. Os aceites de frota já recebidos dos itens 314–321 e 323–329 são histórico concluído, não pendências desta rodada.

- 322: host CRM normalizado somente pelo www inicial; prova SMTP restrita à caixa do próprio site expressamente autorizada para homologação, sem Cco/Smart Bcc; recebimento e exclusão por identidade exata via IMAP UIDPLUS, sem EXPUNGE geral; recibo informa a configuração de supressão Slack. Nenhuma chamada Pipedrive real no Site-Teste.
- 330: padrão de parceiro por conta; geração de acesso monotônica armazenada junto da seleção e derivada pelo Core nas gravações CAS. Mapa/contador editorial não alteram concessão. Cursores continuam vinculados a toda a configuração de relatório. Mudança de formato de revisão requer reconcessão única na implantação.
- 331: superfícies opcionais e motivo por ocorrência, sem ampliar implicitamente caminhos ou permissões de texto visível.
- 332: contagem diária limitada, separação de automação e renovação aceita vinculada por recibo assinado à rejeição e lote. Não guardar token, IP ou dados pessoais no diagnóstico.
- 333: redirecionar para URL canônica construída de home_url antes do cookie.
- 334: padrões viram avisos; limites de segurança antes de aparar; fornecedor decide credenciais verificáveis. Preservar cifra, revisão, identidade e segredo salvo em falha. URLs mantêm validação própria.

Contrato administrativo aditivo 8.24.0. Mínimos preservados, sem mudanças nos acompanhantes. Testes com WordPress real: instalação limpa, atualização 1.59→1.60, repetição, preservação, regressões afetadas, SDK Meta 0.14 e MCP 0.36. Exercitar transporte IMAP/SMTP sintético em laboratório isolado e publicar a limitação de homologação real. Instalar candidato exato no Site-Teste autorizado, conferir ciclo e documentação pelo MCP. Fonte inclui teste/build/evidência sanitizada, nunca credenciais ou laboratório. Fechar instalador, relatório pré-fechamento, fonte e hash externo nessa ordem.
