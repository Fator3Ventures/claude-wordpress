# Plano — Core 1.57.1

Rodada de correção/consolidação solicitada pelo dono em 27/10/2026. Patch explícito, excepcional à regra minor. Base suportada: 1.57.0 canônica, instalador SHA-256 `5a829a78b3a2265560a88a0dde969fd435fd502ea2072e21ae8f47aeabf13ca6`; candidato paralelo não publicado: `a7781197c291f50a859475a8e91f58bac3d6f87e8277400935c53cd34deaa4ab`. Alvo ainda não empacotado. Instruções comuns rev.4 e padrão rev.5.

## Decisões da comparação

Preservar da base instalada: tabelas e colunas GA4, estado `f3base_ga4_estado`, sete recortes (inclusive resumo), fuso e seleção de recortes, cursores cifrados, atualização atômica, exportação base64 com hash, períodos explícitos de comparação, permissões, inventário e dados já gravados. Não importar o schema incompatível do candidato paralelo.

Adaptar do candidato: barreira de autocommit antes da eliminação Instagram; requisição Meta cifrada e estável entre tentativas; conferência do contrato e estado final; validação estrita do envelope GA4 e métricas numéricas; verificação do schema; início efetivo durável quando `inicio` está vazio; retenção respeitada na seleção automática; reconciliação recente/limite de página configuráveis com defaults da base; alternância entre histórico e dados recentes; recuperação protegida; paginação de qualidade para volumes grandes e revisão carregada na navegação.

Não importar: cursor GA4 em claro, teto arbitrário de dez anos, mudança dos nomes públicos, substituição das colunas de dados, supressão de fuso/recortes, ou mudança de defaults que ative coleta. Não exigir operador adicional ao grant público Google já existente.

## Fronteiras

MCP 0.33.0, Google 0.20.0, Meta 0.12.0, LinkedIn 0.11.0 e Pipedrive 0.2.0. Contratos Google `ga4-reader/1.0.0` e Meta `instagram-message-erasure/1.0.0` preservados. As alterações são internas ao consumidor Core, sem pedido de implementação nos acompanhantes; nenhum impacto individual identificado no planejamento. Reavaliar se surgir exigência concreta.

## Verificação prevista

Comparação de hashes dos anexos/instalação; regressões dos pedidos 312/313; falhas e retomada, transação externa, permissões, documentação completa; instalação limpa e atualização nativa 1.57.0 → 1.57.1 em WordPress descartável; verificação no Site-Teste em operação única com backup e pré-condição de versão/hash. Nenhuma concessão real, coleta GA4, envio comercial ou publicação na frota. Fornecedor real permanece pendente sem credenciais autorizadas.
