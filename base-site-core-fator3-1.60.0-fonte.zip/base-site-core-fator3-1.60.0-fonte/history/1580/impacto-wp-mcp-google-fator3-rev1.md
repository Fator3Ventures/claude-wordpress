# Core 1.58.0 → Fator3 MCP Google

Revisão 1 · 28/10/2026 · planejamento · demanda-aberta.
Base Core 1.57.1, SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`; alvo 1.58.0 previsto, instalador ainda não gerado. Destinatário observado: Google 0.20.0. Natureza: contrato. Classificação: ação-necessária. Pedidos core 316, 321, 323, 324; Pedidos MCP Google 39/40.

O contrato `site-conversion-delivery/1.0.0` instalado não admite user_data nem a seleção de ações comerciais por etapa; só o destino vinculado anunciado. O Core mantém esse caminho e não encaminha dados fora do contrato. Para 316, entregar e documentar 1.1.0, formato exato de user_data, normalização/hashing, anúncio local de capacidades/prontidão por conta/ação, elegibilidade sem click ID, consentimento e preview seguro. Para 323, anunciar seleção/binding por ação de etapa, com identidade estável e recibo; nunca mudar silenciosamente a ação de contato já vinculada.

Para 321/324, fornecer consulta pública local de estado/código, vencimento conhecido e referência à rota detalhada, sem introspecção remota nem segredo. Não exigir leitura de opções privadas. A expiração desconhecida deve ser null com motivo, nunca zero ou validade presumida.

Responsável: mantenedor Google; aceite com schema/fixture públicos, rejeição de contrato antigo sem vazamento, revogação, alteração de destino, ausência de consentimento e resultado incerto sem reenvio. Instalar Google compatível antes de habilitar recursos novos no Core. A implementação Core independente continua; homologação Ads real depende do dono/conta. Documento preparado, não enviado. Respostas/atendimento serão registrados no relatório principal conforme norma canônica revisão 5.
