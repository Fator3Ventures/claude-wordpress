# Core 1.58.0 → Fator3 MCP LinkedIn

Revisão 1 · 28/10/2026 · planejamento · demanda-aberta.
Base Core 1.57.1, SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`; alvo 1.58.0 previsto, instalador ainda não gerado. Destinatário observado: LinkedIn 0.11.0. Natureza: contrato. Classificação: ação-necessária. Pedidos core 321, 323, 324.

O adaptador publicado `site-conversion-delivery/1.0.0` anuncia uma única regra de contato vinculada. O pedido 323 exige ações distintas por etapa comercial. É necessário contrato público para capacidades/binding por regra, payload de evento comercial (event_id estável e instante), recibo e reconciliação; não reaproveitar a regra de contato nem alterar concessão silenciosamente. Exigir rw_conversions, regra CONVERSIONS_API e autorização atual da conta.

Para 321/324, expor estado/código e vencimento conhecido de cada credencial por leitura local pública, sem consultar fornecedor ou acessar armazenamento privado. Core continuará lendo capabilities() vigente e mostrará indisponibilidade explícita para detalhes não publicados.

Responsável: mantenedor LinkedIn; fornecer contrato/schema e fixtures de regras distintas, revogação, mudança de binding, permissão e resultado incerto. Homologação da primeira etapa real depende do dono/ativo. Implementação local Core prossegue; emissão remota nova fica condicionada ao contrato compatível. Documento preparado, não enviado. Resposta/atendimento no relatório principal, sem reemitir impacto só para encerramento.
