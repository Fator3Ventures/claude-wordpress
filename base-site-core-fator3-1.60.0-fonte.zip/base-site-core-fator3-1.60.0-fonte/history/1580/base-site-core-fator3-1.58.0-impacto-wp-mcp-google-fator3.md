# Impacto de Fator3 Site Core 1.58.0 em Fator3 MCP Google

28/10/2026 · America/Sao_Paulo · Revisão 2 · Etapa implementação · Situação demanda-aberta.  
Emissor: `base-site-core-fator3`, base 1.57.1, alvo 1.58.0; instalador gerado e validado localmente: 2816484 bytes, SHA-256 `71bf6497a2f2e2c605baf64f0f82c273201915039506b58ac220fc572afbd5e4`. Instalador-base: SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`.  
Destinatário: `wp-mcp-google-fator3` 0.21.0, instalador 836718 bytes, SHA-256 `25da9ef78e303f30ce2f73b8f98743a26e09b8ed238177474e4a956578a63814`.  
Natureza: evolução opcional do contrato de conversões por ação e finalidade. Classificação: **acao-necessaria**. Referência: **Pedidos Core 323**. Não foi criado número de pedido Google.

## Mudança e consequência

O Core passa a configurar ações exclusivas para etapas comerciais em `f3base_qualidade_destinos.google_ads.acoes`, separadas da ação de aquisição. Google 0.21.0 anuncia os contratos de aquisição `site-conversion-delivery/1.0.0` e `1.1.0`, com um destino vinculado. Eles não autorizam o Core a selecionar ações comerciais adicionais. Sem capacidade específica, a prévia e o recibo Core informam `adaptador_etapas_nao_suportado` e não enviam a conversão.

É necessário um contrato opcional **`site-conversion-delivery/1.2.0`**, com seleção, concessão e referência vinculada por ação comercial. O consumidor proposto já diferencia aquisição e etapa; a implementação do produtor permanece sob o mantenedor Google. A ausência do novo contrato bloqueia somente o retorno comercial ao Google Ads.

## Pedido ao mantenedor Google

1. Anunciar 1.2.0 em `supported_contracts` do adaptador de aquisição, preservando os contratos existentes. Atender a nova seleção pelo filtro `f3base_conversoes_adaptador`, destino `google_ads`, contrato 1.2.0 e contexto `{"consumer_id":"site-core-quality","purpose":"crm_stage","action":"customers/1234567890/conversionActions/222"}`. O filtro precisa receber o quarto argumento; a inscrição atual de `ConversionDelivery` usa três. Os números do exemplo são sintéticos.
2. Expor `capabilities()` inteiramente local e `sendBound(payload,destination_ref)`. A concessão deve contemplar consumidor, finalidade, conta e ação selecionada. Não deduzir autorização comercial de uma concessão de aquisição nem trocar a ação de contato para atender ao pedido.
3. Publicar `acquisition_action` explicitamente: recurso completo da ação de aquisição, ou `null` quando o produtor comprovar que nenhuma está configurada. Campo omitido, string vazia ou tipo inválido não comprovam ausência. Quando `enhanced_leads.conversion_action` do adaptador de aquisição está disponível, as duas identidades devem coincidir.
4. Publicar a ação comercial exata em `actions[action]`, com `purpose:"crm_stage"`, `ready`, motivo de bloqueio e `destination_ref` própria. A referência deve vincular conta, ação, identidade e geração de autorização/concessão. Revalidá-la antes do efeito: revogação, mudança de identidade, conta ou ação impede o envio, sem selecionar uma alternativa.
5. Aceitar os campos comuns e a extensão Google descritos abaixo, mantendo normalização, hashing, escolha de transporte, quotas e prova remota sob responsabilidade do produtor. Documentar o schema fechado, os limites e os códigos do retorno. Não persistir dados pessoais brutos em diagnóstico ou recibo.

Capabilities mínimas propostas:

```json
{
  "contract": "site-conversion-delivery/1.2.0",
  "supported_contracts": ["site-conversion-delivery/1.2.0"],
  "purposes": ["crm_stage"],
  "ready": true,
  "acquisition_action": "customers/1234567890/conversionActions/111",
  "actions": {
    "customers/1234567890/conversionActions/222": {
      "action": "customers/1234567890/conversionActions/222",
      "purpose": "crm_stage",
      "ready": true,
      "destination_ref": "referencia-opaca-do-produtor"
    }
  }
}
```

O Core bloqueia reutilização da aquisição com `acao_comercial_reutiliza_contato`, falta de prova com `acao_aquisicao_nao_comprovada` e divergência de identidade com `acao_aquisicao_divergente`. Cada etapa usa ação exclusiva nesse destino; o mapa é local e explícito, por ID de etapa, sem inferência por nome de campanha ou estágio do fornecedor.

## Payload, recibo e resultado incerto

Campos comuns: `contract`, `purpose:"crm_stage"`, `record_id`, `stage_id`, `action`, `event_id` estável por site/contato/etapa/destino e `occurred_at` RFC3339 da mudança comercial. A extensão Google contém `click_ids`, `order_id` igual ao `event_id`, `ad_user_data:"GRANTED"`, `value:0`, `currency:"BRL"` e, quando elegível, `user_data`. Valor monetário real do negócio não é parte desta proposta de retorno por etapa.

A capacidade `actions[action].enhanced_leads`, quando anunciada, deve usar o formato de prova 1.1.0 para a **mesma ação comercial**, com conta, ação, termos, habilitação e validade correntes. Sem clique, o Core exige essa prontidão e e-mail/telefone normalizados disponíveis. Com clique, mantém a elegibilidade do identificador e não inventa dado pessoal. O produtor recebe os identificadores somente no envio autorizado; prévias Core apresentam tipos/hashes e não enviam.

`sendBound` retorna `status:"entregue"|"recusado"|"incerto"`, `code` sanitizado e `http` opcional. `entregue` exige confirmação do fornecedor. `recusado` exige `non_delivery_proven:true`; exceção, resposta desconhecida ou ausência de prova de não entrega resultam em `incerto`. O Core reserva o recibo antes da chamada e não repete automaticamente resultados incertos. Repetição/deduplicação no produtor deve preservar a identidade da ação/evento. Eventual reconciliação precisa de contrato público próprio antes de ser consumida; a versão 1.2 proposta não autoriza reenviar para tentar descobrir o resultado.

## Compatibilidade, responsabilidade e aceite

Google pode manter 1.0.0 e 1.1.0 enquanto implementa a capacidade adicional. Core 1.58.0 pode ser instalado antes dela, com retorno comercial desligado por padrão e bloqueio explícito quando selecionado sem contrato. Somente habilitar a ação comercial depois de configuração, concessão e prova do destino. A instalação não ativa anúncios nem amplia permissões automaticamente.

Responsável pelo adaptador e prova Google: mantenedor `wp-mcp-google-fator3`. Responsável por mapa de etapas, consentimento, filas, recibos e prévias: mantenedor Core. Homologação real: operador/dono, com conta/ação autorizadas.

Aceite coordenado: contrato legado preservado; ações distintas por etapa; aquisição explícita ou ausência comprovada por `null`; recusa por aquisição igual/omitida/divergente; ausência de consentimento; ação/concessão/identidade alterada entre reserva e envio; payload com clique e sem clique elegível; resultado incerto sem reenvio; deduplicação por evento/ação; prévia sem fila nem HTTP. Usar o consumidor Core real e o produtor Google real com HTTP sintético antes do primeiro envio comercial autorizado. O contrato completo do consumidor está em `docs/QUALIDADE-DESTINOS-1.58.md` e `includes/class-f3base-qualidade-destinos.php` no fonte Core.

## Evolução substantiva desta revisão

A revisão 1 de planejamento foi preservada em `history/1580/impacto-wp-mcp-google-fator3-rev1.md`. Esta revisão especifica a negociação 1.2.0, o quarto argumento do filtro, consumidor/finalidade próprios, `acquisition_action`, capabilities por ação, vínculo, payload e semântica de incerteza. Sua base examinada passa a Google 0.21.0. Respostas, comprovações de atendimento e desfechos dos pedidos anteriores pertencem ao relatório principal, conforme NORMA-02 revisão 5. Documento preparado para encaminhamento, sem envio externo.
