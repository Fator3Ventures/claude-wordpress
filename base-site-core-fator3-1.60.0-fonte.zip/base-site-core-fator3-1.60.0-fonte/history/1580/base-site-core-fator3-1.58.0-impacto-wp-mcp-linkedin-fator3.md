# Impacto de Fator3 Site Core 1.58.0 em Fator3 MCP LinkedIn

28/10/2026 · America/Sao_Paulo · Revisão 2 · Etapa implementação · Situação demanda-aberta.  
Emissor: `base-site-core-fator3`, base 1.57.1, alvo 1.58.0; instalador gerado e validado localmente: 2816484 bytes, SHA-256 `71bf6497a2f2e2c605baf64f0f82c273201915039506b58ac220fc572afbd5e4`. Instalador-base: SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`.  
Destinatário: `wp-mcp-linkedin-fator3` 0.11.0, instalador 283053 bytes, SHA-256 `34541afa67c0991e9dc0b5474ab8678dff8cf806eace6ceb1edb47983f9e0308`.  
Natureza: evolução opcional do contrato de conversões por ação e finalidade. Classificação: **acao-necessaria**. Referência: **Pedidos Core 323**. Não foi criado número de pedido LinkedIn.

## Mudança e consequência

O Core passa a configurar ações exclusivas para etapas comerciais em `f3base_qualidade_destinos.linkedin.acoes`, separadas da ação de aquisição. LinkedIn 0.11.0 fornece `site-conversion-delivery/1.0.0` para o consumidor `site-core-conversions`, com uma regra vinculada. Esse contrato não autoriza selecionar regras comerciais adicionais. Sem capacidade específica, a prévia e o recibo Core informam `adaptador_etapas_nao_suportado` e não enviam.

É necessário o contrato opcional **`site-conversion-delivery/1.2.0`**, com seleção, concessão e referência vinculada por ação comercial. O consumidor proposto diferencia aquisição e etapa; a implementação do produtor permanece sob o mantenedor LinkedIn. A ausência do novo contrato bloqueia somente o retorno comercial ao LinkedIn.

## Pedido ao mantenedor LinkedIn

1. Anunciar 1.2.0 em `supported_contracts` do adaptador de aquisição, preservando 1.0.0. Atender a seleção pelo filtro público `f3base_conversoes_adaptador`, destino `linkedin`, contrato 1.2.0 e contexto `{"consumer_id":"site-core-quality","purpose":"crm_stage","action":"222"}`. `222` é um ID sintético. O consumidor e a finalidade precisam ser reconhecidos explicitamente; a base atual só seleciona `site-core-conversions` no contrato 1.0.0.
2. Expor `capabilities()` local e `sendBound(payload,destination_ref)`. A concessão deve contemplar finalidade, consumidor, conta e ação comercial, sem ampliar a autorização de aquisição por inferência. Conservar escopos `rw_conversions` e `r_ads`, prova da regra para Conversions API e autorização atual da conta.
3. Publicar a ação exata em `actions[action]`, com `purpose:"crm_stage"`, `ready`, motivo de bloqueio e referência opaca própria. Vincular essa referência à conta, regra, identidade e geração da concessão/autorização. `sendBound` precisa revalidá-la antes do efeito; mudança de conta/regra, revogação ou troca de identidade deve bloquear, sem escolher destino alternativo.
4. Aceitar o payload comercial abaixo, documentar schema fechado, limites e códigos de retorno, preservando a identidade do evento para deduplicação e o resultado incerto. Não incluir e-mail bruto, credencial ou conteúdo do contato em diagnóstico/recibo.

Capabilities mínimas propostas:

```json
{
  "contract": "site-conversion-delivery/1.2.0",
  "supported_contracts": ["site-conversion-delivery/1.2.0"],
  "purposes": ["crm_stage"],
  "ready": true,
  "actions": {
    "222": {
      "action": "222",
      "purpose": "crm_stage",
      "ready": true,
      "destination_ref": "referencia-opaca-do-produtor"
    }
  }
}
```

O Core valida que o ID comercial é distinto de `f3base_linkedin_server_conversion_id` e que cada etapa tem ação exclusiva nesse destino. A prontidão do produtor precisa provar a regra solicitada, não reutilizar a prova de outra regra. A seleção se faz por ID de etapa e regra; nomes de campanha ou estágio não concedem nem identificam a ação.

## Payload, recibo e resultado incerto

Campos comuns: `contract`, `purpose:"crm_stage"`, `record_id`, `stage_id`, `action`, `event_id` estável por site/contato/etapa/destino e `occurred_at` RFC3339 da mudança comercial. A extensão LinkedIn contém `eventId` igual ao `event_id`, `conversion:"urn:lla:llaPartnerConversion:<action>"`, `conversionHappenedAt` em milissegundos e `user.userIds` com `SHA256_EMAIL` e/ou `LINKEDIN_FIRST_PARTY_ADS_TRACKING_UUID`, conforme os identificadores disponíveis e consentidos. O Core não envia etapa sem identificador elegível.

O contato precisa ser aceito, ativo, real e permitir publicidade na captura e atualmente. Testes, homologação, audiência excluída e entrada por e-mail são suprimidos. O instante da etapa deve ser posterior ou igual à captura, não estar no futuro e permanecer na janela de sete dias do consumidor. A transação do evento comercial reserva o recibo por contato/etapa/destino; voltar à mesma etapa não cria outra conversão.

`sendBound` retorna `status:"entregue"|"recusado"|"incerto"`, `code` sanitizado e `http` opcional. `entregue` exige confirmação do fornecedor. `recusado` exige `non_delivery_proven:true`. Exceção, resposta desconhecida ou ausência de prova de não entrega resultam em `incerto`. O Core registra a tentativa antes do efeito e não repete automaticamente resultado incerto. O produtor deve manter a identidade evento/ação nas proteções de repetição; eventual reconciliação exige contrato público próprio antes de seu consumo, sem reenvio para sondar o resultado.

## Compatibilidade, responsabilidade e aceite

Manter 1.0.0 e sua concessão enquanto a capacidade 1.2.0 é implementada. Core 1.58.0 pode ser instalado antes dela: retorno comercial fica desligado por padrão e apresenta bloqueio explícito se configurado sem produtor compatível. Habilitar exige configuração, concessão e prova da ação comercial. A instalação não ativa anúncios nem altera a ação de aquisição.

Responsável por adaptador, concessão e prova LinkedIn: mantenedor `wp-mcp-linkedin-fator3`. Responsável por etapas, consentimento, filas, recibos e prévias: mantenedor Core. Homologação real: operador/dono, com conta/regra autorizadas.

Aceite coordenado: compatibilidade 1.0.0; consumidor/finalidade reconhecidos; duas etapas com duas regras comerciais; recusa de reutilização da ação de aquisição; conta, regra, escopo, concessão e identidade divergentes; alteração de referência entre reserva e envio; ausência de consentimento/identificador; janela da etapa; resultado incerto sem reenvio; deduplicação por evento/regra; prévia sem fila nem HTTP. Exercitar o consumidor Core real e o produtor LinkedIn real com HTTP sintético antes do primeiro evento comercial autorizado. O contrato completo do consumidor está em `docs/QUALIDADE-DESTINOS-1.58.md` e `includes/class-f3base-qualidade-destinos.php` no fonte Core.

## Evolução substantiva desta revisão

A revisão 1 de planejamento foi preservada em `history/1580/impacto-wp-mcp-linkedin-fator3-rev1.md`. Esta revisão especifica negociação 1.2.0, consumidor/finalidade próprios, capabilities por ação, referência vinculada, campos do payload e semântica de incerteza. Respostas, comprovações de atendimento e desfechos dos pedidos anteriores pertencem ao relatório principal, conforme NORMA-02 revisão 5. Documento preparado para encaminhamento, sem envio externo.
