# Acompanhantes considerados — Core 1.58.0

Os runtimes originais são fornecidos separadamente; não são republicados no fonte Core. O instalador Core permanece autônomo. A tabela descreve a fronteira a reproduzir, não uma homologação universal de cada pacote.

| Pacote | Versão corrente examinada | Fronteira pertinente |
| --- | --- | --- |
| wp-mcp-fator3 | 0.34.0 | Autorização/registro/documentação; diagnóstico compacto, upload idempotente e sonda served. |
| wp-mcp-google-fator3 | 0.21.0 | Adaptador 1.1.0 de conversões otimizadas, status local e SDK GA4 preservado. |
| wp-mcp-meta-fator3 | 0.13.0 | SDK local Meta Ads, saúde parcial e contratos Instagram preservados. |
| wp-mcp-linkedin-fator3 | 0.11.0 | Status/escopos/validades, adaptador de contato e Lead Sync. |
| wp-mcp-pipedrive-fator3 | 0.3.0 | Cliente Core 1.0.0 preservado e operação agregada de relatórios. |

| Instalador | Bytes | SHA-256 |
| --- | ---: | --- |
| wp-mcp-fator3-0.34.0-instalador.zip | 903878 | `5d96b6a33cfc4a7c729c106268f4bc9d8938b34384da022345d7b7dae611a295` |
| wp-mcp-google-fator3-0.21.0-instalador.zip | 836718 | `25da9ef78e303f30ce2f73b8f98743a26e09b8ed238177474e4a956578a63814` |
| wp-mcp-meta-fator3-0.13.0-instalador.zip | 284069 | `3ecd6ee6f277c7581adc05b4fa38c46611e3232b4400bb4a4421956c9fba8ac1` |
| wp-mcp-linkedin-fator3-0.11.0-instalador.zip | 283053 | `34541afa67c0991e9dc0b5474ab8678dff8cf806eace6ceb1edb47983f9e0308` |
| wp-mcp-pipedrive-fator3-0.3.0-instalador.zip | 59877 | `30fc784a552a89351900c169fad7300759163fb886b842f45ba807bb0977f657` |

Alguns anexos receberam sufixos locais `(1)` na importação; isso não muda o conteúdo ou a identidade publicada. Nomes recebidos e hashes dos fontes estão nos manifests de `inputs/1580`. Comparação própria em `evidence/1580/companion-package-comparison.json`: runtime Google/Meta/Pipedrive igual ao plugin do fonte; MCP acrescenta índices de silêncio gerados pelo build. Diferenças de diretórios de laboratório antigos não devem ser apresentadas como diff entre instaladores.

Forneça os instaladores originais ao laboratório e ative pelo `activate-companions1580.php`. Pipedrive 0.3 requer PHP 8.3.36: não ativar no piso Core 8.3.6. Seus contratos/relatório podem ser examinados sem fingir prova nativa nesse runtime. O Site-Teste com PHP 8.3.36 permite a convivência correspondente; o relatório principal delimita o que foi exercitado.

Google 0.21 deve preceder a habilitação de conversões otimizadas 316. Não há envio comercial por etapa nos atuais Google/LinkedIn: contrato 1.2 proposto pelo Core, pendente dos mantenedores. Meta Ads exige seleção Core e concessão administrativa Meta explícitas, sem Graph na leitura. Nenhum acompanhante é modificado pelo build Core.

Testes usam dados sintéticos e transportes controlados. Não incluir credenciais, grants reais, logs brutos ou dados de clientes. Validação de conta real, Ads Manager e DMARC fica separada das fixtures/contratos. Relatórios recebidos são provas do emissor e não devem ser somados aos checks próprios do Core.
