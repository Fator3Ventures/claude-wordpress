# Documentação vigente — Core 1.58.0

Contrato administrativo 8.23.0. Base direta canônica 1.57.1. Pedidos core 314–329 e consumidor Meta 20(e) em RELEASE-1.58.0.md. A documentação descreve comportamento; resultados, arquivos certificados e pendências estão no relatório externo. Nomes antigos de guias indicam a origem de contratos ainda vigentes.

| Necessidade | Documento |
| --- | --- |
| Release e instruções para agentes | RELEASE-1.58.0.md, AGENTES-1.58.0.md |
| Operação curta, prontidão, marcas, SMTP, avisos e edição por caminho | OPERACAO-1.58.md |
| Identidade, WhatsApp, resposta e desfechos | CONTATOS-COMERCIAL-1.58.md |
| Abandono, revisão de formulário e relatório | FORMULARIOS-ABANDONO-1.58.md |
| Google 1.1 e prévias de conversão | CONVERSOES-1.58.md |
| Contrato comercial proposto 1.2 e bloqueios atuais | QUALIDADE-DESTINOS-1.58.md |
| Teste sob demanda e limpeza | CAMINHO-LEAD-1.58.md |
| Consumidor do acervo Meta Ads | META-ADS-CORE-1.58.md |
| Especificação e uso | INSTRUCOES-DO-PLUGIN.md, README.md, LEADS-E-FORMULARIOS.md |
| Configuração e ajuda por campo | CONFIGURACAO.md, AJUDA-OPCOES.md, dados/configuracao-schema.json |
| Contratos e schemas executáveis | CONTRACTS.md, dados/abilities-*.json, dados/contrato.json, schemas/*.json |
| Operação e recuperação | OPERACAO-E-RECUPERACAO.md, CRON-DIAGNOSTICO-1.31.md |
| Contatos externos e atribuição manual | CONTATOS-EXTERNOS-1.54.md |
| Sessões, IMAP e provas cron | OPERACAO-1.55.md |
| Acervo GA4 e exclusão Instagram | ACERVO-GA4-1.57.md, INSTAGRAM-EXCLUSAO-1.57.md |
| Conversas WhatsApp e Instagram | CONVERSAS-1.56.md |
| Correio por site e dependências | EMAIL-SITE-1.53.md, DEPENDENCIAS-EMAIL-1.53.md |
| Iscas e política de avisos | FORMULARIOS-SINAIS-1.53.md |
| Credenciais | CREDENCIAIS-1.51.md |
| Pipedrive | PIPEDRIVE.md, PIPEDRIVE-1.37.md, PIPEDRIVE-OPERACAO.md, ORCAMENTO-PIPEDRIVE.md |
| Meta e LinkedIn | META-ACESSO-1.28.md, META-TRANSPORTE-1.19.md, LINKEDIN-LEAD-SYNC.md |
| Dados, retenção e consentimento | DICIONARIO-DADOS.md, RETENCAO-1.45.md, FORMULARIOS-TENTATIVAS-1.44.md |
| Base preservada e histórico | RELEASE-1.57.1.md, AGENTES-1.57.1.md, history/RELEASE-*.md |
| Normas da manutenção | NORMA-01-instrucoes-agentes-plugins-fator3.md, NORMA-02-padrao-desenvolvimento-plugins-fator3.md |
| Provas e limitações | VALIDACAO.md e relatório externo da entrega |

`f3base/documentacao-ler` sem argumentos fornece a lista exata instalada. Leia cada arquivo com `arquivo`, `linha` e `limite` (até 200), continuando em `proxima_linha`; confira SHA-256 e versão. O índice inclui os demais guias vigentes, schemas e histórico disponível. Leitura documental não faz HTTP, grava configuração ou repara cron.

As notas 1.58 prevalecem nas funcionalidades que ampliam. GA4/Instagram conservam os contratos e proteções da 1.57.1. O envio comercial Google/LinkedIn do 323 segue bloqueado pelos adaptadores atuais, e o teste 322 conserva limites de limpeza explícitos; a existência de guia ou ability não é homologação de fornecedor.
