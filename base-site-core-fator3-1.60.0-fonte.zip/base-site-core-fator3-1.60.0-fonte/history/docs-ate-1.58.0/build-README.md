# Reprodução — Core 1.58.0

Base direta Core 1.57.1 canônica: instalador 2707842 bytes, SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`. Contrato 8.23.0; WordPress>=7.1.2 e PHP>=8.3.6 de 64 bits. A árvore em `work/plugin` é a entrada completa do build; não reaplicar transformações históricas.

## Laboratório descartável

Forneça `F3BASE_WORDPRESS_CORE` (diretório/ZIP original), `F3BASE_RUNTIME` (árvore PHP/MySQL), `F3BASE_LAB_DB` começando com `core_`, `F3BASE_LAB_DIR` e `F3BASE_EVIDENCE_DIR=evidence/1580`. Execute a partir da raiz do fonte:

```bash
python3 build/setup-lab.py
python3 tests/run-lab.py tests/install.php
```

Nunca use banco real. O runner inicia MySQL privado na porta 33436; `F3BASE_MYSQL_DATA` escolhe o diretório de dados. Não sobreponha runners; instalações/ciclos precisam de bancos/diretórios descartáveis próprios. `build/php` aceita `F3BASE_PHP_BIN` ou PHP em `F3BASE_RUNTIME/usr/bin/php8.3`; a configuração de extensões precisa corresponder ao runtime. Não distribuir laboratórios, credenciais ou binários no fonte.

Copie os acompanhantes imutáveis de COMPANIONS.md para o diretório plugins do laboratório. A prova sem acompanhantes e a prova de coexistência são processos distintos. O ativador desta rodada inclui MCP, Google, LinkedIn e Meta, e exclui Pipedrive no PHP 8.3.6 por seu mínimo 8.3.36.

As suites abaixo são mutáveis e exclusivas de laboratório. Consulte o relatório/evidências para saber quais foram executadas no snapshot final; sua presença no fonte não é resultado aprovado:

```bash
python3 tests/run-lab.py tests/request-314-317-328-329.php tests/request-315-318-319.php tests/request-316.php tests/request-320.php tests/request-321-324.php tests/request-323.php tests/request-325.php tests/request-326.php
python3 tests/run-lab.py tests/request-317.php tests/review-315-320.php tests/review-328-329.php tests/request-322.php tests/request-322-remotes.php
python3 tests/run-lab.py tests/activate-companions1580.php
python3 tests/run-lab.py tests/request-316-real.php tests/companions-321-324.php tests/request-321-no-http.php tests/meta-ads-0130.php
```

Algumas suites dependem de estado Core sem acompanhantes ou setup específico; siga os cabeçalhos dos testes. `core-only-mode1580.php` é exclusivo do laboratório. Não desative pacotes do site compartilhado para reproduzir um teste local. Scripts históricos permanecem disponíveis, sem afirmação de nova execução.

Para SMTP 327, `python3 tests/run-327.py` usa uma entrada `/etc/hosts` temporária de fixture, removida em `finally`; requer ambiente descartável com essa permissão. O SMTP é substituído pelo teste e nenhum socket real é aberto para o domínio. Não alterar DNS real. Para DOM 317, execute primeiro a suite PHP que renderiza o formulário, depois `F3_JSDOM=<caminho-jsdom> node tests/request-317-dom.cjs <html-renderizado>`. jsdom 27.4.0 e Terser 5.44.1 estão travados nos respectivos manifests/locks; não distribuir node_modules.

## Instalação limpa e atualização nativa

Forneça caminhos absolutos existentes e as identidades corretas:

```bash
export F3BASE_BASE_VERSION=1.57.1
export F3BASE_BASE_SHA256=ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62
export F3BASE_TARGET_VERSION=1.58.0
export F3BASE_TARGET_CONTRACT=8.23.0
# F3BASE_BASE_ZIP: instalador canônico1.57.1 fornecido separadamente
# F3BASE_CANDIDATE: release/base-site-core-fator3-1.58.0-instalador.zip
python3 tests/run-lab.py tests/native-cycles.py
```

O ciclo confere a base e usa o candidato exato, WordPress real, bancos/conteúdo separados, processos novos e `Plugin_Upgrader`. Preservação de opções/dados e retomada precisam de evidência; não deduzir sucesso do lint. Execute as combinações de WordPress/PHP declaradas e registre diferenças de ambiente, extensões e limites. O atraso de confirmação pode ser acelerado somente no banco descartável do harness.

## Contratos e assets

Parser MIME/transitivas seguem `mime/composer.lock`. Para reconstruir, forneça Composer/PHP-Scoper 0.18.20 por `F3BASE_COMPOSER`/`F3BASE_SCOPER`, instale o lock do Scoper isoladamente e execute `python3 build/mime/build.py`. Apenas runtime prefixado/licenças entram no instalador. Veja DEPENDENCIAS-EMAIL-1.53.md.

`python3 build/assets.py` recompõe JS/hashes usando Terser 5.44.1; `F3BASE_TERSER` pode apontar ao binário. Geradores `tests/base-1330/gerar-inventario.php` e `gerar-contratos.php` aceitam `F3BASE_INVENTORY_OUTPUT`/`F3BASE_DOCS_OUTPUT`. Gerar com Core sozinho, sem dados privados, antes do fechamento; os arquivos resultantes acompanham a árvore final. Não gerar contracts a partir de instalação em recuperação e tratá-los como catálogo completo.

## Site-Teste e fechamento

Instalação remota exige o instalador final e contexto autorizado. MCP 0.34 acrescenta `expected_sha256` e chave idempotente; descubra o schema corrente da operação antes de usar. Preserve pré-imagem e recibo. Repetição da mesma intenção consulta a operação; falha consumindo a chave exige nova tentativa deliberada, não troca automática da chave para contornar incerteza. Não criar ZIPs de fonte em pasta pública para inspeção.

Após upload, confira versão/atividade, home/REST, recuperação, confirmação no executor, provas automáticas 326 e documentação instalada integral. Sonda `served` e `bypass` medem comportamentos distintos; prova interna não é certificação de todos os caches externos. Controladores e fixtures temporários precisam de allowlist, isolamento e limpeza; não copiar credenciais ou dados de produção. Pipedrive real só nos sites autorizados pelo dono, fora da instalação Site-Teste desta entrega.

Feche o instalador primeiro:

```bash
F3BASE_EVIDENCE_DIR=evidence/1580 python3 build/package-installer.py
```

O script faz lint de todo PHP e ZIP determinístico com timestamp interno 28/10/2026. `evidence/1580/installer.json` identifica os bytes. Não alterar runtime depois de validar o ZIP; qualquer correção exige novo build e repetir provas afetadas.

Prepare `release/base-site-core-fator3-1.58.0-relatorio.md` com a identidade final do instalador e marcadores `{{SOURCE_BYTES}}`/`{{SOURCE_SHA256}}`. Após consolidar testes e pendências, execute `python3 build/package-source.py`: ele compara runtime/instalador, inclui build/testes/history/evidências sanitizadas/entradas MD e JSON/impactos atuais, exclui extrações de acompanhantes/laboratórios/node_modules/logs/dumps/ZIPs e grava `source-manifest.json`. O fonte fechado contém cópia do relatório anterior ao seu próprio hash. A identidade final é preenchida apenas no relatório externo, sem reabrir o ZIP.

Para reproduzir, restaure os dois marcadores no relatório pré-fechamento, mantendo os resultados e identidade do instalador. A reprodução não substitui silenciosamente os bytes certificados de uma entrega final. O relatório principal é a referência para instalação observada, testes aprovados e pendências.
