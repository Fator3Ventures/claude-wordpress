# Fonte Core 1.58.0

Base direta suportada: Core 1.57.1 canônico, instalador 2707842 bytes, SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`. Contrato administrativo 8.23.0. Runtime canônico em `work/plugin/base-site-core-fator3`; o empacotador confere sua igualdade integral com o instalador certificado.

Pedidos core 314–329 e consumidor Meta 20(e). Leia `docs/DOCUMENTACAO.md`, `RELEASE-1.58.0.md` e `AGENTES-1.58.0.md` no runtime. O código local não elimina dependências: retorno comercial Google/LinkedIn aguarda contrato 1.2 dos produtores, e teste 322 bloqueia e-mail/webhook sem limpeza individual comprovável. Resultados e aceites reais constam somente do relatório externo da entrega.

Plano anterior à implementação em `history/1580/PLANO.md`; adendo dos novos acompanhantes em `history/1580/ADENDO-MCP0340-META0130.md`; entradas e pedidos em `inputs/1580`; provas desta rodada em `evidence/1580`. Diretórios numerados anteriores são histórico, não testes reexecutados por inferência. As normas canônicas instaladas preservam as revisões recebidas; a Norma 02 revisão 5 rege impactos e fechamento.

Reprodução: `build/README.md`. A árvore final já contém as alterações, sem exigir reaplicar patches transitórios. Acompanhantes originais são fornecidos separadamente conforme `build/COMPANIONS.md`; fontes/runtimes de terceiros, laboratórios, node_modules, dumps, logs brutos e ZIPs aninhados não integram o pacote-fonte Core. Manifestos sanitizados preservam a origem dos insumos.

Mínimos declarados Core: WordPress 7.1.2 e PHP 8.3.6 de 64 bits. O relatório registra quais combinações foram efetivamente exercitadas. Pipedrive 0.3 exige PHP 8.3.36 e não deve ser ativado no piso inferior do Core. Fixtures com SDK real e HTTP sintético não homologam conta Google/Meta/LinkedIn/Pipedrive ou autenticação de e-mail externos.

`base-site-core-fator3-1.58.0-relatorio.md` externo é canônico. A cópia interna do fonte antecede o fechamento e remete ao externo para a identidade final deste próprio ZIP, evitando hash circular. Publicação no repositório e implantação na frota são etapas independentes da entrega ao dono.
