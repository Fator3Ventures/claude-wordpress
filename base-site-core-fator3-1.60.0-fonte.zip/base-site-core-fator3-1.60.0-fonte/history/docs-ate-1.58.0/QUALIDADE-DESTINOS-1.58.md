# Retorno comercial por destino — Core 1.58.0

Pedido Core323. Google Ads e LinkedIn têm configuração própria em `f3base_qualidade_destinos`, desligada por padrão. Cada etapa local usa uma ação exclusiva em cada destino. Configurar uma ação não concede acesso à conta nem altera uma campanha. O destino Meta conserva seu contrato anterior e a opção independente de valor do Pedido315.

## Situação dos acompanhantes

Google0.21.0 entrega `site-conversion-delivery/1.1.0` para aquisição e conserva1.0.0. LinkedIn0.11.0 entrega1.0.0. **Nenhum desses pacotes implementa múltiplas ações comerciais por etapa.** O Core recusa o envio com `adaptador_etapas_nao_suportado`; uma ação de contato nunca é usada como alternativa.

O contrato **1.2.0 descrito abaixo é uma proposta necessária aos mantenedores**, ainda sem aceite de fornecedor. Sua implementação no consumidor permite prévias e testes sintéticos, mas não declara que o envio comercial esteja disponível nas versões atuais. Encaminhamentos e respostas pertencem ao relatório principal da entrega.

## Proposta opcional `site-conversion-delivery/1.2.0`

Descoberta pelo filtro público `f3base_conversoes_adaptador`. O adaptador de aquisição deve anunciar1.2.0 em `supported_contracts`. A segunda seleção recebe destino `google_ads` ou `linkedin`, contrato1.2.0 e contexto `{consumer_id:"site-core-quality",purpose:"crm_stage",action:"..."}`. O objeto retornado deve possuir `capabilities()` local e `sendBound(payload,destination_ref)`; capabilities não chama o fornecedor nem concede acesso.

Capabilities mínimas:

```json
{
  "contract": "site-conversion-delivery/1.2.0",
  "supported_contracts": ["site-conversion-delivery/1.2.0"],
  "purposes": ["crm_stage"],
  "ready": true,
  "acquisition_action": "customers/1234567890/conversionActions/111",
  "actions": {
    "customers/1234567890/conversionActions/222": {
      "action": "customers/1234567890/conversionActions/222",
      "purpose": "crm_stage",
      "ready": true,
      "destination_ref": "referencia-opaca-vinculada-pelo-produtor"
    }
  }
}
```

Os IDs são sintéticos. Google exige `acquisition_action` explicitamente: recurso completo da ação de contato, ou `null` quando o pacote comprova não haver ação de aquisição configurada. Omitir o campo, usar string vazia ou tipo inválido bloqueia com `acao_aquisicao_nao_comprovada`. Reutilizar a ação bloqueia com `acao_comercial_reutiliza_contato`. Quando a capacidade anterior anuncia `enhanced_leads.conversion_action`, a identidade precisa coincidir com `acquisition_action`; divergência bloqueia com `acao_aquisicao_divergente`. Não ler opções privadas do pacote para suprir ausência de contrato. LinkedIn exige ID numérico distinto da ação de contato configurada no Core.

Cada `actions[action]` precisa anunciar exatamente a ação solicitada, `purpose:"crm_stage"`, prontidão e referência própria. A referência deve vincular conta, ação, concessão, identidade e geração de autorização. `sendBound` deve revalidá-la antes do efeito; revogação ou troca de contexto impede envio, sem selecionar outra conta/ação. O Core conserva e confere essa referência e a revisão de sua própria configuração entre reserva e envio.

O payload comum contém `contract`, `purpose`, `record_id`, `stage_id`, `action`, `event_id` estável e `occurred_at` RFC3339 da etapa. Google acrescenta `click_ids`, `order_id` igual ao `event_id`, consentimento `ad_user_data`, valor0/moedaBRL do contrato de aquisição e, se anunciado para aquela ação, `user_data`. `actions[action].enhanced_leads` deve seguir a prova1.1.0, indicar a mesma ação comercial e anunciar prontidão vigente da conta/ação. Sem clique, exige conversão otimizada pronta e identidade normalizada disponível. O hashing e o transporte final continuam sob responsabilidade do Google.

LinkedIn acrescenta `eventId`, `conversion` como URN da ação, `conversionHappenedAt` em milissegundos e `user.userIds` com e-mail SHA-256 e/ou identificador publicitário capturado. Concessão, escopos e regra API pertencem ao produtor e devem fazer parte da prontidão/referência vinculada.

O retorno de `sendBound` usa `status:"entregue"|"recusado"|"incerto"`, `code` sanitizado e `http` opcional. `entregue` exige confirmação do fornecedor. `recusado` só é terminal comprovado com `non_delivery_proven:true`; ausência de prova, exceção ou resultado desconhecido torna o recibo `incerto`. O Core não repete automaticamente resultado incerto nem escolhe outra ação. Reconciliação futura requer contrato próprio e evidência do produtor.

## Operação e limites

A etapa precisa pertencer a contato aceito, ativo, real, com publicidade permitida na captura e atualmente. Testes, homologação, audiência excluída e entrada por e-mail não são enviados. O instante deve estar entre a captura e o presente, dentro de sete dias. A transação que registra o evento comercial também reserva o recibo por contato/etapa/destino; voltar à mesma etapa não gera outra conversão.

`f3base/qualidade-conversoes-previa` não cria fila nem envia: informa elegibilidade, motivo e forma do payload, removendo identificadores brutos e mostrando hashes/tipos. `f3base/contatos-qualidade-ler` acrescenta `envios_comerciais`, com estado e motivo por destino. Opções alteradas depois da reserva bloqueiam o trabalho pendente para evitar redirecionamento silencioso.

As tabelas e prévias locais não comprovam efeito no Google Ads ou LinkedIn. O aceite real permanece dependente da entrega dos adaptadores compatíveis, concessão, configuração e execução autorizada pelo operador.
