<?php
require __DIR__.'/bootstrap.php';
global $wpdb;
$before=get_option('f3base_formularios',false);$visitor=bin2hex(random_bytes(16));
$form=['id'=>'qa317','titulo'=>'[TESTE F3BASE] Abandono','ligado'=>true,'regime'=>'registro','pipedrive'=>false,'campos'=>[
 ['nome'=>'nome','tipo'=>'text','rotulo'=>'Nome','papel'=>'nome','obrigatorio'=>true],
 ['nome'=>'email','tipo'=>'email','rotulo'=>'E-mail','papel'=>'email'],
 ['nome'=>'interesses','tipo'=>'checkbox','rotulo'=>'Interesses','opcoes'=>['Primeiro','Segundo']],
 ['nome'=>'anexo','tipo'=>'file','rotulo'=>'Anexo'],
 ['nome'=>'mensagem','tipo'=>'textarea','rotulo'=>'Mensagem','etapa'=>2],
 ['nome'=>'aviso','tipo'=>'static','rotulo'=>'Aviso','html'=>'<p>Somente informativo</p>']
],'resposta_visitante'=>['ativa'=>false]];
try {
 raw('f3base_formularios',[$form]);$form=F3Base_Formularios::obter('qa317');$revision=F3Base_Formularios::revisao($form);$proof=F3Base_Analise::prova_formulario($form);
 $event=['evento'=>bin2hex(random_bytes(16)),'visitante'=>$visitor,'sessao'=>str_repeat('c',32),'navegacao'=>str_repeat('d',32),'tipo'=>'form_fechado','caminho'=>'/qa-317','formulario'=>'qa317','formulario_revisao'=>$revision,'correlacao'=>str_repeat('e',32),'dispositivo'=>'desktop','criado_em'=>time()-10,'detalhe'=>'saida_sem_aceite_observado','ultimo_campo'=>'nome','etapa'=>1,'campos_preenchidos'=>1,'contexto_teste'=>true];
 $row=F3Base_Analise::validar($event);check(!isset($row['erro'])&&$row['ultimo_campo']==='nome','317_technical_field_current_revision');
 check(!isset(F3Base_Analise::validar($event+['formulario_prova'=>$proof])['erro']),'317_signed_schema_current');
 check(F3Base_Analise::validar($event+['valor_digitado'=>'PRIVATE317'])['erro']==='campo_desconhecido','317_no_entered_value');
 check(F3Base_Analise::validar(array_replace($event,['ultimo_campo'=>'campos[nome]']))['erro']==='campo_formulario_invalido','317_html_field_name_not_technical');
 check(F3Base_Analise::validar(array_replace($event,['ultimo_campo'=>'aviso']))['erro']==='campo_formulario_invalido','317_static_text_not_field');
 check(F3Base_Analise::validar(array_replace($event,['campos_preenchidos'=>6]))['erro']==='abandono_invalido','317_count_limited_to_schema');
 check(F3Base_Analise::validar(array_replace($event,['etapa'=>3]))['erro']==='abandono_invalido','317_stage_domain');
 check(F3Base_Analise::validar(array_replace($event,['formulario_revisao'=>'']))['erro']==='revisao_formulario_nao_comprovada','317_missing_revision_not_invented');
 $legacy=$event;unset($legacy['ultimo_campo'],$legacy['etapa'],$legacy['campos_preenchidos']);$legacy['formulario_revisao']='';check(!isset(F3Base_Analise::validar($legacy)['erro']),'317_old_event_contract_preserved');
 $signed=$event+['formulario_prova'=>$proof];$changed=$form;$changed['campos'][0]['nome']='nome_novo';raw('f3base_formularios',[$changed]);
 check(!isset(F3Base_Analise::validar($signed)['erro']),'317_cached_old_revision_proved');
 check(F3Base_Analise::validar($event)['erro']==='revisao_formulario_nao_comprovada','317_old_revision_without_proof_rejected');
 check(F3Base_Analise::validar(array_replace($signed,['formulario_revisao'=>F3Base_Formularios::revisao($changed)]))['erro']==='revisao_formulario_nao_comprovada','317_proof_cannot_cross_revision');
 check(F3Base_Analise::validar(array_replace($signed,['formulario'=>'qa-other']))['erro']==='revisao_formulario_nao_comprovada','317_proof_cannot_cross_form');
 $parts=explode('.',$proof);$raw=json_decode(base64_decode(strtr($parts[0],'-_','+/')),true);$raw['c']['injected']=1;$parts[0]=rtrim(strtr(base64_encode(wp_json_encode($raw)),'+/','-_'),'=');
 check(F3Base_Analise::validar(array_replace($signed,['formulario_prova'=>implode('.',$parts)]))['erro']==='revisao_formulario_nao_comprovada','317_changed_names_invalid_signature');
 raw('f3base_formularios',[]);check(!isset(F3Base_Analise::validar($signed)['erro']),'317_removed_cached_form_still_bound_to_proof');
 raw('f3base_formularios',[$form]);$html=F3Base_Formularios::renderizar(['id'=>'qa317']);check(str_contains($html,'data-analise-prova="')&&str_contains($html,'name="campos[nome]"'),'317_real_html_carries_proof');
 $fixture=getenv('F3BASE_LAB_DIR').'/request-317-form.html';file_put_contents($fixture,$html);check(is_file($fixture),'317_native_html_exported');
 $row=F3Base_Analise::validar($signed);check(!isset($row['formulario_prova'])&&!str_contains(wp_json_encode($row),$proof),'317_proof_not_persisted');
 check($wpdb->insert(F3Base_Analise::tabela(),$row)===1,'317_abandon_row_persisted');
 $started=$legacy;$started['evento']=bin2hex(random_bytes(16));$started['formulario_revisao']=$revision;$started['tipo']='form_inicio';$started['detalhe']='';$started['criado_em']=time()-20;$r=F3Base_Analise::validar($started);check(!isset($r['erro'])&&$wpdb->insert(F3Base_Analise::tabela(),$r)===1,'317_start_row_persisted');
 $report=F3Base_Relatorios::consultar(['visao'=>'formularios','formulario'=>'qa317','de'=>wp_date('Y-m-d'),'ate'=>wp_date('Y-m-d'),'segmento'=>'somente_testes']);$lines=$report['linhas']??[];
 check(!empty($report['ok'])&&count($lines)===1&&$lines[0]['revisao']===$revision&&($lines[0]['abandono_por_campo']['nome']??0)===1&&($lines[0]['abandono_por_etapa'][1]??0)===1,'317_report_by_revision_field_stage');
 $terminal=$started;$terminal['evento']=bin2hex(random_bytes(16));$terminal['tipo']='form_aceito';$terminal['criado_em']=time()-8;check($wpdb->insert(F3Base_Analise::tabela(),F3Base_Analise::validar($terminal))===1,'317_later_acceptance_persisted');
 $query=['visao'=>'formularios','formulario'=>'qa317','de'=>wp_date('Y-m-d'),'ate'=>wp_date('Y-m-d'),'segmento'=>'somente_testes'];$report=F3Base_Relatorios::consultar($query);$line=$report['linhas'][0];
 check($line['abandono_por_campo']===[]&&$line['fechados_sem_aceite_observado']===0&&$line['etapa1_aceita_observada']===1,'317_later_acceptance_resolves_initial_abandonment');
 $stage2=array_replace($signed,['evento'=>bin2hex(random_bytes(16)),'etapa'=>2,'ultimo_campo'=>'mensagem','campos_preenchidos'=>2,'criado_em'=>time()-6]);check($wpdb->insert(F3Base_Analise::tabela(),F3Base_Analise::validar($stage2))===1,'317_second_stage_close_persisted');
 $report=F3Base_Relatorios::consultar($query);$line=$report['linhas'][0];check(($line['abandono_por_campo']['mensagem']??0)===1&&($line['abandono_por_etapa'][2]??0)===1,'317_first_stage_acceptance_does_not_complete_second');
 $terminal['evento']=bin2hex(random_bytes(16));$terminal['tipo']='form_complemento';$terminal['criado_em']=time()-4;check($wpdb->insert(F3Base_Analise::tabela(),F3Base_Analise::validar($terminal))===1,'317_complement_persisted');
 $report=F3Base_Relatorios::consultar($query);check($report['linhas'][0]['abandono_por_campo']===[]&&$report['linhas'][0]['complementos_observados']===1,'317_complement_resolves_second_stage_abandonment');
 raw('f3base_formularios',[$changed]);$new=array_replace($event,['evento'=>bin2hex(random_bytes(16)),'formulario_revisao'=>F3Base_Formularios::revisao($changed),'ultimo_campo'=>'nome_novo','criado_em'=>time()-2]);check($wpdb->insert(F3Base_Analise::tabela(),F3Base_Analise::validar($new))===1,'317_changed_revision_persisted');
 $report=F3Base_Relatorios::consultar($query);$lines=array_column($report['linhas'],null,'revisao');check(count($lines)===2&&$lines[$revision]['abandono_por_campo']===[]&&$lines[$new['formulario_revisao']]['abandono_por_campo']['nome_novo']===1,'317_revisions_never_merged');
 evidence('request-317');
} finally {$wpdb->delete(F3Base_Analise::tabela(),['visitante'=>$visitor]);raw('f3base_formularios',$before);}
