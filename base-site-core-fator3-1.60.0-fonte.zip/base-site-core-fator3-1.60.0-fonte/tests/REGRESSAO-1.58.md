# Seleção de regressões — Core 1.58.0

Roteiro para laboratório descartável e processos sequenciais. A lista é seleção de cobertura; resultado e contagem pertencem às evidências da execução final. Nenhum teste autoriza fornecedor real.

## Core isolado

Execute primeiro `core-only-mode1580.php`; a seleção vale para o próximo processo. Casos pertinentes: `request-300-mime.php`, `request-300-state.php`, `request-300-collector.php`, `request-300-crm.php`, `request-302.php`, `request-302-crm.php`, `request-305.php`, `request-305-imap.php`, `request-307-311.php`, `request-309-collector.php`, `request-309-crm.php` e `request-301.php`.

Cobrem MIME/UID/pastas/retomada, caixa e CRM, atribuição externa, aprovação sem entrega, conversas WhatsApp, permissões e captura. O coletor 300 conserva as verificações de persistência/revisão/movimentação; sua expectativa de alerta acompanha o pedido 329: primeiro erro real dispara um e-mail técnico, sem Slack, seguido por deduplicação e recuperação do mesmo incidente.

`review-1571.php` e `hardening-1571.php` exercitam acervo GA4, transações, validação, paginação e retenção sem depender do fornecedor. `permissions-1571.php` neste modo produz `permissions-native-1571.json`.

## Google, Meta e LinkedIn reais com fornecedores simulados

Execute `socials-only1580.php`, que seleciona Core + Google 0.21 + Meta 0.13 + LinkedIn 0.11 e deixa MCP/Pipedrive inativos apenas na fixture. Depois, em processos novos: `request-312-1571.php` (exclusão Instagram) e `request-313.php` (SDK GA4). A primeira exige Meta Store; executá-la sem Meta não é prova de regressão do Core. Esta seleção também evita confundir o contrato Instagram com exigências de autenticação do canal MCP.

Os casos focados `request-316-real.php`, `meta-ads-0130.php` e `request-321-no-http.php` usam os runtimes originais, com transportes sintéticos. “real” no nome de 316 designa o adaptador original, não envio de conversão a conta de fornecedor. `request-322-remotes.php` usa objetos e respostas Pipedrive/Slack em memória; nenhuma autorização de CRM real é exercida.

## Coexistência completa e documentação

`site-1580-companions.php` confere versões e ativa MCP 0.34, Google 0.21, Meta 0.13 e LinkedIn 0.11. Ativa Pipedrive 0.3 somente com PHP >= 8.3.36; em piso inferior o mantém inativo com motivo. O helper exige todos os pacotes originais presentes e serve ao laboratório/fixture; não use no site compartilhado.

Em novo processo, executar `companions-321-324.php`, `request-321-no-http.php`, `permissions-1571.php` e `docs-1580.php`. A prova de permissões MCP tem autenticação temporária própria e grava `permissions-mcp-1571.json`; não basta deixar o pacote instalado. O relatório de documentação percorre todo o índice e confere hashes/schema, não apenas os guias novos.

Os históricos `request-294.php`/`request-294-recovery.php` exigem seu MU e árvore `companions` próprios; não fazem parte do bundle remoto. Ensaios de SMTP/IMAP que precisem de setup de DNS ou sockets externos permanecem nos harnesses locais específicos. A seleção não substitui os ciclos nativos de instalação/atualização.

## Harness remoto fechado

Gerar com `python3 build/site-1580-bundle.py`. O arquivo temporário `build/site-1580-controller.php` oferece somente `setup`, `suite`, `site-read` e `cleanup`, por `f3base/qa-core-1580`. Ele confere host Site-Teste e Core 1.58.0; a fixture tem prefixo aleatório `f3qa1580_<12hex>_`, home `https://example.invalid`, salts próprios, tabelas próprias e diretório temporário privado. Não copia opções, contatos ou credenciais dos plugins instalados.

`setup` copia os runtimes instalados para a fixture e valida as versões dos acompanhantes. Cada suite roda em subprocesso, com WP cron desligado, HTTP negado por padrão, wp_mail interceptado e funções de transporte de rede/mail desabilitadas. Os mocks explícitos continuam observáveis. `site-read` inspeciona o site compartilhado sem mutações de contatos; não executa as suites contra suas tabelas. `cleanup` restringe a remoção ao prefixo e diretório validados e devolve prova de ausência. Remova também o controlador temporário pelo fluxo autorizado depois da coleta.

Executar uma suite por chamada e preservar a evidência antes da limpeza. O modo selecionado se aplica somente ao processo seguinte. Regenerar o bundle após qualquer correção dos testes, para não testar bytes antigos. Este roteiro não afirma execução remota.
