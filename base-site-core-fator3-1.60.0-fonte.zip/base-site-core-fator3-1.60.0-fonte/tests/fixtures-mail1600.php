<?php
class Imap1600Stream {
 public $context;private string $read='';public static array $messages=[1=>"Message-ID: <ordinary@example.test>\r\nSubject: Preserve\r\n\r\nUnrelated mail\r\n"];public static array $commands=[];public static int $validity=600;public static bool $uidplus=true;public static array $deleted=[1];
 public function stream_open($path,$mode,$options,&$opened_path){return true;}public function stream_eof(){return false;}public function stream_stat(){return [];}public function stream_set_option($a,$b,$c){return true;}
 public function stream_read($count){$part=substr($this->read,0,$count);$this->read=substr($this->read,strlen($part));return $part;}
 public function stream_write($data){$line=trim($data);self::$commands[]=$line;[$tag,$cmd]=explode(' ',$line,2);$r='';
  if(str_starts_with($cmd,'SELECT')||str_starts_with($cmd,'EXAMINE'))$r='* OK [UIDVALIDITY '.self::$validity."] current\r\n* OK [UIDNEXT 999] next\r\n";
  elseif($cmd==='CAPABILITY')$r='* CAPABILITY IMAP4rev1 '.(self::$uidplus?'UIDPLUS':'')."\r\n";
  elseif(preg_match('/^UID SEARCH HEADER Message-ID "([^"]+)"$/D',$cmd,$m)){$ids=[];foreach(self::$messages as $uid=>$raw)if(str_contains($raw,$m[1]))$ids[]=$uid;$r='* SEARCH'.($ids?' '.implode(' ',$ids):'')."\r\n";}
  elseif(preg_match('/^UID FETCH (\d+) \(UID RFC822.SIZE INTERNALDATE\)$/D',$cmd,$m)){if(isset(self::$messages[$m[1]]))$r='* 1 FETCH (UID '.$m[1].' RFC822.SIZE '.strlen(self::$messages[$m[1]]).' INTERNALDATE "'.gmdate('d-M-Y H:i:s O').'")'."\r\n";}
  elseif(preg_match('/^UID FETCH (\d+) \(UID BODY.PEEK\[\]\)$/D',$cmd,$m)){$raw=self::$messages[$m[1]];$r='* 1 FETCH (UID '.$m[1].' BODY[] {'.strlen($raw)."}\r\n".$raw.")\r\n";}
  elseif(preg_match('/^UID STORE (\d+) \+FLAGS.SILENT \(\\\\Deleted\)$/D',$cmd,$m)){self::$deleted[]=(int)$m[1];}
  elseif(preg_match('/^UID EXPUNGE (\d+)$/D',$cmd,$m)){if(in_array((int)$m[1],self::$deleted,true))unset(self::$messages[(int)$m[1]]);}
  else throw new RuntimeException('Unexpected IMAP command '.$cmd);
  $this->read.=$r.$tag." OK done\r\n";return strlen($data);
 }
}
stream_wrapper_register('imapfixture',Imap1600Stream::class);
$imap=static function(){ $r=new ReflectionClass(F3Base_Email_Imap::class);$c=$r->newInstanceWithoutConstructor();$r->getProperty('socket')->setValue($c,fopen('imapfixture://box','r+'));$r->getProperty('deadline')->setValue($c,microtime(true)+30);return $c;};
class Smtp1600 extends F3Base_SMTP_Cliente {
 public array $recipients=[];public int $sends=0;public bool $opened=false;public bool $uncertain=false;
 public function connected(){return $this->opened;}public function connect($host,$port=null,$timeout=30,$options=[]){$this->opened=true;return true;}public function hello($host=''){return true;}public function getServerExt($name){return true;}public function startTLS(){return true;}public function authenticate($username,$password,$authtype=null,$OAuth=null){return true;}public function mail($from){return true;}public function recipient($address,$dsn=''){$this->recipients[]=$address;return true;}
 public function data($raw){global $wpdb;$this->sends++;check((int)$wpdb->get_var("SELECT COUNT(*) FROM ".F3Base_Caminho_Lead::tabela()." WHERE recibo LIKE '%enviando%'")>0,'322_mail_durable_intent_before_data_'.$this->sends);check(F3Base_Caminho_Email::propria($raw),'322_mail_signed_ownership_'.$this->sends);Imap1600Stream::$messages[100+$this->sends]=$raw;return !$this->uncertain;}
 public function getLastReply(){return $this->uncertain?'':'250 accepted';}public function reset(){return true;}public function quit($close_on_error=true){$this->opened=false;return true;}public function close(){$this->opened=false;}
}
