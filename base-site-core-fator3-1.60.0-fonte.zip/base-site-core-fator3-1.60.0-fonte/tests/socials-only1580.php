<?php
/** Select real social adapters, without MCP authorization wrappers, in the disposable lab only. */
require __DIR__.'/bootstrap.php';
raw('active_plugins',[
    'base-site-core-fator3/base-site-core-fator3.php',
    'wp-mcp-google-fator3/wp-mcp-google-fator3.php',
    'wp-mcp-meta-fator3/wp-mcp-meta-fator3.php',
    'wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php',
]);
echo "Next fixture request: Core + Google + Meta + LinkedIn; MCP and Pipedrive inactive.\n";
