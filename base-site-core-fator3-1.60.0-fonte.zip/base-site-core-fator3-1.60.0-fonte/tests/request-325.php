<?php
require __DIR__.'/bootstrap.php';wp_get_abilities();$original=get_option(F3Base_Marcas::OPCAO,false);$state=get_option(F3Base_Marcas::STATE,false);$id=0;$calls=0;
$deny=static function()use(&$calls){$calls++;throw new RuntimeException('Local reading must not call HTTP');};
try{
 $cfg=[['nome'=>'Marca Vizinha','variacoes'=>['VizinhaTech'],'dominios'=>['vizinha.example'],'caminhos_permitidos'=>['/socios/']]];
 check(save(F3Base_Marcas::OPCAO,$cfg)['persisted'],'325_configuration_saved');
 $html='<!doctype html><html><head><script type="application/ld+json">{"name":"Marca Vizinha","sameAs":"https://vizinha.example/about"}</script></head><body><header>Marca Vizinha</header><main>VizinhaTech <a href="https://sub.vizinha.example/path">'.str_repeat('á',90).'</a><a href="https://vizinha.example.attacker.test">unrelated</a><script>Marca Vizinha</script><span hidden>Marca Vizinha</span> SuperVizinhaTechCorp</main><footer>Marca Vizinha</footer></body></html>';
 $r=F3Base_Marcas::html($html,'https://site.example/teste');check($r['estado']==='inspecionada'&&$r['total']===6,'325_matches_surfaces_not_hidden_or_suffix');check(count(array_unique(array_column($r['ocorrencias'],'superficie')))===4,'325_all_surfaces');check(max(array_map(static fn($x)=>mb_strlen($x['trecho']),$r['ocorrencias']))<=80,'325_excerpt_bound');check($r['nao_permitidas']===6,'325_no_automatic_exceptions');
 $allowed=F3Base_Marcas::html($html,'https://site.example/socios/');check($allowed['nao_permitidas']===0&&$allowed['total']===6,'325_exact_allowed_path');check(F3Base_Marcas::html($html,'https://site.example/socios/filho')['nao_permitidas']===6,'325_exception_does_not_extend_children');
 $id=wp_insert_post(['post_title'=>'[TESTE F3BASE] 325','post_content'=>'<a href="https://vizinha.example">Marca Vizinha</a>','post_status'=>'publish','post_type'=>'page']);check($id>0,'325_test_page_created');$url=get_permalink($id);
 $rev=F3Base_Options::revisao(F3Base_Marcas::OPCAO);raw(F3Base_Marcas::STATE,['revisao'=>$rev,'em'=>time(),'completa'=>true,'paginas'=>[(string)$id=>['completa'=>true,'ocorrencias'=>2,'nao_permitidas'=>2]]]);
 add_filter('pre_http_request',$deny,999);$local=F3Base_Marcas::resumo();check($local['completa']&&$local['ocorrencias']===2&&$calls===0,'325_local_summary_without_fetch');remove_filter('pre_http_request',$deny,999);
 $bad=$cfg;$bad[0]['dominios']=['vizinha.example/'];check(!save(F3Base_Marcas::OPCAO,$bad)['persisted'],'325_domain_validation');$bad=$cfg;$bad[0]['caminhos_permitidos']=['/socios/*'];check(!save(F3Base_Marcas::OPCAO,$bad)['persisted'],'325_no_wildcard_exception');
 wp_delete_post($id,true);check(!get_post($id),'325_test_page_removed');$id=0;check(F3Base_Marcas::resumo()['paginas_inspecionadas']===0,'325_removed_page_excluded');
 check(save(F3Base_Marcas::OPCAO,[])['persisted']&&F3Base_Marcas::html($html,$url)['estado']==='desligada','325_empty_list_disables');
}finally{remove_filter('pre_http_request',$deny,999);if($id){wp_delete_post($id,true);}foreach([F3Base_Marcas::OPCAO=>$original,F3Base_Marcas::STATE=>$state] as $n=>$v){if($v===false){delete_option($n);}else{raw($n,$v);}}}
evidence('request-325');
