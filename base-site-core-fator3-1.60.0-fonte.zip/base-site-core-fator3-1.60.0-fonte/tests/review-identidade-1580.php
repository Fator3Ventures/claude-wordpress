<?php
/** Shared identity lock and encrypted external contacts; synthetic local records only. */
require __DIR__.'/bootstrap.php';global $wpdb;wp_get_abilities();
$role=get_role('administrator');$caps=[];foreach(['f3base_ler_leads','f3base_gerir_leads'] as $cap){$caps[$cap]=$role->has_cap($cap);$role->add_cap($cap);}wp_set_current_user(1);
$old=get_option(F3Base_Contato_Identidade::OPCAO,false);$ids=[];$keys=[];$lock=null;$http=0;$mail=0;$captures=0;$nonce=bin2hex(random_bytes(8));$at=time();
$deny=static function()use(&$http){++$http;return new WP_Error('review_identity_no_http');};$denyMail=static function()use(&$mail){++$mail;return false;};$capture=static function()use(&$captures){++$captures;};
add_filter('pre_http_request',$deny,99999);add_filter('pre_wp_mail',$denyMail,99999);add_action('f3base_lead_persistido',$capture,99999);
$phone=static fn(int $n)=>'+55119'.str_pad((string)(hexdec(substr(hash('sha256',$nonce.'-'.$n),0,7))%100000000),8,'0',STR_PAD_LEFT);
$siteInput=static fn(string $email,string $tel,int $when,array $extra=[])=>array_replace(['nome'=>'[TESTE F3BASE] Identity','email'=>$email,'telefone'=>$tel,'metodo'=>'formulario','formulario'=>'review1580','captura'=>'aceito','criado_em'=>gmdate('Y-m-d H:i:s',$when),'contexto_teste'=>true,'origem_nativa'=>['origem'=>'review_identidade_1580'],'notificar'=>false],$extra);
$externalInput=static fn(string $suffix,string $email,string $tel,int $when)=>['simular'=>false,'idempotency_key'=>'review1580-'.$nonce.'-'.$suffix,'metodo'=>'telefone','nome'=>'[TESTE F3BASE] External identity','email'=>$email,'telefone'=>$tel,'primeiro_contato_em'=>gmdate('Y-m-d\TH:i:s\Z',$when),'contexto_teste'=>true,'pipedrive'=>['acao'=>'nenhuma']];
$remember=static function(array $r)use(&$ids){if(!empty($r['persisted'])&&!empty($r['record_id'])){$ids[]=$r['record_id'];}return $r;};
$total=static fn()=>(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Leads_Repositorio::tabela());
try{
 check(F3Base_Contato_Identidade::instalar(),'identity1580_links_table');raw(F3Base_Contato_Identidade::OPCAO,F3Base_Contato_Identidade::padroes());
 $external=$remember(F3Base_Contatos_Externos::registrar($externalInput('first',$nonce.'-external@example.test',$phone(1),$at-600)));check(!empty($external['persisted']),'identity1580_external_first_persisted');
 $externalLead=F3Base_Leads_Repositorio::obter($external['record_id']);check($externalLead['email']===''&&$externalLead['nome']===''&&F3Base_Contato_Identidade::identificadores($externalLead)['email']===$nonce.'-external@example.test','identity1580_encrypted_external_identifier_projection');
 $site=$remember(F3Base_Leads_Repositorio::guardar($siteInput($nonce.'-external@example.test',$phone(2),$at-480),bin2hex(random_bytes(32))));check(!empty($site['persisted']),'identity1580_site_after_external_persisted');
 $prior=F3Base_Leads_Repositorio::obter($site['record_id'])['dados']['registro_anterior']??[];check(($prior['record_id']??'')===$external['record_id']&&$prior['metodo']==='contato_externo'&&$prior['minutos']===2&&$prior['correspondencia']===['email'],'identity1580_external_to_site_exact_email');
 $siteFirst=$remember(F3Base_Leads_Repositorio::guardar($siteInput($nonce.'-site@example.test',$phone(3),$at-550),bin2hex(random_bytes(32))));check(!empty($siteFirst['persisted']),'identity1580_site_first_persisted');
 $externalLaterInput=$externalInput('later',$nonce.'-other@example.test',$phone(3),$at-430);$externalLater=$remember(F3Base_Contatos_Externos::registrar($externalLaterInput));check(!empty($externalLater['persisted']),'identity1580_external_after_site_persisted');
 $prior=F3Base_Leads_Repositorio::obter($externalLater['record_id'])['dados']['registro_anterior']??[];check(($prior['record_id']??'')===$siteFirst['record_id']&&$prior['metodo']==='formulario'&&$prior['minutos']===2&&$prior['correspondencia']===['telefone'],'identity1580_site_to_external_exact_phone');
 $n=$total();$duplicate=F3Base_Contatos_Externos::registrar($externalLaterInput);check(!empty($duplicate['duplicado'])&&$duplicate['record_id']===$externalLater['record_id']&&$total()===$n,'identity1580_external_retry_no_insert');
 $suspect=$remember(F3Base_Leads_Repositorio::guardar($siteInput($nonce.'-external@example.test',$phone(4),$at-540,['captura'=>'suspeito']),bin2hex(random_bytes(32))));check(!empty($suspect['persisted'])&&empty(F3Base_Leads_Repositorio::obter($suspect['record_id'])['dados']['registro_anterior']),'identity1580_suspect_not_enriched_before_approval');
 $update=['record_id'=>$suspect['record_id'],'revisao_esperada'=>1,'alteracoes'=>['captura'=>'aceito'],'simular'=>false,'entregar'=>false];
 $blockedExternal=$externalInput('blocked',$nonce.'-blocked-external@example.test',$phone(5),$at-100);$blockedSite=$siteInput($nonce.'-blocked-site@example.test',$phone(6),$at-90);$siteKey=bin2hex(random_bytes(32));
 $linkedPrivate=['contexto_teste'=>true,'telefone'=>$phone(3),'primeiro_contato_em'=>gmdate('c',$at-60)];$newPrivate=['contexto_teste'=>true,'telefone'=>$phone(7),'primeiro_contato_em'=>gmdate('c',$at-60)];
 $linkedKey=$keys[]=bin2hex(random_bytes(32));$newKey=$keys[]=bin2hex(random_bytes(32));$directKey=$keys[]=bin2hex(random_bytes(32));
 $lock=F3Base_Trava::adquirir('identidade-captura',120);check($lock!==null,'identity1580_shared_lock_fixture');$n=$total();$before=F3Base_Leads_Repositorio::obter($suspect['record_id']);$beforeCapture=$captures;
 $r=F3Base_Contatos_Externos::registrar($blockedExternal);check(empty($r['persisted'])&&$r['codigo']==='identidade_ocupada','identity1580_external_blocked_by_shared_lock');
 $r=F3Base_Leads_Repositorio::guardar($blockedSite,$siteKey);check(empty($r['persisted'])&&$r['codigo']==='identidade_ocupada','identity1580_site_blocked_by_shared_lock');
 $r=F3Base_Leads_Repositorio::atualizar($update);check(empty($r['ok'])&&$r['codigo']==='identidade_ocupada'&&F3Base_Leads_Repositorio::obter($suspect['record_id'])===$before,'identity1580_update_blocked_without_mutation');
 foreach(['matching'=>[$linkedKey,$linkedPrivate],'absent'=>[$newKey,$newPrivate]] as $label=>[$key,$p]){$r=F3Base_Conversas::persistir('whatsapp_conversa',$key,$p,[]);check(empty($r['persisted'])&&$r['codigo']==='identidade_ocupada','identity1580_conversation_'.$label.'_blocked_before_decision');}
 $r=F3Base_Contato_Identidade::whatsapp($directKey,$linkedPrivate);check(empty($r['persisted'])&&$r['codigo']==='identidade_ocupada','identity1580_direct_whatsapp_uses_shared_lock');
 $links=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE chave IN (%s,%s,%s)',F3Base_Contato_Identidade::tabela(),$linkedKey,$newKey,$directKey));
 check($total()===$n&&$links===0&&$captures===$beforeCapture&&$http===0&&$mail===0,'identity1580_contention_no_insert_hooks_or_remote_effects');
 F3Base_Trava::liberar($lock);$lock=null;
 $r=$remember(F3Base_Contatos_Externos::registrar($blockedExternal));check(!empty($r['persisted']),'identity1580_external_recovers_same_key');
 $r=$remember(F3Base_Leads_Repositorio::guardar($blockedSite,$siteKey));check(!empty($r['persisted']),'identity1580_site_recovers_same_key');
 $r=F3Base_Leads_Repositorio::atualizar($update);$approved=F3Base_Leads_Repositorio::obter($suspect['record_id']);check(!empty($r['persisted'])&&$approved['captura']==='aceito'&&($approved['dados']['registro_anterior']['record_id']??'')===$external['record_id'],'identity1580_approval_recovers_and_enriches_external_identity');
 $n=$total();$beforeCapture=$captures;$r=F3Base_Conversas::persistir('whatsapp_conversa',$linkedKey,$linkedPrivate,[]);check(!empty($r['persisted'])&&!empty($r['vinculado'])&&$r['record_id']===$siteFirst['record_id']&&$total()===$n,'identity1580_matching_conversation_recovers_without_insert');
 $r=F3Base_Contato_Identidade::whatsapp($directKey,$linkedPrivate);check(!empty($r['persisted'])&&!empty($r['vinculado'])&&$r['record_id']===$siteFirst['record_id']&&$total()===$n,'identity1580_direct_whatsapp_recovers_without_nested_lock');
 $r=$remember(F3Base_Conversas::persistir('whatsapp_conversa',$newKey,$newPrivate,[]));check(!empty($r['persisted'])&&empty($r['vinculado'])&&$total()===$n+1,'identity1580_unmatched_conversation_recovers_with_one_insert');
 $again=F3Base_Conversas::persistir('whatsapp_conversa',$newKey,$newPrivate,[]);check(!empty($again['duplicado'])&&$again['record_id']===$r['record_id']&&$total()===$n+1,'identity1580_conversation_retry_idempotent');
 check($captures===$beforeCapture&&$http===0&&$mail===0,'identity1580_link_and_conversation_emit_no_capture_or_remote_effects');
 evidence('review-identidade-1580');
}finally{
 if($lock){F3Base_Trava::liberar($lock);}remove_filter('pre_http_request',$deny,99999);remove_filter('pre_wp_mail',$denyMail,99999);remove_action('f3base_lead_persistido',$capture,99999);
 foreach(array_unique($ids) as $id){F3Base_Leads_Repositorio::eliminar($id,'teste');}foreach($keys as $key){$wpdb->delete(F3Base_Contato_Identidade::tabela(),['chave'=>$key]);}
 if($old===false){delete_option(F3Base_Contato_Identidade::OPCAO);}else{raw(F3Base_Contato_Identidade::OPCAO,$old);}foreach($caps as $cap=>$had){if(!$had){$role->remove_cap($cap);}}wp_set_current_user(1);
}
