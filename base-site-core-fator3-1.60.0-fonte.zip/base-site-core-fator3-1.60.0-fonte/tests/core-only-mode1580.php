<?php
/** Change only the disposable fixture's next-request plugin selection. */
require __DIR__.'/bootstrap.php';
raw('active_plugins',['base-site-core-fator3/base-site-core-fator3.php']);
echo "Next fixture request: Core only.\n";
