<?php
require __DIR__.'/bootstrap.php';global $wpdb;wp_get_abilities();get_role('administrator')->add_cap('f3base_ler_leads');
$schema=['type'=>'object','properties'=>['map'=>['type'=>'object','additionalProperties'=>['type'=>'string']],'items'=>['type'=>'array','items'=>['type'=>'string']]]];
$r=F3Base_Config_Caminhos::aplicar(['map'=>[],'items'=>[]],[['operacao'=>'definir','caminho'=>'/map/key','valor'=>'value']],$schema);check($r['ok']&&$r['valor']['map']===['key'=>'value'],'review328_empty_object_accepts_key');
$r=F3Base_Config_Caminhos::aplicar(['map'=>[],'items'=>[]],[['operacao'=>'definir','caminho'=>'/items/0','valor'=>'value']],$schema);check(!$r['ok']&&$r['codigo']==='indice_lista_invalido','review328_empty_list_requires_append');
$r=F3Base_Config_Caminhos::aplicar(['map'=>[],'items'=>[]],[['operacao'=>'acrescentar','caminho'=>'/items','valor'=>'value']],$schema);check($r['ok']&&$r['valor']['items']===['value'],'review328_empty_list_append');
$llmsBefore=get_option('f3base_llms',false);$revision=F3Base_Options::revisao('f3base_llms');
try{
 $input=['nome'=>'f3base_llms','revisao_esperada'=>$revision,'operacoes'=>[
  ['operacao'=>'acrescentar','caminho'=>'/livres','valor'=>['titulo'=>'Valid earlier operation','url'=>'https://example.test/review328','descricao'=>'fixture']],
  ['operacao'=>'acrescentar','caminho'=>'/livres','valor'=>['titulo'=>'Invalid type','url'=>['not-a-string'],'descricao'=>'fixture']]
 ]];
 $r=wp_get_ability('f3base/config-core-escrever')->execute($input+['simular'=>true]);
 check(!is_wp_error($r)&&empty($r['ok'])&&$r['codigo']==='tipo_invalido'&&empty($r['persisted'])&&F3Base_Options::revisao('f3base_llms')===$revision,'review328_invalid_candidate_simulation_rejected');
 check((bool)array_filter($r['erros']??[],static fn($e)=>str_ends_with($e['caminho']??'','.url')),'review328_invalid_nested_item_path_reported');
 $r=wp_get_ability('f3base/config-core-escrever')->execute($input+['simular'=>false]);
 $valid=!is_wp_error($r)&&empty($r['ok'])&&$r['codigo']==='tipo_invalido'&&empty($r['persisted'])&&F3Base_Options::revisao('f3base_llms')===$revision&&get_option('f3base_llms',false)===$llmsBefore;
 if(!$valid){echo wp_json_encode(['fixture'=>'review328_invalid_url_type','result'=>$r,'same_revision'=>F3Base_Options::revisao('f3base_llms')===$revision]).PHP_EOL;}
 check($valid,'review328_complete_candidate_validation_no_write');
}finally{if($llmsBefore===false){delete_option('f3base_llms');}else{raw('f3base_llms',$llmsBefore);}}
// The same collector code runs against a synthetic IMAP transport; no sockets or supplier traffic.
class Review329_Inbox {public static bool $fail=true;public function select($folder='INBOX',$readonly=true){return ['uidvalidity'=>329,'uidnext'=>2];}public function search($after,$since){return [];}public function pastas($configured,$create=false){return ['pastas'=>array_map(static fn($n)=>['efetiva'=>$n,'disponivel'=>true],$configured)];}public function move($uid,$folder){if(self::$fail){throw new RuntimeException('imap_move_indisponivel');}}public function close(){}}
$source=file_get_contents(F3BASE_PLUGIN_DIR.'includes/class-f3base-email-site.php');$source=str_replace(['final class F3Base_Email_Site','public static function conectar(): F3Base_Email_Imap {$client=apply_filters(\'f3base_email_imap_cliente\',null);if($client instanceof F3Base_Email_Imap){return $client;}return new F3Base_Email_Imap(self::cfg(),F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET));}','movimentos(F3Base_Email_Imap $client'],['final class Review329_Collector','public static function conectar(): Review329_Inbox {return new Review329_Inbox();}','movimentos(Review329_Inbox $client'],$source);eval(substr($source,5));
$saved=[];foreach([F3Base_Email_Site_Config::OPTION,F3Base_Email_Site_Config::STATE,'f3base_avisos_tecnicos','f3base_avisos','admin_email'] as $n){$saved[$n]=get_option($n,false);}$key=bin2hex(random_bytes(32));$mails=[];$http=0;
$mail=static function($pre,$args)use(&$mails){$mails[]=$args;return true;};$block=static function()use(&$http){++$http;return new WP_Error('review_no_http');};add_filter('pre_wp_mail',$mail,999,2);add_filter('pre_http_request',$block,999);
try{
 $cfg=array_replace(F3Base_Email_Site_Config::padroes(),['ativo'=>true,'endereco'=>'review329@example.test','usuario'=>'review329@example.test']);raw(F3Base_Email_Site_Config::OPTION,$cfg);$context=F3Base_Email_Site_Config::identidade($cfg);raw(F3Base_Email_Site_Config::STATE,['identidade'=>$context,'ativado_em'=>time()-120,'ultima_leitura_completa'=>time()-120,'uid'=>1,'uidvalidity'=>329]);raw('admin_email','technical329@example.test');raw('f3base_avisos_tecnicos',['email'=>'','atraso_minutos'=>60]);$notice=F3Base_Options::ler('f3base_avisos');$notice['canal']='slack';raw('f3base_avisos',$notice);
 check($wpdb->insert(F3Base_Email_Site::tabela(),['chave'=>$key,'contexto'=>$context,'direcao'=>'entrada','uidvalidity'=>329,'uid'=>1,'record_id'=>str_repeat('3',32),'classe'=>'aceito','estado'=>'registrado','codigo'=>'importado','message_hash'=>bin2hex(random_bytes(32)),'remetente_hash'=>'','payload'=>'','aviso_em'=>time(),'crm_em'=>time(),'criada_em'=>time()-60,'atualizada_em'=>time()])===1,'review329_pending_move_fixture');
 $r=Review329_Collector::consultar(['simular'=>false,'revisao'=>Review329_Collector::revisao()]);check($r['ok']&&$r['saude']['codigo']==='imap_move_indisponivel'&&$r['saude']['falhas_consecutivas']===1,'review329_movement_error_reaches_health');check(count($mails)===1&&$mails[0]['to']==='technical329@example.test'&&$http===0,'review329_movement_first_error_technical_email_only');
 Review329_Collector::consultar(['simular'=>false,'revisao'=>Review329_Collector::revisao()]);check(count($mails)===1,'review329_movement_incident_deduplicated');
 Review329_Inbox::$fail=false;$r=Review329_Collector::consultar(['simular'=>false,'revisao'=>Review329_Collector::revisao()]);check($r['ok']&&$r['saude']['codigo']===''&&F3Base_Email_Site::row($key)['movida_em']>0,'review329_retry_moves_without_reimport');check(count($mails)===2&&$http===0,'review329_movement_recovery_technical_email_only');
 evidence('review-328-329-1600');
}finally{$wpdb->delete(F3Base_Email_Site::tabela(),['chave'=>$key]);remove_filter('pre_wp_mail',$mail,999);remove_filter('pre_http_request',$block,999);foreach($saved as $n=>$v){if($v===false){delete_option($n);}else{raw($n,$v);}}}
