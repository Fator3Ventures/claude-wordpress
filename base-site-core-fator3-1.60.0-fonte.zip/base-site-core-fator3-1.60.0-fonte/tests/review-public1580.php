<?php
/** Public ability wiring; Meta client seam has no provider I/O or real grants. */
require __DIR__.'/bootstrap.php';wp_get_abilities();
$role=get_role('administrator');$had=$role->has_cap('f3base_ler_leads');$role->add_cap('f3base_ler_leads');wp_set_current_user(1);
$saved=get_option(F3Base_Meta_Ads::OPTION,false);$clientProperty=new ReflectionProperty(F3Base_Meta_Ads::class,'client');$savedClient=$clientProperty->getValue();$http=0;$mail=0;
$deny=static function()use(&$http){++$http;return new WP_Error('review_public_no_http');};$denyMail=static function()use(&$mail){++$mail;return false;};add_filter('pre_http_request',$deny,99999);add_filter('pre_wp_mail',$denyMail,99999);
$client=new class {
 public array $queries=[];
 public function status(array $a): array {return ['success'=>true,'code'=>'ready','data'=>['contract'=>F3Base_Meta_Ads::CONTRACT,'ready'=>true,'grant_revision'=>1]];}
 public function query(array $a): array {$this->queries[]=$a;return ['success'=>true,'data'=>['contract'=>F3Base_Meta_Ads::CONTRACT,'rows'=>[],'generation'=>1,'grant_revision'=>1,'next_cursor'=>isset($a['cursor'])?null:'synthetic-public-page-2','coverage'=>['fixture'=>true]]];}
};
try{
 raw(F3Base_Meta_Ads::OPTION,F3Base_Meta_Ads::padroes());
 $topics=['marcas','meta_ads','identidade_contatos','qualidade_comercial','caminho_lead'];$ability=wp_get_ability(F3Base_Como_Usar::HABILIDADE);check((bool)$ability,'public1580_howto_ability_registered');
 $r=$ability->execute(['compacto'=>true,'assuntos'=>$topics,'incluir'=>[]]);check(!is_wp_error($r)&&($r['versao']??'')===F3BASE_PLUGIN_VERSAO&&array_column($r['assuntos']??[],'id')===$topics,'public1580_howto_new_topics_execute');
 foreach($r['assuntos'] as $topic){check(!empty($topic['options'])&&is_file(F3BASE_PLUGIN_DIR.$topic['documentacao']),'public1580_howto_options_and_doc_'.$topic['id']);}
 $single=$ability->execute(['compacto'=>true,'assuntos'=>['meta_ads'],'incluir'=>[]]);check(!is_wp_error($single)&&array_column($single['assuntos'],'id')===['meta_ads'],'public1580_howto_topic_projection');
 $report=wp_get_ability('f3base/relatorios-integrados-ler');check($report&&in_array('meta_ads',$report->get_input_schema()['properties']['visao']['enum'],true),'public1580_meta_report_registered_in_public_enum');
 $date=gmdate('Y-m-d',time()-2*DAY_IN_SECONDS);$input=['visao'=>'meta_ads','de'=>$date,'ate'=>$date,'limite'=>3];
 $r=$report->execute($input);check(!is_wp_error($r)&&empty($r['ok'])&&$r['codigo']==='configuracao_pendente'&&$r['visao']==='meta_ads','public1580_meta_dispatch_keeps_disabled_state');
 $clientProperty->setValue(null,$client);raw(F3Base_Meta_Ads::OPTION,['ativo'=>true,'conexao'=>'review-public1580','conta_id'=>'15809991','revisao'=>1,'parceiros'=>[]]);
 $r=$report->execute($input);check(!is_wp_error($r)&&$r['ok']&&$r['visao']==='meta_ads'&&$r['fonte']==='Meta Ads / acervo local'&&is_string($r['proximo_cursor']),'public1580_meta_dispatch_local_first_page');
 check(count($client->queries)===1&&$client->queries[0]===['connection_id'=>'review-public1580','account_id'=>'15809991','ads_level'=>'campaign','date_from'=>$date,'date_to'=>$date,'limit'=>3],'public1580_meta_dispatch_preserves_native_query_scope');
 $next=$report->execute($input+['meta_ads_cursor'=>$r['proximo_cursor']]);check(!is_wp_error($next)&&$next['ok']&&$next['pagina_final']&&$next['proximo_cursor']===null&&$client->queries[1]['cursor']==='synthetic-public-page-2','public1580_meta_dispatch_translates_signed_cursor');
 $n=count($client->queries);$r=$report->execute($input+['segmento'=>'sem_testes']);check(!is_wp_error($r)&&empty($r['ok'])&&$r['codigo']==='filtro_nao_suportado_meta_ads'&&count($client->queries)===$n,'public1580_meta_rejects_contact_filters_without_query');
 wp_set_current_user(0);check(F3Base_Como_Usar::responder(['assuntos'=>$topics])['codigo']==='sem_permissao'&&F3Base_Relatorios::consultar($input)['codigo']==='sem_permissao','public1580_anonymous_help_and_report_denied');wp_set_current_user(1);
 check($http===0&&$mail===0,'public1580_no_provider_http_or_mail');evidence('review-public1580');
}finally{
 wp_set_current_user(1);$clientProperty->setValue(null,$savedClient);if($saved===false){delete_option(F3Base_Meta_Ads::OPTION);}else{raw(F3Base_Meta_Ads::OPTION,$saved);}remove_filter('pre_http_request',$deny,99999);remove_filter('pre_wp_mail',$denyMail,99999);if(!$had){$role->remove_cap('f3base_ler_leads');}wp_set_current_user(1);
}
