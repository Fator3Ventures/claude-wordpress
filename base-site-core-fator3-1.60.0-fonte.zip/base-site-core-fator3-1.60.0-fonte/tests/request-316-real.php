<?php
/** Core 1.58 + original Google 0.21 adapter; every provider request is intercepted. */
require __DIR__.'/bootstrap.php';
use Fator3\McpGoogle\{ConversionDelivery as D,Options as O,Connections as C,Settings,Policy,Records,Audit};
wp_get_abilities();global $wpdb;
check(defined('F3_MCP_GOOGLE_VERSION')&&F3_MCP_GOOGLE_VERSION==='0.22.0','316_real_google_021_active');
get_role('administrator')->add_cap('f3base_ler_leads');
$before=$wpdb->get_results($wpdb->prepare('SELECT option_name,option_value,autoload FROM %i WHERE option_name LIKE %s',$wpdb->options,$wpdb->esc_like('f3_mcp_google_').'%'),ARRAY_A);
$oldCore=[];foreach(['f3base_conversoes_transporte','f3base_publicidade'] as $name){$oldCore[$name]=get_option($name,false);}
$oldIdentity=class_exists('Fator3\\McpFiles\\Persistence')?Fator3\McpFiles\Persistence::get('connections','integration:user:1'):null;
$calls=[];$sent=[];$ids=[];$terms=true;$enabled=true;$mode='accepted';
$http=static function($pre,$args,$url)use(&$calls,&$sent,&$terms,&$enabled,&$mode){
    $host=wp_parse_url($url,PHP_URL_HOST);$path=wp_parse_url($url,PHP_URL_PATH);$calls[]=[$host,$path,$args['method']??'GET'];
    $body=is_string($args['body']??null)?json_decode($args['body'],true):($args['body']??[]);$out=[];$c=O::get(D::CONFIG);
    if($host==='oauth2.googleapis.com'&&$path==='/token'){$out=['access_token'=>'synthetic-access-core316','expires_in'=>3600];}
    elseif($host==='googleads.googleapis.com'&&str_ends_with($path,'/googleAds:search')){
        if(str_contains($body['query']??'','FROM customer')){$out=['results'=>[['customer'=>['id'=>$c['customer_id'],'conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>$terms,'enhancedConversionsForLeadsEnabled'=>$enabled]]]]];}
        else{$out=['results'=>[['conversionAction'=>['resourceName'=>$c['conversion_action'],'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>0,'defaultCurrencyCode'=>'BRL']]]]];}
    }
    elseif($host==='datamanager.googleapis.com'&&$path==='/v1/events:ingest'){
        if(empty($body['validateOnly'])){$sent[]=$body;if($mode==='timeout'){return new WP_Error('http_request_failed','Synthetic timeout after dispatch.');}$out=['requestId'=>'core316-'.count($sent)];}
    }
    elseif($host==='datamanager.googleapis.com'&&$path==='/v1/requestStatus:retrieve'){
        $out=['requestStatusPerDestination'=>[['destination'=>Fator3\McpGoogle\Ads\DataManager::destination($c),'requestStatus'=>'SUCCESS','eventsIngestionStatus'=>['recordCount'=>'1']]]];
    }
    else{throw new RuntimeException('Unexpected provider request; real HTTP is forbidden: '.$host.$path);}
    return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($out)];
};
$make=static function(array $click=[],string $traffic='nao_marcado')use(&$ids,$wpdb){
    $id=bin2hex(random_bytes(16));$ids[]=$id;$cap=F3Base_Google_Conversoes::selecionar()['cap'];
    $d=['contexto_teste'=>$traffic==='teste','classe_trafego'=>$traffic,'telefone'=>'+5511999999999','consentimento_snapshot'=>['publicidade'=>true,'medicao'=>true,'politica_versao'=>'legado:core316-real'],'conversoes_transporte'=>['destinos'=>['google_ads'=>'servidor'],'referencias'=>['google_ads'=>$cap['destination_ref']]]];
    if($click){$d['atribuicao']=$click+['ultimo_toque_em'=>time()-120];}
    $l=['record_id'=>$id,'captura'=>'aceito','metodo'=>'formulario','classe_trafego'=>$traffic,'email'=>' First.Last@Gmail.com ','nome'=>'[TESTE F3BASE] adaptador sintético','criado_em'=>gmdate('Y-m-d H:i:s',time()-60),'lixeira'=>0,'eliminacao_pendente'=>0,'dados'=>$d];
    check($wpdb->insert(F3Base_Leads_Repositorio::tabela(),array_replace($l,['dados'=>wp_json_encode($d),'payload_hash'=>hash('sha256',$id),'pagina'=>'/qa-316-real','anexos'=>'[]','revisao'=>1,'atualizado_em'=>gmdate('Y-m-d H:i:s')]))===1,'316_real_fixture_insert_'.count($ids));return $l;
};
try{
    add_filter('pre_http_request',$http,PHP_INT_MAX,3);
    if(class_exists('Fator3\\McpFiles\\Persistence')){Fator3\McpFiles\Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'status'=>'active','profile'=>'maintenance']);}
    $r=O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'core316.apps.googleusercontent.com',C::SERVICES=>['ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-secret-core316',O::OAUTH_REFRESH_TOKEN=>'synthetic-refresh-core316',O::ADS_DEVELOPER_TOKEN=>'synthetic-developer-core316']);
    check(!empty($r['success']),'316_real_synthetic_google_setup');
    $r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/316']]);
    check(!empty($r['success']),'316_real_google_configured');
    $r=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);
    if(empty($r['success'])){throw new RuntimeException('Synthetic Google verification failed: '.wp_json_encode($r));}
    check($r['success'],'316_real_account_action_verified');
    $at=count($calls);$selection=F3Base_Google_Conversoes::selecionar();$cap=$selection['cap'];
    check($selection['adapter'] instanceof D&&$cap['contract']===D::CONTRACT&&F3Base_Google_Conversoes::pronta($cap),'316_real_adapter_11_negotiated');
    check(count($calls)===$at,'316_real_capabilities_zero_http');
    $test=$make([],'teste');$at=count($calls);$beforeQueue=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Conversoes_Servidor::tabela());
    $p=F3Base_Google_Conversoes::previa(['record_id'=>$test['record_id']]);
    check($p['codigo']==='trafego_suprimido'&&!$p['envio_realizado']&&!$p['elegivel_envio'],'316_real_test_preview_only');
    check($p['userIdentifiers']===[['hashedEmail'=>hash('sha256','firstlast@gmail.com')],['hashedPhoneNumber'=>hash('sha256','+5511999999999')]],'316_real_preview_hash_matches_provider');
    check(count($calls)===$at&&(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Conversoes_Servidor::tabela())===$beforeQueue,'316_real_preview_no_effects');
    foreach([[],['gclid'=>'synthetic-gclid316'],['gbraid'=>'synthetic-gbraid316'],['wbraid'=>'synthetic-wbraid316']] as $i=>$click){
        $lead=$make($click);$prep=F3Base_Conversoes_Servidor::preparar($lead,'google_ads',$cap);
        check(!empty($prep['ok'])&&$prep['payload']['user_data']===['email'=>'first.last@gmail.com','telefone'=>'+5511999999999'],'316_real_normalized_identity_'.$i);
        F3Base_Conversoes_Servidor::capturar($lead,'google_ads');F3Base_Conversoes_Servidor::processar();
        $q=F3Base_Conversoes_Servidor::ler(['record_id'=>$lead['record_id']])['entregas'][0];$body=end($sent);$event=$body['events'][0];
        check($q['estado']==='incerto'&&$q['codigo']==='data_manager_pending','316_real_async_receipt_'.$i);
        check($body['encoding']==='HEX'&&$event['userData']['userIdentifiers']===[['emailAddress'=>hash('sha256','firstlast@gmail.com')],['phoneNumber'=>hash('sha256','+5511999999999')]],'316_real_wire_sha256_'.$i);
        check(($event['adIdentifiers']??[])===$click&&$event['transactionId']===$lead['record_id']&&$event['consent']['adUserData']==='CONSENT_GRANTED','316_real_wire_click_consent_identity_'.$i);
        $at=count($sent);F3Base_Conversoes_Servidor::processar();check(count($sent)===$at,'316_real_incerto_not_resent_'.$i);
    }
    $first=$ids[1];$key=hash('sha256','default|'.$first);$receipt=Records::get('conversion',$key);$receipt['next_attempt']=time()-1;Records::put('conversion',$key,$receipt);$wpdb->update(F3Base_Conversoes_Servidor::tabela(),['proxima'=>time()-1],['record_id'=>$first]);$at=count($sent);
    F3Base_Conversoes_Servidor::reconciliar();$q=F3Base_Conversoes_Servidor::ler(['record_id'=>$first])['entregas'][0];check($q['estado']==='entregue'&&count($sent)===$at,'316_real_legacy_reconciler_confirms_11_without_resend');
    $terms=false;D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);$cap=F3Base_Google_Conversoes::selecionar()['cap'];
    $lead=$make();$at=count($calls);$p=F3Base_Conversoes_Servidor::preparar($lead,'google_ads',$cap);
    check(!$p['ok']&&$p['codigo']==='enhanced_leads_not_ready'&&$cap['enhanced_leads']['reason']==='customer_data_terms_not_accepted'&&count($calls)===$at,'316_real_terms_missing_no_click_blocked');
    $click=$make(['gclid'=>'synthetic-legacy316']);$p=F3Base_Conversoes_Servidor::preparar($click,'google_ads',$cap);check($p['ok']&&!isset($p['payload']['user_data']),'316_real_click_only_unchanged');
    F3Base_Conversoes_Servidor::capturar($click,'google_ads');F3Base_Conversoes_Servidor::processar();check(!isset(end($sent)['events'][0]['userData'])&&!isset(end($sent)['encoding']),'316_real_legacy_wire_no_personal_data');
    $terms=true;$enabled=false;D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);$cap=F3Base_Google_Conversoes::selecionar()['cap'];check(!F3Base_Google_Conversoes::pronta($cap)&&$cap['enhanced_leads']['reason']==='enhanced_leads_disabled','316_real_enabled_flag_required');
    $enabled=true;D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);$lead=$make();$bad=$lead;$bad['dados']['consentimento_snapshot']['publicidade']=false;$at=count($calls);
    check(F3Base_Conversoes_Servidor::preparar($bad,'google_ads')['codigo']==='consentimento_nao_permite'&&count($calls)===$at,'316_real_snapshot_consent_blocks_before_http');
    $mode='timeout';F3Base_Conversoes_Servidor::capturar($lead,'google_ads');F3Base_Conversoes_Servidor::processar();$at=count($sent);F3Base_Conversoes_Servidor::processar();$q=F3Base_Conversoes_Servidor::ler(['record_id'=>$lead['record_id']])['entregas'][0];check($q['estado']==='incerto'&&$q['codigo']==='data_manager_receipt_unknown'&&count($sent)===$at,'316_real_timeout_never_replayed');
    $c=O::get(D::CONFIG);$c['verified']['google_ads']['expires']=time()-1;O::set(D::CONFIG,$c);check(!F3Base_Google_Conversoes::pronta(F3Base_Google_Conversoes::selecionar()['cap']),'316_real_expired_proof_blocks');
    $c['verified']['google_ads']['expires']=time()+600;$c['granted_by_target']['google_ads']=0;O::set(D::CONFIG,$c);check(!F3Base_Google_Conversoes::pronta(F3Base_Google_Conversoes::selecionar()['cap']),'316_real_revoked_grant_blocks');
    $safe=wp_json_encode([Records::list('conversion',100),Audit::recent(100),O::get(D::CONFIG),F3Base_Conversoes_Servidor::ler(['record_id'=>$lead['record_id']])]);
    foreach(['First.Last','first.last@gmail.com','firstlast@gmail.com','5511999999999',hash('sha256','firstlast@gmail.com'),hash('sha256','+5511999999999')] as $i=>$needle){check(!str_contains($safe,$needle),'316_real_durable_receipts_no_identifier_'.$i);}
    evidence('request-316-real');
}finally{
    remove_filter('pre_http_request',$http,PHP_INT_MAX);wp_set_current_user(1);
    foreach($ids as $id){Records::remove('conversion',hash('sha256','default|'.$id));$wpdb->delete(F3Base_Conversoes_Servidor::tabela(),['record_id'=>$id]);$wpdb->delete(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id]);}
    $names=$wpdb->get_col($wpdb->prepare('SELECT option_name FROM %i WHERE option_name LIKE %s',$wpdb->options,$wpdb->esc_like('f3_mcp_google_').'%'));foreach($names as $name){delete_option($name);}foreach($before as $row){$wpdb->insert($wpdb->options,$row);wp_cache_delete($row['option_name'],'options');}
    wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');foreach($oldCore as $n=>$v){raw($n,$v);}
    if(class_exists('Fator3\\McpFiles\\Persistence')){if($oldIdentity){Fator3\McpFiles\Persistence::put('connections','integration:user:1',$oldIdentity);}else{Fator3\McpFiles\Persistence::delete('connections','integration:user:1');}}
}
