<?php
/** Installed companion contracts; no provider calls and no scheduling repair on reads. */
require __DIR__.'/bootstrap.php';
use Fator3\Meta as M;
use Fator3\LinkedIn as L;
use Fator3\McpFiles\Persistence as P;
get_role('administrator')->add_cap('f3base_ler_leads');
$app=null;$connection=null;$owned=[];$calls=0;
$http=static function()use(&$calls){++$calls;return new WP_Error('qa_local_only','No provider request is allowed.');};
try{
    if(class_exists(P::class)){
        $app=WP_Application_Passwords::create_new_application_password(1,['name'=>'QA1580 companion reads temporary']);
        if(is_wp_error($app)){throw new RuntimeException('Cannot create temporary native authentication.');}
        $connection='app:'.$app[1]['uuid'];P::put('connections',$connection,['connection_id'=>$connection,'user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);do_action('application_password_did_authenticate',get_user_by('id',1),$app[1]);
    }
    wp_get_abilities();add_filter('pre_http_request',$http,PHP_INT_MIN,3);
    check(defined('F3_MCP_FILES_VERSION')&&F3_MCP_FILES_VERSION==='0.34.0','companions_mcp0340');
    check(defined('F3_MCP_GOOGLE_VERSION')&&F3_MCP_GOOGLE_VERSION==='0.22.0','companions_google0210');
    check(M\Config::VERSION==='0.13.0','companions_meta0130');check(L\Config::VERSION==='0.12.0','companions_linkedin0110');
    $inputs=['meta/health'=>[],'meta/list-connections'=>['offset'=>0],'google/status'=>['compact'=>true,'scope'=>'all_connections'],'linkedin/status'=>[],'linkedin/diagnose-conversions'=>[]];
    foreach($inputs as $name=>$input){$ability=wp_get_ability($name);check((bool)$ability,'companion_ability_'.$name);check(!is_wp_error(rest_validate_value_from_schema($input,$ability->get_input_schema())),'companion_input_schema_'.$name);$r=F3Base_Midia_Prontidao::publica($name,$input);if(empty($r['ok'])){throw new RuntimeException('Public local read rejected: '.$name.' '.wp_json_encode($r));}check($r['ok'],'companion_local_read_'.$name);}
    $base=M\Worker::health();$suffix=bin2hex(random_bytes(4));$meta='qa1580meta'.$suffix;$li='qa1580li'.$suffix;$now=time();
    $seed=['label'=>'[TESTE F3BASE] credential expiry','token'=>'synthetic-token-1580-no-network','client_id'=>'synthetic-app-1580','client_secret'=>'synthetic-secret-1580','application_id'=>'synthetic-app-1580','enabled'=>true,'expires_at'=>$now+8*DAY_IN_SECONDS,'users'=>[1],'assets'=>[],'forms'=>[],'created_by'=>1,'updated_by'=>1,'created_at'=>$now,'updated_at'=>$now,'retention_days'=>90,'authorization_revision'=>1,'credential_generation'=>1,'remote_proof'=>null,'token_identity'=>null];
    M\Store::put('connection',$meta,$seed+['id'=>$meta,'api_version'=>M\Config::API_VERSION]);$owned[]=[M\Store::class,'connection',$meta];
    $seed['expires_at']=$now+11*DAY_IN_SECONDS;L\Store::put('connection',$li,$seed+['id'=>$li,'api_version'=>L\Config::API_VERSION]);$owned[]=[L\Store::class,'connection',$li];
    foreach(['partial','failed'] as $state){$id='qa1580-'.$state.'-'.$suffix;$v=['enabled'=>true,'label'=>'[TESTE F3BASE] '.$state,'query'=>['connection_id'=>$meta,'report'=>'account_insights'],'next_at'=>$now+3600,'interval_minutes'=>60,'last_run_status'=>$state,'last_code'=>$state==='failed'?'metric_unavailable':null,'last_successful_rows'=>$state==='partial'?4:0,'unavailable_metrics'=>['follows_and_unfollows'],'last_partial_at'=>$state==='partial'?$now:null];M\Store::put('schedule',$id,$v);$owned[]=[M\Store::class,'schedule',$id];}
    $cron=serialize(_get_cron_array());$before=F3Base_Options::revisao('f3base_pipedrive');$health=F3Base_Midia_Prontidao::publica('meta/health')['dados'];
    check($health['partial_schedules']===$base['partial_schedules']+1&&$health['failed_schedules']===$base['failed_schedules']+1,'324_meta_partial_and_failed_are_separate');
    $media=F3Base_Midia_Prontidao::ler();check($media['ok']&&count($media['plataformas'])===3,'321_real_three_platforms');
    foreach($media['plataformas'] as $platform=>$rows){foreach($rows['linhas'] as $line){check(!empty($line['fonte'])&&($line['estado']==='pronto'||!empty($line['acao'])),'321_real_source_action_'.$platform.'_'.$line['id']);}}
    $r=F3Base_Resumo_Operacional::ler();$json=wp_json_encode($r);check(strlen($json)<=4096,'324_real_bounded_response');
    foreach(['pacotes','atualizacao','recuperacao','cron_24h','avisos','perfil','caixa','filas','prontidao','credenciais','contatos'] as $group){check(isset($r[$group]['detalhe']),'324_real_detail_'.$group);}
    $pack=$r['prontidao']['plataformas']['meta_pacote'];check($pack['estado']===$health['state']&&$pack['agendas_parciais']===$health['partial_schedules']&&$pack['agendas_falhas']===$health['failed_schedules'],'324_real_meta_state_partial_failure_match');
    $creds=F3Base_Resumo_Operacional::credenciais();$map=[];foreach($creds['credenciais'] as $c){$map[$c['provedor'].'|'.$c['id']]=$c;}
    check(($map['meta|'.$meta]['expira_em']??null)===$now+8*DAY_IN_SECONDS&&$map['meta|'.$meta]['dias']===8,'324_real_meta_expiry');
    check(($map['linkedin|'.$li]['expira_em']??null)===$now+11*DAY_IN_SECONDS&&$map['linkedin|'.$li]['dias']===11,'324_real_linkedin_expiry');
    check($creds['cobertura']['google']!=='pacote_ou_ability_ausente'&&$creds['cobertura']['meta']!=='pacote_ou_ability_ausente'&&$creds['cobertura']['linkedin']!=='pacote_ou_ability_ausente','324_real_providers_observed');
    foreach($creds['credenciais'] as $c){if($c['provedor']==='google'){check($c['dias']===null&&$c['expira_em']===null,'324_real_google_unknown_expiry_'.$c['id']);}}
    check(!str_contains(wp_json_encode([$r,$creds]),'synthetic-token-1580-no-network')&&!str_contains(wp_json_encode([$r,$creds]),'synthetic-secret-1580'),'324_real_no_credential_material');
    check($r['perfil']['contagens']===F3Base_Config_Perfil::avaliar(['perfil_id'=>F3Base_Config_Perfil::ID])['contadores'],'324_real_profile_matches');check($r['cron_24h']['origens']===F3Base_Execucoes::resumo()['passagens_24h'],'324_real_cron_matches');
    check($before===F3Base_Options::revisao('f3base_pipedrive')&&serialize(_get_cron_array())===$cron,'324_real_read_does_not_configure_or_repair_cron');
    $short=wp_get_ability('f3base/resumo-operacional-ler')->execute(['campos'=>['caixa']]);$payload=is_array($short)?array_diff_key($short,array_flip(['success','request_id','result_contract','runtime_verification'])):[];check(array_keys($payload)===['ok','em','http_fornecedor','caixa']&&$payload['ok']&&!isset($short['pacotes'],$short['credenciais'],$short['prontidao']),'324_real_channel_projection');
    $full=wp_get_ability('f3base/resumo-operacional-ler')->execute([]);check(is_array($full)&&!empty($full['ok'])&&strlen(wp_json_encode($full))<=4096,'324_real_mcp_envelope_under_4kb');
    $short=wp_get_ability('f3base/saude-ler')->execute(['compacto'=>true]);check(!is_wp_error($short)&&isset($short['pacotes'])&&strlen(wp_json_encode($short))<=4096,'324_real_channel_health_compact');
    check($calls===0,'321_324_real_contracts_zero_http');
    file_put_contents(getenv('F3BASE_ROOT').'/evidence/1580/resumo-companions-fixture.json',$json);evidence('companions-321-324');
}finally{
    remove_filter('pre_http_request',$http,PHP_INT_MIN);wp_set_current_user(1);
    foreach(array_reverse($owned) as [$store,$bucket,$id]){$row=$store::get($bucket,$id);if($row){$store::remove($bucket,$id,$row['revision']);}}
    if($app){WP_Application_Passwords::delete_application_password(1,$app[1]['uuid']);P::delete('connections',$connection);}
}
