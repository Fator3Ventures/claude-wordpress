// Real analytics source/minified scripts; synthetic responses, no network.
const fs=require('fs'),path=require('path');
const {JSDOM}=require(process.env.F3_JSDOM||'jsdom');
const root=path.resolve(__dirname,'..'),checks={};
const tick=()=>new Promise(r=>setTimeout(r,15));
function check(v,n){checks[n]=!!v;if(!v)throw new Error(n);}
async function run(variant,twice){
 const dom=new JSDOM('<!doctype html><html><body></body></html>',{runScripts:'outside-only',url:'https://fixture332.example.test/',pretendToBeVisual:true}),w=dom.window;
 const key=variant+':'+(twice?'double':'renew'),sent=[],forced=[];let current='expired';
 w.TextEncoder=TextEncoder;w.AbortController=AbortController;w.matchMedia=()=>({matches:false});
 w.f3baseAnaliseDados={endpoint:'/analytics',caminho:'/',token:'expired'};
 w.f3baseTracking={permiteTags:()=>true,sessao:()=>'a'.repeat(32),visitante:()=>'b'.repeat(32)};
 w.f3baseContexto={teste:()=>false,navegacao:()=>({navegacao:'c'.repeat(32),anterior:''}),sinais:()=>({}),audiencia:()=>({}),atribuicao:()=>({}),token:async(c,force)=>{if(force){forced.push(true);current='fresh';}return current;}};
 w.fetch=async(url,options)=>{
  const body=JSON.parse(options.body);sent.push(body);
  const rejected=sent.length===1||twice;
  return {status:rejected?403:200,headers:{get:()=>null},text:async()=>JSON.stringify(rejected?{ok:false,codigo:'token_invalido',renovacao:'signed-fixture-proof'}:{ok:true,confirmados:body.eventos.map(e=>({evento:e.evento,sequencia:e.sequencia}))})};
 };
 w.eval(fs.readFileSync(path.join(root,'work/plugin/base-site-core-fator3/assets/f3base-analise'+variant+'.js'),'utf8'));
 w.document.dispatchEvent(new w.Event('DOMContentLoaded'));await tick();w.dispatchEvent(new w.Event('pagehide'));await tick();await tick();
 check(sent.length===2,key+':one_retry');check(forced.length===1,key+':one_forced_refresh');
 check(sent[0].token==='expired'&&sent[1].token==='fresh',key+':fresh_token_used');
 check(JSON.stringify(sent[0].eventos)===JSON.stringify(sent[1].eventos),key+':same_events');
 check(sent[0].renovacao===''&&sent[1].renovacao==='signed-fixture-proof',key+':proof_forwarded');
 const state=w.f3baseAnalise.diagnostico();
 if(twice){check(state.pendentes>0&&state.contagens.falhas===1&&state.proxima_tentativa>Date.now(),key+':second_403_backoff');}
 else{
  check(state.pendentes===0&&state.contagens.confirmados>0,key+':ack_clears_queue');
  w.f3baseAnalise.oferta('oferta_exibida',{oferta:'fixture'});w.dispatchEvent(new w.Event('pagehide'));await tick();
  check(sent.length===3&&sent[2].renovacao==='',key+':proof_cleared_after_success');
 }
 w.close();
}
(async()=>{for(const v of ['','.min'])for(const twice of [false,true])await run(v,twice);fs.writeFileSync(path.join(root,'evidence/1600/request-332-dom.json'),JSON.stringify({ambiente:'jsdom 27.4.0; real source/minified; synthetic HTTP',checks},null,2)+'\n');console.log(Object.keys(checks).length+' checks OK');})().catch(e=>{console.error(e);process.exit(1);});
