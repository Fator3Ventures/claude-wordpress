<?php
/** A non-local capabilities implementation still cannot dispatch HTTP from readiness. */
require __DIR__.'/bootstrap.php';wp_get_abilities();
$attempts=0;$errors=[];
$fake=static function($old,$target,$contract)use(&$attempts,&$errors){
    if($target!=='google_ads'){return $old;}
    return new class($attempts,$errors,$contract){
        private $attempts;private $errors;
        public function __construct(&$attempts,&$errors,private string $contract){$this->attempts=&$attempts;$this->errors=&$errors;}
        public function capabilities(): array {++$this->attempts;$r=wp_remote_get('https://example.invalid/qa-readiness-http-forbidden');$this->errors[]=is_wp_error($r)?$r->get_error_code():'unexpected_response';return ['contract'=>$this->contract,'ready'=>false,'reason'=>'fixture_nonlocal_capability'];}
        public function send(array $p): array {throw new RuntimeException('Readiness must not dispatch conversions.');}
    };
};
$before=count($GLOBALS['wp_filter']['pre_http_request']->callbacks[PHP_INT_MAX]??[]);
try{
    add_filter('f3base_conversoes_adaptador',$fake,1,3);$r=F3Base_Midia_Prontidao::ler();
    check($r['ok']&&$r['http_fornecedor']===false,'321_nonlocal_capability_read_completes');
    check($attempts>0&&!array_diff($errors,['f3base_leitura_local']),'321_capability_http_shortcircuited');
    check(count($GLOBALS['wp_filter']['pre_http_request']->callbacks[PHP_INT_MAX]??[])===$before,'321_http_guard_removed_after_read');
    evidence('request-321-no-http');
}finally{remove_filter('f3base_conversoes_adaptador',$fake,1);}
