"""Local-only SMTP fixture: DNS resolves, SMTP is replaced in request-327.php.

No socket is opened to this address. Remove exactly our hosts line in finally.
Needs disposable/root lab; existing hosts entries are preserved.
"""
from pathlib import Path
import subprocess
import sys

hosts = Path('/etc/hosts')
line = '\n93.184.216.34 smtp-327.example.test # f3base-core1580-smtp-fixture\n'
if 'smtp-327.example.test' in hosts.read_text():
    raise SystemExit('SMTP fixture hostname already exists; reconcile first')
try:
    with hosts.open('a') as stream:
        stream.write(line)
    result = subprocess.run([sys.executable, str(Path(__file__).with_name('run-lab.py')), 'tests/request-327.php'])
finally:
    content = hosts.read_text()
    if content.count(line) == 1:
        hosts.write_text(content.replace(line, '', 1))
    else:
        raise RuntimeError('Hosts changed unexpectedly; fixture cleanup requires inspection')
raise SystemExit(result.returncode)
