<?php
/** Oversized fixed groups and MCP envelope; no provider I/O. */
require __DIR__.'/bootstrap.php';
use Fator3\McpFiles\Persistence as P;
$app=null;$connection=null;
$old=get_option(F3Base_Wp_Mail::STATE,false);$calls=0;$deny=static function()use(&$calls){++$calls;return new WP_Error('review324_no_http');};add_filter('pre_http_request',$deny,99999);
try{
 if(class_exists(P::class)){
  $app=WP_Application_Passwords::create_new_application_password(1,['name'=>'QA1580 summary bound temporary']);
  if(is_wp_error($app)){throw new RuntimeException('Cannot create temporary native authentication.');}
  $connection='app:'.$app[1]['uuid'];P::put('connections',$connection,['connection_id'=>$connection,'user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);
  do_action('application_password_did_authenticate',get_user_by('id',1),$app[1]);
 }
 wp_get_abilities();
 $base=F3Base_Resumo_Operacional::ler();$groups=['pacotes','atualizacao','recuperacao','cron_24h','avisos','perfil','caixa','filas','prontidao','credenciais','contatos'];
 $limit=new ReflectionMethod(F3Base_Resumo_Operacional::class,'limitar');check($limit->invoke(null,$base)===$base,'review324_already_bounded_response_unchanged');
 $large=$base;$large['pacotes']['valores']=[];$large['credenciais']['itens']=[];$text=str_repeat('"Código\\dados çã" ',700);
 foreach($groups as $group){$large[$group]['codigo_sintetico']=$text;$large[$group]['contagens_sinteticas']=array_fill(0,100,PHP_INT_MAX);}
 check(strlen(wp_json_encode($large))>4096&&$large['pacotes']['valores']===[]&&$large['credenciais']['itens']===[],'review324_fixed_groups_overflow_even_without_lists');
 $bounded=$limit->invoke(null,$large);$json=wp_json_encode($bounded);check(strlen($json)<=3900&&json_decode($json,true)===$bounded,'review324_large_fixed_groups_valid_json_under_budget');
 $omitted=0;foreach($groups as $group){check(isset($bounded[$group]['detalhe'])&&$bounded[$group]['detalhe']===$base[$group]['detalhe'],'review324_route_retained_'.$group);if(!empty($bounded[$group]['conteudo_omitido'])){++$omitted;check(array_keys($bounded[$group])===['conteudo_omitido','detalhe'],'review324_explicit_whole_group_omission_'.$group);}}
 check($omitted>0&&$bounded['ok']===true&&$bounded['http_fornecedor']===false,'review324_omission_is_not_failure_or_guessed_zero');
 check($limit->invoke(null,$bounded)===$bounded,'review324_fallback_idempotent');
 // This models only the known read-only transport fields; the real decorator is
 // exercised below whenever the MCP package is loaded by the companion runner.
 $modeled=$bounded+['success'=>true,'request_id'=>str_repeat('a',24),'result_contract'=>2];check(strlen(wp_json_encode($modeled))<=4096,'review324_modeled_readonly_mcp_envelope_under_4096');
 $ability=wp_get_ability('f3base/resumo-operacional-ler');
 if(class_exists('Fator3\\McpFiles\\AbilityRuntime')){
  $meta=$ability->get_meta();unset($meta['fator3']['decorated']);$args=['meta'=>$meta,'input_schema'=>$ability->get_input_schema(),'output_schema'=>$ability->get_output_schema(),'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>static fn()=>$bounded];
  $decorated=\Fator3\McpFiles\AbilityRuntime::decorate($args,'f3base/resumo-operacional-ler');$actual=$decorated['execute_callback']([]);
  check(!empty($actual['success'])&&isset($actual['request_id'])&&$actual['result_contract']===2&&strlen(wp_json_encode($actual))<=4096,'review324_actual_mcp_decorator_synthetic_overflow_under_4096');
 }
 raw(F3Base_Wp_Mail::STATE,['em'=>time(),'codigo'=>$text,'fase'=>$text]);$actual=$ability->execute([]);
 check(!is_wp_error($actual)&&!empty($actual['ok'])&&!empty($actual['caixa']['conteudo_omitido'])&&$actual['caixa']['detalhe']===$base['caixa']['detalhe']&&strlen(wp_json_encode($actual))<=4096,'review324_actual_summary_ability_bounds_long_diagnostic');
 $short=$ability->execute(['campos'=>['caixa']]);check(!is_wp_error($short)&&!empty($short['caixa']['conteudo_omitido'])&&!isset($short['prontidao'])&&strlen(wp_json_encode($short))<=4096,'review324_projection_keeps_explicit_omission');
 check($calls===0,'review324_no_provider_http');evidence('review-324-bound');
}finally{remove_filter('pre_http_request',$deny,99999);if($old===false){delete_option(F3Base_Wp_Mail::STATE);}else{raw(F3Base_Wp_Mail::STATE,$old);}if(is_array($app)){WP_Application_Passwords::delete_application_password(1,$app[1]['uuid']);P::delete('connections',$connection);}}
