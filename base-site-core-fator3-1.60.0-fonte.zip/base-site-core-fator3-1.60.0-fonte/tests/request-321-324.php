<?php
require __DIR__.'/bootstrap.php';wp_get_abilities();$calls=0;$http=static function($pre)use(&$calls){++$calls;return $pre;};add_filter('pre_http_request',$http,PHP_INT_MIN);
try{
 $before=F3Base_Options::revisao('f3base_pipedrive');$r=F3Base_Midia_Prontidao::ler();check($r['ok']&&count($r['plataformas'])===3,'321_three_platforms');
 foreach($r['plataformas'] as $p=>$v){check($v['estado']==='bloqueado','321_disabled_'.$p);foreach($v['linhas'] as $line){check(!empty($line['fonte'])&&($line['estado']==='pronto'||!empty($line['acao'])),'321_sources_actions_'.$p.'_'.$line['id']);}}
 check($calls===0&&$before===F3Base_Options::revisao('f3base_pipedrive'),'321_readonly_no_http');
 $r=F3Base_Resumo_Operacional::ler();$j=wp_json_encode($r);file_put_contents(getenv('F3BASE_ROOT').'/evidence/1580/resumo-fixture.json',$j);check(strlen($j)<=4096,'324_bytes_'.strlen($j));
 foreach(['pacotes','atualizacao','recuperacao','cron_24h','avisos','perfil','caixa','filas','prontidao','credenciais','contatos'] as $group){check(isset($r[$group]['detalhe']),'324_detail_'.$group);}
 check($r['perfil']['contagens']===F3Base_Config_Perfil::avaliar(['perfil_id'=>F3Base_Config_Perfil::ID])['contadores'],'324_profile_matches');check($r['cron_24h']['origens']===F3Base_Execucoes::resumo()['passagens_24h'],'324_cron_matches');
 check($r['credenciais']['cobertura']['google']==='pacote_ou_ability_ausente','324_missing_provider_not_ready');
 $short=wp_get_ability('f3base/resumo-operacional-ler')->execute(['campos'=>['caixa']]);check(array_keys($short)===['ok','em','http_fornecedor','caixa'],'324_projection');
 $short=wp_get_ability('f3base/saude-ler')->execute(['compacto'=>true]);check(!is_wp_error($short)&&isset($short['pacotes'])&&strlen(wp_json_encode($short))<=4096,'324_health_compact');
 check($calls===0,'324_zero_provider_http');wp_set_current_user(0);check(!F3Base_Resumo_Operacional::ler()['ok']&&!F3Base_Midia_Prontidao::ler()['ok'],'321_324_admin_only');
 evidence('request-321-324');
}finally{remove_filter('pre_http_request',$http,PHP_INT_MIN);wp_set_current_user(1);}
