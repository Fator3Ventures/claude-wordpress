from pathlib import Path
import os,subprocess,time,http.client,json
root=Path(__file__).resolve().parents[1];site=Path(os.environ['F3BASE_LAB_DIR'])/'wordpress'
server=subprocess.Popen([str(root/'build/php'),'-S','127.0.0.1:8137','-t',str(site),str(site/'index.php')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 for _ in range(60):
  try:
   c=http.client.HTTPConnection('127.0.0.1',8137,timeout=5);c.request('GET','/f3base-teste/',headers={'Host':'wrong.example'});r=c.getresponse();r.read();break
  except OSError:time.sleep(.1)
 checks={};checks['wrong_host_redirects']=r.status==302 and r.getheader('Location')=='http://127.0.0.1:8136/f3base-teste/';checks['wrong_host_no_test_cookie']='f3base_teste' not in str(r.getheaders());c.close()
 c=http.client.HTTPConnection('127.0.0.1',8137,timeout=5);c.request('GET','/f3base-teste/',headers={'Host':'127.0.0.1:8136'});r=c.getresponse();body=r.read().decode();checks['canonical_test_cookie']=r.status==200 and 'f3base_teste=1' in (r.getheader('Set-Cookie') or '') and 'Verificando o cookie' in body
 c.close();assert all(checks.values()),checks
 out=root/os.environ['F3BASE_EVIDENCE_DIR']/'request-333-http.json';out.write_text(json.dumps({'versao':'1.60.0','ambiente':'HTTP WordPress local nativo','checks':checks},indent=2));print('request-333-http:',len(checks),'checks OK')
finally:server.terminate();server.wait(timeout=10)
