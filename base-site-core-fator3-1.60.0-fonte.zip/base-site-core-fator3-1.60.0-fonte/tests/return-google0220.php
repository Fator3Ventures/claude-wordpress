<?php
/** Core 1.59 + original Google 0.22: actual SDK/storage, synthetic transports only. */
require __DIR__.'/bootstrap.php';
use Fator3\McpGoogle\{ConversionDelivery as D,StageConversionDelivery as S,Options as O,Connections as C,Settings,Policy,Records,Audit};
wp_get_abilities();global $wpdb;
check(defined('F3_MCP_GOOGLE_VERSION')&&F3_MCP_GOOGLE_VERSION==='0.22.0','google022_original_provider_active');
$hadReadCapability=get_role('administrator')->has_cap('f3base_ler_leads');get_role('administrator')->add_cap('f3base_ler_leads');
check(F3Base_Qualidade_Destinos::instalar(),'google022_receipt_table');
$before=$wpdb->get_results($wpdb->prepare('SELECT option_name,option_value,autoload FROM %i WHERE option_name LIKE %s',$wpdb->options,$wpdb->esc_like('f3_mcp_google_').'%'),ARRAY_A);
$oldCore=[];foreach(['f3base_qualidade',F3Base_Qualidade_Destinos::OPTION] as $name){$oldCore[$name]=['exists'=>$wpdb->get_var($wpdb->prepare('SELECT option_id FROM %i WHERE option_name=%s',$wpdb->options,$name))!==null,'value'=>get_option($name,false)];}
$oldIdentity=class_exists('Fator3\\McpFiles\\Persistence')?Fator3\McpFiles\Persistence::get('connections','integration:user:1'):null;
$calls=[];$ingests=[];$remote=[];$ids=[];$recordKeys=[];$mailCount=0;$mode='SUCCESS';$recordCount='1';$queryMutation=null;$decorator=null;$capabilityMode='version';
$action='customers/1234567890/conversionActions/159022';$acquisition='customers/1234567890/conversionActions/159001';
$lockName='f3base_trava_'.hash('sha256','qualidade-destinos');$foreignLock=null;
$http=static function($pre,$args,$url)use(&$calls,&$ingests,&$remote,&$mode,&$recordCount,&$queryMutation){
    $host=wp_parse_url($url,PHP_URL_HOST);$path=wp_parse_url($url,PHP_URL_PATH);$calls[]=[$host,$path,$args['method']??'GET'];
    $body=is_string($args['body']??null)?json_decode($args['body'],true):($args['body']??[]);$out=[];
    if($host==='oauth2.googleapis.com'&&$path==='/token'){$out=['access_token'=>'synthetic-google022','expires_in'=>3600];}
    elseif($host==='googleads.googleapis.com'&&str_ends_with($path,'/googleAds:search')){
        if(str_contains($body['query']??'','FROM customer')){$out=['results'=>[['customer'=>['id'=>'1234567890','conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>true,'enhancedConversionsForLeadsEnabled'=>true]]]]];}
        else{preg_match('~customers/[0-9]+/conversionActions/[0-9]+~',$body['query']??'',$m);$out=['results'=>[['conversionAction'=>['resourceName'=>$m[0]??'','type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>25,'defaultCurrencyCode'=>'USD','alwaysUseDefaultValue'=>false]]]]];}
    }elseif($host==='datamanager.googleapis.com'&&$path==='/v1/events:ingest'){
        if(empty($body['validateOnly'])){$ingests[]=$body;$rid='synthetic-core1590-'.count($ingests);$remote[$rid]=$body;$out=['requestId'=>$rid];}
    }elseif($host==='datamanager.googleapis.com'&&$path==='/v1/requestStatus:retrieve'){
        check(($args['method']??'GET')==='GET'&&empty($args['body']),'google022_reconcile_transport_has_no_payload');
        if($queryMutation){$mutation=$queryMutation;$queryMutation=null;$mutation();}
        if($mode==='EXCEPTION'){throw new RuntimeException('Synthetic reconciliation exception');}
        if($mode==='TIMEOUT'){return new WP_Error('http_request_failed','Synthetic query timeout');}
        parse_str((string)wp_parse_url($url,PHP_URL_QUERY),$q);$dest=$remote[$q['requestId']??'']['destinations'][0]??[];
        if($mode==='WRONG_DESTINATION'){$dest['productDestinationId']='999999';}
        $item=['destination'=>$dest,'requestStatus'=>$mode==='WRONG_DESTINATION'?'SUCCESS':$mode,'eventsIngestionStatus'=>['recordCount'=>$recordCount]];
        if($mode==='FAILED'){$item['errorInfo']=['errorCounts'=>[['reason'=>'PROCESSING_ERROR_REASON_INVALID_EVENT','recordCount'=>'1']]];}
        $out=['requestStatusPerDestination'=>[$item]];
    }else{throw new RuntimeException('Forbidden provider transport: '.$host.$path);}
    return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($out)];
};
$mail=static function($pre)use(&$mailCount){++$mailCount;return false;};
$row=static function(string $id):array{return F3Base_Qualidade_Destinos::ler($id)[0]??[];};
$event=static fn(string $id):string=>'f3q-'.hash('sha256',get_current_blog_id().'|'.$id.'|google_ads|qualificado');
$providerKey=static fn(string $id):string=>hash('sha256','stage|'.get_current_blog_id().'|stage:'.hash('sha256',S::CONSUMER.'|'.$action.'|'.$event($id)));
$run=static function():array{F3Base_Execucoes::encerrar();return F3Base_Qualidade_Destinos::processar();};
$due=static function(string $id,bool $producer=true)use($wpdb,$providerKey){
    $wpdb->update(F3Base_Qualidade_Destinos::tabela(),['atualizado_em'=>time()-1801],['record_id'=>$id]);
    if($producer){$key=$providerKey($id);$r=Records::get('conversion',$key);if($r){$r['next_attempt']=time()-1;Records::put('conversion',$key,$r);}}
};
$make=static function()use(&$ids,$wpdb):array{
    $id=bin2hex(random_bytes(16));$ids[]=$id;
    $d=['classe_trafego'=>'nao_marcado','contexto_teste'=>false,'telefone'=>'+5511999999999','consentimento_snapshot'=>['publicidade'=>true,'politica_versao'=>'legado:google022'],'atribuicao'=>['gclid'=>'synthetic-core1590-click','ultimo_toque_em'=>time()-100]];
    $l=['record_id'=>$id,'captura'=>'aceito','metodo'=>'formulario','classe_trafego'=>'nao_marcado','email'=>'core1590@example.test','nome'=>'[TESTE F3BASE] Google022','criado_em'=>gmdate('Y-m-d H:i:s',time()-60),'lixeira'=>0,'eliminacao_pendente'=>0,'dados'=>$d];
    check($wpdb->insert(F3Base_Leads_Repositorio::tabela(),array_replace($l,['dados'=>wp_json_encode($d),'payload_hash'=>hash('sha256',$id),'anexos'=>'[]','revisao'=>1,'atualizado_em'=>gmdate('Y-m-d H:i:s')]))===1,'google022_fixture_contact_'.count($ids));return $l;
};
$send=static function()use($make,$run,$row,$providerKey,&$recordKeys):array{
    $lead=$make();check(F3Base_Qualidade_Destinos::registrar($lead,'qualificado',time()),'google022_fixture_reserve_'.count($recordKeys));$recordKeys[]=$providerKey($lead['record_id']);
    $r=$run();check($r['processados']===1&&$row($lead['record_id'])['estado']==='incerto','google022_fixture_ingest_'.count($recordKeys));return $lead;
};
try{
    add_filter('pre_http_request',$http,PHP_INT_MAX,3);add_filter('pre_wp_mail',$mail,PHP_INT_MAX);
    if(class_exists('Fator3\\McpFiles\\Persistence')){Fator3\McpFiles\Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'status'=>'active','profile'=>'maintenance']);}
    $r=O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'core1590.apps.googleusercontent.com',C::SERVICES=>['ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-core1590',O::OAUTH_REFRESH_TOKEN=>'synthetic-core1590',O::ADS_DEVELOPER_TOKEN=>'synthetic-core1590']);
    check(!empty($r['success']),'google022_synthetic_identity');O::set(D::CONFIG,D::defaults());
    check(!empty(D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>$acquisition]])['success']),'google022_acquisition_configured');
    check(!empty(D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads'])['success']),'google022_acquisition_verified');
    check(!empty(S::configure(['expected_revision'=>D::revision(),'action'=>$action,'enabled'=>true])['success']),'google022_independent_commercial_grant');
    check(!empty(S::verify(['expected_revision'=>D::revision(),'action'=>$action])['verified']),'google022_commercial_verified');
    $grantSnapshot=O::get(D::CONFIG);
    $q=F3Base_Qualidade::padrao();$q['ativo']=true;$q['etapas']=[['id'=>'qualificado','nome'=>'Qualificado','evento_meta'=>'']];raw('f3base_qualidade',$q);
    $cfg=F3Base_Qualidade_Destinos::padroes();$cfg['google_ads']=['ativo'=>true,'acoes'=>['qualificado'=>$action]];raw(F3Base_Qualidade_Destinos::OPTION,$cfg);
    $n=count($calls);$selection=F3Base_Qualidade_Destinos::adaptador('google_ads',$action);
    check(!empty($selection['ok'])&&$selection['adapter'] instanceof S&&$selection['cap']['async_reconciliation']===F3Base_Qualidade_Destinos::RECONCILE,'google022_actual_12_and_extension_selected');
    check(count($calls)===$n,'google022_capabilities_local');$reference=$selection['referencia'];
    $lead=$make();$id=$lead['record_id'];$n=count($calls);$countBefore=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Qualidade_Destinos::tabela());
    $preview=F3Base_Qualidade_Destinos::previa(['record_id'=>$id,'etapa'=>'qualificado']);
    check(!empty($preview['destinos']['google_ads']['elegivel'])&&count($calls)===$n&&(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Qualidade_Destinos::tabela())===$countBefore,'google022_preview_no_http_no_queue');
    check(!str_contains(wp_json_encode($preview),'core1590@example.test')&&!str_contains(wp_json_encode($preview),'synthetic-core1590-click'),'google022_preview_hides_identifiers');
    check(F3Base_Qualidade_Destinos::registrar($lead,'qualificado',time()),'google022_real_consumer_reserves');$recordKeys[]=$providerKey($id);$r=$run();$initial=$row($id);$wire=end($ingests);
    check($r['processados']===1&&$initial['estado']==='incerto'&&$initial['codigo']==='data_manager_pending','google022_accepted_ingestion_stays_uncertain');
    check($wire['destinations'][0]['productDestinationId']==='159022'&&$wire['events'][0]['transactionId']===$event($id)&&$wire['events'][0]['conversionValue']==0&&$wire['events'][0]['currency']==='BRL','google022_exact_action_event_zero_brl');
    $n=count($calls);$sent=count($ingests);$r=$run();check($r['reconciliados']===0&&count($calls)===$n&&count($ingests)===$sent,'google022_initial_cooldown_no_reingestion');
    $wpdb->update(F3Base_Qualidade_Destinos::tabela(),['atualizado_em'=>time()-1790],['record_id'=>$id]);$r=$run();check($r['reconciliados']===0&&count($calls)===$n,'google022_minimum_1800_seconds');
    $due($id);$mode='PROCESSING';$r=$run();check($r['reconciliados']===1&&$row($id)['estado']==='incerto'&&count($ingests)===$sent,'google022_processing_remains_uncertain');
    $n=count($calls);$r=$run();check($r['reconciliados']===0&&count($calls)===$n,'google022_interval_reserved_before_query');
    $due($id,false);$r=$run();check($r['reconciliados']===1&&count($calls)===$n,'google022_producer_backoff_prevents_early_http');
    $due($id);$recordCount='2';$mode='SUCCESS';$run();check($row($id)['estado']==='incerto','google022_multiple_events_not_confirmation');
    $due($id);$recordCount='1';$mode='WRONG_DESTINATION';$run();check($row($id)['estado']==='incerto','google022_wrong_destination_not_confirmation');
    $expired=$grantSnapshot;$expired['stage_actions'][$action]['proof']['expires']=time()-1;O::set(D::CONFIG,$expired);
    check(empty(F3Base_Qualidade_Destinos::adaptador('google_ads',$action)['ok'])&&!empty(F3Base_Qualidade_Destinos::adaptador('google_ads',$action,true)['ok']),'google022_expired_send_proof_query_only');
    // A query concerns the already dispatched event and never reconstructs a contact payload.
    $wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>'{}','email'=>'','classe_trafego'=>'teste'],['record_id'=>$id]);
    $due($id);$mode='SUCCESS';$r=$run();$confirmed=$row($id);
    check($r['reconciliados']===1&&$confirmed['estado']==='entregue'&&$confirmed['codigo']==='data_manager_confirmed'&&$confirmed['ocorreu_em']===$initial['ocorreu_em']&&count($ingests)===$sent,'google022_same_receipt_confirmed_without_payload_or_reingestion');
    $n=count($calls);$due($id);$run();check(count($calls)===$n,'google022_confirmed_receipt_not_queried_again');O::set(D::CONFIG,$grantSnapshot);
    $lead=$send();$id=$lead['record_id'];$due($id);$mode='FAILED';$run();check($row($id)['estado']==='recusado'&&$row($id)['codigo']==='data_manager_rejected','google022_proven_non_delivery_refused');
    $lead=$send();$id=$lead['record_id'];$due($id);$mode='TIMEOUT';$sent=count($ingests);$run();check($row($id)['estado']==='incerto'&&count($ingests)===$sent,'google022_timeout_keeps_uncertain');
    $due($id);$mode='EXCEPTION';$run();check($row($id)['estado']==='incerto','google022_provider_exception_keeps_uncertain');$n=count($calls);$run();check(count($calls)===$n,'google022_exception_keeps_cooldown');$mode='SUCCESS';
    $due($id);S::configure(['expected_revision'=>D::revision(),'action'=>$action,'enabled'=>false]);$n=count($calls);$run();check($row($id)['estado']==='incerto'&&count($calls)===$n,'google022_revoked_grant_no_query');
    S::configure(['expected_revision'=>D::revision(),'action'=>$action,'enabled'=>true]);S::verify(['expected_revision'=>D::revision(),'action'=>$action]);$due($id);$n=count($calls);$run();
    check(F3Base_Qualidade_Destinos::adaptador('google_ads',$action)['referencia']!==$reference&&$row($id)['estado']==='incerto'&&count($calls)===$n,'google022_new_generation_cannot_query_old_binding');O::set(D::CONFIG,$grantSnapshot);
    $changed=$cfg;$changed['google_ads']['ativo']=false;raw(F3Base_Qualidade_Destinos::OPTION,$changed);$due($id);$n=count($calls);$run();check($row($id)['estado']==='incerto'&&count($calls)===$n,'google022_disabled_destination_no_query');raw(F3Base_Qualidade_Destinos::OPTION,$cfg);
    $oldClient=O::get(O::OAUTH_CLIENT_ID);O::set(O::OAUTH_CLIENT_ID,'changed.apps.googleusercontent.com');$due($id);$n=count($calls);$run();check($row($id)['estado']==='incerto'&&count($calls)===$n,'google022_changed_identity_no_query');O::set(O::OAUTH_CLIENT_ID,$oldClient);
    // Only capability metadata is decorated; all dispatch/query methods remain the actual SDK.
    $decorator=static function($a,$target,$contract)use(&$capabilityMode) {if($target!=='google_ads'||$contract!==S::CONTRACT||!$a instanceof S){return $a;}return new class($a,$capabilityMode){private $mode;function __construct(private S $real,&$mode){$this->mode=&$mode;}function capabilities(){ $c=$this->real->capabilities();if($this->mode==='version'){$c['async_reconciliation']='site-stage-conversion-reconcile/9.0.0';}elseif($this->mode==='global'){$c['reason']='stage_grant_revoked';}elseif($this->mode==='unready'){$c['ready']=false;}return $c;}function sendBound($p,$r){return $this->real->sendBound($p,$r);}function reconcileBound($e,$r){if($this->mode==='exception'){throw new RuntimeException('Synthetic SDK exception');}return $this->real->reconcileBound($e,$r);}};};
    add_filter('f3base_conversoes_adaptador',$decorator,PHP_INT_MAX,3);
    foreach(['version','global','unready'] as $capabilityMode){$due($id);$n=count($calls);$run();check($row($id)['estado']==='incerto'&&count($calls)===$n,'google022_invalid_capability_no_query_'.$capabilityMode);}
    $capabilityMode='exception';$due($id);$n=count($calls);$run();check($row($id)['estado']==='incerto'&&$row($id)['codigo']==='reconciliacao_indisponivel'&&count($calls)===$n,'google022_sdk_exception_no_transport_or_terminal_state');$run();check(count($calls)===$n,'google022_sdk_exception_reserves_interval');
    remove_filter('f3base_conversoes_adaptador',$decorator,PHP_INT_MAX);$decorator=null;
    $due($id);$held=F3Base_Trava::adquirir('qualidade-destinos',120);$n=count($calls);try{$r=$run();check($r['codigo']==='ocupado'&&count($calls)===$n,'google022_contended_lease_no_query');}finally{F3Base_Trava::liberar($held);}
    $queryMutation=static function()use($lockName,&$foreignLock){$foreignLock=['nome'=>$lockName,'valor'=>['dono'=>'synthetic-foreign-core1590','expira'=>time()+120]];raw($lockName,$foreignLock['valor']);};
    $run();check($row($id)['estado']==='incerto'&&get_option($lockName)===$foreignLock['valor'],'google022_lost_lease_cannot_commit_or_release_other_owner');F3Base_Trava::liberar($foreignLock);$foreignLock=null;
    $n=count($calls);$due($id,false);$r=$run();check($row($id)['estado']==='entregue'&&count($calls)===$n,'google022_recovery_reads_confirmed_provider_receipt_no_ingestion');
    $lead=$send();$id=$lead['record_id'];$due($id);$queryMutation=static function()use($wpdb,$id){$wpdb->update(F3Base_Qualidade_Destinos::tabela(),['atualizado_em'=>time()+10,'codigo'=>'synthetic_concurrent_update'],['record_id'=>$id]);};$run();
    check($row($id)['estado']==='incerto'&&$row($id)['codigo']==='synthetic_concurrent_update','google022_final_cas_preserves_concurrent_receipt');$due($id,false);$run();check($row($id)['estado']==='entregue','google022_cas_recovery_query_only');
    $lead=$send();$id=$lead['record_id'];$due($id);$queryMutation=static function()use($changed){raw(F3Base_Qualidade_Destinos::OPTION,$changed);};$run();
    check($row($id)['estado']==='incerto'&&$row($id)['codigo']==='reconciliacao_configuracao_alterada','google022_changed_core_config_during_query_not_committed');raw(F3Base_Qualidade_Destinos::OPTION,$cfg);$due($id,false);$run();check($row($id)['estado']==='entregue','google022_config_restore_uses_existing_receipt');
    $batch=[];for($i=0;$i<3;++$i){$l=$send();$batch[]=$l['record_id'];}foreach($batch as $id){$due($id);}$sent=count($ingests);$r=$run();
    check($r['reconciliados']===2&&count(array_filter($batch,static fn($id)=>$row($id)['estado']==='entregue'))===2,'google022_at_most_two_queries_per_pass');$r=$run();check($r['reconciliados']===1&&count($ingests)===$sent,'google022_remaining_receipt_next_pass_no_reingestion');
    $safe=wp_json_encode([Records::list('conversion',1000),Audit::recent(1000),O::get(D::CONFIG)]);
    foreach(['core1590@example.test','synthetic-core1590-click',hash('sha256','core1590@example.test'),hash('sha256','+5511999999999')] as $i=>$needle){check(!str_contains($safe,$needle),'google022_durable_provider_state_without_identity_'.$i);}
    check($mailCount===0,'google022_zero_mail');evidence('return-google0220');
}finally{
    remove_filter('pre_http_request',$http,PHP_INT_MAX);remove_filter('pre_wp_mail',$mail,PHP_INT_MAX);if($decorator){remove_filter('f3base_conversoes_adaptador',$decorator,PHP_INT_MAX);}if($foreignLock){F3Base_Trava::liberar($foreignLock);}wp_set_current_user(1);
    foreach($recordKeys as $key){Records::remove('conversion',$key);}foreach($ids as $id){$wpdb->delete(F3Base_Qualidade_Destinos::tabela(),['record_id'=>$id]);$wpdb->delete(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id]);}
    $names=$wpdb->get_col($wpdb->prepare('SELECT option_name FROM %i WHERE option_name LIKE %s',$wpdb->options,$wpdb->esc_like('f3_mcp_google_').'%'));foreach($names as $name){delete_option($name);}foreach($before as $r){$wpdb->insert($wpdb->options,$r);wp_cache_delete($r['option_name'],'options');}
    wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');foreach($oldCore as $name=>$saved){if($saved['exists']){raw($name,$saved['value']);}else{$wpdb->delete($wpdb->options,['option_name'=>$name]);wp_cache_delete($name,'options');}}wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');
    if(!$hadReadCapability){get_role('administrator')->remove_cap('f3base_ler_leads');}
    if(class_exists('Fator3\\McpFiles\\Persistence')){if($oldIdentity){Fator3\McpFiles\Persistence::put('connections','integration:user:1',$oldIdentity);}else{Fator3\McpFiles\Persistence::delete('connections','integration:user:1');}}
}
