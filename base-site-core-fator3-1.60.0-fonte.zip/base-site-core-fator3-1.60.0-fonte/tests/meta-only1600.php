<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';$r=activate_plugin('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');check(!is_wp_error($r),'meta0140_activation');raw('active_plugins',['base-site-core-fator3/base-site-core-fator3.php','wp-mcp-meta-fator3/wp-mcp-meta-fator3.php']);
