<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-linkedin-fator3','wp-mcp-meta-fator3'] as $slug){
 $r=activate_plugin($slug.'/'.$slug.'.php');check(!is_wp_error($r),'activate_'.$slug);
}
echo "Companions active; validate in a new PHP process. Pipedrive0.3 is excluded because PHP8.3.36 is required.\n";
