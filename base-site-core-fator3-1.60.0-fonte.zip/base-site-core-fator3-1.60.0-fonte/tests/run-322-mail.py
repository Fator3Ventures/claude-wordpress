from pathlib import Path
import subprocess,sys
hosts=Path('/etc/hosts');line='\n93.184.216.34 smtp-1600.example.test # f3base-core1600-mail-fixture\n'
assert 'smtp-1600.example.test' not in hosts.read_text()
try:
 with hosts.open('a') as f:f.write(line)
 r=subprocess.run([str(Path(__file__).resolve().parents[1]/'build/php'),str(Path(__file__).with_name(sys.argv[1] if len(sys.argv)>1 else 'request-322-mail.php'))])
finally:
 s=hosts.read_text();assert s.count(line)==1;hosts.write_text(s.replace(line,''))
sys.exit(r.returncode)
