from pathlib import Path
import subprocess,sys
raise SystemExit(subprocess.run([sys.executable,str(Path(__file__).with_name('run-322-mail.py')),'request-322-full-1600.php']).returncode)
