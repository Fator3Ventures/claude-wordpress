<?php
/** Full installed documentation, schemas and additive data dictionary, through the public ability. */
require __DIR__.'/bootstrap.php';
require_once ABSPATH.'wp-admin/includes/user.php';
use Fator3\McpFiles\Persistence as P;
$app=null;$connection=null;$subscriber=null;$http=0;
$deny=static function()use(&$http){++$http;return new WP_Error('qa_docs_no_http');};
try{
    if(class_exists(P::class)){
        $app=WP_Application_Passwords::create_new_application_password(1,['name'=>'QA1600 documentation temporary']);
        if(is_wp_error($app)){throw new RuntimeException('Cannot create temporary native authentication.');}
        $connection='app:'.$app[1]['uuid'];P::put('connections',$connection,['connection_id'=>$connection,'user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);
        do_action('application_password_did_authenticate',get_user_by('id',1),$app[1]);
    }
    add_filter('pre_http_request',$deny,PHP_INT_MAX);
    check(F3BASE_PLUGIN_VERSAO==='1.60.0'&&F3Base_Config_Contrato::VERSAO==='8.24.0','documentation_release_contract');
    $ability=wp_get_ability('f3base/documentacao-ler');check((bool)$ability,'ability_documentacao');
    $index=$ability->execute([]);check(!is_wp_error($index)&&!empty($index['ok'])&&$index['versao']==='1.60.0'&&$index['indice']==='docs/DOCUMENTACAO.md','indice_atual');
    $files=$index['arquivos'];$contents=[];$pages=0;
    foreach(['RELEASE-1.60.0.md','AGENTES-1.60.0.md','RECONCILIACAO-COMERCIAL-1.59.md','CREDENCIAIS-1.60.md','CAMINHO-LEAD-1.60.md','META-ADS-CORE-1.60.md','RELEASE-1.58.0.md','AGENTES-1.58.0.md','OPERACAO-1.58.md','CONTATOS-COMERCIAL-1.58.md','FORMULARIOS-ABANDONO-1.58.md','CONVERSOES-1.58.md','QUALIDADE-DESTINOS-1.58.md','CAMINHO-LEAD-1.58.md','META-ADS-CORE-1.58.md','dados/contrato.json','dados/abilities-1.json'] as $file){check(in_array('docs/'.$file,$files,true),'index_contains_'.$file);}
    foreach($files as $file){
        $at=1;$parts=[];$seen=[];
        do{
            check(!isset($seen[$at]),'pagination_advances_'.$file.'_'.$at);$seen[$at]=true;
            $r=$ability->execute(['arquivo'=>$file,'linha'=>$at,'limite'=>200]);
            check(!is_wp_error($r)&&!empty($r['ok'])&&$r['versao']==='1.60.0','page_'.$file.'_'.$at);
            $parts[]=$r['texto'];$at=$r['proxima_linha'];++$pages;
        }while($at!==null);
        $contents[$file]=implode("\n",$parts);
        check($r['sha256']===hash_file('sha256',F3BASE_PLUGIN_DIR.$file),'hash_'.$file);
        check($contents[$file]===implode("\n",file(F3BASE_PLUGIN_DIR.$file,FILE_IGNORE_NEW_LINES)),'complete_'.$file);
    }
    foreach($index['aliases'] as $alias=>$canonical){$r=$ability->execute(['arquivo'=>$alias,'linha'=>1,'limite'=>5]);check(!is_wp_error($r)&&!empty($r['ok'])&&$r['arquivo_canonico']===$canonical,'alias_'.$alias);}
    foreach(['322','330','331','332','333','334','8.24.0','1.59.0','0.36.0','0.14.0'] as $term){check(str_contains($contents['docs/RELEASE-1.60.0.md'],$term),'release_mentions_'.$term);}
    $dictionary=json_decode($contents['docs/dados/contrato.json'],true,512,JSON_THROW_ON_ERROR);
    check($dictionary['plugin']==='1.60.0'&&$dictionary['versao_contrato']==='8.24.0','data_dictionary_version');
    $inventory=json_decode(file_get_contents(F3BASE_PLUGIN_DIR.'dados/estado-inventario.json'),true,512,JSON_THROW_ON_ERROR);$tables=array_column($inventory['tabelas'],null,'sufixo');
    check($inventory['versao']==='1.60.0','inventory_version');
    foreach(['f3base_conversa_vinculos','f3base_desfechos','f3base_caminho_lead','f3base_qualidade_destinos','f3base_wp_mail'] as $table){
        check(isset($tables[$table])&&!empty($tables[$table]['finalidade'])&&str_starts_with($tables[$table]['uninstall'],'preservar'),'inventory_preserves_'.$table);
        $definition=$dictionary['tabelas'][$table]??[];check(!empty($definition['granularidade'])&&!empty($definition['colunas']),'dictionary_describes_'.$table);
        foreach($definition['colunas'] as $column){check($column['disponivel_desde']==='1.58.0','column_since_'.$table.'_'.$column['nome']);}
        global $wpdb;$columns=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$wpdb->prefix.$table));check(!$wpdb->last_error&&$columns===array_column($definition['colunas'],'nome'),'dictionary_matches_schema_'.$table);
    }
    $analysis=array_column($dictionary['tabelas']['f3base_analise']['colunas'],null,'nome');
    foreach(['ultimo_campo','etapa','campos_preenchidos'] as $name){check(($analysis[$name]['disponivel_desde']??null)==='1.58.0','form_column_since_'.$name);}
    $registered=[];foreach($contents as $file=>$text){if(preg_match('~^docs/dados/abilities-\d+\.json$~',$file)){$part=json_decode($text,true,512,JSON_THROW_ON_ERROR);check($part['plugin']==='1.60.0'&&$part['contrato']==='8.24.0','ability_document_version_'.$file);$registered+=$part['abilities'];}}
    foreach(['midia-prontidao-ler','resumo-operacional-ler','caminho-lead-testar','caminho-lead-limpar','caminho-lead-recibo-ler','email-wordpress-fila-ler'] as $name){check(isset($registered['f3base/'.$name])&&(bool)wp_get_ability('f3base/'.$name),'new_ability_documented_'.$name);}
    foreach(['../../wp-config.php','docs/../../../wp-config.php','/etc/passwd','https://example.test/x.md','base-site-core-fator3.php'] as $path){$r=$ability->execute(['arquivo'=>$path]);check(is_wp_error($r)||empty($r['ok']),'confinement_'.md5($path));}
    check($http===0,'documentation_no_http');
    $suffix=bin2hex(random_bytes(4));$subscriber=wp_insert_user(['user_login'=>'qa_docs_1600_'.$suffix,'user_pass'=>wp_generate_password(24),'role'=>'subscriber','user_email'=>'docs1600_'.$suffix.'@example.test']);check(!is_wp_error($subscriber),'temporary_subscriber_created');
    foreach([$subscriber,0] as $user){wp_set_current_user($user);$r=$ability->execute([]);check(is_wp_error($r)||(empty($r['ok'])&&($r['success']??null)===false&&!isset($r['texto'])&&!isset($r['arquivos'])),$user?'subscriber_denied':'anonymous_denied');}
    $GLOBALS['checks']['documents']=count($files);$GLOBALS['checks']['pages']=$pages;evidence('docs-1600');
}finally{
    wp_set_current_user(1);remove_filter('pre_http_request',$deny,PHP_INT_MAX);
    if(is_int($subscriber)){wp_delete_user($subscriber);}
    if(is_array($app)){WP_Application_Passwords::delete_application_password(1,$app[1]['uuid']);P::delete('connections',$connection);}
}
