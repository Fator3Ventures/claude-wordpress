# Bases e instrução — Core 1.57.1

Instrução explícita do dono nesta conversa: “Verifique a versão instalada e compare com a implementação feita por você. Veja o que tem de melhor nas duas implementações e gere uma nova versão 1.57.1 com o melhor dos 2”. Continuidade autorizada por mensagens “Continue”. Nenhum novo número de pedido foi criado.

A base canônica 1.57.0 foi obtida nos anexos, conferida contra a instalação por hashes dos arquivos principais e usada na atualização nativa. O candidato paralelo 1.57.0 não publicado foi comparado, mas não serve como base de migração. A colisão de números não significa equivalência de schemas.

| Artefato examinado | Bytes | SHA-256 |
|---|---:|---|
| Instalador canônico 1.57.0 | 2696212 | `5a829a78b3a2265560a88a0dde969fd435fd502ea2072e21ae8f47aeabf13ca6` |
| Fonte canônico 1.57.0 | 4066204 | `205bc18523b271afc76b76dbe5ce1e0fb19231ac5f31f19ae2ac3524ab54c758` |
| Relatório canônico 1.57.0 | 18973 | `bc64e5c59d4b49fcccfb658c49b2a3778eb26dc1fa229bbbacd4b30a55bcca93` |
| Instalador candidato paralelo 1.57.0 | 2702843 | `a7781197c291f50a859475a8e91f58bac3d6f87e8277400935c53cd34deaa4ab` |

Os ZIPs anteriores não são aninhados na entrega. Comparação de arquivos em `evidence/1571/initial-differences.json`; conferência da base instalada em `installed-base-hashes.json`; decisões prévias em `history/1571/PLANO.md`; resultado e limites no relatório principal 1.57.1. Instruções dos agentes revisão 4 e padrão de desenvolvimento revisão 5 estão em `work/plugin/base-site-core-fator3/docs/NORMA-*.md`; a revisão 5 canônica prevalece sobre a revisão 4 do padrão inicialmente fornecido.
