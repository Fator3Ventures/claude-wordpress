# Entrega — Fator3 MCP 0.34.0

**Relatório externo canônico. A cópia interna do fonte antecede o fechamento. ZIPs imutáveis.**

Revisão 1 · 28/10/2026 · America/Sao_Paulo · Rodada: implementação.  
Slug: `wp-mcp-fator3` · Basename: `wp-mcp-fator3/wp-mcp-fator3.php`.

**Versão corrente: 0.34.0, instalada e ativa no Site-Teste. Status: com-pendencias.** Os pedidos MCP **69–73** foram implementados e aceitos no Site-Teste. A pendência específica do pedido70 é o aceite das últimas 24 horas em um site da frota com `.gz` na janela, depois de sua atualização pelo responsável. Não há correção de código conhecida pendente no escopo testado. Nenhum acompanhante ou site de produção foi atualizado pelo agente MCP nesta rodada.

## 1. Bases aceitas e entradas

Base direta **0.33.0**, preservada: instalador 888204 bytes, SHA-256 `f16ee3e31e4143ffb42c566ea6da4f2da81d3771a01a0f90b5d34e3d02ac8caa`; fonte 4585261 bytes, SHA-256 `fdef8375bd72533062dff506be52664057619655e948afa3b89e22d4114e2ed6`. Relatório-base: 18433 bytes, SHA-256 `5b974515aa5ef9fb2888f8b5bd567d7d5d9ef42c5c1fcfe1c6ae3feb67d41f71`. Upgrade comprovado **0.33.0 → 0.34.0**, sem versão intermediária. O minor acrescenta recursos; não se trata de revisão sem código.

Pedidos de 28/10/2026, itens69–73, reproduzidos em `docs/entradas/0340/pedidos-mcp.md`. Normas comuns 01/02 **revisão5**, de 23/10/2026, preservadas byte a byte das entradas aceitas. Plano anterior ao código em `docs/PLANO-0340.md`. Manifesto das entradas iniciais em `packages.json`; atualizações concorrentes em `late-packages.json` e `docs/COMPATIBILIDADE-0340.md`.

Mínimos mantidos e exercitados: WordPress **7.1.2**, PHP **8.3.6**, 64 bits. Laboratórios: WordPress7.1.2/7.1.3, PHP8.3.6, MySQL8.0.46, PHP-FPM/lighttpd. Site-Teste: WordPress7.1.3/PHP8.3.36. Os ensaios com workers usam OPcache sem validação automática de timestamps. Pipedrive exige PHP8.3.36 e não foi ativado no PHP local inferior.

## 2. Convivência e encaminhamentos

| Pacote | Entrada inicial | Versão observada no fechamento | Cobertura própria |
|---|---|---|---|
| Site Core | 1.57.1 | 1.57.1 | Configuração, legibilidade, permissões, descoberta e correio sintético; limpeza de cache real sem alterar preferência |
| Google | 0.20.0 | 0.21.0 | Integridade/descoberta/diagnóstico locais nas duas entradas; 12 checks adicionais na 0.21.0 e status remoto sem live |
| Meta | 0.12.0 | 0.13.0 | Integridade e diagnóstico da entrada inicial; 5 checks adicionais na 0.13.0, 44 operações descobertas e health remoto ok |
| LinkedIn | 0.11.0 | 0.11.0 | Integridade, atividade, diagnóstico e descoberta locais; ativo no Site-Teste |
| Pipedrive | 0.2.0 | 0.3.0 | Fontes/relatório/schema examinados; registro do consumidor e recusa por concessão ausente no Core, sem chamada externa |

Google0.21.0 e Pipedrive0.3.0 tiveram instalador, fonte e relatório finais examinados. Meta0.13.0 foi observada na última conferência: o instalador congelado e seu plano/changelog/impacto Core foram examinados; o fonte ZIP e relatório externo finais ainda não integravam as entradas desta rodada. A cobertura MCP dessa versão está explicitada acima; os resultados declarados pelo mantenedor Meta não são contados como testes próprios. A troca dos três acompanhantes foi feita por outras rodadas, durante esta validação. Não houve downgrade ou edição desses pacotes.

| Instalador acompanhante mais recente considerado | Bytes | SHA-256 |
|---|---:|---|
| Core1.57.1 | 2707842 | `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62` |
| Google0.21.0 | 836718 | `25da9ef78e303f30ce2f73b8f98743a26e09b8ed238177474e4a956578a63814` |
| Meta0.13.0 | 284069 | `3ecd6ee6f277c7581adc05b4fa38c46611e3232b4400bb4a4421956c9fba8ac1` |
| LinkedIn0.11.0 | 283053 | `34541afa67c0991e9dc0b5474ab8678dff8cf806eace6ceb1edb47983f9e0308` |
| Pipedrive0.3.0 | 59877 | `30fc784a552a89351900c169fad7300759163fb886b842f45ba807bb0977f657` |

Também observados ativos: DreamHost Panel Login1.0.0, WP Super Cache3.1.4 e Yoast SEO28.8. O guia congelado identifica as entradas iniciais e aponta o relatório externo para validação efetiva; o adendo no fonte documenta as versões tardias. A instalação MCP continua independente de acompanhantes.

### Impactos novos emitidos

**Nenhum.** Foram avaliadas as fronteiras de diagnóstico, descoberta, autorização, transporte, redação, cache, recibos e recuperação. As mudanças são aditivas ao MCP e não exigem modificação de contrato/configuração de outro plugin. Isso não equivale a homologar todas as operações comerciais dos acompanhantes.

### Respostas e desfechos recebidos ou anteriores

| Referência | Resultado nesta rodada | Responsável / evidência |
|---|---|---|
| Impacto MCP0.32.0 → Core, revisão1, Core300 | Encerramento pelo Core1.54.0 preservado. Revogação de leitura/envio bloqueia prévia e recibo privado. | Core; 8 checks próprios, repetidos com o Google tardio, e 32 de correio sem envio |
| MCP67/68 e Core301 | Atendimento anterior preservado: redação segura, `lido` sem `nome`, mensagem `token_indisponivel` e chaves herdadas legíveis. | 479 unitários e regressões HTTP específicas |
| Google39/Core316, site-conversion-delivery/1.1.0 | Pedido ao consumidor Core continua sob seu mantenedor; Google também anuncia 1.0.0. Nenhuma adaptação MCP requerida. | Relatório Google0.21.0 e status/schema exercitados; não foi declarado encerramento do trabalho Core |
| Meta0.13.0 → Core, revisão2, Meta20(e), meta-ads-reader/1.0.0 | Demanda aberta de consumidor analítico Core. Contrato aditivo, concessão desligada por padrão. Nenhuma obrigação nova do MCP. | Plano/impacto Meta examinados; testes MCP limitados ao transporte/registro/diagnóstico |

Desfechos são registrados aqui; não há relatório de impacto de retorno nem reemissão de impactos antigos.

## 3. Mudanças por pedido e evidência

**69 — Diagnóstico compacto.** `system/health` e `system/oauth-diagnostics` aceitam `compact` e `fields`. Preservam os valores selecionados; o limite gera erro explícito se os blocos pedidos não couberem, sem truncar silenciosamente. Cron novo recebe índice sem o limite antigo de 100 entradas; o resumo combina o histórico preservado por identidade. Lacunas anteriores e saturação OAuth são declaradas por `counts_complete:false`, sem inventar eventos. No Site-Teste, health compacto teve **893 bytes**, contra **46892 bytes** do completo, com igualdade conferida de healthy, versão, mutation_audit, estado/contrato/readback do cron e recuperação. O resumo OAuth respondeu em 247 bytes. O cron final está active/active, consistent=true; nenhum reparo de agenda foi executado pela leitura.

**70 — Logs da hospedagem.** Nova `system/error-log`, somente administrador com canal/raiz de arquivos autorizados. Descobre o domínio, arquivos correntes/diários e gzip; valida identidade, CRC e membros concatenados. Filtra período RFC3339, nível e texto; agrupa a janela inteira antes da paginação. Senhas/chaves conhecidas e formatos de credenciais são mascarados antes de filtrar/agrupar. Teto de resposta8KiB, cursor ligado a conexão/filtros/inventário e limites explícitos de leitura. Hora sem offset do arquivo é interpretada em America/Los_Angeles e apresentada no fuso do WordPress. No Site-Teste, um MU-plugin mínimo produziu dois warnings sintéticos: retornaram **um grupo, contagem2, senha `[redigido]`, primeira09:49:48−03 e última09:49:49−03**, arquivo/linha corretos. O MU-plugin foi removido e sua ausência confirmada. A revisão automática recusou a tentativa de leitura do log bruto; o aceite usou exclusivamente a rota redigida e o marcador sintético. Gzip foi validado localmente; o aceite real em outro site da frota permanece pendente.

**71 — Upload repetível.** Com `idempotency_key` e `expected_sha256`, o recibo é reservado antes do download e ligado ao diário antes da troca. Repetição consulta o resultado/diário; não baixa nem reinstala. Digest/intenção conflitantes são recusados; permissões correntes continuam obrigatórias. Recibos pré-existentes da 0.33.0 continuam respeitados, inclusive estados incertos/compactados. `baseline_timeout_seconds`: padrão5, intervalo1–30 por requisição; falha inclui duração medida. No Site-Teste, a troca QA1.0.0→1.0.1 gerou operação `c449547e86088d83f998c485fb8c8d32`. O ZIP público foi apagado antes da repetição; a segunda chamada retornou a mesma operação/backup e `replayed:true`. A auditoria mostrou uma troca real e um replay, sem segunda substituição. Concorrência e interrupções foram cobertas localmente. Falha consome a chave: uma tentativa deliberadamente nova usa outra chave.

**72 — Pré-imagens e retenção.** Novos backups/auditoria incluem plugin, versões anterior/posterior, operação e hash do ZIP; filtros por tipo/plugin/período. A política `package_preimages` seleciona uma troca sucedida por outra concluída do mesmo plugin **ou** uma pré-imagem anterior a N dias. Prévia e aplicação conservam a seleção por hash; referências ativas permanecem protegidas. Diário de sucessão e marcador privado de exclusão impedem reimportação de envelopes já podados, inclusive após perda do índice. Não há poda automática na atualização. No Site-Teste, duas trocas QA1.0.0→1.0.1→1.0.2 criaram pré-imagens `4f89d83643fa1d75d4b3b21a` e `7213f7f95986b8c0fa2af179`; a política2dias selecionou e removeu **somente a primeira**. Após **214 segundos**, uma nova importação/leitura manteve apenas a segunda. O plugin QA e os ZIPs públicos foram removidos. Nenhum backup pré-existente do usuário foi podado.

**73 — Cópia servida.** `system/probe` aceita `cache:"served"`: visitante anônimo, sem cookies, Authorization, assinatura, query anticache ou marca de teste. Asserções preservadas; hash do corpo e evidência/idade de cache só são afirmados quando observáveis. Rodapé de geração isolado não prova HIT; artefato WPSC exige corpo correspondente e estabilidade antes/depois. Sem prova, HIT/idade são desconhecidos. O padrão bypass permanece. No cenário final do Site-Teste, após mudar o valor da página, served retornou HIT com idade93s e falhou no `contains` novo; bypass passou. Após `f3base/config-core-verificar`/`atualizar_cache` sobre a revisão corrente de `f3base_robots`, **served e bypass passaram**, duas amostras cada. Nenhuma preferência Core foi alterada. Página, option e MU-plugin temporários foram removidos; cache foi limpo novamente. A sonda continua declarando `internal_same_origin` e `external_access_proven:false`.

### Comparação de código e correções antes do congelamento

Em relação ao instalador0.33.0: **16 arquivos existentes alterados, 3 novos, nenhum removido**. Novos: Diagnostics.php, HostingErrorLog.php e PackageReceipt.php. Demais mudanças concentram-se em SystemTools/Probe, coordenação de execução, pacotes/recuperação, backups/inventário/retenção, persistência/auditoria/cron, identificação e guia gerado. Slug, basename, namespaces, contratos existentes e mínimos preservados.

Os testes identificaram e corrigiram antes do instalador final: comparação instável de resumo vazio por objetos novos; fechamento de stream não inicializado em erro de gzip, que podia derrubar PHP-FPM8.3.6; compatibilidade de recibos genéricos criados pela base0.33.0. Foram acrescentados testes negativos de gzip, corrida/idempotência, recibos anteriores, tombstone e prova de cache. A referência obsoleta do harness à classe LegacyStorage foi adaptada, pois a classe já não existia na base aceita; o runtime não foi alterado para satisfazer o teste antigo.

## 4. Instalação, prontidão e testes

**1.005 verificações locais aprovadas:** 990 de comportamento e 15 de pacote. Não somam setup, tentativas corrigidas, testes históricos não executados nem repetições da mesma suíte. O lint dos **456 arquivos PHP** integra um check de pacote. A lista completa e o resultado de cada caso estão em `evidencias/0340/test-summary.json` e nas suítes individuais.

| Grupo | Checks |
|---|---:|
| Unitários de redação/política/MCP68 | 479 |
| Pedidos69–73: integração, adversarial, concorrência e artefatos de cache | 82 |
| Política/legibilidade/correio/autorizações HTTP | 119 |
| OAuth, adversarial histórico, idempotência, mídia | 82 |
| Descoberta, busca documental, administração nativa e documentos HTTP | 90 |
| Cron, backups e bordas de retenção | 68 |
| Acompanhantes iniciais e tardios | 33 |
| Instalação limpa e upgrade direto | 37 |
| Pacote/reconstrução/lint | 15 |

Instalação limpa final no WP7.1.2: ativação nativa em um processo, leitura/HTTP em outro, apenas MCP, 467 arquivos iguais ao ZIP. Atualização direta final no WP7.1.3: 24 checks, pacote aplicado pelo fluxo HTTP nativo, preservação de credenciais/estado/recibos e comparação integral dos arquivos. As regressões de fronteiras inalteradas foram executadas durante a implementação; as últimas mudanças de recibo tiveram ensaio adversarial e upgrade repetidos, e as versões tardias tiveram testes adicionais. Não se atribui a um único snapshot inicial toda a matriz final.

No Site-Teste, instalado o **mesmo instalador final** de 903878 bytes/hash indicado no fechamento. Operação `4429fce15e75c5d81fa1dfae1a23a085`, status complete, file_state=candidate, active=true, versão0.34.0. Sondas antes/depois e finais da home/REST:200. Saúde final healthy=true, recuperação unresolved=0, runtime atual. A reativação foi silenciosa; isso confirma arquivos/atividade, não um novo ciclo de hooks de ativação nem prontidão comercial.

**Documentação instalada:** índice e leitura integral via MCP dos **33 documentos**, em **35 páginas**, **231076 bytes**; hashes e conteúdos iguais às fontes. A allowlist inclui release-0340, contratos, configuração/uso, operação/recuperação e guia para agentes. A leitura não chama fornecedor nem altera preferências. Evidências em remote-documents.json.

Auxiliares removidos: dois MU-plugins, páginas127/128, duas options, plugin QA, diretório de ZIPs públicos e ZIP de estágio fora da raiz. Ausência dos arquivos/diretórios confirmada por files/stat; exclusões de conteúdo/options confirmadas pelos resultados aplicados. Restaram somente registros auditáveis e pré-imagens operacionais normais, sem fixture ativa. O backup de atualização MCP foi preservado.

## 5. Banco, dados e reversão

Não há nova tabela ou mudança de schema; permanece schema2. As tabelas de estado existentes recebem buckets operacionais `cron-incidents`, `package-uploads` e `package-history`; o armazenamento privado recebe marcadores de backups retirados. Nenhuma configuração ou concessão de fornecedor é migrada. Não há execução PHP arbitrária, SQL de escrita em fase única, rota de frota ou feed de atualização próprio.

O upgrade preservou opções falsas/vazias, Application Password/OAuth, refresh, recibos concluídos/incertos, confirmação SQL pendente e backup privado. Não se reexecutam efeitos pelo replay. A instalação não recupera incidentes que já haviam sido perdidos pelo histórico anterior; `counts_complete:false` no Site-Teste declara essa limitação preexistente. O histórico OAuth ainda é limitado às128 falhas preservadas.

Backup de reversão MCP: **`63ab4d9c2774137b9aecb304`**. `plugins/rollback` em dry_run confirmou rollback_ready=true e preimage_verified=true, sem restaurar. Permite voltar arquivos à0.33.0; não reverte banco, auditoria ou efeitos externos. Mantenha-o até o aceite operacional. Dados novos de diagnóstico/recibo não passam a ser compreendidos pela versão anterior; evite tratar rollback como restauração transacional do site inteiro.

## 6. Pendências e limites

- **Pedido70, responsável frota/operador:** após implantar0.34.0 em um site autorizado que tenha `.gz` na janela, conferir agregação das últimas24h. Testes locais gzip e warning real do Site-Teste aprovados; não houve instalação nos outros11 sites nesta rodada.
- **Google39/Core316 e Meta20(e):** consumidores novos permanecem com o mantenedor Core conforme os documentos de origem. Não são falhas ou implementação atribuída ao MCP; esta rodada não os encerra.
- **APIs comerciais, Ads Manager, SMTP/IMAP, envios e coleta real de fornecedores:** não homologados pelo MCP. Pipedrive continua sem concessão; Google/Meta sem credenciais configuradas no diagnóstico observado. Não foram solicitadas credenciais para simular prontidão.
- **OAuth/CIMD:** 48 regressões locais e conexão existente preservada. Não foi criado um consentimento/CIMD externo novo do zero. O histórico B22 não é evidência de regressão nova nesta versão.
- **Navegador externo/CDN, multisite, Redis/Memcached, UI visual, outros runtimes e observação prolongada:** fora da matriz. served prova a resposta da URL pública a partir da própria hospedagem, não todos os pontos externos.
- **Limites de logs:** até128 arquivos, 32MiB expandidos, 16MiB comprimidos por arquivo, 5s e5000 grupos; recusa explícita acima desses limites. Hora repetida na transição DST sem offset no arquivo não pode ser desambiguada. Linhas não reconhecidas e mensagens truncadas são sinalizadas; não são contadas silenciosamente como eventos completos.

Nenhuma regressão foi observada nos cenários testados. Essa conclusão tem o alcance das evidências acima e não é garantia universal de ausência de impacto.

## 7. Credenciais e operação

Nenhum novo segredo ou escopo é necessário para atualizar o MCP. Use a conexão existente e suas permissões; o canal não concede capacidades Core nem substitui autorizações dos produtores. system/error-log exige leitura de arquivos e raiz permitida. Segredos, cookies, bancos de laboratório, logs brutos e helpers privados não integram os artefatos.

Para cada nova instalação, conferir SHA-256 e expected_slug, preservar a pré-imagem, verificar versão/atividade/saúde e documentação. Com upload idempotente, manter a chave para repetir a mesma intenção; uma falha registrada exige nova chave para uma nova tentativa deliberada. A poda por pacote requer prévia e o hash da seleção. O modo served não aceita marca de teste.

## 8. Estado final e distribuição

Considere **0.34.0 como versão corrente**. Apenas o ZIP instalador é instalável. Fonte contém código, build, testes, documentação editável, entradas rastreadas, evidências sanitizadas e relatório interno anterior ao fechamento. Nenhum ZIP contém outro ZIP da entrega. Os ZIPs-base permanecem imutáveis.

Nenhum push/publicação GitHub ou distribuição à frota foi realizado. O responsável segue o processo vigente de publicação e verificação dos bytes; o fonte permanece com o dono. Não há novo relatório de impacto próprio nesta entrega.

## 9. Identidade dos arquivos

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| `wp-mcp-fator3-0.34.0-instalador.zip` | 903878 | `5d96b6a33cfc4a7c729c106268f4bc9d8938b34384da022345d7b7dae611a295` |
| `wp-mcp-fator3-0.34.0-fonte.zip` | 4720710 | `4ae0f1bf02b65dae833ad08252be49c69685a76e7da26fb63182bf5f68b2c7b5` |

O instalador contém **467 arquivos, 456 PHP e 56 índices de silêncio gerados**, uma única raiz `wp-mcp-fator3/`, sem testes/ferramentas/fixtures ou ZIP aninhado. O fonte contém **1968 arquivos**. Após o empacotamento único do fonte, ele foi extraído em outro diretório: o instalador reconstruído foi **byte a byte idêntico** ao instalado e entregue. O hash e tamanho do fonte acima foram calculados depois desse fechamento; o arquivo não foi reempacotado.

Arquivos finais:

- [wp-mcp-fator3-0.34.0-instalador.zip](sandbox:/workspace/scratch/d7106ddbcd96/release0340/final/wp-mcp-fator3-0.34.0-instalador.zip)
- [wp-mcp-fator3-0.34.0-fonte.zip](sandbox:/workspace/scratch/d7106ddbcd96/release0340/final/wp-mcp-fator3-0.34.0-fonte.zip)
- [wp-mcp-fator3-0.34.0-relatorio.md](sandbox:/workspace/scratch/d7106ddbcd96/release0340/final/wp-mcp-fator3-0.34.0-relatorio.md)
