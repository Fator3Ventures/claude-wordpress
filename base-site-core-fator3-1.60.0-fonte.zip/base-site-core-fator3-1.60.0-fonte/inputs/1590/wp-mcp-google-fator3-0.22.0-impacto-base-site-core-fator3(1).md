# Impacto de Fator3 MCP Google 0.22.0 em Fator3 Site Core

28/10/2026 · America/Sao_Paulo · Revisão2 · Etapa implementação · Situação patch-disponível-para-incorporação.
Emissor wp-mcp-google-fator3: base0.21.0, alvo previsto0.22.0; instalador-alvo ainda não gerado. Base SHA-256 25da9ef78e303f30ce2f73b8f98743a26e09b8ed238177474e4a956578a63814.
Destinatário base-site-core-fator3 1.58.0, instalador SHA-256 71bf6497a2f2e2c605baf64f0f82c273201915039506b58ac220fc572afbd5e4.
Natureza contrato/reconciliação · Classificação acao-necessaria · Referência Pedidos Core323.

## Consequência nova

O produtor comercial1.2 usa o transporte Data Manager já vigente. events.ingest fornece requestId; a confirmação vem depois por requestStatus.retrieve. Core1.58 reserva o recibo como incerto e processa somente pendentes; não possui consulta do recibo comercial. Assim, uma ingestão aceita continuará incerta no Core mesmo após o Google confirmar o evento. Não reenviar, mudar event_id nem interpretar ingestão como entrega.

O Google0.22 implementa e anuncia em capabilities `async_reconciliation:"site-stage-conversion-reconcile/1.0.0"`. No mesmo objeto1.2 selecionado com consumer_id/purpose/action, `reconcileBound(string event_id,string destination_ref):array` consulta exclusivamente o recibo daquele evento/ação. Não recebe dados pessoais nem constrói nova conversão. Retorno: entregue somente com um evento confirmado no destino exato; recusado somente com non_delivery_proven=true; incerto nos demais casos, com code sanitizado e retry_after quando conhecido.

O vínculo inclui conexão, conta, ação, consumidor, finalidade, identidade e geração da concessão. Mudança ou revogação impede consulta pela referência antiga; nunca escolher alternativa. Deduplicação local permanece por site/ação/evento e não é apagada para permitir reenvio. Reconsulta respeita o cooldown do recibo, originalmente1800s.

## Pedido ao Core

Acrescentar caminho público de reconciliação dos recibos comerciais incertos, somente quando o adaptador anunciar exatamente essa extensão. Reconstituir event_id estável já definido por323, selecionar a mesma ação/consumer/purpose, exigir a referência reservada e revisão vigente e chamar reconcileBound; nunca sendBound. Preservar estados incertos e destinatários sem suporte. Agendar consultas com limite de trabalho/cooldown; timeout ou ausência do recibo não autoriza nova ingestão.

Na resposta comprovada, atualizar apenas estado/código/HTTP do recibo comercial correspondente. A operação administrativa Google `google/reconcile-stage-conversion` permite diagnóstico no produtor; não altera tabelas Core. O consumidor Core foi implementado nesta rodada em `integration/core323/core-1.58.0-reconciliacao-comercial.patch`, junto do arquivo completo e identidade SHA-256 da base. O mantenedor Core incorpora o patch em sua release; operador homologa com conta/ação autorizadas. Atualizar textos estáticos Core que dizem que o produtor Google ainda não possui1.2 depois de validar a capacidade efetiva.

## Compatibilidade e aceite

Google0.22 atende seleção1.2 e mantém aquisição1.0/1.1. Core1.58 pode usá-lo, com concessão comercial explícita e recibos inicialmente incertos; a resolução automática Core depende deste acréscimo. Não há ativação automática de ações. Teste definido com Core original: prévia sem HTTP/fila, envio por ação exata, incerto sem reenvio e confirmação no produtor por consulta. Aceite coordenado futuro: mesmo recibo Core passa de incerto para entregue mediante consulta, zero novas ingestões, revogação/identidade/ação divergentes bloqueadas. Nenhuma homologação comercial é inferida de HTTP sintético.

Este documento contém a necessidade adicional de reconciliação; o atendimento ao impacto Core1.58 revisão2 e o encerramento de Google39/Core316 serão registrados no relatório principal, conforme Norma02 revisão5. Documento preparado para encaminhamento, sem mensagem externa.

## Alteração implementada para o Core

Patch sobre o arquivo original class-f3base-qualidade-destinos.php do1.58.0. O worker consulta até dois incertos Google após1800s, reserva o intervalo antes da chamada e renova a trava. Exige configuração/ação/referência vigentes e extensão exata; não reconstrói dados pessoais nem chama sendBound. Prova de envio expirada permite consultar; revogação bloqueia. Não muda tabela/opções nem numera uma release Core. O fonte Google entrega código, diff e instruções de aplicação; o relatório principal registra o ensaio separado e seus resultados. Nenhum arquivo Core foi alterado no Site-Teste.
