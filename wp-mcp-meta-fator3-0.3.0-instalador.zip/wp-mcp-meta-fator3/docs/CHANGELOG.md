# Alterações — 0.3.0

Atualização direta da 0.2.0; nenhuma migração de banco, seleção ou autorização.

- Pedido MCP Meta 1: Description exata com local de configuração.
- Pedido MCP Meta 9: erros Graph numéricos e subcódigos preservados em consultas/coletas; inspeção de permissões do token derivado de cada Página; fallback individual para grupos vazios; ausência e múltiplos buckets explicitados.

## Histórico da 0.2.0

# 0.2.0

- Gate manage_options em todas as entradas humanas e revalidação de tarefas.
- Documentação completa instalada, índice, paginação UTF-8 e revisão/hash.
- Catálogo versionado, séries diárias e grupos de métricas compatíveis.
- Canal Facebook, tokens de Página privados e propriedade de objetos.
- Histórico cifrado independente de jobs, retenção sem expiração, migração, deduplicação e exportação em partes.
- Backfill com início explícito, janela final congelada e retomada.
- Capturas periódicas de mídias/Stories e rotação validada de token.
- Desinstalação conserva dados.

Homologação de métricas reais, disponibilidade de dois anos e comportamento por tipo de mídia dependem dos ativos/escopos do dono; não são deduzidos dos testes simulados.
