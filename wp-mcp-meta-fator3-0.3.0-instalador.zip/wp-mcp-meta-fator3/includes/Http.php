<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Http {
    private static int $calls=0;
    private static float $until=0;
    public static function budget(int $calls=15,int $seconds=25): void {self::$calls=$calls;self::$until=microtime(true)+$seconds;}
    public static function remaining(int $calls=1): bool {return self::$calls>=$calls&&microtime(true)<self::$until-3;}
    /** Strict projection: provider messages and URLs may contain credentials. */
    public static function diagnostic($data,int $http): array {
        $error=is_array($data)&&is_array($data['error']??null)?$data['error']:[];
        $number=static fn($v)=>is_int($v)&&$v>=0?$v:null;
        return ['http_status'=>$http,'provider_code'=>$number($error['code']??null),'provider_subcode'=>$number($error['error_subcode']??null),'provider_is_transient'=>is_bool($error['is_transient']??null)?$error['is_transient']:null];
    }
    public static function request(array $c,string $path,array $query=[],string $method='GET',?array $body=null,?callable $beforeDispatch=null): array {
        Connections::usable($c);Connections::revalidate($c);
        if(!Adapter::allowed($path,$method))throw new Fault('endpoint_forbidden','Endpoint não permitido.');
        if(self::$until===0)self::budget();
        if(self::$calls--<=0||microtime(true)>self::$until-2)throw new Fault('budget_exhausted','Orçamento da execução atingido.');
        $quota=Store::get('quota',$c['id']);if(($quota['value']['until']??0)>time())throw new Fault('rate_limited','A conexão aguarda a janela de quota.',['retry_after'=>$quota['value']['until']-time()]);
        $url=Adapter::base($c).$path;if($query)$url.='?'.Adapter::encode($query);
        $headers=['Authorization'=>'Bearer '.$c['token'],'Accept'=>'application/json'];
        if(Config::KEY==='f3_linkedin')$headers+=['LinkedIn-Version'=>$c['api_version'],'X-Restli-Protocol-Version'=>'2.0.0'];
        if(Config::KEY==='f3_linkedin'&&isset($query['q']))$headers['X-RestLi-Method']='FINDER';
        if($body!==null)$headers['Content-Type']='application/json';
        $args=['method'=>$method,'headers'=>$headers,'timeout'=>min(8,max(1,(int)(self::$until-microtime(true)))),'redirection'=>0,'sslverify'=>true,'limit_response_size'=>1800000];
        if($body!==null)$args['body']=Util::json($body);
        // Guard runs after all local checks and immediately before the remote side effect.
        if($beforeDispatch)$beforeDispatch();
        $r=wp_remote_request($url,$args);unset($args,$headers);
        if(is_wp_error($r))throw new Fault($method==='GET'?'upstream_error':'operation_uncertain','Não houve confirmação do fornecedor.');
        $http=wp_remote_retrieve_response_code($r);$raw=wp_remote_retrieve_body($r);
        if(strlen($raw)>=1800000)throw new Fault('response_limit','Resposta excedeu o orçamento de bytes.');
        $data=$raw===''?[]:json_decode($raw,true,96,JSON_BIGINT_AS_STRING);
        $provider=self::diagnostic($data,$http);$graphCode=$provider['provider_code']??0;$graphError=is_array($data)&&is_array($data['error']??null);
        if($http===429||(Config::KEY==='f3_meta'&&in_array($graphCode,[4,17,32,613],true))){$ra=(string)wp_remote_retrieve_header($r,'retry-after');$retry=ctype_digit($ra)?(int)$ra:max(60,(int)strtotime($ra)-time());$retry=max(60,min(86400,$retry));
            Store::lock('quota:'.$c['id'],static function()use($c,$retry){$q=Store::get('quota',$c['id']);Store::put('quota',$c['id'],['until'=>time()+$retry],$q['revision']??0);});
            throw new Fault('rate_limited','Limite remoto atingido.',['retry_after'=>$retry]+$provider);}
        if($http<200||$http>=300||$graphError){$code=$http===401?'token_rejected':($http===403?'asset_access_denied':($http===404?'resource_not_found':($http===400?'upstream_validation':'upstream_error')));
            if(Config::KEY==='f3_meta'&&in_array($graphCode,[190,102],true))$code='token_rejected';
            if(Config::KEY==='f3_meta'&&in_array($graphCode,[10,200],true))$code='asset_access_denied';
            if($method!=='GET'&&$http>=500)$code='operation_uncertain';
            if($http>=200&&$http<300&&$code==='upstream_error')$code='upstream_validation';
            throw new Fault($code,'O fornecedor recusou a operação.',$provider);}
        if(!is_array($data))throw new Fault($method==='GET'?'upstream_invalid':'operation_uncertain','Resposta inválida do fornecedor.');
        if($method==='GET')Connections::revalidate($c);
        // A successful write receipt must reach its durable journal even if access changed in flight.
        return ['body'=>$data,'status'=>$http,'id'=>(string)wp_remote_retrieve_header($r,'x-restli-id')];
    }
}
