<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

final class Fault extends \RuntimeException {
    public string $reason;
    public array $details;
    public function __construct(string $reason, string $message, array $details = []) {
        parent::__construct($message); $this->reason = $reason; $this->details = $details;
    }
}
final class Result {
    public static function ok(array $data = []): array {
        return ['success'=>true,'code'=>'ok','provider'=>Config::SLUG,'version'=>Config::VERSION,'data'=>$data];
    }
    public static function fail(Fault $e): array {
        return ['success'=>false,'code'=>$e->reason,'error_code'=>$e->reason,'provider'=>Config::SLUG,
            'message'=>$e->getMessage(),'conflict'=>$e->reason==='revision_conflict',
            'retryable'=>in_array($e->reason,['rate_limited','busy','upstream_error'],true),
            'data'=>null,'details'=>$e->details];
    }
    public static function run(callable $fn): array {
        try { return self::ok($fn()); }
        catch (Fault $e) { return self::fail($e); }
        catch (\Throwable $e) { return self::fail(new Fault('internal_error','A operação não foi concluída. Consulte o diagnóstico local.')); }
    }
}
final class Util {
    public static function json($value): string {
        $s=wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if(!is_string($s))throw new Fault('encoding_failed','Falha ao codificar os dados.');
        return $s;
    }
    public static function id(string $v): string {
        if(!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}$/D',$v))throw new Fault('invalid_input','Identificador inválido.');
        return $v;
    }
    public static function numeric($v): string {
        if(!is_string($v)||!preg_match('/^[0-9]{1,40}$/D',$v))throw new Fault('invalid_input','O identificador remoto deve ser uma string numérica.');
        return $v;
    }
    public static function dates(array $i, int $maxDays=366): array {
        $out=[];
        foreach(['date_from','date_to'] as $k){
            $s=$i[$k]??''; $d=is_string($s)?\DateTimeImmutable::createFromFormat('!Y-m-d',$s,new \DateTimeZone('UTC')):false;
            if(!$d||$d->format('Y-m-d')!==$s)throw new Fault('invalid_input','Datas devem usar YYYY-MM-DD.');
            $out[$k]=$s; $out[$k.'_ts']=$d->getTimestamp();
        }
        if($out['date_from_ts']>$out['date_to_ts']||$out['date_to_ts']-$out['date_from_ts']>=86400*$maxDays)
            throw new Fault('invalid_input','Intervalo de datas fora do limite.',['max_days'=>$maxDays]);
        return $out;
    }
    public static function same(array $a,array $b): bool { return hash_equals(hash('sha256',self::json($a)),hash('sha256',self::json($b))); }
    public static function guardKeys(array $i,array $allowed): void {
        $extra=array_diff(array_keys($i),$allowed);
        if($extra)throw new Fault('invalid_input','Parâmetros desconhecidos.',['fields'=>array_values($extra)]);
    }
    public static function cursor(array $v): string { return Crypto::seal(self::json($v),'cursor'); }
    public static function uncursor(string $s): array {
        if(strlen($s)>50000)throw new Fault('invalid_cursor','Continuação inválida.');
        try{$v=json_decode(Crypto::open($s,'cursor'),true,64,JSON_THROW_ON_ERROR);}catch(\Throwable $e){throw new Fault('invalid_cursor','Continuação inválida ou de outro site.');}
        if(!is_array($v)||($v['expires']??0)<time())throw new Fault('cursor_expired','A continuação expirou. Inicie uma nova consulta.');
        return $v;
    }
}
final class Crypto {
    private static function key(string $purpose): string { return hash_hmac('sha256',Config::SLUG.'|'.get_current_blog_id().'|'.$purpose,wp_salt('auth'),true); }
    public static function available(): bool { return function_exists('sodium_crypto_secretbox') || (function_exists('openssl_encrypt')&&in_array('aes-256-gcm',openssl_get_cipher_methods(),true)); }
    public static function seal(string $s,string $purpose='store'): string {
        if(function_exists('sodium_crypto_secretbox')){$n=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);return 's1.'.base64_encode($n.sodium_crypto_secretbox($s,$n,self::key($purpose)));}
        if(!self::available())throw new Fault('crypto_unavailable','Criptografia autenticada indisponível.');
        $n=random_bytes(12);$tag='';$c=openssl_encrypt($s,'aes-256-gcm',self::key($purpose),OPENSSL_RAW_DATA,$n,$tag,$purpose,16);
        if($c===false)throw new Fault('crypto_unavailable','Falha na cifra.');return 'g1.'.base64_encode($n.$tag.$c);
    }
    public static function open(string $s,string $purpose='store'): string {
        $p=substr($s,0,3);$b=base64_decode(substr($s,3),true);$r=false;
        if($b!==false&&$p==='s1.'&&strlen($b)>40&&function_exists('sodium_crypto_secretbox_open'))$r=sodium_crypto_secretbox_open(substr($b,24),substr($b,0,24),self::key($purpose));
        if($b!==false&&$p==='g1.'&&strlen($b)>=28&&function_exists('openssl_decrypt'))$r=openssl_decrypt(substr($b,28),'aes-256-gcm',self::key($purpose),OPENSSL_RAW_DATA,substr($b,0,12),substr($b,12,16),$purpose);
        if(!is_string($r))throw new Fault('cipher_unreadable','Dados cifrados ilegíveis; confira a chave do site.'); return $r;
    }
}
final class Store {
    public static function table(): string { global $wpdb;return $wpdb->prefix.Config::TABLE; }
    public static function install(): void {
        global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $t=self::table();
        dbDelta("CREATE TABLE $t (
bucket varchar(32) NOT NULL,
record_key varchar(191) NOT NULL,
revision bigint unsigned NOT NULL DEFAULT 1,
payload longtext NOT NULL,
updated_at bigint unsigned NOT NULL,
expires_at bigint unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (bucket,record_key),
KEY expires_at (expires_at)
) ENGINE=InnoDB {$wpdb->get_charset_collate()};");
        if(!self::ready())throw new Fault('storage_unavailable','A estrutura de armazenamento não foi confirmada.');
        update_option(Config::KEY.'_schema',1,false);
    }
    public static function ready(): bool {global $wpdb;$t=self::table();return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;}
    public static function get(string $bucket,string $key): ?array {
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE bucket=%s AND record_key=%s',self::table(),$bucket,$key),ARRAY_A);
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha na leitura do armazenamento.');if(!$r)return null;
        try{$v=json_decode(Crypto::open($r['payload']),true,128,JSON_THROW_ON_ERROR);}catch(Fault $e){throw $e;}catch(\Throwable $e){throw new Fault('storage_corrupt','Registro inválido.');}
        if(!is_array($v))throw new Fault('storage_corrupt','Registro inválido.');
        return ['value'=>$v,'revision'=>(int)$r['revision'],'updated_at'=>(int)$r['updated_at'],'expires_at'=>(int)$r['expires_at']];
    }
    /** CAS includes creation. Every successful write has one subsequent read. */
    public static function put(string $bucket,string $key,array $value,int $expected=0,int $expires=0): array {
        global $wpdb;$cipher=Crypto::seal(Util::json($value));$t=self::table();
        if($expected===0)$n=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (bucket,record_key,revision,payload,updated_at,expires_at) VALUES (%s,%s,1,%s,%d,%d)',$t,$bucket,$key,$cipher,time(),$expires));
        else $n=$wpdb->query($wpdb->prepare('UPDATE %i SET payload=%s,revision=revision+1,updated_at=%d,expires_at=%d WHERE bucket=%s AND record_key=%s AND revision=%d',$t,$cipher,time(),$expires,$bucket,$key,$expected));
        if($n===false)throw new Fault('storage_unavailable','Falha ao persistir o registro.');
        if($n!==1)throw new Fault('revision_conflict','O registro mudou. Releia sua revisão.');
        $r=self::get($bucket,$key);if(!$r||$r['revision']!==$expected+1||!Util::same($r['value'],$value))throw new Fault('persistence_unconfirmed','Gravação ainda não confirmada.');return $r;
    }
    public static function list(string $bucket,int $offset=0,int $limit=50): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s ORDER BY record_key LIMIT %d OFFSET %d',self::table(),$bucket,min(100,$limit),$offset),ARRAY_A);
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao listar os registros.');$out=[];
        foreach($rows as $r){$v=self::get($bucket,$r['record_key']);if($v)$out[]=['key'=>$r['record_key']]+$v;}return $out;
    }
    public static function remove(string $bucket,string $key,int $revision): void {
        global $wpdb;$n=$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE bucket=%s AND record_key=%s AND revision=%d',self::table(),$bucket,$key,$revision));
        if($n===false)throw new Fault('storage_unavailable','Falha ao remover registro.');if($n!==1)throw new Fault('revision_conflict','O registro mudou.');
    }
    /** Keyset scan is stable when earlier records are removed by another worker. */
    public static function scan(string $bucket,string $after='',int $limit=50): array {
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s AND record_key>%s ORDER BY record_key LIMIT %d',self::table(),$bucket,$after,min(100,max(1,$limit))),ARRAY_A);
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha na leitura paginada.');
        $out=[];foreach($rows as $row){$v=self::get($bucket,$row['record_key']);if($v)$out[]=['key'=>$row['record_key']]+$v;}return $out;
    }
    public static function resultExists(string $job): bool {
        global $wpdb;$found=$wpdb->get_var($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s AND record_key LIKE %s LIMIT 1',self::table(),'result',$wpdb->esc_like($job.':').'%'));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha na conferência de resultados.');return $found!==null;
    }
    public static function prune(): int {
        global $wpdb;
        // Meta migrates the existing result pages before applying their retention.
        if(Config::KEY==='f3_meta'&&!History::migrationComplete())History::migrate();
        $results=Config::KEY!=='f3_meta'||History::migrationComplete();
        $buckets=$results?['result','export','audit','history_export','history_export_part']:['export','audit','history_export','history_export_part'];$removed=0;
        foreach($buckets as $bucket){$n=$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE expires_at>0 AND expires_at<%d AND bucket=%s LIMIT 100',self::table(),time(),$bucket));if($n===false)throw new Fault('storage_unavailable','Falha na retenção.');$removed+=$n;}
        $keys=$wpdb->get_col($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s AND expires_at>0 AND expires_at<%d ORDER BY record_key LIMIT 100',self::table(),'job',time()));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha na retenção de coletas.');
        foreach($keys as $key){try{$removed+=self::lock('job:'.$key,static function()use($key){$r=self::get('job',$key);if(!$r||self::resultExists($key))return 0;self::remove('job',$key,$r['revision']);return 1;});}catch(Fault $e){if($e->reason!=='busy')throw $e;}}
        if(Config::KEY==='f3_meta'&&$results)$removed+=History::prune();return $removed;
    }
    /** Database connection lock has no expiring lease that a stale worker can outlive. */
    public static function lock(string $resource,callable $fn) {
        global $wpdb;$name='f3s:'.substr(hash('sha256',DB_NAME.'|'.self::table().'|'.$resource),0,55);
        if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$name))!=='1')throw new Fault('busy','Operação concorrente em andamento.');
        try{return $fn();}finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$name));}
    }
}
