<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Credentials {
    /** Inspect the derived Page credential itself; never infer its scopes from /me. */
    public static function pagePermissions(array $source,array $page,string $account): array {
        $proof=['page_id'=>$account,'source'=>'graph_debug_token','status'=>'unknown','permissions_verified'=>false,'scopes'=>[],
            'read_insights_granted'=>null,'pages_read_engagement_granted'=>null,'is_valid'=>null,'checked_at'=>gmdate('c')];
        $auth=$source;
        if($source['client_id']!==''&&$source['client_secret']!==''){
            if(!ctype_digit($source['client_id']))throw new Fault('invalid_input','Meta App ID deve ser numérico.');
            $auth['token']=$source['client_id'].'|'.$source['client_secret'];$auth['expires_at']=0;
        }
        try{
            $data=Http::request($auth,'debug_token',['input_token'=>$page['token']])['body']['data']??null;
            if(!is_array($data)||!is_bool($data['is_valid']??null))throw new Fault('upstream_invalid','Inspeção de credencial incompleta.');
            $proof['is_valid']=$data['is_valid'];
            if(!$data['is_valid']){$proof['status']='invalid_credential';return $proof;}
            if(isset($data['profile_id'])&&(string)$data['profile_id']!==$account)throw new Fault('credential_identity_mismatch','A inspeção retornou outra Página.');
            if($source['client_id']!==''&&(string)($data['app_id']??'')!==$source['client_id'])throw new Fault('credential_identity_mismatch','A inspeção retornou outro aplicativo.');
            if(isset($data['type'])&&$data['type']!=='PAGE')throw new Fault('credential_identity_mismatch','A inspeção não confirmou uma credencial de Página.');
            if(!is_array($data['scopes']??null)||count($data['scopes'])>200)throw new Fault('upstream_invalid','Escopos da Página ausentes ou inválidos.');
            foreach($data['scopes'] as $scope){if(!is_string($scope)||!preg_match('/^[a-z][a-z0-9_]{0,79}$/D',$scope))throw new Fault('upstream_invalid','Escopo da Página inválido.');}
            $scopes=array_values(array_unique($data['scopes']));sort($scopes);$proof['scopes']=$scopes;
            $granular=$data['granular_scopes']??[];
            if(!is_array($granular)||count($granular)>200)throw new Fault('upstream_invalid','Escopos granulares inválidos.');
            foreach(['read_insights','pages_read_engagement'] as $scope){
                $granted=in_array($scope,$scopes,true);$targeted=[];
                foreach($granular as $entry){
                    if(!is_array($entry)||!is_string($entry['scope']??null))throw new Fault('upstream_invalid','Escopo granular inválido.');
                    if($entry['scope']!==$scope||!array_key_exists('target_ids',$entry))continue;
                    if(!is_array($entry['target_ids']))throw new Fault('upstream_invalid','Ativos do escopo inválidos.');
                    $ids=[];foreach($entry['target_ids'] as $id){if(!is_string($id)&&!is_int($id))throw new Fault('upstream_invalid','Ativo do escopo inválido.');$ids[]=(string)$id;}
                    $targeted[]=in_array($account,$ids,true);
                }
                if($targeted)$granted=$granted&&in_array(true,$targeted,true);
                $proof[$scope.'_granted']=$granted;
            }
            $proof['status']='verified';$proof['permissions_verified']=true;return $proof;
        }catch(Fault $e){
            if(!in_array($e->reason,['upstream_validation','upstream_invalid','upstream_error','token_rejected','asset_access_denied','resource_not_found','credential_identity_mismatch'],true))throw $e;
            // Unknown is not denied. Do not project upstream text or credential values.
            $proof['read_insights_granted']=null;$proof['pages_read_engagement_granted']=null;
            $proof['diagnostic_error']=['code'=>$e->reason]+array_intersect_key($e->details,array_flip(['http_status','provider_code','provider_subcode','provider_is_transient']));
            return $proof;
        }
    }
    public static function identity(array $c): array {
        $r=Http::request($c,'me',['fields'=>'id'])['body'];$subject=(string)($r['id']??'');Util::numeric($subject);
        $proof=['subject_id'=>$subject,'application_id'=>$c['application_id'],'proof'=>'app_scoped_subject_read','app_verified'=>false,'checked_at'=>time()];
        if($c['client_id']!==''&&$c['client_secret']!==''){
            if(!ctype_digit($c['client_id']))throw new Fault('invalid_input','Meta App ID deve ser numérico.');
            $auth=$c;$auth['token']=$c['client_id'].'|'.$c['client_secret'];$auth['expires_at']=0;
            $debug=Http::request($auth,'debug_token',['input_token'=>$c['token']])['body']['data']??null;
            if(!is_array($debug)||empty($debug['is_valid'])||(string)($debug['app_id']??'')!==$c['client_id']||!is_array($debug['scopes']??null))throw new Fault('credential_identity_mismatch','A Meta não confirmou o aplicativo e as permissões deste token.');
            $scopes=array_values(array_filter($debug['scopes'],'is_string'));sort($scopes);
            $proof+=['principal_id'=>(string)($debug['user_id']??''),'scopes'=>$scopes,'remote_expires_at'=>(int)($debug['expires_at']??0)];$proof['application_id']=(string)$debug['app_id'];$proof['app_verified']=true;$proof['proof']='graph_debug_token_and_subject';
        }
        return $proof;
    }

    public static function rotate(array $i): array {
        Access::admin();$c=Connections::get($i['connection_id']);if($c['revision']!==$i['expected_revision'])throw new Fault('revision_conflict','A conexão mudou.');
        $principal=Access::principal();$old=$c['token_identity']??null;if(!$old||empty($old['app_verified']))$old=self::identity($c);if(empty($old['app_verified']))throw new Fault('app_proof_required','Configure Meta App ID/client secret e valide a identidade antes da rotação que preserva agendas.');
        $candidate=$c;$candidate['token']=$i['token'];$candidate['expires_at']=$i['expires_at']??0;$candidate['credential_generation']++;
        if($candidate['token']===''||preg_match('/[\x00-\x20]/',$candidate['token']))throw new Fault('invalid_input','Token inválido.');
        $proof=self::identity($candidate);
        if(empty($proof['app_verified'])||$proof['subject_id']!==$old['subject_id']||$proof['application_id']!==$old['application_id']||($proof['principal_id']??'')!==($old['principal_id']??'')||array_diff($old['scopes']??[],$proof['scopes']??[]))throw new Fault('credential_identity_mismatch','O novo token não preservou a identidade comprovada. Reconfigure a seleção e as agendas explicitamente.');
        // Verify every explicitly selected asset before admitting this generation.
        $count=count($c['assets']['instagram'])+count($c['assets']['facebook']);if($count>12)throw new Fault('validation_limit','Rotação assistida limitada a 12 ativos; use conexões menores.');
        foreach($c['assets'] as $channel=>$ids)foreach($ids as $id){$fields=$channel==='facebook'?'id,name':'id,username';$r=Http::request($candidate,$id,['fields'=>$fields])['body'];if((string)($r['id']??'')!==$id)throw new Fault('asset_access_denied','A nova credencial não confirmou todos os ativos.');}
        return Store::lock('connection:'.$c['id'],static function()use($c,$candidate,$proof,$principal){Connections::revalidate($c);Access::checkPrincipal($principal);$v=$candidate;unset($v['revision']);$v['token_identity']=$proof+['validated_generation'=>$v['credential_generation']];$v['page_tokens']=[];$v['token_configured']=true;$v['updated_at']=time();$r=Store::put('connection',$c['id'],$v,$c['revision']);Jobs::scheduleTick();return ['persisted'=>true,'connection'=>Connections::public($v+['revision'=>$r['revision']]),'schedules_preserved'=>true,'application_independently_verified'=>true];});
    }
}
