<?php
/** Deliberately preserve operation receipts and journal. No network or data deletion. */
defined('WP_UNINSTALL_PLUGIN') || exit;
