<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Api {
    public static function schemas(): array {
        $object=static fn($props=[],$required=[])=>['type'=>'object','properties'=>$props,'required'=>$required,'additionalProperties'=>false];
        $path=['type'=>'string','maxLength'=>200,'description'=>'Caminho relativo exato da lista permitida, sem query embutida.'];
        return [
            'status'=>$object(),
            'relatorio'=>Report::schema(),
            'retencao-ler'=>$object(),
            'retencao-configurar'=>$object(['diario_dias'=>['type'=>'integer','minimum'=>0,'maximum'=>36500,'description'=>'Zero: sem prazo (padrão). Dias positivos permitem expurgo futuro.'],'revisao_esperada'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$'],'confirmar_expurgo'=>['type'=>'boolean','description'=>'Obrigatório true para prazo finito. Não executa expurgo nesta chamada.']],['diario_dias','revisao_esperada']),
            'api-ler'=>$object(['caminho'=>$path,'query'=>['type'=>'object','description'=>'Parâmetros da lista de leitura, separados do caminho.']],['caminho']),
            'api-previa'=>$object(['metodo'=>['type'=>'string','enum'=>['POST','PUT','PATCH','DELETE']],'caminho'=>$path,'corpo'=>['type'=>'object','description'=>'Campos permitidos pelo método; até 64 KiB.']],['metodo','caminho']),
            'api-aplicar'=>$object(['previa_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$'],'confirmacao'=>['type'=>'string','maxLength'=>2000,'description'=>'Frase literal da prévia, obrigatória para estrutura.']],['previa_id']),
            'registro-ler'=>$object(['limite'=>['type'=>'integer','minimum'=>1,'maximum'=>100],'antes_id'=>['type'=>'integer','minimum'=>1]]),
            'documentacao-ler'=>$object(['documento'=>['type'=>'string','maxLength'=>40],'offset'=>['type'=>'integer','minimum'=>0],
                'limite_bytes'=>['type'=>'integer','minimum'=>256,'maximum'=>24000],'sha256_esperado'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$']])
        ];
    }
    public static function writes(string $op): bool { return in_array($op,['api-previa','api-aplicar','retencao-configurar'],true); }
    public static function descriptions(): array {
        return [
            'retencao-ler'=>'Lê a política local do diário, recibos, prazos e revisão. Sem HTTP ou gravação.',
            'retencao-configurar'=>'Configura retenção do diário com revisão; zero significa sem prazo. Prazo finito exige ciência de expurgo futuro. Grava apenas configuração local.',
            'relatorio'=>'Relatório agregado sem dados individuais; paginação interna, período, completo e custo operacao. Leia uso para limites, códigos de categorias e visibilidade.',
            'status'=>'Estado local: contrato, autorização, conta, orçamento e saldo. Sem HTTP, sem reparos. Ajuda: pipedrive/documentacao-ler.',
            'api-ler'=>'Consulta GET da lista fechada pelo cliente Core. Consome orçamento operacao; não altera registros da conta.',
            'api-previa'=>'Prepara escrita por 15 minutos; consulta estado via GET quando há ID, cifra a prévia local e não envia mutação externa.',
            'api-aplicar'=>'Executa uma prévia uma única vez. Estrutura exige frase exata. Repetição devolve recibo; resultado incerto exige reconciliação.',
            'registro-ler'=>'Lê auditoria local paginada com UTC, método, caminho, classe, status, chaves alteradas e saldo; sem valores pessoais.',
            'documentacao-ler'=>'Índice e documentos instalados, completos por páginas com SHA-256. Não chama o Core nem fornecedor e não grava estado.'
        ];
    }
    public static function dispatch(string $op,array $i=[],bool $channel=false): array {
        try {
            Support::admin();$schema=self::schemas()[$op]??null;
            if (!$schema) { throw new Fault('operacao_invalida','Operação desconhecida.'); }
            // MCP decorator can pass empty JSON objects as stdClass in child values.
            foreach (['corpo','query','campos'] as $key) { if (isset($i[$key])&&is_object($i[$key])) { $i[$key]=(array)$i[$key]; } }
            if(isset($i['categorias'])&&is_array($i['categorias'])){$i['categorias']=array_map(static fn($v)=>is_object($v)?(array)$v:$v,$i['categorias']);}
            $valid=rest_validate_value_from_schema($i,$schema,'entrada');
            if (is_wp_error($valid)) { throw new Fault('entrada_invalida','Confira campos, tipos e limites no schema desta operação.'); }
            if ($channel && class_exists('\\Fator3\\McpFiles\\AuthorizationPolicy')) {
                $allowed=\Fator3\McpFiles\AuthorizationPolicy::check('pipedrive/'.$op,$i,!self::writes($op));
                if ($allowed!==true) { throw new Fault('nao_autorizado','A política da conexão MCP recusou esta operação.'); }
            }
            return match ($op) {
                'status'=>Operations::status(),
                'relatorio'=>Report::read($i),
                'retencao-ler'=>self::success(Retention::read()),
                'retencao-configurar'=>Retention::configure($i),
                'api-ler'=>Operations::read($i),
                'api-previa'=>Operations::preview($i),
                'api-aplicar'=>Operations::apply($i),
                'registro-ler'=>self::success(Store::journal($i)),
                'documentacao-ler'=>self::success(Documentation::read($i))
            };
        } catch (Fault $e) { return Support::fail($e); }
        catch (\Throwable $e) { return ['success'=>false,'code'=>'falha_interna','message'=>'A operação não foi concluída. Se houve tentativa de aplicação, consulte o registro antes de repetir.','data'=>null]; }
    }
    private static function success(array $data): array { return ['success'=>true,'code'=>'ok','message'=>'Leitura concluída.','data'=>$data]; }
    public static function outputSchema(): array {
        return ['type'=>'object','required'=>['success','code','message','data'],'properties'=>[
            'success'=>['type'=>'boolean'],'code'=>['type'=>'string'],'message'=>['type'=>'string'],'data'=>['type'=>['object','null']],
            'remote_dispatched'=>['type'=>['boolean','null']],'applied'=>['type'=>['boolean','null']],'previa_id'=>['type'=>'string'],'changed'=>['type'=>'boolean'],'persisted'=>['type'=>'boolean']]];
    }
    public static function abilities(): void {
        if (!function_exists('wp_register_ability')) { return; }
        foreach (self::schemas() as $op=>$schema) {
            $write=self::writes($op);$remote=in_array($op,['api-ler','api-previa','relatorio'],true)?'read':($op==='api-aplicar'?'write':'none');
            wp_register_ability('pipedrive/'.$op,[
                'label'=>'Pipedrive: '.str_replace('-',' ',$op),'description'=>self::descriptions()[$op],'category'=>'pipedrive',
                'input_schema'=>$schema,'output_schema'=>self::outputSchema(),
                'permission_callback'=>static fn()=>is_user_logged_in()&&current_user_can('manage_options'),
                'execute_callback'=>static fn($i=[])=>self::dispatch($op,(array)$i,true),
                'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>!$write,'destructive'=>$op==='api-aplicar','idempotent'=>!in_array($op,['api-previa','retencao-configurar'],true)],
                    'fator3'=>['provider'=>SLUG,'version'=>VERSION,'policy_contract'=>1,'mode'=>$write?'write':'read','remote_effect'=>$remote,
                        'local_effect'=>$write?'write':'none','execution_contract_version'=>'1.0.0']]
            ]);
        }
    }
    public static function routes(): void {
        foreach (self::schemas() as $op=>$schema) {
            $method=in_array($op,['relatorio','status','registro-ler','documentacao-ler','retencao-ler'],true)?'GET':'POST';
            register_rest_route('f3-pipedrive/v1','/'.$op,[
                'methods'=>$method,'permission_callback'=>static fn()=>is_user_logged_in()&&current_user_can('manage_options'),
                'callback'=>static function($request)use($op,$method){
                    $i=$method==='GET'?$request->get_query_params():$request->get_json_params();
                    if ($method==='GET') {
                        unset($i['_wpnonce']);
                        foreach (['offset','limite_bytes','limite','antes_id','limite_plano','max_chamadas','tempo_maximo_segundos'] as $key) {
                            if (isset($i[$key])&&is_string($i[$key])&&ctype_digit($i[$key])) { $i[$key]=(int)$i[$key]; }
                        }
                    }
                    $r=self::dispatch($op,is_array($i)?$i:[]);
                    $response=new \WP_REST_Response($r,$r['code']==='nao_autorizado'?403:200);
                    $response->header('Cache-Control','private, no-store');return $response;
                }
            ]);
        }
    }
}
