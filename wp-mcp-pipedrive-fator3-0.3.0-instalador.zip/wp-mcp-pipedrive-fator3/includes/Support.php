<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

final class Fault extends \RuntimeException {
    public function __construct(public string $reason, string $message, public array $details = []) {
        parent::__construct($message);
    }
}
final class Support {
    public static function admin(): void {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            throw new Fault('nao_autorizado', 'Esta operação exige permissão de administrador.');
        }
    }
    public static function json($value): string {
        $json = wp_json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) { throw new Fault('json_invalido', 'Os dados não são JSON válido.'); }
        return $json;
    }
    public static function canonical($value): string {
        $sort = static function ($v) use (&$sort) {
            if (is_array($v)) {
                if (!array_is_list($v)) { ksort($v); }
                return array_map($sort, $v);
            }
            return $v;
        };
        return self::json($sort($value));
    }
    public static function digest($value): string { return hash('sha256', self::canonical($value)); }
    public static function fail(Fault $e): array {
        return ['success'=>false,'code'=>$e->reason,'message'=>$e->getMessage(),'data'=>(object)$e->details];
    }
    public static function safe($value, int $depth = 0) {
        if ($depth > 30) { return '[limite de profundidade]'; }
        if (is_object($value)) { $value = (array)$value; }
        if (is_array($value)) {
            foreach ($value as $k => $v) {
                if (is_string($k) && preg_match('/token|secret|password|authorization|cookie|credential|api[_-]?key/i', $k)) {
                    $value[$k] = '[redigido]';
                } else { $value[$k] = self::safe($v, $depth + 1); }
            }
        } elseif (is_string($value)) {
            $value = preg_replace('/(api_token|access_token|authorization|password|secret)\s*[=:]\s*[^\s&"<>]+/i', '$1=[redigido]', $value);
            $value = preg_replace('/Bearer\s+[A-Za-z0-9._~+\/-]+/i', 'Bearer [redigido]', $value);
        }
        return $value;
    }
    public static function seal(array $value): string {
        if (!function_exists('openssl_encrypt')) { throw new Fault('cifra_indisponivel','OpenSSL indisponível.'); }
        $iv = random_bytes(12); $tag = '';
        $cipher = openssl_encrypt(self::json($value), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag, SLUG, 16);
        if ($cipher === false) { throw new Fault('cifra_indisponivel','Falha ao proteger o registro privado.'); }
        return base64_encode($iv . $tag . $cipher);
    }
    public static function open(string $cipher): array {
        $raw = base64_decode($cipher, true);
        if ($raw === false || strlen($raw) < 29) { throw new Fault('registro_ilegivel','Registro privado ilegível. Preserve os salts e o backup.'); }
        $plain = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16), SLUG);
        $value = $plain === false ? null : json_decode($plain, true);
        if (!is_array($value)) { throw new Fault('registro_ilegivel','Registro privado ilegível. Preserve os salts e o backup.'); }
        return $value;
    }
    private static function key(): string { return hash('sha256', wp_salt('auth') . '|' . SLUG . '|' . get_current_blog_id(), true); }
    public static function guardResult($r): array {
        if (is_wp_error($r)) {
            $code = (string)$r->get_error_code();
            throw new Fault(self::knownCode($code), self::message($code));
        }
        if (!is_array($r) || !is_bool($r['success'] ?? null)) { throw new Fault('contrato_invalido','Resposta incompatível com o contrato do Core.'); }
        if (!$r['success']) {
            $code = self::knownCode((string)($r['code'] ?? 'core_recusou'));
            throw new Fault($code, self::message($code));
        }
        return $r;
    }
    public static function knownCode(string $code): string {
        return in_array($code, ['saldo_conta_baixo','operacao_nao_autorizada','core_em_recuperacao','orcamento_esgotado','pipedrive_orcamento_esgotado','pausa_remota','rate_limit','credencial_invalida','revisao_conflitante','contexto_alterado','core_indisponivel'], true) ? $code : 'core_recusou';
    }
    public static function message(string $code): string {
        return match ($code) {
            'saldo_conta_baixo'=>'O saldo da conta está abaixo da reserva de 3.000 unidades.',
            'operacao_nao_autorizada'=>'Autorize este provider no Site Core do site-porta.',
            'core_em_recuperacao'=>'O Site Core está em recuperação.',
            'orcamento_esgotado','pipedrive_orcamento_esgotado'=>'O orçamento de operação foi esgotado.',
            'pausa_remota','rate_limit'=>'A conta está em pausa por limite remoto.',
            'contexto_alterado','revisao_conflitante'=>'O contexto do Core mudou; gere uma nova prévia.',
            default=>'O cliente do Core recusou a operação. Consulte o diagnóstico administrativo.'
        };
    }
}
