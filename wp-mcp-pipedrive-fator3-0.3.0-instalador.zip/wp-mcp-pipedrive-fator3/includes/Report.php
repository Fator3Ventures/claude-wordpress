<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Aggregate-only, request-scoped reader. Never persists supplier records. */
final class Report {
    private const DIMS=['parceiro','unidade','canal','campanha','ponto_conversao'];
    private const SOURCES=['campos'=>'/v1/dealFields','leads_abertos'=>'/v1/leads','leads_arquivados'=>'/v1/leads/archived','negocios_ativos'=>'/api/v2/deals','negocios_arquivados'=>'/api/v2/deals/archived'];
    private array $status,$input,$issues=[],$sources=[],$fields=[],$mapping=[],$aliases=[],$seen=[],$leads=[],$deals=[],$outcomes=[];
    private int $from,$until,$calls=0,$sent=0,$uncertain=0,$records=0,$groups=0,$groupBytes=0,$duplicates=0,$activeLeads=0,$activeDeals=0;
    private int $open=0,$archived=0,$won=0,$lost=0;
    private float $started;
    private string $key;
    public static function schema(): array {
        $dims=[];foreach(array_merge(self::DIMS,['motivo_ganho']) as $d){$dims[$d]=['type'=>'string','pattern'=>'^[a-f0-9]{40}$'];}
        $dims['canal']['pattern']='^(?:[a-f0-9]{40}|channel)$';
        return ['type'=>'object','additionalProperties'=>false,'required'=>['data_inicio','data_fim'],'properties'=>[
            'data_inicio'=>['type'=>'string','pattern'=>'^\d{4}-\d{2}-\d{2}$'],
            'data_fim'=>['type'=>'string','pattern'=>'^\d{4}-\d{2}-\d{2}$'],
            'fuso'=>['type'=>'string','maxLength'=>80,'default'=>'America/Sao_Paulo'],
            'criterio_leads'=>['type'=>'string','enum'=>['criacao','arquivamento'],'default'=>'criacao','description'=>'Arquivamento afeta apenas leads arquivados; abertos usam criação. Sem data de arquivo não se presume update_time.'],
            'campos'=>['type'=>'object','properties'=>$dims,'additionalProperties'=>false,'description'=>'Chaves de campos customizados; omissão tenta nome exato normalizado. Canal nativo somente se channel explícito.'],
            'categorias'=>['type'=>'array','maxItems'=>200,'items'=>['type'=>'object','additionalProperties'=>false,'required'=>['dimensao','valor','codigo'],'properties'=>[
                'dimensao'=>['type'=>'string','enum'=>array_merge(self::DIMS,['motivo_arquivamento','motivo_ganho','motivo_perda'])],
                'valor'=>['type'=>'string','minLength'=>1,'maxLength'=>500],'codigo'=>['type'=>'integer','minimum'=>1,'maximum'=>1000000000]]],
                'description'=>'Dicionário opcional em memória. Valores livres saem apenas como código numérico; nunca são refletidos ou gravados.'],
            'limite_plano'=>['type'=>'integer','minimum'=>1,'maximum'=>1000000000,'description'=>'Limite combinado confirmado na tela Uso do Pipedrive. Ausência retorna comparação indisponível.'],
            'max_chamadas'=>['type'=>'integer','minimum'=>1,'maximum'=>120,'default'=>100],
            'tempo_maximo_segundos'=>['type'=>'integer','minimum'=>1,'maximum'=>120,'default'=>45]
        ]];
    }
    public static function read(array $i): array { Support::admin();return (new self($i))->run(); }
    private function __construct(array $i) {
        $this->input=$i+['fuso'=>'America/Sao_Paulo','criterio_leads'=>'criacao','max_chamadas'=>100,'tempo_maximo_segundos'=>45];
        try {$tz=new \DateTimeZone($this->input['fuso']);}catch(\Throwable $e){throw new Fault('entrada_invalida','Fuso IANA inválido.');}
        if(!in_array($this->input['fuso'],\DateTimeZone::listIdentifiers(\DateTimeZone::ALL_WITH_BC),true)){throw new Fault('entrada_invalida','Use um identificador IANA de fuso.');}
        $dates=[];
        foreach(['data_inicio','data_fim'] as $k){$d=\DateTimeImmutable::createFromFormat('!Y-m-d',$i[$k],$tz);if(!$d||$d->format('Y-m-d')!==$i[$k])throw new Fault('entrada_invalida','Data civil inválida.');$dates[]=$d;}
        if($dates[0]>$dates[1]||$dates[0]->diff($dates[1])->days>3660)throw new Fault('entrada_invalida','Período invertido ou maior que 3.660 dias.');
        $this->from=$dates[0]->getTimestamp();$this->until=$dates[1]->modify('+1 day')->getTimestamp();
        foreach($i['categorias']??[] as $a){$k=$a['dimensao'].'|'.hash('sha256',$a['valor']);if(isset($this->aliases[$k])&&$this->aliases[$k]!==$a['codigo'])throw new Fault('entrada_invalida','Um valor não pode apontar para códigos diferentes.');$this->aliases[$k]=$a['codigo'];}
        $this->status=CoreClient::status();$this->key=hash_hmac('sha256',Support::json([$this->status['conta']['conta_id'],get_current_blog_id(),'report-categories-v1']),wp_salt('auth'),true);
        $this->started=microtime(true);
        foreach(self::SOURCES as $name=>$path)$this->sources[$name]=['concluida'=>false,'paginas'=>0,'registros'=>0];
    }
    private function issue(string $code): void {$this->issues[$code]=true;}
    private function run(): array {
        foreach(self::SOURCES as $name=>$path){
            try {$this->collect($name,$path);}catch(Fault $e){$this->issue($e->reason);break;}catch(\Throwable $e){$this->issue('resposta_incompativel');break;}
            if($name==='campos')$this->resolveFields();
        }
        $collected=!in_array(false,array_column($this->sources,'concluida'),true);
        if(!isset($this->input['limite_plano']))$this->issue('limite_plano_nao_informado');
        $usageComplete=$this->sources['leads_abertos']['concluida']&&$this->sources['negocios_ativos']['concluida']&&$this->duplicates===0&&!isset($this->issues['registro_invalido'])&&!isset($this->issues['estado_arquivamento_divergente']);
        $observed=$this->activeLeads+$this->activeDeals;$limit=$this->input['limite_plano']??null;
        $exactCost=$this->uncertain===0?$this->sent*20:null;
        $data=['versao'=>VERSION,'completo'=>$collected&&!$this->issues,'coleta_completa'=>$collected,'pendencias'=>array_keys($this->issues),
            'periodo'=>['data_inicio'=>$this->input['data_inicio'],'data_fim'=>$this->input['data_fim'],'fuso'=>$this->input['fuso'],'inicio_utc'=>gmdate('Y-m-d\TH:i:s\Z',$this->from),'fim_exclusivo_utc'=>gmdate('Y-m-d\TH:i:s\Z',$this->until),'leads_abertos'=>'add_time','leads_arquivados'=>$this->input['criterio_leads']==='criacao'?'add_time':'archive_time','negocios_por_funil'=>'add_time','ganhos'=>'won_time','perdidos'=>'lost_time'],
            'escopo'=>'Registros visíveis ao token; estado atual, leitura sequencial sem snapshot histórico ou transacional.',
            'campos'=>$this->mapping,'fontes'=>$this->sources,
            'leads'=>['abertos_observados'=>$this->open,'arquivados_observados'=>$this->archived,'grupos'=>array_values($this->leads)],
            'negocios'=>['por_funil_etapa'=>array_values($this->deals),'ganhos_observados'=>$this->won,'perdidos_observados'=>$this->lost,'por_resultado_motivo'=>array_values($this->outcomes)],
            'uso_plano'=>['fora_do_periodo'=>true,'coleta_completa'=>$usageComplete,'leads_ativos_observados'=>$this->activeLeads,'negocios_ativos_observados'=>$this->activeDeals,'total_observado'=>$observed,'total'=>$usageComplete?$observed:null,'limite'=>$limit,'origem_limite'=>$limit===null?'nao_disponivel':'informado_pelo_chamador','percentual'=>$usageComplete&&$limit!==null?round(100*$observed/$limit,2):null,'saldo'=>$usageComplete&&$limit!==null?$limit-$observed:null,'escopo'=>'Visibilidade do token; conferir acesso global antes de comparar com Uso da conta.'],
            'custo'=>['consumidor'=>'operacao','unidade'=>'unidades locais do Core; não tokens oficiais Pipedrive','gasto'=>$exactCost,'minimo'=>$this->sent*20,'maximo'=>($this->sent+$this->uncertain)*20,'chamadas_tentadas'=>$this->calls,'enviadas_confirmadas'=>$this->sent,'envio_incerto'=>$this->uncertain],
            'duplicatas'=>$this->duplicates,'privacidade'=>'Somente agregados. IDs de opções/funil/etapa, códigos fornecidos e HMAC de categorias; nenhum texto livre do fornecedor. HMAC estável neste site/conta, não anonimização estatística.'];
        return ['success'=>true,'code'=>$data['completo']?'ok':'relatorio_parcial','message'=>$data['completo']?'Relatório agregado concluído.':'Relatório agregado com pendências; não trate os valores observados como totais fechados.','data'=>$data,'remote_dispatched'=>$this->uncertain?null:$this->sent>0];
    }
    private function collect(string $name,string $path): void {
        $v2=str_starts_with($path,'/api/v2/');$query=['limit'=>100];if(!$v2)$query['start']=0;$tokens=[];
        do {
            if($this->calls>=$this->input['max_chamadas'])throw new Fault('limite_chamadas','');
            if(microtime(true)-$this->started>=$this->input['tempo_maximo_segundos'])throw new Fault('limite_tempo','');
            $route=Policy::route('GET',$path,$query);
            ++$this->calls;$r=CoreClient::request('GET',$route['caminho'],$route['query'],[],$this->status);
            if(($r['remote_dispatched']??null)===true)++$this->sent;elseif(($r['remote_dispatched']??null)!==false)++$this->uncertain;
            if(!$r['success'])throw new Fault($r['code'],'');
            $body=$r['data']['body']??null;$rows=is_array($body)?($body['data']??null):null;
            // Explicit null is the supplier's empty collection, never missing data.
            if(is_array($body)&&array_key_exists('data',$body)&&$rows===null)$rows=[];
            if(!is_array($rows)||!array_is_list($rows)||count($rows)>100)throw new Fault('pagina_invalida','');
            ++$this->sources[$name]['paginas'];
            foreach($rows as $row){
                if(++$this->records>12000)throw new Fault('limite_registros','');
                if(!is_array($row)){ $this->issue('registro_invalido');continue; }
                ++$this->sources[$name]['registros'];
                if($name==='campos'){$this->field($row);continue;}
                $this->record($name,$row);
            }
            $additional=$body['additional_data']??null;
            if(!is_array($additional))throw new Fault('paginacao_invalida','');
            if($v2){
                if(!array_key_exists('next_cursor',$additional))throw new Fault('paginacao_invalida','');
                $next=$additional['next_cursor'];$more=$next!==null;
                if($more&&(!is_string($next)||$next===''||strlen($next)>1024))throw new Fault('paginacao_invalida','');
                if($more)$query['cursor']=$next;
            }else{
                $pagination=$additional['pagination']??null;
                if(!is_array($pagination)||!is_bool($pagination['more_items_in_collection']??null))throw new Fault('paginacao_invalida','');
                $more=$pagination['more_items_in_collection'];$next=$pagination['next_start']??null;
                if($more&&(!is_int($next)||$next<=($query['start']??0)))throw new Fault('paginacao_invalida','');
                if($more)$query['start']=$next;
            }
            if($more){$token=hash('sha256',(string)$next);if(!$rows||isset($tokens[$token]))throw new Fault('paginacao_sem_progresso','');$tokens[$token]=true;}
        }while($more);
        $this->sources[$name]['concluida']=true;
    }
    private function field(array $f): void {
        if(!is_string($f['key']??null)||!preg_match('/^[a-f0-9]{40}$/D',$f['key']))return;
        $type=$f['field_type']??null;$name=is_string($f['name']??null)?strtolower(remove_accents(trim($f['name']))):'';
        $options=[];foreach($f['options']??[] as $o){if(is_array($o)&&is_numeric($o['id']??null))$options[(string)$o['id']]=true;}
        $this->fields[$f['key']]=['name'=>$name,'type'=>$type,'options'=>$options];
    }
    private function resolveFields(): void {
        $names=['parceiro'=>'parceiro','unidade'=>'unidade','canal'=>'canal','campanha'=>'campanha','ponto_conversao'=>'ponto de conversao','motivo_ganho'=>'motivo de ganho'];
        foreach($names as $dim=>$name){
            $key=$this->input['campos'][$dim]??null;
            if($key===null){$found=array_keys(array_filter($this->fields,static fn($f)=>$f['name']===$name));if(count($found)===1)$key=$found[0];elseif(count($found)>1)$this->issue('campo_ambiguo_'.$dim);}
            $native=$dim==='canal'&&$key==='channel';$found=$key!==null&&($native||isset($this->fields[$key]));
            $allowed=$native||($found&&in_array($this->fields[$key]['type'],['enum','set','varchar','varchar_auto','text'],true));
            $this->mapping[$dim]=['chave'=>$found&&$allowed?$key:null,'tipo'=>$native?'enum':($found&&$allowed?$this->fields[$key]['type']:null),'situacao'=>$found&&$allowed?'mapeado':($dim==='motivo_ganho'&&$key===null?'sem_campo_nativo':'indisponivel')];
            if((!$found||!$allowed)&&$dim!=='motivo_ganho')$this->issue('campo_indisponivel_'.$dim);
            if($dim==='motivo_ganho'&&$key!==null&&(!$found||!$allowed))$this->issue('campo_indisponivel_motivo_ganho');
        }
    }
    private function category(string $dim,$value,?string $field=null): string {
        if($value===null||$value==='')return 'sem_valor';
        if(is_array($value)){
            if(!array_is_list($value)){if(array_key_exists('value',$value))return $this->category($dim,$value['value'],$field);$this->issue('valor_categoria_invalido');return 'valor_invalido';}
            $partField=$field!==null&&($this->fields[$field]['type']??null)==='set'?$field.'#enum':$field;
            $parts=[];foreach($value as $v)$parts[]=$this->category($dim,$v,$partField);sort($parts,SORT_STRING);return 'conjunto:'.implode(',',array_unique($parts));
        }
        if(!is_string($value)&&!is_int($value)){$this->issue('valor_categoria_invalido');return 'valor_invalido';}
        $value=(string)$value;
        if(isset($this->aliases[$dim.'|'.hash('sha256',$value)]))return 'codigo:'.$this->aliases[$dim.'|'.hash('sha256',$value)];
        $type=$field!==null?($this->fields[$field]['type']??null):null;
        if($type==='set')return $this->category($dim,explode(',',$value),$field);
        if($field!==null&&str_ends_with($field,'#enum'))$field=substr($field,0,-5);
        if(($field==='channel'&&ctype_digit($value))||($field!==null&&isset($this->fields[$field]['options'][$value])))return 'opcao:'.$value;
        return 'categoria:'.hash_hmac('sha256',$dim.'|'.$value,$this->key);
    }
    private function mapped(string $dim,array $row): string {
        $key=$this->mapping[$dim]['chave']??null;if($key===null)return 'sem_campo';
        return $this->category($dim,$row[$key]??($row['custom_fields'][$key]??null),$key);
    }
    private function inPeriod($value): bool {
        if(!is_string($value)||!preg_match('/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?$/D',$value)){$this->issue('data_registro_indisponivel');return false;}
        if(!checkdate((int)substr($value,5,2),(int)substr($value,8,2),(int)substr($value,0,4))){$this->issue('data_registro_indisponivel');return false;}
        try{$time=new \DateTimeImmutable($value,new \DateTimeZone('UTC'));}catch(\Throwable $e){$this->issue('data_registro_indisponivel');return false;}
        $t=$time->getTimestamp();return $t>=$this->from&&$t<$this->until;
    }
    private function add(array &$target,array $dimensions): void {
        $key=Support::digest($dimensions);if(!isset($target[$key])){$this->groupBytes+=strlen(Support::json($dimensions))+32;if(++$this->groups>200||$this->groupBytes>32000)throw new Fault('limite_grupos','');$target[$key]=$dimensions+['quantidade'=>0];}++$target[$key]['quantidade'];
    }
    private function record(string $source,array $row): void {
        $lead=str_starts_with($source,'leads_');$archived=str_ends_with($source,'_arquivados');$id=$row['id']??null;
        if(($lead&&(!is_string($id)||!preg_match('/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/iD',$id)))||(!$lead&&(!is_int($id)||$id<1))){$this->issue('registro_invalido');return;}
        $key=($lead?'l':'d').hash('sha256',(string)$id);if(isset($this->seen[$key])){++$this->duplicates;$this->issue('registros_repetidos');return;}$this->seen[$key]=true;
        if(isset($row['is_archived'])&&$row['is_archived']!==$archived){$this->issue('estado_arquivamento_divergente');return;}
        if(($row['is_deleted']??false)===true||($row['status']??'')==='deleted')return;
        if($lead){
            if(!$archived)++$this->activeLeads;
            $field=$archived&&$this->input['criterio_leads']==='arquivamento'?'archive_time':'add_time';
            if(!$this->inPeriod($row[$field]??null))return;
            $dims=['estado'=>$archived?'arquivado':'aberto'];foreach(self::DIMS as $dim)$dims[$dim]=$this->mapped($dim,$row);
            $dims['motivo_arquivamento']=$archived?$this->category('motivo_arquivamento',$row['archive_reason']??null):'nao_aplicavel';
            $this->add($this->leads,$dims);if($archived)++$this->archived;else ++$this->open;
        }else{
            $state=$row['status']??null;if(!in_array($state,['open','won','lost'],true)){$this->issue('registro_invalido');return;}
            if(!$archived)++$this->activeDeals;
            $pipeline=$row['pipeline_id']??null;$stage=$row['stage_id']??null;
            if(!is_int($pipeline)||$pipeline<1||!is_int($stage)||$stage<1){$this->issue('funil_etapa_indisponivel');$pipeline=null;$stage=null;}
            if($this->inPeriod($row['add_time']??null))$this->add($this->deals,['funil_id'=>$pipeline,'etapa_id'=>$stage,'estado'=>$state,'arquivado'=>$archived]);
            if($state==='won'||$state==='lost'){
                if(!$this->inPeriod($row[$state==='won'?'won_time':'lost_time']??null))return;
                $reason=$state==='won'?$this->mapped('motivo_ganho',$row):$this->category('motivo_perda',$row['lost_reason']??null);
                $this->add($this->outcomes,['resultado'=>$state==='won'?'ganho':'perdido','motivo'=>$reason]);if($state==='won')++$this->won;else ++$this->lost;
            }
        }
    }
}
