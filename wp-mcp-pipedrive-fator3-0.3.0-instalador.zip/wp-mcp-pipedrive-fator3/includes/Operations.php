<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

final class Operations {
    public static function status(): array {
        Support::admin();
        $base=['provider'=>SLUG,'version'=>VERSION,'contrato_exigido'=>CONTRACT,'registro_cliente'=>CoreClient::registration(),
            'documentacao'=>'pipedrive/documentacao-ler','chamada_externa'=>false,'retencao'=>Retention::read()];
        try { return ['success'=>true,'code'=>'ok','message'=>'Estado local.','data'=>$base+CoreClient::status()]; }
        catch (Fault $e) { return ['success'=>false,'code'=>$e->reason,'message'=>$e->getMessage(),'data'=>$base]; }
    }
    public static function read(array $i): array {
        Policy::route('GET',$i['caminho'],$i['query']??[]);
        return CoreClient::request('GET',$i['caminho'],$i['query']??[],[],CoreClient::status());
    }
    private static function current(array $route, array $status): array {
        if ($route['id']===null) { return ['estado'=>null,'leituras'=>0]; }
        $resource=$route['resource'];$path=$route['caminho'];$reads=0;
        $collection=in_array($resource,['dealFields','personFields','organizationFields','leadLabels'],true);
        if ($collection) { $path='/v1/'.$resource; }
        $query=$collection && $resource!=='leadLabels'?['start'=>0,'limit'=>500]:[];
        do {
            Policy::route('GET',$path,$query);
            $response=CoreClient::request('GET',$path,$query,[],$status);++$reads;
            if (!$response['success']) { throw new Fault($response['code'],$response['message']); }
            $body=$response['data']['body'];
            if (!is_array($body)||!array_key_exists('data',$body)||!is_array($body['data'])) { throw new Fault('estado_incompleto','A leitura não retornou o estado atual completo.'); }
            if (!$collection) { return ['estado'=>$body['data'],'leituras'=>$reads]; }
            if (!array_is_list($body['data'])) { throw new Fault('estado_incompleto','Catálogo não retornou uma lista.'); }
            foreach ($body['data'] as $record) {
                if (is_array($record) && (string)($record['id']??'')===(string)$route['id']) { return ['estado'=>$record,'leituras'=>$reads]; }
            }
            $pagination=$body['additional_data']['pagination']??[];
            if (($pagination['more_items_in_collection']??false)!==true) { break; }
            $next=$pagination['next_start']??null;
            if ($resource==='leadLabels'||!is_int($next)||$next<=($query['start']??-1)) { throw new Fault('estado_incompleto','Paginação do catálogo inválida.'); }
            $query['start']=$next;
        } while ($reads<20);
        if ($reads>=20 && ($pagination['more_items_in_collection']??false)) { throw new Fault('limite_de_leitura','Catálogo excedeu 20 páginas; operação não preparada.'); }
        throw new Fault('registro_nao_encontrado','O identificador não foi encontrado no catálogo permitido.');
    }
    public static function preview(array $i): array {
        $route=Policy::route($i['metodo'],$i['caminho'],[],$i['corpo']??[]);
        Store::ready();Store::cleanup();
        $status=CoreClient::status();$now=self::current($route,$status);
        $removed=Policy::removals($route,$now['estado']??[]);
        $id=bin2hex(random_bytes(16));
        $body=$route['corpo'];unset($body['remover_opcoes']);
        $summary=$route['metodo'].' '.$route['caminho'].'; chaves: '.implode(', ',array_keys($body));
        if ($removed) { $summary.='; remover opções: '.implode(', ',array_column($removed,'id')); }
        // Bind confirmation to a short digest so two bodies with the same keys cannot share it.
        $summary.='; prévia '.substr(Support::digest([$id,$body,$removed]),0,16);
        $phrase='Confirmo por ordem do dono de '.wp_date('d/m/Y',null,new \DateTimeZone('America/Sao_Paulo')).': '.$summary;
        $structureBefore=$route['classe']==='estrutura' && is_array($now['estado']) ? array_intersect_key($now['estado'],array_flip(['name','field_type','options'])) : [];
        $payload=['structure_before'=>Support::safe($structureBefore),'route'=>$route,'body'=>$body,'state_hash'=>Support::digest($now['estado']),'confirmacao'=>$phrase,'summary'=>$summary,'removidas'=>$removed];
        Store::create($id,CoreClient::binding($status),$payload);
        return ['success'=>true,'code'=>'previa_criada','message'=>'Prévia salva por 15 minutos. Nenhuma mutação foi enviada ao Pipedrive.',
            'data'=>['previa_id'=>$id,'expira_em'=>gmdate('Y-m-d\TH:i:s\Z',time()+900),'estado_atual'=>$now['estado'],'corpo_a_enviar'=>$body,
                'classe'=>$route['classe'],'se_desfaz'=>$route['se_desfaz'],'reversao'=>$route['reversao'],'opcoes_a_remover'=>$removed,
                'resumo'=>$summary,'confirmacao_exigida'=>$route['classe']==='estrutura'?$phrase:null,
                'custo_estimado'=>['previa_gets'=>$now['leituras'],'previa_unidades'=>$now['leituras']*20,'aplicar_gets_estimados'=>$now['leituras'],'aplicar_escrita'=>10,'observacao'=>'Estimativa local do contrato; paginação e revalidação também consomem orçamento.']]];
    }
    public static function apply(array $i): array {
        Store::ready();$row=Store::get($i['previa_id']);
        // Expired pending previews never become valid by changing Core state.
        if ($row['state']==='expired' || ($row['state']==='ready' && (int)$row['expires']<=time())) { throw new Fault('previa_expirada','A prévia expirou; gere outra e revise o estado atual.'); }
        $status=CoreClient::status();
        if (!hash_equals($row['binding'],CoreClient::binding($status))) { throw new Fault('contexto_alterado',Support::message('contexto_alterado')); }
        if ($row['state']==='done') { return Support::open($row['result']); }
        if ($row['state']==='running') { throw new Fault('resultado_incerto','Operação em execução ou interrompida. Consulte o registro e reconcilie o fornecedor; não reenvie.'); }
        if ($row['state']!=='ready') { throw new Fault('registro_ilegivel','Estado da operação inválido.'); }
        $p=Support::open($row['payload']);$route=$p['route'];
        Policy::route($route['metodo'],$route['caminho'],[],$route['corpo']);
        if ($route['classe']==='estrutura' && (!is_string($i['confirmacao']??null)||!hash_equals($p['confirmacao'],$i['confirmacao']))) {
            throw new Fault('confirmacao_ausente','Copie exatamente a frase devolvida pela prévia, após a ordem do dono.');
        }
        $current=self::current($route,$status);
        if (!hash_equals($p['state_hash'],Support::digest($current['estado']))) { throw new Fault('estado_alterado','O registro mudou após a prévia. Gere uma nova prévia antes de escrever.'); }
        Policy::removals($route,$current['estado']??[]);
        $meta=self::metadata($i['previa_id'],$route,$p);
        if (!Store::claim($i['previa_id'],$meta)) {
            $again=Store::get($i['previa_id']);
            if ($again['state']==='done') { return Support::open($again['result']); }
            if ((int)$again['expires']<=time() && $again['state']==='ready') { throw new Fault('previa_expirada','A prévia expirou antes da aplicação.'); }
            throw new Fault('resultado_incerto','Outra execução adquiriu esta operação. Não reenvie.');
        }
        try { $r=CoreClient::request($route['metodo'],$route['caminho'],[],$p['body'],$status,$i['previa_id']); }
        catch (Fault $e) { $r=Support::fail($e)+['remote_dispatched'=>false]; }
        catch (\Throwable $e) { $r=['success'=>false,'code'=>'resultado_incerto','message'=>'Execução interrompida; reconcilie o efeito.','data'=>null,'remote_dispatched'=>null]; }
        $r['previa_id']=$i['previa_id'];
        $r['applied']=$r['success']?true:(($r['remote_dispatched']??null)===false?false:null);
        $meta['status']=$r['code'];$meta['http_status']=$r['data']['http_status']??null;$meta['saldo_depois']=$r['data']['saldo_conta']??null;
        Store::finish($i['previa_id'],$r,$meta);
        Store::cleanup();
        return $r;
    }
    private static function metadata(string $id,array $route,array $p): array {
        $m=['previa_id'=>$id,'metodo'=>$route['metodo'],'caminho'=>$route['caminho'],'classe'=>$route['classe'],'status'=>'em_execucao',
            'chaves_alteradas'=>array_keys($p['body']),'http_status'=>null,'saldo_depois'=>null];
        if ($route['classe']==='estrutura') {
            $m['estrutura']=['anterior'=>$p['structure_before']??[]];
            if (isset($p['body']['name'])) { $m['estrutura']['nome']=Support::safe($p['body']['name']); }
            if (isset($p['body']['options'])) {
                $m['estrutura']['opcoes']=array_map(static fn($o)=>Support::safe(array_intersect_key($o,array_flip(['id','label']))),$p['body']['options']);
            }
            $m['estrutura']['opcoes_removidas']=Support::safe($p['removidas']);
        }
        return $m;
    }
}
