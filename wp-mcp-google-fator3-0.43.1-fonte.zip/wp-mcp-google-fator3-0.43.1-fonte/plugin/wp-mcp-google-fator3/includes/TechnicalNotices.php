<?php
/** Durable producer outbox. Core owns recipients, reservation and delivery. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
defined('ABSPATH') || exit;

final class TechnicalNotices {
    private const PAGE_SIZE = 100;
    private const SILENT_ACCESS_HOOK = 'f3base_incidente_acesso_encerrar_v1';

    private static function queue_status(array $queue): string {
        if (!$queue) return 'accepted';
        return isset($queue[0]['motivo_encerramento']) && !has_filter(self::SILENT_ACCESS_HOOK)
            ? 'awaiting_access_core' : 'pending';
    }

    public static function publish(string $code, string $resource, bool $failed, array $details = []): array {
        if (Confirmation::capturing()) return ['ok'=>false, 'codigo'=>'simulation'];
        $id = hash('sha256', Connections::id().'|'.$code.'|'.$resource);
        $lock = Lock::acquire('technical:'.$id, 30);
        if ($lock === null) return ['ok'=>false, 'codigo'=>'occupied'];
        try {
            $old = Records::get('technicalnotice', $id);
            $access = $code === 'integracao_indisponivel' && preg_match('/^[a-f0-9]{64}$/D', $resource);
            $silent = $access && !$failed && in_array($details['access_closure'] ?? null, ['nao_usado', 'consolidado'], true);
            if (!$old && !$failed && !$silent) return ['ok'=>true, 'estado'=>'sem_incidente'];
            $generation = $access ? ($details['access_generation'] ?? null) : null;
            if (is_int($generation) && ($old['event']['geracao_acesso'] ?? 0) > $generation) {
                return ['ok'=>true, 'estado'=>'observacao_superada'];
            }
            $event = ['pacote'=>'google', 'codigo'=>$code,
                'recurso'=>Connections::id().'/'.$resource,
                'estado'=>$failed?'aberto':'recuperado',
                'acao_humana'=>$details['human_action']??true];
            if (is_int($generation) && $generation > 0) $event['geracao_acesso'] = $generation;
            if ($silent) {
                $event['motivo_encerramento'] = $details['access_closure'];
                $event['acao_humana'] = false;
            }
            if (isset($details['expires'])) $event['vence_em'] = $details['expires'];
            if (isset($details['iam'])) $event['iam'] = $details['iam'];
            $queue = $old['queue'] ?? [];
            if (($old['event']??null) !== $event) {
                $event['desde'] = $failed ? time() : (int)($old['since']??time());
                if ($silent) {
                    // These opens have not been acknowledged. The Core checks its own delivery reservations.
                    while ($queue && end($queue)['estado'] === 'aberto') array_pop($queue);
                }
                $queue[] = $event;
                $new = ['id'=>$id, 'connection_id'=>Connections::id(), 'event'=>array_diff_key($event,['desde'=>true]),
                    'since'=>$event['desde'], 'queue'=>$queue, 'status'=>self::queue_status($queue), 'task'=>'core_notice', 'run_after'=>time()];
                $saved = Records::put('technicalnotice',$id,$new);
                if (empty($saved['success'])) return ['ok'=>false, 'codigo'=>'outbox_not_saved'];
                $old = $new;
            }
            return self::flush($id, $old);
        } finally { Lock::release($lock); }
    }

    private static function flush(string $id, array $row): array {
        if (empty($row['queue'])) return $row['receipt']??['ok'=>true,'estado'=>'aceito'];
        $result = ['ok'=>false, 'codigo'=>'core_contract_unavailable'];
        foreach ($row['queue'] as $event) {
            $hook = isset($event['motivo_encerramento']) ? self::SILENT_ACCESS_HOOK : 'f3base_incidente_publicar_v1';
            if (!has_filter($hook)) {
                $status = self::queue_status($row['queue']);
                if ($row['status'] !== $status) {
                    $row['status'] = $status;
                    if (empty(Records::put('technicalnotice', $id, $row)['success'])) return ['ok'=>false,'codigo'=>'outbox_not_saved'];
                }
                return ['ok'=>false,'codigo'=>'core_contract_unavailable'];
            }
            try { $result = apply_filters($hook, null, $event); }
            catch (\Throwable $error) { $result = ['ok'=>false, 'codigo'=>'core_contract_failed']; }
            if (!is_array($result) || empty($result['ok'])) break;
            array_shift($row['queue']);
            $row['status'] = self::queue_status($row['queue']);
            $row['receipt'] = array_intersect_key($result,array_flip(['ok','estado','codigo']));
            if (empty(Records::put('technicalnotice',$id,$row)['success'])) return ['ok'=>false,'codigo'=>'outbox_receipt_not_saved'];
        }
        return is_array($result)?$result:['ok'=>false,'codigo'=>'core_contract_unavailable'];
    }

    public static function dispatch(): void {
        self::dispatch_queue('pending');
        if (has_filter(self::SILENT_ACCESS_HOOK)) self::dispatch_queue('awaiting_access_core');
    }

    private static function dispatch_queue(string $state): void {
        $key = 'f3_mcp_google_notice_cursor_' . $state;
        $cursor = (int) get_option($key, 0);
        $filters = ['state' => $state];
        if ($cursor > 0) {
            $filters['sequence_before'] = $cursor;
        }
        $rows = Storage\Repository::select('technicalnotice', $filters, self::PAGE_SIZE + 1);
        if (is_wp_error($rows) || (!$rows && !$cursor)) {
            return;
        }

        // Short queues need only the original per-notice locks. Multiple-page passes
        // also serialize cursor changes so a concurrent worker cannot rewind the scan.
        $more = count($rows) > self::PAGE_SIZE;
        $scan = null;
        if ($cursor || $more) {
            $scan = Lock::acquire('technical-page:' . $state, 120);
            if ($scan === null) {
                return;
            }
        }
        try {
            if ($scan !== null && (int) get_option($key, 0) !== $cursor) {
                return;
            }
            foreach (array_slice($rows, 0, self::PAGE_SIZE) as $entry) {
                $id = $entry['record_id'];
                $lock = Lock::acquire('technical:' . $id, 30);
                if ($lock === null) {
                    continue;
                }
                try {
                    $row = Records::get('technicalnotice', $id);
                    if (($row['status'] ?? null) === $state) {
                        self::flush($id, $row);
                    }
                } finally {
                    Lock::release($lock);
                }
            }
            // sequence_before is inclusive. Save the first row not visited yet.
            if ($more) {
                update_option($key, (int) $rows[self::PAGE_SIZE]['sequence'], false);
            } elseif ($cursor) {
                delete_option($key);
            }
        } finally {
            if ($scan !== null) {
                Lock::release($scan);
            }
        }
    }

    public static function observe(): void {
        if (Confirmation::capturing() || Recovery::guard() || Storage\State::guard()) return;
        $registry=Connections::registry_verified();
        if (is_wp_error($registry)) return;
        foreach (array_keys($registry) as $connection) {
            Connections::run($connection,static function() {
                if (!Options::is_enabled()) return;
                $state=Automation\Executor::status();
                self::publish('agenda_parada','executor',($state['health']??'unknown')==='degraded');
                foreach ([Ads\Archive::CONFIG,Integration\AdsServiceApi::GRANTS,Integration\Ga4ServiceApi::GRANTS,Integration\QueryServiceApi::GRANTS] as $option) {
                    foreach ((array)Options::get($option,[]) as $grant) {
                        if (is_array($grant) && !empty($grant['enabled'])) SiteAuthority::observe((int)($grant['granted_by']??0));
                    }
                }
                Auth\KeyStatus::observe();
            });
        }
        self::dispatch();
    }
}
