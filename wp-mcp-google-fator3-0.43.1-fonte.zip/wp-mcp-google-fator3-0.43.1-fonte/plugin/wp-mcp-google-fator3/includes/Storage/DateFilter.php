<?php
/**
 * Inclusive UTC/date-time windows shared by local history readers.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Storage;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class DateFilter {

	public static function parse( array $input, string $error_code = 'f3_google_dates' ): array|\WP_Error {
		$filters = array();
		$bounds  = array();
		foreach ( array( 'from', 'to' ) as $key ) {
			if ( ! isset( $input[ $key ] ) ) {
				continue;
			}
			$text     = (string) $input[ $key ];
			$day_only = preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $text );
			if ( $day_only ) {
				$text .= 'to' === $key ? 'T23:59:59Z' : 'T00:00:00Z';
			}
			if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-](?:0\d|1[0-4]):[0-5]\d)$/D', $text, $parts ) ) {
				return new \WP_Error( $error_code, 'Use uma data válida YYYY-MM-DD ou RFC3339 com fuso horário.' );
			}
			try {
				$date   = new \DateTimeImmutable( $parts[1] . $parts[3] );
				$errors = \DateTimeImmutable::getLastErrors();
				if ( false !== $errors && ( $errors['warning_count'] || $errors['error_count'] ) ) {
					throw new \InvalidArgumentException();
				}
			} catch ( \Throwable $error ) {
				return new \WP_Error( $error_code, 'Datas inválidas.' );
			}
			$second         = $date->getTimestamp();
			$fraction       = rtrim( $parts[2], '0' );
			$bounds[ $key ] = array( $second, $fraction );
			if ( 'from' === $key ) {
				// The repository compares created_at > created_after, at whole-second resolution.
				$filters['created_after'] = '' === $fraction ? $second - 1 : $second;
			} else {
				$filters['created_before'] = $second;
				$end_of_day                = (bool) $day_only;
			}
		}
		if ( isset( $bounds['from'], $bounds['to'] ) ) {
			list( $start, $start_fraction ) = $bounds['from'];
			list( $end, $end_fraction )     = $bounds['to'];
			// Compare the original instants. A valid interval can contain no stored second.
			if ( $start > $end || ( $start === $end && ! $end_of_day && strcmp( $start_fraction, $end_fraction ) > 0 ) ) {
				return new \WP_Error( $error_code, 'O início não pode ser posterior ao fim.' );
			}
		}
		return $filters;
	}
}
