<?php
/**
 * Accessible operational forms backed by the same services exposed to agents.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{
    Ability, Admin, Analytics\Profile, Audit, Automation\Alerts, Automation\Executor, Automation\Operations, Cache, Catalog, Confirmation, Connections, Crypto, Gate, Lock, Options, Policy, Response, Settings, Template, Updater
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class OperationsScreen {
    private const PAGE_SIZE = 20;
    private const JOB_STATES = [
        'approval_required'=>'Aguardando aprovação', 'pending'=>'Pendente', 'running'=>'Em execução',
        'blocked'=>'Bloqueado', 'unknown'=>'Resultado incerto', 'failed'=>'Falhou', 'completed'=>'Concluído',
        'cancelled'=>'Cancelado', 'reconciled'=>'Reconciliado',
    ];
    private static function query_text(string $key): string {
        $value = $_GET[$key] ?? '';
        return is_string($value) ? substr(sanitize_text_field(wp_unslash($value)), 0, 180) : '';
    }
    private static function page_controls(string $section, array $filters, int $offset, int $total, int $count, string $offset_key = 'offset', string $label = 'Paginação'): void {
        $range = $count ? ($offset + 1).'–'.($offset + $count).' de '.$total : '0 de '.$total;
        echo '<nav class="f3-list-tools" aria-label="'.esc_attr($label).'"><span class="f3-list-total">'.esc_html($range).'</span>';
        foreach (['Anterior' => $offset - self::PAGE_SIZE, 'Próxima' => $offset + self::PAGE_SIZE] as $label => $start) {
            if (($label === 'Anterior' && $offset > 0) || ($label === 'Próxima' && $start < $total)) {
                $url = add_query_arg([$offset_key => max(0, $start)] + $filters, Admin::url('', $section));
                echo '<a class="button" href="'.esc_url($url).'">'.esc_html($label).'</a>';
            } else {
                echo '<button type="button" class="button" disabled>'.esc_html($label).'</button>';
            }
        }
        echo '</nav>';
    }
    /** Read indexed metadata only. Audit is site-wide; schedules belong to the connection. */
    public static function metadata_list(bool $audit): void {
        $kind = $audit ? 'audit' : 'schedule';
        $section = $audit ? 'advanced' : 'operations';
        $panel = $audit ? 'limits' : 'operations';
        $label = $audit ? 'Buscar por ação, alvo ou conexão' : 'Buscar por tarefa ou ID da agenda';
        $term = self::query_text($kind.'_search');
        $offset = absint(self::query_text($kind.'_offset'));
        $filters = ['admin_search'=>$term];
        if (!$audit) $filters['connection_id'] = Connections::id();
        $total = \Fator3\McpGoogle\Storage\Repository::count_filtered($kind, $filters);
        $rows = \Fator3\McpGoogle\Storage\Repository::select($kind, $filters, self::PAGE_SIZE, $offset);
        if (is_wp_error($total) || is_wp_error($rows)) {
            echo '<p role="alert">Falha ao consultar os registros. Atualize a página para tentar novamente.</p>';
            return;
        }
        echo '<form method="get" class="f3-list-tools">';
        self::hidden('page', Admin::SLUG); self::hidden('section', 'advanced');
        self::hidden('advanced_panel', $panel); self::hidden('connection_id', Connections::id());
        echo '<label>'.esc_html($label).'<input type="search" name="'.esc_attr($kind.'_search').'" value="'.esc_attr($term).'"></label><button class="button">Buscar</button></form>';
        echo '<div class="f3-table-scroll" tabindex="0" role="region" aria-label="'.($audit?'Auditoria':'Agendas').'"><table data-server-page class="widefat striped"><thead><tr>';
        foreach ($audit ? ['Quando','Ação','Alvo'] : ['Tarefa','Estado','Ação'] as $title) echo '<th>'.esc_html($title).'</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $row) {
            if ($audit) {
                echo '<tr><td>'.esc_html(wp_date('d/m/Y H:i:s',(int)$row['created_at'])).'</td><td>'.esc_html($row['task']).'</td><td>'.esc_html($row['target']).'</td></tr>';
            } else {
                $active = $row['state'] === 'enabled';
                echo '<tr><td>'.esc_html($row['task']).'<br><code>'.esc_html($row['record_id']).'</code></td><td>'.OverviewScreen::badge($active?'success':'neutral', $active?'Ativa':'Pausada').'</td><td>';
                self::form('get-schedule'); self::hidden('schedule_id', $row['record_id']); self::button('Consultar, editar ou pausar');
                echo '</td></tr>';
            }
        }
        if (!$rows) echo '<tr><td colspan="3">Nenhum registro encontrado.</td></tr>';
        echo '</tbody></table></div>';
        self::page_controls($section, [$kind.'_search'=>$term,'advanced_panel'=>$panel], $offset, $total, count($rows), $kind.'_offset', $audit?'Paginação da auditoria':'Paginação das agendas');
    }
    private const ACTION = 'f3_google_operation';
    private static ?string $revision = null;
    private static int $field_number = 0;
    public static function init(): void {
        add_action( 'admin_post_' . self::ACTION, array( self::class, 'handle' ) );
    }
    private static function key( string $reference ): string {
        return Admin::feedback_key( 'operation_' . $reference );
    }
    private static function state( string $reference ): array {
        if ( 1 !== preg_match( '/^[a-f0-9]{32}$/D', $reference ) ) {
            return array();
        }
        $cipher = Cache::get( self::key( $reference ) );
        if ( ! is_string( $cipher ) ) {
            return array();
        }
        $plain = Crypto::decrypt( $cipher );
        $state = is_string( $plain ) ? json_decode( $plain, true ) : null;
        return is_array( $state ) && ( $state['reference'] ?? '' ) === $reference ? $state : array();
    }
    /** Mutating continuations claim a preview once. Audit pages remain available for another download. */
    private static function continuation( string $operation, string $reference ): array {
        $read_only = in_array( $operation, array( 'audit-next', 'download-audit' ), true );
        $lease = null;
        if ( ! $read_only && preg_match( '/^[a-f0-9]{32}$/D', $reference ) ) {
            $lease = Lock::acquire( self::key( $reference ) );
            if ( ! $lease ) {
                throw new \RuntimeException( 'Não foi possível reservar esta prévia. Consulte o resultado antes de repetir a ação.' );
            }
        }
        try {
            $prior = self::state( $reference );
            $allowed = match ( $operation ) {
                'apply-cleanup'    => ! empty( $prior['apply_cleanup'] ),
                'apply-export-rule'=>!empty($prior['apply_export_rule']),
                'apply-key-monitoring'=>!empty($prior['apply_key_monitoring']),
                'apply-policy'     => ! empty( $prior['apply_policy'] ),
                'approve-job'      => ! empty( $prior['approve_job'] ),
                'confirm'          => ! empty( $prior['confirm'] ),
                'apply-template'   => ! empty( $prior['apply_template'] ),
                'prepare-profile'  => ! empty( $prior['prepare_profile'] ),
                'download-audit'   => ! empty( $prior['audit_export'] ) && isset( $prior['result']['content_base64'], $prior['result']['filename'] ),
                'audit-next'       => ! empty( $prior['audit_export'] ) && ! empty( $prior['result']['next_cursor'] ),
                default            => false,
            };
            if ( ! $allowed || empty( $prior['result']['success'] ) ) {
                throw new \InvalidArgumentException( 'Esta ação exige a prévia correspondente. Refaça a consulta nesta conexão.' );
            }
            if ( ! $read_only && ! Cache::delete( self::key( $reference ) ) ) {
                throw new \RuntimeException( 'Não foi possível consumir a prévia. Consulte o resultado antes de repetir a ação.' );
            }
            return $prior;
        } finally {
            if ( $lease ) {
                Lock::release( $lease );
            }
        }
    }
    private static function form( string $operation ): void {
        if ( null === self::$revision ) {
            $revision = Settings::revision();
            self::$revision = is_wp_error( $revision ) ? '' : $revision;
        }
        echo '<form class="f3-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        self::hidden( '_wpnonce', wp_create_nonce( self::ACTION ) );
        wp_referer_field();
        foreach ( array(
                'action' => self::ACTION,
                'operation' => $operation,
                'connection_id' => Connections::id(),
                'section' => Admin::section(),
                'expected_revision' => self::$revision,
            ) + Admin::panel_args(Admin::section()) as $name => $value ) {
            self::hidden( $name, $value );
        }
    }
    private static function hidden( string $name, string $value ): void {
        echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
    }
    private static function field( string $name, string $label, string $value, string $help, string $type = 'text' ): void {
        $id = 'f3-op-' . sanitize_key( $name ) . '-' . ( ++self::$field_number );
        echo '<div class="f3-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
        if ( 'textarea' === $type ) {
            echo '<textarea rows="5" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" aria-describedby="' . esc_attr( $id ) . '-help">' . esc_textarea( $value ) . '</textarea>';
        }
        else {
            echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" aria-describedby="' . esc_attr( $id ) . '-help">';
        }
        echo '<p class="description" id="' . esc_attr( $id ) . '-help">' . esc_html( $help ) . '</p></div>';
    }
    private static function check( string $name, string $label, bool $value, string $help ): void {
        echo '<p><label class="f3-check"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . '> ' . esc_html( $label ) . '</label><br><span class="description">' . esc_html( $help ) . '</span></p>';
    }
    private static function button( string $label ): void {
        echo '<p class="f3-actions"><button class="button button-primary">' . esc_html( $label ) . '</button></p></form>';
    }
    private static function json( string $label, array $data ): void {
        if (Admin::section()!=='advanced') return;
        $id = 'f3-operation-json-' . ( ++self::$field_number );
        echo '<details class="f3-collapsible"><summary>' . esc_html( $label ) . '</summary><button type="button" class="button" data-copy-target="' . esc_attr( $id ) . '">Copiar JSON</button><pre id="' . esc_attr( $id ) . '" tabindex="0">' . esc_html( wp_json_encode( Audit::redact( $data ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details>';
    }
    /** A readable result is available without expanding the technical JSON. */
    private static function job_details( array $job ): void {
        $status = (string) ( $job['status'] ?? '' );
        $labels = array(
            'approval_required' => 'Aguardando aprovação',
            'pending' => 'Pendente',
            'running' => 'Em execução',
            'dispatching' => 'Envio iniciado',
            'blocked' => 'Bloqueado',
            'unknown' => 'Resultado incerto',
            'failed' => 'Falhou',
            'completed' => 'Concluído',
            'cancelled' => 'Cancelado',
            'reconciled' => 'Reconciliado',
        );
        $label = $labels[ $status ] ?? $status;
        if ( 'completed' === $status && ( ! empty( $job['summary']['failed'] ) || false === ( $job['result']['checks_passed'] ?? true ) ) ) {
            $label = 'Concluído, com verificações reprovadas';
        }
        $done = (int) ( $job['summary']['processed'] ?? $job['cursor'] ?? 0 );
        $total = (int) ( $job['summary']['total'] ?? ( 'inspect-urls' === ( $job['task'] ?? '' ) ? count( $job['parameters']['urls'] ?? array() ) : 1 ) );
        echo '<h3>Tarefa ' . esc_html( (string) ( $job['id'] ?? '' ) ) . '</h3><p><strong>' . esc_html( $label ) . '</strong> · ' . esc_html( (string) ( $job['task'] ?? '' ) ) . '</p>';
        if ( $total > 0 ) {
            echo '<p>Progresso: ' . esc_html( (string) $done ) . ' de ' . esc_html( (string) $total ) . ' itens.</p><progress aria-label="Progresso da tarefa" max="' . esc_attr( (string) $total ) . '" value="' . esc_attr( (string) min( $done, $total ) ) . '"></progress>';
        }
        if ( isset( $job['summary']['passed'], $job['summary']['failed'] ) ) {
            echo '<p>Consultas aprovadas: ' . esc_html( (string) $job['summary']['passed'] ) . ' · Reprovadas: ' . esc_html( (string) $job['summary']['failed'] ) . '.</p>';
        }
        foreach ( array(
                'updated_at' => 'Última atualização',
                'run_after' => 'Próxima execução elegível',
            ) as $key => $title ) {
            if ( ! empty( $job[ $key ] ) ) {
                echo '<p>' . esc_html( $title ) . ': ' . esc_html( wp_date( 'Y-m-d H:i:s T', (int) $job[ $key ] ) ) . '.</p>';
            }
        }
        $targets = array();
        $walk = static function ( array $parameters ) use ( &$targets, &$walk ): void {
            foreach ( $parameters as $key => $value ) {
                if ( in_array( $key, array( 'property_id', 'customer_id', 'site_url', 'sitemap_url', 'spreadsheet_id', 'stream_id', 'accounts' ), true ) ) {
                    foreach ( (array) $value as $target ) {
                        if ( is_scalar( $target ) ) {
                            $targets[] = (string) $target;
                        }
                    }
                }
                elseif ( is_array( $value ) && ! in_array( $key, array( 'rows', 'urls' ), true ) ) {
                    $walk( $value );
                }
            }
        };
        $walk( $job['parameters'] ?? array() );
        if ( $targets ) {
            echo '<p>Destinos fixados: ' . esc_html( implode( ' · ', array_slice( array_unique( $targets ), 0, 20 ) ) ) . '.</p>';
        }
        if ( ! empty( $job['blocked_reason'] ) ) {
            echo '<p>Motivo do bloqueio: <code>' . esc_html( $job['blocked_reason'] ) . '</code>. Confira a identidade, as permissões e os destinos antes de criar uma nova intenção.</p>';
        }
        if ( 'unknown' === $status ) {
            echo '<p>Confira o destino no Google e registre a reconciliação. Uma execução incerta não é repetida automaticamente.</p>';
        }
        if ( ! empty( $job['result']['message'] ) ) {
            echo '<p>' . esc_html( $job['result']['message'] ) . '</p>';
        }
    }
    public static function render(bool $feedbackOnly=false): void {
        self::$revision = null;
        self::$field_number = 0;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only reference; state() validates its format and scopes it to the current user and connection.
        $reference = isset( $_GET['operation_ref'] ) && is_string( $_GET['operation_ref'] ) ? sanitize_text_field( wp_unslash( $_GET['operation_ref'] ) ) : '';
        $state = self::state( $reference );
        if ( isset( $_GET['operation_ref'] ) && empty( $state ) ) {
            echo '<div class="notice notice-info" role="status"><p>Resultado indisponível. A prévia vale por dez minutos e só pode ser confirmada uma vez. Refaça a consulta nesta conexão.</p></div>';
        }
        if ( isset( $state['result'] ) ) {
            $result = $state['result'];
            echo '<section class="f3-section" role="status"><h2>Resultado da ação</h2><p class="f3-lead">' . esc_html( $result['message'] ?? '' ) . '</p>';
            if ( empty( $result['success'] ) ) {
                echo '<p><strong>' . esc_html( $result['error_code'] ?? 'Falha' ) . '</strong></p>';
            }
            if ( isset( $result['job_id'] ) ) {
                echo '<p>Tarefa: <code>' . esc_html( $result['job_id'] ) . '</code> · ' . esc_html( $result['status'] ?? '' ) . '</p>';
            }
            if ( isset( $result['job'] ) && is_array( $result['job'] ) ) {
                self::job_details( $result['job'] );
            }
            if ( ! empty( $state['confirm'] ) ) {
                echo '<p>Confira os alvos e os efeitos previstos antes de confirmar. A confirmação vale para esta intenção e expira em dez minutos.</p>';
                self::json( 'Ver os efeitos e os parâmetros preparados', $result );
                self::form( 'confirm' );
                self::hidden( 'reference', $state['reference'] );
                self::button( 'Confirmar esta operação' );
            }
            elseif ( ! empty( $state['approve_job'] ) ) {
                echo '<p>A aprovação vale apenas para esta tarefa e para os destinos preparados. O executor conferirá novamente o acesso e o estado remoto.</p>';
                self::json( 'Conferir efeitos da exportação', $result );
                self::form( 'approve-job' );
                self::hidden( 'reference', $state['reference'] );
                self::button( 'Aprovar esta tarefa' );
            }
            elseif ( ! empty( $state['apply_cleanup'] ) ) {
                echo '<p>A limpeza revalida os candidatos e remove até 100 registros por passagem. Tarefas ativas e resultados incertos são preservados.</p>';
                self::json( 'Conferir candidatos à limpeza', $result );
                self::form( 'apply-cleanup' );
                self::hidden( 'reference', $state['reference'] );
                self::button( 'Executar limpeza vencida' );
            }
            elseif ( ! empty( $state['edit_schedule'] ) ) {
                self::schedule_form( $result['schedule'] );
            }
            elseif (!empty($state['apply_export_rule']) || !empty($state['apply_key_monitoring'])) {
                if (!empty($state['apply_key_monitoring'])) {
                    echo '<p>O aviso será emitido quando faltarem ' . esc_html((string)$result['configuration']['warning_days']) . ' dias para o vencimento da chave ativa. O destino é o aviso técnico configurado no Site Core.</p>';
                } else {
                    echo '<p>' . (!empty($result['rule']['enabled']) ? 'Habilitar' : 'Desabilitar') . ' a aprovação automática dos parâmetros desta exportação. Confira a consulta e o destino abaixo.</p>';
                }
                self::json('Conferir configuração e efeitos',$result);
                self::form(!empty($state['apply_export_rule'])?'apply-export-rule':'apply-key-monitoring');
                self::hidden('reference',$state['reference']);self::button('Aplicar esta configuração');
            }
            elseif ( ! empty( $state['apply_policy'] ) ) {
                echo '<p>Contextos a revisar: ' . esc_html( (string) $result['contexts_invalidated']['jobs'] ) . ' tarefas e ' . esc_html( (string) $result['contexts_invalidated']['schedules'] ) . ' agendas. Padrões fora do novo alcance: ' . esc_html( (string) count( $result['defaults_outside_policy'] ) ) . '.</p>';
                self::json( 'Conferir política e impacto', $result );
                self::form( 'apply-policy' );
                self::hidden( 'reference', $state['reference'] );
                self::button( 'Aplicar esta política' );
            }
            elseif ( ! empty( $state['audit_export'] ) && isset( $result['content_base64'], $result['filename'] ) ) {
                echo '<p>Arquivo desta página: ' . esc_html( $result['filename'] ) . ' · ' . esc_html( (string) $result['bytes'] ) . ' bytes.</p>';
                self::form( 'download-audit' );
                self::hidden( 'reference', $state['reference'] );
                self::button( 'Baixar arquivo autenticado' );
                if ( ! empty( $result['next_cursor'] ) ) {
                    self::form( 'audit-next' );
                    self::hidden( 'reference', $state['reference'] );
                    self::button( 'Preparar próxima página' );
                }
                self::json( 'Ver cobertura da exportação', array_diff_key( $result, array( 'content_base64' => true ) ) );
            }
            elseif ( ! empty( $state['apply_template'] ) ) {
                self::json( 'Ver diferenças do modelo', $result );
                self::form( 'apply-template' );
                self::hidden( 'reference', $state['reference'] );
                self::button( 'Aplicar estas diferenças' );
            }
            elseif ( ! empty( $state['prepare_profile'] ) ) {
                self::json( 'Ver diferenças do perfil', $result );
                self::form( 'prepare-profile' );
                self::hidden( 'reference', $state['reference'] );
                self::button( 'Preparar aplicação deste perfil' );
            }
            else {
                self::json( 'Ver resultado técnico', $result );
            }
            echo '</section>';
        }
        if ($feedbackOnly) return;
        if ( 'profiles' === Admin::section() ) {
            self::profiles();
            return;
        }
        if ( 'controls' === Admin::section() ) {
            self::controls();
            return;
        }
        self::operations();
    }
    private static function operations(): void {
        $integration = \Fator3\McpGoogle\Integration\ServiceApi::status();
        echo '<section class="f3-section"><h2>Integração com plugins</h2><p class="f3-lead">Autorize a leitura Search Console para um consumidor registrado. A propriedade, agenda e persistência das métricas são configuradas pelo plugin consumidor. A conta Google e sua política continuam nesta conexão.</p>';
        if ( ! $integration['consumers'] ) {
            echo '<p>Nenhum consumidor compatível registrado. O plugin consumidor precisa registrar-se pelo contrato search-console-reader/1.0.0.</p>';
        }
        foreach ( $integration['consumers'] as $consumer ) {
            echo '<h3>' . esc_html( $consumer['id'] ) . '</h3><p>Propriedade informada pelo consumidor: <strong>' . esc_html( $consumer['configuration']['property'] ?? 'Ainda não configurada' ) . '</strong>. Prontidão: ' . esc_html( ! empty( $consumer['configuration']['ready'] ) ? 'Pronto' : 'Pendente' ) . '.</p>';
            if ( ! empty( $consumer['configuration']['error_code'] ) ) {
                echo '<p>Configuração pendente: <code>' . esc_html( $consumer['configuration']['error_code'] ) . '</code>.</p>';
            }
            $effective = $consumer['effective_status'];
            $resolution_labels = array(
                'resolved' => 'Concessão única localizada',
                'not_granted' => 'Sem concessão ativa',
                'ambiguous' => 'Concessões conflitantes',
                'unreadable' => 'Não foi possível verificar as concessões',
            );
            echo '<p>Conexão selecionada: <strong>' . esc_html( $integration['connection_id'] ) . '</strong>. Conexão efetiva: <strong>' . esc_html( $effective['connection_id'] ?? 'Não determinada' ) . '</strong>. ' . esc_html( $resolution_labels[ $effective['resolution'] ] ?? 'Diagnóstico indisponível' ) . '. A configuração pronta é declarada pelo consumidor; acesso remoto e gravação das métricas dependem da execução.</p>';
            $last = $effective['local_status']['last_service'] ?? null;
            if ( ! empty( $effective['local_status']['last_service_error'] ) ) {
                echo '<p>Último atendimento ilegível: <code>' . esc_html( $effective['local_status']['last_service_error'] ) . '</code>.</p>';
            }
            echo '<p>Último atendimento: ' . esc_html( $last ? wp_date( 'Y-m-d H:i:s T', (int) $last['at'] ) . ' · ' . ( $last['success'] ? 'consulta concluída' : 'falhou: ' . ( $last['error_code'] ?? 'resultado não confirmado' ) ) . ' · ' . (int) ( $last['rows'] ?? 0 ) . ' linhas' : 'Ainda não observado' ) . '. A persistência das métricas é confirmada pelo consumidor.</p>';
            self::form( 'save-consumer' );
            self::hidden( 'consumer_id', $consumer['id'] );
            self::check( 'consumer_enabled', 'Autorizar leitura nesta conexão', ! empty( $consumer['grant']['enabled'] ), 'Permite somente Search Analytics por página e dia. Não concede escrita nem copia a credencial para o outro plugin. Revogue aqui antes de transferir a outra conexão.' );
            self::button( 'Salvar autorização' );
        }
        self::json( 'Ver contrato e atendimento', $integration );
        echo '</section>';
        $cron = Executor::status();
        echo '<section class="f3-section"><h2>Execução das tarefas</h2><p class="f3-lead">Executor observado: <strong>' . esc_html( $cron['executor'] ) . '</strong>. ' . esc_html( $cron['cron_servidor_ativo'] ? 'Passagem CLI observada nas últimas 2 horas.' : 'Nenhuma passagem CLI recente confirmada.' ) . '</p><p>Uma chamada manual no terminal também conta como CLI. O indicador não verifica o agendamento do servidor nem a aprovação dos trabalhos.</p>';
        foreach ( array(
                'ultima_cli' => 'Última CLI',
                'ultima_http' => 'Último cron HTTP',
                'ultima_manual' => 'Última chamada manual',
            ) as $key => $label ) {
            $pass = $cron[ $key ];
            echo '<p><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( $pass ? wp_date( 'Y-m-d H:i:s T', $pass['at'] ) . ' · ' . ( ($pass['state']??'')==='yielded' ? 'Cedida a outra passagem' : ( true === $pass['success'] ? 'concluída' : ( false === $pass['success'] ? 'reprovada' : 'resultado não confirmado' ) ) ) . ' · ' . $pass['items'] . ' itens' : 'Não observada' ) . '</p>';
        }
        if (!empty($cron['history_pending'])) echo '<p><strong>Histórico pendente de confirmação.</strong> O trabalho já registrado será confirmado localmente, sem novo despacho.</p>';
        if (!empty($cron['observability_error'])) echo '<p><strong>Falha atual:</strong> <code>'.esc_html($cron['observability_error']['code']??'diagnóstico indisponível').'</code>.</p>';
        elseif (!empty($cron['last_observability_error']['resolved_at'])) echo '<p><strong>Última falha — resolvida:</strong> '.esc_html(wp_date('Y-m-d H:i:s T',$cron['last_observability_error']['resolved_at'])).'.</p>';
        echo '<h3>Agenda WordPress</h3><p>A confirmação da agenda verifica eventos persistidos. O processamento das tarefas aparece no histórico acima.</p>';
        $current=$cron['scheduling']['checks']['executor']??[];
        $labels=['present'=>'Presente e válido','missing'=>'Ausente','invalid'=>'Estrutura inválida ou múltiplas ocorrências','inactive'=>'Desativado explicitamente','unknown'=>'Leitura não confirmada'];
        echo '<p><strong>Evento executor atual: '.esc_html($labels[$current['state']??'unknown']).'.</strong> A consulta não repara a agenda.</p>';
        if(!empty($current['next_run'])) echo '<p>Próxima ocorrência: '.esc_html(wp_date('Y-m-d H:i:s T',$current['next_run'])).'.</p>';
        if(!empty($current['repair_blocked_by'])) echo '<p>Reparação bloqueada: <code>'.esc_html($current['repair_blocked_by']).'</code>.</p>';
        elseif(($current['state']??'')==='missing') echo '<p>Uma passagem admitida de manutenção, CLI ou execução manual poderá repor o evento. A execução manual também pode processar tarefas vencidas.</p>';
        echo '<h4>Histórico das operações de agenda</h4><p>Uma confirmação anterior não comprova a presença atual do evento.</p>';
        if (empty($cron['scheduling']['read_success'])) echo '<p>Agenda não confirmada: diagnóstico indisponível.</p>';
        if (!empty($cron['scheduling']['active_errors'])) echo '<p><strong>'.esc_html((string)count($cron['scheduling']['active_errors'])).' falha(s) de agenda ainda ativa(s).</strong> Consulte as intenções afetadas no diagnóstico.</p>';
        if (!empty($cron['scheduling']['untracked_errors'])) echo '<p>Cobertura incompleta: o limite de detalhes de incidentes foi atingido.</p>';
        if (isset($cron['scheduling']['last_diagnostic_write']['diagnostic_persisted']) && !$cron['scheduling']['last_diagnostic_write']['diagnostic_persisted']) echo '<p>O último diagnóstico de agenda não teve gravação confirmada.</p>';
        foreach ($cron['scheduling']['observations']??[] as $observation) {
            $label=$observation['state']==='confirmed'?(!empty($observation['original_code'])?'Operação confirmada com aviso do WordPress':'Operação confirmada'):($observation['state']==='failed'?'Falha de agenda':'Agenda não confirmada');
            echo '<p><strong>'.esc_html($label).'</strong> · <code>'.esc_html($observation['hook']).'</code> · '.esc_html($observation['operation'].' / '.$observation['origem'].' · '.wp_date('Y-m-d H:i:s T',$observation['at'])).'</p>';
        }
        self::json( 'Ver diagnóstico do executor', $cron );
        echo '</section>';
        $recovery = \Fator3\McpGoogle\Recovery::status();
        echo '<section class="f3-section"><h2>Restauração e recuperação</h2><p class="f3-lead">Prepare a pausa antes de restaurar o banco. Ela permanece fora do snapshot. Depois, confira conexões, credenciais e efeitos remotos dos trabalhos antes de retomar. Trabalhos restaurados exigem revisão de contexto.</p>';
        self::form( 'recovery' );
        self::hidden( 'recovery_action', ! empty( $recovery['paused'] ) ? 'resume' : 'prepare' );
        self::hidden( 'recovery_generation', $recovery['generation'] ?? '' );
        if ( ! empty( $recovery['paused'] ) ) {
            self::check( 'acknowledge_reconciled', 'Conferi o snapshot e reconciliei os efeitos remotos', false, 'A restauração do banco não desfaz alterações no Google. Confira a auditoria e os recursos afetados antes de retomar.' );
        }
        self::button( ! empty( $recovery['paused'] ) ? 'Retomar após reconciliação' : 'Preparar pausa para restore' );
        if ( ! empty( $recovery['paused'] ) && empty( $recovery['drained'] ) ) {
            self::form( 'recovery' );
            self::hidden( 'recovery_action', 'prepare' );
            self::button( 'Conferir drenagem' );
        }
        self::json( 'Ver estado de recuperação', $recovery );
        echo '</section>';
        echo '<section class="f3-section"><h2>Tarefas e agendas</h2><p class="f3-lead">Uma execução concluída pode conter verificações reprovadas. Consulte o resultado antes de tomar uma ação. Cancelar interrompe etapas futuras e preserva as já concluídas.</p>';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
        $status = isset( $_GET['job_status'] ) ? sanitize_key( wp_unslash( $_GET['job_status'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
        $task = isset( $_GET['job_task'] ) ? sanitize_key( wp_unslash( $_GET['job_task'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
        $from = isset( $_GET['job_from'] ) && is_string( $_GET['job_from'] ) ? sanitize_text_field( wp_unslash( $_GET['job_from'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
        $to = isset( $_GET['job_to'] ) && is_string( $_GET['job_to'] ) ? sanitize_text_field( wp_unslash( $_GET['job_to'] ) ) : '';
        echo '<form class="f3-list-tools" method="get" action="' . esc_url( admin_url( 'tools.php' ) ) . '">';
        foreach ( array(
                'page' => Admin::SLUG,
                'section' => 'operations',
                'connection_id' => Connections::id(),
            ) as $key => $value ) {
            self::hidden( $key, $value );
        }
        $search = self::query_text('job_search');
        echo '<div class="f3-field"><label for="f3-job-search">Buscar por tarefa ou ID</label><input type="search" id="f3-job-search" name="job_search" value="'.esc_attr($search).'"></div>';
        echo '<div class="f3-field"><label for="f3-job-filter">Estado</label> <select id="f3-job-filter" name="job_status">';
        foreach ( ['' => 'Todos'] + self::JOB_STATES as $key => $label ) {
            echo '<option value="' . esc_attr( $key ) . '" ' . selected( $status, $key, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select></div><div class="f3-field"><label for="f3-task-filter">Tarefa</label> <select id="f3-task-filter" name="job_task"><option value="">Todas</option>';
        foreach ( \Fator3\McpGoogle\Automation\Jobs::TASKS as $name ) {
            echo '<option value="' . esc_attr( $name ) . '" ' . selected( $task, $name, false ) . '>' . esc_html( $name ) . '</option>';
        }
        echo '</select></div><div class="f3-field"><label for="f3-job-from">Criada desde (UTC)</label> <input type="date" id="f3-job-from" name="job_from" value="' . esc_attr( $from ) . '"> </div><div class="f3-field"><label for="f3-job-to">Até (UTC)</label> <input type="date" id="f3-job-to" name="job_to" value="' . esc_attr( $to ) . '"> </div><button class="button">Filtrar</button></form>';
        $input = $status ? array( 'status' => $status ) : array();
        foreach ( array(
                'task' => $task,
                'from' => $from,
                'to' => $to,
            ) as $key => $value ) {
            if ( '' !== $value ) {
                $input[ $key ] = $value;
            }
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
        $input['offset'] = isset( $_GET['offset'] ) ? absint( wp_unslash( $_GET['offset'] ) ) : 0;
        $input['limit'] = self::PAGE_SIZE;
        $page = Operations::listing( $input, $search );
        if ( empty( $page['success'] ) ) {
            echo '<p>' . esc_html( $page['message'] ) . '</p></section>';
            return;
        }
        echo '<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Tarefas"><table data-server-page class="widefat striped f3-job-table"><thead><tr><th>Tarefa</th><th>Estado</th><th>Próximo passo</th></tr></thead><tbody>';
        foreach ( $page['jobs'] as $job ) {
            echo '<tr><td data-label="Tarefa"><strong>' . esc_html( $job['task'] ) . '</strong><br><code>' . esc_html( $job['id'] ) . '</code></td><td data-label="Estado">' . OverviewScreen::badge(match ($job['status']) { 'failed'=>'error', 'blocked','unknown','approval_required'=>'attention', 'completed','reconciled'=>'success', default=>'neutral' }, self::JOB_STATES[$job['status']] ?? $job['status']) . '</td><td data-label="Próximo passo">';
            self::form( 'get-job' );
            self::hidden( 'job_id', $job['id'] );
            self::button( 'Consultar resultado' );
            if ( 'approval_required' === $job['status'] ) {
                self::form( 'prepare-job' );
                self::hidden( 'job_id', $job['id'] );
                self::button( 'Conferir exportação para aprovação' );
            }
            if ( 'pending' === $job['status'] ) {
                self::form( 'run-job' );
                self::hidden( 'job_id', $job['id'] );
                self::button( 'Executar próxima passagem' );
            }
            if ( in_array( $job['status'], array( 'pending', 'blocked', 'approval_required' ), true ) ) {
                self::form( 'cancel-job' );
                self::hidden( 'job_id', $job['id'] );
                self::button( 'Cancelar etapas pendentes' );
            }
            if ( 'unknown' === $job['status'] ) {
                echo '<p>Confira o destino no Google. Esta tarefa não será repetida automaticamente.</p><details><summary>Registrar reconciliação</summary>';
                self::form( 'reconcile-job' );
                self::hidden( 'job_id', $job['id'] );
                echo '<label>Estado conferido <select name="observed_outcome"><option value="applied">Aplicado</option><option value="not_applied">Não aplicado</option><option value="partial">Aplicado parcialmente</option></select></label>';
                self::field( 'evidence', 'Evidência da conferência', '', 'Descreva como conferiu o destino, sem credenciais. Entre 10 e 2.000 caracteres.', 'textarea' );
                self::button( 'Registrar sem repetir a escrita' );
                echo '</details>';
            }
            echo '</td></tr>';
        }
        if ( ! $page['jobs'] ) {
            echo '<tr><td colspan="3">Nenhuma tarefa neste filtro.</td></tr>';
        }
        echo '</tbody></table></div>';
        self::page_controls('operations', ['job_search'=>$search, 'job_status'=>$status, 'job_task'=>$task, 'job_from'=>$from, 'job_to'=>$to], $input['offset'], $page['total'], count($page['jobs']));
        echo '<h3>Agendas</h3>';
        self::metadata_list(false);
        echo '<details class="f3-collapsible"><summary>Criar agenda de leitura</summary>';
        self::schedule_form();
        echo '</details>';
        self::form( 'run-due' );
        self::button( 'Executar tarefas e agendas vencidas' );
        self::json( 'Ver estado do executor', Executor::status() );
        echo '</section>';
        echo '<section class="f3-section"><h2>Histórico e incidentes</h2>';
        self::json( 'Consultar incidentes', Alerts::state() );
        self::form( 'audit-export' );
        echo '<label>Formato <select name="format"><option value="json">JSON</option><option value="csv">CSV</option></select></label>';
        self::field( 'desde_revisao', 'Depois da revisão', '0', 'Hash de configuração, marcador event: ou cursor decimal exclusivo; até 100 eventos por página.' );
        self::button( 'Consultar página de exportação' );
        self::form( 'cleanup' );
        self::button( 'Conferir limpeza vencida' );
        echo '</section>';
    }
    private static function schedule_form( ?array $schedule = null ): void {
        self::form( 'save-schedule' );
        if ( null !== $schedule ) {
            self::hidden( 'schedule_id', $schedule['id'] );
            self::hidden( 'schedule_revision', $schedule['revision'] );
        }
        echo '<p><label>Tipo de tarefa <select name="task">';
        foreach ( array(
                'report' => 'Relatório por modelo',
                'query' => 'Consulta de métricas',
                'preflight' => 'Verificação de acesso',
            ) as $key => $label ) {
            echo '<option value="' . esc_attr( $key ) . '" ' . selected( $schedule['task'] ?? 'report', $key, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select></label></p>';
        self::field( 'interval_seconds', 'Intervalo em segundos', (string) ( $schedule['interval_seconds'] ?? 86400 ), 'De 3.600 (uma hora) a 2.592.000 (30 dias). A agenda precisa de WP-Cron ou de um disparador externo.', 'number' );
        self::check( 'schedule_enabled', 'Agenda ativa', (bool) ( $schedule['enabled'] ?? true ), 'Desmarque para pausar novas ocorrências; tarefas já criadas permanecem disponíveis.' );
        echo '<details class="f3-collapsible"><summary>Parâmetros da consulta</summary>';
        self::field( 'parameters_json', 'Parâmetros JSON', wp_json_encode( (object) ( $schedule['parameters'] ?? array( 'template' => 'traffic' ) ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ), 'Informe um objeto JSON. Para uma verificação com os valores padrão, use {}. Em relatórios, informe template e date_range. Em consultas, informe connector, accounts e metrics. A agenda recalcula os períodos relativos em cada execução.', 'textarea' );
        echo '</details>';
        self::button( null === $schedule ? 'Criar agenda' : 'Salvar esta revisão da agenda' );
    }
    public static function profiles(): void {
        $selectedId=sanitize_key(wp_unslash($_GET['profile']??''));
        $selectedProfile=$selectedId?\Fator3\McpGoogle\Records::get('profile',hash('sha256',Connections::id().'|'.$selectedId)):null;
        echo '<form method="get"><input type="hidden" name="page" value="'.esc_attr(Admin::SLUG).'"><input type="hidden" name="section" value="conversions"><input type="hidden" name="connection_id" value="'.esc_attr(Connections::id()).'"><label>Perfil para editar <select name="profile"><option value="">Novo perfil</option>';
        foreach(\Fator3\McpGoogle\Records::list('profile',100) as $profile) if(($profile['connection_id']??'')===Connections::id()) echo '<option value="'.esc_attr($profile['profile_id']).'" '.selected($selectedId,$profile['profile_id'],false).'>'.esc_html($profile['profile_id']).'</option>';
        echo '</select></label> <button class="button">Abrir perfil</button></form>';
        echo '<section class="f3-section"><h2>Perfis GA4</h2><p class="f3-lead">Um perfil descreve somente os valores que você quer administrar. Campos omitidos e definições extras permanecem como estão. A aplicação usa uma propriedade existente e começa pela retenção.</p>';
        self::form( 'plan-profile' );
        self::field( 'profile_id', 'Perfil salvo', '', 'Identificador do perfil configurável desta conexão.' );
        ResourceChoices::select('property_id','Propriedade Google Analytics',(string)Options::get(Options::GA_DEFAULT_PROPERTY,''),ResourceChoices::items('ga'));
        ResourceChoices::select('stream_id','Fluxo de dados',(string)(Options::get(Connections::BINDINGS,[])['ga_stream_id']??''),ResourceChoices::items('stream','properties/'.Options::get(Options::GA_DEFAULT_PROPERTY,'')));
        self::button( 'Comparar sem alterar o Google' );
        $profiles = wp_get_ability( 'ga/list-profiles' );
        if ( $profiles ) {
            self::json( 'Ver perfis salvos', \Fator3\McpGoogle\Gate::administrative( 'ga/list-profiles', static fn () => \Fator3\McpGoogle\Ability::execute_admin( 'ga/list-profiles', array( 'connection_id' => Connections::id() ) ) ) );
        }
        echo '<details class="f3-collapsible"><summary>Criar ou atualizar definição de perfil</summary><p>Seções disponíveis: retenção, medição otimizada, Google Signals, redação de dados, atribuição, dimensões e métricas personalizadas. O contrato abaixo explica campos, tipos e valores aceitos.</p>';
        self::form( 'save-profile' );
        self::field( 'profile_id', 'Identificador do perfil', $selectedId, 'Letras minúsculas, números, hífen ou sublinhado; comece por uma letra.' );
        self::hidden('profile_revision',$selectedProfile['revision']??'');
        if (Admin::section()==='advanced') {        self::field( 'profile_json', 'Definição JSON', '{"schema_version":"1.0.0","custom_dimensions":[]}', 'Informe somente as seções desejadas. Nenhum padrão de agência é presumido.', 'textarea' );} else {self::hidden('profile_structured','1');ProfileForm::render(Profile::schema(),$selectedProfile['profile']??[]);}
        self::button( 'Salvar definição local' );
        self::json( 'Consultar schema do perfil', Profile::schema() );
        echo '</details></section>';
    }
    public static function permissions(): void {
        $policy = Policy::current();
        echo '<section class="f3-section"><h2>Permissões por recurso</h2><p class="f3-lead">Recursos padrão ajudam a selecionar o destino; a política determina quais destinos podem ser usados. Novas conexões começam restritas. Uma instalação anterior mantém o acesso da identidade até você definir restrições.</p>';
        self::form( 'save-policy' );
        echo '<label>Alcance <select name="policy_mode">';
        foreach ( array(
                'restricted' => 'Somente recursos autorizados',
                'identity' => 'Recursos acessíveis à identidade Google',
            ) as $key => $label ) {
            echo '<option value="' . esc_attr( $key ) . '" ' . selected( $policy['mode'] ?? 'identity', $key, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select></label>';
        foreach ( array(
                'gtm' => 'Tag Manager',
                'ga' => 'Analytics',
                'ads' => 'Google Ads',
                'gsc' => 'Search Console',
                'sheets' => 'Sheets',
                'drive' => 'Drive',
                'siteverification' => 'Verificação de sites',
            ) as $key => $label ) {
            $rule = $policy['services'][ $key ] ?? array();
            echo '<details class="f3-collapsible"><summary>' . esc_html( $label ) . '</summary>';
            self::boxes($key.'_resources','Recursos autorizados',$rule['resources']??[],self::resource_boxes($key,$rule['resources']??[]));
            self::boxes($key.'_operations','Operações permitidas',$rule['operations']??[],self::operation_boxes($key));
            self::check( $key . '_create', 'Permitir criação sob um contexto autorizado', ! empty( $rule['allow_create'] ), 'Não concede acesso a outros pais ou destinos.' );
            self::field( $key . '_recipients', 'Destinatários de compartilhamento', implode( "\n", $rule['recipients'] ?? array() ), 'Um e-mail por linha. Permissões exigem preparação e confirmação adicionais.', 'textarea' );
            echo '</details>';
        }
        self::button( 'Conferir impacto antes de salvar' );
        self::form( 'discover-policy' );
        self::button( 'Consultar recursos disponíveis para definir a política' );
        echo '</section>';
    }
    private static function alert_preferences(): void {
        echo '<section class="f3-section"><h2>Avisos técnicos</h2><p class="f3-lead">Incidentes, recuperações, falhas de agenda e vencimento de chave são encaminhados ao destino técnico do Site Core. A fila local conserva os avisos enquanto o Core estiver indisponível.</p><p><a href="'.esc_url(is_callable(['F3Base_Configuracoes_Hub','url'])?\F3Base_Configuracoes_Hub::url('conexoes','f3base_avisos_tecnicos'):admin_url('plugins.php')).'">Configurar destino técnico no Site Core</a></p><p>O registro permanece pendente se o destino técnico não estiver definido. A aceitação do transporte não comprova recebimento na caixa postal.</p></section>';
        echo '<section class="f3-section"><h2>Incidentes de acesso da agenda</h2>';
        self::form( 'access-recheck' );
        self::field( 'access_recheck_hours', 'Reverificar acesso a cada quantas horas?', (string) Alerts::config()['access_recheck_hours'], 'De 1 a 168 horas. A recusa de leitura da chave IAM tem revisão horária própria.', 'number' );
        echo '<p class="f3-actions"><button class="button" name="intent" value="preview">Simular intervalo</button> <button class="button button-primary" name="intent" value="save">Salvar intervalo</button></p></form></section>';
    }
    public static function key_monitoring(): void {
        $key=\Fator3\McpGoogle\Auth\KeyStatus::status();
        $label=!$key['known']?'Desconhecido':($key['expires_at']===null?'Sem prazo finito informado pelo Google':wp_date('d/m/Y H:i T',$key['expires_at']));
        echo '<section class="f3-section"><h2>Validade da chave ativa</h2><p class="f3-lead">'.esc_html($label).'</p><p>A consulta requer a API IAM habilitada e a permissão iam.serviceAccountKeys.get para a conta. O aviso antecipado usa o destino técnico do Core.</p>';
        if ($key['action'] !== null) echo '<p role="status">'.esc_html($key['action']).'</p>';
        if ($key['disabled'] === true) echo '<p>O IAM informou que a chave está desativada.</p>';
        if ($key['stale']) echo '<p>Metadados pendentes de atualização. Consulte a chave para confirmar o estado atual.</p>';
        self::form('refresh-key');self::button('Consultar validade no Google');
        self::form('plan-key-monitoring');
        self::field('warning_days','Avisar com antecedência de dias',(string)$key['warning_days'],'Entre 1 e 365 dias.','number');
        self::button('Conferir antecedência');
        echo '</section>';
    }
    public static function controls(): void {
        echo '<section class="f3-section"><h2>Modelos de configuração</h2><p class="f3-lead">Modelos transportam serviços, vínculos, limites e política. Credenciais e destinatários não são exportados. Os recursos são parametrizados para você mapear na instalação de destino.</p>';
        self::form( 'export-template' );
        self::button( 'Gerar modelo sem segredos' );
        echo '<details class="f3-collapsible"><summary>Importar modelo e mapear recursos</summary>';
        self::form( 'plan-template' );
        self::field( 'template_json', 'Modelo JSON', '', 'Use o objeto template exportado.', 'textarea' );
        self::field( 'mapping_json', 'Mapa de recursos', '{}', 'Objeto com os parâmetros declarados no modelo e os IDs de destino.', 'textarea' );
        self::button( 'Ver diferenças antes de aplicar' );
        echo '</details></section>';
        self::maintenance();
        $origin = Options::get( Updater::OPTION, array() );
        echo '<section class="f3-section"><h2>Distribuição e manutenção</h2>';
        self::form( 'save-updates' );
        self::check( 'updates_enabled', 'Consultar atualizações nesta origem', ! empty( $origin['enabled'] ), 'O manifesto deve vir de um distribuidor em quem você confia. Esta opção não ativa atualizações automáticas.' );
        self::field( 'manifest_url', 'URL HTTPS do manifesto', (string) ( $origin['manifest_url'] ?? '' ), 'O manifesto informa versão, requisitos, URL e hash do pacote.' );
        self::field( 'allowed_hosts', 'Hosts de distribuição', implode( "\n", $origin['allowed_hosts'] ?? array() ), 'Até cinco hosts exatos, um por linha; os redirecionamentos e o pacote devem permanecer nessa lista.', 'textarea' );
        self::button( 'Salvar origem' );
        self::form( 'save-local' );
        self::check( 'audit_local_reads', 'Auditar consultas locais bem-sucedidas', (bool) Options::get( Options::AUDIT_LOCAL_READS, false ), 'Falhas, recusas e alterações continuam auditadas independentemente desta opção.' );
        self::check( 'purge_on_uninstall', 'Excluir também configurações públicas e histórico ao desinstalar', (bool) Options::get( 'f3_mcp_google_purge_on_uninstall', false ), 'Credenciais são sempre removidas. O padrão preserva configurações públicas e histórico para recuperação.' );
        self::button( 'Salvar manutenção' );
        echo '</section>';
        echo '<section class="f3-section"><h2>Aprovação de exportações pelo site</h2><p class="f3-lead">Uma regra permite executar exportações com os mesmos parâmetros exatos da tarefa escolhida. Revise consultas, datas, destinatários e modos de escrita antes de confirmar. Mudanças de identidade, política ou recuperação exigem nova revisão.</p>';
        self::form('plan-export-rule');self::field('job_id','ID da tarefa de exportação','','Consulte a tarefa em Avançado → Tarefas.');
        self::check('enabled','Habilitar esta regra',true,'Desmarque para impedir novos despachos por esta regra.');self::button('Conferir regra de exportação');echo '</section>';
    }
    public static function search_console(): void {
        self::resource_panel('gsc');
        echo '<section class="f3-section"><h2>Verificar Search Console</h2><p class="f3-lead">Confira o acesso e as cotas antes de consultar páginas ou enviar o sitemap. As tarefas e agendas completas estão em Avançado.</p>';
        self::form('preflight');self::button('Verificar acesso e configuração');echo '</section>';
    }
    public static function tag_manager(): void {self::resource_panel('gtm');echo '<p>Escolha um contêiner existente. A configuração não publica tags; a publicação exige uma operação explícita.</p>';}
    private static function resource_panel(string $service): void {
        $bindings=(array)Options::get(Connections::BINDINGS,[]);
        $parent=sanitize_text_field(wp_unslash($_GET['resource_parent']??''));
        if (!$parent&&$service==='gtm'&&!empty($bindings['gtm_container_path'])) $parent=implode('/',array_slice(explode('/',$bindings['gtm_container_path']),0,2));
        echo '<section class="f3-section"><h2>'.esc_html($service==='gtm'?'Conta e contêiner':'Propriedade e sitemap').'</h2>';
        self::form('load-choices');self::hidden('choice_kind',$service);
        if ($service==='gtm') ResourceChoices::select('resource_parent','Conta Tag Manager',$parent,ResourceChoices::items('gtm_account'));
        self::button('Consultar recursos da conta');
        Screen::form('f3_google_setup_save');
        if ($service==='gtm') ResourceChoices::select('gtm_container_path','Contêiner',$bindings['gtm_container_path']??'',ResourceChoices::items('gtm',$parent));
        else {ResourceChoices::select('gsc_site_url','Propriedade Search Console',$bindings['gsc_site_url']??'',ResourceChoices::items('gsc'));self::field('sitemap_url','Endereço do sitemap',$bindings['sitemap_url']??Resources::sitemap_suggestion(),'Endereço HTTPS publicado pelo WordPress.','url');}
        echo '<p class="f3-actions"><button class="button button-primary">Salvar seleção</button></p></form></section>';
    }
    public static function incidents(): void {
        $search = self::query_text('incident_search');
        $offset = absint(self::query_text('offset'));
        echo '<section class="f3-section"><h2>Incidentes</h2><p class="f3-lead">Consulte as ocorrências da conexão e a ação indicada para cada uma.</p><form method="get" class="f3-list-tools">';
        self::hidden('page', Admin::SLUG); self::hidden('section', 'incidents'); self::hidden('connection_id', Connections::id());
        echo '<label>Buscar por recurso, código ou orientação<input type="search" name="incident_search" value="'.esc_attr($search).'"></label><button class="button">Buscar</button></form>';
        $page = Alerts::state(['limit'=>self::PAGE_SIZE, 'offset'=>$offset], false, $search);
        if (empty($page['available'])) {
            echo '<p role="alert">Falha ao consultar os incidentes. Atualize a página para tentar novamente.</p></section>';
            self::alert_preferences();
            return;
        }
        echo '<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Incidentes"><table data-server-page class="widefat striped"><thead><tr><th>Ocorrência</th><th>Estado</th><th>O que fazer</th><th>Última atualização</th></tr></thead><tbody>';
        foreach($page['incidents']??[] as $incident) echo '<tr><td data-label="Ocorrência">'.esc_html(self::incident_label($incident['event']??'')).'</td><td data-label="Estado">'.OverviewScreen::badge(($incident['status']??'')==='resolved'?'success':'attention', ($incident['status']??'')==='resolved'?'Resolvido':'Em aberto').'</td><td data-label="O que fazer">'.esc_html($incident['action']??'Confira o acesso da conexão e tente novamente.').ConversionScreen::diagnostic($incident['provider_error']??null).'</td><td data-label="Última atualização">'.esc_html(wp_date('d/m/Y H:i',(int)($incident['updated_at']??0))).'</td></tr>';
        if (empty($page['incidents'])) echo '<tr><td colspan="4">Nenhum incidente nesta página.</td></tr>';
        echo '</tbody></table></div>';
        self::page_controls('incidents', ['incident_search'=>$search], $offset, $page['total'], count($page['incidents']));
        echo '</section>';
        self::alert_preferences();
    }
    public static function incident_label(string $event): string {return ['access'=>'Falha de acesso ao Google','cron_late'=>'Execução agendada em atraso','sitemap_error'=>'Falha no envio de sitemap','scheduled_check'=>'Verificação agendada com falha','conversion_renewal'=>'Renovação da verificação de conversões falhou','conversion_verification'=>'Falha na verificação do destino de conversões'][$event]??'Ocorrência operacional';}
    private static function boxes(string $name,string $label,array $selected,array $items): void {
        echo '<fieldset class="f3-fieldset f3-choice-list"><legend>'.esc_html($label).'</legend><input type="hidden" name="'.esc_attr($name).'_present" value="1">';
        foreach($selected as $id) if (!isset($items[$id])) $items[$id]='Seleção salva: '.$id;
        foreach($items as $id=>$item) {
            $text=is_array($item)?$item['label']:$item;$description=is_array($item)?($item['description']??''):'';
            $desc='f3-operation-'.substr(hash('sha256',$name.'|'.$id),0,16);
            echo '<label class="f3-check"><input type="checkbox" name="'.esc_attr($name).'[]" value="'.esc_attr($id).'" '.checked(in_array($id,$selected,true),true,false).($description?' aria-describedby="'.esc_attr($desc).'"':'').'> '.esc_html($text).'</label>';
            if ($description) echo '<p class="description" id="'.esc_attr($desc).'">'.esc_html($description).'</p>';
        }
        if (!$items) echo '<p>Consulte os recursos da conta para carregar as opções.</p>';
        echo '</fieldset>';
    }
    private static function resource_boxes(string $service,array $selected): array {
        $items=[];
        foreach(ResourceChoices::items($service) as $row) $items[$service==='ga'?'properties/'.$row['id']:$row['id']]=$row['name'];
        if ($service==='ga'&&\Fator3\McpGoogle\ConversionDelivery::measurement_id()) $items['measurementIds/'.\Fator3\McpGoogle\ConversionDelivery::measurement_id()]='Fluxo de medição configurado no Site Core';
        return $items;
    }
    private static function operation_boxes(string $service): array {
        $out=[];$catalog=require __DIR__.'/../Data/Operations.php';
        $prefix=['ga'=>['analyticsadmin.','analyticsdata.','measurementprotocol.'],'ads'=>['googleads.','datamanager.'],'gtm'=>['tagmanager.'],'gsc'=>['webmasters.','searchconsole.'],'sheets'=>['sheets.'],'drive'=>['drive.'],'siteverification'=>['siteVerification.']][$service]??[];
        foreach(Policy::coverage()['methods'] as $api=>$methods) foreach($methods as $method) {
            if (!array_filter($prefix,static fn($p)=>str_starts_with($method,$p))) continue;
            $entry=\Fator3\McpGoogle\LabelsPT::catalog()['operations'][$method]??null;
            if ($entry) $out[$method]=$entry;
        }
        return $out;
    }
    public static function maintenance(): void {
        $s=\Fator3\McpGoogle\Storage\Maintenance::status();
        $labels=['complete'=>'Concluída na última observação','pending'=>'Há etapas pendentes','failed'=>'Uma etapa falhou'];
        $label=empty($s['read_success'])?'Estado indisponível':(!empty($s['blocked_by'])?'Execução bloqueada':($labels[$s['state']??'pending']??'Ainda não observada'));
        echo '<section class="f3-section"><h2>Manutenção do armazenamento</h2><p class="f3-lead"><strong>'.esc_html($label).'</strong></p>';
        echo '<p>O plugin executa a retenção do histórico e a manutenção do cache em lotes curtos. O progresso depende de uma passagem do cron ou do botão abaixo. A consulta desta tela não executa a manutenção.</p>';
        echo '<dl class="f3-details"><dt>Última observação</dt><dd>'.esc_html(isset($s['at'])?wp_date('d/m/Y H:i:s T',(int)$s['at']):'Não registrada').'</dd><dt>Cobertura</dt><dd>'.(!empty($s['inventory_complete'])?'Todas as etapas verificadas nessa passagem':'Verificação ainda incompleta').'</dd>';
        if (!empty($s['budget'])) echo '<dt>Último lote</dt><dd>'.esc_html((string)$s['budget']['processed']).' unidades · '.esc_html((string)$s['budget']['duration_ms']).' ms</dd>';
        echo '<dt>Próxima passagem agendada</dt><dd>'.esc_html(!empty($s['next_run'])?wp_date('d/m/Y H:i:s T',(int)$s['next_run']):'Sem disparo observado').'</dd></dl>';
        $families=['cron_retention'=>'Retenção do histórico','cache_sql'=>'Cache no banco','cache_files'=>'Arquivos de cache'];
        echo '<ul>';
        foreach($families as $key=>$name) {
            $p=$s['progress'][$key]??[];
            echo '<li>'.esc_html($name).': '.esc_html(!empty($p['error_code'])?'Falha: '.$p['error_code']:(!empty($p['complete'])&&!empty($p['examined_in_run'])?'verificada na última passagem':'pendente ou ainda não examinada')).'</li>';
        }
        echo '</ul>';
        if (!empty($s['blocked_by'])) echo '<p>Motivo: <code>'.esc_html($s['blocked_by']).'</code>. Conclua a recuperação ou aguarde a execução em andamento antes de repetir.</p>';
        else {
            self::form('maintenance');
            self::button('Avançar um lote de manutenção');
        }
        self::json('Ver e copiar detalhes da manutenção',$s);
        echo '</section>';
    }
    private static function lines( string $name ): array {
        if (isset($_POST[$name.'_present'])) return array_values(array_unique(array_map('sanitize_text_field',array_filter((array)wp_unslash($_POST[$name]??[]),'is_string'))));
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
        $text = isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $name ] ) ) : '';
        $lines = preg_split( '/[\r\n,]+/', $text );
        return array_values( array_unique( array_filter( array_map( 'trim', is_array( $lines ) ? $lines : array() ) ) ) );
    }
    private static function decoded( string $name ): array {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper. Structured input is validated by the shared schema/credential writer; text sanitization would corrupt JSON or the key.
        $text = isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : '';
        if ( strlen( $text ) > 262144 ) {
            throw new \InvalidArgumentException( 'JSON excede 256 KiB.' );
        }
        $value = json_decode( $text, true );
        if ( ! is_array( $value ) || ! str_starts_with( ltrim( $text ), '{' ) ) {
            // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception carries a structured internal error; renderers escape it at the output boundary.
            throw new \InvalidArgumentException( 'Informe um objeto JSON válido no campo ' . $name . '.' );
        }
        return $value;
    }
    public static function handle(): void {
        Admin::guard( self::ACTION );
        $operation = Admin::posted( 'operation' );
        if ($operation==='incident-slack') {
            Admin::saved(Alerts::save_slack(Admin::posted('slack_url'),Admin::posted('clear_slack')==='1',Admin::posted_revision()));
            return;
        }
        if ($operation==='load-choices') {
            $kind = Admin::posted('choice_kind');
            $parent = Admin::posted('resource_parent');
            if (Admin::posted_revision() !== Settings::revision()) {
                Admin::back('discovery_stale');
                return;
            }
            $result = \Fator3\McpGoogle\Automation\Execution::run(static function () use ($kind, $parent) {
                if ('gtm' === $kind) {
                    $accounts = ResourceChoices::load('gtm_account');
                    if ('' === $parent || empty($accounts['success']) || empty($accounts['complete'])) {
                        return $accounts;
                    }
                    return ResourceChoices::load('gtm', $parent);
                }
                return in_array($kind, ['ga', 'ads', 'gsc', 'sheets'], true)
                    ? ResourceChoices::load($kind) : ['success' => false];
            });
            wp_safe_redirect(add_query_arg('resource_parent', $parent, Admin::url(Resources::notice($result))));
            exit;
        }
        $parameters = array();
        $ability = '';
        $state = array();
        try {
            switch ( $operation ) {
                case 'access-recheck':
                    $ability = 'google/configure-alerts';
                    $hours = filter_var( Admin::posted( 'access_recheck_hours' ), FILTER_VALIDATE_INT );
                    $parameters = array(
                        'configuration' => array( 'access_recheck_hours' => false === $hours ? 0 : $hours ),
                        'expected_revision' => Admin::posted_revision(),
                        'dry_run' => 'save' !== Admin::posted( 'intent' ),
                    );
                    break;
                case 'refresh-key': $ability='google/refresh-service-account-key-status';break;
                case 'plan-key-monitoring':
                $ability='google/plan-key-monitoring';$parameters=['configuration'=>['warning_days'=>(int)Admin::posted('warning_days')]];$state['apply_key_monitoring']=true;break;
                case 'plan-export-rule':
                $ability='google/plan-export-rule';$parameters=['job_id'=>Admin::posted('job_id'),'enabled'=>Admin::posted('enabled')==='1'];$state['apply_export_rule']=true;break;
                case 'preflight': $ability='google/preflight';break;
                case 'maintenance':
                $ability='google/maintenance';
                break;
                case 'save-consumer':
                $ability = 'google/configure-consumer';
                $parameters = array(
                    'consumer_id' => Admin::posted( 'consumer_id' ),
                    'enabled' => '1' === Admin::posted( 'consumer_enabled' ),
                    'expected_revision' => Admin::posted( 'expected_revision' ),
                );
                break;
                case 'recovery':
                $ability = 'google/recovery';
                $parameters = array(
                    'action' => Admin::posted( 'recovery_action' ),
                    'expected_generation' => Admin::posted( 'recovery_generation' ),
                    'acknowledge_reconciled' => '1' === Admin::posted( 'acknowledge_reconciled' ),
                );
                break;
                case 'get-schedule':
                $ability = 'google/get-schedule';
                $parameters = array( 'schedule_id' => Admin::posted( 'schedule_id' ) );
                $state['edit_schedule'] = true;
                break;
                case 'save-schedule':
                $ability = 'google/schedule-report';
                $parameters = array(
                    'task' => Admin::posted( 'task' ),
                    'parameters' => self::decoded( 'parameters_json' ),
                    'interval_seconds' => (int) Admin::posted( 'interval_seconds' ),
                    'enabled' => '1' === Admin::posted( 'schedule_enabled' ),
                );
                if ( '' !== Admin::posted( 'schedule_id' ) ) {
                    $parameters['schedule_id'] = Admin::posted( 'schedule_id' );
                    $parameters['expected_revision'] = Admin::posted( 'schedule_revision' );
                }
                break;
                case 'prepare-job':
                $ability = 'google/prepare-job';
                $parameters = array( 'job_id' => Admin::posted( 'job_id' ) );
                $state['approve_job'] = true;
                break;
                case 'get-job':
                case 'run-job':
                case 'cancel-job':
                case 'reconcile-job':
                $ability = 'google/' . $operation;
                $parameters = array( 'job_id' => Admin::posted( 'job_id' ) );
                if ( 'get-job' === $operation ) {
                    $parameters['include_input'] = true;
                }
                if ( 'reconcile-job' === $operation ) {
                    $parameters += array(
                        'observed_outcome' => Admin::posted( 'observed_outcome' ),
                        'evidence' => Admin::posted( 'evidence' ),
                    );
                }
                break;
                case 'run-due':
                $ability = 'google/executar-vencidos';
                break;
                case 'cleanup':
                $ability = 'google/cleanup-jobs';
                $parameters = array( 'dry_run' => true );
                $state['apply_cleanup'] = true;
                break;
                case 'audit-export':
                $state['audit_export'] = true;
                $ability = 'google/audit-export';
                $parameters = array(
                    'format' => Admin::posted( 'format' ),
                    'desde_revisao' => Admin::posted( 'desde_revisao' ),
                    'limit' => 100,
                );
                break;
                case 'save-policy':
                $ability = 'google/plan-policy';
                $state['apply_policy'] = true;
                $policy = array(
                    'mode' => Admin::posted( 'policy_mode' ),
                    'services' => array(),
                );
                foreach ( array( 'gtm', 'ga', 'ads', 'gsc', 'sheets', 'drive', 'siteverification' ) as $service ) {
                    $policy['services'][ $service ] = array(
                        'resources' => self::lines( $service . '_resources' ),
                        'operations' => self::lines( $service . '_operations' ),
                        'allow_create' => '1' === Admin::posted( $service . '_create' ),
                        'recipients' => self::lines( $service . '_recipients' ),
                    );
                }
                $parameters = array( 'policy' => $policy );
                break;
                case 'discover-policy':
                \Fator3\McpGoogle\Automation\Execution::run(static function(){foreach(['ga','ads','gsc','sheets'] as $kind) {if(\Fator3\McpGoogle\Automation\Execution::remaining()<2)break;ResourceChoices::load($kind);}return [];});
                $ability = 'google/policy-discover-resources';
                break;
                case 'save-alerts':
                $ability = 'google/configure-alerts';
                $events = array_values( array_filter( Alerts::EVENTS, static fn ( $event ) => '1' === Admin::posted( 'event_' . $event ) ) );
                $parameters = array(
                    'expected_revision' => Admin::posted_revision(),
                    'configuration' => array(
                        'enabled' => '1' === Admin::posted( 'alerts_enabled' ),
                        'email_enabled' => '1' === Admin::posted( 'email_enabled' ),
                        'recipients' => self::lines( 'recipients' ),
                        'events' => $events,
                        'minimum_interval' => (int) Admin::posted( 'minimum_interval' ),
                    ),
                );
                break;
                case 'save-updates':
                $ability = 'google/configure-update-origin';
                $parameters = array(
                    'expected_revision' => Admin::posted_revision(),
                    'origin' => array(
                        'enabled' => '1' === Admin::posted( 'updates_enabled' ),
                        'manifest_url' => Admin::posted( 'manifest_url' ),
                        'allowed_hosts' => self::lines( 'allowed_hosts' ),
                    ),
                );
                break;
                case 'save-local':
                $ability = 'google/configure-local';
                $parameters = array(
                    'expected_revision' => Admin::posted_revision(),
                    'audit_local_reads' => '1' === Admin::posted( 'audit_local_reads' ),
                    'purge_on_uninstall' => '1' === Admin::posted( 'purge_on_uninstall' ),
                );
                break;
                case 'save-profile':
                $ability = 'ga/save-profile';
                $parameters = array(
                    'profile_id' => Admin::posted( 'profile_id' ),
                    'expected_revision' => Admin::posted( 'profile_revision' ),
                    'profile' => Admin::posted('profile_structured')==='1'?ProfileForm::parse(Profile::schema(),(array)wp_unslash($_POST['profile_fields']??[])):self::decoded('profile_json'),
                );
                break;
                case 'plan-profile':
                $ability = 'ga/conformidade';
                $parameters = array(
                    'profile_id' => Admin::posted( 'profile_id' ),
                    'property_id' => Admin::posted( 'property_id' ),
                    'stream_id' => Admin::posted( 'stream_id' ),
                );
                $state['prepare_profile'] = true;
                break;
                case 'export-template':
                $ability = 'google/export-template';
                break;
                case 'plan-template':
                $ability = 'google/plan-template';
                $parameters = array(
                    'template' => self::decoded( 'template_json' ),
                    'mapping' => self::decoded( 'mapping_json' ),
                );
                $state['apply_template'] = true;
                break;
                case 'apply-export-rule':
                case 'apply-key-monitoring':
                case 'apply-cleanup':
                case 'apply-policy':
                case 'approve-job':
                case 'download-audit':
                case 'audit-next':
                case 'apply-template':
                case 'prepare-profile':
                case 'confirm':
                $prior = self::continuation( $operation, Admin::posted( 'reference' ) );
                if ( 'download-audit' === $operation ) {
                    $result = $prior['result'];
                    // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Data transport encoding for a signed cursor or authenticated download; never executable PHP.
                    $content = base64_decode( $result['content_base64'] ?? '', true );
                    if ( ! is_string( $content ) || ! hash_equals( $result['sha256'] ?? '', hash( 'sha256', $content ) ) ) {
                        throw new \InvalidArgumentException( 'Arquivo temporário inválido.' );
                    }
                    nocache_headers();
                    header( 'Content-Type: ' . ( 'csv' === $result['format'] ? 'text/csv' : 'application/json' ) . '; charset=utf-8' );
                    header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $result['filename'] ) . '"' );
                    header( 'X-Content-Type-Options: nosniff' );
                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Authenticated file attachment, verified by hash; escaping would corrupt the CSV/JSON bytes.
                    echo $content;
                    exit;
                }
                elseif ( 'audit-next' === $operation ) {
                    $state['audit_export'] = true;
                    $ability = 'google/audit-export';
                    $parameters = array(
                        'cursor' => $prior['result']['next_cursor'],
                        'format' => $prior['result']['format'],
                        'limit' => 100,
                    );
                }
                elseif (in_array($operation,['apply-export-rule','apply-key-monitoring'],true)) {
                    $ability='google/'.($operation==='apply-export-rule'?'configure-export-rule':'configure-key-monitoring');
                    $parameters=$prior['parameters']+['expected_revision'=>$prior['result']['configuration_revision'],'expected_plan_hash'=>$prior['result']['plan_hash']];
                }
                elseif ( 'apply-cleanup' === $operation ) {
                    $ability = 'google/cleanup-jobs';
                    $parameters = array( 'dry_run' => false );
                }
                elseif ( 'apply-policy' === $operation ) {
                    $ability = 'google/configure-policy';
                    $parameters = array(
                        'policy' => $prior['result']['policy'],
                        'expected_revision' => $prior['result']['revision'],
                        'expected_plan_hash' => $prior['result']['plan_hash'],
                    );
                }
                elseif ( 'approve-job' === $operation ) {
                    $ability = 'google/approve-job';
                    $parameters = array(
                        'job_id' => $prior['result']['job_id'],
                        'approval_token' => $prior['result']['confirmation_token'],
                    );
                }
                elseif ( 'confirm' === $operation ) {
                    $ability = $prior['result']['ability'];
                    $parameters = $prior['result']['parameters'];
                    $parameters['confirmation_token'] = $prior['result']['confirmation_token'];
                }
                elseif ( 'apply-template' === $operation ) {
                    $ability = 'google/apply-template';
                    $parameters = $prior['parameters'] + array(
                        'expected_revision' => $prior['result']['revision'],
                        'expected_plan_hash' => $prior['result']['plan_hash'],
                    );
                }
                else {
                    $ability = 'google/prepare-operation';
                    $parameters = array(
                        'ability' => 'ga/aplicar-perfil',
                        'parameters' => $prior['parameters'] + array(
                            'dry_run' => false,
                            'expected_plan_hash' => $prior['result']['plan_hash'],
                        ),
                    );
                    $state['confirm'] = true;
                }
                break;
                case 'prepare-revoke':
                $ability = 'google/prepare-operation';
                $parameters = array(
                    'ability' => 'google/disconnect',
                    'parameters' => array( 'revoke' => true ),
                );
                $state['confirm'] = true;
                break;
                default:
                throw new \InvalidArgumentException( 'Ação desconhecida.' );
            }
            $entry = wp_get_ability( $ability );
            $input = $parameters + array( 'connection_id' => Connections::id() );
            $result = $entry ? Gate::administrative( $ability, static function () use ( $ability, $entry, $input ) {
                if ( Gate::administrative_allowed( $ability ) ) {
                    return Ability::execute_admin( $ability, $input );
                }
                return $entry->execute( $input );
            } ) : Response::fail( 'Habilidade indisponível.' );
            if ( is_wp_error( $result ) ) {
                $result = Response::fail( $result );
            }
            if ( empty( $result['success'] ) ) {
                $state = array();
            }
            $state += array(
                'parameters' => $parameters,
                'result' => $result,
            );
        }
        catch ( \Throwable $e ) {
            $state = array( 'result' => Response::fail( new \WP_Error( 'f3_google_operation_input', Audit::redact( $e->getMessage() ) ) ) );
        }
        if (\Fator3\McpGoogle\Recovery::guard()) {
            // No transient may be created while restoring. Display the live guard after redirect.
            Admin::back('recovery_observed');
            return;
        }
        $reference = bin2hex( random_bytes( 16 ) );
        $state['reference'] = $reference;
        $cipher = Crypto::encrypt( wp_json_encode( $state ) );
        if ( '' === $cipher ) {
            Admin::require_saved( Response::fail( 'Não foi possível cifrar o resultado temporário.' ) );
        }
        if ( ! Cache::set( self::key( $reference ), $cipher, 600 ) ) {
            Admin::require_saved(Response::fail(new \WP_Error('f3_google_feedback_persistence','O resultado temporário não foi salvo. Consulte o estado da operação antes de repeti-la.')));
        }
        wp_safe_redirect( add_query_arg( 'operation_ref', $reference, Admin::url( 'operation_result' ) ) );
        exit;
    }
}
