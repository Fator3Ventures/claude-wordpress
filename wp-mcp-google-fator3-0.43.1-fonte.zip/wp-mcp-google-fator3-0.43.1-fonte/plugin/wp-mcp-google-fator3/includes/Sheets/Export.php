<?php
/**
 * Exportação de relatórios para Sheets, com células literais e resultado parcial explícito.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Sheets;
use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Confirmation;
use Fator3\McpGoogle\Policy;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Generic\ExecuteAction;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\Unified\Blend;
use Fator3\McpGoogle\Unified\Query;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Export {
    private const MAX_CELLS = 500000;
    public static function register(): void {
        Ability::register(
            'google/export-to-sheet',
            'sheets',
            array(
                'mode' => 'write',
                'label' => __( 'Google: exportar para Sheets', 'wp-mcp-google-fator3' ),
                'description' => __( 'Executa query, blend ou queries e grava uma aba por relatório, substituindo valores ou anexando linhas. Células são literais, sem executar fórmulas. Aceita planilha compartilhada, Drive compartilhado ou criação via OAuth/delegação.', 'wp-mcp-google-fator3' ),
                'input_schema' => array(
                    'properties' => array(
                        'completeness_policy'=>array('type'=>'string','enum'=>array('require_complete','allow_partial'),'default'=>'require_complete','description'=>'Padrão estrito: coleta incompleta ou desconhecida bloqueia qualquer escrita; parcial exige escolha explícita.'),
                        'query' => array(
                            'type' => 'object',
                            'description' => 'Argumentos de google/query. Informe somente um entre query, blend e queries.',
                        ),
                        'blend' => Blend::schema(),
                        'queries' => array(
                            'type' => 'array',
                            'minItems' => 1,
                            'maxItems' => 20,
                            'items' => array( 'type' => 'object' ),
                            'description' => 'Consultas google/query, ou objetos {query:{...},tab_name:"..."} / {blend:{...},tab_name:"..."}.',
                        ),
                        'spreadsheet_id' => array(
                            'type' => 'string',
                            'description' => 'ID de planilha existente, compartilhada com a credencial com permissão de edição.',
                        ),
                        'title' => array(
                            'type' => 'string',
                            'description' => 'Título de uma planilha nova.',
                        ),
                        'tab_name' => array(
                            'type' => 'string',
                            'description' => 'Nome da aba, para uma única query ou blend. Para queries, declare tab_name em cada item.',
                        ),
                        'mode' => array(
                            'type' => 'string',
                            'enum' => array( 'replace', 'append' ),
                            'description' => 'replace limpa os valores antigos da aba e escreve cabeçalho/dados; append exige cabeçalho compatível e preserva as linhas existentes. Padrão replace.',
                        ),
                        'share_with' => array(
                            'type' => 'array',
                            'items' => array( 'type' => 'string' ),
                            'description' => 'E-mails que receberão acesso pelo Drive após a gravação. Não torna a planilha pública.',
                        ),
                        'share_role' => array(
                            'type' => 'string',
                            'enum' => array( 'reader', 'commenter', 'writer' ),
                            'description' => 'Padrão reader.',
                        ),
                        'shared_drive_folder_id' => array(
                            'type' => 'string',
                            'description' => 'Pasta de um Drive compartilhado para criar a planilha com uma service account. Não é uma pasta compartilhada do Meu Drive.',
                        ),
                        'dry_run' => array(
                            'type' => 'boolean',
                            'description' => 'Sheets/Drive não têm validateOnly nesta operação. true é recusado antes de qualquer gravação.',
                        ),
                    ),
                ),
                'callback' => array( self::class, 'run' ),
            )
        );
    }
    public static function run( array $input ): array {
        return self::execute( $input );
    }
    /** Internal adapter for authorized audit rows; this is not a public arbitrary-query parameter. */
    public static function from_tables( array $input, array $tables ): array {
        if ( ! $tables || count( $tables ) > 20 ) {
            return Response::fail( new \WP_Error( 'f3_google_export_tables', 'Informe entre 1 e 20 tabelas.' ) );
        }
        unset( $input['query'], $input['blend'], $input['queries'] );
        $input['queries'] = array_map(
            static fn ( $i ) => array(
                'query' => array(),
                'tab_name' => $input['tab_name'] ?? ( 1 === count( $tables ) ? 'Auditoria' : 'Auditoria ' . ( $i + 1 ) ),
            ),
            array_keys( $tables )
        );
        foreach($tables as &$table)if(!isset($table['collection']))$table['collection']=['mode'=>'supplied_local_rows','complete'=>empty($table['truncated'])&&isset($table['rows'])&&count($table['rows'])===($table['row_count']??count($table['rows']))];
        unset($table);
        return self::execute( $input, array_values( $tables ) );
    }
    private static function execute( array $input, ?array $tables = null ): array {
        $gate = Gate::check( 'sheets' );
        if ( null !== $gate ) {
            return $gate;
        }
        $plan = self::plan( $input );
        if ( is_wp_error( $plan ) ) {
            return Response::fail( $plan );
        }
        // Creation, sharing and multiple report targets need approval of the whole flow.
        if ( '' === $plan['spreadsheet_id'] || $plan['share_with'] || count( $plan['reports'] ) > 1 || $plan['mode']==='append' ) {
            $required = Confirmation::require_confirmation();
            if ( null !== $required ) {
                return Response::fail( $required );
            }
        }
        $state = array(
            'spreadsheet_id' => $plan['spreadsheet_id'],
            'created' => false,
            'writes' => array(),
            'completeness_policy'=>$plan['completeness_policy'],
            'extraction'=>array(),
            'tabs' => array(),
            'shared_with' => array(),
            'warnings' => array(),
        );
        // Todos os relatórios são calculados e validados antes da primeira escrita.
        $reports = array();
        $cells = 0;
        $encoded_bytes = 0;
        foreach ( $plan['reports'] as $index => $entry ) {
            $table = null !== $tables ? $tables[ $index ] : ( 'blend' === $entry['kind'] ? Blend::run( $entry['input'] ) : Query::run( $entry['input'] ) );
            if ( empty( $table['success'] ) ) {
                return Response::fail(
                    new \WP_Error( 'f3_google_export_query_failed', 'A consulta da aba ' . $entry['title'] . ' falhou: ' . ( $table['message'] ?? 'erro sem mensagem' ) ),
                    array(
                        'query_error' => $table,
                        'partial' => false,
                    )
                );
            }
            $complete=\Fator3\McpGoogle\Unified\Quality::complete($table);
            $state['extraction'][]=['title'=>$entry['title'],'complete'=>$complete,'collection'=>$table['collection']??null,'coverage'=>$table['coverage']??null,'quality'=>$table['quality']??null];
            if($plan['completeness_policy']==='require_complete'&&!$complete)return Response::fail(new \WP_Error('f3_google_export_incomplete','A extração da aba '.$entry['title'].' está incompleta ou não comprovada. O destino foi preservado.'),['operation_outcome'=>'not_applied','partial'=>false,'extraction'=>$state['extraction'],'completeness_policy'=>$plan['completeness_policy']]);
            $values = self::values( $table );
            if ( is_wp_error( $values ) ) {
                return Response::fail( $values );
            }
            $cells += count( $values ) * count( $values[0] );
            if ( $cells > self::MAX_CELLS ) {
                return Response::fail( new \WP_Error( 'f3_google_export_size', 'A exportação excede 500.000 células. Reduza limit/dimensões das consultas ou divida em chamadas.' ) );
            }
            $encoded_rows = array_map( array( self::class, 'cells' ), $values );
            $encoded_bytes += strlen( (string) wp_json_encode( $encoded_rows ) );
            if ( $encoded_bytes > 8 * 1024 * 1024 - 65536 ) {
                return Response::fail( new \WP_Error( 'f3_google_export_size', 'O corpo de exportação excede 8 MiB. Reduza limit ou divida os relatórios em chamadas menores.' ) );
            }
            $reports[] = array(
                'title' => $entry['title'],
                'values' => $values,
                'cells' => $encoded_rows,
                'table' => $table,
            );
            foreach ( (array) ( $table['warnings'] ?? array() ) as $warning ) {
                $state['warnings'][] = $entry['title'] . ': ' . ( is_scalar( $warning ) ? (string) $warning : (string) wp_json_encode( $warning ) );
            }
            if ( ! empty( $table['truncated'] ) ) {
                $state['warnings'][] = $entry['title'] . ': a consulta foi truncada; a exportação contém somente as linhas recebidas.';
            }
        }
        if ( '' !== $plan['folder_id'] ) {
            $folder = ExecuteAction::call(
                'drive',
                'drive.files.get',
                array( 'fileId' => $plan['folder_id'] ),
                array(
                    'supportsAllDrives' => true,
                    'fields' => 'id,mimeType,driveId,trashed,capabilities(canAddChildren)',
                ),
                null,
                array( 'mode' => 'read' )
            );
            if ( is_wp_error( $folder ) ) {
                return self::failure( $folder, $state );
            }
            if ( 'application/vnd.google-apps.folder' !== ( $folder['mimeType'] ?? '' ) || empty( $folder['driveId'] ) || ! empty( $folder['trashed'] ) || false === ( $folder['capabilities']['canAddChildren'] ?? true ) ) {
                return self::failure( new \WP_Error( 'f3_google_shared_drive_folder', 'shared_drive_folder_id precisa identificar uma pasta de Drive compartilhado acessível para criação. Uma pasta do Meu Drive compartilhada com a service account não resolve a ausência de quota.' ), $state );
            }
        }
        if ( '' === $state['spreadsheet_id'] ) {
            Audit::before( array( 'exists' => false ) );
            if ( '' !== $plan['folder_id'] ) {
                $created = ExecuteAction::call(
                    'drive',
                    'drive.files.create',
                    array(),
                    array(
                        'supportsAllDrives' => true,
                        'fields' => 'id,name,webViewLink,driveId,parents',
                    ),
                    array(
                        'name' => $plan['title'],
                        'mimeType' => 'application/vnd.google-apps.spreadsheet',
                        'parents' => array( $plan['folder_id'] ),
                    ),
                    array( 'mode' => 'write' )
                );
                $id = is_wp_error( $created ) ? '' : (string) ( $created['id'] ?? '' );
            }
            else {
                $created = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.create', array(), array(), array( 'properties' => array( 'title' => $plan['title'] ) ), array( 'mode' => 'write' ) );
                $id = is_wp_error( $created ) ? '' : (string) ( $created['spreadsheetId'] ?? '' );
            }
            if ( is_wp_error( $created ) ) {
                return self::failure( $created, $state, self::uncertain( $created ) );
            }
            if ( Confirmation::capturing() ) {
                $id = 'f3-pending-spreadsheet';
            }
            if ( ! self::valid_id( $id ) ) {
                return self::failure( new \WP_Error( 'f3_google_export_create_response', 'A API respondeu à criação sem um ID de planilha válido. Verifique o Drive antes de repetir: a criação pode ter ocorrido.' ), $state, true );
            }
            $state['spreadsheet_id'] = $id;
            $state['created'] = true;
            $state['writes'][] = array(
                'operation' => 'create_spreadsheet',
                'spreadsheet_id' => $id,
                'confirmed' => true,
            );
            if ( '' !== $plan['folder_id'] && ! Confirmation::capturing() && ( ! in_array( $plan['folder_id'], (array) ( $created['parents'] ?? array() ), true ) || ( $created['driveId'] ?? null ) !== $folder['driveId'] ) ) {
                return self::failure( new \WP_Error( 'f3_google_export_created_parent', 'Arquivo criado, mas o vínculo com a pasta/Drive autorizado não foi confirmado. Confira o ID devolvido antes de continuar.' ), $state, true );
            }
        }
        if ( $state['created'] ) {
            // The target ID and initial tab IDs do not exist during preparation.
            // The approved template binds literal cells, titles, mode and recipients;
            // its concrete HTTP bodies are recorded before any continuation write.
            $intent = array(
                'reports' => array_map(
                    static fn ( $r ) => array(
                        'title' => $r['title'],
                        'cells' => $r['cells'],
                    ),
                    $reports
                ),
                'mode' => $plan['mode'],
                'share_with' => $plan['share_with'],
                'share_role' => $plan['share_role'],
                'parent' => $plan['folder_id'],
            );
            return Policy::with_created(
                $state['spreadsheet_id'],
                $plan['folder_id'],
                static function () use ( $plan, $state, $reports, $intent ): array {
                $result = Confirmation::deferred( 'sheets-created-export-v1', $intent, static fn () => self::finish( $plan, $state, $reports ) );
                if ( empty( $result['success'] ) && ! isset( $result['spreadsheet_id'] ) ) {
                    return self::failure( new \WP_Error( $result['error_code'] ?? 'f3_google_export_continuation', $result['message'] ?? 'Continuação recusada.', $result['details'] ?? null ), $state );
                }
                return $result;
                }
            );
        }
        return self::finish( $plan, $state, $reports );
    }
    private static function finish( array $plan, array $state, array $reports ): array {
        $metadata = $state['created'] && 'f3-pending-spreadsheet' === $state['spreadsheet_id'] ? array( 'sheets' => array() ) : self::metadata( $state['spreadsheet_id'] );
        if ( is_wp_error( $metadata ) ) {
            return self::failure( $metadata, $state );
        }
        $prepared = self::requests( $reports, $metadata, $state['spreadsheet_id'], $plan['mode'] );
        if ( is_wp_error( $prepared ) ) {
            return self::failure( $prepared, $state );
        }
        if ( ! $state['created'] ) {
            Audit::before(
                array(
                    'spreadsheet_id' => $state['spreadsheet_id'],
                    'metadata' => $metadata,
                    'tabs' => $prepared['before'],
                    'permissions' => array(
                        'available' => false,
                        'reason' => 'Snapshot de permissões não capturado; os compartilhamentos solicitados são registrados separadamente.',
                    ),
                )
            );
        }
        $payload = array(
            'requests' => $prepared['requests'],
            'includeSpreadsheetInResponse' => false,
        );
        if ( strlen( (string) wp_json_encode( $payload ) ) > 8 * 1024 * 1024 ) {
            return self::failure( new \WP_Error( 'f3_google_export_size', 'O corpo de exportação excede 8 MiB. Reduza limit ou divida os relatórios em chamadas menores.' ), $state );
        }
        if ( ! empty( $prepared['requests'] ) ) {
            $written = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.batchUpdate', array( 'spreadsheetId' => $state['spreadsheet_id'] ), array(), $payload, array( 'mode' => 'write' ) );
            if ( is_wp_error( $written ) ) {
                return self::failure( $written, $state, self::uncertain( $written ) );
            }
            $state['writes'][] = array(
                'operation' => 'write_tabs',
                'mode' => $plan['mode'],
                'tabs' => array_column( $prepared['tabs'], 'title' ),
                'confirmed' => true,
            );
        }
        $state['tabs'] = $prepared['tabs'];
        foreach ( $plan['share_with'] as $email ) {
            $permission = ExecuteAction::call(
                'drive',
                'drive.permissions.create',
                array( 'fileId' => $state['spreadsheet_id'] ),
                array(
                    'supportsAllDrives' => true,
                    'sendNotificationEmail' => false,
                    'fields' => 'id,type,emailAddress,role',
                ),
                array(
                    'type' => 'user',
                    'role' => $plan['share_role'],
                    'emailAddress' => $email,
                ),
                array( 'mode' => 'write' )
            );
            if ( is_wp_error( $permission ) ) {
                self::capture_after( $state );
                return self::failure( $permission, $state, self::uncertain( $permission ), 'share:' . $email );
            }
            $state['shared_with'][] = array(
                'email' => $email,
                'role' => $plan['share_role'],
                'permission_id' => $permission['id'] ?? null,
            );
            $state['writes'][] = array(
                'operation' => 'share',
                'email' => $email,
                'role' => $plan['share_role'],
                'confirmed' => true,
            );
        }
        self::capture_after( $state );
        $state['verification']=self::verify($state,$reports,$plan['mode']);
        return Response::ok(
            $state + array(
                'spreadsheet_url' => self::url( $state['spreadsheet_id'] ),
                'mode' => $plan['mode'],
                'partial' => false,
                'extraction_complete'=>!in_array(false,array_column($state['extraction'],'complete'),true),
                'operation_outcome'=>'applied',
                'value_encoding' => 'literal stringValue/numberValue/boolValue; formulas are never inferred',
            ),
            'Relatório exportado: ' . count( $state['tabs'] ) . ' aba(s).'
        );
    }
    /** @return array|\WP_Error */
    private static function plan( array $input ) {
        if ( ! empty( $input['dry_run'] ) ) {
            return new \WP_Error( 'f3_google_dry_run_unsupported', 'Sheets/Drive não oferecem validateOnly para esta exportação. Use google/query ou google/blend para revisar os dados; depois execute a exportação sem dry_run.' );
        }
        $completeness=$input['completeness_policy']??'require_complete';
        if(!in_array($completeness,['require_complete','allow_partial'],true))return new \WP_Error('f3_google_export_completeness','Use require_complete ou allow_partial.');
        $choices = array_intersect( array( 'query', 'blend', 'queries' ), array_keys( $input ) );
        if ( 1 !== count( $choices ) ) {
            return new \WP_Error( 'f3_google_export_source', 'Informe exatamente um entre query, blend e queries.' );
        }
        $spreadsheet = (string) ( $input['spreadsheet_id'] ?? '' );
        $folder = (string) ( $input['shared_drive_folder_id'] ?? '' );
        if ( ( '' !== $spreadsheet && ! self::valid_id( $spreadsheet ) ) || ( '' !== $folder && ! self::valid_id( $folder ) ) || ( '' !== $spreadsheet && '' !== $folder ) ) {
            return new \WP_Error( 'f3_google_export_id', 'Use IDs do Google, sem URL. spreadsheet_id e shared_drive_folder_id são alternativas: o segundo destina-se à criação.' );
        }
        if ( '' === $spreadsheet && '' === $folder && 'service_account' === Options::auth_mode() && '' === trim( (string) Options::get( Options::SA_SUBJECT, '' ) ) ) {
            return new \WP_Error( 'f3_google_service_account_storage', 'Service accounts não têm quota para criar arquivos próprios no Meu Drive. Informe spreadsheet_id de uma planilha compartilhada para edição, shared_drive_folder_id de um Drive compartilhado, ou use OAuth de usuário/delegação configurada.' );
        }
        $mode = $input['mode'] ?? 'replace';
        $role = $input['share_role'] ?? 'reader';
        $title = trim( (string) ( $input['title'] ?? 'Relatório Google ' . gmdate( 'Y-m-d' ) ) );
        if ( ! in_array( $mode, array( 'replace', 'append' ), true ) || ! in_array( $role, array( 'reader', 'commenter', 'writer' ), true ) || '' === $title || strlen( $title ) > 1000 || preg_match( '/[\x00-\x1f]/', $title ) ) {
            return new \WP_Error( 'f3_google_export_options', 'Revise title, mode (replace/append) e share_role (reader/commenter/writer).' );
        }
        $emails = $input['share_with'] ?? array();
        if ( ! is_array( $emails ) || count( $emails ) > 100 ) {
            return new \WP_Error( 'f3_google_export_email', 'share_with deve conter até 100 e-mails.' );
        }
        foreach ( $emails as $email ) {
            if ( ! is_string( $email ) || ! is_email( $email ) ) {
                return new \WP_Error( 'f3_google_export_email', 'Há um e-mail inválido em share_with. Nenhum compartilhamento ou gravação foi realizado.' );
            }
        }
        if ( isset( $input['queries'] ) ) {
            $entries = $input['queries'];
            if ( ! is_array( $entries ) || ! $entries || count( $entries ) > 20 ) {
                return new \WP_Error( 'f3_google_export_queries', 'queries deve conter entre 1 e 20 consultas.' );
            }
        }
        else {
            $kind = isset( $input['blend'] ) ? 'blend' : 'query';
            $entries = array(
                array(
                    $kind => $input[ $kind ],
                    'tab_name' => $input['tab_name'] ?? 'Relatório',
                ),
            );
        }
        if ( isset( $input['queries'], $input['tab_name'] ) && count( $entries ) > 1 ) {
            return new \WP_Error( 'f3_google_export_tab', 'Com várias consultas, informe tab_name em cada item de queries.' );
        }
        $reports = array();
        $titles = array();
        foreach ( array_values( $entries ) as $i => $entry ) {
            if ( ! is_array( $entry ) || ( isset( $entry['query'] ) && isset( $entry['blend'] ) ) ) {
                return new \WP_Error( 'f3_google_export_queries', 'Cada item de queries deve ser uma consulta ou um objeto com query ou blend.' );
            }
            $kind = isset( $entry['blend'] ) ? 'blend' : 'query';
            $args = $entry[ $kind ] ?? $entry;
            if ( ! is_array( $args ) ) {
                return new \WP_Error( 'f3_google_export_queries', 'Os argumentos da consulta devem ser um objeto.' );
            }
            $tab = (string) ( $entry['tab_name'] ?? ( 1 === count( $entries ) ? ( $input['tab_name'] ?? 'Relatório' ) : 'Relatório ' . ( $i + 1 ) ) );
            if ( ! self::valid_title( $tab ) || isset( $titles[ self::fold( $tab ) ] ) ) {
                return new \WP_Error( 'f3_google_export_tab', 'Cada aba deve ter nome único, não vazio, de até 100 caracteres, sem : \\ / ? * [ ].' );
            }
            $titles[ self::fold( $tab ) ] = true;
            unset( $args['tab_name'], $args['prefix'], $args['name'] );
            $reports[] = array(
                'kind' => $kind,
                'input' => $args,
                'title' => $tab,
            );
        }
        return array(
            'spreadsheet_id' => $spreadsheet,
            'completeness_policy'=>$completeness,
            'folder_id' => $folder,
            'title' => $title,
            'mode' => $mode,
            'share_with' => array_values( array_unique( $emails ) ),
            'share_role' => $role,
            'reports' => $reports,
        );
    }
    /** @return array|\WP_Error */
    private static function values( array $table ) {
        if ( empty( $table['columns'] ) || ! is_array( $table['columns'] ) || ! isset( $table['rows'] ) || ! is_array( $table['rows'] ) || count( $table['columns'] ) > 18278 ) {
            return new \WP_Error( 'f3_google_export_table', 'A consulta não devolveu uma tabela com colunas e linhas válidas.' );
        }
        $header = array();
        foreach ( $table['columns'] as $column ) {
            if ( ! is_array( $column ) || ! isset( $column['id'] ) || ! is_string( $column['id'] ) || '' === $column['id'] ) {
                return new \WP_Error( 'f3_google_export_columns', 'A tabela contém uma coluna sem ID.' );
            }
            $header[] = $column['id'];
        }
        if ( count( array_unique( $header ) ) !== count( $header ) ) {
            return new \WP_Error( 'f3_google_export_columns', 'A tabela contém IDs de coluna repetidos.' );
        }
        $rows = array( $header );
        foreach ( $table['rows'] as $row ) {
            if ( ! is_array( $row ) || array_values( $row ) !== $row || count( $row ) !== count( $header ) ) {
                return new \WP_Error( 'f3_google_export_rows', 'A tabela contém linha que não corresponde às colunas.' );
            }
            foreach ( $row as $value ) {
                if ( ( null !== $value && ! is_scalar( $value ) ) || ( is_float( $value ) && ! is_finite( $value ) ) || ( is_string( $value ) && strlen( $value ) > 50000 ) ) {
                    return new \WP_Error( 'f3_google_export_value', 'A tabela contém célula inválida: use valores escalares finitos ou null e textos de até 50.000 bytes.' );
                }
            }
            $rows[] = $row;
        }
        return $rows;
    }
    /** Prepara uma única operação atômica do Sheets para todas as abas. @return array|\WP_Error */
    private static function requests( array $reports, array $metadata, string $id, string $mode ) {
        $sheets = array();
        $next_id = 0;
        foreach ( (array) ( $metadata['sheets'] ?? array() ) as $sheet ) {
            $properties = $sheet['properties'] ?? array();
            if ( isset( $properties['title'], $properties['sheetId'] ) ) {
                $sheets[ self::fold( (string) $properties['title'] ) ] = $properties;
                $next_id = max( $next_id, (int) $properties['sheetId'] + 1 );
            }
        }
        $requests = array();
        $before = array();
        $tabs = array();
        foreach ( $reports as $report ) {
            $existing = $sheets[ self::fold( $report['title'] ) ] ?? null;
            $values = $report['values'];
            $title = $existing['title'] ?? $report['title'];
            $columns = count( $values[0] );
            if ( null === $existing ) {
                $sheet_id = $next_id++;
                $requests[] = array(
                    'addSheet' => array(
                        'properties' => array(
                            'sheetId' => $sheet_id,
                            'title' => $title,
                            'gridProperties' => array(
                                'rowCount' => max( 1000, count( $values ) ),
                                'columnCount' => max( 26, $columns ),
                            ),
                        ),
                    ),
                );
                $before[] = array(
                    'title' => $title,
                    'exists' => false,
                );
            }
            else {
                $sheet_id = (int) $existing['sheetId'];
                if ( 'GRID' !== ( $existing['sheetType'] ?? 'GRID' ) ) {
                    return new \WP_Error( 'f3_google_export_sheet_type', 'A aba ' . $title . ' não é uma grade editável. Escolha outra aba.' );
                }
                $snapshot = self::snapshot( $id, $title, $columns );
                if ( is_wp_error( $snapshot ) ) {
                    return $snapshot;
                }
                $before[] = array(
                    'title' => $title,
                    'exists' => true,
                    'snapshot' => $snapshot,
                );
                if ( 'append' === $mode ) {
                    $header = ExecuteAction::call(
                        'sheets',
                        'sheets.spreadsheets.values.get',
                        array(
                            'spreadsheetId' => $id,
                            'range' => self::quote( $title ) . '!1:1',
                        ),
                        array( 'valueRenderOption' => 'UNFORMATTED_VALUE' ),
                        null,
                        array( 'mode' => 'read' )
                    );
                    if ( is_wp_error( $header ) ) {
                        return $header;
                    }
                    $current = $header['values'][0] ?? array();
                    if ( ! empty( $current ) ) {
                        if ( $current !== $values[0] ) {
                            return new \WP_Error( 'f3_google_export_header', 'O cabeçalho existente de ' . $title . ' não corresponde às colunas da consulta. Use replace ou uma nova aba; nenhuma linha foi anexada.' );
                        }
                        array_shift( $values );
                    }
                    else {
                        return new \WP_Error( 'f3_google_export_header', 'A aba existente ' . $title . ' está sem cabeçalho na primeira linha. Use replace para inicializá-la ou escolha uma nova aba; uma amostra vazia não prova que toda a aba esteja vazia.' );
                    }
                }
                $grid = $existing['gridProperties'] ?? array();
                if ( $columns > (int) ( $grid['columnCount'] ?? 0 ) || ( 'replace' === $mode && count( $values ) > (int) ( $grid['rowCount'] ?? 0 ) ) ) {
                    $requests[] = array(
                        'updateSheetProperties' => array(
                            'properties' => array(
                                'sheetId' => $sheet_id,
                                'gridProperties' => array(
                                    'rowCount' => max( (int) ( $grid['rowCount'] ?? 1000 ), count( $values ) ),
                                    'columnCount' => max( (int) ( $grid['columnCount'] ?? 26 ), $columns ),
                                ),
                            ),
                            'fields' => 'gridProperties.rowCount,gridProperties.columnCount',
                        ),
                    );
                }
            }
            if ( $values ) {
                $rows = count( $values ) === count( $report['values'] ) ? $report['cells'] : array_slice( $report['cells'], 1 );
                // ExtendedValue explícito é equivalente a RAW: nunca usar formulaValue.
                if ( 'replace' === $mode ) {
                    $requests[] = array(
                        'updateCells' => array(
                            'range' => array( 'sheetId' => $sheet_id ),
                            'rows' => $rows,
                            'fields' => 'userEnteredValue',
                        ),
                    );
                }
                else {
                    $requests[] = array(
                        'appendCells' => array(
                            'sheetId' => $sheet_id,
                            'rows' => $rows,
                            'fields' => 'userEnteredValue',
                        ),
                    );
                }
            }
            $tabs[] = array(
                'title' => $title,
                'sheet_id' => $sheet_id,
                'rows_exported' => count( $report['values'] ) - 1,
                'columns' => $columns,
                'header_written' => 'replace' === $mode || count( $values ) === count( $report['values'] ),
                'mode' => $mode,
                'source_accounts' => $report['table']['accounts'] ?? array(),
                'date_range' => $report['table']['date_range'] ?? null,
                'compare_date_range' => $report['table']['compare_date_range'] ?? null,
                'truncated' => ! empty( $report['table']['truncated'] ),
            );
        }
        return array(
            'requests' => $requests,
            'before' => $before,
            'tabs' => $tabs,
        );
    }
    /** Células de uma linha, com valores explícitos, sem inferência de fórmulas. */
    private static function cells( array $row ): array {
        $cells = array();
        foreach ( $row as $value ) {
            if ( null === $value ) {
                $cells[] = new \stdClass();
            }
            elseif ( is_bool( $value ) ) {
                $cells[] = array( 'userEnteredValue' => array( 'boolValue' => $value ) );
            }
            elseif ( is_int( $value ) || is_float( $value ) ) {
                // Inteiros fora da precisão de double são identificadores textuais.
                $key = is_int( $value ) && abs( $value ) > 9007199254740991 ? 'stringValue' : 'numberValue';
                $cells[] = array( 'userEnteredValue' => array( $key => 'stringValue' === $key ? (string) $value : $value ) );
            }
            else {
                $cells[] = array( 'userEnteredValue' => array( 'stringValue' => (string) $value ) );
            }
        }
        return array( 'values' => $cells );
    }
    /** @return array|\WP_Error */
    private static function metadata( string $id ) {
        return ExecuteAction::call( 'sheets', 'sheets.spreadsheets.get', array( 'spreadsheetId' => $id ), array( 'fields' => 'spreadsheetId,spreadsheetUrl,properties(title),sheets(properties)' ), null, array( 'mode' => 'read' ) );
    }
    /** A auditoria captura uma amostra explícita; não promete backup completo. @return array|\WP_Error */
    private static function snapshot( string $id, string $title, int $columns ) {
        $range = self::quote( $title ) . '!A1:' . self::column( min( 100, max( 1, $columns ) ) ) . '51';
        $data = ExecuteAction::call(
            'sheets',
            'sheets.spreadsheets.values.get',
            array(
                'spreadsheetId' => $id,
                'range' => $range,
            ),
            array( 'valueRenderOption' => 'FORMULA' ),
            null,
            array(
                'mode' => 'read',
                'retries' => 0,
            )
        );
        if ( is_wp_error( $data ) ) {
            return $data;
        }
        return array(
            'available' => true,
            'complete' => false,
            'range' => $range,
            'values' => $data['values'] ?? array(),
            'reason' => 'Amostra limitada a cabeçalho + 50 linhas e até 100 colunas; não é cópia de segurança.',
        );
    }
    /** Confirm exactly the exported rectangle; appendCells does not return its inserted range. */
    private static function verify(array $state,array $reports,string $mode): array {
        $tabs=[];
        foreach($reports as $report) {
            $expected=$report['values'];
            $columns=count($expected[0]);
            $cells=count($expected)*$columns;
            $v=['title'=>$report['title'],'expected_rows'=>count($expected),'expected_cells'=>$cells,'verified_rows'=>0,'verified_cells'=>0,'complete'=>false,'scope'=>$mode==='replace'?'exported_rectangle':'api_acknowledgement_only','clear_outside_rectangle_verified'=>false,'reason'=>null];
            if(Confirmation::capturing()){
                $v['reason']='preparation_only';
                $tabs[]=$v;
                continue;
            }
            if($mode==='append'){
                $v['reason']='append_cells_does_not_report_inserted_range';
                $tabs[]=$v;
                continue;
            }
            $size=max(1,min(1000,(int)floor(10000/$columns)));
            for($offset=0;$offset<count($expected);$offset+=$size) {
                if(\Fator3\McpGoogle\Automation\Execution::remaining()<1){
                    $v['reason']='verification_budget';
                    break;
                }
                $chunk=array_slice($expected,$offset,$size);
                $range=self::quote($report['title']).'!A'.($offset+1).':'.self::column($columns).($offset+count($chunk));
                $r=ExecuteAction::call('sheets','sheets.spreadsheets.values.get',['spreadsheetId'=>$state['spreadsheet_id'],'range'=>$range],['valueRenderOption'=>'UNFORMATTED_VALUE'],null,['mode'=>'read','retries'=>0]);
                if(is_wp_error($r)){
                    $v['reason']=$r->get_error_code();
                    break;
                }
                $actual=$r['values']??[];
                $matches=true;
                foreach($chunk as $i=>$row)foreach($row as $j=>$value) {
                    $seen=$actual[$i][$j]??null;
                    if(($value===null||$value==='')&&($seen===null||$seen===''))continue;
                    if(is_numeric($value)&&!is_string($value)&&is_numeric($seen)&&!is_string($seen)&&$value==$seen)continue;
                    if($value!==$seen){
                        $matches=false;
                        break 2;
                    }
                }
                if(!$matches){
                    $v['reason']='readback_mismatch';
                    break;
                }
                $v['verified_rows']+=count($chunk);
                $v['verified_cells']+=count($chunk)*$columns;
            }
            $v['complete']=$v['verified_cells']===$cells;
            $tabs[]=$v;
        }
        return ['complete'=>!in_array(false,array_column($tabs,'complete'),true),'scope'=>'exported_cells_only','tabs'=>$tabs,'transactional_flow'=>false];
    }
    private static function capture_after( array &$state ): void {
        if ( Confirmation::capturing() ) {
            return;
        }
        $after = array(
            'spreadsheet_id' => $state['spreadsheet_id'],
            'created' => $state['created'],
            'writes' => $state['writes'],
            'tabs' => array(),
            'shared_with' => $state['shared_with'],
        );
        foreach ( $state['tabs'] as $tab ) {
            $snapshot = self::snapshot( $state['spreadsheet_id'], $tab['title'], $tab['columns'] );
            if ( is_wp_error( $snapshot ) ) {
                $after['tabs'][] = array(
                    'title' => $tab['title'],
                    'available' => false,
                    'reason' => $snapshot->get_error_message(),
                );
                $state['warnings'][] = 'A gravação de ' . $tab['title'] . ' foi confirmada, mas a releitura para auditoria falhou.';
            }
            else {
                $after['tabs'][] = array(
                    'title' => $tab['title'],
                    'snapshot' => $snapshot,
                );
            }
        }
        Audit::after( $after );
    }
    private static function failure( \WP_Error $error, array $state, bool $uncertain = false, string $failed_operation = '' ): array {
        if ( ! empty( $state['writes'] ) && empty( $state['tabs'] ) ) {
            Audit::after(
                array(
                    'spreadsheet_id' => $state['spreadsheet_id'],
                    'created' => $state['created'],
                    'writes' => $state['writes'],
                    'available' => false,
                    'reason' => 'Etapa posterior falhou antes da releitura dos dados.',
                )
            );
        }
        $result = Response::fail(
            $error,
            $state + array(
                'partial' => ! empty( $state['writes'] ) || $uncertain,
                'outcome_uncertain' => $uncertain,
                'failed_operation' => $failed_operation,
                'spreadsheet_url' => '' !== $state['spreadsheet_id'] ? self::url( $state['spreadsheet_id'] ) : null,
                'retry_advice' => $uncertain ? 'Não repita automaticamente: confira a planilha/Drive. A API pode ter concluído a operação antes da falha de transporte.' : ( ! empty( $state['writes'] ) ? 'As operações em writes já ocorreram. Use o spreadsheet_id devolvido e repita apenas a etapa pendente; append pode duplicar linhas.' : 'Nenhuma gravação foi confirmada.' ),
            )
        );
        $outcome = $uncertain ? 'unknown' : ( $state['writes'] ? 'partial' : 'not_applied' );
        $result['failed_step_outcome'] = $result['operation_outcome'] ?? null;
        $result['operation_outcome'] = $outcome;
        $result['details'] = (array) $result['details'];
        $result['details']['operation_outcome'] = $outcome;
        unset( $result['details']['outcome'] );
        return $result;
    }
    private static function uncertain( \WP_Error $error ): bool {
        $data = $error->get_error_data();
        // A local refusal before dispatch has no HTTP status, but is not an uncertain write.
        if ( is_array( $data ) && ( isset( $data['operation_outcome'] ) || isset( $data['outcome'] ) ) ) {
            $normalized = \Fator3\McpGoogle\Operation::result(
                array(
                    'success' => false,
                    'details' => $data,
                ),
                'write'
            );
            return 'unknown' === $normalized['operation_outcome'];
        }
        $status = is_array( $data ) ? (int) ( $data['status'] ?? 0 ) : 0;
        return 0 === $status || $status >= 500;
    }
    private static function valid_id( string $id ): bool {
        return 1 === preg_match( '/^[A-Za-z0-9_-]{1,200}$/', $id );
    }
    private static function valid_title( string $title ): bool {
        $length = function_exists( 'mb_strlen' ) ? mb_strlen( $title, 'UTF-8' ) : strlen( $title );
        return '' !== trim( $title ) && $length <= 100 && ! preg_match( '~[\x00-\x1f:\\\\/?*\[\]]~', $title );
    }
    private static function fold( string $value ): string {
        return function_exists( 'mb_strtolower' ) ? mb_strtolower( $value, 'UTF-8' ) : strtolower( $value );
    }
    private static function quote( string $title ): string {
        return "'" . str_replace( "'", "''", $title ) . "'";
    }
    private static function column( int $number ): string {
        $name = '';
        do {
            --$number;
            $name = chr( 65 + $number % 26 ) . $name;
            $number = intdiv( $number, 26 );
        }
        while ( $number > 0 );
        return $name;
    }
    private static function url( string $id ): string {
        return 'https://docs.google.com/spreadsheets/d/' . rawurlencode( $id ) . '/edit';
    }
}
