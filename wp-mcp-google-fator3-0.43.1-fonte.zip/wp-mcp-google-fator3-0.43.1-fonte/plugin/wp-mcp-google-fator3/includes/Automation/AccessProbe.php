<?php
/** Confirm access with a bounded read of the affected resource or an authorized validation. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\Ads\{AdsApi, DataManager};
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\{ConversionDelivery, Http\GoogleClient};
defined('ABSPATH') || exit;

final class AccessProbe {
    public static function succeeds(array $member, string $scope): bool {
        $url = $member['url'];
        $method = $member['method'];
        if (!GoogleClient::assert_allowed_host($url)) return false;
        $operation = $member['operation_id'] ?? '';
        $connector = $member['connector'] ?? '';
        $opts = ['mode'=>'read', 'retries'=>0, 'timeout'=>5, 'budget_seconds'=>7, 'require_json_object'=>true];
        $body = null;
        $proof = null;

        if ($method === 'POST' && preg_match('~^https://analyticsdata\.googleapis\.com/v1(?:beta|alpha)?/properties/[0-9]+:runReport$~D', $url)) {
            $connector = 'ga';
            $operation = 'analyticsdata.properties.runReport';
            $body = ['dateRanges'=>[['startDate'=>'yesterday','endDate'=>'yesterday']], 'metrics'=>[['name'=>'activeUsers']], 'limit'=>'1'];
            $proof = 'metricHeaders';
        } elseif ($method === 'POST' && preg_match('~^https://(?:www|searchconsole)\.googleapis\.com/webmasters/v3/sites/[^/]+/searchAnalytics/query$~D', $url)) {
            $connector = 'gsc';
            $operation = 'webmasters.searchanalytics.query';
            $day = gmdate('Y-m-d', time()-3*DAY_IN_SECONDS);
            $body = ['startDate'=>$day, 'endDate'=>$day, 'rowLimit'=>1];
            $proof = 'searchAnalytics';
        } elseif ($method === 'POST' && $url === GoogleClient::HOST_GSC.'/v1/urlInspection/index:inspect') {
            $site = $member['site_url'] ?? '';
            if ($site === '') return false;
            $inspection = str_starts_with($site,'sc-domain:') ? 'https://'.substr($site,10).'/' : $site;
            $connector = 'gsc';
            $operation = 'searchconsole.urlInspection.index.inspect';
            $body = ['siteUrl'=>$site, 'inspectionUrl'=>$inspection];
            $proof = 'inspectionResult';
        } elseif ($method === 'POST' && preg_match('~^https://googleads\.googleapis\.com/v[0-9]+/customers/([0-9]{10})/googleAds:search$~D', $url, $customer)) {
            $connector = 'ads';
            $operation = 'googleads.customers.googleAds.search';
            $opts['headers'] = AdsApi::headers($member['login_customer_id'] ?? '');
            $body = ['query'=>'SELECT customer.id FROM customer LIMIT 1'];
            $proof = 'customer';
        } elseif ($method === 'POST' && $url === DataManager::BASE.'/events:ingest') {
            $config = Context::conversion_probe_config($scope);
            return $config !== null && !empty(DataManager::verify($config, str_starts_with($scope,'stage:'), false)['ok']);
        } elseif ($method === 'POST' && $url === GoogleClient::HOST_MP.'/debug/mp/collect' && str_starts_with($scope,'conversion:ga4:')) {
            return ConversionDelivery::debug_access_probe(substr($scope, strlen('conversion:ga4:')));
        } elseif ($method === 'GET') {
            $read = self::read_options($url);
            if (!$read) return false;
            [$connector,$opts['query'],$proof] = $read;
            if ($connector === 'ads') $opts['headers'] = AdsApi::headers($member['login_customer_id'] ?? '');
        } else {
            // A different capability cannot prove that a failed mutation recovered.
            return false;
        }

        $opts['operation_id'] = $operation;
        $opts['connector'] = $connector;
        $opts['scopes'] = Credentials::scopes_for($connector);
        $result = GoogleClient::request($method, $url, $body, $opts);
        if (!is_array($result) || isset($result['error']) || isset($result['content_base64'])) return false;
        if ($proof === 'customer') return (string)($result['results'][0]['customer']['id'] ?? '') === $customer[1];
        if ($proof === 'searchAnalytics') return !$result || is_array($result['rows'] ?? null) || is_string($result['responseAggregationType'] ?? null);
        if ($proof === 'list') return true;
        if ($proof === 'get') return (bool)$result;
        return is_array($result[$proof] ?? null);
    }

    /** Preflight and API metadata reads. Always project a small static set of fields when available. */
    private static function read_options(string $url): ?array {
        if ($url === GoogleClient::HOST_GA_ADMIN.'/v1beta/accountSummaries') return ['ga',['pageSize'=>1,'fields'=>'accountSummaries(account)'],'list'];
        if (preg_match('~^https://analyticsadmin\.googleapis\.com/v1(?:alpha|beta)?/(?:accounts|properties)/[0-9]+(?:/[A-Za-z0-9_/.-]+)?$~D',$url)) {
            $leaf = basename($url);
            $fields = in_array($leaf, ['accessBindings','dataStreams','measurementProtocolSecrets'],true) ? $leaf.'(name)' : 'name';
            return ['ga',['fields'=>$fields],$fields === 'name' ? 'get' : 'list'];
        }
        if (preg_match('~^https://(?:www|searchconsole)\.googleapis\.com/webmasters/v3/sites(?:/[^?#]+)?$~D',$url)) {
            $list = str_ends_with($url, '/sites') || str_ends_with($url, '/sitemaps');
            return ['gsc',[], $list ? 'list' : 'get'];
        }
        if ($url === GoogleClient::HOST_GOOGLE.'/siteVerification/v1/webResource') return ['siteverification',['fields'=>'items(id)'],'list'];
        if (preg_match('~^https://sheets\.googleapis\.com/v4/spreadsheets/[A-Za-z0-9_-]+$~D',$url)) return ['sheets',['fields'=>'spreadsheetId'],'get'];
        if ($url === GoogleClient::HOST_GOOGLE.'/drive/v3/files') return ['drive',['pageSize'=>1,'fields'=>'files(id)'],'list'];
        if (preg_match('~^https://www\.googleapis\.com/drive/v3/files/[A-Za-z0-9_-]+$~D',$url)) return ['drive',['fields'=>'id','supportsAllDrives'=>true],'get'];
        if ($url === GoogleClient::HOST_GTM.'/tagmanager/v2/accounts') return ['gtm',['fields'=>'account(path)'],'list'];
        if (preg_match('~^https://tagmanager\.googleapis\.com/tagmanager/v2/accounts/[0-9]+/containers/[0-9]+$~D',$url)) return ['gtm',['fields'=>'path'],'get'];
        if (preg_match('~^https://googleads\.googleapis\.com/v[0-9]+/customers:listAccessibleCustomers$~D',$url)) return ['ads',[], 'list'];
        return null;
    }
}
