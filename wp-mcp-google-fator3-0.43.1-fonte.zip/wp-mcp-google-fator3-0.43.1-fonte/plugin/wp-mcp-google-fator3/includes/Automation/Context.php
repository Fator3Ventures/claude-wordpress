<?php
/**
 * A queued operation never acquires new defaults or another identity silently.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{Auth\Credentials, Connections, Options, Settings};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Context {

    public static function access_scope(): string {
        return Execution::access_scope();
    }

    public static function schedule_scope(array $schedule): string {
        $revision = Jobs::schedule_revision($schedule);
        if ($schedule['task'] === 'preflight') {
            // Preflight can follow a mutable connection default instead of storing a fixed account.
            $bindings = $schedule['parameters']['bindings'] ?? Options::get(Connections::BINDINGS, []);
            $revision = FrozenInput::hash([$revision, $bindings, $bindings['ga_property_id'] ?? Options::get(Options::GA_DEFAULT_PROPERTY, '')]);
        }
        return 'schedule:'.$schedule['id'].':'.$revision;
    }

    public static function job_scope(array $job): string {
        $scope = $job['access_scope'] ?? '';
        if (!array_key_exists('access_scope', $job) && in_array($job['task'] ?? '', ['report','query','preflight'], true)) {
            // Older jobs have no provenance marker. Only the scheduler's own durable back-reference qualifies.
            foreach (\Fator3\McpGoogle\Records::list('schedule', 100) as $schedule) {
                if (isset($schedule['last_job_id']) && $schedule['last_job_id'] === $job['id']) {
                    $scope = self::schedule_scope($schedule);
                    break;
                }
            }
        }
        return is_string($scope) && $scope !== '' && self::can_recheck($scope, '') ? $scope : '';
    }

    /** Only the already bound Ads destination is exposed to the validate-only recheck. */
    public static function conversion_probe_config(string $scope): ?array {
        $parts = explode(':', $scope);
        if (count($parts) !== 3 || !Options::is_enabled() || \Fator3\McpGoogle\Recovery::guard()) {
            return null;
        }
        [$type, $id, $revision] = $parts;
        if ($type === 'stage') {
            return \Fator3\McpGoogle\StageConversionDelivery::probe_destination($id, $revision);
        }
        if ($type === 'conversion' && $id === 'google_ads') {
            return \Fator3\McpGoogle\ConversionDelivery::probe_destination($id, $revision);
        }
        return null;
    }

    /** Revalidate the owner, grant and revision inside the same connection before each probe. */
    public static function can_recheck(string $scope, string $resource): bool {
        if (!Options::is_enabled() || \Fator3\McpGoogle\Recovery::guard()) {
            return false;
        }
        $parts = explode(':', $scope);
        if (count($parts) === 4 && $parts[0] === 'reader') {
            $readers = [
                \Fator3\McpGoogle\Integration\ServiceApi::CONTRACT => \Fator3\McpGoogle\Integration\ServiceApi::class,
                \Fator3\McpGoogle\Integration\QueryServiceApi::CONTRACT => \Fator3\McpGoogle\Integration\QueryServiceApi::class,
                \Fator3\McpGoogle\Integration\Ga4ServiceApi::CONTRACT => \Fator3\McpGoogle\Integration\Ga4ServiceApi::class,
            ];
            $reader = $readers[$parts[1]] ?? null;
            return $reader && $reader::can_recheck($parts[2], $scope, $resource);
        }
        if (count($parts) !== 3) {
            return false;
        }
        [$type, $id, $revision] = $parts;
        if ($type === 'conversion') {
            return \Fator3\McpGoogle\ConversionDelivery::probe_destination($id, $revision) !== null;
        }
        if ($type === 'stage') {
            return \Fator3\McpGoogle\StageConversionDelivery::probe_destination($id, $revision) !== null;
        }
        if (!in_array($type, ['schedule','ads-archive'], true) || !ExecutorSchedule::active()) {
            return false;
        }
        if ($type === 'ads-archive') {
            $all = \Fator3\McpGoogle\Ads\Archive::config();
            $cfg = is_array($all) ? ($all[$id] ?? null) : null;
            return is_array($cfg) && ($cfg['revision'] ?? null) === $revision
                && !\Fator3\McpGoogle\Ads\Archive::guard($id, $cfg);
        }
        $schedule = \Fator3\McpGoogle\Records::get('schedule', $id);
        return is_array($schedule) && !empty($schedule['enabled']) && empty($schedule['blocked_reason'])
            && ($schedule['connection_id'] ?? null) === Connections::id()
            && \Fator3\McpGoogle\SiteAuthority::authorized((int) ($schedule['user_id'] ?? 0))
            && isset($schedule['context']) && !self::validate($schedule['context'])
            && hash_equals(self::schedule_scope($schedule), $scope);
    }

	public static function capture(bool $site_schedule = false) {
		$revision = Settings::execution_revision();
		if ( is_wp_error( $revision ) ) {
			return $revision;
		}
		return array(
			'schema_version'      => '2.0.0',
			'site'                => home_url(),
			'connection_id'       => Connections::id(),
			'actor'               => get_current_user_id(),
			'identity'            => Credentials::execution_identity(),
			'revision'            => $revision,
			'bindings'            => (array) Options::get( Connections::BINDINGS, array() ),
			'ga_default_property' => Options::get( Options::GA_DEFAULT_PROPERTY, '' ),
			'services'            => Options::get( Connections::SERVICES, null ),
			'captured_at'         => time(),
            'channel_principal' => null,
            'authority' => 'wordpress',
		);
	}
	public static function validate( array $context ): ?\WP_Error {
		$revision = Settings::execution_revision();
		if ( is_wp_error( $revision ) ) {
			return $revision;
		}
		if ( ( $context['site'] ?? null ) !== home_url() || ( $context['connection_id'] ?? null ) !== Connections::id() || ( $context['identity'] ?? null ) !== Credentials::execution_identity() || ( $context['revision'] ?? null ) !== $revision ) {
			return new \WP_Error(
				'f3_google_job_context_changed',
				'Identidade ou política mudaram. Revise a tarefa antes de criar outra intenção.',
				array(
					'operation_outcome' => 'not_applied',
					'retryable'         => false,
				)
			);
		}
        return null;
	}
}
