<?php
/** Access incidents belong to the scheduled principal and binding that attempted the operation. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{Cache, Confirmation, Connections, Lock, Records};
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Storage\Repository;

defined('ABSPATH') || exit;

final class AccessIncidents {
    private const TASK = 'access_check';
    private const PAGE = 32;
    private const RETRY_SECONDS = 60;

    /** Only called for authenticated scheduled work. The request body and credentials are never stored. */
    public static function observe(string $method, string $resource, int $http, string $scope, array $opts = []): void {
        if ($scope === '' || Confirmation::capturing()) return;
        $url = explode('?', $resource, 2)[0];
        if (strlen($url) > 2048 || !GoogleClient::assert_allowed_host($url)) return;
        $identity = Credentials::execution_identity();
        $family = GoogleClient::service_for($url);
        if (in_array($family, ['analytics-admin', 'analytics-data'], true)) $family = 'analytics';
        $manager = $family === 'google-ads' && preg_match('/^[0-9]{10}$/D', $opts['login_customer_id'] ?? '') ? $opts['login_customer_id'] : '';
        $group = Connections::id().'|access|'.$identity.'|'.$scope.'|'.$family;
        $id = hash('sha256', $manager === '' ? $group : $group.'|'.$manager);
        $denied = in_array($http, [401,403], true);
        $positive = $http >= 200 && $http < 300;
        $site = (string)($opts['site_url'] ?? '');
        $member = hash('sha256', $method.'|'.$url.'|'.$site);
        $resource = self::display_resource($url);
        $probe_site = $site !== '' && !self::private_path($site) && !is_wp_error(\Fator3\McpGoogle\SearchConsole\Api::site($site));
        $old = Records::get('incident', $id);
        if (!$denied && (($old['status'] ?? '') !== 'open' || !isset($old['context']['members'][$member]))) {
            if ($positive) self::retire_legacy($url);
            return;
        }
        $lock = Lock::acquire('incident:'.$id, 30);
        if ($lock === null) return;
        try {
            $old = Records::get('incident', $id);
            $open = ($old['status'] ?? '') === 'open';
            if (!$denied && (!$open || !isset($old['context']['members'][$member]))) return;
            $now = time();
            $policy = Alerts::access_policy();
            $row = $old ?? ['id'=>$id, 'connection_id'=>Connections::id(), 'event'=>'access', 'resource'=>$resource,
                'generation'=>0, 'notification_transport'=>'core/incident-v1'];
            if (!$open) {
                $row['created_at'] = $now;
                $row['context'] = ['scope'=>$scope, 'principal'=>$identity, 'members'=>[],
                    'last_used_at'=>$now, 'next_check_at'=>$now+$policy['recheck_seconds']];
                unset($row['resolution_reason'], $row['notify_recovery']);
            }
            $ctx = &$row['context'];
            $ctx['last_used_at'] = $now;
            if ($positive) {
                unset($ctx['members'][$member]);
            } else {
                $entry = ['method'=>$method, 'url'=>$resource, 'last_used_at'=>$now,
                    'connector'=>(string)($opts['connector'] ?? ''), 'operation_id'=>(string)($opts['operation_id'] ?? '')];
                if ($probe_site) $entry['site_url'] = $site;
                if ($manager !== '') $entry['login_customer_id'] = $manager;
                $ctx['members'][$member] = $entry;
            }
            if ($denied) $row['code'] = 'http_'.$http;
            if ($ctx['members']) {
                self::schedule($row, $policy);
                $saved = self::save($row, !$open);
            } else {
                self::finish($row, 'resolved', 'acesso_restaurado');
            }
        } finally {
            Lock::release($lock);
        }
        // Retire an old per-URL incident only after the current flow has positively identified it.
        if ($denied && !empty($saved)) self::retire_legacy($url, $id);
        elseif ($positive) self::retire_legacy($url);
    }

    /** A path segment may itself contain a URL with credentials, a query or a fragment. */
    private static function private_path(string $value): bool {
        for ($depth = 0; $depth < 5; ++$depth) {
            if (strpbrk($value, '?#@') !== false || preg_match('/[\x00-\x1f]/', $value)) return true;
            $decoded = rawurldecode($value);
            if ($decoded === $value) return false;
            $value = $decoded;
        }
        return true;
    }

    private static function display_resource(string $url): string {
        if (!self::private_path($url)) return $url;
        return 'recurso-privado/'.substr(hash('sha256', $url), 0, 24);
    }

    private static function schedule(array &$row, array $policy): void {
        $ctx = $row['context'];
        $row['status'] = 'open';
        $row['action'] = 'O executor reavalia a permissão da agenda e a atividade de cada recurso.';
        $row['task'] = self::TASK;
        $earliest = min(array_column($ctx['members'], 'last_used_at'));
        $row['run_after'] = min($ctx['next_check_at'], $earliest+$policy['unused_seconds']);
    }

    /** Save before publishing. Dispatch independently retries the durable state. */
    private static function save(array &$row, bool $publish): bool {
        if ($publish) $row['generation'] = (int)($row['generation'] ?? 0)+1;
        $row['access_revision'] = (int)($row['access_revision'] ?? 0) + 1;
        $row['updated_at'] = time();
        $row['email_state'] = 'delegated';
        if ($publish) $row['access_notice_pending'] = true;
        if (!empty($row['access_notice_pending'])) {
            $row['task'] = self::TASK;
            $row['run_after'] = $row['status'] === 'open' ? min(time(), $row['run_after']) : time();
        }
        $saved = Records::put('incident', $row['id'], $row);
        if (empty($saved['success'])) return false;
        if (!empty($row['access_notice_pending'])) self::deliver_notice($row);
        return true;
    }

    /** A persisted outbox entry survives a busy Core or an unavailable silent-closure contract. */
    private static function deliver_notice(array &$row): void {
        $result = Alerts::publish_incident($row);
        $notice_id = hash('sha256', Connections::id().'|integracao_indisponivel|'.$row['id']);
        $notice = Records::get('technicalnotice', $notice_id);
        $durable = !empty($result['ok']) || ($notice['event']['geracao_acesso'] ?? 0) >= $row['generation'];
        $row['access_notice_pending'] = !$durable;
        if ($row['status'] === 'open') {
            self::schedule($row, Alerts::access_policy());
            if (!$durable) $row['run_after'] = min($row['run_after'], time()+self::RETRY_SECONDS);
        } else {
            $row['task'] = $durable ? 'access_closed' : self::TASK;
            $row['run_after'] = $durable ? 0 : time()+self::RETRY_SECONDS;
        }
        Records::put('incident', $row['id'], $row);
    }

    private static function finish(array &$row, string $state, string $reason): void {
        $row['status'] = $state;
        $row['resolution_reason'] = $reason;
        $row['notify_recovery'] = $state === 'resolved';
        $row['code'] = $reason;
        $row['action'] = $state === 'resolved' ? 'A leitura operacional confirmou o acesso.' : 'Episódio encerrado na revisão das agendas.';
        $row['task'] = 'access_closed';
        $row['run_after'] = 0;
        self::save($row, true);
    }

    private static function retire_legacy(string $resource, ?string $successor = null): void {
        $id = hash('sha256', Connections::id().'|access|'.$resource);
        $old = Records::get('incident', $id);
        if (($old['status'] ?? '') !== 'open' || isset($old['context']['scope'])) return;
        $lock = Lock::acquire('incident:'.$id, 30);
        if ($lock === null) return;
        try {
            $old = Records::get('incident', $id);
            if (($old['status'] ?? '') !== 'open' || isset($old['context']['scope'])) return;
            $old['resource'] = self::display_resource($resource);
            if ($successor !== null) $old['superseded_by'] = $successor;
            else $old['reconciled_by_scheduled_use'] = true;
            self::finish($old, 'consolidado', 'consolidado');
        } finally { Lock::release($lock); }
    }

    /** Visit earlier versions' rows incrementally, even behind unrelated incidents. Never invent a scheduled origin. */
    public static function migrate(array $policy): void {
        $key = 'f3_mcp_google_access_scan_'.Connections::id();
        $cursor = (int) Cache::get($key);
        $filter = ['connection_id'=>Connections::id(), 'state'=>'open', 'sequence_after'=>$cursor];
        $rows = Repository::select('incident', $filter, self::PAGE, 0, false);
        if (is_wp_error($rows)) return;
        foreach ($rows as $meta) {
            $id = $meta['record_id'];
            if (($meta['task'] ?? '') === self::TASK) continue;
            $row = Records::get('incident', $id);
            if (($row['event'] ?? '') !== 'access' || isset($row['context']['scope'])) continue;
            $lock = Lock::acquire('incident:'.$id, 30);
            if ($lock === null) continue;
            try {
                $row = Records::get('incident', $id);
                if (($row['status'] ?? '') !== 'open' || ($row['task'] ?? '') === self::TASK) continue;
                $row['resource'] = self::display_resource($row['resource']);
                $last = (int)($row['updated_at'] ?? $row['created_at']);
                $row['context']['last_used_at'] = $last;
                $row['context']['next_check_at'] = $last+$policy['unused_seconds'];
                if ($last+$policy['unused_seconds'] <= time()) {
                    self::finish($row, 'nao_usado', 'nao_usado');
                } else {
                    $row['task'] = self::TASK;
                    $row['run_after'] = $row['context']['next_check_at'];
                    self::save($row, false);
                }
            } finally { Lock::release($lock); }
        }
        $next = count($rows) === self::PAGE ? (int)end($rows)['sequence'] : 0;
        if ($next !== $cursor) Cache::set($key, $next, DAY_IN_SECONDS);
    }

    public static function tick(): void {
        if (Confirmation::capturing()) return;
        $policy = Alerts::access_policy();
        self::migrate($policy);
        $rows = Repository::select('incident', ['connection_id'=>Connections::id(),
            'task'=>self::TASK, 'due_before'=>time()], self::PAGE, 0, false);
        if (is_wp_error($rows)) return;
        foreach ($rows as $meta) {
            if (Execution::remaining()<2) break;
            self::check($meta['record_id'], $policy);
        }
    }

    private static function check(string $id, array $policy): void {
        $lock = Lock::acquire('access-probe:'.$id, 60);
        if ($lock === null) return;
        try {
            $row = Records::get('incident', $id);
            if (!$row || $row['run_after']>time()) return;
            if (!empty($row['access_notice_pending'])) {
                $guard = Lock::acquire('incident:'.$id, 30);
                if ($guard === null) return;
                try {
                    $row = Records::get('incident', $id);
                    if (!empty($row['access_notice_pending'])) self::deliver_notice($row);
                } finally { Lock::release($guard); }
            }
            if (($row['status'] ?? '') !== 'open' || $row['run_after']>time()) return;
            $ctx = $row['context'];
            $revision = (int)($row['access_revision'] ?? 0);
            $unused = [];
            $passed = [];
            $inspected = [];
            $now = time();
            $legacy = !isset($ctx['scope']);
            if (!$legacy) {
                $current_identity = Credentials::execution_identity() === $ctx['principal'];
                foreach ($ctx['members'] as $key=>$entry) {
                    if ($entry['last_used_at']+$policy['unused_seconds'] <= $now) {
                        $unused[] = $key;
                    } elseif ($ctx['next_check_at'] <= $now && $current_identity && Execution::remaining() >= 2) {
                        if (($entry['check_after'] ?? 0) > $now) continue;
                        $inspected[] = $key;
                        if (Context::can_recheck($ctx['scope'], $entry['url'])
                            && Execution::run(static fn()=>AccessProbe::succeeds($entry, $ctx['scope']), 14, null, '')
                            && Context::can_recheck($ctx['scope'], $entry['url'])) $passed[] = $key;
                    }
                }
            }
            // A network probe can overlap a scheduled use; never apply stale evidence.
            $guard = Lock::acquire('incident:'.$id, 30);
            if ($guard === null) return;
            try {
                $row = Records::get('incident', $id);
                if (($row['status'] ?? '') !== 'open' || (int)($row['access_revision'] ?? 0) !== $revision) return;
                if ($legacy) {
                    if ($ctx['last_used_at']+$policy['unused_seconds'] <= $now) self::finish($row,'nao_usado','nao_usado');
                    return;
                }
                $ctx = &$row['context'];
                foreach ($inspected as $key) $ctx['members'][$key]['check_after'] = $now+$policy['recheck_seconds'];
                foreach (array_merge($unused,$passed) as $key) unset($ctx['members'][$key]);
                if (!$ctx['members']) {
                    if ($unused) self::finish($row,'nao_usado','nao_usado');
                    else self::finish($row,'resolved','acesso_restaurado');
                } else {
                    $due = [];
                    foreach ($ctx['members'] as $entry) $due[]=$entry['check_after'] ?? $ctx['next_check_at'];
                    $ctx['next_check_at'] = $current_identity ? min($due) : $now+$policy['recheck_seconds'];
                    self::schedule($row,$policy);
                    self::save($row,false);
                }
            } finally { Lock::release($guard); }
        } finally { Lock::release($lock); }
    }
}
