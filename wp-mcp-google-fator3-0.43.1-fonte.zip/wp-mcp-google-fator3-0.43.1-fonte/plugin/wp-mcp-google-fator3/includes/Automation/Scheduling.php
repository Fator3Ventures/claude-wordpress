<?php
/** Confirms only Google's WordPress events. Never dispatches callbacks as a repair. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Options,Lock,Recovery,Records
};
use Fator3\McpGoogle\Storage\{
    Maintenance
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Scheduling {
    public const OPTION='f3_mcp_google_cron_scheduling';
    private const HOOKS=[Jobs::HOOK,Maintenance::HOOK];
    private static array $context=[];
    private static array $volatile=[];
    private static function site(): int {
        return function_exists('get_current_blog_id')?get_current_blog_id():1;
    }
    private static function key(string $hook,array $args): string {
        return self::site().'|'.$hook.'|'.md5(serialize($args));
    }
    private static function intent(string $op,string $hook,?int $at,array $args=[],$recurrence=false,int $interval=0): array {
        return ['operation'=>$op,'hook'=>$hook,'target_at'=>$at,'args_key'=>md5(serialize($args)),'args_digest'=>hash('sha256',serialize($args)),
            'recurrence'=>$recurrence?:null,'interval'=>$interval,'origem'=>CronHistory::origin()];
    }
    public static function init(): void {
        add_filter('pre_reschedule_event',static function($pre,$event) {
            if (in_array($event->hook,self::HOOKS,true)) self::$context[self::key($event->hook,$event->args)]['reschedule']=self::intent('reschedule',$event->hook,null,$event->args,$event->schedule,(int)$event->interval);
            return $pre;
            },PHP_INT_MAX,2);
        // WordPress computes the actual future timestamp before calling this filter.
        add_filter('pre_schedule_event',static function($pre,$event) {
            $key=self::key($event->hook,$event->args);
            if (in_array($event->hook,self::HOOKS,true) && isset(self::$context[$key]['reschedule'])) self::$context[$key]['reschedule']=self::intent('reschedule',$event->hook,(int)$event->timestamp,$event->args,$event->schedule,(int)($event->interval??0));
            return $pre;
            },PHP_INT_MAX,2);
        add_filter('pre_unschedule_event',static function($pre,$at,$hook,$args) {
            if (in_array($hook,self::HOOKS,true)) self::$context[self::key($hook,$args)]['unschedule']=self::intent('unschedule',$hook,(int)$at,$args);
            return $pre;
            },PHP_INT_MAX,4);
        foreach (['cron_reschedule_event_error'=>'reschedule','cron_unschedule_event_error'=>'unschedule'] as $hook=>$op) add_action($hook,static function($error,$name,$data) use($op) {
            if (!in_array($name,self::HOOKS,true)) return;
            $key=self::key($name,$data['args']??[]);
            $intent=self::$context[$key][$op]??self::intent($op,$name,null,$data['args']??[],$data['schedule']??false,(int)($data['interval']??0));
            unset(self::$context[$key][$op]);
            self::observe($intent,$error);
            },10,3);
    }
    public static function schedule(string $hook,int $at,$recurrence=false,array $args=[]): array {
        if (!in_array($hook,self::HOOKS,true)) return ['success'=>false,'error_code'=>'f3_google_cron_hook'];
        return Recovery::run(static function() use($hook,$at,$recurrence,$args) {
            $schedules=function_exists('wp_get_schedules')?wp_get_schedules():[];
            $intent=self::intent('schedule',$hook,$at,$args,$recurrence,(int)($schedules[$recurrence]['interval']??0));
            $result=$recurrence?wp_schedule_event($at,$recurrence,$hook,$args,true):wp_schedule_single_event($at,$hook,$args,true);
            return self::observe($intent,$result);
            });
    }
    public static function clear(string $hook,array $args=[]): array {
        if (!in_array($hook,self::HOOKS,true)) return ['success'=>false,'error_code'=>'f3_google_cron_hook'];
        return Recovery::run(static fn()=>self::observe(self::intent('clear',$hook,null,$args),wp_clear_scheduled_hook($hook,$args,true)));
    }
    /** Fresh persisted state plus the view the active WordPress scheduler will read. */
    private static function read(): array {
        return self::read_current(self::HOOKS);
    }
    public static function read_current(array $hooks): array {
        $stored=Options::stored('cron');
        if (!$stored['success'] || ($stored['exists']&&!is_array($stored['value']))) return ['success'=>false,'code'=>'f3_google_cron_schedule_read'];
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete('cron','options');
            wp_cache_delete('alloptions','options');
            wp_cache_delete('notoptions','options');
        }
        // _get_cron_array() may upgrade old arrays by writing; status must never do that.
        $effective=get_option('cron',[]);
        if (!is_array($effective)) return ['success'=>false,'code'=>'f3_google_cron_schedule_view'];
        $direct=$stored['value']??[];
        if(($stored['exists']&&($direct['version']??null)!==2)||($effective&&($effective['version']??null)!==2)) return ['success'=>false,'code'=>'f3_google_cron_schedule_format'];
        unset($direct['version'],$effective['version']);
        // Compare only owned events: foreign events may legitimately move between reads.
        $select=static function($cron) use($hooks) {
            $out=[];
            foreach($cron as $at=>$events) {
                if (!is_array($events)) {
                    $out[$at]=['invalid'=>$events];
                    continue;
                }
                foreach($hooks as $hook) if(array_key_exists($hook,$events)) {
                    $rows=$events[$hook];
                    if(is_array($rows)) {
                        ksort($rows);
                        foreach($rows as &$row) if(is_array($row)) ksort($row);
                        unset($row);
                    }
                    $out[$at][$hook]=$rows;
                }
            }
            ksort($out);
            return $out;
        };
        if ($select($direct)!==$select($effective)) return ['success'=>false,'code'=>'f3_google_cron_schedule_view'];
        foreach($direct as $events) if(!is_array($events)) return ['success'=>false,'code'=>'f3_google_cron_schedule_read'];
        return ['success'=>true,'cron'=>$direct];
    }
    private static function proof(array $intent,array $cron): ?bool {
        $op=$intent['operation'];
        $at=$intent['target_at'];
        $hook=$intent['hook'];
        $key=$intent['args_key'];
        if ($op==='clear') {
            foreach ($cron as $events) if (is_array($events)&&isset($events[$hook][$key])) return false;
            return true;
        }
        if ($at===null) return null;
        $event=$cron[$at][$hook][$key]??null;
        if ($op==='unschedule') return $event===null;
        if (!$event && $op==='reschedule' && $intent['interval']>0) {
            foreach ($cron as $later=>$events) {
                if (!is_numeric($later) || (int)$later<$at || (((int)$later-$at)%$intent['interval'])!==0) continue;
                $candidate=$events[$hook][$key]??null;
                if (is_array($candidate) && ($candidate['schedule']??null)===$intent['recurrence'] && (int)($candidate['interval']??0)===$intent['interval'] && hash_equals($intent['args_digest'],hash('sha256',serialize($candidate['args']??null)))) return true;
            }
        }
        if (!$event) return false;
        return is_array($event) && hash_equals($intent['args_digest'],hash('sha256',serialize($event['args']??null)))
        && (($event['schedule']??false)?:null)===$intent['recurrence']
        && (!$intent['recurrence'] || (int)($event['interval']??0)===$intent['interval']);
    }
    /** A single event refused as duplicate_event (and only such a refusal) is resolved by its pending equivalent. */
    private static function duplicate_refusal(array $intent,?string $code): bool {
        return $intent['operation']==='schedule' && $intent['recurrence']===null && $intent['target_at']!==null && $code==='duplicate_event';
    }
    /** Timestamp of an event with the same hook and arguments inside WordPress' duplicate window, else null. */
    private static function equivalent(array $intent,array $cron,int $now): ?int {
        $at=(int)$intent['target_at'];
        // Same bounds as wp_schedule_single_event() in wp-includes/cron.php.
        $min=$at<$now+600?0:$at-600;
        $max=$at<$now?$now+600:$at+600;
        foreach ($cron as $when=>$events) {
            if (!is_numeric($when)||(int)$when<$min||(int)$when>$max||!is_array($events)) continue;
            $candidate=$events[$intent['hook']][$intent['args_key']]??null;
            if (is_array($candidate) && hash_equals($intent['args_digest'],hash('sha256',serialize($candidate['args']??null)))) return (int)$when;
        }
        return null;
    }
    /** Earliest pending occurrence (any timestamp) with the same hook and arguments, else null. */
    private static function pending(array $intent,array $cron): ?int {
        $found=null;
        foreach ($cron as $when=>$events) {
            if (!is_numeric($when)||!is_array($events)) continue;
            $candidate=$events[$intent['hook']][$intent['args_key']]??null;
            if (is_array($candidate) && hash_equals($intent['args_digest'],hash('sha256',serialize($candidate['args']??null))) && ($found===null||(int)$when<$found)) $found=(int)$when;
        }
        return $found;
    }
    private static function check(array $intent,$api): array {
        $read=self::read();
        $proof=$read['success']?self::proof($intent,$read['cron']):null;
        $warning=is_wp_error($api)?$api->get_error_code():($api===false?'api_returned_false':null);
        $equivalent=$proof===false&&self::duplicate_refusal($intent,$warning)?self::equivalent($intent,$read['cron'],time()):null;
        if ($equivalent!==null) $proof=true;
        $state=$proof===true?'confirmed':($proof===false?'failed':'unconfirmed');
        return $intent+['id'=>Records::id(),'at'=>time(),'success'=>$proof===true,'state'=>$state,'read_success'=>$read['success'],
            'postcondition'=>$proof,'original_code'=>$warning,'api_success'=>!is_wp_error($api)&&$api!==false,
            'error_code'=>$proof===true?null:($read['code']??($proof===null?'f3_google_cron_schedule_context':'f3_google_cron_schedule_postcondition')),
            'diagnostic_persisted'=>false,'diagnostic_error_code'=>null]+($equivalent!==null?['equivalent_at'=>$equivalent]:[]);
    }
    private static function observe(array $intent,$api): array {
        return Recovery::run(static function() use($intent,$api) {
            $lock=Lock::acquire_result('cron-scheduling',30);
            if (!$lock['success']) {
                $result=self::check($intent,$api);
                $result['diagnostic_error_code']=$lock['code'];
                self::$volatile[self::site()]=$result;
                return $result;
            }
            try {
                $result=self::check($intent,$api);
                $stored=Options::stored(self::OPTION);
                if (!$stored['success'] || ($stored['exists']&&!self::valid($stored['value']))) {
                    $result['diagnostic_error_code']='f3_google_cron_schedule_diagnostic_read';
                }
                else {
                    $s=$stored['value']??['observations'=>[],'active_errors'=>[],'last_errors'=>[],'untracked_errors'=>0];
                    $identity=self::identity($intent);
                    $slot=$intent['hook'].'|'.$intent['origem'].'|'.$intent['operation'];
                    $durable=$result;
                    $durable['diagnostic_persisted']=true;
                    self::resolve_confirmed($s, $s['observations']);
                    $s['observations'][$slot]=$durable;
                    if (!$result['success']) {
                        $s['active_errors'][$identity]=$durable;
                        $s['last_errors'][$slot]=$durable;
                    }
                    // Reconcile before a newer observation replaces the only proof in its slot.
                    self::resolve_confirmed($s, [$durable]);
                    if (count($s['active_errors'])>100) {
                        $s['untracked_errors']+=count($s['active_errors'])-100;
                        $s['active_errors']=array_slice($s['active_errors'],-100,null,true);
                    }
                    $saved=Lock::owned($lock['lock'])?Options::set(self::OPTION,$s):['success'=>false,'error_code'=>'f3_google_lock_lost'];
                    $result['diagnostic_persisted']=$saved['success'];
                    $result['diagnostic_error_code']=$saved['error_code']??null;
                }
                self::$volatile[self::site()]=$result;
                return $result;
            }
            finally {
                Lock::release($lock['lock']);
            }
            });
    }
    /** An observation proves only the requested state of the same owned event. */
    private static function confirms(array $observation, array $error): bool {
        if (!in_array($error['hook'], self::HOOKS, true)
            || $observation['hook'] !== $error['hook']
            || $observation['args_digest'] !== $error['args_digest']
            || $observation['args_key'] !== $error['args_key']
            || $observation['state'] !== 'confirmed'
            || ($observation['success'] ?? false) !== true
            || ($observation['read_success'] ?? false) !== true
            || ($observation['postcondition'] ?? false) !== true
            || isset($observation['resolved_by'])
            || $observation['id'] === $error['id']) {
            return false;
        }
        // Records::id() starts with a microsecond clock. Random suffixes do not establish order.
        if ($observation['at'] < $error['at']) return false;
        if ($observation['at'] === $error['at']) {
            if (!preg_match('/^([0-9]{20})_/', $observation['id'], $new)
                || !preg_match('/^([0-9]{20})_/', $error['id'], $old)
                || strcmp($new[1], $old[1]) <= 0) return false;
        }
        $op = $observation['operation'];
        if ($error['operation'] === 'clear') return $op === 'clear';
        if ($error['operation'] === 'unschedule') {
            return $op === 'clear' || ($op === 'unschedule' && $observation['target_at'] === $error['target_at']);
        }
        if (!in_array($op, ['schedule', 'reschedule'], true) || $observation['target_at'] === null) return false;
        if ($error['recurrence'] !== null) {
            return $observation['recurrence'] === $error['recurrence'] && $observation['interval'] === $error['interval'];
        }
        // Both owned hooks wake a worker. A verified replacement meets an elapsed wake-up,
        // or a future wake-up if the worker will already be called by the requested time.
        $effective_at = $observation['equivalent_at'] ?? $observation['target_at'];
        return $error['target_at'] !== null && ($error['target_at'] <= $observation['at'] || $effective_at <= $error['target_at']);
    }
    private static function resolve_confirmed(array &$state, array $observations): int {
        $count = 0;
        foreach ($state['active_errors'] as $key => $error) {
            foreach ($observations as $observation) {
                if (!self::confirms($observation, $error)) continue;
                $slot = $error['hook'].'|'.$error['origem'].'|'.$error['operation'];
                $error['resolved_at'] = $observation['at'];
                $error['resolved_by'] = $observation['id'];
                if (!isset($state['last_errors'][$slot]) || $state['last_errors'][$slot]['id'] === $error['id']) {
                    $state['last_errors'][$slot] = $error;
                }
                // last_errors is one row per slot: retain a receipt even if a newer error owns it.
                $state['resolution_receipts'][$error['id']] = array_intersect_key($error, array_flip(['id', 'hook', 'resolved_at', 'resolved_by']));
                unset($state['active_errors'][$key]);
                ++$count;
                break;
            }
        }
        if ($count) $state['resolution_receipts'] = array_slice($state['resolution_receipts'], -100, null, true);
        return $count;
    }
    private static function identity(array $intent): string {
        $parts=[];
        foreach(['hook','origem','operation','target_at','args_key','args_digest','recurrence','interval'] as $f) $parts[$f]=$intent[$f]??null;
        return hash('sha256',wp_json_encode($parts));
    }
    private static function valid($s): bool {
        if (!is_array($s)) return false;
        if (array_key_exists('resolution_receipts', $s)) {
            if (!is_array($s['resolution_receipts'])) return false;
            foreach ($s['resolution_receipts'] as $receipt) {
                if (!is_array($receipt) || !in_array($receipt['hook'] ?? null, self::HOOKS, true)
                    || !is_string($receipt['id'] ?? null) || !is_int($receipt['resolved_at'] ?? null)
                    || !is_string($receipt['resolved_by'] ?? null)) return false;
            }
        }
        foreach(['observations','active_errors','last_errors'] as $key) {
            if (!is_array($s[$key]??null)) return false;
            foreach($s[$key] as $row) {
                if (!is_array($row)||!is_string($row['hook']??null)) return false;
                // Out-of-scope history is preserved, never validated or replayed as current work.
                if (!in_array($row['hook'],self::HOOKS,true)) continue;
                if (!in_array($row['operation']??'',['schedule','reschedule','unschedule','clear'],true)) return false;
                foreach(['id','args_key','args_digest','origem','state'] as $f) if (!is_string($row[$f]??null)) return false;
                foreach(['at','interval'] as $f) if (!is_int($row[$f]??null)) return false;
                if (!array_key_exists('target_at',$row)||($row['target_at']!==null&&!is_int($row['target_at']))) return false;
                if (!array_key_exists('recurrence',$row)||($row['recurrence']!==null&&!is_string($row['recurrence']))) return false;
            }
        }
        return true;
    }
    /** Only confirms old observations. Never reschedules an obsolete intention. */
    public static function reconcile(): array {
        return Recovery::run(static function() {
            $lock=Lock::acquire_result('cron-scheduling',30);
            if (!$lock['success']) return ['success'=>false,'error_code'=>$lock['code']];
            try {
                $stored=Options::stored(self::OPTION);
                if (!$stored['success'] || ($stored['exists']&&!self::valid($stored['value']))) return ['success'=>false,'error_code'=>'f3_google_cron_schedule_diagnostic_read'];
                if (!$stored['exists']||!$stored['value']['active_errors']) return ['success'=>true,'resolved'=>0];
                $s=$stored['value'];
                $read=self::read();
                $resolved=self::resolve_confirmed($s, $s['observations']);
                if (!$read['success']) return ['success'=>false,'error_code'=>$read['code']];
                $keys=array_keys(array_filter($s['active_errors'],static fn($row)=>in_array($row['hook'],self::HOOKS,true)));
                if (!$keys && !$resolved) return ['success'=>true,'resolved'=>0];
                $offset=(int)($s['reconcile_offset']??0)%max(1,count($keys));
                $selected=array_slice(array_merge($keys,$keys),$offset,min(20,count($keys)));
                foreach ($selected as $id) {
                    $error=$s['active_errors'][$id];
                    // An old duplicate_event refusal is resolved only by a pending equivalent read in this same pass.
                    $duplicate=self::duplicate_refusal($error,$error['original_code']??null);
                    $pending=$duplicate?self::pending($error,$read['cron']):null;
                    if ($duplicate && $pending===null) continue;
                    if (!$duplicate && self::proof($error,$read['cron'])!==true) continue;
                    $slot=$error['hook'].'|'.$error['origem'].'|'.$error['operation'];
                    if ($pending!==null) $error['equivalent_at']=$pending;
                    $error['resolved_at']=time();
                    $error['resolved_by']=$duplicate?'duplicate_event_equivalent':'postcondition_recheck';
                    if (($s['last_errors'][$slot]['id']??null)===$error['id']) $s['last_errors'][$slot]=$error;
                    if (($s['observations'][$slot]['id']??null)===$error['id']) $s['observations'][$slot]=array_replace($error,['at'=>time(),'success'=>true,'state'=>'confirmed','postcondition'=>true,'read_success'=>true,'error_code'=>null]);
                    unset($s['active_errors'][$id]);
                    ++$resolved;
                }
                $s['reconcile_offset']=($offset+count($selected))%max(1,count($s['active_errors']));
                if (!$resolved && ($s['reconcile_offset']??0)===($stored['value']['reconcile_offset']??0)) return ['success'=>true,'resolved'=>0];
                if (!Lock::owned($lock['lock'])) return ['success'=>false,'error_code'=>'f3_google_lock_lost'];
                return Options::set(self::OPTION,$s)+['resolved'=>$resolved];
            }
            finally {
                Lock::release($lock['lock']);
            }
            });
    }
    public static function status(): array {
        $stored=Options::stored(self::OPTION);
        $valid=$stored['success']&&(!$stored['exists']||self::valid($stored['value']));
        $s=$valid?($stored['value']??[]):[];
        // Project legacy history on first read; only the locked writer or maintenance persists it.
        if (!empty($s['active_errors'])) self::resolve_confirmed($s, $s['observations']);
        $clean=static function($rows) {
            $rows=array_filter($rows,static fn($row)=>in_array($row['hook'],self::HOOKS,true));
            foreach($rows as &$r) {
                unset($r['args_key']);
                $r['observation_age_seconds']=max(0,time()-(int)$r['at']);
            }
            return array_values($rows);
        };
        $check=ExecutorSchedule::status();
        $errors=$clean($s['active_errors']??[]);
        if($check['reason_code']!==null) $errors[]=['id'=>'current_executor','source'=>'current_state','hook'=>Jobs::HOOK,'at'=>$check['observed_at'],'error_code'=>$check['reason_code'],'state'=>$check['state'],'diagnostic_persisted'=>false];
        return ['checks'=>['executor'=>$check],'contract_version'=>'2.0.0','scope'=>'site','read_success'=>$valid,'observed'=>$stored['exists']&&$valid,
            'error_code'=>$valid?null:'f3_google_cron_schedule_diagnostic_read','observations'=>$clean($s['observations']??[]),
            'resolution_receipts'=>array_values($s['resolution_receipts']??[]),'active_errors'=>$errors,'last_errors'=>$clean($s['last_errors']??[]),'untracked_errors'=>$s['untracked_errors']??0,
            'last_diagnostic_write'=>isset(self::$volatile[self::site()])?$clean([self::$volatile[self::site()]])[0]:null,
            'documentation'=>'ACOMPANHAMENTO-CRON.md'];
    }
    public static function schema(): array {
        $row=['type'=>'object','properties'=>[
                'id'=>['type'=>'string'],'at'=>['type'=>'integer'],'hook'=>['type'=>'string','enum'=>self::HOOKS],
                'operation'=>['type'=>'string','enum'=>['schedule','reschedule','unschedule','clear']],
                'target_at'=>['type'=>['integer','null']],'args_digest'=>['type'=>'string'],'recurrence'=>['type'=>['string','null']],'interval'=>['type'=>'integer'],
                'origem'=>['type'=>'string','enum'=>['cli','http_cron','manual','unknown']],
                'state'=>['type'=>'string','enum'=>['confirmed','failed','unconfirmed']],'success'=>['type'=>'boolean'],'read_success'=>['type'=>'boolean'],
                'postcondition'=>['type'=>['boolean','null']],'original_code'=>['type'=>['string','null']],'api_success'=>['type'=>'boolean'],
                'error_code'=>['type'=>['string','null']],'diagnostic_persisted'=>['type'=>'boolean'],'diagnostic_error_code'=>['type'=>['string','null']],
                'observation_age_seconds'=>['type'=>'integer'],'resolved_at'=>['type'=>'integer'],'resolved_by'=>['type'=>'string'],
                'equivalent_at'=>['type'=>'integer','description'=>'Evento equivalente (mesmo hook e argumentos) que levou o WordPress a recusar o evento único como duplicate_event.']]];
        return ['type'=>'object','properties'=>['contract_version'=>['type'=>'string','enum'=>['2.0.0']],'scope'=>['type'=>'string','enum'=>['site']],
                'read_success'=>['type'=>'boolean'],'observed'=>['type'=>'boolean'],'error_code'=>['type'=>['string','null']],
                'observations'=>['type'=>'array','items'=>$row],'checks'=>['type'=>'object','properties'=>['executor'=>ExecutorSchedule::schema()]],'active_errors'=>['type'=>'array','items'=>['anyOf'=>[$row,['type'=>'object','properties'=>[
                                    'id'=>['type'=>'string'],'source'=>['type'=>'string','enum'=>['current_state']], 'hook'=>['type'=>'string'],'at'=>['type'=>'integer'],
                                    'error_code'=>['type'=>'string'],'state'=>['type'=>'string','enum'=>['missing','invalid','unknown']], 'diagnostic_persisted'=>['type'=>'boolean']]]]]],
                'resolution_receipts'=>['type'=>'array','maxItems'=>100,'items'=>['type'=>'object','properties'=>array_intersect_key($row['properties'],array_flip(['id','hook','resolved_at','resolved_by']))]],'last_errors'=>['type'=>'array','items'=>$row],'untracked_errors'=>['type'=>'integer'],'last_diagnostic_write'=>array_replace($row,['type'=>['object','null']]),'documentation'=>['type'=>'string']]];
    }
}
