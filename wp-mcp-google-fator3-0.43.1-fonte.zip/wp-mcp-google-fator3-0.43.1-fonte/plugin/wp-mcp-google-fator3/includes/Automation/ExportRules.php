<?php
/** Explicit WordPress authorization for an exact, frozen export intention. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{Ability,Auth\Credentials,Confirmation,Connections,Options,Records,Response,Settings};
defined('ABSPATH') || exit;

final class ExportRules {
    public const OPTION='f3_mcp_google_export_rules';
    public const SCAN='f3_mcp_google_authority_scan';
    public static function resume_existing(): void {
        $offset=max(0,(int)Options::get(self::SCAN,0));
        $rows=\Fator3\McpGoogle\Storage\Repository::select('job',['connection_id'=>Connections::id(),'state'=>'blocked'],100,$offset);
        if (is_wp_error($rows)) return;
        $seen=0;
        foreach ($rows as $row) {
            if (Execution::remaining()<3) break;
            ++$seen;
            $job=Records::get('job',$row['record_id']);
            if (!$job || !in_array($job['blocked_reason']??'',['f3_google_channel_revoked','f3_google_channel_changed','authorization_required'],true)) continue;
            if (!\Fator3\McpGoogle\SiteAuthority::authorized((int)$job['user_id']) || Context::validate($job['context']??[])!==null) continue;
            Worker::run($job['id'],1);
        }
        Options::set(self::SCAN,$seen===count($rows)&&count($rows)<100?0:$offset+$seen);
    }
    public static function match(array $job): ?string {
        if (($job['task']??'')!=='export' || $job['connection_id']!==Connections::id()) return null;
        $key=FrozenInput::hash($job['parameters']);
        $rule=Options::get(self::OPTION,[])[$key]??null;
        if (!is_array($rule) || empty($rule['enabled']) ||
            $rule['identity']!==Credentials::execution_identity() || $rule['revision']!==Settings::execution_revision()) return null;
        return FrozenInput::hash($rule);
    }

    public static function plan(array $input): array {
        if (!Options::authorized()) return Response::fail(new \WP_Error('f3_google_forbidden','Permissão administrativa necessária.'));
        if (!is_bool($input['enabled']??null)) return Response::fail(new \WP_Error('f3_google_export_rule_input','Informe enabled como booleano.'));
        $job=Records::get('job',(string)($input['job_id']??''));
        if (!$job || $job['connection_id']!==Connections::id() || $job['task']!=='export') {
            return Response::fail(new \WP_Error('f3_google_export_rule_job','Informe uma exportação desta conexão.'));
        }
        if ($error=Context::validate($job['context']??[])) return Response::fail($error);
        $revision=Settings::revision();
        if (is_wp_error($revision)) return Response::fail($revision);
        $rule=['enabled'=>$input['enabled'],'parameters_hash'=>FrozenInput::hash($job['parameters']),
            'identity'=>Credentials::execution_identity(),'revision'=>Settings::execution_revision()];
        $hash=hash_hmac('sha256',wp_json_encode([$revision,$rule,get_current_user_id()]),wp_salt('auth'));
        return Response::ok(['dry_run'=>true,'configuration_revision'=>$revision,'plan_hash'=>$hash,'rule'=>$rule,
            'parameters'=>$job['parameters'],'effects'=>['Autoriza exportações com estes parâmetros exatos nesta conexão e identidade.',
                'A execução prepara e confere o estado remoto antes de escrever.','A exclusão ou desativação da regra impede novos despachos automáticos.']]);
    }

    public static function configure(array $input): array {
        $plan=self::plan($input);
        if (empty($plan['success'])) return $plan;
        if (!hash_equals($plan['configuration_revision'],(string)($input['expected_revision']??'')) ||
            !hash_equals($plan['plan_hash'],(string)($input['expected_plan_hash']??''))) return Settings::conflict();
        $rules=(array)Options::get(self::OPTION,[]);
        $key=$plan['rule']['parameters_hash'];
        if (!isset($rules[$key]) && count($rules)>=100) return Response::fail(new \WP_Error('f3_google_export_rule_limit','Limite de 100 regras por conexão.'));
        $rules[$key]=$plan['rule']+['approved_by'=>get_current_user_id()];
        $saved=Settings::save([self::OPTION=>$rules],[],[],$input['expected_revision']);
        if (!empty($saved['success'])) Jobs::schedule_tick();
        return $saved;
    }

    /** Uses the same preparation and single-job confirmation fence as manual approval. */
    public static function prepare(array $job): array {
        $rule=self::match($job);
        if ($rule===null) return ['success'=>false,'error_code'=>'f3_google_export_rule_required'];
        $prepared=Confirmation::for_job($job['id'],static fn()=>Confirmation::prepare([
            'ability'=>'google/export-to-sheet','parameters'=>$job['parameters']]));
        if (empty($prepared['success'])) return $prepared;
        if (self::match($job)!==$rule) return Settings::conflict();
        $approved=Confirmation::delegate_job($prepared['confirmation_token']??'','google/export-to-sheet',$job['parameters'],$job['id']);
        return $approved+['rule_revision'=>$rule];
    }

    private static function output_schema(): array {
        $s=['type'=>'string'];$b=['type'=>'boolean'];
        return ['type'=>'object','properties'=>['success'=>$b,'message'=>$s,'error_code'=>['type'=>['string','null']],
            'dry_run'=>$b,'persisted'=>$b,'changed'=>$b,'configuration_revision'=>$s,'revision'=>$s,'plan_hash'=>$s,
            'rule'=>['type'=>'object','properties'=>['enabled'=>$b,'parameters_hash'=>$s,'identity'=>$s,'revision'=>$s]],
            'parameters'=>['type'=>'object'],'effects'=>['type'=>'array','items'=>$s]]];
    }
    public static function register(): void {
        foreach (['plan-export-rule'=>'plan','configure-export-rule'=>'configure'] as $name=>$method) {
            $properties=['job_id'=>['type'=>'string','pattern'=>'^[A-Za-z0-9_-]{1,100}$'],'enabled'=>['type'=>'boolean']];
            $required=['job_id','enabled'];
            if ($method==='configure') {
                foreach (['expected_revision','expected_plan_hash'] as $field) {$properties[$field]=['type'=>'string'];$required[]=$field;}
            }
            Ability::register('google/'.$name,'any',['label'=>'Regra de aprovação de exportações',
                'description'=>'Simula ou grava autorização do WordPress para os parâmetros exatos de uma exportação. Exige administrador.',
                'mode'=>$method==='plan'?'read':'write','input_schema'=>['properties'=>$properties,'required'=>$required],
                'output_schema'=>self::output_schema(),'callback'=>[self::class,$method]]);
        }
    }
}
