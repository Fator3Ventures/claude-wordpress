<?php
/** Lifetime of the last conclusive verification for a single revision and destination. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
defined('ABSPATH') || exit;

final class ConversionProof {
    /** Integer representation of "until rejected" for the Core 1.95 enhanced-leads contract. */
    public const NO_DEADLINE = 253402300799;

    public static function temporary(array $attempt): bool {
        if (isset($attempt['failure_kind'])) return $attempt['failure_kind'] === 'transient';
        $detail = $attempt['provider_error'] ?? [];
        $http = (int) ($detail['http_status'] ?? 0);
        if (in_array($http, [408, 425, 429], true) || $http >= 500) return true;
        if (in_array(strtoupper($detail['reason'] ?? ''), ['RATE_LIMIT_EXCEEDED','QUOTA_EXCEEDED','RESOURCE_EXHAUSTED','RATELIMITEXCEEDED','USERRATELIMITEXCEEDED'], true)) return true;
        if ($http >= 400) return false;
        if (($detail['phase'] ?? '') === 'execution') return true;
        if ($http === 200) return false;
        // Old probes used status zero for both a network error and a rejected action definition.
        if (in_array($detail['phase'] ?? '', ['ads_action_read','data_manager_validation'],true)
            && preg_match('/A ação precisa|valor zero em BRL/u', $detail['message'] ?? '')) return false;
        return $http === 0 && !empty($detail);
    }

    public static function state(string $target, array $proof, array $renewal, string $revision): string {
        if (empty($proof['revision']) || !hash_equals($revision,$proof['revision'])) return 'unverified';
        if (!empty($proof['rejected'])) return 'invalid';
        $failed = ($renewal['result'] ?? '') === 'failed' && ($renewal['revision'] ?? '') === $revision;
        if ($failed) {
            if (!self::temporary($renewal)) return 'invalid';
            // 0.38 retained its prior proof even on a conclusively negative renewal.
            if (!isset($renewal['failure_kind'])) {
                if (!empty($renewal['attempts_omitted'])) return 'unverified';
                foreach ($renewal['attempts'] ?? [] as $attempt) {
                    if (!self::temporary($attempt)) return 'invalid';
                }
            }
        }
        if ($target === 'google_ads') return 'valid_until_rejected';
        if (($proof['expires'] ?? 0) > time()) return 'valid';
        return $failed ? 'stale_transient' : 'expired';
    }

    public static function allows(string $state): bool {
        return in_array($state, ['valid','valid_until_rejected','stale_transient'], true);
    }

    public static function generation(array $proof): string {
        return $proof['generation'] ?? hash('sha256',wp_json_encode([$proof['revision'] ?? '', $proof['at'] ?? 0]));
    }
}
