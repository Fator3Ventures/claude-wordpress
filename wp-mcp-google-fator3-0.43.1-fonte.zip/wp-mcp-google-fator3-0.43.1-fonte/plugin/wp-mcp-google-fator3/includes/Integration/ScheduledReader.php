<?php
/** Bind a scheduled local reader to its current property, grant and execution policy. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
use Fator3\McpGoogle\{Connections, Settings};

if (!defined('ABSPATH')) {
    exit;
}
trait ScheduledReader {
    private static function reader_scope(string $id, array $config, array $grant, string $revision): string {
        $binding = [$config['property'], $config['revision'], $grant['revision'], $revision];
        return 'reader:'.static::CONTRACT.':'.$id.':'.hash('sha256', (string) wp_json_encode($binding));
    }

    public static function can_recheck(string $id, string $scope, string $resource): bool {
        $consumer = static::$consumers[$id] ?? null;
        if (!$consumer) {
            return false;
        }
        $resolved = static::resolve_grant($id);
        if (!is_array($resolved) || $resolved['resolution'] !== 'resolved' || $resolved['connection_id'] !== Connections::id()) {
            return false;
        }
        $config = static::config($consumer);
        $revision = Settings::execution_revision();
        if (!is_array($config) || !is_string($revision) || static::guard($consumer, $config, $revision, $resolved['grant'])) {
            return false;
        }
        $endpoint = static::CONTRACT === Ga4ServiceApi::CONTRACT
            ? 'https://analyticsdata.googleapis.com/v1beta/'.$config['property'].':runReport'
            : 'https://www.googleapis.com/webmasters/v3/sites/'.rawurlencode($config['property']).'/searchAnalytics/query';
        return $endpoint === $resource && hash_equals(static::reader_scope($id, $config, $resolved['grant'], $revision), $scope);
    }
}
