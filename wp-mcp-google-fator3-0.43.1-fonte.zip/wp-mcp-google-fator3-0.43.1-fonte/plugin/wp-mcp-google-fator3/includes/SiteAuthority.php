<?php
/** WordPress owns persisted operations. The original grantor remains audit data. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
defined('ABSPATH') || exit;

final class SiteAuthority {
    public static function administrator(int $preferred = 0): int {
        if ($preferred > 0 && Options::user_authorized($preferred)) return $preferred;
        foreach (get_users(['capability'=>'manage_options', 'fields'=>'ID', 'orderby'=>'ID', 'order'=>'ASC']) as $id) {
            if (Options::user_authorized((int)$id)) return (int)$id;
        }
        return 0;
    }

    public static function authorized(int $grantor): bool {
        return $grantor > 0 && self::administrator($grantor) > 0;
    }

    /** Called by an executor, never by a status read. */
    public static function observe(int $grantor): void {
        if ($grantor < 1) return;
        TechnicalNotices::publish('autorizacao_recusada', 'grantor/'.$grantor,
            !Options::user_authorized($grantor), ['human_action'=>self::administrator($grantor) === 0]);
    }
}
