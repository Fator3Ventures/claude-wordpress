<?php
/** IAM metadata for the active service-account key. Status never contacts Google. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Auth;
use Fator3\McpGoogle\{Ability,Connections,ContractSchema,Http\GoogleClient,Lock,Options,Policy,Response,Settings,TechnicalNotices};
defined('ABSPATH') || exit;

final class KeyStatus {
    public const PERMISSION = 'iam.serviceAccountKeys.get';

    public static function is_metadata_url(string $url): bool {
        return (bool) preg_match('~^https://iam\.googleapis\.com/v1/projects/-/serviceAccounts/[^/?]+/keys/[^/?]+$~D', $url);
    }

    private static function project(?array $key): ?string {
        $project = $key['project_id'] ?? null;
        return is_string($project) && preg_match('/^[a-z0-9][a-z0-9.-]{0,62}$/D', $project) ? $project : null;
    }

    public const STATE='f3_mcp_google_sa_key_status';
    public const CONFIG='f3_mcp_google_sa_key_monitoring';
    public static function schema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['warning_days'],
            'properties'=>['warning_days'=>['type'=>'integer','minimum'=>1,'maximum'=>365,'default'=>30]]];
    }
    public static function status_schema(): array {
        $p=[];foreach(['applicable','known','attention','stale'] as $k)$p[$k]=['type'=>'boolean'];
        foreach(['expires_at','checked_at','last_attempt','next_attempt'] as $k)$p[$k]=['type'=>['integer','null']];
        foreach(['valid_before','error_code'] as $k)$p[$k]=['type'=>['string','null']];
        foreach (['metadata_state','required_permission','project_id','action'] as $field) {
            $p[$field] = ['type'=>['string','null']];
        }
        $p['disabled']=['type'=>['boolean','null']];$p['warning_days']=['type'=>'integer'];$p['source']=['type'=>'string'];
        return ['type'=>'object','properties'=>$p];
    }
    private static function key(): ?array {
        if (Options::auth_mode()!=='service_account') return null;
        $key=json_decode(Options::get_secret(Options::SA_JSON),true);
        if (!is_array($key) || empty($key['client_email']) || empty($key['private_key_id'])) return null;
        return $key;
    }
    private static function fingerprint(array $key): string {
        return hash('sha256',wp_json_encode([$key['client_email'],$key['private_key_id']]));
    }
    public static function status(): array {
        $key=self::key();
        $saved=(array)Options::get(self::STATE,[]);
        if (!$key || ($saved['fingerprint']??'')!==self::fingerprint($key)) $saved=[];
        $expires=$saved['expires_at']??null;
        $days=(int)(Options::get(self::CONFIG,['warning_days'=>30])['warning_days']??30);
        $denied = !empty($saved['iam_denied']);
        // A transient error after a permission refusal leaves that incident open until a valid read.
        $interval = $denied ? HOUR_IN_SECONDS : 6 * HOUR_IN_SECONDS;
        $next_attempt = isset($saved['last_attempt']) ? (int) $saved['last_attempt'] + $interval : null;
        $project = self::project($key);
        $action = $denied ? 'Validade da chave não consultável. Confira a permissão '.self::PERMISSION
            .($project ? ' no projeto '.$project : ' no projeto da conta de serviço').'.' : null;
        return ['metadata_state'=>$saved['outcome'] ?? 'not_checked', 'required_permission'=>$denied ? self::PERMISSION : null,
            'project_id'=>$project,'action'=>$action,'applicable'=>$key!==null,'known'=>isset($saved['valid_before']),'expires_at'=>$expires,
            'valid_before'=>$saved['valid_before']??null,'disabled'=>$saved['disabled']??null,
            'checked_at'=>$saved['checked_at']??null,'last_attempt'=>$saved['last_attempt']??null,'next_attempt'=>$next_attempt,
            'error_code'=>$saved['error_code']??null,'warning_days'=>$days,
            'attention'=>$expires!==null && $expires<=time()+$days*DAY_IN_SECONDS,
            'stale'=>!empty($saved['error_code']) || ($saved['checked_at']??0)<time()-DAY_IN_SECONDS,
            'source'=>'iam.serviceAccounts.keys.get'];
    }
    public static function observe(): void {
        $state=self::status();
        // Retire the former credential classification for this metadata check.
        TechnicalNotices::publish('credencial_invalida','service-account-key-metadata',false);
        $saved = (array) Options::get(self::STATE, []);
        $key = self::key();
        if (!$key || ($saved['fingerprint'] ?? '') !== self::fingerprint($key)) {
            $saved = [];
        }
        if ($state['known'] || !$state['applicable']) {
            TechnicalNotices::publish('token_vencendo','service-account-key',$state['attention'],
                $state['expires_at']!==null ? ['expires'=>$state['expires_at']] : []);
        }
        TechnicalNotices::publish('credencial_invalida', 'service-account-token', !empty($saved['token_rejected']));
        $otherFailure = ($saved['outcome'] ?? '') === 'unavailable'
            && empty($saved['iam_denied']) && empty($saved['token_rejected']);
        TechnicalNotices::publish('integracao_indisponivel', 'iam-metadata-read', $otherFailure);
        TechnicalNotices::publish('autorizacao_recusada', 'iam-key-disabled', ($saved['disabled'] ?? false) === true);

        \Fator3\McpGoogle\Automation\Alerts::observe('key_metadata', 'service-account-key-metadata',
            !empty($saved['iam_denied']), 'key_metadata_permission_denied',
            $state['action'] ?? 'Consulta de validade regularizada.', ['project_id'=>$state['project_id']]);
    }

    private static function record_outcome(array &$saved, $result, string $url, bool $valid): void {
        $data = is_wp_error($result) ? (array) $result->get_error_data() : [];
        $endpoint = $data['url'] ?? '';
        $status = (int) ($data['status'] ?? 0);
        $saved['outcome'] = 'unavailable';
        if ($valid || ($endpoint === $url && $status > 0)) {
            $saved['token_rejected'] = false;
        }
        if ($valid) {
            $saved['outcome'] = 'available';
            $saved['iam_denied'] = false;
        } elseif ($endpoint === $url && $status === 403) {
            // A disabled API or exhausted quota also uses HTTP 403.
            $details = wp_json_encode($data);
            if (!preg_match('/SERVICE_DISABLED|accessNotConfigured|API has not been used|rateLimit|quota|RESOURCE_EXHAUSTED/i', $details)) {
                $saved['outcome'] = 'permission_denied';
                $saved['iam_denied'] = true;
            }
        } elseif (wp_parse_url($endpoint, PHP_URL_HOST) === 'oauth2.googleapis.com'
            && in_array($data['reason'] ?? '', ['invalid_grant','invalid_client'], true)
            && in_array($status, [400,401,403], true)) {
            $saved['outcome'] = 'token_rejected';
            $saved['token_rejected'] = true;
        }
    }

    public static function refresh_due(): void {
        if (!Options::is_enabled()) return;
        $status=self::status();
        if ($status['applicable'] && ($status['next_attempt'] ?? 0) <= time()) {
            $admin=\Fator3\McpGoogle\SiteAuthority::administrator();$prior=get_current_user_id();
            if ($admin>0) {try {wp_set_current_user($admin);self::refresh_key(true);} finally {wp_set_current_user($prior);}}
        }
        self::observe();
    }
    public static function refresh(array $input): array {
        return self::refresh_key(false);
    }
    private static function refresh_key(bool $scheduled): array {
        if (!Options::authorized()) return Response::fail(new \WP_Error('f3_google_forbidden','Administrador atual exigido.'));
        $key=self::key();
        if (!$key) return Response::ok(['key_status'=>self::status(),'google_checks_performed'=>false]);
        $lock=Lock::acquire('key-status:'.Connections::id(),30);
        if ($lock===null) return Response::fail(new \WP_Error('f3_google_key_status_busy','Consulta da chave em andamento.'));
        try {
            if ($scheduled) {
                $status = self::status();
                if (!Options::is_enabled() || ($status['next_attempt'] ?? 0) > time()) {
                    return Response::ok(['key_status'=>$status,'google_checks_performed'=>false]);
                }
            }
            $fingerprint=self::fingerprint($key);
            $url='https://iam.googleapis.com/v1/projects/-/serviceAccounts/'.rawurlencode($key['client_email']).'/keys/'.rawurlencode($key['private_key_id']);
            $envelope=Policy::administrative_read(static fn()=>['result'=>GoogleClient::request('GET',$url,null,[
                'connector'=>'any','operation_id'=>'iam.serviceAccounts.keys.get','mode'=>'read',
                'scopes'=>['https://www.googleapis.com/auth/cloud-platform'],'retries'=>0,'timeout'=>5])]);
            $result=$envelope['result']??new \WP_Error('f3_google_forbidden','Administrador atual exigido.');
            if (!self::key() || self::fingerprint(self::key())!==$fingerprint) return Settings::conflict();
            $saved=(array)Options::get(self::STATE,[]);
            if (($saved['fingerprint']??'')!==$fingerprint) $saved=[];
            $saved['fingerprint']=$fingerprint;
            $saved['last_attempt']=time();
            $valid=is_array($result) && is_string($result['name']??null) &&
                str_ends_with($result['name'],'/keys/'.$key['private_key_id']) &&
                is_string($result['validBeforeTime']??null) && strtotime($result['validBeforeTime'])!==false;
            self::record_outcome($saved, $result, $url, $valid);
            if ($valid) {
                $saved['valid_before']=$result['validBeforeTime'];
                $saved['expires_at']=str_starts_with($result['validBeforeTime'],'9999-')?null:strtotime($result['validBeforeTime']);
                $saved['disabled']=(bool)($result['disabled']??false);
                $saved['checked_at']=time();
                $saved['error_code']=null;
            } else {
                $saved['error_code']=is_wp_error($result)?$result->get_error_code():'f3_google_key_metadata_invalid';
            }
            $write=Options::set(self::STATE,$saved);
            if (empty($write['success'])) return Response::fail(new \WP_Error('f3_google_key_status_save','Consulta da chave não persistida.'));
            self::observe();
            return Response::ok(['key_status'=>self::status(),'google_checks_performed'=>true]);
        } finally { Lock::release($lock); }
    }
    public static function plan(array $input): array {
        if (!Options::authorized()) return Response::fail(new \WP_Error('f3_google_forbidden','Permissão administrativa necessária.'));
        $config=$input['configuration']??null;
        if (!is_array($config) || !ContractSchema::valid($config,self::schema())) return Response::fail(new \WP_Error('f3_google_key_monitor_input','Informe warning_days entre 1 e 365.'));
        $revision=Settings::revision();
        if (is_wp_error($revision)) return Response::fail($revision);
        return Response::ok(['dry_run'=>true,'configuration'=>$config,'configuration_revision'=>$revision,
            'plan_hash'=>hash_hmac('sha256',wp_json_encode([$revision,$config,get_current_user_id()]),wp_salt('auth')),
            'effects'=>['O executor observa o vencimento e publica o aviso técnico no Core quando entrar nesta antecedência.']]);
    }
    public static function configure(array $input): array {
        $p=self::plan($input);
        if (empty($p['success'])) return $p;
        if (!hash_equals($p['configuration_revision'],(string)($input['expected_revision']??'')) || !hash_equals($p['plan_hash'],(string)($input['expected_plan_hash']??''))) return Settings::conflict();
        return Settings::save([self::CONFIG=>$p['configuration']],[],[],$input['expected_revision']);
    }
    public static function register(): void {
        Ability::register('google/service-account-key-status','any',['label'=>'Vencimento da chave de serviço','description'=>'Lê a última consulta IAM da chave ativa, sem HTTP. Estado desconhecido exige consulta IAM.','output_schema'=>['type'=>'object','properties'=>['key_status'=>self::status_schema()]],'callback'=>static fn()=>Response::ok(['key_status'=>self::status()])]);
        Ability::register('google/refresh-service-account-key-status','any',['label'=>'Consultar vencimento da chave','description'=>'Consulta IAM usando iam.serviceAccountKeys.get, persiste o diagnóstico e publica avisos técnicos pelo Core.','mode'=>'write','remote_effect'=>'read','output_schema'=>['type'=>'object','properties'=>['key_status'=>self::status_schema(),'google_checks_performed'=>['type'=>'boolean']]],'callback'=>[self::class,'refresh']]);
        foreach (['plan-key-monitoring'=>'plan','configure-key-monitoring'=>'configure'] as $name=>$method) {
            $props=['configuration'=>self::schema()];$required=['configuration'];
            if ($method==='configure') foreach (['expected_revision','expected_plan_hash'] as $field) {$props[$field]=['type'=>'string'];$required[]=$field;}
            Ability::register('google/'.$name,'any',['label'=>'Antecedência de aviso da chave','description'=>'Simula ou grava a antecedência por conexão. A consulta ao fornecedor ocorre no executor.','mode'=>$method==='plan'?'read':'write','input_schema'=>['properties'=>$props,'required'=>$required],'output_schema'=>['type'=>'object','properties'=>['success'=>['type'=>'boolean'],'message'=>['type'=>'string'],'dry_run'=>['type'=>'boolean'],'configuration'=>self::schema(),'configuration_revision'=>['type'=>'string'],'plan_hash'=>['type'=>'string'],'persisted'=>['type'=>'boolean'],'changed'=>['type'=>'boolean'],'effects'=>['type'=>'array','items'=>['type'=>'string']]]],'callback'=>[self::class,$method]]);
        }
    }
}
