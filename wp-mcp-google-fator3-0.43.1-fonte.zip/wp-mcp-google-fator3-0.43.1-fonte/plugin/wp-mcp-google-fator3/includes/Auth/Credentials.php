<?php
/**
 * Escolha do modo de autenticação e cache de tokens.
 *
 * Access tokens ficam cifrados em transients até pouco antes de expirar.
 * Transients podem residir no banco ou em cache externo. A chave do cache
 * inclui identidade, escopos e geração externa de recuperação, impedindo
 * reutilizar um token restaurado depois de uma retomada explícita.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Connections;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Credentials {
    /** Only the public identity from the stored SA key, never a candidate or key identifier. */
    public static function service_account_identity(): array {
        $empty=['client_email'=>null,'project_id'=>null];
        if(Options::secret_problem(Options::SA_JSON)!==null)return $empty;
        $key=json_decode(Options::get_secret(Options::SA_JSON),true);
        if(!is_array($key)||($key['type']??'')!=='service_account')return $empty;
        return ['client_email'=>is_string($key['client_email']??null)&&strlen($key['client_email'])<=254&&filter_var($key['client_email'],FILTER_VALIDATE_EMAIL)?$key['client_email']:null,
            'project_id'=>is_string($key['project_id']??null)&&preg_match('/^[a-z0-9][a-z0-9.:-]{0,127}$/D',$key['project_id'])?$key['project_id']:null];
    }
	public const SCOPE_GA  = 'https://www.googleapis.com/auth/analytics.readonly';
	public const SCOPE_ADS = 'https://www.googleapis.com/auth/adwords';
	/** Prefixo das chaves de transient onde o token fica. */
	public const CACHE_PREFIX = 'f3_mcp_google_tok_';
	/**
	 * Escopos a pedir para um conector.
	 *
	 * Pedir só o necessário importa no modo OAuth: cada escopo a mais é uma
	 * tela de consentimento a mais e um acesso a mais concedido ao site.
	 *
	 * @param string $connector 'ga' | 'ads' | 'any'.
	 * @return string[]
	 */
	public static function scopes_for( string $connector ): array {
		$selected = \Fator3\McpGoogle\Connections::scopes( $connector );
		if ( 'any' !== $connector && null !== $selected ) {
			return $selected;
		}
		$base  = 'https://www.googleapis.com/auth/';
		$map   = array(
			'ga'               => array( 'analytics.readonly', 'analytics.edit', 'analytics.manage.users' ),
			'ads'              => array( 'adwords', 'datamanager' ),
			'gsc'              => array( 'webmasters' ),
			'siteverification' => array( 'siteverification' ),
			'sheets'           => array( 'spreadsheets', 'drive.file' ),
			'drive'            => array( 'drive.file' ),
			'gtm'              => array( 'tagmanager.readonly', 'tagmanager.edit.containers', 'tagmanager.delete.containers', 'tagmanager.edit.containerversions', 'tagmanager.publish', 'tagmanager.manage.users', 'tagmanager.manage.accounts' ),
		);
		$names = array();
		if ( isset( $map[ $connector ] ) ) {
			$names = $map[ $connector ];
		} else {
			foreach ( $map as $service => $scopes ) {
				if ( ( 'ga' === $service && ! Options::ga_enabled() ) || ( 'ads' === $service && ! Options::ads_enabled() ) ) {
					continue;
				}
				$chosen = \Fator3\McpGoogle\Connections::scopes( $service );
				$names  = array_merge( $names, null === $chosen ? $scopes : array_map( static fn ( $scope ) => substr( $scope, strlen( $base ) ), $chosen ) );
			}
		}
		return array_values( array_unique( array_map( static fn ( $name ) => $base . $name, $names ) ) );
	}
	/** Separação de caches de contas e diagnósticos por credencial/delegação. */
	public static function identity_key(): string {
		$provider = self::current();
		$identity = is_wp_error( $provider ) ? 'unconfigured' : (string) wp_json_encode( $provider->describe() );
		return substr( hash( 'sha256', \Fator3\McpGoogle\Connections::id() . '|' . hash( 'sha256', Options::get_secret( Options::SA_JSON ) ) . '|' . Options::auth_mode() . '|' . $identity . '|' . hash( 'sha256', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) ) . '|' . (string) Options::get( Options::SA_SUBJECT, '' ) . '|' . Options::ads_login_customer_id() ), 0, 24 );
	}
	/** Stable principal for queued work; token caches retain their key fingerprint. */
	public static function execution_identity(): string {
		if ( 'service_account' !== Options::auth_mode() ) {
			return self::identity_key();
		}
		$key = json_decode( Options::get_secret( Options::SA_JSON ), true );
		if ( ! is_array( $key ) || empty( $key['client_id'] ) || empty( $key['client_email'] ) ) {
			return self::identity_key();
		}
		return hash( 'sha256', wp_json_encode( array( Connections::id(), 'service_account', $key['client_id'], $key['client_email'], $key['project_id'] ?? '', Options::get( Options::SA_SUBJECT, '' ) ) ) );
	}
	/**
	 * @return CredentialsInterface|\WP_Error
	 */
	public static function current() {
		if ( ! (bool) Options::get( \Fator3\McpGoogle\Settings::AUTH_READY, true ) ) {
			return new \WP_Error( 'f3_google_auth_not_active', 'Credenciais preparadas. Use a ação de ativação na aba Conexão.' );
		}
		foreach ( 'oauth' === Options::auth_mode() ? array( Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN ) : array( Options::SA_JSON ) as $secret ) {
			$error = Options::secret_problem( $secret );
			if ( null !== $error ) {
				return $error;
			}
		}
		if ( 'oauth' === Options::auth_mode() ) {
			return OAuthUser::from_options();
		}
		$provider = ServiceAccount::from_options();
		if ( is_wp_error( $provider ) && is_array( Candidate::read( 'service_account' ) ) ) {
			return new \WP_Error( 'f3_google_auth_not_active', 'Ative a credencial candidata após validar o acesso.' );
		}
		return $provider;
	}
	public static function is_configured(): bool {
		return ! is_wp_error( self::current() );
	}
	/**
	 * Chave de cache do token.
	 *
	 * Inclui modo, escopos e identidade porque trocar qualquer um dos três
	 * significa outro token: reaproveitar o cache depois de trocar a service
	 * account devolveria dados da conta anterior.
	 *
	 * @param array  $scopes   Escopos pedidos.
	 * @param string $identity Identidade da credencial; vazio consulta a atual.
	 */
	public static function cache_key( array $scopes, string $identity = '', ?string $subject = null, string $fingerprint = '' ): string {
		$scopes = array_values( array_unique( array_filter( array_map( 'strval', $scopes ) ) ) );
		sort( $scopes );
		if ( '' === $identity ) {
			$creds = self::current();
			if ( ! is_wp_error( $creds ) ) {
				$described = $creds->describe();
				$identity  = (string) ( $described['identity'] ?? '' );
			}
		}
		$subject = null === $subject ? ( 'service_account' === Options::auth_mode() ? (string) Options::get( Options::SA_SUBJECT, '' ) : '' ) : $subject;
		if ( '' === $fingerprint && 'oauth' === Options::auth_mode() ) {
			$fingerprint = hash( 'sha256', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
		}
		if (''===$fingerprint && 'service_account'===Options::auth_mode()) {
			$key=json_decode(Options::get_secret(Options::SA_JSON),true);
			if(is_array($key))$fingerprint=hash('sha256',wp_json_encode($key));
		}
		$identity .= '' !== $subject ? '|sub:' . $subject : '';
		$identity .= '' !== $fingerprint ? '|credential:' . $fingerprint : '';
		return self::CACHE_PREFIX . md5( \Fator3\McpGoogle\Recovery::generation() . '|' . \Fator3\McpGoogle\Connections::id() . '|' . Options::auth_mode() . '|' . implode( ' ', $scopes ) . '|' . $identity );
	}
	/**
	 * Guarda o token em cache e anota a chave no índice.
	 *
	 * @param string $key     Chave de transient.
	 * @param string $token   Access token.
	 * @param int    $seconds Validade restante em segundos.
	 */
	public static function cached( string $key, bool $track_hit = true ): string {
		$value = \Fator3\McpGoogle\Cache::get( $key );
		if ( ! is_string( $value ) || '' === $value ) {
			return '';
		}
		$plain = \Fator3\McpGoogle\Crypto::decrypt( $value );
		if ( is_wp_error( $plain ) ) {
			\Fator3\McpGoogle\Cache::delete( $key );
			return '';
		}
		if ( $track_hit ) {
			\Fator3\McpGoogle\Telemetry::add( 'cache_hits' );
		}
		return $plain;
	}
	public static function remember( string $key, string $token, int $seconds ): void {
		if ( '' === $token ) {
			return;
		}
		$cipher = \Fator3\McpGoogle\Crypto::encrypt( $token );
		if ( '' === $cipher ) {
			return;
		}
		\Fator3\McpGoogle\Cache::set( $key, $cipher, max( 1, $seconds ) );
		$index = Options::get( Options::TOKEN_INDEX, array() );
		if ( ! is_array( $index ) ) {
			$index = array();
		}
		if ( ! in_array( $key, $index, true ) ) {
			$index[] = $key;
			// Teto para o índice não crescer indefinidamente com combinações
			// antigas de escopo/identidade.
			if ( count( $index ) > 20 ) {
				foreach ( array_slice( $index, 0, -20 ) as $expired ) {
					if ( is_string( $expired ) && str_starts_with( $expired, self::CACHE_PREFIX ) ) {
						\Fator3\McpGoogle\Cache::delete( $expired );
					}
				}
				$index = array_slice( $index, -20 );
			}
			$saved = Options::set( Options::TOKEN_INDEX, $index );
			if ( empty( $saved['success'] ) ) {
				\Fator3\McpGoogle\Cache::delete( $key );
			}
		}
	}
	/**
	 * Apaga todo token em cache.
	 *
	 * Chamado sempre que a credencial muda na tela: sem isso um token da
	 * credencial antiga continuaria valendo por até uma hora e o administrador
	 * veria dados da conta errada logo depois de trocar a chave.
	 */
	public static function invalidate_cache(): void {
		$index = Options::get( Options::TOKEN_INDEX, array() );
		if ( is_array( $index ) ) {
			foreach ( $index as $key ) {
				if ( is_string( $key ) && 0 === strpos( $key, self::CACHE_PREFIX ) ) {
					\Fator3\McpGoogle\Cache::delete( $key );
				}
			}
		}
		Options::set( Options::TOKEN_INDEX, array() );
	}
}
