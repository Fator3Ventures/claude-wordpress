# Fator3 MCP Google 0.37.0

Pedido MCP Google 55 · 18/11/2026. Base 0.36.0. WordPress mínimo 7.1.4 e PHP mínimo 8.3. Conjunto de referência: Site Core 1.93.0, MCP 0.48.0, LinkedIn 0.26.0, Meta 0.28.0 e Pipedrive 0.12.0.

## Tarefas e autorização

O WordPress autoriza jobs avulsos de inspeção, consulta, exportação, sitemap, relatório e preflight. Revogar a concessão MCP usada para criá-los não invalida a tarefa persistida. A nova chamada pelo transporte revogado continua recusada pelo MCP.

Em cada passagem o executor exige um administrador atual com `manage_options` e a capacidade adicional configurada no Google. Prefere o autor original e, se ele perdeu a permissão, seleciona outro administrador por ID. O histórico conserva o autor original. Sem administrador atual, o trabalho fica bloqueado. A identidade Google, a conexão, a revisão de execução, os recursos e a política continuam sendo revalidados. Nenhuma concessão de recurso é ampliada.

Jobs antigos bloqueados exclusivamente por mudança ou revogação do canal são retomados pelo executor quando essas condições permanecem válidas. Jobs de escrita em estado incerto continuam exigindo reconciliação. Se identidade, política ou geração de recuperação mudou, revise a intenção e crie outra tarefa.

Acervo Ads e consumidores Ads, GA4 e Search Console também aceitam um administrador substituto. A perda de autorização do concedente original gera um aviso técnico, mesmo quando outro administrador permite continuidade.

## Regra persistida para exportação

Em Avançado → Controles, informe o ID de uma exportação, escolha habilitar ou desabilitar e confira a prévia antes de aplicar. A regra autoriza os parâmetros exatos congelados da tarefa: consultas, datas, planilha, abas, modos de escrita e compartilhamentos. Parâmetros diferentes exigem outra regra. Há no máximo 100 regras por conexão.

Pelo MCP:

1. `google/plan-export-rule {"job_id":"ID","enabled":true}`.
2. Confira `parameters`, `effects`, `configuration_revision` e `plan_hash`.
3. Execute `google/configure-export-rule` com os mesmos `job_id` e `enabled`, mais `expected_revision` e `expected_plan_hash` da prévia.

A execução prepara o estado remoto e usa o mesmo registro de confirmação e de tentativas da aprovação manual. A regra é conferida novamente antes de cada despacho. Desabilitá-la impede novas escritas automáticas. Jobs já concluídos ou incertos não são repetidos. A aprovação manual de uma tarefa continua disponível. O autor original permanece no histórico, e a aprovação registra o administrador responsável.

## Avisos técnicos

Todos os avisos operacionais são publicados pelo contrato `f3base_incidente_publicar_v1` do Core. Configure o destino técnico no Site Core. O Google não envia para `admin_email` nem para Slack. Preferências antigas de e-mail e o segredo de webhook ficam inativos e não controlam a entrega.

Uma fila local registra a observação antes de encaminhar. Na ausência do Core, abertura e recuperação permanecem ordenadas para envio posterior. Com Core e sem destinatário, o Core aceita a responsabilidade e mantém sua fila até a configuração do destino. Aceitação não comprova chegada à caixa postal. Reservas incertas são reconciliadas no Core.

O zelador do Core e as visitas administrativas observam a saúde independentemente do tick Google. Se todo o WordPress parar, nenhuma rotina local consegue executar avisos; a disponibilidade do site exige monitoramento externo.

## Recuperação de GA4 e Ads

`google/recovery` com `action:prepare` pausa despachos. Após conferir a restauração e os efeitos remotos, use `action:resume`, `expected_generation` retornado pela pausa e `acknowledge_reconciled:true`. A nova geração invalida a prova operacional. O executor revalida automaticamente destinos previamente autorizados quando identidade, credencial, destino, concessão, serviços e política continuam iguais. Somente uma nova resposta válida do fornecedor devolve `ready:true`.

A migração cria a autorização estável somente a partir de provas ou verificações pendentes que correspondam exatamente ao contexto vigente. Uma prova antiga já incompatível no momento da atualização não demonstra essa autorização: exige verificação administrativa inicial. Alteração de destino ou identidade também exige nova autorização. As retentativas mantêm limites e recuo temporal.

## Validade da chave da conta de serviço

Conexão → Credenciais exibe a última validade conhecida e permite consultar o Google. `google/service-account-key-status` é leitura local. `google/refresh-service-account-key-status` consulta a IAM API e persiste o resultado. O executor consulta a cada seis horas quando a chave está configurada. Leituras de status não consultam o fornecedor.

A conta precisa de `iam.serviceAccountKeys.get` sobre a chave e da IAM API habilitada. A requisição usa o escopo `https://www.googleapis.com/auth/cloud-platform`. O plugin não atribui papéis IAM. O campo oficial `validBeforeTime` é a validade da chave; o prazo do access token não serve como substituto. O valor sentinela do ano 9999 é exposto como sem prazo finito. Ausência de leitura válida é `known:false`; falha após uma leitura conserva o último valor com `stale:true` e diagnóstico.

O aviso começa por padrão 30 dias antes. A tela permite simular e aplicar entre 1 e 365 dias. Pelo MCP, use `google/plan-key-monitoring` com `configuration:{warning_days:30}` e aplique em `google/configure-key-monitoring` com a revisão e o hash retornados. O aviso e a recuperação usam somente o destino técnico do Core.

Referências do fornecedor: https://docs.cloud.google.com/iam/docs/reference/rest/v1/projects.serviceAccounts.keys e https://docs.cloud.google.com/iam/docs/reference/rest/v1/projects.serviceAccounts.keys/get.

## Atualização e validação

Preserve banco, salts e arquivos de estado. Atualize diretamente da 0.36.0, confira a versão e leia o índice completo em `google/documentation`. Não há schema SQL novo. Segredos, pausas, dados, concessões e histórico são preservados. Uma correção posterior à entrega usa nova versão.

Consulte o relatório externo para a identidade dos ZIPs, cenários executados e pendências. Respostas interceptadas em bancada comprovam o fluxo do código; permissões reais da IAM, acesso às contas e recebimento postal precisam de aceite no ambiente autorizado.
