# Guia de operação — Fator3 MCP Google 0.39.0

## Conversões no servidor

O GA4 renova a prova após 12 horas. Uma recusa conclusiva bloqueia imediatamente. Com a mesma revisão e uma prova válida anterior, falhas passageiras mantêm a entrega por tempo indeterminado. O diagnóstico expõe `proof_status=stale_transient` depois das 24 horas e `transient_since` desde a primeira falha. O executor continua tentando e a central do Core recebe `renovacao_falhou` conforme a política de aviso. Sem prova anterior válida ou com revisão alterada, faça uma nova verificação.

No Google Ads, a prova válida da ação de aquisição ou de uma etapa permanece até a revisão mudar ou o envio revelar recusa conclusiva. O executor não renova uma prova Ads válida. O estado `valid_until_rejected` tem `verification_expires_at=null` e nenhuma próxima renovação. Para o consumidor de conversões otimizadas, `enhanced_leads.validity=until_rejected` e `expires_at=253402300799` representam ausência de prazo quando pronto. Depois de uma recusa do destino, corrigir o acesso ou a ação e executar a verificação correspondente. A fila mantém o destino e o identificador de transação para a retomada. O limite de idade do evento Ads é 90 dias. O retorno `ads_retry_same_transaction` permite retentativa com o mesmo pedido e a mesma ação. Uma resposta perdida pode exigir o tratamento descrito no encaminhamento ao Core.

## Verificar e retomar

Em Ferramentas → Fator3 MCP Google → Conversões, selecione a conexão e verifique o destino. Pelo MCP, leia `google/conversion-delivery-status`, use a revisão atual em `google/verify-conversion-delivery` e releia `google/readiness-status`. Para ações comerciais, leia `google/stage-conversion-status` e use `google/verify-stage-conversion` com a ação exata. No Core, leia a fila e confirme o recibo individual da Data Manager. O aceite de ingestão devolve requestId e continua pendente até a confirmação do destino.

## Identidade e outros serviços

O diagnóstico IAM do pedido 56 foi incorporado pelo Core 1.95.0. Consulte `google/service-account-key-status` e `f3base/incidentes-tecnicos-ler`. A configuração da identidade, limites e recursos está em `AGENT-GUIDE.md`, `ESPECIFICACAO.md` e `RECEITAS.md`. A gestão de concessões, tarefas e exportações segue a configuração existente.
