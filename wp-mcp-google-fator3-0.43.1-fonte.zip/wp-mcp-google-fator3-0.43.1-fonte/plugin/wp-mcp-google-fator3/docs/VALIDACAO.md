# Verificação da instalação · 0.43.1

Para o pedido 56, use uma conta com acesso ao GA4 e sem permissão de ler a chave no IAM. Confira uma consulta GA4, depois observe a validade e o projeto. A mesma recusa deve manter um único episódio aberto. A recuperação exige uma resposta IAM válida.

A rodada valida o Pedido MCP Google 56 sobre a base 0.37.0, com Core 1.94.0, MCP 0.49.0, LinkedIn 0.26.0, Meta 0.29.0 e Pipedrive 0.12.0. Consulte o relatório externo para hashes, runtimes efetivamente executados e pendências. Requisitos: WordPress 7.1.4 e PHP 8.3.

## Aceite reproduzível

1. Crie jobs avulsos dos seis tipos por uma concessão MCP descartável. Revogue-a e rebaixe seu autor, mantendo outro administrador. As consultas continuam; o autor original fica no histórico. Novas chamadas pelo transporte revogado permanecem recusadas.
2. Uma exportação espera aprovação. Simule e aplique uma regra com os parâmetros exatos; confirme a conclusão. Desative a regra e confira que a próxima exportação aguarda aprovação sem escrever. Não repita escrita incerta.
3. Rebaixe o concedente dos acervos e leitores. Confira coleta Ads, leitura Ads, GA4 e consulta GSC com outro administrador atual. Confira um aviso técnico para a perda de autorização original. Sem administrador, confira a recusa.
4. Remova o contrato de incidentes somente na bancada. Gere abertura e recuperação; ambas aguardam. Reponha o contrato e confira a ordem, o destinatário técnico e a ausência de duplicação ou Slack.
5. Verifique GA4 e Ads, prepare e retome a recuperação com a geração e a reconciliação explícitas. O estado exige nova prova; o executor consulta o fornecedor e restaura prontidão. Troca de destino não herda essa autorização.
6. Consulte a chave IAM com uma resposta conhecida perto do vencimento, depois com recusa de leitura e depois sem prazo finito. Confira aviso, metadados obsoletos e recuperação. Status deve permanecer local.
7. Na atualização, compare credenciais cifradas, vínculos, jobs pendentes, concluídos e incertos e as provas anteriores. A atualização não cria regras de exportação.

## Documentação e painel

Leia `google/documentation` até o fim de cada documento, valide bytes e SHA-256, e confira as 311 habilidades. Teste administrador e usuário sem permissão, prévias obsoletas e formulários sem JavaScript. A documentação dentro do instalador é gerada dos documentos editáveis e dos schemas do runtime.

As respostas externas e o e-mail dos ensaios locais são interceptados. Elas demonstram as decisões e a persistência do código. A permissão IAM real, as contas Google, a aceitação postal, a instalação compartilhada e o aceite no dia seguinte pela frota são observações distintas; não devem ser inferidas dos testes locais.
