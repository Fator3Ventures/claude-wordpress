# Pedidos em aberto do Fator3 MCP Google

Atualização de 20/11/2026, após a implementação da versão 0.41.0. Próximo número disponível: 60.

A lista de desenvolvimento está vazia. A versão 0.41.0 entrega o Pedido MCP Google 59. O aceite em campo e o encaminhamento ao Site Core estão no relatório da entrega. A janela de operação dos pedidos 57 e 58 segue no estado da frota.
