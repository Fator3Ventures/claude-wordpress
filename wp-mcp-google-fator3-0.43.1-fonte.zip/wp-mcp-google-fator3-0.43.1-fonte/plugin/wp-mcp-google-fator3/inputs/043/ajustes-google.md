# Fator3 MCP Google — ajustes de tela

O Fator3 MCP Google 0.40.0 é o pacote mais perto do guia na base: já tem variáveis de cor, o `hr.wp-header-end`, 360 px sem rolagem e alvo de 40 px. Difere no título (26 px, peso 600), no texto (14 px), na cor de destaque fixa, no terceiro nível de navegação em coluna lateral e no selo com ícone. Slug, capacidade, rotas e options não mudam.

## Navegação

Hoje os grupos são Configurar · Dados · Suporte, e a tela abre em Suporte › Visão geral. Passa a:

| grupo | subabas |
| --- | --- |
| Operação | Visão geral · Incidentes |
| Configurar | as de hoje |
| Dados | as de hoje |
| Suporte | Ajuda |

A tela abre em Operação › Visão geral. Os endereços `&section=` de hoje continuam abrindo a mesma tela.

## Ajustes

| # | onde | hoje | muda para |
| --- | --- | --- | --- |
| 1 | carga da folha (`includes/Admin.php` linha 47) | só `assets/admin.css` | `assets/f3-ui.css` antes da folha própria |
| 2 | raiz `div.wrap.f3-google` | texto de 14 px; variáveis próprias (`--f3-accent:#2271b1`, `--f3-accent-strong:#135e96`, `--f3-success:#00653a`, `--f3-attention:#7a4b00`, `--f3-error:#a8282a`, `--f3-radius-small:5px`) | acrescentar `f3-ui`; a folha própria deixa de declarar variável e usa as da folha comum |
| 3 | cabeçalho (`includes/Admin/Screen.php` linha 31) | `header.f3-header` com `div.f3-title`; h1 de 26 px, peso 600; selo `span.f3-chip` de 12 px, peso 600, texto `#50575e` | `header.f3-heading` sem `div`, h1 nativo, `span.f3-version` |
| 4 | grupos `nav.f3-groups` (linha 102) | pílula de 36 px, raio 24 px, ativa `#135e96` | `div.f3-groups` dentro de `nav.f3-nav`: 40 px, cor do esquema |
| 5 | subabas `nav.f3-navigation.f3-tabs` (linha 109) | traço de 3 px `#2271b1`, texto `#50575e` com peso 600, ativa `#135e96` | `div.f3-subtabs`; a classe `f3-tabs` sai |
| 6 | terceiro nível `nav.f3-subnav` em `div.f3-layout` (linha 118), nas seções de conexão e de opções avançadas | coluna lateral fixa (`position:sticky`) com fundo `#eef1f4` | `f3-switch` no topo do cartão, ou subabas próprias do grupo Configurar; `f3-layout` de duas colunas sai |
| 7 | cartões `.f3-card`, com `.f3-card-header` e `.f3-card-footer` | faixa de título com linha embaixo e margens negativas; 22×24 px, ou 18×16 px abaixo de 782 px | `f3-section` com h2 e `f3-lead`, sem faixa; `f3-actions` no pé |
| 8 | selos `.f3-badge` com `--success`, `--attention`, `--error` e `--neutral` | ícone ✓, !, × ou – num círculo antes do texto; bordas `#b8e6c4`, `#f0d48a`, `#f1c0c1` | `f3-pill` com `is-ok`, `is-warn`, `is-error` ou sem classe; sem ícone |
| 9 | lista de conferência `.f3-check` com `--success`, `--error` e `--neutral`, e `.f3-checklist` | o nome `f3-check` é o da caixa de marcar da folha comum | `f3-card` com `f3-pill`; a classe muda de nome na folha própria |
| 10 | passos `.f3-steps` e `.f3-step` com `--current`, `--done`, `--failed` | cores próprias | mantém o componente na folha própria, com `--f3-ok`, `--f3-error` e `--f3-accent` |
| 11 | tabelas `table.widefat.f3-stack` em `div.f3-table-wrap` (`includes/Admin/OverviewScreen.php` linha 185 e `OperationsScreen.php` linha 680) | cabeçalho sem fundo; célula com `min-width:110px` | `f3-table-scroll`; cabeçalho `#f6f7f7` |
| 12 | botões abaixo de 782 px (`.f3-actions .button`, `.f3-form > p > .button`) | `width:100%` | largura natural, com quebra de linha |
| 13 | títulos de cartão | h2 de 16 px e de 19 px | 1,3 em (16,9 px) |
| 14 | tela de revisão de serviços (`includes/SetupAdmin.php` linha 113) | h1 próprio, "Revisar serviços e recursos" | h1 com o nome exibido; "Revisar serviços e recursos" passa a h2 de um cartão |
| 15 | foco | `2px solid #135e96` | o da folha comum |

## Já está conforme

- `hr.wp-header-end` depois do cabeçalho.
- A 360 px a página não rola na horizontal; navegação e botões com 40 px abaixo de 782 px.
- Rótulo acima do campo; tabela com rolagem própria e `role="region"`.
- Grupos e subabas como links com `aria-current`.

## Aceite

A conferência da seção 7 do guia preenchida por subaba, com as capturas a 360, 768 e 1440 px; nenhum `nav.f3-subnav` no HTML; a tela abrindo em Operação › Visão geral.
