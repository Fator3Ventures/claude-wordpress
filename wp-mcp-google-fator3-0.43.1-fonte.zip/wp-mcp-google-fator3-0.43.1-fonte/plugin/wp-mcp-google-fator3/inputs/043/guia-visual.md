# Guia visual das telas dos pacotes Fator3

Nov 20, 2026 · @Fator3

As seis versões em produção desenham a mesma estrutura (cabeçalho, pílulas, subabas, cartões) com seis folhas de estilo diferentes: nenhum dos itens medidos tem o mesmo valor nos seis pacotes. Este guia fixa um valor para cada item, entrega uma folha de estilo comum (aba "Folha comum") e lista, numa aba por pacote, o que cada um muda. Substitui a referência "telas do Meta 0.26.0 e do LinkedIn 0.23.0" do Padrão de entrega, aba "Regra comum".

## 1. O que o levantamento achou

Lido em 20/11/2026: o código dos instaladores publicados no `main` (commit `b724c5c`) e os estilos computados de cada tela no Site-Teste, pelo navegador embutido, a 1440 px e em tela estreita. Durante a leitura o Site-Teste recebeu o Fator3 MCP 0.53.0 e o Meta 0.31.0; os valores abaixo são das versões da frota.

| item | Site Core 1.98.0 | MCP 0.52.0 | Google 0.40.0 | Meta 0.30.0 | LinkedIn 0.26.0 | Pipedrive 0.12.0 | padrão |
| --- | --- | --- | --- | --- | --- | --- | --- |
| classe raiz | `f3base-tela` e `f3c-painel` | `f3-mcp-admin` | `f3-google` | `f3-social` | `f3-social` | `f3pd` | `f3-ui`, junto da atual |
| largura máxima | 1560 px; 1200 px em Operação pelo submenu | 1450 px | 1320 px | 1320 px | 1320 px | 1120 px | 1320 px |
| cor de destaque | `#135e96` e `#2271b1`, fixas | `#18547e`, `#135e96` e `#2271b1`, fixas | `#135e96` e `#2271b1`, fixas | a do esquema de cores do wp-admin (`#3858e9` no Site-Teste) | `#2271b1`, fixa | `#1c4765`, `#1d6689` e `#185c65`, fixas | a do esquema do wp-admin |
| título (h1) | 23 px, peso 600; texto muda por tela | 25 px, 600 | 26 px, 600 | 23 px, 400 | 23 px, 400 | 28 px, 650 | 23 px, 400, nome exibido |
| texto base | 13 px | 14 px | 14 px | 13 px | 13 px | 13 px | 13 px |
| selo de versão | fundo `#e8f1f8`, sem borda, raio 12 px | fundo `#e8f1fa`, borda `#bbd2e6`, raio 20 px, 12 px/600 | branco, borda `#c3c4c7`, raio 999 px, 12 px/600 | branco, borda `#c3c4c7`, raio 999 px, 13 px/400 | branco, borda `#c3c4c7`, raio 20 px, 13 px/400 | fundo `#edf4f8`, borda `#c7d8e1`, raio 20 px, 12 px/600 | o do Meta |
| grupos (1º nível) | pílula de 34 px, 13 ou 14 px | pílula de 37 px | pílula de 36 px | pílula de 40 px | pílula de 33 px, 13 px | pílula de 37 px | pílula de 40 px, 14 px/600 |
| nomes dos grupos | três conjuntos, um por menu | Operação · Configurar · Suporte | Configurar · Dados · Suporte | Configurar · Dados · Suporte | Conexões · Concessões · Dados · Anúncios e publicações · Manutenção · Ajuda | Operação · Configurar · Suporte | Operação · Configurar · Dados · Suporte |
| subabas (2º nível) | traço de 2 px `#2271b1`, texto `#31526a` | traço de 3 px `#2271b1` | traço de 3 px `#2271b1` | traço de 3 px na cor do esquema | traço de 2 px `#2271b1`, 13 px | traço de 3 px `#1d6689` | o do Meta |
| cartão | raio 0, 4, 6 ou 8 px e borda `#c3c4c7` ou `#dcdcde`, conforme a tela | raio 6 px, borda `#dcdcde`, 20 px | raio 8 px, borda `#dcdcde`, 22×24 px | raio 8 px, borda `#dcdcde`, 24 px | raio 8 px, borda `#dcdcde`, 24 px | raio 8 px, borda `#ced8de`, sombra, 20×24 px | o do Meta |
| selo de estado "ok" | três desenhos: `f3base-chip--ativo`, `f3c-selo is-ok` e `f3base-config-status--ok` | `#e5f3e9` / `#155b32`, sem borda, raio 20 px | `#edfaef` / `#00653a`, borda, ícone ✓ | `#edfaef` / `#005c12`, borda `#68de7c` | `#e8f4eb` / `#14532d`, borda `#91b59a` | `#e0f4e8` / `#17542b`, sem borda, raio 30 px | o do Meta |
| lugar do aviso de outro plugin (`hr.wp-header-end`) | só em Configurações; falta em Contatos, Formulários e Medição | falta | tem | falta | falta | falta | tem |
| rótulo do campo | à esquerda (`form-table`) em Configurações; acima nas outras telas | acima | acima | acima | acima | acima | acima |
| largura da página num telefone de 360 px | 660 px em Contatos, Formulários e Medição; 507 px em Configurações | 661 px | 360 px | 360 px | 360 px | 641 px | 360 px |
| altura dos itens de navegação abaixo de 782 px | 26 a 34 px | 37 px | 40 px | 40 px | 30 px | 35 px | 44 px |

**Por que a página alarga no telefone.** Onde falta o `hr.wp-header-end`, o WordPress põe o aviso de outro plugin dentro do cabeçalho, entre o título e a descrição. O aviso do PublishPress Authors traz um botão que não quebra linha (483 px) e empurra o selo de versão para fora da tela. Meta e LinkedIn seguram 360 px porque mandam os botões quebrarem linha.

**Por que os pacotes divergem.** O padrão de 14/11 foi pedido por descrição, e cada pacote o reescreveu na própria folha; as duas telas de referência já diferiam entre si no raio do selo, na cor de destaque e na navegação.

### Dentro do Site Core

O Site Core tem seis folhas de administração e três famílias de classes (`f3base-*`, `f3c-*`, `f3m-*`). As telas diferem assim:

| tela | endereço | título | navegação | cartão | tabela e campo |
| --- | --- | --- | --- | --- | --- |
| Configurações | `page=base-site-core-fator3` | "Fator3 Site Core", peso 600 | 3 pílulas, 8 seções com rótulo de grupo, 7 itens num terceiro nível e um índice de grupos | `f3base-config-grupo`: raio 0, borda `#c3c4c7`, sombra | 87 de 90 campos em `form-table`; cabeçalho de tabela sem fundo, peso 400 |
| Informações técnicas | `&aba=tecnica` | o mesmo | 3 pílulas e índice | `f3base-tecnica-secao` raio 0; `f3base-saude-card` e `f3base-bloco` raio 4 px | selos `f3base-chip`, 23 tabelas |
| Operação, pelo submenu | `page=f3base-operacao` | peso 400 | abas cinza nativas do WordPress; subabas como links soltos | `f3base-bloco` raio 4 px; largura 1200 px; selo de versão cinza, raio 4 px | tabela sem rolagem própria |
| Contatos | `page=f3base-leads` | "Contatos", com "Fator3 Site Core" acima | 3 pílulas de 13 px e 3 subabas | `f3c-cartao`: raio 8 px, borda `#c3c4c7`, 18 px | rótulo acima do campo |
| Formulários | `page=f3base-formularios` | "Formulários" | 3 pílulas | sem cartão | tabela solta em `f3base-editor`, 1080 px, sem rolagem própria |
| Medição | `page=f3base-medicao` | "Relatórios"; o menu e a aba do navegador dizem "Medição" | 9 pílulas em dois grupos com rótulo, mais subabas | `f3m-card`: raio 6 px, borda `#c3c4c7`, 20 px | cabeçalho de tabela `#f0f0f1` ou `#f6f7f7`, peso 600; campos de 25 a 27 px |

Operação pelo submenu sai diferente porque `f3base-interface.css` só é carregada para uma lista de páginas que não inclui `f3base-operacao` (`includes/class-f3base-interface.php`, linha 62, e `includes/bootstrap-hooks.php`, linha 422).

## 2. Fundamentos

Toda tela de pacote usa a aparência nativa do wp-admin: a fonte, os botões e os campos do WordPress e as cores da paleta dele. O design system de cada marca vale para o site público, não para tela de pacote, que precisa servir a qualquer site e a outros mantenedores.

**Cor de destaque: a do esquema de cores do wp-admin.** Os botões primários do WordPress já usam essa cor. Com cor fixa no pacote, o botão e a pílula ativa saem de cores diferentes na mesma tela: no Site-Teste (esquema Moderno), o botão é `#3858e9` e a pílula do Site Core é `#135e96`.

| variável | valor | onde se usa |
| --- | --- | --- |
| `--f3-accent` | `var(--wp-admin-theme-color, #2271b1)` | pílula ativa, traço da subaba ativa, contorno de foco, barra de informação |
| `--f3-text` | `#1d2327` | texto |
| `--f3-muted` | `#50575e` | descrição, nota de campo, rótulo secundário |
| `--f3-border` | `#dcdcde` | borda de cartão, linha de tabela |
| `--f3-border-strong` | `#c3c4c7` | borda de pílula e de selo, linha sob as subabas |
| `--f3-surface` | `#fff` | fundo de cartão |
| `--f3-subtle` | `#f6f7f7` | cabeçalho de tabela, bloco de código, selo neutro |
| `--f3-divider` | `#f0f0f1` | divisor fino, opção marcada do alternador |

Cores de estado, as mesmas no selo, na barra lateral e no aviso:

| estado | fundo | borda do selo | texto | barra lateral | contraste texto/fundo |
| --- | --- | --- | --- | --- | --- |
| ok | `#edfaef` | `#68de7c` | `#005c12` | `#00a32a` | 7,7:1 |
| atenção | `#fcf9e8` | `#dba617` | `#614200` | `#dba617` | 8,7:1 |
| erro | `#fcf0f1` | `#e65054` | `#8a2424` | `#d63638` | 8,0:1 |
| informação | `#f0f6fc` | `#72aee6` | `#0a4b78` | cor de destaque | 8,4:1 |
| neutro | `#f6f7f7` | `#c3c4c7` | `#1d2327` | `#c3c4c7` | 14,8:1 |

Medidas:

| item | valor |
| --- | --- |
| largura máxima da tela | 1320 px |
| largura de texto corrido | 80 caracteres (`80ch`) |
| largura de formulário em grade | 880 px, colunas de 300 px ou mais |
| escala de espaço | 4, 8, 12, 16 e 24 px |
| raio | cartão 8 px; bloco interno, bloco recolhível e conjunto de campos 6 px; código e cartão de número 4 px; pílula e selo 999 px |
| borda | 1 px; barra de estado à esquerda, 4 px |
| sombra | nenhuma em cartão; só no aviso de resultado fixo |

Texto:

| elemento | tamanho e peso |
| --- | --- |
| título da tela (h1) | 23 px, peso 400: o nativo de `.wrap h1`, que o pacote não redefine |
| título de cartão (h2) | 1,3 em (16,9 px), peso 600 |
| subtítulo (h3) | 1,1 em (14,3 px), peso 600 |
| texto, tabela e rótulo de campo | 13 px; rótulo com peso 600 |
| pílula e subaba | 14 px; peso 600 na pílula, 500 na subaba, 600 na subaba ativa |
| selo de estado, nota de campo, rótulo de cartão de número | 12 px |
| selo de versão | 13 px, peso 400 |
| código | Consolas, Monaco, monospace |

A folha própria do pacote não traz cor, raio nem espaço fora dessas tabelas. O valor que faltar entra primeiro neste guia e na folha comum.

## 3. Estrutura da tela

Toda tela tem os mesmos blocos, na mesma ordem, de cima para baixo:

1. Cabeçalho: o nome exibido do pacote no h1, uma linha que diz o que a tela faz e o selo "Versão X.Y.Z" à direita.
2. `<hr class="wp-header-end">`: é depois dele que o WordPress põe os avisos de outros plugins.
3. Grupos, em pílulas.
4. Subabas do grupo ativo, sublinhadas.
5. Aviso de resultado da última ação, quando houver.
6. Cartões de conteúdo.

```html
<div class="wrap f3-ui f3-social">
  <header class="f3-heading">
    <h1>Fator3 MCP Meta</h1>
    <p>Conecte a conta, escolha os ativos e acompanhe as coletas deste site.</p>
    <span class="f3-version">Versão 0.30.0</span>
  </header>
  <hr class="wp-header-end">
  <nav class="f3-nav" aria-label="Fator3 MCP Meta">
    <div class="f3-groups">
      <a href="…&amp;grupo=configurar" aria-current="true">Configurar</a>
      <a href="…&amp;grupo=dados">Dados</a>
      <a href="…&amp;grupo=suporte">Suporte</a>
    </div>
    <div class="f3-subtabs" aria-label="Configurar">
      <a href="…&amp;aba=conexao" aria-current="page">Conexão</a>
      <a href="…&amp;aba=ativos">Ativos</a>
    </div>
  </nav>
  <section class="f3-section">…</section>
</div>
```

O h1, a descrição e o selo são filhos diretos do `header`, sem `div` em volta. A classe raiz atual do pacote fica ao lado de `f3-ui`.

### Cabeçalho

- O h1 é o nome exibido do pacote, igual em todas as telas dele. O nome da área aparece na pílula ativa e no título da aba do navegador, não no h1.
- A descrição é uma frase que começa por verbo ("Configure…", "Acompanhe…") e muda com o grupo aberto.
- O selo traz só "Versão X.Y.Z". O cabeçalho não leva botão nem selo de estado.

### Navegação

Há dois níveis: grupos e subabas. Nos pacotes de conector (Fator3 MCP, Google, Meta, LinkedIn e Pipedrive) os grupos têm estes nomes, nesta ordem; grupo sem conteúdo não aparece.

| grupo | o que guarda |
| --- | --- |
| Operação | visão geral do estado, atividade, incidentes, filas, entregas, diário |
| Configurar | conexão, credenciais, ativos, concessões, permissões, regras |
| Dados | relatórios, coletas, histórico, acervo, exportação |
| Suporte | diagnóstico, manutenção, retenção, ajuda e documentação |

- A tela abre em Operação › Visão geral. Pacote sem o grupo Operação abre na primeira subaba de Configurar.
- Cada grupo tem até sete subabas; acima disso, as subabas se separam em conjuntos com rótulo (`f3-subtabs-label`), como o Site Core já faz. Grupo com uma subaba só não mostra a linha de subabas.
- Grupo e subaba são links com endereço próprio e `aria-current` no ativo. O endereço antigo de cada aba continua abrindo a mesma tela.
- A linha quebra quando não cabe; nenhum item fica em rolagem horizontal.
- Não há terceiro nível de navegação. O que hoje é terceiro nível vira uma destas três formas: alternador de visão dentro do cartão (`f3-switch`, até cinco botões); cartões-índice na subaba, cada um levando ao detalhe com "Voltar"; ou blocos recolhíveis na mesma página.
- O Site Core, que tem mais de uma página de menu, mostra as áreas do próprio menu como grupos, as mesmas em todas as telas (aba "Fator3 Site Core").

### Conteúdo

- Cada assunto fica num cartão (`f3-section`) com título (h2), uma frase de orientação e as ações no fim. Nada fica solto fora de cartão, salvo o aviso de resultado.
- Dentro da subaba, a ordem é: estado atual, ação mais comum, opções avançadas em bloco recolhido.
- Cada cartão tem uma ação primária (`button button-primary`); as outras são `button`. Ação que apaga ou revoga fica num bloco recolhível `f3-danger` e pede confirmação.

## 4. Componentes

Cada necessidade tem um componente, com uma classe da folha comum. O pacote não cria outro desenho para a mesma função.

| componente | classe | quando se usa | regra |
| --- | --- | --- | --- |
| cartão | `f3-section` | cada assunto da subaba | título (h2), frase de orientação (`f3-lead`) e ações; raio 8 px; 24 px de espaço interno, 16 px abaixo de 600 px |
| cartão interno | `f3-card`, em grade `f3-cards` | itens repetidos dentro de um cartão: conexões, serviços, atalhos | raio 6 px; não se põe cartão dentro de cartão interno |
| bloco recolhível | `details.f3-collapsible` | opções avançadas, detalhe técnico | fechado por padrão; o resumo mostra o valor atual (`f3-summary-value`) |
| zona de risco | `details.f3-collapsible.f3-danger` | apagar, revogar, desconectar | barra vermelha; confirmação antes do efeito |
| selo de estado | `f3-pill` com `is-ok`, `is-warn`, `is-error` ou `is-info` | todo estado: conexão, coleta, módulo, credencial | cor e texto juntos; texto curto ("Conectado", "Pendente", "Falhou"); sem classe de estado é neutro |
| cartão de número | `f3-stat`, em grade `f3-stats` | totais e contadores da visão geral | rótulo de 12 px em cima, valor de 15 px embaixo; barra lateral na cor do estado |
| aviso em linha | `f3-callout` com o estado | orientação ou pendência dentro do cartão | barra de 4 px e fundo do estado; uma frase e, se houver, a ação |
| aviso de resultado | `f3-result`; `is-error` na falha | resposta de salvar, testar ou coletar | fixo sob a barra do wp-admin; `role="status"`, ou `role="alert"` na falha; botão Dispensar |
| estado vazio | `f3-empty` | lista ou tabela sem itens | uma frase que diz o que falta e o botão que resolve |
| campo | `f3-field`, em grade `f3-grid` | todo campo de formulário | rótulo acima, nota abaixo (`description`), 36 px de altura; sem `form-table` |
| conjunto de campos | `fieldset.f3-fieldset` | campos que se salvam juntos | `legend` com o nome do conjunto |
| caixa de marcar | `label.f3-check` | sim ou não | rótulo à direita da caixa; a explicação vai na nota |
| ações | `f3-actions` | botões do cartão | a primária primeiro; a situação da ação ao lado, em `role="status"` |
| botão | `button`, `button-primary` e `button-link`, do WordPress | toda ação | o pacote não desenha botão próprio; o que executa ação é `button`, o que navega é link |
| barra de salvar | `f3-savebar` | formulário mais alto que a tela | fixa no pé do formulário; botão primário e a situação ("Alterações não salvas") |
| ferramentas de lista | `f3-list-tools` | lista ou tabela com mais de 20 linhas | busca, total "1–20 de 134" (`f3-list-total`) e Anterior/Próxima |
| tabela | `table.widefat` dentro de `f3-table-scroll` | dados tabulares | cabeçalho com fundo `#f6f7f7` e peso 600; número à direita (`f3-num`); abaixo de 782 px rola dentro do próprio bloco |
| lista de pares | `dl.f3-details` | ficha de um item, rótulo e valor | duas colunas; uma abaixo de 600 px |
| alternador de visão | `f3-switch` | trocar a visão dentro do cartão | botões `button` com `aria-pressed`; até cinco |
| código | `code` e `pre` | identificador, endereço, JSON | botão Copiar ao lado quando o valor se copia |

## 5. Texto

- Português com acento, em frases completas. O identificador técnico (option, rota, id) aparece entre `code`, ao lado do nome em palavras, nunca no lugar dele.
- Função se chama pelo que faz, sem código de cadência comercial.
- Rótulo de botão: verbo no infinitivo e o objeto ("Salvar conexão", "Testar envio", "Coletar agora").
- Título de cartão: substantivo, sem ponto final, maiúscula só na primeira palavra.
- Mensagem de erro: o que aconteceu, o motivo quando conhecido e o que fazer; o código do erro vai no fim, entre `code`.
- Data e hora: "20/11/2026 14:32", no fuso do site; "há 3 h" só como complemento.
- Número: milhar com ponto, decimal com vírgula.

O mesmo estado tem o mesmo texto em todos os pacotes:

| estado | texto do selo |
| --- | --- |
| ok | Ativo (módulo, agenda) · Conectado (conta) · Concluído (coleta, tarefa) |
| atenção | Pendente · Parcial · Vence em N dias |
| erro | Falhou · Recusado · Expirado |
| informação | Em andamento · Agendado |
| neutro | Desligado · Não configurado · Não se aplica |

## 6. Tela estreita e acessibilidade

- A tela se prova a 360, 768 e 1440 px. Em nenhuma largura a página rola na horizontal; só tabela e bloco de código rolam, dentro do próprio bloco.
- As quebras são 782 px, a do wp-admin, e 600 px. Abaixo de 782 px, botões e campos têm 40 px de altura e itens de navegação, 44 px. Abaixo de 600 px, as grades caem para uma coluna e o cartão passa a 16 px de espaço interno.
- Botão quebra linha em vez de alargar a página, inclusive o botão de aviso de outro plugin dentro da tela.
- Todo link, botão, campo e resumo de bloco recolhível mostra o foco do teclado: contorno de 2 px na cor de destaque.
- O texto tem contraste de 4,5:1 ou mais. Nenhum estado é dito só pela cor.
- A navegação fica em `nav` com `aria-label`, e o item ativo leva `aria-current`. O aviso de resultado leva `role="status"` ou `role="alert"`. Todo campo tem `label` ligado por `for`.
- A navegação funciona sem JavaScript, porque grupos e subabas são links.
- A tela não carrega fonte, ícone nem script de fora do site.

## 7. Entrega e prova

- **Folha comum.** Cada pacote traz `assets/f3-ui.css` com o texto da aba "Folha comum", sem mudança, carregada só nas telas do pacote e antes da folha própria. O relatório da entrega cita o sha256 do arquivo, e a frota confere que os seis são iguais.
- **Folha própria.** A folha do pacote só posiciona o conteúdo próprio dele e usa as variáveis `--f3-*`. Não redefine variável nem componente da folha comum. A classe antiga que tem equivalente sai do HTML e da folha na mesma entrega, e a classe do pacote que tem o nome de um componente comum e outro uso muda de nome.
- **O que não muda.** Slug da tela, capacidade, rotas, dados e nomes de option. O endereço antigo de cada aba redireciona para o novo.
- **Prova.** O relatório traz as capturas de cada subaba a 360, 768 e 1440 px, tiradas com um aviso de outro plugin ativo na tela, e a conferência abaixo.

| # | conferência | como se mede |
| --- | --- | --- |
| 1 | `assets/f3-ui.css` igual à folha comum | sha256 do arquivo no instalador |
| 2 | raiz com `f3-ui`; cabeçalho `f3-heading` com o nome exibido no h1, a descrição e `f3-version` | HTML da tela |
| 3 | `hr.wp-header-end` depois do cabeçalho; aviso de outro plugin fora do cabeçalho | HTML com um aviso ativo |
| 4 | grupos com os nomes e a ordem do guia; até sete subabas; nenhum terceiro nível de navegação | tela |
| 5 | pílula ativa e traço da subaba na cor do esquema do wp-admin | trocar o esquema de cores do usuário e recarregar |
| 6 | todo estado em `f3-pill` com classe de estado | busca das classes antigas de selo no HTML |
| 7 | nenhum campo em `form-table`; rótulo acima do campo | busca no HTML |
| 8 | toda tabela dentro de `f3-table-scroll`; lista com mais de 20 linhas com busca, total e paginação | HTML |
| 9 | a 360, 768 e 1440 px, `document.documentElement.scrollWidth` igual a `innerWidth` | console |
| 10 | abaixo de 782 px, navegação com 44 px e botões e campos com 40 px | console |
| 11 | foco visível em navegação, botões, campos e resumos | tecla Tab |
| 12 | folha própria sem cor, raio ou espaço fora das variáveis | busca por `#` e por `px` na folha |

Só o projeto "Site Geral | Todos" edita este guia. Mudança no padrão muda a folha comum, sobe a versão dela e vira pedido aos seis pacotes. O Fator3 Implantador segue o mesmo guia; a tela dele não foi lida neste levantamento, porque o pacote não fica instalado nos sites.
