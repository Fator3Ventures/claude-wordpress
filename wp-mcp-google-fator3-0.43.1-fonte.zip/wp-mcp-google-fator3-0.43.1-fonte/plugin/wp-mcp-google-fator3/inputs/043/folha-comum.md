# Folha comum — `assets/f3-ui.css`

Versão 1.0.0 da folha que todo pacote traz igual, com 11.886 bytes e sha256 `15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b` (fim de linha LF, com quebra de linha no final). As regras de cabeçalho, navegação, cartão, selo, grade e tela estreita vêm da folha do Fator3 MCP Meta 0.30.0, com as cores em variáveis.

**Ensaio.** Em 20/11/2026, no Site-Teste, as regras de cabeçalho, navegação, cartão, selo, grade e campo foram aplicadas sobre a tela do Fator3 MCP Meta, com a folha do Meta também carregada. A 360 e a 768 px a página ficou sem rolagem horizontal, a navegação com 44 px, os botões com 40 px e o aviso de outro plugin fora do cabeçalho. Tabela, ferramentas de lista, barra de salvar, aviso de resultado, cartão de número, bloco recolhível e estado vazio não foram ensaiados; a primeira entrega de pacote os prova.

**Como se carrega.** `wp_enqueue_style( '<slug>-f3-ui', plugins_url( 'assets/f3-ui.css', <arquivo principal> ), array(), '1.0.0' )`, só nas telas do pacote; a folha própria declara `<slug>-f3-ui` como dependência.

```css
/* f3-ui 1.0.0 — folha comum das telas dos pacotes Fator3. Igual, byte a byte, em todos os pacotes. Não editar no pacote: a mudança entra pelo Guia visual. */
.f3-ui{--f3-accent:var(--wp-admin-theme-color,#2271b1);--f3-accent-dark:var(--wp-admin-theme-color-darker-10,#135e96);--f3-text:#1d2327;--f3-muted:#50575e;--f3-border:#dcdcde;--f3-border-strong:#c3c4c7;--f3-surface:#fff;--f3-subtle:#f6f7f7;--f3-divider:#f0f0f1;--f3-ok:#00a32a;--f3-ok-bg:#edfaef;--f3-ok-line:#68de7c;--f3-ok-text:#005c12;--f3-warn:#dba617;--f3-warn-bg:#fcf9e8;--f3-warn-text:#614200;--f3-error:#d63638;--f3-error-bg:#fcf0f1;--f3-error-line:#e65054;--f3-error-text:#8a2424;--f3-info-bg:#f0f6fc;--f3-info-line:#72aee6;--f3-info-text:#0a4b78;--f3-radius:8px;--f3-radius-inner:6px;--f3-s1:4px;--f3-s2:8px;--f3-s3:12px;--f3-s4:16px;--f3-s5:24px;--f3-touch:30px;max-width:1320px;color:var(--f3-text)}
.f3-ui *,.f3-ui *::before,.f3-ui *::after{box-sizing:border-box}
.f3-ui [hidden]{display:none!important}
.f3-ui :is(a,button,summary,select,input,textarea,[tabindex]):focus-visible{outline:2px solid var(--f3-accent);outline-offset:2px;box-shadow:none}
.f3-ui :is(input,select,textarea,img,pre){max-width:100%}

/* 1. Cabeçalho: título, linha de descrição e versão */
.f3-ui .f3-heading{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:var(--f3-s1) var(--f3-s3);align-items:center;margin:var(--f3-s2) 0 var(--f3-s1)}
.f3-ui .f3-heading h1{grid-column:1;grid-row:1;margin:0;padding:9px 0 0}
.f3-ui .f3-heading p{grid-column:1/-1;grid-row:2;margin:0;max-width:80ch;color:var(--f3-muted)}
.f3-ui .f3-version{grid-column:2;grid-row:1;justify-self:end;margin-top:var(--f3-s2);padding:var(--f3-s1) var(--f3-s3);border:1px solid var(--f3-border-strong);border-radius:999px;background:var(--f3-surface);color:var(--f3-text);font-size:13px;font-weight:400;line-height:1.5;white-space:nowrap}
.f3-ui>.notice{max-width:100%;overflow-wrap:anywhere}
.f3-ui>.notice .button{white-space:normal;height:auto;max-width:100%}

/* 2. Navegação em dois níveis: grupos em pílulas, subabas sublinhadas */
.f3-ui .f3-nav{margin:var(--f3-s4) 0 0}
.f3-ui .f3-groups{display:flex;flex-wrap:wrap;gap:var(--f3-s2)}
.f3-ui .f3-groups a{display:inline-flex;align-items:center;min-height:40px;padding:0 var(--f3-s4);border:1px solid var(--f3-border-strong);border-radius:999px;background:var(--f3-surface);color:var(--f3-text);font-size:14px;font-weight:600;text-decoration:none}
.f3-ui .f3-groups a:hover{border-color:var(--f3-accent)}
.f3-ui .f3-groups a[aria-current]{background:var(--f3-accent);border-color:var(--f3-accent);color:#fff}
.f3-ui .f3-subtabs{display:flex;flex-wrap:wrap;gap:0 var(--f3-s1);margin-top:var(--f3-s2);border-bottom:1px solid var(--f3-border-strong)}
.f3-ui .f3-subtabs a{display:inline-flex;align-items:center;min-height:40px;padding:0 var(--f3-s3);margin-bottom:-1px;border-bottom:3px solid transparent;color:var(--f3-text);font-size:14px;font-weight:500;text-decoration:none}
.f3-ui .f3-subtabs a:hover{color:var(--f3-accent)}
.f3-ui .f3-subtabs a[aria-current]{border-bottom-color:var(--f3-accent);font-weight:600}
.f3-ui .f3-subtabs-label{align-self:center;padding:0 var(--f3-s2) 0 0;color:var(--f3-muted);font-size:12px;font-weight:600}
.f3-ui :is(.f3-groups,.f3-subtabs) a:focus-visible{outline-offset:-2px}
/* Alternador de visão dentro do cartão (terceiro nível) */
.f3-ui .f3-switch{display:flex;flex-wrap:wrap;gap:var(--f3-s2);margin:var(--f3-s3) 0 var(--f3-s1)}
.f3-ui .f3-switch .button{margin:0}
.f3-ui .f3-switch .button:is([aria-pressed=true],[aria-current]){background:var(--f3-divider);border-color:var(--f3-accent);color:var(--f3-text);box-shadow:inset 0 -3px 0 var(--f3-accent);font-weight:600}

/* 3. Cartões */
.f3-ui .f3-section{min-width:0;margin-top:var(--f3-s4);padding:var(--f3-s5);border:1px solid var(--f3-border);border-radius:var(--f3-radius);background:var(--f3-surface)}
.f3-ui .f3-section>:first-child{margin-top:0}
.f3-ui .f3-section>:last-child{margin-bottom:0}
.f3-ui .f3-card{min-width:0;margin-top:var(--f3-s3);padding:var(--f3-s4) 20px;border:1px solid var(--f3-border);border-radius:var(--f3-radius-inner);background:var(--f3-surface)}
.f3-ui .f3-card>:first-child{margin-top:0}
.f3-ui h2{font-size:1.3em;font-weight:600;line-height:1.4}
.f3-ui h3{font-size:1.1em;font-weight:600;line-height:1.4}
.f3-ui .f3-lead,.f3-ui .description{max-width:80ch;color:var(--f3-muted);line-height:1.5}
.f3-ui .f3-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));gap:var(--f3-s3)}
.f3-ui .f3-cards>.f3-card{margin:0;display:flex;flex-direction:column}
.f3-ui .f3-cards>.f3-card>.f3-actions{margin-top:auto;padding-top:var(--f3-s3)}
.f3-ui .f3-actions{display:flex;flex-wrap:wrap;align-items:center;gap:var(--f3-s2) var(--f3-s3);margin-top:var(--f3-s4)}
.f3-ui .f3-actions>:is(.button,button,a){margin:0}
.f3-ui details.f3-collapsible{margin:var(--f3-s2) 0 0;padding:0 20px;border:1px solid var(--f3-border);border-radius:var(--f3-radius-inner);background:var(--f3-surface)}
.f3-ui details.f3-collapsible>summary{display:flex;flex-wrap:wrap;align-items:center;gap:var(--f3-s1) var(--f3-s3);min-height:44px;padding:6px 0;font-weight:600;cursor:pointer;list-style:none}
.f3-ui details.f3-collapsible>summary::-webkit-details-marker{display:none}
.f3-ui details.f3-collapsible>summary::before{content:"▸";display:inline-block;width:1em;color:var(--f3-muted)}
.f3-ui details.f3-collapsible[open]>summary::before{content:"▾"}
.f3-ui details.f3-collapsible[open]{padding-bottom:var(--f3-s4)}
.f3-ui .f3-summary-value{font-weight:400;color:var(--f3-muted)}
.f3-ui details.f3-danger{border-left:4px solid var(--f3-error);background:var(--f3-error-bg)}

/* 4. Estado: selo com cor e texto, cartão de número e aviso */
.f3-ui .f3-pill{display:inline-block;max-width:100%;padding:1px var(--f3-s2);border:1px solid var(--f3-border-strong);border-radius:999px;background:var(--f3-subtle);color:var(--f3-text);font-size:12px;font-weight:500;line-height:1.7}
.f3-ui .f3-pill.is-ok{background:var(--f3-ok-bg);border-color:var(--f3-ok-line);color:var(--f3-ok-text)}
.f3-ui .f3-pill.is-warn{background:var(--f3-warn-bg);border-color:var(--f3-warn);color:var(--f3-warn-text)}
.f3-ui .f3-pill.is-error{background:var(--f3-error-bg);border-color:var(--f3-error-line);color:var(--f3-error-text)}
.f3-ui .f3-pill.is-info{background:var(--f3-info-bg);border-color:var(--f3-info-line);color:var(--f3-info-text)}
.f3-ui .f3-stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,190px),1fr));gap:var(--f3-s3);margin:var(--f3-s3) 0}
.f3-ui .f3-stat{display:flex;flex-direction:column;gap:2px;padding:10px 14px;border:1px solid var(--f3-border);border-left:4px solid var(--f3-border-strong);border-radius:4px;background:var(--f3-surface)}
.f3-ui .f3-stat.is-ok{border-left-color:var(--f3-ok)}
.f3-ui .f3-stat.is-warn{border-left-color:var(--f3-warn)}
.f3-ui .f3-stat.is-error{border-left-color:var(--f3-error)}
.f3-ui .f3-stat-label{font-size:12px;color:var(--f3-muted)}
.f3-ui .f3-stat-value{font-size:15px;font-weight:600}
.f3-ui .f3-callout{margin:var(--f3-s3) 0 0;padding:10px var(--f3-s3);border-left:4px solid var(--f3-accent);background:var(--f3-info-bg)}
.f3-ui .f3-callout.is-ok{border-left-color:var(--f3-ok);background:var(--f3-ok-bg)}
.f3-ui .f3-callout.is-warn{border-left-color:var(--f3-warn);background:var(--f3-warn-bg)}
.f3-ui .f3-callout.is-error{border-left-color:var(--f3-error);background:var(--f3-error-bg)}
.f3-ui .f3-result{position:sticky;top:40px;z-index:30;display:flex;align-items:flex-start;gap:var(--f3-s2);margin:var(--f3-s4) 0 0;padding:var(--f3-s1) var(--f3-s1) var(--f3-s1) var(--f3-s3);border:1px solid var(--f3-border-strong);border-left:4px solid var(--f3-ok);background:var(--f3-surface);box-shadow:0 2px 8px rgba(0,0,0,.12)}
.f3-ui .f3-result.is-error{border-left-color:var(--f3-error)}
.f3-ui .f3-result p{flex:1;margin:0;padding:var(--f3-s2) 0;overflow-wrap:anywhere}
.f3-ui .f3-empty{padding:var(--f3-s5) var(--f3-s4);border:1px dashed var(--f3-border-strong);border-radius:var(--f3-radius-inner);color:var(--f3-muted);text-align:center}

/* 5. Formulário: rótulo acima do campo, em grade */
.f3-ui .f3-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));gap:var(--f3-s4) 20px;max-width:880px;margin:var(--f3-s3) 0 var(--f3-s4)}
.f3-ui .f3-grid.is-wide{max-width:none;grid-template-columns:repeat(auto-fill,minmax(min(100%,240px),1fr))}
.f3-ui .f3-field{display:grid;align-content:start;gap:6px;min-width:0;max-width:520px;margin:var(--f3-s3) 0}
.f3-ui .f3-grid>.f3-field{max-width:none;margin:0}
.f3-ui .f3-field>label,.f3-ui .f3-field>.f3-label{font-weight:600}
.f3-ui .f3-field>:is(input:not([type=checkbox]):not([type=radio]),select,textarea){width:100%;min-height:36px;margin:0}
.f3-ui .f3-field .description{margin:0;font-size:12px}
.f3-ui .f3-check{display:inline-flex;align-items:center;gap:6px;font-weight:400}
.f3-ui .f3-check input{flex:none;margin:0}
.f3-ui fieldset.f3-fieldset{min-width:0;margin:14px 0 0;padding:var(--f3-s2) 20px 14px;border:1px solid var(--f3-border);border-radius:var(--f3-radius-inner)}
.f3-ui fieldset.f3-fieldset>legend{padding:0 6px;font-weight:600}
.f3-ui .f3-savebar{position:sticky;bottom:0;z-index:20;display:flex;flex-wrap:wrap;align-items:center;gap:var(--f3-s2) var(--f3-s3);margin-top:var(--f3-s4);padding:10px 0;border-top:1px solid var(--f3-border-strong);background:var(--f3-surface)}

/* 6. Lista e tabela: busca, total, paginação e rolagem própria */
.f3-ui .f3-list-tools{display:flex;flex-wrap:wrap;align-items:flex-end;gap:var(--f3-s2) var(--f3-s3);margin:var(--f3-s3) 0}
.f3-ui .f3-list-tools label{display:grid;gap:var(--f3-s1);font-weight:600}
.f3-ui .f3-list-tools input[type=search]{width:min(100%,360px);min-height:36px}
.f3-ui .f3-list-total{margin:0 auto 0 0;align-self:center;color:var(--f3-muted);font-variant-numeric:tabular-nums}
.f3-ui .f3-table-scroll{min-width:0;max-width:100%;overflow:auto;overscroll-behavior-x:contain}
.f3-ui .f3-table-scroll table{width:100%;margin:0;border-collapse:collapse}
.f3-ui .f3-table-scroll :is(th,td){padding:10px;border-bottom:1px solid var(--f3-border);text-align:left;vertical-align:top;overflow-wrap:normal;word-break:normal;hyphens:none}
.f3-ui .f3-table-scroll th{background:var(--f3-subtle);font-weight:600;white-space:nowrap}
.f3-ui .f3-num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.f3-ui .f3-details{display:grid;grid-template-columns:minmax(130px,1fr) minmax(180px,3fr);gap:var(--f3-s2) 20px;margin:14px 0}
.f3-ui .f3-details dt{font-weight:600}
.f3-ui .f3-details dd{margin:0;overflow-wrap:anywhere}
.f3-ui pre,.f3-ui code{font-family:Consolas,Monaco,monospace}
.f3-ui pre{overflow:auto;padding:var(--f3-s3) var(--f3-s4);border:1px solid var(--f3-border);border-radius:4px;background:var(--f3-subtle)}

/* 7. Tela estreita: quebra do wp-admin em 782 px e telefone em 600 px */
@media (max-width:782px){
.f3-ui{--f3-touch:40px}
.f3-ui :is(.button,button){min-height:40px;max-width:100%;height:auto;white-space:normal}
.f3-ui :is(.f3-groups,.f3-subtabs) a{min-height:44px}
.f3-ui .f3-result{top:54px}
.f3-ui .f3-table-scroll table{width:max-content;min-width:100%}
.f3-ui .f3-table-scroll :is(th,td){max-width:32rem}
}
@media (max-width:600px){
.f3-ui .f3-version{margin-top:var(--f3-s2);font-size:11px}
.f3-ui .f3-section{padding:var(--f3-s4)}
.f3-ui .f3-card{padding:var(--f3-s3)}
.f3-ui details.f3-collapsible{padding:0 var(--f3-s3)}
.f3-ui fieldset.f3-fieldset{padding:10px var(--f3-s3) var(--f3-s3)}
.f3-ui .f3-grid,.f3-ui .f3-grid.is-wide{grid-template-columns:minmax(0,1fr)}
.f3-ui .f3-details{grid-template-columns:minmax(0,1fr)}
.f3-ui .f3-stats{grid-template-columns:repeat(2,minmax(0,1fr))}
.f3-ui .f3-groups a{padding:0 var(--f3-s3)}
.f3-ui .f3-subtabs a{padding:0 10px}
.f3-ui .f3-result{top:8px}
}
```
