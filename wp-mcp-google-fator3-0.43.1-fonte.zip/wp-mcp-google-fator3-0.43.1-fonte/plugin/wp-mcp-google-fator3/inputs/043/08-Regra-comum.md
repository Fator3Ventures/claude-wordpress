# Padrão de entrega dos pacotes Fator3

Oct 16, 2026 · @Fator3

Cada versão de um pacote Fator3 sai com três arquivos de nome fixo, o cabeçalho de plugin fixo e um relatório que identifica os arquivos pelo sha256. Cada aba de pacote é autossuficiente e se entrega direto ao agente responsável por ele; esta aba traz a regra comum e a conformidade dos pacotes.

## Arquivos de cada versão

Toda versão sai com três arquivos, no padrão `<slug>-<versão>-<tipo>` (dono, 01/10/2026).

| tipo | nome | conteúdo |
| --- | --- | --- |
| instalador | `<slug>-<versão>-instalador.zip` | pasta interna `<slug>/`, com o arquivo principal `<slug>/<slug>.php`; é o único que se instala |
| fonte | `<slug>-<versão>-fonte.zip` | pasta interna `<slug>-<versão>-fonte/`: código, testes, ferramentas de build, evidências e uma cópia do relatório; nunca se instala |
| relatório | `<slug>-<versão>-relatorio.md` | Markdown, em português, com o conteúdo da seção "Relatório" |

- Versão `X.Y.Z`, sem sufixo. Homologação, validação e sha256 ficam no relatório, nunca no nome.
- Um relatório por pacote, também quando dois pacotes saem na mesma entrega. Encaminhamento a outro pacote vai numa seção do relatório.
- Arquivo a mais (lista de sha256, encaminhamento) leva o prefixo `<slug>-<versão>-` e não repete o conteúdo dos três; nenhum ZIP contém os outros.
- O relatório cita os arquivos pelo nome final, o mesmo que o dono recebe.
- Versão já publicada não se renomeia.
- Nenhum dos três leva credencial, banco de laboratório, cookie ou log com dado pessoal.

## Onde ficam

1. O agente do pacote entrega os três arquivos ao dono.
2. A frota confere o sha256 do instalador contra o relatório e publica o instalador e o relatório na raiz de `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/`. O repositório é público.
3. Antes do primeiro `plugins/upload`, a frota confere o sha256 servido pelo raw. A instalação usa sempre a URL do raw com `expected_sha256` e `expected_slug`.
4. Na troca seguinte, a versão anterior sai do `main` e segue no histórico do repositório.

A fonte vai para o `main`, junto do instalador e do relatório (dono, 16/10/2026: "vai para main junto do instalador. Sempre que uma nova versão é instalada, deve ser excluído os arquivos da versão anterior"). Quando uma versão nova é instalada na frota, os três arquivos da versão anterior (instalador, fonte e relatório) saem do `main` no mesmo trabalho e ficam só no histórico do repositório. Antes de publicar, a frota confere o sha256 da fonte contra o relatório.

## Relatório: o que traz

O relatório é o que a frota lê para decidir a troca e conferir a entrega. Nesta ordem:

1. Título `Entrega — <nome exibido> <versão>`.
2. De onde a versão entra: WordPress limpo e as versões anteriores aceitas direto; versão intermediária que não se instala.
3. Versões dos outros pacotes com que a entrega foi validada e a ordem de troca entre eles, quando a entrega mexe em contrato comum.
4. O que mudou, item a item, citando o pedido atendido pelo número ("Pedidos core N", "Pedidos MCP N"), com a evidência.
5. Como instalar e como provar a troca: a rota que mostra a prontidão do pacote e o estado esperado.
6. Banco e volta de versão: o que a versão grava, se a migração retoma sozinha e o que a volta de arquivos não desfaz.
7. O que não foi exercitado ou homologado (conta real, API externa, navegador), dito como pendente.
8. Credenciais: o que o dono cola na tela. Nenhum segredo no relatório.
9. Identidade dos arquivos: nome, tamanho em bytes e sha256 do instalador e da fonte.

## Cabeçalho do plugin, tela e o que não muda

| campo | valor |
| --- | --- |
| Plugin Name | o nome exibido do pacote, começando por "Fator3" |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | o texto da aba do pacote: o que faz e onde se configura |
| Version | `X.Y.Z`, a mesma do nome dos arquivos |
| Requires at least, Requires PHP | os mínimos que o relatório validou |
| Author | Fator3 |
| Author URI | `https://www.fator3.com.br` |
| License | GPL-2.0-or-later |
| Text Domain | o atual do pacote |
| Update URI | `https://fator3.com.br/plugins/<slug>`, sem fonte de atualização publicada (dono, 01/10/2026) |

**Tela.** Em Ferramentas, ou no menu próprio que o pacote já tem, com o nome exibido no título. A tela e toda operação que lê dado de conta conectada ou grava configuração pedem `manage_options`, ou capacidade própria do pacote dada só ao administrador; nunca `read`.

**Padrão visual das telas (dono, 14/11/2026 às 11:03: "Peça esse mesmo padrão visual a todas as telas de todos os plugins").** Referência: as telas do Fator3 MCP Meta 0.26.0 e do Fator3 MCP LinkedIn 0.23.0, como estavam nos 12 sites em 14/11/2026. Toda tela de pacote segue:

1. Cabeçalho com o título (nome exibido), uma linha que diz o que a tela faz e selo "Versão X.Y.Z" à direita.
2. Navegação em dois níveis: grupos em pílulas (como Configurar · Dados · Suporte) e, dentro do grupo, subabas sublinhadas. Com mais de seis destinos, agrupar em vez de enfileirar. Nenhum destino fica escondido em rolagem horizontal; a linha quebra.
3. Conteúdo em cartões, cada um com título, texto de orientação e ações (primária e secundária).
4. Estado em selo com cor e texto (ok, atenção, informação, erro), nunca só em texto corrido.
5. Formulário com rótulo acima do campo, em grade que cai para uma coluna em tela estreita; opções avançadas em bloco recolhível.
6. Lista e tabela com busca, total ("1–20 de 134") e paginação Anterior/Próxima; abaixo de 782 px a tabela rola na horizontal dentro do próprio bloco, sem palavra partida no meio.
7. Textos em português com acento.
8. Legível de 360 a 1440 px.

Não mudam o slug da tela, a capacidade, as rotas e os dados; o endereço antigo de cada aba continua abrindo a mesma tela, redirecionado se ela mudar de grupo. Prova na entrega: capturas de cada aba a 360, 768 e 1440 px. Pedidos de 14/11/2026: core 404, MCP 81, MCP Google 53, MCP Meta 30, MCP LinkedIn 26, MCP Pipedrive 13 e implantador 29.

**O que não muda com o nome.** Slug, pasta, arquivo principal, Text Domain, Update URI, prefixos de option, tabela e rota, e os nomes das ferramentas MCP. Os conectores do Claude nos 12 sites e os documentos da frota dependem deles. A aba de cada pacote lista os dele.

## Conformidade em 09/11/2026

Os seis pacotes publicados cumprem o padrão nos três arquivos, no cabeçalho, na tela e no relatório. Lido nos instaladores, fontes e relatórios do `main` (commit `e3580d3`) em 09/11/2026; o implantador não fica no `main`, e vale a conferência da frota da 2.15.0.

| pacote | versão | instalador | arquivos, cabeçalho e tela | relatório |
| --- | --- | --- | --- | --- |
| Fator3 Site Core | 1.75.1 | 4.372.056 bytes, sha256 `9fff30dc…` | conforme; tela com `manage_options` | conforme, com o sha256 do instalador e da fonte |
| Fator3 MCP | 0.41.0 | 936.186 bytes, sha256 `4a31d227…` | conforme; tela com `manage_options` | conforme, com o sha256 do instalador e da fonte |
| Fator3 MCP Google | 0.31.0 | 947.286 bytes, sha256 `e577dd44…` | conforme; tela com `manage_options` | conforme, com o sha256 do instalador e da fonte |
| Fator3 MCP Meta | 0.21.0 | 243.040 bytes, sha256 `9589456a…` | conforme; tela com `manage_options` | conforme, com o sha256 do instalador e da fonte |
| Fator3 MCP LinkedIn | 0.19.0 | 397.354 bytes, sha256 `613cb47c…` | conforme; tela com `manage_options` | conforme, com o sha256 do instalador e da fonte |
| Fator3 MCP Pipedrive | 0.8.0 | 122.083 bytes, sha256 `89e41f2f…` | conforme; tela com `manage_options` | conforme, com o sha256 do instalador e da fonte |
| Fator3 Implantador | 2.15.0 (frota, 06/11/2026) | 509.202 bytes, sha256 `83f72c1a…` | arquivos conformes; cabeçalho não relido | conforme |

## Regras do dono para todos os pacotes

**Credencial fora do padrão esperado gera aviso, não recusa (dono, 28/10/2026 às 20:46: "o comportamento ao invés de recusar o token deve-se somente emitir um aviso de que está fora do padrão esperado. (e isso vale também para outros tokens)").** Teste local de formato (prefixo, tamanho, alfabeto, forma de outro tipo de credencial) emite aviso com código e motivo, junto do campo e na resposta da rota; quem decide é a conferência no fornecedor, e a recusa dele mantém a credencial salva. Recusa local fica só para o que não se pode guardar nem enviar com segurança (valor vazio ou que não é texto, acima do limite de tamanho, com caractere de controle) e para o que impede a tentativa ou expõe a credencial (JSON ilegível, campo indispensável ausente, endereço de troca de token fora do fornecedor).

**Pacote não trava o agente de forma definitiva (dono, 01/11/2026 às 20:12: "O pacote Linkedin (e qualquer outro) não pode travar de forma definitiva o uso pelo agente. No máximo indicar erro/problema/alerta, mas o agente que tem autonomia para utilizar.").** Erro, operação incerta, concessão suspensa, incidente ou qualquer outra condição de risco vira aviso com código, motivo e ação sugerida, na resposta da rota, na tela e na auditoria; nenhum estado deixa o agente sem saída. Onde o pacote pede confirmação antes de seguir (operação incerta, repetição de escrita, troca de identidade), há uma rota pela qual o agente segue mesmo assim, com o motivo gravado no diário e o risco dito na resposta. Guarda que se resolve relendo e repetindo (revisão esperada, prévia, confirmação) continua, porque não trava.

**Lista, mapa ou regra de negócio que muda por site ou com o tempo fica em configuração com simulação, não no código (dono, 28/10/2026 às 23:39).** O pacote traz o padrão; a option aceita trocar e acrescentar, com revisão e simulação antes de gravar, e o registro de cada efeito guarda a revisão usada. Exemplos: listas de origem, canal e parceiro, prazos e janelas, exclusões, textos aprovados e catálogos como o de assistentes de IA (`dados/origens-ia.json` do Site Core). Fica no código o que não muda por site e protege o dado, como a detecção de mídia paga e a validação de identificador.

## Como se mantém

- Só o projeto "Site Geral | Todos" edita este documento, com a guarda de revisão. Mudança de padrão vem do dono.
- Desvio de um pacote vira item no documento "Pedidos aos pacotes Fator3", na aba do pacote (o implantador tem aba própria), citando a aba deste documento; o item sai quando a sessão que conferir a entrega achar o padrão cumprido.
- A sessão que confere cada entrega relê o instalador e o relatório e atualiza a tabela de conformidade e a aba do pacote.
- Pacote novo ganha aba aqui, no mesmo formato.
