# Pedidos — Fator3 MCP Google (wp-mcp-google-fator3)

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-google-fator3**. Cite como "Pedidos MCP Google N". Próximo número: 61; número retirado fica vago. Pedido entregue sai daqui na troca de versão, mesmo sem aceite; o aceite segue nas pendências do estado da frota, e o reprovado vira pedido novo (dono, 19/11/2026).

## wp-mcp-google-fator3 — pendentes

**60. Tela no Guia visual: folha comum, grupo Operação e fim do terceiro nível de navegação (dono, 20/11/2026 às 14:08: "Ainda temos diferenças entre a parte visual (design/ux) dos plugins ... Analise as versões e padronize").**

*Evidência.* Fator3 MCP Google 0.40.0, Site-Teste, 20/11/2026, código do instalador e estilos computados: h1 de 26 px e peso 600 (padrão 23 px, peso 400); texto de 14 px; cor de destaque fixa (`#2271b1`, `#135e96`); a tela abre em Suporte › Visão geral, e Incidentes fica em Suporte; `nav.f3-subnav` em `div.f3-layout` (`includes/Admin/Screen.php` linha 118) é um terceiro nível de navegação em coluna lateral; selos `f3-badge--*` com ícone e bordas próprias; cartão com faixa de título; botões com `width:100%` abaixo de 782 px; a classe `.f3-check` tem o nome da caixa de marcar da folha comum com outro uso. Medidas, arquivos e linhas: [Guia visual das telas dos pacotes Fator3](https://claude.ai/code/artifact/87331836-0b71-4263-a10a-f4e63fb0cd22), aba "Guia", seção 1, e aba "Fator3 MCP Google".

*Pedido.* Aplicar o guia: (1) `assets/f3-ui.css` igual ao texto da aba "Folha comum", carregada antes da folha própria; (2) os 15 ajustes da aba "Fator3 MCP Google"; (3) grupos Operação (Visão geral · Incidentes) · Configurar · Dados · Suporte (Ajuda), com a tela abrindo em Operação › Visão geral. Slug, capacidade, rotas e options não mudam; os endereços `&section=` continuam.

*Aceite.* No Site-Teste, a conferência da seção 7 do guia preenchida por subaba, com as capturas a 360, 768 e 1440 px; nenhum `nav.f3-subnav` no HTML; sha256 de `f3-ui.css` igual ao dos outros pacotes.
