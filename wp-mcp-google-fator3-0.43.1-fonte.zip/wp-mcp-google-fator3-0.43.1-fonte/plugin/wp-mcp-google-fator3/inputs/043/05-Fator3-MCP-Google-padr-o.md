# Padrão de entrega — Fator3 MCP Google (wp-mcp-google-fator3)

Para o agente responsável pelo Fator3 MCP Google. Vale a partir da próxima versão; a regra comum aos pacotes está na aba "Regra comum", e o essencial vai repetido aqui.

## Arquivos

| tipo | nome | conteúdo |
| --- | --- | --- |
| instalador | `wp-mcp-google-fator3-<versão>-instalador.zip` | pasta interna `wp-mcp-google-fator3/`, arquivo principal `wp-mcp-google-fator3/wp-mcp-google-fator3.php` |
| fonte | `wp-mcp-google-fator3-<versão>-fonte.zip` | pasta interna `wp-mcp-google-fator3-<versão>-fonte/`: documentação integral, scripts do Cloud Shell, testes, contratos, evidências e uma cópia do relatório |
| relatório | `wp-mcp-google-fator3-<versão>-relatorio.md` | Markdown, em português |

Versão `X.Y.Z`, sem sufixo; homologação e sha256 só dentro do relatório. Encaminhamentos aos outros pacotes vão em seção do relatório ou em arquivo com o prefixo `wp-mcp-google-fator3-<versão>-`.

## Cabeçalho e tela

O cabeçalho fica assim:

| campo | valor |
| --- | --- |
| Plugin Name | Fator3 MCP Google |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | Google Analytics 4, Google Ads, Search Console, Tag Manager, Site Verification, Sheets e Drive em leitura e escrita pela Abilities API e pelo Fator3 MCP, com conta técnica, limite de uso e auditoria. Configuração em Ferramentas → Fator3 MCP Google. |
| Requires at least, Requires PHP | os validados pela versão (0.31.0: 7.1.4 e 8.3) |
| Author | Fator3 |
| Author URI | `https://www.fator3.com.br` |
| License | GPL-2.0-or-later |
| Text Domain | `wp-mcp-google-fator3` |
| Update URI | `https://fator3.com.br/plugins/wp-mcp-google-fator3` |
| tela | Ferramentas → Fator3 MCP Google, com a capacidade do filtro `f3_mcp_google_capability` (padrão `manage_options`) |

Se a descrição ganhar ou perder um serviço, ela muda junto, no mesmo formato.

## O que não muda

Slug e pasta `wp-mcp-google-fator3`, arquivo principal, Text Domain, Update URI, o prefixo `f3_mcp_google_` de options, tabelas e eventos de cron (`f3_mcp_google_jobs_tick`), as rotas `ga/*`, `ads/*`, `gsc/*`, `siteverification/*`, `google/*` e `gtm/*`, as ferramentas MCP `google-mcp-read` e `google-mcp-write`, o consumidor `base-site-core-fator3` do leitor `search-console-reader` e a pasta `wp-content/f3-google-state/`.

## Relatório

Nesta ordem:

1. Título `Entrega — Fator3 MCP Google <versão>`.
2. De onde a versão entra (WordPress limpo e as versões aceitas direto).
3. Habilidades (total, leitura e escrita), options e as versões dos contratos de configuração, catálogo, execução e armazenamento; as versões do Fator3 MCP e do Site Core com que a entrega foi validada e a ordem de troca entre eles.
4. O que mudou, citando cada "Pedidos MCP Google N" atendido, com a evidência.
5. Prova da troca: `google/status` (`plugin_version`, `abilities_registered`), `google/integration-status` com `compact: true` e `google/storage-status` com o estado esperado.
6. Banco e volta de versão: migração de schema, transição e o que a volta de arquivos não desfaz.
7. O que não foi exercitado (chamadas reais ao Google, Ads, Sheets, Cloud Shell).
8. Identidade: nome, tamanho e sha256 do instalador e da fonte.

## Conformidade da 0.31.0 (09/11/2026)

Lida no `main` (commit `e3580d3`): instalador `wp-mcp-google-fator3-0.31.0-instalador.zip` (947.286 bytes, sha256 `e577dd44…`) com a pasta `wp-mcp-google-fator3/` e o arquivo principal; fonte `wp-mcp-google-fator3-0.31.0-fonte.zip` (7.886.524 bytes, sha256 `70d788ba…`) com a pasta `wp-mcp-google-fator3-0.31.0-fonte/`; os dois sha256 no relatório, iguais aos dos arquivos; nenhum ZIP dentro de outro. Título `Entrega — Fator3 MCP Google 0.31.0`; cabeçalho e descrição como acima. Nenhum pedido aberto sobre a entrega.

## Fora do escopo (decisão do dono)

Não se pede ao Fator3 MCP Google: mover a emissão de tag ou o consentimento para o pacote Google.
