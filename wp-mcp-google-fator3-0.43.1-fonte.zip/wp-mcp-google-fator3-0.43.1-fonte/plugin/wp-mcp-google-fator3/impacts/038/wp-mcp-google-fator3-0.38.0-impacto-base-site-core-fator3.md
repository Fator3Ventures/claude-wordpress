# Impacto de Fator3 MCP Google 0.38.0 em Fator3 Site Core

Revisão 2 · Entrega de 18/11/2026 · Situação aberta · Desenvolvimento e contrato · **acao-necessaria**. Referência de origem **Pedidos MCP Google 56**. O responsável pela incorporação é o mantenedor do Site Core. Não foi aberto ticket externo.

| Identidade | Versão | SHA-256 |
|---|---|---|
| Base do emissor, instalador Google | 0.37.0 | `2b3695f8d477c593a80c5a91cffac27761d14ed4d50d3d3454b625c6dda85ab5` |
| Emissor entregue, `wp-mcp-google-fator3-0.38.0-instalador.zip` | 0.38.0 | `1ddeb8ef6aa734a3f8c6a95baadd2c3b6256d84e4bbbdb55d781300b8f407e33` |
| Destinatário oficial examinado, instalador | 1.94.0 | `0eff84a92622b3daa2aebd81437bbb2c33eaea648d1955c46e29ef70aedf9008` |
| Diff experimental de dois arquivos, `impacts/038/core-1.94.0.patch` no fonte Google | sobre 1.94.0 | `67ddd34f19af85c7ddf409c43d0bc77ca144ebdc0fbe348abf2fc4c95d2a62e6` |

## Mudança e consequência

Quando a consulta à chave IAM retorna 403 de permissão, o Google 0.38.0 registra o evento local `key_metadata`, código `key_metadata_permission_denied`, com a ação para o administrador. Emite pelo filtro `f3base_incidente_publicar_v1` uma observação com `pacote=google`, `codigo=autorizacao_recusada`, `recurso=<conexão>/service-account-key-metadata` e `iam={permissao,projeto}`. O projeto público vem do JSON da conexão. Quando ausente ou inválido, seu valor é nulo. A recuperação usa o mesmo recurso e código. A rota de reparo continua a do Google.

No Core 1.94.0, `F3Base_Incidentes::publicar` valida e persiste os campos do contrato existente e gera referência opaca para o recurso. A leitura administrativa via `f3base/incidentes-tecnicos-ler` retorna um único incidente aberto. O registro e o e-mail do Core ainda omitem a permissão e o projeto. Quem atende o aviso precisa abrir o diagnóstico no Google. O coletor de incidentes é uma segunda origem legítima de observações e deve usar a mesma identidade.

## Ação do responsável e aceite

Revisar o diff, incorporá-lo em nova versão do Core e manter a validação restrita a este recurso e código. Conferir a abertura e a recuperação em site autorizado com o plugin Google entregue. Um episódio repetido deve manter uma abertura, uma notificação de abertura e a mesma referência. O e-mail de abertura deve indicar “validade da chave não consultável”, `iam.serviceAccountKeys.get` e o projeto identificado. Confirmar as duas informações na leitura MCP. Um episódio anterior, ainda aberto e já notificado, deve ganhar os dados no registro sem reenviar o e-mail. Solicita-se versão do Core incorporando a mudança e resultado do aceite.

## Alteração proposta e reprodução

O diff abaixo altera `includes/class-f3base-incidentes.php` e `includes/class-f3base-incidentes-provedores.php`. O primeiro valida permissão fixa e projeto público opcional, grava o contexto no episódio e no evento da fila e compõe a mensagem na entrega. O segundo recupera esse contexto da leitura Google para enriquecer episódios abertos. As chaves de deduplicação, o destino técnico e a reserva postal continuam sob controle do Core. A restrição de entrada exclui texto livre, chave, e-mail de conta de serviço e a URL do recurso IAM.

Em cópia descartável da pasta do Core 1.94.0, aplicar `patch --dry-run -p1 < CAMINHO/core-1.94.0.patch` e `patch -p1 < CAMINHO/core-1.94.0.patch`. Usar o procedimento e as variáveis descritos em `reproducao/LEIA-ME.md` do fonte Google. Executar `tests/native/key038.php` com fases `clean` e `patch` em bancos independentes. Para o episódio preexistente usar a fase `capture` sob Core oficial, aplicar o diff e executar o coletor uma vez sob administrador. Conferir o registro via `tests/native/acceptance038.php` nas duas condições.

## Prontidão, sequência e evidência

A implementação Google está completa para este contrato. A operação pode instalar Google 0.38.0 com Core 1.94.0 e MCP 0.49.0 e conferir o diagnóstico em Conexão → Identidade. O enriquecimento no Core requer sua futura versão oficial. Depois de incorporado, executar o coletor, verificar a fila e a leitura. Para homologação, primeiro observar antes da concessão IAM e só então conceder a permissão e rodar nova consulta. A leitura posterior deve registrar a recuperação.

| Prova em WordPress 7.1.4 | Resultado | Evidência em `evidence/038/` |
|---|---|---|
| Core original, PHP 8.3.6 | Recusa IAM em paralelo ao GA4 funcional, um incidente no Core, repetição sem nova notificação, recuperação | `clean.json`, `upgrade.json` |
| Leitura MCP HTTP, antes e depois do ajuste isolado | Original retornou unicamente `autorizacao_recusada` em aberto e omitiu o bloco IAM. Cópia ajustada retornou o mesmo código, a permissão e `lab-038` | `core-http-oficial.json`, `core-http-experimental.json` |
| Core experimental, PHP 8.4.27 | 16 verificações, incluindo contexto no registro e na única mensagem de abertura interceptada | `patch.json` |
| Aplicação em episódio já aberto | O coletor acrescentou os campos e a contagem de novos e-mails foi zero | `core-backfill.txt` |

HTTP Google e correio foram interceptados na bancada. A autenticação WordPress e o transporte MCP usados na leitura foram reais em loopback. Incorporação no Core oficial, entrega por SMTP e aceite de frota seguem pendentes.

## Evolução

A revisão 1 de planejamento identificou a perda de contexto no destinatário. Na revisão 2, o emissor já publica o contexto, o diff traz a adaptação de persistência, coletor e correio, e a leitura MCP foi exercitada antes e depois da alteração. A situação continua aberta para o mantenedor do Core.

## Diff aplicável ao Core 1.94.0


```diff
--- a/includes/class-f3base-incidentes-provedores.php
+++ b/includes/class-f3base-incidentes-provedores.php
@@ -96,6 +96,12 @@
                     $page=\Fator3\McpGoogle\Automation\Alerts::state(['limit'=>100,'offset'=>$offset]);
                     if (empty($page['available'])) {return;}
                     foreach ($page['incidents'] as $r) {
+                        if (($r['event'] ?? '') === 'key_metadata' && ($r['status'] ?? '') === 'open') {
+                            F3Base_Incidentes::publicar(['pacote'=>'google','codigo'=>'autorizacao_recusada',
+                                'recurso'=>$id.'/service-account-key-metadata', 'estado'=>'aberto','acao_humana'=>true,
+                                'desde'=>(int)$r['created_at'], 'iam'=>['permissao'=>'iam.serviceAccountKeys.get',
+                                'projeto'=>$r['context']['project_id'] ?? null]]);
+                        }
                         if (in_array($r['event']??'',['channel','access','cron_late','sitemap_error','scheduled_check'],true)
                             && in_array($r['status']??'',['open','resolved'],true)) {
                             self::situacao('google','integracao_indisponivel',$id.'/'.$r['id'],$r['status']==='open',(int)$r['created_at']);
--- a/includes/class-f3base-incidentes.php
+++ b/includes/class-f3base-incidentes.php
@@ -77,21 +77,40 @@
             || (isset($e['vence_em']) && (!is_int($e['vence_em']) || $e['vence_em']<1))) {
             return ['ok'=>false,'codigo'=>'observacao_invalida'];
         }
+        // Restringir diagnóstico ao recurso Google da consulta IAM e a campos tipados.
+        $iam = null;
+        if ($p === 'google' && $c === 'autorizacao_recusada'
+            && preg_match('~^[a-z][a-z0-9_-]{0,39}/service-account-key-metadata$~D', $id)
+            && ($e['iam']['permissao'] ?? null) === 'iam.serviceAccountKeys.get') {
+            $projeto = $e['iam']['projeto'] ?? null;
+            if ($projeto === null || (is_string($projeto) && preg_match('/^[a-z0-9][a-z0-9.-]{0,62}$/D', $projeto))) {
+                $iam = ['permissao'=>'iam.serviceAccountKeys.get', 'projeto'=>$projeto];
+            }
+        }
         $ref=hash_hmac('sha256',$id,wp_salt('auth'));
         $key=self::chave($p,$c,$ref);
-        return self::com_trava($key, static function() use ($key,$e,$p,$c,$id,$ref,$estado,$registro) {
+        return self::com_trava($key, static function() use ($key,$e,$p,$c,$id,$ref,$estado,$registro,$iam) {
             $r=get_option($key,[]);
             if (!$r && $estado==='recuperado') {return ['ok'=>true,'estado'=>'sem_incidente'];}
             if (($r['estado']??'')!==$estado) {
                 $r['pacote']=$p; $r['codigo']=$c; $r['recurso_ref']=$ref; $r['rota']=self::ROTAS[$p];
                 $r['estado']=$estado; $r['alterado_em']=time();
                 if ($estado==='aberto') {$r['desde']=$e['desde']??time();}
+                if ($iam !== null) $r['iam'] = $iam;
                 $r['acao_humana']=$e['acao_humana']??true; $r['vence_em']=$e['vence_em']??null;
                 $r['fila'][]=['estado'=>$estado,'desde'=>$r['desde'],'em'=>time(),'vence_em'=>$r['vence_em'],
-                    'acao_humana'=>$r['acao_humana'],'entrega'=>'pendente'];
+                    'acao_humana'=>$r['acao_humana'],'entrega'=>'pendente'] + ($iam === null ? [] : ['iam'=>$iam]);
                 if ($p === 'canal' && $c === 'canal_indisponivel' && $id === 'registro-wordpress') {
                     $r['historico_registro'] = self::historico_registro($r, $e, $registro);
                 }
+                if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
+            } elseif ($estado==='aberto' && $iam !== null && ($r['iam'] ?? null) !== $iam) {
+                $r['iam'] = $iam;
+                // Enrich only the pending opening of the current episode.
+                foreach ($r['fila'] as &$ev) {
+                    if ($ev['estado']==='aberto' && $ev['desde']===$r['desde'] && $ev['entrega']==='pendente') $ev['iam']=$iam;
+                }
+                unset($ev);
                 if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
             } elseif ($estado==='aberto' && isset($e['vence_em']) && $r['vence_em']!==$e['vence_em']) {
                 $r['vence_em']=$e['vence_em'];
@@ -142,7 +161,12 @@
             if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'reserva_nao_gravada'];}
             $fase=$ev['estado']==='aberto'?'Incidente técnico':'Recuperação técnica';
             $titulo=$fase.' · '.$r['pacote'].' · '.$r['codigo'];
-            $texto=implode("\n",[$titulo, 'Site: '.wp_parse_url(home_url(),PHP_URL_HOST),
+            $detalhe = '';
+            if (isset($ev['iam'])) {
+                $titulo = $fase.' · google · validade da chave '.($ev['estado']==='aberto'?'não consultável':'consultável');
+                $detalhe = 'Permissão: '.$ev['iam']['permissao'].' · Projeto: '.($ev['iam']['projeto'] ?? 'não informado');
+            }
+            $texto=implode("\n",[$titulo, $detalhe, 'Site: '.wp_parse_url(home_url(),PHP_URL_HOST),
                 'Referência do recurso: '.$r['recurso_ref'], 'Desde: '.wp_date('d/m/Y H:i:s T',$ev['desde']),
                 'Observação: '.wp_date('d/m/Y H:i:s T',$ev['em']),
                 $ev['vence_em']?'Vencimento: '.wp_date('d/m/Y H:i:s T',$ev['vence_em']):'',
```

## Retorno do destinatário, registrado no fonte 0.39.0

Em 18/11/2026, a revisão 2 do impacto recebido do Core 1.95.0 confirmou a incorporação oficial e o aceite local do contrato IAM. Encerrada a ação de desenvolvimento deste encaminhamento. A confirmação da conta Google e da caixa postal em produção continua operacional. A revisão entregue com os ZIPs 0.38.0 permanece identificada pelo hash original.
