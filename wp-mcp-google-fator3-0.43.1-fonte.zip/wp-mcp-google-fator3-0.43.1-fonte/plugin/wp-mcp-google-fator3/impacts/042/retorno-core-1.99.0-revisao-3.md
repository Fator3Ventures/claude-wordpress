# Pedido MCP Google 59 — retorno do Fator3 Site Core 1.99.0

| Campo | Registro |
|---|---|
| Data, revisão e etapa | 2026-11-20T14:46-03:00 · Revisão 3 · entrega |
| Origem e destino do encaminhamento inicial | `wp-mcp-google-fator3` 0.40.0 → 0.41.0 para `base-site-core-fator3` 1.98.0 → 1.99.0 |
| Natureza e classificação desse retorno | Contrato de incidentes de acesso · `validacao-coordenada` |
| Situação | `resolvido` no desenvolvimento dos dois pacotes. A operação da frota acompanha a adoção nos sites. |
| Google 0.40.0, instalador usado na origem | SHA-256 `dedded6ec02dbed38bb75f028720a222ec9b6f9335b80e3aa600b44d284da030` |
| Google 0.41.0, instalador e fonte | SHA-256 `47dea7ac080799dfd41cf7583c97a1959daefa0d50b0da490d8219c315bd4d76` e `be55b406d34dca1fefa84b1393a6420e82621e82c67d0cacc1dfac506a670f28` |
| Core oficial 1.98.0, instalador e fonte examinados | SHA-256 `419dab4e9e822ed5a77239dcaef5598554cf50700c633f9625a0dcf91cbb7d5b` e `88e5e4a2c5fdc2507ad0669165079923872c3cd008ca15c159c0b892905c3951` |
| Core entregue | `base-site-core-fator3-1.99.0-instalador.zip` · SHA-256 `3509e2736dfdedd98c2fa142d99028eb629f112ba1c863138850c3f3ee5e7155` |
| Referência técnica recebida | `reference/1990/google-041.patch` · SHA-256 `980318230eb174c2baafed2b2e48321904418b6b0f0f6604738c911b5eb9889c` |

## Mudança e consequência

O Google distingue o desaparecimento do uso de um recurso, a consolidação de duas referências e a recuperação comprovada do acesso. No Core 1.98.0 faltava um consumidor para os dois primeiros desfechos. O Google 0.41.0 mantinha os fechamentos administrativos na fila local, enquanto o episódio continuava aberto na central do site. No Core 1.99.0 o encerramento atinge a mesma referência, preserva a razão e a geração e produz zero mensagens de recuperação administrativa. O acesso restabelecido segue o fluxo de recuperação ordinário.

## Ação do responsável e alteração incorporada

O Core incorporou o contrato do pedido 59. `F3Base_Incidentes::iniciar()` registra o filtro PHP `f3base_incidente_acesso_encerrar_v1` no bootstrap comum. O Google publica `pacote=google`, `codigo=integracao_indisponivel`, recurso `<conexão>/<id hexadecimal de 64 caracteres>`, `estado=recuperado`, `acao_humana=false`, motivo `nao_usado` ou `consolidado` e `geracao_acesso` inteira positiva. `F3Base_Incidentes::encerrar_acesso()` valida o contrato, usa a referência opaca existente e responde após confirmar a gravação. Uma reserva incerta conserva o identificador necessário à conciliação. Se o operador confirma que o aviso dispensado não saiu, o Core o retira da fila.

O observador paginado `F3Base_Incidentes_Provedores::google()` reconhece as mesmas transições no histórico. Para encerramento administrativo, exige estado e motivo coincidentes e `notify_recovery=false`. A geração mais recente prevalece, inclusive quando o coletor vê primeiro a recuperação ordinária de uma geração nova. Eventos de IAM conservam o código `autorizacao_recusada` e sua recuperação ordinária. O contrato está concentrado no PHP dos plugins e mantém as permissões administrativas vigentes.

## Prontidão, compatibilidade e sequência de troca

O Google 0.41.0 já fornece o produtor, o reprocessamento da sua fila e os estados consultáveis. A incorporação no Core 1.99.0 completa a integração com essa versão do Google. A sequência ensaiada instalou Google 0.40.0 e Core 1.98.0, criou um incidente e atualizou primeiro o Google, depois o Core, mantendo banco e salts. Durante o intervalo, a fila do Google retém `awaiting_access_core`. Uma passagem da fila ou a coleta histórica pelo Core 1.99.0 encerra a referência. Um aviso aceito antes da troca conserva seu histórico.

## Validação e evidência

WordPress 7.1.4 e PHP 8.4.27 em loopback. O ensaio usou os plugins e o banco locais, interceptou `wp_mail` e substituiu o transporte HTTP para impedir acesso a serviços externos. A contagem abaixo refere-se a tentativas no transporte local.

| Fase | Verificações | O que foi observado |
|---|---:|---|
| Google 0.40.0 / Core 1.98.0 | 3 | A recusa histórica de acesso foi criada pelo próprio Google. O Core recebeu a abertura na mesma referência. Uma tentativa de abertura foi interceptada. |
| Google 0.41.0 / Core 1.98.0 | 7 | A manutenção encontrou a referência com 25 horas, fechou o diagnóstico local e manteve o evento aguardando o Core. A bancada também preparou histórico somente do coletor, abertura sem destinatário e reserva de resultado incerto. Três tentativas foram interceptadas. |
| Google 0.41.0 / Core 1.99.0 | 20 | Os motivos administrativos, o histórico somente do coletor, a abertura pendente e a reserva incerta sincronizaram com zero novas mensagens administrativas. O adiamento de geração antiga, a reabertura genuína, a carência de 30 minutos, a recuperação por acesso comprovado e a separação de IAM passaram. Somente a abertura ordinária e a recuperação genuína chegaram ao transporte, uma vez cada. |

A instalação final usou o ZIP identificado acima via WordPress. Os 1.290 arquivos instalados coincidiram byte a byte com o pacote. Uma requisição HTTP anônima ao loopback confirmou que os filtros de publicação e de encerramento estão presentes com o perfil público reduzido ativo. A sonda local e seu resultado estão em `tests/199/google-bootstrap.php` e `evidence/1990/google-bootstrap.json`.

O fonte do Core traz `tests/199/google.php` e `evidence/1990/google-{historico,anterior,atual}.json`. Para reproduzir, use uma instalação descartável local com banco `core_199_google`. Execute `wp eval-file tests/199/google.php` em processos distintos com `F3_CORE_GOOGLE_FASE` igual a `historico`, `anterior` e `atual`, conforme as versões da tabela. Indique um arquivo JSON por fase em `F3_CORE_GOOGLE_RESULTADO` e preserve o banco e os salts entre as trocas.

## Evolução, resposta e aceite operacional

A revisão 1 registrou o risco. A revisão 2 entregou a parte Google, seu ensaio com patch experimental e o pedido de ação ao Core. A revisão 3 registra a incorporação na versão 1.99.0, a identidade do instalador e a prova nas duas formas de recepção. A revisão 2 original e o patch recebido permanecem no fonte em `reference/1990/`.

A equipe da frota confirma o aceite operacional quando instalar o conjunto em Pauta e Prática, Desenvolvimento de Softwares e Taberium. Para cada referência histórica afetada, deve conferir o estado recuperado, o motivo administrativo, a ausência de nova mensagem de recuperação e a situação de eventuais reservas anteriores. A confirmação nos três sites e o recebimento em caixa postal dependem dessa verificação operacional.
