<?php
/** Local-only contract exercise. Mail and provider calls never leave the disposable WordPress. */
use Fator3\McpGoogle\{Connections,Records,TechnicalNotices};
if (wp_parse_url(home_url(),PHP_URL_HOST)!=='127.0.0.1') throw new RuntimeException('Loopback required');
wp_set_current_user(1); Connections::select('default');
$phase = getenv('F3_ACCESS_CORE_PHASE'); $checks=[]; $sent=[]; $mode='ok';
$assert = static function($ok,$name) use (&$checks){if (!$ok) throw new RuntimeException($name); $checks[]=$name;};
add_filter('pre_wp_mail',static function($pre,$event) use (&$sent,&$mode) {
    $sent[]=$event['subject'];
    if ($mode==='incerto') throw new RuntimeException('Lab transport interrupted');
    return true;
},1,2);
$dest=static function($email){update_option('f3base_avisos_tecnicos',['email'=>$email]);};
$dest('fixture@example.invalid');
$code='integracao_indisponivel';
$prefix=getenv('F3_ACCESS_CORE_PREFIX')?:'access041';
$id=static fn($s)=>hash('sha256',$prefix.'-'. $s);
$row=static function($id) use ($code) {
    $ref=hash_hmac('sha256','default/'.$id,wp_salt('auth'));
    return get_option('f3base_incidente_v1_'.hash('sha256','google|'.$code.'|'.$ref),[]);
};
$event=static fn($id,$gen,$state)=>['pacote'=>'google','codigo'=>$code,'recurso'=>'default/'.$id,'geracao_acesso'=>$gen,'estado'=>$state];
$pub=static fn($id,$generation)=>TechnicalNotices::publish($code,$id,true,['access_generation'=>$generation]);
$close=static fn($id,$generation,$reason)=>TechnicalNotices::publish($code,$id,false,['access_generation'=>$generation,'access_closure'=>$reason]);
$td=static fn($id)=>Records::get('technicalnotice',hash('sha256','default|'.$code.'|'.$id));
$projection=static function($id,$gen,$state) {
    $r=['id'=>$id,'connection_id'=>'default','event'=>'access','resource'=>'lab-access-scope','status'=>$state,
        'created_at'=>time()-90000,'updated_at'=>time(),'generation'=>$gen,'context'=>[]];
    if ($state==='consolidado'||$state==='nao_usado') {$r['notify_recovery']=false;$r['resolution_reason']=$state;}
    $saved=Records::put('incident',$id,$r);
    if (empty($saved['success'])) throw new RuntimeException('Local incident not persisted');
};
$url='https://analyticsadmin.googleapis.com/v1beta/accounts/'.sprintf('%u',crc32($prefix)).'/accessBindings';
$legacy=hash('sha256','default|access|'.$url);
if ($phase==='seed') {
    $assert(F3_MCP_GOOGLE_VERSION==='0.40.0','Seed with official previous Google');
    \Fator3\McpGoogle\Automation\Alerts::observe('access',$url,true,'http_403','Diagnóstico de acesso');
    $old=Records::get('incident',$legacy); $assert(($old['status']??'')==='open','Baseline saved the per-resource incident');
    $old['updated_at']=$old['created_at']=time()-90000; Records::put('incident',$legacy,$old);
    F3Base_Incidentes_Provedores::google();
    $assert($row($legacy)['estado']==='aberto' && count($sent)===1,'Prior Core stored opening once');
} elseif ($phase==='official') {
    $assert(!has_filter('f3base_incidente_acesso_encerrar_v1'),'Official core lacks silent hook');
    $assert(F3_MCP_GOOGLE_VERSION==='0.41.0','Installed new Google runtime');
    \Fator3\McpGoogle\Automation\AccessIncidents::tick();
    $migrated=Records::get('incident',$legacy);
    $assert(($migrated['status']??'')==='nao_usado' && ($migrated['notify_recovery']??true)===false,'New executor maintenance retired a 25-hour legacy diagnostic');
    $assert($td($legacy)['status']==='awaiting_access_core' && $row($legacy)['estado']==='aberto' && !$sent,'Official consumer cannot close silently; pending producer emits zero email');
    $original=$id('original'); F3Base_Incidentes::publicar($event($original,1,'aberto'));
    F3Base_Incidentes::publicar($event($original,2,'recuperado')+['acao_humana'=>false]);
    $assert(count($sent)===2 && str_contains($sent[1],'Recupera'),'Reproduced recovery email even with human_action false');
    $r=$id('upgrade'); $assert(!empty($pub($r,1)['ok']),'PUSH accepted by official Core');
    $prior=count($sent); $projection($r,2,'nao_usado');
    $result=$close($r,2,'nao_usado'); F3Base_Incidentes_Provedores::google(); TechnicalNotices::dispatch();
    $assert(($result['codigo']??'')==='core_contract_unavailable','Google refuses unsafe fallback');
    $assert(count($sent)===$prior && $row($r)['estado']==='aberto','Core 1.98 preserves old episode and sends no false recovery');
    $assert($td($r)['status']==='awaiting_access_core','Durable outbox awaits receiver');
    $orphan=$id('pull-only');
    F3Base_Incidentes::publicar($event($orphan,1,'aberto')); $projection($orphan,2,'consolidado');
    $close($orphan,2,'consolidado');
    $assert($td($orphan)['status']==='awaiting_access_core','Old pull-only episode is retained even without previous outbox entry');
} elseif ($phase==='experimental') {
    $assert((bool)has_filter('f3base_incidente_acesso_encerrar_v1'),'Experimental core exposes targeted hook');
    TechnicalNotices::dispatch(); F3Base_Incidentes_Provedores::google();
    $migrated=$row($legacy);
    $assert(($migrated['estado']??'')==='recuperado' && $migrated['motivo_encerramento']==='nao_usado' && empty($migrated['fila']) && $td($legacy)['status']==='accepted','Aged pre-update record closed end to end by original reference');
    foreach (['upgrade'=>'nao_usado','pull-only'=>'consolidado'] as $label=>$why) {
        $r=$id($label); $v=$row($r); $assert(($v['estado']??'')==='recuperado' && $v['acao_humana']===false && $v['motivo_encerramento']===$why && empty($v['fila']),'Recovered exactly the original reference '.$label);
        $assert($td($r)['status']==='accepted' && !$td($r)['queue'],'Google acknowledged '.$label);
    }
    $assert(count($sent)===0,'Deferred PUSH and PULL are silent and idempotent');
    $r=$id('upgrade');
    $late=F3Base_Incidentes::publicar($event($r,1,'aberto'));
    $assert($late['estado']==='observacao_superada' && !$sent,'Delayed poll cannot reopen closed generation');
    $pub($r,3); $assert(count($sent)===1 && $row($r)['estado']==='aberto','Later scheduled failure can reopen');
    TechnicalNotices::publish($code,$r,false,['access_generation'=>4]);
    $assert(count($sent)===2 && $row($r)['estado']==='recuperado','Real recovery still notifies');
    $dest(''); $r=$id('pending'); $pub($r,1); $assert(count($row($r)['fila'])===1,'Unsent opening pending at Core');
    $close($r,2,'nao_usado'); $dest('fixture@example.invalid');
    $assert(empty($row($r)['fila']) && count($sent)===2,'Retirement removed stale unsent opening');
    $r=$id('uncertain'); $mode='incerto'; $pub($r,1); $mode='ok';
    $reserved=$row($r)['fila'][0]['reserva']??'';
    $assert($reserved!=='' && count($sent)===3,'Interrupted opening remains reserved');
    $close($r,2,'consolidado'); $rec=$row($r); $assert($rec['fila'][0]['reserva']===$reserved && count($sent)===3,'Silent closure retains uncertain reservation and never resends');
    $ref=hash('sha256','google|'.$code.'|'.$rec['recurso_ref']);
    $res=F3Base_Incidentes::reconciliar(['id'=>$ref,'reserva'=>$reserved,'resultado'=>'nao_enviado']);
    $assert($res['entregas_pendentes']===0,'Reconciliation of unsent retired opener does not reschedule it');
    $r=$id('observer'); $projection($r,1,'open'); F3Base_Incidentes_Provedores::google();
    $before=count($sent); $assert($row($r)['estado']==='aberto','Native polling sees new scheduled episode');
    $projection($r,2,'nao_usado'); F3Base_Incidentes_Provedores::google();
    $assert(count($sent)===$before && $row($r)['motivo_encerramento']==='nao_usado','PULL-only transition closes without email');
    $r=$id('iam'); $wrong=$event($r,1,'recuperado'); $wrong['codigo']='autorizacao_recusada';
    $invalid=apply_filters('f3base_incidente_acesso_encerrar_v1',null,$wrong+['acao_humana'=>false,'motivo_encerramento'=>'nao_usado']);
    $assert(!($invalid['ok']??true),'IAM cannot enter silent access channel');
} else throw new RuntimeException('Unknown phase');
$f=getenv('F3_ACCESS_CORE_RESULT');
file_put_contents($f,wp_json_encode(['phase'=>$phase,'google'=>F3_MCP_GOOGLE_VERSION,'core'=>F3BASE_PLUGIN_VERSAO,'php'=>PHP_VERSION,'wp'=>$GLOBALS['wp_version'],'checks'=>$checks,'count'=>count($checks),'intercepted_mail'=>count($sent),'network'=>'loopback only'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo count($checks)." checks\n";
