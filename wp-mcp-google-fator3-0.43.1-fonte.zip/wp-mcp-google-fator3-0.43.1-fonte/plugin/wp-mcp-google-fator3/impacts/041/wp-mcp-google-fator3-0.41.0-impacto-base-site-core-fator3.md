# Impacto do Fator3 MCP Google 0.41.0 no Fator3 Site Core

Revisão 2 · 20/11/2026 · Entrega · Aberto para o mantenedor do Core · **ação necessária**  
Pedido MCP Google 59 · Emissor `wp-mcp-google-fator3` · Destinatário `base-site-core-fator3`

| Identidade | Referência |
|---|---|
| Google de partida | 0.40.0, instalador SHA-256 `dedded6ec02dbed38bb75f028720a222ec9b6f9335b80e3aa600b44d284da030` |
| Google entregue | 0.41.0, instalador SHA-256 `47dea7ac080799dfd41cf7583c97a1959daefa0d50b0da490d8219c315bd4d76` |
| Core oficial examinado | 1.98.0, instalador SHA-256 `419dab4e9e822ed5a77239dcaef5598554cf50700c633f9625a0dcf91cbb7d5b`, fonte SHA-256 `88e5e4a2c5fdc2507ad0669165079923872c3cd008ca15c159c0b892905c3951` |
| Proposta para a próxima edição do Core | Patch `core-1.98.0.patch`, SHA-256 `980318230eb174c2baafed2b2e48321904418b6b0f0f6604738c911b5eb9889c`, em `impacts/041/` do fonte Google. O diff integral está no fim deste documento. |

## Consequência no Core oficial

Em Pauta e Prática, Desenvolvimento de Softwares e Taberium, o pedido relata avisos ao dono para uma leitura sem permissão de listar vínculos de acesso. Na versão Google anterior, conta e propriedade podiam abrir duas referências. O novo Google agrupa a falha de agenda e retira a observação avulsa. O fechamento por perda de uso e a consolidação de uma referência antiga precisam encerrar o registro correspondente na central técnica sem produzir recuperação por e-mail. O retorno comprovado de um recurso de agenda e o restabelecimento da leitura IAM seguem no fluxo normal.

Reprodução no Core 1.98.0 com WordPress real e correio interceptado: publicar uma abertura e depois um `estado=recuperado` para a mesma referência com `acao_humana=false` gerou duas mensagens. O campo informa a necessidade de intervenção. A fila da central é montada em `includes/class-f3base-incidentes.php::publicar()` sempre que muda o estado. A entrega do próximo evento é iniciada na mesma chamada. O observador `F3Base_Incidentes_Provedores::google()` também traduz qualquer `access` em estado `resolved` em uma recuperação comum.

## Contrato implementado pelo Google

O identificador da central continua sendo derivado do pacote, do código `integracao_indisponivel` e do recurso `<conexão>/<ID de incidente Google>`. O produtor mantém a mesma referência dos registros que já existiam. No ciclo de acesso, `geracao_acesso` é um inteiro positivo monotônico por incidente.

| Estado local Google | Sinal ao Core | Ação do consumidor |
|---|---|---|
| `open` | `f3base_incidente_publicar_v1`, estado `aberto` | Enfileirar uma abertura na transição. Conta e propriedade do mesmo episódio usam a identidade agrupada do produtor. |
| `resolved`, com acesso comprovado | Mesmo filtro, estado `recuperado` | Registrar recuperação ordinária e seu aviso. |
| `nao_usado` ou `consolidado`, com `notify_recovery=false` | **Novo filtro PHP** `f3base_incidente_acesso_encerrar_v1`, estado `recuperado`, `acao_humana=false`, `motivo_encerramento` igual ao estado terminal | Fechar a mesma referência, guardar motivo e geração, descartar a abertura pendente obsoleta. |

Exemplo de registro recebido pelo filtro novo:

```json
{"pacote":"google","codigo":"integracao_indisponivel","recurso":"default/0000000000000000000000000000000000000000000000000000000000000001","estado":"recuperado","acao_humana":false,"motivo_encerramento":"nao_usado","geracao_acesso":2}
```

A chamada normal é `apply_filters('f3base_incidente_acesso_encerrar_v1', null, $evento)`. O consumidor devolve `{"ok":true,"estado":"recuperado"}` somente após persistir, ou `observacao_superada` para uma geração anterior. Erro de validação, trava ocupada ou falha de persistência deixa a operação disponível para nova passagem. O encerramento guarda apenas a referência opaca no Core.

**Com o Core 1.98.0.** O publicador reconhece a falta do filtro por capacidade e mantém o encerramento persistido em `technicalnotice` com `status=awaiting_access_core`. As demais referências seguem em suas filas normais. Para a mesma referência, a outbox conserva a ordem das transições seguintes até o consumidor reconhecer o fechamento. Os estados locais terminais específicos são ignorados pelo observador antigo. Um episódio já aberto na central pode continuar aberto, inclusive em resumos, e uma abertura já enfileirada pelo Core pode ser entregue antes da incorporação. Um aviso produzido antes da troca também pode chegar por uma reserva anterior. A nova transição silenciosa não é enviada à API comum da 1.98.0. Com o novo consumidor, a próxima passagem da outbox ou a leitura paginada pelo observador termina a sincronização. A ausência da outbox histórica não impede o fechamento de um registro originalmente criado apenas pela coleta do Core.

## Proposta de incorporação

Em `includes/class-f3base-incidentes.php`, registrar o filtro dedicado e conferir pacote, código, recurso, estado, motivo, geração positiva e a marca explícita de ausência de ação humana. Atualizar a mesma option sob a trava do episódio e eliminar a notificação pendente pertencente ao episódio encerrado. Uma reserva com resultado externo incerto continua disponível para reconciliação administrativa. Caso o operador confirme que a abertura reservada não saiu, ela é dispensada. O código conserva o último recibo histórico e aceita novas falhas genuínas com geração maior.

Em `includes/class-f3base-incidentes-provedores.php`, o coletor reconhece os estados terminais do Google com motivo coincidente e indicação explícita de silêncio, e usa a mesma rotina. Tanto PUSH como PULL preservam a geração. Uma leitura atrasada da geração já encerrada não reabre o episódio. O contrato IAM segue usando o código `autorizacao_recusada` e exige a recuperação normal. O hook proposto é interno ao PHP, sem nova rota de escrita remota. A listagem e a reconciliação continuam com os controles existentes do Core.

## Ensaio, reprodução e aceite

Os scripts e os resultados sanitizados estão em `impacts/041/` e `evidence/041/` do fonte Google. Em WordPress de loopback descartável, com correio interceptado e a mesma conexão entre fases, instalar os ZIPs oficiais 0.40.0 Google, 1.98.0 Core e 0.52.0 MCP. Primeiro rodar o ensaio com fase `seed` e gravar seu resultado em caminho próprio. Atualizar o Google pelo instalador 0.41.0 no mesmo banco. Em seguida, executar `wp eval-file prova-core.php` com `F3_ACCESS_CORE_PHASE=official`, `F3_ACCESS_CORE_RESULT=/tmp/oficial.json` e um `F3_ACCESS_CORE_PREFIX` exclusivo da rodada. Manter o banco e o prefixo. Aplicar o patch com `patch -p1 < core-1.98.0.patch` na raiz de uma cópia do plugin Core. Repetir o ensaio em novo processo com `F3_ACCESS_CORE_PHASE=experimental` e resultado em outro arquivo.

Em WordPress 7.1.4 e PHP 8.4.27 foram concluídas **3 verificações na base 0.40.0, 10 na nova versão com o Core oficial e 18 com o Core experimental**. O ensaio criou uma recusa `http_403` de `accessBindings` na base, envelheceu o registro em 25 horas e atualizou o Google. A passagem de manutenção do novo plugin encerrou esse registro local como `nao_usado` e reteve o seu encerramento técnico para o novo contrato. Após aplicar a proposta ao Core, a outbox e o coletor recuperaram a mesma referência, sem novo e-mail. O caso de base com referência originada apenas por PULL também sincronizou. Uma abertura de outra geração pôde ocorrer depois e sua recuperação genuína gerou aviso. Uma abertura pendente obsoleta foi dispensada, uma reserva incerta foi preservada e a reconciliação posterior como não enviada terminou sem reenfileirar. Uma observação atrasada foi ignorada e IAM foi recusado pelo canal silencioso. A paridade final confrontou os arquivos instalados de Google, Core oficial restaurado e MCP com seus ZIPs. Os resultados estão em `evidence/041/impacto-core-{seed,official,experimental}.json` e `impacto-core-paridade.json`.

O aceite no destinatário exige uma versão oficial do Core que exponha o filtro e a coleta compatível. A frota confirma a transição e a ausência de novo e-mail de encerramento administrativo, inclusive nas referências históricas, depois de instalar o conjunto. A verificação em bancada interceptou `wp_mail`. O histórico de produção e a caixa postal são responsabilidade da operação. O patch foi aplicado somente na cópia da bancada. O instalador oficial do Core foi preservado.

## Histórico e responsável

A revisão 1, em `impacts/041/planejamento.md`, identificou a recuperação indevida antes da consolidação da interface. A revisão 2 define o contrato, comprova as duas modalidades de recepção e entrega a parte Google pronta. O mantenedor do Core deve revisar e incorporar o patch ou implementação que preserve a mesma semântica e devolver o identificador do instalador e os resultados. A responsabilidade pela distribuição e pelo aceite nos três sites permanece com a frota.

## Patch para a cópia do Core 1.98.0

```diff
--- a/includes/class-f3base-incidentes.php
+++ b/includes/class-f3base-incidentes.php
@@ -21,6 +21,7 @@
 
     public static function iniciar(): void {
         add_filter('f3base_incidente_publicar_v1', static fn($anterior,$e)=>self::publicar($e), 10, 2);
+        add_filter('f3base_incidente_acesso_encerrar_v1', static fn($anterior,$e)=>self::encerrar_acesso($e), 10, 2);
         add_action('wp_abilities_api_init', [self::class,'registrar'], 80);
         add_action('admin_init', static function() {
             if (current_user_can('manage_options')) {self::observar();}
@@ -71,6 +72,50 @@
             'permissao' => 'iam.serviceAccountKeys.get',
             'projeto' => is_string($projeto) && preg_match('/^[a-z0-9][a-z0-9.-]{0,62}$/D', $projeto) ? $projeto : null,
         ];
+    }
+
+    /** Encerramento administrativo de um episódio de acesso do Google, sem mensagem de recuperação. */
+    public static function encerrar_acesso(array $e): array {
+        $motivo = $e['motivo_encerramento'] ?? '';
+        $recurso = $e['recurso'] ?? null;
+        $geracao = $e['geracao_acesso'] ?? null;
+        if (($e['pacote'] ?? '') !== 'google' || ($e['codigo'] ?? '') !== 'integracao_indisponivel'
+            || ($e['estado'] ?? '') !== 'recuperado' || ($e['acao_humana'] ?? true) !== false
+            || !in_array($motivo, ['nao_usado','consolidado'], true)
+            || !is_string($recurso) || !preg_match('~^[a-z][a-z0-9_-]{0,39}/[a-f0-9]{64}$~D', $recurso)
+            || !is_int($geracao) || $geracao < 1) {
+            return ['ok'=>false,'codigo'=>'observacao_invalida'];
+        }
+        $ref = hash_hmac('sha256', $recurso, wp_salt('auth'));
+        $key = self::chave('google','integracao_indisponivel',$ref);
+        return self::com_trava($key,static function() use ($key,$ref,$motivo,$geracao) {
+            $r = get_option($key,[]);
+            if (($r['geracao_acesso'] ?? 0) > $geracao) return ['ok'=>true,'estado'=>'observacao_superada'];
+            if (($r['geracao_acesso'] ?? 0) === $geracao && ($r['motivo_encerramento'] ?? null) === $motivo) {
+                return ['ok'=>true,'estado'=>'recuperado'];
+            }
+            // Mantém o marcador mesmo que a abertura só tenha existido na fila do produtor.
+            $r += ['pacote'=>'google','codigo'=>'integracao_indisponivel','recurso_ref'=>$ref,
+                'rota'=>self::ROTAS['google'],'desde'=>time(),'fila'=>[]];
+            // Somente a cauda do episódio atual. Episódios anteriores com o mesmo timestamp permanecem distintos.
+            $ultima = array_key_last($r['fila']);
+            while ($ultima !== null) {
+                $aviso = $r['fila'][$ultima];
+                if (($aviso['desde'] ?? null) !== $r['desde']) break;
+                if (($aviso['entrega'] ?? '') === 'reservado') {
+                    $r['fila'][$ultima]['dispensar_retentativa'] = true;
+                    break;
+                }
+                if (($aviso['entrega'] ?? '') !== 'pendente') break;
+                array_pop($r['fila']);
+                if ($aviso['estado'] === 'aberto') break;
+                $ultima = array_key_last($r['fila']);
+            }
+            $r['estado'] = 'recuperado'; $r['acao_humana'] = false;
+            $r['alterado_em'] = time(); $r['motivo_encerramento'] = $motivo;
+            $r['geracao_acesso'] = $geracao;
+            return update_option($key,$r,false) ? ['ok'=>true,'estado'=>'recuperado'] : ['ok'=>false,'codigo'=>'persistencia_falhou'];
+        });
     }
 
     /** Valor original do recurso nunca é guardado. O identificador opaco é estável no site. */
@@ -84,15 +129,25 @@
             || (isset($e['vence_em']) && (!is_int($e['vence_em']) || $e['vence_em']<1))) {
             return ['ok'=>false,'codigo'=>'observacao_invalida'];
         }
+        // Um produtor que exige silêncio precisa do contrato específico.
+        if (array_key_exists('motivo_encerramento',$e)) return ['ok'=>false,'codigo'=>'usar_encerramento_acesso'];
+        $geracao = $p === 'google' && $c === 'integracao_indisponivel' ? ($e['geracao_acesso'] ?? null) : null;
+        if ($geracao !== null && (!is_int($geracao) || $geracao < 1)) return ['ok'=>false,'codigo'=>'observacao_invalida'];
         $iam = self::contexto_iam($e);
         $ref=hash_hmac('sha256',$id,wp_salt('auth'));
         $key=self::chave($p,$c,$ref);
-        return self::com_trava($key, static function() use ($key,$e,$p,$c,$id,$ref,$estado,$iam) {
+        return self::com_trava($key, static function() use ($key,$e,$p,$c,$id,$ref,$estado,$iam,$geracao) {
             $r=get_option($key,[]);
+            if (isset($r['geracao_acesso']) && ($geracao === null || $r['geracao_acesso'] > $geracao
+                || ($r['geracao_acesso'] === $geracao && isset($r['motivo_encerramento'])))) {
+                return ['ok'=>true,'estado'=>'observacao_superada'];
+            }
             if (!$r && $estado==='recuperado') {return ['ok'=>true,'estado'=>'sem_incidente'];}
             if (($r['estado']??'')!==$estado) {
                 $r['pacote']=$p; $r['codigo']=$c; $r['recurso_ref']=$ref; $r['rota']=self::ROTAS[$p];
                 if ($p==='core' && $c==='could_not_set' && preg_match('/^[a-z0-9_]{1,120}$/D',$e['gancho']??'')) { $r['gancho']=$e['gancho']; }
+                if ($geracao !== null) $r['geracao_acesso'] = $geracao;
+                unset($r['motivo_encerramento']);
                 $r['estado']=$estado; $r['alterado_em']=time();
                 if ($estado==='aberto') {$r['desde']=$e['desde']??time();}
                 $r['acao_humana']=$e['acao_humana']??true; $r['vence_em']=$e['vence_em']??null;
@@ -110,6 +165,7 @@
                 if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
             } elseif ($estado === 'aberto') {
                 $anterior = $r;
+                if ($geracao !== null) $r['geracao_acesso'] = $geracao;
                 if ($iam !== null && ($r['iam'] ?? null) !== $iam) {
                     $r['iam'] = $iam;
                     // Só a última abertura pode pertencer ao episódio atual, mesmo com timestamps iguais.
@@ -207,7 +263,7 @@
             if (($ev['entrega']??'')!=='reservado' || ($ev['reserva']??null)!==$e['reserva']) {
                 return ['ok'=>false,'codigo'=>'reserva_divergente'];
             }
-            if ($e['resultado']==='aceito') {array_shift($r['fila']);}
+            if ($e['resultado']==='aceito' || !empty($ev['dispensar_retentativa'])) {array_shift($r['fila']);}
             else {$r['fila'][0]['entrega']='pendente'; unset($r['fila'][0]['tentar_apos']);}
             $r['reconciliacao']=['resultado'=>$e['resultado'],'em'=>time(),'operador'=>get_current_user_id(),'fase'=>$ev['estado']];
             if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
--- a/includes/class-f3base-incidentes-provedores.php
+++ b/includes/class-f3base-incidentes-provedores.php
@@ -146,6 +146,21 @@
                                 'iam'=>['permissao'=>'iam.serviceAccountKeys.get', 'projeto'=>$r['context']['project_id'] ?? null],
                             ]);
                         }
+                        if (($r['event'] ?? '') === 'access' && isset($r['generation'])) {
+                            $observacao = ['pacote'=>'google','codigo'=>'integracao_indisponivel',
+                                'recurso'=>$id.'/'.$r['id'],'geracao_acesso'=>$r['generation']];
+                            $estado = $r['status'] ?? '';
+                            if (in_array($estado,['nao_usado','consolidado'],true)
+                                && ($r['notify_recovery'] ?? true) === false && ($r['resolution_reason'] ?? '') === $estado) {
+                                F3Base_Incidentes::encerrar_acesso($observacao + [
+                                    'estado'=>'recuperado','acao_humana'=>false,'motivo_encerramento'=>$estado]);
+                            } elseif (in_array($estado,['open','resolved'],true)) {
+                                F3Base_Incidentes::publicar($observacao + [
+                                    'estado'=>$estado === 'open' ? 'aberto' : 'recuperado',
+                                    'desde'=>max(1,min(time(),(int)$r['created_at']))]);
+                            }
+                            continue;
+                        }
                         if (in_array($r['event']??'',['channel','access','cron_late','sitemap_error','scheduled_check'],true)
                             && in_array($r['status']??'',['open','resolved'],true)) {
                             self::situacao('google','integracao_indisponivel',$id.'/'.$r['id'],$r['status']==='open',(int)$r['created_at']);
```
