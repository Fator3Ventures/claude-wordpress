# Impacto de Fator3 MCP Google 0.37.0 em Fator3 Site Core

Data/hora: 2026-11-18T17:31:54-03:00 · Revisão: 1 · Etapa: entrega · Situação: alinhado

Versão-base: Google 0.36.0, pacote anterior fornecido ao projeto. Versão-alvo: 0.37.0, entregue.

Instalador emissor: `wp-mcp-google-fator3-0.37.0-instalador.zip`, 988922 bytes, SHA-256 `2b3695f8d477c593a80c5a91cffac27761d14ed4d50d3d3454b625c6dda85ab5`.

Destinatário examinado: Core 1.93.0 original, instalador SHA-256 `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8`.

Natureza: contrato e operação. Classificação: validacao-coordenada. Referências: Pedidos MCP Google 55 e core 430; impacto recebido `base-site-core-fator3-1.93.0-impacto-wp-mcp-google-fator3.md`, revisão 2.

## Mudança e consequência

Todos os avisos operacionais do Google passam pelo filtro `f3base_incidente_publicar_v1`. `TechnicalNotices::publish()` persiste cada transição antes de chamar o filtro, com `pacote:google`, `codigo`, `recurso`, `estado:aberto|recuperado`, `desde`, `acao_humana` e, quando aplicável, `vence_em`. O recurso usa o prefixo da conexão Google.

Uma resposta `ok:true` significa que o Core assumiu a responsabilidade pelo registro, inclusive quando aguarda a configuração do destinatário. Não comprova recebimento postal. Ausência do filtro, exceção ou recusa mantêm a transição na fila Google; a recuperação permanece atrás da abertura ainda não aceita. O executor repete a entrega pendente. `f3base_zelador` e uma visita administrativa autorizada observam problemas mesmo sem passagem recente do executor Google. Se o WordPress inteiro deixar de executar, nenhum desses observadores locais funciona.

O Google deixa de usar os antigos destinatários locais e o webhook Slack. A coleta Ads e as concessões dos leitores Ads/GA4/Search Console continuam válidas quando existe outro administrador atual autorizado. O autor original permanece no registro e sua perda de autorização produz um aviso técnico. Sem administrador válido, a execução é recusada.

Após recuperação, as provas de conversão continuam exigindo a geração atual. Uma autorização estável permite ao executor refazer a verificação quando identidade, destino, política e concessão permanecem iguais. O Core deve continuar usando a prontidão do adaptador: o intervalo entre a retomada e a nova prova não constitui prontidão comercial.

## Ação do responsável

Responsável: operação da frota, em coordenação com o mantenedor Core. Configurar e conferir o destino técnico no Site Core. Publicar o instalador e relatório Google, conferir SHA-256/slug e executar a troca pelo fluxo raw previsto no padrão.

Aceite observável em CTOOffice: criar tarefa avulsa com a concessão A, reautorizar o conector, revogar A e comprovar conclusão da tarefa; `google/status` sem incidente de concessão pendente; rebaixar o concedente em cenário controlado mantendo outro administrador, comprovar coleta e aviso técnico; no dia seguinte, verificar os leitores Core. Após recuperação reconciliada, conferir GA4 e Ads `ready` depois da passagem do executor, sem nova verificação administrativa. Simular incidente e recuperação, conferir o destino técnico e ausência de entrega ao Slack.

## Diagnóstico e alteração no destinatário

Foram examinados `includes/class-f3base-incidentes.php`, `includes/class-f3base-incidentes-provedores.php` e o contrato recebido. O Core 1.93.0 já oferece o filtro e o armazenamento necessários; nenhum patch do destinatário foi criado ou aplicado.

O Google usa os recursos esperados pelo coletor do Core: `conexao/alvo` para renovação, com `renovacao_falhou`, e `conexao/id-do-incidente` para incidentes operacionais, com `integracao_indisponivel`. Avisos de concedente usam `conexao/grantor/ID`; chave ativa usa `conexao/service-account-key` e `conexao/service-account-key-metadata`. Os códigos adicionais são `autorizacao_recusada`, `token_vencendo` e `credencial_invalida`. Isso permite ao Core controlar episódios e deduplicação sem criar um segundo destino de comunicação.

Pontos do emissor: `includes/TechnicalNotices.php`, `SiteAuthority.php`, `Auth/KeyStatus.php`, `Automation/Alerts.php`, `ConversionDelivery.php` e `StageConversionDelivery.php`. O nome interno `RenewalNotifications` conserva a leitura de estados anteriores; a entrega passa pelo contrato Core.

## Prontidão do emissor

Implementação concluída na 0.37.0. As interfaces públicas dos leitores e de entrega de conversões mantêm suas versões. Não é necessária outra alteração Google para consumir o contrato core 430 examinado. O monitor de chave consulta IAM com `iam.serviceAccountKeys.get`; erro de acesso mantém diagnóstico desconhecido/desatualizado, sem inventar vencimento.

O instalador traz a documentação completa em `google/documentation`, incluindo `GUIA-0.37.0.md` e `AVISOS-RENOVACAO.md`. A leitura integral por MCP foi testada contra os bytes instalados.

## Compatibilidade e sequência

Conjunto local exercitado: WordPress 7.1.4; PHP 8.3.6 e 8.4.27; Core 1.93.0; MCP 0.48.0; LinkedIn 0.26.0; Meta 0.28.0; Pipedrive 0.12.0. Os cinco acompanhantes permaneceram com os bytes dos instaladores originais. A troca Google foi testada de 0.36.0 para 0.37.0, sem retorno de versão e sem regravação das credenciais.

Usar a frota com os pacotes vigentes. A validação local não certifica a combinação do Site-Teste, que na consulta de leitura ainda tinha Pipedrive 0.11.1. Não alterar destinos ou concessões para forçar uma renovação: alterações materiais invalidam a autorização estável e exigem revisão explícita.

## Validação e evidência

Fonte, diretório `plugin/wp-mcp-google-fator3/evidence/037`: `native83-final.json` e `native84-final.json` registram 61 critérios por runtime. Incluem revogação da concessão, rebaixamento do concedente, leitores, recuperação GA4/Ads, ausência e retorno do filtro Core, ordenação abertura/recuperação e ausência de duplicação. Todo correio observado nos testes usou o endereço técnico sintético; nenhuma chamada Slack foi feita. `installed-parity.json` comprova os pacotes originais da bancada.

Trata-se de WordPress real e Core original em instalação isolada. HTTP Google e transporte postal foram interceptados. Não houve envio comercial, publicação no repositório, instalação compartilhada ou aceite do fornecedor. A ausência do contrato foi simulada retirando o filtro somente durante o teste e restaurando-o em seguida. O teste demonstra persistência/retomada no emissor e aceitação no Core; entrega na caixa postal continua pendente.

## Resposta esperada

Registro do aceite operacional com versão instalada, conexão, tarefa, resultado da revogação, passagem do executor, recebimento do aviso e sucesso dos leitores no dia seguinte. Caso falhe, encaminhar códigos e identificadores sanitizados, mantendo tarefas de resultado incerto para reconciliação.

## Evolução e encerramento

Revisão 1: consolida a decisão registrada no planejamento 037, incorpora o encaminhamento Core 1.93.0 revisão 2 e documenta a implementação própria testada. A integração técnica está alinhada; o aceite coordenado permanece aberto. Este arquivo foi preparado para encaminhamento, sem envio a terceiros.
