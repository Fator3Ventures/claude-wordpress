# Impacto de Fator3 MCP Google 0.39.0 em Fator3 Site Core

**Revisão 3 · 19/11/2026 · Resolvido no Core 1.96.0.** O instalador recebido tem SHA-256 `dde2feadefdf08ab7973e7ea1be588b73709b723a088ef5549e43394aa7f73a5`. O mantenedor confirmou a incorporação oficial, com 44 verificações em PHP 8.3 e 51 em PHP 8.4. A verificação de campo dos dois pedidos continua sob responsabilidade da frota e do titular. Segue o registro da revisão anterior.

**Revisão 2 · 18/11/2026 · Entrega · Aberto · Ação necessária do mantenedor do Core**  
Origem: Pedidos MCP Google 58, associado ao pedido 57. Natureza: contrato de retentativa e filas de conversão.

| Referência | Instalador | SHA-256 |
|---|---|---|
| Emissor de partida | `wp-mcp-google-fator3-0.38.0-instalador.zip` | `1ddeb8ef6aa734a3f8c6a95baadd2c3b6256d84e4bbbdb55d781300b8f407e33` |
| Emissor entregue | `wp-mcp-google-fator3-0.39.0-instalador.zip` | `9a8cadb240e6398f1a85a833fcce46bb7b1bfa251d74c5111984547a5c453fce` |
| Destinatário oficial examinado | `base-site-core-fator3-1.95.0-instalador.zip` | `6971df93ecf39e14e584e0fc3dc802aee77ab4f2d58eb5b8ce35d6a503a4c21c` |
| Patch de bancada sobre o Core | `impacts/039/core-1.95.0.patch` no fonte Google | `f69872b6fc545e69d200cb6705a40aa8aa19b3fb3874ede4cb224bbf7449dd35` |

## Mudança entregue e consequência

A prova Ads tem duração indeterminada enquanto identidade, política, ação e revisão permanecem válidas. Uma recusa conclusiva de ação, termos ou autorização no envio invalida a prova dessa ação e abre `autorizacao_recusada`. Uma nova verificação positiva restabelece a prontidão. O mesmo registro pode então ser reapresentado com a referência vinculada e o mesmo `transactionId`. As credenciais e os dados do lead continuam sob os controles já exigidos pelo WordPress.

**A 1.95.0 oficial já aceita a prontidão das conversões otimizadas.** A prova principal devolve `verification_expires_at=null`. Quando a capacidade `enhanced_leads` está pronta, ela devolve `validity=until_rejected` e o inteiro `expires_at=253402300799` (fim de 9999 em UTC). Foi exercitada a implementação oficial de `F3Base_Google_Conversoes::pronta()`. O GA4 continua a renovar a cada 12 horas e comunica falha transitória prolongada pelo campo `proof_status=stale_transient`.

## Pontos que precisam de alteração no Core

- **Fila de aquisição.** A 1.95.0 consegue reter e reenviar uma recusa conclusiva após nova prova. Também limita a dez tentativas e consulta apenas o recibo das linhas incertas. Em timeout ou 503, o Google pode ter aceitado o pedido antes da falha. A 0.39.0 devolve `incerto/ads_retry_same_transaction` quando a reapresentação é admitida somente com o mesmo identificador. O patch reserva nova passagem na fila existente com as verificações de vínculo e consentimento e conserva o orçamento de tentativas para os erros de destino cobertos. Um resultado incerto de outro tipo segue para reconciliação.
- **Fila comercial por etapa.** A 1.95.0 seleciona apenas `pendente`, embora uma recusa possa deixar a linha bloqueada ou recusada. A janela comum de sete dias também abrange Ads. O patch mantém o limite de sete dias do LinkedIn e aplica até 90 dias ao Ads, ainda sujeito à idade do clique. A fila Ads guarda a referência da ação mesmo se uma prova anteriormente autorizada estiver bloqueada. Reavalia somente os motivos conhecidos, com intervalo mínimo de cinco minutos, usando a mesma ação, evento, revisão e consentimento. Um destino alterado continua exigindo decisão administrativa.

Os códigos de recusa conclusiva são `ads_action_unavailable`, `ads_authorization_refused`, `ads_terms_refused` e `ads_destination_refused`. Para esses códigos, a retomada no Core requer `status=recusado` e `non_delivery_proven=true`. `ads_retry_same_transaction` também admite resposta incerta porque a retentativa conserva o identificador da transação e o destino. Não transformar qualquer erro de rede, recibo desconhecido, duplicidade ou falha interna de outro produtor em permissão de reenvio. A Data Manager identifica duplicidade pela combinação de ação e identificador de transação. [Referência de diagnósticos](https://developers.google.com/data-manager/api/devguides/diagnostics) · [Estados da requisição](https://developers.google.com/data-manager/api/reference/rest/v1/requestStatus/retrieve)

## Implementação e prova

O diff altera `F3Base_Conversoes_Servidor::processar()`, sua reconciliação e `F3Base_Qualidade_Destinos`. Introduz uma verificação restrita ao destino Ads e aos códigos previstos. Conserva a reserva da fila antes do HTTP, a verificação do consentimento e a rejeição de redirecionamento da ação. A parte Google está implementada nos arquivos de entrega acima. A combinação experimental funcionou sem outra alteração Google.

Na raiz de uma cópia do Core 1.95.0, executar `patch --dry-run -p1 < CAMINHO/core-1.95.0.patch` e `patch -p1 < CAMINHO/core-1.95.0.patch`. Instalar os acompanhantes conforme o relatório e executar `tests/native/proofs039.php` no WordPress descartável, com `F3_PHASE39=core-official` ou `core-patch`, `F3_RESULT39` apontando para um arquivo local. O roteiro completo está em `reproducao/LEIA-ME.md`.

| Cenário | Evidência observada |
|---|---|
| Core oficial, WP 7.1.4 / PHP 8.3.6 | 38 verificações. A fila de aquisição recebeu a recusa, passou a bloqueada, enviou o mesmo registro após nova prova e recebeu confirmação assíncrona. |
| Core com diff, WP 7.1.4 / PHP 8.4.27 | 44 verificações. Com nove tentativas anteriores e 503, a linha permaneceu apta a uma nova passagem. O mesmo pedido com 45 dias voltou a ser enviado. Uma etapa de 45 dias recebeu recusa de termos e voltou a ser enviada após nova prova, com o mesmo evento. |
| Controle do fornecedor | OAuth, respostas Google e e-mail foram interceptados. As filas, locks, registros, transições e autorizações WordPress foram exercitados no banco real da bancada. |

## Sequência, aceite e encerramento

O passo do mantenedor é revisar o diff, incorporá-lo em uma nova versão oficial do Core e devolver a identidade do instalador e a evidência da fila. A implantação coordenada pode usar MCP 0.50.0, seguido do Core com o ajuste e Google 0.39.0. A entrega da última prova GA4, o fim da renovação periódica Ads e o registro de recusa no Core já funcionam no Core 1.95.0. A recuperação completa dos casos de fila acima depende da incorporação do diff.

A revisão 1, em `impacts/039/planejamento.md`, levantou o campo obrigatório de validade e os limites das filas antes do fechamento do Google. Na revisão 2, a compatibilidade do campo foi comprovada com o Core original, o patch de fila foi executado em cópia isolada e o Core oficial foi restaurado na bancada. O retorno de IAM do pedido 56 foi incorporado oficialmente na 1.95.0 e a regressão foi verificada. O aceite do pedido 58 na frota ainda requer confirmação do mantenedor e observação em site autorizado.

## Diff sobre a 1.95.0

```diff
--- a/includes/class-f3base-conversoes-servidor.php
+++ b/includes/class-f3base-conversoes-servidor.php
@@ -88,6 +88,14 @@
         if($target==='ga4'){$g=$lead['dados']['ga4']??array();if(!preg_match('/^[0-9]{1,20}\.[0-9]{1,20}$/D',(string)($g['client_id']??''))||!preg_match('/^[1-9][0-9]{0,19}$/D',(string)($g['session_id']??''))){return $fail('identidade_ga4_ausente');}$temporal=F3Base_Ga4_Sessao::validar($g,$time);if($temporal!==''){return $fail($temporal);}$p+=array('measurement_id'=>$g['measurement_id']??'','client_id'=>$g['client_id'],'session_id'=>$g['session_id'],'timestamp_micros'=>$time*1000000,'event_name'=>'generate_lead');}
         else{if($cap===null){try{$cap=F3Base_Google_Conversoes::selecionar()['cap'];}catch(Throwable $x){$cap=array();}}$google=F3Base_Google_Conversoes::montar($lead,$cap);if(empty($google['ok'])){return $google;}$p+=$google['payload'];}
         return array('ok'=>true,'payload'=>$p);
+    }
+    /** Reoffer only the same bound Ads transaction. Ordinary uncertain receipts stay in reconciliation. */
+    public static function retomar_ads(string $destino,array $resposta): bool {
+        if ($destino !== 'google_ads') return false;
+        $codigo=$resposta['code']??'';
+        if ($codigo === 'ads_retry_same_transaction') return in_array($resposta['status']??'', ['recusado','incerto'],true);
+        return ($resposta['status']??'')==='recusado' && ($resposta['non_delivery_proven']??false)===true
+            && in_array($codigo,['ads_action_unavailable','ads_terms_refused','ads_authorization_refused','ads_destination_refused'],true);
     }
     public static function processar(): array {
         global $wpdb;$lock=F3Base_Trava::adquirir('conversoes-servidor',120);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}$done=0;
@@ -109,7 +117,9 @@
                 try{$result=$adapter->sendBound($prep['payload'],$row['destino_ref']);}catch(Throwable $e){$result=array('status'=>'incerto');}
                 $status=is_array($result)?($result['status']??'incerto'):'incerto';if(!is_array($result)){$result=array();}if(!in_array($status,array('entregue','recusado'),true)){$status='incerto';}
                 if($status==='recusado'&&empty($result['non_delivery_proven'])){$status='incerto';}
-                $wpdb->update(self::tabela(),array('estado'=>$status,'codigo'=>self::codigo($result['code']??null,$status),'http'=>is_int($result['http']??null)&&$result['http']>=100&&$result['http']<=599?$result['http']:0,'proxima'=>time()+max(300,min(DAY_IN_SECONDS,(int)($result['retry_after']??3600))),'atualizado_em'=>time()),array('record_id'=>$row['record_id'],'destino'=>$row['destino'],'estado'=>'incerto'));++$done;
+                $retomar=self::retomar_ads($row['destino'],$result);
+                if ($retomar) $status='pendente';
+                $wpdb->update(self::tabela(),array('tentativas'=>(int)$row['tentativas']+($retomar?0:1),'estado'=>$status,'codigo'=>self::codigo($result['code']??null,$status),'http'=>is_int($result['http']??null)&&$result['http']>=100&&$result['http']<=599?$result['http']:0,'proxima'=>time()+max(300,min(DAY_IN_SECONDS,(int)($result['retry_after']??3600))),'atualizado_em'=>time()),array('record_id'=>$row['record_id'],'destino'=>$row['destino'],'estado'=>'incerto'));++$done;
             }return array('ok'=>true,'processados'=>$done);
         }finally{F3Base_Trava::liberar($lock);}
     }
@@ -150,6 +160,7 @@
             if(!is_array($result)) $result=array();
             $status=$result['status']??'incerto';
             if(!in_array($status,array('entregue','recusado'),true)||($status==='recusado'&&empty($result['non_delivery_proven']))) $status='incerto';
+            if (self::retomar_ads($row['destino'],$result)) $status='pendente';
             $wpdb->update(self::tabela(),array('estado'=>$status,'codigo'=>self::codigo($result['code']??null,$status),
                 'proxima'=>time()+max(1800,min(DAY_IN_SECONDS,(int)($result['retry_after']??1800))),'atualizado_em'=>time()),
                 array('record_id'=>$row['record_id'],'destino'=>$row['destino'],'estado'=>'incerto','destino_ref'=>$row['destino_ref']));
--- a/includes/class-f3base-qualidade-destinos.php
+++ b/includes/class-f3base-qualidade-destinos.php
@@ -52,7 +52,7 @@
             $ref=$entry['destination_ref']??'';
             $ready=!empty($cap['ready'])&&!empty($entry['ready']);
             $expiredProof=($cap['reason']??'')==='stage_verification_required'&&($entry['reason']??'')==='stage_verification_required';
-            if((!$ready&&!($reconcile&&$expiredProof))||($reconcile&&(!in_array($cap['reason']??'',array('ok','stage_verification_required'),true)||!in_array($entry['reason']??'',array('ok','stage_verification_required'),true)))||!is_string($ref)||$ref===''||strlen($ref)>191){return array('ok'=>false,'codigo'=>F3Base_Conversoes_Servidor::codigo($entry['reason']??null,'acao_comercial_nao_pronta'));}
+            if((!$ready&&!($reconcile&&$expiredProof))||($reconcile&&(!in_array($cap['reason']??'',array('ok','stage_verification_required'),true)||!in_array($entry['reason']??'',array('ok','stage_verification_required'),true)))||!is_string($ref)||$ref===''||strlen($ref)>191){return array('ok'=>false,'codigo'=>F3Base_Conversoes_Servidor::codigo($entry['reason']??null,'acao_comercial_nao_pronta'),'referencia'=>($expiredProof && is_string($ref) && strlen($ref)<=191)?$ref:'');}
             return array('ok'=>true,'adapter'=>$a,'cap'=>$cap,'acao'=>$entry,'referencia'=>$ref);
         }catch(Throwable $e){return array('ok'=>false,'codigo'=>'adaptador_etapas_indisponivel');}
     }
@@ -70,7 +70,7 @@
         elseif(($lead['captura']??'')!=='aceito'||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])){$why='registro_inelegivel';}
         elseif(!$testPreview&&(($lead['classe_trafego']??'')!=='nao_marcado'||$marked||!empty($lead['dados']['homologacao']))){$why='trafego_suprimido';}
         elseif(!empty($lead['dados']['audiencia_excluida'])||($lead['metodo']??'')==='email'){$why='origem_nao_elegivel';}
-        elseif($at<1||$at>time()||$at<time()-7*DAY_IN_SECONDS||$at<(int)strtotime($lead['criado_em'].' UTC')){$why='etapa_fora_da_janela';}
+        elseif($at<1||$at>time()||$at<time()-($target==='google_ads'?90:7)*DAY_IN_SECONDS||$at<(int)strtotime($lead['criado_em'].' UTC')){$why='etapa_fora_da_janela';}
         if($why===''){
             $decision=F3Base_Publicidade::resolver($lead['dados']);
             if(!$decision['permitida']){
@@ -110,11 +110,12 @@
     }
     public static function processar(): array {
         global $wpdb;$lock=F3Base_Trava::adquirir('qualidade-destinos',120);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}$n=0;
-        try{$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='pendente' ORDER BY atualizado_em LIMIT 2",self::tabela()),ARRAY_A)?:array();foreach($rows as $r){if(F3Base_Execucoes::restante_ms()<20000){break;}$lead=F3Base_Leads_Repositorio::obter($r['record_id']);$p=$lead?self::preparar($lead,$r['etapa'],$r['destino'],(int)$r['ocorreu_em']):array('ok'=>false,'codigo'=>'registro_ausente');
+        try{$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='pendente' OR (destino='google_ads' AND estado='bloqueado' AND codigo IN ('ads_retry_same_transaction','ads_action_unavailable','ads_terms_refused','ads_authorization_refused','ads_destination_refused') AND atualizado_em<=%d) OR (destino='google_ads' AND estado='bloqueado' AND codigo='stage_verification_required' AND destino_ref<>'' AND atualizado_em<=%d) ORDER BY atualizado_em LIMIT 2",self::tabela(),time()-300,time()-300),ARRAY_A)?:array();foreach($rows as $r){if(F3Base_Execucoes::restante_ms()<20000){break;}$lead=F3Base_Leads_Repositorio::obter($r['record_id']);$p=$lead?self::preparar($lead,$r['etapa'],$r['destino'],(int)$r['ocorreu_em']):array('ok'=>false,'codigo'=>'registro_ausente');
                 if(!empty($p['ok'])&&($r['config_revisao']!==F3Base_Options::revisao(self::OPTION)||$r['acao']!==($p['payload']['action']??'')||$r['destino_ref']===''||$r['destino_ref']!==($p['referencia']??''))){$p=array('ok'=>false,'codigo'=>'destino_ou_configuracao_alterado');}
-                if(empty($p['ok'])){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>$p['codigo'],'atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'pendente'));continue;}
-                if($wpdb->update(self::tabela(),array('estado'=>'incerto','codigo'=>'envio_iniciado','atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'pendente'))!==1){continue;}
+                if(empty($p['ok'])){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>$p['codigo'],'atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>$r['estado']));continue;}
+                if($wpdb->update(self::tabela(),array('estado'=>'incerto','codigo'=>'envio_iniciado','atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>$r['estado']))!==1){continue;}
                 try{$result=$p['adapter']->sendBound($p['payload'],$r['destino_ref']);}catch(Throwable $e){$result=array();}$result=is_array($result)?$result:array();$state=$result['status']??'incerto';if(!in_array($state,array('entregue','recusado'),true)||($state==='recusado'&&empty($result['non_delivery_proven']))){$state='incerto';}
+                if (F3Base_Conversoes_Servidor::retomar_ads($r['destino'],$result)) $state='bloqueado';
                 $wpdb->update(self::tabela(),array('estado'=>$state,'codigo'=>F3Base_Conversoes_Servidor::codigo($result['code']??null,$state),'http'=>max(0,min(599,(int)($result['http']??0))),'atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'incerto'));++$n;
             }$queries=self::reconciliar_incertos($lock);return array('ok'=>true,'processados'=>$n,'reconciliados'=>$queries);
         }finally{F3Base_Trava::liberar($lock);}
@@ -146,6 +147,7 @@
             if(!in_array($state,array('entregue','recusado'),true)||($state==='recusado'&&($result['non_delivery_proven']??false)!==true)){$state='incerto';}
             if($why===''&&($r['config_revisao']!==F3Base_Options::revisao(self::OPTION)||empty(F3Base_Qualidade::config()['ativo'])||!F3Base_Qualidade::etapa($r['etapa']))){$why='reconciliacao_configuracao_alterada';}
             if($why!==''){$state='incerto';}
+            elseif(F3Base_Conversoes_Servidor::retomar_ads($r['destino'],$result)){$state='bloqueado';}
             if(!F3Base_Trava::renovar($lock,120)){break;}
             $wpdb->update(self::tabela(),array('estado'=>$state,'codigo'=>$why?:F3Base_Conversoes_Servidor::codigo($result['code']??null,$state),'http'=>max(0,min(599,(int)($result['http']??0))),'atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'incerto','atualizado_em'=>$reserved));
         }
```
