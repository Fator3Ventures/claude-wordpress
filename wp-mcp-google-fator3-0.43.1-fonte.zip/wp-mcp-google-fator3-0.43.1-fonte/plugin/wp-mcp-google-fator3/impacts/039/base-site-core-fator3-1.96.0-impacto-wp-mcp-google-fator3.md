# Impacto do Site Core 1.96.0 no Fator3 MCP Google 0.39.0

**Revisão 2 · Entrega · Incorporação oficial concluída.** Pedidos MCP Google 57 e 58 e Core 431. Destinatário técnico: mantenedor do Google. A bancada verificou o contrato das duas filas. As duas edições oficiais estão ativas no Site-Teste. A frota e o titular da conta acompanham o aceite de campo.

| Artefato | SHA-256 |
|---|---|
| Core de base 1.95.0, instalador | `6971df93ecf39e14e584e0fc3dc802aee77ab4f2d58eb5b8ce35d6a503a4c21c` |
| Core 1.96.0 entregue, instalador | `dde2feadefdf08ab7973e7ea1be588b73709b723a088ef5549e43394aa7f73a5` |
| Google 0.39.0 entregue, instalador | `9a8cadb240e6398f1a85a833fcce46bb7b1bfa251d74c5111984547a5c453fce` |
| Proposta recebida do Google, guardada em `reference/1960/google-039-proposta.patch` | `f69872b6fc545e69d200cb6705a40aa8aa19b3fb3874ede4cb224bbf7449dd35` |

## Causa e contrato

O Google pode autorizar a reapresentação da transação após uma resposta ambígua, sob o código `ads_retry_same_transaction`. A ação e o identificador da transação são os mesmos. Na 1.95.0, uma linha incerta de aquisição podia ficar restrita à consulta de recibo, enquanto a fila de etapas selecionava somente linhas pendentes. A janela de sete dias das etapas também excluía eventos Ads ainda admitidos pelo produtor.

A 1.96.0 aceita a autorização explícita de mesma transação para os estados `recusado` e `incerto`. Os códigos `ads_action_unavailable`, `ads_terms_refused`, `ads_authorization_refused` e `ads_destination_refused` exigem recusa e `non_delivery_proven=true`. A retomada é específica de Google Ads. O evento pendente no Data Manager continua em reconciliação. A parte do Google já veio pronta no instalador 0.39.0.

## Incorporação no Core

- Em `includes/class-f3base-conversoes-servidor.php`, o Core trata o resultado de envio e de reconciliação. Preserva o orçamento nas recusas recuperáveis e no erro explicitamente repetível. Uma linha anterior com recusa registrada ou com o código expresso de repetição pode retomar mesmo se a base já contabilizou a décima tentativa. O processo revalida o contato, consentimento, clique, referência de destino e capacidade. Uma linha esgotada cuja única informação restante seja “limite de tentativas” não fornece evidência suficiente para reenvio automático.
- Em `includes/class-f3base-qualidade-destinos.php`, o Core conserva a referência de uma ação temporariamente sem prova, seleciona os estados e motivos previstos, aplica espera mínima de cinco minutos e confere a revisão da configuração. Aquisição e etapa continuam com identidades próprias. A janela Ads de até 90 dias também depende da idade do clique. O LinkedIn conserva a janela de sete dias.
- Em `includes/class-f3base-incidentes-provedores.php`, o coletor percorre as provas e as renovações das conexões. A regra de prazo usa a duração e o horário previsto da renovação. Para Ads com data residual antiga no banco, vale o prazo efetivo anunciado pela capacidade da conexão. A prova atual sem expiração encerra o aviso de prazo anterior. A recusa da ação ou o erro de renovação continua com seu código próprio.

## Prova e aceite

| Cenário no WordPress | Resultado |
|---|---|
| Produtor oficial com as duas filas | 44 verificações em PHP 8.3.6. Uma aquisição de 45 dias passou por 503 e retomou com o mesmo pedido. Uma etapa de 45 dias passou por recusa de termos, nova prova e reenvio do mesmo evento. O recibo aceito encerrou a aquisição sem terceiro envio. |
| Estados antigos e limites | 51 verificações em PHP 8.4.27, incluindo as 44 anteriores. Linhas antigas recusadas ou incertas com código expresso retomaram pelo ID original. Consentimento revogado, destino divergente e incerteza genérica impediram novo envio nos cenários exercitados. |
| Vigência e migração | Duas aberturas reproduzidas na 1.95.0. Primeira coleta da 1.96.0 recuperou as duas referências e enviou uma recuperação por destino ao coletor de e-mail. Nenhuma reabertura em 73 amostras horárias de uma janela simulada de 72 h. Inclui segunda conexão e prova com duração diferente. |
| Site-Teste | MCP 0.51.0, Core 1.96.0 e Google 0.39.0 ativos. As conversões Google da conexão consultada estavam desligadas. A prova de envio controlado ocorreu na bancada. |

Reprodução no README do fonte, com testes em `tests/196/` e resultados em `evidence/1960/`. A revisão inicial está em `reference/1960/planejamento-google.md`. O relatório do Google documenta o ensaio de seu patch na cópia da 1.95.0. Os resultados acima são do instalador oficial da 1.96.0.

**Ação dos responsáveis.** O mantenedor do Google pode registrar a incorporação do pedido 58 pelo Core. A frota instala o conjunto vigente por hash, acompanha a primeira coleta e as 72 horas de CTO Office e confere os recibos de conversões reais nos destinos autorizados. Casos com origem, consentimento ou destino insuficientes conservam o respectivo bloqueio.
