<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\{Automation\Alerts,Connections,Options,Settings};
use PHPUnit\Framework\TestCase;

final class AccessPolicy041Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = array();
        $GLOBALS['f3_test_caps'] = true;
        $GLOBALS['f3_test_user'] = 1;
        Connections::select('default');
    }

    public function test_preview_and_update_preserve_existing_alert_preferences(): void {
        $previous = array('minimum_interval' => 7200, 'events' => array('access'));
        Options::set(Alerts::OPTION, $previous);
        $this->assertSame(6 * HOUR_IN_SECONDS, Alerts::access_policy()['recheck_seconds']);
        $revision = Settings::revision();
        $change = array('configuration' => array('access_recheck_hours'=>3), 'expected_revision' => $revision);
        $preview = Alerts::configure($change + array('dry_run'=>true));
        $this->assertTrue($preview['success']);
        $this->assertTrue($preview['would_change']);
        $this->assertSame(3, $preview['proposed_access_recheck_hours']);
        $this->assertSame($revision, Settings::revision());
        $this->assertSame($previous, Options::get(Alerts::OPTION));
        $this->assertTrue(Alerts::configure($change)['success']);
        $this->assertSame(array('recheck_seconds'=>10800,'unused_seconds'=>86400), Alerts::access_policy());
        $this->assertSame(7200, Alerts::config()['minimum_interval']);
        $this->assertSame(array('access'), Alerts::config()['events']);
        $this->assertFalse(Alerts::configure($change + array('dry_run'=>true))['success']);
        $this->assertFalse(Alerts::configure($change)['success']);
    }

    public function test_reject_invalid_recheck_interval_without_a_write(): void {
        $revision = Settings::revision();
        foreach (array(0,169,'12', 1.5) as $value) {
            $result = Alerts::configure(array('configuration'=>array('access_recheck_hours'=>$value),'expected_revision'=>$revision));
            $this->assertSame('f3_google_alert_input', $result['error_code']);
        }
        $this->assertSame($revision, Settings::revision());
    }
}
