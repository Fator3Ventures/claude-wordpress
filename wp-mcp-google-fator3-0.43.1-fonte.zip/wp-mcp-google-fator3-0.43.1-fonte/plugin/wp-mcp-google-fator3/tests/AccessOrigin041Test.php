<?php
/** HTTP fixtures exercise the same ad hoc and scheduled entrypoints used in WordPress. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\{Automation\Context, Automation\Execution, Automation\Executor, Automation\Jobs, Connections, Http\GoogleClient, Integration\Ga4ServiceApi, Integration\QueryServiceApi, Integration\ServiceApi, Options, Records, Settings};
use PHPUnit\Framework\TestCase;

final class AccessOrigin041Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = [];
        $GLOBALS['f3_test_caps'] = true;
        $GLOBALS['f3_test_user'] = 1;
        FakeHttp::reset();
        Connections::select('default');
        Options::batch_verified([
            Options::ENABLED=>true, Options::GA_ENABLED=>true, Options::AUTH_MODE=>'oauth',
            Options::OAUTH_CLIENT_ID=>'test.apps.googleusercontent.com', Connections::SERVICES=>['ga'=>'read','gsc'=>'read'],
        ], [Options::OAUTH_CLIENT_SECRET=>'fixture-secret', Options::OAUTH_REFRESH_TOKEN=>'fixture-refresh']);
        FakeHttp::push('/token', 200, ['access_token'=>'fixture-token','expires_in'=>3600]);
    }

    private function open(): array {
        return array_values(array_filter(Records::list('incident'), static fn($row)=>$row['event']==='access' && $row['status']==='open'));
    }

    private function deny(string $match): void {
        FakeHttp::push($match, 403, ['error'=>['status'=>'PERMISSION_DENIED','message'=>'Fixture permission refused']]);
    }

    public function test_account_and_property_ad_hoc_denials_remain_visible_only_in_the_response(): void {
        foreach (['accounts/123','properties/456'] as $resource) {
            $url = GoogleClient::HOST_GA_ADMIN.'/v1alpha/'.$resource.'/accessBindings';
            $this->deny($url);
            $error = GoogleClient::get($url, [], ['connector'=>'ga','mode'=>'read','auth'=>false]);
            $this->assertTrue(is_wp_error($error));
            $this->assertSame(403, $error->get_error_data()['status']);
            $this->assertStringContainsString('Fixture permission refused', $error->get_error_message());
            $this->assertSame([], $this->open());
        }
    }

    public function test_executor_only_attributes_the_job_from_the_persisted_enabled_schedule(): void {
        $query = ['task'=>'query','parameters'=>['connector'=>'ga4','accounts'=>['123'],'metrics'=>['sessions'],'date_range'=>'last_7_days']];
        $intent = Jobs::schedule($query + ['schedule_id'=>'coleta']);
        $this->assertTrue($intent['success']);
        $scope = 'schedule:coleta:'.$intent['schedule']['revision'];
        $manual = Jobs::create($query + ['access_scope'=>$scope,'schedule_id'=>'coleta','idempotency_key'=>'schedule:coleta:um']);
        $this->assertTrue($manual['success']);
        $this->deny(':runReport');
        Jobs::run($manual['job_id']);
        $this->assertSame('', Context::job_scope(Records::get('job', $manual['job_id'])));
        $this->assertSame([], $this->open());

        $this->deny(':runReport');
        Executor::run(['max_items'=>1]);
        $schedule = Records::get('schedule', 'coleta');
        $this->assertSame($scope, Context::job_scope(Records::get('job', $schedule['last_job_id'])));
        $this->assertCount(1, $this->open());
        $this->assertSame($scope, $this->open()[0]['context']['scope']);
        $this->assertSame('', Context::access_scope());
        $url = GoogleClient::HOST_GA_DATA.'/v1beta/properties/123:runReport';
        $this->assertTrue(Context::can_recheck($scope, $url));
        $this->assertTrue(Connections::create('another', 'Outra conexão')['success']);
        $this->assertFalse(Connections::run('another', static fn()=>Context::can_recheck($scope,$url)));
        $legacy = Records::get('job', $schedule['last_job_id']);
        unset($legacy['access_scope']);
        $this->assertSame($scope, Context::job_scope($legacy));
        $changed = Jobs::schedule($query + ['schedule_id'=>'coleta','enabled'=>false,'expected_revision'=>$intent['schedule']['revision']]);
        $this->assertTrue($changed['success']);
        $this->assertFalse(Context::can_recheck($scope, $url));
    }

    public function test_registered_search_console_reader_distinguishes_manual_and_cron_and_grant_revisions(): void {
        $cfg = ['ready'=>true,'property'=>'sc-domain:example.test','revision'=>'1'];
        $client = ServiceApi::register_consumer('origin-reader','1.0.0',ServiceApi::CONTRACT,static fn()=>$cfg);
        $grant = ['consumer_id'=>'origin-reader','enabled'=>true,'expected_revision'=>Settings::revision()];
        $this->assertTrue(ServiceApi::configure($grant)['success']);
        $input = ['contract_version'=>ServiceApi::VERSION,'property'=>$cfg['property'],'consumer_revision'=>'1',
            'date'=>'2026-09-21','run_id'=>'reader-run','budget_ms'=>15000];
        foreach (['manual','http_cron'] as $trigger) {
            $this->deny('/searchAnalytics/query');
            $result = $client->query($input + ['trigger'=>$trigger]);
            $this->assertFalse($result['success']);
            $this->assertCount($trigger === 'manual' ? 0 : 1, $this->open());
        }
        $incident = $this->open()[0];
        $scope = $incident['context']['scope'];
        $this->assertTrue(Context::can_recheck($scope, $incident['resource']));
        $this->assertFalse(Context::can_recheck($scope, GoogleClient::HOST_GA_ADMIN.'/v1alpha/properties/1'));
        $this->assertTrue(ServiceApi::configure(['consumer_id'=>'origin-reader','enabled'=>false,'expected_revision'=>Settings::revision()])['success']);
        $this->assertFalse(Context::can_recheck($scope, $incident['resource']));
    }

    public function test_preflight_using_connection_defaults_retires_its_old_resource(): void {
        Options::set(Connections::BINDINGS, ['ga_property_id'=>'123']);
        $created = Jobs::schedule(['schedule_id'=>'preflight','task'=>'preflight','parameters'=>['services'=>['ga']]]);
        $this->assertTrue($created['success']);
        $scope = Context::schedule_scope(Records::get('schedule','preflight'));
        $url = GoogleClient::HOST_GA_ADMIN.'/v1beta/properties/123';
        $this->assertTrue(Context::can_recheck($scope, $url));
        Options::set(Connections::BINDINGS, ['ga_property_id'=>'456']);
        $this->assertFalse(Context::can_recheck($scope, $url));
    }

    public function test_ga4_and_gsc_query_readers_recheck_only_their_authorized_property(): void {
        foreach ([Ga4ServiceApi::class,QueryServiceApi::class] as $reader) {
            $ga = $reader === Ga4ServiceApi::class;
            $property = $ga ? 'properties/123' : 'sc-domain:example.test';
            $cfg = ['ready'=>true,'property'=>$property,'revision'=>'new'];
            $client = $reader::register_consumer('origin-query','1.0.0',$reader::CONTRACT,static fn()=>$cfg);
            $grant = ['contract'=>$reader::CONTRACT,'consumer_id'=>'origin-query','enabled'=>true,'expected_revision'=>Settings::revision()];
            if ($ga) {
                $grant['property'] = $property;
            }
            $this->assertTrue(ServiceApi::configure($grant)['success']);
            $input = ['contract_version'=>$reader::VERSION,'property'=>$property,'consumer_revision'=>'new',
                'run_id'=>'approved-job','trigger'=>'cli','budget_ms'=>10000];
            $input += $ga ? ['start_date'=>'2026-09-01','end_date'=>'2026-09-02','dimensions'=>['date'],'metrics'=>['sessions']] : ['date'=>'2026-09-01'];
            if (!$ga) {
                FakeHttp::push('/token', 200, ['access_token'=>'fixture-gsc','expires_in'=>3600]);
            }
            $this->deny($ga ? ':runReport' : '/searchAnalytics/query');
            $this->assertFalse($client->query($input)['success']);
            $episodes = array_values(array_filter($this->open(), static fn($row)=>str_contains($row['context']['scope'],$reader::CONTRACT)));
            $this->assertCount(1, $episodes);
            $this->assertTrue(Context::can_recheck($episodes[0]['context']['scope'],$episodes[0]['resource']));
            $this->assertFalse(Context::can_recheck($episodes[0]['context']['scope'],$episodes[0]['resource'].'-other'));
        }
    }

    public function test_invalid_success_and_quota_do_not_resolve_or_open_permissions(): void {
        $scope = 'schedule:fixture:revision';
        $url = GoogleClient::HOST_GA_ADMIN.'/v1alpha/properties/123/accessBindings';
        $opts = ['connector'=>'ga','mode'=>'read','auth'=>false,'operation_id'=>'analyticsadmin.properties.accessBindings.list'];
        $call = static fn()=>Execution::run(static fn()=>GoogleClient::get($url, [], $opts), 15, null, $scope);
        FakeHttp::push('accessBindings', 403, ['error'=>['message'=>'quotaExceeded']]);
        $this->assertSame(403, $call()->get_error_data()['status']);
        $this->assertSame([], $this->open());
        $this->deny('accessBindings');
        $this->assertTrue(is_wp_error($call()));
        $this->assertCount(1, $this->open());
        $member = array_values($this->open()[0]['context']['members'])[0];
        $this->assertSame($opts['operation_id'], $member['operation_id']);
        FakeHttp::push('accessBindings', 200, '{malformed json', ['content-type'=>'application/json']);
        $this->assertSame('f3_google_json', $call()->get_error_code());
        $this->assertCount(1, $this->open());
        FakeHttp::push('accessBindings', 200, ['accessBindings'=>[]]);
        $this->assertSame(['accessBindings'=>[]], $call());
        $this->assertSame([], $this->open());
    }
}
