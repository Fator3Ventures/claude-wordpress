<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\ConversionProof;
use PHPUnit\Framework\TestCase;

final class ConversionProof039Test extends TestCase {
    private function expired(): array {
        return ['revision'=>'current','expires'=>time()-300*DAY_IN_SECONDS,'at'=>time()-301*DAY_IN_SECONDS];
    }
    public function test_only_a_matching_conclusive_proof_can_authorize_the_grace_period(): void {
        $old=['result'=>'failed','revision'=>'current','provider_error'=>['phase'=>'ga4_stream_read','http_status'=>503]];
        $this->assertSame('stale_transient',ConversionProof::state('ga4',$this->expired(),$old,'current'));
        $this->assertFalse(ConversionProof::allows(ConversionProof::state('ga4',$this->expired(),$old,'changed')));
        $this->assertFalse(ConversionProof::allows(ConversionProof::state('ga4',[],$old,'current')));
        $this->assertSame('expired',ConversionProof::state('ga4',$this->expired(),[],'current'));
    }
    public function test_legacy_inconclusive_history_does_not_hide_prior_rejection(): void {
        $old=['result'=>'failed','revision'=>'current','provider_error'=>['phase'=>'ga4_secret_read','http_status'=>503]];
        $old['attempts']=[['provider_error'=>['phase'=>'ga4_secret_match','http_status'=>200]]];
        $this->assertSame('invalid',ConversionProof::state('ga4',$this->expired(),$old,'current'));
        $old['attempts']=[];$old['attempts_omitted']=1;
        $this->assertSame('unverified',ConversionProof::state('ga4',$this->expired(),$old,'current'));
    }
    public function test_ads_lifetime_depends_on_revision_and_provider_refusal(): void {
        $old=$this->expired();
        $this->assertTrue(ConversionProof::allows(ConversionProof::state('google_ads',$old,[],'current')));
        $old['rejected']='ads_terms_refused';
        $this->assertFalse(ConversionProof::allows(ConversionProof::state('google_ads',$old,[],'current')));
    }
    public function test_rate_and_network_failures_remain_separate_from_authentication(): void {
        foreach([408,425,429,500,503] as $http) $this->assertTrue(ConversionProof::temporary(['provider_error'=>['http_status'=>$http]]));
        foreach([400,401,403,404] as $http) $this->assertFalse(ConversionProof::temporary(['provider_error'=>['http_status'=>$http]]));
        $this->assertTrue(ConversionProof::temporary(['provider_error'=>['http_status'=>403,'reason'=>'QUOTA_EXCEEDED']]));
        $this->assertTrue(ConversionProof::temporary(['provider_error'=>['http_status'=>0,'phase'=>'execution']]));
    }
}
