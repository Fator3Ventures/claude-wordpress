<?php
declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Storage\DateFilter;
use PHPUnit\Framework\TestCase;

final class DateFilter040Test extends TestCase {
	public function test_fractional_bounds_match_only_stored_whole_seconds(): void {
		$second = strtotime( '2026-11-19T05:20:00Z' );
		$cases = array(
			array( '02:20:00.000-03:00', '05:20:00Z', $second - 1, $second ),
			array( '05:20:00.0000000001Z', '05:20:01.001Z', $second, $second + 1 ),
			array( '05:20:00.099Z', '05:20:00.100Z', $second, $second ),
			array( '05:20:00.1Z', '05:20:00.10000Z', $second, $second ),
		);
		foreach ( $cases as list( $from, $to, $lower, $upper ) ) {
			$this->assertSame( array( 'created_after' => $lower, 'created_before' => $upper ),
				DateFilter::parse( array( 'from' => '2026-11-19T' . $from, 'to' => '2026-11-19T' . $to ) ) );
		}
		$end = strtotime( '2026-11-19T23:59:59Z' );
		$this->assertSame( array( 'created_after' => $end, 'created_before' => $end ),
			DateFilter::parse( array( 'from' => '2026-11-19T23:59:59.9Z', 'to' => '2026-11-19' ) ) );
	}

	public function test_invalid_and_reversed_instants_keep_the_callers_error_code(): void {
		$cases = array(
			array( 'from' => '2026-11-19T02:20:00.001000001-03:00', 'to' => '2026-11-19T05:20:00.001Z' ),
			array( 'from' => '2026-11-19T02:20:00.Z' ),
			array( 'from' => '2026-11-19T02:20:00.000' ),
			array( 'to' => '2026-02-30T02:20:00.000Z' ),
		);
		foreach ( $cases as $input ) {
			$error = DateFilter::parse( $input, 'f3_google_audit_dates' );
			$this->assertInstanceOf( \WP_Error::class, $error );
			$this->assertSame( 'f3_google_audit_dates', $error->get_error_code() );
		}
	}
}
