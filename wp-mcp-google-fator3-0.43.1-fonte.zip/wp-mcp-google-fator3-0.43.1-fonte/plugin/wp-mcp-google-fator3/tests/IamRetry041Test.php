<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\{Connections,Options};
use Fator3\McpGoogle\Auth\KeyStatus;
use PHPUnit\Framework\TestCase;

final class IamRetry041Test extends TestCase {
    private function set_key(string $id): string {
        $key = ['client_email'=>'fixture@lab.example','private_key_id'=>$id];
        Options::set(Options::AUTH_MODE,'service_account');
        Options::set_secret(Options::SA_JSON, wp_json_encode($key));
        return hash('sha256',wp_json_encode([$key['client_email'],$id]));
    }

    public function test_upgrade_reads_the_previous_denial_and_preserves_it_through_transient_failures(): void {
        Connections::select('default');
        $fingerprint = $this->set_key('fixture-a');
        $at = 1795100400;
        $record = ['fingerprint'=>$fingerprint,'iam_denied'=>true,'outcome'=>'permission_denied','last_attempt'=>$at];
        Options::set(KeyStatus::STATE,$record);
        $this->assertSame($at+HOUR_IN_SECONDS,KeyStatus::status()['next_attempt']);
        $record['outcome'] = 'unavailable';
        Options::set(KeyStatus::STATE,$record);
        $this->assertSame($at+HOUR_IN_SECONDS,KeyStatus::status()['next_attempt']);
        $record['iam_denied'] = false;
        $record['outcome'] = 'available';
        Options::set(KeyStatus::STATE,$record);
        $this->assertSame($at+6*HOUR_IN_SECONDS,KeyStatus::status()['next_attempt']);
        $this->set_key('fixture-b');
        $this->assertNull(KeyStatus::status()['next_attempt']);
    }

    public function test_oauth_has_no_key_to_monitor(): void {
        Connections::select('default');
        Options::set(Options::ENABLED,true);
        $fingerprint=$this->set_key('fixture-c');
        Options::set(KeyStatus::STATE,['fingerprint'=>$fingerprint,'iam_denied'=>true,'outcome'=>'permission_denied','last_attempt'=>time()]);
        Options::set(Options::AUTH_MODE,'oauth');
        $this->assertFalse(KeyStatus::status()['applicable']);
        $this->assertNull(KeyStatus::status()['next_attempt']);
        FakeHttp::reset();
        KeyStatus::refresh_due();
        $this->assertSame(0,FakeHttp::count());
    }
}
