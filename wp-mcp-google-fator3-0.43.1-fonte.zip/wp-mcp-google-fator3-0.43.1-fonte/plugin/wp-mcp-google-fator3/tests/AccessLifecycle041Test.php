<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\{Automation\AccessIncidents, Automation\Alerts, Automation\Jobs, Connections, Http\GoogleClient, Lock, Options, Records};
use PHPUnit\Framework\TestCase;

final class AccessLifecycle041Test extends TestCase {
    private const ACCOUNT = 'https://analyticsadmin.googleapis.com/v1alpha/accounts/123/accessBindings';
    private const PROPERTY = 'https://analyticsadmin.googleapis.com/v1alpha/properties/456/accessBindings';
    private const REPORT = 'https://analyticsdata.googleapis.com/v1beta/properties/456:runReport';

    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = [];
        $GLOBALS['f3_test_caps'] = true;
        $GLOBALS['f3_test_user'] = 1;
        FakeHttp::reset();
        Options::batch_verified([
            Options::ENABLED=>true, Options::GA_ENABLED=>true, Options::AUTH_MODE=>'oauth',
            Options::OAUTH_CLIENT_ID=>'tests.apps.googleusercontent.com', Connections::SERVICES=>['ga'=>'read','gsc'=>'read'],
        ], [Options::OAUTH_CLIENT_SECRET=>'fixture-secret', Options::OAUTH_REFRESH_TOKEN=>'fixture-refresh']);
    }

    private function episodes(): array {
        return array_values(array_filter(Records::list('incident'), static fn($r)=>$r['event']==='access'));
    }

    private function due(string $id, ?int $age = null): void {
        $row = Records::get('incident', $id);
        $row['run_after'] = $row['context']['next_check_at'] = time()-1;
        foreach ($row['context']['members'] as &$member) {
            unset($member['check_after']);
            if ($age !== null) $member['last_used_at'] = time()-$age;
        }
        unset($member);
        Records::put('incident', $id, $row);
    }

    public function test_group_scopes_and_principals_then_close_only_on_the_last_restored_member(): void {
        AccessIncidents::observe('GET', self::ACCOUNT, 403, 'schedule:first');
        AccessIncidents::observe('GET', self::ACCOUNT, 403, 'schedule:first');
        AccessIncidents::observe('GET', self::PROPERTY, 401, 'schedule:first');
        [$episode] = $this->episodes();
        $this->assertCount(2,$episode['context']['members']);
        $this->assertSame(1,$episode['generation']);
        AccessIncidents::observe('GET', self::ACCOUNT, 403, 'schedule:second');
        AccessIncidents::observe('GET', self::ACCOUNT, 200, '');
        AccessIncidents::observe('GET', self::ACCOUNT, 200, 'schedule:first');
        $partial = Records::get('incident',$episode['id']);
        $this->assertSame('open',$partial['status']);
        $this->assertCount(1,$partial['context']['members']);
        AccessIncidents::observe('GET', self::PROPERTY, 429, 'schedule:first');
        AccessIncidents::observe('GET', self::PROPERTY, 200, 'schedule:first');
        $closed = Records::get('incident',$episode['id']);
        $this->assertSame('resolved',$closed['status']);
        $this->assertTrue($closed['notify_recovery']);
        $this->assertSame(2,$closed['generation']);
        AccessIncidents::observe('GET', self::ACCOUNT, 403, 'schedule:first');
        $this->assertSame(3,Records::get('incident',$episode['id'])['generation']);
        Options::set_secret(Options::OAUTH_REFRESH_TOKEN,'another-fixture-identity');
        AccessIncidents::observe('GET', self::ACCOUNT, 403, 'schedule:first');
        $this->assertCount(3,$this->episodes());
    }

    public function test_first_scheduled_success_or_denial_retires_the_exact_legacy_url_silently(): void {
        foreach ([self::ACCOUNT,self::PROPERTY] as $url) Alerts::observe('access',$url,true,'http_403','Permissão');
        AccessIncidents::observe('GET', self::ACCOUNT, 200, 'schedule:a');
        AccessIncidents::observe('GET', self::PROPERTY, 403, 'schedule:a');
        $old = Records::get('incident', hash('sha256','default|access|'.self::ACCOUNT));
        $this->assertSame('consolidado',$old['status']);
        $this->assertFalse($old['notify_recovery']);
        $this->assertTrue($old['reconciled_by_scheduled_use']);
        $second = Records::get('incident', hash('sha256','default|access|'.self::PROPERTY));
        $this->assertSame('consolidado',$second['status']);
        $this->assertSame('open',Records::get('incident',$second['superseded_by'])['status']);
    }

    public function test_unused_migration_preserves_the_last_old_observation_and_skips_key_metadata(): void {
        Alerts::observe('access', self::ACCOUNT, true, 'http_403', 'Permissão');
        Alerts::observe('access', self::PROPERTY, true, 'http_403', 'Permissão');
        Alerts::observe('key_metadata', 'iam', true, 'http_403', 'Permissão');
        $old_id = hash('sha256','default|access|'.self::ACCOUNT);
        $row = Records::get('incident', $old_id);
        $row['updated_at'] = $prior = time()-DAY_IN_SECONDS;
        Records::put('incident',$old_id,$row);
        AccessIncidents::tick();
        $old = Records::get('incident',$old_id);
        $this->assertSame('nao_usado',$old['status']);
        $this->assertFalse($old['notify_recovery']);
        $this->assertSame($prior,$old['context']['last_used_at']);
        $young = Records::get('incident',hash('sha256','default|access|'.self::PROPERTY));
        $this->assertSame('open',$young['status']);
        $this->assertSame(DAY_IN_SECONDS,$young['run_after']-$young['context']['last_used_at']);
        $this->assertSame('open',Records::get('incident',hash('sha256','default|key_metadata|iam'))['status']);
        $this->assertSame(0,FakeHttp::count());
    }

    public function test_due_authorized_probe_with_bad_json_denial_and_verified_recovery_never_counts_as_use(): void {
        $job = Jobs::schedule(['schedule_id'=>'test-read','task'=>'query','parameters'=>['connector'=>'ga4','accounts'=>['456'],'metrics'=>['sessions'],'date_range'=>'yesterday']]);
        $this->assertTrue($job['success']);
        $scope = 'schedule:test-read:'.$job['schedule']['revision'];
        AccessIncidents::observe('POST',self::REPORT,403,$scope);
        [$open] = $this->episodes();
        $this->assertSame(6*HOUR_IN_SECONDS,$open['run_after']-$open['context']['last_used_at']);
        FakeHttp::push('/token',200,['access_token'=>'fixture-token','expires_in'=>3600]);
        foreach ([
            [200,'{truncated','open'],
            [403,['error'=>['status'=>'PERMISSION_DENIED']],'open'],
            [200,['rows'=>[],'metricHeaders'=>[['name'=>'activeUsers']]],'resolved'],
        ] as [$code,$body,$state]) {
            $this->due($open['id'],HOUR_IN_SECONDS);
            $before = Records::get('incident',$open['id']);
            FakeHttp::push(':runReport',$code,$body,['content-type'=>'application/json'],'POST');
            AccessIncidents::tick();
            $actual = Records::get('incident',$open['id']);
            $this->assertSame($state,$actual['status']);
            $this->assertSame($before['context']['last_used_at'],$actual['context']['last_used_at']);
            if ($state === 'open') $this->assertSame(array_column($before['context']['members'],'last_used_at'),array_column($actual['context']['members'],'last_used_at'));
        }
        $calls = array_filter(FakeHttp::$requests,static fn($r)=>$r['url']===self::REPORT);
        $this->assertCount(3,$calls);
        foreach ($calls as $call) $this->assertSame('1',json_decode($call['body'],true)['limit']);
        AccessIncidents::tick();
        $this->assertSame(4,FakeHttp::count());
    }

    public function test_empty_list_requires_an_actual_json_object_on_the_affected_url(): void {
        $member = ['method'=>'GET', 'url'=>self::ACCOUNT, 'operation_id'=>'analyticsadmin.accounts.accessBindings.list'];
        FakeHttp::push('/token',200,['access_token'=>'fixture-token','expires_in'=>3600]);
        foreach (['','[]','<html></html>','{broken','{}','{"accessBindings":[]}'] as $body) {
            FakeHttp::push('accessBindings',200,$body,['content-type'=>'application/json'],'GET');
            $this->assertSame(in_array($body,['{}','{"accessBindings":[]}'],true),
                \Fator3\McpGoogle\Automation\AccessProbe::succeeds($member,'schedule:test'));
        }
    }

    public function test_unused_member_skips_http_and_retries_the_silent_outbox_after_contention(): void {
        AccessIncidents::observe('GET',self::ACCOUNT,403,'schedule:test');
        [$row] = $this->episodes();
        $notice_id = hash('sha256','default|integracao_indisponivel|'.$row['id']);
        $held = Lock::acquire('technical:'.$notice_id,30);
        $this->due($row['id'],DAY_IN_SECONDS);
        AccessIncidents::tick();
        $silent = Records::get('incident',$row['id']);
        $this->assertSame('nao_usado',$silent['status']);
        $this->assertTrue($silent['access_notice_pending']);
        $this->assertFalse($silent['notify_recovery']);
        Lock::release($held);
        $silent['run_after'] = time()-1;
        Records::put('incident',$row['id'],$silent);
        AccessIncidents::tick();
        $this->assertFalse(Records::get('incident',$row['id'])['access_notice_pending']);
        $this->assertSame('nao_usado',Records::get('technicalnotice',$notice_id)['event']['motivo_encerramento']);
        $this->assertSame(0,FakeHttp::count());
    }

    public function test_private_nested_urls_are_only_opaque_and_still_match_real_scheduled_recovery(): void {
        $url = GoogleClient::HOST_GOOGLE.'/webmasters/v3/sites/'.rawurlencode('https://example.test/?private=private-fixture');
        $opts = ['site_url'=>'https://example.test/?private=private-fixture'];
        AccessIncidents::observe('GET',$url,403,'schedule:test',$opts);
        [$open] = $this->episodes();
        $this->assertStringNotContainsString('private-fixture',wp_json_encode($open));
        AccessIncidents::observe('GET',$url,200,'schedule:test',$opts);
        $this->assertSame('resolved',Records::get('incident',$open['id'])['status']);
    }
}
