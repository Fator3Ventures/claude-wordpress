<?php
declare(strict_types=1);
namespace WpMcpUltimate\Admin;
use Fator3\McpFiles\{Admin,ConnectionEndpoints,ConnectionStatus,ConnectionTest,ConnectionsAdmin,Locks,Result};

class Ajax {
    public static function init(): void {
        foreach (['generate_key','revoke_key','test_connection'] as $action) add_action('wp_ajax_wp_mcp_ultimate_' . $action, [self::class, $action]);
    }
    private static function authorize(): void {
        check_ajax_referer('wp-mcp-ultimate', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Permissão insuficiente.'], 403);
        nocache_headers();
    }
    private static function respond(array $result): void {
        if (empty($result['success'])) wp_send_json_error($result);
        wp_send_json_success($result);
    }
    public static function generate_key(): void {
        self::authorize();
        $result = Locks::run(['credential:' . get_current_blog_id() . ':' . get_current_user_id() => LOCK_EX], static function(): array {
            clean_user_cache(get_current_user_id());
            if (ConnectionStatus::key()) return Result::fail('credential_exists', 'Já existe uma senha cadastrada. Revogue-a explicitamente antes de criar outra.');
            if (!wp_is_application_passwords_available()) return Result::fail('application_password_unavailable', 'Senhas de aplicação indisponíveis. Confira HTTPS e as restrições do site.');
            $profile = isset($_POST['profile']) && is_string($_POST['profile']) ? wp_unslash($_POST['profile']) : 'read';
            if (!in_array($profile, ['read', 'content'], true)) return Result::fail('profile_invalid', 'Selecione Leitura ou Conteúdo; perfis avançados ficam em Clientes conectados.');
            $user = wp_get_current_user();
            $created = ConnectionsAdmin::save(['intent'=>'create','user_id'=>$user->ID,'profile'=>$profile,'label'=>'Fator3 MCP']);
            if (empty($created['success']))return $created;
            $password = $created['application_password'];
            $uuid = substr($created['connection_id'], 4);
            try {
                update_user_meta($user->ID,'f3_mcp_app_password',$uuid);
                $tracked = get_user_meta($user->ID,'f3_mcp_app_password',true)===$uuid;
            } catch (\Throwable $e) {
                $tracked = false;
            }
            if (!$tracked) {
                return ConnectionsAdmin::discard_unissued($user->ID,$uuid,Result::fail('credential_save_failed','Falha ao guardar a referência da senha.'));
            }
            delete_user_meta($user->ID, 'f3_mcp_connection_test');
            return Result::ok(['profile' => $profile, 'connection_id' => $created['connection_id'], 'password' => $password, 'username' => $user->user_login, 'base64' => base64_encode($user->user_login . ':' . $password)], 'Senha de aplicação criada.');
        });
        self::respond($result);
    }
    public static function revoke_key(): void {
        self::authorize();
        $result = Locks::run(['credential:' . get_current_blog_id() . ':' . get_current_user_id() => LOCK_EX], static function(): array {
            clean_user_cache(get_current_user_id());
            $user = get_current_user_id(); $item = ConnectionStatus::key();
            if ($item) {
                $deleted = ConnectionsAdmin::save(['intent' => 'revoke', 'connection_id' => 'app:' . $item['uuid'], 'user_id' => $user]);
                if (empty($deleted['success']) || ConnectionStatus::key()) return Result::fail('credential_revoke_failed', 'Não foi possível confirmar a revogação.');
            }
            delete_user_meta($user, 'f3_mcp_app_password');
            if (get_user_meta($user, 'f3_mcp_app_password', true)) return Result::fail('credential_reference_failed', 'A senha foi revogada, mas a referência não foi removida. Atualize a página e tente novamente.');
            delete_user_meta($user, 'f3_mcp_connection_test');
            return Result::ok([], $item ? 'Senha revogada.' : 'Nenhuma senha ativa para revogar.');
        });
        self::respond($result);
    }
    public static function test_connection(): void {
        self::authorize();
        $route = isset($_POST['route']) && is_string($_POST['route']) ? wp_unslash($_POST['route']) : ConnectionEndpoints::route();
        self::respond(ConnectionTest::run($route));
    }
}
