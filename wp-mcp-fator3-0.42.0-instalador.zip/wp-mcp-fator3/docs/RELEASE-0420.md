# Fator3 MCP 0.42.0 — Retenção de pré-imagens de pacotes

## Pedido MCP 78

Uma atualização de plugin pode guardar a versão anterior como pré-imagem. Para revisar as cópias do Site Core, execute `backups/prune` em simulação.

```json
{"policy":"package_preimages","plugin":"base-site-core-fator3","older_than_days":2,"dry_run":true}
```

O filtro aceita o slug da pasta ou o caminho completo do arquivo principal. Sem filtro, a política abrange todos os plugins. Uma pré-imagem pode entrar na seleção quando houve uma troca posterior concluída do mesmo plugin **ou** quando sua criação é anterior a `age_cutoff`. Esse instante, em segundos Unix UTC, é fixado na primeira página. O prazo padrão é de 30 dias. Uma cópia recente substituída pode entrar pela primeira regra. Uma cópia antiga da última versão pode entrar pela segunda.

| Resultado da simulação | Próxima ação |
|---|---|
| `selection_status: inventory_incomplete` | A varredura atingiu o limite de itens ou de tempo. Reenvie os mesmos parâmetros com `cursor` igual ao `next_cursor` recebido. Ainda não há lote para confirmar. |
| `selection_status: more_candidates` | O inventário terminou. Confira as cópias e os bytes deste lote. Use o cursor para consultar outra página. |
| `selection_status: complete` | A consulta chegou ao fim. Confira os itens em `blocked` e as exclusões antes de decidir o que remover. |

Cada página examina até 200 envelopes ou apresenta até 200 candidatos do índice. A continuação pertence à conexão, ao site e aos critérios da prévia, e vence em uma hora. Para aplicar um lote, envie `dry_run:false` com seu `expected_selection_sha256`. Depois da aplicação, inicie uma nova simulação. Referências ativas, componentes alterados e cópias excluídas pelos critérios continuam protegidos. A atualização do plugin e a abertura da tela de configuração não executam a limpeza.
