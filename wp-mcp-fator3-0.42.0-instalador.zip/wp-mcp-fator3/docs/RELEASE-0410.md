# Fator3 MCP 0.41.0 — consulta de conexões, edição do próprio perfil e Registro

Requisitos mínimos de WordPress 7.1.4 e PHP 8.3. Instalação limpa ou atualização direta da 0.40.0. O conjunto de referência desta versão inclui Core 1.71.0, Google 0.28.0, Meta 0.21.0, LinkedIn 0.18.0 e Pipedrive 0.7.0. Consulte `atualizacao` para conferir o instalador e verificar a troca.

## Registro de atividade

Abra Ferramentas → Fator3 MCP → Registro. Os filtros de identificação do evento ficam separados do resultado e do período em UTC. O campo Habilidade aceita o ID exato, inclusive de uma habilidade removida, e oferece sugestões baseadas nos eventos da página. Ao avançar, a consulta preserva os valores do alvo e das datas, inclusive caracteres como `+`, `&` e `#`. O início da janela é inclusivo e o término é exclusivo. Uma data inválida exibe um alerta. A consulta sem eventos tem uma mensagem própria.

## Listagem de conexões

`connections/list` usa as políticas já lidas na página e consulta as credenciais correspondentes em lote. O resultado distingue “Ativa” de “Sem acesso” considerando o perfil, o estado, a validade e a credencial. Use `next_before_id` como `before_id` na continuação. O estado vale para aquela leitura. Uma execução posterior exige autorização atual.

## Confirmação da própria política

`connections/update` passa a gravar o nome informado em `label`. Se a prévia tiver sido emitida na 0.40.0 com esse campo, gere outra para confirmar o nome desejado. Após uma confirmação concluída, repetir a mesma solicitação com o mesmo token e a mesma credencial ainda autorizada recupera o recibo e sua revisão, com `replayed:true`. A revisão de uma escrita nova é verificada antes de aplicá-la. O documento `administracao` explica como proceder com revisão vencida, acesso revogado ou resultado incerto.

Esta rodada preserva o schema de dados 2 e o contrato de perfis 1. A troca de software dispensa reemitir credenciais. O relatório externo distingue os testes locais e o aceite no Site-Teste.
