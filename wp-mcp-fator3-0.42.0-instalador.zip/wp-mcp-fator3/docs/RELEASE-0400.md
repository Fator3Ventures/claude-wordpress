# Fator3 MCP 0.40.0 — administração de clientes e configuração do site

Atualização direta da 0.39.0 ou instalação limpa. Requisitos do projeto: WordPress 7.1.4 e PHP 8.3. Consulte ATUALIZACAO para conferir o instalador e a saúde após a troca.

## O que mudou para o administrador

- Em Ferramentas → Fator3 MCP, o menu separa Configuração de Operação. No celular, abra Menu para trocar de seção.
- Clientes conectados abre a lista e conta as sessões ativas da página em uma consulta. Use Editar para alterar uma política existente, Associar identidade existente para atribuir o primeiro perfil ou Emitir senha de aplicação para criar uma credencial. O formulário de emissão tem um comprovante que impede emitir uma segunda senha ao atualizar a página. Revogar fica em uma seção independente e exige confirmação explícita.
- O editor agrupa conta, perfil, expiração e permissões. A pesquisa de habilidades preserva as seleções. Permissões indisponíveis no catálogo continuam identificadas quando integravam uma política anterior. Uma edição incompleta ou uma revisão vencida é recusada.
- Arquivos e banco mostra separadamente o estado do canal, a escrita SQL, o limite de arquivos e a retenção. Cada botão salva somente a seção correspondente. Se outra pessoa mudar o canal ou a escrita, leia o estado atual antes de enviar novamente.
- Em Atualizações, uma URL simples previamente gravada pelo MCP aparece como “A confirmar”. Confira-a e salve para transformá-la em descritor de manifesto. O fluxo habitual da frota usa o ZIP versionado. A atualização do plugin por si só não ativa uma fonte.
- Em Ajuda, pesquise expressões como “revogar acesso” e abra diretamente a seção encontrada. As orientações atuais de administração têm precedência sobre as notas históricas nos primeiros resultados.

## Para agentes e operadores

Comece por system/health com compact:true e system/guide com document:"administracao". Use system/guide com query para pesquisar ou com ability para consultar o schema vivo. As operações connections/*, system/settings*, db/execute e db/restore mantêm seus nomes, perfis e confirmações. A entrada selected_rows da 0.39.0 continua documentada em RELEASE-0390.

A migração não cria tabelas, não rotaciona credenciais e não exige reconfigurar clientes. A abertura da Ajuda e o carregamento da lista não consultam provedores externos. Em falha após uma troca, confira o recibo e corrija por nova versão. A matriz e as provas executadas constam do relatório da entrega.
