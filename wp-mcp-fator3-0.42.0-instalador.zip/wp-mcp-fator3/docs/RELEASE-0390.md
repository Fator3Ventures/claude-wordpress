# Fator3 MCP 0.39.0 — Pedido MCP 77

Base de migração 0.38.0. Requisitos WordPress 7.1.4 ou superior e PHP 8.3 ou superior. Pacotes de referência: Core 1.69.0, Google 0.26.0, Meta 0.19.0 e LinkedIn 0.17.1. Pipedrive 0.5.0 observado no Site-Teste. Sem nova credencial, tabela, opção ou mudança de política. Instale o ZIP da versão sobre o mesmo slug e confira system/health. Qualquer correção pós-instalação segue em nova versão.

## Escrita pontual

Em Ferramentas → Fator3 MCP, o canal de arquivos e a escrita SQL devem estar habilitados. O usuário precisa de manage_options e a conexão do perfil Manutenção. Descubra db/execute, db/restore, operations/status e seus schemas antes da operação.

1. Prepare uma prévia com o objeto abaixo, substituindo o exemplo por uma tabela e valores autorizados. Omitir backup_scope mantém a cópia integral. selected_tables continua recuperando a tabela completa.
2. Confira selected_rows, target_tables, selection_exact, guard_contract igual a selection-guard/2, a apresentação redigida e backup_scope igual a selected_rows. limit_preview limita só a exibição.
3. Repita os mesmos campos acrescentando o confirm_token recebido, válido por dez minutos. Confira applied, persisted, affected_rows, backup_id e a contagem de linhas verificadas. Identidades, schema, bytes anteriores e chaves únicas são revalidados sob locks na mesma transação. A cópia é privada e verificada antes do UPDATE. Falha da cópia impede a escrita. Prévia com zero linhas permite confirmar um efeito vazio.
4. Em caso de perda da resposta, consulte operations/status pelo operation_id. Repetir a mesma confirmação concluída devolve o recibo já gravado. Se o estado estiver running ou applied for null, reconcilie a linha e o recibo antes de emitir outra operação.

```json
{"sql":"UPDATE wp_exemplo SET valor='novo' WHERE id=46","backup_scope":"selected_rows","limit_preview":1}
```

O modo aceita um UPDATE com WHERE, de até 200 linhas, em uma tabela InnoDB com identidade primária ou única não nula. A simulação copia somente a seleção para uma tabela temporária. A consulta de seleção pode examinar mais linhas se o predicado não usar índice. Não permite alterar colunas de índice único, acessar options/usermeta, usar JOIN, subconsulta, trigger, chave estrangeira ou formas que a guarda não modele. O limite geral de 64 MiB e 30 s do planejador também se aplica. Uma operação inelegível falha antes da escrita. O modo não muda automaticamente para cópia integral. Use outro escopo explicitamente quando a operação o exigir.

## Restaurar pelo backup_id

Passe o backup_id do recibo como artifact_id em db/restore. A primeira chamada retorna preview, confirm_token e restores_entire_tables:false. Confira a tabela e o número de linhas. Repita o mesmo objeto com o token de restauração. A restauração compara cada linha com a pós-imagem, verifica o schema e salva uma cópia das linhas atuais antes de restaurar. O recibo traz o backup_id dessa cópia e affected_rows. Linhas fora da seleção continuam com seu valor corrente.

```json
{"artifact_id":"<backup_id recebido de db/execute>"}
```

Se a linha foi removida ou modificada, restore_destination_changed cancela a operação. Alteração de schema também bloqueia a recuperação. allow_changed_destination:true é recusado neste modo. Para verificar, leia as colunas relevantes por chave em db/query. O backup continua disponível para análise autorizada. backups/list com category sql_artifacts lista os metadados, formato sql_rows e escopo selected_rows. A retenção mantém as regras existentes de referência e poda. O conteúdo privado guarda os bytes originais (inclusive dados sensíveis); a apresentação redigida nunca é usada como origem da restauração.

Consulte o relatório externo para o ambiente efetivamente validado e o aceite na frota.
