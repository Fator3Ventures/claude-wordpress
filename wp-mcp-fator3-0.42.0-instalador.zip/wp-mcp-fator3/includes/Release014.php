<?php
/** 0.14 contracts; registered before the common authorization/audit decorator. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SafeOutput {
    /** Minimal presentation context from the resolved dispatch, never from returned data. */
    public static function call_context(string $ability, array $input): array {
        if(in_array($ability,['wp-mcp-ultimate/execute-ability','wp-mcp-ultimate/execute-readonly-ability'],true)) {
            $ability=is_string($input['ability_name']??null)?$input['ability_name']:'';
            $input=$input['parameters']??[];
            if(is_string($input))$input=json_decode($input,true);
            if($input instanceof \stdClass)$input=(array)$input;
            if(!is_array($input))return [];
        }
        if(!in_array($ability,['f3base/config-core-escrever','f3base/config-core-ler','f3base/conteudo-instrumentacao-ler'],true))return [];
        return ['ability'=>$ability,'option'=>is_string($input['nome']??null)?$input['nome']:''];
    }
    /** Public diagnostic types only; raw SQL/options keep DataSafety's policy. */
    public static function error(array $data, array $path=[], array $context=[]): array {
        $safe=[];
        foreach($data as $key=>$value){
            $childPath=[...$path,(string)$key];
            if(self::policy_path($childPath,$data,$context)) $safe[$key]=self::policy_rules($value);
            elseif(self::inherited_keys_path($childPath,$context))$safe[$key]=self::key_paths($value);
            elseif(self::interface_path($childPath,$context))$safe[$key]=self::interface_text($value);
            elseif(in_array($key,['checks_passed','all_checks_passed','passed','token_configured','secret_configured','cache_bypass_verified'],true) && is_bool($value)) $safe[$key]=$value;
            elseif(in_array($key,['passed','credential_generation','credential_revision','authorization_revision'],true) && is_int($value) && $value>=0) $safe[$key]=$value;
            elseif($key==='credential' && (is_array($value)||$value instanceof \stdClass)) {
                // Do not open this container recursively: unknown children are secret.
                $public=[];
                foreach((array)$value as $child=>$leaf) $public[$child]=$child==='configured'&&is_bool($leaf)?$leaf:'[redigido]';
                $safe[$key]=$value instanceof \stdClass?(object)$public:$public;
            }
            elseif(in_array($key,['input_schema','output_schema'],true) && (is_array($value)||$value instanceof \stdClass)) $safe[$key]=self::schema($value,false,$childPath,$context);
            elseif(in_array($key,['confirm_token','confirmation_token'],true) && is_string($value) && preg_match('/^[a-f0-9]{64}$/D',$value)) $safe[$key]=$value;
            elseif(DataSafety::sensitive_field((string)$key,$value)&&$key!=='error_code')$safe[$key]='[redigido]';
            elseif(in_array($key,['message','error','error_description','last_error_message'],true)&&is_string($value))$safe[$key]=DataSafety::diagnostic_text($value);
            else $safe[$key]=self::value($value,$childPath,$context);
        }
        return $safe;
    }
    public static function value($value, array $path=[], array $context=[]) {
        if(is_array($value)||$value instanceof \stdClass) {
            $node=(array)$value;
            // Providers also embed closed JSON schemas in `contracts`/configuration
            // results. Preserve property descriptors without exempting their values.
            if(in_array('object',(array)($node['type']??[]),true)&&isset($node['properties'])&&(is_array($node['properties'])||$node['properties'] instanceof \stdClass))return self::schema($value,false,$path,$context);
        }
        if(is_array($value))return self::error($value,$path,$context);
        if($value instanceof \stdClass)return (object)self::error((array)$value,$path,$context);
        // Preserve custom serializers; the transport sanitizes their decoded JSON.
        return DataSafety::secret_value($value)?'[redigido]':$value;
    }
    /** Only the Core's published policy locations. Never a global token-name exception. */
    private static function policy_path(array $path, array $parent, array $context): bool {
        // The executor adds one data envelope; WP_Error can add a second one.
        $path=self::domain_path($path);
        $option='f3base_formularios_sinais';
        if(($parent['option']??null)===$option) {
            if($path===['avisos','sinais_formularios','regras'])return true;
            if(count($path)===4 && $path[0]==='assuntos' && preg_match('/^(?:0|[1-9][0-9]*)$/D',$path[1]) && $path[2]==='sinais_formularios' && $path[3]==='regras')return true;
        }
        if(count($path)===3 && $path[0]==='opcoes' && $path[1]===$option && in_array($path[2],['valor','padrao_declarado','valor_efetivo','valor_bruto'],true))return true;
        // Applied Core writes omit nome. Only this exact resolved call supplies its identity.
        if($path===['lido'] && ($context['ability']??'')==='f3base/config-core-escrever' && ($context['option']??'')===$option && (!isset($parent['nome'])||$parent['nome']===$option))return true;
        return count($path)===1 && ($parent['nome']??null)===$option && in_array($path[0],['antes','depois','lido'],true);
    }
    private static function domain_path(array $path): array {
        for($i=0;$i<2 && ($path[0]??null)==='data';++$i)array_shift($path);
        return $path;
    }
    private static function inherited_keys_path(array $path, array $context): bool {
        $path=self::domain_path($path);
        return ($context['ability']??'')==='f3base/config-core-ler' && count($path)===3 && $path[0]==='opcoes' && preg_match('/^f3base_[a-z0-9_]+$/D',$path[1]) && $path[2]==='chaves_herdadas' && (($context['option']??'')===''||$context['option']===$path[1]);
    }
    private static function key_paths($value) {
        if($value===null)return null;
        if(!is_array($value)||!array_is_list($value)||count($value)>4096)return '[redigido]';
        return array_map(static fn($name)=>is_string($name)&&strlen($name)<=1024&&preg_match('/^(?:[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*)?$/D',$name)&&!DataSafety::secret_value($name)?$name:'[redigido]',$value);
    }
    private static function interface_path(array $path, array $context): bool {
        $path=self::domain_path($path);
        return ($context['ability']??'')==='f3base/conteudo-instrumentacao-ler' && count($path)===7 && in_array($path[0],['por_url','linhas'],true) && ($path[0]==='por_url'||preg_match('/^(?:0|[1-9][0-9]*)$/D',$path[1])) && $path[2]==='formularios' && preg_match('/^(?:0|[1-9][0-9]*)$/D',$path[3]) && array_slice($path,4)===['complemento','mensagens','token_indisponivel'];
    }
    private static function interface_text($value): string {
        if(!is_string($value)||strlen($value)>4000||!preg_match('/\A.{0,1000}\z/us',$value))return '[redigido]';
        if(preg_match('~-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----|\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|\b(?:password|senha|access_token|refresh_token|client_secret|api_key)\s*[:=]\s*\S+~i',$value))return '[redigido]';
        return DataSafety::diagnostic_text($value);
    }
    private static function policy_rules($value) {
        if(!(is_array($value)||$value instanceof \stdClass) || count((array)$value)>100)return '[redigido]';
        $out=[];
        foreach((array)$value as $name=>$rule) {
            $row=is_array($rule)||$rule instanceof \stdClass?(array)$rule:[];
            $keys=array_keys($row);sort($keys);
            $valid=(is_string($name)||is_int($name)) && preg_match('/^[a-z0-9_]{1,80}$/D',(string)$name) && $keys===['aviso','suspeito'] && is_bool($row['aviso']) && is_bool($row['suspeito']);
            // Rebuild the two-field public object; do not serialize unknown objects or extra data.
            $out[$name]=$valid?($rule instanceof \stdClass?(object)$row:$row):'[redigido]';
        }
        return $value instanceof \stdClass?(object)$out:$out;
    }
    /** Additive transport metadata; never inserted into provider business objects. */
    public static function presentation($value, array $context=[]): array {
        $public=self::value($value,[],$context);$paths=[];$total=0;$bytes=0;
        $walk=static function($node,$before,string $path,string $field='')use(&$walk,&$paths,&$total,&$bytes):void {
            if(is_string($node) && ($node==='[redigido]' || $node!==$before || (in_array($field,['message','error','error_description','last_error_message'],true)&&str_contains($node,'[redigido]')))) {
                ++$total;
                if(count($paths)<256 && $bytes+strlen($path)<=16384){$paths[]=$path;$bytes+=strlen($path);}
            } elseif(is_array($node)||$node instanceof \stdClass) {
                $prior=is_array($before)||$before instanceof \stdClass?(array)$before:[];
                foreach((array)$node as $key=>$child) {
                    $segment=DataSafety::secret_value((string)$key)?'[redigido]':(string)$key;
                    $walk($child,$prior[$key]??null,$path.'/'.str_replace(['~','/'],['~0','~1'],$segment),(string)$key);
                }
            }
        };
        $walk($public,$value,'');
        return ['value'=>$public,'metadata'=>['contract'=>'fator3-redaction/1','path_format'=>'json-pointer','paths'=>$paths,'total'=>$total,'truncated'=>$total>count($paths),'scope'=>'structuredContent','includes_existing_markers'=>true]];
    }
    /** Schema property names are contract metadata, not credential values. */
    private static function schema($schema, bool $sensitive=false, array $path=[], array $context=[]) {
        $out=[];
        foreach((array)$schema as $key=>$value) {
            if(in_array($key,['properties','$defs','definitions','patternProperties'],true) && (is_array($value)||$value instanceof \stdClass)) {
                $map=[];foreach((array)$value as $name=>$child)$map[$name]=(is_array($child)||$child instanceof \stdClass)?self::schema($child,$sensitive||DataSafety::secret_key((string)$name),[...$path,(string)$key,(string)$name],$context):'[redigido]';
                $out[$key]=$value instanceof \stdClass?(object)$map:$map;
            } elseif(in_array($key,['items','additionalProperties','not','if','then','else','contains'],true) && (is_array($value)||$value instanceof \stdClass)) $out[$key]=self::schema($value,$sensitive,[...$path,(string)$key],$context);
            elseif(in_array($key,['allOf','anyOf','oneOf','prefixItems'],true)&&is_array($value)) {
                $out[$key]=[];foreach($value as $i=>$v)$out[$key][$i]=is_array($v)||$v instanceof \stdClass?self::schema($v,$sensitive,[...$path,(string)$key,(string)$i],$context):$v;
            }
            elseif($sensitive&&in_array($key,['default','examples'],true))$out[$key]='[redigido]';
            else $out+=self::error([$key=>$value],$path,$context);
        }
        return $schema instanceof \stdClass?(object)$out:$out;
    }
}
final class Phase {
    private static ?string $active=null;
    public static function current(): ?string {return self::$active;}
    /** Bind recovery data to the running receipt before touching the destination. */
    public static function attach_backup(string $id): void {
        $index=StateStore::get('phase014-index',substr((string)self::$active,6));
        $token=$index['token']??'';
        $state=StateStore::get('phase014',$token);
        if (($state['status']??null)!=='running')throw new \RuntimeException('phase_not_running');
        $state['backup_id']=$id;
        StateStore::put('phase014',$token,$state);
    }
    public static function status(array $i): array {
        $id=substr($i['operation_id'],6);if(!preg_match('/^[a-f0-9]{32}$/D',$id))return Result::fail('operation_not_found','Operação não encontrada.');
        $index=StateStore::get('phase014-index',$id);$s=$index?StateStore::get('phase014',$index['token']):null;if(!$s||$s['connection_id']!==ConnectionContext::key())return Result::fail('operation_not_found','Operação não encontrada.');
        $out=['operation_id'=>$i['operation_id'],'ability'=>$s['name'],'status'=>$s['status'],'expires_at'=>gmdate('c',$s['expires'])];
        if(isset($s['result']))$out['result']=$s['result'];
        $backup=$s['backup_id']??$s['result']['backup_id']??null;if(is_string($backup)&&preg_match('/^[a-f0-9]{32}$/D',$backup))$out['backup']=SqlArtifacts::availability($backup);
        if($s['status']==='running'){foreach(glob(StateStore::directory('database-recovery').'/*.php')?:[] as $path){$j=\Fator3\RecoveryV1\Engine::read($path);if(($j['operation_id']??null)===$i['operation_id']){$out['recovery_id']=$j['id'];$out['recovery_status']=$j['status'];break;}}$out['applied']=null;$out['retryable']=false;}
        return Result::ok($out);
    }
    /** Caller holds the target lock. Every effect has a durable, credential-bound claim. */
    public static function run(string $name,array $input,callable $snapshot,callable $apply,bool $always=true): array {
        $args=$input;unset($args['confirm_token'],$args['idempotency_key']);
        $intent=hash('sha256',serialize($args));$connection=ConnectionContext::key();
        $token=$input['confirm_token']??'';
        if($token===''){
            $before=$snapshot();if(is_wp_error($before))return Result::error($before);
            $hash=hash_hmac('sha256',serialize($before),wp_salt('auth'));
            if(!$always)return Result::normalize($apply($before));
            $token=bin2hex(random_bytes(32));$id=bin2hex(random_bytes(16));StateStore::put('phase014-index',$id,['token'=>$token]);StateStore::put('phase014',$token,['operation_id'=>'phase:'.$id,'name'=>$name,'intent'=>$intent,'connection_id'=>$connection,'fingerprint'=>$hash,'expires'=>time()+600,'status'=>'pending']);
            return Result::ok(['operation_id'=>'phase:'.$id,'preview'=>true,'applied'=>false,'changed'=>false,'confirm_token'=>$token,'expires_at'=>gmdate('c',time()+600),'summary'=>SafeOutput::error($before)]+array_intersect_key(SafeOutput::error($before),array_flip(['preview_rows','redacted','affected_rows','statement_previews','selection_exact'])));
        }
        if(!preg_match('/^[a-f0-9]{64}$/D',$token))return Result::fail('confirmation_invalid','Confirmação inválida.');
        return Locks::run(['phase014:'.$token=>LOCK_EX],static function()use($token,$name,$intent,$connection,$snapshot,$apply){
            $s=StateStore::get('phase014',$token);
            if(!$s||$s['name']!==$name||$s['intent']!==$intent||$s['connection_id']!==$connection)return Result::fail('confirmation_invalid','Confirmação não pertence à seleção/conexão.');
            if($s['status']==='complete')return $s['result']+['replayed'=>true];
            if($s['status']!=='pending')return Result::fail('operation_uncertain','Efeito iniciado sem conclusão; consulte a operação antes de repetir.',['operation_id'=>$s['operation_id']??null,'applied'=>null,'retryable'=>false]);
            if($s['expires']<time())return Result::fail('confirmation_expired','Prévia expirada.');
            $before=$snapshot();if(is_wp_error($before))return Result::error($before);
            if(!hash_equals($s['fingerprint'],hash_hmac('sha256',serialize($before),wp_salt('auth'))))return Result::fail(str_starts_with($name,'db/')?'database_conflict':'preimage_conflict','Alvo mudou desde a prévia.',['conflict'=>true]);
            $s['status']='running';StateStore::put('phase014',$token,$s);
            $prior=self::$active;self::$active=$s['operation_id']??null;try{$result=Result::normalize($apply($before))+['operation_id'=>self::$active];}finally{self::$active=$prior;}$s['status']='complete';$s['result']=$result;StateStore::put('phase014',$token,$s);return $result;
        });
    }
}
final class Release014 {
    public static function init(): void {
        // Removed operational documents must not be redirected by WordPress's canonical guessing.
        add_action('template_redirect',static function(){
            $base=(string)wp_parse_url(plugins_url('wp-mcp-fator3/'),PHP_URL_PATH);
            $path=rawurldecode((string)wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH));
            foreach(['README.md','CHANGELOG.md','docs/OPERACAO.md','docs/ATUALIZACAO.md','docs/COBERTURA-SEO.md','docs/CONTRATO-EXTENSOES.md','docs/CONTRATOS-INSTALADOS.json'] as $name)if($path===$base.$name){status_header(404);nocache_headers();header('Content-Type: text/plain; charset=utf-8');echo 'Not found';exit;}
        },0);
    }

    public static function register(): void {
        ConnectionTools::register();CronTools::register();SiteAdmin::register();DatabaseAdmin::register();QueryExports::register();ArchiveTools::register();ThemePackages::register();
    }
    public static function schema(array $args,string $name): array {
        $p=&$args['input_schema']['properties'];
        if(DestructiveActions::supports($name))$p['confirm']=Registry::boolean();
        if(in_array($name,['files/write','files/patch','files/delete','files/move','files/fetch','files/restore','files/upload-finalize'],true))$p['probe']=Registry::boolean(true);
        if($name==='db/query'){
            $p['timeout_seconds']=Registry::integer(1,3600);
            $args['output_schema']['properties']['redacted']=['type'=>'array','items'=>['type'=>'object']];
            $args['execute_callback']=[DatabaseRead::class,'query'];
            $args['description']='Consulta de leitura MySQL. Manutenção aceita tabelas/views do banco do site, JOIN, UNION, subconsultas, CTE, janelas e funções analíticas. Resposta até 2000 linhas; db/query-export gera arquivo privado completo. Segredos são redigidos na apresentação; administração SQL não é isolamento contra inferência.';
        }
        if($name==='db/execute'){
            $p['backup_scope']=['type'=>'string','enum'=>['database','selected_tables','selected_rows']];
            $native=$args['execute_callback'];
            $args['execute_callback']=static function($in)use($native){
                if(ConnectionContext::maintenance())return DatabaseAdmin::execute($in);
                if(($in['backup_scope']??'')==='selected_rows')return Result::fail('permission_denied','Pré-imagem de linhas exige perfil Manutenção.');
                return $native($in);
            };
            $args['description']='Escrita MySQL em duas fases com selection-guard/2: guarda linhas, schema e dependências selecionadas. confirm_token válido por 10 minutos; database_conflict exige nova prévia. Formas sem plano verificável retornam sql_guard_unavailable. Backup privado contém valores originais e segredos; backup_scope:database é padrão, selected_tables é opt-in somente para DML elegível de uma tabela e restaura a tabela inteira. selected_rows salva só a seleção de um UPDATE de uma tabela, sem mudar colunas únicas. Restaurar com db/restore, artifact_id igual ao backup_id. DDL tem recuperação por snapshot, sem transação global; db/batch aceita DML InnoDB.';
        }
        if(in_array($name,['db/execute','db/batch','db/search-replace'],true)){
            $args['output_schema']['properties']=($args['output_schema']['properties']??[])+[
                'guard_contract'=>['type'=>'string','enum'=>[SqlMutationPlan::CONTRACT]],'guard_scope'=>Registry::string(),
                'target_tables'=>['type'=>'array','items'=>Registry::string()],'selected_rows'=>Registry::integer(),
                'selection_exact'=>Registry::boolean(),'backup_scope'=>['type'=>'string','enum'=>['database','selected_tables','selected_rows']],'backup_tables'=>['type'=>'array','items'=>Registry::string()],
                'conflict_reason'=>['type'=>'string','enum'=>['target_rows_changed','selection_changed','dependency_changed','schema_changed','unique_key_changed']],
            ];
        }
        if($name==='themes/activate'){$p['confirm_token']=Registry::string();$args['execute_callback']=[ThemePackages::class,'activate'];}
        if($name==='operations/status'){
            $args['description']='Consulta plano por plan_id ou exportação/cron/confirmação por operation_id. Mostra estado observado; efeito incerto não autoriza repetição.';
            $p['operation_id']=Registry::string();$args['input_schema']['required']=[];$native=$args['execute_callback'];
            $args['execute_callback']=static fn($in)=>isset($in['operation_id'])?(str_starts_with($in['operation_id'],'cron:')?CronTools::status($in):(str_starts_with($in['operation_id'],'phase:')?Phase::status($in):QueryExports::status($in))):$native($in);
        }
        if($name==='options/update'){$args['execute_callback']=[SiteAdmin::class,'option'];$args['description']='Grava option com backup e readback. Manutenção administra options exceto f3_mcp_* e estado interno equivalente. Endereço, idioma, papéis e cron usam os serviços nativos; mudanças de endereço exigem confirmação.';$p['confirm_token']=Registry::string();}
    	return $args;
    }
}
