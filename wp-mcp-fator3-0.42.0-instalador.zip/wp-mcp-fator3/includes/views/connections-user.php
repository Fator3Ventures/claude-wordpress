<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$url=Admin::url('connections');
?>
<div class="f3-page-intro"><a class="f3-back" href="<?php echo esc_url($url); ?>">← Clientes conectados</a><h2>Escolher conta WordPress</h2><p>O cliente só poderá executar ações permitidas a esta conta.</p></div>
<section class="f3-card">
<form method="get" action="<?php echo esc_url(admin_url('tools.php')); ?>" class="f3-search">
<input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="connections"><input type="hidden" name="mode" value="<?php echo esc_attr($mode); ?>"><input type="hidden" name="choose_user" value="1">
<label for="f3-user-search">Nome ou login</label><div class="f3-actions"><input id="f3-user-search" type="search" name="user_search" value="<?php echo esc_attr($user_search); ?>"><button class="button">Pesquisar contas</button></div>
</form>
<?php if(!$users): ?><p>Nenhuma conta disponível nesta busca.</p><?php else: ?>
<ul class="f3-link-list"><?php foreach($users as $u): ?><li><a href="<?php echo esc_url(add_query_arg(['mode'=>$mode,'user_id'=>$u->ID],$url)); ?>"><?php echo esc_html($u->display_name.' · '.$u->user_login.' (#'.$u->ID.')'); ?></a></li><?php endforeach; ?></ul>
<p class="description">Até 100 resultados por busca. Refine o nome ou login para localizar outra conta.</p><?php endif; ?>
</section>
