<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$enabled=PathGuard::is_enabled();
$hard=Admin::hard_block();
$file_limit=get_option('f3_mcp_file_bytes',16777216);
$policy=SqlArtifacts::policy();
?>
<div class="f3-page-intro"><h2>Arquivos e banco</h2><p>Defina o acesso geral do site. Cada conexão também precisa de um perfil e das permissões do usuário WordPress.</p></div>
<div class="f3-grid f3-permissions">
<section class="f3-card"><div class="f3-card-heading"><h3>Acesso ao canal</h3><?php Admin::badge($enabled,'Aberto','Fechado'); ?></div>
<?php if($hard): ?><p class="f3-callout">O wp-config.php bloqueia o canal por DISALLOW_FILE_EDIT ou DISALLOW_FILE_MODS.</p>
<?php elseif(Admin::forced_by_filter()): ?><p class="f3-callout">O filtro f3_mcp_files_enabled também controla o estado efetivo.</p><?php endif; ?>
<?php Admin::form('channel',(bool)get_option(PathGuard::OPTION_ENABLED,true),$hard); ?></section>
<section class="f3-card"><div class="f3-card-heading"><h3>Escrita no banco</h3><?php Admin::badge($enabled && Database::writes_enabled(),'Liberada','Bloqueada'); ?></div>
<?php if(!$enabled): ?><p class="f3-callout">O canal está fechado. A preferência fica salva para a próxima abertura.</p><?php endif; ?>
<?php if(has_filter('f3_mcp_db_writes_enabled')): ?><p class="f3-callout">O filtro f3_mcp_db_writes_enabled também controla a permissão de escrita.</p><?php endif; ?>
<?php Admin::form('database',(bool)get_option(Database::OPTION_WRITES,true)); ?></section></div>

<section class="f3-card"><h3>Transferência de arquivos</h3>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="f3-settings-form"><?php Admin::nonce('f3_mcp_file_limit'); ?>
<input type="hidden" name="action" value="f3_mcp_file_limit"><input type="hidden" name="revision" value="<?php echo esc_attr(hash('sha256',serialize($file_limit))); ?>">
<label for="f3-global-limit">Limite por arquivo (bytes)</label><input id="f3-global-limit" type="number" required min="1048576" max="1073741824" step="1" name="file_bytes" value="<?php echo esc_attr((string)$file_limit); ?>" aria-describedby="f3-global-help">
<?php Admin::help('f3-global-help','Padrão de Manutenção: '.size_format((int)$file_limit,1).'. Informe de 1.048.576 a 1.073.741.824 bytes. O perfil pode ter limite próprio.'); ?>
<button class="button button-primary">Salvar limite por arquivo</button></form>
<details><summary>Conferir alcance e restrições do servidor</summary><dl class="f3-facts">
<dt>Diretórios alcançáveis</dt><dd><?php echo esc_html(PathGuard::is_confined()?(implode(', ',PathGuard::roots())?:'Nenhuma raiz válida'):'Diretórios acessíveis ao processo PHP'); ?></dd>
<dt>Limite neste contexto</dt><dd><?php echo esc_html(size_format(PathGuard::max_bytes())); ?></dd>
<dt>Permissão da sua conta</dt><dd><?php echo PathGuard::can_edit()?'Autorizada':'Indisponível'; ?> · edit_themes + manage_options</dd>
<dt>open_basedir</dt><dd><?php echo esc_html(ini_get('open_basedir')?:'Não definido'); ?></dd>
<dt>Extensões permitidas</dt><dd><?php echo esc_html(implode(', ',PathGuard::allowed_extensions())?:'Todas, salvo bloqueios'); ?></dd>
<dt>Extensões bloqueadas</dt><dd><?php echo esc_html(implode(', ',PathGuard::denied_extensions())?:'Nenhuma regra adicional'); ?></dd>
<dt>Nomes protegidos</dt><dd><?php echo esc_html(implode(', ',PathGuard::denied_basenames())?:'Sem regra adicional'); ?></dd></dl></details></section>

<section class="f3-card"><h3>Retenção dos backups SQL</h3><p>A prévia da limpeza seleciona cópias automáticas por idade ou quantidade. As cópias recentes protegidas e as referências ativas são preservadas.</p>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="f3-settings-form">
<?php Admin::nonce('f3_mcp_sql_retention'); ?>
<input type="hidden" name="action" value="f3_mcp_sql_retention"><input type="hidden" name="revision" value="<?php echo esc_attr(hash('sha256',serialize($policy))); ?>">
<div class="f3-field-grid"><?php foreach([
    'older_than_days'=>['Idade mínima (dias)',1,3650,'Idade a partir da qual uma cópia pode entrar na seleção.'],
    'max_count'=>['Máximo desejado',1,10000,'O excedente pode ser selecionado, inclusive antes da idade mínima.'],
    'min_keep'=>['Mínimo protegido',0,10000,'Quantidade de cópias recentes a preservar. Deve ser menor ou igual ao máximo.'],
] as $key=>$field): ?><div><label for="f3-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label>
<input id="f3-<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" type="number" required aria-describedby="f3-retention-<?php echo esc_attr($key); ?>" min="<?php echo (int)$field[1]; ?>" max="<?php echo (int)$field[2]; ?>" value="<?php echo (int)$policy[$key]; ?>">
<?php Admin::help('f3-retention-'.$key,$field[3]); ?></div><?php endforeach; ?></div>
<button class="button button-primary">Salvar política de retenção</button><p class="description">Salvar define os critérios. A exclusão exige uma prévia e uma confirmação separadas.</p></form>
<p class="f3-related"><a href="<?php echo esc_url(add_query_arg('document','sql-retention',Admin::url('help'))); ?>">Como limpar backups SQL</a> · <a href="<?php echo esc_url(add_query_arg('document','release-0390',Admin::url('help'))); ?>">Como restaurar linhas de um UPDATE</a></p></section>

<section class="f3-card"><h3>Pré-imagens de plugins</h3>
<p>Uma atualização pode guardar uma cópia da versão anterior. Para revisar essas cópias, use <code>backups/prune</code> com a política <code>package_preimages</code> e informe o plugin e o prazo em dias.</p>
<p>Comece pela simulação. Se o inventário estiver incompleto, continue com o cursor recebido. Confira os itens e o total em bytes antes de confirmar a limpeza.</p>
<p class="f3-related"><a href="<?php echo esc_url(add_query_arg('document','release-0420',Admin::url('help'))); ?>">Ver exemplo de simulação e como continuar a busca</a></p></section>
