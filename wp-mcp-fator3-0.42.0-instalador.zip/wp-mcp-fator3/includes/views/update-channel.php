<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$allowed=current_user_can('update_plugins');
?>
<div class="f3-page-intro"><h2>Atualizações</h2><p>A frota Fator3 instala o ZIP versionado e confere o SHA-256. Para esse fluxo, deixe a fonte de manifesto vazia.</p></div>
<section class="f3-card"><div class="f3-card-heading"><h3>Fonte de manifesto do MCP</h3>
<?php Admin::badge(is_array($entry)&&$url!=='','Configurada',is_string($entry)&&$url!==''?'A confirmar':'Desativada'); ?></div>
<?php if(is_string($entry)&&$url!==''): ?><p class="f3-callout">O MCP armazenou um endereço simples. Para usá-lo como fonte de manifesto, confira os domínios e salve esta configuração.</p><?php endif; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="f3-settings-form">
<?php Admin::nonce('f3_mcp_update_channels'); ?>
<input type="hidden" name="action" value="f3_mcp_update_channels"><input type="hidden" name="revision" value="<?php echo esc_attr(hash('sha256',serialize($channels))); ?>">
<fieldset <?php disabled(!$allowed); ?>>
<label for="f3-update-url">URL do manifesto (HTTPS)</label><input id="f3-update-url" class="large-text" type="url" maxlength="2048" name="channels[wp-mcp-fator3][url]" value="<?php echo esc_attr($url); ?>" aria-describedby="f3-update-help">
<?php Admin::help('f3-update-help','Endereço do JSON publicado pelo responsável pelo pacote. Limpar o campo e salvar desativa a fonte deste plugin.'); ?>
<label for="f3-update-hosts">Outros domínios de download</label><input id="f3-update-hosts" class="large-text" name="channels[wp-mcp-fator3][package_hosts]" value="<?php echo esc_attr(implode(' ',$hosts)); ?>" aria-describedby="f3-hosts-help">
<?php Admin::help('f3-hosts-help','Preencha somente se o ZIP vier de outro domínio. Separe os domínios por espaço.'); ?>
<button class="button button-primary">Salvar fonte do MCP</button></fieldset>
<?php if(!$allowed): ?><p class="description">Sua conta precisa da permissão update_plugins para alterar esta fonte.</p><?php endif; ?>
</form><p><a href="<?php echo esc_url(add_query_arg('document','atualizacao',Admin::url('help'))); ?>">Como instalar e verificar a versão</a></p></section>
