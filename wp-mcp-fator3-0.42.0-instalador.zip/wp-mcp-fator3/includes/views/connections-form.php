<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$url=Admin::url('connections');
$titles=['edit'=>'Editar perfil do cliente','associate'=>'Associar identidade existente','create'=>'Emitir senha de aplicação'];
$profiles=['read'=>'Leitura','content'=>'Conteúdo','maintenance'=>'Manutenção','custom'=>'Personalizado'];
$instructions=[
    'read'=>'Permite as consultas liberadas para o perfil de leitura.',
    'content'=>'Acrescenta ações de edição de conteúdo, respeitando as capacidades do usuário.',
    'maintenance'=>'Permite administrar o site conforme as capacidades da conta e as restrições do servidor.',
    'custom'=>'Permite apenas as habilidades selecionadas, dentro das permissões do usuário.',
];
$profile=$values['profile']??'read';
$revoked=($values['_storage']['status']??'')==='revoked';
?>
<div class="f3-page-intro"><a class="f3-back" href="<?php echo esc_url($url); ?>">← Clientes conectados</a>
<h2><?php echo esc_html($revoked?'Identidade revogada':$titles[$mode]); ?></h2></div>
<?php if(!$user): ?><div class="f3-card"><p>Esta conta já não está disponível para administração.</p></div><?php return; endif; ?>
<?php if($revoked): ?><section class="f3-card"><h3><?php echo esc_html(($values['label']??'')?:$values['connection_id']); ?></h3><p>O acesso desta identidade foi encerrado. Para conectar o cliente novamente, use outra credencial.</p>
<a class="button" href="<?php echo esc_url(add_query_arg(['mode'=>'create','user_id'=>$user->ID],$url)); ?>">Emitir outra senha</a></section><?php return; endif; ?>

<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="f3-editor">
<?php Admin::nonce('f3_mcp_connection'); ?>
<input type="hidden" name="action" value="f3_mcp_connection">
<?php if ($mode==='create'): ?><input type="hidden" name="issue_ticket" value="<?php echo esc_attr(wp_generate_uuid4()); ?>"><?php endif; ?>
<input type="hidden" name="intent" value="<?php echo esc_attr($editing?'save':$mode); ?>">
<input type="hidden" name="expected_policy_version" value="<?php echo (int)($values['policy_version']??0); ?>">
<input type="hidden" name="user_id" value="<?php echo (int)$user->ID; ?>">
<section class="f3-card"><h3>Conta e identidade</h3>
<p><strong><?php echo esc_html($user->display_name); ?></strong> · <?php echo esc_html($user->user_login.' (#'.$user->ID.')'); ?>
<?php if(!$editing): ?> · <a href="<?php echo esc_url(add_query_arg(['mode'=>$mode,'choose_user'=>'1'],$url)); ?>">Escolher outra conta</a><?php endif; ?></p>
<?php if($editing): ?><p>Identidade <code><?php echo esc_html($values['connection_id']); ?></code></p><input type="hidden" name="connection_id" value="<?php echo esc_attr($values['connection_id']); ?>">
<?php elseif($mode==='associate'): ?>
<label for="f3-connection-identity">Identidade autenticada</label><select id="f3-connection-identity" name="connection_id" aria-describedby="f3-identity-help">
<option value="integration:user:<?php echo (int)$user->ID; ?>">Integração da conta WordPress</option>
<?php foreach(\WP_Application_Passwords::get_user_application_passwords($user->ID) as $app): ?><option value="app:<?php echo esc_attr($app['uuid']); ?>"><?php echo esc_html('Senha de aplicação · '.$app['name']); ?></option><?php endforeach; ?></select>
<?php Admin::help('f3-identity-help','A integração da conta compartilha um perfil entre chamadas autenticadas como esse usuário. Para editar uma identidade já associada, abra o cliente na lista.'); ?>
<?php else: ?><p>O WordPress criará uma senha para esta conta e a exibirá uma vez após a confirmação.</p><?php endif; ?>
<label for="f3-connection-label">Nome do cliente</label><input type="text" id="f3-connection-label" name="label" maxlength="128" value="<?php echo esc_attr($values['label']??''); ?>" <?php if($mode==='create')echo 'required'; ?> aria-describedby="f3-label-help">
<?php Admin::help('f3-label-help','Use um nome que ajude a identificar a finalidade, por exemplo “Revisão editorial”.'); ?>
</section>

<section class="f3-card"><h3>Perfil e validade</h3>
<div class="f3-field-grid"><div><label for="f3-connection-profile">Perfil de acesso</label>
<select id="f3-connection-profile" name="profile" aria-describedby="f3-profile-help">
<?php if(!isset($profiles[$profile])): ?><option value="" selected disabled>Selecione um perfil</option><?php endif; ?>
<?php foreach($profiles as $key=>$name): ?><option value="<?php echo esc_attr($key); ?>" data-description="<?php echo esc_attr($instructions[$key]); ?>" <?php selected($profile,$key); ?>><?php echo esc_html($name); ?></option><?php endforeach; ?>
</select><p id="f3-profile-help" class="description" aria-live="polite"><?php echo esc_html($instructions[$profile]??'Escolha o acesso a conceder.'); ?></p></div>
<div><label for="f3-connection-expires">Expira em (UTC)</label>
<input id="f3-connection-expires" type="datetime-local" step="1" name="expires" value="<?php echo esc_attr(empty($values['expires'])?'':gmdate('Y-m-d\TH:i:s',$values['expires'])); ?>" aria-describedby="f3-expires-help">
<?php Admin::help('f3-expires-help','Deixe em branco para não impor prazo adicional ao perfil.'); ?></div></div>

<details data-custom-abilities <?php if($profile==='custom')echo 'open'; ?>><summary>Habilidades do perfil Personalizado</summary>
<?php
$choices=[];
foreach(wp_get_abilities() as $ability)$choices[$ability->get_name()]=$ability->get_label();
foreach($values['abilities']??[] as $id)if(!isset($choices[$id]))$choices[$id]='Indisponível no momento — seleção preservada';
asort($choices,SORT_NATURAL|SORT_FLAG_CASE);
Admin::choices('abilities',$choices,$values['abilities']??[],'Habilidades','A seleção vale para o perfil Personalizado. Filtrar a lista preserva as marcações.');
?></details></section>

<section class="f3-card"><h3>Restrições e permissões</h3>
<details><summary>Conteúdo e metadados</summary>
<?php
$types=[];
foreach(get_post_types([], 'objects') as $type)$types[$type->name]=$type->labels->singular_name;
foreach($values['post_types']??[] as $id)if(!isset($types[$id]))$types[$id]='Indisponível no momento — seleção preservada';
Admin::choices('post_types',$types,$values['post_types']??[],'Tipos de conteúdo','Nos perfis restritos, deixe a lista vazia para aceitar todos os tipos que a conta pode acessar.');
?>
<label for="f3-connection-meta_keys">Chaves extras de metadados</label><textarea id="f3-connection-meta_keys" name="meta_keys" rows="3" aria-describedby="f3-meta-help"><?php echo esc_textarea(implode("\n",$values['meta_keys']??[])); ?></textarea>
<?php Admin::help('f3-meta-help','Uma chave exata por linha. Autoriza metadados adicionais nos perfis restritos.'); ?></details>
<details><summary>Arquivos e banco de dados</summary>
<label for="f3-connection-roots">Diretórios permitidos</label><textarea id="f3-connection-roots" name="roots" rows="3" aria-describedby="f3-roots-help"><?php echo esc_textarea(implode("\n",$values['roots']??[])); ?></textarea>
<?php Admin::help('f3-roots-help','Informe um diretório existente por linha. Nos perfis restritos, deixar vazio bloqueia acesso a arquivos. Manutenção usa as raízes do servidor.'); ?>
<label for="f3-connection-limit">Limite por arquivo (bytes)</label><input id="f3-connection-limit" type="number" name="file_bytes" min="1048576" max="1073741824" step="1" value="<?php echo esc_attr((string)($values['file_bytes']??'')); ?>" aria-describedby="f3-limit-help">
<?php Admin::help('f3-limit-help','Para Manutenção. Vazio herda o limite do canal. Aceita de 1 MiB a 1 GiB.'); ?>
<?php foreach(['database_write'=>['Permitir escrita SQL','Autoriza db/execute quando a habilidade e o canal estão liberados. O perfil Manutenção segue o controle geral de escrita.'],'allow_backup_export'=>['Exportar backups próprios','Permite exportar cópias com valores originais desta conexão.'],'allow_foreign_backup_export'=>['Incluir backups de outras conexões','Exige também a permissão para exportar backups próprios.']] as $key=>$field): ?>
<label class="f3-control"><input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(!empty($values[$key])); ?> aria-describedby="f3-help-<?php echo esc_attr($key); ?>"> <?php echo esc_html($field[0]); ?></label>
<?php Admin::help('f3-help-'.$key,$field[1]); endforeach; ?></details>
<details><summary>Ferramentas do cliente</summary><label class="f3-control"><input type="checkbox" name="readonly_executor" value="1" <?php checked(!empty($values['readonly_executor'])); ?> aria-describedby="f3-help-readonly"> Expor executor de leitura</label>
<?php Admin::help('f3-help-readonly','Oferece ao cliente uma ferramenta separada para habilidades somente de leitura.'); ?></details>
</section>
<input type="hidden" name="form_complete" value="1">
<div class="f3-actions f3-form-actions"><button class="button button-primary"><?php echo $mode==='create'?'Emitir senha':($editing?'Salvar perfil':'Associar identidade'); ?></button><a class="button" href="<?php echo esc_url($url); ?>">Cancelar</a></div>
</form>

<?php if($editing): ?>
<section class="f3-card f3-revoke"><details><summary>Revogar acesso deste cliente</summary>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php Admin::nonce('f3_mcp_connection'); ?>
<?php foreach(['action'=>'f3_mcp_connection','intent'=>'revoke','user_id'=>$user->ID,'connection_id'=>$values['connection_id'],'expected_policy_version'=>$values['policy_version']??0] as $key=>$v): ?><input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr((string)$v); ?>"><?php endforeach; ?>
<p>O MCP bloqueará novas chamadas desta identidade e encerrará suas sessões. Para uma senha de aplicação, o WordPress também excluirá a credencial. Para OAuth, a revogação alcança a concessão.</p>
<label class="f3-control"><input type="checkbox" required name="confirm_revocation" value="1"> Confirmo a revogação de <strong><?php echo esc_html(($values['label']??'')?:$values['connection_id']); ?></strong>.</label>
<p><button class="button f3-danger">Revogar acesso</button></p></form></details></section>
<?php endif; ?>
