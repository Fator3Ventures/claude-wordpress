<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
?>
<!doctype html><html <?php language_attributes(); ?>><head>
<meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Credencial criada · Fator3 MCP</title>
<link rel="stylesheet" href="<?php echo esc_url(add_query_arg('ver',F3_MCP_FILES_VERSION,plugins_url('core/assets/css/admin.css',F3_MCP_FILES_DIR.'wp-mcp-fator3.php'))); ?>">
<style><?php echo wp_get_view_transitions_admin_css(); /* WordPress' own local stylesheet. */ ?></style>
</head><body class="f3-credential-page"><main class="f3-mcp-admin f3-receipt"><h1>Credencial criada</h1>
<section class="f3-card"><h2><?php echo esc_html($input['label']); ?></h2><dl class="f3-facts">
<dt>Conta WordPress</dt><dd><?php echo esc_html($result['user_login']); ?></dd>
<dt>Perfil</dt><dd><?php echo esc_html(Admin::profile($result['profile'])); ?></dd>
<dt>Identidade</dt><dd><code><?php echo esc_html($result['connection_id']); ?></code></dd></dl>
<p>Copie a senha agora. Ela não será exibida novamente depois que você sair desta página.</p>
<details id="f3-receipt-secret"><summary>Mostrar senha de aplicação</summary><p><code id="f3-issued-password"><?php echo esc_html($result['application_password']); ?></code></p></details>
<?php if(!empty($result['receipt_pending'])): ?><p role="status">O perfil foi salvo. A atualização do comprovante de emissão ficou pendente.</p><?php endif; ?>
<p><a href="<?php echo esc_url(Admin::url('connections')); ?>">Voltar às conexões</a></p></section></main>
<script>
window.addEventListener('pagehide', () => {
    document.getElementById('f3-issued-password').textContent = '';
    document.getElementById('f3-receipt-secret').open = false;
});
</script></body></html>
