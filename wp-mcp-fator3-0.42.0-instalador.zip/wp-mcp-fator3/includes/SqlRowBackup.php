<?php
/** Private row images for an exact, single-table UPDATE with stable identities. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class SqlRowBackup {
    private static function digest(array $row): string {
        return hash('sha256',serialize($row));
    }

    private static function pairs(array $plan): array {
        $pairs=[];
        $images=$plan['images'];
        foreach ($images['before'] as $before) {
            $key=SqlMutationPlan::key($before,$images['identity']);
            $after=$images['after'][$key] ?? throw new SqlGuardUnavailable('unstable_row_identity');
            $pairs[]=['restore'=>$before,'expected'=>self::digest($after)];
        }
        if (count($pairs)!==count($images['after']))throw new SqlGuardUnavailable('unstable_row_identity');
        return $pairs;
    }

    public static function capture(array $plan,string $operation): array {
        $table=$plan['asts'][0]['target_table'];
        return self::write($table,$plan['guard']['schema'][$table],self::pairs($plan),'db/execute',$operation);
    }

    private static function write(string $table,string $schema_hash,array $pairs,string $ability,string $operation): array {
        $writer=PrivateArtifact::writer('sql_rows',true);
        try {
            foreach ($pairs as $pair) {
                $values=array_map(static fn($value)=>$value===null?null:base64_encode($value),$pair['restore']);
                $line=json_encode([$values,$pair['expected']],JSON_THROW_ON_ERROR);
                PrivateArtifact::append($writer,$line."\n");
                $writer['rows']++;
            }
            return PrivateArtifact::finish($writer,[
                'metadata_contract'=>1,'scope'=>'selected_rows','row_contract'=>'row-preimage/1',
                'purpose'=>$ability==='db/restore'?'restore_preimage':'sql_mutation','ability'=>$ability,
                'operation_id'=>$operation,'references'=>[$operation],'database'=>DB_NAME,'site_id'=>get_current_blog_id(),
                'tables'=>[$table=>['rows'=>count($pairs),'schema_sha256'=>$schema_hash]],
                'backup_contains_sensitive_values'=>true,
            ]);
        } catch (\Throwable $e) {
            if (is_resource($writer['stream']))fclose($writer['stream']);
            @unlink(PrivateArtifact::path($writer['id']));
            throw $e;
        }
    }

    private static function read_pairs(array $meta): array {
        $pairs=[];
        foreach (PrivateArtifact::lines($meta['id']) as $line) {
            [$values,$expected]=json_decode($line,true,512,JSON_THROW_ON_ERROR);
            $row=[];
            foreach ($values as $col=>$value) {
                $row[$col]=$value===null?null:base64_decode($value,true);
                if ($row[$col]===false)throw new \RuntimeException('invalid_row_encoding');
            }
            $pairs[]=['restore'=>$row,'expected'=>$expected];
        }
        if (count($pairs)!==$meta['rows'])throw new \RuntimeException('invalid_row_count');
        return $pairs;
    }

    private static function current(\mysqli $db,string $table,string $where): ?array {
        $r=DatabaseRead::checked($db,'SELECT * FROM '.SqlMutationPlan::q($table).' WHERE '.$where.' FOR UPDATE');
        try {return $r->num_rows===1?$r->fetch_assoc():null;}
        finally {$r->free();}
    }

    public static function check_write(\mysqli $db,array $plan): array {
        $table=$plan['asts'][0]['target_table'];
        $reader=new SqlMutationPlan($db);
        $schema=$reader->row_schema($table);
        $pairs=self::pairs($plan);
        foreach ($pairs as $pair) {
            $row=self::current($db,$table,$reader->identity_where($schema,$pair['restore']));
            if ($row===null || self::digest($row)!==$pair['expected'])throw new \RuntimeException('row_write_mismatch');
        }
        return [$table=>['verified_selected_rows'=>count($pairs)]];
    }

    private static function uncertain(?array $inverse): array {
        return Result::fail('operation_uncertain','Confirmação inconclusiva. Consulte operations/status antes de qualquer repetição.',
            ['applied'=>null,'retryable'=>false,'backup_id'=>$inverse['id']??null]);
    }

    private static function apply(\mysqli $db,string $table,array $meta,SqlMutationPlan $reader,array $pairs,
        array $schema,array $current,?array &$inverse,bool &$commit_attempted): array {
        $back=[];
        foreach ($pairs as $i=>$pair)$back[]=['restore'=>$current[$i],'expected'=>self::digest($pair['restore'])];
        $inverse=self::write($table,$meta['tables'][$table]['schema_sha256'],$back,'db/restore',Phase::current());
        if (!PrivateArtifact::verify($inverse['id']))throw new \RuntimeException('backup_verification_failed');
        Phase::attach_backup($inverse['id']);
        $changed=0;
        foreach ($pairs as $i=>$pair) {
            $row=$pair['restore'];$set=[];
            foreach ($schema['columns'] as $c) {
                $col=$c['Field'];
                if ($row[$col]===$current[$i][$col])continue;
                $literal=SqlMutationPlan::typed_value($row[$col],$c['Type']);
                $set[]=SqlMutationPlan::q($col).'='.$literal;
            }
            if (!$set)continue;
            $where=$reader->identity_where($schema,$row);
            DatabaseRead::checked($db,'UPDATE '.SqlMutationPlan::q($table).' SET '.implode(',',$set).' WHERE '.$where);
            if ($db->affected_rows!==1 || self::current($db,$table,$where)!==$row)throw new \RuntimeException('restore_readback_failed');
            ++$changed;
        }
        $commit_attempted=true;
        if (!$db->commit())throw new \RuntimeException('commit_uncertain');
        wp_cache_flush();
        return Result::ok(['applied'=>true,'changed'=>$changed>0,'persisted'=>true,'atomic'=>true,'affected_rows'=>$changed,'backup_id'=>$inverse['id']]);
    }

    public static function restore(array $input,array $meta): array {
        if (!DatabaseAdmin::permission() || !ConnectionContext::maintenance())return Result::fail('permission_denied','Restauração exige Manutenção e escrita habilitada.');
        if (!empty($input['allow_changed_destination']))return Result::fail('row_restore_override_unsupported','Uma pré-imagem de linhas exige correspondência exata da pós-imagem.');
        if (($meta['row_contract']??'')!=='row-preimage/1' || $meta['database']!==DB_NAME || $meta['site_id']!==get_current_blog_id() || count($meta['tables'])!==1) {
            return Result::fail('backup_invalid','Pré-imagem não pertence a este banco/site.');
        }
        $db=null;$inverse=null;$commit_attempted=false;
        try {
            $pairs=self::read_pairs($meta);
            $table=array_key_first($meta['tables']);
            $db=DatabaseRead::connection();
            DatabaseRead::checked($db,'SET SESSION innodb_lock_wait_timeout=5');
            DatabaseRead::checked($db,'SET SESSION lock_wait_timeout=5');
            DatabaseRead::checked($db,'SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
            DatabaseRead::checked($db,'START TRANSACTION');
            $reader=new SqlMutationPlan($db);
            $schema=[];$current=[];
            $snapshot=static function()use($db,$meta,$table,$pairs,$reader,&$schema,&$current) {
                // Acquire a metadata lock before reading schema, triggers or rows, also on empty sets.
                DatabaseRead::checked($db,'SELECT * FROM '.SqlMutationPlan::q($table).' LIMIT 0 FOR UPDATE')->free();
                $schema=$reader->row_schema($table);
                if (hash('sha256',$schema['canonical'])!==$meta['tables'][$table]['schema_sha256']) {
                    return new \WP_Error('database_conflict','A estrutura do destino mudou.');
                }
                foreach ($pairs as $pair) {
                    $row=self::current($db,$table,$reader->identity_where($schema,$pair['restore']));
                    if ($row===null || self::digest($row)!==$pair['expected'])return new \WP_Error('restore_destination_changed','Uma das linhas já não corresponde à pós-imagem.');
                    $current[]=$row;
                }
                return ['artifact_id'=>$meta['id'],'artifact_sha256'=>$meta['sha256'],'table'=>$table,'selected_rows'=>count($pairs),'backup_scope'=>'selected_rows'];
            };
            $apply=static function()use($db,$table,$meta,$reader,$pairs,&$schema,&$current,&$inverse,&$commit_attempted) {
                try {
                    return self::apply($db,$table,$meta,$reader,$pairs,$schema,$current,$inverse,$commit_attempted);
                } catch (\Throwable $e) {
                    if ($commit_attempted)return self::uncertain($inverse);
                    $db->rollback();
                    return Result::fail('row_restore_failed','Restauração cancelada antes do commit.',['applied'=>false,'changed'=>false,'backup_id'=>$inverse['id']??null]);
                }
            };
            $result=Phase::run('db/restore',$input,$snapshot,$apply);
            if (!empty($result['preview']))SqlArtifacts::pin($meta['id'],$result['operation_id']);
            return $result+['backup_scope'=>'selected_rows','restore_tables'=>[$table],'restores_entire_tables'=>false];
        } catch (\Throwable $e) {
            if ($commit_attempted)return self::uncertain($inverse);
            return Result::fail('row_restore_failed','Não foi possível validar e restaurar as linhas. Transação cancelada.',['applied'=>false,'changed'=>false,'backup_id'=>$inverse['id']??null]);
        } finally {
            if ($db){try{$db->rollback();}finally{$db->close();}}
        }
    }
}
