# Acompanhantes considerados — Core 1.65.0

Na retomada de 31/10/2026: MCP 0.38.0, Google 0.24.0, Meta 0.17.0 e LinkedIn 0.13.0 ativos na bancada PHP 8.3.6 / WordPress 7.1.4. Pipedrive 0.5.0 não foi ativado nessa bancada por exigir PHP 8.3.36. Após autorização explícita, o Site-Teste confirmou os cinco acompanhantes e Core 1.65.0 ativos, com PHP 8.3.36 / WordPress 7.1.4. O comparativo remoto com/sem Core e Pipedrive passou no limite de 100 ms pela diferença dos mínimos. O pós-check Pipedrive confirmou a conta, sem ensaio de entrega de contato. Não houve homologação de SDKs comerciais. Consulte o relatório atual e evidence/1650. Nenhum acompanhante foi alterado ou redistribuído. Ciclos nativos do Core também passaram no piso WordPress 7.1.2.

## Registro histórico — Core 1.63.0

Base canônica Core 1.62.0. Pacotes separados, sem alterações ou redistribuição. Novos insumos: inputs/1630/packages.json. MCP/Google/LinkedIn mantêm os pacotes originais da base. Contratos SDK não mudam nesta entrega.

| Pacote | Versão | Verificação |
| --- | --- | --- |
| wp-mcp-fator3 | 0.37.0 | Autorização, catálogo, documentação integral e canal do Site-Teste. |
| wp-mcp-google-fator3 | 0.24.0 | SDK/armazenamento originais; transporte sintético em bancada. |
| wp-mcp-meta-fator3 | 0.17.0 | SDK/armazenamento originais, grants, acervos e monitoramento sintéticos. |
| wp-mcp-linkedin-fator3 | 0.13.0 | Bootstrap e convivência; cliente preservado. |
| wp-mcp-pipedrive-fator3 | 0.5.0 | Exige PHP 8.3.36; fica inativo no laboratório PHP 8.3.6. A prova com o pacote ativo usa a bancada isolada do Site-Teste. |

Matriz local: WordPress 7.1.3 e piso 7.1.2, PHP 8.3.6, MySQL 8.0.46. Instalação limpa, atualização direta 1.62.0, repetição e reativação usam o ZIP final. Nenhum transporte comercial real em testes. As versões ativas no Site-Teste, resultados e pendências efetivamente observados estão no relatório e em evidence/1630; a presença do harness não afirma sua execução.
