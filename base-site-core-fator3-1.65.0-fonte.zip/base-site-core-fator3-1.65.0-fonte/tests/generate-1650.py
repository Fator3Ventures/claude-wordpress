from pathlib import Path
import shutil
r=Path(__file__).resolve().parents[1]
for n in ['opcoes-publicas.php','bootstrap-hooks.php','cron-tarefas.php','cron-opcoes.php']:
 shutil.copy2(r/'lab/wordpress/wp-content/plugins/base-site-core-fator3/includes'/n,r/'work/plugin/base-site-core-fator3/includes'/n)
