<?php
require __DIR__.'/bootstrap.php';
$own=F3Base_Execucoes::iniciar('qa_lease');$deadline=new ReflectionProperty(F3Base_Execucoes::class,'deadline');$deadline->setValue(null,microtime(true)+600);
$at=time()-500;$id=F3Base_Execucoes::iniciar_tarefa('llms','f3base_llms_converter_lote',[1650],$at);check((bool)$id,'lease_first_owner');
global $wpdb;$wpdb->update(F3Base_Execucoes::tabela(),['inicio'=>time()-181],['run_id'=>$id]);
$owner=F3Base_Execucoes::dona('llms','f3base_llms_converter_lote',[1650],$at);check(($owner['run_id']??'')===$id,'lease_after_legacy_180_still_owned');
$second=F3Base_Execucoes::iniciar_tarefa('llms','f3base_llms_converter_lote',[1650],$at);check($second===null,'same_occurrence_not_reclaimed');
F3Base_Execucoes::concluir_tarefa($id,['ok'=>true,'resultado_modulo_confirmado'=>true,'codigo'=>'qa']);F3Base_Execucoes::encerrar();
$r=F3Base_Resumo_Operacional::ler();check(strlen(wp_json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))<=4096,'operational_summary_4096');check(isset($r['cron_24h']['pendencias']),'overdue_visible');
evidence('guards-1650');
