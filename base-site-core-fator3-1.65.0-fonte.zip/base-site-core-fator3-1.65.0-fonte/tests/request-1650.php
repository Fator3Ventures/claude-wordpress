<?php
require __DIR__.'/bootstrap.php';
check(F3BASE_PLUGIN_VERSAO==='1.65.0','1650_version');
check(F3Base_Config_Contrato::VERSAO==='8.30.0','1650_contract');
$cfg=F3Base_Options::declaracao('f3base_cron_cli_segundos');check($cfg['padrao']===120&&$cfg['schema_entrada']['minimum']===30&&$cfg['schema_entrada']['maximum']===600,'361_budget_schema');
check(F3Base_Zelador::tarefas()[F3Base_Atualizacao::EVENTO]['classe']==='urgente'&&F3Base_Zelador::tarefas()[F3Base_Pos_Atualizacao::HOOK]['classe']==='urgente','361_upgrade_urgent_in_registry');
check(F3Base_Operacao::prioridade(F3Base_Atualizacao::EVENTO)<F3Base_Operacao::prioridade(F3Base_Pos_Atualizacao::HOOK),'361_migration_precedes_proofs');
check(F3Base_Execucoes::orcamento()===30,'361_web_budget_not_increased');
$saved=save('f3base_cron_cli_segundos',600);check(!empty($saved['persisted']),'361_config_persisted');check(F3Base_Execucoes::orcamento()===30,'361_cli_option_does_not_raise_web');
check(empty(save('f3base_cron_cli_segundos',601)['persisted']),'361_reject_outside_bounds');
$own=F3Base_Execucoes::iniciar('qa1650');$deadline=new ReflectionProperty(F3Base_Execucoes::class,'deadline');$deadline->setValue(null,microtime(true)-1);
$r=apply_filters('pre_http_request',false,[], 'https://example.test/');check(is_wp_error($r)&&$r->get_error_code()==='qa_external_network_blocked','361_expired_passage_does_not_block_other_plugin_http');
$r=F3Base_Execucoes::no_trabalho(static fn()=>apply_filters('pre_http_request',false,[],'https://example.test/'));check(is_wp_error($r)&&$r->get_error_code()==='f3base_orcamento_esgotado','361_expired_core_scope_still_blocked');F3Base_Execucoes::encerrar();
$r=apply_filters('pre_http_request',false,[],'https://example.test/');check(is_wp_error($r)&&$r->get_error_code()==='qa_external_network_blocked','361_scope_restored_after_end');
F3Base_Servicos::iniciar_cta();$html='<a class="f3base-acao-contato" href="/contato">Contato</a>';
for($n=0;$n<30;$n++){$html='<!-- wp:group --><div class="wp-block-group">'.$html.'</div><!-- /wp:group -->';}
$before=F3Base_Servicos::cta_diagnostico()['parseamentos'];$actual=apply_filters('the_content',$html);$after=F3Base_Servicos::cta_diagnostico()['parseamentos'];
check(str_contains($actual,'data-f3base-lead="contato"'),'354_nested_cta_stamped');check($after-$before===1,'354_nested_tree_parsed_once');
$before=$after;check(F3Base_Servicos::carimbar_cta($actual)===$actual,'354_processed_content_unchanged');check(F3Base_Servicos::cta_diagnostico()['parseamentos']===$before,'354_processed_fragment_memoized');
$late=str_replace('</div>','<a class="f3base-acao-contato" href="/novo">Novo</a></div>',$actual);$result=F3Base_Servicos::carimbar_cta($late);check(substr_count($result,'data-f3base-lead="contato"')===substr_count($actual,'</div>')+1,'354_late_ctas_not_skipped');
check(str_contains(F3Base_Servicos::carimbar_cta('<a class="f3base-acao-contato" href="/x">X</a>','cabecalho'),'data-f3base-superficie="cabecalho"'),'354_surface_in_memo_key');
F3Base_Perfil_Publico::atualizar(false);F3Base_Ativos_Publicos::recuperar();$asset=F3Base_Ativos_Publicos::ler();check($asset['vigente'],'1650_public_artifact_current');
$m=$asset['manifesto'];$file=WP_CONTENT_DIR.'/f3base-publico/'.get_current_blog_id().'/'.$m['arquivo'];$bytes=file_get_contents($file);check(hash('sha256',$bytes)===$m['sha256'],'1650_content_addressed_asset');
foreach(['resumo','token','nonce','capi_test_event_code','email_destinatarios'] as $secret){check(!str_contains($bytes,'"'.$secret.'"'),'1650_no_private_'.$secret);}
F3Base_Ativos_Publicos::recuperar();$next=F3Base_Ativos_Publicos::ler()['manifesto'];check($next['arquivo']===$m['arquivo'],'1650_unchanged_config_same_url');
unlink($file);check(!F3Base_Ativos_Publicos::ler()['vigente'],'1650_missing_file_fallback');$fallback=F3Base_Ativos_Publicos::configurar_tracking();check(isset($fallback['dados']['resumo'],$fallback['dados']['comportamento'])&&$fallback['arquivo']==='assets/f3base-tracking.min.js','1650_fallback_current_data');F3Base_Ativos_Publicos::recuperar();
$c=F3Base_Options::ler('f3base_carregamento_destinos');check($c['clarity']==='imediato','1650_clarity_migration');$c['google_ads']='fixo';$c['google_ads_teto_segundos']=0;$c['referencia']='navegacao';check(!empty(save('f3base_carregamento_destinos',$c)['persisted']),'1650_delay_zero_clock_valid');
wp_set_current_user(0);check(F3Base_Ativos_Publicos::ler()['codigo']==='sem_permissao','1650_diagnostics_admin_gate');wp_set_current_user(1);
evidence('request-1650');
