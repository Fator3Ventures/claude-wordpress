const fs=require('fs'),path=require('path'),{JSDOM}=require('./dom/node_modules/jsdom');
const root=path.resolve(__dirname,'..'),a=path.join(root,'work/plugin/base-site-core-fator3/assets'),checks={};
const ck=(v,n)=>{checks[n]=!!v;if(!v)throw Error(n)},wait=ms=>new Promise(r=>setTimeout(r,ms));
function scene(suffix,policy,permitted=true){
 const d=new JSDOM('<!doctype html><html><head><script></script></head><body><a href="/contato">Contato</a></body></html>',{url:'https://fixture.test/',runScripts:'outside-only',pretendToBeVisual:true});const w=d.window;let yes=permitted;
 w.Request=Request;w.TextEncoder=TextEncoder;w.AbortController=AbortController;w.matchMedia=()=>({matches:false});w.IntersectionObserver=class{observe(){}disconnect(){}};w.ResizeObserver=class{observe(){}disconnect(){}};
 w.f3baseConsentimento={permiteCategoria:()=>yes,permiteGtm:()=>yes,permiteTags:()=>yes};
 w.f3baseContexto={pronto:()=>true,teste:()=>false,politica:()=>yes?'normal':'suprimir',audienciaExcluida:false,audiencia:()=>({}),navegacao:()=>null,sinais:()=>({}),atribuicao:()=>({})};
 w.f3baseContextoDados={carregamento:policy};w.f3baseTrackingDados=JSON.parse(fs.readFileSync(path.join(root,'evidence/tracking-1630.json')));
 Object.assign(w.f3baseTrackingDados,{ga4:'G-FIXTURE',gtm:'GTM-FIXTURE',ads:{id:'AW-123456'},meta:{pixelId:'1234567890',modo:'ambos'},clarity:{projectId:'fixture123'},googleCarregamento:{modo:'imediato'}});w.f3baseTrackingDados.resumo.ativo=false;
 w.fetch=async()=>({ok:true,status:200,json:async()=>({ok:true}),headers:{get:()=>null},text:async()=>'{"ok":true}'});
 w.eval(fs.readFileSync(path.join(a,'f3base-tracking'+suffix+'.js'),'utf8'));
 return {w,has:id=>!!w.document.getElementById('f3base-'+id),deny:()=>{yes=false;w.document.dispatchEvent(new w.Event('f3base-consentimento'));},allow:()=>{yes=true;w.document.dispatchEvent(new w.Event('f3base-consentimento'));},close:()=>w.close()};
}
(async()=>{for(const suffix of ['','.min']){
 const policy={ativo:true,referencia:'elegibilidade',ga4:'imediato',google_ads:'fixo',google_ads_teto_segundos:1,meta:'fixo',meta_teto_segundos:1,gtm:'fixo',gtm_teto_segundos:1,linkedin:'fixo',linkedin_teto_segundos:1};
 let s=scene(suffix,policy);await wait(40);ck(s.has('clarity'),suffix+'clarity_early');ck(s.has('gtag'),suffix+'ga4_initial_shared_script');ck(!s.has('meta-pixel')&&!s.has('gtm'),suffix+'ads_wait');
 let dl=()=>Array.from(s.w.dataLayer).map(x=>Array.from(x));ck(!dl().some(x=>x[0]==='config'&&x[1]==='AW-123456'),suffix+'ads_config_wait');await wait(1100);ck(s.has('gtm'),suffix+'gtm_released');ck(dl().some(x=>x[0]==='config'&&x[1]==='AW-123456'),suffix+'ads_later_config');ck(s.w.document.querySelectorAll('#f3base-gtag').length===1,suffix+'one_google_download');s.close();
 s=scene(suffix,{...policy,meta_teto_segundos:0,gtm_teto_segundos:0});await wait(30);ck(s.has('gtm'),suffix+'zero_immediate');s.close();
 s=scene(suffix,policy,false);await wait(50);ck(!s.has('clarity')&&!s.has('gtag')&&!s.has('gtm'),suffix+'denied_nothing');s.allow();await wait(40);ck(s.has('clarity'),suffix+'grant_starts_replay');s.deny();await wait(1100);ck(!s.has('gtm'),suffix+'revoke_cancels_timer');s.close();
 s=scene(suffix,{...policy,antecipar_conversao:true});let delivered=0; s.w.f3baseDestinoEnviar('meta',()=>delivered++,false);await wait(25);ck(delivered===0,suffix+'ordinary_event_does_not_accelerate');s.w.f3baseDestinoEnviar('meta',()=>delivered++,false,true);await wait(25);ck(delivered===2,suffix+'conversion_accelerates_once');s.close();
 s=scene(suffix,{...policy,gtm:'apos_interacao',gtm_teto_segundos:30});s.w.document.dispatchEvent(new s.w.Event('pointerdown'));await wait(20);ck(s.has('gtm'),suffix+'interaction_releases');s.close();
 }
fs.writeFileSync(path.join(root,'evidence/1650/delays-1650.json'),JSON.stringify({environment:'jsdom; provider requests not executed',checks},null,2));console.log(Object.keys(checks).length+' checks OK');})().catch(e=>{console.error(e);process.exit(1)});
