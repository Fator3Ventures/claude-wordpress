// Execute shipped scripts in jsdom; all provider and collector HTTP is intercepted.
const fs=require('fs'),path=require('path'),{JSDOM}=require('./dom/node_modules/jsdom');
const root=path.resolve(__dirname,'..'),asset=path.join(root,'work/plugin/base-site-core-fator3/assets'),checks={};
const ck=(v,n)=>{checks[n]=!!v;if(!v)throw Error(n);},tick=()=>new Promise(r=>setTimeout(r,15));
async function scene(variant,kind='normal'){
 const dom=new JSDOM('<!doctype html><html><head><script></script></head><body><main>Fixture</main></body></html>',{url:'https://fixture1630.example.test/',runScripts:'outside-only',pretendToBeVisual:true});
 const w=dom.window,requests=[],fb=[],handlers={};let resolve,permit=kind!=='denied';
 const add=w.document.addEventListener.bind(w.document);w.document.addEventListener=(n,fn,o)=>{(handlers[n]??=[]).push(fn);add(n,fn,o);};
 w.Request=Request;w.TextEncoder=TextEncoder;w.AbortController=AbortController;w.matchMedia=()=>({matches:false});w.IntersectionObserver=class{observe(){}disconnect(){}};w.ResizeObserver=class{observe(){}disconnect(){}};
 Object.defineProperty(w.document.documentElement,'scrollHeight',{value:5000});Object.defineProperty(w,'innerHeight',{value:1000});Object.defineProperty(w.performance,'timeOrigin',{value:Date.now()-200});
 if(kind==='test')w.document.cookie='f3base_teste=1';if(kind==='robot')Object.defineProperty(w.navigator,'webdriver',{value:true});
 w.f3baseConsentimento={permiteCategoria:()=>permit,permiteGtm:()=>permit,permiteTags:()=>permit};
 w.f3baseContextoDados={contextoUrl:'/context',audienciaExcluida:kind==='editor',paginaExcluida:kind==='editor',testeServidor:kind==='header',testes:{habilitado:true,destinos:{}},campos:[],atribuicao:{}};
 w.f3baseTrackingDados=JSON.parse(fs.readFileSync(path.join(root,'evidence/tracking-1630.json')));
 Object.assign(w.f3baseTrackingDados,{ga4:'G-FIXTURE',googleCarregamento:{modo:'imediato'},caminho:'direto'});
 w.f3baseTrackingDados.resumo.endpoint='/collector';w.f3baseTrackingDados.resumo.token='9999999999.signature';w.f3baseTrackingDados.resumo.rotaToken='/token';
 w.f3baseTrackingDados.resumo.ativo=true;
 w.fbq=(...args)=>fb.push(args);
 w.fetch=(url,o={})=>{requests.push({url:String(url),body:o.body});if(url==='/context'){return new Promise(r=>{resolve=()=>r({ok:true,json:async()=>({ok:true,excluida:kind==='editor',contexto_teste:kind==='header',teste_origem:kind==='header'?'cabecalho':''})});});}return Promise.resolve({ok:true,status:200,headers:{get:()=>null},json:async()=>({ok:true,token:'9999999999.signature'}),text:async()=>'{"ok":true}'});};
 const load=n=>w.eval(fs.readFileSync(path.join(asset,n+variant+'.js'),'utf8'));
 w.f3baseInicialDados={contextoUrl:'/context'};load('f3base-inicial');load('f3base-contexto');load('f3base-tracking');
 w.f3baseLeadsDados={medicao:{meta:{pixelId:'1234567890',modo:'ambos'},transporte:{},conteudo:{},ads:{},linkedin:{}}};load('f3base-leads');
 await tick();w.document.dispatchEvent(new w.Event('DOMContentLoaded'));
 const conversion=id=>w.document.dispatchEvent(new w.CustomEvent('f3base-formulario-aceito',{detail:{formulario:'fixture',correlacao:id,method:'formulario',contexto_teste:kind==='test',conversao:{elegivel:true,event_id:id,meta_correspondencia:{em:'a'.repeat(64),ph:'b'.repeat(64)}}}}));
 const scroll=()=>{Object.defineProperty(w,'pageYOffset',{value:3200,configurable:true});w.dispatchEvent(new w.Event('scroll'));};
 const gesture=()=>handlers.wheel.forEach(fn=>fn({isTrusted:true,type:'wheel'}));
 return {w,fb,requests,resolve:()=>resolve&&resolve(),scroll,gesture,conversion,permit:v=>{permit=v;w.document.dispatchEvent(new w.Event('f3base-consentimento'));},close:()=>w.close()};
}
(async()=>{
 for(const variant of ['','.min']){
  for(const kind of ['normal','test','header','denied','editor','robot']){
   const s=await scene(variant,kind),prefix=variant+kind;
   ck(s.fb.some(a=>a[0]==='track'&&a[1]==='PageView')===false,prefix+'_pv_waits_for_current_context');
   ck(!s.requests.some(r=>r.url==='/collector'),prefix+'_no_own_send_pending');
   ck(!s.w.document.getElementById('f3base-gtag'),prefix+'_ga4_still_waits');
   s.conversion('c'.repeat(32));ck(!s.fb.some(a=>a[1]==='Lead'),prefix+'_lead_waits');
   s.gesture();s.scroll();await tick();s.resolve();await tick();await tick();
   if(kind==='normal'){
    const i=s.fb.findIndex(a=>a[0]==='track'&&a[1]==='Lead');ck(i>0&&s.fb[i-1][0]==='init'&&s.fb[i-1][2].em==='a'.repeat(64),prefix+'_matching_init_before_lead');ck(s.fb[i][3].eventID==='c'.repeat(32),prefix+'_same_event_id');
    s.conversion('c'.repeat(32));ck(s.fb.filter(a=>a[1]==='Lead').length===1,prefix+'_lead_deduplicated');
    s.w.dispatchEvent(new s.w.Event('pagehide'));await tick();await tick();
    const all=s.requests.filter(r=>r.url==='/collector').map(r=>JSON.parse(r.body));
    ck(all.length>0,prefix+'_own_release_after_classification');
    const events=all.flatMap(b=>b.eventos||b.lote?.eventos||[]);ck(events.some(e=>e.gatilho==='pagina'&&e.ms===0),prefix+'_page_clock_from_navigation');ck(events.filter(e=>e.gatilho==='rolagem').length===3&&!events.some(e=>e.gatilho==='rolagem-salto'),prefix+'_trusted_early_scroll_not_jump');ck(events.some(e=>e.gatilho==='saida'&&e.valor>=30),prefix+'_visible_time_includes_initial_buffer');fs.writeFileSync(path.join(root,'evidence/1650/dom-events-1650'+(variant||'.source')+'.json'),JSON.stringify(all,null,2));
    ck(!JSON.stringify(all).includes('a'.repeat(64)),prefix+'_matching_not_in_own_payload');
    ck(!Array.from({length:s.w.localStorage.length},(_,i)=>s.w.localStorage.getItem(s.w.localStorage.key(i))).join('').includes('a'.repeat(64)),prefix+'_matching_not_in_storage');
   }else{ck(!s.fb.some(a=>a[1]==='Lead'),prefix+'_no_ineligible_meta_lead');}
   s.close();
  }
 }
 fs.writeFileSync(path.join(root,'evidence/1650/dom-1650.json'),JSON.stringify({environment:'jsdom 27.4.0; actual source and minified scripts; synthetic HTTP only',checks},null,2));console.log(Object.keys(checks).length+' checks OK');
})().catch(e=>{console.error(e.stack);process.exit(1);});
