"""Compare generated WordPress HTML and its actual local JS dependencies.
Offline gzip estimates, not HAR, first-three-second timing or provider bytes.
Run after equivalent fixture profiles in lab-base and lab.
"""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse, unquote
import gzip, json, re

root=Path(__file__).resolve().parents[1]
class Scripts(HTMLParser):
    def __init__(self):
        super().__init__(); self.head=False; self.current=None; self.items=[]
    def handle_starttag(self,tag,attrs):
        if tag=='head':self.head=True
        if tag=='script':self.current={'attrs':dict(attrs),'head':self.head,'text':''}
    def handle_endtag(self,tag):
        if tag=='script' and self.current is not None:self.items.append(self.current);self.current=None
        if tag=='head':self.head=False
    def handle_data(self,data):
        if self.current is not None:self.current['text']+=data
def gz(b):return len(gzip.compress(b,compresslevel=9,mtime=0))
def measure(label,lab,evidence):
    html=(root/evidence/'page1-html.html').read_bytes();parser=Scripts();parser.feed(html.decode())
    assets=[];sync=[];inline=[]
    for item in parser.items:
        a=item['attrs'];src=a.get('src','');ident=a.get('id','')
        if src and ('/base-site-core-fator3/' in src or '/f3base-publico/' in src):
            p=root/lab/'wordpress'/unquote(urlparse(src).path).lstrip('/');b=p.read_bytes()
            assets.append({'id':ident,'path':urlparse(src).path,'bytes':len(b),'gzip':gz(b),'defer':'defer' in a})
            if item['head'] and 'defer' not in a:sync.append(b)
        elif not src and ident.startswith('f3base'):
            b=item['text'].encode();inline.append({'id':ident,'bytes':len(b),'gzip':gz(b),'head':item['head']})
            if item['head']:sync.append(b)
    return {'version':label,'html_bytes':len(html),'html_gzip':gz(html),'own_js_requests':len(assets),'external_own_js_gzip':sum(x['gzip'] for x in assets),'head_sync_own_js_gzip_sum':sum(gz(b) for b in sync),'html_plus_external_js_gzip':gz(html)+sum(x['gzip'] for x in assets),'assets':assets,'inline':inline}
base=measure('1.64.0','lab-base','evidence/1650-base');candidate=measure('1.65.0','lab','evidence/1650')
text=(root/'evidence/1650/page1-html.html').read_text();match=re.search(r'var f3baseLeadsDados\s*=\s*',text)
assert match
data=json.JSONDecoder().raw_decode(text[match.end():])[0]
assert set(data['medicao'])=={'caminho','conteudo','gtm','ga4','ads','meta','linkedin'}
report={'scope':'Same synthetic WordPress article fixture; gzip estimate, excludes remote SDKs and does not measure first 3 seconds. Inline compression is an upper-bound sum, not wire compression.','base':base,'candidate':candidate,'conversion_projection_verified':True,'delta_html_plus_js_gzip':candidate['html_plus_external_js_gzip']-base['html_plus_external_js_gzip']}
(root/'evidence/1650/transfer-comparison.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['base','candidate']}))
for v in [base,candidate]:print(json.dumps({k:x for k,x in v.items() if k not in ['assets','inline']}))
