from pathlib import Path
import shutil
r=Path(__file__).resolve().parents[1]
src=r/'lab/wordpress/wp-content/plugins/base-site-core-fator3';dest=r/'work/plugin/base-site-core-fator3'
for n in ['dados/estado-inventario.json','docs/AJUDA-OPCOES.md']:
 shutil.copy2(src/n,dest/n)
shutil.copytree(src/'docs/dados',dest/'docs/dados',dirs_exist_ok=True)
