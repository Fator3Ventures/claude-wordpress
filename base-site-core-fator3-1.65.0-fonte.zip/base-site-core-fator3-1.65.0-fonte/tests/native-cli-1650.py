"""Real WP-CLI cron command; callbacks replaced only in disposable MU fixture, never runtime."""
from pathlib import Path
import os,subprocess,json,hashlib,uuid
r=Path(__file__).resolve().parents[1];site=Path(os.environ['F3BASE_LAB_DIR'])/'wordpress';out=r/os.environ.get('F3BASE_EVIDENCE_DIR','evidence/1650');mu=site/'wp-content/mu-plugins/native1650.php';log=Path(os.environ['F3BASE_LAB_DIR'])/('native-cli-jobs-'+uuid.uuid4().hex+'.jsonl');os.environ['F3BASE_QA_NATIVE_LOG']=str(log)
mu.write_text('''<?php
if(wp_get_environment_type()!=='local'||!defined('WP_CLI')||!WP_CLI){return;}
add_action('f3base_zelador',static function(){
 if(!getenv('F3BASE_QA_NATIVE')){return;}
 $p=new ReflectionProperty(F3Base_Operacao::class,'callbacks');$map=$p->getValue();
 foreach($map as $hook=>&$entries){$entries=[['function'=>static function(...$args)use($hook){
  if($hook==='f3base_llms_converter_lote'&&isset($args[0])&&is_int($args[0])){file_put_contents(getenv('F3BASE_QA_NATIVE_LOG'),json_encode(['job'=>$args[0],'budget'=>F3Base_Execucoes::orcamento(),'origin'=>F3Base_Execucoes::origem(),'lease'=>F3Base_Execucoes::reserva_segundos(),'pass'=>F3Base_Execucoes::atual()['run_id']])."\\n",FILE_APPEND);}
  if($hook==='f3base_llms_converter_lote'&&($args[0]??null)===991){usleep(2500000);}
  return ['ok'=>true,'resultado_modulo_confirmado'=>true,'codigo'=>'qa_native_confirmado'];},'accepted_args'=>99,'priority'=>10]];}unset($entries);$p->setValue(null,$map);
},PHP_INT_MAX-8);
''')
cli=[str(r/'build/php'),str(r/'dependencies/wp-cli.phar'),'--allow-root','--path='+str(site),'--skip-themes']
def call(args,qa=False):
 p=subprocess.run(cli+args,env=dict(os.environ,F3BASE_QA_NATIVE='1' if qa else ''),capture_output=True,text=True,timeout=150)
 if p.returncode:raise RuntimeError(p.stdout[-1500:]+p.stderr[-1500:])
 return p.stdout
try:
 # Complete upgrade normally before fixture callback interception.
 normal=call(['cron','event','run','--due-now'])
 seed=Path(os.environ['F3BASE_LAB_DIR'])/'seed-native1650.php';seed.write_text('''<?php
update_option('f3base_cron_cli_segundos',600,true);global $wpdb;$wpdb->query('DELETE FROM '.F3Base_Operacao_Intencoes::tabela());update_option('cron',[],true);
for($i=0;$i<15;$i++){wp_schedule_single_event(time()-2000+$i,'f3base_llms_converter_lote',[$i]);}
echo wp_json_encode(['budget'=>F3Base_Execucoes::orcamento(),'version'=>F3BASE_PLUGIN_VERSAO]);
''')
 seeded=call(['eval-file',str(seed)])
 executed=call(['cron','event','run','--due-now'],True)
 rows=[json.loads(x) for x in log.read_text().splitlines()];assert [x['job'] for x in rows]==list(range(15)),rows
 assert all(x['origin']=='cli' and x['budget']==600 and x['lease']>600 for x in rows),rows
 assert len(set(x['pass'] for x in rows))==1,rows
 verify=Path(os.environ['F3BASE_LAB_DIR'])/'verify-native1650.php';verify.write_text('''<?php
global $wpdb;$rows=$wpdb->get_results("SELECT origem,entrada,dados FROM ".F3Base_Execucoes::tabela()." WHERE parent_run_id='' ORDER BY id DESC LIMIT 2",ARRAY_A);echo wp_json_encode(['rows'=>$rows,'upgrade'=>get_option('f3base_atualizacao_urgente_concluida'),'pending'=>wp_next_scheduled('f3base_llms_converter_lote')]);
''');v=json.loads(call(['eval-file',str(verify)]));assert v['upgrade']=='1.65.0',v
 # Concurrent native invocations contend for the same durable occurrence.
 seed.write_text("<?php global $wpdb;$wpdb->query('DELETE FROM '.F3Base_Operacao_Intencoes::tabela());update_option('cron',[],true);wp_schedule_single_event(time()-100,'f3base_llms_converter_lote',[991]);")
 call(['eval-file',str(seed)])
 import time
 env=dict(os.environ,F3BASE_QA_NATIVE='1')
 first=subprocess.Popen(cli+['cron','event','run','--due-now'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 for _ in range(80):
  if any(json.loads(x)['job']==991 for x in log.read_text().splitlines()):break
  time.sleep(.05)
 second=subprocess.run(cli+['cron','event','run','--due-now'],env=env,capture_output=True,text=True,timeout=120)
 a,b=first.communicate(timeout=120);assert first.returncode==0 and second.returncode==0,(a,b,second.stderr)
 concurrent=[json.loads(x) for x in log.read_text().splitlines() if json.loads(x)['job']==991];assert len(concurrent)==1,concurrent
 report={'candidate_sha256':hashlib.sha256(Path(os.environ['F3BASE_CANDIDATE']).read_bytes()).hexdigest(),'concurrent_native_occurrence_executed_once':True,'wp_cli':'2.12.0','wp_cli_sha256':hashlib.sha256((r/'dependencies/wp-cli.phar').read_bytes()).hexdigest(),'scope':'native command; synthetic callbacks; no provider delivery proof','jobs':rows,'journal':v,'checks':{'15_due_jobs_drained':True,'oldest_first':True,'single_shared_passage':True,'cli_origin':True,'600_budget_and_lease_over_600':True,'upgrade_first_cli':True},'command_output':executed}
 (out/'native-cli-1650.json').write_text(json.dumps(report,indent=2));print('native CLI: 15 jobs, oldest first, one passage, 600 second budget OK')
finally:mu.unlink(missing_ok=True);log.unlink(missing_ok=True)
