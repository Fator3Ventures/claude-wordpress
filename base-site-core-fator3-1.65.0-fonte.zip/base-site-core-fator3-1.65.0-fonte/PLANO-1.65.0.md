# Entrega — Fator3 Site Core 1.65.0 (prevista)

Revisão 3 · 31/10/2026 · Fuso de referência: America/Sao_Paulo · Rodada: planejamento de implementação.

**Status: planejamento concluído, com medições de navegador e decisões de ativação pendentes.** Base examinada: 1.64.0. A versão 1.65.0 ainda não foi implementada nem empacotada. Esta rodada produziu análise de código, inventário de ativos e plano de execução; não alterou configurações ou instalações.

**Direção definida para a versão:** preservar diagnóstico detalhado e replay em todas as visitas elegíveis; gerar previamente a configuração pública e os ativos próprios aplicáveis; reduzir trabalho no carregamento e durante interações; oferecer atraso publicitário configurável. A 1.65.0 deve entregar essas melhorias em código, com comparação antes/depois e regressão funcional.

**Decisão preservada da revisão 2:** retirada a proposta de amostragem de 10% da revisão 1. Nenhuma visita elegível terá o detalhe reduzido por sorteio ou por ter saído sem interação. A instrumentação acompanha a implementação das melhorias. A gravação deste plano não equivale à implementação do plugin.

**Novidade da revisão 3:** incorporados o pedido 361 e os acréscimos de 31/10 aos pedidos 354 e 360. A correção do executor/cron passa à primeira prioridade, seguida do processamento único de CTA e do catálogo público. O limite de 20 ms não instrumentados foi retirado pela frota e deixa de ser critério de aceite. Permanecem obrigatórias as melhorias de JavaScript, geração prévia e atrasos configuráveis.

## 1. Bases aceitas

- Fonte, instalador e relatório finais do Core 1.64.0; contrato administrativo publicado 8.29.0. Os dez arquivos JavaScript inventariados abaixo foram comparados byte a byte com o instalador.
- Instruções comuns e padrão de desenvolvimento Fator3, revisão 4 de 16/10/2026.
- Pedido atual: reduzir carregamento, bytes, arquivos e JavaScript, preservando a investigação das visitas curtas de tráfego pago e orgânico.
- Complemento do pedido: cobertura integral do diagnóstico/replay, atraso publicitário configurável e geração prévia no salvamento da configuração. Escopo mínimo de implementação definido nas frentes P1–P5, P8 e P9.
- Nova entrada: `Fator3 Site Core(20261031-123104).md`, lida integralmente nesta revisão; SHA-256 `a654c575bfb8d765c53f449a1816df37d7277837d6eb0b3be90df4bf523146e5`. Mantém abertos os pedidos oficiais 354, 360 e 361; 357–359 foram encerrados pela frota. Os códigos P0–P9 deste plano são frentes internas, não novos números oficiais de pedido.
- Evidência recebida da frota: Core 1.64.0 distribuído nos 12 sites, incluindo Site-Teste, e migrações concluídas com intervenção pelo executor nos 11 de produção. Isso é relato posterior à entrega do pacote, não uma implantação ou verificação realizada nesta rodada.

O incremento minor segue a convenção do projeto. Os mínimos comprovados da base são WordPress 7.1.2 e PHP 8.3.6; a futura versão precisa renovar a prova de instalação e atualização direta de 1.64.0.

## 2. Convivência e impactos

Na leitura realizada para a revisão 1, o Site-Teste mantinha Core 1.64.0, MCP 0.38.0, Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0 e Pipedrive 0.5.0 ativos. A presença dos pacotes não comprova que seus fornecedores sejam carregados no navegador.

O diagnóstico dos slots obtido na revisão 1 indicou somente Clarity preenchido; GTM, GA4, Google Ads, Meta Pixel e LinkedIn estavam vazios. A inspeção antiga de GTM estava encerrada e não vigente. **Essa configuração não representa uma página de campanha com todas as tags ativas**, nem exclui tags inseridas por tema ou outra origem. Não se usou o tamanho histórico do contêiner como custo atual.

O Core continua responsável pelos scripts públicos, consentimento, atribuição, Pixel/CAPI e contatos. As APIs dos acompanhantes, o cliente Lead Sync selecionado, o fluxo Pipedrive, os nomes de eventos comerciais e sua deduplicação permanecem no contrato existente.

**Não foi identificado impacto que exija alteração em outro pacote no escopo proposto.** Não foram emitidos documentos individuais sem ação técnica. A coordenação necessária com o operador de campanhas é conferir proprietários das tags, gatilhos de GTM e cobertura nas plataformas; isso não implica mudança no plugin Google, Meta ou LinkedIn. Tema, contêineres efetivos e configuração de produção estão `nao-avaliado` nesta rodada. Se a implementação revelar consumidor externo afetado por um contrato, o impacto correspondente deve ser emitido antes dessa alteração.

No pedido 361, a alteração é do executor e da classificação de tarefas do Core. Preservar os contratos públicos, o transporte MCP, as cotas dos fornecedores e as tarefas dos acompanhantes. O novo orçamento CLI não será aplicado a requisições MCP/web nem deve bloquear chamadas HTTP de outros pacotes por uma passagem Core já encerrada. A ampliação do resumo operacional será aditiva, mantendo o limite de 4096 bytes e a indicação de detalhe/omissão. Essa delimitação sustenta a ausência de encaminhamento individual neste planejamento; qualquer quebra encontrada exige impacto antes da implementação afetada.

## 3. Evidências, oportunidades e plano

### 3.1 O que está comprovado e o que falta medir

**Inventário estático de JavaScript público próprio.** Bytes dos arquivos finais; gzip calculado localmente, nível 9, por arquivo. Não são transferências medidas em uma página, não incluem cabeçalhos, configuração inline, CSS ou scripts baixados dos fornecedores. A soma não afirma que todos os arquivos sejam carregados em toda visita.

| Arquivo em `assets/` | Bytes do arquivo | Bytes gzip local | Condição/observação |
|---|---:|---:|---|
| `f3base-consentimento.min.js` | 12360 | 4663 | Enqueue no head, sem estratégia defer/async |
| `f3base-contexto.min.js` | 12231 | 4660 | Enqueue no head, dependente de consentimento |
| `f3base-tempo-ativo.min.js` | 756 | 444 | Head, quando tempo ativo está habilitado |
| `f3base-tracking.min.js` | 39136 | 13775 | Head; reúne fornecedores e instrumentação |
| `f3base-leads.min.js` | 17376 | 6065 | Footer com defer; verificar elegibilidade por CTA |
| `f3base-formularios.min.js` | 22156 | 7651 | Footer com defer; já solicitado na renderização do formulário |
| `f3base-analise.min.js` | 11896 | 4366 | Footer com defer, dependente de tracking |
| `f3base-ofertas.min.js` | 5012 | 2137 | Enfileirado quando análise está enfileirada |
| `f3base-meta-transporte.min.js` | 4686 | 2062 | Condicionado a tracking e pixel configurado |
| `vendor/web-vitals.js` | 11496 | 4103 | Carga dinâmica; biblioteca local com ajustes do Core |
| **Total do inventário** | **137105** | **49926** | Dez arquivos; combinação efetiva depende da página |

Os três arquivos principais de head somam **63727 bytes**, ou **23098 bytes gzip local**. Com tempo ativo, são quatro arquivos e **64483 / 23542 bytes**. O código pede execução sem defer; a estratégia realmente impressa e eventuais intervenções do cache/otimizador precisam ser verificadas no HTML e no navegador.

O CSS de consentimento tem 3118 bytes; o de formulários, 1921; WhatsApp, 876; contatos, 388. Há CSS inline e configuração JavaScript inline a contabilizar no HTML. CSS administrativo/editorial não foi tratado como custo público. O tamanho de aproximadamente 3 MB do instalador não é o tamanho de uma visita.

| Achado na fonte 1.64.0 | Consequência e oportunidade |
|---|---|
| Consentimento, contexto e tracking estão concentrados no início | Separar bootstrap pequeno, interface de consentimento, funcionalidades e diagnóstico; aplicar defer ao conjunto de dependências compatível |
| Já existe observação inicial efêmera, antes da classificação | Reaproveitar essa estrutura; reduzir trabalho repetido, preservando horários, campos e granularidade dos eventos |
| A coleta comportamental e vários fornecedores aguardam `contexto-publico`; timeout de classificação de 5 s | Medir duração e falhas dessa etapa; iniciar classificação cedo, reduzir processamento e evitar chamadas redundantes sem enfraquecer exclusões |
| Meta PageView tem caminho antecipado próprio, sem aguardar DOMContentLoaded ou a resposta de contexto | Preservar como comportamento de referência; unificar agendamento não pode atrasá-lo inadvertidamente. Seus gates de consentimento, exclusão e teste precisam continuar cobertos |
| Modos ocioso/após interação já existem; o prazo de reserva começa em `load` | Uma página lenta pode prolongar a espera. Propor prazo explícito contado da navegação/elegibilidade, com consentimento como condição obrigatória |
| A fila de análise normalmente espera `load` + 5 s, mas ocultamento/pagehide/cliques podem antecipar envio | Não é correto afirmar que toda visita curta se perde. Investigar eventos anteriores à liberação, falhas de transporte e encerramentos sem evento final |
| Rolagem inicial lê dimensões em cada evento; posição do formulário varre campos em input/change | Reutilizar geometria com invalidação correta e manter estado incremental dos campos. Preservar observações, horários e cruzamentos de limites; não reduzir a frequência de captura para atingir orçamento |
| Ofertas acompanham análise mesmo sem oferta; CSS de formulário pode entrar quando há qualquer formulário cadastrado no site | Carregar por presença real e suportar conteúdo dinâmico. O JS de formulário já é condicionado à renderização, portanto não é uma remoção global nova |
| Google já compartilha gtag entre GA4 e Ads; fornecedores são inseridos com async | Preservar compartilhamento e auditar duplicações com GTM/tema. Async evita bloqueio do parser pelo download, mas não elimina competição por rede e CPU |
| URLs de ativos usam a versão global do plugin | Avaliar hash do conteúdo para preservar cache em atualizações só de PHP, mantendo compatibilidade com HTML antigo em cache |
| `F3Base_Perfil_Publico` já mantém `f3base_config_publica` normalizada, atualizada em alterações de options | Aproveitar a preparação existente no servidor e evoluir para configuração pública serializada, seleção de módulos e ativos cacheáveis. Não contar a normalização já existente como melhoria nova |
| `F3Base_Options::gravar_interno()` confirma persistência, aplica efeitos e invalida cache | Integrar geração ao fluxo comum de escrita e aos recibos existentes, abrangendo wp-admin, MCP, importação e migração |
| `F3Base_Execucoes::iniciar()` fixa 30 s e `pode_trabalhar()` exige menos de três trabalhos, sem distinguir CLI | Confirma o mecanismo do 361; separar orçamento CLI da política web e incluir migração/pós-atualização no caminho urgente |
| `cron-tarefas.php` classifica migração e pós-atualização como rotina; o diário e as reservas usam expiração de 180 s | Corrigir as classificações e compatibilizar reservas/recuperação com o orçamento CLI de até 600 s |

Referências de código, relativas ao runtime do fonte-base: `includes/class-f3base-atribuicao.php:125`, `class-f3base-modulo-consentimento.php:247`, `class-f3base-modulo-tracking.php:528` e `:845`, `class-f3base-formularios.php:267` e `:390`, `class-f3base-ofertas-medicao.php:9`, `class-f3base-meta-transporte.php:54`, `class-f3base-perfil-publico.php:12` e `:29`, `class-f3base-options.php:466` e `:604`, `trait-f3base-options-efeitos.php:9`, `class-f3base-cache-pagina.php:40`, `trait-f3base-options-catalogo.php:757`; `assets/f3base-contexto.js:8`, `f3base-tracking.js:80`, `:183`, `:3100` e `:3528`; início de `f3base-analise.js`.

**Servidor: evidência herdada, não nova medição.** A entrega 1.64.0 registrou 85,888–98,097 ms próprios do Core na página. A comparação com/sem Core **e Pipedrive** teve diferença mínima de 130,460 ms em três amostras por condição. Isso ainda excede o pedido de 100 ms, mas não isola causalmente o Core. A janela não instrumentada inclui WordPress, tema e acompanhantes. As otimizações de catálogo, schema, cron e triagem de HTML já existem; o próximo trabalho é atacar o custo residual, sem contabilizá-las de novo como novidade.

Não há nesta rodada HAR, perfil de CPU móvel, cobertura de código executado, LCP/INP de produção ou volume de perda nos primeiros segundos. Ganhos percentuais de experiência ainda não estão comprovados.

**Atualização de evidência recebida em 31/10:** a frota informa 64–79 ms próprios do Core em korvena.com.br, dentro do limite; em fator3.com.br, 253–307 ms, com 157–171 ms no callback de `render_block` em 424 chamadas e 45–54 ms em `carimbar_cta` no `the_content`. A repetição do processamento em níveis aninhados é hipótese apoiada pelo código, ainda sem medição por bloco. A abertura do catálogo completo em uma amostra de fator3.com.br permanece sem causa identificada. Estes números não foram reproduzidos nesta rodada.

### 3.2 Arquitetura recomendada para os primeiros segundos

“100%” abaixo significa todas as visitas elegíveis em que o código executa e a política permite a medição; não significa todos os cliques dos anúncios ou todos os visitantes.

| Momento | Trabalho proposto | Medição preservada |
|---|---|---|
| Início do documento | Bootstrap mínimo, estado de consentimento, relógio monotônico, visibilidade e observadores mínimos compatíveis | Horário da navegação, início da observação e sinais técnicos efêmeros já permitidos |
| Classificação e consentimento resolvidos | Registrar chegada elegível sem depender do bundle de análise detalhada; iniciar destinos conforme política explícita | Atribuição permitida, versão do coletor, elegibilidade e atraso até a coleta |
| Primeira renderização e disponibilidade do conteúdo | Módulos defer; CTA e formulário utilizáveis desde o primeiro clique; Web Vitals básicos | Primeira pintura observada, primeira interação, CTA, início e aceite de formulário |
| Até 10 s visíveis | Atualizar marcos de 1, 3, 5 e 10 s em memória; consolidar snapshots, sem POST por segundo | Tempo visível e progresso observado, incluindo ausência de interação |
| Ocultamento e retorno | Envio pequeno em `visibilitychange`; pagehide como apoio; retomar corretamente em pageshow/BFCache | Último estado observado e retomada, sem interpretar toda ocultação como saída definitiva |

Todos os módulos de observação detalhada habilitados devem iniciar cedo nas visitas elegíveis. Trabalho posterior de transformação/envio pode ser organizado em lotes, conservando os dados capturados. Replay começa assim que a política permite; um registro leve do Core não reconstrói retroativamente o replay de um SDK que ainda não iniciou. Clarity fica fora da herança de atraso publicitário nesta versão. Consentimento, exclusões, bloqueio de rede e disponibilidade do fornecedor continuam limitando a cobertura observável; o Core não acrescentará amostragem.

Registrar separadamente navegação, início da observação, liberação da política, ocorrência, enfileiramento, envio e confirmação. Isso permite distinguir visitante que saiu cedo de instrumentação que começou tarde. Reusar identificadores e filas do Core; nenhuma segunda contagem de PageView ou de Lead.

Proposta de transporte: um registro inicial assim que elegível, um snapshot em torno de 3 s e outro em torno de 10 s, consolidando eventos no mesmo lote; envio final adicional quando necessário. Os marcos de 1/3/5/10 s não são quatro requisições. Priorizar a confirmação de contato e limitar bytes, frequência, concorrência e memória. Resolver tokens enquanto a página está ativa para não depender de uma renovação no fechamento. Manter política de repetição e deduplicação existente.

O bootstrap pode manter observações técnicas efêmeras dentro da política atual; armazenamento, identificadores e envios continuam sujeitos aos gates. Recusa explícita descarta o que deve ser descartado; não se retroenviam eventos ocorridos durante recusa. O fluxo funcional de contato continua separado da autorização para publicidade.

`sendBeacon` ou fetch com keepalive são opções de transporte, não prova de persistência: uma fila aceita pelo navegador não é um recibo do servidor. Encerramentos abruptos ainda geram observação incompleta. Usar lotes pequenos e respeitar os limites compartilhados de keepalive; não esperar apenas pelo encerramento para enviar a primeira evidência.

Para classificação, começar pelo custo do endpoint e pela sequência de carregamento. Reutilização temporária de resultado exige revisão de política, validade e invalidação bem definidas. Não adotar cache longo que mantenha usuário excluído como elegível. Preservar HTML de cache público independente de cookies de consentimento, identidades ou UTMs.

### 3.3 Decisões de cobertura e comportamento

| Medição/comportamento | Recomendação para a 1.65.0 | Perda ou custo assumido |
|---|---|---|
| Chegada, tempo visível, primeiro gesto, CTA e contato aceito | Preservar em todas as visitas elegíveis; registro leve e cedo | Pequeno custo constante; cobertura limitada por consentimento, bloqueadores, execução e rede |
| Web Vitals e sua atribuição detalhada habilitada | Preservar em todas as visitas elegíveis; distinguir métrica indisponível de zero | Continua o custo dos observadores. Biblioteca local contém ajustes que precisam de regressão |
| Rolagem por seção, releituras, fricção e LoAF habilitados | Preservar detalhe em todas as visitas elegíveis; otimizar leituras, estruturas e execução | A otimização deve manter catálogo, campos, horários e granularidade observada; equivalência precisa de prova |
| Replay/Clarity habilitado | Iniciar cedo em todas as visitas elegíveis; manter mascaramento e demais proteções existentes | Custo do SDK permanece. Cobertura real depende também de execução, política e entrega ao fornecedor |
| Tags de anúncios e PageView | Implementar controles explícitos por destino/canal; modo imediato disponível; Meta antecipado continua padrão | Atraso escolhido pode perder eventos e atribuição de visitas muito curtas; fila não garante entrega antes do SDK carregar |
| Formulários, WhatsApp e ofertas | Funcionalidade conforme presença; análise detalhada separada. Pré-carregar antes do uso quando necessário | Mais complexidade de carregamento; primeiro clique, foco e envio não podem aguardar download ou falhar |
| Modais/ofertas automáticas | Experimento por página: adiar gatilho de tempo até intenção clara ou reduzir frequência, com layout estável | Menos impressões e possível mudança na conversão. Apresentação/gatilhos pertencem ao tema; alteração exige escopo próprio |

Cobertura integral é requisito funcional. A atualização não deve criar amostragem, reduzir resolução temporal, retirar campos ou atrasar o início de observadores/replay como mecanismo de economia. Coleta detalhada e replay já habilitados permanecem disponíveis para toda visita elegível. Recursos desabilitados pelo operador continuam desabilitados; isso não é autorização para ligar novos fornecedores. Detecção condicional de ausência de uma funcionalidade deve ser exata e incluir conteúdo dinâmico.

Para páginas pagas, proteger a chegada e a atribuição autorizada de LinkedIn Ads, Google Ads e Instagram/Meta, testar navegadores internos dos aplicativos e acompanhar contatos aceitos. Para orgânico, manter medição básica e carregar apenas funcionalidades presentes. Não desligar um destino automaticamente porque o referrer é orgânico: isso também altera remarketing e atribuição futura. Perfis por rota/finalidade são explícitos e limitados; não fragmentar o cache por cada UTM.

Não recomendar nesta rodada migração geral para tracking somente no servidor. O Measurement Protocol do GA4 complementa a coleta por tags e não oferece equivalência automática. O Core já tem modo Meta servidor com homologação própria: não substituir esse requisito por um argumento de desempenho.

### 3.3.1 Preparar decisões e ativos antes da visita

**Entrega obrigatória P8:** preparar a configuração pública normalizada e selecionar módulos próprios quando a configuração efetivamente mudar. O manifesto de ativos resultante permite ao PHP imprimir diretamente os arquivos necessários. Evitar uma cadeia adicional no navegador de buscar configuração, interpretá-la e só então descobrir o JS principal.

| Informação/trabalho | Momento de preparação | O que permanece durante a visita |
|---|---|---|
| Destinos habilitados, IDs públicos, associação de eventos, política de atraso | Gravação confirmada da configuração | Gates de consentimento/exclusão e relógio de cada destino |
| Normalização de regras estáticas, tabelas de consulta, textos e configuração visual pública | Gravação e mudança de idioma/configuração pertinente | Seleção da página/idioma e interações reais |
| Código próprio dos módulos selecionados | Módulos minificados no build do plugin; seleção e composição determinística no salvamento | Execução apenas dos módulos aplicáveis, com captura integral habilitada |
| Presença declarada de formulários, ofertas e CTAs | Salvamento de conteúdo, templates, menus e configuração relacionada | Complemento para conteúdo dinâmico e validação do contexto atual |
| Consentimento individual, sessão, atribuição da visita, teste, audiência, tokens e estado de formulário | Dependem da navegação e do servidor | Continuam dinâmicos, com as validações atuais |

A configuração pública será uma projeção com campos explicitamente permitidos. Não serializar integralmente o snapshot interno de options; segredos, tokens de API, nonces, dados de visitantes e flags individuais ficam fora dos arquivos compartilhados. Validação de formulário e autorização continuam no servidor.

Arquitetura proposta: bootstrap pequeno; runtime comum cacheável; configuração pública e adaptadores próprios selecionados por configuração/perfil. Os módulos são preparados no build do pacote. O salvamento em PHP monta dados e, quando vantajoso, compõe módulos previamente preparados; não exige Node, compilador JavaScript ou execução de comandos na hospedagem. Não copiar SDKs remotos de anúncios para dentro de um bundle gerado.

Gerar apenas um arquivo de configuração mantendo o mesmo bundle completo economiza serialização e repetição no HTML, mas não elimina o custo desse bundle. O ganho de bytes depende da seleção real de módulos e de evitar duplicação de dados. Preservar cache do runtime comum quando mudar somente um ID ou prazo. Evitar combinações por visitante, UTM ou sessão; limitar perfis à configuração estática e ao conteúdo aplicável.

**Ciclo de geração e publicação:**

1. Confirmar a gravação autorizada e calcular a revisão das entradas públicas relevantes. Mudança sem efeito público mantém os mesmos bytes e URL.
2. Consolidar as escritas da operação administrativa/MCP para gerar uma vez por revisão coerente. Tratar criação, alteração, remoção, importação, migração e atualização do plugin; gravação de eventos de medição não gera assets.
3. Produzir em diretório gerenciado fora da pasta substituída na atualização do plugin, com escopo por site. O conteúdo usa serialização segura, sem `eval` ou código arbitrário vindo de opções.
4. Validar arquivos e publicar o manifesto atomicamente, conferindo a revisão novamente. Uma geração antiga não pode substituir a configuração mais recente. Hash depende dos bytes, sem horário variável no conteúdo.
5. Coordenar a invalidação de HTML/cache com a publicação. URL com hash permite cache longo dos arquivos imutáveis quando os cabeçalhos efetivos da hospedagem forem confirmados. Conservar versões ainda referenciadas por HTML válido e limpar depois, em manutenção.
6. Em falha de geração/permissão, usar o runtime de reserva com a configuração atual e registrar separadamente configuração persistida e efeito pendente/falho. Recuperação ocorre fora da visita; o primeiro visitante não compila os ativos.

Para geração extensa e reaquecimento, aplicar o prazo aceito no 360: rotina até a próxima passagem de 15 min e efeito de configuração/llms/dados estruturados até 1 h, informado em `efeito_ate`. O passo leve de preparação continua no salvamento; trabalho volumoso vai para o executor corrigido pelo 361. Captura de lead, consentimento, cabeçalhos de segurança, redirecionamentos e retirada de conteúdo que deixou de ser público mantêm efeito imediato. O prazo de 1 h é de atualização da configuração pública/cache, separado do atraso de uma tag durante a visita.

Revogação de destino ou mudança restritiva precisa ser aplicada mesmo se a geração falhar; a reserva usa a configuração atual. Para atender HTML antigo, usar invalidação efetiva ou revalidação da política em tempo de execução. Reutilizar a classificação/revisão já necessária, sem criar uma busca extra de configuração para todas as visitas. Se a invalidação não for suficiente, o caminho Meta precisa obter a política atual antes do disparo; essa espera deve ser distinguida do atraso configurável e medida na entrega. Arquivo imutável não fornece garantia de revogação imediata por si só. A liberação exige provar o comportamento com HTML antigo, sem presumir que excluir um arquivo purga caches externos.

Metadados de presença de módulos precisam ser invalidados por alterações de página e de seus templates/menus. Shortcodes, blocos dinâmicos e filtros dependentes da requisição usam a reserva de renderização atual. Não pré-gerar HTML personalizado nem congelar valores que dependem de usuário, requisição ou permissão.

### 3.3.2 Atraso publicitário configurável

**Entrega obrigatória P5:** controles acessíveis no wp-admin e nas configurações MCP do Core, com schema, revisão/CAS, simulação e diagnóstico da política efetiva. Reusar/evoluir as opções atuais; nenhum atraso será fixado apenas no código.

| Controle | Comportamento proposto |
|---|---|
| Imediato | Solicitar carga/envio assim que permitido; padrão novo para preservar visitas curtas e padrão mantido da Meta |
| Atraso fixo | Valor configurável de 0 a 30 s; zero equivale a imediato |
| Ocioso com limite | Liberar em oportunidade ociosa com prazo máximo configurado e fallback quando a API não existir |
| Após interação com limite | Liberar por interação definida ou prazo máximo; não esperar indefinidamente quem não interage |
| Referência do prazo | Navegação ou elegibilidade, explicitadas. Configurações antigas mantêm referência `load` como comportamento legado identificado até sua edição/migração explícita |
| Conversão prioritária | Opção explícita para antecipar a carga ao ocorrer conversão elegível; não muda a definição da conversão nem contorna consentimento |
| Diagnóstico | Distinguir aguardando política, bloqueado por consentimento, solicitado, carregado e evento confirmado, quando houver prova |

O prazo é de agendamento, não garantia de conclusão de rede. Com referência na navegação, um prazo já vencido só libera quando a política autorizar; consentimento negado nunca é vencido por timer. Cancelar/revalidar agendas na revogação e tratar retorno de BFCache sem duplicação.

Meta e LinkedIn diretos terão controles próprios. GA4 e Google Ads compartilham o arquivo gtag: o primeiro destino elegível que precisar dele dispara o download único; configuração e eventos de Ads podem respeitar um prazo próprio, mas isso não posterga o arquivo já exigido pelo GA4. A interface deve mostrar o compartilhamento e seu efeito real sobre rede e coleta.

GTM exige controle por contêiner: o Core não garante prazos independentes para tags internas sem regras correspondentes no GTM. Evitar aplicar atrasos em dois lugares sem intenção. Atribuir claramente o dono da tag e preservar a conferência de duplicações entre emissão direta, GTM e tema.

Clarity e a coleta detalhada do Core ficam independentes dos atrasos de Ads. Para atender à cobertura inicial solicitada, o planejamento define início imediato após elegibilidade para replay habilitado; eventual configuração antiga de atraso/herança deve ter migração explícita e registrada para esse comportamento na 1.65.0, preservando consentimento e destinos desativados. Nenhuma configuração foi modificada nesta rodada documental.

### 3.4 Sequência de implementação e critérios por frente

| Frente | Trabalho e responsabilidade | Evidência de aceite |
|---|---|---|
| **P0 — linha de base** | Core + operador dos sites: registrar antes/depois em página de campanha com formulário, serviço com WhatsApp e artigo | HAR/trace, bytes, CPU e cobertura. Executar junto ao desenvolvimento; não transformar a versão em entrega apenas de diagnóstico |
| **P9 — executor e cron / pedido 361** | Core: atualização urgente, orçamento CLI configurável, rotinas por atraso, reservas compatíveis e diagnóstico de tarefas paradas | Migração confirmada na primeira CLI; 15 tarefas vencidas drenadas; prioridades, origem, concorrência e reserva validadas; aceite de 24 h pela frota |
| **P8 — preparação prévia** | Core: projeção pública, manifesto, composição de módulos preparados e geração no fluxo comum de gravação | Mesmo conteúdo gera mesmo hash; gravações wp-admin/MCP equivalentes; atomicidade, reserva, invalidação e ausência de geração na visita |
| **P1 — caminho inicial** | Core: separar bootstrap e módulos; acertar dependências defer; manter consentimento e Meta antecipado; iniciar classificação cedo | Menos código bloqueante; nenhum evento duplicado; cobertura de saídas em 0,5/1/3/5/10 s; primeiro clique funcional |
| **P2 — carga por necessidade** | Core: condicionar ofertas/CSS; separar análise do formulário e funcionalidade; retirar configurações desnecessárias do HTML | Páginas sem recurso não o baixam; blocos dinâmicos e formulário acima da dobra funcionam; sem deslocamento visual novo |
| **P3 — CPU e envio** | Core: estado incremental de formulário, geometria reaproveitada, observadores compartilhados, agenda e transporte comuns | Menos CPU/POSTs com catálogo, campos, horários, granularidade, recibos e deduplicação preservados |
| **P4 — servidor e cache / 354(f)(g)** | Core: CTA uma vez por fragmento, eliminar abertura de catálogo na página e registrar sua causa; hash de ativos e perfil de contexto/ingestão | Paridade das 64 fixtures e novos casos aninhados; sem catálogo completo na página; Site-Teste comparativo ≤100 ms e fator3.com.br próprios ≤100 ms; cache compatível |
| **P5 — atraso configurável** | Core: controles por destino/canal, compatibilidade do legado e independência de coleta/replay. Campanhas escolhe os valores | Modos, prazos, zero/imediato, consentimento, conversão prioritária, gtag compartilhado e GTM validados; sem amostragem |
| **P6 — homologação** | Core: instalação limpa e atualização 1.64 → 1.65, site real e combinações afetadas | Consentimento, revogação, cache, modo teste, BFCache, acessibilidade, formulários, WhatsApp e Pixel/CAPI sem regressão |
| **P7 — liberação** | Core prepara fonte/instalador/relatório; operador conduz ativação gradual e reversão | Artefatos e hashes finais, evidência vinculada à versão e acompanhamento por coorte |

P0 acompanha o desenvolvimento. A ordem prioritária passa a ser **P9 (361), P4 (354), P8 e P1–P3/P5, seguidas de P6/P7**, preservando os códigos das frentes. A geração prévia depende da capacidade e da confiabilidade do executor quando exigir recuperação ou trabalho assíncrono. A semântica das opções atuais `f3base_google_carregamento` e `f3base_carregamento_destinos` deve ser evoluída com compatibilidade e migração documentada. Os parâmetros de Ads preservam as escolhas existentes; a independência/início cedo do replay segue a decisão explícita da revisão 2.

**Mínimo para declarar a versão entregue:** correção funcional do 361, processamento único de CTA e tratamento da abertura do catálogo; geração prévia operacional; módulos públicos selecionados conforme configuração/página; retirada dos bundles pesados síncronos com captura inicial preservada; otimizações de formulário/rolagem provadas por equivalência; atrasos configuráveis; cache e reserva funcionais. Uma entrega contendo somente novos medidores não atende ao pedido. Aceites de campo ainda não observados serão identificados como pendentes, sem declarar fechamento dos pedidos pela frota.

Reduzir número de arquivos é objetivo secundário ao caminho crítico e ao trabalho executado. Não juntar todos os módulos em um pacote que obrigue o artigo a baixar funcionalidades de formulário. Avaliar o ganho de cada agrupamento por rede e cache. Compressão reduz transferência, mas não reduz por si só o código que o navegador interpreta e executa.

No PHP, implementar o processamento único solicitado no 354(f), reaproveitando as fixtures da 1.64.0 e ampliando-as conforme a seção 3.7. Evitar cache de HTML personalizado ou uma mudança que deixe cabeçalho, menu e CTA dinâmico sem marcação. Medir também classificação e ingestão: um POST a menos não é vantagem se o novo endpoint fica mais caro que a soma substituída.

### 3.5 Orçamentos candidatos e validação

Os orçamentos de front-end abaixo são **metas propostas de engenharia**, não resultados nem previsões de redução de LCP. Os critérios identificados pelos pedidos 354, 360 e 361 são requisitos recebidos da frota. P0 fecha a matriz junto ao desenvolvimento. A cobertura integral prevalece: nenhum orçamento será atingido desativando detalhe/replay, amostrando visitas ou deslocando o início da captura. As metas de bytes serão recalibradas caso necessário e isso ficará explícito; essa possibilidade não flexibiliza os aceites da frota.

| Dimensão | Meta ou critério de aceite |
|---|---|
| JS síncrono próprio inicial | Até 3 KiB gzip incluindo bootstrap e sua configuração crítica; nenhum bundle pesado síncrono no head |
| JS próprio baixado nos primeiros 3 s | Até 20 KiB comprimidos em artigo sem formulário; até 30 KiB em página com formulário acima da dobra; bibliotecas locais incluídas |
| Arquivos próprios iniciais | Alvo de até três recursos JS nesse intervalo; aceitar divisão adicional quando o teste demonstrar vantagem de cache ou necessidade |
| CPU própria | Nenhuma tarefa própria acima de 50 ms no dispositivo/perfil móvel fixado; comparar também CPU total em 0–3 s, 0–10 s e visita completa |
| Transporte básico | Até três POSTs regulares nos primeiros 10 s por navegação elegível; encerramento, retentativas e contatos contabilizados separadamente |
| Início da coleta | Despachar chegada assim que elegível, sem aguardar `load` ou interação; medir atraso até despacho e até confirmação separadamente |
| Geração PHP | Pedido 354: diferença com/sem Core e Pipedrive ≤100 ms em página/login no Site-Teste, menor de três amostras por condição; próprios ≤100 ms em fator3.com.br e korvena.com.br |
| Aceites restantes do 360 | Até 5 consultas Core além de options autoload, nenhuma consulta de estrutura/UPDATE, até 60 classes e descoberta Markdown ≤5 ms; login próprio ≤50 ms. Tempo não instrumentado é diagnóstico, sem teto de 20 ms |
| Executor CLI / 361 | Padrão 120 s, configurável entre 30 e 600 s com simulação; sem teto de três trabalhos; urgência e vencimento determinam a ordem |
| Experiência do site | LCP ≤ 2,5 s, INP ≤ 200 ms, CLS ≤ 0,1 no percentil 75, separados por móvel/desktop; analisar também o percentil 95 |

Os limites de bytes próprios não são orçamento total do site. P0 deve estabelecer teto adicional para fornecedores, imagens, fontes e HTML. Contabilizar todos os recursos até 10 s e até o fim da visita para revelar custo apenas deslocado no tempo. Não declarar ganho usando transferência zero de recurso de terceiro sem verificar restrições de Resource Timing ou cache.

**Laboratório:** iniciar com pelo menos 20 repetições por variante/cenário principal, alternando a ordem; ampliar quando a variabilidade impedir conclusão. Fixar dispositivo, limitação de CPU e rede, conteúdo e configuração. Separar cache do navegador e cache HTML. Exercitar consentimento pendente/permitido/negado/revogado, armazenamento indisponível, script bloqueado, rede lenta/offline, clique muito cedo, troca de aplicativo, BFCache e prerender quando suportados. Usar destinos de teste e não enviar conversões sintéticas às campanhas.

**Campo:** comparar variantes simultâneas e aleatórias dentro de página/canal/dispositivo, mantendo criativo e oferta comparáveis e coleta integral em ambos os grupos. A ativação gradual muda a versão executada, sem retirar diagnóstico de qualquer grupo. Dimensionar a duração pela taxa e volume reais; não encerrar após um número arbitrário de dias ou prometer equivalência com amostra estatística insuficiente. Atraso publicitário escolhido deve ter sua cobertura comparada separadamente.

**Critério conjunto de liberação:** melhoria verificável de carregamento/CPU; paridade determinística de contatos, consentimento e deduplicação nos testes; cobertura inicial sem regressão inexplicada; nenhuma queda além da margem previamente acordada em contatos aceitos por visita elegível. PageView enviado, SDK carregado e Lead aceito pelo servidor são evidências distintas.

**Regressões específicas da nova arquitetura:** mesmos eventos/campos/horários nos roteiros de rolagem, seção, fricção e formulário; replay iniciado cedo em todas as visitas de teste elegíveis; nenhuma herança de atraso de Ads no replay; perfis com recursos dinâmicos; alteração de configuração via wp-admin e MCP; criação/remoção/importação; duas gravações concorrentes; geração sem permissão de disco; arquivo ausente; HTML em cache com revisão anterior; revogação e mudança de ID durante falha; atualização do plugin e reversão; mesma configuração sem recompilar; ausência de credenciais/identificadores pessoais nos ativos públicos. Não contar redução de eventos como ganho de CPU.

### 3.6 Como investigar as saídas sem distorcer a conclusão

Produzir distribuição de tempo visível observado em faixas 0–1, 1–3, 3–5, 5–10 e acima de 10 s, distinguindo navegação seguinte, ocultamento, retorno e fim desconhecido. Não transformar ausência de evento final em tempo zero nem assumir que a pessoa saiu definitivamente ao trocar de aba. INP indisponível por falta de interação também não é INP zero.

Cruzar essa distribuição com primeira pintura, atraso da classificação, erros técnicos, dispositivo/navegador, página, origem/campanha permitida e versão do coletor. Exibir quantas observações ficaram incompletas e quantas não eram elegíveis. Comparar requisições de documento em registros agregados de servidor/CDN quando já disponíveis e autorizados; cache pode impedir que o PHP veja a visita. Cliques de anúncios não equivalem automaticamente a documentos carregados ou sessões.

Se a “taxa de saída” usada hoje vier da taxa de rejeição do GA4, documentar a definição: ela depende de sessão engajada, incluindo duração, evento principal ou múltiplas visualizações. Manter a nova investigação de visitas curtas separada dessa definição. Os marcos técnicos não devem virar conversões nem engajamento artificial para melhorar um indicador.

Correlação entre página lenta e saída não comprova que a lentidão causou a saída: canal, intenção, dispositivo e conexão podem influenciar os dois. O teste simultâneo ajuda a separar os efeitos. Medir apenas quem esperou o SDK carregar produz viés de sobrevivência; escolher a amostra só após interação produz outro viés. Informar perdas e incerteza é parte do resultado.

### 3.7 Pedidos da frota incorporados em 31/10/2026

#### Pedido 361 — prioridade inicial e aceite obrigatório

**Problema confirmado no código:** o deslocamento das rotinas para 96 passagens CLI diárias manteve o limite de três trabalhos de manutenção por passagem. Isso impõe um teto nominal de 288 trabalhos por dia nesse orçamento, antes das limitações de duração, repetição e falha. Não é contagem de todos os callbacks nem dos urgentes. O documento da frota relata migrações retidas e 8–15 tarefas vencidas após intervenção. A consequência para este plano é direta: adicionar geração assíncrona de ativos a esse executor sem corrigir a capacidade ampliaria o atraso.

**Implementação prevista:**

1. Reclassificar `migracao` e `pos_atualizacao` como urgentes em todas as camadas de classificação e despacho. Rodar na primeira passagem/requisição adequada após a troca, antes das rotinas e fora da contagem de manutenção, respeitando a ordem migração → provas pós-atualização. Preservar travas, autorização, idempotência e limites de execução do ambiente; não deixar carga de atualização permanente na página estável.
2. Criar/evoluir option de orçamento CLI, com padrão **120 segundos**, faixa **30–600**, schema, revisão, simulação e leitura por wp-admin/MCP. A passagem registra o valor e a revisão usados. A mudança vale para a próxima passagem; não altera silenciosamente uma execução em andamento. A contagem de três trabalhos deixa de limitar CLI; web/HTTP/MCP mantêm orçamento próprio.
3. Drenar rotinas vencidas enquanto houver tempo, pela ocorrência mais antiga, com desempate estável. A ordenação interna já existente em `F3Base_Operacao::eventos()` é base a reutilizar; provar que ela também rege o caminho **nativo** de `wp cron event run --due-now`, não apenas o executor manual. Tratar intenções/reagendamentos sem reexecutar a mesma ocorrência nem permitir que uma tarefa que falha bloqueie todas as seguintes.
4. Conservar ocorrência e checkpoint quando faltar tempo; registrar causa, atraso e próxima elegibilidade. Aumento de capacidade não muda cotas externas, política de retentativa ou entrega de contatos. Proteger tarefas urgentes e a continuidade após falha.
5. Ampliar `f3base/resumo-operacional-ler` com total de vencidas, atraso máximo, tarefas paradas agrupadas por causa, orçamento configurado/consumido e referências ao detalhe existente. Respeitar os 4096 bytes, a omissão explícita e a autorização administrativa. Diferenciar orçamento, reserva concorrente, recuperação, recuo e falta de configuração; não ocultar causas para aparentar saúde.

**Riscos técnicos identificados na inspeção:** `F3Base_Execucoes::dona()` e a recuperação de ocorrências usam expiração de 180 s; `F3Base_Operacao` também declara `LEASE_SEGUNDOS=180`. Um orçamento de até 600 s exige ajustar a duração/renovação das reservas e a prova de atividade para impedir que uma tarefa ainda ativa seja retomada por outro processo. Revisar também `com_prioridade()` e os filtros `http_request_args`/`pre_http_request`: o limite deve permanecer no trabalho Core pertinente, sem vazar como bloqueio para outro plugin ou sobreviver ao encerramento da passagem. São riscos inferidos a partir do código, não duplicações observadas nesta rodada.

O PHP CLI tem limite de execução padrão diferente do web, mas o orçamento próprio do Core continua necessário; verificar ainda o timeout efetivo do comando/hospedagem. Não elevar limites globais do servidor como substituto da correção. O heartbeat CLI recente prova passagem, não que a fila foi drenada: apresentar os dois estados separadamente.

**Provas de aceite planejadas:**

- No Site-Teste, atualizar diretamente 1.64 → 1.65 e confirmar a troca na primeira passagem CLI real, com diário e pós-atualização; usar também um cenário em que a primeira entrada após a troca é web. Executar o comando nativo, sem tratar `f3base/executar-pendentes` ou PHP com flag simulada como prova equivalente.
- Preparar 15 rotinas vencidas e executáveis, de custo conhecido dentro do orçamento de teste; uma passagem CLI deve esvaziá-las, na ordem definida, sem remoção artificial ou duplicação. Incluir mais de três ocorrências para detectar o limite antigo.
- Exercitar limites 30/120/600, simulação sem escrita, revisão concorrente, vencimento de orçamento, retomada, dois processos concorrentes e tarefa ativa por mais de 180 s com relógio controlado em teste local. Uma tarefa longa não pode ser apropriada por outro processo apenas porque a reserva antiga expirou.
- Com CLI recente, HTTP executa urgentes e não executa rotinas. Sem CLI por mais de 1 h, comprovar a reserva já prevista no 360 e seu retorno ao modo protegido após nova CLI.
- Nos 12 sites, a frota confere após **24 h de observação pós-liberação**: nenhuma espera persistentemente parada por `orcamento_esgotado` e nenhuma rotina com origem `http_cron` enquanto o heartbeat CLI está válido. Não apagar histórico de orçamento esgotado para satisfazer a conferência. Essa janela não foi executada nem agendada nesta rodada.

#### Pedido 354(f) — CTA uma vez por fragmento

Concentrar a marcação no fragmento completo de nível apropriado, preservando o tratamento específico do template-part de cabeçalho. Evitar reprocessar em cada ancestral e depois no `the_content` o trecho já tratado. Usar contexto de renderização e controle local à requisição; uma chave baseada só no HTML é insuficiente quando a superfície é diferente.

Reexecutar as 64 comparações existentes e acrescentar grupos profundamente aninhados, cabeçalho/menu reutilizado, fragmentos iguais em superfícies diferentes, filtros que acrescentam CTA depois da renderização, shortcodes e conteúdo dinâmico. Preservar o HTML final e a classificação de superfície/destino. Medir chamadas, bytes processados e tempo do parser; não aceitar simplesmente remover o filtro ou pular marcação de conteúdo tardio.

Aceite: protocolo comparativo do 354 no Site-Teste e tempo próprio ≤100 ms na página de fator3.com.br. A reprodução local deve incluir uma página com aninhamento e contatos representativos; uma página simples não reproduz o caso de 424 callbacks informado pela frota.

#### Pedido 354(g) — catálogo completo fora da página anônima

Rastrear a primeira abertura do catálogo completo no perfil público: motivo/entrada, hook, chamador e arquivo/linha relativos, com contagem de recorrências. Coletar uma trilha curta sem argumentos/segredos e somente quando ocorrer a abertura, para limitar o custo. Expor em `f3base/desempenho-ler`, preservando autorização.

Corrigir os caminhos indevidos por carregamento sob demanda ou leitura da configuração já preparada. O registro do motivo é diagnóstico de falha; o aceite continua exigindo **nenhuma abertura do catálogo completo na página anônima**. Testar cache frio/quente, formulário presente/ausente e a primeira requisição após atualização, distinguindo o trabalho excepcional da migração do perfil público estável.

#### Pedido 360 — critério corrigido e responsabilidades

O anexo declara os itens (1)–(8) entregues na 1.64.0. Esta versão preserva esses mecanismos e conclui as correções relacionadas aos pedidos 354/361. O teto de **20 ms não instrumentados está retirado**: a janela continua exposta como diagnóstico, pois inclui WordPress, tema e acompanhantes. Valem o comparativo do 354 e os limites específicos do Core indicados na seção 3.5.

Permanecem com a frota os aceites de campo: contagem diária de HTTP cron, lead de teste entregue em segundos, post novo no mapa em até 1 h e retirada imediata de conteúdo que deixou de ser público. A versão precisa cobrir esses caminhos na regressão do pacote. Para teste real de Pipedrive, a entrada determina **ctooffice.com.br e korvena.com.br**, com marca e homologação de teste; Site-Teste permanece para os demais aceites. Esta revisão não realizou contatos, envios ou alterações nesses sites.

As regras operacionais que variam por site/tempo, incluindo orçamento CLI, prazos e atrasos de tags, ficam em configuração com revisão e simulação. O plano mantém fora de escopo os itens explicitamente rejeitados no anexo: DNS por consulta reversa/direta sem faixas publicadas, canário diário do lead e marcos operacionais automáticos. A regressão sob demanda não cria essas rotinas.

## 4. Instalação e prontidão

Não há instalador 1.65.0. A revisão 1 consultou o Site-Teste de forma somente leitura; as revisões 2 e 3 examinaram o plano atual e a fonte-base, e a revisão 3 incorporou o novo documento da frota. Nenhuma delas trocou plugins ou configurações, disparou campanha ou instalou auxiliar. O último estado observado diretamente permanece na 1.64.0; a frota informa essa mesma versão nos 12 sites. Não houve nova leitura remota nas revisões 2 e 3.

A implementação futura deve preservar slug, basename, namespaces e opções existentes. A validação deve usar instalador fechado e conferir HTML real, não apenas argumentos de `wp_enqueue_script`: o WordPress considera a árvore de dependências ao aplicar a estratégia. A convivência precisa ser exercitada com cache/tema e com as tags efetivamente autorizadas do cenário.

O proprietário das páginas deve selecionar as URLs e configurações representativas na etapa P0. O Site-Teste atual é adequado para regressão funcional, mas insuficiente para estimar sozinho o custo publicitário de produção.

## 5. Banco, compatibilidade e reversão

Nenhum dado ou schema foi alterado. A proposta prioriza reutilizar eventos, filas, ocorrências e recibos existentes. Campos adicionais de revisão de ativos, orçamento de passagem, cobertura e tempos técnicos, se necessários, devem ser aditivos, limitados e documentados. Não há novo mecanismo de amostragem. O contrato administrativo futuro só será versionado quando a mudança real estiver definida. O manifesto gerado é um derivado reconstruível, não a fonte de verdade das configurações. Não recriar ou apagar intenções pendentes para migrar o executor; compatibilizar reservas e histórico durante atualização/reversão.

Prever desligamento dos perfis experimentais sem perder contatos ou esvaziar filas pendentes. Reversão de código deve ser testada junto ao schema efetivamente produzido; restaurar o ZIP anterior não desfaz dados ou entregas externas. Para ativos com hash, manter disponibilidade dos arquivos referenciados por HTML ainda em cache ou fazer transição comprovadamente compatível.

## 6. Pendências e responsáveis

| Pendência | Responsável | Efeito |
|---|---|---|
| HAR/CPU/CWV em páginas representativas e custo efetivo dos fornecedores | Core + operador dos sites | Necessário para ordenar ganho real e fechar orçamentos |
| Proprietários de tags e possíveis duplicações em GTM/tema | Operador de campanhas + Core | Não remover emissor com base apenas em IDs coincidentes |
| Fonte e definição da taxa de saída atual | Operador de análise + Core | Necessário para uma comparação válida com as faixas de tempo visível |
| Cobertura integral de detalhe/replay | Decisão do usuário preservada da revisão 2; Core implementa e comprova | Não depende de novo aceite de amostragem; conservar detalhe para todas as visitas elegíveis |
| Executor e atualização urgente / 361, frente P9 | Core; frota confirma 24 h nos 12 sites | Primeira prioridade; orçamento 120 s configurável, drenagem e concorrência comprovadas |
| CTA e catálogo / 354(f)(g), frente P4 | Core; frota confere fator3.com.br | HTML equivalente, catálogo fora da página, motivo diagnosticável e próprios ≤100 ms |
| Implementação da geração prévia, módulos e otimizações P1–P5/P8 | Core | Obrigatória na 1.65.0; execução assíncrona depende do executor corrigido |
| Valores dos atrasos por destino/canal | Campanhas configura; Core entrega os controles | Imediato disponível; nenhum atraso obrigatório para financiar a redução de custo |
| Invalidação em cache real, concorrência e reserva de geração | Core + operação | Aceite técnico da geração prévia; publicação de ativos não prova atualização de HTML cacheado |
| Aceites restantes 354/360 | Core + operação/frota | Comparativo e provas de campo pendentes; teto de 20 ms não instrumentados retirado |
| Instalação, atualização, navegador real e homologação externa da futura versão | Core e responsáveis pelos ativos | Ainda não executados para 1.65.0 |

## 7. Credenciais e efeitos externos

Nenhuma nova credencial foi solicitada ou alterada. Identificadores de conta/projeto retornados no diagnóstico não foram reproduzidos neste relatório. A consulta não chama fornecedores nem prova entrega nas plataformas. Não houve alterações em anúncios, orçamento, audiência ou GTM.

## 8. Artefatos e rastreabilidade

Esta rodada entrega o presente relatório de planejamento. Os ZIPs a seguir são a **base 1.64.0 inalterada**, com tamanho e SHA-256 reconferidos, e não uma implementação da 1.65.0.

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| `base-site-core-fator3-1.64.0-instalador.zip` | 3020630 | `e8c34d1cfbd347f6947e4e208fed92c11579c735f843d6c2e002c4fe29ce6588` |
| `base-site-core-fator3-1.64.0-fonte.zip` | 6357649 | `651725d756e30c022d3460f17d03da7161fc833138e8659ec2869b9ce2fe3df5` |

- [base-site-core-fator3-1.64.0-instalador.zip](https://chatgpt.com/library?file_id=libfile_718aea46c4848191b52439709e4af678&account_id=personal)
- [base-site-core-fator3-1.64.0-fonte.zip](https://chatgpt.com/library?file_id=libfile_a7d0659ae7d48191a675e6f352685bc0&account_id=personal)
- [base-site-core-fator3-1.64.0-relatorio.md](https://chatgpt.com/library?file_id=libfile_c2ab8470a22c8191afb2c0ac4f54d275&account_id=personal)
- [Fator3 Site Core(20261031-123104).md — pedidos recebidos](https://chatgpt.com/library?file_id=libfile_2c82b08442848191b60092a1c0d66961&account_id=personal)

Reprodução do inventário: ler os nove `assets/*.min.js` públicos e `assets/vendor/web-vitals.js` do instalador; contar bytes; comprimir cada arquivo com `gzip.compress(dados, compresslevel=9, mtime=0)`; somar separadamente. Comparar com a página real antes de usar o inventário como orçamento de transferência.

### Referências técnicas oficiais consultadas em 31/10/2026

- [WordPress — wp_enqueue_script e estratégias/dependências](https://developer.wordpress.org/reference/functions/wp_enqueue_script/).
- [web.dev — Web Vitals e limites no percentil 75](https://web.dev/articles/vitals).
- [web.dev — otimização de INP e trabalho na thread principal](https://web.dev/articles/optimize-inp).
- [MDN — sendBeacon, limites, visibilidade e encerramento](https://developer.mozilla.org/en-US/docs/Web/API/Navigator/sendBeacon).
- [MDN — Resource Timing e interpretação de transferSize](https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming/transferSize).
- [Google — Measurement Protocol e relação com tagging](https://developers.google.com/analytics/devguides/collection/protocol/ga4).
- [Google — consentimento antes dos comandos de medição](https://developers.google.com/tag-platform/security/guides/consent).
- [Google Analytics — sessão engajada e taxa de rejeição](https://support.google.com/analytics/answer/12195621?hl=en).

- [WordPress — notificação após gravação bem-sucedida de opção](https://developer.wordpress.org/reference/hooks/updated_option/).
- [MDN — cache HTTP e arquivos imutáveis com URL versionada](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Caching).
- [WordPress — execução nativa de eventos cron vencidos por WP-CLI](https://developer.wordpress.org/cli/commands/cron/event/run/).
- [PHP — max_execution_time e configuração CLI](https://www.php.net/manual/en/info.configuration.php#ini.max-execution-time).

As referências sustentam os mecanismos e limites descritos. A arquitetura de geração e os orçamentos de front-end são propostas de engenharia específicas deste plano. Os parâmetros 120 s/30–600 s e a remoção do teto de 20 ms vêm dos pedidos da frota recebidos, não dos fornecedores. A revisão 2 fixou cobertura integral e melhorias concretas; a revisão 3 acrescentou o 361, detalhou 354(f)(g), atualizou o aceite do 360 e priorizou a correção do executor.
