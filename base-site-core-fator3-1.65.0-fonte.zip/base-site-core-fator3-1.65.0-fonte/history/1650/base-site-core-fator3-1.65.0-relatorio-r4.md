# Entrega — Fator3 Site Core 1.65.0

**Revisão 4 — 31/10/2026. Candidata implementada e validada em bancada; homologação remota bloqueada. Não liberada para a frota.**

Esta revisão substitui o relatório de planejamento no acompanhamento corrente. Preserva o planejamento revisão 3 em `PLANO-1.65.0.md`, os registros históricos no fonte e o relatório separado de recuperação. O código recuperado já continha a implementação descrita abaixo. Nesta retomada, foram refeitas as provas pertinentes, corrigida a reprodução dos testes, recomposto o fonte e fechado este relatório. Não houve nova alteração do runtime: o instalador conserva o SHA-256 recuperado e foi novamente comparado, arquivo por arquivo, com o código entregue.

## 1. Bases aceitas

- Diretrizes do projeto: `01-instrucoes-agentes-plugins-fator3.md` e `02-padrao-desenvolvimento-plugins-fator3.md`, revisão 4 de 16/10/2026, lidas integralmente na recuperação; diretrizes relidas na retomada.
- Base imutável: Core 1.64.0, contrato 8.29.0. Instalador-base: 3020630 bytes, SHA-256 `e8c34d1cfbd347f6947e4e208fed92c11579c735f843d6c2e002c4fe29ce6588`.
- Alvo: Core 1.65.0, contrato administrativo 8.30.0. Mantidos slug/pasta `base-site-core-fator3`, basename `base-site-core-fator3/base-site-core-fator3.php`, namespaces, dados e contratos dos acompanhantes.
- Entrada de requisitos: `Fator3 Site Core(20261031-123104).md`, SHA-256 `a654c575bfb8d765c53f449a1816df37d7277837d6eb0b3be90df4bf523146e5`; pedidos 354, 360, 361 e planejamento revisão 3.
- Decisões preservadas: todas as visitas elegíveis, sem amostragem de 10%, sem retirar detalhe para atingir orçamento; Clarity independente do atraso publicitário. O teto de 20 ms não instrumentados foi retirado do aceite, mantendo-se a métrica diagnóstica.

As revisões 1–3 deste documento eram de planejamento. Revisão 4 registra implementação recuperada, provas novamente executadas, desvios de escopo e o impedimento remoto. Não converte previsões do plano em resultados.

## 2. Convivência e encaminhamentos

| Pacote | Versão | Evidência desta retomada |
|---|---|---|
| Fator3 MCP | 0.38.0 | Ativo na bancada de desempenho e no Site-Teste; transporte remoto usado para leituras e preparação de envio |
| Fator3 MCP Google | 0.24.0 | Ativo na bancada e no Site-Teste; sem envio comercial |
| Fator3 MCP Meta | 0.17.0 | Ativo na bancada e no Site-Teste; sem envio comercial |
| Fator3 MCP LinkedIn | 0.13.0 | Ativo na bancada e no Site-Teste; sem envio comercial |
| Fator3 MCP Pipedrive | 0.5.0 | Ativo no Site-Teste; não ativado no PHP 8.3.6 local, pois exige 8.3.36 |

Não se identificou mudança de contrato que exigisse desenvolvimento de outro pacote. Não foram alterados acompanhantes nem gerados encaminhamentos apenas para anunciar versão. A validação conjunta remota continua pendente, inclusive Pipedrive e o comparativo com/sem Core e Pipedrive. Esta conclusão não declara aceites de outro responsável.

## 3. Mudanças por pedido e evidência

### 361 — executor e atualização urgente

O orçamento CLI passa a ser configurável entre 30 e 600 segundos, padrão 120, pela opção `f3base_cron_cli_segundos`. A configuração administrativa continua com validação de capacidade e revisão. O orçamento web/MCP permanece em 30 segundos. A restrição a três rotinas não interrompe a drenagem CLI; prioridade e antiguidade ordenam o trabalho, respeitando orçamento, checkpoint e recuos. Migração e pós-atualização são urgentes e ordenadas antes da manutenção.

A reserva acompanha o orçamento restante, com mínimo de 180 segundos. O limite HTTP se aplica dentro do trabalho do Core, sem bloquear chamadas posteriores de outro plugin. O resumo operacional acrescenta vencidas, maior atraso e motivos de parada, mantendo o limite de 4096 bytes e omissão explícita.

Provas refeitas: comando nativo WP-CLI 2.12.0, 15 tarefas sintéticas drenadas em uma passagem, ordem da mais antiga, orçamento de 600 segundos, reserva superior a 600 e ocorrência compartilhada executada uma vez com dois processos concorrentes. Instalação e atualização confirmaram a migração na primeira passagem CLI. Esses callbacks sintéticos comprovam o executor; não comprovam entrega aos fornecedores ou funcionamento contínuo por 24 horas.

### 354 — CTA e catálogo público

O conteúdo final passa uma vez pelo parser de CTA; fragmentos fora desse fluxo conservam processamento próprio. A memoização é limitada e inclui configuração e superfície. Foram aprovadas 64 fixtures de equivalência e cenários adicionais de 30 níveis aninhados, conteúdo já processado, CTA acrescentado posteriormente e superfície de cabeçalho.

O diagnóstico de desempenho registra a primeira abertura indevida do catálogo completo, com hook/chamador/caminho relativo e sem argumentos. Na bancada de páginas estáveis: zero aberturas do catálogo, cinco consultas, nenhuma consulta de estrutura ou UPDATE, 55 classes, descoberta abaixo de 5 ms e tempo próprio abaixo de 100 ms. Isso não substitui o caso de fator3.com.br com 424 callbacks relatado pela frota, nem o comparativo remoto exigido pelo pedido.

### Ativos, carga inicial, coleta e anúncios

O salvamento prepara a projeção pública em arquivo por SHA-256, com temporário, rename, hash e manifesto revisionado. Tokens de visita, nonces e campos privados não entram no arquivo compartilhado. A visita estável não compila nem gera esses ativos. O zelador recupera falhas; arquivos substituídos são conservados por 30 dias para HTML antigo em cache. Falta de arquivo/manifesto ou divergência de versão usa configuração atual e scripts completos como reserva.

O pacote traz 32 composições de consentimento, contexto, tempo ativo e carregadores de fornecedores. Um bootstrap pequeno inicia a observação efêmera e a classificação; os scripts principais usam `defer`. Os handles existentes e dados específicos da página são preservados. O cliente de contatos recebe sete grupos de destinos/conversões, retirando a cópia do catálogo comportamental e dos tokens de resumo sem retirar eventos.

Os controles por destino oferecem imediato, atraso fixo, interação ou prazo, ocioso ou prazo, de 0 a 30 segundos; referência em navegação, elegibilidade ou `load` legado. Conversão prioritária é optativa e falsa por padrão. GA4/Ads compartilham o download gtag com agendamentos por destino. A migração põe Clarity em imediato, preservando os demais destinos; consentimento, exclusões, revogação e marca de teste prevalecem.

Formulários emitem CSS com o primeiro formulário renderizado. A análise reutiliza a lista de campos, invalida por mutação e lê valores atuais. Nos testes com 100 entradas, as varreduras caíram de 103 para 3, mantendo idêntico o evento final de abandono, inclusive limpeza programática, novo campo e renomeação. Os tempos de 157,14 ms para a base e 58,57 ms para a candidata são uma amostra de CPU em jsdom; não estimam o resultado em celulares.

Os testes DOM preservaram deduplicação, correspondência antes do Lead, token, recibos, sequência e restrições de elegibilidade. A classificação começou cedo e sua requisição foi reutilizada. Retentativa de token, confirmação e recuo após segundo 403 passaram no fonte e no minificado.

### Desvios e metas não comprovadas

- **P2 parcial:** ofertas continuam carregadas com a análise, inclusive quando não há oferta inicial no HTML. A API síncrona e a observação de inserções dinâmicas foram preservadas. A divisão em um arquivo tardio não foi implementada: o comportamento atual evita uma nova janela de perda de abertura/fechamento. Não declarar atendido o critério “páginas sem recurso não o baixam” para ofertas.
- A separação adicional entre análise e funcionalidade de formulário não foi demonstrada como uma entrega independente. Houve cache de campos e CSS condicionado, sem claim de todo o redesenho P2.
- Metas de 3 KiB gzip síncronos e 20/30 KiB nos primeiros três segundos não estão integralmente comprovadas. O somatório conservador dos scripts síncronos do cabeçalho foi 3089 bytes (17 acima de 3 KiB). Todos os downloads JS próprios da fixture somaram 36798 bytes gzip; não foi medida a janela dos primeiros três segundos.
- Não houve HAR/CPU/CWV de navegador real, teste de campanhas, confirmação de replay remoto, ensaio de margem de conversão ou prova de invalidação de CDN. A redução local de bytes não estabelece causalidade sobre saída de visitantes ou LCP.

### Comparação com HTML novamente gerado

A evidência antiga de HTML foi substituída para este comparativo porque ainda continha a configuração completa repetida em `f3baseLeadsDados.medicao`. O código recuperado já usava a projeção reduzida. O novo teste confere suas sete chaves e usa dependências realmente referenciadas no HTML gerado por cada versão.

| Métrica da mesma fixture de artigo | 1.64.0 | 1.65.0 |
|---|---:|---:|
| HTML sem compressão | 37245 bytes | 33717 bytes |
| HTML gzip estimado | 8835 bytes | 9488 bytes |
| Downloads próprios de JS | 8 | 6 |
| JS externo próprio, soma gzip | 38172 bytes | 36798 bytes |
| JS próprio síncrono no cabeçalho, soma gzip | 26129 bytes | 3089 bytes |
| HTML + JS externo, soma gzip | 47007 bytes | 46286 bytes |

Redução total estimada: **721 bytes, aproximadamente 1,5%**. A melhora maior está na redução do código síncrono, não no volume total frio. Gzip foi calculado offline por arquivo, nível 9, `mtime=0`; o somatório inline não reproduz a compressão conjunta do documento. Não inclui SDKs remotos, headers de transporte ou cache real. Evidência: `evidence/1650/transfer-comparison.json`; reprodutor: `tests/asset-transfer-1650.py`.

## 4. Instalação, prontidão e provas

### Pacote e bancada

O instalador contém 897 arquivos, dos quais 591 PHP passaram no lint em PHP 8.3.6. O runtime do fonte foi comparado byte a byte com esse ZIP. Mínimos exercitados: WordPress 7.1.2 e PHP 8.3.6; matriz adicional WordPress 7.1.4 com o mesmo PHP. MySQL descartável e transporte/e-mail externos bloqueados.

| Prova refeita | Resultado | Evidência no fonte |
|---|---|---|
| Configuração, ativos, CTA e executor | 31 verificações aprovadas | `evidence/1650/request-1650.json` |
| Gates administrativos e fronteiras | 5 aprovadas | `evidence/1650/guards-1650.json` |
| Equivalência CTA | 64 aprovadas | `evidence/1650/request-360-cta.json` |
| Proteção cron/fallback | 9 aprovadas | `evidence/1650/request-360-cron.json` |
| Documentação por API nativa WordPress | 1910 verificações; 169 documentos, 721 páginas | `evidence/1650/docs-1650.json` |
| Coleta e elegibilidade, fonte/minificado | 76 aprovadas | `evidence/1650/dom-1650.json` |
| Atrasos, Clarity, gtag e revogação | 28 aprovadas | `evidence/1650/delays-1650.json` |
| HTML WordPress executado em jsdom | 19 aprovadas; seis dependências defer | `evidence/1650/html-runtime.json` |
| Detalhe de abandono e custo de campos | 3 aprovadas; 103 → 3 varreduras | `evidence/1650/form-performance.json` |
| Recibos e renovação de token | 26 aprovadas | `evidence/1650/request-332-dom.json` |
| WP-CLI real, drenagem e concorrência | 15 tarefas; ocorrência concorrente única | `evidence/1650/native-cli-1650.json` |
| Limpa, atualização 1.64, repetição, desinstalação/reinstalação | Aprovadas no WP 7.1.4 e no piso 7.1.2, com o ZIP exato | `evidence/1650/native-cycles-1650.json` e `evidence/1650-min/native-cycles-1650.json` |

Nos ciclos, a desinstalação suspende trabalho pendente conforme o contrato; a reinstalação preserva esse estado e os dados. A comparação é feita com o estado previsto após desinstalação, não com uma expectativa incorreta de manter tarefas executáveis após removê-lo.

As páginas estáveis do candidato ficaram em 7,176 / 8,457 / 7,367 ms próprios; login em 0,232 / 0,387 / 0,148 ms. Cinco consultas na página, zero no login; nenhuma escrita/estrutura; 55 e 11 classes, respectivamente. Catálogo completo fechado e descoberta dentro de 5 ms. Esses números são locais, com tema sintético e sem Yoast/Pipedrive ativos. Não substituem o site real. O profiler conserva uma requisição de preparação após configurar a fixture, fora do orçamento estável, seguida de aquecimento e três amostras por rota. Evidências em `performance-1650.json` e `*-profile.json`.

### Documentação instalada e canal remoto

O instalador inclui especificação, configuração, contratos, operação e recuperação, notas `docs/RELEASE-1.65.0.md`, guia `docs/AGENTES-1.65.0.md` e índice `docs/DOCUMENTACAO.md`. A leitura paginada completa, hashes e permissões passaram pelas abilities nativas no WordPress descartável. A leitura completa pelo transporte MCP do **Site-Teste com 1.65.0** continua pendente porque a versão não foi instalada ali. Não confundir essa pendência com a prova local aprovada.

### Site-Teste: estado final e bloqueio

Origem: `https://fator3-teste-mcp-1.dreamhosters.com/`. WordPress 7.1.4, PHP 8.3.36. Core **1.64.0 ativo**, com todos os acompanhantes da seção 2 ativos; estado novamente consultado após cancelar o envio.

Antes da tentativa, três sondagens da 1.64.0 mediram 84,598 / 90,926 / 87,976 ms próprios na página e 4,775 / 4,673 / 5,111 ms no login. Página com três consultas e 60 classes; login sem consultas e 11 classes. São linha de base da versão anterior, não resultado da candidata e não comparação com/sem os dois plugins. GETs anônimos internos de página/login retornaram HTTP 200, com execução PHP nova confirmada. Não são prova de acesso externo por navegador.

O envio do ZIP foi iniciado pelo canal de partes, sem expor o Base64 na conversa. A revisão automática rejeitou a parte 10, exigindo autorização explícita do usuário para esse payload de código e esse destino. Foram reapresentados a diretriz do projeto, o plano de atualização e a identidade/licença do pacote; a rejeição foi mantida. O envio incompleto foi cancelado pela habilidade própria, que confirmou remoção das partes privadas. **Não houve finalize, ZIP de destino, instalação ou troca de versão.**

Não se tentou outro canal para contornar o bloqueio. Nenhuma credencial precisa ser fornecida. Próxima ação concreta, sujeita à aprovação explícita: enviar e instalar somente o instalador identificado na seção 8 nesse Site-Teste, com hash esperado, slug esperado, ativação e sobrescrita controladas, pré-imagem e sondagem do instalador; depois concluir a homologação remota. A frota e os sites de produção não estão incluídos nessa aprovação.

## 5. Banco, preservação e reversão

Sem novas tabelas ou colunas. A versão acrescenta preferência de orçamento CLI, manifesto/erro derivado dos ativos e marcador de atualização urgente. Contatos, filas, intenções e recibos não são apagados para migrar o executor. Os ciclos nativos verificaram preservação e repetição idempotente.

Rollback de código para 1.64.0 conserva dados e volta aos limites/políticas anteriores. Não restaurar o banco apenas para reverter este incremento. Preservar a guarda externa à pasta do plugin e conferir intenções/recibos antes de reprocessar. Invalidar HTML de cache após atualização ou troca de configuração; os ativos antigos são conservados por 30 dias, mas isso não comprova purga de cache externo.

## 6. Pendências e responsáveis

| Pendência real | Responsável | Condição de conclusão |
|---|---|---|
| Aprovação do envio/instalação no Site-Teste | Dono + Core | Autorização explícita para o ZIP desta entrega e destino indicado; revisão automática exige essa confirmação |
| Instalação, primeira passagem CLI e pós-atualização no ambiente remoto | Core | Troca para 1.65.0, diário nativo e pós-atualização confirmados; configurações preservadas |
| Comparativo 354 com/sem Core e Pipedrive | Core + operação | Três amostras por condição em página/login; diferença dos mínimos ≤100 ms |
| MCP documental e convivência reais da 1.65.0 | Core | Índice e leitura paginada completos; perfis/permissões; acompanhantes, tema e cache sem regressão |
| Ofertas condicionais e separação adicional P2 | Core | Implementar sem perda de eventos dinâmicos ou obter decisão explícita sobre o desvio; não encerrado nesta candidata |
| Bytes iniciais, HAR/CPU/CWV, saída em 0,5/1/3/5/10 s, BFCache e navegadores internos | Core + operador | Navegadores/dispositivos representativos, coleta integral, rede/caches reais e destinos de teste |
| Replay e fornecedores/campanhas | Operação de campanhas + Core | Confirmar início/cobertura e ausência de duplicação sem conversões sintéticas em campanhas reais |
| CTA/catálogo e tempo próprio em fator3.com.br/korvena.com.br | Frota + Core | Reproduzir páginas problemáticas e validar próprios ≤100 ms |
| Aceites 360 e 361 de campo | Frota | 24 h nos 12 sites após implantação autorizada; cron, filas, contatos e mapa nos prazos requeridos |

O pacote está pronto para a próxima homologação; **os pedidos 354/360/361 e a liberação para produção não estão encerrados**. A aprovação do envio remove o impedimento imediato, mas não substitui os aceites técnicos listados.

## 7. Credenciais e efeitos externos

Nenhuma credencial foi solicitada, alterada ou incluída nos artefatos. Não houve contatos reais, disparos a clientes, campanhas, gastos publicitários, alteração de GTM ou publicação em repositório. Os testes locais usam destinos sintéticos e bloqueio de HTTP/e-mail. As evidências remotas entregues contêm versões e diagnóstico técnico, sem valores de credenciais.

## 8. Arquivos finais e integridade

| Artefato | Bytes | SHA-256 |
|---|---:|---|
| `base-site-core-fator3-1.65.0-instalador.zip` | 4156410 | `f99d5cf933da2490baebe1d7fbe48d71a98d6b0ae00f51c0748267a471e8ed42` |
| `base-site-core-fator3-1.65.0-fonte.zip` | 7705753 | `b4647a8e12651ff5a9f972a3c314e37090cd4a40ffda529436f0e2bcdb5ad955` |

O instalador é o único ZIP instalável, com raiz `base-site-core-fator3/`. O fonte tem raiz `base-site-core-fator3-1.65.0-fonte/`, runtime em `work/plugin/`, build, testes, fixtures seguras, insumos, planejamento e evidências. Não contém laboratórios prontos, bancos, node_modules, ZIPs aninhados ou pacotes acompanhantes. `source-manifest.json` lista hashes dos arquivos. A cópia interna deste relatório é marcada como anterior ao fechamento do fonte; o hash final do fonte fica apenas neste relatório externo, evitando circularidade.

Links canônicos dos artefatos:

- [base-site-core-fator3-1.65.0-fonte.zip](https://chatgpt.com/library?file_id=libfile_de3594659a488191a8f7c092e3491310&account_id=personal)
- [base-site-core-fator3-1.65.0-instalador.zip](https://chatgpt.com/library?file_id=libfile_a1dbfc6131708191826a5bd1101d6265&account_id=personal)
- [base-site-core-fator3-1.65.0-relatorio.md](https://chatgpt.com/library?file_id=libfile_8ecce6b58e048191a442279f88cc6046&account_id=personal)
- [base-site-core-fator3-1.65.0-notas-da-versao.md](https://chatgpt.com/library?file_id=libfile_d4d9fe71ae0881919895385739e21e78&account_id=personal)
- [base-site-core-fator3-1.65.0-guia-agentes.md](https://chatgpt.com/library?file_id=libfile_07db9a5185748191adfc5724850dbcfb&account_id=personal)

O relatório de recuperação permanece como registro histórico separado. As notas e o guia reproduzem a documentação instalada; este relatório prevalece para o estado de validação e as pendências de conclusão.
