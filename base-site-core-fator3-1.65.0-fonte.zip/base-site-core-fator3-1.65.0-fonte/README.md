# Fator3 Site Core 1.65.0 — fonte

Runtime aplicado em work/plugin/base-site-core-fator3. Base 1.64.0 imutável; contrato 8.30.0. Consulte build/README.md para reproduzir, docs/DOCUMENTACAO.md no runtime para os contratos e o relatório externo da versão para identidades, provas e pendências. PLANO-1.65.0.md é o planejamento revisionado; RELEASE-1.65.0.md descreve o comportamento implementado.

O fonte não contém bancos, credenciais, laboratórios prontos, pacotes acompanhantes, node_modules ou ZIPs aninhados. Forneça os insumos originais especificados antes de executar testes. Scripts históricos permanecem identificados; sua existência não significa reexecução nesta entrega.

Estado em 31/10/2026: Core 1.65.0 instalado e ativo no Site-Teste após autorização explícita. Pós-atualização, saúde, leitura documental selecionada, passagem CLI e desempenho remoto verificados. Comparativo com/sem Core e Pipedrive: diferença dos mínimos de 59,600 ms na página e −13,257 ms no login, abaixo do limite de 100 ms. Consulte o relatório revisão 5 e evidence/1650 para método, provas e limites. Entrega com-pendencias: P2, matriz remota de permissões, navegadores/SDKs e aceites da frota permanecem abertos. Não implantar na frota como versão já homologada.
