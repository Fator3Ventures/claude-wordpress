/**
 * Sonda de JavaScript. Roda sob o Node de verdade e devolve JSON.
 *
 * Dois modos:
 *
 * - `lint <raiz>`: `node --check` em todo `.js`/`.mjs` da raiz. Analisar
 *   JavaScript com expressão regular de PHP seria inferência disfarçada de
 *   medição; quem analisa é o próprio motor.
 * - `extrator <raiz>`: exercita as funções PURAS de
 *   `includes/assets/implantador.js` — as mesmas do arquivo servido, extraídas
 *   dele em tempo de execução, nunca copiadas. A armadilha medida é que a
 *   resposta real de um erro fatal é "HTML + JSON": a página de erro do
 *   WordPress já saiu quando o `shutdown` roda, e o objeto está no FIM do corpo.
 *
 * Esta sonda nunca imprime estado nem conta: quem imprime e conta é `estado()`,
 * no PHP, em um lugar só.
 */

import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, extname } from 'node:path';
import { execFileSync } from 'node:child_process';

const EXCLUIDOS = [ 'suite/fixtures/', 'dist/' ];

function arquivos( raiz, extensoes ) {
	const saida = [];

	function andar( dir ) {
		let itens;

		try {
			itens = readdirSync( dir );
		} catch {
			return;
		}

		for ( const item of itens.sort() ) {
			const caminho = join( dir, item );
			const rel = relative( raiz, caminho ).split( '\\' ).join( '/' );

			if ( EXCLUIDOS.some( ( p ) => rel.startsWith( p ) ) ) {
				continue;
			}

			const st = statSync( caminho );

			if ( st.isDirectory() ) {
				andar( caminho );
				continue;
			}

			if ( extensoes.includes( extname( item ).toLowerCase() ) ) {
				saida.push( rel );
			}
		}
	}

	andar( raiz );

	return saida.sort();
}

function lint( raiz ) {
	const achados = [];
	const alvos = arquivos( raiz, [ '.js', '.mjs' ] );

	for ( const rel of alvos ) {
		try {
			execFileSync( process.execPath, [ '--check', join( raiz, rel ) ], { stdio: [ 'ignore', 'ignore', 'pipe' ] } );
		} catch ( e ) {
			const detalhe = String( e.stderr || e.message ).split( '\n' ).filter( Boolean ).slice( 0, 3 ).join( ' | ' );
			achados.push( rel + ': ' + detalhe );
		}
	}

	return { achados, medidas: alvos.length };
}

/**
 * Extrai as duas funções puras do arquivo REAL e as exercita.
 *
 * Teto e piso na mesma sonda: o que precisa achar, acha; o que precisa devolver
 * `null`, devolve — em vez de fingir sucesso sobre um corpo truncado.
 */
function extrator( raiz ) {
	const alvo = join( raiz, 'includes/assets/implantador.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'includes/assets/implantador.js ausente na raiz varrida' ] };
	}

	const inicioTentar = fonte.indexOf( '\tfunction tentarAnalisar(' );
	const fimTentar = fonte.indexOf( '\t/**', inicioTentar );
	const inicioExtrair = fonte.indexOf( '\tfunction extrairJson(' );
	const fimExtrair = fonte.indexOf( '\t/**', inicioExtrair );

	if ( inicioTentar < 0 || inicioExtrair < 0 ) {
		return { achados: [ 'as funções puras não foram encontradas no arquivo real (contrato de extração quebrado)' ] };
	}

	const codigo =
		'let sentinela = "";\n' +
		fonte.slice( inicioTentar, fimTentar ) + '\n' +
		fonte.slice( inicioExtrair, fimExtrair ) + '\n' +
		'return { extrairJson, definir: ( s ) => { sentinela = s; } };';

	let extrairJson;
	let definir;

	try {
		( { extrairJson, definir } = new Function( codigo )() );
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	const SENT = '<<<F3BASE-JSON>>>';
	const jsonOk = '{"ok":true,"lote":3,"estado":"OK"}';
	const paginaDeErro =
		'<!DOCTYPE html><html><body><h1>Erro crítico { do WordPress }</h1>' +
		'<p>{"isto":"nao e a resposta"}</p></body></html>' +
		'\n' + SENT + '\n' + '{"ok":false,"fatal":{"linha":1624}}';

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	definir( SENT );
	afirmar( extrairJson( SENT + '\n' + jsonOk )?.lote === 3, 'teto: resposta limpa com sentinela não foi lida' );
	afirmar( extrairJson( paginaDeErro )?.fatal?.linha === 1624, 'teto: HTML+JSON — não achou o objeto no FIM do corpo' );

	definir( '' );
	afirmar( extrairJson( paginaDeErro )?.fatal?.linha === 1624, 'teto: sem sentinela, a varredura de trás para frente falhou' );

	definir( SENT );
	afirmar( extrairJson( '<!DOCTYPE html><html><body>Sem JSON nenhum</body></html>' ) === null, 'piso: corpo sem JSON não devolveu null' );
	afirmar( extrairJson( SENT + '\n{"quebrado": ' ) === null, 'piso: JSON truncado depois da sentinela fingiu sucesso' );
	afirmar( extrairJson( '[1,2,3]' ) === null, 'piso: array no corpo passou por objeto de resposta' );

	return { achados };
}

/**
 * Extrai UMA função pura do arquivo real, pelo contrato de fatiamento.
 *
 * O contrato é o mesmo do extrator: a função mora a um nível de indentação e é
 * seguida por um bloco `/**`. Copiar o corpo para dentro desta sonda provaria
 * que a cópia funciona, não que o cliente funciona.
 */
function fatiar( fonte, nome ) {
	const inicio = fonte.indexOf( '\tfunction ' + nome + '(' );

	if ( inicio < 0 ) {
		return null;
	}

	const fim = fonte.indexOf( '\t/**', inicio );

	return fonte.slice( inicio, fim < 0 ? fonte.length : fim );
}

/**
 * BANCADA DE DOM: o cliente REAL, rodado de ponta a ponta sob o Node.
 *
 * Não é uma cópia nem um recorte. O arquivo servido é avaliado inteiro contra um
 * DOM de mentira — o mínimo que ele toca — e uma resposta de lote já concluída.
 * O que sai daqui é a árvore que o operador veria, e é sobre ela que a ordem no
 * DOM é medida. Medir a ordem lendo o código-fonte com expressão regular
 * responderia "o `appendChild` está escrito depois", que é outra pergunta.
 *
 * `fetch` devolve um THENABLE SÍNCRONO de propósito: uma Promise real adiaria a
 * continuação para o microtask, e a sonda teria de virar assíncrona para ver a
 * árvore pronta. O cliente não sabe a diferença — ele chama `.then().then()` e
 * `.catch()`, e é isso que a bancada oferece.
 *
 * @param {string} fonte Código do cliente, como ele viaja no pacote.
 * @return {Object} A árvore montada e o que a execução deixou nela.
 */
function bancadaDeDom( fonte ) {
	const focados = [];

	class Elemento {
		constructor( tag ) {
			this.tagName = String( tag ).toUpperCase();
			this.filhos = [];
			this.atributos = {};
			this.proprioTexto = '';
			this.className = '';
			this.hidden = false;
			this.recebeuFoco = false;
		}

		setAttribute( nome, valor ) {
			this.atributos[ String( nome ) ] = String( valor );
		}

		getAttribute( nome ) {
			return Object.prototype.hasOwnProperty.call( this.atributos, String( nome ) )
				? this.atributos[ String( nome ) ]
				: null;
		}

		appendChild( filho ) {
			this.filhos.push( filho );

			return filho;
		}

		removeChild( filho ) {
			this.filhos = this.filhos.filter( ( c ) => c !== filho );

			return filho;
		}

		addEventListener() {}

		click() {}

		focus() {
			this.recebeuFoco = true;
			focados.push( this );
		}

		set textContent( valor ) {
			this.proprioTexto = String( valor );
			this.filhos = [];
		}

		get textContent() {
			if ( this.proprioTexto !== '' ) {
				return this.proprioTexto;
			}

			return this.filhos.map( ( f ) => f.textContent ).join( '' );
		}

		set innerHTML( valor ) {
			if ( String( valor ) === '' ) {
				this.filhos = [];
			}
		}

		get innerHTML() {
			return '';
		}

		descendentes( tag ) {
			const alvo = String( tag ).toUpperCase();
			const saida = [];

			for ( const filho of this.filhos ) {
				if ( filho.tagName === alvo ) {
					saida.push( filho );
				}

				saida.push( ...filho.descendentes( alvo ) );
			}

			return saida;
		}

		querySelectorAll( seletor ) {
			return this.descendentes( seletor );
		}
	}

	const raizFalsa = new Elemento( 'div' );

	raizFalsa.setAttribute( 'data-endpoint', 'https://exemplo.test/wp-admin/admin-post.php' );
	raizFalsa.setAttribute( 'data-nonce', 'nonce' );
	raizFalsa.setAttribute( 'data-modo', 'aplicacao' );
	raizFalsa.setAttribute( 'data-execucao', 'exec1' );
	raizFalsa.setAttribute( 'data-total', '1' );
	raizFalsa.setAttribute( 'data-estados-aplicacao', 'PRONTO,EXECUTANDO,SUCESSO_APLICACAO,FALHA_PARCIAL,FALHA,REVERTIDO,BLOCKED' );
	raizFalsa.setAttribute( 'data-fecho-reserva', 'BLOCKED' );

	const resposta = {
		ok: true,
		concluido: true,
		parou: false,
		lote: 0,
		total: 1,
		estado: 'OK',
		etapa: 'entrega',
		rotulo: 'entrega',
		motivo: 'entregáveis conferidos',
		aplicacao: 'SUCESSO_APLICACAO',
		checkpoint: true,
		checagens_falha: 0,
		checagens_blocked: 2,
		unidades_falha: 0,
		unidades_blocked: 1,
		checagens_resumidas: 41,
		checagens_nomes: { BLOCKED: [ 'privacidade.controlador_identificado', 'cadencia.mecanismo_declarado' ] },
		unidades_nomes: { BLOCKED: [ 'entrega' ] },
		checagens: []
	};

	function jaResolvido( valor ) {
		return {
			then( aceito ) {
				const seguinte = aceito( valor );

				return ( seguinte && typeof seguinte.then === 'function' ) ? seguinte : jaResolvido( seguinte );
			},
			catch() {
				return this;
			}
		};
	}

	const documento = {
		title: 'Implantação',
		body: new Elemento( 'body' ),
		getElementById: ( id ) => ( 'f3base-imp' === id ? raizFalsa : null ),
		createElement: ( tag ) => new Elemento( tag )
	};

	const janela = {
		fetch: () => jaResolvido( {
			status: 200,
			headers: { get: () => 'application/json' },
			text: () => jaResolvido( JSON.stringify( resposta ) )
		} ),
		setTimeout: () => 0
	};

	const executar = new Function( 'document', 'window', 'FormData', 'Blob', 'URL', fonte );

	executar(
		documento,
		janela,
		class { append() {} },
		class {},
		{ createObjectURL: () => 'blob:x', revokeObjectURL: () => {} }
	);

	const ordem = raizFalsa.filhos;
	const tabela = ordem.findIndex( ( n ) => 'TABLE' === n.tagName );
	const fim = ordem.findIndex( ( n ) => String( n.className ).includes( 'f3base-imp-encerramento' ) );
	const topo = ordem.findIndex( ( n ) => String( n.className ).includes( 'f3base-imp-progresso' ) );

	return {
		indiceDaTabela: tabela,
		indiceDoEncerramento: fim,
		indiceDoProgresso: topo,
		textoDoProgresso: topo < 0 ? '' : ordem[ topo ].textContent,
		textoDoEncerramento: fim < 0 ? '' : ordem[ fim ].textContent,
		encerramento: fim < 0 ? null : ordem[ fim ],
		focados
	};
}

/**
 * As MARCAS do resumo final: o que só pode aparecer no encerramento.
 *
 * Saem dos rótulos de reserva do próprio cliente — que é o que o servidor
 * traduz — e não de frases inventadas aqui.
 */
const MARCAS_DO_RESUMO = [
	'Contagens por escopo',
	'Nomes do que NÃO fechou OK',
	'Suspensas por dependência declarada'
];

/**
 * A ORDEM NO DOM e a separação entre progresso e encerramento: teto e piso.
 *
 * O DEFEITO MEDIDO NA 1.0.18: `progresso` é o PRIMEIRO filho da raiz — é o que
 * `aria-live` exige de um status ao vivo — e o resumo de encerramento inteiro
 * era escrito DENTRO dele. A conclusão aparecia antes do log e empurrava a
 * tabela para baixo.
 *
 * São duas coisas: progresso é status, encerramento é conclusão. O piso não é
 * uma fixture em disco — é um MUTANTE do próprio cliente, e por isso esta
 * checagem está declarada em `suite/pisos-em-sonda.tsv`.
 *
 * @param {string} fonte    Código do cliente REAL.
 * @param {Function} afirmar Coletor de achados.
 * @return {void}
 */
function ordemDoResultado( fonte, afirmar ) {
	const arvore = bancadaDeDom( fonte );

	/* ---------- teto: a árvore que o operador vê ---------- */

	afirmar( arvore.indiceDoProgresso === 0, 'teto da ordem: o progresso deixou de ser o primeiro filho da raiz — ele é o status ao vivo, e é para isso que aria-live existe' );
	afirmar( arvore.indiceDaTabela >= 0, 'teto da ordem: a tabela do log não foi montada na bancada, e sem ela não há ordem a medir' );
	afirmar( arvore.indiceDoEncerramento >= 0, 'teto do encerramento: nenhum nó de encerramento foi montado — a conclusão precisa existir em nó próprio' );
	afirmar(
		arvore.indiceDoEncerramento > arvore.indiceDaTabela,
		'PISO DA ORDEM NO DOM: o nó de encerramento está no índice ' + String( arvore.indiceDoEncerramento ) +
			' e a tabela no ' + String( arvore.indiceDaTabela ) +
			' — a conclusão tem de vir DEPOIS da tabela, ou ela volta a empurrar o log para baixo'
	);

	for ( const marca of MARCAS_DO_RESUMO ) {
		afirmar(
			arvore.textoDoEncerramento.includes( marca ),
			'teto do resumo: o encerramento não traz "' + marca + '" — o resumo inteiro mora no fim, e o que sai de lá não sai em lugar nenhum'
		);

		afirmar(
			! arvore.textoDoProgresso.includes( marca ),
			'PISO DO PROGRESSO: "' + marca + '" foi escrito na barra de progresso — o resumo final NÃO pode ser escrito em progresso, que é o defeito da 1.0.18'
		);
	}

	afirmar(
		arvore.textoDoProgresso.includes( 'SUCESSO_APLICACAO' ),
		'teto da linha curta: o topo não diz o estado fechado da aplicação, e linha curta que não diz o resultado não é verdadeira, é só curta'
	);

	afirmar(
		arvore.textoDoProgresso.length < arvore.textoDoEncerramento.length,
		'teto da linha curta: o topo (' + String( arvore.textoDoProgresso.length ) + ' caracteres) não é mais curto que o encerramento (' +
			String( arvore.textoDoEncerramento.length ) + ') — separar os dois e deixar o volume no topo não separa nada'
	);

	/* ---------- teto: anunciada e alcançável pelo teclado ---------- */

	const no = arvore.encerramento;

	afirmar( !! no && 'region' === no.getAttribute( 'role' ), 'teto da a11y: o encerramento não é uma região nomeável — sem role=region ele some da navegação por regiões' );
	afirmar( !! no && '' !== String( no.getAttribute( 'aria-label' ) || '' ), 'teto da a11y: a região de encerramento não tem nome acessível' );
	afirmar( !! no && '-1' === no.getAttribute( 'tabindex' ), 'teto da a11y: a região de encerramento não é focável por script (tabindex=-1), e sem isso o foco não pode ir até ela' );
	afirmar( !! no && false === no.hidden, 'teto da a11y: a região de encerramento continuou escondida depois de escrita' );
	afirmar( !! no && no.recebeuFoco, 'teto da a11y: a região de encerramento NÃO recebeu foco — mover o nó sem anunciá-lo troca um defeito de leitura por um defeito de acesso' );

	/* ---------- piso: os mutantes do próprio cliente ---------- */

	const mutantes = [
		{
			rotulo: 'resumo escrito no progresso',
			de: 'encerramento.textContent = resumoDeEncerramento(',
			para: 'progresso.textContent += resumoDeEncerramento(',
			prova: ( m ) => MARCAS_DO_RESUMO.every( ( marca ) => ! m.textoDoProgresso.includes( marca ) ),
			porque: 'a bancada não acusou o resumo escrito na barra de progresso, que É o defeito da 1.0.18: sem isso este piso aprova o defeito que ele existe para reprovar'
		},
		{
			rotulo: 'encerramento antes da tabela',
			de: 'raiz.appendChild( tabela );\n\traiz.appendChild( encerramento );',
			para: 'raiz.appendChild( encerramento );\n\traiz.appendChild( tabela );',
			prova: ( m ) => m.indiceDoEncerramento > m.indiceDaTabela,
			porque: 'a bancada não acusou o encerramento montado ANTES da tabela — ela está medindo a ordem no código, não a ordem no DOM'
		},
		{
			rotulo: 'encerramento sem foco',
			de: '\t\tencerramento.focus();\n',
			para: '',
			prova: ( m ) => !! m.encerramento && m.encerramento.recebeuFoco,
			porque: 'a bancada não acusou a região de encerramento sem foco — a conclusão precisa ser anunciada e alcançável, não só existir'
		}
	];

	for ( const mutante of mutantes ) {
		if ( ! fonte.includes( mutante.de ) ) {
			afirmar( false, 'piso do mutante "' + mutante.rotulo + '": o trecho a mutar não existe mais no cliente, e um piso que não consegue plantar o defeito prova que a bancada é cega' );
			continue;
		}

		const mutado = bancadaDeDom( fonte.replace( mutante.de, mutante.para ) );

		afirmar( ! mutante.prova( mutado ), 'piso do mutante "' + mutante.rotulo + '": ' + mutante.porque );
	}
}

/**
 * As DECISÕES do cliente, exercitadas contra a execução que reprovou.
 *
 * Alimenta a checagem `js.decisoes_do_cliente`, cujo piso mora AQUI e não numa
 * fixture em disco: o caso negativo destas regras é um mutante do próprio
 * cliente, não uma árvore de arquivos. É por isso que ela está declarada em
 * `suite/pisos-em-sonda.tsv`, e é `estatica.piso_em_sonda_declarado` que confere
 * que esta sonda de fato traz os dois ramos.
 *
 * O caso medido: o operador executou, deu erro, executou de novo, e a tela
 * entrou em laço — 163 linhas idênticas de rejeição de lock em 90 segundos,
 * `Etapa 94 de 40` na barra, `estado da aplicação:` vazio no rodapé e um
 * encerramento dizendo "163 BLOCKED" ao lado de "BLOCKED: nenhum".
 *
 * As quatro regras que nasceram daí têm teto e piso aqui, e o laço é SIMULADO:
 * a sonda alimenta a decisão de avanço com a resposta real de rejeição de lock
 * e conta quantas requisições o cliente faria.
 */
function cliente( raiz ) {
	const alvo = join( raiz, 'includes/assets/implantador.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'includes/assets/implantador.js ausente na raiz varrida' ] };
	}

	const nomes = [ 'nomeDaLinha', 'dentroDoPlano', 'planoAvancou', 'proximoLote', 'rejeicaoDeLock', 'fechoDaAplicacao', 'formatarLista', 'nomesPorEstado', 'linhaFinalDeProgresso', 'resumoDeEncerramento' ];
	const pedacos = [];

	for ( const nome of nomes ) {
		const corpo = fatiar( fonte, nome );

		if ( ! corpo ) {
			return { achados: [ 'a função pura ' + nome + '() não foi encontrada no arquivo real (contrato de extração quebrado)' ] };
		}

		pedacos.push( corpo );
	}

	let api;

	try {
		api = new Function( pedacos.join( '\n' ) + '\nreturn { ' + nomes.join( ', ' ) + ' };' )();
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	/* Estados de aplicação aceitos, como o servidor os declara para a tela. */
	const FECHADOS_CLIENTE = [ 'PRONTO', 'EXECUTANDO', 'SUCESSO_APLICACAO', 'FALHA_PARCIAL', 'FALHA', 'REVERTIDO', 'BLOCKED' ];

	/* A resposta REAL da rejeição de lock, como o servidor a monta. */
	const rejeicao = {
		ok: false,
		concluido: true,
		parou: true,
		lote: 0,
		etapa: 'lote',
		rotulo: 'lote.lock_ocupado',
		estado: 'BLOCKED',
		aplicacao: 'BLOCKED',
		motivo: 'execução concorrente rejeitada…',
		lock: { dono: 'exec6890', idade: 38, ttl: 90, abandonado_em: 1756000000, abandonado_as: '2026-08-31 21:31:29' }
	};

	/* ---------- 1. o laço de 163 requisições não pode existir ---------- */

	const TOTAL = 40;
	let indice = 0;
	let requisicoes = 1;
	let passo = api.proximoLote( rejeicao, indice, TOTAL );

	while ( passo.enviar && requisicoes < 500 ) {
		indice = passo.indice;
		requisicoes++;
		passo = api.proximoLote( rejeicao, indice, TOTAL );
	}

	afirmar( requisicoes === 1, 'piso do laço: a rejeição de lock produziu ' + String( requisicoes ) + ' requisições; ela não é resultado de unidade nenhuma e tem de parar na PRIMEIRA' );
	afirmar( passo.parada === 'plano-nao-avancou', 'piso do laço: a parada não foi nomeada como plano-não-avançou, e sim "' + String( passo.parada ) + '"' );
	afirmar( indice + 1 <= TOTAL, 'piso do contador: a etapa visível chegou a ' + String( indice + 1 ) + ' com total ' + String( TOTAL ) + ' — Etapa N de M com N maior que M é o contador contando requisição, não unidade' );

	/* ---------- 1b. o payload EXATO da 1.0.15, sem nenhum campo novo ---------- */

	/*
	 * ESTA É A PROVA QUE IMPORTA: o cliente tem de parar sozinho, mesmo contra
	 * um servidor que não manda `parou`, `concluido`, `lote`, `rotulo` nem
	 * `aplicacao` — que era exatamente a resposta da 1.0.15. Um piso que só
	 * exercitasse o payload novo estaria medindo a correção do servidor duas
	 * vezes e a do cliente nenhuma.
	 */
	const rejeicao1015 = { ok: false, estado: 'BLOCKED', motivo: 'execução concorrente rejeitada: o lock pertence a exec6890, com heartbeat há 38 segundos (TTL 90s).' };

	let indiceVelho = 0;
	let requisicoesVelhas = 1;
	let passoVelho = api.proximoLote( rejeicao1015, indiceVelho, TOTAL );

	while ( passoVelho.enviar && requisicoesVelhas < 500 ) {
		indiceVelho = passoVelho.indice;
		requisicoesVelhas++;
		passoVelho = api.proximoLote( rejeicao1015, indiceVelho, TOTAL );
	}

	afirmar( requisicoesVelhas === 1, 'piso do laço da 1.0.15: contra a resposta antiga o cliente fez ' + String( requisicoesVelhas ) + ' requisições; ele tem de parar sozinho, sem depender de o servidor mandar campo novo' );
	afirmar( indiceVelho + 1 <= TOTAL, 'piso do contador da 1.0.15: a etapa visível chegou a ' + String( indiceVelho + 1 ) + ' com total ' + String( TOTAL ) );
	afirmar( api.nomeDaLinha( String( rejeicao1015.estado ), rejeicao1015.rotulo, 'lote.linha_sem_nome' ) !== '', 'piso do nome da 1.0.15: a resposta antiga não traz rótulo e a linha saiu anônima' );
	afirmar( api.fechoDaAplicacao( rejeicao1015, FECHADOS_CLIENTE, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho da 1.0.15: a resposta antiga não traz estado da aplicação e o rodapé fechou vazio' );

	/* ---------- 2. teto: a resposta de unidade AVANÇA ---------- */

	const unidade = { ok: true, concluido: false, lote: 7, total: TOTAL, estado: 'OK', rotulo: 'preflight', aplicacao: 'EXECUTANDO' };
	const avanco = api.proximoLote( unidade, 7, TOTAL );

	afirmar( avanco.enviar === true && avanco.indice === 8, 'teto do avanço: resposta de unidade que rodou tinha de avançar para o lote seguinte' );
	afirmar( api.planoAvancou( unidade, 7 ) === true, 'teto do avanço: planoAvancou() não reconheceu a resposta da própria unidade' );

	/* BLOCKED de UNIDADE continua avançando: a regra da 1.0.13 não foi enfraquecida. */
	const bloqueada = { ok: false, concluido: false, lote: 7, total: TOTAL, estado: 'BLOCKED', rotulo: 'plugins.mcp', aplicacao: 'EXECUTANDO' };
	afirmar( api.proximoLote( bloqueada, 7, TOTAL ).enviar === true, 'teto do BLOCKED: unidade que MEDIU pré-condição ausente não pode parar a execução inteira — a regra de 1.0.13 continua valendo' );

	/* Resposta sobre OUTRO lote não avança: foi assim que o contador se soltou do plano. */
	afirmar( api.planoAvancou( { concluido: false, lote: 3 }, 7 ) === false, 'piso do avanço: resposta sobre outro lote foi tratada como avanço' );
	afirmar( api.planoAvancou( { concluido: false }, 7 ) === false, 'piso do avanço: resposta sem lote foi tratada como avanço' );
	afirmar( api.planoAvancou( null, 0 ) === false, 'piso do avanço: resposta nula foi tratada como avanço' );

	/* ---------- 3. a guarda de índice ---------- */

	afirmar( api.dentroDoPlano( 0, TOTAL ) === true, 'teto da guarda: o primeiro lote cabe no plano' );
	afirmar( api.dentroDoPlano( TOTAL - 1, TOTAL ) === true, 'teto da guarda: o último lote cabe no plano' );
	afirmar( api.dentroDoPlano( TOTAL, TOTAL ) === false, 'piso da guarda: índice igual ao total não existe no plano' );
	afirmar( api.dentroDoPlano( 93, TOTAL ) === false, 'piso da guarda: o índice 93 com 40 unidades é o Etapa 94 de 40 da tela' );
	afirmar( api.dentroDoPlano( -1, TOTAL ) === false, 'piso da guarda: índice negativo passou' );
	afirmar( api.proximoLote( { concluido: false, lote: TOTAL - 1 }, TOTAL - 1, TOTAL ).enviar === false, 'piso da guarda: o avanço depois da última unidade tinha de parar' );

	/* ---------- 4. rejeição de lock reconhecida com os quatro fatos ---------- */

	const lock = api.rejeicaoDeLock( rejeicao );

	afirmar( lock !== null, 'teto do lock: a rejeição não foi reconhecida' );
	afirmar( lock && lock.dono === 'exec6890', 'teto do lock: o dono não saiu na linha' );
	afirmar( lock && lock.idade === '38', 'teto do lock: a idade do heartbeat não saiu na linha' );
	afirmar( lock && lock.ttl === '90', 'teto do lock: o TTL não saiu na linha' );
	afirmar( lock && lock.abandonadoAs === '2026-08-31 21:31:29', 'teto do lock: o HORÁRIO em que o lock passa a ser abandonado não saiu na linha, e é ele que responde "quanto esperar"' );
	afirmar( api.rejeicaoDeLock( unidade ) === null, 'piso do lock: resposta de unidade comum foi lida como rejeição de lock' );
	afirmar( api.rejeicaoDeLock( null ) === null, 'piso do lock: resposta nula foi lida como rejeição de lock' );

	/* ---------- 5. linha que não fecha OK é NOMEADA ---------- */

	afirmar( api.nomeDaLinha( 'BLOCKED', '', 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: linha BLOCKED sem rótulo ficou anônima — foi assim que "163 BLOCKED" saiu ao lado de "BLOCKED: nenhum"' );
	afirmar( api.nomeDaLinha( 'FALHA', null, 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: linha FALHA sem rótulo ficou anônima' );
	afirmar( api.nomeDaLinha( 'WARN', '   ', 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: rótulo só de espaço passou por nome' );
	afirmar( api.nomeDaLinha( 'BLOCKED', 'lote.lock_ocupado', 'lote.linha_sem_nome' ) === 'lote.lock_ocupado', 'teto do nome: o rótulo do servidor foi substituído pelo de reserva' );
	afirmar( api.nomeDaLinha( 'OK', '', 'lote.linha_sem_nome' ) === '', 'teto do nome: OK sem rótulo continua resumido, por desenho' );

	/*
	 * E a contagem por estado não pode divergir da lista de nomes: com a linha
	 * nomeada, uma contagem de N linhas BLOCKED tem pelo menos um nome.
	 */
	const renderizadas = {};
	const nomesRenderizados = {};

	for ( let i = 0; i < 163; i++ ) {
		const estado = 'BLOCKED';
		renderizadas[ estado ] = ( renderizadas[ estado ] || 0 ) + 1;

		if ( ! nomesRenderizados[ estado ] ) {
			nomesRenderizados[ estado ] = [];
		}

		const nome = api.nomeDaLinha( estado, '', 'lote.linha_sem_nome' );

		if ( nome !== '' && nomesRenderizados[ estado ].indexOf( nome ) === -1 ) {
			nomesRenderizados[ estado ].push( nome );
		}
	}

	afirmar(
		renderizadas.BLOCKED > 0 && nomesRenderizados.BLOCKED.length > 0,
		'piso da contagem-com-nomes: ' + String( renderizadas.BLOCKED ) + ' linha(s) BLOCKED e ' + String( nomesRenderizados.BLOCKED.length ) + ' nome(s) — o mesmo escopo se contradizendo em duas frases seguidas'
	);

	/* ---------- 6. o rodapé nunca fecha vazio ---------- */

	const FECHADOS = FECHADOS_CLIENTE;

	afirmar( api.fechoDaAplicacao( { aplicacao: 'SUCESSO_APLICACAO' }, FECHADOS, 'BLOCKED' ) === 'SUCESSO_APLICACAO', 'teto do fecho: o estado que o servidor mandou não foi impresso' );
	afirmar( api.fechoDaAplicacao( rejeicao, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'teto do fecho: execução que nunca adquiriu o lock tinha de fechar BLOCKED' );
	afirmar( api.fechoDaAplicacao( {}, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: resposta sem estado da aplicação fechou vazio, e vazio não é estado fechado' );
	afirmar( api.fechoDaAplicacao( { aplicacao: '' }, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: estado vazio foi impresso como se fosse fechado' );
	afirmar( api.fechoDaAplicacao( null, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: sem resposta nenhuma o rodapé fechou vazio' );
	afirmar( api.fechoDaAplicacao( { aplicacao: 'INVENTADO' }, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: estado fora da lista declarada passou por fechado' );
	afirmar( FECHADOS.indexOf( api.fechoDaAplicacao( { aplicacao: 'QUALQUER' }, FECHADOS, 'BLOCKED' ) ) !== -1, 'piso do fecho: o fecho de reserva não é um estado fechado' );

	/* ---------- 7. progresso é status; encerramento é conclusão ---------- */

	/*
	 * As DUAS funções puras, extraídas do arquivo real: a linha curta do topo
	 * não pode carregar o resumo, e o resumo tem de carregar tudo.
	 */
	const curta = api.linhaFinalDeProgresso( 'Execução concluída.', 'SUCESSO_APLICACAO', 'estado da aplicação', 'O resultado completo está no fim desta página.' );

	afirmar( curta.includes( 'SUCESSO_APLICACAO' ), 'teto da linha curta: o estado fechado da aplicação não saiu na linha do topo' );
	afirmar( curta.includes( 'fim desta página' ), 'teto da linha curta: a linha do topo não diz onde está o resultado completo' );

	for ( const marca of MARCAS_DO_RESUMO ) {
		afirmar( ! curta.includes( marca ), 'piso da linha curta: ela trouxe "' + marca + '", que é parte do resumo e mora no encerramento' );
	}

	const completo = api.resumoDeEncerramento(
		{
			checagens_falha: 0,
			checagens_blocked: 2,
			unidades_falha: 0,
			unidades_blocked: 1,
			checagens_nomes: { BLOCKED: [ 'privacidade.controlador_identificado' ] },
			unidades_nomes: { BLOCKED: [ 'entrega' ] }
		},
		{ contagens: { BLOCKED: 3 }, nomes: { BLOCKED: [ 'entrega' ] }, resumidas: 41, suspensas: 0, bloqueadas: 3 },
		{
			escopos: 'Contagens por escopo — checagens: %1$s FALHA e %2$s BLOCKED · unidades: %3$s FALHA e %4$s BLOCKED · tela: %5$s FALHA e %6$s BLOCKED.',
			nomes: 'Nomes do que NÃO fechou OK — checagens: %1$s · unidades: %2$s · tela: %3$s.',
			resumidas: 'Checagens OK dentro de unidades, resumidas por desenho: %1$s.',
			aplicacao: 'estado da aplicação',
			nenhum: 'nenhum'
		},
		'SUCESSO_APLICACAO'
	);

	afirmar( completo.includes( 'privacidade.controlador_identificado' ), 'teto do resumo: o nome da checagem que não fechou OK não saiu na lista' );
	afirmar( completo.includes( 'Suspensas por dependência declarada: 0 de 3' ), 'teto do resumo: a suspensão por dependência declarada não saiu com os dois números' );
	afirmar( completo.includes( 'SUCESSO_APLICACAO' ), 'teto do resumo: o estado fechado da aplicação não saiu no fim do resumo' );
	afirmar( completo.includes( 'BLOCKED: nenhum' ) === false, 'piso do resumo: a lista do escopo da tela saiu vazia enquanto a contagem do MESMO escopo dizia 3 — o instrumento se contradizendo em duas frases seguidas' );

	/* ---------- 8. a ORDEM NO DOM, medida na árvore que o operador vê ---------- */

	ordemDoResultado( fonte, afirmar );

	return { achados };
}

/**
 * O CORTE DO CLIENTE DE LEADS, na unidade que o servidor publica.
 *
 * Alimenta a checagem `js.limite_do_cliente`, cujo piso mora AQUI: o caso
 * negativo é um mutante do próprio cliente — o corte por unidade UTF-16 —, e
 * não uma árvore de arquivos. Declarada em `suite/pisos-em-sonda.tsv`.
 *
 * O defeito medido na 1.0.17: o servidor contava BYTES (`strlen`) e o cliente
 * contava unidades UTF-16 (`texto.length`), com o MESMO número publicado por
 * `limites_publicos()`. Em português, com acentuação, o navegador aprovava e o
 * servidor devolvia 400 — e a recusa é dura, nunca truncamento em silêncio.
 * Os dois lados agora contam CARACTERES, e é isso que esta sonda mede.
 */
function limiteDoCliente( raiz ) {
	const alvo = join( raiz, 'fontes/site-core/assets/f3base-leads.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/site-core/assets/f3base-leads.js ausente na raiz varrida' ] };
	}

	const nomes = [ 'caracteres', 'limitar' ];
	const pedacos = [];

	for ( const nome of nomes ) {
		const corpo = fatiar( fonte, nome );

		if ( ! corpo ) {
			return { achados: [ 'a função pura ' + nome + '() não foi encontrada no arquivo real (contrato de extração quebrado)' ] };
		}

		pedacos.push( corpo );
	}

	let api;

	try {
		api = new Function( 'LIMITES', pedacos.join( '\n' ) + '\nreturn { ' + nomes.join( ', ' ) + ' };' )( { nome: 120, mensagem: 2000 } );
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	/* Um nome de 120 CARACTERES acentuados: o caso que o servidor recusava. */
	const acentuado = 'ção'.repeat( 40 );

	/* PISO: a sonda reproduz o defeito? Em bytes o mesmo texto EXCEDE o limite. */
	afirmar(
		Buffer.byteLength( acentuado, 'utf8' ) > 120,
		'piso: o texto acentuado no limite não excede 120 bytes, e sem isso a divergência de unidade não é reproduzível aqui'
	);

	afirmar(
		api.caracteres( acentuado ).length === 120,
		'piso: o texto de bancada não tem 120 caracteres — ele tem ' + String( api.caracteres( acentuado ).length )
	);

	/* TETO: o cliente NÃO corta o que o servidor aceita. */
	afirmar(
		api.limitar( 'nome', acentuado ) === acentuado,
		'teto: o cliente CORTOU um nome de 120 caracteres que o servidor aceita — corte de um lado e recusa do outro, com o mesmo número publicado'
	);

	/* PISO da regra: um caractere acima do limite ainda é cortado, em caracteres. */
	afirmar(
		api.caracteres( api.limitar( 'nome', acentuado + 'ç' ) ).length === 120,
		'piso: o corte de 121 caracteres não devolveu 120 caracteres — o corte é por caractere, e nunca por unidade UTF-16'
	);

	/*
	 * PISO do par substituto: cortar por unidade UTF-16 no meio de um emoji
	 * devolveria metade de um caractere, e o servidor receberia texto que
	 * ninguém escreveu.
	 */
	const comEmoji = 'a'.repeat( 119 ) + '🙂';

	afirmar(
		comEmoji.length === 121 && api.caracteres( comEmoji ).length === 120,
		'piso do par substituto: o texto de bancada não tem 121 unidades UTF-16 e 120 caracteres, e sem isso a diferença entre as unidades não é reproduzível'
	);

	afirmar(
		api.limitar( 'nome', comEmoji ) === comEmoji,
		'teto do par substituto: o cliente cortou um texto de 120 caracteres porque ele tem 121 unidades UTF-16'
	);

	afirmar(
		! api.limitar( 'nome', comEmoji + 'b' ).includes( '\uFFFD' ) && api.caracteres( api.limitar( 'nome', comEmoji + 'b' ) ).length === 120,
		'piso do par substituto: o corte partiu um caractere ao meio'
	);

	/* Campo sem limite publicado sai intacto: limite ausente não é limite zero. */
	afirmar(
		api.limitar( 'inexistente', acentuado ) === acentuado,
		'piso do limite ausente: campo sem limite publicado foi cortado — limite ausente não é limite zero'
	);

	return { achados };
}

/**
 * BANCADA DO CLIQUE: o `f3base-leads.js` REAL, rodado de ponta a ponta.
 *
 * Não é recorte nem cópia: o arquivo servido é avaliado inteiro contra um DOM de
 * mentira — o mínimo que ele toca —, e o clique é disparado no ouvinte que ele
 * mesmo registrou. O que sai daqui é o que o navegador teria feito: o `href` que
 * ficou no link, o corpo que foi para o beacon e as chamadas que cada canal
 * recebeu.
 *
 * @param {string} fonte  Código do cliente, como ele viaja no pacote.
 * @param {Object} dados  O objeto que o servidor localiza na página.
 * @param {string} href   O `href` que o link tem quando o clique acontece.
 * @return {Object} O estado depois do clique.
 */
function bancadaDoClique( fonte, dados, href ) {
	const ouvintes = {};
	const chamadas = { gtag: [], fbq: [], lintrk: [], beacon: [] };

	const gatilho = {
		nodeType: 1,
		attrs: { 'data-f3base-lead': 'cta', href },
		getAttribute( nome ) {
			return Object.prototype.hasOwnProperty.call( this.attrs, nome ) ? this.attrs[ nome ] : null;
		},
		setAttribute( nome, valor ) {
			this.attrs[ nome ] = String( valor );
		},
		matches() {
			return true;
		},
		closest() {
			return null;
		},
		querySelector() {
			return null;
		}
	};

	const doc = {
		readyState: 'complete',
		cookie: '',
		referrer: '',
		body: {},
		addEventListener( tipo, fn ) {
			( ouvintes[ tipo ] = ouvintes[ tipo ] || [] ).push( fn );
		},
		querySelectorAll() {
			return [];
		},
		dispatchEvent() {
			return true;
		}
	};

	const win = {
		f3baseLeadsDados: dados,
		dataLayer: [],
		location: {
			search: '?utm_source=google&gclid=BANCADA_GCLID&fbclid=BANCADA_FBCLID&li_fat_id=BANCADA_LI',
			pathname: '/lp/',
			origin: 'https://exemplo.test',
			protocol: 'https:'
		},
		crypto: {
			getRandomValues( bytes ) {
				for ( let i = 0; i < bytes.length; i++ ) {
					bytes[ i ] = i + 1;
				}
				return bytes;
			}
		},
		localStorage: {
			guardado: {},
			getItem( chave ) {
				return Object.prototype.hasOwnProperty.call( this.guardado, chave ) ? this.guardado[ chave ] : null;
			},
			setItem( chave, valor ) {
				this.guardado[ chave ] = String( valor );
			},
			removeItem( chave ) {
				delete this.guardado[ chave ];
			}
		},
		gtag( ...args ) {
			chamadas.gtag.push( args );
		},
		fbq( ...args ) {
			chamadas.fbq.push( args );
		},
		lintrk( ...args ) {
			chamadas.lintrk.push( args );
		},
		addEventListener() {}
	};

	const nav = {
		sendBeacon( url, corpo ) {
			chamadas.beacon.push( { url, corpo: corpo && corpo.partes ? String( corpo.partes[ 0 ] ) : '' } );
			return true;
		}
	};

	function BlobDeBancada( partes ) {
		this.partes = partes;
	}

	// eslint-disable-next-line no-new-func
	new Function( 'window', 'document', 'navigator', 'Blob', fonte )( win, doc, nav, BlobDeBancada );

	for ( const ouvinte of ouvintes.click || [] ) {
		ouvinte( { target: gatilho } );
	}

	return { win, doc, gatilho, chamadas };
}

/**
 * `js.conversao_multicanal` — a CONVERSÃO DO CLIQUE, nos quatro canais e nos
 * dois caminhos.
 *
 * O que ela mede, e por que cada coisa: até a 1.0.19 o CTA disparava
 * `select_content` e nunca `generate_lead` — o evento de conversão exigia
 * formulário e o template não tem nenhum —, nada carregava o `gtag.js`, e o
 * clique reescrevia o `href` sem olhar o que havia ali.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
function conversaoDoClique( raiz ) {
	const alvo = join( raiz, 'fontes/site-core/assets/f3base-leads.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/site-core/assets/f3base-leads.js ausente na raiz varrida' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	const medicaoDireta = {
		caminho: 'direto',
		gtm: '',
		ga4: 'G-ABCDEF1234',
		ads: { id: 'AW-123456789', label: 'AbC-D_efGhIjKlM' },
		meta: { pixelId: '123456789012345', origem: 'https://connect.facebook.net/en_US/fbevents.js' },
		linkedin: { partnerId: '1234567', conversionId: '7654321', origem: 'https://snap.licdn.com/li.lms-analytics/insight.min.js' },
		origemGoogle: 'https://www.googletagmanager.com/',
		eventosGa4: true
	};

	const base = {
		endpoint: 'https://exemplo.test/wp-json/f3base/v1/lead',
		token: 'token-de-bancada',
		numero: '5511999999999',
		mensagem: 'Olá',
		seletor: '[data-f3base-lead]',
		atributo: 'data-f3base-lead',
		atributoNumero: 'data-f3base-numero',
		hrefsDoModelo: [ '', '#', '/contato' ],
		atribuicao: { modelo: 'first-touch', ttlDias: 30, chave: 'f3base_atribuicao' },
		eventosGa4: true,
		limites: { nome: 120, mensagem: 2000, formulario: 60, pagina: 300 },
		medicao: medicaoDireta
	};

	/* TETO: href do modelo, caminho direto. */
	const doModelo = bancadaDoClique( fonte, base, '/contato/' );
	const nomesGtag = doModelo.chamadas.gtag.map( ( c ) => String( c[ 1 ] ) );

	afirmar(
		String( doModelo.gatilho.attrs.href ).indexOf( 'https://wa.me/5511999999999' ) === 0,
		'teto do destino: o href do modelo não virou o link do WhatsApp com a referência do clique'
	);

	afirmar(
		nomesGtag.indexOf( 'generate_lead' ) !== -1,
		'teto do GA4: generate_lead NÃO foi disparado no clique — até a 1.0.19 ele exigia formulário preenchido, e como o template não tem formulário o evento de conversão nunca saía; o que saía era um select_content, que campanha nenhuma otimiza'
	);

	afirmar(
		doModelo.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] && 'AW-123456789/AbC-D_efGhIjKlM' === c[ 2 ].send_to ),
		'teto do Google Ads: a conversão não saiu com send_to montado das duas metades declaradas'
	);

	afirmar(
		doModelo.chamadas.fbq.some( ( c ) => 'track' === c[ 0 ] && 'Lead' === c[ 1 ] && c[ 3 ] && c[ 3 ].eventID ),
		'teto da Meta: o Lead não saiu com eventID — sem ele a deduplicação da Conversions API não tem como acontecer'
	);

	afirmar(
		doModelo.chamadas.lintrk.some( ( c ) => 'track' === c[ 0 ] && 7654321 === c[ 1 ].conversion_id ),
		'teto do LinkedIn: a conversão declarada não foi disparada'
	);

	afirmar(
		doModelo.win.dataLayer.some( ( e ) => e && 'generate_lead' === e.event ),
		'teto do dataLayer: o evento não foi empurrado em formato de OBJETO — é o formato que um container lê como gatilho, e sem ele trocar de caminho perde a conversão'
	);

	const corpo = doModelo.chamadas.beacon.length ? JSON.parse( doModelo.chamadas.beacon[ 0 ].corpo ) : {};
	const atribuido = corpo.atribuicao || {};

	afirmar(
		'BANCADA_GCLID' === atribuido.gclid && 'BANCADA_FBCLID' === atribuido.fbclid && 'BANCADA_LI' === atribuido.li_fat_id,
		'teto dos identificadores de clique: gclid, fbclid e li_fat_id não chegaram ao lead — sem eles o lead chega sem a campanha que o comprou'
	);

	afirmar(
		'string' === typeof atribuido.fbc && 0 === atribuido.fbc.indexOf( 'fb.1.' ) && atribuido.fbc.endsWith( 'BANCADA_FBCLID' ),
		'teto do _fbc: o cookie não foi montado a partir do fbclid no formato que a Meta declara'
	);

	afirmar(
		'google' === atribuido.fonte,
		'teto da campanha: os cinco UTMs pararam de viajar quando os identificadores de clique entraram'
	);

	/* PISO do destino: o href do agente sobrevive ao clique, e a conversão sai igual. */
	const doAgente = bancadaDoClique( fonte, base, 'https://campanha.exemplo.test/lp-outubro' );

	afirmar(
		'https://campanha.exemplo.test/lp-outubro' === doAgente.gatilho.attrs.href,
		'piso do destino: o clique REESCREVEU o href do agente — até a 1.0.19 ele fazia isso a cada clique, e a landing que a campanha aponta virava o wa.me'
	);

	afirmar(
		doAgente.chamadas.gtag.map( ( c ) => String( c[ 1 ] ) ).indexOf( 'generate_lead' ) !== -1,
		'piso do destino: com destino próprio o clique deixou de ser medido — medir não exige mandar no destino'
	);

	/* PISO do caminho: com container, NENHUM disparo direto acontece. */
	const comContainer = bancadaDoClique(
		fonte,
		Object.assign( {}, base, {
			medicao: {
				caminho: 'gtm',
				gtm: 'GTM-ABC1234',
				ga4: '',
				ads: { id: '', label: '' },
				meta: { pixelId: '', origem: '' },
				linkedin: { partnerId: '', conversionId: '', origem: '' },
				origemGoogle: 'https://www.googletagmanager.com/',
				eventosGa4: true
			}
		} ),
		'/contato/'
	);

	afirmar(
		0 === comContainer.chamadas.fbq.length && 0 === comContainer.chamadas.lintrk.length,
		'piso do disparo em dobro: no caminho do container o cliente disparou tag direta — o container também dispara, e a mesma conversão sai duas vezes'
	);

	afirmar(
		! comContainer.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] ),
		'piso do disparo em dobro: a conversão do Ads saiu direto mesmo no caminho do container'
	);

	afirmar(
		comContainer.win.dataLayer.some( ( e ) => e && 'generate_lead' === e.event ),
		'piso do caminho: no caminho do container o objeto do evento não foi empurrado, e é ele o gatilho que o container lê'
	);

	/*
	 * PISO da SEGUNDA trava. São duas para o mesmo disparo em dobro: a
	 * estrutural, no servidor, que não deixa o ID direto chegar ao navegador
	 * (medida em `tracking.caminho_unico`), e a do cliente, medida aqui. Esta
	 * bancada entrega os IDs diretos DE PROPÓSITO junto do container — um
	 * servidor que os deixasse passar — para que a trava do cliente seja o único
	 * motivo pelo qual nada dispara.
	 */
	const containerComIdsVazados = bancadaDoClique(
		fonte,
		Object.assign( {}, base, {
			medicao: Object.assign( {}, medicaoDireta, { caminho: 'gtm', gtm: 'GTM-ABC1234' } )
		} ),
		'/contato/'
	);

	afirmar(
		0 === containerComIdsVazados.chamadas.fbq.length
			&& 0 === containerComIdsVazados.chamadas.lintrk.length
			&& ! containerComIdsVazados.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] ),
		'piso da segunda trava: com o container declarado e os IDs diretos presentes, o cliente disparou tag direta — é o caminho do container decidindo, e não a presença do ID'
	);

	afirmar(
		containerComIdsVazados.win.dataLayer.some( ( e ) => e && 'generate_lead' === e.event ),
		'piso da segunda trava: o objeto do evento deixou de ser empurrado quando o disparo direto foi travado — travar o direto não pode calar o container'
	);

	/* PISO do slot vazio: sem ID nenhum, nada é disparado — e o lead continua registrado. */
	const semSlot = bancadaDoClique(
		fonte,
		Object.assign( {}, base, {
			medicao: {
				caminho: 'nenhum',
				gtm: '',
				ga4: '',
				ads: { id: '', label: '' },
				meta: { pixelId: '', origem: '' },
				linkedin: { partnerId: '', conversionId: '', origem: '' },
				origemGoogle: 'https://www.googletagmanager.com/',
				eventosGa4: true
			}
		} ),
		'/contato/'
	);

	afirmar(
		0 === semSlot.chamadas.fbq.length && 0 === semSlot.chamadas.lintrk.length && ! semSlot.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] ),
		'piso do slot vazio: sem ID gravado alguma conversão foi disparada — slot vazio é inerte, e disparar sem destino é inventar medição'
	);

	afirmar(
		1 === semSlot.chamadas.beacon.length,
		'piso do slot vazio: o lead deixou de ser registrado no endpoint quando não há canal declarado — o registro é do site, não da campanha'
	);

	return { achados };
}

const modo = process.argv[ 2 ] || '';
const raiz = process.argv[ 3 ] || '';

if ( 'lint' === modo ) {
	process.stdout.write( JSON.stringify( lint( raiz ) ) );
} else if ( 'extrator' === modo ) {
	process.stdout.write( JSON.stringify( extrator( raiz ) ) );
} else if ( 'cliente' === modo ) {
	process.stdout.write( JSON.stringify( cliente( raiz ) ) );
} else if ( 'leads' === modo ) {
	process.stdout.write( JSON.stringify( limiteDoCliente( raiz ) ) );
} else if ( 'conversao' === modo ) {
	process.stdout.write( JSON.stringify( conversaoDoClique( raiz ) ) );
} else {
	process.stdout.write( JSON.stringify( { achados: [ 'modo desconhecido: ' + modo ] } ) );
}
