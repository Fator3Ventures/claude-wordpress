<?php
/**
 * Checagens funcionais: as funções puras do pacote, exercitadas de verdade.
 *
 * Rodam em subprocesso (`lib/sonda-funcional.php` e `lib/sonda-gravador.php`)
 * para não contaminar o processo que imprime os estados. Cada uma devolve
 * achados por nome de checagem; quem imprime e conta continua sendo `estado()`.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Roda uma sonda de subprocesso e devolve o veredito por checagem.
 *
 * @param string $sonda Caminho da sonda.
 * @param string $raiz  Raiz do pacote.
 * @return array<string,array{ok:bool,achados:array<int,string>,medidas:int}>
 */
function f3b_rodar_sonda( string $sonda, string $raiz ): array {
	$saida  = array();
	$codigo = 0;
	exec( 'php ' . escapeshellarg( $sonda ) . ' ' . escapeshellarg( $raiz ) . ' 2>&1', $saida, $codigo );

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) ) {
		return array(
			basename( $sonda, '.php' ) => array(
				'ok'      => false,
				'achados' => array( 'a sonda não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
				'medidas' => 0,
			),
		);
	}

	$saida_final = array();

	foreach ( $json as $nome => $dados ) {
		$achados = array_map( 'strval', (array) ( $dados['achados'] ?? array() ) );

		$saida_final[ (string) $nome ] = array(
			'ok'      => array() === $achados,
			'achados' => $achados,
			'medidas' => (int) ( $dados['medidas'] ?? 0 ),
		);
	}

	return $saida_final;
}

/**
 * Veredito de todas as checagens funcionais.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array<string,array{ok:bool,achados:array<int,string>,medidas:int}>
 */
function f3b_ck_funcionais( string $raiz, string $suite ): array {
	return array_merge(
		f3b_rodar_sonda( $suite . '/lib/sonda-funcional.php', $raiz ),
		f3b_rodar_sonda( $suite . '/lib/sonda-gravador.php', $raiz ),
		/*
		 * A sonda da INSTALAÇÃO LIMPA roda em processo próprio porque monta um
		 * WordPress de mentira inteiro — caches que memorizam o negativo,
		 * filesystem, options — e nada disso pode vazar para as outras sondas.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-instalacao.php', $raiz ),
		/*
		 * A sonda do SITE-CORE também roda em processo próprio: ela monta um
		 * wpdb de mentira e roda o endpoint de leads e a cadência REAIS contra
		 * ele. O `$wpdb` global e as options em memória não podem vazar para
		 * nenhuma outra sonda.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-site-core.php', $raiz ),
		/*
		 * A sonda do TEMA roda em processo próprio por um motivo que a do
		 * site-core torna visível: lá o piso do CTA depende de
		 * `WP_HTML_Tag_Processor` NÃO existir, e aqui as duas regras que
		 * preenchem-quando-falta só existem quando ele existe. As duas bancadas
		 * não cabem no mesmo processo.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-tema.php', $raiz )
	);
}

/**
 * Roda um modo da sonda de JavaScript sob o Node de verdade.
 *
 * @param string $modo  Modo da sonda.
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_rodar_js( string $modo, string $raiz, string $suite ): array {
	$saida  = array();
	$codigo = 0;
	exec(
		'node ' . escapeshellarg( $suite . '/checagens/js.mjs' ) . ' ' . escapeshellarg( $modo ) . ' ' . escapeshellarg( $raiz ) . ' 2>&1',
		$saida,
		$codigo
	);

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) || ! isset( $json['achados'] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'sonda js.mjs (modo ' . $modo . ') não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
		);
	}

	return array(
		'ok'      => array() === $json['achados'],
		'achados' => array_map( 'strval', $json['achados'] ),
	);
}

/**
 * Extrator de resposta do cliente: teto e piso, sob o Node de verdade.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_extrator( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'extrator', $raiz, $suite );
}

/**
 * DECISÕES do cliente: o laço de lock, o contador, o fecho e os nomes.
 *
 * As funções puras saem do arquivo REAL, extraídas dele em tempo de execução —
 * nunca copiadas —, e o laço da execução que reprovou é simulado com a resposta
 * de rejeição de lock, inclusive a resposta ANTIGA, sem os campos que a 1.0.16
 * acrescentou: o cliente tem de parar sozinho.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_cliente( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'cliente', $raiz, $suite );
}

/**
 * O CORTE do cliente de leads, na unidade que o servidor publica.
 *
 * A função pura sai do arquivo REAL, extraída dele em tempo de execução, e a
 * sonda mede a MESMA unidade dos dois lados: o defeito medido na 1.0.17 era o
 * servidor contando bytes e o cliente contando unidades UTF-16, com o mesmo
 * número publicado para os dois.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_limite_do_cliente( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'leads', $raiz, $suite );
}

/**
 * A CONVERSÃO DO CLIQUE, medida no cliente REAL sob o Node.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_conversao( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'conversao', $raiz, $suite );
}
