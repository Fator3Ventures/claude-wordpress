<?php
/**
 * Checagens que NÃO rodam neste ambiente.
 *
 * Aqui não há WordPress, banco, navegador nem produção. Cada checagem que
 * depende disso fecha **BLOCKED com a pré-condição que falta** — nunca FALHA
 * (que afirmaria ter medido) e nunca omissão (que esconderia a lacuna).
 *
 * As condicionais que este projeto não instancia fecham **N/A com a condição
 * declarada**, também nomeadas: checagem condicional que some é indistinguível
 * de checagem esquecida.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Tabela das checagens bloqueadas: nome => motivo, o que falta, classe, fase.
 *
 * @return array<string,array{motivo:string,falta:string,classe:string,fase:string}>
 */
function f3b_bloqueadas(): array {
	return array(
		'a11y.piso_da_sonda' => array(
			'motivo' => 'o piso da sonda de acessibilidade exige plantar um defeito em página renderizada e provar que a sonda o acusa',
			'falta'  => 'WordPress servindo as páginas e um motor de acessibilidade sobre o DOM renderizado',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'visual.inspecao_paginas' => array(
			'motivo' => 'inspeção visual mede a página pintada, não o markup',
			'falta'  => 'navegador headless com viewport declarado sobre o site publicado',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'formulario.destino_privado' => array(
			'motivo' => 'com contato.whatsapp_e164 PREENCHIDA o regime existe, e conferir o href promovido é fato do servidor: o link profundo é montado em render_block, no site-core, e não no arquivo do pacote',
			'falta'  => 'WordPress com o site-core ativo servindo a página, para ler o href do CTA publicado',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'formulario.envio_ponta_a_ponta' => array(
			'motivo' => 'envio aceito pelo servidor é teste funcional, não análise estática',
			'falta'  => 'WordPress com o endpoint de leads ativo e uma submissão real',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'formulario.degradado_sem_js' => array(
			'motivo' => 'o caminho degradado só existe quando a página roda sem JavaScript no navegador',
			'falta'  => 'navegador com JavaScript desligado sobre a página publicada',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'consentimento.controle_no_rodape' => array(
			'motivo' => 'o controle precisa ser encontrado no DOM de TODA página publicada, e o rodapé é renderizado pelo WordPress',
			'falta'  => 'WordPress renderizando as páginas com o tema ativo',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'menu.objeto_unico' => array(
			'motivo' => 'o menu é um post wp_navigation no banco; sem banco não existe objeto para conferir',
			'falta'  => 'WordPress com o post wp_navigation criado e f3base_nav_id gravada',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'menu.ref_injetado_no_render' => array(
			'motivo' => 'a injeção do ref acontece no filtro render_block_data, em tempo de render',
			'falta'  => 'WordPress executando o render do bloco core/navigation',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'htaccess.cabecalhos_servidos' => array(
			'motivo' => 'cabeçalho de resposta é fato do servidor, não do arquivo',
			'falta'  => 'servidor HTTP respondendo, para ler os cabeçalhos na resposta',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'htaccess.regras_preservadas' => array(
			'motivo' => 'a preservação das regras existentes só se mede contra um .htaccess real da hospedagem',
			'falta'  => 'acesso ao .htaccess da instalação de destino',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'mcp.autoteste' => array(
			'motivo' => 'o autoteste do canal é DESPACHADO — pela Abilities API quando ela existe, pelo servidor REST interno sempre — e o resultado estruturado dele vai para o relatório; despachar uma rota exige um servidor REST vivo, e a árvore do pacote não é um',
			'falta'  => 'WordPress com o complemento do canal ativo, registrando files/selftest, e um servidor REST que aceite o despacho — a regra do veredito já tem teto e piso em mcp.autoteste_veredito',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'mcp.autoteste_recusa_credencial' => array(
			'motivo' => 'a recusa a uma credencial NÃO autorizada não é mensurável de dentro do WordPress rodando como administrador: wp_execute_ability() e rest_do_request() despacham dentro do processo, com o usuário já autenticado, e nenhuma passa pela autenticação HTTP. Forjar um usuário sem capacidade mediria o permission_callback, não a credencial — prova fraca com nome de prova negativa',
			'falta'  => 'uma requisição HTTP de fora ao servidor do canal, com uma credencial sem a capacidade exigida, e o 401 ou 403 observado na ponta',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'entrega.convergencia' => array(
			'motivo' => 'o terceiro eixo é calculado das linhas de uma EXECUÇÃO: ele soma as pré-condições declaradas que fecharam BLOCKED ou FALHA no host, e a árvore do pacote não executa nada',
			'falta'  => 'uma execução da aplicação em WordPress, para que as pré-condições declaradas fechem estado — a regra do eixo já tem teto e piso em lotes.convergencia_terceiro_eixo',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'cadencia.mecanismo_declarado' => array(
			'motivo' => 'a chave cadencia_relatorio.mecanismo nasce vazia por desenho — o nome do mecanismo depende da hospedagem e é declaração do projeto que instancia esta base —, e o item correspondente da entrega fecha BLOCKED, não OK',
			'falta'  => 'o projeto declarar em cadencia_relatorio.mecanismo qual é o gatilho externo: agendador do host, cron real do servidor ou tarefa do lado do agente',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'plugins.autoupdate_alcance' => array(
			'motivo' => 'flag ligada e fonte alcançável são fatos diferentes, e o alcance de um slug de origem wordpress.org só se decide consultando o WordPress.org — medição por REDE, que a árvore do pacote não faz',
			'falta'  => 'WordPress com os plugins instalados e saída HTTPS para o WordPress.org, para decidir por slug — a regra da classificação já tem teto e piso em plugins.autoupdate_alcance_separado',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'mcp.canal_configurado' => array(
			'motivo' => 'a conferência é das 12 rotas de arquivo e banco PELO NOME, expostas pelo servidor MCP',
			'falta'  => 'WordPress com o servidor MCP e o complemento instalados e ativos',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'mcp.canal_unico' => array(
			'motivo' => 'canal duplicado só aparece na instalação: a medição é o CENSO DE PLUGINS ATIVOS daquele site — o papel canal-mcp-complemento declarado mais qualquer plugin ativo com o mesmo Plugin Name —, e a checagem LÊ o que a unidade mcp gravou; a regra do leitor, nos cinco ramos, já tem teto e piso em mcp.canal_unico_mede_plugins_ativos',
			'falta'  => 'WordPress onde a unidade mcp rode e registre o censo de plugins ativos do canal',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'plugins.autoupdate_conforme_politica' => array(
			'motivo' => 'a política se confere por LEITURA DE VOLTA da option de auto-update de cada plugin instalado',
			'falta'  => 'WordPress com os plugins instalados e a option auto_update_plugins legível',
			'classe' => 'leitura-de-volta',
			'fase'   => 'producao',
		),
		'plugins.adaptador_leitura_de_volta' => array(
			'motivo' => 'o gate do adaptador de SEO é reler do banco cada chave gravada e comparar',
			'falta'  => 'WordPress com o plugin de SEO instalado e ativo',
			'classe' => 'leitura-de-volta',
			'fase'   => 'producao',
		),
		'origem.rota_carimbada' => array(
			'motivo' => 'a rota de origem é REST e responde no runtime do WordPress',
			'falta'  => 'WordPress com o site-core ativo e a rota registrada',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'tema.ancora_sob_sticky' => array(
			'motivo' => 'o recuo da âncora sob o cabeçalho fixo é posição medida na rolagem, não declaração de CSS',
			'falta'  => 'navegador com a página renderizada e rolagem até uma âncora',
			'classe' => 'medida',
			'fase'   => 'local',
		),
		'seguranca.coop_preserva_popup' => array(
			'motivo' => 'a interação entre COOP e a janela aberta por popup só se observa no navegador',
			'falta'  => 'navegador sobre o site publicado, com os cabeçalhos servidos',
			'classe' => 'medida',
			'fase'   => 'producao',
		),
		/*
		 * Esta rodada é a PRODUTORA do registro, não a consumidora dele. Quem o
		 * consome é o host, que confere o hash do pacote instalado contra o que
		 * o registro declara — e o registro desta rodada só existe depois do
		 * selo, que é a última etapa. Fechar OK aqui seria a suíte se aprovando
		 * pelo arquivo que ela mesma acabou de escrever.
		 *
		 * A regra do leitor tem piso dos dois lados em `entrega.rodada_limpa_confere`,
		 * e a separação de gates em `entrega.gates_separados`: BLOCKED aqui trava
		 * o gate da FASE declarada e não segura mais o implantador ativo.
		 */
		'entrega.rodada_limpa' => array(
			'motivo' => 'esta rodada PRODUZ o registro (suite/rodada.json, gravado no selo, com o hash do pacote que ela mediu); quem o CONSOME é o host, conferindo-o contra o hash do pacote instalado, e uma rodada que se aprovasse pelo arquivo que ela mesma escreveu não estaria medindo nada',
			'falta'  => 'um WordPress com o pacote instalado, para conferir o hash do pacote instalado contra o registro que viajou dentro dele — a regra do leitor já tem teto e piso em entrega.rodada_limpa_confere',
			'classe' => 'pendencia-externa',
			'fase'   => 'build',
		),
		'orcamento.pagina' => array(
			'motivo' => 'peso, requisições e nós de DOM são medidos na entrega contra orcamento_pagina; declarar aqui seria inventar número',
			'falta'  => 'página servida por um servidor real, com a medição do carregamento',
			'classe' => 'medida',
			'fase'   => 'producao',
		),
		'desempenho.core_web_vitals' => array(
			'motivo' => 'Core Web Vitals são medidos em campo, sobre tráfego real',
			'falta'  => 'site em produção com coleta de campo',
			'classe' => 'medida',
			'fase'   => 'campo',
		),
		'idempotencia.tres_execucoes' => array(
			'motivo' => 'idempotência é a terceira execução não mudar nada que a segunda já tinha estabilizado',
			'falta'  => 'WordPress onde a aplicação possa rodar três vezes seguidas',
			'classe' => 'teste-funcional',
			'fase'   => 'local',
		),
		'homologacao.a_para_b' => array(
			'motivo' => 'a homologação A→B compara duas instalações reais, a de origem e a de destino',
			'falta'  => 'duas instalações WordPress, a de origem na release anterior',
			'classe' => 'teste-funcional',
			'fase'   => 'producao',
		),
	);
}

/**
 * Tabela das checagens condicionais que este projeto não instancia.
 *
 * @return array<string,array{condicao:string,classe:string,fase:string}>
 */
function f3b_nao_aplicaveis(): array {
	return array(
		'handoff.pacote_de_entrega' => array(
			'condicao' => 'o site de referência desta base não é artefato de handoff: não há site_referencia.tipo=handoff na configuração, e o conteúdo nasce dos arquivos de content/',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		'handoff.credenciais_rotacionadas' => array(
			'condicao' => 'sem artefato de handoff, não há contrato de entrega de terceiro com credencial a rotacionar',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		'formulario.regime_cf7' => array(
			'condicao' => 'o destino declarado pelo regime cf7-email (formularios.1.caixa_de_leads) está vazio, e é a presença do valor — e só ela — que faz o regime existir. A chave mora DENTRO da entrada do regime desde a 1.1.0, e não mais no topo de contato: ela é propriedade do regime, e nenhum módulo do site-core a lia. O conjunto fechado dele fica registrado para quem precisar; preencher a chave faz o regime passar a existir na execução seguinte',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		/*
		 * ESTE NOME ESTÁ NAS DUAS TABELAS, e isso é a regra funcionando. Com o
		 * destino PREENCHIDO a checagem é pendência externa de verdade — o href
		 * promovido é fato do servidor. Com o destino VAZIO não há pendência
		 * nenhuma: o regime não existe, o CTA não é publicado, e relatar isso
		 * como pendente seria a tela dizendo que falta algo que ninguém pediu.
		 * `executar.php` deixa a condição declarada vencer a pendência, e o nome
		 * sai uma vez só.
		 */
		'formulario.destino_privado' => array(
			'condicao' => 'o destino declarado pelo regime whatsapp (contato.whatsapp_e164) está vazio, e é a presença do valor — e só ela — que faz o regime existir. Enquanto ela estiver vazia o CTA não é publicado, nem no comportamento degradado; preencher a chave faz o botão passar a existir na execução seguinte, sem passo manual',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
	);
}
