<?php
/**
 * O consumidor ORFAO que sobrou: le uma chave que ninguem declara mais, e le
 * vazio em silencio — a lista fica vazia e todo host passa a ser recusado.
 *
 * @package F3Base
 */

declare( strict_types = 1 );

/**
 * Origem de plugin.
 */
final class F3Base_Imp_Plugins {

	/**
	 * O host esta na lista declarada?
	 *
	 * @param string $url URL do salto.
	 * @return bool
	 */
	public static function host_autorizado( string $url ): bool {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );

		return in_array( $host, (array) F3Base_Imp_Config::lista( 'plugins.origens_url_autorizadas' ), true );
	}
}
