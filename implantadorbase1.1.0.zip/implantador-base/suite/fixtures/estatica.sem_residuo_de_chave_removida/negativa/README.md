# Origem de plugin

O documento ORFAO que sobrou: ele continua ensinando o operador a preencher
`plugins.origens_url_autorizadas`, uma chave que o arquivo de configuração não
declara mais.
