<?php
/**
 * Resolução de origem depois da remocao da lista de hosts: HTTPS decide sozinho.
 *
 * @package F3Base
 */

declare( strict_types = 1 );

/**
 * Origem de plugin.
 */
final class F3Base_Imp_Plugins {

	/**
	 * O salto e https?
	 *
	 * @param string $url URL do salto.
	 * @return bool
	 */
	public static function salto_e_https( string $url ): bool {
		return 'https' === strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
	}
}
