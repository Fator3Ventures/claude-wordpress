# Origem de plugin

A URL declarada desce em **https**, e a guarda é revalidada a cada salto do
redirecionamento. O digesto do artefato é o que amarra o byte baixado.
