<?php
/**
 * FIXTURE NEGATIVA — o defeito plantado.
 *
 * O módulo registra as options gerenciadas do pacote na lista protegida do
 * servidor MCP: o canal passa a RECUSAR a escrita do agente sobre exatamente as
 * chaves que ele precisa editar. É o comportamento que a 1.1.0 removeu.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

/**
 * Guarda das options no canal.
 */
final class F3Base_Modulo_Guarda_De_Bancada {

	/**
	 * Registra a guarda nos filtros que o servidor expõe.
	 *
	 * @return void
	 */
	public function registrar(): void {
		add_filter( 'wp_mcp_ultimate_protected_options', array( $this, 'proteger' ), 10, 1 );
		add_filter( 'mcp_protected_options', array( $this, 'proteger' ), 10, 1 );
		add_filter( 'wp_mcp_ultimate_options_protegidas', array( $this, 'proteger' ), 10, 1 );
	}

	/**
	 * Acrescenta as options do pacote à lista recebida.
	 *
	 * @param array<int,string> $lista Lista do servidor.
	 * @return array<int,string>
	 */
	public function proteger( array $lista ): array {
		return array_merge( $lista, array( 'f3base_contato', 'f3base_tracking' ) );
	}
}
