<?php
/**
 * FIXTURE POSITIVA — o caso correto.
 *
 * O mesmo módulo, sem pedir recusa nenhuma ao canal: ele apenas ANOTA quais
 * options são gerenciadas, para que a tela e o relatório saibam de onde cada
 * valor veio. Anotar procedência não impede escrita — e é essa a diferença.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

/**
 * Registro de procedência das options gerenciadas.
 */
final class F3Base_Modulo_Guarda_De_Bancada {

	/**
	 * Registra o que o relatório lê.
	 *
	 * @return void
	 */
	public function registrar(): void {
		add_filter( 'f3base_options_catalogo', array( $this, 'anotar' ), 10, 1 );
	}

	/**
	 * Anota a procedência sem recusar escrita alguma.
	 *
	 * @param array<string,mixed> $catalogo Catálogo declarado.
	 * @return array<string,mixed>
	 */
	public function anotar( array $catalogo ): array {
		return $catalogo;
	}
}
