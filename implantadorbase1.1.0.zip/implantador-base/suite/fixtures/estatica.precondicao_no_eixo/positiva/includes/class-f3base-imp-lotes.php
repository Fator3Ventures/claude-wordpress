<?php
/**
 * Emissor de pre-condicao declarada: ele NAO escolhe o gate.
 *
 * @package F3Base
 */

declare( strict_types = 1 );

/**
 * Etapas.
 */
final class F3Base_Imp_Lotes {

	/**
	 * O controlador esta identificado?
	 *
	 * @param string $motivo Motivo medido.
	 * @return void
	 */
	public static function emitir_controlador( string $motivo ): void {
		F3Base_Imp_Relatorio::emitir(
			'BLOCKED',
			'privacidade.controlador_identificado',
			$motivo,
			array(
				'evidencia'   => 'leitura-de-volta',
				'fase'        => 'local',
				'precondicao' => true,
			)
		);
	}
}
