<?php
/**
 * O DEFEITO PLANTADO: o emissor declara pre-condicao E gate no mesmo argumento.
 *
 * Os dois metadados voltam a ser independentes, e a linha passa a ser dado que
 * so o operador tem E gate de aplicacao ao mesmo tempo — que e como uma
 * implantacao de template limpo terminava dizendo que algo estava errado.
 *
 * @package F3Base
 */

declare( strict_types = 1 );

/**
 * Etapas.
 */
final class F3Base_Imp_Lotes {

	/**
	 * O controlador esta identificado?
	 *
	 * @param string $motivo Motivo medido.
	 * @return void
	 */
	public static function emitir_controlador( string $motivo ): void {
		F3Base_Imp_Relatorio::emitir(
			'BLOCKED',
			'privacidade.controlador_identificado',
			$motivo,
			array(
				'evidencia'   => 'leitura-de-volta',
				'fase'        => 'local',
				'gate'        => 'aplicacao',
				'precondicao' => true,
			)
		);
	}
}
