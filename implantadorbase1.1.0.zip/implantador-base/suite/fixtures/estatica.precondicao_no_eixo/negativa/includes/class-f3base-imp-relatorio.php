<?php
/**
 * Relatorio: a DERIVACAO do gate a partir da pre-condicao, num lugar so.
 *
 * @package F3Base
 */

declare( strict_types = 1 );

/**
 * Relatorio em estados fechados.
 */
final class F3Base_Imp_Relatorio {

	public const GATE_APLICACAO    = 'aplicacao';
	public const GATE_CONVERGENCIA = 'convergencia';

	/**
	 * Linhas emitidas.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	private static array $linhas = array();

	/**
	 * Emite uma linha.
	 *
	 * @param string              $estado   Estado fechado.
	 * @param string              $nome     Nome da checagem.
	 * @param string              $mensagem Mensagem.
	 * @param array<string,mixed> $extra    Metadados.
	 * @return void
	 */
	public static function emitir( string $estado, string $nome, string $mensagem, array $extra = array() ): void {
		$precondicao = isset( $extra['precondicao'] ) && (bool) $extra['precondicao'];

		$gate = $precondicao
			? self::GATE_CONVERGENCIA
			: ( isset( $extra['gate'] ) ? (string) $extra['gate'] : self::GATE_APLICACAO );

		self::$linhas[] = array(
			'estado'      => $estado,
			'nome'        => $nome,
			'mensagem'    => $mensagem,
			'gate'        => $gate,
			'precondicao' => $precondicao,
		);
	}
}
