<?php
/**
 * Sonda do TEMA e do CTA sob um processador de HTML.
 *
 * Subprocesso próprio, e por um motivo que a sonda do site-core torna visível:
 * lá o piso do CTA depende de `WP_HTML_Tag_Processor` NÃO existir — é assim que
 * ela mede a instalação em que o atributo nunca é carimbado. Aqui é o contrário:
 * as duas regras desta release que preenchem-quando-falta só existem quando há
 * processador, porque preencher é escrever atributo. As duas bancadas não cabem
 * no mesmo processo.
 *
 * O processador desta bancada é de mentira e sabe disso: ele responde ao que
 * estas duas funções chamam — `next_tag` por nome e por classe, `get_attribute`,
 * `set_attribute`, `remove_attribute` e `get_updated_html` — e a nada mais. O que
 * ele NÃO é: um analisador de HTML. O que ele mede é a DECISÃO das funções sobre
 * o atributo, e é essa decisão que os dois defeitos de 1.0.19 violavam.
 *
 * Cada bloco tem TETO e PISO, e o piso não é "um caso inválido reprovou": é o
 * comportamento da 1.0.19 reproduzido na bancada, com a afirmação de que a
 * bancada realmente o reproduz saindo junto.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'erro' => 'raiz inexistente' ) );
	exit( 2 );
}

define( 'ABSPATH', sys_get_temp_dir() . '/f3base-sonda-tema/' );

$GLOBALS['f3b_tema'] = array(
	'options'      => array(),
	'politica_url' => '',
	'hooks'        => array(),
	'suportes'     => array(),
);

/* ---------------------------------------------------------------------------
 * Núcleo de mentira: só o que estes dois arquivos chamam.
 * ------------------------------------------------------------------------ */

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Plural: eco, escolhendo pela contagem.
 *
 * @param string $singular Singular.
 * @param string $plural   Plural.
 * @param int    $numero   Contagem.
 * @param string $dominio  Domínio.
 * @return string
 */
function _n( string $singular, string $plural, int $numero, string $dominio = '' ): string {
	return 1 === $numero ? $singular : $plural;
}

/**
 * Filtro: devolve o valor sem alterar.
 *
 * @param string $hook   Nome do filtro.
 * @param mixed  $valor  Valor.
 * @param mixed  ...$mais Extras.
 * @return mixed
 */
function apply_filters( string $hook, $valor, ...$mais ) {
	return $valor;
}

/**
 * Registro de filtro: a bancada só anota.
 *
 * @param string $hook       Hook.
 * @param mixed  $callback   Callback.
 * @param int    $prioridade Prioridade.
 * @param int    $args       Argumentos.
 * @return bool
 */
function add_filter( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	$GLOBALS['f3b_tema']['hooks'][] = $hook;

	return true;
}

/**
 * Registro de ação: a bancada só anota.
 *
 * @param string $hook       Hook.
 * @param mixed  $callback   Callback.
 * @param int    $prioridade Prioridade.
 * @param int    $args       Argumentos.
 * @return bool
 */
function add_action( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	$GLOBALS['f3b_tema']['hooks'][] = $hook;

	return true;
}

/**
 * Remoção de ação: sem efeito na bancada.
 *
 * @param string $hook       Hook.
 * @param mixed  $callback   Callback.
 * @param int    $prioridade Prioridade.
 * @return bool
 */
function remove_action( string $hook, $callback, int $prioridade = 10 ): bool {
	return true;
}

/**
 * Remoção de filtro: sem efeito na bancada.
 *
 * @param string $hook       Hook.
 * @param mixed  $callback   Callback.
 * @param int    $prioridade Prioridade.
 * @return bool
 */
function remove_filter( string $hook, $callback, int $prioridade = 10 ): bool {
	return true;
}

/**
 * Suporte de tema: a bancada anota.
 *
 * @param string $suporte Nome.
 * @param mixed  $args    Argumentos.
 * @return void
 */
function add_theme_support( string $suporte, $args = null ): void {
	$GLOBALS['f3b_tema']['suportes'][] = $suporte;
}

/**
 * Carregamento de tradução: sem efeito.
 *
 * @param string $dominio Domínio.
 * @param string $caminho Caminho.
 * @return bool
 */
function load_theme_textdomain( string $dominio, string $caminho ): bool {
	return true;
}

/**
 * Registro de estilo: sem efeito.
 *
 * @param string            $handle Handle.
 * @param string            $src    Origem.
 * @param array<int,string> $deps   Dependências.
 * @param mixed             $ver    Versão.
 * @return bool
 */
function wp_register_style( string $handle, string $src = '', array $deps = array(), $ver = false ): bool {
	return true;
}

/**
 * Registro de categoria de padrão: sem efeito.
 *
 * @param string             $slug  Slug.
 * @param array<string,mixed> $args Argumentos.
 * @return bool
 */
function register_block_pattern_category( string $slug, array $args = array() ): bool {
	return true;
}

/**
 * Tema atual: só a versão é lida.
 *
 * @return object
 */
function wp_get_theme() {
	return new class() {
		/**
		 * Cabeçalho do style.css.
		 *
		 * @param string $chave Chave.
		 * @return string
		 */
		public function get( string $chave ): string {
			return 'Version' === $chave ? '1.1.0' : '';
		}
	};
}

/**
 * Caminho de arquivo do tema.
 *
 * @param string $arquivo Arquivo.
 * @return string
 */
function get_theme_file_path( string $arquivo = '' ): string {
	return ABSPATH . $arquivo;
}

/**
 * URI da folha de estilo.
 *
 * @return string
 */
function get_stylesheet_uri(): string {
	return 'https://exemplo.test/style.css';
}

/**
 * Option em memória.
 *
 * @param string $nome   Nome.
 * @param mixed  $padrao Padrão.
 * @return mixed
 */
function get_option( string $nome, $padrao = false ) {
	return array_key_exists( $nome, $GLOBALS['f3b_tema']['options'] )
		? $GLOBALS['f3b_tema']['options'][ $nome ]
		: $padrao;
}

/**
 * Escrita de option em memória.
 *
 * @param string $nome     Nome.
 * @param mixed  $valor    Valor.
 * @param bool   $autoload Autoload.
 * @return bool
 */
function update_option( string $nome, $valor, bool $autoload = true ): bool {
	$GLOBALS['f3b_tema']['options'][ $nome ] = $valor;

	return true;
}

/**
 * Remoção de option em memória.
 *
 * @param string $nome Nome.
 * @return bool
 */
function delete_option( string $nome ): bool {
	unset( $GLOBALS['f3b_tema']['options'][ $nome ] );

	return true;
}

/**
 * Post: a bancada não tem banco de posts.
 *
 * @param int $id Identificador.
 * @return null
 */
function get_post( int $id = 0 ) {
	return null;
}

/**
 * URL da política de privacidade — declarada pela bancada.
 *
 * O valor mora no estado da bancada porque ele separa os dois ramos que esta
 * release mudou: com política publicada o `href` é preenchido, sem política ele
 * é REMOVIDO — e o parágrafo fica nos dois casos.
 *
 * @return string
 */
function get_privacy_policy_url(): string {
	return (string) $GLOBALS['f3b_tema']['politica_url'];
}

/**
 * Sanitização de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_text_field( string $texto ): string {
	$limpo = strip_tags( $texto );
	$limpo = preg_replace( '/[\r\n\t]+/', ' ', (string) $limpo );

	return trim( (string) $limpo );
}

/**
 * Sanitização de área de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_textarea_field( string $texto ): string {
	return trim( (string) strip_tags( $texto ) );
}

/**
 * Sanitização de chave do núcleo.
 *
 * @param string $chave Chave.
 * @return string
 */
function sanitize_key( string $chave ): string {
	$limpo = preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $chave ) );

	return is_string( $limpo ) ? $limpo : '';
}

/**
 * Sanitização de e-mail do núcleo.
 *
 * @param string $email E-mail.
 * @return string
 */
function sanitize_email( string $email ): string {
	$limpo = filter_var( trim( $email ), FILTER_SANITIZE_EMAIL );

	return is_string( $limpo ) ? $limpo : '';
}

/**
 * URL crua do núcleo.
 *
 * @param string $url URL.
 * @return string
 */
function esc_url_raw( string $url ): string {
	return trim( $url );
}

/**
 * Escape de URL para atributo.
 *
 * @param string $url URL.
 * @return string
 */
function esc_url( string $url ): string {
	return trim( $url );
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor Valor.
 * @param int   $flags Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Informação do site.
 *
 * @param string $campo Campo.
 * @return string
 */
function get_bloginfo( string $campo = '' ): string {
	return 'name' === $campo ? 'Site de bancada' : '';
}

/**
 * Decodificação de entidades do núcleo.
 *
 * @param string $texto Texto.
 * @param int    $quote Modo.
 * @return string
 */
function wp_specialchars_decode( string $texto, int $quote = ENT_QUOTES ): string {
	return html_entity_decode( $texto, $quote, 'UTF-8' );
}

/**
 * Acréscimo de parâmetro a uma URL.
 *
 * @param string $chave Chave.
 * @param string $valor Valor.
 * @param string $url   URL.
 * @return string
 */
function add_query_arg( string $chave, string $valor, string $url ): string {
	return $url . ( str_contains( $url, '?' ) ? '&' : '?' ) . $chave . '=' . $valor;
}

/* ---------------------------------------------------------------------------
 * O processador de HTML da bancada.
 * ------------------------------------------------------------------------ */

/**
 * Processador de tags: o mínimo que estas duas funções chamam.
 *
 * Honestidade do limite, escrita aqui porque é onde ela custa: isto NÃO é o
 * `WP_HTML_Tag_Processor` do núcleo. É um cursor sobre as tags de abertura que
 * uma expressão regular reconhece, com leitura e escrita de atributo. Ele serve
 * para medir QUAL atributo cada função decide escrever, apagar ou deixar em paz
 * — e é só isso que os defeitos desta release eram.
 */
final class WP_HTML_Tag_Processor {

	/**
	 * HTML sendo processado.
	 *
	 * @var string
	 */
	private string $html;

	/**
	 * Tags de abertura reconhecidas: nome, atributos e posição.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	private array $tags = array();

	/**
	 * Cursor da tag atual.
	 *
	 * @var int
	 */
	private int $atual = -1;

	/**
	 * @param string $html HTML de entrada.
	 */
	public function __construct( string $html ) {
		$this->html = $html;

		$achados = array();

		if ( false === preg_match_all( '/<([a-zA-Z][a-zA-Z0-9:-]*)((?:[^>"\']|"[^"]*"|\'[^\']*\')*)>/', $html, $achados, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) {
			return;
		}

		foreach ( $achados as $achado ) {
			$this->tags[] = array(
				'nome'    => strtoupper( (string) $achado[1][0] ),
				'atribs'  => $this->analisar( (string) $achado[2][0] ),
				'inicio'  => (int) $achado[0][1],
				'tamanho' => strlen( (string) $achado[0][0] ),
				'fecha'   => str_ends_with( rtrim( (string) $achado[0][0], '>' ), '/' ),
			);
		}
	}

	/**
	 * Analisa a string de atributos de uma tag.
	 *
	 * @param string $bruto String de atributos.
	 * @return array<string,mixed> Nome em minúsculas => valor (true quando booleano).
	 */
	private function analisar( string $bruto ): array {
		$saida   = array();
		$achados = array();

		if ( false === preg_match_all( '/([a-zA-Z_:][a-zA-Z0-9_:.-]*)(?:\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s>]+)))?/', $bruto, $achados, PREG_SET_ORDER ) ) {
			return $saida;
		}

		foreach ( $achados as $achado ) {
			$nome = strtolower( (string) $achado[1] );

			if ( '' === $nome ) {
				continue;
			}

			if ( ! isset( $achado[2] ) || '' === $achado[2] ) {
				$saida[ $nome ] = true;
				continue;
			}

			if ( isset( $achado[3] ) && '' !== $achado[3] ) {
				$saida[ $nome ] = $achado[3];
				continue;
			}

			if ( isset( $achado[4] ) && '' !== $achado[4] ) {
				$saida[ $nome ] = $achado[4];
				continue;
			}

			$saida[ $nome ] = isset( $achado[5] ) ? (string) $achado[5] : '';
		}

		return $saida;
	}

	/**
	 * Avança o cursor até a próxima tag que casa com a consulta.
	 *
	 * @param array<string,string> $consulta `tag_name` e `class_name`.
	 * @return bool
	 */
	public function next_tag( array $consulta = array() ): bool {
		$nome   = isset( $consulta['tag_name'] ) ? strtoupper( (string) $consulta['tag_name'] ) : '';
		$classe = isset( $consulta['class_name'] ) ? (string) $consulta['class_name'] : '';

		for ( $i = $this->atual + 1; $i < count( $this->tags ); $i++ ) {
			$tag = $this->tags[ $i ];

			if ( '' !== $nome && $tag['nome'] !== $nome ) {
				continue;
			}

			if ( '' !== $classe ) {
				$classes = is_string( $tag['atribs']['class'] ?? null ) ? preg_split( '/\s+/', (string) $tag['atribs']['class'] ) : array();

				if ( ! in_array( $classe, is_array( $classes ) ? $classes : array(), true ) ) {
					continue;
				}
			}

			$this->atual = $i;

			return true;
		}

		$this->atual = count( $this->tags );

		return false;
	}

	/**
	 * Valor de um atributo da tag atual.
	 *
	 * @param string $nome Nome do atributo.
	 * @return string|true|null
	 */
	public function get_attribute( string $nome ) {
		if ( ! isset( $this->tags[ $this->atual ] ) ) {
			return null;
		}

		$chave = strtolower( $nome );

		return array_key_exists( $chave, $this->tags[ $this->atual ]['atribs'] )
			? $this->tags[ $this->atual ]['atribs'][ $chave ]
			: null;
	}

	/**
	 * Escreve um atributo na tag atual.
	 *
	 * @param string $nome  Nome.
	 * @param mixed  $valor Valor.
	 * @return bool
	 */
	public function set_attribute( string $nome, $valor ): bool {
		if ( ! isset( $this->tags[ $this->atual ] ) ) {
			return false;
		}

		$this->tags[ $this->atual ]['atribs'][ strtolower( $nome ) ] = is_bool( $valor ) ? $valor : (string) $valor;

		return true;
	}

	/**
	 * Apaga um atributo da tag atual.
	 *
	 * @param string $nome Nome.
	 * @return bool
	 */
	public function remove_attribute( string $nome ): bool {
		if ( ! isset( $this->tags[ $this->atual ] ) ) {
			return false;
		}

		unset( $this->tags[ $this->atual ]['atribs'][ strtolower( $nome ) ] );

		return true;
	}

	/**
	 * Remonta o HTML com os atributos como estão agora.
	 *
	 * @return string
	 */
	public function get_updated_html(): string {
		$saida  = '';
		$cursor = 0;

		foreach ( $this->tags as $tag ) {
			$saida .= substr( $this->html, $cursor, $tag['inicio'] - $cursor );
			$saida .= $this->remontar( $tag );
			$cursor = $tag['inicio'] + $tag['tamanho'];
		}

		return $saida . substr( $this->html, $cursor );
	}

	/**
	 * Remonta uma tag de abertura a partir dos atributos.
	 *
	 * @param array<string,mixed> $tag Tag.
	 * @return string
	 */
	private function remontar( array $tag ): string {
		$partes = array( strtolower( (string) $tag['nome'] ) );

		foreach ( $tag['atribs'] as $nome => $valor ) {
			$partes[] = true === $valor ? $nome : $nome . '="' . htmlspecialchars( (string) $valor, ENT_QUOTES, 'UTF-8' ) . '"';
		}

		return '<' . implode( ' ', $partes ) . ( $tag['fecha'] ? ' />' : '>' );
	}
}

/* ---------------------------------------------------------------------------
 * Os arquivos REAIS do pacote
 * ------------------------------------------------------------------------ */

require $raiz . '/fontes/site-core/includes/class-f3base-options.php';
require $raiz . '/fontes/site-core/includes/class-f3base-modulo.php';
require $raiz . '/fontes/site-core/includes/class-f3base-modulo-leads-whatsapp.php';
require $raiz . '/fontes/tema/functions.php';

/* ---------------------------------------------------------------------------
 * Registro dos achados
 * ------------------------------------------------------------------------ */

$resultado = array();

/**
 * Registra um achado.
 *
 * @param string $checagem Checagem.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;

	$resultado[ $checagem ]              = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Conta uma unidade medida.
 *
 * @param string $checagem Checagem.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;

	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Afirma, contando a medida.
 *
 * @param string $checagem Checagem.
 * @param bool   $condicao Condição medida.
 * @param string $falha    Texto do achado quando a condição não vale.
 * @return void
 */
function afirmar( string $checagem, bool $condicao, string $falha ): void {
	medir( $checagem );

	if ( ! $condicao ) {
		anotar( $checagem, $falha );
	}
}

/**
 * Zera a bancada entre cenários.
 *
 * @return void
 */
function bancada_limpa(): void {
	$GLOBALS['f3b_tema']['options']      = array();
	$GLOBALS['f3b_tema']['politica_url'] = '';
}

/**
 * O parágrafo do rodapé, como o arquivo da part o entrega.
 *
 * @param string $href Valor do atributo `href`.
 * @return string
 */
function paragrafo_de_privacidade( string $href ): string {
	return '<p class="has-pequeno-font-size">Encarregado: dpo@exemplo.test. '
		. '<a class="f3base-link-privacidade" href="' . $href . '">Política de Privacidade</a></p>';
}

/* ==========================================================================
 * tema.link_privacidade_preserva
 *
 * DOIS DEFEITOS MEDIDOS na 1.0.19, no mesmo arquivo e na mesma função:
 * `functions.php:218-220` devolvia string VAZIA quando não havia política
 * publicada — apagando o parágrafo inteiro, com tudo o que estivesse nele — e
 * `:230` gravava o `href` sem olhar o que já estava ali.
 * ======================================================================= */

$nome = 'tema.link_privacidade_preserva';

bancada_limpa();

$bloco_paragrafo = array( 'blockName' => 'core/paragraph' );

/* PISO: a bancada reproduz o defeito? A função da 1.0.19, aqui, apaga tudo. */
$funcao_da_1_0_19 = static function ( string $conteudo, string $url ): string {
	if ( '' === $url ) {
		return '';
	}

	$processador = new WP_HTML_Tag_Processor( $conteudo );

	while ( $processador->next_tag( array( 'tag_name' => 'A', 'class_name' => 'f3base-link-privacidade' ) ) ) {
		$processador->set_attribute( 'href', $url );
	}

	return $processador->get_updated_html();
};

$paragrafo_com_pdf = paragrafo_de_privacidade( 'https://exemplo.test/politica.pdf' );

afirmar(
	$nome,
	'' === $funcao_da_1_0_19( $paragrafo_com_pdf, '' ),
	'piso: a bancada não reproduz o apagamento da 1.0.19 — sem política publicada a função antiga tem de devolver vazio, e sem isso o teto abaixo aprovaria por acaso'
);

afirmar(
	$nome,
	str_contains( $funcao_da_1_0_19( $paragrafo_com_pdf, 'https://exemplo.test/politica-de-privacidade/' ), 'politica-de-privacidade' ),
	'piso: a bancada não reproduz a sobrescrita da 1.0.19 — a função antiga tem de trocar o PDF pelo permalink, e sem isso o teto abaixo aprovaria por acaso'
);

/* TETO 1: sem política publicada, o PARÁGRAFO FICA e o link vira texto. */
$sem_politica = f3base_link_privacidade( paragrafo_de_privacidade( '#' ), $bloco_paragrafo );

afirmar(
	$nome,
	str_contains( $sem_politica, 'dpo@exemplo.test' ),
	'teto: sem política publicada o parágrafo INTEIRO foi apagado — junto com ele some o que o agente tiver escrito ali, e o remédio para não apontar para rascunho é tirar o href, não sumir com o texto'
);

afirmar(
	$nome,
	! str_contains( $sem_politica, 'href' ),
	'teto: sem política publicada o link continuou com href — apontar para uma página que não existe é aparência de conformidade'
);

afirmar(
	$nome,
	str_contains( $sem_politica, 'Política de Privacidade' ),
	'teto: o texto do link sumiu junto com o href — sem destino o link vira TEXTO, e o texto fica'
);

/* TETO 2: com política publicada e href do modelo, o permalink é PREENCHIDO. */
$GLOBALS['f3b_tema']['politica_url'] = 'https://exemplo.test/politica-de-privacidade/';
$com_politica = f3base_link_privacidade( paragrafo_de_privacidade( '#' ), $bloco_paragrafo );

afirmar(
	$nome,
	str_contains( $com_politica, 'href="https://exemplo.test/politica-de-privacidade/"' ),
	'teto: com política publicada o href do modelo não foi preenchido pelo permalink real — é para isso que o arquivo da part nasce com href="#"'
);

/* TETO 3: o href do AGENTE sobrevive, mesmo com política publicada. */
$com_pdf = f3base_link_privacidade( $paragrafo_com_pdf, $bloco_paragrafo );

afirmar(
	$nome,
	str_contains( $com_pdf, 'https://exemplo.test/politica.pdf' ),
	'teto do destino do agente: o href explícito para um PDF externo foi sobrescrito pelo permalink local — o valor que o agente escreveu vence o pacote, e a cada render a 1.0.19 desfazia a escolha dele'
);

afirmar(
	$nome,
	! str_contains( $com_pdf, 'politica-de-privacidade' ),
	'teto do destino do agente: o permalink local entrou no bloco mesmo com destino explícito'
);

/* PISO do alcance: parágrafo sem a classe passa intacto. */
$alheio = '<p class="has-pequeno-font-size"><a href="/blog/">Ler o blog</a></p>';

afirmar(
	$nome,
	$alheio === f3base_link_privacidade( $alheio, $bloco_paragrafo ),
	'piso do alcance: um parágrafo que não é o do aviso foi alterado — a regra vale para o link da política e para mais nada'
);

afirmar(
	$nome,
	paragrafo_de_privacidade( '#' ) === f3base_link_privacidade( paragrafo_de_privacidade( '#' ), array( 'blockName' => 'core/heading' ) ),
	'piso do alcance: bloco que não é parágrafo foi processado'
);

/* ==========================================================================
 * leads.cta_preserva_destino
 *
 * O DEFEITO MEDIDO na 1.0.19: `promover_cta()` suprimia QUALQUER bloco com a
 * classe do CTA quando o número estava vazio, e reescrevia o `href` sem checar
 * quando estava preenchido. Os quatro quadrantes abaixo são a regra nova.
 * ======================================================================= */

$nome = 'leads.cta_preserva_destino';

bancada_limpa();

/**
 * O bloco do CTA, como o pattern do tema o entrega, com o `href` escolhido.
 *
 * @param string $href Valor do atributo `href`.
 * @return string
 */
function bloco_do_cta( string $href ): string {
	return '<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
		. '<a class="wp-block-button__link wp-element-button" href="' . $href . '" '
		. F3Base_Modulo_Leads_Whatsapp::ATRIBUTO . '="cta">Falar com a equipe</a></div>';
}

$do_modelo  = bloco_do_cta( F3Base_Modulo_Leads_Whatsapp::HREF_DO_MODELO );
$do_agente  = bloco_do_cta( 'https://campanha.exemplo.test/lp-outubro' );
$telefonema = bloco_do_cta( 'tel:+551133334444' );

/* PISO: a bancada TEM o processador — sem ele, os dois quadrantes de promoção não existem. */
afirmar(
	$nome,
	class_exists( 'WP_HTML_Tag_Processor' ),
	'piso: a bancada não tem processador de HTML, e sem ele os quadrantes de promoção não são medidos'
);

$modulo_sem_numero = new F3Base_Modulo_Leads_Whatsapp();

/* QUADRANTE 1 — número vazio + href do modelo: NÃO é publicado. */
afirmar(
	$nome,
	'' === $modulo_sem_numero->promover_cta( $do_modelo, array() ),
	'quadrante 1: sem número e com o href do modelo, o CTA foi publicado — um botão que não leva a lugar nenhum é pior que não ter botão'
);

/* QUADRANTE 2 — número vazio + href do agente: publicado INTACTO. */
afirmar(
	$nome,
	$do_agente === $modulo_sem_numero->promover_cta( $do_agente, array() ),
	'quadrante 2: sem número, o CTA com destino próprio foi SUPRIMIDO ou alterado — era o defeito da 1.0.19, e é o inverso da premissa: a landing que o agente apontou sumia da página sem erro e sem log'
);

afirmar(
	$nome,
	$telefonema === $modulo_sem_numero->promover_cta( $telefonema, array() ),
	'quadrante 2 (tel:): sem número, o CTA com telefone próprio foi suprimido ou alterado'
);

/* QUADRANTE 3 — número preenchido + href do modelo: promovido. */
F3Base_Options::gravar( 'f3base_contato', array( 'whatsapp_e164' => '5511999999999' ), F3Base_Options::ORIGEM_MANUAL );
$modulo_com_numero = new F3Base_Modulo_Leads_Whatsapp();

$promovido = $modulo_com_numero->promover_cta( $do_modelo, array() );

afirmar(
	$nome,
	str_contains( $promovido, 'wa.me/5511999999999' ),
	'quadrante 3: com número gravado, o href do modelo não virou o link profundo — preencher a chave tem de fazer o botão levar à conversa na página seguinte, sem passo manual'
);

afirmar(
	$nome,
	str_contains( $promovido, F3Base_Modulo_Leads_Whatsapp::ATRIBUTO_NUMERO ),
	'quadrante 3: o link promovido não foi carimbado, e é o carimbo que diz ao cliente que aquele href é do pacote'
);

/* QUADRANTE 4 — número preenchido + href do agente: destino PRESERVADO. */
$preservado = $modulo_com_numero->promover_cta( $do_agente, array() );

afirmar(
	$nome,
	str_contains( $preservado, 'https://campanha.exemplo.test/lp-outubro' ),
	'quadrante 4: com número gravado, o destino do agente foi sobrescrito pelo wa.me — o pacote preenche quando falta e não manda no que já tem dono'
);

afirmar(
	$nome,
	! str_contains( $preservado, 'wa.me' ),
	'quadrante 4: o link do WhatsApp entrou por cima do destino do agente'
);

afirmar(
	$nome,
	! str_contains( $preservado, F3Base_Modulo_Leads_Whatsapp::ATRIBUTO_NUMERO ),
	'quadrante 4: o link com destino próprio foi carimbado como promovido pelo pacote, e o cliente vai reescrever o href dele no clique'
);

/* PISO do alcance: bloco que não é o CTA passa intacto, com e sem número. */
$bloco_alheio = '<div class="wp-block-button"><a class="wp-block-button__link" href="/blog/">Ler o blog</a></div>';

afirmar(
	$nome,
	$bloco_alheio === $modulo_com_numero->promover_cta( $bloco_alheio, array() )
		&& $bloco_alheio === $modulo_sem_numero->promover_cta( $bloco_alheio, array() ),
	'piso do alcance: um bloco que não é o CTA foi alterado — a regra vale para o CTA e para mais nada'
);

/* PISO da leitura do destino: `#` e vazio continuam sendo do modelo. */
bancada_limpa();
$modulo_de_novo_sem_numero = new F3Base_Modulo_Leads_Whatsapp();

afirmar(
	$nome,
	'' === $modulo_de_novo_sem_numero->promover_cta( bloco_do_cta( '#' ), array() ),
	'piso da leitura: href "#" foi lido como destino próprio — âncora vazia não é destino, e o botão continuaria publicado sem levar a lugar nenhum'
);

afirmar(
	$nome,
	F3Base_Modulo_Leads_Whatsapp::tem_destino_proprio( $do_agente ),
	'piso da leitura: o destino do agente não foi reconhecido pela varredura — é ela que decide a publicação na instalação sem processador de HTML'
);

afirmar(
	$nome,
	! F3Base_Modulo_Leads_Whatsapp::tem_destino_proprio( $do_modelo ),
	'piso da leitura: o href do modelo foi lido como destino próprio, e com isso o botão do template ficaria publicado sem número'
);

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
