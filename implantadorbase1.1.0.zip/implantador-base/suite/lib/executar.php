<?php
/**
 * Runner do comando único.
 *
 * Ordem fixa: empacotar primeiro, checar depois, resumir por último. O código de
 * saída vem da contagem que `estado()` acumulou — não de uma variável local que
 * alguém possa esquecer de atualizar.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$suite = dirname( __DIR__ );
$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );

require $suite . '/lib/regra.php';
require $suite . '/lib/empacotar.php';

foreach ( array( 'estatica', 'tema', 'conteudo', 'a11y', 'copy', 'entrega', 'funcional', 'bloqueadas', 'meta' ) as $modulo ) {
	require $suite . '/checagens/' . $modulo . '.php';
}

require $suite . '/lib/documentos.php';

if ( '' === $raiz ) {
	fwrite( STDERR, "uso: executar.php <caminho-do-pacote>\n" );
	exit( 2 );
}

/**
 * Emite o veredito de uma checagem, nos DOIS ramos.
 *
 * Toda checagem que varre alguma coisa devolve `medidas`: quantas unidades ela
 * de fato olhou. ESCOPO VAZIO NÃO APROVA — um prefixo de caminho digitado
 * errado faria a varredura percorrer zero arquivo e a linha sairia OK, que é o
 * instrumento mentindo com a melhor cara possível. Zero medida fecha BLOCKED.
 *
 * @param array{ok:bool,achados:array<int,string>,medidas?:int} $r      Veredito.
 * @param string                                                $nome   Nome.
 * @param string                                                $msg_ok Mensagem do ramo aprovado.
 * @param string                                                $classe Classe de evidência.
 * @param string                                                $fase   Fase.
 * @return void
 */
function emitir( array $r, string $nome, string $msg_ok, string $classe, string $fase ): void {
	if ( isset( $r['medidas'] ) && 0 === (int) $r['medidas'] ) {
		estado(
			'BLOCKED',
			$nome,
			'escopo vazio: a checagem não mediu nenhuma unidade, e o que não foi medido não pode ser aprovado.',
			'pendencia-externa',
			$fase
		);
		return;
	}

	$sufixo = isset( $r['medidas'] ) ? sprintf( ' (%d unidade(s) medida(s))', (int) $r['medidas'] ) : '';

	estado_por_origem(
		(bool) $r['ok'],
		'site',
		$nome,
		$msg_ok . $sufixo,
		count( $r['achados'] ) . ' achado(s) em ' . ( $r['medidas'] ?? '?' ) . ' unidade(s) medida(s): ' . f3b_amostra( $r['achados'] ),
		$classe,
		$fase
	);
}

/* =========================================================================
 * ETAPA 1 — EMPACOTAR. Sempre a primeira, e ela pode abortar a rodada.
 * ====================================================================== */

echo "== etapa 1: empacotamento ==\n";

if ( ! is_dir( $raiz ) ) {
	estado(
		'BLOCKED',
		'pacote.artefato',
		'o artefato a verificar não existe no caminho informado: ' . $raiz,
		'pendencia-externa',
		'build'
	);
	echo "\nrodada abortada: sem artefato não há o que empacotar nem o que verificar.\n";
	exit( 2 );
}

$lista = f3b_ck_allow_list( $raiz, $suite );
$fora  = array_values( array_filter( $lista['achados'], static fn( string $a ): bool => str_starts_with( $a, 'FORA DO INVENTÁRIO' ) ) );

if ( array() !== $fora ) {
	foreach ( $fora as $achado ) {
		fwrite( STDERR, 'EMPACOTAMENTO ABORTADO — ' . $achado . "\n" );
	}

	fwrite( STDERR, "o inventário de suite/inventario.tsv é a allow-list de caminhos: arquivo fora dela não entra no bundle.\n" );
	exit( 2 );
}

$build = f3b_empacotar( $raiz, $suite );

foreach ( $build['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

echo sprintf(
	"   documentos regenerados: %s\n",
	array() === $build['documentos'] ? '(nenhum: as regiões geradas já estavam iguais à leitura de disco)' : implode( ', ', $build['documentos'] )
);

echo sprintf(
	"   bundle: %s\n   embutidos: %s\n\n",
	'' !== $build['bundle'] && is_file( $build['bundle'] ) ? $build['bundle'] : '(não montado)',
	array() === $build['embutidos'] ? '(nenhum)' : implode( ', ', $build['embutidos'] )
);

echo "== etapa 2: checagens ==\n";

emitir(
	$lista,
	'pacote.allow_list',
	sprintf( 'todo arquivo do pacote consta do inventário de caminho→papel (%d caminho(s) exato(s) declarado(s)).', count( f3b_inventario( $suite )['exatos'] ) ),
	'analise-estatica',
	'build'
);

emitir(
	f3b_ck_build_fresco( $build['bundle'], $raiz ),
	'pacote.build_fresco',
	'o artefato de build é mais novo que toda fonte do pacote.',
	'medida',
	'build'
);

emitir(
	f3b_ck_backup_sempre_oculto( $raiz ),
	'pacote.backup_sempre_oculto',
	'nenhuma linha do pacote monta caminho de backup sem o ponto na frente da marca — o que constrói caminho vai por caminho_do_backup(), e o literal que só reconhece o nome antigo fica de fora, porque reconhecer é obrigação da migração.',
	'analise-estatica',
	'build'
);

emitir(
	f3b_ck_cabecalho_aninhado( $raiz ),
	'pacote.sem_cabecalho_de_plugin_aninhado',
	'a raiz tem exatamente um .php com "Plugin Name:" e nenhum .php a um nível de subdiretório tem cabeçalho de plugin — o alcance de get_plugins() enxerga um único candidato, e o link "Ativar plugin" da tela de instalação não tem para onde errar.',
	'analise-estatica',
	'build'
);

/* ---------- estáticas ---------- */

emitir( f3b_ck_php_lint( $raiz ), 'estatica.php_lint', 'todo .php do pacote analisa sob php -l.', 'analise-estatica', 'build' );
emitir( f3b_ck_json_valido( $raiz ), 'estatica.json_valido', 'todo .json do pacote analisa.', 'analise-estatica', 'build' );
emitir( f3b_ck_js_lint( $raiz, $suite ), 'estatica.js_lint', 'todo .js/.mjs do pacote passa em node --check.', 'analise-estatica', 'build' );
emitir( f3b_ck_wp_comentarios( $raiz, $suite ), 'estatica.wp_comentarios_balanceados', 'comentários wp: balanceados e JSON de atributo válido em templates, parts, conteúdo e patterns executados.', 'analise-estatica', 'build' );
emitir( f3b_ck_escrita_unica( $raiz ), 'estatica.detector_escrita_unica', 'nenhuma escrita de option fora dos dois gravadores declarados; varredura do pacote inteiro, inclusive a suíte.', 'analise-estatica', 'build' );
emitir( f3b_ck_version_compare( $raiz ), 'estatica.detector_version_compare', 'todo version_compare usa operador da lista fechada.', 'analise-estatica', 'build' );
emitir( f3b_ck_condicao_literal( $raiz ), 'estatica.detector_condicao_literal', 'nenhuma checagem com condição constante fora de ramo de if/else com irmão que emite outro veredito.', 'analise-estatica', 'build' );
emitir( f3b_ck_codigo_em_string( $raiz ), 'estatica.detector_codigo_em_string', 'nenhum JavaScript, SQL ou shell em heredoc ou concatenação PHP.', 'analise-estatica', 'build' );
/*
 * O QUE ESTE DETECTOR MEDE, dito com as palavras exatas — e a mudança da 1.0.18
 * é essa frase. Ele prova que toda chave declarada tem uma LINHA QUE A LÊ, e LER
 * NÃO É CONSUMIR: a chave lida cuja leitura não muda nada passa por aqui, e foi
 * o que aconteceu com `cadencia_relatorio.apos_n_ajustes` até a 1.0.17 — lida,
 * gravada numa option que ninguém relia, e impressa no relatório como gatilho
 * sobre um contador inexistente. Detector que mede a coisa errada é pior que
 * detector ausente, porque produz confiança; a saída foi parar de afirmar o que
 * ele não mede e acrescentar o irmão que mede a outra metade,
 * `estatica.option_gravada_sem_leitor`.
 */
emitir( f3b_ck_chave_sem_consumidor( $raiz ), 'estatica.detector_chave_sem_consumidor', 'toda chave de site.json tem uma LINHA QUE A LÊ (cruzamento geral, cobertura bidirecional). O que esta linha NÃO afirma: que a leitura muda alguma coisa — ler não é consumir, e quem mede a outra metade do trajeto é estatica.option_gravada_sem_leitor.', 'analise-estatica', 'build' );
emitir( f3b_ck_destino_de_formulario_resolve( $raiz ), 'estatica.destino_de_formulario_resolve', 'o destino declarado por cada regime de formulário é um CAMINHO, e todo caminho resolve numa chave que existe em config/site.json — entrada sem destino, caminho que não resolve e caminho que entra em formularios pelo índice de OUTRA entrada são achados. Caminho que não resolve devolve vazio em silêncio, e vazio é exatamente o valor que faz o regime "não existir": o estado sairia verde com uma instrução impossível, mandando preencher uma chave que não está no arquivo.', 'analise-estatica', 'build' );
emitir( f3b_ck_gate_de_fase_do_metadado( $raiz ), 'estatica.gate_de_fase_do_metadado', 'a lista de gates de FASE sai do metadado gate=fase e não de lista paralela: gates_de_fase() não traz nome de checagem literal, nenhum nome está nos dois gates ao mesmo tempo, e todo emissor de gate=fase nomeia a própria checagem com literal. Duas fontes para o mesmo fato divergem, e a divergência da 1.0.17 saiu impressa dentro de uma linha só do log.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_residuo_de_chave_removida( $raiz ), 'estatica.sem_residuo_de_chave_removida', 'toda chave declarada em suite/chaves-removidas.tsv saiu INTEIRA: não está em config/site.json, não está — nem é exigida — em config/site.schema.json, e nenhum token dela sobrou em código ou em documento fora dos arquivos onde a REMOÇÃO é narrada. Remover a chave da configuração é a parte fácil: o schema que continua exigindo-a reprova todo config correto, o consumidor órfão lê vazio em silêncio e o documento órfão ensina a preencher o que não existe mais — e o detector de chave sem consumidor não enxerga nada disso, porque ele cruza no sentido declarada → lida.', 'analise-estatica', 'build' );
emitir( f3b_ck_precondicao_no_eixo( $raiz ), 'estatica.precondicao_no_eixo', 'PRÉ-CONDIÇÃO DECLARADA mora no eixo de convergência e em nenhum outro gate: existe UM lugar fora de suite/ que deriva o gate a partir de precondicao, e nenhum emissor declara os dois no mesmo argumento. Até a 1.0.18 os metadados eram independentes e podiam discordar — dado que só o operador tem E gate de aplicação ao mesmo tempo —, e o preço estava medido: uma implantação de template limpo, que tinha dado certo, terminava com dois BLOCKED de gate de aplicação.', 'analise-estatica', 'build' );
emitir( f3b_ck_option_sem_leitor( $raiz ), 'estatica.option_gravada_sem_leitor', 'toda option do namespace declarado em site.prefixo_tecnico que o pacote GRAVA é lida de volta por alguma linha: gravar não é configurar, e option que ninguém relê é escrita sem consequência — foi por aí que apos_n_ajustes escapou do detector de chave sem consumidor.', 'analise-estatica', 'build' );
emitir( f3b_ck_plano_dependencias( $raiz ), 'estatica.plano_dependencias', 'todo grupo alvo de dependência do plano existe, nenhum depende de si mesmo e não há ciclo — a suspensão por fecho transitivo só pode ser calculada sobre um grafo que fecha.', 'analise-estatica', 'build' );
emitir( f3b_ck_placeholder( $raiz ), 'estatica.detector_placeholder', 'nenhum placeholder no conteúdo publicado.', 'analise-estatica', 'build' );
emitir( f3b_ck_simbolos_resolvem( $raiz ), 'estatica.simbolos_resolvem', 'todo método e constante F3Base_*:: chamados existem.', 'analise-estatica', 'build' );
emitir( f3b_ck_estados_fechados( $raiz ), 'estatica.estados_fechados', 'todo estado emitido pelo pacote pertence à lista fechada.', 'analise-estatica', 'build' );
emitir( f3b_ck_gate_fonte_unica( $raiz ), 'estatica.gate_fonte_unica', 'nenhum estado de gate da autodesativação é derivado em mais de um lugar: cada um é medido por uma função só, quem precisa dele depois lê o registro da execução recebendo o nome por parâmetro, o registro da rodada limpa tem um produtor só — o comando único — e nenhum veredito declarado como da SUÍTE é derivado também no implantador, nem sumiu da suíte.', 'analise-estatica', 'build' );
emitir( f3b_ck_option_fonte_unica( $raiz ), 'estatica.option_fonte_unica', 'nenhuma option gerenciada tem mais de um ponto do código produzindo o valor desejado sem passar pela função de união declarada: os nomes das options saem da âncora options_gerenciadas() e as uniões da âncora uniao_declarada(), as duas do próprio pacote; a varredura enxerga tanto a gravação direta quanto o nome dentro do mapa que um laço grava depois, com o nome escrito por literal ou por constante de classe; e união declarada para option inexistente ou apontando para função que ninguém definiu é achado, porque declaração que absolve sem medir é pior que nenhuma.', 'analise-estatica', 'build' );
emitir( f3b_ck_pagina_status_fonte_unica( $raiz ), 'estatica.pagina_status_fonte_unica', 'o status efetivo de página sai de um produtor só: a âncora produtor_de_status_de_pagina() do próprio pacote nomeia a função e o caminho da intenção, o caminho declarado tem um leitor só e ele passa pelo produtor, e todo post_status DESEJADO de página — o do wp_insert_post inclusive — chama o produtor em vez de escrever o literal; produtor declarado e ausente é achado, porque declaração que absolve sem medir é pior que nenhuma.', 'analise-estatica', 'build' );
emitir( f3b_ck_llms_so_pagina_publicada( $raiz ), 'estatica.llms_so_pagina_publicada', 'toda seleção de llms.txt sai de página PUBLICADA, nos DOIS produtores que a âncora declara — o item de f3base_llms e o ID de wpseo_llmstxt: um gate único mede o status no artefato, cada produtor passa por ele, e quem monta o valor de qualquer das duas options chama o produtor daquela option em vez de resolver a página por fora com localizar_gerenciado() ou get_permalink().', 'analise-estatica', 'build' );
emitir( f3b_ck_identidade_do_implantador( $raiz ), 'estatica.identidade_do_implantador', 'a identidade da release é a MESMA nos três lugares que a carregam: release.identidade e release.implantador em config/site.json, o cabeçalho Version: de implantador-base.php — que é o número que o WordPress mostra e o que f3base_imp_versao() prefere — e F3BASE_IMP_VERSAO_DECLARADA, o fallback de bootstrap que responde antes de get_plugin_data() existir. O MANIFESTO afirmava essa igualdade em linha própria e nada a media: na 1.0.17 a configuração foi para 1.0.17 com o cabeçalho em 1.0.16 e a constante em 1.0.15.', 'analise-estatica', 'build' );
emitir( f3b_ck_carimbo_de_release_nos_documentos( $raiz ), 'estatica.carimbo_de_release_nos_documentos', 'README, MANIFESTO e MEMORIA-DECISOES são entregáveis e carregam regiões GERADAS: cada uma traz os dois marcadores, o carimbo traz a identidade de release.identidade, e o conteúdo de cada região é igual ao que a leitura de disco produz agora — número digitado à mão em documento entregável envelhece calado, e foi o que aconteceu da 1.0.6 à 1.0.13.', 'analise-estatica', 'build' );
emitir( f3b_ck_politica_privacidade_fonte_unica( $raiz ), 'estatica.politica_privacidade_fonte_unica', 'a identidade da política de privacidade tem um produtor só, ela mora no papel declarado na entrada da própria página, e o produtor não lê caminho fora dessa raiz: nenhuma outra função carrega o literal do papel, ninguém lê o caminho aposentado da seleção de llms.txt, e é essa proibição — não o nome da chave — que impede uma seção alheia de silenciar a checagem exigida pelo art. 9º da LGPD.', 'analise-estatica', 'build' );
emitir( f3b_ck_contagem_com_nomes( $raiz ), 'estatica.contagem_com_nomes', 'nenhuma emissão de contagem por estado existe sem a lista de nomes correspondente na mesma saída — nem em PHP nem no cliente, nem dentro de função nem em escopo de arquivo.', 'analise-estatica', 'build' );
emitir( f3b_ck_unidade_reflete_internas( $raiz ), 'estatica.unidade_reflete_internas', 'nenhuma unidade fecha em estado menos severo do que a checagem de gate de APLICAÇÃO mais severa que ela emitiu: quem emite a linha de uma unidade passa o estado pelo helper único de severidade E olha o gate, a ordem FALHA > BLOCKED > WARN é declarada em um lugar só, o gate que decide sai da âncora do pacote, e nenhum registro de relatório traz unidade menos severa que uma checagem sua de aplicação.', 'analise-estatica', 'build' );
emitir( f3b_ck_warn_tem_ramo_adverso( $raiz ), 'estatica.warn_tem_ramo_adverso', 'nenhum WARN do runtime é retorno incondicional ou único: todo WARN de includes/ e fontes/ mora dentro de um ramo — if, elseif, else, foreach, for, while, switch, match ou ternário — ou depois de uma cláusula de guarda que pode impedi-lo, e é a condição desse ramo que mede o achado adverso. Medição sem achado adverso fecha OK com o detalhe no texto, que é a lição que a 1.0.14 pagou com quatro unidades amarelas numa execução em que nada estava errado.', 'analise-estatica', 'build' );
emitir( f3b_ck_troca_invalida_cache( $raiz ), 'estatica.troca_invalida_cache', 'a invalidação de cache pertence a quem TROCOU o diretório: a âncora do pacote nomeia trocador, invalidador, leitura de volta e as duas limpezas do núcleo; o trocador chama o invalidador; o invalidador chama as duas limpezas — as mesmas que Theme_Upgrader::install() e Plugin_Upgrader::install() fazem —; e toda função que chama o trocador relê o artefato pela leitura de volta declarada, em vez de perguntar à API por fora dela e voltar a dizer "não apareceu no disco" sobre diretório que está no disco.', 'analise-estatica', 'build' );
emitir( f3b_ck_artefato_do_pacote_e_lido( $raiz ), 'estatica.artefato_do_pacote_e_lido', 'nenhum artefato instalável viaja no pacote sem um caminho de instalação que o leia: todo .zip do pacote está sob um dos prefixos que a constante do próprio pacote declara, e quem INSTALA e quem PROVA o entregável passam pelo MESMO resolvedor, sem montar caminho de artefato por conta própria — a segunda lista é o que faz o entregável provar um artefato enquanto a instalação usa outro.', 'analise-estatica', 'build' );
emitir( f3b_ck_afirmacoes( $raiz ), 'doc.afirmacao_conferida', 'toda AFIRMAÇÃO DE COMPORTAMENTO declarada em suite/afirmacoes.tsv está no documento que a faz E bate com o fato medido no pacote. É o detector que faltava: os outros conferem identidade de release e números gerados, e nenhum conferia uma frase contra o comportamento — foi por essa fresta que passaram cinco dos vinte e dois achados da 1.0.17, três deles refutados pela configuração do mesmo zip.', 'analise-estatica', 'build' );
emitir( f3b_ck_piso_em_sonda_declarado( $suite ), 'estatica.piso_em_sonda_declarado', 'toda checagem cujo piso é declarado em suite/pisos-em-sonda.tsv se sustenta: a sonda declarada existe, menciona a checagem e traz os DOIS ramos — teto e piso. É o piso da regra do piso: sem ele, uma linha de tabela declararia coberta qualquer checagem, que é a doença que armadilhas.mapeadas existe para impedir um nível acima.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_recusa_de_escrita_do_agente( $raiz ), 'estatica.sem_recusa_de_escrita_do_agente', 'nenhum arquivo do RUNTIME do pacote registra literal de filtro de options protegidas do servidor MCP: depois da instalação quem modifica o site é o agente, pelo canal, e um pacote que peça ao canal para recusar a escrita das próprias options é o pacote impedindo exatamente o que ele existe para permitir. A 1.0.19 registrava as vinte options do catálogo em quatro filtros do servidor; o módulo saiu inteiro na 1.1.0 e este detector existe para que ele não volte por outro nome.', 'analise-estatica', 'build' );
emitir( f3b_ck_resposta_de_lote_nomeada( $raiz ), 'estatica.resposta_de_lote_nomeada', 'toda resposta de lote que a tela renderiza traz as chaves que a âncora declara — rótulo, para a linha não sair anônima e a contagem por estado não ficar sem a lista de nomes; estado da aplicação, para o rodapé não fechar em branco —, e o emissor só recebe carga do produtor declarado ou do produtor de reserva, que é o único lugar onde uma resposta "não rodou" se monta.', 'analise-estatica', 'build' );
emitir( f3b_ck_serie_de_backup( $raiz, $suite ), 'plugins.serie_de_backup_normalizada', 'a chave da série de cópias preservadas colapsa a marca de backup embutida, exercitando a MESMA função do runtime: a cópia simples, o nome medido no site real — backup de um diretório que já era backup —, o aninhamento duplo e o plugin de terceiro caem cada um na série do slug REAL, com o carimbo EXTERNO; quatro cópias fecham duas séries, com três no artefato do pacote, que é a contagem que o teto de plugins.backups_preservados compara; e nome que não é cópia preservada continua fora.', 'teste-funcional', 'build' );

/*
 * O resíduo de prefixo emite o ESTADO QUE MEDIU: N/A enquanto o pacote for o
 * próprio template (a condição de aplicabilidade sai declarada, nunca some),
 * OK quando nenhuma grafia sobrou fora das exceções, FALHA nomeando arquivo e
 * ocorrências quando sobrou. Renomeação que não é conferida é renomeação que
 * ninguém sabe se aconteceu inteira.
 */
$residuo = f3b_ck_sem_residuo_de_prefixo( $raiz );

estado(
	$residuo['estado'],
	'estatica.sem_residuo_de_prefixo',
	$residuo['motivo'],
	'analise-estatica',
	'build'
);

/* ---------- configuração ---------- */

emitir( f3b_ck_slug_declarado( $raiz ), 'config.slug_declarado', 'toda entrada de paginas e posts declara slug não vazio, e nenhum slug se repete entre elas.', 'analise-estatica', 'build' );

/* ---------- tema ---------- */

emitir( f3b_ck_zero_com_unidade( $raiz, $suite ), 'tema.zero_com_unidade', 'nenhum zero sem unidade onde o valor vira custom property; styles.blocks.* fora do escopo, por desenho.', 'analise-estatica', 'build' );
emitir( f3b_ck_preset_ocioso( $raiz, $suite ), 'tema.preset_ocioso', 'todo preset declarado no theme.json tem consumidor no tema.', 'analise-estatica', 'build' );
emitir( f3b_ck_preset_inexistente( $raiz, $suite ), 'tema.preset_inexistente', 'nenhuma referência a preset que não existe.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_cor_literal( $raiz ), 'tema.sem_cor_literal', 'nenhuma cor literal em .css/.html/.php/.svg do tema, SVG inline incluído; fontes/tema/CONTRASTE.md fica fora por ser documentação, não artefato servido.', 'analise-estatica', 'build' );
emitir( f3b_ck_wp_html_declarado( $raiz, $suite ), 'tema.wp_html_declarado', 'todo wp:html do tema consta de tema.wp_html_excecoes com motivo, e nenhum dentro de navegação.', 'analise-estatica', 'build' );
emitir( f3b_ck_main_layout_default( $raiz, $suite ), 'tema.main_layout_default', 'todo main declara layout default — nunca constrained.', 'analise-estatica', 'build' );
emitir( f3b_ck_landing_sem_navegacao( $raiz ), 'tema.landing_sem_navegacao', 'o template de landing existe, está declarado em theme.json como declarável por página, NÃO traz navegação — nem direta nem por template-part, resolvida recursivamente — e traz o controle de consentimento, que é o instrumento permanente do titular e precisa existir em toda página publicada, inclusive na que não tem menu.', 'analise-estatica', 'build' );
emitir( f3b_ck_versao_assets( $raiz ), 'tema.versao_assets', 'nenhuma constante PHP com o número literal da versão; a versão deriva de wp_get_theme().', 'analise-estatica', 'build' );

/* ---------- conteúdo ---------- */

emitir( f3b_ck_sem_estilo_avulso( $raiz, $suite ), 'conteudo.sem_estilo_avulso', 'o conteúdo publicado só referencia preset.', 'analise-estatica', 'build' );
emitir( f3b_ck_headings( $raiz, $suite ), 'conteudo.headings', 'um H1 por template, sem salto de nível, conteúdo começando em H2.', 'analise-estatica', 'build' );

/*
 * As duas checagens do conteúdo demonstrativo emitem o ESTADO QUE MEDIRAM — OK
 * ou WARN —, e é por isso que elas não passam por `emitir()`, que só conhece
 * aprovado e reprovado. A regra do WARN é a da 1.0.15: ele só sai com achado
 * adverso nomeado, e aqui o achado é concreto — o site do template indo ao ar
 * como site de cliente, ou a declaração e o disco discordando arquivo a arquivo.
 */
foreach ( array( 'conteudo.demonstrativo' => f3b_ck_conteudo_demonstrativo( $raiz ), 'conteudo.marca_demonstrativa' => f3b_ck_marca_demonstrativa( $raiz ) ) as $nome_demonstrativo => $veredito_demonstrativo ) {
	if ( 0 === (int) $veredito_demonstrativo['medidas'] ) {
		estado( 'BLOCKED', $nome_demonstrativo, 'escopo vazio: nenhum arquivo de content/ foi medido, e o que não foi medido não pode ser aprovado.', 'pendencia-externa', 'build' );
		continue;
	}

	estado(
		$veredito_demonstrativo['estado'],
		$nome_demonstrativo,
		$veredito_demonstrativo['motivo'] . sprintf( ' (%d unidade(s) medida(s))', (int) $veredito_demonstrativo['medidas'] ),
		'analise-estatica',
		'build'
	);
}

/* ---------- acessibilidade ---------- */

$contraste = f3b_ck_contraste( $raiz, $suite );

estado_por_origem(
	(bool) $contraste['ok'],
	'site',
	'a11y.contraste',
	sprintf( '%d par(es) texto/fundo em uso recalculado(s) da paleta do theme.json; todos acima do piso AA (4,5:1 texto, 3:1 não-texto).', (int) $contraste['total'] ),
	count( $contraste['achados'] ) . ' par(es) abaixo do piso: ' . f3b_amostra( $contraste['achados'] ),
	'medida',
	'build'
);

/* ---------- copy ---------- */

emitir( f3b_ck_copy_contrato( $raiz ), 'copy.contrato', 'as frases obrigatórias estão nas páginas declaradas, na grafia declarada, e as proibidas não aparecem em lugar nenhum do pacote.', 'analise-estatica', 'build' );

/* ---------- funcionais ---------- */

$rotulos_funcionais = array(
	'config.schema_valida'                  => 'o site.json valida e cada mutante declarado reprova — teto e piso do validador, com um mutante por chave nova: as da 1.0.17 (o enum de permalinks, o enum da decisão sobre o conteúdo de exemplo do WordPress e a ausência dessa chave obrigatória) e as da 1.0.18 (o alfabeto do nome do cabeçalho de origem confiável e o mínimo dos saltos de proxy, que não pode ser zero).',
	'conteudo.merge_tres_vias'              => 'a tabela de decisão do merge de três vias do CONTEÚDO inteira, linha por linha, com o ramo que a 1.1.0 inverteu: base ≠ observado ≠ desejado com política gerenciado PRESERVA — até a 1.0.19 gravava, e era o conteúdo do template apagando o do cliente a cada reexecução. O piso é a regra inteira e não uma linha: existindo base, nenhuma política pode produzir gravação sobre objeto que quem opera o site já editou.',
	'options.merge_tres_vias'               => 'a regra de três vias das OPTIONS, os cinco ramos e as frases de cada um: observado igual ao desejado não grava; base igual ao observado é atualização segura; base igual ao desejado com observado diferente PRESERVA a edição feita pelo canal; os três diferentes gravam NOMEANDO a sobreposição com os dois valores; e sem base a primeira execução aplica o desejado DIZENDO que a base nasceu agora. A impressão que decide é a mesma da leitura de volta — tolerante ao round-trip da camada de options e nada além dele —, e a linha do relatório nomeia option e valores em vez de contá-los.',
	'cadencia.recorrencia_declarada'        => 'a decisão da recorrência da cadência, com o site-core na tabela do agendador e sem ele: sem ele a queda para daily acontece e sai NOMEADA com a recorrência declarada que faltava; com ele a recorrência agendada é a DECLARADA, e quinzenal não cai em weekly (que dobraria a frequência combinada). A queda de uma execução anterior é REPARADA quando a declarada passa a existir, e o alcance do reparo é estreito: recorrência que não é a nossa queda não é desfeita, e evento já correto não é reagendado.',
	'conteudo.nao_promocao_status'          => 'a ordem de publicidade dos status sustenta a regra de não promoção.',
	'relatorio.waiver_casa'                 => 'casamento de waiver por igualdade e por prefixo, e os cinco curingas que não podem casar.',
	'relatorio.sanitiza_dump'               => 'a sanitização alcança o dado sensível por dentro do serializado e preserva o resto.',
	'gravador.leitura_de_volta_equivalente' => 'a equivalência reconhece o round-trip da camada de options e continua reprovando valor diferente.',
	'formulario.veredito_destino'           => 'o regime de formulário é DERIVADO do valor do destino, e não de um interruptor: destino vazio fecha N/A com a condição declarada — nomeando a chave a preencher e dizendo que o CTA não é publicado, nem no comportamento degradado —, destino preenchido e no formato do regime fecha OK, destino PREENCHIDO e fora do formato continua FALHA, entrada sem destino declarado é FALHA da própria entrada, e nenhuma entrada declarada traz o interruptor de volta.',
	'relatorio.nomeia_o_que_nao_fecha_ok'   => 'checagem em FALHA ou WARN dentro de unidade que fecha OK sai NOMEADA no recorte da unidade, na lista por estado e no resumo; OK continua resumido e a contagem não é substituída pela lista.',
	'entrega.rodada_limpa_confere'          => 'o leitor do registro da rodada limpa, nos dois ramos: hash casado fecha OK com evidência importada/build, hash divergente e registro ausente são acusados nomeando o esperado e o encontrado.',
	'entrega.gates_separados'               => 'o gate de aplicação lista os oito entregáveis e NÃO inclui a rodada limpa; o gate de fase a inclui, aparece nomeado no motivo e não proíbe a autodesativação; e o caminho de falha continua intacto — FALHA real, cada um dos oito entregáveis em BLOCKED (um a um) e qualquer dos dois vereditos de canal em aberto mantêm o implantador ativo, com o motivo nomeando o que segurou; e a linha de uma UNIDADE em BLOCKED não decide o gate, que é o que mantém a autodesativação possível depois que a unidade passou a refletir as internas.',
	'preflight.artefato_do_pacote_e_baseline' => 'os artefatos do pacote — site-core, tema e implantador — são baseline por definição, resolvidos dos slugs DECLARADOS na configuração: com eles ativos e nada mais a baseline fica em silêncio, plugin de terceiro ativo e não declarado é acusado nomeando, e o mesmo plugin declarado em plugins.operacionais sai da acusação com finalidade e responsável.',
	'tema.override_por_conteudo'            => 'override do editor de site é decidido por CONTEÚDO: stub vazio e post idêntico ao arquivo do tema ficam em silêncio, com o motivo registrado, settings ou styles preenchidos são acusados, e o tamanho do post não decide nada.',
	'mcp.canal_unico_mede_plugins_ativos'   => 'a checagem mede PLUGINS DE CANAL ATIVOS, que é a pergunta com resposta: um complemento ativo fecha OK nomeando-o e SEM a frase da consequência, dois (o declarado mais uma cópia com outro slug e o mesmo Plugin Name) fecham FALHA nomeando os dois diretórios e os dois arquivos principais, nenhum fecha BLOCKED, censo indisponível fecha BLOCKED com a frase da Abilities API, e cópia inativa ou oculta não conta.',
	'lotes.unidade_reflete_internas'        => 'o veredito da unidade é o mais severo entre o dela e as internas de gate de APLICAÇÃO, pelo caminho real de processar(): OK contendo FALHA, BLOCKED ou WARN de aplicação é promovido nomeando a checagem; OK contendo N/A continua OK; BLOCKED ou FALHA de FASE não promove e sai nomeado como pendência no texto da unidade; gate ausente ou vazio promove como aplicação, para que a omissão não absolva; e a ordem FALHA > BLOCKED > WARN, com N/A, OK e WAIVED empatados em zero, sai de um lugar só.',
	'lotes.permalinks_decisao'              => 'a decisão de permalinks MEDE antes de decidir, em todos os ramos: aplicar-e-cobrir — o padrão do template — APLICA e COBRE, gravando 301 do caminho antigo de todo publicado que muda de endereço, gerenciado ou não, e a mensagem NOMEIA cada URL coberta em vez de contá-las; o publicado não gerenciado cujo endereço é de query não ganha par, e a mensagem diz que seria laço; aplicar-se-seguro com todo publicado gerenciado APLICA sem cobrir terceiro, e com um publicado não gerenciado de URL de caminho fecha BLOCKED nomeando o objeto (id, tipo, slug e caminho) e apontando aplicar-e-cobrir como saída; manter-existente fecha BLOCKED mesmo com tudo gerenciado; aplicar-declarada aplica registrando o risco assumido e NÃO coberto; estrutura já igual à declarada fecha OK sem gravação, e a igualdade vence a decisão nos quatro valores; valor não reconhecido não vira aplicação nem recusa silenciosa; nenhum publicado não gerenciado some da classificação; a chave de cobertura é ela mesma piso — só aplicar-e-cobrir a liga —, o par do publicado não gerenciado é chaveado pelo ID e entra na união pelo produtor único com a contagem por origem batendo, e a regra do par grava 301 do caminho antigo para o novo e descarta o caminho que não mudou, que seria laço.',
	'conteudo.exemplo_do_wordpress'         => 'o conteúdo de exemplo do WordPress é decidido por DISCRIMINANTE e nunca por slug: só vai para a LIXEIRA — reversível, nunca exclusão definitiva — o objeto que AINDA É o que wp_install_defaults() criou, com título e conteúdo idênticos ao que o núcleo escreveria agora E post_modified_gmt sem avançar em relação a post_date_gmt; o piso NEGATIVO é o que importa e está plantado nos três lugares (título, conteúdo e os dois), e nenhum deles pode produzir remoção; objeto gerenciado por este pacote e objeto EM USO como página inicial, página de posts ou política de privacidade ficam mesmo intocados; o par tipo/slug só INDEXA a hipótese — tipo trocado, slug de fora e slug vazio não casam com entrada nenhuma —, e todo veredito carrega o discriminante que o relatório imprime.',
	'lotes.indexacao_consequencia'          => 'a checagem de indexação nomeia a CONSEQUÊNCIA junto com a causa: no ramo não indexável diz que o aviso "Problema grave de SEO" do wp-admin é esperado, que ele não é suprimido, e exatamente o caminho de saída da 1.0.12 — sumir a causa medida ou declarar ambiente.indexar = "forcar" —, sem mandar preencher a lista de domínios, que deixou de ser condição; no ramo indexável nenhum dos dois textos aparece.',
	'lotes.indexacao_veredito'              => 'o ônus da indexação está invertido e medido nos dois lados: produção limpa com HTTPS indexa sem configuração nenhuma; wp_get_environment_type() em staging, home_url() em HTTP puro, ambiente.tipo diferente de producao e host casando com sufixo declarado em ambiente.dominios_de_previa seguram a indexação em WARN, cada um nomeando a guarda, o valor observado e como forçar; wp_get_environment_type() fora dos três valores declarados (production, vazio, nome inventado pela hospedagem) NÃO segura, que é o piso do falso positivo; lista de prévia vazia não segura nada, e o casamento é por sufixo de domínio, nunca por trecho; forcar com guarda ativa indexa registrando o motivo por que a decisão existia e sem guarda alguma registra a decisão como inerte; nunca não indexa dizendo que é escolha; modo não reconhecido cai para medir; e a lista de domínios autorizados é cross-check — host fora dela indexa e sai o WARN nomeando o host observado e a lista declarada, lista vazia fecha N/A.',
	'lotes.redirects_uniao'                 => 'f3base_redirects tem fonte composta e ordem declarada, exercitada nos dois lados: configuração vazia NÃO apaga o par computado pela troca de permalinks (o defeito medido no banco depois da 1.0.11), as três fontes somam com a contagem por origem, a execução seguinte preserva o computado pela anterior, o par removido da configuração desaparece, par sem destino não entra, o registro carimba a etapa de origem e é esquecível, e colisão de origem entre um par declarado e um computado fecha FALHA nomeando os dois destinos, com o declarado prevalecendo no valor gravado — nunca sobrescrita silenciosa.',
	'privacidade.controlador_identificado'  => 'a identificação do controlador na política tem os TRÊS ramos separados e provados: chave de contato.controlador vazia é BLOCKED nomeando quais faltam e o caminho de saída — preencher e reexecutar, a página publica sozinha na execução seguinte, sem passo manual —, chaves completas com a qualificação presente no conteúdo servido é OK por leitura de volta, e chaves completas com o valor AUSENTE do conteúdo, ou com marcador não resolvido sobrevivendo nele, é FALHA, porque aí a guarda liberou a publicação e a política está no ar sem dizer quem trata os dados; o produtor único de status segura só a página que a configuração aponta como política, nunca promove o que foi declarado draft, e o arquivo REAL da política é interpolado ponta a ponta, com as duas redações do encarregado se excluindo.',
	'conteudo.guarda_de_marca'              => 'a guarda de publicação cruza a DECLARAÇÃO com o ARQUIVO nos dois lados: chave desligada com a marca do template no topo do arquivo recusa a publicação nomeando o arquivo, a marca e as duas saídas; chave ligada com ou sem marca publica; arquivo já substituído publica; a marca é montada do prefixo declarado, muda com ele e não existe sem ele.',
	'preflight.limites_veredito'            => 'o estado de preflight.limites SAI DA MEDIÇÃO, nos dois lados: limites folgados fecham OK NOMEANDO os valores observados, cada limite abaixo do piso declarado em ambiente.limites_minimos fecha WARN nomeando qual ficou abaixo e o que ele custa, um achado por limite, e max_execution_time = 0 é ausência de limite — nunca limite zero —, que é o piso do falso positivo.',
	'lotes.encerramento_por_estado'         => 'o parágrafo final do encerramento é condicional ao estado: o texto de falha — permanece ativo, retomada idempotente, rollback — não aparece em SUCESSO_APLICACAO, o texto de sucesso não aparece em FALHA_PARCIAL nem em FALHA, e o sucesso diz se o implantador se autodesativou e o que o operador usa a partir de agora (a tela do site-core e o canal MCP).',
	'instalacao.limpa_le_de_volta'          => 'a INSTALAÇÃO LIMPA é exercitada de verdade, tema e site-core, contra um WordPress cujo cache memoriza o negativo como o de verdade: o alvo começa INEXISTENTE, a consulta prévia acontece na mesma requisição e memoriza que não existe, e aí a troca de diretório roda. Com a invalidação DESLIGADA a API tem de continuar cega — é o que prova que a bancada reproduz o defeito da 1.0.15 em vez de aprovar por não ter cache — e a unidade fecha FALHA nomeando DEFEITO DE CACHE, nunca "não apareceu no disco"; com ela ligada a leitura de volta enxerga o artefato, a unidade fecha OK e o tema fica ativo. A ORDEM também é medida na fita de eventos da bancada: leitura de disco antes, invalidação no meio, leitura de disco de novo depois.',
	'instalacao.disco_ou_cache'             => 'o discriminante da leitura de volta, a tabela inteira e nos dois tipos: diretório ausente diz "não apareceu no disco" e não fala em cache; diretório presente sem o arquivo principal é um terceiro fato, com mensagem própria; diretório presente e completo com a API discordando é DEFEITO DE CACHE nomeado como tal e nunca a mensagem de disco; tudo presente com a API enxergando fecha ok; e a API MANDA no "está instalado" — artefato que ela enxerga fora do caminho medido fecha ok registrando o fato, que é o piso do falso positivo em site com mais de uma raiz de temas.',
	'instalacao.artefato_fonte_unica'       => 'a fonte única do artefato de cada papel devolve o slug DECLARADO, a lista de candidatos com o slot de zip do operador, um caminho que existe e que mora dentro do pacote; papel não declarado não inventa artefato nenhum.',
	'leads.limite_por_caractere'            => 'o limite de campo do endpoint é medido na MESMA unidade que o cliente corta — caracteres, nunca bytes: um nome com o número exato de caracteres acentuados é ACEITO, um caractere acima é recusado nomeando a unidade, e a mesma unidade vale dentro de atribuicao. O piso planta o defeito: o texto acentuado no limite EXCEDE em bytes, e é por isso que o servidor devolvia 400 no lead que a própria página tinha aprovado.',
	'leads.email_conclusivo'                => 'e-mail inválido é RECUSADO nomeando o campo, e-mail válido passa e e-mail vazio continua sendo campo opcional ausente. O piso planta o defeito: sanitize_email() devolve string vazia para entrada inválida, e sem conferir o retorno o lead entrava sem endereço nenhum respondendo 201.',
	'leads.booleano_explicito'              => 'o campo booleano tem parser explícito com vocabulário fechado: "false", "0", "", "no", "nao" e "off" valem FALSO, estrutura no lugar de escalar é recusada, valor acima do limite declarado é recusado — o max de 8 deixou de ser letra morta — e valor fora do vocabulário é recusado em vez de adivinhado. O piso planta o defeito: (bool) "false" é true nesta linguagem, e o campo que passava por esse molde era o consentimento.',
	'leads.reserva_compensada'              => 'a reserva de deduplicação nasce PENDENTE, vira firme depois da persistência e é compensada na falha: depois de uma falha de armazenamento a segunda tentativa com o mesmo correlation_id é ACEITA, o replay de uma correlação já gravada continua recusado, a reserva pendente abandonada é retomada uma vez só, e o caminho de contingência por transiente tem a mesma compensação. O piso planta o defeito: sem compensação a reserva sobrevive à falha e bloqueia por 30 dias quem tentou de novo.',
	'leads.atividade_so_com_persistencia'   => 'a atividade "último registro aceito" só é carimbada quando a gravação aconteceu; a recusa deixa carimbo PRÓPRIO nomeando os destinos que recusaram, e o módulo fecha degradado enquanto a tentativa mais recente não tiver entrado. O piso planta o defeito: sem o ramo separado a tela afirmava "último lead registrado" apontando para onde nada foi escrito.',
	'leads.status_da_gravacao'              => 'gravação recusada responde 5xx com código e com o que o visitante deve fazer, nunca 201 Created com ok:false; gravação aceita responde 201 com registrado verdadeiro. O piso planta o defeito: 201 diz que o recurso existe, e nenhum backend tinha aceitado o lead.',
	'leads.rate_limit_atomico'              => 'o incremento do balde é UMA instrução no banco e quem soma é ele: cinco incrementos sob leitura congelada devolvem 1, 2, 3, 4 e 5, sem SELECT antes, e a janela vencida reinicia o balde. O piso planta o defeito: sob a MESMA leitura congelada o caminho de ler-modificar-gravar devolve 1 e 1, que é o incremento perdido sob concorrência.',
	'leads.origem_declarada'                => 'a origem do balde vem de REMOTE_ADDR até que a configuração declare um cabeçalho de proxy: sem declaração o cabeçalho é IGNORADO, com declaração ele é lido descontando os saltos confiáveis da direita, o valor que o visitante empurra na frente da cadeia não vira origem, cadeia curta ou valor que não é IP volta para REMOTE_ADDR, e dois visitantes atrás do mesmo proxy caem em baldes distintos. O piso planta o defeito: sem a declaração, o balde de 20 por janela valia para o proxy inteiro.',
	'cadencia.ouvinte_registrado'           => 'o hook f3base_cadencia_relatorio TEM ouvinte depois do registro único, e as recorrências quinzenal e mensal existem com quinze e trinta dias; o agendamento sai com a recorrência DECLARADA e a divergência entre a agendada e a declarada fecha degradado NOMEANDO as duas. O piso planta o defeito: o núcleo do WordPress não tem monthly nem quinzenal, e sem ouvinte o evento dispara, o WP-Cron o reagenda e nada acontece.',
	'cadencia.execucao_registrada'          => 'a execução registra última execução, gatilho, resultado, erro, duração, atraso, próxima, os módulos por estado COM os nomes e a releitura das options; a medição que explode vira resultado erro nomeado e degrada o módulo; e evento atrasado vira atraso medido e degradação. O piso planta os dois defeitos: previsão no passado e medição que lança exceção.',
	'plugins.digesto_do_artefato'           => 'o digesto do artefato baixado tem os TRÊS ramos separados e provados: declarado e batendo instala nomeando o sha256; declarado e divergindo NÃO instala e nomeia os dois valores; ausente é medido e FIXADO na primeira observação, com a mensagem dizendo com todas as letras o que isso protege (a origem não muda embaixo das execuções seguintes) e o que NÃO protege (esta busca) — e a execução seguinte com digesto diferente do fixado não instala. O piso planta o defeito: a URL declarada aponta para uma ref mutável e, até a 1.0.17, nenhum hash era conferido.',
	'plugins.https_em_todo_salto'           => 'HTTPS é obrigatório em TODOS os saltos, e a guarda medida é a do pacote, alcançada por reflexão: cadeia inteira em https resolve e devolve o endereço final mesmo trocando de host, salto que CAI PARA HTTP não baixa nada e nomeia o esquema observado, URL declarada em http é recusada antes de qualquer busca, endereço sem host legível não abre conexão e cadeia sem fim é abandonada no teto. O piso planta os defeitos: download_url() seguia o redirecionamento sozinho, e conferir só a URL declarada deixaria a guarda valendo para um endereço que ninguém baixa.',
	'plugins.autoupdate_alcance_separado'   => 'flag ligada e fonte alcançável saem separadas: origem url, origem bundle e artefato do próprio pacote são classificados SEM FONTE — o servidor do canal junto com o complemento, que era o esquecido da ressalva do README —, origem wordpress.org e plugin operacional saem como PENDÊNCIA NOMEADA porque decidir exigiria rede, e o veredito é BLOCKED com pendência, WARN com plugin sem fonte e OK só quando todos têm fonte medida. O piso planta o defeito: a flag era conferida contra si mesma e o relatório afirmava alcance para nove plugins dos quais cinco não têm fonte.',
	'mcp.autoteste_veredito'                => 'o autoteste do canal tem teto e piso: rota presente que responde 2xx sem item reprovado fecha OK, rota AUSENTE fecha BLOCKED e nunca OK, e rota que responde reprovando — booleano falso, lista de falhas não vazia, status de erro ou código fora de 2xx — fecha FALHA, que é o que reprova a entrega; recusa por credencial (401/403) é BLOCKED e não FALHA, porque a via interna não carrega credencial. O piso planta o defeito: o README afirmava desde a 1.0.6 que files/selftest rodava na entrega, e o pacote não tinha uma única chamada de execução de rota ou de habilidade.',
	'relatorio.contagem_colada_no_estado'   => 'cada número do resumo por estado sai COLADO ao estado que ele conta, e os nomes de um estado não viajam dentro do segmento de outro. O piso planta o defeito da 1.0.17: a linha do encerramento imprimia "5 em FALHA: nenhum · BLOCKED: … · WARN: …" — o 5 era FALHA MAIS BLOCKED somados, encostava no primeiro estado da string, e a mesma string listava WARN, que não estava nos cinco.',
	'lotes.convergencia_terceiro_eixo'      => 'o terceiro eixo separa execução terminada de estado convergido: pré-condição declarada em BLOCKED torna a convergência PENDENTE, em FALHA torna NÃO CONVERGIDA, BLOCKED que não é pré-condição e WARN de pré-condição não movem o eixo, e o encerramento diz em uma frase o que falta e como sair. E a AUTODESATIVAÇÃO continua amarrada ao gate de aplicação, com piso: com o gate inteiro em OK ela acontece mesmo com a convergência pendente — amarrá-la ao eixo prenderia o pacote a dado que só o operador tem. O piso planta o defeito: privacidade.controlador_identificado e formulario.contato-whatsapp fechavam BLOCKED e não entravam em lista nenhuma.',
	'lotes.gate_de_aplicacao_sem_dado_do_operador' => 'o CRITÉRIO DE ACEITE da 1.0.19, medido pelo emissor REAL: linha declarada como pré-condição sai no gate de CONVERGÊNCIA e nunca no de aplicação, o gate de FASE continua separado dela, um template intocado não deixa nada em BLOCKED no gate de aplicação, a unidade não é promovida por nenhuma das duas e as duas saem NOMEADAS na nota dela, cada uma na sua lista. O piso planta o defeito e prova a diferença: a MESMA linha sem o metadado de pré-condição cai no gate de aplicação e PROMOVE a unidade, que é a regra de 1.0.8 continuando de pé.',
	'cta.publicado_pela_presenca_do_numero' => 'a presença do número decide, e ela sozinha: com contato.whatsapp_e164 gravada o bloco do CTA é publicado; sem ela o bloco do modelo NÃO é publicado, o módulo fecha INATIVO em vez de degradado e o motivo diz o que aconteceu com o botão. O discriminante é a CLASSE do pattern e não o atributo carimbado no render: o piso roda numa bancada SEM WP_HTML_Tag_Processor, que é a instalação em que decidir pelo atributo deixaria publicado um botão que não leva a lugar nenhum.',
	'cta.regra_de_publicacao_registrada'    => 'a regra de publicação do CTA RODA no estado em que ela decide, e isso é medido pelo caminho real — apply_filters, nunca chamada direta: com o módulo INATIVO por número vazio o filtro render_block dele está registrado, o CTA do modelo não é publicado e o CTA com destino próprio fica intocado; com número gravado o do modelo é promovido e o do agente é preservado. A exceção é declarada no PRÓPRIO item do hook e alcança um hook só — o enfileiramento do módulo inativo continua inerte. O piso é o defeito medido: da 1.0.19 à 1.1.0 o filtro só era registrado com o módulo ativo, isto é, quando a condição da supressão já não podia acontecer, e a regra afirmada em três documentos não rodava em site nenhum.',
	'options.chave_desconhecida_preservada' => 'todo sanitizador de grupo normaliza a chave CONHECIDA e preserva a DESCONHECIDA, no catálogo inteiro e dentro das entradas de lista: a chave que o agente acrescentou a f3base_contato sobrevive à leitura, com valor aninhado; f3base_redirects e f3base_journal_eliminacao preservam a chave desconhecida DENTRO da entrada; e a chave conhecida continua sendo normalizada, para que preservar o desconhecido não vire aceitar qualquer coisa. O piso planta o defeito da 1.0.19: o reconstrutor de chaves fixas devolve o valor sem a chave, apagada em silêncio, sem erro e sem log.',
	'seguranca.coop_do_valor_gravado'       => 'o Cross-Origin-Opener-Policy emitido é o valor GRAVADO, e não o literal da classe: gravar same-origin lê de volta same-origin, o cabeçalho sai com ele e o módulo fecha degradado NOMEANDO o que se perde — a janela que o CTA abre. O vocabulário continua fechado: valor que o navegador não conhece cai no padrão declarado, porque cabeçalho ignorado em silêncio é pior que cabeçalho ausente. O piso planta o defeito da 1.0.19: o sanitizador devolvia o literal e a option não tinha efeito nenhum.',
	'seguranca.referrer_policy_avisa_atribuicao' => 'Referrer-Policy no-referrer é ACEITO e AVISADO: o aviso fecha WARN nomeando GA4, Google Ads, Meta Ads e LinkedIn Ads — os quatro que perdem a origem do clique quando ele chega sem parâmetro de campanha —, e o cabeçalho continua sendo emitido, porque avisar é nomear o preço e recusar seria decidir pelo projeto. O piso é o ramo adverso: com o valor padrão gravado, nenhum aviso sai.',
	'tracking.caminho_unico'                => 'uma chave decide o caminho, e um caminho só: com f3base_gtm_container_id preenchido o container vai para o navegador e os IDs diretos NÃO vão — não é um if no cliente, é o ID que não chega —, e sem container os IDs presentes vão e o container não. Slot vazio é inerte: nenhum script enfileirado e o módulo INATIVO. ID fora da forma declarada é PRESERVADO e avisado, nunca apagado. O piso planta o disparo em dobro: com os IDs diretos viajando junto do container, a mesma conversão sai duas vezes e o lance do leilão é reescrito.',
	'tracking.consentimento_gateia_tudo'    => 'um estado de consentimento e quatro tags: na negativa NENHUMA é enfileirada — Pixel e Insight Tag não têm modo de consentimento, e para eles negativa é ausência —, e o módulo fecha degradado dizendo isso; no aceite as quatro saem por UM carregador só, que depende do script de consentimento para que o Consent Mode tenha default antes de a tag decidir. O piso planta a negativa na bancada e mede que nada foi enfileirado.',
	'leads.click_ids_no_schema'             => 'os identificadores de clique estão no schema FECHADO do endpoint e no cliente ao mesmo tempo: gclid, gbraid, wbraid, msclkid, fbclid, fbc, fbp e li_fat_id são aceitos, gravados no registro do lead, e o conjunto continua fechado — chave de fora segue recusada com 400 nomeando a chave. O piso é o pior modo de falhar deste endpoint: acrescentar o campo só no cliente faria todo lead de tráfego pago voltar recusado.',
	'tema.link_privacidade_preserva'        => 'o link da política PREENCHE quando falta e nunca apaga: sem política publicada o href é REMOVIDO e o parágrafo fica inteiro, com tudo o que houver nele; com política publicada o href do modelo recebe o permalink real; e o href explícito do agente — uma política em PDF externo — sobrevive ao render. O piso reproduz os dois defeitos da 1.0.19 na bancada: a função antiga devolve string vazia sem política e troca o PDF pelo permalink com ela.',
	'leads.cta_preserva_destino'            => 'os QUATRO quadrantes do CTA: sem número e com o href do modelo o bloco não é publicado; sem número e com destino próprio ele é publicado intacto; com número e href do modelo ele é promovido ao link profundo e carimbado; com número e destino próprio o destino fica e o carimbo não sai — o cliente não vai tocar nele. Bloco que não é o CTA passa intacto nos dois casos. O piso é a supressão cega da 1.0.19, que apagava qualquer bloco da classe, e a reescrita cega do href, que desfazia a escolha do agente a cada render.',
	'cadencia.contador_de_ajustes'          => 'apos_n_ajustes é LIDO e conta ajustes de verdade: escrita em option gerenciada conta, carimbo de atividade não conta, e ao alcançar o alvo o gatilho DISPARA e zera o contador; com o alvo em zero nada é contado e o estado diz que nada promete disparar; sem periodicidade e sem gatilho o módulo é inerte. O piso planta o defeito: a chave era gravada numa option que ninguém lia, e o relatório prometia gatilho sobre um contador inexistente.',
);

$funcionais = f3b_ck_funcionais( $raiz, $suite );

foreach ( $rotulos_funcionais as $nome => $msg_ok ) {
	if ( ! isset( $funcionais[ $nome ] ) ) {
		estado( 'BLOCKED', $nome, 'a sonda funcional não devolveu veredito para esta checagem.', 'pendencia-externa', 'build' );
		continue;
	}

	$r = $funcionais[ $nome ];

	estado_por_origem(
		(bool) $r['ok'],
		'site',
		$nome,
		$msg_ok . ' ' . (int) $r['medidas'] . ' asserção(ões).',
		count( $r['achados'] ) . ' achado(s): ' . f3b_amostra( $r['achados'] ),
		'teste-funcional',
		'build'
	);
}

emitir( f3b_ck_js_extrator( $raiz, $suite ), 'js.extrator_resposta', 'o extrator de resposta do cliente acha o JSON no fim de um corpo HTML+JSON e devolve null quando não há objeto.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_limite_do_cliente( $raiz, $suite ), 'js.limite_do_cliente', 'o corte do cliente de leads usa a MESMA unidade que o servidor publica e recusa — caracteres —, com a função pura extraída do arquivo REAL: o texto acentuado no limite não é cortado, o de um caractere acima é cortado para o limite em caracteres, o par substituto não é partido ao meio e campo sem limite publicado sai intacto. O piso planta o defeito: o mesmo texto excede o limite em bytes, que era a unidade do servidor.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_conversao( $raiz, $suite ), 'js.conversao_multicanal', 'o clique do CTA é a conversão do site e ela sai nos quatro canais, medida no cliente REAL rodado de ponta a ponta: generate_lead SEMPRE — o formulário é opcional, o clique é o lead —, a conversão do Ads com send_to montado das duas metades, o Lead da Meta com eventID para a deduplicação futura, o track do LinkedIn com o ID declarado, e os identificadores de clique (gclid, fbclid, li_fat_id) chegando ao lead junto do _fbc no formato da Meta. O href do agente sobrevive ao clique e continua sendo medido. Os pisos: no caminho do container nenhum disparo direto acontece nem com os IDs presentes, e com slot vazio nada dispara e o lead continua registrado.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_cliente( $raiz, $suite ), 'js.decisoes_do_cliente', 'as decisões do cliente têm teto e piso sob o Node, com as funções extraídas do arquivo REAL: a rejeição de lock PARA na primeira ocorrência — inclusive contra a resposta ANTIGA, sem parou, concluido, lote, rotulo nem aplicacao, que é o piso do laço de 163 requisições —, o avanço só acontece sobre resposta da própria unidade e BLOCKED de unidade continua avançando, o índice fora do plano é recusado (o Etapa 94 de 40), a rejeição de lock entrega dono, idade do heartbeat, TTL e o horário do abandono, linha que não fecha OK recebe nome de reserva e a contagem por estado nunca fica sem a lista, e o rodapé fecha num estado da lista declarada — nunca vazio. E a ORDEM NO DOM é medida na árvore que o operador vê: a sonda monta um DOM de mentira e roda o cliente REAL de ponta a ponta contra ele — o progresso continua sendo o primeiro filho e fica com uma linha curta, o nó de encerramento vem DEPOIS da tabela e carrega o resumo inteiro, e a região tem nome acessível, tabindex e recebe o foco. O piso são MUTANTES do próprio cliente: o resumo escrito em progresso, o encerramento montado antes da tabela e a chamada de foco apagada — a bancada tem de acusar os três.', 'teste-funcional', 'build' );

/* ---------- entregáveis ---------- */

foreach ( array_keys( f3b_entregaveis( $raiz ) ) as $nome ) {
	$r = f3b_ck_entregavel( $raiz, $nome );

	if ( $r['ok'] ) {
		estado( 'OK', $nome, 'entregável presente e completo.', 'analise-estatica', 'build' );
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		'entregável incompleto. Arquivo(s) que falta(m): ' . f3b_amostra( $r['achados'], 8 ) . '.',
		'analise-estatica',
		'build'
	);
}

/* ---------- condicionais que este projeto não instancia ---------- */

$config    = f3b_config( $raiz ) ?? array();
$anteriores = (array) ( $config['release']['anterior_suportada'] ?? array() );
/*
 * Handoff é o SITE DE REFERÊNCIA em artefato de handoff
 * (data-artifact="wordpress-source-blueprint"), não a existência de release
 * anterior. Condicionar as duas coisas ao mesmo predicado era erro de
 * categoria: bastava declarar a origem suportada de uma release de correção
 * para as checagens de handoff saírem de N/A sem que nada de handoff existisse.
 * A ausência da chave é lida com padrão explícito — chave inexistente não é
 * "ligado" (armadilha do helper permissivo).
 */
$handoff    = 'handoff' === (string) ( $config['site_referencia']['tipo'] ?? '' );

/**
 * O REGIME EXISTE? A resposta sai do VALOR do destino, e de mais nada.
 *
 * A 1.0.19 tirou o interruptor `ativo` da entrada do formulário: havia dois
 * fatos podendo discordar — o interruptor e o destino —, e eles discordavam. O
 * regime whatsapp era declarado ATIVO e fechava BLOCKED por falta de destino na
 * mesma execução. Presença de valor é a condição, e uma condição só.
 *
 * @param array<string,mixed> $config Configuração inteira.
 * @param string              $regime Regime declarado.
 * @return bool
 */
function f3b_regime_existe( array $config, string $regime ): bool {
	foreach ( (array) ( $config['formularios'] ?? array() ) as $formulario ) {
		if ( ! is_array( $formulario ) || $regime !== ( $formulario['regime'] ?? '' ) ) {
			continue;
		}

		$caminho = (string) ( $formulario['destino'] ?? '' );

		if ( '' === $caminho ) {
			continue;
		}

		$valor = $config;

		foreach ( explode( '.', $caminho ) as $segmento ) {
			if ( ! is_array( $valor ) || ! array_key_exists( $segmento, $valor ) ) {
				$valor = '';
				break;
			}

			$valor = $valor[ $segmento ];
		}

		if ( is_scalar( $valor ) && '' !== trim( (string) $valor ) ) {
			return true;
		}
	}

	return false;
}

$cf7_existe      = f3b_regime_existe( $config, 'cf7-email' );
$whatsapp_existe = f3b_regime_existe( $config, 'whatsapp' );

$condicoes = array(
	'handoff.pacote_de_entrega'        => ! $handoff,
	'handoff.credenciais_rotacionadas' => ! $handoff,
	'formulario.regime_cf7'            => ! $cf7_existe,
	'formulario.destino_privado'       => ! $whatsapp_existe,
);

/* ---------- o que este ambiente não pode medir ---------- */

$wp_root = (string) getenv( 'F3BASE_WP_ROOT' );
$tem_wp  = '' !== $wp_root && is_file( rtrim( $wp_root, '/' ) . '/wp-load.php' );

foreach ( f3b_bloqueadas() as $nome => $dados ) {
	/*
	 * CONDIÇÃO DECLARADA FALSA VENCE PENDÊNCIA EXTERNA, e o nome que está nas
	 * duas tabelas sai UMA vez. Não há pendência quando a funcionalidade não
	 * existe: pedir "WordPress em produção" para conferir o CTA de um regime
	 * que ninguém instanciou é relatar como pendente algo que ninguém pediu.
	 */
	if ( $condicoes[ $nome ] ?? false ) {
		continue;
	}

	if ( $tem_wp ) {
		estado(
			'BLOCKED',
			$nome,
			'há WordPress em ' . $wp_root . ', mas esta suíte não traz a sonda desta checagem: ' . $dados['motivo'] . '.',
			$dados['classe'],
			$dados['fase']
		);
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		$dados['motivo'] . '. Falta: ' . $dados['falta'] . '.',
		$dados['classe'],
		$dados['fase']
	);
}

foreach ( f3b_nao_aplicaveis() as $nome => $dados ) {
	if ( $condicoes[ $nome ] ?? false ) {
		estado( 'N/A', $nome, 'condição declarada: ' . $dados['condicao'] . '.', $dados['classe'], $dados['fase'] );
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		'a condição que tornava esta checagem inaplicável deixou de valer, e a sonda dela não roda neste ambiente. Falta: WordPress instalado para exercitar o caminho.',
		'pendencia-externa',
		'local'
	);
}

/* ---------- cruzamentos da própria suíte ---------- */

/*
 * As duas metacheagens entram na própria lista: elas SÃO emitidas nesta rodada,
 * e o cruzamento precisa enxergá-las para não acusar como órfão o rótulo que
 * está prestes a sair. Nada mais é acrescentado à mão.
 */
$emitidas = array_merge( F3Base_Suite::emitidas(), array( 'manifesto.bidirecional', 'armadilhas.mapeadas' ) );

$manifesto = f3b_ck_manifesto_bidirecional( $suite, $emitidas );

estado_por_origem(
	(bool) $manifesto['ok'],
	'site',
	'manifesto.bidirecional',
	sprintf( '%d requisito(s) do manifesto apontam para checagem emitida, e nenhum rótulo emitido ficou órfão.', (int) $manifesto['requisitos'] ),
	count( $manifesto['achados'] ) . ' achado(s): ' . f3b_amostra( $manifesto['achados'] ),
	'analise-estatica',
	'build'
);

$armadilhas = f3b_ck_armadilhas_mapeadas( $suite, $emitidas );

estado( $armadilhas['estado'], 'armadilhas.mapeadas', $armadilhas['mensagem'], 'analise-estatica', 'build' );

/* =========================================================================
 * RESUMO
 * ====================================================================== */

echo "\n== resumo ==\n";

/*
 * CONTAGEM E NOMES SAEM JUNTOS. O resumo imprimia `BLOCKED 22` e nenhum nome:
 * quem quisesse saber QUAIS tinha de reler as 73 linhas acima e contar à mão.
 */
$contagem     = F3Base_Suite::contagem();
$nomes_da_rodada = F3Base_Suite::nomes_por_estado();
$total        = array_sum( $contagem );

foreach ( f3b_resumo_por_estado( $contagem, $nomes_da_rodada ) as $linha_do_resumo ) {
	echo $linha_do_resumo . "\n";
}

printf( "   %-8s %d\n", 'TOTAL', $total );

$falhas = F3Base_Suite::falhas();

/* =========================================================================
 * ETAPA 3 — SELO DA RODADA. Última, sempre: o resumo por estado só existe
 * depois das checagens, e é ele que entra no registro.
 * ====================================================================== */

echo "\n== etapa 3: selo da rodada ==\n";

$selo = f3b_selar_rodada( $raiz, $suite, $build, $contagem, $nomes_da_rodada, f3b_com_piso( $suite ) );

foreach ( $selo['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

if ( $selo['gravado'] ) {
	printf(
		"   registro: %s\n   hash do pacote: %s\n   conferido no bundle SELADO: %s\n",
		$selo['arquivo'],
		$selo['hash'],
		(string) ( $selo['conferido'] ?? '(não conferido)' )
	);
}

if ( ! $selo['ok'] ) {
	estado(
		'FALHA',
		'entrega.selo_da_rodada',
		'o selo da rodada não fechou: ' . f3b_amostra( $selo['achados'], 3 ) . '.',
		'medida',
		'build'
	);

	printf( "\nrodada REPROVADA no selo: %d checagem(ns) em FALHA.\n", F3Base_Suite::falhas() );
	exit( 1 );
}

if ( $falhas > 0 ) {
	printf(
		"\nrodada REPROVADA: %d checagem(ns) em FALHA — %s.\n",
		$falhas,
		'FALHA: ' . ( array() === $nomes_da_rodada['FALHA'] ? 'nenhum' : implode( ', ', $nomes_da_rodada['FALHA'] ) )
	);
	exit( 1 );
}

$bloqueadas = $contagem['BLOCKED'];

printf(
	"\nrodada sem FALHA. %d checagem(ns) em BLOCKED — %s. Nenhuma delas é entregável do gate de aplicação: as de fase declarada não impedem a autodesativação, e as do host são medidas lá.\n",
	$bloqueadas,
	'BLOCKED: ' . ( array() === $nomes_da_rodada['BLOCKED'] ? 'nenhum' : implode( ', ', $nomes_da_rodada['BLOCKED'] ) )
);

exit( 0 );
