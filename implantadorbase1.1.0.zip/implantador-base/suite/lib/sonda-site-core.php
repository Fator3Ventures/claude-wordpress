<?php
/**
 * Sonda do SITE-CORE: as classes REAIS do plugin persistente, exercitadas.
 *
 * Subprocesso por desenho, como as outras sondas: esta monta um WordPress de
 * mentira — `wpdb` com as linhas em memória, options, transientes, hooks e
 * agendamentos — e roda o `class-f3base-modulo-endpoint-leads.php` e o
 * `class-f3base-modulo-cadencia-relatorio.php` de verdade contra ele. Nada é
 * copiado para cá: o que a sonda mede é o arquivo que viaja no pacote.
 *
 * Cada bloco tem TETO e PISO. O piso NÃO é "um caso inválido reprovou": é o
 * DEFEITO MEDIDO reproduzido na bancada, e a afirmação de que a bancada
 * realmente o reproduz sai junto. Um piso que não consegue plantar o defeito
 * prova que a bancada é cega, não que o código está certo — foi a lição que a
 * 1.0.15 pagou na sonda de instalação.
 *
 * A honestidade do limite: a bancada de banco entende as instruções que este
 * módulo emite, e só elas. Ela não é um MySQL. O que ela mede é a SEMÂNTICA
 * declarada — quantas instruções o incremento gasta, quem decide o empate, o
 * que sobra na tabela depois da falha —, e é essa semântica que os defeitos da
 * 1.0.17 violavam.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'erro' => 'raiz inexistente' ) );
	exit( 2 );
}

$GLOBALS['f3b_bench'] = array(
	'options'     => array(),
	'transientes' => array(),
	'congelados'  => null,
	'hooks'       => array(),
	'eventos'     => array(),
	'posts'       => 0,
	'ultimo_post' => array(),
	'insert_ok'   => true,
	'insert_id_cego' => false,
	'servidor'    => array( 'REMOTE_ADDR' => '203.0.113.7' ),
	'fita'        => array(),
	'scripts'     => array(),
	'ssl'         => false,
	'suportes_do_tema' => array( 'f3base-consentimento-rodape' ),
);

/*
 * A raiz do WordPress de mentira fica fora do pacote: `criar_tabela()` faz
 * `require_once ABSPATH . 'wp-admin/includes/upgrade.php'`, e o arquivo precisa
 * existir. O stub é vazio — quem responde por `dbDelta()` é a bancada, logo
 * abaixo.
 */
$abspath = sys_get_temp_dir() . '/f3base-sonda-site-core-' . getmypid() . '-wp/';

if ( ! is_dir( $abspath . 'wp-admin/includes' ) ) {
	mkdir( $abspath . 'wp-admin/includes', 0777, true );
}

file_put_contents( $abspath . 'wp-admin/includes/upgrade.php', "<?php
" );

define( 'ABSPATH', $abspath );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'MONTH_IN_SECONDS', 30 * 86400 );
define( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );
define( 'F3BASE_SITE_CORE_URL', 'https://exemplo.test/wp-content/plugins/f3base-site-core/' );
define( 'F3BASE_SITE_CORE_VERSAO', '1.1.0' );
define( 'F3BASE_TEXT_DOMAIN', 'f3base' );
define( 'F3BASE_PREFIXO', 'f3base' );
define( 'ARRAY_A', 'ARRAY_A' );

/* ---------------------------------------------------------------------------
 * Núcleo de mentira: só o que estas classes chamam.
 * ------------------------------------------------------------------------ */

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor Valor.
 * @param int   $flags Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Validação de e-mail do núcleo.
 *
 * @param mixed $valor Valor.
 * @return string|false
 */
function is_email( $valor ) {
	return is_string( $valor ) && false !== filter_var( $valor, FILTER_VALIDATE_EMAIL ) ? $valor : false;
}

/**
 * Sanitização de e-mail do núcleo: entrada inválida devolve string VAZIA.
 *
 * É esse retorno vazio, não conferido, que fazia o lead entrar sem endereço.
 *
 * @param string $email E-mail bruto.
 * @return string
 */
function sanitize_email( string $email ): string {
	$email = trim( $email );

	return false !== filter_var( $email, FILTER_VALIDATE_EMAIL ) ? $email : '';
}

/**
 * Sanitização de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_text_field( string $texto ): string {
	$texto = strip_tags( $texto );
	$texto = preg_replace( '/[\r\n\t]+/', ' ', $texto );

	return trim( is_string( $texto ) ? $texto : '' );
}

/**
 * Sanitização de área de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_textarea_field( string $texto ): string {
	return trim( strip_tags( $texto ) );
}

/**
 * Sanitização de chave do núcleo.
 *
 * @param string $chave Chave.
 * @return string
 */
function sanitize_key( string $chave ): string {
	$limpo = preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $chave ) );

	return is_string( $limpo ) ? $limpo : '';
}

/**
 * Escape de URL do núcleo.
 *
 * @param string $url URL.
 * @return string
 */
function esc_url_raw( string $url ): string {
	return trim( $url );
}

/**
 * Remoção das barras que o núcleo acrescenta.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function wp_unslash( $valor ) {
	return is_string( $valor ) ? stripslashes( $valor ) : $valor;
}

/**
 * URL do site.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function home_url( string $caminho = '' ): string {
	return 'https://exemplo.test' . $caminho;
}

/**
 * Parser de URL do núcleo.
 *
 * @param string $url        URL.
 * @param int    $componente Componente.
 * @return array<string,mixed>|string|int|null|false
 */
function wp_parse_url( string $url, int $componente = -1 ) {
	return -1 === $componente ? parse_url( $url ) : parse_url( $url, $componente );
}

/**
 * Sal do núcleo.
 *
 * @param string $esquema Esquema.
 * @return string
 */
function wp_salt( string $esquema = 'auth' ): string {
	return 'sal-de-bancada-' . $esquema;
}

/**
 * Aleatório do núcleo.
 *
 * @param int $minimo Mínimo.
 * @param int $maximo Máximo.
 * @return int
 */
function wp_rand( int $minimo = 0, int $maximo = 0 ): int {
	return random_int( $minimo, max( $minimo, $maximo ) );
}

/**
 * Data formatada do núcleo.
 *
 * @param string   $formato  Formato.
 * @param int|null $carimbo  Carimbo.
 * @return string
 */
function wp_date( string $formato, ?int $carimbo = null ): string {
	return gmdate( $formato, null === $carimbo ? time() : $carimbo );
}

/**
 * Diferença legível do núcleo.
 *
 * @param int $de  Início.
 * @param int $ate Fim.
 * @return string
 */
function human_time_diff( int $de, int $ate = 0 ): string {
	return (string) abs( $ate - $de ) . 's';
}

/**
 * Erro do núcleo.
 */
class WP_Error {

	/**
	 * Mensagem do erro.
	 *
	 * @var string
	 */
	public string $mensagem;

	/**
	 * Constrói o erro.
	 *
	 * @param string $codigo   Código.
	 * @param string $mensagem Mensagem.
	 */
	public function __construct( string $codigo = '', string $mensagem = '' ) {
		$this->mensagem = $codigo . ': ' . $mensagem;
	}
}

/**
 * Predicado de erro do núcleo.
 *
 * @param mixed $valor Valor.
 * @return bool
 */
function is_wp_error( $valor ): bool {
	return $valor instanceof WP_Error;
}

/* ---------------------------------------------------------------------------
 * Options, transientes e hooks
 * ------------------------------------------------------------------------ */

/**
 * Leitura de option.
 *
 * @param string $nome   Nome.
 * @param mixed  $padrao Padrão.
 * @return mixed
 */
function get_option( string $nome, $padrao = false ) {
	return array_key_exists( $nome, $GLOBALS['f3b_bench']['options'] ) ? $GLOBALS['f3b_bench']['options'][ $nome ] : $padrao;
}

/**
 * Escrita de option, com os hooks que o núcleo dispara.
 *
 * @param string $nome     Nome.
 * @param mixed  $valor    Valor.
 * @param bool   $autoload Autoload.
 * @return bool
 */
function update_option( string $nome, $valor, bool $autoload = true ): bool {
	$existia = array_key_exists( $nome, $GLOBALS['f3b_bench']['options'] );
	$antigo  = $existia ? $GLOBALS['f3b_bench']['options'][ $nome ] : null;

	$GLOBALS['f3b_bench']['options'][ $nome ] = $valor;

	if ( ! $existia ) {
		do_action( 'added_option', $nome, $valor );

		return true;
	}

	if ( $antigo !== $valor ) {
		do_action( 'updated_option', $nome, $antigo, $valor );
	}

	return true;
}

/**
 * Remoção de option.
 *
 * @param string $nome Nome.
 * @return bool
 */
function delete_option( string $nome ): bool {
	unset( $GLOBALS['f3b_bench']['options'][ $nome ] );
	do_action( 'deleted_option', $nome );

	return true;
}

/**
 * Leitura de transiente.
 *
 * Quando a bancada está com os transientes CONGELADOS, a leitura devolve o
 * retrato tirado antes das gravações: é assim que duas requisições concorrentes
 * enxergam o mesmo valor, que é o defeito do balde por ler-modificar-gravar.
 *
 * @param string $chave Chave.
 * @return mixed
 */
function get_transient( string $chave ) {
	$fonte = null === $GLOBALS['f3b_bench']['congelados']
		? $GLOBALS['f3b_bench']['transientes']
		: $GLOBALS['f3b_bench']['congelados'];

	return array_key_exists( $chave, $fonte ) ? $fonte[ $chave ] : false;
}

/**
 * Escrita de transiente.
 *
 * @param string $chave Chave.
 * @param mixed  $valor Valor.
 * @param int    $ttl   TTL.
 * @return bool
 */
function set_transient( string $chave, $valor, int $ttl = 0 ): bool {
	$GLOBALS['f3b_bench']['transientes'][ $chave ] = $valor;

	return true;
}

/**
 * Remoção de transiente.
 *
 * @param string $chave Chave.
 * @return bool
 */
function delete_transient( string $chave ): bool {
	unset( $GLOBALS['f3b_bench']['transientes'][ $chave ] );

	return true;
}

/**
 * Registra um filtro.
 *
 * @param string   $hook       Hook.
 * @param callable $callback   Callback.
 * @param int      $prioridade Prioridade.
 * @param int      $args       Argumentos.
 * @return bool
 */
function add_filter( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	$GLOBALS['f3b_bench']['hooks'][ $hook ][] = array(
		'callback' => $callback,
		'args'     => $args,
	);

	return true;
}

/**
 * Registra uma ação.
 *
 * @param string   $hook       Hook.
 * @param callable $callback   Callback.
 * @param int      $prioridade Prioridade.
 * @param int      $args       Argumentos.
 * @return bool
 */
function add_action( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	return add_filter( $hook, $callback, $prioridade, $args );
}

/**
 * Aplica um filtro.
 *
 * @param string $hook  Hook.
 * @param mixed  $valor Valor.
 * @param mixed  ...$extras Extras.
 * @return mixed
 */
function apply_filters( string $hook, $valor, ...$extras ) {
	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		$argumentos = array_slice( array_merge( array( $valor ), $extras ), 0, max( 1, (int) $registro['args'] ) );
		$valor      = call_user_func_array( $registro['callback'], $argumentos );
	}

	return $valor;
}

/**
 * Dispara uma ação.
 *
 * @param string $hook  Hook.
 * @param mixed  ...$argumentos Argumentos.
 * @return void
 */
function do_action( string $hook, ...$argumentos ): void {
	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		call_user_func_array( $registro['callback'], array_slice( $argumentos, 0, max( 0, (int) $registro['args'] ) ) );
	}
}

/**
 * Há ouvinte registrado neste hook?
 *
 * @param string $hook Hook.
 * @return int Quantos ouvintes.
 */
function has_action( string $hook ): int {
	return count( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() );
}

/* ---------------------------------------------------------------------------
 * Agendamentos
 * ------------------------------------------------------------------------ */

/**
 * Recorrências do núcleo, ANTES de qualquer filtro.
 *
 * A lista é exatamente a do WordPress: `monthly` não existe, e `quinzenal`
 * tampouco. É esta ausência que fazia "mensal" cair em `daily` e "quinzenal"
 * cair em `weekly`, com o dobro da frequência, em silêncio.
 *
 * @return array<string,array{interval:int,display:string}>
 */
function f3b_recorrencias_do_nucleo(): array {
	return array(
		'hourly'     => array(
			'interval' => HOUR_IN_SECONDS,
			'display'  => 'Once Hourly',
		),
		'twicedaily' => array(
			'interval' => 12 * HOUR_IN_SECONDS,
			'display'  => 'Twice Daily',
		),
		'daily'      => array(
			'interval' => DAY_IN_SECONDS,
			'display'  => 'Once Daily',
		),
		'weekly'     => array(
			'interval' => 7 * DAY_IN_SECONDS,
			'display'  => 'Once Weekly',
		),
	);
}

/**
 * Recorrências disponíveis, já com os filtros aplicados.
 *
 * @return array<string,array{interval:int,display:string}>
 */
function wp_get_schedules(): array {
	return (array) apply_filters( 'cron_schedules', f3b_recorrencias_do_nucleo() );
}

/**
 * Próxima execução agendada de um hook.
 *
 * @param string $hook Hook.
 * @return int|false
 */
function wp_next_scheduled( string $hook ) {
	return isset( $GLOBALS['f3b_bench']['eventos'][ $hook ] )
		? (int) $GLOBALS['f3b_bench']['eventos'][ $hook ]['timestamp']
		: false;
}

/**
 * Evento agendado, com a recorrência.
 *
 * @param string $hook Hook.
 * @return object|false
 */
function wp_get_scheduled_event( string $hook ) {
	if ( ! isset( $GLOBALS['f3b_bench']['eventos'][ $hook ] ) ) {
		return false;
	}

	return (object) $GLOBALS['f3b_bench']['eventos'][ $hook ];
}

/**
 * Agenda um evento recorrente.
 *
 * O núcleo RECUSA recorrência que não exista na lista: é aí que o agendamento
 * sem quem registre `f3base_mensal` fracassa em vez de degradar em silêncio.
 *
 * @param int    $quando      Carimbo.
 * @param string $recorrencia Recorrência.
 * @param string $hook        Hook.
 * @return bool|WP_Error
 */
function wp_schedule_event( int $quando, string $recorrencia, string $hook ) {
	$agendas = wp_get_schedules();

	if ( ! isset( $agendas[ $recorrencia ] ) ) {
		return new WP_Error( 'invalid_schedule', 'recorrência inexistente: ' . $recorrencia );
	}

	$GLOBALS['f3b_bench']['eventos'][ $hook ] = array(
		'hook'      => $hook,
		'timestamp' => $quando,
		'schedule'  => $recorrencia,
		'interval'  => (int) $agendas[ $recorrencia ]['interval'],
		'args'      => array(),
	);

	return true;
}

/**
 * Desagenda um evento.
 *
 * @param int    $quando Carimbo.
 * @param string $hook   Hook.
 * @return bool
 */
function wp_unschedule_event( int $quando, string $hook ): bool {
	unset( $GLOBALS['f3b_bench']['eventos'][ $hook ] );

	return true;
}

/* ---------------------------------------------------------------------------
 * Conteúdo
 * ------------------------------------------------------------------------ */

/**
 * Registro de tipo de conteúdo: inerte na bancada.
 *
 * @param string              $tipo      Tipo.
 * @param array<string,mixed> $argumentos Argumentos.
 * @return void
 */
function register_post_type( string $tipo, array $argumentos = array() ): void {}

/**
 * Registro de rota REST: inerte na bancada.
 *
 * @param string              $espaco    Namespace.
 * @param string              $rota      Rota.
 * @param array<string,mixed> $argumentos Argumentos.
 * @return void
 */
function register_rest_route( string $espaco, string $rota, array $argumentos = array() ): void {}

/**
 * Inserção de conteúdo, com o interruptor de falha da bancada.
 *
 * @param array<string,mixed> $dados Dados.
 * @param bool                $erro  Devolver WP_Error.
 * @return int|WP_Error
 */
function wp_insert_post( array $dados, bool $erro = false ) {
	if ( ! $GLOBALS['f3b_bench']['insert_ok'] ) {
		return new WP_Error( 'db_insert_error', 'a bancada recusou a inserção, como o banco cheio recusaria' );
	}

	++$GLOBALS['f3b_bench']['posts'];

	$GLOBALS['f3b_bench']['ultimo_post'] = $dados;

	return $GLOBALS['f3b_bench']['posts'];
}

/**
 * Migração de tabela do núcleo: a bancada já cria a tabela completa.
 *
 * @param string $sql SQL.
 * @return array<int,string>
 */
function dbDelta( string $sql ): array { // phpcs:ignore WordPress.NamingConventions
	global $wpdb;

	$wpdb->criar_do_sql( $sql );

	return array();
}

/* ---------------------------------------------------------------------------
 * REST
 * ------------------------------------------------------------------------ */

/**
 * Requisição REST de bancada.
 */
class WP_REST_Request {

	/**
	 * Corpo como JSON.
	 *
	 * @var array<string,mixed>|null
	 */
	private ?array $json;

	/**
	 * Corpo como formulário.
	 *
	 * @var array<string,mixed>|null
	 */
	private ?array $form;

	/**
	 * Constrói a requisição.
	 *
	 * @param array<string,mixed>|null $json Corpo JSON.
	 * @param array<string,mixed>|null $form Corpo urlencoded.
	 */
	public function __construct( ?array $json = null, ?array $form = null ) {
		$this->json = $json;
		$this->form = $form;
	}

	/**
	 * Corpo JSON.
	 *
	 * @return array<string,mixed>|null
	 */
	public function get_json_params() {
		return $this->json;
	}

	/**
	 * Corpo urlencoded.
	 *
	 * @return array<string,mixed>|null
	 */
	public function get_body_params() {
		return $this->form;
	}

	/**
	 * Parâmetro solto.
	 *
	 * @param string $nome Nome.
	 * @return mixed
	 */
	public function get_param( string $nome ) {
		return null;
	}

	/**
	 * Cabeçalho.
	 *
	 * @param string $nome Nome.
	 * @return string|null
	 */
	public function get_header( string $nome ) {
		return null;
	}
}

/**
 * Resposta REST de bancada.
 */
class WP_REST_Response {

	/**
	 * Corpo.
	 *
	 * @var array<string,mixed>
	 */
	public array $data;

	/**
	 * Status HTTP.
	 *
	 * @var int
	 */
	public int $status;

	/**
	 * Constrói a resposta.
	 *
	 * @param array<string,mixed> $data   Corpo.
	 * @param int                 $status Status.
	 */
	public function __construct( array $data = array(), int $status = 200 ) {
		$this->data   = $data;
		$this->status = $status;
	}
}

/* ---------------------------------------------------------------------------
 * wpdb de bancada
 * ------------------------------------------------------------------------ */

/**
 * Banco de bancada: linhas em memória, com a semântica das instruções emitidas.
 *
 * Ela entende as instruções que o módulo emite, e só elas. O que importa medir
 * aqui é QUEM decide: a chave primária recusa o segundo `INSERT`, o
 * `ON DUPLICATE KEY UPDATE` soma numa instrução só, e o `UPDATE` condicionado ao
 * carimbo lido faz a retomada da reserva morta acontecer uma vez só.
 */
class F3Base_Bench_Wpdb {

	/**
	 * Prefixo das tabelas.
	 *
	 * @var string
	 */
	public string $prefix = 'wp_';

	/**
	 * Último id gerado por LAST_INSERT_ID().
	 *
	 * @var int
	 */
	public int $insert_id = 0;

	/**
	 * Tabelas: nome => array{colunas:string[],linhas:array<string,array<string,mixed>>}.
	 *
	 * @var array<string,array<string,mixed>>
	 */
	public array $tabelas = array();

	/**
	 * Fita de instruções executadas.
	 *
	 * @var array<int,string>
	 */
	public array $fita = array();

	/**
	 * Cria a tabela a partir do CREATE TABLE do módulo.
	 *
	 * @param string $sql SQL.
	 * @return void
	 */
	public function criar_do_sql( string $sql ): void {
		if ( ! preg_match( '/CREATE TABLE ([A-Za-z0-9_]+) \((.*)\)\s*;?\s*$/s', trim( $sql ), $achado ) ) {
			return;
		}

		$nome    = $achado[1];
		$colunas = array();

		foreach ( explode( "\n", $achado[2] ) as $linha ) {
			$linha = trim( $linha );

			if ( '' === $linha || preg_match( '/^(PRIMARY KEY|KEY|UNIQUE)/i', $linha ) ) {
				continue;
			}

			if ( preg_match( '/^([a-z_]+)\s/i', $linha, $coluna ) ) {
				$colunas[] = $coluna[1];
			}
		}

		$anteriores = $this->tabelas[ $nome ]['linhas'] ?? array();

		$this->tabelas[ $nome ] = array(
			'colunas' => $colunas,
			'linhas'  => $anteriores,
		);
	}

	/**
	 * Interpola a instrução como o núcleo interpola.
	 *
	 * @param string $sql  SQL com marcadores.
	 * @param mixed  ...$argumentos Argumentos.
	 * @return string
	 */
	public function prepare( string $sql, ...$argumentos ): string {
		if ( 1 === count( $argumentos ) && is_array( $argumentos[0] ) ) {
			$argumentos = $argumentos[0];
		}

		$saida = '';
		$i     = 0;
		$n     = strlen( $sql );

		while ( $i < $n ) {
			$c = $sql[ $i ];

			if ( '%' === $c && $i + 1 < $n && in_array( $sql[ $i + 1 ], array( 's', 'd' ), true ) ) {
				$argumento = array_shift( $argumentos );

				$saida .= 's' === $sql[ $i + 1 ]
					? "'" . addslashes( (string) $argumento ) . "'"
					: (string) (int) $argumento;

				$i += 2;
				continue;
			}

			$saida .= $c;
			++$i;
		}

		return $saida;
	}

	/**
	 * Silenciamento de erro: a bancada nunca imprime.
	 *
	 * @param bool $silenciar Silenciar.
	 * @return bool
	 */
	public function suppress_errors( bool $silenciar = true ): bool {
		return false;
	}

	/**
	 * Escape de LIKE.
	 *
	 * @param string $texto Texto.
	 * @return string
	 */
	public function esc_like( string $texto ): string {
		return $texto;
	}

	/**
	 * Collate do núcleo.
	 *
	 * @return string
	 */
	public function get_charset_collate(): string {
		return '';
	}

	/**
	 * Valor único.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return string|null
	 */
	public function get_var( string $sql ) {
		$this->fita[] = $sql;

		if ( preg_match( "/SHOW TABLES LIKE '([^']+)'/", $sql, $achado ) ) {
			return isset( $this->tabelas[ $achado[1] ] ) ? $achado[1] : null;
		}

		if ( preg_match( "/SELECT contador FROM ([A-Za-z0-9_]+) WHERE chave = '([^']*)'/", $sql, $achado ) ) {
			$linha = $this->tabelas[ $achado[1] ]['linhas'][ $achado[2] ] ?? null;

			return null === $linha ? null : (string) $linha['contador'];
		}

		return null;
	}

	/**
	 * Coluna inteira.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return array<int,string>
	 */
	public function get_col( string $sql ): array {
		$this->fita[] = $sql;

		if ( preg_match( '/SHOW COLUMNS FROM ([A-Za-z0-9_]+)/', $sql, $achado ) ) {
			return $this->tabelas[ $achado[1] ]['colunas'] ?? array();
		}

		return array();
	}

	/**
	 * Uma linha.
	 *
	 * @param string $sql   SQL já interpolada.
	 * @param string $saida Formato.
	 * @return array<string,mixed>|null
	 */
	public function get_row( string $sql, string $saida = ARRAY_A ) {
		$this->fita[] = $sql;

		if ( ! preg_match( '/FROM ([A-Za-z0-9_]+)/', $sql, $tabela ) ) {
			return null;
		}

		if ( ! preg_match( "/WHERE chave = '([^']*)'/", $sql, $chave ) ) {
			return null;
		}

		return $this->tabelas[ $tabela[1] ]['linhas'][ $chave[1] ] ?? null;
	}

	/**
	 * Instrução de escrita.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return int|false Linhas afetadas.
	 */
	public function query( string $sql ) {
		$this->fita[] = $sql;

		if ( str_starts_with( ltrim( $sql ), 'INSERT INTO' ) ) {
			return $this->inserir( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'UPDATE' ) ) {
			return $this->atualizar( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'DELETE' ) ) {
			return $this->apagar( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'DROP' ) ) {
			return 0;
		}

		return false;
	}

	/**
	 * INSERT, com e sem ON DUPLICATE KEY UPDATE.
	 *
	 * @param string $sql SQL.
	 * @return int|false
	 */
	private function inserir( string $sql ) {
		if ( ! preg_match( '/INSERT INTO ([A-Za-z0-9_]+) \(([^)]*)\) VALUES \(([^)]*)\)/', $sql, $achado ) ) {
			return false;
		}

		$tabela = $achado[1];

		if ( ! isset( $this->tabelas[ $tabela ] ) ) {
			return false;
		}

		$colunas = array_map( 'trim', explode( ',', $achado[2] ) );
		$valores = $this->argumentos( $achado[3] );

		if ( count( $colunas ) !== count( $valores ) ) {
			return false;
		}

		$linha = array_combine( $colunas, $valores );
		$chave = (string) $linha['chave'];

		if ( ! isset( $this->tabelas[ $tabela ]['linhas'][ $chave ] ) ) {
			$this->tabelas[ $tabela ]['linhas'][ $chave ] = $linha;

			return 1;
		}

		if ( ! str_contains( $sql, 'ON DUPLICATE KEY UPDATE' ) ) {
			/* A CHAVE PRIMÁRIA DECIDE O EMPATE: o segundo INSERT não entra. */
			return false;
		}

		$atual = $this->tabelas[ $tabela ]['linhas'][ $chave ];

		if ( ! preg_match( '/contador = LAST_INSERT_ID\( IF\( expira_em < (\d+), 1, contador \+ 1 \) \)/', $sql, $conta ) ) {
			return false;
		}

		if ( ! preg_match( '/expira_em = IF\( expira_em < (\d+), (\d+), expira_em \)/', $sql, $prazo ) ) {
			return false;
		}

		$expirou = (int) $atual['expira_em'] < (int) $conta[1];

		$atual['contador']  = $expirou ? 1 : (int) $atual['contador'] + 1;
		$atual['expira_em'] = (int) $atual['expira_em'] < (int) $prazo[1] ? (int) $prazo[2] : (int) $atual['expira_em'];

		$this->tabelas[ $tabela ]['linhas'][ $chave ] = $atual;

		/* Driver que não devolve LAST_INSERT_ID(): o interruptor da bancada. */
		$this->insert_id = $GLOBALS['f3b_bench']['insert_id_cego'] ? 0 : (int) $atual['contador'];

		return 2;
	}

	/**
	 * UPDATE, nas duas formas que o módulo emite.
	 *
	 * @param string $sql SQL.
	 * @return int|false
	 */
	private function atualizar( string $sql ) {
		if ( ! preg_match( '/UPDATE ([A-Za-z0-9_]+) SET/', $sql, $achado ) ) {
			return false;
		}

		$tabela = $achado[1];

		if ( ! preg_match( "/WHERE chave = '([^']*)'/", $sql, $chave ) || ! isset( $this->tabelas[ $tabela ]['linhas'][ $chave[1] ] ) ) {
			return 0;
		}

		$linha = $this->tabelas[ $tabela ]['linhas'][ $chave[1] ];

		if ( preg_match( "/AND estado = '([^']*)'/", $sql, $estado ) && (string) $linha['estado'] !== $estado[1] ) {
			return 0;
		}

		if ( preg_match( '/AND criado_em = (\d+)/', $sql, $carimbo ) && (int) $linha['criado_em'] !== (int) $carimbo[1] ) {
			return 0;
		}

		if ( preg_match( "/SET record_id = '([^']*)', criado_em = (\d+), expira_em = (\d+)/", $sql, $set ) ) {
			$linha['record_id'] = $set[1];
			$linha['criado_em'] = (int) $set[2];
			$linha['expira_em'] = (int) $set[3];
		} elseif ( preg_match( "/SET estado = '([^']*)'/", $sql, $set ) ) {
			$linha['estado'] = $set[1];
		} else {
			return false;
		}

		$this->tabelas[ $tabela ]['linhas'][ $chave[1] ] = $linha;

		return 1;
	}

	/**
	 * DELETE, nas duas formas que o módulo emite.
	 *
	 * @param string $sql SQL.
	 * @return int
	 */
	private function apagar( string $sql ): int {
		if ( ! preg_match( '/DELETE FROM ([A-Za-z0-9_]+)/', $sql, $achado ) || ! isset( $this->tabelas[ $achado[1] ] ) ) {
			return 0;
		}

		$tabela = $achado[1];

		if ( preg_match( "/WHERE chave = '([^']*)' AND estado = '([^']*)'/", $sql, $par ) ) {
			$linha = $this->tabelas[ $tabela ]['linhas'][ $par[1] ] ?? null;

			if ( null === $linha || (string) $linha['estado'] !== $par[2] ) {
				return 0;
			}

			unset( $this->tabelas[ $tabela ]['linhas'][ $par[1] ] );

			return 1;
		}

		if ( ! preg_match( "/WHERE criado_em < (\d+) OR \( expira_em > 0 AND expira_em < (\d+) \) OR \( estado = '([^']*)' AND criado_em < (\d+) \)/", $sql, $poda ) ) {
			return 0;
		}

		$removidas = 0;

		foreach ( $this->tabelas[ $tabela ]['linhas'] as $chave => $linha ) {
			$velha     = (int) $linha['criado_em'] < (int) $poda[1];
			$expirada  = (int) $linha['expira_em'] > 0 && (int) $linha['expira_em'] < (int) $poda[2];
			$abandonada = (string) $linha['estado'] === $poda[3] && (int) $linha['criado_em'] < (int) $poda[4];

			if ( $velha || $expirada || $abandonada ) {
				unset( $this->tabelas[ $tabela ]['linhas'][ $chave ] );
				++$removidas;
			}
		}

		return $removidas;
	}

	/**
	 * Valores literais de um trecho de instrução, na ordem em que aparecem.
	 *
	 * @param string $trecho Trecho.
	 * @return array<int,mixed>
	 */
	private function argumentos( string $trecho ): array {
		preg_match_all( "/'((?:[^'\\\\]|\\\\.)*)'|(-?\d+)/", $trecho, $achados, PREG_SET_ORDER );

		$saida = array();

		foreach ( $achados as $achado ) {
			$saida[] = isset( $achado[2] ) && '' !== $achado[2] ? (int) $achado[2] : stripslashes( $achado[1] );
		}

		return $saida;
	}
}

$wpdb = new F3Base_Bench_Wpdb();

/**
 * Plural do núcleo: eco, escolhendo pela contagem.
 *
 * @param string $singular Forma singular.
 * @param string $plural   Forma plural.
 * @param int    $numero   Contagem.
 * @param string $dominio  Domínio.
 * @return string
 */
function _n( string $singular, string $plural, int $numero, string $dominio = '' ): string {
	return 1 === $numero ? $singular : $plural;
}

/**
 * HTTPS na requisição — declarado pela bancada.
 *
 * O valor mora no estado da bancada e não num literal: é ele que separa o ramo
 * em que o HSTS sai do ramo em que ele não sai, e um literal aqui apagaria um
 * dos dois.
 *
 * @return bool
 */
function is_ssl(): bool {
	return (bool) ( $GLOBALS['f3b_bench']['ssl'] ?? false );
}

/**
 * Contexto administrativo: a bancada mede o front-end.
 *
 * @return bool
 */
function is_admin(): bool {
	return false;
}

/**
 * Suporte declarado pelo tema — declarado pela bancada.
 *
 * O valor mora no estado da bancada porque ele separa dois ramos reais: o tema
 * desta base fornece o controle de consentimento na part do rodapé, e o
 * site-core imprime o dele quando o tema não fornece.
 *
 * @param string $suporte Nome do suporte.
 * @return bool
 */
function current_theme_supports( string $suporte ): bool {
	return in_array( $suporte, (array) ( $GLOBALS['f3b_bench']['suportes_do_tema'] ?? array() ), true );
}

/**
 * Registro de enfileiramento: a bancada guarda o que foi para a página.
 *
 * @param string              $handle Handle.
 * @param string              $src    Origem.
 * @param array<int,string>   $deps   Dependências.
 * @param mixed               $ver    Versão.
 * @param array<string,mixed> $args   Argumentos.
 * @return void
 */
function wp_enqueue_script( string $handle, string $src = '', array $deps = array(), $ver = false, $args = array() ): void {
	$GLOBALS['f3b_bench']['scripts'][ $handle ] = array(
		'src'   => $src,
		'deps'  => $deps,
		'ver'   => $ver,
		'args'  => $args,
		'dados' => array(),
	);
}

/**
 * Dados localizados de um script já enfileirado.
 *
 * @param string             $handle Handle.
 * @param string             $objeto Nome do objeto global.
 * @param array<string,mixed> $dados Dados.
 * @return bool
 */
function wp_localize_script( string $handle, string $objeto, array $dados ): bool {
	if ( ! isset( $GLOBALS['f3b_bench']['scripts'][ $handle ] ) ) {
		return false;
	}

	$GLOBALS['f3b_bench']['scripts'][ $handle ]['dados'][ $objeto ] = $dados;

	return true;
}

/* ---------------------------------------------------------------------------
 * As classes REAIS do pacote
 * ------------------------------------------------------------------------ */

$fonte = $raiz . '/fontes/site-core/includes/';

require $fonte . 'class-f3base-options.php';
require $fonte . 'class-f3base-atividade.php';
require $fonte . 'class-f3base-modulo.php';
require $fonte . 'class-f3base-modulo-endpoint-leads.php';
require $fonte . 'class-f3base-modulo-cadencia-relatorio.php';
require $fonte . 'class-f3base-modulo-leads-whatsapp.php';
require $fonte . 'class-f3base-modulo-consentimento.php';
require $fonte . 'class-f3base-modulo-tracking.php';
require $fonte . 'class-f3base-modulo-cabecalhos.php';
require $fonte . 'class-f3base-registro.php';
require $fonte . 'class-f3base-plugin.php';

/* ---------------------------------------------------------------------------
 * Registro dos achados
 * ------------------------------------------------------------------------ */

$resultado = array();

/**
 * Registra um achado.
 *
 * @param string $checagem Checagem.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]              = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Conta uma unidade medida.
 *
 * @param string $checagem Checagem.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Afirma, contando a medida.
 *
 * @param string $checagem Checagem.
 * @param bool   $condicao Condição medida.
 * @param string $falha    Texto do achado quando a condição não vale.
 * @return void
 */
function afirmar( string $checagem, bool $condicao, string $falha ): void {
	medir( $checagem );

	if ( ! $condicao ) {
		anotar( $checagem, $falha );
	}
}

/**
 * Zera a bancada entre cenários.
 *
 * @return void
 */
function bancada_limpa(): void {
	global $wpdb;

	$GLOBALS['f3b_bench']['options']     = array();
	$GLOBALS['f3b_bench']['transientes'] = array();
	$GLOBALS['f3b_bench']['congelados']  = null;
	$GLOBALS['f3b_bench']['posts']       = 0;
	$GLOBALS['f3b_bench']['ultimo_post']  = array();
	$GLOBALS['f3b_bench']['insert_ok']   = true;
	$GLOBALS['f3b_bench']['insert_id_cego'] = false;
	$GLOBALS['f3b_bench']['servidor']    = array( 'REMOTE_ADDR' => '203.0.113.7' );
	$GLOBALS['f3b_bench']['scripts']     = array();
	$GLOBALS['f3b_bench']['ssl']         = false;
	$GLOBALS['f3b_bench']['suportes_do_tema'] = array( 'f3base-consentimento-rodape' );

	$wpdb->tabelas   = array();
	$wpdb->fita      = array();
	$wpdb->insert_id = 0;

	requisicao_nova();
	F3Base_Modulo_Endpoint_Leads::criar_tabela();
}

/**
 * Simula uma REQUISIÇÃO NOVA, zerando os memos de requisição.
 *
 * Os memos existem para não repetir trabalho DENTRO de uma requisição — o
 * registro de módulos e a prontidão da tabela. Numa bancada que encadeia vários
 * cenários no mesmo processo eles atravessariam a fronteira que no site real não
 * existe, e o cenário seguinte mediria o estado do anterior.
 *
 * @return void
 */
function requisicao_nova(): void {
	foreach ( array( 'F3Base_Registro' => 'modulos', 'F3Base_Modulo_Endpoint_Leads' => 'tabela_pronta' ) as $classe => $propriedade ) {
		$reflexo = new ReflectionProperty( $classe, $propriedade );
		$reflexo->setAccessible( true );
		$reflexo->setValue( null, null );
	}
}

/**
 * Quantos ouvintes de um hook pertencem a uma CLASSE de módulo.
 *
 * `has_action()` conta todo mundo, e nesta bancada há mais de um módulo ativo
 * enfileirando script. A pergunta que a regra do CTA faz é outra — "o filtro
 * DESTE módulo está registrado?" —, e responder com a contagem geral seria medir
 * o hook do vizinho.
 *
 * @param string $hook   Nome do hook.
 * @param string $classe Nome da classe do módulo.
 * @return int
 */
function ouvintes_da_classe( string $hook, string $classe ): int {
	$conta = 0;

	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		$callback = $registro['callback'];

		if ( is_array( $callback ) && isset( $callback[0] ) && is_object( $callback[0] ) && $callback[0] instanceof $classe ) {
			++$conta;
		}
	}

	return $conta;
}

/**
 * Linhas da tabela de chaves com um tipo, e opcionalmente um estado.
 *
 * @param string $tipo   Tipo da linha.
 * @param string $estado Estado da reserva; vazio aceita qualquer um.
 * @return int
 */
function linhas_do_tipo( string $tipo, string $estado = '' ): int {
	global $wpdb;

	$tabela = F3Base_Modulo_Endpoint_Leads::nome_tabela();
	$conta  = 0;

	foreach ( $wpdb->tabelas[ $tabela ]['linhas'] ?? array() as $linha ) {
		if ( (string) $linha['tipo'] !== $tipo ) {
			continue;
		}

		if ( '' !== $estado && (string) $linha['estado'] !== $estado ) {
			continue;
		}

		++$conta;
	}

	return $conta;
}

/**
 * Payload mínimo aceito pelo endpoint.
 *
 * @param array<string,mixed> $extra Campos a acrescentar ou trocar.
 * @return array<string,mixed>
 */
function carga( array $extra = array() ): array {
	return array_merge(
		array(
			'token'          => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'correlation_id' => 'correlacao-de-bancada-1',
		),
		$extra
	);
}

/**
 * Exercita o endpoint com um corpo JSON.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Endpoint_Leads();

	return $modulo->receber( new WP_REST_Request( $corpo, null ) );
}

/**
 * Exercita o endpoint com um corpo de formulário — onde tudo chega string.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar_form( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Endpoint_Leads();

	return $modulo->receber( new WP_REST_Request( null, $corpo ) );
}

bancada_limpa();

/* ==========================================================================
 * leads.limite_por_caractere
 * ======================================================================= */

$nome = 'leads.limite_por_caractere';

$limites = F3Base_Modulo_Endpoint_Leads::limites_publicos();
$max     = (int) $limites['nome'];

/* PISO: a bancada reproduz o defeito? O texto acentuado no limite EXCEDE em bytes. */
$acentuado = str_repeat( 'ção', (int) floor( $max / 3 ) );
$acentuado .= str_repeat( 'á', $max - mb_strlen( $acentuado, 'UTF-8' ) );

afirmar(
	$nome,
	mb_strlen( $acentuado, 'UTF-8' ) === $max,
	'piso: a bancada não conseguiu montar um nome com exatamente ' . $max . ' caracteres acentuados, e sem ele o defeito não é reproduzido'
);

afirmar(
	$nome,
	strlen( $acentuado ) > $max,
	'piso: o texto acentuado no limite NÃO excede o limite em bytes — a bancada não está reproduzindo o defeito de unidade da 1.0.17, e o teto abaixo aprovaria por acaso'
);

/* TETO: o mesmo texto é aceito, porque a unidade agora é a que o cliente corta. */
$resposta = postar( carga( array( 'nome' => $acentuado ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: nome com ' . $max . ' caracteres acentuados foi recusado com status ' . $resposta->status . ' e código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — o navegador aprovou e o servidor recusou, que é o lead perdido em português'
);

/* PISO da regra: um caractere ACIMA do limite continua sendo recusado. */
bancada_limpa();
$resposta = postar( carga( array( 'nome' => $acentuado . 'ç' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_limite_excedido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso: um caractere acima do limite passou — a regra deixou de recusar, e "recusado, nunca truncado em silêncio" virou letra morta'
);

afirmar(
	$nome,
	'caracteres' === (string) ( $resposta->data['unidade'] ?? '' ),
	'a recusa não NOMEIA a unidade medida: o cliente precisa saber em que unidade o limite foi contado para cortar na mesma'
);

/* A unidade também vale dentro de atribuicao, que repetia a mesma medida. */
bancada_limpa();
$referrer = 'https://exemplo.test/' . str_repeat( 'é', 500 );
$resposta = postar( carga( array( 'atribuicao' => array( 'fonte' => str_repeat( 'ã', 120 ) ) ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto de atribuicao: 120 caracteres acentuados em atribuicao.fonte foram recusados com status ' . $resposta->status . ' — a segunda medida em bytes continuou de pé'
);

bancada_limpa();
$resposta = postar( carga( array( 'atribuicao' => array( 'fonte' => str_repeat( 'ã', 121 ) ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'atribuicao.fonte' === (string) ( $resposta->data['campo'] ?? '' ),
	'piso de atribuicao: 121 caracteres passaram, ou a recusa não nomeou a chave'
);

/* Um limite por campo, e ele é o do schema: `pagina` no limite chega inteira. */
bancada_limpa();

$caminho  = '/contato/?origem=' . str_repeat( 'ã', 100 );
$resposta = postar( carga( array( 'pagina' => 'https://exemplo.test' . $caminho ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto de pagina: uma URL interna com acentuação dentro do limite foi recusada com status ' . $resposta->status
);

$meta = $GLOBALS['f3b_bench']['ultimo_post']['meta_input'] ?? array();
$corpo_do_post = (string) ( $GLOBALS['f3b_bench']['ultimo_post']['post_content'] ?? '' );

afirmar(
	$nome,
	str_contains( $corpo_do_post, $caminho ),
	'a URL interna acentuada foi CORTADA na normalização: um segundo limite, em outra unidade, é uma segunda fonte para o mesmo fato'
);

/* ==========================================================================
 * leads.email_conclusivo
 * ======================================================================= */

$nome = 'leads.email_conclusivo';

/* PISO: a bancada reproduz o defeito? sanitize_email() devolve VAZIO, não erro. */
afirmar(
	$nome,
	'' === sanitize_email( 'joao arroba exemplo' ),
	'piso: a bancada não reproduz o retorno vazio de sanitize_email() para entrada inválida, e sem ele o teto aprovaria por acaso'
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => 'joao arroba exemplo' ) ) );

afirmar(
	$nome,
	400 === $resposta->status,
	'piso: e-mail inválido foi ACEITO com status ' . $resposta->status . ' — o lead entra sem endereço nenhum e a resposta diz que deu certo'
);

afirmar(
	$nome,
	'email' === (string) ( $resposta->data['campo'] ?? '' ),
	'a recusa do e-mail inválido não nomeia o campo'
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => 'pessoa@exemplo.test' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: e-mail válido foi recusado com status ' . $resposta->status
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => '' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto do falso positivo: e-mail VAZIO é campo opcional ausente, não e-mail inválido, e foi recusado com status ' . $resposta->status
);

/* ==========================================================================
 * leads.booleano_explicito
 * ======================================================================= */

$nome = 'leads.booleano_explicito';

/* PISO: a bancada reproduz o defeito? O molde da linguagem faz "false" valer true. */
afirmar(
	$nome,
	true === (bool) 'false',
	'piso: nesta versão de PHP (bool) "false" não é true, e o defeito medido não é reproduzível aqui'
);

afirmar(
	$nome,
	false === (bool) '0',
	'piso: a assimetria entre "0" e "false" não é reproduzível aqui'
);

$tabela_booleana = array(
	array( 'false', false, 'a string "false" precisa valer FALSO, e era ela que arquivava consentimento inexistente' ),
	array( '0', false, 'a string "0"' ),
	array( '', false, 'a string vazia' ),
	array( 'no', false, 'a string "no"' ),
	array( 'nao', false, 'a string "nao"' ),
	array( 'off', false, 'a string "off"' ),
	array( '1', true, 'a string "1"' ),
	array( 'true', true, 'a string "true"' ),
	array( 'sim', true, 'a string "sim"' ),
	array( 'on', true, 'a string "on"' ),
);

foreach ( $tabela_booleana as $caso ) {
	bancada_limpa();
	$resposta = postar_form( carga( array( 'consentimento' => $caso[0] ) ) );

	afirmar(
		$nome,
		201 === $resposta->status,
		'valor booleano "' . $caso[0] . '" foi recusado com status ' . $resposta->status
	);

	$gravado = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

	afirmar(
		$nome,
		array() !== $gravado,
		'valor booleano "' . $caso[0] . '" não chegou a gravar lead nenhum'
	);

	/*
	 * O VALOR QUE FOI ARQUIVADO, e não só o status da resposta: é o meta
	 * `_f3base_consentimento` que o Flamingo e o CPT guardam, e era ele que
	 * dizia "sim" para quem tinha mandado a string "false".
	 */
	$meta = $GLOBALS['f3b_bench']['ultimo_post']['meta_input'] ?? array();

	afirmar(
		$nome,
		( $caso[1] ? 'sim' : 'nao' ) === (string) ( $meta['_f3base_consentimento'] ?? '' ),
		'o valor "' . $caso[0] . '" foi ARQUIVADO como consentimento "' . (string) ( $meta['_f3base_consentimento'] ?? '' ) . '": ' . $caso[2]
	);
}

/* O valor lido é conferido no meta, que é o que o Flamingo arquiva como consentimento. */
foreach ( $tabela_booleana as $caso ) {
	medir( $nome );

	$lido = F3Base_Modulo_Endpoint_Leads::interpretar_booleano( $caso[0] );

	if ( $caso[1] !== $lido ) {
		anotar( $nome, $caso[2] . ' foi interpretada como ' . var_export( $lido, true ) . ' e devia ser ' . var_export( $caso[1], true ) );
	}
}

/* Estrutura no lugar de escalar: a guarda que o `continue` do booleano pulava. */
bancada_limpa();
$resposta = postar( carga( array( 'consentimento' => array() ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_tipo_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso da estrutura: {"consentimento":{}} devolveu status ' . $resposta->status . ' com código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — array vazio virando consentimento verdadeiro é o defeito que o ramo próprio do booleano escondia'
);

bancada_limpa();
$resposta = postar( carga( array( 'consentimento' => (object) array( 'a' => 1 ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_tipo_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso da estrutura: objeto em consentimento devolveu status ' . $resposta->status
);

/* O limite de 8 do schema deixou de ser letra morta. */
bancada_limpa();
$resposta = postar_form( carga( array( 'consentimento' => 'verdadeiro-demais' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_limite_excedido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso do limite: valor de 17 caracteres no campo booleano de max 8 devolveu status ' . $resposta->status . ' com código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — o ramo próprio do booleano pulava a checagem de limite e o max era letra morta'
);

/* Vocabulário fechado: valor que ninguém sabe ler é recusado, nunca adivinhado. */
bancada_limpa();
$resposta = postar_form( carga( array( 'consentimento' => 'talvez' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_valor_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso do vocabulário: "talvez" foi aceito com status ' . $resposta->status . ' — consentimento adivinhado é consentimento inventado'
);

/* ==========================================================================
 * leads.reserva_compensada
 * ======================================================================= */

$nome = 'leads.reserva_compensada';

bancada_limpa();

$tabela = F3Base_Modulo_Endpoint_Leads::nome_tabela();

/* PISO: a bancada reproduz a reserva? A primeira tentativa DEIXA a linha lá. */
$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	503 === $resposta->status,
	'a gravação recusada devolveu status ' . $resposta->status . ', e não 5xx — 201 Created com ok:false diz que o recurso existe'
);

afirmar(
	$nome,
	0 === linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP ),
	'piso: a reserva SOBREVIVEU à falha de gravação (' . linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP ) . ' linha(s) de deduplicação na tabela). É exatamente ela que, na 1.0.17, bloqueava por 30 dias o visitante que tentasse de novo'
);

/* TETO: a tentativa seguinte com o MESMO correlation_id é ACEITA. */
$GLOBALS['f3b_bench']['insert_ok'] = true;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	201 === $resposta->status && true === ( $resposta->data['registrado'] ?? false ),
	'teto: depois de uma falha de armazenamento, a segunda tentativa com o mesmo correlation_id devolveu status ' . $resposta->status . ' e registrado=' . var_export( $resposta->data['registrado'] ?? null, true ) . ' — ela precisa ser ACEITA'
);

/* PISO da deduplicação: com a gravação BEM-SUCEDIDA, o replay continua recusado. */
$resposta = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	200 === $resposta->status && true === ( $resposta->data['duplicado'] ?? false ),
	'piso da deduplicação: o replay de uma correlação JÁ GRAVADA passou — a compensação não pode ter apagado a reserva firme'
);

/* Exatamente uma reserva FIRME, e o balde do rate limit não se confunde com ela. */
$firmes = linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP, F3Base_Modulo_Endpoint_Leads::RESERVA_FIRME );

afirmar(
	$nome,
	1 === $firmes,
	'a tabela ficou com ' . $firmes . ' reserva(s) firme(s) depois de uma gravação aceita; esperava exatamente uma'
);

afirmar(
	$nome,
	linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_LIMITE ) > 0 && 0 === linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_LIMITE, F3Base_Modulo_Endpoint_Leads::RESERVA_FIRME ),
	'a linha do balde do rate limit está gravada com estado de RESERVA: balde não é reserva, e misturá-los faz qualquer contagem por estado mentir'
);

/* Reserva PENDENTE abandonada é retomada, e uma vez só. */
bancada_limpa();

$chave = F3Base_Modulo_Endpoint_Leads::chave_de_dedup( 'correlacao-abandonada' );

$wpdb->tabelas[ $tabela ]['linhas'][ $chave ] = array(
	'chave'     => $chave,
	'tipo'      => F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP,
	'estado'    => F3Base_Modulo_Endpoint_Leads::RESERVA_PENDENTE,
	'record_id' => 'registro-abandonado',
	'contador'  => 0,
	'expira_em' => time() + 100000,
	'criado_em' => time() - ( F3Base_Modulo_Endpoint_Leads::ttl_reserva_pendente() + 60 ),
);

$retomada = F3Base_Modulo_Endpoint_Leads::reservar( 'correlacao-abandonada', 'registro-novo' );

afirmar(
	$nome,
	true === $retomada['novo'] && 'registro-novo' === $retomada['record_id'],
	'a reserva pendente abandonada não foi retomada: uma requisição interrompida entre a reserva e a gravação bloquearia a correlação até o fim do TTL'
);

$segunda = F3Base_Modulo_Endpoint_Leads::reservar( 'correlacao-abandonada', 'registro-terceiro' );

afirmar(
	$nome,
	false === $segunda['novo'],
	'piso da retomada: a reserva recém-retomada foi retomada DE NOVO — o UPDATE precisa casar o carimbo lido para que dois pedidos concorrentes produzam uma retomada só'
);

/* A contingência por transiente tem a mesma compensação. */
bancada_limpa();
$wpdb->tabelas = array();

afirmar(
	$nome,
	! F3Base_Modulo_Endpoint_Leads::tabela_pronta(),
	'piso da contingência: sem tabela, tabela_pronta() continuou dizendo que está pronta'
);

$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	503 === $resposta->status,
	'contingência: a gravação recusada devolveu status ' . $resposta->status
);

$GLOBALS['f3b_bench']['insert_ok'] = true;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'contingência: a segunda tentativa depois da falha devolveu status ' . $resposta->status . ' — o caminho de transiente tinha o MESMO defeito e precisa da mesma compensação'
);

$resposta = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	200 === $resposta->status && true === ( $resposta->data['duplicado'] ?? false ),
	'contingência: o replay de correlação já gravada passou'
);

/* ==========================================================================
 * leads.atividade_so_com_persistencia
 * ======================================================================= */

$nome = 'leads.atividade_so_com_persistencia';

bancada_limpa();

$GLOBALS['f3b_bench']['insert_ok'] = false;
postar( carga( array( 'correlation_id' => 'correlacao-sem-persistencia' ) ) );

$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );
$falha  = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_LEAD );

afirmar(
	$nome,
	array() === $aceito,
	'piso: a atividade "último registro aceito" foi carimbada mesmo sem persistência — a tela do site-core passa a apontar para onde nada foi escrito'
);

afirmar(
	$nome,
	array() !== $falha && '' !== (string) ( $falha['destino'] ?? '' ),
	'a recusa não deixou carimbo próprio: o ramo adverso não pode simplesmente sumir da tela'
);

afirmar(
	$nome,
	str_contains( (string) ( $falha['motivo'] ?? '' ), F3Base_Modulo_Endpoint_Leads::CPT ),
	'o carimbo da recusa não NOMEIA os destinos que recusaram'
);

/* TETO: com persistência, o carimbo sai e aponta para o destino real. */
$GLOBALS['f3b_bench']['insert_ok'] = true;
postar( carga( array( 'correlation_id' => 'correlacao-com-persistencia' ) ) );

$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::CPT === (string) ( $aceito['destino'] ?? '' ),
	'teto: a gravação aceita não carimbou o destino real'
);

/* O estado do módulo reflete a recusa mais recente, em vez de calar. */
bancada_limpa();
$GLOBALS['f3b_bench']['insert_ok'] = false;
postar( carga( array( 'correlation_id' => 'correlacao-degradada' ) ) );

$estado = ( new F3Base_Modulo_Endpoint_Leads() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" com a última tentativa recusada: gravação que não aconteceu não pode sair verde na tela'
);

/* ==========================================================================
 * leads.status_da_gravacao
 * ======================================================================= */

$nome = 'leads.status_da_gravacao';

bancada_limpa();

$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-do-status' ) ) );

/* PISO: 201 Created com ok:false diz que o recurso existe. Não pode voltar. */
afirmar(
	$nome,
	201 !== $resposta->status,
	'piso: nenhum destino aceitou o lead e a resposta saiu 201 Created — o cliente é informado de que o recurso foi criado quando nada foi escrito'
);

afirmar(
	$nome,
	$resposta->status >= 500 && $resposta->status < 600,
	'a gravação indisponível saiu com status ' . $resposta->status . ', e falha de armazenamento do servidor é 5xx'
);

afirmar(
	$nome,
	false === ( $resposta->data['ok'] ?? true ) && false === ( $resposta->data['registrado'] ?? true ),
	'a resposta da gravação recusada não diz ok=false e registrado=false'
);

afirmar(
	$nome,
	'' !== (string) ( $resposta->data['codigo'] ?? '' ),
	'a resposta da gravação recusada não traz código: erro sem código é erro que o cliente não sabe distinguir'
);

foreach ( array( 'reenviar', 'WhatsApp' ) as $instrucao ) {
	afirmar(
		$nome,
		str_contains( (string) ( $resposta->data['motivo'] ?? '' ), $instrucao ),
		'a resposta da gravação recusada não diz ao visitante o que fazer: falta "' . $instrucao . '" no motivo'
	);
}

/* TETO: a gravação aceita responde 201 com registrado verdadeiro. */
bancada_limpa();
$resposta = postar( carga( array( 'correlation_id' => 'correlacao-do-status-ok' ) ) );

afirmar(
	$nome,
	201 === $resposta->status && true === ( $resposta->data['registrado'] ?? false ),
	'teto: a gravação aceita saiu com status ' . $resposta->status . ' e registrado=' . var_export( $resposta->data['registrado'] ?? null, true )
);

afirmar(
	$nome,
	'' !== (string) ( $resposta->data['record_id'] ?? '' ),
	'a gravação aceita não devolveu o record_id nascido no servidor'
);

/* ==========================================================================
 * leads.rate_limit_atomico
 * ======================================================================= */

$nome = 'leads.rate_limit_atomico';

bancada_limpa();

$chave_limite = hash( 'sha256', 'limite-de-bancada' );

/*
 * PISO: a bancada reproduz o defeito? Com os transientes CONGELADOS — que é o
 * que duas requisições concorrentes enxergam —, o caminho de ler-modificar-
 * gravar precisa PERDER o incremento.
 */
$GLOBALS['f3b_bench']['congelados'] = $GLOBALS['f3b_bench']['transientes'];

$perdido_a = F3Base_Modulo_Endpoint_Leads::incrementar_por_transiente( $chave_limite, 600 );
$perdido_b = F3Base_Modulo_Endpoint_Leads::incrementar_por_transiente( $chave_limite, 600 );

afirmar(
	$nome,
	1 === $perdido_a && 1 === $perdido_b,
	'piso: sob leitura congelada o caminho de transiente devolveu ' . $perdido_a . ' e ' . $perdido_b . ' — a bancada não está reproduzindo a perda de incremento, e o teto abaixo aprovaria por acaso'
);

/* TETO: o incremento no banco não perde nada sob a MESMA leitura congelada. */
$atomico = array();

for ( $i = 0; $i < 5; $i++ ) {
	$atomico[] = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_limite, 600 );
}

$GLOBALS['f3b_bench']['congelados'] = null;

afirmar(
	$nome,
	array( 1, 2, 3, 4, 5 ) === $atomico,
	'teto: cinco incrementos concorrentes devolveram ' . implode( ',', $atomico ) . ' — quem soma tem de ser o banco, numa instrução só, senão N requisições leem o mesmo valor e o balde deixa de segurar'
);

/* Uma instrução por incremento: o balde não tem leitura separada da escrita. */
$instrucoes = 0;

foreach ( $wpdb->fita as $linha ) {
	if ( str_contains( $linha, 'ON DUPLICATE KEY UPDATE' ) ) {
		++$instrucoes;
	}
}

afirmar(
	$nome,
	5 === $instrucoes,
	'os cinco incrementos gastaram ' . $instrucoes . ' instrução(ões) de soma no banco: o incremento tem de ser UMA instrução, sem SELECT antes'
);

/*
 * PISO do driver cego: sem LAST_INSERT_ID() o incremento JÁ aconteceu, e devolver
 * 1 daria um balde que nunca fecha — limite que nunca fecha é pior que limite
 * nenhum, porque parece que existe.
 */
bancada_limpa();
$chave_cega = hash( 'sha256', 'limite-com-driver-cego' );

F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_cega, 600 );
$GLOBALS['f3b_bench']['insert_id_cego'] = true;

$cegos = array();

for ( $i = 0; $i < 3; $i++ ) {
	$cegos[] = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_cega, 600 );
}

$GLOBALS['f3b_bench']['insert_id_cego'] = false;

afirmar(
	$nome,
	array( 2, 3, 4 ) === $cegos,
	'piso do driver cego: sem LAST_INSERT_ID() a contagem devolveu ' . implode( ',', $cegos ) . ' — devolver 1 aqui é um balde que nunca fecha'
);

/* A janela expirada zera o balde, em vez de somar para sempre. */
bancada_limpa();
$chave_curta = hash( 'sha256', 'limite-de-janela-curta' );

F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_curta, 1 );
$linha_curta = $wpdb->tabelas[ $tabela ]['linhas'][ $chave_curta ];
$wpdb->tabelas[ $tabela ]['linhas'][ $chave_curta ]['expira_em'] = time() - 10;

$depois = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_curta, 600 );

afirmar(
	$nome,
	1 === $depois,
	'a janela vencida devolveu ' . $depois . ' em vez de reiniciar o balde em 1'
);

/* ==========================================================================
 * leads.origem_declarada
 * ======================================================================= */

$nome = 'leads.origem_declarada';

bancada_limpa();

/*
 * A cadeia que UM proxy confiável produz: ele acrescenta o IP de quem falou com
 * ele, e o visitante que não mandou nada deixa a lista com um elemento só.
 */
$servidor_com_proxy = array(
	'REMOTE_ADDR'          => '198.51.100.10',
	'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
);

/* PISO: sem declaração, o cabeçalho é IGNORADO. */
$origem = F3Base_Modulo_Endpoint_Leads::origem( $servidor_com_proxy );

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'piso: sem cabeçalho declarado a origem saiu ' . $origem['valor'] . ' por ' . $origem['fonte'] . ' — cabeçalho de proxy aceito sem declaração é o visitante escolhendo o balde em que conta'
);

/* TETO: declarado, o cabeçalho é lido descontando os saltos confiáveis. */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 1,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$origem = F3Base_Modulo_Endpoint_Leads::origem( $servidor_com_proxy );

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'] && 'cabecalho-declarado' === $origem['fonte'],
	'teto: com o cabeçalho declarado a origem saiu ' . $origem['valor'] . ' por ' . $origem['fonte'] . ', e devia ser o IP do visitante'
);

/* PISO do spoofing: o visitante empurra um valor a mais e não escolhe o balde. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => 'balde-inventado, 203.0.113.99',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'],
	'piso do spoofing: o valor que o visitante empurrou na frente da cadeia virou a origem (' . $origem['valor'] . '), e com ela ele escolhe em que balde conta'
);

/* Dois proxies confiáveis: a declaração desconta os dois saltos, não um. */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 2,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99, 198.51.100.20',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'],
	'com dois saltos declarados a origem saiu ' . $origem['valor'] . ' em vez do IP do visitante'
);

/* Cadeia mais curta que a declaração não vira origem: ela volta a REMOTE_ADDR. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
	)
);

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'cadeia mais curta que os saltos declarados virou origem (' . $origem['valor'] . ') em vez de voltar para REMOTE_ADDR'
);

F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 1,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

/* Cadeia mais curta que a declaração, ou valor que não é IP: volta a REMOTE_ADDR. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => 'nao-e-um-ip',
	)
);

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'valor que não é IP no cabeçalho declarado virou origem (' . $origem['valor'] . ') em vez de voltar para REMOTE_ADDR'
);

$origem = F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10' ) );

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'],
	'cabeçalho declarado e AUSENTE na requisição não voltou para REMOTE_ADDR'
);

/* O nome do cabeçalho vira variável de servidor, com e sem o prefixo. */
foreach ( array( 'X-Forwarded-For' => 'HTTP_X_FORWARDED_FOR', 'CF-Connecting-IP' => 'HTTP_CF_CONNECTING_IP', 'HTTP_CF_CONNECTING_IP' => 'HTTP_CF_CONNECTING_IP', '' => '' ) as $declarado => $esperado ) {
	afirmar(
		$nome,
		$esperado === F3Base_Modulo_Endpoint_Leads::chave_de_servidor( $declarado ),
		'o cabeçalho declarado "' . $declarado . '" virou "' . F3Base_Modulo_Endpoint_Leads::chave_de_servidor( $declarado ) . '" em vez de "' . $esperado . '"'
	);
}

/* O balde muda com a origem: dois visitantes atrás do mesmo proxy não se somam. */
bancada_limpa();

F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 1,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$um    = hash( 'sha256', 'limite|' . F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10', 'HTTP_X_FORWARDED_FOR' => '203.0.113.1' ) )['valor'] . '|' . wp_salt( 'nonce' ) );
$outro = hash( 'sha256', 'limite|' . F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10', 'HTTP_X_FORWARDED_FOR' => '203.0.113.2' ) )['valor'] . '|' . wp_salt( 'nonce' ) );

afirmar(
	$nome,
	$um !== $outro,
	'dois visitantes distintos atrás do mesmo proxy caíram na MESMA chave de balde: é o balde único de 20 por 10 minutos para o proxy inteiro'
);

/* ==========================================================================
 * cadencia.ouvinte_registrado
 * ======================================================================= */

$nome = 'cadencia.ouvinte_registrado';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

/* PISO: o núcleo do WordPress não tem as recorrências que a configuração pede. */
$nucleo = f3b_recorrencias_do_nucleo();

afirmar(
	$nome,
	! isset( $nucleo['monthly'] ),
	'piso: a bancada inventou uma recorrência "monthly" no núcleo — sem a ausência dela, a degradação silenciosa não é reproduzível'
);

afirmar(
	$nome,
	! isset( $nucleo[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ] ) && ! isset( $nucleo[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ] ),
	'piso: as recorrências do módulo já existiam no núcleo da bancada'
);

/* PISO: sem ouvinte, o evento dispara e ninguém escuta — que é a 1.0.17. */
afirmar(
	$nome,
	0 === has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ),
	'piso: a bancada começou com ouvinte no hook da cadência, e não há como provar que é o registro que o cria'
);

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 3,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

/* TETO: o registro único enganchou o ouvinte. */
afirmar(
	$nome,
	has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ) > 0,
	'teto: depois do registro único NINGUÉM escuta ' . F3Base_Modulo_Cadencia_Relatorio::HOOK . ' — o evento dispara, o WP-Cron o reagenda, e nada acontece'
);

$agendas = wp_get_schedules();

afirmar(
	$nome,
	isset( $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ] ) && 30 * DAY_IN_SECONDS === (int) $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ]['interval'],
	'teto: a recorrência mensal não foi registrada com trinta dias de intervalo, e "mensal" volta a cair em daily'
);

afirmar(
	$nome,
	isset( $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ] ) && 15 * DAY_IN_SECONDS === (int) $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ]['interval'],
	'teto: a recorrência quinzenal não foi registrada com quinze dias, e "quinzenal" volta a cair em weekly, com o DOBRO da frequência'
);

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL === F3Base_Modulo_Cadencia_Relatorio::recorrencia_declarada(),
	'a periodicidade "mensal" da configuração não resolveu para a recorrência mensal registrada'
);

/* O agendamento acontece com a recorrência DECLARADA, não com a mais próxima. */
( new F3Base_Modulo_Cadencia_Relatorio() )->garantir_agendamento();

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL === F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada(),
	'o evento ficou agendado com "' . F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada() . '" e a configuração declara mensal'
);

/* O estado NOMEIA a divergência quando quem agendou não conhecia a recorrência. */
$GLOBALS['f3b_bench']['eventos'][ F3Base_Modulo_Cadencia_Relatorio::HOOK ]['schedule'] = 'daily';

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'] && str_contains( $estado['motivo'], 'daily' ),
	'a degradação de mensal para daily saiu como "' . $estado['estado'] . '" sem nomear a recorrência observada: era exatamente isso que acontecia em silêncio'
);

/* ==========================================================================
 * cadencia.execucao_registrada
 * ======================================================================= */

$nome = 'cadencia.execucao_registrada';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks']   = array();
$GLOBALS['f3b_bench']['eventos'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'quinzenal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

$modulo = new F3Base_Modulo_Cadencia_Relatorio();
$modulo->garantir_agendamento();

/*
 * DUAS execuções: a primeira CRIA as options de estado que ela mesma grava, e
 * comparar a contagem da primeira com a medição de agora compararia dois
 * momentos diferentes. Da segunda em diante o conjunto é estável, e é sobre ele
 * que a conferência do número tem sentido.
 */
$modulo->executar_por_cron();
$modulo->executar_por_cron();

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

foreach ( array( 'em', 'gatilho', 'resultado', 'duracao_ms', 'atraso_segundos', 'proxima', 'modulos', 'options' ) as $campo ) {
	afirmar(
		$nome,
		array_key_exists( $campo, $carimbo ),
		'a execução não registrou o campo "' . $campo . '": cadência que roda sem deixar última execução, próxima, duração, resultado e erro é cadência que ninguém sabe se rodou'
	);
}

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RESULTADO_OK === (string) ( $carimbo['resultado'] ?? '' ),
	'a execução limpa terminou em "' . (string) ( $carimbo['resultado'] ?? '' ) . '"'
);

afirmar(
	$nome,
	'' === (string) ( $carimbo['erro'] ?? 'x' ),
	'a execução limpa registrou erro: ' . (string) ( $carimbo['erro'] ?? '' )
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['modulos'] ?? '' ), 'cadencia-relatorio' ),
	'o relatório não NOMEIA os módulos que mediu: contagem por estado sem a lista de nomes responde "quantos" e a pergunta é "quais"'
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['options'] ?? '' ), 'divergentes' ),
	'o relatório não diz quais options divergiram na releitura'
);

/* Nenhum número inventado: a contagem de options relidas bate com a medição. */
$relidas = 0;

foreach ( F3Base_Options::nomes() as $option ) {
	if ( F3Base_Options::existe( $option ) ) {
		++$relidas;
	}
}

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['options'] ?? '' ), (string) $relidas . ' relida' ),
	'a contagem de options relidas no texto do relatório não bate com a medição de agora (' . $relidas . '): número em texto de relatório sai de medição, nunca de estimativa'
);

/* PISO do atraso: previsão no passado precisa virar atraso medido e degradação. */
$atrasado = time() - ( F3Base_Modulo_Cadencia_Relatorio::atraso_tolerado() + 3600 );

F3Base_Options::gravar(
	'f3base_cadencia_estado',
	array(
		'ajustes'  => 0,
		'previsto' => $atrasado,
	),
	F3Base_Options::ORIGEM_MANUAL
);

$modulo->executar_por_cron();
$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	(int) ( $carimbo['atraso_segundos'] ?? 0 ) > F3Base_Modulo_Cadencia_Relatorio::atraso_tolerado(),
	'piso do atraso: a execução atrasada registrou atraso de ' . (int) ( $carimbo['atraso_segundos'] ?? 0 ) . 's — evento atrasado que não é medido é evento que ninguém sabe que atrasou'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" com a última execução acima da tolerância de atraso'
);

/* PISO do erro: a medição que explode vira resultado erro NOMEADO, nunca sucesso. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

add_filter(
	'f3base_site_core_relatorio',
	static function ( $relatorio ) {
		throw new RuntimeException( 'a medição do relatório falhou na bancada' );
	}
);

( new F3Base_Modulo_Cadencia_Relatorio() )->executar_por_cron();

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RESULTADO_ERRO === (string) ( $carimbo['resultado'] ?? '' ),
	'piso do erro: a medição que explodiu registrou resultado "' . (string) ( $carimbo['resultado'] ?? '' ) . '"'
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['erro'] ?? '' ), 'a medição do relatório falhou na bancada' ),
	'piso do erro: o erro não foi registrado com a mensagem que o produziu'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" depois de uma execução que terminou em erro'
);

$GLOBALS['f3b_bench']['hooks'] = array();

/* ==========================================================================
 * cadencia.contador_de_ajustes
 * ======================================================================= */

$nome = 'cadencia.contador_de_ajustes';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks']   = array();
$GLOBALS['f3b_bench']['eventos'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'nenhuma',
		'apos_n_ajustes' => 3,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

afirmar(
	$nome,
	3 === F3Base_Modulo_Cadencia_Relatorio::apos_n_ajustes(),
	'piso: a chave apos_n_ajustes gravada pelo implantador não é LIDA por ninguém — era exatamente esse o defeito: o relatório prometia um gatilho sobre um contador inexistente'
);

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o contador não começou em zero'
);

F3Base_Options::gravar( 'f3base_retencao_meses', 7, F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	1 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'teto: a escrita numa option gerenciada não foi contada como ajuste (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* PISO da reentrância: a própria atividade não pode contar como ajuste. */
F3Base_Atividade::registrar( F3Base_Atividade::ULTIMO_LEAD, array( 'record_id' => 'apenas-atividade' ) );

afirmar(
	$nome,
	1 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'piso da reentrância: o carimbo de atividade contou como ajuste (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ') — o site mudar porque rodou não é alguém ter ajustado alguma coisa, e contá-lo faz o gatilho disparar sozinho'
);

F3Base_Options::gravar( 'f3base_linkedin_partner_id', '123456', F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	2 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o segundo ajuste não foi contado (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* TETO: ao alcançar o alvo, o gatilho DISPARA e zera o contador. */
F3Base_Options::gravar( 'f3base_retencao_meses', 9, F3Base_Options::ORIGEM_MANUAL );

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::GATILHO_AJUSTES === (string) ( $carimbo['gatilho'] ?? '' ),
	'teto: o terceiro ajuste NÃO disparou a execução (gatilho registrado: "' . (string) ( $carimbo['gatilho'] ?? 'nenhum' ) . '") — chave que não faz nada é pior que chave ausente, porque produz confiança'
);

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o contador não foi zerado depois do disparo (ficou em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* PISO do gatilho desligado: alvo zero não mantém contador nem promete nada. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();
( new F3Base_Modulo_Cadencia_Relatorio() )->garantir_agendamento();
F3Base_Options::gravar( 'f3base_retencao_meses', 11, F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'piso do gatilho desligado: com apos_n_ajustes em zero o contador andou mesmo assim'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	str_contains( $estado['motivo'], 'zero' ),
	'com o gatilho desligado o estado do módulo não diz que nada promete disparar por ele: "' . $estado['motivo'] . '"'
);

/* Sem periodicidade e sem gatilho, o módulo é INERTE e declara por quê. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'nenhuma',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => '',
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$modulo = new F3Base_Modulo_Cadencia_Relatorio();

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === $modulo->estado()['estado'] && ! $modulo->deve_registrar(),
	'sem periodicidade e sem gatilho o módulo continuou registrando hooks: módulo inativo é inerte de verdade'
);

requisicao_nova();
F3Base_Site_Core::registrar();

afirmar(
	$nome,
	0 === has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ),
	'o módulo inativo enganchou o hook mesmo assim'
);

/* ---------- cta.publicado_pela_presenca_do_numero: teto e piso ---------- */

/*
 * A REGRA DA 1.0.19, e ela tem um lado só: a PRESENÇA do número decide se o
 * regime existe. Não há mais interruptor `ativo` ao lado do destino — havia
 * dois fatos podendo discordar, e eles discordavam.
 *
 * TETO: com número gravado, o bloco do CTA é publicado.
 * PISO: sem número, o bloco NÃO é publicado — nem no comportamento degradado.
 * Publicar um botão que não leva a lugar nenhum é pior que não ter botão, e era
 * isso que a base entregava: "Falar com a equipe" apontando para a própria
 * página de contato.
 *
 * O DISCRIMINANTE É A CLASSE, que mora no arquivo do pattern, e não o atributo,
 * que é carimbo de render e depende de `WP_HTML_Tag_Processor`. Decidir pelo
 * atributo deixaria o botão publicado justamente na instalação onde o
 * processador não existe — e é isso que o último ramo mede: esta bancada NÃO
 * tem o processador, e o CTA continua não sendo publicado.
 */

$nome = 'cta.publicado_pela_presenca_do_numero';

bancada_limpa();

$modulo_cta = new F3Base_Modulo_Leads_Whatsapp();

$bloco_do_cta = '<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
	. '<a class="wp-block-button__link wp-element-button" href="/contato/" '
	. F3Base_Modulo_Leads_Whatsapp::ATRIBUTO . '="cta">Falar com a equipe</a></div>';

$bloco_alheio = '<div class="wp-block-button"><a class="wp-block-button__link" href="/blog/">Ler o blog</a></div>';

/* PISO: número vazio — a option nasce assim no template. */
afirmar(
	$nome,
	'' === $modulo_cta->promover_cta( $bloco_do_cta, array() ),
	'piso da publicação: sem número em f3base_contato o bloco do CTA foi PUBLICADO — um botão que não leva a lugar nenhum é pior que não ter botão, e é isso que a presença do valor passou a decidir'
);

afirmar(
	$nome,
	$bloco_alheio === $modulo_cta->promover_cta( $bloco_alheio, array() ),
	'piso do alcance: um bloco que não é o CTA foi alterado — a regra vale para o CTA e para mais nada'
);

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === $modulo_cta->estado()['estado'],
	'piso do estado: sem número o módulo fechou "' . $modulo_cta->estado()['estado'] . '" em vez de inativo — regime que não existe não está degradado, e degradado é reservado ao que está PIOR que o desenho'
);

afirmar(
	$nome,
	str_contains( $modulo_cta->estado()['motivo'], 'não é publicado' ),
	'piso do estado: o motivo não diz que o CTA não é publicado — o operador precisa saber o que aconteceu com o botão, não só que falta um número'
);

/* TETO: com número gravado, o bloco do CTA É publicado. */
F3Base_Options::gravar(
	'f3base_contato',
	array( 'whatsapp_e164' => '5511999999999' ),
	F3Base_Options::ORIGEM_MANUAL
);

$modulo_com_numero = new F3Base_Modulo_Leads_Whatsapp();

afirmar(
	$nome,
	'' !== $modulo_com_numero->promover_cta( $bloco_do_cta, array() ),
	'teto da publicação: com número gravado o CTA deixou de ser publicado — preencher a chave tem de fazer o botão existir na página seguinte, sem passo manual'
);

afirmar(
	$nome,
	str_contains( $modulo_com_numero->promover_cta( $bloco_do_cta, array() ), F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA ),
	'teto da publicação: o bloco publicado perdeu a classe do CTA'
);

/*
 * PISO DO DISCRIMINANTE: esta bancada NÃO tem WP_HTML_Tag_Processor, e é
 * justamente aí que decidir pelo atributo carimbado deixaria o botão publicado.
 */
afirmar(
	$nome,
	! class_exists( 'WP_HTML_Tag_Processor' ),
	'piso do discriminante: a bancada passou a ter WP_HTML_Tag_Processor, e sem a ausência dele este ramo não reproduz a instalação em que o atributo nunca é carimbado'
);

bancada_limpa();

$modulo_sem_atributo = new F3Base_Modulo_Leads_Whatsapp();

afirmar(
	$nome,
	'' === $modulo_sem_atributo->promover_cta(
		'<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
			. '<a class="wp-block-button__link" href="/contato/">Falar com a equipe</a></div>',
		array()
	),
	'piso do discriminante: sem o atributo carimbado — que é o que acontece quando WP_HTML_Tag_Processor não existe — o CTA voltou a ser publicado sem número'
);

/* ==========================================================================
 * cta.regra_de_publicacao_registrada
 *
 * O ALCANCE, medido pelo CAMINHO REAL. As afirmações acima chamam
 * `promover_cta()` direto; num site quem a chama é o filtro `render_block`, e é
 * ele que precisa existir para decidir. Da 1.0.19 à 1.1.0 o filtro só era
 * registrado com o módulo ATIVO — isto é, com número gravado —, e aí a condição
 * da supressão (número vazio) já não podia acontecer: a regra estava escrita em
 * três documentos e não rodava em site nenhum, e o botão morto do pattern ia ao
 * ar. A marca `sempre` no item do hook é o que corrigiu isso.
 *
 * Daqui para baixo NADA é chamado direto: tudo passa por `apply_filters()`, com
 * o módulo no estado que ele terá em produção.
 * ======================================================================= */

$nome = 'cta.regra_de_publicacao_registrada';

bancada_limpa();
F3Base_Site_Core::registrar();

$modulo_inativo = new F3Base_Modulo_Leads_Whatsapp();

/* PISO: a bancada reproduz o estado de produção? Número vazio, módulo INATIVO. */
afirmar(
	$nome,
	F3Base_Modulo::INATIVO === $modulo_inativo->estado()['estado'] && ! $modulo_inativo->deve_registrar(),
	'piso: a bancada não reproduz o estado de produção — com f3base_contato vazia o módulo tem de fechar inativo, e é justamente nesse estado que a regra de publicação precisa rodar'
);

/* TETO DO REGISTRO: o filtro existe MESMO com o módulo inativo. */
afirmar(
	$nome,
	ouvintes_da_classe( 'render_block', 'F3Base_Modulo_Leads_Whatsapp' ) > 0,
	'teto do registro: o filtro render_block NÃO foi registrado com o módulo inativo — foi este o defeito medido da 1.0.19 à 1.1.0: a regra de publicação do CTA existia, estava afirmada em três documentos e não rodava, porque só era registrada quando a condição dela já não podia acontecer'
);

afirmar(
	$nome,
	1 === count(
		array_filter(
			$modulo_inativo->hooks(),
			static fn ( array $hook ): bool => ! empty( $hook['sempre'] )
		)
	),
	'teto do registro: a exceção deixou de ser declarada por hook — sem a marca no item, quem lê o módulo não sabe qual hook escapa da regra do inativo, e a exceção vira comportamento escondido'
);

/* PISO DA EXCEÇÃO: ela alcança UM hook. O enfileiramento continua inerte. */
afirmar(
	$nome,
	0 === ouvintes_da_classe( 'wp_enqueue_scripts', 'F3Base_Modulo_Leads_Whatsapp' ),
	'piso da exceção: um hook sem a marca foi registrado com o módulo inativo — a exceção é por hook, e "módulo inativo é inerte" continua valendo para asset, endpoint e tabela'
);

/* OS QUATRO QUADRANTES, agora pelo filtro e não pela chamada direta. */
$pelo_filtro = static function ( string $html ): string {
	return (string) apply_filters( 'render_block', $html, array( 'blockName' => 'core/button' ) );
};

$cta_do_modelo = '<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
	. '<a class="wp-block-button__link wp-element-button" href="' . F3Base_Modulo_Leads_Whatsapp::HREF_DO_MODELO . '" '
	. F3Base_Modulo_Leads_Whatsapp::ATRIBUTO . '="cta">Falar com a equipe</a></div>';

$cta_do_agente = '<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
	. '<a class="wp-block-button__link wp-element-button" href="https://campanha.exemplo.test/lp-outubro" '
	. F3Base_Modulo_Leads_Whatsapp::ATRIBUTO . '="cta">Falar com a equipe</a></div>';

afirmar(
	$nome,
	'' === $pelo_filtro( $cta_do_modelo ),
	'quadrante 1 pelo filtro: sem número, o CTA com o href do modelo FOI publicado — é o botão morto do pattern indo ao ar, que é exatamente o que a regra existe para impedir e o que ela não impedia'
);

afirmar(
	$nome,
	$cta_do_agente === $pelo_filtro( $cta_do_agente ),
	'quadrante 2 pelo filtro: sem número, o CTA com destino próprio foi suprimido ou alterado — apagar o destino que alguém escolheu é o inverso da premissa desta release'
);

F3Base_Options::gravar( 'f3base_contato', array( 'whatsapp_e164' => '5511999999999' ), F3Base_Options::ORIGEM_MANUAL );
requisicao_nova();
$GLOBALS['f3b_bench']['hooks'] = array();
F3Base_Site_Core::registrar();

afirmar(
	$nome,
	( new F3Base_Modulo_Leads_Whatsapp() )->deve_registrar() && ouvintes_da_classe( 'wp_enqueue_scripts', 'F3Base_Modulo_Leads_Whatsapp' ) > 0,
	'teto do estado: com número gravado o módulo continua fechando inativo, ou o hook normal dele não foi registrado — a marca sempre não pode ter substituído a regra, só aberto uma exceção nela'
);

afirmar(
	$nome,
	'' !== $pelo_filtro( $cta_do_modelo ) && str_contains( $pelo_filtro( $cta_do_modelo ), F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA ),
	'quadrante 3 pelo filtro: com número gravado o CTA do modelo deixou de ser publicado'
);

afirmar(
	$nome,
	str_contains( $pelo_filtro( $cta_do_agente ), 'https://campanha.exemplo.test/lp-outubro' ),
	'quadrante 4 pelo filtro: com número gravado o destino do agente foi sobrescrito — o pacote preenche quando falta e não manda no que já tem dono'
);

/* ==========================================================================
 * options.chave_desconhecida_preservada
 *
 * O DEFEITO MEDIDO na 1.0.19: todo sanitizador de grupo RECONSTRUÍA o array a
 * partir das chaves declaradas. O agente acrescentava `telefone` a
 * `f3base_contato` pelo canal, a escrita entrava no banco, e a primeira LEITURA
 * devolvia o valor sem a chave — apagada em silêncio.
 * ======================================================================= */

$nome = 'options.chave_desconhecida_preservada';

bancada_limpa();

/* PISO: a bancada reproduz o defeito? O reconstrutor de chaves fixas PERDE a chave. */
$reconstrutor_da_1_0_19 = static function ( array $bruto ): array {
	return array(
		'whatsapp_e164'   => (string) ( $bruto['whatsapp_e164'] ?? '' ),
		'email_leads'     => (string) ( $bruto['email_leads'] ?? '' ),
		'mensagem_padrao' => (string) ( $bruto['mensagem_padrao'] ?? '' ),
	);
};

$do_agente = array(
	'whatsapp_e164' => '+55 (11) 99999-9999',
	'telefone'      => '+55 11 3333-4444',
	'horario'       => array( 'seg_sex' => '09:00-18:00' ),
);

afirmar(
	$nome,
	! array_key_exists( 'telefone', $reconstrutor_da_1_0_19( $do_agente ) ),
	'piso: a bancada não reproduz o descarte da 1.0.19 — o reconstrutor de chaves fixas devolveu a chave desconhecida, e sem esse descarte o teto abaixo aprovaria por acaso'
);

F3Base_Options::gravar( 'f3base_contato', $do_agente, F3Base_Options::ORIGEM_MANUAL );
$lido_contato = F3Base_Options::ler( 'f3base_contato' );

afirmar(
	$nome,
	is_array( $lido_contato ) && '+55 11 3333-4444' === (string) ( $lido_contato['telefone'] ?? '' ),
	'teto: a chave que o agente acrescentou a f3base_contato NÃO sobreviveu à leitura — é o apagamento silencioso da 1.0.19, e ele é o inverso da premissa desta release'
);

afirmar(
	$nome,
	is_array( $lido_contato ) && '09:00-18:00' === (string) ( $lido_contato['horario']['seg_sex'] ?? '' ),
	'teto aninhado: a lista desconhecida foi achatada ou perdida — preservar chave desconhecida vale para a estrutura, não só para o escalar'
);

/* PISO da normalização: preservar o desconhecido não é parar de normalizar o conhecido. */
afirmar(
	$nome,
	is_array( $lido_contato ) && '5511999999999' === (string) ( $lido_contato['whatsapp_e164'] ?? '' ),
	'piso da normalização: a chave CONHECIDA deixou de ser normalizada — preservar o desconhecido virou aceitar qualquer coisa, que é o defeito oposto'
);

/* TETO do catálogo: a regra vale para TODA option de grupo, e não para uma. */
foreach ( F3Base_Options::catalogo() as $option_do_catalogo => $declaracao_do_catalogo ) {
	$padrao_do_catalogo = $declaracao_do_catalogo['padrao'];

	if ( 'grupo' !== (string) $declaracao_do_catalogo['campo'] || ! is_array( $padrao_do_catalogo ) || array() === $padrao_do_catalogo ) {
		continue;
	}

	if ( array_keys( $padrao_do_catalogo ) === range( 0, count( $padrao_do_catalogo ) - 1 ) ) {
		continue;
	}

	$com_desconhecida = $padrao_do_catalogo;
	$com_desconhecida['chave_de_bancada'] = 'valor-do-agente';

	$normalizado = F3Base_Options::sanitizar( $option_do_catalogo, $com_desconhecida );

	afirmar(
		$nome,
		is_array( $normalizado ) && 'valor-do-agente' === (string) ( $normalizado['chave_de_bancada'] ?? '' ),
		'teto do catálogo: ' . $option_do_catalogo . ' descartou a chave desconhecida na leitura — a regra é do catálogo inteiro, e uma option de fora dela é a próxima a apagar trabalho do agente'
	);
}

/* TETO das options em LISTA: a chave desconhecida sobrevive DENTRO da entrada. */
$redirects_do_agente = F3Base_Options::sanitizar(
	'f3base_redirects',
	array(
		array(
			'de'    => '/antigo',
			'para'  => '/novo',
			'status' => 301,
			'nota'  => 'motivo escrito pelo agente',
		),
	)
);

afirmar(
	$nome,
	'motivo escrito pelo agente' === (string) ( $redirects_do_agente[0]['nota'] ?? '' ),
	'teto de lista: f3base_redirects apagou a chave desconhecida da regra — a entrada é reconstruída, e reconstruir é apagar'
);

$journal_do_agente = F3Base_Options::sanitizar(
	'f3base_journal_eliminacao',
	array(
		array(
			'regime'    => 'operacional',
			'contagem'  => 3,
			'chamado'   => 'OS-4471',
		),
	)
);

afirmar(
	$nome,
	'OS-4471' === (string) ( $journal_do_agente[0]['chamado'] ?? '' ),
	'teto de lista: f3base_journal_eliminacao apagou a chave desconhecida da entrada'
);

/* PISO da chave impossível: nome que não sobra ao alfabeto não vira chave vazia. */
$com_chave_torta = F3Base_Options::sanitizar(
	'f3base_contato',
	array(
		'whatsapp_e164' => '5511999999999',
		'<b>'           => 'valor',
	)
);

afirmar(
	$nome,
	! array_key_exists( '', $com_chave_torta ),
	'piso da chave impossível: um nome que não sobrou à redução virou a chave vazia — gravar sob "" é perder o valor de outro jeito'
);

/* ==========================================================================
 * seguranca.coop_do_valor_gravado
 *
 * O DEFEITO MEDIDO: `sanitiza_cabecalhos()` devolvia `coop` como LITERAL,
 * ignorando o valor armazenado, e o emissor mandava a constante da classe. Quem
 * gravasse outro valor lia de volta o do pacote — e a leitura de volta conferia
 * contra o que a própria sanitização tinha imposto.
 * ======================================================================= */

$nome = 'seguranca.coop_do_valor_gravado';

bancada_limpa();

$cabecalhos_padrao = ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos();

/* PISO: a bancada parte do valor do pacote? Sem isso, a troca abaixo não prova nada. */
afirmar(
	$nome,
	F3Base_Modulo_Cabecalhos::COOP_EXIGIDO === (string) ( $cabecalhos_padrao['Cross-Origin-Opener-Policy'] ?? '' ),
	'piso: o padrão embutido não é o valor recomendado do pacote, e sem essa diferença a troca abaixo não distingue o valor gravado do literal'
);

F3Base_Options::gravar( 'f3base_cabecalhos', array( 'coop' => 'same-origin' ), F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	'same-origin' === (string) ( F3Base_Options::ler( 'f3base_cabecalhos' )['coop'] ?? '' ),
	'teto da leitura: o valor gravado não sobreviveu à sanitização — é o literal da 1.0.19 vencendo a option, e quem gravou não tem como saber por quê'
);

$cabecalhos_gravados = ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos();

afirmar(
	$nome,
	'same-origin' === (string) ( $cabecalhos_gravados['Cross-Origin-Opener-Policy'] ?? '' ),
	'teto da emissão: o cabeçalho emitido não é o valor gravado — a option existia e não tinha efeito nenhum'
);

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === ( new F3Base_Modulo_Cabecalhos() )->estado()['estado'],
	'o módulo não NOMEIA a consequência do valor gravado: emitir o que pediram sem dizer o preço é a outra metade da honestidade'
);

afirmar(
	$nome,
	str_contains( ( new F3Base_Modulo_Cabecalhos() )->estado()['motivo'], 'janela' ),
	'o motivo não diz o que se perde: o operador precisa ler que a janela aberta pelo CTA perde a relação com esta aba'
);

/* PISO do vocabulário: valor que o navegador não conhece cai no padrão declarado. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_cabecalhos', array( 'coop' => 'valor-que-nao-existe' ), F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	F3Base_Modulo_Cabecalhos::COOP_EXIGIDO === (string) ( F3Base_Options::ler( 'f3base_cabecalhos' )['coop'] ?? '' ),
	'piso do vocabulário: valor fora do vocabulário do cabeçalho foi emitido — cabeçalho que o navegador ignora em silêncio é pior que cabeçalho ausente'
);

/* ==========================================================================
 * seguranca.referrer_policy_avisa_atribuicao
 * ======================================================================= */

$nome = 'seguranca.referrer_policy_avisa_atribuicao';

bancada_limpa();

/* PISO do ramo adverso: com o valor padrão, NÃO sai aviso nenhum. */
afirmar(
	$nome,
	array() === ( new F3Base_Modulo_Cabecalhos() )->avisos(),
	'piso do ramo adverso: o aviso saiu com o valor padrão gravado — aviso que sai sempre treina o operador a ignorar aviso, e foi a lição que a 1.0.14 pagou'
);

F3Base_Options::gravar(
	'f3base_cabecalhos',
	array( 'referrer_policy' => F3Base_Modulo_Cabecalhos::REFERRER_SEM_ORIGEM ),
	F3Base_Options::ORIGEM_MANUAL
);

$avisos_do_referrer = ( new F3Base_Modulo_Cabecalhos() )->avisos();

afirmar(
	$nome,
	1 === count( $avisos_do_referrer ),
	'teto: Referrer-Policy no-referrer gravado e nenhum aviso emitido — é o cabeçalho que apaga a origem dos quatro canais pagos, e ele passou calado'
);

afirmar(
	$nome,
	'WARN' === (string) ( $avisos_do_referrer[0]['estado'] ?? '' ),
	'o aviso não fecha em WARN: a lista de estados do contrato tem seis nomes, e este é o único que cabe em "funciona, e custa isto"'
);

$motivo_do_referrer = (string) ( $avisos_do_referrer[0]['motivo'] ?? '' );

afirmar(
	$nome,
	str_contains( $motivo_do_referrer, 'GA4' ) && str_contains( $motivo_do_referrer, 'Meta Ads' ) && str_contains( $motivo_do_referrer, 'LinkedIn Ads' ),
	'o aviso não NOMEIA a consequência nos canais: sem os nomes, ele é um alerta genérico sobre um cabeçalho de segurança'
);

/* TETO: avisar não é recusar. O valor continua sendo emitido. */
afirmar(
	$nome,
	F3Base_Modulo_Cabecalhos::REFERRER_SEM_ORIGEM === (string) ( ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos()['Referrer-Policy'] ?? '' ),
	'teto: o cabeçalho gravado deixou de ser emitido por causa do aviso — avisar é nomear o preço, e recusar seria decidir pelo projeto'
);

/* ==========================================================================
 * tracking.caminho_unico
 * ======================================================================= */

$nome = 'tracking.caminho_unico';

bancada_limpa();

/* PISO do slot vazio: nasce inerte, e inerte é NADA no HTML. */
afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_NENHUM === F3Base_Modulo_Tracking::caminho(),
	'piso do slot vazio: o catálogo nasce sem ID nenhum e o caminho não é "nenhum" — slot vazio que emite alguma coisa emite um placeholder'
);

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === ( new F3Base_Modulo_Tracking() )->estado()['estado'],
	'piso do slot vazio: o módulo não fecha inativo com o catálogo vazio — regime que não existe não está degradado'
);

( new F3Base_Modulo_Tracking() )->enfileirar();

afirmar(
	$nome,
	array() === $GLOBALS['f3b_bench']['scripts'],
	'piso do slot vazio: alguma coisa foi enfileirada sem nenhum ID gravado'
);

/* TETO do caminho direto: os IDs presentes chegam ao navegador. */
F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-ABCDEF1234', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar(
	'f3base_google_ads',
	array(
		'conversion_id'    => 'AW-123456789',
		'conversion_label' => 'AbC-D_efGhIjKlM',
	),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_DIRETO === F3Base_Modulo_Tracking::caminho(),
	'teto do caminho direto: com IDs gravados e sem container, o caminho deixou de ser o direto'
);

$medicao_direta = F3Base_Modulo_Tracking::dados_de_medicao();

afirmar(
	$nome,
	'G-ABCDEF1234' === (string) $medicao_direta['ga4']
		&& '123456789012345' === (string) $medicao_direta['meta']['pixelId']
		&& 'AW-123456789' === (string) $medicao_direta['ads']['id'],
	'teto do caminho direto: um dos IDs gravados não chegou ao navegador'
);

afirmar(
	$nome,
	'' === (string) $medicao_direta['gtm'],
	'teto do caminho direto: o container viajou junto das tags diretas, e é assim que a mesma conversão sai duas vezes'
);

/* TETO do container: ele decide, e os IDs diretos NEM CHEGAM ao navegador. */
F3Base_Options::gravar( 'f3base_gtm_container_id', 'GTM-ABC1234', F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_GTM === F3Base_Modulo_Tracking::caminho(),
	'teto do container: com GTM gravado, o caminho não virou o do container'
);

$medicao_gtm = F3Base_Modulo_Tracking::dados_de_medicao();

afirmar(
	$nome,
	'GTM-ABC1234' === (string) $medicao_gtm['gtm'],
	'teto do container: o container não chegou ao navegador'
);

afirmar(
	$nome,
	'' === (string) $medicao_gtm['ga4']
		&& '' === (string) $medicao_gtm['meta']['pixelId']
		&& '' === (string) $medicao_gtm['ads']['id']
		&& '' === (string) $medicao_gtm['ads']['label']
		&& '' === (string) $medicao_gtm['linkedin']['partnerId']
		&& '' === (string) $medicao_gtm['linkedin']['conversionId'],
	'piso do disparo em dobro: no caminho do container os IDs diretos ainda chegam ao navegador — enquanto chegarem, uma linha esquecida no cliente conta a mesma conversão duas vezes, e conversão em dobro reescreve o lance do leilão'
);

/* PISO da forma: ID fora da forma é PRESERVADO e AVISADO, nunca apagado. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'ABCDEF1234', F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	'ABCDEF1234' === (string) F3Base_Options::ler( 'f3base_ga4_measurement_id' ),
	'piso da forma: o measurement ID fora da forma foi APAGADO pela sanitização — apagar em silêncio é o que esta release parou de fazer'
);

$avisos_de_forma = ( new F3Base_Modulo_Tracking() )->avisos();

afirmar(
	$nome,
	array() !== $avisos_de_forma && str_contains( (string) $avisos_de_forma[0]['motivo'], 'G-XXXXXXXXXX' ),
	'piso da forma: o ID fora da forma passou calado — a tag carrega, a conta não recebe nada, e não há erro no console para procurar'
);

/* ==========================================================================
 * tracking.consentimento_gateia_tudo
 * ======================================================================= */

$nome = 'tracking.consentimento_gateia_tudo';

bancada_limpa();

F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-ABCDEF1234', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_linkedin_partner_id', '1234567', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_linkedin_conversion_id', '7654321', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'negado' ), F3Base_Options::ORIGEM_MANUAL );

/* PISO: a bancada reproduz a negativa? Sem ela, o ramo do portão não é medido. */
afirmar(
	$nome,
	! F3Base_Modulo_Consentimento::permite_tags(),
	'piso: a bancada não reproduz a negativa de consentimento, e sem ela o teto abaixo aprovaria por acaso'
);

( new F3Base_Modulo_Tracking() )->enfileirar();

afirmar(
	$nome,
	array() === $GLOBALS['f3b_bench']['scripts'],
	'piso do portão: com o consentimento negado alguma tag foi enfileirada — Pixel e Insight Tag não têm modo de consentimento, e para eles negativa é AUSÊNCIA, não "atualizado para negado"'
);

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === ( new F3Base_Modulo_Tracking() )->estado()['estado'],
	'piso do portão: o módulo não conta que a negativa desligou as quatro tags'
);

/* TETO: com consentimento, as quatro saem por UM carregador só. */
F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'pre-aprovado' ), F3Base_Options::ORIGEM_MANUAL );
$GLOBALS['f3b_bench']['scripts'] = array();

( new F3Base_Modulo_Tracking() )->enfileirar();

$scripts_do_tracking = $GLOBALS['f3b_bench']['scripts'];

afirmar(
	$nome,
	isset( $scripts_do_tracking[ F3Base_Modulo_Tracking::HANDLE ] ),
	'teto: com consentimento vigente e IDs gravados, nenhuma tag foi enfileirada'
);

afirmar(
	$nome,
	1 === count( $scripts_do_tracking ),
	'piso do portão único: mais de um carregador foi enfileirado — quatro tags atrás de quatro portões é a garantia de que um deles vai ficar para trás'
);

$dados_no_navegador = $scripts_do_tracking[ F3Base_Modulo_Tracking::HANDLE ]['dados']['f3baseTrackingDados'] ?? array();

afirmar(
	$nome,
	in_array( F3Base_Modulo_Consentimento::HANDLE, $scripts_do_tracking[ F3Base_Modulo_Tracking::HANDLE ]['deps'], true ),
	'teto: o carregador das tags não depende do script de consentimento — sem essa ordem, a tag decide antes de o Consent Mode ter default'
);

afirmar(
	$nome,
	'G-ABCDEF1234' === (string) ( $dados_no_navegador['ga4'] ?? '' )
		&& '123456789012345' === (string) ( $dados_no_navegador['meta']['pixelId'] ?? '' )
		&& '1234567' === (string) ( $dados_no_navegador['linkedin']['partnerId'] ?? '' )
		&& '7654321' === (string) ( $dados_no_navegador['linkedin']['conversionId'] ?? '' ),
	'teto: um dos quatro canais não chegou ao carregador único'
);

/* ==========================================================================
 * leads.click_ids_no_schema
 *
 * O DEFEITO QUE ISTO IMPEDE: o schema do endpoint é FECHADO e recusa campo
 * desconhecido com 400 nomeando a chave. Acrescentar `gclid` só no cliente faria
 * TODO lead de tráfego pago voltar recusado — o pior modo de falhar que este
 * endpoint tem, porque falha exatamente no tráfego que foi pago.
 * ======================================================================= */

$nome = 'leads.click_ids_no_schema';

bancada_limpa();

$aceitos_na_atribuicao = F3Base_Modulo_Endpoint_Leads::campos_atribuicao();

foreach ( array( 'gclid', 'gbraid', 'wbraid', 'msclkid', 'fbclid', 'fbc', 'fbp', 'li_fat_id' ) as $chave_de_clique ) {
	afirmar(
		$nome,
		isset( $aceitos_na_atribuicao[ $chave_de_clique ] ),
		'teto do schema: ' . $chave_de_clique . ' não está no conjunto aceito de atribuicao, e o cliente que o enviar receberá 400 com o nome da chave'
	);
}

$resposta = postar(
	carga(
		array(
			'atribuicao' => array(
				'gclid'     => 'CjwKCAjw-bancada-de-teste',
				'fbclid'    => 'IwAR0bancadaDeTeste',
				'li_fat_id' => '4f8b1c2d-bancada',
				'msclkid'   => 'bancada0msclkid',
			),
		)
	)
);

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: lead com identificador de clique foi recusado com status ' . $resposta->status . ' e código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — é o lead de tráfego pago voltando 400 por causa do campo que o próprio pacote passou a enviar'
);

$atribuicao_gravada = (string) ( $GLOBALS['f3b_bench']['ultimo_post']['meta_input']['_f3base_atribuicao'] ?? '' );

afirmar(
	$nome,
	str_contains( $atribuicao_gravada, 'CjwKCAjw-bancada-de-teste' ) && str_contains( $atribuicao_gravada, 'IwAR0bancadaDeTeste' ),
	'teto da gravação: o identificador de clique foi aceito e não chegou ao registro do lead — aceitar sem gravar é perder a campanha que comprou o lead'
);

/* PISO: o conjunto continua FECHADO. Campo de fora segue recusado pelo nome. */
bancada_limpa();
$resposta = postar( carga( array( 'atribuicao' => array( 'ttclid' => 'de-outra-plataforma' ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'atribuicao.ttclid' === (string) ( $resposta->data['campo'] ?? '' ),
	'piso: chave fora do conjunto passou, ou a recusa não nomeou a chave — acrescentar campos não pode ter aberto o schema'
);

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
