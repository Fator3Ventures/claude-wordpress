/**
 * Cliente da tela orquestradora.
 *
 * Mora em arquivo próprio, nunca em heredoc PHP: JavaScript dentro de string não
 * é lintado nem executado por teste algum, e a versão anterior deste arquivo —
 * quando vivia num `<<<'JS'` — rendeu três defeitos em três releases:
 *
 * 1. `r.json()` engolindo o corpo da resposta. Aqui a resposta é lida como
 *    TEXTO e só então convertida: quando a conversão falha, o corpo ainda
 *    existe para o diagnóstico.
 * 2. `var i` sombreando o parâmetro e virando "Etapa NaN de 19". Aqui não há
 *    `var`: cada laço declara o próprio `const`/`let`, e o número da etapa vem
 *    do parâmetro, não de uma variável de escopo externo.
 * 3. O diagnóstico reescrevendo a mensagem recuperada. Aqui a mensagem do
 *    servidor é impressa como veio, e o diagnóstico do cliente entra numa
 *    linha separada.
 *
 * A resposta real de um erro fatal é "HTML + JSON": a página de erro do
 * WordPress já foi enviada quando o `shutdown` roda. Por isso o JSON é
 * procurado no FIM do corpo — pela sentinela, e, na falta dela, varrendo de
 * trás para frente pelo último objeto que analisa.
 *
 * Corpo ilegível não é um caso só, e tratar os três como um só custou uma
 * unidade inteira em produção. O discriminante é impresso, sempre:
 *
 * - sentinela de INÍCIO ausente + marcador de wp-admin (`wpwrap`, `wpOnload`):
 *   a requisição nunca chegou ao nosso handler — um plugin de terceiro
 *   redirecionou em `admin_init`, que roda antes do `admin_post_*`. É o único
 *   caso em que o cliente repete a MESMA unidade, uma vez.
 * - sentinela de início presente e nenhum JSON no fim: erro fatal no meio do
 *   lote. A unidade não fechou, e sai marcada como NÃO executada.
 * - nem uma nem outro: resposta de rede ou de proxy, que nunca passou pelo
 *   WordPress.
 *
 * Em todos os casos ilegíveis a unidade fica marcada como não executada — nunca
 * se avança para a próxima, porque a unidade pulada não roda mais.
 *
 * QUATRO REGRAS NASCIDAS DA 1.0.16, todas de uma execução só. O operador rodou,
 * deu erro, rodou de novo, e a tela entrou em laço: 163 linhas idênticas de
 * "execução concorrente rejeitada", com a idade do heartbeat subindo de 38 até
 * 90 segundos, um `Etapa 94 de 40` na barra, `estado da aplicação:` vazio no
 * rodapé, e um encerramento dizendo "163 BLOCKED" ao lado de "BLOCKED: nenhum".
 *
 * 1. **Rejeição de lock PARA a tela na primeira ocorrência.** A regra "BLOCKED
 *    não para mais a execução inteira" é correta para UNIDADE que mediu
 *    pré-condição ausente. A rejeição de lock não é resultado de unidade
 *    nenhuma: o lote não rodou, nada foi medido, não há o que continuar. Sai
 *    UMA linha com dono, idade do heartbeat, TTL e o HORÁRIO em que o lock
 *    passa a ser considerado abandonado — a única pergunta do operador é
 *    quanto esperar.
 * 2. **O avanço é decidido, nunca presumido.** `proximoLote()` só manda seguir
 *    quando a resposta é sobre a unidade que este pedido enviou e não se
 *    declara terminal; `dentroDoPlano()` recusa índice que o plano não tem. O
 *    contador contava requisições, e por isso ultrapassava o próprio total.
 * 3. **Todo caminho terminal fecha pelo MESMO produtor de rodapé**, e o estado
 *    da aplicação sai da lista que o servidor declara. Vazio não é estado
 *    fechado.
 * 4. **Linha que não fecha OK é NOMEADA também aqui.** `nomeDaLinha()` dá nome
 *    de reserva à linha que o servidor mandou sem rótulo: contagem e lista do
 *    mesmo escopo não podem se contradizer.
 */

( function () {
	'use strict';

	const raiz = document.getElementById( 'f3base-imp' );

	if ( ! raiz ) {
		return;
	}

	const endpoint = raiz.getAttribute( 'data-endpoint' ) || '';
	const nonce = raiz.getAttribute( 'data-nonce' ) || '';
	const modo = raiz.getAttribute( 'data-modo' ) || 'simulacao';
	const execucao = raiz.getAttribute( 'data-execucao' ) || '';
	const total = parseInt( raiz.getAttribute( 'data-total' ) || '0', 10 );
	const sentinela = raiz.getAttribute( 'data-sentinela' ) || '';
	const sentinelaInicio = raiz.getAttribute( 'data-sentinela-inicio' ) || '';
	const rotuloEtapa = raiz.getAttribute( 'data-rotulo-etapa' ) || 'Etapa %1$d de %2$d';
	const rotuloErro = raiz.getAttribute( 'data-rotulo-erro' ) || 'Resposta não interpretável do servidor.';
	const rotuloDownload = raiz.getAttribute( 'data-rotulo-download' ) || 'Baixar o log desta execução';
	const rotuloFim = raiz.getAttribute( 'data-rotulo-fim' ) || 'Execução concluída.';
	const rotuloSequestro = raiz.getAttribute( 'data-rotulo-sequestro' ) || 'A requisição foi redirecionada por um plugin de terceiro antes de chegar ao implantador.';
	const rotuloFatal = raiz.getAttribute( 'data-rotulo-fatal' ) || 'A requisição chegou ao implantador e o lote morreu no meio: erro fatal antes do JSON final.';
	const rotuloRede = raiz.getAttribute( 'data-rotulo-rede' ) || 'A resposta não veio do implantador nem do wp-admin: resposta de rede ou de proxy.';
	const rotuloNaoExecutada = raiz.getAttribute( 'data-rotulo-nao-executada' ) || 'Esta unidade NÃO foi executada e não tem checkpoint: a retomada começa por ela.';
	const rotuloRepetindo = raiz.getAttribute( 'data-rotulo-repetindo' ) || 'Repetindo a MESMA unidade uma vez.';
	const rotuloUltimoPlugin = raiz.getAttribute( 'data-rotulo-ultimo-plugin' ) || 'Último plugin ativado antes desta requisição: %1$s.';
	const rotuloSemPlugin = raiz.getAttribute( 'data-rotulo-sem-plugin' ) || 'nenhum plugin foi ativado nesta execução';
	const rotuloCadeia = raiz.getAttribute( 'data-rotulo-cadeia' ) || 'BLOCKED registrado. A execução segue nas unidades independentes; só o fecho declarado desta é suspenso.';
	const rotuloSupressaoSugerida = raiz.getAttribute( 'data-rotulo-supressao-sugerida' ) || 'A repetição funcionou e a execução seguiu. Uma entrada em plugins.supressao_onboarding para o slug %1$s evitaria esta ida e volta.';
	const rotuloEscopos = raiz.getAttribute( 'data-rotulo-escopos' ) || 'Contagens por escopo, cada número dizendo o que conta — checagens do relatório: %1$s FALHA, %2$s BLOCKED · unidades do plano: %3$s FALHA, %4$s BLOCKED · linhas renderizadas nesta tela: %5$s FALHA, %6$s BLOCKED.';
	const rotuloNomes = raiz.getAttribute( 'data-rotulo-nomes' ) || 'Nomes do que NÃO fechou OK, por estado — checagens do relatório: %1$s · unidades do plano: %2$s · linhas desta tela: %3$s.';
	const rotuloResumidas = raiz.getAttribute( 'data-rotulo-resumidas' ) || 'Checagens OK dentro de unidades, resumidas por desenho: %1$s.';
	const rotuloNenhum = raiz.getAttribute( 'data-rotulo-nenhum' ) || 'nenhum';
	const marcaInterna = raiz.getAttribute( 'data-marca-interna' ) || '\u21b3 ';
	const rotuloLock = raiz.getAttribute( 'data-rotulo-lock' ) || 'Execução concorrente: o lock pertence a %1$s, com heartbeat há %2$s segundos (TTL %3$ss). Este lote NÃO rodou e nada foi medido. O lock passa a ser considerado abandonado às %4$s: a partir daí, executar de novo assume o lock automaticamente. A tela PARA aqui — repetir antes disso só produz a mesma linha.';
	const rotuloSemNome = raiz.getAttribute( 'data-rotulo-sem-nome' ) || 'lote.linha_sem_nome';
	const rotuloPlanoParado = raiz.getAttribute( 'data-rotulo-plano-parado' ) || 'A resposta NÃO avançou o plano: o servidor respondeu sobre o lote %1$s enquanto o pedido era o lote %2$s. A tela para aqui, porque avançar o contador sobre resposta que não avançou o plano é contar outra coisa.';
	const rotuloForaDoPlano = raiz.getAttribute( 'data-rotulo-fora-do-plano' ) || 'Pedido de lote fora do plano: índice %1$s com %2$s unidade(s) declarada(s). Nenhuma requisição foi enviada.';
	const rotuloAplicacao = raiz.getAttribute( 'data-rotulo-aplicacao' ) || 'estado da aplicação';
	const rotuloEncerrada = raiz.getAttribute( 'data-rotulo-encerrada' ) || 'Execução encerrada sem concluir o plano.';
	const rotuloRegiaoFinal = raiz.getAttribute( 'data-rotulo-regiao-final' ) || 'Resultado final da execução';
	const rotuloOndeEstaOResumo = raiz.getAttribute( 'data-rotulo-onde-esta-o-resumo' ) || 'O resultado completo está no fim desta página, depois do log.';

	/*
	 * Estados de aplicação ACEITOS, declarados pelo servidor. Lista aqui dentro
	 * seria a segunda fonte para o mesmo fato; o fecho de reserva é BLOCKED,
	 * porque execução que não chegou a rodar fecha em pré-condição ausente.
	 */
	const estadosAplicacao = ( raiz.getAttribute( 'data-estados-aplicacao' ) || 'BLOCKED' ).split( ',' );
	const fechoReserva = raiz.getAttribute( 'data-fecho-reserva' ) || 'BLOCKED';

	/*
	 * Índices já repetidos por sequestro: a repetição é UMA, nunca um laço.
	 * O valor guardado é o NOME do plugin ativado antes do sequestro, capturado
	 * no momento em que ele aconteceu: cada lote é uma requisição própria, o
	 * servidor não carrega esse nome de uma requisição para a outra, e ler o
	 * campo `ativado` da resposta da repetição devolveria vazio.
	 */
	const sequestrosRepetidos = {};

	/* Último plugin que o servidor disse ter ativado, para nomear o sequestro. */
	let ultimoPluginAtivado = '';

	/* Contagem corrida de BLOCKED e de suspensões por dependência declarada. */
	let bloqueadas = 0;
	let suspensas = 0;

	/*
	 * TERCEIRO ESCOPO: as linhas RENDERIZADAS nesta tela. Ele não é o do
	 * servidor: aqui sai uma linha por unidade, mais as linhas que o próprio
	 * cliente registra (sequestro, fatal, rede, checkpoint). O relatório do
	 * servidor conta as checagens, que incluem as que rodam DENTRO de uma
	 * unidade — foi a mesma palavra sobre três escopos que produziu `FALHA: 7`
	 * no cabeçalho, `5 FALHA` no encerramento e 2 linhas visíveis com FALHA.
	 *
	 * O contador mora DENTRO de `registrar()`, que é a única função que desenha
	 * linha: contador por fora, um dia, deixa de descrever o que está na tela.
	 */
	const renderizadas = {};

	/*
	 * E OS NOMES, no mesmo lugar e pela mesma função. Contagem sem nome não
	 * responde à pergunta do operador: ele não quer saber quantas fecharam
	 * FALHA, quer saber QUAIS. Os dois são escritos dentro de `registrar()`, que
	 * é a única função que desenha linha — separar contador de nomeador é abrir
	 * a porta para o número existir sem a lista.
	 */
	const nomesRenderizados = {};

	/* Checagens OK que rodaram dentro de unidades e saem resumidas, por desenho. */
	let resumidas = 0;

	const progresso = document.createElement( 'p' );
	progresso.className = 'f3base-imp-progresso';
	progresso.setAttribute( 'role', 'status' );
	progresso.setAttribute( 'aria-live', 'polite' );

	const tabela = document.createElement( 'table' );
	tabela.className = 'f3base-imp-log';

	const cabecalho = document.createElement( 'thead' );
	cabecalho.innerHTML = '';

	const linhaCabecalho = document.createElement( 'tr' );

	[ 'Estado', 'Etapa', 'Checagem', 'Mensagem' ].forEach( function ( titulo ) {
		const celula = document.createElement( 'th' );
		celula.scope = 'col';
		celula.textContent = titulo;
		linhaCabecalho.appendChild( celula );
	} );

	cabecalho.appendChild( linhaCabecalho );
	tabela.appendChild( cabecalho );

	const corpo = document.createElement( 'tbody' );
	tabela.appendChild( corpo );

	/*
	 * ENCERRAMENTO É CONCLUSÃO, E CONCLUSÃO VEM DEPOIS. Até a 1.0.18 o resumo
	 * inteiro — contagens por escopo, listas de nomes por estado, estado da
	 * aplicação — era escrito DENTRO de `progresso`, que é o primeiro filho da
	 * raiz. O resultado aparecia ANTES do log e empurrava a tabela para baixo:
	 * quem terminava a execução lia a conclusão de costas para as linhas que a
	 * produziram.
	 *
	 * São duas coisas, e agora são dois nós. `progresso` é STATUS AO VIVO e
	 * continua no topo — é para isso que `aria-live` existe. `encerramento` é
	 * CONCLUSÃO e mora no fim, depois da tabela.
	 *
	 * A acessibilidade não sai perdendo com a mudança de lugar, e é por isso que
	 * mover o nó não bastava: a região é `role="region"` com nome acessível, o
	 * que a torna alcançável pela navegação por regiões; recebe `tabindex="-1"`
	 * e o FOCO no instante em que é escrita, o que a anuncia e leva o teclado
	 * até ela; e a linha curta que fica no topo diz onde a conclusão está.
	 */
	const encerramento = document.createElement( 'section' );
	encerramento.className = 'f3base-imp-encerramento';
	encerramento.setAttribute( 'role', 'region' );
	encerramento.setAttribute( 'aria-label', rotuloRegiaoFinal );
	encerramento.setAttribute( 'tabindex', '-1' );
	encerramento.hidden = true;

	const rodape = document.createElement( 'p' );
	rodape.className = 'f3base-imp-acoes';

	raiz.appendChild( progresso );
	raiz.appendChild( tabela );
	raiz.appendChild( encerramento );
	raiz.appendChild( rodape );

	/**
	 * Substitui os marcadores posicionais do rótulo traduzido.
	 *
	 * @param {string} modelo Rótulo com %1$d e %2$d.
	 * @param {number} atual  Índice humano da etapa.
	 * @param {number} quantas Total de etapas.
	 * @return {string} Rótulo montado.
	 */
	function formatar( modelo, atual, quantas ) {
		return String( modelo )
			.replace( '%1$d', String( atual ) )
			.replace( '%2$d', String( quantas ) );
	}

	/**
	 * Substitui %1$s..%N$s por uma lista de valores, na ordem.
	 *
	 * @param {string} modelo  Rótulo com marcadores posicionais.
	 * @param {Array}  valores Valores, na ordem dos marcadores.
	 * @return {string} Rótulo montado.
	 */
	function formatarLista( modelo, valores ) {
		let saida = String( modelo );

		for ( let indice = 0; indice < valores.length; indice++ ) {
			saida = saida.replace( '%' + String( indice + 1 ) + '$s', String( valores[ indice ] ) );
		}

		return saida;
	}

	/**
	 * Tenta analisar um trecho como JSON.
	 *
	 * @param {string} trecho Texto candidato.
	 * @return {Object|null} Objeto analisado, ou null.
	 */
	function tentarAnalisar( trecho ) {
		if ( ! trecho ) {
			return null;
		}

		try {
			const analisado = JSON.parse( trecho );

			return ( analisado && typeof analisado === 'object' ) ? analisado : null;
		} catch ( erro ) {
			return null;
		}
	}

	/**
	 * Procura o objeto JSON no FIM do corpo.
	 *
	 * @param {string} texto Corpo completo da resposta, como texto.
	 * @return {Object|null} Objeto encontrado, ou null.
	 */
	function extrairJson( texto ) {
		if ( sentinela ) {
			const posicao = texto.lastIndexOf( sentinela );

			if ( posicao !== -1 ) {
				const cauda = tentarAnalisar( texto.slice( posicao + sentinela.length ).trim() );

				if ( cauda ) {
					return cauda;
				}
			}
		}

		let inicio = texto.lastIndexOf( '{' );

		while ( inicio !== -1 ) {
			const candidato = tentarAnalisar( texto.slice( inicio ).trim() );

			if ( candidato ) {
				return candidato;
			}

			inicio = texto.lastIndexOf( '{', inicio - 1 );
		}

		return null;
	}

	/**
	 * Classifica um corpo do qual não se extraiu JSON.
	 *
	 * Três respostas distintas que se pareciam entre si até existir a sentinela
	 * de início. O nome do caso vai para o log — o operador precisa saber se
	 * perdeu a unidade por causa de um terceiro, de um fatal ou da rede.
	 *
	 * @param {string} texto Corpo completo da resposta.
	 * @return {{tipo: string, checagem: string, mensagem: string}} Diagnóstico.
	 */
	function classificarIlegivel( texto ) {
		const temInicio = sentinelaInicio !== '' && texto.indexOf( sentinelaInicio ) !== -1;
		const temMarcadorAdmin = texto.indexOf( 'wpwrap' ) !== -1 || texto.indexOf( 'wpOnload' ) !== -1;

		if ( ! temInicio && temMarcadorAdmin ) {
			return {
				tipo: 'sequestro_por_terceiro',
				checagem: 'lote.sequestro_por_terceiro',
				mensagem: rotuloSequestro +
					' Discriminante: sentinela de início AUSENTE e marcador de wp-admin PRESENTE — a requisição não chegou ao handler do implantador.'
			};
		}

		if ( temInicio ) {
			return {
				tipo: 'erro_fatal_no_lote',
				checagem: 'lote.resposta_ilegivel',
				mensagem: rotuloFatal +
					' Discriminante: sentinela de início PRESENTE e JSON final AUSENTE.'
			};
		}

		return {
			tipo: 'resposta_de_rede',
			checagem: 'lote.resposta_ilegivel',
			mensagem: rotuloRede +
				' Discriminante: sentinela de início AUSENTE e nenhum marcador de wp-admin.'
		};
	}

	/**
	 * Substitui `%1$s` pelo valor informado.
	 *
	 * @param {string} modelo Rótulo traduzido.
	 * @param {string} valor  Valor a inserir.
	 * @return {string} Rótulo montado.
	 */
	function preencher( modelo, valor ) {
		return String( modelo ).replace( '%1$s', String( valor ) );
	}

	/**
	 * NOME de uma linha renderizada. Estado que não fecha OK nunca sai anônimo.
	 *
	 * O DEFEITO MEDIDO, e ele é da regra de contagem-com-nomes furando no escopo
	 * do cliente: a rejeição de lock voltava sem `rotulo`, `registrar()` só
	 * empilhava o nome quando ele era não vazio, e o rodapé imprimia
	 * "linhas desta tela: 163 BLOCKED" ao lado de "BLOCKED: nenhum" — o mesmo
	 * escopo se contradizendo em duas frases seguidas. Contagem e lista saem da
	 * MESMA função e nunca podem divergir: linha sem nome recebe o nome de
	 * reserva declarado, e o operador fica com algo para procurar.
	 *
	 * Estado OK continua podendo sair sem nome próprio: OK sai resumido por
	 * desenho. O que não pode existir é estado RUIM invisível.
	 *
	 * @param {string} estado   Estado fechado.
	 * @param {string} checagem Nome que veio do servidor.
	 * @param {string} reserva  Nome declarado de reserva.
	 * @return {string} Nome a registrar.
	 */
	function nomeDaLinha( estado, checagem, reserva ) {
		const nome = String( checagem === undefined || checagem === null ? '' : checagem ).trim();

		if ( nome !== '' ) {
			return nome;
		}

		return String( estado ) === 'OK' ? '' : String( reserva );
	}

	/**
	 * Índice pedido cabe no plano declarado?
	 *
	 * @param {number} indice Índice a enviar.
	 * @param {number} total  Total de unidades declarado pelo servidor.
	 * @return {boolean}
	 */
	function dentroDoPlano( indice, total ) {
		return Number.isInteger( indice ) && Number.isInteger( total ) && indice >= 0 && indice < total;
	}

	/**
	 * A resposta AVANÇOU o plano?
	 *
	 * A pergunta que a 1.0.15 não fazia. Ela avançava o contador em qualquer
	 * resposta legível, inclusive nas que dizem que o lote NÃO rodou — e a
	 * rejeição de lock é exatamente isso: não é resultado de unidade nenhuma,
	 * nada foi medido, e não há o que continuar. O contador subiu além do
	 * próprio total (`Etapa 94 de 40`) porque estava contando requisições, não
	 * unidades do plano.
	 *
	 * Avança só quando a resposta é sobre a unidade que ESTE pedido enviou e
	 * não se declara terminal.
	 *
	 * @param {Object} carga  Resposta do lote.
	 * @param {number} indice Índice enviado.
	 * @return {boolean}
	 */
	function planoAvancou( carga, indice ) {
		if ( ! carga || typeof carga !== 'object' ) {
			return false;
		}

		if ( carga.parou === true || carga.concluido === true ) {
			return false;
		}

		return typeof carga.lote === 'number' && carga.lote === indice;
	}

	/**
	 * Decisão de avanço do fio: enviar o próximo lote, ou parar e por quê.
	 *
	 * @param {Object} carga  Resposta do lote.
	 * @param {number} indice Índice enviado.
	 * @param {number} total  Total de unidades.
	 * @return {{enviar: boolean, indice: number, parada: string}}
	 */
	function proximoLote( carga, indice, total ) {
		if ( ! planoAvancou( carga, indice ) ) {
			return { enviar: false, indice: indice, parada: 'plano-nao-avancou' };
		}

		if ( ! dentroDoPlano( indice + 1, total ) ) {
			return { enviar: false, indice: indice + 1, parada: 'fora-do-plano' };
		}

		return { enviar: true, indice: indice + 1, parada: '' };
	}

	/**
	 * REJEIÇÃO DE LOCK: os fatos, quando a resposta os traz.
	 *
	 * O servidor manda dono, idade do heartbeat, TTL e o horário exato em que o
	 * lock passa a ser considerado abandonado. O cliente não calcula nada disso
	 * — relógio de navegador e relógio do site não são o mesmo relógio.
	 *
	 * @param {Object} carga Resposta do lote.
	 * @return {Object|null} Fatos do lock, ou null.
	 */
	function rejeicaoDeLock( carga ) {
		if ( ! carga || typeof carga !== 'object' || ! carga.lock || typeof carga.lock !== 'object' ) {
			return null;
		}

		return {
			dono: String( carga.lock.dono === undefined || carga.lock.dono === null ? '' : carga.lock.dono ),
			idade: String( carga.lock.idade === undefined || carga.lock.idade === null ? '' : carga.lock.idade ),
			ttl: String( carga.lock.ttl === undefined || carga.lock.ttl === null ? '' : carga.lock.ttl ),
			abandonadoAs: String( carga.lock.abandonado_as === undefined || carga.lock.abandonado_as === null ? '' : carga.lock.abandonado_as )
		};
	}

	/**
	 * ESTADO FECHADO com que a tela encerra. Vazio nunca.
	 *
	 * O rodapé imprimia `estado da aplicação:` e mais nada quando a resposta não
	 * trazia a chave — e vazio não é estado fechado. A lista de estados aceitos
	 * vem do SERVIDOR (`data-estados-aplicacao`), para não haver uma segunda
	 * lista aqui; valor ausente ou fora dela cai no fecho de reserva, que é
	 * BLOCKED: execução que não chegou a rodar fecha em pré-condição ausente.
	 *
	 * @param {Object} carga    Resposta do lote.
	 * @param {Array}  fechados Estados aceitos, declarados pelo servidor.
	 * @param {string} reserva  Fecho de reserva.
	 * @return {string} Estado fechado.
	 */
	function fechoDaAplicacao( carga, fechados, reserva ) {
		const lista = Array.isArray( fechados ) ? fechados : [];
		const valor = ( carga && typeof carga === 'object' && carga.aplicacao !== undefined && carga.aplicacao !== null )
			? String( carga.aplicacao ).trim()
			: '';

		if ( valor !== '' && lista.indexOf( valor ) !== -1 ) {
			return valor;
		}

		return String( reserva );
	}

	/**
	 * Acrescenta uma linha ao log renderizado.
	 *
	 * @param {string}  estado   Estado fechado.
	 * @param {string}  etapa    Nome da etapa.
	 * @param {string}  checagem Nome da checagem.
	 * @param {string}  mensagem Mensagem, impressa como veio do servidor.
	 * @param {boolean} interna  A linha é uma checagem que rodou DENTRO de uma unidade.
	 * @return {void}
	 */
	function registrar( estado, etapa, checagem, mensagem, interna ) {
		/* O CONTADOR DO ESCOPO DA TELA MORA AQUI DENTRO. Nunca no chamador. */
		const chave = String( estado );
		renderizadas[ chave ] = ( renderizadas[ chave ] || 0 ) + 1;

		/* E O NOME TAMBÉM: contagem e lista saem juntas, sempre. */
		if ( ! nomesRenderizados[ chave ] ) {
			nomesRenderizados[ chave ] = [];
		}

		const nome = nomeDaLinha( estado, checagem, rotuloSemNome );

		if ( nome !== '' && nomesRenderizados[ chave ].indexOf( nome ) === -1 ) {
			nomesRenderizados[ chave ].push( nome );
		}

		const linha = document.createElement( 'tr' );

		linha.className = 'f3base-estado-' + String( estado ).replace( /[^A-Za-z0-9_-]/g, '-' ) +
			( interna === true ? ' f3base-imp-interna' : '' );

		[ estado, etapa, ( interna === true ? marcaInterna + nome : nome ), mensagem ].forEach( function ( valor ) {
			const celula = document.createElement( 'td' );
			celula.textContent = String( valor === undefined || valor === null ? '' : valor );
			linha.appendChild( celula );
		} );

		corpo.appendChild( linha );
	}

	/**
	 * Agrupa nomes por estado, para a lista que acompanha toda contagem.
	 *
	 * Estado OK fica de fora: checagem OK dentro de unidade OK sai resumida, por
	 * desenho. O que não pode existir é estado RUIM invisível.
	 *
	 * O rótulo do vazio entra por PARÂMETRO: sem isso esta função dependeria de
	 * uma constante de escopo externo e deixaria de ser extraível pela sonda —
	 * e o que a sonda não consegue extrair ela mede numa cópia, que é medir
	 * outra coisa.
	 *
	 * @param {Object} mapa  Estado => lista de nomes.
	 * @param {string} vazio Rótulo do estado sem nome nenhum.
	 * @return {string} `FALHA: a, b | BLOCKED: c | WARN: nenhum`.
	 */
	function nomesPorEstado( mapa, vazio ) {
		const fonte = mapa && typeof mapa === 'object' ? mapa : {};
		const partes = [];

		[ 'FALHA', 'BLOCKED', 'WARN', 'WAIVED', 'N/A' ].forEach( function ( estado ) {
			const lista = Array.isArray( fonte[ estado ] ) ? fonte[ estado ] : [];

			partes.push( estado + ': ' + ( lista.length === 0 ? String( vazio ) : lista.join( ', ' ) ) );
		} );

		return partes.join( ' | ' );
	}

	/**
	 * Desenha, indentadas sob a unidade, as checagens que rodaram DENTRO dela.
	 *
	 * A correção desta release: existiam checagens em FALHA dentro de unidades
	 * que fechavam OK, e elas não tinham linha nenhuma na tela. O operador via o
	 * número no cabeçalho e nenhum nome.
	 *
	 * @param {Object} carga Resposta do lote.
	 * @return {void}
	 */
	function registrarInternas( carga ) {
		resumidas += parseInt( carga.checagens_resumidas || 0, 10 ) || 0;

		if ( ! Array.isArray( carga.checagens ) ) {
			return;
		}

		for ( let indice = 0; indice < carga.checagens.length; indice++ ) {
			const checagem = carga.checagens[ indice ] || {};
			const evidencia = String( checagem.evidencia || '' );
			const fase = String( checagem.fase || '' );
			const gate = String( checagem.gate || '' );

			registrar(
				String( checagem.estado || 'FALHA' ),
				String( carga.etapa || '' ),
				String( checagem.nome || '' ),
				String( checagem.mensagem || '' ) +
					'  [evidência: ' + ( evidencia === '' ? '—' : evidencia ) +
					'/' + ( fase === '' ? '—' : fase ) +
					' · gate: ' + ( gate === '' ? '—' : gate ) + ']',
				true
			);
		}
	}

	/**
	 * Monta o texto do log a partir do que está renderizado na tela.
	 *
	 * O download é gerado no navegador porque endpoint do próprio implantador
	 * morre com a autodesativação — oferecer um link do plugin seria oferecer um
	 * link que quebra exatamente no caso de sucesso.
	 *
	 * @return {string} Log em texto.
	 */
	function montarTexto() {
		const linhas = [];

		linhas.push( document.title );
		linhas.push( progresso.textContent || '' );
		linhas.push( '' );

		const todas = corpo.querySelectorAll( 'tr' );

		for ( let indice = 0; indice < todas.length; indice++ ) {
			const celulas = todas[ indice ].querySelectorAll( 'td' );
			const partes = [];

			for ( let coluna = 0; coluna < celulas.length; coluna++ ) {
				partes.push( celulas[ coluna ].textContent || '' );
			}

			linhas.push( partes.join( '\t' ) );
		}

		/*
		 * O RESUMO VAI JUNTO, e no lugar em que ele está na tela: o log baixado
		 * é a mesma leitura, na mesma ordem. Deixá-lo de fora agora que ele saiu
		 * de `progresso` seria a mudança de lugar custando conteúdo ao arquivo.
		 */
		linhas.push( '' );
		linhas.push( encerramento.textContent || '' );

		return linhas.join( '\n' );
	}

	/**
	 * Publica o botão de download construído no navegador.
	 *
	 * @return {void}
	 */
	function publicarDownload() {
		const botao = document.createElement( 'button' );

		botao.type = 'button';
		botao.className = 'button button-primary';
		botao.textContent = rotuloDownload;

		botao.addEventListener( 'click', function () {
			const arquivo = new Blob( [ montarTexto() ], { type: 'text/plain;charset=utf-8' } );
			const url = URL.createObjectURL( arquivo );
			const ancora = document.createElement( 'a' );

			ancora.href = url;
			ancora.download = 'implantacao-' + execucao + '.log.txt';
			document.body.appendChild( ancora );
			ancora.click();
			document.body.removeChild( ancora );

			window.setTimeout( function () {
				URL.revokeObjectURL( url );
			}, 2000 );
		} );

		rodape.appendChild( botao );
	}

	/**
	 * PRODUTOR ÚNICO DO RODAPÉ: toda saída da tela passa por aqui.
	 *
	 * Antes desta release só o caminho de `concluido` escrevia o rodapé, e os
	 * caminhos terminais restantes — resposta ilegível, erro fatal, falha de
	 * rede, rejeição de lock — encerravam a tela sem estado nenhum. Um deles
	 * imprimia `estado da aplicação:` seguido de nada. Vazio não é estado
	 * fechado: aqui o valor sai da lista que o servidor declara, e o que não
	 * estiver nela cai no fecho de reserva.
	 *
	 * @param {Object} carga  Última resposta legível, ou null.
	 * @param {string} motivo Frase que abre o rodapé.
	 * @return {void}
	 */
	function encerrar( carga, motivo ) {
		const fonte = carga && typeof carga === 'object' ? carga : {};
		const fecho = fechoDaAplicacao( fonte, estadosAplicacao, fechoReserva );

		/*
		 * O TOPO FICA COM UMA LINHA CURTA E VERDADEIRA. Ele é status ao vivo, e
		 * status ao vivo não é lugar de conclusão: o resumo inteiro escrito aqui
		 * empurrava o log para baixo e punha o resultado antes das linhas que o
		 * produziram.
		 */
		progresso.textContent = linhaFinalDeProgresso( motivo, fecho, rotuloAplicacao, rotuloOndeEstaOResumo );

		/* E O RESUMO INTEIRO MORA NO FIM, depois da tabela. */
		encerramento.hidden = false;
		encerramento.textContent = resumoDeEncerramento(
			fonte,
			{
				contagens: renderizadas,
				nomes: nomesRenderizados,
				resumidas: resumidas,
				suspensas: suspensas,
				bloqueadas: bloqueadas
			},
			{
				escopos: rotuloEscopos,
				nomes: rotuloNomes,
				resumidas: rotuloResumidas,
				aplicacao: rotuloAplicacao,
				nenhum: rotuloNenhum
			},
			fecho
		);

		/*
		 * ANUNCIADA E ALCANÇÁVEL. Mover o nó sem isto teria trocado um defeito
		 * de leitura por um defeito de acesso: quem navega por teclado ou por
		 * leitor de tela ficaria com a conclusão fora do caminho. O foco no nó
		 * com nome acessível a anuncia e leva o teclado até ela; a linha do topo
		 * continua dizendo, em `aria-live`, que a execução terminou e onde a
		 * conclusão está.
		 */
		encerramento.focus();

		publicarDownload();
	}

	/**
	 * A LINHA CURTA que fica no topo quando a execução termina. FUNÇÃO PURA.
	 *
	 * Curta e verdadeira: o que aconteceu, o estado fechado da aplicação e onde
	 * está o resultado completo. Nenhuma contagem por escopo e nenhuma lista de
	 * nomes — elas moram no encerramento, no fim da página.
	 *
	 * @param {string} motivo   Frase que abre o encerramento.
	 * @param {string} fecho    Estado fechado da aplicação.
	 * @param {string} rotulo   Rótulo traduzido do estado da aplicação.
	 * @param {string} onde     Frase que diz onde está o resultado completo.
	 * @return {string} Linha do topo.
	 */
	function linhaFinalDeProgresso( motivo, fecho, rotulo, onde ) {
		return String( motivo ) + ' ' + String( rotulo ) + ': ' + String( fecho ) + '. ' + String( onde );
	}

	/**
	 * O RESUMO INTEIRO do encerramento, em texto. FUNÇÃO PURA.
	 *
	 * Tudo entra por parâmetro para que a sonda possa exercitá-la extraída do
	 * arquivo REAL: a resposta do servidor, o escopo da tela, os rótulos
	 * traduzidos e o estado fechado já decidido por `fechoDaAplicacao()`.
	 *
	 * CONTAGEM E LISTA SAEM JUNTAS, aqui como em toda saída deste pacote: sem
	 * isso o rodapé dizia "163 BLOCKED" e a lista do MESMO escopo dizia
	 * "BLOCKED: nenhum" — o instrumento se contradizendo em duas frases
	 * seguidas.
	 *
	 * @param {Object} carga   Última resposta legível do servidor, ou {}.
	 * @param {Object} tela    Escopo da tela: contagens, nomes, resumidas, suspensas, bloqueadas.
	 * @param {Object} rotulos Rótulos traduzidos: escopos, nomes, resumidas, aplicacao, nenhum.
	 * @param {string} fecho   Estado fechado da aplicação.
	 * @return {string} Resumo completo.
	 */
	function resumoDeEncerramento( carga, tela, rotulos, fecho ) {
		const fonte = carga && typeof carga === 'object' ? carga : {};
		const escopo = tela && typeof tela === 'object' ? tela : {};
		const marcas = rotulos && typeof rotulos === 'object' ? rotulos : {};
		const renderizadas = escopo.contagens && typeof escopo.contagens === 'object' ? escopo.contagens : {};

		return formatarLista( marcas.escopos, [
			fonte.checagens_falha || 0,
			fonte.checagens_blocked || 0,
			fonte.unidades_falha || 0,
			fonte.unidades_blocked || 0,
			renderizadas.FALHA || 0,
			renderizadas.BLOCKED || 0
		] ) +
			' ' +
			formatarLista( marcas.nomes, [
				nomesPorEstado( fonte.checagens_nomes, marcas.nenhum ),
				nomesPorEstado( fonte.unidades_nomes, marcas.nenhum ),
				nomesPorEstado( escopo.nomes, marcas.nenhum )
			] ) +
			' ' + formatarLista( marcas.resumidas, [ String( escopo.resumidas || 0 ) ] ) +
			' Suspensas por dependência declarada: ' + String( escopo.suspensas || 0 ) +
			' de ' + String( escopo.bloqueadas || 0 ) + ' unidade(s) em BLOCKED nesta tela' +
			' · ' + String( marcas.aplicacao ) + ': ' + String( fecho );
	}

	/**
	 * Publica o botão de retomada idempotente.
	 *
	 * @param {number} indice Índice da unidade a repetir.
	 * @return {void}
	 */
	function publicarRetomada( indice ) {
		const botao = document.createElement( 'button' );

		botao.type = 'button';
		botao.className = 'button';
		botao.textContent = 'Retomar do lote ' + String( indice + 1 );

		botao.addEventListener( 'click', function () {
			rodape.innerHTML = '';
			enviarLote( indice );
		} );

		rodape.appendChild( botao );
	}

	/**
	 * Envia um lote e trata a resposta.
	 *
	 * @param {number} indice Índice da unidade.
	 * @return {void}
	 */
	function enviarLote( indice ) {
		/*
		 * GUARDA DE ÍNDICE, e ela é a razão de o contador não poder mais
		 * ultrapassar o total. `Etapa 94 de 40` na tela era o fio pedindo lotes
		 * que o plano não tem, e imprimindo o número do pedido como se fosse a
		 * unidade. Aqui o pedido fora do plano NÃO sai, sai nomeado no log, e a
		 * tela fecha.
		 */
		if ( ! dentroDoPlano( indice, total ) ) {
			registrar(
				'FALHA',
				'cliente',
				'lote.indice_fora_do_plano',
				formatarLista( rotuloForaDoPlano, [ String( indice ), String( total ) ] )
			);

			encerrar( null, rotuloEncerrada );

			return;
		}

		progresso.textContent = formatar( rotuloEtapa, indice + 1, total );

		const dados = new FormData();

		dados.append( 'action', 'f3base_imp_lote' );
		dados.append( '_wpnonce', nonce );
		dados.append( 'modo', modo );
		dados.append( 'execucao', execucao );
		dados.append( 'lote', String( indice ) );

		let estadoHttp = 0;
		let tipoConteudo = '';

		window.fetch( endpoint, {
			method: 'POST',
			credentials: 'same-origin',
			body: dados
		} ).then( function ( resposta ) {
			estadoHttp = resposta.status;
			tipoConteudo = resposta.headers.get( 'Content-Type' ) || '';

			/* A resposta é lida como TEXTO — sempre. A conversão vem depois. */
			return resposta.text();
		} ).then( function ( texto ) {
			const carga = extrairJson( texto );

			if ( ! carga ) {
				const diagnostico = classificarIlegivel( texto );
				const evidencia = ' HTTP ' + String( estadoHttp ) +
					' · Content-Type: ' + ( tipoConteudo || '(ausente)' ) +
					' · ' + String( texto.length ) + ' bytes de corpo: ' +
					texto.slice( -600 );

				/*
				 * Sequestro é o ÚNICO caso em que a mesma unidade volta ao fio:
				 * ela não rodou, e a supressão gravada na ativação anterior já
				 * tirou o redirecionamento do caminho. Uma vez, nunca em laço.
				 */
				if ( 'sequestro_por_terceiro' === diagnostico.tipo && ! Object.prototype.hasOwnProperty.call( sequestrosRepetidos, indice ) ) {
					sequestrosRepetidos[ indice ] = ultimoPluginAtivado || '';

					registrar(
						'WARN',
						'cliente',
						diagnostico.checagem,
						diagnostico.mensagem + ' ' +
							preencher( rotuloUltimoPlugin, ultimoPluginAtivado || rotuloSemPlugin ) + ' ' +
							rotuloRepetindo + evidencia
					);

					enviarLote( indice );

					return;
				}

				registrar(
					'FALHA',
					'cliente',
					diagnostico.checagem,
					rotuloErro + ' ' + diagnostico.mensagem +
						( 'sequestro_por_terceiro' === diagnostico.tipo
							? ' ' + preencher( rotuloUltimoPlugin, sequestrosRepetidos[ indice ] || ultimoPluginAtivado || rotuloSemPlugin )
							: '' ) +
						evidencia
				);

				/*
				 * A unidade sai marcada como NÃO executada: sem isso o operador
				 * lê uma FALHA e não sabe que o trabalho daquela unidade nunca
				 * aconteceu — e a retomada precisa incluí-la.
				 */
				registrar(
					'WARN',
					'cliente',
					'lote.unidade_nao_executada',
					formatar( rotuloEtapa, indice + 1, total ) + ' — ' + rotuloNaoExecutada
				);

				publicarRetomada( indice );
				encerrar( null, rotuloEncerrada );

				return;
			}

			if ( typeof carga.ativado === 'string' && carga.ativado !== '' ) {
				ultimoPluginAtivado = carga.ativado;
			}

			/*
			 * A repetição da unidade TEVE SUCESSO: a resposta é legível e a
			 * execução segue. Isso é observação, não gate — o relatório nomeia o
			 * plugin que sequestrou a requisição e diz o que evitaria a ida e
			 * volta na próxima vez. A chave de option dele NÃO é inventada aqui:
			 * quem a descobre é o operador, e é ele quem a declara em
			 * plugins.supressao_onboarding para aquele slug.
			 */
			if ( Object.prototype.hasOwnProperty.call( sequestrosRepetidos, indice ) ) {
				registrar(
					'WARN',
					'cliente',
					'lote.sequestro_por_terceiro',
					preencher( rotuloUltimoPlugin, sequestrosRepetidos[ indice ] || rotuloSemPlugin ) + ' ' +
						preencher( rotuloSupressaoSugerida, sequestrosRepetidos[ indice ] || rotuloSemPlugin )
				);

				delete sequestrosRepetidos[ indice ];
			}

			if ( carga.fatal ) {
				registrar(
					'FALHA',
					'servidor',
					'lote.erro_fatal',
					String( carga.fatal.mensagem || '' ) +
						' — ' + String( carga.fatal.arquivo || '' ) +
						':' + String( carga.fatal.linha || 0 )
				);

				if ( carga.limites ) {
					registrar(
						'WARN',
						'servidor',
						'lote.limites_do_php',
						'memory_limit ' + String( carga.limites.memory_limit || '' ) +
							' · max_execution_time ' + String( carga.limites.max_execution_time || '' ) +
							' · pico de memória ' + String( carga.limites.memoria_pico || 0 ) + ' bytes'
					);
				}

				publicarRetomada( indice );
				encerrar( carga, rotuloEncerrada );

				return;
			}

			/*
			 * REJEIÇÃO DE LOCK — E ELA PARA A TELA NA PRIMEIRA OCORRÊNCIA.
			 *
			 * A regra "BLOCKED não para mais a execução inteira", logo abaixo, é
			 * correta para UNIDADE que mediu pré-condição ausente. Esta resposta
			 * não é resultado de unidade nenhuma: o lote não rodou, nada foi
			 * medido, e não há o que continuar. Aplicar a regra do BLOCKED aqui
			 * é o que produziu 163 linhas idênticas em 90 segundos, uma por
			 * requisição, até o TTL do lock vencer.
			 *
			 * Sai UMA linha, com os quatro fatos que respondem à única pergunta
			 * do operador — quanto tempo esperar: quem é o dono, há quanto tempo
			 * é o último heartbeat, o TTL, e o HORÁRIO EXATO em que o lock passa
			 * a ser considerado abandonado.
			 */
			const lock = rejeicaoDeLock( carga );

			if ( lock ) {
				registrar(
					String( carga.estado || 'BLOCKED' ),
					String( carga.etapa || 'lote' ),
					String( carga.rotulo || '' ),
					formatarLista( rotuloLock, [ lock.dono, lock.idade, lock.ttl, lock.abandonadoAs ] )
				);

				bloqueadas += 1;
				encerrar( carga, rotuloEncerrada );

				return;
			}

			registrar(
				String( carga.estado || 'FALHA' ),
				String( carga.etapa || '' ),
				String( carga.rotulo || '' ),
				String( carga.motivo || '' )
			);

			/*
			 * As checagens da unidade saem AQUI, indentadas sob ela, com nome,
			 * motivo e classe/fase de evidência — inclusive quando a unidade
			 * acima fechou OK.
			 */
			registrarInternas( carga );

			if ( carga.checkpoint === false ) {
				registrar(
					'WARN',
					String( carga.etapa || '' ),
					'lote.checkpoint',
					'O checkpoint desta unidade não confirmou na leitura de volta: a retomada pode repetir esta unidade — que é idempotente por desenho.'
				);
			}

			/*
			 * BLOCKED NÃO PARA MAIS A EXECUÇÃO INTEIRA. Quem decide o que fica
			 * sem rodar é o servidor, pelo grafo de dependência declarada: a
			 * unidade suspensa volta com `suspensa: true` e a linha já nomeia
			 * quem a suspendeu. O cliente continua para a unidade seguinte —
			 * parar aqui era o cliente reintroduzindo a cadeia posicional que o
			 * servidor acabou de desfazer, e foi assim que a única linha capaz de
			 * diagnosticar o canal MCP deixou de existir na execução em que o
			 * canal era a dúvida.
			 *
			 * A mesma unidade nunca é reenviada por conta própria: o servidor
			 * registra o bloqueio e a repetição sairia como linha repetida.
			 */
			if ( carga.estado === 'BLOCKED' ) {
				suspensas += carga.suspensa === true ? 1 : 0;
				bloqueadas += 1;
				progresso.textContent = rotuloCadeia;
			}

			/*
			 * O AVANÇO É DECIDIDO, NUNCA PRESUMIDO. `proximoLote()` só manda
			 * seguir quando a resposta é sobre a unidade que ESTE pedido enviou
			 * e não se declara terminal — é a regra que impede o contador de
			 * contar requisições em vez de unidades do plano.
			 */
			const passo = proximoLote( carga, indice, total );

			if ( passo.enviar ) {
				enviarLote( passo.indice );

				return;
			}

			if ( 'plano-nao-avancou' === passo.parada && carga.concluido !== true && carga.parou !== true ) {
				registrar(
					'FALHA',
					'cliente',
					'lote.plano_nao_avancou',
					formatarLista( rotuloPlanoParado, [
						String( carga.lote === undefined || carga.lote === null ? '—' : carga.lote ),
						String( indice )
					] )
				);
			}

			encerrar( carga, carga.concluido === true ? rotuloFim : rotuloEncerrada );
		} ).catch( function ( erro ) {
			registrar(
				'FALHA',
				'cliente',
				'lote.rede',
				'Falha de rede ao pedir o lote ' + String( indice + 1 ) + ': ' + String( erro && erro.message ? erro.message : erro )
			);
			publicarRetomada( indice );
			encerrar( null, rotuloEncerrada );
		} );
	}

	enviarLote( 0 );
}() );
