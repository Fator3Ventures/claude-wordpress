<?php
/**
 * Conteúdo gerenciado: páginas, posts, categorias e mídia.
 *
 * O conteúdo editorial mora em ARQUIVO — `content/pages/<ref>.html` e
 * `content/posts/<slug>.html` — e a configuração aponta para ele. HTML dentro de
 * PHP não abre no editor, não entra em diff legível e não é revisável por quem
 * escreve; arquivo ausente é BLOCKED com o nome do arquivo, nunca uma página
 * publicada com o corpo vazio.
 *
 * Idempotência por duas metas: `_f3base_managed_id` (identidade lógica) e
 * `_f3base_managed_version` (release que aplicou). A meta é a fonte confiável —
 * ela sobrevive à exclusão do plugin; a option `f3base_base_merge` é o caminho
 * rápido, e divergência entre as duas é AVISO no relatório, nunca cura silenciosa.
 *
 * Armadilhas de `wp_insert_post()` tratadas aqui, cada uma com o motivo:
 * desambiguação silenciosa de slug, `post_date` reescrita em toda atualização,
 * `_wp_desired_post_slug` ressuscitando o slug da lixeira e `post_modified`
 * carimbado em gravação que não mudou nada — o `lastmod` uniforme do sitemap
 * depois de um redeploy é assinatura desse último.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Aplicação do conteúdo declarado.
 */
final class F3Base_Imp_Conteudo {

	/**
	 * Meta de identidade lógica do objeto gerenciado.
	 */
	public const META_ID = '_f3base_managed_id';

	/**
	 * Meta da release que aplicou o objeto.
	 */
	public const META_VERSAO = '_f3base_managed_version';

	/**
	 * Meta com a base de merge por campo (hash da última aplicação).
	 */
	public const META_BASE = '_f3base_managed_base';

	/**
	 * Meta que registra como o objeto entrou sob gestão.
	 */
	public const META_ORIGEM = '_f3base_managed_origem';

	/**
	 * Meta com o slug ANTERIOR de um objeto gerenciado que mudou de slug.
	 *
	 * O nome não é escolha nossa: é a meta que o módulo de redirects do
	 * `site-core` lê para servir 301 do endereço velho, tratando `pagename` E
	 * `name` (o núcleo só trata `name`, e só para `post_type = post`). Mudança
	 * de slug de objeto JÁ PUBLICADO é caso de primeira classe — sem esta meta,
	 * toda URL publicada com o slug antigo passa a 404 em silêncio.
	 */
	public const META_SLUG_ANTERIOR = '_f3base_old_slug';

	/**
	 * Option-espelho da base de merge (caminho rápido).
	 *
	 * A MESMA option guarda a base das OPTIONS desde a 1.1.0, sob a seção
	 * reservada `SECAO_OPTIONS`. Uma segunda option de infraestrutura seria uma
	 * segunda estrutura de estado para responder à mesma pergunta — qual foi o
	 * último valor que este pacote aplicou —, com duas chances de divergir e
	 * dois lugares para limpar. O que muda entre as duas seções é o alvo, não o
	 * mecanismo: aqui `ref` de objeto, ali nome de option.
	 */
	public const OPTION_BASE = 'f3base_base_merge';

	/**
	 * Seção RESERVADA da base de merge onde mora a base das options.
	 *
	 * O nome não pode colidir com nenhuma referência lógica de conteúdo, e por
	 * isso ele não é um `ref` possível: `ref` sai de `paginas[].ref`,
	 * `posts[].slug` e `midia[].ref`, e o schema desses campos não admite as
	 * cercas duplas.
	 */
	public const SECAO_OPTIONS = '__options__';

	/**
	 * O que acontece com a BASE de um campo depois da decisão do merge.
	 *
	 * ATÉ A 1.0.19 O RAMO `preservar` MOVIA A BASE PARA O VALOR OBSERVADO, e o
	 * efeito era que a preservação durava UMA execução. Base igual ao observado
	 * é justamente a condição do ramo "ninguém tocou": na execução seguinte a
	 * mesma edição, intocada, passava a ser lida como conteúdo do pacote, e a
	 * primeira mudança do template gravava por cima dela. A proteção existia no
	 * papel e tinha prazo de validade de um deploy.
	 *
	 * A base é, por definição, o último valor que ESTE pacote aplicou. Quem
	 * preserva não aplicou nada, e não mexe nela.
	 */
	public const BASE_DESEJADO   = 'desejado';
	public const BASE_INALTERADA = 'inalterada';

	/**
	 * Decisões declaráveis em `conteudo.exemplo_do_wordpress`.
	 *
	 * `lixeira` é o PADRÃO do template: conteúdo de exemplo INTOCADO do
	 * WordPress vai para a lixeira, que é reversível. `manter` desliga a etapa
	 * inteira. Os dois são símbolos porque o schema declara os dois.
	 */
	public const EXEMPLO_LIXEIRA = 'lixeira';
	public const EXEMPLO_MANTER  = 'manter';

	/**
	 * Ações que a regra do conteúdo de exemplo produz.
	 */
	public const ACAO_EXEMPLO_LIXEIRA = 'lixeira';
	public const ACAO_EXEMPLO_MANTER  = 'manter';

	/**
	 * Papéis do que `wp_install_defaults()` cria e este pacote sabe reconhecer.
	 */
	public const EXEMPLO_PRIMEIRO_POST   = 'primeiro-post';
	public const EXEMPLO_PAGINA_EXEMPLO  = 'pagina-de-exemplo';

	/**
	 * Papel de mídia que NÃO passa pela biblioteca.
	 *
	 * O valor é o mesmo do enum de `midia.*.papel` no schema; a constante existe
	 * para que a comparação seja um símbolo que `estatica.simbolos_resolvem`
	 * confere, e não uma cadeia solta repetida em dois pontos do arquivo.
	 */
	public const PAPEL_INLINE = 'marca_inline';

	/**
	 * Metas que o core usa para ressuscitar estado de lixeira.
	 *
	 * @return string[]
	 */
	public static function metas_de_lixeira(): array {
		return array( '_wp_desired_post_slug', '_wp_trash_meta_status', '_wp_trash_meta_time' );
	}

	/**
	 * Nome da guarda que segura a publicação da política de privacidade.
	 */
	public const GUARDA_CONTROLADOR = 'contato.controlador';

	/**
	 * Abertura do marcador de interpolação de configuração no conteúdo.
	 *
	 * O conteúdo editorial mora em ARQUIVO, e continua morando: o que a
	 * aplicação faz é trocar um marcador NOMEADO pelo valor que só o operador
	 * tem. Escrever a frase em PHP para "montar" a qualificação do controlador
	 * seria conteúdo editorial dentro de código — a primeira regra do contrato.
	 */
	public const MARCA_ABRE = '%f3base:';

	/**
	 * Fecho do marcador de interpolação.
	 */
	public const MARCA_FECHA = '%';

	/**
	 * A ÂNCORA do produtor único do status efetivo de página.
	 *
	 * Mesma construção de `uniao_declarada()`: a lista sai do PRÓPRIO PACOTE, e
	 * `estatica.pagina_status_fonte_unica` a LÊ daqui. Escrevê-la na suíte seria
	 * a segunda fonte para o mesmo fato — precisamente o que a regra existe para
	 * impedir.
	 *
	 * - `funcao`: o único ponto do código que decide o status efetivo de uma
	 *   página gerenciada.
	 * - `caminho`: o caminho de configuração que declara a INTENÇÃO, e que só o
	 *   produtor pode ler.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_de_status_de_pagina(): array {
		return array(
			'funcao'  => 'status_efetivo_de_pagina',
			'caminho' => 'paginas.*.status',
		);
	}

	/**
	 * A ÂNCORA do produtor único da identidade da política de privacidade.
	 *
	 * Lida por `estatica.politica_privacidade_fonte_unica`, do próprio pacote.
	 *
	 * - `funcao`: o único ponto do código que responde QUAL página é a política.
	 * - `papel`: o valor declarado na entrada da página.
	 * - `caminho`: o caminho de configuração que carrega o fato — e a raiz
	 *   `paginas` é a ÚNICA que o produtor tem permissão de ler.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_da_politica_de_privacidade(): array {
		return array(
			'funcao'  => 'ref_da_politica_de_privacidade',
			'papel'   => 'politica-privacidade',
			'caminho' => 'paginas.*.papel',
			'raiz'    => 'paginas',
		);
	}

	/**
	 * A REGRA da identidade da política, PURA: mede-se fora, decide-se aqui.
	 *
	 * @param array<int,array{ref:string,papel:string}> $entradas Entradas de página.
	 * @return string Referência lógica, ou vazio.
	 */
	public static function ref_da_politica_em( array $entradas ): string {
		$papel = (string) ( self::produtor_da_politica_de_privacidade()['papel'] ?? '' );

		foreach ( $entradas as $entrada ) {
			if ( ! is_array( $entrada ) ) {
				continue;
			}

			if ( $papel === trim( (string) ( $entrada['papel'] ?? '' ) ) ) {
				return trim( (string) ( $entrada['ref'] ?? '' ) );
			}
		}

		return '';
	}

	/**
	 * A referência lógica da página que É a política de privacidade.
	 *
	 * O FATO MORA ONDE ELE SE CHAMA PELO PRÓPRIO NOME: na entrada de `paginas`
	 * que descreve a página, com `papel: "politica-privacidade"`. É a mesma
	 * construção que já resolve a página inicial pelo `template: front-page` da
	 * entrada dela — papel estrutural declarado no objeto, nunca literal no
	 * código e nunca pendurado em outra seção.
	 *
	 * O DEFEITO CORRIGIDO NA 1.0.14. Até a 1.0.13 esta identidade era lida de
	 * `seo.llms_selecao.politica_privacidade`. Matar o literal `'privacidade'
	 * === $ref` estava certo; o destino estava errado, e a consequência era
	 * medível: quem desligasse `bots_ia.llms_txt` e limpasse a seleção — operação
	 * legítima, que o nome da chave convida a fazer — parava de gravar
	 * `wp_page_for_privacy_policy` E derrubava `privacidade.controlador_identificado`
	 * em "condição de aplicabilidade falsa". Uma chave de SEO silenciava uma
	 * checagem legal, sem nada acusar. Por isso o detector proíbe este produtor
	 * de ler qualquer caminho fora de `paginas.*`: a proibição é a regra, e o
	 * nome da chave sozinho não segura ninguém.
	 *
	 * @return string Referência lógica, ou vazio quando o projeto não declara.
	 */
	public static function ref_da_politica_de_privacidade(): string {
		$entradas = array();

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			$entradas[] = array(
				'ref'   => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' ),
				'papel' => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.papel', '' ),
			);
		}

		return self::ref_da_politica_em( $entradas );
	}

	/**
	 * Esta entrada de página é a que o núcleo grava em
	 * `wp_page_for_privacy_policy`? FUNÇÃO PURA.
	 *
	 * Separada para ter piso: é ela que prova que desligar `bots_ia.llms_txt` e
	 * esvaziar a seleção do `llms.txt` NÃO faz o pacote parar de apontar a
	 * política de privacidade do site — o defeito que a 1.0.13 deixou em pé.
	 * Ela não recebe, não lê e não conhece nada de `seo`.
	 *
	 * @param string $ref_politica Referência lógica declarada da política.
	 * @param string $ref_entrada  Referência lógica da entrada em exame.
	 * @param int    $id           ID aplicado da entrada em exame.
	 * @return bool
	 */
	public static function grava_pagina_de_privacidade( string $ref_politica, string $ref_entrada, int $id ): bool {
		$ref_politica = trim( $ref_politica );

		return '' !== $ref_politica && $ref_politica === trim( $ref_entrada ) && $id > 0;
	}

	/**
	 * O GATE ÚNICO de "esta página está publicada?", medido no ARTEFATO.
	 *
	 * Existe porque a pergunta tem DOIS consumidores com formatos diferentes — o
	 * item de `f3base_llms`, que carrega URL, e o ID que vai para
	 * `wpseo_llmstxt` — e porque a resposta precisa distinguir três estados que
	 * não são intercambiáveis:
	 *
	 * - **não existe**: a referência lógica não resolve para página gerenciada.
	 *   Isso é defeito de configuração, e quem o consome fecha BLOCKED.
	 * - **existe e não está publicada**: estado LEGÍTIMO — é exatamente o que a
	 *   guarda do controlador produz na política. Sai da seleção e sai NOMEADA,
	 *   nunca como se a página não existisse.
	 * - **publicada**: entra, com o ID.
	 *
	 * Quem decide é `get_post_status()` no banco, nunca o status declarado na
	 * configuração: entre o que se pediu e o que o objeto é, quem governa o que
	 * vai para um arquivo público é o objeto.
	 *
	 * @param string $ref Referência lógica da página.
	 * @return array{id:int,existe:bool,publicada:bool,observado:string}
	 */
	public static function id_de_pagina_publicada( string $ref ): array {
		$ref = trim( $ref );

		if ( '' === $ref ) {
			return array(
				'id'        => 0,
				'existe'    => false,
				'publicada' => false,
				'observado' => '',
			);
		}

		$id = self::localizar_gerenciado( 'page', $ref );

		if ( $id <= 0 ) {
			return array(
				'id'        => 0,
				'existe'    => false,
				'publicada' => false,
				'observado' => '',
			);
		}

		$observado = (string) get_post_status( $id );
		$publicada = 'publish' === $observado;

		return array(
			'id'        => $publicada ? $id : 0,
			'existe'    => true,
			'publicada' => $publicada,
			'observado' => $observado,
		);
	}

	/**
	 * As chaves de `contato.controlador` que são CONDIÇÃO DE PUBLICAÇÃO.
	 *
	 * `encarregado` NÃO está aqui, e a ausência é decisão declarada: o art. 41
	 * da LGPD obriga o controlador a indicar encarregado, mas o pacote não tem o
	 * nome e não o inventa — vazio, o texto da página diz que o canal de contato
	 * do site recebe os pedidos, e a política publica assim mesmo, porque o que o
	 * art. 9º exige da notificação é saber QUEM trata e por onde falar com ele.
	 *
	 * @return array<int,string> Caminhos de configuração.
	 */
	public static function chaves_de_publicacao_do_controlador(): array {
		return array(
			'contato.controlador.razao_social',
			'contato.controlador.documento',
			'contato.controlador.endereco',
		);
	}

	/**
	 * Os valores do controlador, por CAMINHO de configuração. MEDIÇÃO.
	 *
	 * As quatro chaves são lidas por LITERAL, uma a uma, e não por caminho
	 * montado em laço: o cruzamento geral de `estatica.detector_chave_sem_consumidor`
	 * normaliza índice dinâmico para `*` e uma leitura montada deixaria as
	 * quatro chaves órfãs — a configuração prometendo o que nenhuma linha lê.
	 *
	 * @return array<string,string> Caminho => valor aparado.
	 */
	public static function controlador_medido(): array {
		return array(
			'contato.controlador.razao_social' => trim( (string) F3Base_Imp_Config::obter( 'contato.controlador.razao_social', '' ) ),
			'contato.controlador.documento'    => trim( (string) F3Base_Imp_Config::obter( 'contato.controlador.documento', '' ) ),
			'contato.controlador.endereco'     => trim( (string) F3Base_Imp_Config::obter( 'contato.controlador.endereco', '' ) ),
			'contato.controlador.encarregado'  => trim( (string) F3Base_Imp_Config::obter( 'contato.controlador.encarregado', '' ) ),
		);
	}

	/**
	 * Quais chaves de publicação do controlador estão VAZIAS. FUNÇÃO PURA.
	 *
	 * @param array<string,string> $medido Valores medidos, por caminho.
	 * @return array<int,string> Caminhos vazios, na ordem declarada.
	 */
	public static function faltando_no_controlador( array $medido ): array {
		$faltando = array();

		foreach ( self::chaves_de_publicacao_do_controlador() as $caminho ) {
			if ( '' === trim( (string) ( $medido[ $caminho ] ?? '' ) ) ) {
				$faltando[] = $caminho;
			}
		}

		return $faltando;
	}

	/**
	 * O caminho de saída da guarda do controlador, dito por inteiro.
	 *
	 * @param array<int,string> $faltando Caminhos vazios.
	 * @return string
	 */
	public static function saida_da_guarda_do_controlador( array $faltando ): string {
		return sprintf(
			/* translators: %s: caminhos de configuração vazios, nomeados. */
			__( 'Caminho de saída: preencha %s em config/site.json e execute de novo — a página publica sozinha na execução seguinte, sem passo manual. Não há botão a apertar nem status a mudar à mão.', 'f3base' ),
			implode( ', ', $faltando )
		);
	}

	/**
	 * A REGRA do status efetivo de página, PURA: mede-se fora, decide-se aqui.
	 *
	 * O ônus é o mesmo da indexação na 1.0.12, e pela mesma razão: o implantador
	 * existe para entregar site pronto para produção, então TODA página declara
	 * `publish` e o produtor só REBAIXA quando MEDE um motivo. A guarda que
	 * existe hoje é uma só, e ela não pode dar falso positivo em site real —
	 * `razao_social`, `documento` ou `endereco` de `contato.controlador` vazios
	 * na página que a configuração aponta como política de privacidade.
	 *
	 * Por que ela existe: o texto da política identifica o controlador com os
	 * valores desta chave, e publicar política sem dizer quem é o controlador é
	 * notificação deficiente na face do art. 9º da LGPD. O pacote não inventa
	 * razão social, documento nem endereço de ninguém — é dado que só o operador
	 * tem, exatamente como `contato.whatsapp_e164`.
	 *
	 * O que a guarda NÃO é: uma espera por revisão jurídica. Rascunho por
	 * decisão do pacote, em silêncio, foi o defeito que esta release corrigiu.
	 *
	 * @param string               $ref           Referência lógica da página.
	 * @param string               $declarado     Status declarado em `paginas.*.status`.
	 * @param string               $ref_politica  Referência lógica da política, declarada na configuração.
	 * @param array<string,string> $medido        Valores do controlador, por caminho.
	 * @return array{status:string,declarado:string,guarda:string,faltando:array<int,string>,motivo:string}
	 */
	public static function veredito_de_status_de_pagina( string $ref, string $declarado, string $ref_politica, array $medido ): array {
		$aplicavel = 'publish' === $declarado && '' !== $ref_politica && $ref === $ref_politica;

		if ( ! $aplicavel ) {
			return array(
				'status'    => $declarado,
				'declarado' => $declarado,
				'guarda'    => '',
				'faltando'  => array(),
				'motivo'    => sprintf(
					/* translators: 1: referência lógica, 2: status declarado. */
					__( 'página %1$s: status efetivo "%2$s", que é o declarado na configuração. Nenhuma guarda de status se aplica a esta página.', 'f3base' ),
					$ref,
					$declarado
				),
			);
		}

		$faltando = self::faltando_no_controlador( $medido );

		if ( array() === $faltando ) {
			return array(
				'status'    => $declarado,
				'declarado' => $declarado,
				'guarda'    => self::GUARDA_CONTROLADOR,
				'faltando'  => array(),
				'motivo'    => sprintf(
					/* translators: 1: referência lógica, 2: status declarado, 3: nome da guarda. */
					__( 'página %1$s: status efetivo "%2$s". A guarda %3$s foi MEDIDA e não segurou nada — a qualificação do controlador está completa na configuração, e a política é publicada como qualquer outra página deste pacote.', 'f3base' ),
					$ref,
					$declarado,
					self::GUARDA_CONTROLADOR
				),
			);
		}

		return array(
			'status'    => 'draft',
			'declarado' => $declarado,
			'guarda'    => self::GUARDA_CONTROLADOR,
			'faltando'  => $faltando,
			'motivo'    => sprintf(
				/* translators: 1: referência lógica, 2: status declarado, 3: quantidade de chaves vazias, 4: chaves vazias nomeadas, 5: caminho de saída. */
				__( 'página %1$s: a configuração declara "%2$s" e o status efetivo é "draft" por UMA guarda MEDIDA, nomeada aqui — %3$d chave(s) de contato.controlador está(ão) vazia(s): %4$s. Isto não é rascunho por decisão do pacote nem espera por revisão jurídica: o texto desta página identifica o controlador por esses valores, e política publicada sem dizer quem é o controlador é notificação deficiente na face do art. 9º da LGPD. O pacote não inventa razão social, documento nem endereço. %5$s', 'f3base' ),
				$ref,
				$declarado,
				count( $faltando ),
				implode( ', ', $faltando ),
				self::saida_da_guarda_do_controlador( $faltando )
			),
		);
	}

	/**
	 * O STATUS EFETIVO de uma página gerenciada — PONTO ÚNICO que o produz.
	 *
	 * Toda decisão de status de página passa por aqui, e é isso que
	 * `estatica.pagina_status_fonte_unica` confere: enquanto duas etapas
	 * decidirem por caminhos diferentes o que é publicado, a segunda a rodar
	 * contradiz a primeira e o relatório sai com duas afirmações verdadeiras
	 * sobre o mesmo artefato — a mesma família de defeito de `f3base_redirects`.
	 *
	 * @param string $ref       Referência lógica da página.
	 * @param string $declarado Status declarado para ela.
	 * @return array{status:string,declarado:string,guarda:string,faltando:array<int,string>,motivo:string}
	 */
	public static function status_efetivo_de_pagina( string $ref, string $declarado ): array {
		return self::veredito_de_status_de_pagina(
			$ref,
			$declarado,
			self::ref_da_politica_de_privacidade(),
			self::controlador_medido()
		);
	}

	/**
	 * Interpola na PROSA do arquivo os valores que só o operador tem.
	 *
	 * Duas operações, nesta ordem:
	 *
	 * 1. **Bloco condicional.** Bloco com o atributo `f3baseSe` sai do conteúdo
	 *    quando o caminho nomeado está vazio; bloco com `f3baseSeVazio` sai
	 *    quando ele está preenchido. É como as duas redações do encarregado
	 *    convivem no arquivo sem que nenhuma delas seja escrita em PHP.
	 *    Caminho fora do conjunto fechado NÃO apaga bloco nenhum: apagar prosa
	 *    em silêncio por causa de um caminho digitado errado é pior do que
	 *    deixar as duas redações visíveis, e a redação nominal carrega o
	 *    marcador não resolvido que `privacidade.controlador_identificado` acusa.
	 * 2. **Marcador nomeado.** `%f3base:<caminho>%` vira o valor daquele caminho,
	 *    escapado. O conjunto é fechado por `controlador_medido()`.
	 *
	 * @param string $html Conteúdo editorial lido do arquivo.
	 * @return string
	 */
	public static function interpolar_configuracao( string $html ): string {
		return self::interpolar_com( $html, self::controlador_medido() );
	}

	/**
	 * A REGRA da interpolação, PURA: mede-se fora, resolve-se aqui.
	 *
	 * @param string               $html   Conteúdo editorial.
	 * @param array<string,string> $medido Valores por caminho de configuração.
	 * @return string
	 */
	public static function interpolar_com( string $html, array $medido ): string {
		$html = self::resolver_blocos_condicionais( $html, $medido );

		foreach ( $medido as $caminho => $valor ) {
			$html = str_replace( self::MARCA_ABRE . $caminho . self::MARCA_FECHA, esc_html( $valor ), $html );
		}

		return $html;
	}

	/**
	 * Remove do conteúdo os blocos cuja condição declarada não vale.
	 *
	 * @param string               $html   Conteúdo.
	 * @param array<string,string> $medido Valores por caminho.
	 * @return string
	 */
	private static function resolver_blocos_condicionais( string $html, array $medido ): string {
		/*
		 * O casamento EXIGE a marca no atributo, e isso não é otimização: uma
		 * expressão que casasse qualquer bloco com atributo casaria primeiro o
		 * `wp:group` que ENVOLVE os condicionais, devolveria o grupo inteiro
		 * intacto e a varredura seguiria depois do fecho dele — os blocos de
		 * dentro nunca seriam vistos. `preg_replace_callback()` não recorre, e
		 * este é exatamente o modo de falha silenciosa: as duas redações do
		 * encarregado sairiam publicadas juntas, contradizendo uma à outra.
		 */
		$re = '#<!--\s*wp:([a-z0-9][a-z0-9/-]*)\s+(\{[^\r\n]*?f3baseSe[^\r\n]*?\})\s*-->.*?<!--\s*/wp:\1\s*-->\s*#s';

		$substituido = preg_replace_callback(
			$re,
			static function ( array $casamento ) use ( $medido ): string {
				$atributos = json_decode( $casamento[2], true );

				if ( ! is_array( $atributos ) ) {
					return $casamento[0];
				}

				foreach ( array( 'f3baseSe' => true, 'f3baseSeVazio' => false ) as $atributo => $exige_preenchido ) {
					$caminho = isset( $atributos[ $atributo ] ) ? (string) $atributos[ $atributo ] : '';

					if ( '' === $caminho || ! array_key_exists( $caminho, $medido ) ) {
						continue;
					}

					$preenchido = '' !== trim( (string) $medido[ $caminho ] );

					return $preenchido === $exige_preenchido ? $casamento[0] : '';
				}

				return $casamento[0];
			},
			$html
		);

		return is_string( $substituido ) ? $substituido : $html;
	}

	/**
	 * Veredito do CONTROLADOR IDENTIFICADO no conteúdo servido. FUNÇÃO PURA.
	 *
	 * Três saídas, e elas não são intercambiáveis:
	 *
	 * - **Chave de publicação vazia: BLOCKED.** Pré-condição de projeto ausente,
	 *   nunca defeito do pacote — a mesma classificação de `contato.whatsapp_e164`
	 *   vazia. A mensagem nomeia QUAIS chaves faltam e o caminho de saída.
	 * - **Chaves completas e a qualificação PRESENTE no conteúdo servido: OK.**
	 *   Leitura de volta: não basta a configuração estar preenchida, o valor
	 *   precisa estar no que o visitante lê.
	 * - **Chaves completas e a qualificação AUSENTE: FALHA.** A interpolação
	 *   furou em silêncio — marcador digitado errado, arquivo trocado, edição
	 *   que apagou a seção — e a política está no ar sem identificar o
	 *   controlador, que é justamente o que a guarda existia para impedir.
	 *
	 * @param array<string,string> $medido           Valores do controlador, por caminho.
	 * @param string               $conteudo_servido Conteúdo lido de volta do objeto.
	 * @return array{estado:string,motivo:string,resumo:string,faltando:array<int,string>,ausentes:array<int,string>}
	 */
	public static function veredito_do_controlador( array $medido, string $conteudo_servido ): array {
		$faltando = self::faltando_no_controlador( $medido );

		if ( array() !== $faltando ) {
			return array(
				'estado'   => F3Base_Imp_Relatorio::BLOCKED,
				'faltando' => $faltando,
				'ausentes' => array(),
				'motivo'   => sprintf(
					/* translators: 1: quantidade de chaves vazias, 2: chaves vazias nomeadas, 3: caminho de saída. */
					__( 'pré-condição ausente: %1$d chave(s) de contato.controlador está(ão) vazia(s) em config/site.json — %2$s. Elas nascem vazias por desenho: são dado do projeto, não defeito do pacote, e o implantador não inventa a qualificação de um controlador. Enquanto faltarem, a página da política fica em "draft" pela guarda medida, não é oferecida ao llms.txt e o link do rodapé não aponta para ela. %3$s', 'f3base' ),
					count( $faltando ),
					implode( ', ', $faltando ),
					self::saida_da_guarda_do_controlador( $faltando )
				),
				'resumo'   => sprintf(
					/* translators: %s: chaves vazias nomeadas. */
					__( 'controlador a preencher em %s (BLOCKED)', 'f3base' ),
					implode( ', ', $faltando )
				),
			);
		}

		$ausentes = array();

		foreach ( self::chaves_de_publicacao_do_controlador() as $caminho ) {
			$valor = trim( (string) ( $medido[ $caminho ] ?? '' ) );

			if ( ! str_contains( $conteudo_servido, esc_html( $valor ) ) ) {
				$ausentes[] = $caminho;
			}
		}

		if ( str_contains( $conteudo_servido, self::MARCA_ABRE ) ) {
			$ausentes[] = __( 'marcador de interpolação não resolvido no conteúdo servido', 'f3base' );
		}

		if ( array() !== $ausentes ) {
			return array(
				'estado'   => F3Base_Imp_Relatorio::FALHA,
				'faltando' => array(),
				'ausentes' => $ausentes,
				'motivo'   => sprintf(
					/* translators: 1: quantidade de ausências, 2: ausências nomeadas. */
					__( 'as chaves de contato.controlador estão TODAS preenchidas na configuração e a qualificação NÃO está no conteúdo servido: %1$d ocorrência(s) — %2$s. A interpolação furou em silêncio, e o efeito é o pior dos dois mundos: a guarda liberou a publicação porque a configuração estava completa, e a política está no ar sem identificar o controlador. Confira os marcadores %3$s<caminho>%4$s em content/pages da página da política.', 'f3base' ),
					count( $ausentes ),
					implode( ', ', $ausentes ),
					self::MARCA_ABRE,
					self::MARCA_FECHA
				),
				'resumo'   => __( 'qualificação do controlador ausente do conteúdo servido (FALHA)', 'f3base' ),
			);
		}

		return array(
			'estado'   => F3Base_Imp_Relatorio::OK,
			'faltando' => array(),
			'ausentes' => array(),
			'motivo'   => sprintf(
				/* translators: 1: quantidade de chaves conferidas, 2: chaves conferidas nomeadas. */
				__( 'controlador identificado no conteúdo SERVIDO: as %1$d chaves de publicação de contato.controlador estão preenchidas e cada valor foi encontrado no conteúdo lido de volta do objeto — %2$s. A política está publicada dizendo quem trata os dados, que é o que o art. 9º da LGPD exige da notificação.', 'f3base' ),
				count( self::chaves_de_publicacao_do_controlador() ),
				implode( ', ', self::chaves_de_publicacao_do_controlador() )
			),
			'resumo'   => __( 'controlador identificado no conteúdo servido', 'f3base' ),
		);
	}

	/**
	 * Os QUATRO ramos da checagem do controlador, num lugar só. FUNÇÃO PURA.
	 *
	 * Existe separada do emissor para que os ramos tenham teto e piso na sonda,
	 * inclusive o que a 1.0.13 deixou frágil: com a identidade da política vindo
	 * de uma chave de llms.txt, desligar o llms.txt derrubava a checagem em N/A.
	 * Agora a identidade vem do papel declarado na entrada da página, e este
	 * ramo N/A só existe quando o projeto REALMENTE não declara política.
	 *
	 * @param string               $ref_politica Referência lógica declarada da política.
	 * @param int                  $id           ID da página aplicada, ou 0.
	 * @param array<string,string> $medido       Valores do controlador, por caminho.
	 * @param string               $conteudo     Conteúdo lido de volta do objeto.
	 * @return array{estado:string,motivo:string,evidencia:string,fase:string}
	 */
	public static function veredito_da_checagem_do_controlador( string $ref_politica, int $id, array $medido, string $conteudo ): array {
		if ( '' === trim( $ref_politica ) ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::NA,
				'motivo'    => __( 'condição de aplicabilidade falsa: nenhuma entrada de paginas declara papel = "politica-privacidade", e sem página de política não há texto onde a qualificação do controlador devesse aparecer. Este ramo NÃO depende de bots_ia.llms_txt nem da seleção do llms.txt: desligar o llms.txt não silencia esta checagem.', 'f3base' ),
				'evidencia' => 'analise-estatica',
				'fase'      => 'local',
			);
		}

		if ( $id <= 0 ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: %s: referência lógica da política. */
					__( 'pré-condição ausente: a página da política (ref %s) ainda não existe no banco, e a qualificação do controlador se mede no conteúdo servido, não no arquivo do pacote. Falta: a etapa de conteúdo aplicar a página nesta instalação.', 'f3base' ),
					$ref_politica
				),
				'evidencia' => 'pendencia-externa',
				'fase'      => 'local',
			);
		}

		$veredito = self::veredito_do_controlador( $medido, $conteudo );

		return array(
			'estado'    => $veredito['estado'],
			'motivo'    => $veredito['motivo'],
			'evidencia' => 'leitura-de-volta',
			'fase'      => 'local',
		);
	}

	/**
	 * Slug determinístico de um ANEXO gerenciado, derivado da referência lógica.
	 *
	 * A colisão medida: as três entradas de `midia` declaram `alt: "Método F3"`,
	 * o sideload usa o `alt` como TÍTULO do anexo, o anexo herda o slug do
	 * título, e a etapa de mídia roda antes da de conteúdo. Resultado no banco:
	 * `attachment #10 post_name=metodo-f3` (o logo), `page #11
	 * post_name=metodo-f3-2` (a home) e `attachment #22 post_name=metodo-f3-3`
	 * (a social). O `alt` continua sendo acessibilidade e pode seguir
	 * alimentando o título; o que não pode é o SLUG nascer daí.
	 *
	 * @param string $ref Referência lógica da entrada de `midia`.
	 * @return string Slug gerenciado, ou vazio quando não há prefixo declarado.
	 */
	public static function slug_de_anexo_gerenciado( string $ref ): string {
		$prefixo = (string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' );

		if ( '' === $prefixo || '' === $ref ) {
			return '';
		}

		return sanitize_title( $prefixo . '-' . $ref );
	}

	/**
	 * Tipos que DISPUTAM um slug com um objeto do tipo dado.
	 *
	 * O conjunto não é escolha nossa: sai de `wp_unique_post_slug()`. Para tipo
	 * HIERÁRQUICO o núcleo consulta `post_type IN ('page','attachment')` — é por
	 * isso que um anexo tira o slug de uma página, e é isso que a mensagem de
	 * diagnóstico precisa saber para nomear o culpado. Para tipo não
	 * hierárquico, a disputa é só com o próprio tipo (e com `attachment`, que o
	 * núcleo consulta sempre que o slug pedido bate com um anexo).
	 *
	 * @param string $tipo Tipo do objeto gerenciado.
	 * @return array<int,string>
	 */
	public static function tipos_que_disputam_slug( string $tipo ): array {
		$tipos = array( $tipo, 'attachment' );

		if ( function_exists( 'is_post_type_hierarchical' ) && is_post_type_hierarchical( $tipo ) ) {
			$tipos[] = 'page';
		}

		return array_values( array_unique( $tipos ) );
	}

	/**
	 * Quem ocupa o slug pretendido, NOMEADO: id, tipo, status e título.
	 *
	 * "O slug é o suspeito de sempre" descreve a classe e não resolve o caso. A
	 * pergunta que o operador faz em seguida é sempre a mesma — quem está com o
	 * slug? — e ela se responde com uma consulta ao banco, não com prosa.
	 *
	 * @param string $tipo    Tipo do objeto gerenciado.
	 * @param string $slug    Slug pretendido.
	 * @param int    $excluir ID a excluir da busca (o próprio objeto).
	 * @return array<int,string> Descrições dos ocupantes, na ordem do id.
	 */
	public static function ocupantes_do_slug( string $tipo, string $slug, int $excluir = 0 ): array {
		if ( '' === $slug ) {
			return array();
		}

		$encontrados = get_posts(
			array(
				'post_type'        => self::tipos_que_disputam_slug( $tipo ),
				'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash', 'inherit' ),
				'name'             => $slug,
				'numberposts'      => 5,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'no_found_rows'    => true,
				'suppress_filters' => false,
				'exclude'          => $excluir > 0 ? array( $excluir ) : array(),
			)
		);

		$saida = array();

		foreach ( is_array( $encontrados ) ? $encontrados : array() as $ocupante ) {
			if ( ! $ocupante instanceof WP_Post ) {
				continue;
			}

			$saida[] = sprintf(
				/* translators: 1: ID, 2: post_type, 3: post_status, 4: título. */
				__( '#%1$d %2$s (%3$s) "%4$s"', 'f3base' ),
				(int) $ocupante->ID,
				(string) $ocupante->post_type,
				(string) $ocupante->post_status,
				(string) $ocupante->post_title
			);
		}

		return $saida;
	}

	/**
	 * Frase de diagnóstico de um slug que voltou desambiguado.
	 *
	 * Só afirma "o núcleo desambiguou" quando o observado É o desejado com
	 * sufixo `-N` — a forma exata que `wp_unique_post_slug()` produz. Fora
	 * dessa forma, o fato observado é outro e a mensagem diz isso, em vez de
	 * atribuir ao slug uma divergência que pode ser de outra natureza.
	 *
	 * @param string $tipo      Tipo do objeto.
	 * @param string $desejado  Slug pedido.
	 * @param string $observado Slug gravado.
	 * @param int    $id        ID do objeto em questão.
	 * @return string
	 */
	public static function diagnostico_de_slug( string $tipo, string $desejado, string $observado, int $id = 0 ): string {
		if ( '' === $desejado ) {
			return __( 'nenhum slug foi declarado para este objeto: sem post_name declarado o núcleo deriva do título e decide sozinho — declare o slug na configuração.', 'f3base' );
		}

		if ( 1 !== preg_match( '/^' . preg_quote( $desejado, '/' ) . '-([0-9]+)$/', $observado ) ) {
			return sprintf(
				/* translators: 1: slug desejado, 2: slug observado. */
				__( 'o slug pedido foi %1$s e o gravado é %2$s, que não é a forma <slug>-N produzida por wp_unique_post_slug(): a divergência não é de desambiguação, e nenhum ocupante foi imputado.', 'f3base' ),
				$desejado,
				$observado
			);
		}

		$ocupantes = self::ocupantes_do_slug( $tipo, $desejado, $id );

		return sprintf(
			/* translators: 1: slug desejado, 2: slug observado, 3: tipos consultados, 4: ocupantes nomeados. */
			__( 'o núcleo desambiguou em silêncio: pedido %1$s, gravado %2$s. Quem ocupa %1$s, consultado no banco em %3$s: %4$s', 'f3base' ),
			$desejado,
			$observado,
			implode( ', ', self::tipos_que_disputam_slug( $tipo ) ),
			array() === $ocupantes
				? __( 'nenhum objeto foi encontrado com esse slug agora — o ocupante pode ter saído entre a gravação e a leitura de volta', 'f3base' )
				: implode( '; ', $ocupantes )
		);
	}

	/**
	 * Grava o slug ANTERIOR de um objeto gerenciado, com leitura de volta.
	 *
	 * Mudança de slug de objeto gerenciado JÁ PUBLICADO é caso de primeira
	 * classe. Para a página inicial o slug não aparece na URL, mas o mecanismo é
	 * GERAL e precisa valer para qualquer página: o `site-core` já implementa o
	 * redirecionamento lendo esta meta, tratando `pagename` e `name`.
	 *
	 * @param int    $id       ID do objeto.
	 * @param string $anterior Slug anterior, não vazio.
	 * @param string $novo     Slug novo.
	 * @return array{estado:string,motivo:string}
	 */
	public static function registrar_slug_anterior( int $id, string $anterior, string $novo ): array {
		if ( '' === $anterior || $anterior === $novo ) {
			return array(
				'estado' => 'N/A',
				'motivo' => __( 'condição de aplicabilidade falsa: não houve troca de slug, e não há endereço antigo a redirecionar.', 'f3base' ),
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return array(
				'estado' => 'N/A',
				'motivo' => sprintf(
					/* translators: 1: meta, 2: slug anterior. */
					__( 'modo simulação: gravaria %1$s = %2$s para o redirecionamento do endereço antigo.', 'f3base' ),
					self::META_SLUG_ANTERIOR,
					$anterior
				),
			);
		}

		F3Base_Imp_Gravador::gravar_meta( 'post', $id, self::META_SLUG_ANTERIOR, $anterior );

		$lido = (string) get_post_meta( $id, self::META_SLUG_ANTERIOR, true );

		return array(
			'estado' => $lido === $anterior ? 'OK' : 'FALHA',
			'motivo' => $lido === $anterior
				? sprintf(
					/* translators: 1: slug anterior, 2: slug novo, 3: nome da meta. */
					__( 'slug trocado de %1$s para %2$s: o anterior ficou gravado em %3$s e conferido na leitura de volta, e é essa meta que o site-core lê para servir 301 do endereço antigo, por pagename e por name.', 'f3base' ),
					$anterior,
					$novo,
					self::META_SLUG_ANTERIOR
				)
				: sprintf(
					/* translators: 1: slug anterior, 2: valor relido. */
					__( 'o slug anterior %1$s NÃO conferiu na leitura de volta (relido: %2$s): sem essa meta, toda URL publicada com o slug antigo passa a 404 em silêncio.', 'f3base' ),
					$anterior,
					'' !== $lido ? $lido : __( 'vazio', 'f3base' )
				),
		);
	}

	/**
	 * Valores de `post_modified` a restaurar na próxima gravação.
	 *
	 * @var array<string,string>
	 */
	private static array $modificado_a_restaurar = array();

	/**
	 * Ranking de publicidade dos status, para a regra de não promoção.
	 *
	 * @param string $status Status.
	 * @return int Quanto maior, mais público.
	 */
	public static function rank_status( string $status ): int {
		switch ( $status ) {
			case 'publish':
				return 4;
			case 'private':
				return 3;
			case 'future':
			case 'pending':
				return 2;
			default:
				return 1;
		}
	}

	/**
	 * Decisão do merge de três vias, por campo.
	 *
	 * Função PURA: é ela que o piso da suíte exercita, e é ela que roda contra o
	 * site. Piso que reimplementa a regra prova que outra regra funcionaria.
	 *
	 * @param string|null $base      Hash do último aplicado, ou null quando não há base.
	 * @param string      $observado Hash do valor observado no site.
	 * @param string      $desejado  Hash do valor desejado.
	 * @param string      $politica  `gerenciado`, `preservar` ou `conflito`.
	 * @return array{acao:string,base:string,motivo:string}
	 */
	public static function merge_campo( ?string $base, string $observado, string $desejado, string $politica ): array {
		if ( $observado === $desejado ) {
			return array(
				'acao'   => 'atualizar_base',
				'base'   => self::BASE_DESEJADO,
				'motivo' => __( 'observado já é o desejado: não gravar, só atualizar a base.', 'f3base' ),
			);
		}

		if ( null === $base ) {
			/*
			 * Primeira execução da estrutura de base — o cenário que a release
			 * que INTRODUZ a base é exatamente a que não tem nenhuma. Sem base,
			 * a política declarada por campo decide; nunca o default público.
			 */
			if ( 'preservar' === $politica ) {
				return array(
					'acao'   => 'preservar',
					'base'   => self::BASE_INALTERADA,
					'motivo' => __( 'sem base de merge e política do campo é preservar: a edição observada permanece e vira base.', 'f3base' ),
				);
			}

			if ( 'gerenciado' === $politica ) {
				return array(
					'acao'   => 'gravar',
					'base'   => self::BASE_DESEJADO,
					'motivo' => __( 'sem base de merge e política do campo é gerenciado: o desejado é aplicado e vira base.', 'f3base' ),
				);
			}

			return array(
				'acao'   => 'conflito',
				'base'   => self::BASE_INALTERADA,
				'motivo' => __( 'sem base de merge e sem política declarada para o campo: conflito, sem escrita.', 'f3base' ),
			);
		}

		if ( $base === $observado ) {
			return array(
				'acao'   => 'gravar',
				'base'   => self::BASE_DESEJADO,
				'motivo' => __( 'observado igual à base e desejado diferente: atualização segura.', 'f3base' ),
			);
		}

		if ( $base === $desejado ) {
			return array(
				'acao'   => 'preservar',
				'base'   => self::BASE_INALTERADA,
				'motivo' => __( 'edição humana sobre a base e desejado igual à base: a edição é preservada.', 'f3base' ),
			);
		}

		/*
		 * O RAMO QUE A 1.1.0 INVERTEU, e é a inversão inteira desta função.
		 * Até a 1.0.19, base ≠ observado ≠ desejado com política `gerenciado`
		 * GRAVAVA: o conteúdo do template vencia a edição de quem opera o site.
		 * Sob a premissa desta release — depois da instalação, toda modificação
		 * é do agente pelo canal —, isso está de cabeça para baixo. O conteúdo
		 * que este pacote traz é DEMONSTRATIVO; uma vez que o agente o
		 * substituiu pelo do cliente, uma atualização do template não tem por
		 * onde saber que o texto novo dela é melhor que o texto que está no ar.
		 * O pacote só grava conteúdo em objeto que o agente nunca tocou, que é
		 * o ramo `base === observado` logo acima.
		 *
		 * A política de campo continua discriminando, e no único lugar em que
		 * ela ainda pode: SEM BASE. Ali `gerenciado` aplica o desejado e
		 * `preservar` mantém o observado — é a primeira execução, e não existe
		 * edição a proteger nem a atropelar.
		 */
		if ( 'gerenciado' === $politica ) {
			return array(
				'acao'   => 'preservar',
				'base'   => self::BASE_INALTERADA,
				'motivo' => __( 'edição de quem opera o site E desejado novo, com política de campo gerenciado: a EDIÇÃO vence e a divergência sai NOMEADA no relatório. Até a 1.0.19 este ramo gravava, e era o template apagando o conteúdo do cliente a cada reexecução do implantador.', 'f3base' ),
			);
		}

		if ( 'preservar' === $politica ) {
			return array(
				'acao'   => 'preservar',
				'base'   => self::BASE_INALTERADA,
				'motivo' => __( 'edição de quem opera o site e desejado novo, com política explícita de campo preservado: a edição vence, e a divergência entra no relatório.', 'f3base' ),
			);
		}

		return array(
			'acao'   => 'conflito',
			'base'   => self::BASE_INALTERADA,
			'motivo' => __( 'edição humana e desejado novo, sem política explícita: conflito, sem escrita.', 'f3base' ),
		);
	}

	/**
	 * Localiza um objeto gerenciado pela identidade lógica.
	 *
	 * @param string $tipo Tipo de post (`page`, `post`, `attachment`, `wp_navigation`).
	 * @param string $ref  Identidade lógica.
	 * @return int ID, ou 0.
	 */
	public static function localizar_gerenciado( string $tipo, string $ref ): int {
		if ( '' === $ref ) {
			return 0;
		}

		/*
		 * `post_type` explícito: `'any'` exclui tipos registrados com
		 * `public => false` — `wp_navigation` é um deles.
		 */
		$encontrados = get_posts(
			array(
				'post_type'        => $tipo,
				'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash', 'inherit' ),
				'numberposts'      => 1,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => false,
				'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- consulta de identidade, uma vez por objeto gerenciado.
					array(
						'key'     => self::META_ID,
						'value'   => self::identidade( $tipo, $ref ),
						'compare' => '=',
					),
				),
			)
		);

		return ( is_array( $encontrados ) && array() !== $encontrados ) ? (int) $encontrados[0] : 0;
	}

	/**
	 * Identidade lógica gravada na meta.
	 *
	 * @param string $tipo Tipo.
	 * @param string $ref  Referência.
	 * @return string
	 */
	public static function identidade( string $tipo, string $ref ): string {
		return $tipo . ':' . $ref;
	}

	/**
	 * A marca de conteúdo demonstrativo, montada a partir do prefixo do site.
	 *
	 * FUNÇÃO PURA e ponto único: o comentário que abre cada arquivo de
	 * `content/` traz esta marca, e é por ela — nunca por uma lista de nomes de
	 * arquivo — que se sabe se aquele conteúdo ainda é o do template. Montada do
	 * prefixo declarado porque o pacote é template de criação de sites: cada
	 * site recebe o seu, e uma marca literal aqui seria a marca do template
	 * sobrevivendo dentro do site do cliente.
	 *
	 * @param string $prefixo Prefixo técnico declarado em site.prefixo_tecnico.
	 * @return string Marca, ou vazio quando não há prefixo declarado.
	 */
	public static function marca_demonstrativa( string $prefixo ): string {
		$prefixo = trim( $prefixo );

		if ( '' === $prefixo ) {
			return '';
		}

		return $prefixo . ':conteudo-demonstrativo';
	}

	/**
	 * A declaração e o arquivo dizem a mesma coisa? FUNÇÃO PURA.
	 *
	 * A regra, e por que ela é FALHA e não aviso. `conteudo.demonstrativo` é a
	 * declaração de que o conteúdo ainda é o do template; a marca no topo do
	 * arquivo é a mesma afirmação, do lado do disco. Divergência entre as duas
	 * significa que UMA DELAS ESTÁ MENTINDO, e o caso que importa é sempre o
	 * mesmo: alguém desligou a chave para calar o aviso e não trocou o conteúdo.
	 * Publicar assim põe a prosa do método no ar com o endereço do cliente e com
	 * a configuração afirmando que aquilo é conteúdo do cliente.
	 *
	 * O ramo inverso — chave ligada e arquivo sem marca — não impede nada aqui:
	 * arquivo novo, ainda sem marca, é conteúdo do cliente entrando, e quem
	 * cobra a marcação completa é a suíte, em `conteudo.marca_demonstrativa`,
	 * que cruza o pacote inteiro e tem piso dos dois lados.
	 *
	 * @param string $conteudo       Conteúdo lido do arquivo.
	 * @param bool   $demonstrativo  O que a configuração declara.
	 * @param string $prefixo        Prefixo técnico declarado.
	 * @param string $arquivo        Caminho relativo, para a mensagem.
	 * @return string Vazio quando não há divergência; a mensagem de falha quando há.
	 */
	public static function guarda_de_marca_demonstrativa( string $conteudo, bool $demonstrativo, string $prefixo, string $arquivo ): string {
		$marca = self::marca_demonstrativa( $prefixo );

		if ( '' === $marca || $demonstrativo ) {
			return '';
		}

		if ( ! str_contains( $conteudo, $marca ) ) {
			return '';
		}

		return sprintf(
			/* translators: 1: caminho relativo do arquivo, 2: a marca procurada. */
			__( 'a configuração declara conteudo.demonstrativo = false e %1$s ainda abre com a marca "%2$s": o arquivo continua sendo o do template. Publicar aqui poria a prosa do método no ar afirmando, na própria configuração, que ela é conteúdo deste site. Troque o conteúdo do arquivo (a marca sai junto) ou volte a declarar conteudo.demonstrativo = true enquanto o conteúdo for o do template.', 'f3base' ),
			$arquivo,
			$marca
		);
	}

	/**
	 * Aplica uma página declarada.
	 *
	 * @param int $indice Índice na lista `paginas`.
	 * @return array<string,mixed>
	 */
	public static function aplicar_pagina( int $indice ): array {
		$ref = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );

		if ( '' === $ref ) {
			return self::saida( 'BLOCKED', 'conteudo.pagina', __( 'entrada de página sem referência lógica declarada.', 'f3base' ) );
		}

		$arquivo = f3base_imp_caminho( 'content/pages/' . $ref . '.html' );

		if ( '' === $arquivo || ! is_readable( $arquivo ) ) {
			return self::saida(
				'BLOCKED',
				'conteudo.pagina:' . $ref,
				sprintf(
					/* translators: %s: caminho relativo do arquivo de conteúdo. */
					__( 'conteúdo editorial ausente: %s. Página não é criada com corpo vazio.', 'f3base' ),
					'content/pages/' . $ref . '.html'
				)
			);
		}

		$conteudo = (string) file_get_contents( $arquivo ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do próprio pacote.

		$divergencia = self::guarda_de_marca_demonstrativa(
			$conteudo,
			(bool) F3Base_Imp_Config::obter( 'conteudo.demonstrativo', false ),
			(string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' ),
			'content/pages/' . $ref . '.html'
		);

		if ( '' !== $divergencia ) {
			return self::saida( 'FALHA', 'conteudo.pagina:' . $ref, $divergencia );
		}

		$conteudo = self::injetar_ids_de_anexo( $conteudo );
		$conteudo = self::interpolar_configuracao( $conteudo );

		$pai = 0;
		$ref_pai = F3Base_Imp_Config::obter( 'paginas.' . $indice . '.post_parent_ref', null );

		if ( is_string( $ref_pai ) && '' !== $ref_pai ) {
			$pai = self::localizar_gerenciado( 'page', $ref_pai );

			if ( $pai <= 0 ) {
				return self::saida(
					'BLOCKED',
					'conteudo.pagina:' . $ref,
					sprintf(
						/* translators: %s: referência lógica do pai. */
						__( 'pai declarado por referência lógica não existe ainda: %s. Erro explícito em vez de página órfã na raiz.', 'f3base' ),
						$ref_pai
					)
				);
			}
		}

		/*
		 * O status efetivo sai do PRODUTOR ÚNICO — nunca do valor declarado,
		 * lido direto aqui. O motivo viaja junto e é registrado, para que uma
		 * página que nasce em "draft" nunca nasça em silêncio.
		 */
		$status = self::status_efetivo_de_pagina( $ref, (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.status', 'draft' ) );

		$desejado = array(
			'post_title'   => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.titulo', '' ),
			'post_name'    => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.slug', '' ),
			'post_status'  => $status['status'],
			'post_content' => $conteudo,
			'post_excerpt' => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.seo.descricao', '' ),
			'post_parent'  => $pai,
		);

		$adotavel = (bool) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.adotar_existente', false );

		$resultado = self::aplicar_objeto( 'page', $ref, $desejado, $adotavel, $indice );

		if ( 'OK' === $resultado['estado'] && $resultado['id'] > 0 ) {
			$template = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.template', '' );

			if ( '' !== $template && 'page' !== $template && 'front-page' !== $template ) {
				F3Base_Imp_Gravador::gravar_meta( 'post', $resultado['id'], '_wp_page_template', $template );
			}

			F3Base_Imp_Seo::gravar_por_conteudo(
				$resultado['id'],
				array(
					'titulo'      => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.seo.titulo', '' ),
					'descricao'   => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.seo.descricao', '' ),
					'frase_chave' => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.seo.frase_chave', '' ),
					'indexar'     => (bool) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.seo.indexar', true ),
					'cornerstone' => (bool) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.cornerstone', false ),
				)
			);
		}

		/*
		 * GUARDA QUE SEGUROU SAI NOMEADA. A 1.0.12 entregou a política em
		 * "draft" sem que uma linha do relatório dissesse por quê — e era essa
		 * decisão calada que esta release corrigiu. Quando o status efetivo
		 * diverge do declarado, o motivo viaja no texto da unidade.
		 */
		if ( $status['status'] !== $status['declarado'] ) {
			$resultado['motivo'] = $resultado['motivo'] . ' | ' . $status['motivo'];
		}

		return $resultado;
	}

	/**
	 * Aplica um post declarado.
	 *
	 * @param int $indice Índice na lista `posts`.
	 * @return array<string,mixed>
	 */
	public static function aplicar_post( int $indice ): array {
		$slug = (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' );

		if ( '' === $slug ) {
			return self::saida( 'BLOCKED', 'conteudo.post', __( 'entrada de post sem slug declarado.', 'f3base' ) );
		}

		$arquivo = f3base_imp_caminho( 'content/posts/' . $slug . '.html' );

		if ( '' === $arquivo || ! is_readable( $arquivo ) ) {
			return self::saida(
				'BLOCKED',
				'conteudo.post:' . $slug,
				sprintf(
					/* translators: %s: caminho relativo do arquivo de conteúdo. */
					__( 'conteúdo editorial ausente: %s. Post não é criado com corpo vazio.', 'f3base' ),
					'content/posts/' . $slug . '.html'
				)
			);
		}

		$conteudo = (string) file_get_contents( $arquivo ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do próprio pacote.

		$divergencia = self::guarda_de_marca_demonstrativa(
			$conteudo,
			(bool) F3Base_Imp_Config::obter( 'conteudo.demonstrativo', false ),
			(string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' ),
			'content/posts/' . $slug . '.html'
		);

		if ( '' !== $divergencia ) {
			return self::saida( 'FALHA', 'conteudo.post:' . $slug, $divergencia );
		}

		$conteudo = self::injetar_ids_de_anexo( $conteudo );
		$conteudo = self::interpolar_configuracao( $conteudo );

		$desejado = array(
			'post_title'   => (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.titulo', '' ),
			'post_name'    => $slug,
			'post_status'  => (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.status', 'draft' ),
			'post_content' => $conteudo,
			'post_excerpt' => (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.seo.descricao', '' ),
			'post_parent'  => 0,
		);

		$resultado = self::aplicar_objeto( 'post', $slug, $desejado, false, $indice );

		if ( 'OK' === $resultado['estado'] && $resultado['id'] > 0 ) {
			$categoria = (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.categoria', '' );

			if ( '' !== $categoria ) {
				self::vincular_categoria( $resultado['id'], $categoria );
			}

			F3Base_Imp_Seo::gravar_por_conteudo(
				$resultado['id'],
				array(
					'titulo'      => (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.seo.titulo', '' ),
					'descricao'   => (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.seo.descricao', '' ),
					'frase_chave' => (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.seo.frase_chave', '' ),
					'indexar'     => (bool) F3Base_Imp_Config::obter( 'posts.' . $indice . '.seo.indexar', true ),
					'cornerstone' => false,
				)
			);
		}

		return $resultado;
	}

	/**
	 * Aplica uma categoria declarada.
	 *
	 * Categoria vazia não se cria: o termo nasce junto com o primeiro post que o
	 * declara. Aqui só se garantem nome e descrição do termo já existente ou
	 * necessário pela lista de posts.
	 *
	 * @param int $indice Índice em `categorias`.
	 * @return array<string,mixed>
	 */
	public static function aplicar_categoria( int $indice ): array {
		$slug = (string) F3Base_Imp_Config::obter( 'categorias.' . $indice . '.slug', '' );
		$nome = (string) F3Base_Imp_Config::obter( 'categorias.' . $indice . '.nome', '' );
		$desc = (string) F3Base_Imp_Config::obter( 'categorias.' . $indice . '.descricao', '' );

		if ( '' === $slug || '' === $nome ) {
			return self::saida( 'BLOCKED', 'conteudo.categoria', __( 'entrada de categoria sem slug ou nome declarado.', 'f3base' ) );
		}

		$usada = false;

		foreach ( F3Base_Imp_Config::lista( 'posts' ) as $posicao => $entrada ) {
			unset( $entrada );

			if ( $slug === (string) F3Base_Imp_Config::obter( 'posts.' . $posicao . '.categoria', '' ) ) {
				$usada = true;
				break;
			}
		}

		if ( ! $usada ) {
			return self::saida(
				'N/A',
				'conteudo.categoria:' . $slug,
				__( 'condição de aplicabilidade falsa: nenhum post declarado usa esta categoria, e categoria vazia não se cria.', 'f3base' )
			);
		}

		$termo = get_term_by( 'slug', $slug, 'category' );

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				'conteudo.categoria:' . $slug,
				$termo instanceof WP_Term
					? __( 'modo simulação: garantiria nome e descrição do termo existente.', 'f3base' )
					: __( 'modo simulação: criaria o termo.', 'f3base' )
			);
		}

		if ( ! $termo instanceof WP_Term ) {
			$criado = wp_insert_term( $nome, 'category', array( 'slug' => $slug, 'description' => $desc ) );

			if ( is_wp_error( $criado ) ) {
				return self::saida( 'FALHA', 'conteudo.categoria:' . $slug, $criado->get_error_message() );
			}

			$id = (int) $criado['term_id'];

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_TERMO,
				'category:' . $slug,
				null,
				array( 'nome' => $nome ),
				array(
					'acao'      => 'termo.excluir',
					'id'        => $id,
					'taxonomia' => 'category',
				)
			);

			$lido = get_term( $id, 'category' );

			return self::saida(
				$lido instanceof WP_Term ? 'OK' : 'FALHA',
				'conteudo.categoria:' . $slug,
				$lido instanceof WP_Term
					? __( 'termo criado e conferido na leitura de volta.', 'f3base' )
					: __( 'o termo não foi encontrado na leitura de volta.', 'f3base' ),
				$id
			);
		}

		if ( $termo->name === $nome && $termo->description === $desc ) {
			return self::saida( 'OK', 'conteudo.categoria:' . $slug, __( 'termo já com nome e descrição desejados: nenhuma gravação executada.', 'f3base' ), $termo->term_id );
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_TERMO,
			'category:' . $slug,
			array(
				'name'        => $termo->name,
				'description' => $termo->description,
			),
			array(
				'name'        => $nome,
				'description' => $desc,
			),
			array(
				'acao'      => 'termo.restaurar',
				'id'        => $termo->term_id,
				'taxonomia' => 'category',
				'campos'    => array(
					'name'        => $termo->name,
					'description' => $termo->description,
				),
			)
		);

		$atualizado = wp_update_term( $termo->term_id, 'category', array( 'name' => $nome, 'description' => $desc ) );

		if ( is_wp_error( $atualizado ) ) {
			return self::saida( 'FALHA', 'conteudo.categoria:' . $slug, $atualizado->get_error_message(), $termo->term_id );
		}

		$lido     = get_term( $termo->term_id, 'category' );
		$conferiu = $lido instanceof WP_Term && $lido->name === $nome && $lido->description === $desc;

		return self::saida(
			$conferiu ? 'OK' : 'FALHA',
			'conteudo.categoria:' . $slug,
			$conferiu ? __( 'termo atualizado e conferido na leitura de volta.', 'f3base' ) : __( 'leitura de volta do termo divergiu.', 'f3base' ),
			$termo->term_id
		);
	}

	/**
	 * Importa um item de mídia declarado, por sideload local.
	 *
	 * Troca de ativo é caso de primeira classe: o novo entra ANTES de o antigo
	 * sair, e a referência é repontada. Falhando o sideload, o site continua com
	 * a versão anterior.
	 *
	 * O papel `marca_inline` é a exceção declarada: aquele arquivo NÃO vai para a
	 * biblioteca. O caso medido foi `assets/logo.svg` — o WordPress recusa SVG na
	 * biblioteca por padrão ("Sem permissão para enviar esse tipo de arquivo"), a
	 * recusa está certa (SVG é vetor de XSS) e habilitar o MIME no site seria
	 * decisão de segurança que este pacote não toma. O papel `custom_logo`, que
	 * exige anexo, ficou com o raster; o vetor continua no pacote para o tema
	 * servir no próprio markup. A unidade fecha N/A com a condição declarada,
	 * nunca some.
	 *
	 * @param int $indice Índice em `midia`.
	 * @return array<string,mixed>
	 */
	public static function aplicar_midia( int $indice ): array {
		$ref     = (string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.ref', '' );
		$arquivo = (string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.arquivo', '' );
		$papel   = (string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.papel', '' );
		$alt     = (string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.alt', '' );

		if ( '' === $ref || '' === $arquivo ) {
			return self::saida( 'BLOCKED', 'conteudo.midia', __( 'entrada de mídia sem referência ou sem arquivo declarado.', 'f3base' ) );
		}

		$origem = f3base_imp_caminho( $arquivo );

		if ( '' === $origem || ! is_readable( $origem ) ) {
			return self::saida(
				'BLOCKED',
				'conteudo.midia:' . $ref,
				sprintf(
					/* translators: %s: caminho relativo do arquivo de mídia. */
					__( 'binário ausente no pacote: %s. Sideload é local: nenhuma chamada de rede externa substitui o arquivo.', 'f3base' ),
					$arquivo
				)
			);
		}

		if ( self::PAPEL_INLINE === $papel ) {
			return self::saida(
				'N/A',
				'conteudo.midia:' . $ref,
				sprintf(
					/* translators: 1: caminho relativo do arquivo, 2: nome do papel declarado. */
					__( 'condição de aplicabilidade falsa: %1$s tem o papel %2$s e por isso NÃO passa pela biblioteca de mídia — o tema o serve no próprio markup, a partir do arquivo do pacote. O binário foi conferido no disco e continua viajando; nenhum tipo de arquivo novo foi habilitado no site.', 'f3base' ),
					$arquivo,
					$papel
				)
			);
		}

		$hash_novo = hash_file( 'sha256', $origem );
		$atual     = self::localizar_gerenciado( 'attachment', 'midia:' . $ref );

		if ( $atual > 0 ) {
			$hash_atual = (string) get_post_meta( $atual, '_f3base_midia_sha256', true );
			$caminho    = get_attached_file( $atual );
			$no_disco   = is_string( $caminho ) && file_exists( $caminho );

			if ( $hash_atual === $hash_novo && $no_disco ) {
				self::aplicar_papel_midia( $papel, $atual );

				/*
				 * O binário não mudou, e mesmo assim o SLUG é reconciliado: o
				 * anexo desta instalação nasceu com o slug derivado do `alt`
				 * (medido: `metodo-f3`), e é ele que tira o slug da página
				 * declarada. Reimportar o arquivo para corrigir um nome seria
				 * trocar um artefato que está certo; renomear é o que basta.
				 */
				$slug_anexo = self::conciliar_slug_de_anexo( $atual, $ref );

				return self::saida(
					$slug_anexo['estado'],
					'conteudo.midia:' . $ref,
					sprintf(
						/* translators: %s: resultado da conciliação do slug. */
						__( 'anexo gerenciado já corresponde ao arquivo do pacote: nenhuma importação executada. %s', 'f3base' ),
						$slug_anexo['motivo']
					),
					$atual
				);
			}

			if ( $hash_atual === $hash_novo && ! $no_disco ) {
				/* Registro dizendo "feito" com o artefato ausente: AVISO, nunca cura silenciosa. */
				self::aviso( sprintf(
					/* translators: %s: referência lógica da mídia. */
					__( 'divergência entre registro e artefato na mídia %s: o hash gravado batia, mas o arquivo não estava no disco. A importação foi refeita.', 'f3base' ),
					$ref
				) );
			}
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida( 'N/A', 'conteudo.midia:' . $ref, __( 'modo simulação: importaria o binário por sideload local e repontaria a referência.', 'f3base' ) );
		}

		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$temporario = wp_tempnam( basename( $origem ) );

		if ( ! is_string( $temporario ) || '' === $temporario ) {
			return self::saida( 'FALHA', 'conteudo.midia:' . $ref, __( 'não foi possível criar o arquivo temporário do sideload.', 'f3base' ) );
		}

		if ( ! copy( $origem, $temporario ) ) {
			wp_delete_file( $temporario );

			return self::saida( 'FALHA', 'conteudo.midia:' . $ref, __( 'falha ao copiar o binário do pacote para o temporário.', 'f3base' ) );
		}

		/*
		 * `post_name` vai declarado no sideload, e não deduzido do título: o
		 * quarto argumento de `media_handle_sideload()` é mesclado nos campos do
		 * anexo antes do `wp_insert_attachment()`. Sem ele, o anexo herda o slug
		 * do `alt` — e três entradas com o mesmo `alt` produzem `metodo-f3`,
		 * `metodo-f3-2` e `metodo-f3-3`, uma delas tirando o slug da home.
		 */
		$slug_gerenciado = self::slug_de_anexo_gerenciado( $ref );

		/*
		 * O SLUG GERENCIADO PRECISA ESTAR LIVRE ANTES DO SIDELOAD, e quem o
		 * ocupa nesta hora é a versão ANTERIOR deste mesmo item de mídia. Sem
		 * este passo, a troca de um binário faria o núcleo gravar
		 * `f3base-logo-2` no anexo novo e a leitura de volta reprovaria — o
		 * mesmo defeito de sempre, agora com o nosso próprio slug.
		 *
		 * Renomear o anterior não é o anterior SAIR: o arquivo, o post e as
		 * metas continuam onde estavam, e o slug velho fica gravado em
		 * `_f3base_old_slug` para o site-core redirecionar. Se o sideload falhar
		 * depois disto, o site continua com a versão anterior — só que sob outro
		 * slug, e o relatório diz qual.
		 */
		$liberacao = self::liberar_slug_de_anexo( $atual, $slug_gerenciado );

		$novo = media_handle_sideload(
			array(
				'name'     => basename( $origem ),
				'tmp_name' => $temporario,
			),
			0,
			$alt,
			'' !== $slug_gerenciado ? array( 'post_name' => $slug_gerenciado ) : array()
		);

		if ( is_wp_error( $novo ) ) {
			if ( file_exists( $temporario ) ) {
				wp_delete_file( $temporario );
			}

			return self::saida( 'FALHA', 'conteudo.midia:' . $ref, $novo->get_error_message() );
		}

		$novo = (int) $novo;

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_MIDIA_REF,
			'midia:' . $ref,
			$atual > 0 ? array( 'id' => $atual ) : null,
			array( 'id' => $novo ),
			array(
				'acao' => 'post.excluir',
				'id'   => $novo,
			)
		);

		F3Base_Imp_Gravador::gravar_meta( 'post', $novo, self::META_ID, self::identidade( 'attachment', 'midia:' . $ref ) );
		F3Base_Imp_Gravador::gravar_meta( 'post', $novo, self::META_VERSAO, (string) F3Base_Imp_Config::obter( 'release.identidade', '' ) );
		F3Base_Imp_Gravador::gravar_meta( 'post', $novo, '_f3base_midia_sha256', (string) $hash_novo );
		F3Base_Imp_Gravador::gravar_meta( 'post', $novo, '_wp_attachment_image_alt', $alt );

		self::aplicar_papel_midia( $papel, $novo );

		if ( $atual > 0 ) {
			/*
			 * O antigo só sai com propriedade exclusiva comprovada. Sem essa
			 * prova, ele fica marcado como obsoleto e é relatado — remover
			 * anexo usado em conteúdo não gerenciado é perda sem registro.
			 */
			F3Base_Imp_Gravador::gravar_meta( 'post', $atual, self::META_ID, self::identidade( 'attachment', 'midia:' . $ref . ':obsoleto' ) );
			F3Base_Imp_Gravador::gravar_meta( 'post', $atual, '_f3base_obsoleto_em', (string) time() );
		}

		$lido = get_post( $novo );

		if ( ! $lido instanceof WP_Post ) {
			return self::saida( 'FALHA', 'conteudo.midia:' . $ref, __( 'o anexo não foi encontrado na leitura de volta.', 'f3base' ), $novo );
		}

		if ( '' !== $slug_gerenciado && (string) $lido->post_name !== $slug_gerenciado ) {
			return self::saida(
				'FALHA',
				'conteudo.midia:' . $ref,
				sprintf(
					/* translators: 1: slug gerenciado pedido, 2: diagnóstico do ocupante. */
					__( 'o anexo foi importado, e o slug gerenciado %1$s NÃO conferiu na leitura de volta. %2$s', 'f3base' ),
					$slug_gerenciado,
					self::diagnostico_de_slug( 'attachment', $slug_gerenciado, (string) $lido->post_name, $novo )
				),
				$novo
			);
		}

		return self::saida(
			'OK',
			'conteudo.midia:' . $ref,
			sprintf(
				/* translators: 1: slug gerenciado conferido, 2: texto alternativo declarado, 3: liberação do slug anterior. */
				__( 'binário importado por sideload local e referência repontada. Slug gerenciado %1$s, derivado da referência lógica e conferido na leitura de volta — o alt (%2$s) segue sendo acessibilidade e alimentando o título, e nunca a origem do slug. %3$s', 'f3base' ),
				'' !== $slug_gerenciado ? $slug_gerenciado : __( 'não gerado: site.prefixo_tecnico vazio', 'f3base' ),
				'' !== $alt ? $alt : __( 'vazio, imagem decorativa', 'f3base' ),
				$liberacao
			),
			$novo
		);
	}

	/**
	 * Libera o slug gerenciado ocupado pela versão ANTERIOR do mesmo item.
	 *
	 * Emite nos DOIS ramos: nada a liberar, ou liberado com o slug antigo
	 * gravado para o redirecionamento.
	 *
	 * @param int    $atual Anexo gerenciado anterior, ou 0.
	 * @param string $slug  Slug gerenciado desejado.
	 * @return string Frase para a mensagem da unidade, sempre presente.
	 */
	private static function liberar_slug_de_anexo( int $atual, string $slug ): string {
		if ( $atual <= 0 || '' === $slug ) {
			return __( 'Slug gerenciado estava livre: não há versão anterior deste item ocupando-o.', 'f3base' );
		}

		$anterior = get_post( $atual );

		if ( ! $anterior instanceof WP_Post || (string) $anterior->post_name !== $slug ) {
			return sprintf(
				/* translators: 1: id do anexo anterior, 2: slug observado nele. */
				__( 'Slug gerenciado estava livre: o anexo anterior #%1$d está com o slug %2$s e não o disputa.', 'f3base' ),
				$atual,
				$anterior instanceof WP_Post && '' !== (string) $anterior->post_name ? (string) $anterior->post_name : __( 'vazio', 'f3base' )
			);
		}

		$aposentado = $slug . '-obsoleto-' . time();

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_POST,
			'conteudo.midia.anterior#' . $atual,
			array( 'post_name' => $slug ),
			array( 'post_name' => $aposentado ),
			array(
				'acao'   => 'post.restaurar',
				'id'     => $atual,
				'campos' => array( 'post_name' => $slug ),
			)
		);

		wp_update_post(
			wp_slash(
				array(
					'ID'            => $atual,
					'post_name'     => $aposentado,
					'post_date'     => $anterior->post_date,
					'post_date_gmt' => $anterior->post_date_gmt,
				)
			)
		);

		$relido = get_post( $atual );
		$agora  = $relido instanceof WP_Post ? (string) $relido->post_name : '';

		if ( $agora !== $aposentado ) {
			return sprintf(
				/* translators: 1: id do anexo anterior, 2: slug gerenciado, 3: slug relido. */
				__( 'Slug gerenciado NÃO foi liberado: o anexo anterior #%1$d continua com %2$s na leitura de volta (relido: %3$s), e o núcleo vai desambiguar o novo.', 'f3base' ),
				$atual,
				$slug,
				'' !== $agora ? $agora : __( 'vazio', 'f3base' )
			);
		}

		$registro = self::registrar_slug_anterior( $atual, $slug, $aposentado );

		return sprintf(
			/* translators: 1: id do anexo anterior, 2: slug aposentado, 3: resultado do registro do slug anterior. */
			__( 'Slug gerenciado liberado: o anexo anterior #%1$d passou a %2$s antes do sideload — o conteúdo dele não foi tocado. %3$s', 'f3base' ),
			$atual,
			$aposentado,
			$registro['motivo']
		);
	}

	/**
	 * Concilia o slug de um anexo gerenciado já existente com o determinístico.
	 *
	 * Emite nos DOIS ramos: já conforme, ou renomeado com o slug anterior
	 * gravado e conferido. Renomear anexo é troca de slug de objeto publicado
	 * como qualquer outra, e por isso passa pela mesma meta de redirecionamento.
	 *
	 * @param int    $id  ID do anexo.
	 * @param string $ref Referência lógica da entrada de `midia`.
	 * @return array{estado:string,motivo:string}
	 */
	private static function conciliar_slug_de_anexo( int $id, string $ref ): array {
		$desejado = self::slug_de_anexo_gerenciado( $ref );

		if ( '' === $desejado ) {
			return array(
				'estado' => 'OK',
				'motivo' => __( 'Slug gerenciado não conciliado: site.prefixo_tecnico está vazio e sem prefixo não há slug determinístico a derivar da referência lógica.', 'f3base' ),
			);
		}

		$post = get_post( $id );

		if ( ! $post instanceof WP_Post ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => __( 'Slug gerenciado não conciliado: o anexo registrado não existe mais no banco.', 'f3base' ),
			);
		}

		$observado = (string) $post->post_name;

		if ( $observado === $desejado ) {
			return array(
				'estado' => 'OK',
				'motivo' => sprintf(
					/* translators: %s: slug gerenciado. */
					__( 'Slug gerenciado já é %s: nenhuma gravação executada.', 'f3base' ),
					$desejado
				),
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return array(
				'estado' => 'N/A',
				'motivo' => sprintf(
					/* translators: 1: slug observado, 2: slug gerenciado. */
					__( 'modo simulação: renomearia o slug do anexo de %1$s para %2$s, gravando o anterior para o redirecionamento.', 'f3base' ),
					$observado,
					$desejado
				),
			);
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_POST,
			'conteudo.midia:' . $ref,
			array( 'post_name' => $observado ),
			array( 'post_name' => $desejado ),
			array(
				'acao'   => 'post.restaurar',
				'id'     => $id,
				'campos' => array( 'post_name' => $observado ),
			)
		);

		$atualizado = wp_update_post(
			wp_slash(
				array(
					'ID'            => $id,
					'post_name'     => $desejado,
					'post_date'     => $post->post_date,
					'post_date_gmt' => $post->post_date_gmt,
				)
			),
			true
		);

		if ( is_wp_error( $atualizado ) ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => sprintf(
					/* translators: %s: mensagem de erro. */
					__( 'Slug gerenciado não conciliado: %s', 'f3base' ),
					$atualizado->get_error_message()
				),
			);
		}

		$relido = get_post( $id );
		$agora  = $relido instanceof WP_Post ? (string) $relido->post_name : '';

		if ( $agora !== $desejado ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => sprintf(
					/* translators: 1: slug pedido, 2: diagnóstico do ocupante. */
					__( 'Slug gerenciado %1$s NÃO conferiu na leitura de volta. %2$s', 'f3base' ),
					$desejado,
					self::diagnostico_de_slug( 'attachment', $desejado, $agora, $id )
				),
			);
		}

		$anterior = self::registrar_slug_anterior( $id, $observado, $desejado );

		return array(
			'estado' => 'FALHA' === $anterior['estado'] ? 'FALHA' : 'OK',
			'motivo' => sprintf(
				/* translators: 1: slug observado, 2: slug gerenciado, 3: resultado do registro do slug anterior. */
				__( 'Slug do anexo renomeado de %1$s para %2$s e conferido na leitura de volta — anexo gerenciado recebe slug gerenciado, e não o derivado do alt. %3$s', 'f3base' ),
				$observado,
				$desejado,
				$anterior['motivo']
			),
		);
	}

	/**
	 * CENSO ÚNICO do conteúdo publicado, com a marca de gestão medida em cada um.
	 *
	 * Duas perguntas diferentes se apoiam nesta MESMA medição, e é por isso que
	 * ela mora num lugar só: `conteudo.nao_gerenciado_publicado` relata o que
	 * sobrou da instalação limpa, e a decisão de permalinks `aplicar-se-seguro`
	 * pergunta se existe URL de terceiro para quebrar. Duas varreduras
	 * independentes com o mesmo propósito é o terreno em que os dois vereditos
	 * divergem sobre o mesmo banco — o relatório afirmando, na mesma execução,
	 * que tudo é gerenciado numa linha e que não é em outra.
	 *
	 * @return array{medidos:int,tipos:array<int,string>,nao_gerenciados:array<int,array{id:int,tipo:string,slug:string,titulo:string}>}
	 */
	public static function censo_de_publicados(): array {
		$tipos = array( 'page', 'post' );

		$publicados = get_posts(
			array(
				'post_type'        => $tipos,
				'post_status'      => array( 'publish' ),
				'numberposts'      => 200,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'no_found_rows'    => true,
				'suppress_filters' => false,
			)
		);

		$nao_gerenciados = array();
		$medidos         = 0;

		foreach ( is_array( $publicados ) ? $publicados : array() as $item ) {
			if ( ! $item instanceof WP_Post ) {
				continue;
			}

			++$medidos;

			if ( '' !== (string) get_post_meta( (int) $item->ID, self::META_ID, true ) ) {
				continue;
			}

			$nao_gerenciados[] = array(
				'id'     => (int) $item->ID,
				'tipo'   => (string) $item->post_type,
				'slug'   => (string) $item->post_name,
				'titulo' => (string) $item->post_title,
			);
		}

		return array(
			'medidos'         => $medidos,
			'tipos'           => $tipos,
			'nao_gerenciados' => $nao_gerenciados,
		);
	}

	/**
	 * Nomeia um objeto do censo para o relatório: id, tipo, título e slug.
	 *
	 * @param array{id:int,tipo:string,slug:string,titulo:string} $item Item do censo.
	 * @return string
	 */
	public static function nomear_publicado( array $item ): string {
		return sprintf(
			/* translators: 1: ID, 2: post_type, 3: título, 4: slug. */
			__( '#%1$d %2$s "%3$s" (slug %4$s)', 'f3base' ),
			(int) $item['id'],
			(string) $item['tipo'],
			(string) $item['titulo'],
			(string) $item['slug']
		);
	}

	/**
	 * RELATA — nunca apaga — o conteúdo publicado que veio da instalação limpa.
	 *
	 * O que esta unidade mede é o conteúdo publicado SEM `_f3base_managed_id`,
	 * que não consta de `paginas` nem de `posts` e não entrou sob gestão por
	 * adoção declarada. Duas coisas, e as duas importam:
	 *
	 * - **Não se apaga AQUI.** Remover conteúdo publicado que o pacote não
	 *   gerencia, sem autorização, é perda sem registro — e o que parece exemplo
	 *   do núcleo pode ter virado página de verdade com link apontando para ela.
	 * - **Não se cala.** Até a 1.0.10 nem relatado era: o operador entregava um
	 *   site com uma página de exemplo publicada e ninguém dizia nada.
	 *
	 * A 1.0.17 abriu UMA porta, e ela é estreita por desenho: a etapa
	 * `conteudo.exemplo_do_wordpress` manda para a lixeira o que AINDA É o que
	 * `wp_install_defaults()` criou, provado por discriminante e nunca por slug.
	 * O que sobra aqui é tudo o que aquela etapa não tocou — incluindo o objeto
	 * que ocupa o slug de exemplo e deixou de ser exemplo —, e continua sendo
	 * decisão do PROJETO. Dizer que ela existe é obrigação do implantador.
	 *
	 * WARN, nunca FALHA: o site não está defeituoso, está com uma decisão em
	 * aberto.
	 *
	 * @return array<string,mixed>
	 */
	public static function relatar_nao_gerenciado(): array {
		$rotulo = 'conteudo.nao_gerenciado_publicado';
		$censo  = self::censo_de_publicados();
		$tipos  = $censo['tipos'];

		$nao_gerenciados = array_map( array( __CLASS__, 'nomear_publicado' ), $censo['nao_gerenciados'] );
		$medidos         = $censo['medidos'];

		if ( 0 === $medidos ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: %s: tipos consultados. */
					__( 'pré-condição ausente: nenhum conteúdo publicado foi lido em %s, e escopo vazio não aprova — o que não foi medido não pode ser declarado limpo.', 'f3base' ),
					implode( ', ', $tipos )
				)
			);
		}

		if ( array() === $nao_gerenciados ) {
			return self::saida(
				'OK',
				$rotulo,
				sprintf(
					/* translators: 1: quantidade medida, 2: tipos consultados. */
					__( 'os %1$d conteúdos publicados em %2$s têm meta de gestão deste pacote: nenhum publicado não gerenciado sobrou da instalação limpa.', 'f3base' ),
					$medidos,
					implode( ', ', $tipos )
				)
			);
		}

		return self::saida(
			'WARN',
			$rotulo,
			sprintf(
				/* translators: 1: quantidade, 2: itens nomeados, 3: quantidade medida. */
				__( 'conteúdo PUBLICADO e NÃO gerenciado por este pacote, herdado da instalação limpa — %1$d de %3$d publicados: %2$s. Ele NÃO foi tocado por ESTA unidade: este pacote não o gerencia e não o apaga sem autorização, porque remover conteúdo publicado alheio é perda sem registro. O conteúdo de exemplo INTOCADO do WordPress é a única exceção, e ela tem etapa própria e discriminante próprio — conteudo.exemplo_do_wordpress —, que não decide por slug e nunca toca no objeto que alguém editou. Para o resto, a remoção é decisão do PROJETO, não do implantador: quem decide apaga pelo wp-admin ou declara o objeto na configuração para trazê-lo para a gestão.', 'f3base' ),
				count( $nao_gerenciados ),
				implode( '; ', $nao_gerenciados ),
				$medidos
			)
		);
	}


	/**
	 * As decisões aceitas em `conteudo.exemplo_do_wordpress`.
	 *
	 * @return array<int,string>
	 */
	public static function decisoes_de_exemplo(): array {
		return array( self::EXEMPLO_LIXEIRA, self::EXEMPLO_MANTER );
	}

	/**
	 * O que `wp_install_defaults()` produz, MEDIDO no núcleo desta instalação.
	 *
	 * `Hello world!` e `Sample Page` não são conteúdo de ninguém: são o que
	 * `wp-admin/includes/upgrade.php`, na função `wp_install_defaults()`, insere
	 * em toda instalação. Este catálogo REPRODUZ aquelas inserções chamando as
	 * MESMAS funções de tradução do núcleo com os MESMOS msgids — é assim que se
	 * pergunta ao WordPress instalado o que ele mesmo escreveria, em vez de
	 * inventar um texto e chamá-lo de esperado. Num site em pt_BR o catálogo sai
	 * em pt_BR, porque o catálogo do núcleo é o mesmo dos dois lados.
	 *
	 * O que acontece quando o núcleo muda o texto numa versão futura: o esperado
	 * deixa de casar, nenhum objeto é reconhecido como intocado e NADA é
	 * removido — o lado seguro. A divergência sai nomeada no relatório, e é o
	 * operador quem decide.
	 *
	 * O slug entra como ÍNDICE da hipótese, nunca como prova: é ele que diz qual
	 * entrada do catálogo comparar, e quem decide é a comparação de título,
	 * conteúdo e tempo. Slug igual não prova nada — a mesma regra que governa a
	 * adoção de objeto.
	 *
	 * AS CHAMADAS DE TRADUÇÃO AQUI VÃO SEM TEXT DOMAIN, DE PROPÓSITO, e são as
	 * únicas do pacote que vão. Domínio ausente é o domínio do NÚCLEO, e é
	 * exatamente o que se quer: o texto que se busca é o do WordPress, não o
	 * deste pacote. Escrever `'f3base'` aqui pediria a tradução ao catálogo
	 * errado e devolveria o msgid em inglês num site em pt_BR — o esperado
	 * deixaria de casar e a etapa nunca reconheceria nada.
	 *
	 * @return array<int,array{papel:string,tipo:string,slug:string,titulo:string,conteudo:string}>
	 */
	public static function amostra_do_wordpress(): array {
		/*
		 * O primeiro post. Fonte: wp_install_defaults(), ramo de site único —
		 * o ramo multisite compõe o parágrafo com o nome da rede e não é o que
		 * este pacote encontra numa instalação comum.
		 */
		$primeiro_post = "<!-- wp:paragraph -->\n<p>" .
			__( 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!' ) .
			"</p>\n<!-- /wp:paragraph -->";

		/* A página de exemplo, montada segmento a segmento como o núcleo monta. */
		$primeira_pagina  = "<!-- wp:paragraph -->\n<p>";
		$primeira_pagina .= __( "This is an example page. It's different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:" );
		$primeira_pagina .= "</p>\n<!-- /wp:paragraph -->\n\n";

		$primeira_pagina .= "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">\n<!-- wp:paragraph -->\n<p>";
		$primeira_pagina .= __( "Hi there! I'm a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin' caught in the rain.)" );
		$primeira_pagina .= "</p>\n<!-- /wp:paragraph -->\n</blockquote>\n<!-- /wp:quote -->\n\n";

		$primeira_pagina .= "<!-- wp:paragraph -->\n<p>";
		$primeira_pagina .= __( '...or something like this:' );
		$primeira_pagina .= "</p>\n<!-- /wp:paragraph -->\n\n";

		$primeira_pagina .= "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">\n<!-- wp:paragraph -->\n<p>";
		$primeira_pagina .= __( 'The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.' );
		$primeira_pagina .= "</p>\n<!-- /wp:paragraph -->\n</blockquote>\n<!-- /wp:quote -->\n\n";

		$primeira_pagina .= "<!-- wp:paragraph -->\n<p>";
		$primeira_pagina .= sprintf(
			/* translators: %s: URL do painel, como o núcleo a interpola. */
			__( 'As a new WordPress user, you should go to <a href="%s">your dashboard</a> to delete this page and create new pages for your content. Have fun!' ),
			admin_url()
		);
		$primeira_pagina .= "</p>\n<!-- /wp:paragraph -->";

		return array(
			array(
				'papel'    => self::EXEMPLO_PRIMEIRO_POST,
				'tipo'     => 'post',
				'slug'     => sanitize_title( _x( 'hello-world', 'Default post slug' ) ),
				'titulo'   => __( 'Hello world!' ),
				'conteudo' => $primeiro_post,
			),
			array(
				'papel'    => self::EXEMPLO_PAGINA_EXEMPLO,
				'tipo'     => 'page',
				'slug'     => __( 'sample-page' ),
				'titulo'   => __( 'Sample Page' ),
				'conteudo' => $primeira_pagina,
			),
		);
	}

	/**
	 * A entrada do catálogo que um objeto observado PODE ser. FUNÇÃO PURA.
	 *
	 * Casa por tipo e slug, que é a hipótese; a prova vem depois. Devolve array
	 * vazio quando o objeto não é nenhum dos que `wp_install_defaults()` cria —
	 * e aí ele é conteúdo de alguém, nunca exemplo.
	 *
	 * @param array<int,array<string,string>> $amostra   Catálogo do núcleo.
	 * @param string                          $tipo      post_type observado.
	 * @param string                          $slug      post_name observado.
	 * @return array<string,string> Entrada do catálogo, ou vazio.
	 */
	public static function entrada_da_amostra( array $amostra, string $tipo, string $slug ): array {
		foreach ( $amostra as $entrada ) {
			if ( (string) ( $entrada['tipo'] ?? '' ) === $tipo && (string) ( $entrada['slug'] ?? '' ) === $slug && '' !== $slug ) {
				return $entrada;
			}
		}

		return array();
	}

	/**
	 * A REGRA do conteúdo de exemplo do WordPress, pura: decide e NOMEIA por quê.
	 *
	 * A orientação que criou esta regra: o implantador deve realizar todas as
	 * modificações necessárias para fazer a página funcionar, alterando conteúdo
	 * preexistente se preciso. Deixar `Sample Page` publicada num site entregue
	 * a põe no sitemap, na seleção do `llms.txt` e na busca — ela não é conteúdo
	 * de ninguém, é resíduo de instalação.
	 *
	 * O que decide NÃO é o slug. O objeto só é conteúdo de exemplo se AINDA FOR
	 * o que o WordPress criou, e isso são duas provas conjuntas:
	 *
	 * 1. **Identidade** contra o que `wp_install_defaults()` produz — título E
	 *    conteúdo idênticos ao que o núcleo escreveria agora.
	 * 2. **Ninguém editou** — `post_modified_gmt` igual a `post_date_gmt`, que é
	 *    como o instalador os grava e o que qualquer edição faz avançar.
	 *
	 * Quem reescreveu o `Hello world!` para publicar um texto de verdade deixou
	 * de ter conteúdo de exemplo, e esse objeto é INTOCÁVEL. O mesmo vale para o
	 * objeto que este pacote gerencia e para o que o site pôs em uso como página
	 * inicial, página de posts ou política de privacidade: em nenhum desses
	 * casos o objeto é resíduo.
	 *
	 * O DISCRIMINANTE volta junto com a ação porque é ele que vai impresso no
	 * relatório: dizer que removeu não basta — o operador precisa saber o que
	 * decidiu, e quem foi preservado precisa saber por qual divergência.
	 *
	 * @param array<string,string> $esperado  Entrada do catálogo do núcleo, ou vazio.
	 * @param array<string,mixed>  $observado Objeto medido: tipo, slug, titulo, conteudo, post_date_gmt, post_modified_gmt, gerenciado, em_uso.
	 * @return array{acao:string,discriminante:string,motivo:string}
	 */
	public static function veredito_de_exemplo_do_wordpress( array $esperado, array $observado ): array {
		if ( (bool) ( $observado['gerenciado'] ?? false ) ) {
			return self::veredito_de_exemplo(
				self::ACAO_EXEMPLO_MANTER,
				__( 'gerenciado por este pacote', 'f3base' ),
				__( 'o objeto tem a meta de gestão deste pacote: ele é conteúdo declarado, e conteúdo declarado nunca é resíduo de instalação.', 'f3base' )
			);
		}

		if ( array() === $esperado ) {
			return self::veredito_de_exemplo(
				self::ACAO_EXEMPLO_MANTER,
				__( 'fora do que wp_install_defaults() cria', 'f3base' ),
				__( 'o par tipo/slug observado não é nenhum dos objetos que wp_install_defaults() insere: o objeto é conteúdo de alguém, e este pacote não o toca.', 'f3base' )
			);
		}

		$em_uso = (string) ( $observado['em_uso'] ?? '' );

		if ( '' !== $em_uso ) {
			return self::veredito_de_exemplo(
				self::ACAO_EXEMPLO_MANTER,
				sprintf(
					/* translators: %s: option do WordPress que aponta para o objeto. */
					__( 'em uso: apontado por %s', 'f3base' ),
					$em_uso
				),
				sprintf(
					/* translators: %s: option do WordPress que aponta para o objeto. */
					__( 'o objeto está EM USO — a option %s aponta para ele —, e um objeto em uso não é resíduo de instalação, mesmo que o texto dele nunca tenha sido tocado.', 'f3base' ),
					$em_uso
				)
			);
		}

		$divergencias = array();

		if ( (string) ( $observado['titulo'] ?? '' ) !== (string) ( $esperado['titulo'] ?? '' ) ) {
			$divergencias[] = __( 'título editado', 'f3base' );
		}

		if ( (string) ( $observado['conteudo'] ?? '' ) !== (string) ( $esperado['conteudo'] ?? '' ) ) {
			$divergencias[] = __( 'conteúdo editado', 'f3base' );
		}

		if ( (string) ( $observado['post_modified_gmt'] ?? '' ) !== (string) ( $observado['post_date_gmt'] ?? '' ) ) {
			$divergencias[] = __( 'post_modified_gmt avançou em relação a post_date_gmt', 'f3base' );
		}

		if ( array() !== $divergencias ) {
			return self::veredito_de_exemplo(
				self::ACAO_EXEMPLO_MANTER,
				implode( '; ', $divergencias ),
				sprintf(
					/* translators: %s: divergências medidas. */
					__( 'o objeto ocupa o tipo e o slug de um conteúdo de exemplo, mas NÃO é mais o que o WordPress criou — %s. Quem editou publicou conteúdo de verdade ali, e este objeto é INTOCÁVEL: nada foi removido.', 'f3base' ),
					implode( '; ', $divergencias )
				)
			);
		}

		return self::veredito_de_exemplo(
			self::ACAO_EXEMPLO_LIXEIRA,
			sprintf(
				/* translators: %s: papel do objeto no catálogo do núcleo. */
				__( 'intocado desde a instalação: título e conteúdo idênticos ao que wp_install_defaults() escreve para %s, e post_modified_gmt igual a post_date_gmt', 'f3base' ),
				(string) ( $esperado['papel'] ?? '' )
			),
			__( 'o objeto AINDA É o que o WordPress criou: título e conteúdo batem com o que wp_install_defaults() escreveria agora, e post_modified_gmt não avançou em relação a post_date_gmt, que é como o instalador os grava e o que qualquer edição faria mudar. Vai para a LIXEIRA — reversível, com um clique em Restaurar —, e não para exclusão definitiva.', 'f3base' )
		);
	}

	/**
	 * Monta o veredito do conteúdo de exemplo.
	 *
	 * @param string $acao          Ação decidida.
	 * @param string $discriminante O que DECIDIU, para o relatório.
	 * @param string $motivo        Frase completa.
	 * @return array{acao:string,discriminante:string,motivo:string}
	 */
	private static function veredito_de_exemplo( string $acao, string $discriminante, string $motivo ): array {
		return array(
			'acao'          => $acao,
			'discriminante' => $discriminante,
			'motivo'        => $motivo,
		);
	}

	/**
	 * A option do núcleo que aponta para este objeto, ou vazio.
	 *
	 * Lista fechada? Não: são as três options do NÚCLEO que dão papel a uma
	 * página, e elas não são declaração do projeto — são fato do WordPress, do
	 * mesmo tipo que `permalink_structure`. O que a configuração declara é se a
	 * etapa roda, e isso mora em `conteudo.exemplo_do_wordpress`.
	 *
	 * @param int $id ID do objeto.
	 * @return string Nome da option, ou vazio.
	 */
	private static function option_que_usa( int $id ): string {
		foreach ( array( 'page_on_front', 'page_for_posts', 'wp_page_for_privacy_policy' ) as $option ) {
			if ( $id > 0 && (int) get_option( $option, 0 ) === $id ) {
				return $option;
			}
		}

		return '';
	}

	/**
	 * Manda para a LIXEIRA o conteúdo de exemplo INTOCADO do WordPress.
	 *
	 * Lixeira, nunca exclusão definitiva: a remoção é reversível pelo wp-admin,
	 * fica registrada no journal com a operação inversa e não perde nada. O
	 * relatório NOMEIA cada objeto e imprime o DISCRIMINANTE que decidiu — dizer
	 * que removeu não basta.
	 *
	 * A etapa roda ANTES da troca de estrutura de permalinks, e a ordem é
	 * decisão: o que sai daqui deixa de ser publicado, some da medição de URLs
	 * de terceiro e não ganha redirect para um endereço que passaria a 404. O
	 * que FICA — o objeto editado, intocável — continua publicado e é coberto
	 * pelo 301 se o caminho dele mudar.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_exemplo_do_wordpress(): array {
		$rotulo  = 'conteudo.exemplo_do_wordpress';
		$decisao = (string) F3Base_Imp_Config::obter( 'conteudo.exemplo_do_wordpress', self::EXEMPLO_LIXEIRA );

		if ( ! in_array( $decisao, self::decisoes_de_exemplo(), true ) ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: 1: valor declarado, 2: valores aceitos. */
					__( 'pré-condição ausente: conteudo.exemplo_do_wordpress declara "%1$s", que não é nenhum dos valores aceitos (%2$s). Nada foi tocado — valor não reconhecido não pode virar remoção silenciosa nem preservação silenciosa.', 'f3base' ),
					$decisao,
					implode( ', ', self::decisoes_de_exemplo() )
				)
			);
		}

		if ( self::EXEMPLO_MANTER === $decisao ) {
			return self::saida(
				'N/A',
				$rotulo,
				__( 'condição declarada: conteudo.exemplo_do_wordpress = "manter". O conteúdo de exemplo do WordPress fica publicado por decisão do projeto, e continua sendo relatado por conteudo.nao_gerenciado_publicado.', 'f3base' )
			);
		}

		$censo   = self::censo_de_publicados();
		$amostra = self::amostra_do_wordpress();

		$para_lixeira = array();
		$preservados  = array();
		$falhas       = array();

		foreach ( $censo['nao_gerenciados'] as $item ) {
			$id   = (int) $item['id'];
			$post = get_post( $id );

			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			$esperado = self::entrada_da_amostra( $amostra, (string) $post->post_type, (string) $post->post_name );

			if ( array() === $esperado ) {
				continue;
			}

			/*
			 * `gerenciado` é relido do objeto, e não herdado do censo — que já
			 * filtrou os gerenciados. É medição redundante DE PROPÓSITO: a regra
			 * é pública e o ramo que ela protege é o mais caro de todos, então
			 * ele não pode depender de um filtro feito noutro lugar.
			 */
			$veredito = self::veredito_de_exemplo_do_wordpress(
				$esperado,
				array(
					'tipo'              => (string) $post->post_type,
					'slug'              => (string) $post->post_name,
					'titulo'            => (string) $post->post_title,
					'conteudo'          => (string) $post->post_content,
					'post_date_gmt'     => (string) $post->post_date_gmt,
					'post_modified_gmt' => (string) $post->post_modified_gmt,
					'gerenciado'        => '' !== (string) get_post_meta( $id, self::META_ID, true ),
					'em_uso'            => self::option_que_usa( $id ),
				)
			);

			$nome = self::nomear_publicado( $item );

			if ( self::ACAO_EXEMPLO_LIXEIRA !== $veredito['acao'] ) {
				$preservados[] = sprintf(
					/* translators: 1: objeto nomeado, 2: discriminante que decidiu. */
					__( '%1$s PRESERVADO — discriminante: %2$s', 'f3base' ),
					$nome,
					$veredito['discriminante']
				);
				continue;
			}

			if ( F3Base_Imp_Gravador::em_simulacao() ) {
				$para_lixeira[] = sprintf(
					/* translators: 1: objeto nomeado, 2: discriminante que decidiu. */
					__( '%1$s iria para a lixeira — discriminante: %2$s', 'f3base' ),
					$nome,
					$veredito['discriminante']
				);
				continue;
			}

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_POST,
				$rotulo . ':' . $id,
				array( 'post_status' => (string) $post->post_status ),
				array( 'post_status' => 'trash' ),
				array(
					'acao'   => 'post.restaurar',
					'id'     => $id,
					'campos' => array( 'post_status' => (string) $post->post_status ),
				)
			);

			wp_trash_post( $id );

			$relido = get_post( $id );
			$agora  = $relido instanceof WP_Post ? (string) $relido->post_status : '';

			if ( 'trash' !== $agora ) {
				$falhas[] = sprintf(
					/* translators: 1: objeto nomeado, 2: status relido, 3: discriminante que decidiu. */
					__( '%1$s NÃO foi para a lixeira: a leitura de volta trouxe post_status "%2$s". Discriminante que havia decidido: %3$s', 'f3base' ),
					$nome,
					'' !== $agora ? $agora : __( 'objeto ausente', 'f3base' ),
					$veredito['discriminante']
				);
				continue;
			}

			$para_lixeira[] = sprintf(
				/* translators: 1: objeto nomeado, 2: discriminante que decidiu. */
				__( '%1$s foi para a LIXEIRA, com leitura de volta em post_status "trash" — discriminante: %2$s', 'f3base' ),
				$nome,
				$veredito['discriminante']
			);
		}

		$medido = sprintf(
			/* translators: 1: removidos ou a remover, nomeados; 2: preservados, nomeados. */
			__( 'Na lixeira: %1$s. Preservados: %2$s.', 'f3base' ),
			array() === $para_lixeira ? __( 'nenhum objeto', 'f3base' ) : implode( ' | ', $para_lixeira ),
			array() === $preservados ? __( 'nenhum objeto ocupa tipo e slug de exemplo sem ser exemplo', 'f3base' ) : implode( ' | ', $preservados )
		);

		if ( array() !== $falhas ) {
			return self::saida(
				'FALHA',
				$rotulo,
				sprintf(
					/* translators: 1: falhas nomeadas, 2: o que foi medido. */
					__( 'a remoção decidida NÃO pegou: %1$s. %2$s', 'f3base' ),
					implode( ' | ', $falhas ),
					$medido
				)
			);
		}

		return self::saida(
			F3Base_Imp_Gravador::em_simulacao() ? 'N/A' : 'OK',
			$rotulo,
			sprintf(
				/* translators: 1: o que foi medido, 2: total de publicados medidos. */
				__( 'conteúdo de exemplo do WordPress decidido por DISCRIMINANTE, nunca por slug: só vai para a lixeira o objeto que AINDA É o que wp_install_defaults() criou — título e conteúdo idênticos ao que o núcleo escreveria agora e post_modified_gmt sem avançar em relação a post_date_gmt. Objeto editado é intocável, e a lixeira é reversível. %1$s Publicados medidos nesta varredura: %2$d.', 'f3base' ),
				$medido,
				(int) $censo['medidos']
			)
		);
	}

	/**
	 * Injeta o ID do anexo nos blocos de imagem, em tempo de deploy.
	 *
	 * O ID muda por instalação e não pode viver no arquivo. Com ele no atributo
	 * do bloco e na classe `wp-image-N`, o core aplica `width`, `height`,
	 * `srcset` e a otimização de carregamento nativos. Sem ele, nada disso sai.
	 *
	 * @param string $html Conteúdo do arquivo.
	 * @return string Conteúdo com IDs resolvidos.
	 */
	public static function injetar_ids_de_anexo( string $html ): string {
		if ( ! str_contains( $html, 'wp:image' ) ) {
			return $html;
		}

		$substituido = preg_replace_callback(
			'#<!--\s*wp:image(\s+(\{.*?\}))?\s*-->(.*?)<!--\s*/wp:image\s*-->#s',
			static function ( array $casamento ): string {
				$atributos = array();

				if ( isset( $casamento[2] ) && '' !== $casamento[2] ) {
					$decodificado = json_decode( $casamento[2], true );
					$atributos    = is_array( $decodificado ) ? $decodificado : array();
				}

				$ref = isset( $atributos['f3baseRef'] ) ? (string) $atributos['f3baseRef'] : '';

				if ( '' === $ref ) {
					return $casamento[0];
				}

				$anexo = self::localizar_gerenciado( 'attachment', 'midia:' . $ref );

				if ( $anexo <= 0 ) {
					return $casamento[0];
				}

				$atributos['id'] = $anexo;
				$url             = wp_get_attachment_url( $anexo );
				$alt             = (string) get_post_meta( $anexo, '_wp_attachment_image_alt', true );
				$interno         = (string) $casamento[3];

				if ( class_exists( 'WP_HTML_Tag_Processor' ) ) {
					$processador = new WP_HTML_Tag_Processor( $interno );

					while ( $processador->next_tag( array( 'tag_name' => 'IMG' ) ) ) {
						if ( is_string( $url ) && '' !== $url ) {
							$processador->set_attribute( 'src', $url );
						}

						$processador->set_attribute( 'alt', $alt );
						$processador->add_class( 'wp-image-' . $anexo );
					}

					$interno = $processador->get_updated_html();
				}

				$json = wp_json_encode( $atributos );

				return '<!-- wp:image ' . ( is_string( $json ) ? $json : '{}' ) . ' -->' . $interno . '<!-- /wp:image -->';
			},
			$html
		);

		return is_string( $substituido ) ? $substituido : $html;
	}

	/**
	 * Avisos acumulados (divergência entre registro e artefato).
	 *
	 * @return string[]
	 */
	public static function avisos(): array {
		return self::$avisos;
	}

	/**
	 * Avisos acumulados nesta execução.
	 *
	 * @var string[]
	 */
	private static array $avisos = array();

	/* ------------------------------------------------------------------ *
	 * Internos
	 * ------------------------------------------------------------------ */

	/**
	 * Registra um aviso de divergência entre registro e artefato.
	 *
	 * @param string $mensagem Mensagem.
	 * @return void
	 */
	private static function aviso( string $mensagem ): void {
		self::$avisos[] = $mensagem;
	}

	/**
	 * Cria ou atualiza um objeto gerenciado pelo merge de três vias.
	 *
	 * @param string               $tipo     `page` ou `post`.
	 * @param string               $ref      Identidade lógica.
	 * @param array<string,mixed>  $desejado Campos desejados.
	 * @param bool                 $adotavel A entrada autoriza adoção.
	 * @param int                  $ordem    Posição, para o escalonamento de datas.
	 * @return array<string,mixed>
	 */
	private static function aplicar_objeto( string $tipo, string $ref, array $desejado, bool $adotavel, int $ordem ): array {
		$rotulo = 'conteudo.' . $tipo . ':' . $ref;
		$id     = self::localizar_gerenciado( $tipo, $ref );
		$origem = 'criado';

		if ( $id <= 0 && $adotavel ) {
			$candidato   = (int) get_option( 'wp_page_for_privacy_policy', 0 );
			$mesmo_slug  = $candidato > 0 && get_post_field( 'post_name', $candidato ) === $desejado['post_name'];

			if ( $candidato > 0 && $mesmo_slug ) {
				$id     = $candidato;
				$origem = 'adotado';
			}
		}

		if ( $id <= 0 ) {
			return self::criar( $tipo, $ref, $desejado, $ordem, $rotulo );
		}

		$post = get_post( $id );

		if ( ! $post instanceof WP_Post ) {
			return self::saida( 'FALHA', $rotulo, __( 'o objeto gerenciado registrado não existe mais no banco.', 'f3base' ) );
		}

		if ( 'adotado' !== $origem ) {
			$origem = (string) get_post_meta( $id, self::META_ORIGEM, true );
			$origem = '' !== $origem ? $origem : 'criado';
		}

		$base = self::ler_base( $id, $ref );

		$observado = array(
			'post_title'   => (string) $post->post_title,
			'post_name'    => (string) $post->post_name,
			'post_status'  => (string) $post->post_status,
			'post_content' => (string) $post->post_content,
			'post_excerpt' => (string) $post->post_excerpt,
			'post_parent'  => (int) $post->post_parent,
		);

		$campos      = array();
		$decisoes    = array();
		$conflitos   = array();
		$preservados = array();
		$nova_base   = is_array( $base ) ? $base : array();
		$politicas   = self::politicas( $origem );

		foreach ( $desejado as $campo => $valor ) {
			$politica  = $politicas[ $campo ] ?? 'conflito';
			$hash_obs  = self::hash_campo( $observado[ $campo ] ?? '' );
			$hash_des  = self::hash_campo( $valor );
			$hash_base = ( is_array( $base ) && isset( $base[ $campo ] ) ) ? (string) $base[ $campo ] : null;

			if ( 'post_status' === $campo && 'adotado' === $origem && self::rank_status( (string) $valor ) > self::rank_status( (string) $observado['post_status'] ) ) {
				$decisoes[ $campo ] = __( 'status não promovido: objeto adotado permanece no status observado, salvo declaração por objeto.', 'f3base' );
				$nova_base[ $campo ] = $hash_obs;
				continue;
			}

			$decisao            = self::merge_campo( $hash_base, $hash_obs, $hash_des, $politica );
			$decisoes[ $campo ] = $decisao['motivo'];

			/*
			 * O DESTINO DA BASE É DECLARADO PELA PRÓPRIA DECISÃO, e não inferido
			 * da ação: `preservar` mantém a base onde ela está, e é isso que faz
			 * a preservação durar mais de uma execução.
			 */
			if ( self::BASE_DESEJADO === ( $decisao['base'] ?? '' ) ) {
				$nova_base[ $campo ] = $hash_des;
			}

			if ( 'gravar' === $decisao['acao'] ) {
				$campos[ $campo ] = $valor;
			} elseif ( 'preservar' === $decisao['acao'] ) {

				/*
				 * A DIVERGÊNCIA PRESERVADA SAI NOMEADA. Até a 1.0.19 as decisões
				 * do merge eram montadas e devolvidas em `decisoes`, e NENHUMA
				 * linha do pacote lia esse campo: a decisão mais importante da
				 * aplicação — o que o pacote deixou de gravar, e por quê — não
				 * chegava ao operador. Preservar calado é indistinguível de não
				 * ter medido nada.
				 */
				if ( $hash_obs !== $hash_des ) {
					$preservados[ $campo ] = $decisao['motivo'];
				}
			} elseif ( 'conflito' === $decisao['acao'] ) {
				$conflitos[] = $campo;
			}
		}

		$nota_preservada = array() === $preservados
			? ''
			: sprintf(
				/* translators: %s: lista de campos preservados. */
				__( ' PRESERVADO, e o pacote NÃO gravou: %s. O valor que está no site é o de quem opera o site; o do template ficou de fora desta aplicação.', 'f3base' ),
				implode( ', ', array_keys( $preservados ) )
			);

		if ( array() !== $conflitos ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: %s: lista de campos em conflito. */
					__( 'conflito de merge sem política explícita nos campos: %s. Nenhuma escrita executada.', 'f3base' ),
					implode( ', ', $conflitos )
				),
				$id,
				$decisoes
			);
		}

		if ( array() === $campos ) {
			if ( ! F3Base_Imp_Gravador::em_simulacao() ) {
				self::gravar_base( $id, $ref, $nova_base );
				F3Base_Imp_Gravador::gravar_meta( 'post', $id, self::META_VERSAO, (string) F3Base_Imp_Config::obter( 'release.identidade', '' ) );
			}

			return self::saida( 'OK', $rotulo, __( 'nada a gravar: todos os campos já estão no estado decidido pelo merge.', 'f3base' ) . $nota_preservada, $id, $decisoes );
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: %s: lista de campos. */
					__( 'modo simulação: gravaria os campos %1$s.%2$s', 'f3base' ),
					implode( ', ', array_keys( $campos ) ),
					$nota_preservada
				),
				$id,
				$decisoes
			);
		}

		self::limpar_metas_de_lixeira( $id );

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_POST,
			$rotulo,
			$observado,
			$campos,
			array(
				'acao'   => 'post.restaurar',
				'id'     => $id,
				'campos' => $observado,
			)
		);

		/*
		 * `post_date` NUNCA vai no update: `wp_insert_post()` parte de defaults e
		 * data vazia vira "agora" — a data de publicação de todo o blog viraria a
		 * data do último deploy. E quando a gravação não muda o conteúdo,
		 * `post_modified` é restaurado pelo filtro: `lastmod` uniforme depois de
		 * um redeploy é FALHA no relatório.
		 */
		$muda_conteudo = array_key_exists( 'post_content', $campos ) || array_key_exists( 'post_title', $campos );

		if ( ! $muda_conteudo ) {
			self::restaurar_modificado( $id, (string) $post->post_modified, (string) $post->post_modified_gmt );
		}

		/*
		 * TROCA DE SLUG DE OBJETO GERENCIADO JÁ PUBLICADO é caso de primeira
		 * classe: o endereço antigo continua circulando, e sem a meta lida pelo
		 * site-core ele passa a 404 em silêncio. A meta é gravada ANTES do
		 * update — depois da gravação o valor anterior já não está no banco.
		 */
		$slug_anterior = '';
		$troca_slug    = array(
			'estado' => 'N/A',
			'motivo' => __( 'Slug inalterado nesta aplicação: nenhum endereço antigo a redirecionar.', 'f3base' ),
		);

		if ( array_key_exists( 'post_name', $campos ) && (string) $observado['post_name'] !== (string) $campos['post_name'] ) {
			$slug_anterior = (string) $observado['post_name'];
			$troca_slug    = self::registrar_slug_anterior( $id, $slug_anterior, (string) $campos['post_name'] );
		}

		$campos['ID']            = $id;
		$campos['post_date']     = $post->post_date;
		$campos['post_date_gmt'] = $post->post_date_gmt;

		$atualizado = wp_update_post( wp_slash( $campos ), true );

		self::desarmar_restauracao();

		if ( is_wp_error( $atualizado ) ) {
			return self::saida( 'FALHA', $rotulo, $atualizado->get_error_message(), $id, $decisoes );
		}

		$lido      = get_post( $id );
		$divergiu  = array();

		if ( $lido instanceof WP_Post ) {
			foreach ( $campos as $campo => $valor ) {
				if ( in_array( $campo, array( 'ID', 'post_date', 'post_date_gmt' ), true ) ) {
					continue;
				}

				if ( (string) $lido->{$campo} !== (string) $valor ) {
					$divergiu[] = $campo;
				}
			}
		}

		if ( array() !== $divergiu ) {
			$culpado = in_array( 'post_name', $divergiu, true ) && $lido instanceof WP_Post
				? ' ' . self::diagnostico_de_slug( $tipo, (string) $campos['post_name'], (string) $lido->post_name, $id )
				: '';

			return self::saida(
				'FALHA',
				$rotulo,
				sprintf(
					/* translators: 1: lista de campos divergentes, 2: diagnóstico nomeando quem ocupa o slug. */
					__( 'leitura de volta divergiu nos campos: %1$s.%2$s', 'f3base' ),
					implode( ', ', $divergiu ),
					$culpado
				),
				$id,
				$decisoes
			);
		}

		self::gravar_base( $id, $ref, $nova_base );
		F3Base_Imp_Gravador::gravar_meta( 'post', $id, self::META_VERSAO, (string) F3Base_Imp_Config::obter( 'release.identidade', '' ) );
		F3Base_Imp_Gravador::gravar_meta( 'post', $id, self::META_ORIGEM, $origem );

		return self::saida(
			'FALHA' === $troca_slug['estado'] ? 'FALHA' : 'OK',
			$rotulo,
			sprintf(
				/* translators: 1: lista de campos gravados, 2: resultado do registro do slug anterior. */
				__( 'campos gravados e conferidos na leitura de volta: %1$s. %2$s%3$s', 'f3base' ),
				implode( ', ', array_keys( $campos ) ),
				$troca_slug['motivo'],
				$nota_preservada
			),
			$id,
			$decisoes
		);
	}

	/**
	 * Cria um objeto gerenciado.
	 *
	 * @param string              $tipo     Tipo.
	 * @param string              $ref      Referência lógica.
	 * @param array<string,mixed> $desejado Campos.
	 * @param int                 $ordem    Posição, para o escalonamento.
	 * @param string              $rotulo   Rótulo do resultado.
	 * @return array<string,mixed>
	 */
	private static function criar( string $tipo, string $ref, array $desejado, int $ordem, string $rotulo ): array {
		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida( 'N/A', $rotulo, __( 'modo simulação: criaria o objeto gerenciado com data escalonada.', 'f3base' ) );
		}

		$data = self::data_escalonada( $ordem );

		$campos = $desejado;
		$campos['post_type']     = $tipo;
		$campos['post_date']     = $data;
		$campos['post_date_gmt'] = get_gmt_from_date( $data );
		$campos['meta_input']    = array(
			self::META_ID     => self::identidade( $tipo, $ref ),
			self::META_VERSAO => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
			self::META_ORIGEM => 'criado',
		);

		$id = wp_insert_post( wp_slash( $campos ), true );

		if ( is_wp_error( $id ) ) {
			return self::saida( 'FALHA', $rotulo, $id->get_error_message() );
		}

		$id = (int) $id;

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_POST,
			$rotulo,
			null,
			$desejado,
			array(
				'acao' => 'post.excluir',
				'id'   => $id,
			)
		);

		$lido = get_post( $id );

		if ( ! $lido instanceof WP_Post ) {
			return self::saida( 'FALHA', $rotulo, __( 'o objeto não foi encontrado na leitura de volta.', 'f3base' ), $id );
		}

		$slug_desejado = (string) $desejado['post_name'];

		if ( '' !== $slug_desejado && $lido->post_name !== $slug_desejado ) {
			return self::saida(
				'FALHA',
				$rotulo,
				self::diagnostico_de_slug( $tipo, $slug_desejado, (string) $lido->post_name, $id ),
				$id
			);
		}

		$base = array();

		foreach ( $desejado as $campo => $valor ) {
			$base[ $campo ] = self::hash_campo( $valor );
		}

		self::gravar_base( $id, $ref, $base );

		return self::saida( 'OK', $rotulo, __( 'objeto criado com data escalonada e conferido na leitura de volta.', 'f3base' ), $id );
	}

	/**
	 * Políticas de campo conforme a origem do objeto.
	 *
	 * @param string $origem `criado` ou `adotado`.
	 * @return array<string,string>
	 */
	private static function politicas( string $origem ): array {
		if ( 'adotado' === $origem ) {
			return array(
				'post_title'   => 'preservar',
				'post_content' => 'preservar',
				'post_excerpt' => 'gerenciado',
				'post_name'    => 'preservar',
				'post_status'  => 'preservar',
				'post_parent'  => 'gerenciado',
			);
		}

		return array(
			'post_title'   => 'gerenciado',
			'post_content' => 'gerenciado',
			'post_excerpt' => 'gerenciado',
			'post_name'    => 'gerenciado',
			'post_status'  => 'gerenciado',
			'post_parent'  => 'gerenciado',
		);
	}

	/**
	 * Hash normalizado de um campo.
	 *
	 * @param mixed $valor Valor.
	 * @return string
	 */
	public static function hash_campo( $valor ): string {
		return hash( 'sha256', (string) ( is_scalar( $valor ) ? $valor : wp_json_encode( $valor ) ) );
	}

	/**
	 * Lê a base de merge de um objeto.
	 *
	 * A meta é a fonte confiável; a option é o caminho rápido. Divergência entre
	 * as duas é AVISO — instalação que esteve num estado mentiroso precisa
	 * aparecer.
	 *
	 * @param int    $id  ID do objeto.
	 * @param string $ref Referência lógica.
	 * @return array<string,string>|null
	 */
	private static function ler_base( int $id, string $ref ): ?array {
		$meta = get_post_meta( $id, self::META_BASE, true );
		$meta = is_array( $meta ) ? $meta : null;

		$espelho = get_option( self::OPTION_BASE, array() );
		$espelho = is_array( $espelho ) && isset( $espelho[ $ref ] ) && is_array( $espelho[ $ref ] ) ? $espelho[ $ref ] : null;

		if ( null !== $meta && null !== $espelho && wp_json_encode( $meta ) !== wp_json_encode( $espelho ) ) {
			self::aviso(
				sprintf(
					/* translators: %s: referência lógica do objeto. */
					__( 'base de merge divergente entre a meta do objeto e a option-espelho em %s: a meta prevaleceu (é ela que sobrevive à exclusão do plugin).', 'f3base' ),
					$ref
				)
			);
		}

		return $meta ?? $espelho;
	}

	/**
	 * Grava a base de merge na meta durável e no espelho rápido.
	 *
	 * @param int                  $id   ID do objeto.
	 * @param string               $ref  Referência lógica.
	 * @param array<string,string> $base Base por campo.
	 * @return void
	 */
	private static function gravar_base( int $id, string $ref, array $base ): void {
		F3Base_Imp_Gravador::gravar_meta( 'post', $id, self::META_BASE, $base );

		$espelho = get_option( self::OPTION_BASE, array() );
		$espelho = is_array( $espelho ) ? $espelho : array();

		$espelho[ $ref ] = $base;

		F3Base_Imp_Gravador::gravar( self::OPTION_BASE, $espelho, array( 'autoload' => false ) );
	}

	/**
	 * Lê o registro de base de uma OPTION.
	 *
	 * Mesma option-espelho do conteúdo, seção reservada. Devolve `null` quando
	 * a option nunca teve base — e é esse `null`, e não um registro vazio, que
	 * a regra de três vias precisa para saber que está na PRIMEIRA execução
	 * daquela estrutura.
	 *
	 * @param string $option Nome da option.
	 * @return array<string,mixed>|null
	 */
	public static function ler_base_de_option( string $option ): ?array {
		$espelho = get_option( self::OPTION_BASE, array() );
		$espelho = is_array( $espelho ) ? $espelho : array();
		$secao   = isset( $espelho[ self::SECAO_OPTIONS ] ) && is_array( $espelho[ self::SECAO_OPTIONS ] )
			? $espelho[ self::SECAO_OPTIONS ]
			: array();

		return isset( $secao[ $option ] ) && is_array( $secao[ $option ] ) ? $secao[ $option ] : null;
	}

	/**
	 * Grava o registro de base de uma OPTION.
	 *
	 * @param string              $option   Nome da option.
	 * @param array<string,mixed> $registro Registro: `hash`, `valor` e o que o produtor acrescentar.
	 * @return void
	 */
	public static function gravar_base_de_option( string $option, array $registro ): void {
		$espelho = get_option( self::OPTION_BASE, array() );
		$espelho = is_array( $espelho ) ? $espelho : array();
		$secao   = isset( $espelho[ self::SECAO_OPTIONS ] ) && is_array( $espelho[ self::SECAO_OPTIONS ] )
			? $espelho[ self::SECAO_OPTIONS ]
			: array();

		$secao[ $option ]                  = $registro;
		$espelho[ self::SECAO_OPTIONS ]    = $secao;

		F3Base_Imp_Gravador::gravar( self::OPTION_BASE, $espelho, array( 'autoload' => false ) );
	}

	/**
	 * Remove as metas que ressuscitam o estado de lixeira.
	 *
	 * @param int $id ID do objeto.
	 * @return void
	 */
	private static function limpar_metas_de_lixeira( int $id ): void {
		foreach ( self::metas_de_lixeira() as $meta ) {
			if ( metadata_exists( 'post', $id, $meta ) ) {
				F3Base_Imp_Gravador::remover_meta( 'post', $id, $meta );
			}
		}
	}

	/**
	 * Arma a restauração de `post_modified` para a próxima gravação.
	 *
	 * @param int    $id       ID do objeto.
	 * @param string $local    Valor local.
	 * @param string $gmt      Valor GMT.
	 * @return void
	 */
	private static function restaurar_modificado( int $id, string $local, string $gmt ): void {
		self::$modificado_a_restaurar = array(
			'id'  => (string) $id,
			'loc' => $local,
			'gmt' => $gmt,
		);

		add_filter( 'wp_insert_post_data', array( __CLASS__, 'filtrar_modificado' ), 10, 2 );
	}

	/**
	 * Desarma a restauração.
	 *
	 * @return void
	 */
	private static function desarmar_restauracao(): void {
		remove_filter( 'wp_insert_post_data', array( __CLASS__, 'filtrar_modificado' ), 10 );
		self::$modificado_a_restaurar = array();
	}

	/**
	 * Restaura `post_modified` quando a gravação não muda conteúdo.
	 *
	 * @param array<string,mixed> $dados    Dados a gravar.
	 * @param array<string,mixed> $original Dados originais recebidos.
	 * @return array<string,mixed>
	 */
	public static function filtrar_modificado( $dados, $original ) {
		if ( ! is_array( $dados ) || array() === self::$modificado_a_restaurar ) {
			return $dados;
		}

		$id = isset( $original['ID'] ) ? (string) $original['ID'] : '';

		if ( $id !== self::$modificado_a_restaurar['id'] ) {
			return $dados;
		}

		$dados['post_modified']     = self::$modificado_a_restaurar['loc'];
		$dados['post_modified_gmt'] = self::$modificado_a_restaurar['gmt'];

		return $dados;
	}

	/**
	 * Data de publicação fixa e escalonada para a criação.
	 *
	 * Um blog que estreia com N posts do mesmo minuto declara ser fachada. Só se
	 * usa na CRIAÇÃO: a atualização preserva a data existente.
	 *
	 * @param int $ordem Posição do objeto na lista declarada.
	 * @return string Data local no formato do WordPress.
	 */
	public static function data_escalonada( int $ordem ): string {
		$total     = max( 1, count( F3Base_Imp_Config::lista( 'posts' ) ) + count( F3Base_Imp_Config::lista( 'paginas' ) ) );
		$distancia = ( $total - $ordem ) * DAY_IN_SECONDS * 3;
		$instante  = time() - $distancia;

		return (string) wp_date( 'Y-m-d H:i:s', $instante );
	}

	/**
	 * Vincula um post à categoria declarada.
	 *
	 * @param int    $id   ID do post.
	 * @param string $slug Slug da categoria.
	 * @return void
	 */
	private static function vincular_categoria( int $id, string $slug ): void {
		$termo = get_term_by( 'slug', $slug, 'category' );

		if ( ! $termo instanceof WP_Term ) {
			return;
		}

		$atuais = wp_get_object_terms( $id, 'category', array( 'fields' => 'ids' ) );
		$atuais = is_wp_error( $atuais ) ? array() : array_map( 'intval', $atuais );

		if ( in_array( (int) $termo->term_id, $atuais, true ) ) {
			return;
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return;
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_RELACAO,
			'post#' . $id . ':category',
			$atuais,
			array( (int) $termo->term_id ),
			array(
				'acao'      => 'relacao.restaurar',
				'objeto_id' => $id,
				'taxonomia' => 'category',
				'termos'    => $atuais,
			)
		);

		wp_set_object_terms( $id, array( (int) $termo->term_id ), 'category', false );
	}

	/**
	 * Aplica o papel declarado de um item de mídia.
	 *
	 * @param string $papel Papel declarado.
	 * @param int    $anexo ID do anexo.
	 * @return void
	 */
	private static function aplicar_papel_midia( string $papel, int $anexo ): void {
		if ( 'custom_logo' === $papel ) {
			F3Base_Imp_Gravador::gravar( 'site_logo', $anexo );

			/*
			 * `set_theme_mod()` grava direto em `theme_mods_<tema>` e ficaria
			 * fora do journal e da procedência. O ponto único de escrita cobre
			 * também as options do core: a chave entra pelo gravador.
			 */
			F3Base_Imp_Gravador::gravar_chaves(
				'theme_mods_' . get_stylesheet(),
				array( 'custom_logo' => $anexo )
			);
		}

		if ( 'site_icon' === $papel ) {
			F3Base_Imp_Gravador::gravar( 'site_icon', $anexo );
		}

		if ( 'og_default_image' === $papel || 'conteudo' === $papel || self::PAPEL_INLINE === $papel ) {
			/*
			 * Papéis consumidos em outra etapa: a imagem social é referenciada
			 * pelo adaptador de SEO por REFERÊNCIA LÓGICA, e o papel `conteudo`
			 * é resolvido na injeção do ID do anexo no bloco de imagem. O papel
			 * `marca_inline` sequer chega aqui com anexo, porque não vai para a
			 * biblioteca. Nada a gravar — e dizer isso é melhor que um `else` mudo.
			 */
			return;
		}
	}

	/**
	 * Monta o resultado de uma unidade de conteúdo.
	 *
	 * @param string                $estado   Estado fechado.
	 * @param string                $rotulo   Nome da checagem.
	 * @param string                $motivo   Mensagem.
	 * @param int                   $id       ID envolvido.
	 * @param array<string,string>  $decisoes Decisões do merge por campo.
	 * @return array<string,mixed>
	 */
	private static function saida( string $estado, string $rotulo, string $motivo, int $id = 0, array $decisoes = array() ): array {
		return array(
			'estado'   => $estado,
			'rotulo'   => $rotulo,
			'motivo'   => $motivo,
			'id'       => $id,
			'decisoes' => $decisoes,
		);
	}
}
