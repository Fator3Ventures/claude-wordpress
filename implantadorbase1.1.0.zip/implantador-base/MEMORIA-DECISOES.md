<!-- gerado:inicio=carimbo -->
# Memória de decisões — implantador-base 1.1.0

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio: foi o que aconteceu da 1.0.6 à 1.0.13. O que não pode ser gerado no momento da escrita
> sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `1.1.0` |
| Implantador · tema · site-core | `1.1.0` · `1.1.0` · `1.1.0` |
| Bundle desta identidade | `implantador-base-1.1.0.zip` |
| Origens de release suportadas | 20 além da instalação limpa |
| Caminhos exatos no inventário | 114 |
| Prefixos declarados no inventário | 3 |
| Arquivos no pacote (fora de `dist/`) | 330 |
| Requisitos em `suite/manifesto.tsv` | 196 |
| Armadilhas com checagem mapeada | 108 |
| Armadilhas em pendência declarada | 11 |
| Detectores com piso em disco | 55 |
| Ramos de piso (negativa + positiva) | 110 |
| Páginas · posts declarados | 6 · 2 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

Registro das decisões desta base. Cada entrada traz quatro campos, sempre na mesma
ordem: **o que foi decidido**, **por quê**, **o que custa** e **como reverter**.
Decisão sem custo escrito é decisão não examinada; decisão sem caminho de reversão
é decisão que só pode ser paga uma vez.

Escopo: as decisões abaixo valem para o pacote-fábrica. Decisão tomada dentro de
uma instância publicada mora na memória daquela instância, não aqui.

Convenção de estados usada neste arquivo: os mesmos seis estados fechados do
relatório da suíte, sem inventar um sétimo.

---

## 1. O menu é um post `wp_navigation`

**Decidido.** A navegação principal é um post do tipo `wp_navigation`, com slug
estável `f3base-principal`, ID guardado na option `f3base_nav_id`, e o tema
injetando o `ref` no bloco em tempo de render. A alternativa descartada é o menu
escrito dentro de `parts/header.html`.

**Por quê.** O critério é quem edita o menu depois da entrega. Com manutenção por
agente conectado ao canal MCP, quem edita é o agente, por rota tipada — sem release,
sem acesso ao servidor de arquivos e sem tocar no tema. E existe uma cópia só do
objeto: duas páginas divergirem de menu deixa de ser possível por construção, não
por disciplina.

**O que custa.** O menu sai do versionamento em arquivo e passa a viver no banco.
Um diff de repositório deixa de mostrar mudança de navegação, e a reconstrução da
instância a partir do pacote depende do implantador recriar o objeto, não de copiar
um arquivo. A compensação declarada é a leitura de volta do objeto na aplicação e o
registro da mudança na memória da instância.

**Como reverter.** Trocar `navegacao.modo` para o menu inline na part, mover os
itens para `parts/header.html`, subir a versão do tema e apagar `f3base_nav_id` pelo
gravador único. A reversão é migração, não ajuste: o objeto no banco continua
existindo até ser removido explicitamente, e menu em dois lugares é a pior das três
configurações possíveis. Projeto explicitamente sem manutenção pós-entrega é o único
caso em que essa reversão faz sentido.

---

## 2. Lockdown do `theme.json`

**Decidido.** Quinze chaves de `settings` desligadas no `theme.json`: as nove que o
contrato exige — `color.custom`, `color.customGradient`, `color.defaultPalette`,
`color.defaultGradients`, `typography.customFontSize`, `typography.defaultFontSizes`,
`spacing.customSpacingSize`, `spacing.defaultSpacingSizes` e
`layout.allowCustomContentAndWideSize` — mais `color.customDuotone`,
`color.defaultDuotone`, `shadow.defaultPresets`, `typography.dropCap`,
`typography.fluid` e `typography.writingMode`.

**Por quê.** Dois motivos independentes. O primeiro é o defeito medido: o WordPress
injeta presets padrão **com os mesmos slugs do tema**, e eles vencem os valores do
tema no global-styles — o sintoma foi `--wp--preset--font-size--large` publicado em
36px com o tema declarando outro valor, com duas rodadas de correção nos `elements`
sem efeito porque o defeito não estava lá. O segundo é o sistema de design: com as
portas fechadas, o editor só oferece o que o `theme.json` declara, e largura, cor,
fonte e espaçamento continuam idênticos entre páginas depois que a suíte da entrega
dormiu.

**O que custa.** O fechamento restringe também o editor humano legítimo. Um pedido
do tipo "esta palavra neste vermelho específico" não tem caminho pela interface: ele
vira preset novo, com nome e propagação, ou vira recusa explicada — e isso precisa
ser dito na conversa de handoff, não descoberto pelo cliente na primeira edição.
Segundo custo, mais sutil: o lockdown governa a interface do editor e **não alcança
quem grava markup direto**, que é justamente o agente de manutenção via MCP.

**Como reverter.** Ligar a chave específica no `theme.json` e subir a versão do
tema. A reversão é por chave, nunca em bloco: reabrir `defaultFontSizes` traz de
volta a colisão de slugs, que é defeito conhecido e não preferência.

**Consequência aceita, não revertida.** Como o lockdown não alcança o markup direto,
o mecanismo que fecha esse lado é a varredura `conteudo.sem_estilo_avulso` sobre o
conteúdo publicado — cor literal, tamanho de fonte solto e largura fixa fora de
referência de preset. Sem a varredura, o lockdown é meia trava.

---

## 3. Consentimento pré-aprovado, com controle no rodapé e aviso de primeira visita desligado

**Decidido.** `consentimento.padrao` é `pre-aprovado`: as tags carregam na chegada,
sem banner bloqueante. O instrumento do titular é o controle de revisão no rodapé,
presente em toda página publicada — inclusive 404 e páginas de confirmação, porque
ele mora na part do rodapé. A negativa desliga as tags na mesma sessão e persiste por
`ttl_dias`, hoje 180; o novo aceite religa. A chave `aviso_primeira_visita` existe,
tem consumidor no JavaScript do `site-core` e nasce **desligada**.

**Por quê.** A pré-aprovação é a política declarada da operação, e o controle
permanente no rodapé é o que a torna revisável em qualquer momento, em vez de uma
decisão tomada uma vez num banner e nunca mais alcançável. O aviso de primeira visita
nasce desligado porque ligá-lo é decisão de projeto — o caso que a pede é o cliente
cujo jurídico exige informação antes da carga.

**O que custa.** O custo é jurídico e está declarado sem maquiagem: o guia de cookies
da ANPD, de 2022, orienta consentimento prévio para cookies não essenciais, e
pré-aprovação **sem** aviso na primeira visita é a leitura mais exposta de uma posição
já contestada na LGPD. Com o aviso desligado, a transparência se apoia inteiramente na
política publicada e no controle do rodapé — e o relatório de entrega precisa dizer
isso com todas as letras, nunca "o visitante foi informado". Custo secundário: sem
JavaScript o controle não opera, e essa perda é declarada como a do fluxo de WhatsApp.

**Como reverter.** Duas reversões diferentes, e elas não são a mesma coisa. Mitigação
parcial: ligar `consentimento.aviso_primeira_visita`, que acrescenta o aviso não
bloqueante apontando a política e o controle do rodapé, sem mudar a política de carga.
Reversão completa: trocar `consentimento.padrao` para negado, e então as tags só
carregam após o aceite, com o controle do rodapé seguindo como caminho de revisão — a
estrutura é a mesma, os quatro caminhos testados apenas se invertem.

---

## 4. Atualização automática ligada para todo plugin, sem exceção

**Decidido.** `plugins.autoupdate` é `todos`, incluindo o servidor do canal MCP.
A política de versão é `ultima-da-fonte-oficial`: nenhuma versão é fixada e nenhuma
janela de versões é homologada previamente.

**Precedência declarada.** Janela de exposição **vence** estabilidade. Quando as duas
entram em conflito, a decisão é atualizar. A saída para quebra é **reverter**, não
deixar de atualizar — a ordem dos dois é o conteúdo da decisão, e inverter a ordem é
mudar a política, não afiná-la.

**Por quê.** Plugin desatualizado num site público é vulnerabilidade com data de
publicação conhecida. Congelar versão troca um risco medido por um risco difuso, e
transfere para uma decisão humana futura — que costuma não acontecer — a proteção que
o automatismo dá de graça.

**O que custa.** Três coisas. O plugin muda embaixo do site sem release nossa, então a
conferência dos adaptadores deixa de ser de instalação e passa a ser de rotina, o que
torna a cadência do modo somente-relatório obrigatória em vez de higiênica. A quebra
sutil — comportamento mudado, chave de option descartada, CSS deslocado — passa pela
rede de proteção do WordPress e só aparece na cadência ou no cliente. E o complemento
do canal, por não vir do WordPress.org, não é alcançado pela atualização automática:
o caminho dele continua sendo release nossa, por upload com sobrescrita e reativação.

**Como reverter.** Não há reversão da política em si sem mudar a precedência acima. O
que existe é o caminho de reversão pontual de um plugin, descrito no `README.md`, com
os três limites que ele carrega: o WordPress só desfaz sozinho a falha fatal; reverter
código não reverte dados; e a reversão é temporária, datada e fecha quando o upstream
corrige.

---

## 5. Nenhuma versão fixada e nenhuma janela homologada; o gate é a leitura de volta

**Decidido.** Plugin de terceiro é instalado sempre na última versão publicada pela
fonte oficial. Não existe número congelado no arquivo de configuração, não existe
intervalo de versões declarado como aprovado e não existe checksum de terceiro no
lock. O que decide se a instalação serve é a leitura de volta de cada option gravada.

**Por quê.** Um portão por número é inferência sobre compatibilidade; gravar e reler é
medição dela. Qualquer portão por número reprovaria um site saudável no dia seguinte a
uma atualização automática, ou aprovaria um site quebrado numa versão que mudou de
comportamento sem mudar de número maior. E a razão da antiga regra — nada de
configurar às cegas — sobrevive inteira num mecanismo que não depende de alguém ter
previsto a numeração do fornecedor: escrever num plugin de versão desconhecida é
seguro **porque** a escrita é reversível e conferida.

**O que custa.** A fronteira de confiança passa a ser a entrega da própria fonte
oficial por HTTPS: sem checksum de terceiro, não há prova criptográfica do artefato
baixado. E o custo operacional é a cadência: sem ela, a releitura não acontece e a
política vira lembrete. O número da versão continua existindo no relatório, mas como
diagnóstico, nunca como critério de aprovação.

**Como reverter.** Voltar a fixar versão exigiria três coisas ao mesmo tempo:
desligar a atualização automática, declarar a versão no arquivo de configuração e
manter uma homologação por número que alguém precisa refazer a cada release do
fornecedor. As três juntas são a política anterior inteira, e ela foi trocada por
medição — reverter uma sem as outras duas produz o pior estado: número declarado que
ninguém confere, com o site atualizando sozinho por baixo.

---

## 6. Canal MCP são dois plugins, e o risco é aceito como política

**Decidido.** O canal exige o par: o servidor (`wp-mcp-ultimate`) e o complemento
(`wp-mcp-ultimate-complemento-fator3`, artefato nosso). Os dois são instalados por
origem `url` declarada, com `pasta_esperada` e host em lista fechada — `plugins.embarcados`
está vazio, e o complemento, que já viajou dentro do bundle, deixou de viajar (decisão 15).
O servidor expõe as rotas tipadas e **nenhuma** rota de arquivo ou de banco; as doze rotas
de arquivo e banco vêm do complemento. A checagem `mcp.canal_configurado` confere as rotas
**pelo nome**, não a presença dos plugins, e tem piso obrigatório: instalação com servidor
e sem complemento precisa reprovar. Desde a 1.0.6, quem deriva esse veredito é uma unidade
só, e `mcp.canal_exposto` é rótulo separado, porque rota **registrada** e rota **exposta
por MCP** são fatos diferentes (decisão 17).

**Por quê.** Sem o complemento, quatro linhas da matriz de alocação — `theme.json`,
`templates/` e `parts/`, o `site-core` e o bump de versão do `style.css` — não têm via
de execução pelo agente, e a manutenção estrutural volta a depender de acesso humano
por FTP. Não é preferência de ferramenta: é a diferença entre a fase de manutenção
existir e não existir.

**O que custa, dito onde custa.** As rotas de arquivo gravam PHP no servidor. O par
autenticado é, por construção, execução remota de código atrás de uma credencial. A
lista de options protegidas é trava contra acidente e disciplina de operação, **não
fronteira de segurança**: quem edita o código do `site-core` pela rota de arquivo
alcança o filtro que a implementa. A fronteira real é o usuário dedicado, a Application
Password e as travas do próprio canal — sintaxe de PHP conferida antes de gravar, hash
esperado na escrita, backup com restauração e escrita de banco em duas fases.

**Decisão sobre o risco.** Aceito **como política**, com responsável e data
registrados na entrega, em vez de reaberto a cada site. Cliente que recuse é exceção
declarada, e o que ele perde é nomeado antes da entrega: sem canal não há fase de
manutenção por agente, e toda mudança estrutural volta a depender de acesso humano ao
servidor.

**Como reverter.** O desligamento é caminho de operador e está documentado no
`README.md`: interruptor na tela do complemento, filtro equivalente no código, e a
revogação da Application Password do usuário dedicado — as três, porque desligar o
canal sem revogar a credencial deixa metade da porta aberta. Reversão permanente é a
exceção declarada acima, com a perda nomeada. E o canal precisa ser **único** no site
para que o interruptor feche tudo: duas cópias do complemento com slugs diferentes são
dois diretórios de backup e duas chaves de desligamento, com a tela dizendo que está
fechado enquanto a outra cópia continua aberta.

---

## 7. Regime de formulário por e-mail declarado e inativo

**Decidido.** O `site.json` declara dois regimes de formulário. O de WhatsApp
(`contato-whatsapp`) está ativo, com escopo de site inteiro. O de e-mail
(`landing-cf7`) está declarado com `ativo: false` e com o motivo escrito no próprio
arquivo: a base não instancia fluxo por e-mail, e o regime fica disponível para o
agente que precisar dele.

**Por quê.** Apagar o regime tornaria a estrutura de configuração incompleta para
quem parte desta base e precisa de formulário por e-mail — e ele voltaria escrito à
mão, sem os campos obrigatórios, sem página de confirmação e sem critério de contato
declarado. Deixá-lo ativo e vazio seria pior: um formulário que aceita envio e não
entrega em lugar nenhum.

**O que custa.** Uma entrada de configuração sem execução nesta base. O risco é
exatamente o da chave sem consumidor, e o mecanismo que o cobre é o mesmo: o detector
geral cruza toda chave declarada contra o código que aplica, e `ativo: false` é um
valor lido, não uma seção ignorada. O comportamento degradado também está declarado:
bloqueado com mensagem, sem envio silencioso.

**Como reverter.** Trocar `ativo` para verdadeiro, preencher `contato.email_leads`,
apontar `pagina_ref`, e a página de confirmação declarada passa a ser criada. A
ativação exige exercitar o envio real na verificação — comportamento se prova
exercitando, e formulário conferido de olho é o defeito do menu compacto com outro
nome.

---

## 8. Fontes de sistema em vez de webfont auto-hospedada

**Decidido.** O `theme.json` declara duas famílias em pilha nativa do sistema
(`sistema` e `mono`) e **nenhum** `fontFace`. A chave `tema.fontes` do `site.json` vem
vazia e não há binário de fonte no pacote.

**Por quê.** O motivo é factual, não estético: não existe arquivo de fonte para
embutir. Referenciar um `.woff2` inexistente produziria 404 em toda página — pior que
a pilha do sistema, que renderiza sem requisição nenhuma. A regra do método continua
valendo e não foi revogada: fonte auto-hospedada, `font-display: swap`, versão no nome
do arquivo, cache imutável escopado no diretório de assets do tema, e **nunca** Google
Fonts por CDN, porque a chamada ao CDN entrega o IP do visitante a um terceiro sem base
legal.

**O que custa.** O site não tem tipografia de marca: ele renderiza com a fonte de
interface do sistema operacional de cada visitante, o que significa desenho de letra
diferente entre plataformas e métricas que variam. Para um projeto com identidade
tipográfica definida, isso é perda visível.

**Como reverter.** Três passos, nesta ordem: colocar o `.woff2` em `fontes/tema/assets/`,
declarar o `fontFace` na família correspondente do `theme.json` com o preload apenas da
face do primeiro render, e listar o arquivo em `tema.fontes` no `site.json`. Antes
disso, conferir a licença: webfont comercial tem licença por domínio e por formato, e
fonte do site de referência não é automaticamente licenciável — sem sustentação, o
caminho é equivalente aberto com métricas próximas, com a troca declarada no relatório.

---

## 9. Rota de origem obrigatória no `site-core`

**Decidido.** O módulo `rota-origem` é obrigatório, não opcional. Ele expõe uma rota
que faz o próprio servidor pedir a própria URL pública e devolve status, cabeçalhos e
corpo, com o resultado carimbado com a fase `origem`. Restrição fechada: apenas
caminho do próprio `home_url()`, host validado, redirecionamento não seguido, destino
livre recusado pelo nome.

**Por quê.** A regra de leitura de volta precisa de mecanismo quando a rede do agente
é barrada — firewall de aplicação, TLS reiniciado para cliente sem navegador, resposta
de excesso de requisições. Regra sem mecanismo é lembrete, e foi por isso que a rota
virou módulo obrigatório em vez de recomendação.

**O que custa.** Dois custos, e o segundo é o importante. O primeiro: uma rota a mais
na superfície do site, mitigada por capability `manage_options` e nonce ou credencial
do canal. O segundo: o resultado dela é evidência de **origem**, nunca do que o
visitante recebe — o loopback tende a bater na origem e a pular exatamente a camada de
cache ou CDN que produz o defeito mais caro deste tipo de projeto. Apresentar
resultado dessa rota como evidência de visitante é reprovação por desenho, e existe
piso para isso.

**Como usar o custo a favor.** A diferença entre a leitura de origem e a leitura
externa é o próprio diagnóstico de cache: tamanhos e hashes iguais nas duas apontam
para valor que varia por requisição; diferentes apontam para cache servindo versão
velha. O relatório imprime o discriminante em vez de escolher a causa.

**Como reverter.** Remover o módulo do registro único do `site-core`. A consequência
precisa ser declarada junto: sem ele, quando a rede do agente estiver barrada, a
leitura de volta não tem segundo caminho e o item correspondente fecha BLOCKED até um
verificador externo fechá-lo. Não é reversão barata — é troca de um instrumento
limitado e rotulado por nenhum instrumento.

---

## 10. Duas exceções de `wp:html` no tema, e nenhuma no conteúdo

**Decidido.** O tema tem exatamente duas exceções de `wp:html`, ambas declaradas em
`tema.wp_html_excecoes` com motivo escrito: o link de pular para o conteúdo em
`parts/header.html` e o botão do controle de consentimento em `parts/footer.html`. O
conteúdo editorial — `content/pages/` e `content/posts/` — não tem nenhuma, e a
navegação nunca é uma delas.

**Por quê.** O link de pular precisa ser o primeiro elemento do DOM e sair da tela até
receber foco: nenhum bloco nativo produz esse par de requisitos. O botão de
consentimento tem comportamento próprio do `site-core` e não tem bloco nativo
equivalente, e ele precisa existir em toda página por construção — que é o que morar
na part do rodapé garante.

**O que custa.** Dois trechos de markup que o editor não valida como bloco e que
mudam apenas por edição de arquivo, com bump de versão do tema. Em troca, o contrato
de nomes entre tema e plugin fica fixo: classe e atributo de dados idênticos aos que o
`site-core` procura, com o suporte de tema declarado para o plugin **não** imprimir um
segundo controle no rodapé.

**Como reverter.** Só com bloco nativo equivalente. Enquanto ele não existir, a
reversão correta é a que já está no código: o `site-core` mantém markup de reserva
idêntico, usado quando o tema **não** declara o suporte — de modo que trocar o tema não
apaga o controle de privacidade da página.

---

## 11. Ícone do site e imagem social em PNG, e o logo em PNG com o vetor preservado

**Decidido (revisto na 1.0.2).** `assets/` embarca quatro binários: `logo.png` em
512 × 512 com fundo transparente para `custom_logo`, `logo.svg` com o papel declarado
`marca_inline`, `favicon.png` em 512 × 512 para `site_icon` e `social.png` em
1200 × 630 para `og_default_image`. Os dois bitmaps são **PNG**, e não WebP nem AVIF. Todos os três são
gerados a partir da paleta já declarada no `theme.json` — `inverso`, `primaria` e `base`
—, sem introduzir cor nova; o SVG não carrega cor literal nenhuma, porque o desenho usa
`currentColor` e herda a cor do contexto em que for colocado.

**Por quê.** O documento do método pede WebP ou AVIF salvo justificativa escrita no
relatório, e a justificativa aqui é de **consumidor**, não de peso. Nenhum dos dois
papéis é servido ao navegador do visitante como imagem de conteúdo: o `site_icon` é lido
pelo próprio WordPress, que gera e serve os tamanhos derivados do ícone, e a imagem
padrão de Open Graph é lida por rastreadores de redes sociais e por aplicativos de
mensagem. O suporte a WebP nesses dois consumidores é inconsistente, e o modo de falha é
o pior possível: o ícone ou a prévia simplesmente não aparece, sem erro em lugar nenhum,
sem linha em log e sem nada para uma checagem observar do lado do site. PNG é o formato
que os dois consomem de forma confiável. **A revisão da 1.0.2 tirou o logo de fora dessa discussão pelo lado errado.** O papel
`custom_logo` exige um **anexo na biblioteca de mídia**, e o WordPress recusa SVG na
biblioteca por padrão — "Sem permissão para enviar esse tipo de arquivo" foi a mensagem
medida. A recusa está certa: SVG é vetor de XSS, e habilitar o MIME no site seria uma
decisão de segurança que este pacote não toma por conta de um logotipo. Então o papel
`custom_logo` passou para `logo.png`, desenhado com os mesmos slugs `inverso`, `primaria`
e `base`, com fundo transparente. O `logo.svg` **continua no pacote**, agora com o papel
declarado `marca_inline`: ele é servido pelo tema no próprio markup, escala sem perda e
não passa pela biblioteca. A unidade daquele item fecha N/A com a condição declarada, e
não some do relatório.

**O que custa.** Peso maior do que os dois bitmaps teriam em WebP — nesta leitura, 2 790
bytes no ícone e 3 272 bytes na imagem social, contra o que a mesma arte pesaria no
formato moderno. É custo aceito e pequeno em termos absolutos, mas ele existe e não é
disfarçado: a decisão troca bytes por previsibilidade de renderização em software de
terceiro que não temos como instrumentar. Custo secundário: dois formatos convivem no
mesmo diretório, e quem acrescentar imagem **de conteúdo** no futuro não deve tomar este
precedente como regra — imagem de conteúdo é servida ao navegador e volta a seguir a
regra de WebP ou AVIF.

**Como reverter.** Trocar os bitmaps por WebP exige, na mesma mudança: substituir os
arquivos em `assets/`, atualizar os caminhos em `midia` no `config/site.json`, atualizar
as linhas correspondentes de `suite/inventario.tsv` e conferir os dois consumidores de
verdade — o ícone renderizado pelo WordPress e a prévia lida por um rastreador externo.
A conferência é obrigatória e não é opcional na reversão: é exatamente a evidência que
falta hoje para tomar a decisão contrária, e trocar o formato sem ela seria substituir uma
justificativa escrita por uma suposição.

**Nota de idempotência.** Troca de ativo é caso de primeira classe: a implantação importa
o arquivo novo **antes** de remover o antigo e reaponta a referência, de modo que uma
falha no envio deixa o site com a versão anterior em vez de sem imagem. Remoção do antigo
só com propriedade exclusiva comprovada; caso contrário ele é marcado obsoleto e relatado.

---

## 12. As fontes do tema e do `site-core` moram em `fontes/`

**Decidido.** `tema/` e `site-core/` saíram da raiz do pacote e passaram a ser
`fontes/tema/` e `fontes/site-core/`. `fontes/` não contém nenhum `.php` diretamente.
A regra virou executável em `pacote.sem_cabecalho_de_plugin_aninhado`: a raiz precisa
ter **exatamente um** `.php` com `Plugin Name:`, e **nenhum** `.php` a um nível de
subdiretório pode ter outro.

**Por quê.** Não é organização, é correção de um defeito medido e determinístico.
`get_plugins( '/implantador-base' )` varre a raiz do plugin **e um nível de
subdiretório**. Com o `site-core` em `site-core/f3base-site-core.php`, aquela varredura
via dois cabeçalhos — "Implantador Base F3" e "F3 Base Site Core" —, ordenava por
**Name**, e "F3 Base Site Core" vinha antes. `Plugin_Upgrader::plugin_info()` devolve
`array_keys(...)[0]`, então o link "Ativar plugin" da tela de instalação carregava
`implantador-base/site-core/f3base-site-core.php`. Aí `validate_plugin()` chama o
`get_plugins()` completo, que só enxerga um nível a partir de `wp-content/plugins/`, não
acha um caminho de dois níveis e devolve exatamente "The plugin does not have a valid
header." Ativar pela **lista de plugins** funcionava, porque ali o link é o arquivo
principal — e foi essa assimetria que fez a 1.0.1 registrar o defeito como
intermitência de cache e recomendar "ative de novo". Não era cache: era ordenação.

**O que custa.** Um nível a mais em todo caminho de fonte, e um custo real de migração
pago uma vez: inventário, empacotador, checagens do tema, entregáveis, resolução de
caminho em `class-f3base-imp-plugins.php` e `class-f3base-imp-entrega.php`, o preflight
que soma o tamanho do pacote, as fixtures do piso e a árvore do leia-me. Custo residual:
quem vier de fora e procurar `tema/` na raiz não acha de primeira.

**Como reverter.** Só reverte quem estiver disposto a reintroduzir o defeito: mover as
duas pastas de volta faz o segundo cabeçalho voltar ao alcance de `get_plugins()`, e o
detector reprova a rodada nomeando o arquivo. Reverter de verdade exigiria outra saída
para o mesmo problema — por exemplo, embarcar tema e `site-core` **só** como zip e não
como árvore de arquivos —, e essa é uma decisão nova, não uma reversão desta.

---

## 13. Backup de instalação anterior com ponto na frente

**Decidido.** A troca controlada de diretório preserva a versão anterior em
`.f3base-anterior-<slug>-<ts>`, irmã do destino, e não mais em
`<destino>-f3base-anterior-<ts>`. A etapa de atualização automática ignora
explicitamente todo diretório que comece com ponto e **diz no relatório quantos
ignorou**.

**Por quê.** `get_plugins()` pula todo diretório cujo nome começa com ponto, e
`search_theme_directories()` faz o mesmo com temas. Sem o ponto, a preimagem virava um
plugin aos olhos do WordPress: o log de uma execução real listou
`f3base-site-core-f3base-anterior-1788152131` entre os plugins com atualização
automática ligada. Um diretório de backup não é código em uso, não deve receber
atualização automática e não deve aparecer em listagem de plugin.

**O que custa.** O backup fica menos visível para quem lista o diretório sem `-a`, e é
por isso que o caminho continua saindo por escrito no journal e na mensagem da unidade.
A filtragem explícita na etapa de auto-update é redundante com o comportamento do
núcleo, e essa redundância é deliberada: depender do comportamento de terceiro para uma
regra nossa é o mesmo que não ter a regra.

**Como reverter.** Tirar o ponto do prefixo em `caminho_do_backup()`, que é o ponto
único onde o nome é montado. A reversão traz de volta o diretório órfão nas listagens, e
a etapa de auto-update passará a reportar zero ignorados enquanto o núcleo volta a
enxergar a preimagem como plugin.

---

## 14. Destino de formulário vazio é BLOCKED, e preenchido-e-inválido continua FALHA

**Decidido.** A etapa de formulários passou a ter três saídas, e elas não são
intercambiáveis: chave de destino declarada e **vazia** fecha **BLOCKED** nomeando a
chave de `config/site.json` a preencher; chave **preenchida** com valor que o regime não
aceita continua **FALHA**; entrada sem `destino` declarado também é **FALHA**. O
veredito mora numa função pura, `F3Base_Imp_Lotes::veredito_destino()`, e os três ramos
são exercitados em `formulario.veredito_destino`.

**Por quê.** `contato.whatsapp_e164` nasce vazia no template **por desenho** — é dado do
projeto, não defeito do pacote. A regra do documento é explícita: pré-condição ausente
NUNCA é FALHA, é BLOCKED com o motivo. Um relatório que grita FALHA por dado de projeto
ausente treina o leitor a ignorar FALHA, que é o pior resultado possível de uma suíte.

**O que custa.** BLOCKED interrompe a cadeia dependente, e essa é a consequência
deliberada: com a chave vazia, a execução para naquela unidade, as etapas seguintes
(cadência, entrega e encerramento) não rodam, e o implantador **não** se autodesativa. A
saída do operador é preencher a chave e iniciar uma execução nova — que é exatamente o
que deveria acontecer, porque uma entrega que se declara concluída com o destino do lead
em branco é uma entrega que mente.

**Como reverter.** Voltar `etapa_formularios()` a `avaliar()` com um booleano só. A
reversão devolve a FALHA por dado de projeto ausente e desfaz a distinção entre "falta
preencher" e "está errado", que é a distinção inteira desta decisão.

---

## 15. Origem de plugin por URL, em https, com precedência declarada

> **Atualizada na 1.0.19.** A lista fechada de hosts que este título dizia saiu do pacote;
> o que ficou está na decisão 45, e é ela que explica por que a lista nunca foi o controle
> que aparentava ser. O resto desta decisão continua valendo como escrito.

**Decidido.** Cada entrada de `plugins.instalaveis` declara a `origem`, e a resolução
tenta três caminhos nesta ordem: o slot embutido `assets/plugins/<slug>.zip`, sem rede; a
URL declarada na própria entrada, **em https**; e o WordPress.org. Toda entrada de
origem `url` também declara `pasta_esperada`, e a pasta criada pelo instalador é lida do
resultado e reconciliada com ela antes da ativação.

**Por quê.** O servidor MCP e o complemento do canal não existem no WordPress.org, e a
única origem prevista era ela: o canal fechava BLOCKED e a fase de manutenção não
existia. A precedência com o slot na frente resolve o caso offline sem mudar uma linha de
configuração — quem não tem rede põe o zip no slot. E a reconciliação de pasta existe
porque zip de código-fonte de repositório extrai como `<repo>-main`, e ativar pelo slug
procurava em um diretório que não estava lá.

**O que custa.** Baixar código executável de um host que não é o repositório oficial é
uma fronteira de confiança a mais, e ela é real. O que a guarda entrega hoje: HTTPS
obrigatório em todos os saltos — autenticidade de origem e integridade em trânsito — e o
digesto, que amarra o BYTE baixado. O que ela não entrega: escolher por você de qual
projeto o artefato vem. Isso é a URL declarada, e quem a escreve é quem monta o projeto.
Custo secundário: origem por URL não anuncia versão como o WordPress.org anuncia — a
versão precisa ser lida do cabeçalho dentro do artefato já baixado, e isso é uma leitura
a mais em todo ciclo.

**Como reverter.** Trocar a `origem` da entrada para `wordpress.org` só faz sentido
quando o artefato passar a existir lá. Enquanto não passar, a reversão real é o slot:
colocar o zip em `assets/plugins/<slug>.zip` remove a rede do caminho sem tirar o plugin
do catálogo. Apagar a `url` da entrada bloqueia aquela origem, com o BLOCKED nomeando a
chave que falta — e o efeito, declarado, é o canal MCP voltar a fechar BLOCKED.

---

## 16. Dependência declarada por unidade, e diagnóstico que não depende de ninguém

**Decidido.** O plano de execução tem um grafo de dependências declarado por grupo em
`F3Base_Imp_Plano`, e a suspensão em cascata depois de um BLOCKED segue o fecho
transitivo desse grafo. Os grupos `mcp`, `entrega` e `encerramento` declaram lista vazia
de dependências, de propósito.

**Por quê.** O orquestrador abortava, depois de um BLOCKED, tudo que vinha depois — a
dependência era a POSIÇÃO na lista. `formularios` fechou BLOCKED por um destino de
WhatsApp vazio, que é o estado correto e esperado desta base, e derrubou `cadencia`,
`entrega` e `encerramento`, nenhuma das quais depende do destino de um formulário. O
efeito prático foi o pior possível: `mcp.canal_configurado` — a única linha que diria ao
operador se o canal está exposto — não rodou, e o operador ficou olhando "Servidor MCP
não detectado" na tela do complemento sem nenhuma evidência do nosso lado. Unidade que
diagnostica não pode ser suspensa pelo que ela diagnostica.

**O que custa.** Uma tabela a mais para manter, e ela é fácil de errar em silêncio:
dependência para grupo inexistente viraria aresta que some. O custo é pago com detector —
`estatica.plano_dependencias` roda a própria função de conferência contra o pacote e
contra as fixtures do piso, reprovando grupo inexistente, autoloop e ciclo. Segundo
custo: "independente" passou a ser afirmação declarada, e afirmação declarada errada é
pior que ordem implícita — uma unidade que realmente dependesse de outra e fosse
declarada livre rodaria sobre estado incompleto.

**Como reverter.** Voltar à cascata por posição significa apagar a tabela e deixar o
orquestrador abortar tudo o que vem depois do primeiro BLOCKED. A consequência está
medida e nomeada acima: o diagnóstico do canal desaparece justamente na execução em que
ele é a dúvida. Não há caminho de reversão que preserve isso.

---

## 17. Uma fonte de verdade por veredito de gate

**Decidido.** A unidade `mcp` é o único ponto do pacote que deriva os dois vereditos de
canal — `mcp.canal_configurado` e `mcp.canal_exposto`. Ela grava o que mediu no registro
da execução, e a entrega e o encerramento **leem** esse registro em vez de recalcular.
Sem registro, o estado é BLOCKED dizendo que a unidade não rodou.

**Por quê.** A linha 14 de um relatório real dizia que as 12 rotas estão registradas e há
servidor MCP ativo expondo-as (OK), e a linha 41 do MESMO relatório dizia que o canal não
está exposto (FALHA). Não era o site oscilando: eram duas implementações do mesmo
veredito — a unidade media pelas habilidades registradas, somando Abilities API e rota
REST, e o encerramento recalculava por conta própria a partir da checagem antiga, que só
enxerga rota REST. Junto com isso ficou declarada uma distinção que o relatório precisava
preservar: **rota registrada** e **rota exposta por MCP** são fatos diferentes, e o
estado do meio — registradas e não expostas — precisa sair com esse nome, não como
"canal incompleto".

**O que custa.** Um estado a mais no banco durante a execução, e uma ordem que passou a
importar: quem lê precisa rodar depois de quem grava. O caso em que a unidade não roda
deixou de produzir um veredito e passou a produzir BLOCKED — mais linhas bloqueadas no
relatório, e é o preço certo: BLOCKED nomeado vale mais que um número recalculado por
quem não mediu.

**Como reverter.** Não há reversão sensata: recalcular em dois lugares é o defeito. O que
existe é extensão — outro veredito de gate entra na mesma lista, com um único derivador,
e `estatica.gate_fonte_unica` é o detector que reprova o segundo derivador de qualquer um
deles.

---

## 18. Slug declarado obrigatório, e slug determinístico para o anexo gerenciado

**Decidido.** Toda entrada de `paginas` e de `posts` declara `slug` não vazio, e nenhum
se repete entre elas — a home passou a `inicio`. Todo anexo gerenciado recebe slug
determinístico derivado do prefixo técnico e da referência lógica, declarado no sideload
e não deduzido do título; o slug anterior é liberado antes da troca e fica gravado em
`_f3base_old_slug` para o `site-core` redirecionar.

**Por quê.** Sem `post_name` declarado o núcleo deriva o slug do título e desambigua em
silêncio. Para tipo hierárquico, `wp_unique_post_slug()` consulta
`post_type IN ('page','attachment')` — ou seja, um anexo pode tomar o slug de uma página.
Foi o que aconteceu: três itens de mídia com o mesmo `alt` produziram `metodo-f3`,
`metodo-f3-2` e `metodo-f3-3`, e um deles tirou o slug da home. A leitura de volta
reprovava depois, com a causa longe do sintoma.

**O que custa.** Duas coisas. A configuração ficou mais verbosa: `slug` deixou de ser
opcional em toda entrada, e o detector `config.slug_declarado` reprova a omissão. E a
troca de um binário de mídia passou a mexer no slug do anexo anterior — o anterior não
sai do site, mas passa a viver sob outro nome, e é por isso que `_f3base_old_slug` é
gravado no mesmo passo. Sem essa gravação, um link para o arquivo antigo quebraria.

**Como reverter.** Não há reversão de "slug declarado" que não reintroduza a colisão
silenciosa. O que se pode mudar é o slug de uma entrada específica: trocar o valor no
`config/site.json` faz o gravador renomear e registrar o anterior para redirecionamento,
que é o mesmo mecanismo, usado de propósito.

---

## 19. Dois tetos declarados: cópias preservadas e troca de artefato idêntico

**Decidido.** As cópias preservadas de cada troca de diretório têm teto por slug, vindo
de `plugins.backups_preservados` — hoje 2. Acima do teto, as mais antigas saem do disco
na unidade de poda, **nomeadas**, e a operação entra no journal. E a troca de diretório é
**pulada** quando o artefato disponível é idêntico ao instalado, com a versão lida do
cabeçalho dentro do próprio artefato quando a origem não a anuncia.

**Por quê.** Os dois são crescimento sem teto, medidos em execuções sucessivas: o disco
acumulando uma cópia por execução, e a troca sendo refeita a cada execução porque origem
por URL não anuncia versão e todo plugin de origem `url` caía no ramo "versão não
anunciada". Preservar a instalação anterior é desenho correto; preservar todas elas para
sempre não é.

**O que custa.** A poda é irreversível por natureza — o diretório sai do disco, e o
journal registra a operação sem poder desfazê-la. É por isso que o teto vem da
configuração e nunca de número escrito no código, que a remoção é por slug e da mais
antiga para a mais nova, e que o que sai sai nomeado no relatório. Custo da segunda
regra: pular a troca quando o artefato é idêntico significa confiar na versão do
cabeçalho; artefato com cabeçalho mentindo sobre a própria versão não seria trocado.

**Como reverter.** Subir `plugins.backups_preservados` guarda mais gerações; baixar para
zero desliga a preservação e passa a manter só a instalação corrente. Para forçar a troca
de um artefato idêntico, o caminho é subir a versão no cabeçalho do artefato — que é a
mesma disciplina de bump de versão que o tema já segue, e não uma exceção.

---

## 20. Conteúdo publicado que o pacote não gerencia: WARN, nunca remoção

**Decidido — e com UMA exceção aberta na 1.0.17, declarada na decisão 31.** Página ou
post publicado que não tem `_f3base_managed_id`, não consta de `paginas` nem de `posts`
e não entrou sob gestão por adoção declarada é **relatado em WARN**, nomeado, e não é
tocado. A exceção é estreita e tem discriminante próprio: o conteúdo de exemplo do
WordPress que **ainda é** o que `wp_install_defaults()` criou vai para a lixeira. Tudo o
mais — inclusive o objeto que ocupa o slug de exemplo e deixou de ser exemplo — continua
sob esta decisão.

**Por quê.** Duas obrigações opostas, e as duas valem. Não se apaga: remover conteúdo
publicado que o pacote não gerencia, sem autorização, é perda sem registro — e o que
parece página de exemplo do núcleo pode ter virado página de verdade, com link apontando
para ela. E não se cala: até esta release o pacote nem relatava, e o operador entregava
um site com `Sample Page` e `Hello world!` publicados sem ninguém dizer nada. A remoção é
decisão do projeto; dizer que ela existe é obrigação do implantador.

**O que custa.** Uma linha WARN em toda execução de um site que tenha conteúdo externo
publicado — e um site com muito conteúdo não gerenciado produzirá uma linha que o
operador vai aprender a ignorar. É o custo aceito: WARN não é gate, não impede a
autodesativação e não reprova nada. O site não está defeituoso, está com uma decisão em
aberto.

**Como reverter.** Duas saídas, e as duas são decisão declarada: adotar o conteúdo,
trazendo-o para `paginas` ou `posts` com `adotar_existente`, o que faz o WARN sumir
porque ele passa a ser gerenciado; ou removê-lo à mão no wp-admin, que é onde uma remoção
com autor e responsável deve acontecer.

---

## 21. Permalinks: aplicar a estrutura declarada e COBRIR o que muda de endereço

**Decidido — e REVISADO duas vezes, na 1.0.11 e na 1.0.17.** A decisão original desta
entrada foi `ambiente.permalinks_decisao` nascer em `manter-existente`: qualquer
divergência de estrutura fechava BLOCKED sem escrita. A 1.0.11 trocou o padrão por
`aplicar-se-seguro`, que MEDE antes de decidir. A 1.0.17 trocou de novo, e o padrão hoje
é **`aplicar-e-cobrir`**: aplica a estrutura declarada **e grava 301 do caminho antigo
para o novo de todo conteúdo publicado que muda de endereço — gerenciado por este pacote
ou não**. O par entra na união declarada de `f3base_redirects` com origem própria, pelo
mesmo produtor único das outras fontes, e o par cujo caminho **não** muda continua sendo
descartado, porque redirecionar um endereço para ele mesmo é laço: `/sample-page/` sob
`/%postname%/` é exatamente esse caso e não pode ganhar par. O relatório **nomeia** cada
URL coberta em vez de contá-las. Os três valores anteriores continuam declaráveis, com o
comportamento de sempre.

As revisões estão escritas AQUI, na entrada original, e não em entradas novas: decisão
superada que fica de pé no registro é a mesma família de defeito que o carimbo velho em
documento entregável — o leitor encontra a afirmação errada e não tem como saber que ela
caducou.

**Por quê — e a RESERVA QUE FOI APOSENTADA na 1.0.17.** Mudar a estrutura de permalinks
reescreve a URL de todo conteúdo publicado de uma vez. Num site que já tem links, índice
de busca e campanhas apontando para as URLs antigas, é a mudança mais cara que uma
execução pode fazer em silêncio — e por isso o padrão anterior recusava aplicar diante de
publicado não gerenciado com URL de caminho. A justificativa da recusa era: **este pacote
não escreve redirecionamento para conteúdo que não gerencia**.

Essa reserva foi aposentada, e o motivo é o que ela confundia. A reserva é boa para
escrita **DESTRUTIVA** — apagar, sobrescrever, promover status de objeto alheio —, e
estava sendo aplicada **por analogia** a uma escrita que não destrói nada. Um par de
redirect é **aditivo e reversível**: não altera o objeto de ninguém, não apaga nada, não
muda um byte do conteúdo, e some junto com a option quando a option some. O que a recusa
comprava era zero; o que ela custava era entregar o site com a estrutura de permalink que
**ninguém escolheu**, por causa de duas páginas que o próprio WordPress cria em toda
instalação. Dano maior do que a reserva evitava.

A orientação que decidiu isto é explícita: o implantador deve realizar todas as
modificações necessárias para fazer a página funcionar, alterando conteúdo preexistente
se preciso. Medir, recusar e devolver ao operador uma lista de opções para escolher à mão
é exatamente o passo manual que este pacote existe para eliminar.

**O que custa.** Uma escrita a mais na option `f3base_redirects` por objeto de terceiro
que mudou de endereço — cada par nomeado no relatório, cada um carimbado com a origem
`computado:wordpress.permalinks`. E custa uma responsabilidade nova: o pacote passa a
manter no ar o endereço antigo de conteúdo que não é dele. É responsabilidade barata,
porque o mecanismo é o do `site-core` que já existia, casado em `template_redirect` com
prioridade 1, antes do 404.

**Como reverter.** Declarar `aplicar-se-seguro` devolve o comportamento da 1.0.11 —
aplica só quando nenhum publicado não gerenciado tem URL de caminho, e fecha BLOCKED
nomeando os objetos quando tem. `aplicar-declarada` aplica sem cobrir terceiro.
`manter-existente` não aplica nunca. Para desfazer a cobertura já gravada, remover os
pares da option: eles não deixam rastro em nenhum objeto, que é a propriedade que
autorizou gravá-los.

---

## 22. A política de privacidade é declarada para produção, e uma guarda medida decide

**Decidido.** `paginas[privacidade].status` passa a `publish`, como o de toda página
deste pacote, e o status EFETIVO passa a sair de um produtor único —
`F3Base_Imp_Conteudo::status_efetivo_de_pagina()`, declarado na âncora
`produtor_de_status_de_pagina()` e conferido por `estatica.pagina_status_fonte_unica`.
Esse produtor rebaixa a política para `draft` enquanto `razao_social`, `documento` ou
`endereco` de `contato.controlador` estiverem vazios, e o registro da execução nomeia
**quais** estão vazios e o caminho de saída: preencher e reexecutar, sem passo manual.
A checagem `privacidade.controlador_identificado` fecha BLOCKED nesse caso, OK quando a
qualificação aparece no conteúdo lido de volta do objeto, e FALHA quando as chaves estão
cheias e a qualificação não está no texto servido. `encarregado` é opcional pelo art. 41:
vazio, o texto diz que o canal de contato do site recebe os pedidos; preenchido, a
redação nominal entra no lugar. As duas redações moram no arquivo de conteúdo, em blocos
que se excluem pela condição declarada no atributo, e nenhuma é escrita em PHP.

**Por quê.** A regra do dono é categórica: toda configuração do implantador já cria um
site pronto para produção e para ser indexado; quem não quiser muda a chave à mão. A
1.0.12 aplicou isso à indexação e deixou UMA exceção declarada pelo próprio agente e
nunca ratificada — a política de privacidade entregue em estado não público, em silêncio.
A exceção tinha um motivo real: o texto da página identificava o controlador com valores
que só o operador tem, e política publicada sem dizer quem é o controlador é notificação
deficiente na face do art. 9º da LGPD. Mas motivo real não autoriza decisão calada, e a
1.0.12 chegou a um estado pior que os dois: a configuração já dizia `seo.indexar: true`
enquanto o último parágrafo do texto afirmava o contrário sobre a mesma página.

A correção é a mesma inversão da indexação. A intenção declarada é produção; o que segura
é uma **guarda medida**, que nomeia a si mesma, o valor observado e a saída — o mesmo
formato de `contato.whatsapp_e164`. E a guarda não é uma espera por revisão jurídica: a
revisão continua sendo do responsável pela operação, e o texto da página diz isso.

**O que custa.** Uma pré-condição a mais no template, e ela é visível: em instalação
recém-configurada, `privacidade.controlador_identificado` fecha BLOCKED e a unidade
`wordpress.paginas_especiais` é promovida a BLOCKED junto — exatamente como
`formularios.regimes` já fica por causa de `contato.whatsapp_e164`. Nenhuma das duas
impede a autodesativação, porque o gate de aplicação lê entregáveis, não unidades. Custa
também um mecanismo novo de conteúdo: marcador nomeado e bloco condicional no arquivo
editorial. O risco desse mecanismo é o marcador sobreviver até a página publicada, e é
por isso que a leitura de volta o procura no conteúdo servido e fecha FALHA se o achar.

**Como reverter.** Declarar `paginas[privacidade].status` como `draft` devolve a página
ao estado não público por decisão do PROJETO — o produtor nunca promove o que foi
declarado, e a diferença em relação ao que esta release corrigiu é que agora a decisão
está escrita na configuração e não escondida no código. Para desligar a guarda sem
desligar a página, basta preencher as três chaves. Remover a guarda inteira é apagar o
ramo do produtor, e aí a política volta a poder ser publicada sem identificar o
controlador: é a reversão que a LGPD desaconselha, e ela precisa ser deliberada.

---

## 23. A identidade da política mora no papel da página; o número em documento é gerado

**Decidido.** Três correções que a revisão da 1.0.13 transformou em defeito, e uma delas
é a que impede a recorrência das outras duas.

1. **O gate de página publicada vale para os DOIS produtores de seleção de `llms.txt`.**
   A 1.0.13 gateou `f3base_llms` pelo artefato e deixou `wpseo_llmstxt` receber
   `privacy_policy => <id>` sem gate nenhum. Agora existe um gate único —
   `F3Base_Imp_Conteudo::id_de_pagina_publicada()` — e dois produtores finos que passam
   por ele, ambos declarados na âncora que `estatica.llms_so_pagina_publicada` lê.
2. **A identidade da política mora em `paginas[*].papel`.** Ela era lida de
   `seo.llms_selecao.politica_privacidade`. A seleção do `llms.txt` passou a REFERENCIAR
   o produtor por um booleano de inclusão, em vez de possuir o fato.
3. **Número em documento entregável é gerado, não digitado.** README, MANIFESTO e
   MEMORIA-DECISOES carregam regiões geradas por leitura de disco na primeira etapa do
   comando único, e `estatica.carimbo_de_release_nos_documentos` compara o que está no
   disco com o que a medição de agora produz.

**Por quê.** O item 1 tinha uma justificativa errada e vale registrá-la: o agente não
gateou o segundo produtor porque não havia medido o que o plugin de terceiro faz com o
identificador de uma página não publicada. O teste é outro — não é o que o consumidor
faz, é se ESTE pacote deve entregar o identificador de um rascunho a um slot chamado
`privacy_policy` que alimenta um arquivo publicado. Não deve, faça o consumidor o que
fizer: a escrita está errada na origem, e não é preciso medir o consumidor para saber
disso. E havia consequência para a suíte: um detector que gateia um produtor e deixa o
segundo passar promete, pelo nome, mais do que mede — compra silêncio sobre o defeito
que continua lá.

O item 2 é uma questão de onde um fato pode morar. A identidade da página de política é
exigida pelo art. 9º da LGPD e é fato do SITE. Pendurada numa chave que nomeia uma
seleção de `llms.txt`, ela ficava à mercê de uma operação legítima: desligar
`bots_ia.llms_txt` e limpar a seleção parava de gravar `wp_page_for_privacy_policy` e
derrubava a checagem legal em "condição de aplicabilidade falsa", sem nada acusar. O que
impede a recorrência não é o nome novo da chave: é a cláusula do detector que PROÍBE o
produtor de ler qualquer caminho fora de `paginas.*`.

O item 3 é o mais importante dos três, e não é sobre esta release. Da 1.0.6 à 1.0.13 os
três documentos entregáveis ficaram carimbados `1.0.6`, afirmando `ambiente.dominios_autorizados`
como gate de indexação e `manter-existente` como padrão de permalinks — os dois superados
por releases posteriores — e imprimindo contagens que a rodada da vez contradizia. Sete
releases passaram por cima disso. Corrigir os números à mão era adiar: eles envelheceriam
de novo na próxima release. O que não envelhece é a regra de que o número sai de leitura
de disco no empacotamento, e o detector que reprova quando o disco e o documento
divergem. As duas afirmações de desenho superadas entraram em
`copy_contrato.nao_podem_voltar`, que já varre o pacote inteiro.

**O que custa.** Três coisas. (a) Os documentos passam a ter regiões que não se editam à
mão: quem escrever dentro delas perde o texto na próxima rodada, e é por isso que cada
região diz, no próprio corpo, que é gerada. (b) A contagem por estado da rodada NÃO pode
entrar no carimbo, porque ela só existe depois das checagens e o carimbo é escrito antes
do bundle; ela sai como pendência nomeada apontando para `suite/rodada.json`, que é
o artefato gerado que a carrega. (c) O empacotamento passou a ESCREVER no pacote antes de
medi-lo. O risco disso é conhecido — artefato que se modifica antes de ser conferido — e
está contido por três coisas: a escrita só acontece quando o conteúdo muda, ela é a
primeira coisa da primeira etapa, e o que ela escreve é comparado de volta em etapa 2
pelo detector.

**Como reverter.** Tirar os marcadores de um documento o devolve à edição manual, e o
detector acusa a ausência deles — a reversão é possível e não é silenciosa, que é a única
forma aceitável. Voltar a identidade da política para uma chave de outra seção exige
apagar a cláusula 3 de `estatica.politica_privacidade_fonte_unica`, e aí o registro
mostra que a proteção foi removida de propósito. Tirar o gate de um dos dois produtores
exige apagá-lo da âncora, e o detector reprova na cláusula que cobra que todo produtor
declarado passe pelo gate.

## 24. WARN só existe com achado adverso; o estado sai da medição

**Decidido.** Nenhuma checagem do runtime emite WARN como retorno incondicional ou único.
Medição que validou, aplicou, declarou ou ficou dentro do esperado fecha **OK**, com o
detalhe no texto da linha; medição que encontrou algo **adverso e que não bloqueia** fecha
**WARN**, nomeando o que está adverso e a consequência. As seis emissões que saíam sempre
foram reescritas assim: `preflight.limites` compara com o piso declarado em
`ambiente.limites_minimos`; `config.schema_declarado` mede se o schema está declarado e se
houve erro de validação; `lgpd.base_legal_declarada` mede se a base legal e o prazo de
retenção existem; `config.chaves_lidas_nesta_execucao` mede se o pacote AFIRMA, em
`consumidores_declarados`, que toda chave tem consumidor; `plugins.politica_versao` mede se
as duas políticas estão declaradas; `tema.declaracoes` mede se toda fonte auto-hospedada
declarada tem arquivo no pacote.

**Por quê.** Na execução real da 1.0.14 nove checagens fecharam WARN sem achado adverso
nenhum, e cada uma promoveu a unidade dela: quatro unidades amarelas numa execução em que
nada estava errado. As frases são literais do log — "a configuração declara o schema e
validou contra ele", "política aplicada: ultima-da-fonte-oficial", "lista vazia é estado
válido" — e `preflight.limites` dizia de si mesma "fato de ambiente, relatado sem decidir
gate" enquanto promovia a unidade. É a mesma família da checagem que acusava o próprio
pacote e das 24 FALHA por ausência de terceiro: relatório que grita treina o leitor a
ignorar o grito, e essa lição já estava escrita no documento mestre — faltava valer para
WARN.

**A correção NÃO foi um sétimo estado.** Os seis são regra do contrato. O que mudou é de
onde o estado vem: da medição, não do desejo de ver a informação na tela. A informação
continua na linha; o que ela deixou de fazer é pintar de amarelo o que estava certo.

**O que custa.** Duas coisas. (a) Uma linha OK é lida com menos atenção que uma WARN, e
detalhe que só existia para ser visto — os limites do PHP, o hash da configuração — passa a
sair no corpo de uma linha resumida. É o preço de o amarelo voltar a significar alguma
coisa. (b) Um piso novo entrou na configuração: `ambiente.limites_minimos`. Piso declarado
errado produz WARN sem achado, que é o defeito que esta decisão fecha — por isso ele é
declarado por projeto e não literal no código.

**O piso.** `estatica.warn_tem_ramo_adverso` varre `includes/` e `fontes/` e acusa todo
WARN que não esteja dentro de um ramo (`if`, `elseif`, `else`, `foreach`, `for`, `while`,
`switch`, `match`, ternário) nem depois de uma cláusula de guarda que possa impedi-lo. A
fixture negativa reproduz a emissão incondicional de `preflight.limites`; a positiva traz
as duas formas legítimas. `preflight.limites_veredito` exercita os dois lados do veredito na
sonda, um achado por limite, com `max_execution_time = 0` tratado como ausência de limite —
o piso do falso positivo.

**Como reverter.** Emitir WARN fora de ramo volta a ser possível apagando o detector do
runner e do registro do piso, e aí a rodada mostra que a proteção foi removida de propósito.

## 25. Cópia preservada de cópia preservada colapsa na série do slug real

**Decidido.** `F3Base_Imp_Plugins::serie_do_nome()` normaliza a chave da série: marca de
backup embutida no resto do nome colapsa na série do slug real, com qualquer profundidade de
aninhamento, e o carimbo que sobrevive é o EXTERNO — quando aquela cópia foi criada.

**Por quê.** No site real apareceu, em `wp-content/plugins/`, o diretório
`.f3base-anterior-f3base-site-core-f3base-anterior-1788152131-1788156801`: backup de um
diretório que já era backup. Cortando o slug no último traço, a chave virava
`f3base-site-core-f3base-anterior-1788152131` — série própria, com uma cópia só, que nunca
alcança o teto de duas e portanto nunca poda. O log fechou com sete cópias preservadas e a
frase "nada acima do teto": cada palavra verdadeira e a conclusão errada. O teto de
`plugins.backups_preservados` existia e não fazia nada.

**O que custa.** A normalização assume que a marca de backup é nossa e nunca faz parte do
nome legítimo de um artefato. Um plugin de terceiro cujo diretório contivesse a marca teria
a série truncada. A marca é montada a partir do prefixo do site, e um plugin de terceiro com
esse nome já colidiria com o pacote inteiro muito antes disto.

**O piso.** `plugins.serie_de_backup_normalizada` roda a MESMA função do runtime em
subprocesso, sobre a tabela de nomes que inclui o literal medido no site e o aninhamento
duplo. A fixture negativa é a leitura anterior, com o corte ingênuo, e ela é acusada
nomeando a série fantasma; a positiva é a leitura corrigida e fica em silêncio.

## 26. O pacote é um template de criação de sites, e o site demonstrativo fica

**Decidido.** Três coisas, e a terceira é o que impede as duas primeiras de virarem mentira.

1. **Cada site recebe o próprio prefixo.** `ferramentas/renomear-prefixo.sh` reescreve tudo
   o que está preso ao prefixo — nomes de diretório e de arquivo, prefixo de classe PHP,
   text domain, slugs de tema e de plugin, options, metas, classes CSS, handles e as chaves
   de configuração que os carregam. Dois sites da operação nunca compartilham nome de tema
   nem de option. A ferramenta recusa prefixo vazio, fora de `[a-z][a-z0-9-]`, em colisão
   com o espaço de nome do WordPress ou igual ao do próprio template, e é idempotente por
   construção: a busca é sempre pelo prefixo de ORIGEM, declarado em
   `ferramentas/prefixo-do-template.tsv`, que ela não reescreve.
2. **O site demonstrativo FICA, marcado como substituível.** Ele é o exemplo funcionante de
   cada padrão, e o agente que instancia o template copia dele. A herança é DECLARADA em
   `conteudo.demonstrativo` e marcada no topo de cada arquivo de `content/`.
3. **`TEMPLATE.md`** diz, em ordem, o que o agente faz para criar um site novo, separando o
   que muda por site do que nunca se toca, com o caminho exato de cada arquivo e chave.

**Por quê `MEMORIA-DECISOES.md` não é reescrito.** Este documento narra defeitos medidos
citando diretórios e nomes que existiram em sites reais — o backup de backup acima, o
cabeçalho de plugin aninhado, a option apagada por uma segunda gravação. Trocar o prefixo
nessas frases inventaria um passado que não aconteceu: nenhum site chamado de outra coisa
produziu aqueles diretórios. Havia duas saídas — reescrever cada frase para uma forma
verdadeira nos dois prefixos, ou declarar a exceção — e a escolha foi a exceção, declarada
em `ferramentas/excecoes-de-prefixo.tsv` e conferida por `estatica.sem_residuo_de_prefixo`.
Reescrever as frases para uma forma genérica custaria justamente o que dá valor a elas: o
nome literal que alguém pode procurar no `wp-content/plugins/` de um site. O documento viaja
com o pacote como história herdada, atribuída a quem a produziu, e o site novo abre o
próprio registro.

Essa decisão teve um corolário no código: **os marcadores de região gerada perderam o
prefixo**. Com `f3base:gerado` dentro deles, o documento não reescrito ficaria com
marcadores que o gerador renomeado não encontraria mais, e a região gerada deixaria de ser
regenerada em silêncio — o defeito da 1.0.6 à 1.0.13 voltando por uma porta nova. O marcador
delimita uma região dentro dos documentos do próprio pacote, não disputa espaço de nome com
ninguém, e sem prefixo o documento é o mesmo nos dois prefixos.

**O uso correto de WARN, em oposição ao item 24.** Com `conteudo.demonstrativo = true` e
`ambiente.tipo = "producao"`, `conteudo.demonstrativo` fecha WARN nomeando as páginas que
continuam sendo do template: publicar um site de cliente com a prosa do método é achado
adverso de verdade. É a única linha amarela da rodada limpa deste pacote, e ela some no
passo em que o conteúdo é substituído.

**A saída barata está fechada.** Desligar `conteudo.demonstrativo` sem trocar o conteúdo cala
o aviso e deixa o site do template no ar com a configuração afirmando que o texto é do
cliente. `conteudo.marca_demonstrativa` acusa a divergência arquivo a arquivo na suíte, e a
guarda de publicação **recusa** o objeto em tempo de aplicação, nomeando o arquivo, a marca e
as duas saídas.

**O que custa.** (a) A renomeação acontece uma vez, a partir do template: renomear o já
renomeado não é suportado, e o texto da ferramenta diz isso. (b) A lista de exceções é uma
superfície que precisa ficar curta — hoje são quatro entradas, cada uma com o motivo escrito
ao lado, e `estatica.sem_residuo_de_prefixo` cobra que nada sobreviva fora delas. (c) O
detector só roda de verdade sobre um pacote já renomeado; enquanto `site.prefixo_tecnico` for
o prefixo do template ele fecha N/A com a condição declarada, e quem prova que ele sabe
acusar é o piso de fixture, em toda rodada.

**Como reverter.** Apagar `ferramentas/` devolve o pacote a um prefixo único e o detector de
resíduo reprova por falta do registro de origem — a remoção é possível e não é silenciosa.
Voltar `conteudo.demonstrativo` a não existir exige removê-la do schema e do `site.json`, e
aí a guarda de publicação e as duas checagens somem juntas, o que o cruzamento bidirecional
do manifesto acusa.

---

## 27. A invalidação de cache pertence a quem trocou o diretório

**Decidido.** `trocar_diretorio()` derruba o cache do núcleo para o artefato que
acabou de mover — `wp_clean_themes_cache()` para tema, `wp_clean_plugins_cache()`
para plugin — antes de qualquer leitura de volta, e a leitura de volta passa a
ser um produtor único, `leitura_de_volta_do_artefato()`, que mede o **diretório**
(`is_dir`, e o arquivo principal dentro dele) **ao lado** da API do WordPress.
Diretório ausente diz "não apareceu no disco"; diretório presente e completo com
a API discordando diz **defeito de cache**, nomeado como tal; e diretório presente
sem o arquivo principal é um terceiro fato, com mensagem própria. A quarta linha da
tabela é o piso do falso positivo: quando a API **enxerga** o artefato e o caminho
medido não o traz — site com mais de uma raiz de temas registrada —, o veredito é
ok e a mensagem registra o fato, porque a API é quem manda no "está instalado" e a
medição de disco existe para discriminar a falha, não para criar uma.

**Por quê.** A 1.0.15 foi instalada num WordPress recém-criado e reprovou com
`FALHA tema — o tema não apareceu no disco depois da instalação` e o mesmo para o
site-core, enquanto a unidade de auto-update, três linhas abaixo da MESMA rodada,
enumerava `f3base-site-core 1.0.0` entre os plugins instalados. O diretório estava
no disco. `Theme_Upgrader::install()` chama `wp_clean_themes_cache()` e
`Plugin_Upgrader::install()` chama `wp_clean_plugins_cache()`; a troca controlada
de diretório não passa pelo upgrader e não chamava nem um nem outro —
`wp_clean_themes_cache` não aparecia uma única vez no pacote. Numa instalação
limpa a etapa consulta o estado antes da troca, o núcleo memoriza o **negativo**
na mesma requisição, a troca acontece, e a leitura de volta relê o cache.

A invalidação mora dentro de quem trocou, e não no chamador, porque há **três**
chamadores — tema, site-core e embarcado — e chamador que esquece é o defeito
voltando. A mensagem se separou em duas porque "não apareceu no disco" dito sobre
um diretório que está lá manda o operador procurar no lugar errado.

**Por que só apareceu na 1.0.15, e essa é a lição.** Toda execução de produção
anterior rodou em site que **já tinha** tema e site-core instalados. Ali a consulta
prévia memorizava o POSITIVO e a leitura de volta passava por acidente. A checagem
atravessou quinze releases sem nunca ter sido exercitada no caminho que importa:
o piso dela nunca teve alvo inexistente. É exatamente o que a disciplina de teto e
piso existe para impedir, e falhou aqui.

**O que custa.** (a) Uma limpeza de cache por troca de diretório executada — custo
real e pequeno, e só quando a troca aconteceu: o ramo "artefato idêntico, nenhuma
troca" não invalida nada. (b) Uma sonda a mais no comando único
(`suite/lib/sonda-instalacao.php`), que monta um WordPress de mentira com caches
que memorizam o negativo e roda o `aplicar_tema()` e o `aplicar_site_core()` REAIS
contra ele. Ela é o piso que faltava: com a invalidação desligada a leitura de
volta **precisa continuar cega**, ou a bancada não estaria reproduzindo o defeito;
com ela ligada, precisa enxergar o artefato. O sandbox começa com o alvo
**inexistente**, e a sonda recusa rodar sobre alvo existente — o piso que passou
quinze releases.

**Como reverter.** Tirar a chamada de dentro de `trocar_diretorio()` devolve o
comportamento da 1.0.15, e `estatica.troca_invalida_cache` acusa na mesma rodada,
com `instalacao.limpa_le_de_volta` medindo o efeito. A reversão é possível e não é
silenciosa.

---

## 28. Fonte única do artefato, e os zips da raiz deixam de viajar

**Decidido.** `F3Base_Imp_Plugins::artefato_do_papel()` é o único lugar que decide
qual artefato instala o tema e qual instala o site-core, e é dele que saem tanto a
instalação quanto a prova do entregável em `F3Base_Imp_Entrega`. A precedência não
mudou: o zip que o operador embute (`assets/plugins/<slug>.zip`, depois
`assets/<slug>.zip`) vence a fonte em `fontes/`. E o empacotamento **parou de
montar** `<tema>.zip` e `<site-core>.zip` na raiz do bundle.

**Por quê.** Da 1.0.14 à 1.0.15 o bundle viajava com `f3base.zip` (27.607 bytes) e
`f3base-site-core.zip` (76.414 bytes) na raiz, e **nenhum caminho de instalação os
abria**: a resolução de zip embutido procura sob os prefixos declarados, e a
instalação de tema e site-core lê `fontes/`. Eram 104.021 bytes dentro do hash do
pacote servindo de prova falsa de entrega. Ao mesmo tempo havia duas listas de
caminhos candidatos — uma no instalador, outra escrita à mão no conferidor de
entregável, que não conhecia o slot `assets/plugins/` — e duas listas para o mesmo
fato divergem por construção.

**Por que remover em vez de ligar ao instalador.** Três medições. (a) Segunda
representação do mesmo artefato deriva: o zip é montado no empacotamento, o
diretório é o que a instalação lê e o que `impressao_de_diretorio()` compara para
pular a troca quando nada mudou; editar `fontes/` sem reempacotar instalaria código
velho. (b) Ligar os zips moveria tema e site-core para o upgrader do núcleo no
mesmo passo em que esta release conserta a leitura de volta da troca de diretório —
trocar de caminho no instante de consertar o outro. (c) `trocar_diretorio()`
continuaria sendo o caminho de `aplicar_embarcado()`, que tem o defeito idêntico:
rotear por fora deixaria o defeito vivo no terceiro chamador e ainda tiraria a
cobertura que o pega.

**O que custa.** O bundle deixa de trazer o tema e o site-core em forma de zip
pronto para upload manual pela tela de plugins do wp-admin. Quem quiser essa forma
põe o zip no slot declarado `assets/plugins/`, que a fonte única lê com precedência
sobre `fontes/`. O hash do pacote muda, como em qualquer release.

**Como reverter.** Voltar o laço de montagem em `f3b_empacotar()` reintroduz os
zips, e `estatica.artefato_do_pacote_e_lido` reprova na mesma rodada enquanto eles
não estiverem sob um prefixo que a instalação lê — que é a forma correta de trazê-
los de volta, se um dia forem necessários.

---

## 29. Rejeição de lock para a tela; o cliente não avança sobre resposta que não avançou o plano

**Decidido.** Quatro regras no cliente e uma no servidor.

1. **A rejeição de lock encerra a tela na primeira ocorrência**, com UMA linha que
   diz o dono do lock, há quanto tempo é o último heartbeat, o TTL e o **horário
   exato** em que o lock passa a ser considerado abandonado.
2. **O avanço é decidido, nunca presumido.** `proximoLote()` só manda seguir quando
   a resposta é sobre a unidade que aquele pedido enviou e não se declara terminal;
   `dentroDoPlano()` recusa índice que o plano não tem.
3. **Todo caminho terminal fecha pelo mesmo produtor de rodapé**, e o estado da
   aplicação sai da lista que o servidor declara. Vazio não é estado fechado.
4. **Linha que não fecha OK é nomeada também no escopo da tela**: `nomeDaLinha()`
   dá nome de reserva à linha que o servidor mandou sem rótulo.
5. No servidor, toda resposta que a tela renderiza carrega `rotulo` e `aplicacao`,
   e a resposta de um lote que **não rodou** se monta num lugar só, `nao_rodou()`.

**Por quê.** O operador executou, deu erro, executou de novo, e a tela entrou em
laço: **163 linhas idênticas** de "execução concorrente rejeitada", com a idade do
heartbeat subindo de 38 até 90 segundos — o cliente repetiu por 90 segundos até o
TTL vencer. A causa é uma regra correta aplicada onde não vale: "BLOCKED não para
mais a execução inteira" é a regra da 1.0.13, e ela fala de **unidade que mediu**
pré-condição ausente. A rejeição de lock não é resultado de unidade nenhuma — o
lote não rodou, nada foi medido, não há o que continuar. Da mesma execução saíram
os outros três achados: `Etapa 94 de 40` (o contador contava requisições, não
unidades), `estado da aplicação:` vazio no rodapé, e "linhas desta tela: 163
BLOCKED" ao lado de "BLOCKED: nenhum" na lista por nome do mesmo escopo — a regra
de contagem-com-nomes furando no escopo do cliente, porque a resposta vinha sem
rótulo e a linha entrava na contagem sem entrar na lista.

**A ação de "assumir o lock" foi avaliada e NÃO é oferecida.** A medição: o lock
com heartbeat mais velho que o TTL **já é assumido automaticamente** —
`adquirir_lock()` faz a troca atômica e segue —, então o operador nunca fica refém
de uma execução morta por mais do que o TTL. Um botão de assumir só faria diferença
para um lock **dentro** do TTL, isto é, uma execução possivelmente viva; e da tela
não se distingue "morta" de "lote lento" — a instalação de um plugin por rede lenta
fica calada por dezenas de segundos, e o heartbeat é renovado por requisição, não
por segundo. Oferecer o botão seria uma segunda fonte de verdade para uma decisão
que já tem uma, e ela é a mesma proibição que `estatica.gate_fonte_unica` cobra em
outro lugar. O que o operador ganha é a **informação**: com o horário do abandono
na linha, "esperar" deixa de ser indefinido e vira um relógio.

**O que custa.** (a) A tela para em vez de seguir, e o operador precisa executar de
novo depois do horário informado — que é o comportamento correto para um lote que
não rodou, mas é um clique a mais do que a ilusão de progresso anterior. (b) O
servidor passa a carregar mais campos em toda resposta, e o cliente valida o estado
da aplicação contra uma lista que o servidor declara.

**Como reverter.** Devolver o avanço incondicional em `proximoLote()` traz o laço
de volta, e `js.decisoes_do_cliente` acusa na mesma rodada — inclusive contra a
resposta ANTIGA, sem os campos novos, que é o piso que prova que o cliente para
sozinho.

---

## 30. Duas formas de piso, e a segunda também tem piso

**Decidido.** "Ter piso" passa a admitir duas formas: a fixture negativa e positiva
em disco, como sempre, e o piso que mora **dentro da própria sonda** — declarado em
`suite/pisos-em-sonda.tsv`. A declaração não absolve: `f3b_tem_piso()` só a aceita
quando a sonda declarada existe, menciona a checagem e traz os dois ramos, teto e
piso; e `estatica.piso_em_sonda_declarado` — que tem fixture em disco como qualquer
outro detector — confere isso a cada rodada.

**Por quê.** `armadilhas.mapeadas` recusa mapear armadilha para checagem sem piso, e
a recusa está certa: armadilha declarada coberta por checagem que não sabe reprovar
é documentação melhor sobre uma suíte cega. Só que "piso" estava definido como uma
forma — fixture em disco — que serve a detector de análise estática e não serve a
sonda funcional, cujo caso negativo é um **mutante do próprio pacote**, não uma
árvore de arquivos. As armadilhas mais caras desta release — o cache negativo numa
instalação limpa, o laço de rejeição de lock — só são cobertas por sonda, e
declará-las como pendência seria mentir para a tabela.

**O que custa.** Uma superfície de declaração a mais, que precisa ficar curta. Ela é
verificada, não presumida, e a verificação exige da sonda exatamente o que uma sonda
cega não teria: as duas afirmações.

**Como reverter.** Apagar `suite/pisos-em-sonda.tsv` devolve a definição antiga de
piso, e as armadilhas que dependiam dela voltam a fechar `armadilhas.mapeadas` em
BLOCKED, nomeando quais — a reversão é possível e não é silenciosa.

---

## 31. Conteúdo de exemplo do WordPress vai para a lixeira, decidido por discriminante

**Decidido.** `conteudo.exemplo_do_wordpress` nasce em `lixeira`, ligado por padrão no
template. O que a etapa remove é apenas o objeto que **ainda é** o que
`wp_install_defaults()` criou, e a prova é conjunta:

1. **Identidade contra o que o núcleo produz.** Título e conteúdo idênticos ao que
   `wp_install_defaults()` escreveria agora. O esperado não é um texto inventado por este
   pacote: ele sai das MESMAS chamadas de tradução que o instalador faz, com os mesmos
   msgids, no locale da instalação — é assim que se pergunta ao WordPress instalado o que
   ele mesmo escreveria.
2. **Ninguém editou.** `post_modified_gmt` igual a `post_date_gmt`, que é como o
   instalador grava os dois e o que qualquer gravação faz avançar.

Além disso, ficam intocados o objeto gerenciado por este pacote e o objeto **em uso** —
apontado por `page_on_front`, `page_for_posts` ou `wp_page_for_privacy_policy`.

O par tipo/slug **indexa a hipótese e não prova nada**: é ele que diz qual entrada do
catálogo comparar, e quem decide é a comparação. É a mesma regra que já governa a adoção
de objeto, onde slug igual sem a option do núcleo apontando para o objeto não adota nada.

Vai para a **lixeira**, nunca para exclusão definitiva: reversível pelo wp-admin,
registrada no journal com a operação inversa (`post.restaurar` com o `post_status`
observado), e conferida por leitura de volta. O relatório **nomeia** o objeto e imprime
**o discriminante que decidiu** — tanto o que removeu quanto o que preservou.

**Por quê.** `Hello world!` e `Sample Page` não são conteúdo de ninguém: são o que o
instalador insere em toda instalação. Deixá-los publicados num site entregue põe
`Sample Page` no sitemap, na seleção do `llms.txt` e na busca — e a decisão 20, que os
mandava relatar e nunca tocar, estava certa sobre conteúdo alheio e errada sobre resíduo
de instalação. A orientação do dono autoriza a diferença: o implantador deve realizar
todas as modificações necessárias para fazer a página funcionar, alterando conteúdo
preexistente se preciso.

O que **não** se autoriza é decidir por slug. Quem reescreveu o `Hello world!` para
publicar um texto de verdade continua com o slug `hello-world`, e apagar aquele objeto
seria perda de conteúdo real — o pior defeito que esta release poderia introduzir. É por
isso que o piso que importa é o **negativo**: a edição é plantada em título, em conteúdo e
nos dois, nos dois objetos do catálogo, e nenhum dos casos pode produzir remoção.

**O que custa.** Fragilidade deliberada, e ela cai para o lado seguro: se o núcleo mudar o
texto de um dos objetos numa versão futura, ou se o site tiver mudado de domínio depois da
instalação (a página de exemplo interpola `admin_url()` no último parágrafo), o esperado
deixa de casar e **nada é removido**. A divergência sai nomeada no relatório como
"conteúdo editado", e o operador decide. Preferir o falso negativo ao falso positivo é a
escolha correta quando o falso positivo apaga conteúdo de alguém.

Custa também uma unidade a mais no plano, posicionada **antes** da troca de estrutura de
permalinks. A ordem é decisão: o que sai daqui deixa de ser publicado, some da medição de
URLs de terceiro e não ganha um 301 para um endereço que passaria a 404; o que fica —
o objeto editado, intocável — continua publicado e é coberto pelo redirect da decisão 21.

**Como reverter.** Declarar `conteudo.exemplo_do_wordpress: "manter"` desliga a etapa: o
exemplo fica publicado por decisão do projeto e volta a ser apenas relatado por
`conteudo.nao_gerenciado_publicado`. O que já foi para a lixeira volta com um clique em
Restaurar, ou pelo `rollback` do journal.

---

## 32. O sequestro do assistente do wp-mcp-ultimate não se desarma por configuração

**Decidido.** `plugins.supressao_onboarding` **não** ganha entrada para
`wp-mcp-ultimate`, e a ausência é resultado de medição, não de esquecimento.

**O que foi medido.** O artefato foi baixado da origem declarada em
`plugins.instalaveis[wp-mcp-ultimate].url` — o zip
`wp-mcp-ultimate-main.zip` do repositório `Fator3Ventures/claude-wordpress` — e lido.
Versão do cabeçalho: `2.1.0`. O assistente é registrado em
`includes/Plugin.php`, **linha 60**:

```php
add_action('admin_init', [$this, 'maybe_redirect_to_dashboard']);
```

e o que ele consulta para decidir redirecionar está no mesmo arquivo, **linha 87**:

```php
if (!get_transient('wp_mcp_ultimate_activated')) {
    return;
}
```

O gatilho é posto em `wp-mcp-ultimate.php`, **linha 38**, dentro do
`register_activation_hook`: `set_transient('wp_mcp_ultimate_activated', true, 30)` — TTL
de trinta segundos. E é apagado na **linha 90** de `Plugin.php`, por
`delete_transient()`, na primeira requisição administrativa que o encontra, antes do
`wp_safe_redirect()` da linha 94. Não há `apply_filters` em nenhum ponto desse caminho.

**Por que não dá para desarmar por configuração.** O mecanismo **não é uma option**. É um
transiente de vida curta, consumido e apagado no primeiro uso. `supressao_onboarding`
grava `option.chave = false` pelo gravador único, e o transiente não tem chave dentro de
uma option para gravar: com cache de objeto persistente ele nem chega à tabela de options.
Declarar uma entrada ali gravaria uma option que ninguém lê — **lixo na instalação do
cliente**, que é exatamente o custo que uma entrada errada nesse mapa tem.

**Consequência aceita.** `lote.sequestro_por_terceiro` continua aparecendo uma vez por
execução em que o plugin seja ativado. Não é bloqueio: o cliente detecta o sequestro,
repete a MESMA unidade uma vez e segue — o transiente já foi apagado pela requisição
sequestrada, e a segunda chega ao implantador. A mensagem da tela deixou de prometer que
uma entrada no mapa resolveria: ela agora diz que a chave sai da LEITURA do artefato
daquele plugin, e que assistente decidido por transiente ou por filtro não se desarma por
configuração nenhuma.

**Como reverter.** Se uma versão futura do plugin passar a decidir por option ou expor um
filtro, a leitura do artefato mostrará isso, e a entrada declarada passa a existir com o
arquivo e a linha registrados aqui — que é o procedimento, e não a exceção.

---

## 33. A identidade da release é medida nos três lugares que a carregam

**Decidido.** `estatica.identidade_do_implantador` compara `release.identidade` e
`release.implantador` do `config/site.json` com o cabeçalho `Version:` de
`implantador-base.php` e com o fallback de bootstrap `F3BASE_IMP_VERSAO_DECLARADA`.
Divergência entre quaisquer dois é achado, nomeando os dois números.

**Por quê.** O `MANIFESTO.md` afirmava, em linha própria da tabela de estado, que
"`release.identidade` e o cabeçalho do implantador são a mesma coisa" — e **nenhuma
checagem media isso**. A afirmação era verdadeira por hábito: alguém lembrava de bumpar o
cabeçalho a cada release. Na 1.0.17 o hábito falhou de forma visível: a configuração foi
para `1.0.17`, o cabeçalho ficou em `1.0.16` e a constante de bootstrap ainda estava em
`1.0.15` — **três respostas** para "qual release é esta?", e a que o WordPress mostra na
lista de plugins é a do cabeçalho.

É a pior forma da doença que este pacote existe para tratar: não uma checagem que nunca
falhou, mas uma garantia **anunciada no documento entregável** sem checagem nenhuma por
trás. Vale mais do que a correção pontual — a correção pontual é bumpar o número, e é o
que já foi feito toda vez até parar de ser feito.

**O que custa.** Um detector a mais, com fixture negativa e positiva em disco, e uma
regra a mais para quem edita o pacote: o número da release passa a ter de mudar nos três
lugares, e a rodada acusa se um ficar para trás. É exatamente o custo que se quer.

**Como reverter.** Tirar a linha do registro do piso e do runner devolve o estado
anterior — e o MANIFESTO volta a afirmar sem medir, que é o que não pode acontecer de
novo.

---

## 34. O limite de campo é medido na unidade que o cliente corta

**Decidido.** O endpoint de leads mede limite de campo em **caracteres**, e o cliente
(`fontes/site-core/assets/f3base-leads.js`) corta em **caracteres**. O número continua
saindo de um lugar só — `limites_publicos()` —, e agora a UNIDADE também.

**Por quê.** O servidor media `strlen()`, que conta bytes; o cliente media `texto.length`,
que conta unidades UTF-16. Os dois recebiam o MESMO número. Com acentuação — isto é, em
português, sempre — o navegador aprovava um nome de 120 caracteres e o servidor devolvia
`400 f3base_limite_excedido` sobre 130 bytes. A recusa é dura por desenho ("recusado,
nunca truncado em silêncio"), então o lead se perdia inteiro, e a página que o aprovou era
a mesma que o pacote publica.

Caracteres, e não bytes nem unidades UTF-16, porque é a unidade que o humano que escreve
o nome percebe, e é a que o texto de recusa nomeia. O corte do cliente passou a andar por
`Array.from()`: cortar por `slice()` no meio de um par substituto devolveria metade de um
caractere, e o servidor receberia texto que ninguém escreveu.

**O que custa.** `mb_strlen()` no servidor (com queda para `preg_match_all('/./us')` onde
mbstring não existir) e uma alocação de array por campo no cliente. Um site que hoje
guarda nomes cortados em 120 bytes passa a aceitar até 120 caracteres — mais bytes na
coluna, o que é o comportamento que o limite declarado sempre prometeu.

**Como reverter.** Trocar `self::comprimento()` por `strlen()` reintroduz o defeito, e
`leads.limite_por_caractere` reprova no mesmo instante — o piso planta o texto acentuado
no limite exato e afirma, antes de medir, que ele EXCEDE em bytes.

---

## 35. Reserva de deduplicação nasce pendente, confirma depois da persistência e é compensada na falha

**Decidido.** `reservar()` insere a correlação com estado `pendente`; a reserva vira
`firme` só depois de o lead estar gravado; e, quando nenhum destino aceita o lead, ela é
APAGADA. O caminho de contingência por transiente tem a mesma disciplina, com TTL curto
enquanto pendente.

**Por quê.** O `INSERT` acontecia em autocommit e não havia `DELETE` compensatório em
caminho nenhum. Bastava `wp_insert_post()` falhar uma vez para a correlação ficar
reservada por **30 dias**: a tentativa seguinte do MESMO visitante recebia
`200 {"ok":true,"registrado":false,"duplicado":true}` e o lead sumia sem que nada no site
dissesse que tinha sumido. A reserva existia para decidir empate entre replay e duplo
clique — e passou a decidir contra o visitante que tentou de novo.

Junto veio a retomada da reserva ABANDONADA: uma requisição interrompida entre a reserva e
a gravação não deixa ninguém para compensar, e o `UPDATE` condicionado ao carimbo lido faz
com que dois pedidos concorrentes disputando a mesma reserva morta produzam uma retomada
só — o banco decide o empate, como no `INSERT`.

**O que custa.** Três colunas a mais na tabela (`tipo`, `estado`, `contador`,
`expira_em`), uma migração por `dbDelta` e uma instrução a mais por lead aceito. A tabela
antiga continua respondendo ao `SHOW TABLES`, então a prontidão passou a ser medida pelas
COLUNAS: sem elas, o módulo cai para o transiente e reporta DEGRADADO com o motivo.

**Como reverter.** Tirar a chamada a `liberar_reserva()` devolve o defeito, e
`leads.reserva_compensada` reprova: o piso prova que a segunda tentativa depois de uma
falha de armazenamento é ACEITA, e que o replay de uma correlação já gravada continua
recusado.

---

## 36. O ouvinte da cadência mora no site-core, e as recorrências que faltam são registradas

**Decidido.** O módulo `cadencia-relatorio` do `site-core` engancha
`f3base_cadencia_relatorio`, registra as recorrências `f3base_quinzenal` (15 dias) e
`f3base_mensal` (30 dias), executa o modo somente-relatório registrando última execução,
próxima, duração, resultado, erro e atraso, e conta os ajustes de
`cadencia_relatorio.apos_n_ajustes` — contando de verdade, e disparando.

**Por quê.** Três defeitos do mesmo tronco, medidos na 1.0.17:

- `f3base_cadencia_relatorio` aparecia **uma vez** no pacote inteiro
  (`includes/class-f3base-imp-lotes.php`, a variável `$hook`) e **zero** `add_action` o
  escutava. O evento disparava, o WP-Cron o reagendava, e nada acontecia. Pior: o único
  lugar que conhecia o nome do hook era o implantador, que **se autodesativa** — o
  ouvinte precisava morar no componente que sobrevive a isso.
- `mensal` degradava para `daily` porque `monthly` não existe no núcleo do WordPress, e
  `quinzenal` degradava para `weekly`, **dobrando a frequência**. As duas em silêncio.
- `apos_n_ajustes` era gravado na option `f3base_cadencia`, que **ninguém lia**, e o
  relatório imprimia "gatilho alternativo: após N ajustes" sobre um contador inexistente.

É o próprio pacote cometendo a regra que o documento mestre enuncia: **gravar não é
configurar**. A saída tinha duas formas honestas — ou a chave conta e dispara, ou ela sai
da configuração. Escolhemos a primeira, porque a chave já estava publicada em documento
entregável e chave que não faz nada é pior que chave ausente: ela produz confiança.

**O que custa.** Um módulo a mais no registro único, duas options novas
(`f3base_cadencia`, lida, e `f3base_cadencia_estado`, de execução) e três hooks de option
(`updated_option`, `added_option`, `deleted_option`) enquanto o gatilho por ajustes estiver
ligado. A reentrância é guardada: as escritas da própria execução — carimbo de atividade,
estado da cadência, procedência e journal — NÃO contam como ajuste, senão o gatilho
dispararia sozinho e o disparo gravaria de novo. "Mensal" no WP-Cron é intervalo de trinta
dias, não mês de calendário, e isso está escrito no nome legível da recorrência em vez de
virar surpresa em fevereiro.

**O que ficou de fora, e é do implantador.** A etapa `cadencia` de
`includes/class-f3base-imp-lotes.php` continua mapeando `quinzenal` para `weekly` e
`mensal` para `monthly` com queda para `daily`, e continua imprimindo o gatilho por
ajustes sem dizer que quem o mantém é o site-core. Ela precisa passar a agendar
`f3base_quinzenal` e `f3base_mensal`, a NOMEAR a degradação quando a recorrência declarada
não existir no momento do agendamento, e a parar de prometer mecanismo que não existe.

**Como reverter.** Tirar o módulo do registro único de `F3Base_Registro::classes()`
devolve o estado anterior — e `cadencia.ouvinte_registrado` reprova dizendo, com o nome do
hook, que ninguém escuta.

---

## 37. A origem do rate limit é declarada, e nunca lida do próprio pedido

**Decidido.** O balde do rate limit conta por `REMOTE_ADDR` até que
`cabecalhos.origem_confiavel` declare um cabeçalho de proxy e quantos saltos confiáveis
existem à frente do site. Declarado, o valor é lido descontando esses saltos da direita da
cadeia — a única parte que o proxy da frente escreveu. Vazio é o padrão, e vazio significa
NUNCA confiar.

**Por quê.** Dois defeitos somados. O incremento era `get_transient()` +
`set_transient()` sem lock: N requisições concorrentes liam o mesmo valor e gravavam o
mesmo valor mais um, e o balde de 20 por 10 minutos deixava passar quantas coubessem na
janela. E a chave saía só de `REMOTE_ADDR`: atrás de CDN ou proxy reverso, `REMOTE_ADDR` é
o mesmo para todos os visitantes, e o balde inteiro virava um só — o limite deixava de
proteger e passava a atrapalhar.

O incremento passou a ser uma instrução só, com o banco somando
(`INSERT ... ON DUPLICATE KEY UPDATE` com `LAST_INSERT_ID()`), pela mesma razão que a
deduplicação já usava chave única: **o banco decide o empate, não o PHP**. E o cabeçalho é
declarado porque cabeçalho de proxy é declaração do CLIENTE: aceitar um sem declaração é
deixar o visitante escolher em que balde ele conta — spoofing de limite.

**O que custa.** Uma chave a mais na configuração e uma option a mais no `site-core`
(`f3base_origem_confiavel`), ambas vazias por padrão. Sem a tabela pronta, o balde cai
para o transiente — declaradamente não atômico —, e o módulo reporta DEGRADADO com o
motivo.

**Como reverter.** Fazer `incrementar_janela()` cair sempre no transiente devolve o
defeito, e `leads.rate_limit_atomico` reprova: o piso congela a leitura, prova que o
caminho de ler-modificar-gravar devolve 1 e 1, e exige 1, 2, 3, 4, 5 do caminho do banco.

---

## 38. O digesto do artefato é declarável, e o que ele não protege está escrito

**Decidido.** O schema passa a **permitir** `sha256` no ramo `origem: "url"` de
`plugins.instalaveis`, e `F3Base_Imp_Plugins::veredito_do_digest()` tem três ramos, cada
um com uma garantia diferente: **declarado e batendo** instala; **declarado e divergindo**
é **FALHA** nomeando os dois valores, sem instalar nada; **ausente** faz o digesto ser
medido e **FIXADO** na primeira observação, com a execução seguinte reprovando qualquer
divergência. E o host da origem passa a ser **revalidado depois de cada
salto**, não só antes do download. (Na 1.0.18 o que se revalidava era o HOST, contra uma
lista fechada; na 1.0.19 a lista saiu — decisão 45 — e o que se revalida é o **esquema**:
todo salto continua em https.)

**Por quê.** Os dois plugins do canal descem de
`https://github.com/…/raw/main/….zip` — **ref mutável** —, e o artefato que chega por esse
caminho é o que expõe as rotas `files/*` e `db/*`. Até a 1.0.17 a guarda de origem
conferia esquema e host **antes** do download, `baixar_artefato()` chamava `download_url()`
puro, nenhum hash era conferido e nada era revalidado depois do salto. Pior, o
schema era ativamente hostil à correção: no ramo `origem: "url"` ele tem
`"additionalProperties": false`, então **declarar um digesto era impossível**.

A restrição que governa o desenho: o usuário exige que o template funcione como produção
**sem configuração extra**. Exigir digesto declarado quebraria a primeira execução de todo
projeto novo. Daí o ramo ausente — e daí, também, a obrigação de não maquiar o que ele é.
**Fixar na primeira observação (TOFU) não é verificação de integridade.** Ela defende
contra a origem mudar embaixo das execuções seguintes e **não** defende a primeira busca:
se o artefato já veio trocado, é o trocado que ficou fixado. A mensagem do relatório diz
as duas metades, com esses nomes, porque TOFU que se apresenta como verificação é pior que
nenhuma verificação — ela produz confiança.

A revalidação depois do salto fecha o outro lado do mesmo buraco: um endereço aprovado
que responda 302 para outro entregaria o artefato desse outro — e um 302 de `https://`
para `http://` traria o corpo por canal aberto. A guarda estaria sendo conferida no
endereço que ninguém baixou. Os saltos passaram a ser seguidos um a um com
`redirection => 0`, a guarda conferida em cada um, e o corpo só desce do endereço final.

**A fronteira com o CONTRATO, medida e escrita.** A regra 20 manda instalar sempre a
última versão da fonte oficial, sem número de versão declarado e **sem checksum de
terceiro**. Não há colisão, e a razão é a origem: a conferência roda **só** quando a
entrada declara `origem: "url"` — artefato NOSSO, endereço com ref mutável. Para
`wordpress.org` ela não roda, e é decisão medida: a URL de lá é **por versão**, o artefato
muda de propósito a cada atualização, e fixar o digesto ali faria a próxima versão
legítima reprovar — o oposto da política. O schema executa a mesma fronteira (o ramo
`wordpress.org` continua com `additionalProperties` fechado), e `digesto_se_aplica()` a
executa no código, com piso nos cinco valores de origem. Na primeira escrita desta release
a conferência rodava para TODA origem remota, o que teria transformado a atualização
seguinte do `wordpress-seo` em FALHA; o achado é da revisão contra o contrato, não da
suíte, e por isso a fronteira virou função com piso em vez de comentário.

**O que custa.** O transporte deixou de ser `download_url()` e passou a ser a mesma camada
HTTP do núcleo com os saltos na mão — mais código nosso, e uma requisição a mais por
salto. Uma option nova, `f3base_digestos`, com o digesto fixado por slug. E um efeito de
configuração que precisa ficar dito: **todo salto do redirecionamento tem de continuar em
https**. Para esta base isso já vale; uma origem que faça um salto por HTTP passa a ver
BLOCKED com o esquema e o host nomeados, que é o comportamento certo.

**Como reverter.** Voltar `baixar_artefato()` a chamar `download_url()` devolve os dois
defeitos, e `plugins.https_em_todo_salto` reprova: o piso injeta um buscador que responde
302 para `http://` e exige recusa. Tirar a conferência do digesto devolve o primeiro, e
`plugins.digesto_do_artefato` reprova nos cinco ramos.

---

## 39. O autoteste do canal é despachado de verdade, e a prova de recusa é BLOCKED declarado

**Decidido.** A unidade `mcp` DESPACHA `files/selftest` — pela Abilities API quando ela
existe, pelo servidor REST interno sempre — e leva o resultado estruturado para a linha
`mcp.autoteste`. Autoteste que devolve falha **reprova a entrega**; ausência da rota fecha
**BLOCKED, nunca OK**. A prova de recusa para credencial não autorizada sai como **BLOCKED
de fase** em `mcp.autoteste_recusa_credencial`, nomeando o que falta.

**Por quê.** `README.md` afirmava desde a 1.0.6 que "`files/selftest` roda na entrega e
após toda mudança de PHP ou de hospedagem, com o resultado no relatório". Medido no
pacote da 1.0.17: os três consumidores do canal faziam `isset( $registradas[ $rota ] )` —
aprovação por NOME —, e `wp_execute_ability`, `execute_ability` e `rest_do_request` tinham
**zero** ocorrências. A rota nunca rodou, e o relatório nunca teve resultado. Aprovar por
nome responde "a rota está registrada"; o autoteste responde "o canal funciona", e o item
que mais importa nele é a detecção de PHP quebrado: com ela inerte, gravar PHP pelo canal
passa a ser perigoso.

Sobre a prova de recusa, a avaliação foi feita e a resposta é **não é mensurável daqui**.
As duas vias de execução deste host despacham DENTRO do processo, com o usuário da
requisição já autenticado como administrador; nenhuma passa pela autenticação HTTP, que é
o que uma credencial não autorizada exercitaria. Forjar um usuário sem capacidade e
despachar de novo mediria o `permission_callback` — e chamar isso de prova de recusa de
credencial seria inventar uma prova fraca e batizá-la de negativa, que é pior do que
declarar a pendência. Ela fica em BLOCKED de fase, com o que falta escrito: requisição
HTTP de fora, credencial sem a capacidade, 401 ou 403 observado na ponta.

**O que custa.** Uma requisição interna a mais por execução, na unidade `mcp`. E uma
fronteira de vocabulário que o pacote não controla: o corpo da resposta é do complemento,
então a leitura é conservadora — booleano falso, `status` de reprovação ou lista de falhas
não vazia REPROVAM; corpo sem campo legível é relatado **como corpo sem campo legível**,
e a linha diz que mediu a resposta 2xx e nada além disso.

**Como reverter.** Tirar o despacho de `etapa_canal_mcp()` devolve o estado anterior, e
`mcp.autoteste_veredito` reprova: o piso exige BLOCKED para rota ausente, FALHA para os
quatro modos de reprovação e OK só para o 2xx sem item reprovado.

---

## 40. Três eixos no encerramento, e a autodesativação continua no gate de aplicação

**Decidido.** O encerramento passa a ter um terceiro eixo, `convergencia`, ao lado do
estado da aplicação e da autodesativação: **convergiu**, **pendente** ou **não
convergiu**. BLOCKED de pré-condição declarada torna a convergência pendente; FALHA de
pré-condição a torna não convergida; e a frase final do encerramento diz o que falta e
como sair. **A autodesativação continua amarrada ao gate de aplicação**, e não à
convergência.

**Por quê.** Aqui a auditoria da 1.0.17 estava certa no fato e nós discordamos da
conclusão, e as duas metades precisam ficar registradas.

O fato: o gate considera BLOCKED — de entregável (`pode_autodesativar()`) e de canal. O
que **ninguém** consultava era o BLOCKED de **pré-condição declarada**:
`privacidade.controlador_identificado` e `formulario.contato-whatsapp` fechavam BLOCKED,
saíam impressos e não entravam em lista nenhuma, porque o mapa do encerramento só
populava `$entregaveis` com `in_array( $nome, $do_gate )`. O resultado era honesto nos
fatos e otimista no nome: `SUCESSO_APLICACAO` mais autodesativação, com a política de
privacidade em rascunho e o CTA de WhatsApp em degradado.

A discordância: a auditoria conclui que a autodesativação deveria esperar pela
convergência. Não deveria. **A autodesativação é sobre o ciclo do implantador ter
terminado, não sobre o site estar completo.** Manter a ferramenta no ar por dado que só o
operador tem — razão social, documento, endereço, número de WhatsApp, nome do mecanismo
de cadência da hospedagem — prenderia o pacote a uma espera indefinida: um site cujo
operador nunca preenche o controlador ficaria com o implantador ativo para sempre, que é
exatamente a forma de gate insatisfazível que a 1.0.8 eliminou para a rodada limpa. O que
o eixo novo muda é o NOME do resultado e a frase de encerramento, não quem sai de cena.

**O que custa.** Um metadado a mais nas linhas (`precondicao`), ortogonal ao `gate` — que
não muda, para que nenhuma guarda de promoção de unidade seja afrouxada —, e uma linha a
mais no relatório (`entrega.convergencia`, com gate de fase, porque ela relata e não
decide). Marcar uma checagem como pré-condição é decisão explícita de quem a emite;
esquecer de marcar deixa o eixo otimista, e é o preço de não inventar heurística sobre
"que BLOCKED é do operador".

**Como reverter.** Tirar `precondicao` das emissões devolve o eixo a "convergiu" sempre, e
`lotes.convergencia_terceiro_eixo` reprova nos cinco casos — inclusive no piso da
discordância, que exige que a autodesativação aconteça com a convergência pendente.

---

## 41. A lista de gates de fase sai do metadado, e o escopo sai junto com o veredito

**Decidido.** `F3Base_Imp_Entrega::gates_de_fase()` deixa de ser lista literal e passa a
devolver `F3Base_Imp_Relatorio::nomes_com_gate( 'fase' )` — os nomes que as linhas desta
execução declararam. E as duas frases que falam de pendência de fase passam a **nomear o
escopo que resumem**.

**Por quê.** Havia duas fontes para o mesmo fato: uma lista declarada com **um** nome
(`entrega.rodada_limpa`) e o metadado `gate` por checagem, com **dois** emissores de
`gate=fase`. Duas fontes divergem, e a divergência saiu impressa dentro de UMA linha do
log da 1.0.17, unidade `entrega`: *"…Nenhuma pendência de fase em aberto. Pendência(s) de
FASE dentro desta unidade — 1 … orcamento.medicao_de_pagina (BLOCKED)"*. Derivar do
metadado faz a causa sumir. O texto precisava da segunda metade: as duas frases contam
escopos diferentes — os gates de fase da EXECUÇÃO e as internas de UMA unidade —, e sem o
escopo nomeado elas continuariam parecendo contradição mesmo concordando.

**O que custa.** `gates_de_fase()` passou a depender das linhas já emitidas, então quem a
consulta tem de consultá-la DEPOIS das emissões — o encerramento, que é onde ela é usada.
A sonda passou a emitir antes de perguntar, e é isso que prova a derivação em vez de
pressupô-la.

**Como reverter.** Devolver a lista literal ao corpo da função devolve a divergência, e
`estatica.gate_de_fase_do_metadado` reprova nomeando o literal; `entrega.gates_separados`
reprova junto, porque o segundo emissor deixa de aparecer na lista derivada.

---

## 42. O registro da rodada declara o veredito, e deixou de se chamar "rodada limpa"

**Decidido.** `suite/rodada-limpa.json` passa a ser `suite/rodada.json`, e o registro
declara **veredito**, **contagem de FALHA** e **pendências de fase NOMEADAS**. O leitor no
host (`veredito_da_rodada_limpa()`) confere o veredito **além** do hash: sem veredito
legível, ou com FALHA declarada, o estado é BLOCKED; com pendências, fecha OK
**nomeando-as**.

**Por quê.** Três defeitos do mesmo tronco. O selo lia só `FALHA` para decidir se gravava;
o arquivo se chamava `rodada-limpa.json` e continha 22 BLOCKED; e o leitor comparava **só
o hash**. Somando os três: o registro com 22 bloqueios era o que fazia `entrega.rodada_limpa`
fechar OK no host — o pacote se aprovando pelo arquivo que ele mesmo escreveu, com a
palavra "limpa" no nome do arquivo fazendo o resto do trabalho. Hash igual prova que a
rodada mediu ESTE pacote; não diz o que ela achou. Um registro chamado "rodada limpa" com
bloqueios dentro é exatamente o tipo de afirmação que esta release existe para eliminar,
e por isso o nome passou a ser neutro e o veredito passou a ser um campo.

**O que custa.** O caminho mudou em nove lugares — inventário, allow-list, constante do
host, marcador do detector de fonte única, fixtures e documentos —, e um pacote instalado
com o registro antigo passa a fechar BLOCKED dizendo que o registro não declara veredito.
É o comportamento certo: registro de uma versão anterior do selo não amarra entrega.

**Como reverter.** Fazer o leitor voltar a comparar só o hash devolve o defeito, e
`entrega.rodada_limpa_confere` reprova nos dois ramos novos — registro sem veredito e
registro declarando FALHA.

---

## 43. Ler não é consumir, e o detector que media a coisa errada parou de afirmar o que não mede

**Decidido.** `estatica.detector_chave_sem_consumidor` **mantém o nome** e passa a dizer,
na própria linha do relatório, exatamente o que mede — "toda chave tem uma LINHA QUE A
LÊ" — e o que não mede: **ler não é consumir**. E nasce o irmão que mede a outra metade,
`estatica.option_gravada_sem_leitor`: toda option do namespace declarado em
`site.prefixo_tecnico` que o pacote GRAVA é lida de volta por alguma linha.

**Por quê.** O detector aprovou `cadencia_relatorio.apos_n_ajustes` com nota cheia até a
1.0.17, e a chave não fazia nada: era lida, o valor ia para a option `f3base_cadencia`, e
nenhuma linha do pacote lia aquela option. Detector que mede a coisa errada é pior que
detector ausente, porque produz confiança — e a confiança que ele produziu foi a de que
toda chave publicada tinha efeito.

Duas saídas foram consideradas. Renomear para `detector_chave_sem_leitor` alinharia nome
e medição, mas trocaria um nome que o CONTRATO usa (regra 10, "toda chave do config tem
consumidor") por outro, sem medir nada a mais — e a propriedade que o contrato pede é
justamente a que o par de detectores passa a provar. A escolhida foi a segunda: parar de
afirmar o que ele não mede, e acrescentar o detector que fecha o trajeto. Os dois juntos
respondem "a chave é lida" **e** "o que a leitura produz é lido de volta", que é o que
"tem consumidor" queria dizer desde o começo.

**O que custa.** O detector novo tem escopo declarado — só options do prefixo técnico —,
e é decisão: option do núcleo (`blog_public`, `site_icon`, `permalink_structure`) é lida
pelo WordPress, e acusá-la seria falso positivo com cara de rigor. O limite que sobra está
escrito: uma leitura cujo valor só chega a uma mensagem de texto continua passando pelos
dois. Quem pega esse caso é `doc.afirmacao_conferida`, e por afirmação declarada.

**Como reverter.** Tirar o detector novo devolve o buraco, e o piso reprova: a fixture
negativa é o defeito de 1.0.17 inteiro — `f3base_cadencia` gravada com o número de
ajustes e nenhuma linha a lendo de volta, com `blog_public` ao lado para provar que option
do núcleo não é acusada.

---

## 44. Afirmação de documento conferida contra comportamento medido

**Decidido.** Nasce `suite/afirmacoes.tsv` e o detector `doc.afirmacao_conferida`: cada
linha declara um **documento**, a **frase exata**, uma **regra** e o **esperado**, e o
detector mede o fato na árvore varrida. Frase declarada que sumiu do documento é achado;
fato que não bate com o esperado é achado, nomeando frase, regra, esperado e observado.
Quatro regras, todas estáticas e todas com piso: `config.vazio`, `config.igual`,
`codigo.chamada` e `codigo.emite_estado`.

**Por quê.** Os detectores desta suíte conferiam identidade de release e números gerados.
**Nenhum conferia uma afirmação de COMPORTAMENTO**, e foi por essa fresta que passaram
cinco dos vinte e dois achados da auditoria da 1.0.17 — três deles refutados pela
configuração e pelo código que viajam no MESMO zip:

- "mecanismo vazio → o item fecha BLOCKED, não OK" (`README.md` duas vezes,
  `MANIFESTO.md` uma), enquanto o código montava WP-Cron sempre e o veredito era OK;
- "`plugins.operacionais` está vazio nesta base" (`README.md` duas vezes), com
  `dreamhost-panel-login` declarado em `config/site.json`;
- "`files/selftest` roda na entrega … com o resultado no relatório" (`README.md`), com
  zero chamadas de execução de rota ou de habilidade no pacote.

O detector não precisa entender prosa. Precisa de um **mecanismo declarado** que ligue a
frase ao fato — e é isso que a tabela é. As três correções foram feitas, e as três frases
corrigidas estão amarradas: se alguém devolver qualquer uma delas ao texto antigo, ou
mudar o comportamento por baixo, a rodada acusa.

**O que custa.** Uma tabela a manter: frase reescrita sem atualizar a linha vira achado de
amarração órfã. É o preço certo — amarração órfã afirma cobertura que não existe, que é a
doença que `armadilhas.mapeadas` combate um nível acima —, mas é trabalho recorrente, e a
mensagem do achado diz as duas saídas: reescrever a frase ou tirar a linha.

**Como reverter.** Tirar a tabela devolve a fresta, e o piso reprova: a fixture negativa é
um pacote com os três defeitos medidos de 1.0.17 — README afirmando, `config/site.json` e
`includes/` refutando — e a positiva é o mesmo pacote com os três fatos no lugar.

---

## 45. Lista declarada no mesmo arquivo que ela restringe não é controle de segurança

**Decidido.** `plugins.origens_url_autorizadas` sai: a chave, a entrada de schema, a
conferência no código e toda mensagem que a nomeava. O que fica, e faz o trabalho de
verdade sem pedir nada ao operador, são duas coisas: **HTTPS obrigatório em TODOS os
saltos** — inclusive o primeiro, e revalidado a cada redirecionamento — e o **digesto** da
1.0.18, com os três ramos que ela já tinha (declarado é gate duro, ausente é medido e
fixado na primeira observação, com o limite dito). A revalidação depois do salto passa a
ser "todo salto continua HTTPS" em vez de "aterrissou em host da lista".

**Por quê — e esta é a regra geral que justifica o resto da release.** Uma lista de hosts
declarada **no mesmo arquivo** que as URLs que ela restringe não é controle de segurança:
quem consegue editar a URL edita a lista na linha de cima. Não há separação de privilégio
entre as duas escritas, não há assinatura, não há segunda autoridade — as duas linhas
moram no `config/site.json` e são gravadas pela mesma pessoa, no mesmo commit, com a
mesma permissão. Contra um adversário que edite a configuração, ela não protege nada.
Contra um operador distraído, ela protege contra um erro de digitação de host — que é uma
guarda de digitação, útil, mas com **preço de controle de segurança**: uma chave a mais no
arquivo único, uma decisão a mais pedida a quem só quer publicar um site, e uma mensagem
de BLOCKED que ensina a "acrescentar o host à lista", que é justamente o gesto que
dissolve a suposta proteção.

Isso é o padrão que esta release inteira persegue: **regra que gera confusão sem comprar
nada sai; regra que compra proteção sem pedir nada fica.** HTTPS compra autenticidade de
origem e integridade em trânsito, e não pede nada — é uma propriedade do endereço que já
está escrito. O digesto compra "o byte de hoje é o byte de ontem", e não pede nada no ramo
ausente. A lista de hosts pedia uma decisão e não comprava nada que a edição do arquivo
não desfizesse.

**O que custa.** Perde-se a guarda de digitação: uma URL escrita para o host errado passa
a ser tentada, e a defesa contra ela deixa de ser "recusa antes de abrir conexão" e passa
a ser "o digesto não bate" — que só existe a partir da segunda execução, ou desde a
primeira quando o `sha256` está declarado. Quem quiser a guarda de volta tem um caminho
melhor que a lista: declarar `sha256` na entrada, que é gate duro **na primeira busca**,
que a lista nunca foi. E o operador que precisa de fronteira de rede de verdade tem a
camada certa para ela — egress do servidor —, que é fora do alcance de quem edita o
`config/site.json`.

**Como reverter.** Redeclarar a chave e devolver a conferência ao código —
`estatica.sem_residuo_de_chave_removida` reprova enquanto a linha estiver em
`suite/chaves-removidas.tsv`, e é ela que precisa sair primeiro. O piso da guarda que
ficou está em `plugins.https_em_todo_salto`: salto que cai para HTTP é recusado, URL
declarada em HTTP é recusada antes de qualquer busca, endereço sem host legível não abre
conexão e cadeia sem fim é abandonada no teto.

---

## 46. Regime de formulário derivado do valor, e não de um interruptor ao lado dele

**Decidido.** Some `formularios[].ativo` e some `formularios[].motivo_inativo`. **A
presença do destino decide**: `contato.whatsapp_e164` preenchida faz o regime whatsapp
existir; vazia, ele não existe — `formulario.contato-whatsapp` fecha **N/A** com a
condição declarada, dizendo que basta preencher a chave nomeada, e o **CTA não é
publicado**. Nem no comportamento degradado: o bloco do botão sai do HTML servido. A
mesma regra vale para o regime `cf7-email` e `contato.email_leads`.

**Por quê.** Havia dois fatos podendo discordar sobre a mesma coisa, e eles discordavam:
o template nascia com o regime whatsapp declarado `ativo: true` e com o destino vazio, e o
relatório fechava a unidade em BLOCKED por falta de destino de um regime que ele mesmo
acabara de declarar ligado. Uma implantação de template intocado, que tinha dado certo,
terminava dizendo que algo estava errado — que é o mesmo defeito do WARN informativo que a
1.0.15 eliminou. Presença de valor é a condição, e uma condição só: não há como o
interruptor discordar do destino quando o interruptor não existe.

E o CTA não é publicado porque **publicar um botão que não leva a lugar nenhum é pior que
não ter botão**. O que a base entregava era um "Falar com a equipe" cujo `href` apontava
para a própria página de contato: o visitante clicava e não acontecia nada que ele
pudesse chamar de resposta. O discriminante da publicação é a CLASSE do pattern, que mora
no arquivo do tema, e não o atributo `data-f3base-lead`, que é carimbo de render e depende
de `WP_HTML_Tag_Processor` — decidir pelo atributo deixaria o botão publicado justamente
na instalação onde o processador não existe, que é onde menos se quer surpresa.

**O que custa.** Um site cujo operador ainda não preencheu o número perde o botão da
página de contato e do cabeçalho: a página de contato passa a ter o texto e nenhum
acionamento. É deliberado, e o preço é assumido — a alternativa é entregar um botão que
mente. O custo secundário é que o motivo declarado de um regime dormindo deixou de
existir: `motivo_inativo` explicava o interruptor, e sem interruptor o motivo passa a ser
MEDIDO — a chave está vazia —, o que o N/A já diz nomeando a chave.

**Atualizado na 1.1.0 — ver a decisão nº 52.** A frase "o CTA não é publicado" continua
valendo para o botão que ainda aponta para o destino do modelo, e deixou de valer para o
bloco cujo `href` alguém trocou: a supressão passou a ser medida no destino, e não presumida
pela classe.

**Como reverter.** Redeclarar `ativo` no schema e na entrada, e voltar o ramo `if
( ! $ativo )` à etapa de formulários. `formulario.veredito_destino` reprova: o piso exige
N/A no destino vazio e varre as entradas declaradas atrás do interruptor de volta. E
`cta.publicado_pela_presenca_do_numero` reprova a publicação do botão sem número, numa
bancada deliberadamente sem `WP_HTML_Tag_Processor`.

---

## 47. Dado do projeto mora no eixo de convergência, não no gate de aplicação

**Decidido.** O metadado `precondicao` passa a **derivar** o gate da linha: pré-condição
declarada fecha no gate `convergencia`, nunca no de `aplicacao`. Uma condição, um lugar —
quem declara `precondicao` não declara `gate`, e o gate `convergencia` não é escolhido por
ninguém. `privacidade.controlador_identificado` é a residência canônica do eixo, e
`cadencia.mecanismo_declarado` entra pela mesma regra.

**Por quê.** O terceiro eixo nasceu na 1.0.18 exatamente para isto, e ficou pela metade: o
eixo passou a SOMAR as pré-condições declaradas, mas as linhas continuaram no gate de
aplicação. `precondicao` e `gate` eram dois metadados independentes, e uma linha podia ser
as duas coisas ao mesmo tempo — dado que só o operador tem E gate de aplicação. O efeito
estava medido: uma implantação de template intocado, em WordPress limpo, terminava com
BLOCKED de gate de aplicação cuja única causa era dado que o pacote não tem como ter. A
tela dizia que algo estava errado numa implantação que deu certo.

Nenhuma guarda enfraquece com isso, e é importante que fique dito qual é a diferença: a
página da política **continua em rascunho** pela guarda medida do controlador, continua
fora do `llms.txt` e continua sem o link no rodapé; o que era nomeado continua nomeado, na
mesma linha, com as mesmas chaves vazias listadas e o mesmo caminho de saída. O que muda é
**onde o fato é contado** — num eixo que diz a verdade sobre ele, em vez de num gate que
mede outra coisa. A promoção do veredito da unidade continua sendo do gate de aplicação, e
a regra de 1.0.8 continua de pé: checagem de aplicação em BLOCKED promove a unidade, e o
piso de `lotes.gate_de_aplicacao_sem_dado_do_operador` exercita justamente essa diferença.

**O que custa.** Um terceiro valor de gate, e a nota da unidade ganhou uma frase: as
pendências de FASE e as de CONVERGÊNCIA saem em listas separadas, porque são perguntas
diferentes — "este host não produz essa evidência" e "falta um dado que só o operador
tem". Duas frases onde havia uma. E fica um risco declarado: marcar como `precondicao`
algo que o pacote PODE medir seria a porta de escape que absolve qualquer coisa — o mesmo
risco que o gate de fase já tinha, e a mesma resposta: a regra é estreita, entra em
`precondicao` só o que depende de dado do operador.

**Como reverter.** Tirar a derivação de `emitir()` devolve os dois metadados
independentes, e `estatica.precondicao_no_eixo` reprova nos dois ramos: sem a derivação
declarada, e com qualquer emissor que declare `precondicao` e `gate` no mesmo argumento.

---

## 48. Progresso é status ao vivo; encerramento é conclusão, e conclusão vem depois

**Decidido.** A tela do implantador passa a ter dois nós onde havia um. `progresso`
continua sendo o primeiro filho da raiz, com `role="status"` e `aria-live="polite"`, e ao
terminar fica com uma **linha curta e verdadeira**: o que aconteceu, o estado fechado da
aplicação e onde está o resultado completo. O **resumo inteiro** — contagens por escopo,
listas de nomes por estado, resumidas, suspensas, estado da aplicação — mora num nó
próprio, `encerramento`, montado **depois da tabela**.

**Por quê.** O resumo de encerramento era escrito dentro de `progresso`, e `progresso` é o
primeiro filho da raiz porque é isso que um status ao vivo precisa ser. O resultado
aparecia **antes** do log e empurrava a tabela inteira para baixo: quem terminava a
execução lia a conclusão de costas para as linhas que a produziram. São duas coisas com
tempos diferentes — uma que muda a cada lote e outra que só existe no fim —, e duas coisas
não cabem num nó só sem que uma atrapalhe a outra.

**Acessibilidade não é o preço da mudança de lugar, é parte dela.** Mover o nó e parar aí
teria trocado um defeito de leitura por um defeito de acesso: quem navega por teclado ou
por leitor de tela ficaria com o resultado fora do caminho. Então a região tem nome
acessível (`role="region"` mais `aria-label`), é focável por script (`tabindex="-1"`),
recebe o **foco** no instante em que é escrita — o que a anuncia e leva o teclado até ela
—, e a linha do topo, que é a região viva, diz que a execução terminou e onde a conclusão
está. O anel de foco é visível por CSS, porque foco sem indicação visível é foco perdido.

**O que custa.** Um nó a mais na tela e dois lugares para ler o resultado em vez de um —
compensado pela linha do topo apontar para o outro. E o piso ficou mais caro: medir a
ordem no DOM lendo o código-fonte responderia "o `appendChild` está escrito depois", que é
outra pergunta, então a sonda passou a montar um **DOM de mentira** e rodar o cliente REAL
de ponta a ponta contra ele. É mais bancada para manter, e é o que faz a medição ser sobre
a árvore que o operador vê.

**Como reverter.** Escrever o resumo em `progresso` de novo, ou montar o encerramento
antes da tabela. `js.decisoes_do_cliente` reprova nos dois casos, e o piso são **mutantes
do próprio cliente**: a sonda troca `encerramento.textContent =` por
`progresso.textContent +=`, inverte a ordem dos dois `appendChild` e apaga a chamada de
foco, e exige que a bancada acuse os três. Piso que não consegue plantar o defeito prova
que a bancada é cega.

---

## 49. Varredura das chaves declaradas: o que muda se eu mudar isto?

**Decidido.** Toda chave de `config/site.json` passou por um teste só — *o que muda se eu
mudar isto?* — e as que responderam "nada que um operador deste template queira" saíram.
São **cinco chaves**, e cada uma com o motivo próprio:

| Chave | Por que saiu |
|---|---|
| `plugins.origens_url_autorizadas` | lista de hosts no mesmo arquivo que as URLs que ela restringia: guarda de digitação com preço de controle de segurança. Decisão 45 |
| `ambiente.dominios_autorizados` | nascia vazia, deixou de ser gate de indexação na 1.0.12 e virou cross-check; o único efeito de preenchê-la era **ganhar um WARN** quando o host diferia. Regra que gera confusão sem comprar nada |
| `formularios[].ativo` | interruptor ao lado do dado que ele liga, podendo discordar dele — e discordava. Decisão 46 |
| `formularios[].motivo_inativo` | existia para explicar o interruptor. Sem interruptor, o motivo é MEDIDO: a chave de destino está vazia, e o N/A a nomeia |
| `copy_contrato.fonte` | enum de um valor só. A condição `'config' === $fonte` nunca podia ser falsa: tautologia dentro de uma condição que mede duas coisas de verdade. Chave que só pode ter um valor não é ponto de extensão — é um comentário com preço de configuração |

**Por quê.** O critério de aceite desta release é *template intocado, WordPress limpo,
site completo e online, sem que o operador decida nada*. Cada chave é uma decisão pedida a
alguém, e chave que não compra nada em troca dessa decisão é custo puro: mais superfície
para errar, mais documento para manter em dia e mais linha de relatório para o operador
interpretar. **Regra que gera confusão sem comprar nada sai; regra que compra proteção sem
pedir nada fica.**

**O que ficou, e por que ficou — os casos que pareciam candidatos e não são:**

- `plugins.politica_versao` e `plugins.autoupdate` também são enums de um valor só, e
  **ficam**. Eles são a declaração, no arquivo único, das regras 20 e 21 do contrato, e
  `doc.afirmacao_conferida` amarra as frases de `README.md` e de `MANIFESTO.md` a eles por
  `config.igual`. Tirá-los moveria uma política declarada para dentro do código, que é o
  que a regra 11 do contrato proíbe. E eles não pedem decisão nenhuma: nascem corretos.
- `consumidores_declarados` **fica**: tem dois ramos de verdade, e o ramo `false` produz um
  WARN que nomeia a garantia que o relatório perde. É o pacote afirmando algo sobre si
  mesmo, e ninguém precisa tocá-la para publicar um site.
- `ambiente.dominios_de_previa`, `plugins.embarcados`, `seo.robots_extra`, `redirects`,
  `tema.fontes` e `tema.fragmentos_sincronizados` **ficam vazios e ficam**: lista vazia é
  estado válido e declarado, e cada uma delas MUDA o comportamento quando preenchida —
  guarda de indexação, artefato no bundle, linha no `robots.txt`, 301, `@font-face`,
  fragmento sincronizado. Nenhuma delas pede decisão para o site nascer.

**O que custa.** Cinco pontos de extensão a menos. Quem quiser a lista de hosts de volta
tem uma resposta melhor — `sha256` declarado, que é gate duro desde a primeira busca —, e
quem quiser o cross-check de domínio perdeu um diagnóstico que ninguém tinha preenchido.
O maior custo é o precedente: remover chave é irreversível na prática, porque o projeto
que dependia dela já não existe para reclamar. É por isso que cada remoção tem detector.

**Como reverter.** Cada linha de `suite/chaves-removidas.tsv` é o que impede a chave de
voltar por descuido: `estatica.sem_residuo_de_chave_removida` reprova enquanto o nome
estiver na tabela e a chave reaparecer na configuração, no schema, no código ou em
documento fora da narrativa declarada. Devolver a chave começa por tirar a linha da
tabela — e essa é uma decisão que fica escrita.

---

## 50. O pacote deixa de pedir ao canal que recuse a escrita do agente

**Decidido.** O módulo `guarda-options-mcp` sai INTEIRO: o arquivo, a linha do autoload, o
nome na lista do registro único e a linha do inventário. Com ele saem os quatro filtros do
servidor MCP em que ele registrava as options do catálogo
(`wp_mcp_ultimate_protected_options` e três irmãos). No lugar fica um detector com piso —
`estatica.sem_recusa_de_escrita_do_agente` — que reprova qualquer literal de nome de filtro
de options protegidas no runtime do pacote.

**Por quê.** A premissa desta release, nas palavras de quem a definiu: *"Após a instalação,
todas as futuras modificações serão realizadas por um agente através de MCP. Então o
template e plugins não devem tentar evitar que futuras modificações sejam realizadas. Elas
serão permitidas."* O módulo fazia exatamente o contrário, e não por acidente: ele
registrava as vinte options do catálogo — `f3base_contato`, `f3base_tracking`,
`f3base_consentimento`, todas — nos filtros pelos quais o servidor decide o que recusar.
O agente que precisasse gravar um número de WhatsApp encontraria a recusa vinda do próprio
pacote que ele acabara de instalar.

O módulo já declarava, em comentário, que a lista protegida **não** é fronteira de
segurança: as rotas de arquivo do canal alcançam o código que a implementa. Ou seja: ela
não protegia contra quem quisesse mudar, e atrapalhava quem tinha o direito de mudar. A
fronteira real continua onde sempre esteve — usuário dedicado, Application Password e as
travas do canal.

**O que custa.** Some a trava contra acidente. Uma escrita distraída pelo canal sobre
`f3base_nav_id` ou `f3base_endpoint_segredo` deixa de encontrar qualquer resistência. O
que continua existindo é o registro: toda escrita passa pelo gravador único, a procedência
fica gravada em `f3base_proveniencia`, e a cadência do modo somente-relatório relê as
options e reporta o que divergiu. Trocamos recusa por rastro — e rastro é o que serve a
quem opera por agente.

**Como reverter.** Devolver o arquivo, a linha do autoload e o nome no registro.
`estatica.sem_recusa_de_escrita_do_agente` reprova, nomeando arquivo e linha de cada
literal de filtro; a fixture negativa dele é um módulo que registra exatamente esses
nomes. Reverter começa por tirar a checagem, e essa é uma decisão que fica escrita.

---

## 51. O sanitizador normaliza o que conhece e preserva o que não conhece

**Decidido.** Todo sanitizador de option de grupo passa por
`F3Base_Options::preservar_desconhecidas()`: a chave declarada continua sendo normalizada
como sempre, e a chave que o pacote não conhece é PRESERVADA — sanitizada como dado (texto,
número, booleano ou lista deles) e com o nome reduzido ao alfabeto de um nome de chave. Nas
options em lista (`f3base_redirects`, `f3base_journal_eliminacao`) a preservação vale
DENTRO de cada entrada. Piso em `options.chave_desconhecida_preservada`, que varre o
catálogo inteiro e não uma option escolhida a dedo.

**Por quê.** O defeito estava medido e é silencioso, que é o pior tipo. Até a 1.0.19 cada
sanitizador RECONSTRUÍA o array a partir das chaves declaradas — `sanitiza_contato`
devolvia três chaves fixas, `sanitiza_tracking` uma, `sanitiza_consentimento` quatro. O
agente acrescentava `telefone` a `f3base_contato` pelo canal; a escrita entrava no banco; a
primeira LEITURA devolvia o valor sem a chave. Sem erro, sem log, sem ninguém para acusar —
e a leitura de volta conferia contra o valor que a própria sanitização tinha imposto, então
até o gate de gravação dizia que estava tudo certo.

Sob a premissa de que toda modificação futura é do agente, um sanitizador que descarta o
que não conhece é um sanitizador que desfaz trabalho alheio a cada leitura.

**O que custa.** A option deixa de ter forma fechada. Um erro de digitação do agente —
`telefonee` — passa a viver na option para sempre, e ninguém o remove por ele. A garantia
que fica é mais fraca e mais honesta: as chaves QUE O PACOTE LÊ continuam com forma
garantida, e o resto é dado de quem escreveu. O segundo custo é de tamanho: option
autoload que cresce sem teto pesa em toda requisição, e o pacote não impõe teto porque não
sabe o que a chave desconhecida vale para quem a gravou.

**Como reverter.** Tirar as chamadas de `preservar_desconhecidas()` dos sanitizadores.
`options.chave_desconhecida_preservada` reprova, e o piso dela é o reconstrutor de chaves
fixas da 1.0.19 escrito na própria bancada: ele existe ali para provar que a bancada
enxerga o descarte, e não para ser usado.

---

## 52. O CTA só some quando não tem destino, e o `href` só é reescrito quando é do modelo

**Decidido.** `promover_cta()` ganha dois lados que não se cruzam. **Supressão**: o bloco
deixa de ser publicado apenas quando não tem destino nenhum — `href` vazio, `#` ou o
marcador do modelo, E número vazio. **Promoção**: o `href` só é reescrito quando é do
modelo; `tel:`, landing, formulário próprio e qualquer outro destino ficam como estão. A
mesma regra vale no clique, dentro de `f3base-leads.js`, que também reescrevia o `href` sem
olhar. O `<a>` que o pacote promoveu recebe o carimbo `data-f3base-numero`, e é ele que diz
ao cliente que aquele destino é do pacote. Piso nos quatro quadrantes, em
`leads.cta_preserva_destino`.

**Por quê.** Este era o mecanismo mais forte do pacote contra o agente, e ele agia duas
vezes por página: `promover_cta()` suprimia **qualquer** bloco com a classe
`f3base-acao-contato` quando o número estava vazio, e reescrevia o `href` sem checar quando
estava preenchido. Um CTA que o agente tivesse apontado para uma landing de campanha sumia
do HTML servido — sem erro, sem log, com o relatório verde. Um CTA apontado para um `tel:`
voltava a ser `wa.me` a cada render, e voltava a ser `wa.me` de novo a cada clique.

A decisão nº 46 continua de pé no que ela realmente mediu: publicar um botão que não leva a
lugar nenhum é pior que não ter botão. O que mudou é o alcance — "não leva a lugar nenhum"
passou a ser medido no `href`, em vez de presumido pela classe.

**A REGRA PASSOU A RODAR, e essa é a segunda metade desta decisão.** A medição que a
motivou: a supressão **nunca chegou a rodar**, desde a 1.0.19. `promover_cta()` está no
filtro `render_block`, e `F3Base_Site_Core::registrar()` pulava todos os hooks de módulo
inativo; com `contato.whatsapp_e164` vazia o módulo fecha INATIVO, então o filtro só era
registrado quando havia número — isto é, quando a condição da supressão já não podia
acontecer. As duas condições eram mutuamente exclusivas. Medido por sonda: `estado()`
devolvia `inativo`, `deve_registrar()` devolvia `false`, e `hooks()` declarava um
`render_block` que ninguém registrava. Três documentos afirmavam a regra; o que ia ao ar
era o botão morto do pattern, com o `href` do modelo, em toda instalação sem número.

A afirmação estava certa e o código, não — então o código mudou. `hooks()` ganhou a chave
opcional **`sempre`**, e `registrar()` passa a registrar o item marcado mesmo com o módulo
inativo. A marca alcança UM hook em todo o pacote, e o motivo é que a decisão dele é POR
BLOCO e não pelo estado do módulo: o caso mais importante dela — CTA sem número e com o
`href` do modelo — acontece justamente no estado inativo. A invariante continua de pé para
tudo o mais: módulo inativo não enfileira asset, não registra endpoint e não cria tabela, e
`cta.regra_de_publicacao_registrada` mede isso no mesmo bloco em que mede os quadrantes.

A alternativa recusada foi mudar o ESTADO do módulo para ativo: ela alcançaria a supressão
pelo caminho errado, misturando "o regime existe" com "esta regra decide", e deixaria o
apagamento dependente de qualquer futura mudança na conta do estado. A exceção declarada
por hook diz exatamente o que faz, no lugar onde alguém a lê.

E o apagamento que ela torna alcançável é o único que esta release aceita: **o do bloco sem
destino nenhum**. É a mesma chave que decide, não uma chave de outro regime; e publicar um
botão que não leva a lugar nenhum continua sendo pior que não ter botão.

**O que custa.** O reconhecimento do "destino do modelo" depende de um LITERAL declarado:
`/contato/`, o `href` que o pattern do tema entrega. Não há como derivá-lo — depois que o
conteúdo entra no banco, o bloco renderizado não carrega nenhuma marca de quem escreveu
aquele `href`, e o do pattern e o que o agente digitou chegam iguais ao filtro. Quem trocar
o pattern e não declarar o novo valor em `f3base_cta_hrefs_do_modelo` terá um CTA que o
pacote nunca promove: ele passa a ser tratado como destino de alguém. É o erro seguro dos
dois possíveis.

**Como reverter.** Tirar a leitura de `tem_destino_proprio()` do ramo da supressão e a de
`e_do_modelo()` do laço da promoção. `leads.cta_preserva_destino` reprova nos quadrantes 2
e 4, e `js.conversao_multicanal` reprova o clique que reescreve o `href` do agente.

---

## 53. O link da política preenche quando falta, e nunca apaga o parágrafo

**Decidido.** `f3base_link_privacidade()` passa a gravar o `href` apenas quando ele está
vazio ou é `#`. Sem política publicada, ela REMOVE o `href` — o link vira texto — em vez de
devolver string vazia. O arquivo de `parts/footer.html` passa a nascer com `href="#"`,
porque é o valor vazio que autoriza o preenchimento. Piso em
`tema.link_privacidade_preserva`.

**Por quê.** Eram dois defeitos na mesma função, e os dois eram a mesma doença — o tema
mandando no que não é dele. O primeiro: sem política publicada, a função devolvia `''`, e
com ela sumia o PARÁGRAFO INTEIRO — endereço do encarregado, razão social, o que o agente
tivesse posto ali. O remédio para "não apontar para rascunho" é tirar o destino, não sumir
com o texto. O segundo: o `href` era gravado sem olhar, então uma política em PDF externo,
uma página do grupo ou um domínio jurídico voltava a ser o permalink local a cada render.

**O que custa.** Um link sem `href` não é focável pelo teclado e não anuncia destino: é
texto. Numa instalação sem política publicada, o rodapé passa a ter a frase "Política de
Privacidade" sem link, que é menos informativo que a ausência do parágrafo — e é
deliberadamente menos destrutivo. O segundo custo é de migração: quem tiver o `href` antigo
`/politica-de-privacidade/` gravado no conteúdo não recebe mais o permalink real, porque
esse valor passou a ser lido como destino de alguém.

**Como reverter.** Devolver o `return '';` e a gravação incondicional.
`tema.link_privacidade_preserva` reprova nos três tetos, e a bancada da sonda carrega a
função da 1.0.19 escrita ali, como piso, para provar que ela enxerga os dois defeitos.

---

## 54. O cabeçalho emitido é o valor gravado, e o preço sai nomeado

**Decidido.** `sanitiza_cabecalhos()` deixa de devolver `coop` como literal e passa a LER o
valor armazenado, dentro do vocabulário fechado do cabeçalho; o módulo emite a lista por
`lista_de_cabecalhos()`, que devolve nome→valor e é o que a suíte mede. `Referrer-Policy:
no-referrer` continua sendo aceito e passa a sair com um AVISO em WARN, nomeando os quatro
canais que perdem a origem do clique. Pisos em `seguranca.coop_do_valor_gravado` e
`seguranca.referrer_policy_avisa_atribuicao`.

**Por quê.** O COOP era travado em `same-origin-allow-popups` em dois lugares — na
sanitização e no emissor —, e o efeito era o pior possível para quem opera por agente:
gravar outro valor pelo canal *funcionava*, a leitura de volta *conferia*, e o cabeçalho
saía com o valor do pacote. A option existia e não tinha efeito nenhum. O pacote continua
sabendo qual valor o fluxo de leads precisa; o que ele passou a fazer é NOMEAR a
consequência — o CTA abre a conversa em janela nova, e fora de `same-origin-allow-popups` o
navegador corta a relação com ela — em vez de decidir pelo projeto.

O `Referrer-Policy` é o caso simétrico, e ele importa por causa da segunda premissa desta
release: *"O site será usado com GA4 e Ads, além de também ser utilizado para receber
tráfego do LinkedIn Ads e Meta Ads."* `no-referrer` apaga o referenciador de toda saída, e
com ele some a origem que o GA4 usa para classificar a sessão e que Google Ads, Meta Ads e
LinkedIn Ads usam para reconhecer o próprio tráfego quando o clique chega sem parâmetro de
campanha. Recusar o valor seria decidir por quem grava; deixá-lo passar calado seria
entregar uma campanha sem atribuição e sem explicação.

**O que custa.** Um COOP mal escolhido passa a chegar ao navegador. `same-origin` quebra o
retorno da janela do WhatsApp, e quem gravar isso vai descobrir pelo comportamento — o
estado do módulo fica degradado, mas estado degradado não impede nada. O aviso do
`Referrer-Policy` acrescenta uma linha amarela na tela para uma configuração que pode ser
deliberada; ele só existe no ramo adverso, e com o valor padrão nenhum aviso sai.

**Como reverter.** Voltar o literal ao sanitizador e a constante ao emissor.
`seguranca.coop_do_valor_gravado` reprova em quatro asserções, e o piso dela grava um valor
diferente do padrão justamente para que o literal não possa passar por acaso.

---

## 55. Tracking dirigido por valores: um caminho só, um portão só, e nenhum Site Kit

**Decidido.** O site-core passa a emitir as tags de GA4, Google Ads, Meta e LinkedIn a
partir de IDs gravados em options — `f3base_gtm_container_id`,
`f3base_ga4_measurement_id`, `f3base_google_ads`, `f3base_meta_pixel_id`,
`f3base_linkedin_partner_id` e `f3base_linkedin_conversion_id` —, todas nascendo vazias e
inertes. `f3base_gtm_container_id` preenchido decide o caminho: sai o contêiner e mais
nada, e os IDs diretos **nem chegam ao navegador**. Vazio, saem as tags diretas dos IDs
presentes. As quatro passam pelo MESMO `permite_tags()` no servidor e pelo mesmo
`permiteTags()` no navegador. O clique do CTA é a conversão do site e sai nos quatro
canais, de `f3base-leads.js`. Pisos em `tracking.caminho_unico`,
`tracking.consentimento_gateia_tudo`, `leads.click_ids_no_schema` e
`js.conversao_multicanal`.

**Por quê.** O que existia era medição que PARECIA existir, e isso é pior que medição
ausente: ninguém procura o que o console não acusa. O pacote não tinha uma única ocorrência
de measurement ID, de `gtag.js`, de `AW-`, de `send_to`, de `fbq`, de `gclid`, de `fbclid`
ou de `li_fat_id`. O único `gtag` era o STUB do Consent Mode, que torna
`typeof gtag === 'function'` verdadeiro em toda página — então os eventos do CTA entravam
no `dataLayer` como arrays de comando e ficavam lá, esperando um consumidor que nada
carregava. E o evento que saía era `select_content`: `generate_lead` exigia formulário
preenchido, e o template não tem formulário nenhum.

O caminho por Site Kit foi recusado com medida: o OAuth dele é passo humano, e sob a
premissa de que quem opera é um agente, 100% do GA4 e do Google Ads dependeria de alguém
sentar na frente da tela. Valor gravado em option é o que um agente escreve pelo canal.

O caminho único é ESTRUTURAL, e não um `if` no cliente: no caminho do container os IDs
diretos não são publicados. Disparar em dobro deixa de ser um ramo esquecido e passa a ser
impossível, porque não há com o que disparar. Conversão contada duas vezes não é um número
errado num relatório — ela reescreve o lance do leilão.

**O que custa.** Seis options novas para manter, cada uma com forma de fornecedor que pode
mudar. O pacote NÃO recusa ID fora da forma: ele preserva o valor e emite um WARN nomeando
a forma esperada, porque apagar em silêncio é o que esta release inteira parou de fazer — o
preço é que um `G-` faltando produz uma tag que carrega e uma conta que não recebe nada, e
o operador só descobre pelo aviso. As Enhanced Conversions do Google nascem inertes: elas
só têm o que hashear quando um formulário associado fornece e-mail ou telefone, e o
template não tem formulário. O telefone só entra em E.164, com `+` e código do país —
adivinhar o país pelo idioma do site seria inventar um número.

**Como reverter.** Esvaziar as options faz o site voltar a não emitir nada, sem release
nova: é o mesmo mecanismo do slot inerte. Remover o desenho é outra coisa — apagar
`class-f3base-modulo-tracking.php` e `assets/f3base-tracking.js` reprova quatro checagens,
e `tracking.caminho_unico` nomeia o disparo em dobro como o defeito que a estrutura impede.

---

## 56. O contrato de copy sai do catálogo do site-core

**Decidido.** `f3base_copy_contrato` sai do catálogo de options do site-core, junto com
`sanitiza_copy_contrato()`. A suíte continua conferindo o contrato de copy contra o pacote
por `copy.contrato`, lendo `config/site.json`; o SITE deixa de carregar o contrato.

**Por quê.** Nenhum módulo o lia. A varredura é curta e conclusiva: `copy_contrato` aparecia
no catálogo, no sanitizador e em mais lugar nenhum do site-core. Era artefato de build para
o conteúdo do template — e vira falso no instante em que o agente troca o conteúdo, que é
exatamente o que a premissa desta release diz que vai acontecer. Uma option que ninguém lê
e que envelhece sozinha é pior que uma option ausente: ela dá ao próximo leitor a impressão
de que alguma coisa está sendo conferida dentro da instância.

**O que custa.** Quem quisesse conferir o contrato de copy DENTRO de um site publicado
perde o espelho. Ninguém fazia isso, e quem quiser fazer tem a suíte, que mede o pacote
inteiro e não só as frases que couberam numa option.

**Como reverter.** Devolver a entrada ao catálogo e o sanitizador. Nada reprova por si —
esta é uma remoção sem detector próprio, e está escrita aqui por isso.

**PENDENTE PARA A PARTE 2 DESTA RELEASE.** A escrita continua existindo em
`includes/class-f3base-imp-lotes.php`: a option é gravada no lote de options do site-core e
relida logo abaixo para a linha `copy.contrato_espelhado`. As duas precisam sair, junto com
a entrada de `f3base_copy_contrato` na lista literal de `options_gerenciadas()` em
`includes/class-f3base-imp-relatorio.php`. Enquanto não saírem, o implantador grava uma
option que o site não lê — que é o defeito descrito acima, um nível acima.

---

## 57. O que FICA como está, e por quê

Três mecanismos foram examinados sob a premissa do agente e **não** mudam. Estão aqui
porque decisão de não mudar também é decisão, e porque a próxima leitura vai fazer a mesma
pergunta.

- **O CPT de leads fechado ao REST fica fechado.** `show_in_rest => false` no CPT de
  contingência não é impedir modificação: é não expor dado pessoal de titular a toda
  credencial autenticada do site, que é o que abrir o REST faria. O agente lê os leads
  pelas rotas de banco do canal, que são credenciadas e auditadas. A saída existe e é
  documentada; o que não existe é a exposição por padrão.
- **A regra dinâmica de `noindex` em categoria rasa fica.** Ela já tem saída declarada, e a
  saída é do agente: gravar `wpseo_noindex = 'index'` no termo faz a categoria passar a ser
  indexada, e o módulo honra o valor do termo em vez de recalcular. Nenhuma release é
  necessária, nenhum arquivo é editado — é uma escrita de meta pelo canal.
- **O contador de ajustes da cadência fica.** Sob a premissa, ele é útil justamente por ser
  o que é: edição do agente conta como ajuste, e ao alcançar o alvo declarado dispara o
  relatório. Um agente que edita muito produz mais relatórios, e é isso que se quer de um
  site cuja manutenção é feita por quem não abre a tela.

---

## 58. As options ganham a regra de três vias, e a sobreposição sai com os dois valores

**Decidido.** Toda option do bloco do `site-core` passa por
`F3Base_Imp_Gravador::merge_option()` antes de qualquer escrita. O pacote registra a
**base** — o último valor que ele mesmo aplicou — e compara as três vias. Cinco ramos:
observado igual ao desejado não grava; base igual ao observado é atualização segura; base
igual ao desejado com observado diferente **preserva**; os três diferentes gravam
**nomeando a sobreposição com os dois valores**; e sem base a primeira execução aplica o
desejado **dizendo que a base nasceu agora**. A linha
`options.edicao_do_agente_preservada` fecha OK quando houve preservação e WARN quando
houve sobreposição — o único ramo adverso.

**Por quê.** O defeito estava medido e é de duas linhas:
`includes/class-f3base-imp-gravador.php`, no ponto em que ele calculava `$mudaria` e
gravava. Não havia base, não havia três vias, e o laço do bloco de options gravava as doze
options a partir de `config/site.json` a cada execução. Sob a premissa desta release — *"Após
a instalação, todas as futuras modificações serão realizadas por um agente através de MCP.
Então o template e plugins não devem tentar evitar que futuras modificações sejam
realizadas."* — isso significa que semanas de trabalho do agente eram apagadas no instante
em que alguém reativasse o implantador. Sem erro, sem log, com o relatório verde: a
gravação lia de volta e conferia, porque conferia contra o valor que ela mesma tinha
acabado de impor.

A regra do conteúdo já existia desde a 1.0.4 e é a mesma; o que faltava era aplicá-la ao
outro artefato. A base mora na option de infraestrutura que já guardava a do conteúdo —
`f3base_base_merge`, seção reservada `__options__` —, e não numa segunda estrutura: duas
estruturas para a mesma pergunta são duas chances de divergir e dois lugares para limpar.

**A PRIMEIRA EXECUÇÃO É DECLARADA, e essa é a metade que a 1.0.19 nos ensinou.** Estrutura
de estado nova que não diz o que faz quando ainda não há estado absolve a si mesma para
sempre. Aqui: numa instalação que tem a option e não tem base, o observado vira base e o
desejado é aplicado — e o relatório imprime QUAIS options tiveram a base nascida naquela
execução, porque só nela o pacote não consegue distinguir uma edição feita pelo canal de
um valor que sempre esteve ali.

**O que custa.** A base é mais uma estrutura de estado a manter, e ela pode ficar
desalinhada da realidade: quem apagar `f3base_base_merge` pelo canal faz toda option voltar
ao ramo "base nasceu agora" — e a próxima execução aplica a configuração por cima do que
estiver lá. É o custo declarado de uma regra que depende de memória. O segundo custo é de
tamanho: a base guarda o valor aplicado, e não só a impressão dele, porque a união dos
redirects precisa dos pares. A option não é autoload.

O terceiro custo é o mais importante, e ele é de MIGRAÇÃO: na primeira execução da 1.1.0
sobre uma instalação existente, nenhuma option tem base, e o desejado é aplicado em todas
— inclusive por cima de uma edição que o agente tivesse feito antes desta release. A
alternativa seria não aplicar nada na primeira execução, e ela é pior: o pacote deixaria de
convergir para a configuração sem que nada dissesse por quê. A linha do relatório nomeia as
options em que isso aconteceu.

**Como reverter.** Tirar `'base' => true` do contexto das escritas do bloco de options.
`options.merge_tres_vias` reprova nos cinco ramos e nas três frases que cada um precisa
imprimir, e a bancada mede a impressão que decide contra o mesmo round-trip da leitura de
volta — sem isso a regra passaria a decidir pelo tipo do valor em vez de pelo valor.

---

## 59. O conteúdo do template deixa de vencer o conteúdo do cliente

**Decidido.** Em `F3Base_Imp_Conteudo::merge_campo()`, o ramo `base ≠ observado ≠ desejado`
com política `gerenciado` passa de **gravar** para **preservar**. O pacote só grava
conteúdo em objeto que ninguém tocou — o ramo `base === observado`. Os campos preservados
saem NOMEADOS na linha do objeto, e essa é a segunda metade da decisão.

**Por quê.** O conteúdo que este pacote traz é DEMONSTRATIVO: ele existe para ser
substituído, e `conteudo.demonstrativo` já diz isso em voz alta a cada rodada. Uma vez que
o agente trocou o texto do template pelo do cliente, uma atualização do template não tem
por onde saber que o texto novo dela é melhor que o texto que está no ar — e a política
`gerenciado` fazia exatamente isso, silenciosamente, a cada reexecução.

A política de campo continua discriminando, e no único lugar em que ela ainda pode: SEM
BASE. Ali `gerenciado` aplica o desejado e `preservar` mantém o observado, porque é a
primeira execução e não existe edição a proteger nem a atropelar.

**A segunda metade: as decisões do merge nunca chegavam ao relatório.** `aplicar_objeto()`
montava um array `decisoes` e o devolvia em `saida()`, e NENHUMA linha do pacote lia esse
campo — a varredura é conclusiva, `'decisoes'` aparecia uma vez, no produtor. A decisão
mais importante da aplicação, que é o que o pacote deixou de gravar e por quê, não tinha
leitor. Preservar calado é indistinguível de não ter medido nada, então a divergência
preservada passou a entrar na mensagem do objeto, com os campos nomeados.

**O que custa.** Um site cujo conteúdo divergiu por engano — alguém salvou uma página no
editor sem querer — não é mais corrigido pela reexecução do implantador. A saída é do
agente: reescrever o conteúdo pelo canal, ou apagar a base daquele objeto. É o erro seguro
dos dois possíveis, e é o mesmo que a 1.1.0 escolhe em todos os outros lugares.

**Como reverter.** Devolver `'acao' => 'gravar'` ao ramo `gerenciado`.
`conteudo.merge_tres_vias` reprova na linha correspondente e no piso da regra inteira, que
percorre as quatro políticas e exige que NENHUMA produza gravação sobre observado diferente
da base.

---

## 60. Par de redirect removido pelo agente não ressuscita

**Decidido.** `uniao_de_redirects()` ganha uma quarta parcela, e ela é uma SUBTRAÇÃO: par
que estava na base da option e não está mais no valor observado foi apagado por quem opera
o site, e não volta — nem pela configuração, nem por uma etapa que o recompute. A lista de
removidos é DURÁVEL: ela viaja na base da option, sob a origem `removido-pelo-operador`, e
é ela que impede a execução seguinte de recriar o par. Presença no observado vence a
memória da remoção: refazer o par pelo canal o traz de volta e apaga a marca.

**Por quê.** A união unia três fontes e rederivava, a cada execução, todo par declarado na
configuração ou computado por uma etapa. O agente que apagasse um 301 obsoleto da option
via o par ressuscitar na reexecução seguinte, sem nada no relatório. O par NOVO do agente
já sobrevivia — `preexistente` existe desde a 1.0.11 —, mas a subtração não tinha como ser
expressa: ausência não deixa rastro, e sem base não havia contra o que compará-la.

**A MARCA NÃO VIAJA DENTRO DE `f3base_redirects`, e isso foi medido antes de decidir.** O
módulo de redirects do `site-core` serve TODO par da option, sem olhar a origem: um par
marcado ali continuaria redirecionando, e a marca teria o efeito exatamente contrário ao
pretendido. Ela mora na base de merge, que é infraestrutura do implantador e que o
`site-core` não lê.

**O que custa.** A remoção passa a ser lembrada, e lembrança é estado. Quem apagar
`f3base_base_merge` perde a memória das remoções, e os pares declarados voltam na execução
seguinte. E há um caso que a regra não distingue: par que sumiu da option por corrupção de
dados é tratado como remoção deliberada. O relatório o NOMEIA, que é a única defesa
possível — e é mais barata que ressuscitar o par de quem o apagou de propósito.

Há também uma interação medida na bancada de ponta a ponta, e ela é o preço de a base ser
por OPTION e não por par. Repontar um par declarado pelo canal, sem removê-lo antes, é
PRESERVADO pela regra de três vias da decisão 58 — o desejado volta a ser o declarado, que
é igual à base, e a edição vence. Mas remover o par e recriá-lo com outro destino cai em
SOBREPOSIÇÃO: a base ficou vazia na remoção, os três valores passam a divergir, e o
declarado da configuração é aplicado. O caminho longo dá um resultado diferente do curto —
e a diferença sai NOMEADA com os dois destinos, que é o que esta release exige do único
ramo em que o pacote vence quem opera o site.

**Como reverter.** Tirar o quarto argumento de `uniao_de_redirects()` e os dois laços de
lápide. `lotes.redirects_uniao` reprova em seis asserções novas: o par declarado que volta,
o par computado que volta, a remoção que não fica registrada, a origem errada, a lista
durável que não segura na execução seguinte e o par refeito que não volta a existir.

---

## 61. A cadência agenda com a recorrência declarada, e a queda anterior é reparada

**Decidido.** Três mudanças na mesma etapa. A option `f3base_cadencia` passa a ser gravada
**antes** do agendamento. `cadencia` declara dependência de `site_core` em
`F3Base_Imp_Plano`. E a decisão da recorrência virou função pura,
`veredito_da_recorrencia()`, com três ações fechadas: `agendar`, `reagendar` e `manter`.

**Por quê.** Medido na execução real: o log registrou `daily` com a configuração declarando
`mensal`. A cadeia é esta, e ela é circular. Quem registra `f3base_quinzenal` e
`f3base_mensal` é o módulo `cadencia-relatorio` do `site-core`, num filtro `cron_schedules`.
Módulo INATIVO não registra hook nenhum, e esse módulo fica inativo enquanto
`f3base_cadencia` não existir. Quem grava `f3base_cadencia` é esta etapa — DEPOIS de
agendar. Na primeira execução, portanto, a recorrência declarada não podia existir: o
agendamento acontecia na única execução em que ele não tinha como dar certo.

E a degradação era PERMANENTE. Na execução seguinte o módulo já estaria ativo e a
recorrência existiria, mas a etapa encontrava `wp_next_scheduled()` verdadeiro e não olhava
COM O QUE o evento tinha sido agendado. O `site-core` fechava degradado dizendo "reexecute a
etapa de cadência do implantador com este plugin já ativo" — e a reexecução não mudava
nada.

**O REPARO TEM ALCANCE ESTREITO, de propósito.** Ele só troca a recorrência quando a
observada é exatamente a recorrência de queda, a declarada é outra e a declarada existe
agora no agendador. Qualquer outra recorrência no evento é decisão de quem opera o site, e
esta etapa não a desfaz — que é a mesma regra do resto desta release. A tabela de
recorrências continua vindo do MÓDULO: quando ele está carregado e o filtro não foi
registrado nesta requisição, a etapa registra o filtro DELE, em vez de escrever "quinze
dias" e "trinta dias" numa segunda fonte.

**O que custa.** Um reagendamento joga a próxima execução da cadência para daqui a um dia,
e isso acontece uma vez por instalação degradada. E há um caso que a regra não distingue:
quem tiver escolhido `daily` deliberadamente, com a configuração declarando outra coisa,
tem a escolha desfeita — `daily` é justamente o valor que a nossa degradação escreve, e os
dois chegam iguais à etapa. O relatório nomeia a troca.

**Como reverter.** Voltar a gravar `f3base_cadencia` depois do agendamento, ou tirar o ramo
`reagendar`. `cadencia.recorrencia_declarada` reprova nos dois lados: sem o site-core na
tabela a queda precisa acontecer e sair nomeada, com ele a recorrência agendada precisa ser
a declarada, a queda anterior precisa ser reparada, e o piso do falso positivo exige que
uma recorrência que não é a nossa queda continue intocada.

---

## 62. A caixa de leads passa a morar dentro do regime que a consome

**Decidido.** `contato.email_leads` sai do topo de `contato` e vira
`formularios[].caixa_de_leads`, na entrada do regime `cf7-email` que a declara como
`destino`. O implantador deixa de gravar a subchave `email_leads` em `f3base_contato`. O
caminho antigo entra em `suite/chaves-removidas.tsv`, e um detector novo —
`estatica.destino_de_formulario_resolve` — passa a cobrar que todo `destino` resolva numa
chave existente e que caminho com índice aponte para a PRÓPRIA entrada.

**Por quê.** Aplicado o teste da 1.0.19 — *o que muda se eu mudar isto?* — a resposta foi:
duas linhas de relatório, e mais nada. `grep -rn email_leads fontes/` devolve três
ocorrências, todas no catálogo de options do `site-core`: o padrão, a declaração de subcampo
e o sanitizador. Nenhum módulo lê o valor. Preencher a chave não instala o Contact Form 7,
não cria o formulário, não cria a página de confirmação e não manda e-mail para lugar
nenhum: ela flipa `formulario.landing-cf7` de N/A para OK e `formulario.regime_cf7` de N/A
para BLOCKED.

A chave sentava ao lado de `contato.whatsapp_e164`, e a simetria era falsa: o número do
WhatsApp TEM consumidor em runtime — o módulo do CTA o lê e publica o botão —, e a caixa de
leads não tinha nenhum. Ela não é identidade de contato do site; é propriedade de um regime
de formulário, e passou a morar nele.

**Por que ela não SAIU inteira.** A alternativa era remover a chave e, com ela, a entrada
do regime — `destino` vazio faz `veredito_destino()` fechar FALHA, e não há terceira
posição. Isso apagaria o conjunto fechado do regime, que o pacote registra de propósito para
quem precisar dele. Mover é reversível; remover a entrada não é.

**O que custa.** O caminho passou a ter um ÍNDICE dentro —
`formularios.1.caixa_de_leads` —, e índice em caminho quebra quando alguém reordena a
lista, em silêncio: a entrada 1 passaria a ler a chave da entrada 0. É um preço criado por
esta decisão, e por isso ele veio com detector próprio, com fixture negativa e positiva em
disco. O segundo custo: o implantador deixou de escrever `email_leads` em `f3base_contato`,
e na PRIMEIRA execução da 1.1.0 — aquela em que a base ainda não existe — um valor que
alguém tivesse gravado ali pelo canal é sobreposto. Da segunda execução em diante a regra de
três vias o preserva.

**Como reverter.** Tirar a linha de `suite/chaves-removidas.tsv` e devolver a chave a
`contato`. Enquanto a linha estiver lá, `estatica.sem_residuo_de_chave_removida` reprova o
caminho antigo em configuração, schema, código e documento.

---

## 63. O que a suíte consome do arquivo único passa a ser declarado

**Decidido.** `estatica.detector_chave_sem_consumidor` ganha uma âncora,
`f3b_config_lida_pela_suite()`, que declara os caminhos de `config/site.json` consumidos
pela PRÓPRIA SUÍTE — hoje um só, `copy_contrato`, lido por `copy.contrato`. A declaração
não absolve sozinha: cada caminho precisa aparecer LITERALMENTE no arquivo da suíte que se
diz o consumidor, e a conferência roda contra a suíte que está executando, não contra a raiz
varrida.

**Por quê.** O detector enxergava UMA forma de leitura, `Config::obter|lista|existe`, que é
a do implantador. Enquanto toda chave do arquivo único tivesse também um leitor no
implantador, isso bastava — e bastou por acaso, não por desenho. A decisão 56 tirou
`f3base_copy_contrato` do catálogo do `site-core`; esta release tirou a escrita da option e
o espelho do implantador. Com eles saiu o último leitor de `copy_contrato` no código do
implantador, e o detector passou a acusar como órfã uma chave que TEM consumidor — a suíte,
que a lê direto do JSON decodificado.

A correção óbvia seria devolver a option morta, e ela é a errada: é justamente o defeito que
a decisão 56 descreveu. A correção certa é o detector saber que existe uma segunda forma de
consumo, e que ela é declarada.

**O que custa.** Uma lista que, mal usada, vira lista de exceções: bastaria acrescentar um
caminho para calar o cruzamento sobre ele. A guarda é a conferência literal, e ela é fraca —
o caminho pode estar num comentário do arquivo declarado. É uma guarda melhor que nenhuma e
pior que um consumidor de verdade, e está escrito aqui que é assim.

**Como reverter.** Esvaziar a âncora. `estatica.detector_chave_sem_consumidor` volta a
acusar `copy_contrato` e as nove chaves abaixo dela, e a próxima pessoa reabre esta
discussão com a lista na frente.

---

## 64. Quem preserva não move a base, e é isso que faz a preservação durar

**Decidido.** `merge_campo()` e `merge_option()` passam a devolver, junto da ação, o
DESTINO DA BASE — `desejado` ou `inalterada` — e os dois chamadores obedecem a ele em vez
de inferi-lo da ação. Ramo que preserva devolve `inalterada`: a base fica exatamente onde
estava. Ramo que aplica alguma coisa devolve `desejado`.

**Por quê.** O defeito foi encontrado numa bancada de ponta a ponta montada para conferir
a plumbing da decisão 58 — não a função pura, que já tinha piso, e sim o que acontece com
o BANCO em execuções sucessivas. A sequência medida: execução 1 grava e a base nasce; o
agente grava um número de WhatsApp pelo canal; execução 2 PRESERVA, correto; execução 3,
com a configuração mudada, devia sair como SOBREPOSIÇÃO e saiu como *atualização segura,
ninguém editou esta option pelo canal* — uma frase falsa, sobre uma edição que existia.

A causa é de uma linha. O ramo `preservar` gravava a base como o valor OBSERVADO, e base
igual ao observado é justamente a condição do ramo "ninguém tocou". A preservação, então,
apagava o fato que ela existe para lembrar: na execução seguinte a edição intocada passava
a ser lida como valor do próprio pacote, e a primeira mudança da configuração gravava por
cima dela **sem nomear sobreposição nenhuma**. A proteção valia por uma execução, e o
único ramo em que o pacote vence quem opera o site — o que precisa ser visível — ficava
praticamente inalcançável.

**O CONTEÚDO TINHA O MESMO DEFEITO, e ele é anterior a esta release.** `aplicar_objeto()`
faz `$nova_base[$campo] = $hash_obs` no ramo `preservar` desde a 1.0.4. Com a política
antiga isso passava despercebido, porque `gerenciado` gravava de qualquer jeito; com a
inversão da decisão 59 ele viraria o buraco no meio da garantia — o conteúdo do cliente
sobreviveria a UMA atualização do template e seria sobrescrito na seguinte. A correção é a
mesma nos dois lugares, e por isso a regra virou parte do contrato das duas funções puras
em vez de uma linha certa em cada chamador.

**O que custa.** A divergência preservada é RE-RELATADA em toda execução, para sempre,
enquanto a configuração e o site discordarem. É ruído deliberado: a alternativa é o
relatório calar sobre uma divergência que continua existindo. E a convergência deixa de
acontecer sozinha — um site cuja option divergiu por engano só volta a acompanhar a
configuração quando alguém mudar a configuração ou apagar a base daquele item.

**Como reverter.** Devolver `BASE_DESEJADO` ao ramo `preservar` de qualquer uma das duas
funções. `options.merge_tres_vias` e `conteudo.merge_tres_vias` reprovam nomeando a
consequência — a preservação que dura uma execução —, e os tetos do mesmo bloco exigem o
contrário para os ramos que aplicam: valor aplicado que não vira base faria o pacote
reaplicar o mesmo item em toda execução, e a preservação nunca teria contra o que comparar.

---

## 65. Duas correções fora do roteiro desta parte, e por que elas foram feitas

**Decidido.** Duas coisas que não estavam na lista desta parte da release foram corrigidas,
e ficam registradas aqui porque decisão fora do roteiro é a que mais precisa de rastro.

**A descrição do catálogo do `site-core` para `f3base_cabecalhos`.** Ela dizia *"COOP fica
travado em same-origin-allow-popups"* — uma frase que a decisão 54, desta mesma release,
tornou falsa: o cabeçalho emitido passou a ser o VALOR GRAVADO, e o sanitizador daquele
mesmo arquivo já explicava isso três funções abaixo. A descrição é o texto que o operador e
o agente leem na tela de options, e afirmar trava onde não há trava é pior que não
descrever nada: quem lesse aquilo deixaria de tentar gravar um valor que o pacote aceita. A
frase passou a dizer o que o módulo faz — emite o gravado, e NOMEIA a consequência de sair
de `same-origin-allow-popups` em vez de recusá-la.

**O bundle da identidade anterior em `dist/`.** `dist/implantador-base-1.0.19.zip`
continuava ao lado do bundle novo. `dist/` é saída de build e nenhuma checagem reprova por
um artefato a mais ali, mas dois bundles no mesmo diretório são dois candidatos a upload, e
o antigo carrega a configuração e os documentos de uma identidade que já não existe. Ele
saiu. O comando único regrava `dist/` a cada rodada, e é ele quem produz o bundle da
identidade declarada.

**O que custa.** O primeiro é edição num arquivo que esta parte da release não tinha como
escopo, e está aqui por isso. O segundo apaga um artefato que alguém poderia querer para
comparação — e a resposta é que o artefato de uma release anterior mora no repositório de
artefatos, não na saída de build da árvore de trabalho.

**Como reverter.** As duas são de uma linha e de um arquivo. Nenhuma tem detector próprio:
a primeira é prosa dentro do catálogo, e a segunda é o conteúdo de um diretório gerado.
Estão escritas aqui porque é isso que sobra quando não há detector.
