/**
 * F3 Base Site Core — carregador único das tags de medição.
 *
 * Este arquivo só chega ao HTML quando as duas condições fecham no servidor: há
 * pelo menos um ID gravado E o consentimento permite tags. A conferência de
 * consentimento é REFEITA aqui porque página em cache congela a decisão do
 * primeiro visitante: o servidor decide se o carregador entra, o navegador
 * decide se a tag carrega.
 *
 * UM CAMINHO, E UM SÓ. Com container do GTM preenchido, este arquivo emite o
 * contêiner e mais nada: as tags moram lá dentro, e emitir também a tag direta
 * contaria a mesma conversão duas vezes. Sem container, ele emite as tags
 * diretas dos IDs presentes — `gtag.js` servindo GA4 e Google Ads no mesmo
 * `gtag`, o Pixel da Meta e o Insight Tag do LinkedIn.
 *
 * O QUE ELE NÃO FAZ: disparar conversão. A conversão do clique é do
 * `f3base-leads.js`, que é onde o clique acontece — um lugar só, para que
 * acrescentar um canal não vire quatro edições.
 *
 * Pixel e Insight Tag NÃO TÊM modo de consentimento: para eles, negativa é
 * ausência. O `gtag` tem Consent Mode v2, e o estado default já foi empurrado
 * pelo `f3base-consentimento.js` antes deste arquivo rodar.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseTrackingDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CAMINHO = String(dados.caminho || 'nenhum');
	var carregado = false;

	window.dataLayer = window.dataLayer || [];

	/**
	 * O portão, do lado do navegador.
	 *
	 * Sem o objeto do consentimento na página não há o que consultar, e a
	 * ausência dele não pode virar bloqueio silencioso: o servidor já decidiu
	 * uma vez, e ele é a decisão de reserva.
	 */
	function permiteTags() {
		if (window.f3baseConsentimento && typeof window.f3baseConsentimento.permiteTags === 'function') {
			return window.f3baseConsentimento.permiteTags();
		}

		return true;
	}

	/**
	 * Insere um <script> externo uma vez só, pelo id declarado.
	 */
	function inserir(id, src) {
		if (document.getElementById(id)) {
			return;
		}

		var tag = document.createElement('script');

		tag.id = id;
		tag.async = true;
		tag.src = src;

		var primeiro = document.getElementsByTagName('script')[0];

		if (primeiro && primeiro.parentNode) {
			primeiro.parentNode.insertBefore(tag, primeiro);
		} else {
			document.head.appendChild(tag);
		}
	}

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	/**
	 * Caminho do contêiner: o GTM entra, e nada mais.
	 */
	function carregarGtm() {
		window.dataLayer.push({
			event: 'gtm.js',
			'gtm.start': new Date().getTime()
		});

		inserir('f3base-gtm', String(dados.origemGoogle) + 'gtm.js?id=' + encodeURIComponent(String(dados.gtm)));
	}

	/**
	 * gtag.js de verdade — GA4 e Google Ads na MESMA instância.
	 *
	 * O carregador é pedido com o primeiro ID presente; os `config` seguintes
	 * registram o resto. É assim que o fornecedor documenta duas contas no mesmo
	 * gtag, e é o que evita dois carregadores brigando pelo mesmo dataLayer.
	 */
	function carregarGoogleDireto() {
		var ga4 = String(dados.ga4 || '');
		var ads = dados.ads && typeof dados.ads === 'object' ? String(dados.ads.id || '') : '';
		var primeiro = ga4 || ads;

		if (!primeiro) {
			return;
		}

		inserir('f3base-gtag', String(dados.origemGoogle) + 'gtag/js?id=' + encodeURIComponent(primeiro));

		window.gtag('js', new Date());

		if (ga4) {
			window.gtag('config', ga4);
		}

		if (ads) {
			window.gtag('config', ads);
		}
	}

	/**
	 * Pixel da Meta, com o `fbq` na forma que o fornecedor consome.
	 */
	function carregarMeta() {
		var pixel = dados.meta && typeof dados.meta === 'object' ? String(dados.meta.pixelId || '') : '';

		if (!pixel) {
			return;
		}

		if (!window.fbq) {
			var fila = function () {
				if (fila.callMethod) {
					fila.callMethod.apply(fila, arguments);
				} else {
					fila.queue.push(arguments);
				}
			};

			fila.push = fila;
			fila.loaded = true;
			fila.version = '2.0';
			fila.queue = [];

			window.fbq = fila;
			window._fbq = window._fbq || fila;
		}

		inserir('f3base-meta-pixel', String(dados.meta.origem));

		window.fbq('init', pixel);
		window.fbq('track', 'PageView');
	}

	/**
	 * Insight Tag do LinkedIn — page view; a conversão é do clique.
	 */
	function carregarLinkedin() {
		var parceiro = dados.linkedin && typeof dados.linkedin === 'object' ? String(dados.linkedin.partnerId || '') : '';

		if (!parceiro) {
			return;
		}

		window._linkedin_partner_id = parceiro;
		window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];

		if (window._linkedin_data_partner_ids.indexOf(parceiro) === -1) {
			window._linkedin_data_partner_ids.push(parceiro);
		}

		inserir('f3base-linkedin-insight', String(dados.linkedin.origem));
	}

	function carregar() {
		if (carregado || !permiteTags()) {
			return;
		}

		carregado = true;

		if (CAMINHO === 'gtm') {
			carregarGtm();
			return;
		}

		if (CAMINHO === 'direto') {
			carregarGoogleDireto();
			carregarMeta();
			carregarLinkedin();
		}
	}

	/*
	 * O re-aceite religa NESTA navegação. Sem este ouvinte, quem negava, mudava
	 * de ideia no controle do rodapé e ficava na mesma página não era medido até
	 * navegar — e a decisão que o visitante acabou de tomar é a que vale.
	 */
	document.addEventListener('f3base-consentimento', function () {
		carregar();
	});

	window.f3baseTracking = {
		caminho: function () {
			return CAMINHO;
		},
		carregar: carregar,
		permiteTags: permiteTags
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', carregar);
	} else {
		carregar();
	}
}(window, document));
