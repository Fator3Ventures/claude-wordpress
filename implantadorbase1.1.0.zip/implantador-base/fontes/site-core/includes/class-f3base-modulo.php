<?php
/**
 * Contrato de um módulo do site-core.
 *
 * Um módulo declara identidade, dependências, options que o controlam, hooks e
 * um `estado()` que devolve ativo, inativo ou degradado COM MOTIVO. O registro
 * único lê esta declaração para (a) registrar hooks, (b) desenhar a tela e
 * (c) montar o relatório — não existe segunda lista.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base comum dos módulos.
 */
abstract class F3Base_Modulo {

	/**
	 * Estados fechados de um módulo.
	 */
	public const ATIVO     = 'ativo';
	public const INATIVO   = 'inativo';
	public const DEGRADADO = 'degradado';

	/**
	 * Estado memoizado por requisição.
	 *
	 * @var array{estado:string,motivo:string}|null
	 */
	private ?array $estado_memo = null;

	/**
	 * Identificador estável do módulo.
	 *
	 * @return string
	 */
	abstract public function id(): string;

	/**
	 * Nome legível.
	 *
	 * @return string
	 */
	abstract public function nome(): string;

	/**
	 * Descrição do que o módulo faz.
	 *
	 * @return string
	 */
	abstract public function descricao(): string;

	/**
	 * Hooks que o módulo registra.
	 *
	 * Cada item: `tipo` (action|filter), `hook`, `metodo`, `prioridade`, `args`
	 * e, opcionalmente, `sempre`.
	 *
	 * `SEMPRE` É EXCEÇÃO DECLARADA, E ELA TEM UM MOTIVO SÓ: há hook cuja decisão
	 * é POR OBJETO, e não pelo estado do módulo. O filtro que decide se um bloco
	 * é publicado é assim — a resposta dele para um bloco depende do que aquele
	 * bloco tem, e o caso em que o módulo está inativo é justamente um dos casos
	 * que ele precisa decidir. Um filtro desses que não registra não decide nada,
	 * e a regra que ele implementa vira letra morta sem ninguém perceber: foi o
	 * que aconteceu com a supressão do CTA da 1.0.19 à 1.1.0.
	 *
	 * Hook sem `sempre` continua valendo a regra normal — módulo inativo não o
	 * registra. A exceção é por hook, é declarada no próprio item, e sai na tela
	 * ao lado dele.
	 *
	 * @return array<int,array{tipo:string,hook:string,metodo:string,prioridade:int,args:int,sempre?:bool}>
	 */
	abstract public function hooks(): array;

	/**
	 * Cálculo do estado real. Devolve `['estado' => ..., 'motivo' => ...]`.
	 *
	 * O motivo NUNCA repete a palavra do estado: quem imprime "ativo" é o
	 * registro, e "ativo — ativo" é ruído.
	 *
	 * @return array{estado:string,motivo:string}
	 */
	abstract protected function calcular_estado(): array;

	/**
	 * Estado real do módulo, memoizado e normalizado.
	 *
	 * @return array{estado:string,motivo:string}
	 */
	final public function estado(): array {
		if ( null !== $this->estado_memo ) {
			return $this->estado_memo;
		}

		$bruto = $this->calcular_estado();

		$estado = isset( $bruto['estado'] ) ? (string) $bruto['estado'] : self::INATIVO;
		if ( ! in_array( $estado, array( self::ATIVO, self::INATIVO, self::DEGRADADO ), true ) ) {
			$estado = self::INATIVO;
		}

		$motivo = isset( $bruto['motivo'] ) ? (string) $bruto['motivo'] : '';

		$this->estado_memo = array(
			'estado' => $estado,
			'motivo' => self::motivo_sem_eco( $estado, $motivo ),
		);

		return $this->estado_memo;
	}

	/**
	 * O módulo deve registrar os hooks NORMAIS nesta requisição?
	 *
	 * Módulo inativo é inerte: nenhum endpoint, tabela, asset ou superfície
	 * pública. Ele aparece na tela com o motivo, e só. A exceção — e é uma só —
	 * são os hooks marcados `sempre` em `hooks()`, cuja decisão é por objeto e
	 * não pelo estado do módulo; a marca é declarada no item e o motivo dela está
	 * escrito lá.
	 *
	 * @return bool
	 */
	public function deve_registrar(): bool {
		$estado = $this->estado();

		return self::INATIVO !== $estado['estado'];
	}

	/**
	 * Dependências declaradas do módulo.
	 *
	 * Cada item: `rotulo`, `presente` (bool), `detalhe`.
	 *
	 * @return array<int,array{rotulo:string,presente:bool,detalhe:string}>
	 */
	public function dependencias(): array {
		return array();
	}

	/**
	 * Options que controlam o módulo.
	 *
	 * @return string[]
	 */
	public function options_que_controlam(): array {
		return array();
	}

	/**
	 * Frases de última atividade relevante.
	 *
	 * @return string[]
	 */
	public function atividade(): array {
		return array();
	}

	/**
	 * AVISOS do módulo — o que continua funcionando com um preço nomeado.
	 *
	 * O estado do módulo responde "isto funciona?", e há coisa que funciona
	 * exatamente como foi pedida e ainda assim custa alguma coisa em outro
	 * lugar: um cabeçalho que apaga a atribuição dos canais pagos é o caso
	 * medido. Aviso não é estado: um módulo com aviso continua ativo, os hooks
	 * continuam registrados e nada é recusado.
	 *
	 * Cada item traz `estado` (sempre WARN) e `motivo`. A lista nasce vazia, e
	 * quem a preenche mede alguma coisa antes: aviso sem ramo adverso é aviso
	 * que sai sempre, e aviso que sai sempre treina o operador a ignorar aviso.
	 *
	 * @return array<int,array{estado:string,motivo:string}>
	 */
	public function avisos(): array {
		return array();
	}

	/**
	 * Estrutura própria criada na ativação (tabelas, agendamentos, CPT flush).
	 *
	 * @return void
	 */
	public function instalar(): void {}

	/**
	 * Estrutura própria desfeita na desativação.
	 *
	 * @return void
	 */
	public function desinstalar(): void {}

	/**
	 * Atalho para montar um estado ativo.
	 *
	 * @param string $motivo Motivo, sem repetir a palavra do estado.
	 * @return array{estado:string,motivo:string}
	 */
	protected function ativo( string $motivo ): array {
		return array(
			'estado' => self::ATIVO,
			'motivo' => $motivo,
		);
	}

	/**
	 * Atalho para montar um estado inativo.
	 *
	 * @param string $motivo Motivo, sem repetir a palavra do estado.
	 * @return array{estado:string,motivo:string}
	 */
	protected function inativo( string $motivo ): array {
		return array(
			'estado' => self::INATIVO,
			'motivo' => $motivo,
		);
	}

	/**
	 * Atalho para montar um estado degradado.
	 *
	 * Degradado é reservado ao que está PIOR que o desenho. Reserva ociosa com o
	 * principal funcionando é ativo.
	 *
	 * @param string $motivo Motivo, sem repetir a palavra do estado.
	 * @return array{estado:string,motivo:string}
	 */
	protected function degradado( string $motivo ): array {
		return array(
			'estado' => self::DEGRADADO,
			'motivo' => $motivo,
		);
	}

	/**
	 * Um plugin está ativo, lido do banco e sem depender de `wp-admin/includes`.
	 *
	 * @param string $pasta Pasta do plugin (slug do diretório).
	 * @return bool
	 */
	protected function plugin_ativo( string $pasta ): bool {
		$ativos = get_option( 'active_plugins', array() );
		$ativos = is_array( $ativos ) ? $ativos : array();

		if ( is_multisite() ) {
			$rede = get_site_option( 'active_sitewide_plugins', array() );
			if ( is_array( $rede ) ) {
				$ativos = array_merge( $ativos, array_keys( $rede ) );
			}
		}

		foreach ( $ativos as $arquivo ) {
			if ( str_starts_with( (string) $arquivo, $pasta . '/' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Remove eco do estado no começo do motivo.
	 *
	 * Guarda de disciplina: se alguém escrever "ativo — reserva em espera", o
	 * registro imprime a palavra uma vez só.
	 *
	 * @param string $estado Estado calculado.
	 * @param string $motivo Motivo declarado.
	 * @return string
	 */
	private static function motivo_sem_eco( string $estado, string $motivo ): string {
		$motivo = trim( $motivo );
		if ( '' === $motivo ) {
			return $motivo;
		}

		$padrao = '/^' . preg_quote( $estado, '/' ) . '\s*(?:[:\x{2014}\x{2013}-]\s*)?/iu';
		$limpo  = preg_replace( $padrao, '', $motivo );

		return is_string( $limpo ) && '' !== $limpo ? $limpo : $motivo;
	}
}
