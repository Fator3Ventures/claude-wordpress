<?php
/**
 * Módulo tracking.
 *
 * O QUE MUDOU NA 1.1.0, dito com a medida que motivou a mudança: até a 1.0.19
 * este pacote não tinha GA4, não tinha Google Ads e não tinha Meta. Zero
 * ocorrência de measurement ID, de `gtag.js`, de `AW-`, de `send_to`, de `fbq`,
 * de `gclid`, de `fbclid` e de `li_fat_id`. O único `gtag` era o STUB do Consent
 * Mode — que torna `typeof gtag === 'function'` verdadeiro em toda página — e os
 * eventos do CTA entravam no `dataLayer` como arrays de comando que ninguém
 * consumia, porque nada carregava o `gtag.js`. Medição que parece existir é pior
 * que medição ausente: ninguém vai procurar o que o console não acusa.
 *
 * O desenho agora é dirigido por VALOR, e nunca por interruptor:
 *
 * - Slot vazio é inerte. Sem ID não sai marcação nenhuma — nunca um placeholder,
 *   nunca um `undefined` no `send_to`. A ausência é dita pelo nome da chave.
 * - `f3base_gtm_container_id` PREENCHIDO decide o caminho e ele é um só: o site
 *   emite o contêiner e alimenta o `dataLayer` com objetos `{event: …}`, e
 *   NENHUMA tag direta é emitida — duas fontes para a mesma conversão é conversão
 *   contada em dobro, e conversão em dobro reescreve o lance do leilão.
 * - Vazio, o site emite as tags diretas dos IDs presentes: `gtag.js` (GA4 e Ads
 *   no mesmo gtag), o Pixel da Meta e o Insight Tag do LinkedIn.
 * - As QUATRO tags passam pelo mesmo portão de consentimento, no servidor e de
 *   novo no navegador. Consent Mode v2 continua valendo para o `gtag`; Pixel e
 *   Insight não têm equivalente, e por isso na negativa eles NÃO SÃO CARREGADOS
 *   — não existe "atualizar para negado" para quem já carregou.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tags de terceiro e eventos de medição.
 */
final class F3Base_Modulo_Tracking extends F3Base_Modulo {

	/**
	 * Handle do carregador único das tags.
	 */
	public const HANDLE = 'f3base-tracking';

	/**
	 * Origem do Insight Tag do LinkedIn.
	 */
	public const ORIGEM_LINKEDIN = 'https://snap.licdn.com/li.lms-analytics/insight.min.js';

	/**
	 * Origem do carregador do Google (gtag.js e gtm.js saem daqui).
	 */
	public const ORIGEM_GOOGLE = 'https://www.googletagmanager.com/';

	/**
	 * Origem do Pixel da Meta.
	 */
	public const ORIGEM_META = 'https://connect.facebook.net/en_US/fbevents.js';

	/**
	 * Caminhos fechados de emissão.
	 */
	public const CAMINHO_GTM     = 'gtm';
	public const CAMINHO_DIRETO  = 'direto';
	public const CAMINHO_NENHUM  = 'nenhum';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'tracking';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Tracking', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Emite as tags de GA4, Google Ads, Meta e LinkedIn a partir dos IDs gravados, sob um único portão de consentimento. Container do GTM preenchido decide o caminho e desliga toda tag direta, para que nada dispare em dobro; slot vazio é inerte e nada é emitido.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 20,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array(
			'f3base_gtm_container_id',
			'f3base_ga4_measurement_id',
			'f3base_google_ads',
			'f3base_meta_pixel_id',
			'f3base_linkedin_partner_id',
			'f3base_linkedin_conversion_id',
			'f3base_tracking',
		);
	}

	/**
	 * Os IDs gravados, por nome de option.
	 *
	 * FONTE ÚNICA dos slots: o estado, as dependências, o aviso de formato e o
	 * que vai para o navegador leem daqui. Duas listas de slots divergiriam no
	 * primeiro canal acrescentado.
	 *
	 * @return array<string,string>
	 */
	public static function ids(): array {
		$ads = F3Base_Options::ler( 'f3base_google_ads' );
		$ads = is_array( $ads ) ? $ads : array();

		return array(
			'f3base_gtm_container_id'       => (string) F3Base_Options::ler( 'f3base_gtm_container_id' ),
			'f3base_ga4_measurement_id'     => (string) F3Base_Options::ler( 'f3base_ga4_measurement_id' ),
			'f3base_google_ads.conversion_id'    => (string) ( $ads['conversion_id'] ?? '' ),
			'f3base_google_ads.conversion_label' => (string) ( $ads['conversion_label'] ?? '' ),
			'f3base_meta_pixel_id'          => (string) F3Base_Options::ler( 'f3base_meta_pixel_id' ),
			'f3base_linkedin_partner_id'    => (string) F3Base_Options::ler( 'f3base_linkedin_partner_id' ),
			'f3base_linkedin_conversion_id' => (string) F3Base_Options::ler( 'f3base_linkedin_conversion_id' ),
		);
	}

	/**
	 * FORMA declarada de cada identificador, por nome de chave.
	 *
	 * A forma não recusa a escrita — o sanitizador guarda o que foi gravado. Ela
	 * existe para o aviso: `G-` faltando no measurement ID produz um `gtag.js`
	 * que carrega e não mede nada, e o silêncio disso custa uma campanha
	 * inteira. Rótulo de conversão do Ads não tem forma pública declarada pelo
	 * fornecedor, e por isso não está aqui: inventar um formato seria pior.
	 *
	 * @return array<string,array{regex:string,forma:string}>
	 */
	public static function formas(): array {
		return array(
			'f3base_gtm_container_id'         => array(
				'regex' => '/^GTM-[A-Z0-9]{4,}$/',
				'forma' => 'GTM-XXXXXXX',
			),
			'f3base_ga4_measurement_id'       => array(
				'regex' => '/^G-[A-Z0-9]{4,}$/',
				'forma' => 'G-XXXXXXXXXX',
			),
			'f3base_google_ads.conversion_id' => array(
				'regex' => '/^AW-[0-9]{6,}$/',
				'forma' => 'AW-000000000',
			),
			'f3base_meta_pixel_id'            => array(
				'regex' => '/^[0-9]{8,}$/',
				'forma' => 'somente dígitos',
			),
			'f3base_linkedin_partner_id'      => array(
				'regex' => '/^[0-9]{4,}$/',
				'forma' => 'somente dígitos',
			),
			'f3base_linkedin_conversion_id'   => array(
				'regex' => '/^[0-9]{4,}$/',
				'forma' => 'somente dígitos',
			),
		);
	}

	/**
	 * Algum slot de medição está preenchido?
	 *
	 * @return bool
	 */
	public static function ha_slot_preenchido(): bool {
		foreach ( self::ids() as $valor ) {
			if ( '' !== $valor ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * O CAMINHO desta instalação, e ele é um só.
	 *
	 * @return string Uma das constantes de caminho.
	 */
	public static function caminho(): string {
		$ids = self::ids();

		if ( '' !== $ids['f3base_gtm_container_id'] ) {
			return self::CAMINHO_GTM;
		}

		return self::ha_slot_preenchido() ? self::CAMINHO_DIRETO : self::CAMINHO_NENHUM;
	}

	/**
	 * O que o navegador precisa saber para emitir e para converter.
	 *
	 * Publicado também para o cliente de leads: a conversão do clique sai de um
	 * lugar só, e esse lugar precisa dos mesmos IDs que as tags usam. Duas
	 * cópias dos IDs seriam duas verdades sobre a mesma conta.
	 *
	 * @return array<string,mixed>
	 */
	public static function dados_de_medicao(): array {
		$ids      = self::ids();
		$caminho  = self::caminho();
		$tracking = F3Base_Options::ler( 'f3base_tracking' );

		/*
		 * O CAMINHO É ESTRUTURAL, e não um `if` no cliente. No caminho do
		 * container, os IDs diretos nem chegam ao navegador: disparar em dobro
		 * deixa de ser um ramo esquecido e passa a ser impossível, porque não há
		 * com o que disparar. E no caminho direto o container também não vai —
		 * pelo mesmo motivo, na direção contrária.
		 */
		$direto = self::CAMINHO_DIRETO === $caminho;

		return array(
			'caminho'    => $caminho,
			'gtm'        => self::CAMINHO_GTM === $caminho ? $ids['f3base_gtm_container_id'] : '',
			'ga4'        => $direto ? $ids['f3base_ga4_measurement_id'] : '',
			'ads'        => array(
				'id'    => $direto ? $ids['f3base_google_ads.conversion_id'] : '',
				'label' => $direto ? $ids['f3base_google_ads.conversion_label'] : '',
			),
			'meta'       => array(
				'pixelId' => $direto ? $ids['f3base_meta_pixel_id'] : '',
				'origem'  => self::ORIGEM_META,
			),
			'linkedin'   => array(
				'partnerId'    => $direto ? $ids['f3base_linkedin_partner_id'] : '',
				'conversionId' => $direto ? $ids['f3base_linkedin_conversion_id'] : '',
				'origem'       => self::ORIGEM_LINKEDIN,
			),
			'origemGoogle' => self::ORIGEM_GOOGLE,
			'eventosGa4'   => is_array( $tracking ) && ! empty( $tracking['eventos_ga4'] ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$saida = array();

		foreach ( self::ids() as $chave => $valor ) {
			$saida[] = array(
				'rotulo'   => $chave,
				'presente' => '' !== $valor,
				'detalhe'  => '' !== $valor
					? __( 'slot preenchido: entra na emissão sob consentimento.', 'f3base' )
					: __( 'vazio por configuração: o slot permanece inerte e nada é emitido por ele.', 'f3base' ),
			);
		}

		$saida[] = array(
			'rotulo'   => __( 'Módulo de consentimento', 'f3base' ),
			'presente' => class_exists( 'F3Base_Modulo_Consentimento' ),
			'detalhe'  => __( 'portão único das quatro tags, conferido no servidor e de novo no navegador.', 'f3base' ),
		);

		return $saida;
	}

	/**
	 * {@inheritDoc}
	 */
	public function avisos(): array {
		$ids    = self::ids();
		$avisos = array();

		foreach ( self::formas() as $chave => $forma ) {
			$valor = (string) ( $ids[ $chave ] ?? '' );

			if ( '' === $valor || 1 === preg_match( $forma['regex'], $valor ) ) {
				continue;
			}

			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: 1: nome da chave, 2: valor gravado, 3: forma declarada. */
					__( '%1$s está gravada como "%2$s", fora da forma %3$s. O valor foi preservado — o pacote não apaga o que alguém gravou —, e a consequência é esta: a tag carrega e a conta não recebe nada, sem erro no console e sem linha no relatório do fornecedor.', 'f3base' ),
					$chave,
					$valor,
					$forma['forma']
				),
			);
		}

		$ads_id    = (string) $ids['f3base_google_ads.conversion_id'];
		$ads_label = (string) $ids['f3base_google_ads.conversion_label'];

		if ( ( '' === $ads_id ) !== ( '' === $ads_label ) ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => __( 'a conversão do Google Ads precisa das DUAS metades do send_to: com só uma preenchida, nenhuma conversão é enviada — o disparo iria para a conta e não para a ação, e o pacote prefere não disparar a disparar no lugar errado.', 'f3base' ),
			);
		}

		return $avisos;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$caminho = self::caminho();

		if ( self::CAMINHO_NENHUM === $caminho ) {
			return $this->inativo(
				__( 'nenhum slot de medição preenchido: não há tag no HTML e nenhuma conversão sai deste site. Preencher qualquer um dos IDs faz a emissão passar a existir na página seguinte, sem passo manual.', 'f3base' )
			);
		}

		if ( ! F3Base_Modulo_Consentimento::permite_tags() ) {
			return $this->degradado(
				__( 'consentimento negado nesta requisição: nenhuma das quatro tags é carregada. Pixel e Insight Tag não têm modo de consentimento — carregar e "atualizar para negado" seria carregar assim mesmo —, e por isso a negativa vira ausência.', 'f3base' )
			);
		}

		if ( self::CAMINHO_GTM === $caminho ) {
			return $this->ativo(
				sprintf(
					/* translators: %s: container do GTM. */
					__( 'container %s emitido sozinho: o site alimenta o dataLayer com eventos em objeto e NENHUMA tag direta é emitida, para que a mesma conversão não seja contada duas vezes.', 'f3base' ),
					self::ids()['f3base_gtm_container_id']
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: quantidade de slots preenchidos. */
				_n(
					'%d slot preenchido, emitido direto a partir do ID gravado e sob consentimento vigente.',
					'%d slots preenchidos, emitidos direto a partir dos IDs gravados e sob consentimento vigente.',
					count( array_filter( self::ids(), static fn ( string $valor ): bool => '' !== $valor ) ),
					'f3base'
				),
				count( array_filter( self::ids(), static fn ( string $valor ): bool => '' !== $valor ) )
			)
		);
	}

	/**
	 * Enfileira o carregador único quando os dois portões abrem.
	 *
	 * @return void
	 */
	public function enfileirar(): void {
		if ( self::CAMINHO_NENHUM === self::caminho() ) {
			return;
		}

		if ( ! F3Base_Modulo_Consentimento::permite_tags() ) {
			return;
		}

		wp_enqueue_script(
			self::HANDLE,
			F3BASE_SITE_CORE_URL . 'assets/f3base-tracking.js',
			array( F3Base_Modulo_Consentimento::HANDLE ),
			F3BASE_SITE_CORE_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		wp_localize_script( self::HANDLE, 'f3baseTrackingDados', self::dados_de_medicao() );
	}
}
