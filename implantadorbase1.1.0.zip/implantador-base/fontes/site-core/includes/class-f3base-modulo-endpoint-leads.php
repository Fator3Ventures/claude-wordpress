<?php
/**
 * Módulo endpoint-leads.
 *
 * Rota REST pública e endurecida: schema fechado por campo com rejeição de campo
 * desconhecido, limites por campo MEDIDOS EM CARACTERES — a mesma unidade que o
 * cliente corta —, token efêmero assinado, honeypot, rate limit com incremento
 * ATÔMICO no banco e deduplicação atômica por chave única (índice UNIQUE em
 * tabela própria — o banco decide o empate, não o PHP).
 *
 * A reserva de deduplicação nasce PENDENTE, vira firme só depois da persistência
 * e é COMPENSADA quando nenhum destino aceita o lead: reserva que sobrevive à
 * falha bloqueia por 30 dias o visitante que tentou de novo.
 *
 * Grava no Flamingo quando a classe existir; senão, no CPT privado de contingência
 * `f3base_lead`, e o módulo reporta o estado com o motivo. `from` e `subject` saem
 * legíveis na gravação. O `record_id` nasce no servidor; o `correlation_id` vem do
 * navegador — nome honesto para cada um.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Endpoint de registro de leads.
 */
final class F3Base_Modulo_Endpoint_Leads extends F3Base_Modulo {

	/**
	 * Rota, dentro do namespace do plugin.
	 */
	public const ROTA = '/lead';

	/**
	 * CPT privado de contingência.
	 */
	public const CPT = 'f3base_lead';

	/**
	 * Canal usado na caixa do Flamingo.
	 */
	public const CANAL = 'f3base-whatsapp';

	/**
	 * Sufixo da tabela de chaves do endpoint.
	 *
	 * A tabela guarda DOIS tipos de linha, discriminados pela coluna `tipo`: a
	 * reserva de deduplicação e o balde do rate limit. Uma só porque as duas
	 * precisam da MESMA propriedade — o banco decide o empate — e uma migração
	 * só é uma migração a menos para sair errada.
	 */
	public const TABELA = 'f3base_leads_dedup';

	/**
	 * Tipos de linha da tabela.
	 */
	public const TIPO_DEDUP  = 'dedup';
	public const TIPO_LIMITE = 'limite';

	/**
	 * Estados fechados de uma reserva de deduplicação.
	 *
	 * `pendente` é a reserva que ainda não tem lead gravado atrás dela; `firme`
	 * é a que tem. Só a firme recusa a tentativa seguinte.
	 */
	public const RESERVA_PENDENTE = 'pendente';
	public const RESERVA_FIRME    = 'firme';

	/**
	 * Vocabulário fechado do parser de booleano.
	 *
	 * Existe porque `(bool) 'false'` é `true` em PHP, e o campo que passava por
	 * esse molde era o CONSENTIMENTO: o lead era arquivado como tendo consentido.
	 */
	public const BOOLEANO_VERDADEIRO = array( '1', 'true', 'sim', 'yes', 'on', 'y', 's', 't', 'verdade' );
	public const BOOLEANO_FALSO      = array( '', '0', 'false', 'nao', 'não', 'no', 'off', 'n', 'f' );

	/**
	 * Memo da prontidão da tabela nesta requisição.
	 *
	 * @var bool|null
	 */
	private static ?bool $tabela_pronta = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'endpoint-leads';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Endpoint de leads', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Rota REST pública endurecida que recebe o beacon do clique: schema fechado com rejeição de campo desconhecido, limites por campo, token efêmero assinado, honeypot, rate limit e deduplicação atômica por chave única. Grava no Flamingo, ou no CPT privado de contingência quando ele não estiver presente.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'registrar_cpt',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'garantir_estrutura',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_contato', 'f3base_endpoint_segredo', 'f3base_origem_confiavel' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'Flamingo (caixa única de leads)', 'f3base' ),
				'presente' => self::flamingo_presente(),
				'detalhe'  => self::flamingo_presente()
					? __( 'gravação vai para a caixa de entrada do Flamingo.', 'f3base' )
					: __( 'ausente: a gravação cai no CPT privado de contingência f3base_lead.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Tabela de chaves do endpoint (dedup e rate limit)', 'f3base' ),
				'presente' => self::tabela_pronta(),
				'detalhe'  => self::tabela_pronta()
					? __( 'chave única no banco decide o empate entre replay e duplo clique, e o incremento do rate limit é uma instrução só.', 'f3base' )
					: sprintf(
						/* translators: %s: nome da tabela. */
						__( 'ausente ou sem a coluna estado: a deduplicação e o rate limit caem para transiente, que faz ler-modificar-gravar e perde incremento sob concorrência. Reative o plugin para que %s seja migrada.', 'f3base' ),
						self::nome_tabela()
					),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_LEAD, __( 'Último registro aceito', 'f3base' ) ),
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_FALHA_LEAD, __( 'Última recusa de gravação', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$falha  = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_LEAD );
		$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

		$em_falha  = isset( $falha['em'] ) ? (int) $falha['em'] : 0;
		$em_aceito = isset( $aceito['em'] ) ? (int) $aceito['em'] : 0;

		if ( $em_falha > 0 && $em_falha > $em_aceito ) {
			return $this->degradado(
				sprintf(
					/* translators: 1: data e hora da recusa, 2: destinos que recusaram. */
					__( 'a tentativa mais recente NÃO foi gravada em %1$s (%2$s) e nenhuma entrou depois dela. A reserva de deduplicação foi liberada, então a próxima tentativa com a mesma correlação é aceita.', 'f3base' ),
					(string) wp_date( 'd/m/Y H:i', $em_falha ),
					isset( $falha['motivo'] ) && '' !== (string) $falha['motivo'] ? (string) $falha['motivo'] : __( 'motivo não registrado', 'f3base' )
				)
			);
		}

		if ( ! self::tabela_pronta() ) {
			return $this->degradado(
				sprintf(
					/* translators: %s: nome da tabela. */
					__( 'tabela %s ausente ou sem a coluna de estado da reserva: a deduplicação e o rate limit caem para transiente, e transiente faz ler-modificar-gravar — sob concorrência ele perde incremento e o balde deixa de segurar.', 'f3base' ),
					self::nome_tabela()
				)
			);
		}

		if ( ! self::flamingo_presente() ) {
			return $this->degradado(
				__( 'Flamingo ausente: gravando no CPT de contingência f3base_lead, fora da caixa única de leads do operador.', 'f3base' )
			);
		}

		$origem = self::cabecalho_confiavel();

		if ( '' === $origem['cabecalho'] ) {
			return $this->ativo(
				__( 'gravação na caixa do Flamingo, com deduplicação decidida pela chave única do banco. O rate limit conta por REMOTE_ADDR: nenhum cabeçalho de proxy está declarado em f3base_origem_confiavel, e cabeçalho aceito sem declaração é o próprio visitante escolhendo o balde em que quer contar.', 'f3base' )
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: 1: nome do cabeçalho declarado, 2: saltos de proxy confiáveis. */
				__( 'gravação na caixa do Flamingo, com deduplicação decidida pela chave única do banco. O rate limit conta pela origem lida do cabeçalho declarado %1$s, descontando %2$d salto(s) de proxy confiável; fora dessa declaração a contagem volta a REMOTE_ADDR.', 'f3base' ),
				$origem['cabecalho'],
				$origem['saltos']
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function instalar(): void {
		self::criar_tabela();
		self::segredo();
	}

	/**
	 * Migra a tabela quando o pacote foi trocado sem passar pela ativação.
	 *
	 * A atualização de um plugin nem sempre reexecuta o hook de ativação, e a
	 * coluna que a 1.0.1 do site-core acrescentou é o que separa a reserva
	 * PENDENTE da firme. Sem ela o módulo cai para o transiente — que é honesto,
	 * mas não é atômico —, então a migração acontece uma vez, no carregamento
	 * seguinte, com guarda para não repetir a cada requisição.
	 *
	 * @return void
	 */
	public function garantir_estrutura(): void {
		if ( self::tabela_pronta() ) {
			return;
		}

		if ( false === set_transient( 'f3base_leads_migrando', 1, 15 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		self::criar_tabela();
	}

	/* ------------------------------------------------------------------ *
	 * Superfície pública
	 * ------------------------------------------------------------------ */

	/**
	 * Registra o CPT privado de contingência.
	 *
	 * A interface só aparece quando o Flamingo não está presente: sem caixa
	 * única, o operador precisa enxergar o plano B; com ela, a listagem dupla é
	 * ruído.
	 *
	 * @return void
	 */
	public function registrar_cpt(): void {
		$contingencia = ! self::flamingo_presente();

		register_post_type(
			self::CPT,
			array(
				'labels'              => array(
					'name'          => __( 'Leads (contingência)', 'f3base' ),
					'singular_name' => __( 'Lead (contingência)', 'f3base' ),
					'menu_name'     => __( 'Leads (contingência)', 'f3base' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => $contingencia,
				'show_in_menu'        => $contingencia ? 'f3base-site-core' : false,
				'show_in_rest'        => false,
				'show_in_nav_menus'   => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'hierarchical'        => false,
				'can_export'          => true,
				'delete_with_user'    => false,
				'supports'            => array( 'title', 'editor', 'custom-fields' ),
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'capabilities'        => array(
					'create_posts' => 'do_not_allow',
				),
				'menu_icon'           => 'dashicons-email-alt',
			)
		);
	}

	/**
	 * Registra a rota REST.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'receber' ),
				'permission_callback' => '__return_true',
				'args'                => array(),
			)
		);
	}

	/**
	 * Recebe o beacon do clique.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function receber( WP_REST_Request $requisicao ): WP_REST_Response {
		$bruto = $requisicao->get_json_params();
		if ( ! is_array( $bruto ) ) {
			$bruto = $requisicao->get_body_params();
		}
		if ( ! is_array( $bruto ) ) {
			$bruto = array();
		}

		$campos = self::campos();

		// Schema fechado: campo desconhecido é recusado pelo nome, nunca ignorado.
		foreach ( array_keys( $bruto ) as $chave ) {
			if ( ! isset( $campos[ (string) $chave ] ) ) {
				return self::resposta(
					400,
					array(
						'ok'     => false,
						'codigo' => 'f3base_campo_desconhecido',
						'campo'  => sanitize_key( (string) $chave ),
						'motivo' => __( 'Campo fora do schema fechado do endpoint.', 'f3base' ),
					)
				);
			}
		}

		// Honeypot: preenchido significa automação. Nada é gravado.
		$honeypot = isset( $bruto['website'] ) ? trim( (string) $bruto['website'] ) : '';
		if ( '' !== $honeypot ) {
			return self::resposta(
				200,
				array(
					'ok'         => true,
					'registrado' => false,
					'motivo'     => 'honeypot',
				)
			);
		}

		if ( ! self::validar_token( isset( $bruto['token'] ) ? (string) $bruto['token'] : '' ) ) {
			return self::resposta(
				403,
				array(
					'ok'     => false,
					'codigo' => 'f3base_token_invalido',
					'motivo' => __( 'Token efêmero ausente, expirado ou com assinatura inválida.', 'f3base' ),
				)
			);
		}

		if ( ! self::dentro_do_rate_limit() ) {
			return self::resposta(
				429,
				array(
					'ok'     => false,
					'codigo' => 'f3base_rate_limit',
					'motivo' => __( 'Limite de registros por janela excedido para esta origem.', 'f3base' ),
				)
			);
		}

		$validado = self::validar_campos( $bruto, $campos );
		if ( isset( $validado['erro'] ) ) {
			return self::resposta( 400, $validado['erro'] );
		}

		$dados = $validado['dados'];

		$record_id = self::gerar_record_id();
		$reserva   = self::reservar( (string) $dados['correlation_id'], $record_id );

		if ( ! $reserva['novo'] ) {
			return self::resposta(
				200,
				array(
					'ok'         => true,
					'registrado' => false,
					'duplicado'  => true,
					'record_id'  => $reserva['record_id'],
					'motivo'     => __( 'Correlação já registrada: replay ou duplo clique.', 'f3base' ),
				)
			);
		}

		$gravacao = self::gravar_lead( $dados, $record_id );

		/*
		 * NADA É REGISTRADO ANTES DA PERSISTÊNCIA. A atividade que carimba
		 * "último registro aceito" com o destino da gravação que falhou faz a
		 * tela do site-core apontar para onde nada foi escrito — e 201 Created
		 * com `ok:false` diz ao cliente que o recurso existe quando ele não
		 * existe. Os dois ramos saem separados, e o adverso compensa a reserva.
		 */
		if ( ! $gravacao['ok'] ) {
			self::liberar_reserva( (string) $dados['correlation_id'] );

			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_FALHA_LEAD,
				array(
					'record_id'  => $record_id,
					'destino'    => $gravacao['destino'],
					'formulario' => (string) $dados['formulario'],
					'motivo'     => (string) $gravacao['motivo'],
				)
			);

			return self::resposta(
				503,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_gravacao_indisponivel',
					'record_id'  => $record_id,
					'destino'    => $gravacao['destino'],
					'motivo'     => __( 'Nenhum destino aceitou o registro: nada foi gravado. A reserva de deduplicação foi liberada, então basta reenviar — a próxima tentativa com a mesma correlação é aceita. A conversa no WhatsApp continua valendo como fonte da verdade do lead.', 'f3base' ),
				)
			);
		}

		self::confirmar_reserva( (string) $dados['correlation_id'], $record_id );

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMO_LEAD,
			array(
				'record_id'  => $record_id,
				'destino'    => $gravacao['destino'],
				'formulario' => (string) $dados['formulario'],
			)
		);

		return self::resposta(
			201,
			array(
				'ok'         => true,
				'registrado' => true,
				'record_id'  => $record_id,
				'destino'    => $gravacao['destino'],
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Schema fechado
	 * ------------------------------------------------------------------ */

	/**
	 * Schema fechado do endpoint: um campo, um tipo, um limite.
	 *
	 * @return array<string,array{tipo:string,max:int,obrigatorio?:bool,regex?:string}>
	 */
	public static function campos(): array {
		return array(
			'token'          => array(
				'tipo'        => 'token',
				'max'         => 200,
				'obrigatorio' => true,
			),
			'correlation_id' => array(
				'tipo'        => 'identificador',
				'max'         => 64,
				'obrigatorio' => true,
				'regex'       => '/^[A-Za-z0-9_-]{8,64}$/',
			),
			'formulario'     => array(
				'tipo' => 'slug',
				'max'  => 64,
			),
			'nome'           => array(
				'tipo' => 'texto',
				'max'  => 120,
			),
			'email'          => array(
				'tipo' => 'email',
				'max'  => 190,
			),
			'telefone'       => array(
				'tipo' => 'telefone',
				'max'  => 40,
			),
			'mensagem'       => array(
				'tipo' => 'texto_longo',
				'max'  => 2000,
			),
			'pagina'         => array(
				'tipo' => 'url_interna',
				'max'  => 500,
			),
			'consentimento'  => array(
				'tipo' => 'booleano',
				'max'  => 8,
			),
			'atribuicao'     => array(
				'tipo' => 'atribuicao',
				'max'  => 8,
			),
			'website'        => array(
				'tipo' => 'honeypot',
				'max'  => 0,
			),
		);
	}

	/**
	 * Limites por campo publicados para o navegador.
	 *
	 * @return array<string,int>
	 */
	public static function limites_publicos(): array {
		$limites = array();

		foreach ( self::campos() as $nome => $definicao ) {
			if ( in_array( $definicao['tipo'], array( 'token', 'honeypot' ), true ) ) {
				continue;
			}
			$limites[ $nome ] = (int) $definicao['max'];
		}

		return $limites;
	}

	/**
	 * Sub-chaves aceitas em `atribuicao`. Fechado como o resto.
	 *
	 * OS IDENTIFICADORES DE CLIQUE ENTRARAM NA 1.1.0, e o motivo é medido: o
	 * schema é fechado e recusa campo desconhecido com 400 nomeando a chave —
	 * acrescentar `gclid` só no cliente faria TODO lead de tráfego pago voltar
	 * recusado, que é o pior modo de falhar que este endpoint tem. Os dois lados
	 * mudam juntos, e é por isso que esta lista está aqui e não em dois lugares.
	 *
	 * Quem é cada um: `gclid`, `gbraid` e `wbraid` vêm do Google Ads (o segundo
	 * e o terceiro são os identificadores de app e de web sem cookie);
	 * `msclkid` é o do Microsoft Advertising, que chega pelo mesmo caminho;
	 * `fbclid` vem do Meta Ads e `fbc`/`fbp` são os cookies que a Meta espera
	 * receber de volta na Conversions API; `li_fat_id` é o do LinkedIn Ads.
	 *
	 * @return array<string,int> Chave para limite de caracteres.
	 */
	public static function campos_atribuicao(): array {
		return array(
			'fonte'             => 120,
			'meio'              => 120,
			'campanha'          => 160,
			'termo'             => 160,
			'conteudo'          => 160,
			'referrer'          => 500,
			'primeiro_toque_em' => 20,
			'modelo'            => 40,
			'gclid'             => 200,
			'gbraid'            => 200,
			'wbraid'            => 200,
			'msclkid'           => 200,
			'fbclid'            => 400,
			'fbc'               => 200,
			'fbp'               => 120,
			'li_fat_id'         => 120,
		);
	}

	/**
	 * Valida e normaliza os campos do payload.
	 *
	 * @param array<string,mixed>                         $bruto  Payload cru.
	 * @param array<string,array<string,mixed>>           $campos Schema fechado.
	 * @return array{dados?:array<string,mixed>,erro?:array<string,mixed>}
	 */
	private static function validar_campos( array $bruto, array $campos ): array {
		$dados = array(
			'correlation_id' => '',
			'formulario'     => '',
			'nome'           => '',
			'email'          => '',
			'telefone'       => '',
			'mensagem'       => '',
			'pagina'         => '',
			'consentimento'  => false,
			'atribuicao'     => array(),
		);

		foreach ( $campos as $nome => $definicao ) {
			if ( in_array( $definicao['tipo'], array( 'token', 'honeypot' ), true ) ) {
				continue;
			}

			$presente = array_key_exists( $nome, $bruto );
			$valor    = $presente ? $bruto[ $nome ] : null;

			if ( ! empty( $definicao['obrigatorio'] ) && ( ! $presente || '' === $valor || null === $valor ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_campo_obrigatorio',
						'campo'  => $nome,
						'motivo' => __( 'Campo obrigatório ausente no payload.', 'f3base' ),
					),
				);
			}

			if ( ! $presente ) {
				continue;
			}

			if ( 'atribuicao' === $definicao['tipo'] ) {
				$atribuicao = self::validar_atribuicao( $valor );
				if ( isset( $atribuicao['erro'] ) ) {
					return array( 'erro' => $atribuicao['erro'] );
				}
				$dados['atribuicao'] = $atribuicao['dados'];
				continue;
			}

			/*
			 * A GUARDA DE ESTRUTURA E A DE LIMITE VÊM ANTES DO DESPACHO POR TIPO.
			 * Enquanto o booleano tinha ramo próprio com `continue`, ele pulava
			 * as duas: `{"consentimento":{}}` virava `true` e o `max` de 8 do
			 * schema era letra morta. Guarda que só vale para alguns tipos é
			 * guarda que o tipo seguinte descobre que não existe.
			 */
			if ( is_array( $valor ) || is_object( $valor ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_tipo_invalido',
						'campo'  => $nome,
						'motivo' => __( 'Campo escalar recebeu estrutura.', 'f3base' ),
					),
				);
			}

			$texto = self::escalar_para_texto( $valor );

			/*
			 * O limite é medido em CARACTERES, que é a unidade que o cliente
			 * corta (`f3base-leads.js`) e a unidade que `limites_publicos()`
			 * publica para ele. Medido em bytes, "José de Sá" ocupava mais do
			 * que o navegador contou e o servidor recusava com 400 o lead que a
			 * própria página tinha aprovado — em português, sempre.
			 */
			if ( self::comprimento( $texto ) > (int) $definicao['max'] ) {
				return array(
					'erro' => array(
						'ok'      => false,
						'codigo'  => 'f3base_limite_excedido',
						'campo'   => $nome,
						'limite'  => (int) $definicao['max'],
						'unidade' => 'caracteres',
						'motivo'  => __( 'Campo excedeu o limite declarado, medido em caracteres: recusado, nunca truncado em silêncio.', 'f3base' ),
					),
				);
			}

			if ( isset( $definicao['regex'] ) && '' !== $texto && ! preg_match( (string) $definicao['regex'], $texto ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_formato_invalido',
						'campo'  => $nome,
						'motivo' => __( 'Campo não casa com o formato declarado.', 'f3base' ),
					),
				);
			}

			if ( 'booleano' === $definicao['tipo'] ) {
				$booleano = self::interpretar_booleano( $texto );

				if ( null === $booleano ) {
					return array(
						'erro' => array(
							'ok'       => false,
							'codigo'   => 'f3base_valor_invalido',
							'campo'    => $nome,
							'aceitos'  => array_merge( self::BOOLEANO_VERDADEIRO, self::BOOLEANO_FALSO ),
							'motivo'   => __( 'Campo booleano recebeu valor fora do vocabulário declarado. Em formulário urlencoded todo valor chega string, e converter string em booleano por molde da linguagem faz "false" valer true — no campo de consentimento isso arquiva como consentido quem não consentiu.', 'f3base' ),
						),
					);
				}

				$dados[ $nome ] = $booleano;
				continue;
			}

			$conclusao = self::inconclusivo( $definicao['tipo'], $texto );

			if ( '' !== $conclusao ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_formato_invalido',
						'campo'  => $nome,
						'motivo' => $conclusao,
					),
				);
			}

			$dados[ $nome ] = self::normalizar( $definicao['tipo'], $texto );
		}

		return array( 'dados' => $dados );
	}

	/**
	 * Texto de um valor escalar, sem o molde surpreendente da linguagem.
	 *
	 * `(string) false` é a string vazia e `(string) true` é "1": os dois entram
	 * no vocabulário fechado do parser de booleano pelo lado certo, e nenhum
	 * outro tipo escalar muda de forma no caminho.
	 *
	 * @param mixed $valor Valor recebido.
	 * @return string
	 */
	private static function escalar_para_texto( $valor ): string {
		if ( is_bool( $valor ) ) {
			return $valor ? '1' : '0';
		}

		if ( null === $valor ) {
			return '';
		}

		return (string) $valor;
	}

	/**
	 * Comprimento em CARACTERES — a unidade publicada em `limites_publicos()`.
	 *
	 * @param string $texto Texto medido.
	 * @return int
	 */
	public static function comprimento( string $texto ): int {
		if ( function_exists( 'mb_strlen' ) ) {
			return (int) mb_strlen( $texto, 'UTF-8' );
		}

		$contagem = preg_match_all( '/./us', $texto );

		return is_int( $contagem ) ? $contagem : strlen( $texto );
	}

	/**
	 * Parser explícito de booleano, com vocabulário fechado.
	 *
	 * Devolve `null` quando o valor não pertence a nenhum dos dois vocabulários:
	 * o schema deste endpoint é fechado, e valor de consentimento que ninguém
	 * sabe ler é recusado, nunca adivinhado.
	 *
	 * @param string $texto Valor já reduzido a texto.
	 * @return bool|null
	 */
	public static function interpretar_booleano( string $texto ): ?bool {
		$normal = trim( $texto );
		$normal = function_exists( 'mb_strtolower' ) ? mb_strtolower( $normal, 'UTF-8' ) : strtolower( $normal );

		if ( in_array( $normal, self::BOOLEANO_VERDADEIRO, true ) ) {
			return true;
		}

		if ( in_array( $normal, self::BOOLEANO_FALSO, true ) ) {
			return false;
		}

		return null;
	}

	/**
	 * Motivo pelo qual um valor NÃO é conclusivo para o tipo declarado.
	 *
	 * Devolve string vazia quando o valor passa. Existe porque `sanitize_email()`
	 * devolve string vazia para entrada inválida: sem conferir o retorno, o lead
	 * era aceito com e-mail vazio respondendo 201 e ninguém tinha como responder
	 * ao visitante.
	 *
	 * @param string $tipo  Tipo declarado no schema fechado.
	 * @param string $texto Valor recebido.
	 * @return string
	 */
	public static function inconclusivo( string $tipo, string $texto ): string {
		if ( 'email' !== $tipo || '' === trim( $texto ) ) {
			return '';
		}

		$limpo = sanitize_email( $texto );

		if ( '' === $limpo || false === is_email( $limpo ) ) {
			return __( 'E-mail inválido: a sanitização devolveria string vazia e o lead entraria sem endereço nenhum, com resposta de sucesso.', 'f3base' );
		}

		return '';
	}

	/**
	 * Valida o sub-objeto de atribuição, também fechado por chave.
	 *
	 * @param mixed $valor Valor bruto.
	 * @return array{dados?:array<string,string>,erro?:array<string,mixed>}
	 */
	private static function validar_atribuicao( $valor ): array {
		if ( null === $valor || '' === $valor ) {
			return array( 'dados' => array() );
		}

		if ( ! is_array( $valor ) ) {
			return array(
				'erro' => array(
					'ok'     => false,
					'codigo' => 'f3base_tipo_invalido',
					'campo'  => 'atribuicao',
					'motivo' => __( 'Atribuição precisa ser um objeto de chaves declaradas.', 'f3base' ),
				),
			);
		}

		$aceitos = self::campos_atribuicao();
		$saida   = array();

		foreach ( $valor as $chave => $item ) {
			$chave = (string) $chave;

			if ( ! isset( $aceitos[ $chave ] ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_campo_desconhecido',
						'campo'  => 'atribuicao.' . sanitize_key( $chave ),
						'motivo' => __( 'Chave de atribuição fora do schema fechado.', 'f3base' ),
					),
				);
			}

			if ( is_array( $item ) || is_object( $item ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_tipo_invalido',
						'campo'  => 'atribuicao.' . $chave,
						'motivo' => __( 'Chave de atribuição escalar recebeu estrutura.', 'f3base' ),
					),
				);
			}

			$texto = self::escalar_para_texto( $item );

			if ( self::comprimento( $texto ) > $aceitos[ $chave ] ) {
				return array(
					'erro' => array(
						'ok'      => false,
						'codigo'  => 'f3base_limite_excedido',
						'campo'   => 'atribuicao.' . $chave,
						'limite'  => $aceitos[ $chave ],
						'unidade' => 'caracteres',
						'motivo'  => __( 'Chave de atribuição excedeu o limite declarado, medido em caracteres.', 'f3base' ),
					),
				);
			}

			$saida[ $chave ] = 'referrer' === $chave ? esc_url_raw( $texto ) : sanitize_text_field( $texto );
		}

		return array( 'dados' => $saida );
	}

	/**
	 * Normaliza um valor conforme o tipo declarado.
	 *
	 * @param string $tipo  Tipo do campo.
	 * @param string $texto Valor cru.
	 * @return string
	 */
	private static function normalizar( string $tipo, string $texto ): string {
		switch ( $tipo ) {
			case 'email':
				return sanitize_email( $texto );
			case 'slug':
				return sanitize_key( $texto );
			case 'identificador':
				return $texto;
			case 'telefone':
				$limpo = preg_replace( '/[^0-9+()\s-]/', '', $texto );
				return is_string( $limpo ) ? trim( $limpo ) : '';
			case 'texto_longo':
				return sanitize_textarea_field( $texto );
			case 'url_interna':
				return self::caminho_interno( $texto );
			default:
				return sanitize_text_field( $texto );
		}
	}

	/**
	 * Reduz uma URL recebida ao caminho do próprio site.
	 *
	 * @param string $url URL bruta.
	 * @return string Caminho do próprio site, ou vazio.
	 */
	private static function caminho_interno( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}

		$partes = wp_parse_url( $url );
		if ( ! is_array( $partes ) ) {
			return '';
		}

		if ( isset( $partes['host'] ) ) {
			$casa = wp_parse_url( home_url( '/' ) );
			$alvo = strtolower( (string) $partes['host'] );
			$meu  = is_array( $casa ) && isset( $casa['host'] ) ? strtolower( (string) $casa['host'] ) : '';

			if ( '' === $meu || $alvo !== $meu ) {
				return '';
			}
		}

		$caminho = isset( $partes['path'] ) ? (string) $partes['path'] : '/';
		if ( isset( $partes['query'] ) && '' !== $partes['query'] ) {
			$caminho .= '?' . (string) $partes['query'];
		}

		/*
		 * SEM CORTE PRÓPRIO AQUI. O limite do campo `pagina` é o do schema
		 * fechado, medido em caracteres antes desta função, e a sanitização só
		 * encurta — um segundo corte, em outra unidade, seria uma segunda fonte
		 * para o mesmo fato, e o corte por byte era exatamente o defeito que a
		 * 1.0.18 tirou do outro lado.
		 */
		return sanitize_text_field( $caminho );
	}

	/* ------------------------------------------------------------------ *
	 * Token efêmero assinado
	 * ------------------------------------------------------------------ */

	/**
	 * TTL do token efêmero, em segundos.
	 *
	 * @return int
	 */
	public static function ttl_token(): int {
		$ttl = (int) apply_filters( 'f3base_token_lead_ttl', 12 * HOUR_IN_SECONDS );

		return max( 300, min( 7 * DAY_IN_SECONDS, $ttl ) );
	}

	/**
	 * Emite um token efêmero assinado, carimbado com a expiração.
	 *
	 * @return string
	 */
	public static function emitir_token(): string {
		$expira = time() + self::ttl_token();

		return $expira . '.' . self::assinar( (string) $expira );
	}

	/**
	 * Valida um token efêmero.
	 *
	 * @param string $token Token recebido.
	 * @return bool
	 */
	public static function validar_token( string $token ): bool {
		if ( '' === $token || ! str_contains( $token, '.' ) ) {
			return false;
		}

		$partes = explode( '.', $token, 2 );
		$expira = $partes[0];
		$assina = $partes[1];

		if ( ! ctype_digit( $expira ) ) {
			return false;
		}

		$agora = time();
		$fim   = (int) $expira;

		if ( $fim < $agora ) {
			return false;
		}

		if ( $fim > $agora + self::ttl_token() + MINUTE_IN_SECONDS ) {
			return false;
		}

		return hash_equals( self::assinar( $expira ), $assina );
	}

	/**
	 * Assina um payload com o segredo do endpoint.
	 *
	 * @param string $payload Conteúdo assinado.
	 * @return string
	 */
	private static function assinar( string $payload ): string {
		return hash_hmac( 'sha256', $payload, self::segredo() );
	}

	/**
	 * Segredo HMAC do endpoint, gerado uma vez.
	 *
	 * @return string
	 */
	private static function segredo(): string {
		$segredo = F3Base_Options::ler( 'f3base_endpoint_segredo' );
		$segredo = is_string( $segredo ) ? $segredo : '';

		if ( 32 > strlen( $segredo ) ) {
			$segredo   = bin2hex( random_bytes( 32 ) );
			$resultado = F3Base_Options::gravar( 'f3base_endpoint_segredo', $segredo, F3Base_Options::ORIGEM_PADRAO );
			$segredo   = is_string( $resultado['lido'] ) ? $resultado['lido'] : $segredo;
		}

		return $segredo . wp_salt( 'auth' );
	}

	/* ------------------------------------------------------------------ *
	 * Rate limit
	 * ------------------------------------------------------------------ */

	/**
	 * A origem está dentro do limite da janela?
	 *
	 * @return bool
	 */
	private static function dentro_do_rate_limit(): bool {
		$janela = max( 60, (int) apply_filters( 'f3base_lead_rate_limit_janela', 10 * MINUTE_IN_SECONDS ) );
		$limite = max( 1, (int) apply_filters( 'f3base_lead_rate_limit_maximo', 20 ) );

		$origem = self::origem();
		$chave  = hash( 'sha256', 'limite|' . $origem['valor'] . '|' . wp_salt( 'nonce' ) );

		return self::incrementar_janela( $chave, $janela ) <= $limite;
	}

	/**
	 * Incrementa o balde da janela e devolve a contagem DEPOIS do incremento.
	 *
	 * Uma instrução só, e é o banco que soma: `INSERT ... ON DUPLICATE KEY
	 * UPDATE` com `LAST_INSERT_ID()` devolve o valor pós-incremento da própria
	 * sessão, então N requisições concorrentes recebem N valores distintos. O
	 * caminho anterior lia com `get_transient()` e gravava com `set_transient()`
	 * sem lock: N requisições concorrentes liam o MESMO valor e gravavam o mesmo
	 * valor mais um, e o balde de 20 deixava passar quantas coubessem na janela.
	 *
	 * A linha do balde entra com estado VAZIO: ela não é uma reserva, e dar a
	 * ela o estado de uma reserva faria a poda e qualquer contagem por estado
	 * misturarem balde com lead.
	 *
	 * @param string $chave  Chave já derivada da origem.
	 * @param int    $janela Janela em segundos.
	 * @return int Contagem depois deste incremento.
	 */
	public static function incrementar_janela( string $chave, int $janela ): int {
		if ( ! self::tabela_pronta() ) {
			return self::incrementar_por_transiente( $chave, $janela );
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$agora  = time();
		$fim    = $agora + $janela;

		$anterior = $wpdb->suppress_errors( true );

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$tabela} (chave, tipo, estado, record_id, contador, expira_em, criado_em) VALUES (%s, %s, %s, %s, 1, %d, %d) ON DUPLICATE KEY UPDATE contador = LAST_INSERT_ID( IF( expira_em < %d, 1, contador + 1 ) ), expira_em = IF( expira_em < %d, %d, expira_em )", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				self::TIPO_LIMITE,
				'',
				'',
				$fim,
				$agora,
				$agora,
				$agora,
				$fim
			)
		);

		$wpdb->suppress_errors( $anterior );

		if ( false === $linhas ) {
			return self::incrementar_por_transiente( $chave, $janela );
		}

		if ( 1 === (int) $linhas ) {
			return 1;
		}

		$contagem = (int) $wpdb->insert_id;

		if ( $contagem > 0 ) {
			return $contagem;
		}

		/*
		 * O incremento JÁ ACONTECEU — ele é a instrução acima. Se o driver não
		 * devolveu o valor de LAST_INSERT_ID(), a leitura seguinte é só para
		 * saber quanto ficou; devolver 1 aqui seria um balde que nunca fecha,
		 * e um limite que nunca fecha é pior que limite nenhum, porque parece
		 * que existe.
		 */
		$lido = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT contador FROM {$tabela} WHERE chave = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave
			)
		);

		return is_numeric( $lido ) ? max( 1, (int) $lido ) : PHP_INT_MAX;
	}

	/**
	 * Contingência declarada do balde: ler, somar e gravar, sem atomicidade.
	 *
	 * Só existe quando a tabela não está pronta, e o módulo reporta esse estado
	 * como DEGRADADO com o motivo — porque é exatamente aqui que o incremento se
	 * perde sob concorrência.
	 *
	 * @param string $chave  Chave já derivada da origem.
	 * @param int    $janela Janela em segundos.
	 * @return int Contagem depois deste incremento.
	 */
	public static function incrementar_por_transiente( string $chave, int $janela ): int {
		$transiente = 'f3base_rl_' . substr( $chave, 0, 32 );
		$atual      = get_transient( $transiente );
		$atual      = is_numeric( $atual ) ? (int) $atual : 0;

		set_transient( $transiente, $atual + 1, $janela );

		return $atual + 1;
	}

	/**
	 * Cabeçalho de proxy em que este site confia, e quantos saltos ele tem.
	 *
	 * Vazio por padrão: cabeçalho de proxy é declaração do CLIENTE, e aceitar um
	 * sem declaração é deixar o visitante escolher em que balde ele conta —
	 * spoofing de limite. Declarado, ele é lido descontando os saltos confiáveis
	 * da direita, que é o único ponto da cadeia que o proxy da frente escreveu.
	 *
	 * @return array{cabecalho:string,saltos:int}
	 */
	public static function cabecalho_confiavel(): array {
		$valor = F3Base_Options::ler( 'f3base_origem_confiavel' );
		$valor = is_array( $valor ) ? $valor : array();

		return array(
			'cabecalho' => isset( $valor['cabecalho'] ) ? trim( (string) $valor['cabecalho'] ) : '',
			'saltos'    => isset( $valor['saltos'] ) ? max( 1, (int) $valor['saltos'] ) : 1,
		);
	}

	/**
	 * Nome de variável de servidor a partir do nome do cabeçalho declarado.
	 *
	 * @param string $cabecalho Nome do cabeçalho, com ou sem o prefixo HTTP_.
	 * @return string Vazio quando o nome declarado não sobra nada depois da limpeza.
	 */
	public static function chave_de_servidor( string $cabecalho ): string {
		$nome = strtoupper( str_replace( '-', '_', trim( $cabecalho ) ) );
		$nome = preg_replace( '/[^A-Z0-9_]/', '', $nome );
		$nome = is_string( $nome ) ? $nome : '';

		if ( '' === $nome ) {
			return '';
		}

		return str_starts_with( $nome, 'HTTP_' ) ? $nome : 'HTTP_' . $nome;
	}

	/**
	 * Origem da requisição, com a fonte NOMEADA.
	 *
	 * @param array<string,mixed>|null $servidor Superglobal a ler; nulo usa `$_SERVER`.
	 * @return array{valor:string,fonte:string,cabecalho:string}
	 */
	public static function origem( ?array $servidor = null ): array {
		if ( null === $servidor ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$servidor = $_SERVER;
		}

		$remoto = isset( $servidor['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $servidor['REMOTE_ADDR'] ) ) : '';
		$remoto = '' !== $remoto ? $remoto : 'desconhecida';

		$declarado = self::cabecalho_confiavel();
		$chave     = self::chave_de_servidor( $declarado['cabecalho'] );

		if ( '' === $chave ) {
			return array(
				'valor'     => $remoto,
				'fonte'     => 'remote_addr',
				'cabecalho' => '',
			);
		}

		$bruto = isset( $servidor[ $chave ] ) ? sanitize_text_field( wp_unslash( (string) $servidor[ $chave ] ) ) : '';
		$lista = array_values(
			array_filter(
				array_map( 'trim', explode( ',', $bruto ) ),
				static fn ( string $item ): bool => '' !== $item
			)
		);

		$indice = count( $lista ) - $declarado['saltos'];

		if ( $indice < 0 || ! isset( $lista[ $indice ] ) || false === filter_var( $lista[ $indice ], FILTER_VALIDATE_IP ) ) {
			return array(
				'valor'     => $remoto,
				'fonte'     => 'remote_addr',
				'cabecalho' => $declarado['cabecalho'],
			);
		}

		return array(
			'valor'     => $lista[ $indice ],
			'fonte'     => 'cabecalho-declarado',
			'cabecalho' => $declarado['cabecalho'],
		);
	}

	/* ------------------------------------------------------------------ *
	 * Deduplicação atômica
	 * ------------------------------------------------------------------ */

	/**
	 * Nome completo da tabela de deduplicação.
	 *
	 * @return string
	 */
	public static function nome_tabela(): string {
		global $wpdb;

		return $wpdb->prefix . self::TABELA;
	}

	/**
	 * A tabela está PRONTA — existe e traz as colunas que esta versão usa?
	 *
	 * Existir não basta: a 1.0.1 do site-core acrescentou a coluna que separa a
	 * reserva pendente da firme e as colunas do balde do rate limit. Tabela
	 * antiga responde ao `SHOW TABLES` e faz o `INSERT` desta versão falhar em
	 * silêncio, então a pergunta certa é a das colunas.
	 *
	 * @return bool
	 */
	public static function tabela_pronta(): bool {
		if ( null !== self::$tabela_pronta ) {
			return self::$tabela_pronta;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$achado = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabela ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( $achado !== $tabela ) {
			self::$tabela_pronta = false;

			return self::$tabela_pronta;
		}

		$colunas = $wpdb->get_col( "SHOW COLUMNS FROM {$tabela}" ); // phpcs:ignore WordPress.DB
		$colunas = is_array( $colunas ) ? array_map( 'strval', $colunas ) : array();

		$faltando = array_diff( array( 'chave', 'tipo', 'estado', 'record_id', 'contador', 'expira_em', 'criado_em' ), $colunas );

		self::$tabela_pronta = array() === $faltando;

		return self::$tabela_pronta;
	}

	/**
	 * Cria — ou migra — a tabela de chaves do endpoint.
	 *
	 * @return void
	 */
	public static function criar_tabela(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tabela  = self::nome_tabela();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$tabela} (
	chave char(64) NOT NULL,
	tipo varchar(12) NOT NULL DEFAULT 'dedup',
	estado varchar(10) NOT NULL DEFAULT 'pendente',
	record_id char(32) NOT NULL DEFAULT '',
	contador int(10) unsigned NOT NULL DEFAULT 0,
	expira_em bigint(20) unsigned NOT NULL DEFAULT 0,
	criado_em bigint(20) unsigned NOT NULL,
	PRIMARY KEY  (chave),
	KEY criado_em (criado_em),
	KEY tipo_expira (tipo,expira_em)
) {$collate};";

		dbDelta( $sql );

		self::$tabela_pronta = null;
	}

	/**
	 * Reserva a correlação. A chave única do banco decide o empate.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @param string $record_id      Identificador nascido no servidor.
	 * @return array{novo:bool,record_id:string}
	 */
	public static function reservar( string $correlation_id, string $record_id ): array {
		$chave = self::chave_de_dedup( $correlation_id );

		if ( ! self::tabela_pronta() ) {
			return self::reservar_por_transiente( $chave, $record_id );
		}

		global $wpdb;

		$tabela   = self::nome_tabela();
		$agora    = time();
		$anterior = $wpdb->suppress_errors( true );

		$inserido = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$tabela} (chave, tipo, estado, record_id, contador, expira_em, criado_em) VALUES (%s, %s, %s, %s, 0, %d, %d)", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				self::TIPO_DEDUP,
				self::RESERVA_PENDENTE,
				$record_id,
				$agora + self::ttl_dedup(),
				$agora
			)
		);

		$wpdb->suppress_errors( $anterior );

		if ( 1 === (int) $inserido ) {
			self::podar_dedup();

			return array(
				'novo'      => true,
				'record_id' => $record_id,
				'meio'      => 'tabela',
			);
		}

		$linha = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT record_id, estado, criado_em FROM {$tabela} WHERE chave = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave
			),
			ARRAY_A
		);

		$existente = is_array( $linha ) ? (string) $linha['record_id'] : '';
		$estado    = is_array( $linha ) ? (string) $linha['estado'] : self::RESERVA_FIRME;
		$nascida   = is_array( $linha ) ? (int) $linha['criado_em'] : 0;

		/*
		 * RESERVA PENDENTE ABANDONADA É RETOMADA, e a retomada é do banco: o
		 * `UPDATE` casa o carimbo que acabou de ser lido, então dois pedidos
		 * concorrentes disputando a mesma reserva morta produzem uma retomada só.
		 * Sem isto, uma requisição interrompida entre a reserva e a gravação
		 * deixaria a correlação bloqueada até o fim do TTL.
		 */
		if ( self::RESERVA_PENDENTE === $estado && $nascida < $agora - self::ttl_reserva_pendente() ) {
			$retomada = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"UPDATE {$tabela} SET record_id = %s, criado_em = %d, expira_em = %d WHERE chave = %s AND estado = %s AND criado_em = %d", // phpcs:ignore WordPress.DB.PreparedSQL
					$record_id,
					$agora,
					$agora + self::ttl_dedup(),
					$chave,
					self::RESERVA_PENDENTE,
					$nascida
				)
			);

			if ( 1 === (int) $retomada ) {
				return array(
					'novo'      => true,
					'record_id' => $record_id,
					'meio'      => 'tabela-retomada',
				);
			}
		}

		return array(
			'novo'      => false,
			'record_id' => $existente,
			'meio'      => 'tabela',
		);
	}

	/**
	 * Chave da reserva de deduplicação.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @return string
	 */
	public static function chave_de_dedup( string $correlation_id ): string {
		return hash( 'sha256', $correlation_id );
	}

	/**
	 * Confirma a reserva DEPOIS que o lead está gravado.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @param string $record_id      Identificador nascido no servidor.
	 * @return void
	 */
	public static function confirmar_reserva( string $correlation_id, string $record_id ): void {
		$chave = self::chave_de_dedup( $correlation_id );

		if ( ! self::tabela_pronta() ) {
			set_transient( self::transiente_de_dedup( $chave ), self::RESERVA_FIRME . '|' . $record_id, self::ttl_dedup() );

			return;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"UPDATE {$tabela} SET estado = %s WHERE chave = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				self::RESERVA_FIRME,
				$chave
			)
		);
	}

	/**
	 * Compensa a reserva quando NADA foi gravado.
	 *
	 * Só a reserva PENDENTE é apagada: uma firme guarda um lead que existe, e
	 * apagá-la traria o duplicado de volta.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @return void
	 */
	public static function liberar_reserva( string $correlation_id ): void {
		$chave = self::chave_de_dedup( $correlation_id );

		if ( ! self::tabela_pronta() ) {
			delete_transient( self::transiente_de_dedup( $chave ) );

			return;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE chave = %s AND estado = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				self::RESERVA_PENDENTE
			)
		);
	}

	/**
	 * Nome do transiente da reserva de contingência.
	 *
	 * @param string $chave Chave derivada da correlação.
	 * @return string
	 */
	private static function transiente_de_dedup( string $chave ): string {
		return 'f3base_dedup_' . substr( $chave, 0, 40 );
	}

	/**
	 * Reserva de contingência quando a tabela não existe.
	 *
	 * Declarado como não atômico: é o motivo que o módulo reporta.
	 *
	 * @param string $chave     Chave derivada da correlação.
	 * @param string $record_id Identificador do servidor.
	 * @return array{novo:bool,record_id:string}
	 */
	private static function reservar_por_transiente( string $chave, string $record_id ): array {
		$transiente = self::transiente_de_dedup( $chave );
		$existente  = get_transient( $transiente );

		if ( is_string( $existente ) && '' !== $existente ) {
			$partes = explode( '|', $existente, 2 );
			$estado = (string) $partes[0];
			$antigo = isset( $partes[1] ) ? (string) $partes[1] : $existente;

			/*
			 * Marca gravada por uma versão anterior não trazia estado: ela
			 * significava "já registrado", e é assim que continua sendo lida.
			 */
			if ( self::RESERVA_PENDENTE !== $estado && self::RESERVA_FIRME !== $estado ) {
				$antigo = $existente;
			}

			return array(
				'novo'      => false,
				'record_id' => $antigo,
				'meio'      => 'transiente',
			);
		}

		/*
		 * A reserva de contingência nasce PENDENTE e com TTL curto: se a
		 * requisição morrer entre a reserva e a gravação, ela some sozinha em
		 * minutos, em vez de bloquear a correlação pelo TTL de deduplicação.
		 */
		set_transient( $transiente, self::RESERVA_PENDENTE . '|' . $record_id, self::ttl_reserva_pendente() );

		return array(
			'novo'      => true,
			'record_id' => $record_id,
			'meio'      => 'transiente',
		);
	}

	/**
	 * Prazo em que uma reserva PENDENTE ainda segura a correlação.
	 *
	 * @return int
	 */
	public static function ttl_reserva_pendente(): int {
		$ttl = (int) apply_filters( 'f3base_lead_reserva_pendente_ttl', 5 * MINUTE_IN_SECONDS );

		return max( 30, min( HOUR_IN_SECONDS, $ttl ) );
	}

	/**
	 * Prazo de guarda das chaves de deduplicação.
	 *
	 * @return int
	 */
	private static function ttl_dedup(): int {
		$ttl = (int) apply_filters( 'f3base_lead_dedup_ttl', 30 * DAY_IN_SECONDS );

		return max( HOUR_IN_SECONDS, $ttl );
	}

	/**
	 * Poda oportunista das chaves expiradas.
	 *
	 * @return void
	 */
	private static function podar_dedup(): void {
		if ( 1 !== wp_rand( 1, 50 ) ) {
			return;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$agora = time();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE criado_em < %d OR ( expira_em > 0 AND expira_em < %d ) OR ( estado = %s AND criado_em < %d )", // phpcs:ignore WordPress.DB.PreparedSQL
				$agora - self::ttl_dedup(),
				$agora,
				self::RESERVA_PENDENTE,
				$agora - self::ttl_reserva_pendente()
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Gravação
	 * ------------------------------------------------------------------ */

	/**
	 * O Flamingo está disponível?
	 *
	 * @return bool
	 */
	public static function flamingo_presente(): bool {
		return class_exists( 'Flamingo_Inbound_Message' ) && method_exists( 'Flamingo_Inbound_Message', 'add' );
	}

	/**
	 * Gera o identificador do servidor.
	 *
	 * @return string
	 */
	private static function gerar_record_id(): string {
		return bin2hex( random_bytes( 16 ) );
	}

	/**
	 * Grava o lead no destino disponível.
	 *
	 * @param array<string,mixed> $dados     Campos validados.
	 * @param string              $record_id Identificador do servidor.
	 * @return array{ok:bool,destino:string}
	 */
	private static function gravar_lead( array $dados, string $record_id ): array {
		$assunto  = self::montar_assunto( $dados );
		$de       = self::montar_remetente( $dados );
		$recusas  = array();

		if ( self::flamingo_presente() ) {
			$gravado = self::gravar_no_flamingo( $dados, $record_id, $assunto, $de );

			if ( $gravado ) {
				return array(
					'ok'      => true,
					'destino' => 'flamingo',
					'motivo'  => '',
				);
			}

			$recusas[] = 'flamingo';
		}

		if ( self::gravar_no_cpt( $dados, $record_id, $assunto, $de ) ) {
			return array(
				'ok'      => true,
				'destino' => self::CPT,
				'motivo'  => '',
			);
		}

		$recusas[] = self::CPT;

		return array(
			'ok'      => false,
			'destino' => self::CPT,
			'motivo'  => sprintf(
				/* translators: %s: destinos que recusaram, pelo nome. */
				__( 'destinos que recusaram: %s', 'f3base' ),
				implode( ', ', $recusas )
			),
		);
	}

	/**
	 * Grava na caixa do Flamingo.
	 *
	 * @param array<string,mixed> $dados     Campos validados.
	 * @param string              $record_id Identificador do servidor.
	 * @param string              $assunto   Assunto legível.
	 * @param string              $de        Remetente legível.
	 * @return bool
	 */
	private static function gravar_no_flamingo( array $dados, string $record_id, string $assunto, string $de ): bool {
		try {
			$resultado = Flamingo_Inbound_Message::add(
				array(
					'channel'    => self::CANAL,
					'subject'    => $assunto,
					'from'       => $de,
					'from_name'  => (string) $dados['nome'],
					'from_email' => (string) $dados['email'],
					'fields'     => self::campos_legiveis( $dados ),
					'meta'       => self::meta( $dados, $record_id ),
					'consent'    => empty( $dados['consentimento'] ) ? array() : array( 'f3base_consentimento' ),
				)
			);
		} catch ( Throwable $erro ) {
			return false;
		}

		return ! empty( $resultado );
	}

	/**
	 * Grava no CPT privado de contingência.
	 *
	 * @param array<string,mixed> $dados     Campos validados.
	 * @param string              $record_id Identificador do servidor.
	 * @param string              $assunto   Assunto legível.
	 * @param string              $de        Remetente legível.
	 * @return bool
	 */
	private static function gravar_no_cpt( array $dados, string $record_id, string $assunto, string $de ): bool {
		$corpo = array();

		foreach ( self::campos_legiveis( $dados ) as $rotulo => $valor ) {
			$corpo[] = $rotulo . ': ' . $valor;
		}

		$post_id = wp_insert_post(
			array(
				'post_type'    => self::CPT,
				'post_status'  => 'private',
				'post_title'   => $assunto,
				'post_content' => implode( "\n", $corpo ),
				'meta_input'   => array_merge(
					self::meta( $dados, $record_id ),
					array(
						'_f3base_from'    => $de,
						'_f3base_subject' => $assunto,
					)
				),
			),
			true
		);

		return ! is_wp_error( $post_id ) && $post_id > 0;
	}

	/**
	 * Assunto legível da gravação.
	 *
	 * @param array<string,mixed> $dados Campos validados.
	 * @return string
	 */
	private static function montar_assunto( array $dados ): string {
		$quem = (string) $dados['nome'];

		if ( '' === $quem ) {
			$quem = (string) $dados['email'];
		}
		if ( '' === $quem ) {
			$quem = (string) $dados['telefone'];
		}
		if ( '' === $quem ) {
			$quem = __( 'visitante sem contato informado', 'f3base' );
		}

		$formulario = (string) $dados['formulario'];
		$formulario = '' !== $formulario ? $formulario : 'contato-whatsapp';

		return sprintf(
			/* translators: 1: identificação do visitante, 2: id do formulário. */
			__( 'WhatsApp — %1$s (%2$s)', 'f3base' ),
			$quem,
			$formulario
		);
	}

	/**
	 * Remetente legível da gravação.
	 *
	 * @param array<string,mixed> $dados Campos validados.
	 * @return string
	 */
	private static function montar_remetente( array $dados ): string {
		$nome  = (string) $dados['nome'];
		$email = (string) $dados['email'];

		if ( '' !== $nome && '' !== $email ) {
			return $nome . ' <' . $email . '>';
		}
		if ( '' !== $email ) {
			return $email;
		}
		if ( '' !== $nome && '' !== (string) $dados['telefone'] ) {
			return $nome . ' <' . (string) $dados['telefone'] . '>';
		}
		if ( '' !== $nome ) {
			return $nome;
		}
		if ( '' !== (string) $dados['telefone'] ) {
			return (string) $dados['telefone'];
		}

		return __( 'clique de WhatsApp sem contato informado', 'f3base' );
	}

	/**
	 * Campos legíveis na listagem da caixa de leads.
	 *
	 * @param array<string,mixed> $dados Campos validados.
	 * @return array<string,string>
	 */
	private static function campos_legiveis( array $dados ): array {
		$campos = array(
			__( 'Nome', 'f3base' )     => (string) $dados['nome'],
			__( 'E-mail', 'f3base' )   => (string) $dados['email'],
			__( 'Telefone', 'f3base' ) => (string) $dados['telefone'],
			__( 'Mensagem', 'f3base' ) => (string) $dados['mensagem'],
			__( 'Página', 'f3base' )   => (string) $dados['pagina'],
		);

		$atribuicao = is_array( $dados['atribuicao'] ) ? $dados['atribuicao'] : array();
		foreach ( $atribuicao as $chave => $valor ) {
			$campos[ 'atribuicao.' . (string) $chave ] = (string) $valor;
		}

		return array_filter( $campos, static fn ( string $valor ): bool => '' !== $valor );
	}

	/**
	 * Metadados técnicos da gravação.
	 *
	 * @param array<string,mixed> $dados     Campos validados.
	 * @param string              $record_id Identificador do servidor.
	 * @return array<string,string>
	 */
	private static function meta( array $dados, string $record_id ): array {
		$atribuicao = is_array( $dados['atribuicao'] ) ? $dados['atribuicao'] : array();
		$json       = wp_json_encode( $atribuicao );

		return array(
			'_f3base_record_id'      => $record_id,
			'_f3base_correlation_id' => (string) $dados['correlation_id'],
			'_f3base_email'          => (string) $dados['email'],
			'_f3base_formulario'     => (string) $dados['formulario'],
			'_f3base_regime'         => 'whatsapp',
			'_f3base_consentimento'  => empty( $dados['consentimento'] ) ? 'nao' : 'sim',
			'_f3base_atribuicao'     => is_string( $json ) ? $json : '{}',
			'_f3base_registrado_em'  => (string) time(),
		);
	}

	/**
	 * Monta a resposta REST.
	 *
	 * @param int                 $status Código HTTP.
	 * @param array<string,mixed> $corpo  Corpo da resposta.
	 * @return WP_REST_Response
	 */
	private static function resposta( int $status, array $corpo ): WP_REST_Response {
		$corpo['fase'] = 'registro';

		return new WP_REST_Response( $corpo, $status );
	}
}
