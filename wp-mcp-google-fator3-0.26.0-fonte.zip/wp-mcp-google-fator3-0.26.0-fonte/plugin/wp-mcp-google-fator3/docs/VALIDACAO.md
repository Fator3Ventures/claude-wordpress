# Validação 0.26.0

Base direta 0.25.1. Rota corrente tools/release026.py, manifests026 em reproducao. Mínimo WP 7.1.2/PHP 8.3.6 e atual WP 7.1.4/PHP 8.3.6/MySQL 8.0.46. Acompanhantes originais Core 1.66.0, MCP 0.38.0, Meta 0.18.0 e LinkedIn 0.14.0. Sem patch de Core nesta rodada.

Pedido 48: fotografia nativa em oito combinações configuráveis; igualdade com schema publicado; matriz selected/effective nas duas finalidades e quatro destinos; valores e campos inválidos recusados. Status conserva prontidão GA4/Ads, sem HTTP/mail. Autorização, regressão dos avisos de renovação, instalação limpa/isolada, atualização direta, rollback/reaplicação e documentação MCP fazem parte da matriz.

Os totais e resultados efetivamente executados constam do relatório externo. Fontes/testes antigos são históricos. Bancadas interceptam HTTP externo e correio: não homologam Google real, mailbox ou cron por horas reais. Pipedrive 0.5 exige PHP 8.3.36 e não é ativado no piso. Não se afirma ausência absoluta de regressões fora do escopo.

A correção Core 363 encaminhada na 0.25.1 foi incorporada na 1.66.0. Aceite de ctooffice com LinkedIn ambos depende da frota; consulta direta desta rodada bloqueada pela revisão automática por escopo de ambiente. Site-Teste é o destino autorizado para a instalação Google.
