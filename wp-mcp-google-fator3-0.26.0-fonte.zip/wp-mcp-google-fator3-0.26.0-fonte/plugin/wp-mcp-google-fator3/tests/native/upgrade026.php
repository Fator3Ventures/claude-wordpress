<?php
/** 0.25.1 → 0.26.0: authenticated native update, encrypted archive/options preservation, rollback/reapply. */
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Options,Connections,Records,Settings};
use Fator3\McpFiles\{Persistence,Backups,StateStore};
verifyLab('actual declared baseline initialized origin',F3_MCP_GOOGLE_VERSION===expectedLab('baseline')&&F3_MCP_FILES_VERSION===expectedLab('baseline_mcp')&&F3BASE_PLUGIN_VERSAO===expectedLab('baseline_core'));
Options::batch_verified([Connections::SERVICES=>['gsc'=>'read'],Options::GA_ENABLED=>false,Options::ADS_ENABLED=>false,Connections::BINDINGS=>['gsc_site_url'=>home_url('/')]], [Fator3\McpGoogle\ConversionDelivery::SECRET=>'synthetic-preserved-mp',Options::OAUTH_REFRESH_TOKEN=>'synthetic-preserved-refresh',Options::SA_JSON=>'synthetic-preserved-sa']);
Connections::create('retained','Retained');Connections::run('retained',static fn()=>Options::set(Connections::SERVICES,['gtm'=>'read']));
Records::put('job','retained-completed',['id'=>'retained-completed','connection_id'=>'default','status'=>'completed','task'=>'preflight','cursor'=>1,'created_at'=>time(),'updated_at'=>time(),'expires_at'=>time()+86400]);
Records::put('schedule','retained-paused',['id'=>'retained-paused','enabled'=>false,'connection_id'=>'default','next_run'=>time()+86400,'task'=>'preflight']);
Records::put('audit','retained-audit',['connection_id'=>'default','action'=>'release:preserved','created_at'=>time()]);
Options::set(Fator3\McpGoogle\ConversionDelivery::CONFIG,['enabled'=>false,'measurement_id'=>'G-RETAINED','stream'=>'properties/111/dataStreams/222','customer_id'=>'','conversion_action'=>'']);
// A valid legacy 0.16 proof has only the shared grant. Upgrade must preserve it without HTTP.
update_option('f3base_ga4_measurement_id','G-UPGRADE017');
Options::batch_verified([Options::ENABLED=>true,Options::GA_ENABLED=>true,Options::ADS_ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'upgrade.apps.googleusercontent.com',Connections::SERVICES=>['ga'=>'write','ads'=>'write'],Fator3\McpGoogle\Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[Options::OAUTH_CLIENT_SECRET=>'synthetic-upgrade',Options::ADS_DEVELOPER_TOKEN=>'synthetic-upgrade-dev']);
$legacy=['enabled'=>true,'measurement_id'=>'G-UPGRADE017','stream'=>'properties/111/dataStreams/222','customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789','granted_by'=>1];
$proofMethod=new ReflectionMethod(Fator3\McpGoogle\ConversionDelivery::class,'proof_revision');$proofMethod->setAccessible(true);
foreach(['ga4','google_ads'] as $target)$legacy['verified'][$target]=['revision'=>$proofMethod->invoke(null,$legacy,$target),'at'=>time(),'expires'=>time()+86400,'by'=>1,'eligibility_source'=>$target==='ga4'?'admin_api_secret_match_and_debug':'data_manager_validate_only_and_action_read','value'=>0,'currency'=>'BRL'];
Options::set(Fator3\McpGoogle\ConversionDelivery::CONFIG,$legacy);
verifyLab('Legacy target proofs ready before upgrade',(new Fator3\McpGoogle\ConversionDelivery('ga4'))->capabilities()['ready']&&(new Fator3\McpGoogle\ConversionDelivery('google_ads'))->capabilities()['ready']);
$names=[Fator3\McpGoogle\ConversionDelivery::CONFIG,Fator3\McpGoogle\ConversionDelivery::SECRET,Connections::SERVICES,Options::GA_ENABLED,Options::ADS_ENABLED,Connections::BINDINGS,Options::OAUTH_REFRESH_TOKEN,Options::SA_JSON];
function fingerprintLab($names){global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT option_name,option_value FROM $wpdb->options WHERE option_name IN (".implode(',',array_fill(0,count($names),'%s')).") ORDER BY option_name",$names),ARRAY_A);return hash('sha256',serialize($rows));}
$socialNames=['f3_meta_release010_upgrade','f3_linkedin_release010_upgrade'];foreach($socialNames as $key){update_option($key,'preserve-upgrade');wp_schedule_single_event(time()+7200,$key);}
Options::set(Fator3\McpGoogle\RenewalNotifications::OPTION,['expiry_warning_hours'=>3]);
Records::put('notification','retained026',['state'=>'accepted','created_at'=>time()]);
$noticeBefore=Records::get('notification','retained026');
$names=array_merge($names,$socialNames,[Fator3\McpGoogle\RenewalNotifications::OPTION]);
Fator3\Meta\Store::put('audit','upgrade-sentinel',['synthetic'=>true]);Fator3\LinkedIn\Store::put('audit','upgrade-sentinel',['synthetic'=>true]);
function socialUpgrade010(): string {global $wpdb;return hash('sha256',serialize([$wpdb->get_results('SELECT * FROM '.Fator3\Meta\Store::table().' ORDER BY bucket,record_key',ARRAY_A),$wpdb->get_results('SELECT * FROM '.Fator3\LinkedIn\Store::table().' ORDER BY bucket,record_key',ARRAY_A)]));}
$socialTables=socialUpgrade010();
$archiveNames=[Fator3\McpGoogle\Ads\Archive::CONFIG,Fator3\McpGoogle\Integration\AdsServiceApi::GRANTS,Fator3\McpGoogle\Integration\QueryServiceApi::GRANTS];
foreach($archiveNames as $key)Options::set($key,['synthetic-preservation'=>['enabled'=>false,'revision'=>'retained024']]);
Fator3\McpGoogle\Ads\ArchiveStore::put('adsrows','retained024',['rows'=>[['gclid'=>'synthetic-retained024','cost_micros'=>'30000000']]]);
$archiveBefore=Fator3\McpGoogle\Ads\ArchiveStore::get('adsrows','retained024');$names=array_merge($names,$archiveNames);
$before=fingerprintLab($names);$rows=[];foreach(['job'=>'retained-completed','schedule'=>'retained-paused','audit'=>'retained-audit'] as $kind=>$id)$rows[$kind]=Records::get($kind,$id);
$credential=rpc_identityLab();$auth=$credential['auth'];$zip=getenv('F3_CANDIDATE');
$oldDoc=rpcLab('google/documentation',['document'=>'README.md']);verifyLab('Baseline documentation read before replacing files',!empty($oldDoc['success'])&&$oldDoc['plugin_version']===expectedLab('baseline'),$oldDoc['error_code']??null);

$r=rpcLab('plugins/upload-base64',['content_base64'=>base64_encode(file_get_contents($zip)),'expected_sha256'=>hash_file('sha256',$zip),'expected_slug'=>'wp-mcp-google-fator3','overwrite'=>true,'activate'=>true]);
if(!empty($r['pending'])&&!empty($r['package_operation_id']))$r=rpcLab('plugins/reconcile',['operation_id'=>$r['package_operation_id']]);
verifyLab('A14 authenticated HTTP updates exact Google candidate',!empty($r['success'])&&($r['version']??'')===expectedLab('candidate'),$r);$backup=$r['backup_id']??null;
$transport=rpcLab('google/conversion-delivery-status');verifyLab('Updated runtime accepts native Core transport',!empty($transport['core_transport']['ok']),$transport['core_transport']??null);
$optional=rpcLab('google/conversion-context');verifyLab('P13 consumer remains available with unchanged companions',!empty($optional['success'])&&$optional['core_conversion_context']['ok'],$optional);
$s=rpcLab('google/status');verifyLab('A14 fresh request observes new runtime and ready storage',($s['plugin_version']??$s['version']??'')===expectedLab('candidate')&&($s['storage']['ready']??false),$s);
verifyLab('Upgrade preserves ready legacy proofs without a new grant',!empty($s['conversion_delivery']['ga4']['ready'])&&!empty($s['conversion_delivery']['google_ads']['ready']),$s['conversion_delivery']??null);
$rd=rpcLab('google/readiness-status');$byId=[];foreach($rd['checks']??[] as $c)$byId[$c['id']]=$c;
verifyLab('0.18.0 readiness available after upgrade and sees preserved proofs',!empty($rd['success'])&&($byId['conversion_ga4']['detail']['ready']??false)&&($byId['conversion_google_ads']['detail']['ready']??false)&&$rd['plugin_version']===expectedLab('candidate'),$rd['error_code']??array_map(static fn($c)=>$c['code'],$byId));
$cat=rpcLab('google/ability-catalog',['prefix'=>'gtm/create-tag']);verifyLab('0.18.0 Portuguese gtm description served after upgrade',str_contains(wp_json_encode($cat,JSON_UNESCAPED_UNICODE),'Cria uma tag da área de trabalho'));
$newDoc=rpcLab('google/documentation',['document'=>'README.md']);verifyLab('Upgrade replaces document identity and bytes without old cache',!empty($newDoc['success'])&&$newDoc['plugin_version']===expectedLab('candidate')&&$newDoc['revision']!==$oldDoc['revision']&&hash('sha256',$newDoc['content'])===$newDoc['revision']);
$stale=rpcLab('google/documentation',['document'=>'README.md','offset'=>1,'expected_revision'=>$oldDoc['revision']]);verifyLab('Upgrade rejects continuation from baseline documentation',($stale['error_code']??'')==='f3_google_document_revision');
verifyLab('A14 ciphertext bindings selection and social sentinels survive',$before===fingerprintLab($names));foreach($socialNames as $key)verifyLab('G91-04 social cron preserved through Google upgrade '.$key,wp_next_scheduled($key)!==false);

foreach(['job'=>'retained-completed','schedule'=>'retained-paused','audit'=>'retained-audit'] as $kind=>$id)verifyLab('A14 current '.$kind.' record unchanged',Records::get($kind,$id)===$rows[$kind]);
verifyLab('A14 additional connection preserved',Connections::run('retained',static fn()=>Options::get(Connections::SERVICES))===['gtm'=>'read']);
$r=rpcLab('google/configuration-schema',['contract_version'=>'4.0.0']);verifyLab('configuration remains contract 4',!empty($r['success'])&&$r['contract_version']==='4.0.0',$r);
verifyLab('Renewal policy and accepted receipt survive update',Fator3\McpGoogle\RenewalNotifications::config()['expiry_warning_hours']===3&&Records::get('notification','retained026')===$noticeBefore);
$cfg023=rpcLab('google/configuration-schema',['compact'=>true,'include_values'=>true,'fields'=>['ads_archive','ads_consumer_grants','query_consumer_grants']]);
verifyLab('024 upgrade preserves all three explicit archive option payloads',!empty($cfg023['success'])&&count($cfg023['options'])===3&&$before===fingerprintLab($names));
verifyLab('024 encrypted permanent archive payload preserved',Fator3\McpGoogle\Ads\ArchiveStore::get('adsrows','retained024')===$archiveBefore);
$r=rpcLab('google/maintenance');verifyLab('A13 new maintenance reachable after update',!empty($r['success'])&&($r['maintenance_contract_version']??'')==='2.0.0',$r);
verifyLab('completed job is not replayed by maintenance',Records::get('job','retained-completed')===$rows['job']);
verifyLab('A14 Google update has rollback preimage',is_string($backup)&&$backup!=='');
$dry=rpcLab('plugins/rollback',['backup_id'=>$backup,'dry_run'=>true]);verifyLab('A14 rollback preview verifies original files without application',!empty($dry['success'])&&!empty($dry['rollback_ready'])&&empty($dry['applied'])&&empty($dry['changed']),$dry);
verifyLab('rollback preview preserves stored configuration',$before===fingerprintLab($names));
$edited=WP_PLUGIN_DIR.'/wp-mcp-google-fator3/assets/admin.css';$original=file_get_contents($edited);file_put_contents($edited,$original."\n/* deliberate rollback guard fixture */\n");
try{$guard=rpcLab('plugins/rollback',['backup_id'=>$backup,'dry_run'=>true]);verifyLab('G91-05 rollback refuses locally edited destination',empty($guard['success'])||empty($guard['rollback_ready']),$guard);}finally{file_put_contents($edited,$original);}
$restored=rpcLab('plugins/rollback',['backup_id'=>$backup]);verifyLab('G91-05 valid package rollback applies preimage',!empty($restored['success'])&&($restored['recovery_status']??'')==='rolled_back',$restored);
$old=rpcLab('google/status');verifyLab('G91-05 fresh request sees restored baseline',($old['plugin_version']??'')===expectedLab('baseline'),$old['plugin_version']??null);
$gone=rpcLab('google/readiness-status');verifyLab('Rolled-back baseline retains readiness',!empty($gone['success'])&&$gone['plugin_version']===expectedLab('baseline'));
clearstatcache(true);
$baselineZip=new ZipArchive();$baselineZip->open(getenv('F3_BASELINE'));$expectedFiles=[];
for($i=0;$i<$baselineZip->numFiles;$i++){$name=$baselineZip->getNameIndex($i);if(!str_ends_with($name,'/'))$expectedFiles[substr($name,strlen('wp-mcp-google-fator3/'))]=hash('sha256',$baselineZip->getFromIndex($i));}$baselineZip->close();
$actualFiles=[];$directory=WP_PLUGIN_DIR.'/wp-mcp-google-fator3';foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory,FilesystemIterator::SKIP_DOTS)) as $file)if($file->isFile())$actualFiles[substr($file->getPathname(),strlen($directory)+1)]=hash_file('sha256',$file->getPathname());ksort($expectedFiles);ksort($actualFiles);
verifyLab('Rollback restores exact baseline inventory before reapply',$actualFiles===$expectedFiles,['extra'=>array_keys(array_diff_key($actualFiles,$expectedFiles)),'missing'=>array_keys(array_diff_key($expectedFiles,$actualFiles)),'changed'=>array_keys(array_diff_assoc($expectedFiles,$actualFiles))]);
$again=rpcLab('plugins/upload-base64',['content_base64'=>base64_encode(file_get_contents($zip)),'expected_sha256'=>hash_file('sha256',$zip),'expected_slug'=>'wp-mcp-google-fator3','overwrite'=>true,'activate'=>true]);if(!empty($again['pending'])&&!empty($again['package_operation_id']))$again=rpcLab('plugins/reconcile',['operation_id'=>$again['package_operation_id']]);verifyLab('G91-05 candidate reapplied after rollback',!empty($again['success'])&&($again['version']??'')===expectedLab('candidate'),$again);
$back=rpcLab('google/readiness-status');verifyLab('Reapplied candidate serves readiness again',!empty($back['success']));
verifyLab('G91-05 rollback and reapply preserve database selection',$before===fingerprintLab($names));verifyLab('G91-04 social encrypted records unchanged through upgrade rollback and reactivation',socialUpgrade010()===$socialTables);
Fator3\Meta\Store::remove('audit','upgrade-sentinel',1);Fator3\LinkedIn\Store::remove('audit','upgrade-sentinel',1);
foreach($socialNames as $key){delete_option($key);wp_clear_scheduled_hook($key);}
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('upgrade026',['loaded_origin'=>expectedLab('baseline'),'observed_after_http'=>expectedLab('candidate'),'backup_id'=>$backup,'google_baseline_bridges_after_mcp_update'=>$GLOBALS['google_baseline_bridge_observation']??null,'rollback_scope'=>'file rollback applied and candidate reapplied; edited postimage refused; no database or remote rollback']);
