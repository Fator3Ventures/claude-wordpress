<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{ConversionDelivery as D,ContractSchema as S,Options as O,Connections as C,Settings,Policy};
wp_get_abilities();
$schema=require WP_PLUGIN_DIR.'/wp-mcp-google-fator3/includes/Data/CoreTransport140.php';
$published=json_decode(file_get_contents(__DIR__.'/../fixtures/core1660-conversion-snapshot-1.1.json'),true);
verifyLab('Schema equals original Core 1.66 public contract',$schema===$published&&$schema===F3Base_Conversoes_Contexto::schema('snapshot-1.1'));
verifyLab('Core 363 measurement fix available without patch',!empty(F3Base_Medicao_Contexto::snapshot()['ok']));
update_option('f3base_ga4_measurement_id','G-TEST026');update_option('f3base_linkedin_partner_id','12345');update_option('f3base_linkedin_conversion_id','67890');
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic026',O::OAUTH_REFRESH_TOKEN=>'synthetic026',O::ADS_DEVELOPER_TOKEN=>'synthetic026',D::SECRET=>'synthetic026']);
$config=['enabled'=>true,'measurement_id'=>'G-TEST026','stream'=>'properties/123/dataStreams/456','customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789','granted_by'=>1];
$proof=new ReflectionMethod(D::class,'proof_revision');$proof->setAccessible(true);
foreach(['ga4','google_ads'] as $target)$config['verified'][$target]=['revision'=>$proof->invoke(null,$config,$target),'at'=>time(),'expires'=>time()+86400,'by'=>1,'eligibility_source'=>$target==='ga4'?'admin_api_secret_match_and_debug':'data_manager_validate_only_and_action_read','value'=>0,'currency'=>'BRL'];
O::set(D::CONFIG,$config);
$network=0;$mail=0;
add_filter('pre_http_request',static function($pre,$args,$url)use(&$network){if(!str_starts_with($url,getenv('F3_LAB_URL').'/'))++$network;return $pre;},0,3);
add_filter('pre_wp_mail',static function($pre)use(&$mail){++$mail;return true;},PHP_INT_MAX);
$credential=rpc_identityLab();$auth=$credential['auth'];$before=google_config_digestLab();$matrix=[];
foreach(['navegador','servidor'] as $ga)foreach(['navegador','servidor'] as $ads)foreach(['navegador','ambos'] as $li){
 $selected=['ga4'=>$ga,'google_ads'=>$ads,'linkedin'=>$li];update_option('f3base_conversoes_transporte',$selected);
 $raw=F3Base_Conversoes_Contexto::snapshot(['contract'=>'site-conversion-purposes/1.1.0']);$out=D::core_transport();$label=implode('/',$selected);
 verifyLab('Native snapshot and consumer '.$label,!empty($raw['ok'])&&!empty($out['ok'])&&S::valid($out,$schema)&&$out['data']['revision']===$raw['data']['revision']);
 foreach($selected as $target=>$mode)verifyLab('Native selected/effective '.$label.'/'.$target,$out['data']['purposes'][0]['destinations'][$target]['transport']['selected']===$mode&&$out['data']['purposes'][0]['destinations'][$target]['transport']['effective']===$mode);
 $status=rpcLab('google/conversion-delivery-status');
 verifyLab('MCP status preserves valid snapshot and Google readiness '.$label,!empty($status['success'])&&!empty($status['core_transport']['ok'])&&!empty($status['ga4']['ready'])&&!empty($status['google_ads']['ready']),$status['core_transport']??null);
 verifyLab('Status output schema '.$label,!is_wp_error(rest_validate_value_from_schema($status,wp_get_ability('google/conversion-delivery-status')->get_output_schema())));
 if($li==='ambos')verifyLab('Unready LinkedIn remains precise '.$label,$status['core_transport']['data']['purposes'][0]['destinations']['linkedin']['transport']===['selected'=>'ambos','effective'=>'ambos','ready'=>false,'reason'=>'regra_ausente']);
 $matrix[]=['selected'=>$selected,'core_code'=>$out['code'],'ga4_ready'=>$status['ga4']['ready'],'ads_ready'=>$status['google_ads']['ready']];
}
// Independent selected/effective combinations, including optional material/Meta transport.
foreach([0,1] as $purpose)foreach(['ga4','meta','google_ads','linkedin'] as $target)foreach(['navegador','servidor','ambos'] as $selected)foreach(['navegador','servidor','ambos'] as $effective){
 $fixture=$raw;$fixture['data']['purposes'][$purpose]['destinations'][$target]['transport']=['selected'=>$selected,'effective'=>$effective,'ready'=>false,'reason'=>'fixture_unavailable'];
 verifyLab('Contract transport '.$purpose.'/'.$target.'/'.$selected.'/'.$effective,S::valid($fixture,$schema));
}
foreach([0,1] as $purpose)foreach(['ga4','meta','google_ads','linkedin'] as $target)foreach(['selected','effective'] as $field){
 $fixture=$raw;$fixture['data']['purposes'][$purpose]['destinations'][$target]['transport']=['selected'=>'ambos','effective'=>'ambos','ready'=>false,'reason'=>'fixture_unavailable'];$fixture['data']['purposes'][$purpose]['destinations'][$target]['transport'][$field]='unknown';
 verifyLab('Unknown transport rejected '.$purpose.'/'.$target.'/'.$field,!S::valid($fixture,$schema));
}
foreach(['provider','contract','extra','revision','ready'] as $kind){$fixture=$raw;
 if($kind==='extra')$fixture['data']['extra']=true;
 elseif($kind==='revision')$fixture['data']['revision']='bad';
 elseif($kind==='ready')$fixture['data']['purposes'][0]['destinations']['linkedin']['transport']['ready']='false';
 else $fixture[$kind]='unknown';
 verifyLab('Malformed snapshot rejected '.$kind,!S::valid($fixture,$schema));
}
$error=['ok'=>false,'code'=>'invalid_output','contract'=>'site-conversion-purposes/1.1.0','provider'=>'base-site-core-fator3','data'=>null];
verifyLab('Published invalid_output error accepted',S::valid($error,$schema));$error['code']='unknown';verifyLab('Unknown error rejected',!S::valid($error,$schema));
verifyLab('Reads preserve Google configuration and avoid external effects',$before===google_config_digestLab()&&$network===0&&$mail===0,[$network,$mail]);
$subscriber=wp_create_user('subscriber026','synthetic-lab-password');wp_set_current_user($subscriber);$denied=wp_get_ability('google/conversion-delivery-status')->execute([]);
verifyLab('Non-administrator cannot read conversion status',(is_wp_error($denied)||(is_array($denied)&&($denied['success']??null)===false))&&(D::status()['error_code']??'')==='f3_google_delivery_not_authorized',$denied);wp_set_current_user(1);
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('transport026',['native_configurations'=>$matrix,'schema_sha256'=>hash_file('sha256',__DIR__.'/../fixtures/core1660-conversion-snapshot-1.1.json'),'external_http'=>$network,'real_mail'=>0]);
