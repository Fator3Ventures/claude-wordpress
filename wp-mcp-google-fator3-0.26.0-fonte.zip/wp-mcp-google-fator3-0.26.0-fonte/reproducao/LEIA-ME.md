# Reprodução — Google 0.26.0

Base direta publicada: Google 0.25.1. Rota corrente: tools/release026.py. Somente evidence/026/closed-* e evidence/026/remote descrevem o instalador final desta rodada. Diretórios anteriores e propostas Core antigas são histórico. Não aplicar core1651-fix sobre Core 1.66.0.

## Entradas

Linux amd64, Python 3, PHP 8.3.6/MySQL 8.0.46. runtime-dependencies.json fixa URLs oficiais, bytes e hashes; download-runtime.py exige SHA-256 e extrai em diretório novo. Use php024.ini.template substituindo RUNTIME_DIRECTORY. O nome histórico do template é preservado. Wrapper: PHP_INI_SCAN_DIR vazio, LD_LIBRARY_PATH=runtime/usr/lib/x86_64-linux-gnu; executar runtime/usr/bin/php8.3 -c caminho/php.ini.

WordPress oficial 7.1.2 e 7.1.4: https://wordpress.org/wordpress-7.1.2.zip e https://wordpress.org/wordpress-7.1.4.zip. Hashes e versões em manifest026-*.json. Ajuste apenas os caminhos absolutos à máquina nova. A árvore runtime é conferida por tree_hash de tools/lab.py.

Instaladores externos, imutáveis, identificados por hash: base Google 0.25.1; Core 1.66.0; MCP 0.38.0; Meta 0.18.0; LinkedIn 0.14.0. Não aninhados neste fonte. Pipedrive 0.5.0 foi observado ativo remotamente; exige PHP 8.3.36 e não foi ativado no piso. Entradas atuais em entradas026/; normas r5 herdadas em entradas/. companion-source-parity026.json confere fontes Core/Meta contra seus instaladores.

## Build e testes

No plugin/wp-mcp-google-fator3:

```sh
PHP_WRAPPER build/export-contracts.php --check
python3 build/check-docs.py
python3 build/build.py candidate --output NOVO/wp-mcp-google-fator3-0.26.0-instalador.zip
python3 tools/release026.py --case CASO --manifest MANIFESTO --workdir NOVO_LAB --evidence NOVA_PROVA --php PHP_WRAPPER
```

O instalador reconstruído deve coincidir com o relatório. Casos independentes:

- minimum: manifest026-7.1.2.json; Google isolado, instalação limpa e gates próprios.
- current: manifest026-7.1.4.json; acompanhantes originais, contrato completo e oito configurações de transporte, política de renovação, documentação inteira por MCP HTTP.
- upgrade: manifest026-7.1.4.json; instalação da base 0.25.1, update autenticado pelo MCP, preservação de ciphertexts/grants/provas/avisos/acervo/jobs/sentinelas, rollback exato e reaplicação.

Reprodução do defeito: tools/lab.py --manifest manifest026-reproduction.json --workdir NOVO --origin clean --order mcp-first tests/native/prepare-core026.php tests/native/baseline026.php. Nesse manifesto candidate aponta para o ZIP 0.25.1; o produtor Core é 1.66.0 original. Não confundir reprodução de falha com validação da candidata.

prepare-core026 acelera apenas o intervalo de confirmação do ciclo nativo no estado descartável Core. Não altera arquivos acompanhantes. Laboratórios possuem marcador de propriedade, banco/portas exclusivos e bloqueio de HTTP externo e correio. As provas de renovação usam fornecedor/clock sintéticos; nenhum resultado equivale a entrega Google ou postal. PHPUnit integral não faz parte do gate desta rodada; não somar resultados unitários históricos.

## Site-Teste e fechamento

site-test-request48.php é sonda temporária de domínio, administrador e versões fixos. Usa somente filtros locais à requisição para a configuração sintética LinkedIn ambos; não grava fixture nem consulta fornecedor. Compara produtor, consumidor, status e preservação; removida ao concluir. Não integra runtime.

Documentação: document-pages026.json identifica os hashes esperados de cada página UTF-8 de até 65536 bytes; sha256-documents.js é usado para comparar os retornos. As leituras remotas têm expected_revision e resultados sanitizados sem conteúdo privado.

empacotar-fonte.py fecha o fonte uma única vez com relatório anterior ao fechamento; identidade final do fonte só no relatório externo. Extraia o fonte fechado e execute seu build para comprovar instalador idêntico. Não incluir bancos, cookies, logs brutos, dependências binárias ou helpers de transferência na entrega.
