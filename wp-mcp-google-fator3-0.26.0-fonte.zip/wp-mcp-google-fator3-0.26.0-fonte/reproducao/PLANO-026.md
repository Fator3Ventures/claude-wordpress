# Plano — Google 0.26.0

Base 0.25.1; rodada minor. Pedido MCP Google 48. Instalador-alvo ainda não gerado.

Sincronizar a cópia de site-conversion-purposes/1.1.0 com o schema publicado pelo Core 1.66.0: ambos nos 16 enums selected/effective dos quatro destinos e duas finalidades; invalid_output entre erros declarados. Preservar validação integral, contratos, nomes, configuração, entregas e permissões. Nenhuma leitura de options privadas no runtime Google.

Provas previstas: reprodução na base; igualdade estrutural com schema recebido; oito configurações nativas ga4/Ads navegador/servidor × LinkedIn navegador/ambos; campos opcionais selected/effective de todas as finalidades; valores inválidos recusados; prontidão de GA4/Ads, renovação, isolamento, instalação limpa, mínimo, atualização direta e rollback; documentação paginada por MCP. Fornecedores e correio sintéticos.

Core 1.66.0 incorpora a correção enviada na 0.25.1 (pedido Core 363). Encerramento no relatório, sem novo impacto apenas de status. Meta 0.18.0 e LinkedIn 0.14.0 preservados. Não há nova mudança pedida aos acompanhantes: falha e correção pertencem ao consumidor Google. Não emitir impacto individual. Aceite de produção ctooffice fica com frota; leitura nesta rodada bloqueada por revisão automática, sem tentativa alternativa.

Atualizar somente Google no Site-Teste após validação do ZIP fechado, preservar configuração e inventário, documentar backup. Entregar instalador, fonte reprodutível e relatório; não publicar nem distribuir frota.
