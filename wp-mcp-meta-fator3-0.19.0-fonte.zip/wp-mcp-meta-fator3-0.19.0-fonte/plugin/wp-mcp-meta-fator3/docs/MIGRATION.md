# Instalação, atualização e reversão — Meta 0.19.0

Base direta aceita: 0.17.0. Instalar o ZIP 0.18.0 sobre wp-mcp-meta-fator3/wp-mcp-meta-fator3.php, sem desinstalar. Preservar backup de arquivos, banco e salts; conferir SHA-256 no relatório. Conferir versão em PHP novo, health/selftest, 47 operações e 28 documentos completos com hashes. O fonte não é instalável.

Mantidos schema de registros 2 e histórico 1, sem nova tabela nem migração destrutiva. Configuração antiga recebe assets.ads=[] apenas na normalização; nenhum ativo, consumidor, token, agenda ou contato é autorizado automaticamente. A atualização preserva ciphertext/revisões das conexões, histórico orgânico, agendas, resultados, arquivo de Stories, retenção e exclusões. Novos campos de diagnóstico são preenchidos em execuções novas; não se inventa sucesso retroativo de agendas legadas.

Conexões Ads exigem ads_read conferido na geração atual do token e seleção explícita. Regravar ativos altera a autorização da conexão e pode exigir revisão das agendas/concessões conforme os guardas existentes. Renovações da mesma identidade seguem preservando a autorização quando a validação permite. Nenhuma agenda de anúncios é criada automaticamente.

Ads usa a tabela histórica existente em partição própria por conexão/conta/nível/atribuição, compartilhável entre administradores autorizados e consumidores registrados com concessão. Histórico orgânico conserva sua partição por principal. Registros Ads ficam sempre sem prazo, mesmo em conexão com política finita. O bucket cifrado ads_grant conserva concessões/revogações sem expiração. Core1.57.1 já integra a eliminação instagram-message-erasure/1.0.0; Core1.59.0 já registra o leitor Ads, que exige configuração e concessão explícitas.

A 0.18.0 acrescenta projeção somente leitura dos diagnósticos históricos. Não cria tabela/coluna/opção, não regrava registros e não altera concessões, consultas, checkpoints, pausas, orçamento ou retenção. Agendas legadas complete/null já mostram last_error_superseded=true. Leia COLLECTION-DIAGNOSTICS.md.

Rollback para 0.17.0: preserve banco, salts/chaves, concessões e recibos e substitua somente os arquivos pelo instalador-base. O rollback remove as marcas públicas de superação e o resumo health.schedules, reintroduzindo a ambiguidade do Pedido 26; não desfaz coletas/e-mails anteriores. Não apague dados/recibos para forçar repetição. Desativação/desinstalação preservam dados.

## Atualização 0.18.0 → 0.19.0

Substituir os arquivos no mesmo slug/basename. Sem DDL novo, regravação em massa, novas opções, mudança de grants ou reativação de agendas. Diagnósticos novos são aditivos em registros cifrados existentes; somente novas execuções recebem mensagens/rotas. Retenção permanece sem prazo. Rollback: restaurar instalador0.18.0 preservando banco, salts e backup; perde a consulta/diagnóstico corrigidos, sem desfazer os registros já persistidos. Não desinstale para reverter. Revalide cron, health e seleção após restauração.
