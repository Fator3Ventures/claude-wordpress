# Diagnóstico das coletas — 0.13.0

## Pedido MCP Meta 17

Uma falha de Story ou de métrica não prova que a conexão perdeu autorização. `story_expired` identifica uma recusa do fornecedor para Story cujo timestamp publicado está há pelo menos 24 horas; `story_insights_unavailable` identifica ausência/supressão ou recusa específica sem prova de expiração. Valores ausentes continuam `null`, nunca zero. A API pode retornar métricas para um objeto mais antigo; uma resposta válida não é descartada apenas pela idade. O plugin não promete recuperar insights já indisponíveis.

Esses códigos não geram issue de autorização nem e-mail. Insights indisponíveis por item produzem resultado parcial com a linha/métrica e diagnóstico; os demais itens/páginas continuam. Recusa do inventário de Stories pausa a coleta atual, conserva a agenda ativa e permite a próxima execução. Rede, quota e orçamento mantêm os códigos e a política de retry existentes. Não transformar indisponibilidade temporária de rede em revogação.

Recusas `token_rejected` e `asset_access_denied` são conferidas por um GET fixo `/me?fields=id` com a mesma credencial salva. Somente recusa de autorização também nessa validação torna a coleta `not_authorized` com `auth_scope=connection`. HTTP/códigos da operação original e da validação ficam separados. Uma validação inconclusiva não comprova revogação. `asset_access_denied` isolado em outro relatório permanece falha de recurso, com orientação específica; não reautoriza nem bloqueia automaticamente as outras agendas. Os gates locais de administrador e concessão continuam recusando acesso por `not_authorized`, independentemente da API; essa falha de origem não se propaga a outras concessões.

A falha confirmada da conexão é registrada no bucket cifrado `collection_failure`, vinculada a `authorization_revision` e `credential_generation`. Todas as agendas dessa conexão recebem o diagnóstico, inclusive as pausadas, sem alterar a seleção, seu principal, estado ativo/pausado ou revisão de autorização. A coleta e o worker não trocam credenciais nem concedem acesso. Um job da geração/identidade antiga não pode diagnosticar a credencial substituta.

## Persistência e leitura

`meta/list-schedules` retorna `last_code` para o resultado corrente e `last_error` para o último erro observado, com `code`, `http_status`, `provider_code`, `provider_subcode`, `observed_at` (Unix UTC) e, quando existentes, `provider_is_transient`, `retry_after`, `auth_scope`, `origin_code`, `connection_validation`, `authorization_revision`, `credential_generation`. Campos remotos desconhecidos são `null`, sem inventar status ou subcódigo. O último erro permanece após uma coleta bem-sucedida; `last_code=null`, `last_success_at` ou `last_recovered_at` indicam a recuperação.

`meta/audit` inclui `operation=collection-run` por avanço de coleta e `schedule-dispatch` quando a agenda falha antes de criar o job. Os eventos contêm conexão, agenda, job, ator de origem, `transport=collection_worker`, código, instante e `last_error` sanitizado. Auditoria mantém retenção sem expiração automática. O corpo/mensagem bruta da Graph, URLs, headers e tokens não são registrados. Falha de auditoria fica em `audit_health=failed`; não se afirma auditoria persistida quando o banco a recusa.

A cobertura do relatório acrescenta `coverage.last_error`, preservado na continuação; a amostra de `coverage.errors` continua limitada a 50. O último diagnóstico não depende dessa amostra. Consultar health, agenda, auditoria ou documentação não confirma remotamente a conexão e não envia avisos.

## Aviso e recuperação

`meta/health` agrega a revogação confirmada em `connection_authorization_failed`, uma issue por conexão. O e-mail ao `admin_email` informa causa medida, HTTP, código/subcódigo e instante, orientando renovar o token ou restaurar permissões do aplicativo. Não pede regravar cada agenda para um token revogado. Falha local de concessão pede restaurar acesso administrativo ou salvar a agenda pela concessão válida; conflito de revisão e recurso recusado têm ações próprias.

O worker/manutenção observa as issues atuais sob trava e reserva o conjunto antes de `wp_mail`. Faz uma única tentativa por incidente ativo, mesmo após uma hora ou uma falha/incerteza de correio; `accepted` só significa aceito pelo WordPress. Não há promessa de entrega nem reenvio automático incerto. Uma coleta nova bem-sucedida com a mesma geração resolve a falha da conexão; uma credencial/identidade nova aceita torna o diagnóstico antigo obsoleto. O worker registra a recuperação antes de avisar, sem enviar alerta de incidente já resolvido. Não se considera resultado armazenado de um job antigo prova de recuperação.

Nenhuma tabela/coluna nova. Dados e opções são preservados na atualização 0.9.0 → 0.10.0. O aviso usa a option existente `f3_meta_operation_notice` com mapa `active`; o formato anterior é aceito como sem mapa. Voltar arquivos à 0.9.0 perde a classificação e a deduplicação novas, sem desfazer diagnóstico/auditoria já gravados.

Referências oficiais consultadas em 24/10/2026: [Instagram Media Insights](https://developers.facebook.com/documentation/instagram-platform/reference/instagram-media/insights) (disponibilidade de métricas de Stories por 24 horas); [tratamento de erros Graph](https://developers.facebook.com/docs/graph-api/guides/error-handling/) (distinguir token e permissões). Esses contratos não comprovam a causa histórica dos e-mails de produção: aquela hipótese só pode ser confirmada com os códigos medidos.


## Pedido21 — coletas parciais na 0.13.0

Campos vazios/suprimidos, null e recusas específicas são diagnosticados individualmente; dados úteis dos pares permanecem. Zero é valor válido. Recusa de permissão por métrica só é localizada depois de conferir a conexão em /me; revogação global, quota ou transporte continuam interrompendo/retentando conforme seus códigos.

coverage acrescenta successful_rows acumulado, page_successful_rows e unavailable_metrics. Jobs acrescentam successful_rows, unavailable_metrics e outcome. Mantém status=partial terminal por compatibilidade quando há lacunas; outcome=failed distingue término sem nenhuma linha útil. Não houve sucesso só por gravar linhas com value=null. Agendas acrescentam last_run_status, last_successful_rows, unavailable_metrics e last_partial_at. last_success_at avança após persistência de linhas úteis (inclusive parcial); last_partial_at registra término parcial com dados. Falha global não se transforma em parcial. Health conta partial_schedules e failed_schedules separadamente entre agendas ativas; issue schedule_partial não dispara novo e-mail.

O workaround A-METASEG-2710 pode ser recomposto pelo operador da frota depois da implantação e conferência do recorte real; o pacote não altera agendas de produção automaticamente.

## Pedido 26 — diagnóstico de agenda na 0.18.0

`last_error` conserva a última ocorrência para consulta histórica. Em `meta/list-schedules.data.schedules[]` e `meta/health.data.schedules[]`, leia o conjunto `last_run_status`, `last_code`, `last_success_at`, `last_error_at`, `last_error_superseded` e `last_error_state`.

| Campo | Significado |
| --- | --- |
| last_error_at | Epoch UTC da observação original; null quando ausente. Não é a hora da consulta. |
| last_error_superseded | true quando o estado conhecido comprova que o erro foi superado; false não comprova, sozinho, erro atual. |
| last_error_state | none: sem diagnóstico; current: falha ou parcial atual; superseded: diagnóstico histórico superado; unknown: estado/datas insuficientes para decidir. |

`complete` com `last_code=null` marca o diagnóstico retido como superado, inclusive para agendas legadas e coletas vazias concluídas sem `last_success_at`. Em outros estados sem erro atual, só se usa `last_success_at` estritamente posterior a `last_error_at`. Falha atual, `partial` ou `last_code` preenchido nunca ficam superados por causa de dados úteis parciais. Uma coleta parcial pode atualizar last_success_at: esse timestamp isolado não comprova conclusão. Em fila com datas empatadas/ausentes, a classificação é unknown. Datas futuras ou ordem do relógio não são corrigidas artificialmente.

Exemplo de agenda recuperada:
```json
{"schedule_id":"ads-campanha-diario","last_run_status":"complete","last_code":null,"last_success_at":1793387990,"last_error":{"code":"budget_exhausted","observed_at":1793386785},"last_error_at":1793386785,"last_error_superseded":true,"last_error_state":"superseded"}
```

A marca é uma projeção de leitura, não uma migração: a atualização não apaga, redata nem regrava ciphertext, diagnóstico, revisão, grant, fila ou política de retenção. Também não chama a Meta, não envia e-mail e não executa reparo. `health.schedules` resume até 100 agendas, habilitadas ou não, com os mesmos campos da lista; seus contadores e incidentes continuam seguindo as regras existentes. `last_error` retido, sozinho, não deve disparar novo alerta. Erro desconhecido exige examinar estado e datas; não declarar recuperação sem evidência.

Aceite real em korvena.com.br pertence à frota: após atualizar, conferir que as agendas complete/null já exibem a marca imediatamente, sem forçar nova coleta. Uma falha posterior deve aparecer como current. A leitura é administrativa, inclusive por MCP/REST. Nenhum consumidor SDK precisa alterar seu contrato.

## Pedido 27 — detalhes sanitizados na 0.19.0

Erros HTTP acrescentam provider_message, provider_error_user_msg, provider_message_redacted, provider_type e fbtrace_id quando válidos. provider_call identifica uma rota fixa sem IDs/URL/token; request_stage distingue ad_account, dataset_binding, stats_browser, stats_server, optimization, emq e connection_validation; provider_api_version informa a versão usada. Campos inexistentes permanecem ausentes/null. diagnostic_action orienta a próxima conferência sem afirmar uma causa não medida.

Esses detalhes seguem para job-status, last_error da agenda e audit. Para dataset_quality, last_errors da agenda e errors da auditoria guardam até oito diagnósticos distintos da execução; health.datasets.diagnostics expõe a mesma projeção. last_error histórico continua sujeito a last_error_state/superseded. Sucesso posterior pode conservar a ocorrência antiga; não tratá-la como falha corrente. Não há reprocessamento dos erros antigos para inventar mensagens ausentes.

A sanitização mantém apenas vocabulário técnico permitido, substitui nomes/identificadores/números desconhecidos e remove URLs, e-mails, IPs e credenciais antes da persistência. Texto limitado a 512 bytes; provider_message_redacted sinaliza alteração. Tipos e rastreios têm validação própria. Uma mensagem pode perder termos técnicos desconhecidos; consulte o código, a rota e o fbtrace_id, sem registrar a resposta bruta. O diagnóstico HTTP é aditivo para os demais relatórios; seus contratos e controle de acesso permanecem.

Exemplo: provider_code=100 e request_stage=emq identificam a chamada recusada, mas não comprovam permissão insuficiente. Para código 10/200 ou HTTP403, conferir acesso “Usar conjunto de dados de eventos”, atribuição ao negócio/conta e ads_read com ads_management ou business_management usando a mesma credencial. O sucesso do conector oficial com outro usuário/token não valida a credencial salva neste plugin.
