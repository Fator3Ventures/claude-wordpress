<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Query {
    public static function execute(array $i,?array $principal=null,?int $expectedRevision=null): array {
        Schemas::validate('query',$i);$c=Connections::get($i['connection_id']);if(Config::KEY==='f3_meta')Catalog::validateSelection($c,$i);$principal=$principal??Access::principal();
        if($expectedRevision!==null){if($expectedRevision!==$c['revision'])throw new Fault('revision_conflict','A conexão mudou desde o plano.');Access::worker($principal,$c,$i['channel'],$i['account_id']);}
        else{Access::connection($c,$i['channel'],$i['account_id']);Connections::usable($c);}
        $base=$i;unset($base['cursor']);$binding=hash('sha256',Util::json([$base,$principal,Config::KEY==='f3_meta'?$c['authorization_revision']:$c['revision']]));$state=[];$priorErrors=[];$priorErrorCount=0;$pages=0;$lastError=null;$successful=0;$unavailable=[];
        if(!empty($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação não pertence à consulta, concessão ou revisão atual.');$state=$cur['state'];if(Config::KEY==='f3_meta'&&($cur['generation']??$c['credential_generation'])!==$c['credential_generation']){if(($c['token_identity']['validated_generation']??0)!==$c['credential_generation'])throw new Fault('credential_revalidation_required','Credencial alterada sem validação.');if(isset($state['after'])||isset($state['ids']))$state=[];}$lastError=$cur['last_error']??null;$priorErrors=$cur['errors']??[];$priorErrorCount=$cur['error_count']??count($priorErrors);$pages=(int)($cur['pages']??0);$successful=(int)($cur['successful_rows']??0);$unavailable=$cur['unavailable_metrics']??[];}
        try{$r=Adapter::page($c,$i,$state,$expectedRevision!==null?$principal:null);}catch(Fault $e){if(Config::KEY==='f3_meta'){if(in_array($i['report'],['stories','stories_insights'],true))throw CollectionState::storyFault($e,$c);throw CollectionState::classify($e,$c);}throw $e;}Connections::revalidate($c);Access::checkPrincipal($principal);
        $pageSuccessful=Config::KEY==='f3_meta'?count(array_filter($r['rows'],[CollectionState::class,'useful'])):count($r['rows']);$successful+=$pageSuccessful;$unavailable=array_values(array_unique(array_merge($unavailable,array_column($r['errors'],'field'))));
        $lastError=$r['errors']?end($r['errors']):$lastError;$errorCount=$priorErrorCount+count($r['errors']);$errors=array_slice(array_values(array_merge($priorErrors,$r['errors'])),0,50);$next=$r['next']!==null?Util::cursor(['binding'=>$binding,'generation'=>$c['credential_generation']??0,'state'=>$r['next'],'errors'=>$errors,'error_count'=>$errorCount,'last_error'=>$lastError,'pages'=>$pages+1,'successful_rows'=>$successful,'unavailable_metrics'=>$unavailable,'expires'=>time()+86400]):null;
        $data=['contract'=>Config::KEY==='f3_meta'&&(($i['granularity']??'interval')==='day'||in_array($i['channel'],['facebook','ads','dataset'],true)||!empty($i['iterate_media'])||$i['report']==='stories_insights')?'social-reporting/1.1.0':'social-reporting/1.0.0','provider'=>Config::SLUG,'channel'=>$i['channel'],'connection_id'=>$c['id'],'connection_revision'=>$c['revision'],'account_id'=>$i['account_id'],'api_version'=>$c['api_version'],'request_id'=>wp_generate_uuid4(),'fetched_at'=>gmdate('c'),'report'=>$i['report'],'selection'=>$base,'fields'=>$r['fields'],'field_catalog'=>Adapter::fields($i['report']),'rows'=>$r['rows'],'timezone'=>$r['timezone'],'currency'=>$r['currency'],'temporal'=>$r['temporal'],'coverage'=>['successful_rows'=>$successful,'page_successful_rows'=>$pageSuccessful,'unavailable_metrics'=>$unavailable,'complete'=>$next===null&&count($errors)===0,'plan_complete'=>$next===null,'all_rows_guaranteed'=>$r['origin_complete'],'stop_reason'=>$next!==null?'continuation':($errors?'fields_unavailable':'plan_finished'),'pages'=>$pages+1,'requested_from'=>$i['date_from']??null,'requested_to'=>$i['date_to']??null,'errors'=>$errors,'error_count'=>$errorCount,'errors_sampled'=>$errorCount>count($errors),'last_error'=>$lastError],'warnings'=>array_values(array_unique($r['warnings'])),'next_cursor'=>$next];
        if(strlen(Util::json($data))>700000)throw new Fault('response_limit','Resultado excedeu o orçamento. Reduza limit ou campos.');
        return $data;
    }
    public static function accounts(array $i): array {
        $c=Connections::get($i['connection_id']);Access::connection($c,$i['channel']);Connections::usable($c);$p=Access::principal();
        $binding=hash('sha256',Util::json([$c['id'],$c['revision'],$i['channel'],$i['ads_account_id']??null,$p]));$state=[];
        if(!empty($i['cursor'])){$v=Util::uncursor($i['cursor']);if(($v['binding']??'')!==$binding)throw new Fault('revision_conflict','Conexão ou concessão alterada.');$state=Config::KEY==='f3_meta'?['after'=>$v['next']]:['offset'=>$v['next']];}
        $r=Adapter::accounts($c,$i+$state);Connections::revalidate($c);Access::checkPrincipal($p);$next=$r['continuation'];unset($r['continuation']);
        return $r+['next_cursor'=>$next===null?null:Util::cursor(['binding'=>$binding,'next'=>$next,'expires'=>time()+3600]),'connection_revision'=>$c['revision']];
    }
    public static function validate(array $i): array {
        Access::admin();$principal=Access::principal();$c=Connections::get($i['connection_id']);Access::connection($c,$i['channel'],$i['account_id']);Connections::usable($c);
        $proof=Adapter::validate($c,$i['channel'],$i['account_id']);if(Config::KEY==='f3_meta')$proof['token_identity']=Credentials::identity($c);
        return Store::lock('connection:'.$c['id'],static function()use($c,$proof,$principal){Connections::revalidate($c);Access::checkPrincipal($principal);$next=$c;unset($next['revision']);$next['remote_proof']=$proof;if(isset($proof['token_identity']))$next['token_identity']=$proof['token_identity']+['validated_generation'=>$c['credential_generation']];if(Config::KEY==='f3_meta'){$before=$c;unset($before['revision']);if(!empty($next['token_identity']['app_verified']))$next['expires_at']=$next['token_identity']['remote_expires_at'];$saved=ConnectionChanges::commit($before,$next,$c['revision'],$principal,false,'validate-connection');return ['proof'=>$proof,'persisted'=>true,'revision'=>$saved['connection']['revision'],'schedules_rebased'=>$saved['schedules_rebased']];}$r=Store::put('connection',$c['id'],$next,$c['revision']);return ['proof'=>$proof,'persisted'=>true,'revision'=>$r['revision']];});
    }
}
final class Jobs {
    public static function create(array $i): array {
        $q=$i['query'];Schemas::validate('query',$q);if(!empty($q['cursor']))throw new Fault('invalid_input','Crie a coleta a partir de uma seleção sem cursor.');
        $c=Connections::get($q['connection_id']);Access::connection($c,$q['channel'],$q['account_id']);Connections::usable($c);$p=Access::principal();
        $key=hash('sha256',Util::json([$p,$i['idempotency_key']]));$intent=hash('sha256',Util::json([$q,$i['max_pages']??500]));
        return Store::lock('job-create:'.$key,static function()use($i,$q,$c,$p,$key,$intent){
            $old=Store::get('job',$key);if($old){if($old['value']['intent']!==$intent)throw new Fault('idempotency_conflict','Chave reutilizada para outra seleção.');return self::public($key,$old);}
            $v=['intent'=>$intent,'query'=>$q,'principal'=>$p,'connection_revision'=>$c['revision'],'status'=>'queued','pages'=>0,'rows'=>0,'cursor'=>null,'next_at'=>time(),'attempts'=>0,'max_pages'=>$i['max_pages']??500,'errors'=>[],'created_at'=>time(),'updated_at'=>time(),'last_code'=>null,'schedule_id'=>$i['schedule_id']??null]+Connections::checkpoint($c);
            $r=Store::put('job',$key,$v);$scheduled=self::scheduleTick();return self::public($key,$r)+['scheduled'=>$scheduled];
        });
    }
    public static function public(string $id,array $r): array {$v=$r['value'];return ['job_id'=>$id,'revision'=>$r['revision'],'status'=>$v['status'],'pages'=>$v['pages'],'rows'=>$v['rows'],'next_at'=>$v['next_at'],'last_code'=>$v['last_code'],'created_at'=>$v['created_at'],'updated_at'=>$v['updated_at'],'query'=>$v['query'],'errors'=>$v['errors'],'last_error'=>$v['last_error']??null,'successful_rows'=>$v['successful_rows']??0,'unavailable_metrics'=>$v['unavailable_metrics']??[],'outcome'=>$v['outcome']??$v['status']];}
    public static function status(string $id): array {$r=Store::get('job',$id);if(!$r)throw new Fault('not_found','Coleta não encontrada.');Access::owned($r['value']['principal']);return self::public($id,$r);}
    public static function list(array $i): array {
        $p=Access::principal();$offset=(int)($i['offset']??0);$batch=Store::list('job',$offset,50);$out=[];foreach($batch as $r)if(Util::same($p,$r['value']['principal']))$out[]=self::public($r['key'],$r);
        return ['jobs'=>$out,'next_offset'=>count($batch)===50?$offset+50:null];
    }
    public static function control(array $i): array {
        return Store::lock('job:'.$i['job_id'],static function()use($i){$r=Store::get('job',$i['job_id']);if(!$r)throw new Fault('not_found','Coleta não encontrada.');Access::owned($r['value']['principal']);if($r['revision']!==$i['expected_revision'])throw new Fault('revision_conflict','A coleta mudou.');$v=$r['value'];
            if(in_array($v['status'],['complete','partial','cancelled'],true))throw new Fault('job_terminal','Coleta encerrada.');
            $v['status']=match($i['action']){'pause'=>'paused','cancel'=>'cancelled',default=>'queued'};
            if($i['action']==='resume'){$c=Connections::get($v['query']['connection_id']);Access::worker($v['principal'],$c,$v['query']['channel'],$v['query']['account_id']);Connections::checkPlan($v,$c);$v['next_at']=time();$v['attempts']=0;}
            $v['updated_at']=time();$new=Store::put('job',$i['job_id'],$v,$r['revision'],Config::KEY!=='f3_meta'&&$v['status']==='cancelled'?time()+90*86400:0);self::scheduleTick();return self::public($i['job_id'],$new);
        });
    }
    public static function run(string $id,bool $background=false,?float $deadline=null): array {
        return Store::lock('job:'.$id,static function()use($id,$background,$deadline){
            $r=Store::get('job',$id);if(!$r)throw new Fault('not_found','Coleta não encontrada.');$v=$r['value'];if(!$background)Access::owned($v['principal']);
            if(!in_array($v['status'],['queued','retry'],true)||$v['next_at']>time())return self::public($id,$r);
            $c=null;$fresh=false;$budgetStarted=false;$pageKey=$id.':'.str_pad((string)$v['pages'],6,'0',STR_PAD_LEFT);
            try{
                $c=Connections::get($v['query']['connection_id']);Connections::checkPlan($v,$c);Access::worker($v['principal'],$c,$v['query']['channel'],$v['query']['account_id']);
                $existing=Store::get('result',$pageKey);
                if($existing){$data=$existing['value']['data'];}
                else{$q=$v['query'];if($v['cursor'])$q['cursor']=$v['cursor'];if(Config::KEY==='f3_meta')Http::budget(40,25,'job_page',$deadline);else Http::budget(12,25);$budgetStarted=true;$data=Query::execute($q,$v['principal'],$c['revision']);$fresh=true;
                    // The durable page precedes the checkpoint. Replay reuses it after a crash.
                    Store::put('result',$pageKey,['principal'=>$v['principal'],'connection_revision'=>$v['connection_revision'],'query'=>$v['query'],'data'=>$data],0,Config::KEY==='f3_meta'&&($c['retention_mode']==='unlimited'||in_array($v['query']['channel'],['ads','dataset'],true))?0:time()+86400*(int)$c['retention_days']);}
                if(Config::KEY==='f3_meta')History::ingest($data,$v['principal'],$c,$pageKey);
                if(Config::KEY==='f3_meta'){ExecutionBudget::progress($v);if($fresh)$v['last_budget']=Http::snapshot();}
                $v['last_error']=Config::KEY==='f3_meta'&&!empty($data['coverage']['last_error'])?CollectionState::diagnostic($data['coverage']['last_error']['code'],$data['coverage']['last_error']):null;$v['pages']++;$v['rows']+=count($data['rows']);$v['cursor']=$data['next_cursor'];$v['errors']=$data['coverage']['errors'];$v['status']=$v['cursor']?'queued':($data['coverage']['complete']?'complete':'partial');
                if($v['cursor']&&$v['pages']>=$v['max_pages']){$v['status']='partial';$v['last_code']='page_budget_exhausted';}else{$v['last_code']=$v['status']==='partial'?'fields_unavailable':null;}
                if(Config::KEY==='f3_meta'&&$v['last_code']==='fields_unavailable'&&!array_diff(array_column($v['errors'],'code'),['story_expired','story_insights_unavailable']))$v['last_code']=$v['errors'][0]['code'];
                $v['successful_rows']=($v['successful_rows']??0)+($data['coverage']['page_successful_rows']??count($data['rows']));$v['unavailable_metrics']=$data['coverage']['unavailable_metrics']??array_values(array_unique(array_column($v['errors'],'field')));$v['outcome']=$v['status']==='partial'&&$v['successful_rows']===0?'failed':$v['status'];if(($data['coverage']['page_successful_rows']??0)>0)$v['last_useful_at']=strtotime($data['fetched_at'])?:time();
                $v['attempts']=0;$v['next_at']=$v['cursor']?time()+5:0;
            }catch(Fault $e){if(Config::KEY==='f3_meta'){ExecutionBudget::failure($v,$e);if($budgetStarted)$v['last_budget']=Http::snapshot();}$v['attempts']++;$v['last_code']=$e->reason;$v['last_error']=Config::KEY==='f3_meta'?CollectionState::diagnostic($e->reason,$e->details):['code'=>$e->reason]+$e->details;$retry=in_array($e->reason,['rate_limited','upstream_error','busy','budget_exhausted'],true)&&($v['attempts']<6||(Config::KEY==='f3_meta'&&$e->reason==='budget_exhausted'));$v['status']=$retry?'retry':'paused';$v['outcome']='failed';$v['next_at']=$retry?time()+max((int)($e->details['retry_after']??0),($e->reason==='budget_exhausted'?300:min(21600,60*2**min(9,$v['attempts'])))):0;}
            $v['updated_at']=time();$saved=Store::put('job',$id,$v,$r['revision'],Config::KEY!=='f3_meta'&&in_array($v['status'],['complete','partial','cancelled'],true)?time()+90*86400:0);if(Config::KEY==='f3_meta')CollectionState::record($id,$v,$c,$fresh);if(in_array($v['status'],['queued','retry'],true))self::scheduleTick();return self::public($id,$saved);
        });
    }
    public static function results(array $i): array {
        $r=Store::get('job',$i['job_id']);if(!$r)throw new Fault('not_found','Coleta não encontrada.');$v=$r['value'];Access::owned($v['principal']);$c=Connections::get($v['query']['connection_id']);Access::worker($v['principal'],$c,$v['query']['channel'],$v['query']['account_id'],false);
        $page=(int)($i['page']??0);$p=Store::get('result',$i['job_id'].':'.str_pad((string)$page,6,'0',STR_PAD_LEFT));if(!$p||($p['expires_at']>0&&$p['expires_at']<time()))throw new Fault('result_unavailable','Página ausente ou expirada.');return ['page'=>$page,'data'=>$p['value']['data'],'next_page'=>$page+1<$v['pages']?$page+1:null,'job_status'=>$v['status']];
    }
    public static function scheduleTick(int $delay=5): bool {
        try{return Store::lock('worker-event',static function()use($delay){
            if(wp_next_scheduled(Config::KEY.'_worker'))return true;
            $result=wp_schedule_single_event(time()+max(5,$delay),Config::KEY.'_worker',[],true);
            $next=wp_next_scheduled(Config::KEY.'_worker')?:null;
            $ok=$result===true&&$next!==null;
            // A concurrent scheduler may have added it; do not report a missing event then.
            if(is_wp_error($result)&&$result->get_error_code()==='duplicate_event'&&$next!==null)$ok=true;
            $attempt=['at'=>time(),'success'=>$ok,'next'=>$next,'code'=>$ok?'ok':(is_wp_error($result)?sanitize_key($result->get_error_code()):'schedule_unconfirmed')];
            update_option(Config::KEY.'_worker_schedule_attempt',$attempt,false);
            if(!$ok)update_option(Config::KEY.'_worker_schedule_failure',$attempt,false);
            return $ok;
        });}catch(\Throwable $e){$attempt=['at'=>time(),'success'=>false,'next'=>null,'code'=>$e instanceof Fault?$e->reason:'schedule_exception'];update_option(Config::KEY.'_worker_schedule_attempt',$attempt,false);update_option(Config::KEY.'_worker_schedule_failure',$attempt,false);return false;}
    }
    public static function tick(): void {
        try{Store::lock('worker-pass',static function(){
            $start=microtime(true);$processed=0;$errors=0;$state='ok';$code=null;
            try{
                // Pre-arm protects against hard process termination; finally checks again.
                Worker::ensure(60);
                $migration=Result::run(static fn()=>Queue::migrate());
                if(!$migration['success']){$errors++;update_option(Config::KEY.'_queue_migration',['at'=>time(),'complete'=>false,'code'=>$migration['code']],false);}
                Schedules::tick($start+22);
                foreach(Queue::due(20,Config::KEY==='f3_meta'?Schedules::priorityJobs():[]) as $row){if(microtime(true)>$start+19)break;$r=Result::run(static fn()=>self::run($row['record_key'],true,$start+22));$processed++;if(!$r['success']){$errors++;if(in_array($r['code'],['cipher_unreadable','storage_corrupt'],true))Queue::isolate($row['record_key']);}}
                Store::prune();
            }catch(\Throwable $e){$state='failed';$code=$e instanceof Fault?$e->reason:'worker_exception';}
            finally{
                $recovery=Result::run(static fn()=>['scheduled'=>Worker::ensure(60)]);
                update_option(Config::KEY.'_last_worker',['at'=>time(),'origin'=>defined('WP_CLI')&&WP_CLI?'cli':'wp_cron','state'=>$state,'code'=>$code,'processed'=>$processed,'errors'=>$errors,'rearmed'=>$recovery['data']['scheduled']??false],false);
                Worker::notifySafely();
            }
        });}catch(Fault $e){if($e->reason!=='busy')throw $e;}
    }
}
final class Schedules {
    public static function save(array $i): array {return Store::lock('schedules',static fn()=>self::saveLocked($i));}
    private static function saveLocked(array $i): array {
        Access::admin();$id=Util::id($i['schedule_id']);$q=$i['query'];Schemas::validate('query',$q);if(isset($q['cursor']))throw new Fault('invalid_input','Agenda não aceita cursor.');
        $c=Connections::get($q['connection_id']);Access::connection($c,$q['channel'],$q['account_id']);Connections::usable($c);
        $old=Store::get('schedule',$id);if(!$old&&count(Store::list('schedule',0,100))>=100)throw new Fault('schedule_limit','Limite de 100 agendas.');if(($old['revision']??0)!==$i['expected_revision'])throw new Fault('revision_conflict','Agenda alterada.');
        $v=['label'=>sanitize_text_field($i['label']??($old['value']['label']??$id)),'query'=>$q,'principal'=>Access::principal(),'connection_revision'=>$c['revision'],'enabled'=>$i['enabled'],'interval_minutes'=>$i['interval_minutes'],'lookback_days'=>$i['lookback_days']??7,'next_at'=>$i['next_at']??($old['value']['next_at']??time()+60),'last_job'=>$old['value']['last_job']??null,'last_budget'=>($old['value']['query']??null)===$q?($old['value']['last_budget']??null):null,'budget_blocked_since'=>($old['value']['query']??null)===$q?($old['value']['budget_blocked_since']??null):null,'last_code'=>$old['value']['last_code']??null,'last_errors'=>$old['value']['last_errors']??[],'last_error'=>$old['value']['last_error']??null,'last_success_at'=>$old['value']['last_success_at']??null,'last_partial_at'=>$old['value']['last_partial_at']??null,'last_run_status'=>$old['value']['last_run_status']??null,'last_successful_rows'=>$old['value']['last_successful_rows']??0,'unavailable_metrics'=>$old['value']['unavailable_metrics']??[]]+Connections::checkpoint($c);
        $r=Store::put('schedule',$id,$v,$i['expected_revision']);Jobs::scheduleTick();return ['schedule_id'=>$id,'revision'=>$r['revision'],'enabled'=>$v['enabled'],'next_at'=>$v['next_at']];
    }
    public static function active(): bool {return (bool)array_filter(Store::list('schedule',0,100),static fn($r)=>$r['value']['enabled']);}
    public static function list(): array {Access::admin();$out=[];foreach(Store::list('schedule',0,100) as $r){$v=$r['value'];if(Config::KEY==='f3_meta')$v+=['last_error'=>null,'last_success_at'=>null,'last_partial_at'=>null,'last_run_status'=>null,'last_successful_rows'=>0,'unavailable_metrics'=>[]];if(Config::KEY==='f3_meta'){$v=array_replace($v,CollectionState::scheduleDiagnostic($v));$v['budget']=ExecutionBudget::view($v);}unset($v['principal']);$out[]=['schedule_id'=>$r['key'],'revision'=>$r['revision']]+$v;}return $out;}
    public static function priorityJobs(): array {$ids=[];foreach(Store::list('schedule',0,100) as $r)if(!empty($r['value']['enabled'])&&!empty($r['value']['last_job']))$ids[]=$r['value']['last_job'];return $ids;}
    public static function tick(?float $deadline=null): void {Store::lock('schedules',static function()use($deadline){if(Config::KEY==='f3_meta')Http::budget(40,25,'schedule_dispatch',$deadline);self::tickLocked();});}
    private static function tickLocked(): void {
        foreach(Store::list('schedule',0,100) as $row){$v=$row['value'];if(!$v['enabled']||$v['next_at']>time())continue;
            Result::run(static function()use($row){return Store::lock('schedule:'.$row['key'],static function()use($row){$r=Store::get('schedule',$row['key']);$v=$r['value'];if(!$v['enabled']||$v['next_at']>time())return [];
                try{$c=Connections::get($v['query']['connection_id']);Connections::checkPlan($v,$c);Access::worker($v['principal'],$c,$v['query']['channel'],$v['query']['account_id']);$q=$v['query'];
                    if(!in_array($q['report'],['profile','media','stories','media_insights','stories_insights','audience','page_profile','page_posts','page_videos','page_ratings','post_insights','video_insights','page_audience','organization','posts','follower_total','ad_accounts','campaign_groups','campaigns','creatives'],true)){$q['date_to']=gmdate('Y-m-d',time()-86400);$q['date_from']=gmdate('Y-m-d',time()-86400*$v['lookback_days']);}
                    if(Config::KEY==='f3_meta'&&in_array($q['channel'],['ads','dataset'],true)){$q['date_to']=Ads::yesterday($c,$q['ads_account_id']??$q['account_id']);$q['date_from']=gmdate('Y-m-d',strtotime($q['date_to'].' UTC')-86400*($v['lookback_days']-1));}
                    $key=hash('sha256','schedule|'.$row['key'].'|'.$v['next_at']);$old=Store::get('job',$key);
                    if(!$old){$job=['intent'=>hash('sha256',Util::json($q)),'query'=>$q,'principal'=>$v['principal'],'connection_revision'=>$c['revision'],'status'=>'queued','pages'=>0,'rows'=>0,'cursor'=>null,'next_at'=>time(),'attempts'=>0,'max_pages'=>500,'errors'=>[],'created_at'=>time(),'updated_at'=>time(),'last_code'=>null,'schedule_id'=>$row['key']]+Connections::checkpoint($c);Store::put('job',$key,$job);}
                    if(Config::KEY==='f3_meta'){$v['last_budget']=Http::snapshot();$v['budget_blocked_since']=ExecutionBudget::since($v);}$v['last_job']=$key;$v['last_code']=null;$v['last_run_status']='queued';$v['last_successful_rows']=0;$v['unavailable_metrics']=[];$v['next_at']=time()+60*$v['interval_minutes'];
                }catch(Fault $e){if(Config::KEY==='f3_meta')ExecutionBudget::failure($v,$e);$v['last_code']=$e->reason;$v['last_run_status']='failed';if(Config::KEY==='f3_meta'){$v['last_error']=CollectionState::diagnostic($e->reason,$e->details);CollectionState::audit('schedule-dispatch',$v['query']['connection_id'],$row['key'],null,$e->reason,$v['last_error'],$v['principal']);}$v['next_at']=time()+300;if(Config::KEY!=='f3_meta')$v['enabled']=false;}
                Store::put('schedule',$row['key'],$v,$r['revision']);return [];
            });});
        }
    }
}
