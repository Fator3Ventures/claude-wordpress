<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

final class Worker {
    private const AUTH_CODES=['not_authorized','grant_revoked','credential_revoked','authorization_revoked','revision_conflict','credential_revalidation_required'];
    public static function ensure(int $delay=60): bool {
        if(Schedules::active()||Queue::waiting())return Jobs::scheduleTick($delay);
        return true;
    }
    /** Runs on plugins_loaded: no SQL once the migration is confirmed complete under schema 2. */
    public static function bootstrap(): void {
        if(Queue::settled())return;
        if(Queue::pending()){Result::run(static fn()=>Queue::migrate());self::ensure();}else Queue::markSettled();
    }
    public static function maintenance(): void {
        // Recovery must precede retention, whose failure cannot break the chain.
        $recovery=Result::run(static fn()=>['scheduled'=>self::ensure()]);
        try{Result::run(static fn()=>Queue::migrate());$prune=Result::run(static fn()=>['removed'=>Store::prune()]);}
        finally{Result::run(static fn()=>['scheduled'=>self::ensure()]);self::notifySafely();}
        update_option(Config::KEY.'_last_maintenance',['at'=>time(),'recovery'=>$recovery['success'],'retention_code'=>$prune['code']],false);
    }
    public static function health(): array {
        $now=time();$queue=Queue::health();$issues=[];$active=0;$partial=0;$failed=0;$failures=[];$budgets=[];$schedules=[];foreach(Store::list('connection',0,100) as $row){$c=Connections::defaults($row['value'])+['revision'=>$row['revision']];$failure=CollectionState::connectionFailure($c);if($failure){$failures[$c['id']]=$failure;$issues[]=['code'=>'connection_authorization_failed','connection_id'=>$c['id'],'label'=>$c['label'],'last_code'=>'not_authorized','last_error'=>$failure,'incident_key'=>$c['id'].':'.$c['authorization_revision'].':'.$c['credential_generation'],'action'=>'A Meta recusou a credencial também em /me. Renove o token da conexão ou restaure as permissões do aplicativo; não é necessário recriar as agendas.'];}}
        foreach(Store::list('schedule',0,100) as $r){$v=$r['value'];$schedules[]=['schedule_id'=>$r['key'],'connection_id'=>$v['query']['connection_id'],'enabled'=>(bool)$v['enabled']]+CollectionState::scheduleDiagnostic($v);if(empty($v['enabled']))continue;$active++;
            $budgets[]=['schedule_id'=>$r['key'],'connection_id'=>$v['query']['connection_id']]+ExecutionBudget::view($v);
            $common=['schedule_id'=>$r['key'],'connection_id'=>$v['query']['connection_id'],'label'=>$v['label']??$r['key']];$code=$v['last_code']??null;$lastError=$v['last_error']??null;
            try{$current=Connections::get($v['query']['connection_id']);if(($lastError['auth_scope']??null)==='connection'&&!CollectionState::connectionFailure($current))$code=null;}catch(Fault $e){$current=null;}
            // A grant may be revoked after the schedule creates its job.
            if(!empty($v['last_job'])){try{$job=Store::get('job',$v['last_job']);if($job&&in_array($job['value']['last_code']??null,self::AUTH_CODES,true)&&($job['value']['last_error']['auth_scope']??null)!=='connection'&&(!$current||CollectionState::current($job['value'],$current))){$code=$job['value']['last_code'];$lastError=$job['value']['last_error']??null;}}
                catch(Fault $e){if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;$issues[]=$common+['code'=>'schedule_job_unreadable','action'=>'A última coleta desta agenda está ilegível. Confira as chaves (salts) e a integridade do registro; seus dados foram preservados.'];}}
            if(!isset($failures[$v['query']['connection_id']])&&in_array($code,self::AUTH_CODES,true))$issues[]=$common+['code'=>'schedule_authorization_failed','last_code'=>$code,'last_error'=>$lastError,'action'=>$code==='revision_conflict'?'A revisão da agenda ou da concessão mudou. Confira a seleção e salve a agenda com a revisão atual.':'O usuário ou a concessão de origem perdeu autorização. Restaure o acesso administrativo ou salve a agenda pela concessão autorizada.'];
            if($code==='asset_access_denied'&&!in_array($v['query']['report'],['stories','stories_insights'],true))$issues[]=$common+['code'=>'schedule_resource_access_failed','last_code'=>$code,'last_error'=>$lastError,'action'=>'A Meta recusou acesso ao recurso desta consulta. Confira a seleção do ativo e as permissões para este relatório; a revogação da conexão não foi comprovada.'];
            if(($v['last_run_status']??null)==='partial'&&!in_array($code,self::AUTH_CODES,true)&&!isset($failures[$v['query']['connection_id']])){$partial++;$issues[]=$common+['code'=>'schedule_partial','unavailable_metrics'=>$v['unavailable_metrics']??[],'successful_rows'=>$v['last_successful_rows']??0,'last_partial_at'=>$v['last_partial_at']??null,'action'=>'Métricas disponíveis foram preservadas. Confira somente as métricas indisponíveis antes de recompor a agenda.'];}
            elseif(($v['last_run_status']??null)==='failed'||$code!==null)$failed++;
            $blocked=ExecutionBudget::since($v);if($blocked!==null&&$now-$blocked>86400)$issues[]=$common+['code'=>'schedule_budget_exhausted','last_code'=>'budget_exhausted','blocked_since'=>$blocked,'blocked_seconds'=>$now-$blocked,'last_error'=>$lastError,'budget'=>ExecutionBudget::view($v),'action'=>'A agenda está bloqueada pelo orçamento local há mais de 24 horas. Confira consumo, prazo e próxima execução no diagnóstico; confira o cron e o progresso das coletas. A quota remota da Meta é informada separadamente.'];
            $lag=max(0,$now-(int)$v['next_at']);if($lag>2*60*(int)$v['interval_minutes'])$issues[]=$common+['code'=>'schedule_overdue','lag_seconds'=>$lag,'action'=>'Confira o cron e a autorização da agenda.'];
        }
        $next=wp_next_scheduled(Config::KEY.'_worker')?:null;$needed=$active>0||Queue::waiting();
        if($needed&&$next===null)$issues[]=['code'=>'worker_missing','action'=>'Rearmar o worker local e conferir o cron do servidor.'];
        if($queue['migration_pending'])$issues[]=['code'=>'queue_migration_pending','action'=>'Aguarde as passagens do worker; consulte a migração se não houver progresso.'];
        if(!wp_next_scheduled(Config::KEY.'_maintenance'))$issues[]=['code'=>'maintenance_missing','action'=>'A manutenção horária é recriada na próxima requisição do site; confira o cron do servidor.'];
        if($queue['unreadable_jobs']>0)$issues[]=['code'=>'queue_record_unreadable','count'=>$queue['unreadable_jobs'],'action'=>'Há coletas cifradas que a chave atual do site não abre. Confira as chaves (salts) do wp-config; esses registros não são executados nem apagados automaticamente.'];
        return ['state'=>$issues?'degraded':'ok','observed_at'=>$now,'issues'=>$issues,'active_schedules'=>$active,'partial_schedules'=>$partial,'failed_schedules'=>$failed,'worker_required'=>$needed,'cron'=>['next'=>$next,'last'=>get_option(Config::KEY.'_last_worker',null),'traffic_required'=>!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON),'last_schedule_attempt'=>get_option(Config::KEY.'_worker_schedule_attempt',null),'last_schedule_failure'=>get_option(Config::KEY.'_worker_schedule_failure',null)],'queue'=>$queue,'execution_budget_policy'=>ExecutionBudget::policy(),'budgets'=>$budgets,'schedules'=>$schedules,'notification'=>get_option(Config::KEY.'_operation_notice',null)];
    }
    /** Read-only observation for meta/health: same diagnosis as status, never repairs, schedules or sends e-mail. */
    public static function observe(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(Connections::list()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'audit_health'=>get_option(Config::KEY.'_audit_health','unknown'),'maintenance'=>['next'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null,'last'=>get_option(Config::KEY.'_last_maintenance',null)],'repair'=>'not_attempted']+self::health();
    }
    public static function status(): array {
        $h=self::health();$observed=$h['cron']['next'];$attempted=$h['worker_required']&&$observed===null;
        $repair=$attempted?Result::run(static fn()=>['scheduled'=>Jobs::scheduleTick()]):null;
        $h['cron']['observed_next']=$observed;$h['cron']['next']=wp_next_scheduled(Config::KEY.'_worker')?:null;
        $h['recovery']=['attempted'=>$attempted,'scheduled'=>$attempted?($repair['data']['scheduled']??false):null,'code'=>$repair['code']??null];
        $h['cron']['last_schedule_attempt']=get_option(Config::KEY.'_worker_schedule_attempt',null);$h['cron']['last_schedule_failure']=get_option(Config::KEY.'_worker_schedule_failure',null);
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(Connections::list()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'audit_health'=>get_option(Config::KEY.'_audit_health','unknown')]+$h;
    }
    public static function notifySafely(): void {Result::run(static function(){self::notify();return [];});}
    public static function notify(): void {
        Store::lock('operation-notice',static function(){
            $h=self::health();$issues=array_values(array_filter($h['issues'],static fn($i)=>!in_array($i['code'],['schedule_partial','queue_migration_pending','queue_record_unreadable','schedule_job_unreadable','maintenance_missing'],true)));
            $old=get_option(Config::KEY.'_operation_notice',[]);$now=time();$active=[];$new=[];
            foreach($issues as $i){$key=hash('sha256',Util::json([$i['code'],$i['incident_key']??$i['schedule_id']??'worker',$i['last_code']??null]));$active[$key]=true;if(empty($old['active'][$key]))$new[]=$i;}
            if(!$new){if(($old['active']??[])!==$active){$old['active']=$active;$old['observed_at']=$now;if(!$active)$old['resolved_at']=$now;update_option(Config::KEY.'_operation_notice',$old,false);}return;}
            // At most one attempt for an active incident, including unknown mail delivery outcomes.
            $notice=['attempted_at'=>$now,'state'=>'sending','issue_count'=>count($new),'active'=>$active];
            update_option(Config::KEY.'_operation_notice',$notice,false);
            if(get_option(Config::KEY.'_operation_notice')!==$notice)return;
            $to=sanitize_email((string)get_option('admin_email',''));$lines=['Fator3 MCP Meta: a coleta requer atenção.',home_url('/'),''];
            foreach($new as $i){$lines[]=($i['label']??'Worker').' ('.($i['connection_id']??$i['schedule_id']??'cron').'): '.$i['action'];$e=$i['last_error']??null;if($e){$lines[]='Causa medida: '.($e['code']??$i['last_code']??$i['code']).'; HTTP '.($e['http_status']??'indisponível').'; Graph '.($e['provider_code']??'indisponível').'/'.($e['provider_subcode']??'indisponível').'; instante '.gmdate('c',(int)($e['observed_at']??$now)).'.';}}
            $lines[]='Abra Ferramentas → Fator3 MCP Meta → Diagnóstico. Nenhuma concessão foi renovada automaticamente.';
            $sent=false;try{if(is_email($to))$sent=wp_mail($to,'Fator3 MCP Meta: atenção às coletas',implode("\n",$lines));}catch(\Throwable $e){$sent=false;}
            $notice['state']=$sent?'accepted':'failed';$notice['finished_at']=time();update_option(Config::KEY.'_operation_notice',$notice,false);
        });
    }
}
