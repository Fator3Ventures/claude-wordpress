# Fonte — Fator3 MCP Meta 0.19.0

Base0.18.0; Pedido27. Código editável em build; build/build.py gera runtime e ZIP determinísticos. Defina F3_SOCIAL_PHP para PHP CLI compatível; lock tools/build-runtime0160.json. plugin contém runtime idêntico ao instalador final. Consulte planning/RELEASE-0190.md, tests/README-0190.md e evidence. Conteúdo em history é histórico e não implica reexecução. Nenhum laboratório compõe o instalador.
