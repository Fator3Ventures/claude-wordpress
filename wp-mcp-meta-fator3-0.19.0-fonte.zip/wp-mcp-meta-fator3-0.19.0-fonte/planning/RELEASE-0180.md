# Meta 0.18.0 — Pedido 26

31/10/2026, America/Sao_Paulo. Base direta 0.17.0, instalador a360feff0bdb723c7f3c2a240b288bc1c3af917e851cb798d905e31a95b4162d. Alvo previsto 0.18.0; instalador ainda não gerado no planejamento. Core 1.65.1/MCP 0.38.0 recebidos e ativos; Google 0.24.0, LinkedIn 0.13.0 e Pipedrive 0.5.0 ativos.

## Análise e decisão antes do código

CollectionState conserva intencionalmente o último diagnóstico, mas list-schedules não explicita que ele é histórico quando last_run_status=complete e last_code=null. O health não oferece resumo de execução das agendas sem incidente. Marcar o histórico em projeção somente leitura preserva dados e funciona imediatamente nos registros legados da 0.17.0, sem migração ou nova execução. last_success_at também avança com dados úteis parciais, portanto sua presença sozinha não comprova recuperação.

Publicar last_error_at, last_error_superseded e last_error_state (none/current/superseded/unknown), junto dos estados existentes; health ganha schedules com diagnóstico mínimo por agenda. Resultado complete sem last_code comprova superação; fora dele, só usar sucesso estritamente posterior ao diagnóstico e ausência de falha/parcial atual. Datas ausentes/empates não geram uma ordem inventada. Erros atuais e parciais permanecem explícitos. Não apagar nem regravar histórico, alterar notificações, grants, orçamento, filas, contratos SDK ou retenção.

## Provas previstas

Reproduzir na base falha seguida de sucesso com diagnóstico antigo. Testar fluxo real da candidata, leitura sem mutação/HTTP/mail, registros legados sem datas, empate de segundos, coleta vazia concluída, falha nova, parcial com dados úteis e permissão de assinante. Instalação limpa, atualização direta com ciphertext/opções preservados, mínimo WordPress 6.4/PHP 8.1.2, regressões do orçamento/fila e integração com Core/MCP atuais. Provas de fornecedor/frota são distintas e ficam pendentes do operador.

## Fronteiras e impactos

Alteração aditiva no diagnóstico Meta, sem modificação exigida dos consumidores publicados. Core/MCP atualizados internamente preservam contratos consumidos; verificar hashes e convivência. Nenhum pedido técnico novo a outro pacote identificado. Não gerar impacto como resposta/encerramento; registrar resultados e pendências no relatório próprio, seguindo a instrução expressa do usuário sobre a regra r4 recebida. Não modificar a lista central nem pacotes alheios.

## Resultado — 31/10/2026

Implementação e testes concluídos: 394 verificações da candidata e 3 da reprodução na base, lint de 33 arquivos, mínimo WP6.4/PHP8.1.2, atualização com preservação e integração com cinco acompanhantes. Versão 0.18.0 instalada no Site-Teste; 28 documentos/31 páginas conferidos. Cinco laboratórios e controlador temporário removidos. Preservada evidência da falha inicial de envelope do harness e da repetição aprovada. Nenhuma nova demanda técnica a outro pacote. Aceite real de korvena.com.br permanece com a frota. Fonte e relatório fechados após registrar as evidências.
