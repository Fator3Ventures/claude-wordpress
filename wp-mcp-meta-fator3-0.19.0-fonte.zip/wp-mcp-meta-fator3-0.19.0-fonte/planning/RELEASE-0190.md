# Meta 0.19.0 — Pedido 27

01/11/2026, America/Sao_Paulo. Base 0.18.0, instalador 5aef6b8fe85e69478285a84ed5d12c623d7834108928c911ca0e54aaf46d95f8. Alvo previsto 0.19.0; instalador ainda não gerado. Site-Teste observado: Core1.66.0, MCP0.38.0, Google0.25.1, Meta0.18.0, LinkedIn0.14.0 e Pipedrive0.5.0.

## Diagnóstico e decisões antes da implementação

O pedido recebido confirma o aceite de frota do 26 e abre o 27. Não há mensagem da recusa histórica, logo não se atribui causa definitiva ao HTTP400 de produção. A base exige primeiro dataset/adaccounts, embora a descoberta aceita no pedido seja act_conta/adspixels; a checagem será alinhada à descoberta mantendo confirmação explícita da relação. O diagnóstico atual remove deliberadamente todo texto e não identifica a requisição. Falhas opcionais de transporte e validação tardia de EMQ podem descartar contagens já obtidas.

Projetar mensagem/error_user_msg sanitizados por vocabulário técnico fechado, tipo, fbtrace_id, código e chamada por rota-modelo sem IDs/URLs/tokens. Persistir o mesmo resumo no job, agenda, auditoria e health. Campos livres desconhecidos são redigidos; nunca guardar o corpo bruto. Erro100 não prova falta de permissão: distinguir código de permissão medido de causa indeterminada e fornecer ação específica.

Contagens separadas por origem usam aggregation=event, conforme restrição event_source do conector oficial Meta; agregar buckets horários distintos e validar cobertura do dia no fuso, sem somar eventos repetidos nem inferir zero de ausência. Reduzir projeção EMQ a web{event_name,event_match_quality}; projetar resposta para campos conhecidos. Falha de uma fase não elimina as demais. Concessão/revisão/seleção alterada permanece fatal. EMQ atual continua snapshot separado; contratos/grants/retencão e 47 operações preservados.

## Fronteiras

Core1.66.0 já exige zero_confirmed, dois zeros explícitos, optimized_by e ambas coberturas para alertar. Suas leituras aceitam linhas parciais. Não é necessário alterar seu contrato meta-ads-monitoring/1.0.0 nem configurar outro plugin. Verificar leitura efetiva pelo Core com contagens sem EMQ e EMQ sem contagens; se surgir incompatibilidade concreta, registrar impacto antes da alteração dependente. Google0.25.1 e Core1.66.0 recebidos preservam os contratos pertinentes. Nenhum impacto novo identificado nesta análise; não emitir respostas/encerramentos como impacto.

## Provas previstas

Reprodução isolada na base; fases recusadas individualmente, falha transitória, payload inválido, fonte ausente, cobertura horária/DST/duplicata/limites, zero explícito, autorização e redação de mensagens/tokens/PII. Jobs/agendas/auditoria/health e MCP decorado, persistência e SDK Core. Instalação limpa, atualização da base e mínimo WP6.4/PHP8.1.2; regressões do orçamento e do 26. Sem fornecedor real/e-mail nos laboratórios. Aceite com credenciais de produção pertence à frota e não será substituído por fixtures.
