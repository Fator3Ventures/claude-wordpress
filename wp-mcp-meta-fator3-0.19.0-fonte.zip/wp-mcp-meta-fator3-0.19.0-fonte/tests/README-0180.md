# Provas Meta 0.18.0

Controlador tests/site/isolated0180-controller.php fechado por SHA-256, restrito ao Site-Teste; diretório/prefixo MySQL privados, HTTP e e-mail comerciais bloqueados. Build: F3_SOCIAL_PHP=<php> python3 build/build.py. Bundle: tools/build-isolated0180-probe.py --baseline <runtime 0.17.0> --candidate <runtime 0.18.0> --output <controle temporário>.

diagnostics0180.php reproduz a ambiguidade na base e valida marcação na candidata em fluxo de falha/sucesso e matriz de legado, parcial e cronologia. Upgrade compara registros/ciphertext/histórico/opções; smoke confere manifesto/docs/REST e assinante. budget0180 e review071 verificam orçamento/filas/quarentena. integration0180 verifica convivência e hashes Core/MCP recebidos; Core Ads usa seu teste original com adaptações documentadas. Rodar instalação própria também em WP6.4/PHP8.1.2 exato. Consultar evidence e relatório para execuções efetivas. Testes históricos não são automaticamente reexecutados.
