# Testes 0.19.0

Site-Teste com WordPress real, tabelas/pasta/salts próprios por laboratório. HTTP Meta e e-mail interceptados; funções de rede externas desabilitadas no processo CLI. Controller fechado e preso ao hash do bundle, host exato e administrador; removido ao final.

dataset0190.php reproduz caminho defeituoso na0.18.0; na candidata testa parciais independentes, diagnóstico sanitizado, permissões, vínculo obrigatório, paginação, cobertura por hora/evento, DST23/25h, overflow, revisão concorrente, MCP real e Core/SDK. Não comprova causa histórica ou aceite externo dos tokens de produção. IDs de fixtures únicos por execução.

Regressões herdadas mantêm as asserções; nomes/versionamentos adaptados. coremonitor0190 adapta a resposta de vínculo para adspixels e stats para24 buckets event, conforme nova consulta, sem reduzir asserções do consumidor. Integração exige hashes recebidos de Core1.66.0/Google0.25.1 e pin MCP0.38.0; LinkedIn0.14.0/Pipedrive0.5.0 conferidos no ambiente. Atualização direta parte de0.18.0. Piso: WordPress6.4 e PHP8.1.2 Ubuntu oficial com hashes fixados. evidence contém resultados completos; tentativas intermediárias são diferenciadas do resultado final.

Matriz adicional: Google0.26.0 copiado do Site-Teste e preso ao digest observado; guia0.26.0 arquivado nos inputs. Google0.25.1 recebido testado em laboratório próprio. Execute dataset0190 logo após setup/integrate: a inspeção de auditoria da fixture limita-se a100 registros; misturá-la com muitas suítes anteriores pode produzir falha de inspeção da fixture. Duas tentativas contaminadas estão preservadas em evidence e não entram na matriz final. Instalações compartilhadas permanecem em Google0.26.0.
