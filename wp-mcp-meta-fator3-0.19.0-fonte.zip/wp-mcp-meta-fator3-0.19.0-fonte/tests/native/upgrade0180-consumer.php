<?php
function upgrade0180_consumer(){return Fator3\Meta\MonitoringReader::register_consumer('qa-upgrade0180','1.0.0',Fator3\Meta\MonitoringReader::CONTRACT,static fn()=>['ready'=>true,'connection_id'=>'upgrade-monitor0180','account_id'=>'160','revision'=>1,'reports'=>['ads_activity','dataset_quality'],'dataset_ids'=>['161']]);}
