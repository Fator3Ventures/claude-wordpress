<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require __DIR__.'/seed-connection090.php';
use Fator3\Meta as M;
wp_set_current_user(1);$checks=[];$http=0;$mail=0;$mode='fail';$id='diagnostics0180';$sid='diagnostics0180';$base=M\Config::VERSION==='0.17.0';
function dck(string $name,bool $ok):void{global $checks;$checks[]=['name'=>$name,'passed'=>$ok];if(!$ok)throw new RuntimeException($name);}
function dset(string $bucket,string $key,callable $fn):array{$r=M\Store::get($bucket,$key);$v=$r['value'];$fn($v);return M\Store::put($bucket,$key,$v,$r['revision']);}
function dreads(string $sid):array{$list=M\Api::dispatch('list-schedules');$health=M\Api::dispatch('health');dck('public reads succeed',$list['success']&&$health['success']);$l=array_values(array_filter($list['data']['schedules'],static fn($v)=>$v['schedule_id']===$sid));$h=array_values(array_filter($health['data']['schedules'],static fn($v)=>$v['schedule_id']===$sid));$dl=array_intersect_key($l[0]??[],M\CollectionState::scheduleDiagnostic([]));$dh=array_intersect_key($h[0]??[],M\CollectionState::scheduleDiagnostic([]));ksort($dl);ksort($dh);dck('same error state through health and list',count($l)===1&&count($h)===1&&$dl===$dh);return [$l[0],$health];}
$hf=static function()use(&$http,&$mode){$http++;return ['headers'=>[],'response'=>['code'=>$mode==='fail'?503:200],'body'=>$mode==='fail'?'{}':'{"id":"180","name":"Fixture","username":"qa0180","followers_count":2}'];};
$mf=static function()use(&$mail){$mail++;return true;};add_filter('pre_http_request',$hf,1);add_filter('pre_wp_mail',$mf,1);
try{
 lab_seed_connection090(['connection_id'=>$id,'expected_revision'=>0,'token'=>'synthetic-diagnostics0180','assets'=>['instagram'=>['180']],'users'=>[1]]);
 $q=['connection_id'=>$id,'channel'=>'instagram','account_id'=>'180','report'=>'profile'];M\Schedules::save(['schedule_id'=>$sid,'query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()-10]);M\Schedules::tick();$job=M\Store::get('schedule',$sid)['value']['last_job'];M\Jobs::run($job,true);
 $failed=M\Store::get('schedule',$sid);$oldError=$failed['value']['last_error'];dck('real job failure recorded',($oldError['code']??null)==='upstream_error'&&$failed['value']['last_run_status']==='failed');
 $mode='success';dset('job',$job,static function(&$v){$v['next_at']=time()-1;});M\Jobs::run($job,true);$complete=M\Store::get('schedule',$sid);
 dck('real retry completes and retains measured history',$complete['value']['last_run_status']==='complete'&&$complete['value']['last_code']===null&&$complete['value']['last_error']===$oldError);
 if($base){$list=M\Api::dispatch('list-schedules')['data']['schedules'];$row=array_values(array_filter($list,static fn($x)=>$x['schedule_id']===$sid))[0];dck('base reproduces unmarked old error after success',!array_key_exists('last_error_superseded',$row)&&$row['last_error']===$oldError);}
 else{
  [$row,$health]=dreads($sid);dck('completed retry is explicitly superseded',$row['last_error_state']==='superseded'&&$row['last_error_superseded']&&$row['last_error_at']===$oldError['observed_at']);dck('retained diagnostic creates no active incident',!array_filter($health['data']['issues'],static fn($v)=>($v['schedule_id']??null)===$sid));
  if(class_exists('Fator3\\McpFiles\\SafeOutput')){$wire=wp_get_ability('meta/list-schedules')->execute([]);$wh=wp_get_ability('meta/health')->execute([]);$wl=array_values(array_filter($wire['data']['schedules']??[],static fn($x)=>$x['schedule_id']===$sid));$ws=array_values(array_filter($wh['data']['schedules']??[],static fn($x)=>$x['schedule_id']===$sid));dck('decorated MCP ability preserves superseded list diagnostic',($wl[0]['last_error_superseded']??false)===true&&$wl[0]['last_error_at']===$oldError['observed_at']);dck('decorated MCP health preserves historical error state',($ws[0]['last_error_state']??null)==='superseded'&&$ws[0]['last_error']===$oldError);}
  $cases=[
   ['legacy budget complete',['last_run_status'=>'complete','last_code'=>null,'last_error'=>['code'=>'budget_exhausted','observed_at'=>100],'last_success_at'=>200],'superseded'],
   ['complete empty without useful timestamp',['last_run_status'=>'complete','last_code'=>null,'last_error'=>['code'=>'upstream_error','observed_at'=>100],'last_success_at'=>null],'superseded'],
   ['complete without error timestamp',['last_run_status'=>'complete','last_code'=>null,'last_error'=>['code'=>'budget_exhausted'],'last_success_at'=>null],'superseded'],
   ['failed despite older error time',['last_run_status'=>'failed','last_code'=>'budget_exhausted','last_error'=>['code'=>'budget_exhausted','observed_at'=>100],'last_success_at'=>200],'current'],
   ['partial useful data never implies recovery',['last_run_status'=>'partial','last_code'=>'fields_unavailable','last_error'=>['code'=>'fields_unavailable','observed_at'=>100],'last_success_at'=>200],'current'],
   ['complete with current code fails conservatively',['last_run_status'=>'complete','last_code'=>'not_authorized','last_error'=>['code'=>'not_authorized','observed_at'=>100],'last_success_at'=>200],'current'],
   ['queued after newer useful success',['last_run_status'=>'queued','last_code'=>null,'last_error'=>['code'=>'upstream_error','observed_at'=>100],'last_success_at'=>200],'superseded'],
   ['queued same second cannot establish order',['last_run_status'=>'queued','last_code'=>null,'last_error'=>['code'=>'upstream_error','observed_at'=>200],'last_success_at'=>200],'unknown'],
   ['queued missing date stays unknown',['last_run_status'=>'queued','last_code'=>null,'last_error'=>['code'=>'upstream_error'],'last_success_at'=>200],'unknown'],
   ['queued future error stays unknown',['last_run_status'=>'queued','last_code'=>null,'last_error'=>['code'=>'upstream_error','observed_at'=>300],'last_success_at'=>200],'unknown'],
   ['no error is explicit',['last_run_status'=>'complete','last_code'=>null,'last_error'=>null,'last_success_at'=>200],'none'],
   ['disabled legacy remains visible',['enabled'=>false,'last_run_status'=>'complete','last_code'=>null,'last_error'=>['code'=>'budget_exhausted','observed_at'=>100],'last_success_at'=>200],'superseded']
  ];
  foreach($cases as [$name,$change,$state]){
   dset('schedule',$sid,static function(&$v)use($complete,$change){$v=array_replace($complete['value'],$change);});$before=M\Store::get('schedule',$sid);$hc=$http;$mc=$mail;[$row,$h]=dreads($sid);
   dck($name,$row['last_error_state']===$state&&$row['last_error_superseded']===($state==='superseded')&&$row['last_error']===($change['last_error']??null)&&$row['last_error_at']===($change['last_error']['observed_at']??null));
   dck('reading preserves bytes and no HTTP or mail: '.$name,M\Store::get('schedule',$sid)===$before&&$http===$hc&&$mail===$mc);
  }
  // A later real failure supersedes a previously recovered execution.
  dset('schedule',$sid,static function(&$v)use($complete){$v=$complete['value'];$v['next_at']=time()-20;});M\Schedules::tick();$mode='fail';$job=M\Store::get('schedule',$sid)['value']['last_job'];M\Jobs::run($job,true);[$row,$h]=dreads($sid);dck('new real failure is current after recovery',$row['last_error_state']==='current'&&!$row['last_error_superseded']&&$row['last_run_status']==='failed');
  $u=username_exists('diagnostics0180sub')?:wp_create_user('diagnostics0180sub',wp_generate_password(),'qa0180@example.invalid');(new WP_User($u))->set_role('subscriber');wp_set_current_user($u);dck('subscriber cannot read either diagnostic',!M\Api::dispatch('list-schedules')['success']&&!M\Api::dispatch('health')['success']);wp_set_current_user(1);
 }
 $out=['version'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>0,'synthetic_http_calls'=>$http,'intercepted_mail_calls'=>$mail,'real_provider_calls'=>0,'baseline_reproduction'=>$base];
}catch(Throwable $e){$out=['checks'=>$checks,'total'=>count($checks),'failed'=>1,'exception'=>get_class($e),'message'=>$e->getMessage()];}
finally{wp_set_current_user(1);remove_filter('pre_http_request',$hf,1);remove_filter('pre_wp_mail',$mf,1);$s=M\Store::get('schedule',$sid);if($s)M\Store::remove('schedule',$sid,$s['revision']);foreach(M\Store::list('job',0,100) as $j)if(($j['value']['query']['connection_id']??'')===$id)M\Store::remove('job',$j['key'],$j['revision']);$c=M\Store::get('connection',$id);if($c)M\Store::remove('connection',$id,$c['revision']);}
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/diagnostics0180.json',wp_json_encode($out));echo wp_json_encode($out);if($out['failed'])exit(1);
