<?php
function upgrade0190_consumer(){return Fator3\Meta\MonitoringReader::register_consumer('qa-upgrade0190','1.0.0',Fator3\Meta\MonitoringReader::CONTRACT,static fn()=>['ready'=>true,'connection_id'=>'upgrade-monitor0190','account_id'=>'160','revision'=>1,'reports'=>['ads_activity','dataset_quality'],'dataset_ids'=>['161']]);}
