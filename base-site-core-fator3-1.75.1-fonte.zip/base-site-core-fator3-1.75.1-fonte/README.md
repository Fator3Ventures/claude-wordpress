# Fator3 Site Core 1.75.1

O runtime está em `work/plugin/base-site-core-fator3/`. Requer WordPress 7.1.4 ou superior em instalação única, PHP de 64 bits 8.3 ou superior e as extensões usadas pelo Core. O índice instalado fica em `docs/DOCUMENTACAO.md`. O guia desta rodada é `docs/RELEASE-1.75.1.md`.

## Reprodução

Na raiz extraída, execute com Python 3.12 e compare os hashes com a seção 8 do relatório externo.

```bash
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.75.1-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.75.1-fonte.zip
```

Use o nome de raiz recebido para reproduzir o fonte. O empacotador verifica os arquivos do runtime e da base histórica antes de criar o ZIP e verificar os CRCs. Os testes escrevem novas evidências e devem ser executados numa cópia de trabalho.

| Caminho | Finalidade |
|---|---|
| `reference/` e `PLANO-1.75.1.md` | Referências centrais, pedidos e planejamento da rodada |
| `history/1.74.0-runtime/` | Árvore e hashes da base de migração da frota |
| `tests/README.md` | Dependências, reprodução e limites das provas |
| `evidence/1750/` | Matriz de instalação, migração, testes específicos e Site-Teste. A pasta identifica a rodada 1.75. A subpasta `candidato-1.75.0` guarda as provas anteriores ao patch |
| `impactos/` | Parecer técnico e patch experimental para o implantador-base 2.18.0 |
| `RELATORIO-PRE-FECHAMENTO.md` | Versão do relatório congelada antes de fechar o ZIP |
| `source-manifest.json` | Inventário do fonte, em bytes e SHA-256 por arquivo |

Os outros scripts com numeração antiga documentam ensaios de rodadas anteriores. Para esta versão, use os comandos de `tests/README.md`.
