# Plano da próxima release — F3 Base Core 1.17.0

Data: 29/09/2026. Revisão do plano: 2, após análise de “Pendências do site-core após a 1.15.0(1).md”. Estado: planejamento, sem implementação ou implantação nesta etapa.

## 1. Objetivo e limites

Transformar Medição em uma área útil para analisar acessos, visitantes observados, conteúdo orgânico e comportamento, com atenção especial à descoberta por IA. As perguntas principais serão: quais páginas e artigos atraem visitas, quais apresentam sinais de consumo, como as sessões entram e percorrem o site, quais conteúdos os agentes de IA requisitam em HTML ou Markdown, quais IAs encaminham visitantes e quais citações/recomendações foram efetivamente observadas.

A referência é a 1.16.0, revisão 2. O relatório recebido informa que esse mesmo ZIP está nos 14 sites; isso é evidência fornecida pela operação, não nova inspeção desta análise. Base para a implementação: instalação nova ou atualização da 1.16.0 concluída, com retomada na própria versão. Não implementar compatibilidade anterior ou downgrade. Tema e implantador permanecem fora do Core. Não testar korvena.net.br; a validação nesse site continua com o dono. Nenhum aceite depende de solicitar alterações à DreamHost.

Todos os pedidos diretos de Medição entram no escopo. A revisão incorpora também as correções pertinentes do relatório, com disposição individual na seção 14. A prioridade de produto passa a ser conteúdo, navegação e IA, apoiados em captura confiável e publicação funcional; conversões existentes continuam acessíveis como resultado secundário. Não abrir uma nova frente de CRM nesta release.

## 2. Diagnóstico da base conferida

Foram lidos o relatório e o manifesto atuais da entrega, e conferidos os hashes de 17 arquivos relevantes da fonte local contra o manifesto. Não houve inspeção do estado instalado em produção.

| Solicitação | Situação na 1.16.0 r2 | Consequência para a 1.17.0 |
|---|---|---|
| Identificar conteúdos requisitados por robôs | Parcialmente atendida. Agentes → Conteúdo já agrupa agente, classe e caminho. | Evoluir para título, identidade do conteúdo, tipo editorial, representação e detalhe navegável. |
| Separar páginas e artigos | Ausente na Medição atual. As visões usam caminhos, sem o recorte editorial solicitado. | Criar sub-abas explícitas em Conteúdo, com `page` e `post` tratados separadamente. |
| Incluir o Markdown do próprio plugin | A rota é servida, mas falta o vínculo analítico com o conteúdo HTML. | Unificar identidade, manter formato e URL requisitada distintos. |
| Recuperar filtro por sessão | Regressão de interface confirmada. A consulta `eventos-ler` aceita `sessao`; a interface atual não encaminha esse filtro. | Recuperar filtro, links e exportação; acrescentar explorador de sessões com jornada. |
| Tornar horários legíveis | A tabela genérica imprime valores sem formatador de coluna; eventos podem mostrar epoch e agentes exibem horas UTC. | Formatação por tipo e uso consistente do fuso do WordPress. |
| Melhorar UX e Design | A interface usa tabelas genéricas, filtros técnicos livres e análises pouco orientadas a perguntas. | Reorganizar navegação, hierarquia, tabelas, filtros e estados de cobertura. |

Achados que precisam entrar na implementação:

- `F3Base_Modulo_Llms_Markdown::url_do_item()` gera `/caminho/index.md`, URLs com extensão seguidas de `.md` e, em permalinks por query, `?f3base_markdown=ID`. O parser de logs atualmente descarta a query, exceto `rest_route`; a variante por ID pode se misturar com a home. É uma lacuna de captura, além de apresentação.
- `.md` não está na lista de extensões estáticas excluídas. Os caminhos amigáveis permanecem disponíveis no agregado diário, mas não há comprovação de que todo `.md` pertence a um artigo do Core.
- O mapa atual de caminhos públicos lê até 1.000 posts e não mantém a identidade editorial. Há também teto de caminhos por dia/agente que pode retirar o detalhe de URL. Esses limites precisam aparecer como cobertura, nunca como ausência de interesse.
- O agregado horário atual não guarda caminho e recusa filtros de caminho/método/status. O detalhe horário por conteúdo exige nova granularidade; não pode ser reconstruído dos totais antigos.
- `f3base_eventos` guarda sessão, caminho, instante, deslocamento em milissegundos e âncora. `f3base_analise` já possui sessão, navegação, atribuição, instante e recebimento. O primeiro conjunto não tem a mesma identificação de navegação, necessária para separar carregamentos/abas sem adivinhar.
- A atual Visão geral privilegia contatos e atendimento. Aquisição privilegia IDs de anúncios. Esses enfoques não atendem ao objetivo principal esclarecido pelo dono.

### 2.1 Leitura crítica do relatório recebido

A conferência de 29/09/2026 no início do anexo prevalece sobre as seções posteriores que ainda descrevem a 1.15.0. O resumo antigo de “22 pedidos abertos” não representa a situação após os testes da 1.16.0. Itens já atendidos não serão reimplementados; permanecem como regressões a proteger.

Os resultados de produção e cenários C1–C7 são atribuídos ao relatório. Nesta revisão foram conferidos os trechos relevantes da fonte e a igualdade de dez arquivos centrais com o ZIP de referência, sem repetir os testes em produção. Constatações:

- **N3 confirmado no código:** a cobertura recua ao primeiro item incompleto e impede promover a geração inteira. O conversor trata blocos dinâmicos sem representação como erro; a combinação explica o travamento relatado.
- **N1/N2/N5 confirmados no código:** P00 percorre inclusive options derivadas; a migração não materializa todas as novas chaves; `dados/mudancas.json` termina na 1.15.0; ofertas não constam nas tarefas do executor; o contexto de redirects inclui a geração global de cache.
- **N4, causa refinada:** `restaurar()` já aplica `chmod` com o modo gravado. O problema anterior à publicação é que a cópia privada recebe 0600 e `confirmar_reserva()` chama `capturar()` novamente, sobrescrevendo `modo` com a permissão da reserva. É uma causa compatível com o resultado observado; validar o ciclo completo antes de encerrar o defeito. Corrigir apenas o `link()` não resolve um modo original já perdido.
- **Origem IA confirmada:** `F3Base_Atribuicao::normalizar()` reconhece `utm_source=chatgpt`, mas não `chatgpt.com` nesse caminho. O histórico que conserva a UTM pode ser reclassificado com procedência, sem inventar dados de leads que nunca foram capturados.
- **Cobertura horária:** existe publicação no código. O bloqueio está nas condições de elegibilidade/dependências entre fontes e dias legados; tabela final vazia não significa ausência de implementação. Precisamos reproduzir o calendário/rotação informado com fixtures.

Não transformar inferências do relatório em fatos individuais: concentração de sessões nos dias de PageSpeed é indício de contaminação; sessão de uma página não prova automação. Core de 24–29/09 e GA4 de 28 dias não são períodos comparáveis. Requisições a arquivos sensíveis são indício de varredura; não comprovam sozinhas User-Agent falso. Mesmo identidade de rede verificada não comprova leitura, treinamento ou citação do conteúdo.

### 2.2 Prioridades da entrega

1. **P0 — integridade:** destravar LLMS (73), preservar/restaurar robots corretamente (74), distinguir automação (76), retirar tráfego operacional dos indicadores editoriais (81) e resolver a publicação/cobertura dos logs (86).
2. **P1 — análise útil:** conteúdo e sessões, canais e origem IA (77–80), verificação de rede de robôs (82), visão IA × conteúdo (83), alertas de bloqueio (84), Search Console (85), agregados históricos (87) e nova Visão geral (88).
3. **P1 — operação do pacote:** P00/defaults (71), histórico de mudanças (72), ofertas/redirects no executor (75), navegação (42), consentimento (45), diagnóstico TTL (37) e textos (61/66).

São etapas internas de uma entrega única, sem releases intermediárias. O bloqueio LLMS precede os relatórios de Markdown: medir bem um conteúdo cuja publicação está travada não atende ao objetivo.

## 3. Organização e navegação

| Área | Experiência principal | Pergunta atendida |
|---|---|---|
| Visão geral | Visitas observadas, entradas por origem, conteúdos mais acessados, sinais de consumo e cobertura. | O conteúdo está atraindo visitas e gerando continuidade? |
| Conteúdo | Sub-abas Páginas, Artigos e Outros recursos. Detalhe individual com navegação, consumo e IA. | Qual conteúdo funciona e para quem? |
| Sessões | Lista pesquisável e jornada de uma sessão, com carregamentos e ações. | Como esta visita entrou e se comportou? |
| Aquisição | Canais por sessão e subvisão Search Console, com fonte e calendário próprios. | De onde vêm as visitas e como o conteúdo aparece na busca? |
| IA e robôs | Sub-abas Acessos ao conteúdo, Visitantes de IA e Referências observadas. Preserva os buscadores convencionais e demais robôs. | Que conteúdo as IAs acessam, que visitas encaminham e onde houve uma referência observada? |
| Conversão | Relatórios existentes de cliques, formulários e resultados associados ao conteúdo. | Que ações vieram depois do contato com o conteúdo? |
| Técnico | Qualidade, erros, fricção, logs, retenção e estado da coleta. | Quanto podemos confiar no recorte e o que está falhando? |

Sessões substitui a entrada principal Comportamento. As análises atuais de seções, rolagem e tempo ativo passam ao detalhe de conteúdo e às subvisões de Sessões; erros e fricção permanecem em Técnico. Nenhuma análise existente deve desaparecer nessa reorganização.

Páginas corresponde a `post_type=page`; Artigos, a `post_type=post`. Categorias, tags, arquivos, resultados de busca, índice do blog, tipos personalizados e rotas sem vínculo ficam em Outros recursos, identificados pelo tipo. A home estática pertence à página configurada. Não deduzir tipo pela palavra `/blog/` na URL, nem atribuir o índice do blog a um artigo individual.

Fluxos essenciais: Visão geral → Artigo → Sessões que o visitaram → Jornada; Agente → Conteúdos → Artigo e representação; Artigo → Origens de entrada → Sessões daquele recorte. Ao abrir uma sessão a partir de um artigo, mostrar a jornada completa disponível e destacar o artigo selecionado; não esconder as outras páginas.

## 4. Relatórios para validar conteúdo orgânico

### 4.1 Visão geral orientada a conteúdo

Exibir no máximo cinco indicadores principais: sessões observadas, visitantes observados quando disponíveis, visualizações, entradas classificadas como busca orgânica e conteúdos acessados por agentes de IA. A origem, unidade, cobertura e período de cada indicador devem estar explícitos; não somar requisições de logs com sessões do navegador.

Complementar com evolução diária, principais páginas de entrada, principais artigos e origem das sessões. Um bloco de destaque para IA reúne conteúdos requisitados, sessões encaminhadas e referências observadas, em medidas separadas e com links para os detalhes. Cliques e envios aparecem como resultado complementar. Retirar “aguardando resposta agora” do centro dessa tela, mantendo-o em Conversão/Atendimento.

### 4.2 Listas de Páginas e Artigos

Colunas iniciais: título e URL, visualizações observadas, sessões observadas, entradas orgânicas, tempo ativo estimado quando disponível, requisições de IA separadas por HTML/Markdown. Oferecer colunas adicionais para visitantes observados, rolagem, próxima página, última página observada, cliques e envios. Evitar colocar todas as métricas numa tabela horizontal única.

Ordenar inicialmente por sessões observadas e permitir ordenar por qualquer métrica apresentada como ordenável. Disponibilizar recortes salvos na própria interface, como “Entradas por busca orgânica”, “Conteúdos acessados por IA” e “Conteúdos sem observações no período”. Este último usa o inventário publicado com junção à medição; ausência de observações só recebe zero quando a fonte e a cobertura permitem essa leitura.

No detalhe individual, apresentar:

1. **Alcance observado:** entradas, visualizações, sessões e origens.
2. **Consumo observado:** tempo ativo, profundidade e seções vistas, com denominador e amostra.
3. **Continuidade:** páginas anteriores e seguintes comprovadas no percurso disponível; lista de sessões para inspeção.
4. **Ações:** cliques, início/aceite de formulário e contatos pareados, preservando os contratos atuais.
5. **IA:** famílias que requisitaram o conteúdo, formatos, método, status, primeiro/último acesso e frequência disponível; sessões encaminhadas por IA e citações/recomendações registradas com evidência.

### 4.3 Contrato de métricas

| Medida | Regra planejada |
|---|---|
| Sessões observadas | Distintos IDs de sessão elegíveis no recorte. Não equivalem a pessoas. |
| Visitantes observados | Distintos pseudônimos disponíveis e permitidos. Sem unir dispositivos ou navegadores. |
| Visualizações | Uma por carregamento identificado; deduplicar fontes que descrevem a mesma visualização. Recarregar a página produz nova visualização. |
| Entrada | Primeira página observada da sessão disponível. Entrada real só é afirmada quando o início da sessão está coberto. |
| Consumo | Sinais de tempo ativo, rolagem e seções vistas. Não nomear como leitura comprovada nem gerar nota arbitrária de qualidade. |
| Tempo ativo | Somar intervalos elegíveis por navegação, usando a coleta de bloco predominante. Ocultação/inatividade e limites da instrumentação devem ser respeitados. |
| Rolagem | Maior marco observado por navegação; percentuais com amostra elegível indicada. Página curta não implica leitura completa. |
| Continuidade | Transição observada entre carregamentos relacionados. Eventos simultâneos em abas diferentes não estabelecem causalidade. |
| Última página | Última página observada no recorte. Não afirmar abandono definitivo ou saída real apenas por ausência de novo evento. |
| Requisições de IA | Contagens dos logs classificadas por família declarada. GET, HEAD, 304, erros e bloqueios permanecem distinguíveis. |

Não calcular um percentual “humanos versus IA” usando sessões JavaScript de um lado e requisições HTTP do outro. As unidades e a cobertura diferem. Comparar desempenho editorial por origens e períodos informa associações; não comprova que publicar ou alterar um artigo causou uma conversão ou crescimento.

Tempo ativo continua respeitando a configuração existente, atualmente desligada por padrão. Mostrar uma indicação contextual quando a métrica estiver desligada e um acesso à configuração. Não ativar coleta adicional silenciosamente na atualização.

### 4.4 Origem orgânica e referências de IA

Criar classificação específica para aquisição de sessões, independente de `plataforma` dos anúncios. Reutilizar a referência externa reduzida ao host e os parâmetros permitidos já capturados. Categorias: busca orgânica, referência de IA, social orgânico declarado/identificado, referência de outro site, e-mail identificado, campanha paga identificada, campanha de meio não classificado e direto/origem não identificada. E-mail exige evidência de meio/campanha, sem dedução pela ausência de referrer.

Registrar a regra e a evidência usada. Meio pago explícito ou identificador cuja finalidade paga seja comprovada prevalece sobre a classificação genérica do domínio referenciador. Nem todo parâmetro de clique comprova anúncio: `fbclid`, isoladamente, não transforma uma visita em paga. Ausência de UTM, referência ou sinal publicitário permanece origem não identificada; publicidade sem sinais observáveis pode continuar nessa categoria.

Busca orgânica é uma classificação baseada nos sinais disponíveis, não certificação de ausência de mídia. Conflitos entre parâmetros devem ficar visíveis. Tabela de domínios/assinaturas para busca e referências de IA será versionada e validada contra documentação oficial durante a implementação; domínios desconhecidos não serão adivinhados.

Preservar uma fotografia da origem no início da sessão. Navegar internamente não deve apagar a origem de entrada; campanhas encontradas depois permanecem separadas, sem reescrever o início. Não confundir essa origem com primeiro/último toque comercial de um lead. Na base, usar a primeira observação válida retida e marcar “origem inicial não comprovada” quando necessário.

Referências de ChatGPT, Claude, Gemini, Perplexity e Copilot recebidas pelo navegador serão tratadas como origem da visita quando observáveis. Manter catálogo extensível, versionado, com aliases explicitamente aceitos; não classificar todo `bing.com` como Copilot nem todo Google como Gemini. Requisições dos robôs dessas famílias terão o relatório próprio de agentes. Ausência de referência enviada pela plataforma não será preenchida por suposição.

Tratar os parâmetros reconhecidos e o host referenciador como evidências distintas. A OpenAI documenta `utm_source=chatgpt.com` nos links de encaminhamento; reconhecer esse sinal mesmo sem referrer, mantendo a classificação declarada, sem tratá-lo como prova inviolável [F1]. Validar hosts por domínio exato/subdomínios permitidos, nunca por substring; `chatgpt.com.exemplo.invalid` não é ChatGPT. Não registrar a URL completa da conversa. Visitas pagas identificadas em plataformas de IA permanecem separadas das referências editoriais, reutilizando os sinais publicitários existentes.

Reclassificação histórica usa somente UTM/referrer ainda retidos, registra versão e se a origem é reconstruída. Não reescrever toques comerciais, reemitir eventos externos ou preencher leads antigos com origem inferida por horário. Consulta por canal/página de entrada deve alcançar rolagem, seções, tempo disponível e jornadas pelo mesmo vínculo de sessão, com qualidade explícita para dados antigos sem o vínculo necessário.

### 4.5 Qualidade de audiência e automação que executa JavaScript — 76/81

Acrescentar uma dimensão de automação independente de `classe_trafego` de teste: não identificada, declarada e provável, com motivo e versão da regra. Cookie/cabeçalho de teste mantém o contrato atual; Lighthouse/PageSpeed identificado por assinatura conhecida, sondas próprias e monitores declarados recebem finalidade técnica. HeadlessChrome e sinais como `navigator.webdriver` constituem evidência de automação provável, não identidade do operador nem prova de fraude.

Capturar somente sinais reduzidos necessários no envelope existente e validar no servidor. User-Agent bruto pode ser examinado transitoriamente na requisição, sem persistência; marca por cliente não concede privilégio. Ausência de sinal permanece “não identificada”, nunca “humano verificado”. O contexto deve funcionar em HTML servido por cache, sem personalizar o cache por visitante.

O recorte padrão de audiência exclui testes marcados, automação declarada e provável; mostra a quantidade excluída, motivos e acesso aos segmentos técnicos. Não apagar silenciosamente o histórico nem descartar leads por heurística. Uma marca provável não bloqueia formulário, envio comercial ou navegação. Web Vitals de laboratório permanecem separados dos de campo em Técnico; o tratamento de telemetria não deve manipular a execução da página para melhorar a nota do Lighthouse.

Histórico sem evidência individual não será reclassificado em massa só pela data, duração ou uma página vista. Permitir anotar períodos de teste conhecidos e aplicar exclusão analítica explícita/reversível, conservando o número original e o motivo. O padrão continua incluindo registros históricos não identificados com aviso de qualidade; não afirmar que o filtro futuro limpou automaticamente os dias 24–25/09.

Nos relatórios de conteúdo/IA, incluir apenas caminhos editoriais e descoberta elegíveis. Rotas MCP, admin, APIs operacionais, assets e varreduras ficam fora desses totais por padrão, inclusive quando o User-Agent declara Claude ou ChatGPT. Classificar o subtipo operacional antes de descartar o caminho; guardar apenas totais técnicos diários. No histórico já reduzido a `classe_caminho=excluido`, excluir a classe do indicador editorial sem prometer reconstruir quais acessos eram MCP.

### 4.6 Search Console por página — 85

Incorporar cliques, impressões, CTR e posição média à análise editorial, como fonte externa identificada. A fonte preferencial é o plugin MCP Google já usado pela operação, mediante capacidade disponível e autorização; o Core também aceitará importação autenticada de uma fotografia normalizada obtida pelo agente. Não duplicar credenciais/OAuth no Core e não exigir alteração do outro plugin como condição para usar o contrato de importação.

O contrato de entrada exige propriedade autorizada, URL canônica, período/dia, tipo de pesquisa, dimensões, métricas, estado final/parcial, instante de extração, origem, filtros e cobertura. Importações substituem a mesma contribuição de forma idempotente; as mesmas linhas não podem ser somadas ao trocar de agente. Validar a propriedade e o host contra o site e impedir fusão entre propriedades sobrepostas. Dados ausentes ou conector indisponível aparecem como não disponíveis, mantendo a análise local utilizável.

Na primeira entrega, usar `page/date` para desempenho editorial e totais da propriedade em consulta independente. Não juntar impressões/cliques a sessões individuais. CTR agregado = soma de cliques / soma de impressões no mesmo universo; posição média é ponderada pelas impressões das linhas comparáveis. Não somar CTR nem tirar média simples de posições. Dados por página não substituem totais da propriedade.

A API tem limites de linhas e usa dias no calendário do Pacífico; preservar esse calendário e a cobertura na apresentação [F7]. Não converter um agregado diário pronto para o fuso do WordPress como se fossem eventos individuais. Comparação com visitas do Core é contextual, com calendários e definições visíveis. Consultas de busca detalhadas, novas credenciais e expansão do plugin Google ficam fora desta release. A integração não fornece prova individual de que AI Overviews ou AI Mode encaminharam determinada sessão.

## 5. Identidade editorial e representação HTML/Markdown

### 5.1 Resolvedor comum

Implementar um catálogo de conteúdo e rotas, compartilhado pela análise, pelos relatórios de logs e pela publicação Markdown. Identidade principal: ID do post no site; guardar tipo editorial e procedência da resolução. Preservar separadamente o caminho requisitado, a URL canônica e a representação (`html`, `markdown_core`, `descoberta`, `outro`, `nao_resolvida`).

Construir/atualizar o catálogo em lotes, com índices e retomada, em eventos de publicação, exclusão, mudança de slug/permalink e seleção LLMS. Substituir o limite silencioso de 1.000 itens por paginação com cobertura declarada. Não consultar WordPress ou fazer HTTP por linha de log; não renderizar páginas ao abrir um relatório.

Guardar vigência/proveniência de rotas conhecidas. Troca de slug mantém a associação histórica comprovada, sem deslocar acessos antigos para o conteúdo que reutilizou o endereço. Na importação histórica sem inventário da época, uma resolução pelo catálogo atual recebe essa qualidade explícita. Ambiguidade permanece não resolvida. Títulos atuais podem mudar; indicar quando o rótulo é o atual e a identidade pertence a uma observação histórica.

### 5.2 Markdown

Resolver a representação a partir das rotas realmente publicadas pelo módulo LLMS, incluindo `/artigo/index.md`, `/pagina.html.md` e `?f3base_markdown=ID`. Extrair exclusivamente os identificadores estruturais permitidos da query, validá-los contra o catálogo e descartá-la; não persistir parâmetros arbitrários, busca livre, tokens ou dados pessoais. Aplicar a mesma disciplina a `?p=ID` e `?page_id=ID`.

Não associar uma URL a um artigo apenas por remover `.md`. Arquivos físicos de outro emissor, URLs desconhecidas, conteúdo fora da seleção e respostas de erro devem manter procedência e estado corretos. O vínculo de uma rota com o conteúdo não prova que a resposta serviu seu corpo: 503 de Markdown é indisponibilidade, HEAD não é download de conteúdo, e 304 é revalidação.

Agrupar HTML e Markdown sob o mesmo item editorial, mantendo contagens por representação. Um GET HTML e um GET Markdown somam duas requisições. O número de conteúdos distintos nesse exemplo é um. Não fundir as duas requisições como se houvesse deduplicação de uma visita humana.

`llms.txt`, `llms-full.txt`, robots, sitemaps e feeds ficam em Descoberta/Outros recursos. Acesso a `llms-full.txt` não será distribuído como uma leitura de cada artigo que ele contém.

## 6. IA e robôs: acessos, visitantes e referências

### 6.1 Acessos ao conteúdo

Evoluir a visão existente, preservando famílias OpenAI, Claude, Google/Gemini e demais assinaturas disponíveis, com nomes legíveis, finalidade declarada e categoria. Acrescentar o recorte `busca-ia`, distinto de busca convencional, e famílias/aliases comprovados pelo catálogo oficial. Separar a declaração do User-Agent do resultado da verificação de rede descrita em 6.5.

Filtros tipados: período, família/categoria, página/artigo/outro, conteúdo, representação, método e status. Famílias existentes aparecem em combobox; busca de conteúdo usa título/URL com autocompletar. Oferecer duas entradas equivalentes: agente → conteúdos e conteúdo → agentes.

Por conteúdo/agente: requisições, GET com resposta 2xx, HEAD, revalidações 304, bloqueios 403/429, outros erros, primeiro/último acesso e dias com acesso. Não transformar 404 em bloqueio. Nomear a medida como acesso/requisição; não prometer treinamento, indexação, citação ou resposta gerada.

Adicionar identidade de conteúdo e representação ao agregado horário novo, conservando método/status necessários aos filtros oferecidos. Expor limites de cardinalidade. Dados antigos por hora sem essas dimensões permanecem disponíveis no resumo geral e indisponíveis para filtros mais detalhados. Não ignorar um filtro silenciosamente.

Reaproveitar importação de logs, contribuições por arquivo, substituição idempotente, retenção e reserva de execução. Uma leitura da tela não inicia varredura nem sonda remota. A fotografia de hoje será integrada aos recortes com marca “parcial”, somente se compatível com regra e filtros; excluir o mesmo dia do consolidado ao usá-la. Na rotação do log, substituir a fotografia pelo dia fechado sem somar os dois.

O cookie/cabeçalho de teste continua excluindo a medição de navegador conforme a regra vigente. Logs que não trazem essa marca não permitem retirar navegação pública de teste por IP/horário. Rotas operacionais/MCP são excluídas do indicador editorial pelo caminho/classe, conforme 4.5; isso não exige identificar a pessoa que as chamou. Mostrar essa diferença na cobertura dos agentes.

Classificar a finalidade declarada da assinatura separadamente da família: busca/descoberta, coleta potencial para modelos, acesso solicitado por usuário, publicidade e desconhecida. Exemplos documentados: OAI-SearchBot e Claude-SearchBot para busca; GPTBot e ClaudeBot para coleta potencial para modelos; ChatGPT-User e Claude-User para acessos motivados por usuários. OAI-AdsBot pertence ao recorte publicitário [F2, F3]. Essa finalidade não comprova o destino final de uma requisição específica, nem converte o acesso do agente em uma sessão humana.

Google/Gemini exige tratamento cuidadoso: `Google-Extended` é um token de controle e não tem User-Agent HTTP próprio. Não converter acessos de Googlebot/GoogleOther em “Gemini leu o artigo”; apresentar produto/finalidade indeterminados quando a assinatura não os distingue [F4]. O mesmo princípio vale para outros provedores e acessos por índices/cache que não geram nova requisição ao site.

### 6.2 Visitantes encaminhados por IA

Uma sub-aba dedicada reaproveita o serviço de Aquisição, com filtro de IA aplicado. Mostrar provedor/superfície quando identificável, sessões observadas, páginas de entrada, proporção entre sessões elegíveis com denominador explícito, continuidade, sinais de consumo e contatos resultantes. Oferecer comparação com busca orgânica e demais origens no mesmo período e cobertura, sem misturar tráfego pago, testes ou requisições de robôs.

O percurso de análise será IA → artigo/página de entrada → sessões → jornada → ações. Preservar a origem ao navegar internamente e permitir filtros por provedor, conteúdo, formato de entrada e campanha quando aplicável. O visitante que chegou por IA pode ler várias páginas; distinguir conteúdo de entrada de conteúdo visitado depois.

Não presumir que toda visita de Google veio de uma resposta com IA. A documentação do Google inclui AI Overviews e AI Mode nos totais de pesquisa Web do Search Console; os sinais locais auditados não garantem a separação dessas superfícies [F5]. Quando não houver evidência específica, conservar Google/busca com superfície indeterminada. Não criar “Gemini = 0” para representar falta dessa capacidade de identificação.

Manter em campos separados a família identificada, o sinal observado (`referrer_host`, UTM reconhecida ou ambos), a superfície quando conhecida, o caráter pago/editorial e a versão da regra. Não produzir uma pontuação numérica de confiança inventada. Zero significa nenhum encaminhamento identificado dentro da cobertura, não ausência de visitantes de IA no mundo real.

### 6.3 Referências observadas: citação, menção e recomendação

Acrescentar registro leve, administrativo, acessível também por ability autenticada, para consolidar evidências coletadas pelo dono ou por seus agentes fora do site. Uma citação exige referência explícita ao site/conteúdo; uma menção ao nome e uma recomendação explícita são tipos diferentes. “Utilizou o conteúdo sem citar” continua não verificável pelos dados locais.

Campos mínimos: provedor/superfície, data da observação, tipo, URL/conteúdo referido quando houver, tema ou pergunta resumida sem dados pessoais, contexto/modelo/localidade quando conhecidos, origem da evidência, referência verificável e estado de revisão. Identificar se a observação veio de teste controlado, descoberta espontânea ou serviço externo. A evidência pode ser um link público apropriado ou uma referência a registro privado autorizado; não copiar conversas completas ou publicar seus links por padrão.

Prever cadastro, listagem, correção e exclusão; importação idempotente por identificador da origem; consulta/CSV com filtros; permissão administrativa e auditoria das alterações. Renderizar os dados como texto seguro e não buscar automaticamente URLs de evidência. Registros de teste ficam em recorte separado e não entram nos totais de visitantes, requisições orgânicas ou referências espontâneas.

Exibir “referências observadas”, nunca “total de citações na IA” ou participação global. Comparações entre rodadas de teste só são válidas com conjunto de perguntas, condições e número de execuções documentados. Nenhum registro é criado automaticamente a partir de um User-Agent ou UTM.

### 6.4 Leitura conjunta sem atribuição falsa

No detalhe do conteúdo, colocar lado a lado: acessos de agentes, visitantes encaminhados e referências observadas. Exemplo de leitura correta: “este artigo recebeu requisições do agente X, teve sessões com origem X e possui uma citação registrada”. Não ligar esses grupos como um funil rastreado: não existe identificador comum que prove qual requisição gerou qual resposta ou clique.

Sem referências cadastradas, informar “nenhuma referência registrada”; sem logs, “acessos não disponíveis”; sem origem identificável, “origem desconhecida”. As três ausências têm significados diferentes. Não gerar nota única de visibilidade em IA. A comparação no tempo deve manter fonte, amostra e cobertura visíveis.

O Core reúne observações locais e evidências recebidas. Não fará consultas periódicas a modelos, scraping de interfaces ou contratação automática de APIs nesta release. Agentes externos podem executar avaliações autorizadas e registrar os resultados pelo contrato documentado.

### 6.5 Verificação de origem de rede sem persistir IP — 82

Incorporado nesta revisão. Validar o IP de origem disponível no log, em memória, contra redes publicadas oficialmente para o agente/provedor. Google documenta essa verificação; OpenAI publica listas por agente; Anthropic também referencia uma lista oficial de redes [F2, F3, F6, F8]. Usar redes pertinentes ao produto, sem considerar toda faixa de uma nuvem prova de Gemini ou de outro provedor.

Persistir somente família/finalidade declaradas, resultado (`rede_compativel`, `fora_das_faixas`, `sem_fonte_oficial`, `fonte_expirada`, `ip_nao_confiavel`), versão/hash da lista, data de verificação e contagem. Não persistir IP, hash de IP, PTR individual ou User-Agent bruto em tabelas, cache, diagnósticos ou exportações. A verificação confirma compatibilidade com rede documentada; não equivale a assinatura criptográfica nem prova de uso editorial.

Baixar listas por tarefa explícita/cadência, com URLs oficiais fixas, HTTPS, limites, validação CIDR IPv4/IPv6, atualização diária e prazo máximo de sete dias para tratá-las como vigentes. Não fazer DNS/HTTP por linha de log nem na renderização de relatório. Preservar a última lista válida e informar sua idade; vencimento ou falha não transforma todo robô em falso. Catálogo sem fonte oficial continua somente declarado.

Aceitar somente endereço cuja origem no formato do log esteja documentada. IP de proxy ou cabeçalho encaminhado sem confiança comprovada recebe `ip_nao_confiavel`; a release não dependerá de configurar a hospedagem para funcionar. Rede incompatível vira identidade não corroborada, sem acusação automática de falsificação. Varredura de caminho e verificação de identidade são dimensões independentes.

A importação usa fotografia fixa da lista por lote. Reprocessar logs antigos com a lista atual recebe a indicação “compatível na verificação atual”; não afirma que a faixa pertencia ao provedor na data histórica sem uma lista válida daquele período. Agregados sem IP de origem não podem ser autenticados retroativamente. Totais declarados e corroborados são apresentados separadamente, com cobertura; provedores sem verificação não somem da análise.

### 6.6 Bloqueios de conteúdo e alertas — 84

Sinalizar 403/429 em páginas, artigos e Markdown para agentes de busca/IA, com período, contagem, proporção no recorte, identidade, representação e primeira/última ocorrência. Destacar incompatibilidade com a política de acesso atualmente configurada, preservando a distinção entre intenção declarada e resposta efetivamente observada. A política atual não é prova da política vigente em um acesso antigo.

Alertas ficam no painel e nas abilities, agrupados para evitar repetição; não enviar novos e-mails automaticamente. Diagnóstico indica “causa não determinada” quando o log só contém status: não atribuir a WAF, rate limit ou hospedagem sem evidência. 503 de Markdown se vincula ao estado da geração quando houver evidência temporal compatível. Não alterar robots, abrir firewall ou liberar IP automaticamente; a análise deve ajudar a decidir a correção.

## 7. Sessões e jornadas individuais

### 7.1 Recuperação imediata

Encaminhar `sessao` pela tela, consulta, links, paginação e CSV. Mostrar um identificador curto clicável com cópia do ID integral no detalhe. Validar o ID completo; prefixo não pode selecionar arbitrariamente uma sessão. Preservar todos os filtros aplicáveis ao navegar e voltar.

### 7.2 Explorador

Lista com início observado, duração observada, origem de entrada, primeira/última página, páginas distintas, ações e classe de tráfego. Filtros por intervalo, sessão exata, conteúdo visitado, página de entrada, canal, dispositivo e segmento de teste. Não exigir que o administrador conheça o ID para começar: ele deve abrir sessões a partir dos relatórios de conteúdo e aquisição.

Detalhe em linha do tempo, organizado por navegação/carregamento: página vista, seções e rolagem observadas, tempo ativo resumido, clique, formulário iniciado, tentativa, erro e aceite registrado. Web Vitals ficam recolhidos em dados técnicos. Links para contatos associados exigem a permissão administrativa existente; não expor nomes/e-mails no resumo de sessões.

Utilizar o ID de sessão existente, sua janela de inatividade configurada e a separação por classe de tráfego. Não criar nova identidade de pessoa nem juntar por IP, e-mail ou proximidade de horários. Não substituir o ID na atualização.

### 7.3 Contrato comum de eventos

Unificar o identificador de navegação gerado no navegador e fazê-lo acompanhar comportamento, análise e capturas relacionadas. Ele nunca deve ser embutido como identificador fixo em HTML em cache. Acrescentar `navegacao` à trilha individual de comportamento e atualizar validação, persistência, deduplicação, consulta, eliminação e documentação. Preservar os registros antigos com navegação não disponível.

Definir uma fonte primária por evento lógico. Aceite vem do lead persistido; página vista usa navegação; dados de tempo são intervalos elegíveis; repetições e retentativas mantêm a mesma identidade. Não somar `f3base_eventos`, `f3base_analise` e leads indiscriminadamente. Para o histórico sem navegação, apresentar a deduplicação limitada e a qualidade; não prometer contagem exata de carregamentos que não foi capturada.

Ordenar por instante válido e deslocamento/ordem quando existente, com desempate estável. Separar navegações simultâneas; `recebido_em` não será tratado como ordem real de ação. Sessão truncada pela janela, retenção, limite ou falta de consentimento deve indicar início/fim desconhecido. Ao ampliar a jornada além do recorte, exibir a nova janela explicitamente.

## 8. Horários, UX e Design

### 8.1 Tempo legível

- Datas e horários na interface: `29/09/2026 15:25:02`, no fuso configurado no WordPress. Fuso visível no cabeçalho; nunca aplicar UTC−3 fixo.
- Durações: `2 min 34 s`, `480 ms`, `1 h 05 min`, conforme unidade e precisão da métrica. Não misturar duração com data.
- “Há 5 minutos” apenas como complemento; manter horário absoluto acessível.
- Armazenar instantes UTC ou epoch; API conserva números/unidades e fornece apresentação separada. CSV inclui UTC ISO 8601, horário local e fuso/offset identificados.
- Horas de agentes devem ser exibidas no fuso do site a partir do instante UTC, distinguindo horas repetidas e limites do calendário. Agregado diário antigo conserva o calendário em que foi calculado; mudança de fuso exige reprocessamento quando houver logs, ou aviso de incompatibilidade histórica.
- Epoch, sentinelas, `null` e deslocamentos técnicos não aparecem como datas humanas. `ms` relativo não é timestamp. Âncora aproximada/horário do servidor precisa de indicação.

### 8.2 Sistema visual e interação

Usar a linguagem visual do admin WordPress com componentes próprios consistentes: espaçamento, hierarquia tipográfica, largura de leitura, alinhamento numérico e cores sem dependência exclusiva para transmitir estado. Não carregar um framework público de análise ou uma biblioteca grande apenas para redesenhar tabelas.

Filtros principais sempre visíveis: período, conteúdo/canal conforme área e segmento. Avançados em expansão. Chips mostram filtros ativos; “Limpar filtros” tem comportamento previsível. Data padrão de 30 dias, atalhos de 7/30/90 e 13 meses nas visões agregadas; intervalo personalizado dentro da retenção disponível. Jornadas e horas conservam sua retenção curta, informada antes de abrir o detalhe. Consultas antigas limitadas a 90/180 dias precisam ser ampliadas somente para agregados compatíveis, com orçamento e paginação. Ao aplicar outro filtro, reiniciar paginação; voltar do detalhe conserva recorte e ordenação.

Tabelas com título do conteúdo, caminho secundário, até seis/sete colunas iniciais, colunas opcionais, cabeçalho estável, paginação e ordenação reais. Detalhes abrem uma visão dedicada com navegação de volta; não uma sequência de modais aninhados. Gráficos diários e distribuição por origem devem ter tabela equivalente e legenda de unidade. Estados de indisponibilidade não são desenhados como zero.

Prever estados distintos: coleta desligada, sem consentimento/detalhe, sem observações, logs não disponíveis, índice em construção, retenção insuficiente, recorte parcial, erro e orçamento excedido. Uma mensagem concisa junto à métrica e detalhes técnicos recolhidos evitam encher a tela de avisos repetidos.

Garantir teclado, foco visível, rótulos associados, seleção acessível, contraste e reflow em largura estreita. Atualizar textos de ajuda para explicar pergunta, cálculo, exemplo, vantagem e limitação. Eliminar texto desatualizado sobre ausência de leads nativos na Aquisição da 1.16.

## 9. Dados, desempenho e continuidade

| Recurso | Mudança necessária |
|---|---|
| Catálogo de conteúdo/rotas | Post ID, tipo, rotas e representação, vigência, procedência e cobertura; resolução paginada e indexada. |
| Contribuições e acessos consolidados | Acrescentar dimensões editoriais/representação e versão da resolução, preservando caminho sanitizado e origem do agregado. |
| Agregados horários | Novas dimensões para filtro por conteúdo; histórico sem granularidade explicitamente limitado. |
| Eventos individuais | Navegação comum e contexto editorial validado; preservar instante, unidade, qualidade e identidade de deduplicação. |
| Origem da sessão | Fotografia de entrada e classificação versionada a partir de sinais permitidos. Não criar uma pessoa ou identificador adicional. |
| Resumo diário editorial | Quantidades aditivas de visualizações/ações por conteúdo e origem, com cobertura; sem armazenar corpos de contatos ou dados digitados. |
| Referências de IA observadas | Registro administrativo de evidência, procedência, contexto, revisão e chave idempotente; separado da telemetria de visitantes. |
| Automação | Ambiente/finalidade, motivo e regra nos eventos/sessões, separados da marca de teste; segmentação consistente nos agregados. |
| Identidade de robôs | Resultado da verificação de rede e versão da lista nos agregados, sem endereço individual. |
| Search Console | Fotografia externa por propriedade/dia/página, calendário, métricas, filtros, cobertura e identidade de importação. |

O resumo diário permite acompanhar tendências após expirar o detalhe individual. A retenção proposta para o novo agregado editorial é 13 meses, sem IDs de visitante/sessão, IP ou query livre. Agregados atuais de acessos têm padrão de 25 meses e não serão reduzidos para 13 na atualização. Configurações explícitas mais curtas permanecem preservadas e sua limitação fica visível; ampliação na frota exige aplicação administrativa explícita.

Sessões e visitantes distintos de um período não podem ser obtidos somando distintos diários: calcular a partir do detalhe enquanto disponível e declarar indisponível quando não for. Para comparação histórica de audiência, manter também contador aditivo de **sessões iniciadas**, atribuído uma vez à data de início observado e ao conteúdo/canal de entrada. Ele não equivale a sessões ativas em qualquer momento do período; sessões com início desconhecido ficam separadas. Visitantes únicos de 13 meses continuam indisponíveis após eliminação dos IDs. Percentis exigem amostra adequada; não usar média de medianas. Atualização de contribuição e marca de contabilização devem ser transacionais, com fechamento da sessão e idempotência antes de eliminar seu detalhe; não conservar o identificador no agregado.

Manter prazos configurados e exclusões explícitas. Detalhes de sessão seguem a retenção individual atual, padrão de 30 dias; horas seguem sua configuração própria. O novo agregado de 13 meses não amplia esses detalhes nem a guarda dos leads. Um comparativo de 30 dias com os 30 anteriores exige cobertura suficiente de ambas as janelas; se faltar, mostrar o limite. Agregados não permitem recuperar jornadas já eliminadas. Remover identificadores não torna qualquer caminho automaticamente anônimo: catálogo editorial e rotas permitidas devem impedir dados pessoais na URL agregada.

Referências cadastradas são registros editoriais de auditoria: permanecem até exclusão explícita, com esse comportamento informado no cadastro e na documentação. Não vinculá-las a uma pessoa visitante; não usá-las para conservar eventos de sessão após sua retenção.

Somente dados necessários à análise: não adicionar IP para identificar visitantes, User-Agent bruto em relatórios, query completa, conteúdo digitado, captura de tela ou gravação de sessão. Esquecimento/revogação/eliminação deve alcançar novos vínculos individualizados; agregados anônimos seguem a regra documentada de retenção, sem permitir remontar a sessão eliminada.

Migração com checkpoints, adição de índices e construção em lotes, sem varredura completa no carregamento de uma tela ou requisição de visitante. Reprocessar logs antigos apenas se ainda disponíveis, dentro da retenção e com versão explícita; não misturar contribuições de regras diferentes nem duplicar totais. Dados com query previamente descartada não podem ser recuperados do agregado antigo.

Consultas aplicam filtros no banco antes de limites, usam paginação estável e retornam cobertura e corte. Dados novos não devem duplicar os beacons públicos: ampliar o envelope existente e manter carregamento adiado, filas, limites e retentativas. Orçamento de consultas, importação e cardinalidade será medido em bancada com volume representativo antes da entrega; não declarar ganho de desempenho apenas pela reorganização visual.

### 9.1 Cobertura e publicação diária/horária — 50/86/87

Separar três estados: arquivo importado, contribuição publicada e cobertura temporal conhecida. Mostrar por dia quais fontes faltam, qual intervalo elas cobrem, calendário de rotação observado, último avanço e próxima ação. “Completo” significa completo para as fontes/intervalos demonstrados, nunca todas as requisições que aconteceram fora do alcance dos logs.

Reproduzir o caso de contribuições horárias existentes e tabela final vazia. O código atual pode bloquear fontes novas por dependências de dias legados ainda não reconstruídos. A correção deve estabelecer fronteira de migração/conjunto de contribuições cuja propriedade temporal seja demonstrável: substituir o conjunto antigo de forma atômica ou preservá-lo isolado. Não misturar parcialmente os mesmos acessos em calendários distintos, nem deixar uma fonte antiga irrecuperável impedir indefinidamente novos dias completos.

Publicar o horário junto da contribuição elegível, com a mesma versão/qualidade. Agregados novos parciais podem ser apresentados como parciais quando sua origem é demonstrada e não há sobreposição com legado; não promover dias antigos só para preencher o painel. Fonte adjacente ainda esperada deve se distinguir de arquivo perdido, erro de leitura e importação em progresso. Sem fonte que permita provar o fechamento, conservar a limitação.

Coleta com cursor, retomada, revisita de dias recentes antes da rotação e controle de atraso. Todas as tarefas novas entram em `executar-pendentes`; o agendamento expõe última execução bem-sucedida, atraso e janela em risco. O plugin não garante cadência em site sem visitas/executor: o canal existente pode executar pendentes, e a falta de execução gera diagnóstico. Não criar dependência de cron da hospedagem ou promessa de “zero lacunas” quando a fonte não existe.

Histórico mensal terá 13 meses consultáveis onde retidos, cobertura por dia e fronteira de início real. Não recuperar meses já eliminados nem reimportar dados fora da política vigente. O item 50 continua com aceite da operação previsto para 30/09; o resultado anterior relatado não é encerrado por esta revisão de código.

## 10. Contratos e documentação instalada

Criar serviços compartilhados entre UI, CSV e abilities, com consultas propostas `conteudos-relatorio`, `sessoes-listar` e `sessao-detalhar`; ampliar `agentes-relatorio` e aquisição por IA; acrescentar consulta e operações de escrita de referências observadas e importação Search Console, explicitamente separadas. Nomes definitivos entram no catálogo autenticado e no contrato da versão. Todas exigem permissão administrativa, têm schema fechado e distinguem consulta de coleta/reprocessamento/escrita.

Contrato comum: período, fuso, filtros aplicados, classe de tráfego, regra de classificação/deduplicação, fonte, granularidade, cobertura, limites, paginação e significado de ausência. CSV preserva filtros e neutraliza fórmulas. IDs internos integrais ficam disponíveis de forma autorizada para agentes e cruzamentos, sem despejar dados pessoais no painel.

Documentos instalados a revisar: METRICAS, RELATORIOS, AGENTES-E-BUSCADORES, DICIONARIO-DADOS, CONSULTAS-EXEMPLO, contrato JSON, catálogo de abilities, instruções para agentes, como-usar, ajuda da interface e CHANGELOG. Acrescentar guia “Analisar conteúdo orgânico” com perguntas e consultas reproduzíveis: artigo → origens → sessões; artigo → robôs → Markdown; histórico indisponível; contagens comparáveis e limites de atribuição. Atualizar a lista de áreas também em RELATORIOS, que ainda descreve a organização anterior.

Acrescentar guia “Analisar presença e visitas de IA”: finalidade declarada dos agentes, sinais de encaminhamento, citações versus menções/recomendações, limites de Google/Gemini, procedimento de teste com exclusão de tráfego interno e exemplos de registro por agentes. Consultas reproduzíveis devem cruzar conteúdo e período, sem inventar associação entre uma requisição de robô e uma sessão humana.

Atualizar `dados/mudancas.json` com as mudanças faltantes da 1.16.0 e as da 1.17.0, preservando o histórico documental; isso não reintroduz compatibilidade de execução com versões antigas. O relatório de entrega terá uma linha por pedido, com estado, arquivo/função/linha da fonte final, teste, evidência, resultado e pendência externa. ZIP, manifesto e hashes da documentação instalada devem corresponder à mesma revisão testada.

## 11. Sequência de implementação e aceite

Uma única entrega funcional, com as seguintes etapas internas:

1. Corrigir LLMS, robots, P00/defaults, agenda, diagnóstico de navegação/consentimento e contratos; reproduzir a publicação dos logs.
2. Separar automação/tráfego operacional; recuperar filtro de sessão e formatadores; implantar catálogo editorial e identidade HTML/Markdown.
3. Unificar navegação, canais/origem IA, verificação de rede e cobertura; criar agregados editoriais e serviços de Conteúdo/Sessões/Aquisição/IA.
4. Acrescentar Search Console, referências observadas, alertas e a nova interface com exportações.
5. Validar cálculos, continuidade, retenção, desempenho e acessibilidade; gerar documentação e pacote único.

Critérios obrigatórios:

- Páginas e Artigos são distintos pelo tipo real do WordPress; home, índice do blog, CPT, slug alterado/excluído e rota não resolvida têm tratamento explícito.
- O mesmo artigo em HTML e Markdown aparece como um conteúdo com representações separadas. Cobrir os três formatos de URL Markdown, queries estruturais, subdiretório, caracteres codificados, arquivo de outro emissor, 404 e 503. `llms-full` não multiplica artigos lidos.
- Agente → conteúdo e conteúdo → agente retornam o mesmo conjunto filtrado em UI, CSV e ability. Testar GET/HEAD/304, erros, assinatura desconhecida, limite de caminhos e catálogo com mais de 1.000 itens.
- Importar novamente um arquivo, interromper/retomar, substituir contribuição, mudar regra e fechar o dia atual não duplicam contagens. Cobertura parcial e sem fonte continuam distinguíveis de zero.
- Sessão com várias páginas, reload, duas abas, retorno por bfcache, envio atrasado, retentativa, troca de teste e revogação mantém identidade, ordem qualificada e deduplicação. Não atribuir uma ação de outra sessão ou classe.
- Filtro por sessão funciona por seleção e ID, sobrevive à paginação/exportação e mostra a jornada além da página inicialmente escolhida. Histórico incompleto é identificado.
- Busca orgânica, referência de IA, social, campanha paga, conflito de parâmetros e ausência de referência são classificados por evidência. Navegação interna não apaga a origem inicial; anúncio sem sinal não ganha rótulo orgânico garantido.
- IA com referrer, somente UTM, ambos, conflito e domínio imitador recebe classificação/evidência correta. Testes internos ficam fora dos totais padrão. Googlebot não vira Gemini; ChatGPT-User/Claude-User não viram sessões humanas; tráfego publicitário não vira recomendação editorial.
- Referências podem ser registradas, corrigidas, excluídas e importadas sem duplicação; testes ficam identificados. Nenhuma referência é fabricada de logs. UI/API/CSV preservam procedência e revisão; não executam HTML recebido nem buscam links de evidência.
- Horários e durações são legíveis; testar meia-noite, UTC versus fuso do site, alteração de fuso, hora repetida, unidade ms/segundos e âncora aproximada. CSV mantém os instantes originais.
- Visitantes/sessões distintos não são somados entre dias como únicos do período. Tempo e rolagem desligados ou sem amostra não aparecem como zero. Crescimento versus período anterior não recebe atribuição causal automática.
- Comparar números em fixtures com totais esperados, nos serviços e na tela. Validar teclado, foco, contraste, telas largas/estreitas e ausência de erros JS.
- Reexecutar instalação nova e atualização da 1.16.0, com preservação de configurações e retomada. Não alterar tema, implantador ou sites de produção nessa bancada.
- Documentação entregue junto do plugin explica coleta, interpretação e SQL/API, sem credenciais de teste ou valores pessoais.
- Uma página com bloco dinâmico não suportado não bloqueia os outros itens da geração LLMS. O preparo expõe item/bloco/motivo, publica cobertura parcial e preserva elegibilidade pública e geração anterior durante a troca.
- Ciclo robots 0644 → reserva privada 0600 → restauração 0644, com os mesmos bytes, funciona em instalação nova, retomada e reativação; edição concorrente externa é preservada e a reativação não espera o cron para entregar o arquivo gerenciado quando esse modo é necessário.
- P00 não exige escrita de projeções; novos defaults não alteram `false`, `0`, `[]` ou credenciais/configurações existentes. `mudancas` com `desde_versao=1.15.0` inclui a 1.16.0; com `1.16.0`, inclui a 1.17.0.
- Ofertas podem ser verificadas pelo executor com WP-Cron automático desabilitado; edição sem efeito nos redirects não invalida prova, mas mudança pertinente invalida com motivo.
- Sinais Lighthouse/Headless/teste/MCP/varredura produzem segmentos corretos em UI/CSV/ability. Uma sessão curta sem sinal continua não identificada. Nenhum lead real é recusado por probabilidade de automação.
- CIDR IPv4/IPv6, limite de prefixo, rede incompatível, lista expirada, falha de atualização, proxy e provedor sem fonte têm resultados explícitos. Nenhum IP ou hash individual aparece nas novas tabelas, caches ou exportações; consultas não fazem uma chamada remota por linha.
- Fontes adjacentes, rotação com fuso diferente, dia vazio, fonte perdida, legado irrecuperável, interrupção e mudança de regra não duplicam dados nem bloqueiam novos dias demonstravelmente completos. Horas elegíveis são publicadas junto dos dias.
- Search Console: importação duplicada, propriedade errada, canonical diferente, fonte parcial, limite de linhas, calendário do Pacífico e conector ausente têm tratamento previsto. CTR/posição e totais não usam agregações inválidas.
- Retenção de 13 meses dos novos agregados, sessão atravessando meia-noite, início desconhecido, finalização repetida e expiração do detalhe não duplicam sessões iniciadas nem transformam distintos diários em visitantes únicos.
- Alerta 403/429 não declara causa sem evidência nem muda proteção do site. Consentimento em painel do tema preserva largura, contraste, teclado e foco em 360/1440 px em bancada, sem editar temas da frota.

## 12. Adiamentos e decisões

| Item | Destino e justificativa |
|---|---|
| Consultas de busca detalhadas e novas credenciais Google | Adiadas. Entram métricas Search Console por página via fonte autorizada/importação; a gestão de conta e consultas detalhadas não é necessária para esse primeiro recorte. |
| Comprovar automaticamente treinamento/uso não citado ou todas as recomendações de IA | Não é possível com dados locais. Entram acessos, encaminhamentos e registro de referências verificáveis; não entra uma alegação de cobertura total. |
| Monitoramento externo contínuo de respostas de IA | Adiado. Requer fonte, conjunto de perguntas, condições de teste, frequência e orçamento próprios. A release recebe observações de agentes, sem executar campanhas de consulta a modelos. |
| Autenticação criptográfica de robôs, bloqueios automáticos e WAF | Fora desta release. Entra verificação limitada de origem de rede por listas oficiais; ações de proteção e bloqueio seguem separadas. |
| Replay de sessão, gravação de tela e conteúdo digitado | Fora do escopo; a jornada por eventos atende ao objetivo com menor custo e coleta. |
| Funil entre dispositivos ou atribuição por IP/horário | Fora do escopo por ausência de vínculo comprovado. |
| CRM, novas plataformas nativas de ads e pendências externas da 1.16 | Permanecem no backlog próprio e no relatório de homologação anterior. Não bloqueiam as correções de Medição. |

O plano pode ser implementado sem decisão adicional de produto. Ficam decisões de ativação, que não bloqueiam o pacote: ligar `tempo_ativo` nos sites (recomendado para analisar consumo, mantendo consentimento e amostra; não ativar silenciosamente); ampliar retenções existentes que o dono tenha fixado abaixo do necessário; autorizar/configurar a fonte Search Console; homologar e ativar Pipedrive/ads. A recomendação para o item 38 é manter coleta confiável e otimizar custo medido, sem exigir que o POST desapareça de toda janela PSI. Caso o dono mantenha esse último aceite, ele deve aceitar e definir o impacto sobre perda/atraso de medição antes de mudar o transporte.

## 13. Fontes de verificação

Base: relatório 1.16.0 r2 e manifesto conferidos em 29/09/2026; instalador de referência SHA-256 `94978e498eb12475480cc570d8f03ca8fca9cde4a79e8aeefbe705f0dbdab344`.

Principais arquivos auditados: `includes/class-f3base-medicao-interface.php`, `class-f3base-medicao-consultas.php`, `class-f3base-relatorios.php`, `class-f3base-agentes.php`, `class-f3base-modulo-acessos-servidor.php`, `class-f3base-acessos-coleta.php`, `class-f3base-acessos-atuais.php`, `class-f3base-modulo-llms-markdown.php`, `class-f3base-analise.php`, `class-f3base-modulo-comportamento.php`, `class-f3base-atribuicao.php`, `admin/class-f3base-admin-medicao.php`, assets de contexto/análise/tracking e documentação instalada.

Os diagnósticos acima são conclusões do código da entrega. O estado de dados, logs e configuração de cada site não foi inspecionado nesta etapa. O plano não afirma que a release já está implementada, testada ou homologada.

Referências oficiais consultadas em 29/09/2026 para o complemento sobre IA; revalidar assinaturas na implementação:

- [F1 — OpenAI: Publishers and Developers FAQ](https://help.openai.com/en/articles/12627856-publishers-and-developers-faq): parâmetro de encaminhamento do ChatGPT.
- [F2 — OpenAI: Overview of OpenAI Crawlers](https://developers.openai.com/api/docs/bots): finalidades distintas dos agentes.
- [F3 — Anthropic: web crawlers](https://privacy.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler): ClaudeBot, Claude-SearchBot e Claude-User.
- [F4 — Google: common crawlers](https://developers.google.com/crawling/docs/crawlers-fetchers/google-common-crawlers): Google-Extended não tem User-Agent HTTP próprio.
- [F5 — Google: AI features and your website](https://developers.google.com/search/docs/appearance/ai-features): métricas das experiências de IA incluídas no tráfego Web do Search Console.
- [F6 — Google: Verify requests from Google crawlers and fetchers](https://developers.google.com/crawling/docs/crawlers-fetchers/verify-google-requests): conferência por faixas publicadas ou DNS com validação de ida e volta. O plano adota faixas para evitar consulta por linha.
- [F7 — Search Console API: Search Analytics query](https://developers.google.com/webmaster-tools/v1/searchanalytics/query): dimensões, métricas, calendário, dados finais/parciais e limites da fonte.
- [F8 — Anthropic: lista de redes de crawling](https://claude.com/crawling/bots.json): lista vinculada pela documentação oficial F3; consultada nesta revisão. Não incorporar uma cópia congelada como verdade permanente.

Arquivo fornecido: `Pendências do site-core após a 1.15.0(1).md`, seção de conferência da 1.16.0 e diagnóstico de Medição, 29/09/2026. O link para “Pedidos ao pacote core” citado no anexo não foi usado como se seu conteúdo tivesse sido consultado; a disposição abaixo cobre o texto efetivamente fornecido.

## 14. Disposição dos pedidos e correções complementares

### 14.1 Matriz por número original

“Atendido” nesta matriz significa confirmado pelo relatório recebido, com proteção de regressão no pacote; não é uma nova homologação de produção feita nesta análise.

| Pedido | Disposição na 1.17.0 | Justificativa / aceite restante |
|---|---|---|
| 17 | Manter integração entregue e desligada | Homologação/ativação externa de Pipedrive e ads permanece decisão operacional; sem nova frente de CRM. |
| 36 | Incorporar o restante com 73 | Publicar LLMS sem bloqueio global e expor indisponibilidade. Manter geração anterior durante preparo e orçamento de conversão por requisição; não converter todo o site sincronamente. |
| 37 | Corrigir mensagem TTL | Separar limitação informativa permanente de aviso acionável; `aviso` vazio quando não houver risco observado/configurado que o justifique. Desconhecido não vira seguro. Renovação de token permanece teste de regressão. |
| 38 | Ajustar o critério proposto | Já foi medido com parâmetros padrão: POST em 5/6 janelas. Presença na janela não demonstra prejuízo à nota. Medir custo real e perdas; não prometer POST fora de toda execução por um atraso fixo. |
| 41 | Atendido; complementar com 75 | Preservar múltiplos períodos/prova/purga. Cadastrar ofertas Twinia e remover compensação do tema são ações da operação do site. |
| 42 | Incorporar | Reparar somente migração equivocada demonstrável e distinguir referência válida, vínculo declarado e uso observado no cabeçalho. P66 não aprova uso sem prova. |
| 45 | Incorporar | Tornar operacional e documentado o modo de painel desenhado pelo tema, mantendo acessibilidade e sem editar o tema. |
| 50 | Aceite operacional aberto | Reler cobertura em 30/09 conforme relatório; novo trabalho de publicação/cobertura incluído em 86. Não marcar resolvido por data futura. |
| 52 | Aceite operacional aberto | Sete dias sem a falha, vencimento informado em 05/10. Incluir regressão local; esta etapa não substitui observação em produção nem cria uma tarefa automática. |
| 54 | Atendido; complementar com 75 | Motivo de invalidação existe; eliminar dependência irrelevante de geração global, preservando invalidações pertinentes. |
| 59 | Atendido | Preservar separação de fbc/fbp e toques; cobrir novamente navegação com canal/origem IA. |
| 60 | Atendido | Preservar procedência da migração; não repetir alterações em ofertas só para preencher lista vazia. |
| 61 | Incorporar somente o restante | Acrescentar ressalva de QUERY_STRING em CONTRACTS. Demais correções relatadas entram como regressão. |
| 62 | Atendido; complementar com 74 | Reserva privada e remoção da cópia pública ficam preservadas; corrigir modo original e reativação. |
| 63 | Atendido | Regressão de oEmbed/RSS/autor; criação de usuário pelo implantador fora do Core. |
| 64 | Atendido | Regressão de schema, campos de serviço e escrita inteira da cadência. |
| 65 | Atendido | Preservar hook correto de meta author, sem reabrir autoria dos temas. |
| 66 | Incorporar textos restantes | Estado do schema deve refletir demais propriedades; ajuda de `full` deve refletir default true. Código morto já retirado. |
| 67 | Atendido | Opção de carimbo pelo destino existe e segue desligada; ativação Twinia/remoção de filtro do tema fora do pacote. |
| 68 | Atendido | Saúde inclui formulários; manter regressão. |
| 69 | Atendido | Preservar superfície menu nos blocos de navegação. |
| 70 | Atendido com limite documentado | Inventário de conteúdo salvo não cobre todos os arquivos/HTML gerados por tema. Não ampliar para varredura arbitrária de código de tema nesta release. |
| 71 / N1 | Incorporar | P00 exclui projeções e estados; novos controles graváveis recebem defaults apenas onde ausentes, com procedência. |
| 72 / N2 | Incorporar | Atualizar histórico legível por agentes com mudanças 1.16 e 1.17 e testes de filtro/paginação. |
| 73 / N3 | Incorporar — P0 | Falha localizada de representação não impede a geração útil de todo o site. |
| 74 / N4 | Incorporar — P0 | Preservar metadados do original ao confirmar reserva e publicar o arquivo gerenciado na reativação. |
| 75 / N5 | Incorporar | Ofertas no executor e contexto de redirects limitado às dependências reais. |
| 76 | Incorporar — P0 | Segmentação de automação com evidência; não deduzir robô apenas da duração/data. |
| 77 | Incorporar | Canais por sessão, origem de entrada preservada e independente da plataforma de anúncios. |
| 78 | Incorporar | Corrigir chatgpt.com e ampliar catálogo de referências IA, com aliases e procedência. |
| 79 | Incorporar | Comportamento por canal e entrada, com ligação à sessão e qualidade histórica explícita. |
| 80 | Incorporar | Finalidade busca-ia e famílias verificadas no catálogo; não inventar tráfego Google-Extended. |
| 81 | Incorporar — P0 | Remover MCP/admin/assets/varreduras dos totais editoriais; manter resumo técnico necessário. |
| 82 | Incorporar com limite explícito | Compatibilidade de rede por fontes oficiais; sem persistir IP e sem prova retrospectiva indevida. |
| 83 | Incorporar | Conteúdo × agentes × visitantes encaminhados, com unidades distintas e registro de referências. |
| 84 | Incorporar | Alertas locais de bloqueio, com evidência, política e causa indeterminada quando necessário. |
| 85 | Incorporar | Search Console por página via fonte autorizada, com contrato de importação e calendário separado. |
| 86 | Incorporar — P0 | Corrigir promoção das contribuições e cobertura; não falsificar “completo” para desbloquear gráfico. |
| 87 | Incorporar com ajuste | 13 meses no novo agregado editorial; preservar 25 meses/configurações já existentes dos logs e retenções curtas individuais. Cadência observável; não garantir fonte inexistente. |
| 88 | Incorporar | Visão geral centrada em conteúdo orgânico, navegação e IA, com números filtrados e cobertura. |

### 14.2 LLMS com falhas localizadas — 36/73

O preparo passa a distinguir item completo, interface omitida com nota, item apenas com HTML e falha transitória. Reconhecer `f3base/formulario` como interface e `core/navigation` como navegação, respeitando a seleção de blocos excluídos, sem executar callbacks arbitrários, formulários ou conteúdo protegido para obter Markdown.

Publicar o conjunto processado com cobertura explícita: itens completos entram em Markdown e full; item editorial sem representação segura entra no índice somente com link para o HTML e motivo de indisponibilidade. O full não apresenta o texto parcialmente convertido como íntegro: inclui referência/nota ou omite o corpo com diagnóstico. Uma lista vazia por exclusão pública válida é resultado possível, diferente de falha de armazenamento.

A geração anterior permanece até a troca consistente. Não converter todo o site na requisição de uma leitura, nem aumentar indiscriminadamente o orçamento atual de conversão imediata. Falha determinística para de ser repetida a cada 60 segundos e só é reaberta por alteração pertinente ou operação explícita; falha transitória tem retentativa limitada e atraso crescente. O endpoint de cobertura lista preparo, item, bloco, motivo, tentativa, próximo passo e versão.

Não anunciar URL `.md` cuja representação não existe. Pedido direto a rota de conteúdo selecionado ainda indisponível recebe 503 com indicação da alternativa HTML; `Retry-After` somente quando há retentativa agendada. Conteúdo removido/privado segue sua elegibilidade, sem exposição da geração antiga. O resolvedor analítico registra essas respostas como indisponibilidade, nunca como conteúdo entregue.

### 14.3 Robots: preservar original e reativar — 74

Separar metadados do original dos da reserva. Ao copiar para área privada 0600, conferir bytes/hash sem substituir a permissão original por `fstat` da cópia. Manter reserva privada restrita; restaurar por arquivo temporário público com modo original, hash e publicação condicionada, sem tornar o arquivo privado legível só para executar hard link.

Na base 1.16 em que o modo original já tenha sido sobrescrito, restaurá-lo de checkpoint confiável quando existir. Sem evidência, não afirmar “mesmas permissões”: usar política documentada de publicação segura do `robots.txt` (0644), com motivo de recuperação; nunca inferir modo original a partir do 0600 da reserva. Preservar edições concorrentes e o backup até confirmação.

Ao religar com modo de entrega por arquivo já conhecido, gerar/publicar o gerenciado na mesma operação administrativa, com orçamento/trava e resultado explícito; verificação HTTP ocorre fora da trava e não deve esperar a próxima visita. Na primeira ativação com entrega desconhecida, executar reconciliação limitada e retornar pendência real se não houver prova. Uma leitura comum de relatório não inicia essa mutação. Aceite cobre bytes, permissões, Sitemap, falha de publicação, concorrência e retomada.

### 14.4 Contratos, navegação, consentimento e agenda — 42/45/71/72/75

**P00/defaults:** separar configurações graváveis, projeções somente leitura e estados operacionais no catálogo. Excluir `f3base_nav_id` derivada e demais campos de serviço da exigência de presença. Na instalação/atualização, materializar somente defaults de novos controles ausentes, com revisão/procedência e retomada; integrações continuam desligadas. Nunca substituir escolha explícita por truthiness: `false`, `0` e `[]` são valores válidos. P00 conserva o significado de presença explícita para o restante, sem mascarar uma falta legítima.

**Navegação:** em atualização da 1.16, reparar registros `bloco` inválidos somente quando a origem da migração é demonstrada e não existe alteração posterior do dono. Em tema clássico, preferir `tema/0` quando não há prova de menu selecionado; menu clássico válido exige evidência própria, sem converter post ID em term ID por coincidência numérica. Para configurações legítimas, distinguir referência, associação, declaração do tema e renderização pública observada. Reconhecer `ref` final injetado em render e navegação inline no escopo do cabeçalho; prova sem escopo não confirma P66. Expor verificação explícita e contrato opcional do tema, sem mudar templates nem exigir sua adoção para o plugin operar.

**Consentimento:** expor controle tipado de apresentação `padrao/tema` e um contrato opcional de declaração pelo tema; aplicar `data-f3base-consent-painel="tema"` pelo próprio plugin antes da apresentação. O modo tema retira somente a moldura/layout do pacote; preserva controles, eventos, foco e contraste. Não tentar deduzir o modo por CSS arbitrário do tema. Ajuda apresenta exemplo, efeito e limitação. Testar em fixtures equivalentes aos dois cenários relatados, sem corrigir arquivos de philon/conselar.

**Ofertas:** registrar `f3base_ofertas_verificar` como tarefa fechada do executor, com callback, reserva, orçamento e progresso. Conferir tarefas de atualização das listas de robôs, catálogo editorial e resumos; nenhuma depende exclusivamente de acesso a `wp-cron.php`.

**Redirects:** substituir a dependência da geração global de cache por revisão dos pares, hosts/permalinks, contrato/provedor pertinente e conteúdo-alvo quando a prova depende de âncora. Edição de página sem relação não invalida tudo; alteração que mude a resposta/âncora de um par invalida as provas pertinentes. Não remover invalidação necessária só para manter `verified`. Documentar quando executar nova rodada e preservar cursor, revisão e resultado por variante.

### 14.5 Limites que permanecem e decisões operacionais

- Modificações de arquivos de tema, retirada das compensações locais e trabalhos do implantador são da operação correspondente. O Core entrega contratos, diagnósticos e regressões.
- Ativação de `tempo_ativo` é recomendada para o objetivo editorial, mas continua desligada onde já estiver assim até aplicação explícita do dono/agente autorizado. Tempo ativo é sinal estimado de consumo.
- O item 38 fica com otimização baseada em custo de CPU/rede e confiabilidade. A exigência “fora do trace” não tem garantia com prazo fixo e não constitui prova de ganho. Manter o prazo atual até benchmark representativo demonstrar mudança necessária; não ocultar telemetria de laboratório para reivindicar melhora artificial.
- Aceites 50/52 e integrações externas têm responsável operacional e evidência futura no relatório de entrega, sem depender de testes em korvena.net.br pelo desenvolvedor.
- Sem fonte oficial ou IP confiável, o robô continua declarado/não verificado. Sem referência/citação observada, não atribuir uso do conteúdo a uma IA. Sem executor e logs retidos, não prometer coleta contínua retroativa.
