"""Assemble validated delivery, sources/evidence and reproducible hashes. No deployment."""
from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parents[1];OUT=BASE/'deliverables/1.17.0';OUT.mkdir(parents=True,exist_ok=True);plugin=ROOT/'fontes/plugin';ev=ROOT/'suite/versao-1170/evidencias'
labels={'core':'Contratos, captura, navegação e segredos','crm':'Pipedrive com transporte simulado','capi':'Regressão CAPI','bordas':'Bordas de contratos e relatórios','llms':'Publicação LLMS','novas':'Ofertas, atribuição, agentes e reconciliação','origens':'Paginação e retomada de origens','editorial':'Conteúdo, sessão, aquisição, IA, referências e GSC','integridade':'Rotas, coortes, histórico e permissões','fronteiras':'Cobertura de logs, horas e rollup idempotente','robots-1170':'Bytes, modos e reativação de robots','obrigatorios':'P00, mudanças, TTL e executor','volume':'Catálogo/volume/orçamento/limite de caminhos','http':'HTTP local, formulário sem JS e cache PHP','redirects-bordas':'Redirects e evidências públicas locais','credenciais':'Troca concorrente de credenciais','fechamento':'Documentação instalada e contratos','admin':'Telas administrativas','ux-editorial':'Conteúdo → sessões → jornada / CSV / teclado / celular','consentimento-tema':'Painel padrão/tema, contraste e tamanhos','transporte':'Transporte, falhas, consentimento e recuperação','contexto-1170':'Identidade por carregamento e origem da sessão','concorrencia':'12 processos, deduplicação, ACK parcial e recuperação'}
results=[]
for key,label in labels.items():
 d=json.loads((ev/(key+'.json')).read_text());checks=d.get('checks',{});n=len(checks) or d.get('total',0);failed=d.get('falhas',[])
 assert not failed and all(checks.values()),(key,failed)
 assert not d.get('stderr'),(key,d.get('stderr'))
 results.append((label,n,key+'.json'))
upgrade=json.loads((ev/'upgrade.json').read_text());assert len(upgrade)==10 and all(x['exit']==0 and not x['stderr'] for x in upgrade)
syntax=json.loads((ev/'sintaxe-build.json').read_text());assert not syntax['falhas'] and syntax['build']['ok']
volume=json.loads((ev/'volume.json').read_text())['detalhes'];perf=json.loads((ev/'performance/matriz.json').read_text());assert len(perf['rows'])==2 and all(not r['runtimeError'] for r in perf['rows'])
total=sum(x[1] for x in results)
validation=f'''# Validação — F3 Base Core 1.17.0

Entrega de 29/09/2026. Instalação nova ou atualização de uma **1.16.0 concluída**, com retomada na própria versão. Sem compatibilidade anterior/downgrade. **Validação local concluída nos cenários abaixo; nenhum site da frota foi alterado e korvena.net.br não foi testado.**

## Ambiente e alcance

WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP Super Cache 3.1.3, Chrome Headless Shell 151 e Lighthouse 13.5.0. Dados sintéticos, e-mails bloqueados e transporte remoto interceptado nas integrações. HTTP local usa oito workers. Os resultados e capturas acompanham `suite/versao-1170/evidencias/` no pacote de fontes.

**{total} verificações aprovadas** nos conjuntos abaixo, mais dez etapas de instalação/atualização. Os números são asserções, não cenários independentes. Testes de serviços e interface foram executados localmente; não equivalem à homologação das contas comerciais ou da hospedagem.

| Conjunto | Aprovadas | Evidência |
|---|---:|---|
'''+''.join(f'| {label} | {n} | `{file}` |\n' for label,n,file in results)+f'''
Instalação/atualização: instalar, semear dados, atualizar, repetir e retomar, para site novo e origem 1.16.0 real. Baseline SHA-256 `94978e498eb12475480cc570d8f03ca8fca9cde4a79e8aeefbe705f0dbdab344`. Preservados contatos, listas vazias, `false`, política e credenciais cifradas. Configuração preexistente inválida é mantida e diagnosticada, sem impedir o preenchimento das outras opções. Sintaxe aprovada em {syntax['php']} arquivos PHP e {syntax['js']} JS; sete assets recompostos e conferidos com Terser fixado.

## Medição, volume e UX

O catálogo de {volume['catalogo_itens']} conteúdos foi concluído em {volume['catalogo_lotes']} lotes. A consulta de {volume['consulta_linhas']} eventos retornou 10 mil visualizações e 2 mil sessões, em {volume['consulta_ms']} ms, com pico de {volume['pico_memoria_mib']} MiB na bancada de 512 MiB. Em 128 MiB houve recusa controlada do recorte, sem totais parciais. O limite de 750 caminhos mantém as demais requisições em uma linha de excesso, sem conservar identidade editorial indevida.

A interface foi percorrida em 1440 e 360 px: áreas, detalhe com cinco eixos, seleção de sessão a partir de artigo, jornada além do conteúdo selecionado, exportação com sessão/UTC/fuso, foco por teclado e ausência de erros JS. Tabelas extensas têm rolagem própria. Consentimento em modo tema foi verificado com fundos/cores variados; isso não certifica CSS de cada tema da frota.

A identidade por carregamento cobre reapresentação do mesmo documento, novo carregamento, separação de abas, origem externa imitadora, troca de sessão e revogação. `pageshow.persisted`/preservação de contexto foram ensaios controlados: **não provam elegibilidade real para bfcache em todo navegador**. Referências IA e GSC usam dados sintéticos autorizados na bancada, com revisão, duplicidade, propriedade e cálculo ponderado. A lista de IPs usa fixtures; disponibilidade externa futura não é garantida.

## Desempenho

Duas rodadas com presets padrão Lighthouse, uma mobile e uma desktop, sem ampliar as janelas. HTML de HIT WP Super Cache foi reproduzido localmente; código Google capturado foi servido localmente, sem envio comercial. Não mede latência de rede da hospedagem/Google nem atribui ganho causal à versão.

| Perfil | Nota | LCP ms | TBT ms | POST de análise na janela |
|---|---:|---:|---:|---|
'''+''.join(f"| {r['formFactor']} | {round(r['score']*100)} | {round(r['lcp'])} | {r['tbt']:.1f} | "+(f"{r['analysisRequests']} requisições; HTTP "+'/'.join(map(str,r['analysisStatuses'])) if r['analysisRequests'] else 'não observado')+' |\n' for r in perf['rows'])+'''
A rodada desktop confirmou os três eventos enviados. Adiar cinco segundos após load continua sem garantir ausência no trace; o transporte prioriza captura e descarga nas saídas. Trace, DevTools e configurações resolvidas acompanham a fonte. É um ensaio da implementação nesta bancada, não um benchmark causal ou byte a byte de cada ajuste final de documentação/validação de origem.

## Correções verificadas durante o fechamento

Além dos itens planejados, o fechamento corrigiu: totais fora do recorte IA; rota de termo renomeado/excluído; preservação do histórico sem navegação, sem colapsar todos os eventos numa página; contagem do excesso de caminhos após retirar as dimensões editoriais; fotografia atual dos robôs respeitando filtros; proteção preventiva de memória; CSV em transação consistente; TTL informativo separado de alerta acionável. As respectivas regressões foram reexecutadas.

O teste com 12 processos induz falha de banco e verifica 503 com ACK parcial e recuperação idempotente. **Não determina a causa dos cinco 503 históricos reportados em produção.** A bancada foi recriada quando seu MySQL transitório perdeu um arquivo de redo; dados eram sintéticos e as verificações relevantes foram reexecutadas. Não houve perda ou acesso a banco de produção.

## Aceites externos ainda abertos

- **50:** conferência operacional da cobertura sobre logs reais, prevista no relatório para 30/09. Lacuna sem fonte não pode ser reconstruída pelo plugin.
- **52:** sete dias de observação sem falha, com vencimento informado de 05/10. O pacote não substitui esse período nem cria um agendamento externo.
- **Pipedrive/ads:** mantêm a configuração existente; padrão desligado até ativação explícita. CRM-A01…CRM-A15 continuam pendentes em conta autorizada: campanha/origem/campos/atividade, retorno, fallback, parceiro desconhecido, reuso de oportunidade, contato existente, credencial, 503/429, resposta perdida, consentimento, Meta/Google, chave recusada, eliminação e limites reais. Mocks não encerram esses aceites. LinkedIn/OpenAI nativos continuam dependentes de contrato/acesso/homologação próprios.
- **Search Console:** autorizar/configurar a fonte e importar fotografias reais. A 1.17 oferece contrato de importação, não OAuth/conector Google novo nem consultas detalhadas.
- **Hospedagem:** HTTP real de robots/cache/documentos, aliases da raiz privada, executor/cron, SMTP, proxy e confiança no IP do log. Nenhum pedido à DreamHost é condição para os testes locais concluídos.
- **Ativações opcionais:** tempo ativo continua conforme a preferência existente; ligar explicitamente quando desejado. O plugin não amplia silenciosamente retenções curtas nem marca desconhecido como seguro/humano.

Sem alteração de tema ou implantador. Não há replay, dados digitados, união entre dispositivos, inferência de treinamento de IA ou bloqueio automático de robôs. Acesso de robô, visita encaminhada e referência observada continuam evidências diferentes.
'''
(plugin/'docs/VALIDACAO.md').write_text(validation)
# Item-level disposition from the approved plan; inherited items remain distinguishable.
items=[
('17','Preservado; aceite externo','Pipedrive e ads da 1.16, sem nova frente comercial nesta release.','pipedrive-fila','processar','crm.json; credenciais.json; aceites CRM-A01…A15'),
('36 / 73 / N3','Implementado','LLMS por item, alternativa HTML, geração parcial e retentativas limitadas.','llms-cobertura','executar','editorial.json; llms.json'),
('37','Implementado','Limitação permanente do TTL separada do aviso acionável.','cache-pagina','diagnostico_ttl','obrigatorios.json; transporte.json'),
('38','Critério ajustado conforme plano','Mantém captura/recuperação e mede custo; não promete POST fora de toda janela PSI.','analise','enfileirar','performance/matriz.json; transporte.json'),
('41 / 54 / 75 / N5','Implementado + base preservada','Ofertas no executor; prova de redirect usa apenas dependências pertinentes.','redirects-servico','componentes','obrigatorios.json; novas.json; redirects-bordas.json'),
('42','Implementado','Reparo de migração inválida com evidência e prova explícita do cabeçalho.','navegacao','preparar_1170','core.json; fronteiras.json; upgrade.json'),
('45','Implementado','Painel padrão/tema explícito antes de exibição; preserva foco e controles.','release-1170','catalogo','consentimento-tema.json'),
('50','Aceite operacional aberto','Publicação independente corrigida; observar logs reais conforme data acordada.','acessos-coleta','publicar','fronteiras.json; conferência operacional 30/09'),
('52','Aceite operacional aberto','Regressão de 503/ACK/repetição local aprovada; sete dias em produção são externos.','analise','persistir','concorrencia.json; transporte.json; prazo informado 05/10'),
('59','Base preservada','Separação fbc/fbp, toques e consentimento conservada com origem por sessão.','audiencia','canal','novas.json; contexto-1170.json; capi.json'),
('60','Base preservada','Procedência/ofertas e listas vazias permanecem; sem reconversão histórica.','instalacao','atualizar','upgrade.json; novas.json'),
('61','Documentado + regressão','Ressalva QUERY_STRING documentada; contratos e sondas mantidos.','config-consultas','integracoes','http.json; docs/CONTRACTS.md'),
('62 / 74 / N4','Implementado','Reserva privada mantém modo original; restauração e reativação condicionais.','robots-arquivo','restaurar','robots-1170.json'),
('63 / 65','Base preservada','oEmbed/RSS/autor e hook de autoria; criação de usuário/tema fora do Core.','autoria','iniciar','novas.json; core.json'),
('64','Base preservada','Schema e contrato normalizado, sem abrir escrita livre de cadência.','config-contrato','schema_valor','novas.json; fechamento.json'),
('66','Implementado','Textos de schema e default full correspondem ao escopo efetivo.','modulo-schema-extensao','descricao','docs/REFERENCIA-CATALOGO.md; fechamento.json'),
('67','Base preservada','Carimbo WhatsApp por destino permanece opcional e desligado.','configuracao-atual','catalogo','core.json; docs/LEADS-E-FORMULARIOS.md'),
('68','Base preservada','Saúde conserva formulários e captura.','modulo-endpoint-leads','atividade','core.json; http.json'),
('69','Base preservada','Menu clássico e blocos continuam superfícies válidas.','navegacao','diagnostico','core.json; fronteiras.json'),
('70','Base preservada com limite','Inventário consulta conteúdo salvo; não varre arbitrariamente código de tema.','cta-inventario','consultar','fechamento.json'),
('71 / N1','Implementado','P00 exclui projeções/estado; defaults apenas ausentes, com procedência.','release-1170','materializar_padroes','obrigatorios.json; editorial.json; upgrade.json'),
('72 / N2','Implementado','Histórico 1.16/1.17 por versão, módulo e paginação.','config-consultas','mudancas','obrigatorios.json'),
('76','Implementado','Automação declarada/provável versionada e separada de teste; não bloqueia lead.','audiencia','automacao','editorial.json; contexto-1170.json'),
('77 / 78 / 79','Implementado','Canal/origem IA por sessão com evidência; origem inicial preservada.','audiencia','canal','editorial.json; contexto-1170.json; ux-editorial.json'),
('80','Implementado','Famílias e finalidades nomeadas; Googlebot não é convertido em Gemini.','modulo-acessos-servidor','robos','novas.json; editorial.json'),
('81','Implementado','Tráfego técnico/MCP/admin/asset/varredura fora dos totais editoriais.','modulo-acessos-servidor','caminho','editorial.json; integridade.json'),
('82','Implementado com limite','CIDR/listas oficiais/proxy/expiração; sem persistir IP individual ou afirmar autenticação.','redes-robos','verificar','editorial.json; docs/ANALISAR-PRESENCA-IA.md'),
('83','Implementado','Conteúdo × robôs × visitantes IA; referências observadas separadas e auditadas.','inteligencia','referencia_gravar','editorial.json; ux-editorial.json'),
('84','Implementado','Aviso local de 403/429 com amostra; sem inferir causa ou alterar WAF.','agentes','consultar','novas.json; ux-editorial.json'),
('85','Implementado','GSC page/date ou propriedade por importação autorizada, calendário/ponderação/cobertura.','inteligencia','gsc_importar','editorial.json; integridade.json'),
('86','Implementado','Contribuições/publicação/cobertura: lacuna antiga não bloqueia dia independente; horas acompanham dia.','acessos-coleta','publicar','fronteiras.json; novas.json'),
('87','Implementado com limites','13 meses em agregado editorial anônimo; detalhe/logs seguem retenções explícitas.','editorial','consolidar','fronteiras.json; volume.json; docs/MEDICAO-1.17.md'),
('88 + pedidos desta release','Implementado','Visão geral, Páginas/Artigos/Outros, detalhe, jornadas, IA/Markdown, horários e UX.','medicao-editorial-ui','render','editorial.json; integridade.json; ux-editorial.json; volume.json')]
import re
mapped=[]
for ids,status,change,cls,func,evidence in items:
 file=plugin/'includes'/('class-f3base-'+cls+'.php');line=None
 if file.exists():
  ls=file.read_text().splitlines();line=next((i+1 for i,l in enumerate(ls) if re.search(r'function\s+'+re.escape(func)+r'\s*\(',l)),None)
 mapped.append({'pedido':ids,'estado':status,'mudanca':change,'arquivo':str(file.relative_to(plugin)) if file.exists() else None,'funcao':func if line else None,'linha':line,'evidencia':evidence})
maptext='# Mapa da entrega — 1.17.0\n\nDisposição dos pedidos do plano aprovado, revisão 2. “Implementado” descreve o pacote; a cobertura e os aceites externos estão em VALIDACAO.md. Código em caminhos relativos à raiz do plugin.\n\n| Pedido | Disposição | Resultado | Fonte | Evidência / pendência |\n|---|---|---|---|---|\n'
for r in mapped:
 loc=(r['arquivo'] or 'docs/CONTRACTS.md')+((':'+str(r['linha'])+' · '+r['funcao']+'()') if r['linha'] else '')
 maptext+=f"| {r['pedido']} | {r['estado']} | {r['mudanca']} | `{loc}` | {r['evidencia']} |\n"
maptext+='''
## Decisões preservadas

Não incluídos, conforme plano: monitoramento contínuo de respostas de modelos; prova automática de treinamento/recomendações; consultas detalhadas e novo OAuth Google; identificação criptográfica de robôs; bloqueios/WAF automáticos; replay/conteúdo digitado; ligação entre dispositivos; novas integrações comerciais. Cada um exige dados, autorização ou escopo diferentes. A versão oferece acesso, encaminhamento e referência observada com suas limitações.

Nenhuma decisão de produto impede instalar a release. Ativações por site continuam explícitas: tempo ativo, fonte GSC, confiança no IP do log e integrações comerciais. Retenções menores, opções desligadas e listas vazias do proprietário permanecem.
'''
(plugin/'docs/MAPA-ENTREGA-1.17.md').write_text(maptext);(plugin/'docs/dados/entrega-1.17.json').write_text(json.dumps({'versao':'1.17.0','plano':'revisao_2','itens':mapped},ensure_ascii=False,indent=2)+'\n')
report='''# Entrega — F3 Base Core 1.17.0

A 1.17.0 implementa o plano aprovado (revisão 2). O foco é medir conteúdo orgânico, acompanhar jornadas e separar as três evidências de IA: requisições de robôs, visitas encaminhadas e referências observadas.

## Arquivos e instalação

- **base-site-core-fator3-1.17.0.zip:** instalador para WordPress.
- **fontes-core-f3base-1.17.0.zip:** código, plano, testes, capturas e evidências; não é instalável.
- **manifesto-1.17.0.json:** SHA-256 de cada arquivo do plugin.
- **SHA256SUMS-1.17.0.txt:** conferência dos arquivos entregues.

Instale o ZIP do plugin em site novo ou atualize uma 1.16.0 concluída. A documentação vem em `docs/` no plugin e é legível pelo serviço autenticado `f3base/documentacao-ler`; comece em DOCUMENTACAO.md e MEDICAO-1.17.md. Não alterei sites de produção.

## Principais resultados

- Medição organizada em Visão geral, Conteúdo, Sessões, Aquisição, IA e robôs, Conversão e Técnico.
- Páginas e artigos separados pelo tipo WordPress; consumo, origem, continuidade, ações e IA no detalhe.
- Filtro por sessão e jornada completa, com identidade de carregamento, horários legíveis e CSV consistente.
- Robôs por conteúdo/HTML/Markdown, família e status; visitas vindas de OpenAI/Claude/Gemini e outras origens mantidas separadas das requisições dos robôs.
- Origem de sessão, automação e cobertura explícitas; referências IA revisáveis e importação Search Console por página.
- Correções de LLMS, robots, defaults/P00, publicação dos logs, navegação, TTL, consentimento e executor.

'''+validation+'\n---\n\n'+maptext
(OUT/'relatorio-core-1.17.0.md').write_text(report)
# Keep installed index up to date.
p=plugin/'docs/DOCUMENTACAO.md';s=p.read_text();s=s if 'MAPA-ENTREGA-1.17.md / dados/entrega-1.17.json' in s else s.replace('| VALIDACAO.md | Evidências locais, CRM-A01…A15 e pendências externas |','| VALIDACAO.md | Evidências locais, CRM-A01…A15 e pendências externas |\n| MAPA-ENTREGA-1.17.md / dados/entrega-1.17.json | Disposição de cada pedido, código e evidência |');p.write_text(s)
subprocess.run(['python3',str(ROOT/'montar-release.py'),'--saida',str(OUT)],check=True)
# Sources include the only accepted upgrade fixture; prefer the packaged reference at reproduction time.
ref=ROOT/'referencias';ref.mkdir(exist_ok=True);shutil.copy2(BASE/'deliverables/1.16.0/base-site-core-fator3-1.16.0.zip',ref/'base-site-core-fator3-1.16.0.zip')
(ROOT/'README.md').write_text('''# Fontes — F3 Base Core 1.17.0

`fontes/plugin/` é o conteúdo exato do instalador. `suite/versao-1170/README.md` explica a bancada isolada; nunca executar fixtures em produção. `PLANO-APROVADO.md` é o plano de referência. A única base é uma 1.16.0 concluída ou site novo, sem downgrade.

`montar-release.py --saida /DESTINO` reconstrói o instalador e seu manifesto, com timestamps determinísticos. `fechar-release.py` reúne relatório/fontes/hash a partir das evidências. Os runtimes PHP/MySQL/WordPress/Chrome não são distribuídos. A referência 1.16 em `referencias/` serve apenas ao teste de atualização; não há runtime de compatibilidade no plugin.

Leia `fontes/plugin/docs/VALIDACAO.md` e `MAPA-ENTREGA-1.17.md` para os limites e aceites externos.\n''')
(OUT/'manifesto-1.17.0.json').write_text((OUT/'manifesto-1.17.0.json').read_text())
source=OUT/'fontes-core-f3base-1.17.0.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(ROOT.rglob('*')):
  rel=p.relative_to(ROOT)
  if not p.is_file() or any(x in rel.parts for x in ['.git','node_modules','__pycache__','patches']) or p.suffix=='.pyc':continue
  i=zipfile.ZipInfo('core-1.17.0/'+rel.as_posix(),(2026,9,29,0,0,0));i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,p.read_bytes())
files=['base-site-core-fator3-1.17.0.zip','fontes-core-f3base-1.17.0.zip','manifesto-1.17.0.json','relatorio-core-1.17.0.md']
(OUT/'SHA256SUMS-1.17.0.txt').write_text(''.join(hashlib.sha256((OUT/f).read_bytes()).hexdigest()+'  '+f+'\n' for f in files))
print(json.dumps({'ok':True,'verificacoes':total,'files':[{'name':f,'bytes':(OUT/f).stat().st_size} for f in files+['SHA256SUMS-1.17.0.txt']]},ensure_ascii=False))
