# 1.17.0 — 29/09/2026

Medição editorial por conteúdo, sessões e aquisição; origem de IA, automação explicável, HTML/Markdown nos logs, verificação de listas oficiais, referências observadas, Search Console autorizado e histórico anônimo. Nova interface com cobertura, horários legíveis e CSV filtrado.

Correções: LLMS por item e retentativas limitadas; robots com modo original; fronteiras de publicação dos logs; defaults/P00 e histórico 1.16/1.17; ofertas no executor; prova pública de navegação; consentimento tema; dependências de redirects e diagnóstico TTL/schema. Base exclusiva 1.16.0 concluída ou instalação nova.

# 1.16.0 — 2026-09-29

Revisão 2 do pacote: captura de CTA sem WhatsApp, invalidação por revisão de credencial/configuração no Pipedrive e Meta, releitura de campos após resposta perdida e recusa de alternativas sem catálogo confirmado. Mesmos caminhos de instalação; sem migração adicional.

- Base exclusiva: instalação nova ou 1.15.0 concluída; recuperação na própria versão, sem downgrade.
- Navegação tipada (tema/menu clássico/bloco), busca paginada, seção correta no admin e ajuda unificada por campo.
- Agentes e buscadores: OpenAI, Claude, Gemini e famílias específicas; frequência com cobertura, horários e CSV.
- Assunto de e-mail sem nome duplicado, classificação de CTA por destino, inventário limitado e atribuição idempotente apesar de cookies auxiliares.
- Pipedrive opcional: segredos cifrados, verificação de conta/campos, intenção durável, fila com checkpoints, conciliação, prévia, jornada limitada e eliminação conservadora.
- Origens nativas Meta/Google com deduplicação/retomada/tombstones; OpenAI oppref web. LinkedIn e captura nativa OpenAI condicionados ao acesso/contrato.
- Correções de cache/redirects, autoria pública, backups privados, prova de ofertas, consentimento e publicação LLMS; retentativa de análise após 503 corrigida.
- Contrato 4.0.0, perfil piso-padrao-3.2 e documentação instalada. Homologações remotas explicitamente pendentes em VALIDACAO.md.

# Changelog

## 1.15.0 — 2026-09-28

- Somente instalação nova e atualização 1.14.0; política, listas vazias e escolhas preservadas.
- Redirects recuperam QUERY_STRING original, respeitam veto por par e consolidam provas por variante em lotes com concorrência/expiração.
- Atribuição/consentimento comum e envelope CAPI a partir do lead persistido, incluindo formulário, fbc/fbp e marca de teste.
- Contrato 3.0.0: mescla parcial por dependências, diagnóstico por caminho, simulação sem efeitos, auditoria ability, piso integral e respostas compactas com evidência única.
- Ofertas múltiplas por plano/período, preço brasileiro, mínimo/grátis/sob consulta, prova pública e conflito de emissor; snapshot privado na migração inequívoca.
- Person incluído na verificação de recursos sameAs; navegação distingue referência válida e vínculo observado.
- Análise com prazo absoluto de 5 segundos após load e saída antecipada; diagnóstico do TTL sem confundir configuração e garantia de idade.
- Confirmação sem JS com noindex/nofollow coerentes; pares de cores acessíveis no consentimento e cadência documentada como registro local.
- Documentação e exemplos novos dentro do instalador; implantador/tema e CRM fora do escopo.

## 1.14.0 — 2026-09-28

- Configurações em sub-abas, ajuda por campo com vantagens/limitações, default de e-mail administrativo somente quando ausente e entrega do índice por arquivo gerado.
- Marcação simples de teste por cookie/cabeçalho/contexto de sonda, preservada em filas; filtros padrão e políticas independentes dos destinos externos/avisos.
- Atribuição comum por anúncio, primeiro/último toque, IDs canônicos e documentação de cruzamentos Meta/Google/LinkedIn.
- Medição em áreas, filtros SQL antes dos limites, cobertura explícita, exportação e jornada; caixa de entrada e editor de formulário organizados.
- Análise com defer, confirmação por evento, idempotência concorrente, retentativas limitadas e diagnóstico de armazenamento. Rapidez de preenchimento deixa de bloquear envio isoladamente.
- Gerações LLMS retomáveis, preservação de publicação e retirada prioritária; operação explícita de cabeçalhos com backup, revisão e recuperação.
- Redirects com preservação de query, host externo autorizado e verificação final/âncora; navegação clássica opcional, instrumentação de CTA e dados estruturados.
- Classificação positiva de acessos e repetição separada; proteção pública configurável, CSS de consentimento por variáveis e cadência observável.
- Documentação técnica completa em diretório protegido, dicionário JSON/Markdown, métricas, SQL e guia de agentes distribuídos no instalador.


## 1.13.0 — 2026-09-24

- Relatórios integrados no painel, CSV e abilities; jornada no contato; cobertura, filtros e comparação.
- Coleta local de funil, navegação, atribuição de sessão, dispositivo e revisão final de vitais; consentimento, quotas e deduplicação.
- Snapshot de opções estruturadas e histórico transacional de atendimento.
- Política explícita Todas/Selecionadas/Nenhuma, prévia de alterações, revisões e gestão por agentes reversível.
- Instalação direta e atualização mínima 1.12.0; preserva políticas existentes, inclusive lista vazia (backlog 29), sem reabrir permissões.
- Sonda de cache reconhece artefatos `wp-cache-*.php` e HTML (backlog 28), sem reduzir a exigência de corpo vazio.
- Retira gravação Flamingo/CPT, reparador histórico, conversão antiga da fila CAPI e desativação automática de cópias antigas.
- Documentação operacional e de agentes incluída no plugin instalado; contrato 2.0.0.

## Histórico até 1.12.0

# Alterações — 1.12.0 — 24/09/2026

- Seletores para campos enumerados; caixas de seleção pesquisáveis para blocos, preservando identificadores indisponíveis.
- Contato organizado em avisos internos, WhatsApp e instrumentação dos botões, com rótulos e ajuda. Até cinco destinatários em campos de e-mail.
- Operação Core integrada à aba Operação do menu F3 Base; o endereço administrativo anterior encaminha ao novo.
- Política de gestão e catálogo operável habilitados na primeira atualização, com fotografia, revisão e marcador por site.
- Leads com sessão canônica, correlação, post_id resolvido no servidor e contexto de IP/user agent. Ausência de sessão tem motivo; não se inventa vínculo histórico.
- Métodos de CTA definidos pelo destino, incluindo `contato_cta` para destino interno, telefone e e-mail. Abrir diálogo continua sem registrar lead.
- Reparo em lotes dos registros já copiados, com evidência preservada ou mapeamento explícito de canal/formulário/campos. Nenhum importador CF7/Flamingo no runtime.
- Saúde e instruções do endpoint identificam o destino `f3base_leads`.
- Arquivos sem `max_bytes` ou com zero ficam sem teto do plugin; extensões vazias não restringem. Limites positivos existentes são preservados.
- Provisionamento e teste de escrita/leitura/remoção da pasta privada; diagnóstico distingue ausência criável e impossibilidade.
- Sonda HTTP do artefato de cache exige corpo vazio, persiste prova e afeta o sucesso agregado na mesma cadência de tokens.
- Web Vitals 6.2.1 local carregado após `load`, com retenção mínima das interações curtas anteriores e correção local de CLS preservada. O arquivo anterior já era minificado; não há alegação de ganho de nota por minificação.
- Resposta ao visitante opcional por formulário, independente do aviso interno, com estado persistente, reserva de envio, limite de frequência e retentativa explícita para estado incerto.
- Documentação versionada incluída no instalador e consultável por ability.
