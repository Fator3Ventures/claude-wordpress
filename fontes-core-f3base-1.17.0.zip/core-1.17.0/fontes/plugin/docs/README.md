# Base Site Core Fator3 1.17.0

Instale `base-site-core-fator3-1.17.0.zip` pelo WordPress. O ZIP de fontes e testes não é instalável. Caminhos suportados: instalação nova ou atualização de uma **1.16.0 concluída**. Recuperação e retomada ocorrem na própria 1.17; não há suporte a downgrade.

A medição passa a priorizar conteúdo orgânico, sessões e presença em IA. Páginas e Artigos usam o tipo real do WordPress. Requisições de robôs, visitas encaminhadas por IA e referências com evidência são medidas separadas. O painel oferece jornadas por sessão, tempo e rolagem quando coletados, origem da entrada, HTML/Markdown, exportação e cobertura.

A versão também corrige publicação parcial de LLMS, preservação/restauração do robots, publicação de logs com lacunas antigas, defaults/P00, verificação da navegação, agenda de ofertas, dependências de redirects e apresentação do consentimento.

Preferências explícitas são preservadas, incluindo `false`, `0` e `[]`. Tempo ativo continua desligado por padrão. Integrações comerciais existentes continuam opcionais e desligadas em instalação nova. A atualização não dispara envios retroativos ao CRM. Não altera temas, implantador ou sites da frota.

Novos agregados editoriais duram 13 meses por padrão, sem IDs de sessão/visitante. Não ampliam a retenção dos eventos individuais nem dos contatos. Logs diários conservam a política existente. Histórico perdido não é reconstruído por suposição.

Leia [DOCUMENTACAO.md](DOCUMENTACAO.md), [MEDICAO-1.17.md](MEDICAO-1.17.md) e [VALIDACAO.md](VALIDACAO.md). Todos acompanham o plugin e estão disponíveis a administradores por `f3base/documentacao-ler`.
