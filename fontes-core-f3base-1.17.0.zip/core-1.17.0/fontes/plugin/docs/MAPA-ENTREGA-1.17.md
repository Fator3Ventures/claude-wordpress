# Mapa da entrega — 1.17.0

Disposição dos pedidos do plano aprovado, revisão 2. “Implementado” descreve o pacote; a cobertura e os aceites externos estão em VALIDACAO.md. Código em caminhos relativos à raiz do plugin.

| Pedido | Disposição | Resultado | Fonte | Evidência / pendência |
|---|---|---|---|---|
| 17 | Preservado; aceite externo | Pipedrive e ads da 1.16, sem nova frente comercial nesta release. | `includes/class-f3base-pipedrive-fila.php:166 · processar()` | crm.json; credenciais.json; aceites CRM-A01…A15 |
| 36 / 73 / N3 | Implementado | LLMS por item, alternativa HTML, geração parcial e retentativas limitadas. | `includes/class-f3base-llms-cobertura.php:65 · executar()` | editorial.json; llms.json |
| 37 | Implementado | Limitação permanente do TTL separada do aviso acionável. | `includes/class-f3base-cache-pagina.php:685 · diagnostico_ttl()` | obrigatorios.json; transporte.json |
| 38 | Critério ajustado conforme plano | Mantém captura/recuperação e mede custo; não promete POST fora de toda janela PSI. | `includes/class-f3base-analise.php:93 · enfileirar()` | performance/matriz.json; transporte.json |
| 41 / 54 / 75 / N5 | Implementado + base preservada | Ofertas no executor; prova de redirect usa apenas dependências pertinentes. | `includes/class-f3base-redirects-servico.php:593 · componentes()` | obrigatorios.json; novas.json; redirects-bordas.json |
| 42 | Implementado | Reparo de migração inválida com evidência e prova explícita do cabeçalho. | `includes/class-f3base-navegacao.php:45 · preparar_1170()` | core.json; fronteiras.json; upgrade.json |
| 45 | Implementado | Painel padrão/tema explícito antes de exibição; preserva foco e controles. | `includes/class-f3base-release-1170.php:14 · catalogo()` | consentimento-tema.json |
| 50 | Aceite operacional aberto | Publicação independente corrigida; observar logs reais conforme data acordada. | `includes/class-f3base-acessos-coleta.php:157 · publicar()` | fronteiras.json; conferência operacional 30/09 |
| 52 | Aceite operacional aberto | Regressão de 503/ACK/repetição local aprovada; sete dias em produção são externos. | `includes/class-f3base-analise.php:111 · persistir()` | concorrencia.json; transporte.json; prazo informado 05/10 |
| 59 | Base preservada | Separação fbc/fbp, toques e consentimento conservada com origem por sessão. | `includes/class-f3base-audiencia.php:20 · canal()` | novas.json; contexto-1170.json; capi.json |
| 60 | Base preservada | Procedência/ofertas e listas vazias permanecem; sem reconversão histórica. | `includes/class-f3base-instalacao.php:27 · atualizar()` | upgrade.json; novas.json |
| 61 | Documentado + regressão | Ressalva QUERY_STRING documentada; contratos e sondas mantidos. | `includes/class-f3base-config-consultas.php:127 · integracoes()` | http.json; docs/CONTRACTS.md |
| 62 / 74 / N4 | Implementado | Reserva privada mantém modo original; restauração e reativação condicionais. | `includes/class-f3base-robots-arquivo.php:352 · restaurar()` | robots-1170.json |
| 63 / 65 | Base preservada | oEmbed/RSS/autor e hook de autoria; criação de usuário/tema fora do Core. | `includes/class-f3base-autoria.php:15 · iniciar()` | novas.json; core.json |
| 64 | Base preservada | Schema e contrato normalizado, sem abrir escrita livre de cadência. | `includes/class-f3base-config-contrato.php:18 · schema_valor()` | novas.json; fechamento.json |
| 66 | Implementado | Textos de schema e default full correspondem ao escopo efetivo. | `includes/class-f3base-modulo-schema-extensao.php:50 · descricao()` | docs/REFERENCIA-CATALOGO.md; fechamento.json |
| 67 | Base preservada | Carimbo WhatsApp por destino permanece opcional e desligado. | `includes/class-f3base-configuracao-atual.php:15 · catalogo()` | core.json; docs/LEADS-E-FORMULARIOS.md |
| 68 | Base preservada | Saúde conserva formulários e captura. | `includes/class-f3base-modulo-endpoint-leads.php:204 · atividade()` | core.json; http.json |
| 69 | Base preservada | Menu clássico e blocos continuam superfícies válidas. | `includes/class-f3base-navegacao.php:54 · diagnostico()` | core.json; fronteiras.json |
| 70 | Base preservada com limite | Inventário consulta conteúdo salvo; não varre arbitrariamente código de tema. | `includes/class-f3base-cta-inventario.php:7 · consultar()` | fechamento.json |
| 71 / N1 | Implementado | P00 exclui projeções/estado; defaults apenas ausentes, com procedência. | `includes/class-f3base-release-1170.php:35 · materializar_padroes()` | obrigatorios.json; editorial.json; upgrade.json |
| 72 / N2 | Implementado | Histórico 1.16/1.17 por versão, módulo e paginação. | `includes/class-f3base-config-consultas.php:109 · mudancas()` | obrigatorios.json |
| 76 | Implementado | Automação declarada/provável versionada e separada de teste; não bloqueia lead. | `includes/class-f3base-audiencia.php:7 · automacao()` | editorial.json; contexto-1170.json |
| 77 / 78 / 79 | Implementado | Canal/origem IA por sessão com evidência; origem inicial preservada. | `includes/class-f3base-audiencia.php:20 · canal()` | editorial.json; contexto-1170.json; ux-editorial.json |
| 80 | Implementado | Famílias e finalidades nomeadas; Googlebot não é convertido em Gemini. | `includes/class-f3base-modulo-acessos-servidor.php:183 · robos()` | novas.json; editorial.json |
| 81 | Implementado | Tráfego técnico/MCP/admin/asset/varredura fora dos totais editoriais. | `includes/class-f3base-modulo-acessos-servidor.php:243 · caminho()` | editorial.json; integridade.json |
| 82 | Implementado com limite | CIDR/listas oficiais/proxy/expiração; sem persistir IP individual ou afirmar autenticação. | `includes/class-f3base-redes-robos.php:44 · verificar()` | editorial.json; docs/ANALISAR-PRESENCA-IA.md |
| 83 | Implementado | Conteúdo × robôs × visitantes IA; referências observadas separadas e auditadas. | `includes/class-f3base-inteligencia.php:98 · referencia_gravar()` | editorial.json; ux-editorial.json |
| 84 | Implementado | Aviso local de 403/429 com amostra; sem inferir causa ou alterar WAF. | `includes/class-f3base-agentes.php:62 · consultar()` | novas.json; ux-editorial.json |
| 85 | Implementado | GSC page/date ou propriedade por importação autorizada, calendário/ponderação/cobertura. | `includes/class-f3base-inteligencia.php:128 · gsc_importar()` | editorial.json; integridade.json |
| 86 | Implementado | Contribuições/publicação/cobertura: lacuna antiga não bloqueia dia independente; horas acompanham dia. | `includes/class-f3base-acessos-coleta.php:157 · publicar()` | fronteiras.json; novas.json |
| 87 | Implementado com limites | 13 meses em agregado editorial anônimo; detalhe/logs seguem retenções explícitas. | `includes/class-f3base-editorial.php:162 · consolidar()` | fronteiras.json; volume.json; docs/MEDICAO-1.17.md |
| 88 + pedidos desta release | Implementado | Visão geral, Páginas/Artigos/Outros, detalhe, jornadas, IA/Markdown, horários e UX. | `includes/class-f3base-medicao-editorial-ui.php:14 · render()` | editorial.json; integridade.json; ux-editorial.json; volume.json |

## Decisões preservadas

Não incluídos, conforme plano: monitoramento contínuo de respostas de modelos; prova automática de treinamento/recomendações; consultas detalhadas e novo OAuth Google; identificação criptográfica de robôs; bloqueios/WAF automáticos; replay/conteúdo digitado; ligação entre dispositivos; novas integrações comerciais. Cada um exige dados, autorização ou escopo diferentes. A versão oferece acesso, encaminhamento e referência observada com suas limitações.

Nenhuma decisão de produto impede instalar a release. Ativações por site continuam explícitas: tempo ativo, fonte GSC, confiança no IP do log e integrações comerciais. Retenções menores, opções desligadas e listas vazias do proprietário permanecem.
