# Validação — F3 Base Core 1.17.0

Entrega de 29/09/2026. Instalação nova ou atualização de uma **1.16.0 concluída**, com retomada na própria versão. Sem compatibilidade anterior/downgrade. **Validação local concluída nos cenários abaixo; nenhum site da frota foi alterado e korvena.net.br não foi testado.**

## Ambiente e alcance

WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP Super Cache 3.1.3, Chrome Headless Shell 151 e Lighthouse 13.5.0. Dados sintéticos, e-mails bloqueados e transporte remoto interceptado nas integrações. HTTP local usa oito workers. Os resultados e capturas acompanham `suite/versao-1170/evidencias/` no pacote de fontes.

**537 verificações aprovadas** nos conjuntos abaixo, mais dez etapas de instalação/atualização. Os números são asserções, não cenários independentes. Testes de serviços e interface foram executados localmente; não equivalem à homologação das contas comerciais ou da hospedagem.

| Conjunto | Aprovadas | Evidência |
|---|---:|---|
| Contratos, captura, navegação e segredos | 74 | `core.json` |
| Pipedrive com transporte simulado | 26 | `crm.json` |
| Regressão CAPI | 10 | `capi.json` |
| Bordas de contratos e relatórios | 17 | `bordas.json` |
| Publicação LLMS | 23 | `llms.json` |
| Ofertas, atribuição, agentes e reconciliação | 37 | `novas.json` |
| Paginação e retomada de origens | 14 | `origens.json` |
| Conteúdo, sessão, aquisição, IA, referências e GSC | 65 | `editorial.json` |
| Rotas, coortes, histórico e permissões | 12 | `integridade.json` |
| Cobertura de logs, horas e rollup idempotente | 11 | `fronteiras.json` |
| Bytes, modos e reativação de robots | 8 | `robots-1170.json` |
| P00, mudanças, TTL e executor | 13 | `obrigatorios.json` |
| Catálogo/volume/orçamento/limite de caminhos | 9 | `volume.json` |
| HTTP local, formulário sem JS e cache PHP | 23 | `http.json` |
| Redirects e evidências públicas locais | 21 | `redirects-bordas.json` |
| Troca concorrente de credenciais | 9 | `credenciais.json` |
| Documentação instalada e contratos | 17 | `fechamento.json` |
| Telas administrativas | 22 | `admin.json` |
| Conteúdo → sessões → jornada / CSV / teclado / celular | 20 | `ux-editorial.json` |
| Painel padrão/tema, contraste e tamanhos | 60 | `consentimento-tema.json` |
| Transporte, falhas, consentimento e recuperação | 22 | `transporte.json` |
| Identidade por carregamento e origem da sessão | 15 | `contexto-1170.json` |
| 12 processos, deduplicação, ACK parcial e recuperação | 9 | `concorrencia.json` |

Instalação/atualização: instalar, semear dados, atualizar, repetir e retomar, para site novo e origem 1.16.0 real. Baseline SHA-256 `94978e498eb12475480cc570d8f03ca8fca9cde4a79e8aeefbe705f0dbdab344`. Preservados contatos, listas vazias, `false`, política e credenciais cifradas. Configuração preexistente inválida é mantida e diagnosticada, sem impedir o preenchimento das outras opções. Sintaxe aprovada em 130 arquivos PHP e 22 JS; sete assets recompostos e conferidos com Terser fixado.

## Medição, volume e UX

O catálogo de 1105 conteúdos foi concluído em 6 lotes. A consulta de 20000 eventos retornou 10 mil visualizações e 2 mil sessões, em 949.6 ms, com pico de 106.5 MiB na bancada de 512 MiB. Em 128 MiB houve recusa controlada do recorte, sem totais parciais. O limite de 750 caminhos mantém as demais requisições em uma linha de excesso, sem conservar identidade editorial indevida.

A interface foi percorrida em 1440 e 360 px: áreas, detalhe com cinco eixos, seleção de sessão a partir de artigo, jornada além do conteúdo selecionado, exportação com sessão/UTC/fuso, foco por teclado e ausência de erros JS. Tabelas extensas têm rolagem própria. Consentimento em modo tema foi verificado com fundos/cores variados; isso não certifica CSS de cada tema da frota.

A identidade por carregamento cobre reapresentação do mesmo documento, novo carregamento, separação de abas, origem externa imitadora, troca de sessão e revogação. `pageshow.persisted`/preservação de contexto foram ensaios controlados: **não provam elegibilidade real para bfcache em todo navegador**. Referências IA e GSC usam dados sintéticos autorizados na bancada, com revisão, duplicidade, propriedade e cálculo ponderado. A lista de IPs usa fixtures; disponibilidade externa futura não é garantida.

## Desempenho

Duas rodadas com presets padrão Lighthouse, uma mobile e uma desktop, sem ampliar as janelas. HTML de HIT WP Super Cache foi reproduzido localmente; código Google capturado foi servido localmente, sem envio comercial. Não mede latência de rede da hospedagem/Google nem atribui ganho causal à versão.

| Perfil | Nota | LCP ms | TBT ms | POST de análise na janela |
|---|---:|---:|---:|---|
| mobile | 82 | 4732 | 14.5 | não observado |
| desktop | 99 | 872 | 0.0 | 2 requisições; HTTP 200/200 |

A rodada desktop confirmou os três eventos enviados. Adiar cinco segundos após load continua sem garantir ausência no trace; o transporte prioriza captura e descarga nas saídas. Trace, DevTools e configurações resolvidas acompanham a fonte. É um ensaio da implementação nesta bancada, não um benchmark causal ou byte a byte de cada ajuste final de documentação/validação de origem.

## Correções verificadas durante o fechamento

Além dos itens planejados, o fechamento corrigiu: totais fora do recorte IA; rota de termo renomeado/excluído; preservação do histórico sem navegação, sem colapsar todos os eventos numa página; contagem do excesso de caminhos após retirar as dimensões editoriais; fotografia atual dos robôs respeitando filtros; proteção preventiva de memória; CSV em transação consistente; TTL informativo separado de alerta acionável. As respectivas regressões foram reexecutadas.

O teste com 12 processos induz falha de banco e verifica 503 com ACK parcial e recuperação idempotente. **Não determina a causa dos cinco 503 históricos reportados em produção.** A bancada foi recriada quando seu MySQL transitório perdeu um arquivo de redo; dados eram sintéticos e as verificações relevantes foram reexecutadas. Não houve perda ou acesso a banco de produção.

## Aceites externos ainda abertos

- **50:** conferência operacional da cobertura sobre logs reais, prevista no relatório para 30/09. Lacuna sem fonte não pode ser reconstruída pelo plugin.
- **52:** sete dias de observação sem falha, com vencimento informado de 05/10. O pacote não substitui esse período nem cria um agendamento externo.
- **Pipedrive/ads:** mantêm a configuração existente; padrão desligado até ativação explícita. CRM-A01…CRM-A15 continuam pendentes em conta autorizada: campanha/origem/campos/atividade, retorno, fallback, parceiro desconhecido, reuso de oportunidade, contato existente, credencial, 503/429, resposta perdida, consentimento, Meta/Google, chave recusada, eliminação e limites reais. Mocks não encerram esses aceites. LinkedIn/OpenAI nativos continuam dependentes de contrato/acesso/homologação próprios.
- **Search Console:** autorizar/configurar a fonte e importar fotografias reais. A 1.17 oferece contrato de importação, não OAuth/conector Google novo nem consultas detalhadas.
- **Hospedagem:** HTTP real de robots/cache/documentos, aliases da raiz privada, executor/cron, SMTP, proxy e confiança no IP do log. Nenhum pedido à DreamHost é condição para os testes locais concluídos.
- **Ativações opcionais:** tempo ativo continua conforme a preferência existente; ligar explicitamente quando desejado. O plugin não amplia silenciosamente retenções curtas nem marca desconhecido como seguro/humano.

Sem alteração de tema ou implantador. Não há replay, dados digitados, união entre dispositivos, inferência de treinamento de IA ou bloqueio automático de robôs. Acesso de robô, visita encaminhada e referência observada continuam evidências diferentes.
