> Atualização 1.17.0: consulte MEDICAO-1.17.md para as novas métricas editoriais, cobertura, automação, navegação comum e tabelas. As definições anteriores abaixo continuam aplicáveis aos serviços comerciais/operacionais que nomeiam. Não reutilize seus limites ou denominadores no relatório editorial.

# Dicionário de dados — 1.17.0

Estrutura lida do MySQL da bancada desta versão. Tipos e índices abaixo são do schema efetivo. O prefixo é resolvido por site; IDs externos e opacos permanecem strings. Nenhuma tabela identifica uma pessoa pela sessão, UA ou IP.

## Tempo, escopo e retenção

Datas de filtros usam o fuso WordPress; início inclusivo, fim exclusivo no começo do dia seguinte. `datetime` de leads é UTC. Epoch é em segundos UTC; `ms` é relativo à âncora. `dia` usa o calendário da regra e não é um instante UTC. Os toques publicitários são strings numéricas de epoch em segundos.

Contatos seguem `f3base_retencao_meses`; agregados/vitais seguem retenção de comportamento; eventos e análise seguem `retencao_eventos_dias`; logs seguem sua própria retenção. Histórico de atendimento acompanha o lead. Anexos/concessões seguem eliminação do contato/material e expiração aplicável. Reservas, quotas e fila têm expiração própria. Consulte valores efetivos no site; os padrões não comprovam disponibilidade histórica.

Ausência histórica, dado não aplicável e valor zero precisam ser declarados separadamente. `nao_marcado` inclui histórico sem evidência de teste; a atualização não reclassifica retrospectivamente por IP/horário. Disponível desde a base 1.12 significa que o campo já existia naquela base, não que foi introduzido exatamente nessa versão.

## f3base_acessos

Uma combinação de dia, classificação de agente/caminho, caminho, HTTP e método.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `dia` | `date` / não | dia YYYY-MM-DD no calendário da regra | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `agente` | `varchar(64)` / não | conforme semântica | Código da evidência de UA/origem: não comprova presença humana. | base 1.12.0 ou anterior |
| `classe_caminho` | `varchar(16)` / não | conforme semântica | Categoria de privacidade/rota aplicada pelo parser; query não é preservada. | base 1.12.0 ou anterior |
| `caminho` | `varchar(191)` / não | conforme semântica | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `status` | `smallint unsigned` / não | conforme semântica | Código HTTP observado no log. | base 1.12.0 ou anterior |
| `metodo` | `varchar(5)` / não | conforme semântica | Método HTTP normalizado do log, não método de contato. | base 1.12.0 ou anterior |
| `contagem` | `bigint unsigned` / não | conforme semântica | Quantidade agregada na granularidade da linha. | base 1.12.0 ou anterior |

Índices: agregado (dia, agente, classe_caminho, caminho, status, metodo) único; dia_classe (dia, classe_caminho).

## f3base_acessos_contribuicoes

Contribuição por arquivo/fonte e chave agregada, com versão de regra.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `fonte` | `char(64)` / não | conforme semântica | Identificador da contribuição do arquivo de log; permite substituição da mesma janela sem soma duplicada. | base 1.12.0 ou anterior |
| `chave` | `char(64)` / não | conforme semântica | Identificador composto/hash da granularidade ou da quota; não é visitante. | base 1.12.0 ou anterior |
| `regra` | `char(64)` / não | conforme semântica | Versão da regra de calendário/agregação/classificação. | base 1.12.0 ou anterior |
| `dia` | `date` / não | dia YYYY-MM-DD no calendário da regra | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `agente` | `varchar(64)` / não | conforme semântica | Código da evidência de UA/origem: não comprova presença humana. | base 1.12.0 ou anterior |
| `classe_caminho` | `varchar(16)` / não | conforme semântica | Categoria de privacidade/rota aplicada pelo parser; query não é preservada. | base 1.12.0 ou anterior |
| `caminho` | `varchar(191)` / não | conforme semântica | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `status` | `smallint unsigned` / não | conforme semântica | Código HTTP observado no log. | base 1.12.0 ou anterior |
| `metodo` | `varchar(5)` / não | conforme semântica | Método HTTP normalizado do log. | base 1.12.0 ou anterior |
| `contagem` | `bigint unsigned` / não | conforme semântica | Quantidade agregada na granularidade da linha. | base 1.12.0 ou anterior |

Índices: PRIMARY (fonte, chave) único; dia_regra (dia, regra).

## f3base_analise

Um evento por evento; vital conserva a última sequência dessa identidade.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `id` | `bigint unsigned` / não | conforme semântica | Chave física local. Não identifica pessoa ou anúncio. | 1.13.0 |
| `evento` | `char(32)` / não | conforme semântica | Identificador de evento de análise. Atualizações de vitais mantêm o mesmo ID. | 1.13.0 |
| `visitante` | `char(32)` / não | conforme semântica | Identificador local pseudônimo do navegador, sujeito a consentimento e expiração. | 1.13.0 |
| `sessao` | `char(32)` / não | conforme semântica | Identificador analítico opcional, originado no navegador; não equivale a pessoa. | 1.13.0 |
| `classe_trafego` | `varchar(16)` / não | conforme semântica | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. Valores: `nao_marcado`, `teste`. | 1.14.0 |
| `navegacao` | `char(32)` / não | conforme semântica | Identificador de carregamento/aba; não é sessão e não atravessa automaticamente todos os carregamentos. | 1.13.0 |
| `tipo` | `varchar(20)` / não | conforme semântica | Tipo do evento ou da reserva; consultar enum da tabela. Valores: `pagina`, `form_vista`, `form_inicio`, `form_tentativa`, `form_erro`, `vital`. | 1.13.0 |
| `caminho` | `varchar(190)` / não | conforme semântica | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | 1.13.0 |
| `formulario` | `varchar(80)` / não | conforme semântica | ID do formulário cadastrado ou identificador de fluxo do CTA; método distingue os dois. | 1.13.0 |
| `formulario_revisao` | `varchar(64)` / não | conforme semântica | Hash da definição do formulário no instante da captura. | 1.13.0 |
| `correlacao` | `varchar(64)` / não | conforme semântica | Identificador declarado da instância/submissão; não é chave universal de publicidade. | 1.13.0 |
| `dispositivo` | `varchar(16)` / não | conforme semântica | movel ou desktop pela largura da tela; não identifica hardware. Valores: `movel`, `desktop`. | 1.13.0 |
| `criado_em` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | 1.13.0 |
| `recebido_em` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário de recebimento pelo servidor, epoch de segundos. | 1.13.0 |
| `qualidade` | `varchar(16)` / não | conforme semântica | Qualidade temporal da origem/normalização; não é nota de qualidade de lead. Valores: `cliente`, `servidor`. | 1.13.0 |
| `detalhe` | `varchar(64)` / não | conforme semântica | Dimensão fechada da métrica, como marco, seção ou código de erro; não contém mensagem livre. | 1.13.0 |
| `valor` | `double` / não | ms para tempos/vitais, CLS sem unidade; demais conforme TSV | Valor numérico da métrica; unidade depende da metrica/detalhe. | 1.13.0 |
| `sequencia` | `int unsigned` / não | conforme semântica | Número crescente da revisão da amostra; conservar a maior sequência válida. | 1.13.0 |
| `atribuicao` | `text` / não | conforme semântica | JSON do contrato compartilhado de origem publicitária. | 1.13.0 |
| `payload_hash` | `char(64)` / não | conforme semântica | SHA-256 do payload canônico para verificar repetição; não usar como identidade pessoal. | 1.14.0 |

Índices: PRIMARY (id) único; evento (evento) único; periodo (criado_em, tipo); trafego_periodo (classe_trafego, criado_em, tipo); sessao (sessao, criado_em); navegacao (navegacao, tipo); visitante (visitante); correlacao (correlacao).

## f3base_arquivos_leads

Um arquivo físico privado identificado por ID/hash.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `id` | `varchar(32)` / não | conforme semântica | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `dono` | `varchar(32)` / não | conforme semântica | record_id proprietário de anexo; vazio para material ainda não vinculado. | base 1.12.0 ou anterior |
| `finalidade` | `varchar(20)` / não | conforme semântica | anexo do contato ou material privado conforme cadastro. | base 1.12.0 ou anterior |
| `nome` | `text` / não | conforme semântica | Nome original do arquivo/material; dado potencialmente pessoal. | base 1.12.0 ou anterior |
| `mime` | `varchar(120)` / não | conforme semântica | Tipo MIME observado do arquivo. | base 1.12.0 ou anterior |
| `bytes` | `bigint unsigned` / não | bytes | Tamanho do arquivo em bytes. | base 1.12.0 ou anterior |
| `sha256` | `varchar(64)` / não | conforme semântica | Hash SHA-256 do conteúdo binário privado. | base 1.12.0 ou anterior |
| `criado_em` | `bigint` / não | epoch segundos UTC; zero = ausente | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |
| `estado` | `varchar(20)` / não | conforme semântica | Estado do ciclo de vida do arquivo/fila/reserva; não inferir atendimento a partir dele. | base 1.12.0 ou anterior |

Índices: PRIMARY (id) único; dono (dono); estado (estado, criado_em).

## f3base_atendimento_historico

Uma mudança operacional por record_id e revisão.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `id` | `bigint unsigned` / não | conforme semântica | Chave física local. Não identifica pessoa ou anúncio. | 1.13.0 |
| `record_id` | `char(32)` / não | conforme semântica | Identificador opaco estável do contato, no escopo deste site. | 1.13.0 |
| `revisao` | `bigint unsigned` / não | conforme semântica | Revisão otimista do registro; deve acompanhar ações de escrita. | 1.13.0 |
| `anterior` | `varchar(20)` / não | conforme semântica | Estado de atendimento anterior à alteração. | 1.13.0 |
| `atual` | `varchar(20)` / não | conforme semântica | Estado de atendimento após alteração. | 1.13.0 |
| `em` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário da alteração epoch em segundos. | 1.13.0 |
| `operador` | `bigint unsigned` / não | conforme semântica | ID WordPress do usuário responsável pela marcação operacional. | 1.13.0 |

Índices: PRIMARY (id) único; alteracao (record_id, revisao) único; periodo (em).

## f3base_capi_fila

Uma entrega durável por record_id; estados incertos exigem reconciliação.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `record_id` | `varchar(128)` / não | conforme semântica | Identificador opaco estável do contato, no escopo deste site. | base 1.12.0 ou anterior |
| `payload` | `longtext` / não | conforme semântica | JSON interno da entrega CAPI; inclui marca de teste durável removida antes do transporte externo. | base 1.12.0 ou anterior |
| `estado` | `varchar(16)` / não | conforme semântica | Estado do ciclo de vida do arquivo/fila/reserva; não inferir atendimento a partir dele. | base 1.12.0 ou anterior |
| `tentativas` | `int unsigned` / não | conforme semântica | Tentativas operacionais de processamento da fila. | base 1.12.0 ou anterior |
| `proxima` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Próxima tentativa elegível em epoch de segundos. | base 1.12.0 ou anterior |
| `expira` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Expiração epoch em segundos. | base 1.12.0 ou anterior |
| `atualizado` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Última alteração da fila em epoch de segundos. | base 1.12.0 ou anterior |
| `reserva` | `varchar(64)` / não | conforme semântica | ID opaco da reserva/lease de execução. | base 1.12.0 ou anterior |
| `http` | `int` / não | conforme semântica | Último código HTTP observado no transporte. | base 1.12.0 ou anterior |
| `pixel_id` | `varchar(64)` / não | conforme semântica | ID da conta de destino Meta Pixel, como string. | base 1.12.0 ou anterior |
| `decisao_ref` | `varchar(64)` / não | conforme semântica | Referência à decisão de consentimento aplicável à entrega. | base 1.12.0 ou anterior |
| `politica_versao` | `varchar(64)` / não | conforme semântica | Versão declarada da política de consentimento. | base 1.12.0 ou anterior |
| `iniciado` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Início da tentativa em epoch de segundos. | base 1.12.0 ou anterior |
| `cancelado` | `bigint unsigned` / não | conforme semântica | Carimbo/indicador operacional de cancelamento; conferir estado antes de interpretar. | base 1.12.0 ou anterior |
| `lead_id` | `bigint unsigned` / não | conforme semântica | Identificador legado/local da origem da fila; não substituir record_id por inferência. | base 1.12.0 ou anterior |
| `eliminar_lead` | `int` / não | conforme semântica | Booleano de remoção pendente do vínculo de lead. | base 1.12.0 ou anterior |
| `limpeza_pendente` | `int` / não | conforme semântica | Booleano de limpeza a concluir após reconciliação do transporte. | base 1.12.0 ou anterior |
| `motivo` | `varchar(64)` / não | conforme semântica | Código técnico da recusa/estado, sem corpo de contato. | base 1.12.0 ou anterior |
| `agendamento_falhou` | `int` / não | conforme semântica | Booleano indicando falha ao agendar a próxima tentativa. | base 1.12.0 ou anterior |
| `schema_versao` | `int` / não | conforme semântica | Versão interna do payload durável da fila. | base 1.12.0 ou anterior |

Índices: PRIMARY (record_id) único; pendentes (estado, proxima); expiracao (expira).

## f3base_comportamento

Uma combinação de dia, caminho, métrica, detalhe, classe e regra/fuso.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `chave` | `char(64)` / não | conforme semântica | Identificador composto/hash da granularidade ou da quota; não é visitante. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` / não | conforme semântica | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. Valores: `nao_marcado`, `teste`. | 1.14.0 |
| `dia` | `char(10)` / não | dia YYYY-MM-DD no calendário da regra | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `caminho` | `varchar(190)` / não | conforme semântica | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `metrica` | `varchar(64)` / não | conforme semântica | Nome estável declarado em dados/eventos-comportamento.tsv; vitais usam LCP, CLS, INP, FCP, TTFB conforme amostra disponível. | base 1.12.0 ou anterior |
| `detalhe` | `varchar(60)` / não | conforme semântica | Dimensão fechada da métrica, como marco, seção ou código de erro; não contém mensagem livre. | base 1.12.0 ou anterior |
| `contagem` | `bigint unsigned` / não | conforme semântica | Quantidade agregada na granularidade da linha. | base 1.12.0 ou anterior |
| `soma` | `double` / não | ms para tempos/vitais, CLS sem unidade; demais conforme TSV | Soma de valores compatíveis; não permite calcular percentis. | base 1.12.0 ou anterior |
| `regra` | `varchar(64)` / não | conforme semântica | Versão da regra de calendário/agregação/classificação. | base 1.12.0 ou anterior |
| `fuso` | `varchar(64)` / não | conforme semântica | Fuso aplicado à agregação; comparar somente regras e fusos compatíveis. | base 1.12.0 ou anterior |
| `qualidade` | `varchar(16)` / não | conforme semântica | Qualidade temporal da origem/normalização; não é nota de qualidade de lead. | base 1.12.0 ou anterior |
| `atualizado_em` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário da última alteração ou agregação. | base 1.12.0 ou anterior |

Índices: PRIMARY (chave) único; classe_dia (classe_trafego, dia); dia (dia); dia_metrica (dia, metrica).

## f3base_concessoes

Uma concessão de material/versão para um lead, com quota e validade.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `id` | `varchar(32)` / não | conforme semântica | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `lead_record_id` | `varchar(32)` / não | conforme semântica | Contato que originou a concessão; relação muitos para um. | base 1.12.0 ou anterior |
| `ativo` | `varchar(32)` / não | conforme semântica | ID do material privado autorizado pela concessão. | base 1.12.0 ou anterior |
| `versao` | `varchar(64)` / não | conforme semântica | Versão/hash do material concedido; não é versão do plugin. | base 1.12.0 ou anterior |
| `dedup` | `varchar(64)` / sim | conforme semântica | Chave única da concessão para repetição idempotente. | base 1.12.0 ou anterior |
| `expira` | `bigint` / não | epoch segundos UTC; zero = ausente | Expiração epoch em segundos. | base 1.12.0 ou anterior |
| `quota` | `int` / não | conforme semântica | Máximo de utilizações autorizadas da concessão. | base 1.12.0 ou anterior |
| `usados` | `int` / não | conforme semântica | Quantidade de tentativas autorizadas debitadas; não comprova leitura completa do arquivo. | base 1.12.0 ou anterior |
| `revogada` | `tinyint(1)` / não | conforme semântica | Booleano de revogação da concessão/decisão. | base 1.12.0 ou anterior |
| `primeira` | `bigint` / não | epoch segundos UTC; zero = ausente | Horário epoch de segundos do primeiro uso autorizado. | base 1.12.0 ou anterior |
| `ultima` | `bigint` / não | epoch segundos UTC; zero = ausente | Horário epoch de segundos do último uso autorizado. | base 1.12.0 ou anterior |

Índices: PRIMARY (id) único; dedup (dedup) único; lead_record_id (lead_record_id).

## f3base_consentimento_decisoes

Uma referência de decisão de consentimento e validade.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `ref` | `varchar(64)` / não | conforme semântica | Referência opaca da decisão de consentimento. | base 1.12.0 ou anterior |
| `politica_versao` | `varchar(64)` / não | conforme semântica | Versão declarada da política de consentimento. | base 1.12.0 ou anterior |
| `medicao` | `tinyint` / não | conforme semântica | Booleano da permissão de medição. | base 1.12.0 ou anterior |
| `publicidade` | `tinyint` / não | conforme semântica | Booleano da permissão publicitária. | base 1.12.0 ou anterior |
| `revogada` | `tinyint` / não | conforme semântica | Booleano de revogação da concessão/decisão. | base 1.12.0 ou anterior |
| `expira_em` | `bigint` / não | epoch segundos UTC; zero = ausente | Expiração epoch de segundos. | base 1.12.0 ou anterior |

Índices: PRIMARY (ref) único; expira_em (expira_em).

## f3base_contatos_legados

Registro histórico preservado; nenhum importador é executado nesta release.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `id` | `bigint unsigned` / não | conforme semântica | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `origem_chave` | `varchar(190)` / não | conforme semântica | Chave no escopo da fonte histórica; única quando presente. | base 1.12.0 ou anterior |
| `email` | `varchar(254)` / não | conforme semântica | Endereço informado pelo contato; dado pessoal, pode estar vazio em cliques. | base 1.12.0 ou anterior |
| `dados` | `longtext` / não | conforme semântica | Snapshot JSON do contato e contexto; contrato dos caminhos abaixo. | base 1.12.0 ou anterior |
| `origem_hash` | `varchar(64)` / não | conforme semântica | Hash da representação da origem histórica para controle de integridade. | base 1.12.0 ou anterior |
| `eliminado` | `tinyint(1)` / não | conforme semântica | Booleano indicando conteúdo histórico eliminado. | base 1.12.0 ou anterior |

Índices: PRIMARY (id) único; origem_chave (origem_chave) único; email (email).

## f3base_eventos

Uma ocorrência detalhada da sessão/caminho/métrica; qualidade temporal por linha.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `id` | `bigint unsigned` / não | conforme semântica | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` / não | conforme semântica | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. Valores: `nao_marcado`, `teste`. | 1.14.0 |
| `visitante` | `char(32)` / não | conforme semântica | Identificador local pseudônimo do navegador, sujeito a consentimento e expiração. | base 1.12.0 ou anterior |
| `sessao` | `char(32)` / não | conforme semântica | Identificador analítico opcional, originado no navegador; não equivale a pessoa. | base 1.12.0 ou anterior |
| `dia` | `char(10)` / não | dia YYYY-MM-DD no calendário da regra | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `caminho` | `varchar(190)` / não | conforme semântica | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `metrica` | `varchar(64)` / não | conforme semântica | Nome estável declarado em dados/eventos-comportamento.tsv; vitais usam LCP, CLS, INP, FCP, TTFB conforme amostra disponível. | base 1.12.0 ou anterior |
| `detalhe` | `varchar(60)` / não | conforme semântica | Dimensão fechada da métrica, como marco, seção ou código de erro; não contém mensagem livre. | base 1.12.0 ou anterior |
| `valor` | `double` / não | ms para tempos/vitais, CLS sem unidade; demais conforme TSV | Valor numérico da métrica; unidade depende da metrica/detalhe. | base 1.12.0 ou anterior |
| `ocorrencia` | `int unsigned` / não | conforme semântica | Ordinal do acionamento na sessão/caminho/métrica; reenvio não cria nova ocorrência. | base 1.12.0 ou anterior |
| `ms` | `bigint unsigned` / não | milissegundos relativos | Milissegundos relativos à âncora da sessão; não é epoch. | base 1.12.0 ou anterior |
| `criado_em` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |
| `ancora` | `varchar(16)` / não | conforme semântica | Origem temporal: visitante, servidor ou vazio histórico. Reconstrução absoluta depende dessa qualidade. Valores: `visitante`, `servidor`, ``. | base 1.12.0 ou anterior |

Índices: PRIMARY (id) único; classe_dia (classe_trafego, dia); dia (dia); dia_caminho (dia, caminho); instante (criado_em, id); sessao (sessao); visitante (visitante).

## f3base_leads

Um contato ou intenção registrada. Cliques não são formulários aceitos.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `id` | `bigint unsigned` / não | conforme semântica | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `record_id` | `varchar(32)` / não | conforme semântica | Identificador opaco estável do contato, no escopo deste site. | base 1.12.0 ou anterior |
| `correlacao` | `varchar(64)` / sim | conforme semântica | Identificador declarado da instância/submissão; não é chave universal de publicidade. | base 1.12.0 ou anterior |
| `sessao` | `char(32)` / sim | conforme semântica | Identificador analítico opcional, originado no navegador; não equivale a pessoa. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` / não | conforme semântica | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. Valores: `nao_marcado`, `teste`. | 1.14.0 |
| `post_id` | `bigint unsigned` / sim | conforme semântica | ID local do conteúdo em que ocorreu a captura; pode faltar no histórico. | base 1.12.0 ou anterior |
| `resposta` | `varchar(30)` / não | conforme semântica | Estado da resposta automática ao visitante, independente do aviso interno. | base 1.12.0 ou anterior |
| `resposta_em` | `bigint` / não | epoch segundos UTC; zero = ausente | Horário do processamento/estado de resposta em epoch de segundos; zero indica ausência. | base 1.12.0 ou anterior |
| `resposta_erro` | `varchar(100)` / não | conforme semântica | Código operacional limitado do último erro de resposta; sem mensagem pessoal. | base 1.12.0 ou anterior |
| `formulario` | `varchar(80)` / não | conforme semântica | ID do formulário cadastrado ou identificador de fluxo do CTA; método distingue os dois. | base 1.12.0 ou anterior |
| `metodo` | `varchar(40)` / não | conforme semântica | Tipo de captura pelo destino/regime: formulario, whatsapp_formulario, conteudo, whatsapp_cta, contato_cta; histórico pode conter legado_desconhecido. Valores: `formulario`, `whatsapp_formulario`, `conteudo`, `whatsapp_cta`, `contato_cta`, `legado_desconhecido`. | base 1.12.0 ou anterior |
| `captura` | `varchar(20)` / não | conforme semântica | Resultado da captura: aceito, suspeito ou clique. Não representa atendimento comercial. Valores: `aceito`, `suspeito`, `clique`. | base 1.12.0 ou anterior |
| `atendimento` | `varchar(20)` / não | conforme semântica | Estado operacional: novo, respondido ou spam. Valores: `novo`, `respondido`, `spam`. | base 1.12.0 ou anterior |
| `lixeira` | `tinyint(1)` / não | conforme semântica | Booleano de remoção operacional reversível; relatórios integrados excluem 1. | base 1.12.0 ou anterior |
| `criado_em` | `datetime` / não | datetime UTC | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |
| `atualizado_em` | `datetime` / não | datetime UTC | Horário da última alteração ou agregação. | base 1.12.0 ou anterior |
| `email` | `varchar(254)` / não | conforme semântica | Endereço informado pelo contato; dado pessoal, pode estar vazio em cliques. | base 1.12.0 ou anterior |
| `nome` | `varchar(250)` / não | conforme semântica | Nome informado ou nome original do arquivo, conforme a tabela; não usar para deduplicar pessoas. | base 1.12.0 ou anterior |
| `pagina` | `text` / não | conforme semântica | URL da página de captura; relatórios normalizam caminho e omitem query/fragmento. | base 1.12.0 ou anterior |
| `dados` | `longtext` / não | conforme semântica | Snapshot JSON do contato e contexto; contrato dos caminhos abaixo. | base 1.12.0 ou anterior |
| `anexos` | `longtext` / não | conforme semântica | Lista JSON dos anexos privados vinculados; não contém URL pública de acesso. | base 1.12.0 ou anterior |
| `idempotencia` | `varchar(64)` / sim | conforme semântica | Chave de deduplicação da submissão. Mesma chave com payload diferente é conflito. | base 1.12.0 ou anterior |
| `payload_hash` | `varchar(64)` / não | conforme semântica | SHA-256 do payload canônico para verificar repetição; não usar como identidade pessoal. | base 1.12.0 ou anterior |
| `origem_chave` | `varchar(190)` / sim | conforme semântica | Chave no escopo da fonte histórica; única quando presente. | base 1.12.0 ou anterior |
| `origem_hash` | `varchar(64)` / não | conforme semântica | Hash da representação da origem histórica para controle de integridade. | base 1.12.0 ou anterior |
| `importado_hash` | `varchar(64)` / não | conforme semântica | Hash preservado da importação já realizada; não ativa novo importador. | base 1.12.0 ou anterior |
| `revisao` | `bigint unsigned` / não | conforme semântica | Revisão otimista do registro; deve acompanhar ações de escrita. | base 1.12.0 ou anterior |
| `aviso` | `varchar(30)` / não | conforme semântica | Estado do aviso interno à equipe; separado de resposta automática ao visitante. | base 1.12.0 ou anterior |
| `aviso_em` | `bigint` / não | epoch segundos UTC; zero = ausente | Último horário operacional do aviso, epoch em segundos. | base 1.12.0 ou anterior |
| `aviso_erro` | `varchar(100)` / não | conforme semântica | Código limitado de falha do aviso, sem corpo da mensagem. | base 1.12.0 ou anterior |
| `eliminacao_pendente` | `tinyint(1)` / não | conforme semântica | Booleano do processo durável de eliminação; registros marcados ficam fora dos relatórios. | base 1.12.0 ou anterior |

Índices: PRIMARY (id) único; record_id (record_id) único; idempotencia (idempotencia) único; origem_chave (origem_chave) único; cronologia (criado_em, id); trafego_periodo (classe_trafego, criado_em, id); sessao (sessao); post_id (post_id); email (email); aviso (aviso, aviso_em).

## f3base_leads_dedup

Uma reserva/chave técnica de deduplicação, sem valor comercial isolado.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `chave` | `char(64)` / não | conforme semântica | Identificador composto/hash da granularidade ou da quota; não é visitante. | base 1.12.0 ou anterior |
| `tipo` | `varchar(12)` / não | conforme semântica | Tipo do evento ou da reserva; consultar enum da tabela. | base 1.12.0 ou anterior |
| `estado` | `varchar(10)` / não | conforme semântica | Estado do ciclo de vida do arquivo/fila/reserva; não inferir atendimento a partir dele. | base 1.12.0 ou anterior |
| `record_id` | `char(32)` / não | conforme semântica | Identificador opaco estável do contato, no escopo deste site. | base 1.12.0 ou anterior |
| `contador` | `int unsigned` / não | conforme semântica | Contador técnico da reserva de deduplicação. | base 1.12.0 ou anterior |
| `expira_em` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Expiração epoch de segundos. | base 1.12.0 ou anterior |
| `criado_em` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |

Índices: PRIMARY (chave) único; criado_em (criado_em); tipo_expira (tipo, expira_em).

## f3base_leads_janelas

Uma quota técnica com prazo de expiração.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `chave` | `varchar(190)` / não | conforme semântica | Identificador composto/hash da granularidade ou da quota; não é visitante. | base 1.12.0 ou anterior |
| `total` | `bigint` / não | conforme semântica | Contador técnico de quota/recusa; não é volume de leads. | base 1.12.0 ou anterior |
| `expira` | `bigint` / não | epoch segundos UTC; zero = ausente | Expiração epoch em segundos. | base 1.12.0 ou anterior |

Índices: PRIMARY (chave) único; expira (expira).

## f3base_leads_recusas

Um total de recusas por motivo e dia, sem dados pessoais.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `dia` | `date` / não | dia YYYY-MM-DD no calendário da regra | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `motivo` | `varchar(40)` / não | conforme semântica | Código técnico da recusa/estado, sem corpo de contato. | base 1.12.0 ou anterior |
| `total` | `bigint unsigned` / não | conforme semântica | Contador técnico de quota/recusa; não é volume de leads. | base 1.12.0 ou anterior |
| `primeiro` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário do primeiro registro da recusa no dia, epoch de segundos. | base 1.12.0 ou anterior |
| `ultimo` | `bigint unsigned` / não | epoch segundos UTC; zero = ausente | Horário do último registro da recusa no dia, epoch de segundos. | base 1.12.0 ou anterior |

Índices: PRIMARY (dia, motivo) único.

## f3base_vitais

Uma amostra de vital atualizada por sequência; sem sessão vinculável.

| Campo | Tipo MySQL / nulo | Unidade | Significado | Disponível |
|---|---|---|---|---|
| `amostra` | `char(64)` / não | conforme semântica | Identificador da amostra vital atualizável, sem chave de sessão nesta tabela. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` / não | conforme semântica | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. Valores: `nao_marcado`, `teste`. | 1.14.0 |
| `dia` | `date` / não | dia YYYY-MM-DD no calendário da regra | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `caminho` | `varchar(760)` / não | conforme semântica | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `metrica` | `varchar(8)` / não | conforme semântica | Nome estável declarado em dados/eventos-comportamento.tsv; vitais usam LCP, CLS, INP, FCP, TTFB conforme amostra disponível. | base 1.12.0 ou anterior |
| `dispositivo` | `varchar(16)` / não | conforme semântica | movel ou desktop pela largura da tela; não identifica hardware. Valores: `movel`, `desktop`. | base 1.12.0 ou anterior |
| `sequencia` | `int unsigned` / não | conforme semântica | Número crescente da revisão da amostra; conservar a maior sequência válida. | base 1.12.0 ou anterior |
| `valor` | `double` / não | ms para tempos/vitais, CLS sem unidade; demais conforme TSV | Valor numérico da métrica; unidade depende da metrica/detalhe. | base 1.12.0 ou anterior |

Índices: PRIMARY (amostra) único; periodo (dia, metrica, dispositivo); classe_dia (classe_trafego, dia); pagina (caminho).

## Campos JSON e junções

O prefixo `atribuicao` representa `f3base_leads.dados.atribuicao` e `f3base_analise.atribuicao`. Não capture query inteira, conteúdo digitado ou tokens dentro de eventos analíticos. `f3_ads_v=1` é necessário para interpretar `utm_content` como ID do anúncio; valores históricos de rótulo não viram IDs retroativamente.

- `atribuicao.utm_source`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.utm_medium`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.utm_campaign`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.utm_content`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.utm_term`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.utm_id`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.utm_source_platform`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.f3_ads_v`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.f3_ads_account_id`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.f3_ads_group_id`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.f3_ads_group_type`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.li_fat_id`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.f3_ads_group_name`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.f3_ads_ad_name`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.f3_ads_placement`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.gclid`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.gbraid`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.wbraid`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `atribuicao.fbclid`: {"tipo": "string", "limite_caracteres": 500, "ausente": "", "origem": "URL declarada, sem inferir identidade pelo clique"}.
- `leads.dados.contexto`: {"tipo": "object", "descricao": "IP/origem técnica, UA, post_id, versão, motivo da ausência de sessão e superfície quando disponíveis; não usar para fundir sessões"}.
- `leads.dados.campos`: {"tipo": "object", "descricao": "Valores do formulário por nome; contém dados pessoais e respostas livres, não são dimensões do relatório"}.
- `leads.dados.campos_snapshot`: {"tipo": "array", "descricao": "Nomes, rótulos e tipos da definição na captura"}.
- `leads.dados.campos_relatorio`: {"tipo": "array", "descricao": "Definições de opções fechadas na captura; preserva interpretação histórica"}.
- `leads.dados.formulario_revisao`: {"tipo": "string", "descricao": "Hash da revisão do formulário"}.
- `leads.dados.navegacao`: {"tipo": "string", "descricao": "Carregamento que gerou contato; pode faltar"}.
- `leads.dados.contexto_teste`: {"tipo": "boolean", "descricao": "Marca durável no instante da captura; não é consentimento"}.
- `atribuicao.modelo`: {"tipo": "string", "valores": ["sessao", "primeiro-toque", "ultimo-toque", "informado"]}.
- `atribuicao.plataforma`: {"tipo": "string", "valores": ["meta_ads", "google_ads", "linkedin_ads", "nao_identificada"]}.
- `atribuicao.cobertura`: {"tipo": "string", "valores": ["anuncio", "campanha", "parcial"]}.
- `atribuicao.referrer`: {"tipo": "string", "descricao": "Somente host externo; não guarda query de origem"}.
- `atribuicao.primeiro_toque_em`: {"tipo": "string", "unidade": "epoch segundos; vazio quando desconhecido"}.
- `atribuicao.ultimo_toque_em`: {"tipo": "string", "unidade": "epoch segundos; vazio quando desconhecido"}.
- `atribuicao.primeiro_toque`: {"tipo": "object", "descricao": "Snapshot de um nível do mesmo contrato, sem recursão"}.
- `atribuicao.ultimo_toque`: {"tipo": "object", "descricao": "Snapshot de um nível do mesmo contrato, sem recursão"}.
- `atribuicao.sessao_origem`: {"tipo": "object", "descricao": "Parâmetros observados no URL/contexto corrente; não inventa histórico"}.
- `atribuicao.anuncio_id`: {"tipo": "string", "descricao": "utm_content somente quando f3_ads_v=1; caso contrário vazio"}.
- `atribuicao.conta_id`: {"tipo": "string", "descricao": "f3_ads_account_id"}.
- `atribuicao.campanha_id`: {"tipo": "string", "descricao": "utm_id"}.
- `atribuicao.grupo_id`: {"tipo": "string", "descricao": "f3_ads_group_id"}.
- `atribuicao.superficie_anuncio`: {"tipo": "string", "descricao": "instagram/facebook/audience_network/messenger quando utm_source declara ig/fb/an/msg; vazio caso contrário"}.

Uma sessão pode ter vários contatos e muitos eventos. Prefira EXISTS ou pré-agregação. Sempre inclua classe de tráfego na junção. Não junte `f3base_vitais` a um lead por caminho/horário como se houvesse sessão: use somente vitais de `f3base_analise` quando a associação for necessária. Histórico de atendimento e concessões precisam ser pré-agregados por record_id antes de somar leads.

`dados.contexto.superficie` usa conteudo/menu/elementor/flutuante segundo evidência. `data-f3base-lead`/form_id de um CTA preservam série histórica; não tornam o clique um envio de formulário. IP e UA servem ao contexto técnico protegido, nunca à exclusão inferida de testes ou à criação de pessoa única.


## Contexto de conversão — contrato 1.16.0

O JSON `leads.dados.consentimento_snapshot` guarda a referência de consentimento confirmada pelo servidor (`decisao_ref`, `politica_versao`, conforme o modo) e os booleanos `medicao`/`publicidade` no instante da captura. No modo legado, a versão é prefixada com `legado:`. `consentimento_publicidade` e `atribuicao_reducao` explicitam a decisão tomada. Esses valores não são inferidos retroativamente para contatos antigos.

`dados.atribuicao.fbc` e `fbp` preservam cookies Meta legítimos, com validação de formato/tamanho e permissão de publicidade. Não são IDs de anúncio, não entram como campos novos da lista operacional e seguem a retenção do lead. A exportação de dados deve considerar o JSON do registro; não criar cruzamentos de identidade a partir de cookies ausentes. A referência de consentimento e a marca de teste são preservadas na fila CAPI, que revalida a autorização antes de despachar.

O payload externo é montado a partir do registro confirmado: contato, IP/UA capturados, URL e horário original, correlação/event ID, atribuição e classe de teste. Cron não substitui a origem pelo contexto do servidor. Capturas históricas sem snapshot suficiente não são reenviadas para preencher esses campos. Consulte `AGENTES-1.17.md` e `CRUZAMENTOS-PUBLICIDADE.md`.


## Novidades 1.16 / contrato 4.0.0

`f3base_pipedrive_fila.record_id` e `f3base_anuncios_recibos.record_id` se relacionam a `f3base_leads.record_id`. Fila: estado próprio, posse/prazo, tentativas, horários, etapas e journal sem cópia do corpo do contato. Recibo: origem/conta/formulário/ID nativo, projeção, horários de origem e recepção, via e tombstone. Exclusão pode manter referência técnica mínima sem que o contato ainda exista; use LEFT JOIN.

`leads.entrega` guarda a intenção durável de integração. Nunca inferir “entregue” porque houve captura ou e-mail. Instantes de fila são epoch UTC; criado_em do lead é datetime UTC. IDs de plataformas são strings. Conta faz parte de toda chave de cruzamento; ID de anúncio sozinho não é identificador global.

Acessos ganharam primeiro_em/ultimo_em/instantes_validos e agregados horários, por contribuição de arquivo/regra. Histórico sem instante tem cobertura indisponível. Dados não contêm IP/User-Agent bruto. Não juntar logs de robôs a uma sessão humana por proximidade temporal. Consulte AGENTES-E-BUSCADORES.md.

Atribuição OpenAI usa oppref opaco: acesso privado, teto 8192 bytes, sujeito a consentimento. O click ID não substitui campanha_id/anuncio_id nem autoriza junção por usuário. O contrato estrutural gerado em dados/contrato.json descreve os tipos e índices efetivos do schema 1.17; prefixo de tabela depende da instalação.

## Estrutura editorial da 1.17

| Tabela (prefixo WordPress variável) | Fonte e ciclo |
|---|---|
| f3base_conteudos | Inventário público por post_id, título/tipo/URL; atualização em lotes e nos saves. |
| f3base_conteudo_rotas | Identidade de rota com início/fim, formato e procedência; não é sessão. |
| f3base_editorial_diario | Dimensões anônimas e métricas aditivas, 13 meses no padrão. |
| f3base_editorial_dias | Estado transacional de fechamento e disponibilidade do bruto. |
| f3base_referencias_ia | Observações administrativas; chave única/revisão; até exclusão. |
| f3base_medicao_anotacoes | Dias/motivos/exclusão reversível; sem IDs de visitantes. |
| f3base_gsc_diario | Universo/propriedade/dia/URL/pesquisa/filtros; métricas e cobertura externa. |
| f3base_inteligencia_auditoria | Ação/hash da chave/revisão/operador/instante; sem evidência copiada. |

Análise acrescenta navegação anterior, automação/regra/motivos, identidade editorial, canal/provedor, evidência/conflitos e início/entrada. Comportamento acrescenta navegação e classificação reduzida. Acessos/contribuições/horas acrescentam post_id/tipo/representação/resolução e metadados da lista oficial. `dimensao` é hash do conjunto agregado, não endereço individual.

Relações novas: conteúdo ↔ post_id; rota válida ↔ caminho + instante; comportamento ↔ análise por classe/sessao/navegacao; contato ↔ dados.navegacao + sessao + classe. Nenhuma chave une uma requisição de robô a uma pessoa. Leia dados/contrato.json para colunas e índices extraídos da estrutura instalada.
