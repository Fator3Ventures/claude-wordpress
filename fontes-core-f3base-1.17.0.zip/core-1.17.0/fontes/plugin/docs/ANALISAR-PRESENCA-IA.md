# Analisar presença e visitas de IA

Mantenha três perguntas separadas: que conteúdo foi requisitado, que visitas vieram por referências observáveis de IA e onde há citação/menção/recomendação com evidência registrada.

Em IA e robôs, escolha OpenAI, Claude, Gemini/Notebook ou outra família. Filtre conteúdo e representação; preserve GET, HEAD, 304, erros, bloqueios e a qualidade da rede. Uma requisição `.md` do Core pode ser ligada ao artigo; um `.md` de outro emissor permanece não resolvido. Download de llms-full não comprova leitura de cada item. Um bloqueio 403/429 não revela sozinho a causa nem autoriza mudança de proteção.

As listas oficiais são buscadas em tarefa separada: duas fontes por execução, timeout de seis segundos por fonte, 1 MiB e até 10 mil prefixos; validade de sete dias e última lista válida preservada quando a atualização falha. IP existe transitoriamente na verificação, sem hash individual nesse mecanismo. Declare `ip_log_confiavel` somente quando o servidor registra a origem real validada. Atrás de proxy sem garantia, não afirmar origem. O resultado registra lista/data/versão, não autenticação criptográfica histórica.

Fontes iniciais: OpenAI (searchbot, gptbot, chatgpt-user, adsbot), Claude (lista publicada) e Google (common-crawlers, user-triggered-fetchers-google e user-triggered-agents). Sem fonte oficial, lista expirada ou endereço não confiável são estados próprios. Reclassificações dos logs registram nova regra; não misturam contribuição antiga à nova. O mecanismo anterior de repetição dos logs tem sua política própria e não é usado para atribuir pessoas/leads.

Em Visitantes de IA, use referências/UTMs disponíveis e examine as sessões. `utm_source=chatgpt.com` é sinal declarado; falta de referência é desconhecida. Googlebot não se transforma em Gemini. Google-Extended é uma preferência de robots, sem User-Agent próprio. Google-Agent e Gemini Notebook têm finalidades diferentes.

Para registrar uma referência, use o formulário administrativo ou `ia-referencia-gravar` com chave única. Diferencie testes de observações externas, cite evidência e revise antes de marcar conferida. Para corrigir, envie a revisão atual; repetir a mesma observação não duplica. Para excluir, informe ID e revisão. Não fabricar referências a partir de acesso do robô.

Antes de testes de agente, ative o cookie existente na rota de teste do plugin e confira a marca no navegador; requisições de teste podem usar o cabeçalho já documentado. Cada contexto/navegador precisa da marca. MCP é operação técnica, não visita orgânica. Não correlacione sessões com IP/horário de acesso ao MCP.

Fontes oficiais conferidas em 29/09/2026:
- https://developers.openai.com/api/docs/bots
- https://claude.com/crawling/bots.json
- https://developers.google.com/crawling/docs/crawlers-fetchers/verify-google-requests
- https://developers.google.com/crawling/docs/crawlers-fetchers/google-user-triggered-fetchers
- https://developers.google.com/webmaster-tools/v1/searchanalytics/query
