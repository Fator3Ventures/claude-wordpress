# Medição editorial — contrato 1.17.0

## Perguntas e navegação

| Área | Uso |
|---|---|
| Visão geral | Sessões, pseudônimos, visualizações, entradas orgânicas, conteúdos requisitados por IA; evolução diária e fontes. |
| Conteúdo → Páginas / Artigos / Outros | Comparar conteúdos pelo tipo WordPress; abrir alcance, consumo, continuidade, ações e IA. |
| Sessões | Filtrar ID, entrada, origem e conteúdo; abrir jornada completa disponível, destacando o conteúdo selecionado. |
| Aquisição | Canais de entrada; campanhas comerciais preservadas; fotografias do Search Console. |
| IA e robôs | Requisições por conteúdo, visitantes de IA, referências observadas, frequência e horas. |
| Conversão | Relatórios comerciais existentes, formulário, métodos, materiais, demanda e atendimento. |
| Técnico | Vitais, erros, fricção, logs e diagnóstico da coleta. |

As análises anteriores de comportamento permanecem acessíveis em Sessões → Análises complementares. Relatórios comerciais conservam os seus denominadores e limites; não somar suas linhas às novas visualizações editoriais.

Páginas = `page`, artigos = `post`. A página definida como índice do blog é `indice_artigos`, não um artigo. Home estática pertence à página configurada. Arquivos/taxonomias, busca sem termo armazenado, CPT e rotas não resolvidas aparecem em Outros. O catálogo trabalha em lotes de 200, sem corte em 1.000 itens. Rotas têm vigência e procedência; a data de publicação de um post não é prova da vigência histórica de seu slug. Uma rota conhecida apenas hoje não recebe identidade retroativa nos logs antigos.

## Métricas e qualidade

- **Visualização:** uma por `(classe_trafego, sessao, navegacao)` na análise. Reload gera nova navegação; retorno ao mesmo documento por bfcache conserva o vínculo e não soma outra visualização. Tracking não é somado como uma segunda fonte de pageview.
- **Sessões/visitantes observados:** distintos do detalhe retido. Não são pessoas autenticadas. Período com dias somente agregados retorna `null` para distintos; nunca soma distintos diários.
- **Sessões iniciadas/entradas cobertas:** contador aditivo, uma vez, no início e conteúdo de entrada. Origem observada somente depois de uma atualização/limpeza de armazenamento não vira início comprovado. A última página observada não é uma saída definitiva.
- **Tempo ativo:** soma dos intervalos de bloco predominante elegíveis, limitados a 30 segundos por evento. Ausência de amostra é indisponível. Não mede leitura comprovada. O agregado conserva amostras de navegação/dia, não pseudônimos.
- **Rolagem:** maior marco por navegação no detalhe; no histórico, amostras de navegação/dia, com soma e denominador. Seções observadas e pares anterior/seguinte detalhados dependem dos eventos retidos.
- **Ações pareadas:** cliques de contato e aceites locais exigem sessão, classe e navegação correspondentes. Contato sem vínculo continua em Conversão, sem atribuição fabricada. Início e tentativa não são aceite.
- **Continuidade:** somente `navegacao_anterior` relacionada à mesma sessão/classe. Abas independentes não estabelecem uma transição. Filtro de conteúdo não corta as outras páginas ao abrir a jornada individual.
- **IA:** requisições HTTP são unidades diferentes de sessões de navegador. HTML e Markdown do Core são representações do mesmo conteúdo quando resolvidos. `llms-full.txt` é uma requisição ao índice completo, não uma visualização de cada artigo.

O segmento padrão exclui testes marcados e automação declarada/provável. `automacao` é independente de `classe_trafego`. Lighthouse, sondas e assinaturas conhecidas são declaradas; HeadlessChrome e `navigator.webdriver` são sinais prováveis. Ausência desses sinais não comprova humano. O servidor valida os sinais e guarda motivo/regra reduzidos; não acrescenta User-Agent bruto ou IP ao evento. Heurísticas não recusam formulários, CRM ou contatos.

Histórico sem regra nova permanece consultável com aviso. Anotações de dias de teste são reversíveis e só afetam números quando `anotacoes=true`; não apagam o registro original. Não usar coincidência de IP/horário do MCP para classificar uma pessoa. Rotas MCP/admin, assets e varreduras saem do total editorial dos logs; o parser guarda apenas subtipo/totais técnicos quando o caminho é descartado.

## Aquisição

`audiencia-1.17.0-1` classifica canais por sinais permitidos: busca orgânica, IA, social, mídia paga, e-mail, outros sites, outra origem identificada e direto/desconhecido. Meio pago explícito ou identificador publicitário comprovado tem prioridade; `fbclid` isolado não prova anúncio. Google/Bing genéricos não são Gemini/Copilot. Hosts são comparados por aliases fechados, não substring. `utm_source=chatgpt.com` é evidência declarada, sem prova inviolável.

A fotografia `atribuicao.sessao_origem` conserva entrada/início e sinais da primeira observação da sessão. Não reescreve primeiro/último toque comercial. Colunas `aquisicao_regra`, `aquisicao_evidencia`, `aquisicao_conflitos` explicam a decisão. Histórico com sinais retidos pode ser interpretado em consulta, marcado como reconstruído; não reemite eventos externos. A área Visitantes de IA usa canal IA editorial; mídia paga identificada permanece em Aquisição.

## API autenticada e CSV

Todos os serviços abaixo exigem `manage_options`, schema fechado e não aceitam SQL do cliente. Leia a Abilities API instalada antes de escrever. Os nomes são do namespace `f3base/`.

| Serviço | Operação |
|---|---|
| `medicao-editorial` | Consulta comum com `visao`: resumo, conteudo, sessoes, sessao, aquisicao, origem_ia, qualidade, gsc ou referencias. |
| `conteudos-relatorio` | Consulta de conteúdo; mesma implementação. |
| `sessoes-listar` / `sessao-detalhar` | Lista ou detalhe; detalhe exige `sessao` integral de 32 hex. |
| `aquisicao-relatorio` | Canais por origem da sessão. |
| `agentes-relatorio` | Conteúdo, horas e frequência dos logs; GET/HEAD/status/formato/rede preservados. |
| `ia-referencias-ler` | Referências fornecidas por operador/serviço. |
| `ia-referencia-gravar` / `ia-referencia-excluir` | Escrita administrativa com chave idempotente e revisão otimista. |
| `medicao-anotacao-gravar` | Anotação de dias completos, com motivo e exclusão reversível. |
| `gsc-importar` | Importação de contribuição normalizada autorizada; não obtém dados do Google. |
| `llms-reprocessar` / `navegacao-verificar` | Ações explícitas; não são consultas puras. |

Filtros editoriais: `de`, `ate` (dias locais, inclusivos), `tipo`, `post_id`, `caminho` exato, `sessao`, `canal`, `origem_ia`, `segmento`, `automacao`, `anotacoes`, `recorte`, `ordenar`, `direcao`, `pagina`, `limite`, `comparar`. Recortes: todos, organico, ia, sem_observacoes. Sem observações consulta o inventário, com indisponível quando falta base para afirmar zero.

Exemplo: `conteudos-relatorio({"de":"2026-09-01","ate":"2026-09-29","tipo":"artigo","canal":"busca_organica","segmento":"sem_testes","automacao":"audiencia"})`. Use um `post_id` retornado em `sessoes-listar`, depois o ID integral em `sessao-detalhar`. Ao informar conteúdo junto do detalhe, a jornada continua completa; `destacado` identifica os passos correspondentes.

Respostas incluem período/fuso, filtros, regra, instante da consulta, cobertura, amostras, exclusões e paginação. `null` significa indisponível e não zero. Timestamps são epoch UTC no detalhe, com projeção local e offset; CSV conserva o instante original e acrescenta UTC/local/fuso, neutralizando fórmulas.

Máximo editorial: 397 dias, até 100 mil linhas candidatas por fonte, com limite preventivo menor conforme a memória disponível. Filtros de conteúdo selecionam a coorte antes desse orçamento. O excesso retorna `reduza_periodo_ou_filtre_conteudo`, sem parcial. CSV tem teto de 20 mil linhas e 20 segundos; reduza o recorte se exceder. As rotinas diárias limitam a 100 mil registros de cada fonte por dia e preservam o bruto se não puderem concluir. Para volumes superiores, use exportação/consulta externa autorizada; não eleve limites sem medir memória.

## Histórico e retenção

`f3base_editorial_diario` guarda contagem/soma por dia, conteúdo, canal, origem IA, classe, automação e métrica; nunca IDs individuais. Padrão de 13 meses, configurável entre 1 e 25. Detalhe segue `retencao_eventos_dias` (30 no padrão), horas sua retenção (30 no padrão), logs diários preservam 25 meses ou a escolha explícita existente. Uma preferência mais curta não é ampliada automaticamente.

Fechamento por dia usa transação, substituição idempotente e guarda de estado. Antes da poda, consolida análise, comportamento e ações pareadas. Caminhos arbitrários sem identidade pública são reduzidos a `/@nao-resolvido` no agregado; não conservar tokens ou dados pessoais sob o rótulo de anonimização. Campos e nomes de seções não são preservados nesse resumo. Esquecimento alcança eventos/vínculos individuais, enquanto totais já anônimos seguem sua retenção.

Logs distinguem fonte importada, contribuição publicada e cobertura. Lacunas antigas não bloqueiam dias novos de propriedade temporal demonstrada. Calendários sobrepostos não são somados parcialmente. Horas elegíveis são publicadas com o dia; dias sem fonte não viram zero. Hoje é fotografia parcial separada, sem duplicar o histórico fechado. Consulte Técnico → Acessos para atualizar a fotografia existente. O executor precisa rodar: não há promessa de cadência sem visitas/executor.

## Referências observadas e Search Console

Referência é **citação**, **menção** ou **recomendação** cadastrada com serviço, instante, conteúdo, contexto resumido, evidência pública ou identificador privado, origem manual/externa/teste e revisão pendente/conferida/descartada. Não cole conversas privadas. Não há consulta automática da evidência nem inferência a partir de logs. Permanecem até exclusão explícita. A auditoria guarda ação, hash da chave, revisão, operador e instante; não copia a conversa/evidência. O resumo considera conferidas sem origem teste, não certifica espontaneidade.

Importação GSC exige propriedade correspondente ao site (`sc-domain:HOST` ou prefixo exato), pesquisa, escopo `paginas`/`propriedade`, dimensões `page,date`/`date`, estado final/parcial, extração, fonte, filtros, cobertura e até 5.000 linhas/1 MiB. A primeira propriedade utilizada impede fusão com outra propriedade sobreposta. Mesma chave propriedade/dia/URL/pesquisa/filtros é substituída, independentemente do agente; fotografia antiga/parcial não sobrescreve uma final mais recente. Linhas ausentes permanecem desconhecidas, não são exclusões ou zeros.

Exemplo de entrada (substitua a propriedade/URL pelas do site autorizado):

```json
{"propriedade":"https://example.org/","pesquisa":"web","escopo":"paginas","dimensoes":["page","date"],"estado":"final","extraido_em":1790720000,"fonte":"operacao-google","cobertura":{"completa":false,"limite_linhas":25000,"truncada":false,"observacao":"Linhas retornadas pela fonte"},"filtros":{},"linhas":[{"dia":"2026-09-25","url":"https://example.org/artigo/","cliques":3,"impressoes":100,"posicao":7.4}]}
```

CTR = soma cliques / soma impressões; posição ponderada por impressões, no mesmo universo. Totais de páginas não substituem totais da propriedade. **Dias do GSC são America/Los_Angeles**, sem conversão para dias do WordPress. Não associar impressões/cliques a sessões individuais nem afirmar encaminhamento individual por AI Overviews/AI Mode. Não guarda OAuth/credenciais Google; ausência do conector/importação não bloqueia a análise local.

No histórico com navegação ausente, as páginas usam o evento persistido como referência de contagem, com qualidade limitada explícita. Não se inventam transições ou pareamentos de comportamento para esse histórico. Exportação CSV usa uma fotografia consistente do banco entre as páginas do resultado.
