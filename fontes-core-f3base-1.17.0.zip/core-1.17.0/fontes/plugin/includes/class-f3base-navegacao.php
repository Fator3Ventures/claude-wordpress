<?php
/** Uma configuração de navegação, sem alterar menus ou templates do tema. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Navegacao {
    const OPTION='f3base_navegacao';
    private static bool $migrando=false;
    private static array $observados=array();
    public static function iniciar(): void {
        add_action('wp_ajax_f3base_navegacao_verificar',static function(){check_ajax_referer('f3base-navegacao','nonce');wp_send_json(self::verificar_publica());});
        add_filter('render_block',static function($html,$b,$instance){if(!self::sonda_valida()||($b['blockName']??'')!=='core/navigation'||!class_exists('WP_HTML_Tag_Processor')){return $html;}$tag=new WP_HTML_Tag_Processor($html);if($tag->next_tag('NAV')){$tag->set_attribute('data-f3base-nav-ref',(string)(int)($b['attrs']['ref']??0));$tag->set_attribute('data-f3base-nav-tipo','bloco');return $tag->get_updated_html();}return $html;},PHP_INT_MAX,3);
        add_filter('wp_nav_menu',static function($html,$args){if(!self::sonda_valida()){return $html;}$menu=wp_get_nav_menu_object($args->menu??null);if(!$menu&&!empty($args->theme_location)){$menu=wp_get_nav_menu_object(get_nav_menu_locations()[$args->theme_location]??0);}$id=$menu?(int)$menu->term_id:0;return '<span data-f3base-nav-ref="'.$id.'" data-f3base-nav-tipo="menu_classico">'.$html.'</span>';},PHP_INT_MAX,2);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('navegacao-verificar','Conferir navegação renderizada no cabeçalho da home',array(__CLASS__,'verificar_publica'),array(),array(),false);});
        add_action('wp_ajax_f3base_navegacao_buscar',static function(){check_ajax_referer('f3base-navegacao','nonce');if(!current_user_can('manage_options')){wp_send_json_error(array('codigo'=>'sem_permissao'),403);}wp_send_json(self::listar(array('tipo'=>sanitize_key($_GET['tipo']??''),'busca'=>sanitize_text_field(wp_unslash($_GET['busca']??'')),'pagina'=>max(1,(int)($_GET['pagina']??1)))));});
        add_filter('pre_option_f3base_nav_id',static function(){ $v=F3Base_Options::ler(self::OPTION);return ($v['tipo']??'tema')==='bloco'?(int)$v['id']:0; });
        add_filter('render_block_data',static function($b){if(($b['blockName']??'')==='core/navigation') { self::$observados[]=(int)($b['attrs']['ref']??0); }return $b;},PHP_INT_MAX);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('navegacao-listar','Pesquisar menus clássicos e blocos publicados',array(__CLASS__,'listar'),array('tipo'=>array('type'=>'string','enum'=>array('menu_classico','bloco')),'busca'=>array('type'=>'string','maxLength'=>100),'pagina'=>array('type'=>'integer','minimum'=>1)),array('tipo'));});
    }
    private static function contexto_prova(): string {return hash('sha256',wp_json_encode(array(F3Base_Options::revisao(self::OPTION),home_url('/'),get_stylesheet(),wp_get_theme()->get('Version'),get_theme_mods(),get_nav_menu_locations(),F3Base_Modulo_Cache_Publico::geracao())));}
    private static function sonda_valida(): bool {$v=$_GET['f3base_nav_sonda']??'';if(!is_string($v)||!preg_match('/^([0-9]{10})\.([a-f0-9]{32})\.([a-f0-9]{64})$/D',$v,$m)||(int)$m[1]<time()-60||(int)$m[1]>time()+10){return false;}return hash_equals(hash_hmac('sha256',$m[1].'.'.$m[2],wp_salt('auth')),$m[3]);}
    public static function analisar_cabecalho(string $html): array {
        if(strlen($html)>2097152||!class_exists('DOMDocument')){return array('estado'=>'indisponivel','referencias'=>array());}$dom=new DOMDocument();$old=libxml_use_internal_errors(true);try{$ok=$dom->loadHTML('<?xml encoding="utf-8" ?>'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);}finally{libxml_clear_errors();libxml_use_internal_errors($old);}if(!$ok){return array('estado'=>'html_invalido','referencias'=>array());}$xp=new DOMXPath($dom);$refs=array();foreach($xp->query('//header[not(ancestor::main) and not(ancestor::article)]//*[@data-f3base-nav-tipo and @data-f3base-nav-ref]') as $node){$refs[]=array('tipo'=>$node->getAttribute('data-f3base-nav-tipo'),'id'=>(int)$node->getAttribute('data-f3base-nav-ref'),'inline'=>$node->getAttribute('data-f3base-nav-tipo')==='bloco'&&(int)$node->getAttribute('data-f3base-nav-ref')===0);}
        return array('estado'=>$refs?'observada':'nao_observada','referencias'=>$refs,'escopo'=>'header_semantico_fora_de_main_article');
    }
    public static function verificar_publica(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$ctx=self::contexto_prova();$sig=time().'.'.bin2hex(random_bytes(16));$sig.='.'.hash_hmac('sha256',$sig,wp_salt('auth'));$res=wp_safe_remote_get(add_query_arg('f3base_nav_sonda',$sig,home_url('/')),array('timeout'=>10,'redirection'=>0,'limit_response_size'=>2097153,'cookies'=>array(),'headers'=>array('Cache-Control'=>'no-cache'),'user-agent'=>F3Base_Publicacao_Sonda::user_agent('navegacao')));
        $r=!is_wp_error($res)&&wp_remote_retrieve_response_code($res)===200?self::analisar_cabecalho(wp_remote_retrieve_body($res)):array('estado'=>'resposta_indisponivel','referencias'=>array());
        $r+=array('em'=>time(),'contexto'=>$ctx,'url'=>home_url('/'),'limite'=>'Prova da home nesta resposta. Sem marca ou cabeçalho semântico, o uso não é comprovado; não modifica o tema.');if(self::contexto_prova()!==$ctx){return array('ok'=>false,'codigo'=>'contexto_alterado');}F3Base_Options::atualizar_estado('f3base_nav_prova',static fn()=>$r);return array('ok'=>$r['estado']==='observada','prova'=>$r);
    }
    public static function schema(): array {return array('type'=>'object','additionalProperties'=>false,'required'=>array('schema','tipo','id'),'properties'=>array('schema'=>array('type'=>'integer','enum'=>array(1)),'tipo'=>array('type'=>'string','enum'=>array('tema','menu_classico','bloco')),'id'=>array('type'=>'integer','minimum'=>0)));}
    public static function catalogo(array $c): array {
        $c['f3base_nav_id']['operavel']=false;
        $c['f3base_nav_id']['derivada']=true;
        $c['f3base_nav_id']['descricao']='Projeção somente de leitura: ID de bloco, ou zero. Escreva f3base_navegacao.';
        $c['f3base_nav_id']['recusa']=static fn()=> 'Use f3base_navegacao; f3base_nav_id é derivada e não aceita escrita.';
        $c[self::OPTION]=array('rotulo'=>'Navegação do site','descricao'=>'Escolha quem administra a navegação e, se necessário, a referência publicada. O tema continua responsável por exibi-la.','operavel'=>true,'secao'=>'conteudo','campo'=>'grupo','padrao'=>array('schema'=>1,'tipo'=>'tema','id'=>0),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>array(__CLASS__,'recusar'),'schema_config'=>self::schema(),'schema_entrada'=>self::schema(),'subcampos'=>array('schema'=>array('tipo'=>'inteiro','rotulo'=>'Versão do formato'),'tipo'=>array('tipo'=>'enum','rotulo'=>'Origem da navegação','opcoes'=>array('tema'=>'Administrada pelo tema','menu_classico'=>'Menu clássico','bloco'=>'Bloco de navegação')),'id'=>array('tipo'=>'inteiro','rotulo'=>'Referência selecionada')));
        return $c;
    }
    public static function recusar($v): string {
        $r=rest_validate_value_from_schema($v,self::schema());if(is_wp_error($r)){return $r->get_error_message();}
        if($v['tipo']==='tema'){return $v['id']===0?'':'Navegação administrada pelo tema exige ID zero.';}
        if(self::$migrando){return '';}
        return self::diagnostico($v)['referencia_valida']?'':'Selecione um menu clássico existente ou um bloco de navegação publicado do tipo escolhido.';
    }
    public static function preparar_1170(): array {
        $f=F3Base_Options::fotografia_bruta(self::OPTION);if($f['erro']){return array('ok'=>false,'codigo'=>'navegacao_leitura_falhou');}
        $v=$f['existe']?$f['valor']:array('schema'=>1,'tipo'=>'tema','id'=>0);
        $prova=F3Base_Options::procedencia(self::OPTION,$f);
        $reparar=$f['existe']&&($v['tipo']??'')==='bloco'&&!self::diagnostico($v)['referencia_valida']&&($prova['origem']??'')===F3Base_Options::ORIGEM_MIGRACAO;
        if($f['existe']&&!$reparar){return array('ok'=>true,'codigo'=>'navegacao_preservada','referencia_valida'=>self::diagnostico($v)['referencia_valida']);}
        $r=F3Base_Options::gravar(self::OPTION,array('schema'=>1,'tipo'=>'tema','id'=>0),F3Base_Options::ORIGEM_MIGRACAO,$f['revisao']);
        return array('ok'=>!empty($r['persisted']),'codigo'=>$reparar?'migracao_invalida_reparada':'navegacao_inicial','antes'=>$f['valor'],'proveniencia'=>$prova);
    }
    public static function diagnostico(?array $v=null): array {
        $v=$v??F3Base_Options::ler(self::OPTION);$tipo=$v['tipo']??'';$id=(int)($v['id']??0);$valid=false;$ref=null;$assoc=array();
        if($tipo==='tema'){$valid=$id===0;}
        elseif($tipo==='menu_classico'){$term=get_term($id,'nav_menu');$valid=$id>0&&$term&&!is_wp_error($term);if($valid){$ref=array('id'=>$id,'nome'=>$term->name);foreach(get_nav_menu_locations() as $loc=>$term_id){if((int)$term_id===$id){$assoc[]=$loc;}}}}
        elseif($tipo==='bloco'){$p=get_post($id);$valid=$id>0&&$p&&$p->post_type==='wp_navigation'&&$p->post_status==='publish';if($p){$ref=array('id'=>$id,'nome'=>$p->post_title,'status'=>$p->post_status);}}
        $prova=F3Base_Options::ler('f3base_nav_prova');$vigente=($prova['contexto']??'')===self::contexto_prova()&&($prova['em']??0)>time()-DAY_IN_SECONDS;$uso=false;if($vigente){foreach($prova['referencias']??array() as $observada){$uso=$uso||($tipo==='tema'||($observada['tipo']===$tipo&&(int)$observada['id']===$id));}}
        return array('configuracao'=>$v,'referencia_valida'=>(bool)$valid,'referencia'=>$ref,'associacao'=>array('localizacoes'=>$assoc,'suporte_declarado'=>current_theme_supports('f3base-navigation')),'uso_observado'=>array('escopo'=>'requisição atual','blocos_renderizados'=>array_values(array_unique(self::$observados))),'prova_publica'=>$prova,'prova_vigente'=>$vigente,'uso_no_cabecalho'=>$uso?'comprovado':'nao_comprovado','warnings'=>$valid?array():array('referencia_invalida_ou_indisponivel'));
    }
    public static function listar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $page=max(1,(int)($e['pagina']??1));$q=sanitize_text_field($e['busca']??'');$items=array();
        if(($e['tipo']??'')==='menu_classico'){$rows=get_terms(array('taxonomy'=>'nav_menu','hide_empty'=>false,'search'=>$q,'number'=>51,'offset'=>($page-1)*50));if(is_wp_error($rows)){return array('ok'=>false,'codigo'=>'consulta_falhou');}foreach($rows as $p){$items[]=array('id'=>(int)$p->term_id,'nome'=>$p->name);}}
        elseif(($e['tipo']??'')==='bloco'){$rows=get_posts(array('post_type'=>'wp_navigation','post_status'=>'publish','s'=>$q,'posts_per_page'=>51,'offset'=>($page-1)*50,'orderby'=>'ID','order'=>'ASC'));foreach($rows as $p){$items[]=array('id'=>(int)$p->ID,'nome'=>$p->post_title);}}
        else{return array('ok'=>false,'codigo'=>'tipo_invalido');}
        return array('ok'=>true,'itens'=>array_slice($items,0,50),'pagina'=>$page,'proxima_pagina'=>count($items)>50?$page+1:null);
    }
    public static function render(array $v): void {
        echo '<input type="hidden" name="f3base[f3base_navegacao][schema]" value="1"><label for="f3base-nav-tipo">Origem da navegação</label> <select id="f3base-nav-tipo" name="f3base[f3base_navegacao][tipo]">';
        foreach(array('tema'=>'Administrada pelo tema','menu_classico'=>'Menu clássico','bloco'=>'Bloco de navegação') as $k=>$label){echo '<option value="'.esc_attr($k).'" '.selected($v['tipo']??'tema',$k,false).'>'.esc_html($label).'</option>';}
        echo '</select><p><label for="f3base-nav-id">Menu ou bloco (ID e nome)</label> <select id="f3base-nav-id" name="f3base[f3base_navegacao][id]"><option value="0">0 — Administrado pelo tema</option>';
        $seen=array('tema:0');foreach(array('menu_classico'=>'Menus clássicos','bloco'=>'Blocos publicados') as $tipo=>$label){echo '<optgroup label="'.esc_attr($label).'">';$r=self::listar(array('tipo'=>$tipo));foreach($r['itens']??array() as $i){$seen[]=$tipo.':'.$i['id'];echo '<option data-tipo="'.esc_attr($tipo).'" value="'.$i['id'].'" '.selected(($v['tipo']??'')===$tipo?(int)$v['id']:-1,$i['id'],false).'>'.esc_html($i['id'].' — '.$i['nome']).'</option>';}echo '</optgroup>';}
        if(!in_array(($v['tipo']??'tema').':'.(int)($v['id']??0),$seen,true)){echo '<option selected value="'.(int)$v['id'].'">'.(int)$v['id'].' — referência atual fora da lista; confira o diagnóstico</option>';}
        echo '</select></p><p><label for="f3base-nav-busca">Pesquisar por nome</label> <input id="f3base-nav-busca" type="search" maxlength="100"> <button type="button" class="button" id="f3base-nav-pesquisar" data-nonce="'.esc_attr(wp_create_nonce('f3base-navegacao')).'" data-url="'.esc_url(admin_url('admin-ajax.php')).'">Pesquisar</button> <button type="button" class="button" id="f3base-nav-proxima" hidden>Próxima página</button> <span id="f3base-nav-status" role="status"></span></p><p>A pesquisa usa o tipo selecionado e mostra 50 itens por página. A associação não prova a exibição no cabeçalho.</p><details><summary>Diagnóstico da navegação</summary><pre>'.esc_html(wp_json_encode(self::diagnostico($v),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details><p><button type="button" class="button" id="f3base-nav-verificar" data-nonce="'.esc_attr(wp_create_nonce('f3base-navegacao')).'">Verificar cabeçalho público</button> <span id="f3base-nav-prova" role="status">'.esc_html(self::diagnostico($v)['uso_no_cabecalho']).'</span></p>';
        echo '<script>document.getElementById("f3base-nav-verificar").addEventListener("click",async function(){this.disabled=true;var out=document.getElementById("f3base-nav-prova");out.textContent="Verificando…";try{var body=new URLSearchParams({action:"f3base_navegacao_verificar",nonce:this.dataset.nonce});var r=await fetch(ajaxurl,{method:"POST",credentials:"same-origin",body:body});var v=await r.json();out.textContent=v.prova?v.prova.estado:"Não foi possível comprovar";}catch(e){out.textContent="Resposta indisponível. Tente novamente.";}finally{this.disabled=false;}});</script>';
    }
}
