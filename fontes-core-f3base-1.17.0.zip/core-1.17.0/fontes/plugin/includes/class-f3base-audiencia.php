<?php
/** Regras explicáveis de aquisição e automação. Nenhum sinal concede privilégio. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Audiencia {
    const REGRA='audiencia-1.17.0-1';
    public static function automacao(array $s=array(),?string $ua=null): array {
        $ua=$ua??(string)($_SERVER['HTTP_USER_AGENT']??'');$motivos=array();$estado='nao_identificada';
        if(preg_match('/Chrome-Lighthouse|PageSpeed|F3Base-(?:Sonda|Prova)|F3Base\/(?:sonda|verificacao)|UptimeRobot|Pingdom|Site24x7/i',$ua)){$estado='declarada';$motivos[]='assinatura_tecnica';}
        elseif(preg_match('/GPTBot|OAI-SearchBot|ChatGPT-User|ClaudeBot|Claude-SearchBot|Claude-User|PerplexityBot|Googlebot|bingbot/i',$ua)){$estado='declarada';$motivos[]='assinatura_robo';}
        if(preg_match('/HeadlessChrome/i',$ua)){$motivos[]='headless_chrome';if($estado==='nao_identificada'){$estado='provavel';}}
        if(($s['webdriver']??false)===true){$motivos[]='webdriver_declarado';if($estado==='nao_identificada'){$estado='provavel';}}
        return array('automacao'=>$estado,'automacao_motivos'=>implode(',',$motivos),'automacao_regra'=>self::REGRA);
    }
    public static function sinais_validos($s): bool {return is_array($s)&&!array_diff(array_keys($s),array('webdriver'))&&(!isset($s['webdriver'])||is_bool($s['webdriver']));}
    public static function ia(array $a): string {
        $map=array('chatgpt'=>'openai','chatgpt.com'=>'openai','www.chatgpt.com'=>'openai','chat.openai.com'=>'openai','openai'=>'openai','openai.com'=>'openai','claude'=>'claude','claude.ai'=>'claude','www.claude.ai'=>'claude','gemini'=>'gemini','gemini.google.com'=>'gemini','bard.google.com'=>'gemini','perplexity'=>'perplexity','perplexity.ai'=>'perplexity','www.perplexity.ai'=>'perplexity','copilot'=>'copilot','copilot.microsoft.com'=>'copilot');
        $src=strtolower(trim((string)($a['utm_source']??'')));$ref=strtolower(trim((string)($a['referrer']??'')));return $map[$src]??$map[$ref]??'';
    }
    public static function canal(array $a): array {
        $src=strtolower($a['utm_source']??'');$m=strtolower($a['utm_medium']??'');$ref=strtolower($a['referrer']??'');$ia=self::ia($a);$iu=self::ia(array('utm_source'=>$src));$ir=self::ia(array('referrer'=>$ref));$conflicts=array();if($iu&&$ir&&$iu!==$ir){$conflicts[]='provedor_utm_diverge_referrer';}if($m==='organic'&&(!empty($a['gclid'])||!empty($a['oppref']))){$conflicts[]='meio_organico_com_identificador_pago';}
        $r=array('canal'=>'direto_desconhecido','origem_ia'=>$ia,'regra'=>self::REGRA,'evidencia'=>'sem_origem_observavel','conflitos'=>implode(',',$conflicts));
        if(!empty($a['oppref'])||!empty($a['gclid'])||!empty($a['gbraid'])||!empty($a['wbraid'])||in_array($m,array('paid','cpc','ppc','cpm','display','paid_social','paid-social','paidsocial','paid_search','paid-search'),true)){return array_replace($r,array('canal'=>'pago','evidencia'=>'identificador_ou_meio_pago'));}
        if($ia){return array_replace($r,array('canal'=>'ia','evidencia'=>$iu?'utm_ia':'referenciador_ia'));}
        if(in_array($m,array('email','e-mail','newsletter'),true)){return array_replace($r,array('canal'=>'email','evidencia'=>'meio_email'));}
        if($m==='organic'||preg_match('/^(?:www\.)?(?:google\.(?:com|com\.br|pt)|bing\.com|duckduckgo\.com|search\.yahoo\.com|yahoo\.com|search\.brave\.com)$/D',$ref)){return array_replace($r,array('canal'=>'busca_organica','evidencia'=>$m==='organic'?'utm_organic':'referenciador_buscador'));}
        if(in_array($m,array('social','social-organic','organic_social'),true)||in_array($src,array('facebook','instagram','ig','fb','linkedin','tiktok','twitter','x'),true)||preg_match('/^(?:www\.|l\.|lm\.|m\.)?(?:facebook\.com|instagram\.com|linkedin\.com|t\.co|twitter\.com|x\.com|tiktok\.com)$/D',$ref)){return array_replace($r,array('canal'=>'social','evidencia'=>'origem_social_sem_prova_pago'));}
        if($m==='referral'||$ref!==''){return array_replace($r,array('canal'=>'referencia','evidencia'=>'referenciador_externo'));}
        if($src!==''||$m!==''){return array_replace($r,array('canal'=>'outro_identificado','evidencia'=>'utm_outro'));}return $r;
    }
    public static function canais(): array {return array('busca_organica'=>'Busca orgânica','ia'=>'Referências de IA','social'=>'Social','pago'=>'Mídia paga','email'=>'E-mail','referencia'=>'Outros sites','outro_identificado'=>'Outra origem identificada','direto_desconhecido'=>'Direto / desconhecido');}
}
