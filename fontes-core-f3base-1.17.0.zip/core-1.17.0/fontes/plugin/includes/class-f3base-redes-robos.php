<?php
/** Listas oficiais em cache. O IP existe somente na pilha da verificação. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Redes_Robos {
    const EVENTO='f3base_redes_robos_atualizar';
    const FONTES=array(
        'oai-searchbot'=>'https://openai.com/searchbot.json',
        'gptbot'=>'https://openai.com/gptbot.json',
        'chatgpt-user'=>'https://openai.com/chatgpt-user.json',
        'oai-adsbot'=>'https://openai.com/adsbot.json',
        'claude'=>'https://claude.com/crawling/bots.json',
        'google-agent'=>'https://developers.google.com/static/crawling/ipranges/user-triggered-agents.json',
        'googlebot'=>'https://developers.google.com/static/crawling/ipranges/common-crawlers.json',
        'google-user'=>'https://developers.google.com/static/crawling/ipranges/user-triggered-fetchers-google.json'
    );
    private static ?array $listas=null;
    public static function iniciar(): void {
        add_action(self::EVENTO,F3Base_Operacao::callback(self::EVENTO,array(__CLASS__,'atualizar')));
        add_action('init',static function(){if(!empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais'])&&!wp_next_scheduled(self::EVENTO)){wp_schedule_event(time()+60,'daily',self::EVENTO);}},110);
    }
    public static function validar(string $body): ?array {
        if(strlen($body)>1048576){return null;}$v=json_decode($body,true);if(!is_array($v)||!is_array($v['prefixes']??null)||!$v['prefixes']||count($v['prefixes'])>10000){return null;}$out=array();
        foreach($v['prefixes'] as $p){if(!is_array($p)){return null;}$s=$p['ipv4Prefix']??$p['ipv6Prefix']??null;if(!is_string($s)||!self::cidr_valido($s)){return null;}$out[]=$s;}
        $out=array_values(array_unique($out));sort($out);return array('prefixos'=>$out,'versao'=>is_string($v['creationTime']??null)?substr($v['creationTime'],0,64):'nao_informada','sha256'=>hash('sha256',wp_json_encode($out)));
    }
    private static function cidr_valido(string $s): bool {$a=explode('/',$s);if(count($a)!==2||!ctype_digit($a[1])||!filter_var($a[0],FILTER_VALIDATE_IP)){return false;}return (int)$a[1]<=strlen(inet_pton($a[0]))*8;}
    public static function contem(string $ip,string $cidr): bool {
        if(!self::cidr_valido($cidr)||!filter_var($ip,FILTER_VALIDATE_IP)){return false;}[$net,$n]=explode('/',$cidr);$ip=inet_pton($ip);$net=inet_pton($net);if(strlen($ip)!==strlen($net)){return false;}$bits=(int)$n;$bytes=intdiv($bits,8);$rest=$bits%8;
        return substr($ip,0,$bytes)===substr($net,0,$bytes)&&(!$rest||((ord($ip[$bytes])&(255<<(8-$rest)))===(ord($net[$bytes])&(255<<(8-$rest)))));
    }
    public static function atualizar(): array {
        if(empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais'])){return array('ok'=>true,'codigo'=>'desligado');}
        $state=F3Base_Options::ler('f3base_redes_robos');$cursor=(int)($state['cursor']??0);$keys=array_keys(self::FONTES);$results=array();
        // Duas fontes por execução: no máximo 12 segundos de rede, nenhuma chamada por linha.
        for($i=0;$i<2&&$cursor<count($keys);++$i,++$cursor){$key=$keys[$cursor];$url=self::FONTES[$key];$r=wp_safe_remote_get($url,array('timeout'=>6,'redirection'=>0,'limit_response_size'=>1048577,'sslverify'=>true,'cookies'=>array(),'headers'=>array('Accept'=>'application/json'),'user-agent'=>'F3Base-Rede/1.17'));
            $parsed=!is_wp_error($r)&&wp_remote_retrieve_response_code($r)===200?self::validar(wp_remote_retrieve_body($r)):null;
            if($parsed){$state['listas'][$key]=$parsed+array('url'=>$url,'obtida_em'=>time(),'valida_ate'=>time()+7*DAY_IN_SECONDS);$results[$key]='atualizada';}else{$results[$key]='fonte_indisponivel';}
            $state['tentativas'][$key]=array('em'=>time(),'resultado'=>$results[$key]);
        }
        $state['cursor']=$cursor<count($keys)?$cursor:0;$state['atualizado_em']=time();$saved=F3Base_Options::atualizar_estado('f3base_redes_robos',static fn()=>$state);self::$listas=null;
        if($state['cursor']){wp_schedule_single_event(time()+10,self::EVENTO,array('continuacao'));}return array('ok'=>!empty($saved['persisted']),'fontes'=>$results,'pendentes'=>count($keys)-$cursor);
    }
    public static function verificar(string $familia,string $ip,bool $confiavel,?int $em=null,?array $listas=null): array {
        $key=in_array($familia,array('claudebot','claude-searchbot','claude-user'),true)?'claude':(in_array($familia,array('googlebot','googlebot-image'),true)?'googlebot':($familia==='google-gemini-notebook'?'google-user':$familia));
        $r=array('rede_estado'=>'sem_fonte_oficial','rede_lista'=>'','rede_data'=>0,'rede_versao'=>'');
        if($listas===null&&empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais'])){$r['rede_estado']='nao_verificada';return $r;}
        if(!isset(self::FONTES[$key])){return $r;}
        if(!$confiavel||!filter_var($ip,FILTER_VALIDATE_IP)){$r['rede_estado']='ip_nao_confiavel';return $r;}
        if($listas===null){if(self::$listas===null){self::$listas=F3Base_Options::ler('f3base_redes_robos')['listas']??array();}$listas=self::$listas;}
        $list=$listas[$key]??array();if(!$list||($list['valida_ate']??0)<time()){$r['rede_estado']='fonte_expirada';return $r;}
        $r['rede_lista']=$list['sha256'];$r['rede_data']=(int)$list['obtida_em'];$r['rede_versao']=$list['versao'];$r['rede_estado']='fora_das_faixas';
        foreach($list['prefixos'] as $cidr){if(self::contem($ip,$cidr)){$r['rede_estado']='rede_compativel';break;}}
        // A data da lista é preservada; não afirma autenticação na data histórica do acesso.
        return $r;
    }
}
