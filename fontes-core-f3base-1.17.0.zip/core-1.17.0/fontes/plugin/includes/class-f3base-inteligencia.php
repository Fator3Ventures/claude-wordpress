<?php
/** Referências observadas, anotações de qualidade e fotografias autorizadas do Search Console. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Inteligencia {
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        $t=F3Base_Editorial::tabela('inteligencia_auditoria');dbDelta("CREATE TABLE {$t} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 acao varchar(40) NOT NULL,
 chave_sha256 char(64) NOT NULL,
 revisao bigint unsigned NOT NULL,
 operador bigint unsigned NOT NULL,
 em bigint unsigned NOT NULL,
 PRIMARY KEY  (id),
 KEY registro (chave_sha256,em)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        $t=F3Base_Editorial::tabela('referencias_ia');dbDelta("CREATE TABLE {$t} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 chave varchar(128) NOT NULL,
 provedor varchar(24) NOT NULL,
 observado_em bigint unsigned NOT NULL,
 tipo varchar(24) NOT NULL,
 post_id bigint unsigned NOT NULL DEFAULT 0,
 url text NOT NULL,
 topico varchar(250) NOT NULL,
 contexto text NOT NULL,
 evidencia text NOT NULL,
 evidencia_tipo varchar(16) NOT NULL,
 origem varchar(16) NOT NULL,
 revisao_estado varchar(16) NOT NULL,
 revisao bigint unsigned NOT NULL DEFAULT 1,
 criado_em bigint unsigned NOT NULL,
 atualizado_em bigint unsigned NOT NULL,
 operador bigint unsigned NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY chave (chave),
 KEY conteudo (post_id,observado_em),
 KEY provedor (provedor,observado_em)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        $t=F3Base_Editorial::tabela('medicao_anotacoes');dbDelta("CREATE TABLE {$t} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 chave varchar(128) NOT NULL,
 inicio date NOT NULL,
 fim date NOT NULL,
 motivo varchar(500) NOT NULL,
 excluir tinyint NOT NULL DEFAULT 0,
 revisao bigint unsigned NOT NULL DEFAULT 1,
 atualizado_em bigint unsigned NOT NULL,
 operador bigint unsigned NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY chave (chave),
 KEY periodo (inicio,fim)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        $t=F3Base_Editorial::tabela('gsc_diario');dbDelta("CREATE TABLE {$t} (
 chave char(64) NOT NULL,
 universo char(64) NOT NULL,
 propriedade varchar(250) NOT NULL,
 dia date NOT NULL,
 pesquisa varchar(16) NOT NULL,
 escopo varchar(16) NOT NULL,
 post_id bigint unsigned NOT NULL DEFAULT 0,
 url text NOT NULL,
 cliques double NOT NULL,
 impressoes double NOT NULL,
 posicao double NOT NULL,
 estado varchar(16) NOT NULL,
 extraido_em bigint unsigned NOT NULL,
 fonte varchar(128) NOT NULL,
 cobertura text NOT NULL,
 filtros text NOT NULL,
 PRIMARY KEY  (chave),
 KEY periodo (dia,pesquisa,escopo),
 KEY conteudo (post_id,dia)
) ENGINE=InnoDB {$cc};");return !$wpdb->last_error;
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('ia-referencias-ler','Referências observadas com origem e evidência',array(__CLASS__,'referencias'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'post_id'=>array('type'=>'integer','minimum'=>0),'provedor'=>array('type'=>'string'),'origem'=>array('type'=>'string'),'pagina'=>array('type'=>'integer','minimum'=>1)));
            F3Base_Servicos::ability('ia-referencia-gravar','Criar ou revisar referência observada, sem consultar a URL da evidência',array(__CLASS__,'referencia_gravar'),self::schema_referencia(),array('chave','provedor','observado_em','tipo','url','evidencia','evidencia_tipo','origem','revisao_estado'),false);
            F3Base_Servicos::ability('ia-referencia-excluir','Excluir referência observada pela revisão',array(__CLASS__,'referencia_excluir'),array('id'=>array('type'=>'integer','minimum'=>1),'revisao'=>array('type'=>'integer','minimum'=>1)),array('id','revisao'),false);
            F3Base_Servicos::ability('medicao-anotacao-gravar','Anotar dias de testes e excluir explicitamente de análises',array(__CLASS__,'anotar'),array('chave'=>array('type'=>'string','maxLength'=>128),'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'motivo'=>array('type'=>'string','maxLength'=>500),'excluir'=>array('type'=>'boolean'),'revisao'=>array('type'=>'integer','minimum'=>1)),array('chave','de','ate','motivo','excluir'),false);
            F3Base_Servicos::ability('gsc-importar','Importar fotografia autorizada page/date ou total de propriedade',array(__CLASS__,'gsc_importar'),self::schema_gsc(),array('propriedade','pesquisa','escopo','dimensoes','estado','extraido_em','fonte','cobertura','filtros','linhas'),false);
        });
        add_action('admin_post_f3base_inteligencia_gravar',array(__CLASS__,'admin_gravar'));
    }
    public static function schema_referencia(): array {return array(
        'chave'=>array('type'=>'string','pattern'=>'^[A-Za-z0-9_.:-]{1,128}$'),
        'provedor'=>array('type'=>'string','enum'=>array('openai','claude','gemini','perplexity','copilot','outro')),
        'observado_em'=>array('type'=>'integer','minimum'=>1),'tipo'=>array('type'=>'string','enum'=>array('citacao','mencao','recomendacao')),
        'url'=>array('type'=>'string','maxLength'=>2000),'topico'=>array('type'=>'string','maxLength'=>250),'contexto'=>array('type'=>'string','maxLength'=>1000),
        'evidencia'=>array('type'=>'string','maxLength'=>2000),'evidencia_tipo'=>array('type'=>'string','enum'=>array('link_publico','referencia_privada')),
        'origem'=>array('type'=>'string','enum'=>array('manual','externa','teste')),'revisao_estado'=>array('type'=>'string','enum'=>array('pendente','conferida','descartada')),'revisao'=>array('type'=>'integer','minimum'=>1));}
    private static function erro(string $codigo): array {return array('ok'=>false,'codigo'=>$codigo);}
    private static function validar(array $v,array $props,array $required=array()): bool {return !is_wp_error(rest_validate_value_from_schema($v,array('type'=>'object','additionalProperties'=>false,'properties'=>$props,'required'=>$required)));}
    private static function auditar(string $acao,string $chave,int $rev): bool {global $wpdb;return false!==$wpdb->insert(F3Base_Editorial::tabela('inteligencia_auditoria'),array('acao'=>$acao,'chave_sha256'=>hash('sha256',$chave),'revisao'=>$rev,'operador'=>get_current_user_id(),'em'=>time()));}

    public static function referencia_gravar(array $v): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}
        if(!self::validar($v,self::schema_referencia(),array('chave','provedor','observado_em','tipo','url','evidencia','evidencia_tipo','origem','revisao_estado'))||$v['observado_em']>time()+300){return self::erro('referencia_invalida');}
        $path=F3Base_Editorial::caminho($v['url']);if(!$path){return self::erro('url_fora_do_site');}
        if($v['evidencia']===''||($v['evidencia_tipo']==='link_publico'&&(!filter_var($v['evidencia'],FILTER_VALIDATE_URL)||!in_array(wp_parse_url($v['evidencia'],PHP_URL_SCHEME),array('http','https'),true)||wp_parse_url($v['evidencia'],PHP_URL_USER)))){return self::erro('evidencia_invalida');}
        $c=F3Base_Editorial::resolver($v['url']);$row=array('chave'=>$v['chave'],'provedor'=>$v['provedor'],'observado_em'=>$v['observado_em'],'tipo'=>$v['tipo'],'post_id'=>$c['post_id'],'url'=>esc_url_raw($v['url']),'topico'=>sanitize_text_field($v['topico']??''),'contexto'=>sanitize_textarea_field($v['contexto']??''),'evidencia'=>sanitize_text_field($v['evidencia']),'evidencia_tipo'=>$v['evidencia_tipo'],'origem'=>$v['origem'],'revisao_estado'=>$v['revisao_estado']);
        global $wpdb;$t=F3Base_Editorial::tabela('referencias_ia');$old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',$t,$v['chave']),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_falhou');}
        if($old){$igual=true;foreach($row as $k=>$x){$igual=$igual&&(string)$old[$k]===(string)$x;}if($igual){return array('ok'=>true,'id'=>(int)$old['id'],'revisao'=>(int)$old['revisao'],'duplicado'=>true);}if(($v['revisao']??0)!==(int)$old['revisao']){return self::erro('conflito_revisao');}}
        $row['atualizado_em']=time();$row['operador']=get_current_user_id();$row['revisao']=$old?(int)$old['revisao']+1:1;
        if(false===$wpdb->query('START TRANSACTION')){return self::erro('transacao_falhou');}$ok=$old?$wpdb->update($t,$row,array('id'=>$old['id'],'revisao'=>$v['revisao'])):$wpdb->insert($t,$row+array('criado_em'=>time()));if($ok!==1){$wpdb->query('ROLLBACK');return self::erro('conflito_ou_persistencia_falhou');}$id=$old?(int)$old['id']:(int)$wpdb->insert_id;if(!self::auditar('referencia_gravada',$v['chave'],$row['revisao'])||false===$wpdb->query('COMMIT')){$wpdb->query('ROLLBACK');return self::erro('auditoria_falhou');}return array('ok'=>true,'id'=>$id,'revisao'=>$row['revisao']);
    }
    public static function referencia_excluir(array $v): array {if(!current_user_can('manage_options')){return self::erro('sem_permissao');}global $wpdb;if(false===$wpdb->query('START TRANSACTION')){return self::erro('transacao_falhou');}$t=F3Base_Editorial::tabela('referencias_ia');$old=$wpdb->get_row($wpdb->prepare('SELECT chave,revisao FROM %i WHERE id=%d FOR UPDATE',$t,(int)($v['id']??0)),ARRAY_A);if(!$old||(int)$old['revisao']!==(int)($v['revisao']??0)){$wpdb->query('ROLLBACK');return self::erro('conflito_ou_ausente');}$ok=$wpdb->delete($t,array('id'=>(int)$v['id'],'revisao'=>(int)$v['revisao']));if($ok!==1||!self::auditar('referencia_excluida',$old['chave'],(int)$v['revisao'])||false===$wpdb->query('COMMIT')){$wpdb->query('ROLLBACK');return self::erro('persistencia_falhou');}return array('ok'=>true);}

    public static function referencias(array $e=array()): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}global $wpdb;$where='1=1';
        if(!empty($e['de'])){[$de]=F3Base_Editorial::janela_dia($e['de']);$where.=$wpdb->prepare(' AND observado_em>=%d',$de);}if(!empty($e['ate'])){[, $ate]=F3Base_Editorial::janela_dia($e['ate']);$where.=$wpdb->prepare(' AND observado_em<%d',$ate);}
        foreach(array('post_id','provedor','origem') as $k){if(isset($e[$k])&&$e[$k]!==''){$where.=$wpdb->prepare(" AND {$k}=%s",$e[$k]);}}
        $page=max(1,(int)($e['pagina']??1));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY observado_em DESC,id DESC LIMIT 51 OFFSET %d",F3Base_Editorial::tabela('referencias_ia'),($page-1)*50),ARRAY_A);if($wpdb->last_error){return self::erro('consulta_falhou');}return array('ok'=>true,'linhas'=>array_slice($rows,0,50),'proxima_pagina'=>count($rows)>50?$page+1:null,'limites'=>'Observações fornecidas por operador ou serviço externo; testes e pendências não comprovam referências espontâneas. Não há consulta automática de conversas. Permanecem até exclusão explícita; o histórico administrativo registra ação, operador e revisão sem copiar a evidência.');
    }
    public static function anotar(array $v): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}
        if(!preg_match('/^[A-Za-z0-9_.:-]{1,128}$/D',$v['chave']??'')||!self::data($v['de']??'')||!self::data($v['ate']??'')||$v['de']>$v['ate']||!is_bool($v['excluir']??null)||trim($v['motivo']??'')===''||mb_strlen($v['motivo'])>500){return self::erro('anotacao_invalida');}
        global $wpdb;$t=F3Base_Editorial::tabela('medicao_anotacoes');$old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',$t,$v['chave']),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_falhou');}if($old&&($v['revisao']??0)!==(int)$old['revisao']){return self::erro('conflito_revisao');}
        $row=array('chave'=>$v['chave'],'inicio'=>$v['de'],'fim'=>$v['ate'],'motivo'=>sanitize_text_field($v['motivo']),'excluir'=>(int)$v['excluir'],'revisao'=>$old?(int)$old['revisao']+1:1,'atualizado_em'=>time(),'operador'=>get_current_user_id());$ok=$old?$wpdb->update($t,$row,array('id'=>$old['id'],'revisao'=>$v['revisao'])):$wpdb->insert($t,$row);if($ok!==1){return self::erro('persistencia_falhou');}self::auditar('periodo_anotado',$v['chave'],$row['revisao']);return array('ok'=>true,'revisao'=>$row['revisao']);
    }
    public static function anotacoes(string $de,string $ate): array {global $wpdb;return $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE inicio<=%s AND fim>=%s ORDER BY inicio,id',F3Base_Editorial::tabela('medicao_anotacoes'),$ate,$de),ARRAY_A)?:array();}
    private static function data(string $v): bool {$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);return $d&&$d->format('Y-m-d')===$v;}
    public static function schema_gsc(): array {
        return array('propriedade'=>array('type'=>'string','maxLength'=>250),'pesquisa'=>array('type'=>'string','enum'=>array('web','image','video','news','discover','googleNews')),'escopo'=>array('type'=>'string','enum'=>array('paginas','propriedade')),'dimensoes'=>array('type'=>'array','items'=>array('type'=>'string'),'maxItems'=>2),'estado'=>array('type'=>'string','enum'=>array('final','parcial')),'extraido_em'=>array('type'=>'integer','minimum'=>1),'fonte'=>array('type'=>'string','maxLength'=>128),'cobertura'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('completa','limite_linhas','truncada'),'properties'=>array('completa'=>array('type'=>'boolean'),'limite_linhas'=>array('type'=>'integer','minimum'=>0),'truncada'=>array('type'=>'boolean'),'observacao'=>array('type'=>'string','maxLength'=>500))),'filtros'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('pais'=>array('type'=>'string','maxLength'=>3),'dispositivo'=>array('type'=>'string','enum'=>array('DESKTOP','MOBILE','TABLET')))),'linhas'=>array('type'=>'array','maxItems'=>5000,'minItems'=>1,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('dia','cliques','impressoes','posicao'),'properties'=>array('dia'=>array('type'=>'string','format'=>'date'),'url'=>array('type'=>'string','maxLength'=>2000),'cliques'=>array('type'=>'number','minimum'=>0),'impressoes'=>array('type'=>'number','minimum'=>0),'posicao'=>array('type'=>'number','minimum'=>0)))));
    }
    public static function gsc_importar(array $v): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}$schema=self::schema_gsc();if(!self::validar($v,$schema,array_keys($schema))||strlen(wp_json_encode($v))>1048576||(int)($v['extraido_em']??0)>time()+300){return self::erro('fotografia_invalida');}
        $home=wp_parse_url(home_url('/'));$prop=$v['propriedade'];$domain='sc-domain:'.strtolower($home['host']);$prefix=home_url('/');
        if($prop!==$domain&&rtrim($prop,'/').'/'!==$prefix){return self::erro('propriedade_nao_corresponde_ao_site');}
        $dims=$v['dimensoes'];sort($dims);if($dims!==($v['escopo']==='paginas'?array('date','page'):array('date'))){return self::erro('dimensoes_nao_suportadas');}
        if($v['cobertura']['completa']&&$v['cobertura']['truncada']){return self::erro('cobertura_contraditoria');}
        $universo=hash('sha256',wp_json_encode(array($prop,$v['pesquisa'],$v['escopo'],F3Base_Auditoria::ordenar($v['filtros']))));$rows=array();
        foreach($v['linhas'] as $line){$url=$line['url']??'';if(!self::data($line['dia'])||($v['escopo']==='paginas'&&(!filter_var($url,FILTER_VALIDATE_URL)||!F3Base_Editorial::caminho($url)))||($v['escopo']==='propriedade'&&$url!=='')){return self::erro('linha_invalida');}
            foreach(array('cliques','impressoes','posicao') as $k){if(!is_finite((float)$line[$k])){return self::erro('metrica_invalida');}}
            if($line['cliques']>$line['impressoes']){return self::erro('cliques_maiores_que_impressoes');}
            $key=hash('sha256',$universo.'|'.$line['dia'].'|'.$url);if(isset($rows[$key])){return self::erro('linha_duplicada_na_fotografia');}$c=$url?F3Base_Editorial::resolver($url):array('post_id'=>0);
            $rows[$key]=array('chave'=>$key,'universo'=>$universo,'propriedade'=>$prop,'dia'=>$line['dia'],'pesquisa'=>$v['pesquisa'],'escopo'=>$v['escopo'],'post_id'=>$c['post_id'],'url'=>$url,'cliques'=>$line['cliques'],'impressoes'=>$line['impressoes'],'posicao'=>$line['posicao'],'estado'=>$v['estado'],'extraido_em'=>$v['extraido_em'],'fonte'=>sanitize_text_field($v['fonte']),'cobertura'=>wp_json_encode($v['cobertura']),'filtros'=>wp_json_encode($v['filtros']));
        }
        global $wpdb;$t=F3Base_Editorial::tabela('gsc_diario');$guard='f3base-gsc-'.substr(hash('sha256',ABSPATH),0,32);if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$guard))!==1){return self::erro('importacao_em_curso');}
        try{
            $existing=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT propriedade FROM %i LIMIT 2',$t));if($wpdb->last_error||($existing&&$existing!==array($prop))){return self::erro('propriedade_sobreposta_recusada');}
            if(false===$wpdb->query('START TRANSACTION')){return self::erro('transacao_falhou');}
            foreach($rows as $row){$old=$wpdb->get_row($wpdb->prepare('SELECT estado,extraido_em FROM %i WHERE chave=%s FOR UPDATE',$t,$row['chave']),ARRAY_A);if($old&&((int)$old['extraido_em']>$row['extraido_em']||($old['estado']==='final'&&$row['estado']==='parcial'))){continue;}if(false===$wpdb->replace($t,$row)){throw new RuntimeException('persistencia_falhou');}}
            if(!self::auditar('gsc_importado',$universo,count($rows))||false===$wpdb->query('COMMIT')){throw new RuntimeException('commit_falhou');}return array('ok'=>true,'linhas'=>count($rows),'universo'=>$universo,'calendario'=>'America/Los_Angeles','modelo'=>'upsert_por_propriedade_dia_url_pesquisa_filtros','limites'=>'Linhas ausentes não são zero nem totais de propriedade. Cada contribuição substitui a mesma chave, independentemente do agente.');
        }catch(Throwable $e){$wpdb->query('ROLLBACK');return self::erro('importacao_falhou');}finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$guard));}
    }
    public static function gsc(array $e): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}global $wpdb;$where=$wpdb->prepare('dia BETWEEN %s AND %s',$e['de'],$e['ate']);if(!empty($e['post_id'])){$where.=$wpdb->prepare(' AND post_id=%d',$e['post_id']);}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT universo,propriedade,pesquisa,escopo,filtros,SUM(cliques) cliques,SUM(impressoes) impressoes,SUM(posicao*impressoes) peso_posicao,MIN(dia) primeira_data,MAX(dia) ultima_data,COUNT(DISTINCT dia) dias_com_linhas,MAX(extraido_em) extraido_em,SUM(estado='parcial') linhas_parciais FROM %i WHERE {$where} GROUP BY universo,propriedade,pesquisa,escopo,filtros ORDER BY escopo,pesquisa",F3Base_Editorial::tabela('gsc_diario')),ARRAY_A);
        $paginas=$wpdb->get_results($wpdb->prepare("SELECT universo,url,post_id,pesquisa,filtros,SUM(cliques) cliques,SUM(impressoes) impressoes,SUM(posicao*impressoes)/NULLIF(SUM(impressoes),0) posicao_media,100*SUM(cliques)/NULLIF(SUM(impressoes),0) ctr_pct,SUM(estado='parcial') linhas_parciais FROM %i WHERE {$where} AND escopo='paginas' GROUP BY universo,url,post_id,pesquisa,filtros ORDER BY cliques DESC,url LIMIT 5001",F3Base_Editorial::tabela('gsc_diario')),ARRAY_A);if($wpdb->last_error||count($paginas)>5000){return self::erro('reduza_periodo_ou_filtre_conteudo');}
        foreach($rows as &$r){$r['ctr_pct']=$r['impressoes']?100*$r['cliques']/$r['impressoes']:null;$r['posicao_media']=$r['impressoes']?$r['peso_posicao']/$r['impressoes']:null;unset($r['peso_posicao']);}unset($r);return array('ok'=>!$wpdb->last_error,'linhas'=>$rows,'paginas'=>$paginas,'calendario'=>'America/Los_Angeles','limites'=>'Universos separados por propriedade, filtros e tipo de pesquisa. Totais de páginas não substituem os da propriedade. Sem vínculo com pessoas ou sessões.');
    }
    public static function admin_gravar(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-inteligencia');$op=sanitize_key($_POST['operacao']??'');$v=wp_unslash($_POST['dados']??array());
        if(!is_array($v)){wp_die('Dados inválidos.',400);}
        if($op==='referencia'){try{$v['observado_em']=(new DateTimeImmutable((string)($v['observado_em']??''),wp_timezone()))->getTimestamp();}catch(Throwable $e){wp_die('Data inválida.',400);}if(isset($v['revisao'])){$v['revisao']=(int)$v['revisao'];}$r=self::referencia_gravar($v);}
        elseif($op==='anotacao'){$v['excluir']=!empty($v['excluir']);if(isset($v['revisao'])){$v['revisao']=(int)$v['revisao'];}$r=self::anotar($v);}
        elseif($op==='excluir'){$r=self::referencia_excluir(array_map('intval',$v));}else{$r=self::erro('operacao_invalida');}
        if(empty($r['ok'])){wp_die(esc_html($r['codigo']),400);}wp_safe_redirect(admin_url('admin.php?page=f3base-medicao&area='.($op==='anotacao'?'sessoes&visao=sessoes':'agentes&visao=referencias').'&salvo=1'));exit;
    }
}
