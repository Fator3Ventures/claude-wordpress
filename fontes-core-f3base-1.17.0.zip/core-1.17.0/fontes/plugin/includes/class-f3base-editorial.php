<?php
/** Catálogo paginado, vigência de rotas e agregados sem identificadores pessoais. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Editorial {
    const EVENTO='f3base_editorial_atualizar';
    private static array $resolvidos=array();
    private static ?array $markdown_ids=null;
    private static function markdown_selecionado(int $id): bool {if(self::$markdown_ids===null){self::$markdown_ids=array_fill_keys(array_column(F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache(F3Base_Options::ler('f3base_llms')),'id'),true);}return isset(self::$markdown_ids[$id]);}
    public static function tabela(string $nome): string {global $wpdb;return $wpdb->prefix.'f3base_'.$nome;}
    public static function iniciar(): void {
        add_action(self::EVENTO,F3Base_Operacao::callback(self::EVENTO,array(__CLASS__,'executar')));
        add_action('save_post',static function($id){if(!wp_is_post_revision($id)&&!wp_is_post_autosave($id)){self::$markdown_ids=null;self::catalogar((int)$id);}},210);
        foreach(array('created_term','edited_term','delete_term') as $hook){add_action($hook,static function($id){self::fechar_recursos('termo:'.(int)$id);F3Base_Options::atualizar_estado('f3base_editorial_estado',static function($v){$v['recursos_cursor']=0;$v['recursos_completos']=false;$v['recursos_inicio']=time();return $v;});self::agendar();});}
        add_action('deleted_post',static fn($id)=>self::catalogar((int)$id));
        add_action('updated_option',static function($n){if(in_array($n,array('permalink_structure','page_on_front','page_for_posts','show_on_front','f3base_llms'),true)){if($n!=='f3base_llms'){self::fechar_recursos();}F3Base_Options::atualizar_estado('f3base_editorial_estado',static function($s){$s['cursor']=0;$s['catalogo_completo']=false;$s['recursos_cursor']=0;$s['recursos_completos']=false;$s['recursos_inicio']=time();return $s;});self::$markdown_ids=null;self::agendar();}},220);
        add_action('init',array(__CLASS__,'agendar'),101);
    }
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        $t=self::tabela('conteudos');dbDelta("CREATE TABLE {$t} (
 post_id bigint unsigned NOT NULL,
 tipo varchar(32) NOT NULL,
 titulo varchar(250) NOT NULL,
 url text NOT NULL,
 caminho varchar(190) NOT NULL,
 publico tinyint NOT NULL,
 atualizado_em bigint unsigned NOT NULL,
 PRIMARY KEY  (post_id),
 KEY tipo (tipo,publico),
 KEY caminho (caminho)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        $t=self::tabela('conteudo_rotas');dbDelta("CREATE TABLE {$t} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 rota_hash char(64) NOT NULL,
 caminho varchar(190) NOT NULL,
 post_id bigint unsigned NOT NULL DEFAULT 0,
 tipo varchar(32) NOT NULL,
 representacao varchar(20) NOT NULL,
 inicio bigint unsigned NOT NULL,
 fim bigint unsigned NOT NULL DEFAULT 0,
 proveniencia varchar(32) NOT NULL,
 recurso varchar(64) NOT NULL DEFAULT '',
 PRIMARY KEY  (id),
 KEY rota (rota_hash,inicio,fim),
 KEY post_id (post_id,fim),
 KEY recurso (recurso,fim)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        $t=self::tabela('editorial_diario');dbDelta("CREATE TABLE {$t} (
 chave char(64) NOT NULL,
 dia date NOT NULL,
 post_id bigint unsigned NOT NULL DEFAULT 0,
 caminho varchar(190) NOT NULL,
 tipo varchar(32) NOT NULL,
 canal varchar(32) NOT NULL,
 origem_ia varchar(24) NOT NULL,
 classe_trafego varchar(16) NOT NULL,
 automacao varchar(20) NOT NULL,
 metrica varchar(32) NOT NULL,
 contagem bigint unsigned NOT NULL DEFAULT 0,
 soma double NOT NULL DEFAULT 0,
 atualizado_em bigint unsigned NOT NULL,
 PRIMARY KEY  (chave),
 KEY periodo (dia,metrica),
 KEY conteudo (post_id,dia)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        $t=self::tabela('editorial_dias');dbDelta("CREATE TABLE {$t} (
 dia date NOT NULL,
 fechado tinyint NOT NULL DEFAULT 0,
 atualizado_em bigint unsigned NOT NULL,
 qualidade varchar(24) NOT NULL,
 PRIMARY KEY  (dia)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        self::agendar();return true;
    }
    public static function agendar(): void {if(!wp_next_scheduled(self::EVENTO)){wp_schedule_single_event(time()+30,self::EVENTO);}}
    public static function caminho(string $url): string {
        $p=wp_parse_url($url);if(!$p||isset($p['user'])||isset($p['pass'])||(!empty($p['host'])&&strtolower($p['host'])!==strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST)))){return '';}
        if(!empty($p['query'])){parse_str($p['query'],$q);if(isset($q['s'])){return '/@busca';}foreach(array('f3base_markdown','p','page_id') as $k){if(isset($q[$k])&&is_scalar($q[$k])&&preg_match('/^[1-9][0-9]*$/D',(string)$q[$k])){return ($k==='f3base_markdown'?'/@markdown-':'/@post-').$q[$k];}}}
        $s='/'.ltrim($p['path']??'/','/');$s=preg_replace_callback('/%[a-f0-9]{2}/i',static fn($m)=>strtoupper($m[0]),$s);if(strlen($s)>190||preg_match('/[\x00-\x20\x7f]/',$s)){return '';}
        return $s==='/'?'/':rtrim($s,'/');
    }
    public static function tipo($post): string {
        if(!$post){return 'outro';}if((int)get_option('page_for_posts')===(int)$post->ID){return 'indice_artigos';}
        return $post->post_type==='page'?'pagina':($post->post_type==='post'?'artigo':(string)$post->post_type);
    }
    public static function catalogar(int $id): bool {
        global $wpdb;$t=self::tabela('conteudos');$r=self::tabela('conteudo_rotas');$p=get_post($id);
        $publico=$p&&is_post_publicly_viewable($p)&&!$p->post_password;
        $agora=time();if(!$publico){$wpdb->update($t,array('publico'=>0,'atualizado_em'=>$agora),array('post_id'=>$id));$wpdb->query($wpdb->prepare('UPDATE %i SET fim=%d WHERE post_id=%d AND fim=0',$r,$agora,$id));self::$resolvidos=array();return !$wpdb->last_error;}
        $url=(string)get_permalink($p);$path=self::caminho($url);if(!$path){return false;}$tipo=self::tipo($p);
        $rotas=array($path=>'html','/@post-'.$id=>'html');$md=F3Base_Modulo_Llms_Markdown::url_do_item(array('id'=>$id,'url'=>$url),false);
        if($md&&self::markdown_selecionado($id)){$rotas[self::caminho($md)]='markdown_core';}
        if(false===$wpdb->query('START TRANSACTION')){return false;}
        try{
            if(false===$wpdb->replace($t,array('post_id'=>$id,'tipo'=>$tipo,'titulo'=>mb_substr(wp_strip_all_tags($p->post_title),0,250),'url'=>$url,'caminho'=>$path,'publico'=>1,'atualizado_em'=>$agora))){throw new RuntimeException('catalogo_falhou');}
            $old=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE post_id=%d AND fim=0 FOR UPDATE',$r,$id),ARRAY_A);if($wpdb->last_error){throw new RuntimeException('rotas_falharam');}
            foreach($old as $linha){if(isset($rotas[$linha['caminho']])&&$rotas[$linha['caminho']]===$linha['representacao']&&$tipo===$linha['tipo']){unset($rotas[$linha['caminho']]);}elseif(false===$wpdb->update($r,array('fim'=>$agora),array('id'=>$linha['id']))){throw new RuntimeException('rota_fim_falhou');}}
            foreach($rotas as $caminho=>$format){if(false===$wpdb->insert($r,array('rota_hash'=>hash('sha256',$caminho),'caminho'=>$caminho,'post_id'=>$id,'tipo'=>$tipo,'representacao'=>$format,'inicio'=>$agora,'fim'=>0,'proveniencia'=>'catalogo_observado'))){throw new RuntimeException('rota_falhou');}}
            if(false===$wpdb->query('COMMIT')){throw new RuntimeException('catalogo_commit_falhou');}self::$resolvidos=array();return true;
        }catch(Throwable $e){$wpdb->query('ROLLBACK');return false;}
    }
    public static function base(string $path): array {
        $base=rtrim((string)wp_parse_url(home_url(),PHP_URL_PATH),'/');if($base&&str_starts_with($path,$base.'/')){$path=substr($path,strlen($base));}
        $classe='outro';$tipo='outro';$format='nao_resolvida';
        if(in_array($path,array('/llms.txt','/llms-full.txt','/robots.txt','/sitemap.xml','/sitemap_index.xml','/wp-sitemap.xml'),true)){$classe='descoberta';$tipo='descoberta';$format='descoberta';}
        elseif(preg_match('~/(?:wp-json/(?:mcp|f3base)(?:/|$)|wp-admin(?:/|$)|wp-login\.php|xmlrpc\.php|wp-cron\.php)~i',$path)){$classe='operacional';}
        elseif(preg_match('~/(?:wp-content|wp-includes)/~',$path)||preg_match('/\.(?:css|js|png|jpg|jpeg|gif|ico|woff2?|svg|webp)$/i',$path)){$classe='asset';}
        elseif(preg_match('~(?:/\.env|/\.git|phpmyadmin|wp-config|/vendor/phpunit|/etc/passwd)~i',$path)){$classe='varredura';}
        return array('post_id'=>0,'tipo'=>$tipo,'representacao'=>$format,'caminho_requisitado'=>$path,'caminho_canonico'=>'','url_canonica'=>'','proveniencia'=>'nao_resolvida','classe'=>$classe);
    }
    public static function resolver(string $url,?int $em=null,?array $mapa=null): array {
        $path=self::caminho($url);$base=self::base($path);if(!$path||in_array($base['classe'],array('operacional','asset','varredura','descoberta'),true)){return $base;}
        $em=$em??time();$key=$path.'|'.$em;if($mapa===null&&isset(self::$resolvidos[$key])){return self::$resolvidos[$key];}
        if($mapa===null){global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT r.*,c.caminho canonico,c.url FROM %i r LEFT JOIN %i c ON c.post_id=r.post_id WHERE r.rota_hash=%s AND r.inicio<=%d AND (r.fim=0 OR r.fim>%d) ORDER BY r.inicio DESC LIMIT 3',self::tabela('conteudo_rotas'),self::tabela('conteudos'),hash('sha256',$path),$em,$em),ARRAY_A);}else{$rows=array_values(array_filter($mapa[$path]??array(),static fn($r)=>(int)$r['inicio']<=$em&&(!(int)$r['fim']||(int)$r['fim']>$em)));}
        if(count($rows)===1){$r=$rows[0];$base=array_replace($base,array('post_id'=>(int)$r['post_id'],'tipo'=>$r['tipo'],'representacao'=>$r['representacao'],'caminho_canonico'=>$r['canonico']??'','url_canonica'=>$r['url']??'','proveniencia'=>$r['proveniencia'],'classe'=>'editorial'));}
        elseif(count($rows)>1){$base['proveniencia']='rota_ambigua';}
        elseif($path==='/@busca'){$base=array_replace($base,array('tipo'=>'busca','representacao'=>'html','classe'=>'editorial','proveniencia'=>'rota_estrutural'));}
        elseif($path==='/'){$base=array_replace($base,array('tipo'=>get_option('show_on_front')==='posts'?'indice_artigos':'home','representacao'=>'html','classe'=>'editorial','proveniencia'=>'raiz_sem_identidade'));}
        if($mapa===null){if(count(self::$resolvidos)>2000){self::$resolvidos=array();}self::$resolvidos[$key]=$base;}return $base;
    }
    /** Prepara uma vez por arquivo, sem SQL nem WordPress por linha do log. */
    public static function mapa(): array {
        global $wpdb;$out=array();$cursor=0;do{$rows=$wpdb->get_results($wpdb->prepare('SELECT r.*,c.caminho canonico,c.url FROM %i r LEFT JOIN %i c ON c.post_id=r.post_id WHERE r.id>%d ORDER BY r.id LIMIT 1000',self::tabela('conteudo_rotas'),self::tabela('conteudos'),$cursor),ARRAY_A);if($wpdb->last_error){throw new RuntimeException('catalogo_indisponivel');}foreach($rows as $r){$out[$r['caminho']][]=$r;$cursor=(int)$r['id'];}if(memory_get_usage(true)>128*1024*1024){throw new RuntimeException('orcamento_catalogo_excedido');}}while(count($rows)===1000);return $out;
    }
    private static function fechar_recursos(string $identidade=''): void {
        global $wpdb;$where="proveniencia='catalogo_recurso' AND fim=0";if($identidade!==''){$where.=$wpdb->prepare(' AND recurso=%s',$identidade);}$wpdb->query($wpdb->prepare("UPDATE %i SET fim=%d WHERE {$where}",self::tabela('conteudo_rotas'),time()));self::$resolvidos=array();
    }
    private static function recurso(string $url,string $tipo,int $inicio,string $identidade=''): void {
        global $wpdb;$path=self::caminho($url);if(!$path){return;}$t=self::tabela('conteudo_rotas');$old=$wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE rota_hash=%s AND fim=0',$t,hash('sha256',$path)));if(!$old){$wpdb->insert($t,array('rota_hash'=>hash('sha256',$path),'caminho'=>$path,'post_id'=>0,'tipo'=>$tipo,'representacao'=>'html','inicio'=>$inicio,'fim'=>0,'proveniencia'=>'catalogo_recurso','recurso'=>$identidade));}
    }
    private static function recursos(): void {
        global $wpdb;$s=F3Base_Options::ler('f3base_editorial_estado');if(!empty($s['recursos_completos'])){return;}$inicio=(int)($s['recursos_inicio']??time());$cursor=(int)($s['recursos_cursor']??0);$tax=array_keys(get_taxonomies(array('public'=>true)));
        $rows=$tax?$wpdb->get_results($wpdb->prepare('SELECT t.term_id,x.taxonomy FROM '.$wpdb->terms.' t JOIN '.$wpdb->term_taxonomy.' x ON x.term_id=t.term_id WHERE t.term_id>%d AND x.taxonomy IN ('.implode(',',array_fill(0,count($tax),'%s')).') ORDER BY t.term_id LIMIT 200',array_merge(array($cursor),$tax)),ARRAY_A):array();if($wpdb->last_error){return;}
        foreach($rows as $row){$term=get_term((int)$row['term_id'],$row['taxonomy']);$url=$term&&!is_wp_error($term)?get_term_link($term):null;if(is_string($url)){self::recurso($url,$row['taxonomy']==='category'?'categoria':($row['taxonomy']==='post_tag'?'tag':'taxonomia'),$inicio,'termo:'.$row['term_id']);}$cursor=max($cursor,(int)$row['term_id']);}
        if(count($rows)<200){foreach(get_post_types(array('public'=>true),'objects') as $type){if($type->has_archive){$url=get_post_type_archive_link($type->name);if($url){self::recurso($url,'arquivo',$inicio,'arquivo:'.$type->name);}}}}
        F3Base_Options::atualizar_estado('f3base_editorial_estado',static function($v)use($rows,$cursor,$inicio){$v['recursos_cursor']=$cursor;$v['recursos_completos']=count($rows)<200;$v['recursos_inicio']=$inicio;return $v;});self::$resolvidos=array();
    }
    public static function executar(): array {
        global $wpdb;$s=F3Base_Options::ler('f3base_editorial_estado');$fim=microtime(true)+5;$cursor=(int)($s['cursor']??0);$n=0;
        if(empty($s['catalogo_completo'])){
            $ids=$wpdb->get_col($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE ID>%d AND post_status='publish' AND post_type NOT IN ('revision','attachment','wp_navigation','wp_block','wp_template','wp_template_part') ORDER BY ID LIMIT 200",$cursor));
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'catalogo_indisponivel');}
            foreach($ids as $id){if(microtime(true)>$fim){break;}if(!self::catalogar((int)$id)){return array('ok'=>false,'codigo'=>'catalogo_pendente');}$cursor=(int)$id;++$n;}
            F3Base_Options::atualizar_estado('f3base_editorial_estado',static function($v)use($cursor,$n,$ids){$v['cursor']=$cursor;$v['catalogo_completo']=count($ids)<200&&$n===count($ids);$v['catalogado_em']=time();return $v;});
        }
        if(microtime(true)<$fim){self::recursos();}
        $today=wp_date('Y-m-d');$days=$wpdb->get_col($wpdb->prepare('SELECT dia FROM %i WHERE fechado=0 AND dia<%s ORDER BY dia LIMIT 3',self::tabela('editorial_dias'),$today));foreach($days as $day){if(microtime(true)>$fim){break;}self::consolidar($day);}
        self::reter();wp_clear_scheduled_hook(self::EVENTO);$s=F3Base_Options::ler('f3base_editorial_estado');wp_schedule_single_event(time()+(!empty($s['catalogo_completo'])&&!empty($s['recursos_completos'])?300:5),self::EVENTO);
        return array('ok'=>true,'catalogados'=>$n,'cursor'=>$cursor,'catalogo_completo'=>!empty($s['catalogo_completo']));
    }
    public static function marcar_dia(int $stamp): void {
        global $wpdb;$dia=wp_date('Y-m-d',$stamp);$wpdb->query($wpdb->prepare('INSERT INTO %i (dia,fechado,atualizado_em,qualidade) VALUES (%s,0,%d,%s) ON DUPLICATE KEY UPDATE fechado=0',self::tabela('editorial_dias'),$dia,time(),'bruto_disponivel'));
    }
    public static function janela_dia(string $dia): array {$d=new DateTimeImmutable($dia.' 00:00:00',wp_timezone());return array($d->getTimestamp(),$d->modify('+1 day')->getTimestamp());}
    private static function linhas_limitadas(string $sql): array {
        global $wpdb;$n=(int)$wpdb->get_var('SELECT COUNT(*) FROM ('.$sql.') f3base_volume');if($wpdb->last_error){throw new RuntimeException('consulta_indisponivel');}
        $limit=trim((string)ini_get('memory_limit'));$free=$limit==='-1'?384*1024*1024:wp_convert_hr_to_bytes($limit)-memory_get_usage(true)-20*1024*1024;
        if($n>100000||$n*7000>max(0,$free)){throw new RuntimeException('orcamento_consolidacao_excedido');}
        $objects=$wpdb->get_results($sql);if($wpdb->last_error){throw new RuntimeException('consulta_indisponivel');}$wpdb->last_result=array();$rows=array();foreach($objects as $i=>$obj){$rows[]=(array)$obj;unset($objects[$i]);}return $rows;
    }
    public static function consolidar(string $dia): bool {
        if(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$dia)){return false;}global $wpdb;[$de,$ate]=self::janela_dia($dia);if($ate>time()-DAY_IN_SECONDS){return false;}
        $state=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE dia=%s',self::tabela('editorial_dias'),$dia),ARRAY_A);if(($state['qualidade']??'')==='bruto_expirado'){return true;}
        $a=F3Base_Analise::tabela();$t=self::tabela('editorial_diario');if(false===$wpdb->query('START TRANSACTION WITH CONSISTENT SNAPSHOT')){return false;}
        try{
            $wpdb->get_row($wpdb->prepare('SELECT dia FROM %i WHERE dia=%s FOR UPDATE',self::tabela('editorial_dias'),$dia));
            $rows=self::linhas_limitadas($wpdb->prepare('SELECT * FROM %i WHERE criado_em>=%d AND criado_em<%d ORDER BY id LIMIT 100001',$a,$de,$ate));if($wpdb->last_error||count($rows)>100000){throw new RuntimeException('volume_editorial_excedido');}
            $groups=array();$views=array();$add=static function($r,$metric,$n=1,$value=0)use(&$groups,$dia){$publico=self::resolver($r['caminho'],(int)($r['criado_em']??time()));if(!$publico['post_id']&&!in_array($publico['proveniencia'],array('rota_estrutural','raiz_sem_identidade','catalogo_recurso'),true)){$r['caminho']='/@nao-resolvido';$r['post_id']=0;$r['tipo_conteudo']='outro';}$dims=array('dia'=>$dia,'post_id'=>(int)$r['post_id'],'caminho'=>$r['caminho'],'tipo'=>$r['tipo_conteudo'],'canal'=>$r['canal'],'origem_ia'=>$r['origem_ia'],'classe_trafego'=>$r['classe_trafego'],'automacao'=>$r['automacao'],'metrica'=>$metric);$k=hash('sha256',wp_json_encode($dims));if(!isset($groups[$k])){$groups[$k]=array('chave'=>$k)+$dims+array('contagem'=>0,'soma'=>0,'atualizado_em'=>time());}$groups[$k]['contagem']+=$n;$groups[$k]['soma']+=$value;};
            foreach($rows as $r){if($r['tipo']==='pagina'){$key=$r['classe_trafego'].'|'.$r['sessao'].'|'.($r['navegacao']?:'evento:'.$r['id']);if(isset($views[$key])){continue;}$views[$key]=$r;$add($r,'visualizacoes');}elseif(str_starts_with($r['tipo'],'form_')){$add($r,$r['tipo']);}}
            // O vínculo usa navegação + sessão + classe; nenhum ID segue para o agregado.
            $behavior=self::linhas_limitadas($wpdb->prepare('SELECT * FROM %i WHERE criado_em>=%d AND criado_em<%d ORDER BY id LIMIT 100001',F3Base_Modulo_Comportamento::nome_tabela_eventos(),$de,$ate));
            if($wpdb->last_error||count($behavior)>100000){throw new RuntimeException('volume_comportamento_excedido');}
            $leads=self::linhas_limitadas($wpdb->prepare("SELECT sessao,classe_trafego,metodo,captura,dados FROM %i WHERE criado_em>=%s AND criado_em<%s AND lixeira=0 AND eliminacao_pendente=0 LIMIT 100001",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',$de),gmdate('Y-m-d H:i:s',$ate)));
            if($wpdb->last_error||count($leads)>100000){throw new RuntimeException('volume_contatos_excedido');}
            $needed=array();foreach($behavior as $r){if($r['navegacao']){$needed[$r['navegacao']]=true;}}foreach($leads as $r){$d=json_decode($r['dados'],true)?:array();if(!empty($d['navegacao'])){$needed[$d['navegacao']]=true;}}
            // A página pode ter sido aberta antes de meia-noite. Busca indexada, em lotes.
            foreach(array_chunk(array_keys($needed),500) as $navs){$q=$wpdb->prepare('SELECT * FROM %i WHERE tipo=%s AND navegacao IN ('.implode(',',array_fill(0,count($navs),'%s')).') ORDER BY id LIMIT 100001',array_merge(array($a,'pagina'),$navs));$extra=self::linhas_limitadas($q);if($wpdb->last_error||count($extra)>100000){throw new RuntimeException('pareamento_excedido');}foreach($extra as $r){$key=$r['classe_trafego'].'|'.$r['sessao'].'|'.$r['navegacao'];if(!isset($views[$key])){$views[$key]=$r;}}}
            $time=F3Base_Modulo_Comportamento::evento_do_gatilho('tempo-ativo');$scroll=F3Base_Modulo_Comportamento::evento_do_gatilho('rolagem');$section=F3Base_Modulo_Comportamento::evento_do_gatilho('interseccao');$times=array();$scrolls=array();
            foreach($behavior as $r){$key=$r['classe_trafego'].'|'.$r['sessao'].'|'.$r['navegacao'];$nav=$views[$key]??null;if(!$nav){continue;}
                if($r['metrica']===$time){$add($nav,'tempo_ativo_ms',0,max(0,min(30000,(float)$r['valor'])));$times[$key]=$nav;}
                elseif($r['metrica']===$scroll){$scrolls[$key]=max($scrolls[$key]??0,max(0,min(100,(int)$r['detalhe'])));}
                elseif($r['metrica']===$section){$add($nav,'secoes_vistas');}
            }
            foreach($times as $nav){$add($nav,'amostras_tempo');}foreach($scrolls as $key=>$v){$add($views[$key],'rolagem',1,$v);}
            foreach($leads as $r){$d=json_decode($r['dados'],true)?:array();$key=$r['classe_trafego'].'|'.$r['sessao'].'|'.($d['navegacao']??'');$nav=$views[$key]??null;if(!$nav){continue;}if(str_ends_with($r['metodo'],'_cta')){$add($nav,'cliques');}elseif($r['captura']==='aceito'){$add($nav,'envios');}}
            // Sessões iniciadas são aditivas: uma única linha representativa por sessão,
            // atribuída à entrada e à data inicial, nunca a cada dia em que permaneceu ativa.
            $sessions=self::linhas_limitadas($wpdb->prepare('SELECT a.* FROM %i a INNER JOIN (SELECT sessao,MIN(id) id FROM %i WHERE inicio_sessao>=%d AND inicio_sessao<%d GROUP BY sessao) s ON a.id=s.id LIMIT 100001',$a,$a,$de,$ate));if($wpdb->last_error||count($sessions)>100000){throw new RuntimeException('sessoes_excedidas');}
            foreach($sessions as $r){$c=self::resolver($r['entrada']?:$r['caminho'],(int)$r['inicio_sessao']);$r['post_id']=$c['post_id'];$r['caminho']=$r['entrada']?:$r['caminho'];$r['tipo_conteudo']=$c['tipo'];$add($r,'sessoes_iniciadas');}
            if(false===$wpdb->delete($t,array('dia'=>$dia))){throw new RuntimeException('agregado_indisponivel');}foreach($groups as $g){if(false===$wpdb->insert($t,$g)){throw new RuntimeException('agregado_indisponivel');}}
            if(false===$wpdb->replace(self::tabela('editorial_dias'),array('dia'=>$dia,'fechado'=>1,'atualizado_em'=>time(),'qualidade'=>'bruto_disponivel'))||false===$wpdb->query('COMMIT')){throw new RuntimeException('fechamento_falhou');}F3Base_Options::atualizar_estado('f3base_editorial_estado',static function($v)use($dia){if(($v['dia_pendente']??'')===$dia){unset($v['dia_pendente'],$v['erro_consolidacao']);}return $v;});return true;
        }catch(Throwable $e){$wpdb->query('ROLLBACK');$codigo=$e->getMessage();F3Base_Options::atualizar_estado('f3base_editorial_estado',static function($v)use($dia,$codigo){$v['dia_pendente']=$dia;$v['erro_consolidacao']=$codigo;return $v;});return false;}
    }
    /** Nenhum bruto expira enquanto a contribuição anônima correspondente estiver pendente. */
    public static function corte_retencao(): int {return (new DateTimeImmutable('today',wp_timezone()))->modify('-'.F3Base_Modulo_Comportamento::retencao_eventos_dias().' days')->getTimestamp();}
    public static function antes_retencao(): bool {
        global $wpdb;$limite=self::corte_retencao();$fim=microtime(true)+8;
        $min=$wpdb->get_var($wpdb->prepare('SELECT MIN(criado_em) FROM %i WHERE criado_em<%d',F3Base_Analise::tabela(),$limite));if($wpdb->last_error){return false;}if(!$min){return true;}
        $de=new DateTimeImmutable(wp_date('Y-m-d',(int)$min),wp_timezone());$ate=wp_date('Y-m-d',$limite);
        for($d=$de;$d->format('Y-m-d')<$ate;$d=$d->modify('+1 day')){
            $dia=$d->format('Y-m-d');$q=$wpdb->get_var($wpdb->prepare('SELECT qualidade FROM %i WHERE dia=%s',self::tabela('editorial_dias'),$dia));if($q==='bruto_expirado'){continue;}
            if(microtime(true)>$fim||!self::consolidar($dia)){return false;}
            $wpdb->update(self::tabela('editorial_dias'),array('qualidade'=>'bruto_expirado'),array('dia'=>$dia));if($wpdb->last_error){return false;}
        }return true;
    }

    public static function reter(): void {global $wpdb;$meses=(int)(F3Base_Options::ler('f3base_medicao_editorial')['retencao_meses']??13);$dia=(new DateTimeImmutable('now',wp_timezone()))->modify('-'.max(1,min(25,$meses)).' months')->format('Y-m-d');foreach(array('editorial_diario','editorial_dias') as $t){$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE dia<%s',self::tabela($t),$dia));}}
}
