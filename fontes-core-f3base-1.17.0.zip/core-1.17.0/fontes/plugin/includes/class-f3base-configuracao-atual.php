<?php
/** Catálogo e serviços da versão atual. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Configuracao_Atual {
    public static function iniciar(): void {
        add_action('wp_abilities_api_init', array(__CLASS__, 'abilities'));
        add_action(F3Base_Leads_Notificacoes::EVENTO, array(F3Base_Resposta_Visitante::class, 'processar_pendentes'));
        F3Base_Evolucao::iniciar();
        F3Base_Politica::iniciar();
        F3Base_Analise::iniciar();
        F3Base_Relatorios::iniciar();
        F3Base_Release_1170::iniciar();
    }
    public static function catalogo( array $c ): array {
        $c['f3base_contato']['padrao']['carimbar_whatsapp_por_destino']=false;
        $c['f3base_contato']['subcampos']['carimbar_whatsapp_por_destino']=array('tipo'=>'booleano','rotulo'=>'Reconhecer links para este WhatsApp','descricao'=>'Marca automaticamente links HTTPS para o número configurado, sem alterar o destino.','impacto'=>'Ative para incluir links sem classe de CTA. Links wa.me/message continuam exigindo marca explícita.','exemplo'=>'https://wa.me/5511900000000 deve corresponder exatamente ao número completo do site.');
        $c['f3base_politica_canal']['padrao'] = true;
        $c['f3base_politica_canal']['descricao'] = 'Gestão autenticada da política pelo canal, habilitada por padrão; alterações exigem manage_options e revisão.';
        $c['f3base_contato']['rotulo'] = 'Contato, avisos e WhatsApp';
        $c['f3base_contato']['descricao'] = 'Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.';
        $labels = array(
            'email_leads' => array( 'Quem recebe os avisos internos (até cinco)', 'E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.', 'registro' ),
            'avisar_por_clique' => array( 'Enviar aviso interno de clique', 'Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.', 'registro' ),
            'avisar_por_formulario' => array( 'Enviar aviso interno de formulário recebido', 'Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.', 'registro' ),
            'classes_cta' => array( 'Classes adicionais de botões de contato', 'Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.', 'instrumentacao' ),
        );
        foreach ( $c['f3base_contato']['subcampos'] as $k => &$sub ) {
            $spec = $labels[$k] ?? null;
            $sub['grupo_visual'] = $spec[2] ?? 'whatsapp';
            if ( $spec ) { $sub['rotulo'] = $spec[0]; $sub['descricao'] = $spec[1]; $sub['impacto'] = $spec[1]; }
        } unset( $sub );
        $c['f3base_contato']['subcampos']['email_leads']['tipo'] = 'emails';
        $c['f3base_contato']['subcampos']['classes_cta']['tipo'] = 'linhas';
        $c['f3base_llms']['subcampos']['blocos_interface']['tipo'] = 'blocos';
        $c['f3base_llms']['subcampos']['blocos_interface']['descricao'] = 'Selecione os blocos de interface que serão omitidos na conversão Markdown. Valores já salvos são preservados quando o bloco está indisponível.';
        foreach ( $c as &$declaracao ) {
            foreach ( $declaracao['subcampos'] ?? array() as $k => $sub ) {
                if ( 'select' === ( $sub['tipo'] ?? '' ) ) { $declaracao['subcampos'][$k]['tipo'] = 'enum'; }
            }
        } unset( $declaracao );
        return F3Base_Release_1170::catalogo(F3Base_Integracoes::catalogo(F3Base_Navegacao::catalogo(F3Base_Politica::catalogo(F3Base_Evolucao::catalogo($c)))));
    }
    public static function abilities(): void {
        F3Base_Servicos::ability( 'documentacao-ler', 'Índice e leitura paginada da documentação instalada do Core', array( __CLASS__, 'documentacao' ), array( 'arquivo' => array( 'type' => 'string' ), 'linha' => array( 'type' => 'integer', 'minimum' => 1 ), 'limite' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 200 ) ) );
        F3Base_Resposta_Visitante::registrar();
        F3Base_Servicos::ability( 'arquivos-privados-preparar', 'Criar e testar diretório privado configurado, sem enviar mensagens', static function () { return F3Base_Arquivos_Privados::provisionar(); }, array(), array(), false );
    }
    public static function documentacao( array $e = array() ): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $arquivos=array();foreach(array('docs','docs/dados','docs/perfis') as $dir){foreach(glob(F3BASE_PLUGIN_DIR.$dir.'/*')?:array() as $p){if(is_file($p)&&!is_link($p)&&in_array(pathinfo($p,PATHINFO_EXTENSION),array('md','json','sql'),true)){$arquivos[]=$dir.'/'.basename($p);}}}
        sort($arquivos);$aliases=array();foreach(array('DOCUMENTACAO.md','INSTRUCOES-DO-PLUGIN.md','README.md','CHANGELOG.md','CONTRACTS.md') as $n){$aliases[$n]='docs/'.$n;}
        if(empty($e['arquivo'])){return array('ok'=>true,'versao'=>F3BASE_PLUGIN_VERSAO,'indice'=>'docs/DOCUMENTACAO.md','arquivos'=>$arquivos,'aliases'=>$aliases,'base'=>plugin_basename(F3BASE_PLUGIN_ARQUIVO),'ability'=>'f3base/documentacao-ler','acesso'=>'Arquivo ou canal autenticado; bloqueado por HTTP anônimo em Apache com AllowOverride compatível.');}
        $canonical=$aliases[$e['arquivo']]??$e['arquivo'];
        if(!in_array($canonical,$arquivos,true)){return array('ok'=>false,'codigo'=>'documento_nao_catalogado');}
        $p=F3BASE_PLUGIN_DIR.$canonical;
        if(!is_readable($p)||filesize($p)>524288||is_link($p)){return array('ok'=>false,'codigo'=>'documento_indisponivel');}
        $lines = file( $p, FILE_IGNORE_NEW_LINES );
        $inicio = max( 1, (int) ( $e['linha'] ?? 1 ) ); $limite = max( 1, min( 200, (int) ( $e['limite'] ?? 120 ) ) );
        return array( 'ok' => true, 'versao' => F3BASE_PLUGIN_VERSAO, 'arquivo' => $e['arquivo'], 'arquivo_canonico'=>$canonical, 'sha256' => hash_file( 'sha256', $p ), 'linha' => $inicio, 'total_linhas' => count( $lines ), 'texto' => implode( "\n", array_slice( $lines, $inicio - 1, $limite ) ), 'proxima_linha' => $inicio + $limite <= count( $lines ) ? $inicio + $limite : null );
    }
}
