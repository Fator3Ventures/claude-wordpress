# Fontes — F3 Base Core 1.17.0

`fontes/plugin/` é o conteúdo exato do instalador. `suite/versao-1170/README.md` explica a bancada isolada; nunca executar fixtures em produção. `PLANO-APROVADO.md` é o plano de referência. A única base é uma 1.16.0 concluída ou site novo, sem downgrade.

`montar-release.py --saida /DESTINO` reconstrói o instalador e seu manifesto, com timestamps determinísticos. `fechar-release.py` reúne relatório/fontes/hash a partir das evidências. Os runtimes PHP/MySQL/WordPress/Chrome não são distribuídos. A referência 1.16 em `referencias/` serve apenas ao teste de atualização; não há runtime de compatibilidade no plugin.

Leia `fontes/plugin/docs/VALIDACAO.md` e `MAPA-ENTREGA-1.17.md` para os limites e aceites externos.
