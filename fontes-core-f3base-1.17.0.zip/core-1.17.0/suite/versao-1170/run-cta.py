from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parent
php=os.environ['F3BASE_TEST_WORKSPACE']+'/runtime1150/php'
subprocess.run([php,str(r/'http-preparar.php')],check=True,stdout=subprocess.DEVNULL)
subprocess.run([php,str(r/'cta-sem-whatsapp-preparar.php')],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['python3',str(r/'http-server.py'),'node',str(r/'cta-sem-whatsapp.cjs')],check=True)
raise SystemExit(subprocess.run([php,str(r/'cta-sem-whatsapp-conferir.php')]).returncode)
