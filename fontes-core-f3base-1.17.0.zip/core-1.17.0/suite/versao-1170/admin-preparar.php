<?php
require __DIR__.'/bootstrap.php';wp_set_password('fixture-1160-only',1);$u=get_userdata(1);echo wp_json_encode(['user'=>$u->user_login]);
