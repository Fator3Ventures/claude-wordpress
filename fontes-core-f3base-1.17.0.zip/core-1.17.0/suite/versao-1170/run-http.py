from pathlib import Path
import subprocess,os,sys
r=Path(__file__).resolve().parent
php=os.environ['F3BASE_TEST_WORKSPACE']+'/runtime1150/php'
subprocess.run([php,str(r/'http-preparar.php')],check=True,stdout=subprocess.DEVNULL)
if os.environ.get('F3BASE_HTTP_CHILD'):
 if sys.argv[1:]==['performance']:
  subprocess.run([php,str(r/'perf-preparar.php')],check=True,stdout=subprocess.DEVNULL)
  raise SystemExit(subprocess.run(['node',str(r/'performance.mjs')]).returncode)
 raise SystemExit(subprocess.run(['python3',str(r/'run-php.py')]+(sys.argv[1:] or ['http','redirects-bordas'])).returncode)
env=os.environ.copy();env['F3BASE_HTTP_CHILD']='1'
raise SystemExit(subprocess.run(['python3',str(r/'http-server.py'),'python3',str(Path(__file__).resolve())]+sys.argv[1:],env=env).returncode)
