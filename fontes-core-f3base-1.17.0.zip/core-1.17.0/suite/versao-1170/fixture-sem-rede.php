<?php
/* Laboratory only. Mock replies may pass; no live request outside loopback. */
add_filter('pre_http_request',static function($pre,$args,$url){
 if(false!==$pre){return $pre;}
 if(in_array(wp_parse_url($url,PHP_URL_HOST),array('127.0.0.1','localhost','::1'),true)){return false;}
 return new WP_Error('fixture_rede_externa_bloqueada','External network disabled in the local laboratory.');
},PHP_INT_MAX,3);
