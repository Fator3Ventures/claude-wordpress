<?php
require __DIR__.'/bootstrap.php';
$r=[];foreach(F3Base_Options::catalogo() as $n=>$d){if(empty($d['operavel'])){continue;}$row=['rotulo'=>$d['rotulo'],'descricao'=>$d['descricao']??'','schema'=>F3Base_Config_Contrato::schema_entrada($d),'folhas'=>[]];foreach($d['subcampos']??[] as $k=>$f){$row['folhas'][$k]=array_intersect_key($f,array_flip(['rotulo','descricao','tipo','opcoes']));}$r[$n]=$row;}echo wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
