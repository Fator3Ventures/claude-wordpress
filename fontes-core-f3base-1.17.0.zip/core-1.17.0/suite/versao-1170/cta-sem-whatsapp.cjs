const fs=require('node:fs'),path=require('node:path'),{chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=process.env.F3BASE_TEST_WORKSPACE,checks={},errors=[],details={};
(async()=>{
 const b=await chromium.launch({executablePath:path.join(root,'runtime1150/headless/chrome-headless-shell-linux64/chrome-headless-shell'),env:{...process.env,LD_LIBRARY_PATH:''},args:['--no-sandbox']});
 try{
  const p=await b.newPage();await p.route('**/*',route=>new URL(route.request().url()).hostname==='127.0.0.1'?route.continue():route.abort());
  p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://127.0.0.1:8150/cta-sem-whatsapp/',{waitUntil:'load'});
  checks.no_form=await p.locator('[data-f3base-formulario]').count()===0;
  checks.no_floating_button=await p.locator('#f3base-whatsapp-flutuante').count()===0;
  checks.script_deferred=await p.locator('script[src*="f3base-leads.min.js"][defer]').count()===1;
  const response=p.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname.endsWith('/lead'),{timeout:15000});
  await p.locator('#cta-sem-whatsapp').click();
  const r=await response;const payload=r.request().postDataJSON();details.correlacao=payload.correlation_id;details.http=r.status();details.destination=payload.destino;
  checks.real_endpoint_accepted=r.status()===201;
  checks.internal_destination=payload.destino.endsWith('/destino-1150/');
  checks.correlation_present=typeof payload.correlation_id==='string'&&payload.correlation_id.length>0;
  await p.waitForURL('**/destino-1150/');checks.navigation_preserved=true;
  checks.no_js_errors=errors.length===0;
 }catch(e){errors.push(e.message);checks.execution=false;}finally{await b.close();}
 const falhas=Object.keys(checks).filter(k=>!checks[k]);fs.writeFileSync(path.join(__dirname,'evidencias/cta-sem-whatsapp.json'),JSON.stringify({checks,falhas,errors,details},null,2));console.log(JSON.stringify({total:Object.keys(checks).length,falhas,errors}));if(falhas.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
