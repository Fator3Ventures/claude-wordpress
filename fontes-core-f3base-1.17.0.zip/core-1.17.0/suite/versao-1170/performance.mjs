/** Warm WordPress/WPSC artifact replay; original Google code served locally, collectors blocked. */
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=process.env.F3BASE_TEST_WORKSPACE,suite=path.dirname(new URL(import.meta.url).pathname),out=path.join(suite,'evidencias/performance');fs.mkdirSync(out,{recursive:true});
const {default:lighthouse}=await import(path.join(root,'lab1150/downloads/node_modules/lighthouse/core/index.js'));
const home=fs.readFileSync(path.join(suite,'evidencias/perf-home.html'),'utf8'),current=fs.readFileSync(path.join(root,'work/core-1.17.0/fontes/plugin/assets/f3base-analise.js'),'utf8');
const saved=fs.existsSync(path.join(out,'matriz.json'))?JSON.parse(fs.readFileSync(path.join(out,'matriz.json'),'utf8')):{};
let active={arm:'5',google:'imediato',name:'warm'};const requests=saved.requests||[],bodies=saved.bodies||[];
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://127.0.0.1:8151');const start=Date.now();
 if(u.pathname==='/google-fixture.js'){res.setHeader('content-type','application/javascript');res.end(fs.readFileSync(path.join(root,'lab1150/downloads/gtag-fixture.js')));return;}
 if(u.pathname==='/fixture-collect'){res.writeHead(204);res.end();return;}
 if(u.pathname==='/fixture-analysis.js'){res.setHeader('content-type','application/javascript');res.end(current);return;}
 if(u.pathname==='/perf/'){
  let body=home.replaceAll('127.0.0.1:8150','127.0.0.1:8151').replace(/src="[^\"]*f3base-analise.min.js[^\"]*"/,'src="/fixture-analysis.js"');
  const script=`<script>document.cookie='f3base_teste=1;path=/';window.__perf={load:0,longtasks:[],errors:[]};addEventListener('load',()=>__perf.load=performance.now());new PerformanceObserver(l=>__perf.longtasks.push(...l.getEntries().map(x=>({start:x.startTime,duration:x.duration})))).observe({type:'longtask',buffered:true});window.addEventListener('error',e=>__perf.errors.push(e.message));window.dataLayer=window.dataLayer||[];window.gtag=function(){dataLayer.push(arguments)};gtag('js',new Date());gtag('config','G-F311500000',{send_page_view:false,transport_url:location.origin+'/fixture-collect'});function googleLoad(){if(window.googleStarted)return;window.googleStarted=performance.now();let s=document.createElement('script');s.src='/google-fixture.js';s.async=true;document.head.append(s)};${active.google==='imediato'?'googleLoad();':"addEventListener('pointerdown',googleLoad,{once:true});addEventListener('keydown',googleLoad,{once:true});setTimeout(googleLoad,5000);"}</script>`;
  body=body.replace('<head>','<head>'+script).replace('</body>',`<script>if(window.f3baseAnaliseDados){f3baseAnaliseDados.endpoint+='?fixture_run=${active.name}';}</script></body>`);res.setHeader('content-type','text/html; charset=utf-8');res.setHeader('Cache-Control','no-store');res.end(body);return;
 }
 let data=[];req.on('data',x=>data.push(x));req.on('end',()=>{
  const body=Buffer.concat(data);let head={...req.headers,host:'127.0.0.1:8150','x-f3base-teste':'1'};if(head.origin)head.origin='http://127.0.0.1:8150';if(head.referer)head.referer=head.referer.replace('8151','8150');
  const proxy=http.request({host:'127.0.0.1',port:8150,path:req.url,method:req.method,headers:head},up=>{
   const chunks=[];up.on('data',x=>chunks.push(x));up.on('end',()=>{const response=Buffer.concat(chunks);res.writeHead(up.statusCode,up.headers);res.end(response);requests.push({run:u.searchParams.get('fixture_run')||active.name,path:u.pathname,method:req.method,start,duration:Date.now()-start,status:up.statusCode,requestBytes:body.length,responseBytes:response.length});
    if(req.method==='POST'&&u.pathname.endsWith('/analise')){try{bodies.push({run:u.searchParams.get('fixture_run')||active.name,request:JSON.parse(body),response:JSON.parse(response),start,latency:Date.now()-start});}catch{}}
   });});proxy.on('error',e=>{res.writeHead(502);res.end(e.message)});proxy.end(body);
 });
});
await new Promise(r=>server.listen(8151,'127.0.0.1',r));let browser;const rows=saved.rows||[];
try{
 browser=await chromium.launch({executablePath:path.join(root,'runtime1150/headless/chrome-headless-shell-linux64/chrome-headless-shell'),headless:true,env:{...process.env,LD_LIBRARY_PATH:''},args:['--no-sandbox','--disable-dev-shm-usage','--remote-debugging-port=9229','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost']});
 const ctx=await browser.newContext();const p=await ctx.newPage();
 // Run ordering is rotated across repetitions; all arms share the same captured public cache HIT.
 const matrix=[];for(let rep=0;rep<3;rep++)for(const formFactor of ['mobile','desktop']){matrix.push({arm:'5',google:'imediato',formFactor,rep});}
 const limit=Number(process.env.F3_PERF_LIMIT||matrix.length);
 for(const row of matrix.slice(0,limit)){
  if(rows.some(x=>x.name===[row.arm,row.google,row.formFactor,row.rep].join('-')))continue;
  active={...row,name:'warm-'+[row.arm,row.google,row.formFactor,row.rep].join('-')};await p.goto('http://127.0.0.1:8151/perf/');await p.waitForTimeout(150);await p.goto('about:blank');await p.waitForTimeout(200);active.name=active.name.replace(/^warm-/,'');
  const mobile=row.formFactor==='mobile';const config=mobile?undefined:(await import(path.join(root,'lab1150/downloads/node_modules/lighthouse/core/config/desktop-config.js'))).default;
  const result=await lighthouse('http://127.0.0.1:8151/perf/',{port:9229,output:'json',logLevel:'error',onlyCategories:['performance']},config);

  const lhr=result.lhr,art=result.artifacts;fs.writeFileSync(path.join(out,active.name+'.settings.json'),JSON.stringify(lhr.configSettings,null,2));fs.writeFileSync(path.join(out,active.name+'.lhr.json'),JSON.stringify(lhr));fs.writeFileSync(path.join(out,active.name+'.trace.json'),JSON.stringify(art.Trace));fs.writeFileSync(path.join(out,active.name+'.devtools.json'),JSON.stringify(art.DevtoolsLog));
  const net=lhr.audits['network-requests'].details.items;
  const nav=art.DevtoolsLog.find(x=>x.method==='Network.requestWillBeSent'&&x.params.request.url==='http://127.0.0.1:8151/perf/');
  const navWall=nav?.params.wallTime*1000;const netEntries=art.DevtoolsLog.filter(x=>x.params?.timestamp);const endTime=Math.max(...netEntries.map(x=>x.params.timestamp));const loadEntry=art.DevtoolsLog.find(x=>x.method==='Page.loadEventFired');const analysisInTrace=art.DevtoolsLog.filter(x=>x.method==='Network.requestWillBeSent'&&x.params.request.method==='POST'&&x.params.request.url.includes('/analise'));const windowInfo={nav:nav?.params.timestamp,load:loadEntry?.params.timestamp,end:endTime,firstPost:analysisInTrace[0]?.params.timestamp??null};

  const a=lhr.audits,rqs=requests.filter(x=>x.run===active.name),events=bodies.filter(x=>x.run===active.name),summary={...active,windowInfo,lighthouseVersion:lhr.lighthouseVersion,fetchTime:lhr.fetchTime,runtimeError:lhr.runtimeError||null,score:lhr.categories.performance.score,lcp:a['largest-contentful-paint'].numericValue,cls:a['cumulative-layout-shift'].numericValue,tbt:a['total-blocking-time'].numericValue,requests:rqs.length,bytes:rqs.reduce((s,x)=>s+x.responseBytes,0),analysisRequests:events.length,analysisEvents:events.flatMap(x=>x.request.eventos||[]).length,analysisConfirmed:events.flatMap(x=>x.response.confirmados||[]).length,firstAnalysisMs:events.length?Math.min(...events.map(x=>x.start))-navWall:null,eventLatencyMs:events.flatMap(x=>(x.request.eventos||[]).map(e=>x.start-e.criado_em*1000)),analysisStatuses:rqs.filter(x=>x.path.endsWith('/analise')).map(x=>x.status),longtasks:a['long-tasks']?.details?.items||[]};rows.push(summary);fs.writeFileSync(path.join(out,'matriz.json'),JSON.stringify({environment:{wordpress:'7.1.2',wpsc:'3.1.3',browser:browser.version(),cache:'HTML real de HIT wp-cache reproduzido; cache de navegador preservado dentro de cada processo Lighthouse; aquecimento em contexto separado',google:'script oficial capturado e servido localmente; sem conexão comercial; não mede latência do Google',throttling:'Presets oficiais mobile/desktop sem override das janelas. Configuração resolvida salva em *.settings.json; replay local não equivale ao PSI.'},rows,requests,bodies},null,2));console.log(JSON.stringify({index:rows.length,total:limit,...summary}));
 }
}finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
