from pathlib import Path
import subprocess,sys
suite=Path(__file__).resolve().parent
commands=[['python',str(suite/'gerar-docs.py')],['python',str(suite/'run-php.py'),'fechamento','credenciais','volume'],['python',str(suite/'upgrade.py')],['python',str(suite/'run-ux.py')],['python',str(suite/'concorrencia.py')]]
for cmd in commands:
 r=subprocess.run(cmd)
 if r.returncode:raise SystemExit(r.returncode)
