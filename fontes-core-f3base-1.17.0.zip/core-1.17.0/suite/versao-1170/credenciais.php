<?php
require __DIR__.'/bootstrap.php';
$checks=[];$details=[];$calls=[];$mode='normal';$account='999';
function ck($k,$v,$d=null){global $checks,$details;$checks[$k]=(bool)$v;if(!$v){$details[$k]=$d;}}
add_filter('pre_wp_mail',static fn()=>true);
delete_option('f3base_pipedrive_orcamento');
$cfg=array_replace(F3Base_Integracoes::definicoes()['f3base_pipedrive']['padrao'],['ativo'=>true,'dominio'=>'fixture.pipedrive.com','responsavel'=>7]);
F3Base_Options::gravar('f3base_pipedrive',$cfg);F3Base_Options::gravar('f3base_pipedrive_token','synthetic-verification-token');
add_filter('pre_http_request',static function($pre,$args,$url)use(&$calls,&$mode,&$account){
 $calls[]=wp_parse_url($url,PHP_URL_PATH);$GLOBALS['wpdb']->query('DELETE FROM '.F3Base_Leads_Repositorio::tabela('leads_janelas'));
 $path=preg_replace('#^/api/#','',wp_parse_url($url,PHP_URL_PATH));$data=[];
 if($path==='v1/users/me'){$data=['company_id'=>$account,'id'=>7];if($mode==='rotate'){$mode='normal';F3Base_Options::gravar('f3base_pipedrive_token','rotated-verification-token');}elseif($mode==='config'){$mode='normal';$c=F3Base_Options::ler('f3base_pipedrive');$c['responsavel']=8;F3Base_Options::gravar('f3base_pipedrive',$c);}}
 elseif($path==='v1/users'){$data=[['id'=>7,'active_flag'=>true],['id'=>8,'active_flag'=>true]];}
 elseif($path==='v2/dealFields'&&$mode==='empty_options'){$data=[['field_code'=>str_repeat('b',40),'field_type'=>'enum','options'=>[]]];}
 elseif(in_array($path,['v1/leadLabels','v1/activityTypes','v2/dealFields'],true)){$data=[];}
 else{return new WP_Error('fixture_route_rejected');}
 return ['headers'=>[],'body'=>wp_json_encode(['success'=>true,'data'=>$data,'additional_data'=>[]]),'response'=>['code'=>200],'cookies'=>[]];
},9999,3);
$r=F3Base_Integracoes::verificar();ck('verification_binds_current_credential',$r['ok']&&F3Base_Integracoes::pipedrive_verificado(),$r);
$before=count($calls);$mode='rotate';$r=F3Base_Integracoes::verificar();ck('rotation_during_verification_not_stamped',$r['codigo']==='verificacao_superada'&&!F3Base_Integracoes::pipedrive_verificado(),$r);ck('rotation_no_mixed_token_catalog',count($calls)===$before+1,$calls);
$account='1000';$r=F3Base_Integracoes::verificar();ck('new_token_rechecks_account',$r['ok']&&get_option('f3base_pipedrive_estado')['conta_id']==='1000'&&F3Base_Integracoes::pipedrive_verificado(),$r);
$before=count($calls);$mode='config';$r=F3Base_Integracoes::verificar();ck('config_during_verification_not_stamped',$r['codigo']==='verificacao_superada'&&!F3Base_Integracoes::pipedrive_verificado()&&count($calls)===$before+1,$r);
$r=F3Base_Integracoes::verificar();ck('new_config_revalidated',$r['ok']&&F3Base_Integracoes::pipedrive_verificado(),$r);
$c=F3Base_Options::ler('f3base_pipedrive');$c['mapa_campos']=['unidade'=>str_repeat('b',40)];$c['unidade']='99';F3Base_Options::gravar('f3base_pipedrive',$c);$mode='empty_options';$r=F3Base_Integracoes::verificar();ck('empty_enum_catalog_rejects_configured_option',!$r['ok']&&$r['codigo']==='alternativa_nao_confirmada:unidade'&&!F3Base_Integracoes::pipedrive_verificado(),$r);
F3Base_Options::gravar('f3base_pipedrive_token','');$before=count($calls);$r=F3Base_Integracoes::verificar();ck('deleted_token_no_network',!$r['ok']&&$r['codigo']==='credencial_indisponivel'&&count($calls)===$before&&!F3Base_Integracoes::pipedrive_verificado(),$r);
ck('diagnostic_no_plaintext_tokens',!str_contains(wp_json_encode(F3Base_Integracoes::diagnostico()),'verification-token'));
$failed=array_keys(array_filter($checks,static fn($v)=>!$v));echo wp_json_encode(['checks'=>$checks,'falhas'=>$failed,'detalhes'=>$details],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);exit($failed?1:0);
