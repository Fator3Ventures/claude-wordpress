<?php
require __DIR__.'/bootstrap.php';
foreach(array_keys(F3Base_Integracoes::definicoes()) as $n){$v=F3Base_Options::ler($n);$v['ativo']=false;F3Base_Options::gravar($n,$v);}
update_option('cron',[]);
$c=F3Base_Options::ler('f3base_contato');$c['whatsapp_e164']='';$c['flutuante']=true;$c['email_leads']=[];$c['avisar_por_clique']=false;$c['avisar_por_formulario']=false;F3Base_Options::gravar('f3base_contato',$c);
$p=get_page_by_path('cta-sem-whatsapp');wp_insert_post(['ID'=>$p?$p->ID:0,'post_type'=>'page','post_status'=>'publish','post_name'=>'cta-sem-whatsapp','post_title'=>'CTA sem WhatsApp','post_content'=>'<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"className":"f3base-acao-contato"} --><div class="wp-block-button f3base-acao-contato"><a id="cta-sem-whatsapp" class="wp-block-button__link wp-element-button" href="/destino-1150/">Falar com a equipe</a></div><!-- /wp:button --></div><!-- /wp:buttons -->']);
if(function_exists('wp_cache_clear_cache')){wp_cache_clear_cache();}
echo "fixture_ready\n";
