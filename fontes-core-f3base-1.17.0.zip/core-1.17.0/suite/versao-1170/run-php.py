from pathlib import Path
import os,json,subprocess,sys
r=Path(__file__).parent;e=r/'evidencias';e.mkdir(exist_ok=True);rows=[]
for n in (sys.argv[1:] or ['core','crm','capi','bordas','llms']):
 run=subprocess.run([str(Path(os.environ['F3BASE_TEST_WORKSPACE'])/'runtime1150/php'),str(r/(n+'.php'))],capture_output=True,text=True)
 try:d=json.loads(run.stdout)
 except:d={'saida':run.stdout[-3000:]}
 d['stderr']=run.stderr[-4000:];(e/(n+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2));rows.append({'teste':n,'exit':run.returncode,'falhas':d.get('falhas'), 'total':len(d.get('checks',{})) or d.get('total')});print(json.dumps(rows[-1]),flush=True)
(e/'php-resumo.json').write_text(json.dumps(rows,indent=2));sys.exit(any(r['exit'] for r in rows))
