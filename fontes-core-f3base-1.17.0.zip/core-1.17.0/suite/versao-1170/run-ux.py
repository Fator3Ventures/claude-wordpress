from pathlib import Path
import subprocess,os,json
r=Path(__file__).resolve().parent;env=os.environ.copy();p=env['F3BASE_TEST_WORKSPACE']+'/runtime1150/php'
x=subprocess.run([p,str(r/'ux-preparar.php')],capture_output=True,text=True,check=True);env['F3BASE_UX']=x.stdout.strip();code=subprocess.run(['python',str(r/'http-server.py'),'node',str(r/'ux-editorial.cjs')],env=env).returncode
raise SystemExit(code)
