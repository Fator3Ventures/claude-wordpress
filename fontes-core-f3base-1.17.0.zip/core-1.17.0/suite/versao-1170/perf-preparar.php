<?php
require __DIR__.'/bootstrap.php';
update_option('f3base_comportamento',array_replace(F3Base_Options::ler('f3base_comportamento'),['ligado'=>true]));
update_option('f3base_consentimento',array_replace(F3Base_Options::ler('f3base_consentimento'),['modo'=>'legado','padrao'=>'pre-aprovado']));
if(function_exists('wp_cache_clear_cache')){wp_cache_clear_cache();}
$resp=null;for($i=0;$i<3;$i++){$resp=wp_remote_get(home_url('/'),['headers'=>['X-F3Base-Teste'=>'1']]);}
$body=wp_remote_retrieve_body($resp);
if(!str_contains($body,'f3base-analise.min.js')||!F3Base_Cache_Pagina::hit_comprovado($resp,$body)){fwrite(STDERR,'Home não contém análise ou HIT não demonstrado');exit(1);}
file_put_contents(__DIR__.'/evidencias/perf-home.html',$body);
echo json_encode(['bytes'=>strlen($body),'hit'=>true,'headers'=>(array)wp_remote_retrieve_headers($resp),'perfil'=>F3Base_Cache_Pagina::perfil()]);
