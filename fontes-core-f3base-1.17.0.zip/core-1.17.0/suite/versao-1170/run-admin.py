from pathlib import Path
import os,subprocess,json
r=Path(__file__).resolve().parent;env=os.environ.copy();php=env['F3BASE_TEST_WORKSPACE']+'/runtime1150/php'
result=subprocess.run([php,str(r/'admin-preparar.php')],capture_output=True,text=True,check=True)
env['F3BASE_ADMIN_USER']=json.loads(result.stdout)['user']
raise SystemExit(subprocess.run(['python3',str(r/'http-server.py'),'node',str(r/'admin.cjs')],env=env).returncode)
