<?php
require __DIR__.'/bootstrap.php';
$path=__DIR__.'/evidencias/cta-sem-whatsapp.json';$r=json_decode(file_get_contents($path),true);
$rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare('SELECT record_id,metodo,post_id,correlacao FROM %i WHERE correlacao=%s',F3Base_Leads_Repositorio::tabela(),$r['details']['correlacao']),ARRAY_A);
$r['checks']['database_one_capture']=count($rows)===1;
$r['checks']['database_method_by_destination']=count($rows)===1&&$rows[0]['metodo']==='contato_cta';
$r['checks']['database_post_id']=count($rows)===1&&(int)$rows[0]['post_id']===(int)get_page_by_path('cta-sem-whatsapp')->ID;
$r['falhas']=array_keys(array_filter($r['checks'],static fn($v)=>!$v));$r['details']['registros']=$rows;file_put_contents($path,wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo wp_json_encode(['total'=>count($r['checks']),'falhas'=>$r['falhas']]);exit($r['falhas']?1:0);
