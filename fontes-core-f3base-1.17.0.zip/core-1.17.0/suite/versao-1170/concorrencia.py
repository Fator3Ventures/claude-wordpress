from pathlib import Path
import os,subprocess,json,time,shutil
HERE=Path(__file__).resolve().parent;ROOT=Path(os.environ.get('F3BASE_TEST_WORKSPACE',str(HERE.parents[3])));php=ROOT/'runtime1150/php';cmd=[str(php),str(HERE/'concorrencia.php')];bar=HERE/'evidencias/barreira';shutil.rmtree(bar,ignore_errors=True);bar.mkdir()
subprocess.run(cmd+['preparar'],check=True,capture_output=True)
workers=[subprocess.Popen(cmd+['worker',str(i)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for i in range(12)]
try:
 end=time.time()+20
 while len(list(bar.glob('ready*')))<12 and time.time()<end:time.sleep(.03)
 (bar/'go').write_text('1');out=[]
 for p in workers:
  stdout,stderr=p.communicate(timeout=30)
  if p.returncode:raise RuntimeError(stderr+stdout)
  out.append(json.loads(stdout))
 r=subprocess.run(cmd+['conferir'],capture_output=True,text=True);result=json.loads(r.stdout);result['checks']['doze_respostas_sem_falha']=all(x['status']==200 for x in out);result['respostas']=out
 (HERE/'evidencias/concorrencia.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'checks':result['checks'],'falhas':result['falhas']}));assert all(result['checks'].values())
finally:
 for p in workers:
  if p.poll() is None:p.kill()
 shutil.rmtree(bar,ignore_errors=True)
