# Fator3 Site Core 1.74.0

O código entregue está em `work/plugin/base-site-core-fator3/`. A raiz do instalador é `base-site-core-fator3/`. A documentação para o operador começa em `docs/DOCUMENTACAO.md` dentro dessa árvore. O Core requer WordPress 7.1.4 e PHP 8.3 de 64 bits ou superiores, em instalação única.

## Reproduzir o instalador

Na pasta extraída do fonte, use Python 3.12 e execute o comando abaixo. O script usa as permissões, o carimbo de data e a ordem de arquivos da entrega.

```bash
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.74.0-instalador.zip
```

Compare o SHA-256 com o relatório externo. Para verificar o código, execute `F3BASE_PHP=/caminho/php python3 tests/verificar-entrega.py`. Os requisitos e a execução dos ensaios funcionais estão em `tests/README.md`. As mudanças desta rodada estão em PHP e JavaScript administrativo, lido diretamente pelo WordPress. Os scripts antigos para gerar os assets públicos ficam como histórico de desenvolvimento.

## Conferir a entrega

| Caminho | Conteúdo |
|---|---|
| `PLANO-1.74.0.md` e `reference/` | Escopo, pedido 374 e normas da rodada |
| `history/1.73.0-runtime/` | Base exata usada na atualização e manifesto de arquivos |
| `evidence/1740/` | Resultados em PHP 8.4, resultados da repetição em PHP 8.3 na subpasta php83, paridade e inventário, estado do Site-Teste |
| `source-manifest.json` | SHA-256 de cada arquivo do fonte, com exclusão do próprio manifesto |
| `RELATORIO-PRE-FECHAMENTO.md` | Cópia do relatório anterior ao empacotamento do fonte |

Para reproduzir o ZIP do fonte, execute `python3 build/empacotar-fonte.py ../base-site-core-fator3-1.74.0-fonte.zip` na raiz de nome `base-site-core-fator3-1.74.0-fonte`. Use as evidências entregues para reproduzir os bytes. Uma nova execução do laboratório grava outros identificadores e horários no material de teste.
