# Fator3 MCP 0.32.0

Entrega das demandas do impacto Core 1.53.0 revisão 2, referentes aos pedidos Core 300/301. Exceção estrita e tipada para a política f3base_formularios_sinais; validação das fronteiras de correio sem concessão de capacidades pelo MCP. Base direta 0.31.0; WordPress mínimo 7.1.2 / PHP 8.3.6.

Instale somente wp-mcp-fator3-0.32.0-instalador.zip. Consulte o relatório externo para hashes, evidências próprias, reversão e limites. Código em fontes/wp-mcp-fator3, ferramentas em tools, manuais em docs. system/guide fornece documentação autenticada; documentos release-0320 e redacao descrevem esta entrega.

Build: python3 tools/sync_docs.py; python3 tools/build_packages.py --out DIRETORIO. O build gera índices de proteção. Use o instalador extraído nos testes, não a árvore de desenvolvimento. Fechar fonte por tools/pack_source.py após relatório e evidências; hash do próprio fonte somente no relatório externo. Testes novos em tools/release0320, regressões anteriores preservadas. Nenhum QA, banco ou credencial de laboratório integra o instalador.
