<?php
/**
 * Resumable copy/verify/switch; the frozen legacy source remains available for recovery.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;
use Fator3\McpGoogle\{
    Ability, Automation\Jobs, Automation\Results, Lock, Options, Records, Response
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Migration {
    public const OPTION = 'f3_mcp_google_storage';
    public const HOOK = 'f3_mcp_google_storage_step';
    public static function init(): void {
        add_action( self::HOOK, array( self::class, 'advance_scheduled' ) );
        \Fator3\McpGoogle\Recovery::run(static function () {
            if (!self::active() && function_exists('wp_next_scheduled') && !wp_next_scheduled(self::HOOK)) \Fator3\McpGoogle\Automation\Scheduling::schedule(self::HOOK,time()+5);
            });
    }
    private static array $scheduled=[];
    public static function advance_scheduled(): array {
        $site=function_exists('get_current_blog_id')?get_current_blog_id():1;
        return self::$scheduled[$site]??(self::$scheduled[$site]=self::advance(true));
    }
    public static function advance(bool $automatic=false): array {
        return \Fator3\McpGoogle\Recovery::run(static fn()=>self::advance_admitted($automatic));
    }
    private static function advance_admitted(bool $automatic): array {
        $budget=$automatic?Budget::automatic():new Budget();
        if (!$automatic) {
            $ready=CronStore::ensure_ready(true);
            if (is_wp_error($ready)) return Response::fail($ready);
        }
        $result = self::state() ? self::step(100,$budget) : self::begin($budget);
        if ( ! self::active() && 'failed' !== ( self::state()['phase'] ?? '' ) && function_exists( 'wp_schedule_single_event' ) ) {
            $result['scheduling']=\Fator3\McpGoogle\Automation\Scheduling::schedule(self::HOOK,time()+15);
            if (empty($result['scheduling']['success'])) {
                $result['success']=false;
                $result['error_code']=$result['scheduling']['error_code']??'f3_google_cron_schedule_failed';
            }
        }
        if (self::active()) {
            $result['maintenance']=$automatic?Maintenance::once($budget):Maintenance::run($budget);
            if(empty($result['maintenance']['success'])) {
                $result['success']=false;
                $result['error_code']='f3_google_maintenance_failed';
                $result['message']='Armazenamento indexado ativo; manutenção pendente por falha local.';
            }
        }
        return $result;
    }
    public static function register(): void {
        Ability::register(
            'google/storage-status',
            'any',
            array(
                'label' => 'Google: estado da migração',
                'output_schema'=>['type'=>'object','properties'=>['maintenance'=>Maintenance::schema()]],
                'description' => 'Consulta local da migração e do armazenamento ativo.',
                'callback' => static fn () => Response::ok( array( 'storage' => self::state(), 'maintenance' => Maintenance::status(), 'cache' => \Fator3\McpGoogle\Cache::status() ) ),
            )
        );
        Ability::register(
            'google/migrate-storage',
            'any',
            array(
                'label' => 'Google: continuar migração',
                'description' => 'Copia e verifica um lote; preserva a origem. A fila permanece pausada até a verificação final.',
                'mode' => 'write',
                'callback' => static function (): array {
            return current_user_can( 'manage_options' ) ? self::advance() : Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) );
                },
            )
        );
    }
    public static function state(): array {
        $stored = Options::stored( self::OPTION );
        $value = $stored['success'] ? ( $stored['value'] ?? array() ) : array(
            'phase' => 'failed',
            'error' => 'state_unreadable',
        );
        return is_array( $value ) ? $value : array(
            'phase' => 'failed',
            'error' => 'state_corrupt',
        );
    }
    public static function active(): bool {
        return 'indexed' === ( self::state()['phase'] ?? 'legacy' );
    }
    public static function paused(): bool {
        return in_array( self::state()['phase'] ?? 'legacy', array( 'drain', 'copy', 'verify', 'failed' ), true );
    }
    public static function begin(?Budget $budget=null): array {
        return \Fator3\McpGoogle\Recovery::run(static fn()=>self::begin_admitted($budget??new Budget()));
    }
    private static function begin_admitted(Budget $budget): array {
        if ( self::state() ) {
            return self::step(100,$budget);
        }
        $admission = Lock::acquire( 'storage-admission', 30 );
        if ( null === $admission ) {
            return Admission::blocked();
        }
        $lock = Lock::acquire( 'queue-admission', 60 );
        if ( null === $lock ) {
            Lock::release( $admission );
            return Response::fail( new \WP_Error( 'f3_google_migration_busy', 'Aguarde a admissão em andamento.' ) );
        }
        try {
            // Freeze admission first. Already-running workers stop at their next dispatch guard.
            $saved = Options::set(
                self::OPTION,
                array(
                    'phase' => 'drain',
                    'cursor' => '',
                    'copied' => 0,
                    'started_at' => time(),
                )
            );
            if ( ! $saved['success'] ) {
                return $saved;
            }
        }
        finally {
            Lock::release( $lock );
            Lock::release( $admission );
        }
        return self::step(100,$budget);
    }
    private static function draining(): bool {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
        $names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'f3_mcp_google_lock_' ) . '%' ) );
        if ( $wpdb->last_error ) {
            return true;
        }
        $self = 'f3_mcp_google_lock_' . hash( 'sha256', 'storage-migration' );
        foreach ( $names as $name ) {
            if ( $name === $self ) {
                continue;
            }
            $lease = Options::stored( $name );
            if ( ! $lease['success'] ) {
                return true;
            }
            if ( is_array( $lease['value'] ) && ( $lease['value']['expires'] ?? 0 ) > time() ) {
                return true;
            }
        }
        return false;
    }
    public static function step( int $limit = 100,?Budget $budget=null ): array {
        return \Fator3\McpGoogle\Recovery::run(static fn()=>self::step_admitted($limit,$budget??new Budget($limit)));
    }
    private static function step_admitted(int $limit,Budget $budget): array {
        global $wpdb;
        $limit = max( 1, min( 100, $limit ) );
        $lock = Lock::acquire( 'storage-migration', 120 );
        if ( null === $lock ) {
            return Response::fail( new \WP_Error( 'f3_google_migration_busy', 'Migração em execução.' ) );
        }
        try {
            $state = self::state();
            if ( 'indexed' === ( $state['phase'] ?? '' ) ) {
                return Response::ok( $state );
            }
            if ( ! $state ) {
                return Response::fail( new \WP_Error( 'f3_google_migration_not_started', 'Inicie a migração.' ) );
            }
            if ( self::draining() ) {
                return Response::ok( $state + array( 'reason' => 'waiting_for_workers' ) );
            }
            $installed = Repository::install();
            if ( is_wp_error( $installed ) ) {
                return self::fail( $state, '', $installed->get_error_message() );
            }
            if ( in_array( $state['phase'], array( 'drain', 'failed' ), true ) ) {
                $state['phase'] = isset( $state['verify_cursor'] ) ? 'verify' : 'copy';
                unset( $state['error'], $state['failed_record'] );
            }
            $verify = 'verify' === $state['phase'];
            $cursor = $verify ? ( $state['verify_cursor'] ?? '' ) : ( $state['cursor'] ?? '' );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
            $names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name>%s ORDER BY option_name ASC LIMIT %d", $wpdb->esc_like( Records::PREFIX ) . '%', $cursor, $limit ) );
            if ( $wpdb->last_error ) {
                return self::fail( $state, '', 'Leitura da origem falhou.' );
            }
            $processed=0;
            foreach ( $names as $name ) {
                if (!$budget->claim()) break;
                if (!Lock::owned($lock)) return Response::fail(new \WP_Error("f3_google_lock_lost","Trava da migração perdida."));
                ++$processed;
                if ( ! preg_match( '/^' . preg_quote( Records::PREFIX, '/' ) . '([a-z]+)_(.+)$/D', $name, $parts ) ) {
                    return self::fail( $state, $name, 'Identificador inválido.' );
                }
                $source = Options::stored( $name );
                if ( ! $source['success'] || ! $source['exists'] || ! is_array( $source['value'] ) ) {
                    return self::fail( $state, $name, 'Registro ilegível; origem preservada.' );
                }
                $kind = $parts[1];
                $id = $parts[2];
                $value = self::transform( $kind, $source['value'] );
                $children = self::children( $kind, $id, $source['value'] );
                $row_chunks = 'job' === $kind ? Results::externalize( $value ) : array();
                // A source can contain many child rows; its durable subcursor shares the global budget.
                $unit=0;
                $resume=($state['unit_record']??null)===$name ? (int)($state['unit_cursor']??0) : 0;
                foreach (['result'=>$row_chunks,'item'=>$children] as $child_kind=>$entries) {
                    foreach ($entries as $child_id=>$child) {
                        ++$unit;
                        if ($unit<=$resume) continue;
                        if (!$budget->claim()) {
                            $state['unit_record']=$name;
                            $state['unit_cursor']=$unit-1;
                            if (!Lock::owned($lock)) return Response::fail(new \WP_Error('f3_google_lock_lost','Trava da migração perdida.'));
                            $saved=Options::set(self::OPTION,$state);
                            return $saved['success']?Response::ok($state+['budget'=>$budget->result()]):$saved;
                        }
                        if (!Lock::owned($lock)) return Response::fail(new \WP_Error('f3_google_lock_lost','Trava da migração perdida.'));
                        if (!self::copy_verified($child_kind,(string)$child_id,$child,$verify)) return self::fail($state,$name,'Resultado filho não confirmado.');
                        $state['unit_record']=$name;
                        $state['unit_cursor']=$unit;
                    }
                }
                unset($state['unit_record'],$state['unit_cursor']);
                if ( ! self::copy_verified( $kind, $id, $value, $verify ) ) {
                    return self::fail( $state, $name, 'Integridade divergente; origem preservada.' );
                }
                $state[ $verify ? 'verify_cursor' : 'cursor' ] = $name;
                $counter = $verify ? 'verified' : 'copied';
                $state[ $counter ] = (int) ( $state[ $counter ] ?? 0 ) + 1;
                if (!Lock::owned($lock)) return Response::fail(new \WP_Error('f3_google_lock_lost','Trava da migração perdida.'));
                if (!Lock::owned($lock)) return Response::fail(new \WP_Error('f3_google_lock_lost','Trava da migração perdida.'));
                $saved = Options::set( self::OPTION, $state );
                if ( ! $saved['success'] ) {
                    return $saved;
                }
            }
            if ( $processed===count($names) && count( $names ) < $limit ) {
                if ( ! $verify ) {
                    $state['phase'] = 'verify';
                    $state['verify_cursor'] = '';
                    $state['verified'] = 0;
                }
                else {
                    if ( $state['verified'] !== $state['copied'] ) {
                        return self::fail( $state, '', 'Contagens divergentes.' );
                    }
                    $legacy = Options::stored( Options::AUDIT );
                    if ( ! $legacy['success'] || ( $legacy['exists'] && ! is_array( $legacy['value'] ) ) ) {
                        return self::fail( $state, Options::AUDIT, 'Log legado ilegível.' );
                    }
                    $audit_position=0;
                    $audit_complete=true;
                    foreach ( $legacy['value'] ?? array() as $index => $entry ) {
                        ++$audit_position;
                        if ($audit_position<=(int)($state['legacy_audit_cursor']??0)) continue;
                        if (!$budget->claim()) {
                            $audit_complete=false;
                            break;
                        }
                        if (!Lock::owned($lock)) return Response::fail(new \WP_Error('f3_google_lock_lost','Trava da migração perdida.'));
                        if ( ! is_array( $entry ) ) {
                            return self::fail( $state, Options::AUDIT, 'Evento legado inválido.' );
                        }
                        $id = 'legacy_' . hash( 'sha256', (string) $index . '|' . wp_json_encode( $entry ) );
                        $entry['migration_origin'] = Options::AUDIT;
                        $legacy_time = strtotime( ( $entry['time'] ?? '' ) . ' UTC' );
                        $entry['created_at'] = $entry['created_at'] ?? ( $legacy_time ? $legacy_time : $state['started_at'] );
                        if ( ! self::copy_verified( 'audit', $id, $entry, false ) ) {
                            return self::fail( $state, Options::AUDIT, 'Evento legado não confirmado.' );
                        }
                        $state['legacy_audit_cursor']=$audit_position;
                    }
                    if ($audit_complete) {
                        $state['phase'] = 'indexed';
                        $state['completed_at'] = time();
                        $state['legacy_audit_count'] = count( $legacy['value'] ?? array() );
                    }
                }
            }
            if (!Lock::owned($lock)) return Response::fail(new \WP_Error('f3_google_lock_lost','Trava da migração perdida.'));
            $saved = Options::set( self::OPTION, $state );
            if ( $saved['success'] && 'indexed' === $state['phase'] ) {
                Jobs::schedule_tick();
            }
            return $saved['success'] ? Response::ok( $state+['budget'=>$budget->result()] ) : $saved;
        }
        finally {
            Lock::release( $lock );
        }
    }
    private static function copy_verified( string $kind, string $id, array $value, bool $verify ): bool {
        $old = Repository::get( $kind, $id );
        if ( is_wp_error( $old ) ) {
            return false;
        }
        if ( null === $old && ! $verify && ! Repository::insert( $kind, $id, $value ) ) {
            return false;
        }
        return Repository::get( $kind, $id ) === $value;
    }
    private static function children( string $kind, string $id, array $value ): array {
        $out = array();
        if ( 'job' === $kind ) {
            foreach ( $value['results'] ?? array() as $index => $result ) {
                $out[ Results::id( $id, (int) $index ) ] = array(
                    'task' => $id,
                    'index' => (int) $index,
                    'result' => $result,
                    'created_at' => $value['created_at'] ?? 0,
                );
            }
        }
        return $out;
    }
    private static function transform( string $kind, array $value ): array {
        if ( 'job' === $kind ) {
            if ( ! isset( $value['context'] ) && in_array( $value['status'] ?? '', array( 'pending', 'running', 'dispatching' ), true ) ) {
                $value['status'] = ! empty( $value['write'] ) && in_array( $value['status'], array( 'running', 'dispatching' ), true ) ? 'unknown' : 'blocked';
                $value['blocked_reason'] = 'legacy_context_required';
            }
            if ( ! empty( $value['results'] ) ) {
                $value['result_count'] = count( $value['results'] );
                unset( $value['results'] );
            }
        }
        if ( 'schedule' === $kind && ! isset( $value['context'] ) ) {
            $value['enabled'] = false;
            $value['blocked_reason'] = 'legacy_context_required';
        }
        return $value;
    }
    private static function fail( array $state, string $record, string $message ): array {
        $state['phase'] = 'failed';
        $state['failed_record'] = $record;
        $state['error'] = $message;
        $saved = Options::set( self::OPTION, $state );
        return Response::fail(
            new \WP_Error( 'f3_google_migration_failed', $message ),
            array(
                'storage' => $state,
                'failure_state_persisted' => $saved['success'],
            )
        );
    }
}
