<?php
/** Bounded error projection with identity-checked recovery. No age-based recovery. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Options, Lock
};
use Fator3\McpGoogle\Storage\CronStore;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class CronErrors {
    public static function identity(array $error): string {
        if (is_string($error['error_id']??null)) return $error['error_id'];
        $fields=[];
        foreach (['at','code','phase','resource','cause_code','origem','run_id','connection_id','storage','attempts','event_persisted'] as $key) $fields[$key]=$error[$key]??null;
        return 'legacy:'.hash('sha256',wp_json_encode($fields));
    }
    public static function snapshot(string $cid): array {
        $event=CronStore::latest($cid,'incident');
        $projection=Options::stored('f3_mcp_google_cron_error_'.$cid);
        if (is_wp_error($event)||!$projection['success']) return ['success'=>false,'error'=>null];
        $old=$projection['value'];
        foreach ([$old,$event] as $row) if ($row!==null && (!is_array($row)||!is_int($row['at']??null)||!is_string($row['code']??null))) return ['success'=>false,'error'=>null];
        $chosen=$event;
        if ($old && (!$event || self::identity($old)===self::identity($event) || [$old['at'],$old['error_id']??'']>=[$event['at'],$event['error_id']??''])) $chosen=$old;
        return ['success'=>true,'error'=>$chosen,'identity'=>$chosen?self::identity($chosen):null];
    }
    /** Caller confirmed terminal event and projection after observing this identity. */
    public static function resolve(string $cid,array $observed,array $row): array {
        if (empty($observed['error']) || isset($observed['error']['resolved_at']) || ($observed['error']['phase']??'')==='maintenance') return ['success'=>true];
        $lock=Lock::acquire_result('cron-incident:'.$cid,30);
        if (!$lock['success']) return $lock;
        try {
            $now=self::snapshot($cid);
            if (!$now['success']) return ['success'=>false,'code'=>'f3_google_cron_read','cause_code'=>'f3_google_option_read','retryable'=>false];
            // The comparison is made under the same lease as every new incident writer.
            if ($now['identity']!==$observed['identity']) return ['success'=>true,'newer_error_preserved'=>true];
            if (!Lock::owned($lock['lock'])) return ['success'=>false,'code'=>'f3_google_lock_lost','cause_code'=>'f3_google_lock_changed','retryable'=>true];
            $error=$now['error'];
            $error['resolved_at']=time();
            $error['resolved_by']=['run_id'=>$row['run_id'],'origem'=>$row['origem'],'connection_id'=>$cid,'basis'=>'terminal_event_and_projection_verified'];
            $r=Options::set('f3_mcp_google_cron_error_'.$cid,$error);
            return $r['success']?['success'=>true]:['success'=>false,'code'=>'f3_google_cron_resolution','cause_code'=>$r['error_code'],'retryable'=>false];
        }
        finally {
            Lock::release($lock['lock']);
        }
    }
}
