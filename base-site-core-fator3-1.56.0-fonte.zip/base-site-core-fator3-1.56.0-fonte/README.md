# Fonte Core 1.56.0

Base direta 1.55.0. Runtime em work/plugin/base-site-core-fator3. Pedidos e impacto Meta recebido em inputs/1560; normas revisão 5 em inputs/1510. Evidências da rodada em evidence/1560.

Leia docs/RELEASE-1.56.0.md e CONVERSAS-1.56.md dentro do runtime. build/package-installer.py e package-source.py fecham os artefatos. Tests request-307-311, request-309-collector e request-311-transport validam decisões, deduplicação, cifra, exclusão e prova sem DATA. APIs simuladas não substituem homologação de fornecedor; confira o relatório externo.
