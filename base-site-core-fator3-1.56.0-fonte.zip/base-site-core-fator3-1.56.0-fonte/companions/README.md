# Acompanhantes para reproduzir os testes

Runtimes dos acompanhantes não são republicados no fonte Core. O instalador Core é autônomo.

| Pacote | Versão | Escopo da 1.56.0 |
|---|---|---|
| wp-mcp-fator3 | 0.33.0 | Decorador original, autorização, descoberta/documentação e instalação real |
| wp-mcp-meta-fator3 | 0.11.1 | SDK original instagram-first-message/1.0.0, Graph simulado, recibos e reconciliação |
| wp-mcp-google-fator3 | 0.19.0 | Convivência no Site-Teste; sem nova prova de fornecedor |
| wp-mcp-linkedin-fator3 | 0.10.1 | Convivência no Site-Teste; sem nova prova de fornecedor |
| wp-mcp-pipedrive-fator3 | 0.1.0 | Convivência; pipeline CRM próprio do Core testado com transporte simulado |

Forneça o instalador MCP original (888204 bytes, SHA-256 `f16ee3e31e4143ffb42c566ea6da4f2da81d3771a01a0f90b5d34e3d02ac8caa`) e extraia sua pasta nos plugins do laboratório. Fonte recebido: SHA-256 `fdef8375bd72533062dff506be52664057619655e948afa3b89e22d4114e2ed6`. Relatório em inputs/1550.

Meta 0.11.1: instalador SHA-256 `b084bf2498eddc0eb93410c04efdd166ba84b2831541e2b5a2acf8dcfe3aa6c1`; fonte SHA-256 `e12e1d6f3a9b9daa8907840bdda40903ec307596971cdff458e7de88a25415b1`. Relatório/impacto recebido em inputs/1560. O SDK fornece registro de consumidor e leitura/reconciliação de recibos; não fornece exclusão local coordenada. Consulte impacto emitido e seção de pendências do relatório Core. Não ativar captação real antes de configurar os dois lados e homologar a conta.

Google 0.19.0 original: SHA-256 `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1`. Pipedrive completo exige PHP 8.3.36 e não deve ser ativado no laboratório PHP 8.3.6. O cliente Pipedrive público do Core mantém contrato 1.0.0. As provas anteriores continuam identificadas por versão nos diretórios históricos.
