# Fator3 Site Core 1.56.0

Comece em DOCUMENTACAO.md e AGENTES-1.56.0.md. Pedidos 307–311 em RELEASE-1.56.0.md e CONVERSAS-1.56.md; contatos externos do pedido 302 permanecem em CONTATOS-EXTERNOS-1.54.md. Contrato administrativo 8.21.0, cliente pipedrive-api-client/1.0.0 preservado.
