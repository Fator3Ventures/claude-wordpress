# Validação — Core 1.56.0

O relatório externo descreve as provas executadas e limitações desta entrega. Testes sintéticos exercitam aprovação sem entrega (307), classificação de telefone (308), paginação/deduplicação/cifra e CRM (309), histórico instalado (310), prova SMTP sem DATA e fases (311), consumidor Meta real com Graph simulado, autorização e regressões de contatos/e-mail. Provas de fornecedor real são separadas. Não presumir publicação da frota nem envio comercial.
