<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** All candidate checks precede domain writes. Principals are never replaced by a rebase. */
final class ConnectionChanges {
    public static function save(array $i): array {
        Access::admin();Schemas::validate('save-connection',$i);$id=Util::id($i['connection_id']);
        return Store::lock('connection:'.$id,static function()use($i,$id){
            $row=Store::get('connection',$id);$expected=$i['expected_revision'];
            if(($row['revision']??0)!==$expected)throw new Fault('revision_conflict','A conexão mudou. Reabra a conexão antes de salvar.');
            if(!$row&&count(Store::list('connection',0,100))>=100)throw new Fault('connection_limit','Limite de 100 conexões.');
            $old=$row?Connections::defaults($row['value']):self::empty($id);$principal=Access::principal();
            $c=self::prepare($old,$i,$expected,false);
            return self::commit($old,$c,$expected,$principal,false,'save-connection');
        });
    }
    private static function empty(string $id): array {
        return Connections::defaults(['id'=>$id,'label'=>$id,'token'=>'','client_secret'=>'','client_id'=>'','application_id'=>'','enabled'=>true,'expires_at'=>0,'users'=>[get_current_user_id()],'assets'=>array_fill_keys(Config::CHANNELS,[]),'forms'=>[],'api_version'=>Config::API_VERSION,'created_by'=>get_current_user_id(),'created_at'=>time(),'retention_days'=>90,'remote_proof'=>null]);
    }
    private static function prepare(array $old,array $i,int $revision,bool $switch): array {
        $c=$old;
        foreach(['token','client_secret'] as $key)if(isset($i[$key])&&$i[$key]!==''){
            if(preg_match('/[\x00-\x20]/',$i[$key]))throw new Fault('invalid_input','A credencial não pode conter espaços ou caracteres de controle.');
            $c[$key]=$i[$key];
        }
        if(!empty($i['clear_token']))$c['token']='';if(!empty($i['clear_client_secret']))$c['client_secret']='';
        foreach(['label','client_id','application_id'] as $key)if(isset($i[$key]))$c[$key]=sanitize_text_field($i[$key]);
        foreach(['enabled','expires_at','retention_days','retention_mode'] as $key)if(isset($i[$key]))$c[$key]=$i[$key];
        if(isset($i['api_version'])){if(!preg_match(Config::API_PATTERN,$i['api_version']))throw new Fault('invalid_input','Versão da API inválida.');$c['api_version']=$i['api_version'];}
        if(isset($i['users'])){$c['users']=array_values(array_unique($i['users']));foreach($c['users'] as $u)if(!get_userdata($u))throw new Fault('invalid_input','Usuário inexistente.');}
        if(isset($i['assets']))foreach($i['assets'] as $channel=>$ids){foreach($ids as $id)Util::numeric($id);$c['assets'][$channel]=array_values(array_unique($ids));}
        if(isset($i['forms'])&&$i['forms'])throw new Fault('unsupported','Formulários não pertencem a este plugin.');
        $appChanged=$old['client_id']!==$c['client_id']||$old['client_secret']!==$c['client_secret'];
        $tokenChanged=$old['token']!==$c['token'];
        if($appChanged)Credentials::appFormat($c);
        $clearingSecret=!empty($i['clear_client_secret'])&&$old['client_id']===$c['client_id'];
        $needsProof=$c['token']!==''&&($tokenChanged||($appChanged&&!$clearingSecret)||$switch);
        if($needsProof){
            $candidate=$c+['revision'=>$revision];$proof=Credentials::candidate($candidate);
            $prior=$old['token_identity'];
            // Legacy connections may have no independent app proof. Inspect the old token using the supplied app.
            if($old['token']!==''&&empty($prior['app_verified'])){
                $source=$candidate;$source['token']=$old['token'];
                try{$prior=Credentials::identity($source);}catch(Fault $e){
                    if(in_array($e->reason,['revision_conflict','busy','storage_unavailable'],true))throw $e;
                    $prior=null;
                }
            }
            if($old['token']!==''&&!$switch){
                if(!$prior||!Credentials::sameIdentity($prior,$proof))throw Credentials::mismatch($proof);
                if(array_diff($prior['scopes']??[],$proof['scopes']))throw new Fault('credential_scopes_reduced','O token novo perdeu permissões da identidade salva. Gere um token com as permissões atuais. O token salvo continua em uso.');
            }
            if($tokenChanged||$appChanged||$switch)$c['credential_generation']=$old['credential_generation']+1;
            $c['token_identity']=$proof+['validated_generation'=>$c['credential_generation']];
            $c['expires_at']=$proof['remote_expires_at'];$c['page_tokens']=[];
        }elseif($tokenChanged){$c['credential_generation']++;$c['token_identity']=null;$c['page_tokens']=[];}
        elseif(!empty($c['token_identity']['app_verified']))$c['expires_at']=$c['token_identity']['remote_expires_at'];
        $changed=$switch||($tokenChanged&&!$needsProof);
        foreach(['enabled','assets','forms','api_version','users'] as $key)if($old[$key]!==$c[$key])$changed=true;
        if($changed)$c['authorization_revision']=$old['authorization_revision']+1;
        $c['token_configured']=$c['token']!=='';$c['secret_configured']=$c['client_secret']!=='';
        if($tokenChanged||$appChanged||$changed)$c['remote_proof']=null;
        $c['updated_by']=get_current_user_id();$c['updated_at']=time();return $c;
    }
    private static function scheduleRows(string $id): array {
        return array_values(array_filter(Store::list('schedule',0,100),static fn($r)=>($r['value']['query']['connection_id']??null)===$id));
    }
    /** Public only to the in-process Meta validation path; always called with the connection lock held. */
    public static function commit(array $old,array $c,int $expected,array $principal,bool $switch=false,string $operation='save-connection'): array {
        return Store::lock('schedules',static function()use($old,$c,$expected,$principal,$switch,$operation){
            Connections::revalidate($c+['revision'=>$expected]);Access::checkPrincipal($principal);
            $rows=self::scheduleRows($c['id']);$rebase=[];$skipped=[];
            foreach($rows as $r){
                $v=$r['value'];$eligible=$switch||($c['authorization_revision']===$old['authorization_revision']&&
                    (isset($v['authorization_revision'])?$v['authorization_revision']===$old['authorization_revision']:$v['connection_revision']===$expected));
                if(!$eligible){$skipped[]=$r['key'];continue;}
                Access::asset($c,$v['query']['channel'],$v['query']['account_id']);
                $v['connection_revision']=$expected+1;$v['authorization_revision']=$c['authorization_revision'];$v['credential_generation']=$c['credential_generation'];
                if(($v['last_code']??null)==='revision_conflict'||(($v['last_error']['auth_scope']??null)==='connection'&&!CollectionState::current($v['last_error'],$c))){$v['last_code']=null;$v['last_recovered_at']=time();}
                $rebase[]=[$r,$v];
            }
            global $wpdb;
            $status=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name=%s',Store::table()),ARRAY_A);
            if(strcasecmp((string)($status['Engine']??''),'InnoDB')!==0)throw new Fault('storage_unavailable','A gravação conjunta exige armazenamento InnoDB. Nenhuma credencial foi alterada.');
            if($wpdb->query('START TRANSACTION')===false)throw new Fault('storage_unavailable','Não foi possível iniciar a gravação conjunta.');
            try{
                $saved=Store::put('connection',$c['id'],$c,$expected);
                foreach($rebase as [$r,$v])Store::put('schedule',$r['key'],$v,$r['revision'],$r['expires_at']);
                if($c['retention_days']!==$old['retention_days']||$c['retention_mode']!==$old['retention_mode'])History::policyChanged($c);
                Store::put('audit',wp_generate_uuid4(),['operation'=>$operation,'actor'=>['type'=>'user','id'=>get_current_user_id()],'transport'=>'connection_commit','connection_id'=>$c['id'],'code'=>'ok','at'=>time(),'from_revision'=>$expected,'to_revision'=>$saved['revision'],'identity_changed'=>$switch,'schedules_rebased'=>array_map(static fn($x)=>$x[0]['key'],$rebase),'schedules_requiring_review'=>$skipped],0,time()+30*86400);
                if($wpdb->query('COMMIT')===false)throw new Fault('persistence_unconfirmed','Não houve confirmação da gravação conjunta. Releia a conexão antes de repetir.');
            }catch(\Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
            return ['persisted'=>true,'connection'=>Connections::public($c+['revision'=>$saved['revision']]),'schedules_rebased'=>count($rebase),'schedules_requiring_review'=>$skipped];
        });
    }
    public static function switchIdentity(array $i): array {
        Access::admin();Schemas::validate('switch-identity',$i);$id=$i['connection_id'];
        if($i['token']==='')throw new Fault('invalid_token_format','Informe o novo token de acesso.');
        return Store::lock('connection:'.$id,static function()use($i,$id){
            $old=Connections::get($id);$expected=$i['expected_revision'];if($old['revision']!==$expected)throw new Fault('revision_conflict','A conexão mudou. Faça uma nova simulação.');unset($old['revision']);
            $principal=Access::principal();$c=self::prepare($old,$i,$expected,true);
            return Store::lock('schedules',static function()use($i,$old,$c,$expected,$principal){
                $rows=self::scheduleRows($c['id']);$revisions=[];
                foreach($rows as $row){$v=$row['value'];Access::asset($c,$v['query']['channel'],$v['query']['account_id']);$revisions[$row['key']]=$row['revision'];}
                // HMAC avoids exposing a reusable hash of credentials; encrypted confirmation contains no secret value.
                $candidate=hash_hmac('sha256',Util::json([$c['id'],$c['label'],$c['token'],$c['client_id'],$c['client_secret'],$c['token_identity']['subject_id'],$c['token_identity']['scopes'],$c['expires_at']]),wp_salt('auth'));
                $binding=hash('sha256',Util::json([$candidate,$expected,$principal,$revisions]));
                if($i['dry_run'])return ['persisted'=>false,'dry_run'=>true,'identity'=>$c['token_identity'],'connection_label'=>$c['label'],'connection_revision'=>$expected,'schedules'=>array_keys($revisions),'confirmation'=>Util::cursor(['binding'=>$binding,'purpose'=>'switch-identity','expires'=>time()+600]),'confirmation_expires_in'=>600,'message'=>'Confira a identidade e as agendas. Confirme a troca para gravar. Coletas iniciadas com a identidade anterior não serão reautorizadas.'];
                $confirmation=Util::uncursor($i['confirmation']??'');
                if(($confirmation['purpose']??'')!=='switch-identity'||!hash_equals($binding,$confirmation['binding']??''))throw new Fault('confirmation_mismatch','A candidata, a conexão, as agendas ou a autorização mudaram. Faça uma nova simulação.');
                return self::commit($old,$c,$expected,$principal,true,'switch-identity');
            });
        });
    }
}
