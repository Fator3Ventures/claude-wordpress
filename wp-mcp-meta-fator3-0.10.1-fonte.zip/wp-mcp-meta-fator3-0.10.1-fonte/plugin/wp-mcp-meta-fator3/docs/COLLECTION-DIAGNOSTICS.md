# Diagnóstico das coletas — 0.10.1

## Pedido MCP Meta 17

Uma falha de Story ou de métrica não prova que a conexão perdeu autorização. `story_expired` identifica uma recusa do fornecedor para Story cujo timestamp publicado está há pelo menos 24 horas; `story_insights_unavailable` identifica ausência/supressão ou recusa específica sem prova de expiração. Valores ausentes continuam `null`, nunca zero. A API pode retornar métricas para um objeto mais antigo; uma resposta válida não é descartada apenas pela idade. O plugin não promete recuperar insights já indisponíveis.

Esses códigos não geram issue de autorização nem e-mail. Insights indisponíveis por item produzem resultado parcial com a linha/métrica e diagnóstico; os demais itens/páginas continuam. Recusa do inventário de Stories pausa a coleta atual, conserva a agenda ativa e permite a próxima execução. Rede, quota e orçamento mantêm os códigos e a política de retry existentes. Não transformar indisponibilidade temporária de rede em revogação.

Recusas `token_rejected` e `asset_access_denied` são conferidas por um GET fixo `/me?fields=id` com a mesma credencial salva. Somente recusa de autorização também nessa validação torna a coleta `not_authorized` com `auth_scope=connection`. HTTP/códigos da operação original e da validação ficam separados. Uma validação inconclusiva não comprova revogação. `asset_access_denied` isolado em outro relatório permanece falha de recurso, com orientação específica; não reautoriza nem bloqueia automaticamente as outras agendas. Os gates locais de administrador e concessão continuam recusando acesso por `not_authorized`, independentemente da API; essa falha de origem não se propaga a outras concessões.

A falha confirmada da conexão é registrada no bucket cifrado `collection_failure`, vinculada a `authorization_revision` e `credential_generation`. Todas as agendas dessa conexão recebem o diagnóstico, inclusive as pausadas, sem alterar a seleção, seu principal, estado ativo/pausado ou revisão de autorização. A coleta e o worker não trocam credenciais nem concedem acesso. Um job da geração/identidade antiga não pode diagnosticar a credencial substituta.

## Persistência e leitura

`meta/list-schedules` retorna `last_code` para o resultado corrente e `last_error` para o último erro observado, com `code`, `http_status`, `provider_code`, `provider_subcode`, `observed_at` (Unix UTC) e, quando existentes, `provider_is_transient`, `retry_after`, `auth_scope`, `origin_code`, `connection_validation`, `authorization_revision`, `credential_generation`. Campos remotos desconhecidos são `null`, sem inventar status ou subcódigo. O último erro permanece após uma coleta bem-sucedida; `last_code=null`, `last_success_at` ou `last_recovered_at` indicam a recuperação.

`meta/audit` inclui `operation=collection-run` por avanço de coleta e `schedule-dispatch` quando a agenda falha antes de criar o job. Os eventos contêm conexão, agenda, job, ator de origem, `transport=collection_worker`, código, instante e `last_error` sanitizado. Auditoria mantém retenção de 30 dias. O corpo/mensagem bruta da Graph, URLs, headers e tokens não são registrados. Falha de auditoria fica em `audit_health=failed`; não se afirma auditoria persistida quando o banco a recusa.

A cobertura do relatório acrescenta `coverage.last_error`, preservado na continuação; a amostra de `coverage.errors` continua limitada a 50. O último diagnóstico não depende dessa amostra. Consultar health, agenda, auditoria ou documentação não confirma remotamente a conexão e não envia avisos.

## Aviso e recuperação

`meta/health` agrega a revogação confirmada em `connection_authorization_failed`, uma issue por conexão. O e-mail ao `admin_email` informa causa medida, HTTP, código/subcódigo e instante, orientando renovar o token ou restaurar permissões do aplicativo. Não pede regravar cada agenda para um token revogado. Falha local de concessão pede restaurar acesso administrativo ou salvar a agenda pela concessão válida; conflito de revisão e recurso recusado têm ações próprias.

O worker/manutenção observa as issues atuais sob trava e reserva o conjunto antes de `wp_mail`. Faz uma única tentativa por incidente ativo, mesmo após uma hora ou uma falha/incerteza de correio; `accepted` só significa aceito pelo WordPress. Não há promessa de entrega nem reenvio automático incerto. Uma coleta nova bem-sucedida com a mesma geração resolve a falha da conexão; uma credencial/identidade nova aceita torna o diagnóstico antigo obsoleto. O worker registra a recuperação antes de avisar, sem enviar alerta de incidente já resolvido. Não se considera resultado armazenado de um job antigo prova de recuperação.

Nenhuma tabela/coluna nova. Dados e opções são preservados na atualização 0.9.0 → 0.10.0. O aviso usa a option existente `f3_meta_operation_notice` com mapa `active`; o formato anterior é aceito como sem mapa. Voltar arquivos à 0.9.0 perde a classificação e a deduplicação novas, sem desfazer diagnóstico/auditoria já gravados.

Referências oficiais consultadas em 24/10/2026: [Instagram Media Insights](https://developers.facebook.com/documentation/instagram-platform/reference/instagram-media/insights) (disponibilidade de métricas de Stories por 24 horas); [tratamento de erros Graph](https://developers.facebook.com/docs/graph-api/guides/error-handling/) (distinguir token e permissões). Esses contratos não comprovam a causa histórica dos e-mails de produção: aquela hipótese só pode ser confirmada com os códigos medidos.
