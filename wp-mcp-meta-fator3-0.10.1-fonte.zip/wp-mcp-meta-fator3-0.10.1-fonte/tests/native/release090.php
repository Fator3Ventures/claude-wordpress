<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
use Fator3\Meta as M;
wp_set_current_user(1);global $wpdb;$checks=[];$calls=0;$mode='valid';$race=null;$id='qa090';
$tokenA='EAA'.str_repeat('A',110);$tokenB='EAA'.str_repeat('B',110);$tokenC='EAA'.str_repeat('C',110);$app='123456789012345';$secret=str_repeat('a',32);
function qa090_check($name,$ok,$detail=[]){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$ok,'details'=>$detail];echo wp_json_encode(end($checks))."\n";}
function qa090_call($op,$i=[]){M\Http::budget(40,25);return M\Api::dispatch($op,$i);}
function qa090_snap(){global $wpdb;return $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE bucket<>%s ORDER BY bucket,record_key',M\Store::table(),'audit'),ARRAY_A);}
function qa090_save($changes){global $id;$c=M\Connections::get($id);return qa090_call('save-connection',['connection_id'=>$id,'expected_revision'=>$c['revision']]+$changes);}
$http=static function($pre,$args,$url)use(&$calls,&$mode,&$race,$app,$tokenA,$tokenB){
 $calls++;if($race){$fn=$race;$race=null;$fn();}
 $path=basename(parse_url($url,PHP_URL_PATH));parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);
 $current=$q['input_token']??substr($args['headers']['Authorization']??'',7);$subject=$current===$tokenB?'902':'901';
 if($path==='debug_token'){
  if($mode==='190')return ['headers'=>[],'body'=>wp_json_encode(['error'=>['code'=>190,'message'=>'never display '.$current]]),'response'=>['code'=>401],'cookies'=>[]];
  $data=['is_valid'=>$mode!=='invalid','app_id'=>$mode==='app'?'999999999999999':$app,'application'=>'QA Aplicativo','user_id'=>$subject,'expires_at'=>$mode==='expired'?time()-1:($mode==='finite'?time()+3600:0),'scopes'=>M\Credentials::READ_SCOPES];
  if($mode==='invalid')$data['error']=['code'=>190];if($mode==='extra')$data['scopes'][]='ads_management';if($mode==='noexpiry')unset($data['expires_at']);
  if($mode==='quota')return ['headers'=>['retry-after'=>'60'],'body'=>wp_json_encode(['error'=>['code'=>4]]),'response'=>['code'=>429],'cookies'=>[]];
  $body=['data'=>$data];
 }elseif($path==='me')$body=['id'=>$subject,'name'=>$subject==='902'?'QA Sistema Novo':'QA Sistema Original'];
 elseif(in_array($path,['910','920'],true)){
  if($mode==='asset')return ['headers'=>[],'body'=>wp_json_encode(['error'=>['code'=>200]]),'response'=>['code'=>403],'cookies'=>[]];
  $body=['id'=>$path,'name'=>'QA Ativo','username'=>'qa090','access_token'=>'EAA'.str_repeat('P',110)];
 }else return new WP_Error('qa_unexpected_http');
 return ['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>200],'cookies'=>[]];
};add_filter('pre_http_request',$http,1,3);add_filter('pre_wp_mail',static fn()=>true,1);
$input=['connection_id'=>$id,'expected_revision'=>0,'label'=>'QA Sistema Original · QA Aplicativo','client_id'=>$app,'client_secret'=>$secret,'token'=>$tokenA,'expires_at'=>time()+99,'assets'=>['instagram'=>['910'],'facebook'=>['920']]];
try{
 $snapshot=qa090_snap();$r=qa090_call('save-connection',array_replace($input,['token'=>$secret]));
 qa090_check('32 hex rejects before HTTP and any domain write',$r['code']==='invalid_token_format'&&$r['message']==="Isto parece a Chave Secreta do Aplicativo, não um token. Copie o token na janela 'Token criado' do usuário do sistema."&&$calls===0&&qa090_snap()===$snapshot);
 $r=qa090_call('save-connection',$input);qa090_check('New validated connection persists with authoritative non-expiring metadata',$r['success']&&$r['data']['connection']['expires_at']===0&&$r['data']['connection']['token_identity']['subject_name']==='QA Sistema Original',['code'=>$r['code']]);
 if(!$r['success'])throw new RuntimeException('Cannot proceed');
 $c=M\Connections::get($id);$proof=$c['token_identity'];qa090_check('Summary includes independently verified application identity and exact scopes',$proof['application_id']===$app&&$proof['application_name']==='QA Aplicativo'&&$proof['app_verified']&&count($proof['scopes'])===5);
 qa090_check('Public projection contains no credential',!str_contains(wp_json_encode($r),$tokenA)&&!str_contains(wp_json_encode($r),$secret)&&!isset($r['data']['connection']['page_tokens']));
 for($n=0;$n<3;$n++)M\Schedules::save(['schedule_id'=>'qa090-'.$n,'query'=>['connection_id'=>$id,'channel'=>'instagram','account_id'=>'910','report'=>'profile'],'enabled'=>$n!==1,'interval_minutes'=>60,'expected_revision'=>0,'next_at'=>time()+7200+$n]);
 $s=M\Store::get('schedule','qa090-2');$v=$s['value'];$v['principal']=['user_id'=>999999999,'channel'=>null];M\Store::put('schedule','qa090-2',$v,$s['revision']);
 $beforeSchedules=M\Schedules::list();$beforeCalls=$calls;$r=qa090_save(['label'=>'Novo rótulo']);$c=M\Connections::get($id);$afterSchedules=M\Schedules::list();
 qa090_check('Label alone performs no HTTP and rebases every schedule',$r['success']&&$r['data']['schedules_rebased']===3&&$calls===$beforeCalls&&count(array_filter($afterSchedules,static fn($s)=>$s['connection_revision']===$c['revision']))===3);
 qa090_check('Rebase preserves paused state, run dates and originating revoked principal',!$afterSchedules[1]['enabled']&&array_column($beforeSchedules,'next_at')===array_column($afterSchedules,'next_at')&&M\Store::get('schedule','qa090-2')['value']['principal']['user_id']===999999999);
 $principalFault=M\Result::run(static function()use($c){$s=M\Store::get('schedule','qa090-2')['value'];M\Access::worker($s['principal'],$c,'instagram','910');return [];});qa090_check('Rebased revoked origin remains unauthorized',$principalFault['code']==='not_authorized');
 foreach(['190'=>'token_rejected','invalid'=>'token_rejected','app'=>'credential_app_mismatch','asset'=>'asset_access_denied','expired'=>'token_expired','noexpiry'=>'upstream_invalid','quota'=>'rate_limited'] as $scenario=>$code){
  $mode=(string)$scenario;$before=qa090_snap();$r=qa090_save(['token'=>$tokenC]);qa090_check('Refusal '.$scenario.' preserves exact domain snapshot',$r['code']===$code&&qa090_snap()===$before,['code'=>$r['code']]);
  if($scenario==190)qa090_check('190 message Portuguese and no raw provider content',$r['message']==='A Meta recusou este token (código 190). O token salvo continua em uso.'&&!str_contains(wp_json_encode($r),$tokenC));
 }
 $mode='valid';$before=qa090_snap();$r=qa090_save(['token'=>'EAAshort']);qa090_check('Short token preserves snapshot',$r['code']==='invalid_token_format'&&qa090_snap()===$before);
 foreach(['123','123456789012345678','12345678901234x'] as $bad){$r=qa090_save(['client_id'=>$bad]);qa090_check('Invalid App ID '.$bad.' rejected',$r['code']==='invalid_app_id');}
 $r=qa090_save(['client_secret'=>'wrong']);qa090_check('Malformed App Secret rejected',$r['code']==='invalid_app_secret');
 $mode='finite';$r=qa090_save(['token'=>$tokenC,'expires_at'=>1]);$c=M\Connections::get($id);qa090_check('Same identity token rotation uses provider expiry and keeps schedule authorization',$r['success']&&$c['expires_at']>time()+3000&&$r['data']['schedules_rebased']===3);
 $mode='valid';$before=qa090_snap();$r=qa090_save(['token'=>$tokenB]);qa090_check('Different identity requires guided flow and preserves bytes',$r['code']==='credential_identity_mismatch'&&str_contains($r['message'],'QA Sistema Novo')&&str_contains($r['message'],'Trocar identidade e regravar agendas')&&qa090_snap()===$before);
 $c=M\Connections::get($id);$switch=['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$tokenB,'dry_run'=>true];$r=qa090_call('switch-identity',$switch);$confirmation=$r['data']['confirmation']??'';
 qa090_check('Identity simulation validates all assets without domain persistence',$r['success']&&count($r['data']['schedules'])===3&&qa090_snap()===$before&&!$r['data']['persisted']);
 $bad=qa090_call('switch-identity',array_replace($switch,['token'=>$tokenA,'dry_run'=>false,'confirmation'=>$confirmation]));qa090_check('Confirmation cannot authorize another token',$bad['code']==='confirmation_mismatch'&&qa090_snap()===$before);
 $s=M\Store::get('schedule','qa090-1');$v=$s['value'];$v['label']='Concurrent label';M\Store::put('schedule','qa090-1',$v,$s['revision']);$before=qa090_snap();
 $bad=qa090_call('switch-identity',array_replace($switch,['dry_run'=>false,'confirmation'=>$confirmation]));qa090_check('Schedule change invalidates identity confirmation',$bad['code']==='confirmation_mismatch'&&qa090_snap()===$before);
 $r=qa090_call('switch-identity',$switch);$confirmation=$r['data']['confirmation'];
 $job=M\Jobs::create(['query'=>['connection_id'=>$id,'channel'=>'instagram','account_id'=>'910','report'=>'profile'],'idempotency_key'=>'qa090-before-switch']);$oldJob=M\Store::get('job',$job['job_id']);
 $r=qa090_call('switch-identity',array_replace($switch,['dry_run'=>false,'confirmation'=>$confirmation]));$c=M\Connections::get($id);
 qa090_check('Explicit identity switch commits token and all three schedule revisions',$r['success']&&$c['token_identity']['subject_id']==='902'&&$c['token']===$tokenB&&$r['data']['schedules_rebased']===3&&count(array_filter(M\Schedules::list(),static fn($s)=>$s['connection_revision']===$c['revision']&&$s['authorization_revision']===$c['authorization_revision']))===3,['code'=>$r['code']]);
 $test=M\Result::run(static function()use($oldJob,$c){M\Connections::checkPlan($oldJob['value'],$c);return [];});qa090_check('Pre-switch jobs and cursors remain untouched and cannot cross identity',$test['code']==='revision_conflict'&&M\Store::get('job',$job['job_id'])===$oldJob);
 $r=qa090_call('switch-identity',array_replace($switch,['dry_run'=>false,'confirmation'=>$confirmation]));qa090_check('Replaying accepted switch conflicts',$r['code']==='revision_conflict');
 $before=qa090_snap();$filter=static fn($sql)=>str_starts_with($sql,'UPDATE')&&str_contains($sql,"bucket='schedule'")?str_replace(M\Store::table(),M\Store::table().'_missing_qa',$sql):$sql;
 add_filter('query',$filter);$suppress=$wpdb->suppress_errors(true);$r=qa090_save(['label'=>'Must roll back']);$wpdb->suppress_errors($suppress);remove_filter('query',$filter);
 qa090_check('Injected schedule SQL failure rolls back connection and all schedule bytes',$r['code']==='storage_unavailable'&&qa090_snap()===$before,['code'=>$r['code']]);
 $before=qa090_snap();wp_set_current_user(0);$r=qa090_call('save-connection',['connection_id'=>$id,'expected_revision'=>M\Connections::get($id)['revision'],'label'=>'No']);qa090_check('Unauthenticated write denied',$r['code']==='not_authorized'&&qa090_snap()===$before);wp_set_current_user(1);
 $subscriber=wp_create_user('qa090subscriber',wp_generate_password(),'qa090subscriber@example.invalid');$u=new WP_User($subscriber);$u->set_role('subscriber');wp_set_current_user($subscriber);
 foreach(['get-connection','switch-identity','rotate-token','save-connection'] as $op){$i=$op==='switch-identity'?$switch:($op==='get-connection'?['connection_id'=>$id]:['connection_id'=>$id,'expected_revision'=>M\Connections::get($id)['revision'],'token'=>$tokenC]);$r=qa090_call($op,$i);qa090_check('Subscriber denied '.$op,$r['code']==='not_authorized');}wp_set_current_user(1);
 require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($subscriber);
 $mode='extra';$r=qa090_save(['token'=>$tokenA]);qa090_check('Different identity still cannot use normal save with extra scopes',$r['code']==='credential_identity_mismatch');
 $same='EAA'.str_repeat('D',110);$current=M\Connections::get($id);$sw=['connection_id'=>$id,'expected_revision'=>$current['revision'],'token'=>$same,'dry_run'=>true];$r=qa090_call('switch-identity',$sw);$r=qa090_call('switch-identity',array_replace($sw,['dry_run'=>false,'confirmation'=>$r['data']['confirmation']]));qa090_check('Excess permission is projected for visible warning',$r['success']&&$r['data']['connection']['token_identity']['extra_scopes']===['ads_management']);
 $mode='extra';$r=qa090_save(['client_secret'=>str_repeat('b',32)]);qa090_check('App secret change validates and rebases without changing identity',$r['success']&&$r['data']['schedules_rebased']===3);
 $before=qa090_snap();$rev=M\Connections::get($id)['revision'];$r=qa090_call('rotate-token',['connection_id'=>$id,'expected_revision'=>$rev,'token'=>$secret]);qa090_check('Rotation rejects App Secret before writing',$r['code']==='invalid_token_format'&&qa090_snap()===$before);
 $events=M\Audit::list([])['events'];qa090_check('History records rebased agendas and old/new revisions',(bool)array_filter($events,static fn($e)=>($e['transport']??'')==='connection_commit'&&count($e['schedules_rebased']??[])===3&&isset($e['from_revision'],$e['to_revision'])));
 // A separate MySQL session owns the same named lock: no operation may cross it.
 $other=new wpdb(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);$other->suppress_errors(true);
 foreach(['connection:'.$id,'schedules'] as $resource){$lock='f3s:'.substr(hash('sha256',DB_NAME.'|'.M\Store::table().'|'.$resource),0,55);$got=$other->get_var($other->prepare('SELECT GET_LOCK(%s,0)',$lock));$before=qa090_snap();$r=qa090_save(['label'=>'Blocked concurrent edit']);$other->get_var($other->prepare('SELECT RELEASE_LOCK(%s)',$lock));qa090_check('Concurrent session lock '.$resource.' blocks without writes',(string)$got==='1'&&$r['code']==='busy'&&qa090_snap()===$before);}
 $other->close();
 $before=qa090_snap();$filter=static fn($sql)=>str_starts_with($sql,'INSERT')&&str_contains($sql,"'audit'")?str_replace(M\Store::table(),M\Store::table().'_missing_qa',$sql):$sql;
 add_filter('query',$filter);$suppress=$wpdb->suppress_errors(true);$r=qa090_save(['label'=>'Audit failure rollback']);$wpdb->suppress_errors($suppress);remove_filter('query',$filter);
 qa090_check('Audit failure rolls back connection and every rebased schedule',$r['code']==='storage_unavailable'&&qa090_snap()===$before);
 $before=qa090_snap();$mode='valid';$r=qa090_save(['token'=>'EAA'.str_repeat('E',110)]);qa090_check('Same identity cannot silently lose a permission',$r['code']==='credential_scopes_reduced'&&qa090_snap()===$before);$mode='extra';
 $r=qa090_save(['clear_client_secret'=>true]);qa090_check('Explicit removal of App Secret remains possible without dropping token',$r['success']&&M\Connections::get($id)['client_secret']===''&&M\Connections::get($id)['token']!==''&&$r['data']['schedules_rebased']===3);
 $before=qa090_snap();$r=qa090_save(['token'=>'EAA'.str_repeat('F',110)]);qa090_check('Missing app proof gives Portuguese field location and preserves state',$r['code']==='app_proof_required'&&str_contains($r['message'],'Configurações do app → Básico')&&qa090_snap()===$before);
 $r=qa090_save(['client_secret'=>str_repeat('b',32)]);qa090_check('Restoring app pair proves current token and rebinds schedules',$r['success']&&$r['data']['schedules_rebased']===3);
 $before=M\Connections::get($id);$race=static function()use($id){$row=M\Store::get('connection',$id);$v=$row['value'];$v['label']='Concurrent committed value';M\Store::put('connection',$id,$v,$row['revision']);};
 $r=qa090_save(['token'=>'EAA'.str_repeat('G',110)]);$current=M\Connections::get($id);qa090_check('Revision changing during provider check prevents overwrite',$r['code']==='revision_conflict'&&$current['token']===$before['token']&&$current['label']==='Concurrent committed value');
 $_GET['tab']='connections';ob_start();M\Admin::screen();$html=ob_get_clean();$fields=json_decode(file_get_contents(dirname(__DIR__).'/credential-fields090.json'),true);
 foreach($fields as $key=>$f){qa090_check('Exact visible label and help '.$key,str_contains($html,esc_html($f[0]))&&str_contains($html,esc_html($f[1])));}
 qa090_check('UI exposes guided identity switch and package version',str_contains($html,'Trocar identidade e regravar agendas')&&str_contains($html,'Versão '.M\Config::VERSION));
 qa090_check('Schema/catalog contains 35 stable localized operations',count(M\Schemas::all())===35&&array_keys(M\Schemas::all())!==[]&&isset(M\AbilityLabels::all()['switch-identity']));
 $r=qa090_call('selftest');qa090_check('Built-in selftest passes',$r['success']);
}catch(Throwable $e){qa090_check('Suite completes',false,['exception'=>get_class($e),'message'=>$e->getMessage()]);}
finally{
 remove_filter('pre_http_request',$http,1);
 foreach(['job','schedule','connection','quota','page_credential'] as $bucket)foreach(M\Store::list($bucket,0,100) as $row){$v=$row['value'];if($row['key']===$id||str_starts_with($row['key'],'qa090-')||($v['query']['connection_id']??null)===$id)M\Store::remove($bucket,$row['key'],$row['revision']);}
}
$failed=count(array_filter($checks,static fn($r)=>!$r['passed']));$out=['version'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'passed'=>count($checks)-$failed,'failed'=>$failed,'intercepted_http'=>$calls,'provider_homologation'=>false];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/release090.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode(['passed'=>$out['passed'],'failed'=>$failed])."\n";exit($failed?1:0);
