# Fator3 MCP Meta 0.10.1

Entrega dos Pedidos MCP Meta 16 e 17 sobre a base aceita 0.9.0. Prévia junto do formulário de origem, foco acessível e nome vinculado à confirmação/transação. Stories indisponíveis têm códigos próprios; revogação da conexão exige validação independente. Agendas e auditoria preservam o diagnóstico medido e o aviso é limitado a uma tentativa por incidente.

Código canônico: `build/common`, `build/meta`, `build/assets`; documentação instalada em `build/docs/meta`. Runtime `plugin/wp-mcp-meta-fator3` idêntico ao instalador. Evidências finais: `evidence/0.10.1`. A pasta `evidence/0.10.0` registra a etapa anterior; não equivale a execução do patch. Entradas em `inputs/0.10.0`; planos em `planning/RELEASE-0100.md` e `planning/PATCH-0101.md`.

A 0.10.1 corrige documentação contraditória encontrada após instalar a 0.10.0 no Site-Teste. Código funcional, JavaScript e schemas são idênticos à 0.10.0; bootstrap/Config mudam somente a versão. Prova: `evidence/0.10.1/patch-diff.json`. A versão corrente é 0.10.1; a 0.10.0 não é pré-requisito para instalar.

Convivência: Core 1.51.0, MCP 0.30.1, Google 0.19.0, LinkedIn 0.10.1 e Pipedrive 0.1.0. Hashes em `tests/companion-hashes0100.json` e `inputs/0.10.0/packages.json`. Nenhum acompanhante alterado. Testes: `release0100.php` (41), `integration0100.php` (23), `release090-metadata.php` (104), `release090.php` (55), `isolated0100-smoke.php` (25), `isolated0100-upgrade.php` (5). Nomes preservam o histórico do harness; expectativas aplicáveis usam 0.10.1.

Build: `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. Empacotamento: `python3 tools/package-source.py --output-dir /diretorio/externo`. O fonte não é instalável e não contém ZIP aninhado; somente o instalador entra no WordPress.

Reprodução nativa: `python3 tools/build-isolated0100-probe.py --baseline <runtime-090> --candidate <runtime-0101> --output <fora-do-fonte>`. O controlador em `tests/site` opera somente no Site-Teste, cria prefixo/tabelas e diretório próprios, bloqueia HTTP/e-mail externos e permite suítes fixas, mínimo, atualização e limpeza. Nunca instalar auxiliares em produção. Etapas `php812` e `reinstall812` conferem os hashes de `tools/php81-lock.json` para instalação limpa no mínimo exato; PHP 8.1.34 é somente preparação. Credenciais e respostas HTTP são sintéticas; provas com fornecedor real ficam com o operador.

DOM: jsdom 27.4.0, `node tests/dom/credential0100.cjs <fixture-ui090.json> build/assets/admin.js tests/credential-fields090.json <evidence.json>`. Fixture renderizada por `tests/native/ui090.php` em WordPress isolado na 0.10.0; Admin e JavaScript são byte a byte iguais no patch. Não equivale a inspeção visual em navegador. O relatório principal traz versões, resultados efetivos, limites, bytes/hashes e estado final do Site-Teste. Respostas e encerramentos de impactos pertencem a esse relatório, conforme revisão 5 das instruções. Nenhum novo impacto foi identificado para outro mantenedor.
