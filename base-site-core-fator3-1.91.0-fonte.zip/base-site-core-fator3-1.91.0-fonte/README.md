# Fonte do Fator3 Site Core 1.91.0

Runtime em work/plugin/base-site-core-fator3. Instalador para instalação nova ou troca direta da 1.90.0. Pesquisa LG e CSV final em reference/419. A base congelada do Google Play, UTF-16 de quatro colunas, está em reference/417/supported_devices.csv. O arquivo integral fica no fonte. O instalador contém o índice comprimido e o catálogo curado.

## Reprodução local

Execute na raiz deste fonte. Para trocar a base, substitua a referência congelada, informe sua data de publicação e reveja as fichas e as ambiguidades antes de fechar nova versão. O resultado de QA desta versão está em evidence/1910. Os manifestos descrevem exatamente os arquivos publicados.

```sh
python3 build/gerar-catalogo-aparelhos.py
python3 build/gerar-google-play.py --google-play reference/417/supported_devices.csv --data 2026-11-15
python3 tests/google-play-integridade.py
python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.91.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.91.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.91.0-fonte.zip
```

Use F3BASE_PHP para selecionar PHP 8.3+. O ensaio de filas está em tests/420. Os testes de catálogo incluem catalogo-google-419.php, projecao-google-419.php e catalogo-precos-413.php. O limite do fonte é 100.000.000 bytes.

Pedidos 421 a 425 em reference/422 e tests/191. Para reproduzir os JS, use Terser 5.44.1 do package-lock em build/node e execute python3 build/assets-1910.py. Para o comparativo em navegador com CPU 4×, use tests/191/medir-interacao.py com os dois diretórios de runtime e um JSON de saída.

## Provas desta rodada

O comparativo de 30 fichas usa `python3 tests/191/catalogo-frota.py /caminho/do/fonte-1.90.0`. O CSV de pesquisa de exceções é reproduzido com `python3 tests/191/catalogo.py`. Para as provas em WordPress veja `tests/191/qa-wordpress.php`, os resultados em `evidence/1910/wordpress.json` e os limites em `RELATORIO-PRE-FECHAMENTO.md`. As páginas `tests/191/versionada.html` e `tests/191/real.html` documentam, respectivamente, o ensaio do navegador com confirmação local e o ensaio com o coletor real. Para repetir a segunda em outra instalação, informe a revisão do formulário registrado naquele site. Os ensaios não integram o instalador.

O simulador do 420 também aceita `--visitas-publicas` para o pedido 423. Use três bancos locais descartáveis de acordo com tests/420/README.md, agora com o Core 1.91.0, o WP Activity Log ativo e o observador adicional tests/191/observador-visitas.php instalado em mu-plugins. O observador permite a chamada de cron disparada pela visita somente para o próprio loopback. Em cada intervalo são três visitas à home e três chamadas HTTP diretas de cron, com WP-CLI a cada três intervalos. As contagens 24 h de evidence/1900 pertencem exclusivamente à 1.90.0. Esta extensão foi conferida sintaticamente, sem a matriz B/C/E executada nesta rodada.
