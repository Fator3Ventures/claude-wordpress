"""Verifica cada Model do CSV congelado e as relações de codinome em todos os fragmentos."""
from collections import defaultdict,Counter
from pathlib import Path
import csv,hashlib,gzip,json
root=Path(__file__).resolve().parents[1]
ref=root/'reference/417/supported_devices.csv'
d=root/'work/plugin/base-site-core-fator3/dados/google-play'
meta=json.loads((d/'base.json').read_text())
assert meta['sha256_fonte']==hashlib.sha256(ref.read_bytes()).hexdigest()
records=defaultdict(list)
norm=lambda x:' '.join(x.lower().split())
with ref.open(encoding='utf-16',newline='') as fp:
    for brand,name,device,model in list(csv.reader(fp))[1:]:
        if model.strip(): records[norm(model)].append((norm(brand),norm(name),norm(device)))
seen=set();reasons=Counter()
for p in d.glob('*.gz'):
    for k,(brand,name,dev,reason) in json.loads(gzip.decompress(p.read_bytes())).items():
        assert k not in seen and hashlib.sha256(k.encode()).hexdigest().startswith(p.name[:2]),k
        seen.add(k);reasons[reason]+=1
        candidates=records[k]
        own={(b,d) for b,n,d in candidates if n==k}
        possible={(b,d) for b,n,d in candidates if n==norm(name)}
        if reason=='nome_google':
            assert possible and (not own or own & possible),k
            if dev: assert (norm(brand),norm(dev)) in possible,k
        else:
            assert norm(name)==k and (not own or reason=="modelo_ambiguo"),k
assert seen==records.keys() and len(seen)==meta['modelos']
print(json.dumps({'codigos':len(seen),'motivos':reasons,'blocos':len(list(d.glob('*.gz')))},ensure_ascii=False))
