# Documentação do pacote

Índice vigente: DOCUMENTACAO.md. Leia RELEASE-1.36.0.md e AGENTES-1.36.0.md.
