# Instruções do plugin

Leia DOCUMENTACAO.md, AGENTES-1.36.0.md e CONVERSOES-SDK-1.36.md. Documentos anteriores são históricos quando houver divergência. Normas comuns revisão 4.
