# Impacto Core 1.49.1 → implantador-base

Revisão 2 · 23/10/2026 · entrega · validacao-coordenada.
Emissor: base-site-core-fator3, base 1.49.0, alvo entregue 1.49.1. Destinatário: implantador-base 2.11.0; responde ao impacto recebido revisão 4.
Situação: correção e provas do Core concluídas; repetição do aceite do Implantador fica com seu responsável. Não declara concluído trabalho alheio.

## Contrato e consequência

Contrato administrativo 8.14.1. Os schemas de `f3base_contato` e `f3base_consentimento` agora são construídos integralmente antes de acrescentar as propriedades de texto. A raiz tem `type=object`; entradas parciais preservam campos e tipos incorretos são recusados. O defeito existia na base recebida e foi reproduzido com o validador nativo; não se suprimiu aviso nem se relaxou a validação.

Nenhuma mudança de código do Implantador foi identificada como necessária. Ação: repetir o aceite de configuração/perfil contra o Core corrigido. Critério: validação dos dois grupos sem `_doing_it_wrong`, gravação parcial válida e recusa de tipo inválido; perfil piso-padrao-3.6 com 92 condições. Preservar a capacidade de diagnosticar divergências reais.

## Evidência e entrega

Provas em WordPress 7.1.3 e 7.1.2/PHP 8.3.6: schemas válidos/inválidos e parciais, zero avisos de schema; perfil de 92 condições. Site-Teste: 42 verificações sintéticas, incluindo os dois schemas, passaram. Ciclo 1.48.0→1.49.1 concluído sem falhas. As seis cópias partilhadas permaneceram inalteradas; nenhum contrato SDK, dependência global, tabela ou opção nova.

Instalador `base-site-core-fator3-1.49.1-instalador.zip` — 2230721 bytes; SHA-256 `4ad3be4159310578a2db47cf179d02fa061fb98021e2f66ca933b59e7db4fb40`. Evidências no fonte: `evidence/1491/review-1491.json`, `review-1491-extra.json`, `wp712/` e `site-teste.json`. Não instalar o Implantador no Site-Teste em operação para esta repetição; usar seu ambiente de implantação descartável.

## Histórico preservado — revisão 1, planejamento

# Impacto Core 1.49.1 → implantador-base

Revisão 1 · 23/10/2026 · planejamento · validacao-coordenada · aberto.
Emissor: base-site-core-fator3, base 1.49.0, alvo previsto 1.49.1, instalador ainda não gerado. Destinatário: implantador-base 2.11.0, impacto recebido revisão 4.

O aviso foi reproduzido em WordPress 7.1.3: as ampliações de texto de f3base_contato e f3base_consentimento constroem schema_entrada com properties e sem type. A consulta de herança chama o validador nativo com esse schema incompleto. Correção proposta no Core: construir o schema-base antes de acrescentar as propriedades, conservando a validação dos demais campos e a escrita parcial. Não suprimir avisos nem alterar o validador WordPress.

Ação do Core: corrigir e provar os dois grupos, valores válidos/inválidos, escrita parcial e perfil de 92 condições. Ação do Implantador: nenhuma mudança de código prevista; repetir seu aceite de implantação com o Core corrigido. Não instalar o Implantador no Site-Teste em operação. As seis cópias partilhadas não são alteradas por esta correção. Sem nova dependência global. Este documento responde ao alerta recebido, sem editar o documento do emissor.
