> Encerramento 23/10/2026: implementado na 1.49.1; testes e identidades no relatório da entrega. A revisão 2 do impacto registra as provas e a validação restante do Implantador.

# Revisão e correção — Core 1.49.1

23/10/2026. Base recebida 1.49.0, SHA-256 64a80ede90d8cc4a555ba39a016eae217898191a6275cb9cdaaed71388af8657. Comparação com 1.48.0 concluída; 63 verificações originais reproduzidas. Patch autorizado pelo dono, incluindo o pedido adicional 291.

Escopo: (291) separar nome e procedência da campanha, anúncio e conta; corrigir campo Campanha do Pipedrive e projeções legadas, sem migração destrutiva. (R1) corrigir schemas incompletos de contato/consentimento, reproduzidos via Config_Mescla. (R2) impedir que falhas SQL nas novas leituras/reavaliações de fila sejam sucesso vazio; verificar agenda antes de afirmar reagendamento.

Compatibilidade: MCP 0.29.1, Google 0.18.1, LinkedIn 0.8.1, Meta 0.7.1. Provar regressões, ausência de chamadas de fornecedores em leitura, negações de autorização, preservação de registros e instalação limpa/upgrade direto. Homologação no Site-Teste; Pipedrive externo não é testado nesse site. Não editar documentos de pedidos, normas nem pacotes dos demais mantenedores.

Impacto pertinente antes da implementação: base-site-core-fator3-1.49.1-impacto-implantador-base.md. Os impactos antigos Meta/LinkedIn→MCP serão confrontados com o contrato atual; nenhuma alteração desses documentos é prevista.
