<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Searchable technical projection only; payload and authority remain encrypted. */
final class Queue {
    /** Projection state for a legacy job whose ciphertext cannot be opened with the current site key. */
    public const UNREADABLE='unreadable';
    /** Caller holds job:<id> and has just failed to decrypt that job. Preserve its encrypted receipt. */
    public static function isolateUnreadable(string $id): void {
        global $wpdb;
        $n=$wpdb->query($wpdb->prepare("UPDATE %i SET queue_state=%s,queue_next=0 WHERE bucket='job' AND record_key=%s AND queue_state IN ('queued','retry')",Store::table(),self::UNREADABLE,$id));
        if($n===false)throw new Fault('storage_unavailable','Falha ao isolar coleta ilegível.');
    }
    public static function pending(): bool {
        global $wpdb;$v=$wpdb->get_var($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state='' LIMIT 1",Store::table()));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Índice da fila indisponível.');return $v!==null;
    }
    /** Per-request gate with no SQL: schema marker and the small autoloaded `_queue_settled` marker. */
    public static function settled(): bool {
        return (int)Util::boot(Config::KEY.'_schema',0)===2&&Util::boot(Config::KEY.'_queue_settled','')==='2';
    }
    /** Records that nothing is pending under schema 2, so later requests skip the probe. */
    public static function markSettled(): void {
        if((int)get_option(Config::KEY.'_schema',0)!==2)return;$old=get_option(Config::KEY.'_queue_migration',[]);
        update_option(Config::KEY.'_queue_migration',['processed'=>0,'unreadable'=>0,'unreadable_total'=>(int)(is_array($old)?($old['unreadable_total']??0):0),'complete'=>true,'at'=>time()],false);
        update_option(Config::KEY.'_queue_settled','2',true);
    }
    /**
     * Bounded batch of 100. An unreadable legacy record is projected as `unreadable` (never runnable) and counted,
     * so it no longer blocks the remaining records; ciphertext, revision and retention are never rewritten.
     */
    public static function migrate(): array {
        return Store::lock('queue-migration',static function(){
            global $wpdb;$keys=$wpdb->get_col($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state='' ORDER BY queue_next,record_key LIMIT 100",Store::table()));
            if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao migrar índice da fila.');$count=0;$unreadable=0;
            foreach($keys as $key){
                try{$r=Store::get('job',$key);}catch(Fault $e){
                    if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;
                    $n=$wpdb->query($wpdb->prepare("UPDATE %i SET queue_state=%s,queue_next=0 WHERE bucket='job' AND record_key=%s AND queue_state=''",Store::table(),self::UNREADABLE,$key));
                    if($n===false)throw new Fault('storage_unavailable','Falha ao projetar coleta ilegível.');$unreadable+=$n;continue;
                }
                if(!$r)continue;$v=$r['value'];
                $n=$wpdb->query($wpdb->prepare("UPDATE %i SET queue_state=%s,queue_next=%d WHERE bucket='job' AND record_key=%s AND revision=%d AND queue_state=''",Store::table(),$v['status']??'invalid',max(0,(int)($v['next_at']??0)),$key,$r['revision']));
                if($n===false)throw new Fault('storage_unavailable','Falha ao projetar coleta.');$count+=$n;
            }
            $old=get_option(Config::KEY.'_queue_migration',[]);$total=(int)(is_array($old)?($old['unreadable_total']??0):0)+$unreadable;
            $result=['processed'=>$count,'unreadable'=>$unreadable,'unreadable_total'=>$total,'complete'=>!self::pending(),'at'=>time()];update_option(Config::KEY.'_queue_migration',$result,false);if($result['complete']&&(int)get_option(Config::KEY.'_schema',0)===2)update_option(Config::KEY.'_queue_settled','2',true);return $result;
        });
    }
    /** Two bounded range scans, then merge, avoiding a filesort over terminal jobs. */
    public static function due(int $limit=20): array {
        global $wpdb;$rows=[];$limit=max(1,min(20,$limit));
        foreach(['queued','retry'] as $state){$batch=$wpdb->get_results($wpdb->prepare("SELECT record_key,queue_next FROM %i WHERE bucket='job' AND queue_state=%s AND queue_next<=%d ORDER BY queue_next,record_key LIMIT %d",Store::table(),$state,time(),$limit),ARRAY_A);
            if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao selecionar fila executável.');$rows=array_merge($rows,$batch);}
        usort($rows,static fn($a,$b)=>((int)$a['queue_next']<=>(int)$b['queue_next'])?:strcmp($a['record_key'],$b['record_key']));return array_slice($rows,0,$limit);
    }
    public static function waiting(): bool {
        global $wpdb;$v=$wpdb->get_var($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state IN ('queued','retry','') LIMIT 1",Store::table()));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao conferir fila.');return $v!==null;
    }
    public static function unreadable(): int {
        global $wpdb;$n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND queue_state=%s",Store::table(),self::UNREADABLE));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao conferir fila.');return (int)$n;
    }
    public static function health(): array {
        $first=self::due(1);$next=$first?(int)$first[0]['queue_next']:null;
        return ['oldest_due_at'=>$next,'oldest_due_lag_seconds'=>$next===null?0:max(0,time()-$next),'migration_pending'=>self::pending(),'unreadable_jobs'=>self::unreadable(),'migration'=>get_option(Config::KEY.'_queue_migration',null)];
    }
}
