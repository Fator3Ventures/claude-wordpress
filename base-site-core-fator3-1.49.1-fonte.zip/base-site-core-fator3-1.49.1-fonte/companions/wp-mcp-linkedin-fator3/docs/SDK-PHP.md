# SDK local Lead Sync — 0.8.1

Entrypoint `Fator3\LinkedIn\PublicApi`; hook de registro `f3_linkedin_register_consumers`, disparado em `init` com prioridade 1 desde a 0.8.0 (antes: `plugins_loaded` 20). Continua antes do WP-Cron (`init` 10), da REST e do painel; registre o consumidor nesse hook e não dependa do registro durante `plugins_loaded`. Contratos negociados linkedin-lead-reader/1.0.0 e linkedin-lead-reader/1.1.0. O consumidor declara um dos contratos no registro; descriptor e capabilities informam recursos. 1.0 permanece disponível; extensão 1.1 acrescenta diário público, efeito remoto, revisão da operação e reconciliação explícita.

```php
add_action('f3_linkedin_register_consumers', static function ($api) {
    $api::register_consumer([
        'id' => 'meu-consumidor',
        'label' => 'Meu consumidor',
        'contract' => 'linkedin-lead-reader/1.1.0',
    ]);
});
$reader = \Fator3\LinkedIn\PublicApi::lead_reader('meu-consumidor');
$result = $reader->effective_status([
    'connection_id' => 'minha-conexao',
    'account_id' => '123',
]);
```

Registro é local e não concede autorização. Um administrador precisa salvar grant ativo de formulários/permissões para esse consumidor. Não use consumer vazio em workers: vazio é entrada administrativa humana. Métodos: descriptor, effective_status, check_access, list_forms, get_form, read_responses, get_response, verify_challenge, verify_notification, list_subscriptions, create_subscription, delete_subscription, get_subscription_operation, reconcile_subscription.

Schemas de método correspondem a operações lead-* em input-schemas.json. Exemplos adicionais:

```php
$state = $reader->get_subscription_operation($context + [
    'ownership_key' => $ownershipKey,
]);
$result = $reader->reconcile_subscription($context + [
    'ownership_key' => $ownershipKey,
    'expected_operation_revision' => $state['data']['operation_revision'],
    'authorize_current_context' => true,
]);
```

Verifique success e state; uma leitura bem-sucedida do diário com state=uncertain não é confirmação de criação. Nunca converta operation_uncertain em nova chave de POST. Guarde ownership_key e revisões do recibo. O consumidor não deve ler Store, opções internas nem tokens. Repetir o contrato 1.0 preserva a recusa de criação incerta; 1.1 permite recibo estruturado de replay do diário.

## Protocolo com Core

1. Registrar 1.1 e descobrir capabilities; manter cliente antigo como opção até decisão explícita.
2. Conceder conta/formulário/permissões e testar check_access sem ingestão comercial.
3. Persistir eventos antes de ACK; deduplicar identidade + occurredAt/ação conforme a origem.
4. Consultar e drenar operações antigas pela API pública antes de trocar contexto.
5. Com ID conhecido, reconciliar; sem ID, manter bloqueio e resolver com evidência do fornecedor.
6. Ativar seleção do novo provedor somente após homologar callback, challenge, notificação e reconciliação.

O seletor e a ingestão são do Core. Consulte a entrega Core vigente; pendências históricas I02/I03 não são reabertas ou declaradas resolvidas por este pacote. Não há criação real automática de assinatura durante instalação, migração ou autoteste.

## Auditoria do adaptador CAPI
ConversionDelivery::sendBound conserva sua assinatura e origem de serviço, independentemente do usuário corrente. A 0.7.0 emite um evento técnico local e fornece funções públicas de descritor/introspecção sem alterar a fila Core. A nova integração central depende do consumidor do MCP. Leia SERVICE-AUDIT.md; não atribua seus hooks ao contrato humano.
