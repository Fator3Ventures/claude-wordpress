# Diagnóstico — 0.7.1

`status` informa versão, banco, criptografia e execução do cron. `selftest` realiza verificações locais; não valida credenciais externas. `validate-connection` lê identidade do ativo, sem prometer todas as métricas. Consulte auditoria paginada para códigos sanitizados.

- not_authorized: confirme manage_options ou a concessão vigente do consumidor SDK.
- revision_conflict: releia a configuração; uma revisão não é intercambiável com outra.
- token_expired/token_rejected: renove e valide a credencial; resultados históricos locais não dependem de token válido.
- rate_limited: aguarde retry_after; o agendador aplica adiamento.
- upstream_validation: confirme versão, campo, produto e aprovação do aplicativo.
- operation_uncertain: consulte e reconcilie o diário; não gere outra chave para contornar o bloqueio.
- history_changed: a visão paginada mudou; reinicie consulta/exportação com nova chave.
- response_limit: reduza campos ou limit. Não considere uma resposta truncada completa.
- cipher_unreadable: confira salts e restauração; não tente regravar sobre dado ilegível.
- storage_unavailable/persistence_unconfirmed: verifique banco, espaço e bloqueios; preserve o backup.

Cron depende de visitas se não houver agendador do servidor. Execução alternativa: `wp f3-meta run` / `wp f3-linkedin run`. Cada passo tem orçamento; grandes coletas exigem múltiplas execuções. O usuário que criou uma agenda precisa continuar autorizado.

Para Page Insights, consulte PAGE-DIAGNOSTICS.md. O número de seguidores e a leitura de page_profile não comprovam permissão read_insights nem disponibilidade histórica. `empty_or_suppressed` sem erro Graph não autoriza afirmar falta de permissão. Consulte provider_code/provider_subcode em errors ou last_error para recusas documentadas.

## Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.

## Códigos novos da 0.7.0

- `maintenance_missing`: a manutenção horária sumiu do cron. É recriada na próxima requisição do site; se persistir, confira o cron do servidor e travas do banco.
- `queue_record_unreadable` (com `count`): há coletas cifradas que a chave atual do site não abre. Não são executadas nem apagadas; confira AUTH_KEY/AUTH_SALT do wp-config contra o backup. Os demais registros seguem normalmente.


## Correção 0.7.1 — registros ilegíveis

Jobs cujo ciphertext ou JSON interno não pode ser lido são isolados com `queue_state=unreadable`, sem reescrever payload, revisão, timestamps ou retenção. O worker trata também jobs já indexados; eles deixam de ocupar repetidamente as 20 posições executáveis. Migração e retenção usam a mesma trava e conferência de revisão/payload; registros legíveis, alterados concorrentemente ou com falha transitória de banco não recebem essa marca.

Se a agenda aponta para um job ilegível, `meta/health` e `meta/status` retornam diagnóstico degradado com `schedule_job_unreadable` e nome da agenda. Health continua sem reparo operacional e status mantém a recuperação explícita do evento. O aviso de ilegibilidade permanece no diagnóstico, fora do e-mail horário. `queue_record_unreadable` informa a contagem já isolada.

A restauração dos salts ou a reparação de dados exige avaliação do administrador. Registros isolados não voltam automaticamente à fila e não são apagados pela retenção; não há reautorização ou exportação automática de conteúdo ilegível.
