# Administração por assunto — 0.7.1

Abra Ferramentas > Fator3 MCP Meta. Cada aba tem endereço próprio com `tab`, pode ser recarregada e respeita Voltar/Avançar do navegador. Os controles comuns usam a mesma seleção em Relatórios, Coletas, Histórico (Meta) e Diagnóstico.

1. Conexão: nome, credenciais, validade UTC, retenção e usuários pelo nome. Abertura lê conexões locais; os nomes de usuários têm estado próprio de carregamento. Identificador interno é automático.
2. Ativos: escolha uma conexão. Carregue nomes selecionados e/ou ativos disponíveis por canal; use carregar mais quando indicado. Novos resultados não são marcados automaticamente. Marque e salve. LinkedIn: salve contas de formulários antes de descobrir os respectivos formulários; depois marque-os e salve novamente.
3. Relatórios: conexão, canal e conta pelo nome; relatório e campos em português; mídias/publicações/vídeos por seletor, campanhas por caixas. Defina datas quando exigidas. Consultar página não cria coleta. Próxima página preserva a seleção original. Stories são capturados em conjunto conforme o relatório existente. Zero é valor; ausência, recusa e múltiplos buckets continuam distintos.
4. Coletas: criar, avançar, pausar, retomar, cancelar e baixar CSV/JSON. Use nomes nas agendas e horário UTC. O cron decide a execução efetiva. Editar nome/intervalo não altera a consulta armazenada; Nova agenda usa a seleção atual.
5. Histórico: consultar valores locais e exportar; manutenção de registros legados fica em detalhes.
6. Diagnóstico: autoteste local, estado, validação do ativo e versão avançada da API por conexão.
7. Ajuda: índice e leitura completa da documentação instalada, sem depender do transporte MCP.

Credenciais existentes não são preenchidas no navegador. Erros não apagam seleções. Quando a origem não informa um nome, a identificação fica visível apenas como referência de um item já selecionado; não é preciso digitá-la. Nomes podem repetir e não substituem as identidades internas. As áreas técnicas de diagnóstico preservam códigos do fornecedor para investigação.
