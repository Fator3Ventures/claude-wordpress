# Fator3 Site Core 1.49.1 — fonte

Base direta 1.49.0; revisão do código e pedido 291. Contrato administrativo 8.14.1. Runtime em `work/plugin/base-site-core-fator3`, igual byte a byte ao instalador desta versão. Este ZIP não é instalável.

`build/README.md` explica a reprodução. `tests/review-1491.php` cobre nomes/fontes, Pipedrive, Slack, legado e falhas SQL. `review-1491-extra.php` cobre perfil e confirmação da agenda. `tests/site-qa-1491.php` é uma ferramenta temporária, restrita ao Site-Teste, com opções somente na requisição e sem fornecedores; foi removida do site após os testes. Nenhuma ferramenta QA entra no instalador.

`evidence/1491/` contém as provas desta rodada; `baseline1490/` reproduz a versão recebida antes das correções, e `from148/` prova o salto adicional. `evidence/1490/`, demais pastas anteriores e `history/` são evidências históricas, não reexecuções desta rodada.

`companions/` contém cópias intactas dos instaladores MCP 0.29.1, Google 0.18.1, LinkedIn 0.8.1 e Meta 0.7.1 usados localmente. Não são alterações nem entregas desses pacotes e não entram no instalador. Identidades em `evidence/1491/companions.json`.

Sem banco, credenciais reais, cookies, runtime baixado ou ZIP aninhado. O relatório na raiz é a cópia anterior ao fechamento do fonte; o relatório externo tem sua identidade final.
