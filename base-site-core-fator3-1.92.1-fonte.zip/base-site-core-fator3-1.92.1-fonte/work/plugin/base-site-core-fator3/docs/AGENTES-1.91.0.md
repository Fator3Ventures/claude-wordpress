# Operação do Site Core 1.91.0

1. Consulte f3base/como-usar com compacto=true para ver continuacao_ga4 e agenda_das_filas. Verifique o instante e o perfil que produziram a observação.
2. Acompanhe os seis ganchos em cron/list e os recibos em f3base/execucoes-ler. Para avulsas, compare também os argumentos.
3. Leia todas as páginas de f3base/aparelhos-sem-nome-ler. Confira separadamente nomes comerciais e fichas de preço.
4. Em f3base/eventos-ler, filtre a classe teste e a navegação da prova. Compare o clique com abertura, início e aceite.
5. Leia as páginas de f3base/email-wordpress-fila-ler com manage_options. Separe os campos fase e codigo dos marcadores de origem legada. A documentação instalada RELEASE-1.91.0.md define os códigos e os limites.
