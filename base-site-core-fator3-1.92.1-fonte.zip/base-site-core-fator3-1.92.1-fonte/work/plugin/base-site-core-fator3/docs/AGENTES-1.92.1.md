# Operação do Site Core 1.92.1

Leia DOCUMENTACAO.md e RELEASE-1.92.1.md por f3base/documentacao-ler, seguindo proxima_linha até o final. Em f3base/como-usar confira versao 1.92.1, contrato 8.44.0 e catalogo_aparelhos.revisao 2026-11-17.3.

Para o pedido 428 use f3base/aparelhos-sem-nome-ler com manage_options. O filtro apos é exclusivo. Confira o par codigo/nome_comercial no resultado. Device sozinho descreve uma plataforma compartilhada. A ausência de um código na página exige conferir paginação, retenção e existência de ficha comercial completa.

No catálogo local, simule a correção antes de gravar. As leituras do catálogo e da documentação dispensam credenciais externas.
