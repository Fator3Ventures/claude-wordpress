# Fator3 Site Core 1.89.1 — guia para agentes

1. Leia `f3base/como-usar` e confirme a versão do plugin e `catalogo_aparelhos.revisao=2026-11-15.3`.
2. Com `manage_options`, consulte `f3base/aparelhos-sem-nome-ler` com `{"limite":200}`. Siga o cursor até `proximo_apos=null`. A resposta contém códigos e contagens.
3. Para uma sessão autorizada, consulte `f3base/sessao-detalhar` com o identificador em `sessao` e o segmento correspondente. Verifique os campos comerciais de `sessoes[]`. A lista `linhas[]` continua representando a cronologia.
4. Para ajustes locais, use o campo Catálogo local de aparelhos em Conteúdo, audiência e IA, ou simule a atualização de `f3base_medicao_editorial` antes de confirmar a revisão. As fichas completas por código e as linhas nome=faixa têm prioridade sobre os padrões pertinentes.
5. O Implantador 2.23.0 consome o contrato do Core. Os dados de aparelhos pertencem ao Core. Consulte RELEASE-1.89.1.md para cobertura, critérios e limites.
