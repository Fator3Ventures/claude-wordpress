# Operar o Fator3 Site Core 1.87.1

Leia docs/RELEASE-1.87.1.md pelo índice de f3base/documentacao-ler. Para percorrer um arquivo, envie arquivo, linha e limite e siga proxima_linha até o final. A capacidade exigida é manage_options.

1. Leia f3base/saude-ler com compacto verdadeiro e registre versão, contrato, atualização e esperas.
2. Consulte f3base/aplicabilidade-ler com modulo igual a email_historico. Compare resultado, revisao, proximos e esperas_observadas antes e depois da distribuição. Compare também cada revisão de agenda dos seis trabalhadores.
3. Para aprofundar uma contagem, consulte a rota retornada em detalhe. O resumo não reproduz séries nem dados de contatos.
4. Nos relatórios integrados, informe visao, de e ate. Reduza o intervalo após limite_memoria ou reduza_periodo. Guarde o diagnóstico. Um erro na fonte precisa ser distinguido de uma métrica zero.
5. No painel, use as telas de Contatos e Medição para conferir histórico e relatórios. Compare o próximo envio natural do CTO Office com a confirmação no CRM. Em Site-Teste, use dados sintéticos e mantenha a configuração comercial vigente.

## Padrão de entrega e operação

O selo identifica a versão em todas as telas do Core. Nos menus Site Core e Medição, os grupos organizam as abas por função. Os endereços anteriores continuam válidos. As listas com resultados paginados exibem a faixa visível. O modo compacto de saúde e de como-usar também mostra versao_alvo, estado, falhas e confirmada_no_executor_em.

A instalação conclui as etapas e o executor confirma o ciclo. Confira a versão 1.87.1, o estado concluida, zero falhas e o horário de confirmação. Uma passagem adiada depende da próxima execução agendada. O perfil canônico é piso-padrao-3.6. O contrato de configuração é 8.41.0. A frota publica os três arquivos no main depois de verificar os dois ZIPs.
