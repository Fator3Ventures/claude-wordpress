# Operar o Fator3 Site Core 1.88.0

Confira o recibo de atualização em f3base/como-usar e o registro em f3base/documentacao-ler. Use a capacidade manage_options. Os detalhes de recuperação e agendamento continuam em OPERACAO-E-RECUPERACAO.md.

A base de 15/11/2026 cobre 1.156 códigos. Os preços são referências em reais para a data da pesquisa. A faixa representa a posição do produto na linha do fabricante. O indicador de linha premium segue a família comercial.

Em Site Core, abra a configuração de Conteúdo, audiência e IA e procure **Catálogo local de aparelhos**. Para ajustar a faixa, use uma linha como `Galaxy A07 4G=entrada`. Para acrescentar ou corrigir um aparelho, use `CODIGO-EXEMPLO=Marca|Modelo exemplo|2025|1199.90|intermediário|não`. Cada chave aparece uma vez. A correção por código tem prioridade. Quando a faixa vem de um nome local, ela prevalece sobre o padrão embarcado. Simule a alteração e confira a revisão antes de confirmar.

Em `f3base/como-usar`, confira `catalogo_aparelhos.data`. Com `manage_options`, use `f3base/aparelhos-sem-nome-ler` com limite 1 a 200. Passe `proximo_apos` como `apos` na próxima leitura até ele ser nulo, inclusive se a página não trouxer itens. A leitura agrega os perfis retidos por código. As observações novas guardam a ficha consultada. As antigas são enriquecidas na leitura enquanto o dado bruto estiver retido.

O Slack mostra o nome, o ano, o preço arredondado em reais e a indicação de linha premium quando aplicável. Para um código desconhecido, exibe “nome comercial não identificado”. Tela, DPR e faixa acompanham o modelo. O CSV de sessões e os filtros de medição preservam os dados técnicos e permitem consultar ano, preço e linha premium. O catálogo do pacote funciona inteiramente no servidor.
