# Operar o Fator3 Site Core 1.87.0

Leia docs/RELEASE-1.87.0.md pelo índice de f3base/documentacao-ler. Para percorrer um arquivo, envie arquivo, linha e limite e siga proxima_linha até o final. A capacidade exigida é manage_options.

1. Leia f3base/saude-ler com compacto verdadeiro e registre versão, contrato, atualização e esperas.
2. Consulte f3base/aplicabilidade-ler com modulo igual a email_historico. Compare resultado, revisao, proximos e esperas_observadas antes e depois da distribuição. Compare também cada revisão de agenda dos seis trabalhadores.
3. Para aprofundar uma contagem, consulte a rota retornada em detalhe. O resumo não reproduz séries nem dados de contatos.
4. Nos relatórios integrados, informe visao, de e ate. Reduza o intervalo após limite_memoria ou reduza_periodo. Guarde o diagnóstico. Um erro na fonte precisa ser distinguido de uma métrica zero.
5. No painel, use as telas de Contatos e Medição para conferir histórico e relatórios. Compare o próximo envio natural do CTO Office com a confirmação no CRM. Em Site-Teste, use dados sintéticos e mantenha a configuração comercial vigente.
