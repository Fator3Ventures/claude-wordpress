# Operação do Site Core 1.92.0

1. Leia DOCUMENTACAO.md e RELEASE-1.92.0.md usando f3base/documentacao-ler, seguindo proxima_linha até o final.
2. Consulte f3base/como-usar compacto; confira versão, contrato 8.44.0 e agenda_das_filas.cobertura=f3base_*.
3. Confira a lista ganchos_cobertos, os três filtros registrados e os plugins reposicionados. A lista é diagnóstica; o prefixo define a cobertura.
4. Consulte f3base/aparelhos-sem-nome-ler com manage_options. Separe nome técnico ambíguo, família inferida e ficha comercial incompleta. Regras locais prevalecem.
5. Para o aceite 426, observe a janela de 24 horas após a troca em ctooffice, korvena.com.br e fator3.com.br: zero could_not_set de f3base_ e zero execução duplicada. Inclua migração e complementos. A consulta não autoriza envio a fornecedores.
6. As provas e as limitações da rodada estão no relatório externo e no fonte. Evidências das versões anteriores não são resultados desta versão.
