# Fator3 Site Core 1.92.1 — leia primeiro

Versão 1.92.1. O catálogo preserva nomes próprios e valida candidatos comerciais antes de usar o Device. Consulte RELEASE-1.92.1.md.

Instalação nova ou atualização da 1.92.0. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.44.0.

