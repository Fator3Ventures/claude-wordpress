# Fonte do Fator3 Site Core 1.92.1

Correção 428 sobre 1.92.0. WordPress 7.1.4+ e PHP 8.3+ de 64 bits. A árvore instalável está em work/plugin/base-site-core-fator3. As normas gerais estão na revisão 5 de 02/11/2026.

## Reproduzir e validar

A partir da raiz do fonte, use Python 3 com a biblioteca padrão.

```sh
python3 build/gerar-google-play.py --data 2026-11-15
python3 tests/google-play-integridade.py
python3 tests/428/catalogo.py
F3BASE_PHP=/caminho/para/php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.92.1-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.92.1-instalador.zip
python3 tests/428/catalogo.py ../base-site-core-fator3-1.92.1-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.92.1-fonte.zip
```

A auditoria histórica completa e os dados de território ficam em reference/428. O teste do catálogo recompila também um snapshot sintético fora da árvore do plugin. As provas desta rodada estão em evidence/1921. As pastas de versões anteriores documentam os respectivos pacotes. Consulte tests/428/README.md para os cenários de WordPress real e RELATORIO-PRE-FECHAMENTO.md para a versão congelada do relatório.
