<?php
require __DIR__.'/bootstrap-1850.php';
require __DIR__.'/origem-1850-fixtures.php';
global $wpdb;
$fixtures=f3qa181_projecoes('check');
$cases=[
    ['email','email',['utm_source'=>'google','utm_medium'=>'cpc'],'Recebido por e-mail'],
    ['formulario','meta',[],'Formulário Meta · Meta Ads'],
    ['anuncio_linkedin','linkedin',[],'Formulário LinkedIn · LinkedIn Ads'],
    ['formulario','',[],'Formulário Site · Orgânico'],
    ['formulario','',['utm_source'=>'google','utm_medium'=>'organic'],'Formulário Site · Orgânico'],
    ['formulario','',['utm_source'=>'Newsletter','utm_campaign'=>'rodada'],'Formulário Site · Newsletter'],
    ['whatsapp_cta','',['utm_source'=>'google','utm_medium'=>'cpc'],'Clique para WhatsApp · Google Ads'],
    ['formulario','',['utm_source'=>'instagram','utm_campaign'=>'verao'],'Formulário Site · Meta Ads'],
];
foreach (['gclid'=>'Google Ads','wbraid'=>'Google Ads','gbraid'=>'Google Ads','fbclid'=>'Meta Ads','li_fat_id'=>'LinkedIn Ads'] as $k=>$label) {
    $cases[]=['whatsapp_cta','',[$k=>'id-privado'],'Clique para WhatsApp · '.$label];
}
foreach ($cases as $i=>[$method,$native,$raw,$label]) {
    $a=$fixtures['google']['a'];$a['origem_nativa']=$native?['origem'=>$native]:[];$a['metodo']=$method;$a['teste']=$i%2===1;
    $a['atribuicao']=F3Base_Contato_Apresentacao::atribuicao(F3Base_Atribuicao::normalizar($raw),true);
    $messages=F3Base_Slack_Thread::mensagens($a);
    $expect=($a['teste']?'[TESTE] ':'').$a['site'].' · '.$label;
    check($messages[0]['blocks'][0]['text']['text']===$expect && explode("\n",$messages[0]['text'])[0]===$expect && !str_contains($messages[0]['text'],'id-privado'),'395_primeira_linha_'.$i,$messages[0]['text']);
}
$google=F3Base_Google_Acervo::opcoes();
$google['ativo']=true;$google['conta_id']='1234567890';$google['conexao']='qa';$google['revisao']=1;
update_option('f3base_google_ads_acervo',$google,false);
$prop=new ReflectionProperty(F3Base_Google_Acervo::class,'client');$previous=$prop->getValue();
$local=new class { public int $reads=0; public function query($q){
    $this->reads++;$row=['dataset'=>'campaign','account_id'=>'1234567890','campaign_id'=>'441','campaign_name'=>'Campanha local QA','date'=>$q['date']];
    return ['success'=>true,'contract_version'=>'1.0.0','rows'=>isset($q['cursor'])?[$row]:[],'next_cursor'=>isset($q['cursor'])?null:'pagina2'];
}};
$prop->setValue(null,$local);
$webAd=['consentimento_historico'=>['publicidade'=>true],'atribuicao'=>['plataforma'=>'google_ads','campanha_id'=>'441','utm_campaign'=>'441'],'corte_em'=>time()];
check(F3Base_Anuncio_Origem::base($webAd)['fields']['Campanha']==='Campanha local QA' && $local->reads===2,'394_nome_acervo_paginado_no_aviso_inicial');
update_option('f3base_campanhas_nomes',[['plataforma'=>'google_ads','conta'=>'1234567890','campanha'=>'441','nome'=>'Mapa local QA']],false);
check(F3Base_Anuncio_Origem::base($webAd)['fields']['Campanha']==='Mapa local QA' && $local->reads===2,'394_mapa_sem_http');
$webAd['atribuicao']['conta_id']='9090909090';
check(empty(F3Base_Anuncio_Origem::base($webAd)['fields']['Campanha']) && $local->reads===2,'394_nao_mistura_contas');
$at=time(); $capture=['gclid'=>'x','campanha_id'=>'441'];$touch=['campanha_id'=>'441','conta_id'=>'1234567890'];
$lead=['criado_em'=>gmdate('Y-m-d H:i:s',$at),'dados'=>['atribuicao'=>$capture],'google_ads'=>wp_json_encode(['codigo'=>'encontrado','configuracao'=>F3Base_Google_Acervo::configuracao()['revision'],'origem_hash'=>hash('sha256',wp_json_encode([$capture,$at])),'clique'=>['account_id'=>'1234567890','campaign_id'=>'441','date'=>gmdate('Y-m-d',$at),'campaign_name'=>'Acervo do clique']])];
check(F3Base_Google_Acervo::campanha_do_clique($lead,$touch)==='Acervo do clique','394_nome_clique_vinculado_com_concessao');
$lead['dados']['atribuicao']['gclid']='outro';
check(F3Base_Google_Acervo::campanha_do_clique($lead,$touch)==='','394_clique_divergente_nao_renomeia');
$prop->setValue(null,$previous);delete_option('f3base_campanhas_nomes');delete_option('f3base_google_ads_acervo');
$url=home_url('/form/?utm_source_platform=meta_ads&utm_medium=cpc&utm_id=333&utm_content=444&f3_ads_v=1&f3_ads_account_id=222&f3_ads_group_id=555');
$web=F3Base_Atribuicao::para_captura(F3Base_Atribuicao::sem_sessao([],$url,true),true,true);
check($web['conta_id']==='222' && $web['anuncio_id']==='444' && $web['grupo_id']==='555','site_url_v1_anuncio_conta_grupo');
$restricted=F3Base_Atribuicao::para_captura(F3Base_Atribuicao::sem_sessao([],$url,false),true,false);
check(!isset($restricted['anuncio_id'],$restricted['conta_id'],$restricted['utm_content']),'site_url_v1_negativa');

require __DIR__.'/origem-1850-transportes.php';
f3qa181_transportes($fixtures,'check');
$http=static fn($body,$code=200)=>['response'=>['code'=>$code,'message'=>'fixture'],'body'=>is_string($body)?$body:wp_json_encode($body),'headers'=>[]];
wp_set_current_user(0);check(F3Base_Google_Acervo::anuncio_origem(['ad_id'=>'456'])['codigo']==='sem_permissao','ability_google_sem_permissao');wp_set_current_user(1);
$home=static fn()=>'https://127.0.0.1:8137/subsite';$content=static fn($url,$path)=>'http://outra.example/custom-conteudo'.($path?'/'.ltrim($path,'/'):'');
add_filter('option_home',$home,999);add_filter('content_url',$content,999,2);$status=404;$urls=[];
$probe=function($pre,$args,$url)use(&$status,&$urls,$http){$urls[]=$url;
    if(str_ends_with($url,'/controle.txt')){preg_match('~(f3base-sonda-index-[a-f0-9]+/controle.txt)$~',$url,$m);return $http(file_get_contents(dirname(F3Base_Llms_Arquivo::caminho()).'/'.$m[1]));}
    if(str_ends_with($url,'/upgrade/')){return $http('',str_starts_with($url,'https://')?$status:301);}
    return $http('',403);
};
add_filter('pre_http_request',$probe,8,3);add_filter('http_allowed_safe_ports',static fn($v)=>array_merge($v,[8137]));
$test=new ReflectionMethod('F3Base_Servidor','verificar_listagem');
foreach([404=>'verified',200=>'pending'] as $code=>$wanted){$status=$code;$r=$test->invoke(null,false);check(!is_ssl() && $r['upgrade_http']===$code && $r['status']===$wanted && end($urls)==='https://127.0.0.1:8137/custom-conteudo/upgrade/','cron_cli_origem_canonica_'.$code,[$r,$urls]);}
evidence('origem-1850',['plataformas'=>array_keys($fixtures),'transporte'=>'WordPress nativo, HTTP interceptado']);
