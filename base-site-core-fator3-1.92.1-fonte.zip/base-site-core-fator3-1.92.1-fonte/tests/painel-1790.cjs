// Aceite do painel do Site Core 1.79.0 (itens A1–A9 do PLANO-1.79.0.md), medido num WordPress de laboratório.
//
// Uso:
//   node tests/painel-1790.cjs <base-url> <arquivo-com-a-senha-do-qa_admin> <saida.json> [--inventario <arquivo>] [--gravar-inventario]
//
// --gravar-inventario grava o inventário de campos da instalação medida (usado uma vez contra a 1.78.0
// para produzir tests/fixtures/painel-campos-1780.json) e não avalia mais nada.
// Sem essa opção, compara os campos de cada área com o inventário e executa todas as checagens.
// Código de saída 1 quando alguma checagem falha. Requer Playwright e axe-core (NODE_PATH).
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const [base, arquivoSenha, saida] = args;
const opcao = (nome) => { const i = args.indexOf(nome); return i === -1 ? null : (args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : true); };
const arquivoInventario = typeof opcao('--inventario') === 'string' ? opcao('--inventario') : path.join(__dirname, 'fixtures', 'painel-campos-1780.json');
const gravarInventario = !!opcao('--gravar-inventario');
const senha = fs.readFileSync(arquivoSenha, 'utf8');
const axeFonte = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');

const P = 'base-site-core-fator3';
const AREAS = ['contato', 'medicao-tags', 'medicao-meta', 'medicao-coleta', 'medicao-gsc', 'medicao-ga4', 'medicao-clarity', 'medicao-testes', 'consentimento', 'privacidade', 'conteudo', 'seo'];
const urlArea = (s) => `/wp-admin/admin.php?page=${P}&secao=${s}`;
const TELAS = [
  { id: 'config-inicio', url: urlArea('inicio') }, { id: 'config-conexoes', url: urlArea('conexoes') },
  ...AREAS.map((s) => ({ id: 'config-' + s, url: urlArea(s), area: s })),
  { id: 'aba-tecnica', url: `/wp-admin/admin.php?page=${P}&aba=tecnica` },
  { id: 'aba-operacao', url: `/wp-admin/admin.php?page=${P}&aba=operacao` },
  { id: 'pg-operacao', url: '/wp-admin/admin.php?page=f3base-operacao' },
  { id: 'pg-leads', url: '/wp-admin/admin.php?page=f3base-leads' },
  { id: 'pg-formularios', url: '/wp-admin/admin.php?page=f3base-formularios' },
  { id: 'pg-conteudos', url: '/wp-admin/admin.php?page=f3base-conteudos' },
  { id: 'pg-medicao', url: '/wp-admin/admin.php?page=f3base-medicao' },
  { id: 'pg-relatorios', url: '/wp-admin/admin.php?page=f3base-relatorios' },
  { id: 'pg-integracoes', url: '/wp-admin/admin.php?page=f3base-integracoes' },
];
// D1: options estruturadas sem editor nesta tela. Na 1.78.0 saíam como <input type="text"> e faziam a área inteira
// ser recusada. Na 1.79.0 deixam de ser campo do formulário e aparecem como bloco somente leitura.
const SEM_EDITOR = { 'medicao-coleta': ['f3base_campanhas_origem', 'f3base_contexto_sessao', 'f3base_canais_organicos', 'f3base_origens_ia'], conteudo: ['f3base_marcas_vigiadas'], seo: ['f3base_redirects'] };
const LARGURAS = [{ w: 1440, h: 900 }, { w: 390, h: 844 }];
// --telas a,b,c restringe a varredura (provas por mutação). A execução completa é a que vale como aceite.
const soTelas = typeof opcao('--telas') === 'string' ? opcao('--telas').split(',') : null;
const TELAS_DA_EXECUCAO = soTelas ? TELAS.filter((t) => soTelas.includes(t.id)) : TELAS;
const AREAS_DA_EXECUCAO = soTelas ? AREAS.filter((s) => soTelas.includes('config-' + s)) : AREAS;
// Campos de controle do formulário que mudam a cada carga ou não são dados da área.
const NOMES_DE_CONTROLE = /^(_wpnonce|_wp_http_referer|action|secao|submit|f3base_renovar_nonce|f3base_contexto|f3base_fim|f3base_revisao\[.*\])$/;

const checagens = []; // {id, ok, detalhe}
const check = (id, ok, detalhe) => { checagens.push({ id, ok: !!ok, detalhe: ok ? undefined : detalhe }); };
const medidas = { telas: [], salvar: [], larguras: {}, tecnica: {}, campos: {} };

// Botão de salvar: o da barra quando existe; senão o do formulário (a ausência da barra é acusada em checagem própria).
const seletorSalvar = async (p) => ((await p.locator('form.f3base-form .f3base-savebar [type=submit]').count()) ? 'form.f3base-form .f3base-savebar [type=submit]' : 'form.f3base-form [type=submit]');

async function entrar(contexto) {
  const p = await contexto.newPage();
  await p.goto(base + '/wp-login.php');
  await p.fill('#user_login', 'qa_admin'); await p.fill('#user_pass', senha);
  await Promise.all([p.waitForNavigation(), p.click('#wp-submit')]);
  return p;
}

const inventarioDaPagina = (controleFonte) => {
  const controle = new RegExp(controleFonte);
  const f = document.querySelector('form.f3base-form');
  if (!f) return null;
  const nomes = [...f.querySelectorAll('input[name],select[name],textarea[name]')].map((e) => e.name).filter((n) => !controle.test(n));
  return { nomes: [...new Set(nomes)].sort(), campos: [...new Set([...f.querySelectorAll('[data-f3base-campo]')].map((e) => e.getAttribute('data-f3base-campo')))].sort() };
};

const medirTela = () => {
  const raiz = document.querySelector('#wpbody-content') || document.body;
  const visivel = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const ids = {}; raiz.querySelectorAll('[id]').forEach((el) => { ids[el.id] = (ids[el.id] || 0) + 1; });
  const rotulaveis = ['INPUT', 'SELECT', 'TEXTAREA', 'BUTTON', 'METER', 'OUTPUT', 'PROGRESS'];
  const rotulosOrfaos = [...raiz.querySelectorAll('label[for]')].filter((l) => { const a = document.getElementById(l.htmlFor); return !a || !rotulaveis.includes(a.tagName); }).map((l) => l.htmlFor);
  // Rótulo repetido: fieldset cujo legend visível repete o texto de um label visível da mesma linha/campo.
  const repetidos = [];
  raiz.querySelectorAll('fieldset > legend').forEach((lg) => {
    if (!visivel(lg)) return;
    const t = lg.textContent.trim(); if (!t) return;
    const escopo = lg.closest('tr') || lg.closest('.f3base-campo') || lg.parentElement.parentElement;
    const igual = [...(escopo ? escopo.querySelectorAll('label') : [])].some((l) => visivel(l) && l.textContent.trim() === t && !lg.parentElement.contains(l));
    if (igual) repetidos.push(t.slice(0, 60));
  });
  // "Como funciona" repetindo a descrição já visível do mesmo campo.
  const ajudaRepetida = [];
  raiz.querySelectorAll('details.f3base-ajuda').forEach((d) => {
    const escopo = d.closest('.f3base-campo') || d.closest('td') || d.parentElement;
    const visiveis = [...escopo.querySelectorAll('p')].filter((p) => !d.contains(p) && visivel(p)).map((p) => p.textContent.replace(/\s+/g, ' ').trim()).filter((t) => t.length > 20);
    [...d.querySelectorAll('p')].forEach((p) => {
      const t = p.textContent.replace(/\s+/g, ' ').trim().replace(/^Como funciona:\s*/, '');
      if (t.length > 20 && visiveis.includes(t)) ajudaRepetida.push(t.slice(0, 60));
    });
  });
  const avisosCrus = [...raiz.querySelectorAll('.notice')].filter(visivel).map((n) => n.textContent.replace(/\s+/g, ' ').trim()).filter((t) => /\b[a-z0-9]+_[a-z0-9_]+ — [a-z0-9]+_[a-z0-9_]+\b/.test(t)).map((t) => t.slice(0, 80));
  let hiddenGlobal = 0;
  for (const folha of document.styleSheets) { let regras = []; try { regras = folha.cssRules; } catch (e) { continue; } for (const r of regras) { if (r.selectorText && r.selectorText.split(',').some((s) => s.trim() === '[hidden]') && /f3base/.test(folha.href || '')) hiddenGlobal++; } }
  return {
    altura: document.documentElement.scrollHeight, larguraDoc: document.documentElement.scrollWidth, larguraJanela: document.documentElement.clientWidth,
    estouro: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
    idsDuplicados: Object.entries(ids).filter(([, n]) => n > 1).map(([i, n]) => i + '×' + n),
    rotulosOrfaos, rotulosRepetidos: repetidos, ajudaRepetida, avisosCrus, hiddenGlobal,
    erroPhp: /(Warning|Notice|Fatal error|Deprecated|Parse error)<\/b>:|Uncaught /.test(document.body.innerHTML),
    estilosInline: raiz.querySelectorAll('.f3base-tela [style]').length,
  };
};

(async () => {
  const navegador = await chromium.launch();

  // ---------- Inventário de campos (pode ser só gravação) ----------
  {
    const ctx = await navegador.newContext({ viewport: { width: 1440, height: 900 }, locale: 'pt-BR' });
    const p = await entrar(ctx);
    for (const s of AREAS) {
      await p.goto(base + urlArea(s), { waitUntil: 'load' });
      medidas.campos[s] = await p.evaluate(inventarioDaPagina, NOMES_DE_CONTROLE.source);
    }
    await ctx.close();
    if (gravarInventario) {
      fs.mkdirSync(path.dirname(arquivoInventario), { recursive: true });
      fs.writeFileSync(arquivoInventario, JSON.stringify(medidas.campos, null, 1) + '\n');
      console.log('inventário gravado em', arquivoInventario, Object.entries(medidas.campos).map(([k, v]) => k + '=' + (v ? v.nomes.length : 'sem-form')).join(' '));
      await navegador.close(); return;
    }
    const baseInv = JSON.parse(fs.readFileSync(arquivoInventario, 'utf8'));
    for (const s of AREAS_DA_EXECUCAO) {
      const a = medidas.campos[s], b0 = baseInv[s];
      const retirados = (SEM_EDITOR[s] || []).map((o) => `f3base[${o}]`);
      const b = b0 && { nomes: b0.nomes.filter((n) => !retirados.includes(n)), campos: b0.campos };
      check(`campos_iguais_a_1780:${s}`, a && b && JSON.stringify(a.nomes) === JSON.stringify(b.nomes) && JSON.stringify(a.campos) === JSON.stringify(b.campos),
        a && b ? { faltam: b.nomes.filter((n) => !a.nomes.includes(n)).slice(0, 8), sobram: a.nomes.filter((n) => !b.nomes.includes(n)).slice(0, 8), camposFaltam: b.campos.filter((n) => !a.campos.includes(n)).slice(0, 8), camposSobram: a.campos.filter((n) => !b.campos.includes(n)).slice(0, 8) } : 'formulário ausente');
    }
  }

  // ---------- Varredura das 23 telas nas duas larguras ----------
  for (const { w, h } of LARGURAS) {
    const ctx = await navegador.newContext({ viewport: { width: w, height: h }, locale: 'pt-BR' });
    const p = await entrar(ctx);
    for (const tela of TELAS_DA_EXECUCAO) {
      const erros = [];
      const aoConsole = (m) => { if (m.type() === 'error') erros.push(m.text().slice(0, 200)); };
      const aoErro = (e) => erros.push(String(e.message || e).slice(0, 200));
      p.on('console', aoConsole); p.on('pageerror', aoErro);
      const resp = await p.goto(base + tela.url, { waitUntil: 'load', timeout: 60000 }); await p.waitForTimeout(300);
      const m = await p.evaluate(medirTela);
      await p.addScriptTag({ content: axeFonte });
      const axe = await p.evaluate(async () => {
        const r = await window.axe.run(document.querySelector('#wpbody-content') || document, { resultTypes: ['violations'], runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] } });
        return r.violations.map((v) => v.id + '×' + v.nodes.length);
      });
      p.off('console', aoConsole); p.off('pageerror', aoErro);
      const t = `${tela.id}@${w}`;
      medidas.telas.push({ tela: tela.id, largura: w, http: resp.status(), altura: m.altura, estouro: m.estouro, idsDuplicados: m.idsDuplicados.length, axe: axe.length, errosJs: erros.length });
      check(`http_200:${t}`, resp.status() === 200, resp.status());
      check(`sem_erro_js:${t}`, erros.length === 0, erros.slice(0, 3));
      check(`sem_erro_php_na_pagina:${t}`, !m.erroPhp, 'texto de erro PHP no HTML');
      check(`A9_ids_unicos:${t}`, m.idsDuplicados.length === 0, m.idsDuplicados.slice(0, 6));
      check(`A9_axe_zero:${t}`, axe.length === 0, axe);
      if (w === 390) check(`A6_sem_estouro_390:${tela.id}`, !m.estouro, `documento com ${m.larguraDoc}px numa janela de ${m.larguraJanela}px`);
      check(`A5_label_for_valido:${t}`, m.rotulosOrfaos.length === 0, m.rotulosOrfaos.slice(0, 6));
      check(`A5_rotulo_unico:${t}`, m.rotulosRepetidos.length === 0, m.rotulosRepetidos.slice(0, 6));
      check(`A5_ajuda_nao_repete_descricao:${t}`, m.ajudaRepetida.length === 0, { ocorrencias: m.ajudaRepetida.length, amostra: m.ajudaRepetida.slice(0, 3) });
      check(`A2_aviso_sem_codigo_cru:${t}`, m.avisosCrus.length === 0, m.avisosCrus);
      check(`A1_hidden_sem_seletor_global:${t}`, m.hiddenGlobal === 0, `${m.hiddenGlobal} regra(s) [hidden] global em folha do plugin`);
      if (tela.id === 'aba-tecnica' && w === 1440) {
        const tec = await p.evaluate(() => {
          const secoes = [...document.querySelectorAll('details.f3base-tecnica-secao')];
          const pres = [...document.querySelectorAll('.f3base-tela pre')];
          const semLimite = pres.filter((x) => { const s = getComputedStyle(x); return s.maxHeight === 'none' || !/(auto|scroll)/.test(s.overflowY); }).length;
          return { secoes: secoes.length, abertas: secoes.filter((d) => d.open).length, semResumo: secoes.filter((d) => !d.querySelector(':scope > summary') || !d.querySelector(':scope > summary').textContent.trim()).length, pres: pres.length, presSemLimite: semLimite };
        });
        medidas.tecnica = { altura: m.altura, ...tec };
        check('A7_tecnica_altura_abaixo_de_6000', m.altura < 6000, m.altura);
        check('A7_tecnica_secoes_recolhiveis', tec.secoes >= 2 && tec.semResumo === 0, tec);
        check('A7_tecnica_no_maximo_uma_secao_aberta', tec.abertas <= 1, tec);
        check('A7_pre_com_altura_maxima_e_rolagem', tec.presSemLimite === 0, tec);
      }
      if (w === 1440 && (tela.area || tela.id === 'config-inicio' || tela.id === 'config-conexoes' || tela.id === 'aba-tecnica')) {
        const lar = await p.evaluate(() => {
          const r = (sel) => { const e = document.querySelector(sel); if (!e) return null; const q = e.getBoundingClientRect(); return [Math.round(q.left), Math.round(q.right)]; };
          const wrap = document.querySelector('.wrap.f3base-tela');
          // Conteúdo principal: .f3base-layout quando existe; senão o maior bloco filho direto da tela abaixo da navegação.
          let principal = r('.f3base-layout');
          if (!principal && wrap) {
            const filhos = [...wrap.children].filter((e) => !e.matches('.f3base-cabecalho,nav,.notice,h1,script,style,p') && e.getBoundingClientRect().height > 60);
            const maior = filhos.sort((a, b) => b.getBoundingClientRect().height - a.getBoundingClientRect().height)[0];
            if (maior) { const q = maior.getBoundingClientRect(); principal = [Math.round(q.left), Math.round(q.right)]; }
          }
          return { cabecalho: r('.f3base-cabecalho'), nav: r('nav.f3base-config-nav'), principal };
        });
        medidas.larguras[tela.id] = lar;
        const pecas = [lar.cabecalho, lar.nav, lar.principal].filter(Boolean);
        const alinhado = !!lar.cabecalho && !!lar.principal && pecas.every((q) => Math.abs(q[0] - pecas[0][0]) <= 2 && Math.abs(q[1] - pecas[0][1]) <= 2);
        check(`A1_largura_unica:${tela.id}`, alinhado, lar);
      }
      if (tela.area) {
        const idx = await p.evaluate(() => {
          const lay = document.querySelector('.f3base-layout'); if (!lay) return null;
          const nav = lay.querySelector('nav.f3base-indice'); const cont = lay.querySelector('.f3base-layout-conteudo');
          if (!nav || !cont) return { nav: !!nav, cont: !!cont };
          const links = [...nav.querySelectorAll('a[href^="#"]')];
          const quebrados = links.filter((a) => { const id = decodeURIComponent(a.getAttribute('href').slice(1)); return !id || !document.getElementById(id); }).map((a) => a.getAttribute('href'));
          const grupos = document.querySelectorAll('form.f3base-form fieldset.f3base-grupo h3, form.f3base-form .f3base-grupo > h3').length;
          const n = nav.getBoundingClientRect(), c = cont.getBoundingClientRect();
          return { nav: true, cont: true, aria: !!nav.getAttribute('aria-label'), links: links.length, quebrados, grupos, aoLado: n.width > 40 && n.height > 20 && (n.right <= c.left + 2 || c.right <= n.left + 2), dentroDeDetails: (!!nav.closest('details') || !!nav.querySelector('details')) && n.width > 40 && n.height > 10, navTopo: Math.round(n.top), contTopo: Math.round(c.top) };
        });
        check(`A3_layout_com_indice:${t}`, idx && idx.nav && idx.cont && idx.aria, idx);
        if (idx && idx.nav && idx.cont) {
          check(`A3_links_do_indice_validos:${t}`, idx.quebrados.length === 0 && idx.links >= 1 && (idx.grupos < 2 || idx.links >= 2), idx);
          if (w === 1440) {
            check(`A3_indice_ao_lado:${t}`, idx.aoLado, idx);
            const fixo = await p.evaluate(async () => { const max = document.documentElement.scrollHeight - innerHeight; if (max < 400) return 'pagina-curta'; scrollTo(0, max * 0.5); await new Promise((x) => setTimeout(x, 150)); const a = document.querySelector('nav.f3base-indice a'); if (!a) return 'sem-link'; const q = a.getBoundingClientRect(); if (q.width === 0 || q.height === 0) return 'oculto'; return q.top >= 0 && q.bottom <= innerHeight ? 'visivel' : 'fora(' + Math.round(q.top) + ')'; });
            check(`A3_indice_visivel_na_rolagem:${t}`, fixo === 'visivel' || fixo === 'pagina-curta', fixo);
          } else {
            check(`A3_indice_recolhivel_no_topo:${t}`, idx.dentroDeDetails && idx.navTopo <= idx.contTopo, idx);
          }
        }
        const avancado = await p.evaluate(() => { const d = document.querySelector('form.f3base-form .f3base-avancado'); return d ? { tag: d.tagName, aberto: d.open === true, resumo: !!d.querySelector(':scope > summary') } : null; });
        if (avancado) check(`A3_ajustes_avancados_recolhidos:${t}`, avancado.tag === 'DETAILS' && !avancado.aberto && avancado.resumo, avancado);
        if (SEM_EDITOR[tela.area]) {
          const sl = await p.evaluate((opts) => opts.map((o) => ({ o, bloco: !!document.querySelector(`form.f3base-form section.f3base-somente-leitura [data-f3base-campo="${o}"]`), controle: document.querySelectorAll(`[name="f3base[${o}]"],[name^="f3base[${o}]["],[name="f3base_revisao[${o}]"]`).length })), SEM_EDITOR[tela.area]);
          check(`D1_bloco_somente_leitura_sem_controle:${t}`, sl.every((x) => x.bloco && x.controle === 0), sl);
        }
        // A4: botão de salvar inteiro dentro da janela em topo, meio e fim; não cobre o último campo.
        const pos = [];
        for (const f of [0, 0.5, 1]) {
          pos.push(await p.evaluate(async (f) => {
            const max = Math.max(0, document.documentElement.scrollHeight - innerHeight); scrollTo(0, max * f); await new Promise((x) => setTimeout(x, 150));
            const barra = document.querySelector('form.f3base-form .f3base-savebar');
            const bt = barra && [...barra.querySelectorAll('input[type=submit],button[type=submit]')].find((e) => e.offsetParent !== null || getComputedStyle(e).position === 'fixed');
            if (!bt) return 'sem-botao-na-savebar'; const q = bt.getBoundingClientRect();
            if (q.width === 0 || q.height === 0) return 'oculto';
            return q.top >= 0 && q.bottom <= innerHeight && q.left >= 0 && q.right <= innerWidth ? 'visivel' : 'fora(' + Math.round(q.top) + ')';
          }, f));
        }
        medidas.salvar.push({ area: tela.area, largura: w, topo: pos[0], meio: pos[1], fim: pos[2] });
        check(`A4_salvar_visivel_topo_meio_fim:${t}`, pos.every((x) => x === 'visivel'), pos);
        const cobre = await p.evaluate(async () => {
          scrollTo(0, document.documentElement.scrollHeight); await new Promise((x) => setTimeout(x, 150));
          const barra = document.querySelector('form.f3base-form .f3base-savebar'); if (!barra) return 'sem-savebar';
          const b = barra.getBoundingClientRect();
          const controles = [...document.querySelectorAll('form.f3base-form [data-f3base-campo] input:not([type=hidden]),form.f3base-form [data-f3base-campo] select,form.f3base-form [data-f3base-campo] textarea')].filter((e) => (e.checkVisibility ? e.checkVisibility() : e.offsetParent !== null) && e.getBoundingClientRect().height > 0);
          const ultimo = controles[controles.length - 1]; if (!ultimo) return 'sem-campo';
          const u = ultimo.getBoundingClientRect(); return u.bottom <= b.top + 1 ? 'livre' : `coberto(${Math.round(u.bottom)}>${Math.round(b.top)})`;
        });
        check(`A4_savebar_nao_cobre_ultimo_campo:${t}`, cobre === 'livre', cobre);
        const sit = await p.evaluate(() => !!document.querySelector('form.f3base-form .f3base-savebar [data-f3base-situacao]'));
        check(`A4_situacao_na_savebar:${t}`, sit, 'elemento [data-f3base-situacao] ausente da barra');
      }
    }
    if (w === 1440) {
      const hrefs = await p.evaluate(() => [...document.querySelectorAll('#toplevel_page_base-site-core-fator3 .wp-submenu a')].map((a) => a.getAttribute('href')));
      medidas.menu = hrefs;
      check('A8_menu_sem_destino_repetido', hrefs.length > 0 && new Set(hrefs).size === hrefs.length, hrefs);
    }
    await ctx.close();
  }

  // ---------- A4: estado "não salvo" e gravação conferida por releitura (com JavaScript) ----------
  if (!soTelas) {
    const ctx = await navegador.newContext({ viewport: { width: 1440, height: 900 }, locale: 'pt-BR' });
    const p = await entrar(ctx);
    await p.goto(base + urlArea('contato'), { waitUntil: 'load' });
    const sel = { texto: 'textarea[name="f3base[f3base_contato][mensagem_padrao]"]', caixa: 'input[type=checkbox][name="f3base[f3base_contato][flutuante]"]', escolha: 'select[name="f3base[f3base_contato][historico_sem_decisao]"]' };
    const antes = await p.evaluate((s) => ({ texto: document.querySelector(s.texto)?.value, caixa: document.querySelector(s.caixa)?.checked, escolha: document.querySelector(s.escolha)?.value, opcoes: [...(document.querySelector(s.escolha)?.options || [])].map((o) => o.value) }), sel);
    check('roteiro_campos_de_ensaio_existem', antes.texto !== undefined && antes.caixa !== undefined && antes.escolha !== undefined, antes);
    const situacao = () => p.evaluate(() => (document.querySelector('[data-f3base-situacao]')?.textContent || '').trim());
    check('A4_situacao_vazia_sem_alteracao', (await situacao()) === '', await situacao());
    const marca = 'Ensaio 1790 ' + Date.now();
    await p.fill(sel.texto, marca);
    await p.dispatchEvent(sel.texto, 'change');
    check('A4_situacao_indica_alteracao', (await situacao()) !== '', 'situação continuou vazia após alterar um campo');
    await p.fill(sel.texto, antes.texto || ''); await p.dispatchEvent(sel.texto, 'change');
    check('A4_situacao_volta_ao_restaurar', (await situacao()) === '', await situacao());
    // Gravação de um campo de cada tipo.
    const novaEscolha = antes.opcoes.find((o) => o !== antes.escolha);
    await p.fill(sel.texto, marca);
    await p.setChecked(sel.caixa, !antes.caixa);
    if (novaEscolha !== undefined) await p.selectOption(sel.escolha, novaEscolha);
    p.once('dialog', (d) => d.accept());
    await Promise.all([p.waitForNavigation({ waitUntil: 'load' }), p.click(await seletorSalvar(p))]);
    await p.goto(base + urlArea('contato'), { waitUntil: 'load' });
    const depois = await p.evaluate((s) => ({ texto: document.querySelector(s.texto)?.value, caixa: document.querySelector(s.caixa)?.checked, escolha: document.querySelector(s.escolha)?.value }), sel);
    check('gravacao_relida:texto', depois.texto === marca, depois);
    check('gravacao_relida:checkbox', depois.caixa === !antes.caixa, depois);
    check('gravacao_relida:select', novaEscolha === undefined || depois.escolha === novaEscolha, depois);
    // D1: enviar o formulário sem alterar nada não pode ser recusado em nenhuma área.
    const avisosDaTela = () => p.evaluate(() => [...document.querySelectorAll('#wpbody-content .notice')].map((n) => n.textContent.replace(/\s+/g, ' ').trim()));
    medidas.gravarSemAlteracao = [];
    for (const s of AREAS) {
      await p.goto(base + urlArea(s), { waitUntil: 'load' });
      await Promise.all([p.waitForNavigation({ waitUntil: 'load' }), p.click(await seletorSalvar(p))]);
      const av = await avisosDaTela();
      const recusa = av.filter((t) => /Não foi possível salvar|Campo incompleto|fora do escopo/.test(t));
      const nada = av.some((t) => /Nenhuma alteração para salvar/.test(t));
      medidas.gravarSemAlteracao.push({ area: s, recusas: recusa.length, nenhumaAlteracao: nada });
      check(`D1_enviar_sem_alteracao_nao_e_recusado:${s}`, recusa.length === 0 && nada, { recusa: recusa.map((t) => t.slice(0, 160)), avisos: av.length });
    }
    // A3: um item do índice que aponta para dentro dos ajustes avançados (recolhidos) abre o bloco e mostra o destino.
    await p.goto(base + urlArea('medicao-tags'), { waitUntil: 'load' });
    const alvoAvancado = await p.evaluate(() => { const l = [...document.querySelectorAll('nav.f3base-indice a[href^="#"]')].find((a) => { const e = document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1))); return e && e.closest('details.f3base-avancado') && !e.matches('details.f3base-avancado'); }); return l ? l.getAttribute('href') : null; });
    check('A3_indice_tem_item_dentro_dos_ajustes_avancados', !!alvoAvancado, 'nenhum link do índice aponta para um campo dos ajustes avançados');
    if (alvoAvancado) {
      await p.click(`nav.f3base-indice a[href="${alvoAvancado}"]`); await p.waitForTimeout(300);
      const aberto = await p.evaluate((h) => { const e = document.getElementById(decodeURIComponent(h.slice(1))); const d = e.closest('details.f3base-avancado'); const q = e.getBoundingClientRect(); return { aberto: d.open, visivel: q.height > 0 && q.top >= 0 && q.top < innerHeight }; }, alvoAvancado);
      check('A3_indice_abre_ajustes_avancados', aberto.aberto && aberto.visivel, aberto);
    }
    // D2: alternar um destino de "Conversões de material" grava e relê; depois volta ao valor anterior.
    const ga4 = 'input[type=checkbox][name="f3base[f3base_conversoes_conteudo][ga4]"]';
    await p.goto(base + urlArea('medicao-tags'), { waitUntil: 'load' });
    const ga4Antes = await p.isChecked(ga4);
    await p.setChecked(ga4, !ga4Antes);
    await Promise.all([p.waitForNavigation({ waitUntil: 'load' }), p.click(await seletorSalvar(p))]);
    const avD2 = await avisosDaTela();
    await p.goto(base + urlArea('medicao-tags'), { waitUntil: 'load' });
    check('D2_alternar_destino_de_material_grava_e_rele', (await p.isChecked(ga4)) === !ga4Antes && !avD2.some((t) => /Não foi possível salvar/.test(t)), avD2.map((t) => t.slice(0, 160)).slice(0, 3));
    await p.setChecked(ga4, ga4Antes);
    await Promise.all([p.waitForNavigation({ waitUntil: 'load' }), p.click(await seletorSalvar(p))]);
    await p.goto(base + urlArea('medicao-tags'), { waitUntil: 'load' });
    check('D2_valor_anterior_restaurado', (await p.isChecked(ga4)) === ga4Antes, 'o destino não voltou ao valor anterior');
    await ctx.close();
  }

  // ---------- Sem JavaScript: barra, índice e gravação continuam funcionando ----------
  if (!soTelas) {
    const ctx = await navegador.newContext({ viewport: { width: 1440, height: 900 }, locale: 'pt-BR', javaScriptEnabled: false });
    const p = await entrar(ctx);
    await p.goto(base + urlArea('contato'), { waitUntil: 'load' });
    const html = await p.content();
    check('semjs_savebar_impressa_pelo_servidor', /class="[^"]*f3base-savebar/.test(html) && (await p.locator('form.f3base-form .f3base-savebar [type=submit]').count()) === 1, 'savebar com botão não está no HTML do servidor');
    check('semjs_indice_impresso_pelo_servidor', (await p.locator('.f3base-layout nav.f3base-indice a[href^="#"]').count()) >= 1, 'índice ausente sem JavaScript');
    const marca = 'Sem JS 1790 ' + Date.now();
    await p.fill('textarea[name="f3base[f3base_contato][mensagem_padrao]"]', marca);
    await Promise.all([p.waitForNavigation({ waitUntil: 'load' }), p.click(await seletorSalvar(p))]);
    await p.goto(base + urlArea('contato'), { waitUntil: 'load' });
    check('semjs_gravacao_relida', (await p.inputValue('textarea[name="f3base[f3base_contato][mensagem_padrao]"]')) === marca, 'valor não persistiu sem JavaScript');
    // Restaura o valor de ensaio para não deixar resíduo que altere medições seguintes.
    await p.fill('textarea[name="f3base[f3base_contato][mensagem_padrao]"]', '');
    await Promise.all([p.waitForNavigation({ waitUntil: 'load' }), p.click(await seletorSalvar(p))]);
    await ctx.close();
  }

  await navegador.close();
  const falhas = checagens.filter((c) => !c.ok);
  const resultado = { teste: 'tests/painel-1790.cjs', base, parcial: soTelas || false, total: checagens.length, aprovadas: checagens.length - falhas.length, falhas: falhas.length, medidas, checagens };
  fs.mkdirSync(path.dirname(path.resolve(saida)), { recursive: true });
  fs.writeFileSync(saida, JSON.stringify(resultado, null, 1) + '\n');
  // Resumo por família de checagem.
  const familias = {};
  for (const c of checagens) { const f = c.id.split(':')[0]; familias[f] = familias[f] || { ok: 0, falha: 0 }; familias[f][c.ok ? 'ok' : 'falha']++; }
  for (const [f, v] of Object.entries(familias)) console.log((v.falha ? 'FALHA' : 'ok   '), f.padEnd(40), `${v.ok}/${v.ok + v.falha}`);
  for (const c of falhas.slice(0, 25)) console.log('  ✗', c.id, JSON.stringify(c.detalhe).slice(0, 220));
  console.log(`painel-1790: ${checagens.length - falhas.length}/${checagens.length} checagens aprovadas`);
  process.exit(falhas.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
