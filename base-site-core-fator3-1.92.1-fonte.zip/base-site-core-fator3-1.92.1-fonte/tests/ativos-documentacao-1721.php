<?php
require __DIR__.'/bootstrap.php';
check(F3Base_Ativos_Publicos::arquivo_leads(null)==='assets/f3base-leads.min.js','projecao_ausente_usa_reserva_completa');
foreach([0,1,2,3] as $mask){
    $projection=['ads'=>['id'=>$mask&1?'AW-123':''],'meta'=>['pixelId'=>$mask&2?'123':'','modo'=>'navegador']];
    check(F3Base_Ativos_Publicos::arquivo_leads($projection)==='assets/perfis/leads-'.$mask.'.min.js','selecao_perfil_'.$mask);
}
check(F3Base_Ativos_Publicos::arquivo_leads(['meta'=>['pixelId'=>'123','modo'=>'servidor']])==='assets/perfis/leads-0.min.js','capi_apenas_nao_inclui_pixel');
if(!defined('SCRIPT_DEBUG')){define('SCRIPT_DEBUG',true);}
if(SCRIPT_DEBUG){check(F3Base_Ativos_Publicos::arquivo_leads([])==='assets/f3base-leads.js','debug_prefere_fonte');}
foreach(['docs/RELEASE-1.72.1.md','docs/VITAIS-VERSAO.md','docs/AGENTES-1.72.1.md'] as $file){
    $line=1;$hash=null;$count=0;
    do{
        $r=F3Base_Configuracao_Atual::documentacao(['arquivo'=>$file,'linha'=>$line,'limite'=>7]);
        check(!empty($r['ok']),'leitura_'.$file.'_'.$line);
        $hash??=$r['sha256'];check($r['sha256']===$hash,'revisao_'.$file.'_'.$line);
        $line=$r['proxima_linha'];$count++;
        if($count>100){throw new RuntimeException('Pagination loop');}
    }while($line!==null);
    check($hash===hash_file('sha256',F3BASE_PLUGIN_DIR.$file),'hash_local_'.$file);
}
check(F3Base_Configuracao_Atual::documentacao(['arquivo'=>'../wp-config.php'])['codigo']==='documento_nao_catalogado','documentacao_recusa_travessia');
wp_set_current_user(0);$r=F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/VITAIS-VERSAO.md']);
check(empty($r['ok']),'documentacao_recusa_anonimo');wp_set_current_user(1);
evidence('ativos-documentacao-1721');
