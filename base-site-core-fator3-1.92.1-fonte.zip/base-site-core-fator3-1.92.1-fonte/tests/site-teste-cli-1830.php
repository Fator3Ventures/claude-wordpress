<?php
defined('ABSPATH') || exit;
// Observa somente a invocação identificada por este teste.
if (defined('WP_CLI') && WP_CLI && getenv('F3_QA_CLI_1830')==='cron') {
    add_action('f3base_servidor_reverificar',static function(){
        $state=get_option('f3base_servidor_estado',[]);
        echo 'F3QA1830 '.wp_json_encode(['php'=>PHP_VERSION,'ssl'=>is_ssl(),'estado'=>$state['status']??'', 'em'=>$state['reverificado_em']??0,'agora'=>time(),'upgrade'=>$state['listagem']['upgrade_http']??0,'tem_callback'=>has_action('f3base_servidor_reverificar',['F3Base_Servidor','reverificar'])!==false])."\n";
    },PHP_INT_MAX);
}
add_action('wp_abilities_api_init', static function() {
    wp_register_ability('f3qa/cron-cli-1830', [
        'label'=>'Verificar o evento do servidor pelo WP-CLI','description'=>'Executa exclusivamente o evento de reverificação do Core no Site-Teste.',
        'category'=>'site','input_schema'=>['type'=>'object','additionalProperties'=>false,'properties'=>['executar'=>['type'=>'boolean']],'required'=>['executar']],
        'output_schema'=>['type'=>'object','additionalProperties'=>true],'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'show_in_rest'=>false],
        'permission_callback'=>static fn()=>current_user_can('manage_options') && F3BASE_PLUGIN_VERSAO==='1.83.0' && wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com',
        'execute_callback'=>static function($v) {
            if(empty($v['executar']))return ['executado'=>false];
            try {
            $wp=null;
            foreach (['/usr/local/bin/wp','/usr/bin/wp'] as $path) {
                if (is_file($path) && is_executable($path)) {$wp=$path;break;}
            }
            if (!$wp || !function_exists('proc_open')) {return ['executado'=>false,'codigo'=>'wp_cli_ou_processo_indisponivel'];}
            $env=getenv();$env['F3_QA_CLI_1830']='cron';unset($env['HTTPS'],$env['SERVER_PORT'],$env['REQUEST_SCHEME']);
            $php=null;
            foreach(['/usr/local/php83/bin/php','/usr/bin/php8.3',dirname(PHP_BINARY).'/php','/opt/php83/bin/php'] as $candidate) {
                if(is_file($candidate) && is_executable($candidate)) {$php=$candidate;break;}
            }
            if(!$php) return ['executado'=>false,'codigo'=>'php83_cli_indisponivel'];
            $env['PATH']=dirname($php).':'.($env['PATH']??'/usr/bin:/bin');
            $env['WP_CLI_PHP']=$php;
            $p=proc_open([$wp,'--path='.ABSPATH,'--no-color','cron','event','run','f3base_servidor_reverificar'],[0=>['file','/dev/null','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,ABSPATH,$env);
            if(!is_resource($p)){return ['executado'=>false,'codigo'=>'wp_cli_nao_iniciado'];}
            $stdout=stream_get_contents($pipes[1]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);$code=proc_close($p);
            preg_match('/F3QA1830 ([^\r\n]+)/',$stdout,$match);
            return ['medicao'=>json_decode($match[1]??'',true),'executado'=>true,'exit_code'=>$code,'evento_mencionado'=>str_contains($stdout,'f3base_servidor_reverificar'),'sucesso_wp_cli'=>str_contains($stdout,'Success:'),'erro_php'=>str_contains($err,'Fatal error')];
            } catch (Throwable $e) { return ['executado'=>false,'codigo'=>'wp_cli_excecao','tipo'=>get_class($e)]; }
        }
    ]);
});
