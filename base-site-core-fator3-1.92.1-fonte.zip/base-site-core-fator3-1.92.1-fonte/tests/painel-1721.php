<?php
/** Same native admin_menu registration in both recovered runtimes. */
define('WP_ADMIN',true);
require __DIR__.'/bootstrap.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
require_once ABSPATH.'wp-admin/includes/template.php';
$GLOBALS['menu']=[];$GLOBALS['submenu']=[];$GLOBALS['admin_page_hooks']=[];
$GLOBALS['_registered_pages']=[];$GLOBALS['_parent_pages']=[];
do_action('admin_menu');
$hook='toplevel_page_f3base-medicao';
$expected=F3BASE_PLUGIN_VERSAO==='1.72.0'?2:1;
$observed=[];
foreach(['vitais','qualidade'] as $view){
    $_GET=['page'=>'f3base-medicao','area'=>'tecnico','visao'=>$view,'vital_versao'=>'1.72.0',
        'vital_dispositivo'=>'movel','caminho'=>'/preservado/','segmento'=>'sem_testes',
        'de'=>wp_date('Y-m-d'),'ate'=>wp_date('Y-m-d')];
    ob_start();do_action($hook);$html=ob_get_clean();
    $dom=new DOMDocument();@$dom->loadHTML('<?xml encoding="UTF-8">'.$html);$xpath=new DOMXPath($dom);
    $panels=$xpath->query('//div[contains(concat(" ",normalize-space(@class)," ")," f3base-tela--medicao ")]')->length;
    $forms=$xpath->query('//form[@method="get"]')->length;
    check($panels===$expected&&$forms===$expected,'painel_e_formulario_'.$view);
    if($view==='vitais'){
        check($xpath->query('//input[@name="vital_versao" and @value="1.72.0"]')->length===$expected,'filtro_de_versao_preservado');
        check($xpath->query('//select[@name="vital_dispositivo"]/option[@value="movel" and @selected]')->length===$expected,'dispositivo_preservado');
        check($xpath->query('//input[@name="caminho" and @value="/preservado/"]')->length===$expected,'caminho_preservado');
        check($xpath->query('//th[text()="Percentil 75"]')->length===$expected,'tabela_vitais_unica');
    }
    $observed[$view]=['painel'=>$panels,'formulario'=>$forms,'sha256_html'=>hash('sha256',$html)];
}
$_GET=['page'=>'f3base-medicao','area'=>'tecnico','visao'=>'vitais','vital_versao'=>'<script>alert(1)</script>'];
ob_start();do_action($hook);$html=ob_get_clean();
check(!str_contains($html,'<script>alert(1)</script>')&&str_contains($html,'Digite uma versão'),'filtro_invalido_escapado_e_explicado');
$denied=static fn()=>static function($message,$title='',$args=[]){throw new RuntimeException('qa_denied');};
add_filter('wp_die_handler',$denied);wp_set_current_user(0);$refused=false;
ob_start();try{F3Base_Admin_Medicao::render();}catch(RuntimeException $e){$refused=$e->getMessage()==='qa_denied';}finally{ob_end_clean();}
check($refused,'painel_recusa_sem_manage_options');wp_set_current_user(1);remove_filter('wp_die_handler',$denied);
evidence('painel-'.str_replace('.','',F3BASE_PLUGIN_VERSAO),$observed);
