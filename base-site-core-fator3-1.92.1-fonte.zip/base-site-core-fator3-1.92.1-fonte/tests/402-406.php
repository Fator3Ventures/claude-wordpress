<?php
/** Execute with wp eval-file in a disposable local site with the fixture installed. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || !in_array(DB_NAME,['core186','fresh186'],true)) { throw new RuntimeException('WordPress local isolado obrigatório'); }
wp_set_current_user(1);
$checks=[];
$check=static function($ok,$name)use(&$checks){$checks[$name]=(bool)$ok;if(!$ok){throw new RuntimeException('Falhou: '.$name);}};
$check(F3BASE_PLUGIN_VERSAO==='1.86.0','versao');
$consulta=F3Base_Leads_Repositorio::consultar(['segmento'=>'sem_testes','busca'=>'Contato Exemplo'],1);
$check($consulta['ok'] && $consulta['total']===53 && count($consulta['registros'])===50,'primeira_pagina_e_total');
$outra=F3Base_Leads_Repositorio::consultar(['segmento'=>'sem_testes','busca'=>'Contato Exemplo'],2);
$check(count($outra['registros'])===3 && !array_intersect(array_column($consulta['registros'],'record_id'),array_column($outra['registros'],'record_id')),'segunda_pagina_sem_duplicados');
$check(count(array_filter(array_merge($consulta['registros'],$outra['registros']),static fn($r)=>!empty($r['aviso_apresentacao'])))===1,'registro_malformado_visivel');
$check(!str_contains(wp_json_encode($consulta['registros']),'payload_hash'),'segredo_interno_omitido');
$cursor=F3Base_Leads_Repositorio::consultar(['segmento'=>'sem_testes','busca'=>'Contato Exemplo','cursor'=>$consulta['proximo_cursor']]);
$check($cursor['ok'] && count($cursor['registros'])===3,'cursor_original');
foreach (['somente_testes'=>1,'todos'=>54] as $f=>$q) {$r=F3Base_Leads_Repositorio::consultar(['segmento'=>$f],1);$check($r['total']===$q,'segmento_'.$f);}
$check(F3Base_Leads_Repositorio::consultar(['lixeira'=>1,'segmento'=>'todos'],1)['total']===1,'lixeira');
$check(F3Base_Leads_Repositorio::consultar(['de'=>'2026-02-30'],1)['codigo']==='data_invalida','data_invalida');
foreach ([null,7,'{','[]',[],['codigo'=>'encontrado','clique'=>['campaign_name'=>['x']]]] as $i=>$v) {
    $check(F3Base_Google_Acervo::campanha_do_clique(['google_ads'=>$v],[])==='','forma_google_'.$i);
}
foreach (['resultados','campanhas','metodos'] as $view) {
    $r=F3Base_Relatorios::consultar(['de'=>wp_date('Y-m-d',time()-86400),'ate'=>wp_date('Y-m-d'),'visao'=>$view]);
    $check(!empty($r['ok']),'relatorio_'.$view);
}
$hora=time();
$intencao=static function($tarefa,$gancho,$at,$args=[],$estado='esgotada') {
    global $wpdb;
    $e=['id'=>$tarefa,'hook'=>$gancho,'args'=>$args,'timestamp'=>$at,'schedule'=>false];
    if (!F3Base_Operacao_Intencoes::registrar($e)) { throw new RuntimeException('Fixture'); }
    $key=F3Base_Operacao_Intencoes::chave($e);
    $wpdb->update(F3Base_Operacao_Intencoes::tabela(),['estado'=>$estado,'atualizada_em'=>$at,'criada_em'=>$at],['chave'=>$key]);
    return $key;
};
global $wpdb;
$estado=static fn($id)=>$wpdb->get_var($wpdb->prepare('SELECT estado FROM %i WHERE chave=%s',F3Base_Operacao_Intencoes::tabela(),$id));
$old=$intencao('ga4',F3Base_Ga4::CONTINUAR,$hora-3600);
$new=$intencao('ga4',F3Base_Ga4::CONTINUAR,$hora+700);
$args=$intencao('ga4',F3Base_Ga4::CONTINUAR,$hora-3800,['teste']);
$locked=$intencao('ga4',F3Base_Ga4::CONTINUAR,$hora-3500);
$wpdb->update(F3Base_Operacao_Intencoes::tabela(),['reserva'=>'teste-reserva','reserva_ate'=>$hora+80],['chave'=>$locked]);
wp_schedule_single_event($hora-3600,F3Base_Ga4::CONTINUAR);
wp_schedule_single_event($hora+800,F3Base_Ga4::CONTINUAR);
(new ReflectionMethod(F3Base_Ga4::class,'registrar_sucesso'))->invoke(null,$hora);
$check($estado($old)==='concluida','ga4_espera_encerrada');
$check($estado($new)==='esgotada' && $estado($args)==='esgotada' && $estado($locked)==='esgotada','ga4_futuro_argumentos_reserva_preservados');
$check(!wp_get_scheduled_event(F3Base_Ga4::CONTINUAR,[],$hora-3600) && wp_get_scheduled_event(F3Base_Ga4::CONTINUAR,[],$hora+800),'ga4_evento_vencido_e_futuro');
$check((F3Base_Options::ler(F3Base_Ga4::STATE)['continuacoes_cobertas_ate']??0)===$hora,'ga4_corte_persistido');
$email=$intencao('email_historico',F3Base_Email_Historico::HOOK,$hora-2500);
wp_schedule_single_event($hora-2500,F3Base_Email_Historico::HOOK);
$check(F3Base_Email_Historico::processar()['codigo']==='nao_aplicavel','email_sem_chamada_remota');
F3Base_Email_Historico::conferir_agenda_1();
$check(!wp_next_scheduled(F3Base_Email_Historico::HOOK) && $estado($email)==='concluida','email_encerra_pendencia_antiga');
$enable=static fn($v)=>['ativo'=>true]+(is_array($v)?$v:[]);
foreach (['f3base_pipedrive',F3Base_Pipedrive_Operacao::OPTION] as $n) {update_option($n,$enable(get_option($n)));}
$check(F3Base_Email_Historico::aplicavel(),'email_volta_a_ser_aplicavel');
F3Base_Email_Historico::conferir_agenda_1();
$check((bool)wp_next_scheduled(F3Base_Email_Historico::HOOK),'email_volta_a_agendar');
update_option(F3Base_Pipedrive_Operacao::OPTION,['ativo'=>false]);
$check(!F3Base_Email_Historico::aplicavel(),'operacao_desligada_com_crm_ligado');
$d=F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/RELEASE-1.86.0.md','limite'=>3]);
$hash=$d['sha256'];$paginas=1;
while ($d['proxima_linha']) {$d=F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/RELEASE-1.86.0.md','linha'=>$d['proxima_linha'],'limite'=>3]);if ($hash!==$d['sha256']) {throw new RuntimeException('Troca de documento');}++$paginas;}
$check($paginas>1 && $hash===hash_file('sha256',F3BASE_PLUGIN_DIR.'docs/RELEASE-1.86.0.md'),'documentacao_integral');
wp_set_current_user(0);
$check(!F3Base_Configuracao_Atual::documentacao([])['ok'],'permissao_documental');
echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'versao'=>F3BASE_PLUGIN_VERSAO,'verificacoes'=>$checks],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
