"""Auditoria independente do gerador. Aceita também um CSV anterior para controle negativo."""
import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / 'reference/417'


def rows(path, encoding='utf-8-sig'):
    with path.open(encoding=encoding, newline='') as stream:
        yield from csv.DictReader(stream)


def norm(name):
    return ' '.join(name.lower().split())


def retail(name):
    return re.sub(r'(moto [ge])\((\d+[a-z]?)\)', r'\1\2', name)


def audit(path):
    # Oracle independente: a identidade é o par (marca Google, Device).
    play = defaultdict(list)
    for entry in rows(REF / 'supported_devices.csv', 'utf-16'):
        label = norm(entry['Marketing Name'])
        if label:
            play[norm(entry['Model'])].append((label, (norm(entry['Retail Branding']), norm(entry['Device']))))
    aliases = {(norm(r['codigo']), norm(r['nome_editorial'])): norm(r['nome_google'])
               for r in rows(REF / 'nomes-editoriais.csv')}
    errors, ambiguous, own_count, total, unresolved = [], 0, 0, 0, {}
    for row in rows(path):
        total += 1
        code, name = norm(row['codigo']), norm(row['nome_comercial'])
        entries = play[code]
        labels = {label for label, _ in entries}
        ambiguous += len(labels) > 1
        anchors = {pair for label, pair in entries if label == code and pair[1]}
        if not anchors:
            if len(labels) > 1:
                unresolved[code] = name
            continue
        own_count += 1
        if name in labels:
            targets = {pair for label, pair in entries if label == name}
        else:
            printed = retail(aliases.get((code, name), name))
            targets = {pair for label, pair in entries if retail(label) == printed}
        if not anchors.intersection(targets):
            errors.append(row['codigo'])
    return dict(codigos=total, ambiguos=ambiguous, com_linha_propria=own_count,
                sem_linha_propria=len(unresolved), erros=errors), unresolved


def verify_patch():
    baseline = {r['codigo']: r for r in rows(ROOT / 'reference/415/catalogo-aparelhos.csv')}
    current = {r['codigo']: r for r in rows(REF / 'catalogo-aparelhos.csv')}
    approved = {r['codigo']: {k: r[k] for k in next(iter(current.values()))}
                for r in rows(REF / 'fichas-pesquisadas.csv')}
    if len(approved) != 12 or len(current) != 1349 or set(baseline) - set(current):
        raise ValueError('Inventário diferente do esperado no pedido 417.')
    changed = {k for k, r in current.items() if r != baseline.get(k)}
    if changed != set(approved) or any(current[k] != r for k, r in approved.items()):
        raise ValueError('Delta diferente das 12 fichas aprovadas.')
    prior, _ = audit(ROOT / 'reference/415/catalogo-aparelhos.csv')
    if set(prior['erros']) != changed & set(baseline) or len(prior['erros']) != 11:
        raise ValueError('O controle negativo deve identificar exatamente os 11 erros na base anterior.')
    return prior


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('catalogo', nargs='?', type=Path)
    args = parser.parse_args()
    result, unresolved = audit(args.catalogo or REF / 'catalogo-aparelhos.csv')
    if not args.catalogo:
        prior = verify_patch()
        logged = {norm(r['codigo']): norm(r['nome_mantido'])
                  for r in rows(REF / 'ambiguidades-sem-linha-propria.csv')}
        if logged != unresolved:
            raise ValueError('A lista de ambiguidades diverge da auditoria do Google Play.')
        result['erros_reproduzidos_na_1_89_1'] = prior['erros']
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(bool(result['erros']))
