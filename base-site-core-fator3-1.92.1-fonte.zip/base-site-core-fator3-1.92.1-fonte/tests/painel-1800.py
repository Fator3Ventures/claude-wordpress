"""Valida o painel nativo em instalações descartáveis, exclusivamente em loopback."""
import argparse
import json
import secrets
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('base')
p.add_argument('senha', type=Path)
p.add_argument('saida', type=Path)
p.add_argument('--chromium')
a = p.parse_args()
if urlparse(a.base).hostname != '127.0.0.1':
    p.error('Use o laboratório local.')
checks = {}
def check(name, result):
    checks[name] = bool(result)
    if not result:
        raise AssertionError(name)

with sync_playwright() as api:
    browser = api.chromium.launch(executable_path=a.chromium, args=['--no-sandbox'])
    context = browser.new_context(viewport={'width':1440,'height':900})
    first, second = context.new_page(), context.new_page()
    for tab in (first, second):
        tab.on('dialog', lambda d: d.accept())
        tab.set_default_timeout(11000)
    first.goto(a.base+'/wp-login.php')
    first.locator('#user_login').fill('qa_admin')
    first.locator('#user_pass').fill(a.senha.read_text().strip())
    first.locator('#wp-submit').click()
    url = a.base+'/wp-admin/admin.php?page=base-site-core-fator3&secao='
    def open_seo(tab):
        tab.goto(url+'seo')
        tab.locator('form.f3base-form').wait_for()
    def field(tab, platform):
        return tab.locator(f'[name="f3base[f3base_verificacao_{platform}]"]')
    def save(tab):
        with tab.expect_navigation(wait_until='domcontentloaded'):
            tab.locator('.f3base-form .f3base-savebar [type=submit]').click()
    # Ambas recebem a mesma revisão, antes da primeira gravação.
    open_seo(first)
    open_seo(second)
    tokens = [secrets.token_hex(16) for _ in range(4)]
    field(first,'google').fill(tokens[0]); save(first)
    field(second,'meta').fill(tokens[1]); save(second)
    open_seo(first)
    check('opcoes_distintas_persistidas', field(first,'google').input_value()==tokens[0] and field(first,'meta').input_value()==tokens[1])
    open_seo(second)
    field(first,'google').fill(tokens[2]); save(first)
    field(second,'google').fill(tokens[3]); save(second)
    check('conflito_com_mensagem', 'reaplique sua edição' in second.locator('.wrap').first.inner_text())
    open_seo(first)
    check('conflito_preserva_primeiro_valor',field(first,'google').input_value()==tokens[2])
    errors=[]
    second.on('pageerror',lambda error:errors.append(str(error)))
    second.set_viewport_size({'width':390, 'height':844})
    second.goto(url+'contato#%ZZ')
    check('fragmento_invalido_ignorado',not errors)
    check('sem_overflow_390',second.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    check('botao_visivel_na_janela',second.locator('.f3base-savebar [type=submit]').evaluate('e=>e.getBoundingClientRect().bottom<=innerHeight && e.getBoundingClientRect().top>=0'))
    check('indice_recolhido_no_celular',not second.locator('[data-f3base-indice-caixa]').evaluate('e=>e.open'))
    policy=second.locator('[name="f3base[f3base_contato][historico_sem_decisao]"]')
    initial=policy.input_value()
    other={'permitir':'negar','negar':'permitir'}[initial]
    policy.select_option(other); save(second)
    second.goto(url+'contato')
    check('historico_leitura_apos_troca',policy.input_value()==other)
    policy.select_option(initial); save(second)
    second.goto(url+'contato')
    check('historico_leitura_apos_restaurar',policy.input_value()==initial)
    second.set_viewport_size({'width':1440,'height':900})
    check('indice_aberto_desktop',second.locator('[data-f3base-indice-caixa]').evaluate('e=>e.open'))
    check('sem_excecoes_javascript',not errors)
    browser.close()
a.saida.write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(f'{len(checks)} verificações do painel aprovadas')
