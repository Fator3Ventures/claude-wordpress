<?php
require __DIR__.'/bootstrap.php';
$nome = 'f3base_meta_capi_token';
$raw = get_option($nome, '');
check(is_string($raw) && str_starts_with($raw, F3Base_Segredos::PREFIXO), 'token_da_tela_cifrado_no_banco');
check(hash_equals('EAAU'.str_repeat('b',194), F3Base_Segredos::abrir($nome,$raw)), 'token_do_resultado_parcial_relido_em_outro_processo');
check(F3Base_Meta_Transporte::config()['modo']==='ambos','transporte_da_tela_relido_no_banco');
check(F3Base_Options::ler(F3Base_Meta_Lead::OPTION)===array('modo'=>'agente','formularios'=>array()),'grupo_invalido_nao_sobrescreveu_o_valor');
evidence('persistencia-admin-meta');
