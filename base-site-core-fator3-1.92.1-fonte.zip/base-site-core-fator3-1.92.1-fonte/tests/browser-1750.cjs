/** Exercise the shipped listeners and gated Meta sender with a local DOM and a recording fbq. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),vm=require('node:vm');
const {JSDOM}=require(process.env.F3BASE_JSDOM||'./dom/node_modules/jsdom');
const acorn=require(process.env.F3BASE_ACORN||'../build/node/node_modules/acorn');
const root=path.resolve(__dirname,'..'),assets=path.join(root,'work/plugin/base-site-core-fator3/assets');
const read=name=>fs.readFileSync(path.join(assets,name),'utf8');
function functions(file,names){
  const source=read(file),tree=acorn.parse(source,{ecmaVersion:'latest'}),output=new Map();
  function walk(node){if(!node||typeof node!=='object')return;
    if(node.type==='FunctionDeclaration'&&names.includes(node.id.name)){output.set(node.id.name,source.slice(node.start,node.end));}
    for(const child of Object.values(node)){if(Array.isArray(child))child.forEach(walk);else if(child&&typeof child==='object')walk(child);}
  }
  walk(tree);assert.equal(output.size,names.length);return names.map(n=>output.get(n)).join('\n');
}
const checks={};function check(name,value){assert(value,name);checks[name]=true;}
(async()=>{
const dom=new JSDOM('<body><section class="f3base-secao-socios"><h2 data-f3base-alvo="equipe">Nome confidencial</h2><h2>Texto privado</h2><button>Continuar</button></section></body>',{url:'https://fixture.test/'});
const w=dom.window,document=w.document,ids=new Set(),events=[],matching=[];
w.fbq=(op,a,b,c)=>{if(op==='init'){ids.add(a);if(b)matching.push(a);}if(op==='track'){for(const pixel of ids)events.push({pixel,event:a,id:c.eventID});}};
const ctx={window:w,document,navigator:w.navigator,CustomEvent:w.CustomEvent,contexto:{pronto:()=>true},context:{pronto:()=>true,teste:()=>false},destinoPermitido:()=>true,prontoDestino:()=>true,inserir:()=>{},destinos:{},sorteado:()=>'pv1750',testeAtual:()=>false,permiteTags:()=>true,dados:{meta:{modo:'navegador',pixelId:'111',pixelsAdicionais:['222'],autoConfig:false}},metaEvento:'Lead',material:false,teste:false,id:'lead1750',carga:{meta_correspondencia:{em:'a'.repeat(64)}}};
ctx.META=ctx.dados.meta;w.f3baseConsentimento={permiteCategoria:()=>true};
vm.createContext(ctx);vm.runInContext(functions('f3base-tracking.js',['metaPaginaPermitida','carregarMeta']),ctx);
vm.runInContext(functions('f3base-leads.js',['metaEnviar']),ctx);ctx.carregarMeta();ctx.carregarMeta();ctx.metaEnviar();
check('dois_pixels_mesmo_pageview_e_lead',events.length===4&&['111','222'].every(pixel=>events.some(e=>e.pixel===pixel&&e.id==='pv1750')&&events.some(e=>e.pixel===pixel&&e.id==='lead1750')));
check('matching_em_cada_pixel',matching.join(',')==='111,222');
ctx.teste=true;ctx.metaEnviar();check('teste_suprime_lead',events.length===4);
const captured=[];Object.assign(ctx,{COMPORTAMENTO:{prefixoSecao:'f3base-secao-'},declaracao:()=>true,numeroDoLimiar:()=>1,emitir:(t,items)=>captured.push(Array.from(items))});
vm.runInContext(functions('f3base-tracking.js',['detalheDe','nomePorPrefixo','alvoDeClique','instrumentarCliqueInerte']),ctx);ctx.instrumentarCliqueInerte();
const headings=document.querySelectorAll('h2');headings[0].click();headings[0].click();headings[1].click();document.querySelector('button').click();
await new Promise(r=>setTimeout(r,25));check('dedupe_e_exclusao_interativa',captured.length===2);
check('alvo_declarado_e_fallback',captured[0].join('/')==='socios/equipe'&&captured[1].join('/')==='socios/socios:titulo:2');
check('sem_texto_no_evento',!JSON.stringify(captured).includes('privado'));
const section=document.querySelector('section');
for(let i=0;i<8;i++){const mark=document.createElement('p');mark.textContent='Texto sintético '+i;section.appendChild(mark);mark.click();}
await new Promise(r=>setTimeout(r,25));
check('dez_toques_com_alvos_tecnicos',captured.length===10&&new Set(captured.map(row=>row.join('/'))).size===10&&captured.every(row=>row[0]==='socios'));
const fd=new JSDOM('<form data-f3base-formulario="qa" data-abandono="1" data-abandono-medicao="1" data-tentativas-valores="0" data-endpoint="/wp-json/f3/"><input name="submissao" type="hidden"><input name="token" type="hidden"><input name="campos[nome]"><input type="email" name="campos[email]"><input type="password" name="campos[senha]"><input type="file" name="campos[arquivo]"></form>',{url:'https://fixture.test/',runScripts:'outside-only'});
const page=fd.window,form=page.document.querySelector('form'),sent=[],beacons=[];let consent=true;
page.TextEncoder=TextEncoder;page.Blob=Blob;page.AbortController=AbortController;
page.f3baseConsentimento={permiteCategoria:()=>consent};page.navigator.sendBeacon=(url,b)=>{beacons.push(b);return true;};
page.fetch=async(url,opt)=>{if(String(url).endsWith('/token')){return new Response(JSON.stringify({ok:true,token:Buffer.from(JSON.stringify({t:Math.floor(Date.now()/1000)})).toString('base64')+'.fixture'}));}
sent.push(JSON.parse(opt.body));return new Response('{"ok":true}');};
page.eval(read('f3base-formularios.min.js'));const nome=form.elements.namedItem('campos[nome]'),email=form.elements.namedItem('campos[email]');
function ev(el,type){el.dispatchEvent(new page.Event(type,{bubbles:true}));}
nome.value='Nome QA';ev(nome,'input');await new Promise(r=>setTimeout(r,25));check('nenhum_envio_por_tecla',sent.length===0);
ev(nome,'focusout');await new Promise(r=>setTimeout(r,25));
email.value='teste@example.test';ev(email,'input');ev(email,'focusout');await new Promise(r=>setTimeout(r,25));
email.value='';ev(email,'input');page.dispatchEvent(new page.Event('pagehide'));await new Promise(r=>setTimeout(r,25));
const last=JSON.parse(await beacons.at(-1).text());
check('blur_e_beacon_com_apagamento',sent.length===2&&last.campos.some(c=>c.nome==='email'&&c.valor==='')&&last.campos.some(c=>c.nome==='nome'&&c.valor==='Nome QA'));
check('senha_e_arquivo_ausentes',last.campos.every(c=>!['senha','arquivo'].includes(c.nome)));
consent=false;ev(nome,'input');ev(nome,'focusout');page.dispatchEvent(new page.Event('pagehide'));check('consentimento_revogado_bloqueia',beacons.length===1&&sent.length===2);
dom.window.close();fd.window.close();fs.writeFileSync(path.join(root,'evidence/1750/dom.json'),JSON.stringify({ambiente:'jsdom; fornecedores instrumentados',checks},null,2));console.log(Object.keys(checks).length+' verificações DOM');
})().catch(e=>{console.error(e);process.exit(1);});
