<?php
require __DIR__.'/bootstrap-1840.php';
$prefixo = static fn($url) => rtrim($url,'/').'/portal';
add_filter('option_home', $prefixo, 100);
$url = home_url('/contato/');
$referer = $url.'?utm_source=teste';
$origem = static fn($referer) => F3Base_Formularios::origem_da_pagina(0, $referer);
check($origem($referer) === [$url,$referer], 'referer_subpasta_uma_vez_e_atribuicao_separada');
check($origem(home_url('/')) === [home_url('/'),home_url('/')], 'home_com_barra');
foreach (['https://example.org/portal/a', str_replace('/portal/', '/vizinho/', $url), $url.'<tag>', $url.chr(92).'b',home_url('/../externo'),home_url('/%2e%2e/externo'),home_url('/x%2F..%2Ffora'),home_url('/x%5Cfora'),home_url('/x%00y')] as $i=>$ruim) {
    check($origem($ruim) === ['',''], 'recusa_referer_'.$i);
}
$valido=home_url('/guia%2Ehtml');
check($origem($valido)===[$valido,$valido],'preserva_ponto_codificado_em_slug');
$id=wp_insert_post(['post_status'=>'publish','post_type'=>'page','post_title'=>'Contato da equipe']);
$GLOBALS['post']=get_post($id);
check($origem('')===['',''],'token_sem_id_nao_herda_post_global');
$pagina=get_permalink($id);
check(F3Base_Formularios::origem_da_pagina($id,'https://example.org')===[$pagina,$pagina],'token_publicado_tem_precedencia');
remove_filter('option_home',$prefixo,100);
$config=wp_get_ability('f3base/config-core-escrever');
check(($config->get_meta()['annotations']['readonly']??null)===false,'escrita_explicita');
wp_set_current_user(0);check(is_wp_error($config->execute([])),'visitante_recusado');wp_set_current_user(1);
$leituras = 0;
$contar = static function($valor) use (&$leituras) { ++$leituras; return $valor; };
add_filter('pre_option_f3base_pos_atualizacao', $contar);
update_option('qa180_opcao_externa', wp_generate_uuid4());
remove_filter('pre_option_f3base_pos_atualizacao', $contar);
check($leituras === 0, 'gravar_opcao_alheia_nao_executa_diagnostico_pos_atualizacao');
evidence('correcoes-1840');
