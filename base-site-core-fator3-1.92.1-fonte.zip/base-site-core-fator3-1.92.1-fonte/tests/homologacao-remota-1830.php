<?php
/** MU-plugin temporário do Site-Teste. Não integra o instalador. */
defined('ABSPATH') || exit;
add_action('wp_abilities_api_init', static function () {
    wp_register_ability('f3qa/core-1830', [
        'label'=>'Prova de aparelho e cache do Core 1.83.0',
        'description'=>'Executa fixtures em transação, sem despacho para serviços externos.',
        'category'=>'site','input_schema'=>['type'=>'object','properties'=>['caso'=>['type'=>'string','enum'=>['aparelho']]],'additionalProperties'=>false],
        'output_schema'=>['type'=>'object','additionalProperties'=>true],
        'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'show_in_rest'=>false],
        'permission_callback'=>static fn()=>current_user_can('manage_options') && current_user_can('f3base_ler_leads')
            && F3BASE_PLUGIN_VERSAO==='1.83.0' && wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com',
        'execute_callback'=>static function () {
            global $wpdb,$wpsc_tracking_parameters;
            $checks=[]; $check=static function ($ok,$label)use(&$checks){$checks[$label]=(bool)$ok;if(!$ok){throw new RuntimeException($label);}};
            $old=$wpsc_tracking_parameters;
            $ref=['classe'=>'teste','sessao'=>bin2hex(random_bytes(16)),'visitante'=>bin2hex(random_bytes(16))];
            $id=bin2hex(random_bytes(16));$now=time();$error='';
            $user=get_current_user_id();
            if ($wpdb->query('START TRANSACTION')===false) {return ['ok'=>false,'codigo'=>'transacao_indisponivel'];}
            try {
                $all=F3Base_Cache_Pagina::parametros_rastreio();
                $check(count($all)===47 && !in_array('ref',$all,true),'47_nomes_ref_funcional');
                $missing=['utm_creative_format','utm_marketing_tactic','gad_source','gad_campaignid','msclkid','ttclid','twclid','epik','rdt_cid','dclid','igshid','_gl'];
                $wpsc_tracking_parameters=array_diff($old,$missing);
                $before=F3Base_Cache_Pagina::requisitos();
                $check($before['status']==='failed' && !array_diff($missing,$before['rastreamento']['faltantes']),'config_antiga_falha_com_os_12');
                $wpsc_tracking_parameters=$old;
                $after=F3Base_Cache_Pagina::requisitos();
                $check($after['status']==='verified'&&!$after['rastreamento']['faltantes'],'config_em_uso_verificada');
                $sample=['modelo'=>'SM-A065M','versao_sistema'=>'14','memoria_gb'=>4,'nucleos'=>8,'largura'=>390,'altura'=>844,'dpr'=>3,'rede'=>'4g'];
                $android=F3Base_Perfil_Aparelho::normalizar($sample,'Android',['SM-A065M=entrada']);
                $iphone=F3Base_Perfil_Aparelho::normalizar($sample,'iPhone OS 18_2',[]);
                $check($iphone['modelo']==='' && $iphone['faixa_fonte']==='estimativa_tela_iphone','iphone_sem_modelo_estimado');
                $check(F3Base_Perfil_Aparelho::gravar($ref['classe'],$ref['sessao'],$ref['visitante'],$now,$android),'primeira_observacao');
                $check(F3Base_Perfil_Aparelho::gravar($ref['classe'],$ref['sessao'],$ref['visitante'],$now,$iphone) && F3Base_Perfil_Aparelho::ler($ref)===$android,'primeira_observacao_preservada');
                wp_set_current_user(0);
                $at=F3Base_Atribuicao::parametros_pagina(home_url('/?gad_campaignid=24432229853&msclkid=qa397'));
                $d=F3Base_Leads_Contexto::capturar(['sessao'=>$ref['sessao'],'visitante'=>$ref['visitante'],'contexto_teste'=>true,'classificacao_contexto'=>'permitida','atribuicao'=>$at,'metodo'=>'formulario'],true);
                $d['atribuicao']=F3Base_Atribuicao::para_captura($at,true,true);
                $d['consentimento_snapshot']=['politica_versao'=>'legado:qa','medicao'=>true,'publicidade'=>true];
                $check($wpdb->insert(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id,'metodo'=>'formulario','classe_trafego'=>'teste','sessao'=>$ref['sessao'],'nome'=>'QA 396','criado_em'=>gmdate('Y-m-d H:i:s'),'atualizado_em'=>gmdate('Y-m-d H:i:s'),'pagina'=>'','dados'=>wp_json_encode($d),'anexos'=>'[]','payload_hash'=>hash('sha256',$id)])===1,'contato_sintetico_em_transacao');
                wp_set_current_user($user);
                $row=F3Base_Leads_Repositorio::obter($id);$record=F3Base_Leads_Admin::projetar_leitura($row);
                $check(($record['dados']['contexto']['perfil_aparelho']??[])===$android,'todos_os_campos_na_ficha');
                $check($row['dados']['atribuicao']['gad_campaignid']==='24432229853' && $row['dados']['atribuicao']['msclkid']==='qa397','campanha_e_clique_persistidos');
                $a=F3Base_Contato_Apresentacao::montar($row);
                $note=F3Base_Contato_Apresentacao::nota($a,'qa-1830');
                $check(str_contains($note,'SM-A065M') && str_contains($note,'390×844') && str_contains($note,'entrada'),'nota_gerada_do_registro');
                $check(str_contains(F3Base_Slack_Thread::com_perfil(['text'=>'Aviso','blocks'=>[]],F3Base_Perfil_Aparelho::apresentar($a))['text'],'SM-A065M'),'aviso_gerado_do_registro');
            } catch(Throwable $e) {$error=$e instanceof RuntimeException?$e->getMessage():get_class($e);}
            finally {$wpsc_tracking_parameters=$old;wp_set_current_user($user);$wpdb->query('ROLLBACK');}
            $checks['limpeza']=!F3Base_Leads_Repositorio::obter($id)&&!F3Base_Perfil_Aparelho::ler($ref);
            return ['ok'=>$error===''&&!in_array(false,$checks,true),'checks'=>$checks,'erro'=>$error,'versao'=>F3BASE_PLUGIN_VERSAO,'php'=>PHP_VERSION,'wordpress'=>get_bloginfo('version'),'envios_externos'=>0];
        },
    ]);
});
