"""Run reconstructed tests in a NEW disposable WordPress/MariaDB laboratory.

All services and tests are children of this process. No remote database or
existing WordPress configuration is accepted. Dependencies are external inputs.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, secrets, shutil, socket, subprocess, tarfile, time

ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--wordpress-archive',type=Path,required=True)
    p.add_argument('--lab',type=Path,required=True)
    p.add_argument('--php',default=os.environ.get('F3BASE_PHP','php'))
    p.add_argument('--mysqld',required=True)
    p.add_argument('--db-install',required=True)
    p.add_argument('--db-basedir',type=Path,required=True)
    p.add_argument('--db-library-dir',type=Path)
    args=p.parse_args();lab=args.lab.resolve()
    if lab.exists() and any(lab.iterdir()):raise RuntimeError('Use a new empty --lab directory')
    lab.mkdir(parents=True,exist_ok=True);(lab/'LOCAL_TEST_LAB').write_text('core1740 native tests\n')
    env=os.environ.copy();env['F3BASE_QA_PASSWORD']=secrets.token_urlsafe(32)
    if args.db_library_dir:env['LD_LIBRARY_PATH']=str(args.db_library_dir)+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    db=lab/'database';logs=lab/'logs';logs.mkdir()
    with (logs/'db-install.log').open('w') as out:
        subprocess.run([args.db_install,'--no-defaults','--basedir='+str(args.db_basedir),
            '--datadir='+str(db),'--auth-root-authentication-method=normal','--skip-test-db'],env=env,stdout=out,stderr=out,check=True)
    server=subprocess.Popen([args.mysqld,'--no-defaults','--basedir='+str(args.db_basedir),
        '--datadir='+str(db),'--socket=','--port='+str(port),'--bind-address=127.0.0.1',
        '--skip-name-resolve','--pid-file='+str(lab/'db.pid'),'--log-error='+str(logs/'db.log')],
        env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    results=[]
    def prepare(phase,runtime):
        site=lab/phase;site.mkdir()
        with tarfile.open(args.wordpress_archive) as archive:
            if any((not m.name.startswith('wordpress/') and not(m.name=='wordpress' and m.isdir())) or '..' in Path(m.name).parts for m in archive.getmembers()):raise RuntimeError('Unexpected WordPress archive layout')
            archive.extractall(site,filter='data')
        wp=site/'wordpress'
        text=(wp/'wp-includes/version.php').read_text()
        if not re.search(r"\$wp_version\s*=\s*'7\.1\.4'",text):raise RuntimeError('This reconstruction requires WordPress 7.1.4')
        dest=wp/'wp-content/plugins/base-site-core-fator3';shutil.copytree(runtime,dest)
        mu=wp/'wp-content/mu-plugins';mu.mkdir(exist_ok=True)
        (mu/'000-qa-no-network.php').write_text("<?php\nadd_filter('pre_http_request',static fn()=>new WP_Error('qa_network_blocked','Local test'),PHP_INT_MAX);\nadd_filter('pre_wp_mail',static fn()=>true,PHP_INT_MAX);\n")
        theme=wp/'wp-content/themes/core-qa';theme.mkdir()
        (theme/'style.css').write_text('/*\nTheme Name: Core QA\nVersion: 1.0\n*/\n')
        (theme/'index.php').write_text('<?php wp_head(); ?><main>Core QA</main><?php wp_footer(); ?>')
        name='core_1740_'+phase
        cfg="<?php\n"+''.join("define("+repr(k)+","+repr(v)+");\n" for k,v in {
            'DB_NAME':name,'DB_USER':'root','DB_PASSWORD':'','DB_HOST':'127.0.0.1:'+str(port),
            'DB_CHARSET':'utf8mb4','DB_COLLATE':'','WP_ENVIRONMENT_TYPE':'local',
            'WP_HOME':'http://127.0.0.1:8137','WP_SITEURL':'http://127.0.0.1:8137','FS_METHOD':'direct'}.items())
        cfg+="$table_prefix='wp_';define('DISABLE_WP_CRON',true);define('WP_DEBUG',true);define('WP_DEBUG_DISPLAY',false);define('WP_DEBUG_LOG',true);\n"
        for k in ('AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'):cfg+=f"define('{k}','{secrets.token_hex(32)}');\n"
        cfg+="if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';\n"
        (wp/'wp-config.php').write_text(cfg);(wp/'wp-config.php').chmod(0o600)
        return wp,name
    def run(wp,name,script,*modes):
        e=env.copy();e.update(F3BASE_ALLOW_LOCAL_TESTS='1',F3BASE_SITE=str(wp/'wp-load.php'),
            F3BASE_PHP=args.php,F3BASE_LAB_DB=name,F3BASE_DB_HOST='127.0.0.1:'+str(port),F3BASE_TEST_PHASE=wp.parent.name)
        r=subprocess.run([args.php,str(ROOT/'tests'/script),*modes],env=e,capture_output=True,text=True,timeout=120)
        item={'phase':wp.parent.name,'test':script,'mode':list(modes),'exit_code':r.returncode,'stdout':r.stdout.strip()}
        results.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
        if r.returncode:raise RuntimeError(r.stderr[-4000:])
    try:
        for _ in range(150):
            if server.poll() is not None:raise RuntimeError('Database exited; inspect local log')
            try:
                with socket.create_connection(('127.0.0.1',port),timeout=.2):break
            except OSError:time.sleep(.1)
        else:raise RuntimeError('Database startup timeout')
        wp,name=prepare('fresh',ROOT/'work/plugin/base-site-core-fator3')
        run(wp,name,'ciclo-1721.php','install')
        run(wp,name,'meta-1740-acesso.php')
        # Start the normal wp-admin entry point, using the disposable administrator.
        with (logs/'php-web.log').open('w') as log:
            web=subprocess.Popen([args.php,'-S','127.0.0.1:8137','-t',str(wp)],env=env,stdout=log,stderr=log)
            try:
                import sys
                for _ in range(100):
                    if web.poll() is not None:raise RuntimeError('Could not bind the local QA web server')
                    try:
                        with socket.create_connection(('127.0.0.1',8137),timeout=.2):break
                    except OSError:time.sleep(.1)
                subprocess.run([sys.executable,str(ROOT/'tests/meta-1740-browser.py')],env=env,check=True,timeout=150)
                run(wp,name,'meta-1740-persistencia.php');run(wp,name,'meta-1740-guardas.php')
            finally:
                web.terminate();web.wait(timeout=10)
        run(wp,name,'medicao-1710-relatorio.php');run(wp,name,'painel-1721.php')
        wp,name=prepare('upgrade',ROOT/'history/1.73.0-runtime/base-site-core-fator3')
        run(wp,name,'ciclo-1721.php','install');run(wp,name,'ciclo-1721.php','seed');run(wp,name,'painel-1721.php')
        dest=wp/'wp-content/plugins/base-site-core-fator3';shutil.rmtree(dest)
        shutil.copytree(ROOT/'work/plugin/base-site-core-fator3',dest)
        run(wp,name,'ciclo-1721.php','migrate');run(wp,name,'painel-1721.php');run(wp,name,'pedidos-1730.php')
        run(wp,name,'ciclo-1721.php','uninstall');run(wp,name,'ciclo-1721.php','reactivate')
        report={'provenance':'release-1.74.0-2026-11-07','wordpress_archive_sha256':hashlib.sha256(args.wordpress_archive.read_bytes()).hexdigest(),
            'runs':results,'all_passed':True,'providers':'HTTP and mail blocked by local MU fixture',
            'mysql_compatibility':'MariaDB result; not a claim of MySQL 8.4 execution'}
        (ROOT/'evidence/1740/native-run.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    finally:
        server.terminate()
        try:server.wait(timeout=20)
        except subprocess.TimeoutExpired:server.kill();server.wait()

if __name__=='__main__':main()
