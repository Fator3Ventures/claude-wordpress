<?php
/**
 * Instalação pelo mecanismo nativo do WordPress, a partir do ZIP instalador final, num laboratório descartável.
 *
 * A suíte principal troca o runtime copiando arquivos. Este ensaio cobre o que ela não cobre: o ZIP entregue
 * passando por Plugin_Upgrader (descompactação, troca do diretório do plugin) e, num PROCESSO NOVO, a
 * conferência da versão efetiva, da conclusão do ciclo de atualização e dos bytes instalados.
 *
 * Uso (cada modo num processo próprio):
 *   F3BASE_SITE=/lab/wordpress/wp-load.php F3BASE_HOST=127.0.0.1:<porta> php tests/instalacao-nativa-1830.php instalar /caminho/instalador.zip
 *   F3BASE_SITE=... F3BASE_HOST=... php tests/instalacao-nativa-1830.php conferir <versao-esperada> <versao-de-origem|limpa> [evidencia.json]
 * Só roda em WordPress local (wp_get_environment_type() === 'local') com banco core_*.
 */
declare(strict_types=1);

$site = getenv('F3BASE_SITE');
if (!$site || !is_file($site)) { fwrite(STDERR, "F3BASE_SITE ausente\n"); exit(2); }
$_SERVER['HTTP_HOST'] = getenv('F3BASE_HOST') ?: '127.0.0.1:8137';
$_SERVER['REQUEST_METHOD'] = 'GET';
require $site;
if (wp_get_environment_type() !== 'local' || !preg_match('/^core_[a-z0-9_]+$/D', DB_NAME)) { fwrite(STDERR, "Somente laboratório local\n"); exit(2); }
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/misc.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
wp_set_current_user(1);

const F3BASE_BASENAME = 'base-site-core-fator3/base-site-core-fator3.php';
$modo = $argv[1] ?? '';
$json = static fn(array $d): string => json_encode($d, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";

if ($modo === 'instalar') {
    $zip = $argv[2] ?? '';
    if (!is_file($zip)) { fwrite(STDERR, "ZIP ausente\n"); exit(2); }
    $antes = defined('F3BASE_PLUGIN_VERSAO') ? F3BASE_PLUGIN_VERSAO : null;
    $ativo_antes = is_plugin_active(F3BASE_BASENAME);
    // O upgrader apaga o pacote depois de instalar: trabalha numa cópia para preservar o artefato entregue.
    $copia = get_temp_dir() . 'f3base-instalador-' . bin2hex(random_bytes(6)) . '.zip';
    copy($zip, $copia);
    $upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
    $r = $upgrader->install($copia, array('overwrite_package' => true));
    if (is_file($copia)) { unlink($copia); }
    $erro = is_wp_error($r) ? $r->get_error_message() : (is_wp_error($upgrader->skin->result ?? null) ? $upgrader->skin->result->get_error_message() : null);
    $ok = true === $r && null === $erro;
    $ativacao = null;
    if ($ok && !$ativo_antes) {
        $a = activate_plugin(F3BASE_BASENAME);
        $ativacao = is_wp_error($a) ? $a->get_error_message() : 'ativado';
        $ok = !is_wp_error($a);
    }
    echo $json(array('modo' => 'instalar', 'ok' => $ok, 'erro' => $erro, 'versao_carregada_antes' => $antes, 'ativo_antes' => $ativo_antes, 'ativacao' => $ativacao, 'sha256_do_zip' => hash_file('sha256', $zip), 'bytes_do_zip' => filesize($zip)));
    exit($ok ? 0 : 1);
}

if ($modo === 'conferir') {
    $esperada = $argv[2] ?? ''; $origem = $argv[3] ?? ''; $saida = $argv[4] ?? '';
    $checks = array();
    $check = static function (bool $ok, string $nome, $detalhe = null) use (&$checks): void { $checks[$nome] = $ok ? true : array('falhou' => true, 'detalhe' => $detalhe); };
    $check(defined('F3BASE_PLUGIN_VERSAO') && F3BASE_PLUGIN_VERSAO === $esperada, 'versao_efetiva_em_processo_novo', defined('F3BASE_PLUGIN_VERSAO') ? F3BASE_PLUGIN_VERSAO : 'plugin não carregado');
    $check(is_plugin_active(F3BASE_BASENAME), 'plugin_ativo');
    $ciclo = null;
    if (class_exists('F3Base_Instalacao')) {
        for ($i = 0; $i < 30; $i++) { $ciclo = F3Base_Instalacao::atualizar(); if (!empty($ciclo['ok']) && F3Base_Instalacao::origem() === 'atual') { break; } }
        $check(F3Base_Instalacao::origem() === 'atual', 'ciclo_de_atualizacao_concluido', $ciclo);
    }
    // Bytes instalados contra o manifesto do runtime da rodada.
    $manifesto = json_decode((string) file_get_contents(dirname(__DIR__) . '/evidence/1830/runtime-manifest.json'), true);
    $esperados = array(); foreach ($manifesto as $m) { $esperados[$m['name']] = $m['sha256']; }
    $dir = WP_PLUGIN_DIR . '/base-site-core-fator3'; $instalados = array();
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) { if ($f->isFile()) { $instalados['base-site-core-fator3/' . substr($f->getPathname(), strlen($dir) + 1)] = hash_file('sha256', $f->getPathname()); } }
    $faltam = array_diff_key($esperados, $instalados); $sobram = array_diff_key($instalados, $esperados);
    $diferem = array(); foreach (array_intersect_key($instalados, $esperados) as $n => $h) { if ($h !== $esperados[$n]) { $diferem[] = $n; } }
    $check(!$faltam && !$sobram && !$diferem, 'arquivos_instalados_iguais_ao_manifesto', array('faltam' => array_slice(array_keys($faltam), 0, 5), 'sobram' => array_slice(array_keys($sobram), 0, 5), 'diferem' => array_slice($diferem, 0, 5)));
    // Funções próprias respondem na versão nova.
    $doc = class_exists('F3Base_Configuracao_Atual') ? F3Base_Configuracao_Atual::documentacao(array()) : array();
    $check(($doc['versao'] ?? '') === $esperada && in_array('docs/RELEASE-' . $esperada . '.md', $doc['arquivos'] ?? array(), true), 'documentacao_instalada_e_da_versao_nova', $doc['versao'] ?? null);
    $abilities = array_filter(array_keys(function_exists('wp_get_abilities') ? wp_get_abilities() : array()), static fn($n) => str_starts_with((string) $n, 'f3base/'));
    $check(count($abilities) > 0, 'abilities_registradas', count($abilities));
    global $wpdb;
    $r = array('ensaio' => 'tests/instalacao-nativa-1830.php', 'origem' => $origem, 'versao_esperada' => $esperada, 'versao_efetiva' => defined('F3BASE_PLUGIN_VERSAO') ? F3BASE_PLUGIN_VERSAO : null,
        'php' => PHP_VERSION, 'wordpress' => get_bloginfo('version'), 'banco' => $wpdb->db_version(), 'arquivos_instalados' => count($instalados), 'arquivos_no_manifesto' => count($esperados),
        'abilities_f3base' => count($abilities), 'checks' => $checks, 'falhas' => count(array_filter($checks, static fn($c) => true !== $c)));
    if ($saida !== '') { file_put_contents($saida, $json($r)); }
    echo $json($r);
    exit($r['falhas'] ? 1 : 0);
}
fwrite(STDERR, "Modo desconhecido. Use instalar ou conferir.\n"); exit(2);
