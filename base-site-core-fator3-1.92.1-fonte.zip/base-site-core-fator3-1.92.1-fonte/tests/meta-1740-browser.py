"""Exercise the signed-in WordPress form in Chromium on the isolated loopback lab."""
import json
import os
import re
from pathlib import Path
from urllib.parse import parse_qsl
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
base = 'http://127.0.0.1:8137'
admin = base + '/wp-admin/admin.php?page=base-site-core-fator3&secao=medicao-meta'
checks = []
def check(condition, name):
    if not condition:
        raise AssertionError(name)
    checks.append(name)

def field(page, option, leaf=''):
    return page.locator('[name="f3base[' + option + ']' + ('[' + leaf + ']' if leaf else '') + '"]')

with sync_playwright() as driver:
    browser = driver.chromium.launch(executable_path=os.environ.get('F3BASE_CHROMIUM', '/usr/bin/chromium'), args=['--no-sandbox','--disable-dev-shm-usage'])
    page = browser.new_page()
    page.set_default_timeout(12000)
    page.on('dialog', lambda dialog: dialog.accept())
    page.goto(base + '/wp-login.php')
    page.locator('#user_login').fill('qa_admin')
    page.locator('#user_pass').fill(os.environ['F3BASE_QA_PASSWORD'])
    page.locator('#wp-submit').click()
    page.goto(admin)
    form = page.locator('form[data-f3base-meta-edicao]')
    lead = 'f3base_meta_lead'
    token = 'f3base_meta_capi_token'
    pixel = 'f3base_meta_capi_pixel_id'
    transport = 'f3base_meta_transporte'
    def save(names):
        with page.expect_request(lambda req: req.url.endswith('/wp-admin/admin-post.php') and req.method == 'POST') as request:
            with page.expect_navigation(wait_until='domcontentloaded'):
                form.locator('[type=submit]').click()
        submitted = {match[1] for key,_ in parse_qsl(request.value.post_data or '',keep_blank_values=True)
                     if (match := re.match(r'^f3base\[([^\]]+)\]',key))}
        check(submitted == set(names), 'POST contém somente ' + ', '.join(sorted(names)))
        check(page.locator('.f3base-leitura').count() == 1, 'Recibo do wp-admin para ' + ', '.join(names))
    check(field(page, lead,'modo').input_value() == 'imediato', 'Seleção inicial imediato')
    check(field(page, lead,'formularios').input_value() == '{}', 'Mapa vazio exibido como objeto')
    check(field(page, lead).count() == 0, 'Campo escalar removido')
    field(page, token).fill('EAAU'+'a'*194)
    save([token])
    check(page.locator('.f3base-leitura.notice-success').count() == 1, 'Token isolado gravado')
    check(field(page, token).input_value() == '' and ('EAAU'+'a'*194) not in page.content(), 'Segredo ausente na resposta')
    field(page,pixel).fill('12345678901234')
    save([pixel])
    field(page,transport,'modo').select_option('ambos')
    save([transport])
    page.goto(admin)
    check(field(page,transport,'modo').input_value() == 'ambos', 'Transporte isolado relido em nova requisição')
    field(page,lead,'modo').select_option('agente')
    editor = page.locator('#linha-f3base_meta_lead .f3base-structured')
    def add_mapping(key, mode):
        editor.locator('.f3base-map-add input').fill(key)
        editor.get_by_role('button',name='Adicionar mapeamento').click()
        editor.locator('.f3base-map-row').last.locator('select').select_option(mode)
    add_mapping('orcamento','imediato')
    add_mapping('f3base_rascunho_json','agente')
    save([lead])
    page.goto(admin)
    check(field(page,lead,'modo').input_value() == 'agente' and json.loads(field(page,lead,'formularios').input_value()) == {'orcamento':'imediato','f3base_rascunho_json':'agente'}, 'Mapa e modo persistidos')
    for _ in range(2): editor.get_by_role('button',name='Remover mapeamento').first.click()
    save([lead])
    page.goto(admin)
    check(json.loads(field(page,lead,'formularios').input_value()) == {}, 'Limpeza explícita do mapa persistida')
    add_mapping('id inválido','agente')
    field(page,token).fill('EAAU'+'b'*194)
    save([lead,token])
    check(page.locator('.f3base-erro-campo').count() > 0 and json.loads(field(page,lead,'formularios').input_value())=={'id inválido':'agente'}, 'Erro localizado e rascunho preservado')
    check(field(page,token).input_value() == '' and ('EAAU'+'b'*194) not in page.content(), 'Token rotacionado sem eco mesmo no resultado parcial')
    page.locator('[data-f3base-reaplicar]').check()
    save([lead])
    check(page.locator('.f3base-erro-campo').count() == 1, 'Reaplicação explícita valida o rascunho')
    field(page,pixel).fill('12345678901235')
    save([pixel])
    check(page.locator('.f3base-leitura.notice-success').count() == 1, 'Rascunho inalterado não é revalidado ao salvar outra opção')
    page.goto(admin)
    check(field(page,lead,'modo').input_value() == 'agente' and json.loads(field(page,lead,'formularios').input_value()) == {}, 'Grupo recusado preservou valor anterior')
    leitor = browser.new_page()
    leitor.goto(base + '/wp-login.php')
    leitor.locator('#user_login').fill('qa_leitor')
    leitor.locator('#user_pass').fill(os.environ['F3BASE_QA_PASSWORD'])
    leitor.locator('#wp-submit').click()
    resposta = leitor.goto(admin)
    check(resposta.status == 403 and leitor.locator('[data-f3base-meta-edicao]').count() == 0, 'WordPress recusa a tela Meta ao assinante')
    browser.close()
(ROOT/'evidence/1740/browser.json').write_text(json.dumps({'chromium':True,'ambiente':'WordPress 7.1.4 local','checks':checks},ensure_ascii=False,indent=2)+'\n')
print('Chromium:',len(checks),'checks OK')
