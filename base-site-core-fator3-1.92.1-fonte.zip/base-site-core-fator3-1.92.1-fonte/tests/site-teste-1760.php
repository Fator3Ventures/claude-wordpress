<?php
/** Bancada de vida curta para o Site-Teste. Requer anexar crm-1760.php ao mesmo arquivo na instalação. */
if(!defined('ABSPATH')){exit;}
add_action('wp_abilities_api_init', static function(){
    wp_register_ability('f3qa/core-1760',[
        'label'=>'Conferir prévia CRM 1.76.0','description'=>'Dois formulários nativos sintéticos em transação descartada. Sem envio comercial.',
        'category'=>'site','input_schema'=>['type'=>'object','additionalProperties'=>false,'properties'=>['caso'=>['type'=>'string','enum'=>['previa']]],'required'=>['caso']],
        'output_schema'=>['type'=>'object','additionalProperties'=>true],
        'permission_callback'=>static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads')&&wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com'&&defined('F3BASE_PLUGIN_VERSAO')&&F3BASE_PLUGIN_VERSAO==='1.76.0',
        'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'show_in_rest'=>false],
        'execute_callback'=>static function(){
            global $wpdb;
            try {
            $checks=f3qa1760_crm();$rows=[];$ids=[];
            if(false===$wpdb->query('START TRANSACTION')){throw new RuntimeException('Banco indisponível');}
            try{
                foreach(['permitido','negativo'] as $case){
                    $id=bin2hex(random_bytes(16));$ids[]=$id;
                    $payload=['id'=>$id,'form_id'=>'7001','is_test'=>true,'created_time'=>gmdate('c'),'field_data'=>[['name'=>'email','values'=>['qa@example.invalid']],['name'=>'ads','values'=>[$case==='negativo'?'nao':'sim']]]];
                    $cfg=['conta_id'=>'7000','formularios'=>['7001'],'mapeamento'=>['formularios'=>['7001'=>['publicidade'=>['campo'=>'ads','negativas'=>['nao']]]]]];
                    $form=F3Base_Anuncios::normalizar('meta',$payload,$cfg,'qa_local');
                    if(empty($form['ok'])){throw new RuntimeException('Falha na normalização');}
                    $d=$form['dados'];$stamp=gmdate('Y-m-d H:i:s',time()-5);
                    $count=$wpdb->insert(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id,'classe_trafego'=>'teste','metodo'=>$d['metodo'],'captura'=>'aceito','criado_em'=>$stamp,'atualizado_em'=>$stamp,'email'=>$d['email'],'pagina'=>'/','dados'=>wp_json_encode($d),'anexos'=>'[]','payload_hash'=>hash('sha256',$id)]);
                    if($count!==1){throw new RuntimeException('Falha ao gravar fixture');}
                    $r=F3Base_Qualidade_Destinos::previa(['record_id'=>$id,'etapa'=>'qualificado']);
                    $dest=$r['destinos']['linkedin']??[];
                    $rows[$case]=['codigo'=>$dest['codigo']??($r['codigo']??'ausente'),'elegivel'=>$dest['elegivel']??false,'envio_realizado'=>$r['envio_realizado']??null];
                    $checks['previa_'.$case]=($dest['codigo']??'')===($case==='negativo'?'consentimento_nao_permite':'elegivel')&&$r['envio_realizado']===false;
                }
            }finally{$wpdb->query('ROLLBACK');}
            foreach($ids as $id){if(F3Base_Leads_Repositorio::obter($id)){throw new RuntimeException('Fixture presente após descarte');}}
            return ['ok'=>!in_array(false,$checks,true),'core'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'checks'=>count($checks),'falhas'=>array_keys($checks,false,true),'previas'=>$rows,'registros_restantes'=>0,'adaptador'=>'fixture local de capacidades, falha se houver envio'];
            } catch(Throwable $failure){
                return ['ok'=>false,'classe'=>get_class($failure),'arquivo'=>basename($failure->getFile()),'linha'=>$failure->getLine(),'falha'=>in_array($failure->getMessage(),['Banco indisponível','Falha na normalização','Falha ao gravar fixture','Fixture presente após descarte'],true)?$failure->getMessage():'falha_na_bancada'];
            }
        }
    ]);
});
