<?php
/** Temporary Site-Teste fixture, excluded from the installer. */
if (!defined('ABSPATH')) { exit; }
const F3QA177_SLUG='homologacao-core-1770-9cb438e';
const F3QA177_USER='qa-core-1770-9cb438e';
function f3qa177_form(){
    return ['id'=>'qa-core-1770','titulo'=>'Homologação Core 1.77.0','ligado'=>true,'regime'=>'registro','botao'=>'Enviar etapa','destinatarios'=>[],'campos'=>[
      ['nome'=>'nome','tipo'=>'text','rotulo'=>'Nome','obrigatorio'=>true,'papel'=>'nome','etapa'=>1],
      ['nome'=>'email','tipo'=>'email','rotulo'=>'E-mail','obrigatorio'=>true,'papel'=>'email','etapa'=>1],
      ['nome'=>'mensagem','tipo'=>'textarea','rotulo'=>'Complemento','obrigatorio'=>false,'etapa'=>2]
    ]];
}
function f3qa177_markup(){
    return '<!-- wp:shortcode -->[f3base_formulario id="qa-core-1770"]<!-- /wp:shortcode -->

<!-- wp:group {"className":"f3base-secao-homologacao","layout":{"type":"constrained"}} -->
<div class="wp-block-group f3base-secao-homologacao"><!-- wp:group {"className":"f3base-alvo-teste-grupo","layout":{"type":"constrained"}} -->
<div class="wp-block-group f3base-alvo-teste-grupo"><!-- wp:paragraph -->
<p>Primeiro alvo da homologação</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:html -->
<p data-f3base-alvo="teste-atributo" class="f3base-alvo-ignorado f3base-alvo-segundo">Segundo alvo da homologação</p>
<a href="https://wa.me/5511999999999" target="_blank" rel="noopener" data-f3base-lead="qa-core-1770">Contato de homologação</a>
<!-- /wp:html --></div>
<!-- /wp:group -->';
}
function f3qa177_host(){return wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com';}
if (!f3qa177_host()){return;}
$scope=str_contains($_SERVER['REQUEST_URI']??'',F3QA177_SLUG)||str_contains($_SERVER['HTTP_REFERER']??'',F3QA177_SLUG)||($_SERVER['HTTP_X_F3QA_CICLO']??'')==='1770';
if ($scope){
 add_filter('option_f3base_config_publica',static function($cfg){$cfg['valores']['f3base_formularios'][]=f3qa177_form();return $cfg;});
 add_filter('option_f3base_formularios',static function($rows){$rows[] = f3qa177_form();return $rows;});
 add_filter('default_option_f3base_formularios',static fn()=>[f3qa177_form()]);
 add_filter('wp_robots',static fn($robots)=>['noindex'=>true,'nofollow'=>true]);
 add_filter('pre_wp_mail',static fn()=>true,PHP_INT_MAX);
 add_filter('option_f3base_contato',static function($cfg){$cfg['avisar_por_clique']=false;$cfg['avisar_por_formulario']=false;$cfg['email_leads']=[];return $cfg;});
}
add_action('wp_abilities_api_init',static function(){
 wp_register_ability('f3qa/core-1770',[
  'label'=>'Homologação Core 1.77.0','description'=>'Preparar ou limpar a página temporária e consultar somente registros sintéticos deste ciclo.',
  'category'=>'site','input_schema'=>['type'=>'object','additionalProperties'=>false,'properties'=>['caso'=>['type'=>'string','enum'=>['preparar','ler','limpar']]],'required'=>['caso']],
  'output_schema'=>['type'=>'object','additionalProperties'=>true],
  'permission_callback'=>static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads')&&F3BASE_PLUGIN_VERSAO==='1.77.0'&&f3qa177_host(),
  'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'show_in_rest'=>false],
  'execute_callback'=>static function($e){
    global $wpdb;
    $page=get_page_by_path(F3QA177_SLUG,OBJECT,'page');$user=get_user_by('login',F3QA177_USER);
    if (($user&&!get_user_meta($user->ID,'_f3qa_1770',true))||($page&&!get_post_meta($page->ID,'_f3qa_1770',true))){return ['ok'=>false,'codigo'=>'colisao'];}
    if ($e['caso']==='preparar'){
      if (!$user){
        $uid=wp_insert_user(['user_login'=>F3QA177_USER,'user_pass'=>wp_generate_password(48,true,true),'user_email'=>'qa1770@example.invalid','role'=>'editor']);
        if(is_wp_error($uid)){return ['ok'=>false,'codigo'=>$uid->get_error_code()];}
        update_user_meta($uid,'_f3qa_1770',1);
      }else{$uid=$user->ID;}
      if (!$page){
        $id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_name'=>F3QA177_SLUG,'post_title'=>'Homologação do Core 1.77.0','post_author'=>$uid,'post_content'=>wp_slash(f3qa177_markup()),'meta_input'=>['_f3qa_1770'=>1]],true);
        if(is_wp_error($id)){return ['ok'=>false,'codigo'=>$id->get_error_code()];}
      }else{$id=$page->ID;}
      $pass=wp_generate_password(36,false,false);wp_set_password($pass,$uid);
      return ['ok'=>true,'url'=>get_permalink($id),'page'=>$id,'login'=>F3QA177_USER,'password'=>$pass];
    }
    $table=F3Base_Leads_Repositorio::tabela();
    $rows=$wpdb->get_results($wpdb->prepare("SELECT record_id FROM $table WHERE formulario=%s AND classe_trafego='teste' LIMIT 50",'qa-core-1770'),ARRAY_A);
    $out=[];
    foreach($rows as $row){
      $id=$row['record_id'];$r=F3Base_Leads_Repositorio::obter($id);$d=$r['dados'];$a=$d['atribuicao']??[];$out[]=['id'=>$id,'sessao'=>$d['sessao']??null,'metodo'=>$r['metodo'],'captura'=>$r['captura'],'etapa2'=>$d['campos']['mensagem']??null,'atribuicao'=>array_intersect_key($a,array_flip(['gclid','gad_campaignid','utm_campaign','plataforma','cobertura','cobertura_fonte']))];
      if ($e['caso']==='limpar'&&!F3Base_Leads_Repositorio::eliminar($id,'homologacao_1770')){return ['ok'=>false,'codigo'=>'falha_descartar_registro'];}
    }
    if ($e['caso']==='ler'){return ['ok'=>true,'registros'=>$out,'pagina'=>$page?['id'=>$page->ID,'classe'=>str_contains($page->post_content,'f3base-alvo-teste-grupo'),'titulo'=>$page->post_title]:null];}
    if ($page&&!wp_delete_post($page->ID,true)){return ['ok'=>false,'codigo'=>'falha_descartar_pagina'];}
    if ($user){require_once ABSPATH.'wp-admin/includes/user.php';if(!wp_delete_user($user->ID)){return ['ok'=>false,'codigo'=>'falha_descartar_usuario'];}}
    return ['ok'=>true,'registros_descartados'=>count($out),'pagina_ausente'=>!get_page_by_path(F3QA177_SLUG,OBJECT,'page'),'usuario_ausente'=>!username_exists(F3QA177_USER)];
  }
 ]);
});
