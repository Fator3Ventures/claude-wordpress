import os,time,json
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
h='fator3-teste-mcp-1.dreamhosters.com';base='https://'+h
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('F3BASE_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'],proxy={'server':os.environ['HTTPS_PROXY']})
 ctx=b.new_context(ignore_https_errors=True,user_agent='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36')
 ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>false})")
 ctx.add_cookies([{'name':'f3base_teste','value':'1','url':base},{'name':'f3base_consentimento','value':'granted','url':base}])
 ctx.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname==h else r.abort())
 page=ctx.new_page();rows=[]
 def resp(r):
  url=urlparse(r.url).path
  if r.request.method!='POST' or '/f3base/' not in url:return
  try:
   d=r.json();obj={k:d[k] for k in ['record_id','codigo','motivo','ok','registrado','method','classe_trafego'] if k in d};obj['conversao']={k:v for k,v in (d.get('conversao') or {}).items() if k in ['codigo','elegivel']};rows.append({'rota':url,'http':r.status,**obj});print(rows[-1],flush=True)
  except Exception:print('http',url,r.status,flush=True)
 page.on('response',resp);page.on('pageerror',lambda e:print('pageerror',e,flush=True))
 page.on('requestfailed',lambda r:print('falha',urlparse(r.url).path,r.failure,flush=True))
 page.goto(base+'/?qa_core=contato1840-'+str(int(time.time())),wait_until='domcontentloaded',timeout=60000)
 page.wait_for_function('!!window.f3baseTracking?.sessao() && !!window.f3baseContexto?.teste()')
 sess=page.evaluate('f3baseTracking.sessao()')
 # Evita a saída da página mantendo propagação da ação do plugin.
 page.evaluate("document.addEventListener('click',e=>{if(e.target.closest('a'))e.preventDefault()},true)")
 page.evaluate("""()=>{const a=document.createElement('a');a.id='qa1840-cta';a.href='https://wa.me/5511999999999';a.textContent='QA botão WhatsApp';a.dataset.f3baseLead='whatsapp';a.dataset.f3baseCta='qa1840-botao';a.dataset.f3baseSuperficie='barra_fixa';document.body.prepend(a);}""")
 page.locator('#qa1840-cta').click()
 page.wait_for_timeout(1100)
 dlg=page.locator('dialog').filter(has=page.locator('a[href*="wa.me"]')).first
 dlg.evaluate('d=>{if(!d.open)d.showModal()}')
 dlg.locator('a[href*="wa.me"]').first.click()
 f=dlg.locator('form[data-f3base-formulario]').first
 print('form',f.count(),flush=True)
 if f.count():
  f.locator('[name="campos[seu-nome]"]').fill('Homologação Core 1840')
  f.locator('[name="campos[contato]"]').fill('(11) 90000-1840')
  f.locator('button[type=submit]').first.click()
 page.wait_for_timeout(14000)
 Path(os.environ.get('F3BASE_EVIDENCIA_399',str(Path(__file__).resolve().parents[1]/'evidence/1840/contatos-navegador.json'))).write_text(json.dumps({'sessao':sess,'respostas':rows},ensure_ascii=False,indent=2))
 b.close()
