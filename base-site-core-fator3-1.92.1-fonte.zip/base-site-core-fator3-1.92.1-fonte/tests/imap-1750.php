<?php
define('ABSPATH',__DIR__);
$lib=dirname(__DIR__).'/work/plugin/base-site-core-fator3/includes/';
require $lib.'class-f3base-email-estrutura.php';require $lib.'class-f3base-email-imap.php';
function sanitize_file_name($n){return $n;}function wp_strip_all_tags($v){return strip_tags($v);}function wp_check_invalid_utf8($v){return $v;}
$cls=new ReflectionClass(F3Base_Email_Imap::class);
$client=$cls->newInstanceWithoutConstructor();$socket=stream_socket_client('tcp://127.0.0.1:'.(int)$argv[1]);
$cls->getProperty('socket')->setValue($client,$socket);$cls->getProperty('deadline')->setValue($client,microtime(true)+20);
foreach([10,11,12] as $uid){
 $msg=$client->fetch($uid);
 if(!$msg['excedida']||$msg['bytes']!==3145728||$msg['parcial']['cabecalho_excedido']!==($uid===11)||count($msg['parcial']['anexos'])!==1||$msg['parcial']['texto']!=='texto QA'){throw new RuntimeException('Metadados incorretos no UID '.$uid.': '.json_encode($msg['parcial']));}
}
$client->close();
