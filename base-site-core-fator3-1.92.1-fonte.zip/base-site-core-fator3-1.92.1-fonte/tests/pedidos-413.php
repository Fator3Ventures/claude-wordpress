<?php
/** WP-CLI no laboratório local. F3_QA_CSV=1 também exercita o exportador HTTP. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' ||
    !in_array(DB_NAME, ['core189limpa','core189upgrade','core1881limpa','core1881upgrade','core188limpa', 'core188upgrade', 'core188dev'], true)) {
    throw new RuntimeException('Execute em WordPress descartável.');
}
wp_set_current_user(1);
global $wpdb;
$check = static function (bool $ok, string $id) use (&$checks) {
    if (!$ok) { throw new RuntimeException($id); }
    $checks[] = $id;
};
$cases = [
    '25078PC3EG' => ['POCO C85 · 2025 · ~R$ 1.164','entrada'],
    'SM-A075M' => ['Galaxy A07 · 2025 · ~R$ 718','entrada'],
    'SM-S928B' => ['Galaxy S24 Ultra · 2024 · ~R$ 5.399 · linha premium','topo'],
    'SM-A175M' => ['Galaxy A17 · 2025 · ~R$ 920','entrada'],
    'X-413-QA' => ['nome comercial não identificado','desconhecido'],
];
$captures=[]; $checks=[]; $ids=[]; $external=[];
$trap = static function ($pre,$args,$url) use (&$external) {
    $external[]=wp_parse_url($url,PHP_URL_HOST);
    return new WP_Error('qa_sem_rede','Rede externa desligada no ensaio.');
};
add_filter('pre_http_request',$trap,10,3);
register_shutdown_function(static function () use (&$ids,$wpdb) {
    foreach ($ids as $id) {
        $wpdb->delete(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id]);
        $wpdb->delete(F3Base_Perfil_Aparelho::tabela(),['sessao'=>$id]);
        $wpdb->delete(F3Base_Analise::tabela(),['sessao'=>$id]);
    }
});
foreach ($cases as $code=>[$expected,$tier]) {
    $id=bin2hex(random_bytes(16)); $ids[]=$id;
    $ref=['classe'=>'teste','sessao'=>$id,'visitante'=>$id];
    $snapshot=['politica_versao'=>'legado:qa','medicao'=>true,'publicidade'=>false];
    $data=['consentimento_snapshot'=>$snapshot,'contexto'=>['perfil_aparelho_ref'=>$ref,'user_agent'=>'Mozilla/5.0 Android']];
    $profile=F3Base_Perfil_Aparelho::normalizar(['modelo'=>$code,'versao_sistema'=>'15','memoria_gb'=>8,
        'nucleos'=>8,'largura'=>360,'altura'=>800,'dpr'=>2,'rede'=>'4g'],'Android',[]);
    $check(F3Base_Perfil_Aparelho::gravar('teste',$id,$id,time(),$profile),'persistir_'.$code);
    $check($wpdb->insert(F3Base_Analise::tabela(),['evento'=>$id,'visitante'=>$id,'sessao'=>$id,'classe_trafego'=>'teste',
        'navegacao'=>$id,'tipo'=>'pagina','caminho'=>'/qa-413','entrada'=>'/qa-413','dispositivo'=>'movel','criado_em'=>time(),
        'inicio_sessao'=>time(),'recebido_em'=>time(),'qualidade'=>'observado','atribuicao'=>'{}','payload_hash'=>hash('sha256',$id)])===1,'evento_'.$code);
    $check($wpdb->insert(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id,'sessao'=>$id,'metodo'=>'formulario','classe_trafego'=>'teste',
        'nome'=>'Exemplo QA','criado_em'=>current_time('mysql',true),'atualizado_em'=>current_time('mysql',true),'pagina'=>'/qa-413',
        'dados'=>wp_json_encode($data),'anexos'=>'[]','payload_hash'=>hash('sha256',$id)])===1,'contato_'.$code);
    $lead=F3Base_Leads_Repositorio::obter($id);
    $a=F3Base_Contato_Apresentacao::montar($lead,false);
    $old=F3Base_Perfil_Aparelho::apresentar($a);
    $check($old['Modelo']===$code && $old['Memória (GB)']==='8' && $old['Rede efetiva']==='4g','perfil_tecnico_'.$code);
    $check(str_contains(F3Base_Contato_Apresentacao::nota($a,'qa'),$code),'nota_'.$code);
    foreach (['compacto','completo','thread'] as $format) {
        foreach (F3Base_Slack::mensagens($a,$format) as $i=>$msg) {
            $type=$format==='thread'?F3Base_Slack_Thread::TIPOS[$i]:($i===0?'principal':'detalhe');
            $payload=F3Base_Slack_Thread::perfil_da_parte($msg,$type,$i,$format,$lead['dados']);
            $both=wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            foreach ([$code,'Versão principal do sistema','Memória (GB)','Núcleos lógicos','Rede efetiva'] as $hidden) {
                $check(!str_contains($both,$hidden),'slack_oculta_'.$format.'_'.$i.'_'.$code.'_'.$hidden);
            }
            if ($type==='acontecimento' || ($format!=='thread' && $i===0)) {
                $check(str_contains($payload['text'],$expected) && str_contains($payload['text'],'Tela e DPR: 360×800 @2x') &&
                    str_contains($payload['text'],'Faixa do aparelho: '.$tier),'slack_texto_'.$format.'_'.$code);
                $check(str_contains(wp_json_encode($payload['blocks'],JSON_UNESCAPED_UNICODE),$expected),'slack_blocos_'.$format.'_'.$code);
                $captures[$code]=$expected;
                $no=$data; $no['consentimento_snapshot']['revogada']=true;
                $check(F3Base_Slack_Thread::perfil_da_parte($msg,$type,$i,$format,$no)===$msg,'consentimento_'.$format.'_'.$code);
            }
        }
    }
}
$filter=['de'=>wp_date('Y-m-d'),'ate'=>wp_date('Y-m-d'),'segmento'=>'somente_testes','caminho'=>'/qa-413','memoria_gb'=>'8'];
$report=F3Base_Editorial_Relatorios::consultar(['visao'=>'sessoes','comparar'=>false]+$filter);
$rows=array_column($report['linhas']??[],null,'sessao');
foreach ($ids as $id) {
    $check(isset($rows[$id]) && $rows[$id]['memoria_gb']==='8' && $rows[$id]['rede_efetiva']==='4g' && is_array($rows[$id]['rede']),'relatorio_memoria_'.array_search($id,$ids,true));
}
$r=F3Base_Editorial_Relatorios::consultar(['visao'=>'sessoes','linha_premium'=>'sim']+$filter);
$check(array_column($r['linhas']??[],'modelo')===['SM-S928B'],'filtro_premium');
$check($rows[$ids[2]]['ano_lancamento']==='2024' && $rows[$ids[2]]['preco_atual_estimado_brl']==='5399.00','preco_ano');
$r=F3Base_Relatorios::consultar(['visao'=>'resultados','linha_premium'=>'sim']+$filter);
$check(!empty($r['ok']),'integrado_aceita_filtros');
$legacy=F3Base_Perfil_Aparelho::para_relatorio(['modelo'=>'SM-S928B','faixa_aparelho'=>'desconhecido']);
$check($legacy['linha_premium']==='sim' && $legacy['faixa_aparelho']==='topo','historico');
$local=F3Base_Catalogo_Aparelhos::resolver('SM-A075M',['Galaxy A07 4G=topo']);
$check($local['faixa_sugerida']==='topo' && $local['nome_comercial']==='Galaxy A07','precedencia_nome');
$custom=['QA-COD=Marca|Modelo do site|2025|1080.00|intermediário|não'];
$check(F3Base_Catalogo_Aparelhos::validar($custom) && F3Base_Catalogo_Aparelhos::resolver('qa-cod',$custom)['preco_atual_estimado_brl']==='1080.00','correcao_site');
$check(!F3Base_Catalogo_Aparelhos::validar([...$custom,...$custom]),'duplicidade');
$unknown=[]; $cursor=''; $pages=0;
do {
    $page=F3Base_Catalogo_Aparelhos::sem_nome(['apos'=>$cursor,'limite'=>1]);
    $check(!empty($page['ok']) && ++$pages<200,'pagina_'.$pages);
    $unknown=array_merge($unknown,array_column($page['itens'],'codigo'));
    $cursor=$page['proximo_apos'];
} while ($cursor!==null);
$check(in_array('x-413-qa',$unknown,true) && !in_array('sm-a075m',$unknown,true),'leitura_sem_nome');
wp_set_current_user(0);
$check(F3Base_Catalogo_Aparelhos::sem_nome()['codigo']==='sem_permissao','leitura_restrita');
wp_set_current_user(1);
$check($external===[],'sem_http');
if (getenv('F3_QA_CSV')) {
    $_POST=['visao'=>'sessoes','linha_premium'=>'sim']+$filter;
    $_REQUEST=$_POST+['_wpnonce'=>wp_create_nonce('f3base-editorial-csv')];
    F3Base_Medicao_Editorial_UI::csv();
}
echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'versao'=>F3BASE_PLUGIN_VERSAO,
    'verificacoes'=>count($checks),'modelos'=>$captures,'paginas_sem_nome'=>$pages,'chamadas_http'=>count($external)],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
