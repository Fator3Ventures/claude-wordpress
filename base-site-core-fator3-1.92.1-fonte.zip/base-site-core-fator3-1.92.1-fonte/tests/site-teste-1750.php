<?php
/** Temporary, authenticated Site-Teste fixture. Never package this as part of the installer. */
if(!defined('ABSPATH')){exit;}
add_action('wp_abilities_api_init',static function(){
 wp_register_ability('f3qa/core-1750',[
  'label'=>'Conferir Core 1.75.0 em homologação','description'=>'Somente casos sintéticos fixos no Site-Teste.',
  'category'=>'site','input_schema'=>['type'=>'object','additionalProperties'=>false,'properties'=>['caso'=>['type'=>'string','enum'=>['comum','cabecalho','automatico','cache','abandono','sessao']]],'required'=>['caso']],
  'output_schema'=>['type'=>'object','additionalProperties'=>true],
  'permission_callback'=>static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads')&&wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com'&&defined('F3BASE_PLUGIN_VERSAO')&&in_array(F3BASE_PLUGIN_VERSAO,['1.75.0','1.75.1'],true),
  'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'show_in_rest'=>false],
  'execute_callback'=>static function($args){
   global $wpdb;$case=$args['caso'];$seed='f3core1750-site-teste-0911-v1';
   if($case==='sessao'){
    $session=bin2hex(random_bytes(16));$nav=bin2hex(random_bytes(16));$visitor=bin2hex(random_bytes(16));
    $form=F3Base_Formularios::obter('contato-whatsapp');$analytics=F3Base_Analise::tabela();$events=F3Base_Modulo_Comportamento::nome_tabela_eventos();
    $base=['classe_trafego'=>'teste','visitante'=>$visitor,'sessao'=>$session,'navegacao'=>$nav,'caminho'=>'/qa-core-1751/','criado_em'=>time()-3,'recebido_em'=>time()];
    try{
     foreach(['pagina','form_fechado'] as $type){
      $row=$base+['dispositivo'=>'movel','atribuicao'=>'{}','qualidade'=>'observada','payload_hash'=>str_repeat('a',64),'inicio_sessao'=>time()-15,'evento'=>bin2hex(random_bytes(16)),'tipo'=>$type];
      if($type==='form_fechado'){$row+=['formulario'=>$form['id'],'formulario_revisao'=>F3Base_Formularios::revisao($form),'correlacao'=>bin2hex(random_bytes(16)),'ultimo_campo'=>'seu-nome','etapa'=>1,'campos_preenchidos'=>1,'detalhe'=>'saida_sem_aceite_observado'];}
      if($wpdb->insert($analytics,$row)!==1){return ['ok'=>false,'codigo'=>'semente_analitica'];}
     }
     for($i=0;$i<12;$i++){
      $row=$base+['dia'=>wp_date('Y-m-d'),'ancora'=>'observada','ocorrencia'=>$i+1];
      if($i<10){$row+=['metrica'=>'f3base_clique_inerte','detalhe'=>'socios~'.($i===0?'equipe':'socios:titulo:'.($i+1))];}
      else{$row+=['metrica'=>'f3base_form_fechado','detalhe'=>'contato-whatsapp:oferta_fechada'];if($i===11){$row['navegacao']=bin2hex(random_bytes(16));}}
      if($wpdb->insert($events,$row)!==1){return ['ok'=>false,'codigo'=>'semente_comportamento'];}
     }
     $filter=['sessao'=>$session,'segmento'=>'somente_testes'];$detail=wp_get_ability('f3base/sessao-detalhar')->execute($filter);
     $forms=wp_get_ability('f3base/relatorios-integrados-ler')->execute($filter+['visao'=>'formularios']);
     $lines=$detail['linhas']??[];$unknown=array_filter($lines,static fn($row)=>($row['ultimo_campo']??null)==='nao_observado'&&($row['etapa']??null)==='nao_observado'&&($row['campos_preenchidos']??null)==='nao_observado');
     $observed=array_filter($lines,static fn($row)=>($row['ultimo_campo']??null)==='seu-nome'&&($row['etapa']??null)===1&&($row['campos_preenchidos']??null)===1);
     $targets=array_column(array_filter($lines,static fn($row)=>($row['f3base_secao']??null)==='socios'),'f3base_alvo');$formOK=!is_wp_error($forms)&&str_contains(wp_json_encode($forms),'seu-nome');
     return ['ok'=>count($observed)===1&&count($unknown)===2&&count($targets)===10&&$formOK,'observados'=>count($observed),'legados_sem_prova'=>count($unknown),'alvos'=>$targets,'visao_formularios'=>$formOK,'origem'=>'eventos sintéticos semeados nas tabelas; leitura pelas abilities reais'];
    }finally{foreach([$analytics,$events] as $table){$wpdb->delete($table,['classe_trafego'=>'teste','sessao'=>$session,'visitante'=>$visitor]);}}
   }
   if($case==='cache'){
    $key='cache-reaquecimento';$opt='f3base_trava_'.hash('sha256',$key);$stub=['dono'=>'qa-core-1750','desde'=>time()-100,'expira'=>time()-1];
    if(!add_option($opt,$stub,'','off')){return ['ok'=>false,'codigo'=>'reserva_preexistente'];}
    try{
     $read=F3Base_Cache_Reaquecimento::consultar();$p=F3Base_Operacao::executar_pendentes(['liberar_reserva_reaquecimento'=>true]);
     $r=F3Base_Operacao::executar_pendentes(['liberar_reserva_reaquecimento'=>true,'simular'=>false,'revisao'=>$p['revisao'],'motivo'=>'Homologação Core 1.75.0 com reserva sintética expirada']);
     return ['ok'=>$r['ok']&&F3Base_Trava::inspecionar($key)===null,'codigo'=>$r['codigo'],'reserva_observada'=>$read['reservas_execucao']['modulo']];
    }finally{F3Base_Trava::liberar(['nome'=>$opt,'valor'=>$stub]);}
   }
   if($case==='abandono'){
    $cfg=F3Base_Options::ler(F3Base_Formulario_Tentativas::OPTION);
    if(!empty($cfg['capturar_abandono'])){return ['ok'=>false,'codigo'=>'configuracao_global_ativa'];}
    $opt=static fn()=>array_replace($cfg,['capturar_abandono'=>true,'abandono_exige_medicao'=>false]);
    $sess=bin2hex(random_bytes(16));$inst=bin2hex(random_bytes(16));$form=F3Base_Formularios::obter('contato-whatsapp');
    $e=['formulario'=>$form['id'],'instancia'=>$inst,'sessao'=>$sess,'evento'=>bin2hex(random_bytes(16)),'sequencia'=>1,'etapa'=>1,'tipo'=>'abandono','ocorrido_ms'=>time()*1000,'token'=>F3Base_Formularios::emitir($form,$inst,1,true),'campos'=>[['nome'=>'seu-nome','estado'=>'preenchido','valor'=>'QA 1750','regras'=>[]],['nome'=>'seu-email','estado'=>'preenchido','valor'=>'qa1750@example.invalid','regras'=>[]]]];
    $denied=F3Base_Formulario_Tentativas::receber($e);
    add_filter('pre_option_'.F3Base_Formulario_Tentativas::OPTION,$opt);
    try{
     $a=F3Base_Formulario_Tentativas::receber($e);$e['sequencia']=2;$e['campos'][1]['estado']='vazio';$e['campos'][1]['valor']='';$b=F3Base_Formulario_Tentativas::receber($e);
     $lines=F3Base_Formulario_Tentativas::consultar(['sessao'=>$sess,'segmento'=>'todos'])['linhas']??[];
     $name=($lines[0]['campos'][0]['valor']??null)==='QA 1750';$empty=($lines[0]['campos'][1]['valor']??null)==='';
     $erase=F3Base_Formulario_Tentativas::eliminar_lead(['correlacao'=>$inst,'sessao'=>$sess]);$late=F3Base_Formulario_Tentativas::receber($e);
     return ['ok'=>$a['ok']&&$b['ok']&&count($lines)===1&&$empty&&$name&&$erase,'desligada_por_padrao'=>$denied['codigo'],'linha_unica'=>count($lines),'nome_conferido'=>$name,'email_vazio'=>$empty,'eliminada'=>$erase,'reenvio'=>$late['codigo']];
    }finally{remove_filter('pre_option_'.F3Base_Formulario_Tentativas::OPTION,$opt);$wpdb->delete(F3Base_Formulario_Tentativas::tabela(),['sessao'=>$sess,'instancia'=>$inst]);}
   }
   $cfg=F3Base_Email_Site::cfg();
   if(!empty($cfg['ativo'])||F3Base_Testes::politica('slack','teste')!=='suprimir'||F3Base_Testes::politica('email','teste')!=='suprimir'){return ['ok'=>false,'codigo'=>'ambiente_nao_isolado'];}
   $cfg['homologacao']=true;$cfg['homologacao_emails']=['qa1750@example.invalid'];$mid='<f3c-'.substr(hash('sha256',$seed.$case),0,32).'@example.invalid>';
   $client=F3Base_Email_Site::conectar();$lock=F3Base_Trava::adquirir('qa1750-'.$case,120);if(!$lock){$client->close();return ['ok'=>false,'codigo'=>'fixture_ocupada'];}
   try{
    $folders=$client->pastas(['destino'=>$cfg['pasta_importados']],true);$folder=$folders['pastas']['destino']['efetiva'];$client->select($folder,true);
    if($client->buscar_message_id($mid)){return ['ok'=>true,'codigo'=>'fixture_ja_importada','caso'=>$case];}
    $box=$client->select('INBOX',false);$uids=$client->buscar_message_id($mid);
    if(!$uids){
     $header="From: Pessoa QA <qa1750@example.invalid>\r\nTo: ".$cfg['endereco']."\r\nMessage-ID: $mid\r\nSubject: [TESTE F3BASE] Core 1.75.0 $case\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=qa1750\r\n";
     if($case==='cabecalho'){$header.=str_repeat('X-QA-Pad: '.str_repeat('x',750)."\r\n",360);}
     if($case==='automatico'){$header.="Auto-Submitted: auto-replied\r\n";}
     $mime=$header."\r\n--qa1750\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\nHomologacao sintetica\r\n--qa1750\r\nContent-Type: application/octet-stream; name=qa1750.bin\r\nContent-Disposition: attachment; filename=qa1750.bin\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode(str_repeat('Q',1700000)),76,"\r\n")."--qa1750--\r\n";
     // The product's outbound APPEND cap is preserved. The fixture seeds an incoming oversized message.
     (new ReflectionMethod(F3Base_Email_Imap::class,'command'))->invoke($client,'APPEND "INBOX" (\\Seen) {'.strlen($mime).'}',$mime);unset($mime);$uids=$client->buscar_message_id($mid);
    }
    if(count($uids)!==1){return ['ok'=>false,'codigo'=>'uid_de_fixture_ambiguo'];}
    $uid=$uids[0];$msg=$client->fetch($uid);$msg['uidvalidity']=$box['uidvalidity'];
    if(empty($msg['excedida'])||!str_contains($msg['raw'],$mid)){return ['ok'=>false,'codigo'=>'mensagem_de_teste_divergente'];}
    $p=F3Base_Email_Mime::parse($msg['raw'],$cfg,$msg['parcial']+['bytes'=>$msg['bytes']]);$context=F3Base_Email_Site_Config::identidade($cfg);
    if($case==='automatico'){F3Base_Email_Site::persistir($msg,['classe'=>'descartado','motivo'=>'resposta_automatica','message_id'=>$p['message_id']],$context);}
    if($p['classe']!=='suspeito'||$p['email']!=='qa1750@example.invalid'||!$p['teste']){return ['ok'=>false,'codigo'=>'classificacao_inesperada'];}
    $r=F3Base_Email_Site::persistir($msg,$p,$context,true);if(empty($r['record_id'])){return ['ok'=>false,'codigo'=>$r['codigo']??'sem_contato'];}
    $lead=F3Base_Leads_Repositorio::obter($r['record_id']);if($lead['captura']!=='suspeito'||$lead['classe_trafego']!=='teste'){return ['ok'=>false,'codigo'=>'contato_divergente'];}
    $client->move($uid,$cfg['pasta_importados']);F3Base_Email_Site::patch($r['chave'],['movida_em'=>time()]);
    $client->select($folder,true);$dest=$client->buscar_message_id($mid);
    $note=F3Base_Leads_Notificacoes::enviar($r['record_id']);
    return ['ok'=>count($dest)===1,'caso'=>$case,'record_id'=>$r['record_id'],'captura'=>$lead['captura'],'bytes'=>$msg['bytes'],'cabecalho_excedido'=>$msg['parcial']['cabecalho_excedido'],'anexos'=>$p['anexos'],'motivo'=>$p['motivo'],'remetente_conferido'=>$lead['email']==='qa1750@example.invalid','assunto_conferido'=>str_contains($p['assunto'],$case),'pasta_importados_confirmada'=>count($dest)===1,'aviso'=>$note['codigo']??$note['estado']??null];
   }finally{$client->close();F3Base_Trava::liberar($lock);}
  }
 ]);
});
