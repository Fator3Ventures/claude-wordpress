<?php
/** Run against a patched, isolated implantador-base source tree in the native WP laboratory. */
require __DIR__.'/bootstrap.php';
$root = realpath(getenv('F3BASE_IMPLANTADOR') ?: '');
if (!$root || !is_file($root.'/content/pages/home.html')) { throw new RuntimeException('Informe a cópia isolada do implantador.'); }
require $root.'/fontes/tema/functions.php';
$blocks = parse_blocks(file_get_contents($root.'/content/pages/home.html'));
$group = array_values(array_filter($blocks, static fn($b)=>($b['blockName']??'')==='core/group'))[0];
$html = render_block($group);
check(substr_count($html,'data-f3base-alvo="introducao"')===1, 'declaracao_no_heading_renderizado');
$before = F3Base_Conteudo_Instrumentacao::html('<html><body>'.$html.'</body></html>', home_url('/'));
$without = F3Base_Conteudo_Instrumentacao::html('<html><body>'.str_replace(' data-f3base-alvo="introducao"','',$html).'</body></html>',home_url('/'));
check(count($before['textos_sem_alvo'])+1===count($without['textos_sem_alvo']), 'auditoria_exclui_so_o_heading_marcado');
check(!str_contains(render_block(['blockName'=>'core/heading','attrs'=>['className'=>'f3-alvo-URL/invalida'],'innerBlocks'=>[],'innerHTML'=>'<h2>QA</h2>','innerContent'=>['<h2>QA</h2>']]),'data-f3base-alvo'), 'rotulo_invalido_ignorado');
evidence('implantador-2180', ['origem'=>'implantador-base 2.18.0, cópia com patch', 'com_marca'=>count($before['textos_sem_alvo']),'sem_marca'=>count($without['textos_sem_alvo'])]);
