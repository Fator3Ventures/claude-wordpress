"""Real-browser acceptance. The temporary editor and page belong only to Site-Teste."""
import argparse, json, os, re, time
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser()
p.add_argument('--access',required=True,type=Path,help='Private temporary fixture receipt; never include it in the ZIP.')
p.add_argument('--output',required=True,type=Path)
p.add_argument('cases',nargs='+',choices=['editor','tracking','contact','form','native'])
args=p.parse_args()
cfg=json.loads(args.access.read_text())
url=cfg['url'];host=urlparse(url).hostname
assert host=='fator3-teste-mcp-1.dreamhosters.com'
base='https://'+host
results={}
with sync_playwright() as pw:
    opts={'args':['--no-sandbox','--disable-dev-shm-usage'],'executable_path':os.environ.get('CHROMIUM','/usr/bin/chromium')}
    if os.environ.get('HTTPS_PROXY'):opts['proxy']={'server':os.environ['HTTPS_PROXY']}
    browser=pw.chromium.launch(**opts)
    for case in args.cases:
        report={'chromium':browser.version,'etapas':[],'http':[]};results[case]=report
        def step(name):report['etapas'].append(name);print(case,name,flush=True)
        ctx=browser.new_context(ignore_https_errors=True,java_script_enabled=case!='native',extra_http_headers={'X-F3Base-Teste':'1','X-F3QA-Ciclo':'1770'},viewport={'width':1440,'height':1000})
        ctx.add_cookies([{'name':k,'value':v,'url':base} for k,v in [('f3base_teste','1'),('f3base_consentimento','granted')]])
        def route(rt):
            if urlparse(rt.request.url).hostname==host:rt.continue_()
            else:rt.abort()
        ctx.route('**/*',route)
        page=ctx.new_page();page.set_default_timeout(20000)
        def resp(r):
            path=urlparse(r.url).path
            if r.request.method=='POST' and ('/wp-json/' in path or 'admin-post.php' in path):
                rec={'path':path,'status':r.status};report['http'].append(rec)
                if 'formularios/' in path or path.endswith('/lead') or path.endswith('/leads') or path.endswith('/comportamento'):
                    try:
                        payload=r.json()
                        rec['dados']={k:v for k,v in payload.items() if k in ['ok','codigo','campo','registrado','record_id','etapa_pendente','persisted','duplicado','motivo']}
                    except Exception:pass
        page.on('response',resp)
        try:
            if case=='editor':
                page.goto(base+'/wp-login.php',wait_until='domcontentloaded',timeout=60000)
                page.locator('#user_login').fill(cfg['login']);page.locator('#user_pass').fill(cfg['password']);page.locator('#wp-submit').click(timeout=60000)
                page.goto(base+'/wp-admin/post.php?post='+str(cfg['page'])+'&action=edit',wait_until='domcontentloaded',timeout=60000)
                page.wait_for_function("window.wp?.data?.select('core/editor')?.getCurrentPostId()>0",timeout=90000)
                ok=page.evaluate("""()=>{let ed=wp.data.select('core/block-editor'),b=ed.getBlocks(),walk=xs=>xs.flatMap(x=>[x,...walk(x.innerBlocks)]),g=walk(b).find(x=>x.attributes.className==='f3base-alvo-teste-grupo');return !!g&&g.isValid;}""")
                assert ok;step('grupo_aberto_valido')
                page.evaluate("""()=>wp.data.dispatch('core/editor').editPost({title:'Homologação do Core 1.77.0 revisada'})""")
                page.evaluate("""async()=>{await wp.data.dispatch('core/editor').savePost();if(wp.data.select('core/editor').isEditedPostDirty())throw Error('Gravação pendente');}""")
                step('edicao_gravada_pelo_gutenberg')
                page.goto(url+'?qa=apos-editor',wait_until='domcontentloaded',timeout=60000)
                assert page.locator('.f3base-alvo-teste-grupo p').count()==1;step('classe_no_html_apos_gravar')
            else:
                target=url+'?gclid=QA1770Google&utm_campaign=Campanha+QA1770&gad_campaignid=770123&caso='+case+'&qa_revision=2'
                res=page.goto(target,wait_until='domcontentloaded',timeout=60000)
                assert res.status==200;step('pagina_publica_200')
                form=page.locator('form[data-f3base-formulario="qa-core-1770"]')
                if case=='native':
                    assert form.locator('[data-etapa="2"][hidden] textarea:disabled').count()==1
                    assert not form.locator('[data-etapa="2"]').is_visible();step('inicial_oculta_sem_js')
                else:
                    page.wait_for_function('window.f3baseContexto?.pronto()',timeout=45000)
                if case=='tracking':
                    page.wait_for_function('window.f3baseTracking?.sessao()')
                    report['config']=page.evaluate('''()=>({teto:window.f3baseTracking.eventos().f3base_clique_inerte?.teto,modo:window.f3baseTrackingDados.resumo.politica,ativo:window.f3baseTrackingDados.resumo.ativo})''')
                    for s in ['Primeiro alvo da homologação','Segundo alvo da homologação']:
                        page.get_by_text(s,exact=True).click();page.wait_for_timeout(1500)
                    report['emitidos']=page.evaluate('window.f3baseTracking.emitidos()')
                    report['resumo']=page.evaluate('window.f3baseTracking.resumo()')
                    report['sessao']=page.evaluate('window.f3baseTracking?.sessao()');step('dois_cliques_reais')
                    page.evaluate("document.dispatchEvent(new CustomEvent('f3base:contato-capturado'))");page.wait_for_timeout(13000)
                    page.evaluate("window.dispatchEvent(new Event('pagehide'))");page.wait_for_timeout(12000)
                    assert report['sessao']
                elif case=='contact':
                    # Reproduce tracking without a session while keeping the actual lead listener and REST transport.
                    page.evaluate("""()=>{if(window.f3baseTracking){window.f3baseTracking.sessao=()=>null;} document.addEventListener('click',e=>{if(e.target.closest('a[href^="https://wa.me"]'))e.preventDefault();},{once:true});}""")
                    page.get_by_text('Contato de homologação',exact=True).click();page.wait_for_timeout(6500);step('clique_wa_sem_sessao')
                else:
                    if case=='form':
                        page.evaluate("""()=>{if(window.f3baseTracking)window.f3baseTracking.sessao=()=>null}""")
                    form.locator('[name="campos[nome]"]').fill('Homologação Core')
                    form.locator('[name="campos[email]"]').fill('qa1770@example.invalid')
                    page.wait_for_timeout(3600)
                    form.locator('button[type=submit]').click(timeout=60000)
                    if case=='form':
                        form.locator('[data-etapa="2"] textarea').wait_for(state='visible',timeout=40000);step('etapa2_revelada')
                        form.locator('[data-etapa="2"] textarea').fill('Complemento de homologação')
                        form.locator('button[type=submit]').click();page.wait_for_timeout(4500)
                        assert any('complement' in x['path'] and x['status']<300 for x in report['http']);step('complemento_confirmado')
                    else:
                        page.wait_for_timeout(1500)
                        assert any('admin-post.php' in x['path'] and x['status']<400 for x in report['http']);step('post_nativo')
            report['ok']=True
        except Exception as err:
            report['ok']=False;report['falha']=str(err).split('Call log:')[0][:320];report['url_final']=urlparse(page.url).path
            print(case,report['falha'],flush=True)
        finally:
            args.output.parent.mkdir(exist_ok=True,parents=True)
            args.output.write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
            ctx.close()
    browser.close()
