<?php
/** Impressão digital de registros sintéticos nos dois caminhos de atualização isolados. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local') {
    throw new RuntimeException('Somente laboratório');
}
global $wpdb;
$tabela = F3Base_Leads_Repositorio::tabela();
$dados = $wpdb->get_row("SELECT COUNT(*) AS contatos,
    SHA2(GROUP_CONCAT(SHA2(CONCAT(record_id,payload_hash),256) ORDER BY record_id),256) AS dados_sha
    FROM {$tabela}", ARRAY_A);
if ((int)$dados['contatos'] !== 55 || $dados['dados_sha'] !== '0149dca7c5e04e77d08606c6677a902f3bd9a6f7f1434ae633ef38a0730c5957') {
    throw new RuntimeException('As amostras divergem da linha de base');
}
echo wp_json_encode($dados);
