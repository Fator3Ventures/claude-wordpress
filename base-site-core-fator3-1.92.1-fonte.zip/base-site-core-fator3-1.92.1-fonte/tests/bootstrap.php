<?php
/** Local integration harness, reconstructed on 2026-11-07. Never use on a shared site. */
declare(strict_types=1);
if (getenv('F3BASE_ALLOW_LOCAL_TESTS') !== '1') { throw new RuntimeException('Set F3BASE_ALLOW_LOCAL_TESTS=1 for a disposable local lab.'); }
$site=getenv('F3BASE_SITE');
if (!$site || !is_file($site)) { throw new RuntimeException('F3BASE_SITE must point to the isolated wp-load.php.'); }
$_SERVER['HTTP_HOST']='127.0.0.1:8137';
require $site;
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_HOST,'127.0.0.1:') || !preg_match('/^core_[a-z0-9_]+$/D',DB_NAME)) {
    throw new RuntimeException('Disposable local WordPress/database required.');
}
if (!defined('WP_INSTALLING') || !WP_INSTALLING) {wp_set_current_user(1);}
set_exception_handler(static function(Throwable $e){fwrite(STDERR,$e->getMessage().' @ '.$e->getFile().':'.$e->getLine()."\n".$e->getTraceAsString()."\n");exit(1);});
$checks=[];
function check($ok,string $name): void {
    global $checks;
    if (array_key_exists($name,$checks)) { throw new RuntimeException('Duplicate assertion: '.$name); }
    $checks[$name]=(bool)$ok;
    if (!$ok) { throw new RuntimeException('FAIL '.$name); }
}
function evidence(string $name,array $details=[]): void {
    global $checks,$wpdb;
    $root=dirname(__DIR__); $dir=$root.'/evidence/1750';
    if(!is_dir($dir)){mkdir($dir,0777,true);}
    $result=['proveniencia'=>'testes da release 1.75.1','versao'=>F3BASE_PLUGIN_VERSAO,
        'php'=>PHP_VERSION,'wordpress'=>get_bloginfo('version'),'banco'=>$wpdb->db_version(),
        'ambiente'=>'WordPress nativo descartável; sem fornecedores externos','checks'=>$checks,'detalhes'=>$details];
    $phase=getenv('F3BASE_TEST_PHASE');$prefix=$phase?preg_replace('/[^a-z0-9_-]/','',$phase).'--':'';
    file_put_contents($dir.'/'.$prefix.$name.'.json',wp_json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n");
    echo $name.': '.count($checks)." checks OK\n";
}
