<?php
require __DIR__.'/bootstrap.php';
global $wpdb;
$names=['f3base_meta_pixels_adicionais','f3base_email_site','f3base_formulario_tentativas','f3base_comportamento','f3base_cadencia'];
$docs=dirname(__DIR__).'/work/plugin/base-site-core-fator3/docs/dados/';
function save1750($f,$d){file_put_contents($f,json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n");}
foreach(['ajuda-opcoes','configuracao-schema'] as $file){
  $path=$docs.$file.'.json';$d=json_decode(file_get_contents($path),true);$d['plugin']=F3BASE_PLUGIN_VERSAO;$d[$file==='ajuda-opcoes'?'contrato':'contract_version']=F3Base_Config_Contrato::VERSAO;
  foreach($names as $name){
    $def=F3Base_Options::declaracao($name);$fields=F3Base_Config_Contrato::campos($def,$name);
    $d['opcoes'][$name]=$file==='configuracao-schema'?['schema'=>F3Base_Config_Contrato::schema_valor($def),'schema_entrada'=>F3Base_Config_Contrato::schema_entrada($def),'campos'=>$fields,'padrao'=>$def['padrao']]:['rotulo'=>$def['rotulo'],'descricao'=>$def['descricao'],'campo'=>$def['campo']??'','ajuda'=>$fields['ajuda']??[],'estrutura'=>$fields['estrutura']??$fields['subcampos']??[]];
  }
  save1750($path,$d);
}
foreach(glob($docs.'abilities-*.json') as $path){
 $d=json_decode(file_get_contents($path),true);$d['plugin']=F3BASE_PLUGIN_VERSAO;$d['contrato']=F3Base_Config_Contrato::VERSAO;
 foreach(['f3base/executar-pendentes','f3base/relatorios-integrados-ler','f3base/caminho-lead-testar'] as $name){
   if(isset($d['abilities'][$name])){$ability=wp_get_ability($name);$d['abilities'][$name]['input_schema']=$ability->get_input_schema();}
 }
 save1750($path,$d);
}
