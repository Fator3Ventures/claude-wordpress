"""Detecta decodificação direta de campo de linha no runtime, excetuando entradas de protocolo e pedidos de formulário."""
import re
from pathlib import Path

root=Path(__file__).resolve().parents[1]/'work/plugin/base-site-core-fator3'
row=re.compile(r'json_decode\s*\(\s*(?:\(string\)\s*)?\$(?:r|row|linha|lead|job|saved|j|prev|email|head|h|fresh)\s*\[')
falhas=[]
for folder in ('includes','admin'):
    for file in (root/folder).rglob('*.php'):
        for i,line in enumerate(file.read_text().splitlines(),1):
            if row.search(line):
                falhas.append(f'{file.name}:{i}')
if falhas:
    raise SystemExit('\n'.join(falhas))
print('Nenhuma chamada direta encontrada nos padrões de linhas do banco. As variáveis intermediárias também requerem revisão de origem.')
