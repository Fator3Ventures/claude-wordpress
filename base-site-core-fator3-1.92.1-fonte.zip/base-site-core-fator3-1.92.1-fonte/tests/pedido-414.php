<?php
/** WP-CLI em WordPress descartável. Semear na base 1.88.1 e validar após a troca. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' ||
    !in_array(DB_NAME, ['core189limpa','core189upgrade','core189dev'], true)) {
    throw new RuntimeException('Laboratório exclusivo do pedido 414 obrigatório.');
}
global $wpdb;
$codigos = ['220333QPG','25028PC03G','2606FRN72L','M2006C3LII','RMX3834','RMX3933',
    'SM-A105M','SM-A107M','SM-A205G','SM-A307GT','SM-M105M','SM-N9600','CPH2819',
    'infinix x6532','infinix x6725','infinix x6728','tecno kl4','tecno kl4h',
    'lm-k410','lm-k510','lm-k520','sp2','moto e(6i)','moto e6s','motorola one fusion','moto g power (2022)'];
$nomes = ['POCO C40','POCO C71','Redmi 17','Redmi 9i','realme Note 50','realme Note 60',
    'Galaxy A10','Galaxy A10s','Galaxy A20','Galaxy A30s','Galaxy M10','Galaxy Note9','OPPO A6x',
    'Infinix SMART 9','Infinix SMART 10','Infinix HOT 60i','TECNO Spark Go 1','TECNO Spark Go 1S',
    'LG K41S','LG K51S','LG K52','Positivo Twist SE','Moto E6i','Moto E6s','Motorola One Fusion','Moto G Power (2022)'];
$modo = getenv('F3_QA_414') ?: 'validar';
$checks=0;
$check=static function ($ok, string $id) use (&$checks) {
    if (!$ok) { throw new RuntimeException($id); }
    ++$checks;
};
$http=0;
add_filter('pre_http_request',static function () use (&$http) {
    ++$http;
    return new WP_Error('qa_sem_rede','Laboratório isolado.');
});
$run=static function (string $rota, array $args) {
    $dados=wp_get_ability('f3base/'.$rota)->execute($args);
    if (is_wp_error($dados) || empty($dados['ok'])) {throw new RuntimeException($rota.': '.wp_json_encode($dados));}
    return $dados;
};
$id=static fn(string $c)=>md5('pedido414:'.strtolower($c));
$perfilAntes=static function() use ($wpdb,$id) {
    return $wpdb->get_var($wpdb->prepare('SELECT perfil FROM %i WHERE sessao=%s',F3Base_Perfil_Aparelho::tabela(),$id('moto e6s')));
};
if ($modo === 'semear') {
    foreach ([...$codigos,'laboratorio-414-sem-registro'] as $c) {
        $chave=$id($c);
        $perfil=F3Base_Perfil_Aparelho::normalizar(['modelo'=>$c,'memoria_gb'=>4,'rede'=>'4g'],'Android',[]);
        $check(F3Base_Perfil_Aparelho::gravar('teste',$chave,$chave,time(),$perfil),'gravar '.$c);
        $check($wpdb->insert(F3Base_Analise::tabela(),['evento'=>$chave,'visitante'=>$chave,'sessao'=>$chave,'classe_trafego'=>'teste',
            'navegacao'=>$chave,'tipo'=>'pagina','caminho'=>'/qa-414','entrada'=>'/qa-414','dispositivo'=>'movel','criado_em'=>time(),
            'inicio_sessao'=>time(),'recebido_em'=>time(),'qualidade'=>'observado','atribuicao'=>'{}','payload_hash'=>hash('sha256',$chave)])===1,'evento '.$c);
    }
    echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'registros'=>27,'perfil_sha256'=>hash('sha256',$perfilAntes()),'testes'=>$checks]);
    return;
}
if ($modo === 'limpar') {
    foreach ([...$codigos,'laboratorio-414-sem-registro'] as $c) {
        $wpdb->delete(F3Base_Analise::tabela(),['sessao'=>$id($c)]);
        $wpdb->delete(F3Base_Perfil_Aparelho::tabela(),['sessao'=>$id($c)]);
    }
    return;
}
$antes=$perfilAntes();
$check(is_string($antes) && $antes!=='','perfil retido');
$alvos=array_map('strtolower',$codigos);$semNome=[];$cursor='';$paginas=0;
do {
    $p=$run('aparelhos-sem-nome-ler',['apos'=>$cursor,'limite'=>4]);++$paginas;
    array_push($semNome,...array_column($p['itens'],'codigo'));
    $cursor=$p['proximo_apos'];
    $check($paginas<20,'avançar cursor');
} while ($cursor!==null);
if ($modo==='base') {
    $check(!array_diff($alvos,$semNome),'26 ausentes na base');
    echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'codigos_pedido_sem_nome'=>count(array_intersect($alvos,$semNome)),'perfil_sha256'=>hash('sha256',$antes)]);
    return;
}
$check(!array_intersect($alvos,$semNome),'26 ausências resolvidas');
$check(in_array('laboratorio-414-sem-registro',$semNome,true),'desconhecido legítimo');
foreach ($codigos as $i=>$codigo) {
    $f=F3Base_Catalogo_Aparelhos::resolver($codigo,[]);
    $check(($f['nome_comercial']??'')===$nomes[$i],$codigo);
    $check(!empty($f['marca']) && preg_match('/^20[0-9]{2}$/D',$f['ano_lancamento']) && (float)$f['preco_atual_estimado_brl']>0
        && in_array($f['faixa_sugerida'],['entrada','intermediário','topo'],true) && in_array($f['linha_premium'],['sim','não'],true),'ficha '.$codigo);
}
$consulta=$run('sessao-detalhar',['sessao'=>$id('moto e6s'),'segmento'=>'somente_testes']);
$linha=$consulta['sessoes'][0]??[];
$campos=['marca'=>'Motorola','nome_comercial'=>'Moto E6s','ano_lancamento'=>'2020','preco_atual_estimado_brl'=>'239.00','faixa_aparelho'=>'entrada','linha_premium'=>'não'];
foreach ($campos as $campo=>$valor) {$check(($linha[$campo]??null)===$valor,'detalhe '.$campo);}
$check(count($consulta['linhas'])>0,'cronologia preservada');
foreach (['MOTO   E(6S)','MotoE 6s','MoTo g ( P O W E R )  (2022)'] as $nome) {
    $f=F3Base_Catalogo_Aparelhos::resolver($nome,[]);$check(str_starts_with($f['nome_comercial']??'','Moto '),'normalizar '.$nome);
}
$enviado=F3Base_Perfil_Aparelho::normalizar(['modelo'=>'  (Moto  E(6s))  '],'Android',[]);
$check(($enviado['nome_comercial']??'')==='Moto E6s','entrada do navegador com parênteses externos');
$check(F3Base_Catalogo_Aparelhos::resolver('Galaxy S9+',[])['nome_comercial']==='Galaxy S9+','preservar +');
$check(F3Base_Catalogo_Aparelhos::resolver('Galaxy S9',[])['nome_comercial']==='Galaxy S9','variante sem +');
$local=['codigoqa=Marca|Modelo (Q)|2020|100.00|entrada|não','codigoqb=Marca|Modelo Q|2021|120.00|topo|sim'];
$check(empty(F3Base_Catalogo_Aparelhos::resolver('mo delo(q)',$local)['marca']),'colisão de nomes locais');
$check(F3Base_Catalogo_Aparelhos::resolver('codigoqb',$local)['ano_lancamento']==='2021','código local inequívoco');
$check(F3Base_Catalogo_Aparelhos::resolver('mo delo(q)',[$local[0]])['ano_lancamento']==='2020','nome local único');
$check(F3Base_Catalogo_Aparelhos::resolver('SM-A075M',['Galaxy A07 4G=topo'])['faixa_sugerida']==='topo','precedência 413');
$check(F3Base_Catalogo_Aparelhos::resolver('SM-A105M',['Galaxy (A10)=topo'])['faixa_sugerida']==='topo','faixa local por nome');
$hist=['modelo'=>'moto e6s','nome_comercial'=>'Nome histórico','preco_atual_estimado_brl'=>'88.00','faixa_aparelho'=>'topo'];
$check(F3Base_Perfil_Aparelho::para_relatorio($hist)===$hist,'snapshot identificado preservado');
$check($perfilAntes()===$antes,'perfil no banco preservado');
$check($http===0,'consulta sem rede');
$admin=get_current_user_id();wp_set_current_user(0);$check(F3Base_Catalogo_Aparelhos::sem_nome()['codigo']==='sem_permissao','controle administrativo');wp_set_current_user($admin);
echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'testes'=>$checks,
    'codigos_pedido'=>count($codigos),'pendentes_do_pedido'=>0,'paginas'=>$paginas,'sintetico_desconhecido_visivel'=>true,
    'sessao_moto_e6s'=>array_intersect_key($linha,$campos),'perfil_sha256'=>hash('sha256',$antes),'chamadas_http'=>$http],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
