"""Verificação por mutação na árvore real.

Para cada mutação: planta o defeito no arquivo da árvore de desenvolvimento, roda a checagem,
exige que ela ACUSE (código de saída diferente de zero e o padrão esperado na saída), restaura o
arquivo byte a byte e confere a restauração pelo SHA-256. Ao final, grava o resultado em JSON.

Uso: python3 -I mutar.py <lista.json> <saida.json> [id ...]
Formato de cada item: {"id", "arquivo" (relativo à árvore; "+caminho" cria arquivo novo), "de", "para"
(substituição exata, uma ocorrência; "de" vazio acrescenta "para" ao fim), "comando", "espera" (regex)}.
"""
import hashlib
import json
import os
import re
import subprocess
import sys

ARVORE = '/home/claude/work/dev/base-site-core-fator3-1.79.0-fonte'
lista = json.load(open(sys.argv[1], encoding='utf8'))
saida = sys.argv[2]
so = set(sys.argv[3:])
sha = lambda b: hashlib.sha256(b).hexdigest()
amb = dict(os.environ, NO_PROXY='127.0.0.1,localhost', no_proxy='127.0.0.1,localhost',
           NODE_PATH='/opt/npm-tools/node_modules:/home/claude/work/scripts/node/node_modules', PLAYWRIGHT_BROWSERS_PATH='/opt/pw-browsers',
           F3BASE_ALLOW_LOCAL_TESTS='1', F3BASE_CONTINUAR='1')
resultados = []
for m in lista:
    if so and m['id'] not in so:
        continue
    novo = m['arquivo'].startswith('+')
    caminho = os.path.join(ARVORE, m['arquivo'].lstrip('+'))
    original = None if novo else open(caminho, 'rb').read()
    r = {'id': m['id'], 'arquivo': m['arquivo'].lstrip('+'), 'descricao': m.get('descricao', '')}
    try:
        if novo:
            assert not os.path.exists(caminho), 'arquivo já existe'
            open(caminho, 'wb').write(m['para'].encode())
        elif m.get('remover'):
            os.remove(caminho)  # o original está em memória e volta no finally
        else:
            texto = original.decode('utf8')
            if m['de'] == '':
                mutado = texto + m['para']
            else:
                n = texto.count(m['de'])
                assert n == 1, f"'de' ocorre {n} vez(es); precisa ser exatamente 1"
                mutado = texto.replace(m['de'], m['para'])
            open(caminho, 'wb').write(mutado.encode('utf8'))
        p = subprocess.run(m['comando'], shell=True, cwd=ARVORE, env=amb, capture_output=True, text=True, timeout=m.get('timeout', 600))
        out = (p.stdout + p.stderr)
        achou = re.search(m['espera'], out) is not None
        r.update(codigo_de_saida=p.returncode, padrao_encontrado=achou, acusou=(p.returncode != 0 and achou),
                 trecho=(re.search(m['espera'], out).group(0)[:200] if achou else out[-300:]))
    except Exception as e:  # noqa: BLE001
        r.update(acusou=False, erro=str(e)[:300])
    finally:
        if novo:
            if os.path.exists(caminho):
                os.remove(caminho)
            r['restaurado'] = not os.path.exists(caminho)
        else:
            open(caminho, 'wb').write(original)
            r['restaurado'] = sha(open(caminho, 'rb').read()) == sha(original)
    resultados.append(r)
    print(('ACUSOU   ' if r.get('acusou') else 'NÃO ACUSOU'), m['id'].ljust(34), 'rc=' + str(r.get('codigo_de_saida')), 'restaurado=' + str(r['restaurado']), '|', str(r.get('trecho', r.get('erro', '')))[:150].replace('\n', ' '), flush=True)
anteriores = []
if os.path.exists(saida):
    anteriores = [x for x in json.load(open(saida, encoding='utf8')) if x['id'] not in {y['id'] for y in resultados}]
json.dump(anteriores + resultados, open(saida, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
print(f"{sum(1 for x in resultados if x.get('acusou'))}/{len(resultados)} mutações acusadas; todas restauradas: {all(x['restaurado'] for x in resultados)}")
