"""Confere o patch sobre o ZIP da 1.89.0, identificado pelo hash da entrega."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('instalador_1890', type=Path)
args = parser.parse_args()
if hashlib.sha256(args.instalador_1890.read_bytes()).hexdigest() != 'f48d257ab67f04a95dc50af8a3ea31241560380d8e1f740ff4574de84b6ef177':
    raise ValueError('O arquivo informado difere do instalador certificado da base.')
root = Path(__file__).resolve().parents[1]
runtime = root / 'work/plugin/base-site-core-fator3'
with ZipFile(args.instalador_1890) as base:
    antigo = json.loads(base.read('base-site-core-fator3/dados/aparelhos-br.json'))
    # Todos os PHP pré-existentes devem permanecer, exceto os dois literais de versão.
    anterior_php = {p for p in base.namelist() if p.endswith('.php')}
    atual_php = {runtime.name + '/' + p.relative_to(runtime).as_posix() for p in runtime.rglob('*.php')}
    assert anterior_php == atual_php
    for nome in anterior_php:
        conteudo = base.read(nome)
        relativo = nome.split('/', 1)[1]
        if relativo == 'base-site-core-fator3.php':
            conteudo = conteudo.replace(b'Version:           1.89.0', b'Version:           1.89.1').replace('atualização da 1.88.1'.encode(), 'atualização da 1.89.0'.encode())
        if relativo == 'includes/class-f3base-catalogo-aparelhos.php':
            conteudo = conteudo.replace(b"const REVISAO = '2026-11-15.2'", b"const REVISAO = '2026-11-15.3'")
        if (runtime / relativo).read_bytes() != conteudo:
            raise ValueError(f'Mudança de PHP fora do pedido: {relativo}')
novo = json.loads((runtime / 'dados/aparelhos-br.json').read_text())
for indice in ['codigos', 'nomes', 'raizes']:
    for chave, modelo in antigo[indice].items():
        if novo['modelos'][novo[indice][chave]] != antigo['modelos'][modelo]:
            raise ValueError(f'Ficha anterior divergente: {indice}/{chave}')
novos = set(novo['codigos']).difference(antigo['codigos'])
if novos != {'infinix x6525b', 'm7_wifi'}:
    raise ValueError(f'Códigos fora do pedido: {novos}')
print(json.dumps({'base':'1.89.0', 'alvo':'1.89.1', 'novos':sorted(novos), 'codigos_preservados':len(antigo['codigos']), 'nomes_preservados':len(antigo['nomes']), 'raizes_preservadas':len(antigo['raizes']), 'arquivos_php_conferidos':len(anterior_php)}))
