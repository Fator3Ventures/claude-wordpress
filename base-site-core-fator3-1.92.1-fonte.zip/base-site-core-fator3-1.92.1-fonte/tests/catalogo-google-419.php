<?php
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type()!=='local' || DB_NAME!=='core190base') {
    throw new RuntimeException('WP local exclusivo do ensaio.');
}
function exigir_419($x,$id) { if (!$x) { throw new RuntimeException($id); } }
$codigos=json_decode(file_get_contents(__DIR__.'/../reference/419/codigos-frota.json'),true,512,JSON_THROW_ON_ERROR);
$ausentes=[];
foreach($codigos as $codigo) {
    $google=F3Base_Catalogo_Aparelhos::google_play($codigo);
    if (!$google) { $ausentes[]=strtolower($codigo); }
    else {
        exigir_419(!empty($google['nome_comercial']) && isset($google['marca'],$google['device']),$codigo);
        exigir_419(!array_intersect(['ano_lancamento','preco_atual_estimado_brl','faixa_sugerida','linha_premium'], array_keys($google)),$codigo);
    }
    $f=F3Base_Catalogo_Aparelhos::resolver($codigo,[]);
    exigir_419(!empty($f['nome_comercial']) && !empty($f['preco_atual_estimado_brl']), 'camada curada: '.$codigo);
}
exigir_419($ausentes===['220333qpg','2606frn72l','m2006c3lii','tecno kl4h'],'ausentes do Google');
$atuais=['lm-x525','m8_wifi','rmx3938','sm-j600gt'];
foreach ([...$atuais,'qa-fora-das-duas-bases'] as $codigo) {
    $chave=md5('190-aparelho:'.$codigo);
    exigir_419(F3Base_Perfil_Aparelho::gravar('teste',$chave,$chave,time(),['modelo'=>$codigo]),'gravar');
    $perfil=F3Base_Perfil_Aparelho::normalizar(['modelo'=>$codigo,'memoria_gb'=>8,'nucleos'=>8],'Android',[]);
    $slack=F3Base_Perfil_Aparelho::para_slack(['perfil_aparelho_ref'=>['sessao'=>$chave,'visitante'=>$chave,'classe'=>'teste']]);
    if ($codigo==='lm-x525') {
        exigir_419(($perfil['nome_comercial']??'')==='LG Q60' && $perfil['ano_lancamento']==='2019' && $perfil['preco_atual_estimado_brl']==='259.00','ficha LG');
    } elseif ($codigo!=='qa-fora-das-duas-bases') {
        exigir_419(($perfil['identificacao_fonte']??null)==='google_play' && $perfil['faixa_aparelho']==='desconhecido'
            && !isset($perfil['ano_lancamento']) && !isset($perfil['preco_atual_estimado_brl']),$codigo);
        exigir_419(str_starts_with($slack['Modelo'],$perfil['nome_comercial']) && !str_contains($slack['Modelo'],'R$'), 'slack '.$codigo);
    }
}
$sem=[];$incompletos=[];$cursor='';$paginas=0;
do {
    $r=wp_get_ability('f3base/aparelhos-sem-nome-ler')->execute(['limite'=>2,'apos'=>$cursor]);
    exigir_419(!is_wp_error($r) && $r['ok'] && $r['itens']===$r['sem_nome'] && ++$paginas<10,'paginacao');
    array_push($sem,...array_column($r['sem_nome'],'codigo'));array_push($incompletos,...array_column($r['sem_ficha_comercial'],'codigo'));
    $cursor=$r['proximo_apos'];
} while ($cursor!==null);
exigir_419($sem===['qa-fora-das-duas-bases'] && $incompletos===array_slice($atuais,1),'grupos '.wp_json_encode([$sem,$incompletos]));
wp_set_current_user(0);exigir_419(!F3Base_Catalogo_Aparelhos::sem_nome()['ok'],'permissao');
echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,
    'google_com_nome'=>count($codigos)-count($ausentes),'ausentes_no_google'=>$ausentes,'nomes_curados'=>count($codigos),
    'paginas'=>$paginas,'sem_nome'=>$sem,'sem_ficha_comercial'=>$incompletos,'slack'=>'tres perfis antigos lidos com nomes do Google'],JSON_PRETTY_PRINT);
