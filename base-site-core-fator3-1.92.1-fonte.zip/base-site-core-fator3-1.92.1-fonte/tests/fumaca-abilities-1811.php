<?php
/**
 * Fumaça das habilidades f3base/* somente leitura, dentro da suíte da 1.81.1.
 * Executa cada leitura como administrador com entrada vazia. Falha com exceção, aviso, notice, deprecation
 * do PHP ou _doing_it_wrong em qualquer uma. Grava evidence/1811/<fase>--abilities-fumaca.json.
 */
declare(strict_types=1);
require __DIR__.'/bootstrap-1811.php';
do_action('admin_init');

$atual = null; $achados = [];
set_error_handler(static function (int $n, string $msg, string $arq = '', int $linha = 0) use (&$atual, &$achados): bool {
    if (!(error_reporting() & $n)) { return true; } // respeita o operador @
    $tipo = [E_WARNING=>'warning',E_NOTICE=>'notice',E_DEPRECATED=>'deprecated',E_USER_WARNING=>'user_warning',E_USER_NOTICE=>'user_notice',E_USER_DEPRECATED=>'user_deprecated'][$n] ?? ('e' . $n);
    $achados[] = ['ability' => $atual, 'tipo' => $tipo, 'msg' => mb_substr($msg, 0, 300), 'arquivo' => str_replace(WP_PLUGIN_DIR . '/', '', $arq), 'linha' => $linha];
    return true;
});
add_action('doing_it_wrong_run', static function ($funcao, $mensagem) use (&$atual, &$achados): void {
    $achados[] = ['ability' => $atual, 'tipo' => 'doing_it_wrong', 'msg' => mb_substr($funcao . ': ' . wp_strip_all_tags((string) $mensagem), 0, 300), 'arquivo' => '', 'linha' => 0];
}, 10, 2);
add_filter('doing_it_wrong_trigger_error', '__return_false');

$todas = function_exists('wp_get_abilities') ? wp_get_abilities() : [];
$resumo = ['total' => 0, 'leitura' => 0, 'executadas' => 0, 'ok' => 0, 'erro_controlado' => 0, 'excecao' => 0];
$excecoes = []; $tempos = [];
foreach ($todas as $nome => $ability) {
    if (!str_starts_with((string) $nome, 'f3base/')) { continue; }
    $resumo['total']++;
    $meta = $ability->get_meta();
    $leitura = !empty($meta['annotations']['readonly']);
    if (!$leitura) { continue; }
    $resumo['leitura']++;
    $atual = $nome; $t = microtime(true);
    try {
        $r = $ability->execute([]);
        $resumo['executadas']++;
        if (is_wp_error($r)) { $resumo['erro_controlado']++; }
        elseif (is_array($r) && array_key_exists('ok', $r) && empty($r['ok'])) { $resumo['erro_controlado']++; }
        else { $resumo['ok']++; }
    } catch (Throwable $e) {
        $resumo['excecao']++;
        $excecoes[] = ['ability' => $nome, 'classe' => get_class($e), 'msg' => mb_substr($e->getMessage(), 0, 300), 'arquivo' => str_replace(WP_PLUGIN_DIR . '/', '', $e->getFile()), 'linha' => $e->getLine()];
    }
    $tempos[$nome] = (int) round((microtime(true) - $t) * 1000);
}
$atual = null;
arsort($tempos);
// Agrupa achados por (tipo, arquivo, linha, msg normalizada).
$grupos = [];
foreach ($achados as $a) {
    $k = $a['tipo'] . '|' . $a['arquivo'] . ':' . $a['linha'] . '|' . preg_replace('/\d+/', 'N', $a['msg']);
    $grupos[$k] ??= ['tipo' => $a['tipo'], 'onde' => $a['arquivo'] . ':' . $a['linha'], 'msg' => $a['msg'], 'n' => 0, 'abilities' => []];
    $grupos[$k]['n']++; $grupos[$k]['abilities'][$a['ability'] ?? '-'] = true;
}
foreach ($grupos as &$g) { $g['abilities'] = array_slice(array_keys($g['abilities']), 0, 6); } unset($g);
$saida = ['versao' => F3BASE_PLUGIN_VERSAO, 'php' => PHP_VERSION, 'wordpress' => get_bloginfo('version'), 'resumo' => $resumo, 'excecoes' => $excecoes, 'avisos_php' => array_values($grupos), 'mais_lentas_ms' => array_slice($tempos, 0, 8, true)];
check($resumo['excecao']===0,'fumaca_nenhuma_excecao',$excecoes);
check($resumo['leitura']>0&&$resumo['executadas']===$resumo['leitura'],'fumaca_executou_todas_as_leituras',$resumo);
$semAviso=static function(string $tipo)use($grupos){return array_values(array_filter($grupos,static fn($g)=>$g['tipo']===$tipo));};
check(!array_filter($grupos,static fn($g)=>in_array($g['tipo'],['warning','user_warning'],true)),'fumaca_sem_warning_php',array_values($grupos));
check(!array_filter($grupos,static fn($g)=>in_array($g['tipo'],['notice','user_notice'],true)),'fumaca_sem_notice_php',array_values($grupos));
check(!array_filter($grupos,static fn($g)=>in_array($g['tipo'],['deprecated','user_deprecated'],true)),'fumaca_sem_deprecation_php',array_values($grupos));
check($semAviso('doing_it_wrong')===[],'fumaca_sem_doing_it_wrong',$semAviso('doing_it_wrong'));
check(!array_filter($grupos,static fn($g)=>!in_array($g['tipo'],['warning','user_warning','notice','user_notice','deprecated','user_deprecated','doing_it_wrong'],true)),'fumaca_sem_outro_erro_php',array_values($grupos));
evidence('abilities-fumaca',['resumo'=>$resumo,'excecoes'=>$excecoes,'avisos'=>array_values($grupos),'mais_lentas_ms'=>array_slice($tempos,0,8,true)]);
