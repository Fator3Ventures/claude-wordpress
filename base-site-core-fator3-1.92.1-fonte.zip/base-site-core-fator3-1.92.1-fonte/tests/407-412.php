<?php
/** WordPress descartável, sem rede externa. Executar com wp eval-file. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type()!=='local' || !in_array(DB_NAME,['core186','fresh187','core187up','fresh1871','direct1871','fresh1872','direct1872','from1870','fresh1872b','direct1872b','from1870b','basepatch1872b','corefresh1873','coredirect1873','corefrom1870','corefrom1871'],true)) {
    throw new RuntimeException('Ambiente local descartável obrigatório');
}
wp_set_current_user(1);
global $wpdb;
$teste=['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'versao'=>F3BASE_PLUGIN_VERSAO];
$check=static function(bool $ok,string $id) use (&$teste) {
    if (!$ok) { throw new RuntimeException('Falhou: '.$id); }
    $teste['verificacoes'][]=$id;
};
$run=static function(string $rota,array $args) {
    $r=wp_get_ability('f3base/'.$rota)->execute($args);
    if (is_wp_error($r)) { throw new RuntimeException($rota.' '.$r->get_error_message()); }
    return $r;
};
$check(F3BASE_PLUGIN_VERSAO==='1.87.3','versao');
$comum=['cache_reaquecimento','carregamento_destinos','classificacao_acessos','gsc','primeira_resposta'];
$a=['pipedrive','email_site','email_historico','ga4_acervo'];
$mais=['email_novo_lead','anuncios_meta','meta_ads','meta_monitoramento','qualidade'];
$perfis=['A'=>$a,'B'=>[...$a,...$mais,'pipedrive_operacao'],'C'=>[...$a,...$mais,'anuncios_linkedin','google_ads_acervo','gsc_consultas'],'D'=>['email_site','ga4_acervo'],'E'=>['pipedrive','email_historico']];
$ids=array_unique([...$comum,...array_merge(...array_values($perfis))]);
$antes=[];foreach ($ids as $id) { $antes[$id]=get_option('f3base_'.$id,null); }
$agenda=get_option('cron');
try {
    foreach ($perfis as $perfil=>$ativos) {
        foreach ($ids as $id) {
            $on=in_array($id,[...$comum,...$ativos],true);
            $valor=F3Base_Options::ler('f3base_'.$id);
            $valor=is_array($valor)?$valor:[];
            $valor['ativo']=$on;
            if ($id==='meta_monitoramento') { $valor['avisar']=$on; }
            if ($id==='anuncios_linkedin') { $valor=['integracoes'=>['principal'=>['ativo'=>$on]+F3Base_Linkedin_Integracoes::padrao()]]; }
            if ($id==='google_ads_acervo') { $valor['conexao']='laboratorio';$valor['conta_id']='1234567890'; }
            update_option('f3base_'.$id,$valor);
        }
        F3Base_Email_Historico::conferir_agenda_1();
        $regras=$run('aplicabilidade-ler',[])['regras'];
        $esperado=$perfil!=='D';$hist=$regras['email_historico'];
        $check($hist['resultado']===$esperado && (bool)wp_next_scheduled(F3Base_Email_Historico::HOOK)===$esperado,'regra_agenda_'.$perfil);
        foreach ($ids as $id) {
            $alvo=in_array($id,[...$comum,...$ativos],true);
            $check($regras[$id]['resultado']===$alvo,$perfil.'_resultado_'.$id);
            $check(isset($regras[$id]['opcoes'],$regras[$id]['condicao'],$regras[$id]['revisao']),$perfil.'_regra_'.$id); }
        $teste['perfis'][$perfil]=['historico'=>$hist['resultado'],'revisao'=>$hist['revisao'],'regras'=>count($regras),'tamanho_bytes'=>[]];
        foreach (['como-usar','saude-ler'] as $rota) {
            $r=$run($rota,['compacto'=>true]);$bytes=strlen(wp_json_encode($r));
            $check($bytes<16384 && isset($r['versao'],$r['contrato'],$r['erros_ativos'],$r['esperas']['contagens']) && !isset($r['agenda'],$r['assuntos']),$perfil.'_'.$rota);
            $teste['perfis'][$perfil]['tamanho_bytes'][$rota]=$bytes;
        }
    }
    $d=$run('como-usar',['incluir'=>['aplicabilidade']]);
    $check(isset($d['aplicabilidade']['email_historico']['esperas_observadas']),'manual_com_regras');
    foreach ([null,['exemplo'=>'teste']] as $i=>$v) {
        $check(is_array((new ReflectionMethod(F3Base_Anuncio_Entrega::class,'estado'))->invoke(null,['anuncio_entrega'=>$v])),'anuncio_entrega_'.$i);
        $check(is_string(F3Base_Analise::origem_imutavel($v)),'automacao_evidencia_'.$i);
        $r=F3Base_Sessao_Contexto::apresentar(['contexto_cifrado'=>$v,'contexto_publico'=>$v,'sessao'=>'s','classe'=>'teste']);
        $check(empty($r['ip']) && is_array($r),'contexto_cifrado_publico_'.$i);
        $check(is_array(F3Base_Contato_Entregas::aprovacao(['captura'=>'aceito','entrega'=>$v])),'entrega_'.$i);
        $check(is_array(F3Base_Google_Acervo::projecao($v)),'google_ads_'.$i);
        $check(is_array(F3Base_Email_Historico::projecao($v)) && is_array(F3Base_Email_Historico::conferir(['historico'=>$v],[])),'historico_'.$i);
        $check(F3Base_Json_Campo::texto($v,'link_destino')==='','link_destino_'.$i);
        $check(F3Base_Contato_Comunicacao::abrir($v)===null,'pedido_'.$i);
        $check((new ReflectionMethod(F3Base_Formulario_Tentativas::class,'abrir'))->invoke(null,$v)===null,'valores_'.$i);
        // Leitura do campo pelo trabalho de eliminação. A atividade já removida impede qualquer chamada remota.
        $real=$wpdb;
        $wpdb=new class($real,$v) {
            public string $last_error='';
            public function __construct(private $base,private $v) {}
            public function __get($n){return $this->base->$n;}
            public function __call($n,$a){return $this->base->$n(...$a);}
            public function get_results($q,$output){return [['atividade_id'=>5,'atividade_prova'=>$this->v,'atividade_estado'=>'confirmada','enviado_em'=>0]];}
        };
        $j=['criados'=>['lead'=>'laboratorio']];$limpo=['removidos'=>['atividade_email_5']];$pendente=false;$revisao=false;
        try { (new ReflectionMethod(F3Base_Pipedrive_Eliminacao::class,'email_proprio'))->invokeArgs(null,[['record_id'=>'teste','conta'=>'teste'],&$j,&$limpo,&$pendente,&$revisao]); }
        finally { $wpdb=$real; }
        $check($j['provas_criacao']['atividade_email_5']===($v??[]),'atividade_prova_'.$i);
    }
    $check(F3Base_Json_Campo::ler('{"ok":true}','teste')===['ok'=>true] && F3Base_Json_Campo::ler('{','teste',$valido)===[] && !$valido,'json_invalido_com_aviso');
    $cifra=F3Base_Contato_Comunicacao::cifrar(['ok'=>true]);$check(F3Base_Contato_Comunicacao::abrir($cifra)===['ok'=>true],'cifra_valida');
    foreach (F3Base_Fila::RECORRENCIAS as $hook=>$intervalo) {
        wp_clear_scheduled_hook($hook);wp_clear_scheduled_hook($hook,F3Base_Fila::ANTECIPAR);
        $hora=time()+400;wp_schedule_single_event($hora,$hook);wp_schedule_single_event($hora+1800,$hook);
        $check(F3Base_Fila::periodicidade($hook) && wp_get_schedule($hook)===$intervalo && wp_next_scheduled($hook)===$hora && !wp_get_scheduled_event($hook,[],$hora+1800),'migra_'.$hook);
        $escritas=0;$contador=static function()use(&$escritas){++$escritas;};add_action('updated_option', $escuta=static function($n)use($contador){if($n==='cron'){$contador();}});
        for($i=0;$i<12;$i++){F3Base_Fila::periodicidade($hook);F3Base_Fila::agendar($hook,$hora+200);}
        $check($escritas===0,'ocioso_'.$hook);
        $prazo=time()+45;F3Base_Fila::agendar($hook,$prazo);F3Base_Fila::agendar($hook,$prazo+10);
        $check($escritas===1 && wp_next_scheduled($hook,F3Base_Fila::ANTECIPAR)===$prazo && wp_next_scheduled($hook)===$hora,'urgente_'.$hook);
        remove_action('updated_option',$escuta);
    }
    $ini=ini_get('memory_limit');ini_set('memory_limit','128M');
    $periodo=['de'=>wp_date('Y-m-d',strtotime('-89 days')),'ate'=>wp_date('Y-m-d')];
    foreach (F3Base_Relatorios::VISOES as $visao) {
        $r=$run('relatorios-integrados-ler',['visao'=>$visao]+$periodo);
        $check(!empty($r['ok'])||!empty($r['codigo']),'relatorio_'.$visao);
        $teste['visoes'][$visao]=$r['ok']?'ok':$r['codigo'];
    }
    // Exercitar o limite com um contato exclusivo da fixture, depois removê-lo.
    $t=F3Base_Leads_Repositorio::tabela();$id=md5('teste-187-custo-'.wp_generate_uuid4());
    $row=['record_id'=>$id,'nome'=>'Teste de orçamento','metodo'=>'formulario','classe_trafego'=>'teste','criado_em'=>current_time('mysql',true),'atualizado_em'=>current_time('mysql',true),'pagina'=>'/teste/','dados'=>'{}','anexos'=>'[]','payload_hash'=>hash('sha256',$id)];
    $check($wpdb->insert($t,$row)!==false,'fixture_de_memoria');
    try {
        $wpdb->query($wpdb->prepare("UPDATE %i SET dados=REPEAT('x',4194304) WHERE record_id=%s",$t,$id));
        $r=$run('relatorios-integrados-ler',['visao'=>'resultados']+$periodo);
        $check(($r['codigo']??'')==='limite_memoria' && $r['periodo']===$periodo && $r['visao']==='resultados','recusa_nomeada_128MiB');
        $query_anterior=$_GET;
        try {
            $_GET=['page'=>'f3base-medicao','area'=>'conversao','visao'=>'resultados']+$periodo;
            ob_start();
            try { F3Base_Medicao_Interface::render(); $html=ob_get_contents(); }
            finally { ob_end_clean(); }
            $check(str_contains($html,'role="alert"') && str_contains($html,'limite_memoria'),'painel_exibe_limite_memoria');
        } finally { $_GET=$query_anterior; }
        $teste['orcamento']=$r['diagnostico'];$teste['pico_processo_bytes']=memory_get_peak_usage(true);
    } finally { $wpdb->delete($t,['record_id'=>$id]);ini_set('memory_limit',$ini); }
    $d=$run('documentacao-ler',['arquivo'=>'docs/RELEASE-1.87.3.md','limite'=>3]);
    $check($d['sha256']===hash_file('sha256',F3BASE_PLUGIN_DIR.'docs/RELEASE-1.87.3.md') && $d['proxima_linha']>0,'documentacao');
    wp_set_current_user(0);$r=wp_get_ability('f3base/aplicabilidade-ler')->execute([]);
    $check(is_wp_error($r) || empty($r['ok']),'permissao_de_leitura');
} finally {
    wp_set_current_user(1);
    foreach ($antes as $id=>$v) {if($v===null){delete_option('f3base_'.$id);}else{update_option('f3base_'.$id,$v);}}
    update_option('cron',$agenda);
}
echo wp_json_encode($teste,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
