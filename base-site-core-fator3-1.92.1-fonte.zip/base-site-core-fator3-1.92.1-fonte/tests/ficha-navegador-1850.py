from pathlib import Path
import json,os,sys
from playwright.sync_api import sync_playwright
doc=json.loads(Path(sys.argv[1]).read_text())
url='http://127.0.0.1:8137'
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ['F3BASE_CHROMIUM'],args=['--no-sandbox'])
 tab=browser.new_page(viewport={'width':1280,'height':850})
 tab.goto(url+'/wp-login.php')
 tab.locator('#user_login').fill('qa_admin');tab.locator('#user_pass').fill(doc['password']);tab.locator('#wp-submit').click()
 tab.goto(url+'/wp-admin/admin.php?page=f3base-leads&record_id='+doc['id'])
 btn=tab.get_by_role('button',name='Consultar anúncio na plataforma')
 btn.wait_for(timeout=15000);btn.click()
 tab.get_by_text('Última consulta em',exact=False).first.wait_for(timeout=12000)
 assert '#f3base-anuncio-origem' in tab.url
 assert tab.get_by_role('button',name='Consultar anúncio na plataforma').count()==1
 Path(sys.argv[2]).write_text(json.dumps({'wordpress':'7.1.4','core':'1.85.0','browser':browser.version,'url':'ficha do contato sintético','checks':{'login_administrador':True,'ficha_mostra_consulta':True,'post_nonce_redireciona_para_o_mesmo_registro':doc['id'] in tab.url,'ultima_consulta_visivel':True}},indent=2))
 browser.close()
