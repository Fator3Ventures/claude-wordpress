import csv,json,gzip,sys,hashlib
from collections import defaultdict,Counter
from pathlib import Path
from zipfile import ZipFile
p=Path(__file__).resolve().parents[2];sys.path.insert(0,str(p/'build'))
from criterios_aparelhos import protected_reason,is_market,brand_terms,commercial_candidate
def official(path,sha):
 assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
 with ZipFile(path) as f:
  return {k:v for n in f.namelist() if '/dados/google-play/' in n and n.endswith('.json.gz') for k,v in json.loads(gzip.decompress(f.read(n))).items()}
a=official(Path(sys.argv[1]),'f780f372f3ffe1417a240eb94f9f2aa7329f5a1d0fb3e270ff6c600d40758f77')
b=official(Path(sys.argv[2]),'28b2ec8cfc6e24622b2f30cae42582475ff246be493c2b604c86403f5964d7b5')
rt=p/'work/plugin/base-site-core-fator3/dados'
c={k:v for f in (rt/'google-play').glob('*.gz') for k,v in json.loads(gzip.decompress(f.read_bytes())).items()}
curated=json.loads((rt/'aparelhos-br.json').read_text())['codigos']
groups=defaultdict(list)
for row in list(csv.reader(open(p/'reference/417/supported_devices.csv',encoding='utf-16')))[1:]:
 if row[3].strip():groups[' '.join(row[3].lower().split())].append([v.strip() for v in row])
terms=brand_terms(groups);audit=[];extra=[]
with (p/'reference/427/decisoes-device.csv').open() as f:
 for r in csv.DictReader(f):
  if r['criterio']!='nome_google':continue
  k=r['modelo']; old,prior,now=a[k][1],b[k][1],c[k][1]
  assert (old,prior)==(r['nome_anterior'],r['nome_entregue']) and old!=prior and now in (old,prior),k
  cohort='sim' if ' ' in old else 'não'
  reasons=[]
  guard=protected_reason(k,old,terms)
  if guard:reasons.append(guard)
  if is_market(prior):reasons.append('territorio')
  if not reasons and now==old:
   reasons.append('device_conflitante' if c[k][3]=='modelo_ambiguo' else 'candidato_sem_evidencia_comercial')
  if now==prior:assert not reasons;reasons=['codigo_tecnico_e_consenso']
  audit.append([k,old,prior,now,'desfeita' if now==old else 'mantida',' + '.join(reasons),cohort,'sim' if k in curated else 'não'])
codes={r[0] for r in audit}; assert len(codes)==412
for k,v in sorted(c.items()):
 if v!=b[k] and k not in codes:
  extra.append([k,a[k][1],b[k][1],v[1],b[k][3],v[3]])
def write(name,header,rows):
 with (p/'reference/428'/name).open('w',newline='') as out:
  w=csv.writer(out);w.writerow(header);w.writerows(rows)
write('revisao-412.csv',['modelo','nome_1910','nome_1920','nome_1921','decisao','motivo','grupo_211','ficha_curada'],audit)
write('outras-diferencas.csv',['modelo','nome_1910','nome_1920','nome_1921','criterio_1920','criterio_1921'],extra)
print(Counter(r[4] for r in audit),Counter(r[5] for r in audit),Counter(r[7] for r in audit if r[6]=='sim'))
print('outras diferencas',len(extra),'nomes diferentes',sum(r[2]!=r[3] for r in extra))
