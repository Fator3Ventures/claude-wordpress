<?php
declare(strict_types=1);
$mode = $argv[1];
require getenv('F3BASE_SITE');
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME, 'core_428_')) { exit(2); }
wp_set_current_user(1);
$checks = [];
function verify428(string $label, bool $result): void {
    global $checks;
    $checks[$label] = $result;
    if (!$result) { fwrite(STDERR, "Falhou: $label\n"); }
}
$raw = ['modelo'=>'motorola one macro','nome_comercial'=>'moto g(8) play','device'=>'lima','identificacao_fonte'=>'google_play','identificacao_criterio'=>'nome_google','faixa_aparelho'=>'intermediário'];
$id = md5('428-retido');
$ref = ['sessao'=>$id,'visitante'=>$id,'classe'=>'teste'];
$ability = wp_get_ability('f3base/aparelhos-sem-nome-ler');
$local = F3Base_Catalogo_Aparelhos::do_site();
if ($mode === 'base' || $mode === 'limpa') {
    verify428('gravar_perfil_teste', F3Base_Perfil_Aparelho::gravar('teste',$id,$id,time(),$raw));
}
$view = $ability->execute(['apos'=>'motorola one macq','limite'=>1]);
if (is_wp_error($view)) { throw new RuntimeException($view->get_error_code().' '.$view->get_error_message()); }
if (is_string($view)) { $view = json_decode($view, true, 512, JSON_THROW_ON_ERROR); }
$transport = 'ability_wordpress';
if (($view['error_code'] ?? '') === 'profile_denied' && defined('WP_PLUGIN_DIR') && DB_NAME === 'core_428_upgrade') {
    // A CLI local não representa uma conexão MCP. Provar o callback de domínio e registrar o gate.
    $transport = 'callback_core_apos_recusa_de_perfil_MCP_na_CLI';
    $view = F3Base_Catalogo_Aparelhos::sem_nome(['apos'=>'motorola one macq','limite'=>1]);
}
$item = $view['sem_ficha_comercial'][0] ?? $view['data']['sem_ficha_comercial'][0] ?? [];
if (empty($item)) { fwrite(STDERR, json_encode($view, JSON_UNESCAPED_UNICODE)."\n"); }
if ($mode === 'base') {
    verify428('controle_1920', F3BASE_PLUGIN_VERSAO === '1.92.0' && ($item['nome_comercial']??'')==='moto g(8) play');
} else {
    verify428('versao', F3BASE_PLUGIN_VERSAO === '1.92.1' && F3Base_Catalogo_Aparelhos::REVISAO === '2026-11-17.3');
    verify428('ability', ($item['nome_comercial']??'') === 'motorola one macro' && $item['device'] === 'lima');
    $stored = F3Base_Perfil_Aparelho::ler($ref);
    $projected = F3Base_Perfil_Aparelho::para_relatorio($stored);
    verify428('perfil_retido', $projected['nome_comercial']==='motorola one macro' && $projected['faixa_aparelho']==='intermediário' && $stored===$raw);
    $withdrawn = F3Base_Perfil_Aparelho::para_relatorio(['modelo'=>'hlte510z','nome_comercial'=>'Hisense H20','device'=>'HSSDM636QC','identificacao_fonte'=>'google_play','identificacao_criterio'=>'familia_google']);
    verify428('familia_retirada', !isset($withdrawn['nome_comercial']) && $withdrawn['modelo']==='hlte510z');
    foreach (['moto g96 5g'=>'moto g96 5g','moto g57'=>'moto g57','moto g57 power'=>'moto g57 power','zte 8045'=>'ZTE 8045','zte blade a5 2019ru'=>'ZTE Blade A5 2019RU','25062rn2da'=>'Redmi 15','lm-x420'=>'LG K40'] as $code=>$expected) {
        $value=F3Base_Perfil_Aparelho::normalizar(['modelo'=>$code],'Android',$local);
        verify428($code, strcasecmp($value['nome_comercial'] ?? '',$expected)===0);
    }
    verify428('variante_inedita', (F3Base_Catalogo_Aparelhos::google_play('25062RN2DZ')['nome_comercial']??'')==='Redmi 15');
    verify428('codigo_novo_sem_prova', empty(F3Base_Catalogo_Aparelhos::google_play('moto qa 999 power')));
    verify428('regra_local', F3Base_Catalogo_Aparelhos::resolver('motorola one macro',['motorola one macro=Marca|Nome Local|2020|100|entrada|não'])['nome_comercial']==='Nome Local');
    $file = fopen(__DIR__.'/../../reference/428/revisao-412.csv', 'rb');
    $header = fgetcsv($file, 0, ',', '"', '');
    $count=0;
    while (($values=fgetcsv($file, 0, ',', '"', '')) !== false) {
        $row=array_combine($header,$values);
        if (F3Base_Catalogo_Aparelhos::google_play($row['modelo'])['nome_comercial']!==$row['nome_1921']) {
            throw new RuntimeException('Divergência: '.$row['modelo']);
        }
        ++$count;
    }
    verify428('auditoria_412_no_runtime', $count===412);
    wp_set_current_user(0);
    $denied = $ability->execute(['limite'=>1]);
    verify428('permissao', (is_wp_error($denied) || empty($denied['success'])) && (F3Base_Catalogo_Aparelhos::sem_nome()['codigo']??'')==='sem_permissao');
}
echo json_encode(['wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'versao'=>F3BASE_PLUGIN_VERSAO,'item'=>$item,'transporte'=>$transport,'checks'=>$checks,'ok'=>!in_array(false,$checks,true)],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
exit(in_array(false,$checks,true)?1:0);
