# Reprodução do pedido 428 no WordPress

Use duas instalações locais descartáveis com bases core_428_clean e core_428_upgrade, WP_ENVIRONMENT_TYPE local, PHP com mysqli, mbstring e zip, e WordPress 7.1.4. Bloqueie saídas HTTP e e-mail no laboratório. A instalação limpa começa sem Core e isolada dos acompanhantes. A de atualização usa as versões relacionadas no relatório. Defina F3BASE_SITE para o wp-load.php absoluto de cada instalação e F3_MANIFEST_428 para evidence/1921/runtime-manifest.json.

Na instalação limpa, execute em processos PHP distintos:

```sh
php tests/428/instalacao.php instalar /caminho/base-site-core-fator3-1.92.1-instalador.zip
php tests/428/instalacao.php conferir 1.92.1 limpa
php tests/428/wordpress.php limpa
php build/gerar-catalogo-abilities.php --check
```

Na instalação de atualização, instale e ative o ZIP oficial 1.92.0. Execute `php tests/428/wordpress.php base` para gravar o perfil sintético e reproduzir a troca original. Em processos novos, execute o modo instalar com o ZIP 1.92.1, conferir com 1.92.1 e origem 1.92.0, e `php tests/428/wordpress.php atualizacao`. O ensaio confere a linha do aparelho na saída administrativa, o perfil histórico, as fichas brasileiras e a projeção das 412 linhas no runtime. A CLI com MCP ativo recebe profile_denied pela ausência de uma conexão remota; nesse cenário o teste registra o gate e verifica o callback de domínio. No WordPress isolado ele exercita a ability diretamente. A leitura remota autenticada é registrada em evidências próprias.

A lista de diferenças históricas do relatório vem dos bytes da 1.91.0 e 1.92.0 indicados na seção 1 do relatório e do índice da 1.92.1. O script auditar-historico.py aceita os dois ZIPs desses releases como parâmetros a partir da raiz do fonte. O primeiro argumento é o fonte 1.91.0 e o segundo é o instalador 1.92.0. Ele regenera os dois CSVs de revisão histórica.
