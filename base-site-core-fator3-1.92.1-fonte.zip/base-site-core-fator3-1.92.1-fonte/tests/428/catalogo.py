"""Garantias históricas nos bytes do pacote e cenários novos em um snapshot sintético."""
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import csv
import gzip
import hashlib
import json
import runpy
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'build'))
from criterios_aparelhos import is_market

def buckets(files):
    return {code: values for data in files for code, values in json.loads(gzip.decompress(data)).items()}

catalog = ROOT / 'work/plugin/base-site-core-fator3/dados/google-play'
if len(sys.argv) > 1:
    with ZipFile(sys.argv[1]) as z:
        actual = buckets(z.read(n) for n in z.namelist() if '/dados/google-play/' in n and n.endswith('.gz'))
else:
    actual = buckets(p.read_bytes() for p in catalog.glob('*.gz'))
with (ROOT / 'reference/428/revisao-412.csv').open() as fp:
    cases = list(csv.DictReader(fp))
with (ROOT / 'reference/427/decisoes-device.csv').open() as fp:
    historical = {r['modelo']: r for r in csv.DictReader(fp) if r['criterio'] == 'nome_google'}
assert len(cases) == len(historical) == len({r['modelo'] for r in cases}) == 412
assert sum(' ' in row['nome_anterior'] for row in historical.values()) == 211
for row in cases:
    code = row['modelo']
    previous = historical[code]
    assert [row['nome_1910'], row['nome_1920']] == [previous['nome_anterior'], previous['nome_entregue']], code
    assert row['nome_1910'] != row['nome_1920']
    expected = row['nome_1920'] if row['decisao'] == 'mantida' else row['nome_1910']
    assert expected == actual[code][1] == row['nome_1921'] and row['motivo'], code
    if ' ' in row['nome_1910'] or is_market(row['nome_1920']):
        assert row['decisao'] == 'desfeita' and actual[code][1] == row['nome_1910'], code
assert all(not is_market(v[1]) for v in actual.values() if v[3] == 'nome_google')
assert all(actual[k][1].casefold() == k for k in ['motorola one macro','moto g96 5g','moto g57','moto g57 power','moto g06 power','moto e(7i) power','nokia c12','zte 8045','zte blade a5 2019ru','motorola edge 20'])
gen = runpy.run_path(str(ROOT / 'build/gerar-google-play.py'))
with TemporaryDirectory() as temp:
    tmp = Path(temp)
    compile_index = gen['compile_index']
    compile_index.__globals__.update(ROOT=tmp, DEST=tmp/'output')
    specs = [
        ('ZX-100', 'ZX-100', 'Orion Summit 9', 'Orion Summit 9'),
        ('ORION_X900', 'ORION_X900', 'Other 9', 'ORION_X900'),
        ('One Horizon 9', 'One Horizon 9', 'Different 9', 'One Horizon 9'),
        ('Pixel-900', 'Pixel-900', 'Different 9', 'Pixel-900'),
        ('XT999Power', 'XT999Power', 'Different 9', 'XT999Power'),
        ('AB-F123', 'AB_F123', 'Different 9', 'AB_F123'),
        ('SPX999', 'SPX999', 'Ukraine, Kazakhstan, Azerbaijan', 'SPX999'),
        ('QQ-85', 'QQ-85', 'Northern Europe', 'QQ-85'),
        ('QQ-86', 'QQ-86', 'QQ-87', 'QQ-86'),
        ('XX-123', 'XX-123', 'Brazil Phone 12', 'Brazil Phone 12'),
    ]
    rows = []
    for i,(code, own, other, expected) in enumerate(specs):
        rows.extend([('Orion', own, str(i), code),('Orion', other, str(i),f'TECH-{i}B')])
    rows += [('Orion','AA-123','shared','AA-123'),('Orion','Beta Phone','shared','Tech-99'),('Orion','Gamma Max','shared','Gamma Max'),
             ('Orion','EU、UK、AP','direct','RT-320'),('Orion','India/Srilanka/Bangladesh/GCC','direct','RT-320'),
             ('Orion','AA-124','multi','AA-124'),('OtherBrand','Another Phone','multi','TECH-314')]
    snapshot = tmp/'fixture.csv'
    with snapshot.open('w', encoding='utf-16', newline='') as fp:
        writer=csv.writer(fp)
        writer.writerow(['Retail Branding','Marketing Name','Device','Model'])
        writer.writerows(rows)
    compile_index(snapshot, 'teste')
    got = buckets(p.read_bytes() for p in (tmp/'output').glob('*.gz'))
    for code, own, other, expected in specs:
        assert got[code.casefold()][1] == expected, (code, got[code.casefold()])
    assert got['aa-123'][3] == got['aa-124'][3] == 'modelo_ambiguo'
    assert got['rt-320'][1:] == ['RT-320', 'direct', 'modelo_sem_nome_publicado']
print(json.dumps({'ok':True, 'modelos':len(actual),'coorte_com_espaco':211,'decisoes':dict(Counter(r['decisao'] for r in cases)), 'cenarios_novos':len(specs)+3}))
