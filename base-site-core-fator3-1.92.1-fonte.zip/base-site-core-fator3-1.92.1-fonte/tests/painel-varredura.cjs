// Varredura do painel do Site Core num laboratório local.
// Uso: node varrer-admin.cjs <base-url> <arquivo-senha> <dir-saida> [largura,...]
// Para cada tela: screenshot de página inteira, erros de console/JS/HTTP, métricas de DOM e axe-core.
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const [base, arquivoSenha, saida, largurasArg] = process.argv.slice(2);
const larguras = (largurasArg || '1440,390').split(',').map(Number);
const senha = fs.readFileSync(arquivoSenha, 'utf8');
const axeFonte = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
fs.mkdirSync(saida, { recursive: true });

const P = 'base-site-core-fator3';
const secoes = ['inicio', 'conexoes', 'contato', 'medicao-tags', 'medicao-meta', 'medicao-coleta', 'medicao-gsc', 'medicao-ga4', 'medicao-clarity', 'medicao-testes', 'consentimento', 'privacidade', 'conteudo', 'seo'];
const telas = [
  ...secoes.map((s) => ({ id: 'config-' + s, url: `/wp-admin/admin.php?page=${P}&secao=${s}` })),
  { id: 'aba-tecnica', url: `/wp-admin/admin.php?page=${P}&aba=tecnica` },
  { id: 'aba-operacao', url: `/wp-admin/admin.php?page=${P}&aba=operacao` },
  { id: 'pg-operacao', url: '/wp-admin/admin.php?page=f3base-operacao' },
  { id: 'pg-leads', url: '/wp-admin/admin.php?page=f3base-leads' },
  { id: 'pg-formularios', url: '/wp-admin/admin.php?page=f3base-formularios' },
  { id: 'pg-conteudos', url: '/wp-admin/admin.php?page=f3base-conteudos' },
  { id: 'pg-medicao', url: '/wp-admin/admin.php?page=f3base-medicao' },
  { id: 'pg-relatorios', url: '/wp-admin/admin.php?page=f3base-relatorios' },
  { id: 'pg-integracoes', url: '/wp-admin/admin.php?page=f3base-integracoes' },
];

const medirDom = () => {
  const raiz = document.querySelector('#wpbody-content') || document.body;
  const visivel = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const campos = [...raiz.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]),select,textarea')];
  const semRotulo = campos.filter((el) => {
    if (el.getAttribute('aria-label') || el.getAttribute('aria-labelledby') || el.getAttribute('title')) return false;
    if (el.closest('label')) return false;
    if (el.id && raiz.querySelector('label[for="' + CSS.escape(el.id) + '"]')) return false;
    return true;
  });
  const ids = {}; raiz.querySelectorAll('[id]').forEach((el) => { ids[el.id] = (ids[el.id] || 0) + 1; });
  const dup = Object.entries(ids).filter(([, n]) => n > 1).map(([i, n]) => i + '×' + n);
  const hs = [...raiz.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(visivel).map((h) => +h.tagName[1]);
  let saltos = 0; for (let i = 1; i < hs.length; i++) if (hs[i] - hs[i - 1] > 1) saltos++;
  const largos = [...raiz.querySelectorAll('*')].filter((el) => visivel(el) && el.getBoundingClientRect().right > document.documentElement.clientWidth + 1 && !el.closest('pre,table')).length;
  const pre = [...raiz.querySelectorAll('pre')].filter(visivel);
  const wrap = raiz.querySelector('.wrap');
  return {
    titulo: document.title, h1: raiz.querySelectorAll('h1').length, cabecalhos: hs.length, saltosDeNivel: saltos,
    campos: campos.length, camposVisiveis: campos.filter(visivel).length, semRotulo: semRotulo.length,
    semRotuloAmostra: semRotulo.slice(0, 8).map((el) => el.tagName.toLowerCase() + '[name=' + (el.name || '') + ']'),
    idsDuplicados: dup.length, idsDuplicadosAmostra: dup.slice(0, 8),
    formularios: raiz.querySelectorAll('form').length, botoesSalvar: [...raiz.querySelectorAll('button[type=submit],input[type=submit]')].filter(visivel).length,
    details: raiz.querySelectorAll('details').length, detailsAbertos: raiz.querySelectorAll('details[open]').length,
    preVisiveis: pre.length, preCaracteres: pre.reduce((n, p) => n + p.textContent.length, 0),
    estiloInline: raiz.querySelectorAll('[style]').length, scriptsInline: raiz.querySelectorAll('script:not([src])').length,
    alturaPagina: document.documentElement.scrollHeight, larguraDoc: document.documentElement.scrollWidth, larguraJanela: document.documentElement.clientWidth,
    estouroHorizontal: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1, elementosAlemDaBorda: largos,
    larguraWrap: wrap ? Math.round(wrap.getBoundingClientRect().width) : null,
    avisos: [...raiz.querySelectorAll('.notice,.error,.updated')].filter(visivel).length,
    textoErroPhp: /(Warning|Notice|Fatal error|Deprecated|Parse error)<\/b>:|Uncaught /.test(document.body.innerHTML),
  };
};

(async () => {
  const navegador = await chromium.launch();
  const resultado = [];
  for (const largura of larguras) {
    const ctx = await navegador.newContext({ viewport: { width: largura, height: 900 }, locale: 'pt-BR' });
    const pagina = await ctx.newPage();
    await pagina.goto(base + '/wp-login.php');
    await pagina.fill('#user_login', 'qa_admin'); await pagina.fill('#user_pass', senha);
    await Promise.all([pagina.waitForNavigation(), pagina.click('#wp-submit')]);
    for (const tela of telas) {
      const consoleErros = [], pageErros = [], httpRuins = [];
      const aoConsole = (m) => { if (m.type() === 'error') consoleErros.push(m.text().slice(0, 300)); };
      const aoErro = (e) => pageErros.push(String(e.message || e).slice(0, 300));
      const aoResp = (r) => { if (r.status() >= 400) httpRuins.push(r.status() + ' ' + r.url().replace(base, '').slice(0, 160)); };
      pagina.on('console', aoConsole); pagina.on('pageerror', aoErro); pagina.on('response', aoResp);
      const t0 = Date.now();
      let status = null, erro = null;
      try { const r = await pagina.goto(base + tela.url, { waitUntil: 'load', timeout: 60000 }); status = r ? r.status() : null; await pagina.waitForTimeout(400); } catch (e) { erro = String(e.message).slice(0, 200); }
      const ms = Date.now() - t0;
      let dom = null, axe = null;
      if (!erro) {
        dom = await pagina.evaluate(medirDom);
        await pagina.addScriptTag({ content: axeFonte });
        axe = await pagina.evaluate(async () => {
          const r = await window.axe.run(document.querySelector('#wpbody-content') || document, { resultTypes: ['violations'], runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] } });
          return r.violations.map((v) => ({ id: v.id, impacto: v.impact, nos: v.nodes.length, amostra: v.nodes.slice(0, 3).map((n) => n.target.join(' ').slice(0, 140)) }));
        });
        await pagina.screenshot({ path: path.join(saida, `${tela.id}-${largura}.png`), fullPage: true });
        if (largura === larguras[0]) fs.writeFileSync(path.join(saida, `${tela.id}.html`), await pagina.evaluate(() => (document.querySelector('#wpbody-content') || document.body).outerHTML));
      }
      pagina.off('console', aoConsole); pagina.off('pageerror', aoErro); pagina.off('response', aoResp);
      resultado.push({ tela: tela.id, largura, status, ms, erro, consoleErros, pageErros, httpRuins, dom, axe });
    }
    await ctx.close();
  }
  await navegador.close();
  fs.writeFileSync(path.join(saida, 'varredura.json'), JSON.stringify(resultado, null, 1));
  for (const r of resultado) {
    const a = (r.axe || []).reduce((n, v) => n + v.nos, 0);
    console.log([r.tela.padEnd(24), String(r.largura).padStart(5), 'http', r.status, (r.ms + 'ms').padStart(7), 'h=' + (r.dom ? r.dom.alturaPagina : '-'), 'campos=' + (r.dom ? r.dom.camposVisiveis + '/' + r.dom.campos : '-'), 'semRot=' + (r.dom ? r.dom.semRotulo : '-'), 'idDup=' + (r.dom ? r.dom.idsDuplicados : '-'), 'estouro=' + (r.dom ? (r.dom.estouroHorizontal ? 'SIM(' + r.dom.larguraDoc + ')' : 'nao') : '-'), 'axe=' + a, 'jsErr=' + (r.consoleErros.length + r.pageErros.length), 'http4xx5xx=' + r.httpRuins.length, r.dom && r.dom.textoErroPhp ? 'PHP-ERRO-NA-PAGINA' : '', r.erro || ''].join(' '));
  }
})().catch((e) => { console.error(e); process.exit(1); });
