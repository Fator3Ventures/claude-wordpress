<?php
require __DIR__.'/bootstrap-1851.php';
$telCases=[
 ['11987654321','+5511987654321',''],['(11) 98765-4321','+5511987654321',''],['5511987654321','+5511987654321',''],
 ['+55 11 98765-4321','+5511987654321',''],['011 98765-4321','+5511987654321',''],['11 3456-7890','+551134567890',''],
 ['55 98765-4321','+5555987654321',''],['+351 912345678','+351912345678',''],['11 6789.0123','+551167890123',''],
 ['98765-4321','','sem_ddd'],['+55 98765-4321','','sem_ddd'],['20 98765-4321','','ddd_invalido'],
 ['11 81234-5678','','quantidade_digitos'],['11 1234-5678','','prefixo_invalido'],
];
$campo=static fn($role,$free=false)=>['campos'=>[['nome'=>'entrada','rotulo'=>'Contato','papel'=>$role,'tipo'=>['telefone'=>'tel','contato'=>'text','email'=>'email'][$role],'formato_livre'=>$free,'obrigatorio'=>true]]];
foreach($telCases as $i=>[$v,$n,$erro]){
 $d=F3Base_Telefone::diagnostico($v,'BR',true);
 check($d['normalizado']===$n && $d['motivo']===$erro,'telefone_'.$i);
 $strict=F3Base_Formularios::validar_campos($campo('telefone'),['entrada'=>$v]);$free=F3Base_Formularios::validar_campos($campo('telefone',true),['entrada'=>$v]);
 check($strict['ok']===($n!=='') && ($strict['motivo']??'')===$erro && $free['ok'],'formulario_'.$i);
 check(F3Base_Pipedrive_Api::identificadores(['dados'=>['telefone'=>$v]])['phone']===$n,'pipedrive_'.$i);
 check(F3Base_Modulo_Meta_Capi::hash_telefone($v)===($n===''?'':hash('sha256',substr($n,1))),'meta_'.$i);
 $href=F3Base_Pipedrive_Comercial::whatsapp(['telefone'=>$v],['pais_telefone'=>'BR']);
 check($n===''||$d['classificacao']['tipo']==='fixo'?$href==='':str_starts_with($href,'https://wa.me/'.substr($n,1)),'whatsapp_'.$i);
}
$hits=[];
add_filter('pre_http_request',static function($pre,$args,$url)use(&$hits){
 if(wp_parse_url($url,PHP_URL_HOST)!=='cloudflare-dns.com'){return $pre;}
 parse_str(wp_parse_url($url,PHP_URL_QUERY),$q);$hits[]=$q;
 if($q['name']==='incerto.example'){return new WP_Error('timeout');}
 $json=['Status'=>0,'Answer'=>[]];
 if(in_array($q['name'],['gmail.com','empresa.co','empresa.com.br','preservar.com.brr','exemplo.org'],true) && $q['type']==='MX'){
  $json['Answer'][]=['type'=>15,'data'=>'10 mx.example.','TTL'=>20];
 }elseif($q['name']==='apenas-a.example' && $q['type']==='A'){$json['Answer'][]=['type'=>1,'data'=>'192.0.2.1'];}
 elseif($q['name']==='null-mx.example'){$json['Answer'][]=['type'=>15,'data'=>'0 .'];}
 elseif($q['name']==='dominioinexistente123.com.br'){$json['Status']=3;}
 return ['response'=>['code'=>200],'body'=>wp_json_encode($json),'headers'=>[]];
},1,3);
$cases=[
 ['Joao @Gmail.com','joao@gmail.com','valido'],['joao@gmail,com','joao@gmail.com','valido'],['JOAO@GMAIL.COM.','joao@gmail.com','valido'],
 ['joao@gmial.com','joao@gmail.com','corrigido'],['joao@empresa.com.brr','joao@empresa.com.br','corrigido'],
 ['joao@preservar.com.brr','joao@preservar.com.brr','valido'],['joao@empresa.co','joao@empresa.co','valido'],
 ['joao@dominioinexistente123.com.br','joao@dominioinexistente123.com.br','invalido'],['joao@incerto.example','joao@incerto.example','nao_verificado'],
 ['joao@apenas-a.example','joao@apenas-a.example','valido'],['joao@null-mx.example','joao@null-mx.example','invalido'],
 ['joão@gmail.com','joão@gmail.com','invalido'],['jo..ao@gmail.com','jo..ao@gmail.com','invalido'],['a@a@a.co','a@a@a.co','invalido'],
 ['a@b.c','a@b.c','invalido'],['a@gmail.com..','a@gmail.com..','invalido'],
];
$ability=wp_get_ability('f3base/email-contato-simular');
foreach($cases as $i=>[$raw,$canonical,$classe]){
 $res=$ability->execute(['valor'=>$raw]);check(!is_wp_error($res)&&$res['digitado']===$raw&&$res['corrigido']===$canonical&&$res['classe']===$classe,'email_'.$i,$res);
 foreach(['email','contato'] as $role){$f=F3Base_Formularios::validar_campos($campo($role),['entrada'=>$raw]);check($f['ok']&&$f['email_normalizacao']['classe']===$classe&&$f['papeis']['email']===($classe==='invalido'?'':$canonical),'form_'.$role.'_'.$i);}
}
$sim=$ability->execute(['valor'=>'a@temporario.org','correcoes'=>['temporario.org=exemplo.org']]);check($sim['email']==='a@exemplo.org','simula_lista');
check(F3Base_Email_Contato::recusa(['a.com=b.com','b.com=a.com'])!=='','lista_sem_ciclo');
wp_set_current_user(0);check(is_wp_error($ability->execute(['valor'=>'qa@gmail.com'])),'simulacao_exige_admin');
$ids=[];$form='qa185-'.bin2hex(random_bytes(4));
try{
 foreach([0,3,7,8] as $i){
  [$raw,$target,$classe]=$cases[$i];$id=bin2hex(random_bytes(16));$ids[]=$id;
  $v=F3Base_Leads_Repositorio::guardar(['record_id'=>$id,'formulario'=>$form,'metodo'=>'formulario','email'=>$raw,'notificar'=>false,'captura'=>'aceito','pagina'=>'/qa185/','nome'=>'QA'],null,null,'');
  $lead=F3Base_Leads_Repositorio::obter($id);
  check($v['ok']&&$lead['dados']['email_normalizacao']['digitado']===$raw&&$lead['dados']['email_normalizacao']['classe']===$classe&&$lead['email']===($classe==='invalido'?'':$target),'persistiu_'.$i);
  $ctx=F3Base_Contato_Apresentacao::montar($lead,false);
  $crm=F3Base_Pipedrive_Api::identificadores($lead);
  check($crm['email']===$lead['email'],'crm_email_'.$i);
  if($classe==='corrigido'){
    $m=F3Base_Slack_Thread::mensagens($ctx)[0]['text'];$note=F3Base_Contato_Apresentacao::nota($ctx,'qa');
    check(str_contains($m,'E-mail corrigido de')&&str_contains($m,$raw)&&str_contains($m,$target),'slack_corrigido');
    check(str_contains($note,'E-mail corrigido de')&&str_contains($note,$raw)&&str_contains($note,$target),'crm_nota');
  }
  if($classe==='invalido'){
   check(!F3Base_Telefone::converter($lead),'sem_conversao_por_padrao');
   check(F3Base_Pipedrive_Comercial::atividade($ctx,[])['subject']==='Conferir contato','crm_conferir_contato');
   check(!F3Base_Email_Novo_Lead::elegivel($lead,[]),'sem_email_automatico');
   $grant=F3Base_Conteudo_Privado::conceder($id,['ativo'=>'fixture'],$lead['email']);
   check(!$grant['ok']&&$grant['codigo']==='conteudo_exige_email_valido'&&!isset($grant['url']),'material_exige_email_utilizavel');
  }
 }
 wp_set_current_user(1);
 $rel=wp_get_ability('f3base/relatorios-integrados-ler')->execute(['visao'=>'emails_normalizacao','formulario'=>$form,'segmento'=>'todos']);
 check(!is_wp_error($rel)&&($rel['ok']??false),'relatorio',$rel instanceof WP_Error?$rel->get_error_message():($rel['codigo']??null));
 check(count($rel['linhas'])===4&&array_sum(array_column($rel['linhas'],'contatos'))===4&&min(array_column($rel['linhas'],'contatos'))===1&&!str_contains(wp_json_encode($rel['linhas']),'@'),'quatro_classes_sem_pii',$rel['linhas']);
}finally{wp_set_current_user(1);foreach($ids as $id){F3Base_Leads_Repositorio::eliminar($id,'qa');}}
check(!array_filter($hits,static fn($q)=>str_contains(wp_json_encode($q),'@')),'dns_apenas_dominio');
evidence('400-401',['telefones'=>count($telCases),'emails'=>count($cases),'dns'=>'respostas controladas em WordPress nativo']);
