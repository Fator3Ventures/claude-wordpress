<?php
/**
 * Regressões da 1.80.0 na release 1.85.1: B1 (habilidades de acompanhantes), versão, fronteiras da 1.80.0 e documentação.
 * Seção tela: gravação da tela de configuração (D1 options sem editor, D2 grupos com delta, B5 escape do índice).
 * F3BASE_SECOES=b1,versao,fronteiras,docs,tela restringe as seções (diagnóstico e prova por mutação; não grava evidência).
 */
require __DIR__.'/bootstrap-1851.php';
global $checks;
$todas=['b1','versao','fronteiras','docs','tela'];
$escolhidas=getenv('F3BASE_SECOES')?array_values(array_intersect($todas,array_map('trim',explode(',',(string)getenv('F3BASE_SECOES'))))):$todas;
$secao=static fn(string $s)=>in_array($s,$escolhidas,true);
$raiz=dirname(__DIR__);
$detalhes=[];

/* ---------- 1. B1: acompanhantes ausentes e presentes ---------- */
if($secao('b1')){
    $avisos=[];
    $capturar=static function($funcao,$mensagem)use(&$avisos){$avisos[]=$funcao.': '.wp_strip_all_tags((string)$mensagem);};
    add_action('doing_it_wrong_run',$capturar,10,2);add_filter('doing_it_wrong_trigger_error','__return_false');
    $consultadas=['meta/health','meta/list-connections','linkedin/status','linkedin/diagnose-conversions','google/status','linkedin/admin-options','ads/search'];
    check(!array_filter($consultadas,'wp_has_ability'),'b1_acompanhantes_ausentes_no_laboratorio',array_values(array_filter($consultadas,'wp_has_ability')));
    $ausente=array('ok'=>false,'codigo'=>'pacote_ou_ability_ausente');
    foreach(['meta/health','meta/list-connections','linkedin/status','linkedin/diagnose-conversions','google/status'] as $nome){
        $avisos=[];$r=F3Base_Midia_Prontidao::publica($nome);$slug=str_replace('/','_',str_replace('-','_',$nome));
        check($r===$ausente,'b1_midia_prontidao_retorno_ausente_'.$slug,$r);
        check($avisos===[],'b1_midia_prontidao_sem_doing_it_wrong_'.$slug,$avisos);
    }
    $avisos=[];
    $r=F3Base_Linkedin_Integracoes::prever(['connection_id'=>'conexao-teste','conta_id'=>'123456789','cliente'=>'linkedin_plugin'],static fn()=>F3Base_Linkedin_Cliente::catalogo('formularios'));
    check($r===array('ok'=>false,'codigo'=>'atualize_o_plugin_linkedin_para_0_4_1'),'b1_linkedin_cliente_retorno_ausente',$r);
    check($avisos===[],'b1_linkedin_cliente_sem_doing_it_wrong',$avisos);
    // A consulta de catálogo tem cota por minuto e usuário; o teste zera a sua própria chave para poder ser repetido.
    $zerarCota=static function(){global $wpdb;$wpdb->delete(F3Base_Leads_Repositorio::tabela('leads_janelas'),['chave'=>'catalogo-ui|'.get_current_user_id().'|'.gmdate('YmdHi')]);};
    $avisos=[];$contexto=(new ReflectionMethod('F3Base_Anuncios_Selecao','contexto'))->invoke(null,'f3base_anuncios_google');
    $pedido=['origem'=>'f3base_anuncios_google','tipo'=>'campanhas','contexto'=>$contexto];
    $zerarCota();$r=F3Base_Anuncios_Selecao::consultar($pedido);
    check($r===array('ok'=>false,'codigo'=>'ative_o_mcp_google_com_ads'),'b1_anuncios_selecao_retorno_ausente',$r);
    check($avisos===[],'b1_anuncios_selecao_sem_doing_it_wrong',$avisos);

    // Caminho positivo: ability falsa com os nomes consultados, registrada num registro novo (os do núcleo já foram inicializados).
    $chamadas=[];
    $rotulo=static fn(string $n)=>['label'=>'Teste '.$n,'description'=>'Ability falsa do teste 1851 para '.$n.'.'];
    $categorias=static function(){wp_register_ability_category('f3base-qa',['label'=>'QA 1851','description'=>'Categoria do teste.']);};
    $registrar=static function()use(&$chamadas,$rotulo){
        $defs=[
            'google/status'=>['success'=>true,'data'=>['marcador'=>'ability-falsa-google-status']],
            'linkedin/admin-options'=>['success'=>true,'data'=>['connection_revision'=>7,'rows'=>[['id'=>'111','name'=>'Formulário A'],['id'=>'abc','name'=>'ignorado por id não numérico']],'next_offset'=>null]],
            'ads/search'=>['success'=>true,'data'=>['rows'=>[['campaign'=>['id'=>'555','name'=>'Campanha QA']]]]],
        ];
        foreach($defs as $nome=>$saida){
            wp_register_ability($nome,$rotulo($nome)+['category'=>'f3base-qa','input_schema'=>['type'=>'object','additionalProperties'=>true],
                'execute_callback'=>static function($entrada)use(&$chamadas,$nome,$saida){$chamadas[$nome][]=$entrada;return $saida;},
                'permission_callback'=>'__return_true','meta'=>['show_in_rest'=>false]]);
        }
    };
    $rA=new ReflectionProperty('WP_Abilities_Registry','instance');$rC=new ReflectionProperty('WP_Ability_Categories_Registry','instance');
    $origA=$rA->getValue();$origC=$rC->getValue();
    try{
        $rA->setValue(null,null);$rC->setValue(null,null);
        add_action('wp_abilities_api_categories_init',$categorias,20);add_action('wp_abilities_api_init',$registrar,20);
        $avisos=[];$presentes=array_map('wp_has_ability',['google/status','linkedin/admin-options','ads/search']);
        check($presentes===[true,true,true],'b1_ability_falsa_registrada_no_teste',$presentes);
        check($avisos===[],'b1_registro_da_ability_falsa_sem_aviso',$avisos);
        $avisos=[];
        $r=F3Base_Midia_Prontidao::publica('google/status');
        check($r===array('ok'=>true,'dados'=>['marcador'=>'ability-falsa-google-status']),'b1_midia_prontidao_usa_ability_presente',$r);
        check(count($chamadas['google/status']??[])===1,'b1_midia_prontidao_executou_a_ability_uma_vez',array_map('count',$chamadas));
        $r=F3Base_Linkedin_Integracoes::prever(['connection_id'=>'conexao-teste','conta_id'=>'123456789','cliente'=>'linkedin_plugin'],static fn()=>F3Base_Linkedin_Cliente::catalogo('formularios'));
        check(($r['ok']??null)===true&&($r['linhas']??null)===[['id'=>'111','name'=>'Formulário A']]&&($r['cursor']??null)==='','b1_linkedin_cliente_usa_ability_presente',$r);
        $in=$chamadas['linkedin/admin-options'][0]??[];
        check(($in['connection_id']??null)==='conexao-teste'&&($in['account_id']??null)==='123456789'&&($in['channel']??null)==='leads'&&($in['kind']??null)==='forms','b1_linkedin_cliente_entrada_enviada_a_ability',$in);
        $zerarCota();$r=F3Base_Anuncios_Selecao::consultar($pedido);
        check(($r['ok']??null)===true&&($r['linhas']??null)===[['id'=>'555','name'=>'Campanha QA']],'b1_anuncios_selecao_usa_ability_presente',$r);
        $in=$chamadas['ads/search'][0]??[];
        check(str_contains((string)($in['query']??''),'FROM campaign')&&($in['format']??null)==='raw','b1_anuncios_selecao_consulta_enviada_a_ability',$in);
        check($avisos===[],'b1_caminho_positivo_sem_doing_it_wrong',$avisos);
    }finally{
        remove_action('wp_abilities_api_categories_init',$categorias,20);remove_action('wp_abilities_api_init',$registrar,20);
        $rA->setValue(null,$origA);$rC->setValue(null,$origC);
        remove_action('doing_it_wrong_run',$capturar,10);remove_filter('doing_it_wrong_trigger_error','__return_false');
    }
}

/* ---------- 3. Versão ---------- */
if($secao('versao')){
    $cabecalho=(string)file_get_contents(F3BASE_PLUGIN_ARQUIVO);
    check(preg_match('/^\s*\*\s*Version:\s*([0-9.]+)/m',$cabecalho,$m)===1&&$m[1]===F3BASE_PLUGIN_VERSAO,'versao_cabecalho_igual_a_constante',[$m[1]??null,F3BASE_PLUGIN_VERSAO]);
    check(F3BASE_PLUGIN_VERSAO==='1.85.1','versao_constante_e_1_81_1',F3BASE_PLUGIN_VERSAO);
    check(str_contains($cabecalho,'/** Referência de implantação: instalação nova ou atualização da 1.85.0. */'),'versao_referencia_de_implantacao_cita_a_base_1_82_0');
    $campos=['abilities-1'=>'plugin','abilities-2'=>'plugin','abilities-3'=>'plugin','abilities-4'=>'plugin','abilities-5'=>'plugin','ajuda-opcoes'=>'plugin','configuracao-schema'=>'plugin','contrato'=>'plugin','estado-inventario'=>'versao'];
    foreach($campos as $arq=>$campo){
        $j=json_decode((string)file_get_contents(F3BASE_PLUGIN_DIR.'docs/dados/'.$arq.'.json'),true);
        check(is_array($j)&&($j[$campo]??null)===F3BASE_PLUGIN_VERSAO,'versao_json_'.str_replace('-','_',$arq),$j[$campo]??null);
    }
}

/* ---------- 4. Fronteiras não reexecutadas ---------- */
if($secao('fronteiras')){
    $manifesto=json_decode((string)file_get_contents($raiz.'/history/1.80.0-runtime/manifest.json'),true);
    $base=array_column($manifesto,'sha256','path');
    foreach(['autoria','cache-reaquecimento','modulo-schema-extensao'] as $nome){
        $rel='includes/class-f3base-'.$nome.'.php';$esperado=$base['base-site-core-fator3/'.$rel]??null;
        check($esperado!==null&&is_file(F3BASE_PLUGIN_DIR.$rel)&&hash_file('sha256',F3BASE_PLUGIN_DIR.$rel)===$esperado,'fronteira_igual_a_base_1_80_0_'.str_replace('-','_',$nome),$rel);
    }
}

/* ---------- 2. Documentação (o conteúdo vem de outro agente; aqui só se mede) ---------- */
if($secao('docs')){
    $versao=F3BASE_PLUGIN_VERSAO;$dir=F3BASE_PLUGIN_DIR;
    $ler=static fn(string $p)=>(string)file_get_contents($dir.$p);
    $docs=glob($dir.'docs/*.md');sort($docs);$nomes=array_map('basename',$docs);
    $todos=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(rtrim($dir,'/'),FilesystemIterator::SKIP_DOTS));
    foreach($it as $f){if($f->isFile()){$todos[substr($f->getPathname(),strlen(rtrim($dir,'/'))+1)]=true;}}
    $normpath=static function(string $p){$o=[];foreach(explode('/',$p) as $s){if($s===''||$s==='.'){continue;}if($s==='..'){if($o&&end($o)!=='..'){array_pop($o);}else{$o[]='..';}}else{$o[]=$s;}}return $o?implode('/',$o):'.';};
    // 2.1 índice
    $indice=$ler('docs/DOCUMENTACAO.md');
    $fora=array_values(array_filter($nomes,static fn($n)=>$n!=='DOCUMENTACAO.md'&&!str_contains($indice,$n)));
    check($fora===[],'docs_todo_md_citado_em_documentacao_md',$fora);
    // 2.2 referências inexistentes (mesmas expressões de scripts/auditar-docs.py)
    $quebradas=[];
    foreach(array_merge(array_map(static fn($n)=>'docs/'.$n,$nomes),['README.md']) as $d){
        $t=$ler($d);
        if(preg_match_all('#(?<![\w/.-])((?:docs|includes|admin|assets|dados)/[\w./-]+\.(?:md|json|php|js|css|sql|tsv))#u',$t,$mm)){
            foreach($mm[1] as $ref){if(!isset($todos[$ref])){$quebradas[$d][$ref]=true;}}
        }
        if(preg_match_all('#\]\((?!https?:|\#|mailto:)([^)\s]+)\)#u',$t,$mm)){
            foreach($mm[1] as $ref){$alvo=$normpath(dirname($d).'/'.explode('#',$ref)[0]);if(!isset($todos[$alvo])){$quebradas[$d]['link:'.$ref]=true;}}
        }
    }
    $quebradas=array_map('array_keys',$quebradas);
    check($quebradas===[],'docs_sem_referencia_a_arquivo_inexistente',$quebradas);
    // 2.3 abilities citadas em documento vigente
    $registradas=[];foreach(wp_get_abilities() as $n=>$a){if(str_starts_with((string)$n,'f3base/')){$registradas[$n]=true;}}
    $fantasmas=[];
    foreach($nomes as $n){
        if(preg_match('/-\d+\.\d+(\.\d+)?\.md$/',$n)){continue;}
        if(preg_match_all('#f3base/[a-z0-9]+(?:-[a-z0-9]+)*#',$ler('docs/'.$n),$mm)){
            foreach(array_unique($mm[0]) as $a){if(!isset($registradas[$a])&&!in_array($a,['f3base/formulario','f3base/artigos'],true)&&!preg_match('#^f3base/v\d+$#',$a)){$fantasmas[$a][]=$n;}}
        }
    }
    check($fantasmas===[],'docs_vigentes_sem_ability_nao_registrada',$fantasmas);
    // 2.4 documentos de entrada
    foreach(['README.md','docs/README.md','docs/DOCUMENTACAO.md','docs/INSTRUCOES-DO-PLUGIN.md','docs/CONFIGURACAO.md','docs/GUIA-PAINEL.md','docs/CONTRACTS.md','docs/CHANGELOG.md','docs/OPERACAO-E-RECUPERACAO.md','docs/VALIDACAO.md'] as $d){
        $cabeca=is_file($dir.$d)?implode("\n",array_slice(explode("\n",$ler($d)),0,6)):'';
        check(is_file($dir.$d)&&preg_match('/(?<![\d.])'.preg_quote($versao,'/').'(?![\d])/',$cabeca)===1,'docs_entrada_cita_versao_corrente_'.str_replace(['/','.','-'],'_',strtolower($d)),$cabeca===''?'ausente':substr($cabeca,0,160));
    }
    // 2.5 AGENTES e RELEASE da versão corrente
    foreach(['AGENTES','RELEASE'] as $n){check(is_file($dir.'docs/'.$n.'-'.$versao.'.md'),'docs_'.strtolower($n).'_da_versao_corrente_existe');}
    // 2.6 entrega íntegra e paginada pela API de leitura
    wp_set_current_user(0);
    check(empty(F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/DOCUMENTACAO.md'])['ok']),'docs_leitura_anonima_recusada');
    wp_set_current_user(1);
    foreach(['DOCUMENTACAO.md','REFERENCIA-ABILITIES.md','AGENTES-'.$versao.'.md','RELEASE-'.$versao.'.md'] as $n){
        $slug=strtolower(str_replace(['.','-'],'_',$n));$f='docs/'.$n;$linha=1;$partes=0;$ok=true;$shaOk=true;$texto=[];$total=null;
        do{
            $d=F3Base_Configuracao_Atual::documentacao(['arquivo'=>$f,'linha'=>$linha,'limite'=>50]);
            if(empty($d['ok'])){$ok=false;break;}
            $shaOk=$shaOk&&$d['sha256']===(is_file($dir.$f)?hash_file('sha256',$dir.$f):'');$texto[]=$d['texto'];$total=$d['total_linhas'];$linha=$d['proxima_linha'];$partes++;
        }while($linha!==null&&$partes<1000);
        check($ok,'docs_api_entrega_'.$slug,$d['codigo']??null);
        check($ok&&$shaOk,'docs_api_sha256_igual_ao_arquivo_'.$slug);
        $arq=is_file($dir.$f)?(string)file_get_contents($dir.$f):null;
        $esperadoTexto=$arq===null?null:implode("\n",array_map(static fn($l)=>rtrim($l,"\r"),array_slice(explode("\n",$arq),0,$total)));
        check($ok&&$linha===null&&$esperadoTexto!==null&&implode("\n",$texto)===$esperadoTexto&&($total<=50||$partes>1),'docs_api_texto_integral_e_paginado_'.$slug,['partes'=>$partes,'total_linhas'=>$total]);
    }
}

/* ---------- 5. Tela de configuração: D1 (options sem editor), D2 (grupos com delta), B5 (índice escapado) ---------- */
if($secao('tela')){
    foreach(['template','misc','screen','plugin','admin','file'] as $inc){if(is_file(ABSPATH.'wp-admin/includes/'.$inc.'.php')){require_once ABSPATH.'wp-admin/includes/'.$inc.'.php';}}
    wp_set_current_user(1);
    $areas12=['contato','medicao-tags','medicao-meta','medicao-coleta','medicao-gsc','medicao-ga4','medicao-clarity','medicao-testes','consentimento','privacidade','conteudo','seo'];
    /* Lista escrita de propósito: uma sétima option sem editor no catálogo derruba o teste e alguém decide. */
    $esperadas=['medicao-coleta'=>['f3base_campanhas_origem','f3base_contexto_sessao','f3base_canais_organicos','f3base_origens_ia'],'conteudo'=>['f3base_marcas_vigiadas'],'seo'=>['f3base_redirects']];
    $sentinela=new stdClass();
    $snap=[];
    $guardar=static function(string $n)use(&$snap,$sentinela){if(!array_key_exists($n,$snap)){$snap[$n]=get_option($n,$sentinela);}};
    $restaurar=static function()use(&$snap,$sentinela){foreach($snap as $n=>$v){if($v===$sentinela){delete_option($n);}else{update_option($n,$v);}}$snap=[];};
    $secoes_vivas=F3Base_Interface::secoes();
    $por_area=[];
    foreach(F3Base_Options::catalogo() as $n=>$d){
        if($n==='f3base_retencao_meses'||!F3Base_Options::operavel((string)$n)){continue;}
        $a=F3Base_Interface::grupo((string)$n,$d);if(!isset($secoes_vivas[$a])||!in_array($a,$areas12,true)){continue;}
        $por_area[$a][(string)$n]=$d;
    }
    /* 1. A regra seleciona exatamente as seis options, por área. */
    $achadas=[];
    foreach($areas12 as $a){$achadas[$a]=array_values(array_filter(array_keys($por_area[$a]??[]),static fn($n)=>F3Base_Admin_Entrada::sem_editor($n,$por_area[$a][$n])));sort($achadas[$a]);}
    $achadas=array_filter($achadas);$alvo=$esperadas;foreach($alvo as $a=>$l){sort($alvo[$a]);}
    check($achadas===$alvo,'tela_regra_sem_editor_seleciona_exatamente_as_seis',['achadas'=>$achadas]);
    check(!F3Base_Admin_Entrada::sem_editor('f3base_navegacao',F3Base_Options::declaracao('f3base_navegacao')),'tela_regra_nao_pega_navegacao');
    $outros=['f3base_campanhas_nomes','f3base_redirects_hosts','f3base_meta_capi_token','f3base_confirmacao_hosts','f3base_formularios'];
    check(!array_filter($outros,static fn($n)=>isset(F3Base_Options::catalogo()[$n])&&F3Base_Admin_Entrada::sem_editor($n,F3Base_Options::declaracao($n))),'tela_regra_nao_pega_campanhas_linhas_segredo_json');
    $renderizar=static function(string $area):string{$_GET['page']=F3Base_Admin_Tela::SLUG;$_GET['secao']=$area;ob_start();try{F3Base_Admin_Tela::render();}finally{$h=(string)ob_get_clean();}return $h;};
    $contexto_do=static function(string $html){if(!preg_match('/name="f3base_contexto" value="([a-f0-9-]{36})"/',$html,$m)){return [null,null];}$c=get_transient('f3base_form_'.$m[1]);return [$m[1],is_array($c)?$c:null];};
    /* 2. Contexto e HTML de cada área. */
    $htmls=[];
    foreach($areas12 as $a){
        $slug=str_replace('-','_',$a);$html=$htmls[$a]=$renderizar($a);[$id,$ctx]=$contexto_do($html);
        check($ctx!==null&&$ctx['area']===$a,'tela_contexto_criado_pelo_render_'.$slug,$id);
        $sem=$esperadas[$a]??[];$nomes_ctx=array_keys($ctx['base']??[]);
        check(!array_intersect($sem,$nomes_ctx),'tela_contexto_sem_option_sem_editor_'.$slug,array_intersect($sem,$nomes_ctx));
        preg_match_all('/name="f3base\[([a-z0-9_]+)\]/',$html,$m);$impressos=array_values(array_unique($m[1]));
        check(!array_intersect($sem,$impressos),'tela_html_sem_name_de_option_sem_editor_'.$slug,array_intersect($sem,$impressos));
        check(!array_diff($impressos,$nomes_ctx),'tela_todo_name_impresso_pertence_ao_contexto_'.$slug,array_diff($impressos,$nomes_ctx));
        preg_match_all('/name="f3base\[([a-z0-9_]+)\]"/',$html,$m);
        $simples_x_array=array_values(array_filter(array_unique($m[1]),static fn($n)=>is_array($ctx['base'][$n]??null)));
        check(!$simples_x_array,'tela_controle_simples_nao_envia_texto_para_valor_estruturado_'.$slug,$simples_x_array);
        preg_match_all('/name="f3base_revisao\[([a-z0-9_]+)\]/',$html,$m);
        check(!array_diff(array_unique($m[1]),$nomes_ctx),'tela_toda_revisao_impressa_pertence_ao_contexto_'.$slug,array_diff(array_unique($m[1]),$nomes_ctx));
        $faltam=array_filter($sem,static fn($n)=>!str_contains($html,'data-f3base-campo="'.$n.'"')||!str_contains($html,'id="linha-'.$n.'"')||!preg_match('/id="linha-'.$n.'" data-f3base-indice="[^"]+"/',$html));
        check(!$faltam,'tela_bloco_somente_leitura_presente_'.$slug,$faltam);
        if($sem){
            $habs=array_map(static fn($n)=>$n==='f3base_redirects'?'f3base/redirects-escrever':'f3base/config-core-escrever',$sem);
            check(!array_filter($habs,static fn($h)=>!str_contains($html,'<code>'.$h.'</code>')),'tela_bloco_cita_habilidade_de_escrita_'.$slug,$habs);
            check(!str_contains($html,'<code>f3base/config-escrever</code>'),'tela_bloco_nao_cita_ponte_do_implantador_'.$slug);
        }else{check(!str_contains($html,'f3base-somente-leitura'),'tela_sem_bloco_somente_leitura_'.$slug);}
    }
    check(wp_has_ability('f3base/config-core-escrever')&&wp_has_ability('f3base/redirects-escrever'),'tela_habilidades_citadas_existem_no_registro');
    /* 3. Gravação pelo caminho da tela. */
    $enviar=static function(string $area,array $html_ctx,array $alterar=[],array $extras=[])use($renderizar,$contexto_do){
        $html=$renderizar($area);[$id,$ctx]=$contexto_do($html);if(!$ctx){return null;}
        $env=$ctx['base'];foreach($alterar as $n=>$f){$env[$n]=$f($env[$n]);}foreach($extras as $n=>$v){$env[$n]=$v;}
        return ['ctx'=>$ctx,'saida'=>F3Base_Admin_Tela::processar_envio($env,$ctx['revisoes'],[],$id,$area,$id)];
    };
    foreach($areas12 as $a){
        $r=$enviar($a,[]);$slug=str_replace('-','_',$a);
        $erros=$r?array_values(array_filter($r['saida'],static fn($x)=>empty($x['persisted']))):['sem contexto'];
        check($r!==null&&$erros===[]&&$r['saida']===[],'tela_reenvio_sem_mudanca_nao_devolve_erro_'.$slug,array_map(static fn($x)=>is_array($x)?($x['nome']??'').': '.($x['motivo']??''):$x,$erros));
    }
    $flip=static fn($v)=>$v==='1'?'0':'1';
    $alteracoes=[
        'medicao-coleta'=>['f3base_meta_correspondencia',[ 'f3base_meta_correspondencia'=>$flip ],static fn()=>(bool)F3Base_Options::ler('f3base_meta_correspondencia')],
        'conteudo'=>['f3base_robots',[ 'f3base_robots'=>static function($v)use($flip){$v['ligado']=$flip($v['ligado']);return $v;} ],static fn()=>F3Base_Options::ler('f3base_robots')['ligado']],
        'seo'=>['f3base_verificacao_google',[ 'f3base_verificacao_google'=>static fn($v)=>'tok1851abc' ],static fn()=>F3Base_Options::ler('f3base_verificacao_google')],
    ];
    foreach($alteracoes as $a=>[$opt,$fns,$ler]){
        $slug=str_replace('-','_',$a);$guardar($opt);$antes=$ler();
        $r=$enviar($a,[],$fns);
        $ok=$r&&count($r['saida'])===1&&!empty($r['saida'][0]['persisted'])&&$r['saida'][0]['nome']===$opt;
        check($ok,'tela_altera_campo_simples_persiste_'.$slug,$r['saida']??null);
        check($ler()!==$antes,'tela_altera_campo_simples_relê_novo_valor_'.$slug,[$antes,$ler()]);
        $restaurar();
    }
    foreach($esperadas as $a=>$lista){
        $slug=str_replace('-','_',$a);
        foreach($lista as $opt){
            $guardar($opt);$antes=get_option($opt,$sentinela);
            $r=$enviar($a,[],[],[$opt=>'texto-forjado']);
            $codigos=$r?array_column($r['saida'],'codigo'):['sem contexto'];
            check($codigos===['escopo_invalido'],'tela_envio_com_option_sem_editor_e_recusado_'.$opt,$codigos);
            check(get_option($opt,$sentinela)===$antes,'tela_envio_recusado_nao_grava_'.$opt);
            $r=$enviar($a,[],[],[$opt=>[]]);
            check(($r?array_column($r['saida'],'codigo'):['sem contexto'])===['escopo_invalido'],'tela_envio_com_array_para_option_sem_editor_e_recusado_'.$opt);
            $restaurar();
        }
    }
    /* 4. D2: a classe inteira, permanente. */
    $mal=[];$pares=0;
    foreach(F3Base_Options::catalogo() as $n=>$d){
        if(!F3Base_Options::operavel((string)$n)||($d['campo']??'')!=='grupo'||empty($d['subcampos'])){continue;}
        $vigente=F3Base_Options::ler((string)$n);
        foreach(['vigente'=>$vigente,'padrao'=>$d['padrao']??null] as $origem=>$v){
            if(!is_array($v)||F3Base_Options::recusar((string)$n,$v,$d)!==''){continue;}
            foreach(array_keys($d['subcampos']) as $k){
                if(!array_key_exists($k,$v)){continue;}
                $esc=F3Base_Config_Mescla::escopo((string)$n,$v,[$k=>$v[$k]],$d);$pares++;
                $m=F3Base_Options::recusar((string)$n,$esc,$d);if($m!==''){$mal[]=$n.'.'.$k.' ('.$origem.'): '.$m;}
            }
        }
    }
    check($pares>150,'tela_d2_enumeracao_avaliou_os_pares',$pares);
    check($mal===[],'tela_d2_nenhuma_option_de_grupo_aceita_inteira_e_recusada_em_delta',$mal);
    foreach(['f3base_conversoes_conteudo','f3base_conversoes_transporte','f3base_navegacao','f3base_gsc_consultas'] as $n){
        $d=F3Base_Options::declaracao($n);$v=F3Base_Options::ler($n);
        check(count(F3Base_Config_Mescla::escopo($n,$v,[array_key_first($d['subcampos'])=>$v[array_key_first($d['subcampos'])]],$d))===count($d['subcampos']),'tela_d2_escopo_cobre_todas_as_chaves_'.$n);
    }
    $guardar('f3base_conversoes_conteudo');
    foreach(['ga4','meta','google_ads','linkedin'] as $k){
        $antes=F3Base_Options::ler('f3base_conversoes_conteudo');
        $r=$enviar('medicao-tags',[],['f3base_conversoes_conteudo'=>static function($v)use($k,$flip){$v[$k]=$flip($v[$k]);return $v;}]);
        $ok=$r&&count($r['saida'])===1&&!empty($r['saida'][0]['persisted']);
        check($ok,'tela_d2_alternar_conversao_de_material_persiste_'.$k,$r['saida']??null);
        $depois=F3Base_Options::ler('f3base_conversoes_conteudo');
        check($depois[$k]===!$antes[$k]&&array_diff_key($depois,[$k=>1])===array_diff_key($antes,[$k=>1]),'tela_d2_alternar_conversao_de_material_relê_'.$k,[$antes,$depois]);
    }
    $restaurar();
    /* 5. B5: chave de texto no índice não sai crua. */
    $guardar('f3base_qualidade');
    $cfg=F3Base_Qualidade::config();$chave='"><img src=x onerror=alert(1)>';
    $cfg['etapas']=[$chave=>['id'=>'etapa_x','nome'=>'Etapa X','evento_meta'=>'']];
    $gravou=F3Base_Options::gravar('f3base_qualidade',$cfg,F3Base_Options::ORIGEM_MANUAL,F3Base_Options::revisao('f3base_qualidade'));
    check(!empty($gravou['persisted']),'tela_b5_preparo_gravou_chave_de_texto',$gravou['motivo']??null);
    ob_start();try{F3Base_Qualidade::tela();}finally{$q=(string)ob_get_clean();}
    check(str_contains($q,'etapas[&quot;&gt;&lt;img src=x onerror=alert(1)&gt;]'),'tela_b5_chave_aparece_escapada_no_name',null);
    check(!str_contains($q,'<img src=x onerror'),'tela_b5_html_sem_img_onerror_cru');
    $restaurar();
}

if(getenv('F3BASE_SECOES')){global $falhas;if($falhas){echo 'pedidos-1851 (secoes: '.implode(',',$escolhidas).'): '.count($falhas).' de '.count($checks)." checks FALHARAM\n";exit(1);}echo 'pedidos-1851 (secoes: '.implode(',',$escolhidas).'): '.count($checks)." checks OK\n";}
else{evidence('pedidos-1851',$detalhes);}
