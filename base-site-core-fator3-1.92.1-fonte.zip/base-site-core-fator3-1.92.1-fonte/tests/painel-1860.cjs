const {chromium} = require('playwright');
const fs = require('node:fs');
(async()=>{
const phase = process.argv[2];
const root=new URL(process.env.F3BASE_QA_URL || 'http://127.0.0.1:8786/').href;
if (!['localhost','127.0.0.1','[::1]'].includes(new URL(root).hostname)) throw new Error('Use um WordPress local');
if (!['antes','depois','subabas','recuperacao','interacoes'].includes(phase)) throw new Error('Fase inválida');
const out=require('node:path').resolve(__dirname,'../evidence/1860/ui-'+phase);
fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_BIN || '/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--disable-gpu','--no-zygote','--single-process']});
const ctx=await browser.newContext({locale:'pt-BR'});const page=await ctx.newPage();page.setDefaultTimeout(30000);
await page.goto(root+'wp-login.php?redirect_to='+encodeURIComponent(root+'wp-admin/admin.php?page=f3base-leads'));await page.locator('#user_login').fill(process.env.F3BASE_QA_USUARIO);await page.locator('#user_pass').fill(process.env.F3BASE_QA_SENHA);await page.locator('#wp-submit').click();await page.waitForURL(/wp-admin/);
if (phase==='interacoes') {
const assert=require('node:assert/strict');
async function seguir(alvo) {
    await Promise.all([page.waitForEvent('domcontentloaded'), alvo.click()]);
}
const test={};
const check=(key,ok)=>{assert.ok(ok,key);test[key]=true;};
await page.goto(root+'wp-admin/admin.php?page=f3base-leads&busca=Exemplo');
check('50_na_primeira',await page.locator('.f3c-rolagem tbody tr').count()===50);
await seguir(page.locator('.tablenav-pages a.next'));
check('3_na_segunda',await page.locator('.f3c-rolagem tbody tr').count()===3);
check('aviso_visivel',await page.getByText('Dados de apresentação indisponíveis',{exact:true}).isVisible());
await seguir(page.getByRole('link',{name:'Contato Exemplo 54',exact:true}));
check('detalhe_historico_validado',!(await page.locator('body').innerText()).match(/critical error|erro crítico/i) && await page.getByText('Entrega de avisos',{exact:true}).count()===1);
await seguir(page.getByRole('link',{name:'Voltar à lista filtrada'}));
check('volta_na_pagina_2',new URL(page.url()).searchParams.get('paged')==='2' && new URL(page.url()).searchParams.get('busca')==='Exemplo');
const csv=await page.request.get(await page.getByRole('link',{name:'Exportar CSV'}).getAttribute('href'));
check('csv_todo_o_recorte',csv.ok() && (await csv.text()).trim().split('\n').length===54 && (csv.headers()['content-type']||'').includes('text/csv'));
await page.goto(root+'wp-admin/admin.php?page=f3base-leads&busca=Exemplo&campanha_id=123');
check('filtros_avancados_abertos',await page.locator('form details[open] input[name=campanha_id]').isVisible());
await seguir(page.getByRole('link',{name:/Remover filtro Campanha · 123/}));
check('selo_preserva_busca',new URL(page.url()).searchParams.get('busca')==='Exemplo' && !new URL(page.url()).searchParams.has('campanha_id'));
await seguir(page.locator('.f3c-subnav').getByRole('link',{name:'Testes',exact:true}));
check('aba_testes',await page.locator('.f3c-rolagem tbody tr').count()===1);
await seguir(page.locator('.f3c-subnav').getByRole('link',{name:'Lixeira',exact:true}));
check('aba_lixeira',await page.locator('.f3c-rolagem tbody tr').count()===1);
fs.writeFileSync(out+'/interacoes.json',JSON.stringify(test,null,2));
await browser.close(); return;
}
const routes={'contatos':'f3base-leads','contatos-filtro':'f3base-leads&busca=Exemplo','testes':'f3base-leads&segmento=somente_testes','lixeira':'f3base-leads&lixeira=1','formularios':'f3base-formularios','privados':'f3base-conteudos','config':'base-site-core-fator3','tecnica':'base-site-core-fator3&aba=tecnica','operacao':'base-site-core-fator3&aba=operacao'};
for(const area of ['geral','conteudo','sessoes','aquisicao','agentes','conversao','ga4','clarity','tecnico'])routes['rel-'+area]='f3base-medicao&area='+area;
if(phase==='subabas'){
for(const k of Object.keys(routes))delete routes[k];
for(const secao of ['inicio','conexoes','contato','medicao-tags','medicao-meta','medicao-coleta','medicao-gsc','medicao-ga4','medicao-clarity','medicao-testes','consentimento','privacidade','conteudo','seo'])routes['config-'+secao]='base-site-core-fator3&secao='+secao;
const views={conteudo:['pagina','artigo','outro'],aquisicao:['aquisicao','campanhas','gsc'],agentes:['resumo','origem_ia','referencias','horas','frequencia'],conversao:['resultados','formularios','ofertas','metodos','superficies','materiais','demanda','operacao','emails_normalizacao','telefones_normalizacao'],comportamento:['blocos','paginas','tempo','profundidade','saidas','eventos'],tecnico:['qualidade','vitais','erros','friccao','sondas','acessos','coleta']};
for(const [area,tabs] of Object.entries(views))for(const tab of tabs)routes[area+'-'+tab]='f3base-medicao&area='+area+'&visao='+tab;
routes['operacao-entregas']='base-site-core-fator3&aba=operacao&fila=entregas';
routes['operacao-avisos']='base-site-core-fator3&aba=operacao&fila=avisos';
}
if(phase==='recuperacao'){for(const k of Object.keys(routes)) delete routes[k];routes.recuperacao='f3base-recuperacao';}
const checks=[];for(const width of [360,768,1440]){await page.setViewportSize({width,height:900});for(const [key,route] of Object.entries(routes)){if(phase==='antes'&&!key.startsWith('contatos'))continue;
const resp=await page.goto(root+'wp-admin/admin.php?page='+route,{waitUntil:'domcontentloaded'});const main=page.locator('body');const body=await page.locator('body').innerText();checks.push({key,width,status:resp.status(),critico:/critical error|erro cr[ií]tico/i.test(body),title:await main.locator('h1').first().textContent({timeout:500}).catch(()=>''),largura:await page.evaluate(()=>document.documentElement.scrollWidth)});await page.screenshot({path:out+'/'+key+'-'+width+'.png'});fs.writeFileSync(out+'/resultados.json',JSON.stringify(checks,null,2));}}
await browser.close();})().catch(e=>{console.error(e);process.exit(1)});
