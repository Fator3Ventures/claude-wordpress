<?php
require __DIR__.'/bootstrap-1790.php';
require __DIR__.'/crm-1760.php';
global $wpdb;
$_SERVER['REMOTE_ADDR']='192.0.2.1';
$_SERVER['HTTP_USER_AGENT']='Fator3 QA local';
$pixel='123456789';$http=[];$tests=F3Base_Testes::padrao();
$tests['destinos']['capi']='marcar';$tests['capi_test_event_code']='TESTLOCAL';
add_filter('pre_option_f3base_testes',static function() use(&$tests){return $tests;});
add_filter('pre_option_f3base_meta_transporte',static fn()=>['modo'=>'ambos','eventos'=>['PageView','Lead']]);
add_filter('pre_option_f3base_meta_capi_pixel_id',static fn()=>$pixel);
$secret=F3Base_Segredos::cifrar(F3Base_Modulo_Meta_Capi::OPTION_TOKEN,'fixture-local');
add_filter('pre_option_f3base_meta_capi_token',static fn()=>$secret);
add_filter('pre_http_request',static function($result,$args,$url)use(&$http,$pixel){
    if(!str_starts_with($url,'https://graph.facebook.com/')||!str_ends_with($url,'/'.$pixel.'/events')){return $result;}
    $body=json_decode($args['body'],true);$http[]=['code'=>$body['test_event_code']??null,'nome'=>$body['data'][0]['event_name'],'event'=>$body['data'][0]['event_id']];
    return ['headers'=>[],'response'=>['code'=>200,'message'=>'OK'],'body'=>'{"events_received":1,"fbtrace_id":"fixture"}','cookies'=>[]];
},PHP_INT_MAX,3);
function capture1760($name='PageView',$test=true,$id=null){
    $id??=bin2hex(random_bytes(16));$req=new WP_REST_Request('POST','/f3base/v1/meta-eventos');
    $req->set_header('Content-Type','application/json');$req->set_header('Origin',home_url());
    $req->set_body(wp_json_encode(['nome'=>$name,'evento'=>$id,'criado_em'=>time(),'token'=>F3Base_Modulo_Endpoint_Leads::emitir_token(),'contexto_teste'=>$test,'caminho'=>'/','navegador_observado'=>true]));
    return [$id,F3Base_Meta_Transporte::receber($req)];
}
$_COOKIE['f3base_capi_ref']=bin2hex(random_bytes(32));
check(F3Base_Meta_Transporte::publico()['testeCapi']==='marcar','publica_apenas_habilitacao');
foreach([true,false] as $test){
    [$id,$response]=capture1760('PageView',$test);
    check($response->get_status()===200&&!empty($response->get_data()['enfileirado']),'captura_pageview_'.(int)$test);
    $res=F3Base_Modulo_Meta_Capi::enviar('meta-page-'.$id);$receipt=F3Base_Capi_Fila::ler('meta-page-'.$id);
    check($res['ok']&&$receipt['estado']==='entregue'&&(int)$receipt['http']===200,'despacho_'.(int)$test);
    check(end($http)===['code'=>$test?'TESTLOCAL':null,'nome'=>'PageView','event'=>$id],'separacao_http_'.(int)$test);
    F3Base_Modulo_Meta_Capi::enviar('meta-page-'.$id);
}
check(count($http)===2,'repeticao_sem_reenvio');
[$revoked]=capture1760();
$r=new WP_REST_Request('POST','/');$r->set_header('content-type','application/json');$r->set_header('origin',home_url());$r->set_header('x-f3base-consentimento','1');
$r->set_body(wp_json_encode(['operacao'=>'revogar_pageview','comprovante_anterior'=>$_COOKIE['f3base_capi_ref']]));
check(F3Base_Consentimento_Decisoes::receber($r)->get_data()['persisted'],'revogacao_confirmada');
check(F3Base_Modulo_Meta_Capi::enviar('meta-page-'.$revoked)['codigo']==='negativa_explicita','revogacao_antes_http');
$_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='denied';
check(capture1760()[1]->get_status()===403,'rodape_impede_captura');unset($_COOKIE[F3Base_Modulo_Consentimento::COOKIE]);
$_COOKIE['f3base_capi_ref']=bin2hex(random_bytes(32));
[$old]=capture1760('PageView',false);$wpdb->update(F3Base_Capi_Fila::tabela(),['decisao_ref'=>'','estado'=>'suspenso','motivo'=>'consentimento_indisponivel'],['record_id'=>'meta-page-'.$old]);
F3Base_Capi_Fila::recuperar();check(F3Base_Capi_Fila::ler('meta-page-'.$old)['estado']==='entregue','retoma_1751_uma_vez');
$tests['capi_test_event_code']='';$x=capture1760()[1];check(!empty($x->get_data()['suprimido']),'teste_sem_codigo_suprimido');$tests['capi_test_event_code']='TESTLOCAL';
$id=bin2hex(random_bytes(16));$d=['contexto_teste'=>true,'metodo'=>'formulario','consentimento_snapshot'=>['medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:'.F3Base_Modulo_Consentimento::politica_versao()],'meta_lead_modo'=>'imediato','telefone'=>'+5511987654321','pagina'=>'/','correlation_id'=>$id];
$wpdb->insert(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id,'correlacao'=>$id,'classe_trafego'=>'teste','metodo'=>'formulario','captura'=>'aceito','criado_em'=>current_time('mysql',true),'atualizado_em'=>current_time('mysql',true),'email'=>'lead@example.test','pagina'=>'/','dados'=>wp_json_encode($d),'anexos'=>'[]','payload_hash'=>hash('sha256',$id)]);
wp_set_current_user(0);
$s=F3Base_Modulo_Meta_Capi::agendar_registro($id,true);
check(!empty($s['agendado']),'lead_aceito_agendado');
check(capture1760('Lead',true,$id)[1]->get_status()===200,'lead_teste_observado');
check(capture1760('Lead',false,$id)[1]->get_status()===409,'lead_outra_classe_recusado');
$res=F3Base_Modulo_Meta_Capi::enviar($id);
check($res['ok']&&end($http)===['code'=>'TESTLOCAL','nome'=>'Lead','event'=>$id],'lead_apenas_teste');
check(empty(F3Base_Qualidade_Destinos::previa(['record_id'=>$id,'etapa'=>'qualificado'])['ok']),'previa_privada');
wp_set_current_user(1);
$consConfig=F3Base_Options::ler('f3base_consentimento');
$consConfig['modo']='granular';
$filter=static function()use(&$consConfig){return $consConfig;};
add_filter('pre_option_f3base_consentimento',$filter);
$ref=bin2hex(random_bytes(32));$version=F3Base_Modulo_Consentimento::politica_versao();
$table=$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA;
$wpdb->insert($table,['ref'=>$ref,'politica_versao'=>$version,'medicao'=>1,'publicidade'=>1,'revogada'=>0,'expira_em'=>time()+500]);
$reason=static fn($v)=>F3Base_Consentimento_Decisoes::motivo_pageview($ref,$v);
check($reason($version)==='','granular_ambas_permitidas');
$wpdb->update($table,['medicao'=>0],['ref'=>$ref]);check($reason($version)==='negativa_explicita','granular_medicao_negada');
$wpdb->update($table,['medicao'=>1,'publicidade'=>0],['ref'=>$ref]);check($reason($version)==='negativa_explicita','granular_publicidade_negada');
$wpdb->update($table,['publicidade'=>1,'revogada'=>1],['ref'=>$ref]);check($reason($version)==='negativa_explicita','granular_revogada');
$wpdb->update($table,['revogada'=>0,'expira_em'=>time()-10],['ref'=>$ref]);check($reason($version)==='decisao_ausente','granular_expirada');
$wpdb->delete($table,['ref'=>$ref]);check($reason($version)==='decisao_ausente','granular_referencia_perdida');
$consConfig['modo']='legado';$consConfig['publicidade_politica']='exigir_decisao';
$version=F3Base_Modulo_Consentimento::politica_versao();
check($reason('legado:'.$version)==='decisao_ausente','legado_alterado_para_exigir_decisao');
check($reason('aceite:'.$version)==='','legado_preserva_aceite_explicito');
check($reason('legado:obsoleta')==='politica_alterada','politica_obsoleta');
remove_filter('pre_option_f3base_consentimento',$filter);
foreach(f3qa1760_crm() as $name=>$ok){check($ok,$name);}
evidence('pedidos-383-385',['requests_http_interceptadas'=>count($http)]);
