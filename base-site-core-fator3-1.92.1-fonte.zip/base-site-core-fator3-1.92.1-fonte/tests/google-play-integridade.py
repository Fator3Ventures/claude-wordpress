"""Auditoria independente dos fragmentos, relações Device e famílias publicadas."""
from collections import defaultdict,Counter
from pathlib import Path
import csv,hashlib,gzip,json,re,sys
root=Path(__file__).resolve().parents[1]
ref=root/'reference/417/supported_devices.csv';d=root/'work/plugin/base-site-core-fator3/dados/google-play'
sys.path.insert(0,str(root/'build'))
from criterios_aparelhos import is_market
meta=json.loads((d/'base.json').read_text());assert meta['sha256_fonte']==hashlib.sha256(ref.read_bytes()).hexdigest()
norm=lambda x:' '.join(x.lower().split())
def label(v):
    v=re.sub(r'(?:[ _-]+|[ (\[]+)(?:eea|eu|ru|us|uk|in|br|jp|kr|cn|tw|latam|emea|global)[)\]]?$','',norm(v))
    return ''.join(c for c in v if c.isalnum() or c=='+')
records=defaultdict(set);devices=defaultdict(set)
with ref.open(encoding='utf-16',newline='') as fp:
    for row in list(csv.reader(fp))[1:]:
        b,n,dv,m=(v.strip() for v in row)
        if m:
            records[norm(m)].add((b,n,dv,m))
            if dv:devices[norm(dv)].add((b,n,dv,m))
seen={};reasons=Counter();extended=[]
for p in d.glob('*.gz'):
    for k,row in json.loads(gzip.decompress(p.read_bytes())).items():
        assert k not in seen and hashlib.sha256(k.encode()).hexdigest().startswith(p.name[:2]),k
        seen[k]=row;brand,name,dev,reason=row;reasons[reason]+=1
        own=[r for r in records[k] if norm(r[1])==k]
        anchors={(norm(r[0]),norm(r[2])) for r in own or records[k] if r[2]}
        candidates={r for b,dv in anchors for r in devices[dv] if r[1] and not is_market(r[1]) and norm(r[3])!=k and label(r[1])!=label(k) and label(r[1])!=label(r[3])}
        possible=[r for r in records[k] if norm(r[1])==norm(name)]
        if reason=='nome_google':
            assert not is_market(name),k
            if not possible:
                assert candidates and len(anchors)==1,k
                assert len({label(r[1]) for r in candidates})==1,k
                assert len({norm(r[0]) for r in candidates}|{b for b,dv in anchors})==1,k
                assert any(norm(r[1])==norm(name) and norm(r[2])==norm(dev) for r in candidates),k
                extended.append(k)
            elif dev:assert any(norm(r[0])==norm(brand) and norm(r[2])==norm(dev) for r in possible),k
        else:assert norm(name)==k,k
assert seen.keys()==records.keys() and len(seen)==meta['modelos']
families=json.loads((d/'familias.json').read_text())
for prefix,(b,n,dv,why) in families.items():
    siblings=[k for k in records if re.fullmatch(re.escape(prefix)+r'[a-z]',k)]
    assert len(siblings)>=2 and why=='familia_google',prefix
    assert len({(norm(row[0]),norm(row[2])) for k in siblings for row in records[k]})==1,prefix
    assert {label(seen[k][1]) for k in siblings}=={label(n)},prefix
    assert all(seen[k][3]=='nome_google' and label(seen[k][1])!=label(k) for k in siblings),prefix
assert families['25062rn2d'][1]=='Redmi 15'
assert seen['pdst00'][1]=='Reno5 Pro 5G'
assert seen['lm-x420'][1]=='X4(2019)'
assert label('S9+')!=label('S9') and label('Model (EU)')==label('Model')
print(json.dumps({'codigos':len(seen),'motivos':reasons,'blocos':len(list(d.glob('*.gz'))),'nomes_entre_modelos':len(extended),'familias':len(families),'ok':True},ensure_ascii=False))
