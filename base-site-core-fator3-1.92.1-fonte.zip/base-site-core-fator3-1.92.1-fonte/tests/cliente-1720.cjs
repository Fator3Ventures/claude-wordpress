/** Reconstructed behavioral tests. Real distributed scripts; jsdom and controlled providers. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {JSDOM}=require('./dom/node_modules/jsdom');
const root=path.resolve(__dirname,'..'),plugin=path.join(root,'work/plugin/base-site-core-fator3');
const checks={};
function check(name,ok){assert(!(name in checks),'duplicate '+name);checks[name]=!!ok;assert(ok,name);}
const tick=()=>new Promise(r=>setTimeout(r,15));
async function vital(asset,pageVersion,seed=null,base=plugin){
  const dom=new JSDOM('<html><body><main><img></main></body></html>',{url:'https://fixture.test/pagina/',runScripts:'outside-only',pretendToBeVisual:true});
  const w=dom.window;let consent=true,callback;const requests=[];
  w.Request=Request;w.TextEncoder=TextEncoder;
  w.performance.getEntriesByType=type=>type==='navigation'?[{responseStart:100,activationStart:0}]:[];
  w.performance.getEntriesByName=()=>[];w.matchMedia=()=>({matches:false});
  w.f3baseConsentimento={permiteCategoria:()=>consent,permiteGtm:()=>false};
  const context={pronto:()=>true,teste:()=>false,politica:()=> 'normal',audiencia:()=>({}),navegacao:()=>null,sinais:()=>({}),atribuicao:()=>({}),audienciaExcluida:false};
  Object.defineProperty(w,'f3baseContexto',{get:()=>context,set:()=>{}});
  w.f3baseTrackingDados={caminho:'nenhum',vitaisUrl:'/vendor.js',vitaisMaxAtualizacoes:60,
    comportamento:{eventos:{teste_vital:{gatilho:'desempenho',teto:50,parametros:['metrica','valor'],limiar:{vitais:['LCP'],duracao_minima_ms:[16]}}}},
    resumo:{ativo:true,endpoint:'/capture',token:'fixture',maximo:50,maximoLog:180,maximoVisita:1000}};
  if(pageVersion!==undefined)w.f3baseTrackingDados.vitaisVersaoPagina=pageVersion;
  w.webVitals={onLCP:cb=>{callback=cb;}};
  w.fetch=async(url,options={})=>{requests.push(JSON.parse(options.body));return {status:503,ok:false};};
  if(seed)for(const [k,v] of Object.entries(seed))w.localStorage.setItem(k,v);
  w.eval(fs.readFileSync(path.join(base,'assets',asset),'utf8'));await tick();
  assert.equal(typeof callback,'function',asset+' collector');
  return {w,requests,emit:(id,value)=>callback({id,name:'LCP',value,navigationType:'navigate',entries:[{element:w.document.querySelector('img'),url:''}]}),
    sample:id=>JSON.parse(w.localStorage.getItem('f3base_sessao')).acumulado.metricas.find(x=>x.amostra?.id===id)?.amostra,
    storage:()=>Object.fromEntries(Array.from({length:w.localStorage.length},(_,i)=>{const k=w.localStorage.key(i);return[k,w.localStorage.getItem(k)];})),
    deny:()=>{consent=false;},close:()=>w.close()};
}
async function leads(asset,mask,options={}){
  const dom=new JSDOM('<html><body></body></html>',{url:'https://fixture.test/',runScripts:'outside-only'});
  const w=dom.window,google=[],meta=[],confirmed=[];let ready=!options.pending;
  w.f3baseLeadsDados={medicao:{ads:{id:'AW-123',label:'fixture'},meta:{pixelId:'123',modo:'navegador'},linkedin:{}}};
  w.f3baseContexto={pronto:()=>ready,pendente:()=>!ready,teste:()=>!!options.test,politica:()=> 'normal'};
  w.f3baseConsentimento={permiteCategoria:()=>!options.deny,permiteGtm:()=>false};
  w.gtag=(...args)=>google.push(args);w.fbq=(...args)=>meta.push(args);
  w.document.addEventListener('f3base-lead-confirmado',ev=>confirmed.push(ev.detail));
  w.eval(fs.readFileSync(path.join(plugin,'assets',asset),'utf8'));await tick();
  const detail={formulario:'fixture',correlacao:'corr',method:'formulario',contexto_teste:!!options.test,
    transporte:{ga4:'navegador',google_ads:'navegador'},conversao:{elegivel:true,event_id:'event1720',supressoes:options.suppress?{google_ads:true,meta:true}:{} }};
  const emit=()=>w.document.dispatchEvent(new w.CustomEvent('f3base-formulario-aceito',{detail}));
  emit();await tick();
  const key=asset+'_'+JSON.stringify(options);
  if(options.pending){check(key+'_aguarda_contexto',!confirmed.length&&!google.length&&!meta.length);ready=true;w.document.dispatchEvent(new w.Event('f3base-contexto-pronto'));await tick();}
  emit();await tick();
  const ads=google.filter(x=>x[0]==='event'&&x[1]==='conversion'),pixel=meta.filter(x=>x[0]==='track');
  const allow=!options.deny&&!options.test&&!options.suppress;
  check(key+'_ads',ads.length===(allow&&(mask&1)?1:0));
  check(key+'_pixel',pixel.length===(allow&&(mask&2)?1:0));
  check(key+'_confirmacao_local_unica',confirmed.length===1);
  check(key+'_mesmo_event_id',(!ads.length||ads[0][2].transaction_id==='event1720')&&(!pixel.length||pixel[0][3].eventID==='event1720'));
  w.close();
}
(async()=>{
  const variants=['f3base-tracking.js','f3base-tracking.min.js'];
  for(let i=0;i<32;i++)variants.push('perfis/tracking-'+i+'.min.js','perfis/publico-'+i+'.min.js');
  for(const asset of variants){
    let s=await vital(asset,'1.72.1');s.emit('sample001',200);
    check(asset+'_origem_coincidente',s.sample('sample001').versao_origem==='1.72.1');
    s.emit('sample001',220);check(asset+'_sequencia_sem_trocar_origem',s.sample('sample001').sequencia===2&&s.sample('sample001').versao_origem==='1.72.1');
    s.deny();s.emit('sample001',400);check(asset+'_recusa_nao_atualiza',s.sample('sample001').sequencia===2);s.close();
    s=await vital(asset,'1.72.0');s.emit('sample002',200);check(asset+'_html_divergente_sem_origem',!('versao_origem' in s.sample('sample002')));s.close();
  }
  for(const pageVersion of [undefined,'01.72.1','1.72.1<script>']){
    const s=await vital('f3base-tracking.js',pageVersion);s.emit('legacy001',200);
    check('html_invalido_'+String(pageVersion),!('versao_origem' in s.sample('legacy001')));s.close();
  }
  for(const origin of ['1.72.0',undefined]){
    const old=path.join(root,'history/1.72.0-runtime/base-site-core-fator3');
    let s=await vital('f3base-tracking.js',origin,null,old);s.emit('recover01',200);const seed=s.storage();s.close();
    s=await vital('f3base-tracking.js','1.72.1',seed);await tick();
    const sample=s.requests.flatMap(x=>x.metricas||[]).find(x=>x.amostra?.id==='recover01')?.amostra;
    check('fila_recuperada_'+String(origin),!!sample&&(origin?sample.versao_origem===origin:!('versao_origem' in sample)));
    s.close();
  }
  for(const [asset,mask] of [['f3base-leads.js',3],['f3base-leads.min.js',3],...[0,1,2,3].map(i=>['perfis/leads-'+i+'.min.js',i])]){
    for(const scenario of [{},{deny:true},{test:true},{pending:true},{suppress:true}])await leads(asset,mask,scenario);
  }
  const evidence={proveniencia:'reconstruído em 06/11/2026',ambiente:'jsdom 27.4.0; scripts integrais; transporte/provedores controlados; sem rede externa',checks};
  const out=path.join(root,'evidence/1721-reconstrucao/cliente-1720.json');fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(evidence,null,2)+'\n');
  console.log(Object.keys(checks).length+' client checks OK');
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
