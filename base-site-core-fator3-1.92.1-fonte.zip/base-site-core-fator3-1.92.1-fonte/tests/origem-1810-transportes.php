<?php
/** Exercita transporte somente em tabelas isoladas, com HTTP interceptado. */
function f3qa181_transportes(array $fixtures,callable $check): void {
    global $wpdb;
$png=base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jJe8AAAAASUVORK5CYII=');
$http=static fn($body,$code=200)=>['response'=>['code'=>$code,'message'=>'fixture'],'body'=>is_string($body)?$body:wp_json_encode($body),'headers'=>[]];
$calls=[];$scope=true;$uncertain=false;$fixture=function($pre,$args,$url)use(&$calls,&$scope,&$uncertain,$png,$http,$check){
    $path=wp_parse_url($url,PHP_URL_PATH);
    if($path==='/assinada'){return $http($png);}
    if($path==='/api/files.getUploadURLExternal'){$calls['reserve']=1+($calls['reserve']??0);return $http($scope?['ok'=>true,'file_id'=>'F123ABC','upload_url'=>'https://files.slack.com/upload/v1/fixture']:['ok'=>false,'error'=>'missing_scope']);}
    if($path==='/upload/v1/fixture'){$check($args['body']===$png,'slack_transfere_bytes_'.($calls['reserve']??0));return $http('OK');}
    if($path==='/api/files.completeUploadExternal'){return $http(['ok'=>true,'files'=>[['id'=>'F123ABC']]]);}
    if($path==='/api/chat.update'){$body=json_decode($args['body'],true);$calls['edit'][]=$body;return $http(['ok'=>true,'ts'=>$body['ts'],'channel'=>$body['channel']]);}
    if(str_contains($url,'fixture.pipedrive.com')){
        $calls['crm'][]=[$args['method'],$path,$args['body']];
        if($uncertain){return new WP_Error('fixture_timeout');}
        return $http(['success'=>true,'data'=>['id'=>str_contains($path,'files')?202:101]]);
    }
    return $pre;
};
add_filter('pre_http_request',$fixture,8,3);
$cc=F3Base_Options::ler('f3base_pipedrive');$cc['ativo']=true;$cc['dominio']='fixture.pipedrive.com';
update_option('f3base_pipedrive',$cc,false);
foreach(['f3base_pipedrive_token','f3base_slack_bot_token'] as $name){update_option($name,F3Base_Segredos::cifrar($name,'fixture-local'),false);}
$proof=F3Base_Pipedrive_Api::iniciar_lote();update_option('f3base_pipedrive_estado',['estado'=>'verificado']+$proof,false);
$pd=new ReflectionMethod('F3Base_Anuncio_Entrega','pipedrive');
$sl=new ReflectionMethod('F3Base_Anuncio_Entrega','arquivo_slack');
foreach($fixtures as $platform=>$f){
    $id=bin2hex(random_bytes(16));$s=[];$opp=$platform==='linkedin'?['tipo'=>'negocio','id'=>123]:['tipo'=>'lead','id'=>wp_generate_uuid4()];
    $crm=['job'=>'fixture-'.$platform,'opp'=>$opp,'url'=>F3Base_Pipedrive_Comercial::link($opp,$cc)];$img=F3Base_Anuncio_Origem::imagem($f['r']['media']);
    $check(($img['bytes']??'')===$png,$platform.'_baixa_imagem_exata');$start=count($calls['crm']??[]);
    $initial=F3Base_Anuncio_Origem::base($f['a'])['fields'];
    $pd->invokeArgs(null,[$id,&$s,$crm,$initial,null]);$sl->invokeArgs(null,[$id,&$s,$img,'fixture']);
    $pd->invokeArgs(null,[$id,&$s,$crm,$f['r']['fields'],$img]);
    $pd->invokeArgs(null,[$id,&$s,$crm,$f['r']['fields'],$img]);$sl->invokeArgs(null,[$id,&$s,$img,'fixture']);
    $writes=array_slice($calls['crm']??[],$start);
    $check(array_column($writes,0)===['POST','PUT','POST'] && ($s['nota_id']??0)===101 && ($s['arquivo_id']??0)===202,$platform.'_nota_edita_anexa_uma_vez',[$s,array_column($writes,1)]);
    $object=$platform==='linkedin'?'deal':'lead';$note=json_decode($writes[0][2],true);
    $check($note['pinned_to_'.$object.'_flag']===1 && $note[$object.'_id']===$opp['id'] && str_contains($writes[2][2],$png) && str_contains($writes[2][2],(string)$opp['id']),$platform.'_nota_fixada_e_arquivo_mesmo_alvo');
    $aviso=hash('sha256',$id);$ch=hash('sha256',$id.'parte');$initialMsg=F3Base_Slack_Thread::mensagens($f['a'])[2];
    $wpdb->insert(F3Base_Slack::tabela(),['chave'=>$ch,'aviso'=>$aviso,'record_id'=>$id,'sequencia'=>2,'tipo'=>'origem','principal'=>'','destino'=>F3Base_Slack::destino(),'canal'=>'C12345678','estado'=>'entregue','ts'=>'123.456','payload'=>F3Base_Contato_Comunicacao::cifrar($initialMsg),'proxima'=>0,'criada_em'=>time(),'atualizada_em'=>time()]);
    $msg=F3Base_Slack_Thread::mensagens($f['a'],[],$f['r']['fields'],$s['slack_file'])[2];$before=count($calls['edit']??[]);
    for($i=0;$i<2;$i++){$check(F3Base_Slack_Thread::editar(F3Base_Slack_Thread::parte($aviso,'origem'),$msg),$platform.'_edicao_'.$i);}
    $check(count($calls['edit'])===$before+1 && end($calls['edit'])['ts']==='123.456',$platform.'_mesma_resposta_sem_duplicar');
    F3Base_Anuncio_Entrega::eliminar($id);$wpdb->delete(F3Base_Slack::tabela(),['chave'=>$ch]);
    // Cada cenário tem a própria janela do orçamento da fixture local.
    if($platform!=='google'){sleep(2);}
}
$id=bin2hex(random_bytes(16));$state=[];$scope=false;$sl->invokeArgs(null,[$id,&$state,$img,'fixture']);
$check(($state['slack_estado']??'')==='Permissão files:write ausente' && empty($state['slack_file']),'slack_sem_files_write_explicito');
$uncertain=true;$before=count($calls['crm']);$pd->invokeArgs(null,[$id,&$state,$crm,$initial,null]);$pd->invokeArgs(null,[$id,&$state,$crm,$initial,null]);
$check(!empty($state['nota_incerto']) && count($calls['crm'])===$before+1,'nota_incerta_nao_reenviada');
remove_filter('pre_http_request',$fixture,8);
}
