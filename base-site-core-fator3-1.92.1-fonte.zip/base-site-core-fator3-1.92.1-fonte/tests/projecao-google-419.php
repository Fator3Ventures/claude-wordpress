<?php
if (DB_NAME!=='core190ident' || wp_get_environment_type()!=='local') { throw new Exception('Banco exclusivo de teste.'); }
$codes=json_decode(file_get_contents(__DIR__.'/../reference/419/codigos-frota.json'),true,512,JSON_THROW_ON_ERROR);
foreach($codes as $codigo) {
    $key=md5('projecao:'.$codigo);
    if(!F3Base_Perfil_Aparelho::gravar('teste',$key,$key,time(),['modelo'=>$codigo])) {throw new Exception($codigo);}
}
$r=wp_get_ability('f3base/aparelhos-sem-nome-ler')->execute(['limite'=>100]);
$sem=array_column($r['sem_nome'],'codigo');sort($sem);
if ($sem!==['220333qpg','2606frn72l','m2006c3lii','tecno kl4h'] || count($r['sem_ficha_comercial'])!==26 || $r['proximo_apos']!==null) {throw new Exception(wp_json_encode($r));}
echo wp_json_encode(['controle'=>'catálogo curado vazio em instalação descartável','codigos'=>30,'sem_nome'=>$sem,'sem_ficha_comercial'=>count($r['sem_ficha_comercial'])]);
