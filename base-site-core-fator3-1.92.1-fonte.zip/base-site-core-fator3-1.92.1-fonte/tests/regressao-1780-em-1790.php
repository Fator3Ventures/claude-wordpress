<?php
require __DIR__.'/bootstrap-1790.php';
global $wp_query, $wpdb, $wp_rewrite;
update_option('permalink_structure','/%postname%/');$wp_rewrite->init();
$post=wp_insert_post(['post_type'=>'post','post_title'=>'Ensaio Core 178','post_status'=>'publish','post_author'=>1]);
update_post_meta($post,'_f3base_autoria','organizacao');
$wp_query=new WP_Query(['p'=>$post]);$url=get_permalink($post);
$ref=static fn($id)=>['@id'=>$id];
$graph=[
 ['@id'=>'#org','@type'=>'Organization','name'=>'Organização pública'],
 ['@id'=>$url.'#art','@type'=>'NewsArticle','mainEntityOfPage'=>$ref($url),'author'=>[$ref('#privado'),$ref('#outra-ref')]],
 ['@id'=>'#webpage','@type'=>['Thing','WebPage'],'url'=>$url,'author'=>$ref('#privado')],
 ['@type'=>'WebPage','@id'=>'https://example.org/outra','author'=>$ref('#visitante')],
 ['@type'=>'WebPage','author'=>$ref('#visitante')],
 ['@type'=>'Article','mainEntityOfPage'=>'https://example.org/outra','author'=>$ref('#visitante')],
 ['@type'=>'Person','@id'=>'#privado','name'=>'Usuário técnico'],
 ['@type'=>'Person','@id'=>'#visitante','name'=>'Visitante'],
 ['@type'=>'Person','@id'=>'#outra-ref','name'=>'Entrevistada'],
 ['@type'=>'CreativeWork','contributor'=>$ref('#outra-ref')],
 ['@type'=>'Person','@id'=>'#equipe','name'=>'Equipe do site']
];
$r=F3Base_Autoria::grafo($graph);$ids=array_column($r,'@id');check($r[1]['author']['@id']==='#org' && $r[2]['author']['@id']==='#org','autoria_artigo_e_webpage');
foreach ([3,4,5] as $i)check($r[$i]===$graph[$i],'no_alheio_ou_sem_identidade_'.$i);
check(!in_array('#privado',$ids,true),'person_tecnico_sem_referencia_removido');
foreach(['#visitante','#outra-ref','#equipe'] as $id)check(in_array($id,$ids,true),'preserva_'.$id);
$pure=$graph;$pure[2]['@id']=$url.'#webpage';unset($pure[2]['url']);check(F3Base_Autoria::grafo($pure)[2]['author']['@id']==='#org','webpage_identificada_por_fragmento');
$public=wp_insert_user(['user_login'=>'interno-178','display_name'=>'Pessoa pública','user_nicename'=>'editora-publica','user_pass'=>wp_generate_password()]);
wp_update_post(['ID'=>$post,'post_author'=>$public]);update_post_meta($post,'_f3base_autoria','usuario');
check(F3Base_Autoria::grafo($graph)===$graph,'preserva_autoria_pessoal_permitida');
$m=new F3Base_Modulo_Schema_Extensao();$before=$m->estender_grafo($graph);
update_post_meta($post,'_f3base_autoria','organizacao');$after=$m->estender_grafo($graph);
check($before[2]['author']['@id']==='#privado'&&$after[2]['author']['@id']==='#org','cache_respeita_troca_de_politica');
$ok='/ensaio-core-178/';$list=[$ok,'/x?busca','/x#parte','/a'.chr(92).'b','/a/../b','/a/./b','/x%2fy','/x%5Cy','/x%2Ey','//outro','/wp-admin/a'];$posts=[];
foreach($list as $i=>$path){
 $p=wp_insert_post(['post_type'=>'post','post_title'=>'Candidato '.$i,'post_status'=>'publish']);$posts[$p]=$path;
 $event=bin2hex(random_bytes(16));$row=['evento'=>$event,'visitante'=>bin2hex(random_bytes(16)),'sessao'=>bin2hex(random_bytes(16)),'navegacao'=>bin2hex(random_bytes(16)),'post_id'=>$p,'tipo'=>'pagina','caminho'=>$path,'dispositivo'=>'desktop','navegador'=>'chrome','criado_em'=>time(),'recebido_em'=>time(),'qualidade'=>'normal','atribuicao'=>'{}','payload_hash'=>hash('sha256',$event)];
 check($wpdb->insert(F3Base_Analise::tabela(),$row)===1,'visita_'.$i);
}
add_filter('post_link',static fn($u,$p)=>isset($posts[$p->ID])?home_url($posts[$p->ID]):$u,10,2);
set_error_handler(static function($code,$msg){throw new ErrorException($msg,0,$code);});
try{$eligible=array_column(F3Base_Cache_Reaquecimento::candidatos(7),'caminho');}finally{restore_error_handler();}
foreach($list as $i=>$path)check(in_array($path,$eligible,true)===($i===0),'candidato_'.$i);
wp_set_current_user(0);
check(empty(F3Base_Cache_Reaquecimento::consultar()['ok']),'leitura_anonima_vedada');
check(empty(F3Base_Servidor::executar(['acao'=>'aplicar'])['ok']),'escrita_anonima_vedada');
check(empty(F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/AGENTES-1.78.0.md'])['ok']),'ajuda_anonima_vedada');
wp_set_current_user(1);
foreach(['AGENTES','RELEASE'] as $name){
 $f='docs/'.$name.'-1.78.0.md';$line=1;$parts=0;
 do{$d=F3Base_Configuracao_Atual::documentacao(['arquivo'=>$f,'linha'=>$line,'limite'=>3]);check(!empty($d['ok'])&&$d['sha256']===hash_file('sha256',F3BASE_PLUGIN_DIR.$f),'doc_'.$name.'_'.$line);$line=$d['proxima_linha'];$parts++;}while($line!==null&&$parts<40);
 check($line===null&&$parts>1,'doc_integral_'.$name);
}
evidence('regressao-1780-em-1790');
