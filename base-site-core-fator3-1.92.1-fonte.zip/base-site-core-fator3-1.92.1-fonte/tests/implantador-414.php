<?php
/** Exercita os contratos públicos dos dois pacotes no banco descartável. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || DB_NAME !== 'core189upgrade') {
    throw new RuntimeException('Laboratório de atualização obrigatório.');
}
require_once WP_PLUGIN_DIR . '/implantador-base/implantador-base.php';
F3Base_Imp_Pacotes::conferir_versao('base-site-core-fator3', F3BASE_PLUGIN_VERSAO);
$nome = 'f3base_medicao_editorial';
$antes = get_option($nome);
$verificacoes = 1;
$conferir = static function (bool $aprovado, string $etapa) use (&$verificacoes): void {
    if (!$aprovado) {
        throw new RuntimeException($etapa);
    }
    ++$verificacoes;
};
try {
    foreach ([[], ['SM-A105M=topo', 'Moto E6s=intermediário']] as $indice => $linhas) {
        $opcao = F3Base_Options::ler($nome);
        $opcao['catalogo_aparelhos'] = $linhas;
        $resultado = F3Base_Imp_Integracoes::escrever($nome, $opcao);
        $conferir(!empty($resultado['ok']), 'Gravação pelo contrato: ' . ($resultado['codigo'] ?? $resultado['error_code'] ?? 'resposta ausente'));
        $plano = F3Base_Imp_Frota::valores([]);
        $conferir($plano[$nome]['catalogo_aparelhos'] === $linhas, 'Preservar catálogo no plano de implantação');
        $moto = F3Base_Catalogo_Aparelhos::resolver('moto E (6s)', $linhas);
        $galaxy = F3Base_Catalogo_Aparelhos::resolver('SM-A105M', $linhas);
        $conferir($moto['faixa_sugerida'] === ($indice ? 'intermediário' : 'entrada'), 'Faixa do Moto E6s');
        $conferir($galaxy['faixa_sugerida'] === ($indice ? 'topo' : 'entrada'), 'Faixa do Galaxy A10');
    }
} finally {
    if ($antes === false) {
        delete_option($nome);
    } else {
        update_option($nome, $antes);
    }
}
$conferir(get_option($nome) === $antes, 'Restaurar configuração original do laboratório');
$plugin = get_file_data(WP_PLUGIN_DIR . '/implantador-base/implantador-base.php', ['versao' => 'Version']);
echo wp_json_encode(['core' => F3BASE_PLUGIN_VERSAO, 'implantador' => $plugin['versao'],
    'verificacoes' => $verificacoes, 'configuracao_restaurada' => true], JSON_PRETTY_PRINT);
