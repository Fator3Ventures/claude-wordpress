"""Disposable local WP only. Verify real Apache behavior with a custom public content path."""
from pathlib import Path
import os,json,sys,subprocess,urllib.request,urllib.error
if os.environ.get('F3BASE_ALLOW_LOCAL_TESTS')!='1': raise RuntimeError('Local laboratory required')
wp=Path(os.environ['F3BASE_SITE']).resolve().parent
if not (wp.parent.parent/'LOCAL_TEST_LAB').exists():raise RuntimeError('Lab marker missing')
root='http://127.0.0.1:8137'
base=wp/'conteudo.qa';base.mkdir(exist_ok=False)
upgrade=base/'upgrade';upgrade.mkdir()
(upgrade/'index.php').write_text('<?php /* sentinela */');(upgrade/'ok.txt').write_text('ok')
(upgrade/'sub').mkdir();(upgrade/'sub/index.html').write_text('controle')
(base/'upgrade-extra').mkdir();(base/'upgrade-extra/index.html').write_text('controle')
original=(wp/'.htaccess').read_bytes();data={}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args):return None
def get(path):
    try:r=urllib.request.build_opener(NoRedirect).open(root+path,timeout=8)
    except urllib.error.HTTPError as err:r=err
    with r:return [r.status,r.read(24).decode(errors='replace')]
php=sys.argv[1];prefix=Path(__file__).resolve().parent/'bootstrap-1780.php'
try:
 for key,enabled in [('ligado','true'),('desligado','false')]:
    code=f"define('WP_CONTENT_URL','{root}/conteudo.qa');require {str(prefix)!r};$cfg=F3Base_Options::ler('f3base_servidor');$cfg['bloquear_listagem']={enabled};update_option('f3base_servidor',$cfg);echo F3Base_Servidor::substituir(file_get_contents(ABSPATH.'.htaccess'),F3Base_Servidor::bloco());"
    result=subprocess.run([php,'-r',code],check=True,capture_output=True);(wp/'.htaccess').write_bytes(result.stdout)
    cases={'/conteudo.qa/upgrade/':404 if enabled=='true' else 200,'/conteudo.qa/upgrade/ok.txt':200,'/conteudo.qa/upgrade/sub/':200,'/conteudo.qa/upgrade-extra/':200,'/wp-content/upgrade/':200}
    if enabled=='true':cases['/conteudo.qa/upgrade']=404
    values={p:get(p)[0] for p in cases};print(key,values);assert values==cases
    data[key]=values
finally:
    (wp/'.htaccess').write_bytes(original)
    import shutil
    shutil.rmtree(base)
    subprocess.run([php,'-r',f"require {str(prefix)!r};$cfg=F3Base_Options::ler('f3base_servidor');$cfg['bloquear_listagem']=true;update_option('f3base_servidor',$cfg);"],check=True)
(Path(__file__).resolve().parents[1]/'evidence/1780/apache-custom.json').write_text(json.dumps(data,indent=2)+'\n')
