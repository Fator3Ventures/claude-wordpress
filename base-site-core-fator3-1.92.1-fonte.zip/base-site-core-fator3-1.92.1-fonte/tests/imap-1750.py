"""Exercise production UID FETCH framing using a synthetic TCP IMAP peer, without logging in to a mailbox."""
from pathlib import Path
import json,sys,subprocess,socketserver,re,threading
root=Path(__file__).resolve().parents[1]
commands=[]
class Peer(socketserver.StreamRequestHandler):
    def handle(self):
        while line:=self.rfile.readline():
            tag,cmd=line.decode().strip().split(' ',1); commands.append(cmd)
            uid=int(cmd.split()[2]); data=None
            if 'RFC822.SIZE' in cmd: result=f'UID {uid} RFC822.SIZE 3145728 INTERNALDATE "09-Nov-2026 09:00:00 +0000"'
            elif 'BODYSTRUCTURE' in cmd:
                result=f'UID {uid} BODYSTRUCTURE (("TEXT" "PLAIN" ("CHARSET" "UTF-8") NIL NIL "7BIT" 8 1)("APPLICATION" "PDF" ("NAME" "qa.pdf") NIL NIL "BASE64" 3130000 NIL ("ATTACHMENT" ("FILENAME" "qa.pdf"))) "MIXED")'
            else:
                m=re.search(r'BODY.PEEK\[(.+)\]<0\.(\d+)>',cmd); assert m,cmd
                section,limit=m[1],int(m[2]); assert section in ['HEADER','1'] or section.startswith('HEADER.FIELDS'),section
                header=b'From: Pessoa QA <qa@example.test>\r\nTo: site@example.test\r\nSubject: QA\r\n'+(b'Auto-Submitted: auto-replied\r\n' if uid==12 else b'')+b'\r\n'
                if section=='1':data=b'texto QA'
                elif section=='HEADER' and uid==11:data=(b'X-Long: '+b'a'*300000)[:limit]
                else:data=header[:limit]
                result=f'UID {uid} BODY[{section}]<0> {{{len(data)}}}'
            self.wfile.write(f'* 1 FETCH ({result}'.encode()+(b'\r\n'+data if data is not None else b'')+f')\r\n{tag} OK fetched\r\n'.encode())
with socketserver.TCPServer(('127.0.0.1',0),Peer) as server:
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:subprocess.run([sys.argv[1],str(root/'tests/imap-1750.php'),str(server.server_address[1])],check=True)
    finally:server.shutdown();thread.join()
assert len(commands)==13 and all('PEEK[]' not in c and 'PEEK[2]' not in c for c in commands)
(root/'evidence/1750/imap-wire.json').write_text(json.dumps({'ambiente':'servidor IMAP de teste, transporte TCP local','uids':3,'bytes_por_mensagem':3145728,'comandos':commands,'partes_de_anexo_solicitadas':0},indent=2)+'\n')
print('3 mensagens, 13 comandos, zero FETCH de anexo')
