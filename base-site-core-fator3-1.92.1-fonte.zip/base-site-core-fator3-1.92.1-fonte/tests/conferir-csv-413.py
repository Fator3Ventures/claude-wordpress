"""Verifica a saída do exportador gerada por F3_QA_CSV=1 wp eval-file tests/pedidos-413.php."""
import csv
import json
import sys
from pathlib import Path

with Path(sys.argv[1]).open(encoding='utf-8-sig', newline='') as stream:
    rows = iter(csv.reader(stream))
    header = next(row for row in rows if row and row[0] == 'sessao')
    [session] = [dict(zip(header, row, strict=True)) for row in rows]
expected = {
    'modelo': 'SM-S928B', 'nome_comercial': 'Galaxy S24 Ultra', 'ano_lancamento': '2024',
    'preco_atual_estimado_brl': '5399.00', 'linha_premium': 'sim', 'versao_sistema': '15',
    'memoria_gb': '8', 'nucleos': '8', 'rede_efetiva': '4g', 'faixa_aparelho': 'topo',
}
for key, value in expected.items():
    assert session[key] == value, (key, session.get(key), value)
assert 'classe' in json.loads(session['rede'])
assert session['tela'] == '360×800 @2x'
print(json.dumps({'linhas': 1, 'campos_verificados': expected, 'rede_do_servidor': True, 'tela': session['tela']}, ensure_ascii=False))
