"""Run the packaged browser collector with deterministic device signals and consent changes."""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
script = (root / 'work/plugin/base-site-core-fator3/assets/f3base-analise.min.js').read_text()
setup = """
window.qa={allowed:false, session:'a'.repeat(32), calls:0, asked:[], pending:null};
window.f3baseAnaliseDados={caminho:'/qa',endpoint:'/coleta'};
window.f3baseTracking={permiteTags:()=>qa.allowed,sessao:()=>qa.session,visitante:()=>'b'.repeat(32)};
window.f3baseConsentimento={permiteCategoria:()=>qa.allowed};
window.f3baseContexto={teste:()=>true,navegacao:()=>null,sinais:()=>({}),atribuicao:()=>({}),audiencia:()=>({})};
Object.defineProperty(navigator,'userAgentData',{configurable:true,value:{getHighEntropyValues(keys){
 qa.calls++;qa.asked=keys;return new Promise(resolve=>{qa.pending=resolve;});}}});
"""
def allow(page, yes):
    page.evaluate("(flag)=>{qa.allowed=flag;document.dispatchEvent(new Event('f3base-consentimento'));}", yes)

def state(page):
    return page.evaluate("()=>({calls:qa.calls, model:window.f3baseAnalise.perfilAparelho()?.modelo, events:(JSON.parse(sessionStorage.getItem('f3base_analise_fila'))?.eventos||[]).filter(x=>x.tipo==='aparelho').length})")

with sync_playwright() as play:
    browser = play.chromium.launch(executable_path=os.environ['F3BASE_CHROMIUM'],args=['--no-sandbox'])
    context = browser.new_context()
    context.route('**/*',lambda r:r.fulfill(status=200,body='<html><body></body></html>',content_type='text/html'))
    def tab():
        page=context.new_page()
        page.goto('https://fixture.test/qa')
        page.evaluate(setup)
        page.add_script_tag(content=script)
        return page
    first=tab()
    assert state(first)['calls']==0
    allow(first,True)
    first.wait_for_function('qa.calls===1')
    assert first.evaluate("qa.asked.join(',')")=='model,platformVersion'
    first.evaluate("qa.pending({model:'SM-A065M',platformVersion:'14.2.1'})")
    first.wait_for_function("window.f3baseAnalise.perfilAparelho()?.versao_sistema==='14'")
    assert state(first)['events']==1
    # Boot the next tab with the same active decision and the same session.
    second=context.new_page()
    second.goto('https://fixture.test/qa')
    second.evaluate(setup+'qa.allowed=true;')
    second.add_script_tag(content=script)
    second.evaluate("()=>navigator.locks.request('f3base_aparelho_sessao',()=>true)")
    assert state(second)['calls']==0
    first.evaluate("qa.session='c'.repeat(32)")
    allow(first,True)
    first.wait_for_function('qa.calls===2')
    allow(first,False)
    first.evaluate("qa.pending({model:'LATE',platformVersion:'99.9'})")
    assert state(first)['events']==0 and not state(first).get('model')
    first.evaluate("Object.defineProperty(navigator,'userAgentData',{value:undefined})")
    allow(first,True)
    first.wait_for_function("window.f3baseAnalise.perfilAparelho()?.modelo===''")
    assert state(first)['events']==1
    report={'engine':browser.version,'checks':['denied_no_query','only_model_and_major_version','first_event','second_tab_no_second_query','revocation_during_query','no_hints_empty_model'],'signals':'emulated','physical_device':False}
    (root/'evidence/1830/navegador-396.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
    browser.close()
