<?php
/** Executar na instalação limpa e descartável, sem o plugin Google. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || DB_NAME !== 'corefresh1873') {
    throw new RuntimeException('WordPress local descartável obrigatório');
}
final class Core186LeitorCampanhaTeste {
    public static bool $autoriza = true;
    public static function capabilities(): array { return ['contract'=>F3Base_Google_Acervo::CONTRACT, 'remote_calls'=>false]; }
    public static function register_consumer(...$args): object { return new self(); }
    public function status(): array { return []; }
    public function query(array $pedido): array {
        return ['success'=>self::$autoriza && $pedido['account_id']==='1234567890' && $pedido['dataset']==='clicks', 'contract_version'=>'1.0.0'];
    }
}
$option = F3Base_Google_Acervo::OPTION;
$anterior = get_option($option);
try {
    update_option($option, array_replace(F3Base_Google_Acervo::padroes(), ['ativo'=>true, 'conexao'=>'laboratorio', 'conta_id'=>'1234567890', 'revisao'=>1]));
    F3Base_Google_Acervo::descobrir(Core186LeitorCampanhaTeste::class, F3Base_Google_Acervo::CONTRACT);
    $captura = ['dados'=>['atribuicao'=>['gclid'=>'sintetico']], 'criado_em'=>'2026-11-10 09:00:00'];
    $anuncio = ['conta_id'=>'1234567890', 'campanha_id'=>'789'];
    $arquivo = ['codigo'=>'encontrado', 'configuracao'=>F3Base_Google_Acervo::configuracao()['revision'],
        'origem_hash'=>hash('sha256',wp_json_encode([$captura['dados']['atribuicao'],strtotime($captura['criado_em'].' UTC')])),
        'clique'=>['campaign_name'=>'Campanha local', 'campaign_id'=>'789', 'date'=>'2026-11-10','account_id'=>'1234567890']];
    $ler = static fn($v, $a)=>F3Base_Google_Acervo::campanha_do_clique($captura+['google_ads'=>$v], $a);
    $r = ['array'=>$ler($arquivo,$anuncio)==='Campanha local','json'=>$ler(wp_json_encode($arquivo),$anuncio)==='Campanha local',
        'conta_divergente'=>$ler($arquivo,['conta_id'=>'2234567890']+$anuncio)==='',
        'campanha_divergente'=>$ler($arquivo,['campanha_id'=>'987']+$anuncio)==='',
        'revisao_divergente'=>$ler(['configuracao'=>'antiga']+$arquivo,$anuncio)==='',
        'captura_divergente'=>$ler(['origem_hash'=>'outra']+$arquivo,$anuncio)===''];
    Core186LeitorCampanhaTeste::$autoriza=false;
    $r['sem_concessao']=$ler($arquivo,$anuncio)==='';
    if (in_array(false,$r,true)) { throw new RuntimeException(wp_json_encode($r)); }
    echo wp_json_encode($r,JSON_PRETTY_PRINT);
} finally {
    if ($anterior===false) {delete_option($option);} else {update_option($option,$anterior);}
}
