<?php
require __DIR__.'/bootstrap-1820.php';
$doc='<html><body><main class="f3base-secao-a"><div class="f3base-alvo-teste-grupo"><p>Um</p><section class="f3base-secao-b"><p>Dois</p></section></div><p class="f3base-alvo-x f3base-alvo-y" data-f3base-alvo="atributo">Três</p><p class="f3base-alvo-A">Quatro</p></main></body></html>';
$r=F3Base_Conteudo_Instrumentacao::html($doc,home_url('/'));
check($r['cobertura_completa'],'auditoria_completa');
check(count($r['textos_sem_alvo'])===2,'cobertura_herdada_com_limite_na_secao');
check(count($r['avisos_alvo'])===1 && $r['avisos_alvo'][0]['efetivo']==='atributo','aviso_com_precedencia');
$origem='/campanha/?gclid=GC123&gad_campaignid=000123&utm_campaign=A%C3%A7%C3%A3o+de+teste&privado=nao';
foreach ([
 ['servidor',[],'pagina_servidor'],['cliente',['gclid'=>'GC123','utm_campaign'=>'Ação de teste','gad_campaignid'=>'000123'],'url_navegador'],
 ['mista',['gclid'=>'GC123'],'url_navegador_e_pagina']
] as [$nome,$dados,$fonte]){
 $a=F3Base_Atribuicao::para_captura(F3Base_Atribuicao::sem_sessao($dados,$origem,true),false,true);
 check($a['gclid']==='GC123'&&$a['campanha_id']==='000123'&&$a['gad_campaignid']==='000123'&&$a['utm_campaign']==='Ação de teste'&&$a['plataforma']==='google_ads'&&$a['cobertura']==='campanha'&&$a['cobertura_fonte']===$fonte,'origem_'.$nome);
}
$negado=F3Base_Atribuicao::para_captura(F3Base_Atribuicao::sem_sessao([],$origem,false),false,false);
check(empty($negado['gclid'])&&empty($negado['gad_campaignid'])&&empty($negado['campanha_id']),'negativa_de_publicidade');
$velho=F3Base_Atribuicao::sem_sessao(['modelo'=>'primeiro-toque','utm_campaign'=>'antiga','fbclid'=>'ontem'],$origem,true);
check(empty($velho['fbclid'])&&$velho['utm_campaign']==='Ação de teste','toque_antigo_nao_misturado');
foreach(['https://example.invalid/?gclid=x','//example.invalid/?gclid=x','javascript:x?gclid=x','/a\\b?gclid=x'] as $i=>$url){check(!F3Base_Atribuicao::parametros_pagina($url),'origem_recusada_'.$i);}
check(F3Base_Atribuicao::parametros_pagina('/?gclid=primeiro&gclid=segundo&utm_campaign[]=x&utm.source=x&livre=x')===['gclid'=>'primeiro'],'primeiro_escalar_lista_fechada');
foreach(['gbraid','wbraid','fbclid','li_fat_id','utm_source','utm_medium','utm_content','utm_term','utm_id','utm_source_platform','utm_creative_format','utm_marketing_tactic'] as $key){
 $a=F3Base_Atribuicao::para_captura(F3Base_Atribuicao::sem_sessao([],'/?'.$key.'=teste',true),false,true);
 check($a[$key]==='teste','parametro_'.$key);
}
$form=['id'=>'qa-1770','titulo'=>'QA','regime'=>'registro','campos'=>[['nome'=>'nome','tipo'=>'text','rotulo'=>'Nome','obrigatorio'=>true],['nome'=>'mensagem','tipo'=>'textarea','rotulo'=>'Mensagem','obrigatorio'=>true,'etapa'=>2],['nome'=>'opcao','tipo'=>'radio','opcoes'=>['A','B'],'rotulo'=>'Opção','etapa'=>2]]];
$dom=new DOMDocument();@$dom->loadHTML(F3Base_Formularios::renderizar_definicao($form));$xp=new DOMXPath($dom);
check($xp->query('//*[@data-etapa="2" and @hidden]')->length===2,'etapa2_oculta_no_html');
check($xp->query('//*[@data-etapa="2"]//*[@disabled]')->length===3,'controles_de_etapa2_desabilitados');
check($xp->query('//*[@data-etapa="1" and not(@hidden)]//input[not(@disabled)]')->length===1,'etapa1_disponivel');
check(F3Base_Formularios::validar_campos(F3Base_Formularios::etapa($form,1),['nome'=>'QA'],[])['ok'],'validacao_primeira_etapa_isolada');
evidence('pedidos-386-388');
