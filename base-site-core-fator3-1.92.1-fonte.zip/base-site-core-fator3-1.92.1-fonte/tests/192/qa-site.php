<?php
/** Temporário, somente no Site-Teste autorizado; remover após homologar. */
defined('ABSPATH')||exit;
if(wp_parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com')return;
add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('qa-core-1920','Verificar pacote Core 1.92.0', 'qa192site',['ensaio'=>['type'=>'string','enum'=>['lint','catalogo','agenda','estado']]],['ensaio'],false);},90);
function qa192site(array $e):array {
 if(!current_user_can('manage_options'))return ['ok'=>false];
 $out=['core'=>F3BASE_PLUGIN_VERSAO,'wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'ensaio'=>$e['ensaio']];
 try{
  if($e['ensaio']==='lint'){
   $file=WP_CONTENT_DIR.'/upgrade/f3-core-1920.zip';$z=new ZipArchive();if($z->open($file)!==true)throw new RuntimeException('ZIP ausente');
   $php=0;for($i=0;$i<$z->numFiles;$i++){if(str_ends_with($z->getNameIndex($i),'.php')){token_get_all($z->getFromIndex($i),TOKEN_PARSE);++$php;}}
   $out+=['php_verificados'=>$php,'zip_sha256'=>hash_file('sha256',$file)];$z->close();
  }elseif($e['ensaio']==='catalogo'){
   $g=F3Base_Catalogo_Aparelhos::google_play('25062RN2DA');$lg=F3Base_Catalogo_Aparelhos::resolver('lm-x420',[]);$op=F3Base_Catalogo_Aparelhos::google_play('PDST00');
   if($g['identificacao_criterio']!=='familia_google'||$g['nome_comercial']!=='Redmi 15'||$lg['nome_comercial']!=='LG K40'||$op['nome_comercial']!=='Reno5 Pro 5G')throw new RuntimeException('Catálogo divergente');
   $out+=['familia'=>$g,'lg'=>$lg,'oppo'=>$op,'meta'=>F3Base_Catalogo_Aparelhos::metadados()];
  }elseif($e['ensaio']==='estado'){
   $out+=['instalacao'=>F3Base_Instalacao::resumo(),'agenda'=>F3Base_Agenda_Filas::diagnostico(),'contrato'=>F3Base_Config_Contrato::VERSAO];
  }else{
   global $wpdb,$wp_object_cache;
   if(wp_using_ext_object_cache())throw new RuntimeException('Cache externo impede isolamento');
   if(!defined('DOING_CRON'))define('DOING_CRON',true);
   if(!class_exists('WSAL\\WP_Sensors\\WP_System_Sensor'))throw new RuntimeException('WPAL ausente');
   \WSAL\WP_Sensors\WP_System_Sensor::attach_cron_actions();
   $real=$wpdb->options;$cache=$wp_object_cache;$tmp=$wpdb->prefix.'qa192_options';
   if($wpdb->query($wpdb->prepare('CREATE TEMPORARY TABLE %i LIKE %i',$tmp,$real))===false)throw new RuntimeException('Tabela temporária indisponível');
   $wpdb->query($wpdb->prepare("INSERT INTO %i SELECT * FROM %i WHERE option_name IN ('siteurl','home','active_plugins','timezone_string','gmt_offset')",$tmp,$real));
   $wpdb->options=$tmp;$wp_object_cache=new WP_Object_Cache();$checks=[];
   try{
    $at=time()+3600;
    foreach(['f3base_meta_capi_enviar','f3base_leads_avisos','f3base_migrar_estrutura','f3base_complementos_processar','f3base_qa192'] as $hook){
     $args=$hook==='f3base_meta_capi_enviar'?['meta-page-qa192']:[];
     $checks[$hook.'_create']=wp_schedule_single_event($at,$hook,$args,true)===true;
     $checks[$hook.'_exact']=(bool)wp_get_scheduled_event($hook,$args,$at);
     $checks[$hook.'_remove']=wp_unschedule_event($at,$hook,$args,true)===true;
    }
    $hook='f3base_qa192';wp_schedule_event($at,'hourly',$hook,[],true);
    $checks['recurrence']=wp_reschedule_event($at,'hourly',$hook,[],true)===true;
    $veto=static fn($pre,$e)=>$e->hook==='f3base_qa192'?new WP_Error('qa_veto','veto'):$pre;
    add_filter('pre_schedule_event',$veto,20,2);$r=wp_schedule_single_event($at+7200,$hook,[],true);remove_filter('pre_schedule_event',$veto,20);
    $checks['veto']=is_wp_error($r)&&$r->get_error_code()==='qa_veto';
    foreach(F3Base_Fila::RECORRENCIAS as $hook=>$freq){$checks[$hook]=wp_schedule_event($at,$freq,$hook,[],true)===true&&wp_reschedule_event($at,$freq,$hook,[],true)===true&&wp_unschedule_event($at,$hook,[],true)===true;}
   }finally{$wpdb->options=$real;$wp_object_cache=$cache;$wpdb->query($wpdb->prepare('DROP TEMPORARY TABLE IF EXISTS %i',$tmp));}
   $out['checks']=$checks;if(in_array(false,$checks,true))throw new RuntimeException('Verificação falhou');
  }
  return $out+['ok'=>true];
 }catch(Throwable $err){return $out+['ok'=>false,'erro'=>$err->getMessage()];}
}
