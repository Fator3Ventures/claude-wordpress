<?php
define('DOING_CRON',true);
require $argv[1].'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
if(wp_get_environment_type()!=='local' || !str_starts_with(DB_NAME,'core192_'))exit(2);
wp_set_current_user(1);
$checks=[];$out=[];$new=F3BASE_PLUGIN_VERSAO==='1.92.0';
$check=static function($name,$ok)use(&$checks){$checks[$name]=(bool)$ok;if(!$ok)fwrite(STDERR,"FAIL $name\n");};
$check('wsal_active',is_plugin_active('wp-security-audit-log/wp-security-audit-log.php'));
$hooks=['f3base_meta_capi_enviar','f3base_leads_avisos','f3base_migrar_estrutura','f3base_complementos_processar','f3base_qa192_future'];
$at=time()+3600;
// Preserve every unrelated native occurrence.
$before=_get_cron_array();
foreach($hooks as $index=>$hook){
    $args=$index===0?['meta-page-qa192']:[];
    $once=wp_schedule_single_event($at,$hook,$args,true);
    $check($hook.'_create',$once===true);
    $check($hook.'_identity',(bool)wp_get_scheduled_event($hook,$args,$at));
    $check($hook.'_other_args',wp_schedule_single_event($at,$hook,['qa192-distinct'],true)===true);
    $removed=wp_unschedule_event($at,$hook,$args,true);
    $out[$hook]=['create'=>is_wp_error($once)?$once->get_error_code():$once,'remove'=>is_wp_error($removed)?$removed->get_error_code():$removed];
    $check($hook.'_removed',$removed===true && !wp_get_scheduled_event($hook,$args,$at));
    $check($hook.'_other_preserved',(bool)wp_get_scheduled_event($hook,['qa192-distinct'],$at));
    wp_unschedule_event($at,$hook,['qa192-distinct'],true);
}
$hook='f3base_qa192_periodic';
$check('recurrence_create',wp_schedule_event($at,'hourly',$hook,['r'],true)===true);
$check('recurrence_reschedule',wp_reschedule_event($at,'hourly',$hook,['r'],true)===true);
wp_clear_scheduled_hook($hook,['r']);
// Simulate a different pre-filter persisting a removal before the actual sensor.
$hook='f3base_meta_capi_enviar';$args=['meta-page-proof192'];
wp_schedule_single_event($at,$hook,$args,true);
$early=static function($pre,$when,$target,$arguments)use($hook,$args){
    if($target!==$hook||$arguments!==$args)return $pre;
    $cron=_get_cron_array();unset($cron[$when][$target][md5(serialize($arguments))]);
    if(empty($cron[$when][$target]))unset($cron[$when][$target]);
    if(empty($cron[$when]))unset($cron[$when]);
    $saved=_set_cron_array($cron,true);
    return $saved===true?true:$saved;
};
add_filter('pre_unschedule_event',$early,20,4);
$r=wp_unschedule_event($at,$hook,$args,true);remove_filter('pre_unschedule_event',$early,20);
$out['early_remove']=is_wp_error($r)?$r->get_error_code():$r;
$check('early_removal',$new?$r===true:is_wp_error($r)&&$r->get_error_code()==='could_not_set');
if($new){
    foreach(['pre_schedule_event','pre_reschedule_event','pre_unschedule_event'] as $filter){
        foreach([20,PHP_INT_MAX] as $priority){
            foreach([false,new WP_Error('qa192_veto','Veto real preservado')] as $decision){
                $target='f3base_qa192_veto';
                wp_schedule_event($at,'hourly',$target,[],true);
                $veto=static function($pre,...$args)use($decision,$filter,$target){
                    $h=$filter==='pre_unschedule_event'?$args[1]:$args[0]->hook;
                    return $h===$target?$decision:$pre;
                };
                add_filter($filter,$veto,$priority,5);
                // Late observer is deliberately re-added after a same-priority veto.
                global $wp_filter;
                foreach($wp_filter[$filter]->callbacks[PHP_INT_MAX]??[] as $key=>$entry){
                    $fn=$entry['function'];$actual=$fn;
                    while($actual instanceof Closure){
                        $r=new ReflectionFunction($actual);
                        if($r->getClosureScopeClass()?->getName()==='WSAL\\WP_Sensors\\WP_System_Sensor'){
                            unset($wp_filter[$filter]->callbacks[PHP_INT_MAX][$key]);
                            add_filter($filter,$actual,PHP_INT_MAX,$entry['accepted_args']);
                            break;
                        }
                        $vars=$r->getStaticVariables();$actual=$vars['callback']??$vars['fn']??null;
                    }
                }
                $result=match($filter){
                    'pre_schedule_event'=>wp_schedule_single_event($at+7200,$target,[],true),
                    'pre_reschedule_event'=>wp_reschedule_event($at,'hourly',$target,[],true),
                    default=>wp_unschedule_event($at,$target,[],true)
                };
                remove_filter($filter,$veto,$priority);
                $check($filter.'_veto_'.$priority.'_'.(is_wp_error($decision)?'error':'false'),is_wp_error($result));
                $check($filter.'_occurrence_'.$priority.'_'.(is_wp_error($decision)?'error':'false'),(bool)wp_get_scheduled_event($target,[],$at));
                wp_clear_scheduled_hook($target);
            }
        }
    }
    // A Core call must not hide the original sensor from the official Meta fix.
    foreach(['f3_meta_worker'] as $worker){
        wp_clear_scheduled_hook($worker);
        for($turn=0;$turn<3;$turn++){
            wp_schedule_single_event($at,'f3base_qa192_interleave',[$turn],true);
            wp_unschedule_event($at,'f3base_qa192_interleave',[$turn],true);
            $check($worker.'_interleave_create_'.$turn,wp_schedule_single_event($at,$worker,[],true)===true);
            $veto=static fn($pre,$e)=>$e->hook===$worker?new WP_Error('qa192_veto','veto'):$pre;
            add_filter('pre_schedule_event',$veto,20,2);
            $v=wp_schedule_single_event($at+7200,$worker,[],true);remove_filter('pre_schedule_event',$veto,20);
            $out[$worker]['veto'][$turn]=is_wp_error($v)?$v->get_error_code():$v;
            $check($worker.'_interleave_veto_'.$turn,is_wp_error($v)&&$v->get_error_code()==='qa192_veto');
            $early=static function($pre,$when,$target,$arguments)use($worker){
                if($target!==$worker)return $pre;
                $cron=_get_cron_array();unset($cron[$when][$target][md5(serialize($arguments))]);
                if(empty($cron[$when][$target]))unset($cron[$when][$target]);
                if(empty($cron[$when]))unset($cron[$when]);
                return _set_cron_array($cron,true);
            };
            add_filter('pre_unschedule_event',$early,20,4);
            $v=wp_unschedule_event($at,$worker,[],true);remove_filter('pre_unschedule_event',$early,20);
            $out[$worker]['remove'][$turn]=is_wp_error($v)?$v->get_error_code():$v;
            $check($worker.'_interleave_remove_'.$turn,$v===true);
        }
    }
    global $wpdb;
    $original=$wpdb->options;
    $wpdb->options=$wpdb->prefix.'qa192_table_missing';
    $wpdb->suppress_errors(true);
    $failed=wp_schedule_single_event($at,'f3base_qa192_db_fail',[],true);
    $wpdb->options=$original;$wpdb->suppress_errors(false);
    $check('persistence_failure',is_wp_error($failed)&&$failed->get_error_code()==='could_not_set');
    $six=F3Base_Fila::RECORRENCIAS;
    foreach($six as $queue=>$schedule){
        $check($queue.'_create',wp_schedule_event($at,$schedule,$queue,[],true)===true);
        $check($queue.'_reschedule',wp_reschedule_event($at,$schedule,$queue,[],true)===true);
        $check($queue.'_remove',wp_unschedule_event($at,$queue,[],true)===true);
    }
}
$after=_get_cron_array();
foreach($before as $time=>$events){
    foreach($events as $h=>$args){
        if(in_array($h,$hooks,true)||isset(F3Base_Fila::RECORRENCIAS[$h]))continue;
        $check('unrelated_'.$h.'_'. $time,($after[$time][$h]??null)===$args);
    }
}
$ok=!in_array(false,$checks,true);
file_put_contents($argv[2],wp_json_encode(['version'=>F3BASE_PLUGIN_VERSAO,'checks'=>$checks,'results'=>$out,'ok'=>$ok],JSON_PRETTY_PRINT));
echo wp_json_encode(['checks'=>count($checks),'ok'=>$ok]);
exit($ok?0:1);
