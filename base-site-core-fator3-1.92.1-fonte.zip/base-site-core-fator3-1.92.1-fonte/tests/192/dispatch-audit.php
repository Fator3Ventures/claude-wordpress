<?php
require $argv[1].'/wp-load.php';if(wp_get_environment_type()!=='local'||DB_NAME!=='core192_upgrade')exit(2);
$trace=array_map(static fn($s)=>json_decode($s,true),file($argv[2],FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));
$ids=[];$since=PHP_INT_MAX;foreach($trace as $r){$since=min($since,$r['time']);if(($r['hook']??'')==='f3base_meta_capi_enviar')$ids[$r['args'][0]]=true;}
$capi=[];foreach(array_keys($ids) as $id){$r=F3Base_Capi_Fila::ler($id);$capi[]=array_intersect_key($r??[],array_flip(['estado','motivo','tentativas','http']));}
$duplicates=$wpdb->get_results($wpdb->prepare("SELECT hook,JSON_UNQUOTE(JSON_EXTRACT(dados,'$.quando')) quando,JSON_UNQUOTE(JSON_EXTRACT(dados,'$.argumentos_sha256')) argumentos,COUNT(*) total FROM %i WHERE inicio >= %d AND sucesso=1 AND fim>0 AND tarefa<>'' AND JSON_EXTRACT(dados,'$.quando') IS NOT NULL GROUP BY hook,quando,argumentos HAVING COUNT(*)>1",F3Base_Execucoes::tabela(),$since),ARRAY_A);
$errors=$wpdb->last_error;
$counts=$wpdb->get_results($wpdb->prepare("SELECT hook,codigo,COUNT(*) total FROM %i WHERE inicio >= %d AND tarefa<>'' GROUP BY hook,codigo",F3Base_Execucoes::tabela(),$since),ARRAY_A);
echo wp_json_encode(['capi'=>$capi,'duplicate_executions'=>$duplicates,'database_error'=>$errors,'execution_counts'=>$counts,'ok'=>!$errors&&$duplicates===[]&&count($capi)===1&&$capi[0]['estado']==='entregue'&&$capi[0]['tentativas']==='1']);
