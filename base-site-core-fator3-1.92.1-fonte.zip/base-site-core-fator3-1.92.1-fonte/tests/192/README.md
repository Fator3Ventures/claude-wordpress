# Reprodução dos ensaios 1.92.0

Use WordPress 7.1.4 real, PHP 8.3+ e MariaDB em duas instalações descartáveis. WP_ENVIRONMENT_TYPE deve ser local, bancos core192_clean e core192_upgrade, prefixo wp_. A instalação limpa começa sem Core; a de atualização começa com o instalador 1.91.0 e os pacotes oficiais MCP 0.46.0, Google 0.36.0, Meta 0.28.0, LinkedIn 0.25.0, Pipedrive 0.11.1 e WP Activity Log 5.7.0. Não use credenciais reais.

- init.php recebe caminho absoluto do WordPress e modo clean/upgrade: instala o WordPress e ativa os plugins disponíveis no diretório.
- Na base 1.91.0, cron.php reproduz o could_not_set no caso de remoção já persistida. O agregado dessa versão tem verificações da nova agenda reprovadas, como esperado no controle.
- Substitua a pasta do Core pelo runtime do fonte. check.php recebe caminho do WordPress e arquivo JSON de saída; verifica migração, catálogo, 32 perfis e permissões. cron.php recebe os mesmos argumentos e usa o banco local para os ensaios de agenda; execute com os outros executores locais parados.
- google-play-integridade.py, na pasta tests, confere os 44.528 códigos sem chamar o compilador; build/gerar-google-play.py reproduz os índices e as auditorias CSV.

## Concorrência e transporte simulado

simular.py espera lab192/upgrade/wordpress e lab192/bin/php ao lado da pasta fonte. Copie observador.php para mu-plugins. Bloqueie HTTP externo com pre_http_request na prioridade 100, permitindo apenas 127.0.0.1, e bloqueie wp_mail por pre_wp_mail. O observador 192 responde localmente somente aos endereços sintéticos de Slack e CAPI na prioridade 101. dispatch-seed.php cria um contato sintético, CAPI, permissão fictícia no banco descartável, migração e complementos; nenhuma API externa é chamada.

Compile tests/420/clock.c com gcc -shared -fPIC em evidence192/simulation/clock.so, ao lado da pasta fonte. Rode simular.py no mesmo namespace de rede do MariaDB. São 97 passos em intervalos simulados de 15 min, 97 processos PHP CLI com o wp-cron nativo, 194 chamadas HTTP de cron e 97 visitas públicas. São 24 horas de relógio simulado, não uma observação real de 24 horas nem uma execução do comando WP-CLI. A execução validada durou cerca de um minuto.

Depois, execute dispatch-audit.php com caminho do WordPress e caminho de trace.jsonl. A prova verifica uma entrega CAPI com uma tentativa e nenhuma execução bem-sucedida duplicada por hook/quando/argumentos no diário. Callback chamado por dois executores pode terminar como reserva_ocupada; conte o efeito confirmado e a identidade da ocorrência, não apenas a entrada no callback.

qa-site.php é uma ferramenta temporária para o Site-Teste autorizado. Tem gates de host e manage_options. A prova de agenda usa tabela TEMPORARY e cache privados da conexão. Ela é removida depois da leitura dos resultados. Não entra no instalador.

Evidências atuais: evidence/1920. Relatórios de versões antigas em evidence/1910 e anteriores não provam esta versão. A janela real do Site-Teste e o aceite em produção permanecem separados.
