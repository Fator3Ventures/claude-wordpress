<?php
require $argv[1].'/wp-load.php';if(wp_get_environment_type()!=='local'||DB_NAME!=='core192_upgrade')exit(2);
wp_set_current_user(1);
update_option('f3base_avisos',['canal'=>'slack','slack_transporte'=>'webhook','slack_formato'=>'compacto','slack_canal_id'=>'']);
update_option(F3Base_Avisos::SEGREDO,F3Base_Segredos::cifrar(F3Base_Avisos::SEGREDO,'https://hooks.slack.com/services/QA192/QA192/QA192'));
update_option(F3Base_Modulo_Meta_Capi::OPTION_TOKEN,F3Base_Segredos::cifrar(F3Base_Modulo_Meta_Capi::OPTION_TOKEN,'synthetic192'));
$lead=F3Base_Leads_Repositorio::guardar(['nome'=>'Contato Sintético 192','email'=>'fixture192@example.invalid','metodo'=>'contato_externo','origem_nativa'=>true,'notificar'=>true,'criado_em'=>gmdate('Y-m-d H:i:s',time()-600),'pagina'=>home_url('/')],'qa192-dispatch-'.wp_generate_uuid4());
update_option('f3base_meta_capi_pixel_id','1234567890');
$cfg=F3Base_Options::ler('f3base_consentimento');$cfg['modo']='granular';update_option('f3base_consentimento',$cfg);
$ref=bin2hex(random_bytes(32));$version=F3Base_Modulo_Consentimento::politica_versao();
$wpdb->insert($wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA,['ref'=>$ref,'politica_versao'=>$version,'medicao'=>1,'publicidade'=>1,'revogada'=>0,'expira_em'=>time()+172800]);
$id='meta-page-qa192-'.wp_generate_uuid4();$capi=F3Base_Capi_Fila::inserir($id,['data'=>[['event_name'=>'PageView','event_id'=>$id,'event_time'=>time(),'action_source'=>'website','user_data'=>['client_user_agent'=>'QA192']]]],7200,'1234567890',['decisao_ref'=>$ref,'politica_versao'=>$version]);
foreach(['f3base_migrar_estrutura','f3base_complementos_processar'] as $h){wp_schedule_single_event(time()+1,$h,[],true);}
echo wp_json_encode(['lead'=>$lead,'capi_queued'=>$capi,'slack_queued'=>(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Avisos::tabela().' WHERE record_id=\''.esc_sql($lead['record_id']??'').'\'')]);
