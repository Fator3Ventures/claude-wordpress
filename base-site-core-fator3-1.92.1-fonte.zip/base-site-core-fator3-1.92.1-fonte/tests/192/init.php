<?php
define('WP_INSTALLING', true);
$site = $argv[1];
$_SERVER['HTTP_HOST'] = '127.0.0.1:18920';
require $site.'/wp-load.php';
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME, 'core192_')) {exit(2);}
require_once ABSPATH.'wp-admin/includes/upgrade.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
if (!is_blog_installed()) {
    wp_install('Core 1.92 QA', 'qa192', 'qa@example.invalid', false, '', bin2hex(random_bytes(24)));
    update_option('home', 'http://127.0.0.1:18920');
    update_option('siteurl', 'http://127.0.0.1:18920');
}
wp_set_current_user(1);
$plugins=['base-site-core-fator3/base-site-core-fator3.php'];
if (DB_NAME==='core192_upgrade') {
    $plugins=array_merge($plugins, ['wp-mcp-fator3/wp-mcp-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php',
        'wp-mcp-meta-fator3/wp-mcp-meta-fator3.php','wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php',
        'wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php', 'wp-security-audit-log/wp-security-audit-log.php']);
}
foreach($plugins as $plugin) {
    $r=activate_plugin($plugin);
    if(is_wp_error($r)) {throw new RuntimeException($plugin.': '.$r->get_error_code());}
}
echo wp_json_encode(['activated'=>$plugins,'wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION]);
