<?php
$site=$argv[1];
require $site.'/wp-load.php';
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core192_')) {exit(2);}
require_once ABSPATH.'wp-admin/includes/plugin.php';
wp_set_current_user(1);
$checks=[];
function check192(string $label, bool $ok): void {
    global $checks;
    $checks[$label]=$ok;
    if(!$ok) {fwrite(STDERR,"FAIL $label\n");}
}
$first=F3Base_Instalacao::resumo();
check192('plugin_version',F3BASE_PLUGIN_VERSAO===($argv[3]??'1.92.0'));
check192('install_version',($first['versao_alvo']??'')===F3BASE_PLUGIN_VERSAO);
check192('structure_ready',F3Base_Leads_Repositorio::pronto());
$doc=wp_get_ability('f3base/como-usar');
check192('ability_available',$doc!==null);
$out=F3Base_Como_Usar::responder(['compacto'=>true]); // Direct admin path; MCP authorization is verified on Site-Teste.
check192('guide_read',is_array($out)&&($out['versao']??'')===F3BASE_PLUGIN_VERSAO);
check192('configuration_count',count(F3Base_Options::catalogo())>90);
if(F3BASE_PLUGIN_VERSAO==='1.92.0'){
    $redmi=F3Base_Catalogo_Aparelhos::google_play('25062RN2DA');
    check192('google_family',$redmi['nome_comercial']==='Redmi 15'&&$redmi['identificacao_criterio']==='familia_google');
    check192('unknown_empty',F3Base_Catalogo_Aparelhos::google_play('fake-family-192')===[]);
    check192('published_exact',F3Base_Catalogo_Aparelhos::google_play('25062RN2DE')['identificacao_criterio']==='nome_google');
    check192('oppo_device',F3Base_Catalogo_Aparelhos::google_play('PDST00')['nome_comercial']==='Reno5 Pro 5G');
    $ficha=F3Base_Catalogo_Aparelhos::resolver('LM-X420',[]);
    check192('lg_br',$ficha['nome_comercial']==='LG K40'&&$ficha['ano_lancamento']==='2019'&&(float)$ficha['preco_atual_estimado_brl']>0);
    $ficha=F3Base_Catalogo_Aparelhos::resolver('25062RN2DA',[]);
    check192('redmi_br',$ficha['nome_comercial']==='Redmi 15'&&$ficha['ano_lancamento']==='2025'&&(float)$ficha['preco_atual_estimado_brl']>0);
    $custom=['25062RN2DA=Minha Marca|Modelo Local|2026|1250.00|entrada|não'];
    check192('local_priority',F3Base_Catalogo_Aparelhos::resolver('25062RN2DA',$custom)['nome_comercial']==='Modelo Local');
    foreach (array_merge(json_decode(file_get_contents(__DIR__.'/../../reference/419/codigos-frota.json'),true),['25062rn2da','lm-x420']) as $code){
        $id=md5('qa192:'.$code);
        check192('profile_'.$code,F3Base_Perfil_Aparelho::gravar('teste',$id,$id,time(),['modelo'=>$code]));
    }
    $missing=F3Base_Catalogo_Aparelhos::sem_nome(['limite'=>200]);
    check192('projection_32',($missing['codigos_examinados']??0)===32 && $missing['sem_nome']===[] && $missing['sem_ficha_comercial']===[]);
    check192('cron_namespace',F3Base_Agenda_Filas::diagnostico()['cobertura']==='f3base_*');
}
$user=wp_create_user('reader192','synthetic-pass-192','reader192@example.invalid');
if(is_wp_error($user)){$user=get_user_by('login','reader192')->ID;}
wp_set_current_user($user);
check192('catalog_denied',F3Base_Catalogo_Aparelhos::sem_nome()['codigo']==='sem_permissao');
$r=wp_get_ability('f3base/como-usar')->execute(['compacto'=>true]);
check192('ability_denied',is_wp_error($r)||empty($r['ok']));
wp_set_current_user(1);
$result=['version'=>F3BASE_PLUGIN_VERSAO,'wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'first_status'=>$first,'checks'=>$checks,'ok'=>!in_array(false,$checks,true)];
file_put_contents($argv[2],wp_json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo wp_json_encode(['version'=>F3BASE_PLUGIN_VERSAO,'checks'=>count($checks),'ok'=>$result['ok']]);
exit($result['ok']?0:1);
