<?php
if(wp_get_environment_type()!=='local'||DB_NAME!=='core192_upgrade')return;
function trace192($type,$fields=[]){$f=getenv('F3_QA_TRACE');if($f)file_put_contents($f,wp_json_encode(['time'=>time(),'type'=>$type,'origin'=>PHP_SAPI==='cli'?'cli':'http']+$fields)."\n",FILE_APPEND|LOCK_EX);}
add_filter('pre_http_request',static function($pre,$args,$url){
 if(str_starts_with($url,'https://graph.facebook.com/')&&str_contains($url,'/1234567890/events')){trace192('transport',['destination'=>'capi']);return ['headers'=>[],'response'=>['code'=>200,'message'=>'Synthetic'],'body'=>'{"events_received":1,"fbtrace_id":"qa192"}','cookies'=>[]];}
 if($url==='https://hooks.slack.com/services/QA192/QA192/QA192'){trace192('transport',['destination'=>'slack']);return ['headers'=>[],'response'=>['code'=>200,'message'=>'Synthetic'],'body'=>'ok','cookies'=>[]];}
 return $pre;
},101,3);
foreach(['cron_reschedule_event_error','cron_unschedule_event_error'] as $type){add_action($type,static function($error,$hook)use($type){if(str_starts_with($hook,'f3base_'))trace192('cron_error',['operation'=>$type,'hook'=>$hook,'code'=>$error->get_error_code()]);},10,2);}
foreach(['f3base_meta_capi_enviar','f3base_leads_avisos','f3base_avisos_processar','f3base_migrar_estrutura','f3base_complementos_processar'] as $h){add_action($h,static function(...$args)use($h){trace192('callback',['hook'=>$h,'args'=>$args]);},PHP_INT_MAX,5);}
