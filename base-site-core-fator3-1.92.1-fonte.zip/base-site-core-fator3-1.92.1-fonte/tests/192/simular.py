"""96 passagens de 15 min do cron nativo: tempo simulado; não equivale ao aceite em 24 h reais."""
import os,pathlib,struct,subprocess,urllib.request,concurrent.futures,time,signal,json,collections
s=pathlib.Path(__file__).resolve().parents[2];root=s.parent;site=root/'lab192/upgrade/wordpress';d=root/'evidence192/simulation';d.mkdir(parents=True,exist_ok=True)
clock=d/'clock';clock.write_bytes(struct.pack('q',0));trace=d/'trace.jsonl';trace.write_text('')
php=str(root/'lab192/bin/php');env={**os.environ,'LD_PRELOAD':str(d/'clock.so'),'F3_QA_CLOCK':str(clock),'F3_QA_TRACE':str(trace),'PHP_CLI_SERVER_WORKERS':'3'}
start=int(time.time());status=[]
with (d/'server.out').open('w') as log:
 subprocess.run([php,str(s/'tests/192/dispatch-seed.php'),str(site)],env=env,stdout=(d/'seed.json').open('w'),stderr=log,check=True)
 server=subprocess.Popen([php,'-d','opcache.enable_cli=1','-S','127.0.0.1:18920','-t',str(site)],env=env,start_new_session=True,stdout=log,stderr=log)
 def request(path):
  with urllib.request.urlopen('http://127.0.0.1:18920/'+path,timeout=50) as r:
   r.read();assert r.status==200
 try:
  time.sleep(.4)
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   for tick in range(97):
    with clock.open('r+b') as timer:timer.write(struct.pack('q',start+tick*900+3-int(time.time())))
    jobs=[pool.submit(subprocess.run,[php,str(site/'wp-cron.php')],env=env,stdout=log,stderr=log,check=True,timeout=55)]
    jobs += [pool.submit(request,'wp-cron.php') for _ in range(2)]
    jobs += [pool.submit(request,'?qa192='+str(tick)) for _ in range(1)]
    for j in jobs:j.result()
    (d/'progress').write_text(str(tick+1))
 finally:
  os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=20)
rows=[json.loads(x) for x in trace.read_text().splitlines()];errors=[x for x in rows if x['type']=='cron_error'];transports=collections.Counter(x['destination'] for x in rows if x['type']=='transport');callbacks=collections.Counter(x['hook'] for x in rows if x['type']=='callback')
result={'virtual_hours':24,'actual_seconds':round(time.time()-start,2),'passes':97,'native_cli_runs':97,'direct_cron_http_200':194,'public_visits_http_200':97,'cron_errors':errors,'synthetic_transport':dict(transports),'callbacks':dict(callbacks),'real_24h_acceptance':False,'ok':not errors and transports['slack']==1 and transports['capi']==1}
(d/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result));assert result['ok']
