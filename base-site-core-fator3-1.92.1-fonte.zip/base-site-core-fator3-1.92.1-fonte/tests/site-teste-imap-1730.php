<?php
/** Temporary authenticated QA ability; install only as a removable MU fixture on Site-Teste. */
if(!defined('ABSPATH')){exit;}
add_action('wp_abilities_api_init',static function(){
 wp_register_ability('f3qa/imap-1730',[
  'label'=>'QA isolado IMAP 1.73.0','description'=>'Executa falhas sintéticas dentro de transação desfeita; intercepta e-mails e não acessa IMAP.',
  'category'=>'site','input_schema'=>['type'=>'object','properties'=>[],'additionalProperties'=>false],
  'output_schema'=>['type'=>'object','additionalProperties'=>true],
  'permission_callback'=>static fn()=>current_user_can('manage_options')&&wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com',
  'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'show_in_rest'=>false],
  'execute_callback'=>static function(){
   global $wpdb,$wp_filter;
   if(F3BASE_PLUGIN_VERSAO!=='1.73.0'||!empty(F3Base_Email_Site::cfg()['ativo'])){return ['ok'=>false,'codigo'=>'fixture_requer_core1730_e_caixa_desligada'];}
   $engine=$wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s',$wpdb->options));
   if(strtoupper((string)$engine)!=='INNODB'){return ['ok'=>false,'codigo'=>'transacao_nao_garantida'];}
   $key=F3Base_Email_Site_Config::STATE;
   $before=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$key));
   if($before===null){return ['ok'=>false,'codigo'=>'estado_ausente'];}
   if(!F3Base_Pipedrive_Fila::travar_linha('email-alerta')){return ['ok'=>false,'codigo'=>'ocupado'];}
   $mail=0;$checks=[];$error=null;
   $oldMail=$wp_filter['pre_wp_mail']??null;remove_all_filters('pre_wp_mail');
   $mailFilter=static function()use(&$mail){$mail++;return true;};add_filter('pre_wp_mail',$mailFilter,PHP_INT_MAX);
   $httpFilter=static fn()=>new WP_Error('qa_no_network');add_filter('pre_http_request',$httpFilter,PHP_INT_MAX);
   $cfg=F3Base_Email_Site::cfg();$cfg['ativo']=true;$cfg['homologacao']=false;
   $cfgFilter=static fn()=>$cfg;add_filter('pre_option_'.F3Base_Email_Site_Config::OPTION,$cfgFilter);
   $set=static function($s)use($wpdb,$key){$n=$wpdb->update($wpdb->options,['option_value'=>maybe_serialize($s)],['option_name'=>$key]);wp_cache_delete($key,'options');if($n===false){throw new RuntimeException('fixture_estado_falhou');}};
   $assert=static function($yes,$name)use(&$checks){$checks[$name]=(bool)$yes;if(!$yes){throw new RuntimeException($name);}};
   $started=false;
   try{
    if($wpdb->query('START TRANSACTION')===false){throw new RuntimeException('transacao_falhou');}$started=true;
    $limits=F3Base_Options::ler('f3base_avisos_tecnicos');$assert($limits['imap_falhas_consecutivas']===24&&$limits['imap_sem_leitura_minutos']===120,'limites_24_120');
    $s=['ativado_em'=>time(),'ultima_tentativa'=>time(),'ultima_leitura_completa'=>time(),'sequencia_leitura_completa'=>1,'codigo'=>'imap_transporte_indisponivel','falhas'=>1];
    $set($s);F3Base_Email_Alerta::observar();$assert($mail===0,'primeira_falha_silenciosa');
    $s['falhas']=23;$set($s);F3Base_Email_Alerta::observar();$assert($mail===0,'abaixo_limite_silencioso');
    $s['falhas']=0;$s['codigo']='';$s['sequencia_leitura_completa']=2;$set($s);F3Base_Email_Alerta::observar();$assert($mail===0,'sem_incidente_sem_recuperacao');
    $s['falhas']=24;$s['codigo']='imap_transporte_indisponivel';$set($s);F3Base_Email_Alerta::observar();$assert($mail===1,'uma_abertura_no_limite');F3Base_Email_Alerta::observar();$assert($mail===1,'abertura_sem_duplicacao');
    $s=get_option($key);$s['falhas']=0;$s['codigo']='';$s['sequencia_leitura_completa']=3;$set($s);F3Base_Email_Alerta::observar();$assert($mail===2,'uma_recuperacao');F3Base_Email_Alerta::observar();$assert($mail===2,'recuperacao_sem_duplicacao');
   }catch(Throwable $e){$error=$e->getMessage();}
   finally{
    if($started){$wpdb->query('ROLLBACK');}
    wp_cache_delete($key,'options');wp_cache_delete('alloptions','options');
    remove_filter('pre_option_'.F3Base_Email_Site_Config::OPTION,$cfgFilter);remove_filter('pre_http_request',$httpFilter,PHP_INT_MAX);
    remove_all_filters('pre_wp_mail');if($oldMail){$wp_filter['pre_wp_mail']=$oldMail;}
    F3Base_Pipedrive_Fila::liberar_linha('email-alerta');
   }
   $after=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$key));$checks['estado_original_preservado']=hash_equals(hash('sha256',$before),hash('sha256',(string)$after));
   return ['ok'=>$error===null&&!in_array(false,$checks,true),'checks'=>$checks,'erro'=>$error,'emails_interceptados'=>$mail,'emails_reais'=>0,'conexao_imap'=>false,'php'=>PHP_VERSION,'wordpress'=>get_bloginfo('version'),'core'=>F3BASE_PLUGIN_VERSAO];
  }
 ]);
});
