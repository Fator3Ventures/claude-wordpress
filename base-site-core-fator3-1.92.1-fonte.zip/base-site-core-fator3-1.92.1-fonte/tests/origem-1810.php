<?php
require __DIR__.'/bootstrap-1810.php';
require __DIR__.'/origem-1810-fixtures.php';
global $wpdb;
$fixtures=f3qa181_projecoes('check');
$url=home_url('/form/?utm_source_platform=meta_ads&utm_medium=cpc&utm_id=333&utm_content=444&f3_ads_v=1&f3_ads_account_id=222&f3_ads_group_id=555');
$web=F3Base_Atribuicao::para_captura(F3Base_Atribuicao::sem_sessao([],$url,true),true,true);
check($web['conta_id']==='222' && $web['anuncio_id']==='444' && $web['grupo_id']==='555','site_url_v1_anuncio_conta_grupo');
$restricted=F3Base_Atribuicao::para_captura(F3Base_Atribuicao::sem_sessao([],$url,false),true,false);
check(!isset($restricted['anuncio_id'],$restricted['conta_id'],$restricted['utm_content']),'site_url_v1_negativa');

require __DIR__.'/origem-1810-transportes.php';
f3qa181_transportes($fixtures,'check');
$http=static fn($body,$code=200)=>['response'=>['code'=>$code,'message'=>'fixture'],'body'=>is_string($body)?$body:wp_json_encode($body),'headers'=>[]];
wp_set_current_user(0);check(F3Base_Google_Acervo::anuncio_origem(['ad_id'=>'456'])['codigo']==='sem_permissao','ability_google_sem_permissao');wp_set_current_user(1);
$home=static fn()=>'https://127.0.0.1:8137/subsite';$content=static fn($url,$path)=>'http://outra.example/custom-conteudo'.($path?'/'.ltrim($path,'/'):'');
add_filter('option_home',$home,999);add_filter('content_url',$content,999,2);$status=404;$urls=[];
$probe=function($pre,$args,$url)use(&$status,&$urls,$http){$urls[]=$url;
    if(str_ends_with($url,'/controle.txt')){preg_match('~(f3base-sonda-index-[a-f0-9]+/controle.txt)$~',$url,$m);return $http(file_get_contents(dirname(F3Base_Llms_Arquivo::caminho()).'/'.$m[1]));}
    if(str_ends_with($url,'/upgrade/')){return $http('',str_starts_with($url,'https://')?$status:301);}
    return $http('',403);
};
add_filter('pre_http_request',$probe,8,3);add_filter('http_allowed_safe_ports',static fn($v)=>array_merge($v,[8137]));
$test=new ReflectionMethod('F3Base_Servidor','verificar_listagem');
foreach([404=>'verified',200=>'pending'] as $code=>$wanted){$status=$code;$r=$test->invoke(null,false);check(!is_ssl() && $r['upgrade_http']===$code && $r['status']===$wanted && end($urls)==='https://127.0.0.1:8137/custom-conteudo/upgrade/','cron_cli_origem_canonica_'.$code,[$r,$urls]);}
evidence('origem-1810',['plataformas'=>array_keys($fixtures),'transporte'=>'WordPress nativo, HTTP interceptado']);
