<?php
/** Chamado com a concessão do SDK real já preparada pela bancada do pacote. */
function f3qa181_worker(string $platform,string $account,string $campaign,string $ad): void {
    if(wp_get_environment_type()!=='local'||!str_starts_with(DB_HOST,'127.0.0.1:')||!str_starts_with(DB_NAME,'core_1810_')){throw new RuntimeException('Laboratório isolado obrigatório');}
    global $wpdb,$wp_filter;
    $id=bin2hex(random_bytes(16));$n=['origem'=>$platform,'conta_id'=>$account,'campanha_id'=>$campaign,'anuncio_id'=>$ad,'nativo_em'=>gmdate('c'),'formulario_id'=>'8331','lead_id'=>'response_1'];
    if($platform==='linkedin'){$n['integracao_id']='example';}
    $row=F3Base_Leads_Repositorio::guardar(['record_id'=>$id,'metodo'=>'anuncio_'.$platform,'origem_nativa'=>$n,'nome'=>'Contato QA','email'=>'qa@example.test','criado_em'=>gmdate('Y-m-d H:i:s',time()-120)],null,null,'',true);
    if(empty($row['ok'])){throw new RuntimeException('Fixture contato: '.wp_json_encode($row));}
    $cfg=F3Base_Options::ler('f3base_pipedrive');$cfg['ativo']=true;$cfg['dominio']='fixture.pipedrive.com';update_option('f3base_pipedrive',$cfg,false);
    foreach(['f3base_slack_bot_token','f3base_pipedrive_token'] as $name){update_option($name,F3Base_Segredos::cifrar($name,'fixture'),false);}
    $proof=F3Base_Pipedrive_Api::iniciar_lote();$acct=['estado'=>'verificado','dominio'=>$cfg['dominio'],'conta_id'=>'101','instalacao'=>'qa'];
    update_option('f3base_pipedrive_estado',$acct+$proof,false);
    $opp=$platform==='linkedin'?['tipo'=>'negocio','id'=>777,'nova'=>false]:['tipo'=>'lead','id'=>wp_generate_uuid4(),'nova'=>true];
    $job=hash('sha256',$id.'crm');$wpdb->insert(F3Base_Pipedrive_Fila::tabela(),['chave'=>$job,'record_id'=>$id,'estado'=>'entregue','conta'=>'fixture.pipedrive.com|101|qa','journal'=>wp_json_encode(['oportunidade'=>$opp]),'capturado_em'=>time(),'atualizado_em'=>time(),'proxima'=>0]);
    $a=F3Base_Contato_Apresentacao::montar(F3Base_Leads_Repositorio::obter($id),false);
    $msg=F3Base_Slack::mensagens($a)[2];$key=hash('sha256',$id.'parte');
    $wpdb->insert(F3Base_Slack::tabela(),['chave'=>$key,'aviso'=>hash('sha256',$id),'record_id'=>$id,'sequencia'=>2,'tipo'=>'origem','principal'=>'','destino'=>F3Base_Slack::destino(),'canal'=>'C12345678','estado'=>'entregue','ts'=>'181.123','payload'=>F3Base_Contato_Comunicacao::cifrar($msg),'proxima'=>0,'criada_em'=>time(),'atualizada_em'=>time()]);
    $http=$wp_filter['pre_http_request'];unset($wp_filter['pre_http_request']);$calls=[];$bytes=base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jJe8AAAAASUVORK5CYII=');
    add_filter('pre_http_request',static function($pre,$args,$url)use($http,$bytes,&$calls){
        $host=wp_parse_url($url,PHP_URL_HOST);$path=wp_parse_url($url,PHP_URL_PATH);
        if($host==='fixture.pipedrive.com'){$calls[]=$args['method'].' '.$path;$body=['success'=>true,'data'=>['id'=>str_contains($path,'files')?102:101]];}
        elseif($host==='slack.com'){$calls[]=$path;$payload=is_string($args['body'])?json_decode($args['body'],true):$args['body'];$body=match($path){
            '/api/files.getUploadURLExternal'=>['ok'=>true,'file_id'=>'F123ABC','upload_url'=>'https://files.slack.com/upload/v1/fixture'],
            '/api/files.completeUploadExternal'=>['ok'=>true,'files'=>[['id'=>'F123ABC']]],
            '/api/chat.update'=>['ok'=>true,'channel'=>$payload['channel'],'ts'=>$payload['ts']],default=>throw new RuntimeException('método inesperado')};}
        elseif($host==='files.slack.com'){$body='OK';}
        elseif(preg_match('/(?:fbcdn\.net|licdn\.com|ytimg\.com|example\.invalid)$/D',$host)){$body=$bytes;}
        else{return $http->apply_filters(false,[$pre,$args,$url]);}
        return ['response'=>['code'=>200,'message'=>'OK'],'headers'=>[],'body'=>is_array($body)?wp_json_encode($body):$body,'cookies'=>[]];
    },1,3);
    try{
        do_action('f3base_anuncio_entrega',$id);do_action('f3base_anuncio_entrega',$id);
        $s=get_option('f3base_anuncio_entrega_'.$id,[]);
        $good=($s['nota_id']??0)===101 && ($s['arquivo_id']??0)===102 && ($s['slack_file']??'')==='F123ABC' && count($calls)===5;
        if(!$good){throw new RuntimeException('worker '.$platform.' '.wp_json_encode([array_keys($s),$s['nota_estado']??'',array_keys($s['fields']??[]),$calls]));}
        file_put_contents(getenv('F3_EVIDENCE_DIR').'/worker-'.$platform.'.json',wp_json_encode(['ok'=>true,'plugin'=>F3BASE_PLUGIN_VERSAO,'plataforma'=>$platform,'execucoes'=>2,'operacoes'=>$calls,'alvo'=>$opp['tipo'],'nota_fixada'=>true,'arquivo'=>true]));
    }finally{$wp_filter['pre_http_request']=$http;F3Base_Anuncio_Entrega::eliminar($id);}
}
