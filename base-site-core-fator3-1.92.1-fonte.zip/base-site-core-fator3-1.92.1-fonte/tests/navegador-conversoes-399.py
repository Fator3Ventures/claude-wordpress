"""Exercita o bundle servido para os quatro destinos com SDKs instrumentados, sem rede externa."""
import os,json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path=os.environ.get('F3BASE_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
    page=b.new_page();page.route('**/*',lambda r:r.fulfill(body='<html><body></body></html>',content_type='text/html'))
    page.goto('https://qa.example.test/')
    page.evaluate("""()=>{
      window.recebidos=[];window.dataLayer=[];
      window.f3baseContexto={pronto:()=>true,pendente:()=>false,estado:()=>'permitida',teste:()=>false,politica:()=>'permitir'};
      window.f3baseConsentimento={permiteCategoria:()=>true,permiteTags:()=>true};
      window.f3baseLeadsDados={medicao:{ga4:'G-TESTE',ads:{id:'AW-1234',label:'qa'},meta:{modo:'ambos',pixelId:'123'},linkedin:{conversionId:'456'}}};
      window.f3baseClarityConversao=(...a)=>recebidos.push(['clarity',...a]);
      window.gtag=(...a)=>recebidos.push(['google',...a]);window.lintrk=(...a)=>recebidos.push(['linkedin',...a]);
      window.fbq=(...a)=>recebidos.push(['meta',...a]);
      window.enviar=(metodo,id)=>document.dispatchEvent(new CustomEvent('f3base-formulario-aceito',{detail:{formulario:'qa',method:metodo,correlacao:id,transporte:{ga4:'navegador',google_ads:'navegador'},conversao:{elegivel:true,event_id:id}}}));
    }""")
    page.add_script_tag(path=str(root/'work/plugin/base-site-core-fator3/assets/perfis/leads-3.min.js'))
    page.evaluate("()=>{enviar('whatsapp_cta','a'.repeat(32));enviar('contato_cta','b'.repeat(32))}")
    assert page.evaluate('recebidos')==[]
    page.evaluate("enviar('whatsapp_formulario','c'.repeat(32))");page.wait_for_timeout(300)
    rows=page.evaluate('recebidos');print([x[:3] for x in rows])
    checks={'GA4':any(x[:3]==['google','event','generate_lead'] for x in rows),'Ads':any(x[:3]==['google','event','conversion'] for x in rows),'Meta':any(x[:3]==['meta','track','Lead'] for x in rows),'LinkedIn':any(x[0]=='linkedin' and x[2]['conversion_id']==456 for x in rows),'Clarity':any(x[0]=='clarity' for x in rows)}
    assert all(checks.values()),checks
    (root/'evidence/1840/controle-destinos.json').write_text(json.dumps({'chromium':b.version,'provider':'SDKs instrumentados','cliques_sem_comandos':2,'formulario_aceito':checks},indent=2)+'\n')
