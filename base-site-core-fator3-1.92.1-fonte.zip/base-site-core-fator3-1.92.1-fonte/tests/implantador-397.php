<?php
/** Args: diretório de uma cópia extraída do instalador oficial do Implantador 2.21.0. */
require __DIR__.'/bootstrap-1830.php';
$plugin=realpath($argv[1]??'');
require $plugin.'/implantador-base.php';
$perfil=F3Base_Imp_Cache::perfil();
$nomes=F3Base_Cache_Pagina::parametros_rastreio();
check($perfil['wpsc_tracking_parameters']===$nomes&&count($nomes)===47,'consome_o_contrato_de_47');
check(!in_array('ref',$nomes,true),'ref_continua_funcional');
$old="<?php\n\$item_do_site = 123;\n\$wpsc_tracking_parameters = array('utm_source');\n";
$uma=F3Base_Imp_Cache::bloco($old,$perfil);
$duas=F3Base_Imp_Cache::bloco($uma,$perfil);
check($uma===$duas,'segunda_gravacao_idempotente');
check(str_contains($uma,'$item_do_site = 123;'),'preserva_outra_variavel');
check(preg_match_all('/^\$wpsc_tracking_parameters\s*=.*;/m',$uma,$m)===1 && str_contains($m[0][0],'gad_campaignid')&&str_contains($m[0][0],'msclkid'),'atribuicao_unica_em_uma_linha');
evidence('implantador-221');
