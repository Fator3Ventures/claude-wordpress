<?php
/** Controller for fresh local installs, direct 1.82.0 upgrade and reactivation. */
$mode=$argv[1]??'';
if($mode==='install'){
    if(getenv('F3BASE_ALLOW_LOCAL_TESTS')!=='1'){throw new RuntimeException('Local opt-in required');}
    $db=getenv('F3BASE_LAB_DB');$host=getenv('F3BASE_DB_HOST');
    if(!preg_match('/^core_[a-z0-9_]+$/D',(string)$db)||!preg_match('/^127\.0\.0\.1:(\d+)$/D',(string)$host,$m)){throw new RuntimeException('Unsafe laboratory database');}
    $conn=new mysqli('127.0.0.1',getenv('F3BASE_DB_USER')?:'root',getenv('F3BASE_DB_PASSWORD')?:'',null,(int)$m[1]);
    $conn->query('CREATE DATABASE '.$db);define('WP_INSTALLING',true);
}
require __DIR__.'/bootstrap-1830.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
global $wpdb;
function snapshot1721(): array{
    global $wpdb;$table=F3Base_Vitais::tabela();
    return ['linhas'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $table"),
        'dados_sha256'=>hash('sha256',wp_json_encode($wpdb->get_results("SELECT * FROM $table ORDER BY amostra",ARRAY_A))),
        'config_sha256'=>hash('sha256',maybe_serialize(get_option('f3base_contato')))];
}
function finish1721(): array{
    for($i=0;$i<30;$i++){
        $r=F3Base_Instalacao::atualizar();
        if(!empty($r['ok'])&&F3Base_Instalacao::origem()==='atual'){return $r;}
        if(empty($r['ok'])&&!in_array($r['codigo']??'',['execucao_em_andamento','aguardando_finalizacao','etapa_concluida'],true)){throw new RuntimeException(wp_json_encode($r));}
    }
    throw new RuntimeException('Installation did not converge: '.wp_json_encode($r));
}
if($mode==='install'){
    require_once ABSPATH.'wp-admin/includes/upgrade.php';
    if(is_blog_installed()){throw new RuntimeException('Fresh install requires empty lab database');}
    wp_install('Core isolated QA','qa_admin','qa@example.test',false,'',getenv('F3BASE_QA_PASSWORD') ?: bin2hex(random_bytes(24)));wp_set_current_user(1);
    switch_theme('core-qa');$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');
    check(!is_wp_error($r),'ativacao_limpa');$result=finish1721();
    check(F3Base_Vitais::pronta()&&F3Base_Instalacao::origem()==='atual','ciclo_limpo_concluido');
    evidence('instalacao-limpa-'.str_replace('.','',F3BASE_PLUGIN_VERSAO),['ciclo'=>$result]);exit;
}
if($mode==='seed'){
    $id=str_repeat('c',32); $n=['origem'=>'google','conta_id'=>'1234567890','campanha_id'=>'999','anuncio_id'=>'222'];
    $row=F3Base_Leads_Repositorio::guardar(['record_id'=>$id,'metodo'=>'anuncio_google','origem_nativa'=>$n,'nome'=>'QA','email'=>'qa@example.test'],null,null,'',true);
    check(!empty($row['ok']),'392_contato_base');
    $base=F3Base_Anuncio_Origem::base(F3Base_Contato_Apresentacao::montar(F3Base_Leads_Repositorio::obter($id),false));
    $binding=hash('sha256',wp_json_encode([$base['platform'],$base['account'],$base['campaign'],$base['ad']]));
    update_option('f3base_anuncio_entrega_'.$id,['vinculo'=>$binding,'fields'=>$base['fields'],'slack_file'=>'FPRIVATE','slack_estado'=>'Arquivo confirmado','nota_id'=>321,'arquivo_id'=>654,'inicio'=>time()-31*DAY_IN_SECONDS,'tentativas'=>7],false);
    update_option('f3base_anuncio_entrega_'.str_repeat('d',32),['nota_id'=>9],false);
    $table=F3Base_Vitais::tabela();check((int)$wpdb->get_var("SELECT COUNT(*) FROM $table")===0,'base_limpa_para_semente');
    $rows=[];for($i=0;$i<993;$i++){$rows[]=$wpdb->prepare('(%s,%s,%s,%s,%s,%d,%f,%s,%s)',hash('sha256','migration-'.$i),wp_date('Y-m-d'),'/preservado/',
        ['LCP','INP','CLS','TTFB'][$i%4],'movel',1+$i%3,$i/10,'nao_identificada',$i%3?'1.72.0':'');}
    check($wpdb->query("INSERT INTO $table (amostra,dia,caminho,metrica,dispositivo,sequencia,valor,automacao,versao_origem) VALUES ".implode(',',$rows))===993,'grava_993_amostras_sinteticas');
    $cfg=get_option('f3base_contato');$cfg['texto_aviso_titulo']='Título preservado na reconstrução';update_option('f3base_contato',$cfg);
    update_option('qa1721_before',snapshot1721(),false);evidence('upgrade-1721-semente',snapshot1721());exit;
}
if($mode==='migrate'){
    $result=finish1721();check(F3BASE_PLUGIN_VERSAO==='1.83.0','executa_alvo_1830');
    $id=str_repeat('c',32);F3Base_Anuncio_Entrega::migrar();F3Base_Anuncio_Entrega::migrar();
    $s=json_decode(F3Base_Leads_Repositorio::obter($id)['anuncio_entrega'],true);
    check($s['nota_id']===321 && $s['arquivo_id']===654 && empty($s['slack_file']) && $s['tentativas']===7,'392_importa_recibos_e_reabre_slack_privado');
    check(get_option('f3base_anuncio_entrega_'.$id,null)===null && get_option('f3base_anuncio_entrega_'.str_repeat('d',32),null)===null,'392_remove_options_incluindo_orfa');
    $detail=F3Base_Leads_Admin::ler(['record_id'=>$id])['registro']['anuncio_entrega']??[];
    check($detail['fields']===$s['fields'] && !isset($detail['vinculo']),'392_detalhe_escopado');
    check(!isset(F3Base_Leads_Repositorio::consultar()['registros'][0]['anuncio_entrega']),'392_recibo_fora_da_lista');
    F3Base_Anuncio_Entrega::executar($id);
    $s=json_decode(F3Base_Leads_Repositorio::obter($id)['anuncio_entrega'],true);
    check($s['trabalho']==='expirado' && !isset($s['tentativas'],$s['inicio']) && wp_next_scheduled('f3base_anuncio_entrega',[$id])===false,'392_expira_sem_nova_escrita');
    check((F3Base_Options::catalogo_ausentes()['quantidade']??-1)===0,'392_catalogo_limpo');
    check(snapshot1721()===get_option('qa1721_before'),'preserva_993_amostras_e_configuracao_no_upgrade');
    check(F3Base_Instalacao::origem()==='atual','upgrade_concluido');evidence('upgrade-'.str_replace('.','',getenv('F3BASE_BASE')?:'1.82.0').'-1830',['ciclo'=>$result]+snapshot1721());exit;
}
if($mode==='uninstall'){
    $tables=$wpdb->get_col("SHOW TABLES LIKE '".$wpdb->esc_like($wpdb->prefix.'f3base_')."%'");
    update_option('qa1721_reactivation_before',snapshot1721(),false);
    deactivate_plugins('base-site-core-fator3/base-site-core-fator3.php');
    uninstall_plugin('base-site-core-fator3/base-site-core-fator3.php');
    $after=$wpdb->get_col("SHOW TABLES LIKE '".$wpdb->esc_like($wpdb->prefix.'f3base_')."%'");
    update_option('qa1721_removed_tables',array_values(array_diff($tables,$after)),false);
    echo wp_json_encode(['removed'=>count(array_diff($tables,$after))]);exit;
}
if($mode==='reactivate'){
    $removed=get_option('qa1721_removed_tables',[]);$premature=[];
    $watch=static function($sql)use(&$premature,$removed){if(preg_match('/^(SELECT|INSERT|UPDATE|DELETE|REPLACE)\b/i',$sql)){foreach($removed as $t){if(str_contains($sql,$t)){$premature[]=$sql;break;}}}return $sql;};
    add_filter('query',$watch);$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');
    check(!is_wp_error($r),'reativacao_aceita');F3Base_Zelador::executar(true);remove_filter('query',$watch);
    check(count($premature)===0,'ativacao_e_cron_antecipado_sem_acesso_a_tabelas_removidas');
    $result=finish1721();$after=$wpdb->get_col("SHOW TABLES LIKE '".$wpdb->esc_like($wpdb->prefix.'f3base_')."%'");
    check(!array_diff($removed,$after),'tabelas_operacionais_recriadas');
    check(snapshot1721()['config_sha256']===get_option('qa1721_reactivation_before')['config_sha256'],'configuracao_preservada_na_reativacao');
    check(snapshot1721()['linhas']===0,'vitais_recriados_vazios_conforme_politica_de_desinstalacao');
    evidence('reativacao-1830',['tabelas_restauradas'=>count($removed),'leituras_prematuras'=>count($premature),'ciclo'=>$result]);exit;
}
throw new RuntimeException('Unknown test mode');
