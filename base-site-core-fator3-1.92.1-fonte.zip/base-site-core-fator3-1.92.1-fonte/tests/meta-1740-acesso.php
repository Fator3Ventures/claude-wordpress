<?php
/** Authorization and read-only documentation on the disposable WordPress installation. */
require __DIR__.'/bootstrap.php';
$http = 0;
add_filter('pre_http_request', static function ($previous) use (&$http) {
    $http++;
    return $previous;
}, 1);

$doc = wp_get_ability('f3base/documentacao-ler');
$config = wp_get_ability('f3base/config-core-ler');
check($doc && $config, 'abilities_registradas');
$file = 'docs/RELEASE-1.74.0.md';
$page = $doc->execute(['arquivo'=>$file, 'limite'=>5]);
check(is_array($page) && $page['sha256'] === hash_file('sha256', F3BASE_PLUGIN_DIR.$file) && $page['proxima_linha'] === 6, 'documentacao_administrativa_local_paginada');

$user = wp_insert_user(['user_login'=>'qa_leitor', 'user_pass'=>getenv('F3BASE_QA_PASSWORD'), 'role'=>'subscriber']);
check(!is_wp_error($user), 'leitor_de_bancada_criado');
wp_set_current_user($user);
check(current_user_can('read') && !current_user_can('manage_options'), 'leitor_sem_gestao');
check(is_wp_error($config->execute(['nome'=>'f3base_meta_transporte'])), 'ability_recusa_consulta_configuracao_do_leitor');
check(is_wp_error($doc->execute(['arquivo'=>$file])), 'ability_documental_recusa_leitor');
check($http === 0, 'leitura_documentacao_e_recusas_sem_http');
evidence('acesso-meta-1740');
