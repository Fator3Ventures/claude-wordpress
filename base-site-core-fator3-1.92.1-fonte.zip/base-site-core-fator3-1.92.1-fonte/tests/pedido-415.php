<?php
/** Antes e depois da troca do ZIP, no banco descartável e exclusivo desta prova. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || DB_NAME !== 'core1891_415') {
    throw new RuntimeException('Este ensaio exige o banco local core1891_415.');
}
global $wpdb;
$esperados = [
    'infinix x6525b' => ['Infinix', 'Infinix SMART 8 Pro', '2024', '800.00', 'entrada', 'não'],
    'm7_wifi' => ['Multilaser', 'M7 Wi-Fi', '2021', '292.89', 'entrada', 'não'],
];
$base = F3BASE_PLUGIN_VERSAO === '1.89.0';
if (!$base && F3BASE_PLUGIN_VERSAO !== '1.89.1') {
    throw new RuntimeException('Versão de ensaio inesperada.');
}
$marcas = [];
foreach ($esperados as $codigo => $campos) {
    $chave = md5('pedido415:' . $codigo);
    if ($base) {
        $perfil = F3Base_Perfil_Aparelho::normalizar(['modelo' => $codigo], 'Android', []);
        if (!F3Base_Perfil_Aparelho::gravar('teste', $chave, $chave, time(), $perfil)) {
            throw new RuntimeException('Falha ao semear perfil.');
        }
    } else {
        $atual = F3Base_Catalogo_Aparelhos::resolver($codigo, []);
        foreach (array_combine(F3Base_Catalogo_Aparelhos::CAMPOS, $campos) as $campo => $valor) {
            if (($atual[$campo] ?? null) !== $valor) { throw new RuntimeException($codigo . ' / ' . $campo); }
        }
    }
    $registro = $wpdb->get_var($wpdb->prepare('SELECT perfil FROM %i WHERE sessao = %s', F3Base_Perfil_Aparelho::tabela(), $chave));
    if (!is_string($registro) || $registro === '') { throw new RuntimeException('Perfil ausente.'); }
    $marcas[$codigo] = hash('sha256', $registro);
}
$cursor = '';
$itens = [];
$examinados = 0;
$paginas = 0;
do {
    $r = wp_get_ability('f3base/aparelhos-sem-nome-ler')->execute(['limite' => 1, 'apos' => $cursor]);
    if (is_wp_error($r) || empty($r['ok']) || ++$paginas > 3) { throw new RuntimeException('Falha na consulta paginada.'); }
    $examinados += $r['codigos_examinados'];
    array_push($itens, ...array_column($r['itens'], 'codigo'));
    $cursor = $r['proximo_apos'];
} while ($cursor !== null);
if ($examinados !== 2 || $itens !== ($base ? array_keys($esperados) : [])) {
    throw new RuntimeException('Resultado agregado divergente.');
}
echo wp_json_encode(['wordpress'=>get_bloginfo('version'), 'php'=>PHP_VERSION, 'versao'=>F3BASE_PLUGIN_VERSAO,
    'catalogo'=>F3Base_Catalogo_Aparelhos::metadados(), 'paginas'=>$paginas, 'codigos_examinados'=>$examinados,
    'itens'=>$itens, 'proximo_apos'=>$cursor, 'sha256_perfis'=>$marcas], JSON_PRETTY_PRINT);
