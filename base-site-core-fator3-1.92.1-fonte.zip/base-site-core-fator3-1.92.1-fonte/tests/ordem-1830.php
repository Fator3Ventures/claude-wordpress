<?php
require __DIR__.'/bootstrap-1830.php';
global $wpdb;
$id=bin2hex(random_bytes(16));
$old=time()-7200;
$cfg=F3Base_Options::ler('f3base_pipedrive');
$cfg['ativo']=true;$cfg['dominio']='fixture.pipedrive.com';
update_option('f3base_pipedrive',$cfg,false);
foreach(['f3base_pipedrive_token','f3base_slack_bot_token'] as $name){
    update_option($name,F3Base_Segredos::cifrar($name,'fixture'),false);
}
$proof=F3Base_Pipedrive_Api::iniciar_lote();
update_option('f3base_pipedrive_estado',['estado'=>'verificado','dominio'=>$cfg['dominio'],'conta_id'=>'101','instalacao'=>'qa']+$proof,false);
$row=F3Base_Leads_Repositorio::guardar(['record_id'=>$id,'metodo'=>'anuncio_linkedin','origem_nativa'=>['origem'=>'linkedin','lead_id'=>'x'],'nome'=>'Contato QA','email'=>'qa@example.test','criado_em'=>gmdate('Y-m-d H:i:s',$old)],null,null,'',true);
check(!empty($row['ok']),'contato_para_ordem');
$wpdb->update(F3Base_Leads_Repositorio::tabela(),['entrega'=>wp_json_encode(['pipedrive'=>['solicitado'=>true,'dominio'=>$cfg['dominio']]])],['record_id'=>$id]);
$notice=hash('sha256',$id.'aviso');$parent=hash('sha256',$notice.'principal');$key=hash('sha256',$notice.'links');
$dest=F3Base_Slack::destino();
$meta=['schema'=>'f3base.slack.app.v1','formato'=>'thread','canal'=>'C12345678'];
$wpdb->insert(F3Base_Avisos::tabela(),['chave'=>$notice,'record_id'=>$id,'destino'=>$dest,'payload'=>F3Base_Avisos::cifrar($meta),'proxima'=>0,'criada_em'=>$old,'atualizada_em'=>$old]);
$part=['record_id'=>$id,'aviso'=>$notice,'destino'=>$dest,'canal'=>'C12345678','proxima'=>0,'criada_em'=>$old,'atualizada_em'=>$old,'payload'=>F3Base_Contato_Comunicacao::cifrar(F3Base_Slack_Thread::mensagem('Links',['WordPress'=>'https://example.test/ficha']))];
$wpdb->insert(F3Base_Slack::tabela(),['chave'=>$parent,'tipo'=>'principal','sequencia'=>0,'principal'=>'','estado'=>'entregue','ts'=>'11.10']+$part);
$wpdb->insert(F3Base_Slack::tabela(),['chave'=>$key,'tipo'=>'links','sequencia'=>4,'principal'=>$parent,'estado'=>'pendente']+$part);
$job=hash('sha256',$id.'crm');
$wpdb->insert(F3Base_Pipedrive_Fila::tabela(),['chave'=>$job,'record_id'=>$id,'estado'=>'pendente','conta'=>'fixture.pipedrive.com|101|qa','journal'=>'{}','capturado_em'=>$old,'atualizado_em'=>$old,'proxima'=>time()+180]);
$link=static fn()=>F3Base_Slack_Thread::parte($notice,'links');
$send=new ReflectionMethod(F3Base_Slack::class,'enviar_parte');
$calls=[];
add_filter('pre_http_request',static function($pre,$args,$url)use(&$calls){
    if(wp_parse_url($url,PHP_URL_HOST)!=='slack.com'){return $pre;}
    $body=json_decode($args['body'],true);$calls[]=[$url,$body];
    return ['response'=>['code'=>200,'message'=>'OK'],'headers'=>[],'body'=>wp_json_encode(['ok'=>true,'channel'=>$body['channel'],'ts'=>$body['ts']??'101.100']),'cookies'=>[]];
},1,3);
$r=$send->invoke(null,$link());
check(($r['codigo']??'')==='aguarda_oportunidade' && !$calls && $link()['estado']==='pendente','duas_horas_aguarda_crm_sem_postar_links',$r);
$wpdb->update(F3Base_Pipedrive_Fila::tabela(),['estado'=>'cancelado'],['chave'=>$job]);
$r=$send->invoke(null,$link());
check(($r['codigo']??'')!=='aguarda_oportunidade','falha_terminal_libera_links',$r);
$calls=[];$wpdb->update(F3Base_Slack::tabela(),['estado'=>'pendente','ts'=>'','proxima'=>0],['chave'=>$key]);
$opp=['tipo'=>'negocio','id'=>777,'nova'=>false];
$wpdb->update(F3Base_Pipedrive_Fila::tabela(),['estado'=>'entregue','journal'=>wp_json_encode(['oportunidade'=>$opp])],['chave'=>$job]);
$r=$send->invoke(null,$link());
$vis=F3Base_Slack_Thread::parte($notice,'visitas');
check(($r['codigo']??'')==='visitas_antes_dos_links' && $vis && (int)$vis['sequencia']<(int)$link()['sequencia'] && !$calls,'confirmacao_tardia_agenda_visitas_primeiro',$r);
$wpdb->update(F3Base_Slack::tabela(),['proxima'=>time()+120],['chave'=>$vis['chave']]);
$wpdb->update(F3Base_Slack::tabela(),['proxima'=>0],['chave'=>$key]);
$r=F3Base_Slack::processar([F3Base_Avisos::linha($notice)]);
check(!$calls && $link()['estado']==='pendente','retentativa_de_visitas_bloqueia_salto_de_links',$r);
// Reproduz um thread preexistente que já publicou Links sem métricas de Visitas.
$wpdb->delete(F3Base_Slack::tabela(),['chave'=>$vis['chave']]);
$wpdb->update(F3Base_Slack::tabela(),['estado'=>'entregue','ts'=>'42.01'],['chave'=>$key]);
$lead=F3Base_Leads_Repositorio::obter($id);
foreach([1,2] as $i){
    $r=F3Base_Slack_Thread::retorno(F3Base_Avisos::linha($notice),$lead,$job);
    check(($r['estado']??'')==='entregue','thread_publicado_retomada_'.$i,$r);
}
$headers=array_column(array_column(array_filter($calls[0][1]['blocks']??[],static fn($b)=>$b['type']==='header'),'text'),'text');
check(count($calls)===1 && str_ends_with($calls[0][0],'chat.update') && $calls[0][1]['ts']==='42.01' && $headers===['Visitas','Links'],'mesmo_ts_visitas_antes_de_links_sem_duplicar');
evidence('ordem-1830',['atraso_simulado_segundos'=>7200,'transportes'=>'interceptados']);
