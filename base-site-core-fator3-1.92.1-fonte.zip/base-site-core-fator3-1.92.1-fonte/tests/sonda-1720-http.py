"""Real PHP HTTP SAPI and WordPress hook dispatcher; route context is controlled."""
from pathlib import Path
import argparse,json,os,socket,subprocess,time,urllib.request
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--php',default=os.environ.get('F3BASE_PHP','php'));p.add_argument('--wordpress',type=Path,required=True)
args=p.parse_args();env=os.environ.copy();env['F3_SONDA_WP']=str(args.wordpress.resolve())
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
server=subprocess.Popen([args.php,'-S','127.0.0.1:'+str(port),str(ROOT/'tests/sonda-1720-router.php')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
scenes=[
 ('pagina','GET','/',{},False),('head','HEAD','/',{},False),
 ('comportamento','POST','/wp-json/f3base/v1/comportamento',{},False),
 ('analise','POST','/wp-json/f3base/v1/analise',{},False),
 ('barra_final','POST','/wp-json/f3base/v1/analise/',{},False),
 ('subdiretorio','POST','/sub/wp-json/f3base/v1/analise',{},False),
 ('query','POST','/?rest_route=/f3base/v1/comportamento',{},False),
 ('prefixo','POST','/rest-local/f3base/v1/analise',{'X-Prefixo-Teste':'rest-local'},False),
 ('outra_rota','POST','/wp-json/f3base/v1/outro',{},True),
 ('rota_query_prevalece','POST','/wp-json/f3base/v1/analise?rest_route=/outra',{},True),
 ('rota_array','POST','/?rest_route[]=analise',{},True),
 ('get_rest','GET','/wp-json/f3base/v1/analise',{},True),
 ('post_com_cookie','POST','/wp-json/f3base/v1/analise',{'Cookie':'sessao_teste=fixture'},True),
 ('post_autenticado','POST','/wp-json/f3base/v1/analise',{'Authorization':'Basic Zml4dHVyZTpmaXh0dXJl'},True),
 ('optin','POST','/wp-json/f3base/v1/analise',{'X-Optin-Teste':'1'},True),
 ('admin','GET','/wp-admin/',{},True),('cron','GET','/wp-cron.php',{},True),
]
checks={};observed={}
try:
 for _ in range(100):
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.2):break
  except OSError:time.sleep(.05)
 else:raise RuntimeError('HTTP server did not start')
 for name,method,path,headers,active in scenes:
  req=urllib.request.Request('http://127.0.0.1:'+str(port)+path,data=b'{}' if method=='POST' else None,method=method,headers=headers)
  with opener.open(req,timeout=10) as response:
   import base64
   row=json.loads(base64.b64decode(response.headers['X-Dados-Sonda']))
  observed[name]=row
  for key,wanted in [('ativo',active),('sql',active),('wrapper',active),('valor','valor-ok')]:
   check=name+'_'+key;checks[check]=row[key]==wanted
   if not checks[check]:raise AssertionError(check+': '+str(row))
 out={'proveniencia':'reconstruído a partir da fixture HTTP 1.71.0','ambiente':'PHP HTTP nativo; dispatcher WordPress real; sem banco, rotas controladas',
      'checks':checks,'observado':observed}
 (ROOT/'evidence/1721-reconstrucao/sonda-1720-http.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(str(len(checks))+' HTTP checks OK')
finally:
 server.terminate()
 try:server.wait(timeout=10)
 except subprocess.TimeoutExpired:server.kill();server.wait()
