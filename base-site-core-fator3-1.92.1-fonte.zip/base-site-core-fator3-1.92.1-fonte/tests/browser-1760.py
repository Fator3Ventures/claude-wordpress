"""Exercise the shipped transport and footer code in Chromium against an in-process, synthetic HTTP peer."""
from pathlib import Path
import json, os, shutil
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'work/plugin/base-site-core-fator3/assets'
checks={}
def check(label,condition):
    checks[label]=bool(condition)
    if not condition: raise AssertionError(label)
with sync_playwright() as playwright:
    browser=playwright.chromium.launch(executable_path=os.getenv('CHROMIUM') or shutil.which('chromium'),args=['--no-sandbox'])
    for label,marked,policy,mode in [('teste',True,'marcar','ambos'),('sem-codigo',True,'suprimir','ambos'),('so-pixel',True,'marcar','navegador'),('normal',False,'marcar','ambos')]:
        ctx=browser.new_context();page=ctx.new_page();events=[];revocations=[];foreign=[]
        def route(r):
            if r.request.url=='https://fixture.test/':return r.fulfill(content_type='text/html',body='<html lang="pt"><body></body></html>')
            if r.request.url.endswith('/events'):
                events.append(r.request.post_data_json);return r.fulfill(json={'ok':True})
            if r.request.url.endswith('/decision'):
                revocations.append(r.request.post_data_json);return r.fulfill(json={'persisted':True})
            foreign.append(r.request.url);r.abort()
        page.route('**/*',route);page.goto('https://fixture.test/')
        page.evaluate("""([marked,policy,mode])=>{
          window.fixtureMarked=marked;window.f3baseContexto={pronto:()=>true,teste:()=>window.fixtureMarked,token:()=>Promise.resolve('fixture')};
          window.f3baseConsentimentoDados={cookie:'f3base_consentimento',modo:'legado',publicidadePreAutorizada:true,padrao:'pre-aprovado',endpoint:'/decision'};
          window.f3baseMetaTransporteDados={pixel:'12345',modo:mode,testeCapi:policy,consentimentoLegado:'sim',eventos:['PageView','Lead'],endpoint:'/events'};
        }""",[marked,policy,mode])
        page.add_script_tag(path=str(ASSETS/'f3base-consentimento.min.js'))
        page.add_script_tag(path=str(ASSETS/'f3base-meta-transporte.min.js'))
        page.evaluate("""()=>document.dispatchEvent(new CustomEvent('f3base-lead-confirmado',{detail:{teste:fixtureMarked,id:'e'.repeat(32),meta_evento:'Lead',metodo:'formulario'}}))""")
        page.wait_for_timeout(180)
        if label in ['normal','teste']:
            check(label+'-capturas',sorted(e['nome'] for e in events)==['Lead','PageView'])
            check(label+'-classe',all(e['contexto_teste']==marked for e in events))
            check(label+'-pixel-sem-disparo',all(e['navegador_observado'] is False for e in events) and not foreign)
            check(label+'-identificadores',all(('fbp' in e) != marked for e in events))
            cookie=next(c['value'] for c in ctx.cookies() if c['name']=='f3base_capi_ref')
            page.evaluate("""()=>window.f3baseConsentimento.definir('denied')""");page.wait_for_timeout(120)
            check(label+'-revogacao',len(revocations)==1 and revocations[0]['comprovante_anterior']==cookie)
            check(label+'-revogacao-confirmada',not any(c['name'] in ['f3base_capi_ref','f3base_capi_revogar'] for c in ctx.cookies()))
            page.evaluate("""()=>document.dispatchEvent(new CustomEvent('f3base-lead-confirmado',{detail:{teste:fixtureMarked,id:'c'.repeat(32),meta_evento:'Lead'}}))""");page.wait_for_timeout(80)
            check(label+'-nega-novo-evento',len(events)==2)
        else:check(label+'-suprimido',not events and not foreign)
        ctx.close()
    result={'chromium':browser.version,'checks':checks,'count':len(checks),'provider':'HTTP fixture'}
    (ROOT/'evidence/1760/browser.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result));browser.close()
