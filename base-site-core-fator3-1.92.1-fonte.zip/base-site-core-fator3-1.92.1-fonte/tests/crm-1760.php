<?php
/** Request-only fixture. No persistent writes, no remote calls. */
function f3qa1760_crm(): array {
    $mapping=['linkedin'=>'7654321','google_ads'=>'customers/1234567890/conversionActions/300'];
    $cfg=[];
    foreach($mapping as $target=>$action){$cfg[$target]=['ativo'=>true,'acoes'=>['qualificado'=>$action]];}
    $policy='pre_autorizada';
    add_filter('pre_option_f3base_consentimento',static function() use (&$policy) {return ['publicidade_politica'=>$policy,'modo'=>'legado','padrao'=>'pre-aprovado'];});
    add_filter('pre_option_'.F3Base_Qualidade::OPCAO,static fn()=>array_replace(F3Base_Qualidade::padrao(),['ativo'=>true,'etapas'=>[['id'=>'qualificado','nome'=>'Qualificado','evento_meta'=>'']]]));
    add_filter('pre_option_'.F3Base_Qualidade_Destinos::OPTION,static fn()=>$cfg);
    add_filter('f3base_conversoes_adaptador',static function($adapter,$target,$contract) use($mapping){
        if(!isset($mapping[$target])){return $adapter;}
        return new class($mapping[$target],$contract) {
            public function __construct(private string $action,private string $contract){}
            public function capabilities(): array{return ['ready'=>true,'contract'=>$this->contract,'supported_contracts'=>[F3Base_Qualidade_Destinos::CONTRACT],'purposes'=>['crm_stage'],'acquisition_action'=>null,'actions'=>[$this->action=>['action'=>$this->action,'purpose'=>'crm_stage','ready'=>true,'destination_ref'=>'qa-local']]];}
            public function send(){throw new LogicException('Unexpected provider call');}
            public function sendBound(){throw new LogicException('Unexpected provider call');}
        };
    },PHP_INT_MAX,3);
    $now=time();$results=[];
    foreach(['meta','linkedin','google'] as $origin){
        $lead=['record_id'=>str_repeat('a',32),'captura'=>'aceito','classe_trafego'=>'teste','metodo'=>'anuncio_'.$origin,
            'email'=>'teste@example.test','criado_em'=>gmdate('Y-m-d H:i:s',$now-60),'dados'=>['origem_nativa'=>['origem'=>$origin],'contexto_teste'=>true,'atribuicao'=>['gclid'=>'qa-fixture','ultimo_toque_em'=>$now-70]]];
        foreach($mapping as $target=>$action){
            $case=$origin.'-'.$target;
            $prepare=static fn($l,$preview)=>F3Base_Qualidade_Destinos::preparar($l,'qualificado',$target,$now,$preview)['codigo'];
            $policy='pre_autorizada';$lead['dados']['publicidade']=F3Base_Publicidade::nativa([],[]);
            $results[$case.'-previa']=$prepare($lead,true)==='elegivel';
            $results[$case.'-worker-teste']=$prepare($lead,false)==='trafego_suprimido';
            $normal=$lead;$normal['classe_trafego']='nao_marcado';$normal['dados']['contexto_teste']=false;
            $results[$case.'-worker-normal']=$prepare($normal,false)==='elegivel';
            $lead['dados']['publicidade']=F3Base_Publicidade::nativa(['ads'=>'nao'],['campo'=>'ads','negativas'=>['nao']]);
            $results[$case.'-negativa']=$prepare($lead,true)==='consentimento_nao_permite';
            $policy='exigir_decisao';$results[$case.'-sem-decisao']=$prepare($normal,false)==='decisao_ausente';
            $policy='pre_autorizada';$normal['metodo']='formulario';
            $results[$case.'-site-sem-retrato']=$prepare($normal,false)==='decisao_ausente';
            $normal['dados']['consentimento_snapshot']=['publicidade'=>true];
            $results[$case.'-site-com-retrato']=$prepare($normal,false)==='elegivel';
        }
    }
    return $results;
}
