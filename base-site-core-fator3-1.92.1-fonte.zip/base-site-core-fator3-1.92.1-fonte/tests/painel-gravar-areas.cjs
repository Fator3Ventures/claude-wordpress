// Para cada área com formulário: abre, envia o formulário SEM alterar nada e registra o que a tela devolve.
// Uso: node gravar-areas.cjs <base-url> <arquivo-senha> <saida.json>
const { chromium } = require('playwright'); const fs = require('fs');
const [base, arquivoSenha, saida] = process.argv.slice(2);
const AREAS = ['contato', 'medicao-tags', 'medicao-meta', 'medicao-coleta', 'medicao-gsc', 'medicao-ga4', 'medicao-clarity', 'medicao-testes', 'consentimento', 'privacidade', 'conteudo', 'seo'];
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, locale: 'pt-BR' }); const p = await ctx.newPage();
  await p.goto(base + '/wp-login.php'); await p.fill('#user_login', 'qa_admin'); await p.fill('#user_pass', fs.readFileSync(arquivoSenha, 'utf8'));
  await Promise.all([p.waitForNavigation(), p.click('#wp-submit')]);
  const r = [];
  for (const s of AREAS) {
    await p.goto(base + '/wp-admin/admin.php?page=base-site-core-fator3&secao=' + s, { waitUntil: 'load' });
    p.once('dialog', (d) => d.accept());
    const sel = (await p.locator('form.f3base-form .f3base-savebar [type=submit]').count()) ? 'form.f3base-form .f3base-savebar [type=submit]' : 'form.f3base-form [type=submit]';
    await Promise.all([p.waitForNavigation({ waitUntil: 'load' }), p.locator(sel).first().click()]);
    const avisos = await p.evaluate(() => [...document.querySelectorAll('#wpbody-content .notice, #wpbody-content .f3base-leitura, #wpbody-content .f3base-config-status')].map((n) => ({ classe: n.className.replace(/\s+/g, ' ').slice(0, 60), texto: n.textContent.replace(/\s+/g, ' ').trim().slice(0, 260) })).filter((a) => !/passagem CLI|cron da hospedagem/.test(a.texto)));
    const recusa = avisos.filter((a) => /recus|incomplet|fora do escopo|inválid|não foi|nao foi|erro|verdadeiro ou falso|falh/i.test(a.texto));
    r.push({ area: s, url: p.url().replace(base, '').slice(0, 90), avisos: avisos.length, recusas: recusa.length, amostra: (recusa.length ? recusa : avisos).slice(0, 3) });
    console.log(s.padEnd(18), 'avisos=' + avisos.length, 'recusas=' + recusa.length, '|', ((recusa[0] || avisos[0] || {}).texto || '').slice(0, 170));
  }
  fs.writeFileSync(saida, JSON.stringify(r, null, 1)); await b.close();
})();
