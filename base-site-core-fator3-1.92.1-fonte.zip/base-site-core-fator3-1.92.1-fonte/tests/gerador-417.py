"""Protege a decisão para nomes e códigos fora do conjunto de correções da rodada."""
from pathlib import Path
import runpy

root = Path(__file__).resolve().parents[1]
module = runpy.run_path(str(root / 'build/selecionar-aparelhos.py'))
fields, choose = module['FIELDS'], module['choose']
code = 'modelo exemplo'
device = ('marca', 'original')
other = ('marca', 'outro')
own = dict(zip(fields, [code, 'Marca', code, '2024', '750.00', 'entrada', 'não']))
old = {**own, 'nome_comercial': 'modelo premium', 'preco_atual_estimado_brl': '3200.00',
       'faixa_sugerida': 'topo', 'linha_premium': 'sim'}
fact = {**own, 'device': 'original'}
names = {code: {device}, 'modelo premium': {other}, 'variante regional': {device}}
for ordered in (names, dict(reversed(names.items()))):
    rows, records = choose({code: old}, {code: fact}, {code: ordered}, {})
    assert rows == [own] and records == []
    alias = {**own, 'nome_comercial': 'variante regional'}
    assert choose({code: alias}, {}, {code: ordered}, {}) == ([alias], [])
    try:
        choose({code: old}, {}, {code: ordered}, {})
    except ValueError as error:
        assert 'Falta ficha' in str(error)
    else:
        raise AssertionError('Ficha de outro Device aceita.')
no_self = {'alternativo 1': {device}, 'modelo premium': {other}}
rows, records = choose({code: old}, {}, {code: no_self}, {})
assert rows == [old] and records[0]['nome_mantido'] == old['nome_comercial']
only = {'variante regional': {device}}
single = {**fact, 'nome_comercial': 'variante regional'}
assert choose({}, {code: single}, {code: only}, {})[0][0]['nome_comercial'] == 'variante regional'
print('OK: linha própria, ordem invertida, alias regional, ausência de ficha, ambiguidade e nome único.')
