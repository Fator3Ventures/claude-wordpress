#!/usr/bin/env bash
# Copia o runtime de desenvolvimento para o plugin de um laboratório de interface já criado.
# Uso: lab-sync.sh <nome-do-lab>   (lab criado por lab-ui.sh; ex.: dev)
set -euo pipefail
NOME="$1"
# Padrões: a árvore de fonte que contém este script e o diretório de laboratórios da rodada.
FONTE="${F3BASE_FONTE:-$(cd "$(dirname "$0")/../.." && pwd)}"
LAB_RAIZ="${F3BASE_LAB_RAIZ:-/home/claude/work/lab}"
SRC=$FONTE/work/plugin/base-site-core-fator3
DST=$LAB_RAIZ/ui-$NOME/wordpress/wp-content/plugins/base-site-core-fator3
[ -d "$DST" ] || { echo "lab ui-$NOME não existe; crie com lab-ui.sh" >&2; exit 1; }
rm -rf "$DST.novo" && cp -a "$SRC" "$DST.novo" && rm -rf "$DST" && mv "$DST.novo" "$DST" && chown -R www-data:www-data "$DST"
echo "sincronizado: $(find "$DST" -type f | wc -l) arquivos"
