#!/usr/bin/env bash
# Laboratório de interface: WordPress 7.1.4 descartável servido por Apache + mod_php.
# Uso: lab-ui.sh <nome> <diretorio-runtime-do-plugin> <porta>
# Cria /home/claude/work/lab/ui-<nome>, banco core_ui_<nome>, instala, ativa o plugin
# e sobe um Apache próprio em 127.0.0.1:<porta>. Rede externa e e-mail bloqueados.
set -euo pipefail
NOME="$1"; RUNTIME="$2"; PORTA="$3"
# Variáveis do ambiente (os padrões são os da máquina em que a rodada 1.79.0 foi executada).
LAB_RAIZ="${F3BASE_LAB_RAIZ:-/home/claude/work/lab}"          # onde os laboratórios são criados
WPZIP="${F3BASE_WORDPRESS_ARCHIVE:-$LAB_RAIZ/wordpress-7.1.4.zip}"  # ZIP oficial do WordPress 7.1.4 (raiz wordpress/)
MYSQL_PORTA="${F3BASE_LAB_PORT:-33575}"                       # MySQL descartável em 127.0.0.1, root sem senha
APACHE_MODULOS="${F3BASE_APACHE_MODULOS:-/usr/lib/apache2/modules}"
LAB=$LAB_RAIZ/ui-$NOME
DB=core_ui_$NOME
SENHA=${F3BASE_QA_PASSWORD:-qa-$(head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n')}

if [ -f "$LAB/apache/httpd.pid" ]; then kill "$(cat "$LAB/apache/httpd.pid")" 2>/dev/null || true; sleep 1; fi
rm -rf "$LAB"; mkdir -p "$LAB/apache/logs"
mysql --protocol=TCP -h127.0.0.1 -P"$MYSQL_PORTA" -uroot -e "DROP DATABASE IF EXISTS $DB"
unzip -q "$WPZIP" -d "$LAB"
WP=$LAB/wordpress
# RUNTIME igual a "-" cria um WordPress sem o plugin (para ensaiar a instalação nativa a partir do ZIP).
[ "$RUNTIME" = "-" ] || cp -a "$RUNTIME" "$WP/wp-content/plugins/base-site-core-fator3"
mkdir -p "$WP/wp-content/mu-plugins" "$WP/wp-content/themes/core-qa"
cat > "$WP/wp-content/mu-plugins/000-qa-no-network.php" <<'PHP'
<?php
add_filter('pre_http_request',static function($pre,$args,$url){$h=wp_parse_url($url,PHP_URL_HOST);return $h==='127.0.0.1'?$pre:new WP_Error('qa_network_blocked','Local test');},PHP_INT_MAX,3);
add_filter('pre_wp_mail',static fn()=>true,PHP_INT_MAX);
PHP
printf '/*\nTheme Name: Core QA\nVersion: 1.0\n*/\n' > "$WP/wp-content/themes/core-qa/style.css"
cat > "$WP/wp-content/themes/core-qa/index.php" <<'PHP'
<!doctype html><html <?php language_attributes(); ?>><head><meta charset="utf-8"><?php wp_head(); ?></head><body <?php body_class(); ?>><main><?php if(have_posts()){while(have_posts()){the_post();the_title('<h1>','</h1>');the_content();}}else{echo 'Core QA';} ?></main><?php wp_footer(); ?></body></html>
PHP
printf "<?php add_action('after_setup_theme',static function(){add_theme_support('title-tag');});\n" > "$WP/wp-content/themes/core-qa/functions.php"

python3 -I - "$WP" "$DB" "$PORTA" "$MYSQL_PORTA" <<'PY'
import sys,secrets
wp,db,porta,mysql=sys.argv[1:5]
c={'DB_NAME':db,'DB_USER':'root','DB_PASSWORD':'','DB_HOST':'127.0.0.1:'+mysql,'DB_CHARSET':'utf8mb4','DB_COLLATE':'',
   'WP_ENVIRONMENT_TYPE':'local','WP_HOME':'http://127.0.0.1:'+porta,'WP_SITEURL':'http://127.0.0.1:'+porta,'FS_METHOD':'direct'}
t="<?php\n"+''.join("define(%r,%r);\n"%(k,v) for k,v in c.items())
t+="$table_prefix='wp_';define('DISABLE_WP_CRON',true);define('WP_DEBUG',true);define('WP_DEBUG_DISPLAY',false);define('WP_DEBUG_LOG',true);define('SCRIPT_DEBUG',false);\n"
for k in ('AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'):
    t+="define('%s','%s');\n"%(k,secrets.token_hex(32))
t+="if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';\n"
open(wp+'/wp-config.php','w').write(t)
PY

cat > "$LAB/instalar.php" <<'PHP'
<?php
$db=getenv('LAB_DB');$c=new mysqli('127.0.0.1','root','',null,(int)getenv('LAB_MYSQL'));$c->query('CREATE DATABASE '.$db);
define('WP_INSTALLING',true);$_SERVER['HTTP_HOST']='127.0.0.1:'.getenv('LAB_PORTA');
require getenv('LAB_WP').'/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
wp_install('Core QA interface','qa_admin','qa@example.test',false,'',getenv('LAB_SENHA'));wp_set_current_user(1);
switch_theme('core-qa');update_option('permalink_structure','/%postname%/');
if(!is_file(WP_PLUGIN_DIR.'/base-site-core-fator3/base-site-core-fator3.php')){echo "WordPress criado sem o plugin\n";exit(0);}
$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');
if(is_wp_error($r)){fwrite(STDERR,$r->get_error_message()."\n");exit(1);}
for($i=0;$i<30;$i++){$x=F3Base_Instalacao::atualizar();if(!empty($x['ok'])&&F3Base_Instalacao::origem()==='atual'){break;}}
echo 'instalado: '.F3BASE_PLUGIN_VERSAO.' origem='.F3Base_Instalacao::origem()."\n";
PHP
LAB_DB=$DB LAB_WP=$WP LAB_PORTA=$PORTA LAB_MYSQL=$MYSQL_PORTA LAB_SENHA=$SENHA php "$LAB/instalar.php"
printf '%s' "$SENHA" > "$LAB/senha.txt"; chmod 600 "$LAB/senha.txt"

cat > "$WP/.htaccess" <<'HT'
# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
HT
chown -R www-data:www-data "$WP"; chmod 644 "$WP/wp-config.php"
# O plugin provisiona uma pasta privada FORA da raiz do WordPress (irmã dela). O usuário do servidor web precisa
# poder criá-la; sem isso o ciclo de instalação entra em recuo na etapa pasta_privada quando roda pelo Apache.
chown www-data:www-data "$LAB"; for d in "$LAB"/f3-privado-*; do [ -d "$d" ] && chown -R www-data:www-data "$d"; done

M=$APACHE_MODULOS
cat > "$LAB/apache/httpd.conf" <<CONF
ServerRoot "$LAB/apache"
PidFile "$LAB/apache/httpd.pid"
Listen 127.0.0.1:$PORTA
ServerName 127.0.0.1
User www-data
Group www-data
LoadModule mpm_prefork_module $M/mod_mpm_prefork.so
LoadModule authz_core_module $M/mod_authz_core.so
LoadModule dir_module $M/mod_dir.so
LoadModule mime_module $M/mod_mime.so
LoadModule rewrite_module $M/mod_rewrite.so
LoadModule headers_module $M/mod_headers.so
LoadModule expires_module $M/mod_expires.so
LoadModule alias_module $M/mod_alias.so
LoadModule env_module $M/mod_env.so
LoadModule setenvif_module $M/mod_setenvif.so
LoadModule php_module $M/libphp8.3.so
TypesConfig /etc/mime.types
StartServers 2
MinSpareServers 2
MaxSpareServers 4
MaxRequestWorkers 8
DocumentRoot "$WP"
DirectoryIndex index.php index.html
ErrorLog "$LAB/apache/logs/error.log"
LogFormat "%h %t \"%r\" %>s %b" simples
CustomLog "$LAB/apache/logs/access.log" simples
<FilesMatch "\.php$">
  SetHandler application/x-httpd-php
</FilesMatch>
<Directory "$WP">
  AllowOverride All
  Require all granted
</Directory>
CONF
/usr/sbin/apache2 -f "$LAB/apache/httpd.conf" -k start
sleep 1
curl -s -o /dev/null -w "home HTTP %{http_code}\n" "http://127.0.0.1:$PORTA/"
curl -s -o /dev/null -w "login HTTP %{http_code}\n" "http://127.0.0.1:$PORTA/wp-login.php"
echo "LAB=$LAB PORTA=$PORTA"
