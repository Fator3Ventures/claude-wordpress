"""Homologação no Site-Teste. Usa tráfego marcado, ancora o resultado à sessão do ensaio e impede saída da página."""
import os, json, time
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
out=root/'evidence/1840'
host='fator3-teste-mcp-1.dreamhosters.com'; base='https://'+host
with sync_playwright() as p:
    opts={'executable_path':os.environ.get('F3BASE_CHROMIUM','/usr/bin/chromium'),'args':['--no-sandbox','--disable-dev-shm-usage']}
    if os.environ.get('HTTPS_PROXY'): opts['proxy']={'server':os.environ['HTTPS_PROXY']}
    b=p.chromium.launch(**opts)
    ctx=b.new_context(ignore_https_errors=True,viewport={'width':1280,'height':900})
    ctx.add_cookies([{'name':'f3base_teste','value':'1','url':base},{'name':'f3base_consentimento','value':'granted','url':base}])
    ctx.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname==host else r.abort())
    page=ctx.new_page();page.set_default_timeout(15000);ack=[];ids=[];errors=[];payloads=[]
    page.on('pageerror',lambda err:errors.append(str(err)[:180]))
    def response(r):
        if r.request.method!='POST' or '/f3base/' not in r.url: return
        try:
            data=r.json()
            if r.url.endswith('/analise'):
                ack.extend(x['evento'] for x in data.get('confirmados',[]))
            if data.get('record_id'):
                ids.append({k:data.get(k) for k in ['record_id','registrado','method','conversao','ok']})
        except Exception:pass
    page.on('response',response)
    def request(req):
        if req.method=='POST' and req.url.endswith('/analise'):
            try:payloads.extend(req.post_data_json.get('eventos',[]))
            except Exception:pass
    page.on('request',request)
    page.goto(base+'/?qa_core=1840-'+str(int(time.time())),wait_until='domcontentloaded',timeout=60000)
    print('pagina',page.title(),flush=True)
    try:
        page.wait_for_function("window.f3baseTracking?.alvoDeClique && window.f3baseTracking.sessao() && window.f3baseAnalise && window.f3baseContexto.teste()",timeout=45000)
    except Exception:
        print(page.evaluate("()=>({tracking:!!window.f3baseTracking,alvo:typeof window.f3baseTracking?.alvoDeClique,session:window.f3baseTracking?.sessao(),contexto:window.f3baseContexto?.estado(),cons:window.f3baseConsentimento?.permiteCategoria('medicao'),teste:window.f3baseContexto?.teste(),scripts:[...document.scripts].filter(x=>x.src.includes('base-site-core')).map(x=>x.src.slice(-80))})"),errors,flush=True);raise
    session=page.evaluate('f3baseTracking.sessao()')
    page.evaluate("""() => {
      const main=document.createElement('section'); main.className='f3base-secao-qa1840';
      const links=[['interno','/qa-interno/'],['externo','https://example.org/qa1840'],['email','mailto:qa@example.test'],['tel','tel:+5511999999999']];
      for(const [id,uri] of links){const a=document.createElement('a');a.id='qa1840-'+id;a.href=uri+'?ignorar=privado';a.innerText='QA '+id;a.className='f3base-clique-'+id;main.append(a);}
      document.body.prepend(main);
      const barra=document.createElement('aside');barra.className='f3base-secao-barra-fixa';const a=document.createElement('a');a.href='https://wa.me/5511999999999?text=privado';a.id='qa1840-barra';a.textContent='WhatsApp da barra';barra.append(a);document.body.append(barra);
      document.addEventListener('click',ev=>{if(ev.target.closest('a'))ev.preventDefault()},true);
    }""")
    sels=['#qa1840-interno','#qa1840-externo','#qa1840-email','#qa1840-tel','header a[href*="wa.me"]','#qa1840-barra','dialog a[href*="wa.me"]']
    for i,sel in enumerate(sels):
        if i==6:page.locator('dialog').filter(has=page.locator('a[href*="wa.me"]')).first.evaluate('(d)=>{if(!d.open)d.showModal()}')
        link=page.locator(sel).first
        link.dispatch_event('click',{'button':0,'bubbles':True,'cancelable':True,'composed':True});page.wait_for_timeout(500)
    page.wait_for_timeout(6500)
    ev=list({x['evento']:x for x in payloads if x['tipo']=='clique_link'}.values())
    result={'wordpress':'Site-Teste','versao':'1.84.0','chromium':b.version,'sessao':session,'links':[x['link'] for x in ev],'eventos_confirmados':sum(x['evento'] in ack for x in ev),'contatos':ids,'erros_js':errors}
    (out/'site-teste-navegador.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('links',len(ev),'confirmados',result['eventos_confirmados'],'contatos',len(ids),'erros',errors,flush=True)
    assert len(ev)==7 and result['eventos_confirmados']==7
    b.close()
