<?php
// Processo isolado da base: duas origens processam o mesmo instante físico previamente lido.
if(wp_get_environment_type()!=='local' || DB_NAME!=='core190base') {throw new RuntimeException('laboratório');}
global $wpdb;
$hook='f3base_conversoes_servidor';
$at=(int)file_get_contents(getenv('QA_AT'));
if (getenv('QA_MODE')==='seed') {
    wp_clear_scheduled_hook($hook);wp_schedule_event($at,'hourly',$hook);
} else {
    $origin=F3Base_Execucoes::origem();
    $read=static fn()=>hash('sha256',(string)$wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name='cron'"));
    $res=[];
    foreach (['reagendar'=>static fn()=>wp_reschedule_event($at,'hourly',$hook,[],true),
              'remover'=>static fn()=>wp_unschedule_event($at,$hook,[],true)] as $op=>$fn) {
        $before=$read();$out=$fn();$res[$op]=['resultado'=>is_wp_error($out)?$out->get_error_code():$out,'hash_igual'=>$before===$read()];
    }
    F3Base_Execucoes::iniciar('prova_dupla');
    $id=F3Base_Execucoes::iniciar_tarefa('conversoes',$hook,[],$at);
    if($id){F3Base_Execucoes::concluir_tarefa($id,['ok'=>true,'codigo'=>'prova_controlada']);}
    $claim=F3Base_Execucoes::reivindicacao();
    echo json_encode(['origem'=>$origin,'timestamp'=>$at,'operacoes'=>$res,'reivindicou'=>(bool)$id,'reserva'=>$claim['codigo'],'origem_dona'=>$claim['dona']['origem']??null]);
}
