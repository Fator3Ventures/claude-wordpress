// Relógio de parede das instalações descartáveis. Duração e timeouts usam relógio monotônico real.
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdint.h>
#include <time.h>
static volatile int64_t *offset;
__attribute__((constructor)) static void init_clock(void) {
    const char *file = getenv("F3_QA_CLOCK");
    if (!file) return;
    int fd = open(file, O_RDONLY);
    if (fd < 0) return;
    void *p = mmap(NULL, sizeof(int64_t), PROT_READ, MAP_SHARED, fd, 0);
    close(fd);
    if (p != MAP_FAILED) offset = p;
}
int clock_gettime(clockid_t id, struct timespec *ts) {
    int r = syscall(SYS_clock_gettime, id, ts);
    if (!r && offset && (id == CLOCK_REALTIME || id == CLOCK_REALTIME_COARSE)) ts->tv_sec += *offset;
    return r;
}
int gettimeofday(struct timeval *v, void *tz) {
    int r = syscall(SYS_gettimeofday,v,tz);
    if (!r && offset && v) v->tv_sec += *offset;
    return r;
}
time_t time(time_t *out) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME,&ts);
    if (out) *out=ts.tv_sec;
    return ts.tv_sec;
}
