<?php
if (wp_get_environment_type()!=='local' || DB_NAME!=='core190base') { throw new RuntimeException('laboratório exclusivo'); }
function verificar_capi($ok,$motivo) { if (!$ok) { throw new RuntimeException($motivo); } }
$c='F3Base_Capi_Fila';
$hook=$c::EVENTO; $individual=F3Base_Modulo_Meta_Capi::HOOK;
wp_clear_scheduled_hook($hook,F3Base_Fila::ANTECIPAR);
wp_clear_scheduled_hook($hook);
verificar_capi(wp_schedule_event(time()+DAY_IN_SECONDS,'daily',$hook,[],true)===true,'semear diária futura');
$novo=static function($id) use($c) {
    return $c::inserir($id,['data'=>[['event_name'=>'PageView','event_id'=>$id,'event_time'=>time()]],'_f3base_contexto_teste'=>true],7200,'1234567890');
};
$id='qa-190-'.wp_generate_uuid4();
verificar_capi($novo($id),'inserir');
verificar_capi(wp_next_scheduled($individual,[$id]) && !wp_next_scheduled($hook,F3Base_Fila::ANTECIPAR),'agenda individual');
$medidas=0;
add_action('f3base_fila_agenda_medida',static function($h,$t,$op,$r) use(&$medidas,$hook){ if($h===$hook && $r==='gravado') {++$medidas;} },10,4);
for ($i=0;$i<50;++$i) { verificar_capi($novo($id) && $c::planejar(),'repetir'); }
verificar_capi($medidas===0 && !wp_next_scheduled($hook,F3Base_Fila::ANTECIPAR),'visita alterou recuperação');
$id2='qa-190-'.wp_generate_uuid4();
add_filter('pre_schedule_event',static function($pre,$e) use($id2,$individual) {
    return $e->hook===$individual && $e->args===[$id2] ? false : $pre;
},0,2);
verificar_capi($novo($id2),'inserir segundo');
$antes=wp_next_scheduled($hook,F3Base_Fila::ANTECIPAR);
verificar_capi($antes && $antes<wp_next_scheduled($hook),'recuperação antes da diária');
for ($i=0;$i<50;++$i) { verificar_capi($novo($id2) && $c::planejar(),'repetir fallback'); }
verificar_capi($medidas===1 && wp_next_scheduled($hook,F3Base_Fila::ANTECIPAR)===$antes,'antecipação duplicada');
echo wp_json_encode(['itens_novos'=>2,'primeiro'=>'agenda individual confirmada','segundo'=>'falha individual induzida, uma antecipação confirmada','releituras_e_reinsercoes'=>100,'gravacoes_extras'=>0]);
