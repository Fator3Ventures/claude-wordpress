<?php
// MU-plugin exclusivo das três instalações de teste. Não altera a reserva ou as escritas dos seis ganchos.
if (wp_get_environment_type() !== 'local' || !in_array(DB_NAME,['core190b','core190c','core190e'],true)) { return; }
function f3qa_fila($hook) {
    return in_array($hook,['f3base_wp_mail_processar','f3base_pipedrive_processar','f3base_email_novo_lead_processar',
        'f3base_linkedin_notificacoes','f3base_conversoes_servidor','f3base_capi_recuperar'],true);
}
function f3qa_log($evento, $hook, $codigo, $ts=0) {
    if (!getenv('F3_QA_TRACE')) { return; }
    $linha=[time(),defined('WP_CLI') && WP_CLI ? 'cli' : 'http_cron',$evento,$hook,$codigo,$ts];
    file_put_contents(getenv('F3_QA_TRACE'),json_encode($linha)."\n",FILE_APPEND|LOCK_EX);
}
add_filter('pre_http_request',static fn()=>new WP_Error('laboratorio_isolado','Transporte isolado.'));
add_filter('pre_wp_mail',static fn()=>true);
// Somente as filas em estudo ocupam a agenda deste ensaio, inclusive em WP-CLI --due-now.
add_filter('pre_schedule_event',static fn($pre,$e)=>f3qa_fila($e->hook)?$pre:true,1,2);
foreach (['cron_reschedule_event_error','cron_unschedule_event_error'] as $op) {
    add_action($op,static function($err,$hook) use($op){if(f3qa_fila($hook)){f3qa_log($op,$hook,$err->get_error_code());}},10,2);
}
add_action('f3base_fila_agenda_medida',static fn($h,$ts,$op,$out)=>f3qa_log($op,$h,$out,$ts),10,4);
