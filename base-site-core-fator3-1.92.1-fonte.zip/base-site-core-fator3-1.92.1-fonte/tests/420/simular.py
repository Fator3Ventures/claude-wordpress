"""Parte de três instalações WP locais com core190b/c/e e o observador instalado."""
import argparse, concurrent.futures, json, mmap, os, pathlib, struct, subprocess, time, urllib.request

def simulate(profile, site, port, start, directory, targets, visitas=False):
    clock = directory / (profile+'.clock')
    trace = directory / (profile+'.jsonl')
    clock.write_bytes(struct.pack('q',0))
    env = {**os.environ,'F3_QA_CLOCK':str(clock),'F3_QA_TRACE':str(trace),'F3_QA_START':str(start),
           'PHP_CLI_SERVER_WORKERS':'10' if visitas else '4','LD_PRELOAD':str(directory/'clock.so')}
    php, phar = env['PHP_BIN'],env['KIT']+'/wp-cli.phar'
    wp=[php,phar,'--allow-root','--path='+str(site),'--user=1']
    request_url='http://127.0.0.1:'+str(port)+'/wp-cron.php'
    if visitas:
        subprocess.run(wp+['plugin','is-active','wp-security-audit-log'],env=env,check=True)
        subprocess.run(wp+['eval',"if (F3BASE_PLUGIN_VERSAO!=='1.91.0' || !defined('F3QA_VISITAS')) {exit(1);}"],env=env,check=True)
    def request(url):
        with urllib.request.urlopen(url,timeout=90) as response:
            response.read()
            if response.status!=200: raise ValueError(response.status)
    import signal
    with (directory/(profile+'.out')).open('w') as log, clock.open('r+b') as fp, mmap.mmap(fp.fileno(),8) as mem:
        subprocess.run(wp+['eval-file',str(pathlib.Path(__file__).with_name('perfil.php'))],env=env,check=True,stdout=log,stderr=log)
        server=subprocess.Popen([php,'-d','opcache.enable_cli=1','-S','127.0.0.1:'+str(port),'-t',str(site)],env=env,
                                start_new_session=True,stdout=log,stderr=log)
        try:
            time.sleep(0.7)
            count=0
            with concurrent.futures.ThreadPoolExecutor(max_workers=7 if visitas else 4) as pool:
                for tick in range(targets):
                    virtual=start+tick*300+2
                    mem[:]=struct.pack('q',virtual-int(time.time()))
                    jobs=[]
                    if tick%3==0:
                        jobs.append(pool.submit(subprocess.run,wp+['cron','event','run','--due-now'],env=env,check=True,stdout=log,stderr=log,timeout=150))
                        count+=1
                        # Alterna qual executor chega primeiro. As três requisições HTTP sempre partem juntas.
                        if tick%6==0: time.sleep(0.10)
                    jobs.extend(pool.submit(request, request_url) for _ in range(3))
                    if visitas:
                        public_url='http://127.0.0.1:'+str(port)+'/?f3qa_passo='+str(tick)
                        jobs.extend(pool.submit(request, public_url) for _ in range(3))
                    for job in jobs: job.result()
                    if tick%12==0: (directory/(profile+'.progress')).write_text(str(tick+1))
            stats={'perfil':profile,'inicio':start,'intervalos_5min':targets,'http_200':targets*3,'cli_ok':count}
            if visitas:
                stats['visitas_publicas_http_200']=targets*3
                stats['wsal_ativo']=True
            (directory/(profile+'.end')).write_text(json.dumps(stats))
        finally:
            os.killpg(server.pid,signal.SIGTERM)
            server.wait(timeout=30)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('directory',type=pathlib.Path);ap.add_argument('--ticks',type=int,default=288)
    ap.add_argument('--visitas-publicas',action='store_true',help='Pedido 423: WSAL ativo e três visitas simultâneas em cada passagem')
    args=ap.parse_args();d=args.directory.resolve();start=int(time.time())+7
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:
        runs=[p.submit(simulate,profile,d.parent/profile,18421+i,start,d,args.ticks,args.visitas_publicas) for i,profile in enumerate('BCE')]
        for run in runs: run.result()
