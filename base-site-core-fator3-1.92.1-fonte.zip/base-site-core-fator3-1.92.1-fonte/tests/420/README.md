# Ensaio de concorrência do WordPress

Use três instalações locais descartáveis do WordPress 7.1.4 em qa/B, qa/C e qa/E, com WP_ENVIRONMENT_TYPE=local, bancos MariaDB core190b, core190c e core190e, prefixo wp_, o Site Core 1.90.0 ativo e inicializado (F3Base_Instalacao::atualizar). Use os URLs locais 127.0.0.1 nas portas 18421, 18422 e 18423 respectivamente. O WP-Cron por visita fica ligado. Não configure credenciais de provedores.

Copie observador.php para wp-content/mu-plugins/420.php em cada instalação. O observador restringe o ensaio aos seis ganchos e bloqueia transporte externo. Cada fila conserva seus callbacks e suas tabelas. Há quatro processos PHP HTTP por site. O relógio simulado altera o tempo de parede em cada processo. Cada passagem de cinco minutos envia três requisições simultâneas a wp-cron.php e a cada terceira passagem também executa o WP-CLI.

Exporte PHP_BIN com o caminho do binário PHP, KIT com a pasta contendo wp-cli.phar e ROOT com o diretório pai de qa. Crie qa/sim vazio e use, a partir da raiz do fonte:

```sh
gcc -shared -fPIC tests/420/clock.c -o "$ROOT/qa/sim/clock.so"
python3 tests/420/simular.py "$ROOT/qa/sim"
bash tests/420/consultar-banco.sh
python3 tests/420/agregar.py "$ROOT/qa/sim"
```

O agregador falha se faltar uma ocorrência esperada, se houver dois sucessos no mesmo horário/gancho/argumentos, falha ou erro nativo de agenda. Ele informa por gancho as ocorrências concluídas e recusas neutras, separadas por origem. A execução automática sem credenciais confirma apenas o estado local dos módulos.

Para a prova isolada, use o banco local core190base com o plugin ativo, QA_AT apontando para um arquivo com o timestamp e QA_MODE=seed para semear controle-cron.php via wp eval-file. Rode o mesmo arquivo por WP-CLI e depois em um processo com DOING_CRON=true e wp-load.php. Compare os hashes, o proprietário e a recusa. capi.php exercita inserções reais no banco descartável, repetição do mesmo item e falha induzida somente no agendamento individual de um segundo item. Em produção use somente leituras agregadas aprovadas.

Para reconferir as 24 horas da rodada com os rastros e as contagens já arquivados, execute na raiz do fonte:

```sh
python3 tests/420/agregar.py evidence/1900 > /tmp/f3base-1900-recontagem.json
cmp /tmp/f3base-1900-recontagem.json evidence/1900/filas-24h.json
```
