<?php
if (!defined('WP_CLI') || wp_get_environment_type()!=='local' || !in_array(DB_NAME,['core190b','core190c','core190e'],true)) {throw new Exception('lab');}
$perfil=strtoupper(substr(DB_NAME,-1));
$comum=['cache_reaquecimento','carregamento_destinos','classificacao_acessos','gsc','primeira_resposta'];
$a=['pipedrive','email_site','email_historico','ga4_acervo'];
$mais=['email_novo_lead','anuncios_meta','meta_ads','meta_monitoramento','qualidade'];
$perfis=['B'=>[...$a,...$mais,'pipedrive_operacao'],'C'=>[...$a,...$mais,'anuncios_linkedin','google_ads_acervo','gsc_consultas'],'E'=>['pipedrive','email_historico']];
foreach (array_unique([...$comum,...array_merge(...array_values($perfis))]) as $id) {
    $on=in_array($id,[...$comum,...$perfis[$perfil]],true);
    $v=F3Base_Options::ler('f3base_'.$id);$v=is_array($v)?$v:[];
    $v['ativo']=$on;
    if($id==='email_site'){$v['wp_mail_pela_caixa']=$on;}
    if($id==='meta_monitoramento'){$v['avisar']=$on;}
    if($id==='anuncios_linkedin'){$v=['integracoes'=>['principal'=>['ativo'=>$on]+F3Base_Linkedin_Integracoes::padrao()]];}
    if($id==='google_ads_acervo'){$v['conexao']='laboratorio';$v['conta_id']='1234567890';}
    update_option('f3base_'.$id,$v);
}
update_option('cron',['version'=>2]);
$at=(int)getenv('F3_QA_START');
foreach(F3Base_Fila::RECORRENCIAS as $hook=>$freq){
    $active=match($hook){
        'f3base_linkedin_notificacoes'=>$perfil==='C',
        'f3base_wp_mail_processar'=>$perfil!=='E',
        default=>true
    };
    if($active && wp_schedule_event($at,$freq,$hook,[],true)!==true){throw new RuntimeException($hook);}
}
echo wp_json_encode(['perfil'=>$perfil,'cron_visita'=>!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON),'versao'=>F3BASE_PLUGIN_VERSAO]);
