"""Reconcilia os recibos do banco e os eventos nativos do laboratório, por perfil e origem."""
import csv
import json
import sys
from collections import Counter
from pathlib import Path

d=Path(sys.argv[1])
hooks={'wp_mail_processar':288,'pipedrive_processar':288,'email_novo_lead_processar':24,'linkedin_notificacoes':288,'conversoes_servidor':24,'capi_recuperar':1}
result={}
for profile in 'BCE':
    summary=json.loads((d/(profile+'.end')).read_text())
    assert (summary['intervalos_5min'],summary['http_200'],summary['cli_ok'])==(288,864,96)
    ops=Counter(json.loads(l)[4] for l in (d/(profile+'.jsonl')).open())
    bad=set(ops)-{'gravado','ja_persistido'}
    assert not bad, bad
    assert not (d/(profile.lower()+'.duplicadas')).read_text().strip()
    by_hook={h:{o:Counter() for o in ['http_cron','cli']} for h in hooks}
    for hook,origin,code,success,count,with_occ in csv.reader((d/(profile.lower()+'.contagem')).open(),delimiter='\t'):
        counts=by_hook[hook.removeprefix('f3base_')][origin]
        if success=='1':
            assert count==with_occ and code in ('lote_concluido','checkpoint_confirmado_releitura'),(hook,code)
            counts['concluidas']+=int(count)
        else:
            assert success=='-1' and code=='reserva_ocupada',(hook,code)
            counts['disputas_neutras']+=int(count)
    for hook,expected in hooks.items():
        active=not ((hook=='wp_mail_processar' and profile=='E') or (hook=='linkedin_notificacoes' and profile!='C'))
        assert sum(x['concluidas'] for x in by_hook[hook].values())==(expected if active else 0),(profile,hook)
    result[profile]={'carga':summary,'agenda':dict(ops),'duplicadas':0,'falhas':0,'could_not_set':0,'ganchos':by_hook}
print(json.dumps(result,indent=2,ensure_ascii=False))
