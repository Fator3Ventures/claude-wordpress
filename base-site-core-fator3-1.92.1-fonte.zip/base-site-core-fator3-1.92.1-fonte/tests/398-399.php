<?php
require __DIR__.'/bootstrap-1851.php';
global $wpdb;
$sessao=bin2hex(random_bytes(16));$nav=bin2hex(random_bytes(16));$ids=[];
$path='/qa-1851-'.substr($nav,0,8).'/';
$base=['sessao'=>$sessao,'visitante'=>$sessao,'navegacao'=>$nav,'dispositivo'=>'desktop','caminho'=>$path,'contexto_teste'=>true,'criado_em'=>time()];
$filtro=['sessao'=>$sessao,'segmento'=>'somente_testes'];
$add=static function($data)use($base){
    $evento=F3Base_Analise::validar($data+['evento'=>bin2hex(random_bytes(16))]+$base);
    if(isset($evento['erro'])){throw new RuntimeException($evento['erro']);}
    $result=F3Base_Analise::persistir($evento);
    if(empty($result['ok'])){throw new RuntimeException(wp_json_encode($result));}
    return $evento;
};
try {
    wp_set_current_user(0);$add(['tipo'=>'pagina']);
    foreach([home_url('/interno/'),'https://outside.example/a','mailto:qa@example.test','tel:+5511999999999','https://wa.me/5511999999999','https://wa.me/5511999999999','https://wa.me/5511999999999'] as $i=>$uri){
        $secao=['conteudo','conteudo','conteudo','conteudo','cabecalho','barra','dialogo'][$i];
        $evento=$add(['tipo'=>'clique_link','link'=>['destino'=>$uri.'?segredo=sigiloso#secreto','alvo'=>$secao.'~'.$secao.':controle:'.($i+1),'secao'=>$secao,'classe'=>'f3base-clique-teste','texto'=>str_repeat('á',85),'nova_aba'=>$i===1]]);
        check(!empty(F3Base_Analise::persistir($evento)['duplicado']),'retry_'.$i);
    }
    wp_set_current_user(1);$rows=wp_get_ability('f3base/eventos-ler')->execute($filtro+['metrica'=>'f3base_clique_link']);
    check(!is_wp_error($rows)&&count($rows['linhas'])===7,'sete_linhas',is_wp_error($rows)?$rows->get_error_message():null);
    foreach($rows['linhas'] as $i=>$l){
        check($l['tipo']===['interno','externo','e-mail','telefone','externo','externo','externo'][$i]&&!strpbrk($l['destino'],'?#')&&mb_strlen($l['texto'])===80&&$l['nova_aba']===($i===1),'projecao_'.$i);
    }
    foreach(['destino'=>5,'secao'=>4,'alvo'=>7] as $campo=>$n){
        $cursor='';$soma=0;$grupos=[];
        do{$q=F3Base_Medicao_Consultas::consultar('eventos',$filtro+['agrupar_por'=>$campo,'limite'=>2,'cursor'=>$cursor]);foreach($q['linhas'] as $l){$grupos[]=$l[$campo];$soma+=$l['contagem'];}$cursor=$q['proximo_cursor'];}while($cursor);
        check(count(array_unique($grupos))===$n&&$soma===7,'grupos_'.$campo);
    }
    $q=F3Base_Editorial_Relatorios::consultar(['visao'=>'conteudo','caminho'=>$path,'segmento'=>'somente_testes','automacao'=>'todas','de'=>wp_date('Y-m-d'),'ate'=>wp_date('Y-m-d')]);
    check(str_contains(wp_json_encode($q,JSON_UNESCAPED_SLASHES),'"https://wa.me/5511999999999":3'),'editorial_seguintes');
    $setting=F3Base_Telefone::OPTION;
    $old=get_option($setting,null);check(F3Base_Options::declaracao($setting)['padrao']===false,'padrao_frota');
    $contato=F3Base_Options::ler('f3base_contato');$aviso=F3Base_Options::ler('f3base_avisos');
    add_filter('pre_option_f3base_avisos',static fn()=>['canal'=>'slack','slack_transporte'=>'webhook']+$aviso);
    add_filter('pre_option_f3base_contato',static fn()=>['avisar_por_clique'=>true]+$contato);
    $_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='granted';wp_set_current_user(0);
    foreach([true,false] as $valor){
        update_option($setting,$valor);
        foreach(['https://wa.me/5511999999999','tel:+5511999999999'] as $i=>$url){
            $id=bin2hex(random_bytes(16));$ids[]=$id;
            $dados=['destino'=>$url,'formulario'=>'qa','pagina'=>$path,'correlation_id'=>$id,'contexto_teste'=>true,'classe_trafego'=>'teste','sessao'=>$sessao,'consentimento_medicao'=>true,'classificacao_contexto'=>'permitida'];
            $gravado=F3Base_Leads_Repositorio::clique($dados,$id);
            $lead=F3Base_Leads_Repositorio::obter($id);$key=(int)$valor.'_'.$i;
            check($gravado['ok']&&$lead['metodo']===($i===0?'whatsapp_cta':'contato_cta'),'captura_'.$key);
            check($lead['dados']['aviso_intencao']['elegivel']&&$lead['dados']['aviso_intencao']['canal']==='slack','intencao_slack_'.$key);
            check(F3Base_Aquisicoes::reservar($lead)['codigo']==='clique_sem_formulario','sem_reserva_'.$key);
            check(!F3Base_Modulo_Meta_Capi::agendar_registro($id,true)['agendado'],'sem_capi_'.$key);
            F3Base_Conversoes_Servidor::capturar($lead);
            foreach([F3Base_Capi_Fila::tabela(),F3Base_Conversoes_Servidor::tabela()] as $t){check(!$wpdb->get_var($wpdb->prepare('SELECT 1 FROM %i WHERE record_id=%s',$t,$id)),'fila_vazia_'.$key.'_'.$t);}
        }
    }
    $id=bin2hex(random_bytes(16));$ids[]=$id;
    $d=['record_id'=>$id,'metodo'=>'whatsapp_formulario','telefone'=>'+5511999999999','nome'=>'QA formulário','contexto_teste'=>true,'captura'=>'aceito','notificar'=>false,'classe_trafego'=>'teste','consentimento_snapshot'=>['medicao'=>true,'publicidade'=>true],'classificacao_contexto'=>'permitida'];
    $r=F3Base_Leads_Repositorio::guardar($d,null,null,'',true);$lead=F3Base_Leads_Repositorio::obter($id);
    check(!empty($r['ok'])&&F3Base_Aquisicoes::reservar($lead)['elegivel'],'formulario_valido_elegivel');
} finally {
    wp_set_current_user(1);
    if(isset($setting)){if($old===null){delete_option($setting);}else{update_option($setting,$old);}}
    foreach($ids as $id){F3Base_Leads_Repositorio::eliminar($id,'qa');}
    foreach([F3Base_Analise::tabela(),F3Base_Modulo_Comportamento::nome_tabela_eventos(),F3Base_Sessoes::tabela()] as $table){$wpdb->delete($table,['sessao'=>$sessao]);}
}
evidence('398-399');
