<?php
require __DIR__.'/bootstrap-1851.php';
global $wpdb;
$id=bin2hex(random_bytes(16));$owner=bin2hex(random_bytes(16));
$assets=F3Base_Leads_Repositorio::tabela('arquivos_leads');$grants=F3Base_Leads_Repositorio::tabela('concessoes');
$root=F3Base_Arquivos_Privados::raiz(true);check($root!=='','diretorio_privado');$path=$root.'/'.$id;
try{
 file_put_contents($path,'amostra');
 check((bool)$wpdb->insert($assets,['id'=>$id,'finalidade'=>'conteudo','nome'=>'qa.txt','mime'=>'text/plain','bytes'=>7,'sha256'=>hash_file('sha256',$path),'criado_em'=>time(),'estado'=>'ativo']),'material_ativo');
 $count=static fn()=>(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE ativo=%s',$grants,$id));
 $f=['ativo'=>$id];
 foreach(['','invalido'] as $i=>$email){
  $r=F3Base_Conteudo_Privado::conceder($owner,$f,$email);
  check(!$r['ok']&&!isset($r['url'])&&$count()===0,'sem_concessao_'.$i);
 }
 $lead=F3Base_Leads_Repositorio::guardar(['record_id'=>$owner,'nome'=>'QA','metodo'=>'conteudo','captura'=>'aceito','email'=>'qa@example.test','notificar'=>false],null,null,'',true);
 check($lead['ok'],'lead_de_controle');
 $g1=F3Base_Conteudo_Privado::conceder($owner,$f,'qa@example.test');check($g1['ok']&&$count()===1,'concessao_valida');
 $g2=F3Base_Conteudo_Privado::conceder($owner,$f,'qa@example.test');check($g2['ok']&&$g2['duplicado']&&$g2['url']===$g1['url']&&$count()===1,'reenvio_mesma_concessao');
 $bad=F3Base_Conteudo_Privado::conceder(bin2hex(random_bytes(16)),$f,'');check(!$bad['ok']&&!isset($bad['url'])&&$count()===1,'terceiro_sem_email_nao_recebe_link_anterior');
}finally{
 $wpdb->delete($grants,['ativo'=>$id]);$wpdb->delete($assets,['id'=>$id]);
 if(is_file($path)){unlink($path);}F3Base_Leads_Repositorio::eliminar($owner,'qa');
}
evidence('material-1851');
