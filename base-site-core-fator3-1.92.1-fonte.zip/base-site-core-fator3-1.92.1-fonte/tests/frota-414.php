<?php
/** Compara códigos agregados lidos na frota com o catálogo instalado no laboratório. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || DB_NAME !== 'core189upgrade') {
    throw new RuntimeException('Este ensaio exige o banco de atualização descartável.');
}
$arquivo = getenv('F3_QA_FROTA_414');
$amostra = json_decode(file_get_contents($arquivo), true, 512, JSON_THROW_ON_ERROR);
$resultados = [];
foreach ($amostra['sites'] as $site) {
    $identificados = 0;
    $pendentes = [];
    foreach ($site['itens'] as $item) {
        $ficha = F3Base_Catalogo_Aparelhos::resolver($item['codigo'], []);
        if (empty($ficha['nome_comercial'])) {
            $pendentes[] = $item['codigo'];
        } else {
            ++$identificados;
        }
    }
    $resultados[$site['site']] = ['amostra' => count($site['itens']), 'identificados' => $identificados, 'pendentes' => $pendentes];
}
echo wp_json_encode(['versao_local' => F3BASE_PLUGIN_VERSAO, 'regras' => 'catálogo embarcado', 'sites' => $resultados], JSON_PRETTY_PRINT);
