from pathlib import Path
from PIL import Image
import json,hashlib
root=Path(__file__).resolve().parents[1] / 'evidence' / '1890'
checks=[]; areas={}; errors=[]
for area,can in [('ui-depois',54),('ui-subabas',150),('ui-conexoes',33),('ui-recuperacao',3)]:
 d=root/area;a=json.loads((d/'resultados.json').read_text());areas[area]=len(a);assert len(a)==can,(area,len(a))
 for r in a:
  p=d/(r['key']+'-'+str(r['width'])+'.png');im=Image.open(p)
  if not(r['status']==200 and not r['critico'] and r['selo']=='Versão 1.89.0' and r['largura']==r['width']==im.width and im.height==900):errors.append(r)
  checks.append(r)
i=json.loads((root/'ui-interacoes/interacoes.json').read_text())
assert len(i)==13 and all(i.values())
out={'capturas':len(checks),'destinos_e_estados':len(checks)//3,'larguras':[360,768,1440],'reprovados':errors,'grupos':areas,'interacoes_aprovadas':len(i)}
(root/'painel.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
assert not errors, errors
print(out)
