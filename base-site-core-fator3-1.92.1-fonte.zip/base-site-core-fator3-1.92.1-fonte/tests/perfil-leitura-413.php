<?php
/** Exclusivo do banco descartável da atualização. Uso antes e depois do ensaio via WP-CLI. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || DB_NAME !== 'core1881upgrade') {
    throw new RuntimeException('Laboratório descartável da 1.88.1 obrigatório.');
}
$acao = getenv('F3_QA_PERFIL');
if (!in_array($acao, ['associate', 'revoke'], true)) {
    throw new RuntimeException('Informe a operação de laboratório.');
}
$resultado = \Fator3\McpFiles\ConnectionsAdmin::save([
    'intent' => $acao,
    'user_id' => get_current_user_id(),
    'connection_id' => 'integration:user:' . get_current_user_id(),
    'profile' => 'read',
    'label' => 'Leitura temporária do laboratório 413',
    'expires' => gmdate('c', time() + HOUR_IN_SECONDS),
]);
echo wp_json_encode($resultado, JSON_PRETTY_PRINT);
if (empty($resultado['success'])) { throw new RuntimeException('A política local não foi gravada.'); }
