<?php
if (($argv[1] ?? '') === 'provider-init') {
 define('WP_ADMIN', true);$_SERVER['REQUEST_METHOD']='GET';$_SERVER['REQUEST_URI']='/wp-admin/edit-tags.php?taxonomy=author';
}
require __DIR__.'/bootstrap-1811.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
$mode=$argv[1];
if($mode==='provider-init'){
 require_once ABSPATH.'wp-admin/includes/admin.php';set_current_screen('edit-author');do_action('admin_init');
 check(get_option('PP_AUTHORS_VERSION')===PP_AUTHORS_VERSION,'fornecedor_inicializado');evidence('fornecedor-inicializado');exit;
}
if($mode==='prepare'){
 foreach(['wordpress-seo/wp-seo.php','wp-super-cache/wp-cache.php','publishpress-authors/publishpress-authors.php'] as $plugin){$r=activate_plugin($plugin);check(!is_wp_error($r),'ativa_'.$plugin);}
 update_option('ppma_activated',false);$yoast=get_option('wpseo',[]);$yoast['should_redirect_after_install_free']=false;update_option('wpseo',$yoast);
 update_option('permalink_structure','/%postname%/');$GLOBALS['wp_rewrite']->init();flush_rewrite_rules(false);
 $cfg=F3Base_Protecao::config();$cfg['usuarios_rest_restritos']=true;update_option('f3base_protecao',$cfg);
 $s=F3Base_Options::ler('f3base_seo_entidade');$s['autoria']='usuario';update_option('f3base_seo_entidade',$s);
 $id=(int)get_option('qa_178_post') ?: wp_insert_post(['post_type'=>'post','post_status'=>'publish','post_title'=>'Artigo de prova 178','post_name'=>'homologacao-178','post_author'=>1,'post_content'=>'Trecho público verificável da homologação.']);
 update_option('qa_178_post',$id);update_post_meta($id,'_f3base_autoria','usuario');echo $id;exit;
}
$id=(int)get_option('qa_178_post');$url=get_permalink($id);
if($mode==='authors'){
 $term=wp_insert_term('Editora de Homologação','author',['slug'=>'editora-da-homologacao']);$term=is_wp_error($term)?(int)$term->get_error_data('term_exists'):(int)$term['term_id'];
 \MultipleAuthors\Classes\Utils::set_post_authors($id,[\MultipleAuthors\Classes\Objects\Author::get_by_term_id($term)],false);check((bool)f3pa_authors($id),'perfil_aprovado');
 update_option('qa_178_term',$term);F3Base_Modulo_Cache_Publico::invalidar(true);exit;
}
if(str_starts_with($mode,'mixed-')){
 $GLOBALS['wp_query']=new WP_Query(['p'=>$id]);$g=[['@type'=>'Article','@id'=>$url.'#article','mainEntityOfPage'=>['@id'=>$url],'author'=>['@id'=>'#old']],['@type'=>'WebPage','@id'=>$url,'author'=>['@id'=>'#old']],['@type'=>'WebPage','@id'=>'https://example.org/pagina','author'=>['@id'=>'#outra-pessoa']],['@type'=>'Person','@id'=>'#outra-pessoa','name'=>'Perfil de outra página']];
 $n=f3pa_schema_graph($g);$changed=$n[2]!==$g[2];check(($mode==='mixed-oficial')===$changed,'resultado_observado_na_ponte');
 check($n[0]['author']!==$g[0]['author'] && $n[0]['author']===$n[1]['author'],'credito_aprovado_nas_pecas_principais');
 if(!$changed){check(in_array('#outra-pessoa',array_column($n,'@id'),true),'pessoa_de_outra_pagina_preservada');}
 evidence($mode,['webpage_alheia_alterada'=>$changed]);exit;
}
if($mode==='disable'){deactivate_plugins('publishpress-authors/publishpress-authors.php');F3Base_Modulo_Cache_Publico::invalidar(true);exit;}
if($mode==='server'){
 $_SERVER['SERVER_SOFTWARE']='Apache/2.4';$cfg=F3Base_Options::ler('f3base_servidor');$cfg['bloquear_listagem']=true;update_option('f3base_servidor',$cfg);
 $r=F3Base_Servidor::executar(['acao'=>'aplicar','revisao_esperada'=>F3Base_Servidor::revisao(),'contexto_teste'=>true]);echo wp_json_encode($r);exit;
}
if($mode==='worker'){
 $page=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Cópia de prova','post_name'=>'copia-178','post_content'=>'Ensaio de cópia anônima.']);
 $path=wp_parse_url(get_permalink($page),PHP_URL_PATH);$event=bin2hex(random_bytes(16));
 $row=['evento'=>$event,'visitante'=>bin2hex(random_bytes(16)),'sessao'=>bin2hex(random_bytes(16)),'navegacao'=>bin2hex(random_bytes(16)),'post_id'=>$page,'tipo'=>'pagina','caminho'=>$path,'dispositivo'=>'desktop','navegador'=>'chrome','criado_em'=>time(),'recebido_em'=>time(),'qualidade'=>'normal','atribuicao'=>'{}','payload_hash'=>hash('sha256',$event)];
 check(!empty(F3Base_Analise::persistir($row)['ok']),'persistiu_visita');
 update_option(F3Base_Cache_Reaquecimento::OPTION,['ativo'=>true,'dias_visita'=>7,'paginas_por_hora'=>20]);
 $_SERVER['SERVER_PORT']=8137;$r=F3Base_Cache_Reaquecimento::processar();$state=wp_get_ability('f3base/cache-reaquecimento-ler')->execute([]);
 $result=array_values(array_filter($state['estado']['resultados']??[],static fn($x)=>$x['caminho']===$path))[0]??[];
 if(($result['resultado']??'')!=='copia_gerada'){throw new RuntimeException(wp_json_encode([$r,$result,F3Base_Cache_Pagina::perfil()]));}
 check($result['http']===200&&$result['anonima'],'copia_gerada_anonima_confirmada');evidence('worker-1780',['passagem'=>$r,'resultado'=>$result]);exit;
}
throw new RuntimeException('Modo desconhecido');
