<?php
if (!defined("WP_CLI") || !WP_CLI || wp_get_environment_type() !== "local" || !in_array(DB_NAME,["core186","fresh186"],true)) { throw new RuntimeException("Fixture exclusiva de laboratório"); }
global $wpdb;
foreach (range(1,55) as $n) {
    $id=md5('core186-local-'.$n);
    $dados=['atribuicao'=>['gclid'=>'ficticio','utm_source'=>'google','utm_medium'=>'cpc','utm_id'=>'123'],'contexto'=>['user_agent'=>'Mozilla/5.0']];
    if ($n===54) {$dados=['atribuicao'=>'registro antigo','contexto'=>['superficie'=>[],'audiencia'=>'X','perfil_aparelho_ref'=>'X'],'navegacao'=>['X']];}
    $wpdb->replace(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id,'nome'=>'Contato Exemplo '.$n,'metodo'=>'formulario','classe_trafego'=>$n===2?'teste':'nao_marcado','lixeira'=>(int)($n===3),'criado_em'=>gmdate('Y-m-d H:i:s',time()-3600-$n),'atualizado_em'=>current_time('mysql',true),'pagina'=>'/exemplo/','dados'=>wp_json_encode($dados),'google_ads'=>wp_json_encode(['codigo'=>'encontrado','clique'=>['date'=>gmdate('Y-m-d'),'campaign_name'=>'Exemplo local']]),'anexos'=>'[]','payload_hash'=>hash('sha256',$id)]);
}
echo $wpdb->last_error;
