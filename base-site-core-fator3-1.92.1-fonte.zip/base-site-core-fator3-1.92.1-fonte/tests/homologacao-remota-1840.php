<?php
/** Teste temporário restrito às quatro sessões sintéticas desta homologação. */
defined('ABSPATH') || exit;
add_action('wp_abilities_api_init',static function(){
 wp_register_ability('f3qa/fechar-core-1840',[
  'label'=>'Conferir e encerrar a homologação 398/399','description'=>'Verifica avisos, filas e elegibilidade dos contatos sintéticos.',
  'category'=>'site','input_schema'=>['type'=>'object','properties'=>['acao'=>['type'=>'string','enum'=>['conferir','limpar']]],'required'=>['acao'],'additionalProperties'=>false],
  'output_schema'=>['type'=>'object','additionalProperties'=>true],'meta'=>['mcp'=>['public'=>true,'type'=>'tool']],
  'permission_callback'=>static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads')&&wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com'&&F3BASE_PLUGIN_VERSAO==='1.84.0',
  'execute_callback'=>static function($e){
   global $wpdb;
   $sessions=['5feff3b68bc7e26ba48f2f77f4c2fb13','9d7e880bc2675c3b6a9fd268e9c030bb','a27a4b79f63f21badf6ce8261e9154cc','462168a44ea29435e5c53e152ad13d45'];
   $records=[];$restantes=[];$erros=[];
   foreach ($sessions as $s){
    $ids=$wpdb->get_col($wpdb->prepare("SELECT record_id FROM %i WHERE sessao=%s AND classe_trafego='teste'",F3Base_Leads_Repositorio::tabela(),$s));
    foreach($ids as $id){
     $l=F3Base_Leads_Repositorio::obter($id);
     if(!in_array($l['metodo']??'',['whatsapp_formulario','whatsapp_cta'],true)||$l['classe_trafego']!=='teste'||$l['sessao']!==$s){return ['ok'=>false,'codigo'=>'escopo_invalido'];}
     if($e['acao']==='limpar'){
      if(!F3Base_Leads_Repositorio::eliminar($id,'homologacao_1840')){$erros[]='limpeza_contato';}continue;
     }
     $event=F3Base_Aquisicoes::event_id($l);$r=F3Base_Aquisicoes::reservar($l);
     $avisos=$wpdb->get_results($wpdb->prepare('SELECT estado,codigo FROM %i WHERE record_id=%s',F3Base_Avisos::tabela(),$id),ARRAY_A);
     $records[]=['record_id'=>$id,'metodo'=>$l['metodo'],'cta'=>$l['dados']['cta']??'','superficie'=>$l['dados']['superficie']??'','codigo'=>$r['codigo'],'elegivel'=>$r['elegivel'],'aviso'=>$avisos,
      'fila_servidor'=>$wpdb->get_results($wpdb->prepare('SELECT destino,estado,codigo FROM %i WHERE record_id=%s',F3Base_Conversoes_Servidor::tabela(),$id),ARRAY_A),
      'fila_capi'=>(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE record_id=%s',F3Base_Capi_Fila::tabela(),$id)),
      'lead_meta'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE nome='Lead' AND evento=%s",$wpdb->prefix.'f3base_meta_eventos',hash('sha256','Lead|'.$event)))];
    }
    if($e['acao']==='limpar'){
     foreach([F3Base_Analise::tabela()=>'classe_trafego',F3Base_Modulo_Comportamento::nome_tabela_eventos()=>'classe_trafego',F3Base_Sessoes::tabela()=>'classe',F3Base_Perfil_Aparelho::tabela()=>'classe'] as $t=>$col){
      if(false===$wpdb->delete($t,['sessao'=>$s,$col=>'teste'])){$erros[]='limpeza_sessao';}
     }
     $restantes[$s]=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE sessao=%s',F3Base_Leads_Repositorio::tabela(),$s));
    }
   }
   return ['ok'=>!$erros&&!array_sum($restantes),'contatos'=>$records,'restantes'=>$restantes,'erros'=>$erros,'versao'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION];
  }]);
});
