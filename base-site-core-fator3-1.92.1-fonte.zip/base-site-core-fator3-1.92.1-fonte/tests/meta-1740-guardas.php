<?php
require __DIR__.'/bootstrap.php';
require_once F3BASE_PLUGIN_DIR.'admin/class-f3base-admin-entrada.php';
$area = 'medicao-meta';
$lead = F3Base_Meta_Lead::OPTION;
$pixel = 'f3base_meta_capi_pixel_id';
function contexto374(array $nomes): array {
    $fotos = F3Base_Options::fotografias($nomes);
    $declaracoes = array_intersect_key(F3Base_Options::catalogo(), array_flip($nomes));
    $id = F3Base_Admin_Entrada::contexto('medicao-meta', $declaracoes, $fotos);
    return array($id, array_map(static fn($foto) => $foto['revisao'], $fotos));
}
function enviar374($id, $revisoes, $valores, $fim=null, $apagar=array()): array {
    return F3Base_Admin_Entrada::processar($valores, $revisoes, $apagar, $id, 'medicao-meta', $fim ?? $id);
}
[$id, $revs] = contexto374([$lead,$pixel]);
$r = enviar374($id,$revs,[$pixel=>'12345'],'');
check($r[0]['codigo']==='contexto_invalido','recusa_sentinela_ausente');
$r = enviar374($id,$revs,[$pixel=>'12345','f3base_gtm_container_id'=>'GTM-INVALID']);
check($r[0]['codigo']==='escopo_invalido','recusa_campo_de_outra_area');
$r = enviar374($id,$revs,[$pixel=>'12345'], null,['f3base_meta_capi_token']);
check($r[0]['codigo']==='escopo_invalido','recusa_apagar_fora_do_envio');
wp_set_current_user(0);
$r=enviar374($id,$revs,[$pixel=>'12345']);
check($r[0]['codigo']==='sem_permissao','recusa_usuario_sem_permissao');
wp_set_current_user(1);
check(enviar374($id,$revs,[])===array(),'envio_vazio_sem_escritas');
check(enviar374($id,$revs,[$pixel=>'12345'])[0]['codigo']==='contexto_invalido','contexto_consumido_nao_repete_gravacao');
[$id,$revs]=contexto374([$lead,$pixel]);
$antes=F3Base_Options::ler($lead);
$r=enviar374($id,$revs,[$lead=>['modo'=>'imediato'],$pixel=>'23456']);
check($r[0]['codigo']==='entrada_incompleta' && $r[1]['persisted'],'grupo_truncado_recusado_e_pixel_gravado');
check(F3Base_Options::ler($lead)===$antes,'grupo_truncado_preserva_mapa');
[$id,$revs]=contexto374([$lead,$pixel]);
update_option($pixel,'34567');
$raw=['modo'=>'imediato','formularios'=>'{"qa":"agente"}'];
$r=enviar374($id,$revs,[$pixel=>'99999',$lead=>$raw]);
check($r[0]['persisted'] && $r[1]['codigo']==='conflito','conflito_recusa_apenas_opcao_desatualizada');
check(F3Base_Options::ler($pixel)==='34567' && F3Base_Options::ler($lead)['formularios']===['qa'=>'agente'],'concorrencia_preserva_valor_mais_recente_e_grupo_independente');
[$id,$revs]=contexto374([$lead,$pixel]);
update_option($pixel,'45678');
$r=enviar374($id,$revs,[$lead=>['modo'=>'agente','formularios'=>'{}']]);
check(count($r)===1 && $r[0]['persisted'],'alteracao_concorrente_em_campo_omitido_nao_bloqueia');
evidence('guardas-admin-meta');
