# Testes do Site Core

Para a 1.89.1, a sequência do pedido 415 está no README da raiz do fonte. Os scripts de regressão e suas fixtures das rodadas anteriores foram preservados para manutenção. Os nomes identificam a versão ou os pedidos que originaram cada ensaio. Resultados históricos, capturas e ambientes de versões antigas pertencem aos respectivos pacotes de origem.
