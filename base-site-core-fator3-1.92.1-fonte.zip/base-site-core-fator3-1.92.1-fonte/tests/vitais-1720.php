<?php
/** Reconstructed regression: native DDL, provenance, p75 and concurrent writers. */
require __DIR__.'/bootstrap.php';
global $wpdb;
$source=F3Base_Vitais::tabela();
$wpdb->prefix.='qa1720_';
$table=F3Base_Vitais::tabela();
if (($argv[1]??'')==='worker') {
    $group=(int)$argv[2]; $start=(float)$argv[3];
    while(microtime(true)<$start){usleep(1000);}
    for($i=1;$i<=15;$i++) {
        $seq=$i*2-($group===1?1:0);
        $ok=F3Base_Vitais::gravar(wp_date('Y-m-d'),'/race/',[
            'detalhe'=>'LCP','soma'=>$seq*10,'amostra'=>['id'=>'race1720','dispositivo'=>'movel',
            'sequencia'=>$seq,'versao_origem'=>$group===1?'1.72.0':'1.72.1']]);
        if(!$ok){throw new RuntimeException('race writer failed');}
        usleep(2000);
    }
    echo 'ok';exit;
}
$wpdb->query("DROP TABLE IF EXISTS $table");
$wpdb->query("CREATE TABLE $table LIKE $source");
function old_schema(): void {
    global $wpdb,$source,$table;
    $wpdb->query("DROP TABLE IF EXISTS $table");
    $wpdb->query("CREATE TABLE $table LIKE $source");
    $wpdb->query("ALTER TABLE $table DROP INDEX origem_periodo, DROP COLUMN versao_origem");
}
function digest_rows(): string {
    global $wpdb,$table;
    $columns=array_values(array_diff($wpdb->get_col("SHOW COLUMNS FROM $table"),['versao_origem']));
    return hash('sha256',wp_json_encode($wpdb->get_results('SELECT `'.implode('`,`',$columns)."` FROM $table ORDER BY amostra",ARRAY_A)));
}
function write_vital(string $id,float $value,?string $origin,int $seq=1,string $traffic='nao_marcado',string $automation='nao_identificada'): bool {
    $sample=['id'=>$id,'dispositivo'=>'movel','sequencia'=>$seq];
    if($origin!==null){$sample['versao_origem']=$origin;}
    return F3Base_Vitais::gravar(wp_date('Y-m-d'),'/origem/',['detalhe'=>'LCP','soma'=>$value,'amostra'=>$sample],$traffic,['automacao'=>$automation]);
}
function query_origin(?string $origin,array $extra=[]): array {
    $filters=['metrica'=>'LCP','caminho'=>'/origem/'];
    if($origin!==null){$filters['versao_origem']=$origin;}
    return F3Base_Vitais::consultar($extra+$filters);
}
try {
    old_schema();
    $rows=[];
    for($i=0;$i<993;$i++){
        $rows[]=$wpdb->prepare('(%s,%s,%s,%s,%s,%d,%f,%s)',hash('sha256','legacy-'.$i),'2020-01-01','/historico/',
            ['LCP','INP','CLS','TTFB'][$i%4],'movel',1+$i%3,$i/10,'nao_identificada');
    }
    check($wpdb->query("INSERT INTO $table (amostra,dia,caminho,metrica,dispositivo,sequencia,valor,automacao) VALUES ".implode(',',$rows))===993,'semente_993_linhas_sinteticas');
    $before=digest_rows();$sql=[];
    $observe=static function($query)use(&$sql,$table){if(str_contains($query,$table)){$sql[]=$query;}return $query;};
    add_filter('query',$observe);
    check(F3Base_Vitais::instalar_estrutura(),'migracao_aditiva_conclui');
    remove_filter('query',$observe);
    check(count(array_filter($sql,static fn($q)=>str_starts_with($q,'ALTER TABLE')))===1,'coluna_e_indice_em_um_alter');
    check(!array_filter($sql,static fn($q)=>preg_match('/^(SELECT|UPDATE|DELETE|REPLACE|INSERT)\b/i',$q)),'migracao_sem_varrer_ou_alterar_amostras');
    check(digest_rows()===$before&&(int)$wpdb->get_var("SELECT COUNT(*) FROM $table")===993,'preserva_todos_os_campos_e_linhas_vencidas');
    check((int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE versao_origem='' ")===993,'legado_recebe_origem_desconhecida');
    set_transient('f3base_vitais_limpeza',true,3600);$sql=[];add_filter('query',$observe);
    check(F3Base_Vitais::instalar_estrutura(),'repeticao_conclui');remove_filter('query',$observe);
    check(!array_filter($sql,static fn($q)=>str_starts_with($q,'ALTER TABLE'))&&digest_rows()===$before,'repeticao_sem_ddl_com_poda_suspensa');
    old_schema();
    $fail=static fn($q)=>str_starts_with(str_replace('`','',$q),'ALTER TABLE '.$table)?'SELECT coluna_inexistente_qa FROM '.$table:$q;
    $wpdb->suppress_errors(true);add_filter('query',$fail);
    check(!F3Base_Vitais::instalar_estrutura()&&F3Base_Vitais::falha_estrutura()==='vitais_ddl_nao_confirmado','falha_ddl_nao_confirma_estrutura');
    remove_filter('query',$fail);$wpdb->suppress_errors(false);
    check(F3Base_Vitais::instalar_estrutura(),'retomada_apos_falha_ddl');
    $wpdb->query("ALTER TABLE $table DROP INDEX origem_periodo");$sql=[];add_filter('query',$observe);
    check(F3Base_Vitais::instalar_estrutura(),'retoma_indice_ausente');remove_filter('query',$observe);
    $alters=array_values(array_filter($sql,static fn($q)=>str_starts_with($q,'ALTER TABLE')));
    check(count($alters)===1&&!str_contains($alters[0],'ADD COLUMN'),'indice_ausente_sem_recriar_coluna');
    $wpdb->query("ALTER TABLE $table MODIFY versao_origem varchar(13) NOT NULL DEFAULT ''");
    check(!F3Base_Vitais::instalar_estrutura()&&F3Base_Vitais::falha_estrutura()==='vitais_coluna_origem_incompativel','recusa_coluna_homonima_incompativel');
    $wpdb->query("ALTER TABLE $table MODIFY versao_origem varchar(14) NOT NULL DEFAULT '', DROP INDEX origem_periodo, ADD INDEX origem_periodo (dia,versao_origem,metrica)");
    check(!F3Base_Vitais::instalar_estrutura()&&F3Base_Vitais::falha_estrutura()==='vitais_indice_origem_incompativel','recusa_indice_em_ordem_errada');
    $wpdb->query("ALTER TABLE $table DROP INDEX origem_periodo");check(F3Base_Vitais::instalar_estrutura(),'repara_fixture_de_indice');
    $wpdb->query("ALTER TABLE $table DROP PRIMARY KEY");
    check(!F3Base_Vitais::instalar_estrutura()&&F3Base_Vitais::falha_estrutura()==='vitais_base_incompativel','recusa_base_sem_chave_primaria');
    $wpdb->query("ALTER TABLE $table ADD PRIMARY KEY (amostra)");
    $sample=['id'=>'valid000','dispositivo'=>'movel','sequencia'=>1];
    foreach(['0.0.0','1.72.0','1.72.1','9999.9999.9999'] as $v){check(F3Base_Vitais::amostra_valida($sample+['versao_origem'=>$v],'LCP'),'versao_valida_'.$v);}
    foreach(['','sem_versao','01.72.0','1.2','1.2.3.4','1.2.3-beta','10000.1.1',"1.2.3\n",'https://exemplo.test',123,null] as $i=>$v){
        check(!F3Base_Vitais::amostra_valida($sample+['versao_origem'=>$v],'LCP'),'versao_invalida_'.$i);
    }
    check(F3Base_Vitais::amostra_valida($sample,'LCP'),'versao_opcional');
    foreach([100,200,300,400] as $i=>$value){check(write_vital('new0000'.$i,$value,'1.72.1'),'grava_nova_'.$i);}
    write_vital('old00001',900,'1.72.0');write_vital('old00002',1000,'1.72.0');write_vital('unknown1',77,null);
    write_vital('robot001',9999,'1.72.1',1,'nao_marcado','declarada');write_vital('test0001',7777,'1.72.1',1,'teste');
    $q=query_origin('1.72.1');$r=$q['linhas'][0];
    check($q['ok']&&$q['versao_origem']==='1.72.1'&&$r['amostras']===4&&$r['p75']===300.0&&$r['excluidas_automacao']===1,'filtro_p75_denominador_e_exclusoes');
    check(query_origin('1.72.0')['linhas'][0]['p75']===1000.0,'origem_anterior_isolada');
    check(query_origin('sem_versao')['linhas'][0]['p75']===77.0,'origem_desconhecida_isolada');
    check(query_origin(null)['linhas'][0]['amostras']===7&&query_origin(null)['versao_origem']===null,'filtro_omitido_inclui_todas');
    check(query_origin('1.72.1',['segmento'=>'somente_testes'])['linhas'][0]['p75']===7777.0,'segmento_de_testes_independente');
    check(query_origin('1.72.1',['automacao'=>'todas'])['linhas'][0]['amostras']===5,'automacao_todas_conserva_origem');
    check(query_origin('1.72.1',['dispositivo'=>'desktop'])['linhas']===[],'filtro_dispositivo');
    check(query_origin('1.72.1',['somente_resumo'=>true])['linhas'][0]['p75']===$r['p75'],'resumo_e_detalhe_mesmo_percentil');
    check(!query_origin('1.72')['ok']&&!query_origin('1.72.1<script>')['ok'],'consulta_recusa_filtro_invalido');
    write_vital('conflict1',10,'1.72.0');write_vital('conflict1',30,'1.72.0',3);write_vital('conflict1',999,'1.72.1',2);write_vital('conflict1',888,'1.72.0',1);
    $id=hash('sha256','/origem/|LCP|conflict1');$r=$wpdb->get_row($wpdb->prepare("SELECT sequencia,valor,versao_origem FROM $table WHERE amostra=%s",$id),ARRAY_A);
    check((int)$r['sequencia']===3&&(float)$r['valor']===30.0&&$r['versao_origem']==='','conflito_antigo_apaga_origem_sem_regredir_valor');
    write_vital('conflict1',40,'1.72.0',4);$r=$wpdb->get_row($wpdb->prepare("SELECT valor,versao_origem FROM $table WHERE amostra=%s",$id),ARRAY_A);
    check((float)$r['valor']===40.0&&$r['versao_origem']==='','origem_desconhecida_irreversivel');
    write_vital('missing1',10,'1.72.1');write_vital('missing1',10,null);
    check(query_origin('sem_versao')['linhas'][0]['amostras']===3,'reenvio_sem_origem_tambem_conflita');
    wp_set_current_user(0);check(F3Base_Vitais::consultar()['codigo']==='sem_permissao','leitura_anonima_recusada');wp_set_current_user(1);
    $php=getenv('F3BASE_PHP')?:PHP_BINARY;$workers=[];$start=(string)(microtime(true)+1);
    foreach([1,2] as $i){$pipes=[];$process=proc_open([$php,__FILE__,'worker',(string)$i,$start],[1=>['pipe','w'],2=>['pipe','w']],$pipes);$workers[]=[$process,$pipes];}
    foreach($workers as $i=>[$process,$pipes]){$output=stream_get_contents($pipes[1]);$error=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$status=proc_close($process);check($status===0&&$output==='ok','processo_concorrente_'.$i);if($error){throw new RuntimeException($error);}}
    $id=hash('sha256','/race/|LCP|race1720');$r=$wpdb->get_row($wpdb->prepare("SELECT sequencia,valor,versao_origem FROM $table WHERE amostra=%s",$id),ARRAY_A);
    check((int)$r['sequencia']===30&&(float)$r['valor']===300.0&&$r['versao_origem']==='','concorrencia_preserva_maior_sequencia_e_conflito');
    evidence('vitais-1720',['historico_sintetico'=>993,'checksum_antes_depois'=>$before,'processos_concorrentes'=>2]);
} finally {
    $wpdb->query("DROP TABLE IF EXISTS $table");
}
