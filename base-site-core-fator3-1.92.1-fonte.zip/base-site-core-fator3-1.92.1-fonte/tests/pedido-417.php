<?php
/** Exercita a atualização com perfis observados na base anterior em um WP descartável. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || DB_NAME !== 'core1892_417') {
    throw new RuntimeException('Este ensaio exige o banco local core1892_417.');
}
$antes = F3BASE_PLUGIN_VERSAO === '1.89.1';
if (!$antes && F3BASE_PLUGIN_VERSAO !== '1.89.2') { throw new RuntimeException('Versão inesperada.'); }
$arquivo = fopen(__DIR__ . '/../reference/417/fichas-pesquisadas.csv', 'rb');
$campos = fgetcsv($arquivo, null, ',', '"', '');
$hashes = [];
foreach (range(1, 12) as $i) {
    $esperado = array_combine($campos, fgetcsv($arquivo, null, ',', '"', ''));
    $codigo = $esperado['codigo'];
    $chave = md5('pedido417:' . $codigo);
    $perfil = F3Base_Perfil_Aparelho::normalizar(['modelo'=>$codigo], 'Android', []);
    if ($antes) {
        if (($perfil['nome_comercial'] ?? '') === $esperado['nome_comercial']
            || !F3Base_Perfil_Aparelho::gravar('teste', $chave, $chave, time(), $perfil)) {
            throw new RuntimeException('Falha ao reproduzir a base: ' . $codigo);
        }
    } else {
        foreach (F3Base_Catalogo_Aparelhos::CAMPOS as $campo) {
            if (($perfil[$campo] ?? null) !== $esperado[$campo]) { throw new RuntimeException("$codigo / $campo"); }
        }
        if ($perfil['faixa_aparelho'] !== $esperado['faixa_sugerida']) { throw new RuntimeException($codigo); }
    }
    $salvo = F3Base_Perfil_Aparelho::ler(['classe'=>'teste','sessao'=>$chave,'visitante'=>$chave]);
    if (!$salvo) { throw new RuntimeException('Perfil ausente: ' . $codigo); }
    $hashes[$codigo] = hash('sha256', wp_json_encode($salvo));
    if (!$antes) {
        $vista = F3Base_Perfil_Aparelho::para_relatorio($salvo);
        $nome = $salvo['nome_comercial'] ?? $esperado['nome_comercial'];
        if ($vista['nome_comercial'] !== $nome) { throw new RuntimeException('Leitura histórica: ' . $codigo); }
    }
}
fclose($arquivo);
$cursor = '';
$itens = [];
$examinados = 0;
$paginas = 0;
do {
    $r = wp_get_ability('f3base/aparelhos-sem-nome-ler')->execute(['limite'=>4,'apos'=>$cursor]);
    if (is_wp_error($r) || empty($r['ok']) || ++$paginas > 5) { throw new RuntimeException('Falha de paginação.'); }
    array_push($itens, ...array_column($r['itens'],'codigo'));
    $examinados += $r['codigos_examinados'];
    $cursor = $r['proximo_apos'];
} while ($cursor !== null);
if ($examinados !== 12 || $itens !== ($antes ? ['moto g(8) power lite'] : [])) {
    throw new RuntimeException('Resultado divergente da consulta paginada.');
}
echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'versao'=>F3BASE_PLUGIN_VERSAO,
    'codigos_examinados'=>$examinados,'paginas'=>$paginas,'itens'=>$itens,'proximo_apos'=>$cursor,
    'hash_observacoes'=>hash('sha256',wp_json_encode($hashes))],JSON_PRETTY_PRINT);
