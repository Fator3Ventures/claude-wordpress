<?php
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local' || DB_NAME !== 'core189upgrade') { throw new RuntimeException('Laboratório obrigatório.'); }
wp_set_current_user(0);
$saida = [];
foreach (['f3base/aparelhos-sem-nome-ler'=>['limite'=>5], 'f3base/sessao-detalhar'=>['sessao'=>md5('pedido414:moto e6s')]] as $nome => $entrada) {
  $operacao = wp_get_ability($nome);
  $r = $operacao->check_permissions($entrada);
  if($r===true) {throw new RuntimeException($nome.' autorizada a visitante.');}
  $saida[$nome]=is_wp_error($r)?$r->get_error_code():'negado';
}
echo wp_json_encode(['usuario'=>'visitante sem login','operacoes'=>$saida]);
