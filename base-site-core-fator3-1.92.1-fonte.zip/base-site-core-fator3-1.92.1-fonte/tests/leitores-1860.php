<?php
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type()!=='local') {throw new RuntimeException('Laboratório obrigatório');}
wp_set_current_user(1);
$g=F3Base_Google_Acervo::status();
$m=F3Base_Meta_Ads::status();
$l=F3Base_Linkedin_Cliente::estado();
$contratos=\Fator3\LinkedIn\PublicApi::capabilities()['contracts'];
$resultado=['google'=>array_intersect_key($g,array_flip(['ok','contrato','registrado'])),
    'meta'=>array_intersect_key($m,array_flip(['ok','codigo','contrato'])),
    'linkedin'=>['contrato'=>$l['contrato'],'oferecido'=>in_array($l['contrato'],$contratos,true),'selecionado'=>$l['selecionado']]];
if (empty($g['registrado']) || empty($m['ok']) || !$resultado['linkedin']['oferecido']) {throw new RuntimeException('Contrato local indisponível');}
echo wp_json_encode($resultado,JSON_PRETTY_PRINT);
