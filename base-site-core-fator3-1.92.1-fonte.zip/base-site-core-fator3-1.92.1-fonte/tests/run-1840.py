"""Run the 1.84.0 tests in a NEW disposable WordPress/MySQL laboratory (F3BASE_PHASE=fresh|upgrade; --recriar recreates it).

The companion shell runner starts an empty, disposable MySQL server on loopback.
Each phase creates a new database and a fresh WordPress configuration.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, secrets, shutil, socket, subprocess, tarfile, time

ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--wordpress-archive',type=Path,required=True)
    p.add_argument('--base',choices=['1.83.0'],default='1.83.0')
    p.add_argument('--lab',type=Path,required=True)
    p.add_argument('--php',default=os.environ.get('F3BASE_PHP','php'))
    p.add_argument('--db-library-dir',type=Path)
    p.add_argument('--recriar',action='store_true',help='apaga o diretório do laboratório (só com o marcador LOCAL_TEST_LAB) e o banco da fase antes de começar')
    args=p.parse_args();lab=args.lab.resolve()
    port=int(os.environ.get('F3BASE_LAB_PORT',33575))
    phase=os.environ.get('F3BASE_PHASE','fresh')
    if phase not in {'fresh','upgrade'}:raise ValueError('Use F3BASE_PHASE=fresh or upgrade')
    if args.recriar:
        if lab.exists():
            if not (lab/'LOCAL_TEST_LAB').is_file():raise RuntimeError('--recriar recusado: o diretorio existe e nao tem o marcador LOCAL_TEST_LAB')
            shutil.rmtree(lab)
        dbname='core_1840_'+phase
        if not re.fullmatch(r'core_1840_(fresh|upgrade)',dbname):raise RuntimeError('nome de banco inesperado')
        subprocess.run(['mysql','--protocol=TCP','-h127.0.0.1','-P'+str(port),'-uroot','-e','DROP DATABASE IF EXISTS '+dbname],check=True)
    if lab.exists() and any(lab.iterdir()):raise RuntimeError('Use a new empty --lab directory')
    lab.mkdir(parents=True,exist_ok=True);(lab/'LOCAL_TEST_LAB').write_text('core1840 native tests\n')
    env=os.environ.copy();env['F3BASE_QA_PASSWORD']=secrets.token_urlsafe(32)
    if args.db_library_dir:env['LD_LIBRARY_PATH']=str(args.db_library_dir)+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    logs=lab/'logs';logs.mkdir()
    results=[]
    def prepare(phase,runtime):
        site=lab/phase;site.mkdir()
        import zipfile
        with zipfile.ZipFile(args.wordpress_archive) as archive:
            assert all(n.startswith('wordpress/') and '..' not in Path(n).parts for n in archive.namelist())
            archive.extractall(site)
        wp=site/'wordpress'
        text=(wp/'wp-includes/version.php').read_text()
        if not re.search(r"\$wp_version\s*=\s*'7\.1\.4'",text):raise RuntimeError('This reconstruction requires WordPress 7.1.4')
        dest=wp/'wp-content/plugins/base-site-core-fator3';shutil.copytree(runtime,dest)
        mu=wp/'wp-content/mu-plugins';mu.mkdir(exist_ok=True)
        (mu/'000-qa-no-network.php').write_text("<?php\nadd_filter('pre_http_request',static fn($pre)=>$pre !== false ? $pre : new WP_Error('qa_network_blocked','Local test'),PHP_INT_MAX);\nadd_filter('pre_wp_mail',static fn()=>true,PHP_INT_MAX);\n")
        theme=wp/'wp-content/themes/core-qa';theme.mkdir()
        (theme/'style.css').write_text('/*\nTheme Name: Core QA\nVersion: 1.0\n*/\n')
        (theme/'index.php').write_text('<?php wp_head(); ?><main>Core QA</main><?php wp_footer(); ?>')
        name='core_1840_'+phase
        cfg="<?php\n"+''.join("define("+repr(k)+","+repr(v)+");\n" for k,v in {
            'DB_NAME':name,'DB_USER':'root','DB_PASSWORD':'','DB_HOST':'127.0.0.1:'+str(port),
            'DB_CHARSET':'utf8mb4','DB_COLLATE':'','WP_ENVIRONMENT_TYPE':'local',
            'WP_HOME':'http://127.0.0.1:8137','WP_SITEURL':'http://127.0.0.1:8137','FS_METHOD':'direct'}.items())
        cfg+="$table_prefix='wp_';define('DISABLE_WP_CRON',true);define('WP_DEBUG',true);define('WP_DEBUG_DISPLAY',false);define('WP_DEBUG_LOG',true);\n"
        for k in ('AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'):cfg+=f"define('{k}','{secrets.token_hex(32)}');\n"
        cfg+="if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';\n"
        (wp/'wp-config.php').write_text(cfg);(wp/'wp-config.php').chmod(0o600)
        return wp,name
    def run(wp,name,script,*modes,base='tests',timeout=300):
        e=env.copy();e.update(F3BASE_BASE=args.base,F3BASE_ALLOW_LOCAL_TESTS='1',F3BASE_SITE=str(wp/'wp-load.php'),
            F3BASE_PHP=args.php,F3BASE_LAB_DB=name,F3BASE_DB_HOST='127.0.0.1:'+str(port),F3BASE_TEST_PHASE=wp.parent.name,F3BASE_HOST='127.0.0.1:8137')
        r=subprocess.run([args.php,str(ROOT/base/script),*modes],env=e,capture_output=True,text=True,timeout=timeout)
        item={'phase':wp.parent.name,'test':script,'mode':list(modes),'exit_code':r.returncode,'stdout':r.stdout.strip()}
        results.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
        if r.returncode:raise RuntimeError(r.stderr[-4000:])
    runtime=ROOT/'work/plugin/base-site-core-fator3'
    wp,name=prepare(phase,runtime if phase=='fresh' else ROOT/('history/'+args.base+'-runtime/base-site-core-fator3'))
    run(wp,name,'ciclo-1840.php','install')
    if phase=='upgrade':
        run(wp,name,'ciclo-1840.php','seed')
        dest=wp/'wp-content/plugins/base-site-core-fator3'
        shutil.rmtree(dest)
        shutil.copytree(runtime,dest)
        run(wp,name,'ciclo-1840.php','migrate')
    run(wp,name,'ordem-1840.php')
    run(wp,name,'396-397.php')
    run(wp,name,'398-399.php')
    run(wp,name,'origem-1840.php')
    run(wp,name,'correcoes-1840.php')
    run(wp,name,'pedidos-1840.php')
    run(wp,name,'regressao-1780-em-1840.php')
    run(wp,name,'regressao-1770-em-1840.php')
    run(wp,name,'regressao-1760-em-1840.php')
    run(wp,name,'fumaca-abilities-1840.php')
    run(wp,name,'gerar-referencia-abilities.php','--check',base='build')
    run(wp,name,'gerar-catalogo-abilities.php','--check',base='build')
    run(wp,name,'ciclo-1840.php','uninstall')
    run(wp,name,'ciclo-1840.php','reactivate')
if __name__=='__main__':main()
