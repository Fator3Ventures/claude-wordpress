<?php
/** Verifica os dois recibos requeridos pelo leitor de e-mail com um transporte local determinístico. */
declare(strict_types=1);
define('ABSPATH',__DIR__.'/');
function wp_json_encode($v) { return json_encode($v,JSON_THROW_ON_ERROR); }
final class F3Base_Pipedrive_Api {
    public static string $vinculo='lead-teste';
    public static array $leituras=[];
    public static function pedir(string $method,string $path,array $params=[]): array {
        self::$leituras[]=$path;
        if ($method!=='GET') { throw new RuntimeException('Método inesperado'); }
        return match ($path) {
            'v1/persons/7/mailMessages'=>['ok'=>true,'data'=>[['mua_message_id'=>'<teste@local.invalid>','mail_thread_id'=>88,'id'=>123,
                'from'=>[['email_address'=>'origem@local.invalid']],'to'=>[['email_address'=>'destino@local.invalid','linked_person_id'=>7]]]],
                'additional_data'=>['pagination'=>['more_items_in_collection'=>false]]],
            'v1/mailbox/mailThreads/88'=>['ok'=>true,'data'=>['lead_id'=>self::$vinculo]],
            default=>throw new RuntimeException('Rota inesperada')
        };
    }
}
$inc=dirname(__DIR__).'/work/plugin/base-site-core-fator3/includes/';
require $inc.'class-f3base-json-campo.php';
require $inc.'class-f3base-email-historico.php';
$envio=['message'=>['message_id'=>'<teste@local.invalid>','historico_contexto'=>['remetente'=>'origem@local.invalid',
            'destinatario'=>'destino@local.invalid','iniciado_em'=>time(),'revisao'=>1,
            'politica'=>['ativo'=>true,'janela_horas'=>48,'intervalo_minutos'=>60]]],'person_id'=>7];
$row=['conta'=>'fixture','lead_id'=>'lead-teste','enviado_em'=>time(),'historico'=>null];
$confirmado=F3Base_Email_Historico::conferir($row,$envio);
F3Base_Pipedrive_Api::$vinculo='outro-lead';
$divergente=F3Base_Email_Historico::conferir($row,$envio);
if ($confirmado['estado']!=='confirmado'||$divergente['estado']==='confirmado'||count(F3Base_Pipedrive_Api::$leituras)!==4) {exit(1);}
echo json_encode(['confirmacao'=>$confirmado['estado'],'vinculo_divergente'=>$divergente['estado'],'leituras'=>4,'transporte'=>'fixture'],JSON_PRETTY_PRINT);
