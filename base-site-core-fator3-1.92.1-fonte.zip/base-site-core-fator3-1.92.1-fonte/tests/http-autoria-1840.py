"""Check an anonymous Yoast response in the disposable core_1780 lab."""
import hashlib,json,re,sys,urllib.request
from html import unescape
from pathlib import Path
mode=sys.argv[1]
with urllib.request.urlopen('http://127.0.0.1:8137/homologacao-178/',timeout=18) as res:
    raw=res.read();status=res.status
html=raw.decode()
scripts=re.findall(r'<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',html,re.I|re.S)
graph=[node for script in scripts for node in json.loads(unescape(script)).get('@graph',[])]
types=lambda n: n.get('@type') if isinstance(n.get('@type'), list) else [n.get('@type')]
main=[n for n in graph if set(types(n)) & {'WebPage','Article','BlogPosting','NewsArticle'}]
auth=[n.get('author',{}) for n in main]
byid={n.get('@id'):n for n in graph};resolved=[byid.get(a.get('@id'),a) for a in auth if isinstance(a,dict)]
checks={'http_200':status==200,'conteudo':'Trecho público verificável' in html,'login_ausente':'qa_admin' not in html,'artigo_e_webpage':len(main)>=2 and any('WebPage' in types(n) for n in main),'autoria_coerente':len(auth)>=2 and all(a and a==auth[0] for a in auth),'autoria_esperada':bool(resolved) and all(n.get('name')=='Editora de Homologação' if mode=='ativo' else 'Organization' in types(n) for n in resolved)}
print(mode,checks,[(n.get('@type'),n.get('author')) for n in main],flush=True)
if not all(checks.values()):sys.exit(1)
out=Path(__file__).resolve().parents[1]/'evidence/1840'/('yoast-http-'+mode+'.json');out.write_text(json.dumps({'checks':checks,'http':status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'tipos':[n.get('@type') for n in main]},indent=2)+'\n')
