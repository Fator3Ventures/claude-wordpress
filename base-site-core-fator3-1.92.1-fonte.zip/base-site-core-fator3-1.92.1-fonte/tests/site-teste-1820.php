<?php
/** Bancada temporária; o empacotador de QA incorpora somente as duas funções de fixtures. */
defined('ABSPATH') || exit;
add_action('wp_abilities_api_init',static function(){
    wp_register_ability('f3qa/core-1820',[
        'label'=>'Homologação do Site Core 1.82.0','description'=>'Verifica os contratos sintéticos e a sonda do Site-Teste.',
        'category'=>'site','input_schema'=>['type'=>'object','additionalProperties'=>false,'properties'=>['caso'=>['type'=>'string','enum'=>['canais','cron']]],'required'=>['caso']],
        'output_schema'=>['type'=>'object','additionalProperties'=>true],'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'show_in_rest'=>false],
        'permission_callback'=>static fn()=>current_user_can('manage_options') && current_user_can('f3base_ler_leads') && F3BASE_PLUGIN_VERSAO==='1.82.0' && wp_parse_url(home_url(),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com',
        'execute_callback'=>static function($args){
            if($args['caso']==='cron'){
                $old=$_SERVER;unset($_SERVER['HTTPS']);$_SERVER['SERVER_PORT']='80';
                try{$ssl=is_ssl();$v=F3Base_Servidor::reverificar();$s=F3Base_Servidor::consultar();return ['ok'=>!empty($v['prova_ok']),'ssl_no_executor'=>$ssl,'status'=>$s['status'],'listagem'=>$s['ultima_operacao']['listagem']??[]];}finally{$_SERVER=$old;}
            }
            global $wpdb,$wp_object_cache;
            if(wp_using_ext_object_cache()){return ['ok'=>false,'codigo'=>'cache_persistente_exige_isolamento'];}
            $prefix=$wpdb->prefix;$temp='f3qa181_'.bin2hex(random_bytes(6)).'_';$tables=[];
            $db=$wpdb;$cache=$wp_object_cache;$hooks=$GLOBALS['wp_filter'];$checks=[];
            $assert=static function($ok,$name)use(&$checks){$checks[$name]=(bool)$ok;if(!$ok){throw new RuntimeException('Falhou: '.$name);}};
            try{
                $wpdb=new wpdb(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);$wpdb->set_prefix($temp);
                foreach(['options','f3base_avisos_partes','f3base_leads_janelas','f3base_leads'] as $suffix){
                    if($wpdb->query($wpdb->prepare('CREATE TEMPORARY TABLE %i LIKE %i',$temp.$suffix,$prefix.$suffix))===false){throw new RuntimeException('tabela_temporaria_indisponivel');}$tables[]=$temp.$suffix;
                }
                wp_cache_init();
                foreach(['pre_http_request','updated_option','added_option','deleted_option','update_option','add_option','delete_option','pre_wp_mail'] as $hook){unset($GLOBALS['wp_filter'][$hook]);}
                add_filter('pre_http_request',static fn($pre)=>$pre!==false?$pre:new WP_Error('http_externo_bloqueado'),PHP_INT_MAX);
                add_filter('pre_wp_mail','__return_true',PHP_INT_MAX);
                add_filter('pre_option_home',static fn()=>'https://fixture.example');add_filter('pre_option_siteurl',static fn()=>'https://fixture.example');
                $f=f3qa181_projecoes($assert);f3qa181_transportes($f,$assert);
                $cases=[
    ['email','email',['utm_source'=>'google','utm_medium'=>'cpc'],'Recebido por e-mail'],
    ['formulario','meta',[],'Formulário Meta · Meta Ads'],
    ['anuncio_linkedin','linkedin',[],'Formulário LinkedIn · LinkedIn Ads'],
    ['formulario','',[],'Formulário Site · Orgânico'],
    ['formulario','',['utm_source'=>'google','utm_medium'=>'organic'],'Formulário Site · Orgânico'],
    ['formulario','',['utm_source'=>'Newsletter','utm_campaign'=>'rodada'],'Formulário Site · Newsletter'],
    ['whatsapp_cta','',['utm_source'=>'google','utm_medium'=>'cpc'],'Clique para WhatsApp · Google Ads'],
    ['formulario','',['utm_source'=>'instagram','utm_campaign'=>'verao'],'Formulário Site · Meta Ads'],
];
foreach (['gclid'=>'Google Ads','wbraid'=>'Google Ads','gbraid'=>'Google Ads','fbclid'=>'Meta Ads','li_fat_id'=>'LinkedIn Ads'] as $k=>$label) {
    $cases[]=['whatsapp_cta','',[$k=>'id-privado'],'Clique para WhatsApp · '.$label];
}
foreach ($cases as $i=>[$method,$native,$raw,$label]) {
    $a=$f['google']['a'];$a['origem_nativa']=$native?['origem'=>$native]:[];$a['metodo']=$method;$a['teste']=$i%2===1;
    $a['atribuicao']=F3Base_Contato_Apresentacao::atribuicao(F3Base_Atribuicao::normalizar($raw),true);
    $messages=F3Base_Slack_Thread::mensagens($a);
    $expect=($a['teste']?'[TESTE] ':'').$a['site'].' · '.$label;
    $assert($messages[0]['blocks'][0]['text']['text']===$expect && explode("\n",$messages[0]['text'])[0]===$expect && !str_contains($messages[0]['text'],'id-privado'),'395_primeira_linha_'.$i,$messages[0]['text']);
}

                return ['ok'=>true,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'checks'=>$checks,'http'=>'interceptado','tabelas'=>'temporarias_na_conexao'];
            } catch(Throwable $e){return ['ok'=>false,'codigo'=>$e->getMessage(),'checks'=>$checks];}
            finally{foreach($tables as $table){$wpdb->query($wpdb->prepare('DROP TEMPORARY TABLE IF EXISTS %i',$table));}$wpdb=$db;$wp_object_cache=$cache;$GLOBALS['wp_filter']=$hooks;}
        }
    ]);
});
