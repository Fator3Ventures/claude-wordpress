<?php
require __DIR__.'/bootstrap-1851.php';
global $wpdb;
wp_set_current_user(0);
$base=['modelo'=>'SM-A065M','versao_sistema'=>'14','memoria_gb'=>4,'nucleos'=>8,'largura'=>390,'altura'=>844,'dpr'=>3,'rede'=>'4g'];
$ref=['classe'=>'teste','sessao'=>bin2hex(random_bytes(16)),'visitante'=>bin2hex(random_bytes(16))];
$p=F3Base_Perfil_Aparelho::normalizar($base,'Android',['SM-A065M=entrada']);
check($p['modelo']==='SM-A065M'&&$p['faixa_aparelho']==='entrada'&&$p['faixa_fonte']==='catalogo'&&$p['tela']==='390×844 @3x','catalogo_e_sinais');
check(F3Base_Perfil_Aparelho::normalizar($base,'Android',[])['faixa_aparelho']==='desconhecido','modelo_sem_catalogo');
check(F3Base_Perfil_Aparelho::normalizar(['modelo'=>'']+$base,'Android',[])['faixa_aparelho']==='intermediário','estimativa_capacidade');
$iphone=F3Base_Perfil_Aparelho::normalizar(['versao_sistema'=>'']+$base,'iPhone OS 18_2',[]);
check($iphone['modelo']===''&&$iphone['faixa_fonte']==='estimativa_tela_iphone'&&$iphone['versao_sistema']==='18','iphone_sem_modelo');
check(!F3Base_Perfil_Aparelho::normalizar($base+['ip'=>'127.0.0.1'],'',[]),'esquema_fechado');
check(!F3Base_Perfil_Aparelho::validar_catalogo(['Foo=entrada','foo=topo']),'duplicata_rejeitada');
$all=F3Base_Cache_Pagina::parametros_rastreio();
check(count($all)===47&&count(array_unique($all))===47&&!in_array('ref',$all,true),'47_distintos_sem_ref');
$url=home_url('/?gad_source=1&gad_campaignid=24432229853&msclkid=abc&_gl=privado&igshid=outro');
$attr=F3Base_Atribuicao::parametros_pagina($url);check($attr===['gad_source'=>'1','gad_campaignid'=>'24432229853','msclkid'=>'abc'],'captura_url_do_site');
foreach(F3Base_Atribuicao::CLIQUES as $k){
 $x=F3Base_Atribuicao::para_captura([$k=>'segredo','sessao_origem'=>[$k=>'segredo']],true,false);
 check(!isset($x[$k],$x['sessao_origem'][$k])&&!str_contains(wp_json_encode($x),'segredo'),'privacidade_'.$k);
 check(F3Base_Audiencia::canal([$k=>'id'])['canal']==='pago','canal_'.$k);
}
$t=F3Base_Perfil_Aparelho::tabela();
try {
 $now=time();$start=['classe'=>$ref['classe'],'sessao'=>$ref['sessao'],'visitante'=>$ref['visitante']];
 $event=['evento'=>bin2hex(random_bytes(16)),'navegacao'=>bin2hex(random_bytes(16)),'sessao'=>$ref['sessao'],'visitante'=>$ref['visitante'],'tipo'=>'pagina','dispositivo'=>'movel','criado_em'=>$now,'caminho'=>'/qa-aparelho/','contexto_teste'=>true];
 foreach([[],['tipo'=>'aparelho','perfil_aparelho'=>$base],['tipo'=>'vital','detalhe'=>'LCP','valor'=>311]] as $extra){
  $row=F3Base_Analise::validar(['evento'=>bin2hex(random_bytes(16))]+$extra+$event);check(empty($row['erro'])&&!empty(F3Base_Analise::persistir($row)['ok']),'evento_'.($extra['tipo']??'pagina'),$row['erro']??null);
 }
 $stored=F3Base_Perfil_Aparelho::ler($ref);
 check($stored['modelo']===$base['modelo'],'persistencia');
 F3Base_Perfil_Aparelho::gravar(...[...array_values($ref),$now,$iphone]);check(F3Base_Perfil_Aparelho::ler($ref)===$stored,'primeira_observacao_fixa');
 check(F3Base_Perfil_Aparelho::ler(['classe'=>'nao_marcado']+$ref)===[],'isolamento_classe');
 wp_set_current_user(1);
 $q=['de'=>wp_date('Y-m-d'),'ate'=>wp_date('Y-m-d'),'modelo'=>'SM-A065M','visao'=>'qualidade','segmento'=>'somente_testes','automacao'=>'todas'];
 $ed=F3Base_Editorial_Relatorios::consultar($q);
 check(!empty($ed['ok'])&&in_array('SM-A065M',array_column($ed['linhas']??[],'modelo'),true),'editorial_vital_por_modelo',$ed['codigo']??($ed['linhas']??null));
 $report=F3Base_Relatorios::consultar($q);check(!empty($report['ok'])&&str_contains(wp_json_encode($report),'SM-A065M'),'integrado_qualidade',$report['codigo']??null);
 wp_set_current_user(0);
 $_COOKIE[F3Base_Modulo_Consentimento::COOKIE]='granted';
 $contact=F3Base_Leads_Contexto::capturar(['sessao'=>$ref['sessao'],'visitante'=>$ref['visitante'],'contexto_teste'=>true,'perfil_aparelho'=>wp_json_encode($base),'atribuicao'=>$attr,'classificacao_contexto'=>'permitida'],true);
 check($contact['contexto']['perfil_aparelho_ref']===$ref&&!isset($contact['perfil_aparelho']),'contato_vinculado');
 $rid=bin2hex(random_bytes(16));
 $contact+=['record_id'=>$rid,'nome'=>'QA 396','pagina'=>$url,'metodo'=>'formulario','notificar'=>false];
 $receipt=F3Base_Leads_Repositorio::guardar($contact);
 check(!empty($receipt['ok']),'contato_real_gravado',$receipt['codigo']??null);
  $record=F3Base_Leads_Repositorio::obter($rid);
  check(($record['dados']['atribuicao']['gad_campaignid']??'')==='24432229853'&&($record['dados']['atribuicao']['msclkid']??'')==='abc','campanha_e_clique_no_contato',$contact['atribuicao_reducao']);
  wp_set_current_user(1);
  $reading=F3Base_Leads_Admin::ler(['record_id'=>$rid])['registro']??[];
  check(($reading['dados']['contexto']['perfil_aparelho']['modelo']??'')==='SM-A065M','ficha_real');
  $presentation=F3Base_Contato_Apresentacao::montar($record);
  check(str_contains(F3Base_Contato_Apresentacao::nota($presentation,'qa'),'SM-A065M'),'nota_do_registro');
  $oldState=get_option('f3base_pipedrive_estado',[]);
  $cfg=F3Base_Options::ler('f3base_pipedrive');
  $cfg['dominio']='fixture.pipedrive.com';$cfg['mapa_campos']=['modelo_aparelho'=>'qa_modelo'];
  $cfg['mapa_pessoa']=['faixa_aparelho'=>'qa_faixa'];
  $state=['dominio'=>$cfg['dominio'],'catalogos'=>['campos'=>[['field_code'=>'qa_modelo','field_type'=>'varchar']],'pessoa_campos'=>[['key'=>'qa_faixa','field_type'=>'varchar']]]];
  update_option('f3base_pipedrive_estado',$state,false);
  try {
   $crm=F3Base_Pipedrive_Fila::contexto($record);
   $leadFields=F3Base_Pipedrive_Fila::campos($crm,$cfg);
   $personFields=F3Base_Pipedrive_Comercial::whatsapp_pessoa($crm,$cfg);
   check(($leadFields['qa_modelo']??'')==='SM-A065M','mapeamento_lead');
   check(($personFields['qa_faixa']??'')===$stored['faixa_aparelho'],'mapeamento_pessoa');
  } finally {update_option('f3base_pipedrive_estado',$oldState,false);}
  wp_set_current_user(0);

 $denied=F3Base_Leads_Contexto::capturar(['sessao'=>$ref['sessao'],'visitante'=>$ref['visitante'],'perfil_aparelho'=>wp_json_encode($base)],false);
 check(!isset($denied['perfil_aparelho'],$denied['contexto']['perfil_aparelho_ref']),'contato_sem_medicao');
 $a=['secoes_comunicacao'=>[],'perfil_aparelho_ref'=>$ref,'atribuicao'=>[],'nome'=>'QA','historico'=>[],'respostas'=>[],'registro_url'=>'','metodo'=>'formulario','pagina'=>'','jornada'=>[]];
 $shown=F3Base_Perfil_Aparelho::apresentar($a);
 check(str_contains(F3Base_Contato_Apresentacao::nota($a,'qa'),'SM-A065M'),'nota_renderizada');
 check(str_contains(F3Base_Slack_Thread::com_perfil(['text'=>'Aviso','blocks'=>[]],$shown)['text'],'SM-A065M'),'aviso_renderizado');
 $wpdb->update($t,['observado_em'=>F3Base_Editorial::corte_retencao()-2],$start);check(!F3Base_Perfil_Aparelho::ler($ref),'expiracao_na_leitura');
 F3Base_Sessoes::reter();check(!$wpdb->get_var($wpdb->prepare('SELECT 1 FROM %i WHERE sessao=%s',$t,$ref['sessao'])),'remocao_fisica');
} finally {if(isset($rid)){check(F3Base_Leads_Repositorio::eliminar($rid,'teste'),'limpeza_do_contato');}$wpdb->delete(F3Base_Analise::tabela(),['sessao'=>$ref['sessao']]);$wpdb->delete(F3Base_Sessoes::tabela(),['sessao'=>$ref['sessao']]);$wpdb->delete($t,['sessao'=>$ref['sessao']]);}
evidence('396-397');
