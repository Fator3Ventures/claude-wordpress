from pathlib import Path
import os,subprocess,json,shutil,zipfile
from argparse import ArgumentParser
p=ArgumentParser(description="Roda os testes oficiais de origem e o worker do Core no WordPress descartável criado por run-1830.py.")
p.add_argument('--lab',type=Path,required=True,help='pasta da fase fresh com o subdiretório wordpress')
p.add_argument('--plugins',type=Path,required=True,help='cinco diretórios dos plugins atuais extraídos')
p.add_argument('--fontes',type=Path,required=True,help='fontes oficiais extraídos dos três provedores')
p.add_argument('--google-zip',type=Path,required=True)
p.add_argument('--php',required=True)
args=p.parse_args()
source=Path(__file__).resolve().parents[1]
root=args.lab.resolve();wp=root/'wordpress';ev=source/'evidence/1830'
here=root/'matriz-1830';here.mkdir()
assert (root.parent/'LOCAL_TEST_LAB').is_file() and "core_1830_" in (wp/'wp-config.php').read_text()
for slug in ['wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3','wp-mcp-pipedrive-fator3']:
    shutil.copytree(args.plugins/slug,wp/'wp-content/plugins'/slug)
(root/'.google-lab-owner.json').write_text(json.dumps({'id':'core1810','path':str(root)}));(root/'.social-lab.json').write_text('{"id":"core1810"}');(root/'evidence').mkdir(exist_ok=True)
mu=wp/'wp-content/mu-plugins/000-qa-no-network.php';mu.write_text("""<?php
define('F3_CORE_FRONTIER_021',true);
add_filter('pre_http_request',static fn($p)=>$p===false?new WP_Error('qa_network_blocked'):$p,PHP_INT_MAX);
add_filter('pre_wp_mail','__return_true',PHP_INT_MAX);
""")
env=os.environ.copy();env.update(F3BASE_ALLOW_LOCAL_TESTS='1',F3BASE_SITE=str(wp/'wp-load.php'),F3_LAB_ROOT=str(root),F3_FIXTURE_ROOT=str(root),F3_LAB_ID='core1810',F3_LAB_URL='http://127.0.0.1:8137',F3_EVIDENCE_DIR=str(ev),F3_CANDIDATE=str(args.google_zip.resolve()))
php=args.php
def run(name,args):
 r=subprocess.run([php,*args],env=env,capture_output=True,text=True)
 (here/('matrix-'+name+'.log')).write_text(r.stdout+r.stderr)
 print(name,r.returncode,flush=True)
 if r.returncode: raise RuntimeError(name+": "+r.stderr[-2000:])
 return r
run('activate',['-r',"""require getenv('F3BASE_SITE');wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';foreach(['wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3','wp-mcp-pipedrive-fator3'] as $slug){$r=activate_plugin($slug.'/'.$slug.'.php');if(is_wp_error($r)){throw new Exception($r->get_error_message());}}"""])
for p,name in [('meta','origin024'),('google','origin034'),('linkedin','ad-source021')]:
 src=next(args.fontes.rglob(name+'.php')).parent
 dst=here/('fixture-'+p);dst.mkdir(exist_ok=True)
 for f in src.glob('*.php'):shutil.copyfile(f,dst/f.name)
 target=dst/(name+'.php')
 test=target.read_text().replace("F3BASE_PLUGIN_VERSAO==='1.80.0'","F3BASE_PLUGIN_VERSAO==='1.83.0'")
 call=f"require {str((source/'tests/worker-origem-1830.php'))!r};"
 if p=='meta':test=test.replace('$hget=$core();',call+"$beforeWorker=$req;f3qa181_worker('meta','160','309','410');$req=$beforeWorker;$hget=$core();")
 if p=='linkedin':
  test=test.replace("$reader=setup17", "add_filter('option_home',static fn()=>'https://example.com',999);$reader=setup17")
  test=test.replace("$r=$reader->resolve_ad_source(array_replace($lead",call+"f3qa181_worker('linkedin','222','999','777');$r=$reader->resolve_ad_source(array_replace($lead")
 if p=='google':test=test.replace("$phase='cards';",call+"f3qa181_worker('google',$account,$campaign,$id);$phase='cards';")
 target.write_text(test)
 if p=='meta':
  f=dst/(name+'.php');s=f.read_text().replace("require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();","""require getenv('F3BASE_SITE');if(wp_get_environment_type()!=='local'||!str_starts_with(DB_NAME,'core_1830_')||!str_starts_with(DB_HOST,'127.0.0.1:'))throw new RuntimeException('isolated lab required');""");f.write_text(s)
 r=run(p,[str(dst/(name+'.php'))])
 if not r.returncode and p=='meta':(ev/'origin024.json').write_text(json.dumps(json.loads(r.stdout.strip().splitlines()[-1]),ensure_ascii=False,indent=2))
 if p=='linkedin' and (root/'evidence/ad-source021.json').exists():shutil.copyfile(root/'evidence/ad-source021.json',ev/'ad-source021.json')
