"""Auditoria da documentação instalada do Site Core.

Uso: python3 -I auditar-docs.py <runtime-do-plugin> <abilities.json> [saida.json]
<abilities.json> é a lista de nomes f3base/* registrados (exportada do WordPress do laboratório).
Mede: cobertura do índice, referências a arquivos inexistentes, abilities citadas que não existem,
abilities registradas sem menção em documento vigente e a versão declarada nos documentos de entrada.
Sai com código 0 sempre; quem decide aprovação é quem lê os números.
"""
import glob
import json
import os
import re
import sys
from collections import Counter

runtime, abil = sys.argv[1], sys.argv[2]
os.chdir(runtime)
reg = set(json.load(open(abil)))
versao = re.search(r'^\s*\*\s*Version:\s*([0-9.]+)', open('base-site-core-fator3.php', encoding='utf8').read(), re.M).group(1)
docs = sorted(glob.glob('docs/*.md'))
todos = set(os.path.relpath(os.path.join(d, f), '.') for d, _, fs in os.walk('.') for f in fs)
indice = open('docs/DOCUMENTACAO.md', encoding='utf8').read()

fora = [os.path.basename(d) for d in docs if os.path.basename(d) != 'DOCUMENTACAO.md' and os.path.basename(d) not in indice]

quebradas = {}
for d in docs + ['README.md']:
    t = open(d, encoding='utf8').read()
    for m in re.finditer(r'(?<![\w/.-])((?:docs|includes|admin|assets|dados)/[\w./-]+\.(?:md|json|php|js|css|sql|tsv))', t):
        if m.group(1) not in todos:
            quebradas.setdefault(d, set()).add(m.group(1))
    for m in re.finditer(r'\]\((?!https?:|#|mailto:)([^)\s]+)\)', t):
        alvo = os.path.normpath(os.path.join(os.path.dirname(d), m.group(1).split('#')[0]))
        if alvo not in todos:
            quebradas.setdefault(d, set()).add('link:' + m.group(1))

# Documento vigente: sem sufixo de versão no nome (AGENTES-1.78.0.md e GSC-1.34.md são datados).
vigentes = [d for d in docs if not re.search(r'-\d+\.\d+(\.\d+)?\.md$', d)]
fantasmas = {}
for d in vigentes:
    t = open(d, encoding='utf8').read()
    for a in set(re.findall(r'f3base/[a-z0-9]+(?:-[a-z0-9]+)*', t)):
        if a not in reg and a not in ('f3base/formulario', 'f3base/artigos') and not re.fullmatch(r'f3base/v\d+', a):  # blocos e namespace REST não são abilities
            fantasmas.setdefault(a, []).append(os.path.basename(d))
texto_vigente = ' '.join(open(d, encoding='utf8').read() for d in vigentes)
sem_doc = [a for a in sorted(reg) if a not in texto_vigente]

entrada = {}
for d in ('README.md', 'docs/README.md', 'docs/DOCUMENTACAO.md', 'docs/INSTRUCOES-DO-PLUGIN.md', 'docs/CONFIGURACAO.md',
          'docs/GUIA-PAINEL.md', 'docs/CONTRACTS.md', 'docs/CHANGELOG.md', 'docs/OPERACAO-E-RECUPERACAO.md', 'docs/VALIDACAO.md'):
    if os.path.exists(d):
        linhas = open(d, encoding='utf8').read().split('\n')
        cabeca = '\n'.join(linhas[:6])
        vs = re.findall(r'\b1\.\d{1,2}\.\d\b', cabeca)
        entrada[d] = {'primeira_linha': linhas[0][:90], 'versoes_nas_6_primeiras_linhas': vs, 'declara_versao_instalada': versao in vs}

r = {
    'versao_do_cabecalho': versao,
    'md_em_docs': len(docs),
    'md_fora_do_indice': len(fora), 'md_fora_do_indice_nomes': fora,
    'referencias_quebradas': sum(len(v) for v in quebradas.values()),
    'referencias_quebradas_por_documento': {k: sorted(v) for k, v in sorted(quebradas.items())},
    'documentos_vigentes': len(vigentes),
    'abilities_registradas': len(reg),
    'abilities_citadas_inexistentes': fantasmas,
    'abilities_sem_mencao_em_documento_vigente': len(sem_doc),
    'documentos_de_entrada': entrada,
    'documentos_de_entrada_sem_a_versao_instalada': [d for d, v in entrada.items() if not v['declara_versao_instalada']],
}
if len(sys.argv) > 3:
    json.dump(r, open(sys.argv[3], 'w'), ensure_ascii=False, indent=1)
resumo = {k: v for k, v in r.items() if k not in ('md_fora_do_indice_nomes', 'referencias_quebradas_por_documento', 'documentos_de_entrada')}
print(json.dumps(resumo, ensure_ascii=False, indent=1))
