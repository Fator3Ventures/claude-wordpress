<?php
/** Confere todos os registros do arquivo com o resolvedor público do pacote instalado. */
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local') {
    throw new RuntimeException('Laboratório local obrigatório.');
}
$arquivo = fopen(getenv('F3_QA_CATALOGO'), 'rb');
$campos = fgetcsv($arquivo, null, ',', '"', '');
if ($campos !== ['codigo', ...F3Base_Catalogo_Aparelhos::CAMPOS]) {
    throw new RuntimeException('Cabeçalho do catálogo divergente.');
}
$codigos = [];
while (($linha = fgetcsv($arquivo, null, ',', '"', '')) !== false) {
    $esperado = array_combine($campos, $linha);
    $codigo = $esperado['codigo'];
    unset($esperado['codigo']);
    if (isset($codigos[mb_strtolower($codigo)]) || (float)$esperado['preco_atual_estimado_brl'] <= 0) {
        throw new RuntimeException('Código duplicado ou preço inválido: ' . $codigo);
    }
    $obtido = F3Base_Catalogo_Aparelhos::resolver($codigo, []);
    if (array_intersect_key($obtido, $esperado) !== $esperado) {
        throw new RuntimeException('Ficha diferente no Core: ' . $codigo);
    }
    $codigos[mb_strtolower($codigo)] = true;
}
fclose($arquivo);
if (count($codigos) !== F3Base_Catalogo_Aparelhos::metadados()['codigos']) {
    throw new RuntimeException('Total incorreto.');
}
echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'codigos_conferidos'=>count($codigos),
    'campos_por_codigo'=>count($campos)-1,'precos_positivos'=>count($codigos)]);
