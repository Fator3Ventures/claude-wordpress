<?php
if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type()!=='local' || !in_array(DB_NAME,['core186','fresh186'],true)) { throw new RuntimeException('Laboratório obrigatório'); }
wp_set_current_user(1);
$dia=wp_date('Y-m-d',time()-DAY_IN_SECONDS);
$cfg=F3Base_Ga4::defaults();
$cfg['ativo']=true;$cfg['propriedade']='properties/987654';$cfg['inicio']=$dia;$cfg['recortes']=[array_key_first(F3Base_Ga4::recortes())];
update_option(F3Base_Ga4::OPTION,$cfg);
class Core186GaFixture {
    public static function capabilities(){return ['contract'=>F3Base_Ga4::CONTRACT,'capabilities'=>['ga4.report.read']];}
    public static function register_consumer(...$args){return new self();}
    public function effective_status(){return [];}
    public function query($q){
        return ['success'=>true,'audit_success'=>true,'contract_version'=>'1.0.0','property'=>$q['property'],'consumer_revision'=>$q['consumer_revision'],
            'coverage'=>['offset'=>0,'pagination_complete'=>true],'metadata'=>[],'quality'=>[],'quota'=>[],'extracted_at'=>time(),'row_count'=>1,
            'dimension_headers'=>array_map(static fn($n)=>['name'=>$n],$q['dimensions']),
            'metric_headers'=>array_map(static fn($n)=>['name'=>$n],$q['metrics']),
            'rows'=>[['dimensionValues'=>array_map(static fn($n)=>['value'=>$n==='date'?str_replace('-','',$q['start_date']):'/qa/'],$q['dimensions']),
                'metricValues'=>array_map(static fn($n)=>['value'=>'1'],$q['metrics'])]]];
    }
}
global $wpdb;
$e=['id'=>'ga4','hook'=>F3Base_Ga4::CONTINUAR,'args'=>[],'timestamp'=>time()-DAY_IN_SECONDS-321,'schedule'=>false];
F3Base_Operacao_Intencoes::registrar($e);
$key=F3Base_Operacao_Intencoes::chave($e);
$wpdb->update(F3Base_Operacao_Intencoes::tabela(),['estado'=>'esgotada','atualizada_em'=>$e['timestamp']],['chave'=>$key]);
wp_schedule_single_event($e['timestamp'],$e['hook']);
F3Base_Ga4::descobrir(new Core186GaFixture(),F3Base_Ga4::CONTRACT);
$r=F3Base_Ga4::coletar();
$state=$wpdb->get_var($wpdb->prepare('SELECT estado FROM %i WHERE chave=%s',F3Base_Operacao_Intencoes::tabela(),$key));
$out=['fonte'=>'SDK com resposta sintética, escrita no acervo real','publicado'=>$r['publicado']??false,'codigo'=>$r['codigo']??'','espera_antiga'=>$state,'gancho_antigo'=>!!wp_get_scheduled_event($e['hook'],[],$e['timestamp']),'proximo_gancho_futuro'=>wp_next_scheduled($e['hook'])>time()];
echo wp_json_encode($out);
if (!$out['publicado'] || $state!=='concluida' || $out['gancho_antigo'] || !$out['proximo_gancho_futuro']) {throw new RuntimeException('Falhou coleta completa');}
