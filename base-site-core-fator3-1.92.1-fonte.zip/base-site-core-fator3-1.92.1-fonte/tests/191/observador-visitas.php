<?php
/** Complemento do observador 420 para os bancos locais descartáveis do pedido 423. */
if (wp_get_environment_type() !== 'local' || !in_array(DB_NAME,['core190b','core190c','core190e'],true)) {
    return;
}
define('F3QA_VISITAS', true);
add_filter('pre_http_request', static function ($pre, $args, $url) {
    $alvo = wp_parse_url($url);
    $site = wp_parse_url(site_url('/wp-cron.php'));
    foreach (['scheme','host','port','path'] as $chave) {
        if (($alvo[$chave] ?? null) !== ($site[$chave] ?? null)) {return $pre;}
    }
    return ($alvo['host'] ?? '') === '127.0.0.1' ? false : $pre;
}, 11, 3);
