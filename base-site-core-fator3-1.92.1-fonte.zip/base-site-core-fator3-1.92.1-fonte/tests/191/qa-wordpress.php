<?php
/** MU-plugin temporário. O mantenedor instala exclusivamente no Site-Teste e remove após o ensaio. */
defined('ABSPATH') || exit;
if (wp_parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com') {return;}
add_action('wp_abilities_api_init',static function(){
    F3Base_Servicos::ability('qa-core-1910','Ensaio isolado dos pedidos 421 a 425', 'f3qa_1910', ['ensaio'=>['type'=>'string','enum'=>['lint','agenda','ga4','mail','catalogo','contexto']]], ['ensaio'], false);
}, 90);
function f3qa_1910(array $ent): array {
    global $wpdb,$wp_object_cache,$wp_filter;
    if(!current_user_can('manage_options')){return ['ok'=>false];}
    $resultado=['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'core'=>F3BASE_PLUGIN_VERSAO,'ensaio'=>$ent['ensaio']];
    $exigir=static function($ok,$caso){if(!$ok){throw new RuntimeException($caso);}};
    try{
        if($ent['ensaio']==='contexto'){
            $forms=[];
            foreach((array)F3Base_Options::ler('f3base_formularios') as $f){
                if(!empty($f['id']) && F3Base_Formularios::obter($f['id'])){$forms[$f['id']]=F3Base_Formularios::revisao($f);}
            }
            return $resultado+['formularios'=>$forms,'granular'=>F3Base_Modulo_Consentimento::modo_granular(),'versao_politica'=>F3Base_Modulo_Consentimento::politica_versao()];
        }elseif($ent['ensaio']==='lint'){
            $z=new ZipArchive();$exigir($z->open(WP_CONTENT_DIR.'/upgrade/f3-core-1910.zip')===true,'zip ausente');
            $php=0;
            for($i=0;$i<$z->numFiles;$i++){if(str_ends_with($z->getNameIndex($i),'.php')){token_get_all($z->getFromIndex($i),TOKEN_PARSE);++$php;}}
            $resultado+=['php_verificados'=>$php,'zip_sha256'=>hash_file('sha256',WP_CONTENT_DIR.'/upgrade/f3-core-1910.zip')];$z->close();
        }elseif($ent['ensaio']==='catalogo'){
            foreach(['lm-x525','rmx3834','rmx3933','cph1903','zte 7060'] as $modelo){$resultado['nomes'][$modelo]=F3Base_Catalogo_Aparelhos::google_play($modelo)['nome_comercial'];}
        }elseif($ent['ensaio']==='agenda'){
            $resultado['wsal_ativo']=is_plugin_active('wp-security-audit-log/wp-security-audit-log.php');
            // Reinstala os callbacks reais na ordem observada no CTO Office, apenas neste processo.
            $depois=[];
            foreach (['pre_schedule_event','pre_reschedule_event','pre_unschedule_event'] as $nome_filtro) {
                foreach (($wp_filter[$nome_filtro]->callbacks[PHP_INT_MAX]??[]) as $cb){
                    $fn=$cb['function'];
                    $rf=is_array($fn)?new ReflectionMethod(...$fn):new ReflectionFunction(Closure::fromCallable($fn));
                    if(!str_contains((string)$rf->getFileName(),'/wp-security-audit-log/')){continue;}
                    remove_filter($nome_filtro,$fn,PHP_INT_MAX);add_filter($nome_filtro,$fn,PHP_INT_MAX,$cb['accepted_args']);
                    $depois[$nome_filtro]=true;
                }
            }
            $resultado['sensores_reordenados']=array_keys($depois);
            $resultado['filtros']=method_exists(F3Base_Agenda_Filas::class,'diagnostico') ? F3Base_Agenda_Filas::diagnostico():null;
            // A cron option e o cache desta conexão são exclusivos da amostra. Não disparar trabalhadores comerciais.
            if(wp_using_ext_object_cache()){return $resultado+['ok'=>false,'erro'=>'cache_externo'];}
            $real=$wpdb->options;$nome=$wpdb->prefix.'f3qa1910_options';$cache=$wp_object_cache;
            $exigir($wpdb->query($wpdb->prepare('CREATE TEMPORARY TABLE %i LIKE %i',$nome,$real))!==false,'tabela temporária');
            $exigir($wpdb->query($wpdb->prepare("INSERT INTO %i SELECT * FROM %i WHERE option_name IN ('active_plugins','siteurl','home','timezone_string','gmt_offset')",$nome,$real))!==false,'opções de teste');
            $wpdb->options=$nome;$wp_object_cache=new WP_Object_Cache();
            try {
                // Os callbacks de terceiros continuam registrados. O filtro de cron e o CAS usam a tabela temporária.
                $base=time()-172800;$cont=[];$falhas=[];$avulsas=0;$depois=[];
                foreach(F3Base_Fila::RECORRENCIAS as $hook=>$agenda){
                    $ts=$base;
                    $r=wp_schedule_event($ts,$agenda,$hook,[],true);$cont['inicial'][]=is_wp_error($r)?$r->get_error_code():$r;
                    $r=wp_reschedule_event($ts,$agenda,$hook,[],true);$cont['reagendar'][]=is_wp_error($r)?$r->get_error_code():$r;
                    $r=wp_unschedule_event($ts,$hook,[],true);$cont['remover'][]=is_wp_error($r)?$r->get_error_code():$r;
                    $f=wp_get_scheduled_event($hook);$depois[$hook]=$f?[$f->schedule,$f->timestamp]:null;
                    $r=wp_schedule_single_event(time()+3600,$hook,F3Base_Fila::ANTECIPAR,true);
                    $avulsas+=(int)($r===true && (bool)wp_get_scheduled_event($hook,F3Base_Fila::ANTECIPAR));
                }
                $resultado+=['operacoes'=>$cont,'recorrentes'=>$depois,'avulsas'=>$avulsas];
                $hook=F3Base_Wp_Mail::HOOK;$args=F3Base_Fila::ANTECIPAR;$stamp=time()-7200;
                $exigir(wp_schedule_single_event($stamp,$hook,$args,true)===true,'semente vencida');
                $original=$wp_filter[$hook]??null;
                unset($wp_filter[$hook]);
                add_filter('wp_doing_cron','__return_true');
                try {
                    $recusa=wp_unschedule_event($stamp,$hook,$args,true);
                    $presente=wp_get_scheduled_event($hook,$args,$stamp)!==false;
                    $exigir(is_wp_error($recusa) && $recusa->get_error_code()==='fila_sem_executor' && $presente,'antecipação consumida sem executor');
                    $resultado['sem_executor']=['codigo'=>$recusa->get_error_code(),'preservada'=>$presente];
                } finally {
                    remove_filter('wp_doing_cron','__return_true');
                    if($original){$wp_filter[$hook]=$original;}
                }
                $resultado['com_executor']=wp_unschedule_event($stamp,$hook,$args,true)===true &&
                    !wp_get_scheduled_event($hook,$args,$stamp);
                $exigir($resultado['com_executor'],'remoção não confirmada');

            }finally{$wpdb->options=$real;$wp_object_cache=$cache;$wpdb->query($wpdb->prepare('DROP TEMPORARY TABLE %i',$nome));}
        }elseif($ent['ensaio']==='ga4'){
            $sel=new ReflectionMethod(F3Base_Ga4::class,'selecionar');$cfg=['property'=>'f3qa1910'];$tz=new DateTimeZone('UTC');
            $ontem=new DateTimeImmutable('yesterday',$tz);$antes=$ontem->modify('-4 days');$opts=['inicio'=>$antes->format('Y-m-d'),'recortes'=>['paginas','resumo'],'revisitar_dias'=>2,'fuso'=>'UTC'];
            $wpdb->query('START TRANSACTION');$q=[];$passes=[];$tab=F3Base_Ga4_Acervo::tabela();
            try {
                for($it=0;$it<3;$it++){$dia=$antes->modify("+$it days")->format('Y-m-d');
                    foreach($opts['recortes'] as $slice){$c=F3Base_Ga4_Acervo::criar($cfg['property'],$dia,$slice,'qa');
                      $exigir($c,'criar histórico');$wpdb->update($tab,['estado'=>'sem_dados','atualizado_em'=>time()-86400],['id'=>$c['id']]);}}
                for($i=0;$i<12;$i++){
                    $retry=null;$pick=$sel->invokeArgs(null,[$cfg,$opts,[],[],&$retry]);if(!$pick){break;}
                    [$day,$slice]=$pick;$chave="$day/$slice";$exigir(!in_array($chave,$passes,true),'recorte repetido');$passes[]=$chave;
                    $c=F3Base_Ga4_Acervo::criar($cfg['property'],$day,$slice,'qa');
                    $wpdb->update($tab,['estado'=>($i%2?'sem_dados':'concluida'),'atualizado_em'=>time()],['id'=>$c['id']]);
                    $t=F3Base_Ga4::passagem(time()+1+$i*900);$q[]=['minuto_utc'=>gmdate('i:s',$t),'alinhado'=>$t%900===0];
                }
                $exigir(count($passes)===4,'esperadas quatro páginas recentes');
                $resultado+=['historicos_vazios'=>6,'paginas'=>$passes,'horarios'=>$q,'continuacoes'=>count($passes)-1];
            }finally{$wpdb->query('ROLLBACK');}
        }elseif($ent['ensaio']==='mail'){
            $m=new ReflectionMethod(F3Base_Wp_Mail::class,'metadados');
            $r=$m->invoke(null,['to'=>'QA Exemplo <qa-recibo@example.org>','subject'=>'Ensaio do aviso 123456','headers'=>['Cc: cc-ensaio@example.org']],['endereco'=>'qa-recibo@example.org']);
            $exigir($r['destinos']===['qa***@example.org','cc***@example.org'] && $r['inclui_propria_caixa'],'máscaras');
            $resultado['metadados']=$r;$cfg=['endereco'=>'teste@example.org','nome_exibicao'=>'Teste'];
            foreach([[],'abc'] as $to){try{F3Base_Wp_Mail::mensagem(['to'=>$to],$cfg,str_repeat('a',32));}catch(Throwable $e){$resultado['recusas'][]=$e->getMessage();}}
            $exigir($resultado['recusas']===['destinatario_vazio','destinatario_sintaxe'],'recusas antes de SMTP');
            $real=$wpdb->options;$nome=$wpdb->prefix.'f3qa1910_mailopts';$cache=$wp_object_cache;
            $exigir(!wp_using_ext_object_cache(),'cache externo');
            $exigir($wpdb->query($wpdb->prepare('CREATE TEMPORARY TABLE %i LIKE %i',$nome,$real))!==false,'opções temporárias');
            $exigir($wpdb->query($wpdb->prepare("INSERT INTO %i SELECT * FROM %i WHERE option_name IN ('siteurl','home','blog_charset','timezone_string','gmt_offset','active_plugins')",$nome,$real))!==false,'configuração de teste');
            $tabela=F3Base_Wp_Mail::tabela();
            $ddl=$wpdb->get_row($wpdb->prepare('SHOW CREATE TABLE %i',$tabela),ARRAY_N);
            $exigir(isset($ddl[1]) && str_starts_with($ddl[1],'CREATE TABLE '),'estrutura da fila');
            $exigir($wpdb->query(preg_replace('/^CREATE TABLE /','CREATE TEMPORARY TABLE ',$ddl[1]))!==false,'fila temporária');
            $wpdb->options=$nome;$wp_object_cache=new WP_Object_Cache();$avisos=0;
            $fixture=array_replace(F3Base_Email_Site_Config::padroes(),[
                'wp_mail_pela_caixa'=>true,'alocacao_confirmada'=>true,'endereco'=>'qa@example.invalid','usuario'=>'qa',
                'nome_exibicao'=>'Teste','homologacao'=>false,'smtp_host'=>'smtp.example.invalid']);
            $fixtures=[F3Base_Email_Site_Config::OPTION=>$fixture,F3Base_Email_Site_Config::SECRET=>F3Base_Segredos::cifrar(F3Base_Email_Site_Config::SECRET,wp_generate_password()),'admin_email'=>'qa@example.invalid'];
            foreach($fixtures as $k=>$v){$exigir($wpdb->replace($nome,['option_name'=>$k,'option_value'=>maybe_serialize($v),'autoload'=>'no'])!==false,'fixture');}
            $interceptar=static function($pre,$atts)use(&$avisos){if(str_contains($atts['subject'],'Falha permanente na fila wp_mail')){++$avisos;return true;}return $pre;};
            add_filter('pre_wp_mail',$interceptar,PHP_INT_MIN,2);
            try{
                $ciclo=[];$ciclo['ciclo']='qa-1910-'.wp_generate_uuid4();update_option(F3Base_Instalacao::OPTION,$ciclo);
                $rotulo='[QA 1.91.0] Recusa controlada '.substr($ciclo['ciclo'],-8);
                $enviar=static function()use($rotulo){wp_mail('nome-sem-arroba',$rotulo,'Teste sintético');};
                add_action('f3qa_1910_recusa',$enviar);do_action('f3qa_1910_recusa');do_action('f3qa_1910_recusa');
                $recibos=array_values(array_filter(F3Base_Wp_Mail::ler()['linhas'],static fn($x)=>($x['diagnostico']['assunto']??'')===$rotulo));
                $resultado['recibos']=array_map(static fn($x)=>array_intersect_key($x,array_flip(['id','codigo','fase','diagnostico'])),$recibos);
                $resultado['avisos_interceptados']=$avisos;$resultado['aceite_canal']=F3Base_Options::ler(F3Base_Wp_Mail::STATE)['aviso']['estado']??null;
                $exigir(count($recibos)===2 && $avisos===1,'dois recibos e um aviso: '.count($recibos).'/'.$avisos);
            }finally{remove_filter('pre_wp_mail',$interceptar,PHP_INT_MIN);$wpdb->query($wpdb->prepare('DROP TEMPORARY TABLE %i',$tabela));$wpdb->options=$real;$wp_object_cache=$cache;$wpdb->query($wpdb->prepare('DROP TEMPORARY TABLE %i',$nome));}
            $resultado['coluna']=(bool)$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM %i LIKE 'diagnostico'",F3Base_Wp_Mail::tabela()));
        }
        return $resultado+['ok'=>true];
    }catch(Throwable $x){return $resultado+['ok'=>false,'erro'=>substr($x->getMessage(),0,300)];}
}
