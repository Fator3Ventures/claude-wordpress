<?php
/** Fixture de retorno de escrita, isolada de agendas e das classes dos pacotes oficiais. */
namespace F3QA191Impacto {
    class Estado {
        public static string $caso;
        public static array $evento=[];
    }
}
namespace F3QA191Impacto\meta {
    use F3QA191Impacto\Estado;
    final class Config { const KEY='f3qa'; }
    final class Store {
        public static function lock($key,$func){return $func();}
        public static function scan(...$args){return [true];}
    }
    function wp_next_scheduled($hook){return Estado::$evento['quando']??false;}
    function wp_get_scheduled_event($hook,$args,$quando){
        $v=Estado::$evento; return $v && $v['hook']===$hook && $v['args']===$args && $v['quando']===$quando ? (object)$v : false;
    }
    function wp_schedule_single_event($quando,$hook,$args=[],$erros=false){
        $caso=Estado::$caso;
        if($caso!=='ausente'){
            Estado::$evento=['quando'=>$quando+($caso==='outro_horario'?1:0),'hook'=>$hook,'args'=>$caso==='outros_args'?['x']:$args];
        }
        return $caso==='ok'?true:new \WP_Error('could_not_set','Erro controlado.');
    }
    function update_option(...$args){return true;}
    final class Jobs {
    public static function scheduleTick(int $delay=5): bool {
        return self::scheduleTickResult($delay)['scheduled'];
    }
    public static function scheduleTickResult(int $delay=5): array {
        try {
            return Store::lock('worker-event', static function () use ($delay) {
                $hook = Config::KEY.'_worker';
                if (wp_next_scheduled($hook)) return ['scheduled'=>true,'code'=>'ok'];
                $when = time()+max(5,$delay);
                $result = wp_schedule_single_event($when, $hook, [], true);
                $next = wp_next_scheduled($hook) ?: null;
                $error = is_wp_error($result) ? sanitize_key($result->get_error_code()) : '';
                $ok = $next !== null && ($result === true || $error === 'duplicate_event');
                if ($error === 'could_not_set' && wp_get_scheduled_event($hook, [], $when)) {
                    $ok = true;
                }
                $code = $ok ? 'ok' : ($error ?: 'schedule_unconfirmed');
                $attempt = ['at'=>time(),'success'=>$ok,'next'=>$next,'code'=>$code];
                update_option(Config::KEY.'_worker_schedule_attempt', $attempt, false);
                if (!$ok) update_option(Config::KEY.'_worker_schedule_failure', $attempt, false);
                return ['scheduled'=>$ok,'code'=>$code];
            });
        } catch (\Throwable $e) {
            $code = $e instanceof Fault ? $e->reason : 'schedule_exception';
            $attempt = ['at'=>time(),'success'=>false,'next'=>null,'code'=>$code];
            update_option(Config::KEY.'_worker_schedule_attempt',$attempt,false);
            update_option(Config::KEY.'_worker_schedule_failure',$attempt,false);
            return ['scheduled'=>false,'code'=>$code];
        }
    }
    }
}
namespace F3QA191Impacto\linkedin {
    use F3QA191Impacto\Estado;
    final class Config { const KEY='f3qa'; }
    final class Store {
        public static function lock($key,$func){return $func();}
        public static function scan(...$args){return [true];}
    }
    function wp_next_scheduled($hook){return Estado::$evento['quando']??false;}
    function wp_get_scheduled_event($hook,$args,$quando){
        $v=Estado::$evento; return $v && $v['hook']===$hook && $v['args']===$args && $v['quando']===$quando ? (object)$v : false;
    }
    function wp_schedule_single_event($quando,$hook,$args=[],$erros=false){
        $caso=Estado::$caso;
        if($caso!=='ausente'){
            Estado::$evento=['quando'=>$quando+($caso==='outro_horario'?1:0),'hook'=>$hook,'args'=>$caso==='outros_args'?['x']:$args];
        }
        return $caso==='ok'?true:new \WP_Error('could_not_set','Erro controlado.');
    }
    function update_option(...$args){return true;}
    final class Jobs {
    public static function scheduleTick(int $delay=5): bool {
        try{return Store::lock('worker-event',static function()use($delay){
            if(wp_next_scheduled(Config::KEY.'_worker'))return true;
            $when=time()+max(5,$delay);
            $result=wp_schedule_single_event($when,Config::KEY.'_worker',[],true);
            $next=wp_next_scheduled(Config::KEY.'_worker')?:null;
            $ok=$result===true&&$next!==null;
            // A concurrent scheduler may have added it; do not report a missing event then.
            if(is_wp_error($result)&&$result->get_error_code()==='duplicate_event'&&$next!==null)$ok=true;
            if(is_wp_error($result) && $result->get_error_code()==='could_not_set'
                && wp_get_scheduled_event(Config::KEY.'_worker',[],$when)) { $ok=true; }
            $attempt=['at'=>time(),'success'=>$ok,'next'=>$next,'code'=>$ok?'ok':(is_wp_error($result)?sanitize_key($result->get_error_code()):'schedule_unconfirmed')];
            update_option(Config::KEY.'_worker_schedule_attempt',$attempt,false);
            if(!$ok)update_option(Config::KEY.'_worker_schedule_failure',$attempt,false);
            return $ok;
        });}catch(\Throwable $e){$attempt=['at'=>time(),'success'=>false,'next'=>null,'code'=>$e instanceof Fault?$e->reason:'schedule_exception'];update_option(Config::KEY.'_worker_schedule_attempt',$attempt,false);update_option(Config::KEY.'_worker_schedule_failure',$attempt,false);return false;}
    }
    }
    final class LeadDiscovery {
    public static function ensure(): bool {
        if(!Store::scan('lead_scan','',1))return true;
        if(wp_next_scheduled(Config::KEY.'_lead_discovery'))return true;
        $hook=Config::KEY.'_lead_discovery';
        $when=time()+60;
        $result=wp_schedule_single_event($when,$hook,[],true);
        if($result===true){return true;}
        return is_wp_error($result) && in_array($result->get_error_code(),['could_not_set','duplicate_event'],true)
            && (bool)wp_get_scheduled_event($hook,[],$when);
    }
    }
}
namespace F3QA191Impacto {
    function validar(){
        $provas=[];
        foreach ([['meta','Jobs','scheduleTick'],['linkedin','Jobs','scheduleTick'],['linkedin','LeadDiscovery','ensure']] as [$plugin,$classe,$metodo]){
            $nome=__NAMESPACE__.'\\'.$plugin.'\\'.$classe;
            foreach(['ok'=>true,'confirmado'=>true,'ausente'=>false,'outro_horario'=>false,'outros_args'=>false] as $caso=>$esperado){
                Estado::$caso=$caso;Estado::$evento=[];$r=$nome::$metodo();
                if($r!==$esperado){throw new \RuntimeException($nome.'::'.$metodo.' '.$caso);}
                $provas[$plugin.'/'.$classe][$caso]=$r;
            }
        }return $provas;
    }
}
