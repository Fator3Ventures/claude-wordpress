"""Toques Chromium por CDP, 4×, página nova por rodada, backend HTTP local com ACK por evento."""
import argparse, json, threading, statistics, time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('novo',type=Path);p.add_argument('saida',type=Path);args=p.parse_args()
html=Path(__file__).with_name('interacao.html').read_bytes()
packs={}; ativo=args.baseline
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def out(self,data,kind='text/html'):
  self.send_response(200);self.send_header('Content-Type',kind);self.end_headers();self.wfile.write(data)
 def do_GET(self):
  path=urlsplit(self.path).path
  if path.startswith('/plugin/assets/') and '..' not in path:self.out((ativo/path.removeprefix('/plugin/')).read_bytes(),'application/javascript')
  elif path.startswith('/fim/'):self.out(b'Fim')
  else:self.out(html)
 def do_POST(self):
  events=json.loads(self.rfile.read(int(self.headers['Content-Length'])))['eventos'];packs.setdefault(self.path,[]).extend(events)
  self.out(json.dumps({'ok':True,'confirmados':[{k:e[k] for k in ['evento','sequencia']} for e in events]}).encode(),'application/json')
server=ThreadingHTTPServer(('127.0.0.1',0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
url='http://127.0.0.1:'+str(server.server_port); data={}
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for v,path in [('antes',args.baseline),('depois',args.novo)]:
  ativo=path; rows=[]
  for i in range(12):
   ident=v+str(i);ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);pg=ctx.new_page()
   pg.context.new_cdp_session(pg).send('Emulation.setCPUThrottlingRate',{'rate':4})
   pg.goto(url+'/?local=1&caso='+ident+('&saida=1' if i==11 else ''));pg.wait_for_timeout(350)
   pg.locator('#abrir').tap()
   if i!=11:
    pg.wait_for_timeout(125);pg.locator('#confirmar').tap();pg.wait_for_timeout(500)
    row=pg.evaluate('window.f3qaFoto()');row['clique_ms']=max((e['d'] for e in row['timings'] if e['el']=='abrir'),default=None);rows.append(row)
   else:pg.wait_for_url('**/fim/*');pg.wait_for_timeout(450)
   types=[e['tipo'] for e in packs.get('/recibo/'+ident,[])]; want=['clique_link','oferta_aberta','form_dialogo','form_inicio','form_aceito','oferta_fechada']
   if i==11:rows.append({'saida_imediata':True,'tipos':types})
   else:rows[-1]['tipos']=types
   if v=='depois':
    assert all(t in types and types.count(t)==1 for t in want),(i,types)
    assert [types.index(t) for t in want]==sorted(types.index(t) for t in want),(i,types)
    if i!=11:assert not row['erros'],row['erros']
   ctx.close()
  data[v]=rows
 b.close()
server.shutdown();args.saida.write_text(json.dumps(data,ensure_ascii=False,indent=2))
for v,rows in data.items():
 print(v,{'toques':len(rows),'ouvinte_mediana_ms':statistics.median(r['custos'][0] for r in rows[:-1]),'clique_ms':[r['clique_ms'] for r in rows[:-1]],'saida':rows[-1]})
