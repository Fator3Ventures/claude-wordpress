from pathlib import Path
import collections, hashlib, json, csv, gzip, sys
here=Path(__file__).resolve()
sources = here.parents[2] if here.parent.name == '191' else Path('base-site-core-fator3-1.91.0-fonte')
old = Path(sys.argv[1])
runtime = Path('work/plugin/base-site-core-fator3')
def read_json(path):
    return json.loads(path.read_bytes())
def open_files(root):
    dados=root/runtime/'dados'
    google={}
    for p in sorted((dados/'google-play').glob('*.gz')):
        google.update(json.loads(gzip.decompress(p.read_bytes())))
    return read_json(dados/'aparelhos-br.json'), google
def get_profile(code, commercial, google):
    index=commercial['codigos'].get(code.lower())
    if index is not None:
        row=commercial['modelos'][index]
        return {'fonte':'comercial','nome':row[1],'ficha':row}
    result=google.get(code.lower())
    assert result,code
    return {'fonte':'google','nome':result[1],'criterio':result[3]}
previous=open_files(old)
current=open_files(sources)
assert previous[0]==current[0]
out=[]
for code in read_json(sources/'reference/419/codigos-frota.json'):
    a=get_profile(code,*previous)
    b=get_profile(code,*current)
    assert a==b or a['nome'].casefold()==code.casefold() and b.get('criterio')=='nome_google', (code,a,b)
    out.append({'codigo':code,'antes':a,'depois':b})
assert len(out)==30
old_csv=(old/'reference/419/catalogo-aparelhos.csv').read_bytes()
new_csv=(sources/'reference/419/catalogo-aparelhos.csv').read_bytes()
assert old_csv==new_csv
with (sources/'reference/419/catalogo-aparelhos.csv').open() as f:
    rows=list(csv.DictReader(f))
    assert len(rows)==1350 and all(float(row['preco_atual_estimado_brl'])>0 for row in rows)
def names(root):
    parts=(root/runtime/'docs/dados').glob('abilities-*.json')
    return {name for part in parts for name in read_json(part)['abilities']}
assert names(old)==names(sources) and len(names(sources))==197
data={'comparacao':'1.90.0 → 1.91.0, runtime embarcado antes da configuração específica do site',
      'codigos':len(out),'fichas_iguais':sum(x['antes']==x['depois'] for x in out),'origens':dict(collections.Counter(x['depois']['fonte'] for x in out)),
      'itens':out,'linhas_csv_precos_positivos':len(rows),'csv_sha256':hashlib.sha256(new_csv).hexdigest(),'mesmas_abilities':197}
(sources/'evidence/1910/frota-catalogo.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in data.items() if k!='itens'})
