"""Confere independentemente as escolhas e as exceções dos candidatos do pedido 422."""
import csv,gzip,json,collections,re
from pathlib import Path
root=Path(__file__).resolve().parents[2]; src=root/'reference/417/supported_devices.csv';td=root/'work/plugin/base-site-core-fator3/dados/google-play'
norm=lambda x:' '.join(x.lower().split())
groups=collections.defaultdict(set); allcounts=collections.defaultdict(collections.Counter)
with src.open(encoding='utf-16',newline='') as f:
 for b,n,d,m in list(csv.reader(f))[1:]:
  if m.strip():groups[norm(m)].add((norm(b),n.strip(),norm(d),m.strip()))
for rows in groups.values():
 for b,n,d,m in rows:allcounts[b,d][norm(n)]+=1
actual={}
for f in td.glob('*.gz'):actual.update(json.loads(gzip.decompress(f.read_bytes())))
work=[];simpl=lambda v:''.join(c for c in norm(v) if c.isalnum())
for k,rows in sorted(groups.items()):
 own={(b,d) for b,n,d,m in rows if norm(n)==k}
 others={(b,d,n) for b,n,d,m in rows if (b,d) in own and n and norm(n)!=k}
 if not others:continue
 meaningful={(b,d,n) for b,d,n in others if simpl(k)!=simpl(n) and simpl(re.sub(r'[ _-]+(eea|eu|ru|us|uk|in|br|jp|kr|cn|tw|latam|emea|global)$','',k))!=simpl(re.sub(r'[ _-]+(eea|eu|ru|us|uk|in|br|jp|kr|cn|tw|latam|emea|global)$','',n,flags=re.I))}
 b,name,d,r=actual[k]
 if r=='modelo_ambiguo':status='ambíguo';assert meaningful
 elif not meaningful:status='região ou grafia';assert norm(name)==k,(k,name)
 else:
  status='nome comercial';assert norm(name)!=k and any(norm(n)==norm(name) for _,_,n in meaningful),(k,name)
  if k!='lm-x525':
   counts=allcounts[norm(b),norm(d)]; assert counts[norm(name)]==max(counts[norm(n)] for _,_,n in meaningful)
 work.append((k,name,status,' | '.join(sorted({n for _,_,n in others}))))
dest=root/'reference/422/auditoria.csv'
with dest.open('w',newline='') as f:
 w=csv.writer(f);w.writerow(('modelo','nome_entregue','decisao','alternativas_publicadas'));w.writerows(work)
expected={'lm-x525':'LG Q60','rmx3834':'realme Note 50','rmx3933':'realme Note 60','cph1903':'AX7','zte 7060':'ZTE Blade A73'}
for k,n in expected.items():assert norm(actual[k][1])==norm(n),(k,actual[k],n)
assert len(work)==826,len(work)
print(json.dumps({'candidatos':len(work),'resultado':collections.Counter(x[2] for x in work),'exemplos':{k:actual[k][1] for k in expected}},ensure_ascii=False))
