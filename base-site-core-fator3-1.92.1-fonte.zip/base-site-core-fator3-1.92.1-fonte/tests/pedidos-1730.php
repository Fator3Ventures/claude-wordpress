<?php
require __DIR__.'/bootstrap.php';
global $wpdb;
// No external event or email can leave this isolated laboratory.
$network=0;add_filter('pre_http_request',static function($pre)use(&$network){$network++;return new WP_Error('qa_blocked');},1);
$check=F3Base_Credenciais::verificar('f3base_meta_capi_token','EAAU'.str_repeat('x',194),'',true);
check($check['ok']&&$check['codigo']==='capi_validacao_por_evento_pendente','372_aceita_token_eventos');
check($network===0,'372_gravar_nao_envia_evento_nem_consulta_ads');
check(!empty($check['avisos']),'372_aviso_de_prova_pendente');
$save=F3Base_Options::gravar('f3base_meta_capi_token','EAAU'.str_repeat('x',194),F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao('f3base_meta_capi_token'));
check(!empty($save['persisted']),'372_gravacao_real_cifrada');
check(str_starts_with(get_option('f3base_meta_capi_token'),F3Base_Segredos::PREFIXO),'372_token_nao_gravado_em_claro');
check(!F3Base_Credenciais::verificar('f3base_meta_capi_token',"bad\x00token")['ok'],'372_controle_inseguro_recusado');
$rotate=F3Base_Options::gravar('f3base_meta_capi_token','EAAU'.str_repeat('y',194),F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao('f3base_meta_capi_token'));
check(!empty($rotate['persisted'])&&!F3Base_Credenciais::preservar_estado('f3base_meta_capi_token'),'372_rotacao_nao_preserva_prova_sem_identidade');
foreach(['opcoes-publicas.php','cron-opcoes.php'] as $file){check(in_array('f3base_meta_lead',require F3BASE_PLUGIN_DIR.'includes/'.$file,true),'371_catalogo_'.$file);}
$cfg=F3Base_Options::ler('f3base_avisos_tecnicos');$cfg['imap_falhas_consecutivas']=24;$cfg['imap_sem_leitura_minutos']=120;update_option('f3base_avisos_tecnicos',$cfg);
foreach(['imap_transporte_indisponivel','imap_resposta_incompleta','imap_tempo_esgotado','imap_tls_interrompido'] as $code){check(F3Base_Email_Alerta::passageira($code,$cfg),'373_transitorio_'.$code);}
foreach(['imap_autenticacao_recusada','imap_pasta_ausente','imap_credencial_vazia'] as $code){$with=$cfg;$with['imap_codigos_passageiros'][]=$code;check(!F3Base_Email_Alerta::passageira($code,$with),'373_imediato_'.$code);}
$custom=$cfg;$custom['imap_codigos_passageiros'][]='imap_rede_customizada';check(F3Base_Email_Alerta::passageira('imap_rede_customizada',$custom),'373_codigo_configuravel');
$mail=0;add_filter('pre_wp_mail',static function()use(&$mail){$mail++;return true;},1);
$box=F3Base_Email_Site_Config::padroes();$box['ativo']=true;update_option(F3Base_Email_Site_Config::OPTION,$box);
$state=['ativado_em'=>time(),'ultima_tentativa'=>time(),'ultima_leitura_completa'=>time(),'sequencia_leitura_completa'=>1,'codigo'=>'imap_transporte_indisponivel','falhas'=>1];update_option(F3Base_Email_Site_Config::STATE,$state);
F3Base_Email_Alerta::observar();check($mail===0,'373_primeira_falha_sem_email');
$state['falhas']=23;update_option(F3Base_Email_Site_Config::STATE,$state);F3Base_Email_Alerta::observar();check($mail===0,'373_abaixo_limite_sem_email');
$state['codigo']='';$state['falhas']=0;$state['sequencia_leitura_completa']=2;update_option(F3Base_Email_Site_Config::STATE,$state);F3Base_Email_Alerta::observar();check($mail===0,'373_recuperacao_sem_incidente_sem_email');
$state['codigo']='imap_transporte_indisponivel';$state['falhas']=24;update_option(F3Base_Email_Site_Config::STATE,$state);F3Base_Email_Alerta::observar();check($mail===1,'373_aviso_no_limite');F3Base_Email_Alerta::observar();check($mail===1,'373_nao_duplica_abertura');
$state=get_option(F3Base_Email_Site_Config::STATE);$state['codigo']='';$state['falhas']=0;$state['sequencia_leitura_completa']=3;update_option(F3Base_Email_Site_Config::STATE,$state);F3Base_Email_Alerta::observar();check($mail===2,'373_recuperacao_unica');F3Base_Email_Alerta::observar();check($mail===2,'373_nao_duplica_recuperacao');
$state=['ativado_em'=>time()-8000,'ultima_tentativa'=>time(),'ultima_leitura_completa'=>time()-7201,'codigo'=>'imap_transporte_indisponivel','falhas'=>1];update_option(F3Base_Email_Site_Config::STATE,$state);F3Base_Email_Alerta::observar();check($mail===3,'373_limite_tempo');
$box['ativo']=false;update_option(F3Base_Email_Site_Config::OPTION,$box);
check(F3Base_Meta_Lead::modo(['metodo'=>'formulario'])==='imediato','371_padrao_imediato');
update_option(F3Base_Meta_Lead::OPTION,['modo'=>'imediato','formularios'=>['qa'=>'agente']]);
check(F3Base_Meta_Lead::modo(['metodo'=>'formulario','formulario'=>'qa'])==='agente','371_sobreposicao_formulario');
check(F3Base_Meta_Lead::modo(['metodo'=>'formulario','formulario'=>'outro'])==='imediato','371_demais_formularios_imediatos');
update_option('f3base_meta_capi_pixel_id','123456');update_option('f3base_meta_transporte',['modo'=>'ambos','eventos'=>['Lead']]);
update_option('f3base_meta_janela',['confirmada'=>true,'aceitacao_segundos'=>604800,'deduplicacao_segundos'=>172800,'conferida_em'=>gmdate('Y-m-d'),'fonte'=>'https://developers.facebook.com/docs/marketing-api/conversions-api']);
$id=bin2hex(random_bytes(16));$d=['record_id'=>$id,'metodo'=>'formulario','formulario'=>'qa','captura'=>'aceito','classe_trafego'=>'nao_marcado','contexto_teste'=>false,'email'=>'qa@example.test','telefone'=>'+5511999998888','pagina'=>'/contato/','classificacao_contexto'=>'permitida','consentimento_snapshot'=>['publicidade'=>true,'medicao'=>true],'contexto'=>['ip'=>'203.0.113.7','user_agent'=>'QA Visitor 1730'],'atribuicao'=>['fbclid'=>'qa_click_1730','fbp'=>'fb.1.1234567890.1234']];
wp_set_current_user(0);$saved=F3Base_Leads_Repositorio::guardar($d);wp_set_current_user(1);check(!empty($saved['persisted']),'371_contato_persistido');
$lead=F3Base_Leads_Repositorio::obter($id);$s=F3Base_Contato_Comunicacao::abrir($lead['dados']['meta_lead_cifrado']??'');
check($s&&$s['ip']==='203.0.113.7'&&$s['user_agent']==='QA Visitor 1730','371_correspondencia_cifrada');
check(str_starts_with($s['fbc'],'fb.1.')&&str_ends_with($s['fbc'],'.qa_click_1730'),'371_fbc_do_fbclid');
check(F3Base_Aquisicoes::event_id($lead)===$id,'371_evento_estavel');
$a=F3Base_Aquisicoes::reservar($lead);check(($a['supressoes']['meta']??'')==='aguardando_marcacao_agente','371_suprime_pixel');
$automatic=F3Base_Modulo_Meta_Capi::agendar_registro($id,true);check(($automatic['motivo']??'')==='aguardando_marcacao_agente','371_suprime_capi_automatico');
$e=['record_id'=>$id,'motivo'=>'Contato aprovado em teste'];$preview=F3Base_Meta_Lead::executar($e);check(!empty($preview['ok'])&&$preview['simulado'],'371_simula_por_padrao');
check(F3Base_Capi_Fila::ler($id)===null,'371_simulacao_sem_fila');
check((F3Base_Meta_Lead::executar($e+['simular'=>false,'revisao_esperada'=>999])['codigo']??'')==='conflito','371_revisao_obrigatoria');
wp_set_current_user(0);check(F3Base_Meta_Lead::executar($e)['codigo']==='sem_permissao','371_recusa_anonimo');wp_set_current_user(1);
$apply=F3Base_Meta_Lead::executar($e+['simular'=>false,'revisao_esperada'=>(int)$lead['revisao']]);check(!empty($apply['ok']),'371_marcacao_enfileira');
$q=F3Base_Capi_Fila::ler($id);$payload=F3Base_Capi_Fila::abrir_payload($q['payload']);$event=$payload['data'][0];
check($event['event_id']===$id&&$event['event_time']===$s['event_time']&&$event['action_source']==='website','371_contrato_evento');
check($event['user_data']['client_ip_address']==='203.0.113.7'&&$event['user_data']['client_user_agent']==='QA Visitor 1730','371_nao_usa_rede_do_operador');
check($event['user_data']['em']===[hash('sha256','qa@example.test')]&&isset($event['user_data']['external_id']),'371_hash_no_payload');
check($event['event_source_url']===home_url('/contato/'),'371_url_original');
$again=F3Base_Meta_Lead::executar($e+['simular'=>false,'revisao_esperada'=>1]);check(!empty($again['repetido'])&&$again['recibo']['estado']===$q['estado'],'371_repeticao_recibo');
$project=F3Base_Leads_Admin::projetar_leitura(F3Base_Leads_Repositorio::obter($id));check(isset($project['meta_lead'])&&!isset($project['dados']['meta_lead_cifrado']),'371_leitura_sem_material_cifrado');
check((int)$project['meta_lead']['marcacao']['operador_id']===1,'371_auditoria_operador');
$deny=$d;$deny['consentimento_snapshot']['publicidade']=false;check(!isset(F3Base_Meta_Lead::capturar($deny,'abc')['meta_lead_cifrado']),'371_nao_captura_sem_publicidade');
// Expired contact and no snapshot remain local, without outbound request.
$id2=bin2hex(random_bytes(16));$d['record_id']=$id2;wp_set_current_user(0);F3Base_Leads_Repositorio::guardar($d);wp_set_current_user(1);$l=F3Base_Leads_Repositorio::obter($id2);$snapshot=F3Base_Contato_Comunicacao::abrir($l['dados']['meta_lead_cifrado']);$snapshot['event_time']=time()-604801;$l['dados']['meta_lead_cifrado']=F3Base_Contato_Comunicacao::cifrar($snapshot);$wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($l['dados'])],['record_id'=>$id2]);
check(F3Base_Meta_Lead::executar(['record_id'=>$id2,'motivo'=>'Expirado'])['codigo']==='meta_janela_encerrada','371_recusa_evento_expirado');
check($network===0,'preparacao_sem_chamada_externa');
// A synthetic HTTP response exercises the real queue consumer; it is not Meta evidence.
$post=0;$observed=[];add_filter('pre_http_request',static function($pre,$args,$url)use(&$post,&$observed){
 if(str_starts_with($url,'https://graph.facebook.com/')&&str_ends_with($url,'/events')){$post++;$observed=json_decode($args['body'],true);return ['response'=>['code'=>200],'body'=>'{"events_received":1,"fbtrace_id":"QA_LOCAL_ONLY"}','headers'=>[],'cookies'=>[]];}
 return new WP_Error('qa_blocked');
},PHP_INT_MAX,3);
$sent=F3Base_Modulo_Meta_Capi::enviar($id);
check($post===1&&!empty($sent['ok'])&&F3Base_Capi_Fila::ler($id)['estado']==='entregue','371_consumidor_recibo_aceito_simulado');
check($observed['data'][0]['event_id']===$id&&$observed['data'][0]['event_time']===$s['event_time'],'371_post_preserva_evento');
F3Base_Modulo_Meta_Capi::enviar($id);$done=F3Base_Meta_Lead::executar($e+['simular'=>false,'revisao_esperada'=>1]);
check($post===1&&$done['recibo']['estado']==='entregue','371_repeticao_apos_entrega_sem_post');
$id3=bin2hex(random_bytes(16));$d['record_id']=$id3;$d['email']='suspect@example.test';$d['captura']='suspeito';wp_set_current_user(0);F3Base_Leads_Repositorio::guardar($d);wp_set_current_user(1);
$l3=F3Base_Leads_Repositorio::obter($id3);check(F3Base_Meta_Lead::executar(['record_id'=>$id3,'motivo'=>'Suspeito'])['codigo']==='contato_nao_elegivel','371_suspeito_nao_enviado');
$approved=F3Base_Leads_Repositorio::atualizar(['record_id'=>$id3,'revisao_esperada'=>(int)$l3['revisao'],'simular'=>false,'alteracoes'=>['captura'=>'aceito']]);
$l3=F3Base_Leads_Repositorio::obter($id3);check(!empty($approved['ok'])&&$l3['captura']==='aceito','371_aprovacao_nativa');
check(!empty(F3Base_Meta_Lead::executar(['record_id'=>$id3,'motivo'=>'Aprovado'])['ok']),'371_suspeito_aprovado_usa_mesmo_caminho');
$l3['dados']['consentimento_snapshot']['publicidade']=false;$wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($l3['dados'])],['record_id'=>$id3]);
check(F3Base_Meta_Lead::executar(['record_id'=>$id3,'motivo'=>'Sem consentimento'])['codigo']==='consentimento_nao_permite','371_reconfere_consentimento');
check($network===1&&$post===1,'somente_post_interceptado_sem_fornecedor_real');
evidence('pedidos-1730',['fornecedores'=>'bloqueados; sem conversão real','checks'=>count($checks)]);
