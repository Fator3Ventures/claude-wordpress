<?php
/** Massa inteiramente sintética. Sem HTTP nem escrita de configuração. */
function f3qa181_projecoes(callable $check): array {
    $at='2026-11-10T20:57:00-03:00';$all=[];
    foreach(['meta','linkedin','google'] as $p){
        $n=['origem'=>$p,'conta_id'=>'1234567890','campanha_id'=>'123','anuncio_id'=>'456','formulario_id'=>'789','lead_id'=>'123456','nativo_em'=>$at];
        $a=['record_id'=>substr(hash('sha256','qa-181-ficha-'.$p),0,32),'site'=>'laboratorio.test','metodo'=>'formulario','nome'=>'Pessoa QA','email'=>'qa@example.test','telefone'=>'5511999999999','empresa'=>'Organização QA','cargo'=>'Diretoria','servicos'=>['Assessoria'],'whatsapp_link'=>'https://wa.me/5511999999999','origem_nativa'=>$n,'formulario'=>'Formulário QA','pagina_titulo'=>'Solicitação','pagina'=>'https://example.test/form','campos'=>['pergunta'=>'Resposta sintética'],'respostas'=>[],'registro_url'=>'https://example.test/wp-admin/admin.php?page=f3base-leads','atribuicao'=>['plataforma'=>$p.'_ads','utm_source'=>$p,'utm_medium'=>'paid','utm_campaign'=>'Campanha QA'],'jornada'=>[]];
        $base=F3Base_Anuncio_Origem::base($a);$media='https://fixture.example/assinada?token=sintetico';
        if($p==='meta'){
            $d=['account_id'=>'1234567890','campaign'=>['name'=>'Campanha QA','id'=>'123'],'ad'=>['id'=>'456','name'=>'Anúncio A'],'ads_manager_url'=>$base['fields']['Abrir anúncio'],'notices'=>[],'creative'=>['primary_text'=>'Texto QA','title'=>'Título QA','description'=>'Descrição QA','button'=>'Inscrever','destination'=>'https://example.test/form','image_url'=>$media,'effective_object_story_id'=>'123_456']];
            $r=F3Base_Anuncio_Origem::projetar($base,$d);
        }elseif($p==='linkedin'){
            $d=['creative_id'=>'456','creative_name'=>'Anúncio A','campaign_id'=>'123','campaign_name'=>'Campanha QA','campaign_manager_url'=>$base['fields']['Abrir campanha'],'post_url'=>'https://www.linkedin.com/feed/update/urn:li:share:456/','text'=>'Texto QA','title'=>'Título QA','description'=>'Descrição QA','button'=>'Inscrever','destination_url'=>'https://example.test/form','media_type'=>'video'];
            $r=F3Base_Anuncio_Origem::projetar($base,$d,['thumbnail'=>['url'=>$media],'media'=>['url'=>'https://fixture.example/video.mp4']]);
        }else{
            $d=['account_id'=>'1234567890','ad_id'=>'456','assets_complete'=>true,'state'=>'found','campaign'=>['id'=>'123','name'=>'Campanha QA','ads_url'=>$base['fields']['Abrir campanha']],'ad_group'=>['ads_url'=>'https://ads.google.com/aw/ads?campaignId=123&adGroupId=67'],'headlines'=>['Título QA'],'descriptions'=>['Descrição QA'],'final_urls'=>['https://example.test/form'],'media'=>[['type'=>'youtube','thumbnail_url'=>$media,'watch_url'=>'https://www.youtube.com/watch?v=0123456789a']]];
            $r=F3Base_Anuncio_Origem::projetar($base,$d);
        }
        $crm=['nova'=>$p!=='linkedin','url'=>'https://fixture.pipedrive.com/deal/123'];
        $m=F3Base_Slack_Thread::mensagens($a,$crm,$r['fields'],'F123ABC');
        $check(array_keys($m)===[0,1,2,3,4],$p.'_thread_cinco');
        $check(array_column(array_column(array_map(static fn($v)=>$v['blocks'][0],$m),'text'),'text')===[ $m[0]['blocks'][0]['text']['text'],'Acontecimento · Solicitação','Origem','Visitas','Links'],$p.'_ordem');
        $check(str_contains($m[0]['text'],'Diretoria') && str_contains($m[0]['text'],'Assessoria') && str_contains($m[1]['text'],'Resposta sintética') && str_contains($m[1]['text'],wp_date('d/m/Y H:i:s P',strtotime($at))),$p.'_campos_hora_real');
        $check($r['media']===$media && !str_contains(wp_json_encode($m),'assinada') && end($m[2]['blocks'])['slack_file']['id']==='F123ABC',$p.'_imagem_slack_por_id');
        $check(str_contains($m[2]['text'],'Título QA') && str_contains($m[3]['text'],$crm['nova']?'Lead novo':'Contato repetido') && str_contains($m[4]['text'],$crm['url']),$p.'_conteudo_comercial');
        $check(!str_contains(F3Base_Anuncio_Entrega::html($r['fields']),'assinada') && str_contains(F3Base_Anuncio_Entrega::html($r['fields']),'[IA] Anúncio de origem'),$p.'_nota_estavel');
        ob_start();F3Base_Anuncio_Entrega::ficha($a);$ficha=ob_get_clean();
        $check(str_contains($ficha,'Consultar anúncio na plataforma') && str_contains($ficha,'_wpnonce') && !str_contains($ficha,'assinada'),$p.'_ficha_consulta_com_nonce');
        $all[$p]=['a'=>$a,'r'=>$r];
    }
    $org=$a;unset($org['origem_nativa']);$org['atribuicao']=[];$org['metodo']='email';$org['email_mensagem']=['texto'=>'Corpo da mensagem QA'];
    $m=F3Base_Slack::mensagens($org);$check(array_keys($m)===[0,1,4] && str_contains($m[1]['text'],'Corpo da mensagem QA'),'organico_sem_origem_visitas');
    $org['atribuicao']=['plataforma'=>'google_ads','campanha_id'=>'123','conta_id'=>'1234567890','anuncio_id'=>'456','utm_medium'=>'cpc'];
    $org['consentimento_historico']=['publicidade'=>true];$check(isset(F3Base_Slack::mensagens($org)[2]),'site_contrato_pago');
    $org['consentimento_historico']['publicidade']=false;$check(!F3Base_Anuncio_Origem::base($org),'site_sem_permissao');
    return $all;
}
