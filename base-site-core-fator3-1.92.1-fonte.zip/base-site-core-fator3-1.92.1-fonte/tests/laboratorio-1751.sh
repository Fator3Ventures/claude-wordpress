#!/usr/bin/env bash
# Start a disposable MySQL 8.0 instance, then run a clean install and the direct upgrade.
set -euo pipefail
: "${F3BASE_MYSQL_BASEDIR:?Informe o diretório base do MySQL.}"
: "${F3BASE_MYSQLD:?Informe o executável mysqld.}"
: "${F3BASE_WORDPRESS_ARCHIVE:?Informe o ZIP do WordPress 7.1.4.}"
: "${F3BASE_PHP:=php}"
src_root="$(cd "$(dirname "$0")/.." && pwd)"
lab_root="$(mktemp -d "${TMPDIR:-/tmp}/f3core-1751.XXXXXX")"
export F3BASE_LAB_PORT="${F3BASE_LAB_PORT:-33575}"
case "$F3BASE_LAB_PORT" in ''|*[!0-9]*) exit 2;; esac
if (echo >"/dev/tcp/127.0.0.1/$F3BASE_LAB_PORT") 2>/dev/null; then
  echo 'Escolha uma porta local livre com F3BASE_LAB_PORT.' >&2
  exit 2
fi
mkdir "$lab_root/db" "$lab_root/files"
"$F3BASE_MYSQLD" --no-defaults --basedir="$F3BASE_MYSQL_BASEDIR" --datadir="$lab_root/db" --initialize-insecure >"$lab_root/init.log" 2>&1
"$F3BASE_MYSQLD" --no-defaults --basedir="$F3BASE_MYSQL_BASEDIR" --datadir="$lab_root/db" --port="$F3BASE_LAB_PORT" --bind-address=127.0.0.1 --socket= --mysqlx=0 --pid-file="$lab_root/db/mysql.pid" --secure-file-priv="$lab_root/files" >"$lab_root/mysql.log" 2>&1 &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true; wait "$server_pid" || true' EXIT
for attempt in {1..60}; do
  kill -0 "$server_pid"
  if (echo >"/dev/tcp/127.0.0.1/$F3BASE_LAB_PORT") 2>/dev/null; then break; fi
  sleep .3
done
for phase in fresh upgrade; do
  F3BASE_PHASE="$phase" python3 "$src_root/tests/run-1750.py" --wordpress-archive "$F3BASE_WORDPRESS_ARCHIVE" --php "$F3BASE_PHP" --lab "$lab_root/$phase"
done
if [[ -n "${F3BASE_IMPLANTADOR:-}" ]]; then
  F3BASE_TEST_PHASE=patch F3BASE_ALLOW_LOCAL_TESTS=1 F3BASE_SITE="$lab_root/fresh/fresh/wordpress/wp-load.php" "$F3BASE_PHP" "$src_root/tests/implantador-379.php"
fi
echo "Laboratório e logs: $lab_root"
