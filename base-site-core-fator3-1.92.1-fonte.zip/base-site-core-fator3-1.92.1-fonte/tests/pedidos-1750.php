<?php
/** WordPress nativo descartável. Todos os registros e identificadores são sintéticos. */
require __DIR__.'/bootstrap.php';
function write1750($name,$value){
    $r=F3Base_Options::gravar($name,$value);
    if(empty($r['persisted'])){throw new RuntimeException("Falha em ".$name.": ".($r['motivo']??$r['codigo']));}
    return $r;
}
$user=wp_get_current_user();$user->add_cap("f3base_gerir_leads");$user->add_cap("f3base_ler_leads");
check(F3BASE_PLUGIN_VERSAO==='1.75.1','versao_ativa');
foreach(['nenhuma'=>'','mensal'=>'f3base_mensal','semanal'=>'weekly'] as $freq=>$sched){
    $result=write1750('f3base_cadencia',['periodicidade'=>$freq,'apos_n_ajustes'=>10]);
    check(F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada()===$sched,'agenda_'.$freq);
}
wp_clear_scheduled_hook(F3Base_Modulo_Cadencia_Relatorio::HOOK);
check(F3Base_Modulo_Cadencia_Relatorio::reconciliar()['ok']&&wp_next_scheduled(F3Base_Modulo_Cadencia_Relatorio::HOOK)>time(),'reparo_agenda_ausente');
check(F3Base_Options::ler('f3base_meta_pixels_adicionais')===[],'pixels_padrao_vazio');
write1750('f3base_meta_pixel_id','1234567');
write1750('f3base_meta_pixels_adicionais',['1234567','7654321','7654321']);
$meta=F3Base_Modulo_Tracking::dados_de_medicao()['meta'];
check($meta['pixelId']==='1234567'&&$meta['pixelsAdicionais']===['7654321'],'pixels_normalizados_unicos');
check(F3Base_Modulo_Meta_Capi::pixel_id()==='1234567','capi_um_destino');
check(empty(F3Base_Options::gravar('f3base_meta_pixels_adicionais',['bad/id'])['persisted']),'pixel_invalido_recusado');
$cfg=F3Base_Email_Site_Config::padroes();$cfg['endereco']='in@example.test';
foreach(['comum','cabecalho','automatico'] as $i=>$case){
    $partial=['bytes'=>2400000,'cabecalho_excedido'=>$case==='cabecalho','anexos'=>[['nome'=>'prova.pdf','bytes_transferencia'=>2200000]],'texto'=>''];
    $raw="From: Pessoa QA <qa@example.test>\r\nTo: in@example.test\r\nSubject: [TESTE F3BASE] $case\r\n".($case==='automatico'?"Auto-Submitted: auto-replied\r\n":"")."\r\n";
    $parsed=F3Base_Email_Mime::parse($raw,$cfg,$partial);
    check($parsed['classe']==='suspeito'&&$parsed['email']==='qa@example.test'&&$parsed['bytes_mensagem']===2400000&&$parsed['anexos_nomes']===['prova.pdf'],'mensagem_'.$case);
    if($case==='automatico'){check($parsed['descarte_original']==='resposta_automatica','sinal_descarte_original');}
    $msg=['uidvalidity'=>2,'uid'=>21+$i,'excedida'=>true,'bytes'=>2400000,'recebida_em'=>time(),'raw'=>$raw];
    if($i===2){F3Base_Email_Site::persistir($msg,['classe'=>'descartado','motivo'=>'resposta_automatica'],'qa1750');}
    $r=F3Base_Email_Site::persistir($msg,$parsed,'qa1750',true);
    check(!empty($r['record_id'])&&F3Base_Leads_Repositorio::obter($r['record_id'])['captura']==='suspeito','contato_gravado_'.$case);
}
$cfg['descartes_acima_limite']=['resposta_automatica'];
check(F3Base_Email_Mime::parse($raw,$cfg,$partial)['classe']==='descartado','excecao_explicita');
$key='cache-reaquecimento';$opt='f3base_trava_'.hash('sha256',$key);
update_option($opt,'invalida',false);$lock=F3Base_Trava::adquirir($key,30);
check($lock!==null && F3Base_Trava::inspecionar($key)['vigente'],'reserva_malformada_recuperada');
$preview=F3Base_Cache_Reaquecimento::liberar_reserva([]);
check(F3Base_Cache_Reaquecimento::liberar_reserva(['simular'=>false,'motivo'=>'Verificar dono ativo','revisao'=>$preview['revisao']])['codigo']==='dono_vigente','reserva_ativa_preservada');
F3Base_Trava::liberar($lock);update_option($opt,['dono'=>'qa','expira'=>time()-10],false);
$prev=F3Base_Cache_Reaquecimento::liberar_reserva([]);
check(F3Base_Cache_Reaquecimento::liberar_reserva(['simular'=>false,'motivo'=>'Reserva expirada no laboratório','revisao'=>$prev['revisao']])['ok'] && F3Base_Trava::inspecionar($key)===null,'liberacao_auditada');
$defs=F3Base_Modulo_Tracking::eventos_de_comportamento();
check($defs['f3base_clique_inerte']['teto']===30&&$defs['f3base_friccao']['teto']===15,'tetos_30_15');
$bc=F3Base_Options::ler('f3base_comportamento');$bc['teto_clique_inerte']=19;write1750('f3base_comportamento',$bc);
check(F3Base_Modulo_Tracking::eventos_de_comportamento()['f3base_clique_inerte']['teto']===19,'teto_configuravel');
check(F3Base_Modulo_Comportamento::alvo_evento('f3base_clique_inerte','socios~socios:titulo:2')['f3base_alvo']==='socios:titulo:2','projecao_alvo');
check(F3Base_Modulo_Comportamento::alvo_evento('f3base_friccao','4')['f3base_alvo']==='nao_observado','alvo_legado');
$html=F3Base_Conteudo_Instrumentacao::html('<html><body><main class="f3base-secao-socios"><p data-f3base-alvo="equipe">A</p><p>B</p></main></body></html>',home_url('/'));
check(count($html['textos_sem_alvo'])===1,'auditoria_texto_sem_alvo');
$form=json_decode(file_get_contents(__DIR__.'/formulario-1750.json'),true);write1750('f3base_formularios',[$form]);$f=F3Base_Formularios::obter('contato-whatsapp');
$ability=wp_get_ability('f3base/caminho-lead-testar');
$preview=$ability->execute(['formulario'=>$f['id'],'campos'=>['contato'=>'11999990000'],'simular'=>true]);
if(is_wp_error($preview)){throw new RuntimeException($preview->get_error_code().' '.$preview->get_error_message());}if(empty($preview['ok'])){throw new RuntimeException(json_encode($preview));}
check(!is_wp_error($preview)&&!empty($preview['simulado']),'telefone_escalar_ability_nativa');
$invalid=$ability->execute(['formulario'=>$f['id'],'campos'=>['contato'=>['abc']]]);
check(!is_wp_error($invalid)&&$invalid['campo']==='contato'&&!empty($invalid['motivo']),'lista_invalida_identifica_campo');
$settings=F3Base_Options::ler(F3Base_Formulario_Tentativas::OPTION);
check(empty($settings['capturar_abandono']),'abandono_desligado_padrao');
$session=bin2hex(random_bytes(16));$inst=bin2hex(random_bytes(16));$token=F3Base_Formularios::emitir($f,$inst,1,true);
$req=['formulario'=>$f['id'],'instancia'=>$inst,'sessao'=>$session,'evento'=>bin2hex(random_bytes(16)),'sequencia'=>1,'etapa'=>1,'tipo'=>'abandono','ocorrido_ms'=>time()*1000,'token'=>$token,'campos'=>[['nome'=>'seu-nome','estado'=>'preenchido','valor'=>'Pessoa Sintética','regras'=>[]],['nome'=>'seu-email','estado'=>'preenchido','valor'=>'foto@example.test','regras'=>[]]]];
check(F3Base_Formulario_Tentativas::receber($req)['codigo']==='abandono_nao_autorizado','servidor_recusa_desligado');
$settings['capturar_abandono']=true;$settings['abandono_exige_medicao']=false;$settings['capturar_valores']=false;write1750(F3Base_Formulario_Tentativas::OPTION,$settings);
$first=F3Base_Formulario_Tentativas::receber($req);check($first['ok'],'fotografia_inicial');
$old=$req;$req['sequencia']=3;$req['campos'][1]['estado']='vazio';$req['campos'][1]['valor']='';
check(F3Base_Formulario_Tentativas::receber($req)['ok']&&F3Base_Formulario_Tentativas::receber($old)['duplicado'],'ordem_e_reenvio');
$table=F3Base_Formulario_Tentativas::tabela();$raw=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE instancia=%s',$table,$inst),ARRAY_A);
check(count($raw)===1&&str_starts_with($raw[0]['valores'],'f3tent:v1:')&&!str_contains(json_encode($raw),'Sint'),'unica_linha_cifrada');
$rows=F3Base_Formulario_Tentativas::consultar(['sessao'=>$session])['linhas'];
check(count($rows)===1&&$rows[0]['campos'][0]['valor']==='Pessoa Sintética'&&$rows[0]['campos'][1]['valor']==='','releitura_campo_apagado');
$unknown=F3Base_Editorial_Relatorios::abandono([]);check($unknown['campos_preenchidos']==='nao_observado','abandono_sem_prova');
$observed=F3Base_Editorial_Relatorios::abandono(['ultimo_campo'=>'seu-nome','etapa'=>1,'campos_preenchidos'=>1]);check($observed['etapa']===1&&$observed['ultimo_campo']==='seu-nome','abandono_metadados');
wp_set_current_user(0);check(!F3Base_Formulario_Tentativas::consultar(['sessao'=>$session])['ok'],'valor_privado');wp_set_current_user(1);
check(F3Base_Formulario_Tentativas::apagar_titular('foto@example.test')['items_removed']&&F3Base_Formulario_Tentativas::receber($req)['codigo']==='sessao_eliminada','eraser_apos_email_apagado');
$nav=bin2hex(random_bytes(16));$common=['visitante'=>bin2hex(random_bytes(16)),'sessao'=>$session,'navegacao'=>$nav,'dispositivo'=>'movel','caminho'=>'/qa/','criado_em'=>time()-10,'recebido_em'=>time(),'atribuicao'=>'{}','qualidade'=>'observada','payload_hash'=>str_repeat('b',64),'inicio_sessao'=>time()-20];
foreach(['pagina','form_inicio','form_fechado'] as $type){
 $item=$common+[];$item['evento']=bin2hex(random_bytes(16));$item['tipo']=$type;
 if($type!=='pagina'){$item['formulario']=$f['id'];$item['formulario_revisao']=F3Base_Formularios::revisao($f);$item['correlacao']=$inst;}
 if($type==='form_fechado'){$item+=['ultimo_campo'=>'seu-nome','etapa'=>1,'campos_preenchidos'=>1,'detalhe'=>'saida_sem_aceite_observado'];}
 check($wpdb->insert(F3Base_Analise::tabela(),$item)===1,'evento_relatorio_'.$type);
}
$eventBase=['dia'=>wp_date('Y-m-d'),'classe_trafego'=>'nao_marcado','visitante'=>$common['visitante'],'sessao'=>$session,'navegacao'=>$nav,'caminho'=>'/qa/','criado_em'=>time()-2,'recebido_em'=>time(),'ancora'=>'observada'];
$tableEvents=F3Base_Modulo_Comportamento::nome_tabela_eventos();
foreach([$nav,bin2hex(random_bytes(16))] as $navClose){
 $row=array_replace($eventBase,['metrica'=>'f3base_form_fechado','detalhe'=>'contato-whatsapp:oferta_fechada','navegacao'=>$navClose]);
 if($wpdb->insert($tableEvents,$row)!==1){throw new RuntimeException('Falha na semente de fechamento histórico');}
}
for($i=1;$i<=10;$i++){
 $target=$i===1?'equipe':'socios:titulo:'.$i;
 $row=$eventBase+['metrica'=>'f3base_clique_inerte','detalhe'=>'socios~'.$target,'ocorrencia'=>$i];
 if($wpdb->insert($tableEvents,$row)!==1){throw new RuntimeException('Falha na semente de cliques');}
}
$report=wp_get_ability('f3base/sessao-detalhar')->execute(['sessao'=>$session]);
$closes=array_values(array_filter($report['linhas']??[],static fn($v)=>($v['acao']??'')==='form_fechado'));
check(count($closes)===1&&$closes[0]['ultimo_campo']==='seu-nome'&&$closes[0]['etapa']===1&&$closes[0]['campos_preenchidos']===1,'sessao_detalhar_fechamento_real');
check(!str_contains(wp_json_encode($report),'Pessoa Sint'),'sessao_sem_valor');
$legacy=array_filter($report['linhas'],static fn($v)=>str_contains($v['detalhe']??'','oferta_fechada'));
check(count($legacy)===2&&!array_filter($legacy,static fn($r)=>($r['ultimo_campo']??null)!=='nao_observado'||($r['etapa']??null)!=='nao_observado'||($r['campos_preenchidos']??null)!=='nao_observado'),'legado_pareado_e_nao_pareado_sem_inferencia');
$targets=array_values(array_filter($report['linhas'],static fn($r)=>($r['f3base_secao']??null)==='socios'));
check(count($targets)===10&&in_array('equipe',array_column($targets,'f3base_alvo'),true)&&in_array('socios:titulo:10',array_column($targets,'f3base_alvo'),true),'dez_alvos_na_sessao');
check(F3Base_Editorial_Relatorios::abandono(['etapa'=>1])['campos_preenchidos']==='nao_observado','contagem_sem_prova');
check(F3Base_Editorial_Relatorios::abandono(['etapa'=>1,'campos_preenchidos'=>0])['campos_preenchidos']===0,'zero_observado');

$integrated=wp_get_ability('f3base/relatorios-integrados-ler')->execute(['visao'=>'formularios','sessao'=>$session]);
if(is_wp_error($integrated)||empty($integrated["ok"])||!str_contains(wp_json_encode($integrated),"seu-nome")){throw new RuntimeException(substr(wp_json_encode($integrated),0,5000));}
check(!is_wp_error($integrated)&&!empty($integrated['ok'])&&str_contains(wp_json_encode($integrated),'seu-nome'),'relatorio_com_filtro_sessao');
$lead=wp_get_ability('f3base/caminho-lead-testar')->execute(['formulario'=>$f['id'],'campos'=>['contato'=>'11999990000'],'simular'=>false,'chave_operacao'=>'percurso-local-1750','revisao'=>$preview['revisao']]);
check(!is_wp_error($lead)&&!empty($lead['id']),'recibo_iniciado');
for($i=0;$i<25&&empty($lead['resultado_final']);$i++){
 $wpdb->update(F3Base_Caminho_Lead::tabela(),['proxima'=>time()-1],['id'=>$lead['id']]);
 $lead=F3Base_Caminho_Lead::processar($lead['id']);
}
check(!empty($lead['resultado_final'])&&!empty($lead['recibo']['saltos']),'recibo_terminal');
$when=time()-200;$event=['id'=>'reaquecimento','hook'=>F3Base_Cache_Reaquecimento::EVENTO,'args'=>[],'timestamp'=>$when];
$added=F3Base_Operacao_Intencoes::adiar($event,'orcamento_esgotado');
check($added['status']==='aguardando'&&$added['tentar_em']<=time()+1,'orcamento_elegivel_proxima_passagem');
evidence('pedidos-1750',['estado_recibo'=>$lead['estado']]);
