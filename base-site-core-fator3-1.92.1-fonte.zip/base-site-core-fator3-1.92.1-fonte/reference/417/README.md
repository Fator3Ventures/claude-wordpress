# Catálogo de aparelhos do pedido 417

O arquivo `supported_devices.csv` é a cópia integral UTF-16 da lista Google Play consultada em 15/11/2026. SHA-256 `74f0ced35bdfa216580c030477db29be01f5cc3e62e7196855c7519503d735bd`. O catálogo anterior permanece em `../415/catalogo-aparelhos.csv` como entrada do gerador. [Fonte do Google](https://storage.googleapis.com/play_public/supported_devices.csv).

## Identificação

O gerador agrupa por Model, despreza diferenças de caixa e reduz espaços repetidos. Entre os 93 códigos com mais de um Marketing Name, 59 têm um nome comercial igual ao próprio código. Essa linha identifica o conjunto de pares (Retail Branding, Device) admissíveis. O nome atual só pode ser conservado se apontar para um desses pares. Assim permanecem os nomes regionais razr 60 ultra, razr 70 e moto g87. Para os 34 códigos ambíguos sem linha própria, o gerador conserva a escolha da base e grava as alternativas e os respectivos pares em `ambiguidades-sem-linha-propria.csv`.

O Google usa Moto G(8) e a ficha de varejo usa Moto G8. O gerador reconhece parênteses desse tipo nas séries Moto G e Moto E e mantém sinais de variante como + e 5G. As grafias de varejo já documentadas para SP2 e M7_WIFI estão em `nomes-editoriais.csv`. Uma linha literal existente no Google tem precedência sobre uma equivalência editorial.

As 12 fichas aprovadas, com Device, idade do modelo, preço e fonte por aparelho, ficam em `fichas-pesquisadas.csv`. Ao detectar em futuras bases um cruzamento com outro Device, o gerador exige os dados comerciais do aparelho correto. A ordenação das linhas da lista do Google não escolhe a ficha. O arquivo completo `catalogo-aparelhos.csv` é a saída.

## Preço e classificação em 15/11/2026

Aplicam-se a [regra do pedido 413](../413/escopo-catalogo.md) e a decisão posterior de preencher um preço positivo mesmo sem oferta nacional adequada. A faixa expressa a posição da família no lançamento. As linhas Edge sem sufixo, Edge Pro e Razr entram como topo e premium. Moto G51, G Stylus 5G e G 5G de 2022 são intermediários. O G 2025 básico, o G Play 2024 e o G8 Power Lite são de entrada. A linha Moto G é não premium em todos esses casos.

As fontes individuais distinguem preço anunciado em reais, mercado secundário, preço convertido e estimativa por comparável. Valores estrangeiros são referências simples em BRL, sem simulação de frete ou tributos. USD × 5,6518 e EUR × 6,2334, taxas de venda do último dia útil, 13/11/2026, com arredondamento a centavos. Para o Razr 2022, a avaliação considera 90% do valor brasileiro de um Razr 40 usado. O percentual é uma hipótese explícita. [Dólar](https://www.financebr.com/cotacao-hoje/USD) e [euro](https://captario.com.br/cotacao/euro/2026-11-13).

O Edge 20 Pro e o G51 foram anunciados em 2021. O Edge 40 Pro é de 2023. As edições americanas e o Razr levam o ano do anúncio no próprio nome. O G8 Power Lite foi anunciado em 3 de abril de 2020. [Linha Motorola](https://www.oficinadanet.com.br/motorola/produtos), [Edge 40 Pro](https://www.oficinadanet.com.br/smartphones/motorola-edge-40-pro), [G8 Power Lite](https://www.oficinadanet.com.br/smartphones/motorola-moto-g8-power-lite), [edições G de 2022](https://www.tomsguide.com/news/moto-g-stylus-5g-2022-moto-g-5g) e [Razr 2022](https://www.tecmundo.com.br/celular/253300-moto-razr-2022-lancado-globalmente-preco-competitivo.htm).
