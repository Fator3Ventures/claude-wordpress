# Site Core 413 — catálogo de aparelhos

Nov 15, 2026 · @Fator3

Lista que acompanha o Pedidos core 413 (b) e (d): 359 aparelhos Android vendidos no Brasil, lançados de 2020 a 2026, com os 1.156 códigos de modelo que o navegador envia para eles, o nome comercial, o ano de lançamento, o preço atual estimado e uma faixa sugerida. Marcas: Samsung (120 aparelhos, 685 códigos), Xiaomi com Redmi e POCO (103, 275), Motorola (91, 133) e realme (45, 63).

## Fontes

- Código e nome comercial: lista de aparelhos compatíveis do Google Play, [supported\_devices.csv](https://storage.googleapis.com/play_public/supported_devices.csv), baixada em 15/11/2026. O código é o campo Model, o mesmo valor que o navegador informa em `navigator.userAgentData` (modelo). Exceção: moto g17, ausente da base; a Motorola usa o nome comercial como código.
- Ano de lançamento e preço: páginas de produtos da Oficina da Net ([Samsung](https://www.oficinadanet.com.br/samsung/produtos), [Motorola](https://www.oficinadanet.com.br/motorola/produtos), [Xiaomi](https://www.oficinadanet.com.br/xiaomi/produtos), [realme](https://www.oficinadanet.com.br/realme/produtos)), lidas em 15/11/2026. O ano é o do anúncio do aparelho. O preço é a menor oferta listada em lojas no Brasil naquele dia, aparelho novo, versão de entrada.

## Regras da lista

- Preço descartado (29 aparelhos, 110 códigos): quando a oferta listada contradiz a própria linha do fabricante, por exemplo acima do modelo superior ou do sucessor, a coluna de preço fica vazia e a observação traz o valor da fonte.
- Sem oferta listada (24 aparelhos, 61 códigos): coluna de preço vazia.
- Faixa sugerida pela posição do aparelho na linha do fabricante, não pelo preço de hoje: um topo de linha de 2021 vendido hoje por R$ 2 mil continua topo.
  - Entrada: Galaxy A0x, A1x, M0x e M1x; moto e; moto g04 a g37 e g(10), g(20), g(30) e g(9) play; Redmi numérico, Redmi A e POCO C; realme C.
  - Intermediário: Galaxy A2x a A7x e M2x a M6x; moto g41 a g87, g(9) plus e power, g(50), g(60); motorola edge fusion, neo e lite; Redmi Note, POCO M, POCO X e Xiaomi Lite; realme numérico.
  - Topo: Galaxy S e Z; motorola razr; motorola edge sem sufixo, pro e ultra; moto g(100) e g200; POCO F; Xiaomi numérico com T; realme GT.
- Samsung: a última letra do código muda por região (SM-A175F, SM-A175N). A base do Google Play não tem todas as variantes brasileiras: em 15/11/2026 faltava SM-A175M (Galaxy A17).
- Fora da lista: iPhone (o navegador não informa o modelo), tablets e marcas com pouca venda no Brasil.

Linha premium (coluna linha\_premium, sim ou não; dono, 15/11/2026 às 09:41): "sim" para a linha principal de cada marca, independentemente do preço de hoje: Samsung Galaxy S e Galaxy Z; motorola razr e motorola edge sem fusion, neo ou lite; Xiaomi numérico (sem Lite) e POCO F; realme GT. Redmi, POCO M, POCO X, Galaxy A e M, moto e e moto g ficam "não", inclusive moto g(100) e g200, que têm faixa topo. Total: 97 aparelhos, 459 códigos.

## Arquivo

Colunas: codigo, marca, nome\_comercial, ano\_lancamento, preco\_atual\_estimado\_brl, faixa\_sugerida, linha\_premium, observacao.

Arquivo `site-core-413-aparelhos.csv`, UTF-8, separador vírgula, ponto decimal no preço, 1.156 linhas mais o cabeçalho, uma por código:

Versão de 15/11/2026, com a coluna linha\_premium:

&#91;image: site-core-413-aparelhos.csv\]
