# Identificação do LG Q60

LM-X525 aparece como LG Q60, LM-X525 e X6(2019) na base do Google, com a mesma marca LGE e o mesmo Device mmh4p. O nome brasileiro K12 Prime identifica o modelo de referência de 64 GB. Preço estimado de R$ 259 com base no seminovo nacional Trocafone, consultado em 16/11/2026. Série intermediária da LG em 2019, sem indicação de linha premium. [Referência de preço](https://www.trocafone.com/celulares?badge=34&color=1&model=1028).

O Q60 foi anunciado em fevereiro de 2019. O K12 Prime brasileiro é a variante X525BAW usada para estimar preço e posição na linha. [Q60](https://canaltech.com.br/produto/lg/q60/), [K12 Prime](https://canaltech.com.br/produto/lg/k12-prime/) e [variantes regionais](https://www.maiscelular.com.br/comparar/celulares/lg-k12-prime-x525baw-vs-lg-q60-x525ha/11379277).
