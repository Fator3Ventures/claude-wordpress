# Fichas brasileiras — consulta de 17/11/2026

- Redmi 15: referência Google Play de 15/11/2026, Model 25062RN2DE/DL/DY, Device creek. Modelo BR 25062RN2DA indicado no pedido 427. Ficha técnica oficial 4G Snapdragon 685: https://www.mi.com/global/support/faq/details/KA-592870/
- Preço Redmi 15: anúncio direto de varejo Magalu, 256 GB/8 GB/4G, R$ 1.439,99 no Pix; outros anúncios observados em torno de R$ 1.517–1.521. Estimativa arredondada R$ 1.500 para 2026. https://www.magazineluiza.com.br/smartphone-xiaomi-redmi-15-256gb-8gb-ram-4g-snapdragron-685tela-fluida-144hz-selfie-com-luz/p/ghd4h2h864/te/rd15/
- LG K40: nome brasileiro indicado pelo usuário; Google Play relaciona LM-X420 e LM-X420N por mmh4, nome publicado X4(2019). Lançamento K40 em comunicado oficial LG de 20/02/2019: https://www.lg.com/global/newsroom/news/corporate/designed-with-solid-fundamentals-new-lg-q-and-k-series-are-designed-to-impress/
- Preço LG K40 usado: R$ 200 no anúncio direto OLX de Belo Horizonte, datado 27/10 e consultado 17/11. É estimativa do aparelho usado, sem equiparação ao preço de lançamento. https://www.olx.com.br/celulares/lg/estado-mg/belo-horizonte — anúncio https://mg.olx.com.br/belo-horizonte-e-regiao/celulares/celular-lg-k40-1547988443

## Critério e contagem

As 2.449 ocorrências citadas no pedido são um ponto de partida de auditoria, não uma meta a forçar. O resultado do compilador considera nome comercial diferente do próprio Model do candidato, elimina grafias e sufixos regionais, rejeita Device vazio e trata colisão de marcas como ambiguidade. Lista completa de decisões em decisoes-device.csv e de famílias aceitas/rejeitadas em familias.csv. O teste independente percorre os 44.528 códigos; nenhuma identificação comercial entre modelos fica sem origem no CSV.

Os arquivos CSV são insumos de compilação e rastreabilidade dentro do fonte. Não constituem entrega avulsa.
