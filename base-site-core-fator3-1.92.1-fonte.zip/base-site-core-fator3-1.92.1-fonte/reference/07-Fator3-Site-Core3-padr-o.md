# Padrão de entrega — Fator3 Site Core (base-site-core-fator3)

Para o agente responsável pelo Fator3 Site Core. Vale a partir da próxima versão; a regra comum aos pacotes está na aba "Regra comum", e o essencial vai repetido aqui.

## Arquivos

| tipo | nome | conteúdo |
| --- | --- | --- |
| instalador | `base-site-core-fator3-<versão>-instalador.zip` | pasta interna `base-site-core-fator3/`, arquivo principal `base-site-core-fator3/base-site-core-fator3.php` |
| fonte | `base-site-core-fator3-<versão>-fonte.zip` | pasta interna `base-site-core-fator3-<versão>-fonte/`: código, testes, schemas, fixtures, geradores, evidências e uma cópia do relatório |
| relatório | `base-site-core-fator3-<versão>-relatorio.md` | Markdown, em português |

Versão `X.Y.Z`, sem sufixo; homologação e sha256 só dentro do relatório. Os encaminhamentos aos outros pacotes vão em seção do relatório ou em arquivo com o prefixo `base-site-core-fator3-<versão>-`. O relatório cita os arquivos por esses nomes.

## Cabeçalho e tela

O cabeçalho fica assim:

| campo | valor |
| --- | --- |
| Plugin Name | Fator3 Site Core |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | Núcleo dos sites Fator3: medição de visitas, robôs e assistentes de IA; contatos e formulários; consentimento; dados estruturados, /llms.txt, robots.txt, cabeçalhos e redirects; integrações opcionais com Pipedrive, Meta, Google, LinkedIn e Clarity. Requer PHP de 64 bits e instalação única (sem multisite). |
| Requires at least, Requires PHP | os validados pela versão (1.75.1: 7.1.4 e 8.3, 64 bits) |
| Author | Fator3 |
| Author URI | `https://www.fator3.com.br` |
| License | GPL-2.0-or-later |
| Text Domain | `f3base` |
| Update URI | `https://fator3.com.br/plugins/base-site-core-fator3` |

Telas: menu "Site Core" com o título "Fator3 Site Core"; os menus "Contatos" e "Medição" ficam. Em modo de recuperação o menu também se chama "Site Core". Tela e operações com `manage_options`.

## O que não muda

Slug e pasta `base-site-core-fator3`, arquivo principal, Text Domain `f3base`, Update URI, o prefixo `f3base_` de options, tabelas e eventos, as rotas `f3base/*`, a sentinela em `wp-content/f3-core-state/` e os nomes dos arquivos de `docs/` que a frota cita (`OPERACAO-E-RECUPERACAO.md`, `DOCUMENTACAO.md`, `RELEASE-<versão>.md`).

## Relatório

Nesta ordem:

1. Título `Entrega — Fator3 Site Core <versão>`.
2. De onde a versão entra (WordPress limpo e as versões aceitas direto) e a versão intermediária que não se instala.
3. Contrato de configuração, perfil do piso (`piso-padrao-*`), número de options operáveis e de abilities, com as abilities que entram e saem.
4. Versões do Fator3 MCP e do Fator3 MCP Google com que a entrega foi validada, e a ordem de troca quando um contrato comum muda.
5. O que mudou, citando cada "Pedidos core N" atendido, com a evidência.
6. Prova da troca: `atualizacao` do `f3base/como-usar` com `versao_alvo`, `estado` concluída, `falhas` 0 e `confirmada_no_executor_em`; o tempo esperado até a confirmação.
7. Banco e volta de versão: etapas do ciclo de instalação, options e tabelas novas, o que a volta de arquivos não desfaz.
8. O que não foi exercitado ou homologado (contas reais, destinos externos, navegador).
9. Segredos novos que o dono cola na tela; nenhum valor de segredo.
10. Identidade: nome, tamanho e sha256 do instalador e da fonte.

## Conformidade da 1.75.1 (09/11/2026)

Lida no `main` (commit `e3580d3`): instalador `base-site-core-fator3-1.75.1-instalador.zip` (4.372.056 bytes, sha256 `9fff30dc…`) com a pasta `base-site-core-fator3/` e o arquivo principal; fonte `base-site-core-fator3-1.75.1-fonte.zip` (9.315.610 bytes, sha256 `ebc04d4f…`) com a pasta `base-site-core-fator3-1.75.1-fonte/`; os dois sha256 no relatório, iguais aos dos arquivos; nenhum ZIP dentro de outro; o encaminhamento ao implantador em arquivo com o prefixo da versão (`base-site-core-fator3-1.75.1-impacto-implantador-base.md`). Título `Entrega — Fator3 Site Core 1.75.1`; cabeçalho como acima. Nenhum pedido aberto sobre a entrega.

## Fora do escopo (decisão do dono)

Não se pede ao Site Core:

- DNS reverso e direto para identificar robô sem lista de faixas publicada (dono, 30/09/2026). Os operadores que importam para a Medição publicam faixas, e a consulta de DNS exige execução assíncrona e reclassificação de agregados já publicados. Pedir de novo só se um operador relevante aparecer sem lista.
- Canário diário do caminho do lead: contato de teste, aviso, Pipedrive em homologação e prévia de conversões todo dia, com limpeza no mesmo ciclo (dono, 28/10/2026 às 07:55: "Abra os pedidos. Não vamos fazer 7 e 8"). O teste ponta a ponta sob demanda segue.
- Marcos operacionais: leitura da primeira ocorrência real, por site, de cada caminho (entrega ao Pipedrive, atividade por canal, e-mail automático pela caixa, e-mail importado aceito, lead nativo da Meta e do LinkedIn, conversão pelo servidor por destino, eliminação com recibo) (mesma decisão).
