# Referências do pedido 428

O snapshot UTF-16 em reference/417 é a entrada comercial publicada pelo Google Play em 15/11/2026. O gerador novo distribui os registros em 256 fragmentos no runtime. As fichas brasileiras e seus preços permanecem em reference/427.

**revisao-412.csv** identifica todas as trocas com criterio=nome_google em reference/427/decisoes-device.csv, congelado como histórico. nome_1910 e nome_1920 foram confrontados com os fragmentos dos respectivos ZIPs originais. A coluna grupo_211 marca espaço no nome anterior, exatamente 211 registros. ficha_curada marca se a ficha brasileira já tinha precedência. A coluna nome_1921 mostra o índice Google Play, independentemente dessa sobreposição. A legenda dos motivos consta do relatório. O teste de regressão exige tanto a decisão aprovada para cada um dos 412 quanto a proteção universal dos 211.

**decisoes-device.csv** e **familias.csv** documentam as decisões da nova compilação. **outras-diferencas.csv** identifica todos os registros fora das 412 linhas em que a tupla publicada mudou, inclusive apenas o motivo ou a grafia; essas mudanças abrangem a filtragem direta de mercados e a remoção de ambiguidade indevidamente atribuída a nomes próprios.

**territorios.json** reúne nomes ISO 3166-1 e CLDR/ICU, macrorregiões ONU M49, siglas e grafias que o fornecedor utiliza para mercados. A atualização opcional é offline com Node e o arquivo de dados iso-codes do sistema: `node build/gerar-territorios.mjs`. O compilador normal usa a cópia versionada. A detecção exige correspondência com o rótulo inteiro ou com todos os elementos de uma enumeração. Novas grafias livres que o fornecedor inventar exigem reavaliação. Listas de mercados e nomes de produto com termos geográficos são exercitados em testes separados.

O gerador rejeita como nome alternativo um SKU compacto sem evidência comercial. Indícios aceitos incluem uma palavra de marca/série, palavra de produto por extenso, grafia internacional e ano comercial entre parênteses. Nomes de aparelhos muito curtos podem permanecer sem inferência. O Device compartilhado sozinho não resolve uma dúvida comercial.

O critério técnico, os exemplos, a precedência de regras locais e o procedimento de aceite estão em work/plugin/base-site-core-fator3/docs/RELEASE-1.92.1.md.
