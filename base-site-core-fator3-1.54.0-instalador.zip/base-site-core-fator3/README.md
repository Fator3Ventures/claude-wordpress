# Fator3 Site Core 1.54.0

Instalação nova ou atualização nativa da 1.53.0. Contrato administrativo 8.19.0. Leia docs/DOCUMENTACAO.md, docs/RELEASE-1.54.0.md e docs/AGENTES-1.54.0.md. A documentação instalada é legível integralmente por f3base/documentacao-ler.
