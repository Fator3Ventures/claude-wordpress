<?php
/** Site mailbox configuration and administrative UI. No implicit credential migration. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Site_Config {
    const OPTION='f3base_email_site';
    const SECRET='f3base_email_site_senha';
    const STATE='f3base_email_site_estado';
    public static function padroes(): array {return array('ativo'=>false,'envio_ativo'=>false,'endereco'=>'','imap_host'=>'imap.dreamhost.com','imap_porta'=>993,'smtp_host'=>'smtp.dreamhost.com','smtp_porta'=>465,'smtp_seguranca'=>'ssl','usuario'=>'','pasta_importados'=>'Importados','pasta_enviados'=>'Sent','nome_exibicao'=>'','assinatura'=>'','cco'=>array('korvena@korvena.net.br'),'smart_bcc'=>'','dominios_ignorados'=>array(),'termos_suspeitos'=>array(),'max_links'=>5,'homologacao'=>false,'homologacao_emails'=>array(),'authserv_ids'=>array(),'cota_destinatarios_hora'=>20,'alocacao_confirmada'=>false);}
    public static function ajuda(): array {return array(
        'ativo'=>'Lê somente mensagens recebidas depois da ativação. A caixa deve ser exclusiva deste site. Desligar pausa a consulta e preserva o cursor. Para importar histórico, use a operação manual por UID.',
        'envio_ativo'=>'Autoriza respostas administrativas e uso desta conta pelo e-mail automático. O envio continua exigindo contato registrado, prévia e revisão. Não ativa o e-mail automático.',
        'endereco'=>'Endereço exclusivo deste site, por exemplo contato.site@exemplo.com.br. A mensagem precisa mencionar este endereço em To, Cc ou cabeçalho de entrega.',
        'imap_host'=>'Servidor de leitura com certificado TLS válido. DreamHost: imap.dreamhost.com. Não informe protocolo, caminho ou IP privado.',
        'imap_porta'=>'993: TLS desde a abertura da conexão. STARTTLS e conexão sem proteção não são admitidos no leitor.',
        'smtp_host'=>'Servidor SMTP com certificado válido. DreamHost: smtp.dreamhost.com.',
        'smtp_porta'=>'465 para SSL/TLS direto ou 587 para STARTTLS. O envio verifica todos os destinatários antes de transmitir a mensagem.',
        'smtp_seguranca'=>'ssl usa TLS direto na porta 465; tls exige STARTTLS na porta 587. Não há modo sem criptografia.',
        'usuario'=>'Usuário completo da caixa, normalmente igual ao endereço. Cole a senha no campo protegido abaixo; ela nunca aparece nas leituras.',
        'pasta_importados'=>'Pasta para mensagens persistidas. O servidor precisa oferecer UID MOVE. Falha de movimentação fica pendente, sem criar outro contato.',
        'pasta_enviados'=>'Pasta que recebe a cópia IMAP APPEND após aceite SMTP. Falha ou resultado incerto da cópia nunca reenvia o e-mail.',
        'nome_exibicao'=>'Nome da marca apresentado no remetente. Não altera o nome do contato.',
        'assinatura'=>'Assinatura em texto simples, com quebras de linha. Links permanecem como digitados.',
        'smart_bcc'=>'Endereço Smart Bcc autorizado da conta Pipedrive. Usado nas respostas administrativas, somado às cópias do site. O e-mail automático usa o Smart Bcc do lead confirmado no CRM.',
        'cco'=>'Uma caixa por linha. Padrão da frota: korvena@korvena.net.br; pode ser removida ou substituída. Soma-se ao Smart Bcc configurado no Pipedrive e também vale no e-mail automático.',
        'dominios_ignorados'=>'Domínios do grupo, um por linha. Remetentes desses domínios ou subdomínios são descartados com motivo, sem contato/aviso comercial.',
        'termos_suspeitos'=>'Termos literais, um por linha, pesquisados no assunto e texto. Correspondência cria contato suspeito, aguardando aprovação para CRM.',
        'max_links'=>'Quantidade máxima de links HTTP(S) antes de classificar como suspeito. Zero marca qualquer link como suspeito.',
        'homologacao'=>'Restringe importação e envio aos remetentes/destinatários autorizados abaixo. Contatos ficam marcados como teste; respeitam a política de Slack/CRM do Core.',
        'homologacao_emails'=>'Caixas controladas autorizadas para testes. Em homologação, as cópias Cco/Smart Bcc também precisam constar nesta lista.',
        'authserv_ids'=>'Identidades confiáveis do servidor em Authentication-Results, uma por linha. Use as publicadas pela sua hospedagem. dmarc=fail é descartado; ausência de resultado confiável marca como suspeito.',
        'cota_destinatarios_hora'=>'Teto deste site: 1 a 99 destinatários na última hora, incluindo cópias. O mesmo contador atende respostas e e-mails automáticos. A cota de outros sites é responsabilidade da alocação da frota.',
        'alocacao_confirmada'=>'Confirme que a soma dos usos da conta cabe no limite do provedor. A confirmação não muda a cota remota.'
    );}
    public static function rotulos(): array {return array('ativo'=>'Importar e-mails','envio_ativo'=>'Habilitar envio pela caixa do site','endereco'=>'E-mail exclusivo do site','imap_host'=>'Servidor IMAP','imap_porta'=>'Porta IMAP','usuario'=>'Usuário da caixa','pasta_importados'=>'Pasta de importados','pasta_enviados'=>'Pasta de enviados','cco'=>'Cópias ocultas (Cco)','dominios_ignorados'=>'Domínios ignorados','termos_suspeitos'=>'Termos de suspeita','max_links'=>'Máximo de links','authserv_ids'=>'Servidores de autenticação confiáveis','homologacao'=>'Modo de homologação');}
    public static function definicao(): array {
        $p=self::padroes();$props=array();$help=self::ajuda();
        foreach($p as $k=>$v){$s=is_bool($v)?array('type'=>'boolean'):(is_int($v)?array('type'=>'integer','minimum'=>0,'maximum'=>65535):(is_array($v)?array('type'=>'array','maxItems'=>50,'uniqueItems'=>true,'items'=>array('type'=>'string','maxLength'=>254)):array('type'=>'string','maxLength'=>$k==='assinatura'?3000:254)));$s['description']=$help[$k];$props[$k]=$s;}
        $props['smtp_seguranca']['enum']=array('ssl','tls');$props['imap_porta']=array('type'=>'integer','enum'=>array(993),'description'=>$help['imap_porta']);$props['smtp_porta']['enum']=array(465,587);$props['cota_destinatarios_hora']['minimum']=1;$props['cota_destinatarios_hora']['maximum']=99;$props['max_links']['maximum']=100;
        return array('titulo'=>'E-mail do site','padrao'=>$p,'props'=>$props);
    }
    public static function validar(array $v): string {
        $r=rest_validate_value_from_schema($v,array('type'=>'object','additionalProperties'=>false,'properties'=>self::definicao()['props']));if(is_wp_error($r)){return $r->get_error_message();}$v=array_replace(self::padroes(),$v);
        foreach($v as $k=>$value){if(is_string($value)&&$k!=='assinatura'&&preg_match('/[\x00-\x1f\x7f]/',$value)){return 'Remova controles dos campos da caixa.';}}
        foreach(array('endereco','smart_bcc') as $key){if($v[$key]!==''&&!is_email($v[$key])){return 'Endereço da caixa inválido.';}}
        foreach(array('cco','homologacao_emails') as $key){foreach($v[$key] as $address){if(!is_email($address)){return 'Há um endereço inválido em '.$key.'.';}}}
        foreach(array_merge($v['dominios_ignorados'],$v['authserv_ids']) as $domain){if(!preg_match('/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/iD',$domain)||!str_contains($domain,'.')){return 'Informe domínios/servidores completos, sem protocolo.';}}
        foreach(array('imap_host','smtp_host') as $key){if(!preg_match('/^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/iD',$v[$key])||!str_contains($v[$key],'.')||filter_var($v[$key],FILTER_VALIDATE_IP)){return 'Servidor público inválido: '.$key;}}
        foreach(array('pasta_importados','pasta_enviados') as $key){if(!preg_match('/^[A-Za-z0-9_. -]{1,100}$/D',$v[$key])||strcasecmp($v[$key],'INBOX')===0){return 'Use uma pasta diferente de INBOX, com até 100 caracteres ASCII.';}}
        if(($v['smtp_porta']===465)!==($v['smtp_seguranca']==='ssl')){return 'Use 465/ssl ou 587/tls.';}
        if($v['ativo']||$v['envio_ativo']){if(!is_email($v['endereco'])||$v['usuario']===''||F3Base_Segredos::abrir(self::SECRET)===''){return 'Prepare endereço, usuário e senha antes de habilitar.';}if($v['homologacao']&&!$v['homologacao_emails']){return 'Cadastre as caixas de homologação.';}}
        if($v['envio_ativo']&&(!$v['alocacao_confirmada']||trim($v['nome_exibicao'])===''||trim($v['assinatura'])==='')){return 'Envio exige nome da marca, assinatura e alocação da cota confirmada.';}
        return '';
    }
    public static function identidade(array $cfg): string {return hash('sha256',wp_json_encode(array_intersect_key($cfg,array_flip(array('endereco','imap_host','imap_porta','usuario')))));}
    public static function mudou(string $name,$before,$after): void {
        if($name!==self::OPTION||!is_array($after)){return;}$before=is_array($before)?$before:self::padroes();
        $newContext=self::identidade($before)!==self::identidade($after);
        if($newContext||(!empty($after['ativo'])&&empty($before['ativo']))){
            F3Base_Options::atualizar_estado(self::STATE,static function($s)use($after,$newContext){$identity=self::identidade($after);if($newContext||empty($s['ativado_em'])){$s=array('identidade'=>$identity,'ativado_em'=>time(),'uid'=>0,'uidvalidity'=>0);}else{$s['reativado_em']=time();}$s['reconciliacao_necessaria']=false;$s['falhas']=0;return $s;});
        }
        if(!empty($after['ativo'])){F3Base_Fila::agendar(F3Base_Email_Site::HOOK,time()+5);}
    }
    public static function catalogo(array $c): array {
        $c[self::STATE]=array('rotulo'=>'Estado da caixa do site','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));
        return $c;
    }
}
