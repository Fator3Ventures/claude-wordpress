# Fator3 Site Core 1.54.0

Contatos externos cifrados, vínculo manual e reversível de sessões e gates exatos das abilities de e-mail. Comece em DOCUMENTACAO.md e AGENTES-1.54.0.md. O guia CONTATOS-EXTERNOS-1.54.md contém os contratos e limites do pedido 302. Contrato administrativo 8.19.0; cliente Pipedrive pipedrive-api-client/1.0.0 preservado.
