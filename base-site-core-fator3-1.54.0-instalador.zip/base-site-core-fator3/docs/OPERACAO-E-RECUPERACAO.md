# Operação e recuperação — Core 1.53.0

A atualização direta da 1.51.0 preserva dados/configuração e executa 17 etapas com checkpoint e confirmação posterior. Instalação existente sem migração de e-mail concluída é bloqueada antes das etapas. Instalação nova não importa defaults antigos nem dados de marca. f3base/como-usar expõe atualizacao, recuperacao, execucoes, esperas, acessos_servidor e captacao_meta.

Executor: captura Meta/LinkedIn e entregas Pipedrive/Slack/e-mail vencidas primeiro, uma oportunidade por seis hooks e orçamento próprio de 30 segundos por hook; manutenção mantém três trabalhos e 30 segundos. Seleção explícita em executar-pendentes limita os domínios. Quotas remotas, recuos, revisão, idempotência e reservas são preservados. Pausa de recuperação bloqueia ambos. Não há garantia de latência quando cron não roda ou hospedagem/fornecedor limita execução.

Antes de restaurar: usar operacao-recuperacao preparar com revisão e confirmação conforme schema; guardar arquivos, banco, salts e manifesto; manter workers pausados; restaurar conjunto coerente; conferir estado; retomar explicitamente. Restauração de arquivos não desfaz banco, mensagens ou CRM. Não tratar timeout ou ausência de applied como prova de que nada foi feito. Não repetir escrita externa sem reconciliar.

Limpeza do e-mail antigo é separada e irreversível sem backup: email-legado-limpar simulado, revisão, aplicação, releitura. Nenhum segredo é retornado. Confira divergências antes de prosseguir. Depois de limpar, downgrade não recria os resíduos. Desativar/desinstalar arquivos não autoriza apagar dados.

Acessos: catálogo usa memória incremental e consulta por caminho quando necessário. Falha preserva contribuição e registra próxima tentativa. Incidentes de captação: duas passagens perdidas/três falhas de transporte; recuperação antes do envio suprime a abertura; um encerramento somente após abertura aceita pelo wp_mail. Aceite não prova recebimento.

Documentação e diagnósticos de leitura não fazem reparo. Use ações explícitas e suas prévias. Histórico técnico, retenções por domínio e dados de negócio seguem os controles próprios; consulte RETENCAO-1.45.md e DICIONARIO-DADOS.md.


## Atualização 1.53.0

Pedidos 299–301 e contrato 8.18.0: EMAIL-SITE-1.53.md documenta caixa, cinco abilities, tabela, retenção e restauração; FORMULARIOS-SINAIS-1.53.md documenta a quarta isca e a política de suspeita/aviso. RELEASE-1.54.0.md reúne as mudanças. A configuração de unidade Pipedrive é obrigatória para reutilizar ou criar oportunidade.
