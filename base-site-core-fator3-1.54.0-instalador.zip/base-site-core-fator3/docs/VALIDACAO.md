# Validação — Core 1.54.0

Evidências reproduzíveis em evidence/1540 e relatório externo. Suítes: request-302 (registro, cifra, links, jornada, filtros, desfazer, revisão, privacidade e exclusão); request-302-crm (vínculo a lead existente sem mutação, entrega opcional e mapa_pontos); permissions-1540 (capacidades nativas e replays MCP 0.32.0); mcp032-policy-1540 (objetos token_* tipados). São testes WordPress/MySQL nativos com fixtures sintéticos; não enviam mensagens reais.

Instalação limpa e atualização nativa da 1.53.0 são cenários distintos. docs-1540 lê todos os documentos via ability com paginação, hashes e permissões. A execução no Site-Teste usa tabelas e arquivos isolados, removidos ao final. O relatório externo informa a identidade exata do instalador aprovado e o resultado efetivamente obtido.

O registro real no CTO Office depende da implantação pela frota e da identidade confirmada do contato. O número receptor da empresa não deve ser usado como telefone da pessoa. Homologação sintética não equivale à execução comercial em produção. Pendências da base relacionadas a IMAP/SMTP real e conversões dos demais domínios não são encerradas por esta entrega.
