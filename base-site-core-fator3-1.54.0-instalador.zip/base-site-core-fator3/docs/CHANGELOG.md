# 1.54.0

Pedido 302: contato externo cifrado, vínculo manual reversível de sessões, consultas/filtros e exclusão em cascata. Gates exatos de e-mail para o MCP 0.32.0.

# 1.53.0 — 25/10/2026

299: comparação do legado por chave, ignorando ativo da raiz. 300: caixa por site e envio explícito, MIME isolado, identidade de mensagem, mesma unidade no CRM. 301 atualizado: quarta isca, política por sinal, supressão auditável e contagens. Contrato 8.18.0; cinco abilities aditivas. Limites de homologação em docs/RELEASE-1.54.0.md.

# Mudanças vigentes — 1.53.0

- 296: adaptador de e-mail com dados fixos removido; guarda de migração anterior; limpeza explícita com prévia/revisão; CF7 sem chamador e inferência Elementor removidos; documentação substituída fora do instalador.
- 297: orçamento incremental do catálogo, modo por caminho e diagnóstico/nova tentativa.
- 298: histerese de captação, incidentes com abertura/encerramento condicionados, prioridade das capturas e entregas no executor.

Base direta 1.51.0, contrato 8.18.0. Histórico completo de releases anteriores no fonte, em history/. Contratos atuais, mudanças e limites em RELEASE-1.54.0.md; não considerar histórico como instrução operacional.
