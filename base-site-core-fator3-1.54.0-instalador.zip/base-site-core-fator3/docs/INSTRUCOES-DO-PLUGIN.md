# Operação do Site Core

Versão corrente 1.54.0. Leia DOCUMENTACAO.md para índice e AGENTES-1.54.0.md para receitas. Cada módulo registra suas opções, estado e atividade em f3base/como-usar; a configuração corrente não é inferida pela presença de um plugin.

Use o painel Site Core ou abilities públicas com manage_options. Configuração parcial mantém campos não tocados e exige a revisão lida. Tokens ficam cifrados; confirmar acesso no fornecedor é operação explícita distinta de validar formato. Ajuda instalada é estática e não faz chamadas externas.

Formulários capturam pela rota do Core, preservando consentimento e intenção de entrega. Contatos de teste seguem políticas por destino. Captação nativa Meta/LinkedIn pertence ao Core; SDKs opcionais têm seleção explícita. Operação manual da conta Pipedrive pertence ao plugin Pipedrive, via cliente do Core. Google, Meta Insights e LinkedIn gerenciam seus próprios produtos e credenciais.

Mudança em produção e publicação pertencem à frota/dono. Relatórios identificam fixture, WordPress real e fornecedor real separadamente. Não force migração, checkpoint, quota ou status para obter aparente sucesso.
