<?php
/**
 * Desinstalação do Fator3 Site Core.
 *
 * O QUE SAI, e é tudo ESTADO DE EXECUÇÃO — coisa que este plugin produziu
 * sozinho e sabe recriar: os carimbos de atividade, o segredo do endpoint, o
 * estado da cadência, a auditoria de escritas do canal, a procedência das
 * gravações e a lista de chaves operáveis; os agendamentos — inclusive o evento
 * único da Conversions API, que é agendado com argumento e por isso pede
 * `wp_unschedule_hook()`; transientes; tabelas auxiliares de comportamento, eventos,
 * acessos, contribuições, decisões de consentimento, vitais e fila CAPI.
 * O llms físico próprio é retirado; se falhar, conserva-se sua prova para recuperação.
 * Robots gerenciado mantém o protocolo de backup/restauração.
 *
 * O que FICA, por decisão declarada:
 *
 *   - os REGISTROS DE LEAD (tabela f3base_leads, CPT e caixa do Flamingo),
 *     contatos legados, anexos e conteúdo privados, concessões e fila de avisos cifrada (suspensa), com os segredos Slack/JSON. Nenhum desses dados entra no DROP.
 *     Desinstalar plugin não é pedido de eliminação de dado pessoal, e esses
 *     registros são o histórico comercial de quem opera o site;
 *   - o JOURNAL DE ELIMINAÇÃO (`f3base_journal_eliminacao`). Ele é a PROVA do
 *     que já foi apagado e quando; apagá-lo junto com o plugin destruiria
 *     exatamente o registro que uma auditoria procuraria depois;
 *   - as OPTIONS DE CONFIGURAÇÃO gravadas pelo implantador ou pela tela — os
 *     identificadores das contas de anúncio, o número de WhatsApp, os prazos, o
 *     llms.txt, os cabeçalhos. Reinstalar o plugin devolve o site ao que ele
 *     era; apagá-las obrigaria a reconfigurar tudo à mão depois de uma
 *     desinstalação feita por engano.
 *
 * A remoção do que fica tem rota própria, com capability, journal e regime
 * declarado. Toda escrita passa pelo gravador único, inclusive aqui.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/*
 * O PLUGIN INTEIRO É CARREGADO AQUI, e não uma classe escolhida a dedo.
 *
 * O DEFEITO MEDIDO num WordPress real: este arquivo fazia `require_once` só de
 * `class-f3base-options.php`, e o catálogo daquela classe cita `F3Base_Vocabulario`
 * e `F3Base_Llms` nos padrões. A desinstalação morria em `Class
 * "F3Base_Vocabulario" not found`, o painel mostrava "erro crítico", e NADA do
 * que este arquivo promete limpar era limpo. Uma segunda lista de `require`
 * aqui adiaria o mesmo defeito para o dia em que um padrão citasse mais uma
 * classe: a lista de arquivos do plugin é UMA, e ela mora no arquivo principal.
 *
 * O arquivo principal NÃO registra hook nenhum quando `WP_UNINSTALL_PLUGIN`
 * está definida — a guarda está lá, ao lado do bootstrap.
 */
require_once __DIR__ . '/base-site-core-fator3.php';
if ( class_exists( 'F3Base_Llms_Arquivo' ) ) {
	F3Base_Llms_Arquivo::desativar(); }
wp_clear_scheduled_hook( 'f3base_schema_verificar' );
wp_clear_scheduled_hook(F3Base_Cache_Reaquecimento::EVENTO);
if(class_exists('F3Base_Email_Site')){F3Base_Email_Site::suspender();}
if(class_exists('F3Base_Avisos')){F3Base_Avisos::suspender();}

if ( class_exists( 'F3Base_Capi_Fila' ) ) {
	F3Base_Capi_Fila::remover(); }
if ( class_exists( 'F3Base_Vitais' ) ) {
	F3Base_Vitais::remover(); }

if ( class_exists( 'F3Base_Robots_Arquivo' ) ) {
	F3Base_Robots_Arquivo::suspender(); }

/**
 * O plugin foi carregado a ponto de a desinstalação poder rodar?
 *
 * NÃO É PARANOIA: o arquivo principal RETORNA sem carregar nada quando o PHP em
 * execução está abaixo do mínimo declarado, e é justamente num servidor assim
 * que alguém apaga o plugin. Sem as classes, o que este arquivo pode fazer com
 * segurança é o que não depende delas — e é o que ele faz.
 *
 * @return bool
 */
function f3base_uninstall_classes_presentes(): bool {
	return class_exists( 'F3Base_Options' );
}

/**
 * Remove os agendamentos do plugin.
 *
 * @return void
 */
function f3base_uninstall_desagendar(): void {
	$eventos = array( 'f3base_operacao_retomar', F3Base_Clarity::EVENTO, 'f3base_clarity_retomar', F3Base_Navegacao::EVENTO, F3Base_Navegacao::EVENTO_REPETIR, F3Base_Tracking_Diagnostico::EVENTO, F3Base_Atualizacao::EVENTO, 'f3base_retencao_limpeza', 'f3base_leads_resumo', 'f3base_llms_converter_lote', 'f3base_cadencia_relatorio', 'f3base_acessos_somar', 'f3base_acessos_continuar', 'f3base_robots_verificar' );

    foreach(F3Base_Operacao::tarefas() as $task){$eventos=array_merge($eventos,$task['hooks']);}
	foreach ( array_unique($eventos) as $evento ) {
		wp_unschedule_hook( $evento );
	}

	/*
	 * O EVENTO DA CONVERSIONS API SAI PELA MESMA PORTA, e a razão é a que fez
	 * as outras duas passarem a usá-la. Ele é agendado COM ARGUMENTO — o
	 * `record_id` do lead —, e `wp_next_scheduled()` sem argumento não encontra
	 * evento agendado com um: um laço sobre ela passaria por ele e o deixaria na
	 * option `cron` para sempre, apontando para um hook que já não tem ouvinte.
	 * `wp_unschedule_hook()` remove todos os eventos do hook, com argumento ou
	 * sem, numa chamada e sem laço — que é o que um desagendamento deve ser.
	 */
	wp_unschedule_hook( 'f3base_meta_capi_enviar' );
}

/**
 * Remove as tabelas próprias do plugin.
 *
 * Os NOMES SAEM DAS CONSTANTES DOS MÓDULOS que as criam — nunca de
 * literais escritos aqui. Uma lista literal é o que deixou `f3base_eventos`
 * para trás: a tabela foi acrescentada ao módulo de comportamento e ninguém
 * lembrou deste arquivo. Com a constante, tabela nova aparece aqui no dia em
 * que ela nasce.
 *
 * @return array<int,string> Nomes das tabelas que deixaram de existir.
 */
function f3base_uninstall_tabela(): array {
	global $wpdb;

    foreach(array('f3base_avisos_partes','f3base_complementos','f3base_qualidade_fila','f3base_linkedin_webhook') as $suffix){$t=$wpdb->prefix.$suffix;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t){$wpdb->query($wpdb->prepare("UPDATE %i SET estado='suspenso' WHERE estado IN ('pendente','enviando','incerto')",$t));}}

	$sufixos = array(
    'f3base_formulario_tentativas',    'f3base_contexto_diagnostico','f3base_sessoes','f3base_contato_sessoes','f3base_contato_campanhas','f3base_sondas_http','f3base_audiencia_404','f3base_operacao_intencoes','f3base_consentimento_reparos',F3Base_Analise::TABELA,'f3base_conteudos','f3base_conteudo_rotas','f3base_editorial_diario','f3base_editorial_dias','f3base_referencias_ia','f3base_medicao_anotacoes','f3base_gsc_diario','f3base_gsc_coletas','f3base_gsc_linhas','f3base_gsc_lacunas','f3base_execucoes','f3base_inteligencia_auditoria','f3base_acessos_legado');

	if ( class_exists( 'F3Base_Modulo_Endpoint_Leads' ) ) {
		$sufixos[] = F3Base_Modulo_Endpoint_Leads::TABELA;
		$sufixos[] = F3Base_Modulo_Endpoint_Leads::TABELA_RECUSAS;
	}

	if ( class_exists( 'F3Base_Modulo_Comportamento' ) ) {
		$sufixos[] = F3Base_Modulo_Comportamento::TABELA;
		$sufixos[] = F3Base_Modulo_Comportamento::TABELA_EVENTOS;
	}

	if ( class_exists( 'F3Base_Modulo_Acessos_Servidor' ) ) {
		$sufixos[] = F3Base_Modulo_Acessos_Servidor::TABELA; }

	$sufixos[]  = F3Base_Consentimento_Decisoes::TABELA;
	$sufixos[]  = F3Base_Acessos_Coleta::TABELA;
	$derrubadas = array();

	foreach ( array_unique( $sufixos ) as $sufixo ) {
		$tabela = $wpdb->prefix . $sufixo;

		$wpdb->query( "DROP TABLE IF EXISTS `{$tabela}`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL

		$derrubadas[] = $tabela;
	}

	return $derrubadas;
}

/**
 * Remove os transientes do plugin.
 *
 * @return void
 */
function f3base_uninstall_transientes(): void {F3Base_Estado_Inventario::apagar_transientes();}

/**
 * Remove o estado de execução do próprio plugin.
 *
 * A LISTA É DERIVADA, e não digitada:
 * `F3Base_Options::descartaveis_na_desinstalacao()` a monta do catálogo, option
 * a option. Duas listas divergiriam na primeira option de estado acrescentada, e
 * a que ficaria para trás é esta — foi assim que `f3base_atividade`,
 * `f3base_endpoint_segredo` e `f3base_cadencia_estado` sobreviveram a uma
 * desinstalação que prometia levá-las.
 *
 * `F3BASE_PROVENIENCIA` E `F3BASE_OPERAVEIS` ENTRAM AQUI porque as duas são
 * estado sobre ESTE plugin e nenhuma outra coisa as lê: a primeira é o registro
 * de quem gravou cada option deste catálogo, a segunda é a lista de chaves que o
 * implantador liberou na tela DELE. Deixá-las para trás é deixar duas options
 * órfãs no banco falando de um plugin que já não existe.
 *
 * O JOURNAL DE ELIMINAÇÃO NÃO ESTÁ NESTA LISTA, e ele é o caso que mostra por
 * que "estado de execução" e "descartável" são declarações diferentes: ele é
 * escrito por uma rotina, e não configurado por ninguém, MAS é a prova do que já
 * foi apagado e quando.
 *
 * @return array<int,string> Nomes que deixaram de existir.
 */
function f3base_uninstall_estado(): array {
	$removidas = array();

	foreach ( F3Base_Options::descartaveis_na_desinstalacao() as $nome ) {
		// Conservar a prova de propriedade se o servidor recusou retirar o arquivo.
		if ( F3Base_Llms_Arquivo::ESTADO === $nome && F3Base_Llms_Arquivo::proprio( true ) ) {
			continue; }
		if ( F3Base_Options::remover( $nome ) ) {
			$removidas[] = $nome;
		}
	}

	return $removidas;
}

f3base_uninstall_desagendar();
f3base_uninstall_transientes();

if ( f3base_uninstall_classes_presentes() ) {
	f3base_uninstall_tabela();
	f3base_uninstall_estado();
}

// Metadado privado da retirada de caminhos; não remove metadados de terceiros.
delete_metadata('post',0,'_f3base_retired_path','',true);

delete_metadata('post',0,'_f3base_redirect_preimage','',true);
