<?php

namespace F3BaseEmailVendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
