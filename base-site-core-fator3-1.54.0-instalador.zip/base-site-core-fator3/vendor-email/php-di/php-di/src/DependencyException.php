<?php

declare (strict_types=1);
namespace F3BaseEmailVendor\DI;

use F3BaseEmailVendor\Psr\Container\ContainerExceptionInterface;
/**
 * Exception for the Container.
 */
class DependencyException extends \Exception implements ContainerExceptionInterface
{
}
