<?php // Sem saída.
