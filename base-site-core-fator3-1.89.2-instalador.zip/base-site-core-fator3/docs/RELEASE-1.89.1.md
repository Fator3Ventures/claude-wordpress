# Fator3 Site Core 1.89.1

Instalação nova ou atualização direta da 1.89.0. WordPress 7.1.4 ou superior e PHP 8.3 ou superior de 64 bits. Contrato administrativo 8.41.0.

## Pedido 415

O catálogo passa a 1.348 códigos na revisão 2026-11-15.3, de 15/11/2026.

| Código recebido | Marca | Nome comercial | Ano | Preço estimado | Faixa | Linha premium |
|---|---|---|---:|---:|---|---|
| infinix x6525b | Infinix | Infinix SMART 8 Pro | 2024 | R$ 800,00 | entrada | não |
| m7_wifi | Multilaser | M7 Wi-Fi | 2021 | R$ 292,89 | entrada | não |

O código M7_WIFI identifica a família do tablet. O ano e o preço usam a configuração NB355 de 32 GB como referência. O fonte traz os critérios e URLs em `reference/415/`.

Com permissão administrativa, consulte `f3base/aparelhos-sem-nome-ler`. Use `proximo_apos` como `apos` na próxima chamada até o cursor ser nulo. Perfis retidos com esses códigos são reconhecidos na leitura. As regras locais continuam com a mesma prioridade. Esta atualização usa as tabelas, configurações e contratos da 1.89.0.
