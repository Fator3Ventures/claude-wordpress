# Fator3 Site Core 1.89.0

Instalação limpa ou atualização direta da 1.88.1. WordPress 7.1.4+, PHP 8.3+ de 64 bits. Contrato administrativo 8.41.0 e perfil piso-padrao-3.6.

## Pedido 414

O catálogo embarcado reúne 1.346 códigos. Os 26 códigos do pedido foram identificados e precificados. Entraram aparelhos Infinix, TECNO, LG e OPPO, o Positivo Twist SE e variantes de aparelhos de 2017 a 2019. A leitura atual da frota também identificou códigos adicionais incluídos na versão. A data da pesquisa é 15/11/2026, revisão 2026-11-15.2. Os preços são estimativas em reais, descritas com as fontes e os comparáveis no fonte do plugin.

A identificação dá prioridade à regra local exata, ao código embarcado e à raiz Samsung inequívoca. Quando o navegador envia o nome comercial, o Core procura o nome sem distinção de caixa, espaços ou parênteses. Sinais de variantes, como +, continuam significativos. A tabela usa somente associações inequívocas para busca por nome. Regras locais de faixa continuam valendo.

Com permissões administrativas, consulte `f3base/aparelhos-sem-nome-ler`. Para paginar, envie `proximo_apos` como `apos` mesmo que a página venha vazia. Em `f3base/sessao-detalhar`, os campos `modelo`, `marca`, `nome_comercial`, `ano_lancamento`, `preco_atual_estimado_brl`, `faixa_aparelho` e `linha_premium` ficam em `sessoes[]`. Exemplo para um perfil retido no Brasil: moto e6s → Motorola, Moto E6s, 2020, R$ 239,00, entrada. O preço do exemplo usa uma oferta de aparelho usado.

Observações identificadas mantêm a ficha histórica. O código de um perfil retido anteriormente sem nome é resolvido no momento da leitura, inclusive se ele já tinha data da lista anterior. Nenhuma tabela, credencial ou migração de dados para regravação é necessária. A recepção de uma visita não consulta serviços externos.
