# Fator3 Site Core 1.87.2

Instalação nova ou atualização direta da 1.86.0, da 1.87.0 ou da 1.87.1. WordPress 7.1.4 e PHP 8.3 de 64 bits. O contrato de configuração permanece 8.41.0. O formato de consulta compacta muda nesta rodada.

## Histórico de e-mail e aplicabilidade (407 e 408)

A conferência do histórico exige f3base_email_historico.ativo e f3base_pipedrive.ativo. Com as duas opções ligadas, o zelador mantém f3base_email_historico_conferir a cada cinco minutos, inclusive nos sites que desligaram a operação comercial. Com uma delas desligada, a rotina retorna nao_aplicavel e encerra esperas antigas elegíveis. Reservas vigentes continuam protegidas. A confirmação de uma mensagem exige identificar o envio e seu vínculo no CRM.

O administrador consulta f3base/aplicabilidade-ler, opcionalmente com modulo, ou f3base/como-usar com incluir contendo aplicabilidade. Cada regra traz condição, opções, resultado local, revisão, ganchos, efeitos e esperas observadas. As chaves modulo/ identificam os módulos do registro. Os demais itens identificam políticas e trabalhadores. As ativações locais e os pré-requisitos adicionais da coleta do Search Console são apresentados separadamente. O perfil de referência da frota está no relatório da versão.

## Campos históricos (409)

O leitor estruturado aceita JSON textual, array já decodificado e ausência de valor. Uma forma inesperada produz aviso por campo e tipo, sem expor o conteúdo. Nas entregas, um recibo ilegível impede a repetição automática. Os campos contexto_cifrado, pedido e valores continuam exigindo a cifra correspondente. O destino de clique é texto. As leituras não regravam o histórico. As projeções de relatórios incluem avisos_campos quando há ocorrências na requisição.

## Relatórios integrados (410)

A consulta admite até 90 dias. O Core mede a contagem e o tamanho dos campos no banco antes de materializar os dados comuns e consulta em lotes de 32 linhas. O orçamento considera a memória já ocupada, a reserva do processo e a expansão das linhas e do JSON. limite_memoria devolve visão, período e orçamento, e reduza_periodo indica o limite de linhas. Reduza o intervalo para obter um relatório completo. O painel usa o mesmo leitor. Uma recusa não representa tráfego zero.

## Leitura compacta (411)

Para varredura, envie {"compacto":true} a f3base/como-usar ou f3base/saude-ler. As duas respostas trazem versão, contrato, atualização, estado dos módulos, contagem de esperas e erros ativos e rotas de detalhe. O detalhamento das regras aceita um módulo por chamada. Para recuperar séries, estado dos executores ou o manual, consulte a rota indicada sem compacto.

## Execução de filas (412)

A agenda mantém wp_mail, Pipedrive e notificações LinkedIn a cada cinco minutos quando elegíveis. Mantém e-mail de novo lead e conversões pelo servidor a cada hora, e recuperação CAPI diariamente. O evento avulso existente é convertido na mesma hora. Um trabalho com prazo mais curto pode antecipar a fila com uma ocorrência separada, compartilhada pelos pedidos urgentes. O executor conserva a cadência regular e trata o trabalhador ocioso sem rearmar a própria agenda. O próprio WordPress ainda atualiza sua option cron quando uma ocorrência vence.

Para o aceite em produção, a operação da frota compara o diagnóstico de cron e o error.log em uma janela integral de 24 horas, incluindo a passagem dos dois executores de ctooffice.com.br.

## Padrão de entrega e operação

O selo identifica a versão em todas as telas do Core. Nos menus Site Core e Medição, os grupos organizam as abas por função. Os endereços anteriores continuam válidos. As listas com resultados paginados exibem a faixa visível. O modo compacto de saúde e de como-usar também mostra versao_alvo, estado, falhas e confirmada_no_executor_em.

A instalação conclui as etapas e o executor confirma o ciclo. Confira a versão 1.87.2, o estado concluida, zero falhas e o horário de confirmação. Uma passagem adiada depende da próxima execução agendada. O perfil canônico é piso-padrao-3.6. O contrato de configuração é 8.41.0. A frota publica os três arquivos no main depois de verificar os dois ZIPs.

Conexões e entregas agrupa canais, CRM e acesso. Operação mantém à vista os três destinos. No menu Site Core, Medição abre os relatórios no endereço existente. O roteiro de produção atualiza direto da 1.86.0.
