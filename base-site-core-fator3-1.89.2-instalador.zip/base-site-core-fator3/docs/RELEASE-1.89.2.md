# Fator3 Site Core 1.89.2

Instalação nova ou atualização direta da 1.89.1. WordPress 7.1.4 ou superior e PHP 8.3 ou superior de 64 bits. Contrato administrativo 8.41.0.

## Pedidos core 417

A revisão 2026-11-15.4 cobre 1.349 códigos. Os 11 primeiros códigos da tabela passam a identificar o próprio aparelho. A última linha acrescenta o Moto G8 Power Lite.

| Código | Device | Nome do aparelho | Ano | Preço estimado (R$) | Faixa | Premium |
|---|---|---|---:|---:|---|---|
| motorola edge 20 pro | pstar | motorola edge 20 pro | 2021 | 896,72 | topo | sim |
| moto g - 2025 | kansas | moto g - 2025 | 2025 | 960,75 | entrada | não |
| moto g stylus 5G (2022) | milanf | moto g stylus 5G (2022) | 2022 | 480,40 | intermediário | não |
| moto g51 5G | cypfq | moto g51 5G | 2021 | 599,00 | intermediário | não |
| motorola edge 40 pro | rtwo | motorola edge 40 pro | 2023 | 1777,39 | topo | sim |
| moto g 5G (2022) | austin | moto g 5G (2022) | 2022 | 429,54 | intermediário | não |
| motorola edge (2022) | tesla | motorola edge (2022) | 2022 | 898,64 | topo | sim |
| moto g stylus 5G - 2023 | genevn | moto g stylus 5G - 2023 | 2023 | 621,70 | intermediário | não |
| moto g play - 2024 | fogona | moto g play - 2024 | 2024 | 847,71 | entrada | não |
| motorola edge 2025 | oulu | motorola edge 2025 | 2025 | 1978,07 | topo | sim |
| motorola razr 2022 | oneli | motorola razr 2022 | 2022 | 1260,00 | topo | sim |
| moto g(8) power lite | blackjack | Moto G8 Power Lite | 2020 | 890,00 | entrada | não |

O gerador compara o Model ao Marketing Name do Google Play. Quando há linha própria, um nome regional já escolhido só é mantido se uma linha desse nome compartilhar o Device e a marca de origem. Os 34 códigos ambíguos sem linha própria conservam a ficha anterior, com candidatos registrados no fonte. Nomes comerciais de varejo e grafias editoriais equivalentes estão documentados em reference/417/.

As novas classificações alimentam a medição, os relatórios e as integrações usuais. Perfis históricos com nome comercial já gravado conservam a ficha da observação. Perfis retidos sem nome, como o G8 Power Lite, recebem a ficha na leitura. Mensagens enviadas e registros externos já criados não são reprocessados.

Para conferir, leia f3base/como-usar e f3base/aparelhos-sem-nome-ler com a permissão administrativa. Passe proximo_apos como apos até o cursor ser nulo. Para auditar os 11 nomes e os preços, use reference/417/catalogo-aparelhos.csv e fichas-pesquisadas.csv no fonte.
