<?php
/** Leitura por MCP das contagens do servidor. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Acessos_Mcp {
	public const HABILIDADE = 'f3base/acessos-ler';
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		F3Base_Servicos::registrar_ability(
			self::HABILIDADE,
			array(
				'label'               => __( 'Ler acessos do servidor', 'f3base' ),
				'description'         => __( 'Contagens de requisições por caminho, família declarada, status e método. Sem IP ou agente bruto. Não mede visitantes únicos nem confirma identidade dos robôs. Paginação por offset; totais do rodapé independem do filtro de caminho.', 'f3base' ),
				'category'            => F3BASE_PREFIXO,
				'input_schema'        => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'properties'           => array(
						'pagos_offset'=>array('type'=>'integer','minimum'=>0,'maximum'=>1000000,'default'=>0),
                        'dias'           => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 90,
							'default' => 90,
						),
						'classe_caminho' => array(
							'type' => 'string',
							'enum' => F3Base_Modulo_Acessos_Servidor::CLASSES,
						),
						'prefixo'        => array(
							'type'      => 'string',
							'maxLength' => 191,
						),
						'incluir_erros'  => array(
							'type'    => 'boolean',
							'default' => false,
						),
						'offset'         => array(
							'type'    => 'integer',
							'minimum' => 0,
							'maximum' => 1000000,
							'default' => 0,
						),
					),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'parametros_pagos'=>array('type'=>'object','additionalProperties'=>true),
                        'fuso'         => array( 'type' => 'string' ),
						'regra'        => array( 'type' => 'string' ),
						'primeiro_dia' => array( 'type' => 'string' ),
						'cobertura'    => array(
							'type'  => 'array',
							'items' => array(
								'type'       => 'object',
								'properties' => array(
									'dia'             => array( 'type' => 'string' ),
									'estado'          => array( 'type' => 'string' ),
									'motivo'          => array( 'type' => 'string' ),
									'origem'          => array( 'type' => 'string' ),
									'regra'           => array( 'type' => 'string' ),
									'fuso'            => array( 'type' => 'string' ),
									'inspecionado_em' => array( 'type' => 'integer' ),
								),
							),
						),
						'inicio'       => array( 'type' => 'string' ),
						'fim'          => array( 'type' => 'string' ),
						'linhas'       => array(
							'type'  => 'array',
							'items' => array(
								'type'       => 'object',
								'properties' => array(
									'agente'         => array( 'type' => 'string' ),
									'classe_agente'  => array( 'type' => 'string' ),
									'classe_caminho' => array( 'type' => 'string' ),
									'caminho'        => array( 'type' => 'string' ),
									'status'         => array( 'type' => 'integer' ),
									'metodo'         => array( 'type' => 'string' ),
									'contagem'       => array( 'type' => 'integer' ),
								),
							),
						),
						'total_linhas' => array( 'type' => 'integer' ),
						'limite'       => array( 'type' => 'integer' ),
						'offset'       => array( 'type' => 'integer' ),
						'totais'       => array(
							'type'        => 'object',
							'description' => 'Excluídos, estáticos e excedentes de TODO o período com o mesmo filtro de status.',
						),
						'dias_somados' => array( 'type' => 'integer' ),
						'ultimo_dia'   => array( 'type' => 'string' ),
						'estado'       => array( 'type' => 'object' ),
						'ultima'       => array( 'type' => 'object' ),
					),
				),
				'permission_callback' => static fn(): bool => current_user_can( 'manage_options' ),
				'execute_callback'    => array( __CLASS__, 'responder' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}
	public static function responder( $entrada = null ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'f3base_acessos_sem_permissao', 'Sem permissão para ler acessos.', array( 'status' => 403 ) ); }
		$e = is_array( $entrada ) ? $entrada : array();
		$r = F3Base_Modulo_Acessos_Servidor::consultar( (int) ( $e['dias'] ?? 90 ), (string) ( $e['classe_caminho'] ?? '' ), (string) ( $e['prefixo'] ?? '' ), (bool) ( $e['incluir_erros'] ?? false ), (int) ( $e['offset'] ?? 0 ) );
		// Objetos vazios precisam ser objetos JSON também ao validar a saída da API.
		if ( ! $r['ultima'] ) {
			$r['ultima'] = (object) array(); }
		$r['parametros_pagos']=F3Base_Acessos_Pagos::ler($r['inicio'],$r['fim'],(string)($e['prefixo']??''),(int)($e['pagos_offset']??0),(bool)($e['incluir_erros']??false),(string)($e['classe_caminho']??''));
		unset( $r['pessoas_medidas'] );
		return $r;
	}
}
