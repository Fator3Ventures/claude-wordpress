<?php
/** Configuração persistente do Core, com schema, simulação e revisão concorrente. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Core_Config_Mcp {
	/** Canal MCP confirmado na versão do conector; preserva proteções de outros donos. */
	public static function registrar_protecao(): void {
		add_filter( 'wp_mcp_ultimate_protected_options', array( __CLASS__, 'proteger_options' ), 10, 2 );
	}
	public static function proteger_options( $protegidas ): array {
		return array_values( array_unique( array_merge( is_array( $protegidas ) ? $protegidas : array(), F3Base_Options::proprias() ) ) );
	}

	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		$nomes = array_keys( array_filter( F3Base_Options::catalogo(), static fn( $d ) => ! empty( $d['operavel'] ) ) );
		$nome  = array(
			'type' => 'string',
			'enum' => $nomes,
		);
		$comum = array(
			'meta'                => array(
				'show_in_rest' => true,
				'mcp'          => array(
					'public' => true,
					'type'   => 'tool',
				),
			),
			'category'            => F3BASE_PREFIXO,
			'permission_callback' => static fn() => current_user_can( 'manage_options' ),
			'output_schema'       => array( 'type' => 'object' ),
		);
		F3Base_Servicos::registrar_ability(
			'f3base/config-core-ler',
			array_merge(
				$comum,
				array(
					'label'            => 'Ler configuração persistente do Core',
					'description'      => 'Lê valores operáveis, revisão opaca, origem e schema do próprio Core; segredos são mascarados. Independe do implantador.',
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array('nome'=>array('type'=>'string'),'caminhos'=>array('type'=>'array','minItems'=>1,'maxItems'=>50,'uniqueItems'=>true,'items'=>array('type'=>'string','pattern'=>'^/','maxLength'=>500)),'hash'=>array('type'=>'boolean','default'=>false)),
						'additionalProperties' => false,
					),
					'execute_callback' => array( __CLASS__, 'ler' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => true,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
		F3Base_Servicos::registrar_ability(
			'f3base/config-core-escrever',
			array_merge(
				$comum,
				array(
					'label'            => 'Simular ou aplicar configuração persistente do Core',
					'description'      => 'Grava pela operação do dono (F3Base_Options::gravar). Envie valor completo e revisão; mesclar=true permite alteração parcial tipada de opções compostas. Simular é o padrão. Confira persisted, effect e verification separadamente; ok mantém compatibilidade. A recusa do Core não autoriza escrita direta ou alteração do tema.',
					'output_schema'    => F3Base_Config_Contrato::schema_gravacao(),
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array(
							'nome'             => $nome,
                            'operacoes'=>F3Base_Config_Caminhos::schema(),
							'valor'            => F3Base_Config_Contrato::schema_dado( 'Valor completo conforme o schema da option.' ),
							'revisao_esperada' => array(
								'type'    => 'string',
								'pattern' => '^[a-f0-9]{64}$',
							),
							'simular'          => array(
								'type'    => 'boolean',
								'default' => true,
							),
							'confirmacao_identidade'=>array('type'=>'string','maxLength'=>100),
                            'mesclar'          => array(
								'type'    => 'boolean',
								'default' => false,
							),
						),
						'required'             => array( 'nome', 'revisao_esperada' ),
						'additionalProperties' => false,
					),
					'execute_callback' => array( __CLASS__, 'escrever' ),
					'meta' => array_merge( $comum['meta'], array( 'annotations' => array( 'readonly' => false ) ) ),
				)
			)
		);
		F3Base_Servicos::registrar_ability(
			F3Base_Config_Contrato::HABILIDADE,
			array_merge(
				$comum,
				array(
					'label'            => 'Contrato de configuração do Core — v1',
					'description'      => 'Catálogo versionado do dono: tipos, limites canônicos, aceitação de entrada, valores atuais, padrões, revisão, dependências e operações permitidas. Segredos mascarados. Leitura de estado do site; não edita os JSONs do implantador.',
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array_merge(
							array(
								'nome' => array(
									'type' => 'string',
									'enum' => F3Base_Config_Contrato::nomes(),
								),
							),
							F3Base_Config_Consultas::propriedades()
						),
						'additionalProperties' => false,
					),
					'output_schema'    => F3Base_Config_Contrato::schema_resposta(),
					'execute_callback' => array( 'F3Base_Config_Contrato', 'consultar' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => true,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
		F3Base_Servicos::registrar_ability(
			'f3base/config-core-perfil-avaliar',
			array_merge(
				$comum,
				array(
					'label'            => 'Avaliar perfil de configuração declarado',
					'description'      => 'Avalia o perfil instalado '.F3Base_Config_Perfil::ID.' por ID/revisão ou um perfil declarado pelo chamador. Exige gravação explícita quando a regra determina e informa herança por caminho. Não grava nem executa sondas; segredos aceitam somente presença.',
					'input_schema'     => F3Base_Config_Perfil::schema(),
					'execute_callback' => array( 'F3Base_Config_Perfil', 'avaliar' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => true,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
		F3Base_Servicos::registrar_ability(
			F3Base_Config_Contrato::VERIFICAR,
			array_merge(
				$comum,
				array(
					'label'            => 'Consultar ou executar a verificação do Core',
					'description'      => 'Consultar é leitura. verificar_publico faz até sete GETs anônimos: dois da home, dois por rota de token ativa e um do artefato elegível de cache, na mesma cadência limitada por minuto. atualizar_cache solicita limpeza e verifica. Ações ativas exigem revisão e não regravam preferências. ok indica operação recebida; confira sonda.persisted, verification.status, cache.historico, cache.agendamento, cache.tokens e efeito_cache. Consultas não iniciam sondas nem agendamento; execuções independentes registram origem e início/fim.',
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array(
                            'compacto'=>array('type'=>'boolean','default'=>false),
                            'evidencia_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),
							'acao'             => array(
								'type'    => 'string',
								'enum'    => array( 'consultar', 'verificar_publico', 'atualizar_cache' ),
								'default' => 'consultar',
							),
							'nome'             => array(
								'type' => 'string',
								'enum' => F3Base_Config_Contrato::nomes(),
							),
							'revisao_esperada' => array(
								'type'    => 'string',
								'pattern' => '^[a-f0-9]{64}$',
							),
						),
						'required'             => array( 'nome' ),
						'additionalProperties' => false,
					),
					'output_schema'    => array(
						'type'       => 'object',
						'properties' => array(
							'contrato_evidencias'=>array('type'=>'integer'),
                            'evidencia_id'=>array('type'=>array('string','null')),
                            'persisted'=>array('type'=>array('boolean','null')),
                            'detalhe'=>array('type'=>'object'),
                            'evidencias_tokens'=>array('type'=>'object'),
                            'verificacao_publica'=>array('type'=>array('object','null')),
                            'cache'                 => F3Base_Config_Contrato::schema_cache(),
							'sonda'                 => array(
								'type'       => array( 'object', 'null' ),
								'properties' => F3Base_Config_Contrato::schema_prova_cache()['properties'],
							),
							'efeito_cache'          => array( 'type' => array( 'object', 'null' ) ),
							'ok'                    => array( 'type' => 'boolean' ),
							'codigo'                => array( 'type' => 'string' ),
							'nome'                  => array( 'type' => 'string' ),
							'revisao'               => array( 'type' => 'string' ),
							'existe_no_banco'       => array( 'type' => 'boolean' ),
							'verification'          => F3Base_Config_Contrato::schema_verificacao(),
							'configuracao_alterada' => array( 'type' => 'boolean' ),
							'efeito_repetido'       => array( 'type' => 'boolean' ),
						),
					),
					'execute_callback' => array( 'F3Base_Config_Contrato', 'verificar' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => false,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
	}
	public static function ler( $entrada = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		if ( ! empty( $entrada['nome'] ) && ! F3Base_Options::operavel( (string) $entrada['nome'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => F3Base_Servicos::motivo_acesso( (string) $entrada['nome'] ),
				'opcoes' => array(),
			);
		}
		$saida  = array();
		$pedido = is_array( $entrada ) ? (string) ( $entrada['nome'] ?? '' ) : '';
		foreach ( F3Base_Options::catalogo() as $nome => $d ) {
			if ( ! F3Base_Options::operavel( $nome ) || ( '' !== $pedido && $pedido !== $nome ) ) {
				continue; }
			$schema = F3Base_Config_Contrato::campos( $d );
			$foto   = F3Base_Options::fotografia( $nome );
			if ( ! empty( $foto['erro'] ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'leitura_falhou',
				); }
			$saida[ $nome ] = array(
				'valor'           => self::visivel( $nome, $foto['valor'] ),
				'revisao'         => $foto['revisao'],
				'origem'          => F3Base_Options::procedencia( $nome, $foto )['origem'],
				'procedencia'     => F3Base_Options::procedencia( $nome, $foto ),
				'schema'          => F3Base_Config_Contrato::schema_valor( $d ),
				'schema_entrada'  => F3Base_Config_Contrato::schema_entrada( $d ),
				'campos'          => $schema,
				'existe_no_banco' => $foto['existe'],
				'verification'    => F3Base_Options::verificar_configuracao( $nome, $foto['valor'] ),
			) + F3Base_Config_Consultas::heranca($nome,$d,$foto);
		}
        if(isset($entrada['caminhos'])||!empty($entrada['hash'])){
            if($pedido===''){return array('ok'=>false,'codigo'=>'nome_obrigatorio');}
            try{foreach($saida as $name=>$entry){$saida[$name]=F3Base_Config_Caminhos::projetar($name,$entry,$entrada);}}catch(InvalidArgumentException $e){return array('ok'=>false,'codigo'=>$e->getMessage());}
        }
		return array(
			'ok'               => '' === $pedido || isset( $saida[ $pedido ] ),
			'opcoes'           => $saida,
			'contract_version' => F3Base_Config_Contrato::VERSAO,
			'contrato'         => F3Base_Config_Contrato::HABILIDADE,
		);
	}
	private static function visivel( string $nome, $valor ) {
		return F3Base_Config_Contrato::visivel( $nome, $valor );
	}
	public static function escrever( $entrada ): array {
        return F3Base_Credenciais::com_confirmacoes(array(($entrada['nome']??'')=>(string)($entrada['confirmacao_identidade']??'')),static fn()=>self::escrever_confirmado($entrada));
    }
    private static function escrever_confirmado( $entrada ): array {
        F3Base_Pipedrive_Credencial::limpar_resultado();$r=self::escrever_interno($entrada);
        $r['efeito_ate']=gmdate('c',time()+3600);$r['efeitos_imediatos']=array('captura','consentimento','cabecalhos_seguranca','redirecionamentos','retirada_conteudo_privado');
        if(is_array($entrada)&&($entrada['simular']??true)){$r['simulado']=true;$r['persisted']=false;if(empty($r['ok'])){$r['alteraria']=false;}}
        $candidate=F3Base_Credenciais::ultima();if(!empty($candidate['remota'])){$r['verificacao_remota']=array_intersect_key($candidate,array_flip(array('remota','ok','codigo','http')));}
        return $r;
    }
    private static function escrever_interno($entrada): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::recusa( 'sem_permissao' ); }
		if ( ! is_array( $entrada ) ) {
			return self::recusa( 'entrada_invalida' ); }
		if ( ( array_key_exists( 'simular', $entrada ) && ! is_bool( $entrada['simular'] ) ) || ( array_key_exists( 'mesclar', $entrada ) && ! is_bool( $entrada['mesclar'] ) ) ) {
			return self::recusa( 'entrada_invalida' ); }
		$nome = is_string( $entrada['nome'] ?? null ) ? $entrada['nome'] : '';
		if ( ! F3Base_Options::operavel( $nome ) || (! array_key_exists( 'valor', $entrada ) && !isset($entrada['operacoes'])) ) {
			return self::recusa( 'option_nao_operavel' ); }
        if(isset($entrada['operacoes'])&&(isset($entrada['valor'])||!empty($entrada['mesclar'])||F3Base_Options::e_segredo($nome)||$nome==='f3base_redirects')){return self::recusa('operacoes_incompativeis');}
		if ( 'f3base_redirects' === $nome ) {
			if ( ! empty( $entrada['mesclar'] ) ) {
				return self::recusa( 'mescla_nao_permitida' ); }
			return F3Base_Redirects_Servico::escrever(
				array(
					'operacao'         => 'substituir_lista',
					'pares'            => $entrada['valor'],
					'revisao_esperada' => $entrada['revisao_esperada'] ?? '',
					'simular'          => $entrada['simular'] ?? true,
				)
			);
		}
		$foto = F3Base_Options::fotografia( $nome );
		if ( ! empty( $foto['erro'] ) ) {
			return self::recusa( 'leitura_falhou' );
		} $revisao = $foto['revisao'];
		$esperada  = $entrada['revisao_esperada'] ?? '';
		if ( ! is_string( $esperada ) || ! hash_equals( $revisao, $esperada ) ) {
			if ( false === ( $entrada['simular'] ?? true ) ) {
				F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'conflito' );
			} return self::recusa( 'conflito', 'A configuração mudou; leia novamente antes de aplicar.' ); }
        $paths=null;
        if(isset($entrada['operacoes'])){$patch=F3Base_Config_Caminhos::aplicar($foto['valor'],$entrada['operacoes'],F3Base_Options::declaracao($nome)['schema_config']??array());if(empty($patch['ok'])){return self::recusa($patch['codigo']);}$entrada['valor']=$patch['valor'];$paths=$patch['caminhos'];}
		$d = F3Base_Options::declaracao( $nome );
        $delta = !empty($entrada['mesclar']) && is_array($entrada['valor']) ? $entrada['valor'] : null;
        $bruto = F3Base_Options::fotografia_bruta($nome);
        if($bruto['erro'] || !hash_equals($bruto['revisao'],$revisao)){return self::recusa('conflito');}
		if ( ! empty( $entrada['mesclar'] ) ) {
			$mescla = F3Base_Config_Mescla::preparar( $d, $bruto['existe'] ? $bruto['valor'] : $foto['valor'], $entrada['valor'] );
			if ( ! $mescla['ok'] ) {
				if ( false === ( $entrada['simular'] ?? true ) ) {
					F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, $mescla['codigo'] );
				} return self::recusa( $mescla['codigo'], 'A mesclagem foi recusada; consulte os campos declarados e seus tipos.' ) + array('erros'=>$mescla['erros']??array()); }
			$entrada['valor'] = $mescla['valor'];
		}
        $avaliado = null === $delta ? $entrada['valor'] : F3Base_Config_Mescla::escopo($nome,$entrada['valor'],$delta,$d);
        $erros_schema = F3Base_Config_Mescla::erros_schema($avaliado,F3Base_Config_Contrato::schema_entrada($d));
        // Path operations are typed mutations of the entire canonical value. The
        // historical input schema can deliberately omit nested item constraints;
        // it must not let a malformed patch become valid through coercion in the
        // sanitizer (for example, an array URL becoming the string "http://Array").
        // Keep the legacy complete-value and merge acceptance rules unchanged.
        if($paths!==null){$erros_schema=F3Base_Config_Mescla::deduplicar(array_merge($erros_schema,F3Base_Config_Mescla::erros_schema($avaliado,F3Base_Config_Contrato::schema_valor($d))));}
		$validacao = $erros_schema ? new WP_Error('tipo_invalido') : true;
		if ( is_wp_error( $validacao ) ) {
			if ( false === ( $entrada['simular'] ?? true ) ) {
				F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'tipo_invalido' ); }
			return self::recusa( 'tipo_invalido', 'Tipo incompatível com o schema de entrada da option.' ) + array('erros'=>$erros_schema);
		}
		$recusa = F3Base_Options::recusar( $nome, $avaliado, $d );
		if ( '' !== $recusa ) {
			if ( false === ( $entrada['simular'] ?? true ) ) {
				F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'valor_recusado' ); }
			$seg=F3Base_Segredos::gerenciado($nome)?F3Base_Segredos::motivo_seguro($nome,$avaliado):null;
            if($seg!==null&&$seg['motivo']===''){$rem=F3Base_Credenciais::ultima();$seg=$rem&&empty($rem['ok'])?array('codigo'=>(string)$rem['codigo'],'motivo'=>(string)$rem['motivo']):array('codigo'=>'recusa_declarada','motivo'=>'Credencial recusada pela regra da opção.');}
            $r=self::recusa('valor_recusado',$seg!==null?$seg['motivo']:(F3Base_Options::e_segredo($nome)?'Valor secreto recusado.':$recusa));if($seg!==null){$r['validacao_segredo']=$seg;}if(F3Base_Segredos::gerenciado($nome)){$r['verificacao_credencial']=F3Base_Credenciais::ultima();$r['avisos']=is_string($avaliado)?F3Base_Credenciais::avisos_formato($nome,$avaliado):array();}
			if ( 'f3base_seo_entidade' === $nome ) {
				$r['validacao'] = F3Base_Seo_Entidade::validar( $entrada['valor'] ); }
			return $r;
		}
        if(!hash_equals($revisao,F3Base_Options::revisao($nome))){return self::recusa('conflito','A configuração mudou durante a verificação. Leia novamente.');}
		$ajuste = F3Base_Options::ajustar_na_escrita( $nome, F3Base_Options::sanitizar( $nome, $entrada['valor'] ), $d );
		$valor  = $ajuste['valor'];
        if(null !== $delta){$valor=F3Base_Config_Mescla::preservar($entrada['valor'],$valor,$delta,F3Base_Config_Contrato::schema_entrada($d));}
        if($nome===F3Base_Meta_Ads::OPTION){$valor=F3Base_Meta_Ads::preparar_escrita($valor);}
        $removidos=F3Base_Config_Mescla::removidos($bruto['valor'],$valor);
		if ( $entrada['simular'] ?? true ) {
			$result = array_replace(
				F3Base_Options::resultado_gravacao( false, self::visivel( $nome, $foto['valor'] ) ),
				array(
					'ok'       => true,
					'simulado' => true,
                    'persisted'=>false,'changed'=>false,'alteraria'=>F3Base_Options::e_segredo($nome)?!hash_equals(F3Base_Segredos::abrir($nome),trim((string)$entrada['valor'])):!F3Base_Options::equivalente($bruto['valor'],$valor),'campos_removidos'=>$removidos,
					'nome'     => $nome,
					'revisao'  => $revisao,
					'antes'    => self::visivel( $nome, $bruto['valor'] ),
					'depois'   => self::visivel( $nome, $valor ),
					'motivo' => 'Simulação concluída; nenhuma configuração foi gravada.',
                    'avisos' => array_merge($ajuste['avisos'],F3Base_Segredos::gerenciado($nome)&&is_string($entrada['valor'])?F3Base_Credenciais::avisos_formato($nome,$entrada['valor']):array()),
				)
			);
            unset($result['lido']);if($paths!==null){$result['antes']=F3Base_Config_Caminhos::trechos($foto['valor'],$paths);$result['depois']=F3Base_Config_Caminhos::trechos($valor,$paths);}return $result;
		}
		$r            = F3Base_Options::pelo_canal( 'ability', static fn() => F3Base_Options::gravar( $nome, $entrada['valor'], F3Base_Options::ORIGEM_ABILITY, $esperada, $delta ) );
        $r['campos_removidos']=$removidos;
        $r['avisos']=array_merge($r['avisos']??array(),F3Base_Config_Consultas::heranca($nome,$d)['avisos']);
		$r['lido']    = self::visivel( $nome, $r['lido'] );
		$r['revisao'] = $r['revisao'] ?? F3Base_Options::revisao( $nome );
		if ( F3Base_Options::e_segredo( $nome ) && ! empty( $r['ok'] ) ) {
			$r['motivo'] = ''; }
		return $r;
	}
	private static function recusa( string $codigo, string $motivo = '' ): array {
		return F3Base_Options::resultado_gravacao( false, null, $motivo, $codigo ); }
}
