<?php
/** Primitivas comuns; cada destino conserva seu contrato, retenção e estados. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Fila {
    private static array $acordar=array();
    public const RECORRENCIAS = [
        'f3base_wp_mail_processar'=>'f3base_filas_5m',
        'f3base_pipedrive_processar'=>'f3base_filas_5m',
        'f3base_email_novo_lead_processar'=>'hourly',
        'f3base_linkedin_notificacoes'=>'f3base_filas_5m',
        'f3base_conversoes_servidor'=>'hourly',
        'f3base_capi_recuperar'=>'daily',
    ];
    // Argumento reservado da ocorrência física. O executor chama o trabalhador sem argumentos.
    public const ANTECIPAR = ['antecipacao_fila'];

    public static function intervalos(array $s): array {
        $s['f3base_filas_5m'] = ['interval'=>300,'display'=>'Filas do Core a cada cinco minutos'];
        return $s;
    }

    private static function ocorrencias_regulares(string $hook): array {
        $horas=[];
        $chave=md5(serialize([]));
        foreach (_get_cron_array() as $hora=>$eventos) {
            if (isset($eventos[$hook][$chave])) { $horas[]=(int)$hora; }
        }
        return $horas;
    }

    public static function periodicidade(string $hook, bool $ativa = true): bool {
        $frequencia=self::RECORRENCIAS[$hook];
        $horas=self::ocorrencias_regulares($hook);
        if ($ativa && count($horas)===1 && wp_get_schedule($hook)===$frequencia) { return true; }
        if (!$ativa && !$horas && !wp_next_scheduled($hook,self::ANTECIPAR)) { return true; }
        $trava=F3Base_Trava::adquirir('fila-recorrente-'.md5($hook),30);
        if (!$trava) { return false; }
        try {
            $horas=self::ocorrencias_regulares($hook);
            if (!$ativa) {
                foreach ([[],self::ANTECIPAR] as $args) {
                    if (wp_next_scheduled($hook,$args)) { wp_clear_scheduled_hook($hook,$args,true); }
                    if (wp_next_scheduled($hook,$args)) { return false; }
                }
                return true;
            }
            $primeira=array_shift($horas)??time()+60;
            if (wp_get_schedule($hook)!==$frequencia && wp_schedule_event($primeira,$frequencia,$hook,[],true)!==true) { return false; }
            foreach ($horas as $duplicada) {
                if (wp_unschedule_event($duplicada,$hook,[],true)!==true) { return false; }
            }
            return wp_get_schedule($hook)===$frequencia;
        } finally { F3Base_Trava::liberar($trava); }
    }

    private static function antecipar(string $hook,int $prazo): array {
        $hora = wp_next_scheduled($hook);
        if (!$hora) {
            $ativa=match ($hook) {
                'f3base_wp_mail_processar'=>!empty(F3Base_Email_Site::cfg()['wp_mail_pela_caixa']),
                'f3base_pipedrive_processar'=>!empty(F3Base_Options::ler('f3base_pipedrive')['ativo']),
                'f3base_linkedin_notificacoes'=>F3Base_Linkedin_Integracoes::ativas(),
                default=>true
            };
            if ($ativa) { self::periodicidade($hook); $hora=wp_next_scheduled($hook); }
        }
        if ($hora && $hora <= $prazo) {
            return ['ok'=>true,'agendado'=>true,'codigo'=>'recorrencia_atende','proxima_execucao'=>$hora,'processamento_confirmado'=>false];
        }
        $trava = F3Base_Trava::adquirir('fila-urgente-'.md5($hook),30);
        if (!$trava) { return ['ok'=>false,'agendado'=>false,'codigo'=>'agenda_ocupada']; }
        try {
            $atual = wp_next_scheduled($hook,self::ANTECIPAR);
            $regular = wp_next_scheduled($hook);
            $antes = min($atual ?: PHP_INT_MAX,$regular ?: PHP_INT_MAX);
            if ($antes <= $prazo) {
                return ['ok'=>true,'agendado'=>true,'codigo'=>'agenda_ja_antecipada','proxima_execucao'=>$antes,'processamento_confirmado'=>false];
            }
            if ($atual && wp_unschedule_event($atual,$hook,self::ANTECIPAR,true)!==true) {
                return ['ok'=>false,'agendado'=>false,'codigo'=>'agenda_remocao_falhou'];
            }
            wp_schedule_single_event($prazo,$hook,self::ANTECIPAR,true);
            $lido = wp_next_scheduled($hook,self::ANTECIPAR);
            $ok = $lido && $lido <= $prazo;
            if (!$ok && $atual && !$lido) { wp_schedule_single_event($atual,$hook,self::ANTECIPAR); }
            if ($ok && $prazo <= time()+1 && !(defined('DISABLE_WP_CRON') && DISABLE_WP_CRON)
                && !(F3Base_Zelador::rotina($hook) && F3Base_Zelador::protegido()) && !isset(self::$acordar[$hook])) {
                self::$acordar[$hook]=true; add_action('shutdown',static function(){spawn_cron();});
            }
            return ['ok'=>(bool)$ok,'agendado'=>(bool)$ok,'codigo'=>$ok?'agenda_antecipada':'agenda_gravacao_falhou',
                'proxima_execucao'=>$lido?:$regular?:null,'processamento_confirmado'=>false];
        } finally { F3Base_Trava::liberar($trava); }
    }

    /** O adaptador fornece SQL fechado e valores; retorno estrito evita duas posses. */
    public static function reservar_condicional(string $sql,array $args): bool {global $wpdb;return $wpdb->query($wpdb->prepare($sql,...$args))===1;}
    public static function possui(?array $row,string $coluna,string $token,array $estados): bool {return $row&&$token!==''&&isset($row[$coluna])&&hash_equals($token,(string)$row[$coluna])&&in_array($row['estado'],$estados,true);}
    public static function lease(): string {return wp_generate_uuid4();}
    public static function restante(float $inicio,int $segundos): int {return max(0,(int)floor(max(1,min(30,$segundos))-(microtime(true)-$inicio)));}
    public static function agendar(string $hook,int $quando=0): bool {
        return !empty(self::agendar_detalhe($hook,$quando)['agendado']);
    }
    public static function agendar_detalhe(string $hook,int $quando=0): array {
        if(!F3Base_Cron_Diagnostico::proprio($hook)){return array('ok'=>false,'agendado'=>false,'codigo'=>'hook_fora_do_core','despacho'=>'nao_tentado');}
        if (isset(self::RECORRENCIAS[$hook])) { return self::antecipar($hook,$quando ?: time()); }
        $quando=$quando?:time();$intencao=F3Base_Cron_Diagnostico::intencao($hook);$lock=F3Base_Trava::adquirir('agenda-'.substr(hash('sha256',$hook),0,32),30);
        if(!$lock){return array('ok'=>false,'agendado'=>false,'codigo'=>'agenda_ocupada','proxima_execucao'=>wp_next_scheduled($hook)?:null,'despacho'=>'nao_tentado');}
        try {
            $old=wp_get_scheduled_event($hook);$atual=$old?(int)$old->timestamp:0;$proof=F3Base_Cron_Diagnostico::conferir('reagendar',$hook,array('timestamp'=>$quando,'args'=>array(),'schedule'=>false));$ok=$proof===true;$code=$proof===null?'agenda_nao_verificavel':($ok?'agenda_ja_antecipada':'agenda_pendente');
            if(!$ok&&$proof===false){
                $removed=!$old||wp_unschedule_event($old->timestamp,$hook,$old->args,true)===true;
                $scheduled=$removed?wp_schedule_single_event($quando,$hook,array(),true):false;
                wp_cache_delete('cron','options');wp_cache_delete('alloptions','options');$confirmed=wp_get_scheduled_event($hook);$ok=F3Base_Cron_Diagnostico::conferir('reagendar',$hook,array('timestamp'=>$quando,'args'=>array(),'schedule'=>false))===true;$idempotente=$ok&&$scheduled!==true;
                $code=$ok?(!empty($idempotente)?'agenda_confirmada_apos_releitura':'agenda_antecipada'):($removed?'agenda_gravacao_falhou':'agenda_remocao_falhou');
                if(!$ok&&$removed&&$old){$restored=$old->schedule?wp_schedule_event($old->timestamp,$old->schedule,$hook,$old->args,true):wp_schedule_single_event($old->timestamp,$hook,$old->args,true);$code.=$restored===true?'_anterior_restaurada':'_restauracao_falhou';}
            }
            if(F3Base_Cron_Diagnostico::intencao($hook)['revisao']!==$intencao['revisao']){if(!empty($scheduled)&&$scheduled===true){wp_unschedule_event($quando,$hook,array(),true);}$ok=false;$code='intencao_substituida_durante_gravacao';}
            $diag=F3Base_Options::atualizar_estado('f3base_agenda',static function($s)use($hook,$ok,$quando,$code,$intencao){$s['observacoes']=array_values(array_filter($s['observacoes']??array(),static fn($x)=>($x['em']??0)>time()-DAY_IN_SECONDS));if(!$ok||$code==='agenda_confirmada_apos_releitura'){$s['observacoes'][]=array('hook'=>$hook,'em'=>time(),'codigo'=>$code,'origem'=>defined('WP_CLI')&&WP_CLI?'cli':(wp_doing_cron()?'http_cron':'manual'));$s['observacoes']=array_slice($s['observacoes'],-200);$hour=gmdate('YmdH');$origin=defined('WP_CLI')&&WP_CLI?'cli':(wp_doing_cron()?'http_cron':'manual');$s['contadores'][$hour][$hook][$origin][$code]=($s['contadores'][$hour][$hook][$origin][$code]??0)+1;foreach(array_keys($s['contadores']) as $h){if((string)$h<gmdate('YmdH',time()-DAY_IN_SECONDS)){unset($s['contadores'][$h]);}}}if($ok){if(!isset($s['pendencias'][$hook])||($s['pendencias'][$hook]['intencao']['revisao']??'')===$intencao['revisao']){if(isset($s['pendencias'][$hook])){$s['resolucoes'][]=array('hook'=>$hook,'estado'=>'resolvida','em'=>time(),'revisao_intencao'=>$intencao['revisao']);$s['resolucoes_omitidas']=(int)($s['resolucoes_omitidas']??0)+max(0,count($s['resolucoes'])-100);$s['resolucoes']=array_slice($s['resolucoes'],-100);}unset($s['pendencias'][$hook]);}}elseif(F3Base_Cron_Diagnostico::proprio($hook)){$old=$s['pendencias'][$hook]??array();$same=($old['intencao']['revisao']??null)===$intencao['revisao'];$s['pendencias'][$hook]=$same?$old:array('quando'=>$quando,'tentar_em'=>time()+60,'tentativas'=>0,'primeira_em'=>time(),'intencao'=>$intencao,'estado'=>'pendente');$s['pendencias'][$hook]['ultima_em']=time();}return $s;});
            $dispatch='aguardando_horario';$external=defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON;
            if($ok&&F3Base_Zelador::rotina($hook)&&F3Base_Zelador::protegido()){$dispatch='aguardando_cron_cli';}
            elseif($ok&&$external){$dispatch='aguardando_executor_externo';}
            elseif($ok&&$quando<=time()+1){$dispatch='solicitacao_no_shutdown';if(!isset(self::$acordar[$hook])){self::$acordar[$hook]=true;add_action('shutdown',static function(){spawn_cron();});}}
            return array('ok'=>(bool)$ok,'agendado'=>(bool)$ok,'codigo'=>$code,'proxima_execucao'=>wp_next_scheduled($hook)?:null,'despacho'=>$dispatch,'processamento_confirmado'=>false,'diagnostico_persistido'=>!empty($diag['persisted']));
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function retomar(): void {
        if(!F3Base_Recuperacao::entrar()){return;}
        try{$n=F3Base_Cron_Diagnostico::retomar(3);$s=get_option('f3base_agenda',array());foreach($s['pendencias']??array() as $hook=>$p){
            if($n>=3){break;}if(($p['tentar_em']??0)>time()||($p['tentativas']??0)>=5){continue;}++$n;$i=F3Base_Cron_Diagnostico::intencao($hook);$reason=!empty($i['verificavel'])&&empty($i['ativa'])?'cancelada':(!empty($p['intencao']['revisao'])&&$p['intencao']['revisao']!==$i['revisao']?'substituida':'');
            $can=!$reason&&!empty($i['verificavel'])&&!empty($i['ativa'])&&!empty($p['intencao']['revisao']);$next=$p;$next['tentativas']=(int)($p['tentativas']??0)+1;$next['tentar_em']=time()+min(3600,60*2**$next['tentativas']);$next['estado']=$next['tentativas']>=5?'esgotada':($can?'pendente':'nao_verificavel');
            $saved=F3Base_Options::atualizar_estado('f3base_agenda',static function($s)use($hook,$p,$reason,$next){if(($s['pendencias'][$hook]??null)!==$p){return null;}if($reason){$s['resolucoes'][]=array('hook'=>$hook,'estado'=>$reason,'em'=>time(),'revisao_intencao'=>$p['intencao']['revisao']??'');$s['resolucoes']=array_slice($s['resolucoes'],-100);unset($s['pendencias'][$hook]);}else{$s['pendencias'][$hook]=$next;}return $s;});
            if(empty($saved['persisted'])||!$can){continue;}if(F3Base_Cron_Diagnostico::intencao($hook)['revisao']!==$i['revisao']){continue;}
            self::agendar_detalhe($hook,max(time()+1,(int)$p['quando']));
        }}finally{F3Base_Recuperacao::sair();}
    }
    public static function resumo(): array {$s=get_option('f3base_agenda',array());$r=array('wordpress'=>F3Base_Cron_Diagnostico::resumo(),'pendencias'=>$s['pendencias']??array(),'ultimas_observacoes'=>array_slice($s['observacoes']??array(),-30),'contagens_por_hora'=>$s['contadores']??array(),'resolucoes'=>$s['resolucoes']??array(),'resolucoes_omitidas'=>$s['resolucoes_omitidas']??0,'observacoes_exibidas'=>min(30,count($s['observacoes']??array())),'observacoes_retidas'=>count($s['observacoes']??array()),'janela'=>'24 horas em baldes UTC; inclui a hora limítrofe','terceiros'=>'Somente os ganchos do Core são reconciliados.');return $r;}
    public static function percentil(array $v,float $p): ?int {if(!$v){return null;}sort($v,SORT_NUMERIC);return (int)$v[max(0,(int)ceil(count($v)*$p)-1)];}
}
