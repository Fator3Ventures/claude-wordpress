<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

final class F3Base_Limite_Relatorio extends RuntimeException {
    public function __construct(public readonly array $diagnostico) { parent::__construct('limite_memoria'); }
}

final class F3Base_Leitura_Relatorio {
    private const LOTE = 32;
    private static array $colunas = [];

    public static function conferir(int $previsto = 0): void {
        $uso = memory_get_usage(true);
        $orcamento = F3Base_Editorial_Relatorios::orcamento_memoria(ini_get('memory_limit'), $uso);
        $disponivel = $orcamento['memoria_disponivel_bytes'] ?? 0;
        if ($disponivel < $previsto + 4 * MB_IN_BYTES) {
            throw new F3Base_Limite_Relatorio(['uso_bytes'=>$uso, 'disponivel_bytes'=>$disponivel, 'previsao_bytes'=>$previsto]);
        }
    }

    /** Medir no servidor SQL antes que mysqli armazene o resultado no PHP. */
    public static function custo(string $tabela, string $de, string $ate, int $maximo): ?array {
        global $wpdb;
        if (!isset(self::$colunas[$tabela])) {
            $campos = $wpdb->get_results($wpdb->prepare('SHOW COLUMNS FROM %i', $tabela), ARRAY_A);
            if (!$campos || $wpdb->last_error) { return null; }
            $larguras = [];
            foreach ($campos as $campo) {
                if (preg_match('/char|text|blob|json|binary/i', $campo['Type'])) {
                    $larguras[] = $wpdb->prepare('COALESCE(OCTET_LENGTH(%i),0)', $campo['Field']);
                }
            }
            self::$colunas[$tabela] = $larguras ? implode('+', $larguras) : '0';
        }
        $sql = 'SELECT COUNT(*) quantidade, COALESCE(SUM(tamanho),0) bytes FROM (SELECT ' . self::$colunas[$tabela]
            . ' AS tamanho FROM %i WHERE criado_em >= %s AND criado_em < %s LIMIT %d) f3_custo';
        $r = $wpdb->get_row($wpdb->prepare($sql, $tabela, $de, $ate, $maximo), ARRAY_A);
        return $r && !$wpdb->last_error ? array_map('intval', $r) : null;
    }

    /** Consultas internas com ordenação estável e LIMIT numérico final. */
    public static function linhas(string $sql): array {
        global $wpdb;
        if (!preg_match('/\s+LIMIT\s+(\d+)(?:\s+OFFSET\s+(\d+))?\s*$/iD', $sql, $m, PREG_OFFSET_CAPTURE)) {
            throw new LogicException('consulta_sem_limite');
        }
        $limite = (int)$m[1][0];
        $inicio = (int)($m[2][0] ?? 0);
        $base = substr($sql, 0, $m[0][1]);
        $total = [];
        for ($pos = 0; $pos < $limite; $pos += self::LOTE) {
            self::conferir();
            $n = min(self::LOTE, $limite - $pos);
            $pagina = $wpdb->get_results($base . $wpdb->prepare(' LIMIT %d OFFSET %d', $n, $inicio + $pos), ARRAY_A);
            if ($wpdb->last_error) { return []; }
            foreach ($pagina as $linha) { $total[] = $linha; }
            if (count($pagina) < $n) { break; }
        }
        return $total;
    }
}
