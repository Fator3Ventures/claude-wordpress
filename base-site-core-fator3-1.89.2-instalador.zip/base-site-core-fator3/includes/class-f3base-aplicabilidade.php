<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

final class F3Base_Aplicabilidade {
    const ROTA = 'f3base/aplicabilidade-ler';
    private const TAREFAS = [
        'cache_reaquecimento'=>'reaquecimento','ga4_acervo'=>'ga4','google_ads_acervo'=>'google_cliques',
        'anuncios_meta'=>'anuncios','anuncios_linkedin'=>'anuncios','wp_mail'=>'wp_mail',
        'conversoes_servidor'=>'conversoes_servidor','capi'=>'capi','whatsapp_site'=>'whatsapp_conversa','pipedrive'=>'pipedrive','email_historico'=>'email_historico',
        'email_novo_lead'=>'email_novo_lead','email_site'=>'email_site','gsc'=>'gsc','gsc_consultas'=>'gsc_consultas',
        'meta_monitoramento'=>'meta_monitoramento','primeira_resposta'=>'primeira_resposta','qualidade'=>'qualidade',
        'clarity_coleta'=>'clarity','redes_robos'=>'redes_robos','marcas_vigiadas'=>'marcas',
    ];

    private static function flags(): array {
        $flags = [];
        foreach (F3Base_Options::catalogo() as $nome=>$declaracao) {
            if (!empty($declaracao['estado_execucao']) || !is_array($declaracao['padrao']??null)
                || !array_key_exists('ativo',$declaracao['padrao'])) { continue; }
            $id = preg_replace('/^f3base_/', '', $nome);
            $flags[$id] = ['opcoes'=>[$nome.'.ativo'],'condicao'=>'Ativação de '.($declaracao['rotulo']??$id).' na configuração efetiva.',
                'resultado'=>!empty(F3Base_Options::ler($nome)['ativo'])];
        }
        $especial = static function(string $nome,array $opcoes,string $descricao,bool $valor) use (&$flags) {
            $flags[$nome]=['opcoes'=>$opcoes,'condicao'=>$descricao,'resultado'=>$valor];
        };
        $especial('email_historico',['f3base_email_historico.ativo','f3base_pipedrive.ativo'],
            'Conferir o histórico quando a política de histórico e o CRM estiverem ativos.',F3Base_Email_Historico::aplicavel());
        $especial('wp_mail',['f3base_email_site.wp_mail_pela_caixa'],'Processar o transporte WordPress pela caixa configurada.',!empty(F3Base_Email_Site::cfg()['wp_mail_pela_caixa']));
        $especial('anuncios_linkedin',['f3base_anuncios_linkedin.integracoes[].ativo'],'Coletar quando ao menos uma integração LinkedIn estiver ativa.',F3Base_Linkedin_Integracoes::ativas());
        $especial('google_ads_acervo',['f3base_google_ads_acervo.ativo','f3base_google_ads_acervo.conexao','f3base_google_ads_acervo.conta_id','f3base_recuperacao'],
            'O enriquecimento requer acervo ativo, conexão, conta válida e Core disponível.',F3Base_Google_Acervo::configuracao()['ready']);
        $c=F3Base_Meta_Monitoramento::opcoes();
        $especial('meta_monitoramento',['f3base_meta_monitoramento.ativo','f3base_meta_monitoramento.avisar'],
            'Agendar a verificação quando o monitoramento e seus avisos estiverem habilitados.',!empty($c['ativo'])&&!empty($c['avisar']));
        $especial('clarity_coleta',['f3base_clarity.coleta_ativa','f3base_clarity_project_id','f3base_clarity_api_token'],
            'A coleta exige projeto, credencial verificada para o projeto e coleta ativa.',F3Base_Clarity::configurado()&&!empty(F3Base_Options::ler('f3base_clarity')['coleta_ativa']));
        $especial('redes_robos',['f3base_medicao_editorial.redes_oficiais'],'Atualizar a lista quando a medição de redes oficiais estiver habilitada.',!empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais']));
        $especial('marcas_vigiadas',['f3base_marcas_vigiadas'],'Executar a inspeção quando houver marcas cadastradas.',(bool)F3Base_Options::ler('f3base_marcas_vigiadas'));
        $especial('conversoes_servidor',[],'Mantém a fila de conversões disponível para entregas autorizadas.',true);
        $especial('capi',[],'O recuperador da fila exige a estrutura CAPI disponível.',F3Base_Capi_Fila::pronta());
        foreach (['gsc'=>F3Base_Gsc::class,'gsc_consultas'=>F3Base_Gsc_Consultas::class] as $id=>$classe) {
            $flags[$id]['precondicoes_coleta']=['configuracao_pronta'=>$classe::configuracao()['ready'],'sdk_registrado'=>$classe::registro()==='registrado'];
            $flags[$id]['condicao'].=' A coleta requer propriedade validada, acervo disponível e SDK registrado.';
            $flags[$id]['opcoes'][]='f3base_gsc_property';
        }
        return $flags;
    }

    /** Só expõe regras, resultados e nomes de opção. Nunca expõe valores de credenciais. */
    private static function regras(): array {
        $regras=self::flags();
        $tarefas=F3Base_Operacao::tarefas();
        foreach ($regras as $id=>&$r) {
            $tarefa=self::TAREFAS[$id]??null;
            $hooks=$tarefas[$tarefa]['hooks']??[];
            if ($id==='anuncios_meta') { $hooks=[F3Base_Anuncios::EVENTO,F3Base_Captacao_Operacao::HOOK]; }
            if ($id==='anuncios_linkedin') { $hooks=[F3Base_Linkedin::EVENTO,F3Base_Linkedin_Webhook::EVENTO,F3Base_Linkedin_Webhook::MANUTENCAO,F3Base_Linkedin_Campanhas::EVENTO]; }
            $r['ganchos']=$hooks;
            $r['tarefas_espera']=$tarefa?[$tarefa]:[];
            $r['recorrencias']=array_intersect_key(F3Base_Fila::RECORRENCIAS,array_flip($hooks));
            $r['quando_ativo']=$hooks?'Execução elegível. A agenda observada identifica as ocorrências instaladas.':'Ativa a função quando houver entrada elegível.';
            $r['quando_inativo']=$hooks?'A configuração impede a função. Pendências e ganchos compartilhados seguem a política própria da tarefa.':'Desativa a função para novas entradas.';
            if ($id==='email_historico') {
                $r['quando_ativo']='O zelador mantém a conferência a cada cinco minutos.';
                $r['quando_inativo']='O zelador remove a conferência e conclui esperas anteriores sem reserva ativa.';
            }
            if ($id==='ga4_acervo') {
                $r['quando_ativo']='Agenda a coleta; uma conclusão automática cobre continuações antigas compatíveis.';
                $r['quando_inativo']='Remove o gancho de coleta e a continuação do GA4.';
            }
            if (in_array($id,['meta_monitoramento','google_ads_acervo','clarity_coleta'],true)) {
                $r['quando_inativo']='Remove o agendamento periódico da coleta ou do monitoramento.';
            }
            if ($id==='email_novo_lead') { $r['quando_inativo']='Novas entregas dependem da política; o trabalhador periódico continua disponível para a fila.'; }
            if (isset($r['recorrencias']) && $r['recorrencias']) {
                $r['quando_ativo'].=' Mantém a recorrência indicada; um prazo anterior com trabalho pendente antecipa uma única passagem.';
            }
            if (in_array($id,['wp_mail','pipedrive','anuncios_linkedin'],true)) {
                $r['quando_inativo']='O zelador retira a recorrência e sua antecipação. Os recibos e os registros de espera permanecem sujeitos ao executor.';
            }
            if (in_array($id,['gsc','gsc_consultas'],true)) {
                $r['quando_ativo']='Agenda a coleta diária quando configuração e SDK estão prontos; a continuação depende do trabalho.';
                $r['quando_inativo']='Ao desligar a política ou remover a propriedade, o zelador retira coleta e continuação.';
            }
            $r['revisao']=$id==='email_historico'?2:1;
            $r['revisao_agenda']=array_intersect($hooks,array_keys(F3Base_Fila::RECORRENCIAS))?2:1;
        }
        unset($r);
        foreach (F3Base_Registro::instanciar() as $m) {
            $estado=$m->estado();
            $hooks=[]; $jobs=[];
            foreach ($m->hooks() as $h) {
                $tarefa=F3Base_Operacao::identificar_hook($h['hook']??'');
                if ($tarefa) { $hooks[]=$h['hook']; $jobs[]=$tarefa; }
            }
            $regras['modulo/'.$m->id()]=['condicao'=>$m->nome().'. '.$estado['motivo'],'opcoes'=>$m->options_que_controlam(),
                'resultado'=>$m->deve_registrar(),'estado'=>$estado['estado'],'revisao'=>1,'ganchos'=>array_values(array_unique($hooks)),
                'tarefas_espera'=>array_values(array_unique($jobs)),'quando_ativo'=>'Registra os ganchos normais do módulo.',
                'quando_inativo'=>'Apenas ganchos declarados como permanentes continuam elegíveis.'];
        }
        ksort($regras);
        return $regras;
    }

    public static function ler(array $entrada=[]): array {
        if (!current_user_can('manage_options')) { return ['ok'=>false,'codigo'=>'sem_permissao']; }
        $regras=self::regras();
        if (isset($entrada['modulo'])) {
            if (!isset($regras[$entrada['modulo']])) { return ['ok'=>false,'codigo'=>'modulo_desconhecido']; }
            $regras=[$entrada['modulo']=>$regras[$entrada['modulo']]];
        }
        global $wpdb;
        $por_tarefa=[];
        $estados=$wpdb->get_results($wpdb->prepare("SELECT tarefa,hook,estado,COUNT(*) n FROM %i WHERE estado IN ('pendente','esgotada','suspensa') GROUP BY tarefa,hook,estado", F3Base_Operacao_Intencoes::tabela()),ARRAY_A);
        $disponivel=!$wpdb->last_error;
        foreach ($estados?:[] as $e) { $por_tarefa[$e['tarefa']][]=['gancho'=>$e['hook'],'estado'=>$e['estado'],'quantidade'=>(int)$e['n']]; }
        foreach ($regras as &$r) {
            $r['esperas_observadas']=$disponivel?[]:null;
            if ($disponivel) {
                foreach ($r['tarefas_espera'] as $tarefa) {
                    foreach ($por_tarefa[$tarefa]??[] as $espera) { $r['esperas_observadas'][]=$espera; }
                }
            }
            $r['proximos']=[];
            foreach ($r['ganchos'] as $hook) { $r['proximos'][$hook]=wp_next_scheduled($hook)?:null; }
        }
        unset($r);
        return ['ok'=>true,'versao'=>F3BASE_PLUGIN_VERSAO,'contrato'=>1,'regras'=>$regras];
    }

    public static function compacto(array $entrada=[]): array {
        if (!current_user_can('manage_options')) { return ['ok'=>false,'codigo'=>'sem_permissao']; }
        global $wpdb;
        $modulos=[];
        foreach (self::regras() as $id=>$r) {
            if (!empty($entrada['assuntos'])&&!in_array($id,$entrada['assuntos'],true)&&!in_array(preg_replace('~^modulo/~','',$id),$entrada['assuntos'],true)) { continue; }
            $modulos[$id]=$r['estado']??($r['resultado']?'ativo':'inativo');
        }
        $linhas=$wpdb->get_results($wpdb->prepare("SELECT estado,COUNT(*) n FROM %i WHERE estado IN ('pendente','esgotada','suspensa') GROUP BY estado",F3Base_Operacao_Intencoes::tabela()),ARRAY_A);
        $contagens=$wpdb->last_error?null:['pendente'=>0,'esgotada'=>0,'suspensa'=>0];
        foreach ($linhas?:[] as $linha) { $contagens[$linha['estado']]=(int)$linha['n']; }
        $falhas=0;
        foreach (F3Base_Options::ler(F3Base_Operacao::OPTION)?:[] as $tarefa) {
            if (in_array($tarefa['ultima']['status']??'', ['falha','pendente'], true)) { ++$falhas; }
        }
        $ciclo=F3Base_Instalacao::resumo();
        return ['ok'=>true,'plugin'=>'base-site-core-fator3','versao'=>F3BASE_PLUGIN_VERSAO,'contrato'=>F3Base_Config_Contrato::VERSAO,
            'atualizacao'=>['versao_alvo'=>F3BASE_PLUGIN_VERSAO,'estado'=>$ciclo['estado']??null,'falhas'=>$ciclo['falhas']??null,
                'confirmada_no_executor_em'=>$ciclo['confirmada_no_executor_em']??null,'confirmada_em'=>$ciclo['finalizacao_em']?:null,'detalhe'=>'f3base/saude-ler'],
            'aplicabilidade'=>['modulos'=>$modulos,'detalhe'=>self::ROTA],
            'esperas'=>['contagens'=>$contagens,'detalhe'=>'f3base/saude-ler'],
            'erros_ativos'=>['tarefas_com_ultima_falha'=>$falhas,'modulos_degradados'=>count(array_keys($modulos,'degradado',true)),'detalhe'=>'f3base/saude-ler']];
    }
}
