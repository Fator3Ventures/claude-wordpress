<?php
/** Validadores dos controles de entrega. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Release_Configuracao {
	public static function estado( $v, $padrao ): array {
		return is_array( $v ) ? $v : $padrao; }
	public static function google( $v, array $padrao ): array {
		$v = is_array( $v ) ? $v : array();
		return array_replace(
			$padrao,
			$v,
			array(
				'modo'          => in_array($v['modo']??'',array('apos_interacao','ocioso','fixo'),true) ? $v['modo'] : 'imediato',
				'teto_segundos' => max( 0, min( 30, (int) ( $v['teto_segundos'] ?? 5 ) ) ),
			)
		);
	}
	public static function verificar_google(): array {
		$gtm    = F3Base_Options::ler( 'f3base_gtm_container_id' );
		$direto = F3Base_Options::ler( 'f3base_ga4_measurement_id' ) || ! empty( F3Base_Options::ler( 'f3base_google_ads' )['conversion_id'] );
		return array(
			'status' => ! $direto ? 'not_required' : 'pending',
			'scope'  => 'browser',
			'codigo' => ! $direto ? 'nao_aplicavel' : 'requer_observacao',
			'motivo' => 'Aplica-se somente ao Google direto GA4/Ads. Inserção do script não comprova entrega de eventos.',
		);
	}
	public static function recusar_google( $v ): string {
		if ( ! is_array( $v ) || ! in_array( $v['modo'] ?? 'imediato', array( 'imediato', 'apos_interacao', 'ocioso', 'fixo' ), true ) || ! self::inteiro( $v['teto_segundos'] ?? 5, 0, 30 ) ) {
			return 'Modo inválido ou prazo fora de 0 a 30 segundos.'; }
		return '';
	}
	public static function recusar_llms( $v ): string {
		if ( ! is_array( $v ) || ! in_array( $v['entrega'] ?? 'dinamica', array( 'dinamica', 'arquivo_gerado' ), true ) || ! self::inteiro( $v['atualizacao_intervalo_segundos'] ?? 3600, 60, 86400 ) ) {
			return 'Entrega inválida ou intervalo fora de 60 a 86400 segundos.'; }
		return '';
	}
	private static function inteiro( $v, int $min, int $max ): bool {
		return false !== filter_var( $v, FILTER_VALIDATE_INT ) && (int) $v >= $min && (int) $v <= $max; }
}
