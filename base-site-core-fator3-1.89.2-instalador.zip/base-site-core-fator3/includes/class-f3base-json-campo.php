<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

/** JSON estruturado persistido. O diagnóstico contém apenas campo, forma e contagem. */
final class F3Base_Json_Campo {
    private static array $avisos = [];

    public static function ler(mixed $valor, string $campo, ?bool &$valido = null): array {
        $valido = true;
        if (is_array($valor)) { return $valor; }
        if ($valor === null || $valor === '') { return []; }
        if (is_string($valor)) {
            $dados = json_decode($valor, true);
            if (is_array($dados)) { return $dados; }
        }
        $valido = false;
        self::avisar($campo, is_string($valor) ? 'json_sem_estrutura' : get_debug_type($valor));
        return [];
    }

    public static function texto(mixed $valor, string $campo): string {
        if (is_string($valor)) { return $valor; }
        if ($valor !== null) { self::avisar($campo, get_debug_type($valor)); }
        return '';
    }

    public static function avisar(string $campo, string $forma): void {
        $chave = $campo . '/' . $forma;
        self::$avisos[$chave] = (self::$avisos[$chave] ?? 0) + 1;
        if (self::$avisos[$chave] === 1) {
            do_action('f3base_json_campo_invalido', $campo, $forma);
            error_log('Fator3 Site Core: campo histórico ignorado (' . $chave . ').');
        }
    }

    public static function avisos(): array { return self::$avisos; }
}
