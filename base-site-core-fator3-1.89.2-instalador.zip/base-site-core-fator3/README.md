# Fator3 Site Core 1.89.2

Versão 1.89.2. Catálogo Motorola corrigido por codinome, incluindo o Moto G8 Power Lite. Consulte docs/RELEASE-1.89.2.md.

Instalação nova ou atualização da 1.89.1. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

Índice de operação em docs/DOCUMENTACAO.md.
