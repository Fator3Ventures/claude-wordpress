<?php
/** Public projection prepared on configuration writes. Never contains visitor tokens. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Ativos_Publicos {
    const OPTION='f3base_ativos_publicos';
    const ENTRADAS=array('f3base_gtm_container_id','f3base_ga4_measurement_id','f3base_google_ads','f3base_meta_pixel_id','f3base_meta_transporte','f3base_meta_homologacao','f3base_meta_auto_config','f3base_linkedin_partner_id','f3base_linkedin_conversion_id','f3base_linkedin_conteudo_conversion_id','f3base_clarity_project_id','f3base_google_carregamento','f3base_carregamento_destinos','f3base_comportamento','f3base_conversoes_conteudo','f3base_eventos_destinos','f3base_consentimento','f3base_consentimento_politica');
    private static bool $pendente=false;
    private static bool $gerando=false;
    private static ?array $build=null;
    public static function build(): array {if(self::$build===null){$file=F3BASE_PLUGIN_DIR.'includes/ativos-build.php';self::$build=is_file($file)?require $file:array();}return self::$build;}
    public static function versao(string $file): string {return self::build()['arquivos'][$file]['sha256']??F3BASE_PLUGIN_VERSAO;}
    public static function revisao(): string {return (string)(F3Base_Perfil_Publico::config()['revisao']??'');}
    public static function assinatura(array $config): string {return hash('sha256',wp_json_encode(array(F3BASE_PLUGIN_VERSAO,array_intersect_key($config['valores']??array(),array_flip(self::ENTRADAS)))));}
    public static function iniciar(): void {
        add_action('updated_option',array(__CLASS__,'alterada'),300,3);
        add_action('added_option',static function($n,$v){self::alterada($n,null,$v);},300,2);
        add_action('shutdown',array(__CLASS__,'publicar'),5);
        add_action('f3base_zelador',array(__CLASS__,'recuperar'),3);
        add_action('f3base_zelador',array(__CLASS__,'podar'),4);
        add_action('wp_head',array(__CLASS__,'bootstrap'),2);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('ativos-publicos-ler','Estado da configuração e dos módulos públicos pré-gerados',array(__CLASS__,'ler'));});
    }
    public static function alterada($nome,$antes,$depois): void {if(!self::$gerando&&$nome===F3Base_Perfil_Publico::OPTION&&($antes['revisao']??null)!==($depois['revisao']??null)){self::$pendente=true;}}
    public static function recuperar(): void {self::$pendente=true;self::publicar();}
    /** Migration/executor barrier: no cache-generating proof before this succeeds. */
    public static function preparar_ciclo(): array {
        if(self::valido()===null){self::recuperar();}
        $m=self::valido();
        return array('ok'=>$m!==null,'codigo'=>$m!==null?'ativos_publicos_vigentes':'aguardando_ativos_publicos','versao'=>$m['versao']??null,'gerado_em'=>$m['gerado_em']??null,'sha256'=>$m['sha256']??null);
    }
    private static function diretorio(): string {return WP_CONTENT_DIR.'/f3base-publico/'.get_current_blog_id();}
    private static function valido(): ?array {
        $m=get_option(self::OPTION,array());
        if(($m['versao']??'')!==F3BASE_PLUGIN_VERSAO||($m['origem_revisao']??null)!==self::revisao()||!preg_match('/^config-[a-f0-9]{64}\.js$/D',$m['arquivo']??'')){return null;}
        return is_file(self::diretorio().'/'.$m['arquivo'])?$m:null;
    }
    public static function publicar(): void {
        if(!self::$pendente||self::$gerando){return;}self::$pendente=false;self::$gerando=true;$lock=null;
        try{
            $lock=F3Base_Trava::adquirir('ativos-publicos',45);if(!$lock){return;}
            $revision=self::revisao();$data=F3Base_Modulo_Tracking::dados_estaticos();
            // No option snapshot is serialized here. dados_estaticos is the closed public contract.
            $mask=(!empty($data['gtm'])?1:0)|(!empty($data['ga4'])||!empty($data['ads']['id'])?2:0)|(!empty($data['meta']['pixelId'])&&$data['meta']['modo']!=='servidor'?4:0)|(!empty($data['linkedin']['partnerId'])?8:0)|(!empty($data['clarity']['projectId'])?16:0);
            $payload='window.f3baseTrackingDados=Object.assign({},'.wp_json_encode($data,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).',window.f3baseTrackingDados||{});' . "\n";
            $sha=hash('sha256',$payload);$file='config-'.$sha.'.js';$dir=self::diretorio();
            if(!wp_mkdir_p($dir)||is_link($dir)){throw new RuntimeException('diretorio_indisponivel');}
            if(!is_file($dir.'/'.$file)){
                $tmp=$dir.'/.'.wp_generate_uuid4().'.tmp';$f=@fopen($tmp,'x');if(!$f){throw new RuntimeException('arquivo_temporario_indisponivel');}
                $written=fwrite($f,$payload);fclose($f);
                if($written!==strlen($payload)||!@rename($tmp,$dir.'/'.$file)){@unlink($tmp);throw new RuntimeException('publicacao_atomica_falhou');}
                @chmod($dir.'/'.$file,0644);
            }
            if(hash_file('sha256',$dir.'/'.$file)!==$sha){throw new RuntimeException('arquivo_divergente');}
            // Concurrent option writes invalidate this revision; a stale publication is never used by PHP.
            $current=(array)get_option(F3Base_Perfil_Publico::OPTION,array());if(($current['revisao']??'')!==$revision){throw new RuntimeException('revisao_superada');}
            $m=array('versao'=>F3BASE_PLUGIN_VERSAO,'origem_revisao'=>$revision,'arquivo'=>$file,'sha256'=>$sha,'bytes'=>strlen($payload),'perfil'=>$mask,'gerado_em'=>time(),'codigo'=>'publicado','conversoes'=>array_intersect_key($data,array_flip(array('caminho','conteudo','gtm','ga4','ads','meta','linkedin'))));
            update_option(self::OPTION,$m,true);
        }catch(Throwable $e){update_option('f3base_ativos_publicos_falha',array('em'=>time(),'codigo'=>in_array($e->getMessage(),array('diretorio_indisponivel','arquivo_temporario_indisponivel','publicacao_atomica_falhou','arquivo_divergente','revisao_superada'),true)?$e->getMessage():'geracao_falhou'),false);}
        finally{self::$gerando=false;if($lock){F3Base_Trava::liberar($lock);}}
    }
    public static function conversoes(): ?array {$m=self::valido();return $m['conversoes']??null;}
    public static function configurar_tracking(): array {
        $m=self::valido();$deps=array();$source='assets/f3base-tracking.min.js';
        if($m){$candidate='assets/perfis/publico-'.$m['perfil'].'.min.js';if(isset(self::build()['arquivos'][$candidate])){
            $source=$candidate;wp_register_script('f3base-config-publica',content_url('/f3base-publico/'.get_current_blog_id().'/'.$m['arquivo']),array(),$m['sha256'],array('strategy'=>'defer','in_footer'=>false));$deps[]='f3base-config-publica';
        }else{$m=null;}}
        // An ordinary concurrent visit between file replacement and migration
        // may use the inline reserve, but must not freeze it in WP Super Cache.
        if(!$m&&!defined('DONOTCACHEPAGE')){define('DONOTCACHEPAGE',true);}
        return array('arquivo'=>$source,'dependencias'=>$deps,'agrupar'=>$m!==null&&!(defined('SCRIPT_DEBUG')&&SCRIPT_DEBUG),'dados'=>$m?F3Base_Modulo_Tracking::dados_dinamicos():F3Base_Modulo_Tracking::dados_de_medicao());
    }
    public static function bootstrap(): void {
        if(!wp_script_is('f3base-contexto','enqueued')&&!wp_script_is('f3base-tracking','enqueued')){return;}
        $script=self::build()['bootstrap']??'';if(!$script){return;}
        $cfg=wp_json_encode(array('contextoUrl'=>rest_url(F3BASE_REST_NAMESPACE.'/contexto-publico')),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        wp_print_inline_script_tag('window.f3baseInicialDados='.$cfg.';'.$script,array('id'=>'f3base-inicial','data-no-optimize'=>'1'));
    }
    /** Old immutable files remain usable for cached HTML for thirty days. */
    public static function podar(): void {
        $m=self::valido();if(!$m){return;}$dir=self::diretorio();$n=0;
        foreach(glob($dir.'/config-*.js')?:array() as $f){if(++$n>500){break;}if(!is_link($f)&&basename($f)!==$m['arquivo']&&preg_match('/^config-[a-f0-9]{64}\.js$/D',basename($f))&&filemtime($f)<time()-30*DAY_IN_SECONDS){@unlink($f);}}
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $m=get_option(self::OPTION,array());return array('ok'=>true,'vigente'=>self::valido()!==null,'revisao_atual'=>self::revisao(),'manifesto'=>$m,'ultima_falha'=>get_option('f3base_ativos_publicos_falha',null),'reserva'=>'Configuração atual inline e runtime completo; recuperação fora da visita.','amostragem'=>false);
    }
}
