# Orientação aos agentes — Core 1.65.0

Leia DOCUMENTACAO.md e RELEASE-1.65.0.md; contrato 8.30.0, base 1.64.0. Confirme versão/hash pelo índice e leia integralmente com paginação. A documentação não contém credenciais. Não inferir aceite de frota de fixtures.

1. Inspecione `f3base/ativos-publicos-ler`, `f3base/resumo-operacional-ler`, diário e estado da migração. Não reduzir coleta a 10%: a revisão vigente exige todas as visitas elegíveis.
2. Configure `f3base_cron_cli_segundos` (120 padrão, 30–600) pelo fluxo CAS existente. Use o comando real `wp cron event run --due-now`; definir WP_CLI em PHP não comprova a passagem nativa.
3. Ajuste destinos/relógio em `f3base_carregamento_destinos`. Clarity é imediato após elegibilidade. Antecipação por conversão precisa ser escolhida; não altera consentimento. Não declarar recebimento de fornecedor por script inserido.
4. Invalidar HTML em caches externos após atualização/política. O manifesto com revisão divergente usa reserva atual no PHP; não modificar manualmente os arquivos de hash. A recuperação roda no zelador.
5. Não apagar fila, quota, histórico, tabela, guarda, procedência ou reserva para fabricar sucesso. Não rodar teste comercial real no Site-Teste. Preservar recibos e informar aceites de campo pendentes.

Relatório, fontes e instalador têm identidades próprias. Só o instalador fechado deve ser instalado; fonte contém laboratórios reproduzíveis sem banco, dependências instaladas, segredos ou ZIPs aninhados.
