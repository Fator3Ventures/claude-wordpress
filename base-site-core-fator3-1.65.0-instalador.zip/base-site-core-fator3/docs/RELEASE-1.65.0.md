# Fator3 Site Core 1.65.0

Contrato administrativo 8.30.0; base imutável 1.64.0. Mantidos slug, basename, namespaces, opções, dados de contatos e contratos dos acompanhantes. Mínimos: WordPress 7.1.2 e PHP 8.3.6. A decisão vigente cobre todas as visitas elegíveis: não há sorteio de 10%, corte de campos ou replay deliberadamente tardio. Recursos desabilitados pelo operador continuam desabilitados.

## 361 — executor

`f3base_cron_cli_segundos`: inteiro de 30 a 600, padrão 120, em Medição e anúncios / Coleta do site. A próxima passagem CLI usa o valor persistido. A configuração aceita wp-admin e o canal administrativo com revisão/CAS. HTTP/MCP conserva 30 segundos e o limite de manutenção anterior. Nenhuma ampliação de cotas de fornecedor ou permissão de envio.

`wp cron event run --due-now` executa o zelador, confirma a migração pendente e despacha pós-atualização antes da manutenção. A drenagem não para em três rotinas no CLI; ordena prioridade e ocorrência mais antiga, revisita a fila enquanto há trabalho e orçamento. Comando com hook explícito ou `--exclude` não é ampliado para outras rotinas. Migração e pós-atualização são urgentes também no fallback web. Rotinas continuam protegidas por CLI recente; sem passagem por uma hora, o WP-Cron por visita assume conforme 1.64.

Reserva de tarefa usa o maior valor entre 180 segundos e o orçamento restante mais 60. Travas de banco/arquivo, ocorrência única, checkpoint e recuo de fornecedor permanecem. O diário registra orçamento, revisão e tempo consumido. O filtro HTTP aplica prazo somente dentro do trabalho Core; passagem esgotada não bloqueia HTTP posterior de outro pacote. Resumo operacional acrescenta contagem de vencidas, maior atraso e causas das intenções paradas, mantendo 4096 bytes e omissões explícitas. Não confundir passagem CLI com sucesso de fornecedor.

## Arquivos preparados e carregamento

O salvamento atualiza a projeção normalizada e prepara um arquivo `config-SHA256.js` em `wp-content/f3base-publico/<blog>/`. Campos vêm do contrato público fechado do tracking, não do catálogo completo. Tokens de visita, nonces, credenciais e parâmetros privados de teste ficam fora desse arquivo. Arquivo temporário, rename e hash antecedem a troca de manifesto; revisão superada não é publicada como vigente. O zelador recupera falhas; não se compila JS na hospedagem.

O pacote inclui 32 composições fechadas de consentimento, contexto, tempo ativo e carregadores dos fornecedores configurados. O navegador baixa a composição selecionada e a configuração pública; os handles WordPress anteriores e dados específicos da página são preservados. O cliente de contatos recebe só a projeção de destinos/conversões; catálogo de comportamento e tokens de resumo ficam no tracking, eliminando a cópia sem retirar eventos. O bootstrap pequeno no head observa chegada/visibilidade/rolagem e inicia a classificação durante o download. A composição usa `defer`. Falta de manifesto/arquivo ou versão divergente usa configuração atual inline e scripts completos. SCRIPT_DEBUG usa as fontes separadas. Essa reserva não promete contornar bloqueio de rede, CSP ou extensão do navegador.

Hashes de conteúdo evitam invalidar scripts próprios apenas pelo número da release. A visita estável não gera arquivos nem abre o catálogo completo. Arquivos públicos substituídos são conservados por 30 dias para HTML em cache; a limpeza é limitada e não remove o ativo. Após atualização/configuração, invalide o HTML público nos caches externos. A classificação rejeita envio a fornecedores quando a revisão do HTML diverge da atual. Não é prova universal de invalidação em CDN. Dados e consentimento continuam revalidados no servidor.

## Anúncios e replay

`f3base_carregamento_destinos` inclui GA4, Google Ads, GTM, Meta, LinkedIn e Clarity. Modos: herdar Google, imediato, atraso fixo, interação ou prazo, ocioso ou prazo; valores 0–30 segundos. Zero é imediato depois da elegibilidade. Referência do relógio: `load` preservado para instalações anteriores, `navegacao` ou `elegibilidade`. O prazo é de agendamento, não de rede concluída. `antecipar_conversao` é false por padrão; quando habilitado, conversão elegível pode antecipar a tag. Evento comum não antecipa.

Clarity habilitado começa assim que a política autoriza medição, independentemente de anúncios. A migração registra a complementação que muda seu modo para imediato; os demais destinos conservam escolhas. Negação, exclusão e marca de teste prevalecem sobre timer. Revogação cancela agendas. GA4/Ads compartilham um download gtag, mas o comando de cada destino espera seu próprio prazo. GTM é agendado como contêiner: o Core não altera as tags internas nem tags colocadas por terceiros.

## CTA, formulário e coleta

O `the_content` final recebe uma passagem de CTA; blocos aninhados não repetem o parser dentro dele. Fora desse fluxo, o fragmento raiz recebe o processamento. A memoização é limitada por quantidade/bytes, inclui configuração e superfície e não descarta HTML novo. Mantidas as 64 fixtures de equivalência. `desempenho-ler` registra primeira abertura indevida do catálogo com hook, chamador e caminho relativo, sem argumentos.

CSS de formulário é emitido uma vez junto do primeiro formulário renderizado. A análise reaproveita a lista de campos e invalida por mutação; lê valores atuais para preservar autofill e mudanças programáticas. Coletores de rolagem compartilham geometria apenas no mesmo evento e invalidam por mutação; eventos posteriores medem novamente. Análise começa cedo e agrupa envios regulares em três segundos; pagehide/ocultamento continuam caminhos urgentes. Recibos, IDs, sequência, renovação de token e retentativa permanecem. Ofertas mantém o contrato e a detecção dinâmica existentes; sua divisão adicional foi evitada para não perder abertura/fechamento antes da chegada de outro arquivo.

## Operação e limites de prova

Sem tabelas/colunas novas. Novos estados derivados: manifesto e última falha dos ativos, marcador de atualização urgente; nova preferência de orçamento CLI. `f3base/ativos-publicos-ler` exige manage_options. Rollback de código para 1.64 preserva dados, mas devolve limites/políticas anteriores. Não restaurar o banco só para reverter este incremento. Preserve a guarda de recuperação externa à pasta do plugin.

O relatório externo contém SHA-256 do ZIP efetivamente testado, testes executados e medições. O limite de 20 ms não instrumentados foi retirado do aceite; a métrica continua diagnóstica. Os limites próprios e consultas não medem experiência publicitária real. Aceite de 24 horas na frota, fator3.com.br, campanhas, navegadores internos e confirmação de replay/fornecedores requerem observação nesses ambientes. A instalação de teste não significa implantação da frota nem encerramento dos pedidos 354/360/361.
