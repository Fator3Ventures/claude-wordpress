/*! F3 Base 1.17 — contexto de atribuição e teste compartilhado. GPL-2.0-or-later. */
(function (w,d) {
 'use strict';
 var cfg=w.f3baseContextoDados||{},fields=cfg.campos||[],pol=cfg.atribuicao||{},test=cfg.testes||{},last=null,headerTest=cfg.testeServidor===true,renewals={},memory=null;
 var KEY='f3base_atribuicao_v1',pronto=false,contextPending=null,contextChecked=0,contextState='pendente',contextValidUntil=0;
 var diagnosticoId=uuid(),diagnosticoFila=['pendente'],diagnosticoVistos={},diagnosticoTimer=null;

 // O bootstrap do head mantém a observação inicial durante o download dos módulos defer.
 function diagnosticoFlush(){if(diagnosticoTimer){clearTimeout(diagnosticoTimer);diagnosticoTimer=null;}if(!cfg.diagnosticoUrl||!diagnosticoFila.length){return;}var states=diagnosticoFila.splice(0,7);fetch(cfg.diagnosticoUrl,{method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify({pagina:diagnosticoId,estados:states})}).catch(function(){});}
 function diagnosticoEstado(v){if(diagnosticoVistos[v]){return;}diagnosticoVistos[v]=true;diagnosticoFila.push(v);if(!diagnosticoTimer){diagnosticoTimer=setTimeout(diagnosticoFlush,1000);}}
 function diagnosticoResolver(){diagnosticoEstado(contextState==='falha'?'falha_classificacao':contextState==='excluida'?'excluida':marked()?'teste_destinos_restritos':(consent()||ads())?'liberada':'consentimento_negado');}
 w.addEventListener('pagehide',function(){if(pendente()){diagnosticoEstado('saida_sem_classificacao');}diagnosticoFlush();});
 function pendente(){return contextState==='pendente'||contextState==='falha';}
 function estadoContexto(){return contextState;}
 function classificar(){
  if(contextPending){return contextPending;}if(Date.now()>contextValidUntil){pronto=false;contextState='pendente';}
  if(cfg.audienciaExcluida===true&&cfg.paginaExcluida===true){contextState='excluida';pronto=false;diagnosticoEstado('excluida');return Promise.resolve(false);}
  if(!cfg.contextoUrl){contextState='falha';pronto=false;return Promise.resolve(false);}
  var abort=new AbortController(),timeout=setTimeout(function(){abort.abort();},5000),early=w.f3baseContextoAntecipado;w.f3baseContextoAntecipado=null;
  contextPending=(early&&early.url===cfg.contextoUrl&&Date.now()-early.inicio<10000?early.promessa:fetch(cfg.contextoUrl,{credentials:'same-origin',cache:'no-store',signal:abort.signal}).then(function(r){if(!r.ok){throw new Error('contexto_indisponivel');}return r.json();})).then(function(r){if(!r||r.ok!==true||typeof r.excluida!=='boolean'){throw new Error('contexto_invalido');}if(r.teste_origem==='cabecalho'&&r.contexto_teste===true){headerTest=true;last=true;}cfg.audienciaExcluida=cfg.paginaExcluida===true||r.excluida;cfg.publicacaoVigente=!cfg.revisaoPublica||cfg.revisaoPublica===r.revisao_publica;pronto=true;contextChecked=Date.now();contextValidUntil=contextChecked+300000;contextState=cfg.audienciaExcluida?'excluida':'permitida';return !cfg.audienciaExcluida;}).catch(function(){if(Date.now()>contextValidUntil){pronto=false;contextState='falha';}return pronto&&!cfg.audienciaExcluida;}).finally(function(){clearTimeout(timeout);contextPending=null;if(w.f3baseContexto){w.f3baseContexto.audienciaExcluida=cfg.audienciaExcluida===true;}d.dispatchEvent(new CustomEvent('f3base-contexto-pronto'));diagnosticoResolver();});return contextPending;
 }
 cfg.paginaExcluida=cfg.audienciaExcluida===true;
 w.addEventListener('pageshow',function(e){if(e.persisted){classificar();}});
 w.addEventListener('focus',function(){if(Date.now()-contextChecked>1000){classificar();}});
 d.addEventListener('visibilitychange',function(){if(d.visibilityState!=='hidden'){classificar();}});

 function cookie(){return test.habilitado!==false&&d.cookie.split(';').some(function(v){return v.trim()==='f3base_teste=1';});}
 // A marca pertence à navegação: sair do modo em outra aba não reclassifica os eventos já acumulados.
 function marked(){if(last===null){last=cookie();}return last||headerTest;}
 function consent(){return pronto&&!cfg.audienciaExcluida&&!!(w.f3baseConsentimento&&w.f3baseConsentimento.permiteCategoria('medicao'));}
 function read(){try{return JSON.parse(w.localStorage.getItem(KEY)||'null');}catch(e){return memory;}}
 function remove(){memory=null;navigation=null;originMemory=null;try{localStorage.removeItem(ORIGIN);localStorage.removeItem('f3base_audiencia_v1');audienceMemory=null;sessionStorage.removeItem(PREVIOUS);}catch(e){}try{w.localStorage.removeItem(KEY);w.localStorage.removeItem('f3base_atribuicao');}catch(e){}}
 function ads(){return pronto&&!cfg.audienciaExcluida&&!!(w.f3baseConsentimento&&w.f3baseConsentimento.permiteCategoria('publicidade'));}
 function restrict(v){if(!v||typeof v!=='object'){return v;}if(!ads()){['fbc','fbp','gclid','gbraid','wbraid','fbclid','li_fat_id','msclkid','oppref'].forEach(function(k){delete v[k];});}return v;}
 function meta(v){
  if(!ads()||marked()){return v;}var cookies={};d.cookie.split(';').forEach(function(x){var a=x.trim().split('=');try{cookies[a[0]]=decodeURIComponent(a.slice(1).join('='));}catch(e){}});
  if(v.fbclid&&!cookies._fbc){cookies._fbc='fb.1.'+Date.now()+'.'+v.fbclid;d.cookie='_fbc='+encodeURIComponent(cookies._fbc)+'; Max-Age=7776000; Path=/; SameSite=Lax'+(location.protocol==='https:'?'; Secure':'');}
  ['fbc','fbp'].forEach(function(k){var x=cookies['_'+k];if(/^fb\.[0-9]{1,3}\.[0-9]{10,13}\.[A-Za-z0-9_-]+$/.test(x||'')){v[k]=x;}});return v;
 }
 function destino(raw){
  if(!raw||raw.charAt(0)==='#'||/[\x00-\x20\x7f\\]/.test(raw)){return null;}
  var u;try{u=new URL(raw,location.href);}catch(e){return null;}if(u.username||u.password){return null;}
  if(u.protocol==='tel:'&&/^\+?[0-9().-]{5,30}$/.test(u.pathname)){return 'telefone';}
  if(u.protocol==='mailto:'&&/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(u.pathname)){return 'email';}
  if(u.protocol==='https:'&&!u.port&&((u.hostname==='wa.me'&&/^\/(?:[1-9][0-9]{6,14}|message\/[A-Za-z0-9_-]+)\/?$/.test(u.pathname))||(u.hostname==='api.whatsapp.com'&&u.pathname.replace(/\/$/,'')==='/send'&&/^[1-9][0-9]{6,14}$/.test(u.searchParams.get('phone')||'')))){return 'whatsapp';}
  return /^https?:$/.test(u.protocol)&&u.origin===location.origin?'interno':null;
 }
 function current(){var q=new URLSearchParams(w.location.search),v={};fields.forEach(function(k){var x=q.get(k);if(x){if(k==='oppref'){if(new TextEncoder().encode(x).length<=8192&&!/[\x00-\x1f\x7f]/.test(x)){v[k]=x;}else{v.oppref_estado='omitido_excede_8192_bytes';}}else{v[k]=x.slice(0,500);}}});try{var ref=new URL(d.referrer);if(ref.hostname!==location.hostname){v.referrer=ref.hostname;}}catch(e){}return restrict(v);}

 var navigation=null,originMemory=null,ORIGIN='f3base_sessao_origem_v2',PREVIOUS='f3base_navegacao_v1';
 function uuid(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join('');}
 function session(){return w.f3baseTracking&&w.f3baseTracking.sessao?w.f3baseTracking.sessao():'';}
 function signals(){return {webdriver:navigator.webdriver===true};}
 function page(){var u=new URL(location.href),id=u.searchParams.get('p')||u.searchParams.get('page_id');if(u.searchParams.has('s')){return '/@busca';}return /^[1-9][0-9]*$/.test(id||'')?'/@post-'+id:u.pathname;}
 function nav(id){id=id||session();if(!consent()||!id){return null;}
  if(!navigation||navigation.sessao!==id){var prev=null;try{prev=JSON.parse(sessionStorage.getItem(PREVIOUS)||'null');}catch(e){}var ref='';try{var refUrl=new URL(d.referrer);ref=refUrl.origin===location.origin?refUrl.pathname:'';}catch(e){}
   navigation={sessao:id,navegacao:uuid(),anterior:prev&&prev.sessao===id&&!w.opener&&ref===prev.caminho?prev.navegacao:'',sinais:signals()};
   try{sessionStorage.setItem(PREVIOUS,JSON.stringify({sessao:id,navegacao:navigation.navegacao,caminho:location.pathname}));}catch(e){}
  }return navigation;
 }
 function sessionOrigin(){var id=session();if(!consent()||!id){return current();}var v=originMemory;
  try{v=JSON.parse(localStorage.getItem(ORIGIN)||'null');}catch(e){}
  if(!v||v.id!==id){var start=w.f3baseTracking&&w.f3baseTracking.inicioSessao?w.f3baseTracking.inicioSessao():0;v={id:id,valor:Object.assign(current(),{entrada:page(),inicio_em:String(start||Math.floor(Date.now()/1000)),inicio_conhecido:start?'1':'0'})};try{localStorage.setItem(ORIGIN,JSON.stringify(v));}catch(e){}}
  originMemory=v;return restrict(Object.assign({},v.valor));
 }
 function attribution(){
  var value=current(),stamp=Math.floor(Date.now()/1000),isTest=marked(),stored=read();
  if(!consent()){if(!pendente()){remove();}value.modelo='sessao';return meta(value);}
  if(!stored||stored.expira<stamp||stored.teste!==isTest){stored=null;}
  if(stored){restrict(stored.primeiro);restrict(stored.ultimo);}
  var has=Object.keys(value).length>0;
  if(!stored){stored={primeiro:value,ultimo:value,primeiro_em:has?String(stamp):'',ultimo_em:has?String(stamp):'',expira:stamp+Math.max(1,Math.min(3650,Number(pol.ttl_dias)||30))*86400,teste:isTest};}
  else if(has){if(!Object.keys(stored.primeiro||{}).length){stored.primeiro=value;stored.primeiro_em=String(stamp);}if(JSON.stringify(stored.ultimo)!==JSON.stringify(value)){stored.ultimo=value;stored.ultimo_em=String(stamp);}}
  memory=stored;try{localStorage.setItem(KEY,JSON.stringify(stored));}catch(e){}
  var first=pol.modelo!=='last-touch',chosen=Object.assign({},first?stored.primeiro:stored.ultimo);chosen.primeiro_toque_em=stored.primeiro_em||'';chosen.ultimo_toque_em=stored.ultimo_em||'';chosen.modelo=first?'primeiro-toque':'ultimo-toque';chosen.primeiro_toque=Object.assign({},stored.primeiro);chosen.ultimo_toque=Object.assign({},stored.ultimo);chosen.sessao_origem=sessionOrigin();return meta(chosen);
 }
 var audienceMemory=null;
 function audience(){var id=session();if(!consent()||!id||cfg.audienciaExcluida){return null;}var all=audienceMemory||{},key=marked()?'teste':'normal';
  try{all=JSON.parse(localStorage.getItem('f3base_audiencia_v1')||'null')||all;}catch(e){}
  var old=all[key];if(!old||old.sessao!==id){
   var known=old&&Array.isArray(old.sessoes_contadas)?old.sessoes_contadas.slice(-63):old&&old.sessao?[old.sessao]:[];
   var count=old&&Number.isInteger(old.visitas)?old.visitas:old?1:0, minimum=old?old.visitas_minimo!==false:false;
   var remembered=old&&old.marcas_sessoes&&typeof old.marcas_sessoes==='object'?old.marcas_sessoes:{}, fresh=known.indexOf(id)<0;
   if(old&&old.sessao&&!remembered[old.sessao]){remembered[old.sessao]=old.retorno;}
   if(fresh){known.push(id);count++;}
   var marks={};known.forEach(function(k){if(remembered[k]){marks[k]=remembered[k];}});
   var returning=remembered[id]||(old&&/^[a-f0-9]{32}$/.test(old.sessao||'')?'recorrente':'novo');marks[id]=returning;
   all[key]={visitas:Math.max(1,Math.min(1000000,count)),visitas_minimo:minimum,visitas_desde:old&&old.visitas_desde||Math.floor(Date.now()/1000),sessoes_contadas:known,marcas_sessoes:marks,sessao:id,retorno:returning,largura:Math.max(0,Math.min(20000,Math.round(w.innerWidth||0))),max_touch_points:Math.max(0,Math.min(20,Math.round(navigator.maxTouchPoints||0)))};
  }
  if(!Number.isInteger(all[key].visitas)){all[key].visitas=all[key].retorno==='recorrente'?2:1;all[key].visitas_minimo=true;all[key].visitas_desde=Math.floor(Date.now()/1000);all[key].sessoes_contadas=[id];}
  audienceMemory=all;try{localStorage.setItem('f3base_audiencia_v1',JSON.stringify(all));}catch(e){}
  return Object.assign({},all[key]);
 }
 function policy(dest,wasTest){if(cfg.publicacaoVigente===false){return 'suprimir';}if(!pronto||cfg.audienciaExcluida){return 'suprimir';}var yes=typeof wasTest==='boolean'?wasTest:marked();if(!yes){return 'normal';}var p=(test.destinos||{})[dest];if(p!=='marcar'){return 'suprimir';}if(dest==='gtm'&&test.gtm_homologado===true){return 'marcar';}if(dest==='ga4'&&Array.isArray(test.ga4_ids)&&test.ga4_ids.length){return 'marcar';}return 'suprimir';}
 function valid(token){var n=Number(String(token||'').split('.')[0]);return Number.isFinite(n)&&n>Math.floor(Date.now()/1000)+30;}
 function token(c,force){
  if(!force&&valid(c.token)){return Promise.resolve(c.token);}var url=new URL(c.rotaToken,location.href);if(c.caminhoToken){url.searchParams.set('caminho',c.caminhoToken);}url.searchParams.set('_f3',String(Date.now()));var key=c.rotaToken+'|'+(c.caminhoToken||'');
  if(!renewals[key]){var control=new AbortController(),deadline=setTimeout(function(){control.abort();},10000);renewals[key]=fetch(url.href,{credentials:'same-origin',cache:'no-store',signal:control.signal}).then(function(r){if(!r.ok){throw new Error('token_indisponivel');}return r.json();}).then(function(r){if(!valid(r.token)){throw new Error('token_invalido');}return r.token;}).finally(function(){clearTimeout(deadline);delete renewals[key];});}
  return renewals[key].then(function(v){c.token=v;return v;});
 }
 d.addEventListener('f3base-consentimento',function(){if(!pendente()){diagnosticoResolver();}if(w.f3baseConsentimento&&!w.f3baseConsentimento.permiteCategoria('medicao')){remove();}else if(consent()){attribution();}});
 w.f3baseContexto={estado:estadoContexto,pendente:pendente,pronto:function(){return pronto&&!cfg.audienciaExcluida;},classificar:classificar,audiencia:audience,audienciaExcluida:cfg.audienciaExcluida===true,navegacao:nav,sinais:signals,origemSessao:sessionOrigin,destino:destino,teste:marked,atribuicao:attribution,politica:policy,token:token,tokenValido:valid,configTestes:test};
 marked();classificar().then(function(){if(consent()){attribution();}});
}(window,document));
