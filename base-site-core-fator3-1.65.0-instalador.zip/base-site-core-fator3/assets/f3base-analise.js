/*! F3 Base 1.16 — análise com confirmação por evento e retentativa limitada. GPL-2.0-or-later. */
(function () {
 'use strict';
 var entradaComAncora=location.hash.length>1;
 var cfg=window.f3baseAnaliseDados||{},nav='',current='',mode=false,queue=[],inflight=null,timer=0,pageSent=false,views=new WeakSet(),vitals={},retry=0,next=0,loaded=document.readyState==='complete',KEY='f3base_analise_fila';
 var ATRASO_INICIAL_MS=0,initialDeadline=0,timerDue=0,urgentPending=false;
 var renewal='';
 var formStates=new Map(),formFocus=new WeakMap(),formFields=new WeakMap();
 function fields(f){var entry=formFields.get(f);if(entry&&entry.observer&&entry.observer.takeRecords().length){entry.dirty=true;}if(!entry){entry={dirty:true,items:[],observer:null};if(window.MutationObserver){entry.observer=new MutationObserver(function(){entry.dirty=true;});entry.observer.observe(f,{childList:true,subtree:true,attributes:true,attributeFilter:["name","class","type"]});}formFields.set(f,entry);}if(entry.dirty||!entry.observer){entry.items=Array.from(f.querySelectorAll(".f3base-campo input[name],.f3base-campo textarea[name],.f3base-campo select[name]"));entry.dirty=false;}return entry.items;}
 // Only technical field names and counts enter analytics; values stay in the form.
 function technicalField(x){var m=(x.name||'').match(/^campos\[([a-z][a-z0-9_-]{0,79})\](?:\[\])?$/);return m&&x.closest('.f3base-campo')&&!/^(hidden|password|submit|button)$/i.test(x.type||'')?m[1]:'';}
 function filledField(x){return x.type==='file'?!!(x.files&&x.files.length):(/^(checkbox|radio)$/i.test(x.type)?x.checked:String(x.value||'').trim()!=='');}
 function formPosition(f){
  var filled=new Set();fields(f).forEach(function(x){var name=technicalField(x);if(!name){return;}if(filledField(x)){filled.add(name);}});
  var position={ultimo_campo:formFocus.get(f)||'',etapa:window.f3baseFormularios?window.f3baseFormularios.etapa(f):1,campos_preenchidos:filled.size};if(f.dataset.analiseProva){position.formulario_prova=f.dataset.analiseProva;}return position;
 }
 ['focusin','input','change'].forEach(function(name){document.addEventListener(name,function(e){if(!permit()){return;}context();var x=e.target,f=x.closest&&x.closest('[data-f3base-formulario]'),field=f&&technicalField(x);if(field){formFocus.set(f,field);var d=formDetail(f),key=d.formulario+'|'+d.correlacao,s=formStates.get(key);if(name!=='focusin'&&filledField(x)&&(!s||!s.iniciado)){emit('form_inicio',d);s=formStates.get(key);}if(s){s.posicao=formPosition(f);if(s.iniciado&&!s.aceito){s.fechado=false;}}}});});
 var counts={confirmados:0,recuperacoes:0,falhas:0,expirados:0,limite:0,rejeitados:0},dead=[];
 function permit(){return !!(window.f3baseTracking&&window.f3baseTracking.permiteTags()&&window.f3baseTracking.sessao());}
 function uuid(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join('');}
 function read(){try{return JSON.parse(sessionStorage.getItem(KEY)||'null');}catch(e){return null;}}
 function persist(){if(permit()){try{sessionStorage.setItem(KEY,JSON.stringify({eventos:queue,contagens:counts,rejeitados:dead}));}catch(e){}}}
 function clear(){renewal='';formStates=new Map();formFocus=new WeakMap();queue=[];nav='';current='';pageSent=false;views=new WeakSet();vitals={};clearTimeout(timer);timer=0;timerDue=0;urgentPending=false;retry=0;next=0;initialDeadline=loaded?Date.now()+ATRASO_INICIAL_MS:0;try{sessionStorage.removeItem(KEY);sessionStorage.removeItem('f3base_analise_origem');}catch(e){}}
 function context(){
  if(!permit()){return null;}var s=window.f3baseTracking.sessao(),test=!!(window.f3baseContexto&&window.f3baseContexto.teste());
  if(current!==s||mode!==test){formStates=new Map();formFocus=new WeakMap();current=s;mode=test;nav=window.f3baseContexto&&window.f3baseContexto.navegacao(s)?window.f3baseContexto.navegacao(s).navegacao:uuid();pageSent=false;views=new WeakSet();vitals={};}
  return {sessao:s,visitante:window.f3baseTracking.visitante(),navegacao:nav,navegacao_anterior:window.f3baseContexto&&window.f3baseContexto.navegacao(s)?window.f3baseContexto.navegacao(s).anterior:'',sinais:window.f3baseContexto?window.f3baseContexto.sinais():{},contexto_teste:test,largura:(window.f3baseContexto.audiencia()||{}).largura||0,max_touch_points:(window.f3baseContexto.audiencia()||{}).max_touch_points||0,retorno:(window.f3baseContexto.audiencia()||{}).retorno||'',dispositivo:matchMedia('(max-width: 767px)').matches?'movel':'desktop',atribuicao:window.f3baseContexto?window.f3baseContexto.atribuicao():{}};
 }
 function schedule(ms){
  if(!initialDeadline){initialDeadline=Date.now()+ATRASO_INICIAL_MS;}
  var due=Math.max(Date.now()+Math.max(ms||0,100),next,initialDeadline);
  if(timer&&timerDue<=due){return;}clearTimeout(timer);timerDue=due;
  timer=setTimeout(function(){timer=0;timerDue=0;flush(false);},Math.max(0,due-Date.now()));
 }
 function expire(){var cutoff=Math.floor(Date.now()/1000)-86400,n=queue.length;queue=queue.filter(function(e){return e.criado_em>=cutoff;});counts.expirados+=n-queue.length;}
 function reject(pack,code,id){var selected=id?pack.filter(function(e){return e.evento===id;}):pack.slice(0,1);selected.forEach(function(e){dead.push({evento:e.evento,sequencia:e.sequencia,codigo:code,em:Date.now()});queue=queue.filter(function(q){return q!==e;});counts.rejeitados++;});dead=dead.slice(-20);persist();}
 function flush(urgent,renewed){
  if(inflight&&urgent){urgentPending=true;}
  if(inflight||!queue.length||!permit()){return;}if(Date.now()<next){schedule(0);return;}if(!urgent&&Date.now()<initialDeadline){schedule(0);return;}expire();if(!queue.length){persist();return;}
  var pack=queue.filter(function(e){return e.contexto_teste===queue[0].contexto_teste;}).slice(0,20);
  while(pack.length>1&&new TextEncoder().encode(JSON.stringify(pack)).length>28000){pack.pop();}
  var control=new AbortController(),deadline=setTimeout(function(){control.abort();},20000);var run={pack:pack},again=false;inflight=run;
  var token=window.f3baseContexto?window.f3baseContexto.token(cfg,false):Promise.resolve(cfg.token);
  token.then(function(t){if(!permit()){throw new Error('consentimento_revogado');}return fetch(cfg.endpoint,{signal:control.signal,method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify({token:t,medicao:true,eventos:pack,renovacao:renewal})});}).then(function(r){
   var header=r.headers.get('Retry-After'),wait=Number(header);if(!Number.isFinite(wait)&&header){wait=(Date.parse(header)-Date.now())/1000;}
   return r.text().then(function(text){var body;try{body=JSON.parse(text);}catch(e){body={codigo:'resposta_nao_json'};}return {status:r.status,data:body,wait:Number.isFinite(wait)?Math.max(0,wait):0};});
  }).then(function(r){
   if(!permit()){clear();return;}var body=r.data||{},acks=Array.isArray(body.confirmados)?body.confirmados:[];
   var before=queue.length;queue=queue.filter(function(e){return !acks.some(function(a){return a.evento===e.evento&&a.sequencia===e.sequencia&&pack.some(function(p){return p===e;});});});counts.confirmados+=before-queue.length;persist();
   if(body.ok){renewal='';if(retry){counts.recuperacoes++;}retry=0;next=0;return;}
   if(r.status===403&&body.codigo==='token_invalido'&&!renewed&&window.f3baseContexto){renewal=typeof body.renovacao==='string'?body.renovacao:'';return window.f3baseContexto.token(cfg,true).then(function(){again=true;});}
   if(body.codigo==='medicao_nao_permitida'){clear();return;}
   if(r.status===400||r.status===409||r.status===413){reject(pack,body.codigo||'rejeitado',body.evento);retry=0;return;}
   var ex=new Error(body.codigo||'envio_nao_confirmado');ex.wait=r.wait;throw ex;
  }).catch(function(e){
   if(!permit()){clear();return;}counts.falhas++;retry=Math.min(8,retry+1);next=Date.now()+Math.max(Number(e.wait||0)*1000,Math.min(300000,2000*Math.pow(2,retry))*(0.8+Math.random()*0.4));persist();
  }).finally(function(){clearTimeout(deadline);if(inflight===run){inflight=null;}if(again){flush(urgent,true);}else if(queue.length&&permit()){if(urgentPending&&Date.now()>=next){urgentPending=false;flush(true);}else{urgentPending=false;schedule(1000);}}else{urgentPending=false;}});
 }
 function emit(type,detail){var c=context();if(!c||!c.visitante){return;}expire();if(queue.length>=100){counts.limite++;persist();return;}
  var pending=detail&&detail.complemento_pendente;if(detail){delete detail.complemento_pendente;}var e=Object.assign({evento:uuid(),tipo:type,caminho:cfg.caminho,criado_em:Math.floor(Date.now()/1000),formulario:'',formulario_revisao:'',correlacao:'',detalhe:'',valor:0,sequencia:1},c,detail||{});queue.push(e);persist();schedule(3000);if(type.indexOf('form_')===0){var key=e.formulario+'|'+e.correlacao,s=formStates.get(key)||{formulario:e.formulario,revisao:e.formulario_revisao,correlacao:e.correlacao,aberto:false,aceito:false,fechado:false};var names={form_vista:'aberto',form_dialogo:'aberto',form_inicio:'iniciado',form_erro:'recusado',form_aceito:'enviado',form_fechado:'fechado'},name=names[type];if(type==='form_inicio'){s.iniciado=true;s.fechado=false;}if(type==='form_dialogo'&&!s.aceito){s.fechado=false;}if(type==='form_aceito'){s.aceito=!pending;}if(['form_complemento','form_pulada','form_conversa'].indexOf(type)>=0){s.aceito=true;}if(type==='form_fechado'){s.fechado=true;}if(name&&!(name==='aberto'&&s.aberto)){document.dispatchEvent(new CustomEvent('f3base-formulario-metrica',{detail:{evento:'f3base_form_'+name,formulario:e.formulario,codigo:e.detalhe,teste:e.contexto_teste}}));}if(name==='aberto'){s.aberto=true;}formStates.set(key,s);}
 }
 function formDetail(f,d){if(window.f3baseFormularioInstancia){window.f3baseFormularioInstancia(f);}var offer=window.f3baseOfertas&&window.f3baseOfertas.contexto(f);return Object.assign(offer?{oferta:offer}:{},{formulario:f.dataset.f3baseFormulario,formulario_revisao:f.dataset.revisao||'',correlacao:(f.elements.submissao&&f.elements.submissao.value)||'',detalhe:(d&&d.codigo)||'',complemento_pendente:!!(d&&d.etapas_restantes&&d.etapas_restantes.length)});}
 document.addEventListener('f3base-contexto-pronto',function(){boot();});
 function boot(){if(!permit()){clear();return;}context();if(!pageSent){pageSent=true;emit('pagina',{detalhe:entradaComAncora?'ancora':''});}
  document.querySelectorAll('[data-f3base-formulario]').forEach(function(f){if(views.has(f)){return;}if(window.IntersectionObserver){var observer=new IntersectionObserver(function(entries){if(entries.some(function(e){return e.isIntersecting;})){if(permit()&&!views.has(f)){views.add(f);emit('form_vista',formDetail(f));}observer.disconnect();}},{threshold:0.1});observer.observe(f);}else{views.add(f);emit('form_vista',formDetail(f));}});
  schedule(100);
 }
 var old=read();if(old&&Array.isArray(old.eventos)){queue=old.eventos.filter(function(e){return e&&typeof e.evento==='string';}).slice(-100).map(function(e){if(typeof e.contexto_teste!=='boolean'){e.contexto_teste=false;}return e;});expire();}
 [['dialogo-aberto','form_dialogo'],['complemento-aceito','form_complemento'],['etapa-pulada','form_pulada'],['conversa-solicitada','form_conversa']].forEach(function(pair){document.addEventListener('f3base-formulario-'+pair[0],function(e){var f=e.target.closest('[data-f3base-formulario]');if(f){emit(pair[1],formDetail(f));}});});
 ['inicio','tentativa','erro','aceito'].forEach(function(name){document.addEventListener('f3base-formulario-'+name,function(e){var f=e.target.closest('[data-f3base-formulario]');if(f){var d=formDetail(f,e.detail),s=formStates.get(d.formulario+'|'+d.correlacao);if(name==='inicio'&&s&&s.iniciado){return;}if(name!=='aceito'||!(e.detail&&e.detail.duplicado)){emit('form_'+name,d);}}});});
 document.addEventListener('f3base-tracking-pronto',boot);document.addEventListener('f3base-consentimento',boot);document.addEventListener('f3base-teste-alterado',function(){current='';boot();});
 window.addEventListener('load',function(){loaded=true;if(!initialDeadline){initialDeadline=Date.now()+ATRASO_INICIAL_MS;}schedule(0);});window.addEventListener('online',function(){next=0;flush(false);});window.addEventListener('pageshow',function(e){if(e.persisted){boot();}});
 function fecharForm(f,motivo,soIniciados){formStates.forEach(function(s){if((!soIniciados||s.iniciado)&&(s.aberto||s.iniciado)&&!s.aceito&&!s.fechado&&(!f||(f.dataset.f3baseFormulario===s.formulario&&((f.elements.submissao&&f.elements.submissao.value)||'')===s.correlacao))){var el=f; if(!el){document.querySelectorAll('[data-f3base-formulario]').forEach(function(x){if(x.dataset.f3baseFormulario===s.formulario&&((x.elements.submissao&&x.elements.submissao.value)||'')===s.correlacao){el=x;}});}emit('form_fechado',Object.assign({formulario:s.formulario,formulario_revisao:s.revisao,correlacao:s.correlacao,detalhe:motivo},el?formPosition(el):(s.posicao||{ultimo_campo:'',etapa:1,campos_preenchidos:0})));}});}
 document.addEventListener('f3base-formulario-fechado',function(e){var f=e.target.closest('[data-f3base-formulario]');if(f){fecharForm(f,'adaptador_fechado');}});
 document.addEventListener('close',function(e){if(e.target.tagName==='DIALOG'){e.target.querySelectorAll('[data-f3base-formulario]').forEach(function(f){fecharForm(f,'dialogo_fechado');});}},true);
 document.addEventListener('f3base-oferta-fechada',function(e){var f=e.target.matches('[data-f3base-formulario]')?e.target:e.target.querySelector('[data-f3base-formulario]');if(f){fecharForm(f,'oferta_fechada');}});
 window.addEventListener('pagehide',function(){fecharForm(null,'saida_sem_aceite_observado',true);flush(true);});document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden'){flush(true);}else{boot();}});
 document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a||a.closest('[data-f3base-formulario]')){return;}try{var u=new URL(a.href,location.href);if(u.origin!==location.origin||!/^https?:$/.test(u.protocol)||u.pathname===location.pathname||new TextEncoder().encode(u.pathname).length>190||/\/f3base\/(arquivo|download)/i.test(u.pathname)){return;}emit('clique_interno',{clique_rotulo:Array.from((a.getAttribute('aria-label')||a.textContent||'Link interno').replace(/\s+/g,' ').trim()).slice(0,160).join(''),clique_destino:u.pathname});flush(true);}catch(x){}},{capture:true});
 document.addEventListener('f3base:contato-capturado',function(){flush(true);});document.addEventListener('f3base-formulario-tentativa',function(){flush(true);});
 window.f3baseAnalise={oferta:function(type,details){if(['oferta_exibida','oferta_aberta','oferta_fechada'].indexOf(type)>=0){emit(type,details);}},contexto:context,atribuicao:function(){return window.f3baseContexto?window.f3baseContexto.atribuicao():{};},diagnostico:function(){return {pendentes:queue.length,em_voo:!!inflight,proxima_tentativa:next,prazo_inicial:initialDeadline,atraso_inicial_ms:ATRASO_INICIAL_MS,contagens:Object.assign({},counts),rejeitados:dead.slice()};},vital:function(name,value,seq){var c=context();if(!c){return;}var id=vitals[name]||(vitals[name]=uuid());emit('vital',{evento:id,detalhe:name,valor:value,sequencia:seq});if(document.visibilityState==='hidden'){Promise.resolve().then(function(){flush(true);});}}};
 if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot);}else{boot();}
}());
