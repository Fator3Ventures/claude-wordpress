/*! F3 Base — bootstrap de observação e classificação antecipada. GPL-2.0-or-later. */
(function(w,d){'use strict';if(w.f3baseObservacaoInicial){return;}
 // Observação efêmera desde o primeiro script. Nenhum identificador, storage ou envio.
 var cedo={inicio:Date.now(),visivel:0,maximo:0,rolagens:[],gesto:0,salto:location.hash?Date.now()+2000:0},desde=d.visibilityState==='hidden'?0:Date.now(),encerrado=false,toque=false,inercia=0;
 function gestoInicial(e){if(!e.isTrusted){return;}if(e.type==='keydown'&&(['ArrowDown','ArrowUp','PageDown','PageUp','Home','End',' '].indexOf(e.key)<0||e.target.closest('input,textarea,select,[contenteditable]'))){return;}cedo.gesto=Date.now();inercia=Date.now()+400;toque=e.type==='touchstart'||(e.type==='pointerdown'&&e.pointerType==='touch');}
 function rolagemInicial(){if(encerrado){return;}var now=Date.now(),el=d.documentElement,b=d.body,util=Math.max(el.scrollHeight,(b&&b.scrollHeight)||0)-(w.innerHeight||el.clientHeight);if(util<=0&&d.readyState!=='complete'){return;}var pct=util>0?Math.max(0,Math.min(100,(w.pageYOffset||el.scrollTop||0)/util*100)):100;if(toque||now<inercia){inercia=now+250;cedo.gesto=now;}cedo.maximo=Math.max(cedo.maximo,pct);var item={percentual:pct,quando:now,gesto:toque||now-cedo.gesto<=2000,salto:now<cedo.salto};if(cedo.rolagens.length<200){cedo.rolagens.push(item);}else{cedo.rolagens[199]=item;}}
 function visibilidadeInicial(){if(desde){cedo.visivel+=Math.max(0,Date.now()-desde);}desde=d.visibilityState==='hidden'?0:Date.now();}
 function removerInicial(){encerrado=true;w.removeEventListener('scroll',rolagemInicial);w.removeEventListener('load',rolagemInicial);d.removeEventListener('visibilitychange',visibilidadeInicial);['wheel','touchstart','touchmove','pointerdown','keydown'].forEach(function(n){d.removeEventListener(n,gestoInicial,true);});}
 function consumirInicial(){if(encerrado){return null;}visibilidadeInicial();removerInicial();var r=cedo;cedo={rolagens:[]};return r;}
 function descartarInicial(){removerInicial();cedo={rolagens:[]};desde=0;}
 ['wheel','touchstart','touchmove','pointerdown','keydown'].forEach(function(n){d.addEventListener(n,gestoInicial,{passive:true,capture:true});});
 ['touchend','touchcancel','pointerup','pointercancel'].forEach(function(n){d.addEventListener(n,function(){toque=false;},{passive:true,capture:true});});
 d.addEventListener('click',function(e){if(encerrado){return;}var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;if(a&&a.hash&&a.origin===location.origin&&a.pathname===location.pathname&&a.search===location.search){cedo.salto=Date.now()+2000;}},true);
 w.addEventListener('hashchange',function(){if(!encerrado){cedo.salto=Date.now()+2000;}});
 w.addEventListener('scroll',rolagemInicial,{passive:true});w.addEventListener('load',rolagemInicial);d.addEventListener('visibilitychange',visibilidadeInicial);
 d.addEventListener('f3base-contexto-pronto',function(){var c=w.f3baseContexto;if(c&&c.pronto()&&(!w.f3baseConsentimento||!w.f3baseConsentimento.permiteCategoria('medicao'))){descartarInicial();}});
 d.addEventListener('f3base-consentimento',function(){if(w.f3baseConsentimento&&!w.f3baseConsentimento.permiteCategoria('medicao')){descartarInicial();}});
 w.addEventListener('pagehide',function(){if(!w.f3baseContexto||!w.f3baseContexto.pronto()){descartarInicial();}});
 w.f3baseObservacaoInicial={consumir:consumirInicial,descartar:descartarInicial};

 var cfg=w.f3baseInicialDados||{};
 if(cfg.contextoUrl&&w.fetch&&w.AbortController){var abort=new AbortController(),timer=setTimeout(function(){abort.abort();},5000);
  w.f3baseContextoAntecipado={url:cfg.contextoUrl,inicio:Date.now(),promessa:fetch(cfg.contextoUrl,{credentials:'same-origin',cache:'no-store',signal:abort.signal}).then(function(r){if(!r.ok){throw new Error('contexto_indisponivel');}return r.json();}).catch(function(){return null;}).finally(function(){clearTimeout(timer);})};}
})(window,document);
