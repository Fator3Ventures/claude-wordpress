<?php
/** Gerado por build/cron-map.php. */
if(!defined('ABSPATH')){exit;}
return array (
  'f3base_acessos_continuar' => 
  array (
    'tarefa' => 'acessos',
    'classe' => 'rotina',
    'gancho' => 'f3base_acessos_continuar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_acessos_somar' => 
  array (
    'tarefa' => 'acessos',
    'classe' => 'rotina',
    'gancho' => 'f3base_acessos_somar',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_anuncios_consultar' => 
  array (
    'tarefa' => 'anuncios',
    'classe' => 'rotina',
    'gancho' => 'f3base_anuncios_consultar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_avisos_processar' => 
  array (
    'tarefa' => 'avisos_contatos',
    'classe' => 'urgente',
    'gancho' => 'f3base_avisos_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_cache_podar' => 
  array (
    'tarefa' => 'retencao',
    'classe' => 'rotina',
    'gancho' => 'f3base_cache_podar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_cache_reaquecer' => 
  array (
    'tarefa' => 'reaquecimento',
    'classe' => 'rotina',
    'gancho' => 'f3base_cache_reaquecer',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_cache_verificar' => 
  array (
    'tarefa' => 'cache',
    'classe' => 'rotina',
    'gancho' => 'f3base_cache_verificar',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_cadencia_relatorio' => 
  array (
    'tarefa' => 'cadencia',
    'classe' => 'rotina',
    'gancho' => 'f3base_cadencia_relatorio',
    'recorrencia' => 'configuravel:f3base_cadencia',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_caminho_lead_processar' => 
  array (
    'tarefa' => 'caminho_lead',
    'classe' => 'rotina',
    'gancho' => 'f3base_caminho_lead_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_capi_recuperar' => 
  array (
    'tarefa' => 'capi',
    'classe' => 'urgente',
    'gancho' => 'f3base_capi_recuperar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_captacao_monitorar' => 
  array (
    'tarefa' => 'anuncios',
    'classe' => 'rotina',
    'gancho' => 'f3base_captacao_monitorar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_clarity_coletar' => 
  array (
    'tarefa' => 'clarity',
    'classe' => 'rotina',
    'gancho' => 'f3base_clarity_coletar',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_clarity_retomar' => 
  array (
    'tarefa' => 'clarity',
    'classe' => 'rotina',
    'gancho' => 'f3base_clarity_retomar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_complementos_processar' => 
  array (
    'tarefa' => 'complementos',
    'classe' => 'urgente',
    'gancho' => 'f3base_complementos_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_conversoes_servidor' => 
  array (
    'tarefa' => 'conversoes_servidor',
    'classe' => 'urgente',
    'gancho' => 'f3base_conversoes_servidor',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_editorial_atualizar' => 
  array (
    'tarefa' => 'editorial',
    'classe' => 'rotina',
    'gancho' => 'f3base_editorial_atualizar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_email_historico_conferir' => 
  array (
    'tarefa' => 'email_historico',
    'classe' => 'rotina',
    'gancho' => 'f3base_email_historico_conferir',
    'recorrencia' => 'f3base_email_historico_5m',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_email_novo_lead_processar' => 
  array (
    'tarefa' => 'email_novo_lead',
    'classe' => 'urgente',
    'gancho' => 'f3base_email_novo_lead_processar',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_email_site_consultar' => 
  array (
    'tarefa' => 'email_site',
    'classe' => 'rotina',
    'gancho' => 'f3base_email_site_consultar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_email_site_saude' => 
  array (
    'tarefa' => 'email_site',
    'classe' => 'rotina',
    'gancho' => 'f3base_email_site_saude',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_esquema_reparar' => 
  array (
    'tarefa' => 'estrutura',
    'classe' => 'rotina',
    'gancho' => 'f3base_esquema_reparar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_ga4_coletar' => 
  array (
    'tarefa' => 'ga4',
    'classe' => 'rotina',
    'gancho' => 'f3base_ga4_coletar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_ga4_continuar' => 
  array (
    'tarefa' => 'ga4',
    'classe' => 'rotina',
    'gancho' => 'f3base_ga4_continuar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_google_cliques' => 
  array (
    'tarefa' => 'google_cliques',
    'classe' => 'rotina',
    'gancho' => 'f3base_google_cliques',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_gsc_coletar' => 
  array (
    'tarefa' => 'gsc',
    'classe' => 'rotina',
    'gancho' => 'f3base_gsc_coletar',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_gsc_consultas_coletar' => 
  array (
    'tarefa' => 'gsc_consultas',
    'classe' => 'rotina',
    'gancho' => 'f3base_gsc_consultas_coletar',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_gsc_consultas_continuar' => 
  array (
    'tarefa' => 'gsc_consultas',
    'classe' => 'rotina',
    'gancho' => 'f3base_gsc_consultas_continuar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_gsc_continuar' => 
  array (
    'tarefa' => 'gsc',
    'classe' => 'rotina',
    'gancho' => 'f3base_gsc_continuar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_gtm_verificar' => 
  array (
    'tarefa' => 'gtm',
    'classe' => 'rotina',
    'gancho' => 'f3base_gtm_verificar',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_integracoes_reverificar' => 
  array (
    'tarefa' => 'integracoes',
    'classe' => 'rotina',
    'gancho' => 'f3base_integracoes_reverificar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_integracoes_verificar' => 
  array (
    'tarefa' => 'integracoes',
    'classe' => 'rotina',
    'gancho' => 'f3base_integracoes_verificar',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_intencoes_podar' => 
  array (
    'tarefa' => 'retencao',
    'classe' => 'rotina',
    'gancho' => 'f3base_intencoes_podar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_leads_avisos' => 
  array (
    'tarefa' => 'avisos_contatos',
    'classe' => 'urgente',
    'gancho' => 'f3base_leads_avisos',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_leads_resumo' => 
  array (
    'tarefa' => 'manutencao',
    'classe' => 'rotina',
    'gancho' => 'f3base_leads_resumo',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_linkedin_assinaturas' => 
  array (
    'tarefa' => 'anuncios',
    'classe' => 'rotina',
    'gancho' => 'f3base_linkedin_assinaturas',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_linkedin_consultar' => 
  array (
    'tarefa' => 'anuncios',
    'classe' => 'rotina',
    'gancho' => 'f3base_linkedin_consultar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_linkedin_notificacoes' => 
  array (
    'tarefa' => 'anuncios',
    'classe' => 'urgente',
    'gancho' => 'f3base_linkedin_notificacoes',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_llms_converter_lote' => 
  array (
    'tarefa' => 'llms',
    'classe' => 'rotina',
    'gancho' => 'f3base_llms_converter_lote',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_llms_regenerar' => 
  array (
    'tarefa' => 'llms',
    'classe' => 'rotina',
    'gancho' => 'f3base_llms_regenerar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_marcas_inspecionar' => 
  array (
    'tarefa' => 'marcas',
    'classe' => 'rotina',
    'gancho' => 'f3base_marcas_inspecionar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_meta_capi_enviar' => 
  array (
    'tarefa' => 'capi',
    'classe' => 'urgente',
    'gancho' => 'f3base_meta_capi_enviar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_meta_monitorar' => 
  array (
    'tarefa' => 'meta_monitoramento',
    'classe' => 'rotina',
    'gancho' => 'f3base_meta_monitorar',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_migrar_estrutura' => 
  array (
    'tarefa' => 'migracao',
    'classe' => 'urgente',
    'gancho' => 'f3base_migrar_estrutura',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_navegacao_rever' => 
  array (
    'tarefa' => 'navegacao',
    'classe' => 'rotina',
    'gancho' => 'f3base_navegacao_rever',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_navegacao_verificar_cron' => 
  array (
    'tarefa' => 'navegacao',
    'classe' => 'rotina',
    'gancho' => 'f3base_navegacao_verificar_cron',
    'recorrencia' => 'twicedaily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_ofertas_verificar' => 
  array (
    'tarefa' => 'ofertas',
    'classe' => 'rotina',
    'gancho' => 'f3base_ofertas_verificar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_operacao_retomar' => 
  array (
    'tarefa' => 'retomadas',
    'classe' => 'rotina',
    'gancho' => 'f3base_operacao_retomar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_operacao_urgente' => 
  array (
    'tarefa' => 'retomadas_urgentes',
    'classe' => 'urgente',
    'gancho' => 'f3base_operacao_urgente',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_pipedrive_alertas' => 
  array (
    'tarefa' => 'avisos_crm',
    'classe' => 'urgente',
    'gancho' => 'f3base_pipedrive_alertas',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_pipedrive_processar' => 
  array (
    'tarefa' => 'pipedrive',
    'classe' => 'urgente',
    'gancho' => 'f3base_pipedrive_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_pos_atualizacao_verificar' => 
  array (
    'tarefa' => 'pos_atualizacao',
    'classe' => 'urgente',
    'gancho' => 'f3base_pos_atualizacao_verificar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_primeira_resposta_processar' => 
  array (
    'tarefa' => 'primeira_resposta',
    'classe' => 'rotina',
    'gancho' => 'f3base_primeira_resposta_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_qualidade_destinos_processar' => 
  array (
    'tarefa' => 'qualidade_destinos',
    'classe' => 'rotina',
    'gancho' => 'f3base_qualidade_destinos_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_qualidade_processar' => 
  array (
    'tarefa' => 'qualidade',
    'classe' => 'rotina',
    'gancho' => 'f3base_qualidade_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_redes_robos_atualizar' => 
  array (
    'tarefa' => 'redes_robos',
    'classe' => 'rotina',
    'gancho' => 'f3base_redes_robos_atualizar',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_retencao_limpeza' => 
  array (
    'tarefa' => 'retencao',
    'classe' => 'rotina',
    'gancho' => 'f3base_retencao_limpeza',
    'recorrencia' => 'daily',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_robots_verificar' => 
  array (
    'tarefa' => 'robots',
    'classe' => 'rotina',
    'gancho' => 'f3base_robots_verificar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_schema_verificar' => 
  array (
    'tarefa' => 'schema',
    'classe' => 'rotina',
    'gancho' => 'f3base_schema_verificar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_servidor_reverificar' => 
  array (
    'tarefa' => 'servidor',
    'classe' => 'rotina',
    'gancho' => 'f3base_servidor_reverificar',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_sessoes_indexar' => 
  array (
    'tarefa' => 'historico_visitas',
    'classe' => 'rotina',
    'gancho' => 'f3base_sessoes_indexar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_whatsapp_conversa_coletar' => 
  array (
    'tarefa' => 'whatsapp_conversa',
    'classe' => 'rotina',
    'gancho' => 'f3base_whatsapp_conversa_coletar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_wp_mail_processar' => 
  array (
    'tarefa' => 'wp_mail',
    'classe' => 'urgente',
    'gancho' => 'f3base_wp_mail_processar',
    'recorrencia' => 'evento_unico',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
  'f3base_zelador_tick' => 
  array (
    'tarefa' => 'zelador',
    'classe' => 'rotina',
    'gancho' => 'f3base_zelador_tick',
    'recorrencia' => 'hourly',
    'condicao' => 'F3Base_Zelador::conferir',
    'declaracao_condicoes' => 'zelador-condicoes.php',
  ),
);
