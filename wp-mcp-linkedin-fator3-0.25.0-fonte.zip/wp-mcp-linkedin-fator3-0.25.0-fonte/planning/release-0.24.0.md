# Pedido 26 · 14/11/2026
Partir do LinkedIn 0.23.0. Corrigir a tabela em Conexões, auditar 12 destinos e o acesso aos conteúdos ocultos, preservar navegação e medir no WordPress em Chromium. Entregar imagens 360/768/1440 e reproduzir a 750. Conjunto: Core 1.87.3, MCP 0.45.0, Google 0.35.0, Meta 0.26.0, Pipedrive 0.10.0. Sem proposta de alteração nos contratos dos acompanhantes.
