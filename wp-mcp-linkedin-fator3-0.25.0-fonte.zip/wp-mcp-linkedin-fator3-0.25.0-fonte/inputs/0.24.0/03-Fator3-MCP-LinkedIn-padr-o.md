# Padrão de entrega — Fator3 MCP LinkedIn (wp-mcp-linkedin-fator3)

Para o agente responsável pelo Fator3 MCP LinkedIn. Vale a partir da próxima versão; a regra comum aos pacotes está na aba "Regra comum", e o essencial vai repetido aqui. O Fator3 MCP LinkedIn e o Fator3 MCP Meta saem com arquivos e relatórios separados, também quando são entregues juntos.

## Arquivos

| tipo | nome | conteúdo |
| --- | --- | --- |
| instalador | `wp-mcp-linkedin-fator3-<versão>-instalador.zip` | pasta interna `wp-mcp-linkedin-fator3/`, arquivo principal `wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php` |
| fonte | `wp-mcp-linkedin-fator3-<versão>-fonte.zip` | pasta interna `wp-mcp-linkedin-fator3-<versão>-fonte/`: código, build, suíte de testes, evidências, manifesto e uma cópia do relatório |
| relatório | `wp-mcp-linkedin-fator3-<versão>-relatorio.md` | Markdown, em português, só deste pacote |

Versão `X.Y.Z`, sem sufixo; homologação e sha256 só dentro do relatório.

## Cabeçalho e tela

| campo | valor |
| --- | --- |
| Plugin Name | Fator3 MCP LinkedIn |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | LinkedIn Pages, Ads, Lead Sync e Conversions API: gestão de anúncios e publicações, relatórios, renovação de acesso, coletas agendadas, exportação em CSV e JSON e notificações verificadas, pela Abilities API e pelo Fator3 MCP. A captação de leads para os contatos do site é do Fator3 Site Core. Configuração em Ferramentas → Fator3 MCP LinkedIn. |
| Requires at least, Requires PHP | os validados pela versão (0.19.0: 7.1.4 e 8.3, 64 bits) |
| Author | Fator3 |
| Author URI | `https://www.fator3.com.br` |
| License | GPL-2.0-or-later |
| Text Domain | `wp-mcp-linkedin-fator3` |
| Update URI | `https://fator3.com.br/plugins/wp-mcp-linkedin-fator3` |
| tela | Ferramentas → Fator3 MCP LinkedIn, com `manage_options` |

Se o escopo mudar, a descrição muda junto, no mesmo formato.

**Capacidade.** A tela e as operações que leem dado da conta conectada pedem `manage_options`.

## O que não muda

Slug e pasta `wp-mcp-linkedin-fator3`, arquivo principal, Text Domain, Update URI, a option `f3_linkedin`, a tabela `f3_linkedin_records`, os nomes das rotas `linkedin/*` já publicadas (99 operações na 0.19.0) e o contrato de `linkedin/save-connection` (`expected_revision`, ativos `pages`, `ads` e `leads`).

## Relatório

Nesta ordem:

1. Título `Entrega — Fator3 MCP LinkedIn <versão>`.
2. De onde a versão entra (WordPress limpo e as versões aceitas direto) e as versões do Fator3 MCP e do Site Core com que foi validada.
3. Escopo: o que o pacote lê e grava e o que fica no Site Core (cliente LinkedIn interno, `f3base_anuncios_linkedin`).
4. O que mudou, citando cada "Pedidos MCP LinkedIn N" atendido, com a evidência.
5. Prova da troca: `linkedin/status` e `system/health` do canal com o estado esperado.
6. Conexão e Lead Sync: o que o dono cola na tela (só senha e segredo) e o que o agente preenche, escolhe e confirma nela, escopos e aprovações do aplicativo no LinkedIn, webhook e assinatura; nenhum segredo.
7. O que não foi homologado (conta real, desafio e notificação do webhook, Lead Sync).
8. Identidade: nome, tamanho e sha256 do instalador e da fonte.

## Conformidade da 0.19.0 (09/11/2026)

Lida no `main` (commit `e3580d3`): instalador `wp-mcp-linkedin-fator3-0.19.0-instalador.zip` (397.354 bytes, sha256 `613cb47c…`) com a pasta `wp-mcp-linkedin-fator3/` e o arquivo principal; fonte `wp-mcp-linkedin-fator3-0.19.0-fonte.zip` (3.056.323 bytes, sha256 `25f3458b…`) com a pasta `wp-mcp-linkedin-fator3-0.19.0-fonte/`; os dois sha256 no relatório, só deste pacote, iguais aos dos arquivos; nenhum ZIP dentro de outro. Título `Entrega — Fator3 MCP LinkedIn 0.19.0`; cabeçalho, descrição e tela como acima. Nenhum pedido aberto sobre a entrega.
