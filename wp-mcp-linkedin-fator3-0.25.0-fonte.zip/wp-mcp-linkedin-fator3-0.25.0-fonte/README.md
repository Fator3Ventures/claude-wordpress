# Fonte — Fator3 MCP LinkedIn 0.25.0

Esta versão atualiza diretamente a 0.24.0. O pedido 423(e) do Core 1.91.0 é tratado nos hooks do LinkedIn. A árvore editável é `build/`; a cópia em `plugin/wp-mcp-linkedin-fator3/` corresponde ao instalador. A documentação de operação está em `docs/WORKER.md` dentro do runtime.

## Reproduzir o build

Use Python 3, PHP de 64 bits ≥ 8.3 e as extensões de WordPress. A variável F3_SOCIAL_PHP identifica o binário ou wrapper PHP. Na raiz do fonte:

```sh
F3_SOCIAL_PHP=/caminho/php python3 build/build.py
python3 tools/verify-installer025.py build/dist/wp-mcp-linkedin-fator3-0.25.0-instalador.zip plugin/wp-mcp-linkedin-fator3
```

O build também compila o índice de documentação, verifica as referências e gera os schemas do registro de operações. O manifesto interno lista o SHA-256 dos 97 arquivos de runtime, excluindo a si próprio.

## Reproduzir as provas

Use **banco descartável**, com permissão para criar e descartar databases, WordPress ≥ 7.1.4, cliente MySQL no PATH e extensões necessárias aos acompanhantes. Copie `tools/lab-release0250.example.json`, indique seus próprios caminhos e confira os hashes das dependências. O hash de um executável, wrapper, ou ZIP de distribuição do WordPress criado localmente depende desses bytes; registre sua origem e versão efetivas. O ZIP do sensor exigido é WP Activity Log 5.7.0 com a pasta wp-security-audit-log. Opções e logs do banco não integram a entrega. O laboratório bloqueia HTTP ao fornecedor e intercepta e-mail.

```sh
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li25-isolado --order linkedin-only --tests suite.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li25-integrado --order linkedin-integrated --tests suite.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li25-migracao --order linkedin-integrated --origin upgrade --tests migration025.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li25-docs --order linkedin-integrated --tests mcp-docs080.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li25-docs-up --order linkedin-integrated --origin upgrade --tests mcp-docs080.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li25-cron --order linkedin-integrated --activity-log --tests cron025.php
```

Para reproduzir o defeito da base em outra instalação limpa, use a última linha com um diretório novo e `--candidate /dependencias/wp-mcp-linkedin-fator3-0.24.0-instalador.zip`. Esta é uma reprodução de referência, não um procedimento de retorno à versão anterior. A prova usa o arquivo nativo wp-cron.php em dois processos novos, o sensor integral sem alteração e um gravador controlado da agenda. O cenário separado de retornos injeta WP_Error com horário/argumentos/ausência/recusa para exercitar os limites de confirmação. Os recibos de remoção e de processamento são capturados separadamente. A fixture cron025-child.php só é copiada para um WordPress descartável durante essa prova.

Consulte `planning/0.25.0/`, `inputs/0.25.0/` e `evidence/release0250/` para o escopo e os resultados desta rodada. Evidências de outras versões e imagens da 0.24.0 são históricas. Para fechar um fonte novo, prepare primeiro o relatório interno e execute `python3 tools/package-source.py --output-dir /caminho/fora-do-fonte` na árvore nomeada com a versão.
