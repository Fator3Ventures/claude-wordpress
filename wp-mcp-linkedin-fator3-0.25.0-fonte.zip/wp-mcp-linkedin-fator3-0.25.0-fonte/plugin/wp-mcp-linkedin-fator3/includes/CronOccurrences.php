<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Reconcile our two single, argument-free events without changing the site's cron store. */
final class CronOccurrences {
    private const WORKER = 'f3_linkedin_worker';
    private const DISCOVERY = 'f3_linkedin_lead_discovery';
    private static array $removing = [];

    public static function schedule(string $hook, int $when): bool {
        // Callers may reuse a previously scheduled tick; only a fresh attempt gets a receipt.
        if (wp_next_scheduled($hook) !== false) return true;
        $result = wp_schedule_single_event($when, $hook, [], true);
        $raw = is_wp_error($result) ? sanitize_key($result->get_error_code()) : ($result === true ? 'ok' : 'schedule_unconfirmed');
        $next = wp_next_scheduled($hook) ?: null;
        $exact = (bool) wp_get_scheduled_event($hook, [], $when);
        $confirmed = $exact && in_array($raw, ['ok', 'could_not_set', 'duplicate_event'], true);
        // A concurrent worker tick is deliberately reusable. Lead discovery requires the exact attempt.
        $reused = !$confirmed && $hook === self::WORKER && $raw === 'duplicate_event' && $next !== null;
        $ok = $confirmed || $reused;
        $receipt = [
            'at'=>time(), 'success'=>$ok, 'next'=>$next, 'code'=>$ok ? 'ok' : ($raw === 'ok' ? 'schedule_unconfirmed' : $raw),
            'requested_at'=>$when, 'api_code'=>$raw, 'confirmation'=>$confirmed ? 'exact' : ($reused ? 'existing_worker' : 'unconfirmed'),
        ];
        update_option($hook.'_schedule_attempt', $receipt, false);
        if (!$ok) update_option($hook.'_schedule_failure', $receipt, false);
        return $ok;
    }

    /** wp-cron removes the event before invoking the callback. Reconcile only a proven disappearance. */
    public static function observeRemoval(): void {
        add_filter('pre_unschedule_event', [self::class, 'beforeRemoval'], PHP_INT_MIN, 4);
        add_filter('pre_unschedule_event', [self::class, 'rememberDecision'], PHP_INT_MAX - 1, 4);
        add_filter('pre_unschedule_event', [self::class, 'afterRemoval'], PHP_INT_MAX, 4);
    }
    private static function key($hook, $when, $args): ?string {
        return ($args === [] && ($hook === self::WORKER || $hook === self::DISCOVERY)) ? $hook.':'.$when : null;
    }
    public static function beforeRemoval($pre, $when, $hook, $args) {
        $key = self::key($hook, $when, $args);
        if ($key !== null) self::$removing[$key][] = ['existed'=>(bool)wp_get_scheduled_event($hook, [], $when), 'decision'=>$pre];
        return $pre;
    }
    public static function rememberDecision($pre, $when, $hook, $args) {
        $key = self::key($hook, $when, $args);
        if ($key !== null && isset(self::$removing[$key]) && $pre !== null) {
            $i = array_key_last(self::$removing[$key]);
            self::$removing[$key][$i]['decision'] = $pre;
        }
        return $pre;
    }
    public static function afterRemoval($pre, $when, $hook, $args) {
        $key = self::key($hook, $when, $args);
        if ($key === null || !isset(self::$removing[$key])) return $pre;
        $observed = array_pop(self::$removing[$key]);
        if (!self::$removing[$key]) unset(self::$removing[$key]);
        if ($pre !== null) return $pre;
        if ($observed['decision'] === false || is_wp_error($observed['decision'])) return $observed['decision'];
        if ($observed['existed'] && !wp_get_scheduled_event($hook, [], $when)) {
            update_option($hook.'_reconciled_removal', ['at'=>time(), 'scheduled_at'=>(int)$when, 'confirmation'=>'exact_absence'], false);
            return true;
        }
        return null;
    }
}
