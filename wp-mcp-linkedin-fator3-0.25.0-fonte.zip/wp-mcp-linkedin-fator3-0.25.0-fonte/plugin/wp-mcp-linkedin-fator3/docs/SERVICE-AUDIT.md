# Auditoria de serviço — 0.25.0

## Estado e domínio

O domínio oferece o descritor de auditoria de serviço ao iniciar. Não declarar integração central homologada por existir código, hook, descritor ou leitor. Sem consumidor compatível, `central_audit=service_principal_unsupported` continua correto.

O Core continua usando `site-conversion-delivery/1.0.0` e `sendBound`; não precisa emitir auditoria nem assumir usuário. Todo envio SDK é serviço, inclusive quando o processo tem usuário WordPress incidental. Escrita administrativa pela ability mantém o contrato humano `mutation-audit/1.0.0`; nenhum usuário/concessão OAuth é convertido em principal de serviço.

## Fronteiras públicas do domínio

`f3_linkedin_service_audit_descriptor(): array` é PHP local sem efeitos. Retorna exatamente:

```json
{"contract":"mutation-service-audit/1.0.0","provider":"wp-mcp-linkedin-fator3","event_contract":"linkedin-service-mutation/1.0.0","event_hook":"f3_linkedin_service_mutation_recorded","reader":"linkedin/get-service-write-operation","introspector":"f3_linkedin_introspect_service_grant"}
```

`f3_linkedin_introspect_service_grant(array $identity): array` é somente PHP local, utilizável com usuário zero. Não há ability/rota de introspecção ou emissão. O introspector não concede acesso, não envia, não renova token e não expõe conta, regra, conexão, usuário ou segredo. Entrada fechada de cinco campos: `provider` com o valor do descritor, `consumer_id=site-core-conversions|site-core-quality`, `principal_ref`, `grant_revision` e `operation_id`, os três últimos com exatamente 64 caracteres hexadecimais minúsculos. Campo extra ou identidade divergente é recusado.

Saída válida: `contract`, `valid=true`, `identity`, `event` (projeção técnica especificada abaixo) e `event_sha256`. Inválida: apenas `contract`, `valid=false` e `code` simbólico. O canal deve exigir validade e igualdade integral do evento recebido com a projeção; nunca fabricar snapshot ou aceitar apenas o booleano. Vincular também `operation_id` evita aceitar um diário humano ou de outra concessão como serviço.

`linkedin/get-service-write-operation` foi a única ability nova na 0.7.0 (80 naquela versão; 99 na 0.19.0), de leitura, com a mesma identidade de cinco campos. REST administrativa: `POST /wp-json/f3-linkedin/v1/get-service-write-operation`, autenticação administrativa normal. Não aceita callbacks, caminhos, credenciais ou payload. Requer `manage_options`, principal proprietário vigente da concessão (incluindo sua conexão/perfil de origem, quando existente), ativo selecionado e política MCP permitindo o leitor. O canal deve exigir adicionalmente permissão no leitor central. Outro administrador ou outra concessão MCP não herda acesso por possuir a referência.

A saída usa o envelope normal do LinkedIn; `data` contém `contract`, `principal_type=service`, identidade, operação/revisão técnica do diário, estado, digest do evento, `before`, `after`, `result`, `central_audit` e `redacted=true`. `before` é `{"status":"nao_enviado"}`; `after` é recibo técnico ou null para envio sem resultado conclusivo. Recibo contém somente status, código simbólico, HTTP, non_delivery_proven e retry_after quando houver. Não contém evento original, identificador de contato, valor da conversão, hash do e-mail, li_fat_id, texto livre ou corpo remoto. Leitura e introspecção não fazem HTTP nem gravam auditoria/configuração. O leitor antigo delega a esta proteção nos novos diários de serviço; diários legados mantêm seu gate original.

## Identidade, concessão e revogação

O principal é HMAC com domínio próprio, site, consumidor e destino congelado; a revisão opaca também incorpora revisão persistida da concessão e seu contexto. Não derivar `user_id` dessas referências nem usá-las como credencial de envio. O registro central deve incluir seu identificador de site ao formar a chave estável site/provider/principal_ref/operation_id.

A identidade é gravada em `conversion_event.service_identity` antes do POST. O gate de preflight compara novamente a revisão da concessão antes do efeito. Reconfirmação de concessão incrementa sua revisão e invalida leitura das referências anteriores, mesmo que preserve destination_ref. Revogação/reconcessão também troca a autoridade. Não atualizar silenciosamente referências de um recibo antigo para a nova concessão.

Introspecção exige: diário de serviço existente com identidade exata; concessão ativa, consumidor e revisão vigentes; administrador concedente ainda autorizado no WordPress; a execução do consumidor e a introspecção de serviço independem da sessão MCP de gravação. A leitura humana de um recibo privado continua restrita ao contexto de origem; conexão ativa, revisão/seleção preservadas; regra da conta selecionada, ativa e com fonte API; prova local de introspecção do token com `active`, vínculo à credencial atual, `rw_conversions` e `r_ads`, sem expiração conhecida já vencida. Mudança de token sem prova correspondente bloqueia detalhe até nova verificação. Não há consulta ao LinkedIn na leitura: revogação remota só se torna conhecida quando o plugin observa uma nova introspecção ou alteração local. O envio continua verificando o fornecedor antes do POST.

Revogação, mudança de ativo, perda de permissão ou revisão divergente bloqueiam detalhe e validação de novos eventos, sem apagar diário nem referência central histórica. O canal mantém seus metadados pela política central de retenção. Diários da 0.6.0 sem `service_identity` não recebem identidade retroativamente; a introspecção responde `service_operation_unbound`. Não há backfill ou reemissão automática após instalar um novo canal.

## Evento local

Após persistir o resultado, o adaptador chama `do_action('f3_linkedin_service_mutation_recorded', $event)`. Um envio incerto também produz estado técnico incerto quando o recibo local foi persistido. Se a autoridade deixou de ser válida entre despacho e registro, a emissão falha fechada, conservando o diário do envio. Evento tem exatamente dez campos:

| Campo | Contrato |
|---|---|
| contract | linkedin-service-mutation/1.0.0 |
| provider | wp-mcp-linkedin-fator3 |
| operation_id | HMAC de operação, 64 hex |
| operation | send-conversion-event ou send-conversion-events |
| state | dispatching, confirmed, uncertain ou rejected |
| before_sha256 / after_sha256 | SHA-256 canônico dos snapshots técnicos; after pode ser null |
| consumer_id | site-core-conversions |
| principal_ref / grant_revision | referências opacas de 64 hex |

Nenhum snapshot, payload ou dado pessoal segue no evento. Um lote tem referência por evento, com correlação pelo diário próprio. Replay confirmado/incerto não emite outro evento e não repete POST. Nova tentativa após recusa comprovada pode atualizar o estado da mesma referência; continua sujeita à autorização e às decisões da fila Core. Falha no Registro não converte entrega confirmada em recusa nem autoriza reenvio comercial.

## Handshake proposto ao MCP

Depois de registrar/decorar o leitor, o central chama em seu bootstrap PHP:

```php
do_action('f3_mcp_register_mutation_service_audit',
    'mutation-service-audit/1.0.0', $registrar, $consultar);
```

Os callables são funções locais do central, nunca dados de rede. `$registrar($descriptor)` valida provedor instalado/reconhecido, contrato, hook e funções fixos, reader somente de leitura e origem; retorna `contract`, `provider`, `registered=true` somente após admissão. O LinkedIn guarda o callback de consulta apenas na memória da requisição após essa confirmação. Fazer o handshake a cada bootstrap, sem depender de ordem de ativação; o central pode inicializá-lo de forma tardia antes de consumir seu contrato.

`$consultar($provider, $identity)` é leitura local sem efeitos. Identidade vazia solicita apenas `contract`, `provider`, `registered`. Para identidade completa, acrescenta `recorded` e `event_sha256` do evento efetivamente persistido. O canal observa o hook, valida a projeção pelo introspector e persiste a referência antes de responder `recorded=true`. A comparação inclui o hash exato; admissão do provedor ou simples chamada do hook não prova persistência.

Digest: ordenar recursivamente chaves de objetos, preservar ordem de listas, codificar JSON UTF-8 sem espaços, com Unicode e barras não escapados, e SHA-256 dos bytes. Valores deste evento são strings ASCII e null, sem floats. O introspector já fornece o digest e o evento esperado. O central deve conferir ambos e não aceitar campos adicionais.

| central_audit | Significado |
|---|---|
| service_principal_unsupported | o handshake de serviço não foi concluído |
| service_provider_registered | diagnóstico de provedor admitido, sem prova de uma operação |
| recorded | recibo central confirmou o digest exato desta operação |
| service_record_unconfirmed | provedor admitido, persistência/digest não confirmados |
| service_provider_not_registered | consulta central falhou ou não confirmou admissão vigente |
| service_authority_unavailable | concessão/prova atual não permite validar a operação |
| service_event_failed | consumidor do hook lançou erro; entrega comercial conservada |
| service_operation_unbound | diário anterior sem vínculo de serviço verificável |
| service_journal_unavailable | não foi possível persistir recibo local; conservada a incerteza |

`linkedin/capabilities` e `linkedin/status` incluem `service_audit` com descritor, `domain_implemented`, `central_registered` e diagnóstico. Não interpretar `domain_implemented=true` como suporte do MCP. O canal 0.27.0 continua oferecendo somente auditoria humana; o aceite conjunto aguarda sua próxima implementação.
