# Notas da versão 0.24.0

Pedidos MCP LinkedIn 26. A navegação das 12 telas quebra a linha para manter todos os destinos visíveis. Abaixo de 782 px, percorra as colunas da tabela de conexões dentro do próprio bloco; Estado e Token permanecem inteiros. Estados têm rótulo e cor. Use busca e paginação nas listas para localizar itens. ADMINISTRATION.md descreve o uso e o alcance de cada busca.

Atualização direta da 0.23.0, sem migração de banco ou troca de autorização. Mesmos endereços do painel, capacidade administrativa, SDK e operações públicas.
