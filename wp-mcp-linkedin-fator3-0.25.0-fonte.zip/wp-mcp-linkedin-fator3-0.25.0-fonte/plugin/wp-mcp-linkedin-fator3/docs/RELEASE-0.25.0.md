# Fator3 MCP LinkedIn 0.25.0 — agenda do worker e da descoberta

Atualização direta da 0.24.0; WordPress ≥ 7.1.4 e PHP ≥ 8.3 de 64 bits. Entrega do pedido 423(e) do Site Core 1.91.0. O catálogo de operações, as permissões e o schema de dados permanecem iguais. Sem nova credencial ou etapa de migração. MCP 0.46.0 provê o transporte.

O plugin confere a identidade de cada ocorrência própria (hook, argumentos vazios e timestamp). O retorno de uma gravação ou remoção confirma apenas a agenda. O recibo do callback informa se houve tentativa de processar itens e quantos erros ocorreram. Veja WORKER.md. Nenhum teste de cron autoriza reenviar conversões, assinaturas ou leads.
