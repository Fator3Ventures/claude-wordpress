"""Capture a local wp-admin, using the installed plugin and a synthetic account. No external HTTP."""
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
import os,json,hashlib
from playwright.sync_api import sync_playwright,expect
origin=os.environ['F3_UI_URL']; assert urlsplit(origin).hostname=='127.0.0.1'
base=os.environ.get('F3_UI_BASELINE')=='1'; dest=Path(os.environ['F3_LAB_ROOT'])/'evidence'/'visual024';dest.mkdir(exist_ok=True)
tabs=dict(connections='Lista de conexões',assets='Ativos',leads='Formulários',conversions='Conversões de aquisição',stages='Etapas comerciais',reports='Relatórios',jobs='Coletas',history='Histórico',management='Anúncios e publicações',diagnostics='Diagnóstico',retention='Retenção',help='Ajuda')
url=origin+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3&tab='
checks=[]; shots=[]; errors=[]
def test(name,v,detail=None):checks.append(dict(name=name,passed=bool(v),detail=detail))
def metrics(p):
 return p.evaluate("""()=>{const root=document.querySelector('.f3-social'),vis=e=>e.getClientRects().length>0, nav=[...root.querySelectorAll('nav')].filter(vis),box=root.querySelector('#f3-connection-list'), th=[...box.querySelectorAll('th')], lines=e=>{let r=document.createRange();r.selectNodeContents(e);return new Set([...r.getClientRects()].map(x=>Math.round(x.top))).size},bounds=e=>{let z=e.getBoundingClientRect();return z.left>=-1&&z.right<=innerWidth+1};return {width:innerWidth,page:document.documentElement.scrollWidth,navAll:nav.every(n=>n.scrollWidth<=n.clientWidth+1&&[...n.children].every(a=>bounds(a)&&a.getBoundingClientRect().bottom<=n.getBoundingClientRect().bottom+1)),navRows:new Set([...nav[0].children].map(a=>Math.round(a.getBoundingClientRect().top))).size,scroller:box.scrollWidth,box:box.clientWidth,headLines:Object.fromEntries(th.map(t=>[t.textContent,lines(t)])),visible:root.querySelectorAll('.f3-section:not([hidden])').length,allGroups:nav[0].children.length,header:root.querySelector('header p')?.textContent||'',badControls:[...root.querySelectorAll('button,select,input,textarea,summary')].filter(e=>vis(e)&&!e.closest('.f3-scroll')&&!bounds(e)).map(e=>e.id||e.name||e.tagName),active:root.querySelector('.f3-section:not([hidden])')?.id}}""")
def picture(p,width,tab):
 f=f'{width}-{tab}.png';p.screenshot(path=dest/f,full_page=True,animations='disabled',caret='hide');shots.append({'name':tab,'width':width,'file':f,'sha256':hashlib.sha256((dest/f).read_bytes()).hexdigest()})
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ['F3_CHROME_HEADLESS_SHELL'],chromium_sandbox=os.environ.get('F3_LAB_CHROME_NO_SANDBOX')!='1',args=['--disable-dev-shm-usage']);version=b.version
 for width in ([750,360] if base else [360,768,1440,750]):
  ctx=b.new_context(viewport={'width':width,'height':900 if width>=750 else 800},locale='pt-BR',device_scale_factor=1,service_workers='block')
  try:
   ctx.route('**/*',lambda r:r.continue_() if urlsplit(r.request.url).netloc==urlsplit(origin).netloc else r.abort())
   ctx.request.get(origin+'/wp-login.php');resp=ctx.request.post(origin+'/wp-login.php',form={'log':'social_admin','pwd':os.environ['F3_UI_PASSWORD'],'testcookie':'1','redirect_to':url+'connections'},max_redirects=0);assert resp.status in (302,303)
   p=ctx.new_page();p.on('pageerror',lambda x:errors.append(str(x)[:220]));p.set_default_timeout(9000)
   for tab in (['connections'] if base or width==750 else tabs):
    p.goto(url+tab,wait_until='networkidle');expect(p.locator('#f3-'+tab)).to_be_visible()
    if tab=='connections':expect(p.locator('#f3-connection-list tbody tr')).to_have_count(20)
    if tab=='diagnostics':p.locator('#f3-status').click();expect(p.locator('#f3-diagnostic-result h3')).to_be_visible()
    if tab=='help':p.locator('#f3-help-read').click();expect(p.locator('#f3-help-content h2').first).to_be_visible()
    p.evaluate('window.scrollTo(0,0)')
    m=metrics(p);key=f'{width}/{tab}: '
    test(key+'destino e cabeçalho',m['active']=='f3-'+tab and m['visible']==1 and bool(m['header']) and m['allGroups']==6)
    test(key+'página e controles sem transbordamento',m['page']<=width+1 and not m['badControls'],m)
    test(key+'todos os destinos visíveis',m['navAll'] and (width!=360 or m['navRows']>1),m['navRows'])
    if tab=='connections':
     test(key+'cabeçalhos Estado e Token inteiros',all(m['headLines'].get(k)==1 for k in ['Estado','Token']),m['headLines'])
     if width<782:
      test(key+'rolagem própria funciona',p.locator('#f3-connection-list').evaluate('e=>{e.scrollLeft=90;const x=e.scrollLeft;e.scrollLeft=0;return x>0&&document.documentElement.scrollLeft===0}'),[m['box'],m['scroller']])
     if not base:test(key+'estados têm selos',p.locator('#f3-connection-list tbody tr').first.locator('.f3-status-pill').count()==2)
    picture(p,width,tab)
    if not base and tab=='connections' and width<782:
     box=p.locator('#f3-connection-list');box.focus();p.keyboard.press('ArrowRight');p.wait_for_function("document.querySelector('#f3-connection-list').scrollLeft>0")
     test(key+'rolagem com teclado isolada',p.evaluate('document.documentElement.scrollLeft===0'));box.evaluate('e=>e.scrollLeft=e.scrollWidth')
     picture(p,width,'connections-colunas');box.evaluate('e=>e.scrollLeft=0')
   if not base and width!=750:
    p.goto(url+'connections',wait_until='networkidle');p.locator('#f3-connections-more').click();expect(p.locator('#f3-connection-count')).to_contain_text('21–40');p.locator('#f3-connection-search').fill('z018-55');expect(p.locator('#f3-connection-list tbody tr')).to_have_count(1);p.locator('#f3-connection-list button').click();expect(p.locator('#f3-connection [name=connection_id]')).to_have_value('z018-55');test(f'{width}: busca, edição e página seguinte',True)
    p.evaluate('scrollTo(0,0)');picture(p,width,'editor')
    # Local pagination of returned rows: exercise the actual renderer using a controlled REST reply.
    p.goto(url+'reports',wait_until='networkidle')
    if not p.locator('#f3-context').evaluate('e=>e.open'):p.locator('#f3-context summary').click()
    p.locator('#f3-context [name=channel]').select_option('pages');expect(p.locator('#f3-context [name=account_id]')).to_be_enabled()
    calls=[]
    def dataset(route):
     calls.append(1);route.fulfill(json={'success':True,'code':'ok','data':{'rows':[{'name':'Organização '+str(i),'state':'ok'} for i in range(1,42)],'coverage':{'complete':True},'next_cursor':None}})
    def report_route(route):
     u=urlsplit(route.request.url);path=parse_qs(u.query).get('rest_route',[u.path])[0]
     if path.rstrip('/').endswith('/f3-linkedin/v1/query'):dataset(route)
     else:route.fallback()
    p.route('**/*',report_route)
    p.locator('#f3-query button.button-primary').click();local=p.locator('#f3-result .f3-list-tools');expect(local.locator('[role=status]')).to_contain_text('1–20 de 41')
    local.get_by_role('button',name='Próxima').click();expect(local.locator('[role=status]')).to_contain_text('21–40');local.get_by_role('button',name='Anterior').click()
    local.locator('input').fill('ORGANIZACAO 41');expect(p.locator('#f3-result tbody tr:visible')).to_have_count(1);local.locator('input').press('Enter');test(f'{width}: busca acentuada, paginação e consulta única',len(calls)==1 and '41' in p.locator('#f3-result tbody tr:visible').inner_text())
    f=p.locator('#f3-query .f3-list-tools input').last;f.fill('Nome');f.press('Enter');test(f'{width}: Enter na busca de campos não envia o formulário',len(calls)==1)

    p.goto(url+'assets#f3-stage-conversions',wait_until='networkidle');expect(p.locator('#f3-stages')).to_be_visible();p.goto(url+'assets#f3-conversions',wait_until='networkidle');expect(p.locator('#f3-conversions')).to_be_visible();test(f'{width}: dois endereços antigos preservados',True)
    p.goto(url+'help',wait_until='networkidle');details=p.locator('#f3-help details').filter(has=p.locator('.f3-field-reference')).last;details.locator('summary').first.click()
    ui=p.locator('#f3-help .f3-list-tools').last;ui.locator('input').fill('OAuth');expect(ui.locator('[role=status]')).to_contain_text(' de ');test(f'{width}: busca na referência de campos',p.locator('.f3-field-reference tbody tr:visible').count()>0)
  finally:ctx.close()
 b.close()
test('Nenhum erro JavaScript não tratado',not errors,errors)
result=dict(browser=version,base=base,tabs=tabs,checks=checks,shots=shots,total=len(checks),failed=sum(not c['passed'] for c in checks))
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('browser','total','failed')}));raise SystemExit(0 if base or not result['failed'] else 1)
