<?php
// Loaded as a temporary mu-plugin, and only by the child wp-cron.php process.
if(!defined('ABSPATH') || getenv('F3_RUN_NATIVE_CRON025')!=='1')return;
$hooks=['f3_linkedin_worker','f3_linkedin_lead_discovery'];
add_filter('pre_get_ready_cron_jobs',static function()use($hooks){
 $ready=[];foreach(_get_cron_array() as $ts=>$list){if($ts<=time()&&($own=array_intersect_key($list,array_flip($hooks))))$ready[$ts]=$own;}return $ready;
});
add_filter('pre_unschedule_event',static function($pre,$ts,$hook,$args,$errors)use($hooks){
 if(!in_array($hook,$hooks,true)||$args!==[]||$pre!==null)return $pre;
 // Controlled writer at normal priority; the unmodified Activity Log cron sensor runs after this.
 $c=_get_cron_array();$k=md5(serialize($args));if(!isset($c[$ts][$hook][$k]))return $pre;
 unset($c[$ts][$hook][$k]);if(!$c[$ts][$hook])unset($c[$ts][$hook]);if(!$c[$ts])unset($c[$ts]);return _set_cron_array($c,$errors);
},15,5);
add_action('cron_unschedule_event_error',static function($err,$hook)use($hooks){
 if(in_array($hook,$hooks,true))update_option('qa025_error_'.$hook,$err->get_error_code(),false);
},10,2);
foreach($hooks as $hook)add_action($hook,static function()use($hook){
 update_option('qa025_calls_'.$hook,1+(int)get_option('qa025_calls_'.$hook,0),false);
},999);
