<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require_once __DIR__.'/lab-helpers.php';wp_set_current_user(1);
if(!class_exists('WpMcpUltimate\\Server\\Abilities\\ExecuteAbilityAbility'))exit(0);
use Fator3\McpFiles as C;
$grant='qa080docs_'.bin2hex(random_bytes(8));$http=0;$reads=[];$checks=[];
C\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>1,'client_id'=>'qa080docs','profile'=>'maintenance','status'=>'active']);C\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$grant,'client_id'=>'qa080docs','profile'=>'maintenance']);
add_filter('pre_http_request',function()use(&$http){$http++;return new WP_Error('blocked','No provider access');},1);
function doc080(array $input): array {$r=\WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute(['ability_name'=>'linkedin/documentation','parameters'=>$input]);if(empty($r['success'])||empty($r['data']['success']))throw new RuntimeException('MCP document failed: '.wp_json_encode($r));return $r['data']['data'];}
try{
 $index=doc080(['document'=>'index']);foreach($index['documents'] as $item){$offset=0;$text='';$pages=0;do{$p=doc080(['document'=>$item['document'],'offset'=>$offset,'limit_bytes'=>16384,'expected_revision'=>$item['sha256']]);$text.=$p['content'];$offset=$p['next_offset'];$pages++;}while($offset!==null);
  $ok=hash('sha256',$text)===$item['sha256']&&strlen($text)===$item['bytes']&&$text===file_get_contents(\Fator3\LinkedIn\Config::DIR.'docs/'.$item['document']);$checks[]=['name'=>'native MCP complete '.$item['document'],'passed'=>$ok];$reads[]=$item+['pages'=>$pages];
 }
 $readme=doc080(['document'=>'README.md','limit_bytes'=>65536]);$version=\Fator3\LinkedIn\Config::VERSION;
 $checks[]=['name'=>'Installed README identifies exactly the current release','passed'=>preg_match('/A release corrente é ([0-9]+\.[0-9]+\.[0-9]+)/u',$readme['content'],$m)&&$m[1]===$version];
 foreach($index['documents'] as $item)if(str_ends_with($item['document'],'.md')&&$item['document']!=='CHANGELOG.md'&&!str_starts_with($item['document'],'RELEASE-')){$header=strtok(file_get_contents(\Fator3\LinkedIn\Config::DIR.'docs/'.$item['document']),"\n");$matches=preg_match('/0\.[0-9]+\.[0-9]+/',$header,$v);$checks[]=['name'=>'Current manual version '.$item['document'],'passed'=>$matches===1&&$v[0]===$version];}
 $checks[]=['name'=>'MCP documentation no provider access','passed'=>$http===0];
 $r=['transport'=>'actual MCP native executor ('.(lab_companion('wp-mcp-fator3/wp-mcp-fator3.php')??'?').'), in real local WordPress; no remote HTTP session','documents'=>$reads,'pages'=>array_sum(array_column($reads,'pages')),'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed']))];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/mcp-docs080.json',wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));echo json_encode(['mcp_docs'=>count($reads),'pages'=>$r['pages'],'failed'=>$r['failed']])."\n";
}finally{C\Persistence::delete('connections','grant:'.$grant);C\Persistence::delete('oauth-grants',$grant);C\ConnectionContext::restore_identity(null,1);}
if($r['failed'])exit(1);
