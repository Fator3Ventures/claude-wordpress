<?php
define('DOING_CRON',true);
$lab=getenv('F3_LAB_ROOT');
require $lab.'/wordpress/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';wp_set_current_user(1);
use Fator3\LinkedIn as L;
$baseline=L\Config::VERSION==='0.24.0';
$checks=[];$add=static function($n,$ok)use(&$checks){$checks[$n]=(bool)$ok;};
$add('WP Activity Log 5.7.0 active',is_plugin_active('wp-security-audit-log/wp-security-audit-log.php')&&get_plugin_data(WP_PLUGIN_DIR.'/wp-security-audit-log/wp-security-audit-log.php')['Version']==='5.7.0');
$hits=0;foreach($GLOBALS['wp_filter']['pre_unschedule_event']->callbacks[PHP_INT_MAX]??[] as $row){
 $fn=$row['function'];$rr=is_array($fn)?new ReflectionMethod(...$fn):new ReflectionFunction(Closure::fromCallable($fn));
 if(str_contains((string)$rr->getFileName(),'/wp-security-audit-log/'))++$hits;
}
$add('both real removal callbacks loaded in cron',$hits>=2);
$worker='f3_linkedin_worker';$discovery='f3_linkedin_lead_discovery';$hooks=[$worker,$discovery];$receipts=[];
$add('no discovery task leaves agenda empty',L\LeadDiscovery::ensure()&&!wp_next_scheduled($discovery));
L\Store::put('lead_scan','qa025',['connection_id'=>'missing-qa025','account_id'=>'1','consumer_id'=>'','next_at'=>time()+14400,'offset'=>8],0);
$clean=static function($hooks){$c=_get_cron_array();foreach($c as $ts=>$row){foreach($hooks as $h)unset($c[$ts][$h]);if(empty($c[$ts]))unset($c[$ts]);}_set_cron_array($c);};
$place=static function($hook,$at,$args=[]){$c=_get_cron_array();$c[$at][$hook][md5(serialize($args))]=['schedule'=>false,'args'=>$args];uksort($c,'strnatcasecmp');_set_cron_array($c);};
foreach($hooks as $h){
 $call=$h===$worker?static fn()=>L\Jobs::scheduleTick():static fn()=>L\LeadDiscovery::ensure();
 $clean($hooks);$add($h.' native create',$call()&&wp_next_scheduled($h)!==false);
 $first=wp_next_scheduled($h);$add($h.' existing tick reused',$call()&&wp_next_scheduled($h)===$first);
 // A real pre-writer commits, and the genuine late sensor drops its return on creation.
 $clean($hooks);$at=0;
 $early=static function($pre,$ev)use($h,$place,&$at){if($ev->hook!==$h)return $pre;$at=$ev->timestamp;$place($h,$at);return true;};
 add_filter('pre_schedule_event',$early,15,2);$scheduled=$call();remove_filter('pre_schedule_event',$early,15);
 if(!$baseline){
 $add($h.' native creation after early write and sensor',$scheduled&&$at>0&&(bool)wp_get_scheduled_event($h,[],$at));
 $receipts[$h]['native_schedule']=array_intersect_key(get_option($h.'_schedule_attempt',[]),array_flip(['code','api_code','confirmation','success']));
 foreach(['exact'=>true,'wrong_time'=>false,'wrong_args'=>false,'wrong_hook'=>false,'missing'=>false,'denied'=>false,'claimed_without_write'=>false,'duplicate_other'=>$h===$worker] as $case=>$expected){
  $clean(array_merge($hooks,['qa025_other']));$cb=static function($pre,$ev)use($h,$case,$place){
   if($ev->hook!==$h)return $pre;
   if(!in_array($case,['missing','claimed_without_write'],true))
    $place($case==='wrong_hook'?'qa025_other':$h,$ev->timestamp+(int)in_array($case,['wrong_time','duplicate_other'],true),$case==='wrong_args'?['unexpected']:[]);
   return $case==='claimed_without_write'?true:new WP_Error($case==='denied'?'blocked_by_policy':($case==='duplicate_other'?'duplicate_event':'could_not_set'));
  };
  add_filter('pre_schedule_event',$cb,PHP_INT_MAX,2);
  try{$ok=$call();}finally{remove_filter('pre_schedule_event',$cb,PHP_INT_MAX);}
  $a=get_option($h.'_schedule_attempt',[]);$add($h.' '.$case,$ok===$expected&&($a['success']??null)===$expected&&($a['confirmation']??null)===($expected?($case==='exact'?'exact':'existing_worker'):'unconfirmed'));
  $receipts[$h]['schedule'][$case]=array_intersect_key($a,array_flip(['code','api_code','confirmation','success']));
 }
 // A real denial wiped by the sensor must still be honored by the native API.
 $clean($hooks);$ts=time()+300;$place($h,$ts);$block=static fn($p,$t,$hook)=>$hook===$h?new WP_Error('qa025_denied'):$p;
 add_filter('pre_unschedule_event',$block,15,3);$out=wp_unschedule_event($ts,$h,[],true);remove_filter('pre_unschedule_event',$block,15);
 $add($h.' removal denial preserved',is_wp_error($out)&&$out->get_error_code()==='qa025_denied'&&(bool)wp_get_scheduled_event($h,[],$ts));
 $clean($hooks);$out=wp_unschedule_event($ts,$h,[],true);
 $add($h.' initially absent not certified',is_wp_error($out)&&$out->get_error_code()==='could_not_set');
 }
}
if(!$baseline){
 $ts=time()+120;$clean($hooks);
 foreach([['qa025_other',[]],[$worker,['non-owned']]] as [$foreign,$args]){
  $place($foreign,$ts,$args);$pre=static function($v,$t,$h,$a)use($foreign,$args){return ($h===$foreign&&$a===$args)?new WP_Error('ordinary_denial'):$v;};
  add_filter('pre_unschedule_event',$pre,15,4);$r=wp_unschedule_event($ts,$foreign,$args,true);remove_filter('pre_unschedule_event',$pre,15);
  // Native sensor erases the foreign denial in this lab; LinkedIn must leave that unrelated chain untouched.
  $add('unowned hook or args untouched: '.$foreign,$r===true&&!wp_get_scheduled_event($foreign,$args,$ts));
 }
}
$clean(array_merge($hooks,['qa025_other']));$due=time()-65;
foreach($hooks as $h)$place($h,$due);
copy(__DIR__.'/cron025-child.php',WPMU_PLUGIN_DIR.'/qa025-native.php');
$cmd=json_decode(getenv('F3_LAB_PHP'),true);$cmd[]=ABSPATH.'wp-cron.php';putenv('F3_RUN_NATIVE_CRON025=1');
for($run=1;$run<=2;$run++){
 wp_cache_flush();delete_transient('doing_cron');
 $p=proc_open($cmd,[0=>['file','/dev/null','r'],1=>['file',$lab.'/child.out','a'],2=>['file',$lab.'/child.err','a']],$pipes);
 $add('native cron process '.$run,proc_close($p)===0);wp_cache_flush();
 if($run===1)foreach($hooks as $h){
  $error=get_option('qa025_error_'.$h,null);
  $add($h.' native removal result',$baseline?$error==='could_not_set':$error===null);
  $add($h.' exact due occurrence absent',!wp_get_scheduled_event($h,[],$due));
  if(!$baseline)$add($h.' receipt proves removal only',(get_option($h.'_reconciled_removal',[])['scheduled_at']??null)===$due);
  $receipts[$h]['native']=['error'=>$error,'removed'=>!wp_get_scheduled_event($h,[],$due),'calls'=>(int)get_option('qa025_calls_'.$h,0)];
 }
}
unlink(WPMU_PLUGIN_DIR.'/qa025-native.php');
foreach($hooks as $h)$add($h.' no repeat after second pass',(int)get_option('qa025_calls_'.$h,0)===1);
$workerRun=get_option('f3_linkedin_last_worker');$ldRun=get_option($discovery.'_last')['result']??[];
$add('no claim of processed worker item',isset($workerRun['processed'])&&$workerRun['processed']===0);
$add('discovery resumes and preserves ineligible checkpoint',($ldRun['data']['processed']??-1)===0&&L\Store::get('lead_scan','qa025')['value']['offset']===8&&wp_next_scheduled($discovery)>$due);
if(!$baseline){$task=L\Store::get('lead_scan','qa025');$v=$task['value'];$v['next_at']=0;L\Store::put('lead_scan','qa025',$v,$task['revision']);L\LeadDiscovery::tick();
 $last=L\Worker::health()['cron_lead_discovery']['last_run'];$add('failed processing distinguishable from successful scheduling',$last['attempted']===1&&$last['errors']===1&&L\Store::get('lead_scan','qa025')['value']['offset']===8);}
$receipts[$worker]['execution']=['processed'=>$workerRun['processed']??null,'errors'=>$workerRun['errors']??null];
$receipts[$discovery]['execution']=['attempted'=>$ldRun['data']['processed']??null,'errors'=>count($ldRun['data']['errors']??[])];
$r=['version'=>L\Config::VERSION,'wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'real_removal_callbacks'=>$hits,'receipts'=>$receipts,'checks'=>$checks,'total'=>count($checks),'failed'=>array_keys(array_filter($checks,fn($v)=>!$v))];
file_put_contents($lab.'/evidence/cron025.json',wp_json_encode($r,JSON_PRETTY_PRINT));echo wp_json_encode(['total'=>$r['total'],'failed'=>$r['failed']])."\n";exit($r['failed']?1:0);
