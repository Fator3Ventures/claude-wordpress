# Plano — Fator3 Site Core 1.51.0

24/10/2026 UTC. Base direta 1.50.0; alvo 1.51.0, contrato administrativo 8.16.0. Pedidos 294 C1–C8 e 295. Normas comuns revisão 5, de 23/10/2026. Plano registrado antes da implementação.

1. Publicar o cliente PHP `pipedrive-api-client/1.0.0` com o hook e os envelopes consumidos pelo Pipedrive 0.1.0. Registro não autoriza uso. A option `f3base_pipedrive_operacao` nasce com ativo=false, consumidores=[] e orcamento_diario=3000; escrita administrativa pelo catálogo/config-core-escrever, com procedência. Nenhuma credencial nova no acompanhante.
2. Reservar atomicamente orçamento separado `operacao` (GET 20, escritas 10, dia UTC). Conferir conta, autorização, callback, revisão esperada e recuperação antes do despacho, sob trava compartilhada com as gravações Core pertinentes. Host fixo, caminhos relativos v1/v2, métodos fechados, corpo de até 64 KiB, timeout 20s, sem redirecionamento/reenvio. Rejeitar ids em massa, merge e credencial na query. Saldo oficial separado da estimativa, bloqueando somente operação se menor que 3000; pausa HTTP 429 continua compartilhada.
3. Pedido 295: normalizar extremidades na escrita/leitura sem rotacionar segredo salvo; avisos explícitos de formato. Retirar mínimo Meta arbitrário de 100 caracteres: documentação oficial diz que tamanho varia. Verificar a credencial salva com debug_token, sem revelar o valor; registrar identidade aceita. Manter segurança de transporte, permissão e guardas de revisão.
4. Atualizar ajuda, contratos, schemas e release; preservar fila, formulários, deduplicação e acompanhantes. Meta 0.9.0, LinkedIn 0.10.1, Google 0.19.0 e MCP 0.29.1 examinados; não se prevê mudança de seus contratos. Pipedrive 0.1.0 novo: impacto próprio de validação coordenada abaixo. O impacto recebido Pipedrive→Core revisão 1 será respondido no relatório principal, conforme norma 5.
5. Provar limites, autorização, concorrência, saldo, recuperação, incerteza e proteção do segredo no WordPress real descartável. Exercitar consumidor Pipedrive original e regressões afetadas. Instalação limpa e atualização 1.50.0, mínimos Core WP7.1.2/PHP8.3.6, integração no Site-Teste WP7.1.3/PHP8.3.36, leitura documental nativa e via MCP.
6. Gerar instalador final, instalar Core no Site-Teste e então o Pipedrive recebido, com configuração desligada por padrão. Testes de fornecedor limitados à autorização/configuração disponível; registrar limites sem inventar homologação. Nenhuma publicação ou instalação em produção. Entregar fonte, instalador, relatório e impacto ao dono.

## Referências técnicas consultadas

- https://developers.facebook.com/documentation/facebook-login/guides/access-tokens — tamanho variável, sem garantia universal de mínimo 100.
- https://developers.facebook.com/docs/graph-api/reference/debug_token/ — metadados e validade remotos.
- https://pipedrive.readme.io/docs/core-api-concepts-rate-limiting — orçamento da conta e burst compartilhados; custos locais são estimativas do pedido.

## Impacto emitido

`base-site-core-fator3-1.51.0-impacto-wp-mcp-pipedrive-fator3.md`, revisão 1, validação coordenada de contrato novo. Não há encaminhamento para anunciar versões ou encerrar impactos anteriores.
