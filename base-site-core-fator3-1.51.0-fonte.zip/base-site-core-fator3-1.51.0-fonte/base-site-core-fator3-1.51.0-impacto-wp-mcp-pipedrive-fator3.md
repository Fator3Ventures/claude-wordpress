# Impacto de base-site-core-fator3 1.51.0 em wp-mcp-pipedrive-fator3

Revisão 1 · 24/10/2026 UTC · etapa planejamento · situação validação-pendente · classificação validacao-coordenada.
Emissor: Core base 1.50.0, alvo previsto 1.51.0/contrato administrativo 8.16.0; instalador ainda não gerado. Destinatário: Pipedrive 0.1.0, instalador SHA-256 3366d83ca8908e407a0736812d30b8fa1506a8c1458a28cfb47eda6fd8f3c54f. Pedido 294 C1–C8; referência de assinatura: impacto recebido Pipedrive→Core revisão 1.

## Contrato novo e consequência

O Core publicará `pipedrive-api-client/1.0.0` por `f3base_register_pipedrive_consumers($registry,$contract)` em plugins_loaded. `register_consumer(provider,version,contract,configuration)` devolve cliente com capabilities/status/request no formato esperado por CoreClient do Pipedrive 0.1.0. Callback retorna ready, revision e provider. A autorização explícita é separada do registro.

Configurar `f3base_pipedrive_operacao` por config-core-escrever com `ativo`, `consumidores` e `orcamento_diario` (padrão false, [], 3000; mínimo 1). Autorizar apenas `wp-mcp-pipedrive-fator3` no site-porta. A fila comercial não depende desse interruptor. O status exige administrador e conta verificada, retorna conta, revisão, orçamento {teto,consumido,reservado} e saldo {restante,lido_em UTC} ou null. Não faz HTTP. A revisão cobre credencial, conta, autorização, limite e configuração do consumidor; não cobre o consumo que muda a cada chamada.

Request exige provider/consumer/contract/actor_id/revisao_esperada, e previa_id nas escritas. Revalida no trecho crítico da reserva/HTTP. Mudança exige nova prévia. Não reutilizar confirmação após contexto_alterado/revisao_conflitante. Códigos sem despacho: operacao_nao_autorizada, credencial_invalida, saldo_conta_baixo, orcamento_esgotado, pausa_remota, core_em_recuperacao, revisao_conflitante, contexto_alterado e core_indisponivel. Entrada recusada usa entrada_invalida; o consumidor atual pode projetá-la como core_recusou.

`remote_dispatched=false` significa bloqueio anterior ao transporte. Depois de iniciar HTTP, timeout/exceção são resultado_incerto e não liberam repetição automática; respostas HTTP conservam status, erros omitem corpo. Corpo bem-sucedido é sanitizado antes de sair do Core. Limite de resposta 512 KiB; limite de corpo de entrada 64 KiB; timeout 20s, zero redirecionamento. Caminho `/v1/` ou `/api/v2/` no host fixo api.pipedrive.com. Merge, ids em query/corpo e credencial em query/corpo são recusados.

Saldo remoto menor que 3000 pausa apenas operacao, inclusive quando o valor remanescente foi observado por entregas/qualidade/verificacao. Saldo desconhecido não inventa valor nem bloqueia pelo piso. O último saldo conhecido persiste com horário; a virada do contador UTC não aumenta saldo remoto por suposição. HTTP 429 pausa todos os consumidores da conta, como antes. Consultas de verificação existentes podem renovar o saldo. Cotas locais não garantem a disponibilidade global do fornecedor.

## Ação e aceite coordenado

Responsáveis Core e mantenedor Pipedrive/frota: instalar Core primeiro, Pipedrive depois no Site-Teste autorizado; conferir A1/A2/A3/A10–A15, conta e revisão no cliente original. Validar configuração desligada, mudança concorrente, teto 40, saldo abaixo de 3000, 429 compartilhado, recuperação e ausência de segredo. Repetir o fluxo de prévia/aplicação/recibo com dados identificados de homologação antes de uso comercial; registros criados devem ser eliminados. Nenhuma nova assinatura é pedida ao Pipedrive antecipadamente; qualquer incompatibilidade de envelope encontrada exige ajuste antes do aceite comercial.

Este documento apresenta a dependência operacional e critérios do contrato novo. Atendimento do impacto recebido e resultados dos testes serão registrados no relatório principal, sem reemitir este arquivo apenas para comunicar aceite.
