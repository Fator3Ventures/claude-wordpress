# Fator3 Site Core 1.51.0 — fonte

Base direta 1.50.0; pedidos 294 e 295. Contrato administrativo 8.16.0, 145 abilities Core. Runtime em work/plugin/base-site-core-fator3, idêntico ao instalador. Este ZIP não é instalável.

build/README.md explica reprodução. tests/request-294.php exercita o contrato novo e o cliente original Pipedrive; request-294-recovery.php prova recuperação e bootstrap em processo novo; request-295.php verifica tokens Meta salvos, avisos, identidade e proteção do segredo. Regressões históricas afetadas e DOM têm evidência própria em evidence/1510. Somente o relatório corrente identifica o que foi executado nesta rodada.

companions/ contém runtime intacto dos instaladores MCP 0.29.1, Google 0.19.0, Meta 0.9.0, LinkedIn 0.10.1 e Pipedrive 0.1.0. São entradas de integração, não entregas alteradas. Não integram o instalador Core. inputs/1510 preserva pedidos/relatórios/normas revisão 5. Fontes e instaladores dos três novos acompanhantes foram comparados byte a byte.

Não contém banco, credenciais reais, cookies, dependências de laboratório, node_modules ou ZIP aninhado. Cópia do relatório no fonte antecede o fechamento; relatório externo informa o hash final do fonte. Arquivos históricos são preservados como referência, sem afirmar reexecução dos seus testes.
