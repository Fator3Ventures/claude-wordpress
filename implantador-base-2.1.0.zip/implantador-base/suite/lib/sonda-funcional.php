<?php
/**
 * Sonda funcional: exercita as funções PURAS do pacote, sem WordPress.
 *
 * Subprocesso por desenho — carregar as classes do implantador define ABSPATH e
 * um punhado de funções do núcleo, e isso não pode vazar para o processo que
 * imprime os estados. Devolve JSON; quem imprime e conta é `estado()`.
 *
 * Cada bloco tem TETO (o caso correto continua em silêncio) e PISO (o mutante
 * precisa reprovar) na mesma sonda: uma validação que só foi exercitada com o
 * arquivo certo não provou saber reprovar nada.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( $argv[1] ?? '', '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'erro' => 'raiz inexistente' ) );
	exit( 2 );
}

define( 'ABSPATH', '/tmp/f3base-sem-wordpress/' );
define( 'F3BASE_IMP_DIR', $raiz . '/' );
define( 'F3BASE_IMP_ARQUIVO', $raiz . '/implantador-base.php' );
define( 'F3BASE_IMP_TEXT_DOMAIN', 'f3base' );

/**
 * Caminho relativo do arquivo principal, como o núcleo o produz.
 *
 * Mesma forma do original — `<pasta>/<arquivo>.php` —, para que o slug que o
 * preflight extrai daqui seja o mesmo que ele extrai no site.
 *
 * @param string $arquivo Caminho absoluto do arquivo principal.
 * @return string
 */
function plugin_basename( string $arquivo ): string {
	return basename( dirname( $arquivo ) ) . '/' . basename( $arquivo );
}

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor  Valor.
 * @param int   $flags  Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Validação de e-mail do núcleo.
 *
 * @param mixed $valor Valor.
 * @return string|false
 */
function is_email( $valor ) {
	return is_string( $valor ) && false !== filter_var( $valor, FILTER_VALIDATE_EMAIL ) ? $valor : false;
}

/**
 * `wp_parse_url()` do núcleo, na forma que este pacote usa.
 *
 * O núcleo delega a `parse_url()` e só acrescenta compatibilidade para URL
 * relativa em PHP antigo. A bancada precisa dela porque a GUARDA DE HTTPS
 * medida aqui é a função REAL do pacote, alcançada por reflexão: reescrevê-la
 * nesta sonda provaria que a cópia funciona.
 *
 * @param string $url       URL.
 * @param int    $componente Componente do parse_url().
 * @return mixed
 */
function wp_parse_url( string $url, int $componente = -1 ) {
	return parse_url( $url, $componente );
}

/**
 * Escapes com tradução, na bancada sem WordPress.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio de tradução.
 * @return string
 */
function esc_html__( string $texto, string $dominio = '' ): string {
	unset( $dominio );

	return $texto;
}

/**
 * Escape de atributo com tradução, na bancada sem WordPress.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio de tradução.
 * @return string
 */
function esc_attr__( string $texto, string $dominio = '' ): string {
	unset( $dominio );

	return $texto;
}

/**
 * Escape de atributo, na bancada sem WordPress.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_attr( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES, 'UTF-8' );
}

/**
 * Escape de saída do núcleo.
 *
 * A MESMA função que a interpolação usa para gravar e que a leitura de volta
 * usa para conferir: fossem duas, a checagem poderia aprovar um conteúdo em que
 * o valor gravado e o valor procurado só coincidem por acaso.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_html( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES );
}

/**
 * Desserialização tolerante do núcleo.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function maybe_unserialize( $valor ) {
	if ( is_string( $valor ) ) {
		$dados = @unserialize( trim( $valor ) );

		if ( false !== $dados || 'b:0;' === trim( $valor ) ) {
			return $dados;
		}
	}

	return $valor;
}

/**
 * Caminho dentro do pacote, com a mesma guarda de travessia do implantador.
 *
 * @param string $relativo Caminho relativo.
 * @return string
 */
function f3base_imp_caminho( string $relativo ): string {
	$base = rtrim( F3BASE_IMP_DIR, '/' ) . '/';

	if ( '' === $relativo || str_contains( $relativo, '../' ) ) {
		return '';
	}

	$candidato = $base . ltrim( $relativo, '/' );
	$real      = realpath( $candidato );

	if ( false === $real ) {
		return $candidato;
	}

	return str_starts_with( $real, $base ) ? $real : '';
}

require $raiz . '/includes/class-f3base-imp-config.php';
require $raiz . '/includes/class-f3base-imp-decisoes.php';
require $raiz . '/includes/class-f3base-imp-projeto.php';
require $raiz . '/includes/class-f3base-imp-residencia.php';
require $raiz . '/includes/class-f3base-imp-formulario.php';
/*
 * O GRAVADOR ENTRA NESTA BANCADA desde a 1.1.0: a regra de três vias das
 * options é função pura dele, e medi-la exige a classe REAL — reimplementá-la
 * aqui provaria que a cópia funciona.
 */
require $raiz . '/includes/class-f3base-imp-gravador.php';
require $raiz . '/includes/class-f3base-imp-conteudo.php';
require $raiz . '/includes/class-f3base-imp-relatorio.php';
require $raiz . '/includes/class-f3base-imp-lotes.php';
require $raiz . '/includes/class-f3base-imp-entrega.php';
require $raiz . '/includes/class-f3base-imp-preflight.php';
require $raiz . '/includes/class-f3base-imp-plugins.php';
require $raiz . '/includes/class-f3base-imp-seo.php';
/*
 * A REGRA DE FASE ENTRA NESTA BANCADA na 1.1.6: ela é função pura, roda nos
 * dois emissores e decide entre dois estados fechados. Medi-la exige a classe
 * REAL — reimplementá-la aqui provaria que a cópia funciona, que é exatamente
 * o que uma suíte não pode provar sobre a regra que ela usa para calar linhas.
 */
require $raiz . '/includes/class-f3base-imp-fases.php';
/*
 * O JOURNAL ENTRA NA 1.1.7 pela leitura pura que ele passou a expor: quais IDs
 * de post ESTA execução escreveu. É esse conjunto que separa "o template está
 * no ar porque acabou de ser implantado" de "o template sobreviveu a quem
 * deveria tê-lo substituído", e uma lista escrita à mão em qualquer outro lugar
 * seria uma segunda verdade sobre o que a execução fez.
 */
require $raiz . '/includes/class-f3base-imp-journal.php';
/*
 * A LIMPEZA ENTRA NA 2.1.0 pela regra pura dela: o plano do que sai e do que
 * fica é função sem WordPress, e é ela que tem teto e piso aqui.
 */
require $raiz . '/includes/class-f3base-imp-limpeza.php';

$resultado = array();

/**
 * Acumula um achado.
 *
 * @param string $checagem Nome.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]             = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Registra uma medida (aprovando ou não).
 *
 * @param string $checagem Nome.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Contém, sem depender de caixa.
 *
 * O texto do relatório grifa em MAIÚSCULA o que precisa saltar aos olhos, e
 * uma sonda presa à caixa reprovaria a ênfase em vez do conteúdo.
 *
 * @param string $palheiro Texto medido.
 * @param string $agulha   Trecho exigido ou proibido.
 * @return bool
 */
function contem( string $palheiro, string $agulha ): bool {
	return '' !== $agulha && false !== stripos( $palheiro, $agulha );
}

/* ---------- config.schema_valida: teto e piso ---------- */

$nome = 'config.schema_valida';
medir( $nome );

if ( ! F3Base_Imp_Config::carregar() ) {
	anotar( $nome, 'teto: site.json não valida contra o schema — ' . implode( ' | ', F3Base_Imp_Config::erros() ) );
}

medir( $nome );

/*
 * O QUE SE PROVA AQUI É DE ONDE O VALOR VEIO, e não QUAL ele é. Fixar a escolha
 * — `false` — amarraria este piso a uma decisão que o pacote tem o direito de
 * rever, e a revisão faria a suíte reprovar sem defeito nenhum. Basta que a
 * chave exista no catálogo e chegue com o tipo que ela declara: se ela tivesse
 * voltado para a configuração, o catálogo não a teria e a leitura devolveria
 * null.
 */
if ( ! is_bool( F3Base_Imp_Decisoes::valor( 'cabecalhos.hsts' ) ) ) {
	anotar( $nome, 'teto: cabecalhos.hsts não veio do catálogo com o tipo declarado — a decisão saiu do lugar certo ou voltou para a configuração' );
}

medir( $nome );

if ( true !== F3Base_Imp_Config::obter( 'ambiente.hsts', true ) ) {
	anotar( $nome, 'teto: chave ausente não devolveu o padrão explícito' );
}

medir( $nome );

if ( false !== F3Base_Imp_Config::existe( 'ambiente.hsts' ) ) {
	anotar( $nome, 'teto: existe() não distingue ausente de declarado' );
}

$original = json_decode( (string) file_get_contents( $raiz . '/config/site.json' ), true );

$mutantes = array(
	'tipo errado'         => static function ( array $c ): array {
		$c['consumidores_declarados'] = 'sim';
		return $c;
	},
	'chave não declarada' => static function ( array $c ): array {
		$c['ambiente']['hsts'] = true;
		return $c;
	},
	'obrigatória ausente' => static function ( array $c ): array {
		unset( $c['seo']['organizacao']['nome'] );
		return $c;
	},
	'enum inválido'       => static function ( array $c ): array {
		$c['ambiente']['tipo'] = 'homologacao';
		return $c;
	},
	/*
	 * As duas chaves nascidas na 1.0.12 entram no piso do validador junto com
	 * as outras: chave nova sem mutante é chave cujo schema nunca provou
	 * reprovar nada.
	 */
	'enum de indexação'   => static function ( array $c ): array {
		$c['ambiente']['indexar'] = 'as-vezes';
		return $c;
	},
	'lista de prévia'     => static function ( array $c ): array {
		$c['ambiente']['dominios_de_previa'] = 'dreamhosters.com';
		return $c;
	},
	'padrão de texto'     => static function ( array $c ): array {
		$c['contato']['whatsapp_e164'] = '+55 11 90000-0000';
		return $c;
	},
	'regime misturado'    => static function ( array $c ): array {
		$c['formularios'][0]['pagina_confirmacao'] = array( 'slug' => 'obrigado', 'pai_ref' => null );
		return $c;
	},
	'mínimo numérico'     => static function ( array $c ): array {
		$c['retencao']['leads_meses'] = 0;
		return $c;
	},
	/*
	 * As chaves nascidas na 1.0.17 entram no piso do validador pela mesma razão
	 * que as da 1.0.12: chave nova sem mutante é chave cujo schema nunca provou
	 * reprovar nada. O enum de permalinks é o que sobrou aqui: a decisão sobre o
	 * conteúdo de exemplo saiu da configuração e virou linha do catálogo, e as
	 * regras dela — valor reconhecido e chave presente — passaram a ser medidas
	 * onde o valor mora agora, em `decisoes.fonte_unica` e no próprio veredito
	 * de `conteudo.exemplo_do_wordpress`, que fecha BLOCKED com valor que não
	 * reconhece.
	 */
	'enum de permalinks'  => static function ( array $c ): array {
		$c['ambiente']['permalinks_decisao'] = 'aplicar-sempre-e-torcer';
		return $c;
	},
	/*
	 * A chave nascida na 1.0.18 entra no piso do validador pela mesma razão que
	 * as anteriores: chave nova sem mutante é chave cujo schema nunca provou
	 * reprovar nada. São DOIS mutantes, porque a chave tem duas regras que
	 * importam — o alfabeto do nome do cabeçalho e o mínimo dos saltos, que não
	 * pode ser zero (zero leria a ponta que o próprio cliente escreveu).
	 */
	'cabeçalho de origem' => static function ( array $c ): array {
		$c['cabecalhos']['origem_confiavel']['cabecalho'] = 'X Forwarded For; drop table';
		return $c;
	},
	'saltos de proxy'     => static function ( array $c ): array {
		$c['cabecalhos']['origem_confiavel']['saltos'] = 0;
		return $c;
	},
);

foreach ( $mutantes as $rotulo => $mutar ) {
	medir( $nome );

	if ( array() === F3Base_Imp_Config::validar( $mutar( $original ) ) ) {
		anotar( $nome, 'piso: mutante "' . $rotulo . '" passou sem erro — validador cego' );
	}
}

medir( $nome );

if ( array() !== F3Base_Imp_Config::validar( $original ) ) {
	anotar( $nome, 'piso: o arquivo correto deixou de ficar em silêncio' );
}

/* ---------- conteudo.merge_tres_vias ---------- */

$nome = 'conteudo.merge_tres_vias';
$b    = hash( 'sha256', 'base' );
$h    = hash( 'sha256', 'humano' );
$n    = hash( 'sha256', 'novo' );

$tabela = array(
	array( $b, $b, $b, 'gerenciado', 'atualizar_base', 'igual/igual/igual não grava' ),
	array( $b, $b, $n, 'gerenciado', 'gravar', 'base/base/novo é atualização segura' ),
	array( $b, $h, $b, 'gerenciado', 'preservar', 'base/edição humana/base preserva a edição' ),
	array( $b, $h, $n, 'conflito', 'conflito', 'base/edição humana/novo sem política é conflito' ),
	/*
	 * A LINHA QUE A 1.1.0 INVERTEU. Até a 1.0.19 ela dizia `gravar`: base ≠
	 * observado ≠ desejado com política `gerenciado` fazia o conteúdo do
	 * template vencer a edição de quem opera o site, a cada reexecução do
	 * implantador. Sob a premissa desta release, o conteúdo do pacote é
	 * DEMONSTRATIVO e a edição vence. O piso é esta linha: trocá-la de volta
	 * para `gravar` reprova aqui.
	 */
	array( $b, $h, $n, 'gerenciado', 'preservar', 'edição do agente + template mudado, com política gerenciado: a EDIÇÃO sobrevive' ),
	array( $b, $h, $n, 'preservar', 'preservar', 'a mesma linha com política de campo preservado preserva' ),
	array( $h, $n, $n, 'conflito', 'atualizar_base', 'igual ao desejado não grava e atualiza a base' ),
	array( null, $h, $n, 'conflito', 'conflito', 'sem base e divergente é conflito' ),
	array( null, $h, $n, 'preservar', 'preservar', 'sem base com política preservar (a página adotada)' ),
	array( null, $h, $n, 'gerenciado', 'gravar', 'sem base com política gerenciado (primeira execução)' ),
);

foreach ( $tabela as $linha ) {
	medir( $nome );
	$decisao = F3Base_Imp_Conteudo::merge_campo( $linha[0], $linha[1], $linha[2], $linha[3] );

	if ( $decisao['acao'] !== $linha[4] ) {
		anotar( $nome, $linha[5] . ': esperado ' . $linha[4] . ', obtido ' . $decisao['acao'] );
	}
}

/*
 * PISO DA REGRA INTEIRA, e não de uma linha: com base, o pacote só GRAVA
 * conteúdo em objeto que ninguém tocou. Qualquer política, qualquer campo — se
 * o observado divergiu da base, a decisão não pode ser `gravar`. É esta
 * afirmação que a 1.0.19 não sustentava.
 */
foreach ( array( 'gerenciado', 'preservar', 'conflito', 'sem-politica-declarada' ) as $politica_medida ) {
	medir( $nome );

	$decisao_tocada = F3Base_Imp_Conteudo::merge_campo( $b, $h, $n, $politica_medida );

	if ( 'gravar' === $decisao_tocada['acao'] ) {
		anotar( $nome, 'piso: com a política "' . $politica_medida . '" o pacote GRAVOU sobre um objeto que quem opera o site já tinha editado — o pacote só pode gravar onde base === observado' );
	}
}

medir( $nome );

if ( ! contem( F3Base_Imp_Conteudo::merge_campo( $b, $h, $n, 'gerenciado' )['motivo'], 'NOMEADA' ) ) {
	anotar( $nome, 'piso: a preservação não anuncia que a divergência sai nomeada no relatório — preservar calado é indistinguível de não ter medido nada' );
}

/*
 * PISO DA DURAÇÃO DA PRESERVAÇÃO. Até a 1.0.19 o ramo `preservar` movia a base
 * para o valor OBSERVADO — e base igual ao observado é a condição do ramo
 * "ninguém tocou". A proteção valia por UMA execução: na seguinte, a mesma
 * edição intocada passava a ser lida como conteúdo do pacote, e a primeira
 * mudança do template gravava por cima dela. A base é o último valor que ESTE
 * pacote aplicou, e quem preserva não aplicou nada.
 */
foreach ( array(
	array( $b, $h, $b, 'conflito', 'preservar', 'edição humana com o desejado igual à base' ),
	array( $b, $h, $n, 'gerenciado', 'preservar', 'edição humana com o template mudado' ),
	array( $b, $h, $n, 'preservar', 'preservar', 'edição humana com política de campo preservado' ),
) as $linha_de_base ) {
	medir( $nome );

	$d = F3Base_Imp_Conteudo::merge_campo( $linha_de_base[0], $linha_de_base[1], $linha_de_base[2], $linha_de_base[3] );

	if ( $linha_de_base[4] !== $d['acao'] || F3Base_Imp_Conteudo::BASE_INALTERADA !== ( $d['base'] ?? '' ) ) {
		anotar( $nome, 'piso: em "' . $linha_de_base[5] . '" a decisão moveu a BASE — na execução seguinte a base ficaria igual ao observado, o ramo "ninguém tocou" venceria e o template gravaria por cima. A preservação duraria uma execução' );
	}
}

/* TETO: o que o pacote APLICA vira base, ou ele reaplicaria tudo para sempre. */
foreach ( array(
	array( $b, $b, $n, 'gerenciado', 'gravar' ),
	array( $b, $n, $n, 'gerenciado', 'atualizar_base' ),
	array( null, $h, $n, 'gerenciado', 'gravar' ),
) as $linha_de_base ) {
	medir( $nome );

	$d = F3Base_Imp_Conteudo::merge_campo( $linha_de_base[0], $linha_de_base[1], $linha_de_base[2], $linha_de_base[3] );

	if ( $linha_de_base[4] !== $d['acao'] || F3Base_Imp_Conteudo::BASE_DESEJADO !== ( $d['base'] ?? '' ) ) {
		anotar( $nome, 'teto: a decisão "' . $d['acao'] . '" não registrou o desejado como base nova — sem isso o pacote reaplicaria o mesmo campo em toda execução' );
	}
}

/* ---------- conteudo.nao_promocao_status ---------- */

$nome = 'conteudo.nao_promocao_status';
medir( $nome );

if ( ! ( F3Base_Imp_Conteudo::rank_status( 'publish' ) > F3Base_Imp_Conteudo::rank_status( 'draft' ) ) ) {
	anotar( $nome, 'publish não é mais público que draft — a regra de não promoção depende disso' );
}

/* ---------- relatorio.waiver_casa ---------- */

$nome  = 'relatorio.waiver_casa';
$casos = array(
	array( 'orcamento.pagina:home', 'orcamento.pagina:', true, 'prefixo terminado em dois-pontos casa' ),
	array( 'orcamento.pagina', 'orcamento.pagina', true, 'igualdade casa' ),
	array( 'orcamento.pagina:', 'orcamento.pagina:', true, 'igualdade exata do prefixo casa' ),
	array( 'orcamento.paginaX', 'orcamento.pagina', false, 'prefixo sem dois-pontos não casa' ),
	array( 'qualquer.coisa', '', false, 'padrão vazio não casa' ),
	array( 'qualquer.coisa', '*', false, 'asterisco não casa' ),
	array( 'qualquer.coisa', ':', false, 'só dois-pontos não casa' ),
	array( 'qualquer.coisa', '.', false, 'ponto não casa' ),
	array( 'orcamento.pagina:home', 'orcamento.', false, 'prefixo com ponto final não casa' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	if ( F3Base_Imp_Relatorio::waiver_casa( $caso[0], $caso[1] ) !== $caso[2] ) {
		anotar( $nome, $caso[3] . ': resultado invertido' );
	}
}

/* ---------- relatorio.sanitiza_dump ---------- */

$nome    = 'relatorio.sanitiza_dump';
$payload = array(
	'user_email'  => 'pessoa@exemplo.test',
	'sha256'      => 'abc123',
	'serializado' => serialize( array( 'token' => 'segredo-real', 'contagem' => 3 ) ),
	'aninhado'    => array( 'senha' => 'nao-deve-sair', 'ok' => 'pode-sair' ),
	'solto'       => 'outra@pessoa.test',
);

$texto = (string) wp_json_encode( F3Base_Imp_Relatorio::sanitizar( $payload ) );

$assercoes = array(
	array( ! str_contains( $texto, 'pessoa@exemplo.test' ), 'e-mail em chave proibida não foi redigido' ),
	array( ! str_contains( $texto, 'outra@pessoa.test' ), 'e-mail solto não foi redigido pelo valor' ),
	array( ! str_contains( $texto, 'segredo-real' ), 'token dentro de array serializado não foi alcançado' ),
	array( ! str_contains( $texto, 'nao-deve-sair' ), 'senha aninhada não foi redigida' ),
	array( str_contains( $texto, 'abc123' ), 'hash técnico de estado foi removido sem motivo' ),
	array( str_contains( $texto, 'pode-sair' ), 'valor legítimo foi removido' ),
	array( str_contains( $texto, '__redigido' ), 'a redação não preservou a estrutura' ),
	array( str_contains( $texto, '"contagem":3' ), 'a estrutura do serializado foi corrompida' ),
);

foreach ( $assercoes as $a ) {
	medir( $nome );

	if ( ! $a[0] ) {
		anotar( $nome, $a[1] );
	}
}

/* ---------- config.residencia_derivada: teto e piso do produtor de residência ---------- */

/*
 * O DEFEITO MEDIDO, num log de implantação real: a guarda da política imprimiu
 * "3 chave(s) de contato.controlador está(ão) vazia(s) EM CONFIG/SITE.JSON …
 * preencha … em config/site.json e execute de novo", e `contato.controlador`
 * mora em `config/projeto.json`. Quem seguisse a instrução editava o arquivo
 * errado e as chaves não passavam a existir.
 *
 * A causa era o nome do arquivo DIGITADO na mensagem. `F3Base_Imp_Residencia`
 * passou a derivá-lo do que cada leitor declara, e é este bloco que prova que
 * ele deriva — e que NÃO adivinha, que é a forma de o defeito voltar com nome
 * de correção.
 *
 * TETO: chave do operador resolve para o arquivo do projeto, chave de conteúdo
 * resolve para o arquivo único, e índice numérico casa com a forma normalizada.
 * PISO: chave que não mora em lugar nenhum não recebe palpite, e a frase dela
 * não nomeia arquivo nenhum.
 */

$nome = 'config.residencia_derivada';
$R    = 'F3Base_Imp_Residencia';

$casos_de_residencia = array(
	array( 'contato.controlador.razao_social', F3Base_Imp_Projeto::ARQUIVO, 'teto: chave do operador' ),
	array( 'contato.whatsapp_e164', F3Base_Imp_Projeto::ARQUIVO, 'teto: destino do regime de WhatsApp' ),
	array( 'mecanismo_de_cadencia', F3Base_Imp_Projeto::ARQUIVO, 'teto: mecanismo da cadência' ),
	array( 'conteudo.demonstrativo', F3Base_Imp_Config::ARQUIVO, 'teto: chave de conteúdo' ),
	array( 'formularios.1.caixa_de_leads', F3Base_Imp_Projeto::ARQUIVO, 'teto: índice numérico casa com a forma normalizada' ),
	array( 'contato.controlador.nao_existe', '', 'piso: chave que não mora em lugar nenhum não recebe palpite' ),
);

foreach ( $casos_de_residencia as $caso ) {
	medir( $nome );

	$obtido = $R::arquivo_da_chave( $caso[0] );

	if ( $obtido !== $caso[1] ) {
		anotar(
			$nome,
			$caso[2] . ': "' . $caso[0] . '" resolveu para "' . $obtido . '" e o esperado era "'
				. ( '' === $caso[1] ? '(nenhum arquivo)' : $caso[1] ) . '"'
		);
	}
}

/*
 * PISO DA FRASE: sem residência derivável, ela não pode nomear arquivo NENHUM.
 * Um palpite aqui seria o defeito de volta com derivação no nome — e o operador
 * não tem como saber que foi palpite.
 */
$frase_sem_residencia = $R::onde_preencher( array( 'contato.controlador.nao_existe' ) );

foreach ( array( F3Base_Imp_Projeto::ARQUIVO, F3Base_Imp_Config::ARQUIVO ) as $arquivo_possivel ) {
	medir( $nome );

	if ( contem( $frase_sem_residencia, $arquivo_possivel ) ) {
		anotar( $nome, 'piso: a frase de uma chave sem residência nomeou ' . $arquivo_possivel . ' — «' . $frase_sem_residencia . '»' );
	}
}

/* TETO E PISO da frase do controlador: nomeia o certo e NÃO nomeia o trocado. */
$frase_do_controlador = $R::onde_preencher( array( 'contato.controlador.razao_social', 'contato.controlador.documento', 'contato.controlador.endereco' ) );

medir( $nome );

if ( ! contem( $frase_do_controlador, F3Base_Imp_Projeto::ARQUIVO ) ) {
	anotar( $nome, 'teto: a frase do controlador não nomeia ' . F3Base_Imp_Projeto::ARQUIVO . ', que é onde as chaves moram — «' . $frase_do_controlador . '»' );
}

medir( $nome );

if ( contem( $frase_do_controlador, F3Base_Imp_Config::ARQUIVO ) ) {
	anotar( $nome, 'piso: a frase do controlador nomeia ' . F3Base_Imp_Config::ARQUIVO . ', que é exatamente o arquivo errado do defeito medido — «' . $frase_do_controlador . '»' );
}

/* TETO da frase MISTA: cada arquivo sai com as chaves que ele declara. */
$frase_mista = $R::onde_preencher( array( 'contato.whatsapp_e164', 'conteudo.demonstrativo' ) );

foreach ( array( F3Base_Imp_Projeto::ARQUIVO, F3Base_Imp_Config::ARQUIVO, 'contato.whatsapp_e164', 'conteudo.demonstrativo' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $frase_mista, $trecho ) ) {
		anotar( $nome, 'teto: chaves de arquivos diferentes perderam "' . $trecho . '" na frase — «' . $frase_mista . '». Sem o par, alguém abre o arquivo certo procurando a chave que está no outro' );
	}
}

/* ---------- formulario.veredito_destino: teto e piso ---------- */

/*
 * O REGIME É DERIVADO DO VALOR desde a 1.0.19, e este bloco é o piso da regra.
 *
 * Havia `ativo` na entrada do formulário E o destino na configuração — dois
 * fatos podendo discordar, e eles discordavam: o regime whatsapp ficava
 * declarado ATIVO e fechava BLOCKED por falta de destino na MESMA execução, e
 * uma implantação de template limpo, que tinha dado certo, terminava dizendo
 * que algo estava errado. A condição passou a ser uma só, a PRESENÇA do valor.
 *
 * Os quatro ramos precisam existir e ficar provados aqui, porque nenhum é
 * intercambiável com outro:
 *
 * - destino VAZIO é N/A com a condição declarada — nunca BLOCKED. Regime que
 *   ninguém instanciou não é pré-condição AUSENTE, e a mensagem diz que basta
 *   preencher a chave nomeada e que, até lá, o CTA não é publicado;
 * - destino preenchido e no formato do regime é OK;
 * - destino PREENCHIDO e fora do formato é FALHA, porque aí o dado existe e
 *   está errado — o lead sairia para um destino que não recebe;
 * - entrada sem `destino` declarado é FALHA: defeito da própria entrada.
 */

$nome  = 'formulario.veredito_destino';
$casos = array(
	array( 'whatsapp', 'contato.whatsapp_e164', '', 'N/A', 'contato.whatsapp_e164', 'chave declarada e vazia é N/A, e não pré-condição pendente' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '   ', 'N/A', 'contato.whatsapp_e164', 'só espaço continua sendo vazio' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '5511900000000', 'OK', '', 'E.164 só com dígitos é aceito' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '+55 11 90000-0000', 'FALHA', 'PREENCHIDA', 'preenchido com pontuação é FALHA, não N/A' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '551', 'FALHA', 'PREENCHIDA', 'curto demais para E.164 é FALHA' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '5511900000000000000', 'FALHA', 'PREENCHIDA', 'longo demais para E.164 é FALHA' ),
	array( 'cf7-email', 'formularios.1.caixa_de_leads', '', 'N/A', 'formularios.1.caixa_de_leads', 'a mesma regra vale para o outro regime, e a chave dele mora DENTRO da entrada desde a 1.1.0' ),
	array( 'cf7-email', 'formularios.1.caixa_de_leads', 'leads@exemplo.test', 'OK', '', 'e-mail válido é aceito' ),
	array( 'cf7-email', 'formularios.1.caixa_de_leads', 'leads-arroba-exemplo', 'FALHA', 'PREENCHIDA', 'e-mail preenchido e inválido é FALHA' ),
	array( 'whatsapp', '', '5511900000000', 'FALHA', 'destino', 'entrada sem chave de destino é defeito da entrada, não pré-condição' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Lotes::veredito_destino( $caso[0], $caso[1], $caso[2] );

	if ( $veredito['estado'] !== $caso[3] ) {
		anotar( $nome, $caso[5] . ': esperado ' . $caso[3] . ', obtido ' . $veredito['estado'] );
		continue;
	}

	medir( $nome );

	if ( '' !== $caso[4] && ! str_contains( $veredito['motivo'], $caso[4] ) ) {
		anotar( $nome, $caso[5] . ': o motivo do ramo ' . $caso[3] . ' não menciona "' . $caso[4] . '"' );
	}

	medir( $nome );

	if ( '' === trim( $veredito['resumo'] ) ) {
		anotar( $nome, $caso[5] . ': ramo ' . $caso[3] . ' sem resumo para a linha da unidade' );
	}
}

/*
 * A MENSAGEM DO RAMO VAZIO diz as TRÊS coisas que o operador precisa, e a
 * terceira entrou na 1.1.0: que o CTA do modelo não é publicado, que um CTA cujo
 * destino alguém já trocou CONTINUA publicado, e o que fazer para o do modelo
 * existir. Sem a segunda, o operador leria "o CTA não é publicado" e procuraria
 * na página um botão que está lá — e a supressão cega que a frase descrevia era
 * justamente o que a 1.1.0 removeu.
 */
$vazio = F3Base_Imp_Lotes::veredito_destino( 'whatsapp', 'contato.whatsapp_e164', '' );

foreach ( array( 'condição de aplicabilidade falsa', 'destino do modelo não é publicado', 'continua publicado como está', 'canal MCP', 'em ' . F3Base_Imp_Projeto::ARQUIVO ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $vazio['motivo'], $trecho ) ) {
		anotar( $nome, 'ramo vazio: a mensagem do N/A não traz "' . $trecho . '" — ' . $vazio['motivo'] );
	}
}

/*
 * PISO DO ARQUIVO TROCADO: o destino dos regimes mora em `config/projeto.json`,
 * e esta mensagem dizia `config/site.json`, digitado à mão. Mandar preencher no
 * arquivo errado é pior que não dizer arquivo nenhum: o operador edita, nada
 * muda, e a linha volta igual na execução seguinte.
 */
medir( $nome );

if ( contem( $vazio['motivo'], F3Base_Imp_Config::ARQUIVO ) ) {
	anotar( $nome, 'ramo vazio: a mensagem manda preencher em ' . F3Base_Imp_Config::ARQUIVO . ', e a chave do destino mora em ' . F3Base_Imp_Projeto::ARQUIVO );
}

/*
 * PISO DO INTERRUPTOR: nenhuma entrada declarada pode trazer `ativo` de volta.
 * Ele é o segundo fato que discordava do primeiro, e o caminho de volta para o
 * defeito é justamente redeclará-lo ao lado do destino.
 */
foreach ( F3Base_Imp_Projeto::lista( 'formularios' ) as $indice_do_regime => $entrada_do_regime ) {
	medir( $nome );

	/*
	 * A entrada é lida como ESTRUTURA, e não pelo caminho pontilhado da chave
	 * removida: escrever o caminho aqui devolveria ao pacote justamente o
	 * literal que `estatica.sem_residuo_de_chave_removida` proíbe, e o piso da
	 * remoção estaria plantando o resíduo que ele existe para acusar.
	 */
	$chaves_do_regime = is_array( $entrada_do_regime ) ? array_keys( $entrada_do_regime ) : array();

	if ( in_array( 'ativo', $chaves_do_regime, true ) ) {
		anotar( $nome, 'piso do interruptor: a entrada ' . $indice_do_regime . ' voltou a declarar um interruptor ao lado do destino — dois fatos podendo discordar, que é exatamente o que a 1.0.19 desfez' );
	}
}

/* ---------- conteudo.politica_de_privacidade: identidade e interpolação ---------- */

/*
 * O QUE SAIU DAQUI NA 2.1.0, e por decisão do dono: a checagem
 * `privacidade.controlador_identificado` (BLOCKED quando razão social, CNPJ e
 * endereço do controlador estavam vazios) e a GUARDA que rebaixava a política a
 * rascunho por esses campos. O que a política afirma é responsabilidade de quem
 * responde por ela; o implantador é executado uma vez, e dado do operador é
 * preenchido antes ou ajustado depois pelo canal. O que FICA medido aqui é o
 * que continua sendo mecanismo do pacote: a IDENTIDADE da política (qual página
 * é, por papel declarado, e que o llms.txt não a silencia) e a INTERPOLAÇÃO dos
 * valores do controlador no texto — os marcadores existem no arquivo real, os
 * valores chegam ao conteúdo, e os blocos condicionais do encarregado fazem o
 * que declaram.
 */

$nome = 'conteudo.politica_de_privacidade';
$C    = 'F3Base_Imp_Conteudo';

/**
 * Valores do controlador, na forma de caminho => valor que o pacote usa.
 *
 * @param array<string,string> $mudanca O que este caso muda.
 * @return array<string,string>
 */
function f3b_controlador( array $mudanca = array() ): array {
	return $mudanca + array(
		'contato.controlador.razao_social' => 'Fator 3 Ventures Ltda.',
		'contato.controlador.documento'    => '00.000.000/0001-00',
		'contato.controlador.endereco'     => 'Rua da Medicao, 42, Sao Paulo, SP',
		'contato.controlador.encarregado'  => '',
	);
}

$completo = f3b_controlador();

/* TETO do status: a página publica com o status DECLARADO — nenhuma guarda de conteúdo rebaixa nada desde a 2.1.0. */
foreach ( array( 'privacidade', 'home' ) as $ref_de_status ) {
	medir( $nome );

	$status = $C::veredito_de_status_de_pagina( $ref_de_status, 'publish', 'privacidade', f3b_controlador( array( 'contato.controlador.razao_social' => '', 'contato.controlador.documento' => '', 'contato.controlador.endereco' => '' ) ) );

	if ( 'publish' !== $status['status'] ) {
		anotar( $nome, 'status: a página ' . $ref_de_status . ' com o controlador vazio saiu como "' . $status['status'] . '" — a guarda do controlador foi retirada na 2.1.0 e o status é o declarado; dado do operador não rebaixa página' );
	}
}

medir( $nome );

if ( 'draft' !== $C::veredito_de_status_de_pagina( 'privacidade', 'draft', 'privacidade', $completo )['status'] ) {
	anotar( $nome, 'status: uma página declarada "draft" saiu publicada — o status declarado é o único produtor' );
}

/* ---------- A IDENTIDADE da política: onde ela mora, e o que NÃO pode derrubá-la ---------- */

/*
 * O defeito da 1.0.13, dito por inteiro: a identidade da página de política era
 * lida de `seo.llms_selecao.politica_privacidade`. Matar o literal
 * `'privacidade' === $ref` estava certo; o destino estava errado. Quem
 * desligasse `bots_ia.llms_txt` e limpasse a seleção — operação legítima, que o
 * nome da chave convida a fazer — parava de gravar `wp_page_for_privacy_policy`
 * E derrubava esta checagem em "condição de aplicabilidade falsa". Uma chave de
 * SEO silenciava uma checagem exigida pelo art. 9º da LGPD, com o relatório
 * verde.
 *
 * O piso abaixo é o que o dono exigiu: com o llms.txt DESLIGADO e a seleção
 * VAZIA, a política continua identificada e `wp_page_for_privacy_policy`
 * continua sendo gravada.
 */

$paginas_do_projeto = array(
	array( 'ref' => 'home', 'papel' => '' ),
	array( 'ref' => 'contato', 'papel' => '' ),
	array( 'ref' => 'privacidade', 'papel' => 'politica-privacidade' ),
);

$casos_identidade = array(
	array( 'rotulo' => 'o papel declarado na entrada da página resolve a identidade', 'entradas' => $paginas_do_projeto, 'ref' => 'privacidade' ),
	array( 'rotulo' => 'nenhuma entrada com papel: projeto sem política declarada', 'entradas' => array( array( 'ref' => 'home', 'papel' => '' ) ), 'ref' => '' ),
	array( 'rotulo' => 'papel declarado com ref vazia não inventa referência', 'entradas' => array( array( 'ref' => '', 'papel' => 'politica-privacidade' ) ), 'ref' => '' ),
	array( 'rotulo' => 'entrada que não é array não derruba a resolução', 'entradas' => array( 'lixo', array( 'ref' => 'p', 'papel' => 'politica-privacidade' ) ), 'ref' => 'p' ),
	array( 'rotulo' => 'papel de outro valor não casa', 'entradas' => array( array( 'ref' => 'x', 'papel' => 'outro-papel' ) ), 'ref' => '' ),
);

foreach ( $casos_identidade as $caso ) {
	medir( $nome );

	$obtido = $C::ref_da_politica_em( $caso['entradas'] );

	if ( $obtido !== $caso['ref'] ) {
		anotar( $nome, $caso['rotulo'] . ': esperado "' . $caso['ref'] . '", obtido "' . $obtido . '"' );
	}
}

/*
 * O PISO DO DONO. As entradas de página de um projeto que desligou o llms.txt
 * são EXATAMENTE as mesmas — o papel não mora lá —, e é isso que a resolução
 * prova. A proibição estática que sustenta a prova está em
 * `estatica.politica_privacidade_fonte_unica`, cláusula 3: o produtor não pode
 * ler caminho fora de `paginas.*`.
 */

$ref_com_llms_desligado = $C::ref_da_politica_em( $paginas_do_projeto );

medir( $nome );

if ( 'privacidade' !== $ref_com_llms_desligado ) {
	anotar( $nome, 'llms.txt desligado e seleção vazia: a identidade da política deixou de resolver — foi exatamente esse o defeito da 1.0.13' );
}

medir( $nome );

if ( ! $C::grava_pagina_de_privacidade( $ref_com_llms_desligado, 'privacidade', 12 ) ) {
	anotar( $nome, 'llms.txt desligado e seleção vazia: wp_page_for_privacy_policy deixaria de ser gravada' );
}

medir( $nome );

if ( $C::grava_pagina_de_privacidade( $ref_com_llms_desligado, 'contato', 12 ) ) {
	anotar( $nome, 'wp_page_for_privacy_policy seria gravada apontando para uma página que não é a política' );
}

medir( $nome );

if ( $C::grava_pagina_de_privacidade( $ref_com_llms_desligado, 'privacidade', 0 ) ) {
	anotar( $nome, 'wp_page_for_privacy_policy seria gravada com ID zero: option apontando para objeto que não existe' );
}

medir( $nome );

if ( $C::grava_pagina_de_privacidade( '', 'privacidade', 12 ) ) {
	anotar( $nome, 'sem política declarada, wp_page_for_privacy_policy seria gravada assim mesmo' );
}

/* E a configuração REAL: o papel está declarado, e o caminho aposentado sumiu. */

medir( $nome );

if ( 'privacidade' !== $C::ref_da_politica_de_privacidade() ) {
	anotar( $nome, 'a configuração deste pacote não declara papel = "politica-privacidade" em nenhuma entrada de paginas: a identidade da política ficou sem produtor' );
}

medir( $nome );

$config_bruta = (array) json_decode( (string) file_get_contents( $raiz . '/config/site.json' ), true );

if ( array_key_exists( 'politica_privacidade', (array) ( $config_bruta['seo']['llms_selecao'] ?? array() ) ) ) {
	anotar( $nome, 'seo.llms_selecao ainda declara "politica_privacidade": a seleção do llms.txt voltou a POSSUIR o fato em vez de referenciar o produtor' );
}

/* A INTERPOLAÇÃO no arquivo REAL da política: o teto que prova o caminho todo. */

$ref_politica = $C::ref_da_politica_de_privacidade();
$arquivo_pol  = $raiz . '/content/pages/' . $ref_politica . '.html';

medir( $nome );

if ( '' === $ref_politica || ! is_file( $arquivo_pol ) ) {
	anotar( $nome, 'a configuração declara a política em "' . $ref_politica . '" e não há content/pages/' . $ref_politica . '.html para interpolar' );
} else {
	$bruto = (string) file_get_contents( $arquivo_pol );

	medir( $nome );

	if ( ! contem( $bruto, '%f3base:contato.controlador.razao_social%' ) ) {
		anotar( $nome, 'o arquivo da política não carrega o marcador da razão social: sem marcador a interpolação não tem onde escrever, e a página publicaria sem identificar o controlador' );
	}

	$com_encarregado = f3b_controlador( array( 'contato.controlador.encarregado' => 'Maria da Medicao' ) );
	$interpolado     = $C::interpolar_com( $bruto, $com_encarregado );

	foreach ( $com_encarregado as $caminho => $valor ) {
		medir( $nome );

		if ( '' !== $valor && ! contem( $interpolado, esc_html( $valor ) ) ) {
			anotar( $nome, 'interpolação: o valor de ' . $caminho . ' não chegou ao conteúdo produzido' );
		}
	}

	medir( $nome );

	if ( contem( $interpolado, $C::MARCA_ABRE ) ) {
		anotar( $nome, 'interpolação: sobrou marcador não resolvido no conteúdo produzido com todos os valores preenchidos' );
	}

	medir( $nome );

	if ( contem( $interpolado, 'Nenhum encarregado é nomeado' ) ) {
		anotar( $nome, 'bloco condicional: com encarregado preenchido, a redação que diz que não há encarregado continuou no conteúdo — as duas afirmações contraditórias na mesma página' );
	}

	$sem_encarregado = $C::interpolar_com( $bruto, f3b_controlador() );

	medir( $nome );

	if ( ! contem( $sem_encarregado, 'Nenhum encarregado é nomeado' ) ) {
		anotar( $nome, 'bloco condicional: com encarregado vazio, a redação que explica quem recebe os pedidos sumiu do conteúdo' );
	}

	medir( $nome );

	if ( contem( $sem_encarregado, 'art. 41 da LGPD, é ' ) ) {
		anotar( $nome, 'bloco condicional: com encarregado vazio, a redação nominal continuou no conteúdo e o pacote estaria inventando um encarregado' );
	}

	medir( $nome );

	if ( contem( $sem_encarregado, $C::MARCA_ABRE ) ) {
		anotar( $nome, 'interpolação: sobrou marcador não resolvido no conteúdo produzido com o encarregado vazio' );
	}

	/* Ponta a ponta: o arquivo do pacote, interpolado, satisfaz a leitura de volta. */
}

/* ---------- relatorio.nomeia_o_que_nao_fecha_ok: o defeito 1, medido ---------- */

/*
 * O defeito, dito por inteiro: o cabeçalho do log de 1.0.6 dizia "checagens do
 * relatório: 5 FALHA e 6 BLOCKED" e as linhas renderizadas mostravam UMA
 * unidade em FALHA. As outras rodavam DENTRO de unidades que fecharam OK — em
 * `etapa_preflight`, por exemplo, o veredito de cada checagem interna é
 * descartado e a unidade devolve OK a menos que a medição inteira esteja
 * bloqueada. O operador ficava com um número e nenhum nome.
 *
 * O que esta sonda prova: uma FALHA emitida DENTRO de uma unidade que fecha OK
 * sai NOMEADA — no recorte que a resposta do lote carrega para a tela, na
 * lista por estado e no resumo com contagem. E que o estado OK continua
 * resumido, que é a outra metade da regra.
 */

$nome = 'relatorio.nomeia_o_que_nao_fecha_ok';

F3Base_Imp_Relatorio::zerar();

$marca_da_unidade = F3Base_Imp_Relatorio::marcar();

F3Base_Imp_Relatorio::emitir( 'OK', 'preflight.disco', 'espaço suficiente.', array( 'evidencia' => 'medida', 'fase' => 'local' ) );
F3Base_Imp_Relatorio::emitir( 'FALHA', 'preflight.saida_https', 'a saída HTTPS não respondeu.', array( 'evidencia' => 'teste-funcional', 'fase' => 'local' ) );
F3Base_Imp_Relatorio::emitir( 'WARN', 'preflight.limites', 'memory_limit apertado.', array( 'evidencia' => 'medida', 'fase' => 'local' ) );

$internas = F3Base_Imp_Relatorio::desde( $marca_da_unidade );

/* A unidade fecha OK — e é justamente esse o caso que escondia as outras. */
F3Base_Imp_Relatorio::emitir_unidade( 'OK', 'preflight', 'preflight completo.', array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local' ) );

medir( $nome );

if ( 3 !== count( $internas ) ) {
	anotar( $nome, 'teto: o recorte da unidade devolveu ' . count( $internas ) . ' checagem(ns) internas, e não as 3 emitidas' );
}

$nomeadas = array();

foreach ( $internas as $interna ) {
	if ( 'OK' !== $interna['estado'] ) {
		$nomeadas[] = (string) $interna['nome'];
	}
}

medir( $nome );

if ( array( 'preflight.saida_https', 'preflight.limites' ) !== $nomeadas ) {
	anotar( $nome, 'teto: o que não fechou OK dentro da unidade precisa sair nomeado e saiu: ' . implode( ', ', $nomeadas ) );
}

$nomes_checagens = F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' );
$nomes_unidades  = F3Base_Imp_Relatorio::nomes_por_estado( 'unidades' );

medir( $nome );

if ( array( 'preflight.saida_https' ) !== $nomes_checagens['FALHA'] ) {
	anotar( $nome, 'piso: a lista de FALHA do escopo checagens não nomeia a checagem interna: ' . implode( ', ', $nomes_checagens['FALHA'] ) );
}

medir( $nome );

if ( array( 'preflight.limites' ) !== $nomes_checagens['WARN'] ) {
	anotar( $nome, 'piso: a lista de WARN do escopo checagens não nomeia a checagem interna' );
}

medir( $nome );

if ( array( 'preflight' ) !== $nomes_unidades['OK'] || array() !== $nomes_unidades['FALHA'] ) {
	anotar( $nome, 'piso: os dois escopos se misturaram — a unidade fechou OK e o escopo de unidades precisa dizer só isso' );
}

$resumo = F3Base_Imp_Relatorio::resumo_por_estado( F3Base_Imp_Relatorio::contagem(), $nomes_checagens );

medir( $nome );

if ( ! str_contains( $resumo, 'preflight.saida_https' ) || ! str_contains( $resumo, 'preflight.limites' ) ) {
	anotar( $nome, 'piso: o resumo por estado conta e NÃO nomeia — é o defeito de volta' );
}

medir( $nome );

if ( str_contains( $resumo, 'preflight.disco' ) ) {
	anotar( $nome, 'teto: checagem OK saiu nomeada no resumo; a regra é que OK fica resumido' );
}

medir( $nome );

if ( ! str_contains( $resumo, 'OK: 2' ) ) {
	anotar( $nome, 'teto: o resumo perdeu a contagem de OK — a lista de nomes não substitui o número, ela acompanha' );
}

F3Base_Imp_Relatorio::zerar();

/* ---------- entrega.rodada_limpa_confere: teto e piso dos DOIS lados ---------- */

/*
 * A rodada limpa é fato da SUÍTE EXTERNA e não roda no host. Antes desta
 * release ela era tratada como entregável em BLOCKED, e como o host nunca pode
 * produzi-la, ela proibia a autodesativação PARA SEMPRE, em toda instalação,
 * por desenho. A separação é a correção; o que esta sonda prova é que o novo
 * caminho de fechamento existe de verdade, nos dois ramos:
 *
 * - registro com o hash CERTO precisa fechar OK, com classe `importada` e fase
 *   `build` — jamais "medida", jamais fase "producao";
 * - registro com hash DIVERGENTE precisa ser acusado NOMEANDO os dois hashes;
 * - registro AUSENTE precisa ser acusado, e nenhum dos dois pode segurar a
 *   autodesativação.
 */

$nome = 'entrega.rodada_limpa_confere';

$hash_certo    = str_repeat( 'a', 64 );
$hash_alheio   = str_repeat( 'b', 64 );

/*
 * O REGISTRO DECLARA O VEREDITO desde a 1.0.18, e o leitor o LÊ além do hash.
 * Sem esse campo, o conteúdo abaixo é o da 1.0.17: hash batendo e nada mais,
 * que era o pacote se aprovando pelo arquivo que ele mesmo escreveu.
 */
$registro_limpo = array(
	'veredito'           => 'sem-falha-e-sem-pendencia',
	'falhas'             => 0,
	'pendencias_de_fase' => array(),
);

$registro_com_pendencia = array(
	'veredito'           => 'sem-falha-com-pendencia-de-fase',
	'falhas'             => 0,
	'pendencias_de_fase' => array( 'mcp.canal_configurado', 'orcamento.pagina' ),
);

/* Ramo 1: registro presente e casado. */
medir( $nome );
$veredito = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_certo, $hash_certo, $registro_limpo );

if ( 'OK' !== $veredito['estado'] ) {
	anotar( $nome, 'teto: hash igual não fechou OK, e sim ' . $veredito['estado'] );
}

medir( $nome );

if ( 'importada' !== $veredito['evidencia'] ) {
	anotar( $nome, 'teto: o ramo OK precisa sair com classe de evidência "importada" e saiu com "' . $veredito['evidencia'] . '"' );
}

medir( $nome );

if ( 'build' !== $veredito['fase'] ) {
	anotar( $nome, 'teto: o ramo OK precisa sair na fase "build" e saiu na fase "' . $veredito['fase'] . '"' );
}

medir( $nome );

if ( ! str_contains( $veredito['motivo'], $hash_certo ) ) {
	anotar( $nome, 'teto: o ramo OK não nomeia o hash conferido' );
}

/* Ramo 2: registro presente e divergente — o piso. */
medir( $nome );
$divergente = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_alheio, $hash_certo, $registro_limpo );

if ( 'BLOCKED' !== $divergente['estado'] ) {
	anotar( $nome, 'piso: hash divergente não foi acusado; fechou ' . $divergente['estado'] );
}

medir( $nome );

if ( ! str_contains( $divergente['motivo'], $hash_alheio ) || ! str_contains( $divergente['motivo'], $hash_certo ) ) {
	anotar( $nome, 'piso: o BLOCKED de hash divergente precisa nomear o esperado E o encontrado' );
}

medir( $nome );

if ( 'medida' === $divergente['evidencia'] || 'producao' === $divergente['fase'] ) {
	anotar( $nome, 'piso: evidência importada não pode sair como "medida" nem na fase "producao"' );
}

/* Ramo 3: registro sem o campo de hash. */
medir( $nome );
$sem_campo = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, '', $hash_certo, $registro_limpo );

if ( 'BLOCKED' !== $sem_campo['estado'] ) {
	anotar( $nome, 'piso: registro sem hash_pacote não foi acusado; fechou ' . $sem_campo['estado'] );
}

/* Ramo 4: registro ausente. */
medir( $nome );
$ausente = F3Base_Imp_Entrega::veredito_da_rodada_limpa( false, '', $hash_certo, array() );

if ( 'BLOCKED' !== $ausente['estado'] ) {
	anotar( $nome, 'piso: registro ausente não foi acusado; fechou ' . $ausente['estado'] );
}

medir( $nome );

if ( ! str_contains( $ausente['motivo'], F3Base_Imp_Entrega::REGISTRO_RODADA ) ) {
	anotar( $nome, 'piso: o BLOCKED de registro ausente não nomeia o caminho que falta' );
}

/*
 * Ramo 5 — O PISO DA 1.0.18: hash batendo NÃO basta. O registro que não declara
 * veredito é o registro da 1.0.17, e aprová-lo pelo hash era o pacote se
 * aprovando pelo arquivo que ele mesmo escreveu.
 */
medir( $nome );
$sem_veredito = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_certo, $hash_certo, array( 'hash_pacote' => $hash_certo ) );

if ( 'BLOCKED' !== $sem_veredito['estado'] ) {
	anotar( $nome, 'piso: registro com hash certo e SEM veredito declarado fechou ' . $sem_veredito['estado'] . ' — hash igual prova que a rodada mediu este pacote, e não diz o que ela achou' );
}

medir( $nome );

if ( ! contem( $sem_veredito['motivo'], 'NÃO declara veredito' ) ) {
	anotar( $nome, 'piso: a recusa do registro sem veredito não diz o que falta nele' );
}

/* Ramo 6: registro que declara FALHA não amarra entrega nenhuma. */
medir( $nome );
$com_falha = F3Base_Imp_Entrega::veredito_da_rodada_limpa(
	true,
	$hash_certo,
	$hash_certo,
	array( 'veredito' => 'com-falha', 'falhas' => 3, 'pendencias_de_fase' => array() )
);

if ( 'BLOCKED' !== $com_falha['estado'] ) {
	anotar( $nome, 'piso: registro declarando 3 FALHA fechou ' . $com_falha['estado'] );
}

medir( $nome );

if ( ! str_contains( $com_falha['motivo'], '3 checagem' ) ) {
	anotar( $nome, 'piso: a recusa do registro com FALHA não nomeia quantas' );
}

/*
 * Ramo 7 — o que a 1.0.17 escondia no NOME do arquivo: hash batendo, zero
 * FALHA e pendências dentro fecha OK, e as pendências saem NOMEADAS. O host não
 * pode afirmar mais do que a rodada mediu.
 */
$com_pendencia = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_certo, $hash_certo, $registro_com_pendencia );

medir( $nome );

if ( 'OK' !== $com_pendencia['estado'] ) {
	anotar( $nome, 'teto: rodada sem FALHA e com pendência de fase declarada fechou ' . $com_pendencia['estado'] . ' — pendência de fase não é FALHA' );
}

foreach ( array( 'mcp.canal_configurado', 'orcamento.pagina', 'NOMEADA', 'rodada limpa' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $com_pendencia['motivo'], $trecho ) ) {
		anotar( $nome, 'teto: o OK com pendências não traz "' . $trecho . '" — contar sem nomear é o que o nome do arquivo antigo escondia' );
	}
}

/* ---------- entrega.gates_separados: o gate de fase NÃO decide a autodesativação ---------- */

$nome = 'entrega.gates_separados';

$do_gate = F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao();

/*
 * A LISTA DO GATE DE FASE SAI DO METADADO desde a 1.0.18, e é por isso que este
 * bloco EMITE antes de perguntar: até a 1.0.17 havia uma lista literal com UM
 * nome do lado de cá e o metadado `gate` com DOIS emissores do lado de lá, e o
 * log imprimia as duas fontes dentro da mesma linha, discordando. Emitir aqui é
 * o que prova a derivação: o nome entra na lista porque a linha o declarou, não
 * porque alguém o escreveu numa segunda lista.
 */
F3Base_Imp_Relatorio::zerar();

F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::BLOCKED,
	'entrega.rodada_limpa',
	'linha de fase da bancada',
	array( 'evidencia' => 'pendencia-externa', 'fase' => 'build', 'gate' => 'fase' )
);

F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::BLOCKED,
	'orcamento.medicao_de_pagina',
	'segunda linha de fase da bancada',
	array( 'evidencia' => 'pendencia-externa', 'fase' => 'campo', 'gate' => 'fase' )
);

F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::OK,
	'entrega.tema',
	'linha de aplicação da bancada',
	array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local', 'gate' => 'aplicacao' )
);

/*
 * A LINHA SEM GATE DECLARADO É DE FASE, e este é o piso da inversão que a 1.3.1
 * fez. Até a 1.3.0 a ausência de `gate` significava APLICAÇÃO: qualquer linha
 * que ninguém tivesse classificado podia reprovar a unidade e suspender tudo
 * que dependesse dela. Foi assim que `preflight.baseline` — uma linha que só
 * relatava os plugins já instalados no site — suspendeu 39 unidades e deixou um
 * site sem tema, sem plugins e sem conteúdo.
 *
 * Para IMPEDIR a instalação, a checagem passou a ter de dizer que impede.
 */
F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::OK,
	'bancada.sem_gate_declarado',
	'linha sem gate declarado da bancada',
	array( 'evidencia' => 'analise-estatica', 'fase' => 'build' )
);

medir( $nome );

if ( in_array( 'bancada.sem_gate_declarado', F3Base_Imp_Relatorio::nomes_com_gate( F3Base_Imp_Relatorio::GATE_APLICACAO ), true ) ) {
	anotar( $nome, 'piso da inversão: linha SEM gate declarado caiu no gate de APLICAÇÃO — é o defeito que deixou um site inteiro sem instalação, e a porta que se abre por esquecimento tem de ser a inofensiva' );
}

medir( $nome );

if ( ! in_array( 'bancada.sem_gate_declarado', F3Base_Imp_Relatorio::nomes_com_gate( F3Base_Imp_Relatorio::GATE_RELATO ), true ) ) {
	anotar( $nome, 'teto da inversão: linha sem gate declarado não caiu no gate de RELATO — ela precisa cair em ALGUM lugar, ou some do relatório' );
}

medir( $nome );

if ( in_array( 'bancada.sem_gate_declarado', F3Base_Imp_Relatorio::nomes_com_gate( F3Base_Imp_Relatorio::GATE_FASE ), true ) ) {
	anotar( $nome, 'piso da 1.7.3: linha sem gate declarado voltou a cair no gate de FASE — e é sobre cada nome dessa lista que o relatório afirma que ESTE HOST NÃO PRODUZ a evidência, o que é falso de toda linha que ninguém classificou' );
}

$de_fase = F3Base_Imp_Entrega::gates_de_fase();

medir( $nome );

if ( 9 !== count( $do_gate ) ) {
	anotar( $nome, 'teto: o gate de aplicação precisa listar os NOVE entregáveis (os quatro de conteúdo e os cinco de artefato, com a documentação desde a 2.1.0) e lista ' . count( $do_gate ) );
}

medir( $nome );

if ( in_array( 'entrega.rodada_limpa', $do_gate, true ) ) {
	anotar( $nome, 'piso: entrega.rodada_limpa continua dentro do gate de aplicação — o gate volta a ser insatisfazível no host' );
}

medir( $nome );

if ( ! in_array( 'entrega.rodada_limpa', $de_fase, true ) ) {
	anotar( $nome, 'piso: entrega.rodada_limpa saiu do gate de aplicação e não entrou no gate de fase — evidência externa não pode simplesmente sumir' );
}

/* TETO da derivação: o SEGUNDO emissor de gate=fase entra sem que ninguém o declare. */
medir( $nome );

if ( ! in_array( 'orcamento.medicao_de_pagina', $de_fase, true ) ) {
	anotar( $nome, 'teto: o segundo emissor de gate=fase não entrou na lista derivada — era exatamente ele que a lista literal da 1.0.17 não continha, e a divergência saía impressa dentro de uma linha só do log' );
}

/* PISO da derivação: gate de aplicação e gate ausente NÃO entram na lista de fase. */
foreach ( array( 'entrega.tema' ) as $fora ) {
	medir( $nome );

	if ( in_array( $fora, $de_fase, true ) ) {
		anotar( $nome, 'piso: ' . $fora . ' entrou na lista de gates de fase sem ter declarado gate=fase — gate ausente conta como aplicação, e a ausência não pode ser o caminho barato para escapar do gate' );
	}
}

/* A nota de fase NOMEIA o escopo que resume: foi a falta disso que fez as duas frases parecerem contraditórias. */
$nota = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, array() )['motivo'];

medir( $nome );

if ( ! contem( $nota, 'derivados do metadado' ) ) {
	anotar( $nome, 'teto: a nota de fase não declara de onde a lista sai — sem o escopo nomeado, "nenhuma pendência de fase em aberto" e "pendência de FASE dentro desta unidade" continuam parecendo contradição na mesma linha' );
}

/* Mapa de uma execução em que TUDO fecha, menos a evidência importada. */
$mapa_bom = array( 'entrega.rodada_limpa' => 'BLOCKED' );

foreach ( $do_gate as $entregavel ) {
	$mapa_bom[ $entregavel ] = 'OK';
}

foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
	$mapa_bom[ $gate ] = 'OK';
}

medir( $nome );
$decisao = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_bom );

if ( true !== $decisao['pode'] ) {
	anotar( $nome, 'teto: com SUCESSO_APLICACAO, entregáveis e canal em OK, a rodada limpa em BLOCKED continuou proibindo a autodesativação — o gate segue insatisfazível' );
}

medir( $nome );

if ( ! str_contains( $decisao['motivo'], 'entrega.rodada_limpa' ) ) {
	anotar( $nome, 'teto: a pendência de fase precisa aparecer NOMEADA no motivo, e não aparece — ignorar a evidência externa é a outra metade do erro' );
}

/* ---------- N/A NÃO É PENDÊNCIA DE FASE: os dois consumidores, medidos ---------- */

/*
 * O DEFEITO QUE A 1.1.6 PODIA CRIAR, e por isso ele tem piso nos DOIS lugares
 * que consultam `gates_de_fase()`. Os dois escreviam `OK !== $estado`, e a regra
 * de aplicabilidade fez surgir um terceiro estado nessas linhas: o N/A. Sem esta
 * correção, o encerramento imprimiria **"pendência de fase (N/A)"** — que é a
 * confusão entre aplicabilidade e pendência que esta release existe para
 * eliminar, um andar abaixo.
 *
 * E há o piso ao contrário, que é o que impede a correção de virar cegueira: uma
 * linha de fase em BLOCKED **continua** sendo pendência, e a nota **não pode**
 * dizer "nenhuma pendência de fase em aberto" quando existe uma. Essa
 * contradição foi medida na 1.0.17 e a 1.1.6 podia reabri-la por outro caminho.
 */

/* CONSUMIDOR 1 — `F3Base_Imp_Entrega::pode_autodesativar()`. */

/*
 * O MAPA COBRE TODA LINHA DE FASE DECLARADA, e não uma lista escrita à mão.
 * Depois que o gate padrão virou FASE, qualquer linha nova sem gate declarado
 * entra nesta contagem — e uma linha que o mapa não conhecesse seria lida como
 * pendência, fazendo a bancada acusar um defeito que não existe.
 */
$mapa_na = array( 'entrega.rodada_limpa' => 'N/A', 'orcamento.medicao_de_pagina' => 'N/A' );

foreach ( F3Base_Imp_Entrega::gates_de_fase() as $de_fase_declarado ) {
	if ( ! isset( $mapa_na[ $de_fase_declarado ] ) ) {
		$mapa_na[ $de_fase_declarado ] = 'OK';
	}
}

foreach ( $do_gate as $entregavel ) {
	$mapa_na[ $entregavel ] = 'OK';
}

foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
	$mapa_na[ $gate ] = 'OK';
}

$decisao_na = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_na );

medir( $nome );

if ( contem( $decisao_na['motivo'], 'em aberto, declarado' ) ) {
	anotar( $nome, 'piso: linha de fase em N/A foi CONTADA como gate de fase em aberto — N/A é condição de aplicabilidade falsa, e não há pendência de ninguém ali' );
}

foreach ( array( 'entrega.rodada_limpa (N/A)', 'orcamento.medicao_de_pagina (N/A)' ) as $rotulo_na ) {
	medir( $nome );

	if ( str_contains( $decisao_na['motivo'], $rotulo_na ) ) {
		anotar( $nome, 'piso: a nota NOMEOU "' . $rotulo_na . '" como pendência — nomear um N/A como pendente é imprimir a contradição em termos que a 1.1.6 existe para tirar do relatório' );
	}
}

medir( $nome );

if ( ! contem( $decisao_na['motivo'], 'Nenhum GATE DE FASE em aberto' ) ) {
	anotar( $nome, 'teto: com todas as linhas de fase em N/A a nota precisa dizer que nenhum gate de fase está em aberto, e não diz' );
}

/*
 * PISO AO CONTRÁRIO — e é o que o roteiro desta parte pediu para conferir: com
 * uma em N/A e OUTRA em BLOCKED, a nota não pode dizer "nenhuma".
 */
$mapa_misto = $mapa_na;
$mapa_misto['entrega.rodada_limpa'] = 'BLOCKED';

$decisao_misto = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_misto );

medir( $nome );

if ( contem( $decisao_misto['motivo'], 'Nenhum GATE DE FASE em aberto' ) ) {
	anotar( $nome, 'piso: existe uma linha de fase em BLOCKED e a nota disse que nenhum gate de fase está em aberto — é a contradição medida na 1.0.17 reaberta pelo outro lado' );
}

medir( $nome );

if ( ! str_contains( $decisao_misto['motivo'], 'entrega.rodada_limpa (BLOCKED)' ) ) {
	anotar( $nome, 'piso: a linha de fase em BLOCKED deixou de sair NOMEADA ao lado de uma em N/A — tirar o N/A do conjunto não pode levar o BLOCKED junto' );
}

medir( $nome );

if ( str_contains( $decisao_misto['motivo'], 'orcamento.medicao_de_pagina (N/A)' ) ) {
	anotar( $nome, 'piso: com uma pendência real na lista, o N/A voltou a ser nomeado junto — a lista precisa conter só o que está em aberto' );
}

/* CONSUMIDOR 2 — `F3Base_Imp_Lotes::nota_de_pendencias_de_fase()`, a função pura da etapa de entrega. */

$gates_da_bancada = array( 'entrega.rodada_limpa', 'orcamento.medicao_de_pagina', 'fases.registro_de_execucao' );

$so_na = F3Base_Imp_Lotes::nota_de_pendencias_de_fase(
	array(
		'entrega.rodada_limpa'        => 'OK',
		'orcamento.medicao_de_pagina' => 'N/A',
		'fases.registro_de_execucao'  => 'OK',
	),
	$gates_da_bancada
);

medir( $nome );

if ( array() !== $so_na['pendencias'] ) {
	anotar( $nome, 'piso: a etapa de entrega contou ' . wp_json_encode( $so_na['pendencias'] ) . ' como pendência de fase, e ali só havia OK e N/A' );
}

medir( $nome );

if ( ! contem( $so_na['nota'], 'Nenhuma pendência de fase em aberto' ) ) {
	anotar( $nome, 'teto: sem pendência nenhuma a etapa de entrega precisa dizer isso com todas as letras, e disse: ' . $so_na['nota'] );
}

$misto = F3Base_Imp_Lotes::nota_de_pendencias_de_fase(
	array(
		'entrega.rodada_limpa'        => 'BLOCKED',
		'orcamento.medicao_de_pagina' => 'N/A',
		'fases.registro_de_execucao'  => 'WARN',
	),
	$gates_da_bancada
);

medir( $nome );

if ( contem( $misto['nota'], 'Nenhuma pendência de fase em aberto' ) ) {
	anotar( $nome, 'piso: a etapa de entrega disse "nenhuma pendência de fase em aberto" com uma linha em BLOCKED na mesma execução' );
}

medir( $nome );

if ( ! in_array( 'entrega.rodada_limpa', $misto['pendencias'], true ) ) {
	anotar( $nome, 'piso: a linha de fase em BLOCKED saiu da lista de pendências da etapa de entrega — BLOCKED de fase continua sendo pendência' );
}

medir( $nome );

if ( in_array( 'orcamento.medicao_de_pagina', $misto['pendencias'], true ) ) {
	anotar( $nome, 'piso: a linha de fase em N/A entrou na lista de pendências da etapa de entrega' );
}

medir( $nome );

if ( ! str_contains( $misto['nota'], 'entrega.rodada_limpa (BLOCKED)' ) ) {
	anotar( $nome, 'teto: a pendência da etapa de entrega precisa sair NOMEADA e COM O ESTADO, e saiu: ' . $misto['nota'] );
}

/* ESTADO AUSENTE CONTINUA SENDO PENDÊNCIA: linha que ninguém emitiu não respondeu nada. */
$sem_estado = F3Base_Imp_Lotes::nota_de_pendencias_de_fase( array(), array( 'entrega.rodada_limpa' ) );

medir( $nome );

if ( array( 'entrega.rodada_limpa' ) !== $sem_estado['pendencias'] ) {
	anotar( $nome, 'piso: gate de fase sem estado lido saiu do conjunto de pendências — tratar ausência como resolução é a aprovação por omissão de novo' );
}

/* CONSUMIDOR 3 — a nota da UNIDADE, pela mesma regra e no mesmo lugar. */

$internas_de_fase = array(
	array( 'nome' => 'bancada.fase_na',      'estado' => 'N/A',     'gate' => 'fase' ),
	array( 'nome' => 'bancada.fase_ok',      'estado' => 'OK',      'gate' => 'fase' ),
	array( 'nome' => 'bancada.fase_blocked', 'estado' => 'BLOCKED', 'gate' => 'fase' ),
);

$unidade_de_fase = F3Base_Imp_Lotes::veredito_da_unidade( 'OK', $internas_de_fase );

medir( $nome );

if ( in_array( 'bancada.fase_na (N/A)', $unidade_de_fase['pendencias_de_fase'], true ) ) {
	anotar( $nome, 'piso: a nota da unidade listou uma interna de fase em N/A como pendência — a regra é a mesma dos outros dois consumidores' );
}

medir( $nome );

if ( in_array( 'bancada.fase_ok (OK)', $unidade_de_fase['pendencias_de_fase'], true ) ) {
	anotar( $nome, 'piso: a nota da unidade listou uma interna de fase em OK como pendência' );
}

medir( $nome );

if ( ! in_array( 'bancada.fase_blocked (BLOCKED)', $unidade_de_fase['pendencias_de_fase'], true ) ) {
	anotar( $nome, 'piso: a interna de fase em BLOCKED saiu da nota da unidade — a correção do N/A não pode levar o BLOCKED junto' );
}

medir( $nome );

if ( 'OK' !== $unidade_de_fase['estado'] ) {
	anotar( $nome, 'teto: interna de gate de FASE promoveu o veredito da unidade para ' . $unidade_de_fase['estado'] . ' — evidência que este host não produz não decide' );
}

/* PISO do caminho de falha: com entregável ausente, o implantador permanece ativo. */
medir( $nome );
$mapa_ruim = $mapa_bom;
$mapa_ruim[ $do_gate[0] ] = 'BLOCKED';
$decisao_ruim = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_ruim );

if ( false !== $decisao_ruim['pode'] ) {
	anotar( $nome, 'piso: entregável do gate de aplicação em BLOCKED deixou de impedir a autodesativação' );
}

medir( $nome );

if ( ! str_contains( $decisao_ruim['motivo'], $do_gate[0] ) ) {
	anotar( $nome, 'piso: o motivo da recusa não nomeia o entregável em BLOCKED' );
}

/* PISO do caminho de falha: sem SUCESSO_APLICACAO, o implantador permanece ativo. */
medir( $nome );
$decisao_falha = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::FALHA_PARCIAL, $mapa_bom );

if ( false !== $decisao_falha['pode'] ) {
	anotar( $nome, 'piso: FALHA_PARCIAL deixou de impedir a autodesativação' );
}

/* PISO do caminho de falha: canal em aberto mantém o implantador ativo. */
medir( $nome );
$mapa_canal = $mapa_bom;
$mapa_canal['mcp.canal_exposto'] = 'BLOCKED';
$decisao_canal = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_canal );

if ( false !== $decisao_canal['pode'] ) {
	anotar( $nome, 'piso: canal não exposto deixou de impedir a autodesativação' );
}

medir( $nome );

if ( ! str_contains( $decisao_canal['motivo'], 'mcp.canal_exposto' ) ) {
	anotar( $nome, 'piso: a recusa por canal em aberto não nomeia o veredito que ficou fora de OK' );
}

/*
 * PISO do caminho de falha, continuação da 1.0.8: com A, B, C e D corrigidos, a
 * execução seguinte fecha sem FALHA e a autodesativação passa a acontecer. É
 * exatamente aí que o caminho de falha precisa continuar provado — senão a
 * correção que destrava o gate é a mesma que o desliga.
 */

/* FALHA de verdade no estado da aplicação: o implantador permanece ativo. */
medir( $nome );
$decisao_estado_falha = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::FALHA, $mapa_bom );

if ( false !== $decisao_estado_falha['pode'] ) {
	anotar( $nome, 'piso: o estado FALHA deixou de impedir a autodesativação' );
}

medir( $nome );

if ( ! str_contains( $decisao_estado_falha['motivo'], F3Base_Imp_Lotes::FALHA ) ) {
	anotar( $nome, 'piso: a recusa por estado FALHA não nomeia o estado observado' );
}

/* Canal CONFIGURADO em aberto: o outro veredito de canal também segura. */
medir( $nome );
$mapa_configurado = $mapa_bom;
$mapa_configurado['mcp.canal_configurado'] = 'BLOCKED';
$decisao_configurado = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_configurado );

if ( false !== $decisao_configurado['pode'] ) {
	anotar( $nome, 'piso: canal não configurado deixou de impedir a autodesativação' );
}

/* Cada entregável do gate, um a um: nenhum deles pode ter deixado de segurar. */
foreach ( $do_gate as $entregavel ) {
	medir( $nome );

	$mapa_um             = $mapa_bom;
	$mapa_um[ $entregavel ] = 'BLOCKED';
	$decisao_um          = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_um );

	if ( false !== $decisao_um['pode'] || ! str_contains( $decisao_um['motivo'], $entregavel ) ) {
		anotar( $nome, 'piso: o entregável ' . $entregavel . ' em BLOCKED não impediu a autodesativação, ou não foi nomeado na recusa' );
	}
}

/*
 * O ESTADO DA UNIDADE NÃO DECIDE O GATE, e desde a 1.0.9 isso precisa estar
 * provado: a unidade `entrega` passou a REFLETIR as checagens que emite, e uma
 * delas — `orcamento.medicao_de_pagina`, evidência de navegador que este host
 * não produz — é BLOCKED por declaração, em toda instalação. Se a linha da
 * unidade entrasse no gate, a autodesativação viraria impossível por desenho,
 * que é exatamente o defeito que a separação dos dois gates desfez.
 */
medir( $nome );
$mapa_com_unidade = $mapa_bom;
$mapa_com_unidade['entrega'] = 'BLOCKED';
$mapa_com_unidade['preflight'] = 'BLOCKED';
$decisao_com_unidade = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_com_unidade );

if ( true !== $decisao_com_unidade['pode'] ) {
	anotar( $nome, 'teto: a linha de uma UNIDADE em BLOCKED passou a proibir a autodesativação — o gate lê nomes de entregável declarados, e unidade não é entregável' );
}

/* TETO, de novo e por último: nada disso pode ter tornado o gate insatisfazível. */
medir( $nome );
$decisao_teto = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_bom );

if ( true !== $decisao_teto['pode'] ) {
	anotar( $nome, 'teto: com tudo do gate em OK a autodesativação deixou de ser autorizada — um gate que não fecha nunca é tão inútil quanto um que fecha sempre' );
}

/* ---------- preflight.artefato_do_pacote_e_baseline: o defeito A, medido ---------- */

/*
 * O defeito, dito por inteiro: `preflight.baseline` reprovou em produção
 * nomeando "dreamhost-panel-login 1.0.0, base-site-core-fator3 1.0.0". O primeiro é
 * achado legítimo — plugin da hospedagem, ativo e não declarado. O segundo é o
 * plugin persistente que ESTE pacote instala e ativa: o instrumento reprovando
 * o próprio produto, e oferecendo como saída que o pacote se declarasse plugin
 * de terceiro.
 *
 * O que esta sonda prova, nos dois lados: com os artefatos do pacote ativos e
 * nada mais, a classificação não produz divergência nenhuma; com um plugin de
 * terceiro ativo e não declarado, ela produz a divergência NOMEADA. E que os
 * slugs saem da CONFIGURAÇÃO — trocar o slug declarado muda o que a baseline
 * reconhece como nosso, que é a propriedade que uma lista literal não teria.
 */

$nome = 'preflight.artefato_do_pacote_e_baseline';

$artefatos = F3Base_Imp_Preflight::artefatos_do_pacote();
$do_pacote = F3Base_Imp_Preflight::plugins_do_pacote( $artefatos );

$slug_site_core = (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' );
$slug_tema      = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );

medir( $nome );

if ( ! isset( $do_pacote[ $slug_site_core ] ) ) {
	anotar( $nome, 'teto: o site-core declarado em site.site_core_slug (' . $slug_site_core . ') não foi reconhecido como artefato do pacote' );
}

/*
 * O SLUG DO IMPLANTADOR É DERIVADO, nunca escrito por extenso. Com o literal
 * `implantador-base` aqui, a asserção media o NOME DO DIRETÓRIO em que a suíte
 * está rodando, e não o que o preflight resolve: bastava verificar uma cópia
 * do pacote a partir de outra pasta — que é exatamente o que a criação de um
 * site novo faz — para a checagem reprovar sem nenhum defeito no pacote. A
 * derivação é a MESMA de artefatos_do_pacote(): plugin_basename() do arquivo
 * principal em execução.
 */
$slug_implantador = dirname( plugin_basename( F3BASE_IMP_ARQUIVO ) );

medir( $nome );

if ( ! isset( $do_pacote[ $slug_implantador ] ) ) {
	anotar( $nome, 'teto: o próprio implantador (' . $slug_implantador . ') não foi reconhecido como artefato do pacote' );
}

medir( $nome );

$tem_tema = false;

foreach ( $artefatos as $artefato ) {
	if ( 'tema' === $artefato['tipo'] && $slug_tema === $artefato['slug'] ) {
		$tem_tema = true;
	}
}

if ( ! $tem_tema ) {
	anotar( $nome, 'teto: o tema declarado em site.tema_slug (' . $slug_tema . ') não consta dos artefatos do pacote' );
}

medir( $nome );

if ( isset( $do_pacote[ $slug_tema ] ) ) {
	anotar( $nome, 'piso: o slug do TEMA entrou na absolvição de PLUGINS — um plugin de terceiro com esse nome de diretório seria absolvido sem estar declarado' );
}

/* TETO: só o que é do pacote, ativo. A checagem precisa ficar em silêncio. */
$so_nosso = array(
	'base-site-core-fator3/base-site-core-fator3.php'                 => array( 'slug' => $slug_site_core, 'nome' => 'Base Site Core Fator3', 'versao' => '1.0.0', 'ativo' => true ),
	$slug_implantador . '/' . basename( F3BASE_IMP_ARQUIVO ) => array( 'slug' => $slug_implantador, 'nome' => 'Implantador Base F3', 'versao' => '1.0.10', 'ativo' => true ),
);

medir( $nome );

$classificado = F3Base_Imp_Preflight::classificar_plugins( $so_nosso, $do_pacote, array(), array() );
$divergentes  = array_values( array_filter( $classificado, static fn ( array $i ): bool => 'divergencia-a-classificar' === $i['classe'] && $i['ativo'] ) );

if ( array() !== $divergentes ) {
	anotar( $nome, 'piso do silêncio: com o site-core e o implantador ativos e nada mais, a baseline acusou ' . count( $divergentes ) . ' divergência(s) — o instrumento reprovando o próprio produto' );
}

medir( $nome );

if ( 'artefato-do-pacote' !== $classificado['base-site-core-fator3/base-site-core-fator3.php']['classe'] ) {
	anotar( $nome, 'piso do silêncio: o site-core saiu classificado como ' . $classificado['base-site-core-fator3/base-site-core-fator3.php']['classe'] );
}

/* PISO: plugin de terceiro, ativo e não declarado. Precisa ser acusado, nomeado. */
$com_terceiro = array_merge(
	$so_nosso,
	array(
		'dreamhost-panel-login/dreamhost-panel-login.php' => array( 'slug' => 'dreamhost-panel-login', 'nome' => 'DreamHost Panel Login', 'versao' => '1.0.0', 'ativo' => true ),
	)
);

medir( $nome );

$classificado = F3Base_Imp_Preflight::classificar_plugins( $com_terceiro, $do_pacote, array(), array() );
$divergentes  = array_values( array_filter( $classificado, static fn ( array $i ): bool => 'divergencia-a-classificar' === $i['classe'] && $i['ativo'] ) );

if ( 1 !== count( $divergentes ) || 'dreamhost-panel-login' !== $divergentes[0]['slug'] ) {
	anotar( $nome, 'piso da acusação: plugin de terceiro ativo e não declarado não foi acusado nomeando — divergências: ' . count( $divergentes ) );
}

/*
 * E DECLARADO como operacional, o mesmo plugin sai da acusação, com finalidade e
 * responsável.
 *
 * A DECLARAÇÃO VEM DA BANCADA, e não do arquivo do projeto que este pacote
 * entrega. A regra medida aqui é "plugin declarado como operacional deixa de ser
 * divergência" — ela não depende de qual plugin um projeto específico declarou,
 * e amarrá-la a uma entrada real fazia o teste de uma REGRA falhar quando um
 * PROJETO mudava de ideia. `plugins_operacionais` nasce vazia, como todo campo
 * do operador, e uma bancada que exigisse entrada ali estaria exigindo que o
 * template deixasse de nascer vazio para o teste passar.
 */
$operacionais = array(
	'dreamhost-panel-login' => array(
		'finalidade'  => 'atalho de login do painel da hospedagem, instalado pela própria hospedagem no provisionamento',
		'responsavel' => 'hospedagem declarada pela bancada',
	),
);

medir( $nome );

if ( ! isset( $operacionais['dreamhost-panel-login'] ) ) {
	anotar( $nome, 'teto: a bancada não declarou o plugin operacional que ela mesma usa para medir a regra' );
}

medir( $nome );

$classificado = F3Base_Imp_Preflight::classificar_plugins( $com_terceiro, $do_pacote, array(), $operacionais );

if ( 'externo-preservado' !== $classificado['dreamhost-panel-login/dreamhost-panel-login.php']['classe'] ) {
	anotar( $nome, 'teto: declarado como operacional, o plugin da hospedagem continuou como divergência' );
}

medir( $nome );

if ( ! str_contains( $classificado['dreamhost-panel-login/dreamhost-panel-login.php']['justificativa'], 'hospedagem declarada pela bancada' ) ) {
	anotar( $nome, 'teto: a classificação do externo preservado não carrega o responsável DECLARADO — sem ele a linha diz que o plugin é tolerado e não diz por quem, que é a metade que serve para alguém decidir depois' );
}

/* PISO da fonte: o slug vem da configuração, não de lista literal no código. */
medir( $nome );

$outro_pacote = array( 'outro-site-core' => 'plugin persistente (site.site_core_slug)' );
$classificado = F3Base_Imp_Preflight::classificar_plugins( $so_nosso, $outro_pacote, array(), array() );

if ( 'divergencia-a-classificar' !== $classificado['base-site-core-fator3/base-site-core-fator3.php']['classe'] ) {
	anotar( $nome, 'piso da fonte: com outro slug declarado, base-site-core-fator3 continuou absolvido — sinal de lista literal decidindo no lugar da configuração' );
}

/* ---------- plugins.emissor_concorrente: o segundo emissor, classificado cedo ---------- */

/*
 * O BURACO QUE ESTA REGRA FECHA. `tracking.caminho_unico` prova que o módulo
 * não emite pelos DOIS caminhos dele mesmo — container × direto. Ela não vê um
 * emissor DE FORA: um plugin de console imprimindo `gtag.js` ao lado do
 * `site-core` é contagem em dobro que nenhuma configuração declarou, e o
 * relatório fica verde.
 *
 * O que esta sonda prova, nos dois lados:
 *
 * - Site Kit ativo com `useSnippet = true` fecha `concorrente`, e a linha da
 *   classificação NOMEIA o plugin e a condição observada;
 * - o MESMO plugin com o snippet e a medição automática de conversões
 *   desligados fecha `leitor` e volta à classe da declaração — a lista de
 *   slugs sozinha não condena ninguém;
 * - a option de condição AUSENTE não absolve: fecha `nao-medido`, porque o que
 *   não foi medido não pode ser declarado inofensivo;
 * - plugin INATIVO não é emissor de nada, que é o piso do falso positivo;
 * - e a classificação NÃO DESATIVA: `classe_declarada` continua sendo a da
 *   declaração, e é ela que decide divergência. Se a acusação apagasse o eixo
 *   da declaração, declarar o plugin em `plugins.operacionais` calaria a
 *   acusação — o contrário do que esta regra existe para fazer.
 */

$nome = 'plugins.emissor_concorrente';

$emissores_declarados = F3Base_Imp_Plugins::emissores_declarados();

medir( $nome );

if ( ! isset( $emissores_declarados['google-site-kit']['condicoes'][0]['option'] ) ) {
	anotar( $nome, 'teto da declaração: partilhado/dados/emissores-conhecidos.tsv não declara nenhuma condição para google-site-kit — sem option conhecida a condição de emissão nunca é medida' );
}

medir( $nome );

if ( 'google_site_kit_feature_enabled' !== (string) ( $emissores_declarados['google-site-kit']['chave_seo'] ?? '' ) ) {
	anotar( $nome, 'teto da declaração: a chave de integração de SEO do plugin de console não sai da declaração, e o adaptador teria de escrever o slug do fornecedor no meio do código' );
}

$arquivo_site_kit = 'google-site-kit/google-site-kit.php';

$censo_site_kit = array(
	$arquivo_site_kit => array( 'slug' => 'google-site-kit', 'nome' => 'Site Kit by Google', 'versao' => '1.0.0', 'ativo' => true ),
);

$condicao_ligada = array(
	'googlesitekit_analytics-4_settings' => array( 'useSnippet' => true, 'measurementID' => 'G-ABCDEF1234' ),
	'googlesitekit_conversion_tracking'  => array( 'enabled' => true ),
);

$condicao_leitor = array(
	'googlesitekit_analytics-4_settings' => array( 'useSnippet' => false, 'measurementID' => 'G-ABCDEF1234' ),
	'googlesitekit_conversion_tracking'  => array( 'enabled' => false ),
);

/* PISO: snippet LIGADO. A classificação precisa acusar, nomeando. */
$acusado = F3Base_Imp_Preflight::classificar_plugins(
	$censo_site_kit,
	array(),
	array(),
	array(),
	$emissores_declarados,
	$condicao_ligada
);

medir( $nome );

if ( 'emissor-concorrente' !== $acusado[ $arquivo_site_kit ]['classe'] ) {
	anotar( $nome, 'piso da acusação: com useSnippet = true o plugin de console saiu como ' . $acusado[ $arquivo_site_kit ]['classe'] . ' — o segundo emissor passou calado, e contagem em dobro sem acusação reescreve o lance do leilão' );
}

medir( $nome );

if ( ! contem( (string) $acusado[ $arquivo_site_kit ]['justificativa'], 'useSnippet' ) ) {
	anotar( $nome, 'piso da acusação: a justificativa não NOMEIA a condição observada — acusação sem o valor medido é alerta genérico' );
}

medir( $nome );

if ( 'concorrente' !== (string) $acusado[ $arquivo_site_kit ]['emissor'] ) {
	anotar( $nome, 'piso da acusação: o eixo do emissor não fechou concorrente com a condição ligada' );
}

/* TETO: snippet DESLIGADO e conversões desligadas. Ele é leitor, e mais nada. */
$leitor = F3Base_Imp_Preflight::classificar_plugins(
	$censo_site_kit,
	array(),
	array(),
	array(),
	$emissores_declarados,
	$condicao_leitor
);

medir( $nome );

if ( 'leitor' !== (string) $leitor[ $arquivo_site_kit ]['emissor'] ) {
	anotar( $nome, 'teto do leitor: com o snippet e as conversões desligados o veredito não fechou leitor — a lista de slugs estaria condenando sozinha, e a lista é dica, não gate' );
}

medir( $nome );

if ( 'emissor-concorrente' === $leitor[ $arquivo_site_kit ]['classe'] ) {
	anotar( $nome, 'teto do leitor: o plugin continuou classificado como emissor concorrente mesmo sem emitir' );
}

/* PISO do não medido: option AUSENTE não absolve. */
$sem_option = F3Base_Imp_Preflight::classificar_plugins(
	$censo_site_kit,
	array(),
	array(),
	array(),
	$emissores_declarados,
	array()
);

medir( $nome );

if ( 'nao-medido' !== (string) $sem_option['google-site-kit/google-site-kit.php']['emissor'] ) {
	anotar( $nome, 'piso do não medido: sem a option de condição observada o veredito não fechou nao-medido — absolver por ausência de medição é a pior aprovação possível' );
}

medir( $nome );

if ( 'emissor-concorrente' !== $sem_option[ $arquivo_site_kit ]['classe'] ) {
	anotar( $nome, 'piso do não medido: o que não foi medido saiu absolvido da classe' );
}

/* PISO do falso positivo: plugin INATIVO não emite nada. */
$inativo = F3Base_Imp_Preflight::classificar_plugins(
	array( $arquivo_site_kit => array( 'slug' => 'google-site-kit', 'nome' => 'Site Kit by Google', 'versao' => '1.0.0', 'ativo' => false ) ),
	array(),
	array(),
	array(),
	$emissores_declarados,
	$condicao_ligada
);

medir( $nome );

if ( 'emissor-concorrente' === $inativo[ $arquivo_site_kit ]['classe'] ) {
	anotar( $nome, 'piso do falso positivo: plugin INATIVO foi acusado de emitir — plugin desativado não imprime tag nenhuma, e acusar quem não emite treina o operador a ignorar a acusação' );
}

/* A DECLARAÇÃO NÃO CALA A ACUSAÇÃO, e a acusação não apaga a declaração. */
$declarado_e_emissor = F3Base_Imp_Preflight::classificar_plugins(
	$censo_site_kit,
	array(),
	array(),
	array( 'google-site-kit' => array( 'finalidade' => 'leitura dos consoles do Google', 'responsavel' => 'cliente' ) ),
	$emissores_declarados,
	$condicao_ligada
);

medir( $nome );

if ( 'emissor-concorrente' !== $declarado_e_emissor[ $arquivo_site_kit ]['classe'] ) {
	anotar( $nome, 'piso da declaração: declarar o plugin em plugins.operacionais CALOU a acusação de emissão — declarar é dizer que o plugin fica, nunca que ele pode emitir' );
}

medir( $nome );

if ( 'externo-preservado' !== (string) $declarado_e_emissor[ $arquivo_site_kit ]['classe_declarada'] ) {
	anotar( $nome, 'piso da declaração: a acusação de emissão apagou o eixo da declaração — com ele apagado, um plugin não declarado que emitisse sairia da lista de divergências' );
}

/* A CHAVE DE INTEGRAÇÃO DO SEO SAI NOS DOIS RAMOS, e `false` tem duas causas. */
$integracao = array(
	array( true, true, true, 'ativo e declarado pelo projeto' ),
	array( true, false, false, 'está ativo e não foi declarado' ),
	array( false, true, false, 'ausente ou inativo' ),
	array( false, false, false, 'ausente ou inativo' ),
);

foreach ( $integracao as $caso ) {
	$veredito_seo = F3Base_Imp_Seo::veredito_de_integracao( 'google-site-kit', (bool) $caso[0], (bool) $caso[1] );

	medir( $nome );

	if ( (bool) $caso[2] !== (bool) $veredito_seo['valor'] ) {
		anotar( $nome, 'ramo do adaptador de SEO (ativo=' . var_export( (bool) $caso[0], true ) . ', declarado=' . var_export( (bool) $caso[1], true ) . '): gravou ' . var_export( (bool) $veredito_seo['valor'], true ) . ' e devia gravar ' . var_export( (bool) $caso[2], true ) . ' — chave gravada só no ramo verdadeiro deixa o true de ontem no banco quando o plugin sai da instalação' );
	}

	medir( $nome );

	if ( ! contem( (string) $veredito_seo['motivo'], (string) $caso[3] ) ) {
		anotar( $nome, 'ramo do adaptador de SEO (ativo=' . var_export( (bool) $caso[0], true ) . ', declarado=' . var_export( (bool) $caso[1], true ) . '): o motivo não diz "' . $caso[3] . '" — false tem DUAS causas, e confundi-las faz procurar o problema no lugar errado' );
	}
}

medir( $nome );

if ( F3Base_Imp_Seo::veredito_de_integracao( 'google-site-kit', true, false )['motivo'] === F3Base_Imp_Seo::veredito_de_integracao( 'google-site-kit', false, false )['motivo'] ) {
	anotar( $nome, 'piso das duas causas: o plugin ativo e não declarado e o plugin ausente saíram com o MESMO motivo — a mensagem deixou de discriminar as duas causas do false' );
}

/* Slug FORA da lista não é acusado por acaso: quem o pega é o HTML. */
$fora_da_lista = F3Base_Imp_Preflight::classificar_plugins(
	array( 'plugin-qualquer/plugin-qualquer.php' => array( 'slug' => 'plugin-qualquer', 'nome' => 'Plugin Qualquer', 'versao' => '1.0.0', 'ativo' => true ) ),
	array(),
	array(),
	array(),
	$emissores_declarados,
	$condicao_ligada
);

medir( $nome );

if ( 'emissor-concorrente' === $fora_da_lista['plugin-qualquer/plugin-qualquer.php']['classe'] ) {
	anotar( $nome, 'piso do escopo: slug fora da lista declarada foi acusado de emitir — a lista é dica para classificar cedo, e quem decide o que emite é a contagem no HTML publicado' );
}

/* ---------- tema.override_por_conteudo: o defeito B, medido ---------- */

/*
 * O defeito: a checagem reprovou nomeando `wp_global_styles:wp-global-styles-f3base
 * (#24, 52 bytes)`. O WordPress cria esse post SOZINHO ao ativar um tema de
 * blocos, e 52 bytes é o stub vazio. Medindo EXISTÊNCIA, a checagem dispararia
 * em toda instalação de tema de blocos, para sempre.
 *
 * Os dois lados, provados aqui: `wp_global_styles` com `styles` preenchido é
 * acusado; o stub vazio fica em silêncio. E o post vazio e o idêntico ao arquivo
 * do tema também ficam — com motivo, porque some-los do relatório seria a outra
 * metade do erro.
 */

$nome = 'tema.override_por_conteudo';

$stub  = '{"version":3,"isGlobalStylesUserThemeJSON":true}';
$vazio = '{"version":3,"isGlobalStylesUserThemeJSON":true,"settings":{},"styles":{}}';
$real_ = '{"version":3,"isGlobalStylesUserThemeJSON":true,"styles":{"color":{"background":"#101010"}}}';

$casos = array(
	array( 'wp_global_styles', $stub, '', false, 'stub vazio', 'stub' ),
	array( 'wp_global_styles', $vazio, '', false, 'settings e styles presentes e VAZIOS', 'nenhuma chave tem conteúdo' ),
	array( 'wp_global_styles', $real_, '', true, 'styles preenchido', 'styles' ),
	array( 'wp_global_styles', '{"version":3,"settings":{"color":{"palette":[]}}}', '', true, 'settings preenchido', 'settings' ),
	array( 'wp_global_styles', '', '', false, 'post_content vazio', 'VAZIO' ),
	array( 'wp_global_styles', '   ', '', false, 'só espaço em branco', 'VAZIO' ),
	array( 'wp_global_styles', '{isso não é json', '', true, 'JSON que não decodifica', 'não decodifica' ),
	array( 'wp_template', '', '<!-- wp:group --><!-- /wp:group -->', false, 'template vazio no banco', 'VAZIO' ),
	array( 'wp_template', "<!-- wp:group --><!-- /wp:group -->\n", '<!-- wp:group --><!-- /wp:group -->', false, 'template idêntico ao arquivo do tema', 'IDÊNTICO' ),
	array( 'wp_template', '<!-- wp:paragraph --><p>outro</p><!-- /wp:paragraph -->', '<!-- wp:group --><!-- /wp:group -->', true, 'template diferente do arquivo do tema', 'DIFERE' ),
	array( 'wp_template_part', '<!-- wp:site-title /-->', '<!-- wp:site-title /-->', false, 'part idêntica ao arquivo do tema', 'IDÊNTICO' ),
	array( 'wp_template_part', '<!-- wp:site-title /-->', '', true, 'part sem arquivo do tema correspondente', 'não há arquivo do tema' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Preflight::veredito_de_override( $caso[0], $caso[1], $caso[2] );

	if ( $veredito['override'] !== $caso[3] ) {
		anotar( $nome, $caso[4] . ': esperado override=' . ( $caso[3] ? 'sim' : 'não' ) . ', obtido ' . ( $veredito['override'] ? 'sim' : 'não' ) );
		continue;
	}

	medir( $nome );

	if ( ! str_contains( $veredito['motivo'], $caso[5] ) ) {
		anotar( $nome, $caso[4] . ': o motivo não diz "' . $caso[5] . '" — ' . $veredito['motivo'] );
	}
}

/*
 * O TAMANHO NÃO DECIDE NADA, e é preciso que não decida: o log de produção
 * trazia "52 bytes" e o núcleo grava o stub em mais de uma grafia — compacta e
 * com espaços —, cada uma com um número diferente. Uma regra por tamanho
 * absolveria pelo motivo errado e reprovaria na próxima versão do WordPress.
 *
 * A prova: as duas grafias do stub ficam em silêncio, e uma personalização MAIS
 * CURTA que qualquer uma delas continua sendo acusada.
 */
$stub_do_nucleo = '{"isGlobalStylesUserThemeJSON":true, "version": 3 }';
$curto_e_real   = '{"styles":{"color":{"text":"#111"}}}';

medir( $nome );

if ( F3Base_Imp_Preflight::veredito_de_override( 'wp_global_styles', $stub_do_nucleo, '' )['override'] ) {
	anotar( $nome, 'a grafia do stub que o núcleo grava (com espaços, ' . strlen( $stub_do_nucleo ) . ' bytes) foi acusada' );
}

medir( $nome );

if ( ! F3Base_Imp_Preflight::veredito_de_override( 'wp_global_styles', $curto_e_real, '' )['override'] ) {
	anotar( $nome, 'personalização de ' . strlen( $curto_e_real ) . ' bytes, MENOR que o stub, não foi acusada: o tamanho voltou a decidir no lugar do conteúdo' );
}

medir( $nome );

if ( strlen( $curto_e_real ) >= strlen( $stub_do_nucleo ) ) {
	anotar( $nome, 'a amostra de personalização deixou de ser menor que o stub, e com isso a sonda parou de provar que o tamanho não decide' );
}

/* ---------- mcp.canal_unico_mede_plugins_ativos: o defeito A, medido ---------- */

/*
 * O DEFEITO DA 1.0.8, verbatim do log de produção:
 *
 *   FALHA entrega ↳ mcp.canal_unico — "as 9 rota(s) de arquivo que a unidade
 *   mediu não têm registrador único: Abilities files/list, Abilities
 *   files/read, … Dois diretórios de backup e DUAS chaves de desligamento — o
 *   operador fecha o canal em um e ele segue aberto pelo outro."
 *
 * Nove rotas, UMA fonte cada, nenhum segundo plugin nomeado: a evidência
 * impressa na própria linha desmente a frase. A causa é que a Abilities API não
 * devolve o plugin que registrou cada habilidade, e o código tratava "não
 * consegui atribuir" como "há mais de um".
 *
 * O que esta sonda prova, nos dois lados:
 *
 * - um complemento ativo → OK nomeando-o, e a FRASE DA CONSEQUÊNCIA não aparece
 *   (é este o piso que tranca o defeito: consequência sem achado é o
 *   diagnóstico afirmando causa que os dados contradizem);
 * - o declarado mais uma cópia com OUTRO slug e o MESMO `Plugin Name` → FALHA
 *   nomeando os dois diretórios e os dois arquivos principais, e aí sim com a
 *   frase da consequência ao lado dos nomes reais;
 * - nenhum complemento ativo → BLOCKED;
 * - censo indisponível (fonte incapaz de atribuir) → BLOCKED com a frase da
 *   Abilities API;
 * - unidade que não rodou → BLOCKED nomeando a option.
 *
 * E prova a medição por baixo do veredito: `complementos_de_canal()` conta
 * PLUGINS ATIVOS, ignora inativo e oculto, e enxerga a cópia pelo Plugin Name.
 */

$nome = 'mcp.canal_unico_mede_plugins_ativos';

$consequencia = 'chaves de desligamento';

$declarado = 'wp-mcp-ultimate-complemento-fator3';
$plugin_name = 'WP MCP Ultimate — Complemento Fator 3';

/*
 * Censo com o complemento declarado ativo, um plugin qualquer ativo, um
 * inativo com o MESMO Plugin Name (não conta: o WordPress não o carrega) e um
 * backup oculto (que `get_plugins()` nem lista, aqui representado como inativo).
 */
$censo_um = array(
	'wp-mcp-ultimate/wp-mcp-ultimate.php' => array( 'slug' => 'wp-mcp-ultimate', 'nome' => 'WP MCP Ultimate', 'ativo' => true ),
	$declarado . '/' . $declarado . '.php' => array( 'slug' => $declarado, 'nome' => $plugin_name, 'ativo' => true ),
	'flamingo/flamingo.php' => array( 'slug' => 'flamingo', 'nome' => 'Flamingo', 'ativo' => true ),
	'copia-inativa/copia-inativa.php' => array( 'slug' => 'copia-inativa', 'nome' => $plugin_name, 'ativo' => false ),
);

$censo_dois = $censo_um + array(
	'canal-mcp-copia/canal-mcp-copia.php' => array( 'slug' => 'canal-mcp-copia', 'nome' => $plugin_name, 'ativo' => true ),
);

$censo_nenhum = array(
	'wp-mcp-ultimate/wp-mcp-ultimate.php' => array( 'slug' => 'wp-mcp-ultimate', 'nome' => 'WP MCP Ultimate', 'ativo' => true ),
	'copia-inativa/copia-inativa.php' => array( 'slug' => 'copia-inativa', 'nome' => $plugin_name, 'ativo' => false ),
);

/* A MEDIÇÃO: um ativo, e o inativo com o mesmo nome fica de fora. */
medir( $nome );

$um = F3Base_Imp_Entrega::complementos_de_canal( $censo_um, $declarado, $plugin_name );

if ( 1 !== count( $um ) || $declarado !== $um[0]['slug'] ) {
	anotar( $nome, 'medição: com um complemento ativo e uma cópia INATIVA de mesmo Plugin Name, a contagem devolveu ' . count( $um ) . ' — diretório que o WordPress não carrega não é canal aberto' );
}

medir( $nome );

$dois = F3Base_Imp_Entrega::complementos_de_canal( $censo_dois, $declarado, $plugin_name );

if ( 2 !== count( $dois ) ) {
	anotar( $nome, 'medição: a cópia ATIVA com outro slug e o mesmo Plugin Name não foi contada — é assim que a segunda cópia aparece, e é ela que abre o segundo canal' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Entrega::complementos_de_canal( $censo_nenhum, $declarado, $plugin_name ) ) {
	anotar( $nome, 'medição: sem complemento ativo, a contagem devolveu alguma coisa' );
}

/* PISO DA FONTE: o slug vem da CONFIGURAÇÃO, não de lista literal no código. */
medir( $nome );

if ( array() !== F3Base_Imp_Entrega::complementos_de_canal( $censo_um, 'outro-slug-declarado', '' ) ) {
	anotar( $nome, 'piso da fonte: com outro slug declarado e nenhum Plugin Name, o complemento continuou sendo reconhecido — sinal de lista literal decidindo no lugar da configuração' );
}

/* Os fatos, como a unidade `mcp` os grava. */
$fatos_um = array(
	'rotas_de_arquivo'    => array( 'files/list', 'files/read', 'files/write' ),
	'fontes_de_arquivo'   => array( 'Abilities files/list', 'Abilities files/read', 'Abilities files/write' ),
	'censo_de_plugins'    => true,
	'complementos_ativos' => $um,
	'nome_complemento'    => $plugin_name,
	'slug_complemento'    => $declarado,
);

$fatos_dois = array(
	'rotas_de_arquivo'    => array( 'files/list' ),
	'fontes_de_arquivo'   => array( 'Abilities files/list' ),
	'censo_de_plugins'    => true,
	'complementos_ativos' => $dois,
	'nome_complemento'    => $plugin_name,
	'slug_complemento'    => $declarado,
);

$fatos_nenhum = array(
	'rotas_de_arquivo'    => array(),
	'fontes_de_arquivo'   => array(),
	'censo_de_plugins'    => true,
	'complementos_ativos' => array(),
	'nome_complemento'    => '',
	'slug_complemento'    => $declarado,
);

$fatos_sem_censo = array(
	'rotas_de_arquivo'    => array( 'files/list', 'files/read' ),
	'fontes_de_arquivo'   => array( 'Abilities files/list', 'Abilities files/read' ),
	'censo_de_plugins'    => false,
	'complementos_ativos' => array(),
	'nome_complemento'    => '',
	'slug_complemento'    => $declarado,
);

$casos = array(
	array( false, array(), 'BLOCKED', F3Base_Imp_Entrega::OPTION_MEDICOES, 'unidade que não rodou é pré-condição ausente, e o BLOCKED nomeia a option' ),
	array( true, $fatos_sem_censo, 'BLOCKED', 'Abilities API não devolve o plugin', 'fonte incapaz de atribuir fecha BLOCKED com a frase da Abilities API' ),
	array( true, $fatos_nenhum, 'BLOCKED', 'canal-mcp-complemento', 'nenhum complemento ativo é BLOCKED nomeando o papel declarado' ),
	array( true, $fatos_um, 'OK', $declarado, 'um complemento ativo fecha OK nomeando-o' ),
	array( true, $fatos_dois, 'FALHA', 'canal-mcp-copia', 'dois complementos ativos é FALHA nomeando o segundo diretório' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Entrega::veredito_do_canal_unico( $caso[0], $caso[1] );

	if ( $veredito['estado'] !== $caso[2] ) {
		anotar( $nome, $caso[4] . ': esperado ' . $caso[2] . ', obtido ' . $veredito['estado'] );
		continue;
	}

	medir( $nome );

	if ( ! str_contains( $veredito['motivo'], $caso[3] ) ) {
		anotar( $nome, $caso[4] . ': o motivo do ramo ' . $caso[2] . ' não menciona "' . $caso[3] . '"' );
	}
}

/*
 * PISO DA CONSEQUÊNCIA DECORADA. É esta a linha que a 1.0.8 imprimiu sem ter
 * medido nada que a sustentasse, e é ela que a sonda tranca: com UM complemento
 * ativo, a frase sobre dois diretórios de backup e duas chaves de desligamento
 * NÃO pode aparecer.
 */
medir( $nome );

$veredito_um = F3Base_Imp_Entrega::veredito_do_canal_unico( true, $fatos_um );

if ( str_contains( $veredito_um['motivo'], $consequencia ) ) {
	anotar( $nome, 'piso: com um único complemento ativo, a mensagem trouxe a frase da consequência ("' . $consequencia . '") — consequência sem achado é o diagnóstico afirmando causa que os dados contradizem' );
}

medir( $nome );

if ( str_contains( $veredito_um['motivo'], 'não têm registrador único' ) ) {
	anotar( $nome, 'piso: o ramo de um só voltou a falar em "registrador único", que é a atribuição que nenhuma das fontes sabe fazer' );
}

/* TETO: no ramo de dois, a consequência é verdadeira e PRECISA sair. */
medir( $nome );

$veredito_dois = F3Base_Imp_Entrega::veredito_do_canal_unico( true, $fatos_dois );

if ( ! str_contains( $veredito_dois['motivo'], $consequencia ) ) {
	anotar( $nome, 'teto: com dois complementos ativos, a frase da consequência sumiu — ela é verdadeira aqui e é o que torna o achado acionável' );
}

/* E o achado precisa NOMEAR os dois diretórios E os dois arquivos principais. */
foreach ( array( $declarado, 'canal-mcp-copia', $declarado . '/' . $declarado . '.php', 'canal-mcp-copia/canal-mcp-copia.php' ) as $exigido ) {
	medir( $nome );

	if ( ! str_contains( $veredito_dois['motivo'], $exigido ) ) {
		anotar( $nome, 'teto: a FALHA de canal duplicado não nomeia "' . $exigido . '" — sem diretório e arquivo principal o operador não tem o que abrir' );
	}
}

/*
 * PISO DA IMPOSSIBILIDADE DE MEDIR: sem censo, o estado NUNCA pode ser FALHA.
 * Era exatamente isso que a 1.0.8 fazia — tratar "não consegui atribuir" como
 * "há mais de um".
 */
medir( $nome );

$veredito_sem_censo = F3Base_Imp_Entrega::veredito_do_canal_unico( true, $fatos_sem_censo );

if ( 'FALHA' === $veredito_sem_censo['estado'] ) {
	anotar( $nome, 'piso: sem censo de plugins o veredito voltou a ser FALHA — impossibilidade de medir é BLOCKED, nunca veredito' );
}

medir( $nome );

if ( str_contains( $veredito_sem_censo['motivo'], $consequencia ) ) {
	anotar( $nome, 'piso: o BLOCKED por fonte incapaz de atribuir trouxe a frase da consequência junto' );
}

/* ---------- lotes.unidade_reflete_internas: o defeito B, medido ---------- */

/*
 * O DEFEITO: na mesma execução de 1.0.8, a linha 48 era `OK entrega — "todos os
 * entregáveis do gate de aplicação fecharam sem BLOCKED"` e a linha 49, DENTRO
 * dela, era `FALHA ↳ mcp.canal_unico`. Uma unidade não pode fechar OK contendo
 * uma checagem em FALHA: quem lê o resumo por unidade vê verde onde há
 * vermelho, e foi essa mesma discrepância que escondeu as FALHAs até a 1.0.7.
 *
 * E OS DOIS DEFEITOS QUE A CORREÇÃO PODIA CRIAR, os dois trancados aqui:
 *
 * - promover por N/A. A 1.0.9 pôs N/A acima de OK e uma unidade que INSTALOU e
 *   ATIVOU um plugin passou a fechar N/A porque a supressão de onboarding não
 *   se aplicava — o relatório mentindo para baixo. Só FALHA, BLOCKED e WARN
 *   promovem.
 * - promover por evidência de FASE. `orcamento.medicao_de_pagina` é BLOCKED por
 *   natureza (medição de navegador), e uma promoção cega ao gate travaria
 *   `entrega` em BLOCKED em toda instalação, para sempre, por desenho.
 *
 * O caminho exercitado é o REAL de `processar()`: `checagens_da_unidade()`
 * recorta as internas a partir da marca e `veredito_da_unidade()` decide.
 * Nenhuma das duas é reimplementada aqui — sonda que reimplementa prova que a
 * cópia funciona.
 */

$nome = 'lotes.unidade_reflete_internas';

/**
 * Roda o caminho real: emite as internas, recorta pela marca e promove.
 *
 * @param string                          $estado_da_unidade Estado que a etapa devolveria.
 * @param array<int,array<string,string>> $emitir            Internas a emitir: estado, nome, gate.
 * @return array<string,mixed>
 */
function f3b_reflexo_real( string $estado_da_unidade, array $emitir ): array {
	F3Base_Imp_Relatorio::zerar();

	$marca = F3Base_Imp_Relatorio::marcar();

	foreach ( $emitir as $linha ) {
		F3Base_Imp_Relatorio::emitir(
			$linha['estado'],
			$linha['nome'],
			'linha da sonda.',
			array( 'evidencia' => 'medida', 'fase' => 'local', 'gate' => $linha['gate'] )
		);
	}

	$internas = F3Base_Imp_Lotes::checagens_da_unidade( $marca );
	$reflexo  = F3Base_Imp_Lotes::veredito_da_unidade( $estado_da_unidade, $internas['nomeadas'] );

	F3Base_Imp_Relatorio::zerar();

	return $reflexo + array( 'internas' => $internas );
}

$ok_aplicacao    = array( 'estado' => 'OK', 'nome' => 'entrega.readme', 'gate' => 'aplicacao' );
$na_aplicacao    = array( 'estado' => 'N/A', 'nome' => 'formulario.regime_cf7', 'gate' => 'aplicacao' );
$warn_aplicacao  = array( 'estado' => 'WARN', 'nome' => 'config.chaves_lidas_nesta_execucao', 'gate' => 'aplicacao' );
$blocked_aplic   = array( 'estado' => 'BLOCKED', 'nome' => 'entrega.suite', 'gate' => 'aplicacao' );
$falha_aplicacao = array( 'estado' => 'FALHA', 'nome' => 'mcp.canal_unico', 'gate' => 'aplicacao' );
$blocked_fase    = array( 'estado' => 'BLOCKED', 'nome' => 'orcamento.medicao_de_pagina', 'gate' => 'fase' );
$falha_fase      = array( 'estado' => 'FALHA', 'nome' => 'entrega.rodada_limpa', 'gate' => 'fase' );

/*
 * O PISO INTEIRO, em tabela: estado da unidade, internas emitidas, estado
 * esperado, e se a promoção deve ou não ter acontecido.
 */
$piso = array(
	array( 'OK', array( $ok_aplicacao ), 'OK', false, 'só OK dentro: nada promove' ),
	array( 'OK', array( $ok_aplicacao, $na_aplicacao ), 'OK', false, 'OK + N/A fecha OK — N/A é condição de aplicabilidade falsa, não "pior que OK"' ),
	array( 'OK', array( $ok_aplicacao, $warn_aplicacao ), 'WARN', true, 'OK + WARN fecha WARN' ),
	array( 'OK', array( $ok_aplicacao, $blocked_aplic ), 'BLOCKED', true, 'OK + BLOCKED de aplicação fecha BLOCKED' ),
	array( 'OK', array( $ok_aplicacao, $falha_aplicacao ), 'FALHA', true, 'OK + FALHA de aplicação fecha FALHA' ),
	array( 'OK', array( $ok_aplicacao, $blocked_fase ), 'OK', false, 'OK + BLOCKED de FASE fecha OK: evidência que o host não produz não decide' ),
	array( 'OK', array( $ok_aplicacao, $falha_fase ), 'OK', false, 'OK + FALHA de FASE fecha OK, pelo mesmo motivo' ),
	array( 'OK', array( $blocked_fase, $warn_aplicacao ), 'WARN', true, 'fase não promove e aplicação promove, na mesma unidade' ),
	array( 'WARN', array( $ok_aplicacao, $warn_aplicacao ), 'WARN', false, 'unidade que JÁ reflete não é promovida de novo' ),
	array( 'FALHA', array( $ok_aplicacao, $blocked_aplic ), 'FALHA', false, 'BLOCKED não rebaixa uma unidade que já está em FALHA' ),
	array( 'N/A', array( $ok_aplicacao ), 'N/A', false, 'unidade N/A com interna OK continua N/A: OK não promove nem rebaixa' ),
	array( 'BLOCKED', array( $falha_aplicacao ), 'FALHA', true, 'FALHA promove por cima de BLOCKED' ),
);

foreach ( $piso as $caso ) {
	medir( $nome );

	$reflexo = f3b_reflexo_real( $caso[0], $caso[1] );

	if ( $reflexo['estado'] !== $caso[2] ) {
		anotar( $nome, $caso[4] . ': esperado ' . $caso[2] . ', obtido ' . $reflexo['estado'] );
		continue;
	}

	medir( $nome );

	if ( $reflexo['promovida'] !== $caso[3] ) {
		anotar( $nome, $caso[4] . ': a marca de promoção saiu ' . var_export( $reflexo['promovida'], true ) . ' e devia ser ' . var_export( $caso[3], true ) );
	}
}

/* A promoção NOMEIA quem a causou — estado promovido sem nome é número sem nome. */
medir( $nome );

$reflexo = f3b_reflexo_real( 'OK', array( $ok_aplicacao, $blocked_fase, $falha_aplicacao ) );

if ( ! str_contains( $reflexo['nota'], 'mcp.canal_unico' ) || ! str_contains( $reflexo['nota'], 'OK' ) ) {
	anotar( $nome, 'a nota da promoção não nomeia a checagem que a causou, ou não diz de qual estado a unidade veio' );
}

medir( $nome );

if ( array( 'mcp.canal_unico' ) !== $reflexo['responsaveis'] ) {
	anotar( $nome, 'a lista de responsáveis pela promoção incluiu quem não promoveu: ' . implode( ', ', $reflexo['responsaveis'] ) );
}

/*
 * A PENDÊNCIA DE FASE SOME DO VEREDITO E NUNCA DO RELATÓRIO: ela precisa estar
 * NOMEADA no texto da unidade mesmo quando não promoveu nada.
 */
medir( $nome );

$so_fase = f3b_reflexo_real( 'OK', array( $ok_aplicacao, $blocked_fase ) );

if ( 'OK' !== $so_fase['estado'] || $so_fase['promovida'] ) {
	anotar( $nome, 'piso da fase: a evidência que este host não produz promoveu a unidade — é a unidade entrega travada em BLOCKED para sempre, por desenho' );
}

medir( $nome );

if ( ! str_contains( $so_fase['nota'], 'orcamento.medicao_de_pagina' ) || array( 'orcamento.medicao_de_pagina (BLOCKED)' ) !== $so_fase['pendencias_de_fase'] ) {
	anotar( $nome, 'piso da fase: a pendência saiu do veredito E do texto — some do veredito, nunca do relatório' );
}

/*
 * PISO DA PORTA DE ESCAPE: gate AUSENTE não pode absolver. Quem esquecer de
 * declarar o gate promove como aplicação, que é o lado seguro.
 */
medir( $nome );

$sem_gate = F3Base_Imp_Lotes::veredito_da_unidade( 'OK', array( array( 'estado' => 'FALHA', 'nome' => 'sem.gate', 'gate' => '' ) ) );

if ( 'FALHA' !== $sem_gate['estado'] ) {
	anotar( $nome, 'piso da porta de escape: interna SEM gate declarado deixou de promover — a omissão virou o caminho barato para escapar da promoção' );
}

/* A ordem inteira, e ela mora em um lugar só. */
$ordem = array(
	array( 'OK', 'FALHA', 'FALHA' ),
	array( 'OK', 'BLOCKED', 'BLOCKED' ),
	array( 'OK', 'WARN', 'WARN' ),
	array( 'OK', 'N/A', 'OK' ),
	array( 'OK', 'WAIVED', 'OK' ),
	array( 'N/A', 'OK', 'N/A' ),
	array( 'WAIVED', 'OK', 'WAIVED' ),
	array( 'BLOCKED', 'FALHA', 'FALHA' ),
	array( 'WARN', 'BLOCKED', 'BLOCKED' ),
	array( 'N/A', 'WARN', 'WARN' ),
	array( 'FALHA', 'BLOCKED', 'FALHA' ),
	array( 'BLOCKED', 'WARN', 'BLOCKED' ),
	array( 'ESTADO-INVENTADO', 'OK', 'FALHA' ),
	array( 'OK', 'ESTADO-INVENTADO', 'FALHA' ),
);

foreach ( $ordem as $par ) {
	medir( $nome );

	$obtido = F3Base_Imp_Relatorio::estado_mais_severo( $par[0], $par[1] );

	if ( $obtido !== $par[2] ) {
		anotar( $nome, 'ordem de severidade: ' . $par[0] . ' com ' . $par[1] . ' devia dar ' . $par[2] . ' e deu ' . $obtido );
	}
}

/* E os pesos: só FALHA, BLOCKED e WARN promovem; o resto empata em zero. */
$pesos = F3Base_Imp_Relatorio::ordem_de_severidade();

foreach ( array( 'OK' => 0, 'N/A' => 0, 'WAIVED' => 0 ) as $estado_neutro => $peso_esperado ) {
	medir( $nome );

	if ( ( $pesos[ $estado_neutro ] ?? -1 ) !== $peso_esperado ) {
		anotar( $nome, 'peso de ' . $estado_neutro . ': ' . var_export( $pesos[ $estado_neutro ] ?? null, true ) . ' — estado que não é reprovação, pré-condição ausente nem observação NÃO pode promover' );
	}
}

medir( $nome );

if ( ! ( ( $pesos['WARN'] ?? 0 ) < ( $pesos['BLOCKED'] ?? 0 ) && ( $pesos['BLOCKED'] ?? 0 ) < ( $pesos['FALHA'] ?? 0 ) ) ) {
	anotar( $nome, 'a ordem entre os três que promovem deixou de ser FALHA > BLOCKED > WARN' );
}

/*
 * PISO DO RECORTE: a promoção enxerga as internas pelo MESMO recorte que
 * `processar()` usa. Se `checagens_da_unidade()` parar de nomear o que não
 * fecha OK, a promoção fica cega e a unidade volta a fechar verde por cima de
 * vermelho — por isso o recorte é medido aqui, e não só a promoção.
 */
medir( $nome );

$recorte = f3b_reflexo_real( 'OK', array( $ok_aplicacao ) );

if ( array() !== $recorte['internas']['nomeadas'] || 1 !== $recorte['internas']['resumidas'] ) {
	anotar( $nome, 'piso do recorte: com só uma checagem OK dentro, o recorte devia nomear nenhuma e resumir uma, e devolveu ' . count( $recorte['internas']['nomeadas'] ) . ' nomeada(s) e ' . $recorte['internas']['resumidas'] . ' resumida(s)' );
}

medir( $nome );

$recorte = f3b_reflexo_real( 'OK', array( $ok_aplicacao, $blocked_fase ) );

if ( 1 !== count( $recorte['internas']['nomeadas'] )
	|| 'orcamento.medicao_de_pagina' !== $recorte['internas']['nomeadas'][0]['nome']
	|| 'fase' !== $recorte['internas']['nomeadas'][0]['gate'] ) {
	anotar( $nome, 'piso do recorte: a checagem que não fechou OK perdeu o nome ou o GATE no recorte que alimenta a promoção — sem o gate, a distinção não tem como existir' );
}

/* ---------- lotes.permalinks_decisao: aplicar e cobrir, e o que não pode sumir ---------- */

/*
 * O ENUM DE QUATRO VALORES SAIU. Ele existia para o operador poder RECUSAR a
 * troca de estrutura de permalinks, e recusar deixava o site com a estrutura que
 * ninguém escolheu — dano maior do que a reserva evitava. O par de
 * redirecionamento é aditivo: não altera objeto nenhum, não apaga nada e some
 * quando a option some.
 *
 * O que sobrou aqui é o que ainda pode quebrar o site: estrutura já igual não
 * pode gravar nada, estrutura diferente aplica E cobre, e a cobertura precisa
 * alcançar o publicado que muda de endereço — sem ela, toda URL indexada vira
 * 404 no dia da troca.
 */
$nome = 'lotes.permalinks_decisao';

$sem_risco = array(
	'em_risco'  => array(),
	'publicado' => 3,
);

medir( $nome );

$igual = F3Base_Imp_Lotes::decisao_de_permalinks( 'aplicar-e-cobrir', '/%postname%/', '/%postname%/', $sem_risco );

if ( F3Base_Imp_Lotes::ACAO_PERMALINK_NADA !== $igual['acao'] || F3Base_Imp_Relatorio::OK !== $igual['estado'] ) {
	anotar( $nome, 'piso: estrutura já igual à declarada não pode gravar nada — gravar por gravar reescreve regras de reescrita sem motivo' );
}

medir( $nome );

if ( $igual['cobertura'] ) {
	anotar( $nome, 'piso: sem troca de estrutura não há endereço antigo a cobrir, e a cobertura saiu ligada' );
}

medir( $nome );

$troca = F3Base_Imp_Lotes::decisao_de_permalinks( 'aplicar-e-cobrir', '', '/%postname%/', $sem_risco );

if ( F3Base_Imp_Lotes::ACAO_PERMALINK_APLICAR !== $troca['acao'] ) {
	anotar( $nome, 'teto: a estrutura declarada não foi aplicada — o site fica com o endereço por ?p=, que nenhum buscador trata como página' );
}

medir( $nome );

if ( F3Base_Imp_Relatorio::OK !== $troca['estado'] ) {
	anotar( $nome, 'teto: aplicar a estrutura declarada não fechou OK — trocar permalinks é o comportamento normal deste pacote, não uma exceção a autorizar' );
}

medir( $nome );

if ( ! $troca['cobertura'] ) {
	anotar( $nome, 'piso: a troca de estrutura saiu SEM cobertura — sem o 301 do endereço antigo, toda URL já indexada vira 404 no dia da troca' );
}

medir( $nome );

$com_risco = F3Base_Imp_Lotes::decisao_de_permalinks(
	'aplicar-e-cobrir',
	'',
	'/%postname%/',
	array(
		'em_risco'  => array( array( 'id' => 7, 'tipo' => 'post', 'slug' => 'post-antigo', 'caminho' => '/?p=7' ) ),
		'publicado' => 4,
	)
);

if ( F3Base_Imp_Lotes::ACAO_PERMALINK_APLICAR !== $com_risco['acao'] || ! $com_risco['cobertura'] ) {
	anotar( $nome, 'piso: publicado em risco fez a troca recuar — recuar deixa o site na estrutura que ninguém escolheu, e a cobertura existe justamente para esse caso' );
}

medir( $nome );

if ( ! str_contains( $com_risco['motivo'], 'post-antigo' ) ) {
	anotar( $nome, 'teto: o publicado que muda de endereço não saiu NOMEADO — quem lê precisa saber qual página teve o endereço trocado' );
}


/* ---------- conteudo.exemplo_do_wordpress: o discriminante, teto e piso ---------- */

/*
 * A orientação que criou esta regra: o implantador deve fazer todas as
 * modificações necessárias para a página funcionar, alterando conteúdo
 * preexistente se preciso. `Hello world!` e `Sample Page` não são conteúdo de
 * ninguém — são o que `wp_install_defaults()` insere em toda instalação —, e
 * deixá-los publicados põe `Sample Page` no sitemap, na seleção do `llms.txt` e
 * na busca.
 *
 * O que decide NÃO é o slug: slug igual não prova nada, e é a mesma regra que
 * governa a adoção de objeto. O objeto só é exemplo se AINDA FOR o que o
 * WordPress criou — título e conteúdo idênticos ao que o núcleo escreveria
 * agora — a data de modificação não decide desde a 2.1.0, porque o instalador
 * da hospedagem a toca sem editar nada.
 *
 * O piso que importa é o NEGATIVO: objeto EDITADO não pode ir para a lixeira em
 * nenhuma circunstância. A edição é plantada em título, em conteúdo e nos dois,
 * e os três casos precisam sobreviver.
 */

$nome = 'conteudo.exemplo_do_wordpress';
$C    = 'F3Base_Imp_Conteudo';

$amostra_falsa = array(
	array(
		'papel'    => $C::EXEMPLO_PRIMEIRO_POST,
		'tipo'     => 'post',
		'slug'     => 'hello-world',
		'titulo'   => 'Hello world!',
		'conteudo' => "<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->",
	),
	array(
		'papel'    => $C::EXEMPLO_PAGINA_EXEMPLO,
		'tipo'     => 'page',
		'slug'     => 'sample-page',
		'titulo'   => 'Sample Page',
		'conteudo' => "<!-- wp:paragraph -->\n<p>This is an example page.</p>\n<!-- /wp:paragraph -->",
	),
);

$post_do_nucleo = $amostra_falsa[0];

/**
 * Objeto observado, INTOCADO, com o desvio que o caso quiser plantar.
 *
 * @param array<string,string> $esperado Entrada do catálogo.
 * @param array<string,mixed>  $desvio   O que o caso muda.
 * @return array<string,mixed>
 */
function f3b_observado_de_exemplo( array $esperado, array $desvio = array() ): array {
	return array_merge(
		array(
			'tipo'              => $esperado['tipo'],
			'slug'              => $esperado['slug'],
			'titulo'            => $esperado['titulo'],
			'conteudo'          => $esperado['conteudo'],
			'post_date_gmt'     => '2026-08-31 12:00:00',
			'post_modified_gmt' => '2026-08-31 12:00:00',
			'gerenciado'        => false,
			'em_uso'            => '',
		),
		$desvio
	);
}

$casos_exemplo = array(
	array(
		'rotulo'   => 'intocado desde a instalação vai para a LIXEIRA',
		'esperado' => $post_do_nucleo,
		'desvio'   => array(),
		'acao'     => $C::ACAO_EXEMPLO_LIXEIRA,
		'exige'    => array( 'intocado', $C::EXEMPLO_PRIMEIRO_POST ),
	),
	array(
		'rotulo'   => 'TÍTULO editado: intocável',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'titulo' => 'Como esta operação constrói sites' ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'título editado' ),
		'proibe'   => array( 'conteúdo editado' ),
	),
	array(
		'rotulo'   => 'CONTEÚDO editado: intocável',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'conteudo' => '<!-- wp:paragraph --><p>Texto de verdade, publicado por alguém.</p><!-- /wp:paragraph -->' ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'conteúdo editado' ),
		'proibe'   => array( 'título editado' ),
	),
	array(
		'rotulo'   => 'título E conteúdo editados: intocável, e as DUAS divergências saem nomeadas',
		'esperado' => $post_do_nucleo,
		'desvio'   => array(
			'titulo'   => 'Como esta operação constrói sites',
			'conteudo' => '<!-- wp:paragraph --><p>Texto de verdade, publicado por alguém.</p><!-- /wp:paragraph -->',
		),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'título editado', 'conteúdo editado' ),
	),
	array(
		/*
		 * O CASO DA HOSPEDAGEM — 2.1.0. O instalador da DreamHost toca o
		 * Hello world! dois segundos depois de criá-lo; com a cláusula da data
		 * o post era preservado e ia ao ar. Texto idêntico ao do núcleo é o
		 * discriminante, e a data não decide.
		 */
		'rotulo'   => 'texto idêntico e post_modified_gmt avançado pelo instalador da hospedagem: ainda é resíduo, e vai para a lixeira',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'post_modified_gmt' => '2026-09-02 09:14:00' ),
		'acao'     => $C::ACAO_EXEMPLO_LIXEIRA,
		'exige'    => array( 'intocado' ),
		'proibe'   => array( 'post_modified_gmt', 'título editado', 'conteúdo editado' ),
	),
	array(
		'rotulo'   => 'objeto gerenciado por este pacote: intocável antes de qualquer comparação',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'gerenciado' => true ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'gerenciado por este pacote' ),
	),
	array(
		'rotulo'   => 'objeto EM USO como página inicial: intocável mesmo intocado',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'em_uso' => 'page_on_front' ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'em uso', 'page_on_front' ),
		'proibe'   => array( 'intocado' ),
	),
	array(
		'rotulo'   => 'fora do catálogo do núcleo: intocável, e a mensagem diz que não é objeto de wp_install_defaults()',
		'esperado' => array(),
		'desvio'   => array(),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'wp_install_defaults' ),
	),
);

foreach ( $casos_exemplo as $caso ) {
	medir( $nome );

	$base_do_caso = array() === $caso['esperado'] ? $post_do_nucleo : $caso['esperado'];
	$veredito     = F3Base_Imp_Conteudo::veredito_de_exemplo_do_wordpress(
		$caso['esperado'],
		f3b_observado_de_exemplo( $base_do_caso, $caso['desvio'] )
	);

	if ( $veredito['acao'] !== $caso['acao'] ) {
		anotar( $nome, $caso['rotulo'] . ': ação esperada ' . $caso['acao'] . ', obtida ' . $veredito['acao'] );
		continue;
	}

	medir( $nome );

	if ( '' === trim( $veredito['discriminante'] ) ) {
		anotar( $nome, $caso['rotulo'] . ': veredito sem DISCRIMINANTE — dizer que removeu ou preservou não basta, o relatório imprime o que decidiu' );
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['discriminante'] . ' ' . $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': a mensagem não menciona "' . $trecho . '"' );
		}
	}

	foreach ( (array) ( $caso['proibe'] ?? array() ) as $trecho ) {
		medir( $nome );

		if ( contem( $veredito['discriminante'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o discriminante trouxe "' . $trecho . '", que é o de outro caso' );
		}
	}
}

/*
 * O PISO NEGATIVO, dito como afirmação própria e não como consequência dos
 * casos acima: objeto EDITADO não vai para a lixeira em NENHUMA circunstância.
 * A edição é plantada em título, em conteúdo e nos dois, e nenhum dos três pode
 * produzir a ação de remover.
 */
$edicoes_plantadas = array(
	'só no título'   => array( 'titulo' => 'Um título que alguém escreveu' ),
	'só no conteúdo' => array( 'conteudo' => '<!-- wp:paragraph --><p>Um texto que alguém escreveu.</p><!-- /wp:paragraph -->' ),
	'nos dois'       => array(
		'titulo'   => 'Um título que alguém escreveu',
		'conteudo' => '<!-- wp:paragraph --><p>Um texto que alguém escreveu.</p><!-- /wp:paragraph -->',
	),
);

foreach ( $amostra_falsa as $entrada_do_nucleo ) {
	foreach ( $edicoes_plantadas as $onde => $edicao ) {
		medir( $nome );

		$veredito = F3Base_Imp_Conteudo::veredito_de_exemplo_do_wordpress(
			$entrada_do_nucleo,
			f3b_observado_de_exemplo( $entrada_do_nucleo, $edicao )
		);

		if ( $C::ACAO_EXEMPLO_LIXEIRA === $veredito['acao'] ) {
			anotar( $nome, 'PISO NEGATIVO violado: ' . $entrada_do_nucleo['papel'] . ' com edição ' . $onde
				. ' foi mandado para a lixeira — objeto editado é conteúdo de verdade de alguém e é intocável' );
		}

		medir( $nome );

		if ( $C::ACAO_EXEMPLO_MANTER === $veredito['acao'] && ! contem( $veredito['discriminante'], 'editado' ) ) {
			anotar( $nome, 'piso do discriminante: ' . $entrada_do_nucleo['papel'] . ' com edição ' . $onde
				. ' foi preservado sem que o discriminante dissesse que houve edição — discriminante: ' . $veredito['discriminante'] );
		}
	}
}

/*
 * PISO DA HIPÓTESE: o slug INDEXA o catálogo, e só. Tipo errado não casa, slug
 * de fora não casa, e slug vazio nunca casa — sem isso, um objeto sem
 * `post_name` cairia na primeira entrada do catálogo e seria comparado com o
 * que não é.
 */
$hipoteses = array(
	array( 'post', 'hello-world', $C::EXEMPLO_PRIMEIRO_POST, 'o post do núcleo casa com a entrada dele' ),
	array( 'page', 'sample-page', $C::EXEMPLO_PAGINA_EXEMPLO, 'a página do núcleo casa com a entrada dela' ),
	array( 'page', 'hello-world', '', 'o slug do post numa página NÃO casa: o tipo faz parte da hipótese' ),
	array( 'post', 'sample-page', '', 'o slug da página num post NÃO casa' ),
	array( 'post', 'metodo-f3', '', 'slug de fora do catálogo não casa' ),
	array( 'post', '', '', 'slug vazio nunca casa' ),
);

foreach ( $hipoteses as $hipotese ) {
	medir( $nome );

	$entrada = F3Base_Imp_Conteudo::entrada_da_amostra( $amostra_falsa, $hipotese[0], $hipotese[1] );
	$papel   = (string) ( $entrada['papel'] ?? '' );

	if ( $papel !== $hipotese[2] ) {
		anotar( $nome, 'piso da hipótese: ' . $hipotese[3] . ' — papel esperado "' . $hipotese[2] . '", obtido "' . $papel . '"' );
	}
}

/*
 * A lista comparada contra os LITERAIS que o schema declara, e não contra as
 * próprias constantes: comparar a constante com ela mesma é tautologia, e o que
 * se quer provar é que o código e o enum do schema não divergiram.
 */
medir( $nome );

if ( array( 'lixeira', 'manter' ) !== F3Base_Imp_Conteudo::decisoes_de_exemplo() ) {
	anotar( $nome, 'piso da lista: as decisões aceitas de conteudo.exemplo_do_wordpress deixaram de ser lixeira e manter, e o schema declara essas duas' );
}

/* ---------- lotes.indexacao_consequencia: causa E consequência, nos dois ramos ---------- */

/*
 * O defeito medido na 1.0.9: `blog_public = 0` era a gravação CERTA quando as
 * condições não fechavam, e o log dizia que gravou — sem dizer que essa
 * gravação é o que faz o wp-admin estampar "Problema grave de SEO: Você está
 * bloqueando o acesso dos robôs". O operador ficava com um alarme vermelho no
 * painel e um relatório em OK, sem nada ligando os dois.
 *
 * O aviso do WordPress não é suprimido: ele está certo. O que se exige aqui é
 * que a mensagem nomeie a consequência E o caminho de saída — e que o ramo
 * indexável NÃO carregue nenhum dos dois, que seria o texto de um ramo impresso
 * no outro.
 *
 * Na 1.0.12 o CAMINHO DE SAÍDA mudou, e a exigência muda com ele: não se pede
 * mais para declarar `producao` nem para preencher lista de domínio nenhuma,
 * porque o padrão já é indexar. O que resta é sumir a causa medida ou declarar
 * `ambiente.indexar = "forcar"`. Exigir aqui o texto antigo seria a suíte
 * guardando a regra revogada.
 */

$nome = 'lotes.indexacao_consequencia';

$bloqueado = F3Base_Imp_Lotes::consequencia_de_indexacao( false, 'local', 'exemplo.test' );
$indexavel = F3Base_Imp_Lotes::consequencia_de_indexacao( true, 'producao', 'exemplo.test' );

foreach ( array( 'Problema grave de SEO', 'ambiente.tipo', 'producao', 'ambiente.indexar = "forcar"', 'ambiente.dominios_de_previa', 'exemplo.test', 'local' ) as $trecho ) {
	medir( $nome );

	if ( ! str_contains( $bloqueado, $trecho ) ) {
		anotar( $nome, 'ramo não indexável: a mensagem não menciona "' . $trecho . '" — causa sem consequência, ou consequência sem o caminho de saída' );
	}
}

medir( $nome );

if ( ! str_contains( $bloqueado, 'não é suprimido' ) ) {
	anotar( $nome, 'ramo não indexável: a mensagem não diz que o aviso do WordPress NÃO é suprimido — esconder alarme verdadeiro é pior que explicá-lo, e a mensagem é o lugar onde isso fica dito' );
}

medir( $nome );

if ( str_contains( $bloqueado, 'inclua o host' ) ) {
	anotar( $nome, 'ramo não indexável: a mensagem ainda manda preencher uma lista de domínios para indexar — ela deixou de ser condição de blog_public na 1.0.12 e saiu do pacote na 1.0.19, e o caminho de saída que exige configuração é justamente o que esta release inverteu' );
}

foreach ( array( 'Problema grave de SEO', 'ambiente.indexar = "forcar"' ) as $trecho ) {
	medir( $nome );

	if ( str_contains( $indexavel, $trecho ) ) {
		anotar( $nome, 'ramo indexável: trouxe "' . $trecho . '", que é texto do ramo bloqueado — o aviso não existe quando blog_public = 1' );
	}
}

medir( $nome );

if ( '' === trim( $indexavel ) ) {
	anotar( $nome, 'ramo indexável em silêncio: toda checagem emite nos DOIS ramos, e o ramo certo também precisa dizer o que o operador deve ver' );
}

/* ---------- lotes.indexacao_veredito: o ônus invertido, teto e piso ---------- */

/*
 * A DECISÃO DO DONO, na 1.0.12: "todas as configurações do implantador devem já
 * criar um site pronto para produção e para ser indexado. Se o usuário não
 * quiser, ele deverá mudar isso manualmente."
 *
 * Até a 1.0.11 era o contrário: `blog_public = 1` exigia TRÊS condições, e o
 * template nascia com `ambiente.tipo = local` e a lista de domínios vazia — o
 * padrão era não indexar, e chegar ao estado normal de um site exigia acertar
 * três chaves. O piso aqui é dos dois lados e cobre os dois riscos: o de o
 * padrão voltar a não indexar, e o de uma guarda passar a dar falso positivo
 * num site real.
 */

$nome = 'lotes.indexacao_veredito';
$L    = 'F3Base_Imp_Lotes';

/**
 * Medição de ambiente com os valores de um site de produção limpo.
 *
 * @param array<string,mixed> $mudanca O que este caso muda.
 * @return array<string,mixed>
 */
function f3b_ambiente_medido( array $mudanca = array() ): array {
	return $mudanca + array(
		'modo'        => 'medir',
		'tipo'        => 'producao',
		'esquema'     => 'https',
		'host'        => 'exemplo.com.br',
		'ambiente_wp' => 'production',
		'previa'      => array(),
	);
}

$casos_indexacao = array(
	array(
		'rotulo' => 'produção limpa com HTTPS indexa, sem configuração nenhuma',
		'medido' => f3b_ambiente_medido(),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'PADRÃO', 'nasce indexável', 'nenhuma guarda' ),
		'proibe' => array( 'guarda(s) MEDIDA(s)', 'ambiente.indexar = "forcar"' ),
	),
	array(
		'rotulo' => 'wp_get_environment_type() = staging segura, em WARN, nomeando',
		'medido' => f3b_ambiente_medido( array( 'ambiente_wp' => 'staging' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'wp_get_environment_type()', 'staging', 'declararam explicitamente', 'ambiente.indexar = "forcar"' ),
		'proibe' => array( 'PADRÃO: o site nasce indexável' ),
	),
	array(
		'rotulo' => 'home_url() em HTTP puro segura, em WARN, nomeando o esquema observado',
		'medido' => f3b_ambiente_medido( array( 'esquema' => 'http' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'esquema de home_url()', 'http', 'HTTP puro é defeito', 'ambiente.indexar = "forcar"' ),
		'proibe' => array( 'wp_get_environment_type()' ),
	),
	array(
		'rotulo' => 'ambiente.tipo diferente de producao segura, em WARN, nomeando o valor declarado',
		'medido' => f3b_ambiente_medido( array( 'tipo' => 'local' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'ambiente.tipo', 'local', 'ambiente.indexar = "forcar"' ),
		'proibe' => array( 'esquema de home_url()' ),
	),
	array(
		'rotulo' => 'host de pré-visualização declarado segura, em WARN, nomeando o sufixo que casou',
		'medido' => f3b_ambiente_medido(
			array(
				'host'   => 'projeto.dreamhosters.com',
				'previa' => array( 'dreamhosters.com' ),
			)
		),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'ambiente.dominios_de_previa', 'projeto.dreamhosters.com', 'dreamhosters.com' ),
		'proibe' => array( 'PADRÃO: o site nasce indexável' ),
	),
	array(
		'rotulo' => 'lista de prévia VAZIA não segura o mesmo host: a guarda não existe escondida no código',
		'medido' => f3b_ambiente_medido( array( 'host' => 'projeto.dreamhosters.com' ) ),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'PADRÃO' ),
		'proibe' => array( 'ambiente.dominios_de_previa (observado' ),
	),
	array(
		'rotulo' => 'indexar = forcar com guarda ativa indexa E registra o motivo por que a decisão existia',
		'medido' => f3b_ambiente_medido(
			array(
				'modo'        => 'forcar',
				'ambiente_wp' => 'staging',
			)
		),
		'valor'  => 1,
		'estado' => 'WARN',
		'exige'  => array( 'forcar', 'IGNORANDO', 'wp_get_environment_type()', 'staging', 'motivo por que a decisão existia' ),
		'proibe' => array( 'INERTE' ),
	),
	array(
		'rotulo' => 'indexar = forcar sem guarda alguma registra a decisão como INERTE, em vez de calar',
		'medido' => f3b_ambiente_medido( array( 'modo' => 'forcar' ) ),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'forcar', 'INERTE' ),
		'proibe' => array( 'IGNORANDO' ),
	),
	array(
		'rotulo' => 'indexar = nunca em produção limpa não indexa, e diz que é escolha, não medição',
		'medido' => f3b_ambiente_medido( array( 'modo' => 'nunca' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'nunca', 'escolha do projeto', 'nenhuma' ),
		'proibe' => array( 'PADRÃO: o site nasce indexável' ),
	),
	array(
		'rotulo' => 'modo não reconhecido cai para medir, e não vira decisão silenciosa',
		'medido' => f3b_ambiente_medido( array( 'modo' => 'talvez' ) ),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'PADRÃO' ),
		'proibe' => array( 'talvez' ),
	),
);

foreach ( $casos_indexacao as $caso ) {
	$veredito = F3Base_Imp_Lotes::veredito_de_indexacao( $caso['medido'] );

	medir( $nome );

	if ( $caso['valor'] !== $veredito['valor'] ) {
		anotar( $nome, $caso['rotulo'] . ': blog_public esperado ' . $caso['valor'] . ', obtido ' . $veredito['valor'] );
	}

	medir( $nome );

	if ( $caso['estado'] !== $veredito['estado'] ) {
		anotar( $nome, $caso['rotulo'] . ': estado esperado ' . $caso['estado'] . ', obtido ' . $veredito['estado'] );
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': a mensagem não menciona "' . $trecho . '" — guarda sem o valor observado, ou decisão sem o motivo, não responde à pergunta seguinte do operador' );
		}
	}

	foreach ( $caso['proibe'] as $trecho ) {
		medir( $nome );

		if ( contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': a mensagem trouxe "' . $trecho . '", que é texto de outro ramo' );
		}
	}
}

/*
 * PISO DA GUARDA QUE NÃO PODE DAR FALSO POSITIVO. `wp_get_environment_type()`
 * devolve `production` por padrão no núcleo; qualquer outro valor fora dos três
 * declarados (uma hospedagem que invente um nome) NÃO pode segurar o site.
 */
foreach ( array( 'production', '', 'producao-cliente' ) as $ambiente_wp ) {
	medir( $nome );

	$v = F3Base_Imp_Lotes::veredito_de_indexacao( f3b_ambiente_medido( array( 'ambiente_wp' => $ambiente_wp ) ) );

	if ( 1 !== $v['valor'] ) {
		anotar( $nome, 'piso do falso positivo: wp_get_environment_type() = "' . $ambiente_wp . '" segurou a indexação, e só local/development/staging podem — o resto é site de produção com nome diferente' );
	}
}

/* PISO DO SUFIXO DE PRÉVIA: casamento por sufixo de DOMÍNIO, nunca por trecho. */
$casos_sufixo = array(
	array( 'projeto.wpengine.com', array( 'wpengine.com' ), 'wpengine.com', 'subdomínio casa' ),
	array( 'wpengine.com', array( 'wpengine.com' ), 'wpengine.com', 'o próprio domínio casa' ),
	array( 'projeto.wpengine.com', array( '*.wpengine.com' ), 'wpengine.com', 'sufixo declarado com asterisco casa' ),
	array( 'projeto.wpengine.com', array( '.wpengine.com' ), 'wpengine.com', 'sufixo declarado com ponto casa' ),
	array( 'meusite.wpengine.com.br', array( 'wpengine.com' ), '', 'outro domínio que só CONTÉM o sufixo não casa — é outro dono' ),
	array( 'naowpengine.com', array( 'wpengine.com' ), '', 'host que termina com o sufixo sem a fronteira do ponto não casa' ),
	array( 'projeto.wpengine.com', array(), '', 'lista vazia não casa com nada' ),
	array( '', array( 'wpengine.com' ), '', 'host vazio não casa' ),
);

foreach ( $casos_sufixo as $caso ) {
	medir( $nome );

	$obtido = F3Base_Imp_Lotes::sufixo_de_previa( $caso[0], $caso[1] );

	if ( $caso[2] !== $obtido ) {
		anotar( $nome, 'sufixo de prévia (' . $caso[3] . '): esperado "' . $caso[2] . '", obtido "' . $obtido . '"' );
	}
}

/* A consequência acompanha o valor gravado, nos dois ramos do veredito. */
$producao_limpa = F3Base_Imp_Lotes::veredito_de_indexacao( f3b_ambiente_medido() );
$com_guarda     = F3Base_Imp_Lotes::veredito_de_indexacao( f3b_ambiente_medido( array( 'ambiente_wp' => 'local' ) ) );

medir( $nome );

if ( contem( $producao_limpa['consequencia'], 'Problema grave de SEO' ) ) {
	anotar( $nome, 'o ramo indexável trouxe o texto do aviso do wp-admin, que só existe quando blog_public = 0' );
}

medir( $nome );

if ( ! contem( $com_guarda['consequencia'], 'Problema grave de SEO' ) ) {
	anotar( $nome, 'o ramo com guarda ativa não nomeia a consequência no wp-admin: o operador fica com um alarme vermelho no painel e um relatório que não o explica' );
}

/* ---------- lotes.redirects_uniao: a fonte composta, teto e piso ---------- */

/*
 * O DEFEITO MEDIDO NO BANCO DEPOIS DA 1.0.11: `f3base_redirects` em `a:0:{}`
 * com o log da mesma execução afirmando "permalinks aplicada para
 * /%postname%/, com 2 URL(s) antiga(s) respondendo por redirecionamento
 * declarado". A option tinha DUAS fontes de valor desejado: a etapa de
 * permalinks computava os pares e gravava; mais adiante, a etapa
 * `site_core.options` gravava a mesma option a partir de `redirects: []` e
 * apagava os dois. As duas gravações leram de volta e conferiram.
 *
 * O piso cobre os dois lados da união e a colisão.
 */

$nome = 'lotes.redirects_uniao';

$par_declarado = array(
	'de'     => '/antigo/',
	'para'   => '/novo/',
	'status' => 301,
);
$par_computado = array(
	'de'     => '/blog/metodo/',
	'para'   => '/metodo/',
	'status' => 301,
);

/* O caso exato do defeito: configuração VAZIA não pode apagar o computado. */
$uniao = F3Base_Imp_Lotes::uniao_de_redirects( array(), array( $par_computado ), array(), array( 'pares' => array(), 'removidos' => array() ) );

medir( $nome );

if ( 1 !== count( $uniao['pares'] ) ) {
	anotar( $nome, 'o defeito medido: com redirects vazio na configuração, a união devolveu ' . count( $uniao['pares'] ) . ' par(es) — o par computado pela troca de permalinks foi apagado pela fonte que não sabia dele, e a URL antiga volta a responder 404' );
}

medir( $nome );

if ( 1 === count( $uniao['pares'] ) && 'computado' !== substr( (string) $uniao['pares'][0]['origem'], 0, 9 ) ) {
	anotar( $nome, 'o par computado foi preservado sem o carimbo de origem: sem ele a execução seguinte não sabe distinguir o que rederivar da configuração do que preservar' );
}

/* As três fontes juntas, e a ordem declarada. */
$tres = F3Base_Imp_Lotes::uniao_de_redirects(
	array( $par_declarado ),
	array( $par_computado ),
	array(
		array(
			'de'     => '/de-outra-execucao/',
			'para'   => '/atual/',
			'status' => 301,
			'origem' => 'computado:wordpress.permalinks',
		),
		array(
			'de'     => '/sem-carimbo/',
			'para'   => '/destino/',
			'status' => 301,
		),
	),
	array( 'pares' => array(), 'removidos' => array() )
);

medir( $nome );

if ( 4 !== count( $tres['pares'] ) ) {
	anotar( $nome, 'as três fontes juntas deveriam dar 4 pares e deram ' . count( $tres['pares'] ) . ': declarado + computado agora + computado de execução anterior + o que já estava gravado sem carimbo' );
}

medir( $nome );

if ( 1 !== (int) $tres['contagem']['declarado'] || 1 !== (int) $tres['contagem']['computado'] || 2 !== (int) $tres['contagem']['preexistente'] ) {
	anotar( $nome, 'a contagem por fonte saiu ' . wp_json_encode( $tres['contagem'] ) . ': o relatório precisa dizer QUANTOS pares vieram de cada fonte, senão a composição do valor volta a ser inferida' );
}

/* IDEMPOTÊNCIA: a segunda execução não recomputa e não pode apagar. */
$segunda = F3Base_Imp_Lotes::uniao_de_redirects(
	array(),
	array(),
	array( $par_computado + array( 'origem' => 'computado:wordpress.permalinks' ) ),
	array( 'pares' => array(), 'removidos' => array() )
);

medir( $nome );

if ( 1 !== count( $segunda['pares'] ) ) {
	anotar( $nome, 'idempotência: a execução seguinte, que não recomputa nada, apagou o par computado pela anterior — a URL antiga continua circulando muito depois da troca' );
}

/* Par gravado com origem `declarado` NÃO é preservado: a fonte dele é o arquivo. */
$removido = F3Base_Imp_Lotes::uniao_de_redirects(
	array(),
	array(),
	array( $par_declarado + array( 'origem' => 'declarado' ) ),
	array( 'pares' => array(), 'removidos' => array() )
);

medir( $nome );

if ( array() !== $removido['pares'] ) {
	anotar( $nome, 'par removido da configuração sobreviveu na option: o que é declarado é rederivado do arquivo a cada execução, e preservá-lo faria a remoção não ter efeito nenhum' );
}

/* COLISÃO: declarado × computado na mesma origem é FALHA nomeando os dois. */
$colisao = F3Base_Imp_Lotes::uniao_de_redirects(
	array( array( 'de' => '/x/', 'para' => '/declarado/', 'status' => 301 ) ),
	array( array( 'de' => '/x/', 'para' => '/computado/', 'status' => 301 ) ),
	array(),
	array( 'pares' => array(), 'removidos' => array() )
);

medir( $nome );

if ( 1 !== count( $colisao['colisoes'] ) ) {
	anotar( $nome, 'colisão de origem entre um par declarado e um computado não foi acusada: sobrescrita silenciosa é exatamente o que esta release corrige' );
}

$veredito_colisao = F3Base_Imp_Lotes::veredito_da_uniao_de_redirects( $colisao );

medir( $nome );

if ( 'FALHA' !== $veredito_colisao['estado'] ) {
	anotar( $nome, 'colisão de origem fechou ' . $veredito_colisao['estado'] . ' em vez de FALHA' );
}

foreach ( array( '/x/', '/declarado/', '/computado/' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $veredito_colisao['motivo'], $trecho ) ) {
		anotar( $nome, 'a mensagem da colisão não nomeia "' . $trecho . '": os DOIS destinos saem nomeados, ou o operador não tem como decidir qual das duas afirmações vale' );
	}
}

medir( $nome );

if ( 1 !== count( $colisao['pares'] ) || '/declarado/' !== $colisao['pares'][0]['para'] ) {
	anotar( $nome, 'na colisão, o par gravado não foi o DECLARADO: a configuração é a afirmação explícita do operador, e o que muda é que a divergência sai nomeada em vez de silenciosa' );
}

$veredito_limpo = F3Base_Imp_Lotes::veredito_da_uniao_de_redirects( $tres );

medir( $nome );

if ( 'OK' !== $veredito_limpo['estado'] ) {
	anotar( $nome, 'a união sem colisão fechou ' . $veredito_limpo['estado'] . ' em vez de OK — toda checagem emite nos dois ramos' );
}

foreach ( array( 'fonte COMPOSTA', 'declarado', 'computado', 'preservado' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $veredito_limpo['motivo'], $trecho ) ) {
		anotar( $nome, 'a mensagem da união sem colisão não menciona "' . $trecho . '": a composição do valor precisa ser LIDA no relatório, não inferida de duas mensagens distantes' );
	}
}

/*
 * O DEFEITO MEDIDO NA 1.0.19, e o piso desta release: o par que o AGENTE
 * apagou da option voltava na execução seguinte, porque a união o rederivava da
 * configuração (ou de uma etapa que o recomputa) sem olhar o que o pacote tinha
 * aplicado por último. Quem opera o site pelo canal apagava um 301 obsoleto e
 * ele ressuscitava, sem nada no relatório.
 */

/* PISO: par declarado que estava na base e sumiu do observado NÃO volta. */
$apagado = F3Base_Imp_Lotes::uniao_de_redirects(
	array( $par_declarado ),
	array(),
	array(),
	array(
		'pares'     => array( $par_declarado + array( 'origem' => 'declarado' ) ),
		'removidos' => array(),
	)
);

medir( $nome );

if ( array() !== $apagado['pares'] ) {
	anotar( $nome, 'piso: o par declarado que estava na base e não está mais no observado VOLTOU na união — quem opera o site apagou o 301 pelo canal e a reexecução o ressuscitou' );
}

medir( $nome );

if ( 1 !== count( $apagado['removidos'] ) || '/antigo/' !== (string) ( $apagado['removidos'][0]['de'] ?? '' ) ) {
	anotar( $nome, 'piso: a remoção não ficou registrada nomeando o endereço de origem — sem o registro, a execução seguinte não tem como saber que não deve recriá-lo' );
}

medir( $nome );

if ( F3Base_Imp_Lotes::REDIRECT_REMOVIDO !== (string) ( $apagado['removidos'][0]['origem'] ?? '' ) ) {
	anotar( $nome, 'piso: o par removido não saiu com a origem ' . F3Base_Imp_Lotes::REDIRECT_REMOVIDO );
}

$veredito_apagado = F3Base_Imp_Lotes::veredito_da_uniao_de_redirects( $apagado );

medir( $nome );

if ( ! contem( $veredito_apagado['motivo'], '/antigo/' ) ) {
	anotar( $nome, 'piso: o relatório não NOMEIA o par que deixou de voltar — ausência sem autor declarado é indistinguível de esquecimento: ' . $veredito_apagado['motivo'] );
}

/* PISO: par COMPUTADO por uma etapa também não ressuscita o que foi removido. */
$apagado_computado = F3Base_Imp_Lotes::uniao_de_redirects(
	array(),
	array( $par_computado ),
	array(),
	array(
		'pares'     => array( $par_computado + array( 'origem' => 'computado:wordpress.permalinks' ) ),
		'removidos' => array(),
	)
);

medir( $nome );

if ( array() !== $apagado_computado['pares'] ) {
	anotar( $nome, 'piso: o par COMPUTADO por uma etapa desta execução ressuscitou o que o agente tinha apagado — a subtração precisa vencer as três fontes, não só a declarada' );
}

/* A EXECUÇÃO SEGUINTE não ressuscita: a lista durável de removidos segura. */
$terceira = F3Base_Imp_Lotes::uniao_de_redirects(
	array( $par_declarado ),
	array(),
	array(),
	array(
		'pares'     => array(),
		'removidos' => array( '/antigo/' ),
	)
);

medir( $nome );

if ( array() !== $terceira['pares'] ) {
	anotar( $nome, 'piso: na execução seguinte o par voltou — a lista de removidos precisa ser DURÁVEL, senão a subtração vale por uma execução só e o par ressuscita na outra' );
}

medir( $nome );

if ( array( '/antigo/' ) !== $terceira['removidos_de'] ) {
	anotar( $nome, 'a lista de removidos não foi devolvida para a base: sem ela a próxima execução perde a memória da remoção' );
}

/* TETO DA REGRA: refazer o par pelo canal o traz de volta e apaga a marca. */
$refeito = F3Base_Imp_Lotes::uniao_de_redirects(
	array( $par_declarado ),
	array(),
	array( $par_declarado + array( 'origem' => 'preexistente' ) ),
	array(
		'pares'     => array(),
		'removidos' => array( '/antigo/' ),
	)
);

medir( $nome );

if ( 1 !== count( $refeito['pares'] ) || '/antigo/' !== (string) $refeito['pares'][0]['de'] ) {
	anotar( $nome, 'teto: o par REFEITO por quem opera o site não voltou a existir — a marca de removido não pode ser permanente, ou a única saída viraria uma release' );
}

medir( $nome );

if ( array() !== $refeito['removidos_de'] ) {
	anotar( $nome, 'teto: o par refeito continuou na lista de removidos, e a marca voltaria a apagá-lo na execução seguinte' );
}

/* TETO: sem remoção nenhuma, a mensagem diz isso e não inventa subtração. */
medir( $nome );

if ( ! contem( $veredito_limpo['motivo'], 'Nenhum par removido' ) ) {
	anotar( $nome, 'teto: a união sem remoção nenhuma não DIZ que não houve remoção — silêncio ali é indistinguível de a medição não existir: ' . $veredito_limpo['motivo'] );
}

/* Par sem destino não vira redirect para lugar nenhum. */
medir( $nome );

if ( array() !== F3Base_Imp_Lotes::uniao_de_redirects( array( array( 'de' => '/y/', 'para' => '' ) ), array(), array(), array( 'pares' => array(), 'removidos' => array() ) )['pares'] ) {
	anotar( $nome, 'par sem destino entrou na união: redirect para cadeia vazia é 301 para lugar nenhum' );
}

/* O REGISTRO das etapas carimba a origem, e é esquecível entre execuções. */
F3Base_Imp_Lotes::esquecer_redirects_computados();
F3Base_Imp_Lotes::registrar_redirects_computados( array( $par_computado ), 'wordpress.permalinks' );

$registrados = F3Base_Imp_Lotes::redirects_computados();

medir( $nome );

if ( 1 !== count( $registrados ) || 'computado:wordpress.permalinks' !== (string) $registrados[0]['origem'] ) {
	anotar( $nome, 'o registro de par computado não carimbou a ETAPA na origem: sem o nome da etapa, o par preservado não diz quem o produziu' );
}

F3Base_Imp_Lotes::esquecer_redirects_computados();

medir( $nome );

if ( array() !== F3Base_Imp_Lotes::redirects_computados() ) {
	anotar( $nome, 'o registro de pares computados não é esquecível: o acúmulo de uma execução vazaria para a seguinte' );
}

/* ---------- lotes.encerramento_por_estado: o texto de cada ramo, no ramo certo ---------- */

/*
 * O defeito medido na 1.0.10: a execução fechou em SUCESSO_APLICACAO, com zero
 * FALHA, e a última frase do log foi "Em falha o implantador permanece ativo,
 * preserva o log e oferece retomada idempotente e rollback das mutações
 * reversíveis." — parágrafo do ramo de falha impresso no ramo de sucesso.
 *
 * O piso é dos dois lados: o texto de falha não pode aparecer em
 * SUCESSO_APLICACAO, e o de sucesso não pode aparecer em FALHA_PARCIAL.
 */

$nome = 'lotes.encerramento_por_estado';

$da_falha   = array( 'PERMANECE ATIVO', 'retomada idempotente', 'rollback' );
$do_sucesso = array( 'autodesativou', 'site-core', 'MCP' );

$sucesso_desativado = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::SUCESSO, true );
$sucesso_ativo      = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::SUCESSO, false );
$falha_parcial      = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::FALHA_PARCIAL, false );
$falha              = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::FALHA, false );

foreach ( array( 'SUCESSO_APLICACAO com autodesativação' => $sucesso_desativado, 'SUCESSO_APLICACAO sem autodesativação' => $sucesso_ativo ) as $rotulo => $texto ) {
	foreach ( $da_falha as $trecho ) {
		medir( $nome );

		if ( contem( $texto, $trecho ) ) {
			anotar( $nome, $rotulo . ': o texto do ramo de FALHA apareceu no ramo de sucesso — trouxe "' . $trecho . '"' );
		}
	}
}

foreach ( $do_sucesso as $trecho ) {
	medir( $nome );

	if ( ! contem( $sucesso_desativado, $trecho ) ) {
		anotar( $nome, 'SUCESSO_APLICACAO com autodesativação: o texto não menciona "' . $trecho . '" — o ramo de sucesso precisa dizer o que aconteceu e o que o operador usa a partir de agora' );
	}
}

foreach ( array( 'FALHA_PARCIAL' => $falha_parcial, 'FALHA' => $falha ) as $rotulo => $texto ) {
	foreach ( $da_falha as $trecho ) {
		medir( $nome );

		if ( ! contem( $texto, $trecho ) ) {
			anotar( $nome, $rotulo . ': o texto do ramo de falha não menciona "' . $trecho . '"' );
		}
	}

	foreach ( array( 'autodesativou', 'MCP' ) as $trecho ) {
		medir( $nome );

		if ( contem( $texto, $trecho ) ) {
			anotar( $nome, $rotulo . ': o texto do ramo de SUCESSO apareceu no ramo de falha — trouxe "' . $trecho . '"' );
		}
	}
}

medir( $nome );

if ( $sucesso_desativado === $sucesso_ativo ) {
	anotar( $nome, 'sucesso com e sem autodesativação devolveram o MESMO texto: o log precisa dizer se o implantador saiu de cena ou continua ativo' );
}


/* ---------- preflight.limites_veredito: o estado sai da MEDIÇÃO, nos dois lados ---------- */

/*
 * O defeito medido na 1.0.14: esta linha era WARN incondicional. Ela dizia de
 * si mesma "fato de ambiente, relatado sem decidir gate" e promovia a unidade
 * do preflight a amarelo numa execução em que nada estava errado.
 *
 * Teto: limites folgados fecham OK NOMEANDO os valores. Piso: cada limite
 * abaixo do piso declarado fecha WARN nomeando QUAL e o que ele custa — e
 * `max_execution_time = 0` é ausência de limite, nunca limite zero.
 */

$nome = 'preflight.limites_veredito';

$piso_declarado = array(
	'max_execution_time_s'   => 30,
	'memory_mb'              => 128,
	'upload_max_filesize_mb' => 8,
	'post_max_size_mb'       => 8,
);

$folgado = array(
	'max_execution_time'  => 120,
	'memory_limit'        => '512M',
	'memoria_bytes'       => 512 * 1048576,
	'upload_max_filesize' => '64M',
	'upload_bytes'        => 64 * 1048576,
	'post_max_size'       => '64M',
	'post_bytes'          => 64 * 1048576,
);

$veredito = F3Base_Imp_Lotes::veredito_de_limites( $folgado, $piso_declarado );

medir( $nome );

if ( 'OK' !== $veredito['estado'] ) {
	anotar( $nome, 'teto: limites folgados fecharam ' . $veredito['estado'] . ' — medição sem achado adverso precisa fechar OK, senão a linha vira ruído amarelo' );
}

foreach ( array( '120s', '512M', '64M' ) as $valor ) {
	medir( $nome );

	if ( ! contem( $veredito['motivo'], $valor ) ) {
		anotar( $nome, 'teto: o ramo OK não NOMEIA o valor medido "' . $valor . '" — o detalhe não pode sumir junto com o WARN' );
	}
}

medir( $nome );

if ( array() !== $veredito['abaixo'] ) {
	anotar( $nome, 'teto: limites folgados produziram achado — ' . implode( ' | ', $veredito['abaixo'] ) );
}

/* `max_execution_time = 0` é AUSÊNCIA de limite: não pode ser lido como zero. */
$sem_limite            = $folgado;
$sem_limite['max_execution_time'] = 0;
$veredito_sem_limite   = F3Base_Imp_Lotes::veredito_de_limites( $sem_limite, $piso_declarado );

medir( $nome );

if ( 'OK' !== $veredito_sem_limite['estado'] ) {
	anotar( $nome, 'piso do falso positivo: max_execution_time = 0 é ausência de limite e fechou ' . $veredito_sem_limite['estado'] );
}

medir( $nome );

if ( ! contem( $veredito_sem_limite['motivo'], 'sem limite' ) ) {
	anotar( $nome, 'piso do falso positivo: o texto não diz que max_execution_time = 0 é ausência de limite' );
}

/* Cada limite, um a um, abaixo do piso: WARN nomeando QUAL e o custo. */
$apertados = array(
	'max_execution_time' => array( 'campo' => 'max_execution_time', 'valor' => 10, 'agulha' => 'max_execution_time 10s', 'custo' => 'retomada refaz a etapa inteira' ),
	'memoria'            => array( 'campo' => 'memoria_bytes', 'valor' => 32 * 1048576, 'agulha' => 'memory_limit', 'custo' => 'morre sem relatório' ),
	'upload'             => array( 'campo' => 'upload_bytes', 'valor' => 2 * 1048576, 'agulha' => 'upload_max_filesize', 'custo' => 'recusado pelo próprio PHP' ),
	'post'               => array( 'campo' => 'post_bytes', 'valor' => 2 * 1048576, 'agulha' => 'post_max_size', 'custo' => 'não cabe' ),
);

foreach ( $apertados as $rotulo => $caso ) {
	$medido                  = $folgado;
	$medido[ $caso['campo'] ] = $caso['valor'];

	if ( 'memoria_bytes' === $caso['campo'] ) {
		$medido['memory_limit'] = '32M';
	}

	if ( 'upload_bytes' === $caso['campo'] ) {
		$medido['upload_max_filesize'] = '2M';
	}

	if ( 'post_bytes' === $caso['campo'] ) {
		$medido['post_max_size'] = '2M';
	}

	$apertado = F3Base_Imp_Lotes::veredito_de_limites( $medido, $piso_declarado );

	medir( $nome );

	if ( 'WARN' !== $apertado['estado'] ) {
		anotar( $nome, $rotulo . ': limite abaixo do piso declarado fechou ' . $apertado['estado'] . ' em vez de WARN' );
	}

	medir( $nome );

	if ( 1 !== count( $apertado['abaixo'] ) ) {
		anotar( $nome, $rotulo . ': ' . count( $apertado['abaixo'] ) . ' achado(s) onde só um limite ficou abaixo do piso' );
	}

	medir( $nome );

	if ( ! contem( $apertado['motivo'], $caso['agulha'] ) ) {
		anotar( $nome, $rotulo . ': o WARN não NOMEIA qual limite ficou abaixo do piso' );
	}

	medir( $nome );

	if ( ! contem( $apertado['motivo'], $caso['custo'] ) ) {
		anotar( $nome, $rotulo . ': o WARN não diz o que o limite abaixo do piso CUSTA' );
	}
}

/* ---------- conteudo.guarda_de_marca: a declaracao e o arquivo, nos dois lados ---------- */

/*
 * A saída barata que esta guarda fecha: desligar `conteudo.demonstrativo` para
 * calar o aviso e não trocar o conteúdo. Aí a configuração afirma que o texto é
 * do site e o arquivo continua sendo o do template — uma das duas está mentindo,
 * e a que vai ao ar é a errada.
 */

$nome = 'conteudo.guarda_de_marca';

$marca_do_template = F3Base_Imp_Conteudo::marca_demonstrativa( 'f3base' );

medir( $nome );

if ( 'f3base:conteudo-demonstrativo' !== $marca_do_template ) {
	anotar( $nome, 'a marca não é montada a partir do prefixo declarado: veio "' . $marca_do_template . '"' );
}

medir( $nome );

if ( '' !== F3Base_Imp_Conteudo::marca_demonstrativa( '' ) ) {
	anotar( $nome, 'sem prefixo declarado não existe marca a procurar, e a função devolveu uma' );
}

/*
 * A MARCA MUDA COM O PREFIXO, e é isto que impede a marca do template de
 * sobreviver dentro do site do cliente. O prefixo de teste aqui é literal e
 * deliberadamente diferente do declarado: é o outro site da operação.
 */
$outro_prefixo = 'siteb';

medir( $nome );

if ( $outro_prefixo . ':conteudo-demonstrativo' !== F3Base_Imp_Conteudo::marca_demonstrativa( $outro_prefixo ) ) {
	anotar( $nome, 'a marca não acompanha o prefixo do site: dois sites diferentes teriam a mesma marca' );
}

$com_marca = $marca_do_template . " -->\n<!-- wp:heading -->\n<h2>O que é o método</h2>\n";
$sem_marca = "<!-- wp:heading -->\n<h2>Serviços de fundação</h2>\n";

$casos_da_guarda = array(
	'desligado com a marca no arquivo' => array( $com_marca, false, 'f3base', true ),
	'desligado sem a marca'            => array( $sem_marca, false, 'f3base', false ),
	'ligado com a marca'               => array( $com_marca, true, 'f3base', false ),
	'ligado sem a marca'               => array( $sem_marca, true, 'f3base', false ),
	'sem prefixo declarado'            => array( $com_marca, false, '', false ),
	'prefixo trocado'                  => array( $com_marca, false, $outro_prefixo, false ),
);

foreach ( $casos_da_guarda as $rotulo => $caso ) {
	list( $texto, $declarado, $prefixo, $espera_recusa ) = $caso;

	$motivo = F3Base_Imp_Conteudo::guarda_de_marca_demonstrativa( $texto, $declarado, $prefixo, 'content/pages/home.html' );

	medir( $nome );

	if ( $espera_recusa && '' === $motivo ) {
		anotar( $nome, $rotulo . ': a guarda deixou publicar um arquivo que ainda é o do template com a configuração afirmando que não é' );
	}

	medir( $nome );

	if ( ! $espera_recusa && '' !== $motivo ) {
		anotar( $nome, $rotulo . ': a guarda recusou um caso legítimo — ' . $motivo );
	}
}

/* A recusa NOMEIA o arquivo, a marca e as duas saídas: recusa sem caminho de saída é beco. */
$recusa = F3Base_Imp_Conteudo::guarda_de_marca_demonstrativa( $com_marca, false, 'f3base', 'content/pages/home.html' );

foreach ( array( 'content/pages/home.html', 'f3base:conteudo-demonstrativo', 'Troque o conteúdo', 'conteudo.demonstrativo = true' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $recusa, $trecho ) ) {
		anotar( $nome, 'a recusa não traz "' . $trecho . '": ela precisa nomear o arquivo, a marca e as duas saídas' );
	}
}


/* ---------- relatorio.contagem_colada_no_estado: o número diz de quem ele é ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.17, na linha do encerramento: `5 em FALHA: nenhum ·
 * BLOCKED: … · WARN: …`. Três coisas erradas de uma vez — o 5 era FALHA MAIS
 * BLOCKED somados, ele encostava no PRIMEIRO estado da string (e quem lê casa
 * número com a primeira palavra, então lia "5 em FALHA" ao lado de "FALHA:
 * nenhum"), e a mesma string ainda listava WARN, que não estava nos cinco.
 *
 * TETO: cada número sai colado ao estado que ele conta.
 * PISO: a forma antiga — soma de dois estados encostada no primeiro — não pode
 * voltar a aparecer.
 */
$nome = 'relatorio.contagem_colada_no_estado';

$contagem_medida = array( 'OK' => 40, 'FALHA' => 0, 'BLOCKED' => 5, 'N/A' => 2, 'WAIVED' => 0, 'WARN' => 1 );
$nomes_medidos   = array(
	'OK'      => array(),
	'FALHA'   => array(),
	'BLOCKED' => array( 'mcp.canal_configurado', 'orcamento.pagina', 'entrega.rodada_limpa', 'origem.rota_carimbada', 'desempenho.core_web_vitals' ),
	'N/A'     => array( 'handoff.pacote_de_entrega', 'formulario.regime_cf7' ),
	'WAIVED'  => array(),
	'WARN'    => array( 'conteudo.demonstrativo' ),
);

$resumo_medido = F3Base_Imp_Relatorio::resumo_por_estado( $contagem_medida, $nomes_medidos );

foreach ( array( 'FALHA: 0', 'BLOCKED: 5', 'WARN: 1' ) as $par ) {
	medir( $nome );

	if ( ! contem( $resumo_medido, $par ) ) {
		anotar( $nome, 'teto: o resumo não traz "' . $par . '" — cada número tem de sair colado ao estado que ele conta' );
	}
}

/* PISO: a soma de FALHA com BLOCKED encostada no primeiro estado não pode existir. */
medir( $nome );

if ( 1 === preg_match( '/\b5\s+em\s+FALHA\b/u', $resumo_medido ) ) {
	anotar( $nome, 'piso: a forma da 1.0.17 voltou — "5 em FALHA: nenhum" com o 5 sendo FALHA mais BLOCKED, encostado no estado errado' );
}

/* PISO: os nomes de WARN não podem viajar dentro do segmento de FALHA nem do de BLOCKED. */
medir( $nome );

$segmento_de_falha = (string) ( explode( '|', $resumo_medido )[1] ?? '' );

if ( contem( $segmento_de_falha, 'conteudo.demonstrativo' ) ) {
	anotar( $nome, 'piso: o nome de uma checagem em WARN apareceu dentro do segmento de FALHA — foi assim que a linha da 1.0.17 listou WARN dentro de uma contagem que não o continha' );
}

/* TETO: OK continua resumido, sem lista de nomes. */
medir( $nome );

if ( ! contem( $resumo_medido, 'OK: 40' ) ) {
	anotar( $nome, 'teto: o resumo deixou de trazer a contagem de OK colada ao estado' );
}

F3Base_Imp_Relatorio::zerar();

/* ---------- plugins.autoupdate_caminho_separado: flag e caminho não são o mesmo fato ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.17: a etapa gravava `auto_update_plugins` e RELIA A
 * MESMA OPTION para conferir — a flag conferida contra si mesma — e o relatório
 * saía dizendo "atualização automática ligada" sobre nove plugins sem dizer por
 * onde cada um seria atualizado.
 *
 * E O DEFEITO QUE A PRIMEIRA CORREÇÃO CRIOU, medido em produção na 1.1.6: a
 * classe `pendente` fazia BLOCKED, e ela cobria tudo o que "só se decide por
 * rede". Nove plugins, quatro sem-fonte e cinco pendentes, unidade inteira
 * PROMOVIDA para BLOCKED em toda execução, sem que nada estivesse errado.
 * Limite da medição não é pré-condição ausente: ninguém tem ação a tomar, e
 * aviso que sai sempre é aviso que ninguém lê.
 *
 * TETO: todo plugin numa classe ESPERADA fecha OK, e a mensagem NOMEIA cada
 * grupo — artefato do pacote, origem url/bundle, e os que dependem do
 * WordPress.org por slug.
 * PISO: `Update URI` para host de terceiro SEM `update_plugins_{host}`
 * registrado é a promessa quebrada MEDIDA — WARN nomeando plugin e host —, o
 * cabeçalho decide ANTES da origem declarada, e escopo vazio continua BLOCKED.
 */
$nome = 'plugins.autoupdate_caminho_separado';

/*
 * OS SLUGS SAEM DA CONFIGURAÇÃO E DO PACOTE, nunca de literal: escrito à mão,
 * este bloco reprovaria o pacote RENOMEADO — que é o único caso em que a regra
 * de prefixo é exercitada de verdade.
 */
$esperado_por_slug = array();

foreach ( F3Base_Imp_Decisoes::bloco( 'plugins.instalaveis' ) as $i => $entrada ) {
	unset( $entrada );

	$slug_declarado   = F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $i, 'slug' );
	$origem_declarada = F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $i, 'origem' );

	$esperado_por_slug[ $slug_declarado ] = in_array( $origem_declarada, array( 'url', 'bundle' ), true )
		? 'upload-do-fornecedor'
		: 'wordpress-org';
}

/*
 * O PLUGIN OPERACIONAL É DECLARADO NA BANCADA. Lido do arquivo do projeto, o
 * caso só existia enquanto ALGUM projeto declarasse um plugin operacional — e
 * `plugins_operacionais` nasce vazia, como todo campo do operador. O laço
 * passava a somar zero entradas e a regra "plugin do cliente segue pelo caminho
 * do WordPress.org" deixava de ser exercitada, sem que nada dissesse isso.
 */
$esperado_por_slug['plugin-operacional-da-bancada'] = 'wordpress-org';

foreach ( F3Base_Imp_Preflight::artefatos_do_pacote() as $artefato ) {
	$esperado_por_slug[ (string) $artefato['slug'] ] = 'artefato-do-pacote';
}

/* Sem cabeçalho medido, quem classifica é a origem declarada na configuração. */
$caminhos_medidos = F3Base_Imp_Plugins::caminhos_declarados( array_keys( $esperado_por_slug ) );

$slug_do_servidor = F3Base_Imp_Entrega::slug_por_papel( 'canal-mcp-servidor' );

foreach ( $esperado_por_slug as $slug => $classe ) {
	medir( $nome );

	if ( $classe !== ( $caminhos_medidos[ $slug ]['classe'] ?? '' ) ) {
		anotar( $nome, $slug . ': classificado como "' . ( $caminhos_medidos[ $slug ]['classe'] ?? 'ausente' ) . '" e o esperado era "' . $classe . '"' );
	}
}

/*
 * O SERVIDOR do canal entra na mesma classe do complemento. `README.md` já
 * ressalvava o complemento e ESQUECIA o servidor, instalado pela MESMA URL — o
 * esquecimento é o achado, e o piso o congela: ele NÃO pode ser contado entre
 * os que dependem do WordPress.org por slug.
 */
medir( $nome );

if ( 'upload-do-fornecedor' !== ( $caminhos_medidos[ $slug_do_servidor ]['classe'] ?? '' ) ) {
	anotar( $nome, 'piso: o SERVIDOR do canal (' . $slug_do_servidor . ') saiu como "' . ( $caminhos_medidos[ $slug_do_servidor ]['classe'] ?? 'ausente' ) . '" — ele desce da mesma URL que o complemento, e a ressalva do README esquecia justamente ele' );
}

/*
 * TETO: com todo mundo numa classe esperada, o veredito é OK — e a mensagem
 * NOMEIA cada grupo. Comportamento declarado pelo próprio pacote, que ninguém
 * vai mudar e para o qual ninguém tem ação, NÃO é pendência.
 */
$caminho_ok = F3Base_Imp_Plugins::veredito_do_caminho( $caminhos_medidos );

medir( $nome );

if ( 'OK' !== $caminho_ok['estado'] ) {
	anotar( $nome, 'teto: o escopo inteiro nas classes esperadas fechou ' . $caminho_ok['estado'] . ' em vez de OK — desenho declarado do pacote não é pendência de ninguém' );
}

foreach ( array( 'ARTEFATO DESTE PACOTE', 'ORIGEM url/bundle DECLARADA', 'DEPENDEM DO WORDPRESS.ORG POR SLUG', $slug_do_servidor, 'FLAG e CAMINHO DE ATUALIZAÇÃO' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $caminho_ok['motivo'], $trecho ) ) {
		anotar( $nome, 'teto: a mensagem do caminho de atualização não traz "' . $trecho . '" — grupo não nomeado é contagem sem nome' );
	}
}

/* E ela NÃO pode afirmar mais do que mediu: a consulta de rede não aconteceu. */
medir( $nome );

if ( ! contem( $caminho_ok['motivo'], 'nenhuma consulta de rede acontece aqui' ) ) {
	anotar( $nome, 'teto: a mensagem não declara que a medição é local — afirmar que a fonte respondeu seria afirmar o que não foi medido' );
}

/*
 * PISO DA PROMESSA QUEBRADA, e é o achado adverso desta linha: `Update URI`
 * para host de terceiro e NENHUM filtro `update_plugins_{host}` registrado. É o
 * único caso em que a flag ligada engana.
 */
$com_promessa_quebrada = F3Base_Imp_Plugins::caminhos_declarados(
	array_keys( $esperado_por_slug ),
	array(
		$slug_do_servidor => array(
			'update_uri' => 'https://plugins.exemplo-terceiro.test/wp-mcp-ultimate.json',
			'host'       => 'plugins.exemplo-terceiro.test',
			'gancho'     => 'update_plugins_plugins.exemplo-terceiro.test',
			'filtro'     => false,
		),
	)
);

medir( $nome );

if ( 'promessa-quebrada' !== ( $com_promessa_quebrada[ $slug_do_servidor ]['classe'] ?? '' ) ) {
	anotar( $nome, 'piso: Update URI de host de terceiro SEM filtro registrado saiu como "' . ( $com_promessa_quebrada[ $slug_do_servidor ]['classe'] ?? 'ausente' ) . '" — o cabeçalho decide antes da origem declarada, porque é ele que o núcleo obedece' );
}

$caminho_warn = F3Base_Imp_Plugins::veredito_do_caminho( $com_promessa_quebrada );

medir( $nome );

if ( 'WARN' !== $caminho_warn['estado'] ) {
	anotar( $nome, 'piso: a promessa quebrada MEDIDA fechou ' . $caminho_warn['estado'] . ' em vez de WARN — a flag ligada prometendo o que não entrega é achado adverso' );
}

foreach ( array( 'PROMESSA QUEBRADA', $slug_do_servidor, 'plugins.exemplo-terceiro.test' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $caminho_warn['motivo'], $trecho ) ) {
		anotar( $nome, 'piso: o WARN da promessa quebrada não nomeia "' . $trecho . '" — plugin e host precisam sair pelo nome' );
	}
}

/*
 * TETO DO OUTRO LADO: o MESMO cabeçalho, com o filtro registrado, deixa de ser
 * achado. É o filtro que decide, e não o host.
 */
$com_atualizador = F3Base_Imp_Plugins::caminhos_declarados(
	array_keys( $esperado_por_slug ),
	array(
		$slug_do_servidor => array(
			'update_uri' => 'https://plugins.exemplo-terceiro.test/wp-mcp-ultimate.json',
			'host'       => 'plugins.exemplo-terceiro.test',
			'gancho'     => 'update_plugins_plugins.exemplo-terceiro.test',
			'filtro'     => true,
		),
	)
);

medir( $nome );

if ( 'atualizador-do-fornecedor' !== ( $com_atualizador[ $slug_do_servidor ]['classe'] ?? '' ) ) {
	anotar( $nome, 'teto: Update URI de terceiro COM o filtro registrado saiu como "' . ( $com_atualizador[ $slug_do_servidor ]['classe'] ?? 'ausente' ) . '" — quem responde ali é o atualizador do fornecedor, e ele está de pé' );
}

medir( $nome );

if ( 'OK' !== F3Base_Imp_Plugins::veredito_do_caminho( $com_atualizador )['estado'] ) {
	anotar( $nome, 'teto: com o atualizador do fornecedor de pé o veredito deixou de ser OK — a promessa não está quebrada quando alguém responde pelo gancho' );
}

/* O cabeçalho de host wordpress.org NÃO é desvio: quem responde é o próprio .org. */
$com_uri_do_org = F3Base_Imp_Plugins::caminhos_declarados(
	array_keys( $esperado_por_slug ),
	array(
		$slug_do_servidor => array(
			'update_uri' => 'https://wordpress.org/plugins/wp-mcp-ultimate/',
			'host'       => 'wordpress.org',
			'gancho'     => 'update_plugins_wordpress.org',
			'filtro'     => false,
		),
	)
);

medir( $nome );

if ( 'promessa-quebrada' === ( $com_uri_do_org[ $slug_do_servidor ]['classe'] ?? '' ) ) {
	anotar( $nome, 'piso do falso positivo: Update URI apontando para o próprio wordpress.org virou promessa quebrada — ali quem responde é o WordPress.org, e não um filtro' );
}

/* Update URI sem host legível é o artefato DESLIGANDO a consulta, e não achado. */
$com_uri_sem_host = F3Base_Imp_Plugins::caminhos_declarados(
	array_keys( $esperado_por_slug ),
	array(
		$slug_do_servidor => array(
			'update_uri' => 'false',
			'host'       => '',
			'gancho'     => '',
			'filtro'     => false,
		),
	)
);

medir( $nome );

if ( 'sem-consulta-declarada' !== ( $com_uri_sem_host[ $slug_do_servidor ]['classe'] ?? '' ) ) {
	anotar( $nome, 'piso do falso positivo: Update URI sem host legível saiu como "' . ( $com_uri_sem_host[ $slug_do_servidor ]['classe'] ?? 'ausente' ) . '" — o valor false do núcleo desliga a consulta por declaração do próprio artefato' );
}

medir( $nome );

if ( 'OK' !== F3Base_Imp_Plugins::veredito_do_caminho( $com_uri_sem_host )['estado'] ) {
	anotar( $nome, 'piso do falso positivo: consulta desligada pelo próprio artefato virou estado adverso — declaração de terceiro para a qual ninguém tem ação não é pendência' );
}

/* PISO do escopo vazio: nada medido não aprova nada. */
medir( $nome );

if ( 'BLOCKED' !== F3Base_Imp_Plugins::veredito_do_caminho( array() )['estado'] ) {
	anotar( $nome, 'piso: escopo vazio aprovou o caminho de atualização — o que não foi medido não pode ser aprovado' );
}

/* ---------- mcp.autoteste_veredito: teto e piso do autoteste do canal ---------- */

/*
 * O DEFEITO MEDIDO: `README.md` afirmava que "files/selftest roda na entrega e
 * após toda mudança de PHP ou de hospedagem, com o resultado no relatório", e o
 * pacote inteiro não tinha uma chamada de execução — nem `wp_execute_ability`,
 * nem `rest_do_request`. A afirmação existia, o resultado não.
 *
 * O SEGUNDO DEFEITO MEDIDO, e ele fechava BLOCKED em toda instalação limpa: o
 * despacho procurava a Abilities API por `function_exists( 'wp_execute_ability' )`,
 * e essa função NÃO EXISTE na API — nem na nativa do 6.9, nem no polyfill que o
 * servidor MCP embarca, que expõem `wp_register_ability()`, `wp_get_abilities()`,
 * `wp_get_ability()` e `wp_has_ability()`, com a execução no MÉTODO do objeto.
 * A guarda era falsa sempre, o laço ficava morto, e a linha — que é do gate de
 * aplicação — segurava `mcp.canal_exposto` e a autodesativação junto.
 *
 * A REGRA DE CASAMENTO entre nome de habilidade e rota curta vivia DUAS VEZES,
 * uma decidindo a presença e outra decidindo a execução. É a mesma forma do
 * desencontro da 1.0.8, e agora ela mora num lugar só, com teto e piso aqui.
 *
 * TETO: rota presente que responde 2xx e sem item reprovado fecha OK.
 * PISO: rota AUSENTE fecha BLOCKED e nunca OK; rota que responde reprovando
 * fecha FALHA, que é o que reprova a entrega.
 */
$nome = 'mcp.autoteste_veredito';

/*
 * O CASAMENTO DO NOME, com as três grafias observadas em host real e com o que
 * NÃO pode casar. `files/selftest` é o nome exato que o servidor MCP registra;
 * as outras duas são convenções de prefixo de fornecedor.
 */
$casos_de_casamento = array(
	array( 'files/selftest', true, 'teto: o nome exato registrado no host medido' ),
	array( 'f3base/files/selftest', true, 'teto: o mesmo nome sob prefixo de fornecedor' ),
	array( 'f3base/files-selftest', true, 'teto: a grafia com hífen no lugar da barra' ),
	array( 'files/selftest-antigo', false, 'piso: sufixo a mais não é a mesma rota' ),
	array( 'outro/selftest', false, 'piso: o segmento files/ faz parte do nome' ),
	array( '', false, 'piso: nome vazio não casa com nada' ),
);

foreach ( $casos_de_casamento as $caso_de_casamento ) {
	medir( $nome );

	if ( F3Base_Imp_Entrega::casa_habilidade( $caso_de_casamento[0], 'files/selftest' ) !== $caso_de_casamento[1] ) {
		anotar(
			$nome,
			$caso_de_casamento[2] . ': "' . $caso_de_casamento[0] . '" casou '
				. ( $caso_de_casamento[1] ? 'não' : 'sim' ) . ' contra o esperado'
		);
	}
}

/*
 * PISO DA FUNÇÃO INVENTADA: a Abilities API não pode voltar a ser procurada por
 * `function_exists( 'wp_execute_ability' )` como CONDIÇÃO do despacho. A função
 * não existe na API, e a guarda sobre ela era falsa sempre.
 */
medir( $nome );

$fonte_da_entrega = (string) file_get_contents( $raiz . '/includes/class-f3base-imp-entrega.php' );

if ( 1 === preg_match( '/if\s*\(\s*function_exists\(\s*\x27wp_execute_ability\x27\s*\)\s*\)\s*\{\s*foreach/', $fonte_da_entrega ) ) {
	anotar( $nome, 'piso: o despacho voltou a depender de function_exists( wp_execute_ability ) para percorrer as habilidades — a função não existe na Abilities API, e a guarda fecha o caminho inteiro em todo host' );
}

medir( $nome );

if ( ! str_contains( $fonte_da_entrega, 'wp_get_ability(' ) ) {
	anotar( $nome, 'piso: a entrega não chama wp_get_ability() — sem o objeto da habilidade não sobra via canônica de despacho, e a linha volta a fechar BLOCKED em toda instalação limpa' );
}

/**
 * Monta a resposta de um despacho, na forma que o veredito recebe.
 *
 * @param int                 $codigo Código HTTP.
 * @param array<string,mixed> $corpo  Corpo devolvido.
 * @param bool                $executou Houve despacho.
 * @param string              $erro   Motivo quando não houve.
 * @return array{executou:bool,codigo:int,corpo:array<string,mixed>,erro:string,via:string}
 */
$despacho = static function ( int $codigo, array $corpo, bool $executou = true, string $erro = '' ): array {
	return array(
		'executou' => $executou,
		'codigo'   => $codigo,
		'corpo'    => $corpo,
		'erro'     => $erro,
		'via'      => 'servidor REST interno, rest_do_request( POST /mcp/files/selftest )',
	);
};

$casos_do_autoteste = array(
	'rota ausente' => array(
		false,
		$despacho( 0, array(), false ),
		'BLOCKED',
		array( 'NÃO está registrada', 'nunca OK' ),
	),
	'rota presente e aprovada' => array(
		true,
		$despacho( 200, array( 'ok' => true, 'php_lint' => true ) ),
		'OK',
		array( 'RODOU nesta execução', 'php_lint=true', 'recusa_credencial' ),
	),
	'rota presente e reprovada' => array(
		true,
		$despacho( 200, array( 'ok' => true, 'php_lint' => false ) ),
		'FALHA',
		array( 'REPROVOU', 'php_lint', 'PHP quebrado' ),
	),
	'rota presente com lista de falhas' => array(
		true,
		$despacho( 200, array( 'status' => 'ok', 'falhas' => array( 'lint' ) ) ),
		'FALHA',
		array( 'REPROVOU', 'falhas' ),
	),
	'rota presente com status de erro' => array(
		true,
		$despacho( 200, array( 'status' => 'error' ) ),
		'FALHA',
		array( 'REPROVOU', 'status=error' ),
	),
	'resposta 500' => array(
		true,
		$despacho( 500, array() ),
		'FALHA',
		array( 'código 500', 'o canal dizendo que não funciona' ),
	),
	'recusa por credencial' => array(
		true,
		$despacho( 403, array() ),
		'BLOCKED',
		array( 'RECUSOU o despacho interno', 'não carrega credencial' ),
	),
	'despacho que não aconteceu' => array(
		true,
		$despacho( 0, array(), false, 'nem a Abilities API nem rest_do_request() existem nesta instalação' ),
		'BLOCKED',
		array( 'não chegou a acontecer' ),
	),
);

foreach ( $casos_do_autoteste as $rotulo => $caso ) {
	$veredito = F3Base_Imp_Entrega::veredito_do_autoteste( $caso[0], $caso[1], 'wp-mcp-ultimate-complemento-fator3' );

	medir( $nome );

	if ( $caso[2] !== $veredito['estado'] ) {
		anotar( $nome, $rotulo . ': fechou ' . $veredito['estado'] . ' e o esperado era ' . $caso[2] );
	}

	foreach ( $caso[3] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $rotulo . ': a mensagem não traz "' . $trecho . '" — ' . $veredito['motivo'] );
		}
	}
}

/* O corpo sem campo legível NÃO pode virar afirmação sobre o que não foi lido. */
$sem_campo = F3Base_Imp_Entrega::ler_resultado_do_autoteste( array() );

medir( $nome );

if ( ! $sem_campo['aprovado'] ) {
	anotar( $nome, 'teto: corpo vazio com resposta 2xx foi tratado como reprovação, e a rota respondeu' );
}

medir( $nome );

if ( ! contem( $sem_campo['resumo'], 'sem campo legível' ) ) {
	anotar( $nome, 'teto: o corpo sem campo legível não é declarado como tal — adivinhar o vocabulário do complemento é afirmar o que não foi lido' );
}

/*
 * A PRESENÇA DA ROTA SAI DA UNIÃO DAS DUAS FONTES, e este é o defeito medido em
 * produção (2026-09-04, fator3-teste-mcp-1): a MESMA execução imprimiu
 * "files/selftest (habilidade files/selftest na Abilities API)" entre as doze
 * rotas REGISTRADAS e, três linhas abaixo, "pré-condição ausente: a rota
 * files/selftest NÃO está registrada neste site". A guarda lia só o servidor
 * REST; a unidade lia a união.
 *
 * TETO: rota que existe SÓ como habilidade — sem rota REST — é rota PRESENTE, e
 * a linha executa e fecha pelo resultado.
 * PISO: ausente nas DUAS fontes continua fechando BLOCKED por ausência.
 */
$rota_do_autoteste = F3Base_Imp_Entrega::ROTA_AUTOTESTE;
$esperadas_do_canal = F3Base_Imp_Entrega::rotas_do_complemento();

$medicao_so_habilidade = array(
	'esperadas' => $esperadas_do_canal,
	'faltam'    => array(),
	'achadas'   => array( $rota_do_autoteste . ' (habilidade ' . $rota_do_autoteste . ' na Abilities API)' ),
);

$presenca_so_habilidade = F3Base_Imp_Entrega::presenca_do_autoteste( $medicao_so_habilidade, array() );

medir( $nome );

if ( true !== $presenca_so_habilidade['presente'] ) {
	anotar( $nome, 'teto da união: a rota registrada SÓ como habilidade foi tratada como ausente — foi exatamente essa a contradição impressa no relatório de produção' );
}

medir( $nome );

if ( '' !== $presenca_so_habilidade['namespace'] ) {
	anotar( $nome, 'teto da união: sem rota REST casável o namespace tem de vir vazio, e vazio significa "despache pela habilidade", nunca "rota ausente"' );
}

medir( $nome );

if ( ! contem( $presenca_so_habilidade['fonte'], 'HABILIDADE' ) ) {
	anotar( $nome, 'teto da união: a fonte que achou a rota não sai nomeada, e o operador fica sem saber por onde ela responde' );
}

/* E a linha executa e fecha PELO RESULTADO, nunca por ausência. */
$veredito_so_habilidade = F3Base_Imp_Entrega::veredito_do_autoteste(
	(bool) $presenca_so_habilidade['presente'],
	array(
		'executou' => true,
		'codigo'   => 200,
		'corpo'    => array( 'ok' => true, 'php_lint' => true ),
		'erro'     => '',
		'via'      => 'Abilities API, habilidade ' . $rota_do_autoteste,
	),
	'wp-mcp-ultimate-complemento-fator3'
);

medir( $nome );

if ( 'OK' !== $veredito_so_habilidade['estado'] ) {
	anotar( $nome, 'teto da união: a rota que existe só como habilidade e respondeu 2xx fechou ' . $veredito_so_habilidade['estado'] . ' em vez de OK' );
}

medir( $nome );

if ( contem( $veredito_so_habilidade['motivo'], 'NÃO está registrada' ) ) {
	anotar( $nome, 'teto da união: a mensagem afirma que a rota não está registrada logo depois de a unidade tê-la listado entre as registradas — duas afirmações opostas sobre o mesmo fato no mesmo relatório' );
}

/* O namespace REST continua sendo lido de rotas_registradas(), quando houver. */
$presenca_com_rest = F3Base_Imp_Entrega::presenca_do_autoteste(
	$medicao_so_habilidade,
	array( $rota_do_autoteste => 'wp-mcp/v1' )
);

medir( $nome );

if ( true !== $presenca_com_rest['presente'] || 'wp-mcp/v1' !== $presenca_com_rest['namespace'] ) {
	anotar( $nome, 'teto: com rota REST casável o namespace tem de sair dela, para que o despacho monte o caminho certo' );
}

/* PISO: ausente nas DUAS fontes continua sendo pré-condição ausente. */
$presenca_ausente = F3Base_Imp_Entrega::presenca_do_autoteste(
	array(
		'esperadas' => $esperadas_do_canal,
		'faltam'    => array( $rota_do_autoteste ),
		'achadas'   => array(),
	),
	array()
);

medir( $nome );

if ( false !== $presenca_ausente['presente'] ) {
	anotar( $nome, 'piso: a rota ausente nas DUAS fontes foi dada como presente — medir-e-passar e não-medir são fatos diferentes' );
}

medir( $nome );

if ( 'BLOCKED' !== F3Base_Imp_Entrega::veredito_do_autoteste( (bool) $presenca_ausente['presente'], $despacho( 0, array(), false ), 'wp-mcp-ultimate-complemento-fator3' )['estado'] ) {
	anotar( $nome, 'piso: ausência nas duas fontes deixou de fechar BLOCKED' );
}

/* ---------- cadencia.mecanismo_do_fato_medido: o fato vale mais que a declaração ---------- */

/*
 * O DEFEITO MEDIDO: `mecanismo_de_cadencia` nasce VAZIA por desenho, e a
 * regra antiga fechava BLOCKED sempre que ela estivesse vazia. O resultado era
 * um BLOCKED em toda execução, para sempre, sobre uma ausência que ninguém vai
 * mudar e para a qual ninguém tem ação — e o mecanismo EXISTE e está medido:
 * WP-Cron, recorrência declarada, hook, com próxima execução conferida.
 *
 * TETO: com agendamento observado a linha fecha OK nomeando o mecanismo
 * OBSERVADO — o gatilho que o operador desabilita para pausar —, e com a chave
 * declarada ela fecha OK nomeando o DECLARADO sem perder o observado.
 * PISO: sem agendamento observado E com a chave vazia não há gatilho nenhum a
 * nomear, e aí a pré-condição está genuinamente ausente: BLOCKED, e é o único
 * ramo que declara pré-condição.
 */
$nome = 'cadencia.mecanismo_do_fato_medido';

$chave_do_mecanismo = 'mecanismo_de_cadencia';
$observado_medido   = 'WP-Cron, recorrência f3base_mensal (declarada: f3base_mensal), hook f3base_cadencia_relatorio';
$hook_da_cadencia   = 'f3base_cadencia_relatorio';

/* TETO 1: chave vazia e agendamento observado — o padrão desta base. */
$mecanismo_observado = F3Base_Imp_Lotes::veredito_do_mecanismo( true, '', $observado_medido, '2026-10-04 03:00', $hook_da_cadencia, $chave_do_mecanismo );

medir( $nome );

if ( 'OK' !== $mecanismo_observado['estado'] ) {
	anotar( $nome, 'teto: chave vazia COM agendamento observado fechou ' . $mecanismo_observado['estado'] . ' em vez de OK — o mecanismo existe, está medido, e ninguém tem ação a tomar' );
}

foreach ( array( $observado_medido, 'desabilita para pausar', $chave_do_mecanismo, '2026-10-04 03:00' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $mecanismo_observado['motivo'], $trecho ) ) {
		anotar( $nome, 'teto: a mensagem do mecanismo observado não traz "' . $trecho . '" — nomear o gatilho é o que o relatório de entrega precisa' );
	}
}

/* TETO 2: chave DECLARADA — o declarado nomeia, e o observado continua saindo. */
$mecanismo_declarado = F3Base_Imp_Lotes::veredito_do_mecanismo( true, 'agendador do painel da hospedagem', $observado_medido, '2026-10-04 03:00', $hook_da_cadencia, $chave_do_mecanismo );

medir( $nome );

if ( 'OK' !== $mecanismo_declarado['estado'] ) {
	anotar( $nome, 'teto: chave declarada fechou ' . $mecanismo_declarado['estado'] . ' em vez de OK' );
}

foreach ( array( 'agendador do painel da hospedagem', $observado_medido ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $mecanismo_declarado['motivo'], $trecho ) ) {
		anotar( $nome, 'teto: com a chave declarada a mensagem perdeu "' . $trecho . '" — declarado e observado são fatos diferentes e os dois saem' );
	}
}

/* PISO: sem agendamento observado E com a chave vazia, não há gatilho nenhum. */
$mecanismo_sem_nada = F3Base_Imp_Lotes::veredito_do_mecanismo( false, '', $observado_medido, '', $hook_da_cadencia, $chave_do_mecanismo );

medir( $nome );

if ( 'BLOCKED' !== $mecanismo_sem_nada['estado'] ) {
	anotar( $nome, 'piso: sem agendamento observado e sem chave declarada o veredito fechou ' . $mecanismo_sem_nada['estado'] . ' em vez de BLOCKED — aí não há gatilho nenhum a nomear' );
}

foreach ( array( 'não há gatilho NENHUM', $hook_da_cadencia, $chave_do_mecanismo, 'em ' . F3Base_Imp_Projeto::ARQUIVO ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $mecanismo_sem_nada['motivo'], $trecho ) ) {
		anotar( $nome, 'piso: o BLOCKED não nomeia "' . $trecho . '" — pendência sem nome é pendência que ninguém resolve' );
	}
}

/* PISO do outro lado: a chave declarada NÃO pode absolver a falta de agendamento na linha da agenda. */
medir( $nome );

if ( ! contem( F3Base_Imp_Lotes::veredito_do_mecanismo( false, 'agendador do painel da hospedagem', $observado_medido, '', $hook_da_cadencia, $chave_do_mecanismo )['motivo'], 'NÃO ficou agendado' ) ) {
	anotar( $nome, 'piso: com a chave declarada e sem agendamento, a mensagem esconde que o agendamento não ficou de pé — declarar o mecanismo não agenda coisa nenhuma' );
}

/* ---------- mcp.gate_le_o_veredito_final: o gate lê o veredito DEPOIS da promoção ---------- */

/*
 * O DEFEITO MEDIDO em produção (2026-09-04, fator3-teste-mcp-1): a unidade de
 * encerramento imprimiu "os vereditos de canal mcp.canal_configurado,
 * mcp.canal_exposto em OK, lidos do registro da execução" enquanto a contagem
 * do MESMO relatório listava `mcp.canal_exposto` entre os BLOCKED. A derivação
 * grava o veredito ANTES de o autoteste rodar; a PROMOÇÃO da unidade acontece
 * depois; e o registro guardava o estado pré-promoção.
 *
 * TETO: rótulo que não está no registro não cria entrada nenhuma — propagar não
 * pode virar uma segunda derivação.
 * PISO: a unidade do canal promovida para BLOCKED tem de chegar ao gate como
 * BLOCKED, e a autodesativação tem de ser NEGADA por causa dela.
 */
$nome = 'mcp.gate_le_o_veredito_final';

$rotulo_do_canal = F3Base_Imp_Entrega::gates_do_canal()[1] ?? 'mcp.canal_exposto';

/* O caminho REAL da promoção: a unidade emite mcp.autoteste em BLOCKED de aplicação. */
$promocao_do_canal = f3b_reflexo_real(
	'OK',
	array(
		array( 'estado' => 'OK', 'nome' => 'mcp.canal_configurado', 'gate' => 'aplicacao' ),
		array( 'estado' => 'BLOCKED', 'nome' => 'mcp.autoteste', 'gate' => 'aplicacao' ),
	)
);

medir( $nome );

if ( 'BLOCKED' !== $promocao_do_canal['estado'] ) {
	anotar( $nome, 'piso: a unidade do canal com mcp.autoteste em BLOCKED de aplicação fechou ' . $promocao_do_canal['estado'] . ' — a regra de 1.0.8 não pode ter sido enfraquecida' );
}

/* O registro nasce com o que a derivação gravou ANTES do autoteste: OK. */
$registro_pre_promocao = array(
	'mcp.canal_configurado' => array( 'estado' => 'OK', 'motivo' => 'as 12 rotas respondem.', 'em' => 0 ),
	$rotulo_do_canal        => array( 'estado' => 'OK', 'motivo' => 'as 12 rotas estão registradas E há servidor MCP ativo.', 'em' => 0 ),
);

$propagado = F3Base_Imp_Entrega::veredito_final_da_unidade(
	$registro_pre_promocao,
	$rotulo_do_canal,
	$promocao_do_canal['estado'],
	'linha da unidade, já promovida.'
);

medir( $nome );

if ( true !== $propagado['atualizou'] ) {
	anotar( $nome, 'piso: a promoção da unidade não chegou ao registro — é exatamente assim que o gate lia OK sobre uma linha que o relatório imprimia em BLOCKED' );
}

medir( $nome );

if ( 'BLOCKED' !== (string) ( $propagado['registro'][ $rotulo_do_canal ]['estado'] ?? '' ) ) {
	anotar( $nome, 'piso: o registro continuou em ' . (string) ( $propagado['registro'][ $rotulo_do_canal ]['estado'] ?? 'ausente' ) . ' depois da promoção — o gate tem de ler o veredito FINAL, o mesmo que o relatório imprime' );
}

/* E o GATE DE APLICAÇÃO enxerga BLOCKED, não OK: a autodesativação é negada. */
$mapa_do_gate = array( 'entrega.rodada_limpa' => 'N/A' );

foreach ( F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao() as $entregavel ) {
	$mapa_do_gate[ $entregavel ] = 'OK';
}

foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
	$mapa_do_gate[ $gate ] = (string) ( $propagado['registro'][ $gate ]['estado'] ?? 'OK' );
}

$decisao_pos_promocao = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_do_gate );

medir( $nome );

if ( false !== $decisao_pos_promocao['pode'] ) {
	anotar( $nome, 'piso: com a unidade do canal promovida para BLOCKED, o gate de aplicação continuou autorizando a autodesativação — o gate estava lendo o veredito ANTERIOR à promoção' );
}

medir( $nome );

if ( ! contem( $decisao_pos_promocao['motivo'], $rotulo_do_canal ) ) {
	anotar( $nome, 'piso: o motivo da recusa não nomeia ' . $rotulo_do_canal . ' — contagem sem nome não diz ao operador o que segurou a ferramenta no ar' );
}

/* TETO: sem promoção, o registro não é reescrito, e o gate continua vendo OK. */
$sem_promocao = F3Base_Imp_Entrega::veredito_final_da_unidade( $registro_pre_promocao, $rotulo_do_canal, 'OK', 'a mesma linha, sem promoção.' );

medir( $nome );

if ( false !== $sem_promocao['atualizou'] || 'OK' !== (string) $sem_promocao['registro'][ $rotulo_do_canal ]['estado'] ) {
	anotar( $nome, 'teto: unidade que fechou no mesmo estado do registro reescreveu o registro — propagação que reescreve sempre é ruído com carimbo de tempo novo' );
}

/*
 * TETO da fronteira: rótulo de unidade que NÃO nomeia um veredito registrado
 * não cria entrada. Criar entrada aqui faria da propagação uma SEGUNDA
 * derivação, que é o defeito original que os comentários do arquivo descrevem.
 */
$fora_do_registro = F3Base_Imp_Entrega::veredito_final_da_unidade( $registro_pre_promocao, 'plugins', 'BLOCKED', 'unidade de plugins.' );

medir( $nome );

if ( false !== $fora_do_registro['atualizou'] || isset( $fora_do_registro['registro']['plugins'] ) ) {
	anotar( $nome, 'teto: a propagação criou entrada para uma unidade que não é veredito de canal — inventar entrada aqui é a segunda derivação voltando por outra porta' );
}

F3Base_Imp_Relatorio::zerar();

/* ---------- plugins.digesto_do_artefato: os três ramos e o do salto ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.17, reproduzido aqui: os dois plugins do canal descem
 * de `https://github.com/.../raw/main/...zip` — ref MUTÁVEL — e `baixar_artefato()`
 * chamava `download_url()` puro. Nenhum hash conferido e nenhuma revalidação de
 * host depois do redirecionamento: o host era conferido na URL declarada e o
 * corpo vinha de onde a origem mandasse.
 *
 * TETO: declarado e batendo instala; ausente na primeira busca instala fixando.
 * PISO: declarado e divergindo NÃO instala; fixado e divergindo NÃO instala; e
 * um redirecionamento para host fora da lista declarada NÃO baixa.
 */
$nome = 'plugins.digesto_do_artefato';

$digesto_a = str_repeat( 'a', 64 );
$digesto_b = str_repeat( 'b', 64 );

$ramos = array(
	'declarado e batendo'   => array( $digesto_a, $digesto_a, '', true, false, array( 'DECLARADO', $digesto_a ) ),
	'declarado e divergindo' => array( $digesto_a, $digesto_b, '', false, false, array( 'DIVERGENTE', $digesto_a, $digesto_b, 'NADA foi instalado' ) ),
	'ausente e fixando'     => array( '', $digesto_a, '', true, true, array( 'FIXADO', 'NÃO PROTEGE', 'não é verificação de integridade' ) ),
	'fixado e batendo'      => array( '', $digesto_a, $digesto_a, true, false, array( 'FIXADO na primeira observação' ) ),
	'fixado e divergindo'   => array( '', $digesto_b, $digesto_a, false, false, array( 'DIVERGENTE do fixado', $digesto_a, $digesto_b, 'NADA foi instalado' ) ),
	'sem digesto medido'    => array( '', '', '', false, false, array( 'não pôde ser medido' ) ),
);

foreach ( $ramos as $rotulo => $caso ) {
	$veredito = F3Base_Imp_Plugins::veredito_do_digest( $caso[0], $caso[1], $caso[2] );

	medir( $nome );

	if ( $caso[3] !== $veredito['ok'] ) {
		anotar( $nome, $rotulo . ': o veredito devolveu ok=' . var_export( $veredito['ok'], true ) . ' e o esperado era ' . var_export( $caso[3], true ) );
	}

	medir( $nome );

	if ( $caso[4] !== $veredito['fixar'] ) {
		anotar( $nome, $rotulo . ': o veredito devolveu fixar=' . var_export( $veredito['fixar'], true ) . ' e o esperado era ' . var_export( $caso[4], true ) );
	}

	foreach ( $caso[5] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $rotulo . ': a mensagem não traz "' . $trecho . '" — ' . $veredito['motivo'] );
		}
	}
}

/*
 * A FRONTEIRA DO CONTRATO, congelada em piso. A regra 20 manda instalar sempre a
 * última versão da fonte oficial, sem número de versão declarado e SEM CHECKSUM
 * DE TERCEIRO, e ela vale inteira para o WordPress.org: a URL de lá é
 * por VERSÃO, o artefato muda de propósito a cada atualização, e fixar o digesto
 * ali faria a PRÓXIMA VERSÃO LEGÍTIMA reprovar — o oposto da política. A origem
 * `url` declarada é o caso que a regra não cobre, porque o endereço é uma ref
 * mutável servindo conteúdo diferente sem que nada no site mude.
 */
foreach ( array( 'url' => true, 'wordpress.org' => false, 'fornecedor' => false, 'bundle' => false, '' => false ) as $origem_declarada => $aplica ) {
	medir( $nome );

	if ( $aplica !== F3Base_Imp_Plugins::digesto_se_aplica( (string) $origem_declarada ) ) {
		anotar(
			$nome,
			'origem "' . $origem_declarada . '": a conferência de digesto ' . ( $aplica ? 'deixou de se aplicar' : 'passou a se aplicar' )
				. ' — fixar o digesto de artefato do WordPress.org faz a próxima versão legítima reprovar, e é a regra 20 do contrato que essa fronteira executa'
		);
	}
}

/*
 * A MENSAGEM DO RAMO AUSENTE NÃO PODE MAQUIAR O LIMITE. TOFU que se apresenta
 * como verificação de integridade é pior que nenhuma, porque produz confiança:
 * a mensagem tem de dizer as duas metades, o que protege e o que não protege.
 */
$tofu = F3Base_Imp_Plugins::veredito_do_digest( '', $digesto_a, '' );

foreach ( array( 'O QUE ISSO PROTEGE', 'O QUE ISSO NÃO PROTEGE', 'esta busca' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $tofu['motivo'], $trecho ) ) {
		anotar( $nome, 'o ramo do digesto ausente não diz "' . $trecho . '": fixar na primeira observação sem declarar o limite produz a confiança que ele não sustenta' );
	}
}

/* ---------- plugins.https_em_todo_salto: teto e piso ---------- */

/*
 * A GUARDA MUDOU NA 1.0.19 e o piso muda com ela. Até a 1.0.18 o que se
 * revalidava a cada salto era o HOST, contra uma lista fechada declarada no
 * MESMO arquivo que as URLs — quem edita a URL edita a lista na linha de cima,
 * e o controle nunca existiu. O que ficou é a guarda que faz trabalho de
 * verdade e não pede nada ao operador: **todo salto continua em https**.
 *
 * TETO: cadeia inteira em https resolve e devolve o endereço final.
 * PISO: salto que cai para http NÃO baixa nada e nomeia o esquema observado;
 * endereço sem host legível é recusado; cadeia sem fim é abandonada no teto.
 */

$nome = 'plugins.https_em_todo_salto';

/*
 * A GUARDA MEDIDA É A DO PACOTE, não uma cópia escrita aqui: o piso exercita a
 * cadeia com a MESMA função privada que o download usa, alcançada pela reflexão
 * do próprio arquivo. Reescrevê-la aqui provaria que a cópia funciona.
 */
$metodo_da_guarda = new ReflectionMethod( 'F3Base_Imp_Plugins', 'salto_e_https' );
$metodo_da_guarda->setAccessible( true );

$guarda = static function ( string $endereco ) use ( $metodo_da_guarda ): array {
	return (array) $metodo_da_guarda->invoke( null, $endereco );
};

/**
 * Buscador de mentira: uma tabela de endereço para resposta.
 *
 * @param array<string,array{codigo:int,location:string,erro:string}> $tabela Respostas.
 * @return callable
 */
$buscador = static function ( array $tabela ): callable {
	return static function ( string $endereco ) use ( $tabela ): array {
		return $tabela[ $endereco ] ?? array(
			'codigo'   => 200,
			'location' => '',
			'erro'     => '',
		);
	};
};

/*
 * A URL DE PARTIDA É DA BANCADA. Lida do catálogo, ela amarra o piso à ordem das
 * entradas: uma reordenação põe outro plugin no índice 2, uma entrada sem `url`
 * devolve string vazia, e a cadeia inteira passa a ser exercitada a partir do
 * nada — verde por não ter medido, que é a forma mais silenciosa de um piso
 * deixar de existir. A regra medida aqui é sobre o SALTO, e ela não depende de
 * qual artefato um projeto resolveu baixar.
 */
$declarada = 'https://origem.exemplo-de-espelho.test/artefato.zip';
$final_ok  = 'https://cdn.exemplo-de-espelho.test/x/artefato.zip';
$final_mau = 'http://cdn.exemplo-de-espelho.test/x/artefato.zip';

/* TETO: a cadeia inteira em https resolve, mesmo trocando de host no meio. */
$boa = F3Base_Imp_Plugins::seguir_redirecionamentos(
	$declarada,
	$buscador( array( $declarada => array( 'codigo' => 302, 'location' => $final_ok, 'erro' => '' ) ) ),
	$guarda,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( ! $boa['ok'] ) {
	anotar( $nome, 'teto: uma cadeia inteiramente em https foi recusada — ' . $boa['motivo'] );
}

medir( $nome );

if ( $final_ok !== $boa['url'] ) {
	anotar( $nome, 'teto: o endereço final devolvido não é o do último salto (' . $boa['url'] . ')' );
}

/* PISO: o salto CAI PARA HTTP e nada é baixado. */
$ma = F3Base_Imp_Plugins::seguir_redirecionamentos(
	$declarada,
	$buscador( array( $declarada => array( 'codigo' => 302, 'location' => $final_mau, 'erro' => '' ) ) ),
	$guarda,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( $ma['ok'] ) {
	anotar( $nome, 'piso: o redirecionamento para http foi aceito — conferir o esquema só na URL declarada deixa a guarda valendo para um endereço que ninguém baixa, e o corpo desceria por canal aberto' );
}

foreach ( array( 'REDIRECIONAMENTO recusado', 'não é https', 'Nada foi baixado', 'cdn.exemplo-de-espelho.test' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $ma['motivo'], $trecho ) ) {
		anotar( $nome, 'piso: a recusa do salto não traz "' . $trecho . '" — ' . $ma['motivo'] );
	}
}

/* PISO: o PRIMEIRO endereço em http também é recusado, e antes de qualquer busca. */
$http_na_entrada = F3Base_Imp_Plugins::seguir_redirecionamentos(
	'http://exemplo-sem-tls.test/artefato.zip',
	$buscador( array() ),
	$guarda,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( $http_na_entrada['ok'] ) {
	anotar( $nome, 'piso: a URL declarada em http foi aceita — HTTPS é obrigatório em TODOS os saltos, e o primeiro é um salto' );
}

medir( $nome );

if ( ! contem( $http_na_entrada['motivo'], 'não é https' ) ) {
	anotar( $nome, 'piso: a recusa da URL declarada em http não nomeia o esquema observado — ' . $http_na_entrada['motivo'] );
}

/* PISO: endereço sem host legível não abre conexão com ninguém. */
$sem_host = F3Base_Imp_Plugins::seguir_redirecionamentos(
	'https:///artefato.zip',
	$buscador( array() ),
	$guarda,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( $sem_host['ok'] ) {
	anotar( $nome, 'piso: endereço sem host legível foi aceito — não há a quem abrir conexão, e seguir adiante é o download decidindo sozinho para onde vai' );
}

/* PISO: cadeia que não termina não pode virar perseguição sem fim. */
$laco = F3Base_Imp_Plugins::seguir_redirecionamentos(
	$declarada,
	static fn( string $endereco ): array => array( 'codigo' => 302, 'location' => $endereco . '/mais', 'erro' => '' ),
	$guarda,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( $laco['ok'] ) {
	anotar( $nome, 'piso: uma cadeia sem fim foi seguida até o fim — seguir indefinidamente deixa a origem decidir quantas vezes o site a persegue' );
}

medir( $nome );

if ( ! contem( $laco['motivo'], 'passou do teto' ) ) {
	anotar( $nome, 'piso: o abandono da cadeia não nomeia o teto de saltos — ' . $laco['motivo'] );
}

/* ---------- options.merge_tres_vias: teto e piso da regra das options ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.19: o gravador comparava DUAS vias — observado contra
 * desejado — e gravava sempre que diferissem. Toda edição de option feita pelo
 * agente pelo canal era revertida na reexecução do implantador, e nada no
 * relatório dizia que uma reversão tinha acontecido.
 *
 * A tabela abaixo é a regra inteira, e o piso dela é a linha 4: base ===
 * desejado com observado diferente PRECISA preservar. Trocá-la por `gravar`
 * devolve o defeito.
 */

$nome = 'options.merge_tres_vias';

$ob = hash( 'sha256', 'base' );
$oh = hash( 'sha256', 'do-agente' );
$on = hash( 'sha256', 'da-configuracao-nova' );

$tabela_options = array(
	array( $ob, $on, $on, 'nada', 'observado já é o desejado: nada a gravar' ),
	array( $ob, $ob, $on, 'gravar', 'ninguém tocou desde a última aplicação: atualização segura' ),
	array( $ob, $oh, $ob, 'preservar', 'o agente tocou e a configuração NÃO mudou: a edição vence a reexecução' ),
	array( $ob, $oh, $on, 'sobrepor', 'o agente tocou E a configuração mudou depois: o pacote vence, e nomeado' ),
	array( null, $oh, $on, 'nascer', 'primeira execução sem base: o desejado é aplicado e a base nasce agora' ),
	array( null, $on, $on, 'nada', 'sem base e já no valor desejado: nada a gravar' ),
);

foreach ( $tabela_options as $linha ) {
	medir( $nome );

	$decisao = F3Base_Imp_Gravador::merge_option( $linha[0], $linha[1], $linha[2] );

	if ( $decisao['acao'] !== $linha[3] ) {
		anotar( $nome, $linha[4] . ': esperado ' . $linha[3] . ', obtido ' . $decisao['acao'] );
	}
}

/* Cada ramo NOMEIA o que fez — decisão calada é indistinguível de ausência. */
$frases = array(
	array( array( $ob, $oh, $ob ), 'PRESERVADA', 'a preservação não se anuncia' ),
	array( array( $ob, $oh, $on ), 'SOBREPOSIÇÃO', 'a sobreposição não se anuncia' ),
	array( array( null, $oh, $on ), 'PRIMEIRA', 'a base que nasce agora não se anuncia — estrutura de estado nova precisa declarar o que faz na primeira execução' ),
);

foreach ( $frases as $caso ) {
	medir( $nome );

	$motivo = F3Base_Imp_Gravador::merge_option( $caso[0][0], $caso[0][1], $caso[0][2] )['motivo'];

	if ( ! contem( $motivo, $caso[1] ) ) {
		anotar( $nome, 'piso: ' . $caso[2] . ' — ' . $motivo );
	}
}

/*
 * PISO DA REGRA INTEIRA: existindo base, a única forma de o pacote gravar por
 * cima de uma edição é a configuração ter mudado aquela mesma coisa. Não existe
 * terceiro caminho.
 */
medir( $nome );

if ( 'preservar' !== F3Base_Imp_Gravador::merge_option( $ob, $oh, $ob )['acao'] ) {
	anotar( $nome, 'piso: com a configuração intocada, o pacote gravou por cima da edição do agente — é exatamente a reversão que esta release corrige' );
}

/*
 * PISO DA DURAÇÃO DA PRESERVAÇÃO, e ele foi medido numa bancada de ponta a
 * ponta antes de virar linha: preservar movendo a base para o valor observado
 * faz a base ficar IGUAL ao observado, e na execução seguinte a primeira
 * mudança da configuração cai no ramo "ninguém tocou" — grava por cima da
 * edição SEM nomear sobreposição nenhuma. O ramo que precisa ser visível fica
 * inalcançável, e a proteção dura uma execução.
 */
medir( $nome );

if ( F3Base_Imp_Gravador::BASE_INALTERADA !== F3Base_Imp_Gravador::merge_option( $ob, $oh, $ob )['base'] ) {
	anotar( $nome, 'piso: a preservação MOVEU a base — na execução seguinte a base seria igual ao observado, e a primeira mudança da configuração gravaria por cima da edição sem nomear sobreposição' );
}

foreach ( array(
	array( $ob, $ob, $on, 'gravar' ),
	array( $ob, $oh, $on, 'sobrepor' ),
	array( null, $oh, $on, 'nascer' ),
	array( $ob, $on, $on, 'nada' ),
) as $linha_de_base ) {
	medir( $nome );

	$d = F3Base_Imp_Gravador::merge_option( $linha_de_base[0], $linha_de_base[1], $linha_de_base[2] );

	if ( $linha_de_base[3] !== $d['acao'] || F3Base_Imp_Gravador::BASE_DESEJADO !== $d['base'] ) {
		anotar( $nome, 'teto: a decisão "' . $d['acao'] . '" não registrou o valor aplicado como base nova — sem isso a mesma option seria reaplicada em toda execução, e a preservação nunca teria contra o que comparar' );
	}
}

/* A IMPRESSÃO É A MESMA DA LEITURA DE VOLTA: sem isso a regra decidiria pelo tipo. */
medir( $nome );

if ( F3Base_Imp_Gravador::impressao( array( 'b' => 2, 'a' => 1 ) ) !== F3Base_Imp_Gravador::impressao( array( 'a' => 1, 'b' => 2 ) ) ) {
	anotar( $nome, 'piso: a impressão depende da ORDEM das chaves do array — a mesma option lida do banco em outra ordem viraria "edição do agente" a cada execução' );
}

medir( $nome );

if ( F3Base_Imp_Gravador::impressao( '1' ) !== F3Base_Imp_Gravador::impressao( true ) ) {
	anotar( $nome, 'piso: a impressão não reconhece o round-trip da camada de options (true volta do banco como "1"), e todo booleano viraria divergência' );
}

medir( $nome );

if ( F3Base_Imp_Gravador::impressao( '' ) === F3Base_Imp_Gravador::impressao( '0' ) ) {
	anotar( $nome, 'piso do piso: a tolerância do round-trip virou "tudo é igual a tudo" — false e 0 precisam continuar diferentes' );
}

/* O RELATÓRIO NOMEIA OS DOIS VALORES. Contagem sem valor não serve a ninguém. */
$texto_sobreposto = F3Base_Imp_Lotes::texto_do_merge_de_options(
	3,
	array( 'f3base_contato (preservado: A; da configuração, não aplicado: B)' ),
	array( 'f3base_cabecalhos (estava: same-origin; aplicado: same-origin-allow-popups)' ),
	array()
);

foreach ( array( 'SOBREPOSIÇÃO', 'f3base_cabecalhos', 'same-origin-allow-popups', 'f3base_contato' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $texto_sobreposto, $trecho ) ) {
		anotar( $nome, 'a linha do relatório não nomeia "' . $trecho . '": o único ramo em que o pacote vence o agente precisa ser visível com os dois valores' );
	}
}

$texto_preservado = F3Base_Imp_Lotes::texto_do_merge_de_options( 3, array( 'f3base_contato (preservado: A; da configuração, não aplicado: B)' ), array(), array() );

medir( $nome );

if ( contem( $texto_preservado, 'SOBREPOSIÇÃO' ) ) {
	anotar( $nome, 'a linha falou em sobreposição sem que houvesse nenhuma: WARN só com achado adverso' );
}

medir( $nome );

if ( ! contem( $texto_preservado, 'VENCEU a reexecução' ) ) {
	anotar( $nome, 'a preservação não sai nomeada no relatório: ' . $texto_preservado );
}

$texto_nascer = F3Base_Imp_Lotes::texto_do_merge_de_options( 3, array(), array(), array( 'f3base_llms' ) );

foreach ( array( 'BASE NASCEU', 'f3base_llms' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $texto_nascer, $trecho ) ) {
		anotar( $nome, 'a primeira execução da estrutura de base não é declarada no relatório, e foi defeito medido: ' . $texto_nascer );
	}
}

$texto_limpo = F3Base_Imp_Lotes::texto_do_merge_de_options( 3, array(), array(), array() );

medir( $nome );

if ( ! contem( $texto_limpo, '3' ) ) {
	anotar( $nome, 'sem preservação nem sobreposição a linha não diz QUANTAS options passaram pela regra: "nenhuma preservada" precisa ser distinguível de "nenhuma medida"' );
}

/* ---------- relatorio.mudanca_desde_a_aplicacao: teto e piso ---------- */

/*
 * O DEFEITO MEDIDO, e ele é de CATEGORIA. Até a 1.1.1 o modo somente-relatório
 * atravessava o gravador em simulação e imprimia "gravaria esta option (valor
 * observado difere do desejado)": ele comparava o observado com o DESEJADO, isto
 * é, com `config/site.json`. Depois que o agente assume o site, esse arquivo é
 * certidão de nascimento e não estado corrente — ele registra o que o pacote
 * aplicou no dia da entrega e nunca mais é reescrito. Cada edição legítima do
 * agente virava, então, uma "divergência" permanente, num relatório que roda na
 * cadência para sempre.
 *
 * Os dois pisos que o roteiro desta release declarou: option editada pelo agente
 * aparece como MUDOU DESDE A APLICAÇÃO e não como divergência; option intocada
 * com a configuração mudada aparece SÓ na segunda linha.
 */

$nome = 'relatorio.mudanca_desde_a_aplicacao';

$rb = hash( 'sha256', 'valor-que-o-pacote-aplicou' );
$rh = hash( 'sha256', 'valor-que-o-agente-gravou' );
$rn = hash( 'sha256', 'valor-novo-da-configuracao' );

/* PISO 1: option EDITADA PELO AGENTE, configuração intocada. */
$editada = F3Base_Imp_Gravador::linha_de_relatorio( $rb, $rh, $rb, 'base', 'do-agente', 'base' );

medir( $nome );

if ( true !== $editada['mudou'] ) {
	anotar( $nome, 'piso: a edição do agente não foi registrada como mudança desde a aplicação' );
}

/*
 * A EDIÇÃO DO AGENTE TAMBÉM DIFERE DA CONFIGURAÇÃO — é claro que difere: a
 * configuração continua declarando o valor da entrega. O que esta release muda
 * é ONDE isso aparece: no registro sai a mudança desde a aplicação, e a
 * comparação com a configuração desce para a segunda linha, rotulada.
 */
medir( $nome );

if ( true !== $editada['difere'] ) {
	anotar( $nome, 'a bancada montou o caso errado: a edição do agente sobre a configuração intocada precisa diferir da configuração' );
}

medir( $nome );

if ( contem( $editada['registro'], 'configuração' ) ) {
	anotar( $nome, 'piso: o REGISTRO falou da configuração — ela desceu para a segunda linha, e misturar as duas é o que fazia toda edição do agente parecer divergência: ' . $editada['registro'] );
}

medir( $nome );

if ( ! contem( $editada['registro'], 'MUDOU DESDE A APLICAÇÃO' ) ) {
	anotar( $nome, 'piso: a linha não diz MUDOU DESDE A APLICAÇÃO — ' . $editada['registro'] );
}

foreach ( array( 'base', 'do-agente' ) as $valor_nomeado ) {
	medir( $nome );

	if ( ! contem( $editada['registro'], $valor_nomeado ) ) {
		anotar( $nome, 'piso: a linha não NOMEIA o valor "' . $valor_nomeado . '" — registrar que mudou sem dizer de quê para quê obriga quem lê a ir ao banco' );
	}
}

/*
 * A PALAVRA "DIVERGÊNCIA" NÃO PODE APARECER, e este é o piso literal do
 * roteiro: mudança feita pelo agente é o trabalho dele, e chamá-la de
 * divergência ensina o leitor a ignorar o relatório inteiro.
 */
/*
 * A LINHA DIZ, EM VOZ ALTA, QUE ISTO NÃO É DIVERGÊNCIA — e não basta evitar a
 * palavra: quem lê o relatório da cadência precisa saber que a mudança do
 * agente é o funcionamento normal, e não um achado que alguém deveria desfazer.
 */
medir( $nome );

if ( ! contem( $editada['registro'], 'não divergência' ) ) {
	anotar( $nome, 'piso: a linha não declara que a mudança do agente NÃO é divergência — ' . $editada['registro'] );
}

medir( $nome );

if ( contem( $editada['texto'], 'divergiu' ) || contem( $editada['texto'], 'divergência entre' ) ) {
	anotar( $nome, 'piso: a edição do agente saiu ACUSADA como divergência — ' . $editada['texto'] );
}

/* PISO 2: option INTOCADA com a configuração mudada — só a SEGUNDA linha fala. */
$intocada = F3Base_Imp_Gravador::linha_de_relatorio( $rb, $rb, $rn, 'base', 'base', 'da-configuracao-nova' );

medir( $nome );

if ( false !== $intocada['mudou'] ) {
	anotar( $nome, 'piso: uma option que ninguém tocou saiu como "mudou desde a aplicação" — ' . $intocada['registro'] );
}

medir( $nome );

if ( ! contem( $intocada['registro'], 'INALTERADA DESDE A APLICAÇÃO' ) ) {
	anotar( $nome, 'piso: a option intocada não é declarada como intocada; silêncio aqui é indistinguível de option não medida — ' . $intocada['registro'] );
}

medir( $nome );

if ( true !== $intocada['difere'] ) {
	anotar( $nome, 'a option intocada com a configuração mudada precisa cair na segunda linha' );
}

foreach ( array( 'difere da configuração original', 'da-configuracao-nova', 'NÃO é achado' ) as $trecho_da_segunda ) {
	medir( $nome );

	if ( ! contem( $intocada['segunda_linha'], $trecho_da_segunda ) ) {
		anotar( $nome, 'piso: a segunda linha não traz "' . $trecho_da_segunda . '" — ela tem leitor (quem for reexecutar) e precisa sair ROTULADA como o que é: ' . $intocada['segunda_linha'] );
	}
}

/* TETO DO CASO CALMO: nada mudou e nada difere, e os dois são ditos. */
$calma = F3Base_Imp_Gravador::linha_de_relatorio( $rb, $rb, $rb, 'base', 'base', 'base' );

medir( $nome );

if ( $calma['mudou'] || $calma['difere'] || ! contem( $calma['segunda_linha'], 'igual à configuração original' ) ) {
	anotar( $nome, 'teto: o caso sem mudança e sem diferença não foi declarado nos dois lados — ' . $calma['texto'] );
}

/* PISO DA PRIMEIRA EXECUÇÃO: sem base não existe "desde a última aplicação". */
$sem_base = F3Base_Imp_Gravador::linha_de_relatorio( null, $rh, $rn, '(vazio)', 'do-agente', 'da-configuracao-nova' );

medir( $nome );

if ( true !== $sem_base['sem_base'] || $sem_base['mudou'] ) {
	anotar( $nome, 'piso: sem base registrada a linha afirmou o resultado de uma comparação que não podia acontecer — ' . $sem_base['registro'] );
}

medir( $nome );

if ( ! contem( $sem_base['registro'], 'SEM BASE' ) ) {
	anotar( $nome, 'piso: a ausência de base não é declarada, e estrutura de estado que cala sobre o caso "ainda não há estado" absolve a si mesma para sempre' );
}

/* A LINHA DO RELATÓRIO junta as duas listas, e a segunda sai rotulada. */
$texto_mudou = F3Base_Imp_Lotes::texto_do_registro_de_mudanca(
	12,
	array( 'f3base_contato — MUDOU DESDE A APLICAÇÃO: o pacote aplicou A e o site tem B agora.' ),
	array( 'f3base_llms — difere da configuração original: ela declara C.' )
);

foreach ( array( 'REGISTRO DO QUE MUDOU DESDE A ÚLTIMA APLICAÇÃO', 'f3base_contato', 'SEGUNDA LINHA', 'f3base_llms', '12' ) as $trecho_da_linha ) {
	medir( $nome );

	if ( ! contem( $texto_mudou, $trecho_da_linha ) ) {
		anotar( $nome, 'a linha do relatório não traz "' . $trecho_da_linha . '": ' . $texto_mudou );
	}
}

medir( $nome );

if ( contem( $texto_mudou, 'divergiu' ) || contem( $texto_mudou, 'divergência entre' ) ) {
	anotar( $nome, 'piso: a linha do relatório ACUSOU a mudança do agente como divergência — ' . $texto_mudou );
}

medir( $nome );

if ( ! contem( $texto_mudou, 'não divergência' ) ) {
	anotar( $nome, 'piso: a linha do relatório não declara que a mudança do agente não é divergência — ' . $texto_mudou );
}

$texto_calmo = F3Base_Imp_Lotes::texto_do_registro_de_mudanca( 12, array(), array() );

medir( $nome );

if ( ! contem( $texto_calmo, '12' ) ) {
	anotar( $nome, 'sem mudança nenhuma a linha não diz QUANTAS options foram lidas: "nada mudou" precisa ser distinguível de "nada foi medido"' );
}

medir( $nome );

if ( ! contem( $texto_calmo, 'Nenhuma option difere da configuração original' ) ) {
	anotar( $nome, 'a segunda linha sumiu quando não havia diferença, e ela precisa sair nos dois ramos: ' . $texto_calmo );
}

/* ---------- cadencia.recorrencia_declarada: teto e piso ---------- */

/*
 * O DEFEITO MEDIDO NA EXECUÇÃO REAL: o log registrou `daily` com a configuração
 * declarando `mensal`. Quem registra `f3base_mensal` e `f3base_quinzenal` é o
 * módulo cadencia-relatorio do site-core, e ele fica INATIVO enquanto
 * `f3base_cadencia` não existir — a option que esta mesma etapa grava. Na
 * primeira execução, portanto, a recorrência declarada não podia existir, e a
 * degradação para `daily` SOBREVIVIA a toda reexecução: a etapa encontrava o
 * evento agendado e não olhava com o quê.
 */

$nome = 'cadencia.recorrencia_declarada';

$tabela_do_nucleo = array(
	'hourly'     => array( 'interval' => 3600 ),
	'twicedaily' => array( 'interval' => 43200 ),
	'daily'      => array( 'interval' => 86400 ),
	'weekly'     => array( 'interval' => 604800 ),
);

$tabela_com_site_core = $tabela_do_nucleo + array(
	'f3base_quinzenal' => array( 'interval' => 1296000 ),
	'f3base_mensal'    => array( 'interval' => 2592000 ),
);

/* PISO: sem o site-core na tabela, a queda acontece E sai nomeada. */
$sem_core = F3Base_Imp_Lotes::veredito_da_recorrencia( 'mensal', $tabela_do_nucleo, '', 'f3base_quinzenal', 'f3base_mensal' );

medir( $nome );

if ( 'daily' !== $sem_core['recorrencia'] ) {
	anotar( $nome, 'piso: sem a recorrência do site-core no agendador, a queda declarada não aconteceu — o evento ficaria sem agendamento nenhum' );
}

medir( $nome );

if ( '' === $sem_core['degradacao'] || ! contem( $sem_core['degradacao'], 'f3base_mensal' ) ) {
	anotar( $nome, 'piso: a degradação não NOMEIA a recorrência declarada que não existia — era exatamente isso que o log não dizia' );
}

/* TETO: com o site-core ativo, a recorrência agendada é a DECLARADA. */
$com_core = F3Base_Imp_Lotes::veredito_da_recorrencia( 'mensal', $tabela_com_site_core, '', 'f3base_quinzenal', 'f3base_mensal' );

medir( $nome );

if ( 'f3base_mensal' !== $com_core['recorrencia'] ) {
	anotar( $nome, 'teto: com o site-core ativo a recorrência agendada foi ' . $com_core['recorrencia'] . ' e a declarada é f3base_mensal' );
}

medir( $nome );

if ( '' !== $com_core['degradacao'] ) {
	anotar( $nome, 'teto: houve degradação nomeada onde não houve degradação nenhuma' );
}

medir( $nome );

if ( 'f3base_quinzenal' !== F3Base_Imp_Lotes::veredito_da_recorrencia( 'quinzenal', $tabela_com_site_core, '', 'f3base_quinzenal', 'f3base_mensal' )['recorrencia'] ) {
	anotar( $nome, 'teto: quinzenal não resolveu para a recorrência de quinze dias do site-core — cair em weekly DOBRA a frequência combinada' );
}

/* PISO DA PERMANÊNCIA: a queda de uma execução anterior é REPARADA. */
$reparo = F3Base_Imp_Lotes::veredito_da_recorrencia( 'mensal', $tabela_com_site_core, 'daily', 'f3base_quinzenal', 'f3base_mensal' );

medir( $nome );

if ( 'reagendar' !== $reparo['acao'] ) {
	anotar( $nome, 'piso: o evento agendado em daily por uma execução anterior NÃO foi reagendado agora que a recorrência declarada existe — a degradação vira permanente, e o site-core fica pedindo uma reexecução que não muda nada' );
}

/* PISO DO ALCANCE: recorrência que NÃO é a nossa queda não é desfeita. */
medir( $nome );

if ( 'manter' !== F3Base_Imp_Lotes::veredito_da_recorrencia( 'mensal', $tabela_com_site_core, 'weekly', 'f3base_quinzenal', 'f3base_mensal' )['acao'] ) {
	anotar( $nome, 'piso do falso positivo: a etapa desfez uma recorrência que ela não colocou ali — weekly no evento é decisão de quem opera o site, e reparar a própria queda não autoriza reescrever a escolha alheia' );
}

medir( $nome );

if ( 'reagendar' === F3Base_Imp_Lotes::veredito_da_recorrencia( 'mensal', $tabela_do_nucleo, 'daily', 'f3base_quinzenal', 'f3base_mensal' )['acao'] ) {
	anotar( $nome, 'piso: pediu reagendamento com a recorrência declarada AINDA ausente do agendador — trocaria daily por daily a cada execução, jogando a próxima cadência para daqui a um dia toda vez' );
}

medir( $nome );

if ( 'agendar' !== F3Base_Imp_Lotes::veredito_da_recorrencia( 'mensal', $tabela_com_site_core, 'f3base_mensal', 'f3base_quinzenal', 'f3base_mensal' )['acao'] ) {
	anotar( $nome, 'teto: o evento já agendado com a recorrência declarada foi marcado para reagendamento — reagendar sem motivo joga a próxima execução para daqui a um dia, toda vez' );
}



/* ---------- release.matriz_do_catalogo: a lista fechada saiu da configuração ---------- */

/*
 * A MATRIZ DE ORIGENS SUPORTADAS deixou de ser configuração de site. Ela responde
 * a uma pergunta sobre o PACOTE — de qual versão instalada este implantador sabe
 * subir —, e nenhum projeto legítimo tem resposta diferente: um operador que a
 * editasse estaria afirmando ter homologado um caminho que ninguém percorreu.
 * Sozinha ela ocupava 78 das folhas do arquivo que o operador abre.
 *
 * TETO: o catálogo do pacote é lido inteiro, com as três colunas de cada linha, e
 * comentário e linha em branco não viram entrada.
 * PISO: arquivo ausente devolve VAZIO — o lado seguro, em que só a instalação
 * limpa passa —, e linha incompleta é descartada em vez de virar entrada com
 * campo vazio, que aprovaria uma origem sem versão declarada.
 */
$nome = 'release.matriz_do_catalogo';

$catalogo_real = F3Base_Imp_Preflight::releases_suportadas_de( $raiz . '/' . F3Base_Imp_Preflight::CATALOGO_DE_RELEASES );

medir( $nome );

if ( array() === $catalogo_real ) {
	anotar( $nome, 'teto: o catálogo de origens suportadas do próprio pacote foi lido VAZIO — sem ele, toda origem que não seja instalação limpa passa a não ser suportada' );
}

foreach ( $catalogo_real as $indice_da_origem => $origem_suportada ) {
	medir( $nome );

	if ( '' === $origem_suportada['componente'] || '' === $origem_suportada['versao'] || '' === $origem_suportada['determinacao'] ) {
		anotar( $nome, 'teto: a entrada ' . $indice_da_origem . ' do catálogo veio com coluna vazia — origem sem componente, sem versão ou sem determinação não sustenta homologação nenhuma' );
	}
}

medir( $nome );

if ( array() !== F3Base_Imp_Preflight::releases_suportadas_de( $raiz . '/config/nao-existe.tsv' ) ) {
	anotar( $nome, 'piso: catálogo ausente devolveu entrada — arquivo que não existe não pode declarar origem homologada' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Preflight::releases_suportadas_de( '' ) ) {
	anotar( $nome, 'piso: caminho vazio devolveu entrada' );
}

/*
 * PISO DA LINHA INCOMPLETA e do COMENTÁRIO: um catálogo montado na bancada, com
 * as quatro formas que o arquivo real pode ter.
 */
$catalogo_da_bancada = tempnam( sys_get_temp_dir(), 'f3b-rel' );

/*
 * A LINHA DE COMENTARIO DA BANCADA CARREGA AS TRES COLUNAS de proposito, e a
 * linha em branco carrega as tabulacoes pelo mesmo motivo: e a unica forma de a
 * guarda do "#" e a guarda do vazio terem piso PROPRIO. Com um comentario sem
 * tabulacao, quem o descarta e a contagem de colunas, e derrubar a guarda do "#"
 * nao muda resultado nenhum — o piso passaria a aprovar por acidente. O catalogo
 * real tem exatamente esse caso na linha `# componente<tab>versao<tab>determinacao`,
 * o cabecalho de colunas escrito como comentario: sem a guarda, ele vira uma
 * origem suportada de componente "# componente".
 */
file_put_contents(
	$catalogo_da_bancada,
	"# componente\tversao\tdeterminacao\n"
	. "\t\t\n"
	. "implantador\t9.9.9\tmedida-no-site\n"
	. "implantador\t9.9.8\n"
	. "tema\t9.9.7\tentregue-nao-confirmada\n"
);

$lido_da_bancada = F3Base_Imp_Preflight::releases_suportadas_de( $catalogo_da_bancada );

medir( $nome );

if ( 2 !== count( $lido_da_bancada ) ) {
	anotar( $nome, 'piso: o catálogo da bancada devolveu ' . count( $lido_da_bancada ) . ' entrada(s) e a bancada declarou 2 completas — comentário, linha em branco e linha incompleta não podem virar origem' );
}

medir( $nome );

if ( '9.9.9' !== (string) ( $lido_da_bancada[0]['versao'] ?? '' ) || 'tema' !== (string) ( $lido_da_bancada[1]['componente'] ?? '' ) ) {
	anotar( $nome, 'piso: as colunas do catálogo saíram fora de ordem ou trocadas — ' . wp_json_encode( $lido_da_bancada ) );
}

medir( $nome );

foreach ( $lido_da_bancada as $entrada_da_bancada ) {
	if ( '9.9.8' === (string) $entrada_da_bancada['versao'] ) {
		anotar( $nome, 'piso: a linha SEM a coluna de determinação virou origem suportada — origem sem o que a sustenta é homologação afirmada e não feita' );
	}
}

medir( $nome );

foreach ( $lido_da_bancada as $entrada_da_bancada ) {
	if ( str_starts_with( ltrim( (string) $entrada_da_bancada['componente'] ), '#' ) ) {
		anotar( $nome, 'piso: uma linha de COMENTÁRIO virou origem suportada — o catálogo real tem o cabeçalho de colunas escrito como comentário, e sem a guarda ele passa a homologar um componente chamado "' . $entrada_da_bancada['componente'] . '"' );
	}
}

medir( $nome );

foreach ( $lido_da_bancada as $entrada_da_bancada ) {
	if ( '' === trim( (string) $entrada_da_bancada['componente'] ) ) {
		anotar( $nome, 'piso: uma linha EM BRANCO virou origem suportada — uma linha só de tabulações tem as três colunas e todas vazias, e origem sem componente não sustenta homologação nenhuma' );
	}
}

unlink( $catalogo_da_bancada );

/*
 * E O CATALOGO REAL PASSA PELA MESMA REGRA: o cabecalho de colunas dele é
 * comentário, e nenhuma entrada lida pode ter vindo dele.
 */
medir( $nome );

foreach ( $catalogo_real as $origem_do_pacote ) {
	if ( str_starts_with( ltrim( (string) $origem_do_pacote['componente'] ), '#' ) ) {
		anotar( $nome, 'piso: o catálogo do PRÓPRIO pacote devolveu uma linha de comentário como origem suportada — "' . $origem_do_pacote['componente'] . '"' );
	}
}

/* ---------- formulario.existe_e_envia: o site nasce com um formulário que funciona ---------- */

/*
 * O DEFEITO QUE ESTA CHECAGEM FECHA, medido nesta base: o regime `cf7-email`
 * declarava campos, página de confirmação e caixa de leads, e a etapa
 * correspondente emitia uma linha dizendo que o regime existia. Nenhum
 * formulário era criado. O plugin que processa o formulário nem estava no
 * catálogo — o que estava era a CAIXA dele, sozinha, guardando envios que nunca
 * aconteciam. O site saía sem formulário e o relatório saía verde.
 *
 * O que se mede aqui é o caminho inteiro, sem WordPress: o markup tem os campos
 * e o botão de enviar, o destinatário nunca é vazio, o shortcode entra na página
 * e não entra duas vezes.
 */
$nome = 'formulario.existe_e_envia';

$markup_do_form = F3Base_Imp_Formulario::markup( array( 'nome', 'email' ) );

medir( $nome );

foreach ( array( 'seu-nome', 'seu-email', 'seu-telefone', 'sua-mensagem' ) as $campo_do_form ) {
	if ( ! str_contains( $markup_do_form, $campo_do_form ) ) {
		anotar( $nome, 'teto: o formulário não tem o campo ' . $campo_do_form . ' — formulário sem campo é página em branco' );
	}
}

medir( $nome );

if ( ! str_contains( $markup_do_form, '[submit ' ) ) {
	anotar( $nome, 'teto: o formulário não tem botão de enviar — sem ele a pessoa preenche e não tem como mandar' );
}

medir( $nome );

if ( ! str_contains( $markup_do_form, '[text* seu-nome' ) || ! str_contains( $markup_do_form, '[email* seu-email' ) ) {
	anotar( $nome, 'teto: os campos declarados obrigatórios não saíram com o asterisco do CF7 — sem ele o envio passa vazio' );
}

medir( $nome );

if ( str_contains( F3Base_Imp_Formulario::markup( array() ), '[text* ' ) ) {
	anotar( $nome, 'piso: sem obrigatórios declarados, um campo saiu obrigatório assim mesmo — quem declara o que é obrigatório é o arquivo do projeto' );
}

/* O DESTINATÁRIO NUNCA É VAZIO: com ele vazio o CF7 recusa o envio inteiro. */
medir( $nome );

if ( 'admin@exemplo.test' !== F3Base_Imp_Formulario::destinatario( '', 'admin@exemplo.test' ) ) {
	anotar( $nome, 'piso: caixa vazia não caiu no e-mail administrativo — destinatário vazio faz o CF7 recusar o envio, e o formulário fica no ar sem entregar nada' );
}

medir( $nome );

if ( 'leads@exemplo.test' !== F3Base_Imp_Formulario::destinatario( 'leads@exemplo.test', 'admin@exemplo.test' ) ) {
	anotar( $nome, 'teto: a caixa declarada não venceu o e-mail administrativo' );
}

medir( $nome );

if ( 'admin@exemplo.test' !== F3Base_Imp_Formulario::destinatario( 'nao-e-email', 'admin@exemplo.test' ) ) {
	anotar( $nome, 'piso: uma caixa fora do formato de e-mail virou destinatário — o CF7 recusaria o envio e ninguém saberia por quê' );
}

/* O SHORTCODE ENTRA NA PÁGINA, e não entra duas vezes. */
$pagina_sem = '<!-- wp:paragraph --><p>Fale com a equipe.</p><!-- /wp:paragraph -->';
$com_form   = F3Base_Imp_Formulario::conteudo_com_formulario( $pagina_sem, 42, 'contato' );

medir( $nome );

if ( ! $com_form['mudou'] || ! str_contains( $com_form['conteudo'], 'contact-form-7 id="42"' ) ) {
	anotar( $nome, 'teto: o shortcode do formulário não entrou na página — o formulário existe e ninguém consegue vê-lo' );
}

medir( $nome );

if ( ! str_contains( $com_form['conteudo'], 'Fale com a equipe' ) ) {
	anotar( $nome, 'piso: pôr o formulário apagou o conteúdo que já estava na página' );
}

medir( $nome );

$de_novo = F3Base_Imp_Formulario::conteudo_com_formulario( $com_form['conteudo'], 42, 'contato' );

if ( $de_novo['mudou'] || substr_count( $de_novo['conteudo'], 'contact-form-7 id="42"' ) > 1 ) {
	anotar( $nome, 'piso: a segunda execução acrescentou o formulário de novo — o pacote roda mais de uma vez no mesmo site, e a página ficaria com três formulários iguais' );
}

medir( $nome );

$movido = F3Base_Imp_Formulario::conteudo_com_formulario(
	'<!-- wp:paragraph --><p>Antes.</p><!-- /wp:paragraph -->[contact-form-7 id="42" title="contato"]',
	42,
	'contato'
);

if ( $movido['mudou'] ) {
	anotar( $nome, 'piso: o shortcode movido de lugar pelo agente foi tratado como ausente e um segundo foi acrescentado — mover não é apagar' );
}

/* O CORREIO tem destinatário, assunto e o Reply-To de quem escreveu. */
$correio_do_form = F3Base_Imp_Formulario::correio( 'leads@exemplo.test', 'Site', 'wordpress@exemplo.test' );

medir( $nome );

if ( 'leads@exemplo.test' !== $correio_do_form['recipient'] || '' === $correio_do_form['subject'] ) {
	anotar( $nome, 'teto: o e-mail do formulário saiu sem destinatário ou sem assunto' );
}

medir( $nome );

if ( ! str_contains( (string) $correio_do_form['additional_headers'], 'Reply-To: [seu-email]' ) ) {
	anotar( $nome, 'piso: sem Reply-To, responder ao aviso responde ao próprio site e a resposta nunca chega a quem escreveu' );
}

medir( $nome );

foreach ( array( '[seu-nome]', '[seu-email]', '[sua-mensagem]' ) as $tag_do_correio ) {
	if ( ! str_contains( (string) $correio_do_form['body'], $tag_do_correio ) ) {
		anotar( $nome, 'teto: o corpo do e-mail não traz ' . $tag_do_correio . ' — o aviso chega sem o que a pessoa escreveu' );
	}
}

/* ---------- tela.falha_diz_a_saida: falha na tela dá o que fazer ---------- */

/*
 * O DEFEITO QUE ESTA CHECAGEM FECHA, e ele foi introduzido pela correção
 * anterior: a tela passou a imprimir "<etapa>: não deu certo." e nada mais. É o
 * oposto do parágrafo técnico e igualmente inútil — cabe numa linha e não diz
 * nem o que quebrou nem o que fazer, justamente na linha que a pessoa lê quando
 * a implantação falhou.
 *
 * TETO: toda etapa que a tela nomeia tem, na falha, uma saída — e as saídas são
 * DIFERENTES entre si, porque os problemas são diferentes: plugin que não baixou
 * se resolve tentando de novo, limite de servidor se resolve com a hospedagem,
 * valor errado se resolve no arquivo.
 * PISO: nenhuma linha de falha é só o nome da etapa, e a frase de "não há saída
 * conhecida" não pode ser a resposta de todas — se virar, o texto voltou a não
 * servir.
 */
$nome = 'tela.falha_diz_a_saida';

$fonte_dos_lotes = (string) file_get_contents( $raiz . '/includes/class-f3base-imp-lotes.php' );

preg_match( '/private static function linha_de_tela_da_unidade.*?\n\t\}/s', $fonte_dos_lotes, $trecho_dos_nomes );
preg_match( '/private static function falha_com_saida.*?\n\t\}/s', $fonte_dos_lotes, $trecho_das_saidas );

$fonte_dos_nomes  = (string) ( $trecho_dos_nomes[0] ?? '' );
$fonte_das_saidas = (string) ( $trecho_das_saidas[0] ?? '' );

preg_match_all( "/'([a-z_]+)'\s*=>\s*__\(/u", $fonte_dos_nomes, $etapas_com_nome );
preg_match_all( "/'([a-z_]+)'\s*=>\s*__\(\s*'((?:[^'\\\\]|\\\\.)*)'/u", $fonte_das_saidas, $etapas_com_saida );

$nomeadas = array_values( array_unique( $etapas_com_nome[1] ?? array() ) );
$com_saida = array();

foreach ( ( $etapas_com_saida[1] ?? array() ) as $posicao => $etapa_da_saida ) {
	$com_saida[ $etapa_da_saida ] = (string) $etapas_com_saida[2][ $posicao ];
}

medir( $nome );

if ( array() === $nomeadas ) {
	anotar( $nome, 'teto: nenhuma etapa nomeada na tela — a leitura do arquivo nao encontrou a lista' );
}

medir( $nome );

foreach ( $nomeadas as $etapa_nomeada ) {
	if ( ! isset( $com_saida[ $etapa_nomeada ] ) ) {
		anotar( $nome, 'teto: a etapa "' . $etapa_nomeada . '" aparece na tela e NAO tem saida declarada para a falha — quem le essa linha esta lendo porque a implantacao falhou, e precisa saber o que fazer' );
	}
}

/*
 * PISO: as saídas precisam ser DIFERENTES. Uma frase repetida em todas é a
 * mesma coisa que a frase genérica que esta checagem existe para impedir, só
 * que copiada.
 */
medir( $nome );

$vistas = array();

foreach ( $com_saida as $etapa_da_saida => $frase_da_saida ) {
	if ( isset( $vistas[ $frase_da_saida ] ) ) {
		anotar( $nome, 'piso: a saida de "' . $etapa_da_saida . '" e palavra por palavra a de "' . $vistas[ $frase_da_saida ] . '" — saida repetida e a frase generica de novo, so que copiada' );
	}

	$vistas[ $frase_da_saida ] = $etapa_da_saida;
}

/*
 * PISO: toda saída precisa dizer o que FAZER. Sem um verbo de ação, a linha
 * descreve o problema e devolve a pessoa ao ponto de partida.
 */
medir( $nome );

$verbos = array( 'Rode', 'Confira', 'Fale', 'Veja', 'resolva', 'corrija', 'Instale', 'log diz' );

foreach ( $com_saida as $etapa_da_saida => $frase_da_saida ) {
	$tem_verbo = false;

	foreach ( $verbos as $verbo ) {
		if ( str_contains( $frase_da_saida, $verbo ) ) {
			$tem_verbo = true;
			break;
		}
	}

	if ( ! $tem_verbo ) {
		anotar( $nome, 'piso: a saida de "' . $etapa_da_saida . '" nao diz o que FAZER — descrever o problema e devolver a pessoa ao ponto de partida' );
	}
}

medir( $nome );

if ( str_contains( $fonte_dos_nomes, 'nao deu certo' ) || str_contains( $fonte_dos_nomes, 'não deu certo' ) ) {
	anotar( $nome, 'piso: a linha de falha voltou a ser "nao deu certo" — cabe numa linha e nao serve para nada' );
}

/* ---------- preflight.plugin_alheio_nao_impede: o caso de produção ---------- */

/*
 * O DEFEITO, MEDIDO EM PRODUÇÃO NA 1.3.0, e este piso é o que faltava.
 *
 * `fator3-teste-mcp-1.dreamhosters.com`: a hospedagem instala
 * `dreamhost-panel-login` no provisionamento. `plugins_operacionais` nasce
 * vazia — decisão certa, porque o plugin que a hospedagem instala é fato de UM
 * site e não do template. `preflight.baseline` encontrou o plugin, fechou FALHA
 * com uma mensagem que dizia, ela mesma, "eles ficam como estão", e o gate
 * padrão daquela linha era APLICAÇÃO. A unidade `preflight` foi promovida a
 * FALHA, as 39 unidades que declaram depender dela foram suspensas, e o site
 * ficou sem tema, sem plugins, sem páginas e sem posts.
 *
 * Três regras nasceram disso, e as três são medidas aqui:
 *
 * 1. o baseline RELATA e nunca reprova — plugin pré-existente é informação;
 * 2. o gate padrão é FASE: para impedir a instalação, a checagem tem de dizer
 *    que impede;
 * 3. a suspensão do que depende sai dos FATOS CRÍTICOS nomeados, não do
 *    veredito agregado da unidade.
 */
$nome = 'preflight.plugin_alheio_nao_impede';

/*
 * A BANCADA REPRODUZ A UNIDADE DO LOG: os fatos críticos todos de pé, e a linha
 * descritiva do baseline com o achado que a produção teve.
 */
$linhas_do_caso = array(
	array( 'nome' => 'preflight.capacidade:install_plugins', 'estado' => 'OK',    'gate' => 'aplicacao' ),
	array( 'nome' => 'preflight.filesystem_direto',          'estado' => 'OK',    'gate' => 'aplicacao' ),
	array( 'nome' => 'preflight.destino:plugins',            'estado' => 'OK',    'gate' => 'aplicacao' ),
	array( 'nome' => 'preflight.disco',                      'estado' => 'OK',    'gate' => 'aplicacao' ),
	array( 'nome' => 'preflight.limites',                    'estado' => 'OK',    'gate' => 'aplicacao' ),
	array( 'nome' => 'preflight.baseline',                   'estado' => 'FALHA', 'gate' => 'fase' ),
);

medir( $nome );

$critico_do_caso = F3Base_Imp_Lotes::fato_critico_caiu_publico( $linhas_do_caso );

if ( $critico_do_caso['caiu'] ) {
	anotar( $nome, 'PISO DO CASO DE PRODUCAO: com todos os fatos criticos de pe e so a linha DESCRITIVA do baseline adversa, a unidade suspendeu o que depende dela — e foi assim que um site ficou sem tema, sem plugins e sem conteudo' );
}

/*
 * PISO AO CONTRÁRIO: quando um fato crítico DE VERDADE cai, a suspensão precisa
 * acontecer. Sem esta metade, a correção viraria cegueira.
 */
$linhas_sem_escrita = $linhas_do_caso;
$linhas_sem_escrita[2]['estado'] = 'FALHA';

medir( $nome );

$critico_sem_escrita = F3Base_Imp_Lotes::fato_critico_caiu_publico( $linhas_sem_escrita );

if ( ! $critico_sem_escrita['caiu'] ) {
	anotar( $nome, 'piso ao contrario: sem poder escrever no diretorio de plugins a instalacao NAO foi suspensa — instalar sem destino gravavel deixa o site pela metade' );
}

medir( $nome );

if ( ! str_contains( $critico_sem_escrita['motivo'], 'preflight.destino:plugins' ) ) {
	anotar( $nome, 'teto: o fato critico que caiu nao saiu NOMEADO — quem le precisa saber qual foi' );
}

/* O BASELINE NAO REPROVA, e a fonte disso e o codigo que o emite. */
$fonte_do_baseline = (string) file_get_contents( $raiz . '/includes/class-f3base-imp-lotes.php' );

/*
 * A JANELA É EM VOLTA DO RÓTULO, e não uma expressão que varre o arquivo até
 * achá-lo: com `.*?` a partir da primeira chamada de relatório, o casamento
 * engoliria todas as emissões anteriores e a medição falaria sobre o arquivo
 * inteiro em vez desta linha.
 */
$posicao_do_baseline = strpos( $fonte_do_baseline, "'preflight.baseline'," );
$emissao_do_baseline = false === $posicao_do_baseline
	? ''
	: substr( $fonte_do_baseline, max( 0, $posicao_do_baseline - 200 ), 1600 );

medir( $nome );

if ( '' === $emissao_do_baseline ) {
	anotar( $nome, 'teto: a emissao de preflight.baseline nao foi encontrada no codigo' );
}

medir( $nome );

if ( str_contains( $emissao_do_baseline, 'avaliar(' ) ) {
	anotar( $nome, 'piso: preflight.baseline voltou a ter dois ramos — plugin pre-existente e informacao, e informacao nao tem ramo adverso' );
}

medir( $nome );

if ( ! str_contains( $emissao_do_baseline, "'gate'      => 'relato'" ) ) {
	anotar( $nome, 'piso: preflight.baseline nao declara gate de RELATO — sem isso ele volta a poder suspender a instalacao inteira, e declarar FASE diria que este host nao produz o censo de plugins do proprio disco' );
}

/* O GATE PADRAO E RELATO, e nao aplicacao nem fase. */
$fonte_do_relatorio = (string) file_get_contents( $raiz . '/includes/class-f3base-imp-relatorio.php' );

medir( $nome );

if ( ! str_contains( $fonte_do_relatorio, "( isset( \$extra['gate'] ) ? (string) \$extra['gate'] : self::GATE_RELATO )" ) ) {
	anotar( $nome, 'piso: o gate PADRAO deixou de ser relato — aplicacao devolve a catastrofe de 1.3.0 (toda linha nao classificada passa a poder derrubar a instalacao inteira) e fase devolve a frase falsa de 1.7.2 (o relatorio afirmando que este host nao produz a evidencia que ele acabou de medir)' );
}

/* ---------- projeto.schema_valida: o arquivo que o operador abre tem validador ---------- */

/*
 * `config/projeto.json` é o único arquivo que o operador abre, e é por isso que
 * ele precisa do mesmo validador que a configuração — não de um parecido. Quem
 * valida é `F3Base_Imp_Config::validar_contra()`, apontado para outro schema: um
 * segundo validador seria um segundo conjunto de regras divergindo do primeiro
 * no dia em que alguém corrigisse só um.
 *
 * TETO: o arquivo que o pacote entrega valida, e o produtor o carrega.
 * PISO: um mutante por regra que o schema promete — tipo, chave não declarada,
 * obrigatória ausente, enum, padrão de texto, mínimo numérico e o registro do
 * ponto de contato sem tipo. Chave nova sem mutante é chave cujo schema nunca
 * provou reprovar nada.
 */
$nome = 'projeto.schema_valida';

medir( $nome );

if ( ! F3Base_Imp_Projeto::carregar() ) {
	anotar( $nome, 'teto: projeto.json não valida contra o próprio schema — ' . implode( ' | ', F3Base_Imp_Projeto::erros() ) );
}

medir( $nome );

/*
 * A REGRA É "NASCE PREENCHIDO", e não "nasce com ESTE fuso. Fixar o valor aqui
 * amarraria o piso ao projeto que este template atende hoje: um template
 * entregue a um cliente em outro fuso passaria a reprovar a suíte sem ter
 * defeito nenhum, e a saída fácil seria mexer no piso. O que se mede é a forma
 * — identificador IANA de área/local, que é o que o WordPress aceita — e o fato
 * de não estar vazio.
 */
$fuso_entregue = (string) F3Base_Imp_Projeto::obter( 'ambiente.fuso', '' );

if ( 1 !== preg_match( '#^[A-Za-z]+/[A-Za-z_+-]+$#', $fuso_entregue ) ) {
	anotar( $nome, 'teto: o fuso entregue é "' . $fuso_entregue . '", que não tem a forma de identificador IANA — o campo nasce PREENCHIDO de propósito, porque instalação limpa nasce em UTC e isso está errado para quase todo mundo' );
}

medir( $nome );

if ( '' !== (string) F3Base_Imp_Projeto::obter( 'contato.whatsapp_e164', 'x' ) ) {
	anotar( $nome, 'teto: um campo do operador nasceu preenchido sem ser caso declarado — campo que nasce com valor de outro projeto é herdado sem conferir' );
}

medir( $nome );

if ( 'x' !== (string) F3Base_Imp_Projeto::obter( 'campo.que.nao.existe', 'x' ) ) {
	anotar( $nome, 'piso: caminho ausente não devolveu o padrão explícito do chamador' );
}

medir( $nome );

if ( false !== F3Base_Imp_Projeto::existe( 'campo.que.nao.existe' ) ) {
	anotar( $nome, 'piso: existe() não distingue ausente de declarado' );
}

$projeto_original = json_decode( (string) file_get_contents( $raiz . '/config/projeto.json' ), true );

$mutantes_do_projeto = array(
	'tipo errado'            => static function ( array $p ): array {
		$p['fato_juridico']['retencao_leads_meses'] = '12';
		return $p;
	},
	'chave não declarada'    => static function ( array $p ): array {
		$p['tracking']['id_do_fornecedor_novo'] = 'X-1';
		return $p;
	},
	'obrigatória ausente'    => static function ( array $p ): array {
		unset( $p['contato']['controlador']['razao_social'] );
		return $p;
	},
	'enum de indexação'      => static function ( array $p ): array {
		$p['ambiente']['indexar'] = 'as-vezes';
		return $p;
	},
	'enum de permalinks'     => static function ( array $p ): array {
		$p['ambiente']['permalinks_decisao'] = 'aplicar-sempre-e-torcer';
		return $p;
	},
	'enum de consentimento'  => static function ( array $p ): array {
		$p['fato_juridico']['consentimento_padrao'] = 'talvez';
		return $p;
	},
	/*
	 * O PADRÃO DE TEXTO dos identificadores de conta entra no piso porque o
	 * erro que ele pega é o mais comum de todos: colar o identificador do
	 * fornecedor errado, ou a propriedade antiga do Universal Analytics no
	 * campo do GA4. Os dois "funcionam" — nada quebra, e a medição some.
	 */
	'padrão do measurement'  => static function ( array $p ): array {
		$p['tracking']['ga4_measurement_id'] = 'UA-123456-1';
		return $p;
	},
	'padrão do container'    => static function ( array $p ): array {
		$p['tracking']['gtm_container_id'] = 'G-ABCDEFGHIJ';
		return $p;
	},
	'mínimo dos saltos'      => static function ( array $p ): array {
		$p['origem_confiavel']['saltos'] = 0;
		return $p;
	},
	'retenção negativa'      => static function ( array $p ): array {
		$p['fato_juridico']['retencao_leads_meses'] = -1;
		return $p;
	},
	'contato sem tipo'       => static function ( array $p ): array {
		$p['organizacao']['ponto_de_contato'] = array( array( 'telefone' => '+5511900000000' ) );
		return $p;
	},
	'regime desconhecido'    => static function ( array $p ): array {
		$p['formularios'][0]['regime'] = 'telepatia';
		return $p;
	},
	'campo fora do registro' => static function ( array $p ): array {
		$p['formularios'][0]['ativo'] = true;
		return $p;
	},
);

foreach ( $mutantes_do_projeto as $rotulo_do_mutante => $mutar_projeto ) {
	medir( $nome );

	if ( array() === F3Base_Imp_Config::validar_contra( $mutar_projeto( $projeto_original ), F3Base_Imp_Projeto::SCHEMA ) ) {
		anotar( $nome, 'piso: mutante "' . $rotulo_do_mutante . '" passou sem erro — validador cego' );
	}
}

medir( $nome );

if ( array() !== F3Base_Imp_Config::validar_contra( $projeto_original, F3Base_Imp_Projeto::SCHEMA ) ) {
	anotar( $nome, 'piso: o arquivo correto deixou de ficar em silêncio' );
}

/*
 * O PONTEIRO DO `destino` RESOLVE DENTRO DO PRÓPRIO ARQUIVO, e é isso que fez a
 * trinca de `formularios` mover inteira em vez de partida.
 */
foreach ( F3Base_Imp_Projeto::lista( 'formularios' ) as $indice_do_form => $entrada_do_form ) {
	unset( $entrada_do_form );

	medir( $nome );

	$ponteiro = (string) F3Base_Imp_Projeto::obter( 'formularios.' . $indice_do_form . '.destino', '' );

	if ( '' === $ponteiro ) {
		anotar( $nome, 'teto: a entrada ' . $indice_do_form . ' não declara destino — sem ponteiro não há o que decidir se o regime existe' );
		continue;
	}

	if ( ! F3Base_Imp_Projeto::existe( $ponteiro ) ) {
		anotar( $nome, 'piso: o destino "' . $ponteiro . '" da entrada ' . $indice_do_form . ' NÃO resolve dentro de config/projeto.json — ponteiro que aponta para fora do arquivo devolve vazio em silêncio, e o regime fecharia N/A dizendo que falta preencher uma chave que está preenchida' );
	}
}

/* ---------- decisoes.leitor_do_pacote: o produtor lê o que o catálogo diz ---------- */

/*
 * O DETECTOR `decisoes.fonte_unica` lê o catálogo pela leitura da SUÍTE, que é
 * outro código. Isso é de propósito — auditor que usa o leitor do auditado não
 * acusa defeito do leitor —, mas deixa uma metade sem piso: o produtor que o
 * RUNTIME usa. Se `F3Base_Imp_Decisoes` passasse a enxergar uma linha a mais ou
 * a menos, o detector continuaria verde e o site sairia com outra decisão.
 *
 * TETO: o produtor devolve o catálogo inteiro do pacote, cada valor com o tipo
 * que o JSON declara, e `bloco()` remonta a lista na ordem posicional que a
 * precedência de origem depende.
 * PISO: as quatro formas de o catálogo mentir, na bancada — decisão DESLIGADA
 * com `#` na frente, linha em branco com as tabulações, linha sem motivo e
 * célula que não é JSON. Nenhuma delas pode virar decisão.
 */
$nome = 'decisoes.leitor_do_pacote';

$catalogo_do_pacote = F3Base_Imp_Decisoes::catalogo();

medir( $nome );

if ( array() === $catalogo_do_pacote ) {
	anotar( $nome, 'teto: o produtor devolveu o catálogo VAZIO — sem ele todo consumidor cai no lado seguro e o pacote entrega o contrário do que decidiu' );
}

medir( $nome );

foreach ( array_keys( $catalogo_do_pacote ) as $chave_lida ) {
	if ( 1 !== preg_match( '/^[a-z][a-z0-9_]*(?:\.[a-z0-9_-]+)*$/', (string) $chave_lida ) ) {
		anotar( $nome, 'teto: o produtor devolveu a chave "' . $chave_lida . '", que não tem forma de caminho pontilhado' );
	}
}

/*
 * A BANCADA REPRODUZ A FORMA REAL DO ARQUIVO, e é isso que faz cada guarda ter
 * piso próprio: a linha de comentário carrega as TRÊS colunas com JSON válido e
 * motivo com corpo — uma decisão DESLIGADA, que é como um catálogo ganha linha
 * fantasma de verdade —, e a linha em branco carrega as tabulações. Com uma
 * bancada mais fácil que o mundo, derrubar a guarda do "#" não mudaria
 * resultado nenhum e o piso aprovaria por acidente.
 */
$bancada_de_decisoes = tempnam( sys_get_temp_dir(), 'f3b-dec' );

file_put_contents(
	$bancada_de_decisoes,
	"# chave\tvalor\tmotivo\n"
	. "# cabecalhos.hsts\ttrue\tMotivo com corpo suficiente para passar por toda guarda que nao seja a do cerquilha, e e esse o ponto desta linha.\n"
	. "\t\t\n"
	. "orcamento_pagina.css_kb\t100\tMotivo com corpo suficiente para a linha ser uma decisao legitima da bancada, e ele precisa de oitenta caracteres.\n"
	. "bots_ia.llms_txt_tipos\t[\"page\",\"post\"]\tSegundo motivo com corpo, diferente do primeiro, para a bancada ter uma lista e um numero.\n"
	. "cabecalhos.coop\t\"same-origin-allow-popups\"\n"
	. "cadencia_relatorio.periodicidade\tnao-sou-json\tMotivo com corpo suficiente, mas o valor ao lado nao e JSON e a linha nao pode virar decisao.\n"
	. "plugins.autoupdate\t\"todos\"\t\n"
);

$lido_da_bancada_de_decisoes = F3Base_Imp_Decisoes::catalogo_de( $bancada_de_decisoes );

medir( $nome );

if ( 2 !== count( $lido_da_bancada_de_decisoes ) ) {
	anotar( $nome, 'piso: a bancada devolveu ' . count( $lido_da_bancada_de_decisoes ) . ' decisão(ões) e declarou 2 completas — ' . wp_json_encode( array_keys( $lido_da_bancada_de_decisoes ) ) );
}

medir( $nome );

foreach ( array_keys( $lido_da_bancada_de_decisoes ) as $chave_da_bancada ) {
	if ( str_starts_with( ltrim( (string) $chave_da_bancada ), '#' ) ) {
		anotar( $nome, 'piso: uma decisão DESLIGADA com "#" na frente voltou à vida — a linha tem as três colunas, JSON válido e motivo, e só a guarda a mantinha fora' );
	}
}

medir( $nome );

foreach ( array_keys( $lido_da_bancada_de_decisoes ) as $chave_da_bancada ) {
	if ( '' === trim( (string) $chave_da_bancada ) ) {
		anotar( $nome, 'piso: uma linha EM BRANCO virou decisão — linha só de tabulações tem as três colunas e todas vazias' );
	}
}

medir( $nome );

if ( array_key_exists( 'cabecalhos.coop', $lido_da_bancada_de_decisoes ) ) {
	anotar( $nome, 'piso: a linha SEM a coluna de motivo virou decisão — decisão sem o que a sustenta é o número que ninguém mais sabe explicar, e foi para não ter isso que o catálogo existe' );
}

medir( $nome );

if ( array_key_exists( 'plugins.autoupdate', $lido_da_bancada_de_decisoes ) ) {
	anotar( $nome, 'piso: a linha com o motivo VAZIO virou decisão — coluna presente e vazia é o mesmo que coluna ausente' );
}

medir( $nome );

if ( array_key_exists( 'cadencia_relatorio.periodicidade', $lido_da_bancada_de_decisoes ) ) {
	anotar( $nome, 'piso: a célula que não é JSON válido virou decisão — sem forma declarada não há como distinguir lista de string, e o defeito apareceria no consumidor, longe daqui' );
}

medir( $nome );

if ( 100 !== ( $lido_da_bancada_de_decisoes['orcamento_pagina.css_kb'] ?? null ) ) {
	anotar( $nome, 'teto: o número saiu como ' . var_export( $lido_da_bancada_de_decisoes['orcamento_pagina.css_kb'] ?? null, true ) . ' — valor em JSON existe para o tipo sobreviver ao TSV' );
}

medir( $nome );

if ( array( 'page', 'post' ) !== ( $lido_da_bancada_de_decisoes['bots_ia.llms_txt_tipos'] ?? null ) ) {
	anotar( $nome, 'teto: a lista saiu como ' . wp_json_encode( $lido_da_bancada_de_decisoes['bots_ia.llms_txt_tipos'] ?? null ) . ' — sem JSON não há como distinguir a lista da string "page,post"' );
}

unlink( $bancada_de_decisoes );

/*
 * `bloco()` remonta o registro na ORDEM POSICIONAL, e a ordem importa: a
 * precedência de origem de um plugin é posicional, e ela mudaria com uma edição
 * de texto que ninguém chamaria de mudança de comportamento.
 */
$bloco_de_instalaveis = F3Base_Imp_Decisoes::bloco( 'plugins.instalaveis' );

medir( $nome );

if ( array_keys( $bloco_de_instalaveis ) !== range( 0, count( $bloco_de_instalaveis ) - 1 ) ) {
	anotar( $nome, 'teto: plugins.instalaveis não saiu como lista indexada — saiu ' . wp_json_encode( array_keys( $bloco_de_instalaveis ) ) . ', e o consumidor espera lista' );
}

medir( $nome );

if ( '' === F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.0', 'slug' ) ) {
	anotar( $nome, 'teto: o campo slug da primeira entrada saiu vazio — o registro não remontou' );
}

medir( $nome );

if ( '' !== F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.0', 'campo-que-nao-existe' ) ) {
	anotar( $nome, 'piso: campo ausente devolveu valor — campo que o registro não declara não pode virar valor plausível' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Decisoes::bloco( '' ) ) {
	anotar( $nome, 'piso: prefixo vazio devolveu bloco — prefixo vazio casaria com o catálogo inteiro' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Decisoes::catalogo_de( '' ) ) {
	anotar( $nome, 'piso: caminho vazio devolveu decisão' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Decisoes::catalogo_de( $raiz . '/config/nao-existe.tsv' ) ) {
	anotar( $nome, 'piso: catálogo ausente devolveu decisão — arquivo que não existe não pode responder pelo pacote' );
}

/* ---------- journal.escritas_desta_execucao: quem escreveu, lido do registro ---------- */

/*
 * O DEFEITO QUE ESTA LEITURA EXISTE PARA FECHAR, medido em produção
 * (2026-09-04): "7 de 9 página(s) publicada(s) ainda carrega(m) a marca" — e as
 * sete tinham sido publicadas por AQUELA MESMA execução, minutos antes. Para o
 * veredito poder discriminar quem escreveu cada página, o conjunto das escritas
 * precisa sair do REGISTRO que o pacote já mantém, e não de uma lista à mão.
 *
 * TETO: as entradas de post DESTA execução entregam os IDs, sem repetição e em
 * ordem, tanto na inserção (`post.excluir`) quanto na atualização
 * (`post.restaurar`).
 * PISO: entrada de OUTRA execução não entra; entrada que não é de post não
 * entra; e entrada sem operação inversa não inventa id nenhum.
 */
$nome = 'journal.escritas_desta_execucao';

$entradas_do_journal = array(
	array( 'tipo' => 'post',   'execucao' => 'exec-a', 'inversa' => array( 'acao' => 'post.excluir', 'id' => 13 ) ),
	array( 'tipo' => 'post',   'execucao' => 'exec-a', 'inversa' => array( 'acao' => 'post.restaurar', 'id' => 11, 'campos' => array() ) ),
	array( 'tipo' => 'post',   'execucao' => 'exec-a', 'inversa' => array( 'acao' => 'post.restaurar', 'id' => 11, 'campos' => array() ) ),
	array( 'tipo' => 'post',   'execucao' => 'exec-b', 'inversa' => array( 'acao' => 'post.excluir', 'id' => 99 ) ),
	array( 'tipo' => 'option', 'execucao' => 'exec-a', 'inversa' => array( 'acao' => 'option.restaurar', 'id' => 77 ) ),
	array( 'tipo' => 'post',   'execucao' => 'exec-a', 'inversa' => array() ),
);

$escritas_de_a = F3Base_Imp_Journal::ids_de_post_das_entradas( $entradas_do_journal, 'exec-a' );

medir( $nome );

if ( array( 11, 13 ) !== $escritas_de_a ) {
	anotar( $nome, 'teto: as escritas de post desta execução saíram como ' . wp_json_encode( $escritas_de_a ) . ' e a bancada declarou 11 e 13 — inserção e atualização carregam o id na operação inversa, e as duas contam' );
}

medir( $nome );

if ( in_array( 99, $escritas_de_a, true ) ) {
	anotar( $nome, 'piso: a escrita de OUTRA execução entrou no conjunto — uma retomada passaria a contar como sua a página que a execução anterior publicou' );
}

medir( $nome );

if ( in_array( 77, $escritas_de_a, true ) ) {
	anotar( $nome, 'piso: uma entrada que não é de post entrou no conjunto — o id de uma option não é id de página, e confundi-los absolveria uma página que ninguém escreveu' );
}

medir( $nome );

if ( array( 11, 13, 99 ) !== F3Base_Imp_Journal::ids_de_post_das_entradas( $entradas_do_journal, '' ) ) {
	anotar( $nome, 'teto: sem execução declarada a leitura precisa devolver o registro inteiro, e não devolveu' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Journal::ids_de_post_das_entradas( array(), 'exec-a' ) ) {
	anotar( $nome, 'piso: journal vazio produziu id — escopo vazio não pode inventar escrita nenhuma, ou toda página marcada seria absolvida de graça' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Journal::ids_de_post_das_entradas( array( array( 'tipo' => 'post', 'execucao' => 'exec-a', 'inversa' => array() ) ), 'exec-a' ) ) {
	anotar( $nome, 'piso: entrada de post SEM operação inversa produziu id — sem o id não há o que comparar, e inventar zero absolveria a página de id zero' );
}

/* ---------- fases.regra_de_aplicabilidade: N/A por fase, e o achado que impede a cegueira ---------- */

/*
 * AS DUAS METADES DA 1.1.6, MEDIDAS JUNTAS, e é de propósito que elas moram na
 * mesma checagem: uma sem a outra é defeito, não meia correção.
 *
 * A primeira metade separa o que a 1.1.5 fundia. `BLOCKED` estava dizendo duas
 * coisas — "falta alguém fazer alguma coisa" e "esta fase não produz este tipo
 * de evidência" —, e o leitor não tinha como distingui-las: 27 linhas amarelas
 * numa rodada impecável, 26 delas do segundo tipo.
 *
 * A segunda metade é o preço da primeira. Uma checagem que fecha N/A porque a
 * fase dela não é esta fase fecharia N/A PARA SEMPRE se ninguém nunca rodasse
 * aquela fase — e silêncio permanente é aprovação por omissão, que é o oposto
 * do que a regra de 1.0.5 exige. Por isso o registro existe, e por isso os
 * pisos abaixo plantam exatamente o modo pelo qual ele se apagaria sozinho:
 * bastaria BLOCKED ou N/A contarem como "a fase rodou".
 */

$nome = 'fases.regra_de_aplicabilidade';

/* TETO: fase declarada FORA da fase corrente é aplicabilidade falsa, e isso é N/A. */
foreach ( array( 'local', 'producao', 'campo' ) as $fase_de_fora ) {
	$v = F3Base_Imp_Fases::aplicabilidade( $fase_de_fora, 'build' );

	medir( $nome );

	if ( 'N/A' !== $v['estado'] || false !== $v['aplicavel'] ) {
		anotar( $nome, 'teto: checagem de fase ' . $fase_de_fora . ' numa rodada de build fechou ' . $v['estado'] . ' — não falta ação de ninguém ali, falta a fase, e condição de aplicabilidade falsa é N/A' );
	}

	medir( $nome );

	if ( ! contem( $v['porque'], $fase_de_fora ) ) {
		anotar( $nome, 'teto: o N/A de fase não NOMEIA a fase em que a checagem é medida (' . $fase_de_fora . ') — N/A que não diz onde a coisa é medida é N/A que ninguém sabe desfazer' );
	}
}

/* TETO: fase declarada IGUAL à corrente continua BLOCKED — a pergunta se aplica aqui. */
foreach ( array( array( 'build', 'build' ), array( 'producao', 'producao' ), array( 'local', 'local' ), array( 'campo', 'campo' ) ) as $par ) {
	$v = F3Base_Imp_Fases::aplicabilidade( $par[0], $par[1] );

	medir( $nome );

	if ( 'BLOCKED' !== $v['estado'] || true !== $v['aplicavel'] ) {
		anotar( $nome, 'teto: checagem de fase ' . $par[0] . ' rodando NA fase ' . $par[1] . ' fechou ' . $v['estado'] . ' — na fase certa o que falta é pré-condição, e pré-condição ausente é BLOCKED, nunca N/A' );
	}
}

/*
 * PISO 1 — NÃO DECLARAR FASE NÃO PODE SER O CAMINHO BARATO PARA SAIR DO BLOCKED.
 * Se fase vazia ou desconhecida absolvesse, bastaria apagar a declaração para
 * uma pendência real virar N/A e sumir do relatório.
 */
foreach ( array( '', 'navegador', 'homologacao', 'BUILD' ) as $fase_torta ) {
	$v = F3Base_Imp_Fases::aplicabilidade( $fase_torta, 'build' );

	medir( $nome );

	if ( 'BLOCKED' !== $v['estado'] ) {
		anotar( $nome, 'piso: fase declarada "' . $fase_torta . '", fora da lista fechada, fechou ' . $v['estado'] . ' — apagar ou errar a declaração viraria a saída barata do BLOCKED' );
	}
}

/* PISO 2 — ambiente que não sabe em que fase está não dispensa checagem nenhuma. */
foreach ( array( '', 'qualquer', 'PRODUCAO' ) as $corrente_torta ) {
	$v = F3Base_Imp_Fases::aplicabilidade( 'producao', $corrente_torta );

	medir( $nome );

	if ( 'BLOCKED' !== $v['estado'] ) {
		anotar( $nome, 'piso: fase corrente "' . $corrente_torta . '", fora da lista fechada, absolveu uma checagem de produção — emissor sem fase declarada calaria o relatório inteiro' );
	}
}

/* ---------- o registro: o que cada fase espera, e a fase que nunca rodou ---------- */

$linhas_da_bancada = array(
	array( 'nome' => 'bancada.build_medida',   'fase' => 'build',    'estado' => 'OK' ),
	array( 'nome' => 'bancada.build_falhou',   'fase' => 'build',    'estado' => 'FALHA' ),
	array( 'nome' => 'bancada.local_bloqueada','fase' => 'local',    'estado' => 'BLOCKED' ),
	array( 'nome' => 'bancada.producao_na',    'fase' => 'producao', 'estado' => 'N/A' ),
	array( 'nome' => 'bancada.producao_na2',   'fase' => 'producao', 'estado' => 'N/A' ),
);

$reg = F3Base_Imp_Fases::registro( $linhas_da_bancada, array(), 1000 );

/* TETO: a fase com linha medida rodou AGORA e não é achado. */
medir( $nome );

if ( true !== $reg['fases']['build']['rodou_agora'] || false !== $reg['fases']['build']['nunca'] ) {
	anotar( $nome, 'teto: a fase build tinha linha em OK e não foi contada como executada' );
}

medir( $nome );

if ( 2 !== $reg['fases']['build']['quantas'] ) {
	anotar( $nome, 'teto: o registro conta ' . (int) $reg['fases']['build']['quantas'] . ' checagem(ns) esperando build, e a bancada declarou 2 — contagem que não descreve o que saiu é a doença que a 1.0.17 fechou' );
}

/*
 * PISO 3 — E ELE É O CENTRO DESTA RELEASE: BLOCKED e N/A NÃO contam como
 * medição. Se contassem, a regra de aplicabilidade apagaria o próprio
 * contrapeso no instante em que passasse a valer: as checagens de navegador
 * viram N/A, o N/A marcaria a fase como executada, e a fase que nunca rodou
 * sumiria do relatório sem que ninguém tivesse rodado nada.
 */
medir( $nome );

if ( false !== $reg['fases']['local']['rodou_agora'] || true !== $reg['fases']['local']['nunca'] ) {
	anotar( $nome, 'piso: a fase local tinha SÓ linha em BLOCKED e foi contada como executada — BLOCKED diz que a medição não pôde acontecer, e contá-lo faz a fase se aprovar por omissão' );
}

medir( $nome );

if ( false !== $reg['fases']['producao']['rodou_agora'] || true !== $reg['fases']['producao']['nunca'] ) {
	anotar( $nome, 'piso: a fase producao tinha SÓ linhas em N/A e foi contada como executada — é exatamente assim que a regra de aplicabilidade da 1.1.6 apagaria o próprio contrapeso' );
}

/* TETO: fase sem ninguém esperando NÃO é achado — não há cobertura a cobrar. */
medir( $nome );

if ( false !== $reg['fases']['campo']['nunca'] || 0 !== $reg['fases']['campo']['quantas'] ) {
	anotar( $nome, 'teto: a fase campo não tinha checagem nenhuma esperando por ela e virou achado — aviso sobre ausência que ninguém pediu é o aviso que sai sempre' );
}

/* TETO: fase nunca executada é ACHADO ADVERSO, e o estado é WARN. */
medir( $nome );

if ( 'WARN' !== $reg['estado'] ) {
	anotar( $nome, 'teto: com duas fases nunca executadas o registro fechou ' . $reg['estado'] . ' — "nunca medido" é adverso de verdade, e silêncio aqui é aprovação por omissão' );
}

medir( $nome );

if ( array( 'local', 'producao' ) !== $reg['nunca'] ) {
	anotar( $nome, 'teto: as fases nunca executadas não saem NOMEADAS: ' . wp_json_encode( $reg['nunca'] ) );
}

/*
 * FASE TODA-N/A NÃO É FASE ESQUECIDA — a correção da 1.1.7, e ela é do mesmo
 * defeito que as outras desta release. Depois que `mcp.autoteste_recusa_credencial`
 * passou para a fase `campo`, aquela fase ficou com checagens que fecham N/A em
 * TODA execução deste host, por desenho: o WARN "campo NUNCA foi executada"
 * passaria a sair para sempre, sobre uma ausência que ninguém vai preencher e
 * que não nomeia ação nenhuma.
 *
 * TETO: a fase cujas checagens esperadas fecharam TODAS em N/A é declarada NÃO
 * APLICÁVEL e sai FORA da cobrança.
 * PISO: a fase com pelo menos uma checagem que podia ter medido e não mediu
 * — uma linha em BLOCKED — continua sendo cobrada, e o estado continua WARN. E
 * o N/A continua NÃO registrando a fase como executada: `nunca`, `rodou_agora`
 * e o registro durável não se movem.
 */
medir( $nome );

if ( true !== ( $reg['fases']['producao']['nao_aplicavel'] ?? null ) ) {
	anotar( $nome, 'teto: a fase producao tinha SÓ linhas em N/A e não foi declarada NÃO APLICÁVEL — cobrar de um emissor a evidência que ele não produz é o aviso permanente que a 1.1.7 tirou do relatório' );
}

medir( $nome );

if ( false !== ( $reg['fases']['local']['nao_aplicavel'] ?? null ) ) {
	anotar( $nome, 'piso: a fase local tinha uma linha em BLOCKED — a pergunta se aplicava ali e a resposta não veio — e foi declarada não aplicável, que é a saída barata para calar a cobrança' );
}

medir( $nome );

if ( array( 'local' ) !== ( $reg['cobrar'] ?? array() ) ) {
	anotar( $nome, 'teto: a lista do que se COBRA saiu como ' . wp_json_encode( $reg['cobrar'] ?? array() ) . ' — só a fase que tinha o que medir e não mediu entra nela' );
}

/*
 * PISO DA MEMÓRIA: declarar a fase não aplicável NÃO pode registrá-la como
 * executada. É a mesma regra do PISO 3, um nível acima — se `nunca` ou
 * `rodou_agora` se movessem aqui, a fase sumiria do registro durável e a
 * pergunta deixaria de existir no dia em que ela passasse a ter o que medir.
 */
medir( $nome );

if ( true !== $reg['fases']['producao']['nunca'] || false !== $reg['fases']['producao']['rodou_agora'] ) {
	anotar( $nome, 'piso: a fase declarada não aplicável foi registrada como executada — N/A continua não medindo, e a mudança é só no que vira WARN' );
}

/*
 * TETO DO ESTADO: com TODA fase pendente sendo toda-N/A, o registro CALA. É o
 * caso do host depois da 1.1.7 — `campo` com as duas checagens em N/A — e é o
 * aviso que saía sempre.
 */
$reg_so_na = F3Base_Imp_Fases::registro(
	array(
		array( 'nome' => 'bancada.build_medida', 'fase' => 'build', 'estado' => 'OK' ),
		array( 'nome' => 'bancada.campo_na',     'fase' => 'campo', 'estado' => 'N/A' ),
	),
	array(),
	1000
);

medir( $nome );

if ( 'OK' !== $reg_so_na['estado'] || array() !== ( $reg_so_na['cobrar'] ?? array( 'x' ) ) ) {
	anotar( $nome, 'teto: a fase cujas checagens fecharam TODAS em N/A continuou produzindo WARN (' . $reg_so_na['estado'] . ') — é o aviso que sai sempre sobre uma ausência por desenho' );
}

medir( $nome );

if ( array( 'campo' ) !== ( $reg_so_na['nunca'] ?? array() ) ) {
	anotar( $nome, 'piso: a fase não aplicável SUMIU do registro de "nunca executadas" — ela deixa de ser cobrada, e não deixa de ser relatada' );
}

/* PISO: uma única linha medível não medida basta para a fase voltar à cobrança. */
$reg_com_bloqueio = F3Base_Imp_Fases::registro(
	array(
		array( 'nome' => 'bancada.build_medida',   'fase' => 'build', 'estado' => 'OK' ),
		array( 'nome' => 'bancada.campo_na',       'fase' => 'campo', 'estado' => 'N/A' ),
		array( 'nome' => 'bancada.campo_bloqueada','fase' => 'campo', 'estado' => 'BLOCKED' ),
	),
	array(),
	1000
);

medir( $nome );

if ( 'WARN' !== $reg_com_bloqueio['estado'] || array( 'campo' ) !== ( $reg_com_bloqueio['cobrar'] ?? array() ) ) {
	anotar( $nome, 'piso: a fase com uma linha em BLOCKED ao lado de uma em N/A deixou de ser cobrada (' . $reg_com_bloqueio['estado'] . ') — ali a pergunta se aplicava e a resposta não veio' );
}

/* TETO: com toda fase esperada medida, o registro CALA — o aviso não sai sempre. */
$reg_limpo = F3Base_Imp_Fases::registro(
	array( array( 'nome' => 'bancada.build_medida', 'fase' => 'build', 'estado' => 'OK' ) ),
	array(),
	1000
);

medir( $nome );

if ( 'OK' !== $reg_limpo['estado'] || array() !== $reg_limpo['nunca'] ) {
	anotar( $nome, 'teto: com a única fase esperada medida o registro fechou ' . $reg_limpo['estado'] . ' — aviso que sai mesmo sem achado treina o operador a ignorar aviso' );
}

/*
 * TETO DA DURABILIDADE: o registro de uma execução ANTERIOR tira a fase de
 * "nunca". É essa memória que faz a fase de navegador, rodada um dia, continuar
 * contando — e é ela que a rodada de build não tem como reproduzir sozinha.
 */
$reg_com_memoria = F3Base_Imp_Fases::registro(
	$linhas_da_bancada,
	array( 'local' => array( 'ultima' => 900, 'por' => 'navegador', 'medidas' => 3 ) ),
	1000
);

medir( $nome );

if ( false !== $reg_com_memoria['fases']['local']['nunca'] || 900 !== $reg_com_memoria['fases']['local']['ultima'] ) {
	anotar( $nome, 'teto: a fase local tinha execução registrada de antes e continuou como nunca executada — sem memória, a regra de fase vira cegueira' );
}

medir( $nome );

if ( 'NUNCA EXECUTADA' === F3Base_Imp_Fases::quando( $reg_com_memoria['fases']['local'] ) ) {
	anotar( $nome, 'teto: a fase com execução registrada continua sendo descrita como NUNCA EXECUTADA' );
}

medir( $nome );

if ( 'NUNCA EXECUTADA' !== F3Base_Imp_Fases::quando( $reg['fases']['local'] ) ) {
	anotar( $nome, 'piso: a fase sem execução nenhuma não sai com todas as letras — traço, data de hoje ou branco fazem "não sei" passar por "agora"' );
}

/*
 * PISO 4 — QUEM NÃO MEDIU NÃO CARIMBA. `durar()` conserva o que já estava para
 * a fase não medida e carimba só a medida: é a mesma regra da decisão 64, onde
 * o ramo que preserva movia a base e apagava o fato que ele existia para
 * lembrar.
 */
$durou = F3Base_Imp_Fases::durar(
	$reg_com_memoria,
	array( 'local' => array( 'ultima' => 900, 'por' => 'navegador', 'medidas' => 3 ) ),
	1000,
	'suite'
);

medir( $nome );

if ( 900 !== (int) ( $durou['local']['ultima'] ?? 0 ) || 'navegador' !== (string) ( $durou['local']['por'] ?? '' ) ) {
	anotar( $nome, 'piso: a fase que NÃO foi medida nesta rodada recebeu carimbo de agora — a rodada de build passaria a afirmar que a fase de navegador rodou' );
}

medir( $nome );

if ( 1000 !== (int) ( $durou['build']['ultima'] ?? 0 ) ) {
	anotar( $nome, 'teto: a fase medida nesta rodada não recebeu o carimbo desta rodada — sem isso o registro nunca sairia de "nunca executada"' );
}

medir( $nome );

if ( isset( $durou['producao'] ) || isset( $durou['campo'] ) ) {
	anotar( $nome, 'piso: fase sem medição agora e sem registro anterior entrou no arquivo durável — entrada inventada é a forma silenciosa de a fase se declarar executada' );
}

/* PISO 5 — WAIVED não mede: desvio ACEITO é FALHA assinada, não fase exercitada. */
$reg_waived = F3Base_Imp_Fases::registro(
	array( array( 'nome' => 'bancada.waived', 'fase' => 'producao', 'estado' => 'WAIVED' ) ),
	array(),
	1000
);

medir( $nome );

if ( true !== $reg_waived['fases']['producao']['nunca'] ) {
	anotar( $nome, 'piso: uma linha em WAIVED marcou a fase como executada — um waiver bem colocado apagaria a pergunta que o registro existe para fazer' );
}

/* TETO: a lista de fases fechadas é a do contrato, e são quatro. */
medir( $nome );

if ( array( 'build', 'local', 'producao', 'campo' ) !== F3Base_Imp_Fases::fases() ) {
	anotar( $nome, 'teto: as fases fechadas deixaram de ser as quatro do contrato: ' . wp_json_encode( F3Base_Imp_Fases::fases() ) );
}

F3Base_Imp_Relatorio::zerar();

/* ---------- lotes.gate_de_fase_nao_derruba_estado: o que o relatorio AFIRMA e o que ele FAZ ---------- */

/*
 * A CONTRADICAO MEDIDA NA 1.7.2, e ela saiu inteira numa tela so. O relatorio
 * escrevia "GATE(S) DE FASE em aberto, declarado(s) e NAO somado(s) a este gate:
 * release.versao_site_core (FALHA)" e, tres linhas acima, "estado da aplicacao:
 * FALHA_PARCIAL" — derivado de uma contagem CRUA de FALHA que conta aquela mesma
 * linha. O estado e a PRIMEIRA condicao do gate da autodesativacao: a linha
 * decidia o gate por dentro enquanto o texto dizia que nao decidia.
 *
 * A saida escolhida foi manter a contagem crua — toda FALHA derruba o estado, de
 * qualquer gate, e nenhuma checagem de gate `fase` do pacote mede evidencia que
 * este host produz — e PROIBIR a outra ponta: linha de gate `fase` nao fecha
 * FALHA. O piso planta exatamente a contradicao.
 */
$nome = 'lotes.gate_de_fase_nao_derruba_estado';

/* TETO: um relatorio saudavel — fase em BLOCKED, e FALHA so onde ela e dita. */
$linhas_ok = array(
	array( 'nome' => 'entrega.rodada_limpa', 'estado' => 'BLOCKED', 'gate' => F3Base_Imp_Relatorio::GATE_FASE ),
	array( 'nome' => 'orcamento.medicao_de_pagina', 'estado' => 'N/A', 'gate' => F3Base_Imp_Relatorio::GATE_FASE ),
	array( 'nome' => 'plugins.site_core_versao', 'estado' => 'FALHA', 'gate' => F3Base_Imp_Relatorio::GATE_RELATO ),
	array( 'nome' => 'entrega.tema', 'estado' => 'FALHA', 'gate' => F3Base_Imp_Relatorio::GATE_APLICACAO ),
);

medir( $nome );

if ( array() !== F3Base_Imp_Lotes::contradicao_de_gate_nao_somado( $linhas_ok ) ) {
	anotar( $nome, 'teto: a regra acusou um relatorio coerente — FALHA de relato e de aplicacao derruba o estado E o relatorio diz isso; so o gate de fase afirma que a evidencia vem de outro lugar' );
}

/* PISO 1: a contradicao da 1.7.2, plantada. */
$linhas_contraditorias = array(
	array( 'nome' => 'release.versao_site_core', 'estado' => 'FALHA', 'gate' => F3Base_Imp_Relatorio::GATE_FASE ),
);

medir( $nome );

if ( array( 'release.versao_site_core' ) !== F3Base_Imp_Lotes::contradicao_de_gate_nao_somado( $linhas_contraditorias ) ) {
	anotar( $nome, 'PISO: uma linha declarada como NAO somada ao gate fechou FALHA — e FALHA derruba o estado, que e a primeira condicao daquele gate — e a regra nao a acusou' );
}

/* PISO 2: BLOCKED de fase NAO e contradicao — ele nao entra na contagem que derruba o estado. */
medir( $nome );

if ( array() !== F3Base_Imp_Lotes::contradicao_de_gate_nao_somado( array( array( 'nome' => 'entrega.rodada_limpa', 'estado' => 'BLOCKED', 'gate' => F3Base_Imp_Relatorio::GATE_FASE ) ) ) ) {
	anotar( $nome, 'piso ao contrario: BLOCKED de fase foi acusado — a regra passaria a cobrar de toda evidencia externa um estado que ela nao tem como fechar, e a correcao viraria ruido permanente' );
}

/* PISO 3: a acusacao e do gate `fase` e de mais nenhum — relato diz o que faz. */
medir( $nome );

if ( array() !== F3Base_Imp_Lotes::contradicao_de_gate_nao_somado( array( array( 'nome' => 'plugins.site_core_versao', 'estado' => 'FALHA', 'gate' => F3Base_Imp_Relatorio::GATE_RELATO ) ) ) ) {
	anotar( $nome, 'piso ao contrario: FALHA de RELATO foi acusada — o host mediu, o relatorio afirma que ela derruba o estado, e nao ha contradicao nenhuma para acusar' );
}

/* TETO DO VOCABULARIO: tres gates desde a 2.1.0, e o padrao e o que nao decide nem mente. */
medir( $nome );

if ( 'relato' !== F3Base_Imp_Relatorio::GATE_RELATO || 'fase' !== F3Base_Imp_Relatorio::GATE_FASE ) {
	anotar( $nome, 'teto: os valores de gate deixaram de ser os do contrato' );
}

/* ---------- plugins.veredito_de_versao_do_site_core: um fato, uma linha, um veredito ---------- */

/*
 * O DEFEITO MEDIDO NA 1.7.2: o MESMO par de numeros — a versao instalada do
 * plugin e a que este pacote carrega — saia em DUAS linhas com severidades
 * DIFERENTES, `plugins.site_core_versao` (WARN) e `release.versao_site_core`
 * (FALHA). A segunda morreu; esta bancada mede a que ficou, nos cinco ramos, e
 * planta os dois defeitos que a fariam voltar a mentir.
 */
$nome = 'plugins.veredito_de_versao_do_site_core';

$ramos = array(
	'instalada atras'      => array( '1.0.0', '1.0.1', 'FALHA' ),
	'instalada a frente'   => array( '1.0.2', '1.0.1', 'OK' ),
	'iguais'               => array( '1.0.1', '1.0.1', 'OK' ),
	'reserva sem numero'   => array( '1.0.1', '', 'WARN' ),
	'nada instalado'       => array( '', '1.0.1', 'N/A' ),
);

foreach ( $ramos as $ramo => $caso ) {
	$veredito = F3Base_Imp_Plugins::veredito_da_versao_do_site_core( $caso[0], $caso[1], 'wp-content/plugins/implantador-base/assets/plugins/x-1.0.1.zip' );

	medir( $nome );

	if ( $caso[2] !== $veredito['estado'] ) {
		anotar( $nome, 'teto do ramo "' . $ramo . '": esperado ' . $caso[2] . ' e veio ' . $veredito['estado'] );
	}
}

/*
 * PISO 1 — O RAMO "ATRAS" NAO PODE SER WARN. WARN nao entra na contagem que
 * derruba o estado, e e o estado que mantem o implantador no ar: com WARN, um
 * site que ficou com o plugin superado veria a ferramenta que corrige isso sair
 * de cena na mesma execucao.
 */
$atras = F3Base_Imp_Plugins::veredito_da_versao_do_site_core( '1.0.0', '1.0.1', 'wp-content/plugins/implantador-base/assets/plugins/x-1.0.1.zip' );

medir( $nome );

if ( 'FALHA' !== $atras['estado'] ) {
	anotar( $nome, 'PISO: o ramo da versao superada voltou a nao ser FALHA — a entrega prometeu o plugin que o pacote carrega e entregou outro, e so FALHA derruba o estado e segura a autodesativacao' );
}

/*
 * PISO 2 — O RAMO "A FRENTE" NAO PODE SER ADVERSO. Era a regra `===` da linha
 * removida: ela acusava o caso CORRETO, o site com uma versao mais nova do que a
 * reserva, que este pacote nao rebaixa por desenho.
 */
$frente = F3Base_Imp_Plugins::veredito_da_versao_do_site_core( '1.0.2', '1.0.1', '' );

medir( $nome );

if ( 'OK' !== $frente['estado'] ) {
	anotar( $nome, 'PISO: o site com o plugin MAIS NOVO que a reserva foi acusado — e a comparacao de igualdade da linha removida na 1.7.3, reprovando o caso certo' );
}

/* TETO: a FALHA nomeia as duas versoes, a saida e o endereco da copia embutida. */
foreach ( array( '1.0.0', '1.0.1', 'assets/plugins/x-1.0.1.zip' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $atras['motivo'], $trecho ) ) {
		anotar( $nome, 'teto da mensagem: a FALHA nao nomeia "' . $trecho . '" — sem as duas versoes e sem o endereco da copia, a linha manda fazer algo que o leitor nao consegue achar' );
	}
}

/*
 * PISO 3 — SEM ENDERECO, A SEGUNDA SAIDA NAO E PROMETIDA. Era o defeito da
 * 1.7.2: a frase mandava "instalar a copia embutida a mao pela tela de plugins"
 * sem dizer onde ela esta, e quem envia o implantador envia o bundle sem abri-lo.
 */
$sem_endereco = F3Base_Imp_Plugins::veredito_da_versao_do_site_core( '1.0.0', '1.0.1', '' );

medir( $nome );

if ( contem( $sem_endereco['motivo'], 'Plugins ›' ) || contem( $sem_endereco['saida'], 'Plugins ›' ) ) {
	anotar( $nome, 'PISO: sem endereco resolvido a mensagem continua mandando o operador a tela de plugins buscar a copia embutida, sem dizer onde ela esta — caminho que o leitor nao consegue seguir e caminho que nao existe' );
}

/* E COM endereco resolvido ela PRECISA mandar, senao a saida some junto com o defeito. */
medir( $nome );

if ( ! contem( $atras['saida'], 'Plugins ›' ) ) {
	anotar( $nome, 'teto: com o endereco resolvido a segunda saida sumiu da frase do operador — a correcao teria apagado o caminho em vez de o completar' );
}

/*
 * UM FATO, UMA LINHA. A regra e pura e recebe FATOS extraidos do codigo, nunca
 * codigo em string: quantas funcoes do implantador consultam a versao embarcada
 * E emitem uma linha a respeito. Duas seriam dois vereditos sobre o mesmo par de
 * numeros, que e o defeito que esta release fechou.
 */
function f3b_emissores_do_veredito_de_versao( array $funcoes ): array {
	$nomes = array();

	foreach ( $funcoes as $funcao => $fatos ) {
		if ( ( $fatos['consulta'] ?? false ) && ( $fatos['emite'] ?? false ) ) {
			$nomes[] = (string) $funcao;
		}
	}

	sort( $nomes );

	return $nomes;
}

$funcoes_medidas = array();

foreach ( glob( $raiz . '/includes/*.php' ) as $arquivo ) {
	$sem_comentario = '';

	foreach ( token_get_all( (string) file_get_contents( $arquivo ) ) as $token ) {
		if ( is_array( $token ) && in_array( $token[0], array( T_COMMENT, T_DOC_COMMENT ), true ) ) {
			continue;
		}

		$sem_comentario .= is_array( $token ) ? $token[1] : $token;
	}

	if ( ! preg_match_all( '/function\s+([a-z0-9_]+)\s*\(/i', $sem_comentario, $ms, PREG_OFFSET_CAPTURE ) ) {
		continue;
	}

	$total = count( $ms[1] );

	for ( $i = 0; $i < $total; $i++ ) {
		$inicio = (int) $ms[1][ $i ][1];
		$fim    = $i + 1 < $total ? (int) $ms[1][ $i + 1 ][1] : strlen( $sem_comentario );
		$corpo  = substr( $sem_comentario, $inicio, $fim - $inicio );

		$funcoes_medidas[ basename( $arquivo ) . '::' . $ms[1][ $i ][0] ] = array(
			'consulta' => str_contains( $corpo, 'versao_embarcada_do_site_core(' ),
			'emite'    => str_contains( $corpo, 'F3Base_Imp_Relatorio::emitir(' ) || str_contains( $corpo, 'F3Base_Imp_Relatorio::condicional(' ) || str_contains( $corpo, 'F3Base_Imp_Relatorio::avaliar(' ),
		);
	}
}

$emissores = f3b_emissores_do_veredito_de_versao( $funcoes_medidas );

medir( $nome );

if ( array( 'class-f3base-imp-plugins.php::relatar_versao_do_site_core' ) !== $emissores ) {
	anotar( $nome, 'TETO: o veredito sobre a versao do site-core deixou de ter UM emissor so — encontrados: ' . ( array() === $emissores ? 'nenhum' : implode( ', ', $emissores ) ) . '. Dois emissores sao dois vereditos sobre o mesmo par de numeros, e na 1.7.2 eles sairam com severidades diferentes na mesma tela' );
}

medir( $nome );

if ( array( 'a', 'b' ) !== f3b_emissores_do_veredito_de_versao( array( 'a' => array( 'consulta' => true, 'emite' => true ), 'b' => array( 'consulta' => true, 'emite' => true ), 'c' => array( 'consulta' => false, 'emite' => true ) ) ) ) {
	anotar( $nome, 'PISO: a regra nao acusou o segundo emissor do mesmo veredito — sem isso ela aprovaria a volta de release.versao_site_core sem dizer nada' );
}


/* ---------- limpeza.plano_dos_padroes: o que sai e o que fica, regra pura ---------- */

/*
 * A 2.1.0 criou a unidade de limpeza por decisão do dono, depois de uma
 * implantação real entregar o site com três temas de fábrica, o Akismet e o
 * Hello Dolly no lugar. A regra que decide o que sai é pura — recebe o medido e
 * o declarado — e as GUARDAS são o piso: o tema ativo e o pai dele nunca saem,
 * o que não está na lista nunca sai, o que não está instalado não é erro.
 */

$nome = 'limpeza.plano_dos_padroes';
$L    = 'F3Base_Imp_Limpeza';

$temas_do_catalogo   = array_map( 'strval', (array) F3Base_Imp_Decisoes::valor( 'limpeza.temas_padrao' ) );
$plugins_do_catalogo = array_map( 'strval', (array) F3Base_Imp_Decisoes::valor( 'limpeza.plugins_padrao' ) );
$tema_do_pacote      = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );

medir( $nome );

if ( array() === $temas_do_catalogo || array() === $plugins_do_catalogo ) {
	anotar( $nome, 'teto: o catálogo não declara limpeza.temas_padrao e limpeza.plugins_padrao — sem lista a unidade fecha N/A e o site sai com os padrões de fábrica' );
}

medir( $nome );

if ( '' !== $tema_do_pacote && in_array( $tema_do_pacote, $temas_do_catalogo, true ) ) {
	anotar( $nome, 'teto: o tema do pacote (' . $tema_do_pacote . ') está na lista de temas a remover' );
}

/* TETO: a instalação limpa medida em 2026-09-07 — três temas de fábrica, dois plugins de fábrica, o Akismet ativo. */
$plano_real = $L::plano(
	$temas_do_catalogo,
	array_merge( $temas_do_catalogo, array( $tema_do_pacote ) ),
	$tema_do_pacote,
	$tema_do_pacote,
	$plugins_do_catalogo,
	array_merge( $plugins_do_catalogo, array( 'dreamhost-panel-login.php', 'wordpress-seo/wp-seo.php' ) ),
	array( 'akismet/akismet.php', 'wordpress-seo/wp-seo.php' )
);

foreach ( $temas_do_catalogo as $slug_de_tema ) {
	medir( $nome );

	if ( $L::REMOVER !== ( $plano_real['temas'][ $slug_de_tema ]['acao'] ?? '' ) ) {
		anotar( $nome, 'teto: o tema de fábrica ' . $slug_de_tema . ', instalado e inativo, não saiu como REMOVER — ' . ( $plano_real['temas'][ $slug_de_tema ]['acao'] ?? 'ausente do plano' ) );
	}
}

foreach ( $plugins_do_catalogo as $arquivo_de_plugin ) {
	medir( $nome );

	if ( $L::REMOVER !== ( $plano_real['plugins'][ $arquivo_de_plugin ]['acao'] ?? '' ) ) {
		anotar( $nome, 'teto: o plugin de fábrica ' . $arquivo_de_plugin . ' não saiu como REMOVER' );
	}
}

medir( $nome );

if ( true !== ( $plano_real['plugins']['akismet/akismet.php']['desativar'] ?? null ) ) {
	anotar( $nome, 'teto: o Akismet ATIVO não foi marcado para desativação antes da remoção — apagar plugin ativo sem os hooks de desativação deixa resíduo' );
}

medir( $nome );

if ( isset( $plano_real['plugins']['dreamhost-panel-login.php'] ) || isset( $plano_real['plugins']['wordpress-seo/wp-seo.php'] ) || isset( $plano_real['temas'][ $tema_do_pacote ] ) ) {
	anotar( $nome, 'piso: o plano tocou em algo que a lista não declara — o que é de alguém fica' );
}

/* PISO 1: tema ATIVO declarado na lista por engano — nunca sai. */
$plano_ativo = $L::plano( array( 'twentytwentyfive' ), array( 'twentytwentyfive' ), 'twentytwentyfive', 'twentytwentyfive', array(), array(), array() );

medir( $nome );

if ( $L::PULAR !== ( $plano_ativo['temas']['twentytwentyfive']['acao'] ?? '' ) || ! contem( (string) ( $plano_ativo['temas']['twentytwentyfive']['motivo'] ?? '' ), 'ATIVO' ) ) {
	anotar( $nome, 'piso cego: o tema ATIVO declarado na lista não foi PULADO nomeando o motivo — a regra apagaria o tema em uso' );
}

/* PISO 2: tema PAI do ativo declarado na lista — nunca sai. */
$plano_pai = $L::plano( array( 'twentytwentyfive' ), array( 'twentytwentyfive', 'filho' ), 'filho', 'twentytwentyfive', array(), array(), array() );

medir( $nome );

if ( $L::PULAR !== ( $plano_pai['temas']['twentytwentyfive']['acao'] ?? '' ) || ! contem( (string) ( $plano_pai['temas']['twentytwentyfive']['motivo'] ?? '' ), 'PAI' ) ) {
	anotar( $nome, 'piso cego: o tema PAI do ativo declarado na lista não foi PULADO — a regra apagaria o pai e derrubaria o filho' );
}

/* PISO 3: declarado e não instalado é AUSENTE, nunca erro nem remoção. */
$plano_ausente = $L::plano( array( 'twentytwentythree' ), array( 'f3base' ), 'f3base', 'f3base', array( 'hello.php' ), array(), array() );

medir( $nome );

if ( $L::AUSENTE !== ( $plano_ausente['temas']['twentytwentythree']['acao'] ?? '' ) || $L::AUSENTE !== ( $plano_ausente['plugins']['hello.php']['acao'] ?? '' ) ) {
	anotar( $nome, 'piso cego: item declarado e não instalado não saiu como AUSENTE' );
}

/* PISO 4: lista vazia é plano vazio — a limpeza só remove o que está declarado. */
$plano_vazio = $L::plano( array(), array( 'twentytwentyfive' ), 'f3base', 'f3base', array(), array( 'akismet/akismet.php' ), array() );

medir( $nome );

if ( array() !== $plano_vazio['temas'] || array() !== $plano_vazio['plugins'] ) {
	anotar( $nome, 'piso cego: com a lista vazia o plano não saiu vazio — a regra passaria a decidir sozinha o que é padrão de fábrica' );
}

/* ---------- formulario.na_pagina_declarada: a página do regime vem do arquivo certo, e a falha fala ---------- */

/*
 * O DEFEITO MEDIDO em 2026-09-07 (vinha da 1.7.4): a referência da página do
 * regime era a ÚNICA chave do bloco lida de config/site.json, onde o bloco não
 * existe; voltava vazia, `por_na_pagina()` devolvia vazio em silêncio e a
 * unidade fechava OK com o formulário em página nenhuma. Dois tetos e um piso:
 * a leitura sai do arquivo certo para a configuração REAL do pacote; a
 * colocação com referência vazia REPROVA nomeando o que falta; e a mesma
 * função, com a referência lida do arquivo errado, devolve vazio — que é o
 * defeito plantado, para provar que o teto não passaria por ele.
 */

$nome = 'formulario.na_pagina_declarada';

$entradas_de_formulario = F3Base_Imp_Projeto::lista( 'formularios' );
$com_pagina             = 0;

foreach ( $entradas_de_formulario as $indice_f => $entrada_f ) {
	unset( $entrada_f );

	$regime_f = (string) F3Base_Imp_Projeto::obter( 'formularios.' . $indice_f . '.regime', '' );
	$ref_f    = F3Base_Imp_Lotes::pagina_ref_do_regime( $regime_f, 'formularios.' . $indice_f );

	medir( $nome );

	if ( '' === $ref_f ) {
		anotar( $nome, 'teto: a entrada formularios.' . $indice_f . ' (regime ' . $regime_f . ') não resolve página nenhuma pelo leitor do projeto — a chave da página está fora de config/projeto.json ou vazia' );
		continue;
	}

	$com_pagina++;

	medir( $nome );

	if ( 0 === count( array_filter( F3Base_Imp_Config::lista( 'paginas' ), static fn( $p ): bool => is_array( $p ) && $ref_f === (string) ( $p['ref'] ?? '' ) ) ) ) {
		anotar( $nome, 'teto: a página "' . $ref_f . '" do regime ' . $regime_f . ' não é uma entrada de paginas em config/site.json — o formulário seria posto numa página que o pacote não gerencia' );
	}
}

medir( $nome );

if ( 0 === $com_pagina ) {
	anotar( $nome, 'teto: nenhum regime de formulário declara página, e escopo vazio não pode aprovar' );
}

/* TETO 2: referência VAZIA reprova nomeando pagina_ref e o arquivo em que ela mora. */
$sem_ref = F3Base_Imp_Formulario::por_na_pagina( array( 'id' => 'contato' ), 42, 'contato' );

medir( $nome );

if ( false !== $sem_ref['ok'] || ! contem( $sem_ref['motivo'], 'pagina_ref' ) || ! contem( $sem_ref['motivo'], F3Base_Imp_Projeto::ARQUIVO ) ) {
	anotar( $nome, 'teto: com pagina_ref vazia a colocação não reprovou nomeando a chave e o arquivo — ' . var_export( $sem_ref, true ) );
}

/* PISO: a leitura pelo arquivo ERRADO — o defeito — devolve vazio para a mesma chave que o leitor certo resolve. */
foreach ( $entradas_de_formulario as $indice_f => $entrada_f ) {
	unset( $entrada_f );

	$regime_f = (string) F3Base_Imp_Projeto::obter( 'formularios.' . $indice_f . '.regime', '' );
	$chave_f  = 'whatsapp' === $regime_f ? '.pagina_canonica_ref' : '.pagina_ref';

	medir( $nome );

	if ( '' !== (string) F3Base_Imp_Config::obter( 'formularios.' . $indice_f . $chave_f, '' ) ) {
		anotar( $nome, 'piso: config/site.json passou a ter formularios.' . $indice_f . $chave_f . ' — o bloco mora em config/projeto.json, e um bloco em dois arquivos é o ponteiro apontando para um registro que não existe inteiro' );
	}
}

/* ---------- plugins.supressao_por_transiente: o mapa aceita transiente, e o nome vem do catálogo ---------- */

/*
 * O `wp-mcp-ultimate` decide o assistente por TRANSIENTE, e option nenhuma o
 * desarma: em toda instalação limpa o lote seguinte à ativação era sequestrado
 * uma vez. A 2.1.0 estende o mapa de supressão com a forma `transiente:<nome>`.
 * Sem WordPress a supressão em si não roda; o que se mede aqui é o CONTRATO:
 * a entrada do catálogo existe para o servidor do canal, tem a forma declarada,
 * o nome bate com o que o código do plugin lê, e a forma antiga (option.chave)
 * continua sendo entendida — as duas convivem no mesmo mapa.
 */

$nome = 'plugins.supressao_por_transiente';

$mapa_de_supressao = (array) F3Base_Imp_Decisoes::bloco( 'plugins.supressao_onboarding' );
$slug_do_servidor  = F3Base_Imp_Entrega::slug_por_papel( 'canal-mcp-servidor' );

medir( $nome );

if ( '' === $slug_do_servidor || ! isset( $mapa_de_supressao[ $slug_do_servidor ] ) ) {
	anotar( $nome, 'teto: o servidor do canal (' . $slug_do_servidor . ') não tem entrada em plugins.supressao_onboarding — o sequestro do lote seguinte à ativação volta em toda instalação limpa' );
} else {
	$entradas_do_servidor = array_map( 'strval', (array) $mapa_de_supressao[ $slug_do_servidor ] );
	$transientes          = array_values( array_filter( $entradas_do_servidor, static fn( string $e ): bool => str_starts_with( $e, 'transiente:' ) ) );

	medir( $nome );

	if ( array( 'transiente:wp_mcp_ultimate_activated' ) !== $transientes ) {
		anotar( $nome, 'teto: a entrada do servidor do canal não declara o transiente que o código dele lê (wp_mcp_ultimate_activated, includes/Plugin.php) — declarado: ' . implode( ', ', $entradas_do_servidor ) );
	}
}

/* A forma antiga continua válida: option.chave para o plugin de SEO. */
medir( $nome );

$entradas_do_seo = isset( $mapa_de_supressao[ F3Base_Imp_Seo::slug() ] ) ? array_map( 'strval', (array) $mapa_de_supressao[ F3Base_Imp_Seo::slug() ] ) : array();

if ( array() === $entradas_do_seo || array() !== array_filter( $entradas_do_seo, static fn( string $e ): bool => str_starts_with( $e, 'transiente:' ) || false === strpos( $e, '.' ) ) ) {
	anotar( $nome, 'teto: a entrada do plugin de SEO deixou de ser da forma option.chave — as duas formas convivem, e esta é a que desarma assistente decidido por option' );
}

/* PISO: o código da supressão reconhece o prefixo, e recusa transiente sem nome. */
$codigo_da_supressao = (string) file_get_contents( $raiz . '/includes/class-f3base-imp-plugins.php' );

medir( $nome );

if ( ! contem( $codigo_da_supressao, "str_starts_with( \$caminho, 'transiente:' )" ) || ! contem( $codigo_da_supressao, 'delete_transient( $nome_do_transiente )' ) ) {
	anotar( $nome, 'piso: suprimir_redirecionamento_de_ativacao() não reconhece a forma transiente:<nome> nem apaga o transiente — a entrada do catálogo seria lida como option "transiente" com chave vazia' );
}

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
