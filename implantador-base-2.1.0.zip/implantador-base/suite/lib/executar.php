<?php
/**
 * Runner do comando único.
 *
 * Ordem fixa: empacotar primeiro, checar depois, resumir por último. O código de
 * saída vem da contagem que `estado()` acumulou — não de uma variável local que
 * alguém possa esquecer de atualizar.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$suite = dirname( __DIR__ );
$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );

require $suite . '/lib/regra.php';
require $suite . '/lib/empacotar.php';

foreach ( array( 'estatica', 'tema', 'conteudo', 'a11y', 'copy', 'entrega', 'funcional', 'bloqueadas', 'meta' ) as $modulo ) {
	require $suite . '/checagens/' . $modulo . '.php';
}

require $suite . '/lib/documentos.php';

if ( '' === $raiz ) {
	fwrite( STDERR, "uso: executar.php <caminho-do-pacote>\n" );
	exit( 2 );
}

/**
 * Emite o veredito de uma checagem, nos DOIS ramos.
 *
 * Toda checagem que varre alguma coisa devolve `medidas`: quantas unidades ela
 * de fato olhou. ESCOPO VAZIO NÃO APROVA — um prefixo de caminho digitado
 * errado faria a varredura percorrer zero arquivo e a linha sairia OK, que é o
 * instrumento mentindo com a melhor cara possível. Zero medida fecha BLOCKED.
 *
 * @param array{ok:bool,achados:array<int,string>,medidas?:int} $r      Veredito.
 * @param string                                                $nome   Nome.
 * @param string                                                $msg_ok Mensagem do ramo aprovado.
 * @param string                                                $classe Classe de evidência.
 * @param string                                                $fase   Fase.
 * @return void
 */
function emitir( array $r, string $nome, string $msg_ok, string $classe, string $fase ): void {
	if ( isset( $r['medidas'] ) && 0 === (int) $r['medidas'] ) {
		estado(
			'BLOCKED',
			$nome,
			'escopo vazio: a checagem não mediu nenhuma unidade, e o que não foi medido não pode ser aprovado.',
			'pendencia-externa',
			$fase
		);
		return;
	}

	$sufixo = isset( $r['medidas'] ) ? sprintf( ' (%d unidade(s) medida(s))', (int) $r['medidas'] ) : '';

	estado_por_origem(
		(bool) $r['ok'],
		'site',
		$nome,
		$msg_ok . $sufixo,
		count( $r['achados'] ) . ' achado(s) em ' . ( $r['medidas'] ?? '?' ) . ' unidade(s) medida(s): ' . f3b_amostra( $r['achados'] ),
		$classe,
		$fase
	);
}

/* =========================================================================
 * ETAPA 1 — EMPACOTAR. Sempre a primeira, e ela pode abortar a rodada.
 * ====================================================================== */

echo "== etapa 1: empacotamento ==\n";

if ( ! is_dir( $raiz ) ) {
	estado(
		'BLOCKED',
		'pacote.artefato',
		'o artefato a verificar não existe no caminho informado: ' . $raiz,
		'pendencia-externa',
		'build'
	);
	echo "\nrodada abortada: sem artefato não há o que empacotar nem o que verificar.\n";
	exit( 2 );
}

$lista = f3b_ck_allow_list( $raiz, $suite );
$fora  = array_values( array_filter( $lista['achados'], static fn( string $a ): bool => str_starts_with( $a, 'FORA DO INVENTÁRIO' ) ) );

if ( array() !== $fora ) {
	foreach ( $fora as $achado ) {
		fwrite( STDERR, 'EMPACOTAMENTO ABORTADO — ' . $achado . "\n" );
	}

	fwrite( STDERR, "o inventário de suite/inventario.tsv é a allow-list de caminhos: arquivo fora dela não entra no bundle.\n" );
	exit( 2 );
}

$build = f3b_empacotar( $raiz, $suite );

foreach ( $build['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

echo sprintf(
	"   documentos regenerados: %s\n",
	array() === $build['documentos'] ? '(nenhum: as regiões geradas já estavam iguais à leitura de disco)' : implode( ', ', $build['documentos'] )
);

echo sprintf(
	"   bundle: %s\n   embutidos: %s\n",
	'' !== $build['bundle'] && is_file( $build['bundle'] ) ? $build['bundle'] : '(não montado)',
	array() === $build['embutidos'] ? '(nenhum)' : implode( ', ', $build['embutidos'] )
);

echo "\n";

echo "== etapa 2: checagens ==\n";

emitir(
	$lista,
	'pacote.allow_list',
	sprintf( 'todo arquivo do pacote consta do inventário de caminho→papel (%d caminho(s) exato(s) declarado(s)).', count( f3b_inventario( $suite )['exatos'] ) ),
	'analise-estatica',
	'build'
);

emitir(
	f3b_ck_build_fresco( $build['bundle'], $raiz ),
	'pacote.build_fresco',
	'o artefato de build é mais novo que toda fonte do pacote.',
	'medida',
	'build'
);

emitir(
	f3b_ck_backup_sempre_oculto( $raiz ),
	'pacote.backup_sempre_oculto',
	'nenhuma linha do pacote monta caminho de backup sem o ponto na frente da marca — o que constrói caminho vai por caminho_do_backup(), e o literal que só reconhece o nome antigo fica de fora, porque reconhecer é obrigação da migração.',
	'analise-estatica',
	'build'
);

emitir(
	f3b_ck_cabecalho_aninhado( $raiz ),
	'pacote.sem_cabecalho_de_plugin_aninhado',
	'a raiz tem exatamente um .php com "Plugin Name:" e nenhum .php a um nível de subdiretório tem cabeçalho de plugin — o alcance de get_plugins() enxerga um único candidato, e o link "Ativar plugin" da tela de instalação não tem para onde errar.',
	'analise-estatica',
	'build'
);

/* ---------- estáticas ---------- */

emitir( f3b_ck_php_lint( $raiz ), 'estatica.php_lint', 'todo .php do pacote analisa sob php -l.', 'analise-estatica', 'build' );
emitir( f3b_ck_json_valido( $raiz ), 'estatica.json_valido', 'todo .json do pacote analisa.', 'analise-estatica', 'build' );
emitir( f3b_ck_js_lint( $raiz, $suite ), 'estatica.js_lint', 'todo .js/.mjs do pacote passa em node --check.', 'analise-estatica', 'build' );
emitir( f3b_ck_wp_comentarios( $raiz, $suite ), 'estatica.wp_comentarios_balanceados', 'comentários wp: balanceados e JSON de atributo válido em templates, parts, conteúdo e patterns executados.', 'analise-estatica', 'build' );
emitir( f3b_ck_escrita_unica( $raiz ), 'estatica.detector_escrita_unica', 'nenhuma escrita de option fora dos dois gravadores declarados; varredura do pacote inteiro, inclusive a suíte.', 'analise-estatica', 'build' );
emitir( f3b_ck_version_compare( $raiz ), 'estatica.detector_version_compare', 'todo version_compare usa operador da lista fechada.', 'analise-estatica', 'build' );
emitir( f3b_ck_condicao_literal( $raiz ), 'estatica.detector_condicao_literal', 'nenhuma checagem com condição constante fora de ramo de if/else com irmão que emite outro veredito.', 'analise-estatica', 'build' );
emitir( f3b_ck_codigo_em_string( $raiz ), 'estatica.detector_codigo_em_string', 'nenhum JavaScript, SQL ou shell em heredoc ou concatenação PHP.', 'analise-estatica', 'build' );
/*
 * O QUE ESTE DETECTOR MEDE, dito com as palavras exatas — e a mudança da 1.0.18
 * é essa frase. Ele prova que toda chave declarada tem uma LINHA QUE A LÊ, e LER
 * NÃO É CONSUMIR: a chave lida cuja leitura não muda nada passa por aqui, e foi
 * o que aconteceu com `cadencia_relatorio.apos_n_ajustes` até a 1.0.17 — lida,
 * gravada numa option que ninguém relia, e impressa no relatório como gatilho
 * sobre um contador inexistente. Detector que mede a coisa errada é pior que
 * detector ausente, porque produz confiança; a saída foi parar de afirmar o que
 * ele não mede e acrescentar o irmão que mede a outra metade,
 * `estatica.option_gravada_sem_leitor`.
 */
emitir( f3b_ck_chave_sem_consumidor( $raiz ), 'estatica.detector_chave_sem_consumidor', 'toda chave de site.json tem uma LINHA QUE A LÊ (cruzamento geral, cobertura bidirecional). O que esta linha NÃO afirma: que a leitura muda alguma coisa — ler não é consumir, e quem mede a outra metade do trajeto é estatica.option_gravada_sem_leitor.', 'analise-estatica', 'build' );
emitir( f3b_ck_destino_de_formulario_resolve( $raiz ), 'estatica.destino_de_formulario_resolve', 'o destino declarado por cada regime de formulário é um CAMINHO, e todo caminho resolve numa chave que existe em config/projeto.json — entrada sem destino, caminho que não resolve e caminho que entra em formularios pelo índice de OUTRA entrada são achados. Caminho que não resolve devolve vazio em silêncio, e vazio é exatamente o valor que faz o regime "não existir": o estado sairia verde com uma instrução impossível, mandando preencher uma chave que não está no arquivo.', 'analise-estatica', 'build' );
emitir( f3b_ck_gate_de_fase_do_metadado( $raiz ), 'estatica.gate_de_fase_do_metadado', 'a lista de gates de FASE sai do metadado gate=fase e não de lista paralela: gates_de_fase() não traz nome de checagem literal, nenhum nome está nos dois gates ao mesmo tempo, e todo emissor de gate=fase nomeia a própria checagem com literal. Duas fontes para o mesmo fato divergem, e a divergência da 1.0.17 saiu impressa dentro de uma linha só do log.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_residuo_de_chave_removida( $raiz ), 'estatica.sem_residuo_de_chave_removida', 'toda chave declarada em suite/chaves-removidas.tsv saiu INTEIRA: não está em config/site.json, não está — nem é exigida — em config/site.schema.json, e nenhum token dela sobrou em código ou em documento fora dos arquivos onde a REMOÇÃO é narrada. Remover a chave da configuração é a parte fácil: o schema que continua exigindo-a reprova todo config correto, o consumidor órfão lê vazio em silêncio e o documento órfão ensina a preencher o que não existe mais — e o detector de chave sem consumidor não enxerga nada disso, porque ele cruza no sentido declarada → lida.', 'analise-estatica', 'build' );
emitir( f3b_ck_decisoes_fonte_unica( $raiz ), 'decisoes.fonte_unica', 'toda decisão de config/decisoes.tsv tem UMA fonte e o motivo escrito: a chave não voltou para config/site.json nem para o schema, quem a nomeia no código passa por F3Base_Imp_Decisoes, nenhum chamador repete o valor como PADRÃO — que era o estado real desta árvore, com 42 leituras carregando o valor declarado como default —, e valor de texto distintivo não vira constante no implantador. Literal em COMPARAÇÃO não conta: é o código reconhecendo o vocabulário em que a resposta vem, e proibi-lo tornaria impossível ramificar sobre a própria decisão. O site-core é outro runtime, recebe por option e tem sanitizador próprio. Sobre o motivo, o detector prova o que sabe provar e diz qual é o limite: ele cobra que o motivo EXISTA, que tenha corpo e que não seja palavra por palavra o de outra decisão — motivo copiado descreve o bloco e não o valor, e nenhuma das duas linhas fica explicada. Julgar se a prosa diz o que aconteceria com outro valor é conferência de quem lê, e afirmar que a máquina julga isso seria afirmar mais do que se mede. As três regras que o schema cobrava de plugins.instalaveis — slug, papel e origem presentes; sha256 com 64 hexadecimais minúsculos; sha256 só no ramo de origem url — passaram a ser medidas aqui, onde o valor mora agora.', 'analise-estatica', 'build' );
emitir( f3b_ck_tela_fala_portugues_comum( $raiz ), 'tela.fala_portugues_comum', 'a tela fala português comum, e o vocabulário interno fica no log. Quem abre a página do implantador quer três respostas: o site está no ar, o que falhou e o que falta ele fazer. Palavra que só faz sentido para quem escreveu o pacote — gate, veredito, pendência de fase, eixo de convergência, condição de aplicabilidade, e as próprias siglas de estado — não responde a nenhuma das três, e na tela só serve para o leitor achar que o problema é dele. Mede as frases destinadas à TELA (as passadas em tela e em operador, inclusive dentro de ternário e de sprintf): nenhuma carrega essas palavras e nenhuma é um parágrafo. A mensagem completa da linha NÃO é medida — ela é o log, e restringir o vocabulário do log empobreceria a única fonte que explica por quê.', 'analise-estatica', 'build' );
emitir( f3b_ck_gate_de_fase_sem_ramo_de_falha( $raiz ), 'estatica.gate_de_fase_sem_ramo_de_falha', 'nenhuma emissão do runtime declara gate=fase tendo ramo capaz de fechar FALHA — medido nas DECLARAÇÕES de includes/, e não numa linha que a suíte monta. O gate de fase é a lista sobre a qual o relatório escreve, nome por nome, que a evidência é de algo que ESTE HOST NÃO PRODUZ e que ela NÃO é somada ao gate da autodesativação; e FALHA entra na contagem crua que derruba o estado da aplicação, que é a PRIMEIRA das três condições daquele gate. As duas coisas não podem ser verdade ao mesmo tempo, e na 1.7.2 elas saíram impressas na mesma tela sobre release.versao_site_core. A regra é decidível e não adivinha: avaliar() e condicional() são acusadas sempre, porque emitem nos dois ramos e o ramo adverso é FALHA; emitir() e emitir_unidade() têm o estado resolvido em um salto — constante literal decide sozinha, variável é resolvida pela produtora que a atribui, e QUALQUER outra forma é acusada dizendo que não foi possível provar. O erro seguro é cobrar: emissão de fase cujo estado ninguém consegue provar é justamente aquela em que a FALHA passa despercebida. Escopo vazio não aprova. O piso em disco é a mutação de uma linha só — plugins.site_core_versao voltando de relato para fase — e o ramo positivo tem de calar sobre as três formas legítimas, senão o detector só sabe reprovar.', 'analise-estatica', 'build' );
emitir( f3b_ck_option_sem_leitor( $raiz ), 'estatica.option_gravada_sem_leitor', 'toda option do namespace declarado em site.prefixo_tecnico que o pacote GRAVA é lida de volta por alguma linha: gravar não é configurar, e option que ninguém relê é escrita sem consequência — foi por aí que apos_n_ajustes escapou do detector de chave sem consumidor.', 'analise-estatica', 'build' );
emitir( f3b_ck_plano_dependencias( $raiz ), 'estatica.plano_dependencias', 'todo grupo alvo de dependência do plano existe, nenhum depende de si mesmo e não há ciclo — a suspensão por fecho transitivo só pode ser calculada sobre um grafo que fecha.', 'analise-estatica', 'build' );
emitir( f3b_ck_placeholder( $raiz ), 'estatica.detector_placeholder', 'nenhum placeholder no conteúdo publicado.', 'analise-estatica', 'build' );
emitir( f3b_ck_simbolos_resolvem( $raiz ), 'estatica.simbolos_resolvem', 'todo método e constante F3Base_*:: chamados existem.', 'analise-estatica', 'build' );
emitir( f3b_ck_estados_fechados( $raiz ), 'estatica.estados_fechados', 'todo estado emitido pelo pacote pertence à lista fechada.', 'analise-estatica', 'build' );
emitir( f3b_ck_gate_fonte_unica( $raiz ), 'estatica.gate_fonte_unica', 'nenhum estado de gate da autodesativação é derivado em mais de um lugar: cada um é medido por uma função só, quem precisa dele depois lê o registro da execução recebendo o nome por parâmetro, o registro da rodada limpa tem um produtor só — o comando único — e nenhum veredito declarado como da SUÍTE é derivado também no implantador, nem sumiu da suíte.', 'analise-estatica', 'build' );
emitir( f3b_ck_option_fonte_unica( $raiz ), 'estatica.option_fonte_unica', 'nenhuma option gerenciada tem mais de um ponto do código produzindo o valor desejado sem passar pela função de união declarada: os nomes das options saem da âncora options_gerenciadas() e as uniões da âncora uniao_declarada(), as duas do próprio pacote; a varredura enxerga tanto a gravação direta quanto o nome dentro do mapa que um laço grava depois, com o nome escrito por literal ou por constante de classe; e união declarada para option inexistente ou apontando para função que ninguém definiu é achado, porque declaração que absolve sem medir é pior que nenhuma.', 'analise-estatica', 'build' );
emitir( f3b_ck_pagina_status_fonte_unica( $raiz ), 'estatica.pagina_status_fonte_unica', 'o status efetivo de página sai de um produtor só: a âncora produtor_de_status_de_pagina() do próprio pacote nomeia a função e o caminho da intenção, o caminho declarado tem um leitor só e ele passa pelo produtor, e todo post_status DESEJADO de página — o do wp_insert_post inclusive — chama o produtor em vez de escrever o literal; produtor declarado e ausente é achado, porque declaração que absolve sem medir é pior que nenhuma.', 'analise-estatica', 'build' );
emitir( f3b_ck_llms_so_pagina_publicada( $raiz ), 'estatica.llms_so_pagina_publicada', 'toda seleção de llms.txt sai de página PUBLICADA, no produtor que a âncora declara — o item de f3base_llms (o ID que ia para o plugin de SEO saiu na 2.1.0): um gate único mede o status no artefato, cada produtor passa por ele, e quem monta o valor da option chama o produtor dela em vez de resolver a página por fora com localizar_gerenciado() ou get_permalink().', 'analise-estatica', 'build' );
emitir( f3b_ck_llms_proprio_sem_concorrente( $raiz ), 'estatica.llms_proprio_sem_concorrente', 'o /llms.txt é do SITE-CORE e o plugin de SEO não concorre por ele: aplicar_geral() grava enable_llms_txt como o literal false, nenhum arquivo de includes/ grava wpseo_llmstxt, e aplicar_llms_proprio() relê a chave do banco, remove o repovoamento agendado do plugin e apaga o arquivo físico que ele tiver deixado na raiz. Medido na implantação de 2026-09-07 com a 2.0.0: o plugin de SEO ligado gravava um arquivo físico que vencia a rota do site-core, a seleção curada ia para chaves que a versão 28.4 não lê, e o arquivo publicado era a seleção automática dele — com a linha fechando OK sobre a própria escrita.', 'analise-estatica', 'build' );
emitir( f3b_ck_conteudo_declara_secoes( $raiz ), 'estatica.conteudo_declara_secoes', 'o conteúdo ENTREGUE declara as seções que o site mede. f3base_secao_vista é um dos eventos declarados, é dirigido por rolagem como o de profundidade — que funciona — e ficou com ZERO linha no site do usuário: o coletor só observa elemento com a classe f3base-secao-<nome>, a classe existia apenas nos patterns do tema, que são modelos para inserir à mão no editor, e nenhuma página entregue a carregava. O observador era instalado e não recebia alvo nenhum. Evento declarado que nunca dispara em nenhum site entregue é um evento que não existe: ocupa linha na declaração, coluna no relatório e espaço na tela, e responde sempre nada. A regra mede o conteúdo publicado, exige a marca nos DOIS lugares que o WordPress precisa — o atributo do bloco e a classe da div, porque escrita em um só o editor reescreve o outro e a marca some sem aviso — e exige nomes que distingam. O piso em disco reproduz os dois defeitos: página sem marca nenhuma e marca em um lugar só.', 'analise-estatica', 'build' );
emitir( f3b_ck_release_declara_a_anterior( $raiz ), 'release.declara_a_anterior', 'toda release declara DE ONDE sabe subir, e quem cobra isso é o build. A 1.3.2 foi cortada com a matriz de origens parada na 1.1.5: no site do usuário, rodando 1.3.1, o contrato de caminho fechou FALHA sobre uma versão que ninguém tinha listado, e 39 unidades foram suspensas — o site não recebeu tema, plugin, página nem post, sem que nada nele estivesse quebrado. A regra é a ADJACÊNCIA: a maior origem declarada tem de estar a exatamente um passo de patch, minor ou major da identidade desta release. Adjacência é a única definição de "a anterior" que não pede um segundo arquivo de histórico para manter, e ela pega o vão inteiro — de 1.1.5 nenhum passo leva a 1.3.2, e a lacuna teria sido acusada já na 1.3.0. Os ramos adversos: matriz sem nenhuma origem do implantador, matriz contendo a própria release ou uma posterior, e o vão nomeado com os passos aceitos. O piso é o caso real em disco.', 'analise-estatica', 'build' );
emitir( f3b_ck_identidade_do_implantador( $raiz ), 'estatica.identidade_do_implantador', 'a identidade da release é a MESMA nos três lugares que a carregam: release.identidade e release.implantador em config/site.json, o cabeçalho Version: de implantador-base.php — que é o número que o WordPress mostra e o que f3base_imp_versao() prefere — e F3BASE_IMP_VERSAO_DECLARADA, o fallback de bootstrap que responde antes de get_plugin_data() existir. O MANIFESTO afirmava essa igualdade em linha própria e nada a media: na 1.0.17 a configuração foi para 1.0.17 com o cabeçalho em 1.0.16 e a constante em 1.0.15.', 'analise-estatica', 'build' );
emitir( f3b_ck_carimbo_de_release_nos_documentos( $raiz ), 'estatica.carimbo_de_release_nos_documentos', 'os documentos entregáveis carregam regiões GERADAS: README, MANIFESTO e MEMORIA-DECISOES, que viajam no bundle. Cada um traz os dois marcadores de cada região declarada, o carimbo traz a identidade de release.identidade, e o conteúdo de cada região é igual ao que a leitura de disco produz agora — número digitado à mão em documento entregável envelhece calado, e foi o que aconteceu da 1.0.6 à 1.0.13. O documento do plugin (INSTRUCOES-DO-PLUGIN.md) não está mais nesta árvore desde a 2.0.0: ele viaja dentro do zip publicado e é o repositório do plugin quem o gera e confere.', 'analise-estatica', 'build' );
emitir( f3b_ck_politica_privacidade_fonte_unica( $raiz ), 'estatica.politica_privacidade_fonte_unica', 'a identidade da política de privacidade tem um produtor só, ela mora no papel declarado na entrada da própria página, e o produtor não lê caminho fora dessa raiz: nenhuma outra função carrega o literal do papel, ninguém lê o caminho aposentado da seleção de llms.txt, e é essa proibição — não o nome da chave — que impede uma seção alheia de silenciar a checagem exigida pelo art. 9º da LGPD.', 'analise-estatica', 'build' );
emitir( f3b_ck_contagem_com_nomes( $raiz ), 'estatica.contagem_com_nomes', 'nenhuma emissão de contagem por estado existe sem a lista de nomes correspondente na mesma saída — nem em PHP nem no cliente, nem dentro de função nem em escopo de arquivo.', 'analise-estatica', 'build' );
emitir( f3b_ck_unidade_reflete_internas( $raiz ), 'estatica.unidade_reflete_internas', 'nenhuma unidade fecha em estado menos severo do que a checagem de gate de APLICAÇÃO mais severa que ela emitiu: quem emite a linha de uma unidade passa o estado pelo helper único de severidade E olha o gate, a ordem FALHA > BLOCKED > WARN é declarada em um lugar só, o gate que decide sai da âncora do pacote, e nenhum registro de relatório traz unidade menos severa que uma checagem sua de aplicação.', 'analise-estatica', 'build' );
emitir( f3b_ck_warn_tem_ramo_adverso( $raiz ), 'estatica.warn_tem_ramo_adverso', 'nenhum WARN do runtime é retorno incondicional ou único: todo WARN de includes/ e fontes/ mora dentro de um ramo — if, elseif, else, foreach, for, while, switch, match ou ternário — ou depois de uma cláusula de guarda que pode impedi-lo, e é a condição desse ramo que mede o achado adverso. Medição sem achado adverso fecha OK com o detalhe no texto, que é a lição que a 1.0.14 pagou com quatro unidades amarelas numa execução em que nada estava errado.', 'analise-estatica', 'build' );
emitir( f3b_ck_troca_invalida_cache( $raiz ), 'estatica.troca_invalida_cache', 'a invalidação de cache pertence a quem TROCOU o diretório: a âncora do pacote nomeia trocador, invalidador, leitura de volta e as duas limpezas do núcleo; o trocador chama o invalidador; o invalidador chama as duas limpezas — as mesmas que Theme_Upgrader::install() e Plugin_Upgrader::install() fazem —; e toda função que chama o trocador relê o artefato pela leitura de volta declarada, em vez de perguntar à API por fora dela e voltar a dizer "não apareceu no disco" sobre diretório que está no disco.', 'analise-estatica', 'build' );
emitir( f3b_ck_artefato_do_pacote_e_lido( $raiz ), 'estatica.artefato_do_pacote_e_lido', 'nenhum artefato instalável viaja no pacote sem um caminho de instalação que o leia: todo .zip do pacote está sob um dos prefixos que a constante do próprio pacote declara, e quem INSTALA e quem PROVA o entregável passam pelo MESMO resolvedor, sem montar caminho de artefato por conta própria — a segunda lista é o que faz o entregável provar um artefato enquanto a instalação usa outro.', 'analise-estatica', 'build' );
emitir( f3b_ck_afirmacoes( $raiz ), 'doc.afirmacao_conferida', 'toda AFIRMAÇÃO DE COMPORTAMENTO declarada em suite/afirmacoes.tsv está no documento que a faz E bate com o fato medido no pacote. É o detector que faltava: os outros conferem identidade de release e números gerados, e nenhum conferia uma frase contra o comportamento — foi por essa fresta que passaram cinco dos vinte e dois achados da 1.0.17, três deles refutados pela configuração do mesmo zip.', 'analise-estatica', 'build' );
emitir( f3b_ck_piso_em_sonda_declarado( $suite ), 'estatica.piso_em_sonda_declarado', 'toda checagem cujo piso é declarado em suite/pisos-em-sonda.tsv se sustenta: a sonda declarada existe, menciona a checagem e traz os DOIS ramos — teto e piso. É o piso da regra do piso: sem ele, uma linha de tabela declararia coberta qualquer checagem, que é a doença que armadilhas.mapeadas existe para impedir um nível acima.', 'analise-estatica', 'build' );
emitir( f3b_ck_segredo_fora_da_configuracao( $raiz ), 'estatica.segredo_fora_da_configuracao', 'nenhuma option declarada como SEGREDO DO SITE na âncora do pacote aparece em config/site.json nem em config/site.schema.json, e nenhuma delas é gravada por lote do implantador. O arquivo único viaja dentro do zip — a suíte o lê, o empacotador o embute, e o bundle chega a quem faz o upload —, então segredo declarado ali é segredo copiado para todo lugar por onde o pacote passou, e a cópia sobrevive à rotação da credencial porque ninguém volta ao zip para apagá-la. A decisão de "declarar por ausência" só vale enquanto alguém mede a ausência, e é isto.', 'analise-estatica', 'build' );
emitir( f3b_ck_residencia_de_chave_derivada( $raiz ), 'estatica.residencia_de_chave_derivada', 'nenhuma mensagem de runtime nomeia um arquivo de configuração em que a chave citada não mora. No implantador o nome do arquivo é DERIVADO da chave por F3Base_Imp_Residencia, que cruza o que cada leitor declara, e nenhuma string traduzível de includes/ pode trazê-lo digitado — o defeito medido chegava com a chave por %s, sem aparecer na frase, e uma regra que só comparasse chave citada com arquivo citado seria cega para ele. Fora do implantador, onde o site-core fala dos arquivos de fora e não tem o derivador, vale a regra verificável: string que nomeia um arquivo E um caminho pontilhado que é chave declarada precisa nomear o arquivo em que essa chave está. Os nomes dos arquivos saem da constante ARQUIVO de cada leitor, nunca digitados no detector. O que ele não mede fica declarado: caminho pontilhado que não é chave de configuração é ignorado, porque nome de checagem também tem ponto, e a segunda cláusula não lê negação. O piso planta a política em draft com a mensagem mandando preencher contato.controlador.razao_social em config/site.json, onde essa chave não existe.', 'analise-estatica', 'build' );
emitir( f3b_ck_fronteira_do_validador( $raiz ), 'mcp.fronteira_do_validador', 'tudo o que as habilidades de configuração do plugin PUBLICADO esperam encontrar dentro da pasta do implantador existe nesta árvore — a classe que elas carregam, o método público e estático que elas chamam para validar antes de gravar, e os quatro arquivos de configuração e schema que elas leem e gravam —, lido de dentro da reserva e conferido contra includes/ e config/. A validação em si tem teto e piso em projeto.schema_valida e config.schema_valida, pelo mesmo método que o plugin chama.', 'analise-estatica', 'build' );
emitir( f3b_ck_hidden_governa_visibilidade( $raiz ), 'estatica.hidden_governa_visibilidade', 'todo elemento cuja visibilidade é comandada por `hidden` — no JavaScript, por `.hidden =` ou por `setAttribute(\'hidden\')`, e no markup, pelo atributo literal — foi cruzado com toda regra de AUTOR que declara `display` sobre a classe dele, nas folhas do tema, do site-core e do implantador. `[hidden] { display: none }` é regra da folha do USER AGENT, e qualquer declaração de autor a vence: a origem decide antes de a especificidade ser consultada. O par declarado é `.classe[hidden] { display: none }` (0,2,0 contra 0,1,0) ou o global com `!important`; um `[hidden]` global SEM `!important` empata e perde na ordem, e por isso não é aceito. Foi este o defeito medido na 1.1.2, e ele estava em dois lugares: o painel de consentimento que cobria a página e não fechava, e a caixa do resumo final do implantador, aberta e vazia do primeiro lote ao último.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_recusa_de_escrita_do_agente( $raiz ), 'estatica.sem_recusa_de_escrita_do_agente', 'nenhum arquivo do RUNTIME do pacote registra literal de filtro de options protegidas do servidor MCP: depois da instalação quem modifica o site é o agente, pelo canal, e um pacote que peça ao canal para recusar a escrita das próprias options é o pacote impedindo exatamente o que ele existe para permitir. A 1.0.19 registrava as vinte options do catálogo em quatro filtros do servidor; o módulo saiu inteiro na 1.1.0 e este detector existe para que ele não volte por outro nome.', 'analise-estatica', 'build' );

/*
 * O EMISSOR ÚNICO NÃO PASSA POR `emitir()`, e pela mesma razão que
 * `conteudo.demonstrativo` não passa: ele tem TRÊS estados. FALHA é o segundo
 * emissor com slot preenchido — contagem em dobro. WARN é o emissor de fora com
 * TODOS os slots vazios, que não é dobro e sim medição que este pacote não
 * emitiu e não governa: sob a premissa do agente a decisão é do projeto, e o
 * pacote nomeia em vez de decidir. A regra do WARN continua sendo a da 1.0.15 —
 * ele só sai com achado adverso nomeado.
 */
$discriminante = f3b_ck_emissor_unico_discrimina( $raiz, $suite );

if ( 0 === (int) $discriminante['medidas'] ) {
	estado( 'BLOCKED', 'tracking.emissor_unico_discrimina', 'escopo vazio: nenhum HTML e nenhum caso declarado foi medido, e o que não foi medido não pode ser aprovado.', 'pendencia-externa', 'build' );
} else {
	estado(
		$discriminante['estado'],
		'tracking.emissor_unico_discrimina',
		$discriminante['motivo'] . sprintf( ' (%d unidade(s) medida(s))', (int) $discriminante['medidas'] ),
		'analise-estatica',
		'build'
	);
}

emitir( f3b_ck_resposta_de_lote_nomeada( $raiz ), 'estatica.resposta_de_lote_nomeada', 'toda resposta de lote que a tela renderiza traz as chaves que a âncora declara — rótulo, para a linha não sair anônima e a contagem por estado não ficar sem a lista de nomes; estado da aplicação, para o rodapé não fechar em branco —, e o emissor só recebe carga do produtor declarado ou do produtor de reserva, que é o único lugar onde uma resposta "não rodou" se monta.', 'analise-estatica', 'build' );
emitir( f3b_ck_serie_de_backup( $raiz, $suite ), 'plugins.serie_de_backup_normalizada', 'a chave da série de cópias preservadas colapsa a marca de backup embutida, exercitando a MESMA função do runtime: a cópia simples, o nome medido no site real — backup de um diretório que já era backup —, o aninhamento duplo e o plugin de terceiro caem cada um na série do slug REAL, com o carimbo EXTERNO; quatro cópias fecham duas séries, com três no artefato do pacote, que é a contagem que o teto de plugins.backups_preservados compara; e nome que não é cópia preservada continua fora.', 'teste-funcional', 'build' );

/*
 * O resíduo de prefixo emite o ESTADO QUE MEDIU: N/A enquanto o pacote for o
 * próprio template (a condição de aplicabilidade sai declarada, nunca some),
 * OK quando nenhuma grafia sobrou fora das exceções, FALHA nomeando arquivo e
 * ocorrências quando sobrou. Renomeação que não é conferida é renomeação que
 * ninguém sabe se aconteceu inteira.
 */
$residuo = f3b_ck_sem_residuo_de_prefixo( $raiz );

estado(
	$residuo['estado'],
	'estatica.sem_residuo_de_prefixo',
	$residuo['motivo'],
	'analise-estatica',
	'build'
);

/* ---------- configuração ---------- */

emitir( f3b_ck_slug_declarado( $raiz ), 'config.slug_declarado', 'toda entrada de paginas e posts declara slug não vazio, e nenhum slug se repete entre elas.', 'analise-estatica', 'build' );

/* ---------- tema ---------- */

emitir( f3b_ck_zero_com_unidade( $raiz, $suite ), 'tema.zero_com_unidade', 'nenhum zero sem unidade onde o valor vira custom property; styles.blocks.* fora do escopo, por desenho.', 'analise-estatica', 'build' );
emitir( f3b_ck_preset_ocioso( $raiz, $suite ), 'tema.preset_ocioso', 'todo preset declarado no theme.json tem consumidor no tema.', 'analise-estatica', 'build' );
emitir( f3b_ck_preset_inexistente( $raiz, $suite ), 'tema.preset_inexistente', 'nenhuma referência a preset que não existe.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_cor_literal( $raiz ), 'tema.sem_cor_literal', 'nenhuma cor literal em .css/.html/.php/.svg do tema, SVG inline incluído; fontes/tema/CONTRASTE.md fica fora por ser documentação, não artefato servido.', 'analise-estatica', 'build' );
emitir( f3b_ck_wp_html_declarado( $raiz, $suite ), 'tema.wp_html_declarado', 'todo wp:html do tema consta de tema.wp_html_excecoes com motivo, e nenhum dentro de navegação.', 'analise-estatica', 'build' );
emitir( f3b_ck_main_layout_default( $raiz, $suite ), 'tema.main_layout_default', 'todo main declara layout default — nunca constrained.', 'analise-estatica', 'build' );
emitir( f3b_ck_landing_sem_navegacao( $raiz ), 'tema.landing_sem_navegacao', 'o template de landing existe, está declarado em theme.json como declarável por página, NÃO traz navegação — nem direta nem por template-part, resolvida recursivamente — e traz o controle de consentimento, que é o instrumento permanente do titular e precisa existir em toda página publicada, inclusive na que não tem menu.', 'analise-estatica', 'build' );
emitir( f3b_ck_versao_assets( $raiz ), 'tema.versao_assets', 'nenhuma constante PHP com o número literal da versão; a versão deriva de wp_get_theme().', 'analise-estatica', 'build' );

/* ---------- conteúdo ---------- */

emitir( f3b_ck_sem_estilo_avulso( $raiz, $suite ), 'conteudo.sem_estilo_avulso', 'o conteúdo publicado só referencia preset.', 'analise-estatica', 'build' );
emitir( f3b_ck_headings( $raiz, $suite ), 'conteudo.headings', 'um H1 por template, sem salto de nível, conteúdo começando em H2.', 'analise-estatica', 'build' );

/*
 * As duas checagens do conteúdo demonstrativo emitem o ESTADO QUE MEDIRAM — OK
 * ou WARN —, e é por isso que elas não passam por `emitir()`, que só conhece
 * aprovado e reprovado. A regra do WARN é a da 1.0.15: ele só sai com achado
 * adverso nomeado, e aqui o achado é concreto — o site do template indo ao ar
 * como site de cliente, ou a declaração e o disco discordando arquivo a arquivo.
 */
foreach ( array( 'conteudo.demonstrativo' => f3b_ck_conteudo_demonstrativo( $raiz ), 'conteudo.marca_demonstrativa' => f3b_ck_marca_demonstrativa( $raiz ) ) as $nome_demonstrativo => $veredito_demonstrativo ) {
	if ( 0 === (int) $veredito_demonstrativo['medidas'] ) {
		estado( 'BLOCKED', $nome_demonstrativo, 'escopo vazio: nenhum arquivo de content/ foi medido, e o que não foi medido não pode ser aprovado.', 'pendencia-externa', 'build' );
		continue;
	}

	estado(
		$veredito_demonstrativo['estado'],
		$nome_demonstrativo,
		$veredito_demonstrativo['motivo'] . sprintf( ' (%d unidade(s) medida(s))', (int) $veredito_demonstrativo['medidas'] ),
		'analise-estatica',
		'build'
	);
}

/* ---------- acessibilidade ---------- */

$contraste = f3b_ck_contraste( $raiz, $suite );

estado_por_origem(
	(bool) $contraste['ok'],
	'site',
	'a11y.contraste',
	sprintf( '%d par(es) texto/fundo em uso recalculado(s) da paleta do theme.json; todos acima do piso AA (4,5:1 texto, 3:1 não-texto).', (int) $contraste['total'] ),
	count( $contraste['achados'] ) . ' par(es) abaixo do piso: ' . f3b_amostra( $contraste['achados'] ),
	'medida',
	'build'
);

/* ---------- copy ---------- */

emitir( f3b_ck_copy_contrato( $raiz ), 'copy.contrato', 'as frases obrigatórias estão nas páginas declaradas, na grafia declarada, e as proibidas não aparecem em lugar nenhum do pacote.', 'analise-estatica', 'build' );

/* ---------- funcionais ---------- */

$rotulos_funcionais = array(
	'config.schema_valida'                  => 'o site.json valida e cada mutante declarado reprova — teto e piso do validador, com um mutante por chave nova: as da 1.0.17 (o enum de permalinks, o enum da decisão sobre o conteúdo de exemplo do WordPress e a ausência dessa chave obrigatória) e as da 1.0.18 (o alfabeto do nome do cabeçalho de origem confiável e o mínimo dos saltos de proxy, que não pode ser zero).',
	'conteudo.merge_tres_vias'              => 'a tabela de decisão do merge de três vias do CONTEÚDO inteira, linha por linha, com o ramo que a 1.1.0 inverteu: base ≠ observado ≠ desejado com política gerenciado PRESERVA — até a 1.0.19 gravava, e era o conteúdo do template apagando o do cliente a cada reexecução. O piso é a regra inteira e não uma linha: existindo base, nenhuma política pode produzir gravação sobre objeto que quem opera o site já editou.',
	'options.merge_tres_vias'               => 'a regra de três vias das OPTIONS, os cinco ramos e as frases de cada um: observado igual ao desejado não grava; base igual ao observado é atualização segura; base igual ao desejado com observado diferente PRESERVA a edição feita pelo canal; os três diferentes gravam NOMEANDO a sobreposição com os dois valores; e sem base a primeira execução aplica o desejado DIZENDO que a base nasceu agora. A impressão que decide é a mesma da leitura de volta — tolerante ao round-trip da camada de options e nada além dele —, e a linha do relatório nomeia option e valores em vez de contá-los.',
	'cadencia.recorrencia_declarada'        => 'a decisão da recorrência da cadência, com o site-core na tabela do agendador e sem ele: sem ele a queda para daily acontece e sai NOMEADA com a recorrência declarada que faltava; com ele a recorrência agendada é a DECLARADA, e quinzenal não cai em weekly (que dobraria a frequência combinada). A queda de uma execução anterior é REPARADA quando a declarada passa a existir, e o alcance do reparo é estreito: recorrência que não é a nossa queda não é desfeita, e evento já correto não é reagendado.',
	'conteudo.nao_promocao_status'          => 'a ordem de publicidade dos status sustenta a regra de não promoção.',
	'relatorio.waiver_casa'                 => 'casamento de waiver por igualdade e por prefixo, e os cinco curingas que não podem casar.',
	'relatorio.sanitiza_dump'               => 'a sanitização alcança o dado sensível por dentro do serializado e preserva o resto.',
	'gravador.leitura_de_volta_equivalente' => 'a equivalência reconhece o round-trip da camada de options e continua reprovando valor diferente.',
	'config.residencia_derivada'            => 'o arquivo em que uma chave de configuração mora é DERIVADO da chave, e não digitado na mensagem: o produtor cruza o que cada leitor declara e acerta chave do operador, chave de conteúdo, destino de regime, mecanismo da cadência e índice numérico na forma normalizada. O piso é a metade que importa — chave que não mora em lugar nenhum NÃO recebe palpite, e a frase dela não nomeia arquivo nenhum, porque um palpite aqui seria o defeito de volta com derivação no nome. E a frase do controlador é medida nos dois sentidos: precisa nomear config/projeto.json e NÃO pode nomear config/site.json, que é o arquivo errado do log medido — a política ficou em draft e a mensagem mandava preencher contato.controlador.razao_social em config/site.json, onde essa chave não existe.',
	'formulario.veredito_destino'           => 'o regime de formulário é DERIVADO do valor do destino, e não de um interruptor: destino vazio fecha N/A com a condição declarada — nomeando a chave a preencher e dizendo que o CTA não é publicado, nem no comportamento degradado —, destino preenchido e no formato do regime fecha OK, destino PREENCHIDO e fora do formato continua FALHA, entrada sem destino declarado é FALHA da própria entrada, e nenhuma entrada declarada traz o interruptor de volta.',
	'relatorio.nomeia_o_que_nao_fecha_ok'   => 'checagem em FALHA ou WARN dentro de unidade que fecha OK sai NOMEADA no recorte da unidade, na lista por estado e no resumo; OK continua resumido e a contagem não é substituída pela lista.',
	'conteudo.politica_de_privacidade'     => 'a IDENTIDADE da política de privacidade e a INTERPOLAÇÃO do controlador no texto — o que continua sendo mecanismo do pacote depois que a checagem do controlador e a guarda de rascunho saíram, na 2.1.0, por decisão do dono (o que a política afirma é responsabilidade de quem responde por ela). Qual página é a política sai do papel declarado na entrada, e desligar o llms.txt não a silencia; o arquivo real da política carrega os marcadores, cada valor do controlador chega ao conteúdo, os blocos condicionais do encarregado fazem o que declaram, e o status de toda página é o DECLARADO — nenhuma guarda de conteúdo rebaixa página: com o controlador vazio a política publica, e o marcador vazio fica à vista de quem ler.',
	'entrega.rodada_limpa_confere'          => 'o leitor do registro da rodada limpa, nos dois ramos: hash casado fecha OK com evidência importada/build, hash divergente e registro ausente são acusados nomeando o esperado e o encontrado.',
	'entrega.gates_separados'               => 'N/A DE FASE NÃO É PENDÊNCIA, e os TRÊS consumidores de gates_de_fase() decidem pela MESMA função: linha de gate de fase em OK respondeu e em N/A não se aplica aqui, e nenhuma das duas entra na lista nem é nomeada; BLOCKED, WARN, WAIVED e estado ausente continuam entrando. O piso ao contrário é o que impede a correção de virar cegueira: com uma linha em N/A ao lado de uma em BLOCKED, a nota NÃO pode dizer "nenhuma pendência de fase em aberto" e a BLOCKED tem de sair nomeada com o estado — foi a contradição medida na 1.0.17, e a 1.1.6 podia reabri-la pelo outro lado. E o gate de aplicação lista os nove entregáveis e NÃO inclui a rodada limpa; o gate de fase a inclui, aparece nomeado no motivo e não proíbe a autodesativação; e o caminho de falha continua intacto — FALHA real, cada um dos nove entregáveis em BLOCKED (um a um) e qualquer dos dois vereditos de canal em aberto mantêm o implantador ativo, com o motivo nomeando o que segurou; e a linha de uma UNIDADE em BLOCKED não decide o gate, que é o que mantém a autodesativação possível depois que a unidade passou a refletir as internas.',
	'preflight.artefato_do_pacote_e_baseline' => 'os artefatos do pacote — site-core, tema e implantador — são baseline por definição, resolvidos dos slugs DECLARADOS na configuração: com eles ativos e nada mais a baseline fica em silêncio, plugin de terceiro ativo e não declarado é acusado nomeando, e o mesmo plugin declarado em plugins.operacionais sai da acusação com finalidade e responsável.',
	'tema.override_por_conteudo'            => 'override do editor de site é decidido por CONTEÚDO: stub vazio e post idêntico ao arquivo do tema ficam em silêncio, com o motivo registrado, settings ou styles preenchidos são acusados, e o tamanho do post não decide nada.',
	'mcp.canal_unico_mede_plugins_ativos'   => 'a checagem mede PLUGINS DE CANAL ATIVOS, que é a pergunta com resposta: um complemento ativo fecha OK nomeando-o e SEM a frase da consequência, dois (o declarado mais uma cópia com outro slug e o mesmo Plugin Name) fecham FALHA nomeando os dois diretórios e os dois arquivos principais, nenhum fecha BLOCKED, censo indisponível fecha BLOCKED com a frase da Abilities API, e cópia inativa ou oculta não conta.',
	'lotes.unidade_reflete_internas'        => 'o veredito da unidade é o mais severo entre o dela e as internas de gate de APLICAÇÃO, pelo caminho real de processar(): OK contendo FALHA, BLOCKED ou WARN de aplicação é promovido nomeando a checagem; OK contendo N/A continua OK; BLOCKED ou FALHA de FASE não promove e sai nomeado como pendência no texto da unidade; gate ausente ou vazio promove como aplicação, para que a omissão não absolva; e a ordem FALHA > BLOCKED > WARN, com N/A, OK e WAIVED empatados em zero, sai de um lugar só.',
	'lotes.permalinks_decisao'              => 'a decisão de permalinks MEDE antes de decidir, em todos os ramos: aplicar-e-cobrir — o padrão do template — APLICA e COBRE, gravando 301 do caminho antigo de todo publicado que muda de endereço, gerenciado ou não, e a mensagem NOMEIA cada URL coberta em vez de contá-las; o publicado não gerenciado cujo endereço é de query não ganha par, e a mensagem diz que seria laço; aplicar-se-seguro com todo publicado gerenciado APLICA sem cobrir terceiro, e com um publicado não gerenciado de URL de caminho fecha BLOCKED nomeando o objeto (id, tipo, slug e caminho) e apontando aplicar-e-cobrir como saída; manter-existente fecha BLOCKED mesmo com tudo gerenciado; aplicar-declarada aplica registrando o risco assumido e NÃO coberto; estrutura já igual à declarada fecha OK sem gravação, e a igualdade vence a decisão nos quatro valores; valor não reconhecido não vira aplicação nem recusa silenciosa; nenhum publicado não gerenciado some da classificação; a chave de cobertura é ela mesma piso — só aplicar-e-cobrir a liga —, o par do publicado não gerenciado é chaveado pelo ID e entra na união pelo produtor único com a contagem por origem batendo, e a regra do par grava 301 do caminho antigo para o novo e descarta o caminho que não mudou, que seria laço.',
	'conteudo.exemplo_do_wordpress'         => 'o conteúdo de exemplo do WordPress é decidido por DISCRIMINANTE e nunca por slug: só vai para a LIXEIRA — reversível, nunca exclusão definitiva — o objeto que AINDA É o que wp_install_defaults() criou, com título e conteúdo idênticos ao que o núcleo escreveria agora E post_modified_gmt sem avançar em relação a post_date_gmt; o piso NEGATIVO é o que importa e está plantado nos três lugares (título, conteúdo e os dois), e nenhum deles pode produzir remoção; objeto gerenciado por este pacote e objeto EM USO como página inicial, página de posts ou política de privacidade ficam mesmo intocados; o par tipo/slug só INDEXA a hipótese — tipo trocado, slug de fora e slug vazio não casam com entrada nenhuma —, e todo veredito carrega o discriminante que o relatório imprime.',
	'lotes.indexacao_consequencia'          => 'a checagem de indexação nomeia a CONSEQUÊNCIA junto com a causa: no ramo não indexável diz que o aviso "Problema grave de SEO" do wp-admin é esperado, que ele não é suprimido, e exatamente o caminho de saída da 1.0.12 — sumir a causa medida ou declarar ambiente.indexar = "forcar" —, sem mandar preencher a lista de domínios, que deixou de ser condição; no ramo indexável nenhum dos dois textos aparece.',
	'lotes.indexacao_veredito'              => 'o ônus da indexação está invertido e medido nos dois lados: produção limpa com HTTPS indexa sem configuração nenhuma; wp_get_environment_type() em staging, home_url() em HTTP puro, ambiente.tipo diferente de producao e host casando com sufixo declarado em ambiente.dominios_de_previa seguram a indexação em WARN, cada um nomeando a guarda, o valor observado e como forçar; wp_get_environment_type() fora dos três valores declarados (production, vazio, nome inventado pela hospedagem) NÃO segura, que é o piso do falso positivo; lista de prévia vazia não segura nada, e o casamento é por sufixo de domínio, nunca por trecho; forcar com guarda ativa indexa registrando o motivo por que a decisão existia e sem guarda alguma registra a decisão como inerte; nunca não indexa dizendo que é escolha; modo não reconhecido cai para medir; e a lista de domínios autorizados é cross-check — host fora dela indexa e sai o WARN nomeando o host observado e a lista declarada, lista vazia fecha N/A.',
	'lotes.redirects_uniao'                 => 'f3base_redirects tem fonte composta e ordem declarada, exercitada nos dois lados: configuração vazia NÃO apaga o par computado pela troca de permalinks (o defeito medido no banco depois da 1.0.11), as três fontes somam com a contagem por origem, a execução seguinte preserva o computado pela anterior, o par removido da configuração desaparece, par sem destino não entra, o registro carimba a etapa de origem e é esquecível, e colisão de origem entre um par declarado e um computado fecha FALHA nomeando os dois destinos, com o declarado prevalecendo no valor gravado — nunca sobrescrita silenciosa.',
	'conteudo.guarda_de_marca'              => 'a guarda de publicação cruza a DECLARAÇÃO com o ARQUIVO nos dois lados: chave desligada com a marca do template no topo do arquivo recusa a publicação nomeando o arquivo, a marca e as duas saídas; chave ligada com ou sem marca publica; arquivo já substituído publica; a marca é montada do prefixo declarado, muda com ele e não existe sem ele.',
	'plugins.emissor_concorrente'           => 'a classe emissor-concorrente sai da CONDIÇÃO MEDIDA, e não da lista de slugs: o plugin de console com useSnippet ligado fecha concorrente e a justificativa NOMEIA a condição observada; o mesmo plugin com o snippet e a medição automática de conversões desligados fecha leitor e volta à classe da declaração; option de condição ausente fecha nao-medido, porque o que não foi medido não absolve; plugin INATIVO não é acusado, que é o piso do falso positivo; e slug fora da lista declarada também não — a lista é dica para classificar cedo e quem decide é a contagem no HTML publicado, em tracking.emissor_unico. A classificação NÃO DESATIVA nada: classe_declarada guarda o eixo da declaração inteiro, e o piso exige que declarar o plugin em plugins.operacionais não cale a acusação nem que a acusação apague a declaração. E a chave de integração do adaptador de SEO sai nos DOIS ramos, com os quatro pares de (ativo, declarado) e as DUAS causas distintas do false — plugin ausente e plugin presente sem declaração —, porque gravar só o ramo verdadeiro deixava o true de ontem no banco quando o plugin saía da instalação.',
	'preflight.limites_veredito'            => 'o estado de preflight.limites SAI DA MEDIÇÃO, nos dois lados: limites folgados fecham OK NOMEANDO os valores observados, cada limite abaixo do piso declarado em ambiente.limites_minimos fecha WARN nomeando qual ficou abaixo e o que ele custa, um achado por limite, e max_execution_time = 0 é ausência de limite — nunca limite zero —, que é o piso do falso positivo.',
	'lotes.encerramento_por_estado'         => 'o parágrafo final do encerramento é condicional ao estado: o texto de falha — permanece ativo, retomada idempotente, rollback — não aparece em SUCESSO_APLICACAO, o texto de sucesso não aparece em FALHA_PARCIAL nem em FALHA, e o sucesso diz se o implantador se autodesativou e o que o operador usa a partir de agora (a tela do site-core e o canal MCP).',
	'instalacao.limpa_le_de_volta'          => 'a INSTALAÇÃO LIMPA é exercitada de verdade, tema e site-core, contra um WordPress cujo cache memoriza o negativo como o de verdade: o alvo começa INEXISTENTE, a consulta prévia acontece na mesma requisição e memoriza que não existe, e aí a troca de diretório roda. Com a invalidação DESLIGADA a API tem de continuar cega — é o que prova que a bancada reproduz o defeito da 1.0.15 em vez de aprovar por não ter cache — e a unidade fecha FALHA nomeando DEFEITO DE CACHE, nunca "não apareceu no disco"; com ela ligada a leitura de volta enxerga o artefato, a unidade fecha OK e o tema fica ativo. A ORDEM também é medida na fita de eventos da bancada: leitura de disco antes, invalidação no meio, leitura de disco de novo depois.',
	'instalacao.disco_ou_cache'             => 'o discriminante da leitura de volta, a tabela inteira e nos dois tipos: diretório ausente diz "não apareceu no disco" e não fala em cache; diretório presente sem o arquivo principal é um terceiro fato, com mensagem própria; diretório presente e completo com a API discordando é DEFEITO DE CACHE nomeado como tal e nunca a mensagem de disco; tudo presente com a API enxergando fecha ok; e a API MANDA no "está instalado" — artefato que ela enxerga fora do caminho medido fecha ok registrando o fato, que é o piso do falso positivo em site com mais de uma raiz de temas.',
	'instalacao.artefato_fonte_unica'       => 'a fonte única do artefato de cada papel devolve o slug DECLARADO, a lista de candidatos com o slot de zip do operador, um caminho que existe e que mora dentro do pacote; papel não declarado não inventa artefato nenhum.',
	'plugins.digesto_do_artefato'           => 'o digesto do artefato baixado tem os TRÊS ramos separados e provados: declarado e batendo instala nomeando o sha256; declarado e divergindo NÃO instala e nomeia os dois valores; ausente é medido e FIXADO na primeira observação, com a mensagem dizendo com todas as letras o que isso protege (a origem não muda embaixo das execuções seguintes) e o que NÃO protege (esta busca) — e a execução seguinte com digesto diferente do fixado não instala. O piso planta o defeito: a URL declarada aponta para uma ref mutável e, até a 1.0.17, nenhum hash era conferido.',
	'plugins.https_em_todo_salto'           => 'HTTPS é obrigatório em TODOS os saltos, e a guarda medida é a do pacote, alcançada por reflexão: cadeia inteira em https resolve e devolve o endereço final mesmo trocando de host, salto que CAI PARA HTTP não baixa nada e nomeia o esquema observado, URL declarada em http é recusada antes de qualquer busca, endereço sem host legível não abre conexão e cadeia sem fim é abandonada no teto. O piso planta os defeitos: download_url() seguia o redirecionamento sozinho, e conferir só a URL declarada deixaria a guarda valendo para um endereço que ninguém baixa.',
	'plugins.autoupdate_caminho_separado'   => 'flag ligada e CAMINHO DE ATUALIZAÇÃO saem separados, e o caminho é medido LOCALMENTE: o cabeçalho Update URI de cada plugin instalado, lido do disco, mais has_filter() sobre update_plugins_{host} — nenhuma consulta de rede. As classes esperadas são todas comportamento declarado, e a mensagem NOMEIA cada grupo: artefato deste pacote (release nossa por upload), origem url/bundle (release do fornecedor por upload, com o servidor do canal junto do complemento — o esquecido da ressalva do README), os que dependem do WordPress.org por slug (declarados wordpress.org, operacionais ou instalados por fora), o atualizador do fornecedor de pé e a consulta desligada pelo próprio artefato. O veredito é OK aí, WARN só na PROMESSA QUEBRADA medida — Update URI para host de terceiro SEM filtro registrado, com plugin e host nomeados — e BLOCKED só com escopo vazio. Os pisos: o cabeçalho decide ANTES da origem declarada, o mesmo cabeçalho COM filtro deixa de ser achado, Update URI do próprio wordpress.org e Update URI sem host legível não viram falso positivo, e escopo vazio não aprova nada. O defeito plantado é o da 1.1.6: a classe pendente promovia a unidade inteira para BLOCKED em toda execução, sobre um limite da medição que não é pré-condição ausente de ninguém.',
	'cadencia.mecanismo_do_fato_medido'     => 'o mecanismo da cadência sai do FATO MEDIDO, e não só da declaração: com agendamento observado e a chave vazia a linha fecha OK nomeando o mecanismo OBSERVADO — o gatilho que o operador desabilita para pausar —, e com a chave declarada ela fecha OK nomeando o declarado sem perder o observado, porque são fatos diferentes. O piso é o caso real: sem agendamento observado E com a chave vazia não há gatilho nenhum a nomear, e aí sim a pré-condição está ausente — BLOCKED, e é o único ramo que declara precondicao, de onde sai o gate de convergência. O defeito plantado é o da 1.1.6: a chave nasce vazia por desenho, e o BLOCKED saía em toda execução, para sempre, sobre uma ausência que ninguém vai mudar.',
	'mcp.gate_le_o_veredito_final'          => 'o gate de aplicação lê o veredito de canal DEPOIS da promoção da unidade, e ele é o mesmo que o relatório imprime: a unidade do canal promovida para BLOCKED chega ao registro como BLOCKED, o gate a enxerga assim e a autodesativação é NEGADA nomeando quem a segurou. Os tetos são a fronteira da propagação: unidade que fechou no mesmo estado não reescreve o registro, e rótulo que não nomeia um veredito registrado não cria entrada — inventar entrada aqui seria a segunda derivação voltando por outra porta, que é o defeito original. O piso planta o que foi medido em produção: o veredito era gravado ANTES de o autoteste rodar, a promoção vinha depois, e o encerramento imprimia "os vereditos de canal em OK, lidos do registro da execução" enquanto a contagem do MESMO relatório listava mcp.canal_exposto entre os BLOCKED.',
	'mcp.autoteste_veredito'                => 'o autoteste do canal tem teto e piso: rota presente que responde 2xx sem item reprovado fecha OK, rota AUSENTE fecha BLOCKED e nunca OK, e rota que responde reprovando — booleano falso, lista de falhas não vazia, status de erro ou código fora de 2xx — fecha FALHA, que é o que reprova a entrega; recusa por credencial (401/403) é BLOCKED e não FALHA, porque a via interna não carrega credencial. O piso planta o defeito: o README afirmava desde a 1.0.6 que files/selftest rodava na entrega, e o pacote não tinha uma única chamada de execução de rota ou de habilidade.',
	'relatorio.contagem_colada_no_estado'   => 'cada número do resumo por estado sai COLADO ao estado que ele conta, e os nomes de um estado não viajam dentro do segmento de outro. O piso planta o defeito da 1.0.17: a linha do encerramento imprimia "5 em FALHA: nenhum · BLOCKED: … · WARN: …" — o 5 era FALHA MAIS BLOCKED somados, encostava no primeiro estado da string, e a mesma string listava WARN, que não estava nos cinco.',
	'tema.link_privacidade_preserva'        => 'o link da política PREENCHE quando falta e nunca apaga: sem política publicada o href é REMOVIDO e o parágrafo fica inteiro, com tudo o que houver nele; com política publicada o href do modelo recebe o permalink real; e o href explícito do agente — uma política em PDF externo — sobrevive ao render. O piso reproduz os dois defeitos da 1.0.19 na bancada: a função antiga devolve string vazia sem política e troca o PDF pelo permalink com ela.',
	'release.matriz_do_catalogo'            => 'a matriz de origens de release suportadas saiu da configuração de site e virou CATÁLOGO do pacote: ela responde de qual versão instalada este implantador sabe subir, e nenhum projeto legítimo tem resposta diferente — sozinha ela ocupava 78 das folhas do arquivo que o operador abre. O teto lê o catálogo do próprio pacote inteiro e exige as três colunas em cada entrada. Os pisos são os quatro modos de o catálogo mentir: arquivo ausente e caminho vazio não podem declarar origem homologada — vazio é o lado seguro, em que só a instalação limpa passa —, e comentário, linha em branco e linha SEM a coluna de determinação não podem virar origem suportada, porque origem sem o que a sustenta é homologação afirmada e não feita.',
	'decisoes.leitor_do_pacote'             => 'o produtor que o RUNTIME usa lê o catálogo do próprio pacote, e essa metade não podia ficar sem piso: decisoes.fonte_unica mede pela leitura da SUÍTE — de propósito, porque auditor que usa o leitor do auditado não acusa defeito do leitor —, e com o produtor enxergando uma linha a mais o detector continuaria verde e o site sairia com outra decisão. O teto lê o catálogo inteiro, exige forma de caminho pontilhado em toda chave, e confere que bloco() remonta a lista na ordem POSICIONAL de que a precedência de origem depende. Os pisos são as formas de o catálogo mentir, numa bancada que reproduz a forma REAL do arquivo: decisão DESLIGADA com # na frente — três colunas, JSON válido e motivo com corpo, que é como um catálogo ganha linha fantasma de verdade —, linha em branco com as tabulações, linha sem a coluna de motivo, motivo presente e vazio, e célula que não é JSON. Bancada mais fácil que o mundo faz a guarda cair por outra porta, e o piso passa a aprovar por acidente.',
	'formulario.existe_e_envia'             => 'o site nasce com um formulário que ENVIA. O regime cf7-email criava nada: declarava campos, página de confirmação e caixa de leads, e a etapa só emitia uma linha dizendo que o regime existia — o plugin que processa o formulário nem estava no catálogo, só a CAIXA dele, guardando envios que nunca aconteciam. Mede o caminho inteiro sem WordPress: o markup traz os quatro campos e o botão de enviar, o obrigatório declarado sai com o asterisco e o não declarado não sai, o destinatário nunca é vazio (vazio faz o CF7 recusar o envio e o formulário fica no ar sem entregar nada), o shortcode entra na página sem apagar o que já estava, não entra duas vezes na reexecução, e o shortcode movido de lugar pelo agente não vira um segundo. O e-mail sai com destinatário, assunto, Reply-To de quem escreveu e o texto que a pessoa mandou.',
	'tela.falha_diz_a_saida'                => 'toda falha na tela diz o que quebrou E qual e a saida, em portugues comum. A correcao anterior introduziu o defeito oposto ao paragrafo tecnico: a tela imprimia "<etapa>: nao deu certo" e nada mais — cabe numa linha e nao serve para nada, justamente na linha que a pessoa le quando a implantacao falhou. O teto e toda etapa nomeada na tela ter saida declarada; os pisos sao as saidas serem DIFERENTES entre si (frase repetida em todas e a generica de novo, so que copiada), toda saida trazer um verbo de acao (descrever o problema devolve a pessoa ao ponto de partida) e a frase generica nao voltar. A frase de "nao ha saida conhecida" existe e e a excecao — se virar a resposta de todas, o texto voltou a nao servir.',
	'preflight.plugin_alheio_nao_impede'    => 'o caso de producao da 1.3.0, e este piso e o que faltava. A hospedagem instala um plugin no provisionamento, plugins_operacionais nasce vazia por desenho, e preflight.baseline — uma linha DESCRITIVA, cuja mensagem dizia "eles ficam como estao" — fechava FALHA com o gate padrao de APLICACAO. A unidade preflight foi promovida, as 39 unidades que dependem dela foram suspensas, e o site ficou sem tema, sem plugins, sem paginas e sem posts. Mede as tres regras que nasceram disso: o baseline relata e nunca reprova (nem tem ramo adverso), o gate PADRAO e fase — para impedir a instalacao a checagem tem de dizer que impede —, e a suspensao sai dos FATOS CRITICOS nomeados e nao do veredito agregado. O piso ao contrario esta junto: quando um fato critico de verdade cai, a suspensao acontece e o fato sai nomeado.',
	'projeto.schema_valida'                 => 'o arquivo que o operador abre tem o MESMO validador da configuração, apontado para outro schema — um segundo validador seria um segundo conjunto de regras divergindo do primeiro no dia em que alguém corrigisse só um. O teto é o arquivo entregue validando e o produtor carregando-o, com o fuso nascendo PREENCHIDO (caso declarado: existe resposta certa para o contexto deste template) e o telefone nascendo vazio. Os pisos são treze mutantes, um por regra que o schema promete: tipo, chave não declarada, obrigatória ausente, os três enums, o padrão de texto dos identificadores de conta — colar a propriedade antiga do Universal Analytics no campo do GA4 não quebra nada e faz a medição sumir —, os mínimos numéricos, o ponto de contato sem tipo e o campo fora do registro do regime. E o ponteiro do destino de cada formulário precisa RESOLVER dentro do próprio arquivo: é isso que fez a trinca mover inteira em vez de partida.',
	'journal.escritas_desta_execucao'       => 'o conjunto das páginas que ESTA execução escreveu sai do JOURNAL — o registro que o pacote já mantém de cada gravação —, e nunca de uma lista escrita à mão: inserção e atualização carregam o id na operação inversa, e as duas contam, sem repetição e em ordem. Os pisos são os quatro modos de o conjunto mentir: entrada de OUTRA execução não entra (uma retomada contaria como sua a página da execução anterior), entrada que não é de post não entra, journal vazio não inventa id — escopo vazio absolveria toda página marcada de graça — e entrada de post sem operação inversa não vira id zero.',
	'relatorio.mudanca_desde_a_aplicacao'   => 'o modo somente-relatório compara com a BASE — o último valor que este pacote aplicou — e não com a configuração: a linha é REGISTRO DO QUE MUDOU DESDE A ÚLTIMA APLICAÇÃO, com os dois valores nomeados, e diz em voz alta que isso não é divergência. A comparação com a configuração continua existindo na SEGUNDA linha, rotulada, porque tem leitor: quem for reexecutar o implantador. Os dois pisos do roteiro: option editada pelo agente aparece como mudança e nunca acusada como divergência, e option intocada com a configuração mudada aparece SÓ na segunda linha. Sem base, a linha diz que não existe "desde a última aplicação" a medir, em vez de afirmar o resultado de uma comparação que não aconteceu.',
	'fases.regra_de_aplicabilidade'         => 'as DUAS metades da regra de fase, medidas na classe REAL que o host executa. A primeira separa o que a 1.1.5 fundia: checagem com fase declarada rodando FORA da fase dela fecha N/A NOMEANDO a fase em que ela é medida — não falta ação de ninguém ali, falta a fase —, e na fase certa ela continua BLOCKED, porque ali o que falta é pré-condição. A segunda é o preço da primeira: o registro diz quantas checagens esperam cada fase, quais são e quando aquela fase rodou pela última vez, e fase declarada que NUNCA rodou fecha WARN com todas as letras. Os pisos são os cinco modos de a regra se apagar sozinha: fase declarada vazia ou fora da lista fechada não pode absolver (seria a saída barata do BLOCKED), fase corrente indefinida não pode absolver, BLOCKED não conta como medição, N/A não conta como medição — é assim que a regra nova apagaria o próprio contrapeso — e WAIVED não conta; e quem não mediu não carimba: a fase não medida conserva o registro anterior, em vez de a rodada de build passar a afirmar que a fase de navegador rodou. E a correção da 1.1.7, do mesmo defeito do aviso que sai sempre: fase cujas checagens esperadas fecharam TODAS em N/A nesta execução é declarada NÃO APLICÁVEL a este emissor e sai FORA da cobrança, relatada com quantas a esperam — cobrar de um emissor a evidência que ele não produz é WARN permanente sobre ausência por desenho. O piso não deixa isso virar a saída barata: uma única linha em BLOCKED ao lado das N/A devolve a fase à cobrança, e declarar a fase não aplicável NÃO a registra como executada — nunca, rodou_agora e o registro durável não se movem.',
);

$rotulos_funcionais['limpeza.plano_dos_padroes'] = 'o PLANO da limpeza dos padrões da instalação limpa é regra pura com teto e piso: contra a instalação medida em 2026-09-07 (três temas de fábrica inativos, Akismet ativo, Hello Dolly inativo, o tema do pacote ativo, o plugin da hospedagem e o de SEO no lugar), os três temas e os dois plugins declarados saem como REMOVER, o Akismet marcado para desativação pela API do núcleo antes, e nada fora da lista é tocado. Os pisos são as guardas: tema ATIVO declarado na lista é PULADO nomeando o motivo, tema PAI do ativo idem, item declarado e não instalado é AUSENTE e não erro, e lista vazia é plano vazio — a limpeza só remove o que está declarado, nunca decide sozinha o que é padrão de fábrica.';
$rotulos_funcionais['formulario.na_pagina_declarada'] = 'a PÁGINA de cada regime de formulário é lida de config/projeto.json — o arquivo em que o bloco formularios mora — pela função nomeada que a 2.1.0 criou, e a colocação do formulário na página REPROVA nomeando pagina_ref e o arquivo quando a referência falta. O defeito medido na implantação de 2026-09-07 (vinha da 1.7.4): esta era a única chave do bloco lida de config/site.json, voltava vazia, por_na_pagina() devolvia vazio em todo caminho de falha, e o formulário do regime cf7-email era criado e posto em página nenhuma com a unidade fechando OK. O teto resolve a página de cada regime da configuração REAL e confere que ela é uma entrada de paginas; o piso prova que o leitor errado devolve vazio para a mesma chave — o defeito plantado, que o teto não deixaria passar.';
$rotulos_funcionais['plugins.supressao_por_transiente'] = 'o mapa plugins.supressao_onboarding aceita a forma transiente:<nome> além de option.chave, e a entrada do servidor do canal declara o transiente que o código dele lê (wp_mcp_ultimate_activated, includes/Plugin.php) — a supressão o apaga na MESMA unidade que ativa, antes de qualquer admin_init. Medido em 2026-09-07: o assistente do wp-mcp-ultimate é decidido por transiente, option nenhuma o desarmava, e em toda instalação limpa o lote seguinte à ativação era sequestrado uma vez e repetido pelo cliente, com dois WARN na tela sobre um evento esperado. O teto lê o catálogo e o contrato das duas formas; o piso confere que o código da supressão reconhece o prefixo e apaga o transiente.';
$rotulos_funcionais['renomeacao.plugin_intacto'] = 'depois de renomear o pacote para um prefixo qualquer, NENHUM arquivo do plugin mudou — nem conteúdo, nem nome, nem caminho. É a linha que separa um site derivado deste template de um FORK do plugin: até a 1.6.6 a ferramenta varria a raiz inteira e renomeava fontes/site-core/ junto, e cada site nascia com options <prefixo>_ga4_measurement_id em vez de f3base_ga4_measurement_id — um plugin com release própria cujo nome de option muda por site não é um plugin, são N plugins parecidos, e nenhuma correção publicada alcança nenhum deles. A sonda copia o pacote, renomeia de verdade e compara a impressão do que é do plugin nesta árvore — partilhado/, a cópia vendorizada, e assets/plugins/, a reserva — antes e depois, exigindo também que a renomeação TENHA acontecido fora do plugin — sem isso, uma ferramenta que não renomeasse nada passaria. O piso é o mutante da 1.6.6: sem as duas exclusões de caminho declaradas em ferramentas/excecoes-de-prefixo.tsv, o plugin PRECISA mudar.';
$rotulos_funcionais['renomeacao.secao_medida_apos_renomear'] = 'a SEÇÃO CONTINUA SENDO MEDIDA depois da renomeação, e esta é a exceção que a exclusão do plugin criou. A classe que marca seção medida é carimbada pelos patterns do TEMA e pelo CONTEÚDO — os dois renomeados — e é procurada pelo coletor do PLUGIN, que não é: com o tema carimbando <prefixo>-secao-abertura e o plugin observando f3base-secao-, o observador não recebe alvo nenhum e a medição de seções morre calada em todo site renomeado, com o evento continuando declarado e respondendo nada para sempre. A saída é o prefixo de seção ser contrato do PLUGIN e não identidade do site: ele fica f3base-secao- em todo lugar, declarado em partilhado/dados/contrato-de-nomes.tsv — cópia conferida por hash do contrato do plugin —, e a renomeação o atravessa sem tocá-lo. A sonda renomeia de verdade, monta a lista de classes que os patterns e as páginas RENOMEADOS carimbam e roda a função REAL do coletor — nomeDaSecao(), extraída de f3base-tracking.js e executada sob o Node — contra cada uma. O piso é o meio-termo: com o contrato apagado e as exclusões de caminho no lugar, as classes PRECISAM sair sem nome.';
$rotulos_funcionais['renomeacao.contrato_de_nomes_completo'] = 'o contrato de nomes do plugin cobre TODA option do catálogo, TODO evento declarado e o prefixo de seção — e nada disso é lista escrita à mão: o que ele precisa cobrir é lido do catálogo de options do próprio plugin e da declaração de eventos de comportamento. É o que impede a tabela de envelhecer: uma option nova acrescentada ao plugin e esquecida no contrato voltaria a ser reescrita pela renomeação do lado de quem grava, e o site ficaria com o implantador escrevendo um nome e o plugin lendo outro. O piso é a MESMA função contra um contrato de onde uma grafia exigida foi removida.';
$rotulos_funcionais['renomeacao.preservados_so_do_codigo'] = 'GRAFIA PRESERVADA É GRAFIA QUE O CÓDIGO DO PLUGIN USA, ou que o contrato declara em linha de dados — nunca a que a prosa do plugin cita. O defeito vinha desde que a derivação existe e foi medido na 2.0.0: a varredura lia cada arquivo do plugin inteiro, e o comentário do próprio contrato de nomes que explica quais options são estado SÓ DO IMPLANTADOR as nomeava — a derivação capturava os nomes DO COMENTÁRIO, o pacote renomeado para acme saía com f3base_lock, f3base_checkpoint, f3base_journal, f3base_estado_aplicacao, f3base_release e f3base_fases intactos (quinze grafias ao todo que nenhum código do plugin usa), e estatica.sem_residuo_de_prefixo fechava OK porque a lista de preservadas as absolvia. Agora PHP passa pelo tokenizador e perde comentários, JS e CSS perdem blocos e linhas de comentário, TSV fica só com as linhas de dados, e Markdown não entra. O teto é a regra pura sobre cinco amostras plantadas e, de ponta a ponta, uma cópia do pacote cuja reserva ganhou um arquivo em que uma grafia aparece só em comentário e outra só em código: renomeada de verdade, a da prosa PRECISA virar acme_ e a do código PRECISA ficar. O piso é a mesma varredura sem o corte — o comportamento antigo —, que PRECISA capturar a prosa; se não capturasse, o corte não estaria provando nada.';
$rotulos_funcionais['pacote.plugin_so_como_zip'] = 'o bundle NÃO contém a fonte do plugin, e contém a reserva versionada dele. O plugin deixou de ser construído pelo implantador na 1.7.0 e deixou de MORAR nesta árvore na 2.0.0: entregar a fonte dele dentro do bundle põe no pacote uma cópia que ninguém deve editar e que diverge da release publicada no instante seguinte — e é essa cópia que dá à renomeação de prefixo algo para renomear. Medido no ARTEFATO montado, com piso pela lista mutante.';
$rotulos_funcionais['pacote.reserva_confere_com_o_catalogo'] = 'a reserva embutida É O ZIP PUBLICADO, e o diz de cinco formas que precisam concordar: o sha256 dos bytes da reserva na árvore é o que o catálogo declara em plugins.instalaveis.<n>.sha256; a versão que o NOME carrega é a que o cabeçalho de dentro do zip declara; a pasta de topo é a pasta_esperada; a cópia dentro do bundle é byte a byte a da árvore; e o zip tem entradas legíveis. Até a 1.7.4 o implantador MONTAVA o zip do plugin e comparava a reserva com a própria montagem — as duas batiam sempre, e nenhuma era o que o catálogo servia: a reserva dizia 1.0.1, o catálogo publicava 1.0.0, e a suíte inteira fechava verde. O piso quebra cada cláusula de propósito e exige que a regra acuse.';
$rotulos_funcionais['pacote.copia_vendorizada_confere'] = 'cada arquivo de partilhado/ é, byte a byte, a entrada correspondente da RESERVA — o zip publicado —, e a lista do que é cópia está declarada em partilhado/VENDORIZADO.tsv nos dois sentidos: arquivo em disco sem declaração e declaração sem arquivo são achados, e declaração sem motivo também. Medido na 1.7.4: quatro dos cinco arquivos vendorizados diferiam do zip publicado — um sem a guarda de class_exists, outro sem duas chaves de cabeçalho que o plugin governa — e nada acusava, porque a gravação funciona. O piso muda um byte da cópia, tira uma declaração, tira a origem do zip e esvazia a tabela, e exige que a regra acuse nos quatro.';
$rotulos_funcionais['lotes.gate_de_fase_nao_derruba_estado'] = 'o que o relatório AFIRMA e o que ele FAZ não podem se contradizer: nenhuma linha declarada com gate de FASE — aquela sobre a qual o texto escreve que "este host não produz" a evidência e que ela NÃO é somada ao gate da autodesativação — pode fechar FALHA, porque FALHA entra na contagem crua que derruba o estado da aplicação, e o estado é a PRIMEIRA das três condições daquele gate. Foi a contradição medida na 1.7.2: `release.versao_site_core` saía nomeada como não somada e era ela que punha a execução em FALHA_PARCIAL. A saída medida antes de escolher: varridas as emissões do runtime, toda checagem de gate `fase` capaz de fechar FALHA media evidência que este host PRODUZ — nenhuma delas era o caso em que a FALHA deveria deixar o estado de pé —, então a contagem continua crua e o que passou a ser proibido é a outra ponta. Os pisos: a contradição plantada tem de ser acusada pelo nome; BLOCKED de fase NÃO pode ser acusado, porque ele não entra na contagem; e FALHA de RELATO ou de CONVERGÊNCIA também não, porque sobre essas o pacote não afirma que a evidência vem de outro lugar — o host mediu, e derrubar o estado é o desfecho que a própria linha anuncia. O QUE ESTA LINHA NÃO AFIRMA, e a distinção é o que a torna honesta: que as declarações DESTE pacote não contenham nenhuma contradição. Ela exercita a REGRA contra linhas que a própria sonda monta — prova que a função reconhece a contradição quando alguém a entrega, e não prova nada sobre o objeto. Quem mede o objeto é estatica.gate_de_fase_sem_ramo_de_falha, sobre as emissões escritas em includes/. As duas existem porque medem coisas diferentes: o estático prova a invariante no build, e esta cobre o que só aparece em execução — um estado que a árvore não consegue provar e que o host resolve na hora.';
$rotulos_funcionais['plugins.veredito_de_versao_do_site_core'] = 'UM FATO, UMA LINHA, UM VEREDITO sobre a versão do plugin do site. Até a 1.7.2 o mesmo par de números — o que ficou instalado e o que este pacote carrega — era medido por DUAS linhas com regras próprias, e numa execução real elas discordaram na mesma tela: `plugins.site_core_versao` em WARN e `release.versao_site_core` em FALHA. A segunda saiu. A bancada mede os cinco ramos da que ficou (instalada atrás fecha FALHA, à frente fecha OK, iguais fecha OK, reserva sem número fecha WARN, nada instalado fecha N/A), exige que a FALHA nomeie as duas versões e o endereço da cópia embutida, e conta os emissores do veredito no código: mais de um é o defeito voltando. Os pisos são os dois erros de regra: o ramo "atrás" em WARN — que não derruba o estado e por isso deixaria a ferramenta de correção sair do ar num site com o plugin superado — e o ramo "à frente" em estado adverso, que era a comparação de igualdade da linha removida reprovando o caso certo; mais o piso da frase, que sem endereço resolvido não pode prometer uma cópia embutida que o leitor não sabe onde achar.';

$funcionais = f3b_ck_funcionais( $raiz, $suite );

foreach ( $rotulos_funcionais as $nome => $msg_ok ) {
	if ( ! isset( $funcionais[ $nome ] ) ) {
		estado( 'BLOCKED', $nome, 'a sonda funcional não devolveu veredito para esta checagem.', 'pendencia-externa', 'build' );
		continue;
	}

	$r = $funcionais[ $nome ];

	estado_por_origem(
		(bool) $r['ok'],
		'site',
		$nome,
		$msg_ok . ' ' . (int) $r['medidas'] . ' asserção(ões).',
		count( $r['achados'] ) . ' achado(s): ' . f3b_amostra( $r['achados'] ),
		'teste-funcional',
		'build'
	);
}

emitir( f3b_ck_js_extrator( $raiz, $suite ), 'js.extrator_resposta', 'o extrator de resposta do cliente acha o JSON no fim de um corpo HTML+JSON e devolve null quando não há objeto.', 'teste-funcional', 'build' );

emitir( f3b_ck_js_banner( $raiz, $suite ), 'js.banner_de_consentimento', 'o controle do titular é medido no COMPORTAMENTO, com o cliente real rodado de ponta a ponta contra um DOM de mentira e a visibilidade decidida pelo style.css REAL — o par (hidden, display), que é a única pergunta que o visitante faz. O banner NASCE FECHADO logo depois de iniciar(), com o id que o aria-controls do rodapé aponta; ele mora na base do viewport (inset-block-end declarado, inset: 0 em lugar nenhum) e não é modal; abrir dá foco ao banner, anuncia aria-expanded e reserva no corpo exatamente a altura da faixa; aceitar e recusar gravam a decisão E fecham; fechar fecha SEM decidir; reabrir mostra o estado corrente nos dois sentidos; e a caixa interna existe, o que tira do CSS a regra órfã. Os pisos são o defeito de hoje escrito dentro da sonda: o CSS da 1.1.2 — display de classe sem o par [hidden] — tem de aparecer como banner visível na carga e como Fechar que não fecha; definir() sem o fecho tem de aparecer como cookie gravado com o banner aberto; e fechar() sem a devolução do foco tem de aparecer como foco que não volta.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_cliente( $raiz, $suite ), 'js.decisoes_do_cliente', 'as decisões do cliente têm teto e piso sob o Node, com as funções extraídas do arquivo REAL: a rejeição de lock PARA na primeira ocorrência — inclusive contra a resposta ANTIGA, sem parou, concluido, lote, rotulo nem aplicacao, que é o piso do laço de 163 requisições —, o avanço só acontece sobre resposta da própria unidade e BLOCKED de unidade continua avançando, o índice fora do plano é recusado (o Etapa 94 de 40), a rejeição de lock entrega dono, idade do heartbeat, TTL e o horário do abandono, linha que não fecha OK recebe nome de reserva e a contagem por estado nunca fica sem a lista, e o rodapé fecha num estado da lista declarada — nunca vazio. E a ORDEM NO DOM é medida na árvore que o operador vê: a sonda monta um DOM de mentira e roda o cliente REAL de ponta a ponta contra ele — o progresso continua sendo o primeiro filho e fica com uma linha curta, o nó de encerramento vem DEPOIS da tabela e carrega o resumo inteiro, e a região tem nome acessível, tabindex e recebe o foco. O piso são MUTANTES do próprio cliente: o resumo escrito em progresso, o encerramento montado antes da tabela e a chamada de foco apagada — a bancada tem de acusar os três.', 'teste-funcional', 'build' );

/* ---------- entregáveis ---------- */

foreach ( array_keys( f3b_entregaveis( $raiz ) ) as $nome ) {
	$r = f3b_ck_entregavel( $raiz, $nome );

	if ( $r['ok'] ) {
		estado( 'OK', $nome, 'entregável presente e completo.', 'analise-estatica', 'build' );
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		'entregável incompleto. Arquivo(s) que falta(m): ' . f3b_amostra( $r['achados'], 8 ) . '.',
		'analise-estatica',
		'build'
	);
}

/* ---------- condicionais que este projeto não instancia ---------- */

$config = f3b_config( $raiz ) ?? array();
/*
 * Handoff é o SITE DE REFERÊNCIA em artefato de handoff
 * (data-artifact="wordpress-source-blueprint"), não a existência de release
 * anterior. Condicionar as duas coisas ao mesmo predicado era erro de
 * categoria: bastava declarar a origem suportada de uma release de correção
 * para as checagens de handoff saírem de N/A sem que nada de handoff existisse.
 * A ausência da chave é lida com padrão explícito — chave inexistente não é
 * "ligado" (armadilha do helper permissivo).
 */
$handoff    = 'handoff' === (string) ( $config['site_referencia']['tipo'] ?? '' );

/**
 * O REGIME EXISTE? A resposta sai do VALOR do destino, e de mais nada.
 *
 * A 1.0.19 tirou o interruptor `ativo` da entrada do formulário: havia dois
 * fatos podendo discordar — o interruptor e o destino —, e eles discordavam. O
 * regime whatsapp era declarado ATIVO e fechava BLOCKED por falta de destino na
 * mesma execução. Presença de valor é a condição, e uma condição só.
 *
 * @param array<string,mixed> $config Configuração inteira.
 * @param string              $regime Regime declarado.
 * @return bool
 */
function f3b_regime_existe( array $config, string $regime ): bool {
	foreach ( (array) ( $config['formularios'] ?? array() ) as $formulario ) {
		if ( ! is_array( $formulario ) || $regime !== ( $formulario['regime'] ?? '' ) ) {
			continue;
		}

		$caminho = (string) ( $formulario['destino'] ?? '' );

		if ( '' === $caminho ) {
			continue;
		}

		$valor = $config;

		foreach ( explode( '.', $caminho ) as $segmento ) {
			if ( ! is_array( $valor ) || ! array_key_exists( $segmento, $valor ) ) {
				$valor = '';
				break;
			}

			$valor = $valor[ $segmento ];
		}

		if ( is_scalar( $valor ) && '' !== trim( (string) $valor ) ) {
			return true;
		}
	}

	return false;
}

$cf7_existe      = f3b_regime_existe( $config, 'cf7-email' );
$whatsapp_existe = f3b_regime_existe( $config, 'whatsapp' );

/*
 * O SEGREDO NÃO ESTÁ NO PACOTE, e a condição é MEDIDA — nunca declarada e
 * pronta. `f3b_segredos_declarados()` lê a âncora do próprio pacote e o
 * detector `estatica.segredo_fora_da_configuracao` mede a ausência; aqui a
 * mesma medida decide se a checagem do envio de servidor é inaplicável (não há
 * token, e não pode haver) ou pendência externa (alguém declarou um, e aí o que
 * falta é uma conta real para responder).
 */
$segredos_declarados = f3b_segredos_declarados( $raiz );
$config_bruta        = (string) @file_get_contents( $raiz . '/config/site.json' );
$segredo_no_pacote   = false;

foreach ( $segredos_declarados['nomes'] as $nome_do_segredo ) {
	if ( str_contains( $config_bruta, $nome_do_segredo ) ) {
		$segredo_no_pacote = true;
		break;
	}
}

$verificacao = (array) ( $config['verificacao_dominio'] ?? array() );
$sem_token_de_verificacao = '' === trim( (string) ( $verificacao['google'] ?? '' ) )
	&& '' === trim( (string) ( $verificacao['meta'] ?? '' ) );

$condicoes = array(
	'handoff.pacote_de_entrega'        => ! $handoff,
	'handoff.credenciais_rotacionadas' => ! $handoff,
	'formulario.regime_cf7'            => ! $cf7_existe,
	'formulario.destino_privado'       => ! $whatsapp_existe,
	'capi.envio_de_servidor'           => ! $segredo_no_pacote,
	'verificacao.dominio_declarada'    => $sem_token_de_verificacao,
);

/* ---------- o que este ambiente não pode medir ---------- */

$wp_root = (string) getenv( 'F3BASE_WP_ROOT' );
$tem_wp  = '' !== $wp_root && is_file( rtrim( $wp_root, '/' ) . '/wp-load.php' );

/*
 * APLICABILIDADE POR FASE — a correção da 1.1.6, e ela é de categoria.
 *
 * Até a 1.1.5 esta tabela inteira saía em BLOCKED, e BLOCKED estava dizendo
 * DUAS coisas que o leitor não consegue separar: "falta alguém fazer alguma
 * coisa" e "esta fase não produz este tipo de evidência, por desenho". Medido:
 * 27 linhas amarelas numa rodada impecável, 26 delas do segundo tipo — e
 * amarelo que sai numa rodada sem defeito ensina o operador a ignorar amarelo.
 *
 * A regra vem da classe que o HOST executa, `F3Base_Imp_Fases`, alcançada por
 * subprocesso: fase declarada diferente da fase corrente é condição de
 * aplicabilidade FALSA, e o contrato manda fechar N/A com a condição declarada.
 * BLOCKED fica reservado para pré-condição ausente NA FASE CERTA — e a fase
 * `build` continua sendo a fase desta rodada, então tudo o que é medido aqui
 * continua sendo cobrado aqui.
 *
 * A REGRA SOZINHA ESCONDERIA DEFEITO, e o contrapeso é obrigatório: quem impede
 * um N/A eterno de virar aprovação por omissão é a própria fixture de piso,
 * logo abaixo, que declara o que cada fase espera e acusa a fase que nunca
 * rodou. Uma sem a outra não pode ser instalada.
 */
$aplicabilidade = f3b_aplicabilidade_por_fase(
	$raiz,
	$suite,
	array_map( static fn( array $d ): string => (string) $d['fase'], f3b_bloqueadas() ),
	F3Base_Suite::FASE_CORRENTE
);

foreach ( f3b_bloqueadas() as $nome => $dados ) {
	/*
	 * CONDIÇÃO DECLARADA FALSA VENCE PENDÊNCIA EXTERNA, e o nome que está nas
	 * duas tabelas sai UMA vez. Não há pendência quando a funcionalidade não
	 * existe: pedir "WordPress em produção" para conferir o CTA de um regime
	 * que ninguém instanciou é relatar como pendente algo que ninguém pediu.
	 */
	if ( $condicoes[ $nome ] ?? false ) {
		continue;
	}

	/*
	 * SUBPROCESSO QUE NÃO RODOU NÃO ABSOLVE NINGUÉM: sem veredito de
	 * aplicabilidade a linha continua BLOCKED, com o erro nomeado. O erro seguro
	 * dos dois é continuar cobrando.
	 */
	$veredito = $aplicabilidade['vereditos'][ $nome ] ?? array();
	$aplicavel = ! isset( $veredito['aplicavel'] ) || (bool) $veredito['aplicavel'];

	if ( ! $aplicavel ) {
		estado(
			'N/A',
			$nome,
			'condição de aplicabilidade falsa: esta checagem é medida na fase ' . $dados['fase']
				. ' e esta rodada é a fase ' . F3Base_Suite::FASE_CORRENTE
				. '. Não há pendência de ninguém aqui — o que falta é a fase, não uma ação: ' . $dados['falta']
				. '. Quando a fase ' . $dados['fase'] . ' rodar, o que ela mede é: ' . $dados['motivo']
				. '. Enquanto ela não rodar, nenhuma evidência deste tipo existe.',
			'analise-estatica',
			$dados['fase']
		);
		continue;
	}

	if ( '' !== $aplicabilidade['erro'] ) {
		estado(
			'BLOCKED',
			$nome,
			'a regra de aplicabilidade por fase não pôde ser consultada, e sem ela nada é dispensado: ' . $aplicabilidade['erro']
				. '. ' . $dados['motivo'] . '. Falta: ' . $dados['falta'] . '.',
			$dados['classe'],
			$dados['fase']
		);
		continue;
	}

	if ( $tem_wp ) {
		estado(
			'BLOCKED',
			$nome,
			'há WordPress em ' . $wp_root . ', mas esta suíte não traz a sonda desta checagem: ' . $dados['motivo'] . '.',
			$dados['classe'],
			$dados['fase']
		);
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		$dados['motivo'] . '. Falta: ' . $dados['falta'] . '.',
		$dados['classe'],
		$dados['fase']
	);
}

$bloqueadas_declaradas = f3b_bloqueadas();

foreach ( f3b_nao_aplicaveis() as $nome => $dados ) {
	if ( $condicoes[ $nome ] ?? false ) {
		estado( 'N/A', $nome, 'condição declarada: ' . $dados['condicao'] . '.', $dados['classe'], $dados['fase'] );
		continue;
	}

	/*
	 * O NOME QUE ESTÁ NAS DUAS TABELAS SAI UMA VEZ — nos DOIS sentidos, e este
	 * era o lado que faltava. Com a condição verdadeira, o laço de cima já
	 * pulava e este emitia o N/A; com ela FALSA, os dois emitiam, e o mesmo
	 * nome saía duas vezes na mesma rodada — uma com a fase declarada dele e
	 * outra com `local`, que é a fase escrita neste ramo genérico. Duas linhas
	 * com o mesmo rótulo e fases diferentes é a divergência de fonte que este
	 * pacote persegue em todo lugar; quem tem entrada própria em
	 * `f3b_bloqueadas()` já falou por si, com a fase que ela declara.
	 */
	if ( isset( $bloqueadas_declaradas[ $nome ] ) ) {
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		'a condição que tornava esta checagem inaplicável deixou de valer, e a sonda dela não roda neste ambiente. Falta: WordPress instalado para exercitar o caminho.',
		'pendencia-externa',
		'local'
	);
}

/* ---------- cruzamentos da própria suíte ---------- */

/*
 * As duas metacheagens entram na própria lista: elas SÃO emitidas nesta rodada,
 * e o cruzamento precisa enxergá-las para não acusar como órfão o rótulo que
 * está prestes a sair. Nada mais é acrescentado à mão.
 */
/*
 * O QUE SAIU DESTA SUÍTE SAIU DECLARADO — 2.0.0. A conferência da lista de
 * exclusões vem ANTES dos dois cruzamentos, e lê a mesma lista de emitidas que
 * eles leem: uma checagem declarada excluída e emitida seria acusada aqui e
 * apareceria órfã lá, e a ordem faz o primeiro achado nomear a causa.
 */
emitir(
	f3b_ck_excluidas_declaradas( $suite, F3Base_Suite::emitidas() ),
	'excluidas.declaradas',
	'toda checagem que a 1.7.4 emitia e esta suíte não emite mais está DECLARADA em suite/excluidas.tsv, com categoria do vocabulário fechado e motivo escrito, e nenhuma linha declarada excluída foi emitida nesta rodada. Rótulo que some é indistinguível de rótulo esquecido, e é assim que a cobertura encolhe em silêncio; a lista é o espelho da do repositório do plugin, que declara do lado de lá o que ficou aqui.',
	'analise-estatica',
	'build'
);

$emitidas = array_merge( F3Base_Suite::emitidas(), array( 'manifesto.bidirecional', 'armadilhas.mapeadas' ) );

$manifesto = f3b_ck_manifesto_bidirecional( $suite, $emitidas );

estado_por_origem(
	(bool) $manifesto['ok'],
	'site',
	'manifesto.bidirecional',
	sprintf( '%d requisito(s) do manifesto apontam para checagem emitida, e nenhum rótulo emitido ficou órfão.', (int) $manifesto['requisitos'] ),
	count( $manifesto['achados'] ) . ' achado(s): ' . f3b_amostra( $manifesto['achados'] ),
	'analise-estatica',
	'build'
);

$armadilhas = f3b_ck_armadilhas_mapeadas( $suite, $emitidas );

estado( $armadilhas['estado'], 'armadilhas.mapeadas', $armadilhas['mensagem'], 'analise-estatica', 'build' );

/* ---------- o contrapeso da regra de fase ---------- */

/*
 * ESTA LINHA É A METADE QUE IMPEDE A OUTRA DE VIRAR CEGUEIRA, e ela sai por
 * ÚLTIMA de propósito: o registro conta o que cada fase espera a partir das
 * LINHAS EFETIVAMENTE EMITIDAS nesta rodada, e as duas metacheagens acima são
 * linhas como quaisquer outras. Emiti-la antes delas produziria uma contagem
 * de fase `build` menor do que a rodada — número que descreve outra coisa que
 * não o que saiu na tela, que é o defeito que a 1.0.17 fechou.
 *
 * Ela entra na própria lista de emitidas, pela mesma razão que as duas
 * metacheagens entram: ela SAI nesta rodada, e o cruzamento precisa enxergá-la
 * para não acusar como órfão o rótulo que está prestes a sair.
 */
$fases = f3b_ck_registro_de_fases( $raiz, $suite, F3Base_Suite::linhas_com_fase(), F3Base_Suite::FASE_CORRENTE );


/* =========================================================================
 * RESUMO
 * ====================================================================== */

echo "\n== resumo ==\n";

/*
 * CONTAGEM E NOMES SAEM JUNTOS. O resumo imprimia `BLOCKED 22` e nenhum nome:
 * quem quisesse saber QUAIS tinha de reler as 73 linhas acima e contar à mão.
 */
$contagem     = F3Base_Suite::contagem();
$nomes_da_rodada = F3Base_Suite::nomes_por_estado();
$total        = array_sum( $contagem );

foreach ( f3b_resumo_por_estado( $contagem, $nomes_da_rodada ) as $linha_do_resumo ) {
	echo $linha_do_resumo . "\n";
}

printf( "   %-8s %d\n", 'TOTAL', $total );

$falhas = F3Base_Suite::falhas();

/* =========================================================================
 * REGISTRO DURÁVEL DE FASES. Gravado ANTES do selo e INDEPENDENTE dele, e as
 * duas coisas são deliberadas.
 *
 * Antes: o selo é a última etapa e pode abortar; o registro de fases não pode
 * depender de ela ter dado certo, porque quem o lê é a rodada SEGUINTE.
 *
 * Independente: a rodada com FALHA APAGA `suite/rodada.json` — registro de
 * limpeza que sobrevive a uma reprovação é afirmação sem medição por trás. O
 * registro de fases é o oposto: ele não afirma aprovação nenhuma, afirma
 * EXECUÇÃO, e apagá-lo numa rodada reprovada perderia o fato de que a fase de
 * navegador rodou um dia — que é justamente o fato que a rodada de build não
 * tem como reproduzir sozinha.
 * ====================================================================== */

$registro_de_fases = f3b_gravar_registro_de_fases( $raiz, (array) $fases['durar'] );

foreach ( $registro_de_fases['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

/* =========================================================================
 * ETAPA 3 — SELO DA RODADA. Última, sempre: o resumo por estado só existe
 * depois das checagens, e é ele que entra no registro.
 * ====================================================================== */

echo "\n== etapa 3: selo da rodada ==\n";

$selo = f3b_selar_rodada( $raiz, $suite, $build, $contagem, $nomes_da_rodada, f3b_com_piso( $suite ) );

foreach ( $selo['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

if ( $selo['gravado'] ) {
	printf(
		"   registro: %s\n   hash do pacote: %s\n   conferido no bundle SELADO: %s\n",
		$selo['arquivo'],
		$selo['hash'],
		(string) ( $selo['conferido'] ?? '(não conferido)' )
	);
}

if ( ! $selo['ok'] ) {
	estado(
		'FALHA',
		'entrega.selo_da_rodada',
		'o selo da rodada não fechou: ' . f3b_amostra( $selo['achados'], 3 ) . '.',
		'medida',
		'build'
	);

	printf( "\nrodada REPROVADA no selo: %d checagem(ns) em FALHA.\n", F3Base_Suite::falhas() );
	exit( 1 );
}

if ( $falhas > 0 ) {
	printf(
		"\nrodada REPROVADA: %d checagem(ns) em FALHA — %s.\n",
		$falhas,
		'FALHA: ' . ( array() === $nomes_da_rodada['FALHA'] ? 'nenhum' : implode( ', ', $nomes_da_rodada['FALHA'] ) )
	);
	exit( 1 );
}

$bloqueadas = $contagem['BLOCKED'];

printf(
	"\nrodada sem FALHA. %d checagem(ns) em BLOCKED — %s. Nenhuma delas é entregável do gate de aplicação: as de fase declarada não impedem a autodesativação, e as do host são medidas lá.\n",
	$bloqueadas,
	'BLOCKED: ' . ( array() === $nomes_da_rodada['BLOCKED'] ? 'nenhum' : implode( ', ', $nomes_da_rodada['BLOCKED'] ) )
);

exit( 0 );
