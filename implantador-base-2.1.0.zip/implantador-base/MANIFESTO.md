<!-- gerado:inicio=carimbo -->
# Manifesto da release — implantador-base 2.1.0

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio, e o documento passa a descrever um pacote que não é este. O que não pode ser gerado
> no momento da escrita sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `2.1.0` |
| Implantador · tema · plugin | `2.1.0` · `1.6.2` · `1.0.0` |
| Bundle desta identidade | `implantador-base-2.1.0.zip` |
| Origens de release suportadas | 47 além da instalação limpa |
| Caminhos exatos no inventário | 118 |
| Prefixos declarados no inventário | 4 |
| Arquivos no pacote (fora de `dist/` e dos produtos da rodada) | 400 |
| Requisitos em `suite/manifesto.tsv` | 222 |
| Armadilhas com checagem mapeada | 122 |
| Armadilhas em pendência declarada | 11 |
| Detectores com piso em disco | 65 |
| Ramos de piso (negativa + positiva) | 130 |
| Páginas · posts declarados | 6 · 2 |
| Reserva do plugin na árvore | `assets/plugins/base-site-core-fator3-1.0.0.zip` |
| `sha256` da reserva · declarado no catálogo | `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f` · `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f` |
| Arquivos vendorizados em `partilhado/` | 6 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

## Onde cada coisa é decidida

Quatro arquivos, quatro naturezas, e a regra que separa uma da outra: uma chave de
configuração só existe se passar nas duas metades — existe projeto legítimo em que o valor
certo é DIFERENTE, **e** o valor é impossível de derivar do site, do exemplo ou do ambiente.

- **`config/projeto.json`** — o que este site decide, e o único arquivo que o operador abre.
  Cada campo nasce vazio, salvo onde o template tem valor obviamente certo para o contexto
  dele, e cada `$comment` do schema diz o que preencher e **onde obter**. Produtor único:
  `F3Base_Imp_Projeto`. Validado pelo MESMO validador de `config/site.json`, apontado para
  outro schema.
- **`config/site.json`** — conteúdo declarado, referências internas e identidade técnica.
- **`config/decisoes.tsv`** — decisão do pacote: chave, valor em JSON e o MOTIVO, que diz o
  que aconteceria se o valor fosse outro. Produtor único: `F3Base_Imp_Decisoes`. O valor de
  uma decisão não aparece como literal em nenhum outro lugar da árvore.
- **`config/releases-suportadas.tsv`** — de qual versão instalada este implantador sabe
  subir, com a determinação que sustenta cada linha. Produtor único:
  `F3Base_Imp_Preflight::releases_suportadas()`.

`F3Base_Vocabulario` guarda o CONJUNTO de valores que os dois runtimes reconhecem; o
catálogo guarda a ESCOLHA entre eles. `decisoes.fonte_unica` cruza os dois, e é o cruzamento
que torna duas fontes seguras.

## Identidade única

A release tem **uma** identidade, e ela é compartilhada por tudo que viaja junto:
implantador, tema, configuração, conteúdo, memória de decisões e suíte. Cada componente
tem numeração PRÓPRIA e pode divergir — o tema sobe quando o tema muda, e o número que
carimba o parâmetro de versão do CSS publicado é o do tema, lido do cabeçalho, nunca a
identidade da release. Os valores desta release estão no carimbo gerado acima; nenhum
deles é digitado aqui, porque número digitado envelhece calado.

### O plugin saiu desta identidade na 1.7.0, e desta ÁRVORE na 2.0.0

`Base Site Core Fator3` (pasta `base-site-core-fator3`) **não é mais construído pelo
implantador**. Ele é artefato próprio, com identidade própria, publicado como zip e
instalado em qualquer site desta operação como qualquer outro plugin de catálogo. A
numeração dele recomeçou em `1.0.0`, e isso é deliberado: herdar o `1.3.7` diria que é o
mesmo artefato de antes com uma correção a mais, e o que mudou foi o que ele **é**.

**Na 2.0.0 a fonte dele saiu deste repositório.** O plugin tem repositório próprio, suíte
própria, bancada própria e documentos próprios; nada aqui constrói, monta, gera ou edita
código dele. O que esta árvore carrega são duas CÓPIAS conferidas contra o artefato
publicado: a RESERVA `assets/plugins/base-site-core-fator3-<versão>.zip`, que é o zip do
catálogo copiado byte a byte, e `partilhado/`, a cópia vendorizada das regras que os dois
runtimes leem. A separação deixou de ser uma exceção de caminho na ferramenta de
renomeação e passou a ser uma fronteira de repositório — e a diferença é que uma fronteira
de repositório tem digesto.

O acoplamento que caiu era um defeito silencioso, e ele foi o achado central da 1.7.0:
`ferramentas/renomear-prefixo.php` varria a raiz inteira do pacote e renomeava **também** a
fonte do plugin — slug, prefixo de classe, prefixo de option, text domain. Cada site
produzia um **fork** do plugin, com options `<prefixo>_ga4_measurement_id` em vez de
`f3base_ga4_measurement_id`. Um plugin com release própria cujo nome de option muda por
site não é um plugin: são N plugins parecidos, e nenhuma correção publicada alcança nenhum
deles.

**O prefixo interno `f3base` não mudou, e essa é a metade que importa.** Nome de option
(`f3base_ga4_measurement_id`, `f3base_comportamento`, …), nome de tabela
(`f3base_comportamento`, `f3base_eventos`, `f3base_leads_dedup`), nome de evento
(`f3base_rolagem`, `f3base_secao_vista`, …), namespace REST (`f3base/v1`), prefixo das
classes PHP e text domain continuam exatamente como estão, porque essas chaves **apontam
para dado vivo** em sites que já rodam. Nome de pasta é ENDEREÇO: trocá-lo custa uma
reinstalação. Nome de option é CHAVE DE DADO: trocá-lo orfana o valor sem apagar nada e
sem erro nenhum, e o site passa a rodar no padrão de fábrica em cima de uma configuração
que ninguém apagou. Nome de tabela é pior — renomear apaga a série histórica. Nome de
evento é pior ainda — renomear quebra a série na conta de medição do fornecedor, onde não
há como reparar depois.

Três lugares sustentam a separação, e nenhum deles é um `if` escondido:

- `ferramentas/excecoes-de-prefixo.tsv` declara `partilhado/` e `assets/plugins/` como
  caminhos que a renomeação **não atravessa**, com o motivo por linha. Até a 1.7.4 a lista
  trazia `fontes/plugin/` no lugar dos dois; ela saiu junto com o diretório;
- `partilhado/dados/contrato-de-nomes.tsv` declara as GRAFIAS que sobrevivem mesmo
  dentro dos arquivos que **são** renomeados — porque o implantador renomeado continua
  gravando `f3base_ga4_measurement_id`, que é o que o plugin lê. Ele também é cópia
  vendorizada: o contrato é do plugin, e quem o publica é quem o define;
- `partilhado/` guarda o contrato que os dois runtimes leem, e desde a 2.0.0 a DIREÇÃO
  está invertida: ele deixou de ser a ORIGEM que o empacotamento copiava para dentro do
  zip do plugin e passou a ser a CÓPIA que o zip do plugin governa — quatro classes de
  regra e duas tabelas, declaradas em `partilhado/VENDORIZADO.tsv` e conferidas byte a
  byte contra a reserva por `pacote.copia_vendorizada_confere`. O dono é o repositório do
  plugin; editar `partilhado/` é fork.

**Duas divergências medidas na 1.7.4 sustentam essa inversão, e as duas eram silenciosas.**
A primeira: quatro dos cinco arquivos de `partilhado/` diferiam do zip que o site recebia —
o censo demonstrativo sem a guarda de `class_exists`, que produz erro fatal `Cannot declare
class` quando os dois runtimes se encontram; o vocabulário sem `cabecalhos.csp_frame_ancestors`
e com `permissions_policy` de um valor só, enquanto o plugin 1.0.0 governa as duas;
`chaves-seo` e `emissores` diferindo em comentário. Nenhuma checagem comparava `partilhado/`
com o artefato que o site recebe. A segunda: o contrato de nomes vendorizado estava ATRÁS
do publicado — o 1.0.0 declara `f3base_proveniencia` e `f3base_operaveis` como FRONTEIRA,
options que o implantador grava e o plugin lê, e nenhuma das duas estava no contrato. Elas
sobreviviam à renomeação porque a ferramenta derivava grafias varrendo `fontes/plugin/`, e
foi assim que a renomeação para `acme` as preservou na 1.7.4: pelo diretório, não pelo
contrato. Tirado o diretório, o contrato tinha de ser o que ele diz ser.

O prefixo da classe que marca **seção medida** é a exceção que a separação criou, e ela
está resolvida no mesmo lugar: `f3base-secao-` é contrato do **plugin**, não identidade do
site. Ele é carimbado pelos patterns do tema e pelo conteúdo — os dois renomeados — e é
procurado pelo coletor do plugin, que não é; com o tema carimbando `<prefixo>-secao-` a
medição de seções morreria calada em todo site renomeado. Ele está no contrato de nomes, e
`renomeacao.secao_medida_apos_renomear` renomeia de verdade, monta a lista de classes que o
markup renomeado carimba e roda a função REAL do coletor contra cada uma — o coletor lido
de DENTRO da reserva, que é o cliente que o site recebe, e não uma cópia da fonte.

A matriz de origens aceitas além da instalação limpa é uma lista FECHADA e mora em
`config/releases-suportadas.tsv`, que é CATÁLOGO do pacote: ela responde de qual versão
instalada este implantador sabe subir, e essa pergunta não é do site. Cada entrada traz a
própria `determinacao`: `medida-no-site` quando a release foi observada rodando num site,
`entregue-nao-confirmada` quando ela foi produzida e nunca chegou a um. A distinção é
sobre o SITE e não sobre o repositório. Origem fora da lista termina em BLOCKED, sem
mutação, e cada entrada custa uma homologação: é por isso que ela é fechada. Catálogo
ausente devolve lista VAZIA, e vazia só a instalação limpa passa.

A identidade existe por um motivo operacional único: sem ela, outro agente recebe o
implantador de uma versão com o dump de outra. Tudo que o pacote produz — checkpoint,
proveniência, carimbo de versão aplicada, relatório — referencia essa identidade, e a
retomada de uma execução interrompida só acontece com a **mesma** identidade e o
**mesmo** hash de configuração.

Duas regras que dependem dela e que valem a pena repetir aqui:

- **O carimbo de versão aplicada avança apenas em `SUCESSO_APLICACAO`.** Execução que
  aborta no preflight, termina em falha ou é revertida não grava a versão. O carimbo é
  afirmação sobre o site, e um estado bloqueado que não tocou em nada não mudou o site.
- **Número de versão escrito em prosa não é contrato.** O contrato é o cabeçalho que o
  código lê. Nenhuma constante de PHP repete o número literal: ela deriva do cabeçalho,
  porque constante que repete o número do `style.css` a cada mudança de versão do tema
  sai de sincronia sem que nada acuse, o CSS publicado viaja com o parâmetro de
  versão do arquivo que não é mais o servido, e navegador e cache continuam
  entregando o antigo.

<!-- gerado:inicio=inventario -->
### Inventário: caminho para papel

Gerado de `suite/inventario.tsv`, que é a allow-list executável do empacotamento: arquivo em disco
fora dela **aborta o build com o nome**. Manter aqui uma cópia escrita à mão criaria duas fontes.

| Caminho | Papel |
|---|---|
| `MANIFESTO.md` | Manifesto da release: identidade única, inventário de caminho para papel, e a fronteira entre checksum de artefato nosso e fato observado de terceiro. |
| `MEMORIA-DECISOES.md` | Registro das decisões desta base, cada uma com o que foi decidido, por quê, o que custa e como reverter. |
| `README.md` | Leia-me do operador: árvore, pré-requisitos, instalação, execução, remoção, plugins, reversão de plugin, cadência, desligamento do canal e desvios. |
| `TEMPLATE.md` | Procedimento de troca de projeto: a ordem executável para criar um site novo a partir deste template, o que muda por site com o caminho exato de cada arquivo e chave, e o que nunca se toca. |
| `MAPA-DA-OPERACAO.md` | O MAPA DA OPERACAO — o documento de quem RECEBE este pacote para operar ou para construir o proprio implantador: quais documentos existem e o que cada um responde, as tres pecas e qual delas e renomeada, o fluxo executavel de ponta a ponta, o que se publica no catalogo e com que nome, os erros que um agente novo comete e as fronteiras. Viaja no pacote desde a 2.1.0 (entrega.documentacao). |
| `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md` | AS INSTRUCOES PARA CONSTRUIR UM IMPLANTADOR a partir deste template — o documento que outro agente le antes de escrever a primeira linha. Manda ler os documentos de DENTRO deste zip e o pacote do plugin Base Site Core Fator3 (INSTRUCOES-DO-PLUGIN.md dentro do zip publicado, e a habilidade f3base/como-usar), e seguir as regras do plugin na construcao do tema e das paginas, porque o plugin e o pacote essencial que sempre e instalado junto. Viaja no pacote desde a 2.1.0 (entrega.documentacao). |
| `config/decisoes.tsv` | CATALOGO das decisoes do pacote: valor com uma resposta certa nao vira chave de configuracao — vira linha aqui, com o motivo que a sustenta escrito ao lado. Tres colunas: chave pontilhada, valor em JSON e motivo, que diz o que aconteceria se o valor fosse outro. Produtor unico: F3Base_Imp_Decisoes. |
| `config/projeto.json` | ARQUIVO DO PROJETO: o UNICO que o operador abre. Cada campo aqui passa nas duas metades da regra 29 — existe projeto legitimo com resposta diferente, e o valor nao e derivavel. Nasce vazio, salvo onde o template tem valor obviamente certo para o contexto dele, e o $comment do schema diz o que preencher e ONDE OBTER. Produtor unico: F3Base_Imp_Projeto. |
| `config/projeto.schema.json` | Schema de validacao do arquivo do projeto, com um $comment por campo dizendo o que preencher e onde obter o valor. Validado pelo MESMO validador de config/site.json, apontado para outro schema: um segundo validador seria um segundo conjunto de regras divergindo do primeiro. |
| `config/site.json` | Arquivo do CONTEUDO e das referencias internas: o que o pacote publica, como os objetos se apontam e a identidade tecnica do pacote renomeado. O que o operador decide mora em config/projeto.json; valor com uma resposta certa mora em config/decisoes.tsv, com o motivo ao lado; fato da historia do pacote mora em config/releases-suportadas.tsv. Fonte do estado desejado gerenciado. |
| `config/site.schema.json` | Schema de validação do arquivo de configuração; toda chave declarada aqui existe no site.json e tem consumidor provado. |
| `config/releases-suportadas.tsv` | CATALOGO das origens de release suportadas pelo contrato de caminho: de qual versao instalada este implantador sabe subir, com a determinacao que sustenta cada linha. E pergunta sobre o PACOTE, nao sobre o site — nenhum projeto legitimo tem resposta diferente —, e por isso saiu do arquivo que o operador abre. Produtor unico do lado do runtime: F3Base_Imp_Preflight::releases_suportadas(). |
| `content/pages/arquitetura.html` | Conteúdo editorial da página de arquitetura (ref arquitetura): matriz de alocação, lockdown do theme.json, menu como objeto e onde mora o conteúdo. |
| `content/pages/contato.html` | Conteúdo editorial da página de contato (ref contato): CTA de WhatsApp no contrato de DOM do site-core e o que acontece no clique. |
| `content/pages/home.html` | Conteúdo editorial da página inicial (ref home): o que é o método, as três peças e a ordem do comando único. |
| `content/pages/manutencao.html` | Conteúdo editorial da página de manutenção (ref manutencao): canal MCP em dois plugins, risco aceito, protocolo do ajuste e cadência. |
| `content/pages/privacidade.html` | Conteúdo editorial da política de privacidade (ref privacidade), declarada para produção: qualificação do controlador interpolada da configuração, as duas redações do encarregado em blocos que se excluem, finalidades, base legal, retenção, fornecedores e direitos. |
| `content/pages/verificacao.html` | Conteúdo editorial da página de verificação (ref verificacao): teto e piso, estados fechados, classe de evidência e fase, e o instrumento que mente. |
| `content/posts/o-artefato-decide-o-registro-e-diagnostico.html` | Conteúdo editorial de post: o artefato decide, o registro é diagnóstico, e a ordem gravar, reler e só então registrar. |
| `content/posts/por-que-checagem-que-nunca-falhou-nao-e-evidencia.html` | Conteúdo editorial de post: por que o piso separa uma checagem correta de uma checagem cega. |
| `partilhado/includes/class-f3base-vocabulario.php` | VOCABULARIO compartilhado pelos dois runtimes: o CONJUNTO de valores que existem — modelos de atribuicao, modos da lista do llms.txt, politicas de frame, COOP, referrer e permissoes, e o slug do plugin de cada papel. Sem pai e sem dependencia, como F3Base_Chaves_Seo: o site-core a carrega pelo autoload dele e o implantador por require_once da copia de origem. Quem ESCOLHE entre os valores e config/decisoes.tsv; decisoes.fonte_unica cruza os dois, e e o cruzamento que torna duas fontes seguras. |
| `implantador-base.php` | Bootstrap do implantador: cabeçalho de plugin, constantes de identidade e caminho, autoload e registro dos hooks. |
| `includes/assets/implantador.css` | Estilo da tela orquestradora e da tela de resultado, em arquivo próprio: a resposta do admin-post.php é um documento que não herda o chrome do wp-admin. |
| `includes/assets/implantador.js` | Cliente da tela orquestradora, em arquivo próprio e nunca em heredoc: lê a resposta como texto e acha o JSON no fim de um corpo HTML+JSON. |
| `includes/class-f3base-imp-admin.php` | Superfície de administração: tela orquestradora e resultado renderizados INLINE na resposta do admin-post.php, nunca por redirect — a página do menu deixa de existir no instante do sucesso. |
| `includes/class-f3base-imp-config.php` | Leitura e validação do arquivo único de configuração. |
| `includes/class-f3base-imp-conteudo.php` | Conteúdo gerenciado: páginas, posts, categorias e mídia. |
| `includes/class-f3base-imp-decisoes.php` | Produtor UNICO do catalogo de decisoes: le config/decisoes.tsv e devolve valor, campo e bloco. Nenhum outro lugar da arvore le o arquivo, e nenhum repete o valor de uma decisao como literal. |
| `includes/class-f3base-imp-entrega.php` | Checagens dos nove entregáveis (a documentação entrou na 2.1.0) e gate da autodesativação: entregável em BLOCKED impede o implantador de sair do ar. |
| `includes/class-f3base-imp-fases.php` | Regra de FASE, num lugar só: aplicabilidade (fase declarada fora da fase corrente é N/A, nunca BLOCKED) e o registro do que cada fase espera, com a fase nunca executada como achado. Roda em dois runtimes que não se enxergam — o encerramento do implantador e a suíte, por suite/lib/sonda-fases.php — e por isso não traduz, não imprime e não usa WordPress. |
| `includes/class-f3base-imp-formulario.php` | O FORMULARIO do site, criado de verdade: cria o formulario no Contact Form 7 com os campos declarados, cria a pagina de confirmacao e poe o shortcode na pagina. O destinatario e derivado do e-mail administrativo; a caixa declarada e um destinatario diferente quando alguem quiser um. Antes desta classe o regime cf7-email so emitia linha de relatorio e nenhum formulario era criado. |
| `includes/class-f3base-imp-gravador.php` | Ponto único de escrita. |
| `includes/class-f3base-imp-journal.php` | Journal de mutações com preimagem, pós-imagem e operação inversa. |
| `includes/class-f3base-imp-lotes.php` | Orquestrador em lotes: checkpoint depois da leitura de volta, lock com heartbeat e fencing token, e resposta JSON bufferizada com shutdown armado antes do trabalho. |
| `includes/class-f3base-imp-limpeza.php` | LIMPEZA DOS PADROES da instalacao limpa — 2.1.0: remove, pela lista declarada em config/decisoes.tsv (limpeza.temas_padrao, limpeza.plugins_padrao), os temas de fabrica e os plugins de fabrica que o pacote nao usa, com leitura de volta e journal declarado irreversivel. A regra pura (plano) nunca remove o tema ativo nem o pai dele, desativa plugin ativo pela API do nucleo antes de remover, e so remove o que a lista declara. Medido: a implantacao de 2026-09-07 entregou o site com Twenty Twenty-Tres/Quatro/Cinco, Akismet e Hello Dolly no lugar. |
| `includes/class-f3base-imp-navegacao.php` | Navegação como entidade, não como markup. |
| `includes/class-f3base-imp-plano.php` | Grafo de dependências do plano: grupos declarados, tabela de dependências reais, resolução para ids concretos e fecho transitivo da suspensão. Função pura, sem WordPress. |
| `includes/class-f3base-imp-plugins.php` | Instalação de tema, `site-core` e plugins. |
| `includes/class-f3base-imp-preflight.php` | Preflight: tudo que se mede ANTES de qualquer mutação. |
| `includes/class-f3base-imp-projeto.php` | Produtor UNICO do arquivo do projeto: carrega, valida por F3Base_Imp_Config::validar_contra e devolve valor e lista. Guarda tambem o veredito das TRES FACES do fato juridico, medidas como conjunto. |
| `includes/class-f3base-imp-residencia.php` | Produtor UNICO da resposta "em QUE arquivo esta chave mora": cruza o que cada leitor declara — F3Base_Imp_Projeto e F3Base_Imp_Config — e devolve o arquivo, ou nenhum quando nao da para derivar. Nem o nome dos arquivos e escrito ali: ele vem da constante ARQUIVO de cada leitor. Existe porque o nome do arquivo estava DIGITADO dentro das mensagens, e a guarda da politica mandava preencher contato.controlador em config/site.json, onde essa chave nao existe. |
| `includes/class-f3base-imp-relatorio.php` | Relatório em estados fechados. |
| `includes/class-f3base-imp-seo.php` | Adaptador do plugin de SEO. |
| `partilhado/dados/emissores-conhecidos.tsv` | Declaração ÚNICA dos emissores de tag conhecidos, com a condição de emissão medida quando há option conhecida. É DICA para o preflight classificar cedo, nunca o gate: quem decide é a contagem no HTML publicado, em tracking.emissor_unico. Viaja dentro do site-core e é lida também pelo implantador, da cópia de origem. |
| `partilhado/includes/class-f3base-emissores.php` | Regra COMPARTILHADA do segundo emissor: lê a declaração e devolve o veredito de emissão (leitor, concorrente, nao-medido). Sem pai e sem dependência de propósito — o preflight do implantador a carrega do arquivo de origem, porque ele roda antes de o site-core existir na instalação. |
| `partilhado/includes/class-f3base-censo-demonstrativo.php` | Regra COMPARTILHADA do censo de conteudo demonstrativo: conta, NO BANCO, as paginas publicadas que ainda carregam a marca do template e as NOMEIA. Sem pai e sem dependencia de proposito — o implantador a carrega do arquivo de origem, porque o modo somente-relatorio precisa dela antes de o site-core existir na instalacao, e duas copias da regra divergiriam na primeira condicao acrescentada. |
| `partilhado/includes/class-f3base-chaves-seo.php` | VOCABULARIO do plugin de SEO — os nomes de meta e de option do fornecedor, num lugar so. Sem pai e sem dependencia de proposito: o site-core o carrega pelo autoload e o implantador pela copia de origem, porque um ESCREVE a meta de cada conteudo e o outro a LE, e quem escreve e quem le a mesma chave precisam da mesma fonte. |
| `partilhado/VENDORIZADO.tsv` | DECLARACAO da copia vendorizada: caminho a caminho, de onde no zip do plugin cada arquivo de partilhado/ vem e por que o implantador precisa dele antes de o plugin existir na instalacao. Declaracao, nao lock: o digesto nao e digitado — quem confere e a comparacao byte a byte com a reserva, a cada rodada (pacote.copia_vendorizada_confere). Arquivo em partilhado/ fora desta tabela e achado. |
| `partilhado/dados/contrato-de-nomes.tsv` | CONTRATO DE NOMES DO PLUGIN, copia vendorizada conferida por hash: as grafias que a renomeacao de prefixo NAO reescreve — options, tabelas, eventos, namespace REST, classes compartilhadas, hook da cadencia e o prefixo da classe que marca secao medida. Lido por ferramentas/nomes-preservados.php sem WordPress nenhum e por renomeacao.contrato_de_nomes_completo; o dono e o repositorio do plugin. |
| `suite/checagens/a11y.php` | Contraste recalculado da paleta do theme.json pela fórmula de luminância relativa da WCAG, sobre os pares em uso. |
| `suite/checagens/bloqueadas.php` | Tabela das checagens que este ambiente não pode medir e das condicionais não instanciadas. Cada entrada declara a FASE em que ela É medida, e é a fase que decide o estado: fora da fase corrente fecha N/A nomeando aquela fase, na fase corrente fecha BLOCKED com a pré-condição que falta. Condicional não instanciada fecha N/A com a condição declarada. |
| `suite/checagens/conteudo.php` | Checagens do conteúdo publicado: só referência a preset, e hierarquia de headings. |
| `suite/checagens/copy.php` | Contrato de copy: frases obrigatórias nas páginas declaradas e frases aposentadas em lugar nenhum do pacote. |
| `suite/checagens/entrega.php` | Os nove entregáveis, derivados da configuração (a documentação entrou na 2.1.0): ausência fecha BLOCKED com o nome do arquivo que falta. |
| `suite/checagens/estatica.php` | Checagens estáticas: lint de PHP, JSON e JS, balanceamento de blocos, e os detectores de escrita única, version_compare, condição literal, código em string, chave sem consumidor e placeholder. |
| `suite/checagens/funcional.php` | Ponte para as sondas funcionais em subprocesso e para a sonda de JavaScript. |
| `suite/checagens/js.mjs` | Sonda de JavaScript sob o Node de verdade: `node --check` do pacote e o extrator de resposta do cliente, com teto e piso. |
| `suite/checagens/meta.php` | Cruzamentos da própria suíte: manifesto bidirecional e mapa de armadilhas, ambos calculados dos rótulos efetivamente emitidos. |
| `suite/checagens/tema.php` | Checagens do tema: zero com unidade, preset ocioso, preset inexistente, cor literal, wp:html declarado, layout do main e versão dos assets. |
| `suite/afirmacoes.tsv` | Elo DECLARADO entre uma frase de documento entregavel e o fato medido que a sustenta: documento, frase exata, regra e esperado. E o unico lugar em que uma afirmacao de COMPORTAMENTO fica amarrada ao codigo: frase que sai do documento e fato que deixa de bater reprovam os dois. |
| `suite/armadilhas.tsv` | Mapa de armadilha para checagem. Armadilha sem checagem é pendência declarada; mapeamento sem piso fecha BLOCKED. |
| `suite/inventario.tsv` | Inventário de caminho para papel: a allow-list de CAMINHOS do empacotamento. Arquivo fora dela aborta o build com o nome. |
| `suite/chaves-removidas.tsv` | Chaves de configuracao REMOVIDAS, com os tokens que nao podem sobreviver, a release que as removeu e os arquivos onde a remocao e narrada. Remover a chave do config e a parte facil: o schema que continua exigindo-a, o consumidor orfao que le vazio em silencio e o documento que ensina a preencher o que nao existe mais sao o resto, e e estatica.sem_residuo_de_chave_removida que os cobra. |
| `suite/casos-de-emissor.tsv` | Tabela DECLARADA de casos do discriminante de emissor, com a superfície medida, os slots e o veredito esperado de cada um. Ela existe porque a árvore deste pacote não publica HTML servido: sem ela os ramos do emissor de fora, do slot vazio e do caminho do container nunca seriam exercitados, e tracking.emissor_unico_discrimina passaria por não ter contra o que falhar. Tabela ausente é achado, nunca silêncio. |
| `suite/pisos-em-sonda.tsv` | Declaração das checagens cujo PISO mora dentro da própria sonda, e não numa fixture em disco: o caso negativo delas é um mutante do próprio pacote. A declaração não absolve — estatica.piso_em_sonda_declarado confere que a sonda existe, menciona a checagem e traz os dois ramos. |
| `suite/excluidas.tsv` | TODA CHECAGEM DA 1.7.4 QUE NAO E MAIS EMITIDA por esta suite, com categoria fechada (plugin, substituida, instrumento) e motivo em uma frase. Espelho do excluidas.tsv do repositorio do plugin. Conferido por excluidas.declaradas: linha sobre checagem emitida e declaracao velha; checagem que some sem linha aqui e cobertura que encolheu em silencio. |
| `suite/manifesto.tsv` | Manifesto de verificação: requisito para checagem, ambiente e classe de evidência. Base do cruzamento bidirecional. |
| `suite/lib/documentos.php` | Regiões GERADAS dos documentos entregáveis (README, MANIFESTO, MEMORIA-DECISOES) e o detector que as guarda: número em documento entregável sai de leitura de disco no empacotamento, nunca digitado, e o que não pode ser gerado sai como pendência nomeada. |
| `suite/lib/empacotar.php` | Empacotamento: allow-list de caminhos, montagem dos zips embutidos e do bundle, lock de sha256 e a checagem de artefato mais novo que a fonte. |
| `suite/lib/executar.php` | Runner do comando único: empacota, roda todas as checagens, imprime o resumo por estado e devolve código de saída diferente de zero quando há FALHA. |
| `suite/lib/piso.php` | Runner do piso: roda a MESMA função de cada checagem contra a fixture negativa (precisa acusar) e a positiva (precisa calar). |
| `suite/lib/sonda-hash.php` | Sonda do hash do pacote em subprocesso: não calcula nada, chama F3Base_Imp_Entrega::hash_do_pacote() — a MESMA função que o host executa ao conferir a amarração da rodada limpa. |
| `suite/lib/sonda-fases.php` | Sonda das fases em subprocesso: não decide nada, chama F3Base_Imp_Fases — a MESMA classe que o host executa no encerramento — para a aplicabilidade por fase e para o registro do que cada fase espera. |
| `suite/lib/sonda-serie.php` | Sonda da série de cópias preservadas em subprocesso: carrega a classe de plugins da raiz apontada e chama a MESMA serie_do_nome() que a poda usa no site, para que o piso possa exercitá-la contra o corte ingênuo e contra o corrigido. |
| `suite/lib/regra.php` | Regra compartilhada, arquivo ÚNICO: `estado()` com o contador dentro, as listas fechadas de estado, classe e fase, a classificação de erro por origem e os utilitários de varredura. |
| `suite/lib/render-pattern.php` | Renderizador de pattern fora do WordPress, em subprocesso: o defeito de comentário `wp:` aparece na saída, não no arquivo cru. |
| `suite/lib/sonda-funcional.php` | Sonda funcional em subprocesso: validação do config com os mutantes, tabela do merge de três vias, casamento de waiver e sanitização de dump. |
| `suite/lib/sonda-gravador.php` | Sonda do gravador em subprocesso: equivalência de leitura de volta e impressão de procedência, com teto e piso. |
| `suite/lib/sonda-instalacao.php` | Sonda da INSTALAÇÃO LIMPA em subprocesso: monta um WordPress de mentira cujo cache memoriza o negativo, com o alvo inexistente e a consulta prévia na mesma requisição, e roda o aplicar_tema() e o aplicar_site_core() REAIS contra ele — com a invalidação desligada a leitura de volta tem de continuar cega, e com ela ligada tem de enxergar o artefato. |
| `suite/lib/sonda-tema.php` | Sonda do TEMA e do CTA em subprocesso: monta um processador de HTML de mentira — que a sonda do site-core precisa NÃO ter — e roda o link da política e a promoção do CTA REAIS contra ele, com o piso plantado dentro da própria bancada. |
| `suite/verificar.sh` | COMANDO ÚNICO: empacota, verifica e resume. Sem argumento reprova; artefato ausente fecha BLOCKED nomeado; subcomando `piso` roda as fixtures. |
| `suite/fases.json` | Registro DURÁVEL de fases, gravado SÓ pelo comando único: quando cada fase fechada rodou pela última vez, medida por linha que fechou OK, FALHA ou WARN naquela fase. BLOCKED e N/A não contam — o primeiro diz que a medição não pôde acontecer e o segundo que ela não se aplicava. É o contrapeso da regra de aplicabilidade: sem ele, checagem em N/A por fase ausente ficaria em N/A para sempre e o silêncio viraria aprovação por omissão. Ele NÃO é injetado no bundle e NÃO é excluído do hash do pacote, ao contrário do selo: quem o lê é a rodada seguinte, na mesma árvore. |
| `suite/rodada.json` | Registro DA rodada, gravado SÓ pelo comando único (etapa do selo): veredito declarado, contagem de FALHA, pendências de fase NOMEADAS, hash do pacote que a rodada mediu, resumo por estado com os nomes, contagem de detectores do piso e carimbo de tempo. É a evidência IMPORTADA que o host confere contra o hash do pacote instalado E cujo veredito ele LÊ; ele fica fora da soma que declara, e é isso que o deixa morar dentro do pacote que descreve. Rodada com FALHA não sela, e o registro anterior é apagado: registro que sobrevive à reprovação seria um selo aprovando o que a rodada reprovou. |
| `fontes/tema/CONTRASTE.md` | Prova calculada do sistema de cor e de fonte: razões de contraste, alvo mínimo e o contrato de nomes entre tema e site-core. |
| `fontes/tema/functions.php` | Funções do tema: suportes declarados, publicação do CSS com a versão certa, injeção do ref da navegação, carimbo do CTA de contato e remoção de peso do núcleo. |
| `fontes/tema/parts/footer.html` | Parte de template do rodapé: navegação secundária, link da política e o controle de consentimento. Uma das duas exceções de wp:html declaradas. |
| `fontes/tema/parts/header.html` | Parte de template do cabeçalho: link de pular, logo, título, navegação e CTA. Uma das duas exceções de wp:html declaradas. |
| `fontes/tema/patterns/cta-whatsapp.php` | Pattern da faixa de conversão com o botão que o site-core promove a conversa de WhatsApp. |
| `fontes/tema/patterns/faq.php` | Pattern de perguntas frequentes em blocos de detalhes nativos. |
| `fontes/tema/patterns/hero.php` | Pattern de abertura de página, em faixa escura de largura total. |
| `fontes/tema/patterns/secao-cartoes.php` | Pattern de seção com três cartões lado a lado. |
| `fontes/tema/patterns/secao-texto.php` | Pattern de texto corrido com título, parágrafos e lista. |
| `fontes/tema/style.css` | Cabeçalho do tema (fonte única da versão) e as regras que o theme.json não expressa, cada uma com o motivo declarado. |
| `fontes/tema/templates/404.html` | Template de página não encontrada. |
| `fontes/tema/templates/archive.html` | Template de arquivo de termo e de data. |
| `fontes/tema/templates/front-page.html` | Template da página inicial, com a faixa de abertura e o conteúdo da página. |
| `fontes/tema/templates/index.html` | Template base do índice de posts. |
| `fontes/tema/templates/page.html` | Template de página: título em H1, e o conteúdo começando em H2. |
| `fontes/tema/templates/landing.html` | Template de landing de campanha: sem navegação, cabeçalho mínimo com logotipo, CTA e rodapé com o controle de consentimento. |
| `fontes/tema/templates/search.html` | Template de resultados de busca. |
| `fontes/tema/templates/single.html` | Template de post: título, data, categorias, conteúdo e navegação entre posts. |
| `fontes/tema/theme.json` | Coração do tema: paleta, escala tipográfica, escala de espaçamento, larguras, estilos por bloco e o lockdown de valores avulsos. |
| `ferramentas/renomear-prefixo.sh` | COMANDO da renomeação de prefixo: contrato de invocação, recusa sem argumento e pré-condição de ambiente nomeada; delega a reescrita ao PHP do pacote. |
| `ferramentas/renomear-prefixo.php` | Motor da renomeação: recusa o prefixo inválido antes de qualquer escrita, reescreve conteúdo e caminho pelas grafias declaradas, pula as exceções declaradas e remove a saída de build do prefixo antigo. |
| `ferramentas/prefixo-do-template.tsv` | Registro do prefixo de ORIGEM nas três grafias — técnica, abreviada e de exibição. Nunca reescrito: é dele que vêm a idempotência da ferramenta e o alvo do detector de resíduo. |
| `ferramentas/prefixos-recusados.tsv` | Prefixos que a renomeação recusa, com a regra (igual ou começa-com) e o motivo de cada um; declarados em arquivo para que acrescentar um não seja editar código. |
| `ferramentas/excecoes-de-prefixo.tsv` | Onde o prefixo do template pode sobreviver depois da renomeação, arquivo a arquivo com o motivo; lida pela ferramenta e pelo detector, para que a exceção não exista só de um lado. |
| `ferramentas/classificacao-config.tsv` | CLASSIFICACAO auditavel das folhas de config/site.json por natureza — operador, decisao, interno, conteudo — com a justificativa de cada uma em uma linha. E o registro que torna a reforma da configuracao decisao medida em vez de opiniao: cada chave passa por um teste de duas partes, e a que falha nele nao ganha um padrao melhor, deixa de existir. |
| `assets/logo.png` | midia embarcada: marca do site 512x512 com fundo transparente, nas cores inverso/primaria/base do theme.json; papel custom_logo, porque custom_logo exige anexo na biblioteca e a biblioteca recusa SVG por padrao |
| `assets/logo.svg` | midia embarcada: a MESMA marca em vetor, sem cor literal (currentColor), papel marca_inline: servida pelo tema no proprio markup e nunca enviada para a biblioteca de midia |
| `assets/favicon.png` | midia embarcada: icone do site 512x512, papel site_icon |
| `assets/social.png` | midia embarcada: imagem social padrao 1200x630, papel og_default_image |
| `assets/plugins/LEIA-ME.txt` | instrucao do slot de zips embutidos |
| `assets/plugins/base-site-core-fator3-1.0.0.zip` | A RESERVA DO PLUGIN DO SITE: o zip publicado no catalogo, copiado para a arvore como entrada de build. E de dentro dele que a suite le tudo o que precisa do plugin — catalogo de options, segredos, prefixo de secao, marcas do carregador de tags, cliente de tracking — e e ele que o implantador instala quando a URL do catalogo nao responde. Conferido por sha256 contra plugins.instalaveis.<n>.sha256; trocado a cada release do plugin, junto com o sha256 declarado e a copia de partilhado/. |
| `suite/lib/sonda-renomeacao.php` | Sonda da RENOMEACAO em subprocesso: copia o pacote, renomeia para um prefixo qualquer e mede o que so aparece no site derivado — nenhum arquivo do plugin mudou (nem conteudo nem nome), a secao continua sendo medida depois de o tema e o conteudo trocarem de prefixo, e a lista de grafias preservadas vem do CODIGO do plugin e nunca da prosa dele (uma quarta copia, com uma grafia plantada so em comentario e outra so em codigo, prova que a primeira e renomeada e a segunda fica). Os pisos sao DOIS mutantes do proprio pacote, porque os dois defeitos sao diferentes: sem as exclusoes de caminho o plugin vira fork, e sem o contrato de nomes o tema carimba acme-secao- enquanto o plugin procura f3base-secao-. |
| `suite/lib/sonda-renomeacao-secao.mjs` | Harness do coletor de secao sob o Node: EXTRAI nomeDaSecao() de f3base-tracking.js e a executa contra as classes que o markup renomeado carimba. Existe para que a sonda de renomeacao nao escreva uma segunda implementacao da regra do coletor — uma copia aprovaria o pacote pelo que a suite acha que o cliente faz. |
| `suite/lib/sonda-bundle.php` | Sonda do BUNDLE em subprocesso: le a lista de entradas do zip montado e a reserva na arvore e mede tres coisas — a fonte do plugin nao viaja e a reserva versionada viaja (pacote.plugin_so_como_zip); a reserva E o zip publicado, com sha256 igual ao do catalogo, versao do nome igual a do cabecalho de dentro, pasta de topo esperada e copia no bundle byte a byte (pacote.reserva_confere_com_o_catalogo); e cada arquivo de partilhado/ e byte a byte a entrada correspondente do zip, com a lista declarada em VENDORIZADO.tsv nos dois sentidos (pacote.copia_vendorizada_confere). Piso por entrada mutante. |
| `ferramentas/nomes-preservados.php` | REGRA COMPARTILHADA do que a renomeacao de prefixo NAO reescreve, arquivo unico: as grafias declaradas no contrato de nomes do plugin MAIS as que o CODIGO do plugin usa, derivadas de dentro da reserva e de partilhado/ com a prosa cortada (comentario PHP, JS e CSS, linha de cerquilha de TSV, Markdown) — nome que o plugin so cita num comentario nao e preservado, e e renomeacao.preservados_so_do_codigo quem o prova —, MAIS os nomes de arquivo das excecoes de caminho. Lida pela ferramenta (que mascara antes de substituir) e por estatica.sem_residuo_de_prefixo (que nao acusa depois) — duas copias divergiriam na primeira linha acrescentada, e a divergencia apareceria como um pacote renomeado que passa na ferramenta e reprova no detector. |
| `suite/casos-de-emissor/` (prefixo) | Amostras de HTML dos casos declarados acima, uma por linha da tabela: o que a rota de origem devolve e o que o DOM tem depois do JavaScript, com e sem a marca do site-core. Fora do escopo das varreduras de conteúdo publicável, por construção. |
| `suite/fixtures/` (prefixo) | Fixtures do piso: uma árvore negativa que reproduz o defeito e uma positiva que preserva o correto, por detector. Fora do escopo das varreduras de pacote, por construção. |
| `dist/` (prefixo) | Saída do empacotamento, gerada pelo comando único: zips embutidos, bundle e lock. Não pertence ao pacote que o operador faz upload. |
| `assets/plugins/` (prefixo) | slot declarado: zip de plugin que o operador embute para dispensar rede no deploy (<slug>.zip, sem numero, e ele vence), e a RESERVA versionada do plugin do site — <slug>-<versao>.zip —, que desde a 2.0.0 e ENTRADA de build: o zip publicado no catalogo, copiado para a arvore byte a byte e conferido por sha256 contra plugins.instalaveis.<n>.sha256 (pacote.reserva_confere_com_o_catalogo). Exatamente um zip versionado; a versao no nome e a que o host le. A resolucao de origem e F3Base_Imp_Plugins::artefato_do_papel(), fonte unica. |
<!-- gerado:fim=inventario -->

### `dist/`

Saída do empacotamento, gerada pelo comando único: **um artefato** — o bundle da
identidade desta release — mais `dist/lock.tsv`. **Não pertence ao pacote que o operador
faz upload** e não viaja dentro dele.

Não há zip de tema aqui: nenhum caminho de instalação o leria — quem instala o tema lê
`fontes/tema/`, que viaja no bundle, ou o zip que o operador embute no slot
`assets/plugins/<slug>-tema.zip`. **E desde a 2.0.0 não há zip de plugin aqui tampouco**: o
implantador deixou de CONSTRUIR o plugin na 1.7.0 e deixou de carregar a fonte dele agora,
então não sobrou o que montar. A reserva `assets/plugins/base-site-core-fator3-<versão>.zip`
mudou de lado na mesma release: ela é ENTRADA de build, não saída — o zip publicado no
catálogo, copiado byte a byte para a árvore, dentro do inventário, dentro do lock e dentro
do hash do pacote. Ela traz o número no nome porque é dele que a versão é lida: sem a fonte
na árvore, o cabeçalho do plugin não chega ao site por nenhum outro caminho.

Tamanho e sha256 de cada peça moram em `dist/lock.tsv`, que a primeira etapa do comando
único grava e a etapa do selo regrava — copiar aqueles números para cá criaria a segunda
fonte que este manifesto inteiro existe para impedir.

#### A reprodutibilidade do zip do plugin mudou de repositório, e o que ficou aqui é o CONTRATO

**Este manifesto não afirma mais nada sobre como aquele zip é montado.** Até a 1.7.4 ele
afirmava, e com mecanismo: época declarada por entrada e ordem de entradas declarada, as
duas medidas falhando antes — a mesma árvore empacotada em 05/09 e em 06/09 dava
`693ca754…` e `aeb40cad…`, e a mesma árvore no mesmo dia dava `693ca754…` num ext4 e
`855fabbb…` num tmpfs desta máquina. A razão de aquilo importar continua exatamente igual:
o zip é publicado num catálogo, o host compara digesto entre execuções, e republicar
amanhã um artefato de conteúdo idêntico faria toda implantação seguinte falhar acusando
**troca de artefato que não houve**. O que mudou é **quem monta**: na 2.0.0 quem monta,
sela e prova reprodutível é a suíte do repositório do plugin, em `pacote.zip_reprodutivel`.
Manter a prova aqui exigiria manter aqui a fonte que ela reconstrói, e é justamente essa
cópia que a 2.0.0 tirou.

**O que este manifesto declara como CONTRATO são três igualdades, e todas são digesto:**

1. **O `sha256` que o catálogo declara para o zip do plugin** — `config/decisoes.tsv`, em
   `plugins.instalaveis.<n>.sha256`. Ele é a linha que amarra o byte: a instalação por URL
   o confere antes de instalar, e o artefato LOCAL — slot do operador ou reserva — passa
   pela mesma conferência. Até a 1.7.4 ele **não existia**, e sem ele o host fixava o
   primeiro digesto observado e reprovava a release seguinte, publicada de propósito.
2. **A reserva na árvore é igual a ele.** `pacote.reserva_confere_com_o_catalogo` mede as
   cinco cláusulas que precisam concordar — digesto dos bytes, versão do nome contra versão
   do cabeçalho de dentro, pasta de topo contra `pasta_esperada`, cópia dentro do bundle
   byte a byte igual à da árvore, e zip com entradas legíveis.
3. **A cópia vendorizada é igual ao zip.** `pacote.copia_vendorizada_confere` compara cada
   arquivo de `partilhado/` com a entrada correspondente da reserva, e cobra
   `partilhado/VENDORIZADO.tsv` nos dois sentidos: arquivo sem declaração e declaração sem
   arquivo são achados.

A diferença entre isto e o que havia antes é o OBJETO: até a 1.7.4 a suíte comparava a
reserva com o zip que ela mesma acabara de montar — as duas batiam sempre, e nenhuma das
duas era o que o catálogo servia. Medido: a reserva dizia `1.0.1` e o catálogo publicava
`1.0.0`.

**O que continua mudando de um dia para o outro, e por quê.** O `hash do pacote` soma o
`sha256` de cada arquivo do corpo do bundle, e `suite/fases.json` está lá dentro com a data
em que cada fase rodou pela última vez. Esse número muda uma vez por dia — medido:
`c4f76e82…` na rodada em que o registro trazia `2026-09-06` e `c1c9a21a…` na primeira
rodada depois de o registro passar a trazer `2026-09-20`, com a árvore idêntica. **Isso
fica como está**: aquele registro responde *quando*, que é pergunta de calendário, e o hash
do pacote nunca é fixado contra um artefato REPUBLICADO — o host confere a árvore instalada
contra o `suite/rodada.json` que viajou dentro dela. Dentro do mesmo dia ele é estável, e
isso foi medido nesta release: **duas rodadas sobre a mesma árvore dão o mesmo hash de
pacote.**

<!-- gerado:inicio=fixtures -->
### Piso: um detector, duas árvores

Gerado de disco. Cada linha é um detector com fixture NEGATIVA — que reproduz o defeito e precisa ser
acusada — e POSITIVA — que preserva o caso correto e precisa ficar em silêncio.

| Detector | Arquivos de piso |
|---|---|
| `a11y.contraste` | 2 |
| `config.slug_declarado` | 2 |
| `conteudo.demonstrativo` | 4 |
| `conteudo.headings` | 4 |
| `conteudo.marca_demonstrativa` | 4 |
| `conteudo.sem_estilo_avulso` | 2 |
| `copy.contrato` | 6 |
| `decisoes.fonte_unica` | 8 |
| `doc.afirmacao_conferida` | 8 |
| `estatica.artefato_do_pacote_e_lido` | 4 |
| `estatica.carimbo_de_release_nos_documentos` | 16 |
| `estatica.contagem_com_nomes` | 4 |
| `estatica.conteudo_declara_secoes` | 4 |
| `estatica.destino_de_formulario_resolve` | 2 |
| `estatica.detector_chave_sem_consumidor` | 4 |
| `estatica.detector_codigo_em_string` | 2 |
| `estatica.detector_condicao_literal` | 2 |
| `estatica.detector_escrita_unica` | 5 |
| `estatica.detector_placeholder` | 2 |
| `estatica.detector_version_compare` | 2 |
| `estatica.estados_fechados` | 2 |
| `estatica.gate_de_fase_do_metadado` | 2 |
| `estatica.gate_de_fase_sem_ramo_de_falha` | 3 |
| `estatica.gate_fonte_unica` | 9 |
| `estatica.hidden_governa_visibilidade` | 4 |
| `estatica.identidade_do_implantador` | 4 |
| `estatica.js_lint` | 2 |
| `estatica.json_valido` | 2 |
| `estatica.llms_proprio_sem_concorrente` | 2 |
| `estatica.llms_so_pagina_publicada` | 6 |
| `estatica.option_fonte_unica` | 6 |
| `estatica.option_gravada_sem_leitor` | 4 |
| `estatica.pagina_status_fonte_unica` | 4 |
| `estatica.php_lint` | 2 |
| `estatica.piso_em_sonda_declarado` | 5 |
| `estatica.plano_dependencias` | 2 |
| `estatica.politica_privacidade_fonte_unica` | 4 |
| `estatica.residencia_de_chave_derivada` | 12 |
| `estatica.resposta_de_lote_nomeada` | 2 |
| `estatica.segredo_fora_da_configuracao` | 8 |
| `estatica.sem_recusa_de_escrita_do_agente` | 2 |
| `estatica.sem_residuo_de_chave_removida` | 10 |
| `estatica.sem_residuo_de_prefixo` | 10 |
| `estatica.simbolos_resolvem` | 2 |
| `estatica.troca_invalida_cache` | 2 |
| `estatica.unidade_reflete_internas` | 6 |
| `estatica.warn_tem_ramo_adverso` | 2 |
| `estatica.wp_comentarios_balanceados` | 4 |
| `mcp.fronteira_do_validador` | 7 |
| `pacote.allow_list` | 5 |
| `pacote.backup_sempre_oculto` | 2 |
| `pacote.build_fresco` | 4 |
| `pacote.sem_cabecalho_de_plugin_aninhado` | 6 |
| `plugins.serie_de_backup_normalizada` | 2 |
| `release.declara_a_anterior` | 4 |
| `tela.fala_portugues_comum` | 2 |
| `tema.landing_sem_navegacao` | 4 |
| `tema.main_layout_default` | 2 |
| `tema.preset_inexistente` | 2 |
| `tema.preset_ocioso` | 2 |
| `tema.sem_cor_literal` | 4 |
| `tema.versao_assets` | 4 |
| `tema.wp_html_declarado` | 6 |
| `tema.zero_com_unidade` | 2 |
| `tracking.emissor_unico_discrimina` | 8 |
<!-- gerado:fim=fixtures -->

## Este pacote é um template, e o que isso muda no manifesto

O pacote é o **template de criação de sites** da operação: cada site
nasce de uma cópia dele, renomeada por `ferramentas/renomear-prefixo.sh` para o próprio
prefixo técnico. A identidade única acima continua sendo a da RELEASE do template; o site
derivado herda a release e troca o prefixo, e é `estatica.sem_residuo_de_prefixo` que
garante que a troca foi inteira — nenhuma grafia do prefixo de origem sobrevive fora da
lista declarada em `ferramentas/excecoes-de-prefixo.tsv`.

Uma exceção dessa lista merece estar aqui, porque é uma decisão sobre a verdade dos
documentos e não sobre código: **`MEMORIA-DECISOES.md` não é reescrito**. Ele narra defeitos
medidos citando diretórios que existiram em sites reais, e trocar o prefixo neles inventaria
um passado que não aconteceu. Ele viaja com o pacote como história herdada, atribuída a quem
a produziu. O procedimento completo está em `TEMPLATE.md`.

## Hash e checksum: o que é nosso e o que é fato observado

A fronteira é simples e não admite meio-termo: **artefato nosso tem checksum; artefato
de terceiro tem fato observado.** Confundir os dois produz um manifesto que parece
rigoroso e não prova nada.

### Artefatos nossos — entram no lock, com versão e checksum

São os que viajam dentro do bundle e cujo conteúdo tem DONO declarado. Desde a 2.0.0 o
dono nem sempre é este repositório: as duas linhas do PLUGIN são cópias de um artefato
publicado por outro, e para elas o lock registra o byte que viajou enquanto o CONTRATO — o
que diz que aquele byte é o certo — mora no catálogo.

| Artefato | O que o lock registra |
|---|---|
| Implantador (`implantador-base.php`, `includes/`, `config/`, `content/`, `assets/`, `suite/`) | `sha256` de cada caminho |
| Tema `f3base` (`fontes/tema/`) | `sha256` de cada caminho — é o diretório que a instalação lê |
| A RESERVA do plugin (`assets/plugins/base-site-core-fator3-<versão>.zip`) | `sha256` do artefato, pela linha dele na árvore. A FONTE do plugin não está mais aqui: o que está é uma CÓPIA de um artefato publicado, e o contrato dela não é este lock — é o `sha256` que `config/decisoes.tsv` declara para o zip do catálogo. O lock registra que aquele byte é o que viajou nesta release; quem diz que ele é o CERTO é o catálogo, e quem cruza os dois é `pacote.reserva_confere_com_o_catalogo` |
| A CÓPIA VENDORIZADA (`partilhado/`) | `sha256` de cada caminho. São quatro classes de regra e duas tabelas que o implantador lê ANTES de o plugin existir na instalação; o dono delas é o repositório do plugin, a lista está em `partilhado/VENDORIZADO.tsv`, e `pacote.copia_vendorizada_confere` exige que cada uma seja, byte a byte, a entrada correspondente da reserva |
| Os três `.md` da raiz | `sha256` de cada um, calculado depois de o arquivo estar fechado |

**O autoteste do canal é despachado de verdade.** A unidade `mcp` DESPACHA
`files/selftest` — pela Abilities API quando ela existe, pelo objeto da habilidade
(`wp_get_ability()` e `WP_Ability::execute()`), e pelo servidor REST interno quando há
namespace — e leva o resultado estruturado para a linha
`mcp.autoteste`. Autoteste que devolve falha REPROVA a entrega; ausência da rota fecha
BLOCKED, nunca OK — e a PRESENÇA da rota sai da UNIÃO das duas fontes, a
mesma que a unidade já mediu: rota registrada só como habilidade da Abilities API é rota
presente, e namespace REST vazio significa "sem via REST, despache pela habilidade". A
recusa a credencial não autorizada NÃO é mensurável de dentro do WordPress rodando como
administrador, e por isso sai numa linha de fase `campo` em
`mcp.autoteste_recusa_credencial`, nomeando o que falta: quem produz essa evidência é o
requisitante externo, e não o host.

**A política de versão declarada é `ultima-da-fonte-oficial`**, e o que a sustenta é a
leitura de volta, nunca um número congelado. A fronteira do outro lado é
**flag de atualização automática ligada não é caminho de atualização**,
e as duas saem em linhas separadas — `plugins.autoupdate_conforme_politica` para a flag,
`plugins.autoupdate_caminho` para o CAMINHO DE ATUALIZAÇÃO, com as classes nomeadas. Essa
segunda linha é medição LOCAL — o cabeçalho `Update URI`
lido do disco e `has_filter()` sobre `update_plugins_{host}`, sem rede —, e a pergunta
dela é se o caminho observado corresponde ao declarado: as classes esperadas fecham
OK nomeando cada grupo, e sobra um único achado adverso, a promessa quebrada (Update URI
de terceiro sem filtro registrado), em WARN com plugin e host nomeados.

**O complemento do canal MCP NÃO está nesta lista, e a razão importa.** Ele é
artefato nosso e não viaja dentro do bundle: `plugins.embarcados` está vazio e
o complemento é instalado por origem `url` declarada, como o servidor. O lock cobre **o
que viaja no pacote**, e o que não viaja não tem caminho para hashear. O que substitui o
checksum nele é o mesmo mecanismo dos plugins de terceiro — a conferência das doze rotas
pelo nome, na unidade `mcp`. Se um dia ele voltar ao slot `assets/plugins/<slug>.zip`,
volta ao lock pelo caminho do slot, sem regra nova: a regra é "o que viaja é
hasheado".

**Regra que produz o valor.** O empacotador percorre a allow-list de caminhos em ordem,
calcula `sha256` de cada arquivo e escreve `caminho` e digest em `dist/lock.tsv`, uma
linha por arquivo, com o cabeçalho de colunas comentado. **É uma linha por caminho da
árvore, e mais nenhuma.** Até a 1.7.4 havia um laço a mais, para o zip que a rodada
montava e que só existia dentro do bundle; ele saiu junto com a montagem. A reserva do
plugin entra como todo arquivo desta árvore, pelo caminho dela em `assets/plugins/`,
porque desde a 2.0.0 ela é entrada de build e não um artefato que nasce na rodada. O
próprio `dist/` fica **fora** do lock: ele é saída de build, não pacote.

O manifesto não pode conter o seu próprio digest — ele é hasheado pelo lock e mudaria a
cada tentativa. Quem o cobre é a linha `MANIFESTO.md` do lock, calculada depois de este
arquivo estar fechado, e o digest do bundle, calculado depois do lock.

**Estado nesta base.** O empacotador existe, roda e produziu lock. Última saída de
build desta montagem:

| Artefato | `sha256` de contrato |
|---|---|
| `dist/implantador-base-<identidade>.zip` | tamanho e digest não podem constar aqui: o bundle **contém este arquivo**, e escrevê-los mudaria os dois no mesmo ato |
| `dist/lock.tsv` | idem: o lock traz a linha de `MANIFESTO.md`, calculada depois de este arquivo estar fechado |

O `dist/lock.tsv` desta montagem traz uma linha por caminho do pacote, a da reserva do
plugin inclusive. **O número não é escrito aqui**: contagem digitada à mão
em documento entregável está correta no
dia em que foi escrita e é contradita pela rodada seguinte. A contagem de arquivos do
pacote sai no carimbo gerado no topo deste arquivo, e o lock em si é o registro
autoritativo — ele é gerado a cada rodada e o próprio `dist/` fica fora dele, porque é
saída de build, não pacote.

**Por que a coluna de digest é um ponteiro e não um número.** A ressalva é do
instrumento: **os digests dos
zips não se repetem entre duas montagens.** `zip` grava a data de modificação de cada
entrada, e os arquivos que o empacotador copia para o diretório de montagem recebem data
nova a cada rodada; conteúdo idêntico produz digest diferente. Um número escrito aqui
estaria errado na rodada seguinte, e um manifesto que envelhece sozinho é pior do que um
que aponta. **O contrato é o `dist/lock.tsv` que sai da rodada que fecha a release**, e o
que ele prova é a correspondência entre caminho e conteúdo naquela rodada — não a
igualdade byte a byte de dois zips montados em momentos diferentes. Dizer isso é mais
barato do que deixar um operador comparar dois digests legítimos e concluir que o pacote
foi adulterado. **O `hash do pacote` é outro número e responde a outra pergunta**: ele soma
o `sha256` de cada arquivo do corpo do bundle, não os bytes do zip, e por isso duas rodadas
sobre a mesma árvore, no mesmo dia, dão o mesmo valor — medido nesta release. É ele que o
host confere contra o `suite/rodada.json` que viajou dentro da árvore instalada.

Recalcular um digest à mão não substitui isso: `sha256sum` de um arquivo desta árvore
devolve um número correto e sem valor de contrato, porque contrato é o que o comando
único reproduz. Evidência que o comando único não reproduz nunca sai como OK: ela sai em
**N/A com a fase em que é medida** quando a
fase declarada não é a desta rodada, e em **BLOCKED** quando a pergunta se aplica aqui e
a resposta depende de alguém; o que não muda é que nenhuma das duas afirma medição.

### Artefatos de terceiro — não entram no lock, entram como fato observado

WordPress núcleo, PHP e os plugins instaláveis da fonte oficial ficam **fora** do lock.
Eles são instalados sempre na última versão publicada pela fonte oficial, e o manifesto
registra a versão **observada** na execução, como fato de diagnóstico e nunca como
critério de aprovação.

| Componente | O que o manifesto registra | O que decide |
|---|---|---|
| WordPress núcleo | versão observada na execução | nada: é diagnóstico |
| PHP | versão observada na execução | o piso `8.1` do preflight, que é requisito e não observação |
| `wordpress-seo` | versão observada e resultado da leitura de volta de cada option gravada | a leitura de volta |
| `flamingo` | versão observada e resultado da leitura de volta | a leitura de volta |
| `wp-mcp-ultimate` | versão observada e o resultado da conferência de rotas por nome | a presença das rotas exigidas |

Nenhum checksum de terceiro entra no lock. A fronteira de confiança nesses artefatos é
a entrega da própria fonte oficial por HTTPS, e o que substitui o checksum como prova de
que a instalação serve é a leitura de volta: o pacote grava dentro do journal, relê a
chave gravada, e reverte a escrita e fecha BLOCKED quando o plugin descartou ou
transformou o valor.

**Estado nesta base: N/A com a fase nomeada.** O comando único roda contra a árvore do
pacote, não contra um WordPress instalado. Nenhuma versão de terceiro foi observada, e
declarar um número aqui seria inventá-lo. Essas linhas fecham **N/A
nomeando a fase `producao`**, nunca BLOCKED: não falta ação de ninguém aqui, falta a
fase — e quem cobra que ela um dia rode é `fases.registro_de_execucao`.

## O que a bancada não mede, e por que a sonda de navegador mudou de repositório

**A bancada de JavaScript SIMULA `IntersectionObserver`. O navegador TEM um.** Essa
diferença não é teórica, e o preço dela está contado: **quatro releases seguidas a bancada
aprovou o que o navegador reprovou.**

| Release | O que a bancada aprovou | O que o navegador fazia |
|---|---|---|
| `1.3.3` | o rearme da seção decidido por `isIntersecting` | o retorno intermediário — razão abaixo da linha com o alvo ainda sobreposto — nunca era produzido pela bancada, e o bloco era gravado uma vez só por carregamento: 80 linhas em produção, todas com `ocorrencia = 1` |
| `1.3.4` | o contador de travessias durável | a linha continuava volátil, e a bancada media um carregamento só — o buraco na sequência só aparecia entre carregamentos |
| `1.3.5` | o despacho do resumo | `sendBeacon` devolvendo `true` diz ENFILEIRADO, nunca ENTREGUE; a release listou três lacunas suas |
| `1.3.6` | a assimetria da 1.3.3, com a mutação plantada | `isIntersecting` **não é sobreposição geométrica**: medido em Chromium 1194, com `threshold: 0.5` a razão 0,2 chega com `isIntersecting: false`. A bancada modelava `razao > 0` e afirmava um defeito que não existe |

É por isso que `navegador.comportamento_real` existe, e é por isso que ela é checagem de
primeira classe e não script auxiliar. Ela roda o cliente **entregue** — sem comentário,
que é o que o visitante baixa — num Chromium de verdade, dirigido só por rolagem, sobre uma
página de geometria de site real. O piso dela é a assimetria da 1.3.3 plantada no cliente
entregue: uma sonda que calasse sobre o defeito que a bancada não media seria uma segunda
bancada com um navegador dentro.

**Ela não é emitida por esta suíte desde a 2.0.0, e o motivo é o OBJETO.** O que ela mede é
o cliente do PLUGIN contra o artefato que o site recebe, e nem o cliente nem o artefato
moram nesta árvore: a fonte saiu, e o diretório do entregue era produzido pelo
empacotamento do plugin, que este repositório não executa. Medir o cliente contra uma cópia
da fonte que o site não recebe é aprovar um arquivo que ninguém baixa — foi exatamente esse
o defeito que a 2.0.0 fechou, e ele valia para os 59 rótulos que saíram daqui, não só para
este. A sonda roda no repositório do plugin, contra o zip que o catálogo publica; a linha
sai declarada em `suite/excluidas.tsv`, com categoria e motivo.

**Do cliente do plugin, esta bancada continua medindo uma checagem, e ela ficou aqui pelo
mesmo critério que mandou as outras embora:** `js.banner_de_consentimento` mede um PAR cujas
duas metades só se encontram deste lado — o `style.css` do TEMA, que é artefato nosso,
contra o cliente de consentimento do plugin, lido de dentro da reserva. A visibilidade é
decidida pelo par (`hidden`, `display`), e um `display` de autor na folha do tema vence o
`[hidden]` da folha do user agent: o defeito mora ENTRE os dois artefatos, e nenhuma das
duas suítes o veria sozinha.

**Um pacote verificado aqui só é um pacote aprovado junto com a rodada selada do plugin**,
e o que amarra as duas é o `sha256` declarado no catálogo — o digesto da release que a
suíte de lá fechou, cobrado sobre a reserva desta árvore por
`pacote.reserva_confere_com_o_catalogo`. Rodada verde de um lado só, sobre uma reserva que
o catálogo não serve, foi o que a 1.7.4 entregou.

### E desde a 2.1.0 ela não mede mais o TEXTO JURÍDICO nem o dado do controlador

Isto não é limite de instrumento: é decisão do dono sobre de quem é a responsabilidade.
`privacidade.controlador_identificado` media o conteúdo SERVIDO e, junto com uma guarda de
status, mantinha a política de privacidade em rascunho enquanto razão social, CNPJ e
endereço estivessem vazios; `projeto.fato_juridico_coerente` media base legal e prazo de
retenção como conjunto coerente; `lgpd.base_legal_declarada`, no host, avisava que a
política ia ao ar sem a hipótese legal. **As três saíram, e a guarda saiu com elas.** O que
a política AFIRMA é responsabilidade de quem responde por ela, e o implantador não confere
o texto jurídico de ninguém.

O que ficou é MECANISMO, e ele continua medido em `conteudo.politica_de_privacidade`: qual
página é a política sai do PAPEL declarado na entrada, o arquivo real carrega os
marcadores `%f3base:contato.controlador.*%` e cada valor chega ao conteúdo pela
interpolação, os dois blocos do encarregado se excluem pela condição declarada no atributo,
e o status de toda página é o DECLARADO — `veredito_de_status_de_pagina()` devolve o
declarado e nenhuma guarda de conteúdo rebaixa página nenhuma.

**O PREÇO ESTÁ DECLARADO, e quem o paga é quem não preencheu:** com `contato.controlador`
vazio a política PUBLICA com o marcador vazio à vista de quem ler. O caminho de saída é o
mesmo da operação inteira — preencher `config/projeto.json` ANTES da execução única, ou
editar a página pelo canal MCP DEPOIS. As duas chaves de `fato_juridico` continuam sendo
LIDAS, e sem juízo: a base legal alimenta o texto da política, o prazo alimenta a retenção
do `site-core`.

## Valores que só existem em tempo de execução

Para cada um deles, a regra que o produz — nunca um número.

| Valor | Regra que o produz | Onde ele aparece |
|---|---|---|
| `sha256` de cada artefato nosso | `sha256` de cada caminho da allow-list, em ordem, no empacotamento | `dist/lock.tsv` |
| Digest do bundle | calculado sobre o arquivo único nomeado, depois de o lock estar fechado | repositório de artefatos |
| Hash da configuração | digest do `config/site.json` no início da execução; a retomada exige o mesmo valor | checkpoint e proveniência |
| Versão do implantador | cabeçalho `Version:` lido por `get_plugin_data()`; a constante de bootstrap é fallback, e o relatório imprime as duas quando divergem | relatório |
| Versão do tema | cabeçalho do `style.css` lido por `wp_get_theme()`; é a mesma que vai ao parâmetro de versão do CSS publicado | relatório e HTML publicado |
| Versão observada de plugin de terceiro | leitura da versão instalada no momento da aplicação, gravada junto do resultado da leitura de volta daquele plugin | relatório |
| Frase de validação do leia-me de projeto | **derivada** do lock: "validado até a versão que o lock registra", nunca "instalado tal versão" | leia-me de cada projeto |
| Identificador da execução e token de disputa | gerados no início da execução, gravados no checkpoint depois da leitura de volta | checkpoint |
| Identificador de anexo de mídia | atribuído pela instalação no sideload e injetado no bloco em tempo de deploy; muda por instalação e não pode viver no arquivo | conteúdo publicado |
| `f3base_nav_id` | identificador do post de navegação criado na aplicação, lido de volta e guardado em option | banco da instância |
| Data da última execução do modo somente-relatório | carimbo da execução mais recente da cadência, gravado pelo módulo `cadencia-relatorio` do `site-core` junto de gatilho, resultado, erro, duração e atraso medido sobre o horário previsto | relatório e tela do site-core |
| Ajustes contados desde a última execução da cadência | escritas em option GERENCIADA desde o último relatório, com carimbo de atividade, estado da cadência, procedência e journal fora da conta — eles mudam porque o site rodou, não porque alguém ajustou | tela do site-core |
| Peso de página, número de requisições e nós de DOM | medidos na entrega contra o orçamento declarado em `orcamento_pagina` | relatório |
| Razões de contraste | fórmula de luminância relativa da WCAG aplicada à paleta do `theme.json`, recalculada pela checagem `a11y` sobre os pares em uso | relatório e `fontes/tema/CONTRASTE.md` |

## Estado do manifesto nesta release

**Nenhuma linha desta tabela carrega contagem digitada.** Contagem por estado é resultado
da rodada, e a rodada acontece DEPOIS de este arquivo ser escrito: quem a carrega é
`suite/rodada.json`, gerado pelo selo com o hash do pacote que aquela rodada mediu.
Os números de disco — caminhos, requisitos, armadilhas, detectores com piso — estão no
carimbo gerado no topo. O que sobra aqui é o que a tabela sempre deveria ter sido: o
ESTADO de cada item e o motivo dele.

**E o que SAIU da tabela tem lista própria, porque some é o que uma checagem não pode
fazer.** A 2.0.0 deixou de emitir 59 rótulos que a 1.7.4 emitia: o objeto que eles mediam é
o PLUGIN, que ganhou repositório e suíte próprios, e medi-lo aqui era medi-lo contra uma
cópia da fonte em vez do artefato que o site recebe. Cada um está declarado em
`suite/excluidas.tsv`, com CATEGORIA fechada — `plugin` quando o objeto mudou de
repositório, `substituida` quando a pergunta continua respondida aqui por outra linha com
outro nome, `instrumento` quando a checagem media um passo do empacotamento que este
repositório não executa mais, e `retirada` quando o dono decidiu que aquela
responsabilidade NÃO é do implantador — e com o MOTIVO em uma frase. Quem confere é
`excluidas.declaradas`: toda linha precisa nomear uma checagem que esta rodada NÃO emite,
com categoria e motivo, e uma linha sobre checagem ainda emitida é declaração velha. O
arquivo é o espelho do `excluidas.tsv` do repositório do plugin, que declara, do lado de
lá, o que ficou aqui. Checagem que some sem declaração é indistinguível de checagem
esquecida, e é assim que a cobertura encolhe sem que nada acuse.

**A categoria `retirada` nasceu na 2.1.0, e ela é diferente das outras três: o objeto não
mudou de endereço, a PERGUNTA deixou de ser deste pacote.** Saíram por ela
`privacidade.controlador_identificado` e `projeto.fato_juridico_coerente` — dado e
declaração jurídica do operador —, e `entrega.convergencia`,
`lotes.gate_de_aplicacao_sem_dado_do_operador` e `estatica.precondicao_no_eixo`, que eram o
TERCEIRO EIXO do encerramento. O eixo somava as pré-condições que dependiam de dado do
operador e respondia sempre a mesma coisa: *preencha e execute de novo*. **O implantador é
executado UMA VEZ por site**, e um eixo cuja única saída é um ciclo que a operação não tem
descrevia um método que não existe. Do lado do host saíram, pelo mesmo motivo,
`lgpd.base_legal_declarada` e `seo.llms_selecao` — esta substituída por `seo.llms_proprio`.
O vocabulário de gates ficou com TRÊS valores — `aplicacao`, `fase` e `relato` —, e a
autodesativação continua onde sempre esteve: no gate de APLICAÇÃO.

**Como ler a tabela abaixo depois dessas duas mudanças, e as duas se leem diferente.** A
linha declarada em `suite/excluidas.tsv` com categoria `plugin`, `substituida` ou
`instrumento` continua descrevendo o REQUISITO e o mecanismo que o sustenta, e o estado
dela é medido no repositório do plugin: o requisito não saiu do método por a medição ter
mudado de endereço, o que saiu daqui é a EMISSÃO. A linha de categoria `retirada` se lê ao
contrário: o estado dela é **`retirada na 2.1.0 — responsabilidade do operador`**, e
ninguém a mede em lugar nenhum — não há segundo endereço, porque a pergunta deixou de ser
do implantador. Ela fica na tabela com o motivo escrito para que a diferença entre
"mudou de repositório" e "deixou de ser nossa" não vire silêncio.

| Item | Estado | Motivo |
|---|---|---|
| Identidade única declarada e compartilhada | OK | `estatica.identidade_do_implantador` mede os TRÊS lugares que carregam o número — `release.identidade` e `release.implantador` na configuração, o cabeçalho `Version:` de `implantador-base.php` e o fallback `F3BASE_IMP_VERSAO_DECLARADA` —, e `estatica.carimbo_de_release_nos_documentos` reprova se um documento entregável carimbar outra. Afirmar a igualdade sem medi-la deixa configuração, cabeçalho e constante divergirem sem que nenhuma rodada acuse |
| Inventário de caminho para papel | OK | gerado de `suite/inventario.tsv`, a allow-list executável, e conferido contra o disco por `pacote.allow_list` |
| Comando único existe e roda | OK | `bash suite/verificar.sh <caminho absoluto>` fecha com código 0, e o resumo por estado daquela rodada é o que vai para `suite/rodada.json` |
| Piso dos detectores | OK | `bash suite/verificar.sh piso` roda dois ramos por detector — a fixture negativa precisa ser acusada, a positiva precisa ficar em silêncio —, e a contagem de detectores com piso está no carimbo |
| Mapa de armadilhas | OK | `armadilhas.mapeadas` calcula dos rótulos EFETIVAMENTE emitidos; mapeamento para checagem sem piso fecha BLOCKED, não OK |
| N/A de fase não é pendência, nos três consumidores | OK | `entrega.gates_separados`: `F3Base_Imp_Fases::gate_de_fase_em_aberto()` decide num lugar só — OK respondeu, N/A não se aplica aqui, e nenhuma das duas entra na lista. O piso ao contrário: com uma em N/A ao lado de uma em BLOCKED, a nota NÃO pode dizer "nenhuma pendência de fase em aberto", e a BLOCKED sai nomeada com o estado |
| Aplicabilidade por fase separada de pré-condição ausente | OK | `fases.regra_de_aplicabilidade`: fase declarada FORA da fase corrente fecha N/A nomeando a fase em que é medida, e na fase certa continua BLOCKED. Os pisos são os cinco modos de a regra se apagar sozinha — fase não declarada não absolve, fase corrente indefinida não absolve, e BLOCKED, N/A e WAIVED não contam como medição de fase |
| Fase declarada que nunca rodou não passa em silêncio | OK nesta base | `fases.registro_de_execucao`: declara, por fase, quantas checagens a esperam, QUAIS são e quando ela rodou pela última vez, e fecha WARN nomeando as que NUNCA rodaram E TINHAM o que medir. É o contrapeso obrigatório da regra acima: sem ele, a checagem de navegador ficaria em N/A para sempre e o silêncio viraria aprovação por omissão. A exceção medida: fase cujas checagens esperadas fecharam TODAS em N/A é declarada NÃO APLICÁVEL a este emissor e sai fora da cobrança — relatada, sem WARN —, porque cobrar de um emissor a evidência que ele não produz por desenho é o aviso que sai sempre. N/A continua NÃO registrando a fase como executada, e uma linha em BLOCKED ao lado das N/A devolve a fase à cobrança. O registro dura entre execuções em `suite/fases.json` (suíte) e na option `f3base_fases` (host) |
| Empacotador produz lock com `sha256` por caminho | OK | `dist/lock.tsv`, gravado na primeira etapa e regravado pelo selo |
| Nenhum cabeçalho de plugin ao alcance de `get_plugins()` fora do arquivo principal | OK | `pacote.sem_cabecalho_de_plugin_aninhado`: um único `Plugin Name:` na raiz e nenhum a um nível, com as fontes em `fontes/` |
| Cobertura da allow-list sobre o disco | OK | nenhum arquivo em disco fora de `suite/inventario.tsv`, e nenhum caminho declarado sem arquivo |
| Lock e bundle correspondentes à árvore de hoje | OK | `pacote.build_fresco`: o bundle desta montagem é mais novo que toda fonte do pacote |
| Documentos entregáveis carimbados com a release que descrevem | OK | `estatica.carimbo_de_release_nos_documentos`: as regiões geradas de README, MANIFESTO e MEMORIA-DECISOES são comparadas com a medição de agora, e divergência é achado |
| Quem recebe o zip recebe COMO usá-lo e como construir o próprio | OK | `entrega.documentacao`, entregável novo na 2.1.0: `MANIFESTO.md`, `TEMPLATE.md`, `MAPA-DA-OPERACAO.md` e `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md` viajam na RAIZ do pacote, estão no inventário e são cobrados pelo nome — ausência fecha BLOCKED nomeando o arquivo que falta. Ele entra no gate de aplicação como os outros entregáveis, e a mesma lista é lida pelo host em `F3Base_Imp_Entrega::artefatos()`. Um pacote sem eles é um pacote que exige procurar em outro lugar como ele se usa, e o outro lugar não viaja junto |
| Grafo de dependências do plano fecha | OK | `estatica.plano_dependencias`: nenhum grupo alvo inexistente, nenhum autoloop, nenhum ciclo |
| Uma fonte de verdade por veredito de gate, por option, por status de página e pela identidade da política | OK | `estatica.gate_fonte_unica`, `estatica.option_fonte_unica`, `estatica.pagina_status_fonte_unica` e `estatica.politica_privacidade_fonte_unica` |
| Slug declarado em todo conteúdo gerenciado | OK | `config.slug_declarado`: toda entrada de `paginas` e `posts` declara slug não vazio, e nenhum se repete |
| Cobertura das URLs antigas na troca de estrutura de permalinks | OK | `lotes.permalinks_decisao`: o padrão `aplicar-e-cobrir` grava 301 do caminho antigo de TODO publicado que muda de endereço, gerenciado ou não; o par sai pelo produtor único de `f3base_redirects` com origem própria, o caminho que não muda é descartado porque seria laço, e o relatório NOMEIA cada URL coberta em vez de contá-las |
| Conteúdo de exemplo do WordPress decidido por discriminante | OK | `conteudo.exemplo_do_wordpress`: só vai para a lixeira o objeto que AINDA É o que `wp_install_defaults()` criou — título E conteúdo idênticos ao que o núcleo escreveria agora, com o objeto gerenciado e o objeto em uso intocáveis. **A CLÁUSULA DA DATA SAIU NA 2.1.0, e por medição**: até a 2.0.0 exigia-se também `post_modified_gmt` sem avançar em relação a `post_date_gmt`, e o instalador da hospedagem toca o `Hello world!` dois segundos depois de criá-lo — a data avançava sem ninguém editar nada, o post era preservado como "editado" e ia ao ar, no sitemap e no `llms.txt`, com a categoria Uncategorized junto. Quem edita muda o TEXTO; a data que o instalador toca não é texto. O piso que importa é o NEGATIVO: a edição é plantada em título, em conteúdo e nos dois, nos dois objetos do catálogo, e nenhum dos casos produz remoção |
| Padrões da instalação limpa removidos pela lista declarada | OK | `limpeza.plano_dos_padroes`: a unidade `limpeza` roda DEPOIS do tema e ANTES do `site_core`, e o PLANO dela é regra pura com teto e piso. Ela remove o que `limpeza.temas_padrao` e `limpeza.plugins_padrao` declaram — `delete_theme()` e `delete_plugins()`, com desativação pela API do núcleo antes —, e lê de volta (`wp_get_theme()->exists()` falso, `get_plugins()` sem o arquivo). As guardas são o piso: tema ATIVO declarado na lista é PULADO nomeando o motivo, tema PAI do ativo idem, item declarado e não instalado é AUSENTE e não erro, lista vazia é plano vazio, e nada fora da lista é tocado — o plugin de painel da hospedagem fica, porque o que é de alguém é de alguém. O journal registra a remoção como IRREVERSÍVEL com o motivo: tema de fábrica volta pelo repositório oficial. **A consequência está declarada**: remover o Twenty Twenty-Cinco tira do núcleo o tema-reserva (`WP_DEFAULT_THEME`), e se o tema ativo quebrar não há para onde cair — tema que quebra neste pacote é defeito de release, medido antes de sair. Medido na implantação de 2026-09-07: o site foi entregue com três temas de fábrica, o Akismet e o Hello Dolly no lugar |
| Nenhum WARN do runtime sem achado adverso | OK | `estatica.warn_tem_ramo_adverso`: todo WARN de `includes/` e `fontes/` mora num ramo que mediu alguma coisa, ou depois de uma cláusula de guarda que pode impedi-lo |
| Série de cópia preservada colapsa o backup de backup | OK | `plugins.serie_de_backup_normalizada`: a MESMA função do runtime, em subprocesso, sobre o nome literal medido no site e o aninhamento duplo |
| Renomeação de prefixo sem resíduo fora das exceções declaradas | N/A neste pacote | `estatica.sem_residuo_de_prefixo`: enquanto `site.prefixo_tecnico` for o prefixo do template, procurar resíduo do próprio prefixo não mede nada. A regra roda de verdade no pacote renomeado, e o piso de fixture prova, em toda rodada, que ela acusa o resíduo plantado e cala sobre a árvore limpa |
| Grafias preservadas na renomeação derivadas do CÓDIGO do plugin, nunca da prosa | OK | `renomeacao.preservados_so_do_codigo`: cinco amostras contra a regra pura e uma cópia do pacote com uma grafia plantada só em comentário e outra só em código, renomeada de verdade — a da prosa vira `acme_`, a do código fica. Medido na 2.0.0: sem o corte, as seis options de estado do implantador (`f3base_lock`, `f3base_checkpoint`, `f3base_journal`, `f3base_estado_aplicacao`, `f3base_release`, `f3base_fases`) sobreviviam com o prefixo do template porque o contrato do plugin as nomeia num comentário |
| Conteúdo demonstrativo declarado e coerente com o disco | WARN por desenho neste pacote | `conteudo.demonstrativo` fecha WARN porque `conteudo.demonstrativo = true` e `ambiente.tipo = "producao"`: as páginas ainda são as do template, e é isso que o aviso diz. `conteudo.marca_demonstrativa` fecha OK — declaração e disco concordam arquivo a arquivo |
| Referências de mídia com arquivo correspondente | OK | os arquivos declarados em `midia` existem em `assets/`; `logo.png` leva o papel `custom_logo` e `logo.svg` o papel `marca_inline`, que não passa pela biblioteca |
| Complemento do canal no lock | N/A | condição declarada: ele não viaja no bundle (`plugins.embarcados` vazio) e é instalado por origem `url`. O lock cobre o que viaja; a conferência dele é a das doze rotas pelo nome |
| Versões observadas de núcleo, PHP e plugins de terceiro | N/A (fase `producao`) | o comando único roda contra a árvore do pacote, não contra uma instalação. Regra que produziria o valor: o adaptador lê a versão instalada no momento da aplicação e a grava no relatório junto do resultado da leitura de volta |
| Canal MCP configurado e exposto | N/A (fase `producao`) | as doze rotas se conferem pelo nome num WordPress com servidor e complemento ativos |
| Autoteste do canal despachado, com o resultado no relatório | N/A (fase `local`) | `mcp.autoteste`: despachar `files/selftest` exige um servidor REST vivo, e a árvore do pacote não é um. O veredito tem teto e piso em `mcp.autoteste_veredito` — autoteste que devolve falha REPROVA a entrega, e ausência da rota fecha BLOCKED, nunca OK. A VIA da Abilities API é o objeto da habilidade (`wp_get_ability()` e `WP_Ability::execute()`): até a 1.7.0 ela era procurada por `function_exists( 'wp_execute_ability' )`, função que NÃO existe na API — nem na nativa do 6.9, nem no polyfill do servidor MCP —, a guarda era falsa sempre e a linha fechava BLOCKED em toda instalação limpa, segurando `mcp.canal_exposto` e a autodesativação junto. A regra de casamento entre nome de habilidade e rota curta mora num lugar só, com piso nas grafias que casam e nas que não podem casar |
| Recusa do autoteste a credencial não autorizada | N/A na suíte e no host (fase `campo`), e o estado sai da REGRA | `mcp.autoteste_recusa_credencial`: não é mensurável de dentro do WordPress rodando como administrador, e a linha nomeia o que falta. A fase é `campo` porque quem produz a evidência é o REQUISITANTE EXTERNO — uma requisição HTTP de fora com credencial sem a capacidade exigida —, e não o host: declará-la `producao` faria a linha sair BLOCKED em toda execução, para sempre, sobre uma ausência por desenho. Prova fraca com nome de prova negativa continua recusada explicitamente |
| Assistente de terceiro desarmado na MESMA unidade que ativa | OK | `plugins.supressao_por_transiente`: o mapa `plugins.supressao_onboarding` aceita a forma `transiente:<nome>` além de `option.chave`, e a entrada do servidor do canal declara o transiente que o CÓDIGO dele lê (`wp_mcp_ultimate_activated`, em `includes/Plugin.php`). A supressão o apaga na unidade que ativou o plugin, antes de qualquer `admin_init`, e a leitura de volta é `get_transient()` devolvendo falso. Medido em 2026-09-07: o assistente daquele plugin é decidido por TRANSIENTE e nenhuma option o desarmava — em toda instalação limpa o lote seguinte à ativação era sequestrado uma vez. O teto lê o catálogo nas duas formas; o piso confere que o código da supressão reconhece o prefixo e apaga o transiente |
| Digesto do artefato baixado por URL | OK | `plugins.digesto_do_artefato`: os três ramos separados, com o limite do ramo TOFU escrito na própria mensagem — fixar na primeira observação defende contra a origem mudar embaixo das execuções seguintes e NÃO defende a primeira busca |
| HTTPS obrigatório em todos os saltos da origem | OK | `plugins.https_em_todo_salto`: os saltos são seguidos um a um com `redirection = 0`, cada endereço precisa continuar em https, e o corpo desce só do endereço final. Não há lista fechada de HOSTS ao lado: ela moraria no mesmo arquivo que as URLs que restringiria, e quem consegue editar a URL edita a lista na linha de cima. O que amarra o byte baixado é o digesto |
| Caminho de atualização, separado da flag | N/A (fase `local`) | `plugins.autoupdate_caminho` lê o cabeçalho `Update URI` de cada plugin INSTALADO e confere `update_plugins_{host}` com `has_filter()` — medição local, sem rede, e a árvore do pacote não tem plugin instalado nem filtro registrado. A classificação e os três vereditos têm teto e piso em `plugins.autoupdate_caminho_separado`: as classes esperadas fecham OK com cada grupo nomeado, a promessa quebrada fecha WARN nomeando plugin e host, e o escopo vazio continua BLOCKED |
| Afirmação de documento conferida contra comportamento medido | OK | `doc.afirmacao_conferida`: o elo mora em `suite/afirmacoes.tsv`, e toda afirmação de comportamento declarada está no documento que a faz E bate com o fato medido no pacote |
| Option gravada que ninguém lê de volta | OK | `estatica.option_gravada_sem_leitor`: o irmão de `estatica.detector_chave_sem_consumidor`, que mede "a chave é lida" e não "a leitura muda alguma coisa" |
| Rodada limpa amarrada ao hash do pacote aplicado | BLOCKED (fase `build` — esta) | `entrega.rodada_limpa` exige uma execução da aplicação em WordPress, com o hash do pacote no checkpoint |
| Identificação do controlador na política publicada | retirada na 2.1.0 — responsabilidade do operador | `privacidade.controlador_identificado` media o conteúdo SERVIDO e fechava BLOCKED com razão social, CNPJ ou endereço vazios, com uma guarda de status segurando a página em rascunho até alguém preencher. Saiu por decisão do dono, e a guarda saiu junto: o que a política AFIRMA é responsabilidade de quem responde por ela. `contato.controlador` continua nascendo vazio e continua sendo INTERPOLADO no texto, e a política PUBLICA — com o marcador vazio à vista quem não preencheu `config/projeto.json` antes da execução única. Declarada em `suite/excluidas.tsv`, categoria `retirada` |
| A política de privacidade é identificada pelo papel e interpolada da configuração | OK | `conteudo.politica_de_privacidade`: é o que sobrou de MECANISMO depois que a checagem do controlador e a guarda de rascunho saíram. Qual página é a política sai do PAPEL declarado na entrada — nunca da seleção do `llms.txt`, porque desligar `bots_ia.llms_txt` silenciaria a identidade junto —, o arquivo real carrega os marcadores `%f3base:contato.controlador.*%` e cada valor chega ao conteúdo, os dois blocos do encarregado se excluem pela condição declarada no atributo, e o status de toda página é o DECLARADO: `veredito_de_status_de_pagina()` devolve o declarado, e `estatica.pagina_status_fonte_unica` continua exigindo UM produtor — a regra de fonte única é sobre haver um produtor, não sobre ele decidir alguma coisa |
| Fato jurídico coerente entre base legal e prazo | retirada na 2.1.0 — responsabilidade do operador | `projeto.fato_juridico_coerente` media base legal e prazo de retenção como CONJUNTO e chamava de incoerente preencher um e deixar o outro. A declaração jurídica é de quem responde pelo site; as duas chaves continuam LIDAS, sem juízo — `fato_juridico.base_legal` alimenta o texto da política e `retencao_leads_meses` alimenta a retenção do `site-core`. Declarada em `suite/excluidas.tsv`, categoria `retirada` |
| Mecanismo da cadência do modo somente-relatório | medido no repositório do plugin | `cadencia.mecanismo_declarado` fecha OK nomeando o mecanismo OBSERVADO quando há agendamento medido para o hook — chave vazia significa "não há gatilho externo além do WP-Cron", que é o padrão desta base e não uma falta — e fecha OK nomeando o DECLARADO quando `mecanismo_de_cadencia` estiver preenchida, sem perder o observado. Ele fecha BLOCKED num caso só: nenhum agendamento observado E a chave vazia, quando não há gatilho nenhum a nomear. `cadencia.agendada` responde a outra pergunta: ela mede o WP-Cron e fecha OK porque o agendamento existe mesmo. O OUVINTE do evento não está em aberto: é o módulo `cadencia-relatorio` do `site-core`, e `cadencia.ouvinte_registrado` mede que o hook tem ouvinte e que as recorrências quinzenal e mensal existem |
| O relatório não afirma uma coisa e faz outra | OK | `lotes.gate_de_fase_nao_derruba_estado`: nenhuma linha declarada com gate de FASE — sobre a qual o texto escreve que este host não produz a evidência e que ela não é somada ao gate — pode fechar FALHA, porque FALHA entra na contagem CRUA que derruba o estado da aplicação, e o estado é a PRIMEIRA das três condições daquele gate. Foi a contradição medida na 1.7.2. A contagem continua crua de propósito, e a medição que sustenta a escolha está na decisão 109: toda checagem de gate `fase` capaz de fechar FALHA media evidência que este host PRODUZ. O piso planta a contradição; os pisos ao contrário impedem a correção de virar ruído — BLOCKED de fase não é acusado, e FALHA de `relato` também não. O vocabulário de gates tem TRÊS valores desde a 2.1.0 — `aplicacao`, `fase` e `relato` —, e o quarto, `convergencia`, saiu inteiro com o eixo que ele derivava |
| Gate de fase sem ramo de FALHA, medido nas DECLARAÇÕES | OK | `estatica.gate_de_fase_sem_ramo_de_falha`: varre as emissões escritas em `includes/` e cruza o gate declarado com os estados que cada uma pode produzir — `avaliar()` e `condicional()` são acusadas sempre, a constante literal decide sozinha, a variável é resolvida pela produtora que a atribui, e qualquer outra forma é acusada por não ser provável. Ele existe porque a bancada irmã, `lotes.gate_de_fase_nao_derruba_estado`, mede a REGRA contra linhas que ela mesma monta: plantada a contradição na declaração real — uma palavra em `class-f3base-imp-plugins.php` —, a rodada fechava sem uma única FALHA. Uma mede o instrumento, a outra mede o objeto, e cada uma diz na própria linha o que não afirma |
| Um fato, uma linha, um veredito sobre a versão do plugin do site | OK | `plugins.veredito_de_versao_do_site_core`: os cinco ramos da regra que ficou (instalada atrás fecha FALHA, à frente fecha OK, iguais fecha OK, reserva sem número fecha WARN, nada instalado fecha N/A), a FALHA nomeando as duas versões e o ENDEREÇO da cópia embutida, e a contagem de emissores do veredito no código — mais de um é o defeito da 1.7.2 voltando, quando o mesmo par de números saiu em WARN numa linha e em FALHA em outra. A versão comparada é a lida do NOME da reserva, e a linha responde por VERSÃO e só por versão: dois artefatos de mesma versão com bytes diferentes ela não distingue, e não deve — quem separa bytes é o digesto, na linha `plugins.instalado:<slug>`, contra o `sha256` que o catálogo declara. Dois fatos, duas linhas |
| Regime de formulário derivado do valor do destino | medido no repositório do plugin | `formulario.veredito_destino`: sumiu o interruptor `ativo` da entrada — havia dois fatos podendo discordar, e discordavam. Destino vazio fecha N/A com a condição declarada e o CTA do modelo não é publicado; `cta.publicado_pela_presenca_do_numero` mede a publicação do bloco nos dois ramos |
| O formulário criado está na PÁGINA declarada, ou a unidade reprova | OK | `formulario.na_pagina_declarada`: a `pagina_ref` de cada regime é lida por `F3Base_Imp_Lotes::pagina_ref_do_regime()` de `config/projeto.json`, que é o arquivo onde o bloco `formularios` mora, e `F3Base_Imp_Formulario::por_na_pagina()` devolve `{ok, motivo}` — REPROVANDO quando a página declarada fica sem o formulário: ref vazia, ref que não resolve, gravação recusada ou leitura de volta sem o shortcode. "Já estava na página" e "publicado e conferido na leitura de volta" são os ramos OK. O defeito que criou a checagem vinha da 1.7.4 e foi medido em 2026-09-07: `pagina_ref` era a única chave do bloco lida de `config/site.json`, onde o bloco não existe — voltava vazia, a função devolvia string vazia em todo caminho de falha, o chamador lia vazio como "nada a acrescentar", e o formulário era criado e posto em PÁGINA NENHUMA com a unidade fechando OK. O teto resolve a página de cada regime na configuração real; o piso prova que o leitor errado devolve vazio |
| A página de confirmação do formulário não se indexa | OK | `F3Base_Imp_Formulario::marcar_noindex()` grava a meta de noindex do fornecedor — pelo nome que `F3Base_Chaves_Seo::NOINDEX` declara, nunca por um literal escrito ao lado — na página de confirmação, criada agora ou já existente, e a linha diz "página de confirmação criada, em noindex". O plugin de SEO a tira do sitemap com essa meta, e o `site-core` honra o MESMO noindex quando é ele quem responde — fora do `llms.txt` e fora do sitemap. Medido em 2026-09-07: `/solicitacao-recebida/` saiu no sitemap, indexável como qualquer página de conteúdo, e uma página que só faz sentido depois de um envio não é resultado de busca |
| O pacote não pede ao canal que recuse a escrita do agente | OK | `estatica.sem_recusa_de_escrita_do_agente`: não há módulo de guarda de options do canal nem filtro de options protegidas do servidor MCP no pacote. Depois da instalação quem modifica o site é um agente pelo canal, e registrar as options do catálogo nos filtros pelos quais o servidor decide o que recusar seria pedir ao canal que recusasse a escrita dele |
| Chave desconhecida sobrevive à leitura da option | medido no repositório do plugin | `options.chave_desconhecida_preservada`: o sanitizador normaliza a chave declarada e PRESERVA a que o pacote não conhece, no catálogo inteiro e dentro das entradas de lista. Sanitizador que reconstrói o array faz a chave acrescentada pelo agente sumir na primeira leitura — sem erro e sem log |
| Cabeçalho emitido é o valor gravado | medido no repositório do plugin | `seguranca.coop_do_valor_gravado`: o COOP emitido é o valor GRAVADO, nunca um literal da classe com uma option ao lado — ali gravar outro valor passaria pela leitura de volta e o cabeçalho continuaria saindo com o do pacote. O módulo fecha degradado NOMEANDO o que se perde |
| Valor aceito que custa atribuição sai com WARN nomeando a perda | medido no repositório do plugin | `seguranca.referrer_policy_avisa_atribuicao`: `no-referrer` é aceito — é decisão do projeto — e sai com aviso que nomeia GA4, Google Ads, Meta Ads e LinkedIn Ads. O aviso só existe no ramo adverso |
| Uma chave decide o caminho de medição, e um caminho só | medido no repositório do plugin | `tracking.caminho_unico`: com `f3base_gtm_container_id` preenchido os IDs diretos NÃO chegam ao navegador — não é um `if` no cliente, é o dado que não viaja —, e por isso a mesma conversão não pode sair duas vezes. Slot vazio é inerte, e ID fora da forma declarada é preservado e avisado |
| Um estado de consentimento gateia as quatro tags | medido no repositório do plugin | `tracking.consentimento_gateia_tudo`: na negativa nenhuma é enfileirada, porque Pixel e Insight Tag não têm modo de consentimento e para eles negativa é ausência; no aceite as quatro saem por um carregador só, dependente do script de consentimento |
| A estratégia de carga do consentimento é decidida pela POLÍTICA | medido no repositório do plugin | `consentimento.estrategia_pela_politica`: pré-aprovado sai `defer`, negado por padrão sai BLOQUEANTE no cabeçalho, e não existe chave de configuração para isso — a condição decide. Nos dois modos o script fica no `<head>`, que é a posição que o põe antes do carregador de tags do rodapé. Os pisos: as duas políticas não podem devolver a mesma estratégia, mudar rodapé, aviso e prazo não pode mexer nela, no modo padrão nenhum script pode ficar no cabeçalho sem estratégia, e no modo opt-in o consentimento PRECISA voltar a bloquear |
| O `consent default` chega antes do `gtag.js`, medido na ORDEM DE EXECUÇÃO | medido no repositório do plugin | `js.ordem_do_consentimento`: os dois clientes REAIS rodados contra um escalonador que é o modelo da especificação, com a linha do tempo lida no `dataLayer` e em cada tag de script externo inserida. O teto que carrega a decisão é uma IGUALDADE — a linha do tempo do consentimento adiado é a MESMA do bloqueante, e é ela que autoriza tirar 5.085 bytes gzip do caminho crítico. Os pisos: `defer` no modo opt-in tem de aparecer como o primeiro `page_view` do emissor concorrente saindo ANTES do `denied`, e o carregador rodando antes do consentimento tem de aparecer como `gtag.js` pedido sem `default` nenhum |
| Identificador de clique dos canais pagos chega ao lead | medido no repositório do plugin | `leads.click_ids_no_schema` e `js.conversao_multicanal`: `gclid`, `gbraid`, `wbraid`, `msclkid`, `fbclid`, `fbc`, `fbp` e `li_fat_id` entram no schema FECHADO do endpoint e no cliente ao mesmo tempo — acrescentá-los só no cliente faria todo lead de tráfego pago voltar 400 |
| O clique do CTA é a conversão do site, e sai em todos os canais | medido no repositório do plugin | `js.conversao_multicanal`: `generate_lead` sempre — o formulário é opcional e o clique é o lead —, `send_to` do Ads com as duas metades, `Lead` da Meta com `eventID` e `track` do LinkedIn. |
| Edição do agente numa option vence a reexecução do implantador | OK | `options.merge_tres_vias`: o pacote registra a BASE e compara TRÊS vias, e a edição do agente vence a reexecução — comparar DUAS vias, observado contra desejado, reverteria em silêncio toda option gravada pelo agente pelo canal; a configuração só vence quando mudou aquela mesma coisa depois, e aí a SOBREPOSIÇÃO sai nomeada com os dois valores. Numa instalação que tem a option e ainda não tem base, o relatório DIZ que a base nasceu naquela execução |
| Conteúdo substituído pelo cliente não volta a ser o do template | OK | `conteudo.merge_tres_vias`: o ramo base ≠ observado ≠ desejado com política `gerenciado` PRESERVA — gravar ali faria o conteúdo demonstrativo do pacote vencer o texto do cliente a cada reexecução —, e o pacote só grava conteúdo em objeto que ninguém tocou. A divergência preservada sai nomeada por campo |
| Par de redirect removido pelo agente não ressuscita | OK | `lotes.redirects_uniao`: o par que estava na base e sumiu do observado é registrado como removido pelo operador, e a união não o recria — nem pela configuração, nem por etapa que o recompute — a marca é durável e mora na base de merge, não na option, porque o site-core serve TODO par gravado sem olhar a origem. Refazer o par pelo canal o traz de volta |
| Recorrência da cadência é a declarada, com o site-core ativo | OK | `cadencia.recorrencia_declarada`: quem registra `f3base_mensal` e `f3base_quinzenal` é um módulo do site-core que fica inativo enquanto `f3base_cadencia` não existir — a option que a própria etapa grava —, e sem isso o agendamento cai em `daily` com a configuração pedindo `mensal`. A option é gravada ANTES do agendamento, a etapa declara dependência de `site_core` no plano, e a queda de uma execução anterior é REPARADA quando a recorrência declarada passa a existir |
| O pacote preenche quando falta e não sobrescreve o explícito | medido no repositório do plugin | `tema.link_privacidade_preserva` e `leads.cta_preserva_destino`: o link da política preenche o `href` vazio e REMOVE o destino quando não há política publicada, em vez de apagar o parágrafo; o CTA só deixa de ser publicado quando não tem destino nenhum, e o `href` só é reescrito quando é o do modelo |
| Landing declarável por página, sem navegação e com consentimento | OK | `tema.landing_sem_navegacao`: o template está declarado em `theme.json`, não traz navegação nem por template-part — a resolução é recursiva — e traz o controle de consentimento, que precisa existir em toda página publicada |
| Chave de configuração removida sem resíduo | OK | `estatica.sem_residuo_de_chave_removida`: as chaves declaradas em `suite/chaves-removidas.tsv` saíram da configuração, do schema, do código e dos documentos, com uma exceção declarada — a memória de decisões, que precisa nomeá-las para explicar por que saíram |
| Resultado final no fim da página, e não na barra de progresso | OK | `js.decisoes_do_cliente`: o cliente REAL roda de ponta a ponta sob um DOM de mentira, e a ordem é medida na árvore montada — o nó de encerramento vem DEPOIS da tabela, o resumo não é escrito em `progresso`, e a região recebe nome acessível, `tabindex` e o foco. O piso são mutantes do próprio cliente |
| Orçamento de página e Core Web Vitals | medido no repositório do plugin | medição pede site servindo páginas e tráfego real; a regra que produziria cada número está na tabela da seção anterior. **A COLETA de Core Web Vitals existe** — LCP, CLS, INP e TTFB por `PerformanceObserver` nativo, com teto e piso em `js.comportamento_instrumentado` —, e `desempenho.core_web_vitals` continua BLOCKED de propósito: coleta existir não é o mesmo que o dado ter chegado. A pré-condição que falta é o TRÁFEGO, e só ele |
| Metade de SERVIDOR da conversão da Meta | medido no repositório do plugin | `leads.capi_meta`: o evento `Lead` sai depois da persistência confirmada, com o MESMO `event_id` que o navegador manda no Pixel — sem essa metade, o pacote pagaria o preço da deduplicação sem receber a cobertura. O envio acontece em OUTRA requisição, por evento único do agendador, e o payload viaja num transiente porque a option `cron` é autoload. E-mail e telefone saem em SHA-256 sobre o valor normalizado pela regra da META; o piso mede o payload serializado INTEIRO atrás de dado em claro, e falha HTTP da Meta não muda o status do lead nem toca na reserva de deduplicação |
| Nenhuma mensagem de runtime nomeia o arquivo errado de uma chave | OK | `estatica.residencia_de_chave_derivada`, em duas cláusulas: no implantador nenhuma string traduzível pode trazer o caminho de um arquivo de configuração DIGITADO — quem responde é `F3Base_Imp_Residencia`, cruzando o que cada leitor declara —, e fora dele a chave citada ao lado de um arquivo precisa morar nesse arquivo. O defeito medido chegava com a chave por `%s`, sem aparecer na frase, e uma regra que só comparasse chave com arquivo seria cega para ele. Os nomes dos arquivos saem da constante `ARQUIVO` de cada leitor, nunca digitados no detector; a fixture negativa planta a mensagem do log real |
| O arquivo de uma chave é derivado dela, e chave sem residência não recebe palpite | OK | `config.residencia_derivada`: o produtor acerta chave do operador, chave de conteúdo, destino de regime, mecanismo da cadência e índice numérico na forma normalizada; chave que não mora em arquivo nenhum devolve vazio, e a frase dela não nomeia arquivo nenhum. A frase do controlador é medida nos dois sentidos — precisa nomear `config/projeto.json` e não pode nomear `config/site.json`, que é o arquivo errado do log medido |
| Segredo do site fora do pacote | OK | `estatica.segredo_fora_da_configuracao`: nenhuma option da âncora `segredos_do_site()` aparece em `config/site.json`, no schema ou numa gravação do implantador. O arquivo único viaja dentro do zip e chega a quem faz o upload — a decisão de "declarar por ausência" só vale enquanto alguém mede a ausência, e a fixture negativa planta os três defeitos de uma vez |
| Envio de servidor sem token | N/A nesta base | `capi.envio_de_servidor`: `f3base_meta_capi_token` não existe no pacote e não pode existir. A condição sai declarada NOMEANDO a option, porque N/A que não diz o que preencher é N/A que ninguém sabe desfazer |
| Verificação de posse do domínio emitida do valor gravado | medido no repositório do plugin | `verificacao.tag_do_valor_gravado`: cada option preenchida emite a sua metatag e só a dela — `google-site-verification` e `facebook-domain-verification`; vazia, nada sai. Valor fora da forma é PRESERVADO, emitido escapado e avisado com a forma esperada — nunca apagado |
| Tokens de verificação não declarados | N/A nesta base | `verificacao.dominio_declarada`: as duas chaves nascem vazias, e é a presença do valor — e só ela — que faz a tag existir. Os tokens saem de console de fornecedor, que é passo humano; `TEMPLATE.md` diz o que a pessoa faz e qual é o teste de cada passo |
| Conteúdo demonstrativo medido no BANCO do site, e discriminado por quem escreveu | medido no repositório do plugin | `conteudo.demonstrativo_no_site`: o aviso conta as páginas PUBLICADAS que ainda carregam a marca e as NOMEIA, em vez de depender de uma flag que o agente nunca reescreve. Zero marcadas, zero aviso. O veredito discrimina QUEM escreveu cada página marcada — o conjunto sai do journal, nunca de lista à mão: toda marcada escrita por ESTA execução fecha OK nomeando-as (o template está no ar porque acabou de ser implantado, que é o estado declarado), e a marcada que a execução NÃO escreveu fecha WARN sozinha. O padrão vazio mantém a cadência do `site-core` avisando um mês depois, que é onde a pergunta vale. O piso mede os quatro casos: recém-implantada, sobrevivente, uma marcada ao lado de uma já substituída, e nenhuma marcada com a flag ainda em `true` |
| Um endereço do llms.txt, um dono | medido no repositório do plugin | `seo.llms_emissor_unico`: a precedência é declarada — arquivo físico na raiz vence, emissor concorrente MEDIDO vem em seguida, e só então a rota deste pacote. Com o plugin de SEO publicando o arquivo, o módulo daqui sai de cena e o estado NOMEIA quem ficou. É a mesma regra de `tracking.emissor_unico` |
| O `/llms.txt` é o PRÓPRIO, e o concorrente não é ligado por este pacote | OK | `estatica.llms_proprio_sem_concorrente`, e a unidade `seo.llms_proprio` do host. Três cláusulas: `aplicar_geral()` grava `enable_llms_txt` como o literal `false`, sempre; nenhum arquivo de `includes/` grava `wpseo_llmstxt`; e `F3Base_Imp_Seo::aplicar_llms_proprio()` relê a chave do banco, remove o agendamento `wpseo_llms_txt_population` — que repovoaria o arquivo na semana seguinte — e apaga o arquivo físico `llms.txt` da raiz SE ele for do plugin de SEO. Quem decide isso é a regra pura `veredito_do_arquivo_fisico_de_llms()`, pela assinatura do fornecedor no corpo: arquivo de OUTRA origem é preservado e sai nomeado, porque só se apaga o que se conhece. **Medido em 2026-09-07 com a 2.0.0**: com a chave ligada, o plugin de SEO gravava um arquivo físico que VENCIA a rota do site-core pela precedência declarada, e a seleção curada ia para chaves (`manual`, `pages`, `privacy_policy`) que a versão instalada não lê — o publicado era a seleção automática dele, com "Contato" selecionada e fora do arquivo e "Blog" não selecionada e dentro. A linha antiga fechava OK medindo a própria escrita. `bots_ia.llms_txt` governa SÓ o módulo do site-core |
| Conteúdo em noindex fora dos dois arquivos, com um produtor só do fato | medido no repositório do plugin | `seo.llms_noindex_respeitado`: quem responde "este ID é noindex?" é `F3Base_Modulo_Noindex_Honrado`, e o llms.txt PERGUNTA a ele. O piso recusa um segundo leitor da chave de meta, mede a regra do noindex nos três ramos, exige o dedupe por ID — URL muda quando o slug muda — e exige que a exclusão declarada alcance também o eixo automático |
| Endereço do sitemap medido, nunca fixo | medido no repositório do plugin | `seo.llms_sitemap_medido`: sitemap do plugin de SEO ligado responde em `sitemap_index.xml`; sem ele, o do núcleo em `wp-sitemap.xml`; sem nenhum dos dois, a seção inteira é OMITIDA. O núcleo desativa o endereço dele quando o plugin assume, e o endereço fixo apontaria para um arquivo que ninguém serve |
| Quem escreve e quem lê a chave do fornecedor compartilham fonte | medido no repositório do plugin | `F3Base_Chaves_Seo` declara os nomes de meta e de option do plugin de SEO num lugar só, sem pai e sem dependência: o `site-core` a carrega pelo autoload e o implantador pela cópia de origem, como já faz com a regra de emissores e com o censo demonstrativo. O implantador ESCREVE essas metas e o `site-core` as LÊ; sem fonte comum, uma renomeação do fornecedor quebraria cada lado no seu lugar, sem erro e sem aviso. `seo.llms_noindex_respeitado` recusa o literal do prefixo no adaptador e exige que as constantes do módulo de noindex saiam do vocabulário |
| Descrição de cada item pela cadeia declarada, com a fonte nomeada | medido no repositório do plugin | `seo.llms_descricao_fonte`: meta do plugin de SEO, resumo declarado no conteúdo, corte do corpo limpo — nessa ordem, e a função devolve o texto E a fonte que respondeu. Sem a fonte não há como provar que a primeira foi preferida. A meta é lida pela constante do módulo de noindex, nunca por um literal novo |
| Resumo de última instância sem interface junto | medido no repositório do plugin | `seo.llms_sem_interface_no_resumo`: shortcode removido, `form`, `script`, `style`, `nav`, `aside`, `button` e `svg` removidos COM o conteúdo, quebra de linha antes de tirar as tags, e só então o corte em palavras. O piso é literal: uma página com formulário de busca dentro não pode produzir resumo contendo o rótulo do botão |
| Ordem do llms.txt declarada, não a do banco | medido no repositório do plugin | `seo.llms_ordem`: página inicial primeiro, curadoria na ordem declarada em seguida, e só então o enumerado — páginas antes de artigos, por data decrescente. O que define o site não sai no rodapé |
| Texto integral só existe com a chave ligada | medido no repositório do plugin | `seo.llms_full_servido`: `/llms-full.txt` usa a MESMA seleção e a mesma precedência de emissor do índice curto, e com `bots_ia.llms_full_txt` desligada o módulo fecha inativo — nenhum hook, nenhuma rota, nenhuma superfície pública. Desligado por padrão: é uma segunda cópia integral do site em texto puro |
| Modo somente-relatório comparado com a BASE | OK | `relatorio.mudanca_desde_a_aplicacao`: a linha é REGISTRO DO QUE MUDOU DESDE A ÚLTIMA APLICAÇÃO, com os dois valores — comparar com `config/site.json` transformaria toda edição legítima do agente em "divergência" permanente, num relatório que roda na cadência para sempre; a comparação com a configuração desce para a SEGUNDA linha, rotulada, porque tem leitor: quem for reexecutar |
| `hidden` governa a visibilidade, ou o `display` de autor tem par declarado | OK | `estatica.hidden_governa_visibilidade`: `[hidden] { display: none }` é regra da folha do USER AGENT, e qualquer declaração de autor a vence — a origem decide antes de a especificidade ser consultada, e um `display` de autor solto sobre uma classe alternada por `hidden` deixa o elemento na tela com o `hidden` inerte. O par aceito é `.classe[hidden] { display: none }` (0,2,0 contra 0,1,0) ou o global com `!important`; um `[hidden]` global SEM `!important` empata e perde na ordem |
| Banner de consentimento: nasce fechado, os três botões fecham, o estado aparece ao reabrir | OK | `js.banner_de_consentimento`: a bancada roda o cliente REAL contra um DOM de mentira e decide visibilidade pelo `style.css` REAL, com o par (`hidden`, `display`) — `hidden === true` não é resposta quando uma regra de autor declara `display` sobre a mesma classe. O controle é um link de texto "Política de Cookie", o banner mora na BASE do viewport e não cobre a página, aceitar e recusar gravam E fecham, fechar fecha SEM decidir, o foco vai para o banner e VOLTA para o controle, e o corpo ganha e devolve a altura da faixa. O piso é o mutante escrito na sonda: com `display` de classe e sem o par `[hidden]`, a bancada TEM de ver o banner visível na carga e o "Fechar" que não fecha |
| O site nasce instrumentado para COMPORTAMENTO | medido no repositório do plugin | `js.comportamento_instrumentado`: seis coletores pelo mesmo portão das quatro tags e nos dois formatos — rolagem por marco, seção vista pelo NOME que o markup declara, clique em link externo com o HOST e só ele, fricção no limiar declarado, erro de JavaScript com a ORIGEM como portão, e LCP/CLS/INP/TTFB por `PerformanceObserver` nativo sem biblioteca externa. O piso é o FALSO POSITIVO e a RAJADA: duplo clique, triplo clique, cliques espalhados, cliques em controles diferentes e cliques em texto não podem produzir fricção; erro de terceiro e de extensão não podem virar erro do site; a rajada bate no teto declarado; e com consentimento negado ou slot vazio nada é emitido |
| Nome de evento de comportamento num lugar só | medido no repositório do plugin | `tracking.eventos_de_comportamento_declarados`: nome, parâmetro, teto por página e limiar moram em `dados/eventos-comportamento.tsv`, DENTRO do plugin, e nenhum deles aparece como literal no JavaScript dele — o cliente pede a declaração pelo GATILHO, que é a chave de junção, e recebe os parâmetros posicionalmente. Quem lê esta série é um agente comparando períodos: nome que muda entre releases é o relatório do mês seguinte vazio, sem erro nenhum |
| Os dados da instrumentação são VISÍVEIS dentro do site | medido no repositório do plugin | `comportamento.resumo_agregado`: os seis coletores vão do navegador para a conta de medição, e sem um resumo do próprio site os eventos não existiriam em lugar nenhum com o slot vazio. O resumo AGREGADO de cada sessão entra por rota própria, com schema fechado no corpo e dentro de cada total, teto de tamanho, o MESMO balde atômico do endpoint de leads e status coerente com o corpo, e é somado numa tabela por dia, caminho, evento e detalhe. Duas sessões somam na mesma linha, numa instrução só; sem a tabela pronta a rota responde 503 nomeando a perda, nunca 201 sobre nada gravado |
| Nenhum dado pessoal no resumo de comportamento | medido no repositório do plugin | `comportamento.resumo_agregado` e `js.resumo_da_sessao`: não há identificador de visitante — nada é gravado em `localStorage`, `sessionStorage` nem cookie, e a sessão vive na memória da aba —, o caminho viaja sem query e sem fragmento, e o detalhe passa por um alfabeto fechado sem barra, arroba, dois-pontos nem espaço. E-mail, caminho de perfil, telefone, identificador de sessão e URL com query são recusados pelo nome; o arquivo do erro de JavaScript não viaja, porque a página já é a chave e o arquivo interpolado é onde mora o valor do titular |
| Retenção do resumo declarada e executada | medido no repositório do plugin | `comportamento.resumo_agregado`: o prazo mora em `f3base_comportamento.retencao_dias`, é operável na tela, e quem o cumpre é a rotina de retenção que já existia — prazo cumprido por uma segunda rotina é prazo que se cumpre pela metade no dia em que ela não roda. O piso mede a linha velha saindo e a segunda poda não apagando nada dentro do prazo |
| Todo campo operável diz o IMPACTO e traz um EXEMPLO | medido no repositório do plugin | `estatica.campo_operavel_tem_impacto_e_exemplo`: toda folha do catálogo diz o que MUDA no site quando o campo é preenchido, e não só o rótulo da option. Segredo não tem exemplo de valor, e identificador de fornecedor sai na FORMA que o próprio pacote declara em `formas()` — exemplo que parece um identificador real é um identificador real esperando para ser colado |
| A tela é agrupada por assunto, e o exemplo nunca entra no campo | medido no repositório do plugin | `tela.campo_diz_impacto_e_exemplo`: medido no DOM que o operador recebe. Quatro blocos de preenchimento na ordem de instalar um site, seguidos das duas leituras; nenhum `placeholder` em lugar nenhum e nenhum exemplo dentro de um `value` — exemplo em placeholder é valor fantasma que some ao digitar e é lido como conteúdo do campo. O diagnóstico continua completo: mudou de lugar, não de tamanho |
| O quadro de comportamento diz o que ele NÃO é | OK | `tela.resumo_de_comportamento`: com zero sessões ele DIZ que não há dados e nomeia as causas, em vez de mostrar zeros que parecem medição; com dados, mostra os totais com o período ao lado e declara que contam só as sessões com consentimento. E diz onde está o que não está ali: com o measurement ID vazio, que nenhum evento chega ao GA4 e o quadro é tudo o que existe; com ele gravado, que este resumo não substitui o relatório do fornecedor |
| A releitura de bloco existe como dado, e a linha é a MESMA nos dois sentidos | medido no repositório do plugin | `js.sessao_com_releitura`: o observador de seções é armado com os thresholds `[0, visivel]` e decide por `intersectionRatio >= visivel` — a MESMA linha declarada na entrada e na saída. Antes, entrava-se no limiar declarado e só se saía em `isIntersecting === false`, que na especificação é razão ZERO: caindo de 0,6 para 0,4 o navegador avisava, o alvo continuava sobreposto, o coletor não rearmava, e o bloco só voltava a contar saindo INTEIRO da tela. Medido em produção: 80 linhas, todas com `ocorrencia = 1`, nenhuma reentrada. O piso é um ciclo dirigido SÓ por rolagem — desce até o fim, volta ao topo e desce de novo — numa página curta em que dois blocos nunca saem inteiros do campo de visão, com a mutação do código antigo tendo de deixá-los presos em uma ocorrência só |
| A bancada de comportamento tem GEOMETRIA, e não só botões | medido no repositório do plugin | `js.sessao_com_releitura`: cada seção do documento falso tem topo e altura, `rolarAte()` calcula a razão de interseção contra a janela e entrega o retorno do observador a quem mudou de faixa de threshold OU de estado de sobreposição — as duas condições da especificação. É o conserto da metade que deixou o defeito passar: a bancada anterior disparava `isIntersecting` À MÃO, `rolarAte(95)` não movia seção nenhuma, e o retorno intermediário do navegador — sobreposto, com a razão abaixo do limiar — nunca era produzido |
| O marco de rolagem tem BANDA declarada na fronteira | medido no repositório do plugin | `js.sessao_com_releitura`: `histerese_pp` mora no limiar da `rolagem` e o marco só rearma abaixo de `marco - histerese_pp`. Fronteira sem banda transforma TREMOR em leitura — um pixel de oscilação na linha, o cabeçalho que recolhe, a imagem que entra e empurra a altura fabricam travessia que ninguém fez. O número mora na declaração, ao lado dos marcos que ele protege, e não no JavaScript; para a seção, a banda `[0, visivel]` já é a histerese, e um segundo número seria um que ninguém revisaria junto com o `visivel` |
| A travessia ATRAVESSA o carregamento, e o estado armado não | medido no repositório do plugin | `js.sessao_com_releitura`: o contador de travessias vive no registro da VISITA, no `localStorage`, chaveado por caminho, gatilho e detalhe — `pecas` em `/` e `pecas` em `/arquitetura/` são seções diferentes com o mesmo nome, e somá-las esconderia as duas. Até a 1.3.3 ele era variável do CARREGAMENTO: medido em produção na visita `8bb0a2d5` de `fator3-teste-mcp-1`, dois carregamentos de `/` na mesma visita saíram os dois com ocorrência 1, e o limiar chamado `travessias_por_sessao` contava carregamento. O que NÃO persiste é o estado armado (`dentro`, `dentroDaVista`): a página nova começa com nada em vista, e é assim que o bloco do topo dela é registrado em vez de engolido. O piso são seis casos dirigidos SÓ por rolagem, com a bancada herdando o `localStorage` do carregamento anterior, e DUAS mutações que têm de acusar em pisos diferentes — o contador em memória do carregamento e o estado armado persistido junto |
| O desligamento da medição é ENCONTRÁVEL, e não ganhou chave nova | medido no repositório do plugin | `medicao.menu_proprio`: a tela Medição diz, antes de qualquer número, onde a medição se desliga, e leva ao campo por link com âncora produzida por `F3Base_Admin_Tela::id_do_subcampo()` — produtor único, cruzado com o `id` que a tela de configuração emite, porque âncora montada como literal nos dois lados continua existindo e deixa de levar a lugar nenhum. Com `f3base_comportamento.ligado` falso, a PRIMEIRA coisa da tela é o desligamento nomeado, e não uma tabela vazia silenciosa — que é indistinguível de um site sem visita. A chave é a que já existia: duas chaves para a mesma decisão são duas respostas para "esta instalação mede?" |

Os BLOCKED continuam BLOCKED pelo mesmo motivo de sempre: pedem uma instalação servindo
páginas, e a árvore do pacote não é uma. Nenhum deles é defeito. Um manifesto que os
fechasse em OK seria o defeito que este pacote inteiro existe para impedir: um registro
afirmando sobre um artefato que ninguém leu de volta. E a distinção continua valendo:
BLOCKED de FASE declarada não impede a autodesativação — quem a decide
é o gate de APLICAÇÃO, que lê nomes de entregável, nunca a linha de uma unidade.
