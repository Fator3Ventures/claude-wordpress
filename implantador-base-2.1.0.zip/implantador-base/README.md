<!-- gerado:inicio=carimbo -->
# implantador-base 2.1.0 — leia-me

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio, e o documento passa a descrever um pacote que não é este. O que não pode ser gerado
> no momento da escrita sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `2.1.0` |
| Implantador · tema · plugin | `2.1.0` · `1.6.2` · `1.0.0` |
| Bundle desta identidade | `implantador-base-2.1.0.zip` |
| Origens de release suportadas | 47 além da instalação limpa |
| Caminhos exatos no inventário | 118 |
| Prefixos declarados no inventário | 4 |
| Arquivos no pacote (fora de `dist/` e dos produtos da rodada) | 400 |
| Requisitos em `suite/manifesto.tsv` | 222 |
| Armadilhas com checagem mapeada | 122 |
| Armadilhas em pendência declarada | 11 |
| Detectores com piso em disco | 65 |
| Ramos de piso (negativa + positiva) | 130 |
| Páginas · posts declarados | 6 · 2 |
| Reserva do plugin na árvore | `assets/plugins/base-site-core-fator3-1.0.0.zip` |
| `sha256` da reserva · declarado no catálogo | `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f` · `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f` |
| Arquivos vendorizados em `partilhado/` | 6 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

Pacote-fábrica do Método F3: um plugin de implantação que aplica um estado desejado
declarado em um arquivo único, embarcando o tema de blocos `f3base` e o plugin
persistente `base-site-core-fator3`. O site que ele produz fala sobre o próprio método.

Este arquivo cobre o que o operador precisa para instalar, executar, reverter e
desligar. **Os documentos que respondem o resto viajam DENTRO do pacote, na raiz**, e
desde a 2.1.0 são estes:

| Documento | O que ele responde |
|---|---|
| `README.md` | instalar, executar, reverter, desligar — este arquivo |
| `MANIFESTO.md` | identidade da release, inventário de caminho para papel, e a fronteira entre checksum de artefato nosso e fato observado de terceiro |
| `MEMORIA-DECISOES.md` | o porquê de cada decisão, com o que ela custa e como reverter |
| `TEMPLATE.md` | a ordem executável para derivar um site novo deste template |
| `MAPA-DA-OPERACAO.md` | o mapa de quem RECEBE o pacote: quais documentos existem, as três peças, o fluxo de ponta a ponta e o que se publica no catálogo |
| `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md` | as instruções para construir um implantador a partir deste template, e as regras do plugin que o tema e as páginas precisam seguir |

**Os dois últimos entraram na 2.1.0, e por decisão do dono: quem recebe o zip recebe
também como usá-lo e como construir o próprio.** Eles estão no inventário e são cobrados
pelo entregável `entrega.documentacao`, junto com `MANIFESTO.md` e `TEMPLATE.md` — ausência
fecha BLOCKED nomeando o arquivo que falta, e o entregável entra no gate de aplicação como
os outros. Um pacote sem eles é um pacote que exige procurar em outro lugar como ele se
usa, e o outro lugar não viaja junto.

O comando único é `bash suite/verificar.sh <caminho-do-pacote>`, com caminho ABSOLUTO;
`bash suite/verificar.sh piso` roda só o piso dos detectores. O locale é `pt_BR` e o fuso
`America/Sao_Paulo`. O prefixo técnico é `f3base` para handles, text domain e slugs, e
`f3base_` para options e metas.

## Árvore de arquivos

**A fonte do TEMA mora em `fontes/`, e a profundidade é regra, não
organização.** `get_plugins()` varre a raiz do plugin e UM
nível de subdiretório: um segundo cabeçalho de plugin dentro desse alcance — `plugin/base-site-core-fator3.php`,
por exemplo — entra na varredura, e a tela de instalação passa a oferecer o arquivo errado no link
"Ativar plugin". Em `fontes/` não existe `.php` direto, e os arquivos reais ficam fora
do alcance. Quem prova isso a cada rodada é `pacote.sem_cabecalho_de_plugin_aninhado`. O
diretório do plugin mudou de nome na 1.7.0 — `fontes/site-core/` virou `fontes/plugin/` — e
SAIU desta árvore na 2.0.0; o que nunca pôde mudar é a PROFUNDIDADE do que ficou.

**A fonte do plugin não mora mais neste repositório.** Desde a 1.7.0 o
`base-site-core-fator3` é artefato próprio; desde a 2.0.0 ele tem REPOSITÓRIO próprio, com
suíte, bancada e documentos dele. Nada aqui constrói, monta ou edita o plugin. O que esta
árvore carrega dele são duas cópias, e as duas são conferidas contra o artefato PUBLICADO:

- a **RESERVA** `assets/plugins/base-site-core-fator3-<versão>.zip` — o zip do catálogo
  copiado byte a byte, ENTRADA de build e não saída, conferida por
  `pacote.reserva_confere_com_o_catalogo` contra o `sha256` que `config/decisoes.tsv`
  declara;
- **`partilhado/`** — a cópia VENDORIZADA das regras que o implantador precisa ler ANTES de
  o plugin existir na instalação, declarada arquivo a arquivo em `partilhado/VENDORIZADO.tsv`
  e conferida byte a byte contra a reserva por `pacote.copia_vendorizada_confere`.

O dono dos dois é o repositório do plugin. Editar `partilhado/` à mão é fork.

<!-- gerado:inicio=arvore -->
### Árvore de arquivos

Gerada de disco na montagem desta release. A allow-list executável que decide o que
entra no bundle é `suite/inventario.tsv`.

```
implantador-base/
  INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md
  MANIFESTO.md
  MAPA-DA-OPERACAO.md
  MEMORIA-DECISOES.md
  README.md
  TEMPLATE.md
  assets/favicon.png
  assets/logo.png
  assets/logo.svg
  assets/plugins/LEIA-ME.txt
  assets/plugins/base-site-core-fator3-1.0.0.zip
  assets/social.png
  config/decisoes.tsv
  config/projeto.json
  config/projeto.schema.json
  config/releases-suportadas.tsv
  config/site.json
  config/site.schema.json
  content/pages/arquitetura.html
  content/pages/contato.html
  content/pages/home.html
  content/pages/manutencao.html
  content/pages/privacidade.html
  content/pages/verificacao.html
  content/posts/o-artefato-decide-o-registro-e-diagnostico.html
  content/posts/por-que-checagem-que-nunca-falhou-nao-e-evidencia.html
  ferramentas/classificacao-config.tsv
  ferramentas/excecoes-de-prefixo.tsv
  ferramentas/nomes-preservados.php
  ferramentas/prefixo-do-template.tsv
  ferramentas/prefixos-recusados.tsv
  ferramentas/renomear-prefixo.php
  ferramentas/renomear-prefixo.sh
  fontes/tema/CONTRASTE.md
  fontes/tema/functions.php
  fontes/tema/parts/footer.html
  fontes/tema/parts/header.html
  fontes/tema/patterns/cta-whatsapp.php
  fontes/tema/patterns/faq.php
  fontes/tema/patterns/hero.php
  fontes/tema/patterns/secao-cartoes.php
  fontes/tema/patterns/secao-texto.php
  fontes/tema/style.css
  fontes/tema/templates/404.html
  fontes/tema/templates/archive.html
  fontes/tema/templates/front-page.html
  fontes/tema/templates/index.html
  fontes/tema/templates/landing.html
  fontes/tema/templates/page.html
  fontes/tema/templates/search.html
  fontes/tema/templates/single.html
  fontes/tema/theme.json
  implantador-base.php
  includes/assets/implantador.css
  includes/assets/implantador.js
  includes/class-f3base-imp-admin.php
  includes/class-f3base-imp-config.php
  includes/class-f3base-imp-conteudo.php
  includes/class-f3base-imp-decisoes.php
  includes/class-f3base-imp-entrega.php
  includes/class-f3base-imp-fases.php
  includes/class-f3base-imp-formulario.php
  includes/class-f3base-imp-gravador.php
  includes/class-f3base-imp-journal.php
  includes/class-f3base-imp-limpeza.php
  includes/class-f3base-imp-lotes.php
  includes/class-f3base-imp-navegacao.php
  includes/class-f3base-imp-plano.php
  includes/class-f3base-imp-plugins.php
  includes/class-f3base-imp-preflight.php
  includes/class-f3base-imp-projeto.php
  includes/class-f3base-imp-relatorio.php
  includes/class-f3base-imp-residencia.php
  includes/class-f3base-imp-seo.php
  partilhado/VENDORIZADO.tsv
  partilhado/dados/contrato-de-nomes.tsv
  partilhado/dados/emissores-conhecidos.tsv
  partilhado/includes/class-f3base-censo-demonstrativo.php
  partilhado/includes/class-f3base-chaves-seo.php
  partilhado/includes/class-f3base-emissores.php
  partilhado/includes/class-f3base-vocabulario.php
  suite/afirmacoes.tsv
  suite/armadilhas.tsv
  suite/casos-de-emissor.tsv
  suite/casos-de-emissor/renderizado-dois-emissores.html
  suite/casos-de-emissor/renderizado-gtm-com-gtag.html
  suite/casos-de-emissor/renderizado-gtm-limpo.html
  suite/casos-de-emissor/renderizado-um-emissor.html
  suite/casos-de-emissor/servido-config-de-fora.html
  suite/casos-de-emissor/servido-emissor-de-fora.html
  suite/casos-de-emissor/servido-emissor-sem-slot.html
  suite/casos-de-emissor/servido-so-o-carregador.html
  suite/chaves-removidas.tsv
  suite/checagens/a11y.php
  suite/checagens/bloqueadas.php
  suite/checagens/conteudo.php
  suite/checagens/copy.php
  suite/checagens/entrega.php
  suite/checagens/estatica.php
  suite/checagens/funcional.php
  suite/checagens/js.mjs
  suite/checagens/meta.php
  suite/checagens/tema.php
  suite/excluidas.tsv
  suite/fases.json  (produto da rodada: gravado no fim do comando único)
  suite/fixtures/a11y.contraste/  (2 arquivo(s) de piso)
  suite/fixtures/config.slug_declarado/  (2 arquivo(s) de piso)
  suite/fixtures/conteudo.demonstrativo/  (4 arquivo(s) de piso)
  suite/fixtures/conteudo.headings/  (4 arquivo(s) de piso)
  suite/fixtures/conteudo.marca_demonstrativa/  (4 arquivo(s) de piso)
  suite/fixtures/conteudo.sem_estilo_avulso/  (2 arquivo(s) de piso)
  suite/fixtures/copy.contrato/  (6 arquivo(s) de piso)
  suite/fixtures/decisoes.fonte_unica/  (8 arquivo(s) de piso)
  suite/fixtures/doc.afirmacao_conferida/  (8 arquivo(s) de piso)
  suite/fixtures/estatica.artefato_do_pacote_e_lido/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.carimbo_de_release_nos_documentos/  (16 arquivo(s) de piso)
  suite/fixtures/estatica.contagem_com_nomes/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.conteudo_declara_secoes/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.destino_de_formulario_resolve/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.detector_chave_sem_consumidor/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.detector_codigo_em_string/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.detector_condicao_literal/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.detector_escrita_unica/  (5 arquivo(s) de piso)
  suite/fixtures/estatica.detector_placeholder/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.detector_version_compare/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.estados_fechados/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.gate_de_fase_do_metadado/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.gate_de_fase_sem_ramo_de_falha/  (3 arquivo(s) de piso)
  suite/fixtures/estatica.gate_fonte_unica/  (9 arquivo(s) de piso)
  suite/fixtures/estatica.hidden_governa_visibilidade/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.identidade_do_implantador/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.js_lint/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.json_valido/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.llms_proprio_sem_concorrente/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.llms_so_pagina_publicada/  (6 arquivo(s) de piso)
  suite/fixtures/estatica.option_fonte_unica/  (6 arquivo(s) de piso)
  suite/fixtures/estatica.option_gravada_sem_leitor/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.pagina_status_fonte_unica/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.php_lint/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.piso_em_sonda_declarado/  (5 arquivo(s) de piso)
  suite/fixtures/estatica.plano_dependencias/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.politica_privacidade_fonte_unica/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.residencia_de_chave_derivada/  (12 arquivo(s) de piso)
  suite/fixtures/estatica.resposta_de_lote_nomeada/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.segredo_fora_da_configuracao/  (8 arquivo(s) de piso)
  suite/fixtures/estatica.sem_recusa_de_escrita_do_agente/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.sem_residuo_de_chave_removida/  (10 arquivo(s) de piso)
  suite/fixtures/estatica.sem_residuo_de_prefixo/  (10 arquivo(s) de piso)
  suite/fixtures/estatica.simbolos_resolvem/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.troca_invalida_cache/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.unidade_reflete_internas/  (6 arquivo(s) de piso)
  suite/fixtures/estatica.warn_tem_ramo_adverso/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.wp_comentarios_balanceados/  (4 arquivo(s) de piso)
  suite/fixtures/mcp.fronteira_do_validador/  (7 arquivo(s) de piso)
  suite/fixtures/pacote.allow_list/  (5 arquivo(s) de piso)
  suite/fixtures/pacote.backup_sempre_oculto/  (2 arquivo(s) de piso)
  suite/fixtures/pacote.build_fresco/  (4 arquivo(s) de piso)
  suite/fixtures/pacote.sem_cabecalho_de_plugin_aninhado/  (6 arquivo(s) de piso)
  suite/fixtures/plugins.serie_de_backup_normalizada/  (2 arquivo(s) de piso)
  suite/fixtures/release.declara_a_anterior/  (4 arquivo(s) de piso)
  suite/fixtures/tela.fala_portugues_comum/  (2 arquivo(s) de piso)
  suite/fixtures/tema.landing_sem_navegacao/  (4 arquivo(s) de piso)
  suite/fixtures/tema.main_layout_default/  (2 arquivo(s) de piso)
  suite/fixtures/tema.preset_inexistente/  (2 arquivo(s) de piso)
  suite/fixtures/tema.preset_ocioso/  (2 arquivo(s) de piso)
  suite/fixtures/tema.sem_cor_literal/  (4 arquivo(s) de piso)
  suite/fixtures/tema.versao_assets/  (4 arquivo(s) de piso)
  suite/fixtures/tema.wp_html_declarado/  (6 arquivo(s) de piso)
  suite/fixtures/tema.zero_com_unidade/  (2 arquivo(s) de piso)
  suite/fixtures/tracking.emissor_unico_discrimina/  (8 arquivo(s) de piso)
  suite/inventario.tsv
  suite/lib/documentos.php
  suite/lib/empacotar.php
  suite/lib/executar.php
  suite/lib/piso.php
  suite/lib/regra.php
  suite/lib/render-pattern.php
  suite/lib/sonda-bundle.php
  suite/lib/sonda-fases.php
  suite/lib/sonda-funcional.php
  suite/lib/sonda-gravador.php
  suite/lib/sonda-hash.php
  suite/lib/sonda-instalacao.php
  suite/lib/sonda-renomeacao-secao.mjs
  suite/lib/sonda-renomeacao.php
  suite/lib/sonda-serie.php
  suite/lib/sonda-tema.php
  suite/manifesto.tsv
  suite/pisos-em-sonda.tsv
  suite/rodada.json  (produto da rodada: gravado no fim do comando único)
  suite/verificar.sh
```
<!-- gerado:fim=arvore -->

## Um arquivo para instalar, e de onde vem o plugin

O pacote entrega **um zip**: `implantador-base-X.Y.Z.zip`. Instale, ative e rode; ele se
desativa quando termina. **O plugin do site não é instalado à mão** — quem o instala é o
implantador, pela origem declarada em `plugins.instalaveis`, na ordem em que ele tenta:

| origem | quando ela responde | o que é conferido |
|---|---|---|
| `assets/plugins/base-site-core-fator3.zip` — o slot do OPERADOR, sem número no nome | quando o operador embutiu um zip por decisão explícita | o `sha256` declarado no catálogo, como em qualquer outra origem |
| a URL declarada no catálogo, **em https** | é o caminho normal, e é ela que entrega a correção a um site já no ar | o `sha256` declarado, conferido ANTES de instalar |
| `assets/plugins/base-site-core-fator3-<versão>.zip` — a RESERVA versionada que viaja no bundle | quando a URL não responde | o MESMO `sha256`: reserva que não é o zip que o catálogo declara não instala |

**Os dois números continuam independentes, e desde a 2.0.0 uma release do plugin custa uma
release do implantador.** A numeração de cada um é própria — o plugin sobe quando o plugin
muda —, mas a reserva e a cópia vendorizada moram nesta árvore, e trocá-las muda os bytes
do pacote. O ciclo inteiro, deste lado, está em "O plugin tem release própria, e publicar o
zip é um passo".

**Depois da entrega, o site é alterado por agente MCP** — tema, plugins e conteúdo. O
plugin registra a habilidade `f3base/como-usar`, que diz ao agente o que ele já faz e por
onde mudar cada coisa, e as habilidades `f3base/config-ler` e `f3base/config-escrever`,
que deixam o agente preencher `config/projeto.json` sem editar arquivo às cegas.

**Essas duas habilidades são uma FRONTEIRA entre os dois artefatos, e ela passou a ser
medida na 2.0.0.** Elas moram no plugin e carregam `includes/class-f3base-imp-config.php`
do implantador, chamam `F3Base_Imp_Config::validar_com_schema()` e leem e gravam
`config/projeto.json`, `config/projeto.schema.json`, `config/site.json` e
`config/site.schema.json` — arquivos desta árvore. Nada conferia isso: um método renomeado
ou um schema movido aqui quebraria o agente do outro lado, em produção, sem que nenhuma
rodada acusasse. `mcp.fronteira_do_validador` lê a classe de habilidades de DENTRO da
reserva e cobra que tudo o que ela espera encontrar exista neste pacote.

## Os quatro arquivos de configuração, e o que decide em qual deles

**O operador abre um arquivo só: `config/projeto.json`.** Os outros três descrevem o
pacote, e ele não precisa tocá-los para pôr um site no ar.

| arquivo | o que guarda | quem responde |
|---|---|---|
| `config/projeto.json` | o que ESTE site tem de decidir: contato, qualificação do controlador, fato jurídico, identificadores de conta, verificação de domínio, dados da organização no grafo, os regimes de formulário | o operador |
| `config/site.json` | o conteúdo declarado, as referências internas entre objetos e a identidade técnica do pacote renomeado | o agente que instancia o template |
| `config/decisoes.tsv` | as decisões do PACOTE, cada uma com o MOTIVO escrito ao lado | quem mantém o pacote |
| `config/releases-suportadas.tsv` | de qual versão instalada este implantador sabe subir | a história de homologação do pacote |

**A regra que decide em qual arquivo uma coisa mora.** Uma chave de configuração só se
justifica se passar nas **duas** metades: existe projeto legítimo em que o valor certo é
DIFERENTE, **e** o valor é impossível de derivar do site, do exemplo ou do ambiente.

Valor com uma resposta certa só reprova a primeira metade — e chave que só pode ter uma
resposta certa não é ponto de extensão, é um comentário com preço de configuração. Ela não
ganha padrão melhor: sai da configuração e vira linha de `config/decisoes.tsv`, com o motivo
que a sustenta ao lado. O motivo é normativo e diz **o que aconteceria se o valor fosse
outro** — motivo que só repete o valor em prosa não sustenta nada e não sobrevive à primeira
pergunta. Quem lê o catálogo é `F3Base_Imp_Decisoes`, e mais ninguém: repetir o valor de uma
decisão como literal fora do produtor é a segunda fonte que `decisoes.fonte_unica` reprova —
chave que volta para a configuração ou para o schema, leitura por outro caminho, padrão
repetido na chamada e valor de texto virando constante são todos achado.

**Cada campo de `config/projeto.json` nasce vazio**, com uma exceção declarada: onde o
template tem um valor obviamente certo para o contexto dele — o fuso é o caso —, o campo
nasce preenchido e o `$comment` do schema diz que aquele é o valor do template e em que
situação trocá-lo. Campo que nasce certo é melhor que campo que nasce vazio; o que não pode
é campo que nasce vazio quando existe resposta certa. Cada `$comment` diz também **onde
obter** o valor — o console do fornecedor, o contrato social, o painel da hospedagem —,
porque o operador não deveria precisar de nós para saber onde achar o que preenche.

**A MENSAGEM PERGUNTA em qual arquivo a chave mora; ela não afirma.** Nenhuma linha do
relatório traz o nome de um arquivo de configuração digitado dentro dela: quem responde é
`F3Base_Imp_Residencia`, que cruza o que cada leitor DECLARA — `F3Base_Imp_Projeto` e
`F3Base_Imp_Config` — e devolve o arquivo. O defeito que produziu essa classe estava medido
num log de instalação limpa: a guarda da política mandava preencher
`contato.controlador.razao_social` **em `config/site.json`**, e essa chave mora em
`config/projeto.json`. Quem seguisse a instrução editava o arquivo errado, as chaves não
passavam a existir e a política ficava em `draft` para sempre — a mensagem que existe para
desbloquear o operador era a que o prendia. Aquela guarda saiu na 2.1.0; a classe ficou,
porque o defeito que ela fecha é sobre TODA mensagem que cita uma chave. Mover uma chave de
arquivo passou a mover a instrução junto, na mesma execução, e
`estatica.residencia_de_chave_derivada` recusa qualquer nome de arquivo que volte a ser
digitado numa mensagem. Chave que não mora em arquivo nenhum **não recebe palpite**: a frase
diz "no arquivo de configuração em que ela estiver declarada" e o caminho da chave continua
nomeado ao lado.

**Vazio não é erro por si, e degrada como o resto do pacote.** Quando a ausência só desliga
um recurso, a linha fecha **N/A** com a condição declarada, nomeando a chave a preencher e
dizendo que preenchê-la faz o recurso existir. **BLOCKED ficou reservado para pré-condição
que o PACOTE precisa e não tem** — origem de plugin inalcançável, capacidade ausente,
gatilho de cadência que não existe nem observado nem declarado. Dado do operador que
falta não fecha BLOCKED desde a 2.1.0: ele é responsabilidade do operador, e a
consequência de não preenchê-lo sai declarada na linha em vez de segurar a entrega.

### A ordem da operação: preencher, executar uma vez, ajustar pelo canal

**O operador preenche `config/projeto.json` ANTES da execução única** — controlador (razão
social, CNPJ, endereço), base legal e prazo de retenção, número de WhatsApp, identificadores
de medição e tokens de verificação de domínio. **Depois da execução, o ajuste é pelo canal
MCP**, e não por uma segunda execução: `f3base_contato`, `f3base_ga4_measurement_id`,
`f3base_verificacao_google` e as demais são options operáveis, e a página da política é um
post que o agente edita.

**O que acontece com o controlador vazio, dito com todas as letras: a política de
privacidade PUBLICA, e publica com o marcador vazio à vista de quem abrir a página.** Até
a 2.0.0 uma guarda medida a segurava em `draft` até razão social, CNPJ e endereço estarem
preenchidos, e `privacidade.controlador_identificado` fechava BLOCKED. As duas saíram por
decisão do dono: o que a política afirma é responsabilidade de quem responde por ela, e o
implantador não confere o texto jurídico de ninguém. **O status de TODA página é o
DECLARADO.** O que o pacote continua fazendo é interpolar: os marcadores
`%f3base:contato.controlador.*%` do arquivo de conteúdo viram o valor daquele caminho,
escapado, e vazio vira vazio. Quem não preencher antes da execução preenche pelo canal
depois — e, enquanto não o fizer, a página no ar diz menos do que a lei pede.

**Base legal, prazo de retenção e padrão de consentimento são um fato só com três faces.** A
base sustenta o tratamento, o prazo é a proporcionalidade dessa base à finalidade, e o
padrão de consentimento é a postura que ela implica no navegador. As duas primeiras moram
juntas em `fato_juridico`, no arquivo do operador; a terceira é decisão do pacote, em
`config/decisoes.tsv`. **O pacote lê as duas do operador e não julga nenhuma**:
`fato_juridico.base_legal` alimenta o texto da política e `retencao_leads_meses` alimenta a
retenção do `site-core`. Até a 2.0.0 `projeto.fato_juridico_coerente` as media como
conjunto e chamava de incoerente preencher uma e deixar a outra; a checagem saiu na 2.1.0,
declarada em `suite/excluidas.tsv` com categoria `retirada`, porque a declaração jurídica é
de quem responde pelo site. Nenhuma preenchida é o estado de entrega do template: o pacote
não declara base legal de ninguém.

**O vocabulário é compartilhado pelos dois runtimes.** O implantador ESCOLHE — no catálogo —
qual modelo de atribuição usar, que política de frame enviar, qual plugin ocupa o papel de
SEO. O `site-core` RECONHECE esses valores: o sanitizador precisa do conjunto aceito para
recusar lixo, e o módulo precisa ramificar sobre o valor que recebeu. O conjunto mora em
`F3Base_Vocabulario`, sem pai e sem dependência, e o DONO dela é o repositório do plugin: o
que existe em `partilhado/` é a cópia vendorizada dessa classe, que o implantador alcança
quando o plugin ainda não existe na instalação — o preflight roda antes de instalar
qualquer coisa. A cópia é conferida byte a byte contra a reserva por
`pacote.copia_vendorizada_confere`, e o motivo é medido: na 1.7.4 esta classe divergia do
zip publicado em duas chaves de cabeçalho que o plugin 1.0.0 governa, e nada acusava.
Duas fontes com papéis diferentes só são seguras quando
alguém as cruza, e é `decisoes.fonte_unica` que cruza: toda decisão que o vocabulário governa
precisa valer um dos valores que ele declara, e todo papel que ele fixa precisa achar no
catálogo uma entrada com exatamente aquele slug.

## Este pacote é um template de criação de sites

O site que ele instala fala sobre o próprio método, e isso é deliberado: o site
demonstrativo **fica**, marcado como substituível, porque é o exemplo funcionante de cada
padrão — o agente que cria um site novo copia dele em vez de inventar markup.

Para criar um site novo a partir daqui, o procedimento executável está em **`TEMPLATE.md`**,
e ele começa pela renomeação do prefixo:

```
cp -a implantador-base <pasta-do-site-novo>
bash <pasta-do-site-novo>/ferramentas/renomear-prefixo.sh <prefixo> <pasta-do-site-novo>
```

Cada site recebe o próprio prefixo técnico — diretório e slug do TEMA, prefixo das options
e das metas DO IMPLANTADOR, text domain, handles, classes CSS de identidade e prefixo das
classes PHP —, e dois sites da operação nunca compartilham nome de tema nem de option do
implantador.

**O PLUGIN NÃO ENTRA NA RENOMEAÇÃO, e isso mudou duas vezes.** Na 1.7.0
`ferramentas/excecoes-de-prefixo.tsv` passou a declarar `fontes/plugin/` e `partilhado/`
como caminhos que a renomeação não atravessa: renomear a fonte do plugin produzia um FORK
por site, com options `<prefixo>_ga4_measurement_id` em vez de `f3base_ga4_measurement_id`,
e um plugin cujo nome de option muda por site não é um plugin — são N plugins parecidos, e
nenhuma correção publicada alcança nenhum deles. Na 2.0.0 `fontes/plugin/` saiu da lista
porque saiu da árvore, e os caminhos declarados passaram a ser `partilhado/`, a cópia
vendorizada, e `assets/plugins/`, a reserva.

Como o implantador renomeado continua GRAVANDO o que o plugin LÊ,
`partilhado/dados/contrato-de-nomes.tsv` — vendorizado do plugin como o resto de
`partilhado/` — declara, grafia a grafia e com o motivo, o que
sobrevive à substituição **também dentro dos arquivos que são renomeados**: namespace REST,
classes de `partilhado/`, hook da cadência, nomes de tabela, nomes de evento, nomes de option
e o prefixo `f3base-secao-`, que marca seção medida e é contrato do plugin, não identidade do
site.

**Por que o contrato precisou virar cópia conferida, e o defeito está medido.** Até a 1.7.4
a ferramenta derivava as grafias que sobrevivem varrendo `fontes/plugin/`, e era essa
derivação de DIRETÓRIO — não o contrato — que salvava `f3base_proveniencia` e
`f3base_operaveis`, as duas options de FRONTEIRA que o implantador grava e o plugin lê: o
contrato vendorizado estava atrás do publicado e não declarava nenhuma das duas. Medido: a
renomeação para `acme` na 1.7.4 preservou as duas pelo diretório. Tirado o diretório, elas
teriam sido reescritas em silêncio, e o implantador do site renomeado passaria a gravar um
nome que o plugin não lê — sem erro e sem aviso. Na 2.0.0 as grafias do plugin saem de
DENTRO da reserva e de `partilhado/`, e o contrato vendorizado declara o resto — do CÓDIGO
deles, nunca da prosa: um nome que o plugin só cita num comentário não é preservado, e foi
assim que as options de estado do próprio implantador (`f3base_lock`, `f3base_checkpoint`,
`f3base_journal`…) sobreviviam com o prefixo do template em todo site renomeado até a
2.0.0. Quem prova isso a cada rodada é `renomeacao.plugin_intacto`,
`renomeacao.secao_medida_apos_renomear`, `renomeacao.contrato_de_nomes_completo` e
`renomeacao.preservados_so_do_codigo`.

A ferramenta é idempotente, recusa prefixo inválido antes de qualquer escrita, e o que
sobrevive do prefixo antigo está declarado arquivo a arquivo em
`ferramentas/excecoes-de-prefixo.tsv`, com o motivo ao lado. `estatica.sem_residuo_de_prefixo`
confere que nada sobrou fora dessa lista.

**Os documentos que viajam no pacote são renomeados com o resto da árvore**, e a exceção
declarada é uma só: `MEMORIA-DECISOES.md`, que narra defeitos medidos citando diretórios
que existiram em sites reais — trocar o prefixo neles inventaria um passado que não
aconteceu. Desde a 2.1.0 o pacote carrega dois documentos a mais na raiz,
`MAPA-DA-OPERACAO.md` e `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md`, e eles passam pela
renomeação como `README.md`, `MANIFESTO.md` e `TEMPLATE.md` passam.

Enquanto o conteúdo demonstrativo continuar declarado em `conteudo.demonstrativo` e
`ambiente.tipo` for `producao`, a rodada fecha `conteudo.demonstrativo` em **WARN nomeando
as páginas que ainda são do template**. Não é defeito do pacote: é o aviso de que ele ainda
não virou o site de ninguém.

## Pré-requisitos

### Do site de destino

| Requisito | Valor | Onde está declarado |
|---|---|---|
| PHP | 8.1 ou superior | cabeçalho dos dois plugins e `ambiente.php_minimo` |
| WordPress | 6.7 ou superior | piso efetivo: o cabeçalho do tema pede 6.7, os plugins pedem 6.4, e vale o maior |
| Compatibilidade máxima declarada | série 7.0 | campo de compatibilidade máxima do cabeçalho do tema |
| Banco de dados | o que a versão de WordPress em uso exigir | não redeclarado aqui, para não criar uma segunda fonte |
| Saída de rede | HTTPS para o WordPress.org | conferida no preflight, antes de qualquer mutação |

Capacidades exigidas da conta que executa, conferidas no preflight: `manage_options`,
`install_plugins`, `activate_plugins`, `install_themes`, `switch_themes`,
`update_themes`, `update_plugins`, `edit_theme_options` e `upload_files`. Capacidade
crítica ausente termina em BLOCKED, sem mutação.

Também medido antes de mutar: método de escrita no sistema de arquivos, escrita nos
destinos, espaço em disco para o pacote temporário, limites de tempo, memória e
upload do PHP, baseline da instalação, colisões de slug e inventário de sobreposições
do editor de site.

### Da máquina que roda o comando único

Quatro executáveis precisam estar no `PATH`: `php`, `node`, `zip` e `unzip`. O
comando único confere os quatro antes de qualquer coisa e, na ausência de qualquer um, fecha
`suite.ambiente` em **BLOCKED nomeando o recurso que falta** e sai com código 2. Não é
FALHA: pré-condição ausente e defeito são coisas diferentes e pedem ações diferentes de
quem lê.

**`faketime` entrou na 1.7.4 e SAIU na 2.0.0, e nos dois casos quem decidiu foi o OBJETO
medido.** Ele existia para um piso que montava o zip do plugin DUAS vezes, com o relógio em
dias diferentes, e exigia bytes idênticos: o zip era publicado num catálogo que ainda não
declarava `sha256`, o host FIXAVA o digesto na primeira observação, e um artefato que
mudasse de bytes sem mudar de conteúdo faria toda implantação seguinte falhar acusando
troca de artefato que não houve. Mover o relógio
de verdade, sobre o empacotamento de verdade, era a única forma de aquilo ser medição em
vez de uma função pura conferindo a si mesma. **O implantador não monta mais zip de
plugin**: quem o monta, sela e prova reprodutível é a suíte do repositório do plugin, em
`pacote.zip_reprodutivel`. O que ficou aqui é conferir que a reserva na árvore É o zip
publicado, e para isso bastam `unzip` e um digesto — nenhum relógio.

**E não há mais Chromium na lista, nem como opcional.** A sonda de navegador media o
cliente do plugin contra o artefato ENTREGUE, e as duas coisas saíram desta árvore junto
com a fonte. O que esta bancada continua medindo do cliente do plugin, e o que passou a ser
medido no repositório dele, está em "A sonda de navegador mora no repositório do plugin".

## Instalação

1. Obtenha o bundle da release no repositório de artefatos do projeto. O bundle é um
   arquivo único e nomeado — o nome exato desta release está no bloco gerado no topo
   deste documento, na linha "Bundle desta identidade" — e carrega o tema e a RESERVA
   versionada do plugin (`assets/plugins/base-site-core-fator3-<versão>.zip`) dentro dele,
   sem chamada de rede externa para esses dois durante o deploy. O plugin é instalado pela
   URL declarada no catálogo; a reserva responde quando aquele endereço não responde, e
   passa pelo MESMO `sha256` declarado que o download passaria.
2. Instale o implantador como plugin, pelo envio de arquivo em **Plugins → Adicionar
   novo → Enviar plugin**, e ative.
3. Não copie arquivo a arquivo sobre código ativo. A troca de diretório é controlada
   e acontece dentro da execução.

O implantador é canônico e consolidado: cada release substitui a anterior por
inteiro. Não existe plugin incremental de correção.

## Execução

```
bash suite/verificar.sh <caminho-do-pacote>   empacota e verifica
bash suite/verificar.sh piso                  roda o piso a partir da raiz do pacote
bash suite/verificar.sh piso <caminho>        roda o piso contra outro caminho
```

Três regras que o próprio script existe para não deixar ninguém contornar:

- **Rodar sem argumento reprova.** Sem caminho não há artefato, e uma rodada sem
  artefato que terminasse em zero seria a pior aprovação possível: ela emite
  `FALHA suite.invocacao` e sai com código 2.
- **Empacotar é a primeira etapa, sempre.** Arquivo fora de `suite/inventario.tsv`
  aborta o build com o nome, antes de qualquer checagem. Artefato de build mais velho
  que a fonte reprova em `pacote.build_fresco`: sem isso, uma edição da fonte não chega
  ao artefato e o operador mede o pacote anterior.
- **O código de saída vem da contagem que a função de emissão acumulou.** Nenhuma etapa
  do script corrige o resultado; o contador mora dentro da função que imprime o estado.

### O que a etapa de empacotamento produz

| Artefato | Papel |
|---|---|
| `dist/implantador-base-<identidade>.zip` | o bundle único que o operador envia ao site; a identidade é a do carimbo gerado no topo deste arquivo |
| `dist/lock.tsv` | `sha256` de cada caminho do pacote, uma linha por arquivo — a reserva do plugin entra pela linha dela, como todo arquivo da árvore |

**Nenhum zip de TEMA é montado aqui, e isso é decisão.** Nenhum caminho de instalação o
abriria: quem instala o tema lê `fontes/tema/`, que viaja no bundle, ou o zip que o operador
embute no slot `assets/plugins/<slug>.zip`. Seriam bytes mortos dentro do hash do pacote
servindo de prova falsa de entrega. Quem cobra a regra é
`estatica.artefato_do_pacote_e_lido`: artefato instalável que viaja no pacote e não
é lido pelo caminho que instala é achado.

**Nenhum zip de PLUGIN é montado aqui, e isso mudou na 2.0.0.** O plugin deixou de ser
CONSTRUÍDO pelo implantador na 1.7.0 e deixou de MORAR nesta árvore agora: ele tem
repositório próprio, e é lá que a release dele é montada, selada e provada reprodutível —
`pacote.zip_reprodutivel`, na suíte de lá. **O corte de comentário do JavaScript entregue
foi junto**, com o `dist/entregue/` que ele produzia e com o tokenizador que o executava: o
que o visitante baixa é decidido por quem monta o zip, e quem monta o zip é o outro
repositório.

**A reserva é ENTRADA de build, e não saída.**
`assets/plugins/base-site-core-fator3-<versão>.zip` é o zip publicado no catálogo, copiado
byte a byte para esta árvore: ele está no inventário, está no `dist/lock.tsv`, está no hash
do pacote e viaja dentro do bundle. `pacote.reserva_confere_com_o_catalogo` cobra cinco
cláusulas que precisam concordar — o `sha256` dos bytes da reserva é o que
`config/decisoes.tsv` declara em `plugins.instalaveis.<n>.sha256`; a versão do NOME é a do
cabeçalho de dentro do zip; a pasta de topo é a `pasta_esperada`; a cópia dentro do bundle
é byte a byte a da árvore; e o zip abre com entradas legíveis.

**Até a 1.7.4 essa conferência era contra a própria montagem, e o instrumento era cego.** A
suíte comparava a reserva com o zip que ela mesma acabara de montar da fonte: as duas
batiam sempre, e nenhuma das duas era o que o catálogo servia. Medido — a reserva embutida
na 1.7.4 dizia `1.0.1`, o catálogo publicava `1.0.0`, e o veredito de versão fechava FALHA
"instalada atrás" em TODA implantação nova, derrubando o estado para `FALHA_PARCIAL` e
impedindo a autodesativação. A regra estava certa; o número que ela carregava, não. E a
rodada da 1.7.4 fechava com FALHA 0, porque nenhuma checagem olhava para fora da árvore.

**A reserva leva o NÚMERO no nome, e isso não é estética.** Até a 1.6.6 o
implantador lia a versão da reserva no cabeçalho da fonte do plugin, que viajava no bundle;
sem a fonte, aquele cabeçalho não chega mais ao site, e o nome do arquivo é a
única fonte que sobra — uma fonte lida de disco, não digitada. É essa versão que
`plugins.site_core_versao` compara contra a instalada, e é por isso que a cláusula "versão
do nome = versão do cabeçalho" existe na checagem acima: nome e cabeçalho discordando
fariam a comparação usar um número que o plugin não tem. O slot **sem** número
(`assets/plugins/<slug>.zip`) continua existindo e continua sendo procurado PRIMEIRO: ele é
do operador, que embute um zip por decisão explícita, e vence a reserva do build.

`dist/` é saída de build, declarada como prefixo no inventário e fora do pacote que o
operador envia.

### O que a etapa de verificação cobre

As checagens da rodada integral nascem dos requisitos declarados em
`suite/manifesto.tsv`, cada linha amarrando requisito, checagem, ambiente em que ela pode
ser medida e classe/fase da evidência. Há mais requisitos do que checagens, e a diferença
é requisito que aponta para uma checagem já emitida por outro. O cruzamento é
**bidirecional** e roda como checagem, em `manifesto.bidirecional`: requisito aplicável
cuja checagem a rodada não emitiu é FALHA, e rótulo emitido sem requisito nem armadilha
que o justifique também é FALHA. O mapa de armadilhas de `suite/armadilhas.tsv` é
calculado dos rótulos efetivamente emitidos, nunca de uma condição literal, e cada
pendência declarada sai nomeada.

**Nenhuma dessas contagens é digitada aqui.** Número digitado em documento entregável —
checagens, requisitos, entradas de armadilha, armadilhas mapeadas — envelhece em silêncio,
que é a razão de o carimbo existir. Os
que vêm de leitura de disco estão no **bloco gerado no topo** deste arquivo, e
`estatica.carimbo_de_release_nos_documentos` os reprova quando divergem; os que são
resultado da rodada — contagem por estado — moram em `suite/rodada.json` e saem na saída
do próprio comando, que é onde eles podem ser verdadeiros.

As famílias são `estatica`, `entrega`, `tema`, `conteudo`, `pacote`, `formulario`,
`limpeza`, `a11y`, `consentimento`, `mcp`, `menu`, `origem`, `plugins`, `relatorio`,
`seguranca`, `orcamento`, `desempenho`, `visual`, `handoff`, `idempotencia`,
`homologacao`, `htaccess`, `copy`, `config`, `lotes`, `js` e a própria meta-verificação da
suíte. **A quantidade por família não é digitada aqui** — ela muda a cada release e o
lugar onde ela está certa é a saída da rodada.

**Duas famílias saíram na 2.1.0, e a razão não é de instrumento.** `privacidade` e `lgpd`
mediam o que a política de privacidade AFIRMA — a identificação do controlador e a
hipótese legal do tratamento —, e o dono decidiu que isso é responsabilidade de quem
responde pelo site, não do implantador. O que continua medido é o MECANISMO, na família
`conteudo`: `conteudo.politica_de_privacidade` mede a identidade da página pelo papel
declarado e a interpolação do controlador no texto.

**A rodada integral sobre este pacote fecha com código de saída 0, sem FALHA.** A
contagem por estado sai na própria rodada e é gravada em `suite/rodada.json` pelo
selo, com o hash do pacote medido; ela não é repetida aqui à mão.

**Os N/A são condicionais não instanciadas com a condição escrita na linha, e a FASE é
uma dessas condições.** Checagem cuja fase declarada não é a fase desta
rodada fecha **N/A nomeando a fase em que ela É medida**: ali não falta ação de ninguém,
falta a fase, e a rodada de build nunca vai ter produção nem campo. **BLOCKED ficou
reservado para pré-condição ausente na fase certa** — a pergunta se aplica aqui e a
resposta depende de alguém.

**E a regra vem em par com `fases.registro_de_execucao`, que é o que a impede de virar
cegueira:** ele declara, por fase, quantas checagens a esperam, QUAIS são e quando aquela
fase rodou pela última vez, e fecha **WARN** quando alguma fase declarada NUNCA rodou. O
registro dura entre execuções em `suite/fases.json`, ao lado do selo. Sem ele, uma
checagem de fase `campo` ficaria em N/A para sempre e o silêncio viraria aprovação por
omissão.

**Com uma exceção MEDIDA:** a fase cujas checagens esperadas
fecharam **todas em N/A** nesta execução é declarada **NÃO APLICÁVEL a este emissor** e sai
FORA da cobrança — relatada, com quantas checagens a esperam, e sem WARN. Cobrar de um
emissor a evidência que ele não produz por desenho é o aviso que sai sempre. O limite da
exceção: N/A **não**
registra a fase como executada, e uma única linha em BLOCKED ao lado das N/A devolve a
fase à cobrança — ali a pergunta se aplica e a resposta não veio.

**A regra vale nos dois emissores, e no host ela dá respostas OPOSTAS para as duas linhas
que ela alcança** — que é o que prova que quem decide é a regra e não quem escreveu o
código. A fase de uma execução no host é `producao` (`F3Base_Imp_Lotes::FASE_DA_EXECUCAO`):
`orcamento.medicao_de_pagina` é fase `campo` e fecha **N/A**, porque peso, requisições e
nós de DOM sobre tráfego real não são pendência de ninguém no momento da implantação; e
`cadencia.mecanismo_declarado` é fase `producao`, a fase corrente, e fecha **BLOCKED**
quando não há agendamento observado nem chave declarada — a pergunta se aplica ali e a
resposta depende de alguém. `mcp.autoteste_recusa_credencial` é de fase `campo`
e fecha **N/A**: a evidência que falta é uma requisição HTTP de fora, produzida por
um requisitante EXTERNO e não pelo host, e declará-la `producao` faria a linha sair
BLOCKED em toda execução, para sempre, sobre uma ausência por desenho.

**E N/A NÃO É PENDÊNCIA DE FASE.** Quem decide é
`F3Base_Imp_Fases::gate_de_fase_em_aberto()`, num lugar só: OK respondeu, N/A não se aplica
aqui, e BLOCKED, FALHA, WARN, WAIVED e estado ausente deixam o gate aberto e saem nomeados.
Cada consumidor comparando `OK !== estado` por conta própria imprimiria "pendência de fase
(N/A)" — a mesma confusão entre aplicabilidade e pendência, um andar abaixo.

No RUNTIME os BLOCKED não são todos iguais para a autodesativação: só BLOCKED de
ENTREGÁVEL do gate de aplicação e de
veredito de canal a impedem; BLOCKED de FASE — evidência que este host não produz — sai
nomeado e não segura a ferramenta. **O vocabulário de gates tem TRÊS valores:**
`aplicacao`, `fase` e `relato`. O quarto, `convergencia`, saiu na 2.1.0 junto com o eixo
que ele derivava — o porquê está em "O implantador é executado uma vez por site".

### O piso, e por que ele é um subcomando próprio

`bash suite/verificar.sh piso` roda **a mesma função** de cada detector contra duas
árvores: a negativa, que reproduz o defeito e precisa ser acusada, e a positiva, que
precisa passar em silêncio. Nesta base o piso fecha com **zero falhas** — cada detector
acusa o defeito plantado e cala sobre o caso correto. A quantidade de detectores com
piso em disco está no bloco gerado no topo deste documento, e o número de ramos executados
sai na saída do próprio subcomando; nenhum dos dois é digitado aqui.

O piso é o que separa uma checagem correta de uma checagem cega: enquanto o único
resultado observado for aprovação, as duas produzem a mesma saída.

### Máquina de estados da aplicação

`PRONTO → EXECUTANDO → SUCESSO_APLICACAO | FALHA_PARCIAL | FALHA | REVERTIDO`.

Antes da primeira execução real em produção roda o **modo somente-relatório** — não
existe camada de ensaio hospedada, e a produção é o primeiro host externo que o pacote
encontra. A aplicação avança em **lotes**: a tela orquestradora renderiza inline na
resposta do `admin-post.php` e avança por requisições autenticadas sucessivas, uma
unidade idempotente por lote. Uma única requisição síncrona estoura tempo e memória em
hospedagem compartilhada.

Proteções da execução, para o operador saber o que esperar:

- **Lock com heartbeat e renovação atômica.** Execução concorrente é rejeitada.
  Expiração sozinha não impede duas execuções quando uma etapa longa passa do prazo.
- **Checkpoint gravado depois da leitura de volta**, com identificador da execução, da
  release, hash da configuração, etapa, estado e token de disputa. A retomada só
  acontece com a mesma release e o mesmo hash de configuração.
- **Journal antes de mutar**, com pré-imagem, pós-imagem e a operação inversa
  declarativa. Ações irreversíveis são declaradas e excluídas da promessa de reversão.
- **O carimbo de versão aplicada avança apenas em `SUCESSO_APLICACAO`.** Execução que
  aborta no preflight, falha ou é revertida não grava a versão.
- **Autodesativação apenas em `SUCESSO_APLICACAO` e sem nenhum entregável do gate de
  aplicação em BLOCKED.** Canal MCP incompleto também impede: sem canal, o implantador é a
  única ferramenta de correção que resta. Em falha ele permanece ativo, preserva o log e
  oferece retomada idempotente e reversão das mutações reversíveis.

### A unidade `limpeza`: o que a instalação limpa traz e este pacote não usa

**A 2.1.0 criou a unidade, e o defeito foi medido antes dela.** A implantação de
2026-09-07 entregou o site com os três temas de fábrica — Twenty Twenty-Três, Quatro e
Cinco —, com o Akismet e com o Hello Dolly no lugar: código que ninguém pediu, que o
painel lista, que a atualização automática alcança e que aparece em todo relatório de
segurança como superfície instalada.

A unidade roda **depois do tema e antes do `site_core`**, e a posição é regra: os temas de
fábrica só saem com o tema do pacote já ativo, e os plugins de fábrica saem antes de a
lista de plugins ser lida pelas etapas seguintes — a de atualização automática ligaria a
flag para o Akismet. Quem decide o que sai são duas listas de `config/decisoes.tsv`,
`limpeza.temas_padrao` e `limpeza.plugins_padrao`, e mais nada: **o que a lista não declara
não é tocado.** O plugin de painel da hospedagem fica, porque o que é de alguém é de
alguém.

Quatro guardas, e cada uma tem piso em `limpeza.plano_dos_padroes`, que mede a regra PURA:

- **o tema ATIVO nunca é removido, nem o tema PAI dele**, ainda que a lista os declare — a
  linha diz que os pulou e por quê;
- **plugin ativo é desativado pela API do núcleo antes de sair**, para que os hooks de
  desativação rodem;
- **item declarado e não instalado é AUSENTE**, não erro;
- **quem apaga é o núcleo** — `delete_theme()` e `delete_plugins()`, pelo mesmo filesystem
  que instalou —, nunca um caminho montado à mão.

A leitura de volta é `wp_get_theme()->exists()` falso e `get_plugins()` sem o arquivo. **A
remoção é IRREVERSÍVEL e o journal a declara como tal, com o motivo**: um tema de fábrica
volta pelo repositório oficial em um clique, e o que se perde é o estado de quem tivesse
editado um tema de fábrica no lugar de um filho — estado que a primeira atualização
automática já teria levado.

**O preço está declarado, e é o Twenty Twenty-Cinco.** `WP_DEFAULT_THEME` aponta para ele:
com os três de fábrica fora, o núcleo não tem para onde cair se o tema ativo quebrar. A
decisão é essa mesma — tema que quebra neste pacote é defeito de release, medido antes de
sair, e o tema-reserva do núcleo era um site alheio no ar com a cara de outro projeto. A
linha do relatório diz isso.

### A tela: o que fica no topo e o que fica no fim

Duas coisas com tempos diferentes, em dois nós:

| Nó | O que é | Onde fica |
|---|---|---|
| `progresso` | **status ao vivo**, região `aria-live`; muda a cada lote e, no fim, fica com uma linha curta: o que aconteceu, o estado fechado da aplicação e onde está o resultado completo | **primeiro** filho da raiz |
| `encerramento` | **conclusão**: contagens por escopo, listas de nomes por estado, resumidas, suspensas e o estado da aplicação | **depois** da tabela do log |

O resumo **não** é escrito dentro de `progresso`. `progresso` é o
primeiro filho da raiz — que é o que um status ao vivo precisa ser —, e a conclusão
escrita ali **apareceria antes do log e empurraria a tabela para baixo**: quem termina a
execução leria o resultado de costas para as linhas que o produziram.

A conclusão é **anunciada e alcançável pelo teclado**: a região tem nome acessível
(`role="region"` mais `aria-label`), é focável por script (`tabindex="-1"`) e **recebe o
foco** no instante em que é escrita — é isso que a anuncia e leva o teclado até ela. O
anel de foco é visível, porque foco sem indicação visível é foco perdido. O log baixado
continua trazendo as duas partes, na mesma ordem da tela.

Quem mede é `js.decisoes_do_cliente`, e a medição é sobre a **árvore montada**: a sonda
monta um DOM de mentira e roda o cliente REAL de ponta a ponta contra ele. O piso são
mutantes do próprio cliente — o resumo escrito em `progresso`, o encerramento montado
antes da tabela e a chamada de foco apagada —, e a bancada precisa acusar os três.

### O implantador é executado uma vez por site

**Esta é a decisão que governa a 2.1.0, e ela apagou um eixo inteiro do encerramento.** Da
1.0.17 à 2.0.0 o encerramento respondia DUAS perguntas: "o implantador aplicou o que sabia
aplicar?" (`SUCESSO_APLICACAO`) e "o site está completo?" — a **convergência**, que somava
as pré-condições declaradas dependentes de dado que só o operador tem: razão social,
CNPJ, endereço, número de WhatsApp, nome do mecanismo de cadência da hospedagem. A saída
que aquele eixo oferecia era sempre a mesma frase: *preencha e execute de novo*.

A operação não tem esse ciclo. **O implantador roda UMA VEZ por site**; o dado do operador
é preenchido em `config/projeto.json` ANTES dessa execução, ou ajustado DEPOIS pelo canal
MCP, que é por onde o site é operado a partir dali. Um eixo cuja única saída descreve um
ciclo que ninguém executa não é um eixo: é um aviso que sai sempre. Saíram inteiros o gate
`convergencia`, o metadado `precondicao` que o derivava, a linha `entrega.convergencia`, a
função que produzia o veredito e as constantes de estado dele; `estatica.precondicao_no_eixo`
e `lotes.gate_de_aplicacao_sem_dado_do_operador`, que mediam a derivação e o gate, saíram
junto e estão declaradas em `suite/excluidas.tsv` com categoria `retirada`.

**O que NÃO saiu é a idempotência.** Ela continua sendo propriedade do código: reexecutar
não repete o que já foi aplicado, o checkpoint retoma pela mesma release e pelo mesmo hash
de configuração, e o merge de três vias preserva o que o agente editou. Reexecutar continua
sendo possível e continua sendo seguro. O que deixou de existir é "execute de novo" como
MÉTODO DE OPERAÇÃO.

Sobraram dois eixos, e cada um responde a uma pergunta que alguém faz:

| Eixo | Pergunta que ele responde | Quem o move |
|---|---|---|
| `estado_final` | O implantador aplicou o que sabia aplicar? | qualquer checagem em FALHA |
| `autodesativacao` | O ciclo do implantador terminou? | o gate de aplicação: os entregáveis nomeados e os dois vereditos de canal |

**A autodesativação sempre esteve amarrada ao gate de aplicação, e continua.** Ela é sobre
o CICLO DO IMPLANTADOR ter terminado, não sobre o site estar completo — manter a ferramenta
no ar por dado que só o operador tem prenderia o pacote a uma espera indefinida, e um site
cujo operador nunca preenche o controlador ficaria com o implantador ativo para sempre. É a
forma de gate insatisfazível que este pacote recusa.

O texto final do encerramento diz isso com todas as letras: *o implantador é executado uma
vez por site, e o que ele deixou por preencher — dado que só o operador tem — é ajustado
pelo canal, sem nova execução.*

## Reexecutar o implantador depois que o agente mexeu no site

**Reexecutar não é o método de operação — é a exceção.** O implantador roda uma vez por
site e sai de cena; o que segue está aqui porque alguém pode reativá-lo, e o que este
pacote promete nessa hipótese precisa estar escrito.

A premissa que governa esta release, nas palavras de quem a definiu: *"Após a instalação,
todas as futuras modificações serão realizadas por um agente através de MCP. Então o
template e plugins não devem tentar evitar que futuras modificações sejam realizadas."*

**A regra: o que o agente mudou vence, salvo quando a configuração mudou
aquela mesma coisa depois — e aí o relatório nomeia a sobreposição.**

Sem ela o pacote **reverteria**. Um gravador que comparasse duas vias — o valor observado
no site contra o valor desejado pela configuração — e gravasse sempre que diferissem, uma
união de `f3base_redirects` que rederivasse a cada execução todo par declarado ou computado,
inclusive o que alguém apagou, e um merge de conteúdo que no ramo com política `gerenciado`
fizesse o texto do template vencer o do cliente, juntos fariam o agente que passa semanas
editando o site pelo canal perder o trabalho no instante em que alguém reativasse o
implantador — sem erro, sem log e com o relatório verde.

### Como ela funciona, por artefato

- **Options do bloco do `site-core`.** O pacote registra a **base** — o último valor que
  ele mesmo aplicou — e compara base, observado e desejado. Observado igual ao desejado:
  nada a gravar. Observado igual à base: atualização segura. Observado diferente da base
  com a configuração intocada: **preserva**, e a linha
  `options.edicao_do_agente_preservada` nomeia a option e o motivo. Os três diferentes: o
  pacote grava e a **sobreposição** sai nomeada com os dois valores — o que estava no site
  e o que foi aplicado. É o único caminho pelo qual o pacote vence quem opera o site, e
  por isso é o único que fecha WARN.
- **Primeira execução com base.** Numa instalação que já tem a option e ainda não tem
  base, o observado é tratado como base e o desejado é aplicado. A linha do relatório
  **diz que a base nasceu naquela execução**, porque só nela o pacote não consegue
  distinguir uma edição de um valor que sempre esteve ali. Estrutura de estado nova
  declara o que faz quando ainda não há estado.
- **Conteúdo.** O que este pacote publica é demonstrativo. Uma vez que o objeto foi
  editado, nenhuma atualização do template o sobrescreve: o pacote só grava conteúdo onde
  a base é igual ao observado, e os campos preservados saem nomeados na linha do objeto.
- **Redirects.** Par que estava na base e não está mais na option foi apagado por quem
  opera o site: a união não o recria — nem pela configuração, nem por uma etapa que o
  recompute — e `redirects.fonte_composta` o nomeia. A marca de removido é durável e mora
  na base de merge, e não dentro de `f3base_redirects`: o `site-core` serve todo par
  gravado sem olhar a origem, e um par marcado ali continuaria redirecionando. Refazer o
  par pelo canal o traz de volta na execução seguinte.

### O modo somente-relatório compara com a BASE, e não com a configuração

Este é o outro lado da mesma regra. Depois que
o agente assume o site, `config/site.json` é **certidão de nascimento e não estado corrente** —
ele registra o que o pacote aplicou no dia da entrega e nunca mais é reescrito, porque quem
opera não edita o zip. Comparar com ele faria de cada edição legítima do agente uma
"divergência" permanente num relatório que roda na cadência para sempre; e relatório que
acusa sempre é relatório que ninguém lê.

A linha `options.mudanca_desde_a_aplicacao` sai neste modo, e ela tem duas partes:

- **O registro.** *Mudou desde a última aplicação*, nomeando o valor que o pacote aplicou e
  o que o site tem agora. Ele fecha **OK**: quem opera este site é o agente, e mudar é o
  trabalho dele. Nenhuma option intocada some da contagem — "nada mudou" precisa ser
  distinguível de "nada foi medido".
- **A segunda linha.** *Difere da configuração original*, rotulada como tal. Ela continua
  existindo porque tem leitor — **quem for reexecutar o implantador**, já que é o valor da
  configuração que a reexecução leva em conta —, e não é achado.

O modo **simulação** responde a outra pergunta — "o que esta execução faria se eu
mandasse aplicar?" —, que é a de quem está prestes a aplicar.

### O aviso de conteúdo demonstrativo é medido no BANCO

`conteudo.demonstrativo` mora no arquivo único. Sob a premissa acima, o agente substitui o
conteúdo **pelo canal** e nunca toca em `content/` nem no `config/site.json` — a chave fica
`true` para sempre, e um aviso preso a ela continuaria saindo depois de o template ter
sumido inteiro do site.

A marca `<prefixo>:conteudo-demonstrativo` já viaja dentro de cada página publicada. A linha
`conteudo.demonstrativo_no_site` conta, **no banco**, as páginas publicadas que ainda a
carregam e as **nomeia**; o mesmo censo entra na medição da cadência do `site-core`. Zero
páginas marcadas, zero aviso — qualquer que seja a chave.

**E o veredito discrimina QUEM escreveu cada página marcada.** Publicar o conteúdo
declarado é o que o implantador faz: sem o discriminante, a unidade `entrega` fecharia WARN
por ter cumprido o próprio desenho, minutos depois de publicar as páginas que a marca
identifica. Quando toda página marcada foi escrita por esta execução, a linha
fecha **OK nomeando as páginas** — o template está no ar porque acabou de ser implantado,
que é o estado declarado e não uma decadência. **WARN sobra para a página marcada que quem
mede NÃO escreveu**, nomeada sozinha: aí é texto de template que sobreviveu a quem deveria
tê-lo substituído. O conjunto das escritas sai do **journal**, o registro que o pacote já
mantém de cada gravação, e ele chega VAZIO por padrão — é assim que a cadência do
`site-core` continua avisando um mês depois, que é onde a pergunta vale. A checagem de build
`conteudo.demonstrativo` continua conferindo o **pacote**, que é outra pergunta e tem outro
leitor: ela responde "este pacote leva conteúdo de template?".

### O que a regra NÃO cobre

- **A infraestrutura da própria execução** — checkpoint, journal, procedência, a base de
  merge. Ela é estado do implantador, não configuração de ninguém, e continua sendo
  reescrita a cada execução.
- **Options de terceiro** gravadas por adaptador — as do plugin de SEO, por exemplo. O
  gate delas continua sendo a leitura de volta, que é outra pergunta.
- **A recorrência do agendamento da cadência**, com uma exceção estreita e declarada: o
  evento que uma execução anterior degradou para `daily` é reagendado quando a recorrência
  declarada passa a existir no agendador. Qualquer outra recorrência é decisão de quem
  opera o site, e a etapa não a desfaz.

## Remoção

- **Implantador.** Autodesativado não é descartável: o pacote versionado continua sendo
  a referência executável do estado gerenciado. Remover o plugin do servidor é escolha
  operacional, com o pacote preservado no projeto. Remover o implantador **não** remove
  nada do que ele aplicou.
- **`site-core`.** Desativar interrompe o comportamento; excluir dispara
  `uninstall.php`, que declara o destino de cada conjunto de dados. Sai o que só o
  plugin usa e sabe recriar: estado de execução, segredo do endpoint, agendamentos,
  transientes e a tabela de deduplicação. O que é dado de titular segue o regime de
  retenção e eliminação, não a desinstalação.
- **Tema.** Trocar o tema não desliga leads, medição, redirects nem retenção — é para
  isso que eles moram no `site-core`. O controle de consentimento do rodapé continua
  existindo: o `site-core` mantém markup de reserva idêntico ao do tema e o imprime
  quando o tema não declara o suporte correspondente.

## O controle de consentimento: link no rodapé, banner na base

**A regra que governa a visibilidade, e ela é detector com piso:** elemento cuja
visibilidade é comandada por `hidden` **não pode ter `display` declarado por regra de
autor**, a menos que o `display` venha acompanhado de um `[hidden] { display: none }` que
o vença. `[hidden] { display: none }` é regra da folha do **user agent**, e qualquer
`display` declarado pelo autor a vence — a **origem** decide antes de a especificidade ser
consultada. Um `display` de autor solto sobre uma classe alternada por `hidden` — o
`position: fixed; inset: 0; display: grid` de um painel, o `display: block` de uma caixa de
resumo — deixa o `hidden` sem efeito nenhum: o painel cobre a página inteira e o botão
"Fechar" não fecha. `estatica.hidden_governa_visibilidade` varre o pacote inteiro —
JavaScript e markup de um lado, todas as folhas do outro.

**Gravar a decisão e fechar o painel são a mesma ação.** `definir()` grava o cookie,
atualiza o Consent Mode, sincroniza o texto **e fecha**: sem o fecho, aceitar e recusar
funcionam por dentro e parecem inertes.

**Toda regra da folha tem elemento que a carregue.** Classe declarada em `style.css` que
nenhum markup usa é regra órfã, e é assim que um painel aparece sem caixa, sobre um fundo
chapado.

**O desenho, e o que cada peça dele decide:**

- **O controle é um link de texto**, sem destaque, na mesma linha e com o mesmo
  tratamento dos outros links do rodapé — a cor sai de `--wp--style--color--link`, que é
  a mesma custom property que o `<a>` vizinho consome. Ele **é um
  `<button>`**, e a escolha é medida: o controle executa uma ação na própria página e não
  navega; um `<a>` sem `href` não é focável nem anunciado — a armadilha clássica — e um
  `<a href="#">` inventa um destino que muda a URL e quebra o botão de voltar. O
  `<button>` responde a Enter e a Espaço sem uma linha de JavaScript.
- **O rótulo é "Política de Cookie"**, nos três lugares que o dizem: `parts/footer.html`,
  `templates/landing.html` e o markup de reserva do `site-core`.
- **Ele abre um banner na BASE do viewport** — largura da viewport, altura do conteúdo,
  acima da página e sem cobri-la. O visitante continua vendo e usando o site com o banner
  aberto.
- **Os três botões funcionam e dão retorno.** Aceitar e recusar gravam **e fecham**;
  fechar fecha **sem decidir** — gravar ali transformaria o gesto de dispensar a faixa em
  consentimento. Ao reabrir, o estado corrente aparece.
- **Rolagem e foco.** Ao abrir, o corpo ganha exatamente a altura do banner como respiro
  embaixo (`--f3base-banner-altura`), e a devolve ao fechar: sem isso a faixa fixa tampa o
  fim do documento, inclusive o rodapé e o próprio controle que a abriu. O foco vai para o
  banner ao abrir e **volta para o controle** ao fechar. Ele **não é modal** —
  `aria-modal="false"` continua declarado — e **não prende o foco**; a única tecla que
  captura é `Esc`.
- **O banner é construído FECHADO na carga**, e não no primeiro clique. É o que faz o
  `aria-controls` do controle apontar para um `id` que existe, em vez de uma referência
  pendurada.

**O piso mede comportamento, não markup.** `js.banner_de_consentimento` roda o cliente
real contra um DOM de mentira e decide visibilidade pelo `style.css` **real**, com o par
(`hidden`, `display`). E ele carrega o **defeito como mutante**: com
`display` de classe e sem o par `[hidden]`, a bancada **tem de** ver o banner
visível na carga e o "Fechar" que não fecha. Se ela não reproduzir isso, ela é cega, e a
aprovação dela não vale nada. Os outros dois mutantes são `definir()` sem o fecho e
`fechar()` sem a devolução do foco.

## Como o script de consentimento é carregado: a política decide

O `default` do Consent Mode só vale se chegar antes do `gtag.js`, e **o `gtag.js` não é
carregado pelo WordPress** — quem o injeta é `f3base-tracking.js`, que é `defer` no rodapé
e declara dependência do handle do consentimento. Entre dois `defer` a ordem do documento
vale, então o consentimento roda antes do carregador sem bloquear o parser.

A **estratégia de carga é decidida pela política**, e não por um
interruptor — não há chave de configuração para isso:

- **`consentimento.padrao = pre-aprovado` → `defer`.** É o padrão do template. O `default`
  deste modo é `granted`, que é materialmente o que o gtag faz **sem Consent Mode nenhum**:
  chegar tarde com `granted` não muda o que foi enviado.
- **`consentimento.padrao` negado por padrão → bloqueante no `<head>`.** Ali o `default` é
  `denied` e a ordem passa a ser a garantia inteira. E `defer` só ordena `defer`: um
  `gtag.js` `async` de um emissor concorrente, ou um snippet colado no cabeçalho, executa
  **antes** de qualquer `defer` da página. Bloquear o parser é o preço de não disparar
  antes de saber.

**O que fica fora do caminho crítico, no modo padrão:** **5.085 bytes gzip** (14.256
crus) — o arquivo inteiro de `f3base-consentimento.js`, que é o **único** script que seria
bloqueante no pacote. Ficam no caminho crítico duas coisas, e as duas estão nomeadas: a folha de
estilo do tema, **6.720 bytes gzip** (20.716 crus), que bloqueia a renderização como toda
folha de estilo; e o bloco de dados que o `wp_localize_script` imprime antes do script,
**831 bytes** de JSON (450 gzip), que continua inline no cabeçalho — ele é uma atribuição
de variável, sem ida à rede. `f3base-leads.js` e `f3base-tracking.js` já estavam fora,
no rodapé e com `defer`.

**O piso mede ORDEM DE EXECUÇÃO, não a string do atributo.** `js.ordem_do_consentimento`
roda os **dois clientes reais** contra um escalonador que é o modelo da especificação —
bloqueante na posição do parser, `defer` depois do parse e na ordem do documento, `async`
sem ordem com nada — e lê uma linha do tempo do `dataLayer` e de cada tag de script
externo inserida. O teto que carrega a decisão é uma **igualdade**: a linha do tempo do
consentimento adiado é a MESMA que a do bloqueante. Os pisos são dois: **inverter a
decisão** — `defer` no modo opt-in — tem de aparecer como o primeiro `page_view` do
emissor concorrente saindo **antes do `denied`**; e o carregador rodando antes do
consentimento tem de aparecer como `gtag.js` pedido sem `default` nenhum, com
`permiteTags()` caindo na decisão de reserva do servidor. `consentimento.estrategia_pela_politica`
mede a outra metade no servidor, e o piso dela é o valor fixo: as duas políticas não podem
devolver a mesma estratégia.

## O que a negativa tardia NÃO desfaz

A recusa vale **do clique em diante**, e a assimetria abaixo é do fornecedor, não nossa:

- **GA4 e Google Ads têm `consent update`.** A negativa passa a valer para o que vier
  depois; **o que já foi enviado permanece no Google**. É o que o Consent Mode faz, e está
  correto.
- **Pixel da Meta e Insight Tag do LinkedIn não têm equivalente de `update`.** Eles
  simplesmente **não carregam** na negativa — mas se já carregaram, porque
  o `default` era `granted`, **negar depois não os descarrega**: nada descarrega um arquivo
  já carregado. O que a negativa faz é impedir os **envios seguintes**.

O que sustenta essa última frase: em
`f3base-leads.js` os dois disparos passam pelo mesmo `permiteTags()` do carregador de tags,
e **nunca pela presença da função** — `typeof window.fbq === 'function'` e
`typeof window.lintrk === 'function'` continuam verdadeiros
depois da recusa, e quem chega, é medido, abre o controle do rodapé e recusa
continuaria mandando `Lead` à Meta e `track` ao LinkedIn a cada clique no CTA.
`js.conversao_multicanal` tem o piso: com o consentimento negado depois da carga, a
bancada **tem de** ver zero envio aos dois. O
`generate_lead` **continua** sendo empurrado no `dataLayer`: quem decide o que o Google
faz com ele depois do `denied` é o Consent Mode, e calar aqui seria decidir duas vezes a
mesma coisa, uma delas sem mecanismo. O registro do lead **no próprio site** também
continua: recusar medição não é recusar o contato.

## Plugins

Política declarada: `politica_versao` é `ultima-da-fonte-oficial` e `autoupdate` é
`todos`. Nenhuma versão é fixada no arquivo de configuração e nenhum checksum de
terceiro entra no lock — o gate é a leitura de volta de cada option gravada.

**Plugin de console do Google: admitido só como leitor, e a pré-condição é não emitir.**
Nenhum plugin de console entra no catálogo, e **não existe chave `plugins.protegidos`** — nem
em `config/site.json`, nem em `config/projeto.json`, nem em `config/decisoes.tsv`. O que
existe é a CLASSIFICAÇÃO que o preflight dá a cada plugin observado, e ela sai do que foi
medido: `artefato-do-pacote`, `gerenciado`, `externo-preservado`, `emissor-concorrente` e
`divergencia-a-classificar`. A emissão de
toda tag de medição é do módulo `tracking` do `site-core`, dirigida pelos IDs gravados em
options, em **toda** instância — **um emissor por fornecedor, e o emissor é o `site-core`**.
Onde um cliente mantiver um plugin de console, ele entra em `plugins_operacionais` como
plugin de leitura, com o snippet e a medição automática de conversões **desligados**: é
essa a pré-condição, e ela é medida. O preflight classifica o slug ativo cuja condição de
emissão está ligada como **`emissor-concorrente`** — classe nomeada no relatório e no
somente-relatório, que **não desativa nada**: depois da instalação quem modifica o site é o
agente, e o pacote nomeia em vez de decidir. Quem decide de verdade é a contagem no HTML
publicado, em `tracking.emissor_unico`: com qualquer slot preenchido, a contagem de
`gtag/js`, de `gtm.js`, de `fbevents.js` e de `insight.min.js` tem de ser exatamente a que
o módulo emitiu, e nenhum `gtag("config", …)` pode vir de emissão que não seja a dele. A
lista de slugs de `partilhado/dados/emissores-conhecidos.tsv` é **dica** para o
preflight classificar cedo, nunca o gate — slug fora dela que emita é pego pelo HTML, e
slug dentro dela que não emita fecha `leitor`.

**Precedência de origem, na ordem em que o instalador tenta:** `assets/plugins/<slug>.zip`
(o slot do OPERADOR, sem número e sem rede) → URL declarada na entrada, **em https** →
`assets/plugins/<slug>-<versão>.zip` (a RESERVA versionada que viaja no bundle) →
WordPress.org. Pôr o zip no slot dispensa a rede sem
mudar uma linha de configuração; `assets/plugins/LEIA-ME.txt` descreve o slot e o
diretório entra no inventário como prefixo declarado. `plugins.embarcados` está **vazio**:
nenhum plugin viaja no bundle pela lista de embarcados, e o complemento do canal é instalado por URL
declarada como o servidor — o zip do slot é o caminho offline dele, não o padrão.

**Artefato LOCAL passa pelo digesto igual ao baixado.** O `sha256` declarado na entrada de
origem `url` vale para o slot do operador e para a reserva, e não só para o download:
instalar um arquivo local sem conferir seria aceitar qualquer zip que tivesse aquele nome.

**Um artefato, uma unidade: o `site-core` é instalado UMA VEZ.** Ele tem unidade própria
no plano — `site_core` —, e desde a 2.1.0 o laço que percorre `plugins.instalaveis` **pula
a entrada de papel `site-core`**. Até a 2.0.0 ele entrava duas vezes: a unidade o
instalava e o laço o baixava DE NOVO, para comparar por hash de diretório e concluir
"artefato idêntico ao instalado". Medido na implantação de 2026-09-07: dois downloads de um
megabyte por execução para instalar uma coisa só. A comparação por bytes continua existindo
e continua saindo na linha `plugins.instalado:<slug>` — o que saiu foi o segundo download.

**A reserva versionada só passou a INSTALAR na 2.0.0, e o defeito durou cinco releases.**
Da 1.7.0 à 1.7.4 o resolvedor de origem conhecia o slot do operador e mais nada: a reserva
versionada era resolvida para a linha de versão e para os entregáveis, e por mais ninguém.
Com a URL fora do ar a instalação fechava BLOCKED, e a frase "se a URL não responder, cai
na reserva" era **falsa** em todos os documentos que a traziam — este inclusive. A bancada
não via porque MONTAVA o slot do operador para se testar, exercitando o caminho que não era
o da entrega. Agora a URL é TENTADA primeiro e a tentativa sai nomeada no relatório; a
reserva responde quando ela não responde; e o digesto declarado é conferido SOBRE a reserva
— com o catálogo declarando outro `sha256`, ela é RECUSADA e nada é instalado.

| Slug | Papel | Origem | Justificativa |
|---|---|---|---|
| `wordpress-seo` | seo | wordpress.org | Responde por Organization, WebSite, WebPage, BreadcrumbList e Article, pelas metas por conteúdo e pelo sitemap. O `site-core` só **estende** o que falta (`Service` e propriedades de entidade), pelos filtros do próprio plugin, sem duplicar nó existente — funcionalidade que o plugin do catálogo cobriria e fosse reimplementada no `site-core` exigiria justificativa escrita. |
| `flamingo` | caixa-de-leads | wordpress.org | Guarda os envios no próprio site. Sem ele, a prova do lead depende de e-mail entregue, que é o elo mais frágil da cadeia. Também é o motivo de a eliminação de lead ter rota própria com journal: eliminar registro por rota genérica de conteúdo já custou 37 registros, com cópia única fora do site. |
| `wp-mcp-ultimate` | canal-mcp-servidor | origem `url`, com `pasta_esperada` e `sha256` declarados | Servidor do canal MCP: rotas tipadas de conteúdo, options, mídia, plugins, usuários, menus e comentários — e **nenhuma** rota de arquivo ou de banco. Instalação obrigatória em todo projeto. |
| `wp-mcp-ultimate-complemento-fator3` | canal-mcp-complemento | origem `url`, com `pasta_esperada` e `sha256` declarados; o slot `assets/plugins/<slug>.zip` tem precedência quando presente | Artefato nosso, instalado como os outros e não embutido no bundle. Acrescenta as doze rotas de arquivo e de banco com as travas do canal: sintaxe de PHP conferida antes de gravar, hash esperado na escrita, backup com restauração e escrita de banco em duas fases com pré-visualização obrigatória. Sem ele, quatro linhas da matriz de alocação não têm via de execução pelo agente. |

### Cadeia de suprimentos: o que o digesto protege e o que ele não protege

Os dois plugins do canal — e, desde a 1.7.0, o próprio `base-site-core-fator3` — descem de
`https://github.com/…/raw/main/….zip` — **ref
mutável**: `main` de hoje não é `main` de amanhã, e o artefato que chega por esse caminho
é o que expõe as rotas `files/*` e `db/*`. Duas guardas, e cada uma vale o que ela vale,
nem mais:

1. **A guarda é revalidada DEPOIS de cada redirecionamento.** Os saltos são seguidos um a
   um, com `redirection => 0`, e **cada endereço precisa continuar em https** antes do
   próximo. O corpo só desce do endereço final, que é o único que teve a guarda
   conferida. Conferir só a URL declarada deixaria a guarda valendo para um endereço que
   ninguém baixa — e um 302 de `https://` para `http://` traria o artefato por canal
   aberto. Cadeia que não termina é abandonada no teto de saltos, com a cadeia percorrida
   nomeada.
2. **`sha256` é DECLARÁVEL na entrada de origem `url`.** O schema o aceita no ramo
   `origem: "url"`, e só nele: fora dali `additionalProperties: false` o rejeita.

**E desde a 2.1.0 as TRÊS entradas de origem `url` declaram o digesto.** O
`base-site-core-fator3` já declarava desde a 2.0.0; agora o servidor do canal
(`wp-mcp-ultimate`) e o complemento (`wp-mcp-ultimate-complemento-fator3`) também, com o
`sha256` medido no download do endereço declarado. O motivo está escrito na própria linha
do catálogo, e ele saiu do log da implantação de 2026-09-07: sem digesto declarado o host
FIXA o primeiro digesto observado, e fixar o primeiro observado **não é verificação de
integridade** — se o artefato já veio trocado, é o trocado que ficou fixado. **O preço é
declarado e é disciplina, não conveniência: zip novo desses dois plugins exige digesto novo
no catálogo**, exatamente como já acontece com o `site-core`, e no mesmo repositório. Quem
publicar sem declarar recebe a instalação reprovando com os dois valores nomeados, que é o
comportamento certo.

**O que NÃO existe aqui, e por quê.** Não há lista fechada de hosts de onde o
site pode baixar artefato. Ela seria declarada no `config/site.json` — no **mesmo arquivo**
que as URLs que ela restringiria —, e isso não é controle de segurança: quem consegue
editar a URL edita a lista na linha de cima. Seria guarda de digitação com preço de
controle, cobrando do operador uma decisão que não compra proteção nenhuma. O que faz o
trabalho de verdade e não pede nada: **HTTPS obrigatório em todos os saltos** — a
autenticidade da origem e a integridade em trânsito são do TLS — e o **digesto**, que é o
que amarra o byte baixado.

Os três ramos, e a diferença entre eles é o ponto inteiro:

| Situação | O que acontece | O que isso garante |
|---|---|---|
| `sha256` declarado e batendo | instala | o artefato é o que a configuração nomeia, **inclusive na primeira busca** |
| `sha256` declarado e divergindo | **FALHA** nomeando os dois valores; **nada é instalado** | — |
| `sha256` ausente | o digesto é **medido e fixado** na primeira observação, e a execução seguinte com digesto diferente do fixado é FALHA | defende contra a origem MUDAR embaixo das execuções seguintes; **não** defende a primeira busca |

**A conferência vale só para a origem `url` declarada, e isso é fronteira de contrato.**
Para `origem: "wordpress.org"` ela **não** roda: a URL de lá é por VERSÃO, o artefato muda
de propósito a cada atualização, e fixar o digesto ali faria a próxima versão legítima
reprovar — o oposto de "sempre a última versão da fonte oficial". O schema executa a mesma
fronteira: `sha256` só existe no ramo `url`.

**O limite do terceiro ramo está escrito na própria mensagem do relatório, e não é
maquiado.** Fixar na primeira observação não é verificação de integridade: se o artefato
já veio trocado, é o trocado que ficou fixado. TOFU que se apresenta como verificação é
pior do que nenhuma, porque produz confiança. O ramo existe porque o usuário exige que o
template funcione como produção sem configuração extra, e exigir digesto declarado
quebraria a primeira execução de todo projeto novo — quem quiser a garantia na primeira
busca declara `sha256` na entrada, e aí o teto é o declarado. **Nenhuma entrada de origem
`url` do catálogo depende desse ramo desde a 2.1.0**: as três declaram o digesto, e o ramo
sobrevive para a entrada que alguém acrescentar sem declarar.

`plugins_operacionais` nasce **vazia** em `config/projeto.json`, como todo campo do
operador: site novo não tem plugin de ninguém, e vazia é estado válido e declarado. Quem a
preenche é quem abre o arquivo, com o que já estava instalado e não veio deste pacote — o
atalho de login que a hospedagem instala no provisionamento é o caso típico, e o
`$comment` do schema diz onde encontrar a lista. A afirmação desta linha é amarrada por
`doc.afirmacao_conferida` contra o `config/projeto.json` que viaja no mesmo zip: documento
que descreve a lista de um jeito e arquivo que a traz de outro é achado. Plugin
operacional declarado é classificado no relatório como externo preservado, nunca removido;
plugin ativo e **não** declarado sai como divergência a classificar, nomeado.

### Versão observada é fato de entrega, não requisito

O relatório de cada execução registra a **versão observada** de cada plugin e do núcleo
no momento em que a execução aconteceu. Esse número é fato de diagnóstico: ele descreve
o que estava instalado, não o que precisa estar. Nenhuma execução aprova ou reprova por
comparação desse número, e nenhum item deste pacote exige uma versão específica de
plugin de terceiro.

Regra que produz o valor, já que ele só existe em tempo de execução: o adaptador lê a
versão instalada no momento da aplicação, grava-a no relatório junto do resultado da
leitura de volta das options daquele plugin, e o leia-me de cada projeto **deriva** do
lock a frase "validado até a versão que o lock registra", nunca "instalado tal versão".

**Estado nesta base: N/A com a fase nomeada.** O comando único roda contra a árvore do
pacote, não contra um WordPress instalado, então nenhuma versão de plugin de terceiro foi
observada. Declarar um número aqui seria inventá-lo. A linha não é pendência de ninguém —
é a fase `producao` que não roda no build —, e quem cobra que essa fase um dia rode é
`fases.registro_de_execucao`.

### Caminho de reversão de um plugin

A fonte é a mesma da instalação: o WordPress.org mantém as versões anteriores de cada
plugin publicadas e baixáveis. Reverter é instalar de lá a última versão em que a
leitura de volta conferiu — a que o relatório da execução anterior registra pelo nome.
Nunca o ZIP do repositório de artefatos, que serve ao laboratório e ao ambiente
offline, não à produção.

Três limites, e eles vêm juntos, sob pena de a reversão virar o segundo incidente:

1. **O WordPress reverte sozinho só a falha grosseira.** A atualização automática
   desfaz a atualização que produz erro fatal na verificação. Quebra sutil —
   comportamento mudado, chave de option descartada, CSS deslocado — passa por essa
   rede e só aparece na cadência ou no cliente.
2. **Reverter código não reverte dados.** Versão nova que migrou schema ou reescreveu
   options deixa o banco à frente do código, e o downgrade pode encontrar estado que
   não sabe ler. Antes de reverter, o estado gravado por aquele plugin entra no journal;
   se a migração for de mão única, a reversão é da instalação inteira pelo backup, não
   do plugin isolado — e isso se decide com o mecanismo na mão, não durante o incidente.
3. **Reversão é temporária e datada.** Ela congela o site numa versão com a
   vulnerabilidade que a política existe para fechar. Entra no relatório com data,
   motivo e a versão de destino, e o item só fecha quando o upstream corrige e o site
   volta à última. Reversão sem data de volta é a exceção que a política recusou,
   entrando pela porta dos fundos.

Nota de fato, para não prometer o que não existe. **Três dos plugins do catálogo não vêm do
WordPress.org**: o servidor do canal, o complemento do canal e — desde a 1.7.0 — o próprio
`base-site-core-fator3`. Os três descem de URL declarada, e para eles não há histórico de
versões publicado por terceiro de onde reverter. O caminho dos três é release nossa, por
upload com sobrescrita e reativação — o instalador desativa ao sobrescrever, e o canal não se
autoedita por desenho.

**Reverter o `base-site-core-fator3` é publicar de novo, e a assimetria importa.** A reversão
dele não é "instalar a versão anterior do .org": é republicar, no endereço declarado do
catálogo e com o nome `base-site-core-fator3.zip`, o zip da versão para a qual se quer voltar
— o que significa que **quem reverte precisa ter guardado aquele zip**, porque o catálogo
serve um arquivo só, sem histórico. Enquanto o endereço não for republicado, os sites
continuam recebendo o que estiver lá; e enquanto ele estiver fora do ar, toda implantação cai
na RESERVA versionada do bundle, que é a versão que aquele bundle carrega — nunca a anterior.

**E a reversão tem um segundo lado, deste repositório.** Republicar o zip antigo devolve a
versão anterior aos sites que ainda vão ser implantados; o pacote que fica aqui continua
carregando a reserva e a cópia vendorizada da versão que saiu — e o `sha256` dela declarado
no catálogo, que passaria a divergir do que a URL serve. Voltar por inteiro são as MESMAS
três edições de uma release do plugin, com o zip anterior no lugar do novo: trocar o
arquivo em `assets/plugins/`, declarar o `sha256` dele em `config/decisoes.tsv` e reextrair
`partilhado/` de dentro dele conforme `partilhado/VENDORIZADO.tsv`. Pular qualquer uma é
medido: `pacote.reserva_confere_com_o_catalogo` e `pacote.copia_vendorizada_confere`
reprovam nomeando o que divergiu.

**Flag ligada e caminho de atualização são fatos diferentes, e saem em duas linhas.**
`plugins.autoupdate_conforme_politica` mede o que sempre mediu: a flag está no banco,
lida de volta plugin a plugin. Ela não mede caminho. A política é categórica e continua
como está — **Atualização automática ligada para TODO plugin instalado** —, e a flag a
executa. `plugins.autoupdate_caminho` mede a segunda pergunta, com medição
LOCAL: o cabeçalho `Update URI` de cada plugin instalado, lido do
disco, mais `has_filter()` sobre `update_plugins_{host}`. Nenhuma consulta de rede
acontece ali, e o que ela pergunta é **o caminho observado corresponde ao declarado?**

A semântica é a do núcleo do WordPress, que é quem decide de fato: sem `Update URI`, o
núcleo consulta o WordPress.org pelo slug; com `Update URI` de host `wordpress.org` ou
`w.org`, quem responde é o WordPress.org; com `Update URI` de qualquer outro host, o
núcleo **não** consulta o `.org` e despacha o filtro `update_plugins_{$hostname}`.

As classes ESPERADAS saem todas nomeadas na linha, e nenhuma delas é pendência: **artefato
deste pacote** (tema, `site-core` e o implantador — release nossa, por upload), **origem
`url`/`bundle` declarada** (os dois plugins do canal — release do fornecedor, por upload),
**dependem do WordPress.org por slug** (declarados `wordpress.org`, o plugin operacional
da hospedagem e os instalados por fora, todos sem `Update URI` conflitante), **atualizador
do fornecedor de pé** e **consulta desligada pelo próprio artefato**. Comportamento
declarado pelo pacote, que ninguém vai mudar e para o qual ninguém tem ação a tomar, não é
pendência: a linha fecha **OK** e diz o que mediu, sem afirmar mais do que mediu.

Sobra **um** achado adverso, e ele é medido: `Update URI` para um host de terceiro **sem**
o filtro `update_plugins_{host}` registrado. Aí o cabeçalho tira o plugin da consulta ao
`.org`, ninguém responde pelo gancho, e a flag ligada não alcança nada — **WARN**,
nomeando plugin e host. **BLOCKED** é o escopo vazio: nenhum plugin classificado,
que é pré-condição ausente de verdade. Limite da medição não é pré-condição ausente: uma
classe "pendente — só se decide por rede" em BLOCKED promoveria a unidade inteira em toda
execução sem que nada estivesse errado.

## O arquivo `llms.txt`, e o que o site diz a um leitor automático

O site serve `/llms.txt` por rota virtual, em `template_redirect` prioridade 0. A
chave-mestra é `bots_ia.llms_txt`: desligada, o módulo fecha inativo e não existe hook,
rota nem superfície pública nenhuma.

**Um endereço tem um dono, e a precedência é declarada.** Um arquivo físico `llms.txt` na
raiz vence — a mesma física do `robots.txt`. Em seguida vem o **emissor concorrente
medido**: se o plugin de SEO estiver com a publicação do arquivo ligada, ele responderia
pela mesma URL, e então o módulo daqui **sai de cena** e o estado dele NOMEIA quem ficou,
dizendo onde desligar. Só quando não há arquivo nem concorrente é que a rota deste pacote
responde. É a mesma regra de `tracking.emissor_unico`: duas respostas para o mesmo
endereço é o defeito, e quem cala é quem chegou depois.

### O `/llms.txt` é o PRÓPRIO, e o concorrente é desligado pelo implantador

**A 2.0.0 entregava o endereço ao plugin de SEO, e ninguém via.** Medido no site em
2026-09-07: a unidade de SEO ligava `enable_llms_txt` junto com o módulo daqui, e com ela
ligada o plugin de SEO **gravava um arquivo físico na raiz** — que vence a rota do
`site-core` pela precedência acima. A curadoria escolhida na entrega ia para a option
`wpseo_llmstxt`, com chaves (`manual`, `pages`, `privacy_policy`) que a versão instalada do
plugin **não lê**: ele lê outras (`llms_txt_selection_mode`, `contact_page`, `terms_page`,
`privacy_policy_page`, `other_included_pages`, …). O resultado publicado era a seleção
automática DELE — "Contato" selecionada e fora do arquivo, "Blog" não selecionada e dentro.
E a linha antiga, `seo.llms_selecao`, fechava OK: ela media a própria escrita, não o que o
endereço servia.

**Na 2.1.0 o concorrente é desligado, sempre**, e são três fatos relidos:

1. `aplicar_geral()` grava `enable_llms_txt` como o literal `false` — não é condicional, não
   depende de chave nenhuma. Quem serve `/llms.txt` neste pacote é a rota do `site-core`,
   com a curadoria em `f3base_llms`, e ligar os dois é entregar o endereço a quem não lê a
   curadoria;
2. a unidade `seo.llms_proprio` **relê a chave do banco** e remove o agendamento
   `wpseo_llms_txt_population`, que repovoaria o arquivo físico na semana seguinte;
3. ela apaga o arquivo físico `llms.txt` da raiz **se ele for do plugin de SEO** — decidido
   pela regra pura `veredito_do_arquivo_fisico_de_llms()`, pela assinatura que o fornecedor
   escreve no corpo do que gera. **Arquivo de outra origem é PRESERVADO e sai nomeado**: só
   se apaga o que se conhece, e um `llms.txt` que alguém pôs ali de propósito continua
   vencendo a rota — a linha diz isso e diz que a remoção é à mão.

A unidade fecha OK só com os três relidos, e `estatica.llms_proprio_sem_concorrente` cobra
o pacote pelas mesmas três cláusulas, com piso. **`bots_ia.llms_txt` governa SÓ o módulo do
`site-core`**: desligada, não há `llms.txt` neste site, e a unidade fecha N/A com a condição
de aplicabilidade falsa declarada.

**Verificado no site real:** desligado `enable_llms_txt` pelo canal, o plugin de SEO removeu
o arquivo físico e `/llms.txt` passou a responder pela rota do `site-core`, com o cabeçalho
`x-f3base-mecanismo: rota-reserva`, a seleção curada na ordem declarada e a enumeração
automática em seguida.

**A lista tem dois eixos, e `bots_ia.llms_txt_modo` diz quais valem.** A CURADORIA é
`seo.llms_selecao`, escolhida na entrega; a ENUMERAÇÃO percorre o conteúdo publicado dos
tipos declarados em `bots_ia.llms_txt_tipos`. O padrão é `curada-mais-automatica`, e a
razão é a premissa desta operação: depois da implantação quem cria página é um agente pelo
canal MCP, e uma seleção só curada deixaria toda página nova fora do arquivo para sempre.
Os tipos válidos são medidos em `get_post_types(['public'=>true])` na instalação — tipo
declarado que este site não tem é descartado com o nome, e tipo que o agente criar depois
passa a poder ser declarado sem release nova.

**Três exclusões, cada uma com um dono só.** Fica de fora o que está em **noindex** — e o
fato vem de `F3Base_Modulo_Noindex_Honrado`, que é quem lê as chaves do plugin de SEO; o
arquivo PERGUNTA a ele, e não lê a meta por conta própria. Os NOMES dessas chaves saem de
`F3Base_Chaves_Seo`, carregado pelos dois runtimes: o implantador escreve as metas que o
`site-core` lê, e sem fonte comum uma renomeação do fornecedor quebraria cada lado no seu
lugar, sem erro e sem aviso. Fica de fora o que já entrou
pela curadoria, e o dedupe é **por ID**, nunca por URL: URL muda quando o slug muda, e o
mesmo conteúdo sairia duas vezes. E fica de fora a política de privacidade quando
`seo.llms_selecao.incluir_politica_privacidade` estiver desligada — a exclusão vale também
no eixo automático, senão a página que a curadoria deixou de fora voltaria pela
enumeração.

**A ordem é declarada.** Página inicial primeiro, porque é ela que define o site; depois os
itens curados **na ordem declarada**, porque a ordem é a curadoria; e só então o
enumerado, páginas antes de artigos e por data decrescente. Ordenar tudo por data joga a
página inicial para o rodapé, depois de qualquer artigo publicado.

**A descrição de cada item tem cadeia, e a fonte que respondeu é nomeada.** Primeiro a
descrição escrita no plugin de SEO, que é o texto que alguém escreveu PARA ser o resumo;
depois o resumo declarado no próprio conteúdo; e só então um corte do corpo. O corte limpa
antes de cortar: remove shortcodes, remove **com o conteúdo** os elementos que são
interface e não texto — `form`, `script`, `style`, `nav`, `aside`, `button`, `svg` —, e
separa os blocos com quebra de linha antes de tirar as tags, para que título e corpo não
colem numa frase só. Sem essa limpeza, uma página com formulário de busca produz um resumo
que termina no rótulo do botão.

**O rodapé aponta o sitemap que este site serve, medido.** Com o sitemap do plugin de SEO
ligado, o endereço é `sitemap_index.xml` — e é preciso medir, porque nesse caso o núcleo
DESATIVA o endereço dele. Sem o plugin, e com o sitemap do núcleo habilitado, o endereço é
`wp-sitemap.xml`. Sem nenhum dos dois, **a seção inteira é omitida**: imprimir um endereço
que ninguém responde é afirmar mais do que se mediu.

**`bots_ia.llms_apresentacao` é o campo de maior retorno do arquivo.** É o parágrafo que
diz o que o site é, para quem e com que oferta, e é ele que um assistente lê antes da lista
de links. Vazio, o arquivo cai para a primeira frase declarada e, na falta dela, para a
descrição cadastrada no WordPress — que serve, mas foi escrita para outra finalidade.

**`bots_ia.llms_indexavel` controla o `X-Robots-Tag`.** Ligado, que é o padrão, a resposta
NÃO leva `noindex`: o arquivo existe para ser ingerido por leitor automático, e `noindex` é
diretiva para indexador — um rastreador que a respeita pode deixar de usar o conteúdo, o
que derrota o propósito do arquivo. Desligado, o cabeçalho volta. Nos dois casos a resposta
continua sem cache.

**`/llms-full.txt` publica o texto integral, e nasce desligado.** A chave é
`bots_ia.llms_full_txt`. Ele usa a MESMA seleção, as mesmas exclusões e a mesma precedência
de emissor do índice curto — dois arquivos com listas diferentes seriam dois vereditos
sobre o mesmo site —, e acrescenta URL, data e o corpo limpo de cada item. Desligado, o
módulo fecha inativo: nenhum hook, nenhuma rota, nenhuma superfície pública. O padrão é
desligado porque o arquivo é uma segunda cópia integral do site em texto puro, com custo
certo de banda e de superfície contra um ganho que é hipótese; ligar é um clique na tela.

Todos os campos acima aparecem na tela de configuração do `site-core`, com rótulo, impacto
— o que muda no site ao ligar e ao desligar — e exemplo de preenchimento.

## O formulário: criado, posto na página declarada, e a confirmação em noindex

**O defeito que criou esta seção vinha da 1.7.4 e foi medido em 2026-09-07: o formulário
era criado e posto em PÁGINA NENHUMA, com a unidade fechando OK.** `pagina_ref` era a única
chave do bloco `formularios` lida de `config/site.json` — onde o bloco não existe, porque
ele mora em `config/projeto.json`. A leitura voltava vazia, `por_na_pagina()` devolvia
string vazia em TODO caminho de falha, e o chamador lia vazio como "nada a acrescentar". O
Contact Form 7 recebeu o formulário, o site ficou sem ele, e o relatório não disse nada.

Duas correções, e as duas são de mecanismo:

- **a página vem do arquivo em que a chave mora.** `F3Base_Imp_Lotes::pagina_ref_do_regime()`
  lê de `F3Base_Imp_Projeto`, que é o produtor único de `config/projeto.json`;
- **a colocação REPROVA quando não acontece.** `F3Base_Imp_Formulario::por_na_pagina()` é
  pública e devolve `{ok, motivo}`. Ela fecha a unidade em FALHA quando a página declarada
  fica sem o formulário — ref vazia, ref que não resolve para um objeto gerenciado,
  gravação recusada, ou leitura de volta sem o shortcode. Os ramos OK são dois e os dois
  são afirmativos: "já estava na página" e "publicado e conferido na leitura de volta".

Quem cobra os dois é `formulario.na_pagina_declarada`: o teto resolve a página de cada
regime na configuração REAL e confere que ela é uma entrada de `paginas`; o piso planta o
defeito — o leitor errado, devolvendo vazio para a mesma chave.

**A página de confirmação nasce em noindex.** Medido no mesmo site:
`/solicitacao-recebida/` saiu no sitemap, indexável como qualquer página de conteúdo. Uma
página que só faz sentido depois de um envio não é resultado de busca.
`marcar_noindex()` grava a meta de noindex do plugin de SEO — pelo nome que
`F3Base_Chaves_Seo::NOINDEX` declara, nunca por um literal novo — na página de
confirmação, criada agora ou já existente, e a linha do relatório diz **página de
confirmação criada, em noindex**. O plugin de SEO a tira do sitemap com essa meta, e o
`site-core` honra o MESMO noindex quando é ele quem responde: fora do `llms.txt` e fora do
sitemap.

## Cadência do modo somente-relatório: como pausar e como retomar

A configuração declara `cadencia_relatorio`: periodicidade **mensal**, ou **a cada 10
ajustes**, o que vier primeiro. Cadência sem agendamento é lembrete, e por isso o
agendamento é item de entrega: quem entrega cria o gatilho e nomeia o mecanismo usado —
agendador do host, cron real do servidor ou tarefa do lado do agente.

**Quem escuta o evento é o `site-core`, não o implantador.** Hook agendado sem
`add_action` que o escute é evento que dispara, é reagendado pelo WP-Cron e não faz nada —
`f3base_cadencia_relatorio` existe nos dois lados. O ouvinte mora no plugin persistente
porque ele é o componente que sobrevive à autodesativação de quem agendou. O módulo **Cadência do modo somente-relatório**
faz três coisas que o agendamento sozinho não fazia:

1. **Registra as recorrências que o núcleo não tem.** `monthly` não existe no WordPress e
   `quinzenal` também não: sem elas, agendar "mensal" cai em `daily` e "quinzenal" cai em
   `weekly` — o dobro da frequência —, as duas em silêncio. O módulo registra `f3base_mensal`
   (trinta dias) e `f3base_quinzenal` (quinze dias); o WP-Cron conta intervalo e não
   calendário, e a aproximação de mês por trinta dias está dita no nome legível.
2. **Executa e registra o que mediu**: última execução, próxima, duração, resultado, erro
   e o atraso do evento sobre o horário previsto. Evento atrasado acima da tolerância
   deixa o módulo DEGRADADO na tela, com o atraso medido.
3. **Conta os ajustes.** `cadencia_relatorio.apos_n_ajustes` é lido de `f3base_cadencia`,
   e cada escrita em option gerenciada conta como um ajuste — carimbo de atividade e
   estado de execução não contam, porque o site mudar porque rodou não é alguém ter
   ajustado alguma coisa. Ao alcançar o número declarado, a execução DISPARA e o contador
   zera. Com o número declarado em zero, nada é contado e o módulo diz na tela que nada
   promete disparar por ali.

Se a recorrência com que o evento está agendado divergir da declarada, o módulo fecha
DEGRADADO **nomeando as duas** — em vez de aceitar a degradação em silêncio.

**O agendamento sai com a recorrência DECLARADA, e a degradação é nomeada.** A etapa
`cadencia` do implantador mapeia `quinzenal` para `f3base_quinzenal` e `mensal` para
`f3base_mensal` — as recorrências que o módulo do `site-core` registra —, nunca
para `weekly` e `monthly`. Se a recorrência declarada não existir no agendador no momento do
agendamento — o caso típico é o `site-core` não estar ativo naquela requisição —, o
evento é agendado assim mesmo, para o site não ficar sem cadência, e `cadencia.agendada`
fecha **WARN** dizendo a recorrência declarada, a usada, o que a diferença custa em
frequência e como sair.

`mecanismo_de_cadencia` está **vazio** nesta base, de propósito: o mecanismo
depende da hospedagem e é preenchido pelo projeto que instancia a base. Vazio **não é
falta** — significa "não há gatilho externo além do WP-Cron", que é o padrão desta base.
O item correspondente da entrega é
`cadencia.mecanismo_declarado`, e nele o **fato medido vale mais que a
declaração**: ele fecha **OK nomeando o mecanismo OBSERVADO** quando há agendamento
medido para o hook — é esse gatilho que o operador desabilita para pausar e reabilita
para retomar. Com a chave preenchida, ele fecha OK nomeando o **declarado** e continua
registrando o observado ao lado, porque são fatos diferentes.

Ele fecha BLOCKED num caso só, e é o caso real: não há agendamento observado E a chave
está vazia. Aí não existe gatilho nenhum a nomear, nem interno nem declarado, e o
relatório de entrega fica sem o que dizer a quem for pausar ou retomar — pré-condição
genuinamente ausente. A chave vazia sozinha **não** basta para o BLOCKED: ela nasce
vazia por desenho, e o aviso sairia em toda execução, para sempre, sobre uma ausência que
ninguém vai mudar — aviso que sai sempre é aviso que ninguém lê. `cadencia.agendada`
responde a outra pergunta: ela mede o WP-Cron e fecha OK porque o agendamento existe mesmo.
Nesse ramo o BLOCKED sai nomeado no relatório e **não** segura a autodesativação: quem a
decide é o gate de aplicação, que lê nomes de entregável.

**Pausar.** Desabilite o gatilho no mecanismo nomeado no relatório de entrega — é lá que
está escrito qual dos três é o seu. A pausa entra no relatório com data, motivo e **data
de retomada**; pausa sem data de retomada é a mesma exceção pela porta dos fundos que a
reversão sem data de volta. Enquanto a cadência estiver pausada, a releitura das options
escritas em plugin de terceiro não acontece — e, com atualização automática ligada, esse
é o único lugar onde ela aconteceria depois da entrega.

**Retomar.** Reabilite o gatilho no mesmo mecanismo e **execute o modo somente-relatório
uma vez, imediatamente**, sem esperar a próxima janela. A execução imediata é o que fecha
a lacuna: ela produz o diff de três vias acumulado no período pausado, classificando cada
divergência como incorporada à próxima versão, mantida como conteúdo externo, ou
corrigida. A data da última execução volta ao relatório, e é ela — não a existência do
gatilho — que sustenta qualquer afirmação sobre o estado atual do site.

## A medição, de ponta a ponta

O site nasce medindo. Esta seção diz o que já funciona, o que exige preenchimento, e o que
o conteúdo precisa declarar para a medição não ficar cega — na ordem em que essas perguntas
aparecem para quem constrói um site novo.

### O plugin tem release própria, e publicar o zip é um passo

O `base-site-core-fator3` é instalado pela **URL declarada** em `plugins.instalaveis`. A
reserva versionada que viaja no bundle entra **apenas** quando aquela URL não responde — um
caminho só de instalação é um lugar só onde ela pode falhar, e é por isso que existem dois.

O efeito colateral é o que mais custa caro: **enquanto o arquivo publicado naquele endereço
estiver atrás da versão que o pacote carrega, toda implantação instala a versão antiga, com
sucesso.** Nada falha e o relatório fecha.

**A release do plugin é cortada no repositório DELE**, e são três passos lá: subir o
`Version:`, rodar a suíte de lá e **publicar `base-site-core-fator3.zip` no endereço
declarado**. É esse último passo — e só ele — que entrega a correção aos sites que já estão
no ar. O nome do arquivo publicado MUDOU na 1.7.0: o `f3base-site-core.zip` antigo não é
lido por ninguém.

**Deste lado, são TRÊS EDIÇÕES e uma rodada**, e nenhuma delas é opcional:

1. **trocar o zip em `assets/plugins/`** pelo publicado, com o nome
   `base-site-core-fator3-<versão>.zip` — é do NOME que a versão da reserva é lida;
2. **declarar o `sha256` novo** em `config/decisoes.tsv`, na chave
   `plugins.instalaveis.<n>.sha256`. Ele é o CONTRATO: é contra ele que a instalação
   confere o byte que desce da URL e o byte da reserva, e é ele que o carimbo gerado no
   topo deste documento imprime ao lado do digesto medido da reserva;
3. **reextrair `partilhado/`** de dentro do zip novo, arquivo por arquivo, conforme
   `partilhado/VENDORIZADO.tsv`. Nada ali é editado à mão: edição em `partilhado/` é fork.

E então `bash suite/verificar.sh <caminho absoluto>`. Sai uma release do implantador,
porque a reserva e a cópia mudaram de bytes e bytes novos são pacote novo. **Pular (1), (2)
ou (3) é medido**: `pacote.reserva_confere_com_o_catalogo` e
`pacote.copia_vendorizada_confere` reprovam nomeando o que divergiu — e foi por não
existirem que a 1.7.4 entregou uma reserva que o catálogo não servia e quatro dos cinco
arquivos de `partilhado/` divergindo do zip publicado, um deles sem a guarda de
`class_exists` que evita erro fatal quando os dois runtimes se encontram.

`plugins.site_core_versao` compara a versão instalada com a versão lida do **NOME da
reserva** e é a DERIVAÇÃO ÚNICA desse fato — até a 1.7.2 o mesmo par de números saía também em
`release.versao_site_core`, com regra própria, e as duas discordaram na severidade dentro
da mesma tela. Ela não impede a instalação nem suspende etapa nenhuma: a versão do plugin
no site é fato do host, e um pacote que se recusasse a entregar por causa dela estaria
protegendo o processo, não o site.

**Versão e BYTES são dois fatos, e saem em duas linhas.** `plugins.site_core_versao`
responde "o site ficou com a versão que este pacote carrega?", e ela não distingue — nem
deve — dois artefatos de mesma versão com bytes diferentes. Quem separa bytes é o digesto,
na linha `plugins.instalado:<slug>`, contra o `sha256` que o catálogo declara. Uma linha só
tentando responder às duas perguntas responderia mal às duas.

**Ela fecha FALHA quando a instalada é menor, e isso tem uma consequência declarada.**
FALHA derruba o estado da aplicação para `FALHA_PARCIAL`, e `SUCESSO_APLICACAO` é a
primeira das três condições da autodesativação: **o implantador não sai do ar num site que
ficou com uma versão superada do plugin.** É o desfecho certo — a ferramenta que corrige
isso é justamente a que ia sair de cena —, e a linha diz as duas saídas com o endereço de
cada uma: publicar o zip novo no endereço declarado e executar de novo, ou enviar à mão,
por *Plugins › Adicionar novo › Enviar plugin*, a cópia embutida, cujo caminho a própria
mensagem imprime. Os outros três ramos não são adversos: site com versão MAIS NOVA que a
reserva fecha OK (este pacote não rebaixa artefato de terceiro), versões iguais fecham OK,
e reserva sem número no nome — o zip que o operador embute — fecha WARN dizendo que não há
com o que comparar.

### Sem preencher nada

Com o `projeto.json` intocado e nenhum ID de fornecedor, o menu **Medição** do wp-admin já
responde: pessoas diferentes por dia; até onde as pessoas descem em cada página, com o
tempo típico até cada marco e quantas releituras — contadas na VISITA inteira, e não em cada
página carregada; cada evento declarado com a pergunta que
ele responde e as páginas em que aconteceu; e as quatro medidas de carregamento com a
explicação e o limiar de "bom" ao lado do valor medido.

Nada disso depende de conta de fornecedor. Os números são somados no próprio site, em
tabela própria, e o agente os lê pelo canal sem credencial de terceiro.

### O que exige preencher

`tracking.*` no `projeto.json` — ou as options pelo canal — para os mesmos acontecimentos
irem também ao GA4, ao Google Ads, à Meta e ao LinkedIn. Slot vazio é inerte: sem ID,
nenhuma tag é emitida e nada vaza. `tracking.gtm_container_id` preenchido decide o caminho e
**desliga toda tag direta**, que é a estrutura que impede a mesma conversão de ser contada
duas vezes.

`fato_juridico.base_legal` continua sendo declaração de quem responde pelo site. Ela pesa
mais desde que a medição passou a guardar dado pessoal pseudonimizado — a política publicada
já descreve a coleta, mas a hipótese legal que a sustenta não é decisão do pacote.

### O conteúdo precisa declarar as seções

Seção vista só é medida em bloco com a classe `f3base-secao-<nome>`, escrita nos **dois**
lugares que o WordPress serve — o atributo `className` do bloco e a classe da `div`. Em um
só, o editor reescreve o outro na primeira edição e a marca some sem aviso.

Página sem seção declarada não gera evento nenhum de seção: o observador é instalado e não
recebe alvo. Quem cria conteúdo novo precisa saber disso, e
`estatica.conteudo_declara_secoes` reprova as duas formas de errar.

O nome sai do markup e nunca do título: nome derivado de texto muda sozinho na primeira
revisão de copy, e a série histórica ganha uma seção nova e perde outra sem que nada tenha
mudado na página.

### A seção entra numa linha e sai em outra, e as duas são declaradas

`f3base_secao_vista` tem **duas** linhas no limiar, e elas moram na mesma célula do TSV:

| Limiar | Valor | O que ele decide |
|---|---|---|
| `visivel` | `0.5` | a seção **entra** quando metade dela está no campo de visão |
| `saida` | `0.2` | a seção **rearma** quando cai abaixo de um quinto |

Entre as duas, nada muda de estado — é uma **banda**, e ela existe de propósito. Com uma linha
só, a razão oscilando em torno de 0,5 rearma e reentra a cada oscilação: a seção parada na
fronteira do campo de visão fabrica ocorrência 2, 3 e 4 sem que ninguém tenha relido nada. É a
mesma disciplina do `histerese_pp` do marco de rolagem, aplicada à seção.

**O preço está declarado:** uma reentrada curta e legítima — quem tira o bloco até a razão 0,3
e o traz de volta — deixa de ser contada. Ocorrência perdida é um número menor; ocorrência
fabricada é um número que descreve um comportamento que não houve.

**Declaração incoerente cai no comportamento simétrico.** `saida` ausente, não numérica,
negativa ou maior/igual a `visivel` faz o cliente usar `saida = visivel`. Uma banda invertida
não é uma banda mais larga: com a saída acima da entrada, o bloco rearma enquanto ainda está
mais visível do que a entrada exige, e cada oscilação vira ocorrência até o teto por visita
cortar.

### A sonda de navegador mora no repositório do plugin

`navegador.comportamento_real` **não é emitida por esta suíte**, e sai declarada em
`suite/excluidas.tsv` com a categoria e o motivo. Ela dirige um Chromium de verdade contra
o cliente ENTREGUE do plugin, e nenhuma das duas pontas existe mais aqui: a fonte do plugin
saiu da árvore, e o `dist/entregue/` que a alimentava era produzido pelo empacotamento do
plugin, que este repositório não executa. Medir o cliente contra uma cópia da fonte que o
site NÃO recebe é o defeito que a 2.0.0 fechou — a bancada aprovaria um arquivo que ninguém
baixa. A sonda roda no repositório do plugin, contra o zip que o catálogo publica.

**Do cliente do plugin, esta bancada continua medindo uma checagem, e ela ficou aqui por um
motivo:** `js.banner_de_consentimento` mede um PAR que só existe deste lado — o `style.css`
do TEMA, que é nosso, contra o cliente de consentimento do plugin, lido de dentro da
reserva. A visibilidade do banner é decidida pelo par (`hidden`, `display`), e um `display`
de autor na folha do tema vence o `[hidden]` da folha do user agent: o defeito mora ENTRE
os dois artefatos, e nenhuma das duas suítes o veria sozinha.

**Um pacote verificado aqui só é um pacote aprovado junto com a rodada selada do plugin.**
O que amarra as duas é o `sha256` declarado no catálogo: é o digesto da release que a suíte
de lá fechou, e é ele que `pacote.reserva_confere_com_o_catalogo` cobra sobre a reserva
desta árvore. Rodada verde aqui sobre uma reserva que o catálogo não serve é exatamente o
que a 1.7.4 entregou.

### O que o agente não deve fazer

Não injetar tag de medição por outro caminho. A emissão é do módulo `tracking` e de mais
ninguém; duas fontes para a mesma conversão contam em dobro e reescrevem o lance do leilão.
Plugin de console entra como **leitor**, com o snippet dele desligado, e
`tracking.emissor_unico` conta os emissores no HTML publicado.

Não escrever nome de evento nem limiar fora das declarações: `dados/eventos-comportamento.tsv`
para os eventos, `dados/vitais.tsv` para as medidas de carregamento. Renomear em qualquer
outro lugar quebra a série histórica sem erro nenhum, e o relatório do mês seguinte sai
vazio sem que ninguém saiba se o site parou de medir ou se os visitantes pararam de rolar.

`f3base/como-usar` responde tudo isso por habilidade, e o manual sai do registro de módulos:
módulo novo aparece nele sozinho.

### Privacidade: duas tabelas, dois prazos

O site guarda um **resumo** (`f3base_comportamento`) — totais por dia, página e evento, que
não identificam ninguém, guardados por 90 dias — e um **registro** (`f3base_eventos`) — cada
acontecimento com apelido do visitante, apelido da visita, o deslocamento em milissegundos desde
o carregamento e o instante em que ele aconteceu, que é **dado pessoal pseudonimizado**, guardado
por 30 dias.

**As duas respondem perguntas diferentes, e o menu Medição diz isso em cada quadro.** O resumo
SOMA por desenho: duas visitas ao mesmo bloco no mesmo dia caem na mesma linha. O registro não
soma e não reescreve nada: cada acionamento é uma linha com `id` próprio. Quem lê a tela sem essa
distinção olha o resumo, vê linhas se somando e conclui que o registro está sendo reescrito —
foi o que aconteceu, e é por isso que a linha existe.

**O horário de cada acionamento é o instante DELE**, e não a hora em que o lote chegou ao
servidor: o navegador manda a origem temporal do carregamento junto do lote selado, e o servidor
soma o deslocamento a ela. Cada linha guarda também de ONDE veio o carimbo — o relógio do
visitante, a âncora derivada do servidor quando aquele relógio não pôde ser usado, ou a hora da
chegada nas linhas gravadas antes desta versão do plugin. A tela mostra isso; um horário sem
procedência declarada seria uma afirmação que ninguém pode conferir.

O apelido é sorteado no navegador, mora no `localStorage` deste domínio e **nunca em
cookie**: cookie viaja em toda requisição, inclusive para o CDN. Ele não é derivado de nada
do aparelho — não há fingerprint — e nasce **depois** do portão de consentimento, de modo
que quem recusou nunca chega a ter um.

A recusa no controle do rodapé apaga o apelido do navegador **e** o registro do servidor, no
mesmo ato. Apagar num lado só faria o próximo aceite ressuscitar o mesmo identificador.

O prazo do registro nunca pode passar o do resumo — o sanitizador impede — e o resumo **não
é derivado** do registro: derivá-lo faria a série do painel evaporar junto com o log na
primeira execução da retenção, perdendo a comparação de trimestre para proteger uma
privacidade que o resumo já protegia sozinho.

### Desligar a medição

O controle é **um só** e já existia: `f3base_comportamento.ligado` — na tela **F3 Base**, em
*Privacidade e retenção*, com o rótulo **"Guardar o resumo no site"**. Não há chave nova, e
não haverá: duas chaves para a mesma decisão são duas respostas para "esta instalação mede?",
e elas divergem na primeira vez que alguém mexer numa e não na outra.

O que mudou é ele ser **encontrável**. O menu **Medição** abre dizendo onde o controle fica e
leva a ele por link com âncora no próprio campo; e com a chave desligada a **primeira** coisa
da tela passa a ser a frase do desligamento — *"A medição está desligada nesta instalação.
Nada é coletado e nada é guardado"* —, em vez de uma tela sem número nenhum, que é
indistinguível de um site sem visita.

Desligado: as páginas param de enviar, a rota recusa com 409 nomeado e nada novo é guardado.
O que já foi guardado continua até a retenção apagá-lo, e **o envio para o Google Analytics,
quando houver, não muda** — são dois destinos independentes, nos dois sentidos.

## Kill switch do canal MCP

O canal é execução remota de código atrás de uma credencial. O desligamento é caminho de
operador e precisa funcionar sem depender do agente.

1. **Interruptor na tela do complemento**, no wp-admin, em Ferramentas. É o caminho de
   primeira mão e não exige acesso a arquivo.
2. **Filtro equivalente no código**, para desligar por `mu-plugin` ou por
   `wp-config.php` quando o wp-admin estiver indisponível.
3. **Revogar a Application Password do usuário dedicado.** Este passo não é opcional:
   desligar as rotas sem revogar a credencial deixa metade da porta aberta, e a
   credencial é o perímetro real.

Duas conferências que precisam acompanhar o desligamento:

- **Canal único.** O complemento é distribuído com identificadores fixos — pasta,
  namespace, diretório de backups e chave de liga-desliga — e nunca prefixado por
  projeto. Uma build prefixada instalada ao lado de uma genérica são, para o WordPress,
  dois plugins, com dois diretórios de backup e **duas** chaves de desligamento: o
  operador desliga o canal e ele continua aberto pelo outro, com a tela dizendo que está
  fechado. A checagem `mcp.canal_unico` acusa mais de um plugin registrando as rotas de
  arquivo, nomeando os dois.
- **Autoteste do canal.** `files/selftest` **é despachado na entrega**, e o resultado
  estruturado vai para o relatório na linha `mcp.autoteste`. O despacho tenta a Abilities
  API primeiro — `wp_get_ability()` e `WP_Ability::execute()`, que é a via canônica dela;
  `wp_execute_ability()` fica como via a mais, para o host que a tiver — e o servidor REST
  interno em seguida — `rest_do_request` —, e a via que respondeu sai nomeada. Até a 1.7.0
  a Abilities API era procurada por `function_exists( 'wp_execute_ability' )`, e essa
  função NÃO EXISTE na API — nem na nativa do 6.9, nem no polyfill que o servidor MCP
  embarca, que expõem `wp_register_ability()`, `wp_get_abilities()`, `wp_get_ability()` e
  `wp_has_ability()`, com a execução no método do objeto. A guarda era falsa sempre, a
  linha fechava BLOCKED em toda instalação limpa e, por ser linha do gate de aplicação,
  segurava `mcp.canal_exposto` e a autodesativação junto. **Autoteste que
  devolve falha REPROVA a entrega**, e **ausência da rota fecha BLOCKED, nunca OK** — não
  medir e medir-e-passar são fatos diferentes. O item que mais importa é a detecção de
  PHP quebrado: se ela estiver inerte, gravar PHP passa a ser perigoso, e é isso que a
  linha diz quando reprova.

  **O que essa linha não prova, e sai declarado:** as duas vias despacham DENTRO do
  processo, com o usuário da requisição já autenticado como administrador, e nenhuma
  passa pela autenticação HTTP. A recusa a uma credencial NÃO autorizada não é
  mensurável daqui, e por isso ela é uma linha própria — `mcp.autoteste_recusa_credencial`
  — declarada na fase **`campo`**, nomeando o que falta: uma requisição HTTP de fora, com
  uma credencial sem a capacidade exigida, e o 401 ou 403 observado na ponta. Quem produz
  essa evidência é o requisitante externo, e não este host: é por isso que a fase é
  `campo` e a linha fecha N/A nomeando a fase, em vez de um BLOCKED que nenhuma execução
  no site poderia fechar. Forjar um
  usuário sem capacidade e despachar internamente mediria o `permission_callback`, não a
  credencial: seria uma prova fraca com nome de prova negativa.

Consequência do desligamento, declarada antes e não depois: sem canal não há fase de
manutenção por agente. Toda mudança estrutural volta a depender de acesso humano ao
servidor, e o implantador deixa de poder se autodesativar em uma execução futura.

## Mídia embarcada e a justificativa de formato

`assets/` carrega quatro binários e um slot. Os quatro binários são gerados a partir da
paleta declarada no `theme.json` — `inverso`, `primaria` e `base`. Nenhuma cor nova foi
introduzida, e o detector `tema.sem_cor_literal` cobre o SVG inline junto com o resto.

| Arquivo | Papel na configuração | Formato e medida |
|---|---|---|
| `assets/logo.png` | `custom_logo` | PNG 512 × 512, 15 546 bytes, fundo transparente |
| `assets/logo.svg` | `marca_inline` | SVG sem cor literal, 656 bytes: o desenho usa `currentColor` e herda a cor do contexto, com `title` e `aria-label` próprios |
| `assets/favicon.png` | `site_icon` | PNG 512 × 512, 2 790 bytes |
| `assets/social.png` | `og_default_image` | PNG 1200 × 630, 3 272 bytes |

`assets/plugins/` não é mídia: ele carrega o `LEIA-ME.txt` que descreve o slot do operador
— `<slug>.zip`, para o projeto que queira instalar sem chamada de rede — e a RESERVA
versionada do plugin do site, `base-site-core-fator3-<versão>.zip`, que é o zip do catálogo
copiado byte a byte e conferido por `pacote.reserva_confere_com_o_catalogo`. O diretório
entra no inventário como prefixo declarado.

**Por que PNG e não WebP ou AVIF.** O método pede WebP ou AVIF salvo justificativa
escrita no relatório, e aqui a justificativa é de compatibilidade do consumidor, não de
peso. Os papéis em jogo são consumidos por software que não é o navegador do visitante:
o `site_icon` do WordPress gera e serve os tamanhos derivados do ícone, e a imagem padrão
de Open Graph é lida por rastreadores de redes sociais e aplicativos de mensagem. O
suporte a WebP nesses consumidores é inconsistente, e o modo de falha é o pior possível —
ícone ou prévia que simplesmente não aparece, sem erro em lugar nenhum. PNG é o formato
que eles consomem de forma confiável.

**Por que o logo é PNG, com o vetor preservado.** `custom_logo` exige anexo na
biblioteca de mídia, e o WordPress recusa SVG por padrão — recusa correta, porque SVG é
vetor de XSS, e habilitar o MIME no site seria decisão de segurança que este pacote não
toma. O bitmap assume o papel de anexo; o vetor continua no pacote sob o papel declarado
`marca_inline`, servido pelo tema dentro do próprio markup e nunca enviado para a
biblioteca. As duas decisões, com custo e caminho de reversão, estão em
`MEMORIA-DECISOES.md`, decisão 11.

## Suposições e desvios

Cada item abaixo é um estado declarado deste pacote, com a consequência escrita. Nenhum
deles é omissão.

### Estado da última rodada integral

1. **A rodada integral fecha sem FALHA.** `bash suite/verificar.sh <caminho absoluto>`
   sobre este pacote sai com código 0. **A contagem por estado desta rodada não é digitada
   aqui**: ela é resultado da rodada, e quem a carrega é `suite/rodada.json`, gravado
   pelo selo com o hash do pacote que aquela rodada mediu. O que é estável e vale
   escrever: a checagem que pede WordPress rodando ou tráfego
   real fecha **N/A nomeando a fase em que ela é medida** — não falta ação de ninguém ali,
   falta a fase —, e o **BLOCKED** que sobra é pré-condição ausente NA FASE CERTA. Nenhuma
   das duas é defeito do pacote e **nenhuma das duas impede a autodesativação**:
   quem a decide é o gate de APLICAÇÃO — os entregáveis nomeados e os dois
   vereditos de canal —, enquanto BLOCKED de FASE sai nomeado e não segura a ferramenta.
   Em WARN sai **uma**
   linha: `conteudo.demonstrativo`, o aviso de que este pacote ainda é o template — some
   no passo em que o conteúdo do site novo entra. `fases.registro_de_execucao` continua
   sendo o contrapeso obrigatório da regra de fase — ela nomeia as fases declaradas que
   NUNCA rodaram e tinham o que medir —, e nesta rodada não sobrou fase nessa condição.

   **O que a construção desta release mediu, como HISTÓRIA e não como estado corrente.**
   A rodada que fechou a 2.0.0 saiu com **FALHA 0**, um único BLOCKED —
   `entrega.rodada_limpa`, que é BLOCKED por desenho, porque a rodada PRODUZ o registro que
   o host consome — e um único WARN, `conteudo.demonstrativo`. Ela emitiu 169 linhas contra
   as 224 da 1.7.4, e a diferença inteira está declarada: **59 rótulos saíram desta suíte**
   porque o objeto que eles mediam é o PLUGIN, e o plugin passou a ter repositório e suíte
   próprios. Cada um está em `suite/excluidas.tsv` com categoria fechada e motivo, e
   `excluidas.declaradas` reprova a linha que nomeie uma checagem que esta rodada ainda
   emite. Checagem que some sem declaração é indistinguível de checagem esquecida — é
   assim que a cobertura encolhe sem que nada acuse, e foi por isso que a lista existe em
   vez de o silêncio bastar.

   Na mesma construção, o piso rodou os 65 detectores com fixture em disco, nos dois ramos
   de cada um, sem ramo pendente; e a rodada foi repetida sobre o pacote RENOMEADO para o
   prefixo `acme`, fechando também com FALHA 0, com `estatica.sem_residuo_de_prefixo` em OK
   e com `f3base_operaveis` e `f3base_proveniencia` — as duas options de fronteira que a
   1.7.4 só preservava pela derivação de diretório — preservadas pelo contrato vendorizado.

   **A 2.1.0 acrescentou uma quarta categoria a `suite/excluidas.tsv`: `retirada`.** As
   outras três — `plugin`, `substituida`, `instrumento` — dizem que a medição mudou de
   endereço. Esta diz outra coisa: **a pergunta deixou de ser do implantador**, por decisão
   do dono, e ninguém a mede em lugar nenhum. Saíram por ela
   `privacidade.controlador_identificado`, `projeto.fato_juridico_coerente`,
   `entrega.convergencia`, `lotes.gate_de_aplicacao_sem_dado_do_operador` e
   `estatica.precondicao_no_eixo`; do lado do host saíram `lgpd.base_legal_declarada` e
   `seo.llms_selecao`, esta substituída por `seo.llms_proprio`. Entraram
   `conteudo.politica_de_privacidade`, `limpeza.plano_dos_padroes`,
   `formulario.na_pagina_declarada`, `plugins.supressao_por_transiente`,
   `estatica.llms_proprio_sem_concorrente` e `entrega.documentacao`. O saldo do piso é um
   detector trocado por outro: saiu `estatica.precondicao_no_eixo`, entrou
   `estatica.llms_proprio_sem_concorrente`.

### Desvios do documento do método

1.1. **O layout de arquivos do contrato ganhou `ferramentas/` e `TEMPLATE.md`.** O contrato
   descreve a árvore do pacote base, e a allow-list EXECUTÁVEL do empacotamento é
   `suite/inventario.tsv` — é ela que aborta o build com o nome do arquivo fora da lista.
   Os cinco arquivos de `ferramentas/` e o `TEMPLATE.md` entraram no inventário com papel
   declarado, como `fontes/` e `dist/` entraram antes deles. O desvio está aqui declarado,
   não omitido: nenhum deles é código que roda no site, e nenhum viaja para dentro do
   WordPress a não ser como parte do bundle.


2. **Fontes de sistema em vez de webfont auto-hospedada.** O `theme.json` declara duas
   pilhas nativas e nenhum `fontFace`, porque `tema.fontes` está vazia e não há binário
   de fonte no pacote. A regra de fonte auto-hospedada continua valendo e o caminho de
   retorno está em `MEMORIA-DECISOES.md`, decisão 8. Custo: o site não tem tipografia
   de marca.
3. **PNG em vez de WebP ou AVIF** para ícone do site, imagem social e logo, pela
   justificativa de compatibilidade da seção de mídia. Decisão 11.
4. **Duas exceções de `wp:html` no tema**, declaradas em `tema.wp_html_excecoes` com
   motivo: o link de pular para o conteúdo e o botão do controle de consentimento.
   Navegação nunca. O conteúdo editorial não tem nenhuma.
5. **Nenhum `core/image` no conteúdo editorial.** Os quatro itens de `midia` servem a
   `custom_logo`, `marca_inline`, `site_icon` e imagem padrão de Open Graph — papéis de
   configuração, não blocos de conteúdo. Imagem dentro de conteúdo exige o identificador
   do anexo injetado no bloco em tempo de deploy, e esse identificador muda por
   instalação: ele não pode viver no arquivo. Os blocos `core/cover` do conteúdo usam
   apenas sobreposição de cor de preset, sem imagem de fundo.

### Chaves de configuração e o que cada uma implica

**Nem tudo que o pacote decide é chave de configuração, e essa separação tem regra.**
Uma chave só se justifica se passar nas duas metades: existe projeto legítimo em que o
valor certo é DIFERENTE, **e** o valor é impossível de derivar do site, do exemplo ou do
ambiente. Valor com uma resposta certa só reprova a primeira metade — e chave que só pode
ter uma resposta certa não é ponto de extensão, é um comentário com preço de
configuração. Ela não ganha padrão melhor: sai da configuração.

Para onde ela vai depende do que ela é — e são quatro arquivos, cada um com uma natureza:

- **`config/decisoes.tsv`** guarda a decisão do PACOTE, com três colunas — chave, valor em
  JSON e o MOTIVO, que diz o que aconteceria se o valor fosse outro. É onde moram o piso
  de PHP, os limites mínimos, os cabeçalhos de segurança, o orçamento de página, a
  política de plugins, a lista de plugins instaláveis e a política de bots de IA. Quem lê
  é `F3Base_Imp_Decisoes`, e mais ninguém.
- **`config/releases-suportadas.tsv`** guarda um fato da história do pacote: de qual
  versão instalada este implantador sabe subir.
- **`config/projeto.json`** guarda o que ESTE site tem de decidir, e é o único dos quatro
  que o operador abre. Cada campo nasce **vazio**, com uma exceção declarada: onde o
  template tem um valor obviamente certo para o contexto dele — o fuso é o caso —, o campo
  nasce preenchido e o `$comment` diz que aquele é o valor do template e em que situação
  trocá-lo. Campo que nasce certo é melhor que campo que nasce vazio; o que não pode é
  campo que nasce vazio quando existe resposta certa. Cada `$comment` diz também **onde
  obter** o valor — o console do fornecedor, o contrato social, o painel da hospedagem —,
  porque o operador não deveria precisar de nós para saber onde achar o que preenche.
- **`config/site.json`** guarda o que sobra: conteúdo declarado, referências internas entre
  objetos e a identidade técnica do pacote renomeado.

**Vazio não é erro por si, e degrada como o resto do pacote.** Quando a ausência só desliga
um recurso, a linha fecha **N/A** com a condição declarada, nomeando a chave a preencher e
dizendo que preenchê-la faz o recurso existir. **BLOCKED ficou reservado para pré-condição
que o PACOTE precisa e não tem**; dado do operador que falta sai na linha com a consequência
declarada, e não segura a entrega — a ordem inteira está em "A ordem da operação".

**Base legal, prazo de retenção e padrão de consentimento são um fato só com três faces**, e
por isso moram juntos em `fato_juridico`. A base sustenta o tratamento, o prazo é a
proporcionalidade dessa base à finalidade, e o padrão de consentimento é a postura que ela
implica no navegador. **O pacote lê as três e não julga nenhuma desde a 2.1.0**: a base
alimenta o texto da política, o prazo alimenta a retenção do `site-core`, e o padrão de
consentimento é decisão do pacote. `projeto.fato_juridico_coerente`, que media as duas
primeiras como conjunto, saiu — a declaração jurídica é de quem responde pelo site. Nenhuma
preenchida é o estado de entrega do template: o pacote não declarou nada porque não tem como
declarar.

Repetir o valor de uma decisão como literal fora do produtor é a segunda fonte que a
migração existiu para fechar, e `decisoes.fonte_unica` a reprova: chave que volta para a
configuração ou para o schema, leitura por outro caminho, padrão repetido na chamada e
valor de texto virando constante são todos achado. Literal em COMPARAÇÃO não é achado —
é o código reconhecendo o vocabulário em que a resposta vem.


6. `ambiente.url_canonica` vazia **não segura nada**. O site nasce INDEXÁVEL e o
   implantador só segura a indexação quando MEDE uma guarda — ambiente do núcleo
   declarado como não-produção, `home_url()` em HTTP puro, `ambiente.tipo` diferente de
   `producao`, ou host casando com sufixo de `ambiente.dominios_de_previa`. Guarda que
   dispara fecha WARN nomeando a si mesma, o valor observado e como forçar.

   **Não há lista de domínios autorizados no pacote.** Ela não seria condição de
   `blog_public`, nasceria vazia, e o único
   efeito de preenchê-la seria ganhar um WARN quando o host diferisse — regra que gera
   confusão sem comprar nada.
7. `ambiente.permalinks_decisao` é `aplicar-e-cobrir`, o padrão: ele
   **aplica** a estrutura declarada **e cobre** com 301 o caminho antigo de todo
   conteúdo publicado que muda de endereço — gerenciado por este pacote ou não. O par
   entra na união declarada de `f3base_redirects` com origem própria, pelo mesmo
   produtor único das outras fontes, e o par cujo caminho **não** muda continua sendo
   descartado, porque redirecionar um endereço para ele mesmo é laço: `/sample-page/`
   sob `/%postname%/` é exatamente esse caso. O relatório **nomeia** cada URL coberta,
   uma a uma, em vez de contá-las.

   Os outros três valores continuam declaráveis e com o comportamento de sempre.
   `aplicar-se-seguro` MEDE antes de decidir e recusa a troca diante de publicado NÃO
   gerenciado com URL de caminho, fechando **BLOCKED sem escrita** e nomeando cada
   objeto em risco com id, tipo, slug e caminho; `aplicar-declarada` aplica sempre,
   **sem** cobrir a URL de terceiro, e registra o risco assumido; `manter-existente`
   nunca aplica.

   A reserva "este pacote não escreve redirect para conteúdo alheio" vale para escrita
   **destrutiva**, e o redirect não é uma: ele é **aditivo e reversível** — não altera o
   objeto, não apaga nada e some quando a option some. Aplicá-la aqui custaria entregar o
   site com a estrutura de permalink que ninguém escolheu, por causa de duas páginas que o
   próprio WordPress cria.
8. `conteudo.exemplo_do_wordpress` é `lixeira`, ligado por padrão, porque a regra deste
   pacote é **nascer pronto para produção**. `Hello world!` e `Sample Page` não são
   conteúdo de ninguém: são o que `wp_install_defaults()` insere em toda instalação, e
   deixá-los publicados num site entregue põe `Sample Page` no sitemap, na seleção do
   `llms.txt` e na busca.

   O que decide **não é o slug** — slug igual não prova nada, e é a mesma regra que
   governa a adoção de objeto. O objeto só é conteúdo de exemplo se **ainda for o que o
   WordPress criou**, e a prova é a **identidade** contra o que `wp_install_defaults()`
   produz: título E conteúdo idênticos ao que o núcleo escreveria agora — o esperado sai
   das mesmas chamadas de tradução que o instalador usa, no locale da instalação. Objeto
   gerenciado por este pacote e objeto em uso como `page_on_front`, `page_for_posts` ou
   `wp_page_for_privacy_policy` também ficam.

   **A CLÁUSULA DA DATA SAIU NA 2.1.0, e quem a tirou foi a medição.** Até a 2.0.0 exigia-se
   também que `post_modified_gmt` não tivesse avançado sobre `post_date_gmt` — "ninguém
   editou". O instalador da hospedagem toca o post: medido em 2026-09-07, o `Hello world!`
   nasceu às 16:03:08 e foi tocado às 16:03:10, dois segundos depois, sem ninguém editar
   nada. Com a cláusula, ele era preservado como "editado" e ia ao ar — no sitemap, no
   `llms.txt` e com a categoria Uncategorized junto. **Quem edita muda o TEXTO, e a data que
   o instalador toca não é texto**: título e conteúdo idênticos ao que o núcleo escreve já
   são a prova de que ninguém editou. O caso "data avançada" passou de MANTER para LIXEIRA
   na bancada, e o piso negativo continua sendo o que importa.

   O que casa vai para a **lixeira**, nunca para exclusão definitiva: é reversível com um
   clique em Restaurar, entra no journal com a operação inversa, e o relatório **nomeia**
   o objeto e imprime **o discriminante que decidiu** — dizer que removeu não basta.
   Quem reescreveu o `Hello world!` para publicar um texto de verdade deixou de ter
   conteúdo de exemplo, e esse objeto é **intocável**: fica publicado, sai relatado em
   `conteudo.nao_gerenciado_publicado` e é coberto pelo 301 se o caminho dele mudar.
   Declarar `manter` desliga a etapa inteira.

   A etapa roda **antes** da troca de estrutura de permalinks, e a ordem é decisão: o
   que sai daqui deixa de ser publicado e não ganha um 301 para um endereço que passaria
   a 404.
9. `contato.whatsapp_e164` vazio: **o regime do WhatsApp não existe.** O CTA que ainda
   aponta para o destino do modelo não é publicado, e a presença do valor é a única
   condição do regime: não há interruptor `ativo` na entrada do formulário, porque seriam
   dois fatos podendo discordar — o regime declarado ATIVO e BLOCKED por falta de
   destino na mesma execução. Com a chave vazia, `formulario.contato-whatsapp` fecha
   **N/A** com a condição de aplicabilidade falsa declarada, dizendo onde a chave mora e o
   que preenchê-la faz. Nenhum número falso aparece no HTML. **O número é preenchido ANTES
   da execução única**, em `config/projeto.json`; depois dela, o ajuste é pelo canal — a
   option `f3base_contato` do `site-core` é operável, e o CTA do modelo passa a apontar
   para a conversa na hora, sem passo manual e sem nova execução. É isso que a mensagem
   diz, e é isso que ela deixou de dizer na 2.1.0: "execute de novo" descrevia um ciclo que
   a operação não tem.

   **A SUPRESSÃO É ESTREITA, e o motivo é a premissa desta release.** Suprimir QUALQUER
   bloco com a classe do CTA quando o número está
   vazio, e reescrever o `href` sem olhar quando está preenchido, faria sumir da página a
   cada render — sem erro e sem log — o `href` para uma landing de
   campanha, o `tel:` e o formulário próprio que o agente publicou pelo canal MCP. A regra
   tem dois lados que não se cruzam:

   - **o bloco só deixa de ser publicado quando não tem destino nenhum** — `href` vazio,
     `#` ou o marcador do modelo, **e** número vazio;
   - **o `href` só é reescrito quando é o do modelo** — `tel:`, landing, formulário
     próprio e qualquer outro destino ficam como estão, no servidor e no clique.

   Os quatro quadrantes têm piso em `leads.cta_preserva_destino`.

   **E A REGRA RODA.** `promover_cta()` está no filtro `render_block`, e
   `F3Base_Site_Core::registrar()`
   pula os hooks de módulo inativo. Com `contato.whatsapp_e164` vazia o módulo
   fecha inativo — e o filtro só existiria quando houvesse número, isto é, quando a condição
   da supressão já não pode acontecer, com o
   botão morto do pattern indo ao ar em toda instalação sem número.

   Por isso o hook traz uma exceção **declarada no próprio item**: `sempre => true`. Ela
   alcança um hook só, e o motivo é que a decisão dele é POR BLOCO, não pelo estado do
   módulo — o caso mais importante dela acontece justamente com o módulo inativo. O resto
   continua valendo: módulo inativo não enfileira asset, não registra endpoint e não cria
   tabela. `cta.regra_de_publicacao_registrada` mede os quatro quadrantes por
   `apply_filters()`, com o módulo no estado que ele terá em produção — nunca por chamada
   direta, que não mede o registro do hook.
10. `formularios[].caixa_de_leads` vazia, na entrada do regime `cf7-email`: pela mesma
    regra, o regime não existe neste site e `formulario.landing-cf7` fecha N/A nomeando a
    chave a preencher. O conjunto fechado do regime continua declarado para quem precisar
    dele. A chave mora **dentro da entrada do regime**, e não no
    topo de `contato`, ao lado de `whatsapp_e164`: a simetria seria falsa, porque o número
    do WhatsApp tem consumidor em runtime e a caixa de leads não tem nenhum.
11. `contato.controlador` com `razao_social`, `documento` ou `endereco` vazios: **a página
    da política de privacidade PUBLICA assim mesmo, com o marcador vazio à vista.** O
    status de toda página é o DECLARADO, e nenhuma guarda de conteúdo o rebaixa desde a
    2.1.0. Até a 2.0.0 uma guarda medida a segurava em `draft` até os três estarem
    preenchidos, e `privacidade.controlador_identificado` fechava BLOCKED nomeando quais
    faltavam; as duas saíram por decisão do dono — **o que a política afirma é
    responsabilidade de quem responde por ela**, e o implantador não é quem confere o texto
    jurídico de ninguém. O que ele continua fazendo é interpolar: os marcadores
    `%f3base:contato.controlador.*%` do arquivo de conteúdo viram o valor daquele caminho,
    escapado, e vazio vira vazio. **A consequência é declarada e o preço é do operador**:
    política publicada sem dizer quem é o controlador é notificação deficiente na face do
    art. 9º da LGPD, razão social, documento e endereço são dado que só o operador tem, e o
    pacote não os inventa. Preencha os três em `config/projeto.json` **antes da execução
    única**, ou edite a página pelo canal MCP depois — não há terceira via, e não há "execute
    de novo".
12. `contato.controlador.encarregado` vazio é estado normal e **não** segura a
    publicação: o texto da política passa a dizer que o canal de contato do site recebe
    os pedidos do titular, em vez de nomear alguém que este pacote não conhece.
    Preenchido, a redação nominal do art. 41 entra no lugar dela. As duas redações moram
    no arquivo de conteúdo, em blocos que se excluem pela condição declarada no atributo.
13. `paginas[*].papel` declara o PAPEL ESTRUTURAL de uma página, e hoje há um valor:
    `politica-privacidade`. É dele — e só dele — que sai a resposta a "qual página é a
    política": é ela que o núcleo grava em `wp_page_for_privacy_policy`, é ela que recebe a
    interpolação do controlador, e é ela que `conteudo.politica_de_privacidade` mede. Ler
    essa identidade de
    `seo.llms_selecao.politica_privacidade` teria este efeito: desligar `bots_ia.llms_txt`
    e limpar a seleção — operação legítima, que o nome da chave convida a fazer — pararia
    de gravar a option do núcleo E derrubaria a identidade da política em "condição de
    aplicabilidade falsa", com o relatório verde. `seo.llms_selecao.incluir_politica_privacidade`
    é hoje um booleano de INCLUSÃO: ligado, a política entra na seleção do `llms.txt`;
    desligado, sai da seleção e nada mais muda.
14. **Os slots de medição vazios: nenhuma tag é emitida, e a ausência é dita pelo nome
    da chave.** São seis, e todos nascem vazios: `f3base_gtm_container_id`,
    `f3base_ga4_measurement_id`, `f3base_google_ads` (`conversion_id` e
    `conversion_label`), `f3base_meta_pixel_id`, `f3base_linkedin_partner_id` e
    `f3base_linkedin_conversion_id`. Com `tracking.linkedin_partner_id` vazio, como nesta
    base, nenhuma tag do LinkedIn é emitida: slot vazio é inerte por desenho, e ausência
    de ID nunca vira placeholder.

    **Uma chave decide o caminho, e um caminho só.** Com `f3base_gtm_container_id`
    preenchido o site emite **apenas** o contêiner e alimenta o `dataLayer` com objetos
    `{event: …}` que um container lê como gatilho, e **os IDs diretos nem chegam ao
    navegador** — não é um `if` no cliente, é o dado que não viaja, e por isso a mesma
    conversão não pode sair duas vezes. Vazio, o site carrega o `gtag.js` de verdade (GA4
    e Google Ads no mesmo `gtag`), o Pixel da Meta e o Insight Tag do LinkedIn, a partir
    dos IDs presentes.

    **Um estado de consentimento, quatro tags.** As quatro passam pelo mesmo
    `permite_tags()` no servidor e pelo mesmo `permiteTags()` no navegador. Consent Mode
    v2 continua valendo para o `gtag`; Pixel e Insight Tag não têm equivalente, e por isso
    na negativa eles **não são carregados** — não existe "atualizar para negado" para quem
    já carregou.

    **O clique do CTA é a conversão deste site.** O formulário é opcional e o clique é o
    lead: `generate_lead` sai sempre no GA4, a conversão do Ads sai com
    `send_to: AW-<id>/<label>` quando as duas metades estão declaradas, o `Lead` da Meta
    sai com `eventID` — e ele deduplica contra o evento de SERVIDOR descrito abaixo — e o
    `track` do LinkedIn sai com o ID de conversão declarado. Tudo de um lugar só, em
    `f3base-leads.js`, antes de a navegação acontecer. As Enhanced Conversions do Google
    existem no arquivo e **nascem inertes**: elas só têm o que hashear quando um
    formulário associado fornece e-mail ou telefone, e o template desta base não tem
    formulário nenhum.

    **Não há interruptor para os eventos recomendados do GA4**, nem option de grupo que
    existisse só para carregá-lo. Seria interruptor ao lado do dado que já
    decide: sem measurement ID gravado nada carrega o `gtag.js`, e sem `gtag.js` o disparo
    não acontece de qualquer jeito; com o ID gravado, não há por que não disparar — quem
    gravou o ID pediu a medição. A chave, os tokens que não podem sobrar dela e o motivo
    estão em `suite/chaves-removidas.tsv`, e a decisão, na memória de decisões.

    **Os identificadores de clique chegam ao lead.** Além dos cinco UTMs, a atribuição
    transporta `gclid`, `gbraid`, `wbraid`, `msclkid`, `fbclid`, `li_fat_id` e os cookies
    `_fbc` (montado a partir do `fbclid`, no formato que a Meta declara) e `_fbp` —
    primeiro toque, mesmo TTL. O schema do endpoint de leads é fechado e os aceita pelo
    nome; chave de fora dele continua sendo recusada com 400.

    **A METADE DE SERVIDOR DA META EXISTE, e é ela que faz o `eventID` valer alguma
    coisa.** Deduplicar contra um evento de servidor que nunca é enviado é pagar o
    preço da deduplicação sem receber a cobertura, e o pixel de navegador é a metade que
    o iOS e os bloqueadores cortam. O módulo `meta-capi` envia o evento `Lead` para a
    Conversions API **depois da persistência confirmada** do lead, com o **mesmo
    `event_id`** — que é o `correlation_id` nascido no navegador, e é essa identidade que
    faz a Meta contar uma conversão em vez de duas.

    - **O token é option, e nunca configuração.** `f3base_meta_capi_token` é segredo do
      site e **não existe** no `config/site.json` nem no schema: o arquivo único viaja
      dentro do zip e chega a quem faz o upload, e segredo em arquivo que viaja é segredo
      copiado. Quem o grava é o agente, pelo canal; nenhum lote do implantador o escreve, e
      `estatica.segredo_fora_da_configuracao` reprova se o nome reaparecer na configuração,
      no schema ou numa gravação do implantador.
    - **Sem token nada é enviado**, e o módulo fecha inativo nomeando a option. Com token e
      `f3base_meta_pixel_id` vazia ele fecha degradado nomeando a dependência: o endpoint é
      `/<pixel-id>/events`, e sem o ID não há destino.
    - **Nada de dado pessoal em claro.** E-mail e telefone saem em SHA-256 sobre o valor
      normalizado **pela regra da Meta** — que não é a do Google: para o e-mail é espaço
      fora e minúsculas, e só; para o telefone são dígitos com código de país e sem o `+`.
      Telefone sem código de país não é enviado, porque completar o país pelo idioma do
      site inventaria um número. Nome e mensagem do lead **não entram** no payload.
    - **O envio não segura a resposta ao visitante e não pode falhar o lead.** Ele acontece
      em outra requisição, por evento único do agendador; o payload viaja num transiente, e
      não nos argumentos do evento, porque a option `cron` é autoload. Recusa da Meta sai
      NOMEADA na atividade, com código HTTP, `events_received` e `fbtrace_id`, e **não muda
      o status do lead** — ele já estava gravado antes de o envio ser agendado.
14a. **O SITE NASCE INSTRUMENTADO PARA COMPORTAMENTO, e não só para conversão.**
    Medir só em torno da conversão — `generate_lead`, `form_start`, `select_content` — não
    diz se a página é lida, onde o visitante para, o que ele tenta clicar nem qual é a
    experiência real de carregamento. O mesmo
    carregador instala seis coletores, **pelo mesmo portão de consentimento** e nos **dois
    formatos** — objeto `{event: …}` no `dataLayer`, para o caminho do container, e comando
    `gtag` para o caminho direto.

    | Coletor | O que sai | Teto por página |
    |---|---|---|
    | Marcos de rolagem | o marco cruzado, uma vez cada | 4 |
    | Seção vista | o nome que o markup declara | 12 |
    | Clique em link externo | o **host** de destino, e só ele | 10 |
    | Fricção | a contagem de cliques do episódio | 3 |
    | Erro de JavaScript do site | caminho de mesma origem e linha | 3 |
    | Core Web Vitals | LCP, CLS, INP e TTFB, valor cru | 4 |

    **Nome, parâmetro, teto e limiar moram num lugar só**: `dados/eventos-comportamento.tsv`,
    DENTRO do plugin. O cliente **não escreve nome de
    evento nem de parâmetro** — ele pede a declaração pelo *gatilho*, que é a chave de
    junção, e recebe de volta o nome, os parâmetros (na ordem em que os entrega,
    posicionalmente) e o teto. Quem vai ler essa série é um agente comparando períodos, e
    para ele um nome que muda entre releases não é erro visível: é o relatório do mês
    seguinte vazio, sem ninguém saber se o site parou de medir ou se os visitantes pararam
    de rolar. Quem reprova o literal de nome dentro do JavaScript é
    `tracking.eventos_de_comportamento_declarados`, e desde a 2.0.0 ela é emitida pela
    suíte do repositório do plugin — o objeto medido é o cliente dele. Aqui a linha sai
    declarada em `suite/excluidas.tsv`, com categoria e motivo.

    **A seção é nomeada pelo markup, nunca pelo texto.** O tema carimba
    `f3base-secao-<nome>` como `className` nos cinco patterns — `abertura`, `texto`,
    `cartoes`, `faq`, `contato` —, e o coletor lê o token pelo prefixo. **Sem a classe, a
    seção não é medida**, e essa é a escolha certa: um nome derivado do título mudaria
    sozinho na primeira revisão de copy, e a série ganharia uma seção nova e perderia outra
    sem que nada tivesse mudado na página.

    **A releitura é registrada, e a linha é a MESMA nos dois sentidos.** O bloco entra
    quando a razão de interseção alcança `visivel` (meia seção) e sai quando ela cai abaixo
    de `visivel` — não quando o bloco some da tela. Até a 1.3.2 a entrada usava o limiar
    declarado e a saída usava `isIntersecting`, que na especificação é razão **zero**: caindo
    de 0,6 para 0,4 o navegador avisava, mas o alvo continuava sobreposto, o coletor não
    rearmava, e o bloco só voltava a contar se saísse **inteiro** do campo de visão — o que
    em página curta não acontece nunca. Medido em produção: 80 linhas, todas com `ocorrencia
    = 1`, nenhuma reentrada. O observador passou a ser armado com os thresholds `[0,
    visivel]`, e a folga entre a razão zero e o limiar declarado **é** a histerese da seção —
    não há um segundo número a inventar aqui.

    **A contagem de passagens é da VISITA, e não do carregamento.** O contador que vira a
    coluna *vez* mora no registro da visita, no `localStorage`, e atravessa a navegação: quem
    vê um bloco, vai para outra página do site e volta continua de onde parou — a volta sai
    como `2ª`. A chave é `caminho`, `gatilho` e `detalhe`, nessa ordem: `pecas` em `/` e
    `pecas` em `/arquitetura/` são seções **diferentes** com o mesmo nome, e somá-las
    responderia uma pergunta que ninguém fez enquanto escondia as duas. Até a 1.3.3 o contador
    era variável do carregamento e o limiar chamado `travessias_por_sessao` contava
    carregamento — medido em produção na visita `8bb0a2d5`, dois carregamentos de `/` na mesma
    visita saíram os dois com ocorrência 1, e o rearme dentro de cada um deles funcionava.

    **O que NÃO atravessa é o estado armado**, e isso é decisão. `dentro` (marcos) e
    `dentroDaVista` (seções) nascem vazios a cada carregamento, porque uma página nova começa
    com nada em vista e nada rolado. Persistir "já estou dentro" junto com o contador faria a
    primeira entrada da página seguinte ser engolida, e o visitante que trocou de página
    perderia justamente a passagem que acabou de fazer — trocaria um defeito por outro, mais
    difícil de ver. O teto do mapa de contadores é o mesmo `maximoVisita` do registro (200);
    passando dele, a passagem conta em **cortadas** e não cria chave nova. Navegador com o
    armazenamento bloqueado continua somando o agregado e volta a contar por carregamento, que
    é a degradação certa.

    **O agregado continua contando uma vez por carregamento.** As duas leituras convivem de
    propósito: o total do painel responde *"quantas visitas viram este bloco"* e a tabela bruta
    responde *"quantas vezes cada uma passou"*. Somar releitura no total transformaria uma
    pessoa inquieta em audiência que não existe.

    **O marco de rolagem tem banda declarada.** `histerese_pp` (5) está no limiar da
    `rolagem` e diz quanto o visitante precisa subir para o marco rearmar: abaixo de `marco -
    histerese_pp`, e nunca na própria linha. Fronteira sem banda transforma **tremor** em
    leitura — um pixel de oscilação em 50%, o cabeçalho que recolhe, a imagem que entra e
    empurra a altura do documento fabricam uma travessia que ninguém fez, e ela chega ao
    relatório com cara de releitura. O número mora na declaração, ao lado dos marcos que ele
    protege, e não no JavaScript.

    **Nenhum evento carrega dado pessoal, e cada recusa tem motivo escrito.** Do link
    externo sai o host e nada mais — caminho e query são onde mora o identificador
    (`/perfil/joao-silva`, `?email=`, `?token=`, um `utm_content` preenchido com o id do
    lead). Do erro sai o caminho sem query e sem fragmento, e **a mensagem não sai**: ela
    carrega o valor interpolado que produziu o erro, e esse valor pode ser o que o titular
    digitou. O piso varre o payload inteiro, como o da CAPI faz.

    **A fricção tem limiar declarado, e o falso positivo é o que o piso mede.** São
    **4 cliques no mesmo controle interativo, dentro de 1200 ms, com deslocamento de até
    24 px**. Quatro, e não dois nem três, porque duplo clique é gesto normal de sistema e
    triplo clique é o gesto normal de selecionar um parágrafo — um limiar em 2 ou 3 marcaria
    como frustração o uso comum de qualquer página de texto. O piso prova os cinco casos
    normais que **não** disparam: duplo clique, triplo clique, cliques espalhados além do
    raio, cliques em controles diferentes e cliques repetidos num parágrafo.

    **O outro sinal de fricção foi RECUSADO, com o motivo.** Clique em elemento não
    interativo — o "dead click" — não é implementado, e não por esquecimento: numa página de
    texto, todo triplo clique para selecionar um parágrafo, todo duplo clique acidental num
    título e todo toque para fechar o teclado no celular pousam em elemento não interativo.
    Separar isso de frustração exigiria um modelo de intenção que este pacote não tem, e um
    falso positivo ali polui exatamente o relatório que a medição existe para produzir.

    **O erro classifica a ORIGEM, e a origem é o portão.** `site` emite; `terceiro` e
    `ambiente` não. É por isso que um bloqueador de anúncio não enche o relatório: ele
    quebra o script do fornecedor, não o nosso. Um parâmetro de origem seria peso morto —
    ele só poderia dizer `site`. `unhandledrejection` **não é ouvido**, também com motivo:
    promessa rejeitada não carrega arquivo nem linha em navegador nenhum, então a origem
    dela não é decidível.

    **Core Web Vitals por `PerformanceObserver` nativo, sem biblioteca externa.** A política
    de origem declarada não admite CDN de terceiro e o peso do carregamento é pago pelo
    visitante. Os quatro são relatados **uma vez**, no primeiro ocultamento da página — que
    é quando LCP, CLS e INP têm valor final. **O valor sai cru, sem classificação**: os
    cortes de bom/precisa-melhorar/ruim são do fornecedor e mudam por calendário, e embuti-los
    aqui faria o relatório deste site discordar do console do fornecedor no dia em que eles
    se movessem, sem uma linha dizendo por quê.

    **`desempenho.core_web_vitals` continua BLOCKED, e a distinção importa**: coleta existir
    não é o mesmo que o dado ter chegado. A pré-condição que falta é o **tráfego**, e só
    ele — e a linha diz isso.

    **O portão é "há destino", e não "há ID".** A instrumentação viaja dentro do mesmo
    `dados_de_medicao()` das tags e atravessa o portão
    do consentimento. O carregador entra quando há **um ID gravado
    OU o resumo do site ligado**: emitir comportamento sem uma
    conta para recebê-lo e sem resumo do próprio site é emitir para lugar nenhum, e por
    isso **sem os
    dois, nada é instalado e nada é emitido**. E a recusa que acompanha: com o slot vazio,
    nada é empurrado no `dataLayer` — alimentar um container que ninguém carregou seria
    mandar dados para uma conta que este pacote nunca soube que existia.

15. **Onde estes dados ficam visíveis: o resumo que o próprio site guarda.**
    Os seis coletores vão do navegador para a conta de medição e `f3base_atividade` guarda
    só o que passa pelo servidor: sem um resumo do próprio site, com o slot vazio os eventos
    não existiriam em lugar nenhum.

    A cada **ocultamento** da página — e ocultamento acontece toda vez que a aba perde o
    foco, não só na saída —, o navegador despacha um **lote** com os totais agregados e o
    registro acumulado desde o lote anterior, e o `site-core` os soma na tabela
    `<prefixo>f3base_comportamento`: uma linha por **dia, caminho, evento e detalhe**, com
    `contagem` e `soma` (a soma existe para os vitais, e é o que permite média sem guardar
    amostra). A tela do plugin lê essa tabela no bloco *"O que as páginas registraram"*, e o
    agente lê a mesma tabela por `db/query`, sem OAuth do GA4. As colunas estão descritas em
    `TEMPLATE.md`, na seção do agente.

    **O envio confirma a ENTREGA, e não o enfileiramento.** O despacho é `fetch` com
    `keepalive`, que sobrevive ao descarregamento da página como o `sendBeacon` e, ao
    contrário dele, devolve resposta: o lote só é esquecido com **2xx**. Rede caindo, 429,
    503 e 5xx mantêm o lote inteiro para a tentativa seguinte. `sendBeacon` devolvendo `true`
    diz apenas que o navegador **aceitou a carga para transferência** — nunca que ela chegou
    —, e limpar o acumulado sobre esse `true` perdia o lote em silêncio. Sem `keepalive`, o
    envio continua acontecendo por `sendBeacon`, degradado e declarado: ali o lote
    enfileirado-e-perdido continua sendo perda, porque não há como saber.

    **A linha é tão durável quanto o contador.** O que ainda não foi selado e os lotes já
    selados moram no `localStorage`, dentro do registro da visita, ao lado do contador de
    travessias — e os dois campos existem separados porque cada um segura um caso: a página
    que morre **sem** ter selado é socorrida pelo acumulado; a que morre **depois** de selar e
    ser recusada é socorrida pela fila, porque ali o acumulado já está vazio. Em nenhum dos
    dois o lote morre com o carregamento, e o carregamento seguinte da mesma visita despacha o
    pendente **antes** do que ele mesmo produzir. Cada lote leva um **selo sorteado**, e o
    servidor recusa um selo que já gravou para a mesma visita respondendo 2xx assim mesmo — é
    o que permite reenviar sem contar duas vezes.

    **O teto de linhas do corpo SELA o lote, e não corta a linha.** São dois tetos com
    desfechos diferentes: passar do orçamento da **visita** termina a série e o excedente sai
    em cortadas; encher **um corpo** apenas fecha aquele lote, e a linha entra no seguinte.
    Tratar o segundo como o primeiro abria buraco no meio da série — e cento e vinte
    acionamentos entre dois ocultamentos é um leitor atento numa página longa, não um caso
    extremo.

    **O que o site DESCARTOU aparece na tela.** O corte é nosso e é contado — a visita tem
    orçamento de linhas, o corpo tem teto de tamanho —, e o menu **Medição** o diz no
    *Estado da coleta*, com o total e as páginas em que aconteceu, **antes** de qualquer
    tabela. Ele fica fora do total e fora da lista de eventos: ninguém "cortou" nada, foi o
    pacote que descartou, e somá-lo faria a tela afirmar ter recebido justamente o que se
    perdeu.

    **As quatro recusas do payload**, cada uma com onde ela pode falhar: **nenhum
    identificador que não seja apelido sorteado** (o que vai ao `localStorage` é um conjunto
    declarado de duas chaves, com a forma de cada valor conferida, e nada em cookie);
    **nenhuma URL com query** (viaja o `pathname`); **nenhum texto livre** (o detalhe passa
    por alfabeto fechado sem barra, arroba, dois-pontos nem espaço — e é por isso que o erro
    de JavaScript entra como contagem **sem** o arquivo); e **nenhum evento sem declaração**
    (o cliente manda o gatilho, o servidor resolve o nome).

    **O portão é o do consentimento**, o mesmo das tags: sem ele nada é enviado. E é por isso
    que o quadro diz, ao lado dos números, que eles contam **só as sessões com
    consentimento** — quem lê um total sem essa frase acha que está vendo o universo.

    **Com zero sessões o quadro DIZ que não há dados** e nomeia as causas possíveis, em vez
    de mostrar uma tabela de zeros que parece medição. E ele diz **onde está o que não está
    ali**: com `f3base_ga4_measurement_id` vazio, que nenhum evento chega ao Google Analytics
    e o quadro é tudo o que existe; com ele gravado, que este resumo **não substitui** o
    relatório do fornecedor — público, origem de tráfego, funil e atribuição vivem lá.

    **Três chaves operáveis**, em *Privacidade e retenção*: ligar ou desligar, o prazo de
    guarda (`retencao_dias`, 90 por padrão, executado pela rotina de retenção que já existia)
    e o período que o quadro soma (`dias_no_painel`). Desligar não afeta o envio para a conta
    de medição — os dois destinos são independentes nos dois sentidos, e o piso mede os dois.

16. **Verificação de posse do domínio: duas options, duas metatags, e vazio é inerte.**
    `verificacao_dominio.google` e `verificacao_dominio.meta` nascem vazias no arquivo único
    e viram as options `f3base_verificacao_google` e `f3base_verificacao_meta`. Preenchida,
    cada uma emite a sua metatag no `<head>` de toda página — `google-site-verification` e
    `facebook-domain-verification`; vazia, nada é emitido.

    As chaves existem na configuração para que um site cujo operador **já tenha** os tokens
    nasça verificado, sem uma segunda visita ao console; elas continuam operáveis pelo canal
    para quem os obtiver depois. O Google aceita também verificação por DNS, e a Meta
    também: quem escolher esse caminho deixa a option vazia, e as duas formas valem.

    **Valor fora da forma é preservado e avisado, nunca apagado.** O
    token é opaco e o alfabeto é do fornecedor; o pacote sabe o que as duas tags aceitam
    hoje e não sabe o que aceitarão amanhã. O que ele faz é NOMEAR a forma esperada num
    WARN e emitir o valor **escapado** no atributo. O engano mais comum — colar a tag
    inteira em vez do conteúdo dela — cai exatamente aí.

    O que a pessoa faz em cada console, e qual é o teste de cada passo, está em
    `TEMPLATE.md`, na seção dos consoles. **Nenhum daqueles passos é executável pelo
    agente.**
17. `mecanismo_de_cadencia` vazio: ver a seção da cadência acima. O item de
    entrega é `cadencia.mecanismo_declarado`, e ele fecha **BLOCKED** num caso só — sem
    agendamento observado E com a chave vazia. Esse BLOCKED sai nomeado no relatório e
    **não** segura a autodesativação. O OUVINTE do
    evento, esse, existe e é do `site-core`: o que continua vazio é o NOME do mecanismo
    externo, não o gatilho.
15a. `origem_confiavel.cabecalho` vazio: o rate limit do endpoint de leads
    conta por `REMOTE_ADDR`. Atrás de CDN ou proxy reverso, `REMOTE_ADDR` é o mesmo para
    todo mundo e os 20 registros por janela passam a valer para o proxy inteiro — preço
    declarado, e a saída é preencher o nome do cabeçalho e os saltos confiáveis. Aceitar
    cabeçalho de proxy sem declaração seria pior: seria o visitante escolhendo em que
    balde ele conta.
18. `plugins.configuracao_servidor_mcp` vazio: os nomes das chaves de configuração do
    servidor MCP são fato do fornecedor, e este pacote não os inventa. Enquanto o mapa
    estiver vazio, a unidade do canal reporta que não há configuração declarada a aplicar
    — e continua conferindo as rotas.
19. `plugins.supressao_onboarding` é declarado, não deduzido: quem descobre como o
    assistente de um plugin é armado é o operador, e é ele quem o declara. O mapa aceita
    **duas formas**, e a segunda entrou na 2.1.0:

    - **`option.chave`** — grava `false` naquela option. É o caso do `wordpress-seo`, que
      decide o redirecionamento do próprio assistente por option;
    - **`transiente:<nome>`** — apaga aquele transiente. É o caso do `wp-mcp-ultimate`, e
      a entrada declara `transiente:wp_mcp_ultimate_activated`.

    **A segunda forma existe porque a primeira não alcançava o defeito, e isso foi
    medido.** O assistente do servidor do canal é decidido por TRANSIENTE, não por option:
    ele grava `wp_mcp_ultimate_activated` no `register_activation_hook` e, no `admin_init`
    seguinte, redireciona para a própria tela (`includes/Plugin.php`,
    `maybe_redirect_to_dashboard()`, lido no artefato da origem declarada). Não há
    `apply_filters` nesse caminho, e **option nenhuma o desarma**: declarar uma entrada de
    option ali gravaria uma chave que ninguém lê. Medido na implantação de 2026-09-07: em
    toda instalação limpa o lote seguinte ao da ativação era sequestrado uma vez e repetido
    pelo cliente.

    Agora **o transiente é apagado na MESMA unidade que ativa o plugin**, antes de qualquer
    `admin_init`, e a leitura de volta é `get_transient()` devolvendo falso. A supressão é
    reescrita de forma idempotente no fim da fase de plugins, para alcançar também o plugin
    que já estava instalado e ativo antes desta execução. `plugins.supressao_por_transiente`
    cobra as duas formas no catálogo e no código, com piso.
20. `plugins.backups_preservados` é 2: por slug, as cópias preservadas acima desse teto
    saem do disco na unidade de poda, **nomeadas**, da mais antiga para a mais nova. O
    teto vem da configuração e nunca de número escrito no código.
21. Origem `url` desce **em https e mais nada**: não há chave a preencher e não há lista
    de hosts a manter. Endereço que não é https é BLOCKED sem download, em qualquer
    salto da cadeia de redirecionamento, e o `sha256` é o que amarra o byte baixado. A
    lista fechada de hosts não existe aqui: ela moraria no MESMO arquivo
    que as URLs que restringiria, e quem consegue editar a URL edita a lista na linha de
    cima.
22. A matriz de origens de release homologadas é uma lista FECHADA, e ela mora em
    `config/releases-suportadas.tsv`, que é CATÁLOGO do pacote e não configuração de
    site: a pergunta que ela responde — de qual versão instalada este implantador sabe
    subir — é sobre o pacote, e nenhum projeto tem resposta diferente. Cada entrada traz
    a própria `determinacao`: `medida-no-site` quando a release foi observada rodando num
    site, `entregue-nao-confirmada` quando ela foi produzida e nunca chegou a um. A
    distinção é sobre o SITE, não sobre o repositório: release entregue não é release
    aplicada. Quantas entradas existem hoje está no carimbo gerado no topo deste arquivo —
    aqui não se digita contagem. Quem lê o catálogo é
    `F3Base_Imp_Preflight::releases_suportadas()`, e é o único que o lê. Catálogo ausente
    devolve lista VAZIA, que é o lado seguro: só a instalação limpa passa. Origem fora da
    lista termina em BLOCKED, sem mutação.
23. `organizacao.same_as` vazio, `redirects` vazio, `plugins.embarcados` vazio,
    `plugins_operacionais` vazio e `tema.fragmentos_sincronizados` vazio: lista vazia é
    estado válido e declarado, não seção esquecida. Fragmento sincronizado vazio é o
    padrão do método, e lista do operador nasce vazia por regra — o que ela ganha ao
    nascer preenchida é a chance de alguém a herdar sem conferir.

### O que foi medido e o que não foi

24. **Medido nesta base:** o piso dos detectores — cada um provando acusar o defeito
    plantado e calar sobre o correto, nos dois ramos. E o contraste, recalculado pela
    checagem `a11y` a partir da paleta do `theme.json`, pela fórmula de luminância
    relativa da WCAG, sobre os pares de texto e fundo EM USO, todos acima do piso AA.
    As contagens dos dois não são digitadas aqui: a de detectores com piso está no
    carimbo gerado no topo, e a de pares de contraste sai na linha `a11y.contraste` da
    rodada, junto com o número que ela mediu.
25. **Não medido: orçamento de página.** `orcamento_pagina` declara 100 kB de CSS, 50 kB
    de JavaScript próprio, 1024 kB de peso total, 30 requisições e 1500 nós de DOM. São
    limites declarados; o consumo real é medido na entrega, num site servindo páginas, e
    `orcamento.pagina` fecha **N/A nomeando a fase `producao`** dizendo exatamente isso.
26. **Não medido: Core Web Vitals.** São medidos em campo, sobre tráfego real;
    `desempenho.core_web_vitals` fecha **N/A nomeando a fase `campo`**, e é
    `fases.registro_de_execucao` que registra que a fase `campo` ainda não rodou.
27. **Não medido: versões observadas de núcleo, PHP e plugins de terceiro**, pelo motivo
    da seção de plugins — o comando único roda contra a árvore do pacote, não contra uma
    instalação. `plugins.autoupdate_conforme_politica` e
    `plugins.adaptador_leitura_de_volta` fecham **N/A com a fase `producao` nomeada**, e a
    classe de evidência `leitura-de-volta` continua declarada na linha, porque é ela que
    diz COMO a medição vai acontecer quando aquela fase rodar.
28. **Conferência do preset no navegador não executada.** As razões de contraste são
    calculadas da paleta; a checagem que lê o valor computado da custom property no
    navegador exige ambiente com navegador e fecha **N/A com a fase nomeada**.
29. **A única linha em BLOCKED da rodada de build é `entrega.rodada_limpa`, e ela é
    BLOCKED por desenho.** Ela é da fase `build` — esta fase —, então a regra de
    aplicabilidade não a alcança, e não deveria: a rodada PRODUZ o registro que o host
    consome, e aprovar-se pelo arquivo que ela mesma acaba de escrever não seria medir
    nada. Quem a fecha em OK é o host, conferindo o hash do pacote instalado contra o
    registro que viajou dentro dele.

### Suposições sobre o ambiente do operador

30. O operador tem acesso ao wp-admin com as capacidades listadas em pré-requisitos, e a
    instalação permite envio de plugin por arquivo.
31. A hospedagem permite saída HTTPS para o WordPress.org e para os hosts das URLs
    declaradas nas entradas de plugin. Sem ela, a instalação fecha BLOCKED e os caminhos
    de contingência declarados são a RESERVA versionada que viaja no bundle — que responde
    depois de a URL ser tentada e passa pelo `sha256` declarado —, o slot
    `assets/plugins/<slug>.zip` e a instalação manual pelo wp-admin.
32. O agendador do WordPress é o mecanismo padrão da rotina de retenção. Ele não garante
    horário: a rotina mede o próprio atraso e se recupera no carregamento seguinte.
    Obrigação temporal relevante pede agendador real do servidor, e essa troca é decisão
    de projeto.

## Regras de robustez do runtime, e o que cada uma impede

Leia esta seção antes de mexer no pacote. **A regra que governa todas: o pacote não
acredita em nada que não mediu.** Origem, pasta criada, veredito de gate, slug e versão de
artefato saem de onde eles moram — lidos uma vez, gravados como lidos. É a regra do
artefato sobre o registro, e cada item abaixo é uma aplicação dela com o preço de
abandoná-la escrito ao lado.

### Instalação e ativação de plugin

1. **Origem é declarada, nunca deduzida.** A precedência é `assets/plugins/<slug>.zip` (o
   slot do operador) → URL declarada na entrada, em https →
   `assets/plugins/<slug>-<versão>.zip` (a reserva versionada) → WordPress.org, e o
   artefato LOCAL passa pelo mesmo `sha256` declarado que o baixado. Plugin que não existe no
   WordPress.org — os dois do canal MCP são o caso — não tem origem alcançável quando o
   `.org` é a única prevista, e o lote fecha BLOCKED.
2. **A pasta criada é lida do resultado do instalador**, e reconciliada com a
   `pasta_esperada` declarada antes da ativação. Zip de código-fonte de repositório extrai
   como `<repo>-main`, e ativar pelo slug procuraria em outro diretório.
3. **Nenhum cabeçalho `Plugin Name:` a um nível da raiz do plugin.** `get_plugins()` varre a
   raiz **e um nível de subdiretório**; com dois cabeçalhos nesse alcance, a varredura ordena
   por **Name**, `Plugin_Upgrader::plugin_info()` devolve o primeiro, o link "Ativar plugin"
   carrega um caminho de dois níveis, e `validate_plugin()` — que só enxerga um nível a
   partir de `wp-content/plugins/` — responde *"The plugin does not have a valid header."*.
   A fonte que viaja é a do TEMA, em `fontes/tema/`, fora do alcance da varredura; o plugin
   viaja como ZIP em `assets/plugins/`, que `get_plugins()` não abre. E
   `pacote.sem_cabecalho_de_plugin_aninhado` reprova o pacote que tenha um cabeçalho a um
   nível da raiz, ou que não tenha exatamente um na raiz.
4. **Sequestro de requisição por terceiro é COMPORTAMENTO ESPERADO, e fecha OK.**
   Assistente de boas-vindas de plugin registra redirecionamento em `admin_init`, que roda
   antes do handler de lote: a supressão acontece na **ativação**, por mapa declarado em
   `plugins.supressao_onboarding` — `option.chave` ou `transiente:<nome>` —, e o cliente
   distingue sequestro por terceiro de erro fatal e de falha de rede, repetindo a unidade
   **uma vez**, nunca em laço, em vez de perdê-la.

   **A linha sai depois do desfecho, e é isso que mudou na 2.1.0.** No momento do sequestro
   o cliente NÃO registra nada: ele guarda a evidência da requisição sequestrada e repete.
   Quando a repetição roda, sai **uma** linha em `lote.sequestro_por_terceiro`, em **OK**,
   com a evidência anexada e com o que evitaria a ida e volta nomeado — a entrada do mapa
   de supressão, sem inventar chave nenhuma. Se a repetição também falhar, a linha é FALHA
   e a unidade sai marcada como não executada, para a retomada incluí-la. Até a 2.0.0 o WARN
   era registrado ANTES de se saber o desfecho, e a tela avisava sobre um evento que
   acontece em toda instalação limpa e termina bem — aviso que sai sempre é aviso que
   ninguém lê.

### Orquestração dos lotes

5. **BLOCKED é registrado uma vez e a unidade não roda de novo.** A interrupção nomeia as
   etapas que ficaram sem executar. Reexecutar unidade bloqueada a cada passagem do
   orquestrador imprime a mesma linha várias vezes e não muda o veredito.
6. **Dependência entre unidades é grafo DECLARADO, nunca posição.** Abortar tudo que vem
   depois de um BLOCKED derruba unidades que não dependem dele — um destino de formulário
   vazio, que é estado correto e esperado, levaria junto `cadencia`, `entrega` e
   `encerramento`. O grafo mora em `F3Base_Imp_Plano`, e `mcp`, `entrega` e `encerramento`
   declaram lista vazia de propósito: unidade que diagnostica não pode ser suspensa pelo que
   ela diagnostica. `estatica.plano_dependencias` reprova dependência para grupo
   inexistente, autoloop e ciclo.
7. **Uma fonte de verdade por veredito de gate.** A unidade `mcp` é o único ponto que deriva
   os dois vereditos de canal, grava-os no registro da execução, e a entrega e o
   encerramento **leem** em vez de recalcular; sem registro, o estado é BLOCKED dizendo que
   a unidade não rodou — nunca um veredito inventado no lugar. Duas implementações do mesmo
   veredito fazem o relatório afirmar, na mesma execução, que o canal está exposto e que não
   está. `mcp.canal_exposto` é rótulo próprio, porque **rota registrada** e **rota exposta
   por MCP** são fatos diferentes, e o estado do meio precisa sair com o nome dele. O
   detector `estatica.gate_fonte_unica` impede o segundo derivador.
8. **Contador tem escopo nomeado.** Checagens e unidades contam separado, cada bloco nomeia
   o escopo que resume, e nenhum estado aparece contado duas vezes sob a mesma palavra —
   três números diferentes para a mesma palavra, medidos em escopos não declarados, é o que
   faz rodapé, encerramento e tela discordarem sobre quantas FALHAs existem.

### Troca de diretório, backup e poda

9. **A cópia preservada de cada troca começa com ponto** (`.f3base-anterior-<slug>-<ts>`),
   porque `get_plugins()` pula tudo que começa com ponto. Sem o ponto, a versão anterior
   aparece na lista de plugins do site — inclusive na lista de atualização automática — como
   se fosse um segundo plugin ativo. A etapa de atualização automática ignora diretório com
   ponto na frente explicitamente e diz no relatório quantos ignorou, e a unidade de
   migração oculta os órfãos que ficaram de fora dessa forma, com quatro regras:
   propriedade provada por `Plugin Name:` que bata com um artefato deste pacote, diretório
   ativo nunca renomeado (sai WARN), nunca apaga, e idempotente por construção, emitindo nos
   dois ramos.
10. **A poda das cópias preservadas tem teto declarado** em `plugins.backups_preservados`, e
    nunca número escrito no código: a troca preserva a versão anterior por desenho, e sem
    poda o disco cresce sem teto a cada execução. O que sai do disco sai **nomeado**, da
    mais antiga para a mais nova, e a operação entra no journal.
11. **A troca é pulada quando o artefato baixado é idêntico ao instalado.** Origem por URL
    não anuncia versão, e sem ler a versão do cabeçalho **dentro** do artefato já baixado
    todo plugin de origem `url` cai no ramo "versão não anunciada" e a troca é refeita em
    toda execução — o segundo crescimento sem teto.

### Conteúdo e slug

12. **Slug declarado é obrigatório** em toda entrada de `paginas` e `posts`, conferido por
    `config.slug_declarado` com piso dos dois lados. Sem `post_name` declarado o núcleo
    deriva o slug do título e `wp_unique_post_slug()` consulta
    `post_type IN ('page','attachment')` para tipo hierárquico, desambiguando em silêncio:
    três itens de mídia com o mesmo `alt` bastam para tirar o slug da home. Anexo gerenciado
    recebe slug determinístico derivado da referência lógica, o slug anterior é liberado
    antes do sideload e fica gravado em `_f3base_old_slug` para o `site-core` redirecionar.
13. **Conteúdo publicado que este pacote não gerencia é relatado, nunca apagado por slug.**
    O que a etapa de conteúdo de exemplo não tocar sai em `conteudo.nao_gerenciado_publicado`
    em **WARN, nunca FALHA**: o site não está defeituoso, está com uma decisão em aberto.

### Tema

14. **O cartão dentro da coluna cresce por regra escopada.** `.wp-block-columns` é flex e a
    coluna já estica; o que não estica é o Group do cartão dentro dela, que é bloco de fluxo
    e fica alto o quanto o texto pedir — o alinhamento vertical do bloco Columns move o
    conteúdo, não faz o filho crescer. A regra é `height: 100%` escopado em
    `.wp-block-column > .f3base-cartao`, no `style.css` do tema, com o motivo escrito ao
    lado, e inerte no móvel, onde o núcleo empilha em uma coluna.
