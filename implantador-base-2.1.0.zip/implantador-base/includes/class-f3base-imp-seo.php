<?php
/**
 * Adaptador do plugin de SEO.
 *
 * Fatos do fornecedor que este adaptador respeita, cada um por ter custado uma
 * medição:
 *
 * - A identidade da organização (`company_*`, `website_name`) vive em
 *   **`wpseo_titles`**, não em `wpseo`. Chave na option errada é descartada em
 *   silêncio, e o relatório diria "gravado" com o site sem identidade.
 * - `WPSEO_Taxonomy_Meta::set_value()` chamado uma chave por vez ZERA as
 *   anteriores. Aqui só existe `set_values()`, com o conjunto inteiro.
 * - O `/llms.txt` do plugin de SEO fica DESLIGADO, sempre — 2.1.0. Quem serve
 *   o endereço é a rota do `site-core`, e a precedência declarada nele é
 *   "arquivo físico na raiz > emissor concorrente ligado > nossa rota": com a
 *   chave `enable_llms_txt` ligada o plugin de SEO gravava um arquivo físico
 *   que vencia a rota, e a seleção curada — gravada em `wpseo_llmstxt` com
 *   chaves que a versão 28.4 nem lê — não governava o arquivo publicado. Foi
 *   medido numa implantação real: "Contato" selecionada e fora do arquivo,
 *   "Blog" não selecionada e dentro. A seleção curada agora vai SÓ para
 *   `f3base_llms`, que é o que a rota do site-core lê.
 * - O SEO por conteúdo é gravado **mesmo sem o plugin ativo**: as chaves são
 *   dele, mas quem lê primeiro pode ser o site (o `site-core` honra o noindex).
 * - A lista do que NUNCA ligar é conferida como LISTA, chave a chave. Fixar a
 *   contagem esconde a chave que mudou de nome.
 *
 * Nenhum número de versão decide nada aqui: a versão observada vai nomeada ao
 * relatório e o gate é a leitura de volta.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Configuração de SEO gravada pelo implantador.
 */
final class F3Base_Imp_Seo {

	/**
	 * Slug do plugin de SEO adaptado, LIDO do catálogo de decisões.
	 *
	 * Era uma constante com o slug escrito à mão, e isso é a segunda fonte que
	 * este pacote persegue em todo lugar: quem instala o plugin lê o slug de
	 * `plugins.instalaveis`, e quem escreve as options do plugin lia de uma
	 * constante. As duas concordavam por coincidência, e trocar o plugin de SEO
	 * no catálogo deixaria este adaptador escrevendo nas options do plugin
	 * antigo — sem erro nenhum, porque a gravação funciona.
	 *
	 * A pergunta certa não é "qual é o slug" e sim "qual é o plugin no PAPEL de
	 * seo", e é essa que `slug_por_papel()` responde, da mesma lista que a
	 * instalação percorre.
	 *
	 * @return string Slug, ou vazio quando nenhuma entrada declara o papel.
	 */
	public static function slug(): string {
		return F3Base_Imp_Entrega::slug_por_papel( 'seo' );
	}

	/**
	 * Options do plugin em que este adaptador escreve.
	 *
	 * @return string[]
	 */
	public static function options(): array {
		return array( 'wpseo', 'wpseo_titles', 'wpseo_social' );
	}

	/**
	 * Chaves que NUNCA se ligam, com a origem do valor esperado.
	 *
	 * As quatro primeiras são proibições incondicionais. As três de bots derivam
	 * da variável de política — nunca de um absoluto: política diferente muda a
	 * checagem, não o padrão.
	 *
	 * @return array<string,array{esperado:bool,motivo:string}>
	 */
	public static function nunca_ligar(): array {
		$restringe = 'restringir' === (string) F3Base_Imp_Decisoes::valor( 'bots_ia.politica' );

		return array(
			'clean_permalinks'              => array(
				'esperado' => false,
				'motivo'   => __( 'redireciona URLs com parâmetros não registrados: apaga as UTMs das campanhas.', 'f3base' ),
			),
			'clean_campaign_tracking_urls'  => array(
				'esperado' => false,
				'motivo'   => __( 'remove utm_* por redirecionamento.', 'f3base' ),
			),
			'deny_adsbot_crawling'          => array(
				'esperado' => false,
				'motivo'   => __( 'o Google reprova o anúncio por não conseguir avaliar a página de destino.', 'f3base' ),
			),
			'deny_wp_json_crawling'         => array(
				'esperado' => false,
				'motivo'   => __( 'sem ganho real; a REST API é usada pelo editor de blocos.', 'f3base' ),
			),
			'deny_gptbot_crawling'          => array(
				'esperado' => $restringe,
				'motivo'   => __( 'valor derivado da política declarada de bots de IA.', 'f3base' ),
			),
			'deny_google_extended_crawling' => array(
				'esperado' => $restringe,
				'motivo'   => __( 'valor derivado da política declarada de bots de IA.', 'f3base' ),
			),
			'deny_ccbot_crawling'           => array(
				'esperado' => $restringe,
				'motivo'   => __( 'valor derivado da política declarada de bots de IA.', 'f3base' ),
			),
		);
	}

	/**
	 * O plugin de SEO está ativo?
	 *
	 * Gate ESTRUTURAL, provado pela saída e não pela presença de uma constante:
	 * uma fixture de onze linhas define a constante sem produzir uma linha de
	 * HTML.
	 *
	 * @return bool
	 */
	public static function plugin_ativo(): bool {
		$arquivo = F3Base_Imp_Plugins::arquivo_principal( self::slug() );

		return '' !== $arquivo && is_plugin_active( $arquivo );
	}

	/**
	 * Identidade da organização e aparência na busca — em `wpseo_titles`.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_identidade(): array {
		$rotulo = 'seo.identidade';
		$nome   = (string) F3Base_Imp_Config::obter( 'seo.organizacao.nome', '' );
		$logo   = (string) F3Base_Imp_Config::obter( 'seo.organizacao.logo_ref', '' );
		$anexo  = '' !== $logo ? F3Base_Imp_Conteudo::localizar_gerenciado( 'attachment', 'midia:' . $logo ) : 0;

		$chaves = array(
			'company_or_person'       => 'company',
			'company_name'            => $nome,
			'website_name'            => (string) F3Base_Imp_Config::obter( 'site.nome', '' ),
			'disable-author'          => true,
			'disable-date'            => true,
			'disable-post_format'     => true,
			'disable-attachment'      => true,
			'breadcrumbs-enable'      => true,
			'noindex-tax-post_tag'    => true,
		);

		if ( $anexo > 0 ) {
			$chaves['company_logo']    = (string) wp_get_attachment_url( $anexo );
			$chaves['company_logo_id'] = $anexo;
		}

		$resultado = F3Base_Imp_Gravador::gravar_chaves( 'wpseo_titles', $chaves, array( 'plugin' => self::slug() ) );

		return self::saida(
			$resultado['estado'],
			$rotulo,
			sprintf(
				/* translators: 1: chaves gravadas, 2: mensagem do gravador, 3: versão observada do plugin. */
				__( 'identidade gravada em wpseo_titles (nunca em wpseo) — chaves: %1$s. %2$s Versão observada do plugin: %3$s.', 'f3base' ),
				implode( ', ', array_keys( $chaves ) ),
				$resultado['motivo'],
				self::versao_observada()
			)
		);
	}

	/**
	 * Open Graph, Twitter Cards e imagem social padrão.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_social(): array {
		$ref   = (string) F3Base_Imp_Config::obter( 'seo.imagem_social_ref', '' );
		$anexo = '' !== $ref ? F3Base_Imp_Conteudo::localizar_gerenciado( 'attachment', 'midia:' . $ref ) : 0;

		$chaves = array(
			'opengraph' => true,
			'twitter'   => true,
		);

		if ( $anexo > 0 ) {
			$chaves['og_default_image']    = (string) wp_get_attachment_url( $anexo );
			$chaves['og_default_image_id'] = $anexo;
		}

		$perfis = array();

		foreach ( F3Base_Imp_Projeto::lista( 'organizacao.same_as' ) as $url ) {
			$limpa = esc_url_raw( (string) $url );

			if ( '' !== $limpa ) {
				$perfis[] = $limpa;
			}
		}

		$chaves['other_social_urls'] = $perfis;

		$resultado = F3Base_Imp_Gravador::gravar_chaves( 'wpseo_social', $chaves, array( 'plugin' => self::slug() ) );

		return self::saida(
			$resultado['estado'],
			'seo.social',
			sprintf(
				/* translators: 1: mensagem do gravador, 2: quantidade de perfis declarados. */
				__( 'Open Graph e Twitter Cards ligados; sameAs com %2$d URL(s) declarada(s) — só URL verificada entra, e vazio é estado válido. %1$s', 'f3base' ),
				$resultado['motivo'],
				count( $perfis )
			)
		);
	}

	/**
	 * Chaves gerais: sitemap, limpeza, telemetria desligada e integração.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_geral(): array {
		$chaves = array(
			'tracking'           => false,
			'enable_xml_sitemap' => true,
			'enable_index_now'   => false,
			/*
			 * SEMPRE FALSO — 2.1.0. O `/llms.txt` é do site-core, por rota
			 * virtual, com a seleção curada em `f3base_llms`; o do plugin de SEO
			 * é um arquivo físico na raiz, e arquivo físico vence a rota pela
			 * precedência que o próprio site-core declara. Ligar os dois é
			 * entregar o endereço ao que não lê a curadoria. `bots_ia.llms_txt`
			 * governa o módulo do site-core, e só ele.
			 */
			'enable_llms_txt'    => false,
		);

		/*
		 * A INTEGRAÇÃO DE CONSOLE É GRAVADA NOS DOIS RAMOS desde a 1.1.1, e a
		 * medida que motivou a mudança é a forma do defeito antigo: o adaptador
		 * só gravava `true`. Quando o plugin de console SAÍA da instalação, o
		 * `true` de ontem ficava no banco — o Yoast continuava anunciando uma
		 * integração com um plugin que não existe mais, e nenhuma leitura de
		 * volta acusava, porque a chave nunca era escrita de novo.
		 *
		 * A condição também mudou. Não basta o plugin estar ATIVO: ele precisa
		 * estar ativo E DECLARADO pelo projeto, em `plugins_operacionais`.
		 * Plugin de console do Google que ninguém
		 * declarou não é dependência deste site — desde a 1.1.1 ele saiu do
		 * catálogo base, e a emissão de toda tag de medição é do módulo
		 * `tracking` do `site-core`, em toda instância.
		 *
		 * O par slug ↔ chave vem da DECLARAÇÃO, nunca de literal aqui dentro:
		 * quem decide o que a configuração declara não é lista escrita no meio
		 * do código.
		 */
		$declarados = self::slugs_operacionais();

		$estados_de_integracao = array();

		foreach ( F3Base_Imp_Plugins::emissores_declarados() as $slug => $declaracao ) {
			$chave_seo = (string) ( $declaracao['chave_seo'] ?? '' );

			if ( '' === $chave_seo ) {
				continue;
			}

			$arquivo   = F3Base_Imp_Plugins::arquivo_principal( (string) $slug );
			$ativo     = '' !== $arquivo && is_plugin_active( $arquivo );
			$declarado = in_array( (string) $slug, $declarados, true );

			$veredito = self::veredito_de_integracao( (string) $slug, $ativo, $declarado );

			$chaves[ $chave_seo ] = $veredito['valor'];

			$estados_de_integracao[] = sprintf(
				/* translators: 1: nome da chave, 2: valor gravado, 3: motivo do valor. */
				__( '%1$s = %2$s (%3$s)', 'f3base' ),
				$chave_seo,
				$veredito['valor'] ? 'true' : 'false',
				$veredito['motivo']
			);
		}

		foreach ( self::nunca_ligar() as $chave => $regra ) {
			$chaves[ $chave ] = $regra['esperado'];
		}

		$resultado = F3Base_Imp_Gravador::gravar_chaves( 'wpseo', $chaves, array( 'plugin' => self::slug() ) );

		return self::saida(
			$resultado['estado'],
			'seo.geral',
			sprintf(
				/* translators: 1: mensagem do gravador, 2: estado de cada integração de console. */
				__( 'telemetria desligada, sitemap do plugin ligado e a lista do que nunca ligar aplicada chave a chave. Integração com plugin de console, gravada nos DOIS ramos e relida como as outras chaves: %2$s. %1$s', 'f3base' ),
				$resultado['motivo'],
				array() === $estados_de_integracao
					? __( 'nenhuma chave de integração de console declarada', 'f3base' )
					: implode( '; ', $estados_de_integracao )
			)
		);
	}

	/**
	 * Slugs declarados em `plugins.operacionais`.
	 *
	 * @return string[]
	 */
	private static function slugs_operacionais(): array {
		$saida = array();

		foreach ( F3Base_Imp_Projeto::lista( 'plugins_operacionais' ) as $indice => $entrada ) {
			unset( $entrada );

			$slug = (string) F3Base_Imp_Projeto::obter( 'plugins_operacionais.' . $indice . '.slug', '' );

			if ( '' !== $slug ) {
				$saida[] = $slug;
			}
		}

		return $saida;
	}

	/**
	 * O VEREDITO da integração com o plugin de console — função pura.
	 *
	 * Ela existe separada, e não como duas linhas dentro de `aplicar_geral()`,
	 * porque é ela que a sonda exercita nos TRÊS ramos sem WordPress nenhum. E
	 * são três de propósito: `false` tem DUAS causas diferentes — o plugin
	 * sumiu, ou o plugin está lá e ninguém o declarou —, e confundi-las é o que
	 * faz alguém procurar o problema no lugar errado.
	 *
	 * O valor sai nos DOIS ramos. Até a 1.1.0 só o `true` era gravado, e quando
	 * o plugin saía da instalação o `true` de ontem ficava no banco: o Yoast
	 * anunciando integração com um plugin que não existe mais, e nenhuma
	 * leitura de volta acusando, porque a chave nunca era escrita de novo.
	 *
	 * @param string $slug      Slug do plugin de console.
	 * @param bool   $ativo     Está ativo na instalação?
	 * @param bool   $declarado Está declarado em plugins_operacionais?
	 * @return array{valor:bool,motivo:string}
	 */
	public static function veredito_de_integracao( string $slug, bool $ativo, bool $declarado ): array {
		if ( $ativo && $declarado ) {
			return array(
				'valor'  => true,
				'motivo' => sprintf(
					/* translators: %s: slug do plugin. */
					__( '%s ativo e declarado pelo projeto', 'f3base' ),
					$slug
				),
			);
		}

		if ( $ativo ) {
			return array(
				'valor'  => false,
				'motivo' => sprintf(
					/* translators: %s: slug do plugin. */
					__( '%s está ativo e não foi declarado em plugins_operacionais: ele saiu do catálogo base, e ligar a integração por presença faria o pacote adotar um plugin que ninguém declarou', 'f3base' ),
					$slug
				),
			);
		}

		return array(
			'valor'  => false,
			'motivo' => sprintf(
				/* translators: %s: slug do plugin. */
				__( '%s ausente ou inativo: a chave é gravada como false em vez de ficar com o true da execução anterior', 'f3base' ),
				$slug
			),
		);
	}

	/**
	 * Confere a lista do que NUNCA ligar, chave a chave e pelo nome.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function conferir_nunca_ligar(): array {
		$saida = array();

		foreach ( self::nunca_ligar() as $chave => $regra ) {
			$onde = self::localizar_chave( $chave );

			if ( '' === $onde ) {
				$saida[] = self::saida(
					'N/A',
					'seo.nunca_ligar:' . $chave,
					sprintf(
						/* translators: 1: nome da chave, 2: versão observada do plugin. */
						__( 'condição de aplicabilidade falsa: a chave %1$s não existe em nenhuma option deste plugin na versão observada %2$s.', 'f3base' ),
						$chave,
						self::versao_observada()
					)
				);
				continue;
			}

			$valores = get_option( $onde, array() );
			$valores = is_array( $valores ) ? $valores : array();
			$atual   = ! empty( $valores[ $chave ] );

			$saida[] = self::saida(
				$atual === (bool) $regra['esperado'] ? 'OK' : 'FALHA',
				'seo.nunca_ligar:' . $chave,
				sprintf(
					/* translators: 1: option onde a chave vive, 2: valor esperado, 3: valor observado, 4: motivo declarado. */
					__( 'em %1$s — esperado %2$s, observado %3$s. %4$s', 'f3base' ),
					$onde,
					$regra['esperado'] ? 'true' : 'false',
					$atual ? 'true' : 'false',
					$regra['motivo']
				)
			);
		}

		return $saida;
	}

	/**
	 * O `/llms.txt` é do SITE-CORE: o emissor do plugin de SEO fica desligado, o
	 * arquivo físico que ele tiver gravado sai, e a rota do site-core responde.
	 *
	 * O DEFEITO MEDIDO na implantação de 2026-09-07, com a 2.0.0: a chave
	 * `enable_llms_txt` do plugin de SEO era ligada junto com o módulo do
	 * site-core, o plugin gravava um arquivo físico na raiz, e a seleção
	 * curada — gravada em `wpseo_llmstxt` com as chaves `manual`, `pages` e
	 * `privacy_policy`, que a versão 28.4 do plugin não lê (ela lê
	 * `llms_txt_selection_mode`, `other_included_pages`, `contact_page`,
	 * `privacy_policy_page`…) — não governava nada: o arquivo publicado era a
	 * seleção AUTOMÁTICA do plugin, com "Blog" dentro e "Contato" fora, e a
	 * linha fechava OK medindo a própria escrita. A decisão do dono é usar o
	 * llms.txt próprio; a consequência é esta unidade.
	 *
	 * Três atos, cada um com leitura de volta:
	 *
	 * 1. `enable_llms_txt = false` já foi gravado por `aplicar_geral()`; aqui
	 *    ela é RELIDA do banco, porque é ela que o site-core consulta para
	 *    saber se há concorrente.
	 * 2. O agendamento semanal que o plugin de SEO registra para repovoar o
	 *    arquivo (`wpseo_llms_txt_population`) é removido: o watcher do plugin
	 *    o remove quando a chave vira falsa, mas só se ele estiver com os hooks
	 *    registrados nesta requisição — e o plugin foi ativado nesta mesma
	 *    execução.
	 * 3. O arquivo físico `llms.txt` na raiz, SE existir e SE for do plugin de
	 *    SEO (ele se assina no corpo), é apagado; arquivo de outra origem não é
	 *    tocado, porque não se apaga o que não se conhece.
	 *
	 * A leitura de volta é dos três fatos, e o veredito segue a precedência que
	 * o site-core declara: sem arquivo físico e sem concorrente ligado, quem
	 * responde em `/llms.txt` é a rota dele, com a seleção de `f3base_llms`.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_llms_proprio(): array {
		$rotulo = 'seo.llms_proprio';

		if ( ! (bool) F3Base_Imp_Decisoes::valor( 'bots_ia.llms_txt' ) ) {
			return self::saida(
				'N/A',
				$rotulo,
				__( 'condição de aplicabilidade falsa: a política declarada mantém o recurso llms.txt desligado no site-core, e com o emissor do plugin de SEO também desligado não há llms.txt nenhum neste site.', 'f3base' )
			);
		}

		$wpseo   = get_option( 'wpseo', array() );
		$ligada  = is_array( $wpseo ) && ! empty( $wpseo['enable_llms_txt'] );
		$achados = array();

		if ( $ligada ) {
			$achados[] = __( 'a chave enable_llms_txt do plugin de SEO continua LIGADA depois da gravação de aplicar_geral(): o plugin de SEO segue sendo emissor concorrente e o site-core cede o endereço a ele', 'f3base' );
		}

		$hook_do_plugin = 'wpseo_llms_txt_population';
		$agendado       = false !== wp_next_scheduled( $hook_do_plugin );

		if ( $agendado && ! F3Base_Imp_Gravador::em_simulacao() ) {
			wp_clear_scheduled_hook( $hook_do_plugin );
		}

		$ainda_agendado = false !== wp_next_scheduled( $hook_do_plugin );

		if ( $ainda_agendado ) {
			$achados[] = sprintf(
				/* translators: %s: nome do hook. */
				__( 'o agendamento %s do plugin de SEO continua registrado depois de wp_clear_scheduled_hook(): ele repovoaria o arquivo físico na semana seguinte', 'f3base' ),
				$hook_do_plugin
			);
		}

		$arquivo = trailingslashit( ABSPATH ) . 'llms.txt';
		$veredito_do_arquivo = self::veredito_do_arquivo_fisico_de_llms( file_exists( $arquivo ), file_exists( $arquivo ) ? (string) file_get_contents( $arquivo ) : '' );

		if ( 'apagar' === $veredito_do_arquivo['acao'] && ! F3Base_Imp_Gravador::em_simulacao() ) {
			wp_delete_file( $arquivo );
		}

		if ( 'apagar' === $veredito_do_arquivo['acao'] && file_exists( $arquivo ) && ! F3Base_Imp_Gravador::em_simulacao() ) {
			$achados[] = __( 'o arquivo físico llms.txt do plugin de SEO continua na raiz depois de wp_delete_file(): permissão do sistema de arquivos, e enquanto ele existir é ele que responde no endereço', 'f3base' );
		}

		if ( 'preservar' === $veredito_do_arquivo['acao'] ) {
			$achados[] = __( 'há um arquivo físico llms.txt na raiz que NÃO é do plugin de SEO, e ele não foi tocado: arquivo físico vence a rota do site-core, e o que está publicado é ele — se não for intenção, remova-o à mão', 'f3base' );
		}

		if ( array() !== $achados ) {
			return self::saida( 'FALHA', $rotulo, implode( ' | ', $achados ) );
		}

		return self::saida(
			F3Base_Imp_Gravador::em_simulacao() ? 'N/A' : 'OK',
			$rotulo,
			sprintf(
				/* translators: 1: o que aconteceu com o arquivo físico, 2: o que aconteceu com o agendamento, 3: versão observada do plugin. */
				__( 'o /llms.txt é servido pela rota do site-core, com a seleção curada de f3base_llms: a chave enable_llms_txt do plugin de SEO está desligada e relida do banco, %1$s, %2$s. Pela precedência que o site-core declara — arquivo físico na raiz, depois emissor concorrente ligado, depois a rota —, não sobra ninguém na frente dela. Versão observada do plugin de SEO: %3$s.', 'f3base' ),
				$veredito_do_arquivo['motivo'],
				$agendado ? __( 'o agendamento semanal de repovoamento do plugin foi removido e conferido', 'f3base' ) : __( 'não havia agendamento de repovoamento do plugin a remover', 'f3base' ),
				self::versao_observada()
			)
		);
	}

	/**
	 * O que fazer com um arquivo físico `llms.txt` na raiz. FUNÇÃO PURA.
	 *
	 * Só se apaga o que se conhece: o plugin de SEO se assina no corpo do
	 * arquivo que gera ("Generated by Yoast SEO"), e é essa assinatura que
	 * autoriza a remoção. Arquivo sem ela é de outra origem — alguém o pôs ali
	 * de propósito — e fica, com a linha dizendo que ele vence a rota.
	 *
	 * @param bool   $existe Há arquivo na raiz.
	 * @param string $corpo  Conteúdo dele, quando existe.
	 * @return array{acao:string,motivo:string} `acao` é `nenhuma`, `apagar` ou `preservar`.
	 */
	public static function veredito_do_arquivo_fisico_de_llms( bool $existe, string $corpo ): array {
		if ( ! $existe ) {
			return array(
				'acao'   => 'nenhuma',
				'motivo' => __( 'não há arquivo físico llms.txt na raiz', 'f3base' ),
			);
		}

		if ( str_contains( $corpo, 'Generated by Yoast SEO' ) ) {
			return array(
				'acao'   => 'apagar',
				'motivo' => __( 'o arquivo físico llms.txt que o plugin de SEO tinha gravado na raiz foi apagado, e a raiz relida sem ele', 'f3base' ),
			);
		}

		return array(
			'acao'   => 'preservar',
			'motivo' => __( 'há um arquivo físico llms.txt de outra origem na raiz, preservado', 'f3base' ),
		);
	}

	/**
	 * Grava o SEO de um conteúdo — mesmo sem o plugin ativo.
	 *
	 * @param int                 $id      ID do post.
	 * @param array<string,mixed> $valores Valores declarados.
	 * @return array<string,mixed>
	 */
	public static function gravar_por_conteudo( int $id, array $valores ): array {
		$rotulo = 'seo.conteudo:' . $id;

		if ( $id <= 0 ) {
			return self::saida( 'BLOCKED', 'seo.conteudo', __( 'identificador de conteúdo ausente.', 'f3base' ) );
		}

		/*
		 * OS NOMES DAS CHAVES SAEM DO VOCABULÁRIO COMPARTILHADO, e não de
		 * literais aqui. Este adaptador ESCREVE as metas que o `site-core` LÊ —
		 * o noindex honrado e a descrição de cada item do llms.txt —, e enquanto
		 * os dois lados não compartilhavam fonte uma renomeação do fornecedor
		 * quebraria cada um no seu lugar, sem erro e sem aviso: o implantador
		 * continuaria gravando o nome antigo e o leitor continuaria procurando o
		 * nome antigo. Vocabulário ausente é pré-condição ausente, e fecha
		 * BLOCKED com o arquivo nomeado — nunca uma gravação em chave adivinhada.
		 */
		if ( ! F3Base_Imp_Plugins::carregar_vocabulario_do_seo() ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				__( 'pré-condição ausente: o vocabulário das chaves do plugin de SEO não pôde ser carregado nem do plugin instalado nem da reserva do contrato compartilhado (partilhado/includes/class-f3base-chaves-seo.php), e sem ele os nomes das metas seriam adivinhados. Quem escreve e quem lê a mesma chave compartilham fonte; sem a fonte, nada é gravado.', 'f3base' )
			);
		}

		$indexar = ! empty( $valores['indexar'] );

		$metas = array(
			F3Base_Chaves_Seo::TITULO    => (string) ( $valores['titulo'] ?? '' ),
			F3Base_Chaves_Seo::DESCRICAO => (string) ( $valores['descricao'] ?? '' ),
		);

		$metas[ F3Base_Chaves_Seo::NOINDEX ]     = $indexar ? '' : '1';
		$metas[ F3Base_Chaves_Seo::CORNERSTONE ] = ! empty( $valores['cornerstone'] ) ? '1' : '';

		$frase = (string) ( $valores['frase_chave'] ?? '' );

		if ( '' !== $frase ) {
			$metas[ F3Base_Chaves_Seo::FRASE_CHAVE ] = $frase;
		}

		$falhas = array();

		foreach ( $metas as $chave => $valor ) {
			$resultado = '' === $valor && in_array( $chave, array( F3Base_Chaves_Seo::NOINDEX, F3Base_Chaves_Seo::CORNERSTONE ), true )
				? F3Base_Imp_Gravador::remover_meta( 'post', $id, $chave, array( 'plugin' => self::slug() ) )
				: F3Base_Imp_Gravador::gravar_meta( 'post', $id, $chave, $valor, array( 'plugin' => self::slug() ) );

			if ( ! in_array( $resultado['estado'], array( 'OK', 'N/A' ), true ) ) {
				$falhas[] = $chave;
			}
		}

		$comprimento_titulo    = mb_strlen( (string) ( $valores['titulo'] ?? '' ) );
		$comprimento_descricao = mb_strlen( (string) ( $valores['descricao'] ?? '' ) );

		$aviso = '';

		if ( $comprimento_titulo > 60 || $comprimento_descricao > 158 ) {
			$aviso = sprintf(
				/* translators: 1: comprimento do título, 2: comprimento da descrição. */
				__( ' Truncamento provável: título com %1$d caracteres (orçamento editorial 60) e descrição com %2$d (orçamento 158) — medida, nunca reescrita automática.', 'f3base' ),
				$comprimento_titulo,
				$comprimento_descricao
			);
		}

		if ( array() !== $falhas ) {
			return self::saida(
				'FALHA',
				$rotulo,
				sprintf(
					/* translators: %s: chaves que falharam. */
					__( 'leitura de volta divergiu nas metas: %s.', 'f3base' ),
					implode( ', ', $falhas )
				)
			);
		}

		return self::saida(
			'OK',
			$rotulo,
			sprintf(
				/* translators: 1: estado de indexação, 2: estado da frase-chave, 3: aviso de truncamento. */
				__( 'SEO por conteúdo gravado e conferido (as chaves são do plugin, mas quem lê primeiro pode ser o site). Indexação: %1$s. Frase-chave: %2$s.%3$s', 'f3base' ),
				$indexar ? __( 'indexável', 'f3base' ) : __( 'noindex, follow', 'f3base' ),
				'' !== $frase
					? $frase
					: ( $indexar
						? __( 'ausente — ausência é válida, não se fabrica frase para indicador verde', 'f3base' )
						: __( 'isenta: conteúdo noindex não disputa busca', 'f3base' ) ),
				$aviso
			)
		);
	}

	/**
	 * Grava as metas de SEO de um termo com o CONJUNTO INTEIRO.
	 *
	 * `set_value()` uma chave por vez zera as anteriores. Só existe `set_values()`.
	 *
	 * @param int                  $termo     ID do termo.
	 * @param string               $taxonomia Taxonomia.
	 * @param array<string,string> $valores   Conjunto inteiro.
	 * @return array<string,mixed>
	 */
	public static function aplicar_termo( int $termo, string $taxonomia, array $valores ): array {
		$rotulo = 'seo.termo:' . $taxonomia . '#' . $termo;

		if ( ! class_exists( 'WPSEO_Taxonomy_Meta' ) ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				__( 'pré-condição ausente: a classe de metas de taxonomia do plugin de SEO não está carregada. Nenhuma chave gravada uma a uma como contorno — esse é o caminho que zera as anteriores.', 'f3base' )
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida( 'N/A', $rotulo, __( 'modo simulação: gravaria o conjunto inteiro das metas do termo.', 'f3base' ) );
		}

		$antes = WPSEO_Taxonomy_Meta::get_term_meta( $termo, $taxonomia );
		$antes = is_array( $antes ) ? $antes : array();

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_TERMO,
			$rotulo,
			$antes,
			$valores,
			array(
				'acao'      => 'termo.restaurar',
				'id'        => $termo,
				'taxonomia' => $taxonomia,
				'campos'    => array(),
			),
			array(
				'reversivel' => false,
				'motivo'     => __( 'as metas de taxonomia do plugin de SEO vivem numa option agregada do próprio plugin: a reversão fina fica fora da promessa automática.', 'f3base' ),
			)
		);

		WPSEO_Taxonomy_Meta::set_values( $termo, $taxonomia, $valores );

		$lido    = WPSEO_Taxonomy_Meta::get_term_meta( $termo, $taxonomia );
		$lido    = is_array( $lido ) ? $lido : array();
		$faltam  = array();

		foreach ( $valores as $chave => $valor ) {
			if ( ! isset( $lido[ $chave ] ) || (string) $lido[ $chave ] !== (string) $valor ) {
				$faltam[] = (string) $chave;
			}
		}

		return self::saida(
			array() === $faltam ? 'OK' : 'FALHA',
			$rotulo,
			array() === $faltam
				? __( 'conjunto inteiro gravado por set_values() e conferido na leitura de volta.', 'f3base' )
				: sprintf(
					/* translators: %s: chaves divergentes. */
					__( 'leitura de volta das metas do termo divergiu em: %s.', 'f3base' ),
					implode( ', ', $faltam )
				)
		);
	}

	/**
	 * Grava o `robots.txt` como ARQUIVO FÍSICO.
	 *
	 * Arquivo físico anula diretiva virtual — e em hospedagem que responde
	 * `robots.txt` no nível do servidor, a ausência do arquivo devolve o
	 * controle ao template do host, não ao WordPress. Consequência dupla: tudo
	 * precisa estar no arquivo, e o arquivo precisa existir sempre.
	 *
	 * A mutação acontece SÓ dentro da raiz autorizada (`ABSPATH`). Candidato em
	 * diretório pai é conflito externo relatado, nunca mutado: em hospedagem
	 * compartilhada o pai pode pertencer a outro site.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_robots_txt(): array {
		$rotulo  = 'seo.robots_txt';
		$destino = trailingslashit( ABSPATH ) . 'robots.txt';

		$linhas = array(
			'# ' . __( 'Arquivo gerenciado pelo implantador do Método F3.', 'f3base' ),
			'# ' . self::comentario_de_politica(),
			'User-agent: *',
			'Disallow: /*?s=',
			'Disallow: /*&s=',
		);

		foreach ( (array) F3Base_Imp_Decisoes::valor( 'seo.robots_extra' ) as $extra ) {
			$linha = trim( (string) $extra );

			if ( '' !== $linha ) {
				$linhas[] = $linha;
			}
		}

		$linhas[] = '';
		$linhas[] = 'Sitemap: ' . trailingslashit( home_url() ) . 'sitemap_index.xml';
		$linhas[] = '';

		$conteudo = implode( "\n", $linhas );

		$externos = self::candidatos_externos();

		$resultado = F3Base_Imp_Gravador::gravar_arquivo( $destino, $conteudo );

		$nota = array() !== $externos
			? sprintf(
				/* translators: %s: caminhos encontrados fora da raiz autorizada. */
				__( ' Conflito externo relatado, não mutado: há robots.txt fora da raiz autorizada em %s — em hospedagem compartilhada o diretório pai pode pertencer a outro site.', 'f3base' ),
				implode( ', ', $externos )
			)
			: '';

		return self::saida(
			$resultado['estado'],
			$rotulo,
			sprintf(
				/* translators: 1: caminho do arquivo, 2: mensagem do gravador, 3: nota sobre candidatos externos. */
				__( 'arquivo físico em %1$s com o conteúdo-base e a linha Sitemap resolvida por home_url(). %2$s%3$s A leitura pela URL pública é evidência de outra classe e fica com a suíte.', 'f3base' ),
				$destino,
				$resultado['motivo'],
				$nota
			)
		);
	}

	/**
	 * Versão observada do plugin de SEO — diagnóstico, nunca gate.
	 *
	 * @return string
	 */
	public static function versao_observada(): string {
		$versao = F3Base_Imp_Plugins::versao_instalada( self::slug() );

		return '' !== $versao ? $versao : __( 'não instalado', 'f3base' );
	}

	/* ------------------------------------------------------------------ *
	 * Internos
	 * ------------------------------------------------------------------ */

	/**
	 * Em qual option do plugin a chave existe hoje.
	 *
	 * Procurar em vez de fixar o par chave→option é o que sobrevive à
	 * reorganização de options entre versões, que já aconteceu neste plugin.
	 *
	 * @param string $chave Nome da chave.
	 * @return string Nome da option, ou vazio quando a chave não existe.
	 */
	private static function localizar_chave( string $chave ): string {
		foreach ( self::options() as $option ) {
			$valores = get_option( $option, null );

			if ( is_array( $valores ) && array_key_exists( $chave, $valores ) ) {
				return $option;
			}
		}

		return '';
	}

	/**
	 * Comentário que declara a política de bots no próprio arquivo.
	 *
	 * Com a política em "liberar", o arquivo NÃO tem grupo nomeado: ausência de
	 * grupo já significa permitido, e grupo nomeado que repete o curinga só cria
	 * chance de perder paridade. A intenção vive em comentário.
	 *
	 * @return string
	 */
	private static function comentario_de_politica(): string {
		$politica = (string) F3Base_Imp_Decisoes::valor( 'bots_ia.politica' );

		return 'liberar' === $politica
			? __( 'Política de bots de IA: liberar. Sem grupo nomeado — grupo só existe para restringir.', 'f3base' )
			: __( 'Política de bots de IA: restringir. Os grupos nomeados repetem as regras do curinga.', 'f3base' );
	}

	/**
	 * Candidatos de `robots.txt` fora da raiz autorizada.
	 *
	 * @return string[]
	 */
	private static function candidatos_externos(): array {
		$raiz       = realpath( ABSPATH );
		$candidatos = array();

		$possiveis = array();

		if ( isset( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$possiveis[] = trailingslashit( sanitize_text_field( wp_unslash( (string) $_SERVER['DOCUMENT_ROOT'] ) ) ) . 'robots.txt';
		}

		$possiveis[] = trailingslashit( dirname( untrailingslashit( ABSPATH ) ) ) . 'robots.txt';

		foreach ( $possiveis as $caminho ) {
			$real = realpath( $caminho );

			if ( false === $real || ! is_file( $real ) ) {
				continue;
			}

			if ( false !== $raiz && str_starts_with( $real, trailingslashit( $raiz ) ) ) {
				continue;
			}

			$candidatos[] = $real;
		}

		return array_values( array_unique( $candidatos ) );
	}

	/**
	 * Monta o resultado de uma unidade.
	 *
	 * @param string $estado Estado fechado.
	 * @param string $rotulo Nome da checagem.
	 * @param string $motivo Mensagem.
	 * @return array<string,mixed>
	 */
	private static function saida( string $estado, string $rotulo, string $motivo ): array {
		return array(
			'estado' => $estado,
			'rotulo' => $rotulo,
			'motivo' => $motivo,
			'id'     => 0,
		);
	}
}
