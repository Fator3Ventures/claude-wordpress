# TEMPLATE do implantador — o mapa da operação

**Implantador 2.1.0 · Base Site Core Fator3 1.0.0**

Este documento é o **mapa**, não o território. Ele existe para um agente que chega sem
contexto nenhum e precisa saber, em cinco minutos: quais documentos existem, o que cada um
responde, em que ordem se lê, e qual é o fluxo executável de ponta a ponta.

**ELE VIAJA DENTRO DO PACOTE DESDE A 2.1.0**, e é isso que o mantém honesto: a versão dele é
a do zip em que você o abriu, e não a de um arquivo solto que alguém guardou em outro lugar.
Nada aqui substitui os documentos que ele aponta. Se uma frase deste arquivo discordar de um
deles, **o documento vale e este está velho**.

**O que mudou de mapa entre a 1.7.4 e a 2.0.0 cabe numa frase:** o plugin do site tem
repositório próprio, e o implantador não o constrói, não o monta e não o edita — carrega uma
cópia do zip publicado como reserva e uma cópia conferida por hash das regras que precisa ler
antes de o plugin existir.

**O que mudou entre a 2.0.0 e a 2.1.0 cabe em outra: o implantador é executado UMA VEZ por
site, e o que vem depois é feito pelo canal MCP.** Daí saem, uma a uma, as decisões desta
release — o terceiro eixo do encerramento saiu inteiro; o dado do operador deixou de segurar
página e deixou de virar veredito; o `/llms.txt` passou a ser o do plugin do site, com o
emissor do plugin de SEO desligado; os padrões de fábrica da instalação limpa saem; e os
documentos que dizem como isto se usa e como isto se constrói passaram a viajar aqui dentro.

---

## 1. Os documentos, e o que cada um responde

Há **quatro trabalhos diferentes** nesta operação, em **dois repositórios**, e cada trabalho
tem o seu documento. Quase todo erro de agente novo é ter aberto o documento do trabalho
errado — ou o repositório errado.

**E DESDE A 2.1.0 TODOS OS DESTA OPERAÇÃO VIAJAM DENTRO DO ZIP.** Até a 2.0.0 as instruções de
construção e este mapa eram entregues **ao lado** do pacote, e um documento ao lado é um
documento que pode ficar numa versão diferente do artefato que alguém tem na mão. Agora são
seis arquivos na raiz do pacote, e a ausência de qualquer um deles é medida: `entrega.documentacao`
confere `MANIFESTO.md`, `TEMPLATE.md`, `MAPA-DA-OPERACAO.md` e `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md`,
e o entregável entra no **gate de aplicação** como os outros — ausente é BLOCKED com o nome do
arquivo, e BLOCKED em entregável **impede a autodesativação**. `README.md` e `MEMORIA-DECISOES.md`
já tinham entregável próprio e continuam com ele.

| Se o seu trabalho é… | O documento é | Onde | Ele responde |
|---|---|---|---|
| **construir ou corrigir o implantador**, o tema e o conteúdo | `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md` — o prompt-mestre | **dentro do pacote**, na raiz | como se constrói o pacote inteiro do zero: as três peças, a configuração, os lotes, o gravador único, o relatório, o vocabulário fechado de gate, a suíte, o empacotamento, a fronteira com o repositório do plugin e as armadilhas conhecidas. **Começa mandando ler os documentos daqui de dentro e verificar o pacote do plugin** — e é a única seção dele que nenhuma checagem cobra |
| **derivar um site novo** deste template | `TEMPLATE.md` | dentro do pacote | a ordem executável de cima para baixo: copiar, renomear, trocar identidade, substituir conteúdo, preencher, rodar a suíte, instalar |
| **saber, em cinco minutos, como esta operação funciona** | `MAPA-DA-OPERACAO.md` — este arquivo | **dentro do pacote**, na raiz | quais documentos existem, as três peças e qual delas é renomeada, o fluxo executável, o que se publica no catálogo, os erros que um agente novo comete e onde ficar na dúvida de fronteira |
| **mudar o plugin do site** | `INSTRUCOES-DO-PLUGIN.md` | **dentro do zip do plugin**, e no repositório do plugin | o registro único de módulos, o catálogo de options, as tabelas, as rotas REST, a medição de comportamento inteira e o que a suíte DE LÁ cobra de quem mexer |
| **receber uma release nova do plugin** neste pacote | `partilhado/VENDORIZADO.tsv` e `assets/plugins/LEIA-ME.txt` | dentro do pacote | as três edições que uma release do plugin custa deste lado, e o que a suíte confere em cada uma |

E mais três, que são de consulta e não de execução — e existem **nos dois repositórios**, um
conjunto para cada artefato:

| Documento | O que é | Quando abrir |
|---|---|---|
| `README.md` | o leia-me do OPERADOR: árvore de arquivos, pré-requisitos, instalação, execução, reversão, remoção, plugins | quando algo precisar ser instalado, executado, revertido ou desligado |
| `MANIFESTO.md` | a identidade e o inventário da release: caminho → papel, requisito → checagem, detector → fixtures, e o que é CONTRATO (o digesto declarado, o lock) e o que é fato observado | quando você precisar saber se uma afirmação tem checagem que a cobre — e em qual dos dois repositórios |
| `MEMORIA-DECISOES.md` | o PORQUÊ de cada decisão, narrado a partir de defeitos medidos | quando você quiser mudar uma regra e precisar saber o que ela custou para existir |

**O PACOTE DO PLUGIN É O QUE NINGUÉM ABRE E TODO MUNDO DEVERIA.** `Base Site Core Fator3` é o
artefato que **sempre** é instalado junto, em todo site desta operação: o zip publicado no
catálogo, com `INSTRUCOES-DO-PLUGIN.md` dentro dele e a habilidade `f3base/como-usar`
respondendo no site. Quem constrói o TEMA e as PÁGINAS **tem de seguir as regras dele** — a
classe `f3base-secao-<nome>` nos dois lugares, o CTA com o endereço canônico, as classes do
controle de consentimento e do link da política, o par `[hidden]` × `display`, o `theme.json`
que o `CONTRASTE.md` prova, o slug do tema, o `wp_navigation` na option que o tema lê, o
contrato de nomes e a fronteira do validador. Nada disso falha alto: o plugin procura, não
acha, e responde **nada para sempre**, com o relatório verde.

**A ordem de leitura, para quem chega agora:**

1. **este arquivo**, até o fim — são poucos minutos e ele evita os erros da seção 5;
2. `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md`, da primeira seção até *A fronteira com o repositório do plugin* — a primeira diz o que ler antes de escrever qualquer coisa, e ali mora a linha entre o que se constrói e o que se recebe pronto;
3. `TEMPLATE.md`, do começo ao fim, se o trabalho for um site novo;
4. `INSTRUCOES-DO-PLUGIN.md`, **de dentro do zip do plugin** — sempre que o trabalho tocar tema ou páginas, e obrigatoriamente se for mexer no plugin, e aí o repositório é o outro;
5. `README.md` e `MEMORIA-DECISOES.md`, sob demanda.

---

## 2. As três peças, e qual delas é renomeada

Esta é a tabela que mais evita estrago. Um agente que não a souber vai tentar renomear o
plugin, ou editar a cópia dele, e vai quebrar sites.

| Peça | O que é | Release | Repositório | Renomeada por site? |
|---|---|---|---|---|
| **Tema de blocos (FSE)** | apresentação: `theme.json`, templates, parts, patterns, CSS | acompanha o pacote, com numeração própria no cabeçalho do `style.css` | o do implantador | **sim** |
| **Implantador** | orquestra a implantação e se autodesativa ao terminar | é a identidade da release | o do implantador | **sim** |
| **Plugin do site — `Base Site Core Fator3`** | comportamento persistente: medição, consentimento, leads, retenção, cabeçalhos, `llms.txt`, redirects, schema | **própria**, recomeçada em 1.0.0 | **próprio** — o implantador carrega só a reserva e a cópia vendorizada | **NÃO** |

**Por que o plugin fica fora, e a razão não é organização: é dado vivo.** Até a 1.6.6 a
renomeação varria a raiz inteira e cada site produzia um **fork** do plugin, com options
`<prefixo>_ga4_measurement_id` em vez de `f3base_ga4_measurement_id`. Um plugin cujo nome de
option muda por site não é um plugin: são N plugins parecidos, e **nenhuma correção publicada
alcança nenhum deles**.

- **Nome de PASTA é endereço** — trocá-lo custa uma reinstalação.
- **Nome de OPTION é chave de dado** — trocá-lo órfã o valor sem apagar nada e sem erro.
- **Nome de TABELA** apaga a série histórica; **nome de EVENTO** quebra a série na conta do
  fornecedor, onde não há reparo depois.

**O que há do plugin dentro deste pacote, e o que a ferramenta não atravessa:**

| Caminho | O que é | Quem confere |
|---|---|---|
| `assets/plugins/base-site-core-fator3-<versão>.zip` | a RESERVA: o zip publicado no catálogo, copiado byte a byte para a árvore. É ENTRADA de build. É de dentro dele que a suíte lê tudo o que precisa do plugin, e é ele que instala quando a URL do catálogo não responde | `pacote.reserva_confere_com_o_catalogo` — o `sha256` é o declarado em `config/decisoes.tsv`, a versão do nome é a do cabeçalho de dentro, a cópia no bundle é a da árvore |
| `partilhado/` | a cópia VENDORIZADA das quatro classes de regra e das duas tabelas que o implantador lê ANTES de o plugin existir na instalação; `partilhado/VENDORIZADO.tsv` declara de onde cada arquivo vem e por quê | `pacote.copia_vendorizada_confere` — cada arquivo é byte a byte a entrada do zip; arquivo sem declaração e declaração sem arquivo são achados |

Os dois estão em `ferramentas/excecoes-de-prefixo.tsv`. E, porque o implantador renomeado
continua **gravando** o que o plugin **lê**, as grafias de
`partilhado/dados/contrato-de-nomes.tsv` — e toda grafia que a ferramenta deriva do **código**
de DENTRO da reserva — sobrevivem **também dentro dos arquivos que são renomeados**. Duas delas
são fronteira e passaram a estar no contrato publicado: `f3base_operaveis` e
`f3base_proveniencia`, gravadas pelo implantador e lidas pelo plugin.

**Do código, e nunca da prosa** — e isso foi medido na 2.0.0: a derivação lia cada arquivo
do plugin inteiro, o comentário do contrato de nomes que explica quais options são estado SÓ
DO IMPLANTADOR as nomeava, e o pacote renomeado para `acme` saía com `f3base_lock`,
`f3base_checkpoint`, `f3base_journal`, `f3base_estado_aplicacao`, `f3base_release` e
`f3base_fases` intactos — dois implantadores no mesmo WordPress disputando o mesmo lock, com
`estatica.sem_residuo_de_prefixo` verde. As options de estado do SEU implantador são suas e
trocam de prefixo com o resto.

**A exceção mais fácil de errar continua sendo `f3base-secao-`,** o prefixo da classe que
marca uma seção medida. Ele é carimbado pelo tema e pelo conteúdo — renomeados — e procurado
pelo coletor do plugin — não renomeado. Trocá-lo por `<prefixo>-secao-abertura` faz o
observador não receber alvo nenhum: **a medição de seções morre calada em todo site
renomeado**. Ele não é identidade do site: o tema estiliza `f3base-faixa-escura`, essa sim
identidade e essa sim renomeada.

Quem prova tudo isso a cada rodada: `renomeacao.plugin_intacto`,
`renomeacao.secao_medida_apos_renomear`, `renomeacao.contrato_de_nomes_completo`,
`renomeacao.preservados_so_do_codigo` e `estatica.sem_residuo_de_prefixo` — os quatro
primeiros lendo o plugin de dentro da reserva.

**E `f3base-secao-` é a mais fácil de errar, não a única: o TEMA e as PÁGINAS têm um contrato
inteiro com o plugin, e ele está escrito em `INSTRUCOES-DO-PLUGIN.md`, dentro do zip
publicado.** O que o plugin procura no que este pacote constrói:

| O que o plugin procura | Onde isso é carimbado | O que acontece se faltar |
|---|---|---|
| `f3base-secao-<nome>` no `className` do bloco **e** na `class` da `<div>` | patterns do tema e conteúdo das páginas | a medição de seções responde nada para sempre |
| o CTA com o **endereço da página canônica** de contato | pattern do tema | o servidor não tem o que promover a link do WhatsApp |
| `f3base-consentimento-abrir`, `data-f3base-consentimento` e `aria-controls="f3base-consentimento-banner"` | part do rodapé | a faixa de consentimento nunca abre |
| `f3base-link-privacidade` no link da política | part do rodapé | o caminho declarado até a política deixa de existir |
| o par `[hidden]` que **vence** o `display` de autor | `style.css` do tema | a faixa nasce visível e o "Fechar" não fecha |
| o mapa de cores e fontes que o `CONTRASTE.md` prova | `theme.json` | a prova do tema passa a descrever outro tema |
| o slug do tema em `site.tema_slug` e o `wp_navigation` na option que o tema lê | configuração e unidade de navegação | instalação procurando no nome errado; menu caindo no fallback de lista de páginas |
| as options `f3base_*` — inclusive `f3base_operaveis` e `f3base_proveniencia` | gravador único do implantador | configuração órfã, sem erro nenhum |

---

## 3. O fluxo executável, de ponta a ponta

### De onde se parte

Do pacote `implantador-base`, que é o **template de criação de sites**: o site demonstrativo
do método mais as peças que produzem qualquer site da operação. Ele não é o site de ninguém.

### O que se copia e o que se renomeia

```
cp -a implantador-base <pasta-do-site-novo>
bash <pasta-do-site-novo>/ferramentas/renomear-prefixo.sh <prefixo> <pasta-do-site-novo>
```

Renomeia: tema, options e metas **do implantador**, text domain, handles, classes CSS de
identidade, prefixo das classes PHP. **Não** renomeia: `partilhado/`, `assets/plugins/` e as
grafias do contrato de nomes e da reserva. A ferramenta é idempotente — a busca é sempre pelo
prefixo de ORIGEM, em `ferramentas/prefixo-do-template.tsv` — e recusa prefixo inválido antes
de qualquer escrita. Medido na construção da 2.0.0: o pacote renomeado para `acme` fecha a
suíte com FALHA 0 e `estatica.sem_residuo_de_prefixo` em OK.

### O que se preenche, e em qual arquivo

**O operador abre um arquivo só: `config/projeto.json`.** Os outros descrevem o pacote.

**E ELE PREENCHE ANTES DA EXECUÇÃO, porque a execução é UMA.** Desde a 2.1.0 o implantador é
executado **uma vez por site**: o que depende de dado que só o operador tem — razão social,
documento e endereço do controlador, número de contato, hipótese legal, IDs de conta, nome do
mecanismo de agendamento da hospedagem — é preenchido **antes**, ou é ajustado **depois pelo
canal MCP**, sobre um site que já está no ar. **Não existe mais "preencha e execute de novo":**
o terceiro eixo do encerramento, que somava essas ausências e respondia sempre essa frase, saiu
inteiro. O que ficou: cada linha continua nomeando a chave vazia e o caminho de saída, sem
somar nada e sem decidir nada.

**O QUE ISSO CUSTA, e o mapa não esconde: com o controlador vazio, a política de privacidade
PUBLICA — com o lugar do valor vazio na frase.** Até a 2.0.0 uma guarda medida a segurava em
rascunho e fechava BLOCKED nomeando as chaves faltantes. A guarda saiu por decisão do dono
("não é blocked, é responsabilidade do usuário"), e o status de **toda** página passou a ser o
DECLARADO. Quem preenche antes não vê diferença; quem não preenche entrega uma política que
não diz quem é o controlador.

| Arquivo | O que guarda | Quem responde |
|---|---|---|
| `config/projeto.json` | contato, controlador, fato jurídico, IDs de conta, verificação de domínio, organização no grafo, regimes de formulário, `plugins_operacionais` | o operador |
| `config/site.json` | conteúdo declarado, referências internas entre objetos, identidade técnica do pacote renomeado | o agente que instancia o template |
| `config/decisoes.tsv` | as decisões do PACOTE, cada uma com o MOTIVO escrito ao lado — inclusive a entrada do catálogo do plugin, com URL **e `sha256`** | quem mantém o pacote |
| `config/releases-suportadas.tsv` | de qual versão instalada este implantador sabe subir | a história de homologação |

**A regra que decide em qual arquivo uma coisa mora:** uma chave só se justifica se passar
nas duas metades — existe projeto legítimo em que o valor certo é DIFERENTE, **e** o valor é
impossível de derivar. Falhou numa? Sai da configuração e vira linha de `config/decisoes.tsv`,
com o motivo ao lado.

**E você não precisa decorar em qual dos dois arquivos cada chave mora: o relatório diz.**
Nenhuma mensagem de runtime carrega o nome do arquivo digitado — ele é **derivado** de qual
leitor declara a chave, e `estatica.residencia_de_chave_derivada` recusa qualquer nome de
arquivo que volte a ser digitado.

Depois: identidade visual em `fontes/tema/`, conteúdo em `content/`, e por último
`config/site.json` → `conteudo.demonstrativo: false` — **último**, nunca antes de substituir
os arquivos.

### O que se roda

```
bash suite/verificar.sh <caminho-absoluto-do-pacote>
bash suite/verificar.sh piso <caminho-absoluto-do-pacote>
```

As duas rodadas precisam fechar com **FALHA 0**. BLOCKED com fase declarada não impede a
entrega. WARN é achado adverso que não bloqueia — leia cada um. Pré-condições da máquina:
`php`, `node`, `zip`, `unzip`. Nem `faketime` nem Chromium: os dois saíram com o
empacotamento do plugin.

**Esta rodada é METADE da aprovação.** A outra metade é a rodada selada do repositório do
plugin — a que roda o endpoint de leads, o `llms.txt`, a medição, a bancada WordPress real e
a única checagem que dirige um Chromium de verdade sobre o cliente entregue,
`navegador.comportamento_real`. O elo entre as duas é o `sha256` do catálogo: a rodada de lá
o sela, `config/decisoes.tsv` o declara, e `pacote.reserva_confere_com_o_catalogo` confere
que a reserva embutida É esse zip. **Um pacote verificado aqui sem a rodada de lá não é um
pacote aprovado.** Toda checagem que esta suíte deixou de emitir está declarada, uma a uma e
com o motivo, em `suite/excluidas.tsv`; `excluidas.declaradas` confere que a lista está viva.

**O vocabulário desse arquivo ganhou uma quarta categoria na 2.1.0, e ela é a única perigosa:
`retirada`.** As outras três dizem *"esta pergunta é respondida noutro lugar"* — na suíte do
plugin, por outra linha daqui, ou num passo que este repositório não executa mais. `retirada`
diz *"esta pergunta não é do implantador"*, e a cobertura encolhe de propósito: saíram por ela
a checagem do controlador, as três do eixo de convergência e a da coerência do fato jurídico.
Por isso ela não é escolha de quem escreve a checagem: é decisão do dono, com a razão escrita
ao lado do nome.

**Duas rodadas sobre a mesma árvore dão o MESMO hash de pacote.** Na 2.0.0 isso é
estrutural: nada é montado a cada rodada — a reserva é entrada de build, com bytes fixos. O
único arquivo que muda de um dia para o outro é `suite/fases.json`, com precisão de dia. Hash
diferente sobre árvore idêntica, no mesmo dia, é sinal de adulteração e não de build.

### O que se instala

A etapa de empacotamento publica **um zip** em `dist/`:

| Artefato | Numeração | O que se faz com ele |
|---|---|---|
| `dist/implantador-base-<versão>.zip` | do implantador | envio de arquivo em **Plugins → Adicionar novo → Enviar plugin**; ativar e rodar. Ele se autodesativa quando termina |

**O implantador instala o plugin sozinho**, do catálogo, pela URL declarada — conferindo o
`sha256` declarado ANTES de instalar. Se a URL não responder, instala a reserva embutida,
pela mesma conferência. Você não precisa instalá-lo à mão, e não precisa publicar nada: o zip
do plugin é publicado pelo repositório do plugin (seção 4). **Ele desce UMA vez:** o plugin do
site tem unidade própria, e o laço que percorre os plugins do catálogo pula a entrada de papel
`site-core` — até a 2.0.0 o mesmo zip descia duas vezes em toda implantação, com as duas linhas
concordando e nenhuma delas errada.

### O que a execução TIRA da instalação

Duas coisas saem, e as duas saem **nomeadas**, porque remoção silenciosa é perda sem registro.

| O que sai | Como sai | O limite |
|---|---|---|
| **os padrões de fábrica** — os temas Twenty Twenty-Três/Quatro/Cinco, o Akismet e o Hello Dolly | pela lista declarada no catálogo, com o plugin ativo desativado pela API do núcleo antes, e leitura de volta; a unidade é `limpeza`, depende do tema e roda antes do plugin do site | **nunca o tema ATIVO nem o pai dele**, ainda que declarados — a linha diz que os PULOU; item não instalado é AUSENTE; lista vazia é plano vazio; nada fora da lista é tocado, e o plugin do painel da hospedagem fica. A remoção é **IRREVERSÍVEL** e o journal a declara assim, com o motivo: volta pelo repositório oficial |
| **o resíduo do instalador** — o post "Hello world!" e a página de exemplo | para a **lixeira**, reversível, decidido por identidade de texto contra o que `wp_install_defaults()` escreveria agora | objeto **em uso** e objeto **gerenciado** são intocáveis; objeto **editado** é intocável; e desde a 2.1.0 a **data de modificação não decide nada** — o instalador da hospedagem toca o post segundos depois de criá-lo, e a 2.0.0 o preservava como "editado", entregando-o publicado, no sitemap e no `llms.txt` |

**O preço da primeira linha fica escrito: remover o Twenty Twenty-Cinco tira do núcleo o
tema-reserva.** Se o tema ativo quebrar, não há para onde cair. A decisão é essa mesma — tema
que quebra neste pacote é defeito de release, medido antes de sair, e a reserva do núcleo era
um site alheio no ar com a cara de outro projeto.

### O `/llms.txt` é do plugin do site, e o emissor do plugin de SEO fica desligado

Isto mudou na 2.1.0 e foi medido no site real. Com o recurso do plugin de SEO ligado, ele grava
um **arquivo físico** na raiz que **vence** a rota do plugin do site — a precedência declarada é
arquivo físico → concorrente ligado → rota —, e a seleção curada que este pacote gravava ia para
chaves que a versão instalada **não lê**: página selecionada ficava fora do arquivo, página não
selecionada ficava dentro, e a linha fechava OK medindo a própria escrita.

Agora: a chave do emissor do plugin de SEO é gravada como o literal `false`, **sempre**; uma
unidade própria **relê a chave do banco**, remove o repovoamento agendado dele e apaga o arquivo
físico da raiz **se ele for daquele plugin** — arquivo de outra origem é preservado e nomeado —,
e só fecha OK com os três fatos relidos. `estatica.llms_proprio_sem_concorrente` fecha a porta no
build. **Verificado no site real:** desligada a chave, o arquivo físico sumiu e `/llms.txt`
passou a responder pela rota do plugin do site, com o cabeçalho do mecanismo e a seleção curada
na ordem declarada, seguida da enumeração automática.

### Como se sabe que terminou

- a rodada da suíte fecha **sem FALHA**, e o selo grava `suite/rodada.json` com o hash do
  pacote medido;
- no site, o implantador **se autodesativa** — e as três condições são todas obrigatórias:
  estado `SUCESSO_APLICACAO`, nenhum entregável em BLOCKED e os dois vereditos do canal MCP
  em OK. **Entregável inclui os documentos**: desde a 2.1.0, `entrega.documentacao` confere
  manifesto, roteiro de derivação, mapa da operação e instruções de construção dentro do
  pacote, e a ausência de qualquer um é BLOCKED com o nome do arquivo;
- **o encerramento tem DOIS eixos, não três.** O texto diz que o implantador é executado uma
  vez por site e que o que ele deixou por preencher é ajustado pelo canal, **sem nova
  execução**. A idempotência continua sendo propriedade do código — reexecutar não repete o
  que já foi aplicado —; o que saiu foi o ciclo "execute de novo" como método de operação;
- **o formulário está NA PÁGINA declarada**, e a página de confirmação está em `noindex`
  gravado. Os dois foram defeito medido: a referência da página era lida do arquivo errado e
  voltava vazia, a função que punha o formulário na página devolvia vazio em todo caminho de
  falha, e a unidade fechava OK com o formulário em página nenhuma; a confirmação, sem o
  `noindex` gravado, ia para o sitemap;
- `conteudo.demonstrativo_no_site` conta **zero** páginas publicadas com a marca do template,
  medido no BANCO e não na configuração — essa linha é do plugin, e sai na rodada dele e no
  site;
- **`plugins.site_core_versao` não fecha FALHA.** Ela é a **derivação única** do confronto
  entre a versão do plugin que ficou instalada e a que o NOME da reserva carrega, e o ramo
  *"instalada atrás"* fecha **FALHA** — não WARN. FALHA derruba o estado da aplicação para
  `FALHA_PARCIAL`, e com ele cai a primeira condição da autodesativação: **um site que ficou
  com uma versão superada do plugin mantém o implantador no ar**, que é o desfecho certo. O
  que ela NÃO distingue — o mesmo número com bytes diferentes — é assunto do digesto, na
  linha `plugins.instalado:base-site-core-fator3`: dois fatos, duas linhas;
- os testes de ligação com os consoles (o `generate_lead` chegando no DebugView do GA4, o
  `Lead` único e deduplicado no Test Events da Meta) passaram — esses são a única prova de
  que a conta do fornecedor recebe o que o site emite.

### O que o relatório diz sobre cada linha, e por que o vocabulário importa

Cada linha do relatório declara **fase** e **gate**, e o gate é vocabulário fechado: **três
nomes**, todos escolhidos por quem emite a linha:

| Gate | O que ele afirma | Efeito |
|---|---|---|
| `aplicacao` | o host mede, e a resposta **decide** | promove a unidade, suspende dependentes, decide a autodesativação |
| `relato` | o host **mede**, a linha é acionável, e **não decide gate nenhum**. **É o padrão** | nenhum |
| `fase` | **evidência que este host NÃO produz** — navegador, campo, suíte externa | nenhum; sai nomeada como pendência de fase |

**Havia um quarto até a 2.0.0, `convergencia`, e ele saiu com o eixo que alimentava.** Ninguém
o escolhia: era derivado de um metadado de pré-condição, para o dado que só o operador tem.
Com a execução única, um gate cuja única saída era "preencha e execute de novo" descrevia um
ciclo que a operação não tem. Linha que depende de dado do operador é hoje `relato` como
qualquer outra medição do host: nomeia a chave vazia, diz a saída, e não decide nada.

**Linha de gate `fase` não pode fechar FALHA:** FALHA entra na contagem que derruba o estado
da aplicação, e uma linha que o texto diz não decidir estaria decidindo por dentro. Quem cobra
a invariante são `estatica.gate_de_fase_sem_ramo_de_falha` e
`lotes.gate_de_fase_nao_derruba_estado`.

---

## 4. O que se publica no catálogo, e com que nome

Três artefatos desta operação **não vêm do WordPress.org**: eles descem de URL declarada no
repositório `Fator3Ventures/claude-wordpress`, em `main`.

| Artefato | Nome do arquivo publicado | Quem publica | `sha256` no catálogo |
|---|---|---|---|
| **Plugin do site** | **`base-site-core-fator3.zip`** | o repositório do plugin, ao fim da rodada selada dele | **declarado** desde a 2.0.0 |
| Servidor do canal MCP | `wp-mcp-ultimate-main.zip` | quem opera o canal | **declarado** desde a 2.1.0 |
| Complemento do canal MCP | `wp-mcp-ultimate-complemento-fator3.zip` | quem opera o canal | **declarado** desde a 2.1.0 |

> **O NOME DO ZIP DO PLUGIN É `base-site-core-fator3.zip`** — sem número no nome. O
> `f3base-site-core.zip` antigo deixou de ser lido por ninguém na 1.7.0.

> **OS TRÊS DECLARAM DIGESTO, e a coluna nova custa um passo em cada publicação.** Sem digesto
> declarado, o host **fixa o primeiro observado** — o que não é verificação de integridade:
> defende contra a origem mudar embaixo das execuções seguintes e **não** defende a primeira
> busca. Sobre os dois artefatos que expõem justamente as rotas de arquivo e de banco do canal,
> essa era a garantia mais fraca do pacote no lugar mais exposto dele. **O preço fica declarado:
> zip novo desses plugins exige digesto novo em `config/decisoes.tsv`** — publicar sem declarar
> faz a instalação reprovar nomeando os dois valores e não instalar nada. É a mesma disciplina
> que o plugin do site já cobrava, estendida aos outros dois.

> **ESTADO DE HOJE: o endereço serve a 1.0.0, o catálogo declara o `sha256` dela, e a reserva
> embutida É ela.** A pendência que a 1.7.4 carregava — reserva em 1.0.1, catálogo em 1.0.0,
> toda implantação nova fechando em `FALHA_PARCIAL` — está fechada, e a 2.0.0 existe para que
> ela não volte: a reserva deixou de ser montada aqui e passou a ser a cópia do publicado,
> conferida por `sha256` a cada rodada.

**O ciclo de release do plugin tem dois lados, e nenhum é opcional.**

No repositório do plugin:

1. subir a versão **só no cabeçalho `Version:`** do arquivo principal;
2. rodar a suíte de lá, que monta o zip reprodutível, sela o `sha256` e o escreve em
   `SHA256SUMS.txt`;
3. **publicar o zip no catálogo, com o nome `base-site-core-fator3.zip`** — só este passo
   alcança os sites já no ar.

Neste pacote, **três edições e a rodada**:

4. trocar `assets/plugins/base-site-core-fator3-<versão>.zip` pelo publicado, com o número
   novo no nome;
5. declarar o `sha256` novo em `config/decisoes.tsv`, na entrada `plugins.instalaveis.<n>`
   de papel `site-core`;
6. extrair de dentro do zip novo os arquivos listados em `partilhado/VENDORIZADO.tsv`, por
   cima dos de `partilhado/` — nunca editá-los à mão;
7. rodar o comando único, que sela uma release nova deste pacote, porque a reserva e a cópia
   mudaram de bytes.

Pular qualquer um dos três é medido, e cada omissão tem o seu lugar de acusação. Trocar o
zip sem declarar o `sha256`, ou declarar sem trocar: `pacote.reserva_confere_com_o_catalogo`
reprova nomeando os dois digestos. Trocar o zip sem reextrair `partilhado/`:
`pacote.copia_vendorizada_confere` reprova nomeando o arquivo. Pular os três de uma vez
deixa a suíte verde e o pacote inteiro atrás do catálogo — e aí quem acusa é o SITE, na
primeira implantação: a URL entrega o zip novo, o digesto declarado é o velho, e
`plugins.instalado:base-site-core-fator3` fecha FALHA com "DIGESTO DIVERGENTE do declarado",
sem instalar nada. Nenhum dos quatro caminhos é silencioso.

**Reverter o plugin é republicar.** Não há histórico de versões servido por terceiro: o
catálogo serve um arquivo só. Quem reverte precisa ter guardado o zip da versão de destino,
e refaz deste lado as mesmas três edições.

---

## 5. Os erros que um agente novo comete aqui

Cada um com a consequência, porque nenhum deles se anuncia como erro.

| Erro | Consequência |
|---|---|
| **Aprovar o pacote com a rodada desta suíte, sem a rodada do plugin** | metade da medição: o endpoint de leads, o `llms.txt`, a medição, a bancada WordPress real e o Chromium sobre o cliente entregue rodam LÁ. O elo é o `sha256` do catálogo; sem a rodada de lá, o número declarado aqui não foi selado por ninguém |
| **Trocar o zip da reserva sem declarar o `sha256` novo no catálogo** | `pacote.reserva_confere_com_o_catalogo` reprova nomeando os dois digestos; e, no site, a URL entregaria um artefato e a reserva outro, com o mesmo nome |
| **Declarar o `sha256` novo sem trocar a reserva** | a mesma linha reprova pelo outro lado; e a suíte, que lê o plugin de dentro da reserva, passaria a medir a versão velha |
| **Editar `partilhado/` à mão** | é fork: `pacote.copia_vendorizada_confere` acusa no primeiro byte diferente. Foi medido na 1.7.4 — quatro dos cinco arquivos divergiam do zip publicado, um sem a guarda de `class_exists`, outro sem duas chaves de cabeçalho que o plugin governa, e nada acusava |
| **Recriar `fontes/plugin/` neste pacote** | `pacote.allow_list` aborta o empacotamento com o nome de cada arquivo; a suíte continua lendo o plugin de dentro da reserva |
| **Deixar o catálogo servindo uma versão ATRÁS da que a reserva carrega** | a URL responde, o plugin instala, a leitura de volta confere, o site sobe funcionando e **nada no site parece errado**: toda implantação entrega a versão ANTERIOR do plugin. O único sintoma é `plugins.site_core_versao`, que fecha **FALHA** nomeando as duas versões e mantém o implantador ativo |
| **Rodar a suíte do plugin, ver verde, e não publicar o zip no catálogo** | os sites já entregues continuam com a versão antiga **sem uma linha de erro em lugar nenhum**; a próxima implantação fecha em FALHA_PARCIAL com o implantador ativo |
| **Confiar que a reserva instala sem digesto** | desde a 2.0.0 ela passa pelo mesmo `sha256` declarado que o download passaria; reserva que não é o zip publicado é RECUSADA nomeando os dois valores. Da 1.7.0 à 1.7.4 a reserva versionada não instalava NUNCA — o resolvedor só conhecia o slot do operador —, e todos os documentos afirmavam o contrário |
| **Embutir DUAS reservas do mesmo slug, ou uma reserva mais velha que o instalado** | duas reservas não escolhem: o resolvedor devolve vazio nomeando as duas, e a instalação fecha BLOCKED com o motivo. Reserva atrás da instalada não instala por cima — nunca downgrade vale para ela também — e a linha diz qual das duas ficou |
| **Renomear o prefixo do plugin junto com o do site** | cada site vira um FORK: options `<prefixo>_ga4_...`, e nenhuma correção publicada alcança nenhum deles |
| **Deixar a lista de grafias preservadas crescer com o que um comentário do plugin cita** | o site renomeado sai com as options de estado do implantador no prefixo do template (`f3base_lock`, `f3base_checkpoint`…), dois implantadores no mesmo WordPress disputam o mesmo lock, e `estatica.sem_residuo_de_prefixo` fica verde porque a lista os absolve. `renomeacao.preservados_so_do_codigo` planta uma grafia só em comentário e exige que ela seja renomeada |
| **Carimbar a seção como `<prefixo>-secao-<nome>`** | o coletor não recebe alvo nenhum; `f3base_secao_vista` continua declarado, ocupa linha no relatório e responde **nada para sempre** |
| **Escrever a classe da seção só no `className` OU só no `<div class>`** | o editor reescreve o outro na primeira edição e a marca some sem aviso — `estatica.conteudo_declara_secoes` reprova as duas formas |
| **Tentar construir o plugin a partir do implantador** | trabalho jogado fora: a fonte do plugin não mora aqui, e nada no implantador o constrói, gera ou edita |
| **Declarar `gate => 'fase'` numa linha que ESTE host mede** | o relatório passa a afirmar, com o nome dela, que a evidência vem de outro lugar — e a frase é falsa. `estatica.gate_de_fase_sem_ramo_de_falha` acusa; o padrão certo é `relato` |
| **Medir o mesmo fato em DUAS linhas com severidades próprias** | elas discordam, e a discordância sai impressa na mesma tela. Um fato, uma linha, um veredito — e versão e bytes são DOIS fatos |
| **Escrever piso que exercita só a REGRA e chamar isso de cobertura** | a bancada prova que a função reconhece a contradição quando alguém a entrega, e não prova nada sobre o pacote. Toda invariante precisa das duas: a estática, que varre o objeto, e a funcional, que cobre o que só aparece em execução |
| **Apagar uma linha de `suite/excluidas.tsv` sem devolver a checagem** | cobertura que encolheu sem que ninguém decidisse; a tabela é ESPELHADA no repositório do plugin justamente para que os dois lados possam ser conferidos |
| **Preencher medição em `config/site.json`** | ela não mora ali: os IDs de conta são de `config/projeto.json` → `tracking.*`, ou das options pelo canal |
| **Declarar o token da Conversions API da Meta na configuração** | o arquivo viaja dentro do zip: o segredo é copiado para todo lugar por onde o pacote passou. `estatica.segredo_fora_da_configuracao` reprova — lendo a lista de segredos de dentro da reserva |
| **Desligar `conteudo.demonstrativo` antes de substituir o conteúdo** | `conteudo.marca_demonstrativa` acusa arquivo a arquivo e a publicação é **recusada** em tempo de aplicação |
| **Renomear um evento de comportamento depois de o site estar no ar** | a série histórica da conta do fornecedor quebra: o nome novo é uma série NOVA, a antiga para de crescer, e nenhum erro aparece. E o lugar de renomear é o repositório do plugin |
| **Rodar `suite/verificar.sh` com caminho relativo, ou sem argumento** | reprova por desenho — `FALHA suite.invocacao`, código de saída 2 |
| **Editar `MEMORIA-DECISOES.md` para trocar o prefixo** | inventaria um passado que não aconteceu; o documento é história herdada e está declarado como exceção da renomeação |
| **Digitar um número num documento entregável** | ele envelhece em silêncio. Nos documentos que carregam região gerada — leia-me, manifesto e memória de decisões —, todo número sai GERADO por leitura de disco, e `estatica.carimbo_de_release_nos_documentos` compara com a medição de agora. Nos outros — roteiro de derivação, este mapa e as instruções de construção — não há região a gerar, e a regra é de escrita: **número só entra como HISTÓRIA de defeito medido**, nunca como estado atual do pacote |
| **Digitar o nome de um arquivo de configuração dentro de uma mensagem** | a mensagem manda editar o arquivo errado e o operador fica preso nela. O arquivo é derivado de quem declara a chave (`estatica.residencia_de_chave_derivada`) |
| **Ligar o `llms.txt` do plugin de SEO** | o **arquivo físico** que ele grava na raiz **vence** a rota do plugin do site, e a seleção curada vai para chaves que a versão instalada não lê. Foi medido: página selecionada ficou de fora do arquivo, página não selecionada ficou dentro, e a linha fechava OK porque media a própria escrita. A chave é gravada como o literal `false`, sempre, e `estatica.llms_proprio_sem_concorrente` acusa quem a religar |
| **Deixar os temas de fábrica na instalação** | os Twenty Twenty-* e o Hello Dolly ficam no painel, entram na atualização automática e aparecem em todo relatório de segurança como superfície instalada. A unidade `limpeza` os remove pela lista do catálogo — e ela **nunca** remove o tema ativo nem o pai dele, ainda que declarados. O preço do contrário também está declarado: sem o Twenty Twenty-Cinco, o núcleo fica sem tema-reserva |
| **Confiar que a data de modificação prova edição** | não prova. O instalador da hospedagem toca o post de exemplo **dois segundos** depois de criá-lo, e a 2.0.0 o preservava como "editado": o "Hello world!" ia ao ar, no sitemap e no `llms.txt`, com a categoria Uncategorized. Quem decide é a identidade do texto contra o que o núcleo escreveria agora — objeto **em uso** e objeto **gerenciado** continuam intocáveis |
| **Ler o bloco `formularios` do arquivo errado** | a referência da página volta vazia, a função que põe o formulário na página devolve vazio em todo caminho de falha, e a unidade fecha **OK com o formulário em página nenhuma**. Foi medido, e vinha da 1.7.4. A página de cada regime é lida do arquivo em que o bloco MORA, e `formulario.na_pagina_declarada` reprova quando a página declarada fica sem o shortcode |
| **Esperar que o implantador cobre o dado do operador** | ele não cobra mais. O terceiro eixo do encerramento saiu na 2.1.0 e a guarda que segurava a política de privacidade em rascunho saiu junto: **com o controlador vazio, a política PUBLICA com o lugar do valor vazio na frase**. O dado é preenchido em `config/projeto.json` ANTES da execução única, ou ajustado DEPOIS pelo canal — e ninguém vai avisar de novo |
| **Publicar um zip novo do canal MCP sem declarar o `sha256`** | desde a 2.1.0 as duas entradas do canal declaram digesto: a instalação reprova nomeando os dois valores e não instala nada. É o comportamento certo, e é o de quem esqueceu um passo — não o de quem foi atacado |
| **Entregar o pacote sem os documentos dentro dele** | `entrega.documentacao` fecha BLOCKED com o nome do arquivo que falta, e BLOCKED em entregável **impede a autodesativação**: o implantador fica no ar até a entrega existir |

---

## 6. Onde ficar quando a dúvida for de fronteira

- **mudou o SITE** — conteúdo, identidade, contato, IDs de conta → `TEMPLATE.md`;
- **mudou o PLUGIN** — módulo, evento, option, rota, tabela → `INSTRUCOES-DO-PLUGIN.md`, no
  repositório do plugin, e sai uma release do plugin — **seguida da publicação no catálogo**
  e das três edições deste lado (seção 4);
- **mudou o IMPLANTADOR** — lotes, preflight, relatório, suíte →
  `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md` para construir e `README.md` para operar — os dois
  **dentro do pacote** —, e sai uma release do implantador;
- **mudou o TEMA ou uma PÁGINA** — pattern, template part, markup de seção, rodapé, CTA →
  este pacote, **e as regras do plugin valem aqui** (seção 2): o que o plugin procura no que
  você carimba está em `INSTRUCOES-DO-PLUGIN.md`, dentro do zip publicado, e a habilidade
  `f3base/como-usar` responde no próprio site;
- **faltou DADO DO OPERADOR** — razão social, documento, endereço, número de contato,
  hipótese legal, ID de conta → `config/projeto.json` **antes** da execução única, ou a rota
  do canal **depois** dela. Não há terceira via, e não há segunda execução esperando por
  ninguém (seção 3);
- **mudou o que o PLUGIN espera do implantador** — a classe que ele carrega, o método que
  chama para validar, os arquivos que lê e grava → `mcp.fronteira_do_validador` acusa deste
  lado, lendo a classe de habilidades de dentro da reserva; a mudança é dos dois repositórios
  ao mesmo tempo, e o zip novo só entra aqui depois de a fronteira fechar.

**Depois da entrega, o site é do agente — e desde a 2.1.0 essa frase é o desenho inteiro, não
o epílogo.** O implantador é executado **uma vez por site**, se autodesativa e não volta
sozinho; quem opera dali em diante é um agente pelo canal MCP — tema, plugins, conteúdo e o
dado que o operador não preencheu, sem exceção. O pacote não protege o que instalou de quem
vai operá-lo: ele **nomeia** o que divergiu, em vez de decidir por quem opera. E não cobra:
o que ele deixou por preencher sai escrito na linha, uma vez, sem virar veredito e sem pedir
uma segunda execução que ninguém vai fazer.
