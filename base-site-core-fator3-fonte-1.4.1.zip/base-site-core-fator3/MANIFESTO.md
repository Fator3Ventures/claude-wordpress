<!-- gerado:inicio=carimbo -->
# Manifesto da release — Base Site Core Fator3 1.4.1

> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip ser
> montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número destes documentos
> é digitado à mão: número digitado está certo no dia em que foi escrito e é contradito pela rodada
> seguinte, sem nada acusando. O que não pode ser medido no momento da escrita sai como pendência
> nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `1.4.1` |
| Pasta instalada | `base-site-core-fator3` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Plataforma declarada no cabeçalho | `EXIGE PHP DE 64 BITS` |
| Escopo de instalação declarado no cabeçalho | `INSTALAÇÃO ÚNICA, NÃO MULTISITE` |
| Arquivos na fonte do plugin | 46 |
| Arquivos vindos de `partilhado/` | 5 |
| Arquivos no repositório (fora de `dist/` e dos produtos da rodada) | 356 |
| Checagens declaradas por classe de evidência | `analise-estatica/build` 34 · `leitura-de-volta/producao` 1 · `medida/build` 1 · `medida/campo` 1 · `medida/producao` 2 · `pendencia-externa/local` 3 · `pendencia-externa/producao` 2 · `teste-funcional/build` 82 · `wp-real/build` 44 |
| Detectores com piso em disco | 28 |
| Ramos de piso em disco (negativa + positiva) | 56 |
| Passos da bancada WordPress com mutante declarado | 43 |
| Checagens com piso declarado em sonda | 126 |
| Artefato publicado | `base-site-core-fator3-1.4.1.zip` |
| Época declarada de cada entrada do zip | `1980-01-01 00:00:00 UTC` |
<!-- gerado:fim=carimbo -->

Este arquivo responde a duas perguntas, e a separação entre elas é o que ele existe para
manter: **o que é CONTRATO** — a coisa que este repositório promete e que outra máquina pode
cobrar — e **o que é FATO OBSERVADO** — a coisa que foi medida numa rodada e que descreve o
estado, não a promessa.

Confundir as duas é barato e caro ao mesmo tempo. Um fato observado tratado como contrato
vira uma promessa que ninguém se comprometeu a manter, e a primeira release que a quebra
não tem nem culpado nem conserto. Um contrato tratado como fato observado é pior: ele deixa
de ser cobrado, e quando alguém percebe, o que já foi publicado depende dele.

O que o produto FAZ não está aqui — está em `fontes/plugin/INSTRUCOES-DO-PLUGIN.md`. Como se
instala, atualiza, reverte e desinstala está em `README.md`. Por que cada coisa é assim está
em `MEMORIA-DECISOES.md`.

## Identidade

A identidade deste artefato é **uma só e sai de um lugar só**: o cabeçalho `Version:` do
arquivo principal do plugin. Ela está no carimbo gerado no topo, e não está escrita em mais
nenhum lugar deste repositório — nem numa constante ao lado do cabeçalho, nem numa chave de
configuração, nem numa frase de prosa.

Isso é decisão, e o defeito que a produziu está medido: o cabeçalho dizia um número e a
constante ao lado dele dizia outro, e ninguém acusava, porque as duas eram verdadeiras
isoladamente. Quem lia a constante — a tela, o parâmetro de versão dos assets publicados —
carimbava um número que o WordPress não mostra em lugar nenhum.

O plugin tem numeração **própria**, e ela recomeçou. Ele deixou de ser construído pelo
implantador e virou artefato com identidade e ciclo próprios: uma correção no plugin não
obriga uma release do implantador, e o número de um não diz nada sobre o do outro.

## Contrato

Três coisas, e as três podem ser cobradas de fora deste repositório.

### O zip é reprodutível, e essa é a cláusula central

**Duas montagens sobre a mesma árvore dão o mesmo `sha256`. Hash diferente sobre árvore
idêntica é adulteração** — não é ruído de build, não é "o zip mudou de data", não é um
detalhe do empacotamento. É a única leitura possível, e é por isso que ela precisa valer
sempre.

A frase só é utilizável porque as duas portas por onde os bytes vazavam estão fechadas, e as
duas foram medidas abertas:

- **O carimbo de cada entrada é uma época DECLARADA**, `1980-01-01 00:00:00 UTC`, produzida
  por `f3b_epoca_do_zip()`. Enquanto ele saía do relógio, a mesma árvore empacotada em dois
  dias dava dois arquivos diferentes, com `diff -r` limpo entre as extrações.
- **A ordem das entradas é DECLARADA**, crescente por byte, montada pelo empacotamento e
  entregue ao `zip` por `-@`. Enquanto ela vinha do `readdir`, a mesma árvore no mesmo dia
  dava bytes diferentes em dois volumes da mesma máquina — no `ext4` e no `tmpfs`.

**Quem cobra isso é `pacote.zip_reprodutivel`**, e ela não se contenta com as duas regras
puras sobre o artefato: o piso dela roda o empacotamento **de novo**, com o relógio movido
por `faketime` e com o volume trocado, e exige bytes idênticos. E roda mais uma vez com um
**mutante do próprio empacotamento** — o carimbo de volta ao relógio —, exigindo que as duas
montagens DIVIRJAM. Sem essa última parte o piso mediria o instrumento em vez do objeto:
uma alavanca que não move nada aprova qualquer coisa.

**Por que a cláusula é central, e não uma elegância.** Este zip é publicado no catálogo, e o
implantador FIXA o digesto dele na primeira observação: republicar amanhã um artefato de
conteúdo idêntico, reconstruído da mesma fonte, faria toda implantação seguinte falhar
acusando troca de artefato que não houve. Um alarme falso que reprova toda a operação é pior
do que não ter alarme.

### O digesto publicado é o digesto que a rodada selou

O `sha256` do artefato está no carimbo gerado no topo e em `suite/rodada.json`, gravado pelo
selo na última etapa do comando único e lido de volta do disco depois de gravado.

**O registro NÃO é injetado dentro do zip**, e a subtração é deliberada: um arquivo que muda
a cada rodada, dentro de um artefato cujo digesto é a chave de comparação entre execuções,
destruiria a cláusula anterior com uma linha.

**Rodada com FALHA não sela, e apaga o registro anterior.** Registro que sobrevive a uma
rodada reprovada é uma afirmação de limpeza sem medição por trás.

### O inventário é allow-list executável, e não uma lista de arquivos

`suite/inventario.tsv` declara caminho e papel. Arquivo em disco que não casa com nenhuma
linha **aborta o build com o nome dele**, antes de qualquer checagem; caminho inventariado
que não existe em disco também é achado. Quem cobra os dois sentidos é `pacote.allow_list`.

A fonte do plugin é declarada **arquivo a arquivo**, e isso é decisão: ela é o artefato, e o
papel de cada arquivo dela é o que outro agente lê para saber no que pode mexer. A suíte e a
saída de build são **prefixos**, também por decisão: ali o que importa é o conjunto.

## Fato observado

Nada abaixo é promessa. É o que foi medido, e a próxima rodada pode medir outra coisa sem
que nada tenha sido quebrado.

- **`dist/lock.tsv`** — o `sha256` de cada arquivo da árvore, mais o do artefato. Ele
  responde "o que exatamente estava em disco quando este zip foi montado", e é o que se lê
  quando duas montagens divergem e é preciso saber ONDE. Ele é reescrito a cada rodada e não
  viaja no repositório.
- **A contagem por estado da rodada** — quantas linhas fecharam em cada um dos seis estados,
  com os nomes. Ela mora em `suite/rodada.json` e não neste documento, porque é resultado de
  execução: escrevê-la aqui seria o número digitado que os quatro documentos entregáveis
  existem para não ter.
- **A versão do núcleo do WordPress em que a bancada rodou.** Ela vem do cache de insumos e
  pode mudar sem que este repositório mude. O que é contrato é o mínimo declarado no
  cabeçalho do plugin; o que a bancada usou é observação.
- **O peso entregue de cada `.js`** — está na região gerada `plugin-peso` de
  `INSTRUCOES-DO-PLUGIN.md`, medido pelo mesmo corte do empacotamento.

## O que a suíte não mede, e por que isso está escrito

Três ausências conhecidas, todas declaradas no lugar onde alguém iria procurá-las:

- **Multisite.** A ativação em rede é recusada com o motivo, e a bancada observa a
  desinstalação num site único. `suite/bancada-wp/LEIA-ME.md` declara a ausência.
- **MySQL.** O banco da bancada é SQLite pelo drop-in; diferenças de `dbDelta` entre os dois
  motores ficam fora do alcance daquela etapa.
- **HTTPS.** O servidor embutido é HTTP, então o que depende de `is_ssl()` não é exercitado
  ali.

A quarta ausência é maior e tem tabela própria, gerada abaixo: **as checagens que a suíte da
referência media e esta não mede.** A suíte deste repositório foi extraída da do implantador,
e checagem que some numa extração é indistinguível de checagem esquecida. A prova de que a
extração não mudou nenhum veredito está em `suite/correcoes/rodada-0.diff.tsv`, e a prova de
que ela não cegou os detectores que sobraram está em `suite/correcoes/rodada-0.mutacoes.md`.

<!-- gerado:inicio=inventario -->
### Inventário: caminho para papel

Gerado de `suite/inventario.tsv`. Manter aqui uma cópia escrita à mão criaria duas fontes, e a segunda
envelheceria calada — o inventário é executável e este documento não.

| Caminho | Papel |
|---|---|
| `fontes/plugin/INSTRUCOES-DO-PLUGIN.md` | INSTRUCOES DO PLUGIN, e ele VIAJA DENTRO DO ZIP DO PLUGIN — nao dentro do bundle. E a unica coisa que outro agente precisa ler para entender, operar e MUDAR este plugin: o que cada modulo faz e quando fica inativo, todas as options com o que acontece com cada uma vazia, as duas tabelas do banco coluna a coluna, as rotas REST com limites e recusas, a medicao de comportamento inteira, como marcar uma secao medida, e o que NUNCA se toca. Os numeros dele sao GERADOS por leitura de disco em regioes marcadas, na primeira etapa do comando unico, antes de o zip ser montado. Quem confere: estatica.carimbo_de_release_nos_documentos (as regioes batem com a medicao de agora) e pacote.instrucoes_do_plugin_no_zip (o documento esta no zip, sem numero digitado fora dos blocos gerados, e com todo modulo de includes/ descrito na prosa). |
| `fontes/plugin/admin/assets/f3base-admin.css` | Estilo da tela de administração. Só apresentação. |
| `fontes/plugin/admin/class-f3base-admin-medicao.php` | Menu Medição: o que os visitantes fizeram, por evento declarado e por página, com estado vazio que diz desde quando o site coleta e o que falta — e o que o site DESCARTOU, dito antes de qualquer tabela, para que ninguém some achando que tem tudo. |
| `fontes/plugin/admin/class-f3base-admin-tela.php` | Tela do wp-admin, renderizada a partir do registro único de módulos — nunca de lista escrita à mão. |
| `fontes/plugin/assets/f3base-consentimento.js` | Comportamento do consentimento pré-aprovado e do controle de revisão do rodapé. |
| `fontes/plugin/assets/f3base-leads.js` | Comportamento do CTA de leads: preserva o destino explícito, monta a URL do WhatsApp só quando o href é do modelo, registra a interação por sendBeacon, transporta a atribuição com os identificadores de clique e dispara a conversão nos quatro canais. É onde o contrato de DOM está documentado. |
| `fontes/plugin/assets/f3base-tracking.js` | Carregador único das tags de GA4, Google Ads, Meta e LinkedIn: um caminho só — container do GTM ou tags diretas —, sempre sob o mesmo portão de consentimento. É também o coletor de comportamento: ele conta a travessia, sela o lote, o grava no registro da visita e o despacha confirmando a ENTREGA — nunca o enfileiramento. |
| `fontes/plugin/base-site-core-fator3.php` | Bootstrap do PLUGIN Base Site Core Fator3: cabeçalho, constantes, guarda de versão de PHP e carregamento do registro único. Desde a 1.7.0 ele é artefato PRÓPRIO — identidade única, numeração recomeçada em 1.0.0, instalado em qualquer site desta operação como plugin de catálogo — e a fonte dele NÃO viaja dentro do bundle do implantador: o bundle leva só o zip. A versão sai do cabeçalho por get_file_data(), nunca de um literal ao lado dele, que foi o defeito medido (o cabeçalho dizia 1.3.6 e a constante dizia 1.3.5). |
| `fontes/plugin/dados/contrato-de-nomes.tsv` | CONTRATO DE NOMES DO PLUGIN: as grafias que a renomeacao de prefixo NAO reescreve — options, tabelas, eventos, namespace REST, classes compartilhadas, hook da cadencia e o prefixo da classe que marca secao medida. Ele e do PLUGIN porque quem e dono do nome e quem o declara, e e lido por tres lugares: a ferramenta de renomeacao (que mascara estas grafias antes de substituir), estatica.sem_residuo_de_prefixo (que nao as acusa) e renomeacao.contrato_de_nomes_completo (que confere que ele cobre o catalogo inteiro). Sem ele o implantador renomeado gravaria acme_ga4_measurement_id e o plugin continuaria lendo f3base_ga4_measurement_id: configuracao orfa, sem erro nenhum. |
| `fontes/plugin/dados/emissores-conhecidos.tsv` | Declaração ÚNICA dos emissores de tag conhecidos, com a condição de emissão medida quando há option conhecida. É DICA para o preflight classificar cedo, nunca o gate: quem decide é a contagem no HTML publicado, em tracking.emissor_unico. Viaja dentro do site-core e é lida também pelo implantador, da cópia de origem. |
| `fontes/plugin/dados/eventos-comportamento.tsv` | Declaração ÚNICA dos eventos de COMPORTAMENTO: nome, parâmetros (na ordem em que o coletor os entrega), teto por página, gatilho e limiar. O cliente não escreve nome de evento nem de parâmetro — ele pede a declaração pelo gatilho, que é a chave de junção. Quem lê a série é um agente comparando períodos, e para ele nome que muda entre releases é medição que sumiu sem erro nenhum. Viaja dentro do site-core e é lida pelo módulo de tracking e pela suíte. |
| `fontes/plugin/dados/vitais.tsv` | Declaração única das medidas de carregamento: o que cada sigla diz, em português comum, e o limiar de "bom" que a tela mostra ao lado do valor medido. |
| `fontes/plugin/includes/class-f3base-atividade.php` | Última atividade relevante por módulo, exibida na tela. |
| `fontes/plugin/includes/class-f3base-censo-demonstrativo.php` | Regra COMPARTILHADA do censo de conteudo demonstrativo: conta, NO BANCO, as paginas publicadas que ainda carregam a marca do template e as NOMEIA. Sem pai e sem dependencia de proposito — o implantador a carrega do arquivo de origem, porque o modo somente-relatorio precisa dela antes de o site-core existir na instalacao, e duas copias da regra divergiriam na primeira condicao acrescentada. |
| `fontes/plugin/includes/class-f3base-chaves-seo.php` | VOCABULARIO do plugin de SEO — os nomes de meta e de option do fornecedor, num lugar so. Sem pai e sem dependencia de proposito: o site-core o carrega pelo autoload e o implantador pela copia de origem, porque um ESCREVE a meta de cada conteudo e o outro a LE, e quem escreve e quem le a mesma chave precisam da mesma fonte. |
| `fontes/plugin/includes/class-f3base-como-usar.php` | A habilidade f3base/como-usar: diz ao agente MCP o que o plugin ja faz por assunto, a option exata para mudar cada coisa e o que NAO fazer por outro caminho, com o preco de cada atalho. A lista de assuntos sai do REGISTRO de modulos, nunca de texto a mao: modulo novo aparece sozinho, e manual digitado envelhece na primeira vez que alguem esquece de atualiza-lo. |
| `fontes/plugin/includes/class-f3base-config-mcp.php` | As habilidades f3base/config-ler e f3base/config-escrever: o agente MCP le a configuracao do implantador e o schema dela, altera e grava. Mora no PLUGIN porque o implantador se autodesativa, e e depois disso que o agente precisa preencher a configuracao para a proxima execucao. Escrita e tudo ou nada: o que nao passa no schema e recusado com o campo nomeado e nada e gravado. Valida pelo validador do implantador, nunca por um segundo. |
| `fontes/plugin/includes/class-f3base-emissores.php` | Regra COMPARTILHADA do segundo emissor: lê a declaração e devolve o veredito de emissão (leitor, concorrente, nao-medido). Sem pai e sem dependência de propósito — o preflight do implantador a carrega do arquivo de origem, porque ele roda antes de o site-core existir na instalação. |
| `fontes/plugin/includes/class-f3base-llms.php` | Regra COMPARTILHADA do arquivo llms.txt: precedencia de emissor, selecao com as exclusoes, ordem, origem de cada descricao, limpeza do resumo e endereco medido do sitemap. Os dois modulos que servem os arquivos a consultam, e nenhum deles le meta de noindex por conta propria — esse fato tem um produtor so, no modulo de noindex. |
| `fontes/plugin/includes/class-f3base-modulo-cabecalhos.php` | Módulo: emite os cabeçalhos de resposta com o valor GRAVADO em cada chave, e avisa em WARN quando o valor custa a atribuição dos canais pagos. |
| `fontes/plugin/includes/class-f3base-modulo-cadencia-relatorio.php` | Módulo: OUVINTE do evento f3base_cadencia_relatorio, registro das recorrências quinzenal e mensal que o núcleo não tem, execução do modo somente-relatório com última execução, próxima, duração, resultado, erro e atraso, e o contador de ajustes que dispara. |
| `fontes/plugin/includes/class-f3base-modulo-comportamento.php` | Modulo: recebe, a cada ocultamento de pagina, o LOTE selado com os totais agregados e o registro daquela visita e os soma numa tabela propria — uma linha por dia, caminho, evento e detalhe, com contagem e soma. E a leitura que o site tem por conta propria, legivel na tela e por rota de banco do canal, sem depender de credencial de fornecedor. Nenhum identificador de visitante, nenhuma URL com query e nenhum texto livre atravessam: o detalhe passa por alfabeto fechado e o nome do evento sai da declaracao, nunca do cliente. O lote leva um SELO sorteado, e um selo ja gravado para a mesma visita e recusado com 2xx: e o que permite ao navegador reenviar um lote cuja resposta se perdeu no caminho de volta sem que a tabela conte duas vezes. O que foi DESCARTADO e gravado por dia e caminho, fora do total, para que a tela possa dizer que a tabela esta incompleta. |
| `fontes/plugin/includes/class-f3base-modulo-consentimento.php` | Módulo: política de consentimento e o controle permanente do rodapé. |
| `fontes/plugin/includes/class-f3base-modulo-endpoint-leads.php` | Módulo: rota REST pública e endurecida que recebe o registro de lead. |
| `fontes/plugin/includes/class-f3base-modulo-leads-whatsapp.php` | Módulo: promove a link profundo do WhatsApp apenas o CTA que ainda tem o href do modelo, preserva o destino de quem o trocou e enfileira o script de leads. |
| `fontes/plugin/includes/class-f3base-modulo-llms-full-txt.php` | Módulo: rota virtual de llms-full.txt com o texto integral dos mesmos itens. Desligado por padrao: com a chave desligada nao ha hook, rota nem superficie publica. |
| `fontes/plugin/includes/class-f3base-modulo-llms-txt-reserva.php` | Módulo: rota virtual de llms.txt, servida quando ela e a responsavel pelo endereco — arquivo fisico vence, emissor concorrente medido vem depois. Junta a selecao curada com a enumeracao do conteudo publicado conforme o modo declarado. |
| `fontes/plugin/includes/class-f3base-modulo-meta-capi.php` | Modulo: envia o evento Lead de SERVIDOR para a Conversions API da Meta depois da persistencia confirmada, com o mesmo event_id do navegador — e-mail e telefone em SHA-256 sobre o valor normalizado pela regra da Meta, nunca em claro. O token e option do site e nao viaja no arquivo de configuracao. |
| `fontes/plugin/includes/class-f3base-modulo-noindex-honrado.php` | Módulo: honra o noindex gravado nas chaves do plugin de SEO mesmo sem o plugin ativo. |
| `fontes/plugin/includes/class-f3base-modulo-redirects.php` | Módulo: redirecionamento de slug antigo, cobrindo o que o núcleo não cobre. |
| `fontes/plugin/includes/class-f3base-modulo-retencao-eliminacao.php` | Módulo: limpeza por prazo, exportador e eliminador do núcleo, e journal de eliminação. |
| `fontes/plugin/includes/class-f3base-modulo-rota-origem.php` | Módulo: rota de leitura de volta pela origem, restrita a caminhos do próprio home_url(). |
| `fontes/plugin/includes/class-f3base-modulo-schema-extensao.php` | Módulo: estende o schema do plugin de SEO sem duplicar nó existente. |
| `fontes/plugin/includes/class-f3base-modulo-tracking.php` | Módulo: emite GA4, Google Ads, Meta e LinkedIn a partir dos IDs gravados, por um caminho só — container do GTM ou tags diretas — e sob um portão de consentimento só; slot vazio é inerte. |
| `fontes/plugin/includes/class-f3base-modulo-verificacao-dominio.php` | Modulo: emite no head a metatag de verificacao de posse do dominio de cada token gravado. Slot vazio e inerte; valor fora da forma esperada e preservado e avisado, nunca apagado. |
| `fontes/plugin/includes/class-f3base-modulo.php` | Contrato de um módulo: identidade, dependências, options que o controlam, hooks e estado com motivo. |
| `fontes/plugin/includes/class-f3base-options.php` | Gravador ÚNICO de options do site-core, com catálogo, sanitização que normaliza o conhecido e PRESERVA o desconhecido, e procedência. |
| `fontes/plugin/includes/class-f3base-plugin.php` | Orquestrador: registra os hooks lendo o registro único. |
| `fontes/plugin/includes/class-f3base-registro.php` | Registro ÚNICO de módulos: alimenta hooks, tela e relatório. |
| `fontes/plugin/includes/class-f3base-vocabulario.php` | VOCABULARIO compartilhado pelos dois runtimes: o CONJUNTO de valores que existem — modelos de atribuicao, modos da lista do llms.txt, politicas de frame, COOP, referrer e permissoes, e o slug do plugin de cada papel. Sem pai e sem dependencia, como F3Base_Chaves_Seo: o site-core a carrega pelo autoload dele e o implantador por require_once da copia de origem. Quem ESCOLHE entre os valores e config/decisoes.tsv; decisoes.fonte_unica cruza os dois, e e o cruzamento que torna duas fontes seguras. |
| `fontes/plugin/uninstall.php` | Desinstalação: declara o destino de cada conjunto de dados, passando pelo gravador único. |
| `README.md` | LEIA-ME DO OPERADOR, e o primeiro arquivo que alguém abre neste repositório. Diz o que o plugin é, o que a máquina que roda o comando único precisa ter, como se instala num site, como se atualiza, como se reverte, como se desinstala e o que fica depois — mais a fronteira com o implantador. As regiões `carimbo` e `arvore` sao GERADAS por leitura de disco; a prosa nao repete o que INSTRUCOES-DO-PLUGIN.md diz sobre o produto, ela aponta para ele. Quem confere: estatica.carimbo_de_release_nos_documentos e doc.numero_digitado. |
| `MANIFESTO.md` | IDENTIDADE E INVENTÁRIO DA RELEASE: o que é CONTRATO (o zip reprodutível e o digesto dele, o lock) e o que é fato observado, mais o inventário caminho a caminho, a tabela requisito -> checagem -> evidência, as três formas de piso e o que a suíte da referência media e esta nao mede. Cinco regiões geradas — `carimbo`, `inventario`, `requisitos`, `fixtures` e `excluidas` —, todas por leitura das tabelas declaradas: uma cópia escrita à mão criaria a segunda fonte que envelhece calada. |
| `MEMORIA-DECISOES.md` | O PORQUÊ, a partir de defeito medido. Duas partes: as decisões HERDADAS do implantador que são do plugin, transcritas verbatim dentro de um bloco delimitado e com a origem declarada em cada título — reescrevê-las inventaria um passado que nao aconteceu —, e as decisões que nasceram nesta release, uma por família de defeito medido, cada uma com o que foi decidido, o defeito que a originou, a checagem que prova, o que custa e como reverter. As regiões `carimbo` e `contagem` sao geradas, e a segunda conta as decisões lendo os títulos deste próprio arquivo. |
| `fontes/plugin/includes/class-f3base-modulo-acessos-servidor.php` | Coleta e leitura dos logs fechados. |
| `fontes/plugin/includes/class-f3base-modulo-sessao-de-login.php` | Prazo e diagnostico de sessoes do nucleo. |
| `fontes/plugin/includes/class-f3base-acessos-mcp.php` | Habilidade administrativa de leitura de acessos. |
| `fontes/plugin/admin/class-f3base-admin-acessos.php` | Aba de acessos por pagina e familia. |
| `fontes/plugin/dados/robos-conhecidos.tsv` | Marcas HTTP e classes de agentes declarados. |
| `ENTREGA-1.1.0.md` | Relatório da evolução: análise dos anexos, ajustes no plano, resultado medido, limites e instruções de uso. |
| `ENTREGA-1.1.1.md` | Relatório das correções de configuração independente e diretório de logs sem www. |
| `ENTREGA-1.1.2.md` | Resolução genérica de logs, evidência no host, testes e limites. |
| `fontes/plugin/includes/class-f3base-acessos-atuais.php` | Leitura temporária do dia atual sem armazenamento histórico. |
| `ENTREGA-1.2.0.md` | Atualização da medição, dia atual e coleta diária verificada. |
| `fontes/plugin/includes/class-f3base-modulo-llms-markdown.php` | Alternativas Markdown e descoberta do índice. |
| `fontes/plugin/includes/class-f3base-modulo-robots-txt.php` | Gerador de robots.txt com troca reversível do arquivo físico. |
| `ENTREGA-1.3.0.md` | Auditoria de llms.txt e robots.txt, referências e validação. |
| `fontes/plugin/includes/class-f3base-robots-arquivo.php` | Troca reversível do robots físico com backup e restauração atômica. |
| `ENTREGA-1.4.0.md` | Relatório da troca de robots.txt e do conteúdo integral em Markdown. |
| `fontes/plugin/includes/class-f3base-robots-entrega.php` | Verificação da entrega pública e manutenção automática do robots gerenciado. |
| `ENTREGA-1.4.1.md` | Correções de entrega HTTP, arquivo gerenciado, filtros tardios e diagnóstico de robots.txt. |
| `suite/bancada-wp/` (prefixo) | A BANCADA WORDPRESS REAL, e ela vem ANTES do prefixo da suíte de propósito: o papel dela não é o do resto do instrumento. Aqui moram o montador do WordPress descartável (bancada.sh), o roteador do servidor embutido, o executor da desinstalação como o núcleo a executa, o roteiro dos passos, a tabela que declara o mutante e a situação do piso de cada passo, os patches mutantes e o LEIA-ME. É a única parte da suíte que instala o zip num WordPress de verdade — e por isso a única que precisa de insumos de fora (núcleo, drop-in de SQLite e wp-cli), que vivem em cache fora do repositório e nunca entram no pacote. |
| `suite/` (prefixo) | A SUÍTE inteira: o comando único, as regras compartilhadas, as sondas em subprocesso, as tabelas declaradas e as fixtures de piso. Prefixo, e não caminho a caminho, porque o que se autoriza aqui é o instrumento como um todo — nenhum arquivo desta árvore viaja no zip do plugin, e nenhum deles é lido pelo runtime do site. |
| `dist/` (prefixo) | SAÍDA DE BUILD: o zip do plugin publicado, a cópia de conferência do que foi entregue (dist/entregue/) e o lock de sha256. Reescrito a cada rodada e fora de toda varredura de pacote, porque não é fonte — é o que a fonte produz. |
<!-- gerado:fim=inventario -->

<!-- gerado:inicio=requisitos -->
### Requisito para checagem, ambiente e evidência

Gerado de `suite/manifesto.tsv`. O cruzamento com a rodada é BIDIRECIONAL e roda em
`manifesto.bidirecional`: requisito cuja checagem a rodada não emitiu é FALHA, e rótulo emitido sem
requisito nem armadilha que o justifique também. Requisito que aparece mais de uma vez aponta para a
mesma checagem por mais de um motivo — um fato, uma linha de rodada, vários requisitos atendidos.

| Requisito | Checagem | Ambiente | Evidência |
|---|---|---|---|
| Layout de arquivos é allow-list de caminhos: arquivo fora dela aborta o empacotamento com o nome | `pacote.allow_list` | aqui | `analise-estatica/build` |
| Artefato de build precisa ser mais novo que toda fonte do pacote | `pacote.build_fresco` | aqui | `medida/build` |
| O JavaScript ENTREGUE ao visitante viaja sem comentario: comentario e para quem MANTEM o pacote, e o site de trafego pago o baixa a cada carregamento sem ter leitor nenhum para ele | `pacote.js_entregue_sem_comentario` | aqui | `analise-estatica/build` |
| O corte de comentario nao perde nada alem de comentario: o fluxo de tokens significativos do entregue e identico ao da fonte, e e por tokenizador — nunca por expressao regular, que apaga `/*` dentro de string e `//` dentro de URL ou de literal de regex | `pacote.js_entregue_sem_comentario` | aqui | `analise-estatica/build` |
| PHP 8.1+ compatível, zero notice: todo arquivo do pacote precisa ao menos analisar | `estatica.php_lint` | aqui | `analise-estatica/build` |
| Arquivo ÚNICO de configuração e seu schema precisam ser JSON válido | `estatica.json_valido` | aqui | `analise-estatica/build` |
| Código executável mora em arquivo .js próprio, e arquivo próprio precisa analisar | `estatica.js_lint` | aqui | `analise-estatica/build` |
| Ponto único de escrita de options: nenhuma chamada direta fora do gravador | `estatica.detector_escrita_unica` | aqui | `analise-estatica/build` |
| version_compare() só aceita os operadores da lista fechada | `estatica.detector_version_compare` | aqui | `analise-estatica/build` |
| Nenhuma checagem com condição literal | `estatica.detector_condicao_literal` | aqui | `analise-estatica/build` |
| Toda checagem emite nos DOIS ramos — provado pelo piso, que roda o ramo negativo e o positivo de cada detector | `estatica.detector_condicao_literal` | aqui | `teste-funcional/build` |
| Conteúdo editorial e código executável não moram em heredoc PHP | `estatica.detector_codigo_em_string` | aqui | `analise-estatica/build` |
| Nenhuma lista fechada literal decide o que a configuração declara: símbolo chamado precisa existir | `estatica.simbolos_resolvem` | aqui | `analise-estatica/build` |
| Estados fechados: OK, FALHA, BLOCKED, N/A, WAIVED, WARN e nenhum outro | `estatica.estados_fechados` | aqui | `analise-estatica/build` |
| Contagem de estado sai sempre com a lista de nomes correspondente na mesma saída: número sem nome não responde à pergunta do operador | `estatica.contagem_com_nomes` | aqui | `analise-estatica/build` |
| Toda checagem em FALHA, BLOCKED ou WARN é nomeada no relatório, mesmo quando a unidade que a contém fecha OK | `estatica.contagem_com_nomes` | aqui | `analise-estatica/build` |
| WARN so existe com achado adverso: medicao que validou, aplicou, declarou ou ficou dentro do esperado fecha OK com o detalhe no texto | `estatica.warn_tem_ramo_adverso` | aqui | `analise-estatica/build` |
| O CTA e publicado pela presenca do numero, e so por ela: sem numero o bloco nao e publicado nem no comportamento degradado | `cta.publicado_pela_presenca_do_numero` | aqui | `teste-funcional/build` |
| Entregável: plugin persistente site-core | `entrega.site_core` | aqui | `analise-estatica/build` |
| O manifesto de verificação cruza nos dois sentidos com a rodada | `manifesto.bidirecional` | aqui | `analise-estatica/build` |
| Toda armadilha conhecida está mapeada para checagem com piso, ou declarada como pendência | `armadilhas.mapeadas` | aqui | `analise-estatica/build` |
| O regime de formulário é DERIVADO do valor do destino, e não de um interruptor: destino preenchido faz o regime existir e o CTA ser publicado; destino vazio fecha N/A com a condição declarada e o CTA não é publicado, nem no comportamento degradado | `formulario.destino_privado` | condicional | `analise-estatica/build` |
| Envio aceito pelo servidor é o critério de lead do regime declarado | `formulario.envio_ponta_a_ponta` | wordpress | `pendencia-externa/local` |
| Sem JavaScript o formulário degrada como declarado, sem envio silencioso | `formulario.degradado_sem_js` | navegador | `pendencia-externa/local` |
| Consentimento pré-aprovado com controle no rodapé de toda página publicada | `consentimento.controle_no_rodape` | wordpress | `pendencia-externa/local` |
| Elemento cuja visibilidade e comandada por hidden nao pode ter display declarado por regra de autor sem o par [hidden] que o vença | `estatica.hidden_governa_visibilidade` | aqui | `analise-estatica/build` |
| Os cabeçalhos de resposta declarados chegam ao cliente | `htaccess.cabecalhos_servidos` | producao | `pendencia-externa/producao` |
| Rota de origem no site-core, restrita a caminhos do próprio home_url() | `origem.rota_carimbada` | producao | `pendencia-externa/producao` |
| COOP declarado preserva a janela aberta por popup | `seguranca.coop_preserva_popup` | producao | `medida/producao` |
| Core Web Vitals medidos em campo: o site COLETA LCP, CLS, INP e TTFB por PerformanceObserver nativo, e o dado de campo continua dependendo de trafego real | `desempenho.core_web_vitals` | campo | `medida/campo` |
| O site nasce instrumentado para comportamento: rolagem, secao vista, link externo, friccao, erro do proprio site e Core Web Vitals, todos sob o mesmo portao de consentimento e com teto por pagina declarado | `js.comportamento_instrumentado` | aqui | `teste-funcional/build` |
| Os dados da instrumentacao sao visiveis DENTRO do WordPress: o resumo agregado por dia, caminho e evento entra por rota propria com schema fechado, limite de taxa atomico e status coerente com o corpo | `comportamento.resumo_agregado` | aqui | `teste-funcional/build` |
| Nenhum dado pessoal e nenhum identificador de visitante atravessa o resumo de comportamento, e duas sessoes somam na mesma linha do dia | `comportamento.resumo_agregado` | aqui | `teste-funcional/build` |
| A retencao do resumo de comportamento e declarada em option operavel e executada pela rotina de retencao que ja existe | `comportamento.resumo_agregado` | aqui | `teste-funcional/build` |
| Numa visita, as ocorrencias de um mesmo gatilho no mesmo caminho formam uma sequencia SEM BURACOS: nenhum mecanismo avanca o contador sem produzir linha | `js.sessao_com_releitura` | aqui | `teste-funcional/build` |
| O envio confirma a ENTREGA e nao o enfileiramento: o lote so e esquecido com resposta 2xx, e rede, 429, 503 e 5xx mantem o lote inteiro para a tentativa seguinte | `js.sessao_com_releitura` | aqui | `teste-funcional/build` |
| A linha e tao duravel quanto o contador: o acumulado e os lotes pendentes moram no registro da visita, e o carregamento que morre sem evento de saida nao leva nenhum dos dois junto | `js.sessao_com_releitura` | aqui | `teste-funcional/build` |
| O acumulado e a fila de pendentes sao duraveis SEPARADAMENTE, e cada um responde por um caso: morrer sem ter selado e segurado pelo acumulado, morrer depois de selar e ser recusado e segurado pela fila | `js.sessao_com_releitura` | aqui | `teste-funcional/build` |
| O teto de linhas do CORPO sela o lote em vez de cortar a linha: um leitor atento entre dois ocultamentos entrega TODOS os acionamentos, em varios lotes, e a serie nao abre buraco no meio | `js.sessao_com_releitura` | aqui | `teste-funcional/build` |
| Sem fetch com keepalive o envio continua acontecendo por sendBeacon, e a perda do lote enfileirado-e-perdido nesse caminho e declarada | `js.resumo_da_sessao` | aqui | `teste-funcional/build` |
| O mesmo lote entregue duas vezes produz UMA linha de cada: o selo e reservado antes da escrita, confirmado depois dela e devolvido quando nada foi gravado | `comportamento.lote_idempotente` | aqui | `teste-funcional/build` |
| O corte deixa de morrer na resposta da rota e e GRAVADO por dia e por caminho, fora do total, para que a tela diga que a tabela esta incompleta | `comportamento.lote_idempotente` | aqui | `teste-funcional/build` |
| O resumo da sessao e enviado UMA vez, no ocultamento da pagina, por sendBeacon, sob o mesmo portao de consentimento da instrumentacao; sem sendBeacon a sessao se perde, e a perda e declarada | `js.resumo_da_sessao` | aqui | `teste-funcional/build` |
| A tela do site-core agrupa os campos por assunto na ordem declarada, e cada campo operavel mostra rotulo, impacto e exemplo com o exemplo fora do value e sem placeholder | `tela.campo_diz_impacto_e_exemplo` | aqui | `teste-funcional/build` |
| O diagnostico de modulos, estados, hooks e avisos continua completo na tela, depois dos campos | `tela.campo_diz_impacto_e_exemplo` | aqui | `teste-funcional/build` |
| A tela mostra o resumo de comportamento com o periodo ao lado, diz que contam as sessoes em que a POLITICA VIGENTE permitiu medir — nomeando a politica e dizendo que quem recusou no controle do rodape fica de fora, sem prometer consentimento onde ha politica declarada do projeto —, diz onde estao os dados que nao estao ali e, com zero sessoes, diz que nao ha dados | `medicao.menu_proprio` | aqui | `teste-funcional/build` |
| Toda folha operavel do catalogo declara IMPACTO — o que muda no site com o campo preenchido, e o que acontece com ele vazio — e EXEMPLO ilustrativo, alem do rotulo | `estatica.campo_operavel_tem_impacto_e_exemplo` | aqui | `analise-estatica/build` |
| Exemplo de campo nunca e valor real de terceiro nem valor que funciona colado: segredo nao tem exemplo de valor, e identificador de fornecedor sai na forma declarada pelo proprio pacote | `estatica.campo_operavel_tem_impacto_e_exemplo` | aqui | `analise-estatica/build` |
| Nome de evento e de parametro de comportamento declarados num lugar so, sem literal no cliente | `tracking.eventos_de_comportamento_declarados` | aqui | `analise-estatica/build` |
| Número em documento entregável é GERADO por leitura de disco no empacotamento, nunca digitado, e o que não pode ser gerado sai como pendência nomeada | `estatica.carimbo_de_release_nos_documentos` | aqui | `analise-estatica/build` |
| A identidade no cabeçalho de README, MANIFESTO e MEMORIA-DECISOES bate com release.identidade, e documento entregável sem região gerada é achado | `estatica.carimbo_de_release_nos_documentos` | aqui | `analise-estatica/build` |
| Chave de configuracao REMOVIDA nao deixa residuo em configuracao, schema, codigo nem documento, fora dos arquivos onde a remocao e narrada | `estatica.sem_residuo_de_chave_removida` | aqui | `analise-estatica/build` |
| A tela fala portugues comum: nenhuma frase destinada a ela carrega vocabulario interno nem vira paragrafo | `tela.fala_portugues_comum` | aqui | `analise-estatica/build` |
| A mensagem do WhatsApp nao leva codigo de referencia e o link abre em aba nova; a correlacao do contato e por data e hora | `contato.whatsapp_sem_codigo` | aqui | `teste-funcional/build` |
| O plugin diz ao agente MCP como usa-lo, e a lista sai do registro de modulos | `mcp.como_usar_sai_do_registro` | aqui | `teste-funcional/build` |
| Piso declarado em sonda se sustenta: a sonda existe, menciona a checagem e traz teto e piso — declaracao nao absolve sem medir | `estatica.piso_em_sonda_declarado` | aqui | `analise-estatica/build` |
| Limite de campo do endpoint medido na MESMA unidade que o cliente corta: o numero publicado vale para os dois lados | `leads.limite_por_caractere` | aqui | `teste-funcional/build` |
| Corte do cliente de leads na unidade publicada pelo servidor, sem partir caractere ao meio | `js.limite_do_cliente` | aqui | `teste-funcional/build` |
| Sanitizar toda entrada: campo cujo sanitizador devolve vazio para entrada invalida precisa de validacao conclusiva | `leads.email_conclusivo` | aqui | `teste-funcional/build` |
| Campo booleano com parser explicito e vocabulario fechado: em urlencoded todo valor chega string, e consentimento nao se adivinha | `leads.booleano_explicito` | aqui | `teste-funcional/build` |
| Reserva de deduplicacao com commit apos persistencia e compensacao na falha: lead legitimo nao pode ficar bloqueado por reserva de tentativa que nao gravou | `leads.reserva_compensada` | aqui | `teste-funcional/build` |
| Atividade registrada so depois da persistencia, e a recusa com carimbo proprio | `leads.atividade_so_com_persistencia` | aqui | `teste-funcional/build` |
| Status HTTP reflete o que aconteceu: gravacao recusada e 5xx com o que o visitante deve fazer, nunca 201 Created com ok:false | `leads.status_da_gravacao` | aqui | `teste-funcional/build` |
| Rate limit com incremento atomico decidido pelo banco, e nao por ler-modificar-gravar sem lock | `leads.rate_limit_atomico` | aqui | `teste-funcional/build` |
| Origem do rate limit atras de proxy tratada de forma declarada: cabecalho confiavel vem da configuracao e nunca do proprio pedido | `leads.origem_declarada` | aqui | `teste-funcional/build` |
| Evento agendado tem ouvinte no componente persistente, e as recorrencias que o nucleo nao tem sao registradas em vez de degradarem em silencio | `cadencia.ouvinte_registrado` | aqui | `teste-funcional/build` |
| Cadencia do modo somente-relatorio registra ultima execucao, proxima, duracao, resultado, erro e detecta evento atrasado | `cadencia.execucao_registrada` | aqui | `teste-funcional/build` |
| Gravar nao e configurar: chave de gatilho gravada precisa ter contador que conta e dispara, ou sair da configuracao | `cadencia.contador_de_ajustes` | aqui | `teste-funcional/build` |
| Mecanismo da cadencia sai do fato medido: agendamento observado ou chave declarada fecham OK, e sem os dois fecha BLOCKED | `cadencia.mecanismo_declarado` | WordPress aplicando | `leitura-de-volta/producao` |
| Nenhum mecanismo do pacote pede ao canal MCP que recuse a escrita do agente: depois da instalacao, toda modificacao futura e feita por ele | `estatica.sem_recusa_de_escrita_do_agente` | aqui | `analise-estatica/build` |
| Sanitizador de option normaliza a chave conhecida e PRESERVA a desconhecida: chave que o agente acrescenta sobrevive a leitura | `options.chave_desconhecida_preservada` | aqui | `teste-funcional/build` |
| Cabecalho emitido e o valor GRAVADO, e nao um literal do codigo: COOP sai como esta na option e o modulo nomeia a consequencia | `seguranca.coop_do_valor_gravado` | aqui | `teste-funcional/build` |
| Valor aceito que custa alguma coisa em outro lugar sai com WARN nomeando a consequencia, e o valor continua sendo emitido | `seguranca.referrer_policy_avisa_atribuicao` | aqui | `teste-funcional/build` |
| Uma chave decide o caminho de medicao e um caminho so: com container do GTM nenhuma tag direta e emitida, para nada disparar em dobro | `tracking.caminho_unico` | aqui | `teste-funcional/build` |
| Um emissor por fornecedor, e o emissor e o site-core: a contagem de gtag/js, gtm.js, fbevents.js e insight.min.js no HTML publicado tem de ser exatamente a que o modulo emitiu, e nenhum gtag(config) pode vir de emissao que nao seja a dele | `tracking.emissor_unico` | producao | `medida/producao` |
| O discriminante entre emissao do site-core e emissao de fora e a MARCA impressa na emissao, medida nas fontes: sem ela a contagem nao separa os dois e aprova por acaso | `tracking.emissor_unico_discrimina` | aqui | `analise-estatica/build` |
| Um estado de consentimento gateia as QUATRO tags, no servidor e no navegador: na negativa nenhuma e carregada | `tracking.consentimento_gateia_tudo` | aqui | `teste-funcional/build` |
| Identificador de clique dos canais pagos chega ao lead, e o schema do endpoint continua fechado | `leads.click_ids_no_schema` | aqui | `teste-funcional/build` |
| O clique do CTA e a conversao do site e sai em todos os canais declarados, de um lugar so | `js.conversao_multicanal` | aqui | `teste-funcional/build` |
| CTA so deixa de ser publicado quando nao tem destino nenhum, e o href so e reescrito quando e do modelo | `leads.cta_preserva_destino` | aqui | `teste-funcional/build` |
| A regra de publicacao do CTA RODA no estado em que ela decide: o filtro por bloco registra mesmo com o modulo inativo, e a excecao e declarada no proprio hook | `cta.regra_de_publicacao_registrada` | aqui | `teste-funcional/build` |
| Meta Conversions API: o evento Lead de SERVIDOR sai depois da persistencia confirmada, com o MESMO event_id que o navegador manda no Pixel, e nunca segura a resposta ao visitante | `leads.capi_meta` | aqui | `teste-funcional/build` |
| Dado pessoal enviado a Meta sai em SHA-256 sobre o valor normalizado pela regra dela; falha da Meta e nomeada e nao muda o status do lead | `leads.capi_meta` | aqui | `teste-funcional/build` |
| Sem token da Conversions API nada e enviado, e a condicao sai declarada nomeando a option | `capi.envio_de_servidor` | aqui | `analise-estatica/build` |
| Verificacao de posse do dominio: cada token gravado emite a metatag correspondente no head, e slot vazio nao emite nada | `verificacao.tag_do_valor_gravado` | aqui | `teste-funcional/build` |
| Token de verificacao fora da forma esperada e preservado e avisado, nunca apagado em silencio | `verificacao.tag_do_valor_gravado` | aqui | `teste-funcional/build` |
| Sem token de verificacao gravado a condicao sai declarada nomeando as options | `verificacao.dominio_declarada` | aqui | `analise-estatica/build` |
| Conteudo demonstrativo e medido NO BANCO do site e discriminado por QUEM escreveu cada pagina marcada: recem-implantado fecha OK nomeando, sobrevivente fecha WARN nomeando so ele | `conteudo.demonstrativo_no_site` | aqui | `teste-funcional/build` |
| Um endereco, um dono: arquivo fisico vence, emissor concorrente medido vem depois, e so entao a rota do llms.txt | `seo.llms_emissor_unico` | aqui | `teste-funcional/build` |
| Conteudo em noindex fica fora dos dois arquivos de llms, e o fato tem um produtor so — o modulo de noindex | `seo.llms_noindex_respeitado` | aqui | `teste-funcional/build` |
| Endereco do sitemap MEDIDO no rodape do llms.txt, e a secao e omitida quando ninguem serve sitemap | `seo.llms_sitemap_medido` | aqui | `teste-funcional/build` |
| Descricao de cada item pela cadeia declarada, com a FONTE que respondeu nomeada | `seo.llms_descricao_fonte` | aqui | `teste-funcional/build` |
| Resumo de ultima instancia sem interface junto: formulario, script, estilo, navegacao, botao e SVG saem com o conteudo | `seo.llms_sem_interface_no_resumo` | aqui | `teste-funcional/build` |
| Ordem do llms.txt: pagina inicial primeiro, curadoria na ordem declarada, e so entao o enumerado | `seo.llms_ordem` | aqui | `teste-funcional/build` |
| Texto integral em llms-full.txt so existe com a chave ligada: desligada, nenhum hook e nenhuma rota | `seo.llms_full_servido` | aqui | `teste-funcional/build` |
| A estrategia de carga do script de consentimento e decidida pela politica: pre-aprovado sai defer, negado por padrao sai bloqueante no cabecalho | `consentimento.estrategia_pela_politica` | aqui | `teste-funcional/build` |
| O consent default chega ao dataLayer ANTES de o gtag.js ser pedido, medido na ordem de execucao dos dois clientes reais | `js.ordem_do_consentimento` | aqui | `teste-funcional/build` |
| Todo callback declarado pelos modulos e INVOCADO pela suite, em todas as formas de requisicao, e nenhum deles lanca nem devolve valor de tipo errado | `modulos.callbacks_executam` | aqui | `teste-funcional/build` |
| Um site recem-implantado com o projeto.json intocado nao tem NENHUM modulo desligado ou degradado por decisao do pacote, e o site sem ID de fornecedor serve o coletor de comportamento e grava linha na tabela | `modulos.nascem_ativos` | aqui | `teste-funcional/build` |
| Todo emissor ligado a mais de um evento de saida de pagina tem trava de uma vez — os dois ouvintes existem de proposito e a funcao chamada pelos dois so pode trabalhar uma vez | `estatica.saida_com_trava_de_uma_vez` | aqui | `analise-estatica/build` |
| O ciclo de vida real da saida de pagina — visibilitychange e pagehide no mesmo carregamento — conta cada metrica uma vez, e o marco de profundidade sai da altura daquela pagina | `js.ciclo_de_vida_da_pagina` | aqui | `teste-funcional/build` |
| O cliente ENTREGUE roda num navegador de verdade, e nao so contra uma bancada que simula IntersectionObserver: as sequencias de ocorrencia por gatilho sao afirmadas nos dois percursos, com zero erro de pagina, zero cortada e o lote CHEGANDO ao servidor | `navegador.comportamento_real` | aqui | `teste-funcional/build` |
| A sonda de navegador acusa o defeito que a bancada nao media: a assimetria da 1.3.3 plantada no cliente entregue tem de prender em uma ocorrencia o bloco cuja razao desce sem nunca zerar | `navegador.comportamento_real` | aqui | `teste-funcional/build` |
| Ambiente sem navegador fecha N/A com a condicao declarada, e nunca OK: um ambiente sem navegador nao e um pacote aprovado | `navegador.comportamento_real` | aqui | `teste-funcional/build` |
| A profundidade de leitura e medida e exibida por PAGINA, com o numero de carregamentos daquela pagina como denominador da proporcao | `medicao.profundidade_por_pagina` | aqui | `teste-funcional/build` |
| A releitura e registrada: o visitante que sobe e desce de novo produz nova travessia, com ocorrencia e carimbo de tempo, sob teto declarado por VISITA | `js.sessao_com_releitura` | aqui | `teste-funcional/build` |
| A travessia atravessa o CARREGAMENTO: o contador de travessias vive no registro da visita, chaveado por caminho, gatilho e detalhe, e o estado armado continua sendo do carregamento — por isso o bloco que ja esta no topo da pagina seguinte e registrado em vez de engolido | `js.sessao_com_releitura` | aqui | `teste-funcional/build` |
| Os dados de comportamento sao separados por data e por visitante, com apelido sorteado de primeira parte, apagavel, e retencao propria mais curta que a do resumo | `medicao.profundidade_por_pagina` | aqui | `teste-funcional/build` |
| O registro detalhado separa visitante de visitante e visita de visita, com carimbo em milissegundos, prazo proprio mais curto que o do resumo e exclusao a pedido do proprio visitante | `medicao.registro_por_visitante` | aqui | `teste-funcional/build` |
| O carimbo de cada linha do registro e o instante do ACIONAMENTO, e nao o da chegada do lote: um lote com acionamentos separados no tempo produz carimbos separados, na ordem certa e com o espacamento dos deslocamentos em milissegundos | `medicao.carimbo_do_acionamento` | aqui | `teste-funcional/build` |
| A ordenacao da tabela bruta continua cronologica com carimbos que se repartem: dois acionamentos que caem no mesmo segundo saem na ordem real, e quem os ordena e o desempate por id | `medicao.carimbo_do_acionamento` | aqui | `teste-funcional/build` |
| A origem temporal vem do relogio do visitante e passa por guarda declarada: ausente, nao numerica, no futuro alem da tolerancia ou mais velha que a retencao do registro cai na ancora derivada do servidor, e o espacamento continua certo | `medicao.carimbo_do_acionamento` | aqui | `teste-funcional/build` |
| Lote entregue com atraso nao embaralha a ordem dentro dele: a origem viaja SELADA no lote e sobrevive a fila pendente e ao reenvio | `medicao.carimbo_do_acionamento` | aqui | `teste-funcional/build` |
| O horario da tabela bruta e mostrado com precisao suficiente para distinguir acionamentos proximos, e cada linha diz de onde veio o carimbo dela — relogio do visitante, ancora do servidor ou a hora da chegada, nas linhas gravadas antes desta versao | `medicao.carimbo_do_acionamento` | aqui | `teste-funcional/build` |
| Cada quadro do menu Medicao diz, em uma linha, de qual das duas tabelas ele vem e o que aquela tabela responde | `medicao.carimbo_do_acionamento` | aqui | `teste-funcional/build` |
| Toda estrutura que a versao nova acrescenta — tabela, coluna, option, subchave e rota — nasce sobre um site que ja rodava a anterior, e nao so em instalacao limpa | `migracao.sobre_site_existente` | aqui | `teste-funcional/build` |
| O contrato de nomes do plugin cobre toda option do catalogo, todo evento declarado e o prefixo de secao, derivados das declaracoes e nunca escritos a mao | `renomeacao.contrato_de_nomes_completo` | aqui | `teste-funcional/build` |
| Ativar o plugin num site que ja roda a pasta antiga desativa a antiga e registra o que fez, sem tocar em plugin de terceiro nem em copia inativa | `migracao.copia_anterior_desativada` | aqui | `teste-funcional/build` |
| O zip do plugin contem todo arquivo que a lista de autoload dele exige, inclusive os cinco que vem de partilhado/ | `pacote.plugin_completo_no_zip` | aqui | `teste-funcional/build` |
| O zip do plugin carrega o documento de instrucoes dele, sem numero digitado fora dos blocos gerados, e com todo modulo de includes/ descrito na prosa | `pacote.instrucoes_do_plugin_no_zip` | aqui | `teste-funcional/build` |
| O ambiente da bancada e declarado: ou o WordPress descartavel subiu e a linha diz qual nucleo e qual PHP, ou ela fecha BLOCKED com o insumo que faltou — bancada que nao montou nunca vira OK nem N/A | `bancada.ambiente` | bancada-wp | `wp-real/build` |
| Ativar o plugin a partir do zip nao escreve Notice, Warning, Deprecated nem Fatal no debug.log | `wp.ativacao_sem_aviso` | bancada-wp | `wp-real/build` |
| A home servida por um WordPress real responde 200 com o consentimento, o carregador de tags e o controle de revisao no HTML, e com os cabecalhos de seguranca do modulo | `wp.home_servida` | bancada-wp | `wp-real/build` |
| As tres habilidades do plugin existem no registro do nucleo real e como-usar executa devolvendo o slug do plugin | `wp.habilidades_registradas` | bancada-wp | `wp-real/build` |
| As duas habilidades de configuracao executam de ponta a ponta no nucleo real: a entrada que o proprio schema pede atravessa a validacao do nucleo, chega ao callback e volta estruturada; sem usuario o portao recusa | `wp.habilidades_de_config_executam` | bancada-wp | `wp-real/build` |
| Lote de comportamento com eventos e metricas vazia — o que o cliente despacha em toda particao depois da primeira — responde 201 e grava o registro detalhado | `wp.lote_sem_metricas_gravado` | bancada-wp | `wp-real/build` |
| O pedido de apagamento por apelido apaga as linhas daquele apelido e nao devolve contagem: contar e um oraculo de existencia | `wp.esquecer_apaga_sem_oraculo` | bancada-wp | `wp-real/build` |
| Ligar a chave full faz /llms-full.txt responder 200 com o texto da pagina publicada, e nao derrubar o endereco | `wp.llms_full_responde` | bancada-wp | `wp-real/build` |
| Par de redirect que difere so pela barra final ou e recusado pelo sanitizador ou termina o salto: endereco publico nao gira | `wp.redirect_nao_gira` | bancada-wp | `wp-real/build` |
| A ativacao como o WordPress a executa agenda a cadencia declarada e a limpeza de retencao no mesmo processo | `wp.cron_na_ativacao` | bancada-wp | `wp-real/build` |
| O token da Conversions API gravado nao aparece no HTML da tela nem no JSON do relatorio | `wp.token_capi_mascarado` | bancada-wp | `wp-real/build` |
| A operacao normal do site — home, llms.txt, um artigo, um lote valido — nao escreve linha de PHP do plugin no debug.log | `wp.debug_log_limpo` | bancada-wp | `wp-real/build` |
| uninstall.php roda como o nucleo o roda — plugin inativo, processo novo, WP_UNINSTALL_PLUGIN definida — sem fatal, e nao deixa tabela com a marca do plugin nem as options declaradas | `wp.desinstalacao_limpa` | bancada-wp | `wp-real/build` |
| A prontidao da tabela de REGISTRO entra nas dependencias, no estado do modulo e nas duas rotas: sem ela o modulo fecha degradado e a rota responde 503, como o agregado ja fazia | `comportamento.estrutura_declarada` | sonda-site-core | `teste-funcional/build` |
| O DDL das duas tabelas nao declara largura de exibicao em coluna inteira: o dbDelta compara a definicao declarada com a devolvida pelo banco e deixa de emitir ALTER a cada chamada | `comportamento.estrutura_declarada` | sonda-site-core | `teste-funcional/build` |
| Cada campo numerico de uma entrada do corpo tem teto DECLARADO — o teto por pagina do evento para a contagem, e o teto por medida de vitais.tsv para o valor e para a soma | `comportamento.teto_por_entrada` | sonda-site-core | `teste-funcional/build` |
| O corte declarado pelo cliente e aparado no orcamento da visita: numero que o cliente nao pode ter produzido nao e corte nosso | `comportamento.teto_por_entrada` | sonda-site-core | `teste-funcional/build` |
| A tela mostra as medidas de carregamento com a explicacao e o limiar lidos da declaracao unica, e nao classifica a pagina | `medicao.quadro_de_vitais` | sonda-site-core | `teste-funcional/build` |
| A media de cada medida de carregamento soma TODA linha daquela metrica, inclusive a de soma zero, e nenhum evento de uso entra no quadro por ter detalhe com nome de sigla | `medicao.quadro_de_vitais` | sonda-site-core | `teste-funcional/build` |
| A tela nao afirma recorte que a consulta nao fez: filtro fora da forma do apelido e descartado E anunciado como descartado | `medicao.tela_declara_o_recorte` | sonda-site-core | `teste-funcional/build` |
| A tela avisa quando o periodo do painel passa do prazo do registro, e declara que o corte por dia e em UTC enquanto o horario sai no fuso do site | `medicao.tela_declara_o_recorte` | sonda-site-core | `teste-funcional/build` |
| O dia gravado nas DUAS tabelas sai da mesma ancora do lote: lote entregue depois da virada nao soma o total num dia e registra o acionamento no outro | `medicao.carimbo_do_acionamento` | sonda-site-core | `teste-funcional/build` |
| A porta da exclusao responde constante — sem contar o que apagou —, exige o token efemero vigente e usa o MESMO balde por origem da rota de entrada | `medicao.registro_por_visitante` | sonda-site-core | `teste-funcional/build` |
| Nome de evento declarado cabe na coluna que o guarda, e toda reserva de limiar escrita no cliente e igual ao numero declarado | `tracking.eventos_de_comportamento_declarados` | estatica | `analise-estatica/build` |
| O carimbo do CLIQUE viaja do navegador e fica GRAVADO no lead: e por data e hora que se casa a conversa que chegou no WhatsApp com o clique que a originou | `leads.registro_fiel_ao_recebido` | aqui | `teste-funcional/build` |
| O consentimento arquivado no lead e o ESTADO MEDIDO, num vocabulario fechado de tres valores que distingue decisao explicita de ausencia de decisao sob politica pre-aprovada | `leads.registro_fiel_ao_recebido` | aqui | `teste-funcional/build` |
| O token efemero do endpoint tem ESCOPO — rota e caminho da pagina — e vida curta declarada; a pagina servida de cache troca o token numa rota GET barata em vez de perder o lead em 403 mudo | `leads.token_com_escopo` | aqui | `teste-funcional/build` |
| A recusa por token invalido CARIMBA a atividade e degrada o modulo: 403 mudo faz um site perder lead por semanas com a tela verde | `leads.token_com_escopo` | aqui | `teste-funcional/build` |
| A listagem dos leads de contingencia continua visivel enquanto existir lead gravado nela, mesmo depois de a caixa unica entrar | `leads.contingencia_visivel` | aqui | `teste-funcional/build` |
| A leitura pela origem devolve o cabecalho COMO ELE VEIO: cabecalho repetido sai como lista, e nunca como a palavra "Array" | `origem.cabecalho_como_veio` | aqui | `teste-funcional/build` |
| Com faixa de IP de proxy declarada, o cabecalho de proxy so e lido quando a conexao vem de dentro dela; com a faixa VAZIA o cabecalho e lido como sempre foi, e o modulo AVISA nomeando o risco e o campo que o fecha | `leads.origem_declarada` | aqui | `teste-funcional/build` |
| Falha de banco na reserva de deduplicacao responde 5xx nomeado com a reserva compensada, e nunca 200 duplicado com identificador vazio | `leads.reserva_compensada` | aqui | `teste-funcional/build` |
| Todo limite publicado ao navegador e aplicado pelo servidor, e o limite do sub-objeto de atribuicao e a quantidade de chaves que o schema aceita | `leads.limite_por_caractere` | aqui | `teste-funcional/build` |
| Cada carimbo de atividade descreve UMA execucao: o gravador substitui o carimbo da chave em vez de mesclar com o anterior | `leads.atividade_so_com_persistencia` | aqui | `teste-funcional/build` |
| O evento de SERVIDOR da Meta so e agendado sob o MESMO portao de consentimento do navegador | `leads.capi_meta` | aqui | `teste-funcional/build` |
| O carregador de tags e servido SEMPRE que ha destino e o portao do consentimento mora no cliente: HTML que depende de cookie e congelado pelo cache de pagina | `tracking.consentimento_gateia_tudo` | aqui | `teste-funcional/build` |
| O cliente do CTA declara dependencia do script de consentimento: sem a ordem declarada, o portao dele consulta um objeto que pode ainda nao existir | `tracking.consentimento_gateia_tudo` | aqui | `teste-funcional/build` |
| O clique produz UM push por evento e no caminho do container nenhuma tag direta e emitida | `js.conversao_multicanal` | aqui | `teste-funcional/build` |
| A atribuicao guardada e os cookies de fornecedor ficam atras do portao do consentimento, e a recusa apaga o que ja estava guardado | `js.conversao_multicanal` | aqui | `teste-funcional/build` |
| O retorno do sendBeacon e lido: recusada a fila, o registro sai pelo fetch com keepalive | `js.conversao_multicanal` | aqui | `teste-funcional/build` |
| A correlacao do clique e estavel dentro da janela declarada pelo servidor, e a pagina em cache troca o token vencido e reenvia uma vez | `js.conversao_multicanal` | aqui | `teste-funcional/build` |
| Pagina publicada COM SENHA fica fora do llms.txt e do llms-full.txt: publish inclui o conteudo protegido, e o arquivo publicaria o corpo dele em texto puro | `wp.llms_nao_publica_protegido` | bancada-wp | `wp-real/build` |
| Par de redirect declarado com status 410 TERMINA a requisicao com corpo minimo, sem carregar o template do site sob o status de removida | `wp.redirect_410_termina` | bancada-wp | `wp-real/build` |
| Com a lixeira do WordPress desligada, o regime operacional da rota e a rotina diaria PROSSEGUEM apagando em definitivo e DIZEM isso: resposta 200 com reversivel false e sem reversivel_ate, entrada de journal com a janela zerada e o motivo, e o modulo ativo nomeando EMPTY_TRASH_DAYS — o prazo prometido pela politica continua sendo cumprido | `wp.retencao_sem_lixeira` | bancada-wp | `wp-real/build` |
| A eliminacao definitiva em lote da rotina de retencao deixa entrada no journal, com contagem e reversivel_ate zerado | `wp.retencao_definitiva_no_journal` | bancada-wp | `wp-real/build` |
| O lote diario da retencao registra quantos vencidos ficaram para tras e o modulo degrada enquanto houver fila | `wp.retencao_declara_o_backlog` | bancada-wp | `wp-real/build` |
| Exportador e eraser do nucleo paginam honrando a pagina pedida e so devolvem done no fim: titular com mais registros que o lote nao recebe resposta truncada | `wp.privacidade_pagina_o_titular` | bancada-wp | `wp-real/build` |
| Emissor concorrente do llms.txt e sitemap do plugin de SEO sao medidos CRUZANDO a chave gravada com a lista de plugins ativos: option sobrevive a desativacao | `seo.llms_emissor_cruza_plugin` | aqui | `teste-funcional/build` |
| A primeira frase do llms.txt e a que a tela promete: introducao primeiro, apresentacao quando ela esta vazia, descricao do WordPress quando as duas estao | `seo.llms_primeira_frase_declarada` | aqui | `teste-funcional/build` |
| Cada uma das duas rotas publicas do llms.txt tem carimbo de atividade proprio e diz no cabecalho quem respondeu | `seo.llms_carimbo_por_rota` | aqui | `teste-funcional/build` |
| O FAQPage so e lido em requisicao singular: o id consultado num arquivo de termo ou de autor colide com id de post | `schema.faq_so_no_singular` | aqui | `teste-funcional/build` |
| sameAs e a UNIAO do que o plugin de SEO ja emitia com o que a configuracao declara; as demais propriedades so gravam chave ausente | `schema.same_as_une` | aqui | `teste-funcional/build` |
| A emissao de cabecalho nao substitui a de outro emissor: a CSP compoe e os demais so saem quando ausentes, com o que foi cedido nomeado no estado | `seguranca.cabecalho_cede_a_quem_chegou_antes` | aqui | `teste-funcional/build` |
| csp_frame_ancestors e validado na FORMA antes de virar cabecalho: ponto e virgula escreve uma diretiva nova pelo campo da moldura | `seguranca.frame_ancestors_na_forma` | aqui | `teste-funcional/build` |
| Os cabecalhos de resposta alcancam a API REST, com o recorte que faz sentido em JSON declarado | `seguranca.cabecalhos_alcancam_rest` | aqui | `teste-funcional/build` |
| O vocabulario governa as chaves de cabecalho que o runtime de fato reconhece, e todo valor que ele aceita passa na forma que o modulo exige | `vocabulario.cabecalhos_governados` | aqui | `teste-funcional/build` |
| O prazo de retencao em MESES e contado em calendario, e a frase de estado diz a data de corte | `retencao.corte_em_calendario` | aqui | `teste-funcional/build` |
| O laco de desagendamento tem teto declarado e confere o retorno de wp_unschedule_event | `retencao.desagendamento_com_teto` | aqui | `analise-estatica/build` |
| O par de redirect cuja origem e destino normalizam igual e recusado na hora de servir e sai nomeado no estado | `redirects.par_que_gira_recusado` | aqui | `teste-funcional/build` |
| As quatro classes partilhadas vem guardadas por class_exists e o docblock de cada uma diz onde ela mora e o que ela usa | `partilhado.contrato_declarado` | aqui | `analise-estatica/build` |
| O comentario de tradução da frase de estado da cadencia descreve o argumento que a frase recebe, na ordem | `cadencia.frase_nomeia_o_evento` | aqui | `teste-funcional/build` |
| A previsao da proxima execucao so e gravada quando o agendamento deu certo | `cadencia.previsao_so_com_evento` | aqui | `teste-funcional/build` |
| Todo sanitizador de grupo avisa por CAMPO o que a normalizacao mudou, e o valor cuja normalizacao significaria o contrario do pedido e RECUSADO com o valor anterior de pe | `options.normalizacao_avisa` | aqui | `teste-funcional/build` |
| Sanitizar duas vezes da o mesmo que sanitizar uma, para toda option do catalogo | `options.sanitizador_idempotente` | aqui | `teste-funcional/build` |
| A procedencia so e registrada em gravacao de CONFIGURACAO, sem autoload, e preserva as chaves que o implantador gravou quando o valor nao mudou | `options.proveniencia_de_configuracao` | aqui | `teste-funcional/build` |
| O journal e a auditoria do canal tem teto declarado, o corte acontece na ESCRITA e a entrada de corte diz quantas sairam e desde quando | `options.journal_corta_na_escrita` | aqui | `teste-funcional/build` |
| As tres habilidades declaram a categoria propria do plugin, registrada no gancho de categorias do nucleo | `wp.habilidades_registradas` | bancada-wp | `wp-real/build` |
| Toda option citada no manual que o agente le existe no catalogo do plugin | `mcp.options_citadas_existem` | aqui | `analise-estatica/build` |
| Toda afirmacao de comportamento declarada no documento que viaja dentro do zip do plugin continua escrita nele e o pacote mede o que ela promete | `doc.afirmacao_conferida` | aqui | `analise-estatica/build` |
| A afirmacao que fala do que roda no NAVEGADOR e do que e declarado em TSV tambem tem elo: a regra nao mede so PHP | `doc.afirmacao_conferida` | aqui | `analise-estatica/build` |
| Nenhum numero digitado a mao fora das regioes geradas dos quatro documentos entregaveis: README, MANIFESTO, MEMORIA-DECISOES e o documento que viaja dentro do zip | `doc.numero_digitado` | aqui | `analise-estatica/build` |
| O indice de cada decisao da memoria e a POSICAO dela, a nota de superacao aponta para uma decisao que existe, e toda secao do bloco transcrito declara a origem | `doc.numero_digitado` | aqui | `analise-estatica/build` |
| Duas montagens sobre a MESMA arvore dao o mesmo sha256: o carimbo de cada entrada do zip e a epoca declarada e a ordem das entradas e a declarada, nunca a do sistema de arquivos | `pacote.zip_reprodutivel` | aqui | `teste-funcional/build` |
| Famílias únicas, classes fechadas e marcas específicas primeiro | `estatica.robos_conhecidos_ordenados` | aqui | `analise-estatica/build` |
| Evolução: acessos somados | `wp.acessos_somados` | bancada-wp | `wp-real/build` |
| Evolução: acessos dia substituido | `wp.acessos_dia_substituido` | bancada-wp | `wp-real/build` |
| Evolução: acessos sem log degradado | `wp.acessos_sem_log_degradado` | bancada-wp | `wp-real/build` |
| Evolução: acessos formato desconhecido | `wp.acessos_formato_desconhecido` | bancada-wp | `wp-real/build` |
| Evolução: acessos limites | `wp.acessos_limites` | bancada-wp | `wp-real/build` |
| Evolução: acessos atualizacao sem reativar | `wp.acessos_atualizacao_sem_reativar` | bancada-wp | `wp-real/build` |
| Evolução: acessos lidos pela habilidade | `wp.acessos_lidos_pela_habilidade` | bancada-wp | `wp-real/build` |
| Evolução: tela acessos por pagina | `wp.tela_acessos_por_pagina` | bancada-wp | `wp-real/build` |
| Evolução: sessao dura o declarado | `wp.sessao_dura_o_declarado` | bancada-wp | `wp-real/build` |
| Evolução: sessao diz quem venceu | `wp.sessao_diz_quem_venceu` | bancada-wp | `wp-real/build` |
| Evolução: llms indice aponta texto integral | `wp.llms_indice_aponta_texto_integral` | bancada-wp | `wp-real/build` |
| Configuração acessível sem implantador e sem Flamingo | `wp.configuracao_independente` | bancada-wp | `wp-real/build` |
| Diretório de log sem alias www e migração do padrão salvo | `wp.log_sem_www` | bancada-wp | `wp-real/build` |
| Logs resolvidos sem HOME ou POSIX, com ambiguidade recusada | `wp.home_generico` | bancada-wp | `wp-real/build` |
| Hoje parcial sem persistência, filtros e ranking combinados | `wp.acessos_atuais` | bancada-wp | `wp-real/build` |
| Coleta diária executada somente sobre logs datados anteriores | `wp.acessos_cron_diario` | bancada-wp | `wp-real/build` |
| Índice Markdown válido e seleção pública segura também na curadoria | `wp.publicacao_llms` | bancada-wp | `wp-real/build` |
| Alternativas Markdown e descoberta com exclusões e HTTP corretos | `wp.publicacao_markdown` | bancada-wp | `wp-real/build` |
| Robots virtual com sitemap real e preservação de regras e arquivos físicos | `wp.publicacao_robots` | bancada-wp | `wp-real/build` |
| Troca do robots físico pelo formulário e restauração exata sem sobrescrever terceiros | `wp.robots_troca` | bancada-wp | `wp-real/build` |
| Falhas e interrupções da troca preservam original e backup | `wp.robots_falhas` | bancada-wp | `wp-real/build` |
| Concorrência, desativação e reativação preservam o ciclo do robots | `wp.robots_ciclo` | bancada-wp | `wp-real/build` |
| Full preserva conteúdo integral e estrutura com as regras públicas do índice | `wp.llms_full_estruturado` | bancada-wp | `wp-real/build` |
| Entrega HTTP confirma rota virtual ou arquivo gerenciado com filtros tardios e restauração exata | `wp.robots_entrega` | bancada-wp | `wp-real/build` |
| Falhas de entrega, jobs antigos e publicações interrompidas preservam arquivos e diagnóstico | `wp.robots_entrega_falhas` | bancada-wp | `wp-real/build` |
<!-- gerado:fim=requisitos -->

<!-- gerado:inicio=fixtures -->
### Piso: as três formas, e o que cada uma prova

Gerado de disco e das tabelas declaradas. Um detector sem piso é uma afirmação sobre a intenção de quem
o escreveu: enquanto ninguém o viu acusar o defeito que ele existe para acusar, ele pode estar cego.

**Piso em disco — um detector, duas árvores.** A NEGATIVA reproduz o defeito e precisa ser acusada; a
POSITIVA preserva o caso correto e precisa ficar em silêncio.

| Detector | Arquivos de piso |
|---|---|
| `doc.afirmacao_conferida` | 8 |
| `doc.numero_digitado` | 22 |
| `estatica.campo_operavel_tem_impacto_e_exemplo` | 4 |
| `estatica.carimbo_de_release_nos_documentos` | 22 |
| `estatica.contagem_com_nomes` | 4 |
| `estatica.detector_codigo_em_string` | 2 |
| `estatica.detector_condicao_literal` | 2 |
| `estatica.detector_escrita_unica` | 5 |
| `estatica.detector_version_compare` | 2 |
| `estatica.estados_fechados` | 2 |
| `estatica.hidden_governa_visibilidade` | 4 |
| `estatica.js_lint` | 2 |
| `estatica.json_valido` | 2 |
| `estatica.php_lint` | 2 |
| `estatica.piso_em_sonda_declarado` | 5 |
| `estatica.robos_conhecidos_ordenados` | 2 |
| `estatica.saida_com_trava_de_uma_vez` | 2 |
| `estatica.sem_recusa_de_escrita_do_agente` | 2 |
| `estatica.sem_residuo_de_chave_removida` | 10 |
| `estatica.simbolos_resolvem` | 2 |
| `estatica.warn_tem_ramo_adverso` | 2 |
| `mcp.options_citadas_existem` | 4 |
| `pacote.allow_list` | 5 |
| `pacote.build_fresco` | 4 |
| `pacote.js_entregue_sem_comentario` | 6 |
| `tela.fala_portugues_comum` | 2 |
| `tracking.emissor_unico_discrimina` | 8 |
| `tracking.eventos_de_comportamento_declarados` | 8 |

**Piso da bancada WordPress — um passo, dois plugins instalados.** O caso negativo não é uma árvore
de arquivos: é o plugin com o defeito dentro, montado a partir do patch, num WordPress que sobe e
responde. `situação` diz se os DOIS ramos fecham hoje.

| Passo | Mutante | Situação |
|---|---|---|
| `wp.ativacao_sem_aviso` | `mutantes/ativacao_sem_aviso.patch` | coberto |
| `wp.home_servida` | `mutantes/home_servida.patch` | coberto |
| `wp.habilidades_registradas` | `mutantes/habilidades_registradas.patch,mutantes/habilidades_sem_categoria.patch` | coberto |
| `wp.habilidades_de_config_executam` | `mutantes/habilidades_de_config_executam.patch` | coberto |
| `wp.lote_sem_metricas_gravado` | `mutantes/lote_sem_metricas_gravado.patch` | coberto |
| `wp.esquecer_apaga_sem_oraculo` | `mutantes/esquecer_apaga_sem_oraculo.patch` | coberto |
| `wp.llms_full_responde` | `mutantes/llms_full_responde.patch` | coberto |
| `wp.redirect_nao_gira` | `mutantes/redirect_nao_gira.patch` | coberto |
| `wp.cron_na_ativacao` | `mutantes/cron_na_ativacao.patch` | coberto |
| `wp.llms_nao_publica_protegido` | `mutantes/llms_nao_publica_protegido.patch` | coberto |
| `wp.redirect_410_termina` | `mutantes/redirect_410_termina.patch` | coberto |
| `wp.token_capi_mascarado` | `mutantes/token_capi_mascarado.patch` | coberto |
| `wp.retencao_sem_lixeira` | `mutantes/retencao_sem_lixeira.patch,mutantes/retencao_sem_lixeira_recusa.patch` | coberto |
| `wp.retencao_definitiva_no_journal` | `mutantes/retencao_definitiva_no_journal.patch` | coberto |
| `wp.retencao_declara_o_backlog` | `mutantes/retencao_declara_o_backlog.patch` | coberto |
| `wp.privacidade_pagina_o_titular` | `mutantes/privacidade_pagina_o_titular.patch` | coberto |
| `wp.acessos_somados` | `mutantes/acessos_somados_exclusao.patch,mutantes/acessos_somados_headless.patch,mutantes/acessos_somados_ordem.patch` | coberto |
| `wp.acessos_dia_substituido` | `mutantes/acessos_dia_substituido_duplicado.patch,mutantes/acessos_dia_substituido_sem_substituir.patch` | coberto |
| `wp.acessos_sem_log_degradado` | `mutantes/acessos_sem_log_degradado_vazio_ativo.patch` | coberto |
| `wp.acessos_formato_desconhecido` | `mutantes/acessos_formato_desconhecido_formato.patch` | coberto |
| `wp.acessos_limites` | `mutantes/acessos_limites_teto.patch,mutantes/acessos_limites_rollback.patch,mutantes/acessos_limites_dominios.patch,mutantes/acessos_limites_retencao.patch` | coberto |
| `wp.acessos_atualizacao_sem_reativar` | `mutantes/acessos_atualizacao_sem_reativar_atualizacao.patch` | coberto |
| `wp.acessos_lidos_pela_habilidade` | `mutantes/acessos_lidos_pela_habilidade_permissao.patch,mutantes/acessos_lidos_pela_habilidade_schema.patch` | coberto |
| `wp.tela_acessos_por_pagina` | `mutantes/tela_acessos_por_pagina_frase.patch,mutantes/tela_acessos_por_pagina_rodape.patch` | coberto |
| `wp.sessao_dura_o_declarado` | `mutantes/sessao_dura_o_declarado_rememberme.patch,mutantes/sessao_dura_o_declarado_prazo.patch` | coberto |
| `wp.sessao_diz_quem_venceu` | `mutantes/sessao_diz_quem_venceu_efetivo.patch,mutantes/sessao_diz_quem_venceu_remedio.patch` | coberto |
| `wp.llms_indice_aponta_texto_integral` | `mutantes/llms_indice_aponta_texto_integral_optional.patch,mutantes/llms_indice_aponta_texto_integral_endereco.patch` | coberto |
| `wp.configuracao_independente` | `mutantes/configuracao_independente.patch` | coberto |
| `wp.log_sem_www` | `mutantes/log_sem_www_padrao.patch,mutantes/log_sem_www_migracao.patch` | coberto |
| `wp.home_generico` | `mutantes/home_generico_ascendentes.patch,mutantes/home_generico_ambiguidade.patch` | coberto |
| `wp.acessos_atuais` | `mutantes/acessos_atuais.patch` | coberto |
| `wp.acessos_cron_diario` | `mutantes/acessos_cron_diario.patch` | coberto |
| `wp.publicacao_llms` | `mutantes/publicacao_llms.patch` | coberto |
| `wp.publicacao_markdown` | `mutantes/publicacao_markdown.patch` | coberto |
| `wp.publicacao_robots` | `mutantes/publicacao_robots.patch` | coberto |
| `wp.robots_entrega` | `mutantes/robots_entrega_sitemap.patch,mutantes/robots_entrega_fallback.patch,mutantes/robots_entrega_diagnostico.patch` | coberto |
| `wp.robots_entrega_falhas` | `mutantes/robots_entrega_ciclo_antigo.patch` | coberto |
| `wp.robots_troca` | `mutantes/robots_troca.patch` | coberto |
| `wp.robots_falhas` | `mutantes/robots_falhas.patch` | coberto |
| `wp.robots_ciclo` | `mutantes/robots_ciclo.patch` | coberto |
| `wp.llms_full_estruturado` | `mutantes/llms_full_estruturado.patch` | coberto |
| `wp.debug_log_limpo` | `mutantes/debug_log_limpo.patch` | coberto |
| `wp.desinstalacao_limpa` | `mutantes/desinstalacao_limpa.patch` | coberto |

**Piso em sonda — o caso negativo mora dentro da própria sonda.** A declaração não absolve: ela só
vale quando a sonda declarada existe, menciona a checagem e traz os dois ramos escritos, e quem
confere isso é `estatica.piso_em_sonda_declarado`, que tem piso em disco como qualquer detector.

| Checagem | Sonda que carrega o piso |
|---|---|
| `leads.limite_por_caractere` | `suite/lib/sonda-site-core.php` |
| `leads.email_conclusivo` | `suite/lib/sonda-site-core.php` |
| `leads.booleano_explicito` | `suite/lib/sonda-site-core.php` |
| `leads.reserva_compensada` | `suite/lib/sonda-site-core.php` |
| `leads.atividade_so_com_persistencia` | `suite/lib/sonda-site-core.php` |
| `leads.status_da_gravacao` | `suite/lib/sonda-site-core.php` |
| `leads.rate_limit_atomico` | `suite/lib/sonda-site-core.php` |
| `leads.origem_declarada` | `suite/lib/sonda-site-core.php` |
| `cadencia.ouvinte_registrado` | `suite/lib/sonda-site-core.php` |
| `cadencia.execucao_registrada` | `suite/lib/sonda-site-core.php` |
| `cadencia.contador_de_ajustes` | `suite/lib/sonda-site-core.php` |
| `js.limite_do_cliente` | `suite/checagens/js.mjs` |
| `js.comportamento_instrumentado` | `suite/checagens/js.mjs` |
| `cta.publicado_pela_presenca_do_numero` | `suite/lib/sonda-site-core.php` |
| `options.chave_desconhecida_preservada` | `suite/lib/sonda-site-core.php` |
| `seguranca.coop_do_valor_gravado` | `suite/lib/sonda-site-core.php` |
| `seguranca.referrer_policy_avisa_atribuicao` | `suite/lib/sonda-site-core.php` |
| `tracking.caminho_unico` | `suite/lib/sonda-site-core.php` |
| `tracking.consentimento_gateia_tudo` | `suite/lib/sonda-site-core.php` |
| `leads.click_ids_no_schema` | `suite/lib/sonda-site-core.php` |
| `leads.cta_preserva_destino` | `suite/lib/sonda-tema.php` |
| `js.conversao_multicanal` | `suite/checagens/js.mjs` |
| `cta.regra_de_publicacao_registrada` | `suite/lib/sonda-site-core.php` |
| `leads.capi_meta` | `suite/lib/sonda-site-core.php` |
| `verificacao.tag_do_valor_gravado` | `suite/lib/sonda-site-core.php` |
| `conteudo.demonstrativo_no_site` | `suite/lib/sonda-site-core.php` |
| `seo.llms_emissor_unico` | `suite/lib/sonda-site-core.php` |
| `seo.llms_noindex_respeitado` | `suite/lib/sonda-site-core.php` |
| `seo.llms_sitemap_medido` | `suite/lib/sonda-site-core.php` |
| `seo.llms_descricao_fonte` | `suite/lib/sonda-site-core.php` |
| `seo.llms_sem_interface_no_resumo` | `suite/lib/sonda-site-core.php` |
| `seo.llms_ordem` | `suite/lib/sonda-site-core.php` |
| `seo.llms_full_servido` | `suite/lib/sonda-site-core.php` |
| `comportamento.resumo_agregado` | `suite/lib/sonda-site-core.php` |
| `comportamento.lote_idempotente` | `suite/lib/sonda-site-core.php` |
| `tela.campo_diz_impacto_e_exemplo` | `suite/lib/sonda-site-core.php` |
| `medicao.menu_proprio` | `suite/lib/sonda-site-core.php` |
| `js.resumo_da_sessao` | `suite/checagens/js.mjs` |
| `consentimento.estrategia_pela_politica` | `suite/lib/sonda-site-core.php` |
| `js.ordem_do_consentimento` | `suite/checagens/js.mjs` |
| `contato.whatsapp_sem_codigo` | `suite/lib/sonda-funcional.php` |
| `mcp.como_usar_sai_do_registro` | `suite/lib/sonda-funcional.php` |
| `modulos.callbacks_executam` | `suite/lib/sonda-site-core.php` |
| `modulos.nascem_ativos` | `suite/lib/sonda-site-core.php` |
| `js.ciclo_de_vida_da_pagina` | `suite/checagens/js.mjs` |
| `medicao.profundidade_por_pagina` | `suite/lib/sonda-site-core.php` |
| `js.sessao_com_releitura` | `suite/checagens/js.mjs` |
| `medicao.registro_por_visitante` | `suite/lib/sonda-site-core.php` |
| `medicao.carimbo_do_acionamento` | `suite/lib/sonda-site-core.php` |
| `migracao.sobre_site_existente` | `suite/lib/sonda-site-core.php` |
| `navegador.comportamento_real` | `suite/checagens/funcional.php` |
| `renomeacao.contrato_de_nomes_completo` | `suite/lib/sonda-renomeacao.php` |
| `migracao.copia_anterior_desativada` | `suite/lib/sonda-migracao.php` |
| `pacote.plugin_completo_no_zip` | `suite/lib/sonda-bundle.php` |
| `pacote.instrucoes_do_plugin_no_zip` | `suite/lib/sonda-bundle.php` |
| `comportamento.estrutura_declarada` | `suite/lib/sonda-site-core.php` |
| `comportamento.teto_por_entrada` | `suite/lib/sonda-site-core.php` |
| `medicao.quadro_de_vitais` | `suite/lib/sonda-site-core.php` |
| `medicao.tela_declara_o_recorte` | `suite/lib/sonda-site-core.php` |
| `wp.ativacao_sem_aviso` | `suite/bancada-wp/roteiro.php` |
| `wp.home_servida` | `suite/bancada-wp/roteiro.php` |
| `wp.habilidades_registradas` | `suite/bancada-wp/roteiro.php` |
| `wp.habilidades_de_config_executam` | `suite/bancada-wp/roteiro.php` |
| `wp.lote_sem_metricas_gravado` | `suite/bancada-wp/roteiro.php` |
| `wp.esquecer_apaga_sem_oraculo` | `suite/bancada-wp/roteiro.php` |
| `wp.llms_full_responde` | `suite/bancada-wp/roteiro.php` |
| `wp.redirect_nao_gira` | `suite/bancada-wp/roteiro.php` |
| `wp.cron_na_ativacao` | `suite/bancada-wp/roteiro.php` |
| `wp.token_capi_mascarado` | `suite/bancada-wp/roteiro.php` |
| `wp.debug_log_limpo` | `suite/bancada-wp/roteiro.php` |
| `wp.desinstalacao_limpa` | `suite/bancada-wp/roteiro.php` |
| `leads.registro_fiel_ao_recebido` | `suite/lib/sonda-site-core.php` |
| `leads.token_com_escopo` | `suite/lib/sonda-site-core.php` |
| `leads.contingencia_visivel` | `suite/lib/sonda-site-core.php` |
| `origem.cabecalho_como_veio` | `suite/lib/sonda-site-core.php` |
| `wp.llms_nao_publica_protegido` | `suite/bancada-wp/roteiro.php` |
| `wp.redirect_410_termina` | `suite/bancada-wp/roteiro.php` |
| `wp.retencao_sem_lixeira` | `suite/bancada-wp/roteiro.php` |
| `wp.retencao_definitiva_no_journal` | `suite/bancada-wp/roteiro.php` |
| `wp.retencao_declara_o_backlog` | `suite/bancada-wp/roteiro.php` |
| `wp.privacidade_pagina_o_titular` | `suite/bancada-wp/roteiro.php` |
| `seo.llms_emissor_cruza_plugin` | `suite/lib/sonda-site-core.php` |
| `seo.llms_primeira_frase_declarada` | `suite/lib/sonda-site-core.php` |
| `seo.llms_carimbo_por_rota` | `suite/lib/sonda-site-core.php` |
| `schema.faq_so_no_singular` | `suite/lib/sonda-site-core.php` |
| `schema.same_as_une` | `suite/lib/sonda-site-core.php` |
| `seguranca.cabecalho_cede_a_quem_chegou_antes` | `suite/lib/sonda-site-core.php` |
| `seguranca.frame_ancestors_na_forma` | `suite/lib/sonda-site-core.php` |
| `seguranca.cabecalhos_alcancam_rest` | `suite/lib/sonda-site-core.php` |
| `vocabulario.cabecalhos_governados` | `suite/lib/sonda-site-core.php` |
| `retencao.corte_em_calendario` | `suite/lib/sonda-site-core.php` |
| `retencao.desagendamento_com_teto` | `suite/lib/sonda-site-core.php` |
| `redirects.par_que_gira_recusado` | `suite/lib/sonda-site-core.php` |
| `partilhado.contrato_declarado` | `suite/lib/sonda-site-core.php` |
| `cadencia.frase_nomeia_o_evento` | `suite/lib/sonda-site-core.php` |
| `cadencia.previsao_so_com_evento` | `suite/lib/sonda-site-core.php` |
| `options.normalizacao_avisa` | `suite/lib/sonda-site-core.php` |
| `options.sanitizador_idempotente` | `suite/lib/sonda-site-core.php` |
| `options.proveniencia_de_configuracao` | `suite/lib/sonda-site-core.php` |
| `options.journal_corta_na_escrita` | `suite/lib/sonda-site-core.php` |
| `pacote.zip_reprodutivel` | `suite/lib/sonda-bundle.php` |
| `wp.acessos_somados` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_dia_substituido` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_sem_log_degradado` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_formato_desconhecido` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_limites` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_atualizacao_sem_reativar` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_lidos_pela_habilidade` | `suite/bancada-wp/roteiro.php` |
| `wp.tela_acessos_por_pagina` | `suite/bancada-wp/roteiro.php` |
| `wp.sessao_dura_o_declarado` | `suite/bancada-wp/roteiro.php` |
| `wp.sessao_diz_quem_venceu` | `suite/bancada-wp/roteiro.php` |
| `wp.llms_indice_aponta_texto_integral` | `suite/bancada-wp/roteiro.php` |
| `wp.configuracao_independente` | `suite/bancada-wp/roteiro.php` |
| `wp.log_sem_www` | `suite/bancada-wp/roteiro.php` |
| `wp.home_generico` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_atuais` | `suite/bancada-wp/roteiro.php` |
| `wp.acessos_cron_diario` | `suite/bancada-wp/roteiro.php` |
| `wp.publicacao_llms` | `suite/bancada-wp/roteiro.php` |
| `wp.publicacao_markdown` | `suite/bancada-wp/roteiro.php` |
| `wp.publicacao_robots` | `suite/bancada-wp/roteiro.php` |
| `wp.robots_troca` | `suite/bancada-wp/roteiro.php` |
| `wp.robots_falhas` | `suite/bancada-wp/roteiro.php` |
| `wp.robots_ciclo` | `suite/bancada-wp/roteiro.php` |
| `wp.llms_full_estruturado` | `suite/bancada-wp/roteiro.php` |
| `wp.robots_entrega` | `suite/bancada-wp/roteiro.php` |
| `wp.robots_entrega_falhas` | `suite/bancada-wp/roteiro.php` |
<!-- gerado:fim=fixtures -->

<!-- gerado:inicio=excluidas -->
### O que a suíte da referência media e esta NÃO mede

Gerado de `suite/excluidas.tsv`. A suíte deste repositório foi EXTRAÍDA da do implantador, e checagem
que some numa extração é indistinguível de checagem esquecida — é exatamente assim que a cobertura
encolhe sem que nada acuse. Cada linha é uma decisão declarada, e o motivo é sempre de OBJETO ou de
ESCOPO. Uma checagem daqui só volta junto com o objeto dela.

**Categoria `ambos`**

| Checagem | Por que ela não está aqui |
|---|---|
| `conteudo.guarda_de_marca` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. o censo é regra compartilhada que mora em partilhado/ (lado plugin); a guarda medida é do implantador — separável |
| `copy.contrato` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. o contrato é editorial (implantador); só a varredura de frases proibidas alcança o plugin — separável |
| `decisoes.fonte_unica` | ÂNCORA DO IMPLANTADOR: ela lê config/decisoes.tsv, o catálogo de decisões dele. |
| `estatica.artefato_do_pacote_e_lido` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. o zip medido é o do PLUGIN, mas quem é medido é o caminho de instalação do implantador; parte-plugin = só partilhado/** (4 classes + TSV) no escopo varrido, separável — as âncoras todas moram em includes/ |
| `estatica.detector_chave_sem_consumidor` | ÂNCORA DO IMPLANTADOR: ela cruza toda chave de config/site.json com quem a lê, e config/site.json é arquivo do implantador. Sem ele a checagem fecha FALHA por ausência de escopo. |
| `estatica.gate_de_fase_do_metadado` | ÂNCORA DO IMPLANTADOR: a lista de gates de fase sai de gates_de_fase(), função do runtime dele. Sem a âncora não há como saber se a lista é derivada ou literal. |
| `estatica.gate_de_fase_sem_ramo_de_falha` | ÂNCORA DO IMPLANTADOR: ela mede as DECLARAÇÕES gate=fase do runtime do implantador, e nenhuma existe nesta árvore. |
| `estatica.gate_fonte_unica` | ÂNCORA DO IMPLANTADOR: gates_do_canal() declara quais estados decidem a autodesativação, e a autodesativação é dele. |
| `estatica.llms_so_pagina_publicada` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. idem; parte-plugin = só partilhado/** (4 classes + TSV) no escopo varrido, separável — as âncoras todas moram em includes/ |
| `estatica.option_fonte_unica` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. a varredura inclui partilhado/**, que é lado-plugin; nenhuma âncora mora lá; parte-plugin = só partilhado/** (4 classes + TSV) no escopo varrido, separável — as âncoras todas moram em includes/ |
| `estatica.option_gravada_sem_leitor` | ESCOPO VAZIO por vocabulário do detector: o lado da ESCRITA dele é fechado — Gravador::gravar(...), update_option, add_option, update_site_option — e Gravador:: é o gravador do IMPLANTADOR. O gravador deste plugin é F3Base_Options::gravar(), que a MESMA função classifica como LEITURA. Apontada para a árvore do plugin ela encontra zero escrita e fecha BLOCKED. Ensinar o detector a reconhecer o gravador do plugin é MUDAR o detector, e mudar detector vem com o piso que prova a mudança: tarefa seguinte, distinta desta. |
| `estatica.pagina_status_fonte_unica` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. idem; parte-plugin = só partilhado/** (4 classes + TSV) no escopo varrido, separável — as âncoras todas moram em includes/ |
| `estatica.politica_privacidade_fonte_unica` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. idem; parte-plugin = só partilhado/** (4 classes + TSV) no escopo varrido, separável — as âncoras todas moram em includes/ |
| `estatica.precondicao_no_eixo` | ÂNCORA DO IMPLANTADOR: o eixo de convergência e o metadado precondicao moram no relatório dele. |
| `estatica.residencia_de_chave_derivada` | ÂNCORA DO IMPLANTADOR: ela deriva o arquivo em que cada chave mora a partir da constante ARQUIVO de includes/class-f3base-imp-{projeto,config}.php. |
| `estatica.resposta_de_lote_nomeada` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. idem; parte-plugin = só partilhado/** (4 classes + TSV) no escopo varrido, separável — as âncoras todas moram em includes/ |
| `estatica.segredo_fora_da_configuracao` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. a lista de segredos é do PLUGIN e o que ela proíbe é do IMPLANTADOR: no split, a âncora vai com o plugin e a regra fica no implantador (ou é duplicada apontando para o catálogo publicado) |
| `estatica.sem_residuo_de_prefixo` | A RENOMEAÇÃO DE PREFIXO É FERRAMENTA DO IMPLANTADOR (ferramentas/renomear-prefixo.php e a regra ferramentas/nomes-preservados.php), e o invariante que ela persegue é justamente que o PLUGIN não seja renomeado. Um detector de resíduo apontado para a árvore do plugin mediria a ausência de um evento que aqui não pode acontecer. |
| `estatica.troca_invalida_cache` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. idem; parte-plugin = só partilhado/** (4 classes + TSV) no escopo varrido, separável — as âncoras todas moram em includes/ |
| `estatica.unidade_reflete_internas` | ESCOPO VAZIO: ela mede a composição de estado das UNIDADES do relatório do implantador, e não há unidade nenhuma nesta árvore. Zero unidade medida fecha BLOCKED. |
| `estatica.wp_comentarios_balanceados` | ESCOPO VAZIO na árvore do plugin: a varredura mede comentário de bloco wp: em .html e .php, e os arquivos que os têm são content/** e fontes/tema/**, que ficaram no implantador. Zero unidade medida fecha BLOCKED, e o que não foi medido não pode ser aprovado. |
| `js.banner_de_consentimento` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. a visibilidade é decidida pelo CSS do TEMA e o comportamento pelo JS do PLUGIN; no repo do plugin a checagem vai junto com uma cópia declarada do CSS, ou o par (hidden, display) é publicado pelo tema como contrato |
| `pacote.backup_sempre_oculto` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. o produtor real é includes/class-f3base-imp-plugins.php::caminho_do_backup(); a varredura é do pacote todo |
| `pacote.plugin_so_como_zip` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. regra sobre o bundle do implantador; FICA NO IMPLANTADOR |
| `pacote.reserva_identica_ao_avulso` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. compara os dois artefatos; FICA NO IMPLANTADOR (é ele que embute) |
| `plugins.emissor_concorrente` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. a regra do segundo emissor mora em partilhado/** (lado plugin) e é exercitada pelo preflight do implantador — separável: partilhado/ vai com o plugin e o implantador passa a lê-la da cópia publicada |
| `renomeacao.plugin_intacto` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. a ferramenta é do implantador e o invariante é do plugin — fica no IMPLANTADOR; o plugin ganha, no máximo, a checagem espelho do contrato-de-nomes |
| `renomeacao.secao_medida_apos_renomear` | PARTE NÃO SEPARÁVEL DO PAR IMPLANTADOR/PLUGIN. fica no IMPLANTADOR pela mesma razão |

**Categoria `conteudo`**

| Checagem | Por que ela não está aqui |
|---|---|
| `config.slug_declarado` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. caminhos lidos: config/site.json (paginas[] e posts[]) |
| `conteudo.demonstrativo` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. caminhos lidos: content/**/*.html (censo da marca demonstrativa) |
| `conteudo.headings` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. caminhos lidos: content/**/*.html + fontes/tema/**/*.html |
| `conteudo.marca_demonstrativa` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. caminhos lidos: content/**/*.html |
| `conteudo.sem_estilo_avulso` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. caminhos lidos: content/**/*.html + fontes/tema/theme.json (presets) |
| `entrega.blog` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. caminhos lidos: config/site.json (posts[].slug) → content/posts/*.html |
| `entrega.conteudo` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. caminhos lidos: config/site.json (paginas[].ref, midia[].arquivo) → content/pages/*.html e assets/* |
| `estatica.conteudo_declara_secoes` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. a marca medida é consumida pelo coletor do plugin, mas nada de fontes/plugin/ é lido |
| `estatica.detector_placeholder` | O OBJETO MEDIDO É O CONTEÚDO EDITORIAL (content/**), que viaja com o implantador. escopo declarado em f3b_ck_placeholder; não toca fontes/plugin/** |

**Categoria `host`**

| Checagem | Por que ela não está aqui |
|---|---|
| `a11y.piso_da_sonda` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (páginas renderizadas a partir de fontes/tema/** e content/**) |
| `entrega.convergencia` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (eixo de convergência de includes/class-f3base-imp-lotes.php) |
| `entrega.rodada_limpa` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (suite/rodada.json + includes/class-f3base-imp-entrega.php) |
| `formulario.regime_cf7` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. N/A por condição declarada; pertenceria ao IMPLANTADOR (includes/class-f3base-imp-formulario.php cria o CF7) |
| `handoff.credenciais_rotacionadas` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. N/A por condição declarada; pertenceria ao IMPLANTADOR |
| `handoff.pacote_de_entrega` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. N/A por condição declarada; pertenceria ao IMPLANTADOR |
| `homologacao.a_para_b` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR |
| `htaccess.regras_preservadas` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. OBJETO INDETERMINADO: nenhum arquivo do pacote (nem implantador nem plugin) escreve ou lê .htaccess — a checagem não tem produtor em nenhum dos dois lados |
| `idempotencia.tres_execucoes` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (três execuções da aplicação) |
| `mcp.autoteste` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (canal MCP conferido por includes/class-f3base-imp-entrega.php / imp-plugins.php) |
| `mcp.autoteste_recusa_credencial` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (mesmo canal MCP) |
| `mcp.canal_configurado` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR |
| `mcp.canal_unico` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (censo de plugins ativos medido pela unidade mcp) |
| `menu.objeto_unico` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (includes/class-f3base-imp-navegacao.php cria o wp_navigation e grava f3base_nav_id) |
| `menu.ref_injetado_no_render` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao TEMA (fontes/tema/functions.php:194, add_filter render_block_data) |
| `orcamento.pagina` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (chave orcamento_pagina do config e preflight); a página medida é tema+plugin |
| `plugins.adaptador_leitura_de_volta` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (includes/class-f3base-imp-seo.php) |
| `plugins.autoupdate_caminho` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (includes/class-f3base-imp-plugins.php) |
| `plugins.autoupdate_conforme_politica` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR |
| `tema.ancora_sob_sticky` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao TEMA (fontes/tema/style.css) |
| `visual.inspecao_paginas` | PERTENCE AO HOST, e a evidência é produzida pela execução do implantador. pertenceria ao IMPLANTADOR (tema+conteúdo pintados) |

**Categoria `implantador`**

| Checagem | Por que ela não está aqui |
|---|---|
| `cadencia.mecanismo_do_fato_medido` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php + includes/class-f3base-imp-projeto.php |
| `cadencia.recorrencia_declarada` | O OBJETO MEDIDO É O IMPLANTADOR. mede como o IMPLANTADOR declara a recorrência; o ouvinte é do plugin e tem checagem própria |
| `config.residencia_derivada` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-residencia.php, -config.php, -projeto.php, -conteudo.php |
| `config.schema_valida` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-config.php + config/site.json + config/site.schema.json + config/decisoes.tsv |
| `conteudo.exemplo_do_wordpress` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-conteudo.php |
| `conteudo.merge_tres_vias` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-conteudo.php |
| `conteudo.nao_promocao_status` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-conteudo.php |
| `decisoes.leitor_do_pacote` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-decisoes.php + config/decisoes.tsv |
| `entrega.gates_separados` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{entrega,lotes,relatorio}.php |
| `entrega.implantador` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: implantador-base.php, config/site.json, config/site.schema.json, includes/class-f3base-imp-config.php, includes/class-f3base-imp-gravador.php |
| `entrega.memoria` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: MEMORIA-DECISOES.md |
| `entrega.readme` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: README.md |
| `entrega.rodada_limpa_confere` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-entrega.php + suite/rodada.json |
| `estatica.destino_de_formulario_resolve` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: config/projeto.json (formularios[].destino) |
| `estatica.identidade_do_implantador` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: config/site.json (release.identidade/release.implantador) + implantador-base.php (cabeçalho Version:) |
| `estatica.plano_dependencias` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-plano.php (executado em subprocesso) |
| `fases.regra_de_aplicabilidade` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-fases.php + includes/class-f3base-imp-relatorio.php |
| `formulario.existe_e_envia` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-formulario.php |
| `formulario.veredito_destino` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php, -config.php, -projeto.php + config/projeto.json |
| `gravador.leitura_de_volta_equivalente` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-gravador.php |
| `instalacao.artefato_fonte_unica` | O OBJETO MEDIDO É O IMPLANTADOR. o artefato instalado é o do plugin, mas o código medido é 100% do implantador |
| `instalacao.disco_ou_cache` | O OBJETO MEDIDO É O IMPLANTADOR. o artefato instalado é o do plugin, mas o código medido é 100% do implantador |
| `instalacao.limpa_le_de_volta` | O OBJETO MEDIDO É O IMPLANTADOR. o artefato instalado é o do plugin, mas o código medido é 100% do implantador |
| `journal.escritas_desta_execucao` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-journal.php |
| `js.decisoes_do_cliente` | O OBJETO MEDIDO É O IMPLANTADOR. idem |
| `js.extrator_resposta` | O OBJETO MEDIDO É O IMPLANTADOR. cliente da tela do IMPLANTADOR |
| `lotes.encerramento_por_estado` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php |
| `lotes.gate_de_aplicacao_sem_dado_do_operador` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{lotes,relatorio}.php |
| `lotes.gate_de_fase_nao_derruba_estado` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{lotes,relatorio}.php |
| `lotes.indexacao_consequencia` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php |
| `lotes.indexacao_veredito` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php |
| `lotes.permalinks_decisao` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{lotes,relatorio}.php |
| `lotes.redirects_uniao` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php |
| `lotes.unidade_reflete_internas` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{lotes,relatorio}.php |
| `mcp.autoteste_veredito` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-entrega.php (lido também como texto) |
| `mcp.canal_unico_mede_plugins_ativos` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-entrega.php |
| `mcp.gate_le_o_veredito_final` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{entrega,lotes,relatorio}.php |
| `options.merge_tres_vias` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{gravador,lotes}.php |
| `pacote.sem_cabecalho_de_plugin_aninhado` | O OBJETO MEDIDO É O IMPLANTADOR. NÃO lê fontes/plugin/** — o cabeçalho do plugin está a dois níveis, e é exatamente isso que a regra existe para garantir |
| `plugins.autoupdate_caminho_separado` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{plugins,preflight,entrega,decisoes}.php |
| `plugins.digesto_do_artefato` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-plugins.php |
| `plugins.https_em_todo_salto` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-plugins.php |
| `plugins.serie_de_backup_normalizada` | O OBJETO MEDIDO É O IMPLANTADOR. a série é de backups do plugin, mas o código medido é do implantador |
| `plugins.veredito_de_versao_do_site_core` | O OBJETO MEDIDO É O IMPLANTADOR. o veredito é SOBRE a versão do plugin, mas todo o código medido é do implantador |
| `preflight.artefato_do_pacote_e_baseline` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{preflight,config}.php |
| `preflight.limites_veredito` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php |
| `preflight.plugin_alheio_nao_impede` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{lotes,relatorio,config}.php |
| `privacidade.controlador_identificado` | O OBJETO MEDIDO É O IMPLANTADOR. também lê content/pages/ (o texto da política) — lado conteúdo, nunca fontes/plugin/ |
| `projeto.fato_juridico_coerente` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{projeto,decisoes}.php + config/projeto.json + config/projeto.schema.json |
| `projeto.schema_valida` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{projeto,config}.php + config/projeto.json + config/projeto.schema.json |
| `relatorio.contagem_colada_no_estado` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-relatorio.php |
| `relatorio.mudanca_desde_a_aplicacao` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-{gravador,lotes}.php |
| `relatorio.nomeia_o_que_nao_fecha_ok` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-relatorio.php |
| `relatorio.sanitiza_dump` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-relatorio.php + includes/class-f3base-imp-residencia.php |
| `relatorio.waiver_casa` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-relatorio.php |
| `release.declara_a_anterior` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: config/site.json + config/releases-suportadas.tsv |
| `release.matriz_do_catalogo` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-preflight.php + config/releases-suportadas.tsv |
| `tela.falha_diz_a_saida` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-lotes.php |
| `tema.override_por_conteudo` | O OBJETO MEDIDO É O IMPLANTADOR. caminhos lidos: includes/class-f3base-imp-preflight.php + config/site.json |

**Categoria `suite-meta`**

| Checagem | Por que ela não está aqui |
|---|---|
| `entrega.suite` | META-CHECAGEM DA SUÍTE DO IMPLANTADOR. caminhos lidos: suite/verificar.sh, suite/lib/regra.php, suite/inventario.tsv, suite/manifesto.tsv, suite/armadilhas.tsv, suite/fixtures/ |

**Categoria `tema`**

| Checagem | Por que ela não está aqui |
|---|---|
| `a11y.contraste` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. lê conteúdo também, mas o objeto medido é a paleta do tema |
| `entrega.tema` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/{style.css,theme.json,functions.php,templates/index.html,parts/header.html,parts/footer.html,patterns/} |
| `tema.landing_sem_navegacao` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/templates/landing.html, fontes/tema/parts/*.html, fontes/tema/theme.json |
| `tema.link_privacidade_preserva` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. o objeto medido é o filtro do TEMA |
| `tema.main_layout_default` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/** (templates e parts) |
| `tema.preset_inexistente` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/theme.json + fontes/tema/** |
| `tema.preset_ocioso` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/theme.json + fontes/tema/** |
| `tema.sem_cor_literal` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/** (.css/.html/.php/.svg), exceto fontes/tema/CONTRASTE.md |
| `tema.versao_assets` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/** |
| `tema.wp_html_declarado` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/** + config/site.json (tema.wp_html_excecoes) |
| `tema.zero_com_unidade` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. caminhos lidos: fontes/tema/theme.json + markup de fontes/tema/** (patterns renderizados por suite/lib/render-pattern.php) |
<!-- gerado:fim=excluidas -->
