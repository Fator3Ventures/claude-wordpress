<?php
/**
 * Sonda funcional: exercita as funções PURAS do PLUGIN, sem WordPress.
 *
 * Subprocesso por desenho — carregar classes define ABSPATH e um punhado de
 * funções do núcleo, e isso não pode vazar para o processo que imprime os
 * estados. Devolve JSON; quem imprime e conta é `estado()`.
 *
 * O QUE SOBROU AO SAIR DO IMPLANTADOR. Esta sonda media quarenta e cinco
 * checagens, e quarenta e três delas exercitavam classes de
 * `includes/class-f3base-imp-*.php` — configuração, gravador, lotes,
 * relatório, preflight, journal. Nenhuma dessas classes existe neste
 * repositório, e nenhuma delas media o plugin: elas mediam o implantador. As
 * duas que ficaram leem `fontes/plugin/` e mais nada — o script de leads e o
 * manual que o agente MCP lê —, e é por isso que o preâmbulo encolheu junto:
 * sem classe do implantador para carregar, não há núcleo de mentira para
 * montar.
 *
 * Cada bloco tem TETO (o caso correto continua em silêncio) e PISO (o mutante
 * precisa reprovar) na mesma sonda.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( $argv[1] ?? '', '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'erro' => 'raiz inexistente' ) );
	exit( 2 );
}

$resultado = array();

/**
 * Acumula um achado.
 *
 * @param string $checagem Nome.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]             = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Registra uma medida (aprovando ou não).
 *
 * @param string $checagem Nome.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Contém, sem depender de caixa.
 *
 * O texto do relatório grifa em MAIÚSCULA o que precisa saltar aos olhos, e
 * uma sonda presa à caixa reprovaria a ênfase em vez do conteúdo.
 *
 * @param string $palheiro Texto medido.
 * @param string $agulha   Trecho exigido ou proibido.
 * @return bool

/* ---------- contato.whatsapp_sem_codigo: a mensagem é só a mensagem ---------- */

/*
 * A mensagem pré-preenchida do `wa.me` não leva código de referência, id de
 * sessão nem parâmetro de rastreio: quem recebe leria um identificador que não
 * significa nada para ela. A correlação entre o clique e a conversa é feita por
 * DATA E HORA, fora do site, e é por isso que o registro do clique carrega o
 * carimbo de tempo.
 */
$nome = 'contato.whatsapp_sem_codigo';

$js_dos_leads = (string) file_get_contents( $raiz . '/fontes/plugin/assets/f3base-leads.js' );

medir( $nome );

if ( 1 === preg_match( '/\[ref[:\s]/', $js_dos_leads ) ) {
	anotar( $nome, 'piso: a mensagem do wa.me voltou a carregar um código de referência' );
}

medir( $nome );

if ( ! str_contains( $js_dos_leads, "setAttribute('target', '_blank')" ) ) {
	anotar( $nome, 'teto: o link do WhatsApp não abre em aba nova — a conversa acontece fora do site e levar a aba faz o visitante perder a página' );
}

medir( $nome );

if ( ! str_contains( $js_dos_leads, "carga.clicado_em = new Date().toISOString();" ) || ! str_contains( $js_dos_leads, 'carga.clicado_em_ms = Date.now();' ) ) {
	anotar( $nome, 'teto: o clique não registra o carimbo de tempo — sem ele não há como casar a conversa que chegou com o clique que a originou' );
}

$php_do_cta = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-leads-whatsapp.php' );

medir( $nome );

if ( ! str_contains( $php_do_cta, "set_attribute( 'target', '_blank' )" ) || ! str_contains( $php_do_cta, "set_attribute( 'rel', 'noopener' )" ) ) {
	anotar( $nome, 'teto: o link reescrito no servidor não sai com target e rel — sem JavaScript o comportamento seria outro' );
}

medir( $nome );

/*
 * A URL do `wa.me` leva a MENSAGEM e nada mais. Os dois lados montam a URL — o
 * servidor reescreve o link no HTML e o script o remonta no clique —, e a
 * medição é sobre a fonte dos dois: qualquer segundo parâmetro ali é um
 * identificador viajando para fora do site dentro de um endereço que a pessoa
 * vê.
 */
if ( 1 === preg_match( "/add_query_arg\(\s*'(?!text')/", $php_do_cta ) ) {
	anotar( $nome, 'piso: o servidor acrescenta à URL do wa.me um parâmetro que não é a mensagem' );
}

medir( $nome );

if ( 1 === preg_match( "/wa\.me[^;]*'&/", $js_dos_leads ) ) {
	anotar( $nome, 'piso: o script acrescenta um segundo parâmetro à URL do wa.me — só a mensagem viaja nela' );
}

/* ---------- mcp.como_usar_sai_do_registro: o manual não é texto à mão ---------- */

/*
 * O manual que o agente lê precisa vir do REGISTRO de módulos. Digitado à mão,
 * ele envelhece na primeira vez que alguém acrescenta um módulo e esquece de
 * atualizá-lo — e manual desatualizado é pior que manual nenhum, porque o
 * agente confia nele e resolve por fora o que o plugin já fazia.
 *
 * TETO: a lista de assuntos vem do registro e traz, por módulo, o que ele faz e
 * as options que o controlam.
 * PISO: nenhum nome de módulo escrito à mão no manual, e a lista do "não faça"
 * nomeia o caminho paralelo E o preço dele — proibição sem motivo é ignorada
 * pelo primeiro que tiver pressa.
 */
$nome = 'mcp.como_usar_sai_do_registro';

$fonte_do_manual = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-como-usar.php' );

medir( $nome );

if ( ! str_contains( $fonte_do_manual, 'F3Base_Registro::modulos()' ) ) {
	anotar( $nome, 'teto: a lista de assuntos NAO sai do registro de modulos — manual digitado envelhece no primeiro modulo novo, e o agente confia nele' );
}

medir( $nome );

foreach ( array( "'assunto'", "'options'", "'estado'", "'faz'" ) as $campo_do_manual ) {
	if ( ! str_contains( $fonte_do_manual, $campo_do_manual ) ) {
		anotar( $nome, 'teto: o assunto nao traz o campo ' . $campo_do_manual . ' — sem ele o agente sabe que o plugin faz algo e nao sabe por onde mudar' );
	}
}

$classes_do_registro = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-registro.php' );

preg_match_all( "/'(F3Base_Modulo_[A-Za-z_]+)'/", $classes_do_registro, $achadas_no_registro );

medir( $nome );

foreach ( array_unique( $achadas_no_registro[1] ) as $classe_de_modulo ) {
	if ( str_contains( $fonte_do_manual, $classe_de_modulo ) ) {
		anotar( $nome, 'piso: o manual nomeia o modulo ' . $classe_de_modulo . ' como literal — a lista passou a ser mantida em dois lugares, e o segundo e o que vai ficar para tras' );
	}
}

medir( $nome );

if ( ! str_contains( $fonte_do_manual, "'porque'" ) || ! str_contains( $fonte_do_manual, "'faca'" ) ) {
	anotar( $nome, 'piso: a lista do que NAO fazer nao traz o motivo e a saida — proibicao sem motivo e ignorada pelo primeiro que tiver pressa, e sem a saida o agente resolve por onde conhece' );
}

medir( $nome );

/*
 * A GRAFIA EXATA DO GANCHO, e a medida anterior era `str_contains( $fonte,
 * 'abilities_api_init' )` — que a grafia ERRADA satisfaz, porque ela CONTÉM a
 * substring. O gancho do núcleo é `wp_abilities_api_init`; sem o prefixo `wp_`
 * o `add_action` nunca é chamado, não falha, não avisa, e as três habilidades
 * simplesmente não existem — foi o que a bancada WordPress real mediu. Uma
 * checagem cuja forma de acusar o defeito é satisfeita PELO defeito não acusa
 * nada, e era esse o caso.
 *
 * TETO: o `add_action` traz a grafia com o prefixo.
 * PISO: a grafia SEM prefixo, isolada — não como sufixo da certa —, é acusada.
 */
$fonte_do_plugin_core = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-plugin.php' );

if ( 1 !== preg_match( "/add_action\(\s*'wp_abilities_api_init'/", $fonte_do_plugin_core ) ) {
	anotar( $nome, "teto: a habilidade nao e registrada em add_action( 'wp_abilities_api_init' ) — o gancho do nucleo tem o prefixo wp_, e um add_action num gancho que ninguem dispara nao falha, nao avisa e nao registra nada" );
}

medir( $nome );

if ( 1 === preg_match( "/add_action\(\s*'abilities_api_init'/", $fonte_do_plugin_core ) ) {
	anotar( $nome, "piso: o gancho SEM o prefixo wp_ voltou a ser usado — essa grafia nao existe no nucleo, e as tres habilidades desaparecem do registro sem erro nenhum" );
}

medir( $nome );

if ( 1 !== preg_match( "/add_action\(\s*'wp_abilities_api_categories_init'/", $fonte_do_plugin_core ) ) {
	anotar( $nome, "piso: a categoria propria nao e registrada em wp_abilities_api_categories_init — o nucleo recusa habilidade cuja category nao esteja registrada, e a janela para registra-la e esse gancho, que dispara antes" );
}

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
