<?php
/**
 * Runner do comando único.
 *
 * Ordem fixa: empacotar primeiro, checar depois, resumir por último. O código de
 * saída vem da contagem que `estado()` acumulou — não de uma variável local que
 * alguém possa esquecer de atualizar.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$suite = dirname( __DIR__ );
$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );

require $suite . '/lib/regra.php';
require $suite . '/lib/empacotar.php';

foreach ( array( 'estatica', 'entrega', 'funcional', 'bloqueadas', 'meta' ) as $modulo ) {
	require $suite . '/checagens/' . $modulo . '.php';
}

require $suite . '/lib/documentos.php';

if ( '' === $raiz ) {
	fwrite( STDERR, "uso: executar.php <caminho-do-pacote>\n" );
	exit( 2 );
}

/**
 * Emite o veredito de uma checagem, nos DOIS ramos.
 *
 * Toda checagem que varre alguma coisa devolve `medidas`: quantas unidades ela
 * de fato olhou. ESCOPO VAZIO NÃO APROVA — um prefixo de caminho digitado
 * errado faria a varredura percorrer zero arquivo e a linha sairia OK, que é o
 * instrumento mentindo com a melhor cara possível. Zero medida fecha BLOCKED.
 *
 * `nota` é o terceiro ramo, e ele existe porque havia um estado que a linha não
 * sabia dizer: aprovada COM PENDÊNCIA DECLARADA. Sem ele, uma checagem que
 * aceita uma pendência — e aceitar é diferente de cobrir — sairia OK igual à
 * que não tem pendência nenhuma, e a diferença viveria só dentro do código.
 *
 * @param array{ok:bool,achados:array<int,string>,medidas?:int,nota?:string} $r      Veredito.
 * @param string                                                             $nome   Nome.
 * @param string                                                             $msg_ok Mensagem do ramo aprovado.
 * @param string                                                             $classe Classe de evidência.
 * @param string                                                             $fase   Fase.
 * @return void
 */
function emitir( array $r, string $nome, string $msg_ok, string $classe, string $fase ): void {
	if ( isset( $r['medidas'] ) && 0 === (int) $r['medidas'] ) {
		estado(
			'BLOCKED',
			$nome,
			'escopo vazio: a checagem não mediu nenhuma unidade, e o que não foi medido não pode ser aprovado.',
			'pendencia-externa',
			$fase
		);
		return;
	}

	$sufixo = isset( $r['medidas'] ) ? sprintf( ' (%d unidade(s) medida(s))', (int) $r['medidas'] ) : '';
	$nota   = isset( $r['nota'] ) ? (string) $r['nota'] : '';

	estado_por_origem(
		(bool) $r['ok'],
		'site',
		$nome,
		$msg_ok . $sufixo . $nota,
		count( $r['achados'] ) . ' achado(s) em ' . ( $r['medidas'] ?? '?' ) . ' unidade(s) medida(s): ' . f3b_amostra( $r['achados'] ) . $nota,
		$classe,
		$fase
	);
}

/* =========================================================================
 * ETAPA 1 — EMPACOTAR. Sempre a primeira, e ela pode abortar a rodada.
 * ====================================================================== */

echo "== etapa 1: empacotamento ==\n";

if ( ! is_dir( $raiz ) ) {
	estado(
		'BLOCKED',
		'pacote.artefato',
		'o artefato a verificar não existe no caminho informado: ' . $raiz,
		'pendencia-externa',
		'build'
	);
	echo "\nrodada abortada: sem artefato não há o que empacotar nem o que verificar.\n";
	exit( 2 );
}

$lista = f3b_ck_allow_list( $raiz, $suite );
$fora  = array_values( array_filter( $lista['achados'], static fn( string $a ): bool => str_starts_with( $a, 'FORA DO INVENTÁRIO' ) ) );

if ( array() !== $fora ) {
	foreach ( $fora as $achado ) {
		fwrite( STDERR, 'EMPACOTAMENTO ABORTADO — ' . $achado . "\n" );
	}

	fwrite( STDERR, "o inventário de suite/inventario.tsv é a allow-list de caminhos: arquivo fora dela não entra no bundle.\n" );
	exit( 2 );
}

$build = f3b_empacotar( $raiz, $suite );

foreach ( $build['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

echo sprintf(
	"   documentos regenerados: %s\n",
	array() === $build['documentos'] ? '(nenhum: as regiões geradas já estavam iguais à leitura de disco)' : implode( ', ', $build['documentos'] )
);

echo sprintf(
	"   artefato do plugin: %s\n   entregue: %s\n",
	'' !== $build['artefato'] && is_file( $build['artefato'] ) ? $build['artefato'] : '(não montado)',
	is_dir( $build['entregue'] ) ? $build['entregue'] : '(não gravado)'
);

/*
 * O PESO ENTREGUE SAI NO RELATÓRIO, e não só num comentário. Um arquivo que
 * cresce quatro quilobytes por release cresce em silêncio se ninguém imprimir o
 * número — e é o visitante quem paga, uma vez por carregamento. Aqui ele
 * aparece a cada rodada, ao lado do bruto, com o comprimido que é o que trafega.
 */
foreach ( (array) ( $build['peso'] ?? array() ) as $arquivo => $medida ) {
	echo sprintf(
		"   entregue enxuto: %s — %s → %s bytes (%s → %s comprimidos, −%d%%)\n",
		$arquivo,
		number_format( (int) $medida['fonte'], 0, ',', '.' ),
		number_format( (int) $medida['entregue'], 0, ',', '.' ),
		number_format( (int) $medida['fonte_gz'], 0, ',', '.' ),
		number_format( (int) $medida['entregue_gz'], 0, ',', '.' ),
		(int) $medida['fonte_gz'] > 0 ? (int) round( 100 - ( 100 * (int) $medida['entregue_gz'] / (int) $medida['fonte_gz'] ) ) : 0
	);
}

echo "\n";

echo "== etapa 2: checagens ==\n";

emitir(
	$lista,
	'pacote.allow_list',
	sprintf( 'todo arquivo do pacote consta do inventário de caminho→papel (%d caminho(s) exato(s) declarado(s)).', count( f3b_inventario( $suite )['exatos'] ) ),
	'analise-estatica',
	'build'
);

emitir(
	f3b_ck_build_fresco( $build['artefato'], $raiz ),
	'pacote.build_fresco',
	'o artefato de build é mais novo que toda fonte do pacote.',
	'medida',
	'build'
);

emitir(
	f3b_ck_js_entregue_sem_comentario( $raiz ),
	'pacote.js_entregue_sem_comentario',
	'o JavaScript que o VISITANTE recebe viaja sem comentário, e não perdeu mais nada. As duas afirmações são medidas sobre o arquivo ENTREGUE — o de dist/entregue/, que é byte a byte o que entrou no zip do plugin, conferido por leitura de volta dentro do próprio empacotamento. '
		. 'A primeira: zero comentário sem aviso de licença. Comentário é para quem MANTÉM o pacote, e o visitante de um site de tráfego pago o baixa a cada carregamento sem ter leitor nenhum para ele — em f3base-tracking.js eram, na 1.3.5, dois terços do arquivo e 22 KB comprimidos. '
		. 'A segunda, que é a que importa: o fluxo de tokens SIGNIFICATIVOS do entregue é idêntico ao da fonte, token a token, com o espaço normalizado. É ela que acusa o corte por expressão regular — `/*` dentro de string e `//` dentro de URL ou de literal de regex existem NESTES arquivos, e apagá-los entrega um arquivo que ainda analisa e faz outra coisa. Contar comentários não veria nada disso: o arquivo corrompido também não tem comentário nenhum. '
		. 'E o entregue passa em node --check, que é o parser de verdade e não a suíte; quem prova que ele se COMPORTA igual são as bancadas de comportamento e a sonda de navegador, que rodam contra ele.',
	'analise-estatica',
	'build'
);

/* ---------- estáticas ---------- */

emitir( f3b_ck_php_lint( $raiz ), 'estatica.php_lint', 'todo .php do pacote analisa sob php -l.', 'analise-estatica', 'build' );
emitir( f3b_ck_json_valido( $raiz ), 'estatica.json_valido', 'todo .json do pacote analisa.', 'analise-estatica', 'build' );
emitir( f3b_ck_js_lint( $raiz, $suite ), 'estatica.js_lint', 'todo .js/.mjs do pacote passa em node --check.', 'analise-estatica', 'build' );
emitir( f3b_ck_escrita_unica( $raiz ), 'estatica.detector_escrita_unica', 'nenhuma escrita de option fora do gravador declarado; varredura do pacote inteiro, inclusive a suíte.', 'analise-estatica', 'build' );
emitir( f3b_ck_version_compare( $raiz ), 'estatica.detector_version_compare', 'todo version_compare usa operador da lista fechada.', 'analise-estatica', 'build' );
emitir( f3b_ck_condicao_literal( $raiz ), 'estatica.detector_condicao_literal', 'nenhuma checagem com condição constante fora de ramo de if/else com irmão que emite outro veredito.', 'analise-estatica', 'build' );
emitir( f3b_ck_codigo_em_string( $raiz ), 'estatica.detector_codigo_em_string', 'nenhum JavaScript, SQL ou shell em heredoc ou concatenação PHP.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_residuo_de_chave_removida( $raiz ), 'estatica.sem_residuo_de_chave_removida', 'toda chave declarada em suite/chaves-removidas.tsv saiu INTEIRA: não está em config/site.json, não está — nem é exigida — em config/site.schema.json, e nenhum token dela sobrou em código ou em documento fora dos arquivos onde a REMOÇÃO é narrada. Remover a chave da configuração é a parte fácil: o schema que continua exigindo-a reprova todo config correto, o consumidor órfão lê vazio em silêncio e o documento órfão ensina a preencher o que não existe mais — e o detector de chave sem consumidor não enxerga nada disso, porque ele cruza no sentido declarada → lida.', 'analise-estatica', 'build' );
emitir( f3b_ck_tela_fala_portugues_comum( $raiz ), 'tela.fala_portugues_comum', 'a tela fala português comum, e o vocabulário interno fica no log. Quem abre a página do implantador quer três respostas: o site está no ar, o que falhou e o que falta ele fazer. Palavra que só faz sentido para quem escreveu o pacote — gate, veredito, pendência de fase, eixo de convergência, condição de aplicabilidade, e as próprias siglas de estado — não responde a nenhuma das três, e na tela só serve para o leitor achar que o problema é dele. Mede as frases destinadas à TELA (as passadas em tela e em operador, inclusive dentro de ternário e de sprintf): nenhuma carrega essas palavras e nenhuma é um parágrafo. A mensagem completa da linha NÃO é medida — ela é o log, e restringir o vocabulário do log empobreceria a única fonte que explica por quê.', 'analise-estatica', 'build' );
emitir( f3b_ck_simbolos_resolvem( $raiz ), 'estatica.simbolos_resolvem', 'todo método e constante F3Base_*:: chamados existem.', 'analise-estatica', 'build' );
emitir( f3b_ck_estados_fechados( $raiz ), 'estatica.estados_fechados', 'todo estado emitido pelo pacote pertence à lista fechada.', 'analise-estatica', 'build' );
emitir( f3b_ck_saida_com_trava_de_uma_vez( $raiz ), 'estatica.saida_com_trava_de_uma_vez', 'todo emissor ligado a MAIS DE UM evento de saída de página tem trava de uma vez. Sair de uma página não é um evento: numa navegação normal o navegador emite visibilitychange para hidden E pagehide, no mesmo carregamento. Os dois ouvintes existem de propósito — há navegador em que só um dispara, e remover um perde a sessão inteira ali —, então o que a duplicidade exige é que a FUNÇÃO chamada pelos dois só trabalhe uma vez. Sem isso cada métrica entra duas vezes no resumo, o resumo é despachado uma vez só, e o relatório mostra o dobro do que aconteceu, sem erro em lugar nenhum. A varredura acha os alvos dos ouvintes de saída e exige de cada um uma bandeira que ele TESTA e LEVANTA, aceitando condição composta — exigir a bandeira sozinha reprovaria a trava correta e ensinaria a contorná-la. O piso é o par em disco: o mesmo cliente com um dos dois emissores sem trava tem de ser acusado, e com os dois travados tem de calar.', 'analise-estatica', 'build' );
emitir( f3b_ck_carimbo_de_release_nos_documentos( $raiz ), 'estatica.carimbo_de_release_nos_documentos', 'os QUATRO documentos entregáveis carregam regiões GERADAS: README, MANIFESTO e MEMORIA-DECISOES, que ficam no repositório e são lidos por quem instala, publica e mexe no código, e fontes/plugin/INSTRUCOES-DO-PLUGIN.md, que viaja dentro do zip do plugin. Cada um traz os dois marcadores de cada região declarada, e o conteúdo de cada região é IGUAL ao que a leitura de disco produz agora — número digitado à mão em documento entregável envelhece calado, e foi o que aconteceu da 1.0.6 à 1.0.13 do implantador, sete releases seguidas afirmando a identidade da anterior. A identidade sai do cabeçalho do arquivo principal do plugin e entra nas quatro pela mesma leitura: uma versão trocada lá e não regenerada aqui reprova nos quatro documentos de uma vez. O piso é o par em disco, com uma região divergente em cada um dos quatro.', 'analise-estatica', 'build' );
emitir( f3b_ck_numero_digitado_nos_documentos( $raiz ), 'doc.numero_digitado', 'nenhum número está digitado à mão fora das regiões geradas dos quatro documentos entregáveis. É a mesma regra que a sonda do zip já aplicava ao documento que viaja dentro dele, subida para os quatro por escopo: o README diz o que instalar, o MANIFESTO declara o que é contrato e a MEMORIA narra por que cada coisa é assim — os três descrevem ESTE pacote, e quem os lê não tem como conferir. Seis isenções, e cada uma é paga: marcador de lista ordenada, que é estrutura do markdown; dígito colado a letra, que é NOME; vão de código cujo conteúdo aparece verbatim na fonte medida do repositório, que deixa passar um teto do código e barra uma contagem inventada; o índice de uma decisão da memória, isento SÓ quando ele é a posição dela entre as decisões; a referência a uma decisão que existe neste documento, que resolve ou é achado; e o número de origem no título de uma decisão transcrita, que é endereço para outro pacote e por isso só tem a forma medida. O bloco transcrito da memória não é varrido — reescrever a decisão herdada inventaria um passado que não aconteceu —, e dentro dele toda seção precisa declarar a origem, senão o delimitador viraria o lugar onde se escreve prosa nova sem detector nenhum.', 'analise-estatica', 'build' );
emitir( f3b_ck_contagem_com_nomes( $raiz ), 'estatica.contagem_com_nomes', 'nenhuma emissão de contagem por estado existe sem a lista de nomes correspondente na mesma saída — nem em PHP nem no cliente, nem dentro de função nem em escopo de arquivo.', 'analise-estatica', 'build' );
emitir( f3b_ck_warn_tem_ramo_adverso( $raiz ), 'estatica.warn_tem_ramo_adverso', 'nenhum WARN do runtime é retorno incondicional ou único: todo WARN de includes/ e fontes/ mora dentro de um ramo — if, elseif, else, foreach, for, while, switch, match ou ternário — ou depois de uma cláusula de guarda que pode impedi-lo, e é a condição desse ramo que mede o achado adverso. Medição sem achado adverso fecha OK com o detalhe no texto, que é a lição que a 1.0.14 pagou com quatro unidades amarelas numa execução em que nada estava errado.', 'analise-estatica', 'build' );
emitir( f3b_ck_piso_em_sonda_declarado( $suite ), 'estatica.piso_em_sonda_declarado', 'toda checagem cujo piso é declarado em suite/pisos-em-sonda.tsv se sustenta: a sonda declarada existe, menciona a checagem e traz os DOIS ramos — teto e piso. É o piso da regra do piso: sem ele, uma linha de tabela declararia coberta qualquer checagem, que é a doença que armadilhas.mapeadas existe para impedir um nível acima.', 'analise-estatica', 'build' );
emitir( f3b_ck_hidden_governa_visibilidade( $raiz ), 'estatica.hidden_governa_visibilidade', 'todo elemento cuja visibilidade é comandada por `hidden` — no JavaScript, por `.hidden =` ou por `setAttribute(\'hidden\')`, e no markup, pelo atributo literal — foi cruzado com toda regra de AUTOR que declara `display` sobre a classe dele, nas folhas do tema, do site-core e do implantador. `[hidden] { display: none }` é regra da folha do USER AGENT, e qualquer declaração de autor a vence: a origem decide antes de a especificidade ser consultada. O par declarado é `.classe[hidden] { display: none }` (0,2,0 contra 0,1,0) ou o global com `!important`; um `[hidden]` global SEM `!important` empata e perde na ordem, e por isso não é aceito. Foi este o defeito medido na 1.1.2, e ele estava em dois lugares: o painel de consentimento que cobria a página e não fechava, e a caixa do resumo final do implantador, aberta e vazia do primeiro lote ao último.', 'analise-estatica', 'build' );
emitir( f3b_ck_campo_operavel_documentado( $raiz ), 'estatica.campo_operavel_tem_impacto_e_exemplo', 'toda folha operável do catálogo do site-core declara IMPACTO e EXEMPLO, e a âncora é o próprio catálogo: rótulo é o nome do campo, descrição é a definição dele, e nenhum dos dois diz o que MUDA no site quando o campo é preenchido nem o que acontece enquanto ele está vazio — que é a única frase de que precisa quem abriu a tela para decidir se preenche. Cada folha declara também a SEÇÃO por assunto em que a tela a apresenta. O exemplo tem duas recusas medidas: option declarada em segredos_do_site() não pode trazer exemplo em forma de valor — corrida de 16 ou mais caracteres alfanuméricos —, porque valor plausível ali é credencial impressa na tela de administração de todo site que instalar este pacote; e identificador de fornecedor sai na FORMA que o próprio pacote declara em formas(), porque exemplo que parece um identificador real é um identificador real esperando para ser colado. O piso planta os quatro defeitos: um sub-campo sem impacto, uma option sem exemplo, um identificador fora da forma declarada e um token com valor de exemplo.', 'analise-estatica', 'build' );
emitir( f3b_ck_robos_conhecidos_ordenados( $raiz ), 'estatica.robos_conhecidos_ordenados', 'Marcas mais específicas precedem as genéricas, famílias são únicas e classes são fechadas.', 'analise-estatica', 'build' );
emitir( f3b_ck_options_citadas_existem( $raiz ), 'mcp.options_citadas_existem', 'toda option citada no manual que o agente lê antes de mexer no site EXISTE no catálogo. O defeito medido: o "não faça" mandava gravar f3base_tracking e f3base_leads, e nenhuma das duas existe — gravar uma option que módulo nenhum lê não falha, não avisa e não muda nada, e quem seguiu a instrução conclui que o plugin não faz o que o próprio manual dele afirma, e passa a resolver por fora, que é o que o manual existe para impedir. O cruzamento é com o catálogo declarado mais as âncoras que o gravador único publica em constantes OPTION_*. O piso planta o defeito: o manual da fixture cita uma option que o catálogo dela não tem. E escopo vazio não aprova: sem manual, sem catálogo ou com um manual que não cita option nenhuma, a linha reprova dizendo qual dos três faltou.', 'analise-estatica', 'build' );
emitir( f3b_ck_eventos_de_comportamento_declarados( $raiz ), 'tracking.eventos_de_comportamento_declarados', 'nome de evento e de parâmetro de comportamento moram em fontes/plugin/dados/eventos-comportamento.tsv e em lugar nenhum mais: nenhum nome declarado aparece como literal no JavaScript do pacote, o servidor LÊ o arquivo e o publica ao navegador, todo evento traz teto por página maior que zero, parâmetro e gatilho, e todo vital declarado é coletado pelo cliente. Quem lê esta série é um agente comparando períodos, e para ele nome que muda entre releases não é erro visível: é o relatório do mês seguinte vazio, sem ninguém saber se o site parou de medir ou se os visitantes pararam de rolar. O gatilho é a chave de junção — único por linha — e os parâmetros chegam POSICIONALMENTE, que é o que permite ao cliente não escrever nome nenhum.', 'analise-estatica', 'build' );
emitir( f3b_ck_afirmacoes( $raiz ), 'doc.afirmacao_conferida', 'toda AFIRMAÇÃO DE COMPORTAMENTO declarada em suite/afirmacoes.tsv continua escrita em fontes/plugin/INSTRUCOES-DO-PLUGIN.md, e o pacote MEDE o que ela promete. Os outros detectores desta suíte conferem identidade, contagem e região gerada; nenhum conferia uma frase de PROSA — e a prosa é a metade do documento que a geração não alcança. Foi por essa fresta que a revisão da 1.0.1 achou dez contradições entre o documento e o código dentro do mesmo zip: a prosa mandava percorrer uma função sem chamador e a receita de evento novo ensinava um passo que nunca dispara. Dois achados possíveis, e os dois reprovam: frase declarada que sumiu do documento — a amarração ficou para trás da redação e passa a afirmar cobertura que não existe — e fato que não bate com o esperado, que é o documento afirmando e o pacote fazendo outra coisa. As regras medem a ÁRVORE VARRIDA: codigo.chamada procura a expressão no PHP do pacote, e codigo.contem procura no arquivo nomeado, que é o que alcança o coletor no navegador, a declaração de eventos em TSV e o contrato de nomes. Tabela vazia não aprova: sem elo declarado nenhuma afirmação é conferida, e a linha reprova dizendo isso.', 'analise-estatica', 'build' );
emitir( f3b_ck_sem_recusa_de_escrita_do_agente( $raiz ), 'estatica.sem_recusa_de_escrita_do_agente', 'nenhum arquivo do RUNTIME do pacote registra literal de filtro de options protegidas do servidor MCP: depois da instalação quem modifica o site é o agente, pelo canal, e um pacote que peça ao canal para recusar a escrita das próprias options é o pacote impedindo exatamente o que ele existe para permitir. A 1.0.19 registrava as vinte options do catálogo em quatro filtros do servidor; o módulo saiu inteiro na 1.1.0 e este detector existe para que ele não volte por outro nome.', 'analise-estatica', 'build' );

/*
 * O EMISSOR ÚNICO NÃO PASSA POR `emitir()`, e pela mesma razão que
 * `conteudo.demonstrativo` não passa: ele tem TRÊS estados. FALHA é o segundo
 * emissor com slot preenchido — contagem em dobro. WARN é o emissor de fora com
 * TODOS os slots vazios, que não é dobro e sim medição que este pacote não
 * emitiu e não governa: sob a premissa do agente a decisão é do projeto, e o
 * pacote nomeia em vez de decidir. A regra do WARN continua sendo a da 1.0.15 —
 * ele só sai com achado adverso nomeado.
 */
$discriminante = f3b_ck_emissor_unico_discrimina( $raiz, $suite );

if ( 0 === (int) $discriminante['medidas'] ) {
	estado( 'BLOCKED', 'tracking.emissor_unico_discrimina', 'escopo vazio: nenhum HTML e nenhum caso declarado foi medido, e o que não foi medido não pode ser aprovado.', 'pendencia-externa', 'build' );
} else {
	estado(
		$discriminante['estado'],
		'tracking.emissor_unico_discrimina',
		$discriminante['motivo'] . sprintf( ' (%d unidade(s) medida(s))', (int) $discriminante['medidas'] ),
		'analise-estatica',
		'build'
	);
}

/* ---------- funcionais ---------- */

$rotulos_funcionais = array(
	'leads.limite_por_caractere'            => 'o limite de campo do endpoint é medido na MESMA unidade que o cliente corta — caracteres, nunca bytes: um nome com o número exato de caracteres acentuados é ACEITO, um caractere acima é recusado nomeando a unidade, e a mesma unidade vale dentro de atribuicao. O piso planta o defeito: o texto acentuado no limite EXCEDE em bytes, e é por isso que o servidor devolvia 400 no lead que a própria página tinha aprovado.',
	'leads.email_conclusivo'                => 'e-mail inválido é RECUSADO nomeando o campo, e-mail válido passa e e-mail vazio continua sendo campo opcional ausente. O piso planta o defeito: sanitize_email() devolve string vazia para entrada inválida, e sem conferir o retorno o lead entrava sem endereço nenhum respondendo 201.',
	'leads.booleano_explicito'              => 'o campo booleano tem parser explícito com vocabulário fechado: "false", "0", "", "no", "nao" e "off" valem FALSO, estrutura no lugar de escalar é recusada, valor acima do limite declarado é recusado — o max de 8 deixou de ser letra morta — e valor fora do vocabulário é recusado em vez de adivinhado. O piso planta o defeito: (bool) "false" é true nesta linguagem, e o campo que passava por esse molde era o consentimento.',
	'leads.reserva_compensada'              => 'a reserva de deduplicação nasce PENDENTE, vira firme depois da persistência e é compensada na falha: depois de uma falha de armazenamento a segunda tentativa com o mesmo correlation_id é ACEITA, o replay de uma correlação já gravada continua recusado, a reserva pendente abandonada é retomada uma vez só, e o caminho de contingência por transiente tem a mesma compensação. O piso planta o defeito: sem compensação a reserva sobrevive à falha e bloqueia por 30 dias quem tentou de novo.',
	'leads.atividade_so_com_persistencia'   => 'a atividade "último registro aceito" só é carimbada quando a gravação aconteceu; a recusa deixa carimbo PRÓPRIO nomeando os destinos que recusaram, e o módulo fecha degradado enquanto a tentativa mais recente não tiver entrado. O piso planta o defeito: sem o ramo separado a tela afirmava "último lead registrado" apontando para onde nada foi escrito.',
	'leads.status_da_gravacao'              => 'gravação recusada responde 5xx com código e com o que o visitante deve fazer, nunca 201 Created com ok:false; gravação aceita responde 201 com registrado verdadeiro. O piso planta o defeito: 201 diz que o recurso existe, e nenhum backend tinha aceitado o lead.',
	'leads.rate_limit_atomico'              => 'o incremento do balde é UMA instrução no banco e quem soma é ele: cinco incrementos sob leitura congelada devolvem 1, 2, 3, 4 e 5, sem SELECT antes, e a janela vencida reinicia o balde. O piso planta o defeito: sob a MESMA leitura congelada o caminho de ler-modificar-gravar devolve 1 e 1, que é o incremento perdido sob concorrência.',
	'leads.origem_declarada'                => 'a origem do balde vem de REMOTE_ADDR até que a configuração declare um cabeçalho de proxy: sem declaração o cabeçalho é IGNORADO, com declaração ele é lido descontando os saltos confiáveis da direita, o valor que o visitante empurra na frente da cadeia não vira origem, cadeia curta ou valor que não é IP volta para REMOTE_ADDR, e dois visitantes atrás do mesmo proxy caem em baldes distintos. O piso planta o defeito: sem a declaração, o balde de 20 por janela valia para o proxy inteiro.',
	'cadencia.ouvinte_registrado'           => 'o hook f3base_cadencia_relatorio TEM ouvinte depois do registro único, e as recorrências quinzenal e mensal existem com quinze e trinta dias; o agendamento sai com a recorrência DECLARADA e a divergência entre a agendada e a declarada fecha degradado NOMEANDO as duas. O piso planta o defeito: o núcleo do WordPress não tem monthly nem quinzenal, e sem ouvinte o evento dispara, o WP-Cron o reagenda e nada acontece.',
	'cadencia.execucao_registrada'          => 'a execução registra última execução, gatilho, resultado, erro, duração, atraso, próxima, os módulos por estado COM os nomes e a releitura das options; a medição que explode vira resultado erro nomeado e degrada o módulo; e evento atrasado vira atraso medido e degradação. O piso planta os dois defeitos: previsão no passado e medição que lança exceção.',
	'cta.publicado_pela_presenca_do_numero' => 'a presença do número decide, e ela sozinha: com contato.whatsapp_e164 gravada o bloco do CTA é publicado; sem ela o bloco do modelo NÃO é publicado, o módulo fecha INATIVO em vez de degradado e o motivo diz o que aconteceu com o botão. O discriminante é a CLASSE do pattern e não o atributo carimbado no render: o piso roda numa bancada SEM WP_HTML_Tag_Processor, que é a instalação em que decidir pelo atributo deixaria publicado um botão que não leva a lugar nenhum.',
	'cta.regra_de_publicacao_registrada'    => 'a regra de publicação do CTA RODA no estado em que ela decide, e isso é medido pelo caminho real — apply_filters, nunca chamada direta: com o módulo INATIVO por número vazio o filtro render_block dele está registrado, o CTA do modelo não é publicado e o CTA com destino próprio fica intocado; com número gravado o do modelo é promovido e o do agente é preservado. A exceção é declarada no PRÓPRIO item do hook e alcança um hook só — o enfileiramento do módulo inativo continua inerte. O piso é o defeito medido: da 1.0.19 à 1.1.0 o filtro só era registrado com o módulo ativo, isto é, quando a condição da supressão já não podia acontecer, e a regra afirmada em três documentos não rodava em site nenhum.',
	'options.chave_desconhecida_preservada' => 'todo sanitizador de grupo normaliza a chave CONHECIDA e preserva a DESCONHECIDA, no catálogo inteiro e dentro das entradas de lista: a chave que o agente acrescentou a f3base_contato sobrevive à leitura, com valor aninhado; f3base_redirects e f3base_journal_eliminacao preservam a chave desconhecida DENTRO da entrada; e a chave conhecida continua sendo normalizada, para que preservar o desconhecido não vire aceitar qualquer coisa. O piso planta o defeito da 1.0.19: o reconstrutor de chaves fixas devolve o valor sem a chave, apagada em silêncio, sem erro e sem log.',
	'seguranca.coop_do_valor_gravado'       => 'o Cross-Origin-Opener-Policy emitido é o valor GRAVADO, e não o literal da classe: gravar same-origin lê de volta same-origin, o cabeçalho sai com ele e o módulo fecha degradado NOMEANDO o que se perde — a janela que o CTA abre. O vocabulário continua fechado: valor que o navegador não conhece cai no padrão declarado, porque cabeçalho ignorado em silêncio é pior que cabeçalho ausente. O piso planta o defeito da 1.0.19: o sanitizador devolvia o literal e a option não tinha efeito nenhum.',
	'seguranca.referrer_policy_avisa_atribuicao' => 'Referrer-Policy no-referrer é ACEITO e AVISADO: o aviso fecha WARN nomeando GA4, Google Ads, Meta Ads e LinkedIn Ads — os quatro que perdem a origem do clique quando ele chega sem parâmetro de campanha —, e o cabeçalho continua sendo emitido, porque avisar é nomear o preço e recusar seria decidir pelo projeto. O piso é o ramo adverso: com o valor padrão gravado, nenhum aviso sai.',
	'tracking.caminho_unico'                => 'uma chave decide o caminho, e um caminho só: com f3base_gtm_container_id preenchido o container vai para o navegador e os IDs diretos NÃO vão — não é um if no cliente, é o ID que não chega —, e sem container os IDs presentes vão e o container não. Slot vazio é inerte: nenhum script enfileirado e o módulo INATIVO. ID fora da forma declarada é PRESERVADO e avisado, nunca apagado. O piso planta o disparo em dobro: com os IDs diretos viajando junto do container, a mesma conversão sai duas vezes e o lance do leilão é reescrito.',
	'tracking.consentimento_gateia_tudo'    => 'um estado de consentimento e quatro tags: na negativa NENHUMA é enfileirada — Pixel e Insight Tag não têm modo de consentimento, e para eles negativa é ausência —, e o módulo fecha degradado dizendo isso; no aceite as quatro saem por UM carregador só, que depende do script de consentimento para que o Consent Mode tenha default antes de a tag decidir. O piso planta a negativa na bancada e mede que nada foi enfileirado.',
	'leads.click_ids_no_schema'             => 'os identificadores de clique estão no schema FECHADO do endpoint e no cliente ao mesmo tempo: gclid, gbraid, wbraid, msclkid, fbclid, fbc, fbp e li_fat_id são aceitos, gravados no registro do lead, e o conjunto continua fechado — chave de fora segue recusada com 400 nomeando a chave. O piso é o pior modo de falhar deste endpoint: acrescentar o campo só no cliente faria todo lead de tráfego pago voltar recusado.',
	'leads.cta_preserva_destino'            => 'os QUATRO quadrantes do CTA: sem número e com o href do modelo o bloco não é publicado; sem número e com destino próprio ele é publicado intacto; com número e href do modelo ele é promovido ao link profundo e carimbado; com número e destino próprio o destino fica e o carimbo não sai — o cliente não vai tocar nele. Bloco que não é o CTA passa intacto nos dois casos. O piso é a supressão cega da 1.0.19, que apagava qualquer bloco da classe, e a reescrita cega do href, que desfazia a escolha do agente a cada render.',
	'leads.capi_meta'                       => 'o evento Lead de SERVIDOR da Meta sai DEPOIS da persistência confirmada e com o MESMO event_id que o navegador manda no Pixel — é essa identidade que deduplica os dois caminhos, e gerar um identificador novo aqui contaria a conversão duas vezes. Com token e Pixel gravados o envio é AGENDADO para outra requisição (o payload fica num transiente, e não nos argumentos do evento: a option cron é autoload, e cada lead pendente pesaria em toda requisição do site); e-mail e telefone saem em SHA-256 sobre o valor normalizado pela regra da META — não a do Google —, IP e user agent vão porque a Meta os pede, e o token vai no CORPO, nunca na URL. Quatro pisos: sem token nada é agendado e o motivo NOMEIA a option; com token e sem Pixel ID o módulo fecha degradado nomeando a dependência; nenhum dado pessoal em claro atravessa o payload serializado; e a recusa HTTP da Meta não muda o status do lead, não mexe na reserva de deduplicação e sai NOMEADA com o código e a mensagem.',
	'verificacao.tag_do_valor_gravado'      => 'as duas metatags de posse do domínio saem do VALOR gravado e de mais nada: option vazia é inerte — nenhum markup, e o módulo fecha inativo NOMEANDO as duas options —, option preenchida emite a tag daquele fornecedor e só a dela. O piso da preservação é a regra da 1.1.0: valor com caractere fora do alfabeto que a tag aceita continua gravado, continua sendo emitido ESCAPADO no atributo, e produz exatamente um WARN nomeando a option, a tag e a forma esperada. Valor dentro da forma não produz aviso nenhum.',
	'seo.llms_emissor_unico'                => 'um endereço, um dono, e a precedência é declarada: arquivo físico na raiz vence, emissor concorrente MEDIDO vem em seguida, e só então a rota deste pacote. É a mesma regra de tracking.emissor_unico. O piso é o caso adverso: com o plugin de SEO publicando o arquivo, a rota NÃO serve e o motivo NOMEIA o outro emissor, dizendo onde desligar; e com arquivo físico e concorrente ao mesmo tempo, quem responde é o arquivo. O teto é o caso sozinho, em que a rota serve — o endereço não pode ficar sem dono nenhum.',
	'seo.llms_noindex_respeitado'           => 'o que está em noindex fica fora dos DOIS arquivos, e o fato tem UM produtor: F3Base_Modulo_Noindex_Honrado. Os pisos são os quatro modos de a exclusão nunca disparar: a regra do noindex medida nos três ramos (a meta que manda não indexar, a meta que manda indexar vencendo o padrão do tipo, e o padrão do tipo sozinho), a página marcada entrando na seleção, o dedupe feito por URL em vez de por ID — a URL muda quando o slug muda —, e a exclusão declarada não alcançando o eixo automático, que faria a página que a curadoria deixou de fora voltar pela enumeração. E o VOCABULÁRIO das chaves do fornecedor sai de um lugar só, `F3Base_Chaves_Seo`, carregado pelos dois runtimes: o arquivo da regra do llms.txt não pode escrever a chave de meta do noindex por conta própria — um segundo leitor do mesmo fato é como a exclusão para de disparar sem que nada acuse —, o adaptador de SEO do implantador, que ESCREVE essas metas, não pode trazer o prefixo do fornecedor como literal, e as constantes do módulo de noindex têm de continuar saindo do vocabulário compartilhado. Quem escreve e quem lê a mesma chave precisam da mesma fonte: sem ela, uma renomeação do fornecedor quebra cada lado no seu lugar, sem erro e sem aviso.',
	'seo.llms_sitemap_medido'               => 'o endereço do sitemap é MEDIDO, nunca fixo: sitemap do plugin de SEO ligado responde em sitemap_index.xml, o do núcleo em wp-sitemap.xml, e sem nenhum dos dois a seção inteira é OMITIDA. O piso é o defeito que o endereço fixo produz: com o sitemap do plugin ligado, imprimir wp-sitemap.xml reprova — o núcleo desativa esse endereço quando o plugin assume, e a última linha do arquivo apontaria para um sitemap que não existe. O outro piso é o escopo vazio: sem sitemap nenhum servido, imprimir qualquer endereço é afirmar mais do que se mediu. E o piso da BARRA: a função é pura e não confia no formato do argumento — com o home sem barra final, os dois ramos que imprimem endereço têm de produzir exatamente uma barra antes do nome do arquivo, e com barra a mais não pode sair barra dupla. Função pura que confia no chamador é defeito esperando o segundo chamador.',
	'seo.llms_descricao_fonte'              => 'a descrição de cada item sai de uma cadeia com ordem — meta do plugin de SEO, resumo declarado no conteúdo, corte do corpo limpo — e a função devolve o texto E a FONTE que respondeu, porque sem a fonte não há como provar qual foi preferida. O piso é o defeito medido: existindo meta descrição, cair no corte do conteúdo reprova. Os outros ramos têm teto próprio, e sem fonte nenhuma a função devolve vazio em vez de inventar descrição. A enumeração do site lê a meta pela constante do módulo de noindex, nunca por um literal novo.',
	'seo.llms_sem_interface_no_resumo'      => 'o resumo de última instância é do assunto, não da interface: shortcode removido, elementos de interface removidos COM o conteúdo (form, script, style, nav, aside, button, svg), quebra de linha antes de tirar as tags e só então o corte em palavras. Os pisos são literais: uma página com formulário de busca dentro não pode produzir resumo contendo o rótulo do botão nem o do campo, o corpo de um script não pode entrar, shortcode não renderizado não pode virar texto com colchetes, título e corpo não podem colar numa frase sem pontuação, e um conteúdo que é só interface produz resumo VAZIO em vez de resumo de nada. O teto é o texto de verdade sobreviver à limpeza.',
	'seo.llms_ordem'                        => 'a ordem é declarada: página inicial primeiro, curadoria NA ORDEM DECLARADA em seguida, e só então o enumerado — páginas antes de posts, por data decrescente. O piso é o defeito que a ordenação por data produz: a home fora da primeira posição reprova, porque ordenar tudo por data a joga para o rodapé, depois de qualquer artigo publicado, e o que define o site não pode sair por último. Os tetos medem a curadoria conservando a ordem de entrada e o eixo automático separando página de artigo.',
	'seo.llms_full_servido'                 => 'o texto integral só existe com a chave ligada: desligada, o módulo fecha INATIVO e não registra hook nenhum — nenhuma rota, nenhuma superfície pública, a mesma física da chave-mestra. Ligada, ele fica ativo e o corpo traz URL, data e o conteúdo inteiro, sem corte. O piso mede os dois lados do interruptor e mais um: o índice curto e o texto integral têm de listar o MESMO conjunto — dois arquivos com listas diferentes seriam dois vereditos sobre o mesmo site —, e a chave de indexação sobrevive à leitura de volta, que é o que torna o cabeçalho X-Robots-Tag controlável.',
	'conteudo.demonstrativo_no_site'        => 'o conteúdo demonstrativo é medido no BANCO, e não na configuração, e o veredito discrimina QUEM escreveu cada página marcada: toda página marcada escrita por ESTA execução fecha OK nomeando-as — o template está no ar porque acabou de ser implantado, que é o estado declarado —, e a página marcada que a execução NÃO escreveu fecha WARN nomeando só ela, que é texto de template sobrevivendo a quem deveria tê-lo substituído. O padrão VAZIO do conjunto de escritas mantém a regra útil no site-core: na cadência ninguém escreveu nada, toda marcada volta a ser achado, e é ali que a pergunta vale. Os outros pisos continuam: com nenhuma marcada a regra CALA mesmo com conteudo.demonstrativo ainda em true — o estado permanente de todo site cujo conteúdo o agente trocou pelo canal —, rascunho com a marca não conta porque o aviso é sobre o que está no ar, e sem prefixo declarado não há marca a procurar, e isso sai dito em vez de virar aprovação por escopo vazio. O defeito plantado é o da 1.1.6: 7 de 9 páginas acusadas, e as sete publicadas pela própria execução minutos antes.',
	'contato.whatsapp_sem_codigo'           => 'a mensagem do WhatsApp é só a mensagem. Nenhum código de referência, id de sessão ou parâmetro de rastreio entra no texto que a pessoa vê ao abrir a conversa nem na URL — quem recebe leria um identificador que não significa nada para ela. A correlação entre o clique e a conversa é por DATA E HORA, feita fora do site, e é por isso que o registro do clique carrega o carimbo de tempo em duas formas: a legível com fuso e a de milissegundos. O link abre em ABA NOVA com rel=noopener, nos dois caminhos — o que o servidor reescreve no HTML e o que o script remonta no clique.',
	'mcp.como_usar_sai_do_registro'         => 'o manual que o agente MCP le vem do REGISTRO de modulos, nunca de texto a mao. Digitado, ele envelhece na primeira vez que alguem acrescenta um modulo e esquece de atualiza-lo — e manual desatualizado e pior que nenhum, porque o agente confia nele e resolve por fora o que o plugin ja fazia. O teto e a lista sair do registro com o que cada modulo faz e as options que o controlam; os pisos sao nenhum nome de modulo escrito a mao no manual e a lista do que NAO fazer trazendo o motivo e a saida — proibicao sem motivo e ignorada pelo primeiro que tiver pressa.',
	'comportamento.resumo_agregado'         => 'a rota que recebe o resumo da sessão segue as regras que o endpoint de leads estabeleceu — schema FECHADO com recusa nomeada de campo desconhecido, no corpo E dentro de cada total, teto de tamanho, limite de taxa pelo MESMO balde atômico e status coerente com o corpo — e as três desta release: DADO PESSOAL NÃO ATRAVESSA (e-mail, caminho de perfil, telefone, identificador de sessão e URL com query são recusados no detalhe; query e fragmento são recusados no caminho; e a tabela inteira é varrida depois, como a da CAPI), DUAS SESSÕES SOMAM na mesma linha de dia, caminho, evento e detalhe — numa instrução só, porque quem soma é o banco —, e a RETENÇÃO apaga o que passou do prazo declarado, executada pela rotina de retenção que já existia. O nome do evento sai da declaração e o cliente manda só o gatilho; gatilho fora dela não vira linha; o teto de linhas por sessão é a SOMA dos tetos declarados, nunca um número escrito no módulo. Os pisos do estado: com o resumo desligado nada é gravado e o módulo fecha inativo; sem a tabela pronta a rota responde 503 NOMEANDO a perda e o módulo fecha degradado, em vez de 201 sobre nada gravado.',
	'comportamento.lote_idempotente'        => 'o REENVIO de um lote não conta duas vezes, e o lote recusado não some. O cliente passou a CONFIRMAR a entrega em vez de confiar no `true` do sendBeacon — que significa ENFILEIRADO, nunca ENTREGUE —, e confirmar implica reenviar: uma resposta perdida no caminho de volta faz o mesmo lote chegar de novo. Cada lote leva um SELO sorteado, e este lado o reconhece: o mesmo lote entregue duas vezes produz UMA linha de cada, no registro E no agregado, e a repetição responde 2XX nomeando f3base_lote_repetido — qualquer outro status faria o cliente reter e reenviar para sempre justamente o lote que o servidor já tem. O selo usa o MESMO mecanismo de reserva do lead, e pelas três etapas dele: reservado antes da escrita, confirmado depois dela e DEVOLVIDO quando nada foi gravado — sem a compensação, o lote fica marcado como recebido sobre um banco que recusou e a retentativa é respondida "já tenho isto" sobre nada. Selo ausente é aceito (sem gerador criptográfico não há selo, nem apelido, nem retentativa a deduplicar) e selo fora da forma fechada é recusado pelo nome, como os apelidos. A janela do selo é a MESMA da visita, lida da declaração única dos dois lados. E o CORTE deixou de morrer na resposta da rota: ele é gravado por dia e por caminho, FORA do total e FORA da lista de eventos, para que a tela possa dizer que a tabela está incompleta em vez de deixar quem lê somar achando que tem tudo. O piso é o servidor sem memória do selo: apagada a reserva, o mesmo lote entregue de novo grava de novo.',
	'tela.campo_diz_impacto_e_exemplo'      => 'a tela é medida no DOM QUE O OPERADOR RECEBE, e não no arquivo que a produz: toda folha operável do catálogo aparece com rótulo, IMPACTO — o que muda no site com o campo preenchido, e o que acontece com ele vazio — e EXEMPLO, e os textos declarados chegam ao HTML. O piso é o VALOR FANTASMA: a tela não usa placeholder em lugar nenhum, e nenhum exemplo aparece dentro de um value do formulário — exemplo dentro do campo é valor que o operador acha que está gravado. A ORDEM dos blocos no DOM é a declarada em ordem_dos_blocos(), com os campos antes do diagnóstico; o diagnóstico continua COMPLETO — módulos, estados, hooks e resumo por estado —, mudou de lugar e não de tamanho; a marca de origem por option e a distinção entre o que tem campo e o que não tem continuam; a capability é conferida antes de renderizar; e o campo declarado SEGREDO apresenta ONDE OBTER, nunca um exemplo de valor.',
	'medicao.registro_por_visitante'        => 'os dados ficam SEPARADOS POR DATA E POR VISITANTE, num registro de eventos ao lado da tabela agregada. As duas existem porque são dois dados de naturezas diferentes: o resumo soma por dia e por página, não identifica ninguém e pode durar; o registro guarda apelido do visitante, apelido da visita e carimbo em milissegundos, é DADO PESSOAL PSEUDONIMIZADO e tem prazo próprio e mais curto. É por isso que o resumo não é derivado do registro — derivá-lo faria a série do painel evaporar junto com o log na primeira execução da retenção, perdendo a comparação de trimestre para proteger uma privacidade que o agregado já protegia sozinho. Os tetos: dois apelidos distintos na mesma página no mesmo dia contam como duas pessoas, a ocorrência separa a primeira descida da releitura, e a mediana do tempo até cada marco sai do carimbo. Os pisos: a MEDIANA resiste à aba esquecida aberta por três horas que moveria a média da página inteira; o prazo do registro nunca pode passar o do resumo, nem digitando um número maior no campo; o esquecimento apaga as linhas de quem pediu e SÓ as dele; e o corte acima do teto de eventos por corpo sai nomeado na resposta em vez de fazer o total do painel não bater com o registro em silêncio.',
	'medicao.carimbo_do_acionamento'        => 'o CARIMBO DE CADA LINHA DO REGISTRO é o instante do ACIONAMENTO, e não o da chegada do lote. O defeito foi medido no banco de um site: `registrar_evento()` gravava `criado_em => time()`, que é a hora em que o LOTE CHEGOU, e um lote carrega dezenas de acionamentos acumulados ao longo de segundos ou minutos de navegação — agrupando por `criado_em`, uma linha só respondia por 33 acionamentos com `ms` de 724 a 10816, dez segundos de leitura no mesmo segundo, e na tela as 25 linhas da primeira página saíam todas com o mesmo 09:22:25. Indistinguíveis no tempo, elas pareciam a mesma linha sendo reescrita; e a coluna `ms`, o deslocamento exato desde o carregamento, estava gravada, certa, e não era usada para nada. O conserto: o cliente manda a ORIGEM temporal do carregamento uma vez por lote, DENTRO do lote selado — para que ela sobreviva à fila pendente e ao reenvio —, e o servidor grava `criado_em` de cada linha como `origem + ms`. A GUARDA DO RELÓGIO é a metade que a origem do visitante obriga: ausente, não numérica, no futuro além da tolerância declarada ou mais velha que a janela de retenção do registro cai na âncora derivada do servidor, `chegada − maior ms do lote`, que dá o mesmo espaçamento sem confiar em relógio nenhum — e essa segunda âncora tem o limite escrito: num lote entregue com atraso, a ORDEM e o ESPAÇAMENTO continuam certos e é só o ABSOLUTO que erra pelo tempo de fila. QUAL ÂNCORA FOI USADA NÃO É SILÊNCIO: a coluna `ancora` guarda a procedência de cada linha, e a tela a diz. Os tetos: 33 acionamentos espalhados por dez segundos saem em dez segundos distintos de carimbo, na ordem certa e com o espaçamento dos `ms`; a tela mostra o horário com a fração de segundo, derivada de `ms` porque a âncora é truncada ao segundo inteiro; e cada quadro diz de qual das duas tabelas ele vem. Os pisos são mutantes: as MESMAS linhas carimbadas com a chegada — o código de ontem — precisam ser acusadas com a frase do caso real; as três linhas empatadas no mesmo segundo invertidas precisam ser acusadas, porque ali quem ordena é o desempate por id e não o carimbo; as seis formas de origem imprestável precisam cair na âncora do servidor sem perder o espaçamento; e o lote atrasado, com e sem origem selada, não pode embaralhar a ordem dentro dele. As linhas gravadas antes desta versão NÃO são reescritas: elas saem marcadas na tela e a retenção as leva.',
	'medicao.profundidade_por_pagina'       => 'a PROFUNDIDADE DE LEITURA é medida e exibida por PÁGINA, e não somada. Somada, ela não responde nada: a página que ninguém termina e a que todo mundo termina entram no mesmo total, e é justamente qual das duas está longa demais que o operador precisa saber. E ela só é legível como PROPORÇÃO — "2 chegaram a 90%" pode ser 2 de 2 ou 2 de 200, e as duas leituras levam a decisões opostas —, por isso o denominador é o número de carregamentos DAQUELA página, vindo de um evento declarado e não de inferência sobre o TTFB: inferir seria uma segunda verdade sobre uma contagem, divergindo no primeiro navegador que não reporte Navigation Timing. A bancada monta duas páginas com comportamentos opostos, confere os denominadores, a proporção e a ordem numérica dos marcos — fora de ordem, uma queda de leitura é lida como subida. Os pisos: sem carregamento registrado a proporção é NULA e não zero, e a tela diz "não medido" em vez de inventar uma porcentagem sobre um total que não existe.',
	'medicao.menu_proprio'                  => 'a MEDIÇÃO GANHOU MENU PRÓPRIO no wp-admin, e a tela é medida no DOM que o operador recebe. Ela morava no fim da tela de configuração, depois de trinta campos de formulário: quem abre aquela tela vai gravar uma option, e quem quer saber o que os visitantes fizeram tem outra pergunta. Com ZERO registro a tela diz que não há dado nenhum e que isso é ausência de REGISTRO, não audiência zero; com registro, mostra desde quando o site coleta, o período somado, os seis eventos declarados — cada um com a PERGUNTA que ele responde, em português comum e lida da declaração, nunca escrita na tela — e as páginas em que cada um aconteceu. O que falta sai nomeado com o lugar de resolver: coleta desligada, tabela ausente, consentimento barrando. Os pisos: nenhuma tabela é montada sem dado, a pergunta de nenhum evento pode estar escrita dentro do PHP da tela (segunda descrição do mesmo evento diverge sem que nada acuse), evento declarado sem registro aparece com zero em vez de sumir, e a tela de configuração deixou de somar os mesmos números — ficou o caminho, e não uma cópia menor do quadro. E O DESLIGAMENTO É ENCONTRÁVEL: a tela diz, ANTES de qualquer número, onde a medição se desliga, e leva ao campo por âncora de produtor único, cruzada com o id que a tela de configuração emite — âncora montada como literal nos dois lados continua existindo e deixa de levar a lugar nenhum. Com a medição desligada, a primeira coisa da tela é o desligamento nomeado, antes do primeiro quadro, e nenhuma tabela é montada: tabela vazia silenciosa é indistinguível de um site sem visita.',
	'consentimento.estrategia_pela_politica' => 'a ESTRATÉGIA DE CARGA do script de consentimento é decidida pela POLÍTICA, e não por um interruptor: pré-aprovado sai defer, fora do caminho crítico do parser; negado por padrão sai BLOQUEANTE no cabeçalho, porque ali o default é denied e a ordem é a garantia inteira. Nos dois modos o script fica no CABEÇALHO, que é a posição que o põe antes do carregador de tags do rodapé; o carregador continua defer no rodapé e continua declarando dependência do handle do consentimento. Os pisos: as duas políticas não podem devolver a mesma estratégia (valor fixo com nome de função em volta), mudar rodapé, aviso e prazo não pode mexer nela (interruptor disfarçado), no modo padrão NENHUM script pode ficar no cabeçalho sem estratégia — era o único, e é o entregável desta release — e no modo opt-in o consentimento PRECISA voltar a bloquear, senão a regra teria virado nunca bloquear, que é a permissividade aplicada onde ela não foi autorizada.',
	'cadencia.contador_de_ajustes'          => 'apos_n_ajustes é LIDO e conta ajustes de verdade: escrita em option gerenciada conta, carimbo de atividade não conta, e ao alcançar o alvo o gatilho DISPARA e zera o contador; com o alvo em zero nada é contado e o estado diz que nada promete disparar; sem periodicidade e sem gatilho o módulo é inerte. O piso planta o defeito: a chave era gravada numa option que ninguém lia, e o relatório prometia gatilho sobre um contador inexistente.',
	'migracao.sobre_site_existente'         => 'toda estrutura que a versão nova acrescenta nasce sobre um site que JÁ RODAVA A ANTERIOR, e não só em instalação limpa. A bancada testava instalação limpa, e o defeito mora na atualização: `garantir_estrutura()` perguntava só pela tabela do resumo, saía cedo em todo site já entregue, e a tabela de registro nunca nascia — sem erro nenhum, com a tela mostrando pessoas diferentes em branco para sempre. O conjunto do que é NOVO não é lista escrita à mão, que envelheceria como a que produziu o defeito: ele é DERIVADO POR EXECUÇÃO — uma instalação limpa roda o caminho de instalação inteiro, e o que ela cria é o que a versão exige. Depois, para cada estrutura, a bancada monta um site que tem todas as outras e não tem aquela, roda só o caminho de ATUALIZAÇÃO — o que uma requisição comum percorre, sem ativação, que é como um plugin é atualizado por cima — e exige que ela nasça. Cobre tabela ausente, COLUNA ausente numa tabela que já existia (a forma mais traiçoeira: a guarda que pergunta só se a tabela existe sai cedo e a escrita passa a falhar em silêncio), option nova que precisa resolver pelo padrão do catálogo, subchave nova dentro de option já gravada, e rota declarada em constante e não registrada. O piso replanta a guarda defeituosa e exige que a varredura acuse.',
	'modulos.nascem_ativos'                 => 'O SITE NASCE COM TUDO ATIVADO, e esta checagem é a prova. Ela monta o site que o implantador entrega — as options gravadas a partir do config/decisoes.tsv e do config/projeto.json REAIS, pelos produtores únicos, com os plugins que o catálogo instala — e exige que todo módulo feche ATIVO. A única inércia legítima é falta de dado que só o operador tem, e ela não é uma lista de exceções: o módulo inerte precisa NOMEAR, no próprio motivo, uma option que está vazia neste site. É assim que o WhatsApp sem número, a CAPI sem token e a verificação de domínio sem token têm álibi, e qualquer outro desligamento é decisão nossa de entregar o site com uma parte apagada. Dentro dela está o caso de produção da 1.3.2: site SEM NENHUM ID de fornecedor tem de servir o coletor de comportamento e GRAVAR linha na tabela — o módulo de tracking fechava inativo por falta de ID, módulo inativo não registra hook, e o coletor do próprio site morria junto de tags que nunca existiram. Os pisos: com a coleta do próprio site desligada e sem ID nenhum o carregador NÃO pode ser servido, desligar o llms.txt por decisão do pacote tem de ser acusado, e o elenco de options desta bancada é conferido contra o do lote real — option acrescentada lá e esquecida aqui derruba a checagem em vez de reduzir o site que ela mede.',
	'modulos.callbacks_executam'            => 'todo callback que um módulo declara é INVOCADO pela suíte, e não apenas lido. Este é o buraco que deixou o site do usuário servindo 141 bytes em toda página: uma variável sombreada fez uma função que promete array devolver booleano, o TypeError estourou dentro do filtro wp_robots no meio do <head>, e as 197 checagens fecharam verde porque nenhuma delas chamava a função. A checagem percorre o registro de módulos, invoca cada hook declarado e prova que não lança e que o retorno honra o tipo — o tipo sai de reflexão sobre a assinatura, não de tabela escrita à mão, porque tabela envelhece e o módulo novo entra sem cobertura. Duas provas: o tipo declarado, e a regra de que FILTRO DEVOLVE O QUE RECEBEU, que cobre os callbacks sem tipo na assinatura. A matriz varre as formas de requisição que trocam de ramo — página, post com e sem noindex gravado, taxonomia, busca, 404, home, arquivo de autor e de data — nos dois estados que um site real tem, recém-instalado e configurado. Os pisos: replantado o defeito de hoje a checagem tem de acusar TypeError, o ramo são tem de passar limpo, e a cobertura tem de bater com o registro — 16 módulos, os hooks que eles declaram e o produto da matriz, senão a bancada teria voltado a carregar menos módulos do que existem, que era o caso.',
);

$rotulos_funcionais['renomeacao.contrato_de_nomes_completo'] = 'o contrato de nomes do plugin cobre TODA option do catálogo, TODO evento declarado e o prefixo de seção — e nada disso é lista escrita à mão: o que ele precisa cobrir é lido do catálogo de options do próprio plugin e da declaração de eventos de comportamento. É o que impede a tabela de envelhecer: uma option nova acrescentada ao plugin e esquecida no contrato voltaria a ser reescrita pela renomeação do lado de quem grava, e o site ficaria com o implantador escrevendo um nome e o plugin lendo outro. O piso é a MESMA função contra um contrato de onde uma grafia exigida foi removida.';
$rotulos_funcionais['migracao.copia_anterior_desativada'] = 'ativar o plugin novo num site que já roda a PASTA ANTIGA desativa a antiga, e diz o que fez. Existe pelo menos um site em produção com o plugin em f3base-site-core 1.3.6: instalar a pasta nova ali deixa duas cópias do MESMO plugin ativas — dois registros de hooks, duas rotas REST para o mesmo endereço, dois coletores na página, conversão contada em dobro —, e o WordPress não impede nem avisa. Não há dado a migrar, e é por isso que o prefixo interno não mudou: as options f3base_* e as tabelas f3base_comportamento e f3base_eventos são as mesmas dos dois lados. O discriminante é a reivindicação do MESMO namespace REST, medida no arquivo principal, e não uma lista de nomes de pasta — lista de nome só reconhece o que alguém lembrou de escrever nela. Os pisos são os falsos positivos, que aqui são o dano maior: plugin de terceiro ativo não é tocado, homônimo sem a marca não é tocado, cópia antiga INATIVA não é tocada, site só com a cópia nova não registra nada, e o hook de desativação da cópia antiga NÃO roda — ele desinstalaria os módulos que a ativação em curso acabou de instalar, porque as chaves são as mesmas.';
$rotulos_funcionais['pacote.plugin_completo_no_zip'] = 'o zip do plugin contém TODO arquivo que a lista de autoload dele exige. A linha existe porque cinco arquivos do plugin não moram na fonte dele: são contrato compartilhado com o implantador, moram em partilhado/ e só entram no zip pela cópia do empacotamento. Um arquivo esquecido nessa cópia não aparece como erro de build — aparece como erro fatal no require_once da ativação, no site do cliente. Os pisos: removida do zip uma entrada que o autoload exige, a regra tem de acusar; e com a lista de autoload vazia ela não pode aprovar, porque escopo vazio não é aprovação.';
$rotulos_funcionais['pacote.instrucoes_do_plugin_no_zip'] = 'o documento de instruções do plugin viaja DENTRO do zip dele, não traz número digitado fora dos blocos gerados, e descreve TODO módulo que existe em includes/. Quem recebe este plugin recebe o zip, e não o repositório: publicá-lo sem o documento entrega o código sem a única explicação de por que ele é assim, e a mudança seguinte desfaz um defeito corrigido sem saber que ele existiu. A cláusula do número é a mesma regra de estatica.carimbo_de_release_nos_documentos um nível abaixo — contagem escrita à mão está certa no dia em que foi escrita e é contradita pela rodada seguinte —, com três isenções declaradas: marcador de lista ordenada, dígito colado a letra (que é NOME) e vão de código cujo conteúdo aparece verbatim na fonte do plugin, que é o que deixa passar um teto do código e barra uma contagem inventada. A cláusula dos módulos é a que impede o documento de envelhecer: as tabelas dele são geradas e acompanham o código sozinhas, e a PROSA não — é ela que diz a pergunta de negócio, quando o módulo fica inativo e o que quebra se alguém mexer nele errado. Os pisos são as MESMAS funções puras contra o defeito plantado: o documento removido da lista de entradas do zip, uma contagem digitada em prosa, um número que a fonte não tem escrito em vão de código, um módulo a mais no escopo sem entrada no documento, e a lista de módulos vazia — que não pode aprovar, porque escopo vazio não é aprovação.';

$rotulos_funcionais['pacote.zip_reprodutivel'] = 'a MESMA árvore empacotada duas vezes dá o MESMO sha256, e hash diferente sobre árvore idêntica é adulteração. É o contrato que o catálogo publica: o implantador FIXA o digesto deste zip na primeira observação e reprova a execução seguinte quando ele muda, então um artefato que muda de bytes sem mudar de conteúdo faria toda implantação seguinte falhar acusando troca que não houve. As duas afirmações de teto saem do ARTEFATO montado, e não do código que o montou: toda entrada carrega a ÉPOCA DECLARADA — o zero do formato zip, que não sai do relógio — e a ORDEM das entradas é a declarada, crescente por byte, e não a que o sistema de arquivos devolve. Os dois defeitos foram medidos com a árvore arquivada: a mesma árvore em dois dias deu 693ca754… e aeb40cad…, e no MESMO dia em dois volumes desta máquina deu 693ca754… no ext4 e 855fabbb… no tmpfs. O piso não é só a lista mutante: o empacotamento é rodado DE NOVO, com o relógio movido por faketime e com o volume trocado, e um mutante do próprio empacotamento — o carimbo de volta ao relógio — PRECISA divergir e ser acusado, senão a alavanca não tem dente e a comparação não prova coisa nenhuma. Máquina sem um segundo sistema de arquivos gravável não aprova em silêncio: a metade que mede a ordem entre volumes sai NOMEADA como não rodada.';
$rotulos_funcionais['comportamento.estrutura_declarada'] = 'as DUAS tabelas do módulo são declaradas e conferidas do MESMO jeito, e o DDL delas é comparável pelo dbDelta. A prontidão de f3base_eventos não entrava em dependencias(), não entrava em calcular_estado() e não era conferida em receber(): um site com a tabela do resumo criada e a do registro não — o caso de toda ATUALIZAÇÃO cuja migração parou no meio — mostrava o módulo ATIVO, a rota respondia 201, e registrar_evento() descartava cada linha devolvendo false em silêncio. Com 2xx o cliente apaga o lote, e a tela dizia "não medido" para sempre. Os tetos: as duas tabelas aparecem nas dependências e o módulo fecha ATIVO com as duas prontas. Os pisos: sem o registro pronto o módulo fecha DEGRADADO, a rota de entrada responde 503 nomeando a tabela e a porta da exclusão responde 503 com apagado=false — confirmar um apagamento que nem chegou a ser tentado é pior que recusar. E o DDL: nenhuma coluna inteira declara largura de exibição, porque o MySQL 8 a descarta ao criar a tabela e o dbDelta passa a emitir um ALTER a cada chamada, para sempre, sem que nada mude; o piso repõe a largura e exige que a regra acuse.';
$rotulos_funcionais['comportamento.teto_por_entrada'] = 'cada CAMPO NUMÉRICO de uma entrada do corpo tem teto DECLARADO, e não só a lista tem tamanho máximo. O teto da lista — a soma dos tetos declarados — limita quantas ENTRADAS cabem; nada limitava o que cada uma carrega dentro, e esta rota é pública, autorizada por um token efêmero impresso em toda página. Os números são os declarados: o teto POR PÁGINA do evento para a contagem, porque ele é por construção o máximo de vezes que o cliente consegue emiti-lo num carregamento, e o teto por medida de dados/vitais.tsv para o valor e para a soma. Os tetos: a contagem exatamente no limite passa, e a soma de duas medidas no teto passa — o teto da soma é o do valor VEZES a contagem, senão ele recusaria medição legítima. Os pisos: contagem acima do teto, soma acima do teto e valor acima do teto são recusados pelo nome e com o limite na resposta; o corte declarado pelo cliente é aparado no orçamento da VISITA, que é o mesmo número que o cliente usa para parar de contar; e detalhe que não nomeia medida nenhuma cai no MAIOR teto declarado, nunca num número inventado no PHP.';
$rotulos_funcionais['medicao.quadro_de_vitais'] = 'a tela mostra as medidas de carregamento com a explicação e a régua ao lado de cada sigla, e a média delas é média. Eram dois defeitos. O primeiro é de AUSÊNCIA: resumo()[vitais] já era calculado, dados/vitais.tsv já trazia a explicação e o limiar, e nenhuma linha da tela chamava qualquer um dos dois — quatro medidas coletadas em toda visita, gravadas, somadas e lidas por ninguém. O segundo é de CONTA: o balde agrupava por detalhe sozinho, sem olhar a métrica, de modo que um marco de rolagem chamado LCP disputava o quadro com a sigla; e excluía as linhas de soma zero, que são justamente o CLS perfeito de uma página firme e o TTFB do cache que respondeu na hora — a média subia por descartar os melhores carregamentos e a amostra dizia menos visitas do que houve. Os tetos: a linha de soma zero entra com a amostra certa, a média é soma dividida por contagem, e a tela imprime a sigla e a explicação de TODA medida declarada. Os pisos: um evento de uso com detalhe de nome igual ao de uma sigla não entra no quadro, e nenhuma explicação declarada aparece escrita dentro do PHP da tela — escrita ali, ela seria uma segunda descrição da mesma medida.';
$rotulos_funcionais['medicao.tela_declara_o_recorte'] = 'a tela não afirma recorte que a consulta não fez, e diz qual é o período e qual é o fuso do dia. Eram três defeitos. Um filtro fora da forma do apelido era DESCARTADO pela consulta e ANUNCIADO pela tela — "Mostrando apenas o visitante joao@exe" sobre uma tabela com todos os visitantes, e quem lia concluía que aquele visitante tinha feito tudo aquilo. dias_no_painel e retencao_eventos_dias são chaves independentes: com o painel somando mais dias do que o registro guarda, os quadros de uma tabela e os da outra cobriam períodos diferentes dizendo o mesmo número. E o corte por dia é UTC nas duas tabelas enquanto a coluna Horário sai em wp_date(), no fuso do site — a diferença é real perto da virada e a tela não a declarava. Os tetos: o filtro bem formado recorta e é anunciado; a frase do fuso tem produtor único no módulo. Os pisos: o filtro mal formado não é anunciado como recorte e SAI NOMEADO como ignorado, e o aviso do período só aparece quando o painel de fato passa do prazo do registro — aviso que aparece sempre deixa de ser lido.';
/*
 * OS RÓTULOS DA FRENTE B vêm no fim, acrescentados como os quatro acima: a
 * ordem do array é a ordem de emissão, e inseri-los no meio reordenaria o
 * relatório inteiro sem que nenhum veredito tivesse mudado.
 */
$rotulos_funcionais['leads.registro_fiel_ao_recebido'] = 'o que o navegador MANDOU chega ao registro do lead, e o que fica gravado é o que foi MEDIDO. Duas coisas, com a mesma forma de defeito. O CARIMBO DO CLIQUE — clicado_em e clicado_em_ms — está no schema fechado, tem formato declarado e é recusado quando não casa; ele não era gravado em lugar nenhum, e o que sobrava no registro era o relógio do SERVIDOR na hora da chegada, em outro fuso e outro instante. É por data e hora que se casa a conversa que chegou no WhatsApp com o clique que a originou, e era exatamente essa data e hora que faltava. Ele passa a sair no metadado técnico E legível ao lado dos outros campos, porque quem faz o casamento está olhando as duas listas. O CONSENTIMENTO passa a ser o estado medido, num vocabulário fechado de três valores: sim e não são decisão explícita do titular, padrao-pre-aprovado é a ausência de decisão sob a política pré-aprovada. O campo booleano do navegador é o PORTÃO das tags, e ele vale verdadeiro quando ninguém decidiu: arquivá-lo como "sim" punha em todo lead do site uma decisão que não existiu. Os pisos são os três casos medidos um a um, com os três valores distintos entre si e dentro da lista fechada.';
$rotulos_funcionais['leads.token_com_escopo'] = 'o token efêmero do endpoint tem ESCOPO e vida curta, e a página em cache tem tratamento em vez de torcida. A assinatura cobria SÓ a expiração e valia doze horas: um token colhido em qualquer página — ele é impresso no HTML de todas — autorizava qualquer POST de registro por meio dia. Agora ela cobre a rota e o caminho da página, com uma hora de vida e teto no filtro, e o token da home não vale num POST que diz vir de outra página. A barra final e a query NÃO distinguem escopo, e a segunda é a que importa: incluir a query faria todo lead de tráfego pago voltar recusado. O outro lado é a página servida de cache mais velho que o prazo, que faria todo beacon voltar 403 — para ela existe a rota GET de emissão, sem nonce porque o token é público por natureza, limitada pelo MESMO balde do registro, e o cliente troca o token e reenvia UMA vez. E a recusa por token passou a CARIMBAR a atividade com a página: ela era muda, e um site podia estar perdendo lead há semanas com o módulo verde na tela.';
$rotulos_funcionais['leads.contingencia_visivel'] = 'a listagem dos leads de contingência aparece enquanto existir lead gravado nela. Ela só existia quando o Flamingo estava AUSENTE, e o percurso normal de um site é o contrário: a caixa única entra depois, e no instante em que ela é ativada os leads que a contingência gravou continuam no banco — com dado pessoal dentro — e a única listagem que os mostrava desaparece do menu. Eles não migram, ninguém é avisado, e não há por onde lê-los nem por onde apagá-los. Os pisos: sem lead nenhum a listagem continua fora do menu, porque listagem sem nada para mostrar é ruído ao lado da caixa que tem tudo; e tornar a listagem visível ao operador não pode abrir o tipo ao público nem ao REST.';
$rotulos_funcionais['origem.cabecalho_como_veio'] = 'a leitura pela origem devolve o cabeçalho COMO ELE VEIO. Ela passava a resposta por array_map(strval), e cabeçalho repetido — Link, Set-Cookie, Vary de emissores diferentes, Cache-Control de CDN — chega da camada HTTP como LISTA: strval() de um array devolve a string "Array" e emite um aviso do PHP. O instrumento cujo papel inteiro é dizer o que o servidor emitiu apagava justamente o cabeçalho emitido duas vezes, que é o caso que se vai ler quando se desconfia de emissor concorrente. Escalar sai texto, repetido sai lista, e o campo de conveniência do redirecionamento aponta para o PRIMEIRO Location em vez de virar "Array" também.';
/*
 * FRENTE D — os rótulos das checagens da sonda do site-core acrescentadas com a
 * correção dos módulos restantes e do contrato partilhado.
 */
$rotulos_funcionais['seo.llms_emissor_cruza_plugin'] = 'quem emite o llms.txt e quem serve o sitemap são medidos CRUZANDO duas perguntas: a chave gravada na option do plugin de SEO E o plugin na lista de ativos. O defeito que isso fecha é o da option órfã: `enable_llms_txt` e `enable_xml_sitemap` sobrevivem à desativação do plugin, e lendo só a chave este pacote cedia o endereço público a um emissor que já não emite — /llms.txt virava 404 permanente com o módulo dizendo ATIVO, e o rodapé do arquivo apontava um sitemap que ninguém serve. O piso é a option órfã: com a chave ligada e o plugin DESATIVADO não há concorrente, a rota volta a servir e o endereço do sitemap sai vazio. O teto é o concorrente de verdade, que continua tirando a rota de cena. O slug do plugin sai do vocabulário compartilhado, nunca de literal.';
$rotulos_funcionais['seo.llms_primeira_frase_declarada'] = 'a primeira frase do arquivo é a que a TELA promete: o campo se chama "Primeira frase do arquivo" e diz que, vazia, o site usa a apresentação abaixo — e o código lia a apresentação primeiro. Quem preenchesse os dois publicava o que a tela chamava de reserva, e nada acusava. A regra mora num lugar só e vale para os DOIS arquivos: dois arquivos com duas ordens seriam dois vereditos sobre o mesmo site. Os pisos: a apresentação só aparece com a introdução vazia, a descrição do WordPress só com as duas vazias, e o texto do campo continua prometendo o que o código faz — sem essa última metade, a precedência voltaria a ser uma escolha sem texto que a sustente.';
$rotulos_funcionais['seo.llms_carimbo_por_rota'] = 'dois endereços públicos são duas atividades: /llms.txt e /llms-full.txt gravavam o MESMO carimbo, e a resposta de um apagava a do outro — a tela mostrava uma linha de "última resposta" que ora falava do índice, ora do texto integral, sem dizer qual. E o cabeçalho X-F3Base-Mecanismo saía com o literal rota-reserva nos dois, isto é, um cabeçalho de diagnóstico que não distinguia nada. Os pisos: a resposta do índice curto não pode aparecer como resposta do texto integral, o mecanismo é ARGUMENTO de responder() e não literal, e a rota do texto integral carimba na chave dela — o MESMO leitor roda contra a forma antiga e tem de acusar as duas coisas.';
$rotulos_funcionais['schema.faq_so_no_singular'] = 'o FAQPage só é lido em requisição SINGULAR. `get_queried_object_id()` devolve um id em toda requisição — o do TERMO num arquivo de categoria, o do AUTOR num arquivo de autor —, e esses ids colidem com ids de post: sem a guarda, o arquivo da categoria 12 emitia o FAQ do post 12, schema afirmando sobre uma página que não está sendo exibida. Os pisos são o arquivo de termo e o de autor com o mesmo id consultado. O teto que a guarda não pode custar: com o id INFORMADO a leitura fora do laço continua funcionando, que é como o filtro f3base_faq_detalhes e a bancada leem um post.';
$rotulos_funcionais['schema.same_as_une'] = 'sameAs é UNIÃO, e as demais propriedades de entidade só gravam chave ausente. A diferença é de natureza: sameAs é uma lista de perfis — o plugin de SEO emite os que conhece, a configuração declara os que ele não conhece, e a resposta certa é o conjunto dos dois sem repetição —, enquanto areaServed já emitida foi escrita por quem configurou o plugin. O docblock dizia "só grava chave ausente" e o código sempre reescrevia: as duas leituras estavam erradas. Os pisos: nenhum dos dois lados pode sumir, a união não repete o perfil que existe dos dois lados, areaServed já emitida continua intocada, e o docblock precisa dizer união.';
$rotulos_funcionais['seguranca.cabecalho_cede_a_quem_chegou_antes'] = 'a emissão não atropela outro emissor, e a regra tem duas metades porque os cabeçalhos têm duas naturezas. `header()` com o $replace padrão SUBSTITUI: num site com CSP emitida por um plugin de segurança, a política inteira dele era trocada pela nossa linha de frame-ancestors, e uma Permissions-Policy mais restritiva era afrouxada para a nossa. A CSP COMPÕE — a especificação manda aplicar a INTERSEÇÃO, então a segunda linha só aperta —, e os demais só saem quando ausentes em headers_list(). Os pisos: Referrer-Policy e Permissions-Policy já postas não podem ser substituídas, a CSP tem de continuar saindo, e o que foi cedido sai NOMEADO no estado — ceder em silêncio é a mesma cegueira ao contrário.';
$rotulos_funcionais['seguranca.frame_ancestors_na_forma'] = 'csp_frame_ancestors é validado na FORMA antes de virar cabeçalho, e esta é a única forma deste pacote que RECUSA em vez de só avisar: o que está do outro lado não é um valor opaco de fornecedor, é uma DIRETIVA que o navegador executa. `sanitize_text_field()` preserva o ponto e vírgula, e o ponto e vírgula ENCERRA a diretiva — "frame-ancestors \'self\'; script-src \'unsafe-inline\'" é um CSP inteiro escrito pelo campo da moldura, com efeito sobre todo script da página. Os pisos são as seis formas que não passam: o ponto e vírgula, \'none\' acompanhado, origem sem https, origem sem esquema, a palavra sem aspas e o curinga solto. E as duas metades da regra da 1.1.0: o valor fora da forma é PRESERVADO no que está gravado, e o aviso NOMEIA o engano em vez de a chave sumir em silêncio.';
$rotulos_funcionais['seguranca.cabecalhos_alcancam_rest'] = '`send_headers` não roda em toda resposta da API REST, e o corpo JSON saía sem nosniff, sem Referrer-Policy e sem HSTS — a mesma superfície que o HTML tem. O recorte é decisão DECLARADA no cabeçalho do módulo: vão para o REST os cabeçalhos que governam a RESPOSTA; ficam de fora Cross-Origin-Opener-Policy e Permissions-Policy, que governam um contexto de navegação de topo que um corpo JSON não abre. Os pisos: o gancho tem de existir, os dois excluídos não podem entrar no recorte, e o filtro devolve exatamente o que recebeu — quem decide se o corpo já foi servido é o núcleo, e trocar esse valor seria este módulo respondendo pela requisição de outro.';
$rotulos_funcionais['vocabulario.cabecalhos_governados'] = 'governar no vocabulário e não reconhecer no runtime é pior que não governar: `cabecalhos.permissions_policy` estava declarada como governada e o sanitizador a aceitava por sanitize_text_field, isto é, aceitava qualquer coisa; `cabecalhos.csp_frame_ancestors` não estava declarada e também não era conferida em lugar nenhum — a linha da tabela afirmava uma recusa que não acontecia. O cruzamento é o que torna duas fontes seguras: toda chave governada existe, todo valor que o vocabulário aceita passa na forma que o módulo exige, e o PADRÃO gravado no catálogo de options está dentro do conjunto. O piso é o valor com ponto e vírgula, que o vocabulário não declara e a forma do módulo recusa.';
$rotulos_funcionais['retencao.corte_em_calendario'] = 'o prazo declarado é em MESES e o corte é contado em CALENDÁRIO. `MONTH_IN_SECONDS` é trinta dias: "guardar por 12 meses" virava 360 dias — cinco dias e pouco a menos por ano —, e registro apagado cinco dias antes do prazo é apagado antes do prazo, sem que nada dissesse isso. Os pisos: doze meses caem no mesmo dia do ano anterior, seis meses no mesmo dia seis meses atrás, a conta por trinta dias tem de dar diferente, prazo zero cai no mínimo de um mês, e a frase de estado DIZ a data de corte — sem ela, "12 meses" continua podendo significar 360 dias sem ninguém saber.';
$rotulos_funcionais['retencao.desagendamento_com_teto'] = 'o laço de desagendamento tem teto declarado e confere o retorno. `wp_unschedule_event()` pode falhar devolvendo false COM O EVENTO AINDA LÁ — outro processo mexendo no array do cron, um filtro de terceiro recusando, um cron object corrompido —, e um laço que só pergunta while ( false !== wp_next_scheduled() ) recebe o mesmo carimbo para sempre: a desativação do plugin não termina, e o operador vê a tela do wp-admin pendurada até o limite de tempo do PHP. Os dois módulos com evento próprio são medidos, e o piso é o MESMO leitor contra a forma antiga, sem teto e sem conferência. O teto que o limite não pode custar: com o evento agendado, a desinstalação continua removendo.';
$rotulos_funcionais['redirects.par_que_gira_recusado'] = 'o par cuja origem e destino normalizam para o MESMO caminho é recusado na hora de servir, e não só no sanitizador: o par pode ter sido gravado por uma versão anterior deste pacote, por outro agente ou à mão no banco, e quem serve a requisição é o módulo. O defeito medido: o sanitizador recusava de === para no TEXTO CRU e o comparador normalizava barra final e query, então /servicos/ para /servicos passava nos dois e girava para sempre. Os pisos: a barra final e a query são normalizadas dos dois lados, um par de verdade NÃO pode ser tratado como laço, e o par recusado sai NOMEADO no estado — sem o nome, o operador não teria como saber qual endereço parou de redirecionar.';
$rotulos_funcionais['partilhado.contrato_declarado'] = 'as quatro classes partilhadas rodam em DOIS runtimes que não se enxergam, vêm guardadas por class_exists e o docblock de cada uma diz a verdade sobre onde ela mora e o que ela usa. Três defeitos moravam ali: o censo era a única das quatro SEM a guarda — e sem ela um processo que carregue os dois runtimes morre em "Cannot declare class" —, as quatro diziam que o implantador lê a "cópia de origem" daqui quando é ele quem VENDORIZA uma cópia, e as quatro afirmavam que o censo "não usa nada do WordPress" enquanto ele usa $wpdb->prepare() e get_post_types(). O piso é o MESMO leitor contra o texto que estava nas quatro, e ele tem de acusar as três coisas.';
$rotulos_funcionais['cadencia.frase_nomeia_o_evento'] = 'o comentário de tradução descreve o ARGUMENTO que a frase recebe, e o desta descrevia outros três: dizia "1: recorrência declarada, 2: data e hora previstas, 3: gatilho por ajustes" sobre uma chamada que passa o NOME DO EVENTO, a RECORRÊNCIA e a DATA. Quem traduz o pacote reordena a frase pelo comentário, e o estado passa a dizer outra coisa. O piso é o MESMO leitor contra o comentário antigo. E a frase que SAI é medida: ela nomeia o evento, depois a recorrência, depois a data — a ordem que o comentário declara.';
$rotulos_funcionais['cadencia.previsao_so_com_evento'] = 'a previsão da próxima execução só é gravada quando o agendamento deu certo. `wp_schedule_event()` devolve false quando a recorrência não existe no núcleo daquele processo — e é exatamente o que acontece na ATIVAÇÃO, em que init já passou sem o plugin —, e gravar previsto mesmo assim inventa um horário que evento nenhum vai cumprir: o carregamento seguinte mede atraso contra ele, encontra horas de atraso e degrada o módulo por uma execução que nunca foi agendada. Os pisos: sem as recorrências próprias registradas o núcleo recusa f3base_mensal e a previsão NÃO pode ser gravada; com elas registradas o evento é agendado e a previsão sai; e o gancho de ativação precisa registrá-las, que é o que faz a ativação agendar no mesmo processo.';

$rotulos_funcionais['options.normalizacao_avisa'] = 'quem grava fica sabendo o que ficou gravado, e isso valia SÓ para valor ESCALAR: gravar() testava is_scalar( $valor ) antes de dizer que a sanitização tinha mudado alguma coisa, e treze das options deste catálogo são GRUPO. Quem gravasse um grupo com um campo fora da forma recebia ok verdadeiro e silêncio — a leitura de volta CONFERIA, porque ela compara o normalizado com o normalizado, e quem discordava era a ENTRADA, que ninguém comparava. Agora a comparação é POR CAMPO e o aviso NOMEIA o campo. A outra metade é a RECUSA, que existe onde normalizar significaria o contrário do que foi pedido: retencao_meses = 0 era elevado a 1 em silêncio — o prazo mais curto possível, e a rotina do dia seguinte apagava todo contato com mais de um mês —, e passa a ser recusado com o prazo anterior de pé; o par de redirect cuja origem e destino normalizam igual não entra e sai nomeado; e o csp_frame_ancestors fora da forma não substitui um valor bom. Os pisos: a gravação limpa não pode produzir aviso, um campo que não mudou não pode entrar na lista, e a recusa não pode reescrever o que estava gravado.';
$rotulos_funcionais['options.sanitizador_idempotente'] = 'sanitizar duas vezes dá o mesmo que sanitizar uma, para TODA option do catálogo. Isto não é elegância: gravar() compara o que sanitizou com o que RELEU do banco, e a releitura sanitiza de novo — um sanitizador não idempotente faz a leitura de volta acusar divergência numa gravação que não tinha nada de errado, e quem opera vê que o valor lido de volta não é o valor gravado sem ter feito nada. O defeito medido era sanitiza_llms(): politica_privacidade AUSENTE virava lista vazia na primeira passagem e, na segunda, a chave EXISTIA e virava o objeto de quatro campos vazios. Os tetos: o padrão de cada option e o valor que volta do banco depois de uma gravação. O piso é a bancada reproduzindo a forma antiga, que tem de dar resultado diferente na segunda passagem — sem isso o teto aprovaria por acaso.';
$rotulos_funcionais['options.proveniencia_de_configuracao'] = 'a procedência responde quem escolheu este valor, e a pergunta não se aplica a um carimbo de execução: ninguém ESCOLHEU que a última limpeza foi às 3h12. Três defeitos se somavam. TODA gravação registrava procedência, inclusive f3base_atividade, que a rota PÚBLICA do beacon escreve a cada visita — a option de procedência era reescrita uma vez por visitante. Ela era gravada com autoload ligado, e escrita sobre option autoloaded INVALIDA o alloptions do site inteiro: somando os dois, uma invalidação do cache de options por visitante. E a entrada era RECONSTRUÍDA com origem e carimbo, apagando valor_hash e release — as chaves com que o implantador sabe se a option continua sendo a que ele escreveu, e sem elas ele passa a tratar como alterada à mão uma chave que ele mesmo gravou. Os pisos: carimbo de atividade não escreve procedência nenhuma, a option não é autoloaded, e as chaves do implantador sobrevivem quando o valor não mudou. O teto do outro lado: quando o valor MUDA, a marca dele sai, porque ali ela deixou de valer.';
$rotulos_funcionais['options.journal_corta_na_escrita'] = 'o journal de eliminação existe para provar o que foi apagado e quando, e ele tinha dois defeitos que se somavam. O CORTE ACONTECIA NA LEITURA — o sanitizador roda também em ler() —, então a option continuava INTEIRA no banco e o que a tela mostrava era um recorte dela; e o corte descartava as MAIS ANTIGAS, que numa lista de auditoria são justamente as que alguém procuraria, sem deixar marca nenhuma. E o campo DESCONHECIDO era preservado enquanto o docblock prometia descartar: é por essa porta que o conteúdo do lead volta para dentro da option que existe para provar que ele saiu. Agora o teto é declarado no catálogo, o corte acontece só na ESCRITA e deixa uma entrada dizendo QUANTAS saíram e DESDE QUANDO, e essa entrada sobrevive à leitura seguinte. A mesma regra vale para a auditoria de escritas do canal, que não tinha teto nenhum e era autoloaded. Os pisos: a leitura de uma lista acima do teto tem de devolvê-la inteira, a escrita tem de cortar e registrar, e descartar o desconhecido não pode virar descartar a entrada.';

$funcionais = f3b_ck_funcionais( $raiz, $suite );

foreach ( $rotulos_funcionais as $nome => $msg_ok ) {
	if ( ! isset( $funcionais[ $nome ] ) ) {
		estado( 'BLOCKED', $nome, 'a sonda funcional não devolveu veredito para esta checagem.', 'pendencia-externa', 'build' );
		continue;
	}

	$r = $funcionais[ $nome ];

	estado_por_origem(
		(bool) $r['ok'],
		'site',
		$nome,
		$msg_ok . ' ' . (int) $r['medidas'] . ' asserção(ões).',
		count( $r['achados'] ) . ' achado(s): ' . f3b_amostra( $r['achados'] ),
		'teste-funcional',
		'build'
	);
}

emitir( f3b_ck_js_limite_do_cliente( $raiz, $suite ), 'js.limite_do_cliente', 'o corte do cliente de leads usa a MESMA unidade que o servidor publica e recusa — caracteres —, com a função pura extraída do arquivo REAL: o texto acentuado no limite não é cortado, o de um caractere acima é cortado para o limite em caracteres, o par substituto não é partido ao meio e campo sem limite publicado sai intacto. O piso planta o defeito: o mesmo texto excede o limite em bytes, que era a unidade do servidor.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_conversao( $raiz, $suite ), 'js.conversao_multicanal', 'o clique do CTA é a conversão do site e ela sai nos quatro canais, medida no cliente REAL rodado de ponta a ponta: generate_lead SEMPRE — o formulário é opcional, o clique é o lead —, a conversão do Ads com send_to montado das duas metades, o Lead da Meta com eventID para a deduplicação futura, o track do LinkedIn com o ID declarado, e os identificadores de clique (gclid, fbclid, li_fat_id) chegando ao lead junto do _fbc no formato da Meta. O href do agente sobrevive ao clique e continua sendo medido. Os pisos: no caminho do container nenhum disparo direto acontece nem com os IDs presentes, e com slot vazio nada dispara e o lead continua registrado.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_comportamento( $raiz, $suite ), 'js.comportamento_instrumentado', 'o site NASCE INSTRUMENTADO, e o que ele emite é medido no dataLayer com o carregador real rodado contra a plataforma de mentira. Os seis coletores: marcos de rolagem — um por marco declarado, uma vez cada, e voltar ao fim não repete —; seção vista pelo NOME que o markup declara, uma vez por nome, e seção sem a classe não é medida; clique em link externo com o HOST e só ele, sem caminho e sem query; fricção no limiar declarado; erro de JavaScript com a origem como PORTÃO — site emite, terceiro e ambiente não —; e LCP, CLS, INP e TTFB por PerformanceObserver nativo, sem biblioteca externa, relatados uma vez no primeiro ocultamento da página. Os pisos são o FALSO POSITIVO e a RAJADA: duplo clique, triplo clique — o gesto de selecionar um parágrafo —, cliques espalhados além do raio, cliques em controles diferentes e cliques repetidos em texto não podem produzir fricção; erro de terceiro, de extensão do navegador e sem arquivo não podem virar erro do site; a rajada de erros tem de bater no teto declarado; um segundo ocultamento não pode relatar os vitais de novo; e com o consentimento negado ou com o slot vazio nada é emitido. Todo payload é varrido contra a declaração: nenhum evento fora dela, nenhum parâmetro fora dela, e nenhum identificador pessoal em nenhum deles.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_resumo( $raiz, $suite ), 'js.resumo_da_sessao', 'o RESUMO DA SESSÃO é medido no corpo que o sendBeacon levaria — exatamente o que o servidor recebe — com o carregador real rodado contra a plataforma de mentira. Uma sessão produz UM envio, no primeiro ocultamento da página, e ele carrega token, caminho e a lista de totais, e nada mais. As recusas são pisos: sem consentimento nada sai, nem para a conta de medição nem para o site; nenhum identificador de visitante é gravado em armazenamento nem em cookie, porque a sessão vive na memória da aba; o caminho vai sem a query que a URL da bancada tem de propósito, com utm_content e e-mail dentro; o arquivo do erro de JavaScript não viaja, e o link externo entrega o HOST e nada mais; nenhum nome de evento declarado aparece no payload, porque o cliente manda o GATILHO e quem resolve o nome é o servidor; a aba que vai e volta manda uma vez só; e sem sendBeacon a sessão se perde sem levar junto a instrumentação. E os dois destinos são independentes nos dois sentidos: com o resumo desligado a conta de medição continua recebendo, e sem ID de medição nenhum o dataLayer fica vazio enquanto o resumo do próprio site é enviado — que era exatamente o buraco da 1.1.3.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_releitura( $raiz, $suite ), 'js.sessao_com_releitura', 'o CICLO QUE O USUÁRIO DESCREVEU, rodado contra o cliente REAL: carrega, desce até o fim, volta ao topo, desce de novo, sai. Até a 1.1.1 o marco alcançado ficava marcado para o resto do carregamento e a segunda descida não produzia nada — a pergunta "ela voltou e leu de novo?" não podia ser respondida porque o dado não existia. Agora o marco é rearmado quando o visitante sobe abaixo dele, e a bancada prova as quatro entregas do registro: a segunda travessia existe, a OCORRÊNCIA distingue a primeira da segunda (sem ela as duas linhas são indistinguíveis, e releitura fica igual a duas páginas lidas), o CARIMBO de milissegundos permite calcular o tempo até cada marco e é crescente do marco menor para o maior, e o AGREGADO não dobra — somar releitura no total do painel transformaria uma pessoa inquieta em audiência que não existe. Os pisos: o teto declarado de travessias por sessão corta o excesso em vez de deixar a tabela crescer com rolagem inquieta; dois navegadores na mesma página no mesmo dia recebem apelidos DIFERENTES, senão a contagem de pessoas funde duas numa; e a recusa no controle do rodapé apaga o apelido do navegador E pede a exclusão do registro ao servidor, porque apagar só num dos dois lados faz o próximo aceite ressuscitar o mesmo identificador. E o CICLO DIRIGIDO SÓ POR ROLAGEM, que é o que a bancada não sabia fazer: as seções do documento falso ganharam topo e altura, rolar move todas elas, e o retorno do observador sai com a RAZÃO de interseção — inclusive o retorno intermediário, com o alvo ainda sobreposto e a razão abaixo do limiar, que é onde o defeito morava. Numa página curta em que dois blocos nunca saem inteiros da tela, os três blocos e os quatro marcos têm de sair com ocorrência 1 e 2; e o piso é a MUTAÇÃO do código antigo — observar com o limiar declarado e decidir a saída por isIntersecting, que é razão ZERO —, que tem de deixar os dois blocos presos numa ocorrência só. Foi esse código que produziu 80 linhas com ocorrencia 1 e nenhuma reentrada em produção. O último piso é a BANDA do marco: tremer um ponto percentual na fronteira não pode fabricar travessia, e removida a banda a mesma bancada tem de acusar.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_ciclo( $raiz, $suite ), 'js.ciclo_de_vida_da_pagina', 'o CICLO DE VIDA REAL da página, rodado contra o cliente REAL: numa navegação normal o navegador emite visibilitychange para hidden E pagehide no mesmo carregamento, e os dois chamam o mesmo relator. As quatro formas de saída são medidas — os dois eventos juntos, só pagehide, só visibilitychange, e a aba que volta a ficar visível e é ocultada de novo —, cada uma com e SEM interação do visitante, e em todas cada métrica é contada uma vez e o resumo sai uma vez. O carregamento sem interação é o que expõe a falha: sem INP sobra folga sob o teto por página, e é ela que torna a repetição visível — com as quatro métricas o próprio teto absorveria o segundo relato e uma trava removida passaria despercebida. O piso planta o defeito no cliente real e exige que a bancada o acuse. A PROFUNDIDADE entra aqui porque tem a mesma natureza: o marco sai da altura DAQUELA página, relida a cada medição; página curta conta como lida inteira, página longa não emite marco sem rolagem, e a página que ainda está carregando não pode queimar os quatro marcos antes de as imagens entrarem — era essa a assinatura do relatório do usuário, com 25, 50, 75 e 90 empatados. E a seção vista: com seções marcadas o evento sai, sem nenhuma marcada ele cala.', 'teste-funcional', 'build' );
emitir( f3b_ck_js_ordem( $raiz, $suite ), 'js.ordem_do_consentimento', 'a ORDEM DE EXECUÇÃO medida, e não a string do atributo: os DOIS clientes reais rodados contra um escalonador que é o modelo da especificação — bloqueante na posição do parser, defer depois do parse e NA ORDEM DO DOCUMENTO, async sem ordem com nada — e a linha do tempo lida no dataLayer e em cada tag de script externo inserida. Os tetos: com o consentimento ADIADO o consent default continua chegando antes de o gtag.js ser pedido, e a linha do tempo é IGUAL à do consentimento bloqueante — é essa igualdade que autoriza tirar o script do caminho crítico; no modo opt-in com o script bloqueante, o denied chega antes do primeiro page_view de um emissor concorrente; e em pré-aprovado o default que chega tarde é granted, que é o que torna o atraso inócuo, porque ausência de default é granted para o fornecedor. Os pisos: inverter a decisão — defer no modo opt-in — tem de aparecer como o primeiro page_view saindo ANTES do denied, e o carregador rodando antes do consentimento tem de aparecer como gtag.js pedido sem default nenhum, com permiteTags() caindo na decisão de reserva do servidor.', 'teste-funcional', 'build' );

/*
 * A SONDA DE NAVEGADOR, e ela é a única linha desta suíte medida FORA de uma
 * simulação. Sem Chromium ela fecha N/A COM A CONDIÇÃO DECLARADA, e nunca OK:
 * um ambiente sem navegador não é um pacote aprovado, e verde sobre medição que
 * não aconteceu é o instrumento mentindo com a melhor cara possível.
 */
$navegador = f3b_ck_navegador_real( $raiz, $suite );

if ( 'ausente' === $navegador['ambiente'] ) {
	estado( 'N/A', 'navegador.comportamento_real', 'condição declarada: ' . $navegador['condicao'] . '.', 'teste-funcional', 'build' );
} else {
	emitir(
		$navegador,
		'navegador.comportamento_real',
		'o cliente ENTREGUE — o de dist/entregue/, sem comentário, que é o que o visitante baixa — rodado num Chromium REAL, dirigido só por rolagem, numa página de geometria de site real: quatro seções de uma tela cada, faixa rolável de três telas, com a classe que o tema carimba lida de prefixoSecao e a declaração de eventos GERADA do TSV na hora. '
			. 'Dois percursos. O LONGO desce até o fim, volta ao topo e desce de novo, com um ocultamento no meio: as quatro seções e os quatro marcos saem com a sequência de ocorrências afirmada, sem buraco. O CURTO é o do relatório do usuário — sobe três passos perto do fim e desce de novo —, e nele as seções do topo saem com UMA ocorrência, o que está certo: ninguém voltou a elas. Ausência de reentrada não é perda, e quem responderia por perda é o corte, medido em zero nos dois percursos. '
			. 'Zero erro de página, zero cortada, e o lote CHEGOU ao servidor — não basta o cliente ter despachado. '
			. 'O PISO é a assimetria da 1.3.3 plantada no cliente entregue: com a saída decidida por isIntersecting e o observador armado só com o limiar declarado, o bloco cuja razão desce a 0,1 sem nunca zerar tem de ficar preso em uma ocorrência. É a prova de que esta sonda mede o que a bancada não media — quatro releases seguidas a bancada aprovou o que o navegador reprovou, e ela simula IntersectionObserver enquanto o navegador tem um.',
		'teste-funcional',
		'build'
	);
}

/* ---------- entregáveis ---------- */

foreach ( array_keys( f3b_entregaveis( $raiz ) ) as $nome ) {
	$r = f3b_ck_entregavel( $raiz, $nome );

	if ( $r['ok'] ) {
		estado( 'OK', $nome, 'entregável presente e completo.', 'analise-estatica', 'build' );
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		'entregável incompleto. Arquivo(s) que falta(m): ' . f3b_amostra( $r['achados'], 8 ) . '.',
		'analise-estatica',
		'build'
	);
}

/* ---------- condicionais que este projeto não instancia ---------- */

$config = f3b_config( $raiz ) ?? array();
/**
 * O REGIME EXISTE? A resposta sai do VALOR do destino, e de mais nada.
 *
 * A 1.0.19 tirou o interruptor `ativo` da entrada do formulário: havia dois
 * fatos podendo discordar — o interruptor e o destino —, e eles discordavam. O
 * regime whatsapp era declarado ATIVO e fechava BLOCKED por falta de destino na
 * mesma execução. Presença de valor é a condição, e uma condição só.
 *
 * @param array<string,mixed> $config Configuração inteira.
 * @param string              $regime Regime declarado.
 * @return bool
 */
function f3b_regime_existe( array $config, string $regime ): bool {
	foreach ( (array) ( $config['formularios'] ?? array() ) as $formulario ) {
		if ( ! is_array( $formulario ) || $regime !== ( $formulario['regime'] ?? '' ) ) {
			continue;
		}

		$caminho = (string) ( $formulario['destino'] ?? '' );

		if ( '' === $caminho ) {
			continue;
		}

		$valor = $config;

		foreach ( explode( '.', $caminho ) as $segmento ) {
			if ( ! is_array( $valor ) || ! array_key_exists( $segmento, $valor ) ) {
				$valor = '';
				break;
			}

			$valor = $valor[ $segmento ];
		}

		if ( is_scalar( $valor ) && '' !== trim( (string) $valor ) ) {
			return true;
		}
	}

	return false;
}

$whatsapp_existe = f3b_regime_existe( $config, 'whatsapp' );

/*
 * O SEGREDO NÃO ESTÁ NO PACOTE, e a condição é MEDIDA — nunca declarada e
 * pronta. `f3b_segredos_declarados()` lê a âncora do próprio pacote e o
 * detector `estatica.segredo_fora_da_configuracao` mede a ausência; aqui a
 * mesma medida decide se a checagem do envio de servidor é inaplicável (não há
 * token, e não pode haver) ou pendência externa (alguém declarou um, e aí o que
 * falta é uma conta real para responder).
 */
$segredos_declarados = f3b_segredos_declarados( $raiz );
$config_bruta        = (string) @file_get_contents( $raiz . '/config/site.json' );
$segredo_no_pacote   = false;

foreach ( $segredos_declarados['nomes'] as $nome_do_segredo ) {
	if ( str_contains( $config_bruta, $nome_do_segredo ) ) {
		$segredo_no_pacote = true;
		break;
	}
}

$verificacao = (array) ( $config['verificacao_dominio'] ?? array() );
$sem_token_de_verificacao = '' === trim( (string) ( $verificacao['google'] ?? '' ) )
	&& '' === trim( (string) ( $verificacao['meta'] ?? '' ) );

$condicoes = array(
	'formulario.destino_privado'       => ! $whatsapp_existe,
	'capi.envio_de_servidor'           => ! $segredo_no_pacote,
	'verificacao.dominio_declarada'    => $sem_token_de_verificacao,
);

/* ---------- o que este ambiente não pode medir ---------- */

$wp_root = (string) getenv( 'F3BASE_WP_ROOT' );
$tem_wp  = '' !== $wp_root && is_file( rtrim( $wp_root, '/' ) . '/wp-load.php' );

/*
 * APLICABILIDADE POR FASE — a correção da 1.1.6, e ela é de categoria.
 *
 * Até a 1.1.5 esta tabela inteira saía em BLOCKED, e BLOCKED estava dizendo
 * DUAS coisas que o leitor não consegue separar: "falta alguém fazer alguma
 * coisa" e "esta fase não produz este tipo de evidência, por desenho". Medido:
 * 27 linhas amarelas numa rodada impecável, 26 delas do segundo tipo — e
 * amarelo que sai numa rodada sem defeito ensina o operador a ignorar amarelo.
 *
 * A regra vem da classe que o HOST executa, `F3Base_Imp_Fases`, alcançada por
 * subprocesso: fase declarada diferente da fase corrente é condição de
 * aplicabilidade FALSA, e o contrato manda fechar N/A com a condição declarada.
 * BLOCKED fica reservado para pré-condição ausente NA FASE CERTA — e a fase
 * `build` continua sendo a fase desta rodada, então tudo o que é medido aqui
 * continua sendo cobrado aqui.
 *
 * A REGRA SOZINHA ESCONDERIA DEFEITO, e o contrapeso é obrigatório: quem impede
 * um N/A eterno de virar aprovação por omissão é a própria fixture de piso,
 * logo abaixo, que declara o que cada fase espera e acusa a fase que nunca
 * rodou. Uma sem a outra não pode ser instalada.
 */
$aplicabilidade = f3b_aplicabilidade_por_fase(
	$raiz,
	$suite,
	array_map( static fn( array $d ): string => (string) $d['fase'], f3b_bloqueadas() ),
	F3Base_Suite::FASE_CORRENTE
);

foreach ( f3b_bloqueadas() as $nome => $dados ) {
	/*
	 * CONDIÇÃO DECLARADA FALSA VENCE PENDÊNCIA EXTERNA, e o nome que está nas
	 * duas tabelas sai UMA vez. Não há pendência quando a funcionalidade não
	 * existe: pedir "WordPress em produção" para conferir o CTA de um regime
	 * que ninguém instanciou é relatar como pendente algo que ninguém pediu.
	 */
	if ( $condicoes[ $nome ] ?? false ) {
		continue;
	}

	/*
	 * SUBPROCESSO QUE NÃO RODOU NÃO ABSOLVE NINGUÉM: sem veredito de
	 * aplicabilidade a linha continua BLOCKED, com o erro nomeado. O erro seguro
	 * dos dois é continuar cobrando.
	 */
	$veredito = $aplicabilidade['vereditos'][ $nome ] ?? array();
	$aplicavel = ! isset( $veredito['aplicavel'] ) || (bool) $veredito['aplicavel'];

	if ( ! $aplicavel ) {
		estado(
			'N/A',
			$nome,
			'condição de aplicabilidade falsa: esta checagem é medida na fase ' . $dados['fase']
				. ' e esta rodada é a fase ' . F3Base_Suite::FASE_CORRENTE
				. '. Não há pendência de ninguém aqui — o que falta é a fase, não uma ação: ' . $dados['falta']
				. '. Quando a fase ' . $dados['fase'] . ' rodar, o que ela mede é: ' . $dados['motivo']
				. '. Enquanto ela não rodar, nenhuma evidência deste tipo existe.',
			'analise-estatica',
			$dados['fase']
		);
		continue;
	}

	if ( '' !== $aplicabilidade['erro'] ) {
		estado(
			'BLOCKED',
			$nome,
			'a regra de aplicabilidade por fase não pôde ser consultada, e sem ela nada é dispensado: ' . $aplicabilidade['erro']
				. '. ' . $dados['motivo'] . '. Falta: ' . $dados['falta'] . '.',
			$dados['classe'],
			$dados['fase']
		);
		continue;
	}

	if ( $tem_wp ) {
		estado(
			'BLOCKED',
			$nome,
			'há WordPress em ' . $wp_root . ', mas esta suíte não traz a sonda desta checagem: ' . $dados['motivo'] . '.',
			$dados['classe'],
			$dados['fase']
		);
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		$dados['motivo'] . '. Falta: ' . $dados['falta'] . '.',
		$dados['classe'],
		$dados['fase']
	);
}

$bloqueadas_declaradas = f3b_bloqueadas();

foreach ( f3b_nao_aplicaveis() as $nome => $dados ) {
	if ( $condicoes[ $nome ] ?? false ) {
		estado( 'N/A', $nome, 'condição declarada: ' . $dados['condicao'] . '.', $dados['classe'], $dados['fase'] );
		continue;
	}

	/*
	 * O NOME QUE ESTÁ NAS DUAS TABELAS SAI UMA VEZ — nos DOIS sentidos, e este
	 * era o lado que faltava. Com a condição verdadeira, o laço de cima já
	 * pulava e este emitia o N/A; com ela FALSA, os dois emitiam, e o mesmo
	 * nome saía duas vezes na mesma rodada — uma com a fase declarada dele e
	 * outra com `local`, que é a fase escrita neste ramo genérico. Duas linhas
	 * com o mesmo rótulo e fases diferentes é a divergência de fonte que este
	 * pacote persegue em todo lugar; quem tem entrada própria em
	 * `f3b_bloqueadas()` já falou por si, com a fase que ela declara.
	 */
	if ( isset( $bloqueadas_declaradas[ $nome ] ) ) {
		continue;
	}

	estado(
		'BLOCKED',
		$nome,
		'a condição que tornava esta checagem inaplicável deixou de valer, e a sonda dela não roda neste ambiente. Falta: WordPress instalado para exercitar o caminho.',
		'pendencia-externa',
		'local'
	);
}

/* =========================================================================
 * ETAPA 2b — BANCADA WORDPRESS REAL.
 *
 * Vem DEPOIS de tudo o que se pode afirmar sem WordPress, e é a única etapa que
 * carrega o núcleo: ela instala o zip que a etapa 1 acabou de montar num
 * WordPress descartável com banco de verdade, sobe um servidor, e pergunta ao
 * produto o que ele FAZ — não o que ele faria. As linhas dela entram na mesma
 * contagem, pelo mesmo `estado()`, com a classe de evidência `wp-real`.
 *
 * Ela fica ANTES dos cruzamentos de propósito: `manifesto.bidirecional` e
 * `armadilhas.mapeadas` leem os rótulos EFETIVAMENTE emitidos, e um bloco que
 * saísse depois deles ficaria fora do cruzamento — cobertura afirmada sobre
 * linhas que ninguém conferiu.
 * ====================================================================== */

echo "\n== etapa 2b: bancada WordPress real ==\n";

$passos_da_bancada = f3b_bancada_passos( $suite );
$bancada_desligada = f3b_bancada_desligada();

if ( array() === $passos_da_bancada ) {
	estado(
		'BLOCKED',
		'bancada.ambiente',
		'a bancada não declara passo nenhum: suite/bancada-wp/pisos.tsv está vazia ou ausente, e uma etapa sem passo declarado não mede nada. Recurso ausente: suite/bancada-wp/pisos.tsv.',
		'pendencia-externa',
		'build'
	);
} elseif ( '' !== $bancada_desligada ) {
	/*
	 * DESLIGADA FECHA N/A COM A CONDIÇÃO DECLARADA, em TODA linha da etapa — e
	 * nunca OK. O interruptor existe para quem precisa de uma rodada sem rede e
	 * sem WordPress; o que ele não pode fazer é transformar ausência de medição
	 * em aprovação, que é o modo mais silencioso de uma suíte mentir.
	 */
	estado( 'N/A', 'bancada.ambiente', 'condição declarada: ' . $bancada_desligada . '.', 'wp-real', 'build' );

	foreach ( array_keys( $passos_da_bancada ) as $nome_do_passo ) {
		estado( 'N/A', $nome_do_passo, 'condição declarada: ' . $bancada_desligada . '.', 'wp-real', 'build' );
	}
} else {
	$bancada = f3b_rodar_bancada( $suite, (string) $build['artefato'] );

	if ( '' !== $bancada['erro'] ) {
		estado(
			'BLOCKED',
			'bancada.ambiente',
			'a bancada WordPress não pôde ser executada, e sem ela nada desta classe de evidência é dispensado: ' . $bancada['erro'] . '.',
			'pendencia-externa',
			'build'
		);

		foreach ( array_keys( $passos_da_bancada ) as $nome_do_passo ) {
			estado(
				'BLOCKED',
				$nome_do_passo,
				'não medido: a etapa da bancada não produziu veredito para este passo. ' . $bancada['erro'] . '.',
				'pendencia-externa',
				'build'
			);
		}
	} else {
		$vistos_na_bancada = array();

		foreach ( $bancada['linhas'] as $linha_da_bancada ) {
			$vistos_na_bancada[ $linha_da_bancada['nome'] ] = true;

			estado(
				$linha_da_bancada['estado'],
				$linha_da_bancada['nome'],
				$linha_da_bancada['mensagem'],
				'bancada.ambiente' === $linha_da_bancada['nome'] && 'OK' !== $linha_da_bancada['estado'] ? 'pendencia-externa' : 'wp-real',
				'build'
			);
		}

		/*
		 * PASSO DECLARADO QUE NÃO VOLTOU NÃO SOME. A etapa poderia ter morrido no
		 * meio, e um relatório com menos linhas do que a tabela declara é a forma
		 * mais discreta de perder uma medição.
		 */
		foreach ( array_keys( $passos_da_bancada ) as $nome_do_passo ) {
			if ( isset( $vistos_na_bancada[ $nome_do_passo ] ) ) {
				continue;
			}

			estado(
				'BLOCKED',
				$nome_do_passo,
				'não medido: o passo está declarado em suite/bancada-wp/pisos.tsv e a bancada não devolveu veredito para ele. Recurso ausente: execução completa do roteiro da bancada.',
				'pendencia-externa',
				'build'
			);
		}
	}
}

echo "\n";

/* ---------- cruzamentos da própria suíte ---------- */

/*
 * As duas metacheagens entram na própria lista: elas SÃO emitidas nesta rodada,
 * e o cruzamento precisa enxergá-las para não acusar como órfão o rótulo que
 * está prestes a sair. Nada mais é acrescentado à mão.
 */
$emitidas = array_merge( F3Base_Suite::emitidas(), array( 'manifesto.bidirecional', 'armadilhas.mapeadas' ) );

$manifesto = f3b_ck_manifesto_bidirecional( $suite, $emitidas );

estado_por_origem(
	(bool) $manifesto['ok'],
	'site',
	'manifesto.bidirecional',
	sprintf( '%d requisito(s) do manifesto apontam para checagem emitida, e nenhum rótulo emitido ficou órfão.', (int) $manifesto['requisitos'] ),
	count( $manifesto['achados'] ) . ' achado(s): ' . f3b_amostra( $manifesto['achados'] ),
	'analise-estatica',
	'build'
);

$armadilhas = f3b_ck_armadilhas_mapeadas( $suite, $emitidas );

estado( $armadilhas['estado'], 'armadilhas.mapeadas', $armadilhas['mensagem'], 'analise-estatica', 'build' );

/* ---------- o contrapeso da regra de fase ---------- */

/*
 * ESTA LINHA É A METADE QUE IMPEDE A OUTRA DE VIRAR CEGUEIRA, e ela sai por
 * ÚLTIMA de propósito: o registro conta o que cada fase espera a partir das
 * LINHAS EFETIVAMENTE EMITIDAS nesta rodada, e as duas metacheagens acima são
 * linhas como quaisquer outras. Emiti-la antes delas produziria uma contagem
 * de fase `build` menor do que a rodada — número que descreve outra coisa que
 * não o que saiu na tela, que é o defeito que a 1.0.17 fechou.
 *
 * Ela entra na própria lista de emitidas, pela mesma razão que as duas
 * metacheagens entram: ela SAI nesta rodada, e o cruzamento precisa enxergá-la
 * para não acusar como órfão o rótulo que está prestes a sair.
 */
$fases = f3b_ck_registro_de_fases( $raiz, $suite, F3Base_Suite::linhas_com_fase(), F3Base_Suite::FASE_CORRENTE );


/* =========================================================================
 * RESUMO
 * ====================================================================== */

echo "\n== resumo ==\n";

/*
 * CONTAGEM E NOMES SAEM JUNTOS. O resumo imprimia `BLOCKED 22` e nenhum nome:
 * quem quisesse saber QUAIS tinha de reler as 73 linhas acima e contar à mão.
 */
$contagem     = F3Base_Suite::contagem();
$nomes_da_rodada = F3Base_Suite::nomes_por_estado();
$total        = array_sum( $contagem );

foreach ( f3b_resumo_por_estado( $contagem, $nomes_da_rodada ) as $linha_do_resumo ) {
	echo $linha_do_resumo . "\n";
}

printf( "   %-8s %d\n", 'TOTAL', $total );

$falhas = F3Base_Suite::falhas();

/* =========================================================================
 * REGISTRO DURÁVEL DE FASES. Gravado ANTES do selo e INDEPENDENTE dele, e as
 * duas coisas são deliberadas.
 *
 * Antes: o selo é a última etapa e pode abortar; o registro de fases não pode
 * depender de ela ter dado certo, porque quem o lê é a rodada SEGUINTE.
 *
 * Independente: a rodada com FALHA APAGA `suite/rodada.json` — registro de
 * limpeza que sobrevive a uma reprovação é afirmação sem medição por trás. O
 * registro de fases é o oposto: ele não afirma aprovação nenhuma, afirma
 * EXECUÇÃO, e apagá-lo numa rodada reprovada perderia o fato de que a fase de
 * navegador rodou um dia — que é justamente o fato que a rodada de build não
 * tem como reproduzir sozinha.
 * ====================================================================== */

$registro_de_fases = f3b_gravar_registro_de_fases( $raiz, (array) $fases['durar'] );

foreach ( $registro_de_fases['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

/* =========================================================================
 * ETAPA 3 — SELO DA RODADA. Última, sempre: o resumo por estado só existe
 * depois das checagens, e é ele que entra no registro.
 * ====================================================================== */

echo "\n== etapa 3: selo da rodada ==\n";

$selo = f3b_selar_rodada( $raiz, $suite, $build, $contagem, $nomes_da_rodada, f3b_com_piso( $suite ) );

foreach ( $selo['achados'] as $achado ) {
	echo '   ! ' . $achado . "\n";
}

if ( $selo['gravado'] ) {
	printf(
		"   registro: %s\n   sha256 do artefato do plugin: %s\n   conferido por leitura de volta: %s\n",
		$selo['arquivo'],
		$selo['hash'],
		(string) ( $selo['conferido'] ?? '(não conferido)' )
	);
}

if ( ! $selo['ok'] ) {
	estado(
		'FALHA',
		'entrega.selo_da_rodada',
		'o selo da rodada não fechou: ' . f3b_amostra( $selo['achados'], 3 ) . '.',
		'medida',
		'build'
	);

	printf( "\nrodada REPROVADA no selo: %d checagem(ns) em FALHA.\n", F3Base_Suite::falhas() );
	exit( 1 );
}

if ( $falhas > 0 ) {
	printf(
		"\nrodada REPROVADA: %d checagem(ns) em FALHA — %s.\n",
		$falhas,
		'FALHA: ' . ( array() === $nomes_da_rodada['FALHA'] ? 'nenhum' : implode( ', ', $nomes_da_rodada['FALHA'] ) )
	);
	exit( 1 );
}

$bloqueadas = $contagem['BLOCKED'];

printf(
	"\nrodada sem FALHA. %d checagem(ns) em BLOCKED — %s. Nenhuma delas é entregável do gate de aplicação: as de fase declarada não impedem a autodesativação, e as do host são medidas lá.\n",
	$bloqueadas,
	'BLOCKED: ' . ( array() === $nomes_da_rodada['BLOCKED'] ? 'nenhum' : implode( ', ', $nomes_da_rodada['BLOCKED'] ) )
);

exit( 0 );