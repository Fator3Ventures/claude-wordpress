<?php
/**
 * TOKENIZADOR DE JAVASCRIPT, vendorizado — e o motivo de ele existir aqui.
 *
 * Ele serve a UM propósito: remover comentários dos `.js` que o pacote ENTREGA,
 * sem tocar em mais nada. Três decisões sustentam o arquivo, e as três são
 * sobre o que dá errado quando ele não existe.
 *
 * 1. NADA DE EXPRESSÃO REGULAR. Comentário-que-não-é-comentário é o caso comum,
 *    não a exceção: `"/*"` dentro de string, `//` dentro de uma URL
 *    (`https://exemplo.test`), `/` dentro de literal de regex — inclusive
 *    escapado (`/^\/[a-z]*$/`) e dentro de classe de caractere (`/[/]/`). Uma
 *    expressão regular que "acha comentário" apaga o miolo de uma string e
 *    entrega um arquivo que ainda analisa e faz outra coisa. É o pior defeito
 *    possível de um empacotamento: silencioso, entregue e só visível no
 *    navegador do visitante.
 *
 * 2. NADA DE DEPENDÊNCIA DE REDE. Um `npm install` no empacotamento é um build
 *    que para de funcionar sozinho no dia em que o registro sai do ar, o pacote
 *    é publicado ou a versão some. O tokenizador mora aqui, no pacote, viaja
 *    com ele e é lido pela mesma allow-list que autoriza todo o resto.
 *
 * 3. O ENTREGUE É A FONTE MENOS OS COMENTÁRIOS, e nada além disso. Cada
 *    comentário removido vira UM caractere: quebra de linha quando ele continha
 *    uma, espaço quando não. As duas escolhas são da especificação, não de
 *    conveniência — um comentário de bloco com quebra de linha CONTA como
 *    quebra de linha para a inserção automática de ponto e vírgula, e apagá-lo
 *    sem deixar a quebra mudaria o significado do arquivo. Fora isso, byte
 *    nenhum se move: indentação, linha em branco e ordem continuam as da fonte.
 *    É essa invariante que `pacote.js_entregue_sem_comentario` confere.
 *
 * CABEÇALHO DE LICENÇA É PRESERVADO. Comentário de bloco que começa com `/*!`
 * ou que carrega `@license` ou `@preserve` sobrevive: remover aviso de licença
 * de código de terceiro é problema jurídico, não economia de bytes.
 *
 * O QUE ELE NÃO É. Não é um parser, não valida sintaxe e não entende o
 * programa. Quem diz que o resultado analisa é o `node --check` rodado sobre o
 * arquivo ENTREGUE, e quem diz que ele se comporta igual são as bancadas de
 * comportamento e a sonda de navegador, que rodam contra o entregue.
 *
 * @package F3Base\Ferramentas
 */

declare( strict_types = 1 );

/**
 * A REGRA DA BARRA: `/` começa um literal de regex ou é divisão?
 *
 * A resposta depende do último token SIGNIFICATIVO antes dela, e não há como
 * decidir sem essa memória — é exatamente por isso que uma expressão regular
 * não serve. Depois de algo que TERMINA um valor (identificador, número,
 * string, `)`, `]`), a barra é divisão. Depois de qualquer outra coisa
 * (operador, `(`, `,`, `=`, `return`, `typeof`), ela abre um regex.
 *
 * As palavras-chave que terminam valor estão listadas porque `true`, `this` e
 * companhia são identificadores para o léxico e valores para a gramática:
 * `this / 2` é divisão, `return /x/` é regex, e as duas terminam em
 * identificador.
 *
 * O caso ambíguo real — `)` e `}`, que terminam valor depois de uma chamada e
 * abrem expressão depois de `if (...)` ou de um bloco — é resolvido pelo lado
 * CONSERVADOR: eles contam como fim de valor, e a barra seguinte é divisão.
 * Errar aqui não apaga nada: o resultado é um `/` tratado como operador, e o
 * conteúdo continua saindo inteiro. O erro que apagaria conteúdo é o oposto, e
 * ele não acontece.
 *
 * @param string $token Último token significativo, ou vazio.
 * @return bool Verdadeiro quando a barra seguinte é divisão.
 */
function f3b_js_barra_e_divisao( string $token ): bool {
	if ( '' === $token ) {
		return false;
	}

	$fim_de_valor = array( ')', ']', '}', '++', '--' );

	if ( in_array( $token, $fim_de_valor, true ) ) {
		return true;
	}

	$palavras_que_abrem = array(
		'return', 'typeof', 'instanceof', 'in', 'of', 'new', 'delete', 'void',
		'do', 'else', 'case', 'yield', 'await', 'throw',
	);

	if ( in_array( $token, $palavras_que_abrem, true ) ) {
		return false;
	}

	/* Identificador, número, string ou template: termina valor. */
	return 1 === preg_match( '/^[A-Za-z0-9_$\'"`\\\\]/u', $token );
}

/**
 * Percorre a fonte e devolve a lista de tokens, cobrindo TODOS os bytes.
 *
 * A concatenação dos textos devolvidos é, byte a byte, a fonte de entrada — e
 * é essa cobertura total que permite ao chamador remover só o que quer sem
 * mexer em mais nada. Tipos: `comentario-linha`, `comentario-bloco`, `string`,
 * `template`, `regex`, `espaco` e `codigo`.
 *
 * @param string $fonte Código-fonte.
 * @return array<int,array{tipo:string,texto:string}>
 */
function f3b_tokenizar_js( string $fonte ): array {
	$tokens    = array();
	$total     = strlen( $fonte );
	$i         = 0;
	$anterior  = '';
	$pendente  = '';
	$templates = array();

	/**
	 * Fecha o token de código acumulado, se houver.
	 *
	 * @return void
	 */
	$fechar = static function () use ( &$pendente, &$tokens ): void {
		if ( '' !== $pendente ) {
			$tokens[]  = array(
				'tipo'  => 'codigo',
				'texto' => $pendente,
			);
			$pendente = '';
		}
	};

	while ( $i < $total ) {
		$c = $fonte[ $i ];
		$d = ( $i + 1 < $total ) ? $fonte[ $i + 1 ] : '';

		/* Espaço em branco: token próprio, para que nada o confunda com código. */
		if ( 1 === preg_match( '/^\s$/', $c ) ) {
			$fechar();
			$j = $i;

			while ( $j < $total && 1 === preg_match( '/^\s$/', $fonte[ $j ] ) ) {
				++$j;
			}

			$tokens[] = array(
				'tipo'  => 'espaco',
				'texto' => substr( $fonte, $i, $j - $i ),
			);
			$i        = $j;
			continue;
		}

		if ( '/' === $c && '/' === $d ) {
			$fechar();
			$j = $i + 2;

			while ( $j < $total && "\n" !== $fonte[ $j ] && "\r" !== $fonte[ $j ] ) {
				++$j;
			}

			$tokens[] = array(
				'tipo'  => 'comentario-linha',
				'texto' => substr( $fonte, $i, $j - $i ),
			);
			$i        = $j;
			continue;
		}

		if ( '/' === $c && '*' === $d ) {
			$fechar();
			$fim = strpos( $fonte, '*/', $i + 2 );
			/* Comentário sem fechamento é erro de sintaxe: vai inteiro até o fim, e o node --check o acusa. */
			$j   = false === $fim ? $total : $fim + 2;

			$tokens[] = array(
				'tipo'  => 'comentario-bloco',
				'texto' => substr( $fonte, $i, $j - $i ),
			);
			$i        = $j;
			continue;
		}

		if ( '"' === $c || "'" === $c ) {
			$fechar();
			$j = $i + 1;

			while ( $j < $total ) {
				if ( '\\' === $fonte[ $j ] ) {
					$j += 2;
					continue;
				}

				if ( $fonte[ $j ] === $c ) {
					++$j;
					break;
				}

				++$j;
			}

			$tokens[]  = array(
				'tipo'  => 'string',
				'texto' => substr( $fonte, $i, $j - $i ),
			);
			$anterior = '"';
			$i        = $j;
			continue;
		}

		/*
		 * TEMPLATE COM SUBSTITUIÇÃO ANINHADA. `${ ... }` volta a ser código —
		 * e dentro dele pode haver outro template. A pilha existe por isso: sem
		 * ela, a primeira `}` fecharia o template errado e o resto do arquivo
		 * seria lido como texto.
		 */
		if ( '`' === $c ) {
			$fechar();
			$j       = $i + 1;
			$fechado = false;

			while ( $j < $total ) {
				if ( '\\' === $fonte[ $j ] ) {
					$j += 2;
					continue;
				}

				if ( '`' === $fonte[ $j ] ) {
					++$j;
					$fechado = true;
					break;
				}

				if ( '$' === $fonte[ $j ] && ( $j + 1 < $total ) && '{' === $fonte[ $j + 1 ] ) {
					$j += 2;
					break;
				}

				++$j;
			}

			$tokens[] = array(
				'tipo'  => 'template',
				'texto' => substr( $fonte, $i, $j - $i ),
			);

			if ( ! $fechado && $j <= $total && '{' === substr( $fonte, $j - 1, 1 ) ) {
				$templates[] = 1;
			}

			$anterior = '`';
			$i        = $j;
			continue;
		}

		/* `}` fechando uma substituição volta ao template de onde ela saiu. */
		if ( '}' === $c && array() !== $templates ) {
			$fechar();
			array_pop( $templates );
			$j       = $i + 1;
			$fechado = false;

			while ( $j < $total ) {
				if ( '\\' === $fonte[ $j ] ) {
					$j += 2;
					continue;
				}

				if ( '`' === $fonte[ $j ] ) {
					++$j;
					$fechado = true;
					break;
				}

				if ( '$' === $fonte[ $j ] && ( $j + 1 < $total ) && '{' === $fonte[ $j + 1 ] ) {
					$j += 2;
					break;
				}

				++$j;
			}

			if ( ! $fechado ) {
				$templates[] = 1;
			}

			$tokens[] = array(
				'tipo'  => 'template',
				'texto' => substr( $fonte, $i, $j - $i ),
			);
			$anterior = '`';
			$i        = $j;
			continue;
		}

		if ( '/' === $c && ! f3b_js_barra_e_divisao( $anterior ) ) {
			$fechar();
			$j      = $i + 1;
			$classe = false;

			while ( $j < $total ) {
				$e = $fonte[ $j ];

				if ( '\\' === $e ) {
					$j += 2;
					continue;
				}

				if ( "\n" === $e || "\r" === $e ) {
					/* Regex não atravessa linha: o que parecia regex era divisão. */
					$j = $i + 1;
					break;
				}

				if ( '[' === $e ) {
					$classe = true;
				} elseif ( ']' === $e ) {
					$classe = false;
				} elseif ( '/' === $e && ! $classe ) {
					++$j;

					while ( $j < $total && 1 === preg_match( '/^[a-z]$/', $fonte[ $j ] ) ) {
						++$j;
					}

					break;
				}

				++$j;
			}

			if ( $j > $i + 1 ) {
				$tokens[]  = array(
					'tipo'  => 'regex',
					'texto' => substr( $fonte, $i, $j - $i ),
				);
				$anterior = '/regex/';
				$i        = $j;
				continue;
			}
		}

		/* Código: identificador, número ou pontuação. */
		if ( 1 === preg_match( '/^[A-Za-z0-9_$]$/', $c ) ) {
			$j = $i;

			while ( $j < $total && 1 === preg_match( '/^[A-Za-z0-9_$.]$/', $fonte[ $j ] ) ) {
				++$j;
			}

			$palavra   = substr( $fonte, $i, $j - $i );
			$pendente .= $palavra;
			$anterior  = $palavra;
			$i         = $j;
			continue;
		}

		$dois = $c . $d;

		if ( in_array( $dois, array( '++', '--' ), true ) ) {
			$pendente .= $dois;
			$anterior  = $dois;
			$i        += 2;
			continue;
		}

		$pendente .= $c;
		$anterior  = $c;
		++$i;
	}

	$fechar();

	return $tokens;
}

/**
 * A fonte SEM os comentários, com a invariante escrita no topo deste arquivo.
 *
 * @param string $fonte Código-fonte.
 * @return string Código entregue.
 */
function f3b_js_sem_comentario( string $fonte ): string {
	$saida = '';

	foreach ( f3b_tokenizar_js( $fonte ) as $token ) {
		if ( 'comentario-linha' !== $token['tipo'] && 'comentario-bloco' !== $token['tipo'] ) {
			$saida .= $token['texto'];
			continue;
		}

		if ( f3b_js_comentario_de_licenca( $token['texto'] ) ) {
			$saida .= $token['texto'];
			continue;
		}

		/*
		 * O COMENTÁRIO VIRA UM CARACTERE, e qual deles é decisão da
		 * especificação: comentário de bloco COM quebra de linha conta como
		 * quebra de linha para a inserção automática de ponto e vírgula.
		 * Trocá-lo por espaço juntaria duas instruções que a fonte separava.
		 */
		$saida .= ( false !== strpos( $token['texto'], "\n" ) || false !== strpos( $token['texto'], "\r" ) ) ? "\n" : ' ';
	}

	return $saida;
}

/**
 * Comentário que carrega aviso de licença e por isso sobrevive.
 *
 * @param string $texto Texto do comentário, com os delimitadores.
 * @return bool
 */
function f3b_js_comentario_de_licenca( string $texto ): bool {
	if ( str_starts_with( $texto, '/*!' ) ) {
		return true;
	}

	return false !== stripos( $texto, '@license' ) || false !== stripos( $texto, '@preserve' );
}
