<?php
/**
 * Sonda das FASES — subprocesso que chama a ÚNICA implementação da regra.
 *
 * A regra de fase tem uma dona: `F3Base_Imp_Fases`, que é a classe que o HOST
 * executa no encerramento. Reimplementá-la aqui criaria duas respostas para a
 * mesma pergunta — "esta checagem se aplica nesta fase?" e "esta fase já rodou
 * alguma vez?" —, e no dia em que uma delas mudasse a de cá continuaria dizendo
 * que estava tudo certo. É a mesma doença que `sonda-hash.php` existe para não
 * ter, e a saída é a mesma: subprocesso.
 *
 * Subprocesso por desenho — carregar a classe define `ABSPATH`, e isso não pode
 * vazar para o processo que imprime os estados.
 *
 * uso: php suite/lib/sonda-fases.php <raiz-do-pacote> <arquivo-json-de-entrada>
 *
 * A entrada é um objeto JSON com:
 *   - `operacao`: `aplicabilidade` ou `registro`.
 *   - `fase_corrente`: fase deste emissor (para `aplicabilidade`).
 *   - `declaradas`: mapa nome => fase (para `aplicabilidade`).
 *   - `linhas`: lista de {nome, fase, estado} (para `registro`).
 *   - `anterior`: registro durável lido do disco (para `registro`).
 *   - `agora`: carimbo de tempo (para `registro`).
 *
 * A saída é JSON no stdout. Erro vai para o stderr e sai com código != 0 —
 * nunca com um veredito inventado, que é o que faria a suíte aprovar por causa
 * de um subprocesso que não rodou.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz    = rtrim( (string) ( $argv[1] ?? '' ), '/' );
$entrada = (string) ( $argv[2] ?? '' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	fwrite( STDERR, "sonda-fases: raiz do pacote inexistente\n" );
	exit( 2 );
}

/*
 * A CLASSE DA REGRA DE FASE MORA NA SUÍTE NESTE REPOSITÓRIO, e a mudança é de
 * endereço, não de regra: o arquivo é cópia byte a byte de
 * `includes/class-f3base-imp-fases.php` do implantador. Lá ela mora no runtime
 * porque é o HOST que a executa no encerramento; aqui não há runtime de
 * implantador, e quem executa a regra é a suíte — que continua sendo a única a
 * executá-la, que é o que a decisão de fonte única cobrava. O `$raiz` continua
 * chegando por argumento porque é ele que a sonda mede.
 */
$classe = dirname( __FILE__ ) . '/class-f3base-imp-fases.php';

if ( ! is_file( $classe ) ) {
	fwrite( STDERR, 'sonda-fases: pré-condição ausente. Recurso ausente: ' . $classe . "\n" );
	exit( 2 );
}

if ( '' === $entrada || ! is_file( $entrada ) ) {
	fwrite( STDERR, "sonda-fases: arquivo de entrada inexistente\n" );
	exit( 2 );
}

$pedido = json_decode( (string) file_get_contents( $entrada ), true );

if ( ! is_array( $pedido ) ) {
	fwrite( STDERR, "sonda-fases: entrada não é JSON de objeto\n" );
	exit( 2 );
}

define( 'ABSPATH', '/tmp/f3base-sem-wordpress/' );
define( 'F3BASE_IMP_DIR', $raiz . '/' );

require $classe;

$operacao = (string) ( $pedido['operacao'] ?? '' );

if ( 'aplicabilidade' === $operacao ) {
	$corrente = (string) ( $pedido['fase_corrente'] ?? '' );
	$saida    = array( 'fases' => F3Base_Imp_Fases::fases() );

	foreach ( (array) ( $pedido['declaradas'] ?? array() ) as $nome => $fase ) {
		$saida['vereditos'][ (string) $nome ] = F3Base_Imp_Fases::aplicabilidade( (string) $fase, $corrente );
	}

	echo (string) json_encode( $saida, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	exit( 0 );
}

if ( 'registro' === $operacao ) {
	/*
	 * O CARIMBO É ALINHADO AO DIA, e a razão está em `F3Base_Imp_Fases::dia()`:
	 * este registro mora dentro do pacote e entra no hash dele, então precisão de
	 * segundo faria duas rodadas idênticas produzirem hashes diferentes.
	 */
	$agora    = F3Base_Imp_Fases::dia( (int) ( $pedido['agora'] ?? time() ) );
	$anterior = (array) ( $pedido['anterior'] ?? array() );
	$registro = F3Base_Imp_Fases::registro( (array) ( $pedido['linhas'] ?? array() ), $anterior, $agora );

	$quando = array();

	foreach ( F3Base_Imp_Fases::fases() as $fase ) {
		$quando[ $fase ] = F3Base_Imp_Fases::quando( (array) ( $registro['fases'][ $fase ] ?? array() ) );
	}

	echo (string) json_encode(
		array(
			'fases_fechadas' => F3Base_Imp_Fases::fases(),
			'registro'       => $registro,
			'quando'         => $quando,
			'durar'          => F3Base_Imp_Fases::durar( $registro, $anterior, $agora, 'suite' ),
		),
		JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
	);
	exit( 0 );
}

fwrite( STDERR, 'sonda-fases: operação desconhecida: ' . $operacao . "\n" );
exit( 2 );
