<?php
/**
 * Piso: a prova de que cada detector SABE REPROVAR.
 *
 * Regra dura deste arquivo: o piso roda a MESMA função que roda contra o
 * pacote. Nada é reimplementado aqui — o registro abaixo só troca a raiz. Uma
 * suíte cujo piso reimplementa a regra prova que a cópia funciona, não que o
 * detector funciona.
 *
 * Segunda regra dura: a detecção precisa sair com o NOME DA PRÓPRIA CHECAGEM.
 * Reprovar por exceção, por erro de análise ou por qualquer acidente genérico
 * não prova nada — por isso toda chamada é isolada e a exceção vira FALHA do
 * piso, nunca aprovação.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$suite = dirname( __DIR__ );
$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );

require $suite . '/lib/regra.php';
require $suite . '/lib/empacotar.php';

foreach ( array( 'estatica', 'entrega', 'funcional', 'bloqueadas', 'meta' ) as $modulo ) {
	require $suite . '/checagens/' . $modulo . '.php';
}

require $suite . '/lib/documentos.php';

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	fwrite( STDERR, "uso: piso.php <caminho-do-pacote>\n" );
	exit( 2 );
}

/**
 * Registro: nome da checagem => a MESMA função que o runner chama.
 *
 * @param string $suite Diretório da suíte.
 * @return array<string,callable(string):array{ok:bool,achados:array<int,string>}>
 */
function f3b_registro_piso( string $suite ): array {
	return array(
		'estatica.php_lint'                    => static fn( string $r ): array => f3b_ck_php_lint( $r ),
		'estatica.json_valido'                 => static fn( string $r ): array => f3b_ck_json_valido( $r ),
		'estatica.js_lint'                     => static fn( string $r ): array => f3b_ck_js_lint( $r, $suite ),
		'estatica.detector_escrita_unica'      => static fn( string $r ): array => f3b_ck_escrita_unica( $r ),
		'estatica.detector_version_compare'    => static fn( string $r ): array => f3b_ck_version_compare( $r ),
		'estatica.detector_condicao_literal'   => static fn( string $r ): array => f3b_ck_condicao_literal( $r ),
		'estatica.detector_codigo_em_string'   => static fn( string $r ): array => f3b_ck_codigo_em_string( $r ),
		'estatica.sem_residuo_de_chave_removida' => static fn( string $r ): array => f3b_ck_sem_residuo_de_chave_removida( $r ),
		'tela.fala_portugues_comum'            => static fn( string $r ): array => f3b_ck_tela_fala_portugues_comum( $r ),
		'estatica.simbolos_resolvem'           => static fn( string $r ): array => f3b_ck_simbolos_resolvem( $r ),
		'estatica.estados_fechados'            => static fn( string $r ): array => f3b_ck_estados_fechados( $r ),
		'estatica.carimbo_de_release_nos_documentos' => static fn( string $r ): array => f3b_ck_carimbo_de_release_nos_documentos( $r ),
		'estatica.saida_com_trava_de_uma_vez'  => static fn( string $r ): array => f3b_ck_saida_com_trava_de_uma_vez( $r ),
		'estatica.contagem_com_nomes'          => static fn( string $r ): array => f3b_ck_contagem_com_nomes( $r ),
		'estatica.warn_tem_ramo_adverso'        => static fn( string $r ): array => f3b_ck_warn_tem_ramo_adverso( $r ),
		'estatica.piso_em_sonda_declarado'      => static fn( string $r ): array => f3b_ck_piso_em_sonda_declarado( $r ),
		'estatica.sem_recusa_de_escrita_do_agente' => static fn( string $r ): array => f3b_ck_sem_recusa_de_escrita_do_agente( $r ),
		'estatica.hidden_governa_visibilidade' => static fn( string $r ): array => f3b_ck_hidden_governa_visibilidade( $r ),
		'estatica.campo_operavel_tem_impacto_e_exemplo' => static fn( string $r ): array => f3b_ck_campo_operavel_documentado( $r ),
		'tracking.eventos_de_comportamento_declarados' => static fn( string $r ): array => f3b_ck_eventos_de_comportamento_declarados( $r ),
		'tracking.emissor_unico_discrimina'    => static fn( string $r ): array => f3b_ck_emissor_unico_discrimina( $r, $suite ),
		'pacote.allow_list'                    => static fn( string $r ): array => f3b_ck_allow_list( $r, $r . '/suite' ),
		'pacote.build_fresco'                  => static fn( string $r ): array => f3b_ck_build_fresco( $r . '/artefato.zip', $r . '/fonte' ),
		'pacote.js_entregue_sem_comentario'    => static fn( string $r ): array => f3b_ck_js_entregue_sem_comentario( $r ),
		'mcp.options_citadas_existem'          => static fn( string $r ): array => f3b_ck_options_citadas_existem( $r ),
		'doc.afirmacao_conferida'              => static fn( string $r ): array => f3b_ck_afirmacoes( $r ),
		'estatica.robos_conhecidos_ordenados' => static fn( string $r ): array => f3b_ck_robos_conhecidos_ordenados( $r ),
		'doc.numero_digitado'                  => static fn( string $r ): array => f3b_ck_numero_digitado_nos_documentos( $r ),
	);
}

/**
 * FIXA OS MTIMES da fixture cujo defeito É o mtime, nos DOIS ramos.
 *
 * O DEFEITO MEDIDO, e ele é do ambiente e não do detector. `pacote.build_fresco`
 * compara a data do artefato com a de cada fonte, e o piso dele planta a
 * inversão: na fixture negativa o zip é MAIS VELHO que a fonte. Data de arquivo
 * não é conteúdo, e o git não a versiona — todo arquivo de um clone nasce com a
 * data do checkout. Num clone limpo os dois arquivos da fixture negativa passam
 * a ter a MESMA data, a inversão some, e o piso reprova o detector por um fato
 * do disco: "detector cego" sobre um detector que enxerga. Foi exatamente o que
 * a rodada de partida desta frente mediu neste worktree.
 *
 * O QUE ISTO NÃO É: reimplementação da regra. A regra continua sendo
 * `f3b_ck_build_fresco()`, chamada logo abaixo sem nenhuma alteração — o que
 * esta função faz é MONTAR a fixture, do mesmo jeito que as outras fixtures já
 * vêm montadas em disco, só que num atributo que o versionador não carrega.
 * Ela é declarada por NOME de checagem para não tocar em fixture nenhuma que
 * não dependa de data.
 *
 * @param string $nome     Nome da checagem.
 * @param string $negativa Diretório da fixture negativa.
 * @param string $positiva Diretório da fixture positiva.
 * @return void
 */
function f3b_montar_datas_da_fixture( string $nome, string $negativa, string $positiva ): void {
	if ( 'pacote.build_fresco' !== $nome ) {
		return;
	}

	/* Instante fixo: o piso não pode depender de quando a rodada aconteceu. */
	$velho = 1700000000;
	$novo  = $velho + 3600;

	/* NEGATIVA: o artefato é mais velho que a fonte — é o defeito plantado. */
	foreach ( f3b_fontes( $negativa . '/fonte' ) as $rel ) {
		touch( $negativa . '/fonte/' . $rel, $novo );
	}
	touch( $negativa . '/artefato.zip', $velho );

	/* POSITIVA: o artefato é mais novo que toda fonte — é o caso correto. */
	foreach ( f3b_fontes( $positiva . '/fonte' ) as $rel ) {
		touch( $positiva . '/fonte/' . $rel, $velho );
	}
	touch( $positiva . '/artefato.zip', $novo );

	clearstatcache();
}

$registro = f3b_registro_piso( $suite );
$fixtures = $suite . '/fixtures';

echo "== piso: cada detector contra a fixture que reproduz o defeito ==\n";

foreach ( $registro as $nome => $funcao ) {
	$negativa = $fixtures . '/' . $nome . '/negativa';
	$positiva = $fixtures . '/' . $nome . '/positiva';

	if ( is_dir( $negativa ) && is_dir( $positiva ) ) {
		f3b_montar_datas_da_fixture( $nome, $negativa, $positiva );
	}

	if ( ! is_dir( $negativa ) || ! is_dir( $positiva ) ) {
		estado(
			'BLOCKED',
			$nome,
			'piso ausente: falta ' . ( is_dir( $negativa ) ? 'fixtures/' . $nome . '/positiva' : 'fixtures/' . $nome . '/negativa' ) . '.',
			'pendencia-externa',
			'build'
		);
		continue;
	}

	/* Ramo negativo: a fixture reproduz o defeito e a checagem PRECISA acusar. */
	try {
		$r = $funcao( $negativa );

		if ( ! is_array( $r ) || ! array_key_exists( 'ok', $r ) ) {
			estado( 'FALHA', $nome, 'piso negativo: a checagem não devolveu veredito analisável.', 'teste-funcional', 'build' );
		} elseif ( $r['ok'] ) {
			estado( 'FALHA', $nome, 'piso negativo: o defeito plantado NÃO foi acusado — detector cego.', 'teste-funcional', 'build' );
		} else {
			estado(
				'OK',
				$nome,
				'piso negativo: acusou o defeito plantado — ' . f3b_amostra( $r['achados'], 2 ) . '.',
				'teste-funcional',
				'build'
			);
		}
	} catch ( Throwable $e ) {
		estado(
			'FALHA',
			$nome,
			'piso negativo: reprovou por exceção (' . get_class( $e ) . ': ' . $e->getMessage() . '), e exceção não prova detecção.',
			'teste-funcional',
			'build'
		);
	}

	/* Ramo positivo: a fixture preserva o correto e a checagem PRECISA calar. */
	try {
		$r = $funcao( $positiva );

		if ( ! is_array( $r ) || ! array_key_exists( 'ok', $r ) ) {
			estado( 'FALHA', $nome, 'piso positivo: a checagem não devolveu veredito analisável.', 'teste-funcional', 'build' );
		} elseif ( $r['ok'] ) {
			estado( 'OK', $nome, 'piso positivo: ficou em silêncio sobre o caso correto.', 'teste-funcional', 'build' );
		} else {
			estado(
				'FALHA',
				$nome,
				'piso positivo: acusou o caso correto — ' . f3b_amostra( $r['achados'], 3 ) . '.',
				'teste-funcional',
				'build'
			);
		}
	} catch ( Throwable $e ) {
		estado(
			'FALHA',
			$nome,
			'piso positivo: morreu por exceção (' . get_class( $e ) . ': ' . $e->getMessage() . ').',
			'teste-funcional',
			'build'
		);
	}
}

/**
 * OS INSUMOS DECLARADOS que moram em `suite/fixtures/` e NÃO são piso.
 *
 * `suite/fixtures/` é o lugar do que a suíte usa para medir, e o piso é o uso
 * mais visível dele — mas não o único. Ao sair do implantador, duas coisas que
 * lá vinham de fora do repositório passaram a morar aqui, e as duas são
 * INSUMO: dado de entrada declarado, com a procedência escrita dentro do
 * próprio arquivo.
 *
 * Elas precisam ser declaradas porque a regra logo abaixo é dura de propósito:
 * diretório em `fixtures/` que não corresponde a detector nenhum é piso solto,
 * e piso solto é uma fixture que ninguém executa — a pior forma de cobertura,
 * porque ela existe, parece medir e não mede. Declarar aqui, com o motivo, é o
 * oposto de abrir exceção: é dizer o que aquele diretório é.
 *
 * @return array<string,string> Diretório => o que ele é.
 */
function f3b_insumos_de_fixture(): array {
	return array(
		'atualizacao' => 'ZIP anterior enviado pelo operador, com procedência e SHA no README. Usado por bancada-wp/atualizacao.sh para instalar a versão anterior e trocar os arquivos sem reativação.',
		'config' => 'ANDAIME DE CONFIGURAÇÃO da bancada do site-core: o retrato dos valores que `config/{site.json,projeto.json,decisoes.tsv}` do implantador entregavam à sonda. Lido por `suite/lib/andaime-config.php`, e por mais ninguém.',
		'tema'   => 'INSUMO DO TEMA: a cópia byte a byte de `fontes/tema/patterns/cta-whatsapp.php`, que é de onde sai a forma do markup do CTA que `leads.cta_preserva_destino` mede. Sem ela a bancada estaria medindo a regra do plugin contra um markup inventado na própria bancada.',
	);
}

/* Fixture sem checagem no registro é piso solto: ninguém a executa. */
foreach ( glob( $fixtures . '/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
	$nome = basename( $dir );

	if ( isset( $registro[ $nome ] ) || isset( f3b_insumos_de_fixture()[ $nome ] ) ) {
		continue;
	}

	estado( 'FALHA', 'piso.fixture_orfa', 'fixtures/' . $nome . ' não corresponde a nenhuma checagem do registro do piso nem a um insumo declarado em f3b_insumos_de_fixture().', 'analise-estatica', 'build' );
}

/* =========================================================================
 * PISO DA BANCADA WORDPRESS.
 *
 * O piso de um detector de análise estática é uma árvore de arquivos. O piso de
 * um passo de bancada não pode ser isso: o caso negativo dele é um PLUGIN
 * INSTALADO com o defeito dentro, num WordPress que sobe e responde. Por isso
 * ele mora em `suite/bancada-wp/`, é declarado em `pisos.tsv` e roda pelo mesmo
 * `bancada.sh` que a rodada usa — o piso executa a MESMA coisa que o teto, com
 * a árvore trocada, que é a regra dura deste arquivo desde a primeira linha.
 * ====================================================================== */

echo "\n== piso da bancada WordPress: cada passo contra a árvore mutante ==\n";

$passos_da_bancada = f3b_bancada_passos( $suite );
$bancada_desligada = f3b_bancada_desligada();

if ( array() === $passos_da_bancada ) {
	estado(
		'BLOCKED',
		'bancada.ambiente',
		'a bancada não declara passo nenhum: suite/bancada-wp/pisos.tsv está vazia ou ausente. Recurso ausente: suite/bancada-wp/pisos.tsv.',
		'pendencia-externa',
		'build'
	);
} elseif ( '' !== $bancada_desligada ) {
	foreach ( array_keys( $passos_da_bancada ) as $nome_do_passo ) {
		estado( 'N/A', $nome_do_passo, 'condição declarada: ' . $bancada_desligada . '.', 'wp-real', 'build' );
	}
} else {
	$piso_da_bancada = f3b_rodar_bancada( $suite, '', 'piso', $raiz );

	if ( '' !== $piso_da_bancada['erro'] ) {
		foreach ( array_keys( $passos_da_bancada ) as $nome_do_passo ) {
			estado(
				'BLOCKED',
				$nome_do_passo,
				'o piso da bancada não pôde ser executado, e piso que não roda não prova detecção: ' . $piso_da_bancada['erro'] . '.',
				'pendencia-externa',
				'build'
			);
		}
	} else {
		$ramos_por_passo = array();

		foreach ( $piso_da_bancada['linhas'] as $ramo ) {
			$ramos_por_passo[ $ramo['nome'] ] = true;

			estado(
				$ramo['estado'],
				$ramo['nome'],
				$ramo['mensagem'],
				'bancada.ambiente' === $ramo['nome'] && 'OK' !== $ramo['estado'] ? 'pendencia-externa' : 'wp-real',
				'build'
			);
		}

		foreach ( array_keys( $passos_da_bancada ) as $nome_do_passo ) {
			if ( isset( $ramos_por_passo[ $nome_do_passo ] ) ) {
				continue;
			}

			estado(
				'BLOCKED',
				$nome_do_passo,
				'o passo está declarado em suite/bancada-wp/pisos.tsv e o piso não devolveu ramo nenhum para ele. Recurso ausente: execução completa do piso da bancada.',
				'pendencia-externa',
				'build'
			);
		}
	}
}

echo "\n== resumo do piso ==\n";

/* CONTAGEM E NOMES SAEM JUNTOS, aqui pela mesma razão que no runner. */
$contagem   = F3Base_Suite::contagem();
$nomes_piso = F3Base_Suite::nomes_por_estado();

foreach ( f3b_resumo_por_estado( $contagem, $nomes_piso ) as $linha_do_resumo ) {
	echo $linha_do_resumo . "\n";
}

printf( "   %-8s %d\n", 'TOTAL', array_sum( $contagem ) );

$falhas = F3Base_Suite::falhas();

if ( $falhas > 0 ) {
	printf(
		"\npiso REPROVADO: %d ramo(s) em FALHA — %s.\n",
		$falhas,
		'FALHA: ' . ( array() === $nomes_piso['FALHA'] ? 'nenhum' : implode( ', ', $nomes_piso['FALHA'] ) )
	);
	exit( 1 );
}

printf(
	"\npiso aprovado: %d detector(es) provaram acusar o defeito e calar sobre o correto, e %d passo(s) da bancada WordPress provaram o mesmo contra a árvore mutante — aqueles cujo ramo positivo está declarado pendente de correção saem relatados acima e NÃO contam como cobertos.\n",
	count( $registro ),
	count( $passos_da_bancada )
);

exit( 0 );
