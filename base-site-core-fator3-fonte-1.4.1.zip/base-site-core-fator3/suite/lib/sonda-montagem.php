<?php
/**
 * Sonda de MONTAGEM — monta o zip do plugin e imprime o sha256 dos BYTES.
 *
 * ELA EXISTE PARA QUE O PISO POSSA MOVER O MUNDO EM VOLTA DO BUILD.
 *
 * O piso de `pacote.zip_reprodutivel` precisa provar que a mesma árvore,
 * empacotada com o RELÓGIO em dias diferentes e num VOLUME diferente, dá os
 * mesmos bytes. As duas alavancas só existem de fora do processo: o relógio se
 * move envolvendo o processo em `faketime`, e o volume se move apontando o
 * diretório de saída para outro sistema de arquivos. Um piso que chamasse a
 * função no MESMO processo mediria a si mesmo — provaria que uma função pura
 * devolve o mesmo valor para o mesmo argumento, que é verdade por construção e
 * não diz nada sobre o artefato.
 *
 * O EMPACOTADOR ENTRA POR PARÂMETRO, e é isso que permite o MUTANTE. O piso
 * roda esta mesma sonda duas vezes: uma contra `suite/lib/` do pacote, outra
 * contra uma cópia em que o carimbo voltou ao relógio. Se o mutante não
 * divergir com o relógio movido, a alavanca não tem dente e o piso inteiro é
 * encenação.
 *
 * uso: php suite/lib/sonda-montagem.php <dir-com-empacotar.php> <raiz> <dist>
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$lib  = rtrim( (string) ( $argv[1] ?? '' ), '/' );
$raiz = rtrim( (string) ( $argv[2] ?? '' ), '/' );
$dist = rtrim( (string) ( $argv[3] ?? '' ), '/' );

if ( '' === $lib || ! is_file( $lib . '/empacotar.php' ) || ! is_file( $lib . '/regra.php' ) ) {
	fwrite( STDERR, 'sonda-montagem: pré-condição ausente. Recurso ausente: ' . $lib . "/empacotar.php\n" );
	exit( 2 );
}

if ( '' === $raiz || ! is_dir( $raiz ) || '' === $dist ) {
	fwrite( STDERR, "sonda-montagem: raiz ou destino ausentes\n" );
	exit( 2 );
}

if ( ! is_dir( $dist ) && ! mkdir( $dist, 0755, true ) && ! is_dir( $dist ) ) {
	fwrite( STDERR, 'sonda-montagem: não foi possível preparar ' . $dist . "\n" );
	exit( 2 );
}

require $lib . '/regra.php';
require $lib . '/empacotar.php';

$montado  = f3b_empacotar_site_core( $raiz, $dist );
$artefato = (string) ( $montado['artefato'] ?? '' );

if ( '' === $artefato || ! is_file( $artefato ) ) {
	fwrite( STDERR, "sonda-montagem: o artefato do plugin não foi montado\n" );
	exit( 2 );
}

echo hash_file( 'sha256', $artefato ), "\n", $artefato, "\n";
