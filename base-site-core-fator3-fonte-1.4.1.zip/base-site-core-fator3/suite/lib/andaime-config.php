<?php
/**
 * ANDAIME DE CONFIGURAÇÃO da bancada do site-core.
 *
 * O QUE ESTE ARQUIVO SUBSTITUI, e por que ele existe. No implantador,
 * `suite/lib/sonda-site-core.php` carregava três classes de runtime dele —
 * `F3Base_Imp_Config`, `F3Base_Imp_Decisoes` e `F3Base_Imp_Projeto` — e por
 * elas lia `config/site.json`, `config/projeto.json` e `config/decisoes.tsv`.
 * Não era o PLUGIN que estava sendo configurado ali: era a pergunta que a
 * bancada faz — "o que este site fica sendo quando o implantador acaba de
 * entregá-lo?" — que só tem resposta com os valores do implantador do lado de
 * fora. Neste repositório aquele lado de fora não existe.
 *
 * A SAÍDA É UM RETRATO DECLARADO, e não um valor inventado em cada ponto de
 * uso. `suite/fixtures/config/site-core.json` guarda EXATAMENTE os valores que
 * a sonda recebia — extraídos daqueles três arquivos, com a procedência de cada
 * grupo escrita dentro do próprio fixture — e este leitor é o único caminho
 * até eles. Digitar os valores nos pontos de uso teria espalhado o retrato por
 * trinta e oito lugares, e o primeiro que alguém esquecesse de atualizar faria
 * a bancada medir um site que ninguém entrega.
 *
 * O QUE ELE NÃO É. Ele não é configuração deste plugin, não é lido pelo runtime
 * do plugin e não viaja no zip: mora em `suite/fixtures/`, que é o lugar do que
 * a suíte usa para medir. E ele não reimplementa produtor nenhum — não há aqui
 * merge de três vias, resolução de decisão nem validação de schema; há um mapa
 * chave => valor e uma chave ausente que ABORTA em vez de devolver padrão.
 *
 * CHAVE AUSENTE ABORTA, e essa é a regra dura deste arquivo. Um leitor que
 * devolvesse o padrão do chamador para uma chave que o fixture não tem faria a
 * bancada medir um site com o campo vazio e continuar verde — que é exatamente
 * a classe de aprovação por omissão que a suíte inteira existe para não
 * produzir. O padrão do chamador só vale quando a chave EXISTE e o valor é nulo.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Leitor mínimo do retrato de configuração da bancada.
 */
final class F3Base_Andaime_Config {

	/** @var array<string,mixed>|null Retrato lido do fixture. */
	private static ?array $retrato = null;

	/**
	 * Caminho do fixture, derivado da árvore DESTE arquivo.
	 *
	 * @return string
	 */
	private static function arquivo(): string {
		return dirname( __DIR__ ) . '/fixtures/config/site-core.json';
	}

	/**
	 * Carrega o retrato uma vez, ou morre dizendo o que falta.
	 *
	 * @return array<string,mixed>
	 */
	private static function retrato(): array {
		if ( null !== self::$retrato ) {
			return self::$retrato;
		}

		$caminho = self::arquivo();

		if ( ! is_file( $caminho ) ) {
			fwrite( STDERR, 'andaime-config: pré-condição ausente. Recurso ausente: ' . $caminho . "\n" );
			exit( 2 );
		}

		$lido = json_decode( (string) file_get_contents( $caminho ), true );

		if ( ! is_array( $lido ) ) {
			fwrite( STDERR, 'andaime-config: ' . $caminho . " não é JSON de objeto\n" );
			exit( 2 );
		}

		self::$retrato = $lido;

		return self::$retrato;
	}

	/**
	 * Valor de um grupo do retrato, com a chave cobrada.
	 *
	 * @param string $grupo  Grupo do retrato.
	 * @param string $chave  Chave.
	 * @param mixed  $padrao Padrão do chamador, usado só quando o valor declarado é nulo.
	 * @return mixed
	 */
	private static function do_grupo( string $grupo, string $chave, $padrao ) {
		$mapa = (array) ( self::retrato()[ $grupo ] ?? array() );

		if ( ! array_key_exists( $chave, $mapa ) ) {
			fwrite(
				STDERR,
				'andaime-config: a chave "' . $chave . '" não existe em ' . $grupo . ' de ' . self::arquivo()
					. '. Chave ausente não vira padrão: a bancada mediria um site com o campo vazio e continuaria verde.' . "\n"
			);
			exit( 2 );
		}

		return null === $mapa[ $chave ] ? $padrao : $mapa[ $chave ];
	}

	/**
	 * Uma DECISÃO, no lugar de `F3Base_Imp_Decisoes::valor()`.
	 *
	 * @param string $chave Chave da decisão.
	 * @return mixed
	 */
	public static function decisao( string $chave ) {
		return self::do_grupo( 'decisoes', $chave, null );
	}

	/**
	 * Uma chave do PROJETO, no lugar de `F3Base_Imp_Projeto::obter()`.
	 *
	 * @param string $chave  Chave do projeto.
	 * @param mixed  $padrao Padrão do chamador.
	 * @return mixed
	 */
	public static function projeto( string $chave, $padrao = '' ) {
		return self::do_grupo( 'projeto', $chave, $padrao );
	}

	/**
	 * A versão que a bancada carimba em `F3BASE_PLUGIN_VERSAO`.
	 *
	 * Ela é o retrato do que `config/site.json` do implantador devolvia por
	 * `release.site_core` — e devolvia a string vazia, porque aquela chave nunca
	 * existiu no arquivo entregue. Ler aqui o cabeçalho do plugin daria outro
	 * valor e faria esta bancada medir outra coisa.
	 *
	 * @return string
	 */
	public static function versao_do_plugin(): string {
		return (string) ( self::retrato()['plugin_versao'] ?? '' );
	}
}
