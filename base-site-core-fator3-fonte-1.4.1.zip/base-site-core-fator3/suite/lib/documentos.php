<?php
/**
 * Documentos entregáveis: as regiões GERADAS e o detector que as guarda.
 *
 * A REGRA, e o defeito que a produziu. README, MANIFESTO e MEMORIA-DECISOES são
 * ENTREGÁVEIS: o operador instala por eles e outros agentes constroem sites a
 * partir deles. Da 1.0.6 à 1.0.13 os três ficaram carimbados `1.0.6`, afirmando
 * a lista de domínios como gate de indexação (superado na 1.0.12) e
 * `permalinks_decisao: manter-existente` como padrão (superado na 1.0.11), e
 * imprimindo contagens que a rodada da vez contradizia. Sete releases passaram
 * por cima disso sem que nada acusasse.
 *
 * Trazer os números à mão só adia: eles envelhecem de novo na próxima release.
 * Então:
 *
 * 1. **Número em documento entregável é GERADO, não digitado.** Ele sai de
 *    LEITURA DE DISCO no empacotamento — a primeira etapa do comando único, e
 *    portanto antes de o bundle ser montado, para que o que viaja seja o
 *    documento atualizado.
 * 2. **O que não pode ser gerado no momento da escrita sai como PENDÊNCIA
 *    NOMEADA**, nunca como número velho. A contagem por estado da rodada é
 *    resultado da rodada: ela não existe quando os documentos são escritos, e o
 *    carimbo diz isso e aponta para `suite/rodada.json`, que é o artefato
 *    gerado que a carrega.
 * 3. **`estatica.carimbo_de_release_nos_documentos` compara o que está no disco
 *    com o que a medição de agora produz.** É ele que impede a recorrência —
 *    vale mais do que a correção pontual, porque a correção pontual é o que já
 *    foi feito sete vezes.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Abertura de uma região gerada.
 *
 * Montada por concatenação de propósito: escrita inteira, ESTA função conteria
 * o marcador que ela procura, e o arquivo do gerador viraria uma quarta cópia
 * do carimbo dentro do pacote.
 *
 * SEM PREFIXO, e isso mudou na 1.0.15 por uma razão medida. Este pacote virou
 * template de criação de sites, e a renomeação de prefixo NÃO reescreve
 * `MEMORIA-DECISOES.md`: aquele documento narra defeitos observados citando
 * diretórios e nomes reais, e trocar o prefixo neles inventaria um passado que
 * não aconteceu. Com o prefixo dentro do marcador, o documento não reescrito
 * ficaria com marcadores que o gerador renomeado não encontraria mais, e a
 * região gerada deixaria de ser regenerada em silêncio. O marcador delimita uma
 * região dentro dos documentos do próprio pacote e não disputa espaço de nome
 * com ninguém: não precisa de prefixo, e sem ele o documento é o mesmo nos dois
 * prefixos.
 *
 * @param string $regiao Nome da região.
 * @return string
 */
function f3b_marca_inicio( string $regiao ): string {
	return '<!-- gerado:' . 'inicio=' . $regiao . ' -->';
}

/**
 * Fecho de uma região gerada.
 *
 * @param string $regiao Nome da região.
 * @return string
 */
function f3b_marca_fim( string $regiao ): string {
	return '<!-- gerado:' . 'fim=' . $regiao . ' -->';
}

/**
 * Quais documentos são ENTREGÁVEIS e quais regiões cada um carrega.
 *
 * Fonte única do escopo: o gerador escreve por esta lista e o detector cobra
 * por ela. Documento entregável sem região gerada é documento que envelhece
 * calado — foi o que aconteceu sete vezes seguidas no implantador.
 *
 * SÃO QUATRO, E A REGIÃO `carimbo` VOLTOU — com outro conteúdo. No implantador
 * ela carregava `release.identidade`, lida de `config/site.json`; aqui não há
 * `config/site.json` nem release do implantador, e o que ela carrega é a
 * identidade DESTE artefato, lida do cabeçalho do arquivo principal do plugin.
 * O nome ficou porque o papel é o mesmo — o bloco que diz de qual artefato este
 * documento fala —, e trocá-lo obrigaria a reescrever os três documentos por
 * uma razão que não é deles.
 *
 * `fontes/plugin/INSTRUCOES-DO-PLUGIN.md` continua com regiões de nome próprio,
 * prefixadas `plugin-`: ele viaja DENTRO do zip e é o único que sai do
 * repositório, e as tabelas dele descrevem o produto, não a release.
 *
 * @return array<string,array<int,string>>
 */
function f3b_regioes_dos_documentos(): array {
	return array(
		'README.md'           => array(
			'carimbo',
			'arvore',
		),
		'MANIFESTO.md'        => array(
			'carimbo',
			'inventario',
			'requisitos',
			'fixtures',
			'excluidas',
		),
		'MEMORIA-DECISOES.md' => array(
			'carimbo',
			'contagem',
		),
		'fontes/plugin/INSTRUCOES-DO-PLUGIN.md' => array(
			'plugin-identidade',
			'plugin-modulos',
			'plugin-options',
			'plugin-eventos',
			'plugin-rotas',
			'plugin-tabelas',
			'plugin-limites',
			'plugin-peso',
		),
	);
}




/* =========================================================================
 * O DOCUMENTO QUE VIAJA DENTRO DO ZIP DO PLUGIN
 *
 * `fontes/plugin/INSTRUCOES-DO-PLUGIN.md` é entregável como os três da raiz, e
 * pela mesma razão: outro agente opera e MUDA o plugin lendo por ele. A
 * diferença é o destino — ele viaja dentro do zip do plugin, e não do bundle —,
 * e a consequência é que a identidade dele NÃO é a da release do implantador:
 * o plugin tem numeração própria desde a 1.7.0, e carimbar a identidade da
 * release nele desfaria em uma linha a separação que aquela release custou.
 *
 * É por isso que as regiões dele têm nomes próprios e nenhuma se chama
 * `carimbo`: a cláusula de identidade de `f3b_ck_carimbo_de_release_nos_documentos`
 * vale só para a região com esse nome, e ela cobra `release.identidade`.
 *
 * NENHUMA DESTAS FUNÇÕES ESCREVE O PREFIXO DO TEMPLATE, e isso não é estilo. Este
 * arquivo É reescrito pela renomeação de prefixo, e a fonte do plugin NÃO é: uma
 * glob escrita com o prefixo aqui encontraria os módulos no pacote de origem e
 * nenhum módulo no pacote renomeado, e o documento passaria a ser regenerado
 * VAZIO num site derivado, sem nada acusando. Tudo aqui é encontrado por forma —
 * `class-*-modulo-*.php` — ou lido do próprio arquivo do plugin.
 * ====================================================================== */

/**
 * A raiz da fonte do plugin dentro do pacote.
 *
 * @param string $raiz Raiz do pacote.
 * @return string
 */
function f3b_fonte_do_plugin( string $raiz ): string {
	return $raiz . '/fontes/plugin';
}

/**
 * O arquivo principal do plugin, ou string vazia quando ele não existe.
 *
 * O nome do arquivo NÃO carrega o prefixo do template — é o nome do artefato —,
 * e é por isso que ele sobrevive à renomeação sem exceção declarada.
 *
 * @param string $raiz Raiz do pacote.
 * @return string
 */
function f3b_principal_do_plugin( string $raiz ): string {
	$caminho = f3b_fonte_do_plugin( $raiz ) . '/base-site-core-fator3.php';

	return is_file( $caminho ) ? $caminho : '';
}

/**
 * Um campo do cabeçalho do plugin, lido do arquivo principal.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $campo Nome do campo do cabeçalho.
 * @return string
 */
function f3b_cabecalho_do_plugin( string $raiz, string $campo ): string {
	$principal = f3b_principal_do_plugin( $raiz );

	if ( '' === $principal ) {
		return '';
	}

	$topo = (string) file_get_contents( $principal, false, null, 0, 8192 );

	if ( 1 === preg_match( '/^[\s*#@]*' . preg_quote( $campo, '/' ) . ':\s*(.+?)\s*$/mi', $topo, $achou ) ) {
		return trim( (string) $achou[1] );
	}

	return '';
}

/**
 * O valor de uma constante `define()` do arquivo principal, pelo SUFIXO do nome.
 *
 * O sufixo é a metade que não muda: o prefixo da constante é o do plugin, e
 * escrevê-lo aqui traria de volta o literal que esta seção existe para evitar.
 *
 * @param string $raiz   Raiz do pacote.
 * @param string $sufixo Sufixo do nome da constante.
 * @return string
 */
function f3b_constante_do_plugin( string $raiz, string $sufixo ): string {
	$principal = f3b_principal_do_plugin( $raiz );

	if ( '' === $principal ) {
		return '';
	}

	$fonte = (string) file_get_contents( $principal );
	$busca = '/define\(\s*\'[A-Z0-9_]*' . preg_quote( $sufixo, '/' ) . '\'\s*,\s*\'([^\']*)\'/';

	return 1 === preg_match( $busca, $fonte, $achou ) ? (string) $achou[1] : '';
}

/**
 * Os arquivos de MÓDULO do plugin, encontrados por FORMA e não por prefixo.
 *
 * `class-*-modulo-<nome>.php` é módulo; `class-*-modulo.php` é o CONTRATO deles,
 * e por isso fica de fora — contá-lo como módulo inflaria toda medida deste
 * documento em um.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,string> Caminhos absolutos, em ordem de caminho.
 */
function f3b_arquivos_de_modulo( string $raiz ): array {
	$achados = glob( f3b_fonte_do_plugin( $raiz ) . '/includes/class-*-modulo-*.php' ) ?: array();

	sort( $achados );

	return array_values( array_map( 'strval', $achados ) );
}

/**
 * O nome da classe declarada num arquivo do plugin.
 *
 * @param string $caminho Caminho absoluto.
 * @return string
 */
function f3b_classe_do_arquivo( string $caminho ): string {
	$fonte = (string) @file_get_contents( $caminho );

	return 1 === preg_match( '/^\s*(?:final\s+|abstract\s+)?class\s+([A-Za-z0-9_]+)/m', $fonte, $achou )
		? (string) $achou[1]
		: '';
}

/**
 * Um bloco de método, sem comentário, pelo nome.
 *
 * @param string $fonte  Código do arquivo.
 * @param string $metodo Nome do método.
 * @return string
 */
function f3b_corpo_do_metodo( string $fonte, string $metodo ): string {
	$busca = '/function\s+' . preg_quote( $metodo, '/' ) . '\s*\([^)]*\)\s*:\s*[a-zA-Z]+\s*\{(.*?)\n\t\}/s';

	if ( 1 !== preg_match( $busca, $fonte, $achou ) ) {
		return '';
	}

	return (string) preg_replace( '#/\*.*?\*/#s', '', (string) $achou[1] );
}

/**
 * Resolve `self::CONST` contra as constantes do próprio arquivo.
 *
 * @param string $fonte Código do arquivo.
 * @param string $bruto Expressão como aparece no código.
 * @return string
 */
function f3b_valor_literal( string $fonte, string $bruto ): string {
	$bruto = trim( $bruto );

	if ( 1 === preg_match( '/^\'([^\']*)\'$/', $bruto, $achou ) ) {
		return (string) $achou[1];
	}

	if ( 1 === preg_match( '/^self::([A-Z0-9_]+)$/', $bruto, $achou ) ) {
		$busca = '/const\s+' . preg_quote( (string) $achou[1], '/' ) . '\s*=\s*\'([^\']*)\'/';

		if ( 1 === preg_match( $busca, $fonte, $valor ) ) {
			return (string) $valor[1];
		}
	}

	return $bruto;
}

/**
 * Os NOMES do array que um método do próprio arquivo devolve.
 *
 * Serve a `options_que_controlam()` que delega — `array_keys( self::tags() )` é
 * a forma medida — e é escrita por INDENTAÇÃO, e não por nome de método: o
 * nível do `return array(` decide o que é entrada de primeiro nível, e tanto a
 * chave (`'nome' => array(`) quanto o valor solto (`'nome',`) contam. Nome de
 * método escrito aqui faria a regra valer para um módulo e não para o próximo.
 *
 * @param string $fonte  Código do arquivo.
 * @param string $metodo Nome do método chamado.
 * @return array<int,string>
 */
function f3b_nomes_do_array_devolvido( string $fonte, string $metodo ): array {
	$corpo = f3b_corpo_do_metodo( $fonte, $metodo );

	if ( 1 !== preg_match( '/(\t*)return array\(\n(.*)/s', $corpo, $achou ) ) {
		return array();
	}

	$nivel  = (string) $achou[1] . "\t";
	$dentro = "\n" . (string) $achou[2];
	$nomes  = array();

	/*
	 * A CLASSE `[=,]` NO LUGAR DA SETA, e não é estilo: escrita inteira, a seta
	 * dentro de um literal concatenado faz `estatica.detector_codigo_em_string`
	 * ler esta linha como JavaScript montado por pedaços. A classe cobre as duas
	 * formas de entrada de primeiro nível — chave e valor solto — porque só elas
	 * podem seguir o nome citado nesse nível.
	 */
	if ( preg_match_all( '/\n' . $nivel . '\'([a-z0-9_]+)\'\s*[=,]/', $dentro, $lista ) ) {
		$nomes = array_map( 'strval', $lista[1] );
	}

	return $nomes;
}

/**
 * A ficha de um módulo, lida do arquivo dele.
 *
 * @param string $caminho Caminho absoluto do arquivo do módulo.
 * @return array{classe:string,arquivo:string,id:string,options:array<int,string>,hooks:array<int,string>}
 */
function f3b_ficha_do_modulo( string $caminho ): array {
	$fonte = (string) @file_get_contents( $caminho );

	$id = '';
	if ( 1 === preg_match( '/function\s+id\(\)\s*:\s*string\s*\{\s*return\s+\'([^\']*)\'/', $fonte, $achou ) ) {
		$id = (string) $achou[1];
	}

	$options = array();
	$corpo   = f3b_corpo_do_metodo( $fonte, 'options_que_controlam' );

	/*
	 * `self::CONST` É RESOLVIDO, e não ignorado. Um módulo que declara a option
	 * dele por constante — e há um — sairia deste documento com a lista
	 * incompleta, afirmando que ele não lê o que ele lê.
	 */
	if ( preg_match_all( '/\'([a-z0-9_]+)\'|self::([A-Z0-9_]+)/', $corpo, $achou, PREG_SET_ORDER ) ) {
		foreach ( $achou as $item ) {
			$valor = '' !== (string) ( $item[1] ?? '' )
				? (string) $item[1]
				: f3b_valor_literal( $fonte, 'self::' . (string) ( $item[2] ?? '' ) );

			if ( '' !== $valor && ! in_array( $valor, $options, true ) ) {
				$options[] = $valor;
			}
		}
	}

	/*
	 * CHAMADA A MÉTODO DO PRÓPRIO MÓDULO É RESOLVIDA, e este é o defeito que a
	 * revisão da 1.0.1 mediu: o módulo de verificação de domínio declara as
	 * options dele por `array_keys( self::tags() )`, e a tabela gerada dizia
	 * "nenhuma" — o documento afirmava que um módulo não é controlado por
	 * option nenhuma quando ele é controlado por duas. Ler só literal e
	 * `self::CONST` é ler metade das formas em que uma lista pode ser
	 * declarada, e a metade não lida sai como ausência, que é a pior saída
	 * possível: ausência parece um fato medido.
	 *
	 * A RESOLUÇÃO É ESTRUTURAL E VALE PARA TODO MÓDULO: o método chamado é
	 * lido do mesmo arquivo e as CHAVES (ou os valores) do array que ele
	 * devolve entram na lista, no nível de indentação do `return array(` dele.
	 * Nada aqui conhece o nome `tags` nem o prefixo do template.
	 */
	if ( preg_match_all( '/self::([a-z_][a-zA-Z0-9_]*)\s*\(/', $corpo, $chamadas ) ) {
		foreach ( $chamadas[1] as $metodo ) {
			foreach ( f3b_nomes_do_array_devolvido( $fonte, (string) $metodo ) as $valor ) {
				if ( ! in_array( $valor, $options, true ) ) {
					$options[] = $valor;
				}
			}
		}
	}

	$hooks = array();
	$corpo = f3b_corpo_do_metodo( $fonte, 'hooks' );

	if ( preg_match_all( '/\'tipo\'\s*=>\s*\'([a-z]+)\'.*?\'hook\'\s*=>\s*([^,\n]+).*?\'prioridade\'\s*=>\s*([0-9]+)/s', $corpo, $achou, PREG_SET_ORDER ) ) {
		foreach ( $achou as $item ) {
			$hooks[] = $item[1] . ' ' . f3b_valor_literal( $fonte, (string) $item[2] ) . ' (' . $item[3] . ')';
		}
	}

	return array(
		'classe'  => f3b_classe_do_arquivo( $caminho ),
		'arquivo' => basename( $caminho ),
		'id'      => $id,
		'options' => $options,
		'hooks'   => $hooks,
	);
}

/**
 * O catálogo de options do plugin, lido do gravador único.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,array{nome:string,secao:string,campo:string,operavel:string,sanitiza:string,subcampos:int}>
 */
function f3b_catalogo_do_plugin( string $raiz ): array {
	$arquivos = glob( f3b_fonte_do_plugin( $raiz ) . '/includes/class-*-options.php' ) ?: array();

	if ( array() === $arquivos ) {
		return array();
	}

	$fonte = (string) file_get_contents( (string) $arquivos[0] );

	/*
	 * A LEITURA É RESTRITA AO CORPO DE `catalogo()`, e a restrição fecha um
	 * defeito medido: varrendo o arquivo inteiro, qualquer `'chave' => array(`
	 * escrito no mesmo nível de indentação em OUTRO método entrava no catálogo.
	 * Dois blocos `'avisos' => array(` de sanitizadores de escrita eram lidos
	 * como options, e o documento publicava um catálogo com duas entradas a
	 * mais — inclusive na contagem da região de identidade, que é lida como
	 * fato medido. O catálogo é o corpo de um método, e é dele que ele sai.
	 */
	$corpo  = f3b_corpo_do_metodo( $fonte, 'catalogo' );
	$saida  = array();
	$partes = preg_split( '/\n\t\t\t\'([a-z0-9_]+)\'\s*=> array\(/', $corpo, -1, PREG_SPLIT_DELIM_CAPTURE );

	if ( ! is_array( $partes ) ) {
		return array();
	}

	for ( $i = 1; $i < count( $partes ); $i += 2 ) {
		$nome  = (string) $partes[ $i ];
		$bloco = (string) ( $partes[ $i + 1 ] ?? '' );
		$bloco = substr( $bloco, 0, (int) ( strpos( $bloco, "\n\t\t\t)," ) ?: strlen( $bloco ) ) );

		$secao = 1 === preg_match( '/\'secao\'\s*=>\s*self::SECAO_([A-Z_]+)/', $bloco, $achou )
			? strtolower( (string) $achou[1] )
			: '—';

		$campo = 1 === preg_match( '/\'campo\'\s*=>\s*\'([a-z]+)\'/', $bloco, $achou ) ? (string) $achou[1] : '—';

		$sanitiza = 1 === preg_match( '/\'sanitiza\'\s*=>\s*array\(\s*__CLASS__,\s*\'([a-z0-9_]+)\'/', $bloco, $achou )
			? (string) $achou[1]
			: '—';

		$subcampos = 0;
		if ( 1 === preg_match( '/\'subcampos\'\s*=> array\((.*)/s', $bloco, $achou ) ) {
			$subcampos = (int) preg_match_all( '/\n\t\t\t\t\t\'([a-z0-9_]+)\'\s*=> array\(/', (string) $achou[1] );
		}

		$saida[] = array(
			'nome'      => $nome,
			'secao'     => $secao,
			'campo'     => $campo,
			'operavel'  => 1 === preg_match( '/\'operavel\'\s*=>\s*true/', $bloco ) ? 'sim' : 'não',
			'sanitiza'  => $sanitiza,
			'subcampos' => $subcampos,
		);
	}

	return $saida;
}

/**
 * As rotas REST registradas pelo plugin, lidas de cada `register_rest_route()`.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,array{rota:string,metodo:string,permissao:string,arquivo:string}>
 */
function f3b_rotas_do_plugin( string $raiz ): array {
	$fonte_do_plugin = f3b_fonte_do_plugin( $raiz );
	$saida           = array();

	foreach ( f3b_arquivos( $fonte_do_plugin, array( 'php' ), array() ) as $rel ) {
		$fonte = (string) file_get_contents( $fonte_do_plugin . '/' . $rel );

		if ( ! preg_match_all( '/register_rest_route\(\s*[^,]+,\s*([^,]+),\s*array\((.*?)\n\t\t\t\)/s', $fonte, $achou, PREG_SET_ORDER ) ) {
			continue;
		}

		foreach ( $achou as $item ) {
			$corpo = (string) $item[2];

			$metodo = 1 === preg_match( '/\'methods\'\s*=>\s*\'([A-Z]+)\'/', $corpo, $m ) ? (string) $m[1] : '—';

			$permissao = '—';
			if ( 1 === preg_match( '/\'permission_callback\'\s*=>\s*\'([^\']+)\'/', $corpo, $p ) ) {
				$permissao = (string) $p[1];
			} elseif ( 1 === preg_match( '/\'permission_callback\'.*?current_user_can\(\s*\'([a-z_]+)\'/s', $corpo, $p ) ) {
				$permissao = 'current_user_can( ' . (string) $p[1] . ' )';
			} elseif ( 1 === preg_match( '/\'permission_callback\'\s*=>\s*array\(\s*\$this,\s*\'([a-z_]+)\'/', $corpo, $p ) ) {
				$permissao = (string) $p[1] . '()';
			}

			$saida[] = array(
				'rota'      => f3b_valor_literal( $fonte, (string) $item[1] ),
				'metodo'    => $metodo,
				'permissao' => $permissao,
				'arquivo'   => $rel,
			);
		}
	}

	usort(
		$saida,
		static fn( array $a, array $b ): int => strcmp( $a['rota'], $b['rota'] )
	);

	return $saida;
}

/**
 * As TABELAS próprias do plugin com as colunas de cada uma, lidas do CREATE TABLE.
 *
 * O PAREAMENTO É POR CONJUNTO DE COLUNAS, e não pela ordem em que os blocos
 * aparecem no arquivo: a constante `COLUNAS…` de cada tabela declara o que ESTA
 * versão exige, e é ela que casa com o bloco. Parear por ordem faria o documento
 * trocar as duas tabelas de nome no dia em que alguém movesse um bloco.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,array{tabela:string,colunas:array<int,array{nome:string,tipo:string}>,chaves:array<int,string>}>
 */
function f3b_tabelas_do_plugin( string $raiz ): array {
	$fonte_do_plugin = f3b_fonte_do_plugin( $raiz );
	$saida           = array();

	foreach ( f3b_arquivos( $fonte_do_plugin, array( 'php' ), array() ) as $rel ) {
		$fonte = (string) file_get_contents( $fonte_do_plugin . '/' . $rel );

		if ( ! preg_match_all( '/CREATE TABLE \{\$[a-z_]+\} \(\n(.*?)\n\)/s', $fonte, $blocos, PREG_SET_ORDER ) ) {
			continue;
		}

		if ( ! preg_match_all( '/const\s+COLUNAS([A-Z_]*)\s*=\s*array\(([^)]*)\)/', $fonte, $consts, PREG_SET_ORDER ) ) {
			continue;
		}

		foreach ( $consts as $const ) {
			$sufixo = (string) $const[1];

			if ( 1 !== preg_match( '/const\s+TABELA' . preg_quote( $sufixo, '/' ) . '\s*=\s*\'([^\']+)\'/', $fonte, $nome ) ) {
				continue;
			}

			$exigidas = array();
			if ( preg_match_all( '/\'([a-z_]+)\'/', (string) $const[2], $lista ) ) {
				$exigidas = array_map( 'strval', $lista[1] );
			}

			foreach ( $blocos as $bloco ) {
				$colunas = array();
				$chaves  = array();

				foreach ( preg_split( '/\R/', (string) $bloco[1] ) ?: array() as $linha ) {
					$linha = trim( (string) $linha, " \t," );

					if ( '' === $linha ) {
						continue;
					}

					if ( 1 === preg_match( '/^(PRIMARY KEY|KEY|UNIQUE KEY)\s+(.+)$/', $linha, $chave ) ) {
						$chaves[] = trim( (string) $chave[1] . ' ' . (string) $chave[2] );
						continue;
					}

					if ( 1 === preg_match( '/^([a-z_]+)\s+(.+)$/', $linha, $coluna ) ) {
						$colunas[] = array(
							'nome' => (string) $coluna[1],
							'tipo' => trim( (string) $coluna[2] ),
						);
					}
				}

				$nomes = array_map( static fn( array $c ): string => $c['nome'], $colunas );

				if ( array() !== array_diff( $exigidas, $nomes ) || array() !== array_diff( $nomes, $exigidas ) ) {
					continue;
				}

				$saida[] = array(
					'tabela'  => (string) $nome[1],
					'colunas' => $colunas,
					'chaves'  => $chaves,
				);
			}
		}
	}

	usort(
		$saida,
		static fn( array $a, array $b ): int => strcmp( $a['tabela'], $b['tabela'] )
	);

	return $saida;
}

/**
 * OS LIMITES do plugin, lidos de onde eles são decididos: o código.
 *
 * POR QUE ESTA REGIÃO EXISTE. O documento do plugin afirmava "nenhum número
 * deste documento é digitado à mão" e trazia vinte e seis números na prosa —
 * tetos de corpo, linhas por lote, tolerância de relógio, prazo de token,
 * janela de balde. Eles passavam pela isenção de `pacote.instrucoes_do_plugin_no_zip`
 * (número em vão de código que existe verbatim na fonte), e passar não é a
 * mesma coisa que estar certo: o número continuava DIGITADO, e um teto ajustado
 * no código deixava para trás a frase que o citava, sem nada acusando. Aqui ele
 * é LIDO.
 *
 * DUAS FORMAS, porque o plugin decide limite de duas maneiras e só duas:
 *
 * 1. **Constante numérica** — `const NOME = <inteiro>;`. É o teto que não se
 *    ajusta de fora.
 * 2. **Padrão de filtro** — `apply_filters( '<gancho>', <expressão numérica> )`.
 *    É o prazo ou o tamanho que o site pode esticar, e o que o documento
 *    precisa dizer é o PADRÃO e o ponto de ajuste.
 *
 * A varredura é por FORMA, e não por lista de nomes: lista escrita aqui seria o
 * número digitado voltando por outra porta, agora com uma curadoria que
 * envelhece calada. Expressão que não é aritmética de inteiro e de constante de
 * tempo do núcleo fica de fora porque não é limite — é código.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{constantes:array<int,array{simbolo:string,valor:string,arquivo:string}>,filtros:array<int,array{gancho:string,padrao:string,arquivo:string}>}
 */
function f3b_limites_do_plugin( string $raiz ): array {
	$fonte_do_plugin = f3b_fonte_do_plugin( $raiz );
	$constantes      = array();
	$filtros         = array();

	foreach ( f3b_arquivos( $fonte_do_plugin, array( 'php' ), array() ) as $rel ) {
		$fonte  = (string) file_get_contents( $fonte_do_plugin . '/' . $rel );
		$classe = f3b_classe_do_arquivo( $fonte_do_plugin . '/' . $rel );

		if ( preg_match_all( '/const\s+([A-Z][A-Z0-9_]*)\s*=\s*([0-9]+)\s*;/', $fonte, $achou, PREG_SET_ORDER ) ) {
			foreach ( $achou as $item ) {
				$constantes[] = array(
					'simbolo' => ( '' === $classe ? '' : $classe . '::' ) . (string) $item[1],
					'valor'   => (string) $item[2],
					'arquivo' => basename( $rel ),
				);
			}
		}

		$numero = '(?:[0-9]+|[A-Z][A-Z0-9_]*)';

		if ( preg_match_all( '/apply_filters\(\s*\'([a-z0-9_]+)\',\s*(' . $numero . '(?:\s*\*\s*' . $numero . ')*)\s*\)/', $fonte, $achou, PREG_SET_ORDER ) ) {
			foreach ( $achou as $item ) {
				$filtros[ (string) $item[1] . '|' . (string) $item[2] ] = array(
					'gancho'  => (string) $item[1],
					'padrao'  => (string) $item[2],
					'arquivo' => basename( $rel ),
				);
			}
		}
	}

	usort(
		$constantes,
		static fn( array $a, array $b ): int => strcmp( $a['simbolo'], $b['simbolo'] )
	);

	$filtros = array_values( $filtros );

	usort(
		$filtros,
		static fn( array $a, array $b ): int => strcmp( $a['gancho'], $b['gancho'] )
	);

	return array(
		'constantes' => $constantes,
		'filtros'    => $filtros,
	);
}

/**
 * O PESO ENTREGUE de cada `.js` do plugin, pelo MESMO corte do empacotamento.
 *
 * A medida sai da FONTE passada por `f3b_conteudo_entregue()`, e não do que
 * `dist/entregue/` guarda: os documentos são regenerados na primeira etapa do
 * comando único, antes de o zip ser montado, e ler a saída de build aqui faria
 * o documento que VIAJA carregar o peso da rodada anterior.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,array{arquivo:string,fonte:int,entregue:int,fonte_gz:int,entregue_gz:int}>
 */
function f3b_peso_entregue_do_plugin( string $raiz ): array {
	$fonte_do_plugin = f3b_fonte_do_plugin( $raiz );
	$saida           = array();

	foreach ( f3b_arquivos( $fonte_do_plugin, array( 'js' ), array() ) as $rel ) {
		$bruto = (string) file_get_contents( $fonte_do_plugin . '/' . $rel );
		$corpo = f3b_conteudo_entregue( $rel, $bruto );

		$saida[] = array(
			'arquivo'     => $rel,
			'fonte'       => strlen( $bruto ),
			'entregue'    => strlen( $corpo ),
			'fonte_gz'    => strlen( (string) gzencode( $bruto, 9 ) ),
			'entregue_gz' => strlen( (string) gzencode( $corpo, 9 ) ),
		);
	}

	return $saida;
}


/**
 * O conteúdo de uma região gerada do documento do PLUGIN.
 *
 * Separado de `f3b_conteudo_da_regiao()` porque o escopo é outro: aqui nada é
 * lido de `config/site.json` e nada carrega a identidade da release. Tudo sai
 * da fonte do plugin.
 *
 * @param string $raiz   Raiz do pacote.
 * @param string $regiao Região.
 * @return string
 */
function f3b_conteudo_da_regiao_do_plugin( string $raiz, string $regiao ): string {
	if ( 'plugin-identidade' === $regiao ) {
		$modulos   = f3b_arquivos_de_modulo( $raiz );
		$catalogo  = f3b_catalogo_do_plugin( $raiz );
		$eventos   = f3b_tsv( f3b_fonte_do_plugin( $raiz ) . '/dados/eventos-comportamento.tsv' );
		$operaveis = 0;

		foreach ( $catalogo as $option ) {
			if ( 'sim' === $option['operavel'] ) {
				++$operaveis;
			}
		}

		/*
		 * A ORIGEM DE CADA ARQUIVO, separada de disco pela lista declarada em
		 * `f3b_insumos_partilhados()`. No implantador a separação era o próprio
		 * diretório — `fontes/plugin/` de um lado, `partilhado/` do outro —, e
		 * aqui os dois já chegaram fundidos: sem a lista, os dois números
		 * mudariam por causa da fusão, e o documento leria como se o plugin
		 * tivesse crescido cinco arquivos e perdido o contrato compartilhado.
		 */
		$partilhados = array();
		$proprios    = array();

		foreach ( f3b_arquivos( f3b_fonte_do_plugin( $raiz ) ) as $rel_do_plugin ) {
			if ( isset( f3b_insumos_partilhados()[ $rel_do_plugin ] ) ) {
				$partilhados[] = $rel_do_plugin;
				continue;
			}

			$proprios[] = $rel_do_plugin;
		}

		$fatos = array(
			'Nome do artefato'                       => '`' . f3b_cabecalho_do_plugin( $raiz, 'Plugin Name' ) . '`',
			'Versão, lida do cabeçalho'              => '`' . f3b_cabecalho_do_plugin( $raiz, 'Version' ) . '`',
			'Pasta instalada'                        => '`base-site-core-fator3`',
			'Prefixo interno'                        => '`' . f3b_constante_do_plugin( $raiz, 'PREFIXO' ) . '`',
			'Namespace REST'                         => '`' . f3b_constante_do_plugin( $raiz, 'REST_NAMESPACE' ) . '`',
			'Text domain'                            => '`' . f3b_cabecalho_do_plugin( $raiz, 'Text Domain' ) . '`',
			'WordPress mínimo · PHP mínimo'          => '`' . f3b_cabecalho_do_plugin( $raiz, 'Requires at least' ) . '` · `' . f3b_cabecalho_do_plugin( $raiz, 'Requires PHP' ) . '`',
			'Módulos no registro único'              => (string) count( $modulos ),
			'Options no catálogo'                    => (string) count( $catalogo ),
			'Options operáveis na tela'              => (string) $operaveis,
			'Eventos de comportamento declarados'    => (string) count( $eventos ),
			'Rotas REST registradas'                 => (string) count( f3b_rotas_do_plugin( $raiz ) ),
			'Tabelas próprias com colunas declaradas' => (string) count( f3b_tabelas_do_plugin( $raiz ) ),
			'Arquivos na fonte do plugin'            => (string) count( $proprios ),
			'Arquivos vindos de `partilhado/`'       => (string) count( $partilhados ),
		);

		$linhas = array(
			'> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip',
			'> ser montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número deste',
			'> documento é digitado à mão: número digitado envelhece em silêncio, e um documento que descreve',
			'> outro plugin é pior do que documento nenhum.',
			'',
			'| Fato medido | Valor |',
			'|---|---|',
		);

		foreach ( $fatos as $rotulo => $valor ) {
			$linhas[] = '| ' . $rotulo . ' | ' . $valor . ' |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'plugin-modulos' === $regiao ) {
		$linhas = array(
			'| Módulo | Arquivo | Options que o controlam | Hooks (tipo, gancho, prioridade) |',
			'|---|---|---|---|',
		);

		foreach ( f3b_arquivos_de_modulo( $raiz ) as $caminho ) {
			$ficha = f3b_ficha_do_modulo( $caminho );

			$linhas[] = '| `' . $ficha['classe'] . '`<br>id `' . $ficha['id'] . '` | `' . $ficha['arquivo'] . '` | '
				. ( array() === $ficha['options'] ? 'nenhuma' : '`' . implode( '`, `', $ficha['options'] ) . '`' ) . ' | '
				. ( array() === $ficha['hooks'] ? 'nenhum' : '`' . implode( '`<br>`', $ficha['hooks'] ) . '`' ) . ' |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'plugin-options' === $regiao ) {
		$linhas = array(
			'| Option | Seção da tela | Campo | Operável | Sub-campos | Sanitizador |',
			'|---|---|---|---|---|---|',
		);

		foreach ( f3b_catalogo_do_plugin( $raiz ) as $option ) {
			$linhas[] = '| `' . $option['nome'] . '` | ' . $option['secao'] . ' | ' . $option['campo'] . ' | '
				. $option['operavel'] . ' | ' . ( 0 === $option['subcampos'] ? '—' : (string) $option['subcampos'] )
				. ' | `' . $option['sanitiza'] . '` |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'plugin-eventos' === $regiao ) {
		$linhas = array(
			'| Evento | Gatilho | Parâmetros | Teto por página | Limiar | Natureza |',
			'|---|---|---|---|---|---|',
		);

		foreach ( f3b_tsv( f3b_fonte_do_plugin( $raiz ) . '/dados/eventos-comportamento.tsv' ) as $linha ) {
			$parametros = trim( (string) ( $linha[1] ?? '' ) );

			$linhas[] = '| `' . trim( (string) ( $linha[0] ?? '' ) ) . '` | `' . trim( (string) ( $linha[3] ?? '' ) ) . '` | '
				. ( '' === $parametros ? 'nenhum' : '`' . $parametros . '`' ) . ' | ' . trim( (string) ( $linha[2] ?? '' ) ) . ' | `'
				. trim( (string) ( $linha[4] ?? '' ) ) . '` | ' . trim( (string) ( $linha[7] ?? '' ) ) . ' |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'plugin-rotas' === $regiao ) {
		$namespace = f3b_constante_do_plugin( $raiz, 'REST_NAMESPACE' );

		$linhas = array(
			'| Rota | Método | Autenticação | Onde é registrada |',
			'|---|---|---|---|',
		);

		foreach ( f3b_rotas_do_plugin( $raiz ) as $rota ) {
			$linhas[] = '| `/wp-json/' . $namespace . $rota['rota'] . '` | ' . $rota['metodo'] . ' | `'
				. $rota['permissao'] . '` | `' . $rota['arquivo'] . '` |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'plugin-tabelas' === $regiao ) {
		$linhas = array();

		foreach ( f3b_tabelas_do_plugin( $raiz ) as $tabela ) {
			$linhas[] = '**`<prefixo-do-wpdb>' . $tabela['tabela'] . '`**';
			$linhas[] = '';
			$linhas[] = '| Coluna | Definição |';
			$linhas[] = '|---|---|';

			foreach ( $tabela['colunas'] as $coluna ) {
				$linhas[] = '| `' . $coluna['nome'] . '` | `' . $coluna['tipo'] . '` |';
			}

			foreach ( $tabela['chaves'] as $chave ) {
				$linhas[] = '| _índice_ | `' . $chave . '` |';
			}

			$linhas[] = '';
		}

		return trim( implode( "\n", $linhas ) );
	}

	if ( 'plugin-limites' === $regiao ) {
		$limites = f3b_limites_do_plugin( $raiz );

		$linhas = array(
			'**Tetos fixos — constante do código, sem ponto de ajuste**',
			'',
			'| Constante | Valor | Arquivo |',
			'|---|---|---|',
		);

		foreach ( $limites['constantes'] as $constante ) {
			$linhas[] = '| `' . $constante['simbolo'] . '` | `' . $constante['valor'] . '` | `' . $constante['arquivo'] . '` |';
		}

		$linhas[] = '';
		$linhas[] = '**Prazos e tamanhos ajustáveis — o valor é o PADRÃO do código, e o gancho é onde o site o muda**';
		$linhas[] = '';
		$linhas[] = '| Filtro | Padrão | Arquivo |';
		$linhas[] = '|---|---|---|';

		foreach ( $limites['filtros'] as $filtro ) {
			$linhas[] = '| `' . $filtro['gancho'] . '` | `' . $filtro['padrao'] . '` | `' . $filtro['arquivo'] . '` |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'plugin-peso' === $regiao ) {
		$linhas = array(
			'| Arquivo | Fonte | Entregue | Fonte comprimido | Entregue comprimido |',
			'|---|---|---|---|---|',
		);

		foreach ( f3b_peso_entregue_do_plugin( $raiz ) as $peso ) {
			$linhas[] = '| `' . $peso['arquivo'] . '` | ' . $peso['fonte'] . ' B | ' . $peso['entregue'] . ' B | '
				. $peso['fonte_gz'] . ' B | ' . $peso['entregue_gz'] . ' B |';
		}

		return implode( "\n", $linhas );
	}

	return '';
}

/* =========================================================================
 * OS TRÊS DOCUMENTOS DO REPOSITÓRIO
 *
 * README, MANIFESTO e MEMORIA-DECISOES NÃO viajam dentro do zip do plugin: eles
 * ficam no repositório, e quem os lê é quem instala, quem publica e quem vai
 * mexer no código. É a mesma razão pela qual eles precisam de região gerada —
 * documento entregável com número digitado à mão está certo no dia em que foi
 * escrito e é contradito pela rodada seguinte —, e é por isso que a `carimbo`
 * dos três é O MESMO BLOCO: um fato, um produtor, três documentos que o
 * publicam. Três blocos parecidos seriam três lugares para atualizar, que é
 * exatamente o defeito que a região gerada existe para fechar.
 *
 * NADA AQUI LÊ `dist/`. Os documentos são regenerados na PRIMEIRA etapa do
 * comando único, antes de o zip ser montado: ler a saída de build daqui faria o
 * documento carregar o peso e o digesto da rodada anterior como se fossem
 * desta. NADA do carimbo vem de uma rodada: o digesto do artefato fica FORA
 * dos documentos por construção — um documento do repositório que carregasse o
 * digesto do zip produzido a partir do próprio repositório mudaria a cada
 * checkout novo (o registro do selo não viaja) e nunca fecharia limpo duas vezes
 * seguidas. O digesto é declarado onde ele é contrato: no selo `suite/rodada.json`
 * e na entrada do catálogo do implantador, no ato da publicação.
 * ====================================================================== */

/**
 * O título de cada documento do repositório, com a versão lida do cabeçalho.
 *
 * @param string $doc    Nome do documento.
 * @param string $versao Versão do plugin.
 * @return string
 */
function f3b_titulo_do_documento( string $doc, string $versao ): string {
	$titulos = array(
		'README.md'           => '# Base Site Core Fator3 %s — leia-me do operador',
		'MANIFESTO.md'        => '# Manifesto da release — Base Site Core Fator3 %s',
		'MEMORIA-DECISOES.md' => '# Memória de decisões — Base Site Core Fator3 %s',
	);

	return sprintf( $titulos[ $doc ] ?? '# Base Site Core Fator3 %s', $versao );
}

/**
 * Uma DECLARAÇÃO do cabeçalho do plugin, pela marca que a abre.
 *
 * O `Description:` do arquivo principal declara duas coisas que o operador
 * precisa ler antes de instalar — a plataforma exigida e o escopo de instalação
 * — e elas moram lá porque é o cabeçalho que o WordPress mostra na tela de
 * plugins. Repeti-las à mão aqui seria o segundo lugar que envelhece calado;
 * lidas de lá, elas mudam nos dois lugares de uma vez.
 *
 * A marca é o começo da declaração, e o que sai é a frase até os dois-pontos —
 * a afirmação, sem a justificativa, que continua no cabeçalho e no documento.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $marca Começo da declaração procurada.
 * @return string
 */
function f3b_declaracao_do_cabecalho( string $raiz, string $marca ): string {
	$descricao = f3b_cabecalho_do_plugin( $raiz, 'Description' );

	foreach ( preg_split( '/(?<=\.)\s+/', $descricao ) ?: array() as $frase ) {
		$frase = trim( (string) $frase );

		if ( ! str_contains( $frase, $marca ) ) {
			continue;
		}

		$corte = strpos( $frase, ':' );

		return false === $corte ? $frase : trim( substr( $frase, 0, $corte ) );
	}

	return '';
}

/**
 * As CHECAGENS declaradas no manifesto, agrupadas por classe de evidência.
 *
 * Conta CHECAGEM, e não linha de requisito: o manifesto tem mais de uma linha
 * apontando para a mesma checagem — um fato pode responder a dois requisitos —,
 * e contar linhas publicaria um número maior do que a rodada emite, que é a
 * forma mais fácil de um documento exagerar sem mentir em nenhuma frase.
 *
 * @param string $suite Diretório da suíte.
 * @return array<string,int> Classe de evidência => quantas checagens distintas.
 */
function f3b_checagens_por_evidencia( string $suite ): array {
	$por_checagem = array();

	foreach ( f3b_tsv( $suite . '/manifesto.tsv' ) as $linha ) {
		$checagem  = trim( (string) ( $linha[1] ?? '' ) );
		$evidencia = trim( (string) ( $linha[3] ?? '' ) );

		if ( '' === $checagem || '' === $evidencia ) {
			continue;
		}

		$por_checagem[ $checagem ] = $evidencia;
	}

	$contagem = array();

	foreach ( $por_checagem as $evidencia ) {
		$contagem[ $evidencia ] = ( $contagem[ $evidencia ] ?? 0 ) + 1;
	}

	ksort( $contagem );

	return $contagem;
}

/**
 * Os FATOS MEDIDOS do carimbo, todos por leitura de disco.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array<string,string> Rótulo => valor.
 */
function f3b_fatos_do_carimbo( string $raiz, string $suite ): array {
	$partilhados = array();
	$proprios    = array();

	foreach ( f3b_arquivos( f3b_fonte_do_plugin( $raiz ) ) as $rel_do_plugin ) {
		if ( isset( f3b_insumos_partilhados()[ $rel_do_plugin ] ) ) {
			$partilhados[] = $rel_do_plugin;
			continue;
		}

		$proprios[] = $rel_do_plugin;
	}

	$evidencias = array();

	foreach ( f3b_checagens_por_evidencia( $suite ) as $classe => $quantas ) {
		$evidencias[] = '`' . $classe . '` ' . $quantas;
	}

	$detectores = count( f3b_com_piso( $suite ) );
	$bancada    = 0;

	foreach ( f3b_tsv( $suite . '/bancada-wp/pisos.tsv' ) as $linha ) {
		if ( '' !== trim( (string) ( $linha[0] ?? '' ) ) && 'coberto' === trim( (string) ( $linha[2] ?? '' ) ) ) {
			++$bancada;
		}
	}

	return array(
		'Nome do artefato'                          => '`' . f3b_cabecalho_do_plugin( $raiz, 'Plugin Name' ) . '`',
		'Versão, lida do cabeçalho'                 => '`' . f3b_cabecalho_do_plugin( $raiz, 'Version' ) . '`',
		'Pasta instalada'                           => '`base-site-core-fator3`',
		'WordPress mínimo · PHP mínimo'             => '`' . f3b_cabecalho_do_plugin( $raiz, 'Requires at least' ) . '` · `' . f3b_cabecalho_do_plugin( $raiz, 'Requires PHP' ) . '`',
		'Plataforma declarada no cabeçalho'         => '`' . f3b_declaracao_do_cabecalho( $raiz, 'EXIGE PHP DE' ) . '`',
		'Escopo de instalação declarado no cabeçalho' => '`' . f3b_declaracao_do_cabecalho( $raiz, 'MULTISITE' ) . '`',
		'Arquivos na fonte do plugin'               => (string) count( $proprios ),
		'Arquivos vindos de `partilhado/`'          => (string) count( $partilhados ),
		'Arquivos no repositório (fora de `dist/` e dos produtos da rodada)' => (string) count( array_diff( f3b_fontes( $raiz ), array_keys( f3b_produzidos_pela_rodada() ) ) ),
		'Checagens declaradas por classe de evidência' => array() === $evidencias ? 'nenhuma' : implode( ' · ', $evidencias ),
		'Detectores com piso em disco'              => (string) $detectores,
		'Ramos de piso em disco (negativa + positiva)' => (string) ( $detectores * 2 ),
		'Passos da bancada WordPress com mutante declarado' => (string) $bancada,
		'Checagens com piso declarado em sonda'     => (string) count( f3b_pisos_em_sonda( $suite ) ),
		'Artefato publicado'                        => '`base-site-core-fator3-' . f3b_cabecalho_do_plugin( $raiz, 'Version' ) . '.zip`',
		'Época declarada de cada entrada do zip'    => '`' . f3b_epoca_do_zip() . '`',
	);
}

/**
 * A primeira frase de um papel do inventário.
 *
 * O papel completo é longo de propósito — ele diz o que o arquivo é e por que
 * ele é assim —, e a árvore do README existe para dar a FORMA do repositório.
 * O corte é declarado no próprio bloco gerado e aponta para o `MANIFESTO.md`,
 * onde o papel sai inteiro: abreviar sem dizer que abreviou é a forma pela qual
 * um resumo passa a ser lido como a coisa toda.
 *
 * @param string $papel Papel declarado.
 * @return string
 */
function f3b_primeira_frase( string $papel ): string {
	/*
	 * O CORTE É NO PONTO FINAL, e não nos dois-pontos. Cortar no primeiro
	 * separador que aparecesse deixaria metade dos papéis reduzida à palavra
	 * "Módulo" — todos eles começam declarando o que a coisa é e só depois
	 * dizendo o que ela faz —, e uma árvore em que vinte linhas dizem "Módulo"
	 * não informa nada.
	 */
	if ( 1 === preg_match( '/^(.+?\.)(?:\s|$)/u', $papel, $achou ) ) {
		return rtrim( trim( (string) $achou[1] ), '.' );
	}

	return $papel;
}

/**
 * A ÁRVORE do repositório, desenhada a partir do inventário declarado.
 *
 * A árvore sai do INVENTÁRIO, e não de uma varredura de disco, e a diferença é
 * a que importa: o inventário é a allow-list executável do empacotamento, e
 * arquivo em disco fora dela ABORTA o build com o nome. Desenhar de disco daria
 * uma árvore que pode conter o que não está declarado; desenhar do inventário
 * dá a árvore que o pacote autoriza — e a que ela não bate com o disco é
 * `pacote.allow_list` que responde, nos dois sentidos.
 *
 * O prefixo declarado sai como UM nó, com o papel dele: é assim que ele está
 * declarado, e expandir `suite/` arquivo a arquivo afogaria a forma do
 * repositório em fixtures.
 *
 * @param string $suite Diretório da suíte.
 * @return string
 */
function f3b_arvore_do_repositorio( string $suite ): string {
	$inventario = f3b_inventario( $suite );
	$entradas   = array();

	foreach ( $inventario['exatos'] as $caminho => $papel ) {
		$entradas[ $caminho ] = $papel;
	}

	foreach ( $inventario['prefixos'] as $caminho => $papel ) {
		$entradas[ $caminho ] = $papel;
	}

	ksort( $entradas );

	$linhas  = array( 'base-site-core-fator3/' );
	$abertos = array();

	foreach ( $entradas as $caminho => $papel ) {
		$partes = explode( '/', rtrim( (string) $caminho, '/' ) );
		$folha  = array_pop( $partes );
		$trilha = '';

		foreach ( $partes as $nivel => $dir ) {
			$trilha .= $dir . '/';

			if ( isset( $abertos[ $trilha ] ) ) {
				continue;
			}

			$abertos[ $trilha ] = true;
			$linhas[]           = str_repeat( '  ', $nivel + 1 ) . $dir . '/';
		}

		/*
		 * PREFIXO DECLARADO É DIRETÓRIO, e por isso ele entra em `$abertos`: sem
		 * isto, `suite/` sairia duas vezes — uma como a linha declarada, com o
		 * papel, e outra como o diretório que `suite/bancada-wp/` precisa abrir.
		 */
		if ( str_ends_with( (string) $caminho, '/' ) ) {
			$abertos[ (string) $caminho ] = true;
		}

		$sufixo   = str_ends_with( (string) $caminho, '/' ) ? '/' : '';
		$linhas[] = str_repeat( '  ', count( $partes ) + 1 ) . $folha . $sufixo . '   — ' . f3b_primeira_frase( (string) $papel );
	}

	return "```\n" . implode( "\n", $linhas ) . "\n```";
}

/**
 * O conteúdo de uma região gerada dos três documentos do repositório.
 *
 * @param string $raiz   Raiz do pacote.
 * @param string $suite  Diretório da suíte.
 * @param string $doc    Documento.
 * @param string $regiao Região.
 * @return string
 */
function f3b_conteudo_da_regiao_do_repositorio( string $raiz, string $suite, string $doc, string $regiao ): string {
	if ( 'carimbo' === $regiao ) {
		$fatos  = f3b_fatos_do_carimbo( $raiz, $suite );
		$versao = trim( (string) ( $fatos['Versão, lida do cabeçalho'] ?? '' ), '`' );

		$linhas = array(
			f3b_titulo_do_documento( $doc, $versao ),
			'',
			'> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip ser',
			'> montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número destes documentos',
			'> é digitado à mão: número digitado está certo no dia em que foi escrito e é contradito pela rodada',
			'> seguinte, sem nada acusando. O que não pode ser medido no momento da escrita sai como pendência',
			'> nomeada, nunca como número velho.',
			'',
			'| Fato medido | Valor |',
			'|---|---|',
		);

		foreach ( $fatos as $rotulo => $valor ) {
			$linhas[] = '| ' . $rotulo . ' | ' . $valor . ' |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'arvore' === $regiao ) {
		return "### Árvore do repositório\n\n"
			. "Gerada de `suite/inventario.tsv`, que é a allow-list executável do empacotamento: arquivo em disco fora\n"
			. "dela **aborta o build com o nome**. Diretório declarado como prefixo sai como um nó só, porque é assim\n"
			. "que ele está declarado. O papel de cada caminho sai aqui até o primeiro ponto final; ele está inteiro\n"
			. "no inventário de `MANIFESTO.md`.\n\n"
			. f3b_arvore_do_repositorio( $suite );
	}

	if ( 'inventario' === $regiao ) {
		$linhas = array(
			'### Inventário: caminho para papel',
			'',
			'Gerado de `suite/inventario.tsv`. Manter aqui uma cópia escrita à mão criaria duas fontes, e a segunda',
			'envelheceria calada — o inventário é executável e este documento não.',
			'',
			'| Caminho | Papel |',
			'|---|---|',
		);

		$inventario = f3b_inventario( $suite );

		foreach ( $inventario['exatos'] as $caminho => $papel ) {
			$linhas[] = '| `' . $caminho . '` | ' . $papel . ' |';
		}

		foreach ( $inventario['prefixos'] as $caminho => $papel ) {
			$linhas[] = '| `' . $caminho . '` (prefixo) | ' . $papel . ' |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'requisitos' === $regiao ) {
		$linhas = array(
			'### Requisito para checagem, ambiente e evidência',
			'',
			'Gerado de `suite/manifesto.tsv`. O cruzamento com a rodada é BIDIRECIONAL e roda em',
			'`manifesto.bidirecional`: requisito cuja checagem a rodada não emitiu é FALHA, e rótulo emitido sem',
			'requisito nem armadilha que o justifique também. Requisito que aparece mais de uma vez aponta para a',
			'mesma checagem por mais de um motivo — um fato, uma linha de rodada, vários requisitos atendidos.',
			'',
			'| Requisito | Checagem | Ambiente | Evidência |',
			'|---|---|---|---|',
		);

		foreach ( f3b_tsv( $suite . '/manifesto.tsv' ) as $linha ) {
			$requisito = trim( (string) ( $linha[0] ?? '' ) );

			if ( '' === $requisito ) {
				continue;
			}

			$linhas[] = '| ' . $requisito . ' | `' . trim( (string) ( $linha[1] ?? '' ) ) . '` | '
				. trim( (string) ( $linha[2] ?? '' ) ) . ' | `' . trim( (string) ( $linha[3] ?? '' ) ) . '` |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'fixtures' === $regiao ) {
		$linhas = array(
			'### Piso: as três formas, e o que cada uma prova',
			'',
			'Gerado de disco e das tabelas declaradas. Um detector sem piso é uma afirmação sobre a intenção de quem',
			'o escreveu: enquanto ninguém o viu acusar o defeito que ele existe para acusar, ele pode estar cego.',
			'',
			'**Piso em disco — um detector, duas árvores.** A NEGATIVA reproduz o defeito e precisa ser acusada; a',
			'POSITIVA preserva o caso correto e precisa ficar em silêncio.',
			'',
			'| Detector | Arquivos de piso |',
			'|---|---|',
		);

		foreach ( f3b_com_piso( $suite ) as $detector ) {
			$linhas[] = '| `' . $detector . '` | ' . count( f3b_arquivos( $suite . '/fixtures/' . $detector ) ) . ' |';
		}

		$linhas[] = '';
		$linhas[] = '**Piso da bancada WordPress — um passo, dois plugins instalados.** O caso negativo não é uma árvore';
		$linhas[] = 'de arquivos: é o plugin com o defeito dentro, montado a partir do patch, num WordPress que sobe e';
		$linhas[] = 'responde. `situação` diz se os DOIS ramos fecham hoje.';
		$linhas[] = '';
		$linhas[] = '| Passo | Mutante | Situação |';
		$linhas[] = '|---|---|---|';

		foreach ( f3b_tsv( $suite . '/bancada-wp/pisos.tsv' ) as $linha ) {
			$passo = trim( (string) ( $linha[0] ?? '' ) );

			if ( '' === $passo ) {
				continue;
			}

			$linhas[] = '| `wp.' . $passo . '` | `' . trim( (string) ( $linha[1] ?? '' ) ) . '` | '
				. trim( (string) ( $linha[2] ?? '' ) ) . ' |';
		}

		$linhas[] = '';
		$linhas[] = '**Piso em sonda — o caso negativo mora dentro da própria sonda.** A declaração não absolve: ela só';
		$linhas[] = 'vale quando a sonda declarada existe, menciona a checagem e traz os dois ramos escritos, e quem';
		$linhas[] = 'confere isso é `estatica.piso_em_sonda_declarado`, que tem piso em disco como qualquer detector.';
		$linhas[] = '';
		$linhas[] = '| Checagem | Sonda que carrega o piso |';
		$linhas[] = '|---|---|';

		foreach ( f3b_pisos_em_sonda( $suite ) as $checagem => $sonda ) {
			$linhas[] = '| `' . $checagem . '` | `suite/' . $sonda . '` |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'excluidas' === $regiao ) {
		$por_categoria = array();

		foreach ( f3b_tsv( $suite . '/excluidas.tsv' ) as $linha ) {
			$nome = trim( (string) ( $linha[0] ?? '' ) );

			if ( '' === $nome ) {
				continue;
			}

			$categoria = trim( (string) ( $linha[1] ?? '' ) );

			$por_categoria[ $categoria ][ $nome ] = trim( (string) ( $linha[2] ?? '' ) );
		}

		ksort( $por_categoria );

		$linhas = array(
			'### O que a suíte da referência media e esta NÃO mede',
			'',
			'Gerado de `suite/excluidas.tsv`. A suíte deste repositório foi EXTRAÍDA da do implantador, e checagem',
			'que some numa extração é indistinguível de checagem esquecida — é exatamente assim que a cobertura',
			'encolhe sem que nada acuse. Cada linha é uma decisão declarada, e o motivo é sempre de OBJETO ou de',
			'ESCOPO. Uma checagem daqui só volta junto com o objeto dela.',
			'',
		);

		foreach ( $por_categoria as $categoria => $itens ) {
			ksort( $itens );

			$linhas[] = '**Categoria `' . $categoria . '`**';
			$linhas[] = '';
			$linhas[] = '| Checagem | Por que ela não está aqui |';
			$linhas[] = '|---|---|';

			foreach ( $itens as $nome => $motivo ) {
				$linhas[] = '| `' . $nome . '` | ' . $motivo . ' |';
			}

			$linhas[] = '';
		}

		return trim( implode( "\n", $linhas ) );
	}

	if ( 'contagem' === $regiao ) {
		$memoria = f3b_decisoes_da_memoria( $raiz );

		$linhas = array(
			'> Este bloco é **gerado** pela leitura deste próprio arquivo: as decisões são contadas a partir dos',
			'> títulos que existem nele, e não de um número escrito ao lado. Uma memória que declara quantas',
			'> decisões tem e conta outra coisa é a primeira frase que alguém confere e a última em que confia.',
			'',
			'| Fato medido | Valor |',
			'|---|---|',
			'| Decisões nesta memória | ' . count( $memoria['todas'] ) . ' |',
			'| Herdadas do implantador, transcritas verbatim | ' . count( $memoria['herdadas'] ) . ' |',
			'| Nascidas nesta release | ' . count( $memoria['novas'] ) . ' |',
			'| Herdadas com nota de superação | ' . count( $memoria['superadas'] ) . ' |',
		);

		return implode( "\n", $linhas );
	}

	return '';
}

/**
 * O conteúdo de uma região gerada.
 *
 * @param string $raiz   Raiz do pacote.
 * @param string $suite  Diretório da suíte.
 * @param string $doc    Documento.
 * @param string $regiao Região.
 * @return string
 */
function f3b_conteudo_da_regiao( string $raiz, string $suite, string $doc, string $regiao ): string {
	if ( str_starts_with( $regiao, 'plugin-' ) ) {
		return f3b_conteudo_da_regiao_do_plugin( $raiz, $regiao );
	}

	return f3b_conteudo_da_regiao_do_repositorio( $raiz, $suite, $doc, $regiao );
}


/* =========================================================================
 * A MEMÓRIA DE DECISÕES, LIDA DE SI MESMA
 *
 * `MEMORIA-DECISOES.md` tem duas partes, e elas têm naturezas diferentes. A
 * primeira é TRANSCRIÇÃO: decisões herdadas do implantador, copiadas palavra
 * por palavra, com a origem declarada no título. Reescrevê-las inventaria um
 * passado que não aconteceu — a decisão foi tomada com aquelas palavras, sobre
 * aquele pacote, e o valor dela para quem lê hoje é justamente ela não ter sido
 * ajustada depois. A segunda parte é desta release, e é prosa nossa.
 *
 * O BLOCO TRANSCRITO É DELIMITADO, e a delimitação é o que torna a distinção
 * mensurável em vez de uma promessa: `doc.numero_digitado` varre a prosa nossa
 * inteira e, dentro do bloco transcrito, varre SÓ as duas linhas que são nossas
 * — o título da decisão e a nota de superação —, cobrando a forma declarada das
 * duas. Sem o delimitador, ou o detector acusaria a transcrição por números que
 * são história, ou alguém esconderia prosa nova dentro dela.
 * ====================================================================== */

/**
 * Abertura e fecho do bloco transcrito.
 *
 * Montados por concatenação pela mesma razão de `f3b_marca_inicio()`: escritos
 * inteiros, este arquivo conteria o marcador que ele procura.
 *
 * @param string $ponta `inicio` ou `fim`.
 * @return string
 */
function f3b_marca_transcrito( string $ponta ): string {
	return '<!-- ' . 'transcrito:' . $ponta . ' -->';
}

/**
 * As DECISÕES declaradas em `MEMORIA-DECISOES.md`, lidas do próprio arquivo.
 *
 * Fonte única da contagem — a região `contagem` a publica — e do escopo que
 * `doc.numero_digitado` cobra. Ler o arquivo é o que impede a memória de
 * declarar um número que os títulos dela contradizem.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{todas:array<int,array{numero:string,ordinal:int,linha:int,titulo:string,origem:string,transcrita:bool,superada:string}>,herdadas:array<int,int>,novas:array<int,int>,superadas:array<int,int>,fora_de_forma:array<int,string>}
 */
function f3b_decisoes_da_memoria( string $raiz ): array {
	$caminho = $raiz . '/MEMORIA-DECISOES.md';
	$saida   = array(
		'todas'         => array(),
		'herdadas'      => array(),
		'novas'         => array(),
		'superadas'     => array(),
		'fora_de_forma' => array(),
	);

	if ( ! is_file( $caminho ) ) {
		return $saida;
	}

	$linhas     = preg_split( '/\R/', (string) file_get_contents( $caminho ) ) ?: array();
	$transcrito = false;
	$ordinal    = 0;
	$ultima     = -1;

	foreach ( $linhas as $n => $linha ) {
		$linha = (string) $linha;

		if ( str_starts_with( $linha, f3b_marca_transcrito( 'inicio' ) ) ) {
			$transcrito = true;
			continue;
		}

		if ( str_starts_with( $linha, f3b_marca_transcrito( 'fim' ) ) ) {
			$transcrito = false;
			continue;
		}

		if ( str_starts_with( $linha, '> **Superada' ) && $ultima >= 0 ) {
			$saida['todas'][ $ultima ]['superada'] = $linha;
			$saida['superadas'][]                  = $ultima;
			continue;
		}

		/*
		 * SÓ O TÍTULO QUE COMEÇA POR DÍGITO É DECISÃO, e o recorte é o que deixa
		 * o arquivo ter seções: "## Parte I" é prosa nossa, varrida pela regra do
		 * número como qualquer outra linha, e não um título fora de forma.
		 */
		if ( 1 !== preg_match( '/^## [0-9]/', $linha ) ) {
			continue;
		}

		if ( 1 !== preg_match( '/^## ([0-9]+)\. (.+?)(\s*\(origem: [^)]+\))?$/u', $linha, $achou ) ) {
			$saida['fora_de_forma'][] = 'linha ' . ( $n + 1 ) . ': "' . $linha . '"';
			continue;
		}

		++$ordinal;
		$ultima = count( $saida['todas'] );

		$saida['todas'][] = array(
			'numero'     => (string) $achou[1],
			'ordinal'    => $ordinal,
			'linha'      => $n + 1,
			'titulo'     => (string) $achou[2],
			'origem'     => trim( (string) ( $achou[3] ?? '' ) ),
			'transcrita' => $transcrito,
			'superada'   => '',
		);

		if ( $transcrito ) {
			$saida['herdadas'][] = $ultima;
			continue;
		}

		$saida['novas'][] = $ultima;
	}

	return $saida;
}

/**
 * A FONTE MEDIDA do repositório: o que o pacote decide e declara.
 *
 * É o corpo contra o qual a isenção de vão de código é conferida, e o recorte é
 * a metade que faz a isenção valer alguma coisa. Entram a fonte do plugin e o
 * instrumento — código e tabelas declaradas —, porque ali um número é uma
 * DECISÃO do pacote que alguém pode ir conferir. Ficam de fora:
 *
 * - os quatro documentos entregáveis, e a exclusão é o ponto: com eles dentro,
 *   todo número que um deles traz passaria a "existir na fonte" e a regra se
 *   autoaprovaria — é a mesma exclusão que a sonda do zip já faz;
 * - `suite/correcoes/`, que é REGISTRO de rodada — os TSVs das frentes e os
 *   logs salvos. Eles são prosa e saída de execução, do mesmo tipo do
 *   documento que está sendo varrido: aceitar um número por ele aparecer num
 *   log de rodada anterior seria isentar tudo, porque um log traz todo número
 *   que a rodada imprimiu;
 * - `suite/fixtures/`, que por construção contém defeito plantado.
 *
 * @param string $raiz Raiz do pacote.
 * @return string
 */
function f3b_fonte_medida_do_repositorio( string $raiz ): string {
	$fonte     = '';
	$documento = f3b_regioes_dos_documentos();

	foreach ( f3b_arquivos( $raiz, array(), array( 'dist/', '.git', 'suite/fixtures/', 'suite/correcoes/' ) ) as $rel ) {
		if ( isset( $documento[ $rel ] ) ) {
			continue;
		}

		$fonte .= (string) file_get_contents( $raiz . '/' . $rel ) . "\n";
	}

	return $fonte;
}

/**
 * A PROSA de um documento, linha a linha, com as regiões geradas em branco.
 *
 * As linhas são preservadas em NÚMERO, e não removidas: o achado precisa dizer
 * em que linha do arquivo o número está, e um texto colapsado devolveria a
 * posição de um arquivo que ninguém abre.
 *
 * Bloco de código cercado sai inteiro, com o limite declarado: ali o número é
 * argumento de comando ou de consulta — um intervalo de dias, uma porta, um
 * limite de linhas —, e não afirmação sobre este pacote.
 *
 * @param string $texto Documento inteiro.
 * @return array<int,string>
 */
function f3b_prosa_por_linha( string $texto ): array {
	$saida   = array();
	$dentro  = false;
	$cercado = false;

	foreach ( preg_split( '/\R/', $texto ) ?: array() as $linha ) {
		$linha = (string) $linha;

		if ( str_starts_with( $linha, '<!-- gerado:' . 'inicio=' ) ) {
			$dentro  = true;
			$saida[] = '';
			continue;
		}

		if ( str_starts_with( $linha, '<!-- gerado:' . 'fim=' ) ) {
			$dentro  = false;
			$saida[] = '';
			continue;
		}

		if ( ! $dentro && str_starts_with( ltrim( $linha ), '``' . '`' ) ) {
			$cercado = ! $cercado;
			$saida[] = '';
			continue;
		}

		$saida[] = $dentro || $cercado ? '' : $linha;
	}

	return $saida;
}

/**
 * NENHUM NÚMERO DIGITADO À MÃO nos quatro documentos entregáveis.
 *
 * A REGRA É A MESMA que `pacote.instrucoes_do_plugin_no_zip` já aplicava ao
 * documento que viaja dentro do zip, e o motivo de ela subir para os quatro é
 * de escopo, não de rigor: o README diz ao operador o que instalar, o MANIFESTO
 * declara o que é contrato e a MEMORIA narra por que cada coisa é assim. Os
 * três descrevem ESTE pacote, e um número digitado neles envelhece do mesmo
 * jeito — com o agravante de que a suíte não tinha nenhuma linha que o
 * enxergasse.
 *
 * ISENÇÕES, e cada uma é paga:
 *
 * 1. **Marcador de lista ordenada.** É estrutura do markdown, não afirmação.
 * 2. **Dígito colado a letra**, direta ou por hífen ou sublinhado: isso é NOME.
 * 3. **Vão de código cujo conteúdo aparece VERBATIM na fonte medida do
 *    repositório.** É a isenção que carrega o peso: um teto do código passa
 *    porque ele está no código, e uma contagem inventada não passa porque ela
 *    não é literal de lugar nenhum. O recorte da fonte medida está em
 *    `f3b_fonte_medida_do_repositorio()`.
 * 4. **O índice de uma decisão da memória** — e ele só é isento quando É o
 *    índice: `## N.` passa quando N é a posição daquela decisão entre as
 *    decisões do arquivo. Índice fora de posição não vira exceção; sai acusado,
 *    porque uma memória cujo décimo título diz "12" manda quem procura a
 *    décima segunda para o lugar errado.
 * 5. **A referência `nº N` a uma decisão que existe neste documento.** Ela
 *    resolve ou é achado — referência pendurada é a forma pela qual a memória
 *    passa a apontar para uma decisão que alguém apagou.
 * 6. **O número de origem no título de uma decisão transcrita** — `(origem:
 *    implantador 1.7.4, decisão nº X)`. Ele é ENDEREÇO para outro pacote e não
 *    pode ser medido daqui; o que pode ser medido é a FORMA, e ela é fechada.
 *
 * E o BLOCO TRANSCRITO não é varrido, com uma exceção que o mantém honesto:
 * dentro dele, toda seção precisa declarar a origem. Sem essa cláusula, o
 * delimitador viraria o lugar onde se escreve prosa nova sem detector nenhum.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_numero_digitado_nos_documentos( string $raiz ): array {
	$fonte    = f3b_fonte_medida_do_repositorio( $raiz );
	$memoria  = f3b_decisoes_da_memoria( $raiz );
	$versao   = f3b_cabecalho_do_plugin( $raiz, 'Version' );
	$achados  = array();
	$medidas  = 0;
	$numeros  = array();

	foreach ( $memoria['todas'] as $decisao ) {
		$numeros[ $decisao['numero'] ] = true;
	}

	foreach ( $memoria['fora_de_forma'] as $fora ) {
		$achados[] = 'MEMORIA-DECISOES.md: título de decisão fora da forma declarada — ' . $fora
			. '. A forma é "## <índice>. <título>", com "(origem: implantador <versão>, decisão nº <número>)" no fim quando ela é transcrita';
	}

	foreach ( $memoria['todas'] as $decisao ) {
		++$medidas;

		if ( (string) $decisao['ordinal'] !== $decisao['numero'] ) {
			$achados[] = 'MEMORIA-DECISOES.md linha ' . $decisao['linha'] . ': a decisão está na posição '
				. $decisao['ordinal'] . ' e o título dela diz "' . $decisao['numero']
				. '". Índice que não é a posição manda quem procura uma decisão para o lugar errado, e é ele que a região `contagem` conta';
		}

		if ( $decisao['transcrita'] && '' === $decisao['origem'] ) {
			$achados[] = 'MEMORIA-DECISOES.md linha ' . $decisao['linha'] . ': a decisão "' . $decisao['titulo']
				. '" está DENTRO do bloco transcrito e não declara a origem. O bloco transcrito não é varrido por número, '
				. 'e prosa nova escrita ali ficaria sem detector nenhum';
		}

		if ( ! $decisao['transcrita'] && '' !== $decisao['origem'] ) {
			$achados[] = 'MEMORIA-DECISOES.md linha ' . $decisao['linha'] . ': a decisão "' . $decisao['titulo']
				. '" declara origem e está FORA do bloco transcrito. Decisão desta release não tem origem em outro pacote';
		}

		if ( '' === $decisao['superada'] ) {
			continue;
		}

		++$medidas;

		if ( 1 !== preg_match( '/^> \*\*Superada na ([0-9.]+)\*\* — ver decisão nº ([0-9]+)\.$/u', $decisao['superada'], $nota ) ) {
			$achados[] = 'MEMORIA-DECISOES.md: a nota de superação da decisão "' . $decisao['titulo']
				. '" está fora da forma declarada — "> **Superada na <versão>** — ver decisão nº <índice>."';
			continue;
		}

		if ( version_compare( (string) $nota[1], $versao, '>' ) ) {
			$achados[] = 'MEMORIA-DECISOES.md: a nota de superação da decisão "' . $decisao['titulo'] . '" diz "'
				. (string) $nota[1] . '" e o cabeçalho do plugin declara "' . $versao
				. '". Uma nota histórica não pode declarar versão futura; notas de releases anteriores são preservadas';
		}

		if ( ! isset( $numeros[ (string) $nota[2] ] ) ) {
			$achados[] = 'MEMORIA-DECISOES.md: a nota de superação da decisão "' . $decisao['titulo']
				. '" aponta para a decisão nº ' . (string) $nota[2] . ', que não existe neste documento';
		}
	}

	foreach ( array_keys( f3b_regioes_dos_documentos() ) as $doc ) {
		$caminho = $raiz . '/' . $doc;

		if ( ! is_file( $caminho ) ) {
			$achados[] = 'documento entregável ausente: ' . $doc;
			continue;
		}

		++$medidas;

		$transcrito = false;

		foreach ( f3b_prosa_por_linha( (string) file_get_contents( $caminho ) ) as $n => $linha ) {
			$bruta = $linha;

			if ( str_starts_with( $linha, f3b_marca_transcrito( 'inicio' ) ) ) {
				$transcrito = true;
				continue;
			}

			if ( str_starts_with( $linha, f3b_marca_transcrito( 'fim' ) ) ) {
				$transcrito = false;
				continue;
			}

			/* O título da decisão e a nota de superação já foram medidos acima, na forma. */
			if ( 1 === preg_match( '/^#{2,6} [0-9]+\. /', $linha ) ) {
				$linha = (string) preg_replace( '/^#{2,6} [0-9]+\. /', '', $linha );
				$linha = (string) preg_replace( '/\s*\(origem: [^)]+\)$/u', '', $linha );
			} elseif ( str_starts_with( $linha, '> **Superada' ) ) {
				$linha = '';
			} elseif ( $transcrito ) {
				continue;
			}

			$linha = (string) preg_replace( '/^(\s*)[0-9]+\.(\s)/', '$1$2', $linha );

			$linha = (string) preg_replace_callback(
				'/`([^`]*)`/',
				static fn( array $achou ): string => str_contains( $fonte, (string) $achou[1] ) ? '' : (string) $achou[0],
				$linha
			);

			$linha = (string) preg_replace_callback(
				'/nº ([0-9]+)/u',
				static fn( array $achou ): string => isset( $numeros[ (string) $achou[1] ] ) ? '' : (string) $achou[0],
				$linha
			);

			if ( ! preg_match_all( '/[0-9]+(?:[.,][0-9]+)*/', $linha, $encontrados, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $encontrados[0] as $numero ) {
				$valor  = (string) $numero[0];
				$onde   = (int) $numero[1];
				$antes  = substr( $linha, max( 0, $onde - 2 ), min( 2, $onde ) );
				$depois = substr( $linha, $onde + strlen( $valor ), 2 );

				if ( 1 === preg_match( '/[A-Za-z][-_]?$/', $antes ) || 1 === preg_match( '/^[-_]?[A-Za-z]/', $depois ) ) {
					continue;
				}

				$achados[] = $doc . ' linha ' . ( $n + 1 ) . ': o número "' . $valor . '" está digitado fora de região gerada — "'
					. trim( $bruta ) . '". Número em documento entregável é GERADO por leitura de disco: digitado, ele está certo '
					. 'no dia em que foi escrito e é contradito pela rodada seguinte, sem nada acusando. Se ele é um limite do '
					. 'código, escreva-o em vão de código com a mesma grafia que a fonte usa; se é uma contagem, ela pertence a '
					. 'uma região gerada';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Substitui uma região marcada, ou devolve null quando os marcadores faltam.
 *
 * @param string $texto    Texto do documento.
 * @param string $regiao   Nome da região.
 * @param string $conteudo Conteúdo novo.
 * @return string|null
 */
function f3b_trocar_regiao( string $texto, string $regiao, string $conteudo ): ?string {
	$abre  = f3b_marca_inicio( $regiao );
	$fecha = f3b_marca_fim( $regiao );

	$ini = strpos( $texto, $abre );
	$fim = strpos( $texto, $fecha );

	if ( false === $ini || false === $fim || $fim < $ini ) {
		return null;
	}

	return substr( $texto, 0, $ini ) . $abre . "\n" . $conteudo . "\n" . substr( $texto, $fim );
}

/**
 * O que está DENTRO de uma região marcada, ou null quando ela não existe.
 *
 * @param string $texto  Texto do documento.
 * @param string $regiao Nome da região.
 * @return string|null
 */
function f3b_regiao_atual( string $texto, string $regiao ): ?string {
	$abre  = f3b_marca_inicio( $regiao );
	$fecha = f3b_marca_fim( $regiao );

	$ini = strpos( $texto, $abre );
	$fim = strpos( $texto, $fecha );

	if ( false === $ini || false === $fim || $fim < $ini ) {
		return null;
	}

	return trim( substr( $texto, $ini + strlen( $abre ), $fim - $ini - strlen( $abre ) ), "\n" );
}

/**
 * Regenera as regiões dos documentos entregáveis. Roda no EMPACOTAMENTO.
 *
 * Só escreve quando o conteúdo muda: reescrever igual mexeria na data de
 * modificação a cada rodada e faria `pacote.build_fresco` reprovar um artefato
 * que está correto.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array{achados:array<int,string>,escritos:array<int,string>}
 */
function f3b_gerar_documentos( string $raiz, string $suite ): array {
	$achados  = array();
	$escritos = array();

	foreach ( f3b_regioes_dos_documentos() as $doc => $regioes ) {
		$caminho = $raiz . '/' . $doc;

		if ( ! is_file( $caminho ) ) {
			$achados[] = 'documento entregável ausente: ' . $doc;
			continue;
		}

		$texto   = (string) file_get_contents( $caminho );
		$antes   = $texto;

		foreach ( $regioes as $regiao ) {
			$novo = f3b_trocar_regiao( $texto, $regiao, f3b_conteudo_da_regiao( $raiz, $suite, $doc, $regiao ) );

			if ( null === $novo ) {
				$achados[] = $doc . ': região gerada "' . $regiao . '" sem marcadores no arquivo — não há onde escrever, '
					. 'e um documento entregável sem região gerada é um documento que envelhece calado';
				continue;
			}

			$texto = $novo;
		}

		if ( $texto !== $antes ) {
			file_put_contents( $caminho, $texto );
			$escritos[] = $doc;
		}
	}

	return array(
		'achados'  => $achados,
		'escritos' => $escritos,
	);
}

/**
 * O carimbo dos documentos entregáveis bate com a medição de agora.
 *
 * Duas cláusulas, e as duas reprovam:
 *
 * 1. **O documento existe** e traz cada região declarada, com os dois
 *    marcadores. Marcador ausente é a porta pela qual o documento sai do
 *    alcance do gerador e volta a envelhecer calado.
 * 2. **O conteúdo de cada região é IGUAL ao que a medição de agora produz.** É
 *    a cláusula que pega número velho — o defeito de sete releases seguidas.
 *
 * A TERCEIRA CLÁUSULA DO IMPLANTADOR NÃO VOLTOU, e a ausência é de escopo, não
 * de rigor: lá ela cobrava que a região `carimbo` trouxesse `release.identidade`
 * de `config/site.json`, e aqui não há `config/site.json` nem release do
 * implantador. A identidade deste artefato sai do cabeçalho do arquivo
 * principal do plugin, entra nas regiões `carimbo` e `plugin-identidade` pela
 * mesma leitura de disco, e é conferida pela cláusula 2 junto com todo o resto:
 * uma versão trocada no cabeçalho e não regenerada aqui reprova nas quatro.
 *
 * O ESCOPO SÃO OS QUATRO DOCUMENTOS ENTREGÁVEIS. Três ficam no repositório —
 * README, MANIFESTO e MEMORIA-DECISOES — e o quarto viaja dentro do zip. O que
 * os iguala é o que esta função mede: eles descrevem ESTE pacote, e quem os lê
 * não tem como conferir o número que eles trazem.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_carimbo_de_release_nos_documentos( string $raiz ): array {
	$suite   = $raiz . '/suite';
	$achados = array();
	$medidas = 0;

	foreach ( f3b_regioes_dos_documentos() as $doc => $regioes ) {
		$caminho = $raiz . '/' . $doc;

		if ( ! is_file( $caminho ) ) {
			$achados[] = 'documento entregável ausente: ' . $doc . ' — quem recebe este plugin recebe o zip, '
				. 'e outro agente opera e MUDA o plugin lendo por ele';
			continue;
		}

		$texto = (string) file_get_contents( $caminho );

		foreach ( $regioes as $regiao ) {
			$medidas++;
			$atual = f3b_regiao_atual( $texto, $regiao );

			if ( null === $atual ) {
				$achados[] = $doc . ': região gerada "' . $regiao . '" sem marcadores — documento entregável fora do '
					. 'alcance do gerador volta a carregar número digitado à mão, que envelhece em silêncio';
				continue;
			}

			$esperado = f3b_conteudo_da_regiao( $raiz, $suite, $doc, $regiao );

			if ( trim( $atual ) !== trim( $esperado ) ) {
				$achados[] = $doc . ': a região "' . $regiao . '" está DIVERGENTE da medição de agora — o documento '
					. 'afirma um número que a leitura de disco contradiz. Número em documento entregável é gerado no '
					. 'empacotamento, nunca digitado';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}
