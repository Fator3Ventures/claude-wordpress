<?php
/**
 * Sonda da MIGRAÇÃO DE PASTA em subprocesso.
 *
 * O DEFEITO QUE ELA MEDE, e ele existe num site real: há pelo menos uma
 * instalação em produção com este plugin na pasta antiga (`f3base-site-core`,
 * 1.3.6). Instalar a pasta nova ali deixa DUAS CÓPIAS DO MESMO PLUGIN ATIVAS —
 * dois registros de hooks, duas rotas REST para o mesmo endereço, dois
 * coletores na página, conversão contada em dobro. O WordPress não impede e não
 * avisa: não aparece como erro, aparece como número errado semanas depois.
 *
 * A REGRA MEDIDA É A REAL: a sonda monta um WordPress de mentira com um
 * `wp-content/plugins/` de verdade em disco e roda
 * `F3Base_Site_Core::desativar_copias_do_mesmo_plugin()` contra ele.
 *
 * TETO E PISO NA MESMA BANCADA, e o piso é o falso positivo — que aqui é o
 * dano maior, porque desativar plugin alheio é atrevimento:
 *
 * - TETO: a cópia velha ATIVA, reconhecida pela reivindicação do mesmo
 *   namespace REST, é desativada, e o que foi feito fica registrado com o nome.
 * - PISO 1: um plugin de terceiro ATIVO, sem a marca, NÃO é tocado.
 * - PISO 2: uma cópia velha INATIVA não é tocada — ela não colide com nada, e
 *   desativar o que já está desativado é escrita sem efeito com registro falso.
 * - PISO 3: um plugin cujo NOME parece o da cópia velha mas que não traz a
 *   marca NÃO é tocado. É o que prova que o discriminante é a reivindicação do
 *   namespace e não uma lista de nomes — lista de nome só reconhece o que
 *   alguém lembrou de escrever nela, e os sites renomeados até a 1.6.6
 *   receberam forks deste plugin com nomes de pasta que ninguém enumerou.
 * - PISO 4: num site com só a cópia nova, nada é desativado e nada é
 *   registrado — aviso sobre um fato que não houve é pior que aviso nenhum.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );

$veredito = array(
	'migracao.copia_anterior_desativada' => array( 'achados' => array(), 'medidas' => 0 ),
);

$base = sys_get_temp_dir() . '/f3b-migracao-' . getmypid();

/**
 * Apaga uma árvore inteira.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_mg_apagar( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	foreach ( (array) scandir( $dir ) as $nome ) {
		$nome = (string) $nome;

		if ( '.' === $nome || '..' === $nome ) {
			continue;
		}

		$alvo = $dir . '/' . $nome;

		if ( is_dir( $alvo ) && ! is_link( $alvo ) ) {
			f3b_mg_apagar( $alvo );
			continue;
		}

		unlink( $alvo );
	}

	rmdir( $dir );
}

f3b_mg_apagar( $base );

define( 'ABSPATH', $base . '/wp/' );
define( 'WP_PLUGIN_DIR', $base . '/wp-content/plugins' );
define( 'WEEK_IN_SECONDS', 604800 );

mkdir( WP_PLUGIN_DIR . '/base-site-core-fator3', 0755, true );
mkdir( WP_PLUGIN_DIR . '/f3base-site-core', 0755, true );
mkdir( WP_PLUGIN_DIR . '/plugin-de-terceiro', 0755, true );
mkdir( WP_PLUGIN_DIR . '/f3base-site-core-antigo-sem-marca', 0755, true );
mkdir( ABSPATH . 'wp-admin/includes', 0755, true );
file_put_contents( ABSPATH . 'wp-admin/includes/plugin.php', "<?php\n" );

copy(
	$raiz . '/fontes/plugin/base-site-core-fator3.php',
	WP_PLUGIN_DIR . '/base-site-core-fator3/base-site-core-fator3.php'
);

/* A cópia velha: outro nome de pasta, MESMA reivindicação de namespace. */
file_put_contents(
	WP_PLUGIN_DIR . '/f3base-site-core/f3base-site-core.php',
	"<?php\n/**\n * Plugin Name: F3 Base Site Core\n * Version: 1.3.6\n */\nif ( ! defined( 'F3BASE_REST_NAMESPACE' ) ) {\n\tdefine( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );\n}\n"
);

/* Terceiro ativo, sem marca nenhuma. */
file_put_contents(
	WP_PLUGIN_DIR . '/plugin-de-terceiro/plugin-de-terceiro.php',
	"<?php\n/**\n * Plugin Name: Plugin de Terceiro\n * Version: 2.0.0\n */\n"
);

/* Nome parecido com o da cópia velha, e sem a marca: não é cópia deste plugin. */
file_put_contents(
	WP_PLUGIN_DIR . '/f3base-site-core-antigo-sem-marca/f3base-site-core-antigo-sem-marca.php',
	"<?php\n/**\n * Plugin Name: F3 Base Site Core (homônimo)\n * Version: 0.1.0\n */\n"
);

define( 'F3BASE_PLUGIN_ARQUIVO', WP_PLUGIN_DIR . '/base-site-core-fator3/base-site-core-fator3.php' );

/** @var array<int,string> */
$GLOBALS['f3b_mg_ativos']       = array();
/** @var array<string,mixed> */
$GLOBALS['f3b_mg_transientes']  = array();
/** @var array<int,array{arquivos:array<int,string>,silencioso:bool}> */
$GLOBALS['f3b_mg_desativacoes'] = array();

/**
 * Plugins do site de mentira.
 *
 * @return array<string,array<string,string>>
 */
function get_plugins(): array {
	return array(
		'base-site-core-fator3/base-site-core-fator3.php'                       => array( 'Name' => 'Base Site Core Fator3' ),
		'f3base-site-core/f3base-site-core.php'                                 => array( 'Name' => 'F3 Base Site Core' ),
		'plugin-de-terceiro/plugin-de-terceiro.php'                             => array( 'Name' => 'Plugin de Terceiro' ),
		'f3base-site-core-antigo-sem-marca/f3base-site-core-antigo-sem-marca.php' => array( 'Name' => 'F3 Base Site Core (homônimo)' ),
	);
}

/**
 * @param string $arquivo Arquivo principal.
 * @return bool
 */
function is_plugin_active( string $arquivo ): bool {
	return in_array( $arquivo, $GLOBALS['f3b_mg_ativos'], true );
}

/**
 * @param array<int,string>|string $arquivos    Arquivos.
 * @param bool                     $silencioso  Pular o hook de desativação?
 * @return void
 */
function deactivate_plugins( $arquivos, bool $silencioso = false ): void {
	$arquivos = (array) $arquivos;

	$GLOBALS['f3b_mg_desativacoes'][] = array(
		'arquivos'   => array_map( 'strval', $arquivos ),
		'silencioso' => $silencioso,
	);

	$GLOBALS['f3b_mg_ativos'] = array_values( array_diff( $GLOBALS['f3b_mg_ativos'], $arquivos ) );
}

/**
 * @param string $arquivo Caminho absoluto.
 * @return string
 */
function plugin_basename( string $arquivo ): string {
	return ltrim( str_replace( WP_PLUGIN_DIR, '', $arquivo ), '/' );
}

/**
 * @param string $chave  Chave.
 * @param mixed  $valor  Valor.
 * @param int    $prazo  Prazo.
 * @return bool
 */
function set_transient( string $chave, $valor, int $prazo = 0 ): bool {
	unset( $prazo );
	$GLOBALS['f3b_mg_transientes'][ $chave ] = $valor;

	return true;
}

/**
 * @param string $chave Chave.
 * @return mixed
 */
function get_transient( string $chave ) {
	return $GLOBALS['f3b_mg_transientes'][ $chave ] ?? false;
}

/**
 * @param string $chave Chave.
 * @return bool
 */
function delete_transient( string $chave ): bool {
	unset( $GLOBALS['f3b_mg_transientes'][ $chave ] );

	return true;
}

/**
 * @param string $capacidade Capacidade.
 * @return bool
 */
function current_user_can( string $capacidade ): bool {
	unset( $capacidade );

	return true;
}

/**
 * @param string $texto  Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = 'default' ): string {
	unset( $dominio );

	return $texto;
}

/**
 * @param string $texto Texto.
 * @return string
 */
function esc_html( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES, 'UTF-8' );
}

/**
 * @param string $hook     Hook.
 * @param mixed  $callback Callback.
 * @param int    $ordem    Prioridade.
 * @param int    $args     Argumentos.
 * @return void
 */
function add_action( string $hook, $callback, int $ordem = 10, int $args = 1 ): void {
	unset( $hook, $callback, $ordem, $args );
}

require_once $raiz . '/fontes/plugin/includes/class-f3base-plugin.php';

/**
 * Roda a regra real sobre um elenco de plugins ativos e devolve o que ela fez.
 *
 * @param array<int,string> $ativos Arquivos principais ativos.
 * @return array{desativados:array<int,string>,ainda_ativos:array<int,string>,registro:mixed,chamadas:array<int,array{arquivos:array<int,string>,silencioso:bool}>}
 */
function f3b_mg_rodar( array $ativos ): array {
	$GLOBALS['f3b_mg_ativos']       = $ativos;
	$GLOBALS['f3b_mg_transientes']  = array();
	$GLOBALS['f3b_mg_desativacoes'] = array();

	$desativados = F3Base_Site_Core::desativar_copias_do_mesmo_plugin();

	return array(
		'desativados'  => $desativados,
		'ainda_ativos' => $GLOBALS['f3b_mg_ativos'],
		'registro'     => get_transient( F3Base_Site_Core::TRANSIENTE_MIGRACAO ),
		'chamadas'     => $GLOBALS['f3b_mg_desativacoes'],
	);
}

$novo     = 'base-site-core-fator3/base-site-core-fator3.php';
$velho    = 'f3base-site-core/f3base-site-core.php';
$terceiro = 'plugin-de-terceiro/plugin-de-terceiro.php';
$homonimo = 'f3base-site-core-antigo-sem-marca/f3base-site-core-antigo-sem-marca.php';

/* ---- TETO: a cópia velha ativa sai ---- */
$r = f3b_mg_rodar( array( $novo, $velho, $terceiro, $homonimo ) );
$veredito['migracao.copia_anterior_desativada']['medidas'] += 4;

if ( ! in_array( $velho, $r['desativados'], true ) ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'teto: a cópia ANTIGA ativa (' . $velho . ') não foi desativada na ativação da nova. '
		. 'Duas cópias do mesmo plugin ativas registram os mesmos hooks e as mesmas rotas REST, e a conversão passa a ser contada em dobro sem nenhum erro aparecer';
}

if ( in_array( $velho, $r['ainda_ativos'], true ) ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'teto: a cópia antiga continuou ativa depois da migração: a linha relatou uma ação que não aconteceu';
}

if ( ! is_array( $r['registro'] ) || ! in_array( $velho, (array) $r['registro'], true ) ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'teto: a desativação não deixou REGISTRO com o nome do que saiu. Desativar plugin alheio sem dizer o que foi feito é a mudança silenciosa que este pacote recusa em todo lugar';
}

foreach ( $r['chamadas'] as $chamada ) {
	if ( true !== $chamada['silencioso'] ) {
		$veredito['migracao.copia_anterior_desativada']['achados'][] = 'a desativação rodou o hook de desativação da cópia antiga. '
			. 'Aquele hook desinstala os módulos — desagenda a cadência, remove regras de reescrita — e as chaves são as MESMAS da cópia nova: '
			. 'ele desfaria a ativação em curso, e o site ficaria com o plugin ativo e a cadência desagendada, calado';
	}
}

/* ---- PISO 1: terceiro ativo não é tocado ---- */
if ( in_array( $terceiro, $r['desativados'], true ) ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'piso — falso positivo: um plugin de terceiro ATIVO, sem a marca, foi desativado. Desativar plugin alheio é o dano maior desta migração';
}

/* ---- PISO 3: homônimo sem marca não é tocado ---- */
if ( in_array( $homonimo, $r['desativados'], true ) ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'piso — falso positivo: um plugin cujo NOME parece o da cópia velha, e que não traz a marca, foi desativado. '
		. 'O discriminante tem de ser a reivindicação do namespace REST, medida no arquivo, e não o nome da pasta';
}

/* ---- PISO 2: cópia velha INATIVA não é tocada ---- */
$r2 = f3b_mg_rodar( array( $novo, $terceiro ) );
$veredito['migracao.copia_anterior_desativada']['medidas'] += 2;

if ( array() !== $r2['desativados'] ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'piso: com a cópia antiga INATIVA, a migração ainda desativou alguma coisa (' . implode( ', ', $r2['desativados'] ) . '). '
		. 'Cópia inativa não colide com nada, e escrever sobre ela produz registro de uma ação sem efeito';
}

/* ---- PISO 4: site só com a cópia nova não registra nada ---- */
$r3 = f3b_mg_rodar( array( $novo ) );
$veredito['migracao.copia_anterior_desativada']['medidas'] += 2;

if ( array() !== $r3['desativados'] || false !== $r3['registro'] ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'piso: num site com só a cópia nova, a migração desativou algo ou deixou registro: aviso sobre um fato que não houve é pior que aviso nenhum';
}

/* ---- O AVISO diz o que foi feito, e some depois de dito ---- */
f3b_mg_rodar( array( $novo, $velho ) );
ob_start();
F3Base_Site_Core::avisar_copia_desativada();
$aviso = (string) ob_get_clean();
$veredito['migracao.copia_anterior_desativada']['medidas'] += 2;

if ( ! str_contains( $aviso, $velho ) ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'o aviso da tela não nomeia o que foi desativado: quem lê precisa saber QUAL plugin saiu para poder reativá-lo se discordar';
}

if ( false !== get_transient( F3Base_Site_Core::TRANSIENTE_MIGRACAO ) ) {
	$veredito['migracao.copia_anterior_desativada']['achados'][] = 'o registro sobreviveu à leitura: o fato é de UMA ativação, e um aviso que não some vira aviso permanente sobre um fato de um dia só';
}

f3b_mg_apagar( $base );

echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
