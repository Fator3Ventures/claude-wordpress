<?php
/**
 * FASES: aplicabilidade por fase e o registro do que cada fase espera.
 *
 * POR QUE ESTA CLASSE EXISTE, e por que ela não tem pai, não usa WordPress e
 * não escreve uma frase traduzida.
 *
 * A 1.1.5 usava **BLOCKED para duas coisas que o leitor não consegue separar**:
 *
 * 1. *"A pergunta se aplica aqui e falta alguém fazer alguma coisa."* É o caso
 *    de `formulario.destino_privado` com o número de WhatsApp vazio: há ação
 *    pendente e ela é do operador. Isso é **pré-condição ausente**, e o
 *    contrato manda fechar BLOCKED.
 * 2. *"Esta fase não produz este tipo de evidência, por desenho."* É o caso de
 *    `visual.inspecao_paginas` numa rodada de build: não falta ação nenhuma —
 *    falta um NAVEGADOR, que o build nunca vai ter, e a medição acontece noutro
 *    lugar sempre. Isso é **condição de aplicabilidade falsa**, e o contrato
 *    manda fechar N/A com a condição declarada.
 *
 * Medido na 1.1.5: 27 linhas em BLOCKED numa rodada impecável, e 26 delas eram
 * do segundo tipo. Vinte e seis linhas amarelas numa rodada sem defeito ensinam
 * o operador a ignorar amarelo — que é exatamente o defeito que a 1.0.15 fechou
 * para o WARN informativo, voltando um nível acima.
 *
 * **A REGRA, e ela é de uma linha:** checagem com FASE DECLARADA, rodando FORA
 * da fase dela, fecha N/A nomeando a fase em que ela É medida. BLOCKED fica
 * reservado para pré-condição ausente NA FASE CERTA.
 *
 * **E A REGRA SOZINHA ESCONDE DEFEITO**, por isso ela vem em par com o
 * registro. Se `visual.inspecao_paginas` for N/A para sempre porque ninguém
 * nunca roda a fase de navegador, o silêncio vira aprovação por omissão — e
 * "checagem que nunca falhou não é evidência" é regra da casa desde a 1.0.5. O
 * registro responde, para cada fase: **quantas checagens a esperam**, **quais
 * são** e **quando aquela fase rodou pela última vez**. Fase declarada que
 * NUNCA rodou é ACHADO ADVERSO, e sai em WARN — **com uma exceção medida, e não
 * declarada à mão**: a fase cujas checagens esperadas fecharam TODAS em N/A
 * nesta execução é relatada como NÃO APLICÁVEL a este emissor, sem WARN. Ali não
 * falta ação de ninguém e ninguém vai preencher aquilo aqui: é o mesmo fato que
 * a regra de aplicabilidade já declarou linha por linha, subindo um nível. Sem
 * a exceção, a fase `campo` — cujas checagens são, por desenho, evidência que
 * este host não produz — gerava WARN em toda execução, para sempre, que é o
 * defeito do aviso que sai sempre reaparecendo no próprio contrapeso.
 *
 * A classe roda em dois runtimes que não se enxergam — no IMPLANTADOR, no
 * encerramento, e na SUÍTE, que é PHP puro sem WordPress. Duas cópias da regra
 * divergiriam na primeira condição acrescentada, então o arquivo é um só: o
 * implantador o alcança pelo autoload, e a suíte por `suite/lib/sonda-fases.php`,
 * que é subprocesso pelo mesmo motivo de `sonda-hash.php` — carregar a classe
 * define `ABSPATH`, e isso não pode vazar para o processo que imprime estados.
 *
 * É por isso que **nada aqui é traduzido e nada aqui é impresso**: a classe
 * devolve DADO ESTRUTURADO, e a prosa é de cada emissor — o implantador com
 * `__()`, a suíte com o texto do relatório dela. Uma chamada a `__()` aqui
 * mataria o subprocesso da suíte, que não tem núcleo do WordPress.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Regra de fase: aplicabilidade e registro de execução.
 */
final class F3Base_Imp_Fases {

	/**
	 * FASES FECHADAS DO CONTRATO. Nenhuma outra.
	 *
	 * A mesma lista mora em `F3Base_Suite::FASES`, do lado da suíte, porque a
	 * suíte precisa dela antes de qualquer subprocesso — e as duas não podem
	 * divergir. Quem confere a igualdade é `fases.registro_de_execucao`, na
	 * primeira asserção dele: fase declarada de um lado e desconhecida do outro
	 * absolveria uma checagem por um nome que ninguém reconhece.
	 */
	public const FASES = array( 'build', 'local', 'producao', 'campo' );

	/**
	 * ESTADOS QUE SÓ A MEDIÇÃO PRODUZ — e é esta lista que decide "a fase rodou".
	 *
	 * OK, FALHA e WARN saem de uma medição que aconteceu: alguma coisa foi
	 * olhada e o resultado foi esse. BLOCKED e N/A são o oposto exato — o
	 * primeiro diz que a medição NÃO pôde acontecer, o segundo que ela não se
	 * aplicava. WAIVED fica de fora porque ele é FALHA assinada: a medição
	 * aconteceu, mas quem a lê está lendo uma assinatura, e contar isso como
	 * "a fase rodou" faria um waiver bem colocado apagar a pergunta.
	 *
	 * Sem esta distinção o registro se aprovaria sozinho: bastaria a fase ter
	 * uma linha em BLOCKED para ela contar como executada, e "nunca medido"
	 * deixaria de existir no instante em que passasse a valer.
	 */
	public const ESTADOS_QUE_MEDEM = array( 'OK', 'FALHA', 'WARN' );

	/**
	 * Estados fechados que a aplicabilidade decide entre si.
	 */
	public const BLOCKED = 'BLOCKED';
	public const NA      = 'N/A';

	/**
	 * ESTADOS QUE RESOLVEM UM GATE DE FASE — e por que são exatamente estes dois.
	 *
	 * Um gate de fase existe para perguntar *"a evidência daquela fase já
	 * chegou?"*. Dois estados respondem que não há nada pendente ali, e por
	 * motivos opostos:
	 *
	 * - **OK**: a evidência chegou e passou.
	 * - **N/A**: a pergunta **não se aplica aqui** — a fase declarada não é a
	 *   fase corrente. Não falta ação de ninguém; falta a fase.
	 *
	 * Todos os outros deixam o gate ABERTO: `BLOCKED` (não foi possível medir na
	 * fase certa), `FALHA` (mediu e reprovou), `WARN` (mediu e sobrou achado
	 * adverso) e `WAIVED` (reprovou e alguém assinou — o waiver silencia o
	 * veredito, nunca a medição, e some daqui seria a assinatura apagando o
	 * registro).
	 *
	 * ESTA FUNÇÃO EXISTE PORQUE A COMPARAÇÃO ESTAVA EM TRÊS LUGARES, e os três
	 * escreviam `OK !== $estado`. Com a 1.1.6 isso passou a imprimir
	 * **"pendência de fase (N/A)"** — que é a mesma confusão entre
	 * aplicabilidade e pendência que esta release existe para eliminar, um andar
	 * abaixo: N/A não é pendência de ninguém. Três comparações são três chances
	 * de a próxima condição ser acrescentada em duas delas.
	 */
	public const RESOLVEM_A_FASE = array( 'OK', 'N/A' );

	/**
	 * O gate de FASE desta linha continua ABERTO?
	 *
	 * @param string $estado Estado fechado lido da linha.
	 * @return bool
	 */
	public static function gate_de_fase_em_aberto( string $estado ): bool {
		return ! in_array( $estado, self::RESOLVEM_A_FASE, true );
	}

	/**
	 * As fases fechadas.
	 *
	 * @return string[]
	 */
	public static function fases(): array {
		return self::FASES;
	}

	/**
	 * REGRA 1 — a checagem se aplica NESTA fase?
	 *
	 * Fase declarada igual à fase corrente: a pergunta se aplica aqui, e o que
	 * falta é pré-condição — BLOCKED. Fase declarada diferente: a condição
	 * "esta fase produz esta evidência" é FALSA, e N/A é precisamente o estado
	 * de condição de aplicabilidade falsa.
	 *
	 * DOIS PISOS, e eles são o motivo de a função existir em vez de um `===`
	 * solto no chamador. Fase declarada fora da lista fechada **não absolve**:
	 * esquecer de declarar seria o caminho barato para sair do BLOCKED, e o erro
	 * seguro dos dois é continuar cobrando. Fase corrente fora da lista fechada
	 * também não absolve, pela razão simétrica: um ambiente que não sabe dizer
	 * em que fase está não pode dispensar checagem nenhuma.
	 *
	 * @param string $fase_declarada Fase em que a checagem É medida.
	 * @param string $fase_corrente  Fase deste emissor.
	 * @return array{aplicavel:bool,estado:string,fase_declarada:string,fase_corrente:string,porque:string}
	 */
	public static function aplicabilidade( string $fase_declarada, string $fase_corrente ): array {
		$declarada_valida = in_array( $fase_declarada, self::FASES, true );
		$corrente_valida  = in_array( $fase_corrente, self::FASES, true );

		if ( ! $declarada_valida || ! $corrente_valida ) {
			return array(
				'aplicavel'      => true,
				'estado'         => self::BLOCKED,
				'fase_declarada' => $fase_declarada,
				'fase_corrente'  => $fase_corrente,
				'porque'         => $declarada_valida
					? 'fase corrente fora da lista fechada (' . $fase_corrente . '): ambiente que não sabe dizer em que fase está não dispensa checagem nenhuma'
					: 'fase declarada fora da lista fechada (' . $fase_declarada . '): não declarar fase não pode ser o caminho barato para sair do BLOCKED',
			);
		}

		if ( $fase_declarada === $fase_corrente ) {
			return array(
				'aplicavel'      => true,
				'estado'         => self::BLOCKED,
				'fase_declarada' => $fase_declarada,
				'fase_corrente'  => $fase_corrente,
				'porque'         => 'a fase declarada é a fase corrente: a pergunta se aplica aqui, e o que falta é pré-condição',
			);
		}

		return array(
			'aplicavel'      => false,
			'estado'         => self::NA,
			'fase_declarada' => $fase_declarada,
			'fase_corrente'  => $fase_corrente,
			'porque'         => 'esta checagem é medida na fase ' . $fase_declarada . ' e este emissor é a fase ' . $fase_corrente
				. ': não falta ação de ninguém, falta a fase — e condição de aplicabilidade falsa é N/A, não pendência',
		);
	}

	/**
	 * REGRA 2 — o registro do que cada fase espera, e quando ela rodou.
	 *
	 * Recebe as LINHAS emitidas (nome, fase, estado) e o registro DURÁVEL das
	 * execuções anteriores. Devolve, por fase: quantas checagens a esperam,
	 * QUAIS são, quais delas foram medidas AGORA, quando a fase rodou pela
	 * última vez e se ela nunca rodou.
	 *
	 * FASE SEM NINGUÉM ESPERANDO NÃO É ACHADO. Uma fase para a qual nenhuma
	 * checagem foi declarada não tem cobertura a cobrar: acusá-la produziria um
	 * aviso permanente sobre uma ausência que ninguém pediu, que é o mesmo
	 * defeito do aviso que sai sempre.
	 *
	 * @param array<int,array{nome?:string,fase?:string,estado?:string}> $linhas   Linhas emitidas.
	 * @param array<string,mixed>                                        $anterior Registro durável lido de fora.
	 * @param int                                                        $agora    Carimbo de tempo desta execução.
	 * @return array{fases:array<string,array<string,mixed>>,nunca:array<int,string>,cobrar:array<int,string>,estado:string,esperando:int}
	 */
	public static function registro( array $linhas, array $anterior, int $agora ): array {
		$fases = array();

		foreach ( self::FASES as $fase ) {
			$fases[ $fase ] = array(
				'esperam'   => array(),
				'medidas'   => array(),
				'fora_do_na' => array(),
			);
		}

		foreach ( $linhas as $linha ) {
			$fase   = (string) ( $linha['fase'] ?? '' );
			$nome   = (string) ( $linha['nome'] ?? '' );
			$estado = (string) ( $linha['estado'] ?? '' );

			if ( '' === $nome || ! isset( $fases[ $fase ] ) ) {
				continue;
			}

			if ( ! in_array( $nome, $fases[ $fase ]['esperam'], true ) ) {
				$fases[ $fase ]['esperam'][] = $nome;
			}

			if ( in_array( $estado, self::ESTADOS_QUE_MEDEM, true ) && ! in_array( $nome, $fases[ $fase ]['medidas'], true ) ) {
				$fases[ $fase ]['medidas'][] = $nome;
			}

			/*
			 * FORA DO N/A: a linha fechou em qualquer coisa que NÃO seja N/A —
			 * medida, BLOCKED, WAIVED. É este conjunto que separa "esta fase não
			 * se aplica a este emissor, por desenho" de "esta fase tinha o que
			 * medir e não mediu". Uma linha em BLOCKED entra aqui de propósito:
			 * ali a pergunta se aplicava e a resposta não veio.
			 */
			if ( self::NA !== $estado && ! in_array( $nome, $fases[ $fase ]['fora_do_na'], true ) ) {
				$fases[ $fase ]['fora_do_na'][] = $nome;
			}
		}

		$nunca     = array();
		$cobrar    = array();
		$esperando = 0;

		foreach ( self::FASES as $fase ) {
			sort( $fases[ $fase ]['esperam'] );
			sort( $fases[ $fase ]['medidas'] );
			sort( $fases[ $fase ]['fora_do_na'] );

			$rodou_agora = array() !== $fases[ $fase ]['medidas'];
			$registrada  = isset( $anterior[ $fase ] ) && is_array( $anterior[ $fase ] )
				? (int) ( $anterior[ $fase ]['ultima'] ?? 0 )
				: 0;

			$ultima = $rodou_agora ? $agora : $registrada;

			$fases[ $fase ]['quantas']     = count( $fases[ $fase ]['esperam'] );
			$fases[ $fase ]['rodou_agora'] = $rodou_agora;
			$fases[ $fase ]['ultima']      = $ultima;
			$fases[ $fase ]['por']         = $rodou_agora
				? ''
				: (string) ( is_array( $anterior[ $fase ] ?? null ) ? ( $anterior[ $fase ]['por'] ?? '' ) : '' );
			$fases[ $fase ]['nunca']       = 0 === $ultima && array() !== $fases[ $fase ]['esperam'];

			/*
			 * NÃO APLICÁVEL A ESTE EMISSOR: toda checagem que espera esta fase
			 * fechou N/A nesta execução. Não falta ação de ninguém e ninguém vai
			 * preencher isso aqui — é o mesmo fato que a regra de aplicabilidade
			 * já declarou, linha por linha, subindo um nível. Sem esta
			 * separação, a fase `campo` produzia WARN em TODA execução deste
			 * host, para sempre, sobre uma ausência por desenho — que é o
			 * defeito do aviso que sai sempre, do lado do contrapeso.
			 *
			 * O QUE NÃO MUDA: N/A continua NÃO registrando a fase como
			 * executada. `rodou_agora`, `ultima` e `nunca` seguem contando só os
			 * estados que MEDEM, e o registro durável continua cobrando a fase.
			 * A mudança é só no que vira WARN.
			 */
			$fases[ $fase ]['nao_aplicavel'] = array() !== $fases[ $fase ]['esperam']
				&& array() === $fases[ $fase ]['fora_do_na'];

			if ( array() !== $fases[ $fase ]['esperam'] ) {
				++$esperando;
			}

			if ( $fases[ $fase ]['nunca'] ) {
				$nunca[] = $fase;

				if ( ! $fases[ $fase ]['nao_aplicavel'] ) {
					$cobrar[] = $fase;
				}
			}
		}

		return array(
			'fases'     => $fases,
			'nunca'     => $nunca,
			'cobrar'    => $cobrar,
			'esperando' => $esperando,
			'estado'    => array() === $cobrar ? 'OK' : 'WARN',
		);
	}

	/**
	 * O registro durável ATUALIZADO, pronto para ser persistido.
	 *
	 * A fase medida nesta execução recebe o carimbo de agora; a que não foi
	 * medida CONSERVA o que já estava — é isso que faz o registro durar entre
	 * execuções, e é a mesma razão pela qual a decisão 64 proibiu o ramo que
	 * preserva de mover a base.
	 *
	 * @param array{fases:array<string,array<string,mixed>>} $registro Resultado de `registro()`.
	 * @param array<string,mixed>                            $anterior Registro durável anterior.
	 * @param int                                            $agora    Carimbo de tempo.
	 * @param string                                         $por      Quem mediu (`suite` ou `host`).
	 * @return array<string,array{ultima:int,por:string,medidas:int}>
	 */
	public static function durar( array $registro, array $anterior, int $agora, string $por ): array {
		$saida = array();

		foreach ( self::FASES as $fase ) {
			$dados = $registro['fases'][ $fase ] ?? array();

			if ( ! empty( $dados['rodou_agora'] ) ) {
				$saida[ $fase ] = array(
					'ultima'  => $agora,
					'por'     => $por,
					'medidas' => count( (array) ( $dados['medidas'] ?? array() ) ),
				);
				continue;
			}

			if ( isset( $anterior[ $fase ] ) && is_array( $anterior[ $fase ] ) && (int) ( $anterior[ $fase ]['ultima'] ?? 0 ) > 0 ) {
				$saida[ $fase ] = array(
					'ultima'  => (int) $anterior[ $fase ]['ultima'],
					'por'     => (string) ( $anterior[ $fase ]['por'] ?? '' ),
					'medidas' => (int) ( $anterior[ $fase ]['medidas'] ?? 0 ),
				);
			}
		}

		return $saida;
	}

	/**
	 * O CARIMBO DE TEMPO DESTE REGISTRO, alinhado ao DIA em UTC.
	 *
	 * A precisão é de dia, e isso é decisão, não descuido. O registro da suíte
	 * mora DENTRO do pacote e entra na soma que produz o hash do pacote — foi a
	 * escolha declarada, para que um registro forjado, que é o que afirmaria
	 * falsamente "a fase de navegador rodou", não escape da cobertura de
	 * integridade. O preço direto disso é que qualquer coisa que mude no
	 * registro muda o hash: com precisão de segundo, DUAS rodadas seguidas sobre
	 * uma árvore idêntica produziriam hashes diferentes, e um operador
	 * comparando dois digests legítimos concluiria que o pacote foi adulterado —
	 * que é exatamente o mal-entendido que o MANIFESTO existe para evitar.
	 *
	 * Com o dia, a árvore reverificada no mesmo dia dá o MESMO hash. E não se
	 * perde nada que esta pergunta precise: "quando aquela fase rodou pela
	 * última vez" é uma pergunta de calendário, e a hora exata não muda nenhuma
	 * decisão que este registro alimenta.
	 *
	 * @param int $agora Carimbo de tempo bruto.
	 * @return int Carimbo alinhado à meia-noite UTC daquele dia.
	 */
	public static function dia( int $agora ): int {
		return $agora - ( $agora % 86400 );
	}

	/**
	 * A frase de "quando esta fase rodou", sem tradução e sem inventar data.
	 *
	 * Fase nunca executada sai com todas as letras — nunca com um traço, nunca
	 * com a data de hoje e nunca em branco. Registro que não distingue "não sei"
	 * de "agora" é registro que aprova por omissão.
	 *
	 * A data sai sem hora pela razão escrita em `dia()`: a precisão guardada é a
	 * de dia, e imprimir `00:00:00` ao lado dela seria afirmar uma hora que
	 * ninguém mediu.
	 *
	 * @param array<string,mixed> $dados Bloco de uma fase, como `registro()` o devolve.
	 * @return string
	 */
	public static function quando( array $dados ): string {
		if ( ! empty( $dados['rodou_agora'] ) ) {
			return 'nesta rodada';
		}

		$ultima = (int) ( $dados['ultima'] ?? 0 );

		if ( 0 === $ultima ) {
			return 'NUNCA EXECUTADA';
		}

		$por = (string) ( $dados['por'] ?? '' );

		return gmdate( 'Y-m-d', $ultima ) . ( '' !== $por ? ' (' . $por . ')' : '' );
	}
}
