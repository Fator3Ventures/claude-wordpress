<?php
/**
 * Empacotamento — PRIMEIRA ETAPA do comando único, sempre.
 *
 * Verificar sem empacotar já aprovou um pacote que não montava: o build é a
 * primeira coisa que roda, e um arquivo fora do inventário ABORTA a rodada com
 * o nome do arquivo, antes de qualquer checagem.
 *
 * A allow-list é de CAMINHOS, não de extensões. Filtro por extensão já publicou
 * sonda de depuração dentro de um tema e já aprovou um pacote que continha uma
 * cópia inteira de si mesmo: as extensões estavam certas e os caminhos não.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/*
 * O TOKENIZADOR VEM DA ÁRVORE DESTE ARQUIVO, e não da raiz varrida. O piso roda
 * as mesmas funções contra fixtures, e uma fixture que trouxesse o próprio
 * tokenizador estaria sendo medida pelo corte que ela mesma declara.
 */
require_once __DIR__ . '/tokenizador-js.php';

/**
 * ASSETS DO PLUGIN QUE VIAJAM SEM COMENTÁRIO, e o peso que isso devolve.
 *
 * Medido na 1.3.5, em `assets/f3base-tracking.js`: 88.367 bytes brutos e 30.328
 * comprimidos; sem comentários, 29.218 e 7.709. Dois terços do arquivo eram
 * comentário, e são vinte e dois quilobytes comprimidos que TODO visitante de
 * um site de tráfego pago baixa sem ter, no navegador, um único leitor para
 * eles.
 *
 * A disciplina de comentário deste pacote não mudou: ela existe para impedir
 * regressão, e quem lê é quem MANTÉM o pacote. A fonte continua com tudo. O que
 * muda é o que sai pela porta — o zip do plugin, o avulso de `dist/` e a cópia
 * embutida (byte a byte a mesma), levam os `.js` sem comentário.
 *
 * O CORTE É FEITO POR TOKENIZADOR, nunca por expressão regular, e o motivo está
 * escrito em `ferramentas/tokenizador-js.php`: `/*` dentro de string e `//`
 * dentro de URL ou de literal de regex existem NESTES arquivos, e um corte
 * ingênuo os apaga entregando um arquivo que ainda analisa e faz outra coisa.
 *
 * @return array<int,string> Prefixos, relativos à fonte do plugin, cujos `.js` viajam enxutos.
 */
function f3b_prefixos_de_js_entregue(): array {
	return array( 'assets/' );
}

/**
 * O conteúdo que um caminho da fonte do plugin ENTREGA.
 *
 * Ponto único: o zip avulso, a cópia embutida e a cópia de conferência em
 * `dist/entregue/` saem todos daqui. Duas implementações do corte divergiriam
 * na primeira vez que alguém mexesse numa só, e a divergência apareceria como
 * um arquivo entregue diferente do arquivo medido.
 *
 * @param string $relativo Caminho relativo à fonte do plugin.
 * @param string $bruto    Conteúdo da fonte.
 * @return string Conteúdo entregue.
 */
function f3b_conteudo_entregue( string $relativo, string $bruto ): string {
	if ( '.js' !== strtolower( substr( $relativo, -3 ) ) ) {
		return $bruto;
	}

	foreach ( f3b_prefixos_de_js_entregue() as $prefixo ) {
		if ( str_starts_with( $relativo, $prefixo ) ) {
			return f3b_js_sem_comentario( $bruto );
		}
	}

	return $bruto;
}

/**
 * Inventário declarado: caminho relativo → papel.
 *
 * Linha terminada em `/` é PREFIXO declarado (diretório inteiro, com o papel
 * escrito). Todo o resto é caminho exato.
 *
 * @param string $suite Diretório da suíte.
 * @return array{exatos:array<string,string>,prefixos:array<string,string>}
 */
function f3b_inventario( string $suite ): array {
	$exatos   = array();
	$prefixos = array();

	foreach ( f3b_tsv( $suite . '/inventario.tsv' ) as $linha ) {
		$caminho = trim( $linha[0] ?? '' );
		$papel   = trim( $linha[1] ?? '' );

		if ( '' === $caminho ) {
			continue;
		}

		if ( str_ends_with( $caminho, '/' ) ) {
			$prefixos[ $caminho ] = $papel;
			continue;
		}

		$exatos[ $caminho ] = $papel;
	}

	return array(
		'exatos'   => $exatos,
		'prefixos' => $prefixos,
	);
}

/**
 * Caminhos que a PRÓPRIA RODADA produz dentro do pacote.
 *
 * Eles constam do inventário (têm papel declarado, entram no bundle e viajam
 * com ele), mas a rodada que os grava só os grava no FIM — depois das
 * checagens. Cobrar a presença deles ANTES do selo faria um clone limpo
 * reprovar na primeira execução por um arquivo que aquela execução ainda vai
 * escrever. O que cobra a presença deles no artefato ENTREGUE é
 * `entrega.rodada_limpa`, no host, que é onde a ausência importa.
 *
 * @return array<string,string> Caminho relativo => por que ele nasce na rodada.
 */
function f3b_produzidos_pela_rodada(): array {
	return array(
		'suite/rodada.json' => 'registro DA rodada: gravado pelo selo, no fim do comando único, com o veredito declarado, as pendências de fase nomeadas e o hash do pacote que esta rodada mediu',
		'suite/fases.json'  => 'registro DURÁVEL de fases: gravado no fim do comando único, com a data em que cada fase fechada rodou pela última vez. É ele que impede a regra de aplicabilidade da 1.1.6 de virar cegueira — sem ele, uma checagem em N/A por fase ausente ficaria em N/A para sempre e ninguém saberia que a fase nunca rodou',
	);
}

/**
 * Todo arquivo do pacote consta do inventário, com papel declarado.
 *
 * Acusa nos dois sentidos: arquivo em disco fora do inventário, e caminho
 * inventariado que não existe em disco. Papel vazio também é achado — um
 * inventário que lista o caminho e não diz para que ele serve não é allow-list,
 * é lista de arquivos.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_allow_list( string $raiz, string $suite ): array {
	$inv = f3b_inventario( $suite );

	if ( array() === $inv['exatos'] && array() === $inv['prefixos'] ) {
		return array(
			'ok'      => false,
			'achados' => array( 'suite/inventario.tsv vazio ou ausente — sem inventário não existe allow-list' ),
		);
	}

	$achados = array();
	$emdisco = f3b_arquivos( $raiz, array(), f3b_fora_do_pacote() );

	foreach ( $emdisco as $rel ) {
		if ( isset( $inv['exatos'][ $rel ] ) ) {
			if ( '' === $inv['exatos'][ $rel ] ) {
				$achados[] = 'sem papel declarado: ' . $rel;
			}

			continue;
		}

		$coberto = false;

		foreach ( $inv['prefixos'] as $prefixo => $papel ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$coberto = true;

				if ( '' === $papel ) {
					$achados[] = 'sem papel declarado no prefixo ' . $prefixo . ': ' . $rel;
				}

				break;
			}
		}

		if ( ! $coberto ) {
			$achados[] = 'FORA DO INVENTÁRIO: ' . $rel;
		}
	}

	$produzidos = f3b_produzidos_pela_rodada();

	foreach ( $inv['exatos'] as $rel => $papel ) {
		unset( $papel );

		if ( in_array( $rel, $emdisco, true ) ) {
			continue;
		}

		if ( isset( $produzidos[ $rel ] ) ) {
			/* Ausente porque esta rodada ainda não o gravou — e quem o grava é ela. */
			continue;
		}

		$achados[] = 'inventariado e ausente em disco: ' . $rel;
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
	);
}

/**
 * Fontes do pacote, sem a saída de build.
 *
 * É a árvore INTEIRA do repositório, e é ela que `pacote.build_fresco` compara
 * contra os artefatos: editar a fonte do plugin sem reempacotar precisa deixar
 * o build velho, mesmo que aquela fonte não viaje dentro do bundle.
 *
 * @param string $raiz Raiz.
 * @return array<int,string>
 */
function f3b_fontes( string $raiz ): array {
	return f3b_arquivos( $raiz, array(), f3b_fora_do_pacote() );
}

/**
 * O QUE NÃO É PACOTE, e por isso não entra em varredura nenhuma daqui.
 *
 * `dist/` é saída desta suíte, declarada como tal no inventário. O prefixo
 * `.git` é METADADO DO CONTROLE DE VERSÃO — o diretório do repositório, o
 * arquivo-ponteiro que um worktree põe no lugar dele, e o `.gitignore`. Nada
 * disso viaja no zip e nada disso é fonte do plugin.
 *
 * POR QUE ISTO EXISTE. O repositório passou a ser versionado depois da rodada
 * de referência, e sem esta exclusão o comando único ABORTA na primeira etapa
 * com `FORA DO INVENTÁRIO: .git` em qualquer checkout — inventariar metadado de
 * VCS seria pior: `pacote.build_fresco` compara a mesma varredura contra o
 * artefato, e um commit deixaria o build "velho" sem que uma linha de fonte
 * tivesse mudado.
 *
 * @return array<int,string> Prefixos relativos.
 */
function f3b_fora_do_pacote(): array {
	return array( 'dist/', '.git' );
}


/**
 * OS ARQUIVOS DA FONTE DO PLUGIN QUE VÊM DO CONTRATO COMPARTILHADO.
 *
 * No implantador esta distinção era de DIRETÓRIO: `fontes/plugin/` de um lado,
 * `partilhado/` do outro, e o empacotamento fundia os dois dentro do zip. Neste
 * repositório o plugin é o artefato inteiro e a fonte dele já está fundida —
 * `includes/` traz as quatro classes de regra e `dados/` traz a declaração de
 * emissores. A ORIGEM continua sendo um fato, e um fato que o documento do
 * plugin declara: sem esta lista, "arquivos na fonte do plugin" e "arquivos
 * vindos de partilhado/" passariam a ser dois números diferentes dos que o
 * mesmo disco produzia do outro lado, e a diferença não seria mudança nenhuma
 * do plugin — seria a fusão de dois diretórios contada como crescimento.
 *
 * Lista de CAMINHOS, nunca de contagem: quem conta é quem lê o disco.
 *
 * @return array<string,string> Caminho relativo à fonte do plugin => de onde ele veio.
 */
function f3b_insumos_partilhados(): array {
	return array(
		'dados/emissores-conhecidos.tsv'              => 'partilhado/dados/ do implantador — a declaração de emissores que os dois runtimes leem',
		'includes/class-f3base-censo-demonstrativo.php' => 'partilhado/includes/ do implantador — regra de censo do conteúdo demonstrativo',
		'includes/class-f3base-chaves-seo.php'        => 'partilhado/includes/ do implantador — o contrato de chaves de SEO',
		'includes/class-f3base-emissores.php'         => 'partilhado/includes/ do implantador — a regra do emissor concorrente',
		'includes/class-f3base-vocabulario.php'       => 'partilhado/includes/ do implantador — o vocabulário comum às duas telas',
	);
}


/**
 * Artefato de build mais novo que toda fonte.
 *
 * Artefato mais velho que a fonte é o defeito silencioso do empacotamento: o
 * zip existe, o nome está certo, e o conteúdo é de antes da última mudança.
 *
 * @param string $artefato Caminho do artefato.
 * @param string $raiz     Raiz das fontes.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_build_fresco( string $artefato, string $raiz ): array {
	if ( ! is_file( $artefato ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'artefato de build ausente: ' . $artefato ),
		);
	}

	clearstatcache();

	$data_artefato = (int) filemtime( $artefato );
	$achados       = array();

	foreach ( f3b_fontes( $raiz ) as $rel ) {
		$data_fonte = (int) filemtime( $raiz . '/' . $rel );

		if ( $data_fonte > $data_artefato ) {
			$achados[] = sprintf(
				'%s (%s) é mais novo que %s (%s)',
				$rel,
				gmdate( 'Y-m-d H:i:s', $data_fonte ),
				basename( $artefato ),
				gmdate( 'Y-m-d H:i:s', $data_artefato )
			);
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
	);
}

/**
 * Remove um diretório inteiro.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_apagar( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	$itens = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $itens as $item ) {
		if ( $item->isDir() ) {
			rmdir( $item->getPathname() );
			continue;
		}

		unlink( $item->getPathname() );
	}

	rmdir( $dir );
}

/**
 * Monta o artefato deste repositório: o zip do plugin, e só ele.
 *
 * O QUE ESTA FUNÇÃO NÃO FAZ MAIS, e por quê. No implantador ela montava um
 * BUNDLE — a árvore inteira do pacote, com o zip do plugin embutido como
 * reserva de instalação — e o zip do plugin era um passo dentro dela. Aqui o
 * plugin É o artefato: não há bundle para montar, não há reserva para embutir e
 * não há hash de árvore para calcular, porque o que sai pela porta é um arquivo
 * só. Manter aquele caminho vivo sem bundle produziria as duas coisas que esta
 * suíte recusa em todo lugar — um artefato que ninguém instala e uma afirmação
 * sobre ele.
 *
 * A ORDEM CONTINUA A MESMA: documentos primeiro, artefato depois, lock por
 * último. Regenerar os documentos depois de fechar o zip publicaria o documento
 * da rodada anterior dentro dele, que é exatamente o defeito que a região
 * gerada existe para não ter.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>,artefato:string,entregue:string,versao:string,documentos:array<int,string>,peso:array<string,mixed>}
 */
function f3b_empacotar( string $raiz, string $suite ): array {
	/*
	 * DOCUMENTOS ENTREGÁVEIS PRIMEIRO, antes de qualquer cópia:
	 * INSTRUCOES-DO-PLUGIN.md viaja DENTRO do zip do plugin, e regenerá-lo
	 * depois faria o artefato publicado carregar o carimbo da rodada anterior.
	 */
	$documentos = f3b_gerar_documentos( $raiz, $suite );

	$dist = $raiz . '/dist';

	if ( ! is_dir( $dist ) && ! mkdir( $dist, 0755, true ) && ! is_dir( $dist ) ) {
		return array(
			'ok'         => false,
			'achados'    => array( 'não foi possível criar ' . $dist ),
			'artefato'   => '',
			'entregue'   => '',
			'versao'     => '',
			'documentos' => $documentos['escritos'],
			'peso'       => array(),
		);
	}

	$achados = $documentos['achados'];

	if ( ! is_dir( $raiz . '/fontes/plugin' ) ) {
		$achados[] = 'diretório ausente: fontes/plugin/';
	}

	$plugin = f3b_empacotar_site_core( $raiz, $dist );

	foreach ( $plugin['achados'] as $achado_do_plugin ) {
		$achados[] = $achado_do_plugin;
	}

	/* Lock: sha256 de cada caminho da allow-list, em ordem de caminho. */
	if ( is_file( $plugin['artefato'] ) ) {
		f3b_gravar_lock( $raiz, $dist, $plugin['artefato'] );
	}

	/*
	 * O ARTEFATO PRECISA SER MAIS NOVO QUE A FONTE, e o toque é do próprio
	 * build — a mesma regra do bundle do implantador. O carimbo INTERNO das
	 * entradas do zip continua sendo a época declarada: o `touch` mexe no inode
	 * do arquivo, nunca no conteúdo dele, e é por isso que ele não desfaz a
	 * reprodutibilidade que `f3b_epoca_do_zip()` sustenta.
	 */
	if ( is_file( $plugin['artefato'] ) ) {
		touch( $plugin['artefato'] );
	}

	return array(
		'ok'         => array() === $achados,
		'achados'    => $achados,
		'artefato'   => $plugin['artefato'],
		'entregue'   => $dist . '/entregue/base-site-core-fator3',
		'versao'     => $plugin['versao'],
		'documentos' => $documentos['escritos'],
		'peso'       => $plugin['peso'] ?? array(),
	);
}


/**
 * A ÉPOCA DECLARADA DAS ENTRADAS DO ZIP DO PLUGIN. Produtor ÚNICO.
 *
 * UM INSTANTE CONSTANTE, e a escolha é a decisão desta release. As duas saídas
 * possíveis foram pesadas:
 *
 * - **Época fixa declarada** — o carimbo deixa de dizer qualquer coisa sobre
 *   quando o pacote foi montado. Isso é HONESTO, porque ele já não dizia: até a
 *   1.7.3 ele dizia "meia-noite do dia da montagem", que é um instante que
 *   nunca existiu, e a partir da 1.7.0 nenhum caminho do pacote o lia. Quem
 *   responde "qual versão é esta" é o cabeçalho do plugin; quem responde "o
 *   artefato mudou" é o `sha256` do lock e o digesto fixado no host.
 * - **Derivado do conteúdo** — o mtime mais novo entre os arquivos-fonte, por
 *   exemplo. Carrega alguma informação e RECUSADA: mtime de arquivo é
 *   reescrito por qualquer cópia de árvore — `git clone`, `cp` sem `-a`,
 *   extração de um tar, um checkout de CI —, e foi exatamente uma cópia de
 *   estágio nascendo com a hora de agora que criou o defeito original. Trocar o
 *   relógio do processo pelo relógio gravado no inode é trocar de porta, não
 *   fechar a porta.
 *
 * O INSTANTE É `1980-01-01 00:00:00 UTC`, e ele foi escolhido por dizer o que
 * é. Ele é o ZERO do formato zip — a menor data que o carimbo DOS representa —,
 * então ninguém o lê como data de montagem por engano, que é justamente o
 * mal-entendido que uma época plausível (2020-01-01, por exemplo) reintroduz.
 *
 * QUEM MAIS LÊ ESTA FUNÇÃO: `suite/lib/sonda-bundle.php`, no teto de
 * `pacote.reserva_identica_ao_avulso`. Ela confere o carimbo do artefato
 * MONTADO contra esta declaração, e é por ela ser a mesma função dos dois
 * lados que o teto não pode concordar com um build que mudou de época.
 *
 * @return string Instante aceito por `touch -d`.
 */
function f3b_epoca_do_zip(): string {
	return '1980-01-01 00:00:00 UTC';
}

/**
 * As entradas do zip do plugin, em caminhos relativos ao estágio.
 *
 * Diretórios INCLUÍDOS, e de propósito: o zip do plugin sempre teve entrada
 * própria para cada diretório, e tirá-las mudaria o conjunto de entradas do
 * artefato entregue — que é coisa diferente de mudar a ordem delas.
 *
 * @param string $stage Diretório do estágio.
 * @param string $topo  Nome do diretório de topo dentro do estágio.
 * @return array<int,string> Caminhos relativos ao estágio, sem ordem garantida.
 */
function f3b_entradas_do_zip( string $stage, string $topo ): array {
	$raiz = $stage . '/' . $topo;

	if ( ! is_dir( $raiz ) ) {
		return array();
	}

	$saida    = array( $topo . '/' );
	$iterador = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::SELF_FIRST
	);

	foreach ( $iterador as $item ) {
		if ( ! $item instanceof SplFileInfo ) {
			continue;
		}

		$relativo = substr( str_replace( '\\', '/', (string) $item->getPathname() ), strlen( $stage ) + 1 );

		$saida[] = $item->isDir() ? $relativo . '/' : $relativo;
	}

	return $saida;
}

/**
 * Monta `dist/base-site-core-fator3-A.B.C.zip` e devolve a cópia a embutir.
 *
 * O NÚMERO SAI DO CABEÇALHO DO PRÓPRIO PLUGIN, nunca de `config/site.json`: é
 * ele que tem release própria, e é o cabeçalho que o WordPress mostra na lista
 * de plugins. Repetir o número na configuração do implantador foi exatamente o
 * que fez toda correção do plugin virar release do implantador.
 *
 * @param string $raiz Raiz do pacote.
 * @param string $dist Diretório de saída.
 * @return array{achados:array<int,string>,artefato:string,versao:string,peso:array<string,mixed>}
 */
function f3b_zip_atual( string $raiz ): string {
	$principal = $raiz . '/fontes/plugin/base-site-core-fator3.php';
	$topo = is_file( $principal ) ? (string) file_get_contents( $principal, false, null, 0, 8192 ) : '';
	return preg_match( '/^[\s*#@]*Version:\s*([a-zA-Z0-9.+-]+)\s*$/mi', $topo, $m ) ? $raiz . '/dist/base-site-core-fator3-' . $m[1] . '.zip' : '';
}
function f3b_empacotar_site_core( string $raiz, string $dist ): array {
	$fonte     = $raiz . '/fontes/plugin';
	$principal = $fonte . '/base-site-core-fator3.php';
	$achados   = array();

	if ( ! is_file( $principal ) ) {
		return array(
			'achados'   => array( 'fontes/plugin/base-site-core-fator3.php ausente: o plugin não pode ser empacotado' ),
			'artefato'  => '',
			'versao'    => '',
		);
	}

	$topo   = (string) file_get_contents( $principal, false, null, 0, 8192 );
	$versao = 1 === preg_match( '/^[\s*#@]*Version:\s*(\S+)\s*$/mi', $topo, $achou ) ? trim( $achou[1] ) : '';

	if ( '' === $versao ) {
		return array(
			'achados'   => array( 'fontes/plugin/base-site-core-fator3.php sem cabeçalho Version: — o nome do artefato do plugin não pode ser inventado' ),
			'artefato'  => '',
			'versao'    => '',
		);
	}

	$stage = $dist . '/stage-site-core';

	f3b_apagar( $stage );

	if ( ! mkdir( $stage . '/base-site-core-fator3', 0755, true ) && ! is_dir( $stage . '/base-site-core-fator3' ) ) {
		return array(
			'achados'   => array( 'não foi possível preparar ' . $stage ),
			'artefato'  => '',
			'versao'    => '',
		);
	}

	/*
	 * A CÓPIA DE CONFERÊNCIA, e ela existe porque a bancada não pode medir um
	 * arquivo que só existiu dentro de um diretório temporário.
	 *
	 * O stage é apagado no fim desta função. Sem `dist/entregue/`, a única
	 * forma de a suíte ver o arquivo ENTREGUE seria reabrir o zip a cada
	 * checagem — ou, pior, refazer o corte por conta própria, que é a segunda
	 * implementação que este pacote recusa em todo lugar. Aqui ela é gravada
	 * uma vez, byte a byte igual à que entrou no zip, e todas as checagens de
	 * comportamento leem daí. Ela mora em `dist/`, que é saída de build: não
	 * entra no inventário, não entra no lock e não viaja no pacote.
	 */
	$entregue = $dist . '/entregue/base-site-core-fator3';

	f3b_apagar( $entregue );

	$peso = array();

	/*
	 * O CONTRATO COMPARTILHADO ENTRA AQUI, e não mora na fonte do plugin.
	 *
	 * `partilhado/` guarda as quatro classes de regra e a declaração de
	 * emissores que os DOIS runtimes leem: o implantador precisa delas ANTES de
	 * este plugin existir na instalação — o preflight roda antes de instalar
	 * qualquer coisa — e o plugin as carrega pelo autoload dele. Uma cópia de
	 * cada lado divergiria na primeira condição acrescentada, e foi a ausência
	 * desse lugar neutro que fazia o implantador ler de dentro da fonte do
	 * plugin — a dependência que obrigava aquela fonte a viajar no bundle.
	 *
	 * A cópia é MECÂNICA e no mesmo caminho relativo: `partilhado/includes/x`
	 * vira `includes/x` dentro do plugin. Quem confere que o zip ficou
	 * completo é `pacote.plugin_completo_no_zip`, contra a lista de autoload do
	 * próprio plugin.
	 */
	$origens = array( $fonte => '' );

	$arquivos_do_plugin = array();

	foreach ( $origens as $de => $ignorado ) {
		unset( $ignorado );

		foreach ( f3b_arquivos( $de, array(), array() ) as $rel ) {
			if ( isset( $arquivos_do_plugin[ $rel ] ) ) {
				$achados[] = $rel . ': o mesmo caminho existe em fontes/plugin/ e em partilhado/. '
					. 'Duas origens para o mesmo arquivo dentro do zip fazem a segunda cópia sobrescrever a primeira em silêncio, '
					. 'e qual delas o site recebe passa a depender da ordem da varredura';
				continue;
			}

			$arquivos_do_plugin[ $rel ] = $de;
		}
	}

	ksort( $arquivos_do_plugin );

	foreach ( $arquivos_do_plugin as $rel => $de_onde ) {
		$destino = $stage . '/base-site-core-fator3/' . $rel;

		if ( ! is_dir( dirname( $destino ) ) ) {
			mkdir( dirname( $destino ), 0755, true );
		}

		$bruto  = (string) file_get_contents( $de_onde . '/' . $rel );
		$corpo  = f3b_conteudo_entregue( $rel, $bruto );

		file_put_contents( $destino, $corpo );

		if ( $corpo !== $bruto ) {
			$peso[ $rel ] = array(
				'fonte'            => strlen( $bruto ),
				'entregue'         => strlen( $corpo ),
				'fonte_gz'         => strlen( (string) gzencode( $bruto, 9 ) ),
				'entregue_gz'      => strlen( (string) gzencode( $corpo, 9 ) ),
			);
		}

		$espelho = $entregue . '/' . $rel;

		if ( ! is_dir( dirname( $espelho ) ) ) {
			mkdir( dirname( $espelho ), 0755, true );
		}

		file_put_contents( $espelho, $corpo );
	}

	/*
	 * O DOCUMENTO DE INSTRUÇÕES É CONFERIDO AQUI, ANTES DE O ZIP FECHAR.
	 *
	 * Ele entra no zip pela mesma varredura que traz todo o resto da fonte — não
	 * há lista de arquivos a manter —, e é justamente por isso que a presença
	 * dele precisa ser AFIRMADA: um arquivo que entra por varredura some por
	 * varredura, e um zip sem ele fecha verde. Quem recebe este plugin recebe o
	 * zip, e não o repositório: publicá-lo sem o documento entrega o código sem
	 * a única explicação de por que ele é assim.
	 *
	 * A conferência do ARTEFATO montado, com as três cláusulas, é
	 * `pacote.instrucoes_do_plugin_no_zip`. Esta aqui é anterior e mais barata:
	 * ela aborta o build com o nome, em vez de deixar a suíte reprovar um zip
	 * que já foi publicado.
	 */
	if ( ! is_file( $stage . '/base-site-core-fator3/INSTRUCOES-DO-PLUGIN.md' ) ) {
		$achados[] = 'INSTRUCOES-DO-PLUGIN.md não chegou ao diretório de montagem do plugin: o zip sairia sem o documento que '
			. 'outro agente precisa para entender, operar e MUDAR este plugin, e quem o recebe recebe o zip, não o repositório';
	}

	$artefato = $dist . '/base-site-core-fator3-' . $versao . '.zip';

	if ( is_file( $artefato ) ) {
		unlink( $artefato );
	}

	/*
	 * O ZIP DO PLUGIN É REPRODUTÍVEL, E ISSO TEM DUAS METADES — 1.7.4.
	 *
	 * Nenhuma delas pode faltar. A 1.7.3 instalou meia correção, declarou a
	 * outra por engano e as duas metades foram medidas falhando nesta release.
	 *
	 * PRIMEIRA METADE — O CARIMBO SAI DO RELÓGIO. Até a 1.7.3 o carimbo das
	 * entradas era `gmdate( 'Y-m-d', floor( time() / 86400 ) * 86400 )`: o
	 * relógio, arredondado ao dia. A mesma árvore, byte a byte idêntica,
	 * empacotada em dois dias dava dois arquivos diferentes — medido, com a
	 * árvore arquivada, extraída noutro lugar e reempacotada, `diff -r` limpo e
	 * `sha256` diferente:
	 *
	 *     05/09  693ca754ab5bc337e8786c4959c346c6342dd04804f577d597bf57fea3d42a31
	 *     06/09  aeb40cadf2598e87814c5adaaae1a80138c89434d1f364f25fc142356a3bf94c
	 *
	 * SEGUNDA METADE — A ORDEM SAI DO SISTEMA DE ARQUIVOS. `zip -r` grava as
	 * entradas na ordem em que o diretório as devolve, e essa ordem é do
	 * SISTEMA DE ARQUIVOS: no ext4 ela vem do hash do nome com a semente do
	 * volume, no tmpfs vem da ordem de criação. Medido nesta bancada, mesma
	 * árvore, MESMO DIA, dois volumes: `693ca754…` no ext4 e
	 * `855fabbb…` no tmpfs. A 1.7.3 escreveu que `TZ=UTC` fazia "a mesma árvore
	 * montada em duas máquinas" dar os mesmos bytes; o fuso era só uma das
	 * portas, e esta era a outra. Por isso a lista de entradas é montada AQUI,
	 * ordenada por byte, e entregue ao `zip` por `-@`: a ordem passa a ser
	 * decisão deste arquivo, e não do volume onde o build calhou de rodar.
	 *
	 * POR QUE ISSO É MAIS GRAVE DO QUE "o hash do pacote não fecha duas vezes".
	 * Este zip é PUBLICADO no catálogo (`plugins.instalaveis.0`, origem `url`,
	 * sem `sha256` declarado), e `F3Base_Imp_Plugins::veredito_do_digest()`
	 * FIXA o digesto dele na primeira observação e REPROVA a execução seguinte
	 * quando ele muda, com a frase "a origem não mudou entre as execuções"
	 * invertida. Republicar amanhã um zip de conteúdo idêntico, reconstruído da
	 * mesma fonte, faria TODA implantação seguinte falhar acusando troca de
	 * artefato que não houve. É o falso alarme que a decisão 84 existe para
	 * evitar, produzido pela aplicação LITERAL da régua dela.
	 *
	 * E É POR ISSO QUE A RÉGUA DA DECISÃO 84 NÃO SE APLICA AQUI. Precisão de
	 * DIA serve a um registro que alguém LÊ — "quando aquela fase rodou pela
	 * última vez" é pergunta de calendário, e o `suite/fases.json` continua
	 * respondendo assim. Não serve a um artefato cujo digesto é a CHAVE de uma
	 * comparação entre execuções: ali qualquer granularidade tirada do relógio
	 * é uma bomba-relógio, e a única resposta certa é o relógio não entrar.
	 *
	 * A ÉPOCA É DECLARADA e mora em `f3b_epoca_do_zip()`, com o motivo ao lado.
	 *
	 * `TZ=UTC` continua nas duas chamadas, e continua sendo necessário: o
	 * formato zip guarda a hora LOCAL de cada entrada, então sem fixar o fuso a
	 * mesma época declarada viraria carimbos diferentes em máquinas de fusos
	 * diferentes.
	 */
	$saida  = array();
	$codigo = 0;
	exec(
		sprintf(
			'TZ=UTC find %s -exec touch -d %s {} + 2>&1',
			escapeshellarg( $stage . '/base-site-core-fator3' ),
			escapeshellarg( f3b_epoca_do_zip() )
		),
		$saida,
		$codigo
	);

	if ( 0 !== $codigo ) {
		$achados[] = 'falha ao fixar o carimbo de tempo do estágio do plugin: ' . f3b_amostra( $saida, 2 );
	}

	/*
	 * A LISTA DE ENTRADAS, ordenada por BYTE e escrita fora do estágio.
	 *
	 * Ela é montada em PHP, e não por `find | sort`, por duas razões medidas.
	 * A primeira é o código de saída: `exec()` roda por `sh`, o `sh` desta base
	 * é o `dash`, o `dash` não tem `pipefail`, e num cano o código que volta é o
	 * do ÚLTIMO comando — um `find` que falhasse deixaria o `zip` fechar um
	 * arquivo incompleto com código 0. A segunda é que a lista já existe: o
	 * laço da cópia acabou de percorrer esta árvore, e refazer a varredura por
	 * fora seria uma segunda implementação da mesma pergunta.
	 *
	 * Ela mora em `$dist` e NÃO dentro do estágio: um arquivo de trabalho
	 * dentro do estágio entraria no zip.
	 */
	$entradas = array();

	foreach ( f3b_entradas_do_zip( $stage, 'base-site-core-fator3' ) as $rel ) {
		if ( 1 === preg_match( '/[\r\n]/', $rel ) ) {
			$achados[] = 'entrada do zip do plugin com quebra de linha no nome (' . rawurlencode( $rel ) . '): '
				. 'a lista de entradas é uma linha por caminho, e um nome com quebra de linha faria o zip receber dois nomes que não existem';
			continue;
		}

		$entradas[] = $rel;
	}

	sort( $entradas, SORT_STRING );

	$lista = $dist . '/entradas-do-plugin.txt';

	file_put_contents( $lista, implode( "\n", $entradas ) . "\n" );

	$saida  = array();
	$codigo = 0;
	exec(
		sprintf(
			'cd %s && TZ=UTC zip -qX -@ %s < %s 2>&1',
			escapeshellarg( $stage ),
			escapeshellarg( $artefato ),
			escapeshellarg( $lista )
		),
		$saida,
		$codigo
	);

	unlink( $lista );

	if ( 0 !== $codigo || ! is_file( $artefato ) ) {
		$achados[] = 'falha ao montar o artefato do plugin: ' . f3b_amostra( $saida, 2 );
	}


	/*
	 * O ARTEFATO NÃO É GRAVADO NA ÁRVORE DE ORIGEM, e isso não mudou ao sair do
	 * implantador: um artefato gerado pelo build morando entre as fontes seria um
	 * arquivo que o inventário teria de autorizar e que mudaria de conteúdo a
	 * cada rodada. Ele mora em `dist/`, que é saída de build, e o nome carrega o
	 * NÚMERO lido do cabeçalho — é ele que responde, no host, qual versão está
	 * publicada, e é uma fonte lida de disco, não digitada.
	 */
	f3b_apagar( $stage );

	return array(
		'achados'  => $achados,
		'artefato' => $artefato,
		'versao'   => $versao,
		'peso'     => $peso,
	);
}

/**
 * O JAVASCRIPT ENTREGUE NÃO TEM COMENTÁRIO — e não perdeu mais nada.
 *
 * Duas afirmações, e a segunda é a que importa. A primeira é fácil de medir e
 * fácil de conseguir errado: basta apagar bytes até não sobrar `/*`. A segunda
 * diz o que NÃO pode ter acontecido — o entregue precisa ser a fonte com cada
 * comentário trocado por um espaço ou por uma quebra de linha, e nada mais.
 *
 * A PROVA É O FLUXO DE TOKENS. Fonte e entregue são tokenizados, os comentários
 * são descartados dos dois e os espaços são normalizados; o que sobra tem de ser
 * idêntico, token a token. É essa comparação que acusa o corte por expressão
 * regular: apagando de `/*` dentro de uma string até o `fechamento de bloco` seguinte, o
 * conteúdo entre eles some, as aspas passam a fechar em outro lugar, e o fluxo
 * de tokens do entregue deixa de ser o da fonte. Contar comentários não veria
 * nada disso — o arquivo corrompido também não tem comentário nenhum.
 *
 * E QUEM DIZ QUE O ENTREGUE AINDA É JAVASCRIPT É O `node --check`, que é o
 * parser de verdade e não este arquivo. Quem diz que ele se COMPORTA igual são
 * as bancadas de comportamento e a sonda de navegador, que rodam contra o
 * entregue e não contra a fonte.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_js_entregue_sem_comentario( string $raiz ): array {
	$fonte    = $raiz . '/fontes/plugin';
	$entregue = $raiz . '/dist/entregue/base-site-core-fator3';
	$achados  = array();
	$medidas  = 0;
	$zip      = f3b_zip_atual( $raiz );

	foreach ( f3b_arquivos( $fonte, array( 'js' ), array() ) as $rel ) {
		$enxuto = false;

		foreach ( f3b_prefixos_de_js_entregue() as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$enxuto = true;
			}
		}

		if ( ! $enxuto ) {
			continue;
		}

		++$medidas;

		if ( ! is_file( $entregue . '/' . $rel ) ) {
			$achados[] = $rel . ': o arquivo ENTREGUE não existe em dist/entregue/. Sem ele nada aqui foi medido, e uma checagem que não encontra o que mede não pode fechar OK';
			continue;
		}

		$bruto   = (string) file_get_contents( $fonte . '/' . $rel );
		$servido = (string) file_get_contents( $entregue . '/' . $rel );

		$comentarios = 0;

		foreach ( f3b_tokenizar_js( $servido ) as $token ) {
			if ( 'comentario-linha' === $token['tipo'] || 'comentario-bloco' === $token['tipo'] ) {
				if ( f3b_js_comentario_de_licenca( $token['texto'] ) ) {
					continue;
				}

				++$comentarios;
			}
		}

		if ( $comentarios > 0 ) {
			$achados[] = $rel . ': o arquivo entregue ainda tem ' . $comentarios .
				' comentário(s) sem aviso de licença. Comentário é para quem MANTÉM o pacote, e o visitante de um site de tráfego pago o baixa a cada carregamento sem ter leitor nenhum para ele';
		}

		$da_fonte  = f3b_js_significativo( $bruto );
		$do_servido = f3b_js_significativo( $servido );

		if ( $da_fonte !== $do_servido ) {
			$achados[] = $rel . ': o entregue perdeu ou ganhou conteúdo que NÃO é comentário — ' .
				count( $da_fonte ) . ' token(s) significativo(s) na fonte contra ' . count( $do_servido ) . ' no entregue, primeira divergência em "' .
				f3b_js_primeira_divergencia( $da_fonte, $do_servido ) .
				'". É a assinatura do corte por expressão regular: `/*` dentro de string e `//` dentro de URL ou de literal de regex não são comentário, e apagá-los entrega um arquivo que ainda analisa e faz outra coisa';
		}

		$saida  = array();
		$codigo = 0;
		exec( 'node --check ' . escapeshellarg( $entregue . '/' . $rel ) . ' 2>&1', $saida, $codigo );

		if ( 0 !== $codigo ) {
			$achados[] = $rel . ': o arquivo ENTREGUE não passa em node --check: ' . f3b_amostra( $saida, 2 );
		}

		/*
		 * LEITURA DE VOLTA DO QUE ENTROU NO ZIP, e ela é o que amarra a medição
		 * ao artefato. `dist/entregue/` só vale alguma coisa se for, byte a
		 * byte, o que o visitante recebe: sem abrir o zip, um erro de ordem
		 * entre a escrita do stage e a montagem faria a suíte medir um arquivo e
		 * o site servir outro, com todas as linhas em OK.
		 *
		 * A leitura é BYTE A BYTE, por `shell_exec`. `exec()` devolve o corpo
		 * quebrado em linhas e APARA o branco do fim de cada uma — e o arquivo
		 * entregue tem linhas que terminam em branco, porque um comentário
		 * removido deixa a indentação onde estava. A comparação sairia
		 * divergente sobre dois arquivos idênticos.
		 */
		if ( '' === $zip ) {
			$achados[] = $rel . ': existe dist/entregue/ e não existe zip do site-core em dist/ para conferir contra ele. '
				. 'A cópia de conferência sem o artefato ao lado é uma medição sobre um arquivo que ninguém provou ter sido entregue';
			continue;
		}

		$no_zip = (string) shell_exec(
			'unzip -p ' . escapeshellarg( $zip ) . ' ' . escapeshellarg( 'base-site-core-fator3/' . $rel ) . ' 2>/dev/null'
		);

		if ( $no_zip !== $servido ) {
			$achados[] = $rel . ': o que entrou no zip do site-core NÃO é o que ficou em dist/entregue/ ('
				. strlen( $no_zip ) . ' contra ' . strlen( $servido ) . ' bytes). A suíte estaria medindo um arquivo e o site servindo outro';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * O fluxo de tokens SIGNIFICATIVOS: sem comentário e com o espaço normalizado.
 *
 * O espaço é normalizado — e não removido — porque ele separa tokens: apagá-lo
 * faria `var a` e `vara` terem o mesmo fluxo. O que ele NÃO pode carregar é a
 * forma: o comentário removido deixa para trás um espaço ou uma quebra onde a
 * fonte tinha outra coisa, e comparar a forma acusaria justamente a mudança que
 * o corte tem o direito de fazer.
 *
 * @param string $codigo Código-fonte.
 * @return array<int,string>
 */
function f3b_js_significativo( string $codigo ): array {
	$fluxo = array();

	foreach ( f3b_tokenizar_js( $codigo ) as $token ) {
		if ( 'comentario-linha' === $token['tipo'] || 'comentario-bloco' === $token['tipo'] ) {
			if ( ! f3b_js_comentario_de_licenca( $token['texto'] ) ) {
				continue;
			}
		}

		if ( 'espaco' === $token['tipo'] ) {
			if ( array() !== $fluxo && ' ' === $fluxo[ count( $fluxo ) - 1 ] ) {
				continue;
			}

			$fluxo[] = ' ';
			continue;
		}

		$fluxo[] = $token['texto'];
	}

	return $fluxo;
}

/**
 * A primeira posição em que dois fluxos de token discordam, com o trecho.
 *
 * Achado que só diz "diferente" manda alguém abrir dois arquivos de trinta
 * quilobytes e comparar à mão.
 *
 * @param array<int,string> $a Fluxo da fonte.
 * @param array<int,string> $b Fluxo do entregue.
 * @return string
 */
function f3b_js_primeira_divergencia( array $a, array $b ): string {
	$total = min( count( $a ), count( $b ) );

	for ( $i = 0; $i < $total; $i++ ) {
		if ( $a[ $i ] !== $b[ $i ] ) {
			return 'token ' . $i . ': fonte=' . substr( $a[ $i ], 0, 40 ) . ' | entregue=' . substr( $b[ $i ], 0, 40 );
		}
	}

	return 'token ' . $total . ': um dos fluxos terminou antes do outro';
}

/**
 * Grava `dist/lock.tsv`: sha256 de cada caminho da allow-list, em ordem.
 *
 * Função própria porque ela roda DUAS vezes: no empacotamento e de novo depois
 * do selo, quando `suite/rodada.json` acabou de mudar. Um lock que descreve o
 * arquivo anterior é pior que lock nenhum.
 *
 * O ARTEFATO ENTRA NO LOCK pelo nome com que ele é publicado. Ele não mora na
 * árvore de origem — é saída de build —, e é justamente por isso que o sha256
 * dele precisa estar aqui: sem essa linha, o único registro do que foi
 * publicado seria o próprio arquivo.
 *
 * @param string $raiz     Raiz do pacote.
 * @param string $dist     Diretório de saída.
 * @param string $artefato Caminho do zip do plugin.
 * @return void
 */
function f3b_gravar_lock( string $raiz, string $dist, string $artefato = '' ): void {
	$linhas = array( "# caminho\tsha256" );

	foreach ( f3b_fontes( $raiz ) as $rel ) {
		$linhas[] = $rel . "\t" . hash_file( 'sha256', $raiz . '/' . $rel );
	}

	if ( '' !== $artefato && is_file( $artefato ) ) {
		$linhas[] = 'dist/' . basename( $artefato ) . "\t" . hash_file( 'sha256', $artefato );
	}

	file_put_contents( $dist . '/lock.tsv', implode( "\n", $linhas ) . "\n" );
}


/**
 * SELO DA RODADA — grava `suite/rodada.json` com o artefato que ela mediu.
 *
 * O QUE MUDOU AO SAIR DO IMPLANTADOR, e é uma subtração. Lá o registro era
 * INJETADO dentro do bundle já montado, e para isso ele precisava ser excluído
 * do hash do pacote dos dois lados — o registro descrevia o artefato em que ele
 * próprio morava. Aqui o artefato é o zip do PLUGIN, e o registro NÃO entra
 * nele: o zip é reprodutível byte a byte a partir da fonte, é o que o catálogo
 * publica, e o digesto dele é fixado no host na primeira observação. Injetar um
 * arquivo que muda a cada rodada dentro dele faria toda implantação seguinte
 * acusar troca de artefato que não houve.
 *
 * Sem injeção, a circularidade não existe e o hash volta a ser a coisa simples
 * que ele deveria ter sido: o `sha256` do arquivo publicado, lido de volta do
 * disco depois de gravado.
 *
 * E ele só grava REGISTRO DE RODADA LIMPA: com qualquer FALHA, o registro
 * anterior é REMOVIDO e o achado sai nomeado. Registro que sobrevive a uma
 * rodada reprovada é uma afirmação de limpeza sem medição por trás.
 *
 * @param string                          $raiz     Raiz do pacote.
 * @param string                          $suite    Diretório da suíte.
 * @param array<string,mixed>             $build    Resultado do empacotamento.
 * @param array<string,int>               $contagem Contagem por estado da rodada.
 * @param array<string,array<int,string>> $nomes    Nomes por estado da rodada.
 * @param array<int,string>               $piso     Detectores com piso em disco.
 * @return array{ok:bool,achados:array<int,string>,arquivo:string,hash:string,gravado:bool}
 */
function f3b_selar_rodada( string $raiz, string $suite, array $build, array $contagem, array $nomes, array $piso ): array {
	unset( $suite );

	$relativo = 'suite/rodada.json';
	$arquivo  = $raiz . '/' . $relativo;
	$achados  = array();
	$artefato = (string) ( $build['artefato'] ?? '' );
	$falhas   = (int) ( $contagem['FALHA'] ?? 0 );

	if ( $falhas > 0 ) {
		if ( is_file( $arquivo ) ) {
			unlink( $arquivo );
		}

		return array(
			'ok'      => true,
			'achados' => array( 'rodada com ' . $falhas . ' FALHA — o registro NÃO foi gravado e o anterior foi removido: ' . $relativo ),
			'arquivo' => $arquivo,
			'hash'    => '',
			'gravado' => false,
		);
	}

	if ( '' === $artefato || ! is_file( $artefato ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'selo impossível: o artefato do plugin não existe (artefato="' . $artefato . '")' ),
			'arquivo' => $arquivo,
			'hash'    => '',
			'gravado' => false,
		);
	}

	$hash = (string) hash_file( 'sha256', $artefato );

	/*
	 * O REGISTRO DECLARA O VEREDITO, e não só o hash. Pendência é NOMEADA,
	 * nunca contada sem nome: um registro que diz "sem falha" com bloqueios
	 * dentro afirma mais do que o conteúdo sustenta.
	 */
	$pendencias = array_values( array_map( 'strval', $nomes['BLOCKED'] ?? array() ) );
	$veredito   = array() === $pendencias ? 'sem-falha-e-sem-pendencia' : 'sem-falha-com-pendencia-de-fase';

	$registro = array(
		'registro'           => 'rodada',
		'produzido_por'      => 'suite/verificar.sh — comando único; gravado à mão, este registro não vale nada e o detector de fonte única existe para impedi-lo',
		'veredito'           => $veredito,
		'veredito_diz'       => array() === $pendencias
			? 'a rodada fechou com ZERO FALHA e ZERO pendência: nenhuma checagem ficou em BLOCKED.'
			: 'a rodada fechou com ZERO FALHA e ' . count( $pendencias ) . ' pendência(s) de fase em BLOCKED, nomeada(s) em pendencias_de_fase. Isto NÃO é uma rodada sem pendência, e o campo existe para que o host não leia mais do que foi medido.',
		'falhas'             => (int) ( $contagem['FALHA'] ?? 0 ),
		'pendencias_de_fase' => $pendencias,
		'release'            => (string) ( $build['versao'] ?? '' ),
		'artefato'           => basename( $artefato ),
		'hash_artefato'      => $hash,
		'hash_regra'         => 'sha256 do arquivo publicado em dist/, lido de volta do disco depois de gravado. Aqui o artefato é o zip do plugin e o registro NÃO viaja dentro dele — o zip é reprodutível byte a byte a partir da fonte e o digesto dele é fixado no host, então injetar um arquivo que muda a cada rodada faria a implantação seguinte acusar troca que não houve.',
		'em'                 => gmdate( 'Y-m-d\TH:i:s\Z' ),
		'resumo'             => $contagem,
		'nomes'              => $nomes,
		'piso'               => array(
			'detectores_com_fixture' => count( $piso ),
			'nomes'                  => $piso,
			'medicao'                => 'fixtures negativa E positiva presentes em suite/fixtures/; a execução do piso é o subcomando "bash suite/verificar.sh piso"',
		),
	);

	$json = json_encode( $registro, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

	if ( ! is_string( $json ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'o registro da rodada não codificou em JSON' ),
			'arquivo' => $arquivo,
			'hash'    => $hash,
			'gravado' => false,
		);
	}

	file_put_contents( $arquivo, $json . "\n" );

	/*
	 * LEITURA DE VOLTA: o hash gravado é relido do artefato em disco. Gravar o
	 * número que a variável carrega provaria que a variável existe, e é a
	 * mesma classe de afirmação sem medição que o selo existe para não fazer.
	 */
	$conferido = (string) hash_file( 'sha256', $artefato );

	if ( $conferido !== $hash ) {
		$achados[] = 'o sha256 relido do artefato (' . $conferido . ') difere do que foi gravado no registro (' . $hash . ')';
	}

	f3b_gravar_lock( $raiz, $raiz . '/dist', $artefato );

	return array(
		'ok'        => array() === $achados,
		'achados'   => $achados,
		'arquivo'   => $arquivo,
		'hash'      => $hash,
		'conferido' => $conferido,
		'gravado'   => true,
	);
}


/**
 * REGISTRO DURÁVEL DE FASES — grava `suite/fases.json`. Produtor ÚNICO.
 *
 * IRMÃO DO SELO, E NÃO O SELO. Os dois moram em `suite/`, os dois são escritos
 * só pelo comando único e os dois são conferidos por `estatica.gate_fonte_unica`
 * pela mesma regra de produtor único. O que os separa é o tempo de vida:
 *
 * - `suite/rodada.json` descreve UMA rodada, é reescrito a cada rodada e é
 *   APAGADO quando a rodada tem FALHA — registro de limpeza que sobrevive a uma
 *   rodada reprovada é afirmação sem medição por trás.
 * - `suite/fases.json` descreve QUANDO CADA FASE RODOU PELA ÚLTIMA VEZ, e
 *   precisa durar entre execuções: é ele que impede a regra de aplicabilidade
 *   da 1.1.6 de virar cegueira. Apagá-lo numa rodada com FALHA perderia o
 *   registro de que a fase de navegador rodou um dia — e é justamente esse fato
 *   que a rodada de build não tem como reproduzir. Por isso ele é gravado
 *   SEMPRE, inclusive na rodada reprovada: ele não afirma aprovação nenhuma,
 *   afirma execução.
 *
 * ELE NÃO É INJETADO NO BUNDLE, e essa é a segunda metade da decisão. O selo
 * precisa ser injetado porque o HOST o consome, e para isso ele foi excluído do
 * hash do pacote dos dois lados. Excluir um segundo arquivo da soma tiraria mais
 * um caminho da cobertura de integridade para resolver um problema que este
 * registro não tem: quem o lê é a PRÓXIMA rodada da suíte, na mesma árvore, e o
 * host tem o registro dele próprio, na option `f3base_fases`. O preço declarado
 * é que a cópia que viaja dentro do bundle é a da rodada ANTERIOR — o que basta,
 * porque a fase corrente é sempre recalculada ao vivo e só as OUTRAS fases são
 * lidas daqui.
 *
 * @param string              $raiz   Raiz do pacote.
 * @param array<string,mixed> $durar  Registro atualizado, como `F3Base_Imp_Fases::durar()` o devolve.
 * @return array{ok:bool,arquivo:string,achados:array<int,string>}
 */
function f3b_gravar_registro_de_fases( string $raiz, array $durar ): array {
	$relativo = 'suite/fases.json';
	$arquivo  = $raiz . '/' . $relativo;

	$registro = array(
		'registro'      => 'fases',
		'produzido_por' => 'suite/verificar.sh — comando único; gravado à mão, este registro não vale nada e o detector de fonte única existe para impedi-lo',
		'o_que_declara' => 'quando cada fase fechada rodou pela ÚLTIMA vez, medida por uma linha que fechou OK, FALHA ou WARN naquela fase. BLOCKED e N/A não contam: o primeiro diz que a medição não pôde acontecer e o segundo que ela não se aplicava, e contar qualquer um dos dois faria a fase se aprovar por omissão.',
		'precisao'      => 'DIA, em UTC. Este registro mora dentro do pacote e entra na soma que produz o hash dele — de propósito, para que um registro forjado não escape da cobertura de integridade. Com precisão de segundo, duas rodadas seguidas sobre uma árvore idêntica dariam hashes diferentes, e dois digests legítimos pareceriam adulteração.',
		'em'            => gmdate( 'Y-m-d' ),
		'fases'         => $durar,
	);

	$json = json_encode( $registro, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

	if ( ! is_string( $json ) ) {
		return array(
			'ok'      => false,
			'arquivo' => $arquivo,
			'achados' => array( 'o registro de fases não codificou em JSON' ),
		);
	}

	file_put_contents( $arquivo, $json . "\n" );

	return array(
		'ok'      => true,
		'arquivo' => $arquivo,
		'achados' => array(),
	);
}
