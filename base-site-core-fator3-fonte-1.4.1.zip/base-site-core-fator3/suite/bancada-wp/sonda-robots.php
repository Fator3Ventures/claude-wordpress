<?php
/** Processo independente: opções em cache antes de uma troca concorrente. */
declare( strict_types = 1 );
require $argv[1] . 'wp-load.php';
if ( 'recusa' === $argv[2] ) { echo wp_json_encode( F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) ) ); exit; }
F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION ); F3Base_Options::ler( 'f3base_robots' );
file_put_contents( $argv[2] . '/pronto-' . $argv[3], '1' );
$limite = microtime( true ) + 20;
while ( ! is_file( $argv[2] . '/iniciar' ) && microtime( true ) < $limite ) { usleep( 10000 ); }
echo wp_json_encode( F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) ) );
