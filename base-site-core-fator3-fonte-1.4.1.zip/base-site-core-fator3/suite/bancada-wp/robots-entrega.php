<?php
/** Testes da entrega real, da interceptação do servidor e da preservação de arquivos. */
declare( strict_types = 1 );
function f3b_re_fixture( string $modo ): void {
	file_put_contents( WP_CONTENT_DIR . '/mu-plugins/f3base-robots-hospedagem.txt', $modo );
}
function f3b_re_iniciar(): void {
	f3b_p_visibilidade( '1' ); f3b_rf_limpar();
	copy( __DIR__ . '/fixture-robots-entrega.php', WP_CONTENT_DIR . '/mu-plugins/f3base-robots-entrega.php' );
	f3b_re_fixture( '' );
}
function f3b_re_limpar(): void {
	foreach ( array( 'f3base-robots-entrega.php', 'f3base-robots-hospedagem.txt', 'f3base-robots-regra.txt' ) as $nome ) { $p = WP_CONTENT_DIR . '/mu-plugins/' . $nome; if ( is_file( $p ) ) { unlink( $p ); } }
	foreach ( glob( ABSPATH . '.f3base-robots-*.tmp' ) ?: array() as $p ) { unlink( $p ); }
	f3b_rf_limpar(); f3b_rf_ligar( true );
}
function f3b_re_estado(): array { f3b_rf_reler(); return ( new F3Base_Modulo_Robots_Txt() )->estado(); }
function f3b_re_verificar(): array {
	$r = F3Base_Robots_Entrega::verificar(); f3b_rf_reler();
	f3b_e_exige( $r['ok'], 'Verificação pública falhou: ' . wp_json_encode( $r ) );
	return $r;
}
function f3b_re_entrega(): array {
	f3b_re_iniciar(); $alvo = ABSPATH . 'robots.txt'; $original = "\xEF\xBB\xBF# original exato\r\nUser-agent: Original\r\nDisallow: /original/\r\n";
	try {
		file_put_contents( $alvo, $original ); chmod( $alvo, 0640 ); f3b_rf_ligar( true );
		f3b_e_exige( f3b_re_estado()['estado'] === 'degradado', 'Ausência de arquivo físico foi tomada como confirmação HTTP.' );
		$r = f3b_re_verificar();
		f3b_e_exige( $r['entrega']['modo'] === 'virtual' && ! file_exists( $alvo ) && f3b_re_estado()['estado'] === 'ativo', 'Servidor com rota virtual passou para arquivo físico ou não confirmou entrega.' );
		$http = f3b_bancada_get( '/robots.txt' );
		f3b_e_exige( substr_count( $http['corpo'], F3Base_Llms::sitemap_medido()['url'] ) === 1 && substr_count( $http['corpo'], home_url( '/mapa-terceiro.xml' ) ) === 1 && str_contains( $http['corpo'], 'User-agent: RoboFixture' ), 'Filtros tardios duplicam sitemaps ou perdem regras de terceiros.' );
		f3b_p_evidencia( 'robots-entrega-virtual', $http );
		f3b_re_fixture( 'interceptar' ); $r = f3b_re_verificar(); $e = f3b_rf_reler();
		f3b_e_exige( $r['entrega']['modo'] === 'gerenciado' && F3Base_Robots_Arquivo::proprio( $alvo, $e ) && base64_decode( $e['conteudo_base64'], true ) === $original && is_file( ABSPATH . $e['reserva'] ), 'Fallback físico não guardou o original ou não registrou propriedade.' );
		$http = f3b_bancada_get( '/robots.txt' );
		f3b_e_exige( str_starts_with( $http['corpo'], F3Base_Robots_Entrega::MARCA ) && ! str_contains( $http['corpo'], '/hospedagem/' ) && str_contains( $http['corpo'], '/primeira/' ) && f3b_re_estado()['estado'] === 'ativo', 'Hospedagem continua vencendo ou contexto real do filtro foi perdido.' );
		f3b_p_evidencia( 'robots-entrega-gerenciada', $http );
		$head = wp_remote_head( home_url( '/robots.txt' ) ); f3b_e_exige( wp_remote_retrieve_response_code( $head ) === 200 && wp_remote_retrieve_body( $head ) === '', 'HEAD físico divergente.' );
		F3Base_Robots_Entrega::planejar(); $proxima = wp_next_scheduled( F3Base_Robots_Entrega::EVENTO );
		f3b_e_exige( $proxima && $proxima <= time() + F3Base_Robots_Entrega::INTERVALO + 10, 'Job automático não foi agendado.' );
		file_put_contents( WP_CONTENT_DIR . '/mu-plugins/f3base-robots-regra.txt', 'segunda' );
		do_action( F3Base_Robots_Entrega::EVENTO ); $e = f3b_rf_reler();
		f3b_e_exige( str_contains( file_get_contents( $alvo ), '/segunda/' ) && ! str_contains( file_get_contents( $alvo ), '/primeira/' ) && base64_decode( $e['conteudo_base64'], true ) === $original, 'Job não atualizou as regras ou recapturou o arquivo gerenciado como original.' );
		f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $original && ( fileperms( $alvo ) & 0777 ) === 0640, 'Desligar não restaurou o original sobre o arquivo gerenciado.' );
		F3Base_Robots_Entrega::planejar(); f3b_e_exige( ! wp_next_scheduled( F3Base_Robots_Entrega::EVENTO ), 'Job permaneceu agendado com a opção desligada.' );
		f3b_rf_ligar( true ); f3b_re_verificar();
		$externo = "User-agent: *\nDisallow: /edicao-externa/\n"; file_put_contents( $alvo, $externo );
		$r = F3Base_Robots_Entrega::verificar(); f3b_e_exige( ! $r['ok'] && file_get_contents( $alvo ) === $externo && f3b_re_estado()['estado'] === 'degradado', 'Edição externa foi sobrescrita ou informada como ativa.' );
		f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $externo, 'Desligar descartou edição externa.' );
		f3b_rf_ligar( true ); f3b_re_verificar(); F3Base_Robots_Arquivo::suspender();
		f3b_e_exige( file_get_contents( $alvo ) === $externo, 'Suspensão não restaurou o original do novo ciclo.' );
		unlink( $alvo ); f3b_rf_ligar( true ); f3b_re_verificar(); f3b_rf_ligar( false );
		f3b_e_exige( ! file_exists( $alvo ), 'Novo ciclo sem original ressuscitou backup de um ciclo encerrado.' );
		f3b_rf_limpar(); f3b_rf_ligar( true ); f3b_re_verificar(); f3b_rf_ligar( false );
		f3b_e_exige( ! file_exists( $alvo ), 'Desligar deixou arquivo gerenciado sem original anterior.' );
	} finally { f3b_re_limpar(); }
	return array( 'OK', 'HTTP real: filtros tardios, sitemaps únicos, rota virtual, fallback de hospedagem, atualização pelo job, HEAD, propriedade, restauração exata e edições externas.' );
}
function f3b_re_falhas(): array {
	f3b_re_iniciar(); $alvo = ABSPATH . 'robots.txt';
	try {
		f3b_rf_ligar( true ); f3b_re_fixture( 'sem-prova' );
		$r = F3Base_Robots_Entrega::verificar(); f3b_e_exige( ! $r['ok'] && ! file_exists( $alvo ) && f3b_re_estado()['estado'] === 'degradado', 'Resposta sem prova foi usada como fonte.' );
		f3b_re_fixture( 'cache' ); $r = F3Base_Robots_Entrega::verificar();
		f3b_e_exige( ! $r['ok'] && is_file( $alvo ) && f3b_re_estado()['estado'] === 'degradado', 'Cache divergente foi reportado como entrega confirmada.' );
		f3b_re_fixture( 'interceptar' ); f3b_re_verificar(); $bom = f3b_rf_reler();
		$velho = $bom; $velho['entrega']['verificado_em'] = time() - F3Base_Robots_Entrega::INTERVALO * 3; F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $velho );
		f3b_e_exige( f3b_re_estado()['estado'] === 'degradado', 'Confirmação vencida continuou ativa.' );
		F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $bom );
		$antes = file_get_contents( $alvo ); $contexto = F3Base_Robots_Arquivo::contexto();
		f3b_rf_ligar( false );
		$r = F3Base_Robots_Arquivo::publicar( $antes, $contexto ); f3b_e_exige( ! $r['ok'] && ! file_exists( $alvo ), 'Job antigo publicou após desligamento.' );
		f3b_rf_ligar( true );
		$r = F3Base_Robots_Arquivo::publicar( $antes, $contexto ); f3b_e_exige( ! $r['ok'] && ! file_exists( $alvo ), 'Job de ciclo anterior publicou após reativação.' );
		f3b_re_verificar(); $bom = f3b_rf_reler(); $antes = file_get_contents( $alvo );
		// Interrupção após retirar a versão anterior, antes de publicar a nova.
		$tmp = '.f3base-robots-gerado-' . wp_generate_uuid4() . '.tmp'; $ret = '.f3base-robots-retirado-' . wp_generate_uuid4() . '.tmp';
		$novo = $antes . "\n# proxima versao\n"; file_put_contents( ABSPATH . $tmp, $novo ); rename( $alvo, ABSPATH . $ret );
		$b = $bom; $b['gerenciado'] += array( 'novo_sha256' => hash( 'sha256', $novo ), 'temporario' => $tmp, 'retirado' => $ret ); F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $b );
		$r = F3Base_Robots_Arquivo::sincronizar(); f3b_e_exige( $r['ok'] && file_get_contents( $alvo ) === $antes && ! file_exists( ABSPATH . $tmp ) && ! file_exists( ABSPATH . $ret ), 'Publicação interrompida não devolveu a versão anterior.' );
		// Um terceiro ocupa o destino depois da preparação no banco; o gravador deve preservar esse arquivo.
		$externo = "User-agent: *\nDisallow: /corrida/\n";
		$intervir = static function ( $novo, $anterior ) use ( $alvo, $externo ) { if ( ! empty( $novo['gerenciado']['temporario'] ) && empty( $anterior['gerenciado']['temporario'] ) ) { file_put_contents( $alvo, $externo ); } return $novo; };
		add_filter( 'pre_update_option_f3base_robots_backup', $intervir, 10, 2 );
		try { $r = F3Base_Robots_Arquivo::publicar( $novo, F3Base_Robots_Arquivo::contexto() ); f3b_e_exige( ! $r['ok'] && file_get_contents( $alvo ) === $externo, 'Terceiro surgido durante publicação foi sobrescrito.' ); }
		finally { remove_filter( 'pre_update_option_f3base_robots_backup', $intervir ); }
	} finally { f3b_re_limpar(); }
	return array( 'OK', 'Recusa fonte sem prova, cache divergente, confirmação vencida, job de ciclo antigo; recupera publicação interrompida e preserva terceiro na disputa.' );
}
