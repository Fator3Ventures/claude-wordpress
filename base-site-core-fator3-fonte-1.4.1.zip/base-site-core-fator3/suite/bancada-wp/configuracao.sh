#!/usr/bin/env bash
# Prova complementar em navegador, em instalação descartável apenas com o plugin.
set -uo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/bancada.sh"
faltam="$(insumos)"
if [ -n "$faltam" ]; then echo "$faltam" >&2; exit 1; fi
if ! montar "$(realpath "$1")"; then echo "$MOTIVO" >&2; exit 1; fi
F3BASE_BANCADA_PORTA="$PORTA" node "$AQUI/tela-configuracao.cjs"
