#!/usr/bin/env python3
"""Reexecuta os defeitos relacionados à publicação em cópias isoladas do plugin.

Uso: python3 suite/bancada-wp/piso-publicacao.py /caminho/do/pacote [passo...]
A rodada positiva completa é suite/verificar.sh. Aqui cada mutante deve ser recusado.
Requer o mesmo PATH/cache da bancada; não altera a fonte nem os testes.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

root = Path(sys.argv[1]).resolve()
bench = root / 'suite/bancada-wp'
steps = {'robots_entrega', 'robots_entrega_falhas', 'robots_troca', 'robots_falhas', 'robots_ciclo', 'llms_full_estruturado', 'publicacao_llms', 'publicacao_markdown', 'publicacao_robots',
         'llms_nao_publica_protegido', 'llms_full_responde',
         'llms_indice_aponta_texto_integral', 'configuracao_independente'}
if len(sys.argv) > 2:
    steps = set(sys.argv[2:])
jobs = []
for line in (bench / 'pisos.tsv').read_text().splitlines():
    fields = line.split('\t')
    if len(fields) >= 2 and fields[0] in steps:
        jobs.extend((fields[0], patch) for patch in fields[1].split(','))

def run(job):
    step, patch = job
    with tempfile.TemporaryDirectory(prefix='f3base-publicacao-piso-') as d:
        d = Path(d)
        tree = d / 'base-site-core-fator3'
        shutil.copytree(root / 'fontes/plugin', tree)
        applied = subprocess.run(['patch', '-p1', '--batch', '--silent', '-i', str(bench / patch)],
                                 cwd=tree, capture_output=True, text=True)
        if applied.returncode:
            return {'estado': 'FALHA', 'passo': step, 'mutante': patch, 'motivo': applied.stdout + applied.stderr}
        artifact = d / 'mutante.zip'
        with zipfile.ZipFile(artifact, 'w', zipfile.ZIP_DEFLATED) as z:
            for p in sorted(tree.rglob('*')):
                if p.is_file():
                    z.write(p, p.relative_to(d))
        env = dict(os.environ)
        env.pop('F3BASE_PUBLICACAO_EVIDENCIAS', None)
        r = subprocess.run(['bash', str(bench / 'bancada.sh'), 'rodada', str(artifact), step],
                           capture_output=True, text=True, env=env, timeout=300)
        result = None
        for line in r.stdout.splitlines():
            try:
                item = json.loads(line)
                if item.get('nome') == 'wp.' + step:
                    result = item
            except json.JSONDecodeError:
                pass
        return {'estado': 'OK' if result and result['estado'] == 'FALHA' else 'FALHA',
                'passo': step, 'mutante': patch, 'observado': result,
                'motivo': ('Defeito detectado pelo cenário real.' if result['estado'] == 'FALHA' else 'Mutante não detectado; cenário retornou ' + result['estado']) if result else r.stdout + r.stderr}

failed = False
with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(run, jobs):
        print(json.dumps(result, ensure_ascii=False), flush=True)
        failed = failed or result['estado'] != 'OK'
sys.exit(1 if failed else 0)
