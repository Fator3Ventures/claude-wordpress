<?php
/** Regressões da instalação independente e do diretório de logs. */
declare( strict_types = 1 );
function f3b_c_home_generico(): array {
	$dir = getenv( 'F3BASE_BANCADA_TMP' ) . '/home-' . wp_generate_uuid4(); mkdir( $dir, 0700 );
	$processo = proc_open( array( 'env', '-u', 'HOME', PHP_BINARY, '-d', 'disable_functions=posix_getpwuid,posix_geteuid', __DIR__ . '/sonda-home.php', F3BASE_PLUGIN_DIR, $dir ), array( 1 => array( 'pipe', 'w' ), 2 => array( 'pipe', 'w' ) ), $pipes );
	f3b_e_exige( is_resource( $processo ), 'Não foi possível iniciar a sonda sem HOME.' );
	$saida = stream_get_contents( $pipes[1] ); $erro = stream_get_contents( $pipes[2] ); fclose( $pipes[1] ); fclose( $pipes[2] );
	$codigo = proc_close( $processo ); $r = json_decode( $saida, true );
	f3b_e_exige( $codigo === 0 && ! empty( $r['ok'] ) && '' === $erro, ( $r['mensagem'] ?? $saida ) . $erro );
	return array( 'OK', $r['mensagem'] );
}
function f3b_c_dom( string $html ): DOMXPath {
	$doc = new DOMDocument();
	$antes = libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="UTF-8">' . $html );
	libxml_clear_errors(); libxml_use_internal_errors( $antes );
	return new DOMXPath( $doc );
}
function f3b_c_configuracao_independente(): array {
	f3b_e_exige( get_option( 'active_plugins' ) === array( 'base-site-core-fator3/base-site-core-fator3.php' ), 'Cenário precisa somente do site-core ativo.' );
	f3b_e_exige( ! class_exists( 'Flamingo_Inbound_Message' ), 'Flamingo esconde a contingência nesta prova.' );
	$login = wp_remote_post( f3b_bancada_url( '/wp-login.php' ), array( 'redirection' => 0, 'body' => array( 'log' => 'admin', 'pwd' => 'admin' ) ) );
	$cookies = wp_remote_retrieve_cookies( $login );
	// A tela de opções carrega o mesmo menu, sem feeds externos do dashboard.
	$r = wp_remote_get( f3b_bancada_url( '/wp-admin/options-general.php' ), array( 'cookies' => $cookies, 'timeout' => 20 ) );
	f3b_e_exige( ! is_wp_error( $r ), 'Não foi possível ler o menu: ' . ( is_wp_error( $r ) ? $r->get_error_message() : '' ) );
	$x = f3b_c_dom( wp_remote_retrieve_body( $r ) );
	$menu = '//li[@id="toplevel_page_base-site-core-fator3"]';
	$href = $x->evaluate( 'string(' . $menu . '/a/@href)' );
	f3b_e_exige( $href === 'admin.php?page=base-site-core-fator3', 'Clique em F3 Base abre destino incorreto: ' . $href . '; HTTP=' . wp_remote_retrieve_response_code( $r ) . '; titulo=' . $x->evaluate( 'string(//title)' ) . '; login=' . wp_remote_retrieve_response_code( $login ) );
	f3b_e_exige( $x->evaluate( 'string(' . $menu . '/ul/li[a][1]/a/@href)' ) === $href, 'Configuração não é o primeiro submenu.' );
	f3b_e_exige( $x->query( $menu . '/ul/li/a[contains(@href,"post_type=f3base_lead")]' )->length === 1, 'Contingência deixou de ser acessível.' );
	$r = wp_remote_get( f3b_bancada_url( '/wp-admin/' . $href ), array( 'cookies' => $cookies, 'timeout' => 20 ) );
	$x = f3b_c_dom( wp_remote_retrieve_body( $r ) );
	$form = '//form[@class="f3base-form"]';
	$nonce = $x->evaluate( 'string(' . $form . '//input[@name="_wpnonce"]/@value)' );
	$acao = $x->evaluate( 'string(' . $form . '//input[@name="action"]/@value)' );
	f3b_e_exige( $nonce !== '' && $acao !== '' && $x->query( $form . '//section' )->length > 3, 'Configuração completa não renderizou.' );
	$r = wp_remote_post( f3b_bancada_url( '/wp-admin/admin-post.php' ), array( 'cookies' => $cookies, 'redirection' => 0, 'body' => array( 'action' => $acao, '_wpnonce' => $nonce, 'f3base' => array( 'f3base_sessao' => array( 'ligado' => '1', 'dias' => '77' ) ) ) ) );
	f3b_e_exige( wp_remote_retrieve_response_code( $r ) === 302, 'Gravação administrativa não redirecionou.' );
	$r = wp_remote_get( f3b_bancada_url( '/wp-admin/' . $href ), array( 'cookies' => $cookies, 'timeout' => 20 ) );
	$x = f3b_c_dom( wp_remote_retrieve_body( $r ) );
	f3b_e_exige( $x->evaluate( 'string(//input[@name="f3base[f3base_sessao][dias]"]/@value)' ) === '77', 'Valor enviado não persistiu no formulário.' );
	F3Base_Options::gravar( 'f3base_sessao', array( 'ligado' => true, 'dias' => 90 ) );
	return array( 'OK', 'Somente site-core ativo: menu real abre configurações completas; gravação HTTP com nonce persiste e leads de contingência continuam acessíveis.' );
}
function f3b_c_log_sem_www(): array {
	$antes = F3Base_Options::ler( 'f3base_acessos' );
	$origem = F3Base_Options::proveniencia( 'f3base_acessos' );
	$home = 'https://www.exemplo.test';
	$filtro = static function () use ( &$home ) { return $home; };
	add_filter( 'pre_option_home', $filtro );
	try {
		foreach ( array( 'www.exemplo.test' => 'exemplo.test', 'exemplo.test' => 'exemplo.test', 'WWW.Exemplo.test' => 'exemplo.test', 'loja.exemplo.test' => 'loja.exemplo.test', 'loja.www.exemplo.test' => 'loja.www.exemplo.test' ) as $host => $diretorio ) {
			$home = 'https://' . $host . '/subdiretorio';
			f3b_e_exige( F3Base_Modulo_Acessos_Servidor::padrao_do_log() === '~/logs/' . $diretorio . '/https/access.log.*', 'Diretório incorreto para ' . $host );
		}
		$home = 'https://www.exemplo.test';
		$config = array( 'ligado' => false, 'padrao_do_log' => '~/logs/www.exemplo.test/https/access.log.*', 'retencao_meses' => 12, 'caminhos_excluidos' => array( '/privado/' ) );
		F3Base_Options::gravar( 'f3base_acessos', $config, F3Base_Options::ORIGEM_MANUAL );
		$esperado = F3Base_Options::ler( 'f3base_acessos' ); $esperado['padrao_do_log'] = '~/logs/exemplo.test/https/access.log.*';
		$m = new F3Base_Modulo_Acessos_Servidor(); $m->inicializar();
		f3b_e_exige( get_option( 'f3base_acessos' ) === $esperado && F3Base_Options::proveniencia( 'f3base_acessos' ) === F3Base_Options::ORIGEM_MANUAL, 'Atualização não corrigiu o padrão salvo ou alterou outras escolhas.' );
		$m->inicializar(); f3b_e_exige( get_option( 'f3base_acessos' ) === $esperado, 'Atualização não é idempotente.' );
		foreach ( array( '/home/operador/logs/www.exemplo.test/https/access.log.*', '~/logs/outro.test/https/access.log.*' ) as $personalizado ) {
			$config['padrao_do_log'] = $personalizado; F3Base_Options::gravar( 'f3base_acessos', $config );
			$m->inicializar(); f3b_e_exige( get_option( 'f3base_acessos' )['padrao_do_log'] === $personalizado, 'Caminho personalizado foi alterado.' );
		}
	} finally { remove_filter( 'pre_option_home', $filtro ); F3Base_Options::gravar( 'f3base_acessos', $antes, $origem ); }
	return array( 'OK', 'Domínio sem www, subdomínios preservados, migração do antigo padrão sem reativação e caminhos personalizados intactos.' );
}
