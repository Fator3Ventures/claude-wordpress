/* Homologação local opcional: login nativo, formulário com nonce e screenshot. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const out = process.env.F3BASE_EVIDENCIA_DIR;
  if (!out) throw new Error('F3BASE_EVIDENCIA_DIR ausente');
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: process.env.F3BASE_CHROMIUM, headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    const base = `http://127.0.0.1:${process.env.F3BASE_BANCADA_PORTA}`;
    await page.goto(`${base}/wp-login.php`);
    await page.locator('#user_login').fill('admin');
    await page.locator('#user_pass').fill('admin');
    await Promise.all([page.waitForURL('**/wp-admin/**'), page.locator('#wp-submit').click()]);
    await page.goto(`${base}/wp-admin/admin.php?page=f3base-medicao&aba=acessos`);
    await Promise.all([page.waitForNavigation(), page.getByRole('button', { name: 'Coletar e Armazenar Logs', exact: true }).click()]);
    const text = await page.locator('#wpbody-content').innerText();
    for (const phrase of ['Dias armazenados: 2 de 89', '/atualizada/', 'Humanos (log)', 'não verificada']) {
      if (!text.includes(phrase)) throw new Error(`Tela sem ${phrase}`);
    }
    await page.locator('select[name="dias"]').selectOption('2');
    await page.locator('input[type="checkbox"][name="incluir_erros"]').check();
    await Promise.all([page.waitForNavigation(), page.getByRole('button', { name: 'Atualizar', exact: true }).click()]);
    const row = page.locator('tr').filter({ has: page.locator('code', { hasText: '/atualizada/' }) });
    if (await row.locator('td').nth(1).innerText() !== '3') throw new Error('Hoje não entrou na soma de dois dias');
    const line = fs.readFileSync(process.env.F3BASE_LOG_ATUAL, 'utf8');
    fs.appendFileSync(process.env.F3BASE_LOG_ATUAL, line);
    await Promise.all([page.waitForNavigation(), page.getByRole('button', { name: 'Atualizar', exact: true }).click()]);
    if (await row.locator('td').nth(1).innerText() !== '4') throw new Error('Atualizar não releu log após append');
    await Promise.all([page.waitForNavigation(), page.getByRole('button', { name: 'Coletar e Armazenar Logs', exact: true }).click()]);
    if (await page.locator('select[name="dias"]').inputValue() !== '2' || !await page.locator('input[type="checkbox"][name="incluir_erros"]').isChecked()) throw new Error('Coleta perdeu filtros');
    if (await row.locator('td').nth(1).innerText() !== '4') throw new Error('Coleta duplicou hoje');
    await page.getByText('Por família', { exact: true }).first().click();
    await page.screenshot({ path: path.join(out, 'acessos-wordpress-local.png'), fullPage: true });
    fs.writeFileSync(path.join(out, 'tela-acessos.txt'), await page.locator('#wpbody-content').innerText() + '\nAtualizar após append alterou contagem de três para quatro; coleta preservou filtros e contagem. Login pelo formulário nativo e botão Coletar e Armazenar Logs executados no Chromium.\n');
    process.stdout.write('Tela e botão reais conferidos; screenshot salvo.\n');
  } finally { await browser.close(); }
})().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
