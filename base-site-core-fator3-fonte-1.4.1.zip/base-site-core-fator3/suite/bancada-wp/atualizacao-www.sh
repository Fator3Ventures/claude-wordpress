#!/usr/bin/env bash
# Troca real de arquivos: recebe ZIP antigo e novo, sem desativar nem reativar.
set -uo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/bancada.sh"
novo="$(realpath "$2")"
faltam="$(insumos)"
if [ -n "$faltam" ]; then echo "$faltam" >&2; exit 1; fi
if ! montar "$(realpath "$1")"; then echo "$MOTIVO" >&2; exit 1; fi
wp eval 'update_option("home", "https://www.exemplo.test"); F3Base_Options::gravar("f3base_acessos", array("ligado" => false, "padrao_do_log" => "~/logs/www.exemplo.test/https/access.log.*", "retencao_meses" => 12, "caminhos_excluidos" => array("/privado/")));' >/dev/null || exit 1
mkdir -p "$SITE/wp-content/mu-plugins"
cat > "$SITE/wp-content/mu-plugins/observador.php" <<'PHP'
<?php
add_action('activated_plugin', static function () { update_option('f3base_teste_reativado', true); });
PHP
unzip -qo "$novo" -d "$SITE/wp-content/plugins" || exit 1
# A primeira inicialização após a troca acontece em HTTP, sem ajuda do roteiro.
codigo="$(curl -s --max-time 30 -o "$TMP/login.html" -w '%{http_code}' "http://127.0.0.1:$PORTA/wp-login.php")"
if [ "$codigo" != '200' ]; then echo "HTTP inesperado: $codigo" >&2; exit 1; fi
# Não carrega o plugin para conferir: o comando não pode fazer a migração que mede.
wp --skip-plugins eval '$c = get_option("f3base_acessos"); if ($c["padrao_do_log"] !== "~/logs/exemplo.test/https/access.log.*" || $c["ligado"] !== false || $c["retencao_meses"] !== 12 || !in_array("/privado/", $c["caminhos_excluidos"], true) || get_option("f3base_teste_reativado") || !in_array("base-site-core-fator3/base-site-core-fator3.php", get_option("active_plugins"), true)) { throw new RuntimeException("Migração incorreta ou reativação detectada."); } echo "OK: troca real de ZIP, migração no primeiro HTTP, plugin permaneceu ativo e nenhuma reativação ocorreu.\n";' || exit 1
