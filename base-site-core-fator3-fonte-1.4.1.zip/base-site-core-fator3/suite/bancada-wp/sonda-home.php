<?php
/** Processo sem HOME e sem POSIX: sistema de arquivos real e módulo da entrega. */
declare( strict_types = 1 );
define( 'ABSPATH', $argv[2] . '/conta/site/public/wordpress/' );
function wp_date( string $formato ): string { return gmdate( $formato ); }
require $argv[1] . '/includes/class-f3base-modulo.php';
require $argv[1] . '/includes/class-f3base-modulo-acessos-servidor.php';
function exigir_home( bool $condicao, string $motivo ): void { if ( ! $condicao ) { throw new RuntimeException( $motivo ); } }
try {
	exigir_home( false === getenv( 'HOME' ), 'Processo não está sem HOME.' );
	exigir_home( ! function_exists( 'posix_getpwuid' ), 'Cenário não desabilitou POSIX.' );
	$raiz = $argv[2]; $dominio = 'site-' . basename( $raiz ) . '.test';
	mkdir( ABSPATH, 0700, true ); mkdir( $raiz . '/storage/https.42', 0700, true );
	$logico = $raiz . '/conta/logs/' . $dominio; mkdir( $logico, 0700, true );
	symlink( $raiz . '/storage/https.42', $logico . '/https' );
	$dia = gmdate( 'Y-m-d', strtotime( '-1 day' ) );
	$arquivo = $raiz . '/storage/https.42/access.log.' . $dia;
	file_put_contents( $arquivo, "fixture\n" );
	$padrao = '~/logs/' . $dominio . '/https/access.log.*';
	$grupo = F3Base_Modulo_Acessos_Servidor::arquivos( $padrao );
	exigir_home( count( $grupo ) === 1 && $grupo[ $dia ][0]['nome'] === $arquivo, 'Ascendentes e symlink não resolveram os logs sem HOME/POSIX.' );
	exigir_home( F3Base_Modulo_Acessos_Servidor::arquivos( $logico . '/https/access.log.*' ) === $grupo, 'Caminho absoluto foi alterado.' );
	// Alias adicionais para o mesmo diretório não criam ambiguidade.
	$segundo = ABSPATH . 'logs/' . $dominio; mkdir( $segundo, 0700, true );
	symlink( $raiz . '/storage/https.42', $segundo . '/https' );
	exigir_home( F3Base_Modulo_Acessos_Servidor::arquivos( $padrao ) === $grupo, 'Aliases do mesmo destino não foram deduplicados.' );
	unlink( $segundo . '/https' ); mkdir( $segundo . '/https', 0700 );
	$recusou = false;
	try { F3Base_Modulo_Acessos_Servidor::arquivos( $padrao ); }
	catch ( RuntimeException $e ) { $recusou = str_contains( $e->getMessage(), 'ambígua' ); }
	exigir_home( $recusou, 'Duas pastas distintas foram aceitas silenciosamente.' );
	rmdir( $segundo . '/https' );
	$recusou = false;
	try { F3Base_Modulo_Acessos_Servidor::arquivos( '~/logs/inexistente-' . $dominio . '/https/access.log.*' ); }
	catch ( RuntimeException $e ) { $recusou = str_contains( $e->getMessage(), 'HOME ausente no processo PHP' ) && str_contains( $e->getMessage(), 'Diretórios tentados:' ); }
	exigir_home( $recusou, 'Ausência não diferenciada ou outro domínio foi usado.' );
	unlink( $arquivo ); $recusou = false;
	try { F3Base_Modulo_Acessos_Servidor::arquivos( $padrao ); }
	catch ( RuntimeException $e ) { $recusou = str_contains( $e->getMessage(), 'Nenhum arquivo datado fechado' ) && ! str_contains( $e->getMessage(), 'HOME ausente' ); }
	exigir_home( $recusou, 'Pasta vazia confundida com HOME ausente.' );
	echo json_encode( array( 'ok' => true, 'mensagem' => 'Sem HOME/POSIX: ascendentes, subdiretório, symlinks, aliases, caminho absoluto, ambiguidade, domínio ausente e pasta vazia conferidos.' ), JSON_UNESCAPED_UNICODE );
} catch ( Throwable $e ) { echo json_encode( array( 'ok' => false, 'mensagem' => $e->getMessage() ), JSON_UNESCAPED_UNICODE ); exit( 1 ); }
