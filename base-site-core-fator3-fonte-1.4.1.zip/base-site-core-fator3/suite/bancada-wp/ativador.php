<?php
/**
 * ATIVAÇÃO COMO O WORDPRESS A EXECUTA — num processo em que o plugin nasce inativo.
 *
 * O defeito que este arquivo existe para poder medir é de ORDEM, e ordem não se
 * observa de dentro de um processo que já carregou o plugin: quando o núcleo
 * ativa um plugin, ele o faz numa requisição em que aquele plugin NÃO estava na
 * lista de ativos, portanto não foi carregado, portanto os ganchos que ele
 * registra em `init` nunca foram registrados — e `init` já passou. Um teste que
 * desativasse e reativasse dentro do mesmo processo teria os filtros do
 * carregamento anterior ainda pendurados e aprovaria um agendamento que num site
 * real devolve `false`.
 *
 * Ele mora em arquivo próprio, e não numa string passada a outro processo,
 * porque código executável dentro de literal não é lintado nem lido por
 * ninguém — é a mesma regra que `estatica.detector_codigo_em_string` cobra do
 * resto do pacote, e a suíte não abre exceção para si mesma.
 *
 * Saída: uma linha JSON com o erro da ativação (se houve), os dois agendamentos
 * observados NESTE processo e as periodicidades que ele conhecia.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

define( 'WP_USE_THEMES', false );

$f3b_site = (string) getenv( 'F3BASE_SITE' );

if ( '' === $f3b_site || ! is_file( $f3b_site . '/wp-load.php' ) ) {
	echo '{"erro":"a bancada não expôs um WordPress carregável em F3BASE_SITE"}';
	exit( 2 );
}

require $f3b_site . '/wp-load.php';

if ( ! function_exists( 'activate_plugin' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$f3b_erro = activate_plugin( 'base-site-core-fator3/base-site-core-fator3.php' );

echo (string) wp_json_encode(
	array(
		'erro'           => is_wp_error( $f3b_erro ) ? $f3b_erro->get_error_message() : '',
		'ativo'          => is_plugin_active( 'base-site-core-fator3/base-site-core-fator3.php' ),
		'cadencia'       => wp_next_scheduled( 'f3base_cadencia_relatorio' ),
		'acessos' => wp_next_scheduled( 'f3base_acessos_somar' ),
		'retencao'       => wp_next_scheduled( 'f3base_retencao_limpeza' ),
		'periodicidades' => array_keys( wp_get_schedules() ),
	)
);
