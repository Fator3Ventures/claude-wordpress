<?php
/** Reproduz registro condicional e tardio, como o Yoast, somente na instalação descartável. */
add_action( 'wp', static function () {
	if ( ! is_robots() ) { return; }
	add_filter( 'robots_txt', static function ( $texto ) {
		$versao = WP_CONTENT_DIR . '/mu-plugins/f3base-robots-regra.txt';
		$regra = is_file( $versao ) ? trim( file_get_contents( $versao ) ) : 'primeira';
		$url = home_url( '/mapa-terceiro.xml' );
		return $texto . "\nUser-agent: RoboFixture\nDisallow: /" . $regra . "/\nSitemap: " . F3Base_Llms::sitemap_medido()['url'] . "\nSitemap: $url\nsitemap: $url\n";
	}, 99999 );
} );
