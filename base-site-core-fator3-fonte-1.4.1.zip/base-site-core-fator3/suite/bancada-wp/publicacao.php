<?php
/** Publicação llms/Markdown e integração robots em WordPress real. */
declare( strict_types = 1 );
function f3b_p_visibilidade( string $valor ): void {
	$dir = WP_CONTENT_DIR . '/mu-plugins'; if ( ! is_dir( $dir ) ) { mkdir( $dir ); }
	copy( __DIR__ . '/fixture-publicacao.php', $dir . '/f3base-publicacao-fixture.php' );
	require_once __DIR__ . '/fixture-publicacao.php';
	file_put_contents( $dir . '/f3base-publicacao-publico.txt', $valor );
}
function f3b_p_evidencia( string $nome, array $resposta ): void {
	$dir = getenv( 'F3BASE_PUBLICACAO_EVIDENCIAS' ); if ( ! $dir ) { return; }
	if ( ! is_dir( $dir ) ) { mkdir( $dir, 0700, true ); }
	$resposta['cabecalhos'] = array_intersect_key( $resposta['cabecalhos'], array_flip( array( 'content-type', 'link', 'x-robots-tag', 'x-f3base-mecanismo', 'cache-control' ) ) );
	file_put_contents( $dir . '/' . $nome . '.json', wp_json_encode( $resposta, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n" );
	file_put_contents( $dir . '/' . $nome . '.txt', $resposta['corpo'] );
}
function f3b_p_config( array $mais = array() ): array {
	f3b_p_visibilidade( '1' );
	$c = array_replace( F3Base_Options::ler( 'f3base_llms' ), array( 'ligado' => true, 'full' => true, 'markdown' => true, 'modo' => 'curada', 'livres' => array(), 'politica_privacidade' => array() ), $mais );
	F3Base_Options::gravar( 'f3base_llms', $c ); return F3Base_Options::ler( 'f3base_llms' );
}
function f3b_p_item( int $id ): array { return array( 'id' => $id, 'url' => get_permalink( $id ), 'titulo' => get_the_title( $id ) ); }
function f3b_p_path( string $url ): string { return (string) wp_parse_url( $url, PHP_URL_PATH ) . ( wp_parse_url( $url, PHP_URL_QUERY ) ? '?' . wp_parse_url( $url, PHP_URL_QUERY ) : '' ); }
function f3b_p_exigir_md( array $r ): void {
	f3b_e_exige( $r['codigo'] === 200 && str_starts_with( $r['cabecalhos']['content-type'] ?? '', 'text/markdown' ), 'Alternativa não respondeu Markdown: ' . wp_json_encode( $r ) );
}
function f3b_p_llms(): array {
	global $wp_rewrite; $estrutura_inicial = get_option( 'permalink_structure' ); $wp_rewrite->set_permalink_structure( '/%postname%/' ); flush_rewrite_rules( false );
	$ids = array();
	foreach ( array( 'publico' => 'publish', 'rascunho' => 'draft', 'privado' => 'private', 'senha' => 'publish', 'noindex' => 'publish' ) as $nome => $status ) {
		$ids[$nome] = wp_insert_post( array( 'post_type' => 'page', 'post_status' => $status, 'post_title' => 'Publicacao ' . $nome, 'post_content' => 'CORPO-' . $nome, 'post_password' => $nome === 'senha' ? 'protecao' : '' ) );
	}
	update_post_meta( $ids['noindex'], F3Base_Modulo_Noindex_Honrado::META_NOINDEX, '1' );
	$livres = array_map( 'f3b_p_item', array_values( $ids ) );
	foreach ( $ids as $nome => $id ) { $livres[] = array( 'id' => 0, 'url' => get_permalink( $id ), 'titulo' => $nome . ' por URL' ); }
	$livres[] = array( 'id' => 0, 'url' => get_permalink( $ids['senha'] ), 'titulo' => 'Senha por URL' );
	$livres[] = array( 'id' => 0, 'url' => get_permalink( $ids['noindex'] ), 'titulo' => 'Noindex por URL' );
	$c = f3b_p_config( array( 'livres' => $livres ) );
	$itens = F3Base_Modulo_Llms_Txt_Reserva::selecao( $c );
	f3b_e_exige( count( $itens ) === 1 && $itens[0]['id'] === $ids['publico'] && $itens[0]['conteudo'] === 'CORPO-publico', 'Curadoria vazou conteúdo protegido ou não hidratou o público: ' . wp_json_encode( $itens ) );
	foreach ( array( '/llms.txt', '/llms-full.txt' ) as $path ) {
		$r = f3b_bancada_get( $path ); f3b_e_exige( $r['codigo'] === 200 && str_contains( $r['cabecalhos']['content-type'] ?? '', 'text/plain' ), 'Arquivo textual não responde: ' . $path );
		foreach ( array( 'rascunho', 'privado', 'senha', 'noindex' ) as $proibido ) { f3b_e_exige( ! str_contains( $r['corpo'], $proibido ), 'Conteúdo excluído no arquivo ' . $path . ': ' . $proibido ); }
	}
	$linha = F3Base_Llms::linha_de_item( array( 'titulo' => "A [B]\n# C", 'url' => 'https://exemplo.test/a(b)', 'descricao' => "Resumo\r\n## falso" ) );
	f3b_e_exige( $linha === '- [A \\[B\\] \\# C](https://exemplo.test/a%28b%29): Resumo \\#\\# falso', 'Metacaracteres quebraram Markdown: ' . $linha );
	foreach ( array( 'javascript:alert(1)', 'https://usuario:senha@exemplo.test/', "https://exemplo.test/a\nX:" ) as $url ) { f3b_e_exige( F3Base_Llms::linha_de_item( array( 'url' => $url ) ) === '', 'URL inválida publicada.' ); }
	$livres = array(); for ( $i = 0; $i < 205; ++$i ) { $livres[] = array( 'url' => 'https://externo.test/item-' . $i, 'titulo' => 'Referência ' . $i ); }
	array_unshift( $livres, $livres[0] ); $c = f3b_p_config( array( 'livres' => $livres, 'introducao' => "Contexto\n## nao e secao" ) );
	f3b_e_exige( count( F3Base_Modulo_Llms_Txt_Reserva::selecao( $c ) ) === 200, 'Teto não inclui curadoria ou dedupe falhou.' );
	$r = f3b_bancada_get( '/llms.txt' ); preg_match_all( '/^# /m', $r['corpo'], $h1 );
	f3b_e_exige( count( $h1[0] ) === 1 && str_contains( $r['corpo'], '> Contexto \\#\\# nao e secao' ), 'Estrutura do índice inválida.' );
	$arquivo = ABSPATH . 'llms-full.txt'; file_put_contents( $arquivo, 'FULL FISICO' );
	try {
		clearstatcache(); f3b_e_exige( ! F3Base_Modulo_Llms_Full_Txt::emissor()['serve'] && F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'], 'Emissor do full não foi medido separadamente.' );
		$r = f3b_bancada_get( '/llms-full.txt' ); f3b_e_exige( trim( $r['corpo'] ) === 'FULL FISICO', 'Arquivo full físico não prevaleceu.' );
	} finally { unlink( $arquivo ); clearstatcache(); }
	f3b_p_visibilidade( '0' );
	try {
		f3b_e_exige( array() === F3Base_Modulo_Llms_Txt_Reserva::selecao( $c ), 'Visibilidade desativada ainda gera seleção.' );
		foreach ( array( '/llms.txt', '/llms-full.txt' ) as $path ) { $r = f3b_bancada_get( $path ); f3b_e_exige( ! str_contains( $r['corpo'], 'externo.test/item-' ), 'Site não público ainda publica o índice.' ); }
	} finally { f3b_p_visibilidade( '1' ); f3b_p_config(); }
	$wp_rewrite->set_permalink_structure( $estrutura_inicial ); flush_rewrite_rules( false );
	return array( 'OK', 'Índice UTF-8 com H1, resumo, links seguros, dedupe/teto; curadoria respeita publicação, senha e noindex; full físico e visibilidade do site conferidos.' );
}
function f3b_p_markdown(): array {
	global $wp_rewrite; $estrutura_inicial = get_option( 'permalink_structure' ); $wp_rewrite->set_permalink_structure( '/%postname%/' ); flush_rewrite_rules( false );
	wp_set_current_user( 1 );
	$conteudo = '<h2>Seção útil</h2><p>Texto <strong>relevante</strong> com <a href="/destino/">referência</a>.</p><ul><li>Primeiro</li><li>Segundo</li></ul><pre><code>a &lt; b\n```</code></pre><form>RUIDO-FORM</form>' . '<' . 'script>RUIDO-SCRIPT</' . 'script><p hidden>RUIDO-OCULTO</p>[f3b_nao_executar]';
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Página editorial', 'post_name' => 'pagina-editorial', 'post_content' => $conteudo ) );
	$c = f3b_p_config( array( 'livres' => array( f3b_p_item( $id ) ) ) );
	$md = F3Base_Llms::markdown( $conteudo, get_permalink( $id ) );
	foreach ( array( '## Seção útil', '**relevante**', '- Primeiro', '- Segundo', '[referência](' . home_url( '/destino/' ) . ')', 'a < b', '````' ) as $termo ) { f3b_e_exige( str_contains( $md, $termo ), 'Conversão perdeu estrutura/conteúdo: ' . $termo . '\n' . $md ); }
	foreach ( array( 'RUIDO-FORM', 'RUIDO-SCRIPT', 'RUIDO-OCULTO' ) as $termo ) { f3b_e_exige( ! str_contains( $md, $termo ), 'Interface vazou para Markdown.' ); }
	add_shortcode( 'f3b_nao_executar', static function () { throw new RuntimeException( 'Shortcode executado na publicação textual.' ); } );
	f3b_e_exige( ! str_contains( F3Base_Llms::markdown( $conteudo, get_permalink( $id ) ), 'f3b_nao_executar' ), 'Shortcode registrado não foi removido.' ); remove_shortcode( 'f3b_nao_executar' );
	$url = F3Base_Modulo_Llms_Markdown::url_do_item( F3Base_Modulo_Llms_Txt_Reserva::selecao( $c )[0] );
	$r = f3b_bancada_get( f3b_p_path( $url ) ); f3b_p_exigir_md( $r );
	f3b_e_exige( str_contains( $r['corpo'], 'Seção útil' ) && str_contains( $r['cabecalhos']['link'] ?? '', 'rel="canonical"' ) && str_contains( $r['cabecalhos']['link'] ?? '', 'rel="describedby"' ) && str_contains( $r['cabecalhos']['x-robots-tag'] ?? '', 'noindex' ), 'Resposta Markdown sem corpo/cabeçalhos declarados.' );
	$head = wp_remote_head( $url ); f3b_e_exige( wp_remote_retrieve_response_code( $head ) === 200 && wp_remote_retrieve_body( $head ) === '', 'HEAD publicou corpo ou falhou.' );
	f3b_p_evidencia( 'pagina-markdown', $r );
	$indice = f3b_bancada_get( '/llms.txt' ); f3b_p_evidencia( 'llms', $indice ); f3b_e_exige( str_contains( $indice['corpo'], '(' . $url . ')' ), 'Índice não anuncia alternativa disponível.' );
	$html = f3b_bancada_get( f3b_p_path( get_permalink( $id ) ) ); $x = f3b_c_dom( $html['corpo'] );
	f3b_e_exige( $x->evaluate( 'string(//link[@rel="alternate" and @type="text/markdown"]/@href)' ) === $url && $x->evaluate( 'string(//link[@rel="describedby"]/@href)' ) === home_url( '/llms.txt' ), 'HTML não anuncia Markdown/llms.' );
	$artigo = wp_insert_post( array( 'post_type' => 'post', 'post_status' => 'publish', 'post_title' => 'Artigo editorial', 'post_name' => 'artigo-editorial', 'post_content' => 'Corpo do artigo' ) );
	$c['livres'][] = f3b_p_item( $artigo ); F3Base_Options::gravar( 'f3base_llms', $c );
	$anterior = get_option( 'permalink_structure' );
	global $wp_rewrite;
	try {
		foreach ( array( '', '/%postname%/', '/%postname%.html' ) as $estrutura ) {
			$wp_rewrite->set_permalink_structure( $estrutura ); flush_rewrite_rules( false );
			foreach ( F3Base_Modulo_Llms_Txt_Reserva::selecao( $c ) as $item ) {
				$url = F3Base_Modulo_Llms_Markdown::url_do_item( $item );
				if ( $estrutura === '/%postname%.html' && $item['id'] === $artigo ) { f3b_e_exige( str_ends_with( $url, '.html.md' ), 'Alternativa com extensão não foi construída.' ); }
				f3b_p_exigir_md( f3b_bancada_get( f3b_p_path( $url ) ) );
			}
		}
	} finally { $wp_rewrite->set_permalink_structure( $anterior ); flush_rewrite_rules( false ); }
	foreach ( array( 'senha', 'noindex', 'desligado', 'site-privado' ) as $restricao ) {
		if ( $restricao === 'senha' ) { wp_update_post( array( 'ID' => $id, 'post_password' => 'restrito' ) ); }
		if ( $restricao === 'noindex' ) { update_post_meta( $id, F3Base_Modulo_Noindex_Honrado::META_NOINDEX, '1' ); }
		if ( $restricao === 'desligado' ) { $c['markdown'] = false; F3Base_Options::gravar( 'f3base_llms', $c ); }
		if ( $restricao === 'site-privado' ) { f3b_p_visibilidade( '0' ); }
		$r = f3b_bancada_get( '/pagina-editorial/index.md' ); f3b_e_exige( ! str_starts_with( $r['cabecalhos']['content-type'] ?? '', 'text/markdown' ), 'Markdown ainda disponível: ' . $restricao );
		wp_update_post( array( 'ID' => $id, 'post_password' => '' ) ); delete_post_meta( $id, F3Base_Modulo_Noindex_Honrado::META_NOINDEX ); f3b_p_visibilidade( '1' ); $c['markdown'] = true; F3Base_Options::gravar( 'f3base_llms', $c );
	}
	$r = f3b_bancada_get( '/inexistente-f3b/index.md' ); f3b_e_exige( $r['codigo'] === 404, 'Alternativa inexistente não retorna 404.' );
	$wp_rewrite->set_permalink_structure( $estrutura_inicial ); flush_rewrite_rules( false );
	return array( 'OK', 'Markdown editorial, links/estrutura, limpeza, sem execução de shortcode, descoberta HTML, cabeçalhos, HEAD, permalinks simples e bonitos, exclusões e 404 conferidos.' );
}
function f3b_p_robots(): array {
	f3b_p_visibilidade( '1' ); F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) );
	$m = new F3Base_Modulo_Robots_Txt();
	$r = f3b_bancada_get( '/robots.txt' );
	f3b_e_exige( $r['codigo'] === 200 && str_contains( $r['cabecalhos']['content-type'] ?? '', 'text/plain' ), 'Robots virtual não responde text/plain: ' . wp_json_encode( array( $r['codigo'], $r['cabecalhos'] ) ) );
	foreach ( array( 'User-agent: *', 'Disallow: /wp-admin/', 'Allow: /wp-admin/admin-ajax.php' ) as $regra ) { f3b_e_exige( str_contains( $r['corpo'], $regra ), 'Regra do núcleo perdida: ' . $regra ); }
	f3b_p_evidencia( 'robots', $r );
	$sitemap = F3Base_Llms::sitemap_medido()['url']; f3b_e_exige( $sitemap !== '' && str_contains( $r['corpo'], 'Sitemap: ' . $sitemap ), 'Sitemap do núcleo não foi descoberto/anunciado.' );
	$s = f3b_bancada_get( f3b_p_path( $sitemap ) ); f3b_e_exige( $s['codigo'] === 200 && str_contains( $s['corpo'], 'sitemapindex' ), 'Sitemap anunciado não responde XML.' );
	$custom = "User-agent: GPTBot\nDisallow: /\n\nUser-agent: *\nDisallow: /busca/\nAllow: /publico/\n";
	$com = $m->complementar( $custom, true );
	f3b_e_exige( str_starts_with( $com, $custom ) && substr_count( $com, 'Sitemap: ' . $sitemap ) === 1 && $m->complementar( $com, true ) === $com, 'Filtro alterou política de bots ou duplicou sitemap.' );
	f3b_e_exige( $m->complementar( $custom, false ) === $custom, 'Filtro alterou resposta de site não público.' );
	$sem = static fn() => false; add_filter( 'wp_sitemaps_enabled', $sem );
	try { f3b_e_exige( $m->complementar( $custom, true ) === $custom && F3Base_Llms::sitemap_medido()['url'] === '', 'Sitemap desligado foi anunciado.' ); } finally { remove_filter( 'wp_sitemaps_enabled', $sem ); }
	$arquivo = ABSPATH . 'robots.txt'; file_put_contents( $arquivo, $custom );
	try { clearstatcache(); f3b_e_exige( $m->complementar( $custom, true ) === $custom && str_contains( ( new F3Base_Modulo_Robots_Txt() )->estado()['motivo'], 'físico' ), 'Arquivo físico sem precedência/diagnóstico.' ); $r = f3b_bancada_get( '/robots.txt' ); f3b_e_exige( $r['corpo'] === $custom, 'Robots físico foi alterado.' ); } finally { unlink( $arquivo ); clearstatcache(); }
	// Núcleo em subpasta: raiz pública é a da home, não a do núcleo.
	$script = $_SERVER['SCRIPT_FILENAME'] ?? ''; $home = get_option( 'home' );
	$siteurl = static fn() => $home . '/nucleo'; add_filter( 'pre_option_siteurl', $siteurl ); $_SERVER['SCRIPT_FILENAME'] = ABSPATH . 'nucleo/wp-admin/index.php';
	file_put_contents( $arquivo, $custom );
	try { f3b_e_exige( F3Base_Llms::arquivo_publico( 'robots.txt' ) === $arquivo, 'Raiz pública calculada incorretamente com núcleo em subpasta.' ); } finally { unlink( $arquivo ); remove_filter( 'pre_option_siteurl', $siteurl ); $_SERVER['SCRIPT_FILENAME'] = $script; clearstatcache(); }
	F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => false ) ); f3b_e_exige( $m->complementar( $custom, true ) === $custom, 'Módulo desligado ainda altera robots.' ); F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) );
	return array( 'OK', 'Robots HTTP UTF-8, regras do núcleo, sitemap real sem duplicação, regras de terceiros intactas, visibilidade, desligamento e precedência física/raiz pública conferidos.' );
}
