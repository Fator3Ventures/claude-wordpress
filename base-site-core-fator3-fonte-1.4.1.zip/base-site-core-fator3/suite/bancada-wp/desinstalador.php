<?php
/**
 * Desinstalação COMO O WORDPRESS A EXECUTA, e não como seria cômodo medi-la.
 *
 * O núcleo roda `uninstall.php` num processo NOVO, com o plugin JÁ DESATIVADO e
 * portanto NÃO CARREGADO, definindo `WP_UNINSTALL_PLUGIN` e incluindo o arquivo.
 * Medir isso de dentro do processo do roteiro — com o plugin ativo — mediria
 * outra coisa: todas as classes que faltam ao `uninstall.php` estariam
 * carregadas, o fatal não aconteceria, e a linha fecharia OK sobre uma
 * desinstalação que quebra em todo site real.
 *
 * O fatal é CAPTURADO e RELATADO, nunca engolido: `register_shutdown_function()`
 * lê o último erro e imprime o veredito que o roteiro lê de volta.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

define( 'WP_USE_THEMES', false );

$f3b_site   = (string) getenv( 'F3BASE_SITE' );
$f3b_plugin = 'base-site-core-fator3/base-site-core-fator3.php';

if ( '' === $f3b_site || ! is_file( $f3b_site . '/wp-load.php' ) ) {
	echo "BANCADA-SEM-WORDPRESS\n";
	exit( 2 );
}

require $f3b_site . '/wp-load.php';

$f3b_arquivo = WP_PLUGIN_DIR . '/base-site-core-fator3/uninstall.php';

if ( ! is_file( $f3b_arquivo ) ) {
	echo "BANCADA-SEM-UNINSTALL\n";
	exit( 2 );
}

register_shutdown_function(
	static function (): void {
		$erro = error_get_last();

		if ( is_array( $erro ) && in_array( (int) $erro['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true ) ) {
			echo "\nBANCADA-FATAL: " . (string) $erro['message'] . ' — ' . (string) $erro['file'] . ':' . (int) $erro['line'] . "\n";
			return;
		}

		echo "\nBANCADA-SEM-FATAL\n";
	}
);

define( 'WP_UNINSTALL_PLUGIN', $f3b_plugin );

include $f3b_arquivo;
