<?php
/** Fixture exclusiva da instalação descartável: simula a opção de visibilidade do núcleo. */
add_filter( 'pre_option_blog_public', static function ( $anterior ) {
	$arquivo = WP_CONTENT_DIR . '/mu-plugins/f3base-publicacao-publico.txt';
	return is_readable( $arquivo ) ? trim( file_get_contents( $arquivo ) ) : $anterior;
} );
add_filter( 'pre_option_wp_page_for_privacy_policy', static function ( $anterior ) {
	$arquivo = WP_CONTENT_DIR . '/mu-plugins/f3base-publicacao-privacidade.txt';
	return is_readable( $arquivo ) ? (int) file_get_contents( $arquivo ) : $anterior;
} );
