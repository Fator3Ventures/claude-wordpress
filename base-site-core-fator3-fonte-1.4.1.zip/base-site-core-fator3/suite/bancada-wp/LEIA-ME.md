# Bancada WordPress real

## O que é

A etapa da suíte que instala o zip do plugin num **WordPress de verdade** e
pergunta ao produto o que ele faz.

Todo o resto do comando único mede o pacote **sem WordPress**: análise da árvore
de arquivos, funções puras exercitadas em subprocesso contra um `wpdb` de
mentira e stubs do núcleo, e o cliente entregue rodado num Chromium. É uma boa
suíte e ela não consegue ver uma classe inteira de defeito — o que só existe
quando o núcleo está carregado:

- `uninstall.php` executado como o WordPress o executa (plugin **inativo**,
  processo novo, `WP_UNINSTALL_PLUGIN` definida);
- a Abilities API do núcleo aceitando ou recusando o registro de uma habilidade;
- o cron de verdade, com a ordem real entre `init` e a ativação de um plugin;
- `dbDelta`, as tabelas próprias e o que sobra delas depois da desinstalação;
- uma rota pública respondendo 500 porque uma função do núcleo estourou;
- um par de redirect que o sanitizador aceita e o navegador não consegue seguir;
- o HTML que o servidor realmente emite, com os cabeçalhos que ele realmente põe.

Cada passo emite **uma linha** com nome `wp.<passo>`, nos mesmos seis estados do
resto da suíte, com a classe de evidência `wp-real` — que existe justamente para
que o relatório não confunda "rodou contra um `wpdb` de mentira" com "rodou
contra o WordPress".

## Pré-condições

| Precisa de | Para quê |
|---|---|
| `php` com `sqlite3`/`pdo_sqlite`, `zip`, `unzip`, `curl` (ou `wget`) | montar e servir a bancada |
| `patch` | aplicar o mutante, no modo piso |
| Cache de insumos, ou rede na primeira vez | núcleo do WordPress, drop-in de SQLite e wp-cli |

Nada é instalado no sistema e nada é gravado no repositório: o WordPress inteiro
nasce em `mktemp -d`, o servidor sobe numa porta livre e **tudo é derrubado ao
final, inclusive em falha e inclusive em interrupção** (`trap`).

Sem cache e sem rede a etapa **não** fecha OK e **não** fecha N/A: ela fecha
`BLOCKED bancada.ambiente` nomeando o recurso que faltou, e cada passo fecha
BLOCKED junto. Ambiente que não pôde medir não aprova pacote.

## Cache

Os insumos moram fora do repositório, em `${F3BASE_BANCADA_CACHE}` — por padrão
`~/.cache/f3base-bancada`:

- `wordpress.zip`
- `sqlite-database-integration.zip`
- `wp-cli.phar`

Semear ou completar o cache:

```bash
# baixando o que faltar
bash suite/bancada-wp/bancada.sh cache

# copiando de uma bancada montada à mão que já tem os arquivos
bash suite/bancada-wp/bancada.sh cache /caminho/da/bancada
```

Para fixar uma versão do núcleo em vez do `latest`, aponte
`F3BASE_BANCADA_WP_URL` para o endereço da versão desejada antes de semear.

## Como rodar

A bancada é **uma etapa do comando único** — normalmente ninguém a chama à mão:

```bash
bash suite/verificar.sh <caminho-do-pacote>     # empacota, checa, e roda a bancada
bash suite/verificar.sh piso <caminho>          # inclui o piso da bancada
F3BASE_SEM_BANCADA=1 bash suite/verificar.sh <caminho>   # pula a etapa: tudo N/A com a condição declarada
```

O interruptor `F3BASE_SEM_BANCADA=1` existe para quem precisa de uma rodada sem
rede. Ele nunca produz OK: cada `wp.*` sai em N/A dizendo que a etapa foi
desligada por quem chamou o comando.

### Rodar um passo só

Direto no roteiro, com o zip que se quer medir:

```bash
bash suite/bancada-wp/bancada.sh rodada dist/base-site-core-fator3-<versao>.zip llms_full_responde
```

Vários passos, na ordem em que forem escritos:

```bash
bash suite/bancada-wp/bancada.sh rodada dist/base-site-core-fator3-<versao>.zip home_servida redirect_nao_gira
```

A saída é uma linha JSON por veredito. Quem imprime estado e conta continua
sendo `estado()`, na suíte — este diretório não conta nada.

## Os arquivos

| Arquivo | Papel |
|---|---|
| `bancada.sh` | monta o WordPress descartável, instala o plugin do zip, sobe o servidor, roda os passos, derruba tudo. Também roda o piso. |
| `roteiro.php` | os passos, um por função, um veredito por execução. Roda por `php`, carregando o `wp-load.php` da bancada. |
| `ativador.php` | ativa o plugin num processo em que ele **nasce inativo** — a única forma de observar a ordem real entre `init` e a ativação. |
| `desinstalador.php` | executa `uninstall.php` como o núcleo o executa, capturando fatal. |
| `roteador.php` | roteador do `php -S`, para que endereço que não é arquivo chegue ao `index.php` e as rotas virtuais existam. |
| `pisos.tsv` | **fonte única**: quais passos existem, em que ordem rodam, qual mutante prova cada um e qual é a situação do piso. |
| `mutantes/*.patch` | os defeitos plantados, em `diff -u` sobre `fontes/plugin/`. |

## Como funciona o piso

O piso de um detector de análise estática é uma árvore de arquivos em
`suite/fixtures/<checagem>/{negativa,positiva}`. O piso de um passo de bancada
não pode ser isso: o caso negativo dele é um **plugin instalado com o defeito
dentro**, num WordPress que sobe e responde.

`bancada.sh piso` faz, para cada passo declarado:

1. **Ramo positivo** — a rodada sobre a fonte como ela está: o passo tem de
   ficar em silêncio sobre o caso correto.
2. **Ramo negativo** — copia `fontes/plugin/` para um temporário, aplica o
   patch do mutante, empacota a árvore mutante num zip instalável, sobe uma
   bancada nova, roda **só aquele passo** e exige o estado adverso.

### Passo cujo defeito ainda mora na fonte

Enquanto o produto ainda carrega o defeito, o mutante negativo **é a própria
fonte** e o ramo positivo não pode existir: montá-lo sobre a fonte defeituosa
mediria o defeito de novo. Esses passos são declarados em `pisos.tsv` com
`(fonte-atual)` na coluna do mutante e `positivo-pendente-de-correcao` na coluna
da situação, com o motivo escrito ao lado.

A declaração é **aceita e não conta como cobertura**:

- `estatica.piso_em_sonda_declarado` a relata como pendência declarada em vez de
  achado — a linha de tabela está dizendo a verdade;
- `f3b_tem_piso()` continua devolvendo falso para esses passos, então
  `armadilhas.mapeadas` continua recusando pendurar uma armadilha neles.

Quando a fonte for corrigida, o passo troca de situação: o patch deixa de ser
`(fonte-atual)` e passa a ser o que **reintroduz** o defeito corrigido, e os dois
ramos passam a fechar.

## Como escrever um mutante

1. Copie a fonte para dois diretórios irmãos e edite só o segundo:

   ```bash
   cd "$(mktemp -d)"
   cp -r <repo>/fontes/plugin a
   cp -r a b
   # edite b/ plantando UM defeito, o menor possível
   diff -ruN a b > <repo>/suite/bancada-wp/mutantes/<passo>.patch
   ```

2. Declare-o em `pisos.tsv`, na linha do passo: caminho do patch na coluna do
   mutante, `coberto` na situação, e na última coluna **o que ele planta** — não
   "quebra o passo", mas o defeito concreto, na linguagem de quem opera o site.

3. Prove os dois ramos:

   ```bash
   bash suite/verificar.sh piso <caminho-do-pacote>
   ```

Regras que valem para todo mutante:

- **Um defeito por patch.** Dois defeitos no mesmo patch fazem o ramo negativo
  fechar sem que se saiba qual deles o passo acusou.
- **Defeito real, não sabotagem.** Erro de sintaxe reprova qualquer coisa e não
  prova nada sobre o passo. O que se planta é o que já aconteceu, ou o que
  aconteceria numa edição plausível: um cabeçalho retirado da lista, um aviso
  que passa a ser emitido, um gancho trocado.
- **O patch aplica com `patch -p1` de dentro da árvore do plugin.** É por isso
  que o `diff` é feito entre `a/` e `b/`.

## O que esta bancada não mede

- **Multisite**, e é uma ausência conhecida: a desinstalação num único site é o
  que se observa aqui.
- **MySQL.** O banco é SQLite pelo drop-in; diferenças de `dbDelta` entre os
  dois motores ficam fora do alcance desta etapa.
- **HTTPS.** O servidor embutido é HTTP, então o que depende de `is_ssl()` — o
  HSTS, por exemplo — não é exercitado aqui.
- **Navegador.** Quem mede o cliente é `navegador.comportamento_real`, com um
  Chromium; esta etapa mede o servidor.
