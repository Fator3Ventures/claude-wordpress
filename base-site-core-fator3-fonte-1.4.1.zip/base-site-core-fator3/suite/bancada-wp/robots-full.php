<?php
/** Troca reversível de robots e conteúdo integral, com WordPress e HTTP reais. */
declare( strict_types = 1 );
function f3b_rf_reler(): array {
	foreach ( array( 'f3base_robots', F3Base_Robots_Arquivo::OPTION, 'alloptions', 'notoptions' ) as $key ) { wp_cache_delete( $key, 'options' ); }
	clearstatcache();
	return F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION );
}
function f3b_rf_limpar(): void {
	// Esta raiz pertence exclusivamente ao WordPress descartável criado pela bancada.
	foreach ( glob( ABSPATH . '.f3base-robots-*.bak' ) ?: array() as $r ) { unlink( $r ); }
	if ( is_file( ABSPATH . 'robots.txt' ) || is_link( ABSPATH . 'robots.txt' ) ) { unlink( ABSPATH . 'robots.txt' ); }
	F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, array() );
	F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => false ) );
	f3b_rf_reler();
}
function f3b_rf_ligar( bool $ligado ): void {
	$r = F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => $ligado ) );
	f3b_e_exige( ! empty( $r['ok'] ), 'Troca falhou: ' . $r['motivo'] );
	f3b_rf_reler();
}
function f3b_rf_admin( bool $ligado ): void {
	$login = wp_remote_post( f3b_bancada_url( '/wp-login.php' ), array( 'redirection' => 0, 'body' => array( 'log' => 'admin', 'pwd' => 'admin' ) ) );
	$cookies = wp_remote_retrieve_cookies( $login );
	$r = wp_remote_get( f3b_bancada_url( '/wp-admin/admin.php?page=base-site-core-fator3' ), array( 'cookies' => $cookies, 'timeout' => 20 ) );
	$x = f3b_c_dom( wp_remote_retrieve_body( $r ) );
	$nonce = $x->evaluate( 'string(//form[@class="f3base-form"]//input[@name="_wpnonce"]/@value)' );
	$action = $x->evaluate( 'string(//form[@class="f3base-form"]//input[@name="action"]/@value)' );
	f3b_e_exige( $nonce !== '' && $action !== '', 'Formulário de configuração ausente.' );
	$r = wp_remote_post( f3b_bancada_url( '/wp-admin/admin-post.php' ), array( 'cookies' => $cookies, 'timeout' => 20, 'redirection' => 0, 'body' => array( 'action' => $action, '_wpnonce' => $nonce, 'f3base' => array( 'f3base_robots' => array( 'ligado' => $ligado ? '1' : '0' ) ) ) ) );
	f3b_e_exige( wp_remote_retrieve_response_code( $r ) === 302, 'Gravação administrativa falhou.' );
	f3b_rf_reler();
}
function f3b_rf_troca(): array {
	f3b_p_visibilidade( '1' ); f3b_rf_limpar(); $alvo = ABSPATH . 'robots.txt';
	$original = "\xEF\xBB\xBF# Original exato — não importar no virtual\r\nUser-agent: BotOriginal\r\nDisallow: /restricao-original/\r\n\r\nSitemap: https://exemplo.test/original.xml\r\n";
	try {
		file_put_contents( $alvo, $original ); chmod( $alvo, 0640 );
		f3b_rf_admin( true ); $e = f3b_rf_reler();
		f3b_e_exige( ! file_exists( $alvo ) && $e['original_existe'] && base64_decode( $e['conteudo_base64'], true ) === $original && $e['sha256'] === hash( 'sha256', $original ) && is_file( ABSPATH . $e['reserva'] ), 'Original não foi guardado integralmente antes de retirar o nome público.' );
		global $wpdb; $autoload = $wpdb->get_var( $wpdb->prepare( "SELECT autoload FROM {$wpdb->options} WHERE option_name = %s", F3Base_Robots_Arquivo::OPTION ) );
		f3b_e_exige( in_array( $autoload, array( 'no', 'off', 'auto-off' ), true ), 'Backup carrega em autoload.' );
		$r = f3b_bancada_get( '/robots.txt' );
		f3b_e_exige( $r['codigo'] === 200 && str_starts_with( $r['cabecalhos']['content-type'] ?? '', 'text/plain' ) && str_contains( $r['corpo'], 'Disallow: /wp-admin/' ) && str_contains( $r['corpo'], 'Sitemap: ' . F3Base_Llms::sitemap_medido()['url'] ) && ! str_contains( $r['corpo'], 'restricao-original' ), 'Robots do plugin não assumiu a resposta HTTP.' );
		$head = wp_remote_head( home_url( '/robots.txt' ) ); f3b_e_exige( wp_remote_retrieve_response_code( $head ) === 200 && wp_remote_retrieve_body( $head ) === '', 'HEAD do robots falhou.' );
		f3b_p_evidencia( 'robots-troca-virtual', $r );
		f3b_rf_admin( false );
		f3b_e_exige( file_get_contents( $alvo ) === $original && ( fileperms( $alvo ) & 0777 ) === 0640, 'Desligar não restaurou bytes e permissões.' );
		f3b_e_exige( f3b_bancada_get( '/robots.txt' )['corpo'] === $original, 'Servidor não voltou a entregar o original.' );
		f3b_rf_ligar( true ); f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $original, 'Ciclo repetido alterou o original.' );
		f3b_rf_ligar( true ); $novo = "# Arquivo novo\nUser-agent: *\nDisallow: /novo/\n"; file_put_contents( $alvo, $novo );
		$r = F3Base_Robots_Arquivo::sincronizar(); f3b_e_exige( ! $r['ok'] && file_get_contents( $alvo ) === $novo, 'Conflito externo não foi preservado.' );
		f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $novo, 'Desligar sobrescreveu um arquivo criado por terceiro.' );
		f3b_rf_ligar( true ); f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $novo, 'Novo ciclo não adotou o novo original.' );
		f3b_rf_ligar( true ); $e = f3b_rf_reler(); unlink( ABSPATH . $e['reserva'] );
		f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $novo, 'Restauração a partir do banco falhou quando a reserva sumiu.' );
		f3b_rf_limpar(); f3b_rf_ligar( true ); f3b_rf_ligar( false ); f3b_e_exige( ! file_exists( $alvo ), 'Foi inventado um original que nunca existiu.' );
	} finally { f3b_rf_limpar(); f3b_rf_ligar( true ); }
	return array( 'OK', 'Formulário real, backup exato sem autoload, troca GET/HEAD, restauração de bytes/permissões, repetição, conflito externo, recuperação pelo banco e ausência de original conferidos.' );
}
function f3b_rf_falhas(): array {
	f3b_rf_limpar(); $alvo = ABSPATH . 'robots.txt'; $original = "User-agent: *\nDisallow: /original/\n";
	try {
		file_put_contents( $alvo, $original );
		foreach ( array( 'rename', 'link' ) as $funcao ) {
			$p = proc_open( array( PHP_BINARY, '-d', 'disable_functions=' . $funcao, __DIR__ . '/sonda-robots.php', ABSPATH, 'recusa' ), array( 1 => array( 'pipe', 'w' ), 2 => array( 'pipe', 'w' ) ), $pipes );
			f3b_e_exige( is_resource( $p ), 'Não foi possível iniciar a sonda de função indisponível.' );
			$saida = stream_get_contents( $pipes[1] ); $erro = stream_get_contents( $pipes[2] ); fclose( $pipes[1] ); fclose( $pipes[2] ); $codigo = proc_close( $p ); $r = json_decode( $saida, true );
			f3b_e_exige( $codigo === 0 && $erro === '' && is_array( $r ) && ! $r['ok'] && file_get_contents( $alvo ) === $original, 'Função indisponível não preservou o original: ' . $funcao . ' ' . $saida . $erro );
			f3b_rf_reler(); f3b_rf_ligar( false );
		}
		// Recusa especificamente o backup anterior ao rename, sem barrar apenas a gravação inicial do ciclo.
		$falhar = static fn( $novo, $anterior ) => 'preparado' === ( $novo['etapa'] ?? '' ) ? $anterior : $novo; add_filter( 'pre_update_option_f3base_robots_backup', $falhar, 10, 2 );
		try { $r = F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) ); f3b_e_exige( ! $r['ok'] && file_get_contents( $alvo ) === $original, 'Backup recusado no banco ainda retirou o original.' ); }
		finally { remove_filter( 'pre_update_option_f3base_robots_backup', $falhar ); }
		f3b_rf_ligar( true ); $bom = f3b_rf_reler(); $ruim = $bom; $ruim['sha256'] = str_repeat( '0', 64 ); F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $ruim );
		$r = F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => false ) ); f3b_e_exige( ! $r['ok'] && ! file_exists( $alvo ) && is_file( ABSPATH . $bom['reserva'] ), 'Backup inválido foi publicado ou descartado.' );
		F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $bom ); f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $original, 'Correção do checksum não permitiu recuperar o original.' );
		f3b_rf_limpar(); $externo = ABSPATH . 'robots-fixture.txt'; file_put_contents( $externo, $original ); symlink( $externo, $alvo );
		$r = F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) ); f3b_e_exige( ! $r['ok'] && is_link( $alvo ) && file_get_contents( $externo ) === $original, 'Link simbólico foi removido ou alterado.' ); unlink( $alvo ); unlink( $externo );
		f3b_rf_limpar(); $grande = str_repeat( '#', F3Base_Robots_Arquivo::MAX_BYTES + 1 ); file_put_contents( $alvo, $grande );
		$r = F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => true ) ); f3b_e_exige( ! $r['ok'] && file_get_contents( $alvo ) === $grande, 'Arquivo acima do limite foi truncado ou retirado.' );
		f3b_rf_limpar(); file_put_contents( $alvo, $original ); f3b_rf_ligar( true ); $e = f3b_rf_reler();
		// Simula uma interrupção após o rename, com mudança externa entre a leitura e o rename.
		$alterado = $original . '# edição capturada na reserva'; file_put_contents( ABSPATH . $e['reserva'], $alterado ); $e['etapa'] = 'preparado'; F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $e );
		$r = F3Base_Robots_Arquivo::sincronizar(); f3b_e_exige( $r['ok'], 'Interrupção após rename não foi recuperada.' ); f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $alterado, 'Recuperação perdeu a edição existente na reserva.' );
		f3b_rf_ligar( true ); $e = f3b_rf_reler(); file_put_contents( ABSPATH . $e['reserva'], $grande ); $e['etapa'] = 'preparado'; F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $e );
		$r = F3Base_Robots_Arquivo::sincronizar(); f3b_e_exige( ! $r['ok'] && file_get_contents( $alvo ) === $grande, 'Reserva que cresceu além do limite não foi devolvida ao caminho público.' );
		f3b_rf_limpar(); file_put_contents( $alvo, $original ); f3b_rf_ligar( true ); $e = f3b_rf_reler(); $e['caminho'] = '/outra-raiz/robots.txt'; F3Base_Options::gravar( F3Base_Robots_Arquivo::OPTION, $e );
		$r = F3Base_Options::gravar( 'f3base_robots', array( 'ligado' => false ) ); f3b_e_exige( ! $r['ok'] && ! file_exists( $alvo ), 'Backup de outra raiz foi restaurado.' );
	} finally { f3b_rf_limpar(); f3b_rf_ligar( true ); }
	return array( 'OK', 'Falha de banco, checksum inválido, symlink, limite de tamanho, interrupção do rename, alteração externa e backup de outra raiz preservam os arquivos.' );
}
function f3b_rf_ciclo(): array {
	f3b_rf_limpar(); $alvo = ABSPATH . 'robots.txt'; $original = "User-agent: *\nDisallow: /ciclo/\n"; $plugin = 'base-site-core-fator3/base-site-core-fator3.php';
	try {
		file_put_contents( $alvo, $original );
		$dir = getenv( 'F3BASE_BANCADA_TMP' ) . '/robots-concorrencia'; mkdir( $dir ); $processos = array();
		for ( $i = 0; $i < 2; ++$i ) {
			$p = proc_open( array( PHP_BINARY, __DIR__ . '/sonda-robots.php', ABSPATH, $dir, (string) $i ), array( 1 => array( 'pipe', 'w' ), 2 => array( 'pipe', 'w' ) ), $pipes );
			f3b_e_exige( is_resource( $p ), 'Não foi possível iniciar concorrência real.' ); $processos[] = array( $p, $pipes );
		}
		$limite = microtime( true ) + 15;
		while ( ( ! is_file( $dir . '/pronto-0' ) || ! is_file( $dir . '/pronto-1' ) ) && microtime( true ) < $limite ) { usleep( 10000 ); }
		file_put_contents( $dir . '/iniciar', '1' );
		foreach ( $processos as [ $p, $pipes ] ) { $saida = stream_get_contents( $pipes[1] ); $erro = stream_get_contents( $pipes[2] ); fclose( $pipes[1] ); fclose( $pipes[2] ); $codigo = proc_close( $p ); f3b_e_exige( $codigo === 0 && $erro === '' && is_array( json_decode( $saida, true ) ), 'Processo concorrente falhou: ' . $saida . $erro ); }
		f3b_rf_reler(); $r = F3Base_Robots_Arquivo::sincronizar(); $e = f3b_rf_reler();
		f3b_e_exige( $r['ok'] && ! file_exists( $alvo ) && base64_decode( $e['conteudo_base64'], true ) === $original && count( glob( ABSPATH . '.f3base-robots-*.bak' ) ) === 1, 'Concorrência perdeu ou duplicou o original.' );
		deactivate_plugins( $plugin ); $e = f3b_rf_reler(); f3b_e_exige( $e['suspenso'] && file_get_contents( $alvo ) === $original, 'Desativar o plugin não restaurou o original.' );
		F3Base_Robots_Arquivo::sincronizar(); f3b_e_exige( file_get_contents( $alvo ) === $original, 'Requisição antiga desfez a restauração após desativação.' );
		$r = activate_plugin( $plugin ); f3b_e_exige( ! is_wp_error( $r ), 'Plugin não reativou.' ); $e = f3b_rf_reler(); f3b_e_exige( ! $e['suspenso'] && ! file_exists( $alvo ), 'Reativação não retomou a opção ligada.' );
		f3b_rf_ligar( false ); f3b_e_exige( file_get_contents( $alvo ) === $original, 'Restauração após reativação divergiu.' );
	} finally { if ( ! is_plugin_active( $plugin ) ) { activate_plugin( $plugin ); } f3b_rf_limpar(); f3b_rf_ligar( true ); }
	return array( 'OK', 'Dois processos com cache pré-carregado preservam uma única cópia; desativação restaura, requisição antiga respeita suspensão e reativação retoma o gerador.' );
}
function f3b_rf_full(): array {
	wp_set_current_user( 1 );
	$codigo = "a < b\n\n\n```\ncaminho\\arquivo\n";
	$corpo = '<h1>Título interno</h1><h2>Seção integral</h2><h3>Detalhe</h3><p>Texto <strong>importante</strong> com <a href="/referencia/">referência</a>.</p><ul><li>Primeiro</li><li>Segundo</li></ul><pre><code>' . htmlspecialchars( $codigo, ENT_NOQUOTES, 'UTF-8' ) . '</code></pre><form>RUIDO-FULL-FORM</form><p hidden>RUIDO-FULL-OCULTO</p>' . str_repeat( '<p>Parágrafo longo com conteúdo que deve permanecer integral.</p>', 120 ) . '<p>MARCADOR-FINAL-INTEGRAL</p>';
	$id = wp_insert_post( wp_slash( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Guia [integral]', 'post_content' => $corpo ) ) );
	$c = f3b_p_config( array( 'livres' => array( f3b_p_item( $id ) ), 'markdown' => false ) );
	$r = f3b_bancada_get( '/llms-full.txt' );
	f3b_e_exige( $r['codigo'] === 200 && str_starts_with( $r['cabecalhos']['content-type'] ?? '', 'text/plain' ) && str_contains( strtolower( $r['cabecalhos']['content-type'] ), 'utf-8' ) && str_contains( $r['cabecalhos']['link'] ?? '', 'rel="describedby"' ), 'Full sem cabeçalhos e descoberta esperados.' );
	foreach ( array( '## Guia \\[integral\\]', '### Título interno', '### Seção integral', '#### Detalhe', '**importante**', '- Primeiro', '- Segundo', '[referência](' . home_url( '/referencia/' ) . ')', "````\n" . rtrim( $codigo, "\n" ) . "\n````", 'MARCADOR-FINAL-INTEGRAL' ) as $texto ) { f3b_e_exige( str_contains( $r['corpo'], $texto ), 'Full perdeu estrutura ou texto: ' . $texto . '\n' . $r['corpo'] ); }
	f3b_e_exige( substr_count( $r['corpo'], 'Parágrafo longo com conteúdo' ) === 120 && ! str_contains( $r['corpo'], 'RUIDO-FULL' ), 'Full resumiu o corpo ou publicou interface oculta.' );
	preg_match_all( '/^# /m', $r['corpo'], $h1 ); f3b_e_exige( count( $h1[0] ) === 1, 'Full possui mais de um título principal.' );
	$head = wp_remote_head( home_url( '/llms-full.txt' ) ); f3b_e_exige( wp_remote_retrieve_response_code( $head ) === 200 && wp_remote_retrieve_body( $head ) === '', 'HEAD do full falhou.' );
	$post = wp_remote_post( home_url( '/llms-full.txt' ) ); f3b_e_exige( ! str_contains( wp_remote_retrieve_body( $post ), 'MARCADOR-FINAL-INTEGRAL' ), 'Full respondeu conteúdo a POST.' );
	f3b_p_evidencia( 'llms-full-estruturado', $r );
	foreach ( array( 'senha', 'noindex', 'exclusao', 'site-privado', 'full-desligado' ) as $regra ) {
		if ( $regra === 'senha' ) { wp_update_post( array( 'ID' => $id, 'post_password' => 'restrito' ) ); }
		if ( $regra === 'noindex' ) { update_post_meta( $id, F3Base_Modulo_Noindex_Honrado::META_NOINDEX, '1' ); }
		if ( $regra === 'exclusao' ) { file_put_contents( WP_CONTENT_DIR . '/mu-plugins/f3base-publicacao-privacidade.txt', (string) $id ); }
		if ( $regra === 'site-privado' ) { f3b_p_visibilidade( '0' ); }
		if ( $regra === 'full-desligado' ) { $c['full'] = false; F3Base_Options::gravar( 'f3base_llms', $c ); }
		$f = f3b_bancada_get( '/llms-full.txt' ); f3b_e_exige( ! str_contains( $f['corpo'], 'MARCADOR-FINAL-INTEGRAL' ), 'Full ignorou regra: ' . $regra );
		wp_update_post( array( 'ID' => $id, 'post_password' => '' ) ); delete_post_meta( $id, F3Base_Modulo_Noindex_Honrado::META_NOINDEX ); if ( is_file( WP_CONTENT_DIR . '/mu-plugins/f3base-publicacao-privacidade.txt' ) ) { unlink( WP_CONTENT_DIR . '/mu-plugins/f3base-publicacao-privacidade.txt' ); } f3b_p_visibilidade( '1' ); $c['full'] = true; F3Base_Options::gravar( 'f3base_llms', $c );
	}
	return array( 'OK', 'Full conserva corpo extenso, hierarquia, listas, links e código; limpa interface, respeita seleção/exclusões, GET/HEAD e funciona com Markdown por página desligado.' );
}
