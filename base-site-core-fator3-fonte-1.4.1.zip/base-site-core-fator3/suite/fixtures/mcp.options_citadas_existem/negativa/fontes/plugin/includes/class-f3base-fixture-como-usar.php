<?php
/**
 * O manual da fixture, com o defeito plantado: ele cita uma option que não existe.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Manual do agente.
 */
final class F3Base_Fixture_Como_Usar {

	/**
	 * O que NÃO fazer, com o caminho certo.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function nao_faca(): array {
		return array(
			array(
				'nao'    => 'Não instale plugin de consentimento por fora.',
				'porque' => 'Dois controladores criam dois estados para o mesmo visitante.',
				'faca'   => 'Ajuste a option f3base_consentimento.',
			),
			array(
				'nao'    => 'Não injete tag de medição pelo tema.',
				'porque' => 'Dois emissores contam a mesma conversão duas vezes.',
				'faca'   => 'Grave o ID na option f3base_tracking.',
			),
		);
	}
}
