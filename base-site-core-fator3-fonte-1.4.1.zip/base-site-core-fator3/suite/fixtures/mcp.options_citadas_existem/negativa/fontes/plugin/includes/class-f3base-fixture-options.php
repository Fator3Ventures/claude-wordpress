<?php
/**
 * Catálogo de options da fixture: a âncora contra a qual o manual é cruzado.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Gravador único da fixture.
 */
final class F3Base_Fixture_Options {

	/**
	 * Option de procedência: âncora publicada fora do catálogo.
	 */
	public const OPTION_PROVENIENCIA = 'f3base_proveniencia';

	/**
	 * O catálogo declarado.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function catalogo(): array {
		$catalogo = array(
			'f3base_consentimento' => array(
				'rotulo'   => 'Consentimento',
				'operavel' => true,
				'campo'    => 'grupo',
				'padrao'   => array(),
			),
			'f3base_cabecalhos'    => array(
				'rotulo'   => 'Cabeçalhos de resposta',
				'operavel' => false,
				'campo'    => 'grupo',
				'padrao'   => array(),
			),
		);

		return $catalogo;
	}
}
