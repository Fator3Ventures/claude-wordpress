<?php
/**
 * O manual da fixture, correto: toda option citada existe no catálogo.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Manual do agente.
 */
final class F3Base_Fixture_Como_Usar {

	/**
	 * O que NÃO fazer, com o caminho certo.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function nao_faca(): array {
		return array(
			array(
				'nao'    => 'Não instale plugin de consentimento por fora.',
				'porque' => 'Dois controladores criam dois estados para o mesmo visitante.',
				'faca'   => 'Ajuste a option f3base_consentimento.',
			),
			array(
				'nao'    => 'Não escreva cabeçalhos de segurança por .htaccess.',
				'porque' => 'Cabeçalho duplicado tem resultado dependente do servidor.',
				'faca'   => 'Ajuste a option f3base_cabecalhos; a procedência dela fica em f3base_proveniencia.',
			),
		);
	}
}
