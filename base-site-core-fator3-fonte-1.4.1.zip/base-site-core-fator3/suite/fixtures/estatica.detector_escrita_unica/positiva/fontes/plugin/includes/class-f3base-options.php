<?php
/**
 * Fixture POSITIVA: o gravador declarado é o único que escreve. Ele PODE.
 *
 * O ARQUIVO MUDOU DE CAMINHO, e é o mesmo motivo do repositório: o gravador
 * declarado passou a ser um só — o do PLUGIN, em
 * `fontes/plugin/includes/class-f3base-options.php` —, porque o do implantador
 * ficou no repositório dele. Uma fixture que declarasse o gravador num caminho
 * que a checagem não isenta mais estaria medindo outra coisa.
 */
declare( strict_types = 1 );

final class F3Base_Options {

	public static function gravar( string $nome, $valor ): bool {
		return update_option( $nome, $valor, false );
	}
}
