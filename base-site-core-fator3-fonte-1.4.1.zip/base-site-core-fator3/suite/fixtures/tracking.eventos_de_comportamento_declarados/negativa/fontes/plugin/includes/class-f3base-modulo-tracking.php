<?php
/**
 * Fixture negativa: o módulo NÃO lê a declaração.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

final class F3Base_Modulo_Tracking {

	/**
	 * Slots de medição, sem nenhum consumidor da declaração de comportamento.
	 *
	 * @return array<string,string>
	 */
	public static function ids(): array {
		return array();
	}
}
