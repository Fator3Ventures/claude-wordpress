<?php
/**
 * Fixture: só o DDL de que o detector precisa.
 *
 * O comprimento do nome de evento NÃO é digitado dentro do detector: ele é lido
 * da coluna que guarda o nome. É por isso que a fixture precisa trazer a
 * declaração da tabela — sem ela, a regra não teria de onde tirar o número e
 * ficaria em silêncio nos dois ramos.
 */

declare( strict_types = 1 );

final class F3Base_Fixture_Comportamento {

	/**
	 * A tabela do resumo, como o módulo a declara.
	 *
	 * @return string
	 */
	public static function ddl(): string {
		return 'CREATE TABLE fixture_comportamento (
	chave char(64) NOT NULL,
	dia char(10) NOT NULL,
	caminho varchar(190) NOT NULL,
	metrica varchar(64) NOT NULL,
	detalhe varchar(60) NOT NULL DEFAULT \'\',
	PRIMARY KEY  (chave)
)';
	}
}
