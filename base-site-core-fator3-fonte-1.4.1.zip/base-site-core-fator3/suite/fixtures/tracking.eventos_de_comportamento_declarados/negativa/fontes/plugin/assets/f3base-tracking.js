(function (window) {
	'use strict';

	/* O DEFEITO: o nome do evento e o do parâmetro escritos aqui, ao lado da
	   declaração que já os tem. Duas fontes de verdade sobre a mesma série. */
	function emitirErro(arquivo) {
		window.dataLayer.push({
			event: 'fixture_erro',
			fixture_arquivo: arquivo
		});
	}

	/* O SEGUNDO DEFEITO: a reserva do limiar não é o número declarado. Zero
	   REMOVE a banda da fronteira, e é a reserva menos conservadora possível —
	   ela vale justamente no dia em que a declaração chega truncada. */
	function medirRolagem() {
		var GATILHO = 'rolagem';

		return numeroDoLimiar(GATILHO, 'histerese_pp', 0);
	}

	function numeroDoLimiar(gatilho, chave, reserva) {
		return reserva;
	}

	window.fixture = { emitirErro: emitirErro, medirRolagem: medirRolagem };
}(window));
