(function (window) {
	'use strict';

	var EVENTOS = window.fixtureDados && window.fixtureDados.eventos ? window.fixtureDados.eventos : {};
	var medidos = { LCP: null, TTFB: null };

	/* O nome vem da declaração, encontrado pelo GATILHO. O cliente não o escreve. */
	function declaracao(gatilho) {
		var nome;

		for (nome in EVENTOS) {
			if (Object.prototype.hasOwnProperty.call(EVENTOS, nome) && EVENTOS[nome].gatilho === gatilho) {
				return { nome: nome, dados: EVENTOS[nome] };
			}
		}

		return null;
	}

	function numeroDoLimiar(gatilho, chave, reserva) {
		var d = declaracao(gatilho);
		var lista = d && d.dados.limiar && d.dados.limiar[chave];
		var valor = lista ? parseFloat(lista[0]) : NaN;

		return isNaN(valor) ? reserva : valor;
	}

	/* A reserva é o MESMO número da declaração: no dia em que o arquivo chega
	   truncado, os dois lados continuam medindo a mesma coisa. */
	function medirRolagem() {
		var GATILHO = 'rolagem';

		return numeroDoLimiar(GATILHO, 'histerese_pp', 5);
	}

	function emitir(gatilho, valores) {
		var d = declaracao(gatilho);
		var objeto = {};
		var i;

		if (!d) {
			return false;
		}

		objeto.event = d.nome;

		for (i = 0; i < d.dados.parametros.length && i < valores.length; i++) {
			objeto[d.dados.parametros[i]] = valores[i];
		}

		window.dataLayer.push(objeto);

		return true;
	}

	window.fixture = { emitir: emitir, medidos: medidos, medirRolagem: medirRolagem };
}(window));
