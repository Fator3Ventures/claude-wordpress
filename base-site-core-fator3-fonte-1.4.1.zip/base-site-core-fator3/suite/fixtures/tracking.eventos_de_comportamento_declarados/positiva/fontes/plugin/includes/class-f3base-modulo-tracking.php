<?php
/**
 * Fixture positiva: o módulo LÊ a declaração e a publica ao navegador.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

final class F3Base_Modulo_Tracking {

	/**
	 * Arquivo da declaração única dos eventos de comportamento.
	 */
	public const ARQUIVO_EVENTOS = 'dados/eventos-comportamento.tsv';

	/**
	 * A declaração, lida do arquivo único.
	 *
	 * @return array<string,mixed>
	 */
	public static function comportamento(): array {
		return array( 'arquivo' => self::ARQUIVO_EVENTOS );
	}
}
