<!-- gerado:inicio=carimbo -->
# Base Site Core Fator3 9.9.0 — leia-me do operador

> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip ser
> montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número destes documentos
> é digitado à mão: número digitado está certo no dia em que foi escrito e é contradito pela rodada
> seguinte, sem nada acusando. O que não pode ser medido no momento da escrita sai como pendência
> nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `9.9.0` |
| Pasta instalada | `base-site-core-fator3` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Plataforma declarada no cabeçalho | `EXIGE PHP DE 64 BITS` |
| Escopo de instalação declarado no cabeçalho | `INSTALACAO UNICA, NAO MULTISITE` |
| Arquivos na fonte do plugin | 2 |
| Arquivos vindos de `partilhado/` | 0 |
| Arquivos no repositório (fora de `dist/` e dos produtos da rodada) | 11 |
| Checagens declaradas por classe de evidência | `analise-estatica/build` 2 |
| Detectores com piso em disco | 0 |
| Ramos de piso em disco (negativa + positiva) | 0 |
| Passos da bancada WordPress com mutante declarado | 1 |
| Checagens com piso declarado em sonda | 1 |
| Artefato publicado | `base-site-core-fator3-9.9.0.zip` |
| Época declarada de cada entrada do zip | `1980-01-01 00:00:00 UTC` |
<!-- gerado:fim=carimbo -->

Prosa do leia-me, que o gerador não toca e que não traz número digitado.

<!-- gerado:inicio=arvore -->
### Árvore do repositório

Gerada de `suite/inventario.tsv`, que é a allow-list executável do empacotamento: arquivo em disco fora
dela **aborta o build com o nome**. Diretório declarado como prefixo sai como um nó só, porque é assim
que ele está declarado. O papel de cada caminho sai aqui até o primeiro ponto final; ele está inteiro
no inventário de `MANIFESTO.md`.

```
base-site-core-fator3/
  MANIFESTO.md   — MANIFESTO desta árvore de piso
  MEMORIA-DECISOES.md   — MEMÓRIA desta árvore de piso
  README.md   — LEIA-ME DO OPERADOR desta árvore de piso
  fontes/
    plugin/
      INSTRUCOES-DO-PLUGIN.md   — INSTRUÇÕES DO PLUGIN desta árvore de piso
      base-site-core-fator3.php   — Arquivo principal do plugin desta árvore de piso
  suite/   — A SUÍTE desta árvore de piso
```
<!-- gerado:fim=arvore -->
