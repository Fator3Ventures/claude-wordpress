<!-- gerado:inicio=carimbo -->
# Memória de decisões — Base Site Core Fator3 9.9.0

> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip ser
> montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número destes documentos
> é digitado à mão: número digitado está certo no dia em que foi escrito e é contradito pela rodada
> seguinte, sem nada acusando. O que não pode ser medido no momento da escrita sai como pendência
> nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `9.9.0` |
| Pasta instalada | `base-site-core-fator3` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Plataforma declarada no cabeçalho | `EXIGE PHP DE 64 BITS` |
| Escopo de instalação declarado no cabeçalho | `INSTALACAO UNICA, NAO MULTISITE` |
| Arquivos na fonte do plugin | 2 |
| Arquivos vindos de `partilhado/` | 0 |
| Arquivos no repositório (fora de `dist/` e dos produtos da rodada) | 11 |
| Checagens declaradas por classe de evidência | `analise-estatica/build` 2 |
| Detectores com piso em disco | 0 |
| Ramos de piso em disco (negativa + positiva) | 0 |
| Passos da bancada WordPress com mutante declarado | 1 |
| Checagens com piso declarado em sonda | 1 |
| Artefato publicado | `base-site-core-fator3-9.9.0.zip` |
| Época declarada de cada entrada do zip | `1980-01-01 00:00:00 UTC` |
<!-- gerado:fim=carimbo -->

Prosa da memória, que o gerador não toca.

<!-- gerado:inicio=contagem -->
> Este bloco é **gerado** pela leitura deste próprio arquivo: as decisões são contadas a partir dos
> títulos que existem nele, e não de um número escrito ao lado. Uma memória que declara quantas
> decisões tem e conta outra coisa é a primeira frase que alguém confere e a última em que confia.

| Fato medido | Valor |
|---|---|
| Decisões nesta memória | 2 |
| Herdadas do implantador, transcritas verbatim | 1 |
| Nascidas nesta release | 1 |
| Herdadas com nota de superação | 1 |
<!-- gerado:fim=contagem -->

## Parte I — decisões herdadas, transcritas

<!-- transcrito:inicio -->

## 1. Decisão herdada de piso (origem: implantador 1.7.4, decisão nº 9)

**Decidido.** Texto transcrito palavra por palavra, com os números de história que a regra
não varre: a rodada da referência emitiu 224 linhas e o prazo era de 12 h.

> **Superada na 9.9.0** — ver decisão nº 2.

<!-- transcrito:fim -->

## Parte II — as decisões desta release

## 2. Decisão desta release, sem número digitado na prosa

**Decidido.** Prosa nossa, varrida pela regra do número como qualquer outra linha.
