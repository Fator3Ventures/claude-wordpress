<?php
/**
 * FORMA REAL do cabeçalho de plugin. A identidade que os quatro documentos
 * carimbam sai DAQUI e de nenhum outro lugar: é o cabeçalho que o WordPress lê
 * para barrar a instalação, e um número repetido ao lado dele sai de sincronia
 * na primeira release em que alguém mexe em só um dos dois.
 *
 * Plugin Name:       Base Site Core Fator3
 * Description:       Plugin de piso desta fixture. EXIGE PHP DE 64 BITS: o carimbo de milissegundo nao cabe nos 32 bits. INSTALACAO UNICA, NAO MULTISITE: a ativacao em rede e recusada.
 * Version:           9.9.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Text Domain:       f3base
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );
