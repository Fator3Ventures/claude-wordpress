# Instruções do plugin — Base Site Core Fator3

Árvore de piso: o documento existe com as regiões marcadas, e o conteúdo delas é o que a
medição de disco DESTA árvore produz. Sem os marcadores, o documento sairia do alcance do
gerador e a cláusula que este detector cobra deixaria de ter onde ser medida.

<!-- gerado:inicio=plugin-identidade -->
> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip
> ser montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número deste
> documento é digitado à mão: número digitado envelhece em silêncio, e um documento que descreve
> outro plugin é pior do que documento nenhum.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `9.9.0` |
| Pasta instalada | `base-site-core-fator3` |
| Prefixo interno | `` |
| Namespace REST | `` |
| Text domain | `f3base` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Módulos no registro único | 0 |
| Options no catálogo | 0 |
| Options operáveis na tela | 0 |
| Eventos de comportamento declarados | 0 |
| Rotas REST registradas | 0 |
| Tabelas próprias com colunas declaradas | 0 |
| Arquivos na fonte do plugin | 2 |
| Arquivos vindos de `partilhado/` | 0 |
<!-- gerado:fim=plugin-identidade -->

<!-- gerado:inicio=plugin-modulos -->
| Módulo | Arquivo | Options que o controlam | Hooks (tipo, gancho, prioridade) |
|---|---|---|---|
<!-- gerado:fim=plugin-modulos -->

<!-- gerado:inicio=plugin-options -->
| Option | Seção da tela | Campo | Operável | Sub-campos | Sanitizador |
|---|---|---|---|---|---|
<!-- gerado:fim=plugin-options -->

<!-- gerado:inicio=plugin-eventos -->
| Evento | Gatilho | Parâmetros | Teto por página | Limiar | Natureza |
|---|---|---|---|---|---|
<!-- gerado:fim=plugin-eventos -->

<!-- gerado:inicio=plugin-rotas -->
| Rota | Método | Autenticação | Onde é registrada |
|---|---|---|---|
<!-- gerado:fim=plugin-rotas -->

<!-- gerado:inicio=plugin-tabelas -->

<!-- gerado:fim=plugin-tabelas -->

<!-- gerado:inicio=plugin-limites -->
**Tetos fixos — constante do código, sem ponto de ajuste**

| Constante | Valor | Arquivo |
|---|---|---|

**Prazos e tamanhos ajustáveis — o valor é o PADRÃO do código, e o gancho é onde o site o muda**

| Filtro | Padrão | Arquivo |
|---|---|---|
<!-- gerado:fim=plugin-limites -->

<!-- gerado:inicio=plugin-peso -->
| Arquivo | Fonte | Entregue | Fonte comprimido | Entregue comprimido |
|---|---|---|---|---|
<!-- gerado:fim=plugin-peso -->
