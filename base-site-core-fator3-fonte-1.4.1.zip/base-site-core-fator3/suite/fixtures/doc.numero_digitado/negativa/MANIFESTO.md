<!-- gerado:inicio=carimbo -->
# Manifesto da release — Base Site Core Fator3 9.9.0

> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip ser
> montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número destes documentos
> é digitado à mão: número digitado está certo no dia em que foi escrito e é contradito pela rodada
> seguinte, sem nada acusando. O que não pode ser medido no momento da escrita sai como pendência
> nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `9.9.0` |
| Pasta instalada | `base-site-core-fator3` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Plataforma declarada no cabeçalho | `EXIGE PHP DE 64 BITS` |
| Escopo de instalação declarado no cabeçalho | `INSTALACAO UNICA, NAO MULTISITE` |
| Arquivos na fonte do plugin | 2 |
| Arquivos vindos de `partilhado/` | 0 |
| Arquivos no repositório (fora de `dist/` e dos produtos da rodada) | 11 |
| Checagens declaradas por classe de evidência | `analise-estatica/build` 2 |
| Detectores com piso em disco | 0 |
| Ramos de piso em disco (negativa + positiva) | 0 |
| Passos da bancada WordPress com mutante declarado | 1 |
| Checagens com piso declarado em sonda | 1 |
| Artefato publicado | `base-site-core-fator3-9.9.0.zip` |
| Época declarada de cada entrada do zip | `1980-01-01 00:00:00 UTC` |
<!-- gerado:fim=carimbo -->

Prosa do manifesto, que o gerador não toca.

<!-- gerado:inicio=inventario -->
### Inventário: caminho para papel

Gerado de `suite/inventario.tsv`. Manter aqui uma cópia escrita à mão criaria duas fontes, e a segunda
envelheceria calada — o inventário é executável e este documento não.

| Caminho | Papel |
|---|---|
| `README.md` | LEIA-ME DO OPERADOR desta árvore de piso. Existe para que a região arvore tenha o que desenhar. |
| `MANIFESTO.md` | MANIFESTO desta árvore de piso. Existe para que a região inventario tenha o que transcrever. |
| `MEMORIA-DECISOES.md` | MEMÓRIA desta árvore de piso. Existe para que a região contagem tenha títulos para contar. |
| `fontes/plugin/INSTRUCOES-DO-PLUGIN.md` | INSTRUÇÕES DO PLUGIN desta árvore de piso. Viajam dentro do zip. |
| `fontes/plugin/base-site-core-fator3.php` | Arquivo principal do plugin desta árvore de piso. É dele que a identidade sai. |
| `suite/` (prefixo) | A SUÍTE desta árvore de piso. Prefixo declarado, e é ele que prova que prefixo sai como um nó só. |
<!-- gerado:fim=inventario -->

<!-- gerado:inicio=requisitos -->
### Requisito para checagem, ambiente e evidência

Gerado de `suite/manifesto.tsv`. O cruzamento com a rodada é BIDIRECIONAL e roda em
`manifesto.bidirecional`: requisito cuja checagem a rodada não emitiu é FALHA, e rótulo emitido sem
requisito nem armadilha que o justifique também. Requisito que aparece mais de uma vez aponta para a
mesma checagem por mais de um motivo — um fato, uma linha de rodada, vários requisitos atendidos.

| Requisito | Checagem | Ambiente | Evidência |
|---|---|---|---|
| Número em documento entregável é gerado por leitura de disco | `estatica.carimbo_de_release_nos_documentos` | aqui | `analise-estatica/build` |
| Nenhum número digitado fora das regiões geradas | `doc.numero_digitado` | aqui | `analise-estatica/build` |
<!-- gerado:fim=requisitos -->

<!-- gerado:inicio=fixtures -->
### Piso: as três formas, e o que cada uma prova

Gerado de disco e das tabelas declaradas. Um detector sem piso é uma afirmação sobre a intenção de quem
o escreveu: enquanto ninguém o viu acusar o defeito que ele existe para acusar, ele pode estar cego.

**Piso em disco — um detector, duas árvores.** A NEGATIVA reproduz o defeito e precisa ser acusada; a
POSITIVA preserva o caso correto e precisa ficar em silêncio.

| Detector | Arquivos de piso |
|---|---|

**Piso da bancada WordPress — um passo, dois plugins instalados.** O caso negativo não é uma árvore
de arquivos: é o plugin com o defeito dentro, montado a partir do patch, num WordPress que sobe e
responde. `situação` diz se os DOIS ramos fecham hoje.

| Passo | Mutante | Situação |
|---|---|---|
| `wp.home_servida` | `mutantes/home_servida.patch` | coberto |

**Piso em sonda — o caso negativo mora dentro da própria sonda.** A declaração não absolve: ela só
vale quando a sonda declarada existe, menciona a checagem e traz os dois ramos escritos, e quem
confere isso é `estatica.piso_em_sonda_declarado`, que tem piso em disco como qualquer detector.

| Checagem | Sonda que carrega o piso |
|---|---|
| `pacote.zip_reprodutivel` | `suite/lib/sonda-bundle.php` |
<!-- gerado:fim=fixtures -->

<!-- gerado:inicio=excluidas -->
### O que a suíte da referência media e esta NÃO mede

Gerado de `suite/excluidas.tsv`. A suíte deste repositório foi EXTRAÍDA da do implantador, e checagem
que some numa extração é indistinguível de checagem esquecida — é exatamente assim que a cobertura
encolhe sem que nada acuse. Cada linha é uma decisão declarada, e o motivo é sempre de OBJETO ou de
ESCOPO. Uma checagem daqui só volta junto com o objeto dela.

**Categoria `implantador`**

| Checagem | Por que ela não está aqui |
|---|---|
| `config.schema_valida` | O OBJETO MEDIDO É O IMPLANTADOR. |

**Categoria `tema`**

| Checagem | Por que ela não está aqui |
|---|---|
| `a11y.contraste` | O OBJETO MEDIDO É O TEMA, que tem repositório próprio. |
<!-- gerado:fim=excluidas -->
