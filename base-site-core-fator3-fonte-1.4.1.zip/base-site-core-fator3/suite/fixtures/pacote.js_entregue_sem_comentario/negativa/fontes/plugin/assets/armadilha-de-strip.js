/**
 * FONTE PLANTADA: o comentário-que-não-é-comentário, em todas as formas que
 * este pacote de fato usa.
 *
 * Ela existe para uma pergunta só: o corte de comentários sabe a diferença
 * entre um comentário e uma sequência de dois caracteres dentro de um literal?
 * Um corte por expressão regular não sabe, e o arquivo que ele entrega ainda
 * analisa em alguns casos e faz outra coisa — que é o pior defeito possível de
 * um empacotamento, porque ele é silencioso e chega ao navegador do visitante.
 */
var abreBloco = '/*';
var fechaBloco = "*/";
var endereco = 'https://exemplo.test/a//b';
var barraEscapada = /^\/\/[a-z]*$/;
var barraEmClasse = /[/*]+/g;
var divisao = (10) / 2 / 1;
// comentário de linha, que precisa sair
var comDuasBarras = 'isto // não é comentário';
var modelo = `linha /* uma ` + abreBloco + `outra */ fim`;

function ehRegex() {
	return /ainda-regex/.test(fechaBloco + endereco + barraEscapada + barraEmClasse + divisao + comDuasBarras + modelo);
}

window.armadilhaDeStripDoPiso = ehRegex;
