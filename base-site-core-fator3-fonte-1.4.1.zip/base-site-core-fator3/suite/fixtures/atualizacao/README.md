# Insumo anterior para a atualização real

Cópia do ZIP instalável enviado pelo operador na sessão de evolução, sem alteração de bytes. Não é instalado em produção pela suíte. A bancada o instala apenas em um WordPress descartável, antes de trocar os arquivos pelo ZIP que está sendo testado.

SHA-256: `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f`.
