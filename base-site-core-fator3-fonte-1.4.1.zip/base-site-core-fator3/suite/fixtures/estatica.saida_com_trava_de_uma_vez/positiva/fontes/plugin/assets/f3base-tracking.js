/**
 * FORMA REAL do cliente: dois emissores ligados aos dois eventos de saída.
 * Os DOIS emissores têm a trava de uma vez: é o caso correto.
 */
(function (window, document) {
	'use strict';

	var resumoEnviado = false;

	function enviarResumo() {
		if (resumoEnviado) {
			return;
		}

		resumoEnviado = true;

		window.navigator.sendBeacon('/r', '{}');
	}

	var relatado = false;

	function relatar() {
		if (relatado) {
			return;
		}

		relatado = true;

		window.dataLayer.push({ event: 'f3base_web_vital' });
	}

	document.addEventListener('visibilitychange', function () {
		if ('hidden' === document.visibilityState) {
			relatar();
		}
	});

	window.addEventListener('pagehide', relatar);

	document.addEventListener('visibilitychange', function () {
		if ('hidden' === document.visibilityState) {
			enviarResumo();
		}
	});

	window.addEventListener('pagehide', enviarResumo);
}(window, document));
