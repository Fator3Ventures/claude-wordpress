/**
 * FORMA REAL do cliente: dois emissores ligados aos dois eventos de saída.
 * O despachante tem a trava; o relator de vitais NÃO tem — é o defeito.
 */
(function (window, document) {
	'use strict';

	var resumoEnviado = false;

	function enviarResumo() {
		if (resumoEnviado) {
			return;
		}

		resumoEnviado = true;

		window.navigator.sendBeacon('/r', '{}');
	}

	function relatar() {
		window.dataLayer.push({ event: 'f3base_web_vital' });
	}

	document.addEventListener('visibilitychange', function () {
		if ('hidden' === document.visibilityState) {
			relatar();
		}
	});

	window.addEventListener('pagehide', relatar);

	document.addEventListener('visibilitychange', function () {
		if ('hidden' === document.visibilityState) {
			enviarResumo();
		}
	});

	window.addEventListener('pagehide', enviarResumo);
}(window, document));
