<?php
/**
 * Fixture negativa: a tela devolveu o vocabulário interno e o parágrafo.
 */
class F3Base_Imp_Fixture_Tela {

	/**
	 * Emite as linhas de uma etapa.
	 *
	 * @return void
	 */
	public static function emitir(): void {
		F3Base_Imp_Relatorio::emitir(
			'OK',
			'etapa.exemplo',
			__( 'medição completa da etapa.', 'f3base' ),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				'tela'      => __( 'gate de aplicação fechado: veredito promovido sem pendência de fase.', 'f3base' ),
				'operador'  => __( 'A unidade fechou BLOCKED porque a pré-condição declarada do eixo de convergência não foi satisfeita nesta execução, e o veredito promovido da unidade reflete a checagem mais severa que ela emitiu, de modo que a autodesativação não pôde acontecer e o gate de aplicação permaneceu aberto aguardando a fase seguinte.', 'f3base' ),
			)
		);
	}
}
