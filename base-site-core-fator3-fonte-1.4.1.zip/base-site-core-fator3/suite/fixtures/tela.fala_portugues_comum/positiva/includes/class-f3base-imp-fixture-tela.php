<?php
/**
 * Fixture positiva: a tela fala português comum.
 */
class F3Base_Imp_Fixture_Tela {

	/**
	 * Emite as linhas de uma etapa.
	 *
	 * @return void
	 */
	public static function emitir(): void {
		F3Base_Imp_Relatorio::emitir(
			'OK',
			'etapa.exemplo',
			__( 'medição completa da etapa, com evidência, fase e o parágrafo inteiro que explica cada número — este texto é o log e pode ser tão longo quanto precisar para alguém entender por que a etapa terminou assim.', 'f3base' ),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				'tela'      => __( 'Páginas e posts publicados.', 'f3base' ),
				'operador'  => __( 'Preencher o número de WhatsApp em config/projeto.json para o botão de contato abrir a conversa.', 'f3base' ),
			)
		);
	}
}
