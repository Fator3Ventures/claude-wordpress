/**
 * Fixture do PISO de `doc.afirmacao_conferida` — o lado do NAVEGADOR, correto.
 *
 * O que ela sustenta: a afirmação "O coletor pede a declaração pelo gatilho",
 * declarada em `suite/afirmacoes.tsv` desta fixture pela regra `codigo.contem`.
 * É este arquivo, e não o PHP, que a regra lê — e é essa a razão de a regra
 * existir: metade do que o documento do plugin afirma acontece aqui.
 */
(function () {
	'use strict';

	var EVENTOS = {};

	function declaracao(gatilho) {
		var nome;

		for (nome in EVENTOS) {
			if (Object.prototype.hasOwnProperty.call(EVENTOS, nome) && EVENTOS[nome].gatilho === gatilho) {
				return { nome: nome, dados: EVENTOS[nome] };
			}
		}

		return null;
	}

	window.f3baseFixtureDeclaracao = declaracao;
})();
