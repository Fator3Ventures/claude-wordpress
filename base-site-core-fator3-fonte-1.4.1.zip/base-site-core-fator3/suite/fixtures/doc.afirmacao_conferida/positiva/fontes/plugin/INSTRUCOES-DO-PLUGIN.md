# Documento de fixture — o caso CORRETO

Duas afirmações de comportamento, das duas naturezas que este detector precisa
alcançar: uma que mora no PHP do servidor e outra que mora no arquivo que roda
no navegador.

O carimbo de cada linha sai da âncora do lote.

O coletor pede a declaração pelo gatilho.
