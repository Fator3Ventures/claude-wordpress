/**
 * Fixture do PISO de `doc.afirmacao_conferida` — o lado do NAVEGADOR, DEFEITUOSO.
 *
 * O defeito plantado: o documento continua afirmando "O coletor pede a
 * declaração pelo gatilho" e o coletor passou a pedi-la pelo NOME do evento. É
 * exatamente a forma de mentira que este detector existe para acusar — a frase
 * de prosa continua lá, correta no dia em que foi escrita, e o código dentro do
 * mesmo zip faz outra coisa.
 */
(function () {
	'use strict';

	var EVENTOS = {};

	function declaracao(nome) {
		if (Object.prototype.hasOwnProperty.call(EVENTOS, nome)) {
			return { nome: nome, dados: EVENTOS[nome] };
		}

		return null;
	}

	window.f3baseFixtureDeclaracao = declaracao;
})();
