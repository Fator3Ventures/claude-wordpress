<?php
/**
 * Fixture do PISO de `doc.afirmacao_conferida` — o lado do SERVIDOR.
 *
 * Aqui o código está correto: o defeito plantado deste lado é no DOCUMENTO — a
 * frase declarada em `suite/afirmacoes.tsv` desta fixture saiu dele, e a
 * amarração ficou para trás da redação.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Gravação de uma linha carimbada pela âncora do lote.
 */
class F3Base_Fixture_Lote {

	/**
	 * A âncora do lote, em segundos.
	 *
	 * @param int $chegada Instante da chegada.
	 * @param int $maior   Maior deslocamento do lote, em milissegundos.
	 * @return int
	 */
	public static function ancora_do_lote( int $chegada, int $maior ): int {
		return $chegada - intdiv( $maior, 1000 );
	}

	/**
	 * O carimbo de uma linha, derivado da âncora.
	 *
	 * @param int $chegada Instante da chegada.
	 * @param int $maior   Maior deslocamento do lote, em milissegundos.
	 * @param int $ms      Deslocamento desta linha, em milissegundos.
	 * @return int
	 */
	public static function carimbo( int $chegada, int $maior, int $ms ): int {
		return self::ancora_do_lote( $chegada, $maior ) + intdiv( $ms, 1000 );
	}
}
