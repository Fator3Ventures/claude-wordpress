# Documento de fixture — os DOIS defeitos plantados

Primeiro defeito: a frase sobre a âncora do lote SAIU deste documento e a linha
da tabela continua declarando que ela está aqui. Amarração órfã afirma cobertura
que não existe.

Segundo defeito: esta frase continua escrita e o pacote faz outra coisa.

O coletor pede a declaração pelo gatilho.
