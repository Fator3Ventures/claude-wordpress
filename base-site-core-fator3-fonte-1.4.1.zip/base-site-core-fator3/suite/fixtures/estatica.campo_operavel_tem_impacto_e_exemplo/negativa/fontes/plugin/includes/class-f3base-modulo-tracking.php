<?php
/**
 * Fixture do piso: a ÂNCORA das FORMAS ilustrativas de identificador.
 *
 * Ela é a mesma nos dois lados — o que o detector mede não é a âncora, e sim o
 * exemplo que o catálogo escreveu contra ela.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Formas declaradas dos identificadores de fornecedor.
 */
final class F3Base_Modulo_Tracking {

	/**
	 * Forma pública de cada identificador, como o fornecedor a documenta.
	 *
	 * @return array<string,array{regex:string,forma:string}>
	 */
	public static function formas(): array {
		return array(
			'f3base_ga4_measurement_id' => array(
				'regex' => '/^G-[A-Z0-9]{4,}$/',
				'forma' => 'G-XXXXXXXXXX',
			),
		);
	}
}
