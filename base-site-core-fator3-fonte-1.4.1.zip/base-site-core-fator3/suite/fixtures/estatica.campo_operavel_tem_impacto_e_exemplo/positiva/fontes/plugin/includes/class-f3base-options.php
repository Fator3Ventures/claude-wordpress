<?php
/**
 * Fixture do piso: catálogo reduzido de options do site-core.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Catálogo reduzido.
 */
final class F3Base_Options {

	/**
	 * Seções da tela.
	 */
	public const SECAO_CONTATO = 'contato';
	public const SECAO_MEDICAO = 'medicao';

	/**
	 * As options que são SEGREDO DO SITE.
	 *
	 * @return string[]
	 */
	public static function segredos_do_site(): array {
		return array(
			'f3base_meta_capi_token',
		);
	}

	/**
	 * Catálogo.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function catalogo(): array {
		$catalogo = array(
			'f3base_contato'            => array(
				'rotulo'    => __( 'Contato pelo WhatsApp', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_CONTATO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'whatsapp_e164' => '',
				),
				'subcampos' => array(
					'whatsapp_e164' => array(
						'tipo'    => 'texto',
						'rotulo'  => __( 'Número de WhatsApp', 'f3base' ),
						'impacto' => __( 'Com o número preenchido, o botão de contato passa a ser publicado e abre a conversa; vazio, o botão não é publicado em página nenhuma.', 'f3base' ),
						'exemplo' => __( 'Ilustrativo: 5511900000000 — código do país, DDD e número, somente dígitos.', 'f3base' ),
					),
				),
			),
			'f3base_ga4_measurement_id' => array(
				'rotulo'    => __( 'Google Analytics 4 — ID da métrica', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site passa a enviar as páginas vistas ao Google Analytics; vazio, nada chega lá.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo, na forma que o próprio Google usa na documentação: G-XXXXXXXXXX.', 'f3base' ),
			),
			'f3base_retencao_meses'     => array(
				'rotulo'    => __( 'Guarda dos contatos recebidos (meses)', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'inteiro',
				'padrao'    => 12,
				'impacto'   => __( 'É o prazo que a limpeza automática usa: passado ele, o registro do contato vai para a lixeira.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 12, o prazo que este site usa por padrão.', 'f3base' ),
			),
			'f3base_meta_capi_token'    => array(
				'rotulo'    => __( 'Meta — token do envio de servidor', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o contato passa a ser enviado também do servidor para a Meta; vazio, só o envio pelo navegador existe.', 'f3base' ),
				'exemplo'   => __( 'Este campo não tem exemplo de valor: um valor de exemplo aqui seria uma credencial. O token é gerado no Gerenciador de Eventos da Meta.', 'f3base' ),
			),
		);

		return $catalogo;
	}
}
