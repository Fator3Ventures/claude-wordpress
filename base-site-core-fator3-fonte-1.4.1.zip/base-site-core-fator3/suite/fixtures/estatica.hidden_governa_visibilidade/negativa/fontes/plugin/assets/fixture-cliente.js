(function (document) {
	'use strict';

	var painel = document.createElement('div');
	var resumo = document.createElement('section');

	painel.className = 'fixture-painel';
	painel.hidden = true;

	resumo.className = 'fixture-resumo';
	resumo.setAttribute('hidden', 'hidden');

	document.body.appendChild(painel);
	document.body.appendChild(resumo);
}(document));
