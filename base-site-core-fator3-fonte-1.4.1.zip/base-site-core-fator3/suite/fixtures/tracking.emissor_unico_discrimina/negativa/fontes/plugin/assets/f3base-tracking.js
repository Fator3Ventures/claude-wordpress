/**
 * Bancada de `tracking.emissor_unico_discrimina`: os ids das tags criadas.
 *
 * O carregador real cria cada tag de fornecedor por `document.createElement` e
 * lhe dá um id que só ele usa. É esse id que separa, no DOM, a emissão do
 * site-core da emissão de fora. O recorte abaixo declara os mesmos quatro.
 */
(function () {
	'use strict';

	function inserir(id, src) {
		var tag = document.createElement('script');

		tag.id = id;
		tag.src = src;

		document.head.appendChild(tag);
	}

	inserir('f3base-gtm', 'https://www.googletagmanager.com/gtm.js');
	inserir('f3base-gtag', 'https://www.googletagmanager.com/gtag/js');
	inserir('f3base-meta-pixel', 'https://connect.facebook.net/en_US/fbevents.js');
	inserir('f3base-linkedin-insight', 'https://snap.licdn.com/li.lms-analytics/insight.min.js');
}());
