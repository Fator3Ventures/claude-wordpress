<?php
/**
 * Bancada de `tracking.emissor_unico_discrimina`: as MARCAS, e só elas.
 *
 * O discriminante que a checagem usa sai daqui e do carregador ao lado: o
 * handle vira `id="<handle>-js"` no HTML que o WordPress imprime, e as origens
 * dizem qual `src` é de cada fornecedor. Sem os dois arquivos a checagem não
 * consegue separar a emissão do pacote da emissão de fora — e ela diz isso em
 * vez de aprovar.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Recorte do módulo real, com as constantes que a marca precisa.
 */
final class F3Base_Modulo_Tracking_Bancada {

	public const HANDLE = 'f3base-tracking';

	public const ORIGEM_GOOGLE = 'https://www.googletagmanager.com/';

	public const ORIGEM_META = 'https://connect.facebook.net/en_US/fbevents.js';

	public const ORIGEM_LINKEDIN = 'https://snap.licdn.com/li.lms-analytics/insight.min.js';
}
