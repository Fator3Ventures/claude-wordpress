# Frente A → frente C: dois diffs propostos em `includes/class-f3base-options.php`

Nenhum dos dois está aplicado. Eles são de arquivo da frente C, e as correções da
frente A foram feitas sem eles — o que cada um muda está dito abaixo junto com o
que acontece enquanto ele não existir.

## 1. O padrão entregue de `aviso_primeira_visita` (consequência direta de A-13)

**O que mudou na frente A.** O apelido do visitante deixou de nascer no primeiro
carregamento de um site em modo `pre-aprovado` SEM aviso. A regra, escrita em
`podeIdentificar()` no cliente e publicada pelo servidor em `dados_do_cliente()`:
o apelido nasce depois de uma decisão explícita do visitante, ou com a política de
negativa por padrão (em que `granted` só existe por decisão), ou no pré-aprovado
COM `aviso_primeira_visita` ligado — que é a única coisa, nesse modo, que diz ao
visitante que ele está sendo medido antes de o identificador existir.

**O efeito no site entregue.** O catálogo declara `f3base_consentimento` com
`padrao => pre-aprovado` e `aviso_primeira_visita => false`. Com esses dois
valores, um site recém-entregue passa a somar o AGREGADO inteiro e a NÃO produzir
registro detalhado: some a tabela de acionamentos, somem "visitas por página" e
"pessoas diferentes". Isso é o comportamento correto sob a regra nova — o
identificador de quem nunca foi perguntado não nasce —, e é uma perda de função
que quem opera o site não pediu.

**O diff proposto**, no bloco de `f3base_consentimento` do catálogo:

```diff
 				'padrao'    => array(
 					'padrao'                => 'pre-aprovado',
 					'controle_rodape'       => true,
-					'aviso_primeira_visita' => false,
+					'aviso_primeira_visita' => true,
 					'ttl_dias'              => 180,
 				),
```

E, no `impacto` do subcampo `aviso_primeira_visita`, a frase que faltava: com a
política pré-aprovada, é este aviso que autoriza o apelido do visitante a nascer —
desligado, o site continua medindo em agregado e para de produzir o registro
detalhado por visitante.

**Enquanto ele não existir:** nenhuma checagem fica em FALHA. As bancadas de
`js.resumo_da_sessao` medem os quatro casos da regra explicitamente, inclusive o
do pré-aprovado sem aviso, e a sonda de navegador publica `aviso: true` porque é o
caso em que o registro existe.

## 2. O prazo que o painel não alcança (A-17)

**O que a frente A fez.** A tela Medição passou a avisar, em português comum,
quando `dias_no_painel` é maior que `retencao_eventos_dias`: os quadros que leem o
REGISTRO cobrem a janela menor e os que leem o AGREGADO cobrem a maior, e os dois
diziam o mesmo número de dias. A checagem é `medicao.tela_declara_o_recorte`.

**O que continua incoerente do lado de C.** `sanitiza_comportamento()` limita
`dias_no_painel` por `retencao_dias` — o prazo do agregado — e o docblock diz
"`dias_no_painel` governa só a leitura, e é limitado pelo que existe: pedir mais
dias do que a retenção guarda mostraria um período cujo começo foi apagado". A
frase descreve UM dos dois prazos. O segundo, `retencao_eventos_dias`, é sempre
menor ou igual ao primeiro e é o que governa metade dos quadros da tela.

**O diff proposto é de DOCUMENTO, e não de aritmética** — e a recusa de apertar o
número é a parte que importa: limitar `dias_no_painel` por `retencao_eventos_dias`
encolheria o painel inteiro para o prazo do dado pessoal e esconderia a série do
agregado, que dura mais justamente por não identificar ninguém.

```diff
  * na conta de medição. `dias_no_painel` governa só a leitura, e é limitado
  * pelo que existe: pedir mais dias do que a retenção guarda mostraria um
- * período cujo começo foi apagado, com o total parecendo queda de tráfego.
+ * período cujo começo foi apagado, com o total parecendo queda de tráfego.
+ *
+ * O TETO É O DO AGREGADO, E NÃO O DO REGISTRO, e a diferença é declarada. O
+ * registro tem prazo próprio e mais curto, e os quadros da tela que vêm dele
+ * cobrem essa janela menor: apertar `dias_no_painel` até lá encolheria também
+ * a série do agregado, que dura mais justamente por não identificar ninguém.
+ * Quem avisa que os dois períodos divergem é a tela Medição, com os dois
+ * números ao lado — a escolha entre encolher o painel e alongar a guarda de
+ * dado pessoal é de quem opera o site.
```

E, no `impacto` do subcampo `dias_no_painel`, a frase que falta: os quadros que
vêm do registro detalhado cobrem o prazo DELE, que é o campo logo acima.

**Enquanto ele não existir:** nenhuma checagem fica em FALHA — a tela já diz o que
precisa ser dito, e o que sobra do lado de C é um docblock e um `impacto`
descrevendo um dos dois prazos como se fosse o único.
