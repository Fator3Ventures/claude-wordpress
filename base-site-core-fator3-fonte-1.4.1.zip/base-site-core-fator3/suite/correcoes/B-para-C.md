# Frente B → frente C: `f3base_origem_confiavel` precisa declarar as faixas de IP dos proxies

## Por que

O achado **B-8**. O cabeçalho de proxy confiável era declarado pelo NOME e por mais nada, e nome
de cabeçalho não é autenticação: cabeçalho é texto que qualquer cliente manda. Quem alcança a
origem por fora da CDN — pelo IP, o que costuma responder — envia o cabeçalho declarado com o
valor que quiser e, com ele, escolhe o balde do limite por janela e o `client_ip_address` que o
servidor manda à Meta.

A correção do CONSUMO está feita na frente B, em
`fontes/plugin/includes/class-f3base-modulo-endpoint-leads.php`: `cabecalho_confiavel()` passou a
ler a subchave `redes_confiaveis`, `em_rede_confiavel()` compara `REMOTE_ADDR` contra as faixas em
BINÁRIO (prefixo casado por texto deixa `10.0.0.10` entrar em `10.0.0.1/32`), e `origem()` só lê o
cabeçalho quando a conexão vem de uma delas. **Chave ausente é lista vazia, e lista vazia é NUNCA
CONFIAR** — a posição segura é a que não depende de ninguém ter lembrado de preencher.

Isso FUNCIONA hoje sem a mudança abaixo, porque `sanitiza_origem_confiavel()` termina em
`preservar_desconhecidas()` e a chave é de primeiro nível: ela sobrevive à leitura de volta. O que
falta é o que só a frente C pode dar — a chave declarada no catálogo, com rótulo, impacto,
exemplo e sanitização própria, e a tela onde o operador a preenche. Enquanto ela for chave
desconhecida preservada, `estatica.campo_operavel_tem_impacto_e_exemplo` não a cobre e o operador
não tem onde escrevê-la a não ser pelo canal.

`leads.origem_declarada` cobre o consumo — inclusive o piso da chave ausente — e passa sem esta
mudança.

## O diff proposto em `fontes/plugin/includes/class-f3base-options.php`

### 1. O subcampo declarado, ao lado de `cabecalho` e `saltos`

```php
                                'saltos'    => array(
                                        'tipo'      => 'inteiro',
                                        'rotulo'    => __( 'Em que posição da lista está o endereço do visitante', 'f3base' ),
                                        'descricao' => __( 'Usado apenas quando o cabeçalho acima está preenchido.', 'f3base' ),
                                        'impacto'   => __( 'É a POSIÇÃO contada do fim da lista do cabeçalho: 1 é o último elemento, que é o único escrito pelo seu próprio proxy. Um número menor que o real faz o site ler um endereço que o visitante escreveu; um número maior faz a leitura falhar e voltar ao endereço da conexão.', 'f3base' ),
                                        'exemplo'   => __( 'Ilustrativo: 1, quando há uma única CDN na frente do site.', 'f3base' ),
                                ),
+                               'redes_confiaveis' => array(
+                                       'tipo'      => 'lista',
+                                       'rotulo'    => __( 'De quais endereços os seus proxies falam com o site', 'f3base' ),
+                                       'descricao' => __( 'Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.', 'f3base' ),
+                                       'impacto'   => __( 'Sem pelo menos uma faixa aqui, o cabeçalho acima NÃO é lido — e essa é a posição segura. Cabeçalho é texto que qualquer cliente manda: quem alcança o servidor por fora da CDN escolheria em que balde do limite ele conta e qual endereço o site envia aos fornecedores de anúncio. Preenchidas, só o pedido que chega de uma dessas faixas tem o cabeçalho lido.', 'f3base' ),
+                                       'exemplo'   => __( 'Ilustrativo: 198.51.100.0/24 numa linha e 203.0.113.7 na outra. Só declare faixa que a sua hospedagem confirmar.', 'f3base' ),
+                               ),
```

E o padrão do grupo ganha `'redes_confiaveis' => array()` — lista vazia, que é NUNCA CONFIAR.

### 2. A sanitização, dentro de `sanitiza_origem_confiavel()`

O sanitizador não precisa reimplementar a leitura: ela já existe, é pública e é a MESMA que o
endpoint usa para consumir. Duas cópias divergiriam na primeira notação aceita a mais.

```php
                $saltos = isset( $valor['saltos'] ) ? (int) $valor['saltos'] : (int) $padrao['saltos'];

+               /*
+                * A LEITURA DAS FAIXAS É A DO CONSUMIDOR. `redes_declaradas()` aceita lista ou
+                * texto separado por vírgula, quebra de linha ou espaço, e DESCARTA o que não
+                * casa com IP nem com CIDR — faixa ilegível não pode virar faixa que aceita
+                * tudo. Reescrevê-la aqui seria a segunda regra para o mesmo risco.
+                */
+               $redes = class_exists( 'F3Base_Modulo_Endpoint_Leads' )
+                       ? F3Base_Modulo_Endpoint_Leads::redes_declaradas( $valor['redes_confiaveis'] ?? array() )
+                       : array();
+
                return self::preservar_desconhecidas(
                        array(
-                               'cabecalho' => $cabecalho,
-                               'saltos'    => max( 1, min( 10, $saltos ) ),
+                               'cabecalho'        => $cabecalho,
+                               'saltos'           => max( 1, min( 10, $saltos ) ),
+                               'redes_confiaveis' => $redes,
                        ),
                        $valor
                );
```

Se a frente C preferir não depender da classe do módulo dentro do gravador, a alternativa é mover
`redes_declaradas()` para um lugar sem dependência — o critério deste pacote é ponto único, não
qual dos dois arquivos o hospeda. O que **não** pode acontecer é uma segunda implementação da
leitura de CIDR.

### 3. A frase de `saltos` estava errada, e é a mesma frase de B-18

O `impacto` atual diz "O endereço é lido descontando esta quantidade a partir do fim da lista". O
código faz `count( $lista ) - $saltos`, que é a POSIÇÃO contada do fim: com `saltos = 1` ele lê o
ÚLTIMO elemento. "Descontando 1 a partir do fim" descreve o penúltimo. Quem tem uma única CDN e lê
a frase atual escreve `2`, e o site passa a ler a ponta que o próprio visitante escreveu — que é
exatamente o defeito que a chave existe para impedir. O texto novo está no diff do item 1.

O comentário equivalente dentro do endpoint e a frase do estado do módulo já foram corrigidos na
frente B, e `leads.origem_declarada` acusa a volta da frase antiga.
