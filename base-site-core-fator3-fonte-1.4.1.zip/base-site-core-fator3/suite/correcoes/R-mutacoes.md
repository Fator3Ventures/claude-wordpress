# Frente R — as cinco mutações, e o que cada checagem disse

Este arquivo existe pela mesma razão de `rodada-0.mutacoes.md`: **checagem que
nunca foi vista acusando é afirmação sobre a intenção de quem a escreveu.** Esta
rodada REVERTE comportamento — o apelido volta a nascer com a política, a faixa
vazia volta a confiar, a eliminação sem lixeira volta a acontecer —, e reverter
sem plantar o defeito contrário deixaria as três reversões apoiadas em nada.

Regra das cinco: **uma por vez, na árvore real, e revertida com
`git checkout -- <caminho>` com `git status` limpo depois.** A reversão é
conferida pelo próprio git: árvore suja depois de uma mutação é a mutação virando
release.

As duas últimas também rodam sozinhas, a cada `bash suite/verificar.sh piso`:
elas são patches declarados em `suite/bancada-wp/pisos.tsv`, e a bancada monta a
árvore mutante, empacota, instala num WordPress novo e exige o estado adverso. O
que está registrado abaixo é a plantação NA ÁRVORE REAL, que é a prova
independente do arnês.

---

## (a) O apelido nascendo sob o portão NEGADO — `js.resumo_da_sessao`

**O que ele planta.** O portão do consentimento sai dos DOIS lugares que guardam
o nascimento do apelido: a guarda de `carregar()` e a resposta de
`podeIdentificar()`. As duas metades são necessárias porque a redundância é
deliberada — remover uma só não produz apelido nenhum, e é isso que o piso dentro
da própria checagem documenta.

**O comando**

```
python3 -c "
import io
P='fontes/plugin/assets/f3base-tracking.js'
t=io.open(P,encoding='utf-8').read()
io.open(P,'w',encoding='utf-8').write(
    t.replace('if (carregado || !permiteTags()) {','if (carregado) {')
     .replace('\tfunction podeIdentificar() {\n\t\treturn permiteTags();\n\t}',
              '\tfunction podeIdentificar() {\n\t\treturn true;\n\t}'))"
bash suite/verificar.sh /root/base/wt-R
```

**A linha acusada**

```
FALHA   js.resumo_da_sessao                          — 3 achado(s) em ? unidade(s) medida(s): piso do consentimento: com o consentimento NEGADO saíram 1 envio(s) e 7 evento(s). A porta do resumo é a mesma das quatro tags, e ela não tem exceção; TETO do caso negativa por padrão: com o portão NEGADO e nenhuma decisão do visitante, o cliente gravou apelido ou despachou 1 envio(s). Sob negativa por padrão só o aceite muda o portão, e antes dele não há apelido, não há visita e não há linha; PISO do portão do apelido: a bancada não encontrou as duas guardas para removê-las. Ou o portão mudou de forma, e o piso deixou de provar o que promete, ou ele sumiu — e nesse caso os tetos acima é que deveriam ter acusado  [evidência: teste-funcional/build]
```

**O que isso ensina.** A terceira linha do achado é a mais informativa: com o
defeito JÁ plantado na fonte, o piso interno da checagem não encontra mais o que
mutar e diz isso em voz alta, em vez de calar. Uma segunda checagem falou junto —
`js.comportamento_instrumentado`, acusando os eventos emitidos sob o portão
negado —, e ela está certa em falar: o mutante remove o portão do carregador
inteiro, e a instrumentação passa pela mesma porta.

**Reversão**

```
git checkout -- fontes/plugin/assets/f3base-tracking.js fontes/plugin/INSTRUCOES-DO-PLUGIN.md
```

(o documento entra na reversão porque a região gerada `plugin-peso` acompanha o
tamanho do arquivo entregue, e a rodada com o mutante a reescreveu.)

---

## (b) Faixa VAZIA voltando a "nunca confiar" — `leads.origem_declarada`

**O que ele planta.** O comportamento de hoje, que esta rodada reverteu: sem
faixa de proxy declarada, o cabeçalho declarado deixa de ser lido.

**O comando**

```
python3 -c "
import io
P='fontes/plugin/includes/class-f3base-modulo-endpoint-leads.php'
t=io.open(P,encoding='utf-8').read()
io.open(P,'w',encoding='utf-8').write(t.replace(
  \"if ( array() !== \\\$declarado['redes_confiaveis'] && ! self::em_rede_confiavel( \\\$remoto, \\\$declarado['redes_confiaveis'] ) ) {\",
  \"if ( ! self::em_rede_confiavel( \\\$remoto, \\\$declarado['redes_confiaveis'] ) ) {\"))"
bash suite/verificar.sh /root/base/wt-R
```

**A linha acusada**

```
FALHA   leads.origem_declarada                       — 1 achado(s): teto da faixa vazia: sem faixa de proxy declarada o cabeçalho DEIXOU de ser lido (203.0.113.200 por remote_addr) — é o comportamento que toda instalação já entregue tem, e trocá-lo numa atualização faz cada uma delas passar a contar todos os visitantes no mesmo balde sem ninguém ter mexido em nada  [evidência: teste-funcional/build]
```

**Reversão**

```
git checkout -- fontes/plugin/includes/class-f3base-modulo-endpoint-leads.php
```

---

## (c) Faixa PREENCHIDA e a conexão de fora, com o cabeçalho lido — `leads.origem_declarada`

**O que ele planta.** A proteção que o campo existe para ligar sai inteira: a
conferência da conexão desaparece, e quem alcança a origem por fora da CDN volta
a escolher o balde do limite e o endereço enviado ao fornecedor.

**O comando**

```
python3 -c "
import io
P='fontes/plugin/includes/class-f3base-modulo-endpoint-leads.php'
t=io.open(P,encoding='utf-8').read()
bloco=t[t.index('\t\tif ( array() !== \$declarado'):t.index('\t\t\$bruto = isset(')]
io.open(P,'w',encoding='utf-8').write(t.replace(bloco,''))"
bash suite/verificar.sh /root/base/wt-R
```

**A linha acusada**

```
FALHA   leads.origem_declarada                       — 1 achado(s): piso do contorno da CDN: com a faixa DECLARADA, um pedido que chegou DIRETO ao servidor teve o cabeçalho lido (10.0.0.1 por cabecalho-declarado) — quem alcança a origem por fora escolhe o balde do rate limit e o endereço que o servidor manda à Meta  [evidência: teste-funcional/build]
```

**O que isso ensina, e é por isso que os dois mutantes existem.** (b) e (c) são
opostos sobre o mesmo campo: um afrouxa a lista preenchida, o outro endurece a
lista vazia. Uma checagem que só medisse um deles aprovaria a metade errada da
decisão do operador sem nada dizendo.

**Reversão**

```
git checkout -- fontes/plugin/includes/class-f3base-modulo-endpoint-leads.php
```

---

## (d) `reversivel: true` sem lixeira — `wp.retencao_sem_lixeira`

**O que ele planta.** O defeito da 1.0.1: a rota deixa de perguntar pela lixeira,
move para uma lixeira que não existe — o registro é apagado — e responde
`reversivel: true` com `reversivel_ate`, prometendo uma janela de reversão sobre
o que já não está lá.

**O comando**

```
( cd fontes/plugin && patch -p1 < ../../suite/bancada-wp/mutantes/retencao_sem_lixeira.patch )
bash suite/verificar.sh /root/base/wt-R
```

**A linha acusada**

```
FALHA   wp.retencao_sem_lixeira                      — o regime operacional não diz o que faz quando não há lixeira: a rota respondeu reversivel: true com a lixeira do WordPress desligada, isto é, prometeu uma janela de reversão sobre uma cópia que não existe | a resposta trouxe reversivel_ate mesmo sem janela nenhuma: campo de prazo sobre o que não tem prazo é a mesma promessa falsa com outro nome | a resposta não NOMEIA EMPTY_TRASH_DAYS: quem opera o site não tem onde mexer para ter a janela de volta (+3). Com EMPTY_TRASH_DAYS em zero, mover para a lixeira APAGA — e as duas saídas erradas são prometer a janela assim mesmo e recusar o pedido, que deixa o prazo declarado sem ser cumprido.  [evidência: wp-real/build]
```

**Reversão**

```
git checkout -- fontes/plugin/
```

---

## (e) Sem lixeira, NÃO elimina — `wp.retencao_sem_lixeira`

**O que ele planta.** O comportamento de hoje, que esta rodada reverteu: a rota
recusa o regime operacional com `409` e nada é apagado. O registro vencido fica
no banco, e o prazo que a política de privacidade promete deixa de ser cumprido
para ele — em silêncio, porque a recusa parece zelo.

**O comando**

```
( cd fontes/plugin && patch -p1 < ../../suite/bancada-wp/mutantes/retencao_sem_lixeira_recusa.patch )
bash suite/verificar.sh /root/base/wt-R
```

**A linha acusada**

```
FALHA   wp.retencao_sem_lixeira                      — o regime operacional não diz o que faz quando não há lixeira: a rota respondeu 409 em vez de 200: recusar o pedido deixa o registro vencido no banco, e o prazo que a política de privacidade promete passa a não ser cumprido para ele | a resposta declarou contagem 0 para um pedido de um registro só | o registro continuou no banco em "publish": sem lixeira a eliminação é definitiva, e não acontecer é o prazo declarado deixando de ser cumprido (+1). Com EMPTY_TRASH_DAYS em zero, mover para a lixeira APAGA — e as duas saídas erradas são prometer a janela assim mesmo e recusar o pedido, que deixa o prazo declarado sem ser cumprido.  [evidência: wp-real/build]
```

**Reversão**

```
git checkout -- fontes/plugin/
```

---

## O que o piso roda sozinho

`bash suite/verificar.sh piso` planta (d) e (e) por conta própria, cada um numa
árvore temporária empacotada e instalada num WordPress novo, e exige o estado
adverso dos dois. O passo aparece três vezes no relatório do piso: o ramo
positivo, que exige silêncio sobre a fonte correta, e um ramo negativo por
mutante declarado em `suite/bancada-wp/pisos.tsv`.

Os mutantes (a), (b) e (c) moram dentro das próprias checagens — o de (a) como
transformação da fonte lida em memória, dentro de `js.resumo_da_sessao`; os de
(b) e (c) como os ramos opostos que a sonda mede um contra o outro. O que este
arquivo acrescenta é a plantação na árvore REAL, que não depende do arnês ter
sido escrito direito.

---

## Replantação independente, na árvore fundida (item 6 do plano)

Depois da entrega da frente, as mutações foram replantadas UMA A UMA em
`wt-R` por quem conduz a rodada — sem o arnês do piso, com `git checkout --
fontes/plugin` e `git status` limpo depois de cada uma. O que cada checagem
disse:

| Mutante | O que foi plantado | Checagem | O que a rodada disse |
|---|---|---|---|
| (a₁) só a segunda guarda | `podeIdentificar()` devolvendo `true`, com a guarda de `carregar()` intacta | `js.resumo_da_sessao` | FALHA — pelo **piso da forma** ("a bancada não encontrou as duas guardas para removê-las"); o teto do caso negativo ficou em silêncio, porque com uma guarda só o apelido de fato não nasce. É a redundância que a própria sonda documenta. |
| (a₂) as duas guardas | `podeIdentificar()` em `true` **e** `carregar()` sem `!permiteTags()` | `js.resumo_da_sessao`, `js.comportamento_instrumentado` | FALHA — pelo **teto**: "com o portão NEGADO e nenhuma decisão do visitante, o cliente gravou apelido ou despachou 1 envio(s)"; mais o piso da forma e a instrumentação, que partilha a porta. |
| (b) | a conferência de faixa trocada por `if ( false )` — preenchida e de fora, o cabeçalho é lido | `leads.origem_declarada` | FALHA — "com a faixa DECLARADA, um pedido que chegou DIRETO ao servidor teve o cabeçalho lido (10.0.0.1 por cabecalho-declarado)". Só ela. |
| (c) | faixa vazia passando a ignorar o cabeçalho (`array() === ... \|\|`) | `leads.origem_declarada` | FALHA — "sem faixa de proxy declarada o cabeçalho DEIXOU de ser lido (203.0.113.200 por remote_addr)". Só ela. |
| (d) | `'reversivel' => true` na resposta sem lixeira | `wp.retencao_sem_lixeira` | FALHA — "a rota respondeu reversivel: true com a lixeira do WordPress desligada". Só ela. |

Cada rodada mutante fechou com a mesma contagem de linhas da rodada limpa e
exatamente a(s) FALHA(s) esperada(s); o selo não foi gravado em nenhuma delas.

## R-9, o defeito achado depois da rodada

A conferência à mão do zip final num WordPress real — executar `config-ler`
como administrador, coisa que a suíte nunca tinha feito — derrubou a chamada
com `Error — Cannot use object of type stdClass as array (rest-api.php:2445)`.
O passo `wp.habilidades_de_config_executam` nasceu ANTES da correção e acusou
os três pontos (as duas habilidades de configuração com a entrada válida, e
`como-usar` com um campo fora do schema); a correção o calou; o mutante
`habilidades_de_config_executam.patch` o faz acusar de novo a cada piso.
