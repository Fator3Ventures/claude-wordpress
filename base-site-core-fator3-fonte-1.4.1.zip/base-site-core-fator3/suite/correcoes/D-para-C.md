# Frente D → frente C: os diffs propostos em `fontes/plugin/includes/class-f3base-options.php`

Este arquivo é da frente C. As correções abaixo são a OUTRA METADE de achados da
frente D: o módulo já foi corrigido e já impede o dano sozinho, e o que falta é
o sanitizador — o gravador único — parar de aceitar o valor que produz o dano.
Nenhuma checagem da frente D fica em FALHA por causa destas pendências: cada uma
delas é medida contra o módulo, que é quem serve a requisição.

Além destas, uma correção fora de `options.php` e também fora do alcance da
frente D está no fim, em **Nota sobre `base-site-core-fator3.php`**.

---

## 1. `sanitiza_redirects()` — a MESMA normalização do comparador (achado D-3)

**O defeito medido.** O sanitizador recusa `de === para` comparando o TEXTO CRU;
`F3Base_Modulo_Redirects::casar_declarado()` normaliza barra final e query antes
de casar. O par `/servicos/ → /servicos` passa nos dois e gira para sempre — a
bancada WordPress registrou quatro respostas 3xx seguidas, que é o
`ERR_TOO_MANY_REDIRECTS` do navegador.

**O que a frente D já fez.** `F3Base_Modulo_Redirects::normalizar()` e
`::par_gira()` são funções puras e públicas, e o módulo RECUSA o par na hora de
servir, nomeando-o em `avisos()`. `wp.redirect_nao_gira` e
`redirects.par_que_gira_recusado` fecham OK sem esta mudança.

**Por que fazer assim mesmo.** Um par que nunca pode redirecionar não deveria
chegar a ser gravado: gravá-lo e recusá-lo depois obriga o operador a descobrir
pelo aviso que a regra que ele escreveu não vale.

```diff
--- a/fontes/plugin/includes/class-f3base-options.php
+++ b/fontes/plugin/includes/class-f3base-options.php
@@ sanitiza_redirects()
 			$de   = isset( $regra['de'] ) ? self::sanitiza_caminho( (string) $regra['de'] ) : '';
 			$para = isset( $regra['para'] ) ? self::sanitiza_caminho( (string) $regra['para'] ) : '';
 
-			if ( '' === $de || '' === $para || $de === $para ) {
+			if ( '' === $de || '' === $para ) {
 				continue;
 			}
 
 			$status = isset( $regra['status'] ) ? (int) $regra['status'] : 301;
 			if ( ! in_array( $status, array( 301, 302, 307, 308, 410 ), true ) ) {
 				$status = 301;
 			}
 
+			/*
+			 * A COMPARAÇÃO É A DO COMPARADOR, e não a do texto cru. Quem casa a
+			 * requisição com o par é `F3Base_Modulo_Redirects::casar_declarado()`,
+			 * e ele normaliza barra final e query dos dois lados: recusar aqui
+			 * `$de === $para` deixava passar `/servicos/ → /servicos`, que casa lá
+			 * e devolve o visitante ao mesmo endereço para sempre. O 410 é a
+			 * exceção declarada: ali o destino não é para onde se vai, é só o que
+			 * sobra do par.
+			 */
+			if ( 410 !== $status && F3Base_Modulo_Redirects::par_gira( $de, $para ) ) {
+				continue;
+			}
+
 			$saida[] = self::preservar_desconhecidas(
```

---

## 2. `sanitiza_cabecalhos()` — `csp_frame_ancestors` validado na FORMA (achado D-14)

**O defeito medido.** O valor chega por `sanitize_text_field()`, que PRESERVA o
ponto e vírgula. `frame-ancestors 'self'; script-src 'unsafe-inline'` é uma
segunda diretiva escrita pelo campo da moldura: um CSP inteiro injetado pelo
campo errado, com efeito sobre o carregamento de todo script da página.

**O que a frente D já fez.** `F3Base_Modulo_Cabecalhos::frame_ancestors_na_forma()`
é pura e pública, o módulo NÃO emite o cabeçalho enquanto o valor estiver fora da
forma, e `avisos()` nomeia o valor e o engano. `seguranca.frame_ancestors_na_forma`
fecha OK sem esta mudança.

```diff
--- a/fontes/plugin/includes/class-f3base-options.php
+++ b/fontes/plugin/includes/class-f3base-options.php
@@ sanitiza_cabecalhos()
+		/*
+		 * FORMA, e não só sanitização de texto. `sanitize_text_field()` preserva
+		 * o ponto e vírgula, e o ponto e vírgula ENCERRA a diretiva: o que vem
+		 * depois vira uma política nova. O valor fora da forma é PRESERVADO —
+		 * este pacote não apaga o que alguém gravou — e quem não o emite é o
+		 * módulo, que já avisa por quê. O que muda aqui é o valor NOVO: ele não
+		 * entra no lugar de um valor bom.
+		 */
+		$ancestrais = isset( $valor['csp_frame_ancestors'] )
+			? sanitize_text_field( (string) $valor['csp_frame_ancestors'] )
+			: (string) $padrao['csp_frame_ancestors'];
+
+		if ( '' !== $ancestrais && ! F3Base_Modulo_Cabecalhos::frame_ancestors_na_forma( $ancestrais ) ) {
+			$ancestrais = (string) $padrao['csp_frame_ancestors'];
+		}
+
 		return self::preservar_desconhecidas(
 			array(
 				'x_content_type_options' => isset( $valor['x_content_type_options'] ) ? (bool) $valor['x_content_type_options'] : (bool) $padrao['x_content_type_options'],
 				'x_frame_options'        => $frame,
-				'csp_frame_ancestors'    => isset( $valor['csp_frame_ancestors'] ) ? sanitize_text_field( (string) $valor['csp_frame_ancestors'] ) : (string) $padrao['csp_frame_ancestors'],
+				'csp_frame_ancestors'    => $ancestrais,
```

**Ponto de atenção para C.** A normalização precisa vir com AVISO, como manda a
regra da 1.1.0: um valor trocado em silêncio é o que este pacote parou de fazer.
`f3base_options_avisos` (ou o mecanismo equivalente que C usar para as options de
grupo, achado C-11) é onde a frase entra.

---

## 3. `sanitiza_cabecalhos()` — `permissions_policy` dentro do vocabulário (achado D-15)

**O defeito medido.** `F3Base_Vocabulario::decisoes_governadas()` declarava
governar `cabecalhos.permissions_policy`, e o sanitizador a aceitava por
`sanitize_text_field()` — isto é, aceitava qualquer coisa. Governar no
vocabulário e não reconhecer no runtime é pior que não governar: a linha da
tabela afirma uma recusa que não acontece.

**O que a frente D já fez.** `F3Base_Vocabulario::politicas_de_permissoes()` e
`::ancestrais_de_frame()` declaram os conjuntos, `decisoes_governadas()` passou a
citá-los, e `vocabulario.cabecalhos_governados` cruza o vocabulário com a forma
que o módulo exige e com o padrão do catálogo.

```diff
--- a/fontes/plugin/includes/class-f3base-options.php
+++ b/fontes/plugin/includes/class-f3base-options.php
@@ sanitiza_cabecalhos()
-		$permissoes = isset( $valor['permissions_policy'] ) ? sanitize_text_field( (string) $valor['permissions_policy'] ) : (string) $padrao['permissions_policy'];
+		/*
+		 * O CONJUNTO É O DO VOCABULÁRIO COMPARTILHADO, como já acontece com
+		 * frame, referrer e COOP. Cada capacidade acrescentada a uma
+		 * `Permissions-Policy` desliga um recurso do navegador para o site
+		 * inteiro, e a escolha entre listas mora em `config/decisoes.tsv`, com o
+		 * motivo escrito ao lado.
+		 */
+		$permissoes = isset( $valor['permissions_policy'] ) ? sanitize_text_field( (string) $valor['permissions_policy'] ) : (string) $padrao['permissions_policy'];
+		$permissoes = in_array( $permissoes, F3Base_Vocabulario::politicas_de_permissoes(), true )
+			? $permissoes
+			: (string) $padrao['permissions_policy'];
```

---

## 4. A frase do campo `apresentacao` (achado D-17)

**O que a correção da frente D tornou falso.** O código passou a seguir a frase
do campo `introducao` — "é a primeira frase que um leitor automático encontra" e
"vazia, o site usa a apresentação abaixo". O texto do campo `apresentacao` diz o
contrário na mesma tela: que ela é o texto lido antes da lista e que, VAZIA, o
site "cai para a primeira frase acima". As duas frases não podiam estar certas ao
mesmo tempo, e a que descreve o código é a de `introducao`.

```diff
--- a/fontes/plugin/includes/class-f3base-options.php
+++ b/fontes/plugin/includes/class-f3base-options.php
@@ catálogo, f3base_llms, subcampo apresentacao
-						'impacto'   => __( 'Preenchida, é o texto que um assistente lê antes da lista de links, e é dele que sai a frase com que ele apresenta o site a quem perguntar. É o campo de maior retorno do arquivo inteiro: sem ele, o arquivo é uma lista de endereços e o posicionamento do negócio precisa ser inferido das páginas. Vazia, o site cai para a primeira frase acima e, na falta dela, para a descrição cadastrada no WordPress.', 'f3base' ),
+						'impacto'   => __( 'É o texto que um assistente lê antes da lista de links quando o campo acima está vazio, e é dele que sai a frase com que ele apresenta o site a quem perguntar. É o campo de maior retorno do arquivo inteiro: sem ele e sem a primeira frase, o arquivo é uma lista de endereços e o posicionamento do negócio precisa ser inferido das páginas. Com a primeira frase preenchida, é ELA que sai, e este parágrafo fica de reserva; com os dois vazios, o arquivo usa a descrição cadastrada no WordPress.', 'f3base' ),
```

Quem confere: `seo.llms_primeira_frase_declarada` já exige que o texto do campo
`introducao` continue prometendo o que o código faz. A frase de `apresentacao`
não é conferida por nenhuma checagem hoje — ela é prosa de tela —, e por isso ela
vem aqui como diff e não como pendência de FALHA.

---

## 5. `sanitiza_journal()` — conferência da frente D (achados D-6 e D-11, que são C-8)

**Não há diff da frente D a propor no comportamento do journal**, e o que segue é
a conferência que o prompt pediu.

O módulo `retencao-e-eliminacao` escreve no journal por um caminho só —
`registrar_journal()` — e ele grava EXATAMENTE os sete campos que
`sanitiza_journal()` declara conhecer: `regime`, `identificador`,
`identificador_hash`, `contagem`, `em`, `operador`, `reversivel_ate`. O módulo
**não lê campo nenhum** do journal: ele lê a lista, acrescenta uma entrada e
grava de volta. Portanto:

- o módulo **não depende** de `preservar_desconhecidas()` no journal;
- o módulo **não quebra** se C fizer o sanitizador DESCARTAR o desconhecido, que
  é o que o docblock dele promete e o que C-8 aponta como divergência;
- o único regime novo desta release, a eliminação definitiva em lote (achado
  D-5), usa `regime = 'operacional'` com `reversivel_ate = 0` — dentro do
  vocabulário fechado que o sanitizador já aceita, sem campo novo.

O que C precisa decidir continua sendo o de C-8, e a frente D não tem opinião
sobre ele além desta: **o corte em 500 entradas acontece na LEITURA**, e ele
descarta as MAIS ANTIGAS. Um journal de eliminação existe para provar o que foi
apagado e quando; cortar o começo dele é apagar a prova mais velha primeiro, que
é justamente a que alguém procuraria numa auditoria. Se o corte precisa existir,
ele deveria acontecer na ESCRITA e sair registrado — nunca em silêncio, na
leitura, sobre uma option que ninguém pediu para encurtar.

---

## Nota sobre `base-site-core-fator3.php` (achado D-19)

O docblock de `f3base_site_core_carregar()`, no arquivo principal do plugin, diz:

> «CINCO DESTES ARQUIVOS NÃO MORAM NA FONTE DESTE PLUGIN … Elas moram em
> `partilhado/` no repositório, e o empacotamento as copia para dentro deste zip»

e, logo abaixo:

> «a pasta `fontes/plugin/` do repositório NÃO é instalável como está — faltam
> cinco arquivos»

Neste repositório as duas frases são **falsas**: os cinco moram em
`fontes/plugin/` (quatro em `includes/`, mais `dados/emissores-conhecidos.tsv`),
estão declarados um a um em `suite/inventario.tsv`, e é a própria
`suite/lib/sonda-site-core.php` que registra o fato — «Aqui a fonte do plugin JÁ
É o que fica montado». O arquivo principal é da frente C; a frente D corrigiu os
docblocks das quatro classes partilhadas (medido por
`partilhado.contrato_declarado`) e deixa aqui a metade que não pode tocar.

```diff
--- a/fontes/plugin/base-site-core-fator3.php
+++ b/fontes/plugin/base-site-core-fator3.php
@@ docblock de f3base_site_core_carregar()
- * CINCO DESTES ARQUIVOS NÃO MORAM NA FONTE DESTE PLUGIN, e é preciso dizer
- * qual é o preço. … Elas moram em `partilhado/` no repositório, e o
- * empacotamento as copia para dentro deste zip, no caminho declarado aqui.
- *
- * O QUE ISSO CUSTA, dito por inteiro: a pasta `fontes/plugin/` do repositório
- * NÃO é instalável como está — faltam cinco arquivos.
+ * CINCO DESTES ARQUIVOS SÃO CONTRATO COMPARTILHADO com o implantador —
+ * `class-f3base-chaves-seo.php`, `class-f3base-vocabulario.php`,
+ * `class-f3base-emissores.php`, `class-f3base-censo-demonstrativo.php` e
+ * `dados/emissores-conhecidos.tsv` —, e eles MORAM NESTE REPOSITÓRIO, no
+ * caminho declarado nesta lista: o preflight do implantador precisa das mesmas
+ * regras ANTES de este plugin existir na instalação, e quem carrega uma CÓPIA é
+ * ele, que a vendoriza na árvore dele. A pasta `fontes/plugin/` deste
+ * repositório é instalável como está.
```
