# Rodada 0 — as três mutações, e o que cada detector disse

Este arquivo existe por uma razão só: **detector que nunca foi visto acusando é
afirmação sobre a intenção de quem o escreveu.** A extração deixou de fora boa parte
das checagens da referência, reduziu as sondas e reescreveu o empacotamento;
nada disso prova que o que sobrou continua enxergando. O que prova é plantar o
defeito e ver a linha sair.

Quantas checagens ficaram de fora e por quê está em `suite/excluidas.tsv`, uma
linha por checagem; o que cada linha que ficou emitiu, contra o que o
implantador emitia, está em `rodada-0.diff.tsv`. Nenhum dos dois é resumido
aqui: número copiado para um segundo lugar envelhece no primeiro dia.

Regra das três: **uma por vez, na CÓPIA, e revertida da origem byte a byte.** A
reversão não é `git checkout` nem desfazer a edição — é copiar o arquivo de
`/root/base/src/implantador-base/fontes/plugin/` por cima, e conferir com
`diff -r` que a árvore inteira voltou a ser idêntica à origem. Fonte de plugin
que muda numa tarefa de extração é a tarefa mudando o que ela deveria estar
medindo.

---

## (a) `f3base-tracking.js` sem o ouvinte de `pagehide`

**O comando**

```
python3 -c "
import io
P='fontes/plugin/assets/f3base-tracking.js'
t=io.open(P,encoding='utf-8').read()
a=\"\\t\\twindow.addEventListener('pagehide', enviarResumo);\\n\"
assert t.count(a)==1
io.open(P,'w',encoding='utf-8').write(t.replace(a,'',1))"
bash suite/verificar.sh /root/base/plugin-repo
```

**A linha acusada**

```
FALHA   js.ciclo_de_vida_da_pagina                   — 6 achado(s) em ? unidade(s) medida(s): TETO do envio único (só pagehide, o navegador que não emite o outro): a aba mandou 0 resumo(s). Um por carregamento, sempre; TETO da contagem única (só pagehide, o navegador que não emite o outro): LCP foi contada 0 vez(es) num único carregamento. É o defeito medido em produção: os dois eventos de saída disparam o mesmo relator, cada métrica entra duas vezes no resumo, o resumo é enviado uma vez só, e o relatório mostra o dobro do que aconteceu — sem erro em lugar nenhum; TETO da contagem única (só pagehide, o navegador que não emite o outro): CLS foi contada 0 vez(es) num único carregamento. É o defeito medido em produção: os dois eventos de saída disparam o mesmo relator, cada métrica entra duas vezes no resumo, o resumo é enviado uma vez só, e o relatório mostra o dobro do que aconteceu — sem erro em lugar nenhum; TETO da contagem única (só pagehide, o navegador que não emite o outro): INP foi contada 0 vez(es) num único carregamento. É o defeito medido em produção: os dois eventos de saída disparam o mesmo relator, cada métrica entra duas vezes no resumo, o resumo é enviado uma vez só, e o relatório mostra o dobro do que aconteceu — sem erro em lugar nenhum; TETO da contagem única (só pagehide, o navegador que não emite o outro): TTFB foi contada 0 vez(es) num único carregamento. É o defeito medido em produção: os dois eventos de saída disparam o mesmo relator, cada métrica entra duas vezes no resumo, o resumo é enviado uma vez só, e o relatório mostra o dobro do que aconteceu — sem erro em lugar nenhum; TETO do denominador (só pagehide, o navegador que não emite o outro): o carregamento da página foi contado 0 vez(es). Ele é o denominador de toda proporção da tela, e um denominador dobrado corta toda profundidade de leitura pela metade  [evidência: teste-funcional/build]
```

**O que isso ensina, e é o motivo de a mutação ter sido esta.** A tarefa admitia
duas acusadoras — `estatica.saida_com_trava_de_uma_vez` ou
`js.ciclo_de_vida_da_pagina` — e só a segunda falou. A primeira ficou verde:

```
OK      estatica.saida_com_trava_de_uma_vez          — tod
```

Ela está certa em calar. O que ela mede é a **trava de uma vez** do emissor
ligado a mais de um evento de saída, e a trava continuou lá — o que sumiu foi um
dos dois ouvintes. Quem mede o COMPORTAMENTO é a bancada de JavaScript, que roda
o cliente real contra um escalonador e conta os resumos que a aba mandou: com um
ouvinte só, o navegador que não emite o outro evento manda zero resumo. Um
detector estático mede a forma; o comportamento se mede executando. As duas
linhas existem por isso, e a mutação separou uma da outra.

**Reversão**

```
cp /root/base/src/implantador-base/fontes/plugin/assets/f3base-tracking.js fontes/plugin/assets/f3base-tracking.js
diff -r /root/base/src/implantador-base/fontes/plugin fontes/plugin
```

---

## (b) `update_option()` direto — e ONDE ele está muda tudo

A mutação foi plantada **duas vezes**, e a diferença entre as duas é a resposta
inteira.

### (b1) dentro de `class-f3base-options.php`, que é o gravador declarado

**O comando**

```
python3 -c "
import io
P='fontes/plugin/includes/class-f3base-options.php'
t=io.open(P,encoding='utf-8').read()
a='\tpublic static function segredos_do_site(): array {'
b='\tpublic static function mutacao_da_rodada_zero(): void {\n\t\tupdate_option( \'f3base_mutacao_rodada_zero\', 1 );\n\t}\n\n'+a
io.open(P,'w',encoding='utf-8').write(t.replace(a,b,1))"
bash suite/verificar.sh /root/base/plugin-repo
```

**O que saiu**

```
(nenhuma linha adversa: a rodada fechou sem FALHA, sem BLOCKED e sem WARN)
```

**Nada, e é o desenho.** `estatica.detector_escrita_unica` isenta os arquivos que
ela DECLARA como gravadores, e neste repositório há um só:
`fontes/plugin/includes/class-f3base-options.php`. Escrever option ali é o que
aquele arquivo existe para fazer — é ele que tem o catálogo, a sanitização que
preserva a chave desconhecida e a procedência. Um detector que acusasse o
gravador de gravar acusaria o pacote correto, e detector que reprova o correto é
o mais caro de todos: ensina a ignorá-lo.

Fica registrado porque o enunciado da tarefa dizia "`class-f3base-options.php`
com um `update_option()` direto fora do gravador", e esse par de palavras não
tem referente: dentro daquele arquivo não existe "fora do gravador". O que
existe é a mutação de baixo.

### (b2) o MESMO `update_option()`, em um módulo

**O comando**

```
python3 -c "
import io
P='fontes/plugin/includes/class-f3base-modulo-tracking.php'
t=io.open(P,encoding='utf-8').read()
i=t.index('\tpublic function ')
b='\tpublic static function mutacao_da_rodada_zero(): void {\n\t\tupdate_option( \'f3base_mutacao_rodada_zero\', 1 );\n\t}\n\n'
io.open(P,'w',encoding='utf-8').write(t[:i]+b+t[i:])"
bash suite/verificar.sh /root/base/plugin-repo
```

**A linha acusada**

```
FALHA   estatica.detector_escrita_unica              — 1 achado(s) em 52 unidade(s) medida(s): fontes/plugin/includes/class-f3base-modulo-tracking.php:123 update_option()  [evidência: analise-estatica/build]
```

Arquivo e linha nomeados. É a mesma função que rodou verde contra o pacote
intacto, com o mesmo número de unidades medidas: o que mudou foi o pacote.

**Reversão**

```
cp /root/base/src/implantador-base/fontes/plugin/includes/class-f3base-options.php fontes/plugin/includes/
cp /root/base/src/implantador-base/fontes/plugin/includes/class-f3base-modulo-tracking.php fontes/plugin/includes/
diff -r /root/base/src/implantador-base/fontes/plugin fontes/plugin
```

---

## (c) um número alterado DENTRO de uma região gerada do `INSTRUCOES-DO-PLUGIN.md`

**O comando**

```
python3 -c "
import io
P='fontes/plugin/INSTRUCOES-DO-PLUGIN.md'
t=io.open(P,encoding='utf-8').read()
io.open(P,'w',encoding='utf-8').write(t.replace('| Módulos no registro único | 16 |','| Módulos no registro único | 42 |',1))"
```

**A linha acusada — o detector, chamado como o piso o chama**

```
ACUSA: fontes/plugin/INSTRUCOES-DO-PLUGIN.md: a região "plugin-identidade" está DIVERGENTE da medição de agora — o documento afirma um número que a leitura de disco contradiz. Número em documento entregável é gerado no empacotamento, nunca digitado
```

**E pelo comando único, a acusação tem outra forma: o build CONSERTA e NOMEIA.**

```
documentos regenerados: fontes/plugin/INSTRUCOES-DO-PLUGIN.md
```

Depois da rodada, o documento em disco:

```
23:| Módulos no registro único | 16 |
```

**Por que as duas formas são a mesma prova, e por que a segunda não é um
detector cego.** A etapa 1 do comando único REGENERA as regiões marcadas antes
de montar o zip — de propósito, para que o artefato publicado nunca leve o
carimbo da rodada anterior. Consequência: numa rodada completa o número
digitado à mão não sobrevive até a etapa 2, e
`estatica.carimbo_de_release_nos_documentos` fecha OK sobre um documento que
acabou de ser corrigido. O que a rodada imprime é a linha `documentos
regenerados:`, que NOMEIA o arquivo — o que era um número mentindo em silêncio
virou uma linha no log de toda rodada.

Quem prova que o detector sabe reprovar é o piso, que roda a MESMA função contra
a fixture negativa sem passar pelo gerador. Essa fixture teve de MUDAR nesta
extração, e a mudança está declarada dentro dela: no implantador o defeito era
plantado no `carimbo` de README, MANIFESTO e MEMORIA-DECISOES, que são
entregáveis dele; aqui a única região gerada que existe é a do documento que
viaja dentro do zip do plugin, e uma fixture que continuasse plantando o defeito
em documento que o detector não mede mais não reprovaria nada.

**Reversão**

```
cp /root/base/src/implantador-base/fontes/plugin/INSTRUCOES-DO-PLUGIN.md fontes/plugin/INSTRUCOES-DO-PLUGIN.md
diff -r /root/base/src/implantador-base/fontes/plugin fontes/plugin
```

---

## Estado final

`diff -r` entre `/root/base/src/implantador-base/fontes/plugin` e
`fontes/plugin` deste repositório não devolve nenhuma diferença de conteúdo — só
os cinco arquivos que vieram de `partilhado/` e que, por desenho, existem aqui e
não lá. Nenhuma das três mutações sobreviveu.
