<?php
/**
 * Os oito entregáveis.
 *
 * Entregável ausente é BLOCKED COM O NOME DO ARQUIVO QUE FALTA — nunca ausência
 * silenciosa, nunca FALHA. O caso medido: um pacote sem suíte, sem leia-me e sem
 * memória fechou o relatório com zero falhas e se autodesativou dizendo OK.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Confere presença de caminhos e devolve os que faltam.
 *
 * @param string            $raiz     Raiz.
 * @param array<int,string> $caminhos Caminhos relativos obrigatórios.
 * @return array<int,string>
 */
function f3b_faltando( string $raiz, array $caminhos ): array {
	$faltam = array();

	foreach ( $caminhos as $rel ) {
		if ( str_ends_with( $rel, '/' ) ) {
			if ( array() === f3b_arquivos( $raiz . '/' . rtrim( $rel, '/' ) ) ) {
				$faltam[] = $rel . ' (diretório vazio ou ausente)';
			}

			continue;
		}

		if ( ! is_file( $raiz . '/' . $rel ) ) {
			$faltam[] = $rel;
		}
	}

	return $faltam;
}

/**
 * Mapa dos oito entregáveis: nome da checagem => caminhos obrigatórios.
 *
 * Os caminhos de conteúdo e de blog são DERIVADOS da configuração, nunca de
 * lista fechada no código: é o `site.json` que declara quais páginas e quais
 * posts a release entrega.
 *
 * @param string $raiz Raiz.
 * @return array<string,array<int,string>>
 */
function f3b_entregaveis( string $raiz ): array {
	unset( $raiz );

	return array(
		'entrega.site_core'   => array(
			'fontes/plugin/base-site-core-fator3.php',
			'fontes/plugin/uninstall.php',
			'fontes/plugin/includes/class-f3base-plugin.php',
			'fontes/plugin/includes/class-f3base-registro.php',
			'fontes/plugin/includes/class-f3base-options.php',
		),
	);
}

/**
 * Um entregável.
 *
 * @param string $raiz Raiz.
 * @param string $nome Nome da checagem.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_entregavel( string $raiz, string $nome ): array {
	$mapa = f3b_entregaveis( $raiz );

	if ( ! isset( $mapa[ $nome ] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'entregável desconhecido: ' . $nome ),
		);
	}

	if ( array() === $mapa[ $nome ] ) {
		return array(
			'ok'      => false,
			'achados' => array( 'a configuração não declara nenhum item para este entregável' ),
		);
	}

	$faltam = f3b_faltando( $raiz, $mapa[ $nome ] );

	return array(
		'ok'      => array() === $faltam,
		'achados' => $faltam,
	);
}
