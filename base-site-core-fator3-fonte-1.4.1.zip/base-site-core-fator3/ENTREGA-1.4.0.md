# Base Site Core Fator3 — 1.4.0

Entrega de **11 de setembro de 2026**, sobre a versão 1.3.0. Mantém as melhorias anteriores de configuração independente, descoberta de logs, medição de hoje, coleta diária e publicação textual. O plugin permanece autocontido; o implantador não é necessário.

## Robots.txt: ativação e restauração

| Situação | Comportamento |
|---|---|
| Ligar “Utilizar o robots.txt do plugin” com arquivo físico | Salva o original integral no banco, confere a gravação e retira `robots.txt` do caminho público. Mantém uma reserva no mesmo diretório. |
| Opção ligada | O WordPress entrega o robots virtual, complementado pelo plugin com o sitemap disponível. |
| Desligar a opção com caminho livre | Restaura os bytes e as permissões do original. |
| Desligar quando já existe outro arquivo | Preserva o arquivo encontrado, sem sobrescrevê-lo. |
| Nunca existiu um original | Não inventa um arquivo ao desligar; a resposta virtual padrão do WordPress pode continuar disponível. |
| Desativar o plugin | Suspende a troca e tenta restaurar o original, com as mesmas condições. Reativar retoma a preferência salva. |
| Atualizar com a opção já ligada | A primeira requisição que carrega o WordPress reconcilia a troca, sem exigir reativação. |
| Arquivo criado por terceiro durante o uso do gerador | Preserva arquivo e backup e informa conflito. Desligar e ligar novamente adota esse arquivo como original do novo ciclo. |

**As regras exclusivas do arquivo físico ficam no backup; não são importadas para o gerador.** A resposta ativa utiliza as regras virtuais do WordPress e de seus filtros, mais o sitemap disponível. Assim, um bloqueio de bot que só existia no arquivo original deixa de valer durante o uso do gerador e volta quando o original é restaurado.

O gerador mantém o formato textual, o caminho `/robots.txt` e as regras do núcleo, incluindo a exceção de `admin-ajax.php`. Não cria grupos de bots de IA nem acrescenta `Noindex:` ou diretivas não padronizadas. Grupos e regras de filtros de terceiros são preservados. Essas escolhas seguem o [RFC 9309](https://www.rfc-editor.org/rfc/rfc9309.html) e o [gerador de robots do WordPress](https://developer.wordpress.org/reference/functions/do_robots/).

### Integridade e recuperação

O backup usa Base64 e SHA-256 para preservar os bytes, incluindo BOM e quebras de linha. A opção `f3base_robots_backup` não usa autoload e permanece após a desinstalação. Uma reserva física permite recuperar interrupções após a retirada do arquivo; se essa reserva desaparecer, o banco permite reconstruir o original.

A trava de arquivo e a releitura das opções dentro dela coordenam requisições concorrentes. A restauração prepara e confere o conteúdo antes de publicá-lo por hard link, sem sobrescrever um destino surgido em paralelo. O marcador de suspensão impede que uma requisição antiga recapture o original após a desativação.

Falhas de banco, permissões, checksum, tamanho ou conflito aparecem no retorno da gravação e no diagnóstico do módulo. O plugin não remove um arquivo sem confirmar o backup. O limite do original é **1 MiB**; arquivos maiores, links simbólicos e objetos que não sejam arquivos regulares são preservados.

A troca automática exige WordPress de site único, home na raiz do domínio, raiz pública confirmada e permissões para as operações de arquivo. Multisite e home em subdiretório recebem diagnóstico, sem escrita automática na raiz compartilhada. Instalações com o núcleo em subpasta podem ser resolvidas a partir de `ABSPATH` e das URLs configuradas; a decisão de escrita não depende de HOME nem de `SCRIPT_FILENAME`. A distinção entre raiz pública e diretório do núcleo é documentada pelo [WordPress](https://developer.wordpress.org/reference/functions/get_home_path/).

Cache, CDN e regras do servidor podem manter uma resposta anterior mesmo após a troca local. Os testes desta entrega não substituem uma conferência posterior na hospedagem de destino.

## Llms-full.txt

**O endpoint já existia e foi atualizado.** Continua opcional, desligado por padrão e anunciado em `Optional` no índice quando disponível. A opção é `f3base_llms.full`; o campo de Markdown por página é independente.

O índice permanece conciso. O full reúne o **corpo editorial completo dos itens selecionados**, sem aplicar o limite de palavras do resumo. Mantém título do site, apresentação, título e URL de cada item, data disponível e corpo em Markdown. Títulos internos ficam abaixo da seção do item; listas, links, citações e código conservam sua estrutura. O arquivo recebe a relação HTTP `describedby` para o índice.

A [proposta llms.txt v2](https://llmstxt.org/) organiza o índice com título, resumo e listas de links para conteúdo em Markdown, com descoberta por relações de link. O full é um recurso complementar: seu corpo integral não é convertido em outra lista resumida de links. A proposta não torna esse arquivo obrigatório nem garante citações por ferramentas de IA.

Índice, full e alternativas por página compartilham a seleção pública, deduplicação, exclusões e teto global de **200 itens**. Rascunhos, privados, conteúdo com senha, noindex reconhecido pelo plugin e a política de privacidade excluída pela configuração não entram. A visibilidade do WordPress suspende a publicação automática. GET e HEAD são atendidos; POST não publica o recurso.

O conteúdo vem do texto editorial armazenado. Formulários, scripts, elementos ocultos e shortcodes registrados são removidos, sem executar blocos dinâmicos ou buscar conteúdo remoto. Sem a extensão DOM, o texto integral permanece, com formatação reduzida. Referências externas da curadoria recebem a descrição disponível. Arquivos físicos de `llms.txt` e `llms-full.txt` conservam a precedência existente; a transferência automática desta versão aplica-se a robots.txt.

## Validação

A execução completa de `suite/verificar.sh` fechou com **155 OK, zero FALHA, zero BLOCKED e 13 N/A**, em WordPress 7.1 com PHP 8.3 e SQLite. Os N/A correspondem a condições externas/de fase e ao cenário de navegador sem Chromium disponível; não são contados como testes aprovados.

Os novos cenários verificam formulário administrativo autenticado, respostas GET/HEAD, backup e restauração exatos, permissões, ausência de original, arquivo de terceiro, recuperação pelo banco, falha de persistência, operações PHP indisponíveis, limite, checksum, interrupção após rename, raiz divergente, dois processos concorrentes e desativação/reativação real.

O full foi verificado por HTTP com corpo longo e marcador final, títulos, listas, links, código com quebras internas, exclusões e opção de Markdown por página desligada. As regressões anteriores de acessos e configuração também passaram.

Os testes de mutação de publicação detectaram **12 defeitos reintroduzidos** em cópias isoladas. Um patch antigo de endereço precisou de ajuste de contexto; a repetição direcionada confirmou sua detecção. O consolidado usa o resultado final de cada mutante e conserva as duas execuções brutas. O relatório final dessa execução está em `dist/validacao-1.4.0/piso-publicacao.ndjson`. Evidências da rodada positiva: `verificacao.log`, `rodada.json` e respostas HTTP sintéticas no mesmo diretório. Os exemplos com endereço localhost e conteúdo de teste não devem ser publicados no site.

## Instalação e fontes

Instale `base-site-core-fator3-1.4.0.zip`, substituindo a versão anterior. A opção de robots já ligada pode iniciar a transferência na primeira requisição ao WordPress. Para usar o full, habilite seu campo na configuração de llms.

`base-site-core-fator3-fonte-1.4.0.zip` contém fontes, testes, mutantes, documentação, evidências, instalador e histórico Git em bundle. O manifesto SHA-256 acompanha a entrega. Esta entrega gera os pacotes; não instala a versão nem altera arquivos no site conectado.
