<?php
/** Aba Acessos: consultas limitadas, com totais independentes do limite da tela. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Admin_Acessos {
	public const TETO_PAGINAS = 200;
	public const PERIODOS = array( 1, 2, 3, 4, 5, 6, 7, 15, 30, 60, 90 );
	private static function periodo( $valor ): int {
		return is_scalar( $valor ) && in_array( (int) $valor, self::PERIODOS, true ) ? (int) $valor : 90;
	}
	public static function abas(): void {
		$ativa = isset( $_GET['aba'] ) && 'acessos' === $_GET['aba'];
		echo '<nav class="nav-tab-wrapper" aria-label="Medição">';
		foreach ( array( 'comportamento' => 'Comportamento', 'acessos' => 'Acessos' ) as $slug => $nome ) {
			$url = add_query_arg( array( 'page' => F3Base_Admin_Medicao::SLUG, 'aba' => $slug ), admin_url( 'admin.php' ) );
			printf( '<a class="nav-tab%s" href="%s">%s</a>', ( $ativa === ( 'acessos' === $slug ) ) ? ' nav-tab-active' : '', esc_url( $url ), esc_html( $nome ) );
		}
		echo '</nav>';
	}
	public static function somar(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Sem permissão.', '', array( 'response' => 403 ) ); }
		check_admin_referer( 'f3base_acessos_somar' );
		( new F3Base_Modulo_Acessos_Servidor() )->somar();
		wp_safe_redirect( add_query_arg( array( 'page' => F3Base_Admin_Medicao::SLUG, 'aba' => 'acessos', 'dias' => self::periodo( $_POST['dias'] ?? 90 ), 'incluir_erros' => isset( $_POST['incluir_erros'] ) && '1' === $_POST['incluir_erros'] ? '1' : '0' ), admin_url( 'admin.php' ) ) );
		exit;
	}
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$dias = self::periodo( $_GET['dias'] ?? 90 );
		$erros = isset( $_GET['incluir_erros'] ) && '1' === $_GET['incluir_erros'];
		$r = F3Base_Modulo_Acessos_Servidor::consultar( $dias, '', '', $erros, 0, true );
		$hoje = F3Base_Acessos_Atuais::ler();
		$vivo = array_values( array_filter( $hoje['linhas'], static fn( $l ) => $l['status'] >= 200 && $l['status'] <= ( $erros ? 599 : 399 ) ) );
		foreach ( $vivo as $l ) { if ( isset( $r['totais'][ $l['classe_caminho'] ] ) ) { $r['totais'][ $l['classe_caminho'] ] += $l['contagem']; } }
		echo '<h2>Acessos por página</h2>';
		printf( '<p><strong>%s</strong>: %s</p>', esc_html( $r['estado']['estado'] ), esc_html( $r['estado']['motivo'] ) );
		foreach ( ( new F3Base_Modulo_Acessos_Servidor() )->avisos() as $aviso ) { printf( '<p class="notice notice-warning">%s</p>', esc_html( $aviso['motivo'] ) ); }
		echo '<form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="aba" value="acessos"><label>Período <select name="dias">';
		foreach ( self::PERIODOS as $n ) { printf( '<option value="%d" %s>%d dias</option>', $n, selected( $dias, $n, false ), $n ); }
		echo '</select></label> ';
		printf( '<label><input type="checkbox" name="incluir_erros" value="1" %s> Incluir 4xx/5xx</label> ', checked( $erros, true, false ) );
		submit_button( 'Atualizar', 'secondary', '', false );
		echo '</form><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="f3base_acessos_somar">';
		printf( '<input type="hidden" name="dias" value="%d"><input type="hidden" name="incluir_erros" value="%d">', $dias, $erros ? 1 : 0 );
		wp_nonce_field( 'f3base_acessos_somar' );
		submit_button( 'Coletar e Armazenar Logs', 'secondary' );
		echo '</form>';
		printf( '<p>Período: %s a %s, incluindo hoje. Dias armazenados: %d de %d anteriores. Último dia armazenado: %s.</p>', esc_html( $r['inicio'] ), esc_html( $r['fim'] ), $r['dias_somados'], $dias - 1, esc_html( $r['ultimo_dia'] ?: 'nenhum' ) );
		if ( $hoje['erro'] ) { printf( '<p class="notice notice-warning">Hoje indisponível: %s. Os totais abaixo contêm apenas o histórico disponível.</p>', esc_html( $hoje['erro'] ) ); }
		else { printf( '<p>Hoje (%s): parcial. Leitura atualizada em %s (%s); %d linhas ignoradas.</p>', esc_html( $hoje['dia'] ), esc_html( wp_date( 'd/m/Y H:i:s', $hoje['atualizado'] ) ), esc_html( wp_timezone_string() ), $hoje['ignoradas'] ); }
		echo '<p>Atualizar relê o access.log e recalcula esta tela. Hoje não é armazenado. A contagem considera as linhas completas de hoje ainda presentes no arquivo atual; a rotação e o atraso de escrita do servidor podem reduzir a cobertura. Clique novamente para acompanhar novas requisições.</p>';
		self::agendamento();
		echo '<p>No histórico, a data é o dia do arquivo rotacionado do servidor. Hoje usa o horário de cada requisição convertido ao fuso do WordPress. A classificação aceita o User-Agent declarado. Humanos são requisições; pessoas medidas são identificadores distintos registrados no navegador. Repetições, consentimento, retenção e cache afetam essa comparação. A diferença não mede quantos robôs existem.</p>';
		$c = F3Base_Options::ler( 'f3base_comportamento' );
		printf( '<p>O registro detalhado guarda até %d dias e usa dias UTC. Períodos sem registro detalhado disponível aparecem como “—”; a cobertura dos logs depende dos arquivos ainda disponíveis no host.</p>', (int) $c['retencao_eventos_dias'] );
		self::tabelas( $r, $erros, $vivo );
		echo '<p>Família declarada pelo agente, não verificada. Humano = agente que não se declarou robô.</p>';
		printf( '<p>Totais fora das páginas, com o mesmo filtro de status: excluídos %d; estáticos %d; outros/excedentes %d.</p>', $r['totais']['excluido'], $r['totais']['estatico'], $r['totais']['outro'] );
		echo '<p>' . esc_html( F3Base_Atividade::descrever( 'ultima_soma_acessos', 'Última soma' ) ) . '</p>';
		echo '<p>A janela cresce com os dias somados. Dias que o host apagou e acessos atendidos exclusivamente pela CDN não entram no histórico. As classes busca, treino e resposta representam a finalidade declarada, sem comprovar o uso posterior do conteúdo.</p>';
	}
	private static function agendamento(): void {
		if ( empty( F3Base_Modulo_Acessos_Servidor::config()['ligado'] ) ) { echo '<p>Coleta automática desligada.</p>'; return; }
		$proximo = wp_next_scheduled( F3Base_Modulo_Acessos_Servidor::EVENTO );
		printf( '<p>Coleta automática diária às 09:00 UTC. Próxima execução prevista: %s. Coleta e armazena somente logs datados de dias anteriores; ignora access.log, access.log.0 e arquivos datados de hoje.</p>', esc_html( $proximo ? wp_date( 'd/m/Y H:i:s', $proximo ) . ' (' . wp_timezone_string() . ')' : 'agendamento não confirmado' ) );
		if ( $proximo && $proximo < time() ) { echo '<p class="notice notice-warning">Coleta agendada em atraso; verifique o acionamento do WP-Cron.</p>'; }
		echo '<p>O WP-Cron depende de requisições ao site; em sites sem tráfego, use uma tarefa cron do servidor para acioná-lo regularmente.</p>';
		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) { echo '<p>Acionamento automático do WP-Cron desabilitado nesta instalação: a tarefa cron do servidor precisa estar configurada.</p>'; }
	}
	/** Une os líderes históricos a TODOS os grupos de hoje antes de limitar. */
	private static function ranking( string $where, array $vivo, bool $desc ): array {
		global $wpdb;
		$t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
		$grupo = $desc ? 'caminho,classe_caminho,agente' : 'caminho';
		$soma = $desc ? 'SUM(contagem)' : "SUM(CASE WHEN agente = 'humano' THEN contagem ELSE 0 END)";
		$where .= $desc ? " AND classe_caminho IN ('descoberta','api')" : " AND classe_caminho = 'pagina'";
		$chave = static fn( $l ) => wp_json_encode( $desc ? array( $l['caminho'], $l['classe_caminho'], $l['agente'] ) : array( $l['caminho'] ) );
		$atuais = array(); $caminhos = array(); $historico = array(); $total = 0;
		foreach ( $vivo as $l ) {
			if ( ! in_array( $l['classe_caminho'], $desc ? array( 'descoberta', 'api' ) : array( 'pagina' ), true ) ) { continue; }
			$k = $chave( $l ); $caminhos[ $l['caminho'] ] = true;
			if ( ! isset( $atuais[ $k ] ) ) { $atuais[ $k ] = $l; $atuais[ $k ]['total'] = 0; }
			$atuais[ $k ]['total'] += $desc || 'humano' === $l['agente'] ? (int) $l['contagem'] : 0;
		}
		if ( F3Base_Modulo_Acessos_Servidor::tabela_pronta() ) {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM (SELECT 1 FROM {$t} WHERE {$where} GROUP BY {$grupo}) f3base_ranking" );
			$sql = "SELECT {$grupo},{$soma} AS total FROM {$t} WHERE {$where}";
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "{$sql} GROUP BY {$grupo} ORDER BY total DESC,{$grupo} LIMIT %d", self::TETO_PAGINAS ), ARRAY_A ) as $l ) { $historico[ $chave( $l ) ] = $l; }
			// Um grupo com novos acessos pode entrar no topo mesmo estando fora do limite histórico.
			foreach ( array_chunk( array_keys( $caminhos ), 200 ) as $lote ) {
				$in = implode( ',', array_fill( 0, count( $lote ), '%s' ) );
				foreach ( (array) $wpdb->get_results( $wpdb->prepare( "{$sql} AND caminho IN ({$in}) GROUP BY {$grupo}", $lote ), ARRAY_A ) as $l ) { $historico[ $chave( $l ) ] = $l; }
			}
		}
		foreach ( $atuais as $k => $l ) {
			if ( isset( $historico[ $k ] ) ) { $historico[ $k ]['total'] = (int) $historico[ $k ]['total'] + $l['total']; }
			else { $historico[ $k ] = $l; ++$total; }
		}
		usort( $historico, static function ( $a, $b ) use ( $desc ): int {
			return ( (int) $b['total'] <=> (int) $a['total'] ) ?: strcmp( $a['caminho'], $b['caminho'] ) ?: ( $desc ? ( strcmp( $a['classe_caminho'], $b['classe_caminho'] ) ?: strcmp( $a['agente'], $b['agente'] ) ) : 0 );
		} );
		return array( array_slice( $historico, 0, self::TETO_PAGINAS ), $total );
	}
	private static function tabelas( array $r, bool $erros, array $vivo ): void {
		global $wpdb;
		$t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
		$where = $wpdb->prepare( 'dia >= %s AND dia < %s', $r['inicio'], $r['fim'] ) . ( $erros ? ' AND status BETWEEN 200 AND 599' : ' AND status BETWEEN 200 AND 399' );
		[ $ranking, $total ] = self::ranking( $where, $vivo, false );
		$paginas = array_column( $ranking, 'caminho' );
		$mapa = array();
		foreach ( $paginas as $p ) { $mapa[ $p ] = array( 'humano' => 0, 'busca' => 0, 'treino-ia' => 0, 'resposta-ia' => 0, 'outros' => 0, 'familias' => array() ); }
		$pessoas = array();
		if ( $paginas ) {
			$in = implode( ',', array_fill( 0, count( $paginas ), '%s' ) );
			$linhas = F3Base_Modulo_Acessos_Servidor::tabela_pronta() ? $wpdb->get_results( $wpdb->prepare( "SELECT caminho,agente,SUM(contagem) AS contagem FROM {$t} WHERE {$where} AND classe_caminho = 'pagina' AND caminho IN ({$in}) GROUP BY caminho,agente", $paginas ), ARRAY_A ) : array();
			foreach ( $vivo as $l ) { if ( 'pagina' === $l['classe_caminho'] && isset( $mapa[ $l['caminho'] ] ) ) { $linhas[] = $l; } }
			$familias = array();
			foreach ( (array) $linhas as $l ) { $k = wp_json_encode( array( $l['caminho'], $l['agente'] ) ); if ( isset( $familias[ $k ] ) ) { $familias[ $k ]['contagem'] += (int) $l['contagem']; } else { $familias[ $k ] = $l; } }
			$linhas = array_values( $familias );
			foreach ( (array) $linhas as $l ) {
				$classe = F3Base_Modulo_Acessos_Servidor::classe_agente( $l['agente'] );
				$coluna = in_array( $classe, array( 'humano', 'busca', 'treino-ia', 'resposta-ia' ), true ) ? $classe : 'outros';
				$mapa[ $l['caminho'] ][ $coluna ] += (int) $l['contagem'];
				$mapa[ $l['caminho'] ]['familias'][] = $l['agente'] . ': ' . $l['contagem'];
			}
			if ( F3Base_Modulo_Comportamento::eventos_prontos() ) {
				$eventos = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA_EVENTOS;
				foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT caminho,COUNT(DISTINCT visitante) AS pessoas FROM {$eventos} WHERE dia >= %s AND dia <= %s AND visitante <> '' AND caminho IN ({$in}) GROUP BY caminho", array_merge( array( $r['inicio'], $r['fim'] ), $paginas ) ), ARRAY_A ) as $l ) { $pessoas[ $l['caminho'] ] = (int) $l['pessoas']; }
			}
		}
		$titulos = get_transient( 'f3base_acessos_titulos' );
		$titulos = is_array( $titulos ) ? $titulos : array();
		echo '<table class="widefat striped"><thead><tr><th>Página</th><th>Humanos (log)</th><th>Pessoas medidas</th><th>Busca</th><th>Treino IA</th><th>Resposta IA</th><th>Outros robôs</th></tr></thead><tbody>';
		foreach ( $mapa as $p => $m ) {
			if ( ! array_key_exists( $p, $titulos ) ) {
				$origin = wp_parse_url( home_url() );
				$url = $origin['scheme'] . '://' . $origin['host'] . ( isset( $origin['port'] ) ? ':' . $origin['port'] : '' ) . $p;
				$id = url_to_postid( $url ); $titulos[ $p ] = $id ? get_the_title( $id ) : '';
			}
			printf( '<tr><td>%s<br><code>%s</code><details><summary>Por família</summary>%s</details></td><td>%d</td><td>%s</td><td>%d</td><td>%d</td><td>%d</td><td title="%s">%d</td></tr>', esc_html( $titulos[ $p ] ), esc_html( $p ), esc_html( implode( '; ', $m['familias'] ) ), $m['humano'], esc_html( isset( $pessoas[ $p ] ) ? (string) $pessoas[ $p ] : '—' ), $m['busca'], $m['treino-ia'], $m['resposta-ia'], esc_attr( implode( '; ', $m['familias'] ) ), $m['outros'] );
		}
		if ( ! $mapa ) { echo '<tr><td colspan="7">Nenhuma página encontrada neste período e filtro.</td></tr>'; }
		echo '</tbody></table>';
		set_transient( 'f3base_acessos_titulos', array_slice( $titulos, -1000, null, true ), DAY_IN_SECONDS );
		printf( '<p>Exibindo %d de %d páginas; ordenação por requisições humanas. Detalhamento e paginação do histórico até ontem disponíveis em f3base/acessos-ler.</p>', count( $mapa ), $total );
		[ $desc, $total_desc ] = self::ranking( $where, $vivo, true );
		echo '<h2>Descoberta e APIs por família</h2><table class="widefat striped"><thead><tr><th>Caminho</th><th>Classe</th><th>Família</th><th>Requisições</th></tr></thead><tbody>';
		foreach ( $desc as $l ) { printf( '<tr><td><code>%s</code></td><td>%s</td><td>%s</td><td>%d</td></tr>', esc_html( $l['caminho'] ), esc_html( $l['classe_caminho'] ), esc_html( $l['agente'] ), (int) $l['total'] ); }
		if ( ! $desc ) { echo '<tr><td colspan="4">Nenhum acesso de descoberta ou API no período.</td></tr>'; }
		echo '</tbody></table>';
		printf( '<p>Exibindo %d de %d combinações de caminho e família.</p>', count( $desc ), $total_desc );
	}
}
