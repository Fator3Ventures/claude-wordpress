<?php
/**
 * Emissores de tag conhecidos: a DECLARAÇÃO e o VEREDITO, num lugar só.
 *
 * POR QUE ESTA CLASSE EXISTE, e por que ela não tem pai nem dependência.
 *
 * A regra do segundo emissor precisa rodar em dois runtimes que não se
 * enxergam: no `site-core`, para que o estado do módulo `tracking` diga se há
 * emissor concorrente, e no IMPLANTADOR, no preflight — que roda ANTES de o
 * `site-core` existir na instalação, e portanto não pode chamar nada dele.
 *
 * Duas cópias da mesma regra divergiriam na primeira condição acrescentada. Por
 * isso a REGRA é uma só, e ela MORA NESTE REPOSITÓRIO, em
 * `fontes/plugin/includes/`: é daqui que o zip a leva, e é daqui que o
 * implantador VENDORIZA a cópia que ele carrega por `require_once` na árvore
 * dele. A guarda de `class_exists` existe porque os dois caminhos de arquivo
 * são diferentes e `require_once` não os reconhece como o mesmo — as duas
 * cópias podem estar carregadas no mesmo processo.
 *
 * A classe não estende `F3Base_Modulo` e não usa nada do WordPress além de
 * `__()`, de propósito: o implantador não tem a hierarquia de módulos do
 * `site-core`, e uma dependência aqui devolveria as duas cópias.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'F3Base_Emissores' ) ) {

	/**
	 * Lista declarada de emissores e o veredito de emissão de cada slug.
	 */
	final class F3Base_Emissores {

		/**
		 * Nome do arquivo de declaração, relativo ao diretório do plugin.
		 */
		public const ARQUIVO = 'dados/emissores-conhecidos.tsv';

		/**
		 * Vocabulário FECHADO do veredito de emissão.
		 */
		public const LEITOR      = 'leitor';
		public const CONCORRENTE = 'concorrente';
		public const NAO_MEDIDO  = 'nao-medido';

		/**
		 * A declaração lida do arquivo TSV informado.
		 *
		 * A lista é DICA, e está escrito no próprio arquivo: quem decide é a
		 * medição do HTML publicado. Slug fora dela que emita é pego pelo HTML;
		 * slug dentro dela que não emita fecha `leitor`.
		 *
		 * @param string $arquivo Caminho absoluto do TSV declarado.
		 * @return array<string,array<string,mixed>> Slug => declaração.
		 */
		public static function declarados( string $arquivo ): array {
			if ( '' === $arquivo || ! is_file( $arquivo ) || ! is_readable( $arquivo ) ) {
				return array();
			}

			$saida = array();

			foreach ( (array) file( $arquivo, FILE_IGNORE_NEW_LINES ) as $linha ) {
				$linha = (string) $linha;

				if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
					continue;
				}

				$colunas = explode( "\t", $linha );

				if ( count( $colunas ) < 7 ) {
					continue;
				}

				$slug = trim( $colunas[0] );

				if ( '' === $slug ) {
					continue;
				}

				if ( ! isset( $saida[ $slug ] ) ) {
					$saida[ $slug ] = array(
						'fornecedor' => trim( $colunas[1] ),
						'condicoes'  => array(),
						'chave_seo'  => trim( $colunas[5] ),
						'notas'      => array(),
					);
				}

				if ( '' !== trim( $colunas[2] ) && '' !== trim( $colunas[3] ) ) {
					$saida[ $slug ]['condicoes'][] = array(
						'option' => trim( $colunas[2] ),
						'chave'  => trim( $colunas[3] ),
						'leitor' => trim( $colunas[4] ),
					);
				}

				if ( '' !== trim( $colunas[6] ) ) {
					$saida[ $slug ]['notas'][] = trim( $colunas[6] );
				}
			}

			return $saida;
		}

		/**
		 * Slugs declarados que carregam uma chave de integração de SEO.
		 *
		 * É daqui que o adaptador de SEO tira o par slug ↔ chave, em vez de
		 * escrever o slug do fornecedor no meio do código: quem decide o que a
		 * configuração declara não é lista literal dentro da classe.
		 *
		 * @param string $arquivo Caminho absoluto do TSV declarado.
		 * @return array<string,string> Slug => nome da chave de integração.
		 */
		public static function integracoes_de_seo( string $arquivo ): array {
			$saida = array();

			foreach ( self::declarados( $arquivo ) as $slug => $declaracao ) {
				$chave = (string) ( $declaracao['chave_seo'] ?? '' );

				if ( '' !== $chave ) {
					$saida[ (string) $slug ] = $chave;
				}
			}

			return $saida;
		}

		/**
		 * O VEREDITO de emissão de um slug — função pura, sem WordPress.
		 *
		 * Três posições, e as três saem nomeadas:
		 *
		 * - `leitor`: há condição conhecida e TODAS fecham no valor de leitor.
		 *   O plugin fica, lê os consoles do fornecedor, e não imprime tag.
		 * - `concorrente`: há condição conhecida e alguma NÃO fecha no valor de
		 *   leitor — o snippet está ligado, e a mesma conversão sai duas vezes.
		 * - `nao-medido`: o slug é conhecido e não há option conhecida a medir,
		 *   ou a option declarada não foi observada. Suspeita NOMEADA, nunca
		 *   desativação: o que não foi medido não absolve, e o HTML decide.
		 *
		 * @param array<string,mixed> $declaracao Entrada declarada do slug.
		 * @param array<string,mixed> $observadas Options observadas, por nome.
		 * @return array{veredito:string,motivo:string}
		 */
		public static function veredito( array $declaracao, array $observadas ): array {
			$condicoes = (array) ( $declaracao['condicoes'] ?? array() );

			if ( array() === $condicoes ) {
				return array(
					'veredito' => self::NAO_MEDIDO,
					'motivo'   => __( 'slug conhecido sem option de condição declarada: o pacote não tem o que medir aqui, e quem decide é a contagem no HTML publicado.', 'f3base' ),
				);
			}

			$ligadas = array();

			foreach ( $condicoes as $condicao ) {
				$option = (string) ( $condicao['option'] ?? '' );
				$chave  = (string) ( $condicao['chave'] ?? '' );
				$leitor = (string) ( $condicao['leitor'] ?? '' );

				if ( ! array_key_exists( $option, $observadas ) ) {
					return array(
						'veredito' => self::NAO_MEDIDO,
						'motivo'   => sprintf(
							/* translators: %s: nome da option declarada como condição. */
							__( 'a option de condição %s não foi observada nesta instalação: a condição não foi medida, e o que não foi medido não absolve.', 'f3base' ),
							$option
						),
					);
				}

				$valor = $observadas[ $option ];
				$atual = is_array( $valor ) ? ( $valor[ $chave ] ?? null ) : null;

				if ( self::como_texto( $atual ) !== $leitor ) {
					$ligadas[] = $option . '.' . $chave . ' = ' . self::como_texto( $atual );
				}
			}

			if ( array() === $ligadas ) {
				return array(
					'veredito' => self::LEITOR,
					'motivo'   => __( 'snippet e medição automática de conversões desligados: o plugin lê os consoles do fornecedor e não imprime tag nenhuma.', 'f3base' ),
				);
			}

			return array(
				'veredito' => self::CONCORRENTE,
				'motivo'   => sprintf(
					/* translators: %s: lista de condições observadas que estão ligadas. */
					__( 'condição de emissão LIGADA: %s.', 'f3base' ),
					implode( '; ', $ligadas )
				),
			);
		}

		/**
		 * Representação textual fechada de um valor de condição.
		 *
		 * Booleano do banco chega como `1`, `"1"`, `""` ou `false` conforme quem
		 * o gravou; comparar sem normalizar faria a MESMA configuração fechar
		 * leitor numa instalação e concorrente na seguinte.
		 *
		 * @param mixed $valor Valor observado.
		 * @return string
		 */
		private static function como_texto( $valor ): string {
			if ( null === $valor ) {
				return 'ausente';
			}

			if ( is_bool( $valor ) ) {
				return $valor ? 'true' : 'false';
			}

			if ( is_scalar( $valor ) ) {
				$texto = trim( (string) $valor );

				if ( '' === $texto || '0' === $texto ) {
					return 'false';
				}

				if ( '1' === $texto ) {
					return 'true';
				}

				return $texto;
			}

			return 'estrutura';
		}
	}
}
