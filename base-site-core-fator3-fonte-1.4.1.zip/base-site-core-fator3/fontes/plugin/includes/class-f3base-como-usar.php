<?php
/**
 * A habilidade que diz ao agente COMO USAR este plugin.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * O MANUAL DE USO, montado do registro de módulos.
 *
 * POR QUE ISTO EXISTE. Depois da entrega, quem muda este site é um agente por
 * MCP. Sem saber o que o plugin já faz, o caminho natural do agente é resolver
 * cada pedido por onde ele conhece: injetar o GTM no tema, instalar um plugin de
 * pixel, escrever um segundo llms.txt. Nada disso falha — e é esse o problema.
 * O site passa a ter dois emissores da mesma tag, a conversão é contada duas
 * vezes, a campanha otimiza para um número inflado e ninguém vê erro nenhum.
 *
 * A LISTA SAI DO REGISTRO, nunca de um texto escrito à mão. Um manual digitado
 * envelhece na primeira vez que alguém acrescenta um módulo e esquece de
 * atualizá-lo — e um manual desatualizado é pior que nenhum, porque o agente
 * confia nele. Módulo novo aparece aqui sozinho, com o que ele controla e o
 * estado em que está.
 */
final class F3Base_Como_Usar {

	/**
	 * Nome da habilidade registrada na Abilities API.
	 *
	 * @var string
	 */
	public const HABILIDADE = 'f3base/como-usar';

	/**
	 * Registra a habilidade quando a API existir.
	 *
	 * O GANCHO NÃO MORA AQUI: quem engancha é `F3Base_Site_Core::iniciar()`, em
	 * `wp_abilities_api_init`, e a categoria `f3base` é registrada antes, em
	 * `wp_abilities_api_categories_init`. As duas grafias foram medidas contra um
	 * WordPress real: o núcleo recusa habilidade sem `category` conhecida, e um
	 * `add_action` em `abilities_api_init` — sem o `wp_` — não é chamado nunca.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			self::HABILIDADE,
			array(
				'label'               => __( 'Como usar o plugin do site', 'f3base' ),
				'description'         => __( 'O que este plugin já faz, por onde mudar cada coisa e o que NÃO fazer por outro caminho. Leia antes de instalar plugin de medição, editar o tema ou escrever configuração à mão.', 'f3base' ),
				'category'            => F3BASE_PREFIXO,
				/*
				 * SEM `PROPERTIES`, de propósito. Esta habilidade não recebe
				 * entrada nenhuma, e o mapa vazio tem duas formas erradas: um
				 * array PHP vazio serializa como `[]`, que em JSON Schema é uma
				 * lista onde se espera um mapa; um `stdClass` serializa como `{}`
				 * e derruba o validador do núcleo, que indexa `properties` como
				 * ARRAY ao conferir cada campo que chegar — com `{"x":1}` na
				 * entrada a chamada morria em Error em vez de ser recusada pelo
				 * schema. Omitir a chave é a forma que os dois leem igual:
				 * `additionalProperties: false` sozinho já diz "nenhum campo".
				 * Medido em `wp.habilidades_de_config_executam`.
				 */
				'input_schema'        => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'description'          => __( 'Sem entrada: o manual é o mesmo para quem perguntar.', 'f3base' ),
				),
				'output_schema'       => self::schema_da_resposta(),
				'execute_callback'    => array( __CLASS__, 'responder' ),
				'permission_callback' => static function ( $entrada = null ): bool {
					unset( $entrada );

					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * O QUE ESTA HABILIDADE DEVOLVE, campo a campo.
	 *
	 * O DEFEITO MEDIDO: o `output_schema` era `array( 'type' => 'object' )` — um
	 * objeto de forma desconhecida. Um agente que lê só o schema não sabia que a
	 * resposta traz `assuntos` com a option de cada assunto, e o caminho natural
	 * dele era executar para descobrir. Schema de saída existe para ser lido
	 * ANTES da chamada.
	 *
	 * @return array<string,mixed>
	 */
	public static function schema_da_resposta(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'plugin'     => array(
					'type'        => 'string',
					'description' => __( 'Slug do plugin que respondeu: base-site-core-fator3.', 'f3base' ),
				),
				'versao'     => array(
					'type'        => 'string',
					'description' => __( 'Versão lida do cabeçalho do plugin instalado.', 'f3base' ),
				),
				'resumo'     => array(
					'type'        => 'string',
					'description' => __( 'Uma frase com o que o plugin já cobre.', 'f3base' ),
				),
				'assuntos'   => array(
					'type'        => 'array',
					'description' => __( 'Um item por módulo do registro, na ordem em que a tela os apresenta.', 'f3base' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'assunto' => array( 'type' => 'string' ),
							'id'      => array( 'type' => 'string' ),
							'faz'     => array( 'type' => 'string' ),
							'options' => array(
								'type'        => 'array',
								'items'       => array( 'type' => 'string' ),
								'description' => __( 'Os nomes de option que mudam ESTE assunto. É por aqui que se muda o comportamento.', 'f3base' ),
							),
							'estado'  => array( 'type' => 'string' ),
							'por_que' => array( 'type' => 'string' ),
						),
					),
				),
				'nao_faca'   => array(
					'type'        => 'array',
					'description' => __( 'Caminhos paralelos que funcionam e custam caro, com o preço de cada um e a saída certa.', 'f3base' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'nao'    => array( 'type' => 'string' ),
							'porque' => array( 'type' => 'string' ),
							'faca'   => array( 'type' => 'string' ),
						),
					),
				),
				'como_mudar' => array(
					'type'        => 'string',
					'description' => __( 'Por onde a option é gravada e quando o valor passa a valer.', 'f3base' ),
				),
			),
		);
	}

	/**
	 * A resposta: legível por máquina e por gente.
	 *
	 * A ASSINATURA ACEITA A ENTRADA QUE O NÚCLEO MANDA, e ela pode ser `null`.
	 * Com `strict_types=1`, um parâmetro tipado `array` sem padrão seguro
	 * derruba a execução com TypeError na primeira chamada em que o núcleo não
	 * tem entrada para passar — e a habilidade passaria a existir no registro e
	 * a falhar ao executar, que é pior que não existir.
	 *
	 * @param mixed $entrada Entrada da habilidade; esta não usa nenhuma.
	 * @return array<string,mixed>
	 */
	public static function responder( $entrada = null ): array {
		unset( $entrada );

		return self::resposta();
	}

	/**
	 * O corpo da resposta.
	 *
	 * @return array<string,mixed>
	 */
	private static function resposta(): array {
		return array(
			'plugin'      => 'base-site-core-fator3',
			'versao'      => defined( 'F3BASE_PLUGIN_VERSAO' ) ? F3BASE_PLUGIN_VERSAO : '',
			'resumo'      => __( 'Este plugin já cuida de medição, consentimento, leads, llms.txt, redirects, cabeçalhos, noindex e schema. Mude o comportamento gravando as options listadas aqui — não por outro plugin, não pelo tema, não por tag manager paralelo.', 'f3base' ),
			'assuntos'    => self::assuntos(),
			'nao_faca'    => self::nao_faca(),
			'como_mudar'  => __( 'Grave a option indicada em cada assunto pela API de options do WordPress. O plugin relê a option a cada carregamento: não há cache a limpar e não é preciso reativar nada.', 'f3base' ),
		);
	}

	/**
	 * Os assuntos, um por módulo do registro.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function assuntos(): array {
		$saida = array();

		foreach ( F3Base_Registro::modulos() as $modulo ) {
			$estado = $modulo->estado();

			$saida[] = array(
				'assunto'      => $modulo->nome(),
				'id'           => $modulo->id(),
				'faz'          => $modulo->descricao(),
				'options'      => $modulo->options_que_controlam(),
				'estado'       => (string) ( $estado['estado'] ?? '' ),
				'por_que'      => (string) ( $estado['motivo'] ?? '' ),
			);
		}

		return $saida;
	}

	/**
	 * OS NOMES DE OPTION DE UM MÓDULO, lidos do REGISTRO.
	 *
	 * O DEFEITO MEDIDO, e ele mandava o agente gravar no lugar errado: a lista
	 * do "não faça" trazia `f3base_tracking` e `f3base_leads` escritas à mão, e
	 * NENHUMA DAS DUAS EXISTE no catálogo. Quem seguisse a instrução gravaria
	 * uma option que módulo nenhum lê — sem erro, sem aviso, sem efeito —, e
	 * concluiria que o plugin não faz o que o próprio manual dele afirma.
	 *
	 * A ÂNCORA É O REGISTRO, e não uma segunda lista: `options_que_controlam()`
	 * é a mesma declaração que a tela, o relatório e o assunto acima leem. Um
	 * módulo que passe a governar outra option aparece aqui sozinho, e uma option
	 * que deixe de existir some daqui na mesma release.
	 *
	 * @param string $id      Identificador do módulo no registro.
	 * @param string $reserva Frase usada quando o módulo não está no registro.
	 * @return string Nomes separados por vírgula, ou a reserva.
	 */
	public static function options_de( string $id, string $reserva ): string {
		$modulo = F3Base_Registro::modulo( $id );

		if ( null === $modulo ) {
			return $reserva;
		}

		$nomes = array_values( array_filter( array_map( 'strval', $modulo->options_que_controlam() ) ) );

		return array() === $nomes ? $reserva : implode( ', ', $nomes );
	}

	/**
	 * O QUE NÃO FAZER, e o preço de cada um.
	 *
	 * Cada item nomeia o caminho alternativo que o agente tomaria e o efeito
	 * medido de tomá-lo. Não é uma lista de proibições: é a explicação de por
	 * que o caminho paralelo custa caro, para quem precisa decidir.
	 *
	 * TODO NOME DE OPTION CITADO AQUI SAI DO REGISTRO. Nenhum é digitado: a
	 * frase é o que muda entre um item e outro, e o nome vem de quem o declara.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function nao_faca(): array {
		$reserva = __( '(nenhuma: esta parte está fora do registro nesta instalação)', 'f3base' );

		return array(
			array(
				'nao'    => __( 'Não injete GTM, GA4, Pixel da Meta, Google Ads ou Insight Tag do LinkedIn pelo tema, por plugin de terceiro ou por um segundo tag manager.', 'f3base' ),
				'porque' => __( 'Este plugin já emite todas elas a partir dos IDs gravados em option, e um emissor por fornecedor. Dois emissores contam a mesma conversão duas vezes: a campanha otimiza para um número inflado e nada aparece como erro.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Grave o identificador de cada fornecedor na option correspondente: %s. Deixe o identificador vazio para desligar aquele fornecedor.', 'f3base' ),
					self::options_de( 'tracking', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não instale plugin de consentimento nem escreva o consentimento por fora.', 'f3base' ),
				'porque' => __( 'A decisão de consentimento aqui é quem libera cada tag. Um segundo controlador cria dois estados para o mesmo visitante, e o que decide passa a ser a ordem de carregamento — que muda de página para página.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Ajuste a option %s.', 'f3base' ),
					self::options_de( 'consentimento', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não crie um segundo produtor de /llms.txt nem de /llms-full.txt.', 'f3base' ),
				'porque' => __( 'O plugin já responde nessas rotas. Um segundo produtor faz o WordPress servir o que responder primeiro, e qual dos dois é imprevisível entre requisições.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Ajuste a option %s.', 'f3base' ),
					self::options_de( 'llms-txt-reserva', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não crie endpoint próprio para receber lead do formulário do site.', 'f3base' ),
				'porque' => __( 'O endpoint deste plugin já valida, limita por IP, registra e dispara a conversão com o mesmo event_id do navegador. Um segundo caminho recebe lead sem nada disso, e a conversão dele não deduplica.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Use o endpoint existente; quem governa o destino e a guarda do que ele recebe são as options %s.', 'f3base' ),
					self::options_de( 'endpoint-leads', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não escreva cabeçalhos de segurança por .htaccess ou por plugin quando este já os envia.', 'f3base' ),
				'porque' => __( 'Cabeçalho duplicado com valores diferentes tem resultado dependente do servidor, e o mais restritivo costuma vencer — cortando a janela do fluxo de leads sem erro visível.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Ajuste a option %s.', 'f3base' ),
					self::options_de( 'cabecalhos', $reserva )
				),
			),
		);
	}
}
