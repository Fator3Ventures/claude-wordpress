<?php
/**
 * Módulo retencao-e-eliminacao.
 *
 * Limpeza por prazo em WP-Cron que MEDE O PRÓPRIO ATRASO e se recupera no
 * carregamento seguinte — WP-Cron não garante horário, e obrigação temporal
 * relevante leva recomendação de cron real no README.
 *
 * Exportador e eraser do core registrados, e uma rota de eliminação com journal
 * que distingue os dois regimes:
 *
 * - limpeza OPERACIONAL admite janela reversível com cópia protegida e expirável;
 * - eliminação A PEDIDO DO TITULAR é irreversível por desenho, e o journal guarda
 *   só identificador e carimbo, nunca o conteúdo eliminado — backup de dado
 *   pessoal apagado a pedido derrota o próprio direito que a rota atende.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retenção, eliminação e journal.
 */
final class F3Base_Modulo_Retencao_Eliminacao extends F3Base_Modulo {

	/**
	 * Evento agendado da limpeza.
	 */
	public const EVENTO = 'f3base_retencao_limpeza';

	/**
	 * Rota de eliminação, dentro do namespace do plugin.
	 */
	public const ROTA = '/eliminacao';

	/**
	 * Ação do nonce aceito pela rota.
	 */
	public const NONCE = 'f3base_eliminacao';

	/**
	 * Meta que marca o fim da janela reversível.
	 */
	public const META_REVERSIVEL = '_f3base_reversivel_ate';

	/**
	 * MOTIVO gravado no journal quando a eliminação saiu DEFINITIVA sem lixeira.
	 *
	 * Ele é uma chave curta e estável, e não uma frase: quem lê o journal meses
	 * depois precisa distinguir "a janela venceu e o lote foi eliminado" de "este
	 * host nunca teve janela", e uma frase traduzida ou reescrita numa release
	 * seguinte deixaria de casar com a anterior no meio da mesma lista.
	 */
	public const MOTIVO_SEM_LIXEIRA = 'sem lixeira neste host';

	/**
	 * TETO DE VOLTAS do desagendamento, e ele é declarado por um motivo.
	 *
	 * `wp_unschedule_event()` pode falhar — outro processo mexendo no array do
	 * cron, um filtro de terceiro recusando, um cron object corrompido — e ela
	 * falha devolvendo `false` COM O EVENTO AINDA LÁ. Um laço que só pergunta
	 * `while ( false !== wp_next_scheduled() )` recebe de volta o mesmo carimbo
	 * para sempre: a desativação do plugin não termina, e o que o operador vê é
	 * a tela do wp-admin pendurada até o limite de tempo do PHP.
	 */
	public const TETO_DE_DESAGENDAMENTO = 50;

	/**
	 * TETO DA CONTAGEM do que ainda falta arquivar.
	 *
	 * A pergunta "quantos ainda faltam?" não pode custar uma varredura da tabela
	 * inteira todo dia. Acima deste número o carimbo diz que o resto não foi
	 * contado, em vez de contar tudo ou de inventar um número.
	 */
	public const TETO_DA_CONTAGEM = 5000;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'retencao-e-eliminacao';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Retenção e eliminação', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Limpa registros de lead pelo prazo declarado em WP-Cron, medindo o próprio atraso e se recuperando no carregamento seguinte; registra exportador e eraser do core; e expõe a rota de eliminação com journal que separa limpeza operacional reversível de eliminação irreversível a pedido do titular.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'garantir_agendamento',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => self::EVENTO,
				'metodo'     => 'executar_limpeza',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'wp_privacy_personal_data_exporters',
				'metodo'     => 'registrar_exportador',
				'prioridade' => 10,
				'args'       => 1,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'wp_privacy_personal_data_erasers',
				'metodo'     => 'registrar_eraser',
				'prioridade' => 10,
				'args'       => 1,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_retencao_meses', 'f3base_journal_eliminacao' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$agendado = wp_next_scheduled( self::EVENTO );
		$cron_off = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;

		return array(
			array(
				'rotulo'   => __( 'Agendamento da limpeza', 'f3base' ),
				'presente' => false !== $agendado,
				'detalhe'  => false !== $agendado
					? sprintf(
						/* translators: %s: data e hora previstas. */
						__( 'próxima execução prevista para %s.', 'f3base' ),
						(string) wp_date( 'd/m/Y H:i', (int) $agendado )
					)
					: __( 'evento não agendado: a limpeza depende do carregamento seguinte para se recuperar.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'WP-Cron habilitado', 'f3base' ),
				'presente' => ! $cron_off,
				'detalhe'  => $cron_off
					? __( 'DISABLE_WP_CRON ligado: a limpeza depende de cron real do sistema, conforme o README.', 'f3base' )
					: __( 'WP-Cron não garante horário; o atraso é medido e reportado a cada execução.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_LIMPEZA, __( 'Última limpeza de retenção', 'f3base' ) ),
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_ELIMINACAO, __( 'Última eliminação pela rota', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$agendado = wp_next_scheduled( self::EVENTO );

		if ( false === $agendado ) {
			return $this->degradado(
				__( 'evento de limpeza sem agendamento: o prazo de retenção só é aplicado quando o carregamento seguinte recuperar a rotina.', 'f3base' )
			);
		}

		$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_LIMPEZA );
		$atraso  = isset( $carimbo['atraso_segundos'] ) ? (int) $carimbo['atraso_segundos'] : 0;
		$limite  = (int) apply_filters( 'f3base_retencao_atraso_tolerado', 2 * DAY_IN_SECONDS );

		if ( $atraso > $limite ) {
			return $this->degradado(
				sprintf(
					/* translators: %s: atraso medido, em formato humano. */
					__( 'última execução saiu com %s de atraso sobre o horário previsto, acima da tolerância declarada.', 'f3base' ),
					human_time_diff( 0, $atraso )
				)
			);
		}

		/*
		 * BACKLOG É ESTADO DEGRADADO, e ele é invisível sem esta frase: o lote é
		 * de 200 por dia, e um site que acumule mais que isso por dia nunca
		 * alcança o próprio prazo — a rotina carimba "200 arquivados" todo dia,
		 * parecendo em dia, enquanto o registro mais velho envelhece.
		 */
		$restantes = isset( $carimbo['restantes'] ) ? (int) $carimbo['restantes'] : 0;

		if ( $restantes > 0 ) {
			return $this->degradado(
				sprintf(
					/* translators: 1: quantos registros vencidos ainda não foram arquivados, 2: "ou mais" quando a contagem bateu no teto, 3: data de corte. */
					__( 'sobraram %1$d registro(s)%2$s vencidos que o lote do dia não alcançou: o prazo declarado não está sendo cumprido para eles enquanto a fila não baixar. O corte desta medição foi %3$s. O tamanho do lote é o filtro f3base_retencao_lote, e aumentar o lote é a decisão de quem opera o site.', 'f3base' ),
					$restantes,
					! empty( $carimbo['restantes_teto'] ) ? __( ' ou mais', 'f3base' ) : '',
					(string) ( $carimbo['corte'] ?? self::corte_de_retencao( $this->meses() ) )
				)
			);
		}

		/*
		 * SEM LIXEIRA A ELIMINAÇÃO É DEFINITIVA, E A FRASE DIZ ISSO — sem fechar
		 * degradado. Com `EMPTY_TRASH_DAYS` em zero o núcleo faz `wp_trash_post()`
		 * apagar em definitivo, e não existe neste host onde guardar a cópia
		 * protegida da janela reversível.
		 *
		 * O QUE MUDOU E POR QUÊ. Houve uma versão em que este estado era
		 * DEGRADADO, a rotina não arquivava e a rota recusava o regime operacional
		 * com 409. Isso trocava um defeito por outro: o prazo de retenção que a
		 * política de privacidade PROMETE deixava de ser cumprido — os registros
		 * vencidos ficavam no banco indefinidamente — para não escrever uma
		 * palavra errada na resposta. A escolha desta release é a inversa: o prazo
		 * continua sendo cumprido, a eliminação acontece, e o que ela é fica
		 * DECLARADO na resposta, no journal e aqui.
		 */
		if ( ! self::lixeira_disponivel() ) {
			return $this->ativo(
				sprintf(
					/* translators: 1: prazo em meses, 2: data de corte em calendário, 3: data e hora previstas da próxima limpeza, 4: valor de EMPTY_TRASH_DAYS medido nesta instalação. */
					__( 'guardando leads por %1$d meses de CALENDÁRIO — hoje o corte cai em %2$s —; próxima limpeza prevista para %3$s, com o atraso medido a cada execução. A ELIMINAÇÃO NESTE SITE É DEFINITIVA: EMPTY_TRASH_DAYS vale %4$d, a lixeira do WordPress está desligada e não há onde guardar a cópia protegida da janela reversível. O prazo continua sendo cumprido, a resposta da rota sai com reversivel: false e o journal registra a eliminação como definitiva. Definir EMPTY_TRASH_DAYS acima de zero devolve a janela na requisição seguinte.', 'f3base' ),
					$this->meses(),
					self::corte_de_retencao( $this->meses() ),
					(string) wp_date( 'd/m/Y H:i', (int) $agendado ),
					self::dias_de_lixeira()
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: 1: prazo em meses, 2: data de corte em calendário, 3: data e hora previstas da próxima limpeza. */
				__( 'guardando leads por %1$d meses de CALENDÁRIO — hoje o corte cai em %2$s —; próxima limpeza prevista para %3$s, com o atraso medido a cada execução.', 'f3base' ),
				$this->meses(),
				self::corte_de_retencao( $this->meses() ),
				(string) wp_date( 'd/m/Y H:i', (int) $agendado )
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function instalar(): void {
		$this->garantir_agendamento();
	}

	/**
	 * {@inheritDoc}
	 */
	public function desinstalar(): void {
		$timestamp = wp_next_scheduled( self::EVENTO );
		$voltas    = 0;

		while ( false !== $timestamp && $voltas < self::TETO_DE_DESAGENDAMENTO ) {
			++$voltas;

			/*
			 * O RETORNO É CONFERIDO, e é ele que fecha o laço: desagendamento
			 * que falha devolve `false` e deixa o MESMO carimbo no cron —
			 * perguntar de novo devolveria o mesmo, para sempre.
			 */
			if ( true !== wp_unschedule_event( (int) $timestamp, self::EVENTO ) ) {
				break;
			}

			$timestamp = wp_next_scheduled( self::EVENTO );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Agendamento e recuperação
	 * ------------------------------------------------------------------ */

	/**
	 * Garante o agendamento e recupera a execução perdida.
	 *
	 * @return void
	 */
	public function garantir_agendamento(): void {
		$previsto = $this->previsto();

		if ( false === wp_next_scheduled( self::EVENTO ) ) {
			$proxima = time() + HOUR_IN_SECONDS;

			/*
			 * O RETORNO DECIDE SE A PREVISÃO É GRAVADA: previsão sem evento faz o
			 * carregamento seguinte medir atraso contra um horário que ninguém
			 * agendou, e degradar o módulo por uma execução que nunca existiu.
			 */
			if ( true === wp_schedule_event( $proxima, 'daily', self::EVENTO ) ) {
				$this->guardar_previsao( $proxima );
			}
		}

		if ( $previsto <= 0 ) {
			return;
		}

		$tolerancia = (int) apply_filters( 'f3base_retencao_tolerancia_recuperacao', 6 * HOUR_IN_SECONDS );
		$tolerancia = max( MINUTE_IN_SECONDS, $tolerancia );

		if ( time() <= $previsto + $tolerancia ) {
			return;
		}

		if ( false === set_transient( 'f3base_retencao_recuperando', 1, 15 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		$this->executar_limpeza( true );
	}

	/**
	 * Executa a limpeza por prazo.
	 *
	 * @param bool $recuperacao Verdadeiro quando disparada pelo carregamento.
	 * @return void
	 */
	public function executar_limpeza( bool $recuperacao = false ): void {
		$previsto = $this->previsto();
		$atraso   = $previsto > 0 ? max( 0, time() - $previsto ) : 0;

		$arquivamento = $this->arquivar_expirados();
		$para_lixeira = $arquivamento['arquivados'];
		$eliminados   = $this->eliminar_janela_vencida();

		/*
		 * O RESUMO DE COMPORTAMENTO É PODADO PELA MESMA ROTINA, e por um motivo
		 * de desenho: prazo declarado que depende de uma segunda rotina é prazo
		 * que se cumpre pela metade no dia em que a segunda não roda. Ela já é
		 * a rotina de retenção deste site; o que muda é que ela passou a ter
		 * dois prazos para cumprir, cada um com a sua option, e o carimbo diz
		 * quantas linhas saíram — nunca o que havia nelas.
		 */
		$comportamento = class_exists( 'F3Base_Modulo_Comportamento' )
			? F3Base_Modulo_Comportamento::podar()
			: 0;

		/*
		 * O REGISTRO DETALHADO TEM PRAZO PRÓPRIO E MAIS CURTO, e ele é podado
		 * aqui, na mesma rotina e na mesma execução. São dois prazos porque são
		 * dois dados: o resumo soma por dia e por página e não identifica
		 * ninguém; o registro guarda o apelido do visitante, a visita e o
		 * horário em milissegundos, e isso é dado pessoal pseudonimizado. Uma
		 * segunda rotina para o segundo prazo seria um prazo que se cumpre pela
		 * metade no dia em que ela não rodar — e o que ficaria para trás é
		 * justamente o dado identificável.
		 */
		$registro_podado = class_exists( 'F3Base_Modulo_Comportamento' )
			? F3Base_Modulo_Comportamento::podar_eventos()
			: 0;

		if ( class_exists( 'F3Base_Modulo_Comportamento' ) ) {
			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_PODA_COMPORTAMENTO,
				array(
					'linhas'         => $comportamento,
					'dias'           => F3Base_Modulo_Comportamento::retencao_dias(),
					'registro'       => $registro_podado,
					'registro_dias'  => F3Base_Modulo_Comportamento::retencao_eventos_dias(),
				)
			);
		}

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_LIMPEZA,
			array(
				'arquivados'      => $para_lixeira,
				'restantes'       => $arquivamento['restantes'],
				'restantes_teto'  => $arquivamento['restantes_no_teto'],
				'sem_lixeira'     => $arquivamento['sem_lixeira'],
				'corte'           => self::corte_de_retencao( $this->meses() ),
				'eliminados'      => $eliminados,
				'comportamento'   => $comportamento,
				'registro'        => $registro_podado,
				'meses'           => $this->meses(),
				'atraso_segundos' => $atraso,
				'recuperada'      => $recuperacao,
			)
		);

		/*
		 * O LOTE DO DIA ENTRA NO JOURNAL DIZENDO O QUE ELE FOI. Com lixeira, ele
		 * é uma ida para a janela reversível e sai com a data em que ela vence.
		 * SEM LIXEIRA ele é eliminação DEFINITIVA, e sai com a janela zerada e o
		 * motivo — um journal que registrasse uma janela sobre o que já não
		 * existe seria a mesma promessa falsa que esta release veio cortar, só
		 * que gravada.
		 */
		if ( $para_lixeira > 0 ) {
			$this->registrar_journal(
				'operacional',
				sprintf( 'retencao-%s', gmdate( 'Y-m-d-H-i-s' ) ),
				'',
				$para_lixeira,
				$recuperacao ? 'carregamento' : 'wp-cron',
				$arquivamento['sem_lixeira'] ? 0 : time() + $this->janela_reversivel(),
				$arquivamento['sem_lixeira'] ? self::MOTIVO_SEM_LIXEIRA : ''
			);
		}

		/*
		 * A ELIMINAÇÃO DEFINITIVA EM LOTE ENTRA NO JOURNAL, e ela é a única
		 * escrita deste módulo que APAGA SEM VOLTA. Até a 1.0.1 o journal
		 * registrava a ida para a lixeira — que é reversível — e não registrava
		 * a perda: quem lesse o journal via o registro entrar na janela e nunca
		 * via a data em que ele deixou de existir. É o mesmo regime operacional,
		 * na outra ponta, e por isso `reversivel_ate` sai ZERO: a janela deste
		 * lote acabou de vencer, e é o vencimento dela que autorizou apagar.
		 */
		if ( $eliminados > 0 ) {
			$this->registrar_journal(
				'operacional',
				sprintf( 'retencao-definitiva-%s', gmdate( 'Y-m-d-H-i-s' ) ),
				'',
				$eliminados,
				$recuperacao ? 'carregamento' : 'wp-cron',
				0
			);
		}

		$proxima = wp_next_scheduled( self::EVENTO );
		$this->guardar_previsao( false !== $proxima ? (int) $proxima : time() + DAY_IN_SECONDS );

		delete_transient( 'f3base_retencao_recuperando' );
	}

	/**
	 * Aplica o prazo ao que venceu: lixeira quando ela existe, definitivo quando não.
	 *
	 * SEM LIXEIRA ELE ELIMINA EM DEFINITIVO, e diz que foi isso. Com
	 * `EMPTY_TRASH_DAYS` em `0`, `wp_trash_post()` APAGA — o núcleo pula a
	 * lixeira inteira —, e a janela reversível que a limpeza operacional promete
	 * não pode ser cumprida por ninguém neste host.
	 *
	 * O QUE MUDOU E POR QUÊ. Houve uma versão em que este ramo não arquivava
	 * NADA, para não apagar o registro com o carimbo de uma cópia que nunca
	 * houve. Ela trocava um defeito por outro: o prazo de retenção que a política
	 * de privacidade PROMETE deixava de ser cumprido, e o dado pessoal vencido
	 * ficava no banco indefinidamente. A escolha desta release é cumprir o prazo
	 * e DECLARAR o que foi feito — `sem_lixeira` viaja no carimbo da rotina, o
	 * journal sai com a janela zerada e o motivo, e o estado do módulo diz que a
	 * eliminação neste site é definitiva.
	 *
	 * A ELIMINAÇÃO USA `wp_delete_post( $id, true )` em vez de `wp_trash_post()`:
	 * o efeito é o mesmo neste host, e o nome da chamada é o que ela faz. Chamar
	 * "arquivar" o que apaga é como o defeito anterior começou.
	 *
	 * @return array{arquivados:int,restantes:int,restantes_no_teto:bool,sem_lixeira:bool}
	 */
	private function arquivar_expirados(): array {
		$sem_lixeira = ! self::lixeira_disponivel();
		$vazio       = array(
			'arquivados'        => 0,
			'restantes'         => 0,
			'restantes_no_teto' => false,
			'sem_lixeira'       => $sem_lixeira,
		);

		$lote  = max( 1, (int) apply_filters( 'f3base_retencao_lote', 200 ) );
		$busca = array(
			'post_type'              => $this->tipos_de_lead(),
			'post_status'            => array( 'publish', 'private', 'draft', 'pending' ),
			'numberposts'            => $lote,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'suppress_filters'       => false,
			'date_query'             => array(
				array(
					'before'    => self::corte_de_retencao( $this->meses() ),
					'inclusive' => true,
					'column'    => 'post_date_gmt',
				),
			),
		);

		$ids = get_posts( $busca );

		if ( ! is_array( $ids ) ) {
			return $vazio;
		}

		$conta  = 0;
		$expira = time() + $this->janela_reversivel();

		foreach ( $ids as $id ) {
			$id = (int) $id;

			/*
			 * SEM LIXEIRA NÃO SE CARIMBA JANELA NENHUMA. O metadado da janela
			 * reversível existe para que a eliminação definitiva do lote saiba
			 * quando ela venceu; gravá-lo sobre um registro que está sendo apagado
			 * agora seria escrever a data de uma cópia que não vai existir.
			 */
			if ( $sem_lixeira ) {
				if ( wp_delete_post( $id, true ) ) {
					++$conta;
				}

				continue;
			}

			update_post_meta( $id, self::META_REVERSIVEL, $expira );

			if ( wp_trash_post( $id ) ) {
				++$conta;
			}
		}

		/*
		 * O QUE FICOU PARA TRÁS É MEDIDO, e não deduzido do tamanho do lote.
		 *
		 * O lote é de 200 por dia. Um site que acumule mais de 200 registros
		 * vencidos por dia — uma importação, uma campanha, um prazo encurtado
		 * de doze meses para três — nunca alcança o próprio prazo, e a rotina
		 * continua carimbando "200 arquivados" todo dia como se estivesse em
		 * dia. A contagem só acontece quando o lote saiu CHEIO, que é quando
		 * pode haver resto, e ela tem teto declarado.
		 */
		if ( count( $ids ) < $lote ) {
			return array(
				'arquivados'        => $conta,
				'restantes'         => 0,
				'restantes_no_teto' => false,
				'sem_lixeira'       => $sem_lixeira,
			);
		}

		$busca['numberposts'] = self::TETO_DA_CONTAGEM;
		$restam               = get_posts( $busca );
		$restam               = is_array( $restam ) ? count( $restam ) : 0;

		return array(
			'arquivados'        => $conta,
			'restantes'         => $restam,
			'restantes_no_teto' => $restam >= self::TETO_DA_CONTAGEM,
			'sem_lixeira'       => $sem_lixeira,
		);
	}

	/**
	 * A LIXEIRA EXISTE NESTE SITE? Um produtor só deste fato.
	 *
	 * `EMPTY_TRASH_DAYS` em `0` desliga a lixeira do WordPress inteira, e o
	 * núcleo passa a fazer `wp_trash_post()` APAGAR EM DEFINITIVO. A METADE
	 * REVERSÍVEL do regime operacional deste módulo — a janela, a cópia
	 * protegida, o `reversivel: true` e o `reversivel_ate` da resposta — depende
	 * de a lixeira existir; a ELIMINAÇÃO não depende, e acontece do mesmo jeito
	 * para que o prazo que a política de privacidade promete continue sendo
	 * cumprido. O que muda sem lixeira é o que a rota, o journal e o estado do
	 * módulo DIZEM sobre ela.
	 *
	 * @return bool
	 */
	public static function lixeira_disponivel(): bool {
		return self::dias_de_lixeira() > 0;
	}

	/**
	 * Dias que o núcleo guarda na lixeira, com o padrão do WordPress.
	 *
	 * O filtro existe para a bancada poder exercitar os dois estados sem mexer
	 * numa constante do processo, que é irreversível.
	 *
	 * @return int
	 */
	public static function dias_de_lixeira(): int {
		$dias = defined( 'EMPTY_TRASH_DAYS' ) ? (int) EMPTY_TRASH_DAYS : 30;

		/**
		 * Permite exercitar o site sem lixeira sem redefinir a constante.
		 *
		 * @param int $dias Dias declarados por `EMPTY_TRASH_DAYS`.
		 */
		return (int) apply_filters( 'f3base_dias_de_lixeira', $dias );
	}

	/**
	 * O CORTE DA RETENÇÃO, em data de calendário. Regra pura.
	 *
	 * `MONTH_IN_SECONDS` é TRINTA DIAS, e o prazo declarado é em MESES: "guardar
	 * por 12 meses" virava 360 dias, cinco dias e pouco a menos por ano, sem que
	 * nada dissesse isso — e o registro apagado cinco dias antes do prazo é
	 * apagado antes do prazo. `DateTimeImmutable::modify( '-N months' )` conta
	 * calendário, e mês curto é tratado como o PHP trata: 31 de março menos um
	 * mês cai em 3 de março, nunca em fevereiro que não tem 31.
	 *
	 * @param int $meses Prazo declarado, em meses.
	 * @param int $agora Instante de referência; 0 usa o relógio.
	 * @return string Data em `Y-m-d H:i:s`, UTC.
	 */
	public static function corte_de_retencao( int $meses, int $agora = 0 ): string {
		$agora = $agora > 0 ? $agora : time();
		$meses = max( 1, $meses );

		$corte = ( new DateTimeImmutable( '@' . $agora ) )->modify( '-' . $meses . ' months' );

		return false === $corte
			? gmdate( 'Y-m-d H:i:s', $agora )
			: $corte->format( 'Y-m-d H:i:s' );
	}

	/**
	 * Elimina em definitivo o que já venceu a janela reversível.
	 *
	 * @return int Quantidade eliminada.
	 */
	private function eliminar_janela_vencida(): int {
		$ids = get_posts(
			array(
				'post_type'              => $this->tipos_de_lead(),
				'post_status'            => 'trash',
				'numberposts'            => (int) apply_filters( 'f3base_retencao_lote', 200 ),
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => false,
				'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'     => self::META_REVERSIVEL,
						'value'   => time(),
						'compare' => '<=',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		if ( ! is_array( $ids ) ) {
			return 0;
		}

		$conta = 0;

		foreach ( $ids as $id ) {
			if ( wp_delete_post( (int) $id, true ) ) {
				++$conta;
			}
		}

		return $conta;
	}

	/* ------------------------------------------------------------------ *
	 * Rota de eliminação
	 * ------------------------------------------------------------------ */

	/**
	 * Registra a rota de eliminação.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'eliminar' ),
				'permission_callback' => array( $this, 'pode_eliminar' ),
				'args'                => array(
					'regime'        => array(
						'type'     => 'string',
						'required' => true,
						'enum'     => array( 'operacional', 'titular' ),
					),
					'identificador' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Capability da rota.
	 *
	 * @return bool
	 */
	public function pode_eliminar(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Executa a eliminação pedida.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function eliminar( WP_REST_Request $requisicao ): WP_REST_Response {
		$nonce = (string) $requisicao->get_param( '_wpnonce' );
		if ( '' === $nonce ) {
			$cabecalho = $requisicao->get_header( 'x_wp_nonce' );
			$nonce     = is_string( $cabecalho ) ? $cabecalho : '';
		}

		$por_cookie = defined( 'LOGGED_IN_COOKIE' ) && isset( $_COOKIE[ LOGGED_IN_COOKIE ] );
		$nonce_ok   = '' !== $nonce && ( wp_verify_nonce( $nonce, self::NONCE ) || wp_verify_nonce( $nonce, 'wp_rest' ) );

		if ( ! $nonce_ok && $por_cookie ) {
			return new WP_REST_Response(
				array(
					'ok'     => false,
					'codigo' => 'f3base_nonce_invalido',
					'motivo' => __( 'Nonce ausente ou inválido para a rota de eliminação.', 'f3base' ),
				),
				403
			);
		}

		$regime        = sanitize_key( (string) $requisicao->get_param( 'regime' ) );
		$identificador = sanitize_text_field( (string) $requisicao->get_param( 'identificador' ) );

		if ( '' === $identificador ) {
			return new WP_REST_Response(
				array(
					'ok'     => false,
					'codigo' => 'f3base_identificador_ausente',
					'motivo' => __( 'Informe o identificador do titular ou do registro.', 'f3base' ),
				),
				400
			);
		}

		$alvos = $this->localizar( $identificador );

		if ( array() === $alvos ) {
			return new WP_REST_Response(
				array(
					'ok'       => true,
					'regime'   => $regime,
					'contagem' => 0,
					'motivo'   => __( 'Nenhum registro casou com o identificador informado.', 'f3base' ),
				),
				200
			);
		}

		$operador = wp_get_current_user()->user_login;
		$operador = is_string( $operador ) && '' !== $operador ? $operador : 'canal';

		if ( 'titular' === $regime ) {
			$contagem = 0;
			foreach ( $alvos as $id ) {
				if ( wp_delete_post( (int) $id, true ) ) {
					++$contagem;
				}
			}

			$this->registrar_journal(
				'titular',
				'',
				$this->impressao( $identificador ),
				$contagem,
				$operador,
				0
			);

			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_ELIMINACAO,
				array(
					'regime'   => 'titular',
					'contagem' => $contagem,
					'operador' => $operador,
				)
			);

			return new WP_REST_Response(
				array(
					'ok'          => true,
					'regime'      => 'titular',
					'contagem'    => $contagem,
					'reversivel'  => false,
					'motivo'      => __( 'Eliminação a pedido do titular é irreversível por desenho: nenhuma cópia foi mantida e o journal guarda só identificador e carimbo.', 'f3base' ),
				),
				200
			);
		}

		/*
		 * SEM LIXEIRA O REGIME OPERACIONAL PROSSEGUE, E DIZ QUE FOI DEFINITIVO.
		 *
		 * Com `EMPTY_TRASH_DAYS` em zero, `wp_trash_post()` apaga em definitivo:
		 * o núcleo pula a lixeira inteira, e não existe neste host onde guardar a
		 * cópia protegida da janela. Houve uma versão em que esta rota RECUSAVA o
		 * pedido com 409 por causa disso. Ela trocava um defeito por outro: o
		 * prazo de retenção que a política de privacidade PROMETE deixava de ser
		 * cumprido — o registro vencido ficava no banco — para não escrever uma
		 * palavra errada na resposta.
		 *
		 * A ESCOLHA DESTA RELEASE É A INVERSA: elimina, e declara. A resposta sai
		 * 200 com `reversivel: false` e SEM `reversivel_ate` — campo de janela
		 * sobre o que não tem janela é a mesma promessa falsa, com outro nome —, o
		 * journal sai com a janela zerada e o motivo, e o estado do módulo diz que
		 * a eliminação neste site é definitiva e por quê, sem fechar degradado.
		 */
		$sem_lixeira = ! self::lixeira_disponivel();
		$expira      = $sem_lixeira ? 0 : time() + $this->janela_reversivel();
		$contagem    = 0;

		foreach ( $alvos as $id ) {
			$id = (int) $id;

			if ( $sem_lixeira ) {
				if ( wp_delete_post( $id, true ) ) {
					++$contagem;
				}

				continue;
			}

			update_post_meta( $id, self::META_REVERSIVEL, $expira );

			if ( wp_trash_post( $id ) ) {
				++$contagem;
			}
		}

		$this->registrar_journal(
			'operacional',
			implode( ',', array_map( 'strval', $alvos ) ),
			'',
			$contagem,
			$operador,
			$expira,
			$sem_lixeira ? self::MOTIVO_SEM_LIXEIRA : ''
		);

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_ELIMINACAO,
			array(
				'regime'   => 'operacional',
				'contagem' => $contagem,
				'operador' => $operador,
			)
		);

		if ( $sem_lixeira ) {
			return new WP_REST_Response(
				array(
					'ok'         => true,
					'regime'     => 'operacional',
					'contagem'   => $contagem,
					'reversivel' => false,
					'motivo'     => sprintf(
						/* translators: %d: valor de EMPTY_TRASH_DAYS medido nesta instalação. */
						__( 'Eliminação DEFINITIVA: EMPTY_TRASH_DAYS vale %d e a lixeira está desligada, então não houve cópia protegida nem janela. Acima de zero, a janela volta no pedido seguinte.', 'f3base' ),
						self::dias_de_lixeira()
					),
				),
				200
			);
		}

		return new WP_REST_Response(
			array(
				'ok'             => true,
				'regime'         => 'operacional',
				'contagem'       => $contagem,
				'reversivel'     => true,
				'reversivel_ate' => $expira,
				'motivo'         => __( 'Limpeza operacional: cópia protegida na lixeira até o fim da janela declarada.', 'f3base' ),
			),
			200
		);
	}

	/* ------------------------------------------------------------------ *
	 * Exportador e eraser do core
	 * ------------------------------------------------------------------ */

	/**
	 * Registra o exportador do core.
	 *
	 * @param array<string,mixed> $exportadores Exportadores registrados.
	 * @return array<string,mixed>
	 */
	public function registrar_exportador( array $exportadores ): array {
		$exportadores['f3base-leads'] = array(
			'exporter_friendly_name' => __( 'Leads do Base Site Core Fator3', 'f3base' ),
			'callback'               => array( $this, 'exportar' ),
		);

		return $exportadores;
	}

	/**
	 * Registra o eraser do core.
	 *
	 * @param array<string,mixed> $erasers Erasers registrados.
	 * @return array<string,mixed>
	 */
	public function registrar_eraser( array $erasers ): array {
		$erasers['f3base-leads'] = array(
			'eraser_friendly_name' => __( 'Leads do Base Site Core Fator3', 'f3base' ),
			'callback'             => array( $this, 'apagar' ),
		);

		return $erasers;
	}

	/**
	 * Exporta os registros de um titular.
	 *
	 * A PAGINAÇÃO É HONRADA, e ela não era. Até a 1.0.1 esta função ignorava
	 * `$pagina`, buscava no máximo 500 registros e devolvia `done => true`: um
	 * titular com mais de 500 recebia uma exportação SILENCIOSAMENTE INCOMPLETA
	 * e o núcleo dizia a ele que estava completa. `done` agora só é verdadeiro
	 * quando a página veio incompleta, que é o sinal de que acabou.
	 *
	 * O deslocamento é por página porque o EXPORTADOR não muda o conjunto: os
	 * registros continuam lá entre uma chamada e a seguinte.
	 *
	 * @param string $email  E-mail do titular.
	 * @param int    $pagina Página da exportação.
	 * @return array{data:array<int,array<string,mixed>>,done:bool}
	 */
	public function exportar( string $email, int $pagina = 1 ): array {
		$pagina = max( 1, $pagina );
		$lote   = self::lote_de_privacidade();
		$ids    = $this->localizar( $email, $pagina, $lote );

		$dados = array();

		foreach ( $ids as $id ) {
			$post = get_post( (int) $id );
			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			$dados[] = array(
				'group_id'    => 'f3base-leads',
				'group_label' => __( 'Leads', 'f3base' ),
				'item_id'     => 'f3base-lead-' . (int) $id,
				'data'        => array(
					array(
						'name'  => __( 'Assunto', 'f3base' ),
						'value' => (string) $post->post_title,
					),
					array(
						'name'  => __( 'Registrado em', 'f3base' ),
						'value' => (string) $post->post_date,
					),
					array(
						'name'  => __( 'Conteúdo', 'f3base' ),
						'value' => (string) $post->post_content,
					),
				),
			);
		}

		return array(
			'data' => $dados,
			/* PÁGINA INCOMPLETA É O FIM. Página cheia pode ter mais atrás dela. */
			'done' => count( $ids ) < $lote,
		);
	}

	/**
	 * Apaga os registros de um titular pelo fluxo do core.
	 *
	 * Este caminho é o do titular: irreversível, com journal de identificador e
	 * carimbo apenas.
	 *
	 * A PAGINAÇÃO AQUI NÃO USA DESLOCAMENTO, e a diferença para o exportador é
	 * de natureza: o que este método faz é REMOVER do conjunto. Pular
	 * `($pagina-1) * $lote` registros na segunda chamada saltaria por cima de
	 * tudo o que a primeira já apagou e deixaria a metade do titular no banco.
	 * O núcleo chama de novo enquanto `done` for falso, e cada chamada leva o
	 * que sobrou — que é a paginação certa para um conjunto que encolhe.
	 *
	 * A SAÍDA DE SEGURANÇA é o lote que não apagou NADA: se `wp_delete_post()`
	 * falhar em todos — um filtro de terceiro recusando, por exemplo —, a mesma
	 * página voltaria para sempre. Nesse caso a rotina para, declara
	 * `items_retained` e diz o que ficou.
	 *
	 * @param string $email  E-mail do titular.
	 * @param int    $pagina Página da eliminação.
	 * @return array{items_removed:bool,items_retained:bool,messages:string[],done:bool}
	 */
	public function apagar( string $email, int $pagina = 1 ): array {
		$pagina = max( 1, $pagina );
		$lote   = self::lote_de_privacidade();
		$ids    = $this->localizar( $email, 1, $lote );

		$contagem = 0;

		foreach ( $ids as $id ) {
			if ( wp_delete_post( (int) $id, true ) ) {
				++$contagem;
			}
		}

		if ( $contagem > 0 ) {
			$this->registrar_journal( 'titular', '', $this->impressao( $email ), $contagem, 'privacidade-do-core', 0 );

			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_ELIMINACAO,
				array(
					'regime'   => 'titular',
					'contagem' => $contagem,
					'operador' => 'privacidade-do-core',
					'pagina'   => $pagina,
				)
			);
		}

		$travou = array() !== $ids && 0 === $contagem;

		return array(
			'items_removed'  => $contagem > 0,
			'items_retained' => $travou,
			'messages'       => $travou
				? array(
					sprintf(
						/* translators: %d: quantos registros o site não conseguiu apagar. */
						__( '%d registro(s) de lead não puderam ser apagados nesta passagem e continuam no site: a eliminação parou aqui em vez de repetir a mesma página sem fim.', 'f3base' ),
						count( $ids )
					),
				)
				: array(),
			/* PÁGINA INCOMPLETA É O FIM; lote que não apagou nada também para. */
			'done'           => $travou || count( $ids ) < $lote,
		);
	}

	/**
	 * TAMANHO DO LOTE das rotinas de privacidade do núcleo.
	 *
	 * O núcleo chama exportador e eraser em sequência, uma página por
	 * requisição, e é ele quem controla o ritmo: o lote existe para que cada
	 * chamada caiba no tempo e na memória da requisição, não para limitar o que
	 * o titular recebe ou o que ele pode apagar.
	 *
	 * @return int
	 */
	public static function lote_de_privacidade(): int {
		$lote = (int) apply_filters( 'f3base_privacidade_lote', 100 );

		return max( 1, $lote );
	}

	/* ------------------------------------------------------------------ *
	 * Journal e apoio
	 * ------------------------------------------------------------------ */

	/**
	 * Acrescenta uma entrada ao journal.
	 *
	 * Nenhum campo de conteúdo entra: identificador, contagem, carimbo, operador,
	 * regime e o motivo da janela zerada, e só.
	 *
	 * O MOTIVO DIZ POR QUE, NUNCA O QUÊ. `reversivel_ate` em zero significa duas
	 * coisas diferentes — a janela venceu e o lote foi eliminado, ou este host
	 * nunca teve janela porque a lixeira do WordPress está desligada — e quem lê
	 * o journal meses depois não tem como distinguir as duas por um zero. O campo
	 * carrega essa distinção e nada mais: ele nunca recebe conteúdo do registro
	 * eliminado, que é a promessa inteira desta option.
	 *
	 * @param string $regime         `operacional` ou `titular`.
	 * @param string $identificador  Identificadores técnicos afetados.
	 * @param string $impressao      Impressão do identificador do titular.
	 * @param int    $contagem       Quantos registros.
	 * @param string $operador       Quem pediu.
	 * @param int    $reversivel_ate Fim da janela reversível, 0 quando irreversível.
	 * @param string $motivo         Por que a janela saiu zerada; vazio quando não há o que distinguir.
	 * @return void
	 */
	private function registrar_journal( string $regime, string $identificador, string $impressao, int $contagem, string $operador, int $reversivel_ate, string $motivo = '' ): void {
		$journal = F3Base_Options::ler( 'f3base_journal_eliminacao' );
		$journal = is_array( $journal ) ? $journal : array();

		$journal[] = array(
			'regime'             => $regime,
			'identificador'      => $identificador,
			'identificador_hash' => $impressao,
			'contagem'           => $contagem,
			'em'                 => time(),
			'operador'           => $operador,
			'reversivel_ate'     => $reversivel_ate,
			'motivo'             => $motivo,
		);

		F3Base_Options::gravar( 'f3base_journal_eliminacao', $journal, F3Base_Options::ORIGEM_MANUAL );
	}

	/**
	 * Impressão irreversível do identificador do titular.
	 *
	 * O journal precisa provar QUE algo foi eliminado sem guardar QUEM em claro.
	 *
	 * @param string $identificador Identificador informado.
	 * @return string
	 */
	private function impressao( string $identificador ): string {
		return hash_hmac( 'sha256', strtolower( trim( $identificador ) ), wp_salt( 'auth' ) );
	}

	/**
	 * Localiza registros por e-mail, record_id ou ID de post.
	 *
	 * @param string $identificador Identificador informado.
	 * @param int    $pagina        Página pedida, a partir de 1.
	 * @param int    $por_pagina    Tamanho da página; 0 usa o teto declarado.
	 * @return int[]
	 */
	private function localizar( string $identificador, int $pagina = 1, int $por_pagina = 0 ): array {
		$identificador = trim( $identificador );

		if ( '' === $identificador ) {
			return array();
		}

		$pagina     = max( 1, $pagina );
		$por_pagina = $por_pagina > 0 ? $por_pagina : self::TETO_DA_CONTAGEM;

		if ( ctype_digit( $identificador ) ) {
			$post = get_post( (int) $identificador );
			if ( $post instanceof WP_Post && in_array( $post->post_type, $this->tipos_de_lead(), true ) ) {
				/* Um id casa com um registro só: a página 2 dele está vazia. */
				return 1 === $pagina ? array( (int) $post->ID ) : array();
			}
		}

		$meta = is_email( $identificador ) ? '_f3base_email' : '_f3base_record_id';

		$ids = get_posts(
			array(
				'post_type'              => $this->tipos_de_lead(),
				'post_status'            => 'any',
				'numberposts'            => $por_pagina,
				'offset'                 => ( $pagina - 1 ) * $por_pagina,
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => false,
				'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'     => $meta,
						'value'   => $identificador,
						'compare' => '=',
					),
				),
			)
		);

		return is_array( $ids ) ? array_map( 'intval', $ids ) : array();
	}

	/**
	 * Tipos de conteúdo que guardam lead.
	 *
	 * @return string[]
	 */
	private function tipos_de_lead(): array {
		$tipos = array( F3Base_Modulo_Endpoint_Leads::CPT );

		if ( post_type_exists( 'flamingo_inbound' ) ) {
			$tipos[] = 'flamingo_inbound';
		}

		/**
		 * Permite acrescentar outra caixa de leads à retenção.
		 *
		 * @param string[] $tipos Tipos de conteúdo cobertos.
		 */
		$tipos = apply_filters( 'f3base_tipos_de_lead', $tipos );

		return is_array( $tipos ) ? array_values( array_unique( array_map( 'strval', $tipos ) ) ) : array( F3Base_Modulo_Endpoint_Leads::CPT );
	}

	/**
	 * Prazo de retenção, em meses.
	 *
	 * @return int
	 */
	private function meses(): int {
		$meses = F3Base_Options::ler( 'f3base_retencao_meses' );

		return is_int( $meses ) ? $meses : 12;
	}

	/**
	 * Janela reversível da limpeza operacional, em segundos.
	 *
	 * @return int
	 */
	private function janela_reversivel(): int {
		$dias = (int) apply_filters( 'f3base_janela_reversivel_dias', 30 );

		return max( DAY_IN_SECONDS, $dias * DAY_IN_SECONDS );
	}

	/**
	 * Timestamp previsto da execução, guardado na atividade.
	 *
	 * @return int
	 */
	private function previsto(): int {
		$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ATRASO_CRON );

		return isset( $carimbo['previsto'] ) ? (int) $carimbo['previsto'] : 0;
	}

	/**
	 * Guarda a previsão da próxima execução, para medir o atraso seguinte.
	 *
	 * @param int $quando Timestamp previsto.
	 * @return void
	 */
	private function guardar_previsao( int $quando ): void {
		F3Base_Atividade::registrar(
			F3Base_Atividade::ATRASO_CRON,
			array( 'previsto' => $quando )
		);
	}
}
