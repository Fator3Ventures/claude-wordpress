<?php
/**
 * Censo do conteúdo demonstrativo NO BANCO DO SITE.
 *
 * POR QUE ESTA CLASSE EXISTE, e o defeito medido que a motiva. Até a 1.1.1 a
 * única medição de "o conteúdo ainda é o do template" era de BUILD: a checagem
 * `conteudo.demonstrativo` lia `config.conteudo.demonstrativo` e os arquivos de
 * `content/` do pacote. Sob a premissa desta operação — *"após a instalação,
 * todas as futuras modificações serão realizadas por um agente através de MCP"*
 * — o agente substitui o conteúdo PELO CANAL e nunca toca em `content/` nem no
 * arquivo único. A flag fica `true` para sempre, e o WARN continua saindo depois
 * de o template ter sumido inteiro do site: um aviso sobre um estado que não
 * existe mais, que é a forma mais barata de ensinar alguém a ignorar avisos.
 *
 * A marca `<prefixo>:conteudo-demonstrativo` viaja DENTRO de cada página
 * publicada desde a 1.0.15 — ela abre o arquivo de `content/`, e o arquivo
 * inteiro vira `post_content`. Então a pergunta certa tem resposta no banco:
 * quantas páginas publicadas ainda carregam a marca, e QUAIS.
 *
 * Duas propriedades desta regra, e as duas são deliberadas:
 *
 * 1. **A contagem decide, não a flag.** Zero páginas marcadas é zero aviso,
 *    qualquer que seja `conteudo.demonstrativo`. A flag continua sendo a
 *    declaração do build; o site é o fato.
 * 2. **A marca é montada do PREFIXO declarado, nunca de literal.** Este pacote
 *    é template de criação de sites: cada site recebe o seu prefixo, e uma marca
 *    literal aqui seria a marca do template sobrevivendo dentro do site do
 *    cliente.
 *
 * A classe não tem pai e não depende de nenhuma outra do plugin, pelo mesmo
 * motivo de `F3Base_Emissores`: ela roda em DOIS runtimes que não se enxergam —
 * no `site-core`, na cadência, e no implantador, no modo somente-relatório.
 * Duas cópias da regra divergiriam na primeira condição acrescentada. ELA MORA
 * NESTE REPOSITÓRIO, em `fontes/plugin/includes/`, e é daqui que o zip a leva;
 * o implantador VENDORIZA uma cópia dela na árvore dele e a alcança por
 * `require_once`.
 *
 * ELA USA O WORDPRESS, e isso a separa das outras três partilhadas: a consulta
 * é `$wpdb->prepare()` sobre `{$wpdb->posts}` e os tipos saem de
 * `get_post_types()`. O que ela não tem é PAI e DEPENDÊNCIA INTERNA — é isso
 * que a deixa carregável nos dois runtimes, e não uma abstinência de núcleo que
 * ela nunca teve. Quem chama do lado sem banco recebe conjunto vazio pelas
 * guardas de `$wpdb`, que é a única concessão que a regra faz.
 *
 * A GUARDA DE `class_exists` é obrigatória e é a mesma das irmãs: os dois
 * runtimes alcançam esta classe por CAMINHOS DE ARQUIVO DIFERENTES, e
 * `require_once` não os reconhece como o mesmo arquivo. Sem a guarda, um
 * processo que carregue os dois — o implantador rodando dentro de um site com o
 * `site-core` ativo, que é o modo somente-relatório — morre em
 * `Cannot declare class F3Base_Censo_Demonstrativo`. Ela faltava aqui e existia
 * nas três irmãs: uma diferença invisível até o dia em que os dois se
 * encontram.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'F3Base_Censo_Demonstrativo' ) ) {

	/**
	 * Censo, no banco, das páginas publicadas que ainda são as do template.
	 */
	final class F3Base_Censo_Demonstrativo {

		/**
		 * Sufixo da marca. O prefixo do site é quem a completa.
		 */
		public const SUFIXO = ':conteudo-demonstrativo';

		/**
		 * Teto de nomes que a mensagem imprime antes de resumir.
		 *
		 * Contagem sem nome não responde à pergunta do operador, que é "quais?"; e
		 * uma lista de duzentos títulos não cabe numa linha de relatório. O teto é
		 * declarado, e o que sobra sai contado — nunca omitido em silêncio.
		 */
		public const TETO_DE_NOMES = 12;

		/**
		 * A marca deste site, montada do prefixo declarado.
		 *
		 * @param string $prefixo Prefixo técnico do site.
		 * @return string Marca, ou vazio quando não há prefixo.
		 */
		public static function marca( string $prefixo ): string {
			$prefixo = trim( $prefixo );

			return '' === $prefixo ? '' : $prefixo . self::SUFIXO;
		}

		/**
		 * As páginas PUBLICADAS que ainda carregam a marca, com id e título.
		 *
		 * A consulta é direta porque a pergunta é direta: existe a marca dentro de
		 * `post_content`? Uma busca por `WP_Query` com `s` passaria pelos filtros de
		 * busca do site e por relevância, e o que se quer aqui é uma ocorrência
		 * literal. Os tipos de post saem MEDIDOS de `get_post_types()` — escrever
		 * `page` e `post` aqui deixaria de fora todo tipo que o agente criar depois.
		 *
		 * @param string $prefixo Prefixo técnico do site.
		 * @return array<int,array{id:int,titulo:string,tipo:string}>
		 */
		public static function paginas_marcadas( string $prefixo ): array {
			$marca = self::marca( $prefixo );

			if ( '' === $marca ) {
				return array();
			}

			global $wpdb;

			if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
				return array();
			}

			$tipos = function_exists( 'get_post_types' ) ? array_values( (array) get_post_types( array( 'public' => true ), 'names' ) ) : array();
			$tipos = array_values( array_filter( array_map( 'strval', $tipos ) ) );

			if ( array() === $tipos ) {
				return array();
			}

			$marcadores = implode( ', ', array_fill( 0, count( $tipos ), '%s' ) );

			$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"SELECT ID, post_title, post_type FROM {$wpdb->posts} WHERE post_status = %s AND post_type IN ( {$marcadores} ) AND post_content LIKE %s ORDER BY ID ASC", // phpcs:ignore WordPress.DB.PreparedSQL
					array_merge(
						array( 'publish' ),
						$tipos,
						array( '%' . $wpdb->esc_like( $marca ) . '%' )
					)
				),
				ARRAY_A
			);

			$saida = array();

			foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
				$saida[] = array(
					'id'     => (int) ( $linha['ID'] ?? 0 ),
					'titulo' => (string) ( $linha['post_title'] ?? '' ),
					'tipo'   => (string) ( $linha['post_type'] ?? '' ),
				);
			}

			return $saida;
		}

		/**
		 * Quantas páginas publicadas existem — o denominador da medição.
		 *
		 * Sem ele, "nenhuma marcada" é indistinguível de "nenhuma medida", que é a
		 * mesma doença do escopo vazio que aprova por não ter olhado nada.
		 *
		 * @return int
		 */
		public static function publicadas(): int {
			global $wpdb;

			if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
				return 0;
			}

			$tipos = function_exists( 'get_post_types' ) ? array_values( (array) get_post_types( array( 'public' => true ), 'names' ) ) : array();
			$tipos = array_values( array_filter( array_map( 'strval', $tipos ) ) );

			if ( array() === $tipos ) {
				return 0;
			}

			$marcadores = implode( ', ', array_fill( 0, count( $tipos ), '%s' ) );

			$total = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = %s AND post_type IN ( {$marcadores} )", // phpcs:ignore WordPress.DB.PreparedSQL
					array_merge( array( 'publish' ), $tipos )
				)
			);

			return is_numeric( $total ) ? (int) $total : 0;
		}

		/**
		 * Nomes legíveis das páginas marcadas, com o teto declarado.
		 *
		 * @param array<int,array{id:int,titulo:string,tipo:string}> $marcadas Páginas marcadas.
		 * @return string
		 */
		public static function nomear( array $marcadas ): string {
			if ( array() === $marcadas ) {
				return '';
			}

			$nomes = array();

			foreach ( array_slice( $marcadas, 0, self::TETO_DE_NOMES ) as $pagina ) {
				$titulo  = '' !== $pagina['titulo'] ? $pagina['titulo'] : __( '(sem título)', 'f3base' );
				$nomes[] = $titulo . ' #' . $pagina['id'];
			}

			$resto = count( $marcadas ) - count( $nomes );

			return $resto > 0
				? implode( ', ', $nomes ) . sprintf(
					/* translators: %d: quantas páginas marcadas não couberam na lista. */
					__( ' (+%d)', 'f3base' ),
					$resto
				)
				: implode( ', ', $nomes );
		}

		/**
		 * O VEREDITO da medição no site. FUNÇÃO PURA sobre o que já foi medido.
		 *
		 * Separada da consulta de propósito: é ela que o piso exercita, e um piso
		 * que precisasse de um banco para provar a regra estaria provando o banco.
		 *
		 * Quatro ramos, e nenhum deles é silencioso:
		 *
		 * - **Sem prefixo**: não existe marca a procurar, e dizer "nada encontrado"
		 *   sobre uma busca que não pôde acontecer é o instrumento mentindo.
		 * - **Toda página marcada foi ESCRITA por quem está medindo, agora**: OK,
		 *   nomeando as páginas. O conteúdo do template está no ar porque ACABOU DE
		 *   SER IMPLANTADO — é o estado declarado, e não uma decadência.
		 * - **Sobra página marcada que quem mede NÃO escreveu**: WARN, nomeando só
		 *   essas. É conteúdo de template que sobreviveu a uma execução que deveria
		 *   tê-lo substituído, ou que continua no ar meses depois — aí o aviso tem
		 *   dono e ação.
		 * - **Nenhuma marcada**: OK, e o texto diz o que a flag declara, para que a
		 *   divergência entre a certidão de nascimento e o site fique visível sem
		 *   virar aviso.
		 *
		 * O DEFEITO QUE O TERCEIRO RAMO FECHA, medido em produção (2026-09-04): "7
		 * de 9 página(s) publicada(s) ainda carrega(m) a marca" — e as sete tinham
		 * sido publicadas por AQUELA MESMA execução, minutos antes, porque é isso
		 * que o implantador faz. A unidade `entrega` fechava WARN por ter cumprido o
		 * próprio desenho. Quem escreveu cada página marcada passou a ser parte do
		 * veredito.
		 *
		 * `$escritas` chega VAZIA por padrão, e isso é deliberado: o `site-core`
		 * continua chamando sem o argumento — na cadência ninguém escreveu nada, e é
		 * justamente ali que a pergunta vale ("um mês depois, o texto do template
		 * ainda está no ar?"). Vazia, toda página marcada cai no ramo do WARN, que é
		 * o comportamento que esta regra sempre teve.
		 *
		 * `$declarado` é `null` quando quem chama NÃO tem o arquivo único à mão — o
		 * caso do `site-core`, que roda no site e não carrega a configuração do
		 * implantador. A frase muda para dizer isso, em vez de imprimir um `false`
		 * que ninguém mediu.
		 *
		 * @param string                                             $prefixo    Prefixo técnico.
		 * @param bool|null                                          $declarado  O que `conteudo.demonstrativo` declara, ou null quando a configuração não está ao alcance.
		 * @param array<int,array{id:int,titulo:string,tipo:string}>  $marcadas   Páginas marcadas medidas.
		 * @param int                                                $publicadas Total de páginas publicadas medidas.
		 * @param array<int,int>                                     $escritas   IDs de post que ESTA execução escreveu; vazio quando quem mede não escreveu nada.
		 * @return array{estado:string,motivo:string,marcadas:int,medidas:int,nomes:string,recem_publicadas:int,sobreviventes:int}
		 */
		public static function veredito( string $prefixo, ?bool $declarado, array $marcadas, int $publicadas, array $escritas = array() ): array {
			$marca = self::marca( $prefixo );
			$flag  = null === $declarado
				? __( 'não alcançável deste runtime', 'f3base' )
				: ( $declarado ? 'true' : 'false' );

			if ( '' === $marca ) {
				return array(
					'estado'   => 'WARN',
					'motivo'   => __( 'não há prefixo técnico declarado, e sem ele não existe marca de conteúdo demonstrativo a procurar no banco: esta medição não aconteceu, e não ter medido não é o mesmo que não ter achado.', 'f3base' ),
					'marcadas' => 0,
					'medidas'  => $publicadas,
					'nomes'    => '',
					'recem_publicadas' => 0,
					'sobreviventes'    => 0,
				);
			}

			if ( array() !== $marcadas ) {
				$separadas     = self::separar( $marcadas, $escritas );
				$sobreviventes = $separadas['sobreviventes'];
				$recem         = $separadas['recem_publicadas'];

				if ( array() === $sobreviventes ) {
					return array(
						'estado'   => 'OK',
						'motivo'   => sprintf(
							/* translators: 1: quantas páginas marcadas, 2: total publicado, 3: os nomes, 4: a marca procurada, 5: o que a configuração declara. */
							__( '%1$d de %2$d página(s) publicada(s) carrega(m) a marca "%4$s", e TODAS elas foram escritas por esta mesma execução: %3$s. O conteúdo do template está no ar porque acabou de ser implantado, que é o estado DECLARADO (conteudo.demonstrativo = %5$s) e não uma decadência — avisar aqui seria o instrumento acusando o trabalho que ele mesmo acabou de fazer. O aviso volta a existir na primeira medição que encontrar uma página marcada que a execução NÃO escreveu: é essa a pergunta útil, e é a cadência do site-core que a faz.', 'f3base' ),
							count( $marcadas ),
							$publicadas,
							self::nomear( $recem ),
							$marca,
							$flag
						),
						'marcadas' => count( $marcadas ),
						'medidas'  => $publicadas,
						'nomes'    => self::nomear( $recem ),
						'recem_publicadas' => count( $recem ),
						'sobreviventes'    => 0,
					);
				}

				return array(
					'estado'   => 'WARN',
					'motivo'   => sprintf(
						/* translators: 1: quantas sobreviveram, 2: total publicado, 3: os nomes das sobreviventes, 4: a marca procurada, 5: o que a configuração declara, 6: quantas foram escritas agora. */
						__( '%1$d de %2$d página(s) publicada(s) ainda carrega(m) a marca "%4$s" SEM terem sido escritas por quem está medindo, e continua(m) sendo o conteúdo do TEMPLATE no ar: %3$s. Estas não são conteúdo recém-implantado: são texto de template que sobreviveu a quem deveria tê-lo substituído. (Outras %6$d página(s) marcada(s) foram escritas por esta execução e NÃO entram neste aviso — acusá-las seria acusar o trabalho que acabou de ser feito.) A medição é do BANCO deste site, não da configuração — a configuração declara conteudo.demonstrativo = %5$s, e ela é certidão de nascimento, não estado corrente. Substituir o conteúdo pelo canal faz a marca sair junto, e este aviso some sem release nova.', 'f3base' ),
						count( $sobreviventes ),
						$publicadas,
						self::nomear( $sobreviventes ),
						$marca,
						$flag,
						count( $recem )
					),
					'marcadas' => count( $marcadas ),
					'medidas'  => $publicadas,
					'nomes'    => self::nomear( $sobreviventes ),
					'recem_publicadas' => count( $recem ),
					'sobreviventes'    => count( $sobreviventes ),
				);
			}

			return array(
				'estado'   => 'OK',
				'motivo'   => sprintf(
					/* translators: 1: total publicado, 2: a marca procurada, 3: o que a configuração declara. */
					__( 'nenhuma das %1$d página(s) publicada(s) carrega a marca "%2$s": o conteúdo no ar é o deste site. A configuração declara conteudo.demonstrativo = %3$s, e isso NÃO produz aviso — ela é a certidão de nascimento do pacote, e quem responde por este estado é o banco.', 'f3base' ),
					$publicadas,
					$marca,
					$flag
				),
				'marcadas' => 0,
				'medidas'  => $publicadas,
				'nomes'    => '',
				'recem_publicadas' => 0,
				'sobreviventes'    => 0,
			);
		}

		/**
		 * SEPARA as páginas marcadas por QUEM as escreveu. Regra pura, sem banco.
		 *
		 * Um id que está no conjunto de escritas desta execução é conteúdo
		 * recém-implantado; o que não está sobreviveu a alguém. A comparação é por
		 * ID de post — o único identificador que o journal e o banco compartilham.
		 *
		 * @param array<int,array{id:int,titulo:string,tipo:string}> $marcadas Páginas marcadas.
		 * @param array<int,int>                                     $escritas IDs escritos por quem mede.
		 * @return array{recem_publicadas:array<int,array{id:int,titulo:string,tipo:string}>,sobreviventes:array<int,array{id:int,titulo:string,tipo:string}>}
		 */
		public static function separar( array $marcadas, array $escritas ): array {
			$ids   = array_map( 'intval', array_values( $escritas ) );
			$recem = array();
			$resto = array();

			foreach ( $marcadas as $pagina ) {
				if ( in_array( (int) ( $pagina['id'] ?? 0 ), $ids, true ) ) {
					$recem[] = $pagina;
					continue;
				}

				$resto[] = $pagina;
			}

			return array(
				'recem_publicadas' => $recem,
				'sobreviventes'    => $resto,
			);
		}

		/**
		 * A medição inteira, do banco desta instalação.
		 *
		 * @param string         $prefixo   Prefixo técnico do site.
		 * @param bool|null      $declarado O que `conteudo.demonstrativo` declara, ou null quando a configuração não está ao alcance deste runtime.
		 * @param array<int,int> $escritas  IDs de post que quem mede escreveu nesta execução; vazio quando ninguém escreveu nada.
		 * @return array{estado:string,motivo:string,marcadas:int,medidas:int,nomes:string,recem_publicadas:int,sobreviventes:int}
		 */
		public static function medir( string $prefixo, ?bool $declarado, array $escritas = array() ): array {
			return self::veredito( $prefixo, $declarado, self::paginas_marcadas( $prefixo ), self::publicadas(), $escritas );
		}
	}
}
