<?php
/**
 * Orquestrador do plugin.
 *
 * Registra os hooks LENDO O REGISTRO ÚNICO: nenhum `add_action` de módulo é
 * escrito aqui à mão. Módulo inativo não registra nada — é inerte de verdade.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ciclo de vida do site-core.
 */
final class F3Base_Site_Core {

	/**
	 * Prioridade em que os hooks dos módulos são registrados, dentro de `init`.
	 *
	 * Registrar em `init` (e não em `plugins_loaded`) mantém toda leitura de
	 * estado depois do carregamento do text domain: chamar tradução antes de
	 * `init` gera aviso do core desde o WordPress 6.7.
	 */
	public const PRIORIDADE_REGISTRO = 5;

	/**
	 * Liga o plugin.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
		add_action( 'admin_notices', array( __CLASS__, 'avisar_copia_desativada' ) );
		add_action( 'init', array( __CLASS__, 'registrar' ), self::PRIORIDADE_REGISTRO );
		add_action( 'rest_api_init', array( __CLASS__, 'registrar_rota_relatorio' ), 10 );

		/*
		 * AS HABILIDADES QUE DIZEM AO AGENTE COMO USAR O PLUGIN, e a grafia do
		 * gancho é a metade que faltava.
		 *
		 * O DEFEITO MEDIDO num WordPress 7.1 real: o gancho era
		 * `abilities_api_init`, SEM o prefixo `wp_`. Esse nome não existe no
		 * núcleo — a Abilities API dispara `wp_abilities_api_init` —, e um
		 * `add_action` num gancho que ninguém dispara não falha, não avisa e não
		 * registra nada. As três habilidades simplesmente não existiam:
		 * `wp_get_abilities()` devolvia só as do núcleo, e o caminho documentado
		 * para um agente ler e gravar a configuração do site não estava no ar.
		 *
		 * A CATEGORIA VEM ANTES, e num gancho próprio. O núcleo recusa habilidade
		 * cuja `category` não esteja registrada, e a janela para registrá-la é
		 * `wp_abilities_api_categories_init`, que dispara antes. Registrar a
		 * categoria dentro do gancho das habilidades chegaria tarde: as três
		 * seriam recusadas com `_doing_it_wrong` e sumiriam de novo.
		 */
		add_action( 'wp_abilities_api_categories_init', array( __CLASS__, 'registrar_categoria_de_habilidades' ) );
		add_action( 'wp_abilities_api_init', array( 'F3Base_Como_Usar', 'registrar' ) );
		add_action( 'wp_abilities_api_init', array( 'F3Base_Config_Mcp', 'registrar' ) );
		add_action( 'wp_abilities_api_init', array( 'F3Base_Acessos_Mcp', 'registrar' ) );

		if ( is_admin() ) {
			F3Base_Admin_Tela::iniciar();
			/*
			 * A MEDIÇÃO GANHOU CASA PRÓPRIA na 1.1.0. Ela morava no fim da tela
			 * de configuração, depois de trinta campos de formulário: quem abre
			 * aquela tela vai gravar uma option, e quem quer saber o que os
			 * visitantes fizeram tem outra pergunta — que não é sub-item de
			 * configuração nenhuma.
			 */
			F3Base_Admin_Medicao::iniciar();
		}
	}

	/**
	 * A CATEGORIA DAS HABILIDADES DESTE PLUGIN.
	 *
	 * POR QUE ELA EXISTE, e não é formalidade. O núcleo exige `category` em toda
	 * habilidade registrada e RECUSA a que traz uma categoria desconhecida — "The
	 * ability properties must contain a `category` string" foi a recusa medida na
	 * bancada. A categoria é também o que um agente vê antes de escolher: sem uma
	 * própria, as três habilidades deste plugin cairiam numa gaveta genérica ao
	 * lado das do núcleo, e quem procura "por onde mudo a medição deste site" não
	 * teria como saber que elas existem.
	 *
	 * O SLUG É O PREFIXO DO PACOTE, `f3base`, pela mesma razão de todo o resto: é
	 * o nome que este pacote reivindica em option, tabela, evento e namespace
	 * REST, e categoria com nome genérico colide com a de outro plugin.
	 *
	 * @return void
	 */
	public static function registrar_categoria_de_habilidades(): void {
		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		wp_register_ability_category(
			F3BASE_PREFIXO,
			array(
				'label'       => __( 'Base Site Core Fator3', 'f3base' ),
				'description' => __( 'Leitura e escrita da configuração deste site pelo plugin persistente do Método F3: o que ele já faz por assunto, a option exata de cada ajuste, e a configuração do implantador para a execução seguinte.', 'f3base' ),
			)
		);
	}

	/**
	 * Registra os hooks declarados pelos módulos do registro único.
	 *
	 * Módulo inativo continua inerte — nenhum asset, nenhum endpoint, nenhuma
	 * tabela —, com UMA exceção declarada por hook: o item marcado `sempre` é
	 * registrado de qualquer jeito. Ele existe para o filtro cuja decisão é POR
	 * OBJETO, e cujo caso mais importante acontece justamente com o módulo
	 * inativo: o bloco do CTA sem número. Antes desta exceção, o filtro que
	 * decidia publicar o botão só era registrado quando a condição dele já não
	 * podia acontecer, e a regra nunca rodava.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		foreach ( F3Base_Registro::modulos() as $modulo ) {
			$ativo = $modulo->deve_registrar();

			foreach ( $modulo->hooks() as $hook ) {
				if ( ! $ativo && empty( $hook['sempre'] ) ) {
					continue;
				}

				$metodo = (string) $hook['metodo'];

				if ( ! method_exists( $modulo, $metodo ) ) {
					continue;
				}

				$callback   = array( $modulo, $metodo );
				$prioridade = (int) $hook['prioridade'];
				$args       = (int) $hook['args'];

				if ( 'filter' === (string) $hook['tipo'] ) {
					add_filter( (string) $hook['hook'], $callback, $prioridade, max( 1, $args ) );
					continue;
				}

				add_action( (string) $hook['hook'], $callback, $prioridade, $args );
			}
		}
	}

	/**
	 * Rota de leitura do relatório — a mesma estrutura que a tela renderiza.
	 *
	 * @return void
	 */
	public static function registrar_rota_relatorio(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/relatorio',
			array(
				'methods'             => 'GET',
				'callback'            => static function (): WP_REST_Response {
					return new WP_REST_Response( F3Base_Registro::relatorio(), 200 );
				},
				'permission_callback' => static function (): bool {
					return current_user_can( 'manage_options' );
				},
				'args'                => array(),
			)
		);
	}

	/**
	 * Relatório do plugin, para o implantador e para a suíte.
	 *
	 * @return array<string,mixed>
	 */
	public static function relatorio(): array {
		return F3Base_Registro::relatorio();
	}

	/**
	 * Nome do transiente que carrega, para a tela, o que a ativação desativou.
	 *
	 * Transiente e não option: a mensagem é de UMA ativação, tem prazo e não é
	 * estado do site. Option sem prazo obrigaria alguém a apagá-la depois, e
	 * option que ninguém apaga vira aviso permanente sobre um fato de um dia só.
	 */
	public const TRANSIENTE_MIGRACAO = 'f3base_copia_anterior_desativada';

	/**
	 * Marca que o arquivo principal de uma cópia deste plugin sempre carrega.
	 *
	 * O DISCRIMINANTE NÃO É O NOME DA PASTA, e é isso que o torna honesto. Uma
	 * lista literal de pastas antigas só reconhece o que alguém lembrou de
	 * escrever nela, e a pasta antiga deste plugin não é a única que pode
	 * existir: sites renomeados por `ferramentas/renomear-prefixo.sh` até a
	 * 1.6.6 receberam um FORK dele com outro nome de pasta ainda. O que TODAS
	 * essas cópias têm em comum é a reivindicação do mesmo namespace REST — é
	 * dela que vem a colisão, porque é ela que faz duas cópias registrarem as
	 * MESMAS rotas.
	 */
	public const MARCA_DE_COPIA = 'F3BASE_REST_NAMESPACE';

	/**
	 * DESATIVA QUALQUER OUTRA CÓPIA ATIVA DESTE MESMO PLUGIN.
	 *
	 * O DEFEITO QUE ISTO IMPEDE, e ele é real: existe pelo menos um site em
	 * produção com este plugin na pasta antiga (`f3base-site-core`, 1.3.6).
	 * Instalar a pasta nova ali deixa DUAS CÓPIAS DO MESMO PLUGIN ATIVAS ao
	 * mesmo tempo. O WordPress não impede isso e não avisa: são dois registros
	 * de hooks, dois `register_rest_route` para o mesmo endpoint, dois
	 * coletores enfileirados na mesma página e a conversão contada em dobro na
	 * conta de medição do fornecedor. Nada disso aparece como erro — aparece
	 * como número errado, semanas depois, sem nada que aponte para a causa.
	 *
	 * NÃO HÁ DADO A MIGRAR, e é exatamente por isso que o prefixo interno não
	 * mudou: as options são as mesmas `f3base_*` e as tabelas são as mesmas
	 * `f3base_comportamento` e `f3base_eventos`. A cópia nova encontra a
	 * configuração do site inteira, no lugar onde ela sempre esteve. O que
	 * mudou foi o ENDEREÇO do código, e endereço não guarda dado.
	 *
	 * POR QUE DESATIVAR A OUTRA, E NÃO RECUSAR ATIVAR ESTA. A recusa foi
	 * considerada e é pior por três razões medidas:
	 *
	 * 1. Recusar deixa o site rodando a cópia ANTIGA — que é o artefato que
	 *    esta release existe para substituir — e transfere a correção para uma
	 *    pessoa ler uma mensagem. A instalação é feita pelo implantador, sem
	 *    ninguém olhando; a mensagem chegaria a um relatório e o site seguiria
	 *    exatamente como estava.
	 * 2. O dano das duas cópias já existe no instante da ativação, e recusar
	 *    não o desfaz: ele só não fica pior. Desativar a antiga é a única ação
	 *    que devolve o site a UMA cópia.
	 * 3. Desativar plugin alheio seria atrevimento. Este não é alheio: é uma
	 *    cópia MAIS VELHA DESTE MESMO PLUGIN, reconhecida pela reivindicação do
	 *    mesmo namespace REST, e o WordPress não tem como servir os dois.
	 *
	 * O QUE ISTO NÃO FAZ, e o limite importa: não apaga arquivo nenhum, não
	 * toca em option nem em tabela, e não desativa nada que não carregue a
	 * marca. A pasta antiga continua em disco, legível, e reativá-la é um
	 * clique — a ação é reversível, e é isso que a torna aceitável. O que ela
	 * deixa é REGISTRO: um transiente que a tela lê e um nome, nunca um número.
	 *
	 * @return array<int,string> Os arquivos principais que foram desativados.
	 */
	public static function desativar_copias_do_mesmo_plugin(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$este       = plugin_basename( F3BASE_PLUGIN_ARQUIVO );
		$desativar  = array();

		foreach ( array_keys( get_plugins() ) as $arquivo ) {
			$arquivo = (string) $arquivo;

			if ( $arquivo === $este || ! is_plugin_active( $arquivo ) ) {
				continue;
			}

			$principal = WP_PLUGIN_DIR . '/' . $arquivo;

			if ( ! is_readable( $principal ) ) {
				continue;
			}

			/*
			 * Os mesmos 8 KiB que `get_file_data()` lê. Um arquivo principal
			 * que define o namespace REST deste plugin É uma cópia dele: a
			 * constante é a reivindicação, e duas reivindicações do mesmo
			 * namespace são duas cópias servindo as mesmas rotas.
			 */
			$topo = (string) file_get_contents( $principal, false, null, 0, 8192 );

			if ( ! str_contains( $topo, self::MARCA_DE_COPIA ) ) {
				continue;
			}

			$desativar[] = $arquivo;
		}

		if ( array() === $desativar ) {
			return array();
		}

		/*
		 * `true` NO SEGUNDO ARGUMENTO — `$silent` —, e o comentário anterior
		 * descrevia outro parâmetro: ele dizia "false no terceiro argumento",
		 * que em `deactivate_plugins( $plugins, $silent, $network_wide )` é o
		 * escopo de rede, e não o silêncio. Quem lesse o comentário para mexer
		 * na linha mexeria no argumento errado.
		 *
		 * O QUE `$silent = true` FAZ é o que esta chamada precisa: NÃO dispara
		 * `deactivate_plugin` nem `deactivated_plugin`, e portanto não roda o
		 * gancho de desativação da cópia antiga. O gancho dela desinstala os
		 * módulos e desagenda a cadência — os MESMOS agendamentos que esta cópia
		 * acabou de instalar, porque as chaves são as mesmas. Rodá-lo desfaria a
		 * ativação em curso, e o site ficaria com o plugin ativo e a cadência
		 * desagendada, calado.
		 */
		deactivate_plugins( $desativar, true );

		set_transient( self::TRANSIENTE_MIGRACAO, $desativar, WEEK_IN_SECONDS );

		return $desativar;
	}

	/**
	 * Aviso da tela: o que a ativação desativou, com o nome e o motivo.
	 *
	 * Ele é lido UMA vez e apagado: o fato é de uma ativação, não do site.
	 *
	 * @return void
	 */
	public static function avisar_copia_desativada(): void {
		$desativados = get_transient( self::TRANSIENTE_MIGRACAO );

		if ( ! is_array( $desativados ) || array() === $desativados ) {
			return;
		}

		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		delete_transient( self::TRANSIENTE_MIGRACAO );

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: %s: lista de arquivos principais de plugin desativados. */
					__( 'Base Site Core Fator3 desativou uma cópia mais velha de si mesmo que estava ativa neste site: %s. Duas cópias ativas registram os mesmos hooks e as mesmas rotas REST, e a conversão passa a ser contada em dobro sem nenhum erro aparecer. Nenhum dado foi tocado: as options f3base_* e as tabelas f3base_comportamento e f3base_eventos são as mesmas dos dois lados, e é por isso que não há o que migrar. A pasta antiga continua em disco e pode ser reativada por um clique — o que não pode existir é as duas ativas ao mesmo tempo.', 'f3base' ),
					implode( ', ', array_map( 'strval', $desativados ) )
				)
			)
		);
	}

	/**
	 * Ativação: recusa a ativação em rede, desativa cópia anterior deste mesmo
	 * plugin, semeia os padrões e instala a estrutura dos módulos.
	 *
	 * A ORDEM É A DO CÓDIGO. A cópia velha sai ANTES de qualquer escrita: com
	 * ela ativa, os hooks dela ainda estão registrados nesta requisição, e a
	 * semeadura veria o estado das duas.
	 *
	 * `FLUSH_REWRITE_RULES()` SAIU DAQUI, e ele era TRABALHO PURO. A chamada
	 * regrava a option `rewrite_rules` inteira — em site grande é a operação
	 * mais cara da ativação — e existe para publicar as regras que o plugin
	 * REGISTROU. Este plugin não registra nenhuma: `add_rewrite_rule`,
	 * `add_permastruct` e `add_rewrite_endpoint` não aparecem em arquivo nenhum
	 * dele. As rotas que ele serve são REST (`register_rest_route`, que não usa
	 * a tabela de reescrita) e as reservas de `/llms.txt` e `/llms-full.txt`,
	 * servidas em `template_redirect` pela requisição em curso. O comentário
	 * anterior descrevia regras que não existem, e um comentário assim é o que
	 * faz alguém procurar por horas o efeito de uma linha que não tem nenhum.
	 *
	 * @param bool $em_rede Verdadeiro quando o WordPress está ativando o plugin
	 *                      para a rede inteira (`$network_wide`).
	 * @return void
	 */
	public static function ativar( bool $em_rede = false ): void {
		self::recusar_ativacao_em_rede( $em_rede );

		self::desativar_copias_do_mesmo_plugin();

		self::semear_padroes();

		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			if ( $modulo->deve_registrar() ) {
				$modulo->instalar();
			}
		}
	}

	/**
	 * MULTISITE NÃO É SUPORTADO NA 1.0.0, e a ativação em rede é recusada.
	 *
	 * O LIMITE MEDIDO, dito por inteiro. Ativado para a rede, este plugin
	 * registraria os hooks em todos os sites, mas TUDO o que ele guarda é do
	 * site corrente e por site: options `f3base_*`, as tabelas
	 * `f3base_comportamento` e `f3base_eventos`, o CPT de contingência e os
	 * agendamentos. A desinstalação, que o WordPress roda UMA vez, limparia o
	 * site corrente e deixaria as tabelas e as options de todos os outros — dado
	 * pessoal pseudonimizado guardado por um plugin que já não existe. Não há
	 * `wpmu_drop_tables`, não há laço por blog, e fingir que há seria pior que
	 * declarar o limite.
	 *
	 * RECUSAR É BARATO E É REVERSÍVEL: quem quer o plugin numa rede o ativa SITE
	 * A SITE, e cada ativação faz exatamente o que faz numa instalação única.
	 * O que a recusa impede é a ativação em rede — a única forma em que a
	 * desinstalação prometeria uma limpeza que ela não sabe fazer.
	 *
	 * @param bool $em_rede Escopo da ativação.
	 * @return void
	 */
	private static function recusar_ativacao_em_rede( bool $em_rede ): void {
		if ( ! $em_rede ) {
			return;
		}

		deactivate_plugins( plugin_basename( F3BASE_PLUGIN_ARQUIVO ), true, true );

		wp_die(
			esc_html__( 'Base Site Core Fator3 1.0.0 não suporta ativação em rede. Tudo o que ele guarda é do site corrente e por site — options, as tabelas de comportamento e de eventos, o registro de contingência e os agendamentos —, e a desinstalação que o WordPress roda uma única vez limparia só um dos sites, deixando dado pessoal pseudonimizado nos demais. Ative o plugin SITE A SITE pela tela de plugins de cada site: ali ele faz exatamente o que faz numa instalação única.', 'f3base' ),
			esc_html__( 'Ativação em rede recusada', 'f3base' ),
			array( 'back_link' => true )
		);
	}

	/**
	 * Desativação: desfaz agendamentos e a estrutura instalável dos módulos.
	 *
	 * Nenhum dado de lead é tocado aqui: desativar plugin não é pedido de
	 * eliminação, e apagar registro pessoal sem journal é perda sem registro.
	 *
	 * Sem `flush_rewrite_rules()` pela mesma razão da ativação: não há regra de
	 * reescrita deste plugin para retirar da tabela.
	 *
	 * @return void
	 */
	public static function desativar(): void {
		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			$modulo->desinstalar();
		}
	}

	/**
	 * Grava o padrão embutido apenas nas options que ainda não existem.
	 *
	 * Option já escrita pelo implantador nunca é sobrescrita na ativação.
	 *
	 * @return void
	 */
	private static function semear_padroes(): void {
		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) {
			if ( F3Base_Options::existe( $nome ) ) {
				continue;
			}

			if ( isset( $declaracao['campo'] ) && 'segredo' === $declaracao['campo'] ) {
				continue;
			}

			F3Base_Options::gravar( $nome, $declaracao['padrao'], F3Base_Options::ORIGEM_PADRAO );
		}
	}
}
