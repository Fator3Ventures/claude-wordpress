<?php
/** Gerador virtual com troca reversível do arquivo físico e regras do WordPress. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Modulo_Robots_Txt extends F3Base_Modulo {
	public function id(): string {
		return 'robots-txt';
	}
	public function nome(): string {
		return 'Robots.txt do site';
	}
	public function descricao(): string {
		return 'Publica as regras do WordPress e dos plugins, confirma a resposta HTTP e mantém um arquivo gerenciado quando a hospedagem intercepta a rota virtual. Guarda o original e restaura ao desligar.';
	}
	public function options_que_controlam(): array {
		return array( 'f3base_robots', F3Base_Robots_Arquivo::OPTION );
	}
	public function dependencias(): array {
		$estado = $this->estado();
		return array( array( 'rotulo' => 'Entrega pública confirmada por HTTP', 'presente' => self::ATIVO === $estado['estado'], 'detalhe' => $estado['motivo'] ) );
	}
	public function hooks(): array {
		return array(
			// A restauração precisa executar também com a opção desligada.
			array( 'tipo' => 'action', 'hook' => 'init', 'metodo' => 'sincronizar', 'prioridade' => 8, 'args' => 0, 'sempre' => true ),
			array( 'tipo' => 'filter', 'hook' => 'robots_txt', 'metodo' => 'complementar', 'prioridade' => PHP_INT_MAX, 'args' => 2 ),
			array( 'tipo' => 'filter', 'hook' => 'request', 'metodo' => 'reconhecer_rota', 'prioridade' => 0, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'template_redirect', 'metodo' => 'rota_reserva', 'prioridade' => 0, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'do_robotstxt', 'metodo' => 'cabecalhos', 'prioridade' => 0, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'wp_loaded', 'metodo' => 'planejar', 'prioridade' => 20, 'args' => 0, 'sempre' => true ),
			array( 'tipo' => 'action', 'hook' => F3Base_Robots_Entrega::EVENTO, 'metodo' => 'verificar', 'prioridade' => 10, 'args' => 0, 'sempre' => true ),
		);
	}
	/** Permalinks simples também precisam de is_robots antes de plugins registrarem filtros condicionais. */
	public function reconhecer_rota( array $vars ): array {
		$path = wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
		if ( '/robots.txt' === $path && in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', array( 'GET', 'HEAD' ), true ) && F3Base_Robots_Entrega::ligado() ) { $vars = array( 'robots' => '1' ); }
		return $vars;
	}
	/** Com permalinks simples, /robots.txt pode chegar ao núcleo como a home. */
	public function rota_reserva(): void {
		$path = wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
		if ( '/robots.txt' !== $path || ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', array( 'GET', 'HEAD' ), true ) || empty( F3Base_Options::ler( 'f3base_robots' )['ligado'] ) || '' !== F3Base_Llms::arquivo_publico( 'robots.txt' ) || is_robots() ) { return; }
		status_header( 200 );
		if ( 'HEAD' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) { ob_start(); do_robots(); ob_end_clean(); } else { do_robots(); }
		exit;
	}
	public function sincronizar(): void {
		F3Base_Robots_Arquivo::sincronizar();
	}
	public function planejar(): void { F3Base_Robots_Entrega::planejar(); }
	public function verificar(): void { F3Base_Robots_Entrega::verificar(); }
	public function cabecalhos(): void { F3Base_Robots_Entrega::cabecalhos(); }
	public function instalar(): void {
		F3Base_Robots_Arquivo::retomar();
	}
	public function desinstalar(): void {
		F3Base_Robots_Arquivo::suspender();
		F3Base_Robots_Entrega::parar();
	}
	protected function calcular_estado(): array {
		$e = F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION );
		if ( ! empty( $e['erro'] ) ) { return $this->degradado( 'Troca do robots.txt pendente: ' . $e['erro'] ); }
		if ( empty( F3Base_Options::ler( 'f3base_robots' )['ligado'] ) ) { return $this->inativo( 'Gerador do plugin desligado; original restaurado quando disponível e sem sobrescrever arquivos existentes.' ); }
		if ( ! empty( $e['suspenso'] ) ) { return $this->degradado( 'Gerador suspenso; retomada ocorre na reativação do plugin.' ); }
		[ $alvo, $erro ] = F3Base_Robots_Arquivo::destino();
		if ( $erro ) { return $this->degradado( $erro ); }
		$proprio = F3Base_Robots_Arquivo::proprio( $alvo, $e );
		if ( ( file_exists( $alvo ) || is_link( $alvo ) ) && ! $proprio ) { return $this->degradado( 'Arquivo físico de terceiros prevalece. Arquivo e backup são preservados até resolver o conflito.' ); }
		$d = (array) ( $e['entrega'] ?? array() );
		if ( ! empty( $d['erro'] ) ) { return $this->degradado( (string) $d['erro'] ); }
		if ( empty( $d['ok'] ) || ( $d['assinatura'] ?? '' ) !== F3Base_Robots_Entrega::assinatura() || time() - (int) ( $d['verificado_em'] ?? 0 ) > F3Base_Robots_Entrega::INTERVALO * 2 || empty( $d['esperado_sha256'] ) || ( $d['esperado_sha256'] ?? '' ) !== ( $d['recebido_sha256'] ?? '' ) || ( $proprio ? 'gerenciado' : 'virtual' ) !== ( $d['modo'] ?? '' ) ) {
			return $this->degradado( 'Entrega pública aguardando verificação atual. O WP-Cron verifica automaticamente e atualiza este diagnóstico; sem execução do cron a confirmação permanece pendente.' );
		}
		if ( $proprio && ( $e['gerenciado']['sha256'] ?? '' ) !== $d['esperado_sha256'] ) { return $this->degradado( 'Arquivo atualizado; nova confirmação da resposta pública pendente.' ); }
		return $this->ativo( 'Entrega HTTP confirmada em ' . wp_date( 'd/m/Y H:i:s', (int) $d['verificado_em'] ) . ( $proprio ? ', por arquivo gerenciado porque a rota virtual não prevaleceu.' : ', pela rota virtual.' ) . ' Revalidação automática a cada hora; original preservado quando existente.' );
	}

	public function complementar( string $texto, $publico ): string {
		$c = F3Base_Options::ler( 'f3base_robots' );
		$e = F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION );
		[ $alvo ] = F3Base_Robots_Arquivo::destino();
		if ( empty( $c['ligado'] ) || ! empty( $e['suspenso'] ) || ! $publico || ! F3Base_Llms::site_publico() || ( '' !== F3Base_Llms::arquivo_publico( 'robots.txt' ) && ! F3Base_Robots_Arquivo::proprio( $alvo, $e ) ) ) { return $texto; }
		$texto = str_replace( array( "\r\n", "\r" ), "\n", $texto );
		// Executa depois do Yoast e conserva apenas uma declaração de cada URL, sem alterar grupos ou regras.
		$vistos = array();
		$texto = implode( "\n", array_filter( explode( "\n", $texto ), static function ( string $linha ) use ( &$vistos ): bool {
			if ( ! preg_match( '/^\s*Sitemap\s*:\s*([^\s#]+)\s*(?:#.*)?$/iD', $linha, $m ) ) { return true; }
			if ( isset( $vistos[ $m[1] ] ) ) { return false; }
			$vistos[ $m[1] ] = true; return true;
		} ) );
		// O núcleo já mantém /wp-admin/ e sua exceção admin-ajax.php. Não bloqueamos recursos públicos.
		$sitemap = F3Base_Llms::url_markdown( (string) F3Base_Llms::sitemap_medido()['url'] );
		preg_match_all( '/^\s*Sitemap\s*:\s*([^\s#]+)\s*(?:#.*)?$/im', $texto, $existentes );
		if ( '' !== $sitemap && ! in_array( $sitemap, $existentes[1], true ) ) {
			$texto = rtrim( $texto ) . "\n\nSitemap: " . $sitemap . "\n";
		}
		return $texto;
	}
}
