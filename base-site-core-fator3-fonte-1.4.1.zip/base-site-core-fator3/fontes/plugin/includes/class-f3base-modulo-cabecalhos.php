<?php
/**
 * Módulo cabecalhos.
 *
 * Emite os cabeçalhos de resposta da configuração — os de segurança que não
 * alteram o carregamento de recurso nenhum.
 *
 * COOP SAI DO VALOR GRAVADO desde a 1.1.0. `same-origin-allow-popups` continua
 * sendo o valor de que o fluxo de leads precisa — `same-origin` corta a relação
 * com a janela que o CTA abre —, mas o pacote passou a NOMEAR a consequência em
 * vez de impor o valor: quem grava outra coisa lê de volta o que gravou, e o
 * estado do módulo fecha degradado dizendo o que se perde.
 *
 * HSTS fica desligado por padrão — é o único da lista com efeito persistente no
 * navegador, e a decisão é do cliente, com implantação escalonada.
 *
 * `Referrer-Policy: no-referrer` é aceito e AVISADO: ele apaga o referenciador
 * de toda saída, e é dele que dependem a atribuição de origem do GA4 e o
 * reconhecimento de tráfego pago de Google Ads, Meta Ads e LinkedIn Ads quando
 * o clique chega sem parâmetro de campanha. O aviso nomeia a perda; recusar o
 * valor seria decidir pelo projeto.
 *
 * ESTE MÓDULO NÃO ATROPELA OUTRO EMISSOR, e a regra tem duas metades porque os
 * cabeçalhos têm duas naturezas. `header()` com o `$replace` padrão SUBSTITUI o
 * valor que outro plugin, o tema ou o servidor já tinham posto: um site com CSP
 * emitida por um plugin de segurança perdia a política inteira e ficava com a
 * nossa linha de `frame-ancestors`, e uma `Permissions-Policy` mais restritiva
 * de outro emissor era afrouxada para a nossa. As duas metades:
 *
 * 1. **Content-Security-Policy COMPÕE** — a especificação manda o navegador
 *    aplicar a INTERSEÇÃO de todas as políticas entregues, então uma segunda
 *    linha só aperta. Ela sai com `$replace = false`.
 * 2. **Os demais só saem quando AUSENTES** — `headers_list()` diz o que já foi
 *    posto nesta resposta, e o que já tem dono este módulo cede, registrando o
 *    nome no estado. Ceder em silêncio seria a mesma cegueira ao contrário.
 *
 * A EMISSÃO ALCANÇA O REST desde a 1.0.0, e o recorte é decisão declarada:
 * `send_headers` não roda em toda resposta da API, e uma resposta JSON servida
 * sem `nosniff` é a mesma superfície que o HTML tem. Vão para o REST os
 * cabeçalhos que governam a RESPOSTA — `X-Content-Type-Options`,
 * `Referrer-Policy`, `Strict-Transport-Security`, `X-Frame-Options` e a CSP de
 * `frame-ancestors`. Ficam de fora `Cross-Origin-Opener-Policy` e
 * `Permissions-Policy`: os dois governam um CONTEXTO DE NAVEGAÇÃO de topo, que
 * um corpo JSON não abre — emiti-los ali seria peso sem efeito.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cabeçalhos de resposta.
 */
final class F3Base_Modulo_Cabecalhos extends F3Base_Modulo {

	/**
	 * Valor de que o fluxo de leads PRECISA — recomendação medida, não trava.
	 */
	public const COOP_EXIGIDO = F3Base_Vocabulario::COOP_PERMITE_POPUP;

	/**
	 * Valor de `Referrer-Policy` que apaga a atribuição dos canais pagos.
	 */
	public const REFERRER_SEM_ORIGEM = 'no-referrer';

	/**
	 * O cabeçalho que COMPÕE com o de outro emissor, em vez de substituí-lo.
	 */
	public const CABECALHO_QUE_COMPOE = 'Content-Security-Policy';

	/**
	 * Carimbo do que a última emissão fez — inclusive o que ela cedeu.
	 */
	public const ATIVIDADE = 'ultimos_cabecalhos';

	/**
	 * OS CABEÇALHOS QUE FAZEM SENTIDO NUMA RESPOSTA JSON.
	 *
	 * Lista declarada, e a exclusão é a parte que importa: COOP e
	 * `Permissions-Policy` governam um contexto de navegação de topo, e um corpo
	 * JSON não abre nenhum.
	 *
	 * @return string[]
	 */
	public static function cabecalhos_do_rest(): array {
		return array(
			'X-Content-Type-Options',
			'Referrer-Policy',
			'Strict-Transport-Security',
			'X-Frame-Options',
			self::CABECALHO_QUE_COMPOE,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'cabecalhos';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Cabeçalhos de resposta', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Emite no front-end os cabeçalhos de segurança declarados na configuração, cada um com o valor gravado. COOP sai como está gravado, e o estado nomeia a consequência quando não for same-origin-allow-popups; HSTS sai apenas quando ligado por decisão e sobre HTTPS.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'send_headers',
				'metodo'     => 'emitir',
				'prioridade' => 10,
				'args'       => 0,
			),
			/*
			 * `send_headers` NÃO COBRE O REST. A API serve o corpo por
			 * `rest_pre_serve_request`, e a resposta JSON saía sem nenhum
			 * cabeçalho desta lista — sem `nosniff` inclusive. O filtro devolve
			 * o que recebeu: quem decide se o corpo já foi servido é o núcleo.
			 */
			array(
				'tipo'       => 'filter',
				'hook'       => 'rest_pre_serve_request',
				'metodo'     => 'emitir_no_rest',
				'prioridade' => 10,
				'args'       => 1,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( self::ATIVIDADE, __( 'Última emissão dos cabeçalhos de resposta', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_cabecalhos' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'HTTPS na requisição', 'f3base' ),
				'presente' => is_ssl(),
				'detalhe'  => is_ssl()
					? __( 'HSTS pode ser emitido quando a decisão do cliente ligar a chave.', 'f3base' )
					: __( 'sem HTTPS, HSTS não é emitido em hipótese alguma.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( self::COOP_EXIGIDO !== (string) $config['coop'] ) {
			return $this->degradado(
				sprintf(
					/* translators: 1: valor gravado, 2: valor recomendado. */
					__( 'COOP gravado como %1$s e emitido assim: o valor gravado é o que sai. O preço medido é este — o CTA abre a conversa em janela nova, e fora de %2$s o navegador corta a relação com ela: window.opener some e o retorno para esta aba deixa de existir. Gravar %2$s desfaz o corte na requisição seguinte.', 'f3base' ),
					(string) $config['coop'],
					self::COOP_EXIGIDO
				)
			);
		}

		if ( ! empty( $config['hsts'] ) && ! is_ssl() ) {
			return $this->degradado(
				__( 'HSTS ligado sem HTTPS nesta requisição: o cabeçalho não é emitido, e ligá-lo aqui não teria efeito seguro.', 'f3base' )
			);
		}

		if ( empty( $config['hsts'] ) ) {
			return $this->ativo(
				sprintf(
					/* translators: %s: valor do COOP. */
					__( 'emitindo a lista declarada com COOP %s; HSTS desligado por padrão, como decisão do cliente.', 'f3base' ),
					self::COOP_EXIGIDO
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: max-age do HSTS, em segundos. */
				__( 'emitindo a lista declarada, com HSTS em max-age de %d segundos na etapa escalonada vigente.', 'f3base' ),
				(int) $config['hsts_max_age']
			)
		);
	}

	/**
	 * A DECISÃO de emissão, cabeçalho a cabeçalho. FUNÇÃO PURA.
	 *
	 * Pura de propósito: `header()` não devolve nada e não se mede, e é aqui que
	 * mora a regra que o piso exercita — o que sai, o que compõe e o que é
	 * CEDIDO a quem chegou antes.
	 *
	 * @param array<string,string> $lista        Cabeçalhos a emitir, nome => valor.
	 * @param array<int,string>    $ja_enviados  Cabeçalhos já postos nesta resposta, como `headers_list()` os devolve.
	 * @return array{emitir:array<int,array{nome:string,valor:string,compoe:bool}>,cedidos:array<int,string>}
	 */
	public static function decidir_emissao( array $lista, array $ja_enviados ): array {
		$presentes = array();

		foreach ( $ja_enviados as $linha ) {
			$nome = trim( (string) strtok( (string) $linha, ':' ) );

			if ( '' !== $nome ) {
				$presentes[] = strtolower( $nome );
			}
		}

		$emitir  = array();
		$cedidos = array();

		foreach ( $lista as $nome => $valor ) {
			$nome = (string) $nome;

			if ( self::CABECALHO_QUE_COMPOE === $nome ) {
				/*
				 * CSP COMPÕE: o navegador aplica a INTERSEÇÃO das políticas
				 * entregues, então a nossa linha só aperta a de quem já estava.
				 */
				$emitir[] = array(
					'nome'   => $nome,
					'valor'  => (string) $valor,
					'compoe' => true,
				);
				continue;
			}

			if ( in_array( strtolower( $nome ), $presentes, true ) ) {
				$cedidos[] = $nome;
				continue;
			}

			$emitir[] = array(
				'nome'   => $nome,
				'valor'  => (string) $valor,
				'compoe' => false,
			);
		}

		return array(
			'emitir'  => $emitir,
			'cedidos' => $cedidos,
		);
	}

	/**
	 * Emite os cabeçalhos no front-end.
	 *
	 * @return void
	 */
	public function emitir(): void {
		if ( is_admin() || headers_sent() ) {
			return;
		}

		$this->emitir_lista( $this->lista_de_cabecalhos(), 'send_headers', true );
	}

	/**
	 * Emite na resposta da API REST o recorte que faz sentido em JSON.
	 *
	 * Filtro de passagem: devolve exatamente o que recebeu. Quem decide se o
	 * corpo já foi servido é o núcleo, e trocar esse valor aqui seria este
	 * módulo respondendo pela requisição de outro.
	 *
	 * @param mixed $servido O núcleo já serviu o corpo.
	 * @return mixed
	 */
	public function emitir_no_rest( $servido ) {
		if ( headers_sent() ) {
			return $servido;
		}

		/*
		 * O REST NÃO CARIMBA, e isso é desenho e não esquecimento: quem já pôs
		 * cabeçalho numa resposta HTML não é necessariamente quem põe numa
		 * resposta JSON, e um carimbo compartilhado entre os dois ficaria
		 * alternando entre os dois conjuntos — uma escrita de option por
		 * requisição, que é o custo que o carimbo existe para não ter. O estado
		 * do módulo fala do front-end, que é onde o operador olha.
		 */
		$this->emitir_lista( self::cabecalhos_para_rest( $this->lista_de_cabecalhos() ), 'rest_pre_serve_request', false );

		return $servido;
	}

	/**
	 * O RECORTE de uma lista que faz sentido numa resposta JSON. Função pura.
	 *
	 * @param array<string,string> $lista Cabeçalhos completos.
	 * @return array<string,string>
	 */
	public static function cabecalhos_para_rest( array $lista ): array {
		return array_intersect_key( $lista, array_flip( self::cabecalhos_do_rest() ) );
	}

	/**
	 * Aplica a decisão e carimba o que foi cedido a outro emissor.
	 *
	 * O CARIMBO SÓ É GRAVADO QUANDO O CONJUNTO CEDIDO MUDA, e a economia é de
	 * desenho: esta função roda em TODA resposta do site, e o gravador único
	 * reescreve a procedência a cada escrita — carimbar aqui a cada requisição
	 * trocaria um cabeçalho por uma escrita de option por visitante. O que
	 * interessa ao operador é a MUDANÇA: o dia em que outro plugin passou a
	 * mandar no cabeçalho, e o dia em que parou.
	 *
	 * @param array<string,string> $lista    Cabeçalhos a emitir.
	 * @param string               $onde     Gancho que pediu a emissão.
	 * @param bool                 $carimbar Esta emissão responde pelo estado do módulo.
	 * @return void
	 */
	private function emitir_lista( array $lista, string $onde, bool $carimbar ): void {
		$decisao = self::decidir_emissao( $lista, headers_list() );

		foreach ( $decisao['emitir'] as $item ) {
			header( $item['nome'] . ': ' . $item['valor'], ! $item['compoe'] );
		}

		if ( ! $carimbar ) {
			return;
		}

		$cedidos  = implode( ', ', $decisao['cedidos'] );
		$anterior = F3Base_Atividade::ler( self::ATIVIDADE );

		if ( $cedidos === (string) ( $anterior['cedidos'] ?? '' ) ) {
			return;
		}

		F3Base_Atividade::registrar(
			self::ATIVIDADE,
			array(
				'onde'    => $onde,
				'cedidos' => $cedidos,
			)
		);
	}

	/**
	 * A LISTA que `emitir()` manda para o navegador — nome => valor.
	 *
	 * Existe separada de `emitir()` porque `header()` não devolve nada e não se
	 * mede: a bancada da suíte lê ESTA lista e compara com o que foi gravado. O
	 * defeito que ela existe para impedir é o de 1.0.19, em que o COOP saía do
	 * literal da classe e a option gravada não tinha efeito nenhum.
	 *
	 * @return array<string,string>
	 */
	public function lista_de_cabecalhos(): array {
		$config = $this->config();
		$saida  = array();

		if ( ! empty( $config['x_content_type_options'] ) ) {
			$saida['X-Content-Type-Options'] = 'nosniff';
		}

		$frame = (string) $config['x_frame_options'];
		if ( '' !== $frame ) {
			$saida['X-Frame-Options'] = $frame;
		}

		$ancestrais = (string) $config['csp_frame_ancestors'];
		if ( '' !== $ancestrais && self::frame_ancestors_na_forma( $ancestrais ) ) {
			$saida[ self::CABECALHO_QUE_COMPOE ] = 'frame-ancestors ' . $ancestrais;
		}

		$referrer = (string) $config['referrer_policy'];
		if ( '' !== $referrer ) {
			$saida['Referrer-Policy'] = $referrer;
		}

		$coop = (string) $config['coop'];
		if ( '' !== $coop ) {
			$saida['Cross-Origin-Opener-Policy'] = $coop;
		}

		$permissoes = (string) $config['permissions_policy'];
		if ( '' !== $permissoes ) {
			$saida['Permissions-Policy'] = $permissoes;
		}

		if ( ! empty( $config['hsts'] ) && is_ssl() ) {
			$saida['Strict-Transport-Security'] = 'max-age=' . (int) $config['hsts_max_age'];
		}

		return $saida;
	}

	/**
	 * A FORMA declarada de `frame-ancestors`. FUNÇÃO PURA, e ela RECUSA.
	 *
	 * Ela recusa — ao contrário da forma do token de verificação de domínio, que
	 * só avisa — porque o que está do outro lado não é um valor opaco de
	 * fornecedor: é uma DIRETIVA DE POLÍTICA que o navegador executa. O valor
	 * chegava por `sanitize_text_field()`, que preserva o ponto e vírgula, e
	 * `frame-ancestors 'self'; script-src 'unsafe-inline'` é uma segunda
	 * diretiva escrita por quem preencheu um campo de moldura — um CSP inteiro
	 * injetado pelo campo errado, com efeito sobre o carregamento de todo script
	 * da página.
	 *
	 * A forma aceita é a da especificação, e nada além dela: `'none'` sozinho,
	 * ou uma lista separada por espaço de `'self'` e origens `https://host`,
	 * com porta opcional e curinga opcional só no rótulo mais à esquerda.
	 *
	 * @param string $valor Valor gravado.
	 * @return bool
	 */
	public static function frame_ancestors_na_forma( string $valor ): bool {
		$valor = trim( $valor );

		if ( '' === $valor ) {
			return false;
		}

		$fontes = preg_split( '/\s+/', $valor );
		$fontes = is_array( $fontes ) ? array_values( array_filter( $fontes ) ) : array();

		if ( array() === $fontes ) {
			return false;
		}

		if ( in_array( "'none'", $fontes, true ) ) {
			/* `'none'` é absoluto: acompanhado de outra fonte, a lista se contradiz. */
			return array( "'none'" ) === $fontes;
		}

		foreach ( $fontes as $fonte ) {
			if ( "'self'" === $fonte ) {
				continue;
			}

			if ( 1 === preg_match( '#^https://(\*\.)?[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)*(:\d{1,5})?$#', $fonte ) ) {
				continue;
			}

			return false;
		}

		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public function avisos(): array {
		$config = $this->config();
		$avisos = array();

		$ancestrais = (string) $config['csp_frame_ancestors'];

		if ( '' !== $ancestrais && ! self::frame_ancestors_na_forma( $ancestrais ) ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: %s: valor gravado em csp_frame_ancestors. */
					__( 'csp_frame_ancestors gravado como %s está fora da forma que a diretiva aceita, e o cabeçalho Content-Security-Policy NÃO é emitido enquanto ele estiver assim. A forma é: \'none\' sozinho, ou \'self\' e origens https://host separadas por espaço. O engano que este aviso existe para pegar é o ponto e vírgula: ele encerra a diretiva de moldura e o que vem depois vira uma política nova — um CSP inteiro escrito pelo campo errado, com efeito sobre todo script da página. O valor foi PRESERVADO; corrigi-lo faz o cabeçalho voltar na requisição seguinte.', 'f3base' ),
					$ancestrais
				),
			);
		}

		$cedidos = (string) ( F3Base_Atividade::ler( self::ATIVIDADE )['cedidos'] ?? '' );

		if ( '' !== $cedidos ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: %s: nomes dos cabeçalhos que outro emissor já tinha posto. */
					__( 'outro emissor já tinha posto estes cabeçalhos na resposta, e este módulo CEDEU em vez de substituí-los: %s. Substituí-los seria apagar a política de quem chegou antes — um plugin de segurança, o tema ou o próprio servidor — e o site ficaria com a nossa linha no lugar da dele. O que sai neste site é o valor do outro emissor; para que o valor gravado aqui volte a valer, desligue o cabeçalho lá.', 'f3base' ),
					$cedidos
				),
			);
		}

		if ( self::REFERRER_SEM_ORIGEM === (string) $config['referrer_policy'] ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: %s: valor gravado de Referrer-Policy. */
					__( 'Referrer-Policy gravado como %s: o navegador para de enviar o referenciador em TODA saída deste site, e com ele some a origem que o GA4 usa para classificar a sessão e que Google Ads, Meta Ads e LinkedIn Ads usam para reconhecer o próprio tráfego quando o clique chega sem parâmetro de campanha. O valor continua valendo — é decisão do projeto —, e o que este aviso faz é nomear o preço.', 'f3base' ),
					self::REFERRER_SEM_ORIGEM
				),
			);
		}

		return $avisos;
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$declaracao = F3Base_Options::declaracao( 'f3base_cabecalhos' );
		$padrao     = null !== $declaracao && is_array( $declaracao['padrao'] ) ? $declaracao['padrao'] : array();
		$config     = F3Base_Options::ler( 'f3base_cabecalhos' );

		return array_merge( $padrao, is_array( $config ) ? $config : array() );
	}
}
