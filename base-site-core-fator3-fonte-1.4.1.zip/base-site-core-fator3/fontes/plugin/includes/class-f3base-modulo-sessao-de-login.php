<?php
/** Sessões persistentes do formulário nativo, sem alterar os tokens do núcleo. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class F3Base_Modulo_Sessao_De_Login extends F3Base_Modulo {
	public const PRIORIDADE = 9999;
	public function id(): string { return 'sessao-de-login'; }
	public function nome(): string { return __( 'Sessão de login', 'f3base' ); }
	public function descricao(): string { return __( 'Define o prazo das novas sessões e mantém o login ao fechar o navegador no formulário nativo.', 'f3base' ); }
	public function options_que_controlam(): array { return array( 'f3base_sessao' ); }
	public function hooks(): array {
		return array(
			array( 'tipo' => 'filter', 'hook' => 'auth_cookie_expiration', 'metodo' => 'duracao', 'prioridade' => self::PRIORIDADE, 'args' => 3 ),
			array( 'tipo' => 'action', 'hook' => 'login_form_login', 'metodo' => 'lembrar', 'prioridade' => self::PRIORIDADE, 'args' => 0 ),
			array( 'tipo' => 'filter', 'hook' => 'wp_login_form_defaults', 'metodo' => 'padroes_formulario', 'prioridade' => self::PRIORIDADE, 'args' => 1 ),
		);
	}
	// O registro pergunta pelo estado antes de instalar os filtros. A elegibilidade
	// depende da configuração; o diagnóstico efetivo só é medido ao consultar a tela.
	public function deve_registrar(): bool { return ! empty( F3Base_Options::ler( 'f3base_sessao' )['ligado'] ); }
	public function duracao( $duracao, $usuario = 0, $lembrar = false ): int {
		$config = F3Base_Options::ler( 'f3base_sessao' );
		return ! empty( $config['ligado'] ) ? (int) $config['dias'] * DAY_IN_SECONDS : (int) $duracao;
	}
	public function lembrar(): void {
		if ( $this->deve_registrar() && 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) { $_POST['rememberme'] = 'forever'; }
	}
	public function padroes_formulario( array $args ): array {
		if ( $this->deve_registrar() ) {
			$args['remember'] = true;
			$args['value_remember'] = true; // remember apenas EXIBE a caixa; value_remember a marca.
		}
		return $args;
	}
	/** Mede a cadeia real uma vez; sondas entre prioridades identificam a última alteração. */
	public static function diagnostico( ?int $usuario = null, bool $lembrar = true ): array {
		global $wp_filter;
		$config = F3Base_Options::ler( 'f3base_sessao' );
		$usuario = $usuario ?? get_current_user_id();
		$anterior = ( $lembrar ? 14 : 2 ) * DAY_IN_SECONDS;
		$alteradores = array();
		$sondas = array();
		$grupos = isset( $wp_filter['auth_cookie_expiration'] ) ? $wp_filter['auth_cookie_expiration']->callbacks : array();
		foreach ( $grupos as $prioridade => $callbacks ) {
			$nomes = array();
			foreach ( $callbacks as $item ) { $nomes[] = self::nome_callback( $item['function'] ); }
			$sonda = static function ( $valor ) use ( &$anterior, &$alteradores, $nomes ): mixed {
				if ( $valor !== $anterior ) { $alteradores = $nomes; }
				$anterior = $valor;
				return $valor;
			};
			add_filter( 'auth_cookie_expiration', $sonda, (int) $prioridade, 1 );
			$sondas[] = array( $prioridade, $sonda );
		}
		try { $efetivo = apply_filters( 'auth_cookie_expiration', ( $lembrar ? 14 : 2 ) * DAY_IN_SECONDS, $usuario, $lembrar ); }
		finally { foreach ( $sondas as [ $prioridade, $sonda ] ) { remove_filter( 'auth_cookie_expiration', $sonda, (int) $prioridade ); } }
		return array( 'declarado_segundos' => (int) $config['dias'] * DAY_IN_SECONDS, 'efetivo_segundos' => (int) $efetivo, 'usuario' => $usuario, 'callbacks' => $alteradores );
	}
	private static function nome_callback( $callback ): string {
		if ( is_string( $callback ) ) { return $callback; }
		if ( is_array( $callback ) ) { return ( is_object( $callback[0] ) ? get_class( $callback[0] ) : $callback[0] ) . '::' . $callback[1]; }
		if ( $callback instanceof Closure ) {
			$r = new ReflectionFunction( $callback );
			return 'Closure (' . basename( (string) $r->getFileName() ) . ':' . $r->getStartLine() . ')';
		}
		return is_object( $callback ) ? get_class( $callback ) . '::__invoke' : 'callback desconhecido';
	}
	protected function calcular_estado(): array {
		if ( ! $this->deve_registrar() ) { return $this->inativo( __( 'Novos logins usam os prazos do núcleo e dos demais plugins. Cookies já emitidos conservam o prazo original.', 'f3base' ) ); }
		$d = self::diagnostico();
		$frase = sprintf( __( 'Prazo efetivo para o usuário consultado: %s dias. Sessões existentes conservam o prazo original. Use “Sair de todos os outros dispositivos” no perfil para revogar as demais sessões.', 'f3base' ), (string) ( $d['efetivo_segundos'] / DAY_IN_SECONDS ) );
		if ( $d['efetivo_segundos'] !== $d['declarado_segundos'] ) {
			return $this->degradado( $frase . ' ' . __( 'Último grupo que alterou o prazo:', 'f3base' ) . ' ' . implode( ', ', $d['callbacks'] ) . '. ' . __( 'Callbacks na mesma prioridade são apresentados juntos; a atribuição individual não é presumida.', 'f3base' ) );
		}
		return $this->ativo( $frase );
	}
	public function atividade(): array {
		return array( __( 'Um cookie de sessão roubado permite acesso até expirar ou ser revogado. O prazo é aplicado a novos logins; formulários externos que não usam o fluxo nativo precisam respeitar rememberme.', 'f3base' ) );
	}
}
