<?php
/** Troca reversível do robots físico: cópia no banco e reserva atômica no mesmo diretório. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Robots_Arquivo {
	public const OPTION = 'f3base_robots_backup';
	public const MAX_BYTES = 1048576;

	/** Caminho verificado, sem depender de SCRIPT_FILENAME (que muda no WP-CLI). */
	public static function destino(): array {
		if ( is_multisite() ) { return array( '', 'A troca de arquivo físico não opera em multisite: a raiz pode ser compartilhada por outros sites.' ); }
		$home = wp_parse_url( home_url( '/' ) ); $site = wp_parse_url( site_url( '/' ) );
		if ( ! is_array( $home ) || ! is_array( $site ) || '/' !== ( $home['path'] ?? '/' ) ) { return array( '', 'A troca automática exige home na raiz do domínio; robots.txt de subdiretório depende do servidor.' ); }
		$rel = trim( (string) ( $site['path'] ?? '' ), '/' );
		$core = rtrim( str_replace( '\\', '/', ABSPATH ), '/' );
		if ( '' !== $rel ) {
			if ( str_contains( $rel, '..' ) || ! str_ends_with( $core, '/' . $rel ) ) { return array( '', 'Não foi possível determinar a raiz pública a partir de ABSPATH e da URL do WordPress.' ); }
			$core = substr( $core, 0, -strlen( '/' . $rel ) );
		}
		$raiz = realpath( $core );
		if ( ! $raiz || '/' === $raiz || ! is_file( $raiz . '/index.php' ) ) { return array( '', 'Raiz pública não confirmada: o diretório precisa conter o index.php do site.' ); }
		return array( rtrim( $raiz, '/\\' ) . '/robots.txt', '' );
	}

	/** Chamado após a gravação explícita da preferência. */
	public static function ao_gravar( $valor ): array {
		unset( $valor );
		return self::executar( 'retomar' );
	}
	public static function sincronizar(): array { return self::executar( 'normal' ); }
	public static function retomar(): array { return self::executar( 'retomar' ); }
	public static function suspender(): array { return self::executar( 'suspender' ); }
	public static function publicar( string $bytes, string $contexto ): array { return self::executar( 'publicar', array( 'bytes' => $bytes ), $contexto ); }
	public static function diagnostico( array $dados, string $contexto ): array { return self::executar( 'diagnostico', $dados, $contexto ); }
	public static function contexto(): string {
		$e = F3Base_Options::ler( self::OPTION );
		return hash( 'sha256', (string) ( $e['geracao'] ?? '' ) . F3Base_Robots_Entrega::assinatura() );
	}
	public static function proprio( string $alvo, array $e ): bool {
		$sha = (string) ( $e['gerenciado']['sha256'] ?? '' );
		return '' !== $sha && ! is_link( $alvo ) && is_file( $alvo ) && hash_equals( $sha, (string) @hash_file( 'sha256', $alvo ) );
	}

	/** Sempre relê a opção e o backup dentro da trava; visitas não disputam a restauração. */
	private static function executar( string $acao, array $dados = array(), string $contexto = '' ): array {
		$e = F3Base_Options::ler( self::OPTION );
		[ $alvo, $erro ] = self::destino();
		$ligado = ! empty( F3Base_Options::ler( 'f3base_robots' )['ligado'] ) && empty( $e['suspenso'] );
		if ( 'normal' === $acao && '' === ( $e['erro'] ?? '' ) && empty( $e['gerenciado']['temporario'] ) && empty( $e['gerenciado']['retirado'] ) ) {
			if ( ! $ligado && empty( $e['original_existe'] ) && empty( $e['gerenciado'] ) ) { return self::resultado( true, 'Sem original físico para restaurar.' ); }
			if ( $ligado && $alvo && self::proprio( $alvo, $e ) ) { return self::resultado( true, 'Arquivo gerenciado preservado; entrega pública conferida separadamente.' ); }
			if ( $ligado && $alvo && ! file_exists( $alvo ) && ! is_link( $alvo ) && 'virtual' === ( $e['etapa'] ?? '' ) ) { return self::resultado( true, 'Robots do plugin em uso.' ); }
			if ( ! $ligado && $alvo && is_file( $alvo ) && 'fisico' === ( $e['etapa'] ?? '' ) && empty( $e['gerenciado'] ) ) { return self::resultado( true, 'Robots físico mantido.' ); }
		}
		$nome_lock = get_temp_dir() . 'f3base-robots-' . hash( 'sha256', ABSPATH ) . '.lock';
		$lock = ! is_link( $nome_lock ) ? @fopen( $nome_lock, 'c' ) : false;
		if ( ! $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
			if ( is_resource( $lock ) ) { fclose( $lock ); }
			return self::resultado( false, 'Troca de robots.txt em curso ou trava indisponível. A próxima requisição tentará novamente.' );
		}
		try {
			// WordPress também mantém um cache por requisição; outra gravação pode ter ocorrido antes da trava.
			foreach ( array( 'f3base_robots', self::OPTION, 'alloptions', 'notoptions' ) as $chave ) { wp_cache_delete( $chave, 'options' ); }
			$e = F3Base_Options::ler( self::OPTION );
			if ( in_array( $acao, array( 'publicar', 'diagnostico' ), true ) && ( ! hash_equals( self::contexto(), $contexto ) || empty( F3Base_Options::ler( 'f3base_robots' )['ligado'] ) || ! empty( $e['suspenso'] ) ) ) {
				return self::resultado( false, 'A configuração mudou durante a verificação. O resultado anterior foi descartado.' );
			}
			if ( in_array( $acao, array( 'retomar', 'suspender' ), true ) ) {
				$e['suspenso'] = 'suspender' === $acao;
				$e['geracao'] = wp_generate_uuid4(); $e['entrega'] = array();
				if ( ! self::salvar( $e ) ) { return self::resultado( false, 'Não foi possível registrar a suspensão ou retomada do robots.txt.' ); }
			}
			$ligado = ! empty( F3Base_Options::ler( 'f3base_robots' )['ligado'] ) && empty( $e['suspenso'] );
			if ( 'diagnostico' === $acao ) { $e['entrega'] = $dados; return self::resultado( self::salvar( $e ), 'Verificação pública registrada.' ); }
			if ( '' !== $erro ) { throw new RuntimeException( $erro ); }
			if ( ! empty( $e['caminho'] ) && $e['caminho'] !== $alvo ) { throw new RuntimeException( 'O backup pertence a outra raiz pública. Nenhum arquivo foi alterado.' ); }
			self::recuperar_gerenciado( $alvo, $e );
			if ( ! $ligado ) {
				self::retirar_gerenciado( $alvo, $e );
				if ( empty( $e['original_existe'] ) ) { return self::concluir( $e, 'fisico', 'Sem original físico para restaurar; arquivo de terceiros preservado quando existente.' ); }
			}
			$reserva = self::reserva( $alvo, $e );
			// Recupera uma interrupção após mover o arquivo e antes de confirmar a cópia final no banco.
			if ( 'preparado' === ( $e['etapa'] ?? '' ) && $reserva && is_file( $reserva ) ) {
				$e = self::confirmar_reserva( $alvo, $reserva, $e ); $e['etapa'] = 'virtual';
				if ( ! self::salvar( $e ) ) { throw new RuntimeException( 'A reserva foi preservada, mas sua confirmação no banco falhou.' ); }
			}
			if ( ! $ligado ) { return self::restaurar( $alvo, $e ); }
			if ( 'publicar' === $acao ) { return self::gravar_gerenciado( $alvo, (string) $dados['bytes'], $e ); }
			if ( ! empty( $e['gerenciado']['sha256'] ) ) {
				if ( file_exists( $alvo ) && ! self::proprio( $alvo, $e ) ) { throw new RuntimeException( 'O robots.txt gerenciado foi alterado por fora do plugin. Arquivo e original foram preservados; desligue e ligue a opção para iniciar outro ciclo.' ); }
				if ( self::proprio( $alvo, $e ) ) { return self::concluir( $e, 'gerenciado', 'Arquivo gerenciado mantido.' ); }
				$e['gerenciado'] = array(); $e['entrega'] = array();
			}
			if ( is_link( $alvo ) || ( file_exists( $alvo ) && ! is_file( $alvo ) ) ) { throw new RuntimeException( 'robots.txt é um link simbólico ou um objeto que não é arquivo regular. Ele foi preservado.' ); }
			if ( ! file_exists( $alvo ) ) {
				if ( 'fisico' === ( $e['etapa'] ?? '' ) ) {
					self::limpar_reserva( $alvo, $e );
					$e['original_existe'] = false; $e['conteudo_base64'] = ''; $e['sha256'] = ''; $e['reserva'] = '';
				}
				$e['caminho'] = $alvo; return self::concluir( $e, 'virtual', 'Rota virtual preparada; entrega pública aguardando verificação.' );
			}
			if ( 'virtual' === ( $e['etapa'] ?? '' ) ) { throw new RuntimeException( 'Outro robots.txt físico apareceu após a troca. Ele e o backup foram preservados; desligue e ligue a opção para adotar esse arquivo como novo original.' ); }
			if ( ! function_exists( 'link' ) ) { throw new RuntimeException( 'A hospedagem desabilitou a publicação atômica necessária à restauração. O original foi mantido.' ); }
			// Não sobrescreve reservas anteriores de um ciclo concluído sem conferência.
			self::limpar_reserva( $alvo, $e );
			$e = self::capturar( $alvo, $e );
			$e['caminho'] = $alvo; $e['reserva'] = '.f3base-robots-' . wp_generate_uuid4() . '.bak'; $e['etapa'] = 'preparado'; $e['erro'] = '';
			$reserva = self::reserva( $alvo, $e );
			if ( file_exists( $reserva ) || is_link( $reserva ) || ! self::salvar( $e ) ) { throw new RuntimeException( 'Backup não confirmado. O robots.txt físico foi mantido.' ); }
			// Mesmo diretório: rename retira o nome público sem expor uma cópia parcial.
			if ( ! function_exists( 'rename' ) || ! @rename( $alvo, $reserva ) ) { throw new RuntimeException( 'Sem permissão para retirar robots.txt da raiz pública. O backup está salvo e o original foi mantido.' ); }
			clearstatcache();
			$e = self::confirmar_reserva( $alvo, $reserva, $e );
			return self::concluir( $e, 'virtual', 'Original salvo e robots.txt físico retirado. O gerador do plugin passa a responder.' );
		} catch ( Throwable $falha ) {
			$e['erro'] = $falha->getMessage(); self::salvar( $e );
			return self::resultado( false, $e['erro'] );
		} finally { flock( $lock, LOCK_UN ); fclose( $lock ); }
	}

	/** Caminhos de trabalho sempre relativos à raiz já confirmada, separados do backup original. */
	private static function trabalho( string $alvo, string $nome ): string {
		if ( '' === $nome ) { return ''; }
		if ( ! preg_match( '/^\.f3base-robots-(?:gerado|retirado)-[a-f0-9-]+\.tmp$/D', $nome ) ) { throw new RuntimeException( 'Nome de arquivo gerenciado inválido; recuperação interrompida.' ); }
		return dirname( $alvo ) . '/' . $nome;
	}
	private static function apagar_conferido( string $arquivo, string $sha ): void {
		if ( '' === $arquivo || ( ! file_exists( $arquivo ) && ! is_link( $arquivo ) ) ) { return; }
		if ( is_link( $arquivo ) || ! is_file( $arquivo ) || '' === $sha || ! hash_equals( $sha, (string) @hash_file( 'sha256', $arquivo ) ) ) { throw new RuntimeException( 'Arquivo de recuperação alterado por terceiros; preservado em ' . $arquivo ); }
		if ( ! @unlink( $arquivo ) ) { throw new RuntimeException( 'Sem permissão para limpar arquivo de recuperação: ' . $arquivo ); }
	}
	/** Resolve uma publicação interrompida. Um nome público livre recebe de volta o arquivo retirado. */
	private static function recuperar_gerenciado( string $alvo, array &$e ): void {
		$g = (array) ( $e['gerenciado'] ?? array() );
		$tmp = self::trabalho( $alvo, (string) ( $g['temporario'] ?? '' ) );
		$ret = self::trabalho( $alvo, (string) ( $g['retirado'] ?? '' ) );
		if ( '' === $tmp && '' === $ret ) { return; }
		clearstatcache();
		if ( $ret && ( file_exists( $ret ) || is_link( $ret ) ) && ! file_exists( $alvo ) && ! is_link( $alvo ) ) {
			if ( is_link( $ret ) || ! is_file( $ret ) || ! function_exists( 'link' ) || ! @link( $ret, $alvo ) ) { throw new RuntimeException( 'Arquivo retirado preservado; não foi possível devolver seu nome público.' ); }
		}
		$atual = ! is_link( $alvo ) && is_file( $alvo ) ? (string) @hash_file( 'sha256', $alvo ) : '';
		$novo = (string) ( $g['novo_sha256'] ?? '' );
		// Só descarta o retirado após verificar que seus bytes ainda pertencem ao plugin.
		self::apagar_conferido( $ret, (string) ( $g['sha256'] ?? '' ) );
		self::apagar_conferido( $tmp, $novo );
		$sha = '' !== $novo && hash_equals( $novo, $atual ) ? $novo : (string) ( $g['sha256'] ?? '' );
		$e['gerenciado'] = '' === $sha ? array() : array( 'sha256' => $sha );
		if ( ! self::salvar( $e ) ) { throw new RuntimeException( 'Recuperação de publicação pendente de confirmação no banco.' ); }
	}
	/** Publica por hard link sem sobrescrever um arquivo surgido entre a retirada e a publicação. */
	private static function gravar_gerenciado( string $alvo, string $bytes, array &$e ): array {
		if ( '' === $bytes || strlen( $bytes ) > self::MAX_BYTES ) { throw new RuntimeException( 'Conteúdo de robots.txt vazio ou acima do limite; publicação recusada.' ); }
		if ( ! function_exists( 'link' ) || ! function_exists( 'rename' ) ) { throw new RuntimeException( 'A hospedagem não permite a publicação atômica do robots.txt gerenciado.' ); }
		if ( is_link( $alvo ) || ( file_exists( $alvo ) && ! self::proprio( $alvo, $e ) ) ) { throw new RuntimeException( 'robots.txt físico de terceiros preservado; publicação automática interrompida.' ); }
		$sha = hash( 'sha256', $bytes );
		if ( self::proprio( $alvo, $e ) && hash_equals( $sha, (string) $e['gerenciado']['sha256'] ) ) { return self::concluir( $e, 'gerenciado', 'Arquivo gerenciado já contém as regras atuais.' ); }
		$g = array( 'sha256' => (string) ( $e['gerenciado']['sha256'] ?? '' ), 'novo_sha256' => $sha, 'temporario' => '.f3base-robots-gerado-' . wp_generate_uuid4() . '.tmp', 'retirado' => '.f3base-robots-retirado-' . wp_generate_uuid4() . '.tmp' );
		$tmp = self::trabalho( $alvo, $g['temporario'] ); $ret = self::trabalho( $alvo, $g['retirado'] );
		$fp = @fopen( $tmp, 'xb' );
		if ( ! $fp ) { throw new RuntimeException( 'Sem permissão para preparar robots.txt na raiz pública.' ); }
		try { $total = 0; while ( $total < strlen( $bytes ) ) { $n = fwrite( $fp, substr( $bytes, $total ) ); if ( false === $n || 0 === $n ) { break; } $total += $n; } fflush( $fp ); }
		finally { fclose( $fp ); }
		if ( $total !== strlen( $bytes ) || ! hash_equals( $sha, (string) @hash_file( 'sha256', $tmp ) ) || ! @chmod( $tmp, 0644 ) ) { @unlink( $tmp ); throw new RuntimeException( 'Falha na preparação do arquivo gerenciado; original preservado.' ); }
		$e['gerenciado'] = $g; $e['caminho'] = $alvo; $e['entrega'] = array();
		if ( ! self::salvar( $e ) ) { self::apagar_conferido( $tmp, $sha ); throw new RuntimeException( 'Banco não confirmou a publicação; arquivo público preservado.' ); }
		clearstatcache();
		if ( file_exists( $alvo ) || is_link( $alvo ) ) {
			if ( ! self::proprio( $alvo, $e ) || file_exists( $ret ) || is_link( $ret ) || ! @rename( $alvo, $ret ) ) { throw new RuntimeException( 'Arquivo público mudou ou sua retirada falhou; publicação interrompida.' ); }
			if ( is_link( $ret ) || ! hash_equals( $g['sha256'], (string) @hash_file( 'sha256', $ret ) ) ) {
				self::recuperar_gerenciado( $alvo, $e );
				throw new RuntimeException( 'Edição externa durante a troca foi preservada.' );
			}
		}
		if ( ! @link( $tmp, $alvo ) ) {
			self::recuperar_gerenciado( $alvo, $e );
			throw new RuntimeException( 'Destino ocupado ou publicação atômica recusada; arquivos preservados.' );
		}
		self::recuperar_gerenciado( $alvo, $e );
		if ( ! self::proprio( $alvo, $e ) ) { throw new RuntimeException( 'O robots.txt publicado foi alterado externamente; arquivo preservado.' ); }
		return self::concluir( $e, 'gerenciado', 'Regras publicadas em arquivo gerenciado; entrega pública aguardando confirmação.' );
	}
	/** Desligar só retira o arquivo cuja soma ainda corresponde ao conteúdo gerado. */
	private static function retirar_gerenciado( string $alvo, array &$e ): void {
		if ( empty( $e['gerenciado'] ) ) { return; }
		if ( self::proprio( $alvo, $e ) ) {
			$e['gerenciado']['retirado'] = '.f3base-robots-retirado-' . wp_generate_uuid4() . '.tmp';
			$ret = self::trabalho( $alvo, $e['gerenciado']['retirado'] );
			if ( ! self::salvar( $e ) || file_exists( $ret ) || is_link( $ret ) || ! function_exists( 'rename' ) || ! @rename( $alvo, $ret ) ) { throw new RuntimeException( 'Não foi possível retirar o arquivo gerenciado para restaurar o original.' ); }
			if ( is_link( $ret ) || ! hash_equals( $e['gerenciado']['sha256'], (string) @hash_file( 'sha256', $ret ) ) ) { self::recuperar_gerenciado( $alvo, $e ); throw new RuntimeException( 'Edição externa preservada durante a desativação.' ); }
			self::apagar_conferido( $ret, $e['gerenciado']['sha256'] );
		}
		$e['gerenciado'] = array(); $e['entrega'] = array();
		if ( ! self::salvar( $e ) ) { throw new RuntimeException( 'Retirada concluída; confirmação pendente no banco.' ); }
	}

	/** Lê bytes integrais, com limite de tamanho; nenhuma normalização de linhas ou UTF-8. */
	private static function capturar( string $arquivo, array $e ): array {
		if ( is_link( $arquivo ) || ! is_file( $arquivo ) ) { throw new RuntimeException( 'O original ou a reserva não é um arquivo regular.' ); }
		$fp = @fopen( $arquivo, 'rb' );
		if ( ! $fp ) { throw new RuntimeException( 'O original não pôde ser lido; nenhum conteúdo será descartado.' ); }
		try { $bytes = stream_get_contents( $fp, self::MAX_BYTES + 1 ); $stat = fstat( $fp ); }
		finally { fclose( $fp ); }
		if ( false === $bytes || ! $stat || strlen( $bytes ) > self::MAX_BYTES || strlen( $bytes ) !== (int) $stat['size'] ) { throw new RuntimeException( 'Original excede o limite de 1 MiB ou mudou durante a leitura; arquivo preservado.' ); }
		$e['original_existe'] = true; $e['conteudo_base64'] = base64_encode( $bytes ); $e['sha256'] = hash( 'sha256', $bytes ); $e['modo'] = (int) $stat['mode'] & 0777;
		return $e;
	}

	/** Uma mudança externa entre a leitura e o rename não autoriza descartar a reserva. */
	private static function confirmar_reserva( string $alvo, string $reserva, array &$e ): array {
		try { return self::capturar( $reserva, $e ); }
		catch ( Throwable $falha ) {
			clearstatcache();
			if ( ! file_exists( $alvo ) && ! is_link( $alvo ) && function_exists( 'link' ) && @link( $reserva, $alvo ) ) {
				if ( @unlink( $reserva ) ) { $e['reserva'] = ''; }
				$e['etapa'] = 'fisico';
				throw new RuntimeException( $falha->getMessage() . ' A troca foi revertida e o original voltou ao caminho público.' );
			}
			throw new RuntimeException( $falha->getMessage() . ' O original permanece na reserva: ' . $reserva );
		}
	}

	/** Publica os bytes conferidos por link atômico: um destino surgido em paralelo nunca é sobrescrito. */
	private static function restaurar( string $alvo, array $e ): array {
		if ( file_exists( $alvo ) || is_link( $alvo ) ) {
			self::limpar_reserva( $alvo, $e ); $e['reserva'] = '';
			return self::concluir( $e, 'fisico', 'Já existe um robots.txt físico; seu conteúdo foi preservado.' );
		}
		if ( strlen( (string) ( $e['conteudo_base64'] ?? '' ) ) > (int) ceil( self::MAX_BYTES / 3 ) * 4 ) { throw new RuntimeException( 'Backup excede o limite de restauração.' ); }
		$bytes = base64_decode( (string) ( $e['conteudo_base64'] ?? '' ), true );
		if ( false === $bytes || ! hash_equals( (string) ( $e['sha256'] ?? '' ), hash( 'sha256', $bytes ) ) ) { throw new RuntimeException( 'Backup inválido: checksum não confere. Restauração interrompida sem publicar conteúdo incorreto.' ); }
		$reserva = self::reserva( $alvo, $e );
		if ( ! $reserva || ! is_file( $reserva ) ) {
			$e['reserva'] = '.f3base-robots-' . wp_generate_uuid4() . '.bak'; $reserva = self::reserva( $alvo, $e );
			if ( ! self::salvar( $e ) ) { throw new RuntimeException( 'Não foi possível registrar o arquivo de restauração.' ); }
			$fp = @fopen( $reserva, 'xb' );
			if ( ! $fp ) { throw new RuntimeException( 'Sem permissão para preparar o original na raiz pública.' ); }
			try { $total = 0; while ( $total < strlen( $bytes ) ) { $n = fwrite( $fp, substr( $bytes, $total ) ); if ( false === $n || 0 === $n ) { break; } $total += $n; } fflush( $fp ); }
			finally { fclose( $fp ); }
			if ( $total !== strlen( $bytes ) ) { @unlink( $reserva ); throw new RuntimeException( 'Escrita incompleta; o backup no banco foi preservado.' ); }
		}
		if ( is_link( $reserva ) || ! hash_equals( $e['sha256'], (string) @hash_file( 'sha256', $reserva ) ) ) { throw new RuntimeException( 'A reserva física mudou; backup preservado e restauração interrompida.' ); }
		if ( ! @chmod( $reserva, (int) $e['modo'] & 0777 ) ) { throw new RuntimeException( 'Não foi possível restaurar as permissões do original.' ); }
		if ( ! function_exists( 'link' ) || ! @link( $reserva, $alvo ) ) {
			clearstatcache();
			if ( file_exists( $alvo ) || is_link( $alvo ) ) { return self::concluir( $e, 'fisico', 'Um robots.txt apareceu durante a restauração e foi preservado.' ); }
			throw new RuntimeException( 'A hospedagem não permitiu a publicação atômica do original. A reserva e o backup permanecem disponíveis.' );
		}
		self::limpar_reserva( $alvo, $e ); $e['reserva'] = '';
		return self::concluir( $e, 'fisico', 'Robots.txt original restaurado com os mesmos bytes e permissões.' );
	}

	private static function reserva( string $alvo, array $e ): string {
		$nome = (string) ( $e['reserva'] ?? '' );
		return preg_match( '/^\.f3base-robots-[a-f0-9-]+\.bak$/D', $nome ) ? dirname( $alvo ) . '/' . $nome : '';
	}
	private static function limpar_reserva( string $alvo, array $e ): void {
		$r = self::reserva( $alvo, $e );
		if ( ! $r || ( ! file_exists( $r ) && ! is_link( $r ) ) ) { return; }
		if ( is_link( $r ) || ! is_file( $r ) || empty( $e['sha256'] ) || ! hash_equals( $e['sha256'], (string) @hash_file( 'sha256', $r ) ) ) { throw new RuntimeException( 'Reserva alterada por fora do plugin; arquivo e backup preservados para conferência.' ); }
		if ( ! @unlink( $r ) ) { throw new RuntimeException( 'Não foi possível limpar a reserva já conferida; arquivo e backup preservados.' ); }
	}
	private static function salvar( array $e ): bool {
		$r = F3Base_Options::gravar( self::OPTION, $e );
		return ! empty( $r['ok'] ) && $r['lido'] === $e;
	}
	private static function concluir( array $e, string $etapa, string $motivo ): array {
		$e['etapa'] = $etapa; $e['erro'] = '';
		if ( ! self::salvar( $e ) ) { return self::resultado( false, 'Arquivos preservados; falhou a confirmação do estado no banco.' ); }
		return self::resultado( true, $motivo );
	}
	private static function resultado( bool $ok, string $motivo ): array { return array( 'ok' => $ok, 'motivo' => $motivo ); }
}
