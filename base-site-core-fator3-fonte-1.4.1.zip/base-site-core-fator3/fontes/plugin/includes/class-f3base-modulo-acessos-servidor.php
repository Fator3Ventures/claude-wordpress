<?php
/** Estatísticas de logs combined fechados. Linhas brutas existem somente no laço de leitura. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class F3Base_Modulo_Acessos_Servidor extends F3Base_Modulo {
	public const TABELA = 'f3base_acessos';
	public const EVENTO = 'f3base_acessos_somar';
	public const CONTINUAR = 'f3base_acessos_continuar';
	public const TETO_CAMINHOS_POR_DIA = 500;
	public const TETO_LINHAS = 1000;
	public const TETO_AGREGADOS = 50000;
	public const MAX_BYTES_ARQUIVO = 67108864;
	public const MAX_SEGUNDOS_DIA = 8;
	public const EXCLUIDOS = array( '/wp-json/mcp/', '/wp-json/f3base/', '/wp-admin/', '/wp-login.php', '/xmlrpc.php', '/wp-cron.php', '/wp-content/', '/wp-includes/' );
	public const CLASSES = array( 'pagina', 'descoberta', 'api', 'excluido', 'estatico', 'outro' );
	public const EXTENSOES = 'css|js|map|png|jpg|jpeg|gif|webp|avif|svg|ico|woff|woff2|ttf|mp4|webm|pdf';
	public const GENERICOS = 'bot|crawler|spider|curl|wget|python|Go-http-client|Java/|libwww|HeadlessChrome|PhantomJS';
	public function id(): string { return 'acessos-servidor'; }
	public function nome(): string { return __( 'Acessos do servidor', 'f3base' ); }
	public function descricao(): string { return __( 'Soma requisições de arquivos datados do servidor por página, família declarada, método e status. Não guarda IP, referer nem User-Agent bruto. Caminhos públicos ainda podem conter dados pessoais; exclua as rotas privadas.', 'f3base' ); }
	public function options_que_controlam(): array { return array( 'f3base_acessos', 'f3base_acessos_estado' ); }
	public function hooks(): array {
		return array(
			array( 'tipo' => 'action', 'hook' => 'init', 'metodo' => 'inicializar', 'prioridade' => 25, 'args' => 0, 'sempre' => true ),
			array( 'tipo' => 'action', 'hook' => self::EVENTO, 'metodo' => 'somar', 'prioridade' => 10, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => self::CONTINUAR, 'metodo' => 'somar', 'prioridade' => 10, 'args' => 0 ),
		);
	}
	public static function config(): array { return F3Base_Options::ler( 'f3base_acessos' ); }
	public static function padrao_do_log( bool $normalizar = true ): string {
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		// O diretório do host usa o domínio sem o alias www. Outros subdomínios ficam.
		// A forma anterior é usada apenas para reconhecer o padrão salvo na atualização.
		if ( $normalizar ) { $host = preg_replace( '/^www\./', '', strtolower( $host ) ); }
		return '~/logs/' . ( preg_match( '/^[a-z0-9.-]+$/iD', $host ) ? $host : 'dominio-nao-identificado' ) . '/https/access.log.*';
	}
	protected function calcular_estado(): array {
		if ( empty( self::config()['ligado'] ) ) { return $this->inativo( __( 'Soma desligada; histórico preservado.', 'f3base' ) ); }
		$e = F3Base_Options::ler( 'f3base_acessos_estado' );
		if ( ! empty( $e['erro'] ) ) { return $this->degradado( $e['erro'] ); }
		if ( empty( $e['ultima_soma'] ) ) { return $this->degradado( __( 'Primeira soma ainda não concluída. Consulte o padrão de log e execute Coletar e Armazenar Logs.', 'f3base' ) ); }
		if ( ! empty( $e['pendentes'] ) ) { return $this->degradado( sprintf( __( 'Importação parcial: %d dias pendentes; continuação agendada.', 'f3base' ), $e['pendentes'] ) ); }
		return $this->ativo( __( 'Última soma concluída; cobertura e arquivos disponíveis aparecem em Medição → Acessos.', 'f3base' ) );
	}
	public function dependencias(): array {
		$e = F3Base_Options::ler( 'f3base_acessos_estado' );
		return array( array( 'rotulo' => 'Log do servidor processado', 'presente' => ! empty( $e['ultima_soma'] ), 'detalhe' => $e['erro'] ?? 'Requer acesso a logs datados deste site.' ) );
	}
	public function atividade(): array { return array( F3Base_Atividade::descrever( 'ultima_soma_acessos', __( 'Última soma do servidor', 'f3base' ) ) ); }
	public function avisos(): array {
		$e = F3Base_Options::ler( 'f3base_acessos_estado' );
		if ( ! empty( self::config()['ligado'] ) && (int) ( $e['ultima_soma'] ?? 0 ) < time() - 2 * DAY_IN_SECONDS ) {
			return array( array( 'estado' => 'WARN', 'motivo' => __( 'Sem soma confirmada nos últimos dois dias. Verifique o cron e a disponibilidade dos logs.', 'f3base' ) ) );
		}
		if ( ! empty( $e['dias_regras_anteriores'] ) ) { return array( array( 'estado' => 'WARN', 'motivo' => sprintf( '%d dias preservam regras anteriores porque os arquivos de origem não estão mais disponíveis.', $e['dias_regras_anteriores'] ) ) ); }
		return array();
	}
	public function instalar(): void { $this->inicializar(); }
	public function desinstalar(): void { wp_unschedule_hook( self::EVENTO ); wp_unschedule_hook( self::CONTINUAR ); }
	public function inicializar(): void {
		$c = self::config();
		$padrao = self::padrao_do_log();
		// Migração idempotente: só o antigo padrão exato, nunca um caminho personalizado.
		if ( $c['padrao_do_log'] !== $padrao && $c['padrao_do_log'] === self::padrao_do_log( false ) ) {
			$c['padrao_do_log'] = $padrao;
			F3Base_Options::gravar( 'f3base_acessos', $c, F3Base_Options::proveniencia( 'f3base_acessos' ) );
		}
		// Sempre é necessário para retirar eventos quando o operador desliga a coleta.
		if ( empty( self::config()['ligado'] ) ) { $this->desinstalar(); return; }
		if ( ! wp_next_scheduled( self::EVENTO ) ) {
			$proximo = strtotime( gmdate( 'Y-m-d' ) . ' 09:00:00 UTC' );
			wp_schedule_event( $proximo > time() ? $proximo : $proximo + DAY_IN_SECONDS, 'daily', self::EVENTO );
		}
		$e = F3Base_Options::ler( 'f3base_acessos_estado' );
		if ( ! self::tabela_pronta() || empty( $e['tentativa'] ) || (int) $e['tentativa'] < time() - DAY_IN_SECONDS || ( $e['config_hash'] ?? '' ) !== self::config_hash() ) { $this->somar(); }
		if ( ! wp_next_scheduled( self::EVENTO ) ) {
			$e = F3Base_Options::ler( 'f3base_acessos_estado' );
			$e['erro'] = trim( ( $e['erro'] ?? '' ) . ' O WordPress não confirmou o agendamento de ' . self::EVENTO . '.' );
			F3Base_Options::gravar( 'f3base_acessos_estado', $e );
		}
	}
	private static function config_hash(): string {
		$c = self::config();
		return hash( 'sha256', wp_json_encode( array( $c['padrao_do_log'], $c['caminhos_excluidos'], $c['retencao_meses'], 'parser-1', hash_file( 'sha256', F3BASE_PLUGIN_DIR . 'dados/robos-conhecidos.tsv' ) ) ) );
	}
	public static function tabela_pronta(): bool {
		global $wpdb;
		$t = $wpdb->prefix . self::TABELA;
		return $t === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) );
	}
	public function garantir_estrutura(): bool {
		global $wpdb;
		if ( self::tabela_pronta() ) { return true; }
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = $wpdb->prefix . self::TABELA;
		$charset = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$t} (
	dia date NOT NULL,
	agente varchar(64) NOT NULL,
	classe_caminho varchar(16) NOT NULL,
	caminho varchar(191) COLLATE utf8mb4_bin NOT NULL,
	status smallint unsigned NOT NULL,
	metodo varchar(5) NOT NULL,
	contagem bigint unsigned NOT NULL,
	UNIQUE KEY agregado (dia,agente,classe_caminho,caminho,status,metodo),
	KEY dia_classe (dia,classe_caminho)
	) ENGINE=InnoDB {$charset};" );
		return self::tabela_pronta();
	}
	/** O TSV usa marcas HTTP reais; tokens exclusivos de robots.txt não são famílias. */
	public static function robos(): array {
		static $linhas = null;
		if ( null !== $linhas ) { return $linhas; }
		$linhas = array();
		foreach ( (array) file( F3BASE_PLUGIN_DIR . 'dados/robos-conhecidos.tsv', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ) as $linha ) {
			if ( str_starts_with( $linha, '#' ) ) { continue; }
			$v = explode( "\t", $linha );
			if ( count( $v ) >= 4 ) { $linhas[] = array( 'familia' => $v[0], 'marca' => $v[1], 'classe' => $v[2], 'operador' => $v[3] ); }
		}
		return $linhas;
	}
	public static function agente( string $ua ): array {
		// Tokens de controle declarados como HTTP são automação sem operador verificado.
		if ( preg_match( '/Google-Extended|Applebot-Extended/i', $ua ) ) { return array( 'robo-generico', 'generico' ); }
		foreach ( self::robos() as $robo ) { if ( false !== stripos( $ua, $robo['marca'] ) ) { return array( $robo['familia'], $robo['classe'] ); } }
		return preg_match( '~' . self::GENERICOS . '~i', $ua ) ? array( 'robo-generico', 'generico' ) : array( 'humano', 'humano' );
	}
	public static function classe_agente( string $familia ): string {
		if ( 'humano' === $familia ) { return 'humano'; }
		foreach ( self::robos() as $r ) { if ( $r['familia'] === $familia ) { return $r['classe']; } }
		return 'generico';
	}
	/** Classifica antes de truncar; protege REST por query e instalações em subdiretório. */
	public static function caminho( string $alvo, array $excluidos ): array {
		$partes = wp_parse_url( $alvo );
		$p = is_array( $partes ) ? (string) ( $partes['path'] ?? '/' ) : '/';
		if ( isset( $partes['host'] ) && strtolower( (string) $partes['host'] ) !== strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ) { return array( 'outro', '' ); }
		if ( ! str_starts_with( $p, '/' ) ) { return array( 'outro', '' ); }
		$p = preg_replace_callback( '/%[a-f0-9]{2}/i', static fn( $m ) => strtoupper( $m[0] ), $p );
		$normal = rawurldecode( $p );
		$base = rtrim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		if ( '' !== $base && $normal !== $base && ! str_starts_with( $normal, $base . '/' ) ) { return array( 'excluido', '' ); }
		$relativo = '' !== $base ? substr( $normal, strlen( $base ) ) : $normal;
		$relativo = '/' . ltrim( preg_replace( '~/+~', '/', $relativo ), '/' );
		if ( preg_match( '~(?:^|/)\.\.?(?:/|$)|[\x00-\x1f\x7f]~', $relativo ) ) { return array( 'outro', '' ); }
		// A query é usada somente para descobrir a rota REST; nenhum parâmetro é persistido.
		if ( in_array( $relativo, array( '/', '/index.php' ), true ) && ! empty( $partes['query'] ) ) {
			parse_str( $partes['query'], $query );
			if ( isset( $query['rest_route'] ) && is_string( $query['rest_route'] ) ) {
				$relativo = '/wp-json/' . ltrim( $query['rest_route'], '/' );
				$p = $base . $relativo;
			}
		}
		foreach ( $excluidos as $prefixo ) {
			if ( str_starts_with( $relativo, $prefixo ) || str_starts_with( $normal, $prefixo ) || rtrim( $relativo, '/' ) === rtrim( $prefixo, '/' ) ) { return array( 'excluido', '' ); }
		}
		if ( preg_match( '~\.(' . self::EXTENSOES . ')$~iD', $relativo ) ) { return array( 'estatico', '' ); }
		$classe = 'pagina';
		if ( preg_match( '~^/(?:robots\.txt|llms(?:-full)?\.txt|(?:.*sitemap[^/]*|sitemap[^/]*)\.xml|feed(?:/.*)?)/?$~iD', $relativo ) ) { $classe = 'descoberta'; }
		elseif ( '/wp-json' === rtrim( $relativo, '/' ) || str_starts_with( $relativo, '/wp-json/' ) ) { $classe = 'api'; }
		// E-mails e tokens óbvios no path não precisam de detalhe na estatística.
		if ( preg_match( '/@|[a-f0-9]{32,}|[A-Za-z0-9_-]{60,}/i', rawurldecode( $p ) ) ) { return array( 'outro', '' ); }
		$p = wp_check_invalid_utf8( $p, true );
		return array( $classe, function_exists( 'mb_substr' ) ? mb_substr( $p, 0, 191, 'UTF-8' ) : substr( $p, 0, 191 ) );
	}
	/** Sem capturas do endereço, identidade, usuário e referer. */
	public static function linha( string $linha, array $excluidos ): ?array {
		$regex = '~^\S+ \S+ \S+ \[[^\]\r\n]+\] "([A-Z]+) ([^"\r\n ]+) HTTP/[0-9.]+" ([1-5][0-9]{2}) (?:[0-9]+|-) "(?:[^"\\\\]|\\\\.)*" "((?:[^"\\\\]|\\\\.)*)"\s*$~D';
		if ( ! preg_match( $regex, $linha, $m ) ) { return null; }
		[ $classe, $caminho ] = self::caminho( $m[2], $excluidos );
		return array( 'agente' => self::agente( $m[4] )[0], 'classe_caminho' => $classe, 'caminho' => $caminho, 'status' => (int) $m[3], 'metodo' => in_array( $m[1], array( 'GET', 'HEAD', 'POST' ), true ) ? $m[1] : 'outro', 'contagem' => 1 );
	}
	/** Expande ~ com evidência de diretório existente, sem depender de um host específico. */
	public static function resolver_padrao( string $padrao ): string {
		if ( ! str_starts_with( $padrao, '~/' ) ) { return $padrao; }
		$bases = array();
		$home = (string) getenv( 'HOME' );
		$diagnostico = '' === $home ? 'HOME ausente no processo PHP' : ( @is_dir( $home ) ? 'HOME presente' : 'HOME não reconhecido como diretório pelo PHP' );
		$bases[] = $home;
		// SAPI e ambiente local podem expor valores diferentes, especialmente em FastCGI.
		$bases[] = (string) getenv( 'HOME', true );
		if ( function_exists( 'posix_getpwuid' ) ) {
			$uids = array( @fileowner( ABSPATH ) );
			if ( function_exists( 'posix_geteuid' ) ) { $uids[] = posix_geteuid(); }
			foreach ( array_unique( $uids, SORT_REGULAR ) as $uid ) {
				if ( false === $uid ) { continue; }
				$usuario = posix_getpwuid( (int) $uid );
				if ( is_array( $usuario ) ) { $bases[] = (string) ( $usuario['dir'] ?? '' ); }
			}
		}
		// Só ascendentes da instalação; sem varrer usuários vizinhos ou o disco inteiro.
		foreach ( array_unique( array( ABSPATH, (string) @realpath( ABSPATH ) ) ) as $raiz ) {
			$base = rtrim( $raiz, '/\\' );
			for ( $n = 0; $n < 16 && '' !== $base && dirname( $base ) !== $base; ++$n ) {
				$bases[] = $base;
				$base = dirname( $base );
			}
		}
		$encontrados = array(); $tentados = array(); $sem_leitura = array();
		foreach ( array_unique( $bases ) as $base ) {
			if ( '' === $base || ! preg_match( '~^(?:/|[A-Za-z]:[\\\\/])~', $base ) ) { continue; }
			$candidato = rtrim( $base, '/\\' ) . substr( $padrao, 1 );
			$diretorio = dirname( $candidato ); $tentados[] = $diretorio;
			foreach ( @glob( $diretorio, GLOB_ONLYDIR ) ?: array() as $pasta ) {
				$real = @realpath( $pasta );
				if ( false === $real || ! @is_readable( $real ) ) { $sem_leitura[] = $pasta; continue; }
				// Dois links para a mesma pasta são uma única origem de logs.
				$encontrados[ $real ] = $real . '/' . basename( $padrao );
			}
		}
		if ( count( $encontrados ) > 1 ) {
			throw new RuntimeException( 'Resolução ambígua de ' . $padrao . ': múltiplos diretórios encontrados: ' . implode( ', ', array_keys( $encontrados ) ) . '. Configure um caminho absoluto exclusivo deste site.' );
		}
		if ( $sem_leitura ) { throw new RuntimeException( 'Diretório de logs sem leitura ou resolução pelo PHP: ' . implode( ', ', array_unique( $sem_leitura ) ) . '. Verifique permissões e open_basedir.' ); }
		if ( $encontrados ) { return reset( $encontrados ); }
		throw new RuntimeException( 'Não foi possível resolver ' . $padrao . '. ' . $diagnostico . '; nenhum diretório de logs acessível foi encontrado. Diretórios tentados: ' . implode( ', ', array_slice( array_unique( $tentados ), 0, 12 ) ) . '. Configure um caminho absoluto; verifique a existência da pasta, permissões e open_basedir.' );
	}
	/** Descoberta restrita a um diretório: combined não informa o virtual host. */
	public static function arquivos( string $padrao ): array {
		$padrao = self::resolver_padrao( $padrao );
		$arquivos = array(); $diretorios = array(); $vistos = array();
		foreach ( (array) glob( $padrao, GLOB_NOSORT ) as $arquivo ) {
			if ( ! preg_match( '/^access\.log\.(\d{4}-\d{2}-\d{2})$/D', basename( $arquivo ), $m ) ) { continue; }
			$dia = $m[1];
			if ( ! self::dia_valido( $dia ) || $dia >= wp_date( 'Y-m-d' ) ) { continue; }
			$real = realpath( $arquivo );
			if ( false === $real || ! is_file( $real ) || ! is_readable( $real ) ) { throw new RuntimeException( 'Log sem leitura: ' . $arquivo ); }
			$stat = stat( $real );
			$inode = $stat['dev'] . ':' . $stat['ino'];
			if ( isset( $vistos[ $inode ] ) ) { continue; }
			$vistos[ $inode ] = true;
			$diretorios[ dirname( $real ) ] = true;
			$arquivos[ $dia ][] = array( 'nome' => $real, 'tamanho' => (int) $stat['size'], 'mtime' => (int) $stat['mtime'] );
		}
		if ( count( $diretorios ) > 1 ) { throw new RuntimeException( 'O padrão alcança múltiplos diretórios: ' . implode( ', ', array_keys( $diretorios ) ) . '. Restrinja a um diretório deste site; logs combined não identificam o domínio.' ); }
		if ( ! $arquivos ) {
			$pastas = array_slice( (array) glob( dirname( $padrao ), GLOB_ONLYDIR ), 0, 12 );
			throw new RuntimeException( 'Nenhum arquivo datado fechado casa com ' . $padrao . '; pastas vistas: ' . ( implode( ', ', $pastas ) ?: '(nenhuma)' ) );
		}
		ksort( $arquivos );
		return $arquivos;
	}
	public static function dia_anterior(): string {
		return ( new DateTimeImmutable( wp_date( 'Y-m-d' ), new DateTimeZone( 'UTC' ) ) )->modify( '-1 day' )->format( 'Y-m-d' );
	}
	public static function corte( int $meses ): string {
		$hoje = new DateTimeImmutable( wp_date( 'Y-m-d' ), new DateTimeZone( 'UTC' ) );
		$mes = $hoje->modify( 'first day of this month' )->modify( '-' . $meses . ' months' );
		return $mes->setDate( (int) $mes->format( 'Y' ), (int) $mes->format( 'm' ), min( (int) $hoje->format( 'd' ), (int) $mes->format( 't' ) ) )->format( 'Y-m-d' );
	}
	private static function dia_valido( string $dia ): bool {
		$d = DateTimeImmutable::createFromFormat( '!Y-m-d', $dia, new DateTimeZone( 'UTC' ) );
		return false !== $d && $d->format( 'Y-m-d' ) === $dia;
	}
	/** Soma um dia completo na memória; falha preserva o dia anterior e seu checkpoint. */
	private static function ler_dia( array $arquivos, array $excluidos ): array {
		$agregados = array(); $caminhos = array(); $relatorios = array();
		$limite_php = (int) ini_get( 'max_execution_time' );
		$segundos = $limite_php > 0 ? max( 1, min( self::MAX_SEGUNDOS_DIA, intdiv( $limite_php, 3 ) ) ) : self::MAX_SEGUNDOS_DIA;
		$prazo = microtime( true ) + $segundos;
		foreach ( $arquivos as $arquivo ) {
			if ( $arquivo['tamanho'] > self::MAX_BYTES_ARQUIVO ) { throw new RuntimeException( 'Log excede o limite de 64 MiB por arquivo: ' . $arquivo['nome'] . '. Use coleta externa para este volume.' ); }
			$f = fopen( $arquivo['nome'], 'rb' );
			if ( false === $f ) { throw new RuntimeException( 'Não foi possível abrir ' . $arquivo['nome'] ); }
			$n = 0; $ignoradas = 0;
			try {
				while ( false !== ( $bruta = fgets( $f, 32769 ) ) ) {
					if ( microtime( true ) > $prazo ) { throw new RuntimeException( 'Leitura de ' . $arquivo['nome'] . ' excedeu ' . $segundos . ' segundos; dia preservado. Use coleta externa para este volume.' ); }
					++$n;
					if ( ! str_ends_with( $bruta, "\n" ) && ! feof( $f ) ) {
						while ( false !== ( $parte = fgets( $f, 32769 ) ) && ! str_ends_with( $parte, "\n" ) ) {
							if ( microtime( true ) > $prazo ) { throw new RuntimeException( 'Linha excessiva em ' . $arquivo['nome'] . '; dia preservado.' ); }
						} ++$ignoradas; continue;
					}
					$r = self::linha( $bruta, $excluidos );
					if ( null === $r ) { ++$ignoradas; continue; }
					$a = $r['agente']; $p = $r['caminho'];
					if ( '' !== $p ) {
						if ( ! isset( $caminhos[ $a ][ $p ] ) && count( $caminhos[ $a ] ?? array() ) >= self::TETO_CAMINHOS_POR_DIA ) { $r['caminho'] = ''; $r['classe_caminho'] = 'outro'; }
						else { $caminhos[ $a ][ $p ] = true; }
					}
					$chave = wp_json_encode( array_slice( $r, 0, 5 ) );
					if ( isset( $agregados[ $chave ] ) ) { ++$agregados[ $chave ]['contagem']; }
					else { $agregados[ $chave ] = $r; }
					if ( count( $agregados ) > self::TETO_AGREGADOS ) { throw new RuntimeException( 'Teto de agregados excedido em ' . $arquivo['nome'] . '; dia preservado sem atualização.' ); }
				}
				if ( ! feof( $f ) ) { throw new RuntimeException( 'Leitura interrompida em ' . $arquivo['nome'] ); }
			} finally { fclose( $f ); }
			clearstatcache( true, $arquivo['nome'] );
			if ( filesize( $arquivo['nome'] ) !== $arquivo['tamanho'] || filemtime( $arquivo['nome'] ) !== $arquivo['mtime'] ) { throw new RuntimeException( 'Log mudou durante a leitura: ' . $arquivo['nome'] . '; nova tentativa necessária.' ); }
			if ( $ignoradas > $n / 2 ) { throw new RuntimeException( 'Formato não reconhecido em ' . $arquivo['nome'] . ': ' . $ignoradas . ' de ' . $n . ' linhas.' ); }
			$relatorios[] = array( 'arquivo' => $arquivo['nome'], 'linhas' => $n, 'ignoradas' => $ignoradas );
		}
		return array( 'linhas' => array_values( $agregados ), 'arquivos' => $relatorios );
	}
	private static function gravar_dia( string $dia, array $linhas ): void {
		global $wpdb;
		$t = $wpdb->prefix . self::TABELA;
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) { throw new RuntimeException( 'Banco recusou a transação de acessos.' ); }
		try {
			if ( false === $wpdb->delete( $t, array( 'dia' => $dia ), array( '%s' ) ) ) { throw new RuntimeException( 'Banco recusou a substituição do dia ' . $dia ); }
			foreach ( array_chunk( $linhas, 100 ) as $lote ) {
				$valores = array(); $formas = array();
				foreach ( $lote as $r ) { $formas[] = '(%s,%s,%s,%s,%d,%s,%d)'; array_push( $valores, $dia, $r['agente'], $r['classe_caminho'], $r['caminho'], $r['status'], $r['metodo'], $r['contagem'] ); }
				if ( false === $wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (dia,agente,classe_caminho,caminho,status,metodo,contagem) VALUES " . implode( ',', $formas ), $valores ) ) ) { throw new RuntimeException( 'Banco recusou os agregados de ' . $dia ); }
			}
			if ( false === $wpdb->query( 'COMMIT' ) ) { throw new RuntimeException( 'Banco não confirmou o dia ' . $dia ); }
		} catch ( Throwable $erro ) { $wpdb->query( 'ROLLBACK' ); throw $erro; }
	}
	/** Mutex de processo liberado em fatal; evita corridas entre cron e botão no mesmo host. */
	public function somar(): array {
		global $wpdb;
		if ( empty( self::config()['ligado'] ) ) { return array( 'erro' => 'Soma desligada.' ); }
		$lock = @fopen( get_temp_dir() . 'f3base-acessos-' . hash( 'sha256', ABSPATH . $wpdb->prefix ) . '.lock', 'c' );
		if ( false === $lock ) {
			$e = F3Base_Options::ler( 'f3base_acessos_estado' );
			$e['erro'] = 'Diretório temporário sem escrita para a trava de acessos: ' . get_temp_dir();
			$e['tentativa'] = time(); $e['config_hash'] = self::config_hash();
			F3Base_Options::gravar( 'f3base_acessos_estado', $e );
			return $e;
		}
		if ( ! flock( $lock, LOCK_EX | LOCK_NB ) ) { fclose( $lock ); return array( 'em_curso' => true ); }
		$e = F3Base_Options::ler( 'f3base_acessos_estado' );
		$e['tentativa'] = time(); $e['erro'] = ''; $e['pendentes'] = 0;
		try {
			if ( ! self::tabela_pronta() ) { $e['dias'] = array(); }
			if ( ! $this->garantir_estrutura() ) { throw new RuntimeException( 'Não foi possível criar a tabela de acessos.' ); }
			$config = self::config();
			$hash = self::config_hash();
			$corte = self::corte( (int) $config['retencao_meses'] );
			$t = $wpdb->prefix . self::TABELA;
			if ( false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE dia < %s", $corte ) ) ) { throw new RuntimeException( 'Falha na retenção do agregado.' ); }
			foreach ( ( $e['dias'] ?? array() ) as $dia => $v ) { if ( $dia < $corte ) { unset( $e['dias'][ $dia ] ); } }
			$arquivos = self::arquivos( $config['padrao_do_log'] );
			$inicio = microtime( true ); $falhas = array();
			$limite_php = (int) ini_get( 'max_execution_time' );
			$orcamento = $limite_php > 0 ? max( 1, min( 10, intdiv( $limite_php, 3 ) ) ) : 10;
			foreach ( $arquivos as $dia => $grupo ) {
				if ( $dia < $corte ) { continue; }
				usort( $grupo, static fn( $a, $b ) => strcmp( $a['nome'], $b['nome'] ) );
				$assinatura = hash( 'sha256', wp_json_encode( array( $hash, $grupo ) ) );
				if ( ( $e['dias'][ $dia ]['assinatura'] ?? '' ) === $assinatura ) { continue; }
				if ( microtime( true ) - $inicio > $orcamento ) { ++$e['pendentes']; continue; }
				try {
					$lido = self::ler_dia( $grupo, $config['caminhos_excluidos'] );
					self::gravar_dia( $dia, $lido['linhas'] );
					$e['dias'][ $dia ] = array( 'assinatura' => $assinatura, 'arquivos' => $grupo, 'config_hash' => $hash );
					$e['ultima_soma'] = time();
					$e['ultima'] = array( 'arquivo' => implode( ', ', array_column( $grupo, 'nome' ) ), 'linhas' => array_sum( array_column( $lido['arquivos'], 'linhas' ) ), 'ignoradas' => array_sum( array_column( $lido['arquivos'], 'ignoradas' ) ), 'gravadas' => count( $lido['linhas'] ) );
					F3Base_Atividade::registrar( 'ultima_soma_acessos', $e['ultima'] );
					F3Base_Options::gravar( 'f3base_acessos_estado', $e );
				} catch ( Throwable $falha ) { $falhas[] = $falha->getMessage(); }
			}
			$e['config_hash'] = $hash;
			$e['dias_regras_anteriores'] = count( array_filter( $e['dias'] ?? array(), static fn( $d ) => ( $d['config_hash'] ?? '' ) !== $hash ) );
			$e['erro'] = implode( ' | ', array_slice( $falhas, 0, 10 ) );
			if ( $e['pendentes'] && ! wp_next_scheduled( self::CONTINUAR ) && ! wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::CONTINUAR ) ) { $e['erro'] = trim( $e['erro'] . ' O WordPress recusou o agendamento da continuação.' ); }
			if ( ! $e['pendentes'] ) { wp_unschedule_hook( self::CONTINUAR ); }
			delete_transient( 'f3base_acessos_titulos' );
		} catch ( Throwable $erro ) { $e['erro'] = $erro->getMessage(); $e['config_hash'] = self::config_hash(); }
		finally { F3Base_Options::gravar( 'f3base_acessos_estado', $e ); flock( $lock, LOCK_UN ); fclose( $lock ); }
		return $e;
	}
	/** Leitura administrativa limitada e ordenada; totais calculados antes do LIMIT. */
	public static function consultar( int $dias = 90, string $classe = '', string $prefixo = '', bool $erros = false, int $offset = 0, bool $incluir_hoje = false ): array {
		global $wpdb;
		$dias = max( 1, min( 90, $dias ) );
		$fim = $incluir_hoje ? wp_date( 'Y-m-d' ) : self::dia_anterior();
		$inicio = ( new DateTimeImmutable( $fim ) )->modify( '-' . ( $dias - 1 ) . ' days' )->format( 'Y-m-d' );
		$e = F3Base_Options::ler( 'f3base_acessos_estado' );
		$cobertos = array_filter( array_keys( $e['dias'] ?? array() ), static fn( $d ) => $d >= $inicio && $d <= $fim && $d <= self::dia_anterior() );
		$saida = array( 'inicio' => $inicio, 'fim' => $fim, 'linhas' => array(), 'total_linhas' => 0, 'limite' => self::TETO_LINHAS, 'offset' => max( 0, $offset ), 'totais' => array( 'excluido' => 0, 'estatico' => 0, 'outro' => 0 ), 'dias_somados' => count( $cobertos ), 'ultimo_dia' => $cobertos ? max( $cobertos ) : '', 'estado' => ( new self() )->estado(), 'ultima' => $e['ultima'] ?? array(), 'pessoas_medidas' => array() );
		if ( ! self::tabela_pronta() ) { return $saida; }
		$t = $wpdb->prefix . self::TABELA;
		$where = $wpdb->prepare( 'dia >= %s AND dia <= %s', $inicio, $fim ) . ( $erros ? ' AND status BETWEEN 200 AND 599' : ' AND status BETWEEN 200 AND 399' );
		if ( $incluir_hoje ) { $where .= $wpdb->prepare( ' AND dia < %s', $fim ); }
		foreach ( (array) $wpdb->get_results( "SELECT classe_caminho, SUM(contagem) AS total FROM {$t} WHERE {$where} GROUP BY classe_caminho", ARRAY_A ) as $r ) { if ( isset( $saida['totais'][ $r['classe_caminho'] ] ) ) { $saida['totais'][ $r['classe_caminho'] ] = (int) $r['total']; } }
		if ( in_array( $classe, self::CLASSES, true ) ) { $where .= $wpdb->prepare( ' AND classe_caminho = %s', $classe ); }
		if ( '' !== $prefixo ) { $where .= $wpdb->prepare( ' AND caminho LIKE %s', $wpdb->esc_like( $prefixo ) . '%' ); }
		$group = 'agente,classe_caminho,caminho,status,metodo';
		$saida['total_linhas'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM (SELECT 1 FROM {$t} WHERE {$where} GROUP BY {$group}) f3base_grupos" );
		$saida['linhas'] = (array) $wpdb->get_results( $wpdb->prepare( "SELECT {$group}, SUM(contagem) AS contagem FROM {$t} WHERE {$where} GROUP BY {$group} ORDER BY classe_caminho,caminho,agente,status,metodo LIMIT %d OFFSET %d", self::TETO_LINHAS, max( 0, $offset ) ), ARRAY_A );
		foreach ( $saida['linhas'] as &$r ) { $r['status'] = (int) $r['status']; $r['contagem'] = (int) $r['contagem']; $r['classe_agente'] = self::classe_agente( $r['agente'] ); } unset( $r );
		return $saida;
	}
}
