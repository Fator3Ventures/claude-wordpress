# Base Site Core Fator3 — correções 1.1.1

A versão corrige a navegação das configurações na instalação independente e o diretório padrão dos logs. Mantém as melhorias de acessos, sessão de login e llms.txt da versão 1.1.0.

## Diagnóstico e correções

| Relato | Causa confirmada e ajuste |
| --- | --- |
| F3 Base abre apenas “Leads (contingência)” | Sem Flamingo, o CPT privado de leads aparece como submenu. O WordPress usa a primeira entrada desse submenu como destino do menu principal. A configuração já existia, mas sua entrada não estava explícita. Agora **Configurações** ocupa a primeira posição e **Leads (contingência)** continua acessível separadamente. |
| O padrão de logs contém www, mas o diretório do host não | O padrão copiava literalmente o host da home. Agora normaliza o host em minúsculas e remove somente o prefixo `www.`. Outros subdomínios são preservados. |
| Instalações existentes conservam o padrão incorreto | A inicialização reconhece o antigo padrão exato e o corrige, mesmo com a soma desligada, sem reativar o plugin. Preserva retenção, exclusões, estado ligado/desligado e procedência. Caminhos personalizados permanecem intactos. |

Exemplo: a home `https://www.exemplo.com` passa a usar `~/logs/exemplo.com/https/access.log.*`. Uma home `https://loja.exemplo.com` continua usando `~/logs/loja.exemplo.com/https/access.log.*`. O endereço público do site não é alterado.

O implantador anexado foi inspecionado. Seu catálogo declara Flamingo como caixa de leads; no site-core, a presença de Flamingo oculta a contingência quando não há registros nela. Isso explica como a composição instalada pelo implantador pode mascarar o defeito do menu. Não houve acesso ao site do usuário para determinar quais ações do implantador aconteceram ali. A correção foi comprovada com apenas o site-core ativo.

## Validação

Os dois defeitos foram reproduzidos no ZIP 1.1.0 antes da correção. A versão nova passou pelos testes específicos de navegação via HTML administrativo, leitura do formulário completo, POST com nonce, persistência de campo e conservação da lista de contingência.

No Chromium, foi realizado login pelo formulário nativo, clique no menu **F3 Base**, alteração do prazo da sessão, envio pelo botão **Gravar e conferir**, leitura do valor salvo e abertura da lista de contingência. Não houve erro de JavaScript. A captura e o relato ficam em `dist/validacao-1.1.1/`.

Uma instalação descartável com o ZIP 1.1.0 recebeu o novo ZIP sem desativação ou reativação. A primeira requisição HTTP corrigiu o padrão salvo com www. A leitura de confirmação foi feita sem carregar o plugin, para impedir que o próprio teste executasse a migração que pretendia medir.

A suíte completa e seu piso de detecção acompanham o fonte em `dist/validacao-1.1.1/`. O piso reintroduz separadamente a ausência do submenu, o padrão com www e a ausência da migração, exigindo falha nos respectivos testes. O resultado resumido está em `resultado.json`; os logs registram os vereditos completos.

Ambiente de validação: WordPress 7.1, PHP 8.3.6, SQLite e Chromium 151. As verificações locais não incluem o servidor de produção, seu MySQL/MariaDB ou a leitura de seus logs reais.

## Instalação

1. No WordPress, envie **base-site-core-fator3-1.1.1.zip** em **Plugins → Adicionar plugin → Enviar plugin** e substitua a versão instalada. Use o ZIP instalável, não o ZIP de fonte.
2. Abra **F3 Base → Configurações**. O implantador não é necessário para acessar ou salvar a tela.
3. Confira **Acessos do servidor → Padrão do log**. O antigo padrão exato é corrigido automaticamente. Se havia um caminho personalizado, ele foi preservado e pode ser ajustado nesse campo.
4. Abra **Medição → Acessos** e execute **Somar agora** para confirmar a leitura no host. O resultado depende da existência e da permissão de leitura dos arquivos datados.

Atualize por substituição. Excluir o plugin aciona sua rotina de desinstalação, que remove dados próprios. Não é necessário excluir o plugin nem reinstalar o implantador para aplicar esta correção.

O fonte contém documentação, testes e histórico Git em `dist/base-site-core-fator3-1.1.1.bundle`. Para obter um checkout com histórico: `git clone base-site-core-fator3-1.1.1.bundle base-site-core-fator3`. A versão anterior permanece no histórico e em `dist/referencias/base-site-core-fator3-1.1.0.zip` para reproduzir a atualização.
