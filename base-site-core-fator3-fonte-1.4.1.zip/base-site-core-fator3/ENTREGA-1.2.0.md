# Base Site Core Fator3 — medição atualizada 1.2.0

- **Atualizar** substitui Aplicar, relê o arquivo `access.log` e recalcula a tela com hoje incluído. Hoje é parcial, com data, horário da leitura e fuso do WordPress. Um dia significa somente hoje.
- Períodos: **1, 2, 3, 4, 5, 6, 7, 15, 30, 60 e 90 dias**.
- **Coletar e Armazenar Logs** substitui Somar agora, conserva período e filtro de erros e continua armazenando somente `access.log.AAAA-MM-DD` de datas anteriores a hoje. Ignora `access.log`, `.0`, datas de hoje e arquivos compactados.
- A coleta automática diária já existia e permanece agendada às **09:00 UTC**. A tela agora informa a próxima execução no fuso local, atraso, falta de agendamento e acionamento desabilitado. O mesmo coletor atende o botão e a ação do cron; sua repetição não duplica dias.

## Limites e operação

A atualização ocorre ao clicar no botão ou recarregar a página, sem polling contínuo. Conta somente linhas completas de hoje presentes no arquivo corrente no início da leitura; novas linhas entram na próxima atualização. Atrasos de escrita, rotação intradiária, logs indisponíveis e CDN podem limitar a cobertura. A leitura respeita limite de 64 MiB e orçamento de tempo de até 8 segundos. Falhas são exibidas separadamente e o histórico continua visível. Hoje não é persistido nem guardado em cache de contagens.

O WP-Cron depende de requisições ao site e pode executar depois do horário agendado. Para regularidade em sites sem tráfego, configure o cron da hospedagem para acionar o WordPress. O plugin não pode criar essa tarefa do servidor. [Funcionamento do WP-Cron na documentação oficial](https://developer.wordpress.org/plugins/cron/).

O histórico conserva o calendário dos arquivos datados do host; hoje usa timestamps convertidos ao fuso do WordPress. O registro de pessoas medidas usa dias UTC. O MCP `f3base/acessos-ler` continua consultando somente o histórico até ontem. Humanos são requisições de agentes não declarados como robôs, não pessoas únicas.

## Instalação

Atualize o plugin pelo ZIP instalável, substituindo a versão anterior. Não é necessário instalar o implantador. A agenda e a estrutura são verificadas na inicialização, inclusive em atualização sem reativação. As correções anteriores de menu, domínio sem www e resolução de logs sem HOME permanecem.

O pacote fonte inclui código, suíte, documentação e evidências locais. Esta entrega não instala a nova versão no site conectado.

## Validação

A suíte principal terminou com **149 verificações aprovadas, 12 não aplicáveis e nenhuma falha ou bloqueio**, usando WordPress 7.1, PHP 8.3.6 e SQLite em instalação descartável do ZIP.

Os novos testes verificam filtro de dia/fuso, linhas incompletas, releitura após append, períodos, filtro de erros, totais por família, ordenação após unir hoje, ausência de persistência do dia atual e preservação do histórico quando o log corrente falha. A ação do cron foi executada no WordPress real: coletou o arquivo datado anterior, ignorou os três arquivos abertos/atuais e não duplicou registros ao repetir. A agenda diária foi removida e recuperada, sem duplicação, e retirada ao desligar o módulo.

A prova no Chromium instalou a versão anterior, substituiu os arquivos sem reativação, efetuou login, clicou nos dois botões e manteve os filtros. Após acrescentar uma linha ao log atual, a contagem passou de três para quatro ao clicar em Atualizar. A coleta histórica manteve quatro e a consulta ao banco confirmou que hoje não foi armazenado. A captura de tela está em `dist/validacao-1.2.0/acessos-wordpress-local.png` no pacote fonte.

Na rodada ampla de mutações, **138 ramos passaram**. Um patch antigo não aplicou porque seu contexto ainda continha o nome anterior do botão; isso foi uma falha da fixture, sem alterar o comportamento do produto. O patch foi atualizado e o cenário foi reexecutado isoladamente nos dois sentidos: fonte correta aceita e defeito plantado detectado. Os resultados originais e a revalidação estão preservados em `dist/validacao-1.2.0/`. Os mutantes novos que removem o filtro de hoje e permitem coletar o arquivo datado de hoje foram detectados na rodada ampla.

A nova versão foi validada localmente; não foi instalada no site de teste conectado.
