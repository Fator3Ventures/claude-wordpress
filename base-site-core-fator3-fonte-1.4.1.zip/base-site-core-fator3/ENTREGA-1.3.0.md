# Base Site Core Fator3 — 1.3.0

Revisão de llms.txt e robots.txt, com base nas fontes oficiais consultadas em **10 de setembro de 2026**. A entrega parte do fonte completo 1.2.0 e conserva as correções anteriores de configuração independente, descoberta de logs, medição de hoje e coleta diária.

## O que mudou

| Área | Implementação |
| --- | --- |
| Índice llms.txt | Título H1, resumo em citação, seções H2 e listas de links. Títulos e descrições recebem escape Markdown; quebras e controles não criam seções. Destinos exigem HTTP(S), sem credenciais ou controles. |
| Seleção | Curadoria de conteúdo local identificado passa pelas mesmas restrições de publicação, senha e noindex reconhecido pelo plugin. Resolve IDs por URL, usa o permalink atual e lê o corpo atual. Deduplicação por ID e URL; limite global de 200 itens, incluindo curadoria. |
| Alternativas Markdown | Campo `f3base_llms.markdown`, ligado por padrão. Conteúdos selecionados recebem alternativa `index.md` sob o permalink ou `.md` após a extensão. Com permalinks simples, utiliza `?f3base_markdown=ID`. |
| Descoberta | HTML anuncia llms.txt com `rel="describedby"`; páginas selecionadas anunciam a alternativa com `rel="alternate"` e `type="text/markdown"`. A resposta Markdown informa o endereço canônico e llms.txt no cabeçalho `Link`. |
| Corpo Markdown | Preserva texto editorial, títulos, listas, links e código; remove elementos de interface. Não executa shortcodes, blocos dinâmicos nem requisições externas. |
| HTTP e indexação | Índices em `text/plain; charset=utf-8`; alternativas em `text/markdown; charset=utf-8`. HEAD sem corpo. Alternativas recebem `X-Robots-Tag: noindex` para evitar duplicação em buscadores. |
| Visibilidade | A publicação automática é suspensa quando a opção de visibilidade pública do WordPress está desativada. Arquivos físicos ficam sob controle do servidor. |
| Emissores | Arquivos físicos conservam precedência, usando a raiz pública mesmo quando o núcleo está numa subpasta. llms-full.txt tem verificação de arquivo físico própria. |
| Robots virtual | Novo módulo `robots-txt`, com controle `f3base_robots.ligado`. Complementa a saída do WordPress com sitemap disponível, sem duplicar o mesmo endereço nem substituir regras existentes. |
| Permalinks simples | Rota de reserva de `/robots.txt` usa o gerador do próprio WordPress quando o núcleo não reconhece o endereço como robots. |
| Sitemap | Corrigida consulta a uma função inexistente: a medição agora usa `wp_sitemaps_get_server()`, o estado do servidor e a URL de seu índice. Respeita sitemap desativado e URLs com parâmetros. A compatibilidade anterior com o emissor de SEO reconhecido permanece. |
| Textos da configuração | Removidas promessas de citação em IA e a associação incorreta entre noindex e bloqueio de leitura/treinamento. |

## Critérios adotados

A proposta **llms.txt v2**, revisada em agosto de 2026, recomenda um índice conciso em Markdown, descrição do site, links organizados e alternativas em Markdown para o conteúdo. A descoberta em HTML e a relação com as páginas foram consideradas na implementação. O arquivo integral continua opcional e é anunciado em `Optional` quando este plugin é responsável por publicá-lo. llms.txt é uma proposta; não controla rastreamento nem concede ou revoga permissões de uso do conteúdo. [Proposta llms.txt](https://llmstxt.org/) e [mudanças da proposta](https://llmstxt.org/changes.html).

Para robots.txt foram adotados o caminho na raiz da origem, resposta textual e preservação de grupos e regras. Grupos específicos não herdam automaticamente as regras do grupo `*`; por isso o complemento não cria grupos de bots de IA nem muda políticas existentes. Não adiciona `Noindex:`, `Crawl-delay:` ou campos como `LLMs-txt:`. Também não introduz bloqueios de CSS, JavaScript ou imagens. [RFC 9309](https://www.rfc-editor.org/rfc/rfc9309.html) e [interpretação do robots.txt pelo Google](https://developers.google.com/crawling/docs/robots-txt/robots-txt-spec).

O gerador do núcleo mantém a regra de `/wp-admin/` e a exceção de `admin-ajax.php`; outros emissores podem acrescentar suas próprias regras. Em site não público, o complemento conserva a política do núcleo, sem acrescentar um bloqueio geral que impediria a leitura de noindex. [Gerador do WordPress](https://developer.wordpress.org/reference/functions/do_robots/), [servidor de sitemaps](https://developer.wordpress.org/reference/functions/wp_sitemaps_get_server/) e [URL do índice](https://developer.wordpress.org/reference/classes/wp_sitemaps_index/get_index_url/).

Bloquear rastreamento não impede necessariamente que uma URL apareça nos resultados, e robots.txt não protege conteúdo confidencial. Noindex precisa ser lido pelo rastreador; conteúdo privado exige controle de acesso. O Google informa que suas funcionalidades de IA na Busca não exigem arquivos textuais especiais para IA, e nenhuma destas mudanças garante citações ou posicionamento. [Introdução a robots.txt](https://developers.google.com/search/docs/crawling-indexing/robots/intro) e [funcionalidades de IA na Busca](https://developers.google.com/search/docs/appearance/ai-features).

## Situação do site conectado

A consulta somente de leitura ao site `fator3-teste-mcp-1.dreamhosters.com` identificou um **robots.txt físico criado pelo implantador**, com regras que excluem URLs de busca e um sitemap. Esse arquivo tem precedência sobre a resposta virtual do WordPress. O plugin passa a diagnosticar essa condição, mas não apaga nem reescreve o arquivo. O llms.txt físico não foi encontrado nessa consulta.

Assim, atualizar o plugin **não substitui automaticamente o robots.txt físico desse site**. Para adotar o gerador virtual, é necessário revisar e preservar as regras desejadas antes de remover o arquivo físico, mantendo uma cópia. Esta entrega não instala a versão nem altera arquivos no site conectado.

## Limites e operação

- Conteúdo montado por JavaScript, shortcodes, blocos dinâmicos ou construtores pode não estar integralmente no corpo salvo. A alternativa Markdown não renderiza esses componentes. Sem a extensão PHP DOM, há fallback para texto limpo com estrutura simplificada.
- Referências externas e URLs livres não identificáveis como conteúdo do WordPress dependem da curadoria editorial. O plugin não rastreia sites externos nem garante a disponibilidade desses destinos.
- As regras de noindex de conteúdo continuam sendo as reconhecidas pelo módulo existente do plugin. Regras de um proxy, servidor ou plugin de terceiros fora dessa integração não são inferidas.
- Servidores, arquivos físicos, cache, CDN e emissores executados após os filtros podem modificar a resposta final. Em home dentro de subdiretório, robots.txt ainda precisa estar na raiz da origem; isso depende do encaminhamento do servidor.
- O emissor llms.txt do plugin de SEO já reconhecido conserva a precedência. Não é uma detecção universal de todos os plugins de SEO.
- O limite de seleção é de 200 itens para manter o índice manejável. A curadoria editorial continua recomendada para destacar páginas úteis e descrições precisas.

## Validação

A suíte principal concluiu **151 verificações aprovadas, nenhuma falha e nenhum bloqueio**, com **13 casos não aplicáveis** na rodada. Foi usado WordPress 7.1, PHP 8.3.6 e SQLite em instalações descartáveis, com instalação a partir do ZIP. Chromium não estava disponível nesta rodada; as verificações de navegador não foram executadas. Os endpoints e a configuração administrativa foram verificados por HTTP.

Os novos cenários cobrem estrutura e escape do índice; curadoria por ID e URL; exclusão de rascunhos, privados, senha e noindex; limite e deduplicação; alternativas Markdown de páginas e artigos com permalinks simples, bonitos e com extensão; descoberta HTML; cabeçalhos e HEAD; precedência de arquivos físicos; visibilidade do site; robots e sitemap real. A regressão anterior de acessos de hoje, coleta diária, configuração independente e resolução de logs também passou.

Foram executados **oito mutantes relacionados à publicação e ao menu**, em cópias isoladas do plugin. Todos foram recusados pelos testes pelos motivos esperados: quebra do arquivo integral, vazamento de página com senha, link Optional indevido, URL integral incorreta, retorno ao menu de contingência, noindex ignorado na curadoria, cabeçalho Link removido e sitemap nativo não descoberto. A rodada ampla de todos os mutantes antigos não foi repetida nesta entrega; seus testes e evidências históricas permanecem no fonte.

A primeira verificação administrativa encontrou timeout nos feeds externos do dashboard. A bancada passou a ler o mesmo menu pela tela de opções gerais, sem esses feeds; menu e gravação com nonce passaram por HTTP. Não foi uma alteração do menu do produto.

Evidências: `dist/validacao-1.3.0/verificacao.log`, `rodada.json`, `piso-publicacao.ndjson` e exemplos sintéticos das respostas llms.txt, robots.txt e Markdown. Esses exemplos têm conteúdo adversarial de teste e endereço localhost; não são arquivos para publicar no site.

Para reproduzir, disponibilize PHP com DOM, mbstring, SQLite, cURL, ZIP e demais extensões usuais, Node.js, zip/unzip e faketime. Execute `bash suite/verificar.sh /caminho/do/pacote`. A bancada baixa/cacheia WordPress, o drop-in SQLite e WP-CLI; `F3BASE_BANCADA_CACHE` permite reaproveitar os insumos. Depois, execute `python3 suite/bancada-wp/piso-publicacao.py /caminho/do/pacote` para os mutantes desta revisão. O comando amplo `bash suite/verificar.sh piso /caminho/do/pacote` continua disponível.

## Instalação e fonte

Instale o ZIP `base-site-core-fator3-1.3.0.zip`, substituindo a versão anterior. O implantador não é necessário. O ZIP fonte inclui `fontes/plugin`, suíte de testes, documentação, evidências em `dist/validacao-1.3.0`, instalador e histórico Git em bundle. O manifesto SHA-256 acompanha os arquivos de entrega.
