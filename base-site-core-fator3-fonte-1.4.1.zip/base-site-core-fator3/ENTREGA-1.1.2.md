# Base Site Core Fator3 — resolução genérica de logs 1.1.2

A versão mantém as correções anteriores e permite resolver padrões `~/logs/...` quando o PHP não recebe HOME. O usuário e o domínio do site de teste não foram incorporados ao código.

## Como funciona

1. Caminhos absolutos são usados como configurados.
2. Para `~/`, são consultados HOME do SAPI e do ambiente local, os diretórios disponíveis via POSIX do usuário efetivo do PHP e do proprietário da instalação, e até 16 níveis ascendentes dos caminhos lógico e real do WordPress.
3. Em cada candidato, é procurado o diretório completo do padrão configurado. Não há enumeração de outras contas nem busca recursiva no servidor.
4. Links simbólicos são resolvidos. Vários aliases da mesma pasta contam como uma origem; duas pastas reais distintas geram diagnóstico de ambiguidade e exigem um caminho absoluto.
5. A pasta precisa estar acessível, e os arquivos são verificados quanto à leitura. Sem pasta identificada, a mensagem informa a condição observada de HOME e os caminhos tentados. Pasta existente sem arquivos datados produz uma mensagem diferente.

A documentação do PHP descreve o retorno `false` de [getenv](https://www.php.net/manual/en/function.getenv.php) quando a variável não existe e o campo `dir` de [posix_getpwuid](https://www.php.net/manual/en/function.posix-getpwuid.php) para o diretório do usuário. POSIX é opcional nesta implementação.

## Evidência no host real

Uma rotina temporária autenticada, acessível apenas a administrador, executou uma cópia exata do novo método de resolução pelo WP MCP fator3-teste. O resultado foi:

- `getenv('HOME')`: `false`.
- `getenv('HOME', true)`: `false`.
- POSIX disponível: `true`.
- Padrão com til resolvido com sucesso para o diretório real de logs do host.
- 7 arquivos datados encontrados, todos com leitura permitida.

O arquivo temporário foi removido com verificação de SHA-256. A listagem posterior da pasta confirmou zero arquivos. O conector guardou seu backup de remoção. A prova não alterou as opções, não executou a soma e não substituiu o plugin instalado.

Essa medição confirma a causa do erro anterior: HOME estava ausente do processo PHP, embora os logs fossem acessíveis pelo caminho absoluto. A evidência estruturada acompanha o fonte em `dist/validacao-1.1.2/home-host.json`.

## Testes locais

A suíte exercita o código entregue em subprocesso sem HOME e com as funções POSIX desabilitadas. Confere instalação em subdiretórios, descoberta por ascendentes, links simbólicos, deduplicação de aliases, preservação de caminho absoluto, recusa de duas origens, domínio sem pasta correspondente e pasta vazia. Dois mutantes removem separadamente a descoberta por ascendentes e a recusa de ambiguidade.

A suíte geral, seu piso de detecção e os resultados resumidos estão em `dist/validacao-1.1.2/`. O cenário local usa WordPress 7.1, PHP 8.3.6 e SQLite; o teste remoto do método usou o PHP 8.3.30 do site. A coleta integral da nova versão não foi instalada ou executada no servidor nesta entrega.

## Instalação e alcance

Envie `base-site-core-fator3-1.1.2.zip` pelo atualizador do WordPress, substituindo a versão existente. Abra **Medição → Acessos → Somar agora** para aplicar a nova resolução imediatamente. Uma tentativa recente que falhou ainda pode aguardar o próximo disparo automático; o botão antecipa essa execução.

Um caminho absoluto já configurado continua funcionando. Para usar a descoberta automática, o campo pode manter `~/logs/dominio-do-site/https/access.log.*`, com o domínio correspondente ao diretório dos logs. O ajuste anterior que remove o www inicial do padrão permanece.

A resolução é genérica para as disposições de diretório verificáveis pelas fontes descritas. Não existe descoberta garantida em toda hospedagem: o provedor precisa disponibilizar os arquivos ao PHP. Logs em um diretório fora dessas relações exigem configuração absoluta; permissões e open_basedir continuam sendo respeitados. A leitura continua voltada a logs combined datados e fechados, conforme o contrato anterior.

O ZIP de fonte inclui documentação, suíte, evidências e histórico em `dist/base-site-core-fator3-1.1.2.bundle`. O bundle pode ser clonado por Git. A versão instalada no host não foi substituída automaticamente.
