# Entrega — Base Site Core Fator3 1.1.0

A evolução foi aplicada sobre o **fonte completo** enviado, preservando a estrutura do plugin e sua suíte. A entrega inclui o ZIP instalável, a cópia com o nome do catálogo, o fonte, um bundle Git com as tags de origem e evolução, os quatro documentos atualizados e as evidências de validação.

## Conferência dos arquivos recebidos

O ZIP maior contém o projeto com a suíte e a documentação de desenvolvimento. O PHP do plugin corresponde ao instalador original; os JavaScripts do instalador têm os comentários retirados pelo processo de build. O instalador fornecido é a referência usada no teste de atualização real.

| Arquivo recebido | SHA-256 |
|---|---|
| `base-site-core-fator3.zip` | `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f` |
| `base-site-core-fator3-fonte-1.0.0.zip` | `f53cd6812cf429788252ae7588c476d9366ff4d0dbb1271ce1769bb19ad87007` |
| `Plano plugin 1.1.0 acessos.md` | `8c713f2bbd4fe80471fb7938936d5cea388c20af9e58b23c5f74dd9d33705cbd` |

## O que foi implementado

| Parte do plano | Comportamento entregue |
|---|---|
| Acessos do servidor | Módulo ligado por padrão; parser combined; agregados por dia, família, caminho, classe, status e método. Sem coluna de IP, referer ou User-Agent bruto. |
| Arquivos e reprocessamento | Apenas `access.log.AAAA-MM-DD` de dias fechados. Ignora `.0`, comprimidos e o dia corrente; deduplica aliases; acompanha nome, tamanho e mtime. |
| Consistência | Substituição do dia em transação, checkpoint após confirmação, trava de execução no host, recuperação quando a tabela falta e continuação entre dias. |
| Retenção | Padrão de 25 meses por calendário, com descarte dos dias vencidos. Configuração aceita 1 a 120 meses. |
| Tela | Aba **Medição → Acessos**, períodos de 7/30/90 dias, famílias por página, métricas do navegador ao lado, descoberta/APIs separadas, filtro de erros, cobertura e totais excluídos. |
| Operação | Botão **Somar agora** com nonce e `manage_options`, evento diário às 09h UTC, diagnóstico de fonte indisponível, formato inválido, importação parcial e agendamento recusado. |
| MCP | `f3base/acessos-ler`, autorização administrativa, schema de entrada fechado, filtro por caminho/classe/status e paginação. Não devolve linhas brutas de log. |
| Sessão | Padrão de 90 dias, ajustável entre 1 e 365, cookie persistente no login nativo e diagnóstico do prazo efetivo e dos filtros concorrentes. |
| llms.txt | Seção `Optional` com URL de `home_url()` para o texto integral quando habilitado e servido pelo próprio emissor. Não acrescenta esses arquivos ao sitemap. |
| Ciclo de vida | Ativação e atualização criam estrutura e cron; desinstalação remove tabela/estado/eventos e preserva configurações. |
| Documentação | README, MANIFESTO, INSTRUCOES e MEMORIA atualizados; decisões 78 a 92, contratos de nomes, inventário e provas de regressão incluídos. |

Os mínimos declarados continuam WordPress 6.4 e PHP 8.1, em instalação única e PHP de 64 bits. A habilidade MCP depende da disponibilidade da Abilities API no WordPress, como as demais habilidades do plugin.

## Ajustes feitos no plano

- **Isolamento do site:** o padrão inicial é `~/logs/<host-de-home_url>/https/access.log.*`. O wildcard entre domínios do plano poderia misturar sites. Um padrão que alcance múltiplos diretórios é recusado, pois combined não informa o virtual host.
- **Unidade da comparação:** “humanos” conta requisições cujo agente não se declarou robô; “pessoas medidas” conta identificadores distintos do registro detalhado. A diferença não quantifica bots. A tela informa também a retenção e o calendário distintos das fontes.
- **Marcas de robôs:** Google-Extended e Applebot-Extended são controles de uso em robots.txt, sem crawler HTTP próprio. Se aparecerem como User-Agent, entram como automação genérica. Marcas legadas sem confirmação atual são identificadas assim no TSV, em vez de receber uma finalidade presumida.
- **Privacidade:** retirar IP e User-Agent bruto não garante anonimato de um caminho que contenha dados pessoais. Queries não são persistidas; e-mails e tokens evidentes no caminho perdem o detalhe; rotas privadas devem ser excluídas na configuração. O gerador de privacidade pertence ao implantador e não oferece aqui uma extensão por módulo: a inclusão da frase na página gerada permanece pendente nessa fase, conforme o plano.
- **Limites de importação:** a primeira requisição começa a soma, com continuação por cron quando o orçamento entre dias termina. O estado informa progresso parcial. Há teto de 64 MiB por arquivo, 500 caminhos por dia/família, 50.000 agregados por dia e até 8 segundos de leitura por dia, reduzidos para limites menores de execução do PHP. Um dia excedido é recusado inteiro e preserva seu agregado anterior; exige redução de volume ou coletor externo.
- **Sessão efetiva:** `value_remember` marca a caixa no formulário do tema; `remember` apenas a exibe. O diagnóstico identifica o último grupo de filtros que alterou o prazo. Callbacks na mesma prioridade são apresentados juntos, porque não é correto atribuir a alteração individualmente sem evidência.
- **Histórico de decisões:** notas de versões anteriores foram preservadas. O detector da suíte agora recusa versões futuras, sem obrigar a reescrever a história a cada release.

## Validação

Ambiente: WordPress **7.1**, PHP **8.3.6**, SQLite Database Integration **3.0.1**, WP-CLI **2.12.0**, Node **24.19.0** e Chromium **151.0.7922.34**.

| Execução | OK | FALHA | BLOCKED | N/A |
|---|---:|---:|---:|---:|
| Suíte principal no fonte | 144 | 0 | 0 | 12 |
| Provas de regressão no fonte | 127 | 0 | 0 | 0 |

O **clone limpo** repetiu os dois resultados: 144 OK na suíte principal e 127 OK nas provas de regressão, com zero FALHA e zero BLOCKED. Os 12 N/A permanecem restritos à aplicação no host. O ZIP produzido pelo clone tem SHA-256 idêntico ao do fonte de trabalho. Os arquivos de código e da suíte permaneceram iguais após essa validação; o fechamento posterior apenas registrou o resultado neste relatório.

Os 12 casos não aplicáveis são verificações do site/serviços externos: envio de formulário, alternativa sem JavaScript, controle de consentimento no rodapé, cabeçalhos do host, disparo de cron no host, emissor de tracking, rota da origem, popup/COOP, Core Web Vitals, destino privado, envio CAPI e verificação de domínio. Não foram tratados como aprovações.

A cobertura inclui contagens sintéticas exatas, precedência de famílias, exclusões, caminhos codificados, instalação em subdiretório, isolamento de domínios, idempotência, alteração do arquivo, limite de cardinalidade, erro SQL e exceção após o DELETE, retenção e fim de mês, autorização/schema da habilidade, tela, duração dos cookies e tokens e conflito de filtros. O módulo de sessão desligado foi conferido em novo login HTTP.

A atualização foi medida instalando o ZIP 1.0.0 recebido em WordPress descartável, confirmando ausência da nova tabela/evento, trocando os arquivos pelo ZIP novo sem desativar nem reativar e fazendo a primeira requisição por HTTP. A tabela, o cron e os agregados de dois dias apareceram. Um observador confirmou ausência de nova ativação.

Também foi feito login no Chromium e acionado o botão **Somar agora** com o formulário real. A captura da aba está em `dist/validacao/acessos-wordpress-local.png`. As provas de regressão executam cada mutante em outra instalação descartável. O teste de rollback cobre erro SQL e uma exceção anterior ao INSERT: o segundo cenário é necessário porque o driver SQLite pode reverter erros SQL automaticamente.

As evidências integrais, os dados do ambiente e as somas dos insumos de teste ficam em `dist/validacao/`. Os testes de origem foram registrados contra o ZIP anterior, antes da implementação, com falhas esperadas nos recursos ausentes. Não há alegação de uma sequência prévia de falha para cada teste adicional criado durante a revisão.

## Uso e limites da entrega

1. Instale `base-site-core-fator3-1.1.0.zip` pelo atualizador de plugins do WordPress, substituindo a versão anterior. O ZIP de fonte é destinado a desenvolvimento.
2. Confira o padrão de logs em **F3 Base** e abra **Medição → Acessos**. Se o host não expuser esses arquivos ao PHP, o módulo mostrará o motivo; configure o caminho real desse site.
3. Confira os dias somados e use **Somar agora**. O histórico começa com os arquivos ainda disponíveis; não há promessa de 90 dias no primeiro uso. O cron depende do mecanismo de disparo do WordPress/host.
4. Faça um novo login para receber o prazo configurado. Cookies já emitidos mantêm o prazo original. O controle de revogação continua no perfil do WordPress.
5. Para reverter o código, reinstale o ZIP anterior. Isso não revoga sessões existentes nem apaga automaticamente o agregado novo. Desligar a coleta preserva o histórico e interrompe sua limpeza; desinstalar remove tabela e estado. Um backup do banco é necessário para recuperar dados que tenham sido eliminados. O instalador anterior, com os bytes recebidos, está incluído no fonte em `suite/fixtures/atualizacao/base-site-core-fator3-1.0.0.zip`.

A validação é local, com WordPress real e banco SQLite. O servidor de produção, seu MySQL/MariaDB, logs reais, PHP 8.1 e WordPress 6.4 não foram homologados nesta sessão. A confirmação de filtros de terceiros e do caminho/rotação do log no host permanece uma etapa de instalação. A trava é para processos no mesmo host; cenários com múltiplos nós requerem coordenação adicional. O código não modifica robots.txt nem o catálogo do implantador.

A retenção guarda histórico além de 90 dias, mas a tela e a habilidade desta entrega consultam até 90 dias, conforme o plano. Um comparativo anual ainda exige outra consulta. Mudanças nas regras reprocessam os arquivos disponíveis e avisam sobre dias antigos cuja fonte já desapareceu.

O bundle Git contém a importação do fonte fornecido e a evolução desta tarefa, com tags `v1.0.0` e `v1.1.0`; não reconstrói um histórico Git anterior que não veio no arquivo. Pode ser clonado com `git clone base-site-core-fator3-1.1.0.bundle base-site-core-fator3`.

**SHA-256 do ZIP instalável:** `e796f6ef4146a1d87f7584b8a345a535d26cf1244c032b8ba373e91d9835c05d`. A cópia `base-site-core-fator3.zip` tem os mesmos bytes.

## Referências técnicas usadas na revisão

A persistência do cookie e o prazo assinado seguem o fluxo de [wp_set_auth_cookie](https://developer.wordpress.org/reference/functions/wp_set_auth_cookie/) e [wp_signon](https://developer.wordpress.org/reference/functions/wp_signon/). A distinção dos tokens de uso segue as descrições oficiais de [Google-Extended](https://developers.google.com/crawling/docs/crawlers-fetchers/google-common-crawlers) e [Applebot-Extended](https://support.apple.com/en-ie/119829). As fontes de cada família HTTP ficam em `fontes/plugin/dados/robos-conhecidos.tsv`, incluindo [OpenAI](https://developers.openai.com/api/docs/bots), [Anthropic](https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler), [Perplexity](https://docs.perplexity.ai/docs/resources/perplexity-crawlers) e [Amazon](https://developer.amazon.com/amazonbot).
