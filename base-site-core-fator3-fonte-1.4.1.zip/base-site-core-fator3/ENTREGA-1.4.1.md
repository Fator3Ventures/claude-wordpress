# Base Site Core Fator3 — 1.4.1

Correções sobre a versão 1.4.0. Mantém a configuração independente do implantador, a medição de acessos, a coleta diária e a publicação automática de llms.txt, llms-full.txt e alternativas Markdown.

## Problemas corrigidos

- A hospedagem de teste entrega um robots.txt global antes de encaminhar a rota ao WordPress quando não existe arquivo na raiz do site. A nova rotina confirma a resposta pública e usa um arquivo gerenciado quando a entrega virtual não prevalece.
- O Yoast acrescenta seu sitemap em um filtro tardio. Nosso complemento agora executa depois dele e conserva uma declaração por URL, mantendo sitemaps distintos e regras de terceiros.
- O diagnóstico anterior considerava a ausência do arquivo físico suficiente para dizer ativo. Agora exige HTTP bem-sucedido, conteúdo correspondente e confirmação recente da configuração atual.
- Com permalinks simples, a rota pública recebe o contexto de robots antes do registro dos filtros condicionais, para reproduzir a política completa do WordPress e do Yoast.

## Comportamento

| Situação | Resultado |
|---|---|
| Ativar com original físico | Backup integral no banco e reserva no mesmo diretório; retirada do nome público. |
| Rota virtual entrega o conteúdo esperado | Mantém a rota virtual. |
| Hospedagem entrega outro conteúdo ou não encontra a rota | Publica um arquivo gerenciado e confere a resposta pública novamente. |
| Regras geradas mudam | Atualiza o arquivo gerenciado no próximo job, sem recapturá-lo como original. |
| Desligar a opção ou desativar o plugin | Remove somente o arquivo que ainda corresponde ao gerado e restaura o original com seus bytes e permissões. |
| Edição externa | Preserva o arquivo e o backup, com diagnóstico de conflito. Um novo ciclo explícito pode adotar o arquivo externo como original. |
| Novo ciclo sem original | Ao desligar, remove o gerenciado sem recriar um original de ciclo anterior. |
| Rede, cache ou CDN impedem a confirmação | Informa degradação e registra nova tentativa. |

O arquivo físico usa as regras obtidas numa requisição real do WordPress, incluindo filtros condicionais do Yoast. As regras exclusivas do original ficam no backup durante o uso do gerador. Nenhuma configuração global da hospedagem é alterada.

## Atualização e diagnóstico

A verificação roda no evento `f3base_robots_verificar`, via WP-Cron. O carregamento do site agenda a primeira execução e antecipa verificações após alterações reconhecidas. A revalidação normal ocorre a cada hora; falhas tentam novamente após dez minutos. Uma confirmação com mais de duas horas passa a ser considerada vencida.

WP-Cron depende de visitas ou de acionamento externo. Uma instalação que o desabilite deve executá-lo pelo agendador da hospedagem. O painel informa pendência ou vencimento quando não há confirmação atual. A opção ligada já existente é reconhecida na atualização, sem exigir desativar e reativar o plugin.

As consultas usam `wp_safe_remote_get`, somente URLs configuradas do próprio site, sem redirecionamentos nem cookies administrativos. Cada consulta tem limite de oito segundos e de tamanho. A fonte precisa responder texto válido e uma prova correspondente à requisição; a URL pública é conferida sem parâmetro de cache. O modo gerenciado permanece enquanto a opção estiver ligada; um novo ciclo explícito testa a entrega virtual novamente.

## Integridade

O backup original mantém Base64, SHA-256 e permissões. O gerenciado usa identificação própria, escrita preparada e publicação por hard link. A troca do conteúdo anterior verifica os bytes retirados antes de descartá-los. A recuperação de interrupções e a identificação de ciclo impedem perda de original e publicação por jobs antigos após desligamento e reativação.

A troca exige site único, home na raiz do domínio, raiz pública confirmada, escrita, rename e hard link. Multisite, raízes ambíguas e home em subdiretório mantêm diagnóstico sem escrita automática. A confirmação feita pelo servidor não representa teste em todas as regiões ou nós de uma CDN.

## Validação

A suíte completa fechou com **157 OK, zero FALHA, zero BLOCKED e 13 N/A**, em WordPress 7.1/PHP 8.3/SQLite, com instalação a partir do ZIP. Os N/A correspondem a cenários de fase externa e ao navegador sem Chromium disponível; não são contados como aprovados.

Os cenários novos reproduzem interceptação da hospedagem, cache divergente, filtros tardios condicionais, fonte sem prova, atualização por job, HEAD, restauração exata, conflito externo, ciclo antigo e interrupção de publicação. A bancada desabilita o disparo incidental do WP-Cron para manter cenários determinísticos; os testes verificam o agendamento e despacham o evento real explicitamente. A execução automática também foi observada na hospedagem de teste.

Os testes de mutação detectaram **16 defeitos reintroduzidos**. Uma primeira execução mostrou que a falha de banco antiga barrava apenas a gravação do identificador de ciclo. O teste foi fortalecido para recusar especificamente o backup antes do rename; a rodada positiva direcionada passou e a repetição do mutante detectou a remoção dessa proteção. O consolidado usa o resultado mais recente por mutante e preserva as duas execuções brutas.

As sondas de conteúdo do instalador passaram a selecionar o ZIP pela versão declarada no cabeçalho, evitando medir uma versão histórica deixada em dist. Todos os 60 patches de mutação da bancada passaram na conferência de aplicação.

Evidências em `dist/validacao-1.4.1/`: `verificacao.log`, `rodada.json`, `piso-publicacao.ndjson`, execuções brutas, teste dirigido de backup e respostas HTTP sintéticas.

## Conferência na hospedagem de teste

A versão foi instalada e ativada em `fator3-teste-mcp-1.dreamhosters.com` pelo canal WordPress conectado. O WP-Cron executou a verificação automaticamente, identificou a interceptação e publicou o arquivo gerenciado. O painel passou a indicar entrega HTTP confirmada, com data e modo.

A leitura HTTP externa confirmou `/robots.txt` com status 200, 234 bytes e uma única referência ao sitemap do Yoast. SHA-256: `4cec880af9fe3b380f77dddc08674473684be01370ff4ecd956547209e2f3aa1`. O conteúdo inclui o bloco real do Yoast e a identificação do arquivo gerenciado. O backup original mantém os mesmos bytes e SHA-256 `42fc0ef8b1746063dc8a16a5f41e59be64d9ac7fb41fd3172b9a7eb0da90a3ae`. A configuração de reescrita do site permaneceu idêntica.

`llms.txt` e `llms-full.txt` responderam HTTP 200 com os mesmos hashes anteriores à atualização, preservando os nove itens. A primeira tentativa externa expirou; a repetição concluiu normalmente. O próximo job de robots permaneceu agendado. Evidência consolidada: `dist/validacao-1.4.1/hospedagem.json`.

O servidor envia `Cache-Control: max-age=172800` para o arquivo físico. A atualização do arquivo ocorre no servidor; caches de terceiros podem conservar uma resposta até sua expiração. A verificação envia pedido sem cache e acusa divergência quando recebe conteúdo antigo. Alterar a política HTTP dessa hospedagem exige configuração específica do servidor; esta correção preserva sua configuração.

## Pacotes

O instalador e o pacote completo de fontes, testes, documentação, evidências e histórico Git acompanham a entrega. O manifesto SHA-256 identifica os artefatos entregues.

## Referências

- [Gerador de robots do WordPress](https://developer.wordpress.org/reference/functions/do_robots/).
- [Consultas HTTP com validação de destino](https://developer.wordpress.org/reference/functions/wp_safe_remote_get/).
- [Protocolo Robots Exclusion — RFC 9309](https://www.rfc-editor.org/rfc/rfc9309.html).
