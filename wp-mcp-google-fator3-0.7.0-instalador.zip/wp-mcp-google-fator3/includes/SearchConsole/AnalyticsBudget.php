<?php
/** Atomic, rolling local Search Analytics budget shared across consumers/connections. */
declare(strict_types=1);
namespace Fator3\McpGoogle\SearchConsole;
use Fator3\McpGoogle\{
    Auth\Credentials, Lock, Options
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class AnalyticsBudget {
    public static function principal(): string {
        if ('service_account' === Options::auth_mode()) {
            $sa = json_decode(Options::get_secret(Options::SA_JSON), true);
            $id = ['service_account', $sa['client_email'] ?? '', Options::get(Options::SA_SUBJECT, '')];
        }
        else {
            $email = strtolower((string) Options::get(Options::OAUTH_EMAIL, ''));
            $id = ['oauth', $email ?: hash('sha256', Options::get_secret(Options::OAUTH_REFRESH_TOKEN))];
        }
        return hash('sha256', wp_json_encode($id));
    }
    public static function reserve(string $property): ?\WP_Error {
        $id = hash('sha256', self::principal() . '|' . $property);
        $lock = Lock::acquire('search-analytics:' . $id, 30);
        if (!$lock) {
            return self::error('busy', 'Reserva de limite ocupada.', time()+1);
        }
        try {
            $key = 'f3_mcp_google_analytics_budget_' . $id;
            $state = Options::stored($key);
            if (!$state['success']) {
                return self::error('read', 'Falha ao ler limite local.', time()+15);
            }
            if ($state['exists'] && (!is_array($state['value']) || !is_array($state['value']['events'] ?? null) || count(array_filter($state['value']['events'],'is_int'))!==count($state['value']['events']))) {
                return self::error('read','Limite local corrompido; reserva bloqueada.',time()+15);
            }
            $now = time();
            $events = array_values(array_filter((array) ($state['value']['events'] ?? []), static fn($t) => is_int($t) && $t > $now-86400 && $t <= $now));
            sort($events);
            $minute = array_values(array_filter($events, static fn($t) => $t > $now-60));
            $min = Options::limit(Options::GSC_MINUTE);
            $day = Options::limit(Options::GSC_DAY);
            if (count($minute) >= $min || count($events) >= $day) {
                $next = max(count($minute) >= $min ? $minute[count($minute)-$min]+60 : $now, count($events) >= $day ? $events[count($events)-$day]+86400 : $now);
                return self::error('limit', 'Limite local Search Analytics atingido.', $next);
            }
            $events[] = $now;
            $saved = Options::set($key, ['events'=>$events]);
            return $saved['success'] ? null : self::error('persistence', 'Reserva de limite não confirmada.', $now+15);
        }
        finally {
            Lock::release($lock);
        }
    }
    private static function error(string $code, string $message, int $next): \WP_Error {
        return new \WP_Error('f3_google_analytics_budget_' . $code, $message, ['retryable'=>true,'retry_after_ms'=>max(1000,($next-time())*1000),'next_eligible_at'=>$next,'operation_outcome'=>'not_applied']);
    }
}
