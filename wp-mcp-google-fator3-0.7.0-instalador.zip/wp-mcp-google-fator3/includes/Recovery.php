<?php
/** Recovery fence outside the restored database and replaceable plugin tree. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Recovery {
    private const HEADER = "<?php http_response_code(404); exit; ?>\n";
    private static int $depth=0;
    private static function dir(): string {
        return WP_CONTENT_DIR.'/f3-google-state';
    }
    private static function path(): string {
        return self::dir().'/site-'.(function_exists('get_current_blog_id') ? get_current_blog_id() : 1).'.php';
    }
    private static function read() {
        $path=self::path();
        if (is_link(self::dir()) || is_link($path)) {
            return new \WP_Error('f3_google_recovery_storage','Armazenamento de recuperação inválido.');
        }
        if (!file_exists($path)) {
            return ['paused'=>false,'generation'=>'initial'];
        }
        $raw=file_get_contents($path);
        $state=is_string($raw) && str_starts_with($raw,self::HEADER) ? json_decode(substr($raw,strlen(self::HEADER)),true) : null;
        if (!is_array($state) || !is_bool($state['paused'] ?? null) || !is_string($state['generation'] ?? null)) {
            return new \WP_Error('f3_google_recovery_storage','Guarda de recuperação ilegível.');
        }
        return $state;
    }
    public static function generation(): string {
        $s=self::read();
        return is_wp_error($s) ? 'unreadable' : $s['generation'];
    }
    public static function guard(): ?\WP_Error {
        $s=self::read();
        if (is_wp_error($s)) {
            return $s;
        }
        return $s['paused'] ? new \WP_Error('f3_google_recovery_paused','Despacho pausado para restauração e reconciliação.',['retryable'=>true,'retry_after_ms'=>60000]) : null;
    }
    private static function lockfile() {
        if (is_link(self::dir()) || (!is_dir(self::dir()) && !mkdir(self::dir(),0700,true))) {
            return false;
        }
        $index=self::dir().'/index.php';
        if (!file_exists($index) && file_put_contents($index,self::HEADER,LOCK_EX)===false) {
            return false;
        }
        $path=self::path().'.lock.php';
        if (is_link($path)) {
            return false;
        }
        $fp=fopen($path,'c+');
        if ($fp && fstat($fp)['size']===0) {
            fwrite($fp,self::HEADER);
            fflush($fp);
            chmod($path,0600);
        }
        return $fp;
    }
    /** Shared lock spans an admitted operation; prepare uses a nonblocking exclusive lock. */
    public static function run(callable $callback) {
        $error=self::guard();
        if ($error) {
            return Response::fail($error);
        }
        if (self::$depth) {
            return $callback();
        }
        $fp=self::lockfile();
        if (!$fp || !flock($fp,LOCK_SH|LOCK_NB)) {
            if ($fp) {
                fclose($fp);
            }
            return Response::fail(new \WP_Error('f3_google_recovery_busy','Não foi possível admitir a execução na guarda de recuperação.'));
        }
        ++self::$depth;
        try {
            $error=self::guard();
            return $error ? Response::fail($error) : $callback();
        }
        finally {
            --self::$depth;
            flock($fp,LOCK_UN);
            fclose($fp);
        }
    }
    public static function http(callable $callback) {
        $error=self::guard();
        if ($error) {
            return $error;
        }
        $r=self::run($callback);
        return is_array($r) && isset($r['error_code']) && ($r['success'] ?? null)===false ? new \WP_Error($r['error_code'],$r['message']) : $r;
    }
    private static function write(array $s): bool {
        $path=self::path();
        if (is_link($path)) {
            return false;
        }
        $tmp=$path.'.'.bin2hex(random_bytes(8)).'.php';
        $text=self::HEADER.wp_json_encode($s);
        $f=fopen($tmp,'x');
        if (!$f) {
            return false;
        }
        chmod($tmp,0600);
        $ok=fwrite($f,$text)===strlen($text) && fflush($f);
        if (function_exists('fsync')) {
            $ok=fsync($f) && $ok;
        }
        fclose($f);
        if (!$ok || !rename($tmp,$path)) {
            @unlink($tmp);
            return false;
        }
        clearstatcache(true,$path);
        return self::read()===$s;
    }
    public static function status(): array {
        $s=self::read();
        return is_wp_error($s) ? ['paused'=>true,'error_code'=>$s->get_error_code()] : array_intersect_key($s,array_flip(['paused','generation','prepared_at','resumed_at','drained']));
    }
    public static function change(array $input): array {
        if (!current_user_can('manage_options') || !current_user_can(Options::capability())) {
            return Response::fail(new \WP_Error('f3_google_forbidden','Permissão administrativa exigida.'));
        }
        $action=$input['action'] ?? '';
        if (!in_array($action,['prepare','resume'],true)) {
            return Response::fail(new \WP_Error('f3_google_recovery_action','Use prepare ou resume.'));
        }
        $fp=self::lockfile();
        if (!$fp) {
            return Response::fail(new \WP_Error('f3_google_recovery_storage','Não foi possível preparar a guarda fora do banco.'));
        }
        // Another prepare/resume is serialized separately from running operations.
        $mutation_path=self::path().'.mutation.php';
        if (is_link($mutation_path)) {
            fclose($fp);
            return Response::fail(new \WP_Error('f3_google_recovery_storage','Guarda de mutação inválida.'));
        }
        $mutation=fopen($mutation_path,'c+');
        if (!$mutation || !flock($mutation,LOCK_EX|LOCK_NB)) {
            fclose($fp);
            if ($mutation) {
                fclose($mutation);
            }
            return Response::fail(new \WP_Error('f3_google_recovery_busy','Recuperação em alteração.'));
        }
        if (fstat($mutation)['size']===0) {
            fwrite($mutation,self::HEADER);
            fflush($mutation);
            chmod(self::path().'.mutation.php',0600);
        }
        try {
            $s=self::read();
            if (is_wp_error($s)) {
                return Response::fail($s);
            }
            if ('prepare'===$action) {
                if (!$s['paused']) {
                    $s=['paused'=>true,'generation'=>bin2hex(random_bytes(16)),'prepared_at'=>time(),'drained'=>false];
                }
                if (!self::write($s)) {
                    return Response::fail(new \WP_Error('f3_google_recovery_persistence','Pausa não confirmada.'));
                }
                if (!flock($fp,LOCK_EX|LOCK_NB)) {
                    return Response::fail(new \WP_Error('f3_google_recovery_draining','Pausa ativa; ainda há trabalho em voo. Repita prepare.'),['recovery'=>self::status()]);
                }
                $s['drained']=true;
                return self::write($s) ? Response::ok(['recovery'=>self::status(),'ready_for_restore'=>true]) : Response::fail(new \WP_Error('f3_google_recovery_persistence','Drenagem não confirmada.'));
            }
            if (!$s['paused'] || empty($s['drained']) || ($input['expected_generation'] ?? '')!==$s['generation'] || ($input['acknowledge_reconciled'] ?? false)!==true) {
                return Response::fail(new \WP_Error('f3_google_recovery_confirmation','Confirme a geração e a reconciliação do snapshot antes de retomar.'));
            }
            if (!flock($fp,LOCK_EX|LOCK_NB)) {
                return Response::fail(new \WP_Error('f3_google_recovery_draining','Ainda há execução em voo.'));
            }
            foreach (array_keys(Connections::registry()) as $cid) {
                Connections::run($cid,static fn()=>Auth\Credentials::invalidate_cache());
            }
            // A new outside-DB generation invalidates restored job contexts and token cache keys.
            $s['generation']=bin2hex(random_bytes(16));
            $s['paused']=false;
            $s['resumed_at']=time();
            return self::write($s) ? Response::ok(['recovery'=>self::status(),'restored_jobs_require_context_review'=>true]) : Response::fail(new \WP_Error('f3_google_recovery_persistence','Retomada não confirmada.'));
        }
        finally {
            flock($fp,LOCK_UN);
            fclose($fp);
            flock($mutation,LOCK_UN);
            fclose($mutation);
        }
    }
    public static function register(): void {
        Ability::register('google/recovery-status','any',['label'=>'Google: estado de recuperação','description'=>'Consulta a pausa fora do banco e a geração de execução; nenhum segredo.','callback'=>static fn()=>Response::ok(['recovery'=>self::status()])]);
        Ability::register('google/recovery','any',['label'=>'Google: preparar ou concluir recuperação','mode'=>'write','description'=>'Prepare pausa e drena antes do restore. Resume exige reconciliação e geração atual; invalida contextos restaurados.','input_schema'=>['required'=>['action'],'properties'=>['action'=>['type'=>'string','enum'=>['prepare','resume']],'expected_generation'=>['type'=>'string'],'acknowledge_reconciled'=>['type'=>'boolean']]],'callback'=>[self::class,'change']]);
    }
}
