<?php
/**
 * Serialized, verified configuration changes with optimistic revision checks.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Settings {

	public const AUTH_READY = 'f3_mcp_google_auth_ready';
	public const REVISION   = 'f3_mcp_google_configuration_revision';

	/** A digest of stored settings catches stale forms, including writes by older code. */
	public static function revision() {
		$names    = array_merge( Connections::scoped_names(), array( self::REVISION, Options::ENABLED, Options::AUDIT_LOCAL_READS, Updater::OPTION, 'f3_mcp_google_purge_on_uninstall' ), array_keys( Options::LIMITS ) );
		$snapshot = array();
		$states   = Options::snapshot( array_map( array( Options::class, 'storage_name' ), array_unique( $names ) ) );
		foreach ( array_unique( $names ) as $name ) {
			if ( Options::TOKEN_INDEX === $name ) {
				continue;
			}
			$state = $states[ Options::storage_name( $name ) ];
			if ( ! $state['success'] ) {
				return new \WP_Error( 'f3_google_option_read', 'Não foi possível ler a revisão da configuração.' );
			}
			$snapshot[ $name ] = array( $state['exists'], $state['value'] );
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- One-way digest input only; no unserialize() or object construction.
		return hash( 'sha256', Connections::id() . '|' . serialize( $snapshot ) );
	}

	/** Defaults are frozen in jobs. Validated SA key rotation keeps the principal. */
	public static function execution_revision() {
		$names    = array( self::AUTH_READY, Policy::OPTION, Connections::SERVICES, Options::GA_ENABLED, Options::ADS_ENABLED, Options::OAUTH_SCOPES, Options::ADS_LOGIN_CUSTOMER_ID, Options::ADS_API_VERSION );
		$states   = Options::snapshot( array_map( array( Options::class, 'storage_name' ), $names ) );
		$snapshot = array();
		foreach ( $names as $name ) {
			$state = $states[ Options::storage_name( $name ) ];
			if ( ! $state['success'] ) {
				return new \WP_Error( 'f3_google_option_read', 'Falha ao ler o contexto da execução.' );
			} $snapshot[ $name ] = array( $state['exists'], $state['value'] );
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- One-way digest input only; no unserialize() or object construction.
		return hash( 'sha256', serialize( array( Auth\Credentials::execution_identity(), Recovery::generation(), $snapshot ) ) );
	}

	public static function conflict(): array {
		return Response::fail(
			new \WP_Error( 'f3_google_configuration_conflict', 'A configuração mudou desde que esta tela foi aberta. Recarregue e confira os valores antes de salvar.' ),
			array(
				'persisted' => false,
				'changed'   => false,
			)
		);
	}

	public static function save( array $values, array $secrets = array(), array $deletes = array(), ?string $expected = null, ?callable $guard = null ): array {
		// The common lock also serializes site-wide settings across connections.
		$global = Lock::acquire( 'configuration:site' );
		if ( null === $global ) {
			return self::busy();
		}
		$lock = Lock::acquire( 'configuration:' . Connections::id() );
		if ( null === $lock ) {
			Lock::release( $global );
			return self::busy();
		}
		try {
			$revision = self::revision();
			if ( is_wp_error( $revision ) ) {
				return Response::fail( $revision );
			}
			if ( null !== $expected && ! hash_equals( $revision, $expected ) ) {
				return self::conflict();
			}
			// Avoid re-encrypting equal secrets: "no change" is an observable outcome.
			foreach ( $secrets as $name => $plain ) {
				$state = Options::stored( Options::storage_name( $name ) );
				if ( ! $state['success'] ) {
					return Response::fail( new \WP_Error( 'f3_google_option_read', 'Falha ao ler a credencial existente.' ) );
				}
				if ( '' === $plain ) {
					$deletes[] = $name;
					unset( $secrets[ $name ] );
					continue;
				}
				if ( $state['exists'] && null === Options::secret_problem( $name ) && hash_equals( Options::get_secret( $name ), $plain ) ) {
					unset( $secrets[ $name ] );
				}
			}
			foreach ( $values as $name => $value ) {
				$state = Options::stored( Options::storage_name( $name ) );
				if ( ! $state['success'] ) {
					return Response::fail( new \WP_Error( 'f3_google_option_read', 'Falha ao ler a configuração existente.' ) );
				}
				if ( $state['exists'] && self::equal( $state['value'], $value ) ) {
					unset( $values[ $name ] );
				}
			}
			foreach ( $deletes as $i => $name ) {
				$state = Options::stored( Options::storage_name( $name ) );
				if ( ! $state['success'] ) {
					return Response::fail( new \WP_Error( 'f3_google_option_read', 'Falha ao ler o valor a remover.' ) );
				}
				if ( ! $state['exists'] ) {
					unset( $deletes[ $i ] );
				}
			}
			if ( ! $values && ! $secrets && ! $deletes ) {
				return array(
					'success'   => true,
					'persisted' => true,
					'changed'   => false,
					'revision'  => $revision,
					'message'   => 'Nenhuma alteração necessária.',
				);
			}
			$detail  = $values[ Options::JOB_DETAIL_DAYS ] ?? Options::limit( Options::JOB_DETAIL_DAYS );
			$summary = $values[ Options::JOB_SUMMARY_DAYS ] ?? Options::limit( Options::JOB_SUMMARY_DAYS );
			if ( $summary < $detail ) {
				return Response::fail( new \WP_Error( 'f3_google_retention_order', 'Resumos e deduplicação devem durar pelo menos o prazo dos detalhes.' ) );
			}
			if ( null !== $guard ) {
				$issue = $guard();
				if ( is_wp_error( $issue ) ) {
					return Response::fail(
						$issue,
						array(
							'persisted' => false,
							'changed'   => false,
						)
					);
				}
			}
			$values[ self::REVISION ] = bin2hex( random_bytes( 16 ) );
			$result                   = Options::batch_verified( $values, $secrets, array_values( array_unique( $deletes ) ), $guard );
			if ( ! $result['success'] ) {
				return $result;
			}
			$auth_names = array_merge( array_diff( Options::secret_names(), array( Auth\Candidate::SA, Auth\Candidate::OAUTH ) ), array( Options::AUTH_MODE, Options::SA_SUBJECT, Options::OAUTH_CLIENT_ID, Connections::SERVICES ) );
			if ( array_intersect( array_keys( $values ), $auth_names ) || array_intersect( array_keys( $secrets ), $auth_names ) || array_intersect( $deletes, $auth_names ) ) {
				Auth\Credentials::invalidate_cache();
			}
			$result['changed']  = true;
			$result['revision'] = self::revision();
			if ( is_wp_error( $result['revision'] ) ) {
				return Response::fail(
					$result['revision'],
					array(
						'persisted' => true,
						'changed'   => true,
					)
				);
			}
			Audit::log(
				'configuration:saved',
				Connections::id(),
				array( 'status' => 'ok' ),
				array(
					'revision'  => $result['revision'],
					'change_id' => $values[ self::REVISION ],
				)
			);
			$result['audit_marker']            = Audit::last_marker();
			$result['configuration_change_id'] = $values[ self::REVISION ];
			if ( null !== Audit::last_failure() ) {
				$result['audit_warning'] = Audit::last_failure();
			}
			return $result;
		} finally {
			Lock::release( $lock );
			Lock::release( $global );
		}
	}
	private static function equal( $a, $b ): bool {
		return is_scalar( $a ) && is_scalar( $b ) ? (string) $a === (string) $b : $a === $b;
	}
	private static function busy(): array {
		return Response::fail(
			new \WP_Error( 'f3_google_configuration_busy', 'Outra configuração está sendo salva. Aguarde e tente novamente.' ),
			array(
				'persisted' => false,
				'changed'   => false,
			)
		);
	}
}
