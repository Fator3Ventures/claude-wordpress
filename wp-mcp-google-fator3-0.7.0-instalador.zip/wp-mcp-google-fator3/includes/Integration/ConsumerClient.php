<?php
/** Public client bound by object identity to a registered consumer. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ConsumerClient {
    public function query(array $input): array {
        return ServiceApi::query($this, $input);
    }
    public function status(): array {
        return ServiceApi::client_status($this);
    }
}
