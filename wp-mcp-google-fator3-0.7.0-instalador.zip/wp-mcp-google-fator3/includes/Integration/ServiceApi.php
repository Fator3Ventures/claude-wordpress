<?php
/** Public, versioned Search Console reader for registered local plugins. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
use Fator3\McpGoogle\{
    Ability, Audit, Auth\Credentials, Automation\Execution, Connections, Crypto, Gate, Http\GoogleClient, Options, Policy, Records, Response, Settings, Storage\Admission, Storage\Migration
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ServiceApi {
    public const CONTRACT = 'search-console-reader/1.0.0';
    public const VERSION = '1.0.0';
    public const CAPABILITY = 'gsc.page-day.read';
    public const GRANTS = 'f3_mcp_google_consumer_grants';
    public const MAX_LIMIT = 5000;
    public const MAX_BUDGET_MS = 20000;
    private static array $consumers = [];
    public static function init(): void {
        add_action('plugins_loaded', [self::class,'discover'], 30);
    }
    public static function discover(): void {
        do_action('f3_mcp_google_register_consumers', new self(), self::CONTRACT);
    }
    public static function capabilities(): array {
        return ['contract'=>self::CONTRACT,'contract_version'=>self::VERSION,'plugin_version'=>F3_MCP_GOOGLE_VERSION,'registration_hook'=>'f3_mcp_google_register_consumers','capabilities'=>[self::CAPABILITY], 'input_schema'=>self::schema(), 'max_budget_ms'=>self::MAX_BUDGET_MS, 'return_margin_ms'=>2000,'limit_max'=>min(self::MAX_LIMIT,Options::max_rows()),'calendar'=>'America/Los_Angeles','all_rows_guaranteed'=>false];
    }
    public static function schema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['contract_version','property','consumer_revision','date','run_id','trigger','budget_ms'], 'properties'=>[
                'contract_version'=>['type'=>'string','enum'=>[self::VERSION]],
                'property'=>['type'=>'string','minLength'=>1,'maxLength'=>512],
                'consumer_revision'=>['type'=>'string','minLength'=>1,'maxLength'=>128],
                'date'=>['type'=>'string','pattern'=>'^\\d{4}-\\d{2}-\\d{2}$'],
                'limit'=>['type'=>'integer','minimum'=>1,'maximum'=>min(self::MAX_LIMIT,Options::max_rows()),'default'=>min(1000,Options::max_rows())],
                'cursor'=>['type'=>['string','null'],'maxLength'=>4096],
                'run_id'=>['type'=>'string','minLength'=>1,'maxLength'=>100,'pattern'=>'^[A-Za-z0-9._:-]+$'],
                'trigger'=>['type'=>'string','enum'=>['cli','http_cron','manual']],
                'budget_ms'=>['type'=>'integer','minimum'=>1,'maximum'=>self::MAX_BUDGET_MS],
            ]];
    }
    /** $configuration returns {property:string,revision:string,ready:bool}. */
    public static function register_consumer(string $id, string $version, string $contract, callable $configuration) {
        if (!preg_match('/^[a-z][a-z0-9-]{1,79}$/D',$id) || !preg_match('/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/D',$version)) {
            return new \WP_Error('f3_google_consumer_input','Identidade/versão do consumidor inválida.');
        }
        if ($contract !== self::CONTRACT) {
            return new \WP_Error('f3_google_consumer_contract','Contrato de consumidor incompatível.');
        }
        if (isset(self::$consumers[$id])) {
            return new \WP_Error('f3_google_consumer_duplicate','Consumidor já registrado.');
        }
        $client = new ConsumerClient();
        self::$consumers[$id] = ['id'=>$id,'version'=>$version,'configuration'=>$configuration,'client'=>$client];
        return $client;
    }
    private static function find(ConsumerClient $client): ?array {
        foreach (self::$consumers as $consumer) {
            if ($consumer['client'] === $client) {
                return $consumer;
            }
        }
        return null;
    }
    private static function config(array $consumer) {
        try {
            $c = ($consumer['configuration'])();
        }
        catch (\Throwable $e) {
            return new \WP_Error('f3_google_consumer_configuration','Consumidor não forneceu configuração válida.');
        }
        if (!is_array($c) || !is_bool($c['ready'] ?? null)) {
            return new \WP_Error('f3_google_consumer_configuration','Callback exige propriedade, revisão e prontidão.');
        }
        if (!$c['ready']) {
            return new \WP_Error('f3_google_consumer_not_ready','Estrutura/configuração do consumidor ainda não está pronta.', ['retryable'=>true,'retry_after_ms'=>15000]);
        }
        if (!is_string($c['property'] ?? null) || !self::valid_property($c['property']) || !is_string($c['revision'] ?? null) || strlen($c['revision'])<1 || strlen($c['revision'])>128) {
            return new \WP_Error('f3_google_consumer_configuration','Propriedade ou revisão inválida no consumidor.');
        }
        return array_intersect_key($c,array_flip(['property','revision','ready']));
    }
    public static function valid_property(string $p): bool {
        if (strlen($p)>512 || preg_match('/[\x00-\x20]/',$p)) {
            return false;
        }
        if (str_starts_with($p,'sc-domain:')) {
            return (bool) preg_match('/^sc-domain:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9-]{2,63}$/Di',$p);
        }
        $url = wp_parse_url($p);
        return is_array($url) && in_array($url['scheme'] ?? '',['http','https'],true) && !empty($url['host']) && !isset($url['user']) && !isset($url['pass']) && !isset($url['query']) && !isset($url['fragment']);
    }
    private static function grants() {
        $r = Options::stored(Options::storage_name(self::GRANTS));
        if (!$r['success'] || ($r['exists'] && !is_array($r['value']))) {
            return new \WP_Error('f3_google_consumer_grants_read','Autorizações ilegíveis.');
        }
        return $r['value'] ?? [];
    }
    private static function guard(array $consumer, array $configuration, string $revision, array $grant): ?\WP_Error {
        $recovery = \Fator3\McpGoogle\Recovery::guard();
        if ($recovery) {
            return $recovery;
        }
        if (!Options::is_enabled()) {
            return new \WP_Error('f3_google_disabled','Google desativado.');
        }
        if (Migration::paused() || (Transition::status()['state'] ?? '') !== 'completed') {
            return new \WP_Error('f3_google_consumer_transition','Transição/armazenamento pendente.', ['retryable'=>true,'retry_after_ms'=>15000]);
        }
        if (!Connections::enabled('gsc')) {
            return new \WP_Error('f3_google_connector_off','Search Console desativado.');
        }
        $grants = self::grants();
        if (is_wp_error($grants)) {
            return $grants;
        }
        if (($grants[$consumer['id']] ?? null) !== $grant || empty($grant['enabled']) || ($grant['capability'] ?? '') !== self::CAPABILITY) {
            return new \WP_Error('f3_google_consumer_unauthorized','Consumidor sem concessão vigente nesta conexão.');
        }
        $now = self::config($consumer);
        if (is_wp_error($now)) {
            return $now;
        }
        if ($now !== $configuration) {
            return new \WP_Error('f3_google_consumer_changed','Configuração do consumidor mudou; reinicie a página.');
        }
        $current = Settings::execution_revision();
        if (is_wp_error($current)) {
            return $current;
        }
        if (!hash_equals($revision,$current)) {
            return new \WP_Error('f3_google_context_changed','Credencial ou política mudou durante a consulta.');
        }
        if (!Policy::permitted('gsc',$configuration['property'])) {
            return new \WP_Error('f3_google_policy','Propriedade fora da política da conexão.');
        }
        $credentials = Credentials::current();
        return is_wp_error($credentials) ? $credentials : null;
    }
    public static function query(ConsumerClient $client, array $input): array {
        $consumer = self::find($client);
        if (!$consumer) {
            return self::failure(new \WP_Error('f3_google_consumer_unregistered','Cliente não registrado.'));
        }
        $error = self::validate_input($input);
        if ($error) {
            return self::failure($error);
        }
        return Execution::run(static fn()=>self::authorized_query($consumer,$input),$input['budget_ms']/1000);
    }
    private static function authorized_query(array $consumer,array $input): array {
        $cfg = self::config($consumer);
        if (is_wp_error($cfg)) {
            return self::failure($cfg);
        }
        if ($input['property'] !== $cfg['property'] || $input['consumer_revision'] !== $cfg['revision']) {
            return self::failure(new \WP_Error('f3_google_consumer_property','Consulta deve usar propriedade e revisão atuais do consumidor.'));
        }
        // The client cannot select an arbitrary connection: one explicit grant per consumer.
        $matches = [];
        foreach (array_keys(Connections::registry()) as $cid) {
            $g = Connections::run($cid,static fn()=>self::grants());
            if (is_wp_error($g)) {
                return self::failure($g);
            }
            if (!empty($g[$consumer['id']]['enabled'])) {
                $matches[$cid] = $g[$consumer['id']];
            }
        }
        if (count($matches)!==1) {
            return self::failure(new \WP_Error('f3_google_consumer_unauthorized','Autorize o consumidor em exatamente uma conexão.'));
        }
        $cid = key($matches);
        $grant = $matches[$cid];
        return Connections::run($cid, static function() use ($consumer,$cfg,$input,$grant): array {
            $revision = Settings::execution_revision();
            if (is_wp_error($revision)) {
                return self::failure($revision);
            }
            $guard = static fn()=>self::guard($consumer,$cfg,$revision,$grant);
            $error = $guard();
            if ($error) {
                return self::failure($error);
            }
            return Admission::run('plugin:gsc.page-day.read', static fn()=>Execution::run(
                    static fn()=>self::page($consumer,$cfg,$input,$revision,$grant,$guard), $input['budget_ms']/1000, $guard
                ));
            });
    }
    private static function validate_input(array $i): ?\WP_Error {
        $schema = self::schema();
        if (array_diff(array_keys($i),array_keys($schema['properties'])) || array_diff($schema['required'],array_keys($i))) {
            return new \WP_Error('f3_google_consumer_input','Parâmetros ausentes ou não permitidos.');
        }
        if (($i['contract_version'] ?? '') !== self::VERSION) {
            return new \WP_Error('f3_google_consumer_contract','Versão de contrato incompatível.');
        }
        foreach (['property','consumer_revision','date','run_id','trigger'] as $k) {
            if (!is_string($i[$k])) {
                return new \WP_Error('f3_google_consumer_input','Tipo inválido: '.$k);
            }
        }
        if (!in_array($i['trigger'],['cli','http_cron','manual'],true) || !preg_match('/^[A-Za-z0-9._:-]{1,100}$/D',$i['run_id']) || !is_int($i['budget_ms']) || $i['budget_ms']<1 || $i['budget_ms']>self::MAX_BUDGET_MS || (isset($i['limit']) && (!is_int($i['limit']) || $i['limit']<1 || $i['limit']>min(self::MAX_LIMIT,Options::max_rows()))) || (isset($i['cursor']) && (!is_string($i['cursor']) || strlen($i['cursor'])>4096))) {
            return new \WP_Error('f3_google_consumer_input','Origem, prazo, limite ou cursor inválido.');
        }
        $d = \DateTimeImmutable::createFromFormat('!Y-m-d',$i['date'],new \DateTimeZone('America/Los_Angeles'));
        if (!$d || $d->format('Y-m-d') !== $i['date'] || $d >= new \DateTimeImmutable('today',new \DateTimeZone('America/Los_Angeles'))) {
            return new \WP_Error('f3_google_consumer_date','Informe um dia passado válido no calendário Search Console.');
        }
        return null;
    }
    private static function page(array $consumer,array $cfg,array $i,string $revision,array $grant,callable $guard): array {
        $limit = $i['limit'] ?? min(1000,Options::max_rows());
        $start = 0;
        $binding = [$consumer['id'],Connections::id(),$cfg['property'],$cfg['revision'],$i['date'],$limit,$revision,$grant['revision']];
        if (!empty($i['cursor'])) {
            $plain = Crypto::decrypt($i['cursor']);
            $c = is_string($plain) ? json_decode($plain,true) : null;
            if (!is_array($c) || ($c['binding'] ?? null) !== $binding || ($c['expires'] ?? 0) < time() || !is_int($c['start'] ?? null) || $c['start']<0) {
                return self::failure(new \WP_Error('f3_google_consumer_cursor','Cursor inválido, expirado ou de outro contexto.'));
            }
            $start = $c['start'];
        }
        $body = ['startDate'=>$i['date'],'endDate'=>$i['date'],'dimensions'=>['date','page'],'type'=>'web','dataState'=>'final','aggregationType'=>'auto','rowLimit'=>$limit,'startRow'=>$start];
        $request = Records::id();
        $ctx = ['actor'=>['type'=>'plugin','id'=>$consumer['id'],'version'=>$consumer['version']], 'run_id'=>$i['run_id'],'trigger'=>$i['trigger'],'request_id'=>$request,'property'=>$cfg['property'],'consumer_revision'=>$cfg['revision'],'body'=>$body,'http_attempts'=>0,'query_dispatched'=>false];
        return Context::run($ctx, static function() use ($cfg,$i,$body,$request,$binding,$start,$limit,$guard): array {
            $common = ['contract_version'=>self::VERSION,'request_id'=>$request,'connection_id'=>Connections::id(),'property'=>$cfg['property'],'consumer_revision'=>$cfg['revision'],'date'=>$i['date'],'run_id'=>$i['run_id']];
            $deadline = Execution::check();
            if ($deadline) {
                return self::failure($deadline,$common);
            }
            $before = Audit::append('plugin:gsc.page-day.begin',$cfg['property'],['mode'=>'read','status'=>'started']);
            if (!$before['success']) {
                return self::failure(new \WP_Error('f3_google_audit_persistence','Consulta suspensa: auditoria indisponível.'),$common);
            }
            $raw = GoogleClient::post(GoogleClient::HOST_GOOGLE.'/webmasters/v3/sites/'.rawurlencode($cfg['property']).'/searchAnalytics/query',$body,[
                    'connector'=>'gsc','mode'=>'read','operation_id'=>'webmasters.searchanalytics.query','scopes'=>['https://www.googleapis.com/auth/webmasters.readonly'],'retries'=>0,
                ]);
            $context = Context::current();
            $common['remote_dispatched'] = !empty($context['query_dispatched']);
            $common['http_attempts'] = $context['http_attempts'];
            $error = is_wp_error($raw) ? $raw : $guard();
            $rows = [];
            if (!$error) {
                if ((array_key_exists('responseAggregationType',$raw) || !empty($raw['rows'])) && ($raw['responseAggregationType'] ?? null) !== 'byPage') {
                    $error = new \WP_Error('f3_google_consumer_response','Agregação inesperada; esperado por página.');
                }
                if (array_key_exists('rows',$raw) && !is_array($raw['rows'])) {
                    $error = new \WP_Error('f3_google_consumer_response','Linhas inválidas.');
                }
                foreach (is_array($raw['rows'] ?? null) ? $raw['rows'] : [] as $r) {
                    if (!is_array($r) || !is_array($r['keys'] ?? null) || count($r['keys'])!==2 || $r['keys'][0]!==$i['date'] || !is_string($r['keys'][1]) || (!filter_var($r['keys'][1],FILTER_VALIDATE_URL) || !in_array(wp_parse_url($r['keys'][1],PHP_URL_SCHEME),['https','http'],true))) {
                        $error = new \WP_Error('f3_google_consumer_response','Dimensões inválidas.');
                        break;
                    }
                    foreach (['clicks','impressions','ctr','position'] as $n) {
                        if (!isset($r[$n]) || !is_numeric($r[$n]) || !is_finite((float)$r[$n]) || $r[$n]<0) {
                            $error = new \WP_Error('f3_google_consumer_response','Métricas inválidas.');
                            break 2;
                        }
                    }
                    $rows[] = ['date'=>$r['keys'][0],'page'=>$r['keys'][1],'clicks'=>(float)$r['clicks'],'impressions'=>(float)$r['impressions'],'ctr'=>(float)$r['ctr'],'position'=>(float)$r['position']];
                }
                if (count($rows)>$limit) {
                    $error = new \WP_Error('f3_google_consumer_response','Resposta excedeu o limite solicitado.');
                }
            }
            $next = null;
            $full = count($rows)===$limit;
            $ceiling = $start+count($rows)>=50000;
            if (!$error && $full && !$ceiling) {
                $next = Crypto::encrypt(wp_json_encode(['binding'=>$binding,'start'=>$start+count($rows),'expires'=>time()+86400]));
                if (!$next) {
                    $error = new \WP_Error('f3_google_crypto_encrypt','Não foi possível criar cursor.');
                }
            }
            $result = $error ? self::failure($error,$common) : Response::ok($common+['extracted_at'=>time(),'rows'=>$rows,'next_cursor'=>$next,'coverage'=>[
                        'limit'=>$limit,'returned_rows'=>count($rows),'pagination_complete'=>!$full,'truncated'=>$full,'truncation_reason'=>$full ? ($ceiling ? 'api_daily_row_limit' : 'page_pending') : null,'all_rows_guaranteed'=>false,'calendar'=>'America/Los_Angeles','data_state'=>'final','dimensions'=>['date','page'],'type'=>'web','aggregation'=>'byPage','start_row'=>$start,'filters'=>[],
                    ]]);
            $after = Audit::append('plugin:gsc.page-day.end',$cfg['property'],['mode'=>'read','status'=>$result['success'] ? 'completed' : 'failed','rows'=>count($rows),'error_code'=>$result['error_code'] ?? null]);
            if (!$after['success']) {
                return self::failure(new \WP_Error('f3_google_audit_incomplete','Consulta concluída; registro final não confirmado. Não avance o cursor.'),$common+['query_result'=>$result,'audit_success'=>false]);
            }
            $result['audit_success'] = true;
            $saved = Options::set('f3_mcp_google_consumer_last_'.Connections::id().'_'.hash('sha256',Context::current()['actor']['id']), ['at'=>time(),'success'=>$result['success'],'error_code'=>$result['error_code'] ?? null,'request_id'=>$request,'run_id'=>$i['run_id'],'rows'=>count($rows)]);
            if (!$saved['success']) {
                return self::failure(new \WP_Error('f3_google_consumer_state','Último atendimento não confirmado.'),$common+['query_result'=>$result]);
            }
            return $result;
            });
    }
    private static function failure(\WP_Error $e, array $extra=[]): array {
        $d = (array)$e->get_error_data();
        $result = Response::fail($e,$extra+['contract_version'=>self::VERSION,'retryable'=>(bool)($d['retryable'] ?? false),'retry_after_ms'=>$d['retry_after_ms'] ?? (isset($d['retry_after']) ? (int)$d['retry_after']*1000 : null),'next_eligible_at'=>$d['next_eligible_at'] ?? null,'remote_dispatched'=>false]);
        // Preserve the service correlation; an HTTP request id remains in details.
        if (isset($extra['request_id'])) {
            $result['request_id']=$extra['request_id'];
        }
        return $result;
    }
    public static function client_status(ConsumerClient $client): array {
        $c = self::find($client);
        return $c ? self::status($c['id']) : self::failure(new \WP_Error('f3_google_consumer_unregistered','Cliente não registrado.'));
    }
    public static function status(?string $only=null): array {
        $g = self::grants();
        $items=[];
        foreach (self::$consumers as $id=>$c) {
            if ($only!==null && $id!==$only) {
                continue;
            }
            $cfg=self::config($c);
            $items[]=['id'=>$id,'version'=>$c['version'],'configuration'=>is_wp_error($cfg) ? ['ready'=>false,'error_code'=>$cfg->get_error_code()] : $cfg,'grant'=>is_wp_error($g) ? null : ($g[$id] ?? null),'last_service'=>Options::get('f3_mcp_google_consumer_last_'.Connections::id().'_'.hash('sha256',$id),null)];
        }
        return ['contract'=>self::CONTRACT,'connection_id'=>Connections::id(),'consumers'=>$items,'grants_error'=>is_wp_error($g) ? $g->get_error_code() : null,'transition'=>Transition::status(),'google_enabled'=>Options::is_enabled(),'configured'=>Credentials::is_configured()];
    }
    public static function configure(array $input): array {
        if (!current_user_can('manage_options') || !current_user_can(Options::capability())) {
            return self::failure(new \WP_Error('f3_google_forbidden','Permissão administrativa exigida.'));
        }
        $id=$input['consumer_id'] ?? '';
        $enabled=$input['enabled'] ?? null;
        if (!is_string($id) || !isset(self::$consumers[$id]) || !is_bool($enabled) || !is_string($input['expected_revision'] ?? null)) {
            return self::failure(new \WP_Error('f3_google_consumer_input','Consumidor, enabled e expected_revision são obrigatórios.'));
        }
        // Single site lock prevents two simultaneous grants on different connections.
        $lock=\Fator3\McpGoogle\Lock::acquire('consumer-grants',30);
        if (!$lock) {
            return self::failure(new \WP_Error('f3_google_consumer_busy','Concessão em atualização.'));
        }
        try {
            if ($enabled) {
                foreach (array_keys(Connections::registry()) as $cid) {
                    if ($cid===Connections::id()) {
                        continue;
                    }
                    $other=Connections::run($cid,static fn()=>self::grants());
                    if (is_wp_error($other)) {
                        return self::failure($other);
                    }
                    if (!empty($other[$id]['enabled'])) {
                        return self::failure(new \WP_Error('f3_google_consumer_connection','Revogue a concessão na outra conexão antes de transferir.'));
                    }
                }
            }
            $grants=self::grants();
            if (is_wp_error($grants)) {
                return self::failure($grants);
            }
            if (!isset($grants[$id]) || $grants[$id]['enabled']!==$enabled) {
                $grants[$id]=['enabled'=>$enabled,'capability'=>self::CAPABILITY,'revision'=>bin2hex(random_bytes(16)),'at'=>time()];
            }
            return Settings::save([self::GRANTS=>$grants],[],[],$input['expected_revision']) + ['integration'=>self::status()];
        }
        finally {
            \Fator3\McpGoogle\Lock::release($lock);
        }
    }
    public static function register(): void {
        Ability::register('google/integration-status','any',['label'=>'Google: integração com plugins','description'=>'Contrato, consumidores registrados, concessões e último atendimento. Consulta local.','callback'=>static fn()=>Response::ok(self::status())]);
        Ability::register('google/configure-consumer','any',['label'=>'Google: autorizar consumidor','description'=>'Concede ou revoga leitura Search Console para plugin registrado nesta conexão. A propriedade é mantida pelo consumidor.','mode'=>'write','input_schema'=>['required'=>['consumer_id','enabled','expected_revision'],'properties'=>['consumer_id'=>['type'=>'string'],'enabled'=>['type'=>'boolean'],'expected_revision'=>['type'=>'string']]],'callback'=>[self::class,'configure']]);
        Ability::register('google/complete-transition','any',['label'=>'Google: concluir transição 0.6.0','description'=>'Desliga a importação antiga e preserva seu checkpoint; confirmação de drenagem não executa coleta.','mode'=>'write','input_schema'=>['properties'=>['acknowledge_drained'=>['type'=>'boolean','default'=>false]]],'callback'=>static fn($i)=>current_user_can('manage_options') ? Transition::advance(!empty($i['acknowledge_drained'])) : self::failure(new \WP_Error('f3_google_forbidden','Permissão administrativa exigida.'))]);
    }
}
