<?php
/** Restricted plugin-reader context; never establishes a remote user's permissions. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Context {
    private static array $stack = [];
    public static function current(): ?array {
        return self::$stack ? end(self::$stack) : null;
    }
    public static function run(array $context, callable $callback) {
        self::$stack[] = $context;
        try {
            return $callback();
        }
        finally {
            array_pop(self::$stack);
        }
    }
    public static function dispatched(string $url): void {
        if (!self::$stack) {
            return;
        }
        $index=count(self::$stack)-1;
        ++self::$stack[$index]['http_attempts'];
        if (str_contains($url,'/searchAnalytics/query')) {
            self::$stack[$index]['query_dispatched']=true;
        }
    }
    public static function audit_attempt(string $url, string $phase, $response=null): ?\WP_Error {
        $c=self::current();
        if (!$c) {
            return null;
        }
        $token=$url==='https://oauth2.googleapis.com/token';
        $r=\Fator3\McpGoogle\Audit::append('plugin:http.'.$phase,$c['property'],[
                'mode'=>'read','endpoint'=>$token ? 'token' : 'searchanalytics',
                'attempt'=>$c['http_attempts']+($phase==='begin' ? 1 : 0),
                'status'=>$phase==='begin' ? 'started' : (is_wp_error($response) ? 'network_error' : (string)wp_remote_retrieve_response_code($response)),
            ]);
        return $r['success'] ? null : new \WP_Error($phase==='begin' ? 'f3_google_audit_persistence' : 'f3_google_audit_incomplete','Registro da tentativa HTTP não confirmado.');
    }
    public static function guard(string $method, string $url, ?array $body, array $opts): ?\WP_Error {
        $c = self::current();
        if (!$c) {
            return null;
        }
        if ($url === 'https://oauth2.googleapis.com/token' && strtoupper($method) === 'POST' && ($opts['auth'] ?? true) === false) {
            return null;
        }
        $expected = 'https://www.googleapis.com/webmasters/v3/sites/' . rawurlencode($c['property']) . '/searchAnalytics/query';
        if ($url !== $expected || strtoupper($method) !== 'POST' || ($opts['mode'] ?? '') !== 'read' || $body !== $c['body']) {
            return new \WP_Error('f3_google_consumer_scope', 'O consumidor só pode consultar a página Search Console autorizada.');
        }
        return null;
    }
}
