<?php
/** Inert, verified checkpoint when retiring the 0.6.0 Core importer. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
use Fator3\McpGoogle\{
    Connections, Lock, Options, Records, Response, Storage\Migration
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Transition {
    public const LEGACY = 'f3_mcp_google_gsc_import';
    public const OPTION = 'f3_mcp_google_transition_070';
    public static function status(): array {
        $s = Options::stored(Options::storage_name(self::OPTION));
        if (!$s['success'] || ($s['exists'] && (!is_array($s['value']) || !is_string($s['value']['state'] ?? null)))) {
            return ['state'=>'failed','error_code'=>'f3_google_option_read'];
        }
        return $s['value'] ?? ['state'=>'pending'];
    }
    public static function init(): void {
        foreach (array_keys(Connections::registry()) as $id) {
            Connections::run($id, static fn()=>self::advance());
        }
    }
    public static function advance(bool $acknowledge_drained = false): array {
        if (Migration::paused()) {
            return Response::fail(new \WP_Error('f3_google_storage_migrating','Conclua a migração de armazenamento antes da transição.'));
        }
        $prior = self::status();
        if (isset($prior['error_code'])) {
            return Response::fail(new \WP_Error($prior['error_code'],'Transição armazenada ilegível; verifique antes de continuar.'));
        }
        if (($prior['state'] ?? '') === 'completed') {
            return Response::ok(['transition'=>$prior]);
        }
        // Inspect before acquiring: an expired lease is not evidence that old PHP stopped.
        $dailyKey = 'f3_mcp_google_lock_' . hash('sha256', 'gsc-daily:' . Connections::id());
        $lease = Options::stored($dailyKey);
        if (!$lease['success']) {
            return Response::fail(new \WP_Error('f3_google_option_read','Não foi possível verificar o importador antigo.'));
        }
        if ($lease['exists'] && (!$acknowledge_drained || ($lease['value']['expires'] ?? PHP_INT_MAX) > time())) {
            return Response::fail(new \WP_Error('f3_google_transition_drain','Aguarde a drenagem do processo antigo; lease expirado exige confirmação operacional.'), ['transition'=>['state'=>'waiting_for_drain']]);
        }
        $lock = Lock::acquire('gsc-daily:' . Connections::id(), 60);
        if (!$lock) {
            return Response::fail(new \WP_Error('f3_google_transition_busy','Transição ocupada.'));
        }
        try {
            $old = Options::stored(Options::storage_name(self::LEGACY));
            if (!$old['success'] || ($old['exists'] && !is_array($old['value']))) {
                return Response::fail(new \WP_Error('f3_google_option_read','Configuração antiga ilegível.'));
            }
            $config = is_array($old['value'] ?? null) ? $old['value'] : [];
            $checkpoint = Records::get('gscdaily',Connections::id());
            $snapshot = $prior['snapshot'] ?? [
                'source_version'=>'0.6.0','connection_id'=>Connections::id(),'enabled'=>!empty($config['enabled']),
                'configuration'=>array_intersect_key($config,array_flip(['enabled','site_url','start_date'])),
                'checkpoint'=>array_intersect_key($checkpoint ?? [],array_flip(['status','next_run','last_checked_day','last_imported_day','cursor','date'])),
                'coverage_confirmed'=>false,'at'=>time(),
            ];
            $values = [self::OPTION=>['state'=>'completed','completed_at'=>time(),'snapshot'=>$snapshot]];
            if ($old['exists']) {
                $values[self::LEGACY] = array_replace($config,['enabled'=>false]);
            }
            return Options::batch_verified($values) + ['transition'=>$values[self::OPTION]];
        }
        catch (\Throwable $e) {
            return Response::fail(new \WP_Error('f3_google_transition_read','Checkpoint antigo ilegível.'));
        }
        finally {
            Lock::release($lock);
        }
    }
}
