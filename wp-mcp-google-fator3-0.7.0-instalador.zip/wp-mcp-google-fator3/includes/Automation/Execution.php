<?php
/**
 * One deadline and dispatch fence shared by token, discovery and API requests.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Execution {

	private static array $stack = array();
	public static function run( callable $callback, float $seconds = 20, ?callable $guard = null ) {
		$parent = self::$stack ? end( self::$stack ) : null;
		$end    = (hrtime(true) / 1000000000) + min( 20, max( 0, $seconds ) );
		if ( $parent ) {
			$end = min( $end, $parent['end'] );
		}
		self::$stack[] = array(
			'end'   => $end,
			'guard' => $guard ?? ( $parent['guard'] ?? null ),
		);
		try {
			return $callback();
		} finally {
			array_pop( self::$stack );
		}
	}
	public static function active(): bool {
		return (bool) self::$stack;
	}
	public static function remaining(): float {
		return self::$stack ? max( 0, end( self::$stack )['end'] - (hrtime(true) / 1000000000) - 2 ) : INF;
	}
	public static function check( bool $dispatch = false, bool $write = false ): ?\WP_Error {
		if ( self::remaining() < 1 ) {
			return new \WP_Error(
				'f3_google_deadline',
				'Orçamento da passagem esgotado; continue o mesmo job.',
				array(
					'retryable'         => true,
					'retry_after'       => 1,
					'operation_outcome' => 'not_applied',
				)
			);
		}
		$frame = self::$stack ? end( self::$stack ) : null;
		if ( $dispatch && isset( $frame['guard'] ) ) {
			$r = ( $frame['guard'] )( $write );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		return null;
	}
}
