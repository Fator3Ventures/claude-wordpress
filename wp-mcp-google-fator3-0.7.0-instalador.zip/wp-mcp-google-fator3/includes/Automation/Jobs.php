<?php
/**
 * Persistent bounded jobs. Writes interrupted in flight are never replayed automatically.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{
	Ability, Connections, Gate, Lock, Options, Preflight, Records, Response, SearchConsole\Workflow, Sheets\Export, Unified\Query
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Jobs {

	public const TASKS = array( 'inspect-urls', 'query', 'export', 'sitemap', 'report', 'preflight' );
	public const HOOK  = 'f3_mcp_google_jobs_tick';
	public static function init(): void {
		add_action( self::HOOK, array( self::class, 'tick' ) );
		add_filter(
			// phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- One-minute bounded worker; cron only schedules while local work exists, with leases and item/time budgets.
			'cron_schedules',
			static function ( array $schedules ): array {
				$schedules['f3_google_minute'] = array(
					'interval' => 60,
					'display'  => 'MCP Google: um minuto',
				);
				return $schedules;
			}
		);
		// Hook registration does not hydrate jobs on public requests. Creation schedules work.
		if ( function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( self::HOOK ) && Records::has_work() ) {
			self::schedule_tick();
		}
	}
	public static function schedule_tick(): void {
		if ( function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( self::HOOK ) ) {
			$scheduled = wp_schedule_event( time() + 60, 'f3_google_minute', self::HOOK, array(), true );
			Options::set(
				'f3_mcp_google_cron_schedule',
				array(
					'at'         => time(),
					'success'    => true === $scheduled,
					'error_code' => is_wp_error( $scheduled ) ? $scheduled->get_error_code() : ( true === $scheduled ? null : 'f3_google_cron_schedule_failed' ),
				)
			);
		}
	}
	public static function create( array $input ): array {
		$lock = Lock::acquire( 'queue-admission', 60 );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_queue_busy', 'Admissão de tarefas ocupada.' ) );
		}
		try {
			return self::create_locked( $input );
		} finally {
			Lock::release( $lock );
		}
	}
	private static function create_locked( array $input ): array {
		if ( \Fator3\McpGoogle\Storage\Migration::paused() ) {
			return Response::fail( new \WP_Error( 'f3_google_storage_paused', 'Fila pausada para migração.' ) );
		}
		$context = Context::capture();
		if ( is_wp_error( $context ) ) {
			return Response::fail( $context );
		}
		$task   = $input['task'] ?? '';
		$params = $input['parameters'] ?? array();
		if ( ! in_array( $task, self::TASKS, true ) || ! is_array( $params ) || strlen( (string) wp_json_encode( $params ) ) > 262144 ) {
			return Response::fail( new \WP_Error( 'f3_google_job_input', 'Tarefa ou parâmetros inválidos; máximo 256 KiB.' ) );
		}
		if ( 'inspect-urls' === $task ) {
			$urls = $params['urls'] ?? null;
			if ( ! is_array( $urls ) || ! $urls || count( $urls ) > 500 ) {
				return Response::fail( new \WP_Error( 'f3_google_job_urls', 'Informe entre 1 e 500 URLs.' ) );
			}
			$site = (string) ( $params['site_url'] ?? Options::get( Connections::BINDINGS, array() )['gsc_site_url'] ?? '' );
			foreach ( $urls as $url ) {
				if ( ! is_string( $url ) || ! Workflow::belongs( $url, $site ) ) {
					return Response::fail( new \WP_Error( 'f3_google_job_urls', 'Todas as URLs devem pertencer à propriedade.' ) );
				}
			}
			$params['site_url'] = $site;
			$params['urls']     = array_values( array_unique( $urls ) );
		}
		// Credentials are configured only through the panel; queues never retain secrets.
		if ( self::contains_secret( $params ) ) {
			return Response::fail( new \WP_Error( 'f3_google_job_secret', 'Não envie credenciais em parâmetros de jobs.' ) );
		}
		// Deduplicate the submitted intention before resolving dates or mutable defaults.
		$actor = get_current_user_id();
		$key   = (string) ( $input['idempotency_key'] ?? '' );
		if ( strlen( $key ) > 200 ) {
			return Response::fail( new \WP_Error( 'f3_google_job_key', 'idempotency_key aceita até 200 caracteres.' ) );
		}
		$id           = '' !== $key ? 'k_' . hash( 'sha256', Connections::id() . '|' . $actor . '|' . $key ) : Records::id();
		$submitted    = $input['parameters'] ?? array();
		$request_hash = FrozenInput::hash( array( $task, $submitted, Connections::id(), $actor, $context['identity'], $context['revision'] ) );
		$reservation  = Records::get( 'dedupe', $id );
		$old          = Records::get( 'job', $id );
		$previous     = null !== $old ? $old : ( null !== $reservation && ( $reservation['expires_at'] ?? PHP_INT_MAX ) > time() ? $reservation : null );
		if ( null !== $previous && isset( $previous['request_hash'] ) ) {
			if ( ! hash_equals( $previous['request_hash'], $request_hash ) ) {
				return Response::fail( new \WP_Error( 'f3_google_job_key_conflict', 'Chave já usada para outra intenção ou contexto.' ) );
			}
			return Response::ok(
				array(
					'job_id'                 => $id,
					'created'                => false,
					'status'                 => $old['status'] ?? 'expired_details',
					'idempotency_expires_at' => $reservation['expires_at'] ?? null,
				)
			);
		}
		// Persist resource defaults as part of the intent; later configuration never retargets it.
		if ( 'sitemap' === $task ) {
			foreach ( array(
				'site_url'    => 'gsc_site_url',
				'sitemap_url' => 'sitemap_url',
			) as $key => $binding ) {
				if ( ! isset( $params[ $key ] ) && isset( $context['bindings'][ $binding ] ) ) {
					$params[ $key ] = $context['bindings'][ $binding ];
				}
			}
		}
		if ( 'report' === $task && empty( $params['accounts'] ) ) {
			$connector = Reports::templates()[ $params['template'] ?? 'traffic' ]['connector'] ?? '';
			$key       = array(
				'ga4'            => 'ga_property_id',
				'google-ads'     => 'ads_customer_id',
				'search-console' => 'gsc_site_url',
			)[ $connector ] ?? '';
			if ( ! empty( $context['bindings'][ $key ] ) ) {
				$params['accounts'] = array( $context['bindings'][ $key ] );
			}
		}
		$params = FrozenInput::resolve( $task, $params );
		if ( is_wp_error( $params ) ) {
			return Response::fail( $params );
		}
		$changed_context = Context::validate( $context );
		if ( null !== $changed_context ) {
			return Response::fail( $changed_context );
		}
		$actor       = get_current_user_id();
		$hash        = FrozenInput::hash( array( $task, $params, Connections::id(), $actor, $context['identity'], $context['revision'] ) );
		$key         = (string) ( $input['idempotency_key'] ?? '' );
		$id          = '' !== $key ? 'k_' . hash( 'sha256', Connections::id() . '|' . $actor . '|' . $key ) : Records::id();
		$reservation = Records::get( 'dedupe', $id );
		if ( null !== $reservation && ( $reservation['expires_at'] ?? PHP_INT_MAX ) > time() ) {
			if ( $reservation['input_hash'] !== $hash ) {
				return Response::fail( new \WP_Error( 'f3_google_job_key_conflict', 'Chave já usada para outra intenção ou contexto.' ) );
			}
			$existing = Records::get( 'job', $id );
			return Response::ok(
				array(
					'job_id'                 => $id,
					'created'                => false,
					'status'                 => $existing['status'] ?? 'expired_details',
					'idempotency_expires_at' => $reservation['expires_at'],
				)
			);
		}
		$old = Records::get( 'job', $id );
		if ( null !== $old ) {
			return $old['input_hash'] === $hash ? Response::ok(
				array(
					'job_id'  => $id,
					'created' => false,
					'status'  => $old['status'],
				)
			) : Response::fail( new \WP_Error( 'f3_google_job_key_conflict', 'Chave de idempotência já usada com parâmetros diferentes.' ) );
		}
		if ( count( Records::ids( 'job', 1001 ) ) >= 1000 ) {
			return Response::fail( new \WP_Error( 'f3_google_job_limit', 'Limite de 1.000 jobs retidos. Remova jobs encerrados antes de criar novos.' ) );
		}
		$job = array(
			'context'       => $context,
			'result_count'  => 0,
			'id'            => $id,
			'task'          => $task,
			'parameters'    => $params,
			'connection_id' => Connections::id(),
			'user_id'       => $actor,
			'request_hash'  => $request_hash,
			'input_hash'    => $hash,
			'status'        => 'export' === $task ? 'approval_required' : 'pending',
			'cursor'        => 0,
			'results'       => array(),
			'attempts'      => 0,
			'created_at'    => time(),
			'updated_at'    => time(),
			'run_after'     => time(),
			'priority'      => max( 0, min( 9, (int) ( $input['priority'] ?? 5 ) ) ),
			'write'         => in_array( $task, array( 'export', 'sitemap' ), true ),
		);
		if ( ! Records::insert( 'job', $id, $job ) ) {
			return Response::fail( new \WP_Error( 'f3_google_job_persistence', 'Não foi possível criar o job; consulte a chave antes de repetir.' ) );
		}
		if ( '' !== $key ) {
			$reserved = Records::put(
				'dedupe',
				$id,
				array(
					'job_id'        => $id,
					'connection_id' => Connections::id(),
					'request_hash'  => $request_hash,
					'input_hash'    => $hash,
					'expires_at'    => time() + Options::limit( Options::JOB_SUMMARY_DAYS ) * 86400,
				)
			);
			if ( ! $reserved['success'] ) {
				return $reserved + array( 'job_id' => $id );
			}
		}
		self::schedule_tick();
		return Response::ok(
			array(
				'job_id'                => $id,
				'created'               => true,
				'status'                => $job['status'],
				'approval_required'     => 'export' === $task,
				'executor'              => 'wp-cron',
				'cron_requires_trigger' => true,
			)
		);
	}
	public static function run( string $id ): array {
		return Worker::run( $id );
	}
	public static function tick(): void {
		Executor::run( array( 'all_connections' => true ) );
	}
	public static function schedule( array $input ): array {
		$task = $input['task'] ?? 'report';
		if ( ! in_array( $task, array( 'report', 'query', 'preflight' ), true ) ) {
			return Response::fail( new \WP_Error( 'f3_google_schedule_task', 'Agendamentos recorrentes aceitam report, query ou preflight.' ) );
		}
		$id = (string) ( $input['schedule_id'] ?? Records::id() );
		if ( ! preg_match( '/^[A-Za-z0-9_-]{1,100}$/D', $id ) ) {
			return Response::fail( new \WP_Error( 'f3_google_schedule_id', 'schedule_id inválido.' ) );
		}
		$params = $input['parameters'] ?? array();
		if ( ! is_array( $params ) || self::contains_secret( $params ) || strlen( wp_json_encode( $params ) ) > 262144 ) {
			return Response::fail( new \WP_Error( 'f3_google_schedule_input', 'Parâmetros inválidos.' ) );
		}
		$lock = Lock::acquire( 'schedules' );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_schedule_busy', 'Agenda em alteração.' ) );
		}
		try {
			$old = Records::get( 'schedule', $id );
			if ( null !== $old && Connections::id() !== $old['connection_id'] ) {
				return Response::fail( new \WP_Error( 'f3_google_schedule_connection', 'Agenda pertence a outra conexão.' ) );
			}
			if ( null !== $old && ! hash_equals( self::schedule_revision( $old ), (string) ( $input['expected_revision'] ?? '' ) ) ) {
				return Response::fail( new \WP_Error( 'f3_google_schedule_conflict', 'Agenda alterada ou revisão ausente. Consulte google/get-schedule antes de salvar.' ) );
			}
			if ( null === $old && count( Records::list( 'schedule', 101 ) ) >= 100 ) {
				return Response::fail( new \WP_Error( 'f3_google_schedule_limit', 'Limite de 100 agendas.' ) );
			}
			$interval = max( 3600, min( 2592000, (int) ( $input['interval_seconds'] ?? 86400 ) ) );
			$context  = Context::capture();
			if ( is_wp_error( $context ) ) {
				return Response::fail( $context );
			}
			if ( 'report' === $task && empty( $params['accounts'] ) ) {
				$connector = Reports::templates()[ $params['template'] ?? 'traffic' ]['connector'] ?? '';
				$binding   = array(
					'ga4'            => 'ga_property_id',
					'google-ads'     => 'ads_customer_id',
					'search-console' => 'gsc_site_url',
				)[ $connector ] ?? '';
				if ( ! empty( $context['bindings'][ $binding ] ) ) {
					$params['accounts'] = array( $context['bindings'][ $binding ] );
				}
			}
			$params = FrozenInput::resolve( $task, $params, false );
			if ( is_wp_error( $params ) ) {
				return Response::fail( $params );
			}
			$changed = Context::validate( $context );
			if ( null !== $changed ) {
				return Response::fail( $changed );
			}
			$record = array(
				'context'          => $context,
				'id'               => $id,
				'task'             => $task,
				'parameters'       => $params,
				'interval_seconds' => $interval,
				'next_run'         => $old['next_run'] ?? time(),
				'enabled'          => $input['enabled'] ?? true,
				'user_id'          => get_current_user_id(),
				'connection_id'    => Connections::id(),
			);
			$saved  = Records::put( 'schedule', $id, $record );
			if ( ! $saved['success'] ) {
				return $saved;
			}
			self::schedule_tick();
			$record['revision'] = self::schedule_revision( $record );
			unset( $record['context'] );
			return Response::ok( array( 'schedule' => $record ) );
		} finally {
			Lock::release( $lock );
		}
	}
	public static function schedule_revision( array $record ): string {
		return FrozenInput::hash( array_intersect_key( $record, array_flip( array( 'id', 'task', 'parameters', 'interval_seconds', 'enabled', 'user_id', 'connection_id', 'context' ) ) ) );
	}
	public static function get_schedule( array $input ): array {
		$id = (string) ( $input['schedule_id'] ?? '' );
		if ( ! preg_match( '/^[A-Za-z0-9_-]{1,100}$/D', $id ) ) {
			return Response::fail( new \WP_Error( 'f3_google_schedule_id', 'schedule_id inválido.' ) );
		}
		$record = Records::get( 'schedule', $id );
		if ( null === $record || Connections::id() !== $record['connection_id'] ) {
			return Response::fail( new \WP_Error( 'f3_google_schedule_missing', 'Agenda não encontrada nesta conexão.' ) );
		}
		$record['revision'] = self::schedule_revision( $record );
		unset( $record['context'] );
		return Response::ok( array( 'schedule' => $record ) );
	}
	private static function contains_secret( array $params ): bool {
		foreach ( $params as $key => $value ) {
			if ( preg_match( '/secret|token|private.?key|password|authorization/i', (string) $key ) || ( is_array( $value ) && self::contains_secret( $value ) ) ) {
				return true;
			}
		}
		return false;
	}
	/** Keep MCP output bounded; persisted results remain available page by page. */
	public static function view( array $job, int $offset = 0, int $limit = 20, bool $include_input = false ): array {
		unset( $job['confirmation_record'] );
		$offset = max( 0, $offset );
		$limit  = max( 1, min( 100, $limit ) );
		if ( ! $include_input ) {
			unset( $job['parameters'], $job['input_hash'], $job['context'] );
		}
		if ( ! empty( $job['details_removal_started'] ) ) {
			unset( $job['result'], $job['results'] );
			$job['details_available'] = false;
			$job['cleanup_pending']   = true;
			return $job;
		}
		$field = 'inspect-urls' === $job['task'] ? 'results' : 'rows';
		$rows  = 'results' === $field ? ( $job['results'] ?? array() ) : ( $job['result']['rows'] ?? array() );
		$total = count( $rows );
		$slice = array_slice( $rows, $offset, $limit );
		if ( 'results' === $field && isset( $job['result_count'] ) ) {
			$total = $job['result_count'];
			$slice = Results::page( $job['id'], $offset, $limit );
		}
		if ( 'results' === $field ) {
			$job['results'] = $slice;
		} elseif ( isset( $job['result']['rows'] ) ) {
			$job['result']['rows'] = $slice;
		}
		if ( isset( $job['result']['page_changes'] ) ) {
			$job['result']['page_changes'] = array_slice( $job['result']['page_changes'], $offset, $limit );
		}
		if ( isset( $job['result_pages'] ) ) {
			foreach ( $job['result_pages'] as $name => $meta ) {
				$job['result'][ $name ] = Results::rows( $job, $name, $offset, $limit );
			}
			$total = $job['result_pages']['rows']['count'] ?? $total;
			$slice = $job['result']['rows'] ?? $slice;
		}
		$job['page'] = array(
			'offset'      => $offset,
			'limit'       => $limit,
			'total'       => $total,
			'next_offset' => $offset + count( $slice ) < $total ? $offset + count( $slice ) : null,
		);
		return $job;
	}
	public static function inspect( array $input ): array {
		$mode = $input['execution_mode'] ?? 'auto';
		if ( ! in_array( $mode, array( 'auto', 'queued' ), true ) ) {
			return Response::fail( new \WP_Error( 'f3_google_execution_mode', 'Use auto ou queued.' ) );
		}
		$params  = array_diff_key( $input, array_flip( array( 'connection_id', 'idempotency_key', 'priority', 'execution_mode' ) ) );
		$created = self::create(
			array(
				'task'            => 'inspect-urls',
				'parameters'      => $params,
				'priority'        => $input['priority'] ?? 5,
				'idempotency_key' => $input['idempotency_key'] ?? '',
			)
		);
		if ( ! $created['success'] || 'queued' === $mode || count( array_unique( $params['urls'] ?? array() ) ) > 5 ) {
			return $created;
		}
		$result            = Worker::run( $created['job_id'], 5 );
		$result['created'] = $created['created'];
		return $result;
	}
	public static function register(): void {
		$task_schema = array(
			'task'            => array(
				'type' => 'string',
				'enum' => self::TASKS,
			),
			'parameters'      => array( 'type' => 'object' ),
			'idempotency_key' => array( 'type' => 'string' ),
			'priority'        => array(
				'type'    => 'integer',
				'minimum' => 0,
				'maximum' => 9,
			),
		);
		Ability::register(
			'google/create-job',
			'any',
			array(
				'label'        => 'Google: criar job',
				'description'  => 'Enfileira tarefa persistente. Use idempotency_key para repetir o pedido sem duplicar. Escritas interrompidas não são repetidas.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => $task_schema,
					'required'   => array( 'task', 'parameters' ),
				),
				'callback'     => array( self::class, 'create' ),
			)
		);
		Ability::register(
			'gsc/inspect-urls',
			'gsc',
			array(
				'label'        => 'Search Console: inspecionar URLs em lote',
				'description'  => 'Persiste até 500 URLs. auto executa 1–5 URLs únicas na chamada; queued apenas enfileira. Compartilha worker, prazo e cota com cron e CLI.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'execution_mode'  => array(
							'type'    => 'string',
							'enum'    => array( 'auto', 'queued' ),
							'default' => 'auto',
						),
						'site_url'        => array( 'type' => 'string' ),
						'urls'            => array(
							'type'     => 'array',
							'items'    => array( 'type' => 'string' ),
							'minItems' => 1,
							'maxItems' => 500,
						),
						'refresh'         => array( 'type' => 'boolean' ),
						'language_code'   => array( 'type' => 'string' ),
						'idempotency_key' => array( 'type' => 'string' ),
						'priority'        => array(
							'type'    => 'integer',
							'minimum' => 0,
							'maximum' => 9,
						),
					),
					'required'   => array( 'urls' ),
				),
				'callback'     => array( self::class, 'inspect' ),
			)
		);
		Ability::register(
			'google/get-schedule',
			'any',
			array(
				'label'        => 'Google: consultar agenda',
				'description'  => 'Consulta parâmetros, estado e revisão de uma agenda da conexão, sem executá-la.',
				'input_schema' => array(
					'required'   => array( 'schedule_id' ),
					'properties' => array( 'schedule_id' => array( 'type' => 'string' ) ),
				),
				'callback'     => array( self::class, 'get_schedule' ),
			)
		);
		Operations::register();
		Approval::register();
		Ability::register(
			'google/schedule-report',
			'any',
			array(
				'label'        => 'Google: agendar relatório',
				'description'  => 'Cria ou atualiza agenda de leituras. enabled=false pausa. Atualizações exigem a revisão de google/get-schedule. Resultados ficam em jobs, sem enviar notificações externas.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'schedule_id'       => array( 'type' => 'string' ),
						'expected_revision' => array(
							'type'        => 'string',
							'description' => 'Obrigatória ao atualizar uma agenda; obtida em google/get-schedule.',
						),
						'task'              => array(
							'type' => 'string',
							'enum' => array( 'report', 'query', 'preflight' ),
						),
						'parameters'        => array( 'type' => 'object' ),
						'interval_seconds'  => array(
							'type'    => 'integer',
							'minimum' => 3600,
							'maximum' => 2592000,
						),
						'enabled'           => array( 'type' => 'boolean' ),
					),
					'required'   => array( 'parameters' ),
				),
				'callback'     => array( self::class, 'schedule' ),
			)
		);
	}
}
