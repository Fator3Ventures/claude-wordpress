<?php
/** Verified independent origin projections; a status read never creates activity. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Connections, Lock, Options, Records
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class CronHistory {
    private static ?array $invocation=null;
    public static function origin(): string {
        return defined('WP_CLI') && WP_CLI ? 'cli' : ((function_exists('wp_doing_cron') ? wp_doing_cron() : (defined('DOING_CRON') && DOING_CRON)) ? 'http_cron' : 'manual');
    }
    public static function init(): void {
        if (defined('WP_CLI') && WP_CLI && class_exists('WP_CLI') && method_exists('WP_CLI','add_hook')) {
            \WP_CLI::add_hook('before_invoke:cron event run',static function($args) {
                self::$invocation=self::begin(array_keys(Connections::registry()),'wp cron event run',true);
                return $args;
                });
            \WP_CLI::add_hook('after_invoke:cron event run',static function($args) {
                if (self::$invocation) {
                    self::finish(self::$invocation,[],'observed');
                    self::$invocation=null;
                }
                return $args;
                });
        }
    }
    public static function begin(array $connections,string $entry='executor',bool $observation=false): array {
        $frame=self::$invocation ?? ['run_id'=>Records::id(),'at'=>time(),'origem'=>self::origin(),'entry'=>$entry,'connections'=>$connections];
        $frame['connections']=$connections;
        $frame['observation']=$observation;
        $frame['errors']=[];
        $frame['previous']=[];
        foreach ($connections as $cid) {
            if (self::$invocation && !$observation) {
                $prior=Options::stored(self::event_key($cid,$frame['run_id']));
                if ($prior['success'] && is_array($prior['value'] ?? null) && ($prior['value']['scope'] ?? '')==='executor') {
                    $frame['previous'][$cid]=$prior['value'];
                }
            }
            $row=['at'=>$frame['at'],'started_at'=>$frame['at'],'run_id'=>$frame['run_id'],'origem'=>$frame['origem'],'entry'=>$frame['entry'],'scope'=>$observation ? 'wp_cli_invocation':'executor','connection_id'=>$cid,'connection_examined'=>false,'success'=>null,'items'=>0,'jobs'=>0,'schedules'=>0,'alerts'=>0,'state'=>'running','finished_at'=>null];
            if (!self::save($row,!$observation)) {
                $frame['errors'][$cid]='f3_google_cron_persistence';
                self::failure($cid);
            }
        }
        return $frame;
    }
    public static function finish(array $frame,array $results,string $reason='completed'): array {
        $errors=$frame['errors'];
        $passes=[];
        foreach ($frame['connections'] as $cid) {
            $stored=Options::stored(self::event_key($cid,$frame['run_id']));
            if (!$stored['success'] || !is_array($stored['value'] ?? null)) {
                $errors[$cid]='f3_google_cron_read';
                continue;
            }
            $row=$stored['value'];
            if (!empty($frame['observation']) && ($row['scope'] ?? '')==='executor') {
                $passes[$cid]=$row;
                continue;
            }
            $r=$results[$cid] ?? [];
            $previous=$frame['previous'][$cid] ?? [];
            if ($previous) {
                foreach (['items','jobs','schedules','alerts'] as $field) {
                    $r[$field]=(int)($r[$field] ?? 0)+(int)($previous[$field] ?? 0);
                }
                $r['connection_examined']=!empty($r['connection_examined']) || !empty($previous['connection_examined']);
                if (($previous['success'] ?? null)===false) {
                    $r['success']=false;
                    $r['state']='failed';
                }
            }
            $row=array_replace($row,$r,['finished_at'=>time(),'state'=>$r['state'] ?? $reason]);
            if (!self::save($row,empty($frame['observation']))) {
                $errors[$cid]='f3_google_cron_persistence';
                self::failure($cid);
            }
            $passes[$cid]=$row;
        }
        return ['passes'=>$passes,'observability_error'=>$errors ?: null];
    }
    private static function event_key(string $cid,string $id): string {
        return 'f3_mcp_google_cron_pass_'.$cid.'_'.$id;
    }
    private static function failure(string $cid): void {
        Options::set('f3_mcp_google_cron_error_'.$cid,['at'=>time(),'code'=>'f3_google_cron_persistence']);
    }
    private static function save(array $row,bool $executor): bool {
        $cid=$row['connection_id'];
        $lock=Lock::acquire('cron-history:'.$cid,30);
        if (!$lock) {
            return false;
        }
        try {
            $key='f3_mcp_google_cron_history_'.$cid;
            $s=Options::stored($key);
            if (!$s['success']) {
                return false;
            }
            $state=$s['value'] ?? ['observed_since'=>time(),'window_complete'=>true];
            if (!is_array($state)) {
                return false;
            }
            $event=self::event_key($cid,$row['run_id']);
            $old=Options::stored($event);
            if (!$old['success']) {
                return false;
            }
            // The same native invocation may enter the executor several times.
            if (is_array($old['value'] ?? null) && ($row['state'] ?? '')==='running' && ($old['value']['scope'] ?? '')==='executor') {
                $row=array_replace($row,array_intersect_key($old['value'],array_flip(['items','jobs','schedules','alerts'])));
            }
            $saved=Options::set($event,$row);
            if (!$saved['success']) {
                return false;
            }
            $field=['cli'=>'ultima_cli','http_cron'=>'ultima_http','manual'=>'ultima_manual'][$row['origem']];
            foreach (array_merge([$field],$executor ? ['last_pass'] : []) as $f) {
                if (!isset($state[$f]) || strcmp($row['run_id'],$state[$f]['run_id'])>=0) {
                    $state[$f]=$row;
                }
            }
            if ($row['success']===true && ($row['at'] ?? 0)>($state['last_success'] ?? 0)) {
                $state['last_success']=$row['at'];
            }
            $saved=Options::set($key,$state);
            if (!$saved['success']) {
                Options::set('f3_mcp_google_cron_error_'.$cid,['at'=>time(),'code'=>'f3_google_cron_projection']);
            }
            return $saved['success'];
        }
        finally {
            Lock::release($lock);
        }
    }
    public static function summary(string $cid,?int $now=null): array {
        $now=$now ?? time();
        $s=Options::stored('f3_mcp_google_cron_history_'.$cid);
        $base=['last_pass'=>null,'ultima_cli'=>null,'ultima_http'=>null,'ultima_manual'=>null,'last_success'=>null,'cron_servidor_ativo'=>false,'executor'=>'wp-cron','agendamento_verificado'=>false,'passagens_24h'=>['cli'=>0,'http_cron'=>0,'manual'=>0],'observed_since'=>null,'window_complete'=>false,'observability_error'=>null];
        if (!$s['success'] || ($s['exists'] && !is_array($s['value']))) {
            return array_replace($base,['observability_error'=>'f3_google_cron_read']);
        }
        $state=$s['value'] ?? [];
        $base=array_replace($base,array_intersect_key($state,$base));
        foreach (['last_pass','ultima_cli','ultima_http','ultima_manual'] as $f) {
            if (is_array($base[$f]) && ($base[$f]['state'] ?? '')==='running' && $base[$f]['at']<$now-120) {
                $base[$f]['state']='interrupted';
                $base[$f]['success']=null;
            }
        }
        $at=$base['ultima_cli']['at'] ?? null;
        $base['cron_servidor_ativo']=is_int($at) && $at <= $now && $at >= $now-7200;
        $base['executor']=$base['cron_servidor_ativo'] ? 'server-cron' : 'wp-cron';
        $base['legacy_last_pass']=get_option('f3_mcp_google_executor_last_'.$cid,null);
        try {
            $names=self::names($cid,10001,true);
            if (is_wp_error($names)) {
                throw new \RuntimeException();
            }
            $complete=count($names)<=10000;
            foreach (array_slice($names,0,10000) as $name) {
                $row=Options::stored($name);
                if (!$row['success'] || !is_array($row['value'])) {
                    throw new \RuntimeException();
                }
                $r=$row['value'];
                if (($r['at'] ?? 0)>$now-86400 && $r['at'] <= $now && isset($base['passagens_24h'][$r['origem'] ?? ''])) {
                    ++$base['passagens_24h'][$r['origem']];
                }
            }
            $error=Options::stored('f3_mcp_google_cron_error_'.$cid);
            if (!$error['success']) {
                throw new \RuntimeException();
            }
            $base['observability_error']=($error['value']['at'] ?? 0)>$now-86400 ? $error['value'] : null;
            $base['window_complete']=$complete && !$base['observability_error'] && ($state['observed_since'] ?? $now)>0 && ($state['observed_since'] ?? $now)<=$now-86400;
        }
        catch (\Throwable $e) {
            $base['observability_error']='f3_google_cron_read';
            $base['window_complete']=false;
            $base['cron_servidor_ativo']=false;
            $base['executor']='wp-cron';
        }
        return $base;
    }
    private static function names(string $cid,int $limit,bool $newest) {
        global $wpdb;
        $prefix='f3_mcp_google_cron_pass_'.$cid.'_';
        $rows=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name ".($newest?'DESC':'ASC')." LIMIT %d",$wpdb->esc_like($prefix).'%', $limit));
        return $wpdb->last_error ? new \WP_Error('f3_google_cron_read','Histórico ilegível.') : $rows;
    }
    public static function cleanup(): void {
        foreach (array_keys(Connections::registry()) as $cid) {
            $names=self::names($cid,100,false);
            if (is_wp_error($names)) {
                continue;
            }
            foreach ($names as $name) {
                $row=Options::stored($name);
                if ($row['success'] && is_array($row['value']) && ($row['value']['at'] ?? PHP_INT_MAX)<time()-7*86400) {
                    Options::delete($name);
                }
            }
        }
    }
}
