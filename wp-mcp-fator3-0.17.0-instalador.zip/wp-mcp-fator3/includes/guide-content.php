<?php
/** Generated from docs/OPERACAO.md. Authenticated guide only. */
if (!defined('ABSPATH')) { exit; }
return <<<'F3_GUIDE_CONTENT'
# Fator3 MCP 0.17.0 — manual de operação

Este manual descreve o runtime 0.17.0. Esta é a versão estável. O guia/relatório externo registra os testes executados e os limites de cobertura. Os contratos completos são consultados por Get Ability Info ou `system/guide` com `ability`.

## Conexão e descoberta

URL principal: `https://SEU-SITE/wp-json/mcp/wp-mcp-fator3`. A URL `https://SEU-SITE/wp-json/mcp/wp-mcp-ultimate` continua sendo um alias do mesmo serviço. Não é necessário recriar conectores existentes. Em instalações sem permalink, use `?rest_route=/mcp/wp-mcp-fator3`.

O transporte mantém suporte às revisões MCP implementadas na base, inclusive os clientes com sessão e o modo sem sessão. Uma sessão antiga sem prova da versão efetivamente negociada recebe HTTP 404 para o cliente inicializar outra, preservando a credencial. Não são removidas sessões nem o servidor próprio do Elementor.

Comece por `system/capabilities`, Discover Abilities e Get Ability Info. Há três metatools principais: descoberta, informação e execução. O executor de leitura é optativo conforme política. Não há necessidade de expor centenas de tools individuais. Executores que chamam outra habilidade por nome não podem ser alvos, inclusive executores de outros provedores: `ability_executor_forbidden`.

Discovery aceita filtros, paginação e `if_catalog_sha256`; `unchanged:true` significa que o catálogo efetivo daquela conexão não mudou. Permissões dependentes do alvo aparecem como `requires_input`, e serão conferidas com os parâmetros reais. Leia o schema; não deduza o contrato a partir do título ou de uma versão anterior.

## Perfis e migração de credenciais

Manutenção é o perfil administrativo pleno: observa capacidades WordPress, permissões PHP/sistema operacional, constantes de bloqueio e estado geral do canal. Não exige raízes por conexão, flag adicional de SQL ou permissão adicional de exportação. Quem instala código e administra o banco pode acessar dados sensíveis; redação de resposta evita exposição acidental e não isola esse administrador.

A base de atualização validada é a 0.16.0 (sem bloqueio por versão de origem no código) e conserva credenciais, prazos e políticas já efetivas. Não há promoção de perfil durante esta atualização. Instalação limpa não importa opções de plugins predecessores. Identidades novas sem configuração ficam Sem acesso. Uma política Legado explícita conserva sua restrição até uma mudança administrativa deliberada.

OAuth aceita uma lista de escopos separados por espaço e recusa escopos desconhecidos. O consentimento escolhe o perfil permitido. Ao renovar um token legado, o novo grant herda a política configurada e seus ajustes. Revogar depois a identidade legada não revoga esse grant independente.

`connections/list` pagina identidades sem tokens/senhas. `connections/update` e `connections/revoke` exigem ID exato e `expected_policy_version`. Alteração da própria identidade requer prévia e `confirm_token`. O painel e as habilidades usam o mesmo serviço. Senha de aplicação continua sendo emitida pelo painel WordPress do canal. Não confunda conexões do mesmo usuário com a mesma credencial.

## Confirmação, conflitos e resultados

Resultados incluem `success`, código estável de erro, identificação da operação quando pertinente e estado observado do efeito. No MCP, falha de tool usa `isError:true` e conteúdo estruturado. `data` de WP_Error é preservada com redação por chave. `applied:null` significa efeito incerto, não autorização para repetir.

Operações em duas fases fornecem uma identidade `phase:…` consultável por `operations/status`, inclusive se a resposta de confirmação se perder. Para operações em duas fases, faça a chamada sem `confirm_token`, examine a prévia e repita os mesmos parâmetros com o token. Ele se vincula à intenção, conexão e pré-imagem, e expira em 600 segundos. SQL, lotes, restauração, mudanças de endereço e autorrestrição continuam em duas fases. `confirm:true` dispensa a segunda chamada apenas em exclusões tipadas admitidas para Manutenção; não dispensa uma revisão/hash fornecida.

`expected_sha256`, `expected_revision` e revisões de política impedem sobrescrever uma pré-imagem diferente. Os locks de arquivo cobrem leitura, comparação, backup e substituição entre operações cooperantes. O tempo padrão `lock_wait_seconds` é 2 segundos; dois agentes no mesmo site devem tratar conflitos e reler antes de decidir. Editores externos que não usam o mesmo lock continuam podendo alterar arquivos.

## Arquivos, busca e transferências

`files/read` conserva bytes binários em base64 também na leitura integral. Use `offset_bytes` para iniciar em um byte arbitrário; o cursor opaco continua disponível. Cursor e offset incompatíveis são recusados. `tail_lines`, `offset`, `grep` e busca por `grep_regex` atendem logs/textos; `files/search` aceita arquivo único ou diretório. Erros de PCRE são identificáveis.

`files/write` recusa conteúdo textual para extensões binárias; use `content_base64`. Arquivos PHP têm validação sintática, pré-imagem, escrita atômica e sondas. Em Manutenção, `probe:false` é uma escolha explícita que pula apenas as sondas de execução; a resposta registra isso, e a operação concluída não é revertida como se estivesse abandonada.

`files/move`, `files/copy`, `files/delete`, `files/rmdir`, patch e restauração preservam seus contratos. Rótulos `label`/`rotulo` identificam backups; aliases conflitantes são recusados. O armazenamento `f3-mcp-private` não é uma pasta comum disponível por files/*: consulte `system/health` e os serviços de backup/exportação.

O limite padrão por arquivo é 16 MiB. `system/settings-update` ajusta `file_bytes` entre 1 MiB e 1 GiB, sujeito aos recursos físicos; a conexão pode ter limite próprio. Isso não aumenta o tamanho máximo de uma resposta nem elimina limites PHP. Para 20 MiB, configure pelo menos 20 MiB e use `files/upload-create`, partes de 256 KiB, `files/upload-part` e `files/upload-finalize`. SHA-256 e tamanho total são conferidos; partes repetidas idênticas são aceitas. Cancelar remove as partes da transferência, sem desfazer um arquivo já concluído.

`files/archive` compacta a origem incluindo seu nome. `files/extract` valida o ZIP e prepara o destino antes de substituir. `overwrite:true` substitui a árvore inteira, sem mesclar. Links, traversal, colisões, CRC inválido e expansão excessiva são recusados. `files/rollback-tree` usa o backup e recusa pós-imagem alterada. Limites adicionais do inventário de recuperação: 20.000 entradas e 256 MiB por árvore.

## Backups e recuperação

Backups e artefatos são privados, com envelope PHP e metadados assinados. A exportação contém valores originais quando destinada a recuperação, inclusive segredos. Base64 não é criptografia. `backups/list` permite rótulo/data. Retenção é explícita, com prévia/seleção congelada e tratamento de legados; instalar a versão não limpa pendências automaticamente.

A sentinela em mu-plugins preserva a recuperação fora da pasta substituível. Não a remova enquanto houver operação pendente. Rollback de arquivos/plugins/temas verifica a pós-imagem para não apagar mudança posterior. Restauração de arquivos não desfaz migrações arbitrárias realizadas por código de um plugin/tema.

`system/health` apresenta estado e localização do armazenamento, recuperação, cron e sondas. Consulte o código e o estado de erro antes de repetir. Uma operação interrompida pode precisar de recuperação explicitamente confirmada.

## Plugins, temas e atualização do canal

`plugins/upload` e base64 aceitam hash do ZIP, slug esperado, overwrite e ativação explícita. Omissão de `activate` equivale a false. A substituição cria pré-imagem e devolve versões/ativação antes e depois. Plugins que já estavam ativos permanecem ativos ao atualizar, com verificação em requisição nova e sondas anônimas. `plugins/rollback` recupera a árvore anterior. A exclusão verifica ausência e limpa somente a entrada correspondente em auto-update; limpeza de registro de uninstall não executa o callback.

A atualização da 0.16.0 pode usar `plugins/upload` com o instalador 0.17.0, `expected_sha256`, `expected_slug:wp-mcp-fator3` e `overwrite:true`; confira a evidência de self-upload no relatório desta entrega antes da frota. Instalação limpa usa o mesmo instalador no wp-admin. A inicialização por estado substitui os migradores antigos; o schema de dados permanece 2. Diários e sentinelas existentes não são apagados automaticamente.

`plugins/list` permite projeção `fields`/`campos` e filtro `prefixes`/`prefixo`. `themes/upload`, `themes/activate`, `themes/update`, `themes/delete` e `themes/rollback` acrescentam pré-imagem, identidade, requisitos, pai/filho e recuperação. O tema em uso ou seu pai não pode ser excluído; tema com dependentes também é recusado.

O canal aceita fontes HTTPS de manifesto em `system/settings-update.update_channels`. Configurá-las não liga atualização automática. `Update URI: https://fator3.com.br/plugins/wp-mcp-fator3` identifica o pacote no mecanismo de atualização próprio; não é um feed publicado. O manifesto precisa apontar para bytes reais verificáveis por SHA-256. Não substitua Core/Google atuais pelos pacotes antigos usados em testes históricos.

## Leitura SQL e exportação de resultados

Em Manutenção, `db/query` aceita SELECT, WITH terminado em SELECT, JOIN, UNION, views do banco do site, subconsultas, agregações, CASE, janelas, funções JSON/data e leitura pertinente de information_schema. Há uma única instrução, sem escrita nem construções com efeito colateral. O SQL original é preservado; somente o LIMIT externo é limitado para a resposta interativa.

A resposta interativa tem até 2.000 linhas e 16 MiB. `timeout_seconds` é limitado pelo tempo efetivo do processo. Para o resultado completo, use `db/query-export` com `format:jsonl` ou `csv`, `gzip` opcional e `async:true` por padrão. A operação materializa um snapshot de leitura, informa contagem/bytes/SHA-256 e só publica artefato completo. `operations/status` recebe `operation_id`; `db/export-part` lê blocos base64 de até 256 KiB com offset/hash. `db/query-page` pagina JSONL sem gzip por uma chave sequencial criada no snapshot, sem OFFSET sobre tabelas vivas.

Jobs dependem do loopback ou WP-Cron, sem daemon novo. `db/export-cancel` solicita cancelamento cooperativo. Snapshot de worker encerrado não é retomado como se ainda existisse: o estado aponta interrupção e exige nova exportação. Artefatos de consulta expiram em sete dias. Espaço/tempo insuficientes geram falha sem disponibilizar arquivo parcial como concluído.

A redação usa origem da coluna, chave projetada e predicado exato comprovado. Aliases de colunas secretas continuam redigidos. `option_value`/`meta_value` com chave ambígua são redigidos conservadoramente; `redacted` informa célula, razão e origem. Transformações arbitrárias em SQL administrativo não têm garantia de impedir inferência. Respostas binárias preservam encoding explícito.

## Escrita SQL, dump e troca serializada

`db/execute`, `db/batch` e `db/search-replace` usam `selection-guard/2`, descrito integralmente na seção **Contrato da guarda SQL** deste manual. A seleção e suas dependências são verificadas sob locks MySQL, com token de dez minutos, dump privado (integral por padrão) e recibo persistido. A guarda não é uma impressão do banco inteiro. `database_conflict` exige revisão de nova prévia; `sql_guard_unavailable` recusa formas sem prova completa antes de escrever. Tokens SQL pendentes conservados na 0.16.0 continuam válidos até o prazo original e mantêm o escopo integral quando omitido.

DML aplica uma transação InnoDB; DDL é operação separada, com snapshot para recuperação e sem promessa de rollback transacional global. `operations/plan` não inclui SQL.

`db/export` produz SQL gzip privado de tabelas selecionadas ou do banco. Inclui schema, dados, índices, views em ordem de dependência, triggers e manifesto. Bytes binários, NULL e Unicode são preservados. Banco com rotinas/eventos SQL não suportados é recusado como dump completo; nenhum artefato parcial recebe esse rótulo. Dumps de recuperação não expiram automaticamente.

`db/restore` exige artefato íntegro, prévia do destino e confirmação; cria backup anterior e diário fora do banco afetado. O estado MCP corrente é preservado por inventário explícito (`preserved-state/1`), inclusive revogações, senhas de aplicação e sessões WordPress. Options `f3_mcp_google_*` e a tabela Google pertencem à fotografia restaurada. Suspenda e reconcilie executores pelos controles dos seus donos: restauração não desfaz efeitos já enviados a APIs externas. Diários e recibos existentes na 0.16.0 são preservados; novos diários incluem `preserved_state_manifest`. Não é uma transação global. O controlador em mu-plugins mantém wp_options disponível durante a importação e, após abandono do processo, tenta restaurar a pré-imagem na requisição seguinte. Consulte `db/recovery-status` e `operations/status`; falha de recuperação permanece explícita. Backups de mutação com pós-imagem divergente exigem revisão e nova prévia com `allow_changed_destination:true`. Não repita cegamente uma restauração incompleta.

`db/search-replace` faz troca literal em strings, JSON e arrays serializados, com filtros `tables`/`columns`, amostras redigidas e lotes por chave primária dentro de uma transação. Não instancia objetos PHP. Objetos serializados e alterações em chave primária são apontados e preservados; tabela selecionada sem chave primária causa recusa antes da confirmação. Alterações de chave usam SQL explícito. Contagens por tabela/coluna e backup acompanham o resultado. Confira `skipped`, mesmo quando a operação conclui.

`db/schema` com `contar:true` acrescenta `rows_exact`, mantendo distinta a estimativa.

## Conteúdo e mídia

Patch de post/página exige seleção única por padrão, aceita limite também no modo regex e suporta `expected_revision`. Readback inclui SHA-256 e CHAR_LENGTH; transformação observada é indicada por `content_filtered`. As descrições usam `parent`; `parent_id` é alias compatível, com recusa quando diverge.

`content/edit-block` não descarta filhos silenciosamente quando recebe `inner_html`; use `children` para substituir a árvore. `featured_media` e revisão final consideram as gravações pertinentes. Revisões e getters permitem projeção sem trazer conteúdo desnecessário.

`content/delete-post` explicita o comportamento real de lixeira para tipos de post e exclusão permanente. `media/regenerate` e `media/set-site-icon` usam as APIs nativas e verificam metadados/recortes. Não exigem mu-plugin descartável.

## Configuração, cron e cache

Em Manutenção, `options/update` administra options fora do estado interno do canal, com backup e readback. `stylesheet` usa `themes/activate`; `template`/`current_theme` orientam para essa seleção nativa. `active_plugins` orienta para as habilidades de ativação/desativação para preservar hooks. Nomes internos f3_mcp_* orientam para `system/settings-update`. Segredos podem ser gravados, mas não são repetidos em resultado/log. `auto_update_plugins` é administrável; instalar o canal não a habilita automaticamente.

`site/set-admin-email` grava o e-mail autorizado e limpa confirmação pendente; não comprova entrega de e-mail. `site/set-language` instala pacote oficial compatível antes de mudar WPLANG. `roles/list`/`roles/update` usam APIs nativas e confirmação. `site/set-address` faz prévia, exige destino alcançável e permite troca serializada de URLs, com verificação e reversão. Não cria DNS/TLS.

Permalink, category_base e tag_base são regenerados pelo serviço nativo; `rewrite/flush` executa flush soft e devolve comparação de regras. Não é necessário editar rewrite_rules por SQL.

`cron/list` mostra hook/timestamp/argumentos/recorrência e revisão. `cron/run` executa somente evento existente conferido, sob lock cooperativo e contexto cron sem usuário logado; conclusão do callback informa `business_result:unknown`. O resultado inclui `operation_id`; `operations/status` conserva conclusão ou efeito incerto após interrupção. Não é um executor de nomes de funções PHP. `cron/schedule` e `cron/unschedule` verificam a agenda nativa. Dois disparos cooperantes são serializados; callbacks com efeito externo precisam de verificação própria.

`system/delete-transient` remove chave exata e identifica backend. `system/cache-flush` limpa cache de objeto, não cache de página. `system/health.cron` informa wp_cron_desabilitado, eventos_vencidos e ultimo_disparo. Site sem disparo WP-Cron pode acumular agenda vencida.

## Sondas e limites da evidência

`system/probe` faz requisições anônimas ao próprio site, sem cookie, com asserções e informação de cache. Home/REST recebem verificação comum após operações protegidas. Uma medição de TTFB não identifica sozinha o tempo de geração PHP ou cache frio. Só considere `http_protection_tested` quando houver evidência efetiva da sonda.

Os documentos operacionais Markdown e o catálogo JSON bruto ficam no pacote fonte/documentação externa. O instalador fornece esta ajuda por recurso PHP protegido, lido por `system/guide` e wp-admin; não depende de regras manuais de .htaccess para esconder o manual. Atualização substitui a árvore do canal e remove os documentos residuais da distribuição anterior com pré-imagem.


## Contrato de integração do servidor


Contrato canônico L01/L02/I04/I05. Provedor `wp-mcp-fator3`; política de extensão continua `policy_contract:1`.

Identidade constante: `server_id:wp-mcp-ultimate-server`, `route:/mcp/wp-mcp-fator3`, `aliases:[/mcp/wp-mcp-ultimate]`. Slug, Text Domain, Update URI e nomes dos metatools permanecem.

Filtros públicos: `f3_mcp_create_default_server(bool $enabled, array $identity)` e `f3_mcp_default_server_config(array $config, array $identity)`. O primeiro usa true como default e compartilha a decisão entre categoria, habilidades, fábrica e diagnóstico. O kill-switch continua controlando autorização, independentemente do registro do servidor.

O segundo aceita contribuições em `tools`, `resources`, `prompts`; preserva defaults e os três metatools. Nomes novos precisam existir, estar públicos, ter tipo correto e pertencer a provedor aderente. Retornos inválidos preservam defaults e registram códigos sanitizados. ID, endpoints, autenticação e handlers não podem ser substituídos. Contribuições repetidas são deduplicadas. Este SDK é cooperação entre plugins PHP; não é isolamento contra PHP malicioso.

`Fator3\McpFiles\ServerContract::capabilities()` informa contrato, versão, identidade e disponibilidade do hook. `::status()` é observação local, sem HTTP ou montagem recursiva: `core_loaded`, `server_enabled`, `channel_enabled`, `registry_checked`, `server_registered`, `tools_ready`, `endpoints`, `errors`. Antes de registro, desconhecidos são null. `external_connectivity_tested:false` distingue isso de conectividade externa comprovada. A fachada não devolve credenciais ou identidades de conexões.

Filtros `mcp_adapter_*` não controlam o núcleo embutido. O ciclo é `f3_mcp_adapter_init`. O mapa completo está em `server-hook-map.json` no fonte; os demais hooks são internos, sem estabilidade de SDK prometida. Hooks da Abilities API e `f3_mcp_register_providers` continuam compartilhados. O Fator3 não altera `elementor_mcp_enabled`, não desliga o servidor Elementor e continua descobrindo seus recursos públicos com URI em `meta.mcp.uri`.

Google 0.8.0 conserva `google/mcp-read` e `google/mcp-write` por um adaptador do MCP que verifica os metadados públicos e o provedor. Não chama APIs privadas Google. A contribuição Google ao filtro próprio é deduplicada. O executor opcional de leitura do canal também é preservado.

Somente uma chamada direta de ferramenta registrada no servidor Fator3, autenticada por OAuth/senha de aplicação, estabelece contexto interno de entrada. As duas bridges Google têm admissão explícita nesse contexto, verificando perfil e permissão nativa. Leitura não admite a bridge de escrita; Personalizado precisa permitir a bridge e o alvo final. O Google conserva seus gates e confirmações. Qualquer executor usado como alvo retorna `ability_executor_forbidden`, incluindo bridges Google e `mcp-adapter/execute-ability`. Parâmetros do cliente e outra porta MCP não fabricam esse contexto.

A integração PHP Core → Google permanece fora do transporte MCP. Não recebe perfil sintético, não depende de sessão MCP, nem ganha bypass pelo nome do provedor. O catálogo reflete as abilities realmente registradas pelo complemento instalado.


## Contrato da guarda SQL


Guarda preservada de 0.15.0; extensão M38B do escopo de backup. `db/execute`, `db/batch` e `db/search-replace` usam este protocolo. `db/restore` verifica o destino das tabelas presentes no manifesto; o dump integral conserva o alcance global. SQL não é aceito por `operations/plan`.

## Duas fases

Chame sem `confirm_token`. A resposta é prévia, com `applied:false`, token, `operation_id` e validade de 600 segundos. Repita os mesmos parâmetros com o token. A guarda privada está vinculada à intenção, credencial, usuário, site e contrato. Uma confirmação concluída devolve o recibo com `replayed:true`; uma operação iniciada sem recibo final devolve `operation_uncertain` e nunca se reaplica automaticamente. Consulte `operations/status`.

Tokens SQL pendentes conservados na 0.16.0 preservam intenção, identidade, guarda, prazo e escopo integral quando omitido. Recibos concluídos e estados incertos continuam consultáveis. A atualização não captura novamente credenciais históricas.

`guard_contract:selection-guard/2`; `guard_scope:selected_rows_and_dependencies` ou `ddl_objects`; `target_tables`; `selected_rows`; `selection_exact`; `backup_scope:database` ou `selected_tables` em db/execute elegível; `backup_tables`. O antigo inventário global `summary.tables` deixa de ser a guarda de DML. `statement_previews.predicted_affected_rows` vem da simulação sequencial; `affected_rows` na aplicação vem do MySQL real. db/execute apresenta 20 linhas por padrão (`limit_preview`, máximo 200); demais prévias apresentam no máximo 200 linhas; a guarda cobre a seleção integral dentro do orçamento.

## SQL aceito e limites explícitos

| Forma | Cobertura |
|---|---|
| UPDATE/DELETE | Um alvo físico InnoDB, predicados, expressões determinísticas, alteração de chave, NULL, binário, Unicode; chave primária ou única não nula |
| JOIN | INNER JOIN, um alvo de escrita, sem duplicar identidade alvo; todas as linhas participantes influenciam a guarda |
| Subconsultas | Um nível em WHERE: IN e EXISTS; fontes físicas explícitas e predicado; fontes recebem suas próprias leituras bloqueantes |
| ORDER BY/LIMIT | LIMIT requer ORDER BY em colunas diretas contendo a identidade completa, inclusive no INSERT SELECT; seleção sem ordem total é recusada |
| INSERT/REPLACE | Lista explícita de colunas, VALUES; todas as chaves únicas, colisões e ausências; upsert com ON DUPLICATE KEY UPDATE |
| INSERT SELECT | Uma fonte física diferente do destino, projeção determinística e filtros; sem agregação/janela/UNION |
| Lote | Até 100 instruções DML; dependências sequenciais simuladas. Cada instrução tem uma fonte física; JOIN/subconsulta em lote e identidade autoatribuída em lote exigem reescrita explícita |
| DDL | CREATE TABLE, ALTER TABLE, DROP TABLE e TRUNCATE TABLE sobre um objeto. Sem IF EXISTS, RENAME, FK, PARTITION, tablespace, CREATE SELECT/LIKE ou rotinas |
| Search-replace | Seleção literal de linhas/colunas, chave primária; preserva objetos serializados e chaves primárias; valores únicos resultantes participam da guarda. Tabela selecionada sem chave causa recusa antes do token |

Expressões admitem aritmética e funções determinísticas declaradas no planejador, como CONCAT, REPLACE, COALESCE, IFNULL, CAST, CONVERT, HEX, UNHEX e funções JSON de valores. Funções não classificadas, funções temporais aleatórias, variáveis de sessão, views, tabelas sem identidade estável, índices únicos parciais/funcionais, colunas geradas/ON UPDATE, triggers e FKs não modeladas recebem `sql_guard_unavailable`, sem token utilizável e sem escrita. Não há fallback para a impressão do banco inteiro. UPDATE de vários alvos e autorreferência à mesma tabela por outro alias também são recusados. Consulte o erro `reason`; não altere dados para contornar a recusa.

A implementação materializa cópias temporárias das tabelas envolvidas para calcular o efeito sequencial, sem DML de ensaio na base real. Essa materialização é limitada a 100.000 linhas por leitura, 64 MiB acumulados e 30 segundos. O orçamento inclui cópias intermediárias e metadados, portanto uma tabela grande pode esgotá-lo mesmo com seleção pequena. Nesse caso retorna `sql_selection_budget`; a seleção nunca é truncada e assinada como completa. Use operações tipadas ou reduza a operação. O tokenizador admite até 8.192 tokens por instrução. Essa é uma limitação operacional explícita desta implementação.

## Concorrência, backup e resultados

Pré-imagens completas e seleções são assinadas com HMAC privado, preservando tipo estrutural, bytes e NULL. O contador corrente AUTO_INCREMENT não participa da guarda DML; o atributo da coluna permanece. DDL conserva o contador no schema de seu alvo.

A confirmação usa uma conexão MySQL fixa e REPEATABLE READ. Antes de criar a visão consistente, lê com FOR UPDATE as seleções, dependências, identidades e intervalos pertinentes. Os locks impedem alterações externas durante backup e escrita. Conforme índices e plano de execução, o InnoDB pode bloquear vizinhos examinados. Uma mudança fora da seleção entre prévia e confirmação não cria conflito só por pertencer à mesma tabela. Leituras de dependências são conservadoras dentro dos predicados modelados, especialmente fontes de IN/EXISTS.

O dump de recuperação é integral por padrão. db/execute admite selected_tables nas condições descritas em SQL-RETENTION.md. Ambos são privados e contêm valores originais, inclusive segredos. É produzido por leituras consistentes, sem FOR UPDATE em todas as tabelas. Falha de gravação/verificação cancela a aplicação. O volume do dump pode dominar a duração da operação; não equivale ao escopo da guarda. DML falha por rollback da transação, sem restaurar automaticamente o banco inteiro. DDL exige recuperação por snapshot e usa trava do objeto na conferência final. Restauração integral é outra operação explícita.

`database_conflict` inclui `conflict:true`, `applied:false`, `changed:false`, e `conflict_reason` (`target_rows_changed`, `selection_changed`, `dependency_changed`, `schema_changed`, `unique_key_changed`). Faça nova prévia e revise a diferença. Timeout SQL (`database_lock_timeout`), deadlock (`database_deadlock`), orçamento, backup indisponível e expiração são erros separados. A espera de locks SQL é 5 segundos; não é o `lock_wait_seconds` de arquivos.

`changed` depende das instruções efetivamente executadas. Não compara todo o banco após a escrita. O recibo inclui `statement_results`, `backup_id`, `readback`, `atomic` e estado persistido. Perda do recibo depois de commit deixa a operação incerta, com backup e ID para investigação. Não interprete `applied:null` como falha sem efeito.

Redação na prévia evita exposição acidental de tokens e colunas sensíveis. Um administrador com instalação de código e SQL pleno não fica isolado dos dados por essa redação. Guarde os backups com o mesmo cuidado dedicado ao banco original.

## Contratos dos complementos

As ferramentas diretas Google conservam seus parâmetros nativos, inclusive `label`. Os aliases de backup do MCP não reescrevem parâmetros de negócio de outros provedores. O SDK local e a distinção entre ferramenta direta e executor aninhado estão documentados em `SERVER-INTEGRATION.md`.

## Compatibilidade e ciclo do servidor

A 0.17.0 usa instalação nova e atualização da 0.16.0 como cenários de manutenção e teste, sem trava por versão de origem. A matriz local é Core 1.24.0 e Google 0.8.0; o relatório distingue essa matriz dos pacotes efetivos do Site-Teste. A integração verifica contratos, sem igualdade obrigatória de versão. Não repete a captura histórica de credenciais nem eleva perfis. Options explicitamente falsas/vazias, prazos, revogações, recibos e confirmações SQL pendentes permanecem.

A primeira entrada REST/CLI conclui o registro público de habilidades após init e antes de compor tools, resources e prompts. Chamadas reentrantes durante registro/configuração não publicam um servidor parcial. ServerContract::status continua observacional. O aquecimento do Google permanece válido, mas não é necessário para corrigir o ciclo do MCP. Um erro de criação é diagnosticado e não marca a inicialização como concluída.

## Retenção dos dumps SQL

`backups/list` e `backups/prune` aceitam category: `backups` (padrão anterior), `sql_mutation` (dumps automáticos comprovados) e `sql_artifacts` (todos os artefatos SQL inventariados). Não use backups/export para ler SQL: use `db/export-part` e `db/restore`. A listagem mostra metadados, nunca as linhas originais. Exige manage_options e perfil Manutenção, além do canal habilitado.

O inventário herdado ainda presente na 0.16.0 avança em lotes de até 200 artefatos, com checkpoint. Repita backups/list até inventory_complete:true. Origem não comprovada vira unknown; pares incompletos não são restauráveis. Saúde não faz dump, poda ou migração. storage.sql_artifacts mostra contagens e bytes indexados, política e elegibilidade observada; eligibility.complete:false e inventory_complete:false indicam cobertura parcial. A observação de elegibilidade examina no máximo 1000 registros e protege o acervo se o diário de recuperação exceder 1000 registros ou for inválido.

Política inicial: idade maior que 30 dias OU exceder 20 dumps automáticos, preservando ao menos os três mais recentes e todas as referências ativas. Ajuste em Configurações → Retenção dos backups SQL ou system/settings-update.sql_retention (duas fases): older_than_days de 1 a 3650, max_count de 1 a 10000, min_keep de 0 a max_count. A política não executa exclusão automática.

```json
{"ability_name":"backups/prune","parameters":{"category":"sql_mutation","dry_run":true}}
```

Confira selection, blocked, selected_bytes e expected_selection_sha256. Aplique repetindo a categoria e enviando dry_run:false e o hash. Seletores repetidos precisam ser idênticos aos da prévia. Alternativamente, use artifact_ids com IDs completos de 32 caracteres; não misture IDs e política. ID explícito permite selecionar manual_export, restore_preimage e unknown completos, mas não ignora referências ou integridade.

Seleções são privadas, vinculadas ao usuário/conexão/site e válidas por 600 segundos antes do início. Novos arquivos não entram numa seleção existente. Criação, leitura e restore compartilham lock; poda é exclusiva. A espera padrão é 2 segundos. artifact_in_use e backup_selection_conflict não autorizam forçar a remoção. Operações em curso/incertas, diários pendentes e prévias válidas de restore protegem o dump. Recibos concluídos não impedem retenção para sempre.

Quarentena e remoção persistem por componente. backup_prune_partial retorna removed_bytes efetivamente retirados e remaining_count; retome com a mesma categoria/hash. O recibo concluído é reapresentado sem nova seleção. Tombstones preservam o histórico; operations/status.backup informa disponibilidade ou removed sem reaplicar SQL. Bytes retirados não equivalem à variação de espaço livre do volume.

## Backup SQL da tabela alvo

Somente db/execute admite backup_scope:selected_tables: uma instrução DML, uma tabela base InnoDB com identidade estável, sem outras fontes, joins, views, triggers ou chaves estrangeiras não modeladas. A tabela vem da análise SQL. DDL, db/batch e db/search-replace mantêm backup integral. Escopo reduzido inelegível recebe backup_scope_unsupported na prévia, sem escrita. Omitir o campo conserva database, inclusive em confirmações preservadas na 0.16.0.

```json
{"ability_name":"db/execute","parameters":{"sql":"UPDATE wp_exemplo SET valor='novo' WHERE id=1","backup_scope":"selected_tables"}}
```

Substitua wp_exemplo pelo alvo real permitido; o exemplo não deve ser aplicado literalmente. A prévia informa backup_scope e backup_tables, vinculados à confirmação. O dump inclui a tabela inteira, contém valores originais e é produzido/verificado na mesma conexão protegida antes da escrita. Falha de backup impede mutação. A resposta inclui backup_id/artifact_id, backup_bytes e backup_contains_sensitive_values.

O restore escreve apenas as tabelas do manifesto e preserva o estado MCP corrente conforme preserved-state/1. A prévia declara restore_tables e restores_entire_tables:true: alterações posteriores da tabela podem ser perdidas. Atividade fora do manifesto não altera a guarda do destino. O restore cria pré-imagem integral de segurança, classificada restore_preimage; considere esse custo ao estimar economia.

## Excluir e restaurar papéis

roles/delete exige role; roles/restore exige role e backup_id. Ambos exigem manage_options, perfil Manutenção e prévia/confirm_token, nunca exclusão imediata por confirm:true. Recusam exclusão de administrator/editor/author/contributor/subscriber, default_role e papéis atribuídos a qualquer usuário, inclusive usuários com múltiplos papéis. Códigos: role_protected, role_is_default, role_in_use, role_not_found e preimage_conflict.

```json
{"ability_name":"roles/delete","parameters":{"role":"papel_personalizado"}}
```

Após revisar a prévia, repita com confirm_token. A confirmação relê uso/default/capacidades, cria backup do alvo e verifica o estado gravado. O recibo informa role, persisted, changed, backup_id e operation_id. Uma confirmação concluída pode ser repetida sem novo efeito.

roles/restore restaura só o papel escolhido, verifica a pós-imagem esperada e faz backup da alteração atual. Restaurar a criação de um papel significa removê-lo, sujeito às mesmas guardas. Backups 0.15.0 de roles/update continham o mapa completo: o runtime extrai só a entrada escolhida e declara restore_legacy_without_postimage na prévia. Nunca repõe o mapa inteiro nem atribui usuários.

roles/update calcula a alteração dentro do lock. options/update de user_roles aplica as mesmas recusas antes da primeira escrita; use roles/delete/restore para operações pontuais. As rotas de usuários e alteração de default_role compartilham a coordenação. Escritores externos/SQL administrativo não cooperantes continuam fora do lock MCP; persistência incerta exige investigação. Capacidades humanas não reescrevem concessões do consumidor PHP Google.

## Recuperação conjunta Core 1.24.0 e Google 0.8.0

Consulte f3base/operacao-recuperacao-ler e google/recovery-status. Prepare Core com f3base/operacao-recuperacao, acao:preparar e geracao_esperada corrente; prepare Google com google/recovery, action:prepare. Aguarde pronto_para_restaurar:true do Core e ready_for_restore:true do Google. Essas barreiras não suspendem todo o WordPress nem processos externos.

Restaure somente após as duas guardas prontas. Releia ambas depois do restore: os arquivos de pausa fora do banco devem permanecer pausados. Reconcile options, concessões, conexões Google, jobs e contextos com o manifesto restaurado. Restauração de uma tabela de um provedor não comprova coerência de todo o seu estado. Não repita efeitos enviados às APIs.

Retome explicitamente cada provedor com geração atual: Google action:resume/expected_generation/acknowledge_reconciled:true; Core acao:retomar/geracao_esperada/reconciliacao_confirmada:true. Retomar um não retoma o outro. Core pode invalidar cursores/intenções/filas em tabelas não restauradas; registre esses efeitos como ações do provedor. Falha ou reconciliação incompleta mantém a pausa.

Core com sentinela ausente/divergente exige seu procedimento de recriação com precondicao_esperada e manter_pausado:true, seguido de preparar/drenar. O MCP não recria estado privado Core/Google. Use o guia incluído em cada pacote. Não atribua automaticamente f3base_ler_leads ou grants Google, nem fabrique sessão humana para o consumidor PHP.

## Inicialização da release

`ReleaseState` registra `migration/release:0.17.0`, conserva a option histórica `f3_mcp_release_version` para rollback e não recaptura credenciais. Schema desconhecido recebe `mcp_schema_unsupported`; persistência indisponível recebe `mcp_initialization_failed`, contendo o canal com HTTP 503. Veja ATUALIZACAO.md.


## system/probe

`contexto_teste` é booleano e opcional. Se omitido, o cabeçalho opcional `X-F3Base-Teste` determina a classe (`1` = teste; `0` = não marcado). Sem ambos, sai explicitamente `0`, sem herdar cookie ou cabeçalho do solicitante. Se ambos estiverem presentes, devem concordar. Cabeçalhos são comparados sem distinção de maiúsculas/minúsculas.

```json
{"ability_name":"system/probe","parameters":{"contexto_teste":true,"paths":[{"path":"/","assert":{"status":200}},{"path":"/wp-json/","assert":{"status":200}}]}}
```

Resultados e amostras incluem `contexto_teste`, `classe_trafego:teste|nao_marcado` e `traffic_class_scope:outgoing_request`. Isso informa a marca enviada, não prova coleta, consentimento, gravação ou contagem pelo Core. A marca não concede permissões. `success:true` indica execução da ferramenta; confira também `passed`, as asserções e `cache_bypass_verified`.

Códigos de recusa: `probe_test_context_invalid` (tipo/valor inválido), `probe_test_context_conflict` (argumento e cabeçalho discordam), `probe_header_conflict` (duplicatas discordam) e `probe_header_forbidden` (cabeçalho não permitido ou injeção). Cookies e Authorization permanecem recusados. A marca acompanha GET, HEAD, repetições, redirecionamentos da mesma origem e teste de armazenamento privado; sair da origem é recusado.

Sondas internas de troca/recuperação de plugins, temas, arquivos PHP, árvores e endereços usam `contexto_teste:true`. O executor 0.16.0 ainda em memória durante a atualização faz suas próprias sondas conforme o contrato antigo; a mudança vale para operações executadas pela 0.17.0.

O Core 1.24.0 reconhece o cabeçalho em `F3Base_Testes::resolver`. GET/HEAD da sonda não executa JavaScript nem envia um evento de navegador ao coletor de análise/comportamento. Portanto a ausência de evento nessas leituras não prova perda da marca. O MCP não fabrica métricas nem grava diretamente tabelas de medição do Core. A evidência da release distingue recepção da marca de persistência em métricas; encaminhamento separado ao Core trata essa lacuna do aceite solicitado.

## Recusa anônima MCP

GET sem credencial a `/wp-json/mcp/wp-mcp-fator3` e ao alias `/wp-json/mcp/wp-mcp-ultimate` continua recebendo 401. A recusa esperada não gera erro no error.log. `audit/list` expõe `ability:mcp/access-denied`, alvo da rota, `user:0`, `success:false` e `error_code:mcp_authentication_required`.

As avaliações repetidas de permissão para o mesmo objeto WP_REST_Request produzem uma única entrada. Requisições distintas continuam auditadas. Não são persistidos Authorization, cookies, corpo, query string ou IP nesse registro. Falha de gravação usa o diagnóstico existente de persistência de auditoria; não concede acesso. O tamanho da auditoria continua sujeito à retenção MCP.

Usuário autenticado sem a capacidade exigida é uma recusa diferente (`mcp_permission_denied`) e conserva aviso único. Erros inesperados do servidor continuam no log com diagnóstico sanitizado. Esta mudança não suprime globalmente `error_log` nem altera o servidor MCP próprio do Elementor.

## Diagnósticos Google 0.8.0

O selftest incompleto pode devolver `success:true`, `execution_success:true`, `result_status:incomplete` e `complete:false`, sem `error_code`. Isso não é aprovação de acesso externo nem erro MCP. Falha real conserva `f3_google_selftest_failed`; falha de execução usa `result_status:execution_error`. Não converter o texto “incompleto” em falha nem inferir acesso às APIs a partir do autoteste local. `google/preflight`, gates, grants e confirmações permanecem sujeitos ao contrato Google.
F3_GUIDE_CONTENT;
