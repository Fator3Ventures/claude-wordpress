<?php
/** Release observations are independent of data schema and package-origin permissions. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ReleaseState {
    public static function run(): array {
        try {
            return Locks::run(['release-initialization'=>LOCK_EX], static function(): array {
                $schema = get_option('f3_mcp_schema_version', 0);
                if (!in_array($schema, [0, 1, 2, '0', '1', '2'], true)) {
                    return Result::fail('mcp_schema_unsupported', 'Formato de persistência MCP não reconhecido; preserve os dados e confira a versão do schema.');
                }
                Persistence::install();
                $key = 'release:' . F3_MCP_FILES_VERSION;
                $journal = Persistence::get('migration', $key);
                if (($journal['status'] ?? '') === 'complete') return Result::ok(['changed'=>false]);
                // This option is consumed by the 0.16 recovery package. Do not overwrite it
                // with the new release or recapture credentials. Current version comes from PHP.
                $origin = get_option('f3_mcp_release_version', null);
                $origin = is_string($origin) && preg_match('/^[0-9A-Za-z.+-]{1,64}$/D', $origin) ? $origin : 'unrecorded';
                add_option('f3_mcp_014_credential_ids', [], '', false);
                Persistence::put('migration', $key, [
                    'from'=>$origin, 'to'=>F3_MCP_FILES_VERSION, 'status'=>'complete',
                    'finished_at'=>time(), 'data_schema'=>2,
                    'credentials_preserved'=>true, 'policies_preserved'=>true,
                ]);
                $saved = Persistence::get('migration', $key);
                if (($saved['status'] ?? '') !== 'complete') throw new \RuntimeException('Release checkpoint unavailable.');
                return Result::ok(['changed'=>true]);
            });
        } catch (\Throwable $error) {
            return Result::fail('mcp_initialization_failed', 'Persistência MCP indisponível; confira a instalação e o armazenamento.');
        }
    }

    public static function boot(): void {
        $result = self::run();
        if (!empty($result['success'])) {
            require_once F3_MCP_FILES_DIR . 'core/bootstrap.php';
            return;
        }
        add_action('admin_notices', static function(): void {
            echo '<div class="notice notice-error"><p>Fator3 MCP: inicialização incompleta. Confira a persistência e o armazenamento antes de usar o canal.</p></div>';
        });
        add_filter('rest_authentication_errors', static function($prior) use ($result) {
            $route = ConnectionEndpoints::request_route();
            if ($route === null || !ConnectionEndpoints::matches($route)) return $prior;
            return new \WP_Error($result['error_code'], $result['message'], ['status'=>503]);
        }, PHP_INT_MAX);
    }
}
