# Fechamento documental — 0.13.0

Atualização 0.14.0: base direta Google 0.13.0; adaptador Core de entrega 1.0.0 e leitura de transporte negociada 1.1.0, sem fila Google paralela. Prontidão é por conexão e exige verificação; resultado incerto não permite repetição automática. Evidências correntes e limites no relatório 0.14.0; as seções versionadas anteriores abaixo são históricas.

Os documentos editáveis desta árvore são compilados por `build/compile-documents.py` para `includes/Data/Documentation.php`. Painel e `google/documentation` consomem a mesma allowlist. O catálogo de 283 operações e schemas deriva do registro por `build/export-contracts.php`; execute ambos antes de formar o candidato. `build/check-docs.py` verifica correspondência, inventário, links e versão.

O relatório da rodada é externo e canônico. Sua cópia incluída no fonte antecede o fechamento do ZIP fonte; não contém hash circular. O instalador validado não é reconstruído na promoção. Provas anteriores preservadas no fonte são históricas e não contam como execução da 0.13.0.
