# Validação — 0.14.0

Escopo: pedidos 28/29, integração Core 1.40.0, compatibilidade de leitura Core 1.39.0, atualização Google 0.13.0→0.14.0, rollback de arquivos e isolamento. Mínimos executáveis: WordPress 7.1.2/PHP 8.3.6. MCP 0.24.0, Meta/LinkedIn 0.3.0 preservados.

`tools/release014.py` exige inventário exato do candidato e vincula por SHA-256 os testes nativos e puros. O laboratório usa PHP CLI server com quatro workers, MySQL isolado, transporte HTTP MCP, respostas Google simuladas e rede externa bloqueada. Exercita saída de processo, fatal PHP, SIGKILL, prova de intervalo ocioso e ambiguidade sem atribuir causa inventada. Não é execução PHP-FPM nem acompanhamento de três dias.

Resultados e contagens efetivamente executados constam do relatório externo e `evidence/014`. Provas 013 e anteriores são históricas. O gate específico não representa execução integral do PHPUnit nem de `tools/validate.py`/`build/build.py verify`; esses preservam requisitos próprios.

Pendentes: credenciais e acessos comerciais, processamento/atribuição GA4, Android WebView e Ads real, observação de três dias nos 12 sites, navegador visual, multisite/CDN e PHP-FPM. A versão Core no Site-Teste deve ser informada pelo relatório observado, sem inferir instalação a partir do ZIP recebido.
