# Guia de configuração e operação · Fator3 MCP Google 0.28.0

Comece em **Ferramentas → Fator3 MCP Google**. O seletor do topo define a conexão usada pelos formulários. Confira a identidade exibida antes de editar um recurso. Os controles identificados como globais valem para todo o site.

| Onde | O que fazer | Como conferir |
|---|---|---|
| Conexão → Identidade | Preparar e ativar conta de serviço ou OAuth. O nome e a criação de conexões ficam abaixo da autenticação. | Confira a identidade e o método em uso no topo. |
| Conexão → Serviços e recursos | Escolher o nível de cada serviço, seus recursos padrão e o acesso do projeto Ads. | Revise a seleção e salve. **Verificar acessos** abre o diagnóstico da mesma conexão. |
| Conexão → Permissões | Limitar contas, propriedades e operações ao escopo pretendido. | Confira a prévia antes de aplicar a política. |
| Conversões | Em GA4, selecionar propriedade e fluxo (stream). Em Google Ads, selecionar cliente e ação importada. | Consulte a lista de cada serviço, salve os destinos e use **Verificar destino**. |
| Acervo Ads | Escolher uma conta existente ou **Nova conta**. Ajustar dados, recuperação e revisita. | Confira os valores carregados da conta antes de salvar. Leitores têm autorização separada. |
| Search Console e GTM | Conferir propriedades ou contêineres e autorizações necessárias. | A consulta de recursos é solicitada explicitamente pelo administrador. |
| Incidentes e Avançado | Acompanhar falhas, diagnóstico, tarefas, auditoria e recuperação. | Use `google/readiness-status` para localizar o recurso e a ação indicada. |

## Google Ads

A conta anunciante (`ads_customer_id`) identifica o cliente consultado. A gerenciadora (`ads_login_customer_id`) identifica por onde a credencial acessa esse cliente. O nível do planejador vem da declaração feita a partir do Google Cloud Console. O resumo na aba **Acervo Ads** mostra o nível e as operações observadas neste WordPress. O manual **PLANEJADOR.md** contém as chamadas completas, em português.

## Conversões

Consulte propriedades e fluxos GA4 ou contas e ações Ads pelos botões do respectivo destino. Uma consulta completa atualiza por 15 minutos as opções daquela identidade, conta ou propriedade. Se a consulta falhar ou vier incompleta, o painel mantém a última lista completa enquanto seu cache for válido. Um destino salvo continua visível para revisão. Para gravar um novo segredo, preencha-o imediatamente antes de clicar em **Salvar destinos e autorização**.

Uma verificação usa a conexão exibida no formulário. Se o contexto mudou ou o painel indicar conflito de revisão, recarregue a tela, confira os valores atuais e aplique novamente a intenção. Consulte **AVISOS-RENOVACAO.md** para o prazo de atenção e a recuperação dos avisos.

## Acervo diário

Use **Conta para editar → Abrir conta** antes de alterar uma coleta existente. A tela carrega os conjuntos de dados, janelas e autorizações salvos para aquela conta. **Nova conta** começa com coleta desligada. A autorização para armazenar dados e a permissão de um plugin para lê-los são decisões separadas. Ao pausar a coleta, o histórico permanece disponível segundo a política da conexão.

## Diagnóstico local e verificação remota

`google/status` com `{"compact":true}` resume a configuração sem consultar o Google. `google/readiness-status` detalha credencial, armazenamento, executor e destinos. Use `google/ability-catalog` para ver se a operação está disponível na conexão. Em caso de Explorer, a leitura histórica já arquivada e as chamadas ao fornecedor têm condições diferentes. Para conferir os dados da conta ou validar uma permissão efetiva, execute a operação de leitura autorizada.
