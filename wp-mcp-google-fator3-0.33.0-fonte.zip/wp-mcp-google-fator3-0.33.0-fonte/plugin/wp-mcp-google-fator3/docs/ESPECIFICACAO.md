# Especificação · Fator3 MCP Google

Descreve a release instalada: objetivo, responsabilidades, comportamento, dados, efeitos, limites e recursos indisponíveis. Nomes de habilidades, campos e códigos conferem com o catálogo instalado (`ability-catalog.json`); em divergência, prevalece o schema executável.

## Objetivo

Dar a administradores do WordPress e a agentes autorizados acesso controlado às APIs Google — Analytics 4 (Data e Admin API), Google Ads (API e Data Manager), Search Console, Tag Manager, Site Verification, Sheets e Drive — por habilidades da Abilities API, com credencial guardada no servidor, política por recurso, confirmação de operações sensíveis, fila durável e auditoria.

## Responsabilidades e fronteiras

| Plugin | Responsável por | Não faz |
|---|---|---|
| Fator3 MCP Google (este) | Credenciais e identidades Google; chamadas às APIs Google; política por conexão, serviço e recurso; confirmação; fila e agendas de leitura/exportação; acervo Ads; entrega de conversões aos destinos Google; auditoria das chamadas | Não coleta eventos de visitantes, não guarda contatos nem pipeline comercial, não autentica clientes MCP, não opera Meta, LinkedIn ou Pipedrive |
| Fator3 Site Core | Medição no site (tags, consentimento, eventos), contatos, pipeline, histórico GSC por página e consulta, relatórios integrados, decisão de enviar uma conversão | Não guarda credencial Google; consome o Google por contratos públicos (`CONTRATOS-PUBLICOS.md`, `SDK-PHP.md`) |
| Fator3 MCP | Transporte MCP, autenticação do cliente, perfis e descoberta de habilidades, redação de campos sensíveis na saída | Não concede acesso a recursos Google; a autorização do Google é revalidada na execução |

Cada plugin decide por capacidade e contrato publicados. A ausência de um contrato de outro plugin torna indisponível somente a operação dependente.

## Modelo

| Conceito | Definição |
|---|---|
| Conexão | Conjunto nomeado (`connection_id`, padrão `default`) com identidade, serviços, recursos padrão e política. Opções de conexão diferente de `default` usam o prefixo `f3_mcp_google_conn_<id>_` |
| Identidade | Conta de serviço (JSON da chave, assunto opcional) ou OAuth (aplicativo Web e consentimento). Uma credencial candidata só substitui a ativa depois de validada |
| Serviço | `ga`, `ads`, `gsc`, `gtm`, `siteverification`, `sheets`, `drive`, cada um com nível de operação. Serviço desligado recusa com `f3_google_connector_off` |
| Recurso | Conta, propriedade, cliente Ads, site, contêiner ou planilha. Recursos padrão não concedem autorização |
| Política | `identity` (acesso da identidade) ou `restricted` (somente recursos listados). Conexões novas começam restritas. Recurso fora da política recusa com `f3_google_policy_denied` |
| Canal | Interruptor global `f3_mcp_google_enabled`. Fechado, as habilidades recusam com `f3_google_disabled`; os formulários administrativos permitidos continuam funcionando |

Ordem das recusas comuns (`includes/Gate.php`): canal fechado (`f3_google_disabled`) → permissão (`f3_google_forbidden`) → serviço desligado (`f3_google_connector_off`) → credencial ausente (`f3_google_not_configured`). Rotas de diagnóstico e catálogo funcionam sem credencial para informar o que falta.

## Permissões

Tela, leitura de dados de conta, leitura da documentação e escrita de configuração exigem `manage_options`. As habilidades exigem também a capacidade adicional do filtro `f3_mcp_google_capability` (padrão `manage_options`). Pelo MCP, o perfil da conexão MCP também precisa permitir a habilidade; a recusa do perfil pertence ao Fator3 MCP.

## Habilidades

Contagem por namespace, lida de `ability-catalog.json` desta release com o comando:

```
python3 -c "import json,collections as c;d=json.load(open('docs/ability-catalog.json'));t=c.defaultdict(c.Counter)
for n,a in d['abilities'].items():t[n.split('/')[0]][a['meta']['fator3']['mode']]+=1
print(d['total'],d['modes'],{k:dict(v) for k,v in t.items()})"
```

| Namespace | Total | Leitura | Escrita | Conteúdo |
|---|---|---|---|---|
| `google/` | 72 | 37 | 35 | Estado, prontidão, catálogo, documentação, configuração, conexões, política, consultas unificadas, fila e agendas, exportação, conversões, auditoria, recuperação, manutenção, atualização |
| `ga/` | 51 | 16 | 35 | GA4 Data e Admin API, perfil GA4 |
| `gsc/` | 13 | 6 | 7 | Search Console: propriedades, sitemaps, consulta, inspeção |
| `ads/` | 55 | 18 | 37 | Google Ads: consultas, mutações, acervo diário, planejador de palavras-chave |
| `gtm/` | 110 | 41 | 69 | Tag Manager: contas, contêineres, workspaces, versões, publicação |
| `siteverification/` | 4 | 2 | 2 | Verificação de propriedade do site |
| Total | 305 | 120 | 185 | |

`mode` classifica a ferramenta; `remote_effect` e `local_effect` em `meta.fator3` distinguem efeito no Google e efeito local. As habilidades `google/mcp-read` e `google/mcp-write` executam outra habilidade Google pelo nome, com os mesmos controles; no servidor MCP aparecem como as ferramentas `google-mcp-read` e `google-mcp-write` (parâmetros em `AGENT-GUIDE.md`).

## Dados gravados

| Onde | O que | Autoload |
|---|---|---|
| Options `f3_mcp_google_*` | Configuração pública e de conexão (definições em `configuration-definitions.json`: 43 opções, contadas com `python3 -c "import json;print(len(json.load(open('docs/configuration-definitions.json'))['options']))"`) | Sim, salvo as exceções abaixo |
| Options cifradas | `sa_json`, `oauth_client_secret`, `oauth_refresh_token`, `ads_developer_token`, `mp_secret` (segredo do Measurement Protocol), `candidate_sa`, `candidate_oauth` (lista em `Options::secret_names()`) | Não |
| Options operacionais | Projeções do cron (`f3_mcp_google_cron_*`), travas (`f3_mcp_google_lock_*`), cotas (`f3_mcp_google_quota_*`), `f3_mcp_google_maintenance`, `f3_mcp_google_cache_health`, `f3_mcp_google_token_index`, política de avisos `f3_mcp_google_conversion_renewal_notice` | Não |
| Transients `f3_mcp_google_*` | Tokens de acesso em cache (indexados por `token_index`) e cache de respostas até 100.000 bytes serializados | — |
| Tabela `{prefix}f3_google_records` | Repositório indexado: tarefas, agendas, deduplicação, confirmações e tentativas, incidentes, auditoria, recibos de conversão e de e-mail, publicações GTM, acervo Ads e recibos do planejador (payloads do acervo cifrados) | — |
| Tabela `{prefix}f3_google_cron` | Passagens e incidentes do executor por conexão | — |
| `wp-content/f3-google-state/site-{blog_id}.php` | Sentinela da guarda de recuperação | — |
| `wp-content/f3-google-cache/site-{blog_id}-*.php` | Cache de respostas grandes, cifrado, com preâmbulo PHP que responde 404 | — |

Segredos nunca são devolvidos por habilidade; `google/configuration-schema` informa apenas presença e legibilidade. O que a desinstalação remove está em `MIGRACAO.md`.

## Efeitos externos

| Efeito | Origem |
|---|---|
| Leituras nas APIs Google | Habilidades de leitura, diagnóstico com `live:true`, tarefas e agendas, acervo Ads, renovação de provas de conversão |
| Escritas nas APIs Google | Habilidades de escrita com `remote_effect: write`, sujeitas a política e confirmação |
| Envio de conversões | Data Manager (`events:ingest`) e GA4, somente pelos contratos de entrega chamados pelo Site Core |
| E-mail pelo `wp_mail` | Alertas configurados e avisos de renovação (`AVISOS-RENOVACAO.md`) |
| Download de pacote | `google/check-update` e atualização a partir da origem configurada pelo administrador |

Leituras locais (`google/status`, `google/readiness-status`, `google/ability-catalog`, `google/configuration-schema`, `google/documentation`) não chamam o Google. `google/status` com `live:true` pede um access token por serviço ligado e devolve só o veredito em `auth_probe`.

## Limites

| Limite | Valor |
|---|---|
| Linhas por consulta (`max_rows`) | 1–10.000, padrão 1.000 |
| Tempo limite HTTP | 5–120 s, padrão 30 |
| Orçamento GSC Search Analytics | 30/minuto e 1.000/dia por padrão; até 300 e 10.000 |
| Orçamento de inspeção de URL | até 1.000/dia (padrão 1.000) |
| Retenção de auditoria e de tarefas | `0` = sem prazo (padrão); detalhes até 365 dias, resumos até 730, auditoria até 5.000 eventos |
| Executor | 20 s por passagem, até 25 itens, compartilhado por MCP, cron e CLI |
| Catálogo | `limit` 1–100, padrão 30 |
| Documentação | página de 256 a 65.536 bytes |
| Confirmação | token de uso único, válido por 600 s |
| Cache em arquivo | 64 arquivos, 16 MiB por arquivo, 64 MiB por site, validade até 24 h |
| Histórico do cron | 8 dias, até 20.000 passagens e 1.000 incidentes por conexão |

Valores configuráveis e seus padrões: `configuration-definitions.json`.

## O que exige credencial, aprovação ou contrato de outro plugin

| Requisito | Afeta |
|---|---|
| Credencial Google ativa (conta de serviço ou OAuth) com acesso ao recurso | Toda chamada ao Google; sem ela, `f3_google_not_configured` |
| Developer token do Google Ads e nível de acesso aprovado (Test, Basic, Standard) | API Google Ads, descoberta de contas e ações; o planejador recusa Explorer e nível não informado com `f3_google_keyword_access_level` |
| Data Manager API habilitada no projeto Cloud e escopo `datamanager` | Entrega de conversões Google Ads |
| Fator3 Site Core com o contrato correspondente | Contexto de medição, finalidades de conversão, entrega de conversões, consumidores dos leitores GSC, GA4 e Ads |
| Fator3 MCP | Acesso de agentes remotos; perfil MCP que permita a habilidade |

## Não disponível nesta release

- Reverter uma versão instalada: correção é feita por nova versão.
- Desfazer efeitos remotos: não há rollback remoto nem execução exatamente uma vez; resultado incerto fica `unknown` e não é repetido automaticamente.
- Operar Meta, LinkedIn ou Pipedrive, ou coletar eventos de visitantes.
- Criar automaticamente eventos-chave, ações de conversão, tags ou publicações a partir do contexto do Site Core.
- Coleta completa de Google Ads por `google/query` (somente GA4 e Search Console aceitam `collection.mode: complete`).
- Aliases para nomes de campos de saída renomeados (`CONTRACTS.md`, seção de nomes de campo).
- Homologação em contas Google reais: a validação desta release usa respostas sintéticas (`VALIDACAO.md`).
