# Fator3 MCP Google 0.27.0

Pedido MCP Google 49. Atualização direta da 0.26.0 ou instalação limpa, com WordPress 7.1.4 ou superior e PHP 8.3 ou superior. O planejador funciona sem Site Core. Requer um administrador, canal habilitado, perfil Ads de leitura, credencial com escopo adwords e acesso à conta. A política da conexão precisa autorizar o cliente e os métodos consultados.

## Configurar e verificar acesso

1. Na página Google Ads API do projeto no Cloud Console, consulte o nível aprovado. Em Ferramentas → Fator3 MCP Google → Conexão → Acesso ao Google Ads, selecione o mesmo nível e salve. A declaração se vincula à identidade do projeto da conexão. A mudança para outro projeto exige nova declaração.
2. Configure o cliente em ads_customer_id da conexão. Para uma leitura, informe outro customer_id autorizado se necessário. O login_customer_id da gerenciadora é separado da conta alvo. connection_id seleciona a conexão. A URL usada como semente pertence à pesquisa, independentemente do WordPress que recebeu a chamada.
3. Leia google/status (aceita compact:true) ou google/readiness-status. ads_planning_access identifica o nível declarado, sua origem, os serviços bloqueados e a providência recomendada. A leitura é local. Unknown significa declaração ausente ou de outro projeto. Explorer bloqueia o planejamento antes de consultar o Google. Test só opera em conta de teste. Basic/Standard dependem de credenciais, permissões e disponibilidade do fornecedor. Um erro específico de nível conserva o motivo informado pelo Google.
4. operations_last_24h estima as operações Ads observadas neste WordPress para o projeto da conexão. A janela é móvel, arredondada ao minuto. Inclui tentativas respondidas e retentativas, pondera as mutações em lote e isenta páginas com token aceito. Exclui tráfego de outros sites e ferramentas. As cotas de produção e teste aparecem separadamente. Basic compartilha as 15.000 operações. Standard continua sujeito a limites por serviço.

## Consultar

Cada ability remota usa somente métodos de leitura do Google Ads. O efeito local é arquivar a leitura e atualizar a contagem. Por padrão, ideias e métricas usam Brasil (2076), português (1014), Google Search e os últimos 12 meses disponíveis do planejador. Pode-se passar geo, language, network e year_month_range. O campo geo é uma lista de até dez recursos geoTargetConstants. Exemplos para o MCP, em parâmetros JSON:

- ads/keyword-metrics — {"keywords":["cto as a service","cto fracionado","consultoria de tecnologia"]}
- ads/keyword-ideas — {"url":"https://www.engagia.com.br/","page_size":1000}. Use keywords, url, site ou keywords com url. Use site para domínio inteiro. Aceita page_size até 10000. A chamada percorre páginas, com checkpoint por página. Enquanto complete for false, repita ads/keyword-ideas com resume_id e a mesma conta/conexão, até o fim. Um cursor repetido gera erro explícito. A aquisição de páginas e a paginação do resultado arquivado são independentes.
- ads/keyword-forecast — {"campaign":{"adGroups":[{"keywords":[{"text":"cto fracionado","matchType":"PHRASE"}]}],"biddingStrategy":{"maximizeClicksBiddingStrategy":{"dailyTargetSpendMicros":"10000000"}}}}. campaign usa CampaignToForecast REST. forecast_period é opcional. A resposta explicita moeda, impressões, cliques e custo, com null onde a versão ou estratégia omite a métrica.
- ads/keyword-themes — {"keywords":["cto fracionado"],"ad_groups":["customers/1234567890/adGroups/456"]}. Envie grupos existentes da mesma conta. A resposta conserva sugestões de grupo/campanha e os grupos inutilizáveis.
- ads/keyword-archive — {"from":"2026-10-01","to":"2026-11-30"} lista as leituras por data UTC e cliente. Paginar listas com next_before_sequence. Para abrir use {"archive_id":"<id retornado>","limit":50,"offset":0}. Siga next_offset. Para requisições acima de 8192 bytes, reconstrua meta.request_part passando meta.next_request_offset como request_offset até null e confira meta.request_sha256. A resposta contém data, requisição efetiva, série mensal, concorrência, índice, variantes e moeda. Lances e CPC são convertidos de micros. Conceitos dependem de a API fornecê-los nas ideias. Ausência é preservada e zero continua zero. Credenciais, IDs de sessão e cabeçalhos não integram o arquivo.

## Cruzar com Search Console

Execute ads/keyword-metrics e use o archive_id completo. Depois chame google/blend:

```json
{"on":["query"],"join":"left","date_range":{"from":"2026-10-01","to":"2026-10-31"},"queries":[{"prefix":"gsc","connector":"search-console","accounts":["sc-domain:example.com"],"metrics":["impressions","clicks","position"],"dimensions":["query"]},{"prefix":"ads","connector":"keyword-planner","customer_id":"1234567890","archive_id":"<id retornado>"}]}
```

Também aceita on:["keyword"]. A junção compara textos após aparar espaços e normalizar caixa, conserva acentos e recusa chaves duplicadas. Cada grupo Ads participa sob o termo canônico retornado. Um volume de variantes agrupadas nunca é distribuído por várias consultas. O intervalo do GSC e a janela histórica da pesquisa permanecem separados. Use full para incluir termos exclusivos das duas fontes.

## Operação e aceite

Descubra as quatro consultas e o leitor local com google/ability-catalog. Se a conta do projeto estiver no Explorer, o dono conclui a verificação de marca e solicita Basic. Com aprovação, comparar três palavras no painel Ads no mesmo dia, idioma, local e rede, testar a URL Engagia e consultar o histórico de alterações da conta. Acesso de produção exige a autorização aplicável. Referência de medição GA4 e stream continuam em CONVERSOES.md.

Os instantâneos cifrados usam o repositório já instalado. Não há cron de planejamento, migração destrutiva ou novo grant para o Core. Uma leitura incompleta é identificada por complete:false. Para outra operação que falhar, iniciar uma nova consulta mantém o registro separado. Faça backup dos dados e salts antes de uma troca. Correções posteriores entram em nova versão.

Referências do fornecedor: [níveis e permissões](https://developers.google.com/google-ads/api/docs/api-policy/access-levels), [cotas](https://developers.google.com/google-ads/api/docs/best-practices/quotas), [ideias](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-keyword-ideas), [histórico](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-historical-metrics), [previsão](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-forecast-metrics) e [temas](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-ad-group-themes).
