# Conversões por finalidade: leitura e diagnóstico

`google/conversion-context` lê a configuração local pública de **contato** e **material**. Usa o SDK opcional `F3Base_Conversoes_Contexto`, contrato `site-conversion-purposes/1.0.0`, provider `base-site-core-fator3`, `schema_revision:"1"`. A leitura funciona sem credencial Google; exige `manage_options`, capacidade adicional configurada, canal habilitado e perfil MCP autorizado. A chamada direta do callback aplica o mesmo gate administrativo.

## Descobrir e ler

1. Descubra `google/conversion-context` no catálogo e confira seu schema.
2. Execute `{}`. `connection_id` opcional usa as políticas daquela conexão, mas o contexto continua sendo do site. O seletor nunca é enviado ao Core.
3. Leia `success`, `core_conversion_context.ok` e `code`; somente `ok:true` contém `data` válida.
4. Para exigir a mesma fotografia, repita com `expected_revision` igual à revisão retornada. Não há `offset` nem `limit`.

A resposta conserva o envelope Google e aninha o envelope Core exato: `ok`, `code`, `contract`, `provider`, `data`. Decorações normais do executor/transportador continuam presentes. Falha desta operação produz `success:false` e `error_code:f3_google_core_conversion_<code>`, mantendo o código original e `data:null` no bloco. Recusa anterior de autorização não expõe o contexto.

Em sucesso, `data` contém `scope:site_configuration`, `revision`, `measurement_revision`, `observed_at`, `purposes` e as flags `runtime_verified:false` e `remote_access_verified:false`. São exatamente duas finalidades, identificadas pelo campo `purpose`, independentemente da ordem.

| Finalidade | Evento GA4 | Evento Meta | Google Ads / LinkedIn |
|---|---|---|---|
| contact | generate_lead | Lead | Identificadores locais de contato |
| material | download_material | MaterialDownload | Rótulo Ads e conversion_id LinkedIn próprios de material |

Cada finalidade contém os destinos `ga4`, `google_ads`, `meta`, `linkedin`, com `enabled`, `configured`, `identifiers` e `provenance`. Meta/LinkedIn são somente informação pública do Core nesta leitura. O Google não opera essas APIs.

`enabled:true/configured:false` é válido: o destino está ligado, mas faltam identificadores locais. String vazia e null permanecem distintos. Material não herda rótulo Ads ou ID LinkedIn de contato. Um mesmo Measurement ID ou AW-ID pode ser compartilhado entre finalidades; os eventos/rótulos as distinguem. `configured:true` não prova ação cadastrada na conta, permissão, consentimento, disparo nem entrega. Um rótulo web Ads não é um resource name de conversion action.

## Conflito de revisão

A recusa validada `revision_conflict` retorna `conflict:true` e `retryable:false`, tanto no callback administrativo quanto pelo MCP. O bloco Core permanece `ok:false/code:revision_conflict/data:null`. Outros erros não são classificados como conflito. Repetir a mesma guarda obsoleta não resolve a divergência: releia sem `expected_revision`, examine a fotografia e só então use a nova revisão.

O SDK não traz a revisão atual no ramo de erro, portanto `current_revision` é omitida nesse caso. Se o produtor devolver uma fotografia de sucesso válida mas divergente da guarda, a defesa do consumidor recusa essa fotografia e informa sua `data.revision` como `current_revision`. Não existe uma segunda leitura, hash fabricado ou substituição por `measurement_revision`/revisão Google. A extensão não altera o schema Core. O parâmetro de saída opcional do adaptador interno é reinicializado em cada chamada.

Exemplo de recusa normal: `success:false`, `error_code:f3_google_core_conversion_revision_conflict`, `conflict:true`, `retryable:false`, sem `current_revision`.

## Falhas e ausência

| code | Tratamento |
|---|---|
| unavailable | Estado do consumidor: classe pública ausente; demais recursos Google continuam disponíveis |
| unsupported | Método/versão/schema incompatível, resposta malformada ou invariante inválida; não usar os dados |
| invalid_input | Entrada fora do contrato; corrigir parâmetros |
| unreadable | Produtor ilegível ou exceção sanitizada; diagnosticar sem converter em configuração vazia |
| revision_conflict | Configuração mudou; reiniciar a leitura, sem juntar fotografias |
| not_authorized | Recusa informada pelo produtor; não contornar o gate |

`unavailable` não foi adicionado ao enum do produtor. Os schemas originais são mantidos, e o schema de saída Google declara separadamente esse estado local. O consumidor valida descritor, métodos e payload contra cópias empacotadas: não importa classes internas, options privadas nem abre caminhos anunciados pelo produtor. Não busca schemas na rede.

## Diagnóstico GTM

`gtm/diagnostico` conserva `core_context`, `core_events`, seis slots e análise estática da versão publicada. Traz também `core_conversion_context`. O contexto de medição usa `site-measurement-context/1.0.0`, cujo catálogo não inclui `download_material`.

O diagnóstico obtém a fotografia de conversões antes da leitura GTM já existente, compara `measurement_revision` com o contexto de medição utilizado e revalida a revisão de conversões depois. Se somente o contexto de conversões divergir ou ficar indisponível, o diagnóstico de medição válido permanece e o bloco adicional retorna falha com `data:null`. A alteração do contexto de medição mantém seu próprio erro. Não há repetição automática da chamada GTM por conflito.

A leitura GTM continua exigindo a credencial/serviço e acesso já previstos. Correspondência literal de identificadores permanece análise estática, sem prova de disparo.

## Efeitos, configuração e compatibilidade

O adaptador puro não grava nem acessa a rede. A operação é leitura local, `remote_effect:none`; auditoria sanitizada segue a política existente, inclusive falhas e `audit_local_reads:true`. Leituras não reparam storage, agendas ou configuração. Não são criados eventos-chave, ações Ads, tags, publicações, campanhas, grants, bindings ou jobs automaticamente.

A instalação do Google não depende de versão, presença ou ordem de ativação do Site Core. A leitura não usa credencial, opção, tabela ou migração própria.

## Booleanos efetivos na configuração

`google/configuration-schema` retorna true/false em `state.effective_value` das cinco opções declaradas booleanas: `enabled`, `ga_enabled`, `ads_enabled`, `audit_local_reads`, `purge_on_uninstall`. `persisted_value` continua representando o armazenamento WordPress e pode ser `""`/`"1"`. Campos textuais, null e dados de opções compostas não são convertidos por essa correção.

Para conferir `audit_local_reads:false`, use `google/configure-local` com o booleano false e `expected_revision` obrigatório obtido na leitura da configuração; leia `google/configuration-schema` em nova requisição. O resultado efetivo deve ser booleano false. A escrita continua sujeita aos gates e à revisão.

## Exemplos

Consulta local: `google/conversion-context {}`. Sucesso: `success:true`, bloco `ok:true/code:ok`; o material pode ter `enabled:true/configured:false` e IDs vazios. Ausência: `success:false`, `error_code:f3_google_core_conversion_unavailable`, bloco `ok:false/code:unavailable/data:null`.

Conflito: envie `expected_revision` de uma fotografia anterior após mudar a configuração de material; a resposta deve ser `revision_conflict`, com `data:null`. No diagnóstico GTM, esse mesmo bloco parcial não transforma uma análise antiga válida em prova de configuração ou entrega de material.

Os documentos instalados `core-conversions-capabilities.json`, `core-conversions-snapshot-input.json` e `core-conversions-snapshot.json` são cópias dos schemas do SDK PHP; o schema da operação Google está em `ability-catalog.json`. As fixtures do produtor e os testes adversários ficam no fonte, fora do runtime público.

## Limite desta leitura

`site-conversion-delivery` não é o contrato deste leitor; a entrega usa o adaptador separado descrito em [CONVERSION-DELIVERY-CORE-140.md](CONVERSION-DELIVERY-CORE-140.md). O contrato de leitura mantém `configured` como disponibilidade de identificadores locais; não representa transporte, segredo MP, permissão Ads ou entrega. A mudança operacional de contato no Site Core requer coordenação e homologação próprias. Material e o diagnóstico GTM preservam seus contratos.


## Configuração e verificação dos destinos

Alterar Ads preserva a prova GA4, e vice-versa. Uma configuração parcial preserva campos omitidos; vazio explícito limpa o campo. Desabilitar a integração invalida ambas. As concessões são mantidas por destino, sem transferir a autorização de um destino ao editar outro.

Na verificação, o retorno `provider_error` traz apenas HTTP, estado, motivo, mensagem sanitizada e violações de campo. O incidente mostra o mesmo diagnóstico. NOT_FOUND em destination_references registra uma tentativa pendente e nova validação em 5 minutos, com espera progressiva até 1 hora. Não presume propagação como causa. Nenhuma conversão é coletada. A tentativa só continua com a mesma configuração, credencial, política e autorização. Sucesso remove a pendência e renova a prova por 24 horas.

A reconciliação assíncrona é feita pelo Site Core com o contrato `site-conversion-reconcile/1.0.0`.


## Prontidão

O check `credential` bloqueia o canal fechado mesmo com credenciais válidas. Um fluxo GA4 selecionado sem ID de medição do Core e um destino Ads incompleto são bloqueados; destinos não selecionados e integrações desabilitadas continuam opcionais. Configuração ilegível bloqueia a operação. `verification_pending` só produz atenção quando a causa efetiva é `verification_required`; autorização revogada e demais bloqueios prevalecem.

Incidentes abertos são filtrados por conexão antes da paginação. `detail.open` conta os incidentes lidos (máximo 100); `detail.complete=false` informa que existem mais. `items` conserva os primeiros dez. O estado `attention` significa que a conexão requer atenção, sem afirmar disponibilidade. Não há consulta ao Google nem alteração de configuração no diagnóstico.
