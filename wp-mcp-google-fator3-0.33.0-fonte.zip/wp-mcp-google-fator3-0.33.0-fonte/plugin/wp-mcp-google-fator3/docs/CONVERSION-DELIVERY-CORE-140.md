# Conversões pelo servidor: GA4 e Google Ads

Contratos e operação da entrega de conversões que o Fator3 Site Core solicita ao Google. O Google valida destino, identidade e prova antes de cada envio; o Site Core decide o que enviar e mantém captura, consentimento e fila comercial. Leitura do contexto de finalidades: `CONVERSOES.md`. Política de e-mail das renovações: `AVISOS-RENOVACAO.md`.

## Contratos

| Contrato | Uso |
|---|---|
| `site-conversion-delivery/1.0.0` | Aquisição: `send(payload)` e `sendBound(payload, destinationRef)` para GA4 e Google Ads |
| `site-conversion-delivery/1.1.0` | Igual a 1.0.0, com dados do usuário opcionais para conversões otimizadas de leads no Google Ads (`enhanced_leads`) |
| `site-conversion-delivery/1.2.0` | Conversões comerciais por etapa (`consumer_id` `site-core-quality`, `purpose` `crm_stage`), por ação Google Ads concedida |
| `site-conversion-reconcile/1.0.0` | `reconcileBound(recordId, destinationRef)`: consulta do resultado assíncrono da aquisição Ads, sem reenvio |
| `site-stage-conversion-reconcile/1.0.0` | `reconcileBound(eventId, destinationRef)`: o mesmo para conversões por etapa |

O consumidor obtém o adaptador pelo filtro `f3base_conversoes_adaptador` com target (`ga4` ou `google_ads`) e o contrato exato. `capabilities.contract` reflete a versão solicitada; `supported_contracts` anuncia as aceitas. Sem o método de reconciliação no consumidor, Ads informa `core_async_unsupported`.

## Configuração e autorização

Configure pelo painel (**Conversões**) ou por `google/configure-conversion-delivery` com `expected_revision` (campo `revision` de `google/conversion-delivery-status`). O ID de medição GA4 vem do contexto de medição do Site Core; o campo `measurement_id` da configuração é aceito, mas substituído pelo valor efetivo do Core. O segredo do Measurement Protocol é cifrado por conexão; vazio preserva e a remoção é explícita (`clear_mp_secret`).

`google/conversion-delivery-status` e `google/status` são leituras locais. A conexão de um destino é a que tem esse destino configurado: fluxo (`stream`) para GA4, ação de conversão para Ads. Mais de uma conexão habilitada para o mesmo destino bloqueia a prontidão. A prontidão também aparece em `google/readiness-status` (checks `conversion_ga4` e `conversion_google_ads`).

`google/verify-conversion-delivery {"expected_revision","target"}` verifica explicitamente. GA4 exige fluxo pertencente ao ID de medição do Core e segredo conferido na Admin API, seguido de validação de debug sem ingestão. Configuração idêntica não revoga a prova; mudança de configuração, credencial, segredo, destino, concessão, política, serviços ou geração de recuperação exige nova verificação. Alterar Ads preserva a prova GA4 e vice-versa.

## Prova e renovação

A prova vale 24 horas; o executor tenta renová-la após 12 horas com as mesmas consultas da verificação, sem coletar evento nem conversão. Falha mantém a prova até expirar, registra incidente e agenda nova tentativa em 5, 10, 20, 40 e depois 60 minutos. Renovação recupera prova expirada se identidade e autorização permanecerem iguais.

`renewal` por destino informa `phase`, `provider_error`, `last_at`, `result`, `code`, `next_attempt`, `failures`, `attempts`, `attempt_count`, `cycle_started_at`, `proof_status`, `unverified_since` e `unverified_seconds`. Fases GA4: `ga4_stream_read`, `ga4_secret_read`, `ga4_secret_match`, `ga4_debug_validation`; `execution` para falha de orçamento. Cada tentativa é registrada em `google/audit` como `conversion:verification`. `NOT_FOUND` em `destination_references` registra pendência e nova validação em 5 minutos, até 1 hora.

## Google Ads pela Data Manager

Requisitos: Data Manager API habilitada no projeto Cloud; conta de serviço ou OAuth com escopo `https://www.googleapis.com/auth/datamanager` e acesso Padrão ou Administrador à conta Ads; para conta de serviço, Service Usage Consumer no projeto. OAuth sem o escopo precisa de novo consentimento. A ingestão não envia developer token; a consulta de contas e ações usa a Google Ads API com developer token e nível aprovado. `google/selftest` descreve esses requisitos em `data_manager`.

A ação deve ser Site — Importação de cliques (`UPLOAD_CLICKS`), ativa. A verificação lê a ação, valor e moeda e executa `events:ingest` com `validateOnly:true`; isso confirma a verificação técnica, não a atribuição. O valor e a moeda enviados são os da última verificação ou renovação.

O adaptador exige exatamente um identificador `gclid`, `gbraid` ou `wbraid` (ou, com `enhanced_leads` pronto, nenhum clique e dados do usuário), consentimento de dados publicitários concedido, `order_id = record_id`, identidade e data válidas. Envia um evento e um destino por requisição. Antes do HTTP registra intenção durável (tipo `conversion`, sem dados de contato ou clique); depois registra `requestId`. Repetir `send` ou `sendBound` para o mesmo registro consulta o recibo e não repete a ingestão. Sem `requestId` recuperável, o resultado permanece incerto.

### Conversões otimizadas de leads (1.1.0)

A verificação consulta também os termos de dados do cliente e a habilitação de conversões otimizadas; o resultado aparece em `enhanced_leads` (conta, ação, `ready`, `reason`, `checked_at`, `expires_at`). Sem observação válida: `enhanced_leads_unverified`.

No payload Ads, `user_data:{email, telefone}` é opcional e exige consentimento elegível; telefone em E.164. Os valores são normalizados e enviados como hash SHA-256 (`encoding: HEX`) em `userData.userIdentifiers`. Dados fornecidos sem prontidão: `enhanced_leads_not_ready`, sem envio; dados inválidos: `enhanced_leads_user_data_invalid`. GA4 não aceita dados pessoais.

### Conversões comerciais por etapa (1.2.0)

Conceda cada ação comercial (`UPLOAD_CLICKS` ativa, diferente da aquisição) e verifique:

```json
{"ability":"google/stage-conversion-status","parameters":{}}
{"ability":"google/configure-stage-conversion","parameters":{"expected_revision":"<revisão atual>","action":"customers/1234567890/conversionActions/222","enabled":true}}
{"ability":"google/verify-stage-conversion","parameters":{"expected_revision":"<revisão após a concessão>","action":"customers/1234567890/conversionActions/222"}}
```

`configure-stage-conversion` não faz HTTP; `verify-stage-conversion` consulta ação e termos e faz `validateOnly`. `enabled:false` revoga; `renew_grant:true` cria geração nova e exige nova prova. Até 100 ações armazenadas por conexão. A prova vale 24 horas, renovada a partir de 12 horas (até duas ações devidas por conexão e passagem).

`sendBound(payload, destination_ref)` aceita somente o schema `stage-conversion-payload.json`. Regras: `order_id` igual a `event_id`; `occurred_at` RFC 3339, não futuro e com no máximo sete dias; no máximo um clique; sem clique exige e-mail ou telefone e `enhanced_leads.ready`; valor zero e moeda BRL. A deduplicação persiste por site, ação e evento; a mesma identidade com contato, etapa ou data diferentes é conflito.

```json
{"contract":"site-conversion-delivery/1.2.0","purpose":"crm_stage","record_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","stage_id":"qualificado","action":"customers/1234567890/conversionActions/222","event_id":"f3q-exemplo-estavel","order_id":"f3q-exemplo-estavel","occurred_at":"2026-10-28T10:00:00Z","click_ids":{"gclid":"exemplo"},"ad_user_data":"GRANTED","value":0,"currency":"BRL","user_data":{"email":"contato@exemplo.com.br"}}
```

`google/reconcile-stage-conversion {"action","event_id","destination_ref"}` atualiza só o recibo do Google, sem reenviar.

## Confirmação assíncrona

A consulta (`requestStatus:retrieve`) começa 30 minutos depois do envio e usa espera crescente até 6 horas; não recebe dados do contato. `SUCCESS` com o destino correspondente e `recordCount = "1"` confirma o registro (cada requisição tem um evento e um destino). `PROCESSING`, `PARTIAL_SUCCESS`, divergência, perda de resposta ou erro desconhecido permanecem `incerto`. `FAILED` vira `recusado` com `non_delivery_proven` somente para rejeição explícita do único registro. Nenhuma consulta repete o envio.

O método direto `ads/upload-click-conversions` é recusado antes do HTTP sem comprovação administrativa vigente vinculada à mesma identidade, token e destino; a entrega usa a Data Manager.

## Recuperação

Recibos ficam no repositório indexado e servem à deduplicação: não apague recibos nem reabra registros incertos para forçar novo envio. Backup e restauração preservam banco, salts e a guarda de recuperação; restauração não desfaz conversões enviadas. Aceites com conversão real (primeiro contato com clique, segredo revogado, e-mail antes do vencimento) são feitos pelo operador e não são substituídos pela validação local.

## Referências oficiais

- [Ingestão e validateOnly](https://developers.google.com/data-manager/api/reference/rest/v1/events/ingest)
- [Conversões offline e ação exigida](https://developers.google.com/data-manager/api/devguides/events/google-ads/offline/send-events)
- [Consulta assíncrona](https://developers.google.com/data-manager/api/reference/rest/v1/requestStatus/retrieve)
- [Diagnóstico e intervalo inicial](https://developers.google.com/data-manager/api/devguides/diagnostics)
- [Acesso](https://developers.google.com/data-manager/api/devguides/quickstart/set-up-access)
- [Implantação e conta de serviço](https://developers.google.com/data-manager/api/devguides/concepts/deploy)
