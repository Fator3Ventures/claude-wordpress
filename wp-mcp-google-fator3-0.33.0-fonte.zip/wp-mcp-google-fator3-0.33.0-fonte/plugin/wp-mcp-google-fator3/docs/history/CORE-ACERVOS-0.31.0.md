# Histórico — não descreve a release instalada

Cópia integral do documento instalado na 0.31.0, retirada do índice na 0.32.0. Mantida no fonte para consulta; não vale como documentação da release instalada. Os links locais foram ajustados para a pasta docs/history/.

# CORE-ACERVOS · 0.29.0

O guia GUIA-0.29.0.md descreve as telas atuais. Para instalação, atualização ou correção use MIGRACAO.md. O catálogo e os schemas instalados descrevem as interfaces vigentes.

## Referência técnica e histórico de contratos

# Referência operacional — Google 0.26.0

Base direta 0.25.1. Matriz desta rodada: Core 1.66.0, MCP 0.38.0, Meta 0.18.0 e LinkedIn 0.14.0. Pedido 48 e limites da rodada estão no guia GUIA-0.26.0.md e no relatório externo. As seções versionadas herdadas abaixo descrevem capacidades e evidências históricas; não definem a base corrente nem representam novos testes. Contratos e políticas aqui descritos permanecem, exceto a cópia de transporte 1.1.0 alinhada ao Core (ambos e invalid_output).

# Integração com o Core — Google 0.24.0

O Core 1.61.1 incorpora os consumidores `google-ads-reader/1.0.0` e `search-console-reader/1.1.0`, com identidade `base-site-core-fator3`. Os contratos GSC 1.0, GA4 e conversões anteriores permanecem. O produtor Google controla credenciais, coleta Ads e concessões; o Core mantém configuração, contatos, relatórios e histórico GSC.

## Configuração e permissões

| Configuração | Dono | Uso |
| --- | --- | --- |
| `f3base_google_ads_acervo` | Core | Seleção do leitor Ads: ativo, conexao, conta_id, revisao, parceiros e parceiro_padrao. |
| `f3base_google_ads` | Core | Conversão/tag existente. Não usar esta opção para o leitor do acervo. |
| `ads_archive` | Google | Concessão de coleta por conexão, conta e datasets. |
| `ads_consumer_grants` | Google | Concessão de leitura local por consumidor, conexão, conta e datasets. |
| `f3base_gsc_consultas` | Core | Agenda de consultas por página; propriedade e prova vêm da configuração GSC existente. |
| `query_consumer_grants` | Google | Concessão independente ao contrato GSC 1.1. |

Use as APIs públicas de cada dono. No Core, leia `f3base/config-core-ler` com `nome` e simule/aplique por `f3base/config-core-escrever`. Preserve campos não alterados usando o schema retornado; `revisao_esperada` é a revisão opaca da escrita, enquanto o campo inteiro `revisao` da seleção deve crescer. São controles diferentes. Confira `persisted`, `effect` e `verification` e releia antes de conceder no Google. Alterar ou restaurar seleção/revisão invalida a concessão anterior; reautorizar exige ato explícito.

Leitura/configuração exige `manage_options`. O leitor Core exige também `f3base_ler_leads` para datasets diferentes de `changes`; em `changes`, essa capacidade controla a autoria. Sem ela, o Core preserva valores operacionais e retira autoria/metadados pessoais. O Google exige administrador e revalida identidade, política, canal e concessão. O registro do consumidor não concede acesso; não há fallback por credencial administrativa.

## Sequência Ads

1. No Google, configure a conexão, developer token, serviços e política para a conta anunciante de dez dígitos. Confirme acesso com o operador autorizado.
2. No Core, selecione `f3base_google_ads_acervo` com conexão, conta e revisão positiva. A seleção entra desligada por padrão. O mapa de parceiros usa IDs explícitos de campanhas.
3. Leia `google/integration-status` com `compact:true` para obter a revisão Google atual e conferir o consumidor. Autorize a coleta com `ads/archive-configure` e, separadamente, o leitor com `ads/archive-consumer-grant`. Releia a revisão antes de cada escrita. Exemplos de campos estão em [ACERVO-ADS-GSC.md](../ACERVO-ADS-GSC.md).
4. Execute a coleta autorizada ou acompanhe o worker. `ads/archive-status` não inicia HTTP. A coleta de um recorte pode exigir várias chamadas; aguarde publicação e confira cobertura.
5. Consulte `f3base/google-ads-acervo-status` e `f3base/google-ads-acervo-ler`. A leitura usa somente o acervo local; não coleta nem consulta o fornecedor.

```json
{"ability":"f3base/config-core-ler","parameters":{"nome":"f3base_google_ads_acervo"}}
{"ability":"google/integration-status","parameters":{"compact":true,"connection_id":"default"}}
{"ability":"f3base/google-ads-acervo-status","parameters":{}}
{"ability":"f3base/google-ads-acervo-ler","parameters":{"de":"2026-10-27","ate":"2026-10-27","dataset":"campaign","limite":500}}
```

Exemplos são sintéticos; descubra os schemas instalados antes de executar. O Core lê uma página/dia por chamada, até 1000 linhas, em período de até 366 dias. Continue `proximo_cursor` inclusive se um filtro deixar a página vazia. Reinicie após mudança de seleção, concessão, recorte ou conjunto de contatos. Revisões são diárias; não há fotografia global simultânea do período.

O job Core `google_cliques` relaciona GCLID por igualdade exata e registra origem, conta, revisão e cobertura em sessões/contatos. Busca a data UTC de entrada/captura e os dias adjacentes; isso não garante localizar um clique antigo reutilizado. Ambiguidade permanece explícita. Termo de busca individual continua nulo quando o fornecedor não o oferece. Revogação ou mudança de origem impede exibir observação antiga.

`f3base/relatorios-integrados-ler`, `visao=campanhas`, apresenta acervos Google/Meta separadamente, com `google_ads_cursor` e `meta_ads_cursor`. `google_ads_dataset` seleciona o nível. Não somar moedas, revisões ou métricas sobrepostas. `f3base/anuncios-alteracoes-ler`, `plataforma=google_ads`, consulta alterações por entidade/campo, mantendo limites e autoria protegida.

## Sequência GSC consulta × página × dia

Configure e valide a propriedade GSC pelo Core. Ative `f3base_gsc_consultas` com horário, início e revisão; a propriedade deve cobrir o site e o armazenamento Core deve estar pronto. Conceda `search-console-reader/1.1.0` ao consumidor `base-site-core-fator3` na conexão Google desejada. A concessão 1.0 não autoriza consultas e deve permanecer independente. Mais de uma conexão elegível exige resolver a ambiguidade explicitamente.

```json
{"ability":"f3base/config-core-ler","parameters":{"nome":"f3base_gsc_consultas"}}
{"ability":"f3base/gsc-consultas-status","parameters":{}}
{"ability":"f3base/gsc-historico","parameters":{"escopo":"consultas","dia":"2026-10-26"}}
```

O Core publica o dia em transação somente depois da conclusão explícita. Página curta permanece parcial; revisão incompleta preserva a publicação anterior. A coleta pode consultar Google; a leitura do histórico consulta o banco Core. O calendário dos dados é America/Los_Angeles. Use `f3base/gsc-consultas-coletar` conforme o schema e acompanhe status/histórico/lacunas. O relatório editorial aceita `visao=gsc`, `gsc_escopo=consultas`, `pagina_url` e `consulta` exatas; o histórico por página anterior permanece separado.

`all_rows_guaranteed=false` e limites/anonimização acompanham a cobertura. Quantidade e cliques de consultas anônimas não são fornecidos: continuam nulos com motivo. A diferença entre universos página/dia e consulta/página/dia não é uma contagem exata de anonimização.

## Atualização, diagnóstico e aceite

Não copie nem carregue `integration/core337-340-342` sobre o Core 1.61.1. A proposta histórica foi incorporada e ampliada pelo Core; o bootstrap entregue nesta versão está desativado para impedir reaplicação e colisão de classes/hooks. Seu nome de opção de referência foi corrigido. Também não reaplique `integration/core323`: a reconciliação já foi incorporada desde o Core 1.59.

Seleção incompleta, concessão ausente, coleta incompleta, dia publicado vazio e erro de leitura são estados distintos. Use `coverage.archive_state`, `latest_collection_state`, `previous_complete_preserved` e os motivos Core antes de concluir ausência de atividade. Zero só é observado na linha/dia com cobertura correspondente.

O aceite em ctooffice exige: GCLID de um dia conferido contra `ads/search`; 30 dias de custo/cliques por campanha/moeda iguais à origem; alteração real de orçamento no acervo; e consulta/página/dia comparada ao GSC com limites explícitos. Fixtures e prontidão local não encerram esses aceites. Não gere gasto, conversão ou alteração de campanha para fabricar prova.

Atualizar Google não altera automaticamente seleção, grants ou agenda Core. Faça backup de banco, arquivos e salts. Ao reverter somente Google para 0.23.0, os mesmos contratos e dados continuam disponíveis; confira jobs/recibos e não repita efeitos externos. A antiga orientação do adaptador permanece inadequada ao Core atual mesmo após rollback.
