# Histórico — não descreve a release instalada

Cópia integral do documento instalado na 0.31.0, retirada do índice na 0.32.0. Mantida no fonte para consulta; não vale como documentação da release instalada. Os links locais foram ajustados para a pasta docs/history/.

# Contratos do Google · 0.31.0

O guia GUIA-0.31.0.md descreve as telas atuais. Para instalação, atualização ou correção use MIGRACAO.md. O catálogo e os schemas instalados descrevem as interfaces vigentes.

## Referência técnica e histórico de contratos

# Contratos correntes — Google 0.26.0

Base direta 0.25.1. Pedido 48 sincroniza a cópia de site-conversion-purposes/1.1.0 com Core 1.66.0: navegador, servidor e ambos em selected/effective; invalid_output no envelope de erro. Mantém validação integral, 300 habilidades (115 leitura, 185 escrita), 42 opções, configuração 4.0.0 e execução/armazenamento/manutenção 2.0.0. Não há alteração de contratos de envio, grants, fila ou banco.

A correção Core 363 foi incorporada no Core 1.66.0. core_transport.ok não substitui a prontidão de cada destino; LinkedIn indisponível continua legível sem invalidar GA4/Ads. Os avisos do pedido 47 permanecem em [Avisos de renovação](../AVISOS-RENOVACAO.md). A integração Ads/GSC e a reconciliação comercial existentes permanecem.

As seções abaixo são histórico; não definem a base de atualização ou o resultado de testes da 0.26.0.

## Histórico da 0.21.0 — preservado como referência

Base direta **0.20.0**. Acompanhantes examinados: Core 1.57.1, MCP 0.33.0, Meta 0.12.0, LinkedIn 0.11.0 e Pipedrive 0.2.0. O relatório externo distingue convivência, provas nativas e fornecedor real. A versão amplia conversões, consultas e diagnósticos, preservando a retenção ilimitada e o SDK GA4 da 0.20.0. As seções versionadas anteriores abaixo são histórico; não definem a base de atualização desta rodada.

## Atualização 0.19.0 — pedido Google 36

Base direta 0.18.1. Consulte [GUIA-0.19.0.md](../GUIA-0.19.0.md) para validação obrigatória de credenciais, rotação, resumo e troca guiada de identidade. Novas operações: google/rename-connection, google/plan-identity-change e google/switch-identity. Contratos compartilhados preservados. Não há novo impacto técnico ao Core. Credenciais recusadas não substituem as anteriores; retryable não prova ausência de efeito.

O conteúdo a seguir descreve capacidades mantidas e histórico anterior; não amplia a janela de atualização desta rodada.

# Contratos — Fator3 MCP Google 0.13.0

Atualização 0.19.0: base direta Google 0.17.0. Nova leitura `google/readiness-status` (contrato `google-readiness/1.0.0`, abaixo); descrições em português nos parâmetros de `google/mcp-read`/`google/mcp-write`, sem mudança de tipo; seleção da conexão GA4 de entrega pelo fluxo configurado; schemas de saída de `google/status` e das habilidades de conversões documentam todos os campos devolvidos, sem remoção. Histórico: base 0.14.0 da 0.17.0. Extensão PHP `sendBound(array $payload, string $destinationRef)` negociada pela existência do método, sem alterar `site-conversion-delivery/1.0.0`. `send()` permanece. Referência divergente antes do envio retorna `recusado/non_delivery_proven` com `destination_mismatch`; perda da concessão/trava durante o despacho retorna `authorization_changed` quando a barreira comprova ausência de envio. Resultados externos incertos continuam incertos. Veja [entrega servidor](../CONVERSION-DELIVERY-CORE-140.md). As seções versionadas anteriores são históricas.

Este documento descreve a versão 0.13.0. A situação da validação está em [VALIDACAO.md](../VALIDACAO.md). A consulta executável dos schemas prevalece sobre exemplos; diferenças documentais bloqueiam o build de produção.

## Versões e compatibilidade

| Interface | Versão | Regra |
|---|---|---|
| Execução | 2.0.0 | `meta.fator3.execution_contract_version`; confirmação obrigatória nas operações afetadas |
| Catálogo de habilidades | 3.0.0 | Registro atual, paginação e schemas opcionais |
| Configuração | 4.0.0 | Opções, valores seguros, revisão, credencial ativa/candidata e operações permitidas |
| Perfil GA4 | 1.0.0 | Seções explícitas; não há perfil de agência embutido |
| Modelo portátil | 1.0.0 | Lista permitida de serviços, bindings, limites e política |
| Manifesto de atualização | 1.0.0 | Origem HTTPS, versão, requisitos e SHA256 do pacote |

`google/configuration-schema` publica e aceita somente **4.0.0**. As projeções anteriores não são anunciadas pelo contrato atual. A base de manutenção é instalação limpa ou Google 0.9.0; isso não cria trava no código por número de versão anterior. Consultar novamente o schema antes de configurar. O contrato de execução continua 2.0.0.

## Entrada e autorização

Os objetos superiores são fechados (`additionalProperties:false`). `connection_id` seleciona explicitamente uma conexão; a omissão usa `default` ou o contexto do job em execução. Não há fallback para outra identidade quando um recurso é recusado.

A execução confere canal, capacidade WordPress, conexão, serviço, credencial, escopos e política de recursos. Administradores podem usar os formulários locais expressamente permitidos mesmo com o canal fechado; essa exceção não reabre chamadas MCP. Credenciais não são gravadas por `options/update` nem retornadas pelo contrato.

`google/execute-read` admite somente métodos classificados como leitura. O verbo HTTP não determina o efeito: relatórios e URL Inspection usam POST de leitura. Métodos novos do Discovery sem classificação aprovada são recusados. Seletores wildcard são recusados em escritas antes da expansão. `google/execute-action` permanece, sujeito às mesmas regras.

`mode` e as anotações MCP descrevem a ferramenta. `remote_effect` distingue consultas, mutações possíveis e operações locais; `local_effect` indica mutação funcional local. Cache e auditoria incidental não convertem uma consulta em mutação do recurso Google. `available` no catálogo avalia configuração local, sem comprovar acesso ao recurso: `resource_access_verified:false` é explícito.

## Envelope e resultado

`success:false` permanece falso e inclui `error_code`/mensagem. O adaptador do canal também sinaliza `isError:true`. Não deduzir resultado a partir do texto da mensagem.

O efeito se refere à operação executada: local para configuração/fila, remoto para chamadas Google. A admissão de um job não comprova aplicação remota; consulte `job_outcomes`/resultado da execução.

| `operation_outcome` | Interpretação |
|---|---|
| `not_applicable` | Consulta sem mutação remota |
| `not_applied` | Nenhuma mutação desta intenção aplicada |
| `applied` | Efeito confirmado pela resposta/validação correspondente |
| `partial` | Algumas etapas aplicadas; consultar os resultados por etapa |
| `unknown` | Resultado remoto incerto; conferir o destino antes de uma nova intenção |

`retryable:false` em `unknown`/`partial`. Executar uma passagem local não implica escrita aplicada: jobs de leitura retornam `not_applicable`, escritas pendentes retornam `not_applied`, e o executor publica `job_outcomes` com o resultado observado por tarefa. Uma resposta HTTP bem-sucedida não comprova indexação do Google nem entrega de e-mail. Para diagnóstico, `execution_success`, `all_checks_passed`, contadores e estados por verificação distinguem execução, aprovação, falha, ausência de configuração e etapas puladas.

## Autoteste diagnóstico — 0.13.0

`google/selftest` sem parâmetros usa `live:false`, sem chamadas HTTP Google. `live:true` acrescenta leituras dos serviços/recursos habilitados. Conexão selecionada e permissões continuam aplicáveis.

| Resultado | success | execution_success | complete | checks_passed | all_checks_passed | Código |
|---|---|---|---|---|---|---|
| `passed` | true | true | true | true | true | ausente |
| `incomplete`, com não configurada | true | true | false | false | false | ausente |
| `incomplete`, somente puladas/aprovadas | true | true | false | true | false | ausente |
| `failed`, sem puladas/não configuradas | false | true | true | false | false | `f3_google_selftest_failed` |
| `failed`, também com pendências | false | true | false | false | false | `f3_google_selftest_failed` |
| `execution_error` | false | false | false | false | false | causa de execução |

`success:true` neste diagnóstico significa execução terminada sem reprovação. Aprovação integral exige `all_checks_passed:true`; `complete` mede cobertura. Os contadores `passed`, `failed`, `skipped`, `not_configured` correspondem ao vetor completo de `checks`, com `name`, `status`, `ok`, `detail` e contexto seguro quando presente. A mensagem nomeia todas as não configuradas. Um erro interno/preflight interrompido não fabrica checagens nem contagens. Recusas externas do WordPress/canal preservam o envelope de seu próprio executor e não afirmam execução do diagnóstico.

Segredo existente ilegível é reprovação. Ads ativo sem developer token é configuração pendente; nenhuma opção é alterada para tornar o resultado aprovado. `SelfTest::summarize()` conserva a semântica estrita dos consumidores de preflight, Setup, candidata e worker. `SelfTest::diagnose()` compõe somente o resultado diagnóstico; o envelope genérico `Response` não foi alterado.

## Persistência e configuração

`Options::set()`, `set_secret()` e gravação em lote retornam `success`, `persisted`, `changed`, código e mensagem. A confirmação lê o banco; o retorno booleano de `update_option()` isolado não comprova falha. Uma opção ausente recebendo `false` é criada explicitamente. Valor equivalente já gravado retorna sucesso sem mudança.

Segredos são cifrados antes da persistência. Falhas de leitura, cifra, escrita, verificação e compensação são distintas. Operações compostas preservam o estado anterior quando possível e informam falha de restauração sem anunciar sucesso. `expected_revision` rejeita formulários/planos obsoletos. A revisão de execução dos jobs ignora mudanças que não alteram a identidade/política/serviços, como simples seleção de novos defaults.

O contrato diferencia valor persistido, efetivo e padrão. Para segredos, informa somente presença e legibilidade; uma falha de leitura não vira ausência. Credenciais candidatas possuem opções cifradas separadas e promoção explícita após validar autenticação e recursos já vinculados. Falha preserva a ativa. Rotação de chave da mesma Service Account não representa troca de principal.

## Confirmação e diário de tentativas

Use `google/prepare-operation` com habilidade e parâmetros exatos. A preparação faz consultas e captura localmente os pedidos de mutação; devolve alvos/efeitos, token opaco de uso único e validade de dez minutos. Isso não atesta aprovação humana e não equivale a um `validateOnly` remoto.

A confirmação vincula ator, site, conexão, identidade, revisão, política, método, corpo e conjunto de alvos. A execução reconsulta o estado necessário, compara a intenção, consome o token sob trava e registra a intenção de despacho antes do transporte. Tokens ausentes, expirados, reaproveitados ou pertencentes a outro contexto são recusados sem nova escrita.

Redução de retenção, exclusões, alterações de acesso/proprietários, Google Signals e operações compostas sensíveis exigem esse fluxo. Aumento de retenção não exige por si só confirmação adicional. A falta do token requerido retorna `f3_google_confirmation_required`.

Quando a criação retorna um ID, a continuação deriva de um modelo semântico aprovado, fixa os pedidos concretos no armazenamento antes de enviar e restringe a autorização temporária ao recurso criado. Falha posterior retorna IDs/etapas confirmadas e resultado parcial/incerto, sem fingir rollback remoto.

## Fila, agendas e recuperação

Jobs congelam recursos, parâmetros e datas na admissão; agendas congelam recursos e mantêm períodos relativos para cada ocorrência. A chave de idempotência é vinculada a ator/conexão/intenção; mudança de intenção com a mesma chave é conflito. Troca posterior de defaults não redireciona o job.

O worker compartilha prazo de 20 segundos, reserva de dois segundos para persistência e teto de 25 itens entre MCP, cron e CLI. Resultado/cursor têm commit transacional com proprietário, geração e lease. Uma leitura abandonada pode retomar; uma escrita despachada sem resultado fica `unknown` e não é repetida automaticamente. Não há promessa de execução remota exatamente uma vez.

`inspect-urls`: 1–500 URLs, duplicatas normalizadas; `auto` processa até cinco URLs únicas na chamada quando há orçamento; `queued` apenas admite. Cota local inicial: 25 tentativas/minuto e até 1.000/dia por propriedade/instalação, incluindo retentativas. Outros clientes Google podem consumir a mesma cota remota.

Exportações entram em `approval_required`. `google/prepare-job` e `google/approve-job` delegam uma intenção ao job; tokens não ficam nos parâmetros. Alteração de contexto ou estado relevante bloqueia o despacho. `get-job` pagina resultados; cancelamento preserva etapas concluídas; reconciliação exige evidência e não repete a escrita.

Agendas aceitam `report`, `query` e `preflight`, com intervalo de 3.600–2.592.000 segundos. Atualização exige a revisão de `get-schedule`. Ocorrências vencidas são identificadas por agenda/data prevista; o atraso é coalescido em uma ocorrência por passagem, sem reproduzir todos os intervalos perdidos. O executor atua na conexão selecionada, salvo `all_connections:true`; o cron usa todas as conexões do site.

Retenção: detalhes 30 dias (1–365); resumos/deduplicação 90 dias (30–730), nunca menos que detalhes. Alterações afetam novos encerramentos. Limpeza tem prévia por padrão e até 100 remoções por passagem; preserva ativos, resultados desconhecidos e deduplicação ainda necessária. Resumos de falhas não resolvidas permanecem para diagnóstico. Diários de confirmações resolvidas são removidos com seus filhos após a retenção; confirmações consumidas sem desfecho permanecem.

## Política e portabilidade

Conexões novas começam restritas; instalações anteriores sem política explícita preservam o acesso da identidade. Defaults não concedem autorização. A política verifica alvos, pais, recursos relacionados e destinatários de compartilhamento. Métodos/suboperações não cobertos são recusados sob restrição; não há autorização implícita de toda uma MCC.

`plan-policy` calcula o impacto e informa revisão/hash; `configure-policy` exige ambos. Modelos portáteis exportam somente serviços, vínculos, limites e política. Recursos são parâmetros por padrão; incluir IDs exige pedido explícito. Credenciais, identidades de autenticação, destinatários e preferências de alertas não são exportados. Aplicação exige prévia/revisão e usa a mesma gravação verificada.

## Auditoria, notificações e atualização

Falha de gravação do log não altera um efeito remoto já conhecido. A chamada recebe `audit_warning`, o status expõe `audit_health`, e a janela de auditoria deixa `complete:false`. O marcador conserva a lacuna observada mesmo que gravações posteriores funcionem. Ocultar um token em texto não conta como reutilização da credencial na telemetria.

Eventos de auditoria têm sequência local ao site e, quando observável, `configuration_revision` e `configuration_change_id`. Uma gravação alterada e confirmada retorna `revision`, `configuration_change_id` e `audit_marker` (`event:…`); falha no log preserva o resultado da configuração, devolve marcador nulo e `audit_warning`. Uma gravação sem mudança não cria marcador. `desde_revisao` aceita o hash de configuração, o marcador exato ou uma sequência decimal (compatibilidade), sempre exclusivo. Hash com mais de um marcador retorna `f3_google_audit_revision_ambiguous`, até 20 candidatos seguros e indicador de truncamento, sem escolher uma ocorrência. Marcador ausente, expurgado ou anterior à implantação retorna `f3_google_audit_revision_unavailable` e cobertura indisponível. `configuration_marker` identifica a fronteira resolvida; `coverage_start` informa o início do histórico retido. Eventos legados não recebem associação inventada. O cursor fixa filtros, conexão, ator, teto da janela e expiração de uma hora. `complete` e `retention_gap` informam a cobertura. Exportação JSON/CSV entrega bytes autenticados com tamanho/hash; CSV neutraliza fórmulas. Sheets usa ação de escrita própria, cursor fixado, células literais e confirmação.

Alertas são optativos, por conexão, com até dez destinatários e intervalo de 60–604.800 segundos. Eventos: `access`, `cron_late`, `sitemap_error`, `scheduled_check`. Uma transição persistida deduplica notificações; crash após iniciar envio gera estado incerto e não reenvia automaticamente.

O atualizador usa somente origem configurada por administrador. Valida HTTPS em cada salto, hosts autorizados, limite de bytes, SHA256, estrutura protegida, versão interna e requisitos. O manifesto identifica `plugin`, `schema_version`, `version`, `package_url`, `sha256`, `requires_php` e `requires_wordpress`. Não existe servidor de distribuição predefinido nem publicação automática.

## GTM e transporte

Todas as habilidades declaram `meta.fator3.provider="wp-mcp-google-fator3"`, `version="0.13.0"` e `policy_contract:1`. As bridges declaram `executes_ability:true`; sua autorização não substitui a autorização do alvo. O perfil Manutenção permite todas as operações GTM e dispensa a confirmação genérica adicional; a publicação conserva o fingerprint solicitado neste contrato. Capacidades WordPress, credencial Google e serviços escolhidos continuam válidos.

`gtm/publicar {path,simular:true}` lê o workspace, suas coleções, conflitos e versão publicada, sem escrita remota. Retorna diff, versão anterior e `expected_fingerprint`. Aplicar exige `simular:false` e o mesmo fingerprint, vinculado ao site, conexão, ator, revisão da configuração, alvo, conteúdo e versão live. `gtm/reverter` recebe o caminho de uma versão existente e usa o mesmo protocolo. A publicação nativa via `google/execute-action` ou `gtm/publish-version` também passa por esse protocolo, com `dry_run:true` para prévia. `query` e `body` não são aceitos no atalho de publicação: o fingerprint nativo é obtido do snapshot conferido.

A criação de versão pode substituir o workspace. O resultado preserva `new_workspace_path`, `previous_version_id`, `new_version_id`, `new_version_path`, `publication_id` e `operation_outcome`. Em perda de resposta, `unknown` impede reenvio automático da mesma intenção. `gtm/get-publication` consulta o diário; `gtm/live-version` permite conferir o estado remoto. A API protege a versão-alvo por fingerprint, mas não oferece comparação/troca atômica da versão live: alterações externas depois da última conferência ainda podem concorrer. Versionamento não é transação com rollback automático.

A prontidão é verificada na estrutura corrente. `f3_google_storage_unavailable` recusa trabalho quando as tabelas não podem ser consultadas. Não há phases ou marcadores de migração. A guarda de recuperação cobre toda a operação admitida; proprietário/geração continuam protegendo o despacho e o commit. Uma gravação de auditoria confirmada recupera a saúde atual sem apagar `historical_gap` de um evento perdido.

Atualização: com origem Google configurada no canal 0.22.0, seu manifesto tem precedência. Sem ela, funciona a origem própria do Google. Um ZIP enviado manualmente pelo administrador continua permitido. O manifesto próprio usa `schema_version:"1.0.0"`; o canal usa `schema_version:1`, `requires` e `tested`. Os formatos não são intercambiáveis. Ambos verificam SHA-256; os demais pacotes permanecem sob o atualizador do canal.

## Integração local entre plugins — 0.13.0

A interface pública é `Fator3\McpGoogle\Integration\ServiceApi`, contrato **search-console-reader/1.0.0**. O documento [SDK-PHP.md](../SDK-PHP.md) congela assinaturas, entrada, resposta, erros e exemplo. O plugin consumidor controla propriedade, revisão, prontidão, calendário de coleta e persistência das métricas. Google fornece credenciais, consulta, orçamento, política e auditoria.

`google/integration-status` consulta consumidores registrados, prontidão, concessões e último atendimento. `google/configure-consumer` recebe `consumer_id`, `enabled`, `expected_revision` e `connection_id` opcional. Exige administrador com a capacidade do Google, gravação verificada e uma única conexão autorizada por consumidor. Registrar código não concede acesso. O interruptor global Google bloqueia consumidores; desligar apenas o transporte MCP não exige usuário humano para a consulta PHP autorizada.

Cada tentativa HTTP de token/consulta possui eventos de início/fim, com `actor:{type:plugin,id,version}`, `initiator_user`, `run_id`, `trigger`, `request_id`, `property` e `consumer_revision`; `user:0` não é uma impersonação. `google/audit` aceita filtros `consumer_id`, `run_id`, `request_id`, inclusive na exportação paginada JSON/CSV e na preparação para Sheets. O `request_id` superior é o do serviço; um identificador de transporte pode aparecer em `details`. Registros históricos mantêm seus campos originais. O leitor exige auditoria antes de enviar e recusa avanço de cursor se não conseguir registrar a conclusão.

## Cron e proveniência — 0.13.0

`google/status.cron` e `google/executar-vencidos` usam o mesmo diário por conexão. `last_pass` acompanha a entrada do executor; `ultima_cli`, `ultima_http` e `ultima_manual` são independentes. Cada passagem contém `at`/`started_at` (Unix UTC de entrada), `finished_at`, `run_id`, `origem`, `entry`, `scope`, `connection_id`, `connection_examined`, `success`, `items`, `jobs`, `schedules`, `alerts` e `state`. `items` conta itens de jobs executados; `jobs` conta avanços tentados, `schedules` ocorrências examinadas/despachadas e `alerts` tentativas de notificação. Não contam linhas GSC.

A origem é determinada pelo processo: WP-CLI → `cli`; cron WordPress → `http_cron`; demais entradas autorizadas → `manual`. Parâmetro enviado pelo agente não substitui a origem. CLI prevalece sobre DOING_CRON. O estado `no_due_work` com `success:true,items:0` confirma exame sem trabalho. Uma mera observação CLI tem `scope:wp_cli_invocation`, `connection_examined:false`, `success:null`, `items:0`. Registros iniciados sem conclusão por mais de 120 segundos aparecem como `interrupted`, sem inventar sucesso. Conexões não alcançadas pelo orçamento mantêm `connection_examined:false` e resultado próprio.

`wp cron event run --due-now` é observado pelos hooks públicos WP-CLI mesmo sem trabalho Google; os callbacks Google no mesmo processo compartilham um único `run_id`, com contadores consolidados. Listar eventos ou consultar status não conta. `wp mcp-google run-due --user=<administrador>` preserva a autorização humana exigida; `google/executar-vencidos` exige autorização de agente. Execução pelo `cron/run` do MCP em HTTP é `http_cron`.

`cron_servidor_ativo` é verdadeiro se houver `ultima_cli.at` entre agora−7200 e agora, inclusive. Nesse caso `executor:server-cron`; fora da janela `executor:wp-cron`. Isso indica passagem CLI recente, mesmo com falha, e não comprova crontab instalado: `agendamento_verificado:false`. Hora futura ou leitura inválida não conta. O fallback não prova disparo quando `DISABLE_WP_CRON` estiver ativo.

`passagens_24h.{cli,http_cron,manual}` usa a janela `(agora−86400,agora]`, uma linha por invocação/conexão. `observed_since` e `window_complete` distinguem janela observada, começo recente, falha de persistência/leitura e limite de retenção. O diário indexado retém oito dias, no máximo 20.000 passagens e 1.000 incidentes por conexão. A limpeza remove até 100 registros de cada tipo por passagem; as últimas projeções permanecem. Descarte dentro da janela de 24 horas marca `truncated_in_window:true` e `window_complete:false`. Conclusão atrasada não substitui passagem mais recente. `observability_error` denuncia falha de gravação; a resposta mantém o resultado do trabalho separado.

## Recuperação — 0.13.0

`google/recovery-status` é consulta local. `google/recovery {action:prepare}` pausa fora do banco e aguarda drenagem; somente `ready_for_restore:true` libera a preparação. `action:resume` exige `expected_generation` atual e `acknowledge_reconciled:true`. A geração nova invalida caches de token e contextos restaurados de jobs/agendas. Prepare não desfaz operações remotas já realizadas.

A sentinela protegida em `wp-content/f3-google-state/site-{blog_id}.php` usa troca atômica e locks de arquivo; banco restaurado ou substituição do plugin não a removem. Todos os processos precisam compartilhar esse volume, com permissão de escrita do PHP/CLI. Armazenamento ilegível bloqueia o despacho. Não restaurar/copiar a sentinela antiga por cima da pausa atual. O procedimento completo e o inventário estão em [MIGRACAO.md](../MIGRACAO.md). Não há detecção automática de todo restore externo.

A bridge usa exclusivamente o SDK MCP **server-integration/1.0.0** disponibilizado pela 0.17.0, filtro `f3_mcp_default_server_config` com identidade. Preserva `executes_ability:true` e a autorização do alvo. `mcp_server` distingue SDK conhecido, servidor registrado e observação inconclusiva, sem forçar inicialização REST. O acesso externo continua sendo verificado no cliente MCP.

O catálogo distribuído descreve os schemas Google. O MCP pode acrescentar metadados e campos de idempotência no registro; consulte o contrato executável. O Google registra categoria/habilidades pelos hooks públicos. O MCP conclui esse registro antes de construir o servidor; o Google não aquece `wp_get_abilities()` em REST/CLI. A identidade corrente `wp-mcp-ultimate-server` e `server-integration/1.0.0` são preservadas.

## Diagnóstico e extensões preservadas

`mcp_server.diagnostic` contém `state`, `reason_codes`, `observed_version` (versão semântica observada ou null) e `scope:local_registration`. Estados: `sdk_unavailable`, `sdk_incompatible`, `disabled`, `not_observed`, `not_ready`, `registered`, `error`. `registered` comprova o registro local e ferramentas básicas indicadas pelo SDK; não comprova a contribuição de toda bridge, transporte externo ou autenticação Google. A leitura não inicializa REST/Abilities. Respostas malformadas/exceções retornam erro sem expor a exceção.

`abilities_registered` e `google/ability-catalog` selecionam a mesma categoria Google do registro; agrupamento dinâmico por prefixo, incluindo GTM, e `total`. Não comparar esse total ao catálogo MCP filtrado por perfil.

`google/integration-status` aceita `compact:boolean` (padrão false), retorna a revisão da conexão selecionada, `read_success` e `connection_id`. Falha de leitura retorna revisão nula. O SDK PHP anuncia `effective_status()` optativo desde o registro; `resolved`, `not_granted`, `ambiguous` e `unreadable` não alteram a semântica de `status()` ou `query()`. Consulte [SDK PHP](../SDK-PHP.md).

Cada passagem cron nova acrescenta `reason_code` e `reason_evidence`. `google_executor_not_observed`/`callback_not_observed` significa que o observador WP-CLI não viu o executor Google: não distingue evento ausente, não selecionado ou outra causa sem evidência adicional. Executor examinado com zero itens usa `connection_examined_no_items`; bloqueio publica seu código. Registros antigos permanecem sem motivos inventados. Uma coleta Core pelo SDK não fabrica passagem do executor Google.

`observability_error` recente e `last_observability_error` histórico identificam `code`, `phase`, `resource`, `cause_code`, `retryable`, `storage`, `at`, origem, conexão e passagem quando conhecidos. Recursos incluem lock, event e projection; falha do próprio diagnóstico informa `diagnostic_persisted:false` e seu código na resposta imediata. Se o banco recusar tudo, não existe promessa de evidência durável desse incidente.

O evento durável precede a projeção. Disputa de lock tem no máximo três tentativas com espera curta; armazenamento idempotente tem no máximo três tentativas. Nenhuma delas repete job/HTTP. Falha inicial impede despacho. Falha no fechamento conserva `work_result`, `work_success`/`execution_success`, passagem e erro de observabilidade, sem autorizar repetição do trabalho remoto. `CronHistory::reconcile()` reconstitui a projeção e a limpeza tenta repará-la quando há incidente persistido correspondente. Status reconcilia somente em memória e sinaliza `projection_reconciled_in_memory`; não grava nem renova atividade. Passagens tardias não substituem origens mais recentes. Uma execução posterior bem-sucedida não apaga o último incidente histórico.

## Companheiros e dados de origem

Core 1.33.0 verifica capacidades do leitor `search-console-reader/1.0.0`, `gsc.page-day.read` e `effective_status` anunciado/chamável. Não exige faixa numérica Google. Registro válido, concessão e resolução explícita da conexão permanecem obrigatórios; não existe fallback para outra identidade.

Configuração Core usa contrato 7.1.0 e leads schema 7. Leia `contract_version` em `f3base/config-core-contrato-v1` e o índice `f3base/documentacao-ler`/chave `documentacao`. `persisted`, `audit`, `effect`, `verification` são evidências distintas; `ok` não comprova efeito externo.

Audiência, saída e tempo visível Core permanecem locais. GA4 continua pela tag; tempo visível não equivale ao engajamento GA4. Preserve unidade, período, origem, cobertura e `null` como indisponível. Não existe envio automático de audiência Core ou criação de novas dimensões por essa integração.

## Armazenamento e manutenção — 0.13.0

A tabela `{prefix}f3_google_cron` armazena passagens e incidentes por conexão, com índices de data, origem e escopo. Não há nova option por evento. As projeções fixas `cron_history_*`, `cron_error_*`, `cron_truncated_*` não usam autoload.

Retenção: oito dias, até 20.000 passagens e 1.000 incidentes por conexão. Uma passagem ainda em andamento há menos de 120 segundos não é expulsa para abrir espaço: sem capacidade, a admissão informa erro. A consulta usa agregações e leituras das últimas linhas; não desserializa todo o histórico. `passagens_24h` conta os registros retidos; `truncated_in_window:true`, erro de observação impedem `window_complete:true`. As últimas projeções por origem continuam disponíveis após a poda dos detalhes.

`f3_mcp_google_maintenance` executa manutenção local horária, independentemente de credenciais e de trabalhos vencidos. Lotes pendentes pedem nova passagem em 15 segundos, sujeita ao disparo real do cron. `CronHistory::finish()` também limpa o histórico na observação CLI sem callback Google. Sem visitas e sem cron externo, a manutenção aguarda disparo; `google/maintenance` avança a manutenção corrente explicitamente, com a autorização administrativa existente.

`google/status.maintenance` e `google/storage-status.maintenance` expõem `state`, `success`, contagens e erros. `state:pending` indica uma passagem ainda incompleta. `google/status.cron.maintenance` mostra o última observação da retenção global, com a conexão consultada identificada. A guarda externa pausa a manutenção do pacote durante recuperação.

Nenhum valor novo de transient do Google acima de **100.000 bytes serializados** é gravado em options. Conteúdos maiores usam `wp-content/f3-google-cache/site-{blog_id}-*.php`, cifrados e protegidos por saída PHP imediata, sem `.htaccess`. Limites por site: 64 arquivos de dados, 16 MiB por arquivo, 64 MiB no total e validade máxima de 24 horas. Escrita atômica, lock e poda limitam ocupação. Cache corrompido/expirado é miss; indisponibilidade não causa fallback grande para SQL. Discovery pode usar a resposta validada na requisição sem persistir o cache. `google/status.cache.health` registra falha/recuperação de gravação do cache.

O cache é descartável e separado de `f3-google-state`, que contém a guarda de recuperação. A nova geração de recuperação invalida os arquivos de cache anteriores. Não remover, copiar ou restaurar a sentinela como parte de limpeza de cache. Tokens continuam cifrados. Credenciais, grants, políticas e confirmações duráveis mantêm seus próprios contratos.

A descoberta Core lê o Measurement ID efetivo do slot GA4 pelo SDK público `site-measurement-context/1.0.0`, independentemente da presença de GTM. Exige catálogo completo e correspondência única, sem criar recursos ou inferir destinos do container. Plano e aplicação retornam `core_source` com `adapter`, `contract`, `slot`, `scope`, `configured`, `provenance`, `measurement_id`, `gtm_container_id` contextual e `revision`. A presença de ambos os IDs não comprova duplicidade nem coleta ativa. Revisões e validação de acesso continuam obrigatórias conforme a operação.

## Manutenção 2.0.0 — 0.13.0

`google/storage-status.maintenance` e `google/status.maintenance` compartilham a projeção local. Consultar não executa lote, HTTP Google nem cria evento cron. O schema corrente substitui o anterior; não muda configuração 4.0.0, execução 2.0.0/catálogo 3.0.0 ou SDK leitor 1.0.0.

| Campo | Semântica |
|---|---|
| `maintenance_contract_version` | `2.0.0` |
| `state` | `complete`, `pending` ou `failed` da última observação disponível |
| `success` / `execution_success` | Resultado da passagem local; ausência de amostra pode ter `success:null`. Não representa resultado remoto de job |
| `read_success` | A projeção foi lida. Falha não vira zero |
| `inventory_complete` / `remaining` | Conclusão exige todas as famílias observadas completas na mesma passagem, sem erro; desconhecido mantém pendência |
| `progress` | Cursor, conexão quando aplicável, `at`, `complete`, `read_success`, `error_code`, `examined_in_pass` por família |
| `pending_counts` | Zero somente para uma família confirmada concluída na passagem; `null` se quantidade não conhecida |
| `at` / `finished_at` | Início/fim em epoch UTC; ausentes quando não existe amostra |
| `budget` | `row_limit:100`, `time_limit_ms:1000`, `processed`, `duration_ms`, `stop_reason` (`row_limit`, `time_limit` ou `null`) |
| `observed_at` / `observation_age_seconds` | Instante da consulta e idade da amostra; idade `null` se ainda não houve passagem |
| `blocked_by` | Causa corrente da guarda ou bloqueio registrado da última passagem; consulta em pausa não grava um novo estado |
| `errors` / `error_code` | Códigos estruturados, sem payload/SQL privado |
| `next_run` / `advance_operation` | Próximo evento WordPress observado ou `null`; operação manual `google/maintenance`. Não comprova cron de servidor |

Famílias atuais: `cron_retention`, `cache_sql` e `cache_files`. O orçamento é global por site/invocação automática, compartilhado por manutenção e fechamento do executor/observador. Chamadas manuais explícitas podem solicitar outro lote. O limite de tempo é cooperativo: uma operação SQL ou de filesystem já iniciada pode ultrapassá-lo. Não há cópia de registros antigos, importação de eventos nem arquivamento de fontes de versões anteriores.

`Maintenance::run()` bloqueada devolve falha de recuperação sem persistir a recusa. `state` do status continua histórico; `blocked_by` informa a guarda atual. Na interface, uma ação sob pausa redireciona para a guarda consultável sem gravar feedback em transient.

`google/executar-vencidos` separa resultado do trabalho, `observability_error` e `maintenance_success`/`maintenance`. Falha de histórico ou limpeza **não** autoriza reexecução remota. Preservados `cron.storage`, `history_storage`, contadores/origens independentes e regra de duas horas para `server-cron`.

Causas relevantes: `f3_google_recovery_paused`, `f3_google_recovery_draining`, `f3_google_storage_unavailable`, `f3_google_maintenance_busy`, `f3_google_lock_lost`, `f3_google_maintenance_read`, `f3_google_maintenance_persistence`, `f3_google_cron_storage_retention_verify` e falhas específicas de cache. São resultados locais; não autorizam repetição de uma mutação remota.

Schema de cron ausente é diagnosticado em caminhos normais sem DDL repetido. `google/maintenance`, com autorização administrativa, pode recriar uma tabela ausente; não recupera linhas perdidas nem apaga/recria tabela corrupta. Estrutura incompatível devolve `f3_google_cron_storage_schema_invalid` e exige reparo/restauração autorizados.

Cache: SQL ≤100.000 bytes serializados; arquivos cifrados ≤16 MiB cada, ≤64 arquivos/site, ≤64 MiB totais/site e TTL máximo de 24 horas. Arquivos têm preâmbulo PHP que responde 404. Resíduo SQL e backend externo ativo são fontes distintas: sob cache externo, só a cópia SQL obsoleta e seu timeout são removidos. Sem backend externo, conversão preserva TTL restante; vencidos/sem timeout e Discovery legado são descartados. A mesma trava coordena leitura, escrita, transição e exclusão; snapshots locais de options são invalidados antes de consultar SQL. Não ocorre flush global de WordPress/Redis/Memcached.

## Cron — contrato preservado na 0.13.0

`google/executar-vencidos` publica `history_status:confirmed|pending|unconfirmed`, `work_success:boolean|null` e a cessão `state:yielded`. Cessão normal tem `success:true`, `execution_success:true`, zero itens e conexão não examinada; não autoriza inferir resultado de outra passagem. Falhas reais preservam o envelope de reprovação. Campos por passagem continuam em `pass.results`.

`google/status.cron` acrescenta `history_pending`, `coverage_gap`, resolução por identidade em `last_observability_error` e `scheduling` **2.0.0**, escopo por site. `observability_error` não expira por idade. Evento terminal precede projeção; retenção preserva fontes pendentes. A ordenação de locks é admissão `jobs-tick` → evento/retenção `cron-history:<conexão>` → projeção `cron-projection:<conexão>` → incidente `cron-incident:<conexão>` → trava curta da option. Escritores de incidente não adquirem histórico. A guarda de recuperação engloba a operação. O observador WP-CLI protege só suas gravações e não mantém uma trava durante callbacks de terceiros.

A resolução captura uma identidade antes da confirmação terminal e compara novamente sob a trava de incidente. Escrita confirmada de evento/projeção encerra somente a identidade capturada. Erro novo, inclusive no mesmo segundo, permanece ativo. Passagem cedida, início sem fechamento, status e outra conexão não resolvem o erro. Lacuna e retenção influenciam a cobertura separadamente.

O schema executável detalha os campos de `scheduling`. As listas `observations`, `active_errors` e `last_errors` não expõem argumentos. Estado `confirmed` exige pós-condição da operação correta; `failed` conserva divergência e `unconfirmed` conserva ausência de prova. Aviso nativo, falha de operação e falha do diagnóstico têm campos separados. Nenhum novo serviço, configuração pública ou habilidade foi criado. Guia operacional e limites: [ACOMPANHAMENTO-CRON.md](../ACOMPANHAMENTO-CRON.md).

Matriz Google 0.13.0/Core 1.38.0/MCP 0.26.0. Core configuração 8.3.0 e Google configuração 4.0.0 têm numerações independentes. SDK GSC permanece 1.0.0; concessão Google não decorre da política publicitária Core. Publicidade permitida/medição negada não habilita GA4 por servidor. O catálogo agregado deve ser descoberto dinamicamente; 283 conta somente o provider Google.

## Configuração 4.0.0 — seleção de serviços

`google/plan-configuration` e `google/configure {dry_run:true}` calculam o mesmo plano. A prévia contém `configuration_contract_version`, `configuration_revision`, `plan_hash`, `would_change`, `services_before`, `services_after`, `services_stored_before/after`, `services_mode`, `service_changes` e `confirmation_required`. Estados efetivos incluem `enabled`, `level` e `source:inherited|explicit`. A seleção armazenada nula herda o comportamento existente e respeita as flags GA/Ads; não equivale a nenhum serviço.

| Entrada | Semântica |
|---|---|
| `services` omitido | Preserva seleção e flags. |
| `services:{...}` | Substitui a seleção completa; omitidos ficam desligados. |
| `services:{...}, merge:true` | Mescla os informados e preserva os demais serviços/níveis. |
| `services:{}, merge:true` | No-op, inclusive na seleção herdada. |
| `services:{}` sem merge | Desativa todos; exige confirmação se houver redução efetiva. |
| `services:null`, nível/serviço desconhecido, booleano textual | Erro, sem conversão silenciosa. |
| `merge:true` sem `services` | Erro de entrada. |

`service_changes` separa `enabled`, `disabled`, `upgraded`, `downgraded` e `unchanged`. Desativações e reduções locais (inclusive Ads read/write com mesmo escopo OAuth) exigem `confirm_service_reduction:true`, `expected_revision` e `expected_plan_hash`. Sem isso, toda a requisição é recusada com `f3_google_service_reduction_confirmation_required`, diff, `persisted:false`, `changed:false`, `operation_outcome:not_applied`; nenhum binding associado é salvo.

O hash cobre site, ator, conexão, contrato, revisão, modo, seleção e valores completos, origem Core e teste de acesso. Ordem de chaves não altera a intenção. A seção protegida de `Settings::save()` relê/revalida o plano antes de gravar. Mudança de contexto ou parâmetros retorna `f3_google_configuration_conflict`. Não preencher automaticamente a confirmação; esses campos expressam a intenção recebida, não certificam aprovação humana. Não usar `confirmation_token`/`google/prepare-operation` nem o `confirm_token` do MCP neste fluxo local.

A prévia não altera configuração, credenciais, seleção nem cron; descoberta/Core optativos podem fazer leituras Google. Autorização, recuperação e registro de tentativa permanecem ativos. `google/configure` continua habilidade de escrita mesmo em simulação. `success:true` com `dry_run:true` e `persisted:false` não significa aplicação. O painel apresenta antes/depois, revisão e etapa de confirmação; modelos mostram o mesmo diff e conservam sua confirmação integral por revisão/hash.

Repetição equivalente retorna sucesso com `changed:false`. Falhas de gravação preservam resultados da verificação/restauração: `restored:true` permite `not_applied`; restauração não confirmada permanece `unknown`, sem anunciar sucesso ou ausência de alteração. Não se promete transação contra escritores externos que ignoram as travas.

## Agenda atual — cron.scheduling 2.0.0

`checks.executor` prova a presença atual de uma única ocorrência de `f3_mcp_google_jobs_tick`, recorrência `f3_google_minute`, intervalo 60 e argumentos vazios. Campos: `state:present|missing|invalid|inactive|unknown`, `desired_state`, `generation`, `intent_origin`, `read_success`, `present`, `occurrences`, `next_run`, `observed_at`, `expected`, `reason_code`, `repair_allowed` e `repair_blocked_by`.

A comparação usa leitura persistida e visão efetiva do WordPress, sem chamar a rotina que atualiza arrays cron antigos. Divergência/erro de leitura permanece `unknown`; array legado não é convertido pela consulta. Ordem de campos/eventos é normalizada. Evento vencido é presente; atraso não é ausência. Estrutura divergente ou múltiplas ocorrências não são reparadas automaticamente.

`active_errors` une incidentes históricos não resolvidos e erros atuais derivados (`source:current_state`, `diagnostic_persisted:false`). `observations`, `last_errors` e avisos nativos preservam seu sentido histórico: não comprovam presença atual. `health:degraded` prevalece sobre `work_health:idle|due|blocked|unknown` quando a agenda/histórico não são confirmados. O campo `executor:server-cron|wp-cron` continua derivado da atividade CLI recente, não da presença de evento ou execução de callback.

O evento é obrigatório enquanto o plugin está ativo, mesmo sem jobs. Registro e consulta não o criam. Ativação explícita, manutenção, observador CLI e execução manual/cron admitida podem repor o ausente, com trava, geração de ciclo de vida e pós-condição. Pausa de recuperação ou indisponibilidade de armazenamento impede reparação operacional. Desativação publica a intenção inativa antes de disputar a trava; processo com geração antiga é recusado. A geração é revalidada também depois do agendador nativo: uma ocorrência escrita por reparação obsoleta é removida quando a intenção passou a inativa. Não há replay de trabalho para reparar agenda nem alteração de hooks MCP/Core. A projeção e a reconciliação consideram somente hooks atuais; observações de hooks fora desse conjunto ficam preservadas no registro, sem bloquear o diagnóstico nem serem reaplicadas.

O executor expõe `executor_repair` e `executor_schedule_success`; a manutenção expõe seu subresultado `executor_repair`. Trabalho, histórico, manutenção e reparação são resultados independentes: não repetir mutação remota por falha na agenda. O orçamento da manutenção inclui a unidade de reparação.

MCP 0.22.0 publica `mcp-cron-marker/2`; seu ciclo explícito de reposição permanece independente. SDK `server-integration/1.0.0`, política 1 e execução 2.0.0 são preservados. Retenção de tokens MCP nunca gerencia credenciais Google. Rollback de pacote não reverte opções, intenção/histórico ou efeitos externos.


## Retiradas históricas e integração preservadas na 0.13.0

O catálogo 3.0.0 retira `google/migrate-storage` e `google/complete-transition` e acrescenta `google/maintenance`. Não existem aliases nem transferência de grants. `google/storage-status.storage` publica `storage_contract_version:2.0.0`, `ready`, `state:ready|unavailable`, `tables` e `error_code`, sem fases de migração. As consultas são observacionais. O cron deixa de publicar `legacy_last_pass` e `migration_pending`; reconciliação de falhas correntes continua em `history_pending`/`history_status`.

MCP 0.26.0 e Core 1.38.0 são a matriz corrente recebida. Não há condição de instalação por versão/presença/ordem de acompanhantes. Registro `f3_mcp_register_providers` e `ExtensionContract::register`, metadados do próprio provedor e política 1 permanecem consistentes. Incompatibilidade de capacidade afeta a operação dependente.

O Core publica os eventos `f3base_form_aberto`, `f3base_form_iniciado`, `f3base_form_recusado`, `f3base_form_enviado` e `f3base_form_fechado`, com `form_id` e `codigo` separados. Não transportar valores preenchidos pelo visitante; `generate_lead` é uma conversão distinta. Nenhuma dimensão, métrica, conversão ou emissão duplicada é criada por essa documentação.

LinkedIn/Pipedrive, segredos, filas, cotas e cursores pertencem ao Core. `f3base/anuncios-linkedin-acesso-verificar`, `f3base/anuncios-linkedin-consultar` e `f3base/anuncios-linkedin-webhook-configurar` são escritas, inclusive em simulação, e são recusadas pelas bridges Google. `idempotency_key` do MCP não substitui `revisao`/`chave_operacao` nativos. A callback Core `GET/POST /wp-json/f3base/v1/anuncios/linkedin/notificacoes` usa autenticação/contexto próprios, sem criar identidade MCP ou passagem cron Google. Diagnóstico parcial não comprova acesso, e leads importados não são eventos de navegador.

## Contratos públicos e relatórios — 0.13.0

Os contratos `site-measurement-context/1.0.0`, `package-distribution/1.0.0` e `executor-registration/1.0.0` são consumidos pelas capacidades publicadas, sem comparação numérica das versões dos plugins. O leitor editorial `search-console-reader/1.0.0` permanece independente. Consulte [CONTRATOS-PUBLICOS.md](../CONTRATOS-PUBLICOS.md).

`google/query` conserva o modo de uma página por padrão. `collection.mode:complete` e `calendar` ativam a coleta limitada. `collection.complete` descreve o fim do plano sobre as linhas disponíveis; não certifica todas as linhas da origem. Cobertura, qualidade, limites, retenção e schemas em [ANALYTICS.md](../ANALYTICS.md).

Exportação passa a `completeness_policy:require_complete` por padrão, inclusive em jobs/agendas existentes que omitam o campo. Não há conversão dos registros anteriores: a intenção corrente aplica a regra atual. `allow_partial` exige entrada explícita. Confirmações antigas cuja semântica de exportação não coincide com o contrato atual são recusadas; não são apagadas nem reaplicadas. O hash inclui exportação 2.0.0 e a política de completude. A aprovação de escrita, a extração e a verificação possuem resultados separados.

Diagnóstico: `success:true` confirma a observação, não prontidão remota. `storage.ready`, saúde do cron e verificações de recurso devem ser lidos separadamente. `live:false` não consulta o Google nem repara estruturas; `live:true` é explícito e não é aceito com `scope:all_connections`. Os schemas permitem metadados adicionais do envelope e descrevem campos condicionais dos dois escopos.

## Conversões e tipagem na 0.13.0

Consulte [docs/CONVERSOES.md](../CONVERSOES.md) para `google/conversion-context`, o bloco adicional GTM e `effective_value` booleano (Pedido MCP Google 26). O contrato de medição existente permanece.

## Pedido 27 — classificação de revisão

`google/conversion-context` mapeia somente o código validado `revision_conflict` para `conflict:true`; `retryable:false` permanece. O erro do produtor conserva seu envelope com `data:null`. `current_revision` é opcional e só contém a revisão da mesma fotografia pública válida recusada pela guarda defensiva; não há segunda consulta. O erro normal do SDK 1.0.0 omite esse campo. Não há mudança de configuração 4.0.0, catálogo 3.0.0 ou execução 2.0.0. O contrato de entrega servidor Core 1.39.0 não é implementado por esta versão.

## Prontidão operacional — `google-readiness/1.0.0` (0.19.0)

`google/readiness-status` é leitura local (`mode: read`, `remote_effect: none`, `local_effect: none`, `annotations.readonly: true`). Entrada: `hours_ahead` inteiro de 1 a 48 (padrão 6) e o `connection_id` comum a todas as habilidades. Saída: `success`, `message`, `contract`, `state` (`ready` | `attention` | `blocked`), `connection_id`, `plugin_version`, `observed_at`, `hours_ahead`, `google_checks_performed` (sempre `false`), `checks[]` e `actions[]`.

Cada item de `checks` tem `id`, `state` (`ok` | `attention` | `blocked` | `not_configured`), `code`, `action` (texto em português ou `null`) e `detail` opcional. Ordem fixa dos `id`: `credential`, `storage`, `recovery`, `executor`, `conversion_ga4`, `conversion_google_ads`, `incidents`, `core`. O veredito é o pior estado; `not_configured` não piora o veredito. `actions` segue a gravidade, sem repetição. Códigos dos destinos: os motivos locais de `capabilities.reason` quando bloqueado, e `verification_pending`, `renewal_overdue`, `renewal_not_scheduled_before_expiry`, `renewal_failing` quando em atenção. A leitura não chama o Google, não repara e não envia e-mail.



## Atualização 0.20.0

Pedidos 37/38: retenção 0 sem prazo e SDK ga4-reader/1.0.0. Valores explícitos da base 0.19.0 permanecem; manutenção protege os registros presentes quando configurada retenção ilimitada. GSC não muda. O SDK GA4 não implementa o acervo do Core. Consulte o guia 0.20.0 e SDK-PHP para concessão, cotas, limites e uso.
