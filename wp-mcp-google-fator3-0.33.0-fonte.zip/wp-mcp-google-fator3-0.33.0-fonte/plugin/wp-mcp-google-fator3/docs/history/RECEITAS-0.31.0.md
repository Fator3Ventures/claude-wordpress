# Histórico — não descreve a release instalada

Cópia integral do documento instalado na 0.31.0, retirada do índice na 0.32.0. Mantida no fonte para consulta; não vale como documentação da release instalada. Os links locais foram ajustados para a pasta docs/history/.

# RECEITAS · 0.29.0

O guia GUIA-0.29.0.md descreve as telas atuais. Para instalação, atualização ou correção use MIGRACAO.md. O catálogo e os schemas instalados descrevem as interfaces vigentes.

## Referência técnica e histórico de contratos

# Referência operacional — Google 0.26.0

Base direta 0.25.1. Matriz desta rodada: Core 1.66.0, MCP 0.38.0, Meta 0.18.0 e LinkedIn 0.14.0. Pedido 48 e limites da rodada estão no guia GUIA-0.26.0.md e no relatório externo. As seções versionadas herdadas abaixo descrevem capacidades e evidências históricas; não definem a base corrente nem representam novos testes. Contratos e políticas aqui descritos permanecem, exceto a cópia de transporte 1.1.0 alinhada ao Core (ambos e invalid_output).

# Receitas das capacidades existentes — 0.12.0

- Descobrir a conexão: `google/status` e `google/configuration-schema`; configurar somente as opções necessárias, conferir revisão e testar recursos explicitamente.
- Descobrir relatórios GA4: `google/list-accounts`, `google/list-fields` com a propriedade, depois `google/query`. O catálogo dinâmico não tem contagem universal de dimensões/métricas.
- Relatórios nativos, inclusive coortes: consultar `google/list-actions` e o schema do método; usar `google/execute-read` para métodos classificados como leitura. Os endpoints GA/GSC específicos continuam disponíveis.
- Preparar perfil GA4 genérico: fornecer o perfil desejado a `ga/aplicar-perfil`, simular, revisar diff e aplicar com as confirmações exigidas. A operação não cria uma propriedade.
- GSC: `gsc/preparar-site`, `gsc/migracao-conferir`, inspeção e acompanhamento de sitemap mantêm seus contratos. Confirmação de envio não significa processamento ou indexação.
- Agendar leituras: criar explicitamente job/agenda, acompanhar estado e cron. `google/executar-vencidos` e `wp mcp-google run-due` não exigem tráfego público; a instalação de crontab externo continua responsabilidade operacional.
- Exportar: revisar [ANALYTICS.md](../ANALYTICS.md), especialmente completude, confirmação de append, recibos de escrita e limites de verificação.

Não foram criados aliases Porter ou atalhos nominais para essas sequências. Os nomes/schema efetivos estão no catálogo gerado; receitas não substituem autorização por serviço e recurso.

## Contrato de medição preservado: contato e material (Pedido Core 222)

O SDK site-measurement-context/1.0.0 mantém seis slots e enumeração fechada. O slot google_ads.conversion_label refere-se a contato; não representa material. O Core 1.35.0 emite download_material por seus emissores, mas não o anuncia neste SDK. Sua configuração de material está no contrato administrativo Core 8.1.0.

Uma receita de material deve usar explicitamente download_material e identificadores próprios por finalidade. Não convertê-lo em generate_lead, nem reaproveitar o label de contato. Consultas GA4 por eventName podem usar download_material explicitamente; o catálogo incompleto não significa ausência do evento no fornecedor. A criação de evento-chave, ação Ads ou publicação GTM é decisão explícita do dono, com os gates existentes. O Google não infere nem cria essas ações ao ler contexto.

Na 0.12.0, `google/conversion-context` usa separadamente o contrato opcional `site-conversion-purposes/1.0.0`, entregue desde Core 1.36.0 e conferido na 1.38.0. Os schemas do contrato antigo permanecem intactos. Veja CONVERSOES.md para entrada, erros e limites.

## Conversões e tipagem na 0.12.0

Consulte [CONVERSOES.md](../CONVERSOES.md) para `google/conversion-context`, o bloco adicional GTM e `effective_value` booleano (Pedido MCP Google 26). O contrato de medição existente permanece.
