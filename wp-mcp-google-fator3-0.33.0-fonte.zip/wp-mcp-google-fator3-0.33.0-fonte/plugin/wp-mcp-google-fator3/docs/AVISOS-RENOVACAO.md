# Avisos de renovação

Aplica-se à renovação automática das provas de aquisição GA4 e Google Ads, por conexão e destino. Não altera conversões por etapa nem seus contratos.

1. A primeira falha abre imediatamente o incidente de renovação, preservando a prova até sua validade normal. Não envia e-mail enquanto a sequência inicial não terminar e o vencimento estiver distante.
2. A sequência usa intervalos de 5, 10, 20, 40 e 60 minutos após falhas. A sexta falha consecutiva (inicial mais cinco retentativas) habilita um aviso de atenção. Falhas de verificação manual também integram o contador existente, mas somente o executor envia atenção. Após essa sequência, as retentativas continuam de hora em hora.
3. Independentemente do contador, uma renovação falha com prova a até `expiry_warning_hours` horas de vencer habilita o aviso. Padrão 6; inteiros de 0 a 24; zero significa no vencimento. Sem prova prévia, só o esgotamento habilita o aviso. O executor reavalia entre tentativas; na tentativa já vencida, tenta renovar primeiro e evita um aviso desnecessário quando há recuperação.
4. Recuperação resolve o incidente. Envia uma única recuperação somente se a atenção do mesmo ciclo foi aceita pelo `wp_mail`. Um novo ciclo após recuperação recebe identidade nova. Incidentes abertos antigos com atenção aceita não recebem atenção novamente; incidentes antigos já resolvidos permanecem intactos.

## Configuração com prévia

Em Ferramentas → Fator3 MCP Google → Conversões → Avisos de renovação, informe as horas, clique Simular e revise antes de Aplicar. No MCP: `google/plan-renewal-notifications` recebe `configuration:{expiry_warning_hours:6}`. Use `configuration_revision` e `plan_hash` da resposta como `expected_revision` e `expected_plan_hash` em `google/configure-renewal-notifications`, junto da configuração exata. A prévia é vinculada a conexão, usuário e valor corrente; uma prévia obsoleta é recusada. Repetir aplicação sem mudança é permitido com nova prévia.

O ajuste não altera credenciais, destinos, grants ou provas. Não consulta Google nem envia e-mail durante simulação/aplicação. O próximo passe autorizado do executor avalia incidentes abertos. Estado aparece em `conversion_delivery.<destino>.renewal.notification`; leituras não executam trabalhos. A pausa e os gates de autorização continuam vigentes.

## Entrega e persistência

Destinatário: e-mail administrativo do WordPress. Uma reserva persistente por conexão/destino/ciclo/tipo precede o envio, dentro da trava de conversões. `accepted` significa aceitação pelo transporte WordPress; não prova entrega na caixa postal. `failed` significa recusa; `unknown` inclui interrupção ou exceção. Para impedir duplicatas, não há reenvio automático após uma tentativa de correio, mesmo falha/incerta. Nessa condição confira o transporte e o incidente; retentativas da verificação continuam normalmente. Sem atenção aceita, a recuperação não envia correio.

Uma opção não carregada automaticamente por conexão (`f3_mcp_google_conversion_renewal_notice`) armazena a política; incidentes e recibos usam o repositório indexado. Instalação e atualização não materializam o padrão nem reescrevem registros antigos.
