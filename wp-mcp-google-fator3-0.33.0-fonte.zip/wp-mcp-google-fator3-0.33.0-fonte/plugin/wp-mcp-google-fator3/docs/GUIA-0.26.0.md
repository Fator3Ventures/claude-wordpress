# Guia Google 0.26.0

Base direta 0.25.1. Pedido MCP Google 48.

## Diagnóstico de transporte

`google/conversion-delivery-status` lê `site-conversion-purposes/1.1.0` pelo SDK público do Core. A cópia do contrato foi sincronizada com Core 1.66.0, aceitando navegador, servidor e ambos em selected/effective, e invalid_output no envelope de erro. A fotografia inteira permanece validada, inclusive propriedades adicionais, tipos, revisão e identidade do produtor.

`core_transport.ok:true` significa que a fotografia do Core é válida; não significa que todos os destinos estão prontos. LinkedIn com selected/effective ambos, ready false e reason regra_ausente é um diagnóstico válido. GA4 e Ads mantêm seus gates, provas e filas independentes. A mudança não habilita um transporte novo na configuração Google nem envia conversões.

## Atualização e operação

Instale o ZIP 0.26.0 sobre 0.25.1, sem desinstalar. WordPress limpo também é aceito. Sem alteração de banco, configuração, credenciais, grants, política de renovação ou rotinas de envio. A correção de medição solicitada ao Core na 0.25.1 está incorporada no Core 1.66.0; não aplicar o patch histórico desta fonte.

Leia google/readiness-status e google/conversion-delivery-status. O GA4 usa o stream selecionado na aba Conversões e o Measurement ID público do Core. Consulte google/ability-catalog para descrições em português e schemas atuais. No site afetado, confirme core_transport.ok true com LinkedIn ambos; não altere destinos só para tornar o diagnóstico verde. Instalar Google 0.26.0 não torna uma credencial ausente pronta. Ajuda e status não consultam fornecedores nem enviam e-mail.

Rollback: repor o instalador 0.25.1 ou sua pré-imagem, preservando banco/salts. Isso restaura a rejeição de ambos, mas não desfaz efeitos externos. O schema 1.1.0 não mudou de identidade.

Matriz da rodada e limites constam do relatório externo. Fornecedores simulados não encerram aceites reais da frota. Consulte [renovação](AVISOS-RENOVACAO.md), [migração](MIGRACAO.md) e [contratos](../CONTRACTS.md).
