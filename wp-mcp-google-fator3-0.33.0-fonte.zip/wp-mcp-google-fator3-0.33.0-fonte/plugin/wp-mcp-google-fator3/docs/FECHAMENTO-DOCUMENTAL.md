# FECHAMENTO-DOCUMENTAL · 0.33.0

O guia GUIA-0.33.0.md descreve as telas atuais. O índice instalado (README.md) publica o mapa de documentos; `build/check-docs.py` recusa referência a documento fora do índice, título com versão vencida e nome de campo de saída antigo fora da tabela de renomes.

## Referência técnica e histórico de contratos

# Fechamento documental — 0.26.0

Catálogo e opções são gerados do runtime. Guia, especificação do acervo, SDK, exemplos e índice MCP usam a mesma versão. Dados PHP protegidos levam a documentação no instalador; o fonte contém os editáveis e geradores. Candidato aprovado é promovido sem recompressão. O relatório no fonte antecede seu fechamento; bytes e SHA finais do fonte constam somente no relatório externo. Nenhum ZIP aninhado.
