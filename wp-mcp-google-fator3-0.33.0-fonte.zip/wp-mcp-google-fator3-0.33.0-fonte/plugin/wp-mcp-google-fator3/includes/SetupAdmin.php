<?php
/**
 * Guided forms share the same writers used by agents and manual configuration.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class SetupAdmin {
    public static function init(): void {
        foreach ( array( 'save', 'import', 'create' ) as $action ) {
            add_action( 'admin_post_f3_google_setup_' . $action, static fn () => self::handle( $action ) );
        }
    }
    public static function handle( string $action ): void {
        Admin::guard( 'f3_google_setup_' . $action );
        if ( 'create' === $action ) {
            $id = Admin::posted( 'new_id' );
            $result = Connections::create( $id, Admin::posted( 'label' ) );
            Admin::require_saved( $result );
            Connections::select( $id );
            wp_safe_redirect( Admin::url( 'created', 'connection', 'service_account' ) );
            exit;
        }
        if ( 'import' === $action ) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Missing -- Upload metadata is checked for error, size and is_uploaded_file() before a bounded local read. POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
            $file = $_FILES['credential'] ?? array();
            $max = Auth\Configuration::JSON_MAX_BYTES;
            if ( ! is_array( $file ) || ( $file['error'] ?? 1 ) !== UPLOAD_ERR_OK || ! is_string( $file['tmp_name'] ?? null ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
                Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_credential_upload', 'Envie um arquivo JSON de até 1 MiB. Confira também o limite de upload do servidor.' ) ) );
                return;
            }
            if ( filesize( $file['tmp_name'] ) > $max ) {
                Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' ) ) );
                return;
            }
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Bounded read of a verified local upload, never a remote URL.
            $json = file_get_contents( $file['tmp_name'], false, null, 0, $max + 1 );
            $result = Auth\Configuration::import( is_string( $json ) ? $json : '', Admin::method(), '1' === Admin::posted( 'activate' ), Admin::posted_revision() );
            $activated = '1' === Admin::posted( 'activate' );
            Admin::saved( $result, $activated ? 'activated' : 'saved' );
            return;
        }
        if ('save' === $action && isset($_POST['configuration_intent'])) {
            // Capability and nonce were checked above; preserve JSON bytes for hash verification.
            $json=is_string($_POST['configuration_intent'])?wp_unslash($_POST['configuration_intent']):'';
            $input=strlen($json)<=65536?json_decode($json,true):null;
            if (!is_array($input)||array_diff(array_keys($input),array_keys(Setup::schema()))) {
                Admin::require_saved(Response::fail(new \WP_Error('f3_google_setup_input','Prévia inválida.')));
                return;
            }
            $input['confirm_service_reduction']='1'===Admin::posted('confirm_service_reduction');
            self::submit($input);
            return;
        }
        $input = array(
            'bindings' => array(),
            'validate_access' => '1' === Admin::posted( 'validate_access' ),
        );
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
        if ( isset( $_POST['services_present'] ) || isset( $_POST['services'] ) ) {
            $input['services'] = array();
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Missing -- Structured input is validated by the shared schema/credential writer; text sanitization would corrupt JSON or the key. POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
            foreach ( (array) wp_unslash( $_POST['services'] ?? array() ) as $service => $level ) {
                if ( ! is_string( $level ) ) {
                    Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_setup_input', 'Perfil de serviço inválido.' ) ) );
                    return;
                }
                if ( '' !== $level ) {
                    $input['services'][ $service ] = $level;
                }
            }
        }
        foreach ( array_keys( Setup::BINDING_RULES ) as $key ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
            if ( ! isset( $_POST[ $key ] ) ) {
                continue;
            }
            $service = Setup::BINDING_RULES[$key]['service'];
            if (isset($input['services']) && !isset($input['services'][$service])) {
                // An inactive field must not replace a saved binding, including without JavaScript.
                continue;
            }
            $value = Admin\Resources::normalize( $key, Admin::posted( $key ) );
            if ( is_wp_error( $value ) ) {
                Admin::require_saved( Response::fail( $value ) );
                return;
            }
            $input['bindings'][ $key ] = $value;
        }
        if ( null !== Admin::posted_revision() ) {
            $input['expected_revision'] = Admin::posted_revision();
        }
        self::submit($input,'1'===Admin::posted('preview_configuration'));
    }
    /** Activation switches and the services form share the review step. */
    public static function submit(array $input,bool $preview=false): void {
        $plan=Setup::plan($input);
        Admin::require_saved($plan);
        if($preview || ($plan['confirmation_required']&&empty($input['confirm_service_reduction']))) {
            wp_die(self::preview_html($input,$plan),'Revisar configuração Google',['response'=>200,'back_link'=>false]);
            return;
        }
        Admin::saved(Setup::apply($input));
    }
    public static function preview_html(array $input,array $plan): string {
        $input['expected_revision']=$plan['configuration_revision'];
        $input['expected_plan_hash']=$plan['plan_hash'];
        unset($input['dry_run'],$input['confirm_service_reduction']);
        $html='<h1>Revisar serviços e recursos</h1><p>A configuração ainda não foi salva. Confira os serviços que serão desativados ou terão o nível reduzido.</p><table style="width:100%;text-align:left"><thead><tr><th>Serviço</th><th>Antes</th><th>Depois</th></tr></thead><tbody>';
        foreach($plan['services_before'] as $service=>$before) {
            $after=$plan['services_after'][$service];
            $label=Admin\Fields::services()[$service]['label']??$service;
            $levels=['read'=>'Leitura','write'=>'Leitura e escrita','admin'=>'Administração'];
            $html.='<tr><th>'.esc_html($label).'</th><td>'.esc_html($before['enabled']?$levels[$before['level']]:'Desativado').'</td><td>'.esc_html($after['enabled']?$levels[$after['level']]:'Desativado').'</td></tr>';
        }
        $html.='</tbody></table>';
        foreach($plan['changes'] as $change) {
            if(!$change['changed']||!in_array($change['option'],[Connections::BINDINGS,Options::GA_DEFAULT_PROPERTY],true))continue;
            $html.='<p>Recursos: <code>'.esc_html(wp_json_encode($change['before'])).'</code> → <code>'.esc_html(wp_json_encode($change['after'])).'</code></p>';
        }
        $html.='<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3_google_setup_save"><input type="hidden" name="section" value="connection"><input type="hidden" name="connection_panel" value="services"><input type="hidden" name="connection_id" value="'.esc_attr(Connections::id()).'"><input type="hidden" name="configuration_intent" value="'.esc_attr(wp_json_encode($input)).'">';
        $html.=wp_nonce_field('f3_google_setup_save','_wpnonce',true,false);
        if($plan['confirmation_required']) $html.='<input type="hidden" name="confirm_service_reduction" value="1">';
        return $html.'<p><button type="submit">Confirmar alterações'.($plan['confirmation_required']?' e reduções':'').'</button> <a href="'.esc_url(Admin::url('','services')).'">Cancelar e voltar</a></p></form><p>Se a configuração mudar, esta confirmação será recusada. O teste de acesso selecionado será executado ao aplicar.</p>';
    }
    /** Compatibility entry point now prepares credentials without activating another method. */
    public static function import( string $json ): array {
        return Auth\Configuration::import( $json );
    }
    public static function render(): void {
        Admin\Screen::services();
    }
}
