<?php
/**
 * Durable pass records, independent origin projections and explicit observability failures.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Connections, Lock, Options, Records
};
use Fator3\McpGoogle\Storage\CronStore;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class CronHistory {
    private static ?array $invocation = null;
    private static array $open_frames = [];
    private static ?string $liveness_key = null;
    private static bool $shutdown_registered = false;
    private static function liveness(): ?string {
        global $wpdb;
        if (self::$liveness_key===null) {
            $key='f3gc:'.get_current_blog_id().':'.bin2hex(random_bytes(16));
            if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$key))==='1') self::$liveness_key=$key;
        }
        return self::$liveness_key;
    }
    private static function alive(array $row): ?bool {
        global $wpdb;
        $key=$row['liveness_key']??null;
        if (!is_string($key)||!preg_match('/^f3gc:[0-9]+:[a-f0-9]{32}$/D',$key)) return null;
        $id=$wpdb->get_var($wpdb->prepare('SELECT IS_USED_LOCK(%s)',$key));
        return $wpdb->last_error?null:$id!==null;
    }
    public static function shutdown(): void {
        $last=error_get_last();
        $cause='shutdown_before_completion';
        $known=false;
        if ($last&&in_array($last['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR],true)) {
            $cause=str_contains($last['message'],'Maximum execution time')?'time_limit':(str_contains($last['message'],'Allowed memory size')?'memory_limit':'php_fatal');
            $known=true;
        }
        foreach (self::$open_frames as $frame) {
            $results=[];
            foreach ($frame['connections'] as $cid) $results[$cid]=['state'=>'interrupted','success'=>null,'reason_code'=>$cause,'reason_evidence'=>'shutdown_handler','cause_known'=>$known];
            try {
                self::finish($frame,$results,'interrupted');
            }
            catch (\Throwable $e) {
                /* A dead/unwritable store remains explicitly unconfirmed. */
            }
        }
        self::$open_frames=[];
        if (self::$liveness_key) {
            global $wpdb;
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',self::$liveness_key));
            self::$liveness_key=null;
        }
    }
    public static function origin(): string {
        return defined( 'WP_CLI' ) && WP_CLI ? 'cli' : ( ( function_exists( 'wp_doing_cron' ) ? wp_doing_cron() : ( defined( 'DOING_CRON' ) && DOING_CRON ) ) ? 'http_cron' : 'manual' );
    }
    public static function init(): void {
        if (!self::$shutdown_registered) {
            register_shutdown_function([self::class,'shutdown']);
            self::$shutdown_registered=true;
        }
        if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( 'WP_CLI' ) && method_exists( 'WP_CLI', 'add_hook' ) ) {
            \WP_CLI::add_hook(
                'before_invoke:cron event run',
                static function ( $args ) {
                self::$invocation = self::begin( array_keys( Connections::registry() ), 'wp cron event run', true );
                return $args;
                }
            );
            \WP_CLI::add_hook(
                'after_invoke:cron event run',
                static function ( $args ) {
                if ( self::$invocation ) {
                    self::finish( self::$invocation, array(), 'observed' );
                    self::$invocation = null;
                    // No executor may have run: retain the observer's bounded maintenance.
                    ExecutorSchedule::ensure('cli_observer');
                    self::cleanup();
                }
                return $args;
                }
            );
        }
    }
    public static function begin( array $connections, string $entry = 'executor', bool $observation = false ): array {
        $r=\Fator3\McpGoogle\Recovery::run(static fn()=>self::begin_admitted($connections,$entry,$observation));
        if (isset($r['error_code']) && empty($r['success'])) {
            return ['run_id'=>Records::id(),'at'=>time(),'origem'=>self::origin(),'entry'=>$entry,'observation'=>$observation,'connections'=>$connections,'previous'=>[], 'errors'=>array_fill_keys($connections,$r)];
        }
        return $r;
    }
    private static function begin_admitted(array $connections,string $entry,bool $observation): array {
        $frame = self::$invocation ?? array(
            'run_id' => Records::id(),
            'at' => time(),
            'origem' => self::origin(),
            'entry' => $entry,
        );
        $frame['segment_id']=Records::id();
        $frame['connections'] = $connections;
        $frame['observation'] = $observation;
        $frame['errors'] = array();
        $frame['previous'] = array();
        $frame['rows'] = array();
        $frame['work_before'] = array();
        $live=self::liveness();
        foreach ( $connections as $cid ) {
            self::reconcile_admitted($cid);
            $frame['work_before'][$cid]=CronCoverage::snapshot($cid);
            $row = array(
                'liveness_key'=>$live,
                'work_before'=>$frame['work_before'][$cid],
                'at' => $frame['at'],
                'started_at' => $frame['at'],
                'run_id' => $frame['run_id'],
                'segment_id'=>$frame['segment_id'],
                'origem' => $frame['origem'],
                'entry' => $frame['entry'],
                'scope' => $observation ? 'wp_cli_invocation' : 'executor',
                'connection_id' => $cid,
                'connection_examined' => false,
                'success' => null,
                'items' => 0,
                'jobs' => 0,
                'schedules' => 0,
                'alerts' => 0,
                'state' => 'running',
                'finished_at' => null,
                'reason_code' => $observation ? 'google_executor_not_observed' : 'executor_entered',
                'reason_evidence' => $observation ? 'callback_not_observed' : 'callback_entered',
            );
            $frame['rows'][$cid]=$row;
            $saved = self::save( $row, 'begin' );
            if ( ! empty( $saved['previous'] ) && ( $saved['previous']['scope'] ?? '' ) === 'executor' ) {
                $frame['previous'][ $cid ] = $saved['previous'];
            }
            if ( ! $saved['success'] ) {
                if (empty($saved['event_persisted'])) $saved['coverage_gap_recorded']=self::gap($cid,$frame['run_id'],$saved,$frame['work_before'][$cid]??null);
                $frame['errors'][ $cid ] = self::busy($saved) ? $saved : self::record_failure( $row, $saved );
            }
        }
        self::$open_frames[$frame['segment_id']]=$frame;
        return $frame;
    }
    public static function finish( array $frame, array $results, string $reason = 'completed' ): array {
        try {
            $r=\Fator3\McpGoogle\Recovery::run(static fn()=>self::finish_admitted($frame,$results,$reason));
        }
        finally {
            unset(self::$open_frames[$frame['segment_id']??'']);
        }
        return isset($r['error_code']) && empty($r['success']) ? ['passes'=>[],'observability_error'=>$r] : $r;
    }
    private static function finish_admitted(array $frame,array $results,string $reason): array {
        $errors = array_filter($frame['errors'],static fn($e)=>!self::busy($e));
        $passes = array();
        foreach ( $frame['connections'] as $cid ) {
            // Initial recording failure blocks dispatch. Never invent a completed pass.
            if ( isset( $frame['errors'][ $cid ] ) && !self::busy($frame['errors'][$cid]) ) {
                continue;
            }
            $stored = CronStore::get( 'pass', $cid, $frame['run_id'] );
            if ($stored['success'] && !$stored['exists'] && isset($frame['rows'][$cid]) && isset($frame['errors'][$cid]) && self::busy($frame['errors'][$cid])) $stored['value']=$frame['rows'][$cid];
            $context = array(
                'connection_id' => $cid,
                'run_id' => $frame['run_id'],
                'segment_id'=>$frame['segment_id'],
                'origem' => $frame['origem'],
            );
            if ( ! $stored['success'] || ! self::valid_row( $stored['value'] ?? null ) ) {
                $errors[ $cid ] = self::record_failure( $context, self::error( 'f3_google_cron_read', 'finish', 'event', 'f3_google_option_read', false ) );
                continue;
            }
            $row = $stored['value'];
            if ( ! empty( $frame['observation'] ) && 'executor' === $row['scope'] ) {
                $passes[ $cid ] = $row;
                continue;
            }
            if (($row['history_status']??'')==='confirmed' && !empty($row['finished_at']) && ($row['segment_id']??null)===($frame['segment_id']??null)) {
                $passes[$cid]=$row+['history_persisted'=>true];
                continue;
            }
            $r = $results[ $cid ] ?? array();
            $previous = $frame['previous'][ $cid ] ?? array();
            if ( $previous ) {
                foreach ( array( 'items', 'jobs', 'schedules', 'alerts' ) as $field ) {
                    $r[ $field ] = (int) ( $r[ $field ] ?? 0 ) + (int) ( $previous[ $field ] ?? 0 );
                }
                $r['connection_examined'] = ! empty( $r['connection_examined'] ) || ! empty( $previous['connection_examined'] );
                if ( ( $previous['success'] ?? null ) === false ) {
                    $r['success'] = false;
                    $r['state'] = 'failed';
                }
            }
            $row = array_replace(
                $row,
                $r,
                array(
                    'finished_at' => time(),
                    'state' => $r['state'] ?? $reason,
                )
            );
            if ( ! empty( $frame['observation'] ) && !isset($r['reason_code']) ) {
                // The WP-CLI hook does not expose the final event selection. Do not infer absence.
                $row['reason_code'] = 'google_executor_not_observed';
                $row['reason_evidence'] = 'callback_not_observed';
            }
            elseif ( empty( $row['connection_examined'] ) ) {
                $row['reason_code'] = $r['reason_code'] ?? 'connection_not_examined';
                $row['reason_evidence'] = $r['reason_evidence'] ?? 'executor_result';
            }
            else {
                $row['reason_code'] = $r['reason_code'] ?? ( $row['items'] ? 'work_executed' : 'connection_examined_no_items' );
                $row['reason_evidence'] = $r['reason_evidence'] ?? 'executor_result';
            }
            $saved = self::save( $row, 'finish' );
            if ( ! $saved['success'] ) {
                if (empty($saved['event_persisted'])) $saved['coverage_gap_recorded']=self::gap($cid,$frame['run_id'],$saved,$frame['work_before'][$cid]??null);
                if (!self::busy($saved)) $errors[ $cid ] = self::record_failure( $row, $saved );
            }
            // This is the work outcome; persisted separately in observability fields.
            $row['history_persisted'] = $saved['success'];
            $row['history_status']=$saved['success']?'confirmed':(!empty($saved['event_persisted'])?'pending':'unconfirmed');
            $row['history_reason']=$saved['success']?null:($saved['code']??'f3_google_cron_persistence');
            $passes[ $cid ] = $row;
        }
        // Retention runs after the executor releases admission; never part of terminal commit.
        $maintenance=null;
        return array(
            'maintenance'=>$maintenance,
            'passes' => $passes,
            'observability_error' => $errors ? $errors : null,
        );
    }
    public static function busy(array $r): bool {
        return ($r['code']??null)==='f3_google_lock_busy' && in_array($r['cause_code']??null,['f3_google_option_exists','f3_google_lock_changed'],true);
    }
    private static function gap(string $cid,string $run,array $failure=[],?array $proof=null): bool {
        $lock=Lock::acquire('cron-gap:'.$cid,30);
        if (!$lock) return false;
        try {
            $key='f3_mcp_google_cron_gap_'.$cid;
            $old=Options::stored($key);
            if (!$old['success']||!Lock::owned($lock)) return false;
            $prior=is_array($old['value'])&&!isset($old['value']['resolved_at'])?$old['value']:null;
            $gap=['at'=>max(time(),(int)($prior['at']??0)),'run_id'=>$run,'reason'=>'event_not_confirmed',
                'cause_code'=>$failure['cause_code']??'unknown','cause_known'=>isset($failure['cause_code']),
                'phase'=>$failure['phase']??'unknown','work_outcome'=>'unknown','work_before'=>$proof];
            if ($prior) {
                $gap['work_before']=$prior['work_before']??null;
                $gap['interval_start']=$prior['interval_start']??$prior['at'];
            }
            else $gap['interval_start']=$proof['at']??time();
            return Options::set($key,$gap)['success'];
        }
        finally {
            Lock::release($lock);
        }
    }
    private static function event_key( string $cid, string $id ): string {
        return 'f3_mcp_google_cron_pass_' . $cid . '_' . $id;
    }
    private static function valid_row( $row, bool $projection = false ): bool {
        $valid = is_array( $row ) && is_string( $row['run_id'] ?? null ) && is_int( $row['at'] ?? null )
        && in_array( $row['origem'] ?? null, array( 'cli', 'http_cron', 'manual' ), true )
        && ( ( $projection && ! isset( $row['scope'] ) ) || in_array( $row['scope'] ?? null, array( 'executor', 'wp_cli_invocation' ), true ) );
        if ( ! $valid ) {
            return false;
        }
        foreach ( array( 'items', 'jobs', 'schedules', 'alerts' ) as $key ) {
            if ( array_key_exists( $key, $row ) && ( ! is_int( $row[ $key ] ) || $row[ $key ] < 0 ) ) {
                return false;
            }
        }
        return ( ! isset( $row['success'] ) || is_bool( $row['success'] ) )
        && ( ! isset( $row['connection_examined'] ) || is_bool( $row['connection_examined'] ) );
    }
    private static function valid_projection( $state ): bool {
        if ( ! is_array( $state ) ) {
            return false;
        }
        foreach ( array( 'last_pass', 'ultima_cli', 'ultima_http', 'ultima_manual' ) as $key ) {
            // Older projections may lack scope; retain that uncertainty verbatim.
            if ( isset( $state[ $key ] ) && ! self::valid_row( $state[ $key ], true ) ) {
                return false;
            }
        }
        foreach ( array( 'last_success', 'observed_since' ) as $key ) {
            if ( isset( $state[ $key ] ) && ! is_int( $state[ $key ] ) ) {
                return false;
            }
        }
        return true;
    }
    private static function error( string $code, string $phase, string $resource_kind, string $cause, bool $retryable ): array {
        return array(
            'success' => false,
            'code' => $code,
            'phase' => $phase,
            'resource' => $resource_kind,
            'cause_code' => $cause,
            'retryable' => $retryable,
            'storage' => 'google_cron_table',
            'at' => time(),
        );
    }
    private static function record_failure( array $row, array $result ): array {
        $error = array_intersect_key( $result, array_flip( array( 'code', 'phase', 'resource', 'cause_code', 'retryable', 'storage', 'at', 'attempts', 'event_persisted' ) ) );
        $error += array(
            'at' => time(),
            'origem' => $row['origem'],
            'run_id' => $row['run_id'],
            'connection_id' => $row['connection_id'],
        );
        $installed = CronStore::ensure_ready();
        $held = Lock::acquire_result('cron-incident:'.$row['connection_id'],30);
        $error['diagnostic_persisted']=false;
        $error['diagnostic_projection_persisted']=false;
        if (is_wp_error($installed)||!$held['success']) {
            $error['diagnostic_error_code']=is_wp_error($installed)?$installed->get_error_code():$held['code'];
            return $error;
        }
        try {
            $error['error_id']=Records::id();
            $saved=CronStore::put('incident',$row['connection_id'],$error['error_id'],$error,null,$held['lock']);
            $error['diagnostic_persisted']=$saved['success'];
            $error['diagnostic_error_code']=$saved['success']?null:($saved['error_code']??'f3_google_cron_storage_incident');
            $projected=Lock::owned($held['lock'])?Options::set('f3_mcp_google_cron_error_'.$row['connection_id'],$error):['success'=>false];
            $error['diagnostic_projection_persisted']=$projected['success'];
            return $error;
        }
        finally {
            Lock::release($held['lock']);
        }
    }
    private static function acquire( string $cid, string $kind='history' ): array {
        for ( $attempt = 1; $attempt <= 3; ++$attempt ) {
            $r = Lock::acquire_result( 'cron-'.$kind.':' . $cid, 30 );
            $r['attempts'] = $attempt;
            if ( $r['success'] || ! $r['retryable'] || 3 === $attempt ) {
                return $r;
            }
            usleep( 10000 * $attempt );
        }
        return $r;
    }
    /** Called under a short connection lock. Event precedes all projection reads/writes. */
    private static function save( array $row, string $phase ): array {
        $cid = $row['connection_id'];
        $installed=CronStore::ensure_ready();
        if(is_wp_error($installed))return self::error($installed->get_error_code(),$phase,'event',$installed->get_error_code(),false);
        $observed=CronErrors::snapshot($cid);
        if (!$observed['success']) return self::error('f3_google_cron_read',$phase,'incident','f3_google_cron_storage_read',false);
        $acquired = self::acquire( $cid );
        if ( ! $acquired['success'] ) {
            return self::error( $acquired['code'], $phase, 'lock', $acquired['cause_code'], $acquired['retryable'] ) + array(
                'attempts' => $acquired['attempts'],
                'event_persisted' => false,
            );
        }
        $projection=null;
        try {
            $event = self::event_key( $cid, $row['run_id'] );
            $old = CronStore::get( 'pass', $cid, $row['run_id'] );
            if ( ! $old['success'] || ( $old['exists'] && ! self::valid_row( $old['value'] ) ) ) {
                return self::error( 'f3_google_cron_read', $phase, 'event', 'f3_google_option_read', false );
            }
            if (in_array($phase,['reconcile','reconcile_terminal','observe_interruption'],true) && $old['exists']) $row=$old['value'];
            if ($phase==='observe_interruption' && ($row['state']??'')==='running' && self::alive($row)!==true && $row['at']<time()-120) {
                $row=array_replace($row,['state'=>'interrupted','success'=>null,'reason_code'=>'completion_not_recorded','reason_evidence'=>self::alive($row)===false?'database_session_ended':'history_only','cause_known'=>false,'observed_end_at'=>time()]);
            }
            // An observer never replaces a child executor. Repeated close is idempotent.
            if ( 'wp_cli_invocation' === $row['scope'] && 'executor' === ( $old['value']['scope'] ?? '' ) ) {
                $row = $old['value'];
            }
            elseif ( 'begin' === $phase && 'executor' === ( $old['value']['scope'] ?? '' ) ) {
                $row = array_replace( $row, array_intersect_key( $old['value'], array_flip( array( 'items', 'jobs', 'schedules', 'alerts', 'connection_examined', 'success' ) ) ) );
            }
            if ( ! Lock::owned( $acquired['lock'] ) ) {
                return self::error( 'f3_google_lock_lost', $phase, 'lock', 'f3_google_lock_changed', true );
            }
            $row['history_status']='pending';
            $saved = CronStore::put( 'pass', $cid, $row['run_id'], $row, null, $acquired['lock'] );
            if ( ! $saved['success'] ) {
                return self::error( 'f3_google_cron_event', $phase, 'event', $saved['error_code'], false ) + array( 'event_persisted' => false );
            }
            $projected=self::acquire($cid,'projection');
            if (!$projected['success']) return self::error($projected['code'],$phase,'projection_lock',$projected['cause_code'],$projected['retryable'])+['event_persisted'=>true];
            $projection=$projected['lock'];
            $key = 'f3_mcp_google_cron_history_' . $cid;
            $stored = Options::stored( $key );
            if ( ! $stored['success'] || ( $stored['exists'] && ! self::valid_projection( $stored['value'] ) ) ) {
                return self::error( 'f3_google_cron_read', $phase, 'projection', 'f3_google_option_read', false ) + array( 'event_persisted' => true );
            }
            $state = $stored['value'] ?? array(
                'observed_since' => $row['at'],
                'window_complete' => false,
            );
            $state = self::project( $state, $row );
            if ( ! Lock::owned( $acquired['lock'] ) ) {
                return self::error( 'f3_google_lock_lost', $phase, 'lock', 'f3_google_lock_changed', true ) + array( 'event_persisted' => true );
            }
            $saved = self::write_retry( $key, $state );
            if ( ! $saved['success'] ) {
                return self::error( 'f3_google_cron_projection', $phase, 'projection', $saved['error_code'], false ) + array( 'event_persisted' => true );
            }
            if (in_array($phase,['finish','reconcile_terminal'],true) && !empty($row['finished_at']) && $row['state']!=='yielded') {
                $resolution=CronErrors::resolve($cid,$observed,$row);
                if (!$resolution['success']) return self::error($resolution['code'],$phase,'resolution',$resolution['cause_code'],$resolution['retryable'])+['event_persisted'=>true];
            }
            $row['history_status']='confirmed';
            $confirmed=CronStore::put('pass',$cid,$row['run_id'],$row,null,$acquired['lock']);
            if (!$confirmed['success']) return self::error('f3_google_cron_event',$phase,'event',$confirmed['error_code'],false)+['event_persisted'=>true];
            return array(
                'success' => true,
                'event_persisted' => true,
                'previous' => $old['value'],
                'attempts' => $acquired['attempts'],
            );
        }
        finally {
            if ($projection) Lock::release($projection);
            Lock::release( $acquired['lock'] );
        }
    }
    private static function write_retry( string $key, array $value ): array {
        // Repeats only idempotent history storage, never a job or an HTTP request.
        for ( $attempt = 0; $attempt < 3; ++$attempt ) {
            $saved = Options::set( $key, $value );
            if ( $saved['success'] ) {
                break;
            }
            if ( $attempt < 2 ) {
                usleep( 10000 );
            }
        }
        return $saved;
    }
    private static function project( array $state, array $row ): array {
        $field = array(
            'cli' => 'ultima_cli',
            'http_cron' => 'ultima_http',
            'manual' => 'ultima_manual',
        )[ $row['origem'] ];
        foreach ( array_merge( array( $field ), 'executor' === $row['scope'] ? array( 'last_pass' ) : array() ) as $f ) {
            $prior = $state[ $f ] ?? null;
            if ( ! $prior || array( $row['at'], $row['run_id'] ) >= array( $prior['at'], $prior['run_id'] ) ) {
                $state[ $f ] = $row;
            }
        }
        if ( ( $row['success'] ?? null ) === true && $row['at'] > ( $state['last_success'] ?? 0 ) ) {
            $state['last_success'] = $row['at'];
        }
        return $state;
    }
    /** Reconcile one durable event into its fixed projection under the connection lock. */
    public static function reconcile(string $cid): array {
        return \Fator3\McpGoogle\Recovery::run(static fn()=>self::reconcile_admitted($cid));
    }
    private static function reconcile_admitted(string $cid): array {
        $rows=CronStore::pending($cid,20);
        if (is_wp_error($rows)) return self::error('f3_google_cron_read','reconcile','event',$rows->get_error_code(),false);
        foreach ($rows as $row) {
            if (Execution::remaining()<1) return ['success'=>true,'deferred'=>true];
            if (!self::valid_row($row)) return self::error('f3_google_cron_read','reconcile','event','f3_google_cron_storage_corrupt',false);
            $r=self::save($row,empty($row['finished_at'])?'reconcile':'reconcile_terminal');
            if (!$r['success']) return $r;
        }
        foreach (['cli','http_cron','manual'] as $origin) {
            if (Execution::remaining()<1) return ['success'=>true,'deferred'=>true];
            $row=CronStore::latest($cid,'pass','origin',$origin);
            if (is_wp_error($row)) return self::error('f3_google_cron_read','reconcile','event',$row->get_error_code(),false);
            // Rows are read per connection; older payloads may omit the field (0.18.0).
            if ($row && !isset($row['connection_id'])) $row['connection_id']=$cid;
            if ($row) {
                if (($row['state']??'')==='running' && self::alive($row)!==true && $row['at']<time()-120) {
                    if (!self::gap($cid,$row['run_id'],[], $row['work_before']??null)) return self::error('f3_google_cron_gap_write','reconcile','gap','f3_google_option_write',false);
                    $r=self::save($row,'observe_interruption');
                }
                else $r=self::save($row,'reconcile');
                if (!$r['success']) return $r;
            }
        }
        return CronCoverage::reconcile($cid);
    }
    public static function summary(string $cid,?int $now=null): array {
        $now=$now??time();
        $base=['last_pass'=>null,'ultima_cli'=>null,'ultima_http'=>null,'ultima_manual'=>null,'last_success'=>null,'cron_servidor_ativo'=>false,'executor'=>'wp-cron','agendamento_verificado'=>false,'passagens_24h'=>['cli'=>0,'http_cron'=>0,'manual'=>0],'observed_since'=>null,'window_complete'=>false,'observability_error'=>null,'last_observability_error'=>null,'projection_reconciled_in_memory'=>false,'retention_days'=>CronStore::DAYS,'max_passes'=>CronStore::MAX_PASSES,'history_storage'=>'google_cron_table'];
        $s=Options::stored('f3_mcp_google_cron_history_'.$cid);
        $bad=!$s['success']||($s['exists']&&!self::valid_projection($s['value']));
        if(!$bad)$base=array_replace($base,array_intersect_key($s['value']??[],array_flip(['last_pass','ultima_cli','ultima_http','ultima_manual','last_success','observed_since'])));
        foreach([['origin','cli'],['origin','http_cron'],['origin','manual'],['scope','executor'],['success','1']]as$filter) {
            $r=CronStore::latest($cid,'pass',$filter[0],$filter[1]);
            if(is_wp_error($r)||($r&&!self::valid_row($r))){
                $bad=true;
                continue;
            }
            if($r){
                $before=$base;
                $base=self::project($base,$r);
                if($before!==$base)$base['projection_reconciled_in_memory']=true;
            }
        }
        $counts=CronStore::counts($cid,$now);
        if(is_wp_error($counts))$bad=true;
        else foreach($counts as$row){
            if(isset($base['passagens_24h'][$row['origin']]))$base['passagens_24h'][$row['origin']]=(int)$row['total'];
            else$bad=true;
        }
        $diagnostic=CronErrors::snapshot($cid);
        if (!$diagnostic['success']) $bad=true;
        elseif ($diagnostic['error']) {
            $base['last_observability_error']=$diagnostic['error'];
            if (!isset($diagnostic['error']['resolved_at'])) $base['observability_error']=$diagnostic['error'];
        }
        $pending_rows=CronStore::pending($cid,1);
        $base['history_pending']=is_wp_error($pending_rows)?null:(bool)$pending_rows;
        if (is_wp_error($pending_rows)) $bad=true;
        $global=Options::stored(\Fator3\McpGoogle\Storage\Maintenance::OPTION);
        $base['maintenance']=null;
        if (!$global['success']) {
            $bad=true;
        }
        elseif (is_array($global['value'])) {
            $codes=array_values(array_filter($global['value']['errors']??[],static fn($code)=>str_starts_with($code,'f3_google_cron_')||$code==='f3_google_lock_lost'));
            $retention=$global['value']['progress']['cron_retention']??[];
            $base['maintenance']=['at'=>$global['value']['at']??null,'success'=>!$codes,'complete'=>!empty($retention['complete'])&&!empty($retention['examined_in_pass']),'connection_id'=>$cid,'scope'=>'global_retention','error_code'=>$codes[0]??null];
            if ($codes) $base['observability_error']=self::error('f3_google_cron_maintenance','maintenance','history',$codes[0],true);
        }
        $cut=Options::stored('f3_mcp_google_cron_truncated_'.$cid);
        if(!$cut['success'])$bad=true;
        $base['truncated_in_window']=$cut['success']&&(int)($cut['value']??0)>$now-86400;
        $gap=Options::stored('f3_mcp_google_cron_gap_'.$cid);
        if (!$gap['success']||($gap['exists']&&(!is_array($gap['value'])||!is_int($gap['value']['at']??null)))) $bad=true;
        $base['last_coverage_gap']=$gap['success']&&is_array($gap['value'])?$gap['value']:null;
        $base['coverage_gap']=$base['last_coverage_gap']&&!isset($gap['value']['resolved_at'])&&($gap['value']['at']??0)>$now-86400?$gap['value']:null;
        if($bad)$base['observability_error']=self::error('f3_google_cron_read','summary','history','f3_google_cron_storage_read',false);
        $unclosed=false;
        foreach(['last_pass','ultima_cli','ultima_http','ultima_manual']as$f) {
            if(is_array($base[$f])&&($base[$f]['state']??'')==='running') {
                $alive=self::alive($base[$f]);
                $base[$f]['process_observed_alive']=$alive;
                if ($alive===false || ($alive===null&&$base[$f]['at']<$now-120)) {
                    $base[$f]['state']='interrupted';
                    $base[$f]['success']=null;
                    $base[$f]['reason_code']='completion_not_recorded';
                    $base[$f]['reason_evidence']=$alive===false?'database_session_ended':'history_only';
                    $base[$f]['cause_code']='unknown';
                    $base[$f]['cause_known']=false;
                    if ($base[$f]['at']>$now-86400) $unclosed=true;
                }
            }
        }
        $base['completion_unconfirmed']=$unclosed;
        $base['observation_health']=$bad?'unreadable':(($base['coverage_gap']||$unclosed)?'gap':'observed');
        $at=$base['ultima_cli']['at']??null;
        $base['cron_servidor_ativo']=!$bad&&is_int($at)&&$at<=$now&&$at>=$now-7200;
        $base['executor']=$base['cron_servidor_ativo']?'server-cron':'wp-cron';
        $base['window_complete']=!$bad&&!$unclosed&&!$base['coverage_gap']&&!$base['truncated_in_window']&&!$base['history_pending']&&!$base['observability_error']&&is_int($base['observed_since'])&&$base['observed_since']<=$now-86400;
        // Stored projections keep `last_pass`; the public name avoids the MCP redaction component `pass` (0.32.0).
        $out=[];
        foreach($base as $key=>$value) $out['last_pass'===$key?'last_run':$key]=$value;
        return $out;
    }
    public static function schema(): array {
        $pass = array(
            'type' => array( 'object', 'null' ),
            'properties' => array(
                'at' => array( 'type' => 'integer' ),
                'started_at' => array( 'type' => 'integer' ),
                'finished_at' => array( 'type' => array( 'integer', 'null' ) ),
                'run_id' => array( 'type' => 'string' ),
                'origem' => array(
                    'type' => 'string',
                    'enum' => array( 'cli', 'http_cron', 'manual' ),
                ),
                'scope' => array(
                    'type' => 'string',
                    'enum' => array( 'executor', 'wp_cli_invocation' ),
                ),
                'connection_id' => array( 'type' => 'string' ),
                'connection_examined' => array( 'type' => 'boolean' ),
                'success' => array( 'type' => array( 'boolean', 'null' ) ),
                'items' => array( 'type' => 'integer' ),
                'state' => array( 'type' => 'string' ),
                'reason_code' => array( 'type' => 'string' ),
                'reason_evidence' => array( 'type' => 'string' ),
                'cause_code'=>['type'=>'string'],'cause_known'=>['type'=>'boolean'],'process_observed_alive'=>['type'=>['boolean','null']],
                'history_status'=>['type'=>'string','enum'=>['confirmed','pending','unconfirmed']],
                'history_persisted'=>['type'=>'boolean'],
                'history_reason'=>['type'=>['string','null']],
            ),
        );
        $error = array(
            'type' => array( 'object', 'string', 'null' ),
            'properties' => array(
                'code' => array( 'type' => 'string' ),
                'at' => array( 'type' => 'integer' ),
                'origem' => array( 'type' => 'string' ),
                'run_id' => array( 'type' => 'string' ),
                'connection_id' => array( 'type' => 'string' ),
                'phase' => array( 'type' => 'string' ),
                'cause_code' => array( 'type' => 'string' ),
                'storage' => array( 'type' => 'string' ),
                'resource' => array( 'type' => 'string' ),
                'retryable' => array( 'type' => 'boolean' ),
                'event_persisted' => array( 'type' => 'boolean' ),
                'error_id'=>['type'=>'string'],
                'resolved_at'=>['type'=>'integer'],
                'resolved_by'=>['type'=>'object','properties'=>['run_id'=>['type'=>'string'],'origem'=>['type'=>'string'],'connection_id'=>['type'=>'string'],'basis'=>['type'=>'string']]],
                'success'=>['type'=>'boolean'],'attempts'=>['type'=>'integer'],'diagnostic_projection_persisted'=>['type'=>'boolean'],
                'diagnostic_persisted' => array( 'type' => 'boolean' ),
                'diagnostic_error_code' => array( 'type' => array( 'string', 'null' ) ),
            ),
        );
        return array(
            'type' => 'object',
            'properties' => array(
                'observation_health'=>['type'=>'string','enum'=>['unreadable','gap','observed']],
                'completion_unconfirmed'=>['type'=>'boolean'],
                'last_coverage_gap'=>['type'=>['object','null']],
                'work_observation'=>['type'=>'object','properties'=>['state'=>['type'=>'string','enum'=>['due','no_due_work','unknown']],'at'=>['type'=>'integer'],'interval_proven'=>['type'=>'boolean']]],
                'history_pending'=>['type'=>['boolean','null']],
                'coverage_gap'=>['type'=>['object','null'],'properties'=>['at'=>['type'=>'integer'],'run_id'=>['type'=>'string'],'reason'=>['type'=>'string']]],
                'history_storage'=>['type'=>'string','enum'=>['google_cron_table']],
                'retention_days'=>['type'=>'integer'],
                'max_passes'=>['type'=>'integer'],
                'truncated_in_window'=>['type'=>'boolean'],
                'maintenance'=>['type'=>['object','null'],'properties'=>['at'=>['type'=>['integer','null']],'success'=>['type'=>'boolean'],'complete'=>['type'=>'boolean'],'connection_id'=>['type'=>'string'],'scope'=>['type'=>'string'],'error_code'=>['type'=>['string','null']]]],
                'health'=>['type'=>'string','enum'=>['degraded','due','blocked','idle']], 'work_health'=>['type'=>'string','enum'=>['unknown','due','blocked','idle']],'scheduling'=>Scheduling::schema(),
                'schedule_observation'=>array_replace(Scheduling::schema()['properties']['observations']['items'],['type'=>['object','null']]),
                'requires_trigger'=>['type'=>'boolean'],'disabled_builtin_trigger'=>['type'=>'boolean'],
                'next_run'=>['type'=>['integer','null']],'observed_at'=>['type'=>'integer'],'connection_id'=>['type'=>'string'],
                'agendas_vencidas'=>['type'=>['integer','null']],'blocked_schedules'=>['type'=>['integer','null']],
                'oldest_due_at'=>['type'=>['integer','null']],'oldest_delay_seconds'=>['type'=>['integer','null']],
                'storage'=>\Fator3\McpGoogle\Storage\State::schema(),
                'jobs'=>['type'=>'object','properties'=>array_fill_keys(['pending','approval_required','running','dispatching','blocked','unknown','failed','completed'],['type'=>'integer'])],
                'execution_in_progress'=>['type'=>'boolean'],'read_error'=>['type'=>'string'],
                'last_success'=>['type'=>['integer','null']],
                'observed_since'=>['type'=>['integer','null']],
                'passagens_24h'=>['type'=>'object','properties'=>array_fill_keys(['cli','http_cron','manual'],['type'=>'integer'])],
                'last_run' => $pass,
                'ultima_cli' => $pass,
                'ultima_http' => $pass,
                'ultima_manual' => $pass,
                'cron_servidor_ativo' => array( 'type' => 'boolean' ),
                'executor' => array(
                    'type' => 'string',
                    'enum' => array( 'server-cron', 'wp-cron' ),
                ),
                'agendamento_verificado' => array( 'type' => 'boolean' ),
                'window_complete' => array( 'type' => 'boolean' ),
                'observability_error' => $error,
                'last_observability_error' => $error,
                'projection_reconciled_in_memory' => array( 'type' => 'boolean' ),
            ),
        );
    }
    public static function cleanup(): array {
        return \Fator3\McpGoogle\Storage\Maintenance::once();
    }
}
