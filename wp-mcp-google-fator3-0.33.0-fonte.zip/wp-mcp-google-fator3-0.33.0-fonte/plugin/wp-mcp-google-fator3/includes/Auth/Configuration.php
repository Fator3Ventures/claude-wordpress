<?php
/**
 * Credential preparation and explicit activation shared by every admin entry point.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\{Options, Settings, Connections, Response};
use Fator3\McpGoogle\Http\GoogleClient;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Configuration {

	public const JSON_MAX_BYTES = 1048576;
	private static function fail( string $code, string $message ): array {
		return Response::fail(
			new \WP_Error( $code, $message ),
			array(
				'persisted' => false,
				'changed'   => false,
			)
		);
	}
	public static function import( string $json, ?string $method = null, bool $activate = false, ?string $expected = null ): array {
		if ( strlen( $json ) > self::JSON_MAX_BYTES ) {
			return self::fail( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' );
		}
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			return self::fail( 'f3_google_credential_json', 'JSON inválido. Envie o arquivo de credenciais completo.' );
		}
		if ($method==='service_account' && (isset($data['web'])||isset($data['installed']))) return self::fail('f3_google_credential_type','Este é o JSON de um cliente OAuth, não a chave de uma conta de serviço. A chave salva continua em uso.');
		$detected = ( $data['type'] ?? '' ) === 'service_account' ? 'service_account' : ( isset( $data['web'] ) ? 'oauth' : '' );
		if ( '' === $detected || ( null !== $method && $method !== $detected ) ) {
			return self::fail( 'f3_google_credential_type', 'O tipo do JSON não corresponde ao método selecionado. Abra a aba correspondente ao arquivo.' );
		}
		if ( 'service_account' === $detected ) {
			return self::save_sa( $json, null, $activate, $expected );
		}
		$web = $data['web'];
		if ( ! is_array( $web ) || ! is_string( $web['client_id'] ?? null ) || ! is_string( $web['client_secret'] ?? null ) || '' === $web['client_id'] || '' === $web['client_secret'] ) {
			return self::fail( 'f3_google_oauth_client_json', 'Envie o JSON de um cliente OAuth do tipo aplicativo Web.' );
		}
		if ( ! in_array( OAuthFlow::redirect_uri(), (array) ( $web['redirect_uris'] ?? array() ), true ) ) {
			return self::fail( 'f3_google_oauth_redirect', 'Cadastre o callback exibido na aba OAuth no cliente Web e baixe o JSON atualizado.' );
		}
		return self::save_oauth( $web['client_id'], $web['client_secret'], $expected );
	}
	public static function save_sa( string $json, ?string $subject = null, bool $activate = false, ?string $expected = null ): array {
		if ( ! Options::authorized() ) {
			return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' );
		}
		$revision = Validation::revision($expected);
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}
		if ( strlen( $json ) > self::JSON_MAX_BYTES ) {
			return self::fail( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' );
		}
		$prior = Candidate::read( 'service_account' );
		if ( is_wp_error( $prior ) ) {
			return Response::fail( $prior );
		}
		$values  = $prior['values'] ?? array( Options::SA_SUBJECT => Options::get( Options::SA_SUBJECT, '' ) );
		$secrets = $prior['secrets'] ?? array( Options::SA_JSON => Options::get_secret( Options::SA_JSON ) );
		if ( null !== $subject ) {
			if ( '' !== $subject && ! is_email( $subject ) ) {
				return self::fail( 'f3_google_sa_subject', 'Informe e-mail válido.' );
			} $values[ Options::SA_SUBJECT ] = $subject;
		}
		if ( '' !== trim( $json ) ) {
			$key = ServiceAccount::validate_key( $json, true );
			if ( is_wp_error( $key ) ) {
				return Response::fail( $key );
			} $secrets[ Options::SA_JSON ] = wp_json_encode( $key );
		}
		if ( '' === ( $secrets[ Options::SA_JSON ] ?? '' ) ) {
			return self::fail( 'f3_google_candidate_missing', 'Importe uma chave antes de ativar.' );
		}
		$data=['mode'=>'service_account','values'=>$values,'secrets'=>$secrets];
		if ($activate) return self::commit_sa($data,$revision)+['warnings'=>ServiceAccount::warnings(json_decode($secrets[Options::SA_JSON],true))];
		// Check even a resubmitted equal key: it may have been revoked since the last save.
		$checked=Validation::sa($data);
		if (empty($checked['success'])) return $checked;
		$saved=Candidate::save('service_account',$values,$secrets,$revision);
		return $saved+['warnings'=>$checked['warnings']??[],'authentication_validated'=>true,'identity_change_required'=>self::identity_change($data),'message'=>self::identity_change($data)?self::identity_message($data):'Chave validada e preparada. Use a ação de ativação.'];
	}
	public static function save_oauth( string $id, string $secret, ?string $expected = null ): array {
		if ( ! Options::authorized() ) {
			return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' );
		}
		$revision = Validation::revision( $expected );
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}
		if (!preg_match('/^[A-Za-z0-9._-]+\.apps\.googleusercontent\.com$/D',$id)) {
			return self::fail( 'f3_google_oauth_client', 'Informe o Client ID do aplicativo Web.' );
		}
		if ($secret!=='' && !preg_match('/^GOCSPX-[A-Za-z0-9_-]+$/D',$secret)) return self::fail('f3_google_oauth_secret','A chave secreta do cliente deve começar com GOCSPX-. Não informe o Client ID nem a chave JSON. O segredo salvo continua em uso.');
		$prior = Candidate::read( 'oauth' );
		if ( is_wp_error( $prior ) ) {
			return Response::fail( $prior );
		}
		$values  = $prior['values'] ?? array(
			Options::OAUTH_CLIENT_ID => Options::get( Options::OAUTH_CLIENT_ID, '' ),
			Options::OAUTH_EMAIL     => Options::get( Options::OAUTH_EMAIL, '' ),
			Options::OAUTH_SCOPES    => Options::get( Options::OAUTH_SCOPES, array() ),
		);
		$secrets = $prior['secrets'] ?? array(
			Options::OAUTH_CLIENT_SECRET => Options::get_secret( Options::OAUTH_CLIENT_SECRET ),
			Options::OAUTH_REFRESH_TOKEN => Options::get_secret( Options::OAUTH_REFRESH_TOKEN ),
		);
		$client_changed = $id !== ( $values[ Options::OAUTH_CLIENT_ID ] ?? '' );
		if ( '' === $secret && ( $client_changed || empty( $secrets[ Options::OAUTH_CLIENT_SECRET ] ) ) ) {
			return self::fail( 'f3_google_oauth_secret_required', 'Informe a chave secreta deste aplicativo. Ao trocar o Client ID, informe também o Client secret correspondente.' );
		}
		if ( $client_changed || ( '' !== $secret && $secret !== ( $secrets[ Options::OAUTH_CLIENT_SECRET ] ?? '' ) ) ) {
			unset( $secrets[ Options::OAUTH_REFRESH_TOKEN ], $values[ Options::OAUTH_EMAIL ], $values[ Options::OAUTH_SCOPES ] );
		}
		$values[ Options::OAUTH_CLIENT_ID ] = $id;
		if ( '' !== $secret ) {
			$secrets[ Options::OAUTH_CLIENT_SECRET ] = $secret;
		}
		return Candidate::save( 'oauth', $values, $secrets, $revision );
	}
	/** Same resource set for both credential activation paths. */
	public static function bound_services( array $bindings ): array {
		$services = array();
		foreach ( array( 'ga_property_id' => 'ga', 'ads_customer_id' => 'ads', 'gsc_site_url' => 'gsc', 'spreadsheet_id' => 'sheets', 'gtm_container_path' => 'gtm' ) as $key => $service ) {
			if ( ! empty( $bindings[ $key ] ) ) {
				$services[] = $service;
			}
		}
		return $services;
	}
	public static function activate( string $mode, ?string $expected = null ): array {
		if ( ! in_array( $mode, Options::AUTH_MODES, true ) ) {
			return self::fail( 'f3_google_auth_mode', 'Método inválido.' );
		}
		return Candidate::promote( $mode, $expected );
	}
	public static function identity_change(array $data): bool {
		$old=json_decode(Options::get_secret(Options::SA_JSON),true);
		$new=json_decode($data['secrets'][Options::SA_JSON]??'',true);
		return is_array($old)&&!empty($old['client_email'])&&is_array($new)&&$old['client_email']!==($new['client_email']??'');
	}
	public static function identity_message(array $data): string {
		$key=json_decode($data['secrets'][Options::SA_JSON]??'',true);
		return 'A chave nova é de outra conta de serviço ('.($key['client_email']??'').'). As contas do Analytics, do Search Console e do Google Ads precisam dar acesso a ela antes da troca. Para trocar, use \'Trocar identidade\': a seleção de serviços e recursos é mantida e a tela lista o que a nova conta ainda não acessa.';
	}
	private static function rotation(array $data): bool {
		if (Options::auth_mode()!=='service_account'||!Credentials::is_configured()) return false;
		return hash_equals(Credentials::execution_identity(),Candidate::preview($data,static fn()=>Credentials::execution_identity()));
	}
	private static function bound_checks(array $data): array {
		return Candidate::preview($data,static function(){
			$bindings=(array)Options::get(Connections::BINDINGS,[]);
			$services=self::bound_services($bindings);
			if (!$services) return ['success'=>true,'all_checks_passed'=>true,'checks'=>[],'resource_access_validated'=>false];
			$r=\Fator3\McpGoogle\Preflight::run(['services'=>$services,'bindings'=>$bindings]);
			return $r+['resource_access_validated'=>!empty($r['all_checks_passed'])];
		});
	}
	public static function plan_identity_change(?string $expected): array {
		$revision=Validation::revision($expected);if(is_wp_error($revision))return Response::fail($revision);
		$data=Candidate::read('service_account');
		if(!is_array($data))return self::fail('f3_google_candidate_missing','Prepare a chave candidata antes de simular a troca.');
		$checked=Validation::sa($data);if(empty($checked['success']))return $checked;
		$preflight=self::bound_checks($data);
		$now=Settings::revision();if(is_wp_error($now)||!hash_equals($revision,$now))return Settings::conflict();
		return Response::ok(['expected_revision'=>$revision,'plan_hash'=>self::plan_hash($revision,$data),'preflight'=>$preflight,'can_switch'=>!empty($preflight['all_checks_passed']), 'message'=>self::identity_message($data),'active_preserved'=>true]);
	}
	private static function plan_hash(string $revision,array $data): string {
		return hash_hmac('sha256',Connections::id().'|'.get_current_user_id().'|'.$revision.'|'.($data['revision']??'').'|'.Validation::sa_fingerprint($data),wp_salt('auth'));
	}
	public static function switch_identity(string $expected,string $plan): array {
		$revision=Validation::revision($expected);if(is_wp_error($revision))return Response::fail($revision);
		$data=Candidate::read('service_account');
		if(!is_array($data)||!hash_equals(self::plan_hash($revision,$data),$plan))return self::fail('f3_google_identity_plan','Simule novamente a troca de identidade.');
		return self::commit_sa($data,$revision,true);
	}
	public static function commit_sa(array $data,?string $expected,bool $confirmed=false): array {
		$revision=Validation::revision($expected);if(is_wp_error($revision))return Response::fail($revision);
		if(apply_filters('f3_mcp_google_auth_mode','service_account')!=='service_account')return self::fail('f3_google_auth_override','Método controlado por código.');
		if(self::identity_change($data)&&!$confirmed)return self::fail('f3_google_identity_change_required',self::identity_message($data));
		$checked=Validation::sa($data);if(empty($checked['success']))return $checked;
		$rotation=self::rotation($data);
		$current=Settings::revision();if(is_wp_error($current)||!hash_equals($revision,$current))return Settings::conflict();
		$preflight=$confirmed?self::bound_checks($data):['all_checks_passed'=>true,'checks'=>[],'resource_access_validated'=>false];
		$current=Settings::revision();if(is_wp_error($current)||!hash_equals($revision,$current))return Settings::conflict();
		if(empty($preflight['all_checks_passed']))return self::fail('f3_google_candidate_access','A candidata não confirmou acesso aos recursos vinculados. A chave salva continua em uso.')+['preflight'=>$preflight];
		$receipts=Validation::receipts();if(is_wp_error($receipts))return Response::fail($receipts);
		$values=$data['values']+[Options::AUTH_MODE=>'service_account',Settings::AUTH_READY=>true];
		if($rotation){
			$preserved=\Fator3\McpGoogle\ConversionDelivery::rotation_values($data);
			if(is_wp_error($preserved))return Response::fail($preserved);
			$values+=$preserved;
			// Preserve absent legacy AUTH_READY too: job revisions distinguish absent and true.
			$ready=Options::stored(Options::storage_name(Settings::AUTH_READY));
			if(!$ready['success'])return self::fail('f3_google_option_read','Falha ao ler a ativação.');
			if(!$ready['exists'])unset($values[Settings::AUTH_READY]);
			$old=json_decode(Options::get_secret(Options::SA_JSON),true);$new=json_decode($data['secrets'][Options::SA_JSON],true);
			if(Options::get_secret(Options::SA_JSON)!==$data['secrets'][Options::SA_JSON]){
				$history=(array)($receipts['rotations']??[]);$history[]=['at'=>time(),'by'=>get_current_user_id(),'from_suffix'=>substr((string)($old['private_key_id']??''),-8),'to_suffix'=>substr((string)($new['private_key_id']??''),-8)];$receipts['rotations']=array_slice($history,-20);
			}
		}
		$services=[];foreach($preflight['checks']??[] as $check)if(($check['status']??'')==='passed')$services[]=substr($check['name'],5);
		$previous=Validation::summary();
		$receipts['service_account']=['fingerprint'=>Validation::sa_fingerprint($data),'at'=>$checked['checked_at'],'services'=>$rotation?($previous['services']??[]):$services,'resource_access_at'=>$rotation?($previous['resource_access_at']??null):($services?time():null)];
		$values[Validation::RECEIPTS]=$receipts;
		$saved=Settings::save($values,$data['secrets'],[Candidate::SA],$revision);
		return $saved+['warnings'=>$checked['warnings']??[],'authentication_validated'=>true,'resource_access_validated'=>$preflight['resource_access_validated'],'rotation'=>$rotation,'activated'=>!empty($saved['success']),'auth_mode'=>'service_account'];
	}
	public static function clear( string $mode, ?string $expected = null ): array {
		if ( ! Options::authorized() ) {
			return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' );
		}
		if ( ! in_array( $mode, Options::AUTH_MODES, true ) ) {
			return self::fail( 'f3_google_auth_mode', 'Método inválido.' );
		}
		$names   = 'service_account' === $mode ? array( Options::SA_JSON, Options::SA_SUBJECT ) : array( Options::OAUTH_CLIENT_ID, Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES );
		$names[] = Candidate::name( $mode );
		return Settings::save( array(), array(), $names, $expected );
	}
}
