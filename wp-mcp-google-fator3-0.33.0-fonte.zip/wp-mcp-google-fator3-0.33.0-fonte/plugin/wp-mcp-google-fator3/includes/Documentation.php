<?php
/** Allowlisted installed documentation. No provider, connection or storage calls. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Documentation {
    public const MAX_BYTES = 65536;
    public static function allowed(): bool { return current_user_can('manage_options'); }
    private static function index(): array|\WP_Error {
        $path = F3_MCP_GOOGLE_DIR . 'includes/Data/DocumentIndex.php';
        $index = is_file($path) ? require $path : null;
        $public = Admin::documents();
        if (!is_array($index) || array_diff_key($public, $index) || array_diff_key($index, $public)) {
            return self::integrity_error();
        }
        foreach ($index as $entry) {
            if (!is_array($entry) || !is_int($entry['bytes'] ?? null) || $entry['bytes'] < 0
                || !is_string($entry['revision'] ?? null) || !preg_match('/^[0-9a-f]{64}$/D', $entry['revision'])
                || !is_string($entry['file'] ?? null) || !preg_match('~^Manuals/[a-z0-9-]+\.php$~D', $entry['file'])) {
                return self::integrity_error();
            }
        }
        return $index;
    }
    private static function integrity_error(): \WP_Error {
        return new \WP_Error('f3_google_document_integrity', 'O documento ou o índice instalado diverge desta versão.');
    }
    private static function verified_content(array $entry): string|\WP_Error {
        $path = F3_MCP_GOOGLE_DIR . 'includes/Data/' . $entry['file'];
        $content = is_file($path) ? require $path : null;
        if (!is_string($content) || strlen($content) !== $entry['bytes'] || !hash_equals($entry['revision'], hash('sha256', $content))) {
            return self::integrity_error();
        }
        return $content;
    }
    /** Download a whole installed manual through the same allowlist as the MCP route. */
    public static function content(string $id): string|\WP_Error {
        if (!self::allowed()) {
            return new \WP_Error('f3_google_forbidden', 'A documentação exige administração do site.');
        }
        $index = self::index();
        if (is_wp_error($index)) {
            return $index;
        }
        if (!isset(Admin::documents()[$id], $index[$id])) {
            return new \WP_Error('f3_google_document_missing', 'Documento fora do índice local.');
        }
        return self::verified_content($index[$id]);
    }
    public static function read( array $input ): array {
        if (!self::allowed()) {
            return Response::fail(new \WP_Error('f3_google_forbidden', 'A documentação exige administração do site.'));
        }
        $index = self::index();
        if (is_wp_error($index)) {
            return Response::fail($index);
        }
        $identity = array('slug'=>'wp-mcp-google-fator3', 'plugin_version'=>F3_MCP_GOOGLE_VERSION, 'origin'=>'local', 'encoding'=>'UTF-8');
        $id = $input['document'] ?? '';
        if ('' === $id) {
            $documents = array();
            foreach (Admin::documents() as $name => $label) {
                $documents[] = array('document'=>$name, 'description'=>$label, 'bytes'=>$index[$name]['bytes'], 'revision'=>$index[$name]['revision']);
            }
            return Response::ok($identity + array('documents'=>$documents, 'max_limit_bytes'=>self::MAX_BYTES, 'read'=>array('ability'=>'google/documentation','parameters'=>array('document'=>'README.md','offset'=>0,'limit_bytes'=>16384)), 'pagination'=>'offset é byte UTF-8. Use next_offset e expected_revision em cada continuação. revision é SHA-256 do documento inteiro.'));
        }
        if (!is_string($id) || !isset(Admin::documents()[$id], $index[$id])) {
            return Response::fail(new \WP_Error('f3_google_document_missing', 'Documento fora do índice local.'));
        }
        $entry = $index[$id];
        $offset = $input['offset'] ?? 0;
        $limit = $input['limit_bytes'] ?? 16384;
        $size = $entry['bytes'];
        if (!is_int($offset) || $offset < 0 || $offset > $size || !is_int($limit) || $limit < 256 || $limit > self::MAX_BYTES) {
            return Response::fail(new \WP_Error('f3_google_document_range', 'offset ou limit_bytes inválido.'));
        }
        if (($offset > 0 && !isset($input['expected_revision'])) || (isset($input['expected_revision']) && (!is_string($input['expected_revision']) || !hash_equals($entry['revision'], $input['expected_revision'])))) {
            return Response::fail(new \WP_Error('f3_google_document_revision', 'Revisão ausente ou alterada. Reinicie a leitura pelo índice.'));
        }
        $content = self::verified_content($entry);
        if (is_wp_error($content)) {
            return Response::fail($content);
        }
        if ($offset < $size && (ord($content[$offset]) & 0xc0) === 0x80) {
            return Response::fail(new \WP_Error('f3_google_document_range', 'offset deve iniciar um caractere UTF-8.'));
        }
        $end = min($size, $offset + $limit);
        while ($end < $size && (ord($content[$end]) & 0xc0) === 0x80) {
            --$end;
        }
        $page = substr($content, $offset, $end - $offset);
        return Response::ok($identity + array('document'=>$id, 'revision'=>$entry['revision'], 'sha256'=>$entry['revision'], 'total_bytes'=>$size, 'offset'=>$offset, 'returned_bytes'=>strlen($page), 'content'=>$page, 'has_more'=>$end < $size, 'next_offset'=>$end < $size ? $end : null));
    }
    public static function register(): void {
        Ability::register('google/documentation','any',array('label'=>'Google: documentação instalada','description'=>'Índice e leitura integral paginada dos manuais e schemas desta versão. Local, estática, sem credenciais nem chamadas Google. Exige manage_options.',
            'output_schema'=>array('type'=>'object','properties'=>array(
                'success'=>array('type'=>'boolean'),'message'=>array('type'=>'string'),'error_code'=>array('type'=>'string'),
                'slug'=>array('type'=>'string'),'plugin_version'=>array('type'=>'string'),'origin'=>array('type'=>'string','enum'=>array('local')),
                'encoding'=>array('type'=>'string','enum'=>array('UTF-8')),'document'=>array('type'=>'string'),'revision'=>array('type'=>'string'),'sha256'=>array('type'=>'string'),
                'documents'=>array('type'=>'array','items'=>array('type'=>'object')),'content'=>array('type'=>'string'),
                'offset'=>array('type'=>'integer'),'returned_bytes'=>array('type'=>'integer'),'total_bytes'=>array('type'=>'integer'),
                'has_more'=>array('type'=>'boolean'),'next_offset'=>array('type'=>array('integer','null')),
            )),
            'input_schema'=>array('properties'=>array(
                'document'=>array('type'=>'string','description'=>'ID exato do índice; omitir para obter o índice.'),
                'offset'=>array('type'=>'integer','minimum'=>0,'default'=>0),
                'limit_bytes'=>array('type'=>'integer','minimum'=>256,'maximum'=>self::MAX_BYTES,'default'=>16384),
                'expected_revision'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$','description'=>'SHA-256 obrigatório ao continuar offset maior que zero.'),
            )), 'callback'=>array(self::class,'read')));
    }
}
