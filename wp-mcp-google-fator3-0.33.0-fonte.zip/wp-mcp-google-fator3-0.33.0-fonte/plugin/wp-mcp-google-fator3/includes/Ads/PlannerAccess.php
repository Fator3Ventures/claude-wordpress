<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\{Connections,Lock,Options,Policy,Recovery,Settings,Storage\Repository};

if (!defined('ABSPATH')) { exit; }

/** The Cloud project owns the level. Only an administrator declares it from the console. */
final class PlannerAccess {
    public const OPTION = 'f3_mcp_google_ads_planning_access';
    public const LEVELS = ['unknown','test','explorer','basic','standard'];
    public const EXPLORER_BLOCKS = [
        'CustomerService.CreateCustomerClient','CustomerUserAccessInvitationService','CustomerUserAccessService',
        'KeywordPlanService','KeywordPlanIdeaService','KeywordPlanCampaignService','KeywordPlanCampaignKeywordService',
        'KeywordPlanAdGroupService','KeywordPlanAdGroupKeywordService','AudienceInsightsService','ReachPlanService',
        'PaymentsAccountService','BillingSetupService','AccountBudgetProposalService','InvoiceService',
    ];
    public const ACTION = 'Confira o nível no Google Cloud Console → Google Ads API. Para Explorer, conclua a verificação da marca, solicite Basic e atualize o nível na conexão depois da aprovação.';

    public static function scope(): string {
        $project = '';
        if (Options::auth_mode() === 'service_account') {
            $json = json_decode(Options::get_secret(Options::SA_JSON), true);
            $project = (string) ($json['project_id'] ?? '');
        } else {
            $client = (string) Options::get(Options::OAUTH_CLIENT_ID,'');
            $project = explode('-', $client, 2)[0];
        }
        // No cross-connection aggregation without a common project identifier.
        return hash('sha256', $project === '' ? 'connection:'.Connections::id() : 'project:'.$project);
    }

    /** Fresh SQL values detect edits committed by other requests while WordPress caches options. */
    public static function read_revision(): string|\WP_Error {
        $names = [Options::ENABLED, Options::ADS_ENABLED, Connections::SERVICES, Policy::OPTION, self::OPTION,
            Settings::AUTH_READY, Options::AUTH_MODE, Options::SA_JSON, Options::SA_SUBJECT, Options::OAUTH_CLIENT_ID,
            Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES,
            Options::ADS_API_VERSION, Options::ADS_LOGIN_CUSTOMER_ID, Options::ADS_DEVELOPER_TOKEN];
        $states = Options::snapshot(array_map([Options::class, 'storage_name'], $names));
        foreach ($states as $state) {
            if (!$state['success']) { return new \WP_Error('f3_google_option_read','Falha ao ler a autorização do planejador.'); }
        }
        // This digest is local to the running call. Older receipts keep their original wire format.
        return hash('sha256', wp_json_encode([Connections::id(), Recovery::generation(), $states]));
    }

    public static function level(): string {
        $declaration = Options::get(self::OPTION, []);
        return is_array($declaration) && ($declaration['scope'] ?? '') === self::scope()
            && in_array($declaration['level'] ?? '', self::LEVELS, true) ? $declaration['level'] : 'unknown';
    }

    /** Public status returned by the status and readiness abilities. */
    public static function status_schema(): array {
        $count = ['type' => ['integer', 'null'], 'minimum' => 0];
        $fields = [
            'level'                       => ['type' => 'string', 'enum' => self::LEVELS],
            'source'                      => ['type' => 'string', 'enum' => ['unknown', 'admin_cloud_console']],
            'provider_verified'           => ['type' => 'boolean', 'enum' => [false]],
            'scope'                       => ['type' => 'string', 'enum' => ['cloud_project']],
            'planning'                    => ['type' => 'string', 'enum' => ['blocked', 'not_configured', 'test_accounts_only', 'subject_to_provider_permission']],
            'blocked_services'            => ['type' => 'array', 'items' => ['type' => 'string']],
            'production_accounts_blocked' => ['type' => 'boolean'],
            'action'                      => ['type' => 'string'],
            'operations_last_24h'         => $count,
            'production_daily_limit'      => $count,
            'test_daily_limit'            => $count,
            'daily_limit_unlimited'       => ['type' => 'boolean'],
            'usage_scope'                 => ['type' => 'string', 'enum' => ['estimate_this_installation_project']],
            'global_usage_known'          => ['type' => 'boolean', 'enum' => [false]],
        ];
        return ['type' => 'object', 'properties' => $fields, 'required' => array_keys($fields)];
    }

    public static function status(): array {
        $level = self::level();
        $quota = self::usage();
        return [
            'level'=>$level, 'source'=>$level === 'unknown' ? 'unknown' : 'admin_cloud_console',
            'provider_verified'=>false, 'scope'=>'cloud_project', 'planning'=>match ($level) {
                'explorer'=>'blocked', 'unknown'=>'not_configured','test'=>'test_accounts_only', default=>'subject_to_provider_permission',
            },
            'blocked_services'=>$level === 'explorer' ? self::EXPLORER_BLOCKS : [],
            'production_accounts_blocked'=>$level === 'test', 'action'=>self::ACTION,
            'operations_last_24h'=>$quota, 'production_daily_limit'=>match ($level) {
                'test'=>0,'explorer'=>2880,'basic'=>15000,default=>null,
            }, 'test_daily_limit'=>in_array($level,['explorer','test','basic'],true) ? 15000 : null,
            'daily_limit_unlimited'=>$level === 'standard', 'usage_scope'=>'estimate_this_installation_project', 'global_usage_known'=>false,
        ];
    }

    /** Limit dispatch starts locally per customer, including retries of read-only planning RPCs. */
    public static function pace(string $url): ?\WP_Error {
        if (!preg_match('~^https://googleads\.googleapis\.com/v[0-9]+/customers/([0-9]{10}):(generateKeywordIdeas|generateKeywordHistoricalMetrics|generateKeywordForecastMetrics|generateAdGroupThemes)$~D',$url,$match)) { return null; }
        $key='f3_mcp_google_planner_pace_'.hash('sha256',$match[1]);
        $lock=Lock::acquire($key,5);
        if (!$lock) { return new \WP_Error('f3_google_keyword_rate','Outra leitura está reservando a cota. Repita em um segundo.',['retryable'=>true,'retry_after'=>1]); }
        try {
            $last=Options::stored($key);
            if (!$last['success']) { return new \WP_Error('f3_google_keyword_rate','Falha ao ler o intervalo entre chamadas.'); }
            $wait=max(0,min(1,(float)($last['value']??0)+1-microtime(true)));
            if ($wait>0) { usleep((int)ceil($wait*1e6)); }
            $saved=Options::set($key,(string)microtime(true));
            return $saved['success'] ? null : new \WP_Error('f3_google_keyword_rate','Falha ao reservar o intervalo entre chamadas.');
        } finally { Lock::release($lock); }
    }
    /** Minute buckets are shared by project and reused after the 24h window. */
    private static function usage(): ?int {
        global $wpdb;
        $table=Repository::table();
        $slug=substr(self::scope(),0,40);
        $cutoff=intdiv(time()-86400,60)*60;
        $total=$wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(CAST(JSON_UNQUOTE(JSON_EXTRACT(payload,'$.count')) AS UNSIGNED)),0) FROM $table WHERE kind='adsusage' AND connection_id=%s AND due_at>%d",
            $slug,$cutoff
        ));
        return $total===null || $wpdb->last_error!=='' ? null : (int)$total;
    }

    public static function count_request(string $url, ?array $body, $response): void {
        if (wp_parse_url($url, PHP_URL_HOST) !== 'googleads.googleapis.com' || str_contains($url,'/discovery/')) { return; }
        $http = is_wp_error($response) ? 0 : (int) wp_remote_retrieve_response_code($response);
        if ($http === 0 || ($http < 400 && !empty($body['pageToken']))) { return; }
        $weight = max(1, count($body['mutateOperations'] ?? $body['operations'] ?? []));
        $minute=intdiv(time(),60);
        $project=substr(self::scope(),0,40);
        $slot=$project.'-'.($minute % 1441);
        // Compare-and-swap retries preserve parallel increments without serializing HTTP.
        for ($try=0;$try<8;++$try) {
            $row=Repository::row('adsusage',$slot);
            if (is_wp_error($row)) { return; }
            $prior=$row ? json_decode($row['payload'],true) : [];
            $count=(($prior['minute']??null)===$minute ? $prior['count'] : 0)+$weight;
            $record=['connection_id'=>$project,'minute'=>$minute,'count'=>$count,'run_after'=>$minute*60];
            if ($row===null) {
                if (Repository::insert('adsusage',$slot,$record)) { return; }
            } else {
                $result=Repository::put('adsusage',$slot,$record,(int)$row['generation']);
                if ($result['success']) { return; }
            }
        }
    }
}
