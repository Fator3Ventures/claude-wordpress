<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;
if (!defined('ABSPATH')) { exit; }

final class PlannerRequest {
    public const METHODS = [
        'ideas'=>'generateKeywordIdeas','metrics'=>'generateKeywordHistoricalMetrics',
        'forecast'=>'generateKeywordForecastMetrics','themes'=>'generateAdGroupThemes',
    ];
    private static function period_schema(): array {
        $month=['type'=>'object','required'=>['year','month'],'properties'=>[
            'year'=>['type'=>'integer','minimum'=>2000,'maximum'=>2100],
            'month'=>['type'=>'string','enum'=>['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']]
        ],'additionalProperties'=>false];
        return ['type'=>'object','description'=>'Intervalo inclusivo. Ausência usa os últimos 12 meses disponíveis.','required'=>['start','end'],
            'properties'=>['start'=>$month,'end'=>$month],'additionalProperties'=>false];
    }
    public static function schema(string $kind): array {
        $words = ['type'=>'array','minItems'=>1,'maxItems'=>$kind==='ideas'?20:10000,
            'items'=>['type'=>'string','minLength'=>1,'maxLength'=>80]];
        $props = ['customer_id'=>['type'=>'string','description'=>'Conta alvo. Padrão: ads_customer_id da conexão.']];
        if ($kind === 'ideas' || $kind === 'metrics') {
            $props += ['keywords'=>$words,'geo'=>['type'=>'array','minItems'=>1,'maxItems'=>10,'items'=>['type'=>'string','pattern'=>'^geoTargetConstants/[0-9]+$']],
                'language'=>['type'=>'string','pattern'=>'^languageConstants/[0-9]+$'],
                'network'=>['type'=>'string','enum'=>['GOOGLE_SEARCH','GOOGLE_SEARCH_AND_PARTNERS']],
                'year_month_range'=>self::period_schema()];
        }
        if ($kind==='ideas') {
            $props += ['url'=>['type'=>'string'],'site'=>['type'=>'string'],'page_size'=>['type'=>'integer','minimum'=>1,'maximum'=>10000],
                'resume_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$','description'=>'Continua a mesma leitura até concluir.']];
        }
        if ($kind==='forecast') {
            $props += ['campaign'=>['type'=>'object','description'=>'CampaignToForecast REST da versão configurada.'],
                'forecast_period'=>['type'=>'object','properties'=>['startDate'=>['type'=>'string','format'=>'date'],'endDate'=>['type'=>'string','format'=>'date']],'required'=>['startDate','endDate'],'additionalProperties'=>false]];
        }
        if ($kind==='themes') {
            $props += ['keywords'=>$words,'ad_groups'=>['type'=>'array','minItems'=>1,'maxItems'=>10000,'items'=>['type'=>'string']]];
        }
        $required = match($kind) {'metrics'=>['keywords'],'forecast'=>['campaign'],'themes'=>['keywords','ad_groups'],default=>[]};
        return ['properties'=>$props,'required'=>$required];
    }
    private static function invalid(string $message): \WP_Error { return new \WP_Error('f3_google_keyword_input',$message); }

    public static function body(string $kind,array $i,string $account): array|\WP_Error {
        if ($kind==='forecast') {
            $campaign=$i['campaign']??[];
            if (empty($campaign['adGroups']) || empty($campaign['biddingStrategy'])) {
                return self::invalid('A previsão exige campaign.adGroups e campaign.biddingStrategy.');
            }
            $campaign += ['geoTargetConstants'=>['geoTargetConstants/2076'],'languageConstants'=>['languageConstants/1014']];
            $body=['campaign'=>$campaign];
            if (isset($i['forecast_period'])) { $body['forecastPeriod']=$i['forecast_period']; }
            return $body;
        }
        $keywords=array_values($i['keywords']??[]);
        foreach ($keywords as $word) {
            if (!is_string($word) || trim($word)==='' || mb_strlen($word)>80) { return self::invalid('Palavra vazia ou maior que 80 caracteres.'); }
        }
        if ($kind==='themes') {
            foreach ($i['ad_groups'] as $group) {
                if (!preg_match('~^customers/'.$account.'/adGroups/[0-9]+$~D',$group)) { return self::invalid('Use recursos de grupos de anúncio existentes da conta alvo.'); }
            }
            return ['keywords'=>$keywords,'adGroups'=>$i['ad_groups']];
        }
        $options=['includeAverageCpc'=>true];
        if (isset($i['year_month_range'])) { $options['yearMonthRange']=$i['year_month_range']; }
        $body=['geoTargetConstants'=>$i['geo']??['geoTargetConstants/2076'],'language'=>$i['language']??'languageConstants/1014',
            'keywordPlanNetwork'=>$i['network']??'GOOGLE_SEARCH','historicalMetricsOptions'=>$options];
        if ($kind==='metrics') { return $body+['keywords'=>$keywords]; }
        $site=$i['site']??''; $url=$i['url']??'';
        if (($site!=='' && ($keywords || $url!=='')) || ($site==='' && $url==='' && !$keywords)) {
            return self::invalid('Informe palavras, URL, palavras mais URL, ou site sozinho.');
        }
        foreach ([$site,$url] as $value) {
            if ($value!=='' && (!filter_var($value,FILTER_VALIDATE_URL) || !in_array(wp_parse_url($value,PHP_URL_SCHEME),['https','http'],true)
                || wp_parse_url($value,PHP_URL_USER)!==null || wp_parse_url($value,PHP_URL_PASS)!==null)) { return self::invalid('Use URL HTTP(S) absoluta sem credenciais.'); }
        }
        $seed = $site!=='' ? ['siteSeed'=>['site'=>$site]] : ($url==='' ? ['keywordSeed'=>['keywords'=>$keywords]]
            : ($keywords ? ['keywordAndUrlSeed'=>['url'=>$url,'keywords'=>$keywords]] : ['urlSeed'=>['url'=>$url]]));
        return $body+$seed+['keywordAnnotation'=>['KEYWORD_CONCEPT'],'pageSize'=>$i['page_size']??1000];
    }

    private static function money(array $record,string $field): ?float {
        return isset($record[$field]) ? (int)$record[$field]/1000000 : null;
    }
    /** An omitted repeated field is a valid empty protobuf response. A malformed row is not. */
    public static function validate_response(string $kind,array $response): ?\WP_Error {
        $error = static fn()=>new \WP_Error('f3_google_keyword_response','O Google devolveu uma página em formato inesperado. A última página válida continua arquivada.');
        if (array_key_exists('nextPageToken',$response) && (!is_string($response['nextPageToken'])
            || ($kind!=='ideas' && $response['nextPageToken']!==''))) { return $error(); }
        if ($kind==='forecast') {
            $forecast=$response['campaignForecastMetrics']??[];
            if (!is_array($forecast)) { return $error(); }
            foreach (['impressions','clicks','costMicros','averageCpcMicros'] as $field) {
                if (isset($forecast[$field]) && !is_numeric($forecast[$field])) { return $error(); }
            }
            return null;
        }
        if ($kind==='themes') {
            foreach (['adGroupKeywordSuggestions','unusableAdGroups'] as $field) {
                $items=$response[$field]??[];
                if (!is_array($items) || !array_is_list($items)) { return $error(); }
                foreach ($items as $item) { if (!is_array($item)) { return $error(); } }
            }
            return null;
        }
        $rows=$response['results']??[];
        if (!is_array($rows) || !array_is_list($rows)) { return $error(); }
        foreach ($rows as $row) {
            if (!is_array($row) || !is_string($row['text']??null) || trim($row['text'])==='') { return $error(); }
            $metrics=$row['keywordIdeaMetrics']??$row['keywordMetrics']??[];
            if (!is_array($metrics)) { return $error(); }
            foreach (['avgMonthlySearches','competitionIndex','lowTopOfPageBidMicros','highTopOfPageBidMicros','averageCpcMicros'] as $field) {
                if (isset($metrics[$field]) && !is_numeric($metrics[$field])) { return $error(); }
            }
            foreach ([$metrics['monthlySearchVolumes']??[], $row['closeVariants']??[], $row['keywordAnnotations']['concepts']??[]] as $items) {
                if (!is_array($items) || !array_is_list($items)) { return $error(); }
            }
            foreach ($metrics['monthlySearchVolumes']??[] as $month) {
                if (!is_array($month) || (isset($month['monthlySearches']) && !is_numeric($month['monthlySearches']))) { return $error(); }
            }
            foreach ($row['closeVariants']??[] as $variant) { if (!is_string($variant)) { return $error(); } }
            foreach ($row['keywordAnnotations']['concepts']??[] as $concept) { if (!is_array($concept)) { return $error(); } }
        }
        return null;
    }

    public static function chunks(string $kind,array $response,string $currency): \Generator {
        if ($kind==='themes') {
            foreach (array_chunk($response['adGroupKeywordSuggestions']??[],100) as $batch) { yield $batch; }
            return;
        }
        if ($kind==='forecast') {
            $metrics=$response['campaignForecastMetrics']??[];
            yield [['impressions'=>$metrics['impressions']??null,'clicks'=>$metrics['clicks']??null,
                'cost'=>self::money($metrics,'costMicros'),'currency'=>$currency,'provider_metrics'=>$metrics]];
            return;
        }
        $batch=[];
        foreach ($response['results']??[] as $row) {
            $metrics=$row['keywordIdeaMetrics']??$row['keywordMetrics']??[];
            $batch[]=['keyword'=>$row['text'],'avg_monthly_searches'=>isset($metrics['avgMonthlySearches'])?(int)$metrics['avgMonthlySearches']:null,
                'monthly_search_volumes'=>$metrics['monthlySearchVolumes']??[],'competition'=>$metrics['competition']??null,
                'competition_index'=>isset($metrics['competitionIndex'])?(int)$metrics['competitionIndex']:null,
                'low_top_of_page_bid'=>self::money($metrics,'lowTopOfPageBidMicros'),'high_top_of_page_bid'=>self::money($metrics,'highTopOfPageBidMicros'),
                'average_cpc'=>self::money($metrics,'averageCpcMicros'),'currency'=>$currency,
                'concepts'=>$row['keywordAnnotations']['concepts']??null,'close_variants'=>$row['closeVariants']??[]];
            if (count($batch)===100) { yield $batch; $batch=[]; }
        }
        if ($batch) { yield $batch; }
    }
}
