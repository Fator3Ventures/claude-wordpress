<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\{Ability,Connections,Gate,Lock,Options,Policy,Response,Recovery,Storage\Repository,Storage\State,Http\GoogleClient,Auth\Credentials};

if (!defined('ABSPATH')) { exit; }

final class KeywordPlanner {
    private const KIND = 'keywordread';
    private const PREVIEW = 25;

    public static function register(): void {
        $labels=['ideas'=>'Gerar ideias de palavras-chave','metrics'=>'Consultar métricas históricas de palavras-chave',
            'forecast'=>'Prever desempenho de campanha hipotética','themes'=>'Agrupar palavras em grupos de anúncios existentes'];
        foreach ($labels as $kind=>$label) {
            Ability::register('ads/keyword-'.$kind,'ads',[
                'label'=>$label,'description'=>$label.'. Consulta Google Ads sem alterar a conta. Arquiva a leitura na conexão. Use ads/keyword-archive para ler as demais linhas.',
                'mode'=>'read','input_schema'=>PlannerRequest::schema($kind),'output_schema'=>self::output(),
                'diagnostic_permission'=>true,
                'callback'=>static fn(array $i)=>self::run($kind,$i),
            ]);
        }
        Ability::register('ads/keyword-archive','any',[
            'label'=>'Consultar histórico do planejador','description'=>'Lista leituras da conta por data ou lê as linhas de uma leitura arquivada. Paginação exclusivamente local.',
            'mode'=>'read','input_schema'=>['properties'=>[
                'customer_id'=>['type'=>'string'],'archive_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$'],
                'from'=>['type'=>'string','format'=>'date'],'to'=>['type'=>'string','format'=>'date'],
                'before_sequence'=>['type'=>'integer','minimum'=>1],'offset'=>['type'=>'integer','minimum'=>0],
                'limit'=>['type'=>'integer','minimum'=>1,'maximum'=>200],
                'request_offset'=>['type'=>'integer','minimum'=>0,'description'=>'Offset em bytes para ler a requisição arquivada em blocos UTF-8.'],
            ]], 'output_schema'=>self::output(),'callback'=>[self::class,'archive'],
        ]);
    }
    private static function output(): array {
        return ['type'=>'object','properties'=>[
            'success'=>['type'=>'boolean'],'message'=>['type'=>'string'],'error_code'=>['type'=>'string'],
            'archive_id'=>['type'=>'string'],'resume_id'=>['type'=>['string','null']],'complete'=>['type'=>'boolean'],
            'customer_id'=>['type'=>'string'],'connection_id'=>['type'=>'string'],'rows'=>['type'=>'array','items'=>['type'=>'object','properties'=>[
                'keyword'=>['type'=>['string','null']],'avg_monthly_searches'=>['type'=>['integer','null']],
                'monthly_search_volumes'=>['type'=>'array','items'=>['type'=>'object']],'competition'=>['type'=>['string','null']],
                'competition_index'=>['type'=>['integer','null']],'average_cpc'=>['type'=>['number','null']],
                'low_top_of_page_bid'=>['type'=>['number','null']],'high_top_of_page_bid'=>['type'=>['number','null']],
                'currency'=>['type'=>'string'],'concepts'=>['type'=>['array','null'],'items'=>['type'=>'object']],
                'close_variants'=>['type'=>'array','items'=>['type'=>'string']],
                'cost'=>['type'=>['number','null']],'impressions'=>['type'=>['string','number','null']],'clicks'=>['type'=>['string','number','null']],
            ]]],
            'row_count'=>['type'=>'integer'],'next_offset'=>['type'=>['integer','null']],'meta'=>['type'=>'object'],
            'reads'=>['type'=>'array','items'=>['type'=>'object']],'next_before_sequence'=>['type'=>['integer','null']],
            'access'=>['type'=>'object'],'action'=>['type'=>'string'],
        ]];
    }
    private static function account(array $i): string|\WP_Error {
        $account=CustomerId::normalize($i['customer_id']??(Options::get(Connections::BINDINGS,[])['ads_customer_id']??''));
        if (is_wp_error($account)) { return $account; }
        if (!Gate::permission('ads') || !Policy::permitted('ads',$account)) {
            return new \WP_Error('f3_google_keyword_forbidden','A conexão ou a política não autoriza a leitura desta conta.');
        }
        return $account;
    }
    private static function load(string $account,string $id): array|\WP_Error {
        $read=ArchiveStore::get(self::KIND,$account.'-'.$id);
        return $read ?? new \WP_Error('f3_google_keyword_archive_missing','Leitura inexistente nesta conta e conexão.');
    }
    private static function meta(array $read,?int $offset): array {
        $meta=array_intersect_key($read,array_flip(['kind','observed_at','currency','api_version','unusable_ad_groups']));
        $json=wp_json_encode($read['request'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $bytes=strlen($json);
        if ($bytes<=8192 && $offset===null) { return $meta+['request'=>$read['request']]; }
        $offset ??= 0;
        if ($offset>$bytes || ($offset<$bytes && (ord($json[$offset]) & 0xc0)===0x80)) {
            throw new \InvalidArgumentException('request_offset fora do intervalo UTF-8.');
        }
        $end=min($bytes,$offset+8192);
        while ($end<$bytes && (ord($json[$end]) & 0xc0)===0x80) { --$end; }
        return $meta+['request_bytes'=>$bytes,'request_sha256'=>hash('sha256',$json),'request_part'=>substr($json,$offset,$end-$offset),
            'request_offset'=>$offset,'next_request_offset'=>$end<$bytes?$end:null];
    }
    private static function view(array $read,int $offset,int $limit,?int $request_offset=null): array {
        $rows=ArchiveStore::page($read,$offset,$limit);
        if (is_wp_error($rows)) { return Response::fail($rows); }
        $next=$offset+count($rows);
        try { $meta=self::meta($read,$request_offset); } catch (\InvalidArgumentException $e) { return self::fail('offset',$e->getMessage()); }
        return Response::ok(['archive_id'=>$read['id'],'connection_id'=>Connections::id(),'customer_id'=>$read['account'],
            'complete'=>$read['complete'],'resume_id'=>$read['complete'] || $read['kind']!=='ideas' ? null : $read['id'],
            'row_count'=>$read['count'],'rows'=>$rows,'next_offset'=>$next<$read['count']?$next:null,'meta'=>$meta]);
    }
    public static function archive(array $i): array {
        $account=self::account($i);
        if (is_wp_error($account)) { return Response::fail($account); }
        $limit=$i['limit']??self::PREVIEW;
        if (isset($i['archive_id'])) {
            $read=self::load($account,$i['archive_id']);
            return is_wp_error($read)?Response::fail($read):self::view($read,$i['offset']??0,$limit,$i['request_offset']??null);
        }
        $from=$i['from']??''; $to=$i['to']??'';
        foreach ([$from,$to] as $date) {
            if ($date!=='' && gmdate('Y-m-d',(int)strtotime($date.' 00:00:00 UTC'))!==$date) { return self::fail('date','Data UTC inválida.'); }
        }
        if ($from!=='' && $to!=='' && $from>$to) { return self::fail('date','A data inicial deve ser anterior ou igual à final.'); }
        $filters=['id_prefix'=>$account.'-','connection_id'=>Connections::id()];
        if (isset($i['before_sequence'])) { $filters['sequence_before']=$i['before_sequence']-1; }
        $items=[]; $scanned=0; $last=null;
        // Old receipts could record a later checkpoint in the SQL created_at column.
        // Use the immutable observation inside the encrypted receipt for both versions.
        while ($scanned<200 && count($items)<$limit) {
            $batch=min(12,200-$scanned,$limit-count($items));
            $rows=Repository::select(self::KIND,$filters,$batch+1,0,true,true);
            if (is_wp_error($rows)) { return Response::fail($rows); }
            foreach (array_slice($rows,0,$batch) as $row) {
                ++$scanned;
                $last=(int)$row['sequence'];
                if (!hash_equals($row['digest'],hash('sha256',$row['payload']))) { return self::fail('archive_corrupt','Registro do histórico ilegível.'); }
                $record=json_decode($row['payload'],true);
                if (!is_array($record)) { return self::fail('archive_corrupt','Registro do histórico inválido.'); }
                $read=ArchiveStore::decrypt(self::KIND,$row['record_id'],$record);
                if (is_wp_error($read)) { return Response::fail($read); }
                $day=substr($read['observed_at'],0,10);
                if (($from!=='' && $day<$from) || ($to!=='' && $day>$to)) { continue; }
                $items[]=['archive_id'=>$read['id'],'observed_at'=>$read['observed_at'],'kind'=>$read['kind'],'complete'=>$read['complete'],'row_count'=>$read['count']];
            }
            if (count($rows)<=$batch) { return Response::ok(['reads'=>$items,'next_before_sequence'=>null]); }
            $filters['sequence_before']=$last-1;
        }
        return Response::ok(['reads'=>$items,'next_before_sequence'=>$last]);
    }
    private static function fail(string $code,string $message,array $more=[]): array {
        return Response::fail(new \WP_Error('f3_google_keyword_'.$code,$message),$more);
    }
    public static function run(string $kind,array $i): array {
        $account=self::account($i);
        if (is_wp_error($account)) { return Response::fail($account); }
        $level=PlannerAccess::level();
        if (in_array($level,['unknown','explorer'],true)) {
            return self::fail('access_level', $level==='explorer'?'Explorer bloqueia KeywordPlanIdeaService.':'Informe o nível confirmado no Google Cloud Console.',
                ['access'=>PlannerAccess::status(),'action'=>PlannerAccess::ACTION]);
        }
        if ($error=Recovery::guard()??State::guard()) { return Response::fail($error); }
        $id=$i['resume_id']??bin2hex(random_bytes(16));
        $lock=Lock::acquire('planner:'.Connections::id().':'.$account.':'.$id,600);
        if (!$lock) { return self::fail('busy','A leitura está em andamento. Repita com o mesmo resume_id.',['resume_id'=>$id]); }
        try {
            $revision=PlannerAccess::read_revision();
            if (is_wp_error($revision)) { return Response::fail($revision); }
            $identity=Credentials::execution_identity();
            $version=Options::ads_api_version();
            if (isset($i['resume_id'])) {
                if (array_diff(array_keys($i),['resume_id','connection_id','customer_id'])) { return self::fail('resume','Retome somente com resume_id e a mesma conta/conexão.'); }
                // Capture the generation before loading the receipt so a concurrent checkpoint cannot be overwritten.
                $row=Repository::row(self::KIND,$account.'-'.$id,false);
                if (is_wp_error($row)) { return Response::fail($row); }
                $generation=(int)($row['generation']??0);
                $read=self::load($account,$id);
                if (is_wp_error($read)) { return Response::fail($read); }
                if ($read['kind']!==$kind || $read['identity']!==$identity || $read['api_version']!==$version) {
                    return self::fail('context','O contexto do planejamento mudou. Inicie uma nova leitura.');
                }
            } else {
                $body=PlannerRequest::body($kind,$i,$account);
                if (is_wp_error($body)) { return Response::fail($body); }
                $details=AdsApi::search($account,'SELECT customer.currency_code, customer.test_account FROM customer LIMIT 1',['max_rows'=>1]);
                if (is_wp_error($details)) { return self::provider_error($details); }
                if (!Lock::owned($lock) || !self::context_matches($account,$identity,$version,$revision)) {
                    return self::fail('context','A autorização mudou enquanto o Google confirmava a conta. Inicie uma nova leitura.');
                }
                $row=$details['rows'][0]??[];
                $currency=$row['customer.currency_code']??$row['customer.currencyCode']??'';
                if (!is_string($currency) || !preg_match('/^[A-Z]{3}$/D',$currency)) { return self::fail('currency','Moeda da conta não confirmada.'); }
                $read=['id'=>$id,'account'=>$account,'identity'=>$identity,'api_version'=>$version,
                    'currency'=>$currency,'test_account'=>($row['customer.test_account']??$row['customer.testAccount']??false)===true,
                    'kind'=>$kind,'request'=>$body,'observed_at'=>gmdate('c'),'count'=>0,'chunks'=>[],'tokens'=>[],
                    'next'=>'','complete'=>false];
            }
            if ($level==='test' && !$read['test_account']) {
                return self::fail('access_level','Test permite apenas contas de teste.',['access'=>PlannerAccess::status(),'action'=>PlannerAccess::ACTION]);
            }
            if (!$read['complete']) {
                // Persist the initial cursor before dispatch so a later failure is resumable.
                if (!isset($i['resume_id'])) {
                    $save=ArchiveStore::put(self::KIND,$account.'-'.$id,$read);
                    if (!$save['success']) { return $save; }
                    $generation=1;
                }
                $result=self::advance($read,$lock,$revision,$generation);
                if (!$result['success']) { return $result+['archive_id'=>$id,'resume_id'=>$kind==='ideas'?$id:null]; }
            }
            return self::view($read,0,self::PREVIEW);
        } finally { Lock::release($lock); }
    }
    /** A complete archived metrics snapshot is the Ads side of a keyword blend. */
    public static function blend_table(array $query): array {
        $account=self::account($query);
        if (is_wp_error($account)) { return Response::fail($account); }
        $read=self::load($account,$query['archive_id']);
        if (is_wp_error($read)) { return Response::fail($read); }
        if (!$read['complete'] || !in_array($read['kind'],['metrics','ideas'],true)) {
            return self::fail('blend_snapshot','Use uma leitura completa de ideias ou de métricas.');
        }
        $fields=['keyword','avg_monthly_searches','average_cpc','currency'];
        $columns=[];
        foreach ($fields as $field) {
            $columns[]=['id'=>$field,'label'=>$field,'type'=>$field==='keyword'?'dimension':'metric','kind'=>in_array($field,['keyword','currency'],true)?'string':'number'];
        }
        $rows=[];
        foreach ($read['chunks'] as $chunk) {
            $data=ArchiveStore::get('adsrows',$chunk['id']);
            if (is_wp_error($data) || count($data['rows']??[])!==$chunk['count']) { return self::fail('archive_corrupt','Parte da leitura está indisponível.'); }
            foreach ($data['rows'] as $r) { $rows[]=array_map(static fn($field)=>$r[$field]??null,$fields); }
        }
        return Response::ok(['connector'=>'keyword-planner','accounts'=>[$account],'columns'=>$columns,'rows'=>$rows,
            'collection'=>['complete'=>true,'archive_id'=>$read['id'],'observed_at'=>$read['observed_at'],'historical_metrics_options'=>$read['request']['historicalMetricsOptions']],
            'warnings'=>['Volume e CPC pertencem ao período histórico do planejador. Variantes agrupadas contam uma vez, sob a palavra devolvida.']]);
    }
    private static function provider_error(\WP_Error $error): array {
        $reason=(string)($error->get_error_data()['reason']??'');
        if (str_contains($reason,'DEVELOPER_TOKEN_NOT_APPROVED') || str_contains($reason,'PROJECT_DISABLED')) {
            $status=PlannerAccess::status();
            if (stripos($error->get_error_message(),'explorer')!==false) { $status['provider_reported_level']='explorer'; }
            return Response::fail($error,['access'=>$status,'action'=>PlannerAccess::ACTION]);
        }
        return Response::fail($error);
    }
    private static function context_matches(string $account,string $identity,string $version,string $revision): bool {
        return PlannerAccess::read_revision()===$revision && Recovery::guard()===null
            && !is_wp_error(self::account(['customer_id'=>$account]))
            && Credentials::execution_identity()===$identity && Options::ads_api_version()===$version;
    }
    private static function still_allowed(array $read,string $revision): bool {
        return self::context_matches($read['account'],$read['identity'],$read['api_version'],$revision)
            && in_array(PlannerAccess::level(),$read['test_account']?['test','basic','standard']:['basic','standard'],true);
    }
    private static function advance(array &$read,array $lock,string $revision,int $generation): array {
        $method=PlannerRequest::METHODS[$read['kind']];
        $account=$read['account'];
        $start=microtime(true);
        for ($p=0;$p<5 && !$read['complete'];++$p) {
            if (!Lock::owned($lock) || !self::still_allowed($read,$revision)) {
                return self::fail('context','A autorização ou reserva mudou durante a leitura.');
            }
            $body=$read['request'];
            if ($read['next']!=='') { $body['pageToken']=$read['next']; }
            $result=GoogleClient::post(AdsApi::base().'/customers/'.$account.':'.$method,$body,AdsApi::request_opts('','googleads.customers.'.$method));
            if (is_wp_error($result)) { return self::provider_error($result); }
            if ($issue=PlannerRequest::validate_response($read['kind'],$result)) { return Response::fail($issue); }
            $next=$result['nextPageToken']??'';
            if ($next!=='' && isset($read['tokens'][hash('sha256',$next)])) { return self::fail('pagination','O Google repetiu o cursor. A coleta continua marcada incompleta.'); }
            if (!Lock::owned($lock) || !self::still_allowed($read,$revision)) {
                return self::fail('context','A conta ou a identidade mudou antes da gravação.');
            }
            if ($read['kind']==='themes') { $read['unusable_ad_groups']=$result['unusableAdGroups']??[]; }
            $read['next']=$next;
            $read['complete']=$next==='';
            if ($next!=='') { $read['tokens'][hash('sha256',$next)]=true; }
            $rows=PlannerRequest::chunks($read['kind'],$result,$read['currency']);
            $save=ArchiveStore::commit_keyword_page($read,$rows,$generation,
                static fn()=>Lock::owned($lock) && self::still_allowed($read,$revision));
            if (!$save['success']) { return $save; }
            $generation=$save['generation'];
            if (microtime(true)-$start >= 8 || $p===4) { break; }

        }
        return Response::ok();
    }
}
