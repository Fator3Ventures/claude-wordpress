<?php
/**
 * Resource suggestions never implicitly select, create or submit a resource.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Admin;

use Fator3\McpGoogle\{Admin, Settings, Options, Connections, Gate, Response, Cache, Policy, Ads\AdsApi, Unified\Query, Auth\Credentials, Http\GoogleClient};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Resources {

	public static function normalize( string $field, string $value ) {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}
		if ( 'ads_customer_id' === $field ) {
			return \Fator3\McpGoogle\Ads\CustomerId::normalize( $value );
		}
		if ( 'ga_property_id' === $field ) {
			$id = \Fator3\McpGoogle\Analytics\PropertyId::normalize( $value );
			return is_wp_error( $id ) ? $id : preg_replace( '~^properties/~', '', $id );
		}
		if ( 'spreadsheet_id' === $field && false !== strpos( $value, '://' ) ) {
			$parts = wp_parse_url( $value );
			if ( ! is_array( $parts ) || ( $parts['scheme'] ?? '' ) !== 'https' || ( $parts['host'] ?? '' ) !== 'docs.google.com' || isset( $parts['user'] ) || isset( $parts['port'] ) || ! preg_match( '~^/spreadsheets/d/([A-Za-z0-9_-]+)(?:/|$)~D', $parts['path'] ?? '', $m ) ) {
				return new \WP_Error( 'f3_google_sheet_url', 'Informe o ID ou uma URL HTTPS de planilha em docs.google.com.' );
			}
			return $m[1];
		}
		return $value;
	}
	public static function discover( string $service, string $page = '' ): array {
		if ( ! in_array( $service, array( 'ga', 'ads', 'gsc', 'sheets' ), true ) ) {
			return Response::fail( new \WP_Error( 'f3_google_discovery_service', 'Serviço inválido para descoberta.' ) );
		}
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}
		$result = array(
			'success'         => true,
			'items'           => array(),
			'warnings'        => array(),
			'next_page_token' => '',
			'complete'        => true,
			'revision'        => $revision,
			'connection_id'   => Connections::id(),
			'checked_at'      => gmdate( 'c' ),
		);
		if ( 'sheets' === $service ) {
			$gate = Gate::check( 'sheets' );
			if ( null !== $gate ) {
				return $gate + array( 'complete' => false ) + $result;
			}
			$query = array(
				'q'                         => "mimeType='application/vnd.google-apps.spreadsheet' and trashed=false",
				'fields'                    => 'files(id,name),nextPageToken,incompleteSearch',
				'pageSize'                  => 100,
				'supportsAllDrives'         => true,
				'includeItemsFromAllDrives' => true,
			);
			if ( '' !== $page ) {
				$query['pageToken'] = $page;
			}
			$data = GoogleClient::get(
				GoogleClient::HOST_GOOGLE . '/drive/v3/files',
				$query,
				array(
					'scopes'    => Credentials::scopes_for( 'sheets' ),
					'connector' => 'sheets',
					'mode'      => 'read',
					'retries'   => 0,
				)
			);
			if ( is_wp_error( $data ) ) {
				return Response::fail( $data ) + array( 'complete' => false ) + $result;
			}
			foreach ( $data['files'] ?? array() as $row ) {
				$result['items'][] = array(
					'id'   => (string) $row['id'],
					'name' => (string) ( $row['name'] ?? $row['id'] ),
				);
			}
			$result['next_page_token'] = (string) ( $data['nextPageToken'] ?? '' );
			$result['complete']        = '' === $result['next_page_token'] && empty( $data['incompleteSearch'] );
			if ( ! empty( $data['incompleteSearch'] ) ) {
				$result['warnings'][] = 'O Google retornou uma busca incompleta. Informe o ID conhecido se o arquivo não aparecer.';
			}
		} else {
			$data               = Query::accounts(
				array(
					'connector'       => array(
						'ga'  => 'ga4',
						'ads' => 'google-ads',
						'gsc' => 'search-console',
					)[ $service ],
					'refresh'         => true,
					'expand_managers' => true,
				)
			);
			$result['warnings'] = $data['warnings'] ?? array();
			$result['success']  = ! empty( $data['success'] ) && ( ! $result['warnings'] || ! empty( $data['accounts'] ) );
			$result['complete'] = ! empty( $data['success'] ) && ! $result['warnings'];
			foreach ( $data['accounts'] ?? array() as $row ) {
				$id = self::normalize(
					array(
						'ga'  => 'ga_property_id',
						'ads' => 'ads_customer_id',
						'gsc' => 'gsc_site_url',
					)[ $service ],
					(string) ( $row['native_account_id'] ?? $row['account_id'] ?? '' )
				);
				if ( ! is_wp_error( $id ) && '' !== $id ) {
					$result['items'][] = array(
						'id'   => $id,
						'name' => (string) ( $row['name'] ?? $id ) . ( ! empty( $row['parent'] ) ? ' · ' . $row['parent'] : '' ),
					);
				}
			}
		}
		return $result;
	}
	/** Shared feedback for the resource forms. A partial page can still supply choices. */
	public static function notice( array $result ): string {
		if ( empty( $result['success'] ) ) {
			return 'discovery_failed';
		}
		return empty( $result['complete'] ) ? 'discovery_partial' : 'discovered';
	}
	public static function cached( string $service ): ?array {
		$data     = \Fator3\McpGoogle\Cache::get( Admin::feedback_key( 'discovery_' . $service ) );
		$revision = Settings::revision();
		return is_array( $data ) && is_string( $revision ) && ( $data['revision'] ?? '' ) === $revision ? $data : null;
	}
	public static function sitemap_suggestion(): string {
		if ( defined( 'WPSEO_VERSION' ) && ( ! class_exists( '\WPSEO_Options' ) || \WPSEO_Options::get( 'enable_xml_sitemap', true ) ) ) {
			return home_url( '/sitemap_index.xml' );
		}
		if ( function_exists( 'wp_sitemaps_get_server' ) ) {
			$s = wp_sitemaps_get_server();
			if ( $s && $s->sitemaps_enabled() ) {
				return $s->index->get_index_url();
			}
		}
		return '';
	}
}

/** Structured administration; kept in this module for exact 0.15 rollback. */
final class ResourceChoices {
    private static int $field_number = 0;
    private static function key(string $kind,string $parent=''): string {return 'f3_mcp_google_choices_'.hash('sha256',Connections::id().'|'.Credentials::identity_key().'|'.$kind.'|'.$parent);}
    public static function items(string $kind,string $parent=''): array {return Cache::get(self::key($kind,$parent))['items']??[];}
    public static function load(string $kind,string $parent=''): array {
        if (!Options::authorized()) return ['success'=>false];
        $service = ['stream'=>'ga','action'=>'ads','gtm_account'=>'gtm'][$kind] ?? $kind;
        if ($denied=Gate::check($service)) { return $denied+['complete'=>false]; }
        $revision = Settings::revision();
        if (is_wp_error($revision)) {
            return Response::fail($revision);
        }
        $key = self::key($kind, $parent);
        $r=Policy::administrative_read(static function() use($kind,$parent) {
            if (in_array($kind,['ga','ads','gsc','sheets'],true)) return Resources::discover($kind);
            $opts=['mode'=>'read','retries'=>0,'timeout'=>5];$field='';$url='';$body=null;$verb='GET';
            if ($kind==='stream'&&preg_match('~^properties/[0-9]+$~D',$parent)) {
                $opts+=['connector'=>'ga','scopes'=>Credentials::scopes_for('ga'),'operation_id'=>'analyticsadmin.properties.dataStreams.list'];
                $url=GoogleClient::HOST_GA_ADMIN.'/v1beta/'.$parent.'/dataStreams';$field='dataStreams';
            } elseif ($kind==='action'&&preg_match('/^[0-9]{10}$/D',$parent)) {
                $opts+=['connector'=>'ads','scopes'=>Credentials::scopes_for('ads'),'operation_id'=>'googleads.customers.googleAds.search','headers'=>AdsApi::headers()];
                $url=AdsApi::base().'/customers/'.$parent.'/googleAds:search';$verb='POST';$field='results';
                $body=['query'=>"SELECT conversion_action.resource_name, conversion_action.name FROM conversion_action WHERE conversion_action.type = 'UPLOAD_CLICKS' AND conversion_action.status = 'ENABLED'"];
            } elseif ($kind==='gtm_account'||($kind==='gtm'&&preg_match('~^accounts/[0-9]+$~D',$parent))) {
                $accounts=$kind==='gtm_account';
                $opts+=['connector'=>'gtm','scopes'=>Credentials::scopes_for('gtm'),'operation_id'=>$accounts?'tagmanager.accounts.list':'tagmanager.accounts.containers.list'];
                $url=GoogleClient::HOST_GTM.'/tagmanager/v2/'.($accounts?'accounts':$parent.'/containers');$field=$accounts?'account':'container';
            } else return ['success'=>false,'message'=>'Selecione primeiro a conta ou propriedade.'];
            $items=[];$page='';
            for($n=0;$n<10;$n++) {
                if ($page) {if ($verb==='POST') $body['pageToken']=$page;else $opts['query']=['pageToken'=>$page];}
                $r=GoogleClient::request($verb,$url,$body,$opts);
                if (is_wp_error($r)) return ['success'=>false,'items'=>$items,'complete'=>false,'message'=>'Não foi possível consultar a lista. Confira o acesso e tente novamente.'];
                foreach($r[$field]??[] as $row) {
                    if ($kind==='action') $row=$row['conversionAction']??[];
                    $id=$row['resourceName']??$row['path']??$row['name']??'';
                    if ($id) $items[]=['id'=>$id,'name'=>$row['displayName']??$row['name']??$id];
                }
                $page=$r['nextPageToken']??'';if (!$page) break;
            }
            return ['success'=>true,'items'=>$items,'complete'=>!$page];
        });
        if ($revision !== Settings::revision() || $key !== self::key($kind, $parent)) {
            return Response::fail(new \WP_Error('f3_google_choice_changed', 'A configuração mudou durante a consulta. Confira a conexão e consulte novamente.'));
        }
        if (!empty($r['success']) && !empty($r['complete']) && !Cache::set($key,$r,900)) {
            return Response::fail(new \WP_Error('f3_google_choice_cache','A lista chegou do Google, mas o armazenamento local falhou. Confira o armazenamento e repita a consulta.'));
        }
        return $r;
    }
    public static function select(string $name,string $label,string $value,array $items,string $help=''): void {
        $known=array_column($items,'id');
        if ($value!==''&&!in_array($value,$known,true)) $items[]=['id'=>$value,'name'=>'Seleção salva — consulte a conta para conferir o nome'];
        $id='f3-choice-'.$name.'-'.(++self::$field_number);
        if (!$items && !$help) { $help='Consulte as listas da conta para carregar as opções.'; }
        echo '<div class="f3-field"><label for="'.esc_attr($id).'">'.esc_html($label).'</label><select id="'.esc_attr($id).'" name="'.esc_attr($name).'"'.($help!==''?' aria-describedby="'.esc_attr($id.'-help').'"':'').'><option value="">Selecionar</option>';
        foreach($items as $item) { echo '<option value="'.esc_attr($item['id']).'" '.selected($value,$item['id'],false).'>'.esc_html($item['name'].' · '.$item['id']).'</option>'; }
        echo '</select>';
        if ($help!=='') { echo '<p class="description" id="'.esc_attr($id.'-help').'">'.esc_html($help).'</p>'; }
        echo '</div>';
    }
}

/** Structured administration; kept in this module for exact 0.15 rollback. */
final class ProfileForm {
    private const LABELS=[
        'retention'=>'Retenção','enhanced_measurement'=>'Medição otimizada','google_signals'=>'Sinais do Google','data_redaction'=>'Ocultação de dados','attribution'=>'Atribuição','custom_dimensions'=>'Dimensões personalizadas','custom_metrics'=>'Métricas personalizadas',
        'resetUserDataOnNewActivity'=>'Reiniciar retenção quando houver atividade','eventDataRetention'=>'Retenção de eventos','userDataRetention'=>'Retenção de usuários','searchQueryParameter'=>'Parâmetros da busca interna','siteSearchEnabled'=>'Busca interna','streamEnabled'=>'Medição do fluxo','videoEngagementEnabled'=>'Interações com vídeos','pageChangesEnabled'=>'Mudanças de página','outboundClicksEnabled'=>'Cliques em links externos','uriQueryParameter'=>'Parâmetros adicionais da URL','fileDownloadsEnabled'=>'Downloads','formInteractionsEnabled'=>'Interações com formulários','scrollsEnabled'=>'Rolagem da página','state'=>'Estado','emailRedactionEnabled'=>'Ocultar e-mails','queryParameterRedactionEnabled'=>'Ocultar parâmetros da URL','queryParameterKeys'=>'Parâmetros a ocultar','otherConversionEventLookbackWindow'=>'Janela de outras conversões','adsWebConversionDataExportScope'=>'Canais exportados para Ads','acquisitionConversionEventLookbackWindow'=>'Janela de aquisição','reportingAttributionModel'=>'Modelo de atribuição','scope'=>'Escopo','displayName'=>'Nome exibido','parameterName'=>'Nome do parâmetro','description'=>'Descrição','disallowAdsPersonalization'=>'Impedir personalização de anúncios','restrictedMetricType'=>'Tipo de dado restrito','measurementUnit'=>'Unidade',
        'TWO_MONTHS'=>'2 meses','FOURTEEN_MONTHS'=>'14 meses','TWENTY_SIX_MONTHS'=>'26 meses','THIRTY_EIGHT_MONTHS'=>'38 meses','FIFTY_MONTHS'=>'50 meses','GOOGLE_SIGNALS_ENABLED'=>'Ativado','GOOGLE_SIGNALS_DISABLED'=>'Desativado','NOT_SELECTED_YET'=>'Ainda não selecionado','PAID_AND_ORGANIC_CHANNELS'=>'Canais pagos e orgânicos','GOOGLE_PAID_CHANNELS'=>'Canais pagos do Google','PAID_AND_ORGANIC_CHANNELS_DATA_DRIVEN'=>'Canais pagos e orgânicos — baseado em dados','PAID_AND_ORGANIC_CHANNELS_LAST_CLICK'=>'Canais pagos e orgânicos — último clique','GOOGLE_PAID_CHANNELS_LAST_CLICK'=>'Canais pagos do Google — último clique','EVENT'=>'Evento','USER'=>'Usuário','ITEM'=>'Item','COST_DATA'=>'Custo','REVENUE_DATA'=>'Receita','STANDARD'=>'Padrão','CURRENCY'=>'Moeda','FEET'=>'Pés','METERS'=>'Metros','KILOMETERS'=>'Quilômetros','MILES'=>'Milhas','MILLISECONDS'=>'Milissegundos','SECONDS'=>'Segundos','MINUTES'=>'Minutos','HOURS'=>'Horas'];
    public static function label(string $key): string {
        if (isset(self::LABELS[$key])) return self::LABELS[$key];
        if (preg_match('/_([0-9]+)_DAYS$/',$key,$m)) return $m[1].' dias';
        return 'Configuração';
    }
    public static function render(array $schema,array $values=[]): void {
        echo '<p>Campos vazios não são administrados por este perfil. Escolha explicitamente Sim ou Não para alterar uma opção.</p>';
        foreach($schema as $section=>$node) {echo '<details class="f3-details"><summary>'.esc_html(self::label($section)).'</summary>';self::node($node,'profile_fields['.$section.']',$values[$section]??null,self::label($section));echo '</details>';}
    }
    private static function node(array $node,string $name,$value,string $label): void {
        $type=$node['type']??'object';
        if ($type==='object') {foreach($node['properties'] as $key=>$child) self::node($child,$name.'['.$key.']',$value[$key]??null,self::label($key));return;}
        if ($type==='array') {
            $rows=is_array($value)?$value:[];$rows[]=null;
            echo '<div data-profile-rows="'.esc_attr($name).'">';
            foreach($rows as $i=>$row) {echo '<fieldset class="f3-profile-row" data-row-index="'.(int)$i.'"><legend>'.esc_html($label).' · '.($i+1).'</legend>';self::node($node['items'],$name.'['.$i.']',$row,$label);echo '<button type="button" class="button" data-remove-row>Remover linha</button></fieldset>';}
            echo '<button type="button" class="button" data-add-profile-row>Adicionar linha</button></div>';return;
        }
        $id='f3-profile-'.substr(hash('sha256',$name),0,12);
        echo '<p class="f3-field"><label for="'.esc_attr($id).'">'.esc_html($label).'</label>';
        if ($type==='boolean'||isset($node['enum'])) {
            echo '<select id="'.esc_attr($id).'" name="'.esc_attr($name).'"><option value="">Não alterar</option>';
            $values=$type==='boolean'?['true','false']:$node['enum'];$current=is_bool($value)?($value?'true':'false'):$value;
            foreach($values as $v) echo '<option value="'.esc_attr($v).'" '.selected($current,$v,false).'>'.esc_html($type==='boolean'?($v==='true'?'Sim':'Não'):self::label($v)).'</option>';
            echo '</select>';
        } else echo '<input id="'.esc_attr($id).'" name="'.esc_attr($name).'" type="'.(in_array($type,['integer','number'],true)?'number':'text').'" value="'.esc_attr((string)$value).'" maxlength="'.(int)($node['maxLength']??1024).'">';
        echo '</p>';
    }
    public static function parse(array $schema,array $posted): array {
        $out=['schema_version'=>'1.0.0'];
        foreach($schema as $section=>$node) { $value=self::value($node,$posted[$section]??null);if ($value!==null) $out[$section]=$value; }
        return $out;
    }
    private static function value(array $node,$value) {
        $type=$node['type']??'object';
        if ($type==='object') {$out=[];foreach($node['properties'] as $key=>$child){$v=self::value($child,is_array($value)?($value[$key]??null):null);if($v!==null)$out[$key]=$v;}return $out?:null;}
        if ($type==='array') {$out=[];foreach(array_slice(is_array($value)?$value:[],0,100) as $row){$v=self::value($node['items'],$row);if($v!==null)$out[]=$v;}return $out?:null;}
        if (!is_scalar($value)||$value==='') return null;
        if ($type==='boolean') return $value==='true'?true:($value==='false'?false:$value);
        if ($type==='integer') return preg_match('/^-?[0-9]+$/D',(string)$value)?(int)$value:$value;
        if ($type==='number') return is_numeric($value)?(float)$value:$value;
        return sanitize_text_field((string)$value);
    }
}
