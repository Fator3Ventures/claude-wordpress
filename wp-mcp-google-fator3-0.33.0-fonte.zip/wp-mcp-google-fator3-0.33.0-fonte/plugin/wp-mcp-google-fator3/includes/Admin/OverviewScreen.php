<?php
/**
 * Status strip, Overview and Help sections (0.32.0). Read-only: local readers only,
 * no request to Google and no write while rendering.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Admin;

use Fator3\McpGoogle\{Admin, Options, Connections, Readiness};
use Fator3\McpGoogle\Auth\{Candidate, Credentials};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class OverviewScreen {

	/** Sections that compute the local readiness verdict (measured cost: evidence uicost032). */
	public const READINESS_SECTIONS = array( 'overview', 'conversions' );
	private const TONES      = array( 'success', 'attention', 'error', 'neutral' );
	private const LEVELS     = array(
		'read'  => 'Leitura',
		'write' => 'Leitura e escrita',
		'admin' => 'Administração',
	);
	private const BINDINGS   = array(
		'gtm'    => 'gtm_container_path',
		'ga'     => 'ga_property_id',
		'ads'    => 'ads_customer_id',
		'gsc'    => 'gsc_site_url',
		'sheets' => 'spreadsheet_id',
	);
	/** Readiness check => label and the place where it is resolved (section, panel). */
	private const CHECKS = array(
		'credential'            => array( 'Credencial da conexão', 'connection', 'identity' ),
		'storage'               => array( 'Armazenamento local', 'advanced', 'diagnostics' ),
		'recovery'              => array( 'Recuperação após restauração', 'advanced', 'operations' ),
		'executor'              => array( 'Executor de tarefas e agenda', 'advanced', 'operations' ),
		'conversion_ga4'        => array( 'Entrega de conversões ao Google Analytics', 'conversions', null ),
		'conversion_google_ads' => array( 'Entrega de conversões ao Google Ads', 'conversions', null ),
		'incidents'             => array( 'Incidentes', 'incidents', null ),
		'core'                  => array( 'Contexto do Site Core', 'conversions', null ),
	);
	private const CHECK_STATES = array(
		'ok'             => array( 'Em ordem', 'success' ),
		'not_configured' => array( 'Não configurado', 'neutral' ),
		'attention'      => array( 'Requer atenção', 'attention' ),
		'blocked'        => array( 'Bloqueado', 'error' ),
	);
	private const RANK = array( 'blocked' => 0, 'attention' => 1, 'not_configured' => 2, 'ok' => 3 );

	private static ?array $readiness = null;

	/** One local readiness read per request, shared by the strip, Overview and Conversions. */
	public static function readiness(): array {
		if ( null === self::$readiness || ( self::$readiness['connection_id'] ?? null ) !== Connections::id() ) {
			self::$readiness = Readiness::read( array() ) + array( 'connection_id' => Connections::id() );
		}
		return self::$readiness;
	}

	/** Status label with a text and a shape marker (CSS); color is never the only cue. */
	public static function badge( string $tone, string $text ): string {
		$tone = in_array( $tone, self::TONES, true ) ? $tone : 'neutral';
		return '<span class="f3-badge f3-badge--' . esc_attr( $tone ) . '">' . esc_html( $text ) . '</span>';
	}

	/** URL of a section, optionally a panel of it, keeping the selected connection. */
	public static function link( string $section, ?string $panel = null ): string {
		$args = array(
			'page'          => Admin::SLUG,
			'connection_id' => Connections::id(),
			'section'       => $section,
			'method'        => Admin::method(),
		);
		if ( null !== $panel ) {
			$args[ 'connection' === $section ? 'connection_panel' : 'advanced_panel' ] = $panel;
		}
		return add_query_arg( $args, admin_url( 'tools.php' ) );
	}

	public static function status_strip(): void {
		$items = array();
		$enabled = Options::is_enabled();
		$items[] = array(
			'Canal MCP',
			$enabled ? 'success' : 'error',
			$enabled ? 'Habilitado' : 'Bloqueado',
			( $enabled ? 'Chamadas Google permitidas neste site.' : 'Chamadas Google bloqueadas neste site.' ) . ( Admin::forced_by_filter() ? ' Controlado também por filtro.' : '' ),
			array( self::link( 'advanced', 'limits' ), 'Controle do site' ),
		);
		$provider  = Credentials::current();
		$candidate = Candidate::state( Options::auth_mode() );
		$detail    = DiagnosticState::identity( $provider, $candidate );
		if ( ! is_wp_error( $provider ) ) {
			list( $tone, $state ) = array( 'success', 'Ativa' );
		} elseif ( in_array( $provider->get_error_code(), array( 'f3_google_crypto_decrypt', 'f3_google_option_read' ), true ) ) {
			list( $tone, $state ) = array( 'error', 'Falha de leitura' );
		} elseif ( ! empty( $candidate['present'] ) || 'f3_google_auth_not_active' === $provider->get_error_code() ) {
			list( $tone, $state ) = array( 'attention', 'Ativação pendente' );
		} else {
			list( $tone, $state ) = array( 'error', 'Ausente' );
		}
		$items[] = array( 'Identidade', $tone, $state, ( 'oauth' === Options::auth_mode() ? 'Conta Google · OAuth' : 'Conta de serviço' ) . ' — ' . $detail, array( self::link( 'connection', 'identity' ), 'Identidade' ) );
		$names = array();
		foreach ( array_keys( Fields::effective_services() ) as $service ) {
			$names[] = Fields::services()[ $service ]['label'] ?? $service;
		}
		$items[] = array(
			'Serviços ativos',
			$names ? 'success' : 'attention',
			$names ? count( $names ) . ( 1 === count( $names ) ? ' serviço' : ' serviços' ) : 'Nenhum',
			$names ? implode( ', ', $names ) : 'Selecione os serviços desta conexão.',
			array( self::link( 'connection', 'services' ), 'Serviços e recursos' ),
		);
		if ( in_array( Admin::section(), self::READINESS_SECTIONS, true ) ) {
			$r = self::readiness();
			if ( empty( $r['success'] ) ) {
				$items[] = array( 'Prontidão local', 'neutral', 'Indisponível', (string) ( $r['message'] ?? 'Leitura local não concluída.' ), array( self::link( 'overview' ), 'Visão geral' ) );
			} else {
				$pending = count( array_filter( (array) $r['checks'], static fn( $c ) => in_array( $c['state'] ?? '', array( 'attention', 'blocked' ), true ) ) );
				$names   = array( 'ready' => array( 'Pronta', 'success' ), 'attention' => array( 'Requer atenção', 'attention' ), 'blocked' => array( 'Bloqueada', 'error' ) );
				list( $state, $tone ) = $names[ $r['state'] ] ?? array( (string) $r['state'], 'neutral' );
				$items[] = array( 'Prontidão local', $tone, $state, $pending ? $pending . ( 1 === $pending ? ' pendência' : ' pendências' ) . ' nas verificações locais.' : 'Nenhuma pendência nas verificações locais.', array( self::link( 'overview' ) . '#f3-next-steps', 'Próximos passos' ) );
			}
		} else {
			// Measured: the readiness read costs more than most sections (uicost032); it runs only where it is shown in full.
			$items[] = array( 'Prontidão local', 'neutral', 'Na Visão geral', 'Verificações locais calculadas na Visão geral.', array( self::link( 'overview' ) . '#f3-next-steps', 'Consultar prontidão' ) );
		}
		echo '<div class="f3-status" role="region" aria-label="Estado da conexão"><ul class="f3-status-list">';
		foreach ( $items as list( $label, $tone, $state, $text, $link ) ) {
			echo '<li class="f3-status-item"><span class="f3-status-label">' . esc_html( $label ) . '</span>' . self::badge( $tone, $state ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
				. '<span class="f3-status-detail">' . esc_html( $text ) . '</span><a class="f3-status-link" href="' . esc_url( $link[0] ) . '">' . esc_html( $link[1] ) . '</a></li>';
		}
		echo '</ul></div>';
	}

	public static function overview(): void {
		echo '<div class="f3-overview">';
		self::next_steps();
		self::services();
		self::operation();
		echo '</div>';
	}

	private static function next_steps(): void {
		$r = self::readiness();
		echo '<section class="f3-card f3-span-2" id="f3-next-steps" aria-labelledby="f3-next-steps-title"><div class="f3-card-header"><h2 id="f3-next-steps-title">Próximos passos</h2>';
		if ( empty( $r['success'] ) ) {
			echo self::badge( 'neutral', 'Indisponível' ) . '</div><p class="f3-empty">' . esc_html( (string) ( $r['message'] ?? 'A leitura local de prontidão não foi concluída.' ) ) . '</p></section>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
			return;
		}
		$names = array( 'ready' => array( 'Pronta', 'success' ), 'attention' => array( 'Requer atenção', 'attention' ), 'blocked' => array( 'Bloqueada', 'error' ) );
		list( $state, $tone ) = $names[ $r['state'] ] ?? array( (string) $r['state'], 'neutral' );
		echo self::badge( $tone, $state ) . '<p class="f3-card-lead">Verificações locais desta conexão, sem consulta ao Google. A mesma leitura está em <code>google/readiness-status</code>.</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
		$checks = (array) $r['checks'];
		usort( $checks, static fn( $a, $b ) => ( self::RANK[ $a['state'] ] ?? 9 ) <=> ( self::RANK[ $b['state'] ] ?? 9 ) );
		echo '<ol class="f3-checklist">';
		foreach ( $checks as $check ) {
			$meta = self::CHECKS[ $check['id'] ] ?? array( (string) $check['id'], 'overview', null );
			if ( 'credential' === $check['id'] && 'channel_disabled' === ( $check['code'] ?? '' ) ) {
				$meta = array( $meta[0], 'advanced', 'limits' );
			}
			list( $label, $tone ) = self::CHECK_STATES[ $check['state'] ] ?? array( (string) $check['state'], 'neutral' );
			$title  = $meta[0];
			$action = $check['action'] ?? null;
			$idle   = 'core' === $check['id'] ? 'Site Core não encontrado nesta instalação.' : ( str_starts_with( (string) $check['id'], 'conversion_' ) ? 'Sem destino configurado nesta conexão.' : 'Não configurado nesta conexão.' );
			$text   = null !== $action && '' !== $action ? $action : ( 'ok' === $check['state'] ? 'Nenhuma ação necessária.' : $idle );
			$where  = 'connection' === $meta[1] || 'advanced' === $meta[1] ? Admin::SECTIONS[ $meta[1] ] . ' → ' . ( 'connection' === $meta[1] ? Admin::CONNECTION_PANELS : Admin::ADVANCED_PANELS )[ $meta[2] ] : Admin::SECTIONS[ $meta[1] ];
			echo '<li class="f3-check f3-check--' . esc_attr( $tone ) . '"><div class="f3-check-head"><strong>' . esc_html( $title ) . '</strong>' . self::badge( $tone, $label ) . '</div>' . ( 'ok' === $check['state'] ? '' : '<p>' . esc_html( $text ) . '</p>' ) . '<a href="' . esc_url( self::link( $meta[1], $meta[2] ) ) . '">' . esc_html( 'Abrir ' . $where ) . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
		}
		echo '</ol></section>';
	}

	private static function services(): void {
		$services = Fields::effective_services();
		$bindings = (array) Options::get( Connections::BINDINGS, array() );
		echo '<section class="f3-card" aria-labelledby="f3-overview-services"><div class="f3-card-header"><h2 id="f3-overview-services">Serviços desta conexão</h2>' . self::badge( $services ? 'success' : 'attention', $services ? count( $services ) . ' ativo' . ( 1 === count( $services ) ? '' : 's' ) : 'Nenhum ativo' ) . '<p class="f3-card-lead">Nível de operação e recurso padrão usados quando a chamada não informa o destino.</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
		if ( ! $services ) {
			echo '<p class="f3-empty">Nenhum serviço habilitado. Escolha os serviços e o nível de operação desta conexão.</p>';
		} else {
			echo '<div class="f3-table-wrap" tabindex="0" role="region" aria-label="Serviços desta conexão"><table class="widefat f3-table f3-stack"><thead><tr><th scope="col">Serviço</th><th scope="col">Nível</th><th scope="col">Recurso padrão</th></tr></thead><tbody>';
			foreach ( $services as $service => $level ) {
				$key = self::BINDINGS[ $service ] ?? null;
				$value = null === $key ? null : ( 'ga_property_id' === $key ? (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' ) : (string) ( $bindings[ $key ] ?? '' ) );
				echo '<tr><th scope="row" data-label="Serviço">' . esc_html( Fields::services()[ $service ]['label'] ?? $service ) . '</th><td data-label="Nível">' . esc_html( self::LEVELS[ $level ] ?? (string) $level ) . '</td><td data-label="Recurso padrão">' . ( null === $value ? '<span class="f3-muted">Sem recurso padrão</span>' : ( '' === $value ? '<span class="f3-muted">Não selecionado</span>' : '<code>' . esc_html( $value ) . '</code>' ) ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '<p class="f3-card-footer"><a href="' . esc_url( self::link( 'connection', 'services' ) ) . '">Abrir Serviços e recursos</a></p></section>';
	}

	private static function operation(): void {
		$r      = self::readiness();
		$checks = array_column( (array) ( $r['checks'] ?? array() ), null, 'id' );
		echo '<section class="f3-card" aria-labelledby="f3-overview-operation"><div class="f3-card-header"><h2 id="f3-overview-operation">Operação</h2><p class="f3-card-lead">Executor, manutenção e incidentes observados localmente.</p></div><dl class="f3-facts">';
		$executor = $checks['executor'] ?? null;
		$codes    = array(
			'ok'                    => 'Em funcionamento',
			'executor_not_observed' => 'Nenhuma passagem registrada',
			'executor_stalled'      => 'Sem passagem há mais de uma hora',
		);
		if ( $executor ) {
			list( , $tone ) = self::CHECK_STATES[ $executor['state'] ] ?? array( '', 'neutral' );
			$label = $codes[ $executor['code'] ] ?? ( str_starts_with( (string) $executor['code'], 'executor_schedule_' ) ? 'Agenda do executor não confirmada' : (string) $executor['code'] );
			echo '<div><dt>Executor e agenda</dt><dd>' . self::badge( $tone, $label ) . '</dd></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
			$next = $executor['detail']['next_run'] ?? null;
			echo '<div><dt>Próxima ocorrência agendada</dt><dd>' . esc_html( $next ? wp_date( 'd/m/Y H:i:s T', (int) $next ) : 'Sem ocorrência agendada' ) . '</dd></div>';
		} else {
			echo '<div><dt>Executor e agenda</dt><dd>' . self::badge( 'neutral', 'Indisponível' ) . '</dd></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
		}
		$m      = \Fator3\McpGoogle\Storage\Maintenance::status();
		$labels = array( 'complete' => array( 'Concluída', 'success' ), 'pending' => array( 'Etapas pendentes', 'neutral' ), 'failed' => array( 'Uma etapa falhou', 'error' ) );
		list( $label, $tone ) = empty( $m['read_success'] ) ? array( 'Estado indisponível', 'neutral' ) : ( ! empty( $m['blocked_by'] ) ? array( 'Execução bloqueada', 'attention' ) : ( $labels[ $m['state'] ?? 'pending' ] ?? array( 'Ainda não observada', 'neutral' ) ) );
		echo '<div><dt>Última manutenção</dt><dd>' . self::badge( $tone, $label ) . ' <span>' . esc_html( isset( $m['at'] ) ? wp_date( 'd/m/Y H:i:s T', (int) $m['at'] ) : 'Não registrada' ) . '</span></dd></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
		$incidents = $checks['incidents'] ?? null;
		if ( ! $incidents ) {
			$text = array( 'neutral', 'Indisponível' );
		} elseif ( 'ok' === $incidents['state'] ) {
			$text = array( 'success', 'Nenhum aberto' );
		} elseif ( 'open_incidents' === $incidents['code'] ) {
			$open = (int) ( $incidents['detail']['open'] ?? 0 );
			$text = array( 'attention', $open . ( 1 === $open ? ' aberto' : ' abertos' ) );
		} else {
			$text = array( 'attention', 'Leitura não concluída' );
		}
		echo '<div><dt>Incidentes</dt><dd>' . self::badge( $text[0], $text[1] ) . '</dd></div></dl>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge() escapes.
		echo '<p class="f3-card-footer f3-links"><a href="' . esc_url( self::link( 'advanced', 'operations' ) ) . '">Tarefas e agendas</a><a href="' . esc_url( self::link( 'advanced', 'templates' ) ) . '">Manutenção</a><a href="' . esc_url( self::link( 'incidents' ) ) . '">Incidentes</a></p></section>';
	}

	public static function help(): void {
		$documents = Admin::documents();
		$groups    = Admin::document_groups();
		$listed    = array_merge( ...array_values( $groups ) );
		$others    = array_values( array_diff( array_keys( $documents ), $listed ) );
		if ( $others ) {
			$groups['Outros documentos'] = $others;
		}
		echo '<section class="f3-card" aria-labelledby="f3-help-documents"><div class="f3-card-header"><h2 id="f3-help-documents">Documentos da versão ' . esc_html( F3_MCP_GOOGLE_VERSION ) . '</h2><p class="f3-card-lead">Guias, contratos e schemas instalados com o plugin. O download exige sessão de administrador.</p></div><div class="f3-doc-groups">';
		foreach ( $groups as $group => $names ) {
			$names = array_values( array_filter( $names, static fn( $name ) => isset( $documents[ $name ] ) ) );
			if ( ! $names ) {
				continue;
			}
			$id = 'f3-doc-group-' . substr( md5( $group ), 0, 8 );
			echo '<section class="f3-doc-group" aria-labelledby="' . esc_attr( $id ) . '"><h3 id="' . esc_attr( $id ) . '">' . esc_html( $group ) . '</h3><ul class="f3-doc-list">';
			foreach ( $names as $name ) {
				echo '<li><a href="' . esc_url( Admin::document_url( $name ) ) . '">' . esc_html( $documents[ $name ] ) . '</a><span class="f3-doc-meta"><code>' . esc_html( $name ) . '</code> · ' . esc_html( str_ends_with( $name, '.json' ) ? 'JSON' : 'Markdown' ) . '</span></li>';
			}
			echo '</ul></section>';
		}
		echo '</div></section>';
		echo '<section class="f3-card" aria-labelledby="f3-help-mcp"><div class="f3-card-header"><h2 id="f3-help-mcp">Leitura pelo MCP</h2><p class="f3-card-lead">Os mesmos documentos podem ser lidos por agentes, em páginas, pela operação <code>google/documentation</code>.</p></div><ol class="f3-sequence">';
		echo '<li><strong>Índice.</strong> Chame com <code>{}</code>. A resposta lista cada documento com descrição, tamanho e <code>revision</code> (SHA-256 do documento inteiro).</li>';
		echo '<li><strong>Primeira página.</strong> Informe <code>document</code> e, se quiser, <code>limit_bytes</code>: <code>{"document":"README.md","limit_bytes":16384}</code>.</li>';
		echo '<li><strong>Continuação.</strong> Enquanto <code>next_offset</code> não for nulo, repita com <code>offset</code> igual a <code>next_offset</code> e <code>expected_revision</code> igual à <code>revision</code> recebida.</li>';
		echo '<li><strong>Documento alterado.</strong> Se a revisão mudar durante a leitura, a continuação é recusada; recomece pelo índice.</li></ol></section>';
	}
}
