<?php
/** Read-only labels for local credential and cached diagnostic states. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class DiagnosticState {
    public static function identity( $provider, array $candidate ): string {
        if ( is_wp_error($provider) ) {
            $code = $provider->get_error_code();
            if ( 'f3_google_crypto_decrypt' === $code ) { return 'Falha de descriptografia da credencial ativa; consulte diagnóstico e recuperação'; }
            if ( 'f3_google_option_read' === $code ) { return 'Falha de leitura da credencial ativa; consulte diagnóstico e recuperação'; }
            if ( !empty($candidate['present']) && empty($candidate['readable']) ) { return 'Credencial candidata salva, mas ilegível'; }
            if ( !empty($candidate['present']) ) { return 'Credencial candidata salva; ativação pendente'; }
            if ( 'f3_google_auth_not_active' === $code ) { return 'Credencial salva; ativação pendente'; }
            return 'Credencial ausente; configure na área Conexão';
        }
        $label = 'Credencial ativa legível: ' . (string)($provider->describe()['identity'] ?? 'identidade disponível');
        if ( !empty($candidate['present']) ) { $label .= empty($candidate['readable']) ? ' · candidata ilegível' : ' · candidata salva; ativação pendente'; }
        return $label;
    }
    public static function valid( array $result ): bool {
        if ( ! is_bool( $result['execution_success'] ?? null )
            || ! is_string( $result['revision'] ?? null ) || '' === $result['revision']
            || ! is_string( $result['checked_at'] ?? null ) || false === strtotime( $result['checked_at'] ) ) {
            return false;
        }
        foreach ( array( 'message', 'connection_id', 'auth_mode' ) as $key ) {
            if ( isset( $result[ $key ] ) && ! is_string( $result[ $key ] ) ) {
                return false;
            }
        }
        $verdict = $result['result_status'] ?? null;
        if ( ! $result['execution_success'] ) {
            return 'execution_error' === $verdict && empty( $result['checks'] );
        }
        if ( ! is_array( $result['checks'] ?? null ) || ! $result['checks'] ) {
            return false;
        }
        $counts = array( 'passed' => 0, 'failed' => 0, 'skipped' => 0, 'not_configured' => 0 );
        foreach ( $result['checks'] as $check ) {
            if ( ! is_array( $check ) || ! is_string( $check['name'] ?? null )
                || ! is_string( $check['status'] ?? null ) || ! isset( $counts[ $check['status'] ] ) ) {
                return false;
            }
            foreach ( array( 'detail', 'target', 'error_code' ) as $key ) {
                if ( isset( $check[ $key ] ) && ! is_string( $check[ $key ] ) ) {
                    return false;
                }
            }
            ++$counts[ $check['status'] ];
        }
        foreach ( $counts as $key => $count ) {
            if ( $count !== ( $result[ $key ] ?? null ) ) {
                return false;
            }
        }
        $expected = $counts['failed'] ? 'failed' : ( $counts['skipped'] || $counts['not_configured'] ? 'incomplete' : 'passed' );
        return $verdict === $expected;
    }
    public static function instant( string $date ): string {
        $timestamp = strtotime($date);
        if ( false === $timestamp ) { return 'Horário indisponível'; }
        return wp_date('d/m/Y H:i:s T',$timestamp);
    }
}
