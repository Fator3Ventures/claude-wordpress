<?php
/**
 * Operational readiness of the selected connection in one local call (0.18.0).
 *
 * Interprets the same local readers used by google/status, google/conversion-delivery-status,
 * google/alerts and google/storage-status, and answers "can this site deliver and renew now,
 * and what must be done if not". It never calls Google, never repairs, never sends e-mail.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Automation\{Alerts, CronHistory, ExecutorSchedule};
use Fator3\McpGoogle\Storage\State;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Readiness {
	public const CONTRACT = 'google-readiness/1.0.0';
	/** An executor pass older than this, with the event scheduled, means the site trigger is not running. */
	public const EXECUTOR_STALE_SECONDS = 3600;
	/** A renewal attempt this late means the executor did not run it. */
	public const RENEWAL_LATE_SECONDS = 3600;
	private const RANK = array( 'ok' => 0, 'not_configured' => 0, 'attention' => 1, 'blocked' => 2 );
	private const TARGETS = array(
		'ga4'        => array( 'Google Analytics', array( 'stream', 'measurement_id' ) ),
		'google_ads' => array( 'Google Ads', array( 'customer_id', 'conversion_action' ) ),
	);
	/** Action for each local readiness reason of a configured destination. */
	private const REASON_ACTIONS = array(
		'verification_required'                => 'Verifique o destino na aba Conversões (google/verify-conversion-delivery). Sem prova válida o Core não envia.',
		'grant_revoked'                        => 'Um administrador atual deve salvar a configuração de conversões de novo, renovando a autorização do destino.',
		'channel_disabled'                     => 'Abra o canal em Ferramentas → Fator3 MCP Google → Conexão.',
		'service_disabled'                     => 'Ligue o serviço (GA4 ou Ads) da conexão na aba Conexão.',
		'service_read_only'                    => 'Conceda escrita ao serviço na política da conexão; a entrega é uma escrita.',
		'credential_unavailable'               => 'Configure a credencial (conta de serviço ou OAuth) na aba Conexão.',
		'destination_missing'                  => 'Selecione o destino na aba Conversões; o ID de medição GA4 vem do Site Core.',
		'mp_secret_missing'                    => 'Cadastre o segredo do Measurement Protocol do fluxo GA4 na aba Conversões.',
		'ads_developer_token_missing'          => 'Cadastre o token de desenvolvedor do Google Ads na aba Conexão.',
		'core_async_unsupported'               => 'Atualize o Site Core para a versão com reconciliação assíncrona das conversões Ads.',
		'resource_not_permitted'               => 'Autorize o destino nas permissões por recurso da conexão (google/plan-policy e google/configure-policy).',
		'storage_or_recovery_unavailable'      => 'Conclua a recuperação ou restaure o armazenamento antes de entregar conversões.',
		'configuration_unreadable'             => 'A configuração de conversões está ilegível; salve-a novamente na aba Conversões.',
		'connections_unreadable'               => 'O registro de conexões está ilegível; confira a aba Conexão.',
		'ambiguous_connection'                 => 'Mais de uma conexão entrega este destino; deixe a entrega habilitada em apenas uma.',
	);

	public static function register(): void {
		Ability::register(
			'google/readiness-status',
			'any',
			array(
				'label'         => 'Consultar prontidão operacional',
				'description'   => 'Veredito local da conexão em uma chamada: ready, attention ou blocked, com cada verificação (credencial, armazenamento, recuperação, executor, entrega GA4 e Ads com validade e renovação, incidentes abertos e Site Core) e a ação a tomar. Não consulta o Google, não repara nem envia e-mail.',
				'mode'          => 'read',
				'input_schema'  => array(
					'properties' => array(
						'hours_ahead' => array(
							'type'        => 'integer',
							'minimum'     => 1,
							'maximum'     => 48,
							'default'     => 6,
							'description' => 'Janela, em horas, para apontar prova de entrega que vence sem renovação agendada antes do vencimento.',
						),
					),
				),
				'output_schema' => self::schema(),
				'callback'      => array( self::class, 'read' ),
			)
		);
	}

	public static function schema(): array {
		$state = array( 'type' => 'string', 'enum' => array( 'ok', 'attention', 'blocked', 'not_configured' ) );
		return array(
			'type'       => 'object',
			'required'   => array( 'success', 'contract', 'state', 'checks', 'actions', 'google_checks_performed' ),
			'properties' => array(
				'success'                 => array( 'type' => 'boolean' ),
				'message'                 => array( 'type' => 'string' ),
				'contract'                => array( 'type' => 'string', 'enum' => array( self::CONTRACT ) ),
				'state'                   => array( 'type' => 'string', 'enum' => array( 'ready', 'attention', 'blocked' ) ),
				'connection_id'           => array( 'type' => 'string' ),
				'plugin_version'          => array( 'type' => 'string' ),
				'observed_at'             => array( 'type' => 'integer' ),
				'hours_ahead'             => array( 'type' => 'integer' ),
				'google_checks_performed' => array( 'type' => 'boolean', 'enum' => array( false ) ),
				'ads_planning_access' => Ads\PlannerAccess::status_schema(),
                'checks'                  => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'required'   => array( 'id', 'state', 'code', 'action' ),
						'properties' => array(
							'id'     => array( 'type' => 'string' ),
							'state'  => $state,
							'code'   => array( 'type' => 'string' ),
							'action' => array( 'type' => array( 'string', 'null' ) ),
							'detail' => array( 'type' => 'object' ),
						),
					),
				),
				'actions'                 => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
			),
		);
	}

	public static function read( array $input = array() ): array {
		if ( ! Options::authorized() ) {
			return Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão administrativa exigida.' ) );
		}
		$hours = (int) ( $input['hours_ahead'] ?? 6 );
		$hours = max( 1, min( 48, $hours ) );
		return CoreContext::within_read_scope( static fn() => self::report( $hours, time() ) );
	}

	private static function check( string $id, string $state, string $code, ?string $action, array $detail = array() ): array {
		$check = array(
			'id'     => $id,
			'state'  => $state,
			'code'   => $code,
			'action' => $action,
		);
		if ( $detail ) {
			$check['detail'] = $detail;
		}
		return $check;
	}

	private static function report( int $hours, int $now ): array {
		$checks   = array();
		$checks[] = self::credential();
		$checks[] = self::storage();
		$checks[] = self::recovery();
		$checks[] = self::executor( $now );
		foreach ( self::conversions( $hours * HOUR_IN_SECONDS, $now ) as $check ) {
			$checks[] = $check;
		}
		$checks[] = self::incidents();
		$checks[] = self::core();
		$worst = 0;
		foreach ( $checks as $check ) {
			$worst = max( $worst, self::RANK[ $check['state'] ] );
		}
		$ordered = $checks;
		usort( $ordered, static fn( $a, $b ) => self::RANK[ $b['state'] ] <=> self::RANK[ $a['state'] ] );
		$actions = array();
		foreach ( $ordered as $check ) {
			if ( self::RANK[ $check['state'] ] > 0 && null !== $check['action'] && ! in_array( $check['action'], $actions, true ) ) {
				$actions[] = $check['action'];
			}
		}
		$state = array( 0 => 'ready', 1 => 'attention', 2 => 'blocked' )[ $worst ];
		return Response::ok(
			array(
				'contract'                => self::CONTRACT,
				'state'                   => $state,
				'connection_id'           => Connections::id(),
				'plugin_version'          => F3_MCP_GOOGLE_VERSION,
				'observed_at'             => $now,
				'hours_ahead'             => $hours,
				'google_checks_performed' => false,
				'ads_planning_access' => Ads\PlannerAccess::status(),
                'checks'                  => $checks,
				'actions'                 => $actions,
			),
			array( 'ready' => 'Conexão pronta.', 'attention' => 'Conexão requer atenção.', 'blocked' => 'Há bloqueio que impede a operação.' )[ $state ]
		);
	}

	private static function credential(): array {
		if ( ! Options::is_enabled() ) {
			return self::check( 'credential', 'blocked', 'channel_disabled', self::REASON_ACTIONS['channel_disabled'], array( 'mode' => Options::auth_mode() ) );
		}
		$credentials = Credentials::current();
		if ( is_wp_error( $credentials ) ) {
			return self::check( 'credential', 'blocked', (string) $credentials->get_error_code(), 'Configure a credencial (conta de serviço ou OAuth) na aba Conexão.', array( 'mode' => Options::auth_mode() ) );
		}
		return self::check( 'credential', 'ok', 'ok', null, array( 'mode' => Options::auth_mode() ) );
	}

	private static function storage(): array {
		$status = State::status();
		return ! empty( $status['ready'] )
			? self::check( 'storage', 'ok', 'ok', null )
			: self::check( 'storage', 'blocked', (string) ( $status['error_code'] ?? 'f3_google_storage_unavailable' ), 'Consulte google/storage-status; reative o plugin depois de conferir o banco.', array( 'tables' => $status['tables'] ?? array() ) );
	}

	private static function recovery(): array {
		$status = Recovery::status();
		if ( isset( $status['error_code'] ) ) {
			return self::check( 'recovery', 'blocked', (string) $status['error_code'], 'Consulte google/recovery-status; o estado da recuperação está ilegível.' );
		}
		return ! empty( $status['paused'] )
			? self::check( 'recovery', 'blocked', 'recovery_paused', 'Conclua a recuperação e retome a operação por google/recovery.' )
			: self::check( 'recovery', 'ok', 'ok', null );
	}

	private static function executor( int $now ): array {
		$schedule = ExecutorSchedule::status();
		$state    = (string) ( $schedule['state'] ?? 'unknown' );
		$history  = CronHistory::summary( Connections::id(), $now );
		$last     = is_array( $history['last_run'] ?? null ) ? (int) ( $history['last_run']['at'] ?? 0 ) : 0;
		$detail   = array(
			'schedule_state'   => $state,
			'next_run'         => $schedule['next_run'] ?? null,
			'last_run_at'          => $last ?: null,
			'last_run_age_seconds' => $last ? max( 0, $now - $last ) : null,
			'server_cron'      => (bool) ( $history['cron_servidor_ativo'] ?? false ),
		);
		if ( 'present' !== $state ) {
			return self::check( 'executor', 'attention', 'executor_schedule_' . $state, 'Execute google/maintenance para reparar a agenda do executor; renovações e tarefas dependem dela.', $detail );
		}
		if ( ! $last ) {
			return self::check( 'executor', 'attention', 'executor_not_observed', 'Nenhuma passagem do executor foi registrada. Confira o WP-Cron ou configure o cron do servidor para google/executar-vencidos.', $detail );
		}
		if ( $now - $last > self::EXECUTOR_STALE_SECONDS ) {
			return self::check( 'executor', 'attention', 'executor_stalled', 'O executor não passa há mais de uma hora. Sem tráfego o WP-Cron não dispara; configure o cron do servidor.', $detail );
		}
		return self::check( 'executor', 'ok', 'ok', null, $detail );
	}

	/** @return array<int,array> */
	private static function conversions( int $window, int $now ): array {
		$status = ConversionDelivery::status();
		if ( empty( $status['success'] ) ) {
			$out = array();
			foreach ( array_keys( self::TARGETS ) as $target ) {
				$out[] = self::check( 'conversion_' . $target, 'blocked', (string) ( $status['code'] ?? 'configuration_unreadable' ), self::REASON_ACTIONS['configuration_unreadable'] );
			}
			return $out;
		}
		$config = (array) ( $status['config'] ?? array() );
		$out    = array();
		foreach ( self::TARGETS as $target => list( $label, $fields ) ) {
			$id  = 'conversion_' . $target;
			$cap = (array) ( $status[ $target ] ?? array() );
			// The shared Core measurement ID is not a per-connection destination selection.
			// Once any local destination is selected, let the delivery guard explain missing fields.
			$destination = 'ga4' === $target
				? '' !== (string) ( $config['stream'] ?? '' )
				: '' !== (string) ( $config['customer_id'] ?? '' ) || '' !== (string) ( $config['conversion_action'] ?? '' );
			if ( ! $destination ) {
				$out[] = self::check( $id, 'not_configured', 'destination_not_selected', null, array( 'destination' => $label ) );
				continue;
			}
			if ( empty( $config['enabled'] ) ) {
				$out[] = self::check( $id, 'not_configured', 'integration_disabled', null, array( 'destination' => $label ) );
				continue;
			}
			$renewal = is_array( $cap['renewal'] ?? null ) ? $cap['renewal'] : array();
			$expires = isset( $cap['verification_expires_at'] ) ? (int) $cap['verification_expires_at'] : null;
			$next    = isset( $renewal['next_attempt'] ) ? (int) $renewal['next_attempt'] : null;
			$detail  = array(
				'destination'             => $label,
				'ready'                   => ! empty( $cap['ready'] ),
				'reason'                  => (string) ( $cap['reason'] ?? 'unknown' ),
				'verified_at'             => $cap['verified_at'] ?? null,
				'verification_expires_at' => $expires,
				'expires_in_seconds'      => null === $expires ? null : $expires - $now,
				'verification_pending'    => ! empty( $cap['verification_pending'] ),
				'renewal'                 => array_intersect_key( $renewal, array_flip( array( 'last_at', 'result', 'code', 'failures', 'next_attempt' ) ) ),
			);
			if ( empty( $cap['ready'] ) ) {
				if ( 'verification_required' === $detail['reason'] && ! empty( $cap['verification_pending'] ) ) {
					$out[] = self::check( $id, 'attention', 'verification_pending', 'A validação automática do destino foi reagendada' . ( $next ? ' para ' . wp_date( 'd/m/Y H:i', $next ) : '' ) . '. Confira o destino; o diagnóstico do Google está em google/alerts.', $detail );
					continue;
				}
				$reason = $detail['reason'];
				$out[]  = self::check( $id, 'blocked', $reason, self::REASON_ACTIONS[ $reason ] ?? 'Confira a configuração do destino na aba Conversões.', $detail );
				continue;
			}
			if ( null !== $next && $next < $now - self::RENEWAL_LATE_SECONDS ) {
				$out[] = self::check( $id, 'attention', 'renewal_overdue', 'A renovação da prova está atrasada: o executor não a executou. Confira o cron do servidor; a prova vence em ' . wp_date( 'd/m/Y H:i', (int) $expires ) . '.', $detail );
				continue;
			}
			if ( null !== $expires && $expires - $now <= $window && ( null === $next || $next >= $expires ) ) {
				$out[] = self::check( $id, 'attention', 'renewal_not_scheduled_before_expiry', 'A prova vence em ' . wp_date( 'd/m/Y H:i', $expires ) . ' sem renovação agendada antes disso. Verifique o destino manualmente na aba Conversões.', $detail );
				continue;
			}
			if ( 'failed' === ( $renewal['result'] ?? '' ) ) {
				$out[] = self::check( $id, 'attention', 'renewal_failing', 'A última renovação falhou (' . (string) ( $renewal['code'] ?? 'verification_failed' ) . '); a prova atual ainda vale. Confira o acesso antes do vencimento.', $detail );
				continue;
			}
			$out[] = self::check( $id, 'ok', 'ok', null, $detail );
		}
		return $out;
	}

	private static function incidents(): array {
		$state = Alerts::state( array( 'limit' => 100 ), true );
		if ( empty( $state['available'] ) ) {
			return self::check( 'incidents', 'attention', (string) ( $state['error_code'] ?? 'f3_google_incident_read' ), 'Os incidentes não puderam ser lidos; consulte google/alerts.' );
		}
		$open = array();
		foreach ( (array) $state['incidents'] as $incident ) {
			if ( 'open' !== ( $incident['status'] ?? '' ) ) {
				continue;
			}
			$open[] = array_intersect_key( $incident, array_flip( array( 'event', 'resource', 'code', 'updated_at' ) ) );
		}
		if ( ! $open ) {
			return self::check( 'incidents', 'ok', 'ok', null, array( 'open' => 0 ) );
		}
		return self::check( 'incidents', 'attention', 'open_incidents', 'Consulte google/alerts e resolva a causa indicada em cada incidente aberto.', array( 'open' => count( $open ), 'complete' => null === ( $state['next_offset'] ?? null ), 'items' => array_slice( $open, 0, 10 ) ) );
	}

	private static function core(): array {
		$snapshot = CoreContext::snapshot();
		if ( ! empty( $snapshot['ok'] ) ) {
			return self::check( 'core', 'ok', 'ok', null, array( 'measurement_id_present' => '' !== ConversionDelivery::measurement_id() ) );
		}
		$code = (string) ( $snapshot['code'] ?? 'unreadable' );
		if ( 'unavailable' === $code ) {
			return self::check( 'core', 'not_configured', 'core_absent', null );
		}
		return self::check( 'core', 'attention', 'core_context_' . $code, 'O contexto de medição do Site Core não pôde ser lido; confira a versão e a configuração do Core.' );
	}
}
