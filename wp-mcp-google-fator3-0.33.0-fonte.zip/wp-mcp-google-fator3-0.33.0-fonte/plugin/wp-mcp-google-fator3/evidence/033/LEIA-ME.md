# Evidências da versão 0.33.0

`inputs.json` identifica os instaladores. O ZIP de WordPress usado na bancada foi montado a partir da árvore local do WordPress 7.1.4. O manifesto para execução deve informar o caminho dos insumos disponíveis na máquina do revisor. O formato é o de `tools/lab.py`. Os acompanhantes da base e do candidato devem apontar para os mesmos pacotes vigentes.

Na raiz do plugin, os comandos abaixo conferem documentação, produzem o instalador e executam uma faixa da bancada. Informe um diretório de trabalho vazio por faixa. Execute `isolated`, `discovery`, `upgrade`, `docs` e `browser`. Para o navegador, forneça `F3_CHROMIUM` e instale o Playwright para Node. O PHP da suíte PHPUnit precisa de DOM, mbstring, XML, XMLReader e XMLWriter. A configuração e a lista de testes estão em `phpunit.xml`.

```sh
php build/export-contracts.php --check
python3 build/check-docs.py
python3 build/build.py candidate --output /tmp/wp-mcp-google-fator3-0.33.0-instalador.zip
php -d memory_limit=512M /caminho/phpunit-9.6.37.phar --configuration phpunit.xml
python3 tools/release033.py upgrade --manifest /caminho/manifest.json --workdir /tmp/google033-upgrade
```

`unitarios.json` registra a base, a reprodução dos defeitos e o candidato. As subpastas trazem verificações independentes do WordPress, do navegador e do transporte HTTP. `site-teste.json` contém o recibo resumido e as leituras posteriores no ambiente compartilhado. As imagens são da bancada com dados sintéticos.
