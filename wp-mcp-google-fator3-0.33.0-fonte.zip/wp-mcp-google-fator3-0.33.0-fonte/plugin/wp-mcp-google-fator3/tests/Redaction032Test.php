<?php
/** 0.32.0 A: no public output field may collide with the MCP 0.43.0 redaction rule. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options,Connections,Plugin,Catalog,Configuration,Readiness,SelfTest,Telemetry,Records};
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Automation\{Scheduling,ExecutorSchedule,Executor,CronHistory};
use Fator3\McpGoogle\Storage\{Maintenance,Budget};
use Fator3\McpGoogle\Unified\Abilities;
require_once __DIR__.'/Support/McpRedactionRule.php';
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS',3600);
final class Redaction032Test extends TestCase {
    /**
     * Option identifiers of google/configuration-schema. They are input identifiers (fields, configure-*),
     * the definition carries no value, and renaming them would break the configuration input contract.
     * Four are secret options (confidential=true); credential_receipts is a non-secret receipts option whose
     * identifier collides. The MCP hides these five definitions; reported for decision, not renamed here.
     */
    private const CONFIGURATION_OPTION_IDS=['.options.ads_developer_token','.options.mp_secret','.options.oauth_client_secret','.options.oauth_refresh_token','.options.credential_receipts'];
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;Connections::select('default');
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f) if(is_file($f)) unlink($f);
        foreach(['context','volatile'] as $field) { $p=new \ReflectionProperty(Scheduling::class,$field);$p->setAccessible(true);$p->setValue(null,[]); }
        $p=new \ReflectionProperty(Maintenance::class,'observed');$p->setAccessible(true);$p->setValue(null,[]);
        FakeHttp::reset();
        Options::set(Options::ENABLED,true);Options::set(Options::GA_ENABLED,true);Options::set(Options::ADS_ENABLED,true);
        Plugin::register_abilities();
    }
    public function test_rule_double_controls(): void {
        foreach(['last_pass'=>['object','null'],'pass'=>'object','token_ok'=>'object','authorization'=>'object','examined_in_pass'=>'boolean'] as $name=>$type) {
            $this->assertTrue(McpRedactionRule::schema_name_masked($name,$type),$name);
        }
        foreach(['passagens_24h'=>'object','mp_secret_present'=>'boolean','ads_developer_token_configured'=>'boolean','last_run'=>['object','null'],'examined_in_run'=>'boolean','auth_probe'=>'object'] as $name=>$type) {
            $this->assertFalse(McpRedactionRule::schema_name_masked($name,$type),$name);
        }
        $this->assertTrue(McpRedactionRule::sensitive_field('examined_in_pass',true));
        $this->assertTrue(McpRedactionRule::sensitive_field('last_pass_at',null));
        $this->assertFalse(McpRedactionRule::sensitive_field('mp_secret_present',true));
        $this->assertTrue(McpRedactionRule::sensitive_field('mp_secret_present','yes'));
        $this->assertSame(['.cron.last_pass','.x.0.token_ok'],McpRedactionRule::masked_paths(['cron'=>['last_pass'=>null,'passagens_24h'=>['cli'=>1]],'x'=>[['token_ok'=>['ga'=>true]]]]));
        $this->assertSame([],McpRedactionRule::masked_paths(['credential'=>['configured'=>true],'output_schema'=>['type'=>'object','properties'=>['token_ok'=>['type'=>'object']]]]));
        $this->assertSame(['.credential.email'],McpRedactionRule::masked_paths(['credential'=>['configured'=>true,'email'=>'a@b']]));
    }
    /** @return array<string,array> */
    private function output_schemas(): array {
        $out=[];
        foreach (wp_get_abilities() as $entry) {
            if ('google'!==$entry->get_category()) continue;
            $schema=$entry->get_output_schema();
            if (is_array($schema)&&$schema) $out[$entry->get_name()]=$schema;
        }
        return $out;
    }
    private function walk($schema,string $path,array &$hits): void {
        if (!is_array($schema)) return;
        foreach (['properties','patternProperties'] as $k) foreach (($schema[$k]??[]) as $name=>$child) {
            if (McpRedactionRule::schema_name_masked((string)$name,is_array($child)?($child['type']??null):null)) $hits[]=$path.'.'.$name;
            $this->walk($child,$path.'.'.$name,$hits);
        }
        foreach (['items','additionalProperties','not'] as $k) if (isset($schema[$k])&&is_array($schema[$k])) $this->walk($schema[$k],$path.'[]',$hits);
        foreach (['oneOf','anyOf','allOf'] as $k) foreach (($schema[$k]??[]) as $alt) $this->walk($alt,$path,$hits);
    }
    public function test_no_registered_output_schema_property_collides(): void {
        $schemas=$this->output_schemas();
        $this->assertGreaterThan(250,count($schemas));
        $hits=[];
        foreach ($schemas as $name=>$schema) { $found=[];$this->walk($schema,'',$found);foreach($found as $p)$hits[]=$name.' '.$p; }
        $this->assertSame([],$hits);
        // The walker sees nested and anyOf names: the same scan over a planted name must accuse it.
        $planted=[];$this->walk(['type'=>'object','properties'=>['cron'=>['anyOf'=>[['type'=>'object','properties'=>['last_pass'=>['type'=>['object','null']]]]]]]],'',$planted);
        $this->assertSame(['.cron.last_pass'],$planted);
    }
    private function clean(string $label,$result,array $allow=[]): array {
        $this->assertIsArray($result,$label);
        $this->assertSame([],McpRedactionRule::masked_paths($result,'',$allow),$label);
        return $result;
    }
    private function seed_history(): void {
        // A real executor run gives cron.last_run and maintenance progress a non-null value.
        $this->assertTrue(ExecutorSchedule::ensure()['success']);
        $r=Executor::run();
        $this->assertTrue($r['success'],json_encode($r));
    }
    public function test_runtime_outputs_have_no_masked_keys(): void {
        $this->seed_history();
        // A token request leaves telemetry counters in google/status: an old counter name must be accused here.
        Telemetry::started(GoogleClient::HOST_TOKEN.'/token',[]);
        Telemetry::quota(GoogleClient::HOST_GA_DATA.'/v1beta/properties/123:runReport',['propertyQuota'=>['tokensPerHour'=>['consumed'=>1,'remaining'=>9]]]);
        $run=$this->clean('executar-vencidos',wp_get_ability('google/executar-vencidos')->execute([]));
        $this->assertIsArray($run['run']);$this->assertArrayNotHasKey('pass',$run);
        foreach ($run['maintenance']['progress'] as $family=>$p) { $this->assertIsBool($p['examined_in_run'],$family);$this->assertArrayNotHasKey('examined_in_pass',$p); }
        $status=$this->clean('status',Abilities::status([]));
        $this->assertSame(1,$status['telemetry']['counters']['auth_requests']??null,json_encode($status['telemetry']));
        $this->assertIsArray($status['cron']['last_run']);$this->assertArrayNotHasKey('last_pass',$status['cron']);
        foreach ($status['maintenance']['progress'] as $p) $this->assertIsBool($p['examined_in_run']);
        $this->clean('status compact',Abilities::status(['compact'=>true]));
        $live=$this->clean('status live',Abilities::status(['live'=>true]));
        $this->assertIsArray($live['auth_probe']);$this->assertArrayNotHasKey('token_ok',$live);
        $this->assertIsArray($this->clean('status compact live',Abilities::status(['compact'=>true,'live'=>true]))['auth_probe']);
        $this->clean('status all',Abilities::status(['scope'=>'all_connections']));
        $ready=$this->clean('readiness',wp_get_ability('google/readiness-status')->execute([]));
        $executor=array_values(array_filter($ready['checks'],static fn($c)=>$c['id']==='executor'))[0];
        $this->assertIsInt($executor['detail']['last_run_at']);$this->assertIsInt($executor['detail']['last_run_age_seconds']);
        $maintenance=$this->clean('maintenance',wp_get_ability('google/maintenance')->execute([]));
        foreach ($maintenance['progress'] as $p) $this->assertIsBool($p['examined_in_run']);
        $this->clean('storage-status',wp_get_ability('google/storage-status')->execute([]));
        $catalog=$this->clean('ability-catalog',wp_get_ability('google/ability-catalog')->execute(['prefix'=>'google/s','include_schemas'=>true]));
        $this->assertIsString($catalog['execution_checks']);
        $config=$this->clean('configuration-schema',wp_get_ability('google/configuration-schema')->execute([]),self::CONFIGURATION_OPTION_IDS);
        $this->assertIsArray($config['access_requirements']);$this->assertIsArray($config['runtime_prerequisites']['authentication']);
        foreach ($config['options'] as $id=>$definition) $this->assertIsBool($definition['confidential'],$id);
        $this->clean('configuration-schema values',wp_get_ability('google/configuration-schema')->execute(['include_values'=>true]),self::CONFIGURATION_OPTION_IDS);
        $self=$this->clean('selftest',wp_get_ability('google/selftest')->execute([]));
        $template=$this->clean('export-template',wp_get_ability('google/export-template')->execute([]));
        $this->assertFalse($template['confidential_included']);$this->assertArrayNotHasKey('secrets_included',$template);
        $this->assertIsString($self['data_manager']['identity_requirement']);$this->assertIsString($self['data_manager']['developer_access']);
        $this->assertSame(0,count(array_filter(FakeHttp::$requests,static fn($r)=>!str_contains($r['url'],'/token'))));
    }
    public function test_configuration_allowlist_is_exactly_the_secret_option_ids(): void {
        $config=wp_get_ability('google/configuration-schema')->execute([]);
        $this->assertEqualsCanonicalizing(self::CONFIGURATION_OPTION_IDS,McpRedactionRule::masked_paths($config));
        foreach (self::CONFIGURATION_OPTION_IDS as $path) $this->assertSame('credential_receipts'!==substr($path,9),$config['options'][substr($path,9)]['confidential']??null,$path);
    }
    public function test_stored_legacy_names_stay_readable_after_update(): void {
        // State written by 0.31.0: persisted keys are unchanged, presented under the new names.
        Options::set(Maintenance::OPTION,['state'=>'complete','success'=>true,'at'=>time()-60,'progress'=>['cron_retention'=>['cursor'=>'','complete'=>true,'examined_in_pass'=>true]]]);
        $s=Maintenance::status();
        $this->assertTrue($s['progress']['cron_retention']['examined_in_run']);$this->assertArrayNotHasKey('examined_in_pass',$s['progress']['cron_retention']);
        $this->assertTrue(CronHistory::summary('default')['maintenance']['complete']);
        $row=['at'=>time()-30,'started_at'=>time()-30,'finished_at'=>time()-29,'run_id'=>'legacy-run','origem'=>'manual','scope'=>'executor','connection_id'=>'default','success'=>true,'items'=>3,'state'=>'completed'];
        Options::set('f3_mcp_google_cron_history_default',['last_pass'=>$row,'ultima_manual'=>$row,'observed_since'=>time()-100]);
        $summary=CronHistory::summary('default');
        $this->assertSame('legacy-run',$summary['last_run']['run_id']);$this->assertArrayNotHasKey('last_pass',$summary);
        $this->assertArrayHasKey('last_pass',Options::get('f3_mcp_google_cron_history_default'));
    }
    private function telemetry_names(array $state): array {
        $names=[];
        foreach ($state['counters'] as $k=>$v) $names[]=['counters.'.$k,$k,$v];
        foreach ($state['apis'] as $api=>$metrics) { $names[]=['apis.'.$api,$api,$metrics]; foreach ($metrics as $k=>$v) $names[]=['apis.'.$api.'.'.$k,$k,$v]; }
        return $names;
    }
    public function test_every_telemetry_free_map_key_passes_the_redaction_rule(): void {
        // Every counter category and every service map key Telemetry can emit.
        Telemetry::started(GoogleClient::HOST_TOKEN.'/token',[]);
        Telemetry::started(GoogleClient::HOST_GOOGLE.'/discovery/v1/apis',[]);
        Telemetry::started(GoogleClient::HOST_GA_DATA.'/v1beta/properties/1:runReport',['mode'=>'read']);
        Telemetry::started(GoogleClient::HOST_ADS.'/v20/customers/1/googleAds:mutate',['mode'=>'write']);
        Telemetry::finished(GoogleClient::HOST_ADS.'/v20/customers/1/googleAds:mutate',new \WP_Error('x','y'),0.01);
        Telemetry::add('cache_hits');
        foreach ([GoogleClient::HOST_GA_ADMIN,GoogleClient::HOST_GSC,GoogleClient::HOST_SHEETS,GoogleClient::HOST_GTM,GoogleClient::HOST_MP,GoogleClient::HOST_GOOGLE.'/drive/',GoogleClient::HOST_GOOGLE.'/webmasters/',GoogleClient::HOST_GOOGLE.'/siteVerification/'] as $host) Telemetry::started($host.'/x',[]);
        $state=Telemetry::state();
        $this->assertTrue($state['available']);
        $this->assertCount(8,$state['counters'],json_encode($state['counters']));
        $this->assertSame(1,$state['counters']['auth_requests']??null);
        $this->assertArrayNotHasKey('token_requests',$state['counters']);
        foreach ($this->telemetry_names($state) as [$path,$key,$value]) $this->assertFalse(McpRedactionRule::sensitive_field((string)$key,$value),$path);
        $this->assertSame([],McpRedactionRule::masked_paths(['telemetry'=>$state]));
        // Quota observations are a Telemetry map too.
        Telemetry::quota(GoogleClient::HOST_GA_DATA.'/v1beta/properties/123:runReport',['propertyQuota'=>['tokensPerDay'=>['consumed'=>1,'remaining'=>9],'tokensPerHour'=>['consumed'=>1,'remaining'=>9],'tokensPerProjectPerHour'=>['consumed'=>1,'remaining'=>9],'concurrentRequests'=>['consumed'=>0,'remaining'=>10],'serverErrorsPerProjectPerHour'=>['consumed'=>0,'remaining'=>10],'potentiallyThresholdedRequestsPerHour'=>['consumed'=>0,'remaining'=>120]]]);
        $quotas=Telemetry::quotas();
        $this->assertCount(6,$quotas['observations'][0]['observations']);
        $this->assertSame([],McpRedactionRule::masked_paths(['quota_observations'=>$quotas]));
        // The rule itself accuses the old names.
        $this->assertTrue(McpRedactionRule::sensitive_field('token_requests',3));
        $this->assertTrue(McpRedactionRule::sensitive_field('tokensPerDay',['consumed'=>1]));
    }
    public function test_legacy_token_requests_buckets_are_summed_into_auth_requests(): void {
        $hour=(int)(floor(time()/3600)*3600);
        $base=['connection_id'=>'default','apis'=>[]];
        $this->assertTrue(Records::put('telemetry','default_'.($hour-3600),$base+['created_at'=>$hour-3600,'expires_at'=>$hour+24*3600,'counters'=>['http_attempts'=>3,'token_requests'=>3]])['success']);
        $this->assertTrue(Records::put('telemetry','default_'.$hour,$base+['created_at'=>$hour,'expires_at'=>$hour+25*3600,'counters'=>['http_attempts'=>2,'auth_requests'=>2]])['success']);
        $state=Telemetry::state();
        $this->assertSame(5,$state['counters']['auth_requests']??null,json_encode($state['counters']));
        $this->assertSame(5,$state['counters']['http_attempts']);
        $this->assertArrayNotHasKey('token_requests',$state['counters']);
        // Stored buckets are read, never rewritten.
        $this->assertSame(3,Records::get('telemetry','default_'.($hour-3600))['counters']['token_requests']);
    }
    public function test_other_fixed_output_names_pass_the_redaction_rule(): void {
        $cleanup=\Fator3\McpGoogle\Automation\Executor::cleanup(['dry_run'=>true]);
        $this->assertTrue($cleanup['success'],json_encode($cleanup));
        $this->assertSame([],McpRedactionRule::masked_paths($cleanup));
        $this->assertSame(100,$cleanup['max_records_per_run']);
        $plan=\Fator3\McpGoogle\Template::plan(['template'=>['schema_version'=>'1.0.0','services'=>['gtm'=>'write']]]);
        $this->assertTrue($plan['success'],json_encode($plan));
        $this->assertSame([],McpRedactionRule::masked_paths($plan));
        $this->assertFalse($plan['confidential_promoted']);
    }
}
