<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{ContractSchema,Options,Plugin,Connections};
use Fator3\McpGoogle\Unified\{Abilities,StatusSchema};
final class Release090StatusTest extends TestCase {
    protected function setUp(): void {$GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;FakeHttp::reset();Options::set(Options::ENABLED,true);Plugin::register_abilities();}
    private function covered($value,array $schema,string $path='root'): void {
        if(!is_array($value))return;
        if(isset($schema['anyOf'])){foreach($schema['anyOf'] as $branch)if(ContractSchema::valid($value,$branch)){$this->covered($value,$branch,$path);return;}}
        if(isset($schema['items'])){foreach($value as $i=>$v)$this->covered($v,$schema['items'],$path.'.'.$i);return;}
        foreach($value as $key=>$v){$child=$schema['properties'][$key]??($schema['additionalProperties']??null);$this->assertIsArray($child,'Undocumented '.$path.'.'.$key);$this->covered($v,$child,$path.'.'.$key);}
    }
    public function test_selected_and_all_connection_fields_have_types_and_coverage(): void {
        foreach([[],['scope'=>'all_connections']] as $input){$r=Abilities::status($input);$this->assertTrue(ContractSchema::valid($r,StatusSchema::schema()),json_encode($r));$this->covered($r,StatusSchema::schema());}
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_storage_and_cache_schema_reuse_and_negative_type(): void {
        $r=wp_get_ability('google/storage-status')->execute([]);$schema=wp_get_ability('google/storage-status')->get_output_schema();$this->assertTrue(ContractSchema::valid($r,$schema));
        $this->assertSame($schema['properties']['storage'],StatusSchema::schema()['properties']['storage']);
        $bad=$r;$bad['storage']['ready']='true';$this->assertFalse(ContractSchema::valid($bad,$schema));
        $GLOBALS['f3_test_record_read_fail']=true;$r=Abilities::status([]);$this->assertFalse($r['storage']['ready']);$this->assertTrue(ContractSchema::valid($r,StatusSchema::schema()),json_encode($r));$this->covered($r,StatusSchema::schema());
    }
    public function test_missing_credentials_are_not_remote_failure_or_hidden_token_test(): void {
        $r=Abilities::status([]);$this->assertTrue($r['success']);$this->assertFalse($r['auth']['configured']);$this->assertArrayNotHasKey('auth_probe',$r);
        $this->assertFalse(Abilities::status(['scope'=>'all_connections','live'=>true])['success']);$this->assertSame(0,FakeHttp::count());
    }
}
