'use strict';
/*
 * Reusable full-page screenshot + layout measurement of the Google admin screen.
 * Not an acceptance gate: it records facts (overflow, console/JS errors) for review.
 * Input (stdin JSON, written by tests/native/screens032.php):
 *   {url, cookies, out, connection_id|null, root_selector}
 * Environment:
 *   F3_CHROMIUM            browser executable (default /usr/bin/chromium)
 *   F3_SCREENS_PAGES       optional path to JSON [{section, panel?, method?, name?}] replacing the default list
 *   F3_SCREENS_VIEWPORTS   optional "1440x900,390x844"
 * Output: <out>/<width>/<name>.png, <out>/screens.json; stdout = summary JSON.
 * Page identity comes only from URL parameters; no assertion depends on visible text.
 */
const { chromium } = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const rootUrl = new URL(input.url);
if (rootUrl.hostname !== '127.0.0.1') throw new Error('Laboratory URL required');

const DEFAULT_PAGES = [
  { section: 'overview' },
  { section: 'connection', panel: 'identity', method: 'service_account' },
  { section: 'connection', panel: 'identity', method: 'oauth' },
  { section: 'connection', panel: 'services' },
  { section: 'connection', panel: 'permissions' },
  { section: 'conversions' },
  { section: 'archive' },
  { section: 'gsc' },
  { section: 'gtm' },
  { section: 'incidents' },
  { section: 'advanced', panel: 'limits' },
  { section: 'advanced', panel: 'diagnostics' },
  { section: 'advanced', panel: 'operations' },
  { section: 'advanced', panel: 'templates' },
  { section: 'advanced', panel: 'credentials' },
  { section: 'advanced', panel: 'contract' },
  { section: 'help' },
];
// F3_SCREENS_ENFORCE=0 records the criteria without failing (used to measure the 0.31.0 base).
const ENFORCE = process.env.F3_SCREENS_ENFORCE !== '0';
const MOBILE_MAX = 600;
const pages = process.env.F3_SCREENS_PAGES ? JSON.parse(fs.readFileSync(process.env.F3_SCREENS_PAGES, 'utf8')) : DEFAULT_PAGES;
const viewports = (process.env.F3_SCREENS_VIEWPORTS || '1440x900,390x844').split(',').map(v => {
  const [width, height] = v.trim().split('x').map(Number);
  if (!width || !height) throw new Error('Invalid viewport ' + v);
  return { width, height };
});
const panelKey = section => section === 'connection' ? 'connection_panel' : section === 'advanced' ? 'advanced_panel' : null;
const nameOf = p => p.name || [p.section, p.panel, p.method].filter(Boolean).join('-');
const urlOf = p => {
  const url = new URL('/wp-admin/tools.php', input.url);
  const q = { page: 'wp-mcp-google-fator3', section: p.section };
  if (input.connection_id) q.connection_id = input.connection_id;
  if (p.panel && panelKey(p.section)) q[panelKey(p.section)] = p.panel;
  if (p.method) q.method = p.method;
  url.search = new URLSearchParams(q).toString();
  return url.href;
};

// Runs inside the page: document/viewport widths and elements that leave the viewport or clip content.
function measure(rootSelector) {
  const vw = document.documentElement.clientWidth;
  const describe = el => {
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    else if (typeof el.className === 'string' && el.className.trim()) s += '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.');
    const parent = el.closest('[id]');
    return parent && parent !== el ? '#' + parent.id + ' ' + s : s;
  };
  const visible = el => {
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const scope = document.querySelector('#wpbody-content') || document.body;
  const beyond = [], clipped = [];
  for (const el of scope.querySelectorAll('*')) {
    if (!visible(el)) continue;
    const r = el.getBoundingClientRect();
    // Ignore elements inside a horizontally scrollable ancestor: their overflow is contained.
    let contained = false;
    for (let a = el.parentElement; a && a !== scope; a = a.parentElement) {
      const ox = getComputedStyle(a).overflowX;
      if (ox === 'auto' || ox === 'scroll' || ox === 'hidden' || ox === 'clip') { contained = true; break; }
    }
    if (!contained && (r.right > vw + 1 || r.left < -1)) beyond.push({ el: describe(el), left: Math.round(r.left), right: Math.round(r.right), width: Math.round(r.width) });
    const ox = getComputedStyle(el).overflowX;
    if (el.scrollWidth > el.clientWidth + 1 && el.clientWidth > 0 && (ox === 'visible')) clipped.push({ el: describe(el), scroll: el.scrollWidth, client: el.clientWidth });
  }
  // Report only the outermost offenders first; counts include all.
  const root = rootSelector ? document.querySelector(rootSelector) : null;
  const rr = root ? root.getBoundingClientRect() : null;
  return {
    document_width: document.documentElement.scrollWidth,
    viewport_width: vw,
    horizontal_overflow: document.documentElement.scrollWidth > vw + 1,
    document_height: document.documentElement.scrollHeight,
    root_found: Boolean(root),
    root: root ? { scroll_width: root.scrollWidth, client_width: root.clientWidth, right: Math.round(rr.right) } : null,
    elements_beyond_viewport: beyond.length,
    elements_with_content_overflow: clipped.length,
    beyond_sample: beyond.slice(0, 12),
    overflow_sample: clipped.slice(0, 12),
  };
}

// Runs inside the page: automatic acceptance criteria (0.32.0) and the form inventory.
function audit(rootSelector) {
  const root = document.querySelector(rootSelector) || document.body;
  const shown = el => {
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const unlabelled = [];
  for (const el of root.querySelectorAll('input, select, textarea')) {
    if (el.type === 'hidden' || el.type === 'submit' || el.type === 'button' || !shown(el)) continue;
    const named = (el.labels && el.labels.length > 0) || (el.getAttribute('aria-label') || '').trim() !== '' || (el.getAttribute('aria-labelledby') || '').trim() !== '';
    if (!named) unlabelled.push((el.name || el.id || el.tagName).slice(0, 80));
  }
  const navs = [...root.querySelectorAll('nav')];
  const primary = root.querySelector('nav[aria-label="Configuração Google"]');
  const tops = primary ? [...primary.querySelectorAll('a')].map(a => Math.round(a.getBoundingClientRect().top)) : [];
  const forms = [...root.querySelectorAll('form')].map(form => {
    const method = (form.getAttribute('method') || 'get').toLowerCase();
    const hiddenAction = form.querySelector('input[type="hidden"][name="action"]');
    let action;
    if (hiddenAction) action = hiddenAction.value;
    else if (method === 'get') action = 'get:' + new URL(form.action, location.href).pathname;
    else action = 'post:' + (form.getAttribute('action') ? new URL(form.action, location.href).pathname : 'self');
    const skip = new Set(['_wpnonce', '_wp_http_referer']);
    const names = [...new Set([...form.elements].map(e => e.name).filter(n => n && !skip.has(n)))].sort();
    // Values that select the operation inside a shared action (never secrets or nonces).
    const disc = [];
    for (const e of form.elements) {
      if (!e.name) continue;
      if ((e.type === 'hidden' && ['operation', 'archive_operation', 'recovery_action', 'service', 'auth_mode', 'choice_kind'].includes(e.name))
        || ((e.tagName === 'BUTTON' || e.type === 'submit') && e.value !== '')) disc.push(e.name + '=' + e.value);
    }
    return { action, method, discriminator: [...new Set(disc)].sort(), fields: names };
  });
  const firstCard = root.querySelector('main .f3-card, .f3-card');
  return {
    first_card_top: firstCard ? Math.round(firstCard.getBoundingClientRect().top + scrollY) : null,
    h1_count: document.querySelectorAll('h1').length,
    unlabelled_fields: unlabelled,
    nav_count: navs.length,
    nav_without_label: navs.filter(n => !(n.getAttribute('aria-label') || n.getAttribute('aria-labelledby'))).length,
    primary_nav_found: Boolean(primary),
    primary_nav_rows: new Set(tops).size,
    primary_current: primary ? primary.querySelectorAll('[aria-current="page"]').length : 0,
    forms,
  };
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.F3_CHROMIUM || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const results = [];
  const inventory = {};
  try {
    for (const vp of viewports) {
      const dir = path.join(input.out, String(vp.width));
      fs.mkdirSync(dir, { recursive: true });
      const ctx = await browser.newContext({ viewport: vp, reducedMotion: 'reduce' });
      await ctx.route('**/*', route => {
        const u = new URL(route.request().url());
        if (u.origin === rootUrl.origin || u.protocol === 'data:') return route.continue();
        return route.abort();
      });
      await ctx.addCookies(Object.entries(input.cookies).map(([name, value]) => ({ name, value, url: input.url })));
      for (const p of pages) {
        const page = await ctx.newPage();
        page.setDefaultTimeout(60000);
        const consoleErrors = [], jsErrors = [], failed = [];
        page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text()); });
        page.on('pageerror', e => jsErrors.push(e.message));
        page.on('requestfailed', r => { const u = new URL(r.url()); failed.push({ url: r.url(), external: u.origin !== rootUrl.origin, error: (r.failure() || {}).errorText }); });
        const url = urlOf(p);
        const response = await page.goto(url, { waitUntil: 'load' });
        await page.waitForLoadState('networkidle').catch(() => {});
        const file = path.join(dir, nameOf(p) + '.png');
        const m = await page.evaluate(measure, input.root_selector || null);
        const a = await page.evaluate(audit, input.root_selector || '.f3-google');
        await page.screenshot({ path: file, fullPage: true });
        const final = new URL(page.url());
        // Only the deliberately blocked avatar request may fail; any other failure counts.
        const ignored = failed.filter(f => f.external && /(^|\.)gravatar\.com$/.test(new URL(f.url).hostname));
        const otherConsole = consoleErrors.length - ignored.length;
        const violations = [];
        if (m.document_width > m.viewport_width) violations.push('horizontal overflow ' + m.document_width + '>' + m.viewport_width);
        if (jsErrors.length) violations.push('JS errors: ' + jsErrors.join(' | '));
        if (otherConsole > 0 || failed.length > ignored.length) violations.push('console/request errors: ' + JSON.stringify({ consoleErrors, failed }));
        if (a.h1_count !== 1) violations.push('h1 count ' + a.h1_count);
        if (a.unlabelled_fields.length) violations.push('unlabelled fields: ' + a.unlabelled_fields.join(', '));
        if (a.nav_without_label) violations.push(a.nav_without_label + ' nav without aria-label');
        if (!a.primary_nav_found || a.primary_current !== 1) violations.push('primary navigation missing or without one aria-current');
        if (vp.width <= MOBILE_MAX && a.primary_nav_rows !== 1) violations.push('mobile primary navigation in ' + a.primary_nav_rows + ' rows');
        if (vp === viewports[0]) inventory[nameOf(p)] = { url: final.pathname + final.search, forms: a.forms };
        results.push({ name: nameOf(p), viewport: vp.width + 'x' + vp.height, url: url.replace(input.url, ''), final_url: final.pathname + final.search, status: response ? response.status() : null, screenshot: file, ...m, audit: { ...a, forms: a.forms.length }, violations, console_errors: consoleErrors, js_errors: jsErrors, failed_requests: failed });
        await page.close();
      }
      await ctx.close();
    }
    const summary = {
      browser: browser.version(), playwright: require('playwright/package.json').version,
      pages: pages.length, viewports: viewports.map(v => v.width + 'x' + v.height), screenshots: results.length,
      with_horizontal_overflow: results.filter(r => r.horizontal_overflow).map(r => r.viewport + ' ' + r.name),
      with_elements_beyond_viewport: results.filter(r => r.elements_beyond_viewport).map(r => r.viewport + ' ' + r.name),
      with_js_errors: results.filter(r => r.js_errors.length).map(r => r.viewport + ' ' + r.name),
      // Console errors other than the ones produced by external requests the lab blocks on purpose.
      with_console_errors_not_from_blocked_external: results.filter(r => r.console_errors.length > r.failed_requests.filter(f => f.external).length).map(r => r.viewport + ' ' + r.name),
      blocked_external_origins: [...new Set(results.flatMap(r => r.failed_requests.filter(f => f.external).map(f => new URL(f.url).origin)))],
      failed_same_origin_requests: results.flatMap(r => r.failed_requests.filter(f => !f.external).map(f => r.viewport + ' ' + r.name + ' ' + f.url)),
      non_200: results.filter(r => r.status !== 200).map(r => r.viewport + ' ' + r.name + ' ' + r.status),
      enforce: ENFORCE,
      criteria: ['scrollWidth <= viewport', 'no JS error', 'no console/request error except blocked gravatar', 'exactly one h1', 'every visible input/select/textarea labelled', 'every nav labelled', 'primary nav with one aria-current', 'primary nav in one row at width <= ' + MOBILE_MAX],
      pages_checked: results.length,
      violations: results.filter(r => r.violations.length).map(r => ({ page: r.viewport + ' ' + r.name, violations: r.violations })),
    };
    fs.writeFileSync(path.join(input.out, 'screens.json'), JSON.stringify({ summary, results }, null, 2) + '\n');
    fs.writeFileSync(path.join(input.out, 'forms.json'), JSON.stringify({ viewport: viewports[0].width + 'x' + viewports[0].height, pages: inventory }, null, 2) + '\n');
    console.log(JSON.stringify(summary));
  } finally { await browser.close(); }
})().catch(error => { console.error(error.stack); process.exitCode = 1; });
