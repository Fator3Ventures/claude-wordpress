'use strict';
const run = require('./admin-browser.cjs');

async function checkDiagnostics({page, root, check, input}) {
  const form = root.getByRole('form', {name: 'Teste de acessos da conexão'});
  const help = await form.getAttribute('aria-describedby');
  check('Diagnostic form points to visible guidance', !!help && await root.locator('#'+help).isVisible());
  const result = root.getByRole('region', {name: 'Resultado da última verificação'});
  check('Diagnostic result starts empty', await result.getByText('Nenhum resultado disponível', {exact:false}).isVisible());
  const nav = root.getByRole('navigation', {name: 'Preparar o teste'});
  const links = await nav.getByRole('link').evaluateAll(nodes => nodes.map(node => new URL(node.href).searchParams.get('connection_id')));
  check('Diagnostic preparation links keep the selected connection', links.length === 2 && links.every(id=>id==='browserqa'));
  await form.getByRole('button', {name: 'Testar acessos agora'}).click();
  await page.waitForURL(url => url.searchParams.has('f3_status'));
  const verdict = result.locator(':scope > p > .f3-state');
  await verdict.waitFor();
  check('Diagnostic POST shows a result for the selected connection', await verdict.innerText() === 'Incompleto' && new URL(page.url()).searchParams.get('connection_id')==='browserqa');
  const local = result.locator('details').filter({has:page.locator('summary',{hasText:'Verificações locais do plugin'})});
  check('Local checks are initially collapsed', await local.count()===1 && !await local.evaluate(node=>node.open));
  await local.locator('summary').click();
  check('An administrator can open the local checks', await local.evaluate(node=>node.open));
  await page.screenshot({path:input.scratch+'/diagnostics-desktop.png'});
}

run(checkDiagnostics).catch(error => { console.error(error.stack); process.exitCode = 1; });
