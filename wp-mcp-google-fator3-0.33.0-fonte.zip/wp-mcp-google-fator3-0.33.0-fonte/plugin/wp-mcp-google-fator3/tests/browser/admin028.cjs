'use strict';
require('./admin-browser.cjs')().catch(error => { console.error(error.stack); process.exitCode = 1; });
