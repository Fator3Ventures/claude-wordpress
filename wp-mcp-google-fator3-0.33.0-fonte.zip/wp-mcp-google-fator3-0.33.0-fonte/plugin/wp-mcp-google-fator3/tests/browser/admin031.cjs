'use strict';
const run = require('./admin-browser.cjs');
async function checkPlanner({page,root,check,input}) {
  const url=new URL(page.url());url.searchParams.set('section','connection');url.searchParams.set('connection_panel','services');url.searchParams.delete('advanced_panel');
  await page.goto(url.href);
  const card=root.getByRole('region',{name:'Acesso ao Google Ads',exact:true});
  const help=card.getByRole('complementary',{name:'Conferir o Planejador pelo MCP'});
  check('Ads configuration has named region and diagnostic group',await card.isVisible()&&await help.isVisible());
  check('MCP diagnosis is positioned after the save form',await help.evaluate(el=>el.previousElementSibling.tagName==='FORM'));
  check('Level description distinguishes declaration from Google verification',await card.locator('#f3-ads-level-help').innerText().then(t=>t.includes('Test exige conta de teste')&&t.includes('Explorer e Não informado')&&t.includes('salvar não comprova acesso')));
  check('Planner help explains five routes and disabled connector diagnosis',await help.innerText().then(t=>t.includes('cinco operações')&&t.includes('Ads desligado')&&t.includes('PLANEJADOR.md')));
  const selector=card.locator('#f3-ads-level');await selector.focus();
  check('Level selector accepts keyboard focus',await selector.evaluate(el=>el===document.activeElement));
  for(const width of [1440,390]){
    await page.setViewportSize({width,height:width===390?844:900});
    check('Ads description fits viewport '+width,await card.evaluate(el=>el.scrollWidth<=el.clientWidth+2&&el.getBoundingClientRect().right<=innerWidth+2));
    check('Planner help follows fields vertically '+width,await help.evaluate(el=>el.getBoundingClientRect().top>=el.previousElementSibling.getBoundingClientRect().bottom));
    await card.screenshot({path:input.scratch+'/planner-'+width+'.png'});
  }
  await page.setViewportSize({width:1440,height:900});
}
run(checkPlanner).catch(error=>{console.error(error.stack);process.exitCode=1;});
