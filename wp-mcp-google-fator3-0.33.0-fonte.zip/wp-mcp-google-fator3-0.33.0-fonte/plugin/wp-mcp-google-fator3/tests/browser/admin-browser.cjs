'use strict';
const { chromium } = require('playwright');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const rootUrl = new URL(input.url);
assert.equal(rootUrl.hostname, '127.0.0.1');
const checks = [];
const check = (name, pass) => { assert.ok(pass, name); checks.push(name); };
const browserErrors = [];
const pageUrl = (section, more = {}) => {
  const url = new URL('/wp-admin/tools.php', input.url);
  url.search = new URLSearchParams({ page: 'wp-mcp-google-fator3', connection_id: 'browserqa', section, ...more }).toString();
  return url.href;
};

async function contextFor(browser, cookies, options = {}) {
  // Use the supported reduced-motion preference so rapid test navigation does not
  // interrupt WordPress core's cross-document view transitions.
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce', ...options });
  await ctx.route('**/*', route => {
    const url = new URL(route.request().url());
    return url.origin === rootUrl.origin || url.protocol === 'data:' ? route.continue() : route.abort();
  });
  await ctx.addCookies(Object.entries(cookies).map(([name,value]) => ({ name, value, url: input.url })));
  const page = await ctx.newPage();
  page.on('pageerror', e => browserErrors.push(e.message));
  page.setDefaultTimeout(60000);
  return { ctx, page };
}

async function run(checkDiagnostics) {
  const browser = await chromium.launch({ executablePath: process.env.F3_CHROMIUM || '/usr/bin/chromium', headless:true, args:['--no-sandbox','--disable-dev-shm-usage'] });
  try {
    const { ctx, page } = await contextFor(browser, input.cookies);
    await page.goto(pageUrl('connection'));
    const root = page.locator('.f3-google');
    check('WordPress tools screen renders selected connection', await root.locator('#f3-connection').inputValue() === 'browserqa');
    check('Local script and scoped stylesheet loaded', await root.evaluate(el => el.classList.contains('f3-js') && getComputedStyle(el.querySelector('.f3-subnav')).display==='flex'));
    check('Only identity setup shown by default', await root.getByRole('heading',{name:'Autenticação',exact:true}).isVisible() && await root.locator('[name="services_present"]').count()===0);
    await root.locator('.f3-subnav').getByRole('link',{name:'Serviços e recursos',exact:true}).click();
    await page.locator('.f3-google.f3-js').waitFor();
    check('Services tab keeps connection', new URL(page.url()).searchParams.get('connection_id')==='browserqa');
    check('Services tab avoids authentication form', await root.locator('[name="sa_json"]').count()===0);
    check('Level field exposes its help to assistive technology', await root.locator('#f3-ads-level').getAttribute('aria-describedby')==='f3-ads-level-help');
    const ads=root.locator('#f3-service-ads'), binding=root.locator('[name="ads_customer_id"]');
    await ads.selectOption('');
    check('Service disabled hides and disables its binding', await binding.isDisabled() && await binding.isHidden());
    await ads.selectOption('read');
    check('Re-enabling restores saved selection', await binding.isEnabled() && await binding.inputValue()==='1234567890');
    // Intentional navigation after changing a selection.
    page.on('dialog', dialog=>dialog.accept());
    await root.getByRole('link',{name:'Verificar acessos em Diagnóstico'}).click();
    await root.getByRole('heading',{name:'Verificar a conexão',exact:true}).waitFor();
    check('Diagnostic deep link opens the diagnostic panel', await root.getByRole('heading',{name:'Verificar a conexão',exact:true}).isVisible());
    check('Diagnostic deep link preserves context',new URL(page.url()).searchParams.get('connection_id')==='browserqa');
    if (checkDiagnostics) { await checkDiagnostics({ page, root, check, input }); }
    await page.goto(pageUrl('connection'));
    await root.locator('details').filter({has:page.locator('summary',{hasText:'Nome da conexão'})}).locator('summary').first().click();
    await root.locator('[name="connection_label"]').fill('Nome editado no navegador');
    await root.getByRole('button',{name:'Salvar nome',exact:true}).click();
    await page.waitForURL(/f3_status=/);
    check('Real POST returns to same identity panel and connection', new URL(page.url()).searchParams.get('connection_panel')==='identity'&&new URL(page.url()).searchParams.get('connection_id')==='browserqa');
    check('Rename persisted after reload',(await root.locator('#f3-connection option:checked').innerText()).includes('Nome editado no navegador'));
    await page.goto(pageUrl('archive'));
    check('Archive opens existing account with correct saved windows', await root.locator('#archive_backfill').inputValue()==='45'&&await root.locator('#archive_revisit').inputValue()==='3');
    check('Archive selected datasets are exact', await root.locator('form:has(#archive_backfill) input[name="archive_datasets[]"]:checked').count()===1);
    check('Account ID is read-only while editing',await root.locator('form:has(#archive_backfill) [name="archive_account"]').getAttribute('readonly')!==null);
    await root.locator('#f3-archive-account').selectOption('new');
    await root.getByRole('button',{name:'Abrir conta'}).click();
    check('New collection starts paused',!(await root.locator('form:has(#archive_backfill) input[name="archive_enabled"]').isChecked()));
    await page.goto(pageUrl('conversions'));
    check('Independent GA4 and Ads lookup buttons available',await root.getByRole('button',{name:'Consultar propriedades e fluxos'}).isVisible()&&await root.getByRole('button',{name:'Consultar contas e ações'}).isVisible());
    check('GA4 and Ads use labelled fieldsets',await root.locator('.f3-destinations fieldset > legend').count()===2);
    // Structured profiles have reversible row edits and unique labels.
    const group=root.locator('[data-profile-rows]').first();
    for (const node of await group.locator('xpath=ancestor::details').all()) { await node.evaluate(el=>el.open=true); }
    const count=await group.locator(':scope > .f3-profile-row').count();
    await group.locator(':scope > [data-add-profile-row]').click();
    check('Add GA4 profile row sets focus and distinct names',await group.locator(':scope > .f3-profile-row').count()===count+1 && await group.locator(':scope > .f3-profile-row').last().evaluate(el=>el.contains(document.activeElement)));
    const duplicate=await group.evaluate(el=>{const names=[...el.querySelectorAll('input,select')].map(f=>f.name);return new Set(names).size!==names.length;});
    check('Dynamic GA4 profile row names are unique',!duplicate);
    await group.locator(':scope > .f3-profile-row').last().locator(':scope > [data-remove-row]').click();
    check('Remove GA4 profile row restores original count',await group.locator(':scope > .f3-profile-row').count()===count);
    await page.goto(pageUrl('connection',{connection_panel:'services'}));
    await page.screenshot({path:input.scratch+'/desktop-private.png'});
    await page.setViewportSize({width:390,height:844});
    for (const section of ['connection','conversions','archive','gsc','gtm','incidents','advanced','diagnostics']) {
      await page.goto(pageUrl(section,section==='connection'?{connection_panel:'services'}:{}));
      const overflow=await root.evaluate(el=>{const bound=el.getBoundingClientRect();return {inner:el.scrollWidth,width:el.clientWidth,right:bound.right,viewport:innerWidth};});
      check('Mobile content fits viewport on '+section, overflow.inner <= overflow.width + 2 && overflow.right <= overflow.viewport + 2);
      if (section === 'diagnostics' && checkDiagnostics) {
        await page.screenshot({path:input.scratch+'/diagnostics-mobile.png'});
      }
    }
    await page.goto(pageUrl('archive'));
    await page.screenshot({path:input.scratch+'/mobile-private.png'});
    await ctx.close();

    const nojs=await contextFor(browser,input.cookies,{javaScriptEnabled:false});
    await nojs.page.goto(pageUrl('services'));
    const form=nojs.page.locator('form:has([name="services_present"])');
    await form.locator('#f3-service-ads').selectOption('');
    await form.getByRole('button',{name:'Revisar alterações'}).click();
    await nojs.page.waitForURL(url => url.pathname.endsWith('/admin-post.php'));
    check('No-JS service preview uses normal WordPress POST',new URL(nojs.page.url()).pathname.endsWith('/admin-post.php') && await nojs.page.locator('[name="connection_id"]').inputValue()==='browserqa');
    const confirm=nojs.page.locator('form:has([name="configuration_intent"])');
    check('No-JS review offers confirmation bound to this intent',await confirm.count()===1);
    const agree=confirm.locator('[name="confirm_service_reduction"]');
    if (await agree.getAttribute('type')==='checkbox') await agree.check();
    await confirm.locator('button[type="submit"],button').last().click();
    await nojs.page.waitForURL(url => url.searchParams.get('connection_panel') === 'services');
    check('No-JS form returns to the same service panel after applying',new URL(nojs.page.url()).searchParams.get('connection_panel')==='services');
    check('No-JS reduction persisted in the selected connection',await nojs.page.locator('#f3-service-ads').inputValue()==='');
    await nojs.ctx.close();
    const limited=await contextFor(browser,input.subscriber);
    const denied=await limited.page.goto(pageUrl('connection'));
    check('Subscriber is denied the administrative page',denied.status()===403 && await limited.page.locator('.f3-google').count()===0);
    await limited.ctx.close();
    if (browserErrors.length) { throw Error('Page errors: '+JSON.stringify(browserErrors)); }
    check('No JavaScript page errors',true);
    console.log(JSON.stringify({checks,browser:browser.version(),viewports:['1440x900','390x844']}));
  } finally { await browser.close(); }
}
module.exports = run;
