'use strict';
// Render the HTML returned by WordPress and run the exact packaged admin.js.
const { JSDOM, VirtualConsole } = require('jsdom');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const origin = new URL(input.url);
assert.equal(origin.hostname,'127.0.0.1');
const checks=[];
const pass=(name,value)=>{assert.ok(value,name);checks.push(name);};
const js=fs.readFileSync(path.join(__dirname,'../../assets/admin.js'),'utf8');
const cookie=Object.entries(input.cookies).map(([k,v])=>k+'='+v).join('; ');
const url=(section,extra={})=>input.url+'/wp-admin/tools.php?'+new URLSearchParams({page:'wp-mcp-google-fator3',connection_id:'browserqa',section,...extra});
async function documentAt(target,init={},exec=true,auth=cookie) {
  const res=await fetch(target,{...init,headers:{cookie:auth,...init.headers}});
  const consoleDOM=new VirtualConsole();
  const dom=new JSDOM(await res.text(),{url:res.url,runScripts:'outside-only',pretendToBeVisual:true,virtualConsole:consoleDOM});
  if(exec)dom.window.eval(js);
  return {dom,doc:dom.window.document,href:res.url,code:res.status};
}
async function submit(form,button,exec=true,override={}) {
  const win=form.ownerDocument.defaultView;
  const data=new URLSearchParams([...new win.FormData(form)]);
  if(button?.name) data.set(button.name,button.value);
  for(const [key,value] of Object.entries(override))data.set(key,value);
  return documentAt(form.action,{method:'POST',body:data},exec);
}
const get=(doc,selector)=>{const e=doc.querySelector(selector);assert.ok(e,selector);return e;};
async function main() {
  let view=await documentAt(url('connection'));
  pass('HTTP admin is authenticated',view.code===200 && get(view.doc,'.f3-google').classList.contains('f3-js'));
  pass('Active identity tab is explicit',get(view.doc,'nav[aria-label="Configurações da conexão"] [aria-current]').textContent==='Identidade');
  pass('Identity tab does not render the other settings forms',!view.doc.querySelector('[name="services_present"]'));
  const name=get(view.doc,'[name="connection_label"]');name.value='Nome editado no navegador';
  view=await submit(name.form);
  pass('Rename performs canonical scoped redirect',new URL(view.href).searchParams.get('connection_id')==='browserqa' && new URL(view.href).searchParams.get('connection_panel')==='identity');
  pass('New label persisted',get(view.doc,'#f3-connection option:checked').textContent.includes('Nome editado no navegador'));

  view=await documentAt(url('services'));
  pass('Services alias opens services tab',get(view.doc,'nav[aria-label="Configurações da conexão"] [aria-current]').textContent==='Serviços e recursos');
  const service=get(view.doc,'#f3-service-ads'),account=get(view.doc,'[name="ads_customer_id"]');
  service.value=''; service.dispatchEvent(new view.dom.window.Event('change',{bubbles:true}));
  pass('Deactivated service hides bindings',account.disabled && account.closest('[data-service-fields]').hidden);
  service.value='read';service.dispatchEvent(new view.dom.window.Event('change',{bubbles:true}));
  pass('Enabled service restores binding',!account.disabled && account.value==='1234567890');
  const level=get(view.doc,'#f3-ads-level');
  pass('Ads field links its explanation',!!view.doc.getElementById(level.getAttribute('aria-describedby')));
  const diag=[...view.doc.querySelectorAll('.f3-google a')].find(a=>a.textContent.includes('Verificar acessos em Diagnóstico'));
  view=await documentAt(diag.href);
  pass('Diagnostic link retains selected connection and opens diagnosis',new URL(view.href).searchParams.get('connection_id')==='browserqa' && !![...view.doc.querySelectorAll('h2')].find(x=>x.textContent==='Verificar a conexão'));

  view=await documentAt(url('archive'));
  const collection=get(view.doc,'[name="archive_operation"][value="collection"]').form;
  pass('Existing Ads account renders persisted windows and datasets',collection.elements.archive_backfill.value==='45' && collection.elements.archive_revisit.value==='3' && collection.querySelectorAll('[name="archive_datasets[]"]:checked').length===1);
  const existingId=collection.elements.archive_account.value;
  view=await documentAt(url('archive',{archive_account:'new'}));
  const fresh=get(view.doc,'[name="archive_operation"][value="collection"]').form;
  pass('New archive form has explicit new target and no active grant',fresh.elements.archive_target.value==='new'&&!fresh.elements.archive_enabled.checked);
  fresh.elements.archive_account.value=existingId;
  view=await submit(fresh);
  pass('Existing account cannot be overwritten as new',view.doc.body.textContent.includes('já tem configuração'));
  view=await documentAt(url('archive',{archive_account:existingId}));
  pass('Attempt to overwrite existing account preserved its windows',get(view.doc,'#archive_backfill').value==='45'&&get(view.doc,'#archive_revisit').value==='3');

  view=await documentAt(url('conversions'));
  const fieldsets=view.doc.querySelectorAll('.f3-destinations fieldset');
  pass('Two destination groups have distinct legends',fieldsets.length===2 && fieldsets[0].querySelector('legend').textContent==='Google Analytics 4' && fieldsets[1].querySelector('legend').textContent==='Google Ads');
  pass('Lookup actions scoped to each destination',!!view.doc.querySelector('button[value="resources-ga"]')&&!!view.doc.querySelector('button[value="resources-ads"]'));
  const group=get(view.doc,'[data-profile-rows]');
  const add=get(group,':scope > [data-add-profile-row]');
  const count=group.querySelectorAll(':scope > .f3-profile-row').length;add.click();
  let rows=group.querySelectorAll(':scope > .f3-profile-row');
  pass('GA4 add row appended and focused',rows.length===count+1 && rows[rows.length-1].contains(view.doc.activeElement));
  const names=[...group.querySelectorAll('input,select')].map(x=>x.name);
  pass('GA4 array names are unique after append',new Set(names).size===names.length);
  pass('Dynamic labels identify their field',Array.from(rows[rows.length-1].querySelectorAll('label[for]')).every(l=>l.control && l.control.id===l.htmlFor));
  const dirty=new view.dom.window.Event('beforeunload',{cancelable:true});view.dom.window.dispatchEvent(dirty);
  pass('Editing a profile row marks the form as unsaved',dirty.defaultPrevented);
  get(rows[rows.length-1],':scope > [data-remove-row]').click();
  pass('Removing a row restores previous row count',group.querySelectorAll(':scope > .f3-profile-row').length===count);
  for (const section of ['connection','conversions','archive','gsc','gtm','incidents','advanced']) {
    view=await documentAt(url(section),{},false);
    const root=get(view.doc,'.f3-google');
    const orphan=[...root.querySelectorAll('label[for]')].filter(l=>!l.control);
    pass('Labels resolve on '+section,orphan.length===0);
    pass('Top navigation highlights '+section,root.querySelectorAll('nav.f3-navigation [aria-current="page"]').length===1);
  }

  // With JavaScript disabled, even hidden controls can be included in the POST.
  view=await documentAt(url('services'),{},false);
  const form=get(view.doc,'[name="services_present"]').form;
  form.elements['services[ads]'].value='';
  form.elements.ads_customer_id.value=''; // stale browser field must not clear the saved binding.
  view=await submit(form,get(form,'[name="preview_configuration"]'),false);
  const intent=get(view.doc,'[name="configuration_intent"]').form;
  pass('Native no-JS preview contains a guarded intent',view.code===200 && JSON.parse(intent.elements.configuration_intent.value).expected_plan_hash);
  pass('Preview retains target context',intent.elements.connection_id.value==='browserqa'&&intent.elements.connection_panel.value==='services');
  view=await submit(intent,null,false);
  pass('No-JS apply opens the services panel',new URL(view.href).searchParams.get('connection_panel')==='services');
  pass('Applied reduction persisted',get(view.doc,'#f3-service-ads').value==='');
  const subscriber=Object.entries(input.subscriber).map(([k,v])=>k+'='+v).join('; ');
  view=await documentAt(url('connection'),{},false,subscriber);
  pass('Subscriber denied the WordPress tools screen',view.code===403&&!view.doc.querySelector('.f3-google'));
  console.log(JSON.stringify({checks,engine:'jsdom '+require('jsdom/package.json').version,http:true}));
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
