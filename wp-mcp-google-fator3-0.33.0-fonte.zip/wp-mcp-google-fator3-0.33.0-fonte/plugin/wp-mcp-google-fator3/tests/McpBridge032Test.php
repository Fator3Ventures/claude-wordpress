<?php
/**
 * Ponte google/mcp-write: onde chegam confirmation_token e idempotency_key do nível da ferramenta.
 *
 * Exercita uma escrita sensível real do catálogo (gsc/delete-site, DELETE) preparada por
 * google/prepare-operation e executada pela habilidade google/mcp-write, contando pelo
 * FakeHttp as requisições de escrita que chegariam ao Google.
 */
declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Automation\Jobs;
use Fator3\McpGoogle\Confirmation;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\McpBridge;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Records;
use Fator3\McpGoogle\SearchConsole\Abilities as GscAbilities;
use PHPUnit\Framework\TestCase;

require_once dirname( __DIR__ ) . '/includes/Generic/Discovery.php';
require_once dirname( __DIR__ ) . '/includes/Generic/ExecuteAction.php';
require_once dirname( __DIR__ ) . '/includes/SearchConsole/Api.php';
require_once dirname( __DIR__ ) . '/includes/SearchConsole/Abilities.php';

final class McpBridge032Test extends TestCase {
	private const SITE      = 'https://example.test/';
	private const SITE_PATH = 'webmasters/v3/sites/https%3A%2F%2Fexample.test%2F';

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;
		FakeHttp::reset();
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, false );
		Options::set( Options::AUTH_MODE, 'oauth' );
		Options::set( Options::OAUTH_CLIENT_ID, 'gsc-test.apps.googleusercontent.com' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'gsc-client-secret-for-tests' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'gsc-refresh-token-for-tests' );
		Options::set( Options::OAUTH_SCOPES, array( 'https://www.googleapis.com/auth/webmasters', 'https://www.googleapis.com/auth/analytics.readonly' ) );
		$document = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/discovery/searchconsole-v1.json' ), true );
		\Fator3\McpGoogle\Cache::set( Discovery::cache_key( 'search-console' ), $document, 86400 );
		GscAbilities::register();
		Jobs::register();
		Confirmation::register();
		McpBridge::register();
	}

	/** Respostas de um percurso completo de gsc/delete-site: preparação, revalidação, envio e conferência. */
	private function prime(): void {
		FakeHttp::$queue    = array();
		FakeHttp::$requests = array();
		for ( $i = 0; $i < 3; ++$i ) {
			FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'fake-gsc-access-token', 'expires_in' => 3600 ) );
		}
		for ( $i = 0; $i < 3; ++$i ) {
			FakeHttp::push( self::SITE_PATH, 200, array( 'siteUrl' => self::SITE ), array(), 'GET' );
		}
		FakeHttp::push( self::SITE_PATH, 204, '', array(), 'DELETE' );
		FakeHttp::push( self::SITE_PATH, 404, array( 'error' => array( 'code' => 404, 'message' => 'not found', 'status' => 'NOT_FOUND' ) ) );
	}

	private function prepare(): string {
		$p = wp_get_ability( 'google/prepare-operation' )->execute( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE ) ) );
		$this->assertTrue( $p['success'], (string) wp_json_encode( $p ) );
		$this->assertSame( 0, $this->writes(), 'a preparação não pode enviar escrita' );
		FakeHttp::$requests = array();
		return $p['confirmation_token'];
	}

	private function bridge( array $input ): array {
		return wp_get_ability( 'google/mcp-write' )->execute( $input );
	}

	/** Requisições de escrita (não GET, fora do endpoint de token) registradas pelo FakeHttp. */
	private function writes(): int {
		return count( array_filter( FakeHttp::$requests, static fn ( array $r ): bool => 'GET' !== strtoupper( $r['method'] ) && ! str_contains( $r['url'], 'oauth2.googleapis.com/token' ) ) );
	}

	public function test_a_token_inside_parameters_is_consumed_by_target(): void {
		$this->prime();
		$token = $this->prepare();
		$r     = $this->bridge( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE, 'confirmation_token' => $token ) ) );
		$this->assertTrue( $r['success'], (string) wp_json_encode( $r ) );
		$this->assertSame( 1, $this->writes() );
		$this->assertSame( 'finished', Records::get( 'confirmation', hash( 'sha256', $token ) )['status'] );
	}

	public function test_b_token_at_tool_level_is_consumed_by_target(): void {
		$this->prime();
		$token = $this->prepare();
		$r     = $this->bridge( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE ), 'confirmation_token' => $token ) );
		$this->assertTrue( $r['success'], (string) wp_json_encode( $r ) );
		$this->assertSame( 1, $this->writes() );
		$this->assertSame( 'finished', Records::get( 'confirmation', hash( 'sha256', $token ) )['status'] );
	}

	public function test_c_without_token_requires_confirmation_and_sends_nothing(): void {
		$this->prime();
		$r = $this->bridge( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE ) ) );
		$this->assertFalse( $r['success'] );
		$this->assertSame( 'f3_google_confirmation_required', $r['error_code'], (string) wp_json_encode( $r ) );
		$this->assertSame( 0, $this->writes() );
	}

	public function test_d_tool_level_token_is_single_use(): void {
		$this->prime();
		$token = $this->prepare();
		$input = array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE ), 'confirmation_token' => $token );
		$first = $this->bridge( $input );
		$this->assertTrue( $first['success'], (string) wp_json_encode( $first ) );
		$this->prime();
		FakeHttp::$requests = array();
		$second = $this->bridge( $input );
		$this->assertFalse( $second['success'] );
		$this->assertSame( 'f3_google_confirmation_used', $second['error_code'], (string) wp_json_encode( $second ) );
		$this->assertSame( 0, $this->writes() );
		// O mesmo token também não é reaproveitado dentro de parameters.
		$third = $this->bridge( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE, 'confirmation_token' => $token ) ) );
		$this->assertSame( 'f3_google_confirmation_used', $third['error_code'], (string) wp_json_encode( $third ) );
		$this->assertSame( 0, $this->writes() );
	}

	/**
	 * (e) A chave do nível da ferramenta não pertence ao schema publicado de google/mcp-write
	 * (é decoração do transporte Fator3 MCP) e a ponte não a repassa: só a chave dentro de
	 * parameters deduplica google/create-job.
	 */
	public function test_e_tool_level_idempotency_key_is_not_forwarded_and_parameters_key_dedupes(): void {
		$this->assertArrayNotHasKey( 'idempotency_key', wp_get_ability( 'google/mcp-write' )->get_input_schema()['properties'] );
		$job   = array( 'task' => 'query', 'parameters' => array( 'connector' => 'ga4', 'accounts' => array( '123' ), 'date_range' => 'last_7_days' ) );
		$input = array( 'ability' => 'google/create-job', 'parameters' => $job, 'idempotency_key' => 'bridge-key-1' );
		$first = $this->bridge( $input );
		$this->assertTrue( $first['success'], (string) wp_json_encode( $first ) );
		$this->assertTrue( $first['created'] );
		$second = $this->bridge( $input );
		$this->assertTrue( $second['success'], (string) wp_json_encode( $second ) );
		$this->assertTrue( $second['created'], (string) wp_json_encode( $second ) );
		$this->assertNotSame( $first['job_id'], $second['job_id'] );
		$inner  = array( 'ability' => 'google/create-job', 'parameters' => $job + array( 'idempotency_key' => 'bridge-key-2' ) );
		$third  = $this->bridge( $inner );
		$fourth = $this->bridge( $inner );
		$this->assertTrue( $third['created'], (string) wp_json_encode( $third ) );
		$this->assertFalse( $fourth['created'], (string) wp_json_encode( $fourth ) );
		$this->assertSame( $third['job_id'], $fourth['job_id'] );
		$this->assertSame( 0, $this->writes() );
	}

	public function test_f_conflicting_tokens_between_levels_are_refused_without_consuming(): void {
		$this->prime();
		$token = $this->prepare();
		$r     = $this->bridge( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE, 'confirmation_token' => $token ), 'confirmation_token' => str_repeat( 'a', 64 ) ) );
		$this->assertSame( 'f3_google_mcp_input', $r['error_code'], (string) wp_json_encode( $r ) );
		$this->assertSame( 0, $this->writes() );
		$this->assertSame( 'prepared', Records::get( 'confirmation', hash( 'sha256', $token ) )['status'] );
		// Mesmo valor nos dois níveis é aceito e consumido uma única vez.
		$same = $this->bridge( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => self::SITE, 'confirmation_token' => $token ), 'confirmation_token' => $token ) );
		$this->assertTrue( $same['success'], (string) wp_json_encode( $same ) );
		$this->assertSame( 1, $this->writes() );
	}

	public function test_g_tool_level_token_is_bound_to_target_intent(): void {
		$this->prime();
		$token = $this->prepare();
		$r     = $this->bridge( array( 'ability' => 'gsc/delete-site', 'parameters' => array( 'site_url' => 'https://other.test/' ), 'confirmation_token' => $token ) );
		$this->assertFalse( $r['success'] );
		$this->assertSame( 'f3_google_confirmation_changed', $r['error_code'], (string) wp_json_encode( $r ) );
		$this->assertSame( 0, $this->writes() );
		$this->assertSame( 'prepared', Records::get( 'confirmation', hash( 'sha256', $token ) )['status'] );
	}
}
