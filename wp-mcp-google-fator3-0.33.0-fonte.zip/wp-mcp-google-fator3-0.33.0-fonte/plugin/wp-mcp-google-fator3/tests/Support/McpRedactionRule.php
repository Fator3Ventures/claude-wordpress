<?php
/**
 * Dublê de teste (não é runtime): cópia fiel da regra de chave sensível do
 * transporte MCP que mascara campos de saída com "[redigido]".
 *
 * Procedência: plugin "Fator3 MCP" 0.43.0 (F3_MCP_FILES_VERSION 0.43.0),
 * arquivo includes/DataSafety.php, métodos key_name(), secret_key(),
 * diagnostic() e sensitive_field() da classe Fator3\McpFiles\DataSafety.
 * Aplicação na saída: includes/Release014.php, SafeOutput::error(), que
 * mascara toda chave com sensitive_field() verdadeiro, salvo exceções
 * nominais (ex.: contêiner `credential` só preserva `configured` booleano).
 *
 * Ao atualizar o MCP, compare este arquivo com o DataSafety.php da nova versão.
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

final class McpRedactionRule {
    /** Names/components, never arbitrary substrings such as pass in passagens. */
    private static function key_name(string $key): string {
        $key=preg_replace('/([a-z0-9])([A-Z])/', '$1_$2', $key);
        $key=preg_replace('/([A-Z])([A-Z][a-z])/', '$1_$2', $key);
        return trim((string)preg_replace('/[^a-z0-9]+/', '_', strtolower($key)), '_');
    }
    public static function secret_key(string $key): bool {
        $name=self::key_name($key);
        if(preg_match('/(?:^|_)(?:pass|passwords?|passwd|pwd|senhas?|secrets?|segredos?|tokens?|credentials?|credenciais|cookies?|authorization|salts?|chaves?)(?:_|$)/D',$name))return true;
        if(preg_match('/(?:^|_)(?:api|private|auth|activation|access|consumer|client|encryption|signing)_?key(?:_|$)/D',$name))return true;
        return (bool)preg_match('/(?:^|_)(?:accesstoken|refreshtoken|idtoken|clientsecret|sessiontokens|applicationpasswords|userpass)(?:_|$)/D',$name);
    }
    /** Presentation-only diagnostics. Storage/write guards still use secret_key(). */
    public static function diagnostic(string $key, $value): bool {
        $name=self::key_name($key);
        if(is_bool($value) && preg_match('/(?:^|_)(?:configured|present|available|valid|expired|enabled|verified)$/D',$name))return true;
        if((is_int($value)||is_float($value)) && is_finite((float)$value) && $value>=0 && preg_match('/(?:^|_)(?:count|total|generation|revision|age_seconds|expires_in|ttl_seconds)$/D',$name))return true;
        return is_string($value) && preg_match('/(?:^|_)(?:created_at|updated_at|expires_at|expired_at|issued_at|checked_at)$/D',$name)
            && (bool)preg_match('/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2}))?$/D',$value);
    }
    public static function sensitive_field(string $key, $value): bool {
        return self::secret_key($key) && !self::diagnostic($key,$value);
    }
    /**
     * Exceção por tipo aplicada a um nome de schema: o nome só é seguro se TODO
     * tipo declarado for booleano e o sufixo estiver na lista de diagnósticos
     * booleanos (o caso numérico/data exige valor real e não é presumido).
     */
    public static function schema_name_masked(string $name,$type): bool {
        if (!self::secret_key($name)) return false;
        $types=array_values(array_filter((array)$type,static fn($t)=>$t!=='null'));
        if ($types===['boolean']) return !self::diagnostic($name,true);
        if ($types && !array_diff($types,['integer','number'])) return !self::diagnostic($name,0);
        return true;
    }
    /**
     * Caminhos que o MCP 0.43.0 mascararia num valor de saída real. Espelho
     * simplificado de SafeOutput::value()/error()/schema() (Release014.php):
     * schemas embutidos (type object + properties) preservam nomes de
     * propriedades; exceções nominais de error() são reproduzidas; caminhos
     * de política do Site Core (policy_path/interface_path) não se aplicam ao
     * Google. $allow aceita caminho exato ou com índices de lista como `*`.
     */
    public static function masked_paths($value,string $path='',array $allow=[]): array {
        if (!is_array($value) && !$value instanceof \stdClass) return [];
        $node=(array)$value;
        if (in_array('object',(array)($node['type']??[]),true) && isset($node['properties']) && (is_array($node['properties'])||$node['properties'] instanceof \stdClass)) return self::schema_paths($node,false,$path,$allow);
        $hits=[];
        foreach ($node as $key=>$child) {
            $key=(string)$key;
            $p=$path.'.'.$key;
            if (self::allowed($p,$allow)) continue;
            if (in_array($key,['checks_passed','all_checks_passed','passed','token_configured','secret_configured','cache_bypass_verified'],true) && is_bool($child)) continue;
            if (in_array($key,['passed','credential_generation','credential_revision','authorization_revision'],true) && is_int($child) && $child>=0) continue;
            if ($key==='credential' && (is_array($child)||$child instanceof \stdClass)) {
                foreach ((array)$child as $k=>$leaf) if (!((string)$k==='configured' && is_bool($leaf))) $hits[]=$p.'.'.$k;
                continue;
            }
            if (in_array($key,['input_schema','output_schema'],true) && (is_array($child)||$child instanceof \stdClass)) { $hits=array_merge($hits,self::schema_paths((array)$child,false,$p,$allow)); continue; }
            if (in_array($key,['confirm_token','confirmation_token'],true) && is_string($child) && preg_match('/^[a-f0-9]{64}$/D',$child)) continue;
            if (self::sensitive_field($key,$child) && $key!=='error_code') { $hits[]=$p; continue; }
            $hits=array_merge($hits,self::masked_paths($child,$p,$allow));
        }
        return $hits;
    }
    private static function allowed(string $p,array $allow): bool {
        return in_array($p,$allow,true)||in_array((string)preg_replace('/\.\d+(?=\.|$)/','.*',$p),$allow,true);
    }
    private static function schema_paths(array $schema,bool $sensitive,string $path,array $allow): array {
        $hits=[];
        foreach ($schema as $key=>$value) {
            $key=(string)$key;
            $p=$path.'.'.$key;
            if (in_array($key,['properties','$defs','definitions','patternProperties'],true) && (is_array($value)||$value instanceof \stdClass)) {
                foreach ((array)$value as $name=>$child) $hits=(is_array($child)||$child instanceof \stdClass)?array_merge($hits,self::schema_paths((array)$child,$sensitive||self::secret_key((string)$name),$p.'.'.$name,$allow)):array_merge($hits,[$p.'.'.$name]);
            }
            elseif (in_array($key,['items','additionalProperties','not','if','then','else','contains'],true) && (is_array($value)||$value instanceof \stdClass)) $hits=array_merge($hits,self::schema_paths((array)$value,$sensitive,$p,$allow));
            elseif (in_array($key,['allOf','anyOf','oneOf','prefixItems'],true) && is_array($value)) {
                foreach ($value as $i=>$v) if (is_array($v)||$v instanceof \stdClass) $hits=array_merge($hits,self::schema_paths((array)$v,$sensitive,$p.'.'.$i,$allow));
            }
            elseif ($sensitive && in_array($key,['default','examples'],true)) { if (!self::allowed($p,$allow)) $hits[]=$p; }
            else $hits=array_merge($hits,self::masked_paths([$key=>$value],$path,$allow));
        }
        return $hits;
    }
}
