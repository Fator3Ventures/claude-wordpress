<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{
    Options,Lock,Connections,Recovery,Records
};
use Fator3\McpGoogle\Automation\{
    CronHistory,CronErrors,Executor,Scheduling,Jobs
};
use Fator3\McpGoogle\Storage\CronStore;
final class Release083Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;
        $GLOBALS['f3_test_user']=1;
        Connections::select('default');
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f) unlink($f);
        foreach(['invocation'=>null] as $field=>$v) {
            $p=new \ReflectionProperty(CronHistory::class,$field);
            $p->setAccessible(true);
            $p->setValue(null,$v);
        }
        foreach(['context','volatile'] as $field) {
            $p=new \ReflectionProperty(Scheduling::class,$field);
            $p->setAccessible(true);
            $p->setValue(null,[]);
        }
        Options::set(Options::ENABLED,true);
        FakeHttp::reset();
        CronStore::ensure_ready();
    }
    protected function tearDown(): void {
        $GLOBALS['f3_test_write_fail']=[];
        Connections::select('default');
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f) unlink($f);
    }
    private function close(array $f,bool $success=true): array {
        return CronHistory::finish($f,['default'=>['success'=>$success,'items'=>2,'connection_examined'=>true,'state'=>$success?'completed':'failed']]);
    }
    private function intent(string $op,?int $at,array $args=[],string $rec=''): array {
        $m=new \ReflectionMethod(Scheduling::class,'intent');
        $m->setAccessible(true);
        return $m->invoke(null,$op,Jobs::HOOK,$at,$args,$rec, $rec?60:0);
    }
    private function observe(array $intent,$result=false): array {
        $m=new \ReflectionMethod(Scheduling::class,'observe');
        $m->setAccessible(true);
        return $m->invoke(null,$intent,$result);
    }
    private function event(int $at,array $args=[],string $rec=''): void {
        $cron=get_option('cron',[]);
        $cron[$at][Jobs::HOOK][md5(serialize($args))]=['args'=>$args,'schedule'=>$rec?:false]+($rec?['interval'=>60]:[]);
        update_option('cron',$cron+['version'=>2]);
    }
    public function test_admission_busy_yields_without_work_or_incident(): void {
        $held=Lock::acquire('jobs-tick');
        $r=Executor::run();
        Lock::release($held);
        $this->assertTrue($r['success']);
        $this->assertSame('yielded',$r['state']);
        $this->assertNull($r['work_success']);
        $this->assertSame(0,$r['executed']);
        $this->assertFalse($r['run']['results']['default']['connection_examined']);
        $this->assertNull(CronHistory::summary('default')['observability_error']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_history_busy_is_unconfirmed_without_a_storage_incident(): void {
        $held=Lock::acquire('cron-history:default');
        $r=Executor::run();
        Lock::release($held);
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertSame('yielded',$r['state']);
        $this->assertSame('unconfirmed',$r['history_status']);
        $this->assertNull($r['observability_error']);
        $this->assertNull(CronStore::latest('default','incident'));
    }
    public function test_unrecorded_contention_keeps_coverage_gap_after_recovery(): void {
        $held=Lock::acquire('cron-history:default');
        Executor::run();
        Lock::release($held);
        $this->close(CronHistory::begin(['default']));
        $s=CronHistory::summary('default');
        $this->assertNull($s['observability_error']);
        $this->assertFalse($s['window_complete']);
        $this->assertNotEmpty($s['coverage_gap']);
    }
    public function test_corrupt_scheduling_observation_is_unconfirmed_without_mutation(): void {
        Options::set(Scheduling::OPTION,['observations'=>['bad'=>['id'=>'x','hook'=>Jobs::HOOK,'operation'=>'schedule','args_key'=>'x','args_digest'=>'x']],'active_errors'=>[],'last_errors'=>[]]);
        $before=$GLOBALS['f3_test_options'];
        $r=Scheduling::status();
        $this->assertFalse($r['read_success']);
        $this->assertSame('f3_google_cron_schedule_diagnostic_read',$r['error_code']);
        $this->assertSame($before,$GLOBALS['f3_test_options']);
    }
    public function test_projection_contention_keeps_terminal_source_and_reconciles_locally(): void {
        $frame=CronHistory::begin(['default']);
        $held=Lock::acquire('cron-projection:default');
        $r=$this->close($frame);
        Lock::release($held);
        $this->assertNull($r['observability_error']);
        $this->assertSame('pending',$r['passes']['default']['history_status']);
        $row=CronStore::get('pass','default',$frame['run_id'])['value'];
        $this->assertSame(2,$row['items']);
        $this->assertSame('completed',$row['state']);
        $before=$GLOBALS['f3_test_options'];
        $status=CronHistory::summary('default');
        $this->assertSame($before,$GLOBALS['f3_test_options']);
        $this->assertTrue($status['history_pending']);
        $this->assertTrue(CronHistory::reconcile('default')['success']);
        $this->assertFalse(CronHistory::summary('default')['history_pending']);
        $this->assertSame(0,FakeHttp::count());
        $this->assertTrue(CronHistory::reconcile('default')['success']);
        $this->assertSame(2,CronHistory::summary('default')['last_run']['items']);
    }
    public function test_orphan_error_survives_age_then_resolves_after_confirmed_failed_work(): void {
        $error=['at'=>time()-90000,'code'=>'f3_google_cron_projection','phase'=>'finish','run_id'=>'old','origem'=>'http_cron','connection_id'=>'default','diagnostic_persisted'=>false];
        Options::set('f3_mcp_google_cron_error_default',$error);
        $this->assertSame($error,CronHistory::summary('default')['observability_error']);
        $frame=CronHistory::begin(['default']);
        $this->assertNotNull(CronHistory::summary('default')['observability_error']);
        $r=$this->close($frame,false);
        $this->assertFalse($r['passes']['default']['success']);
        $s=CronHistory::summary('default');
        $this->assertNull($s['observability_error']);
        $this->assertSame($frame['run_id'],$s['last_observability_error']['resolved_by']['run_id']);
        $this->assertSame('old',$s['last_observability_error']['run_id']);
    }
    public function test_new_error_with_same_second_is_not_cleared_by_old_observation(): void {
        $old=['at'=>time(),'code'=>'f3_google_cron_event','phase'=>'finish','error_id'=>'first'];
        Options::set('f3_mcp_google_cron_error_default',$old);
        $snapshot=CronErrors::snapshot('default');
        $new=$old;
        $new['error_id']='second';
        Options::set('f3_mcp_google_cron_error_default',$new);
        $r=Recovery::run(fn()=>CronErrors::resolve('default',$snapshot,['run_id'=>'old-close','origem'=>'cli']));
        $this->assertTrue($r['success']);
        $this->assertTrue($r['newer_error_preserved']);
        $this->assertSame($new,CronHistory::summary('default')['observability_error']);
    }
    public function test_yielded_and_other_connection_do_not_clear_active_error(): void {
        Options::set('f3_mcp_google_cron_error_default',['at'=>time(),'code'=>'f3_google_cron_event','error_id'=>'old']);
        $held=Lock::acquire('jobs-tick');
        Executor::run();
        Lock::release($held);
        $this->assertNotNull(CronHistory::summary('default')['observability_error']);
        Connections::create('second','Second');
        Connections::run('second',fn()=>Executor::run());
        $this->assertNotNull(CronHistory::summary('default')['observability_error']);
    }
    public function test_resolution_write_failure_keeps_active_failure_and_work(): void {
        Options::set('f3_mcp_google_cron_error_default',['at'=>time(),'code'=>'f3_google_cron_event','error_id'=>'old']);
        $frame=CronHistory::begin(['default']);
        $GLOBALS['f3_test_write_fail']['f3_mcp_google_cron_error_default']=true;
        $r=$this->close($frame);
        unset($GLOBALS['f3_test_write_fail']['f3_mcp_google_cron_error_default']);
        $this->assertSame(2,$r['passes']['default']['items']);
        $this->assertSame('pending',$r['passes']['default']['history_status']);
        $this->assertNotNull($r['observability_error']);
        $this->assertNotNull(CronHistory::summary('default')['observability_error']);
    }
    public function test_repeated_finish_does_not_add_counts(): void {
        $frame=CronHistory::begin(['default']);
        $this->close($frame);
        $r=$this->close($frame);
        $this->assertSame(2,$r['passes']['default']['items']);
        $this->assertSame(1,CronHistory::summary('default')['passagens_24h']['manual']);
    }
    public function test_pending_terminal_source_is_not_evicted_by_retention(): void {
        $frame=CronHistory::begin(['default']);
        $held=Lock::acquire('cron-projection:default');
        $this->close($frame);
        Lock::release($held);
        $row=CronStore::get('pass','default',$frame['run_id'])['value'];
        $row['at']=time()-9*86400;
        $held=Lock::acquire('cron-history:default');
        CronStore::put('pass','default',$frame['run_id'],$row,null,$held);
        $trim=CronStore::trim('default','pass',0,null,$held);
        Lock::release($held);
        $this->assertTrue($trim);
        $this->assertTrue(CronStore::get('pass','default',$frame['run_id'])['exists']);
    }
    public function test_schedule_already_persisted_is_confirmed_with_warning(): void {
        $at=time()+60;
        $this->event($at,[],'f3_google_minute');
        $r=$this->observe($this->intent('schedule',$at,[],'f3_google_minute'),new \WP_Error('could_not_set','fixture'));
        $this->assertTrue($r['success']);
        $this->assertSame('could_not_set',$r['original_code']);
        $this->assertSame('confirmed',$r['state']);
        $this->assertTrue($r['diagnostic_persisted']);
        $active=Scheduling::status()['active_errors'];
        $this->assertSame([],array_values(array_filter($active,static fn($e)=>($e['source']??'history')!=='current_state')));
    }
    public function test_future_event_does_not_prove_old_occurrence_removed(): void {
        $at=time()-10;
        $this->event($at);
        $this->event($at+60);
        $r=$this->observe($this->intent('unschedule',$at));
        $this->assertFalse($r['success']);
        $this->assertSame('failed',$r['state']);
        $cron=get_option('cron');
        unset($cron[$at]);
        update_option('cron',$cron+['version'=>2]);
        $this->assertTrue(Scheduling::reconcile()['success']);
        $active=Scheduling::status()['active_errors'];
        $this->assertSame([],array_values(array_filter($active,static fn($e)=>($e['source']??'history')!=='current_state')));
        $this->assertArrayHasKey($at+60,get_option('cron'));
    }
    public function test_arguments_recurrence_and_timestamp_are_part_of_proof(): void {
        $at=time()+60;
        $this->event($at,['a'=>1],'f3_google_minute');
        foreach([$this->intent('schedule',$at,['a'=>'1'],'f3_google_minute'),$this->intent('schedule',$at+1,['a'=>1],'f3_google_minute'),$this->intent('schedule',$at,['a'=>1],'hourly')] as $intent) $this->assertFalse($this->observe($intent)['success']);
    }
    public function test_missing_context_is_unconfirmed_not_harmless(): void {
        $this->event(time()+60);
        $r=$this->observe($this->intent('reschedule',null));
        $this->assertSame('unconfirmed',$r['state']);
        $this->assertNull($r['postcondition']);
        $this->assertFalse($r['success']);
    }
    public function test_schedule_diagnostic_failure_is_separate_from_postcondition(): void {
        $at=time()+5;
        $this->event($at);
        $GLOBALS['f3_test_write_fail'][Scheduling::OPTION]=true;
        $r=$this->observe($this->intent('schedule',$at));
        $this->assertTrue($r['success']);
        $this->assertFalse($r['diagnostic_persisted']);
        $this->assertNotNull($r['diagnostic_error_code']);
    }
    public function test_status_and_paused_observation_have_no_writes(): void {
        Recovery::change(['action'=>'prepare']);
        $before=$GLOBALS['f3_test_options'];
        $r=$this->observe($this->intent('schedule',time()));
        $this->assertSame('f3_google_recovery_paused',$r['error_code']);
        Scheduling::status();
        $this->assertSame($before,$GLOBALS['f3_test_options']);
    }
    public function test_foreign_hook_is_not_owned_and_no_argument_leaks(): void {
        $this->assertSame('f3_google_cron_hook',Scheduling::schedule('f3base_any',time())['error_code']);
        $this->observe($this->intent('schedule',time(),['secret'=>'PRIVATE_ARGS']));
        $this->assertStringNotContainsString('PRIVATE_ARGS',wp_json_encode(Scheduling::status()));
    }
}
