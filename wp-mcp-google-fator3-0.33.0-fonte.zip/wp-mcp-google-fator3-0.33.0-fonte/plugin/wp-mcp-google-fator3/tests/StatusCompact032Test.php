<?php
/** 0.32.0 C: the compact status carries local health without any Google request. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options,Connections,Records};
use Fator3\McpGoogle\Automation\{Scheduling,ExecutorSchedule,Executor};
use Fator3\McpGoogle\Storage\Maintenance;
use Fator3\McpGoogle\Unified\{Abilities,StatusSchema};
require_once __DIR__.'/Support/JsonSchema.php';
final class StatusCompact032Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;Connections::select('default');
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f) if(is_file($f)) unlink($f);
        foreach(['context','volatile'] as $field) { $p=new \ReflectionProperty(Scheduling::class,$field);$p->setAccessible(true);$p->setValue(null,[]); }
        Options::set(Options::ENABLED,true);FakeHttp::reset();
        $this->assertTrue(ExecutorSchedule::ensure()['success']);
    }
    private function compact(): array {
        $r=Abilities::status(['compact'=>true]);
        $this->assertTrue($r['success'],json_encode($r));
        return $r;
    }
    public function test_compact_reports_health_fields_with_types_and_no_google_call(): void {
        $r=$this->compact();
        foreach(['health','work_health'] as $k) $this->assertIsString($r[$k]??null,$k);
        $this->assertIsInt($r['scheduling_active_errors']??null);
        $this->assertIsInt($r['incidents_open']??null);
        $full=Executor::status();
        $this->assertSame($full['health'],$r['health']);$this->assertSame($full['work_health'],$r['work_health']);
        $this->assertSame(0,$r['scheduling_active_errors']);$this->assertSame(0,$r['incidents_open']);
        $this->assertNotSame('degraded',$r['health']);
        $this->assertSame(0,FakeHttp::count());
        $schema=StatusSchema::schema();
        foreach(['health','work_health','scheduling_active_errors','incidents_open'] as $k) $this->assertArrayHasKey($k,$schema['properties']);
        $this->assertTrue(JsonSchema::validate($r,$schema));
    }
    public function test_compact_is_degraded_with_a_real_active_error(): void {
        $m=new \ReflectionMethod(Scheduling::class,'intent');$m->setAccessible(true);
        $o=new \ReflectionMethod(Scheduling::class,'observe');$o->setAccessible(true);
        $failed=$o->invoke(null,$m->invoke(null,'reschedule',Maintenance::HOOK,time()+60,[],'hourly',3600),new \WP_Error('could_not_set','x'));
        $this->assertFalse($failed['success']);
        $r=$this->compact();
        $this->assertSame('degraded',$r['health']);
        $this->assertSame(1,$r['scheduling_active_errors']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_compact_counts_open_incidents_like_readiness(): void {
        Options::set(\Fator3\McpGoogle\Automation\Alerts::OPTION,['enabled'=>true,'email_enabled'=>false,'recipients'=>[],'events'=>\Fator3\McpGoogle\Automation\Alerts::EVENTS,'minimum_interval'=>3600]);
        $event=\Fator3\McpGoogle\Automation\Alerts::EVENTS[0];
        \Fator3\McpGoogle\Automation\Alerts::observe($event,'resource-a',true,'f3_test','agir');
        \Fator3\McpGoogle\Automation\Alerts::observe($event,'resource-b',true,'f3_test','agir');
        \Fator3\McpGoogle\Automation\Alerts::observe($event,'resource-b',false,'f3_test','agir');
        $this->assertSame(1,$this->compact()['incidents_open']);
        $open=0;foreach(\Fator3\McpGoogle\Automation\Alerts::state(['limit'=>100],true)['incidents'] as $i) if(($i['status']??'')==='open') ++$open;
        $this->assertSame($open,$this->compact()['incidents_open']);
    }
}
