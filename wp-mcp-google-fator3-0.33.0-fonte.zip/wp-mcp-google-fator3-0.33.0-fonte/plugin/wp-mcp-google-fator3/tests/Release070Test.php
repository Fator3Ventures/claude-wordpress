<?php
/** Release 0.7 contract, failure and isolation regressions. HTTP is simulated here. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Audit, Connections, Gate, Options, Plugin, Policy, Records, Recovery, Settings};
use Fator3\McpGoogle\Integration\{ConsumerClient, ServiceApi, Transition};
use Fator3\McpGoogle\Automation\{CronHistory, Executor};
use Fator3\McpGoogle\SearchConsole\AnalyticsBudget;
use PHPUnit\Framework\TestCase;
final class Release070Test extends TestCase {
    private array $cfg;
    private ConsumerClient $client;
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=[]; $GLOBALS['f3_test_transients']=[]; $GLOBALS['f3_test_write_fail']=[]; $GLOBALS['f3_test_caps']=true; $GLOBALS['f3_test_user']=1; $GLOBALS['f3_test_user_caps']=[];
        FakeHttp::reset();
        $r=new \ReflectionProperty(ServiceApi::class,'consumers'); $r->setAccessible(true); $r->setValue(null,[]);
        foreach (glob(WP_CONTENT_DIR.'/f3-google-state/*') ?: [] as $p) { unlink($p); }
        Options::batch_verified([Options::ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'test.apps.googleusercontent.com',Connections::SERVICES=>['gsc'=>'read']], [Options::OAUTH_CLIENT_SECRET=>'fixture-secret',Options::OAUTH_REFRESH_TOKEN=>'fixture-refresh']);

        $this->cfg=['property'=>'sc-domain:example.test','revision'=>'core-rev-1','ready'=>true];
        $this->client=ServiceApi::register_consumer('base-site-core-fator3','1.20.0',ServiceApi::CONTRACT,fn()=>$this->cfg);
        $r=ServiceApi::configure(['consumer_id'=>'base-site-core-fator3','enabled'=>true,'expected_revision'=>Settings::revision()]);
        $this->assertTrue($r['success'],json_encode($r));
        Plugin::register_abilities();
    }
    protected function tearDown(): void {
        $GLOBALS['f3_test_caps']=true; $GLOBALS['f3_test_user']=1;
        foreach (glob(WP_CONTENT_DIR.'/f3-google-state/*') ?: [] as $p) { unlink($p); }
    }
    private function input(array $changes=[]): array { return array_replace(['contract_version'=>'1.0.0','property'=>$this->cfg['property'],'consumer_revision'=>$this->cfg['revision'],'date'=>'2026-09-20','run_id'=>'core-test-1','trigger'=>'cli','budget_ms'=>20000],$changes); }
    private function token(): void { FakeHttp::push('/token',200,['access_token'=>'fixture-access','expires_in'=>3600]); }
    private function rows(int $count=1): array {
        return ['responseAggregationType'=>'byPage','rows'=>array_map(static fn($n)=>['keys'=>['2026-09-20','https://blog.example.test/p'.$n],'clicks'=>2,'impressions'=>10,'ctr'=>0.2,'position'=>3.5],$count ? range(1,$count) : [])];
    }
    public function test_registered_plugin_reads_without_user_and_preserves_host_and_audit_actor(): void {
        $GLOBALS['f3_test_user']=0; $GLOBALS['f3_test_caps']=false; $this->token(); FakeHttp::push('/searchAnalytics/query',200,$this->rows());
        $r=$this->client->query($this->input());
        $this->assertTrue($r['success'],json_encode($r)); $this->assertTrue($r['audit_success']);
        $this->assertSame('https://blog.example.test/p1',$r['rows'][0]['page']); $this->assertFalse($r['coverage']['all_rows_guaranteed']);
        $this->assertSame(0,get_current_user_id()); $this->assertFalse(Gate::permission('gsc'));
        $log=array_values(array_filter(Audit::recent(20),fn($e)=>$e['action']==='plugin:gsc.page-day.end'))[0];
        $this->assertSame('base-site-core-fator3',$log['actor']['id']); $this->assertSame(0,$log['user']); $this->assertSame($r['request_id'],$log['request_id']);
        $this->assertNull(\Fator3\McpGoogle\Integration\Context::current());
    }
    public function test_pagination_cursor_binds_connection_configuration_and_revision(): void {
        $this->token(); FakeHttp::push('/searchAnalytics/query',200,$this->rows());
        $first=$this->client->query($this->input(['limit'=>1])); $this->assertTrue($first['success'],json_encode($first)); $this->assertNotNull($first['next_cursor']);
        FakeHttp::push('/searchAnalytics/query',200,$this->rows(0));
        $last=$this->client->query($this->input(['limit'=>1,'cursor'=>$first['next_cursor']]));
        $this->assertTrue($last['success']); $this->assertSame(1,json_decode(FakeHttp::last()['body'],true)['startRow']); $this->assertTrue($last['coverage']['pagination_complete']);
        $this->cfg['revision']='core-rev-2';
        $bad=$this->client->query($this->input(['limit'=>1,'cursor'=>$first['next_cursor']])); $this->assertSame('f3_google_consumer_cursor',$bad['error_code']);
    }
    public function test_forged_client_and_wrong_property_do_not_dispatch(): void {
        $this->assertSame('f3_google_consumer_unregistered',(new ConsumerClient())->query($this->input())['error_code']);
        $this->assertSame('f3_google_consumer_property',$this->client->query($this->input(['property'=>'sc-domain:foreign.test']))['error_code']);
        $this->assertSame(0,FakeHttp::count());
    }
    /** @dataProvider invalid */
    public function test_contract_rejects_bad_input_before_http(array $change): void {
        $r=$this->client->query($this->input($change)); $this->assertFalse($r['success']); $this->assertSame(0,FakeHttp::count());
    }
    public static function invalid(): array { return [[['budget_ms'=>0]],[['budget_ms'=>20001]],[['budget_ms'=>'5000']],[['trigger'=>'server-cron']],[['actor'=>'admin']],[['contract_version'=>'2.0.0']],[['date'=>'2026-02-30']],[['limit'=>10001]],[['cursor'=>'broken']]]; }
    public function test_insufficient_budget_refuses_before_token(): void {
        $r=$this->client->query($this->input(['budget_ms'=>2500])); $this->assertSame('f3_google_deadline',$r['error_code']); $this->assertSame(0,FakeHttp::count());
    }
    public function test_timeout_is_bounded_in_token_and_query(): void {
        $timeouts=[]; $hook=static function($pre,$args) use (&$timeouts) { $timeouts[]=$args['timeout']; return $pre; };
        add_filter('pre_http_request',$hook,20,3);
        try { $this->token(); FakeHttp::push('/searchAnalytics/query',200,$this->rows(0)); $r=$this->client->query($this->input(['budget_ms'=>4000])); $this->assertTrue($r['success'],json_encode($r)); }
        finally { remove_filter('pre_http_request',$hook,20); }
        $this->assertCount(2,$timeouts); foreach ($timeouts as $timeout) { $this->assertLessThanOrEqual(2,$timeout); }
    }
    public function test_unready_disabled_and_denied_consumers_do_not_dispatch(): void {
        $this->cfg['ready']=false; $this->assertSame('f3_google_consumer_not_ready',$this->client->query($this->input())['error_code']); $this->cfg['ready']=true;
        Options::set(Options::ENABLED,false); $this->assertSame('f3_google_disabled',$this->client->query($this->input())['error_code']); Options::set(Options::ENABLED,true);
        Options::set(ServiceApi::GRANTS,[]); $this->assertSame('f3_google_consumer_unauthorized',$this->client->query($this->input())['error_code']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_policy_applies_without_human_capability(): void {
        Options::set(Policy::OPTION,['mode'=>'restricted','services'=>['gsc'=>['resources'=>['sc-domain:other.test']]]]);
        $GLOBALS['f3_test_caps']=false; $GLOBALS['f3_test_user']=0;
        $r=$this->client->query($this->input()); $this->assertFalse($r['success']); $this->assertSame(0,FakeHttp::count());
    }
    public function test_revocation_during_token_prevents_query_dispatch(): void {
        $hook=static function($pre,$args,$url) { if (str_contains($url,'/token')) { Options::set(ServiceApi::GRANTS,[]); } return $pre; };
        add_filter('pre_http_request',$hook,20,3);
        try { $this->token(); $r=$this->client->query($this->input()); $this->assertSame('f3_google_consumer_unauthorized',$r['error_code']); $this->assertSame(1,FakeHttp::count()); }
        finally { remove_filter('pre_http_request',$hook,20); }
    }
    public function test_upstream_error_is_not_empty_success(): void {
        $this->token(); FakeHttp::push('/searchAnalytics/query',429,['error'=>['code'=>429,'message'=>'Quota']],['retry-after'=>'15']);
        $r=$this->client->query($this->input()); $this->assertFalse($r['success']); $this->assertTrue($r['retryable']); $this->assertSame(15000,$r['retry_after_ms']); $this->assertArrayNotHasKey('rows',$r);
    }
    public function test_bad_aggregation_or_metrics_are_rejected(): void {
        $this->token(); $raw=$this->rows(); $raw['responseAggregationType']='byProperty'; FakeHttp::push('/searchAnalytics/query',200,$raw);
        $r=$this->client->query($this->input()); $this->assertSame('f3_google_consumer_response',$r['error_code']);
        $raw=$this->rows(); $raw['rows'][0]['clicks']='NaN'; FakeHttp::push('/searchAnalytics/query',200,$raw);
        $this->assertSame('f3_google_consumer_response',$this->client->query($this->input())['error_code']);
    }
    public function test_budget_shared_across_connections_with_same_principal(): void {
        Options::set(Options::OAUTH_EMAIL,'reader@example.test'); Options::set(Options::GSC_MINUTE,1);
        $this->assertNull(AnalyticsBudget::reserve($this->cfg['property']));
        Connections::create('second','Second');
        Connections::run('second',function(){ Options::set(Options::AUTH_MODE,'oauth'); Options::set(Options::OAUTH_EMAIL,'reader@example.test'); $this->assertSame('f3_google_analytics_budget_limit',AnalyticsBudget::reserve($this->cfg['property'])->get_error_code()); });
    }
    public function test_human_generic_query_consumes_same_budget(): void {
        Options::set(Options::GSC_MINUTE,1); $this->token(); FakeHttp::push('/searchAnalytics/query',200,$this->rows(0));
        $this->assertTrue($this->client->query($this->input())['success']);
        $error=\Fator3\McpGoogle\Http\GoogleClient::post('https://www.googleapis.com/webmasters/v3/sites/'.rawurlencode($this->cfg['property']).'/searchAnalytics/query',[],['mode'=>'read','connector'=>'gsc','auth'=>false]);
        $this->assertSame('f3_google_analytics_budget_limit',$error->get_error_code()); $this->assertSame(2,FakeHttp::count());
    }
    public function test_multiple_grants_are_refused_and_permission_is_verified(): void {
        Connections::create('second','Second');
        $r=Connections::run('second',fn()=>ServiceApi::configure(['consumer_id'=>'base-site-core-fator3','enabled'=>true,'expected_revision'=>Settings::revision()]));
        $this->assertSame('f3_google_consumer_connection',$r['error_code']);
        $GLOBALS['f3_test_caps']=false;
        $this->assertSame('f3_google_forbidden',ServiceApi::configure(['consumer_id'=>'base-site-core-fator3','enabled'=>false,'expected_revision'=>Settings::revision()])['error_code']);
    }


    public function test_retired_importer_absent_and_new_contract_exposes_writers(): void {
        foreach (['google/configure-gsc-import','google/sync-gsc-core','google/gsc-import-status'] as $name) { $this->assertNull(wp_get_ability($name)); }
        $r=\Fator3\McpGoogle\Configuration::read(); $this->assertSame('4.0.0',$r['contract_version']); $this->assertArrayNotHasKey('gsc_import',$r['options']);
        $this->assertContains('google/configure-consumer',$r['options']['consumer_grants']['allowed_operations']);
        $this->assertArrayNotHasKey('gsc_import',\Fator3\McpGoogle\Unified\Abilities::status([]));
    }
    public function test_cron_projection_independent_origins_expire_without_new_pass(): void {
        $base=['run_id'=>'00000000000000000001_fixture','at'=>time(),'origem'=>'cli','success'=>false,'items'=>2,'state'=>'failed'];
        Options::set('f3_mcp_google_cron_history_default',['ultima_cli'=>$base,'ultima_http'=>array_replace($base,['origem'=>'http_cron','at'=>time()+1]),'last_pass'=>$base,'observed_since'=>time()-90000]);
        $state=CronHistory::summary('default'); $this->assertTrue($state['cron_servidor_ativo']); $this->assertSame('server-cron',$state['executor']);
        $this->assertTrue(CronHistory::summary('default',$base['at']+7200)['cron_servidor_ativo']);
        $this->assertFalse(CronHistory::summary('default',$base['at']+7201)['cron_servidor_ativo']);
        $this->assertFalse(CronHistory::summary('default',$base['at']-1)['cron_servidor_ativo']);
        $f=CronHistory::begin(['default']); CronHistory::finish($f,['default'=>['connection_examined'=>true,'success'=>true,'items'=>0]],'no_due_work');
        $state=CronHistory::summary('default'); $this->assertSame($base,$state['ultima_cli']); $this->assertSame('manual',$state['last_run']['origem']);
    }
    public function test_cron_late_completion_cannot_overwrite_newer_pass_or_other_connection(): void {
        Connections::create('second','Second');
        $a=CronHistory::begin(['default','second']); $b=CronHistory::begin(['default']);
        CronHistory::finish($b,['default'=>['connection_examined'=>true,'items'=>2,'success'=>true]]);
        CronHistory::finish($a,['default'=>['connection_examined'=>true,'items'=>1,'success'=>false],'second'=>['connection_examined'=>false,'items'=>0,'success'=>null]]);
        $this->assertSame($b['run_id'],CronHistory::summary('default')['last_run']['run_id']); $this->assertSame(2,CronHistory::summary('default')['last_run']['items']);
        $this->assertNull(CronHistory::summary('second')['last_run']['success']); $this->assertSame(0,CronHistory::summary('second')['last_run']['items']);
    }
    public function test_recovery_survives_database_restore_and_fences_dispatch(): void {
        $options=$GLOBALS['f3_test_options']; $generation=Recovery::generation();
        $r=Recovery::change(['action'=>'prepare']); $this->assertTrue($r['success'],json_encode($r)); $this->assertTrue($r['ready_for_restore']);
        $GLOBALS['f3_test_options']=$options;
        $this->assertTrue(Recovery::status()['paused']);
        $this->assertSame('f3_google_recovery_paused',$this->client->query($this->input())['error_code']);
        $state=Recovery::status();
        $bad=Recovery::change(['action'=>'resume','expected_generation'=>'wrong','acknowledge_reconciled'=>true]); $this->assertFalse($bad['success']);
        $good=Recovery::change(['action'=>'resume','expected_generation'=>$state['generation'],'acknowledge_reconciled'=>true]);
        $this->assertTrue($good['success']); $this->assertNotSame($generation,Recovery::generation()); $this->assertSame(0,FakeHttp::count());
    }
    public function test_executor_no_work_has_verified_manual_origin_and_no_importer(): void {
        $r=Executor::run(); $this->assertTrue($r['success'],json_encode($r)); $this->assertSame('manual',$r['run']['origem']);
        $this->assertSame(0,$r['run']['results']['default']['items']); $this->assertTrue($r['run']['results']['default']['success']);
        $this->assertArrayNotHasKey('gsc_imports',$r);
    }
    public function test_native_invocation_consolidates_executor_children_without_duplicate_passes(): void {
        $property=new \ReflectionProperty(CronHistory::class,'invocation'); $property->setAccessible(true);
        $outer=CronHistory::begin(['default'],'wp cron event run',true); $property->setValue(null,$outer);
        try {
            $one=CronHistory::begin(['default']); CronHistory::finish($one,['default'=>['items'=>2,'jobs'=>2,'success'=>false,'state'=>'failed','connection_examined'=>true]]);
            $two=CronHistory::begin(['default']); CronHistory::finish($two,['default'=>['items'=>3,'jobs'=>3,'success'=>true,'state'=>'completed','connection_examined'=>true]]);
            CronHistory::finish($outer,[],'observed');
            $state=CronHistory::summary('default');
            $this->assertSame(5,$state['last_run']['items']); $this->assertFalse($state['last_run']['success']);
            $this->assertSame(1,$state['passagens_24h']['manual']);
        } finally { $property->setValue(null,null); }
    }
    public function test_cron_projection_failure_is_machine_readable(): void {
        $GLOBALS['f3_test_write_fail']['f3_mcp_google_cron_history_default']=true;
        $r=Executor::run(); $this->assertFalse($r['success']); $this->assertSame('f3_google_cron_persistence',$r['error_code']);
        $this->assertNotNull(CronHistory::summary('default')['observability_error']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_grant_write_refusal_does_not_enable_or_revoke_silently(): void {
        $GLOBALS['f3_test_write_fail'][ServiceApi::GRANTS]=true;
        $r=ServiceApi::configure(['consumer_id'=>'base-site-core-fator3','enabled'=>false,'expected_revision'=>Settings::revision()]);
        $this->assertFalse($r['success']); $this->assertTrue(Options::get(ServiceApi::GRANTS)['base-site-core-fator3']['enabled']);
    }
    public function test_unavailable_storage_blocks_reader_before_network(): void {
        $GLOBALS['f3_test_record_read_fail']=true;
        $r=$this->client->query($this->input()); $this->assertSame('f3_google_storage_unavailable',$r['error_code']); $this->assertSame(0,FakeHttp::count());
    }
    public function test_attempt_audits_and_error_keep_service_correlation(): void {
        $this->token(); FakeHttp::push('/searchAnalytics/query',403,['error'=>['code'=>403,'message'=>'Denied']]);
        $r=$this->client->query($this->input());
        $events=array_values(array_filter(Audit::recent(30),fn($e)=>($e['request_id'] ?? null)===$r['request_id']));
        $this->assertFalse($r['success']); $this->assertCount(6,$events);
        $this->assertCount(2,array_filter($events,fn($e)=>$e['action']==='plugin:http.end'));
    }

    public function test_null_rows_and_unproven_aggregation_never_become_empty_success(): void {
        $this->token();FakeHttp::push('/searchAnalytics/query',200,['rows'=>null]);
        $this->assertSame('f3_google_consumer_response',$this->client->query($this->input())['error_code']);
        $raw=$this->rows();unset($raw['responseAggregationType']);FakeHttp::push('/searchAnalytics/query',200,$raw);
        $this->assertSame('f3_google_consumer_response',$this->client->query($this->input())['error_code']);
    }

}
