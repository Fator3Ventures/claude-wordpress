<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Admin, Connections, Options, Policy, Settings};
use Fator3\McpGoogle\Auth\{Candidate, Configuration, Credentials, OAuthFlow};

final class OAuthLifecycle030Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = [];
        $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1;
        $_GET = $_POST = []; FakeHttp::reset();
        Options::batch_verified([Options::ENABLED=>true, Options::AUTH_MODE=>'oauth', Settings::AUTH_READY=>true,
            Options::OAUTH_CLIENT_ID=>'active.apps.googleusercontent.com', Options::OAUTH_EMAIL=>'active@example.test',
            Options::OAUTH_SCOPES=>['https://www.googleapis.com/auth/tagmanager.readonly'], Connections::SERVICES=>['gtm'=>'read'],
            Policy::OPTION=>['mode'=>'identity','services'=>[]]],
            [Options::OAUTH_CLIENT_SECRET=>'GOCSPX-active', Options::OAUTH_REFRESH_TOKEN=>'active-refresh']);
    }
    protected function tearDown(): void {
        $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_write_fail'] = [];
        $_GET = $_POST = []; FakeHttp::reset();
    }
    private function candidate(): void {
        $r=Candidate::save('oauth', [Options::OAUTH_CLIENT_ID=>'pending.apps.googleusercontent.com',
            Options::OAUTH_EMAIL=>'pending@example.test',Options::OAUTH_SCOPES=>['https://www.googleapis.com/auth/tagmanager.readonly']],
            [Options::OAUTH_CLIENT_SECRET=>'GOCSPX-pending',Options::OAUTH_REFRESH_TOKEN=>'pending-refresh']);
        self::assertTrue($r['success']);
    }
    public function test_changed_client_requires_its_own_secret_and_preserves_state(): void {
        $this->candidate(); $before=Settings::revision();
        $r=Configuration::save_oauth('new.apps.googleusercontent.com','',$before);
        self::assertFalse($r['success']); self::assertSame('f3_google_oauth_secret_required',$r['error_code']);
        self::assertSame($before,Settings::revision()); self::assertCount(0,FakeHttp::$requests);
    }
    public function test_first_client_requires_secret(): void {
        Configuration::clear('oauth'); $before=Settings::revision();
        self::assertFalse(Configuration::save_oauth('new.apps.googleusercontent.com','')['success']);
        self::assertSame($before,Settings::revision());
    }
    public function test_blank_secret_preserves_same_client_and_its_consent(): void {
        $this->candidate(); $before=Settings::revision();
        $r=Configuration::save_oauth('pending.apps.googleusercontent.com','',$before);
        self::assertTrue($r['success']); self::assertFalse($r['changed']);
        self::assertSame($before,Settings::revision());
        self::assertSame('pending-refresh',Candidate::read('oauth')['secrets'][Options::OAUTH_REFRESH_TOKEN]);
    }
    public function test_changed_client_with_secret_requires_new_consent(): void {
        $this->candidate(); $r=Configuration::save_oauth('new.apps.googleusercontent.com','GOCSPX-new',Settings::revision());
        self::assertTrue($r['success']); self::assertFalse(Candidate::state('oauth')['ready']);
        self::assertSame('active-refresh',Options::get_secret(Options::OAUTH_REFRESH_TOKEN));
    }
    public function test_disconnect_clears_active_and_pending_authorizations_atomically(): void {
        $this->candidate(); $before=Settings::revision();
        $r=OAuthFlow::disconnect(false,$before); self::assertTrue($r['success']);
        self::assertSame('',Options::get_secret(Options::OAUTH_REFRESH_TOKEN));
        self::assertSame('GOCSPX-active',Options::get_secret(Options::OAUTH_CLIENT_SECRET));
        $pending=Candidate::read('oauth'); self::assertSame('pending.apps.googleusercontent.com',$pending['values'][Options::OAUTH_CLIENT_ID]);
        self::assertSame('GOCSPX-pending',$pending['secrets'][Options::OAUTH_CLIENT_SECRET]);
        self::assertArrayNotHasKey(Options::OAUTH_REFRESH_TOKEN,$pending['secrets']);
        self::assertArrayNotHasKey(Options::OAUTH_EMAIL,$pending['values']);
        self::assertArrayNotHasKey(Options::OAUTH_SCOPES,$pending['values']);
        self::assertFalse(Candidate::state('oauth')['ready']);
        self::assertFalse(Configuration::activate('oauth',Settings::revision())['success']);
        self::assertCount(0,FakeHttp::$requests);
    }
    public function test_disconnect_rolls_back_both_authorizations_on_candidate_write_failure(): void {
        $this->candidate(); $before=Settings::revision(); $GLOBALS['f3_test_write_fail'][Candidate::OAUTH]=true;
        $r=OAuthFlow::disconnect(false,$before); self::assertFalse($r['success']);
        self::assertSame($before,Settings::revision()); self::assertTrue(Candidate::state('oauth')['ready']);
        self::assertSame('active-refresh',Options::get_secret(Options::OAUTH_REFRESH_TOKEN));
    }
    public function test_disconnect_is_idempotent_and_scoped_to_selected_connection(): void {
        $this->candidate(); Connections::create('other','Other');
        Connections::run('other',function(){ $this->candidate(); });
        self::assertTrue(OAuthFlow::disconnect()['success']); $revision=Settings::revision();
        self::assertTrue(OAuthFlow::disconnect(false,$revision)['success']); self::assertSame($revision,Settings::revision());
        self::assertTrue(Connections::run('other',static fn()=>Candidate::state('oauth')['ready']));
    }
    public function test_stale_or_unauthorized_disconnect_preserves_both_grants(): void {
        $this->candidate(); $old=Settings::revision(); Settings::save([Options::HTTP_TIMEOUT=>31]); $before=Settings::revision();
        self::assertSame('f3_google_configuration_conflict',OAuthFlow::disconnect(false,$old)['error_code']);
        $GLOBALS['f3_test_caps']=false; self::assertSame('f3_google_forbidden',OAuthFlow::disconnect()['error_code']);
        self::assertSame($before,Settings::revision()); self::assertCount(0,FakeHttp::$requests);
    }
    public function test_gtm_denial_blocks_oauth_activation_and_keeps_active_grant(): void {
        $this->candidate(); Options::set(Connections::BINDINGS,['gtm_container_path'=>'accounts/123/containers/456']);
        $before=Settings::revision(); FakeHttp::push('/token',200,['access_token'=>'pending-access','expires_in'=>3600]);
        FakeHttp::push('tagmanager.googleapis.com',403,['error'=>['status'=>'PERMISSION_DENIED']]);
        $r=Configuration::activate('oauth',$before);
        self::assertFalse($r['success']); self::assertSame('f3_google_candidate_access',$r['error_code']);
        self::assertSame($before,Settings::revision()); self::assertSame('active-refresh',Options::get_secret(Options::OAUTH_REFRESH_TOKEN));
        self::assertStringContainsString('accounts/123/containers/456',FakeHttp::last()['url']);
    }
    public function test_gtm_access_is_checked_before_successful_oauth_activation(): void {
        $this->candidate(); Options::set(Connections::BINDINGS,['gtm_container_path'=>'accounts/123/containers/456']);
        FakeHttp::push('/token',200,['access_token'=>'pending-access','expires_in'=>3600]);
        FakeHttp::push('tagmanager.googleapis.com',200,['path'=>'accounts/123/containers/456']);
        $r=Configuration::activate('oauth',Settings::revision());
        self::assertTrue($r['success'],json_encode($r)); self::assertTrue($r['resource_access_validated']);
        self::assertSame('pending-refresh',Options::get_secret(Options::OAUTH_REFRESH_TOKEN)); self::assertNull(Candidate::read('oauth'));
    }
    public function test_pending_only_disconnect_requires_new_consent(): void {
        $this->candidate(); Settings::save([],[],[Options::OAUTH_REFRESH_TOKEN]);
        self::assertTrue(OAuthFlow::disconnect()['success']); self::assertFalse(Candidate::state('oauth')['ready']);
        self::assertSame('pending.apps.googleusercontent.com',Candidate::oauth_value(Options::OAUTH_CLIENT_ID));
        self::assertCount(0,FakeHttp::$requests);
    }
    public function test_disconnect_invalidates_an_inflight_callback(): void {
        $this->candidate(); $state=bin2hex(random_bytes(32));
        \Fator3\McpGoogle\Cache::set('f3_mcp_google_oauth_state_'.$state,OAuthFlow::state_record(),600);
        OAuthFlow::disconnect();
        $r=OAuthFlow::complete(new \WP_REST_Request(['state'=>$state,'code'=>'old-consent']));
        self::assertSame('f3_google_configuration_conflict',$r['error_code']); self::assertCount(0,FakeHttp::$requests);
        self::assertFalse(Candidate::state('oauth')['ready']);
    }
    public function test_stale_client_edit_does_not_overwrite_prepared_application(): void {
        $old=Settings::revision(); $this->candidate(); $before=Settings::revision();
        $r=Configuration::save_oauth('new.apps.googleusercontent.com','GOCSPX-new',$old);
        self::assertSame('f3_google_configuration_conflict',$r['error_code']); self::assertSame($before,Settings::revision());
    }
    public function test_screen_separates_active_pending_and_application_without_exposing_secrets(): void {
        $this->candidate(); $_GET=['section'=>'connection','method'=>'oauth'];
        ob_start(); Admin::render(); $html=(string)ob_get_clean();
        $doc=new \DOMDocument(); @$doc->loadHTML('<?xml encoding="UTF-8">'.$html); $xp=new \DOMXPath($doc);
        self::assertSame(3,$xp->query('//section[contains(@class,"f3-oauth-step")][@aria-labelledby]')->length);
        foreach (['active@example.test','pending@example.test','Pronta para ativar','Ao trocar o Client ID'] as $text) self::assertStringContainsString($text,$html);
        foreach (['GOCSPX-active','GOCSPX-pending','active-refresh','pending-refresh','A chave é verificada no Google antes de ser salva.'] as $secret) self::assertStringNotContainsString($secret,$html);
        self::assertCount(0,FakeHttp::$requests);
    }
    public function test_unconfigured_screen_explains_disabled_authorization(): void {
        Configuration::clear('oauth'); $_GET=['section'=>'connection','method'=>'oauth'];
        ob_start(); Admin::render(); $html=(string)ob_get_clean();
        $doc=new \DOMDocument(); @$doc->loadHTML('<?xml encoding="UTF-8">'.$html); $xp=new \DOMXPath($doc);
        self::assertSame(1,$xp->query('//form[@aria-label="Autorizar conta Google"]//button[@disabled]')->length);
        self::assertStringContainsString('Salve o Client ID e o Client secret na etapa 1',$html);
        self::assertSame(0,$xp->query('//button[text()="Usar OAuth"]')->length);
    }
}
