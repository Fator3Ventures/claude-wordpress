<?php
/** 0.32.0: uninstall removes every declared secret, with or without purge. No filesystem operation in this test. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options,Connections,Uninstall};
final class Uninstall032Test extends TestCase {
    private const PREFIX='f3_mcp_google_';
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;$GLOBALS['f3_test_multisite']=false;
        Connections::select('default');
    }
    protected function tearDown(): void {
        $GLOBALS['f3_test_multisite']=false;Connections::select('default');
    }
    /** @return string[] option names of every declared secret, in the default and in a named connection */
    private function secret_options(): array {
        $out=[];
        foreach (Options::secret_names() as $name) {
            $this->assertStringStartsWith(self::PREFIX,$name);
            $out[]=$name;
            $out[]=self::PREFIX.'conn_shop_'.substr($name,strlen(self::PREFIX));
        }
        return $out;
    }
    public function test_site_uninstall_without_purge_removes_every_declared_secret(): void {
        $this->assertContains('f3_mcp_google_mp_secret',Options::secret_names());
        $secrets=$this->secret_options();
        foreach ($secrets as $name) $GLOBALS['f3_test_options'][$name]='cipher-'.$name;
        $removed=['f3_mcp_google_sa_subject','f3_mcp_google_oauth_email','f3_mcp_google_oauth_scopes','f3_mcp_google_token_index','f3_mcp_google_conn_shop_oauth_email','f3_mcp_google_conn_shop_token_index','f3_mcp_google_lock_x'];
        foreach ($removed as $name) $GLOBALS['f3_test_options'][$name]='v';
        $kept=[Options::MAX_ROWS=>500,Options::GA_DEFAULT_PROPERTY=>'properties/1','f3_mcp_google_conn_shop_ga_default_property'=>'properties/2',Options::OAUTH_CLIENT_ID=>'client-id.apps.googleusercontent.com','f3_mcp_google_conversion_delivery'=>['target'=>'ga4']];
        foreach ($kept as $name=>$value) $GLOBALS['f3_test_options'][$name]=$value;
        $GLOBALS['f3_test_options'][Options::ENABLED]=true;
        Uninstall::site();
        foreach (array_merge($secrets,$removed) as $name) $this->assertArrayNotHasKey($name,$GLOBALS['f3_test_options'],$name);
        foreach ($kept as $name=>$value) $this->assertSame($value,$GLOBALS['f3_test_options'][$name]??null,$name);
        $this->assertFalse($GLOBALS['f3_test_options'][Options::ENABLED]);
    }
    /** uninstall.php loads a fixed class subset: the secret list must resolve with exactly that subset. */
    public function test_uninstall_loader_resolves_the_secret_list_without_other_classes(): void {
        $root=dirname(__DIR__);
        $this->assertSame(1,preg_match("/foreach \(\[([^\]]+)\] as \\\$f3_google_class\)/",(string)file_get_contents($root.'/uninstall.php'),$m));
        $code='define("ABSPATH","/");spl_autoload_register(static function($c){fwrite(STDERR,"autoload:".$c);exit(3);});'
            .'foreach (['.$m[1].'] as $c) require_once '.var_export($root.'/includes/',true).'.$c.".php";'
            .'require_once '.var_export($root.'/includes/Uninstall.php',true).';'
            .'echo json_encode(\Fator3\McpGoogle\Uninstall::secret_suffixes());';
        exec(escapeshellarg(PHP_BINARY).' -r '.escapeshellarg($code).' 2>&1',$out,$status);
        $this->assertSame(0,$status,implode("\n",$out));
        $suffixes=json_decode(implode('',$out),true);
        $this->assertEqualsCanonicalizing(array_map(static fn($n)=>substr($n,strlen(self::PREFIX)),Options::secret_names()),$suffixes);
    }
}
