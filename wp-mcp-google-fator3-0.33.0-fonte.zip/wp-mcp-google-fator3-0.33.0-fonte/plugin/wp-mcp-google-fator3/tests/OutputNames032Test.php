<?php
/**
 * 0.32.0 A (resto): paginação e valor de verificação não podem sair com nomes que o
 * transporte MCP 0.43.0 mascara ("[redigido]"). Só dublês em memória (options, FakeHttp).
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options,Connections};
use Fator3\McpGoogle\Ads\Abilities as AdsAbilities;
use Fator3\McpGoogle\Ads\WriteAbilities as AdsWriteAbilities;
use Fator3\McpGoogle\Analytics\AdminWrite;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\SiteVerification\Abilities as VerificationAbilities;
require_once __DIR__.'/Support/McpRedactionRule.php';
final class OutputNames032Test extends TestCase {
    private static ?string $key=null;
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;
        Connections::select('default');FakeHttp::reset();
        if (null===self::$key) { $pair=openssl_pkey_new(['private_key_bits'=>2048,'private_key_type'=>OPENSSL_KEYTYPE_RSA]);$k='';openssl_pkey_export($pair,$k);self::$key=$k; }
        Options::set(Options::ENABLED,true);Options::set(Options::ADS_ENABLED,true);Options::set(Options::GA_ENABLED,true);
        Options::set(Options::AUTH_MODE,'service_account');
        Options::set_secret(Options::ADS_DEVELOPER_TOKEN,'dev-token-ads-1234');
        Options::set_secret(Options::SA_JSON,(string)wp_json_encode(['type'=>'service_account','project_id'=>'p','private_key'=>self::$key,'client_email'=>'robo@p.iam.gserviceaccount.com','token_uri'=>'https://oauth2.googleapis.com/token']));
        foreach (['ads','ga','siteverification','any'] as $c) { Credentials::remember(Credentials::cache_key(Credentials::scopes_for($c)),'cached-'.$c,3500); foreach (Credentials::scopes_for($c) as $s) Credentials::remember(Credentials::cache_key([$s]),'cached-'.$c,3500); }
        \Fator3\McpGoogle\Cache::set(Discovery::cache_key('analytics-admin-v1alpha'),json_decode((string)file_get_contents(__DIR__.'/fixtures/discovery/analyticsadmin-v1alpha.json'),true),86400);
        \Fator3\McpGoogle\Cache::set(Discovery::cache_key('analytics-admin-v1beta'),json_decode((string)file_get_contents(__DIR__.'/fixtures/discovery/analyticsadmin-v1beta.json'),true),86400);
        \Fator3\McpGoogle\Cache::set(Discovery::cache_key('site-verification'),json_decode((string)file_get_contents(__DIR__.'/fixtures/discovery/siteverification-v1.json'),true),86400);
        AdsAbilities::register();AdsWriteAbilities::register();AdminWrite::register();VerificationAbilities::register();\Fator3\McpGoogle\Generic\Abilities::register();
    }
    private function run_ability(string $name,array $input): array {
        $a=wp_get_ability($name);$this->assertNotNull($a,$name);
        $r=$a->execute($input);$this->assertIsArray($r);$this->assertTrue($r['success']??false,$name.': '.wp_json_encode($r));
        return $r;
    }
    private function clean(array $r,string $name): void {
        $this->assertArrayNotHasKey('next_page_token',$r,$name);
        $this->assertArrayNotHasKey('token',$r,$name);
        $this->assertSame([],McpRedactionRule::masked_paths($r),$name.': '.wp_json_encode($r));
    }
    private function page(string $token,array $rows): void {
        FakeHttp::push('googleAds:search',200,['results'=>$rows,'nextPageToken'=>$token,'fieldMask'=>'campaign.id']);
    }
    public function test_ads_search_two_pages_through_next_page_and_page_token(): void {
        foreach (['table','raw'] as $format) {
            FakeHttp::reset();
            $this->page('pagina-2',[['campaign'=>['id'=>'1']],['campaign'=>['id'=>'2']]]);
            $first=$this->run_ability('ads/search',['customer_id'=>'1234567890','query'=>'SELECT campaign.id FROM campaign','limit'=>2,'format'=>$format]);
            $this->assertSame('pagina-2',$first['next_page'],$format);
            $this->clean($first,'ads/search '.$format);
            $this->assertArrayNotHasKey('pageToken',json_decode((string)FakeHttp::last()['body'],true));
            FakeHttp::push('googleAds:search',200,['results'=>[['campaign'=>['id'=>'3']]],'fieldMask'=>'campaign.id']);
            $second=$this->run_ability('ads/search',['customer_id'=>'1234567890','query'=>'SELECT campaign.id FROM campaign','limit'=>2,'format'=>$format,'page_token'=>$first['next_page']]);
            $this->assertSame('pagina-2',json_decode((string)FakeHttp::last()['body'],true)['pageToken'],$format);
            $this->assertNull($second['next_page'],$format);
            $this->assertArrayHasKey('next_page',$second);
            $this->clean($second,'ads/search '.$format);
        }
        $desc=wp_get_ability('ads/search')->get_input_schema()['properties']['page_token']['description'];
        $this->assertStringContainsString('next_page',$desc);$this->assertStringNotContainsString('next_page_token',$desc);
    }
    public function test_ads_read_route_emits_next_page(): void {
        $this->page('pagina-b',[['asset'=>['id'=>'1']]]);
        $r=$this->run_ability('ads/list-assets',['customer_id'=>'1234567890','limit'=>1]);
        $this->assertSame('pagina-b',$r['next_page']);
        $this->clean($r,'ads/list-assets');
        FakeHttp::push('googleAds:search',200,['results'=>[]]);
        $r=$this->run_ability('ads/list-assets',['customer_id'=>'1234567890','limit'=>1,'page_token'=>'pagina-b']);
        $this->assertSame('pagina-b',json_decode((string)FakeHttp::last()['body'],true)['pageToken']);
        $this->assertNull($r['next_page']);$this->clean($r,'ads/list-assets');
    }
    public function test_ga_list_users_and_get_settings_emit_next_page(): void {
        FakeHttp::push('/v1alpha/properties/123/accessBindings',200,['accessBindings'=>[['name'=>'properties/123/accessBindings/1']],'nextPageToken'=>'continue']);
        $r=$this->run_ability('ga/list-users',['property_id'=>'123','max_pages'=>1]);
        $this->assertTrue($r['truncated']);$this->assertSame('continue',$r['next_page']);
        $this->clean($r,'ga/list-users');
        FakeHttp::push('/v1alpha/properties/123/accessBindings',200,['accessBindings'=>[]]);
        $r=$this->run_ability('ga/list-users',['property_id'=>'123','page_token'=>'continue']);
        $this->assertStringContainsString('pageToken=continue',FakeHttp::last()['url']);
        $this->assertFalse($r['truncated']);$this->assertNull($r['next_page']);$this->clean($r,'ga/list-users');
        FakeHttp::push('/v1alpha/properties/123',200,['name'=>'properties/123']);
        foreach (['dataRetentionSettings','attributionSettings','googleSignalsSettings'] as $res) FakeHttp::push('/v1alpha/properties/123/'.$res,200,['name'=>'properties/123/'.$res]);
        FakeHttp::push('/v1alpha/properties/123/keyEvents',200,['keyEvents'=>[],'nextPageToken'=>'ke-2']);
        FakeHttp::push('/v1alpha/properties/123/',200,[]);
        $r=$this->run_ability('ga/get-settings',['property_id'=>'123','max_pages'=>1]);
        $this->assertSame('ke-2',$r['truncated_sections']['key_events']['next_page']??null,wp_json_encode($r['truncated_sections']));
        $this->assertArrayNotHasKey('next_page_token',$r['truncated_sections']['key_events']);
        $this->assertSame([],McpRedactionRule::masked_paths($r['truncated_sections']));
    }
    public function test_siteverification_get_token_emits_verification_value_and_data_without_token(): void {
        $value='<meta name="google-site-verification" content="verification-test-value">';
        FakeHttp::push('/siteVerification/v1/token',200,['method'=>'META','token'=>$value]);
        $r=$this->run_ability('siteverification/get-token',['site'=>['type'=>'SITE','identifier'=>'https://example.test/'],'verification_method'=>'META']);
        $this->assertSame($value,$r['verification_value']);
        $this->assertSame(['method'=>'META'],$r['data']);
        $this->assertArrayNotHasKey('token',$r['data']);
        $this->clean($r,'siteverification/get-token');
        $this->assertStringContainsString('verification_value',$r['next_step']);
        $schema=wp_get_ability('siteverification/get-token')->get_output_schema();
        $this->assertSame(['string'],(array)$schema['properties']['verification_value']['type']);
        $this->assertArrayNotHasKey('token',$schema['properties']);
        $this->assertArrayNotHasKey('token',$schema['properties']['data']['properties']??[]);
    }
    public function test_execute_read_adds_next_page_without_touching_raw_data(): void {
        FakeHttp::push('/v1beta/accounts',200,['accounts'=>[['name'=>'accounts/1']],'nextPageToken'=>'acc-2']);
        $r=$this->run_ability('google/execute-read',['api'=>'analytics-admin-v1beta','method'=>'analyticsadmin.accounts.list','query'=>['pageSize'=>1]]);
        $this->assertSame('acc-2',$r['next_page']);
        $this->assertSame('acc-2',$r['data']['nextPageToken'],'dados brutos inalterados');
        // Só o próprio campo bruto é mascarado pelo transporte; next_page chega legível.
        $this->assertSame(['.data.nextPageToken'],McpRedactionRule::masked_paths($r));
        FakeHttp::push('/v1beta/accounts',200,['accounts'=>[]]);
        $r=$this->run_ability('google/execute-read',['api'=>'analytics-admin-v1beta','method'=>'analyticsadmin.accounts.list','query'=>['pageToken'=>'acc-2']]);
        $this->assertStringContainsString('pageToken=acc-2',FakeHttp::last()['url']);
        $this->assertArrayNotHasKey('next_page',$r,'sem nextPageToken bruto, campo ausente');
        $schema=wp_get_ability('google/execute-read')->get_output_schema();
        $this->assertSame(['string','null'],$schema['properties']['next_page']['type']);
        $this->assertSame([],McpRedactionRule::masked_paths(['output_schema'=>$schema]));
    }
}
