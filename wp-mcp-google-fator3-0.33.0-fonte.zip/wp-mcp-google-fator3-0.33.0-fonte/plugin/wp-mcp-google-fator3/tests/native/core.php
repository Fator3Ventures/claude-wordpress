<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options,Connections,Policy,Settings,Recovery};
use Fator3\McpGoogle\Integration\{ServiceApi};
wp_set_current_user(1);Options::set(Options::ENABLED,true);$checks=[];
// This disposable lab may contain grants from a previous successful run.
foreach(array_keys(Connections::registry()) as $cid){Connections::run($cid,fn()=>Options::set(ServiceApi::GRANTS,[]));}
function corecheck($ok,$name){global $checks;if(!$ok)throw new RuntimeException($name);$checks[]=$name;}
function coreoption($key,$value){$r=F3Base_Options::pelo_canal('ability',fn()=>F3Base_Options::gravar($key,$value,F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao($key)));corecheck(!empty($r['persisted']),$key.': '.json_encode($r));}
$cfg=F3Base_Options::ler('f3base_gsc');$cfg['ativo']=true;$cfg['inicio']=(new DateTimeImmutable('-3 days',new DateTimeZone('America/Los_Angeles')))->format('Y-m-d');coreoption('f3base_gsc_property',home_url('/'));coreoption('f3base_gsc',$cfg);
F3Base_Gsc::validar_propriedade();
corecheck(F3Base_Gsc::configuracao()['ready'],'real Core GSC structurally ready');
corecheck(F3Base_Gsc::resumo()['sdk']==='registrado','Core discovered real Google consumer');
corecheck(F3Base_Gsc::resumo()['servico']['resolution']==='not_granted','real Core projects absence');
Connections::create('analytics','Analytics');
$r=Connections::run('analytics',function(){Options::batch_verified([Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',Connections::SERVICES=>['gsc'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]],[Options::OAUTH_CLIENT_SECRET=>'fixture-secret',Options::OAUTH_REFRESH_TOKEN=>'fixture-refresh']);return ServiceApi::configure(['consumer_id'=>'base-site-core-fator3','enabled'=>true,'expected_revision'=>Settings::revision()]);});corecheck($r['success'],'grant on non-default connection');
$merge=Connections::run('analytics',fn()=>Fator3\McpGoogle\Setup::apply(['services'=>['gtm'=>'write'],'merge'=>true]));corecheck($merge['success']&&$merge['services_after']['gsc']['enabled'],'Lab additive GTM preserves GSC service');
$reduction=Connections::run('analytics',fn()=>Fator3\McpGoogle\Setup::apply(['services'=>['gtm'=>'write']]));corecheck(!$reduction['success']&&$reduction['error_code']==='f3_google_service_reduction_confirmation_required','Lab unconfirmed replacement refused before Core GSC access changes');
$s=F3Base_Gsc::resumo();corecheck($s['servico']['resolution']==='resolved'&&$s['servico']['connection_id']==='analytics','real Core resolves non-default connection');
Connections::run('analytics',fn()=>Fator3\McpGoogle\Auth\Credentials::invalidate_cache());
// Reset only this disposable laboratory's collection state to exercise a fresh request.
$wpdb->query('UPDATE '.F3Base_Gsc_Acervo::tabela()." SET estado='reiniciar', atualizado_em=0, proxima_tentativa=0");
F3Base_Options::atualizar_estado('f3base_gsc_estado',static fn($s)=>array_merge($s,['proxima_tentativa'=>0]));
corecheck(Connections::id()==='default','diagnostic restores selected context');
corecheck(!str_contains(json_encode(F3Base_Gsc::resumo()),'CORE_NESTED_SECRET_MARKER'),'nested marker absent in real Core projection');
$http=[];add_filter('pre_http_request',static function($pre,$args,$url)use(&$http){$http[]=$url;if(str_contains($url,'/token'))$body=['access_token'=>'native-fixture','expires_in'=>3600];elseif(str_contains($url,'/searchAnalytics/query')){$q=json_decode($args['body'],true);$body=['responseAggregationType'=>'byPage','rows'=>[['keys'=>[$q['startDate'],home_url('/page')],'clicks'=>1,'impressions'=>10,'ctr'=>0.1,'position'=>2]]];}else return $pre;return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];},1,3);
$before=count($http);$beforeCron=Fator3\McpGoogle\Automation\CronHistory::summary('analytics');$s=F3Base_Gsc::resumo();corecheck(count($http)===$before,'summary no network');
$held=Fator3\McpGoogle\Lock::acquire('jobs-tick',60);$yield=Fator3\McpGoogle\Automation\Executor::run();corecheck(($yield['state']??'')==='yielded','executor yields while SDK remains independent');
wp_set_current_user(0);$r=F3Base_Gsc::coletar();Fator3\McpGoogle\Lock::release($held);corecheck(!empty($r['ok']),'real Core collection: '.json_encode($r));
corecheck(get_current_user_id()===0,'no human impersonation');$afterCron=Fator3\McpGoogle\Automation\CronHistory::summary('analytics');corecheck($beforeCron['last_run']===$afterCron['last_run'],'Core query does not fabricate executor pass');
corecheck(count($http)>=2,'real Google reader called simulated token and query');
$due=time()+600;$beforeHttp=count($http);F3Base_Options::atualizar_estado('f3base_gsc_estado',static fn($s)=>array_merge($s,['proxima_tentativa'=>$due]));$wait=F3Base_Gsc::coletar();corecheck(($wait['codigo']??'')==='aguardando_servico'&&count($http)===$beforeHttp,'Core future quota has no early Google dispatch');F3Base_Options::atualizar_estado('f3base_gsc_estado',static fn($s)=>array_merge($s,['proxima_tentativa'=>0]));
$count=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Gsc_Acervo::tabela().' WHERE publicado=1');corecheck($count>0,'Core committed snapshot');
wp_set_current_user(1);
// Failure injection through WP query filter keeps production sources untouched.
$filter=static function($sql){return str_starts_with($sql,'SHOW COLUMNS FROM')&&str_contains($sql,'f3base_gsc_linhas')?'SELECT fixture_column_failure FROM missing_fixture_table':$sql;};$wpdb->suppress_errors(true);add_filter('query',$filter);corecheck(!F3Base_Gsc::configuracao()['ready'],'structural read refusal makes Core unready');remove_filter('query',$filter);

F3Base_Gsc::agendar();corecheck((bool)wp_next_scheduled(F3Base_Gsc::EVENTO),'Core agenda present');
wp_schedule_single_event(time()+3600,F3Base_Gsc::CONTINUAR);$cfg['ativo']=false;coreoption('f3base_gsc',$cfg);F3Base_Gsc::agendar();corecheck(!wp_next_scheduled(F3Base_Gsc::EVENTO)&&!wp_next_scheduled(F3Base_Gsc::CONTINUAR),'explicit disable clears both hooks');
$cfg['ativo']=true;coreoption('f3base_gsc',$cfg);F3Base_Gsc::agendar();
$grant=Connections::run('analytics',fn()=>Options::get(ServiceApi::GRANTS));
Options::set(ServiceApi::GRANTS,$grant);corecheck(F3Base_Gsc::resumo()['servico']['resolution']==='ambiguous','Core reports ambiguous grant instead of selecting current connection');Options::set(ServiceApi::GRANTS,[]);
$grantName=Connections::run('analytics',fn()=>Options::storage_name(ServiceApi::GRANTS));
$refuse=static function($sql)use($grantName){return str_contains($sql,'option_value')&&str_contains($sql,$grantName)?'SELECT fixture_missing_grant FROM fixture_missing_table':$sql;};add_filter('query',$refuse);try { corecheck(F3Base_Gsc::resumo()['servico']['resolution']==='unreadable','Core reports grant read refusal without connection fallback'); } finally {remove_filter('query',$refuse);}
finishLab('core',['google_http'=>'simulated','snapshots'=>$count]);
