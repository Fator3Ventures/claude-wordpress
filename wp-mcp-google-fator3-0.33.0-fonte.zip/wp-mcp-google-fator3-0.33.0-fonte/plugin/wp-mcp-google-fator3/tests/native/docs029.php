<?php
require __DIR__ . '/common.php';
use Fator3\McpGoogle\Documentation;

function manuals029(): array {
    return array_values(array_filter(get_included_files(), static fn($path) => str_contains($path, '/includes/Data/Manuals/')));
}
$index = Documentation::read([]);
verifyLab('Index returns public identities and reads no manual body', !empty($index['documents']) && manuals029() === []);
$guide = 'GUIA-'.F3_MCP_GOOGLE_VERSION.'.md';
$meta = array_column($index['documents'], null, 'document')[$guide];
verifyLab('Index keeps packaging paths private', array_keys($meta) === ['document','description','bytes','revision']);
foreach ([
    [['document'=>'../README.md'], 'f3_google_document_missing'],
    [['document'=>$guide, 'offset'=>1], 'f3_google_document_revision'],
    [['document'=>$guide, 'expected_revision'=>str_repeat('0',64)], 'f3_google_document_revision'],
    [['document'=>$guide, 'limit_bytes'=>255], 'f3_google_document_range'],
    [['document'=>$guide, 'offset'=>$meta['bytes'] + 1], 'f3_google_document_range']
] as [$input, $code]) {
    $error = Documentation::read($input);
    verifyLab('Refuse invalid request before reading a manual: '.json_encode($input), ($error['error_code']??'') === $code && manuals029() === []);
}
wp_set_current_user(0);
verifyLab('Download enforces administrator gate before reading files', is_wp_error(Documentation::content($guide)) && manuals029() === []);
wp_set_current_user(1);
$body = Documentation::content($guide);
verifyLab('Download reads just one manual and matches its exact bytes', is_string($body) && strlen($body) === $meta['bytes'] && hash('sha256',$body) === $meta['revision'] && count(manuals029()) === 1);
$offset = 0;
$joined = '';
do {
    $page = Documentation::read(['document'=>$guide, 'limit_bytes'=>256, 'offset'=>$offset, 'expected_revision'=>$meta['revision']]);
    verifyLab('Paginated guide preserves UTF-8 at byte '.$offset, !empty($page['success']) && mb_check_encoding($page['content'],'UTF-8') && $page['returned_bytes'] <= 256);
    $joined .= $page['content'];
    $offset = $page['next_offset'];
} while ($offset !== null);
verifyLab('Paginated MCP guide equals admin download', $joined === $body && count(manuals029()) === 1);
$end = Documentation::read(['document'=>$guide, 'offset'=>$meta['bytes'], 'expected_revision'=>$meta['revision']]);
verifyLab('Offset at end returns a complete empty page', $end['content'] === '' && !$end['has_more'] && $end['next_offset'] === null);
$file = manuals029()[0];
$original = file_get_contents($file);
try {
    file_put_contents($file, "<?php return 'truncated';\n");
    $bad = Documentation::read(['document'=>$guide]);
    verifyLab('Damaged installed document fails closed', ($bad['error_code']??'') === 'f3_google_document_integrity' && !isset($bad['content']));
    unlink($file);
    verifyLab('Missing installed document also fails closed', Documentation::content($guide)->get_error_code() === 'f3_google_document_integrity');
} finally {
    file_put_contents($file, $original);
}
$indexPath = F3_MCP_GOOGLE_DIR . 'includes/Data/DocumentIndex.php';
$indexBytes = file_get_contents($indexPath);
try {
    file_put_contents($indexPath, "<?php return [];\n");
    $invalid = Documentation::read([]);
    verifyLab('A partial index fails closed without returning inaccurate metadata', ($invalid['error_code']??'') === 'f3_google_document_integrity' && !isset($invalid['documents']));
} finally {
    file_put_contents($indexPath, $indexBytes);
}
$index = 'caller-index';
$documents = 'caller-documents';
$legacy = require F3_MCP_GOOGLE_DIR . 'includes/Data/Documentation.php';
verifyLab('Full map remains compatible without overwriting caller variables', $index === 'caller-index' && $documents === 'caller-documents' && $legacy[$guide] === $joined);
finishLab('docs029', ['manuals_loaded_for_index'=>0, 'manuals_loaded_for_guide'=>1]);
