<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options,Connections,Settings,Policy,Ads\ArchiveStore,Ads\KeywordPlanner};
$account='7777777777';
Options::batch_verified([Options::ENABLED=>true,Options::ADS_ENABLED=>true,Connections::SERVICES=>['ads'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]]);
$newReceipt=static function(string $observed) use($account) {
 $id=bin2hex(random_bytes(16));
 $r=ArchiveStore::put('keywordread',$account.'-'.$id,['id'=>$id,'observed_at'=>$observed,'kind'=>'metrics','complete'=>true,'count'=>0]);
 if (!$r['success'])throw new RuntimeException('Cannot seed a receipt');
 return $id;
};
$old=$newReceipt('2025-12-05T10:10:00+00:00');
for($i=0;$i<200;++$i)$newReceipt('2025-12-06T10:10:00+00:00');
$range=['customer_id'=>$account,'from'=>'2025-12-05','to'=>'2025-12-05','limit'=>1];
$first=KeywordPlanner::archive($range);
verifyLab('Filtered page can be empty and still has a stable continuation',$first['success'] && $first['reads']===[] && is_int($first['next_before_sequence']));
$late=$newReceipt('2025-12-05T23:59:00+00:00');
$last=KeywordPlanner::archive($range+['before_sequence'=>$first['next_before_sequence']]);
verifyLab('Continuation excludes concurrent insert with no duplicate or omission',$last['success'] && array_column($last['reads'],'archive_id')===[$old] && $last['next_before_sequence']===null);
$fresh=KeywordPlanner::archive($range);
verifyLab('A fresh list sees the newer matching receipt',array_column($fresh['reads'],'archive_id')===[$late]);
finishLab('archive-window028',['seeded'=>202,'utc'=>true]);
