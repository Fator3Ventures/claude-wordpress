<?php
/** Exercise the actual admin action, WordPress nonce gate, result store and rendered page. */
require __DIR__ . '/common.php';
require_once ABSPATH . 'wp-admin/includes/template.php';

use Fator3\McpGoogle\{Admin,Cache,Connections,Options,Policy,Settings};

function diagnosticPage029( string $connection ): string {
    $_GET = array( 'section' => 'advanced', 'advanced_panel' => 'diagnostics', 'connection_id' => $connection );
    $_POST = array();
    $_REQUEST = $_GET;
    $_SERVER['REQUEST_METHOD'] = 'GET';
    ob_start();
    Admin::render();
    return (string) ob_get_clean();
}

function diagnosticSubmit029( array $post ): array {
    $_GET = array();
    $_POST = $post;
    $_REQUEST = $_POST;
    $_SERVER['REQUEST_METHOD'] = 'POST';
    $outcome = array();
    $redirect = static function ( $url ) use ( &$outcome ) {
        parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $outcome );
        throw new RuntimeException( 'finish-diagnostic-action' );
    };
    $die = static function () use ( &$outcome ) {
        return static function () use ( &$outcome ) {
            $outcome = array( 'blocked' => true );
            throw new RuntimeException( 'finish-diagnostic-action' );
        };
    };
    // Intercept only the terminating redirect or rejection; authorization, nonce and callback are real.
    add_filter( 'wp_redirect', $redirect );
    add_filter( 'wp_die_handler', $die );
    try {
        do_action( 'admin_post_f3_mcp_google_test' );
    } catch ( RuntimeException $error ) {
        if ( 'finish-diagnostic-action' !== $error->getMessage() ) {
            throw $error;
        }
    } finally {
        remove_filter( 'wp_redirect', $redirect );
        remove_filter( 'wp_die_handler', $die );
    }
    return $outcome;
}

function diagnosticXpath029( string $html ): DOMXPath {
    $dom = new DOMDocument();
    @$dom->loadHTML( '<?xml encoding="UTF-8">' . $html );
    return new DOMXPath( $dom );
}

$connection = 'diag029';
$other = 'diag029other';
Connections::create( $connection, 'Diagnóstico de homologação' );
Connections::create( $other, 'Segunda conexão de homologação' );
Connections::select( $connection );
$seed = Options::batch_verified(
    array(
        Options::ENABLED => true, Options::AUTH_MODE => 'oauth', Settings::AUTH_READY => true,
        Options::OAUTH_CLIENT_ID => 'diagnostic.apps.googleusercontent.com',
        Options::OAUTH_SCOPES => array( 'https://www.googleapis.com/auth/webmasters.readonly' ),
        Connections::SERVICES => array( 'gsc' => 'read' ),
        Connections::BINDINGS => array( 'gsc_site_url' => 'sc-domain:example.invalid' ),
        Policy::OPTION => array( 'mode' => 'identity', 'services' => array() ),
    ),
    array( Options::OAUTH_CLIENT_SECRET => 'fixture-client', Options::OAUTH_REFRESH_TOKEN => 'fixture-refresh' )
);
verifyLab( 'Configured dedicated diagnostic connection', ! empty( $seed['success'] ) );
$revision = Settings::revision();
$requests = array();
$mutate = false;
$fixture = static function ( $pre, $args, $url ) use ( &$requests, &$mutate ) {
    $requests[] = $url;
    if ( str_contains( $url, 'oauth2.googleapis.com/token' ) ) {
        $body = array( 'access_token' => 'fixture-access', 'expires_in' => 3600 );
    } elseif ( str_contains( $url, '/webmasters/v3/sites/' ) ) {
        if ( $mutate ) {
            Options::set( Connections::BINDINGS, array( 'gsc_site_url' => 'sc-domain:changed.invalid' ) );
        }
        $body = array( 'siteUrl' => 'sc-domain:example.invalid', 'permissionLevel' => 'siteOwner' );
    } else {
        return new WP_Error( 'fixture_endpoint', 'Unexpected diagnostic request' );
    }
    return array( 'response' => array( 'code' => 200 ), 'headers' => array(), 'body' => wp_json_encode( $body ) );
};
add_filter( 'pre_http_request', $fixture, 1, 3 );

$html = diagnosticPage029( $connection );
$xpath = diagnosticXpath029( $html );
$form = $xpath->query( '//form[input[@name="action" and @value="f3_mcp_google_test"]]' )->item(0);
verifyLab( 'Explicit action includes selected connection, revision, nonce and help', $form
    && $form->getAttribute( 'method' ) === 'post' && $xpath->query( '//*[@id="f3-diagnostic-help"]' )->length === 1
    && $form->getAttribute( 'aria-describedby' ) === 'f3-diagnostic-help'
    && $xpath->query( 'input[@name="connection_id"]', $form )->item(0)->getAttribute('value') === $connection
    && $xpath->query( 'input[@name="expected_revision"]', $form )->item(0)->getAttribute('value') === $revision
    && $xpath->query( 'input[@name="_wpnonce"]', $form )->length === 1 );
foreach ( array( 'Conferir identidade' => 'identity', 'Conferir serviços e recursos' => 'services' ) as $label => $panel ) {
    $href = $xpath->query( '//a[normalize-space(text())="'.$label.'"]' )->item(0)->getAttribute('href');
    parse_str( (string) wp_parse_url( $href, PHP_URL_QUERY ), $args );
    verifyLab( 'Scoped configuration link '.$panel, $args['section'] === 'connection' && $args['connection_panel'] === $panel && $args['connection_id'] === $connection );
}
verifyLab( 'Opening the empty result does not contact the provider', $requests === array() && str_contains( $html, 'Nenhum resultado disponível' ) );

$post = array( 'connection_id' => $connection, 'expected_revision' => $revision, '_wpnonce' => wp_create_nonce( 'f3_mcp_google_test' ),
    'section' => 'connection', 'connection_panel' => 'permissions' );
$rejected = diagnosticSubmit029( array_replace( $post, array( '_wpnonce' => 'invalid' ) ) );
verifyLab( 'Invalid nonce blocks the real action', ! empty( $rejected['blocked'] ) && ! $requests );
$rejected = diagnosticSubmit029( array_replace( $post, array( 'expected_revision' => str_repeat( '0', 64 ) ) ) );
verifyLab( 'Stale form returns to diagnostic before contacting Google', ( $rejected['f3_status'] ?? '' ) === 'diagnostic_stale'
    && $rejected['advanced_panel'] === 'diagnostics' && $rejected['connection_id'] === $connection && ! $requests );
$rejected = diagnosticSubmit029( array_diff_key( $post, array( 'connection_id' => true ) ) );
verifyLab( 'Missing connection never runs the default test', ( $rejected['f3_status'] ?? '' ) === 'diagnostic_stale' && ! $requests );
$rejected = diagnosticSubmit029( array_diff_key( $post, array( 'expected_revision' => true ) ) );
verifyLab( 'Missing revision never runs the selected test', ( $rejected['f3_status'] ?? '' ) === 'diagnostic_stale' && ! $requests );
$viewer = wp_insert_user( array( 'user_login' => 'diag029viewer', 'user_pass' => wp_generate_password(), 'role' => 'subscriber' ) );
wp_set_current_user( $viewer );
$viewer_post = array_replace( $post, array( '_wpnonce' => wp_create_nonce( 'f3_mcp_google_test' ) ) );
$rejected = diagnosticSubmit029( $viewer_post );
verifyLab( 'Authenticated subscriber with their own valid nonce cannot see or run a test', ! empty( $rejected['blocked'] ) && diagnosticPage029( $connection ) === '' && ! $requests );
wp_set_current_user( 0 );
verifyLab( 'Anonymous navigation cannot expose diagnostic controls', diagnosticPage029( $connection ) === '' && ! $requests );
wp_set_current_user( 1 );
$status = diagnosticSubmit029( $post );
verifyLab( 'Successful POST returns to the canonical result for its connection', ( $status['f3_status'] ?? '' ) === 'tested'
    && $status['section'] === 'advanced' && $status['advanced_panel'] === 'diagnostics' && $status['connection_id'] === $connection && ! isset( $status['connection_panel'] ), $status );
$record = Cache::get( Admin::diagnostic_key() );
verifyLab( 'Explicit test reads the bound resource and records its identity and revision', is_array( $record ) && $record['connection_id'] === $connection
    && $record['auth_mode'] === 'oauth' && $record['revision'] === $revision && Settings::revision() === $revision
    && ( array_column( $record['checks'], 'status', 'name' )['live_gsc'] ?? '' ) === 'passed'
    && count( array_filter( $requests, static fn($url) => str_contains($url,'/webmasters/v3/sites/') ) ) === 1, $requests );
$count = count( $requests );
$html = diagnosticPage029( $connection );
$xpath = diagnosticXpath029( $html );
verifyLab( 'Service results and local checks occupy separate groups', str_contains( $html, 'Acesso aos serviços Google' )
    && $xpath->query( '//details[summary="Verificações locais do plugin" and not(@open)]//th[@scope="row"]' )->length > 0
    && ! str_contains( $html, 'Resultado desatualizado' ) && count($requests) === $count );
verifyLab( 'Switching connections does not reveal the prior result', str_contains( diagnosticPage029( $other ), 'Nenhum resultado disponível' ) && count($requests) === $count );
$second_admin = wp_insert_user( array( 'user_login' => 'diag029admin', 'user_pass' => wp_generate_password(), 'role' => 'administrator' ) );
wp_set_current_user( $second_admin );
verifyLab( 'Second administrator sees only their own result', str_contains( diagnosticPage029( $connection ), 'Nenhum resultado disponível' )
    && count($requests) === $count );
wp_set_current_user( 1 );
Connections::select( $connection );
$foreign = array_replace( $record, array( 'connection_id' => $other, 'message' => 'foreign-evidence-marker' ) );
$foreign['checks'][0]['detail'] = 'foreign-evidence-marker';
Cache::set( Admin::diagnostic_key(), $foreign, 3600 );
$html = diagnosticPage029( $connection );
verifyLab( 'Mismatched stored identity never renders foreign checks or raw detail', str_contains( $html, 'Resultado desatualizado' ) && ! str_contains( $html, 'foreign-evidence-marker' ) );
$malformed = $record;
$malformed['passed']++;
Cache::set( Admin::diagnostic_key(), $malformed, 3600 );
verifyLab( 'Inconsistent counters are rejected before displaying a verdict', str_contains( diagnosticPage029( $connection ), 'Diagnóstico armazenado inválido' ) );
$malformed = $record;
$malformed['checks'][0]['detail'] = array( 'unexpected value' );
Cache::set( Admin::diagnostic_key(), $malformed, 3600 );
verifyLab( 'Malformed detail is rejected before rendering it', str_contains( diagnosticPage029( $connection ), 'Diagnóstico armazenado inválido' ) );
Cache::set( Admin::diagnostic_key(), $record, 3600 );
$mutate = true;
$status = diagnosticSubmit029( $post );
verifyLab( 'Change during the Google read discards its result', ( $status['f3_status'] ?? '' ) === 'diagnostic_changed' && Cache::get( Admin::diagnostic_key() ) === $record, $status );
$count = count($requests);
verifyLab( 'Earlier saved revision renders as history without retesting', str_contains( diagnosticPage029( $connection ), 'Resultado desatualizado' ) && count($requests) === $count );
$mutate = false;
$post['expected_revision'] = Settings::revision();
$key = 'pre_set_transient_' . Admin::diagnostic_key();
$keep = static fn() => $record;
add_filter( $key, $keep );
try {
    $status = diagnosticSubmit029( $post );
} finally {
    remove_filter( $key, $keep );
    remove_filter( 'pre_http_request', $fixture, 1 );
}
verifyLab( 'Storage failure is reported separately from a recorded test', ( $status['f3_status'] ?? '' ) === 'diagnostic_store_failed'
    && $status['advanced_panel'] === 'diagnostics' && Cache::get( Admin::diagnostic_key() ) === $record, $status );
finishLab( 'diagnostics029', array( 'provider' => 'Synthetic OAuth and Search Console responses via pre_http_request; all other endpoints blocked' ) );
