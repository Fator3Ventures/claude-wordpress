<?php
/** Exercise the real protected WordPress resource actions and verified transient writes. */
require __DIR__ . '/common.php';
use Fator3\McpGoogle\{Admin, Cache, Connections, Options, Settings};

function resourcePost033(string $action, array $input): array {
    $_GET = [];
    $_POST = $_REQUEST = $input + [
        'action' => $action, 'section' => 'connection', 'connection_panel' => 'services',
        '_wpnonce' => wp_create_nonce($action), 'connection_id' => 'default',
        'expected_revision' => Settings::revision(),
    ];
    $query = [];
    $capture = static function ($url) use (&$query) {
        parse_str(wp_parse_url($url, PHP_URL_QUERY), $query);
        throw new RuntimeException('resource-redirect-033');
    };
    add_filter('wp_redirect', $capture);
    try {
        do_action('admin_post_'.$action);
    } catch (RuntimeException $e) {
        if ($e->getMessage() !== 'resource-redirect-033') {
            throw $e;
        }
    } finally {
        remove_filter('wp_redirect', $capture);
    }
    return $query;
}

Options::set(Connections::SERVICES, []);
$action = 'f3_mcp_google_discover';
$cache = Admin::feedback_key('discovery_sheets');
$result = resourcePost033($action, ['service' => 'sheets']);
verifyLab('Disabled service shows failure in real POST and returns to selected panel',
    ($result['f3_status'] ?? '') === 'discovery_failed' && $result['connection_panel'] === 'services');
$stale = resourcePost033($action, ['service'=>'sheets', 'expected_revision'=>'obsolete']);
verifyLab('Obsolete form rejected', $stale['f3_status'] === 'discovery_stale');
$marker = ['previous' => 'result', 'revision' => Settings::revision()];
Cache::set($cache, $marker, 600);
$preserve = static fn() => $marker;
add_filter('pre_set_transient_'.$cache, $preserve);
try {
    $result = resourcePost033($action, ['service'=>'sheets']);
    verifyLab('Failed cache write has separate feedback and prior result is intact',
        $result['f3_status'] === 'discovery_store_failed' && Cache::get($cache) === $marker);
} finally {
    remove_filter('pre_set_transient_'.$cache, $preserve);
}
foreach (['gtm','gsc'] as $service) {
    $result = resourcePost033('f3_google_operation', ['section'=>$service, 'operation'=>'load-choices', 'choice_kind'=>$service]);
    verifyLab('Dedicated '.$service.' screen reports refusal and preserves section',
        $result['f3_status'] === 'discovery_failed' && $result['section'] === $service);
}
finishLab('discovery033', ['provider'=>'blocked in disposable lab']);
