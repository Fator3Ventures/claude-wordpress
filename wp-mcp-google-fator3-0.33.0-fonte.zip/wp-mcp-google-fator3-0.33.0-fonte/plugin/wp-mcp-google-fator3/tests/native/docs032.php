<?php
/**
 * 0.32.0 D: the whole installed documentation is read through the real MCP HTTP transport
 * (tools/call wp-mcp-ultimate-execute-ability -> google/documentation), page by page with
 * expected_revision, and every document matches the packaged DocumentIndex.php byte for byte.
 * A must-use probe records every outbound HTTP request made by the web server while serving
 * the MCP calls: reading documentation must not make any.
 */
require __DIR__ . '/common.php';
require __DIR__ . '/rpc.php';
use Fator3\McpGoogle\Options as O;

$probeDir = WP_CONTENT_DIR . '/mu-plugins';
$probe = $probeDir . '/f3-docs032-http-probe.php';
$log = getenv('F3_FIXTURE_ROOT') . '/docs032-http.log';
$credentials = [];
$counts = ['documents' => 0, 'pages' => 0, 'bytes' => 0];
try {
    O::set(O::ENABLED, true);
    if (!is_dir($probeDir)) mkdir($probeDir, 0755, true);
    @unlink($log);
    file_put_contents($probe, '<?php
if (PHP_SAPI === "cli") return;
add_action("rest_api_init", static function () { file_put_contents(' . var_export($log, true) . ', json_encode(["event"=>"rest","sapi"=>PHP_SAPI])."\n", FILE_APPEND); });
add_filter("pre_http_request", static function ($pre, $args, $url) { file_put_contents(' . var_export($log, true) . ', json_encode(["event"=>"http","sapi"=>PHP_SAPI,"host"=>parse_url($url, PHP_URL_HOST)])."\n", FILE_APPEND); return $pre; }, 0, 3);
');
    $credential = rpc_identityLab();
    $credentials[] = [$credential['uuid'], 1];
    $auth = $credential['auth'];

    $packaged = require F3_MCP_GOOGLE_DIR . 'includes/Data/DocumentIndex.php';
    verifyLab('Packaged DocumentIndex.php is readable', is_array($packaged) && $packaged !== []);

    $index = rpcLab('google/documentation', []);
    verifyLab('MCP index succeeds', !empty($index['success']) && is_array($index['documents'] ?? null), $index);
    verifyLab('MCP index identifies slug and installed version', ($index['slug'] ?? '') === 'wp-mcp-google-fator3' && ($index['plugin_version'] ?? '') === F3_MCP_GOOGLE_VERSION && F3_MCP_GOOGLE_VERSION === expectedLab('candidate'), [$index['slug'] ?? null, $index['plugin_version'] ?? null]);
    $listed = array_column($index['documents'], null, 'document');
    $a = array_keys($listed); $b = array_keys($packaged); sort($a); sort($b);
    verifyLab('MCP index lists exactly the packaged documents (order follows the public allowlist)', $a === $b && count($a) === count($index['documents']), [$a, $b]);
    foreach (['README.md', 'ESPECIFICACAO.md', 'GUIA-' . expectedLab('candidate') . '.md', 'AGENT-GUIDE.md', 'RECEITAS.md', 'MIGRACAO.md', 'CHANGELOG.md'] as $required) {
        verifyLab('Index contains ' . $required, isset($listed[$required]));
    }
    verifyLab('Index no longer offers the previous guide', !isset($listed['GUIA-' . expectedLab('baseline') . '.md']) && !isset($listed['GUIA-0.30.0.md']));

    foreach ($packaged as $id => $entry) {
        verifyLab('Index metadata equals package for ' . $id, $listed[$id]['bytes'] === $entry['bytes'] && $listed[$id]['revision'] === $entry['revision'], [$listed[$id], $entry]);
        $offset = 0;
        $body = '';
        $pages = 0;
        do {
            $page = rpcLab('google/documentation', ['document' => $id, 'offset' => $offset, 'limit_bytes' => 65536, 'expected_revision' => $entry['revision']]);
            $ok = !empty($page['success']) && ($page['document'] ?? '') === $id && ($page['revision'] ?? '') === $entry['revision']
                && ($page['offset'] ?? -1) === $offset && is_string($page['content'] ?? null) && strlen($page['content']) === ($page['returned_bytes'] ?? -1)
                && ($page['total_bytes'] ?? -1) === $entry['bytes'];
            if (!$ok) verifyLab('Page of ' . $id . ' at offset ' . $offset . ' is consistent', false, $page);
            $body .= $page['content'];
            $offset = $page['next_offset'];
            ++$pages;
        } while ($offset !== null && $pages < 1000);
        verifyLab('Read ' . $id . ' to next_offset null in ' . $pages . ' page(s)', $offset === null);
        verifyLab('Bytes and SHA-256 of ' . $id . ' match DocumentIndex.php', strlen($body) === $entry['bytes'] && hash('sha256', $body) === $entry['revision'], [strlen($body), $entry['bytes']]);
        ++$counts['documents'];
        $counts['pages'] += $pages;
        $counts['bytes'] += strlen($body);
    }

    $guide = 'GUIA-' . expectedLab('candidate') . '.md';
    foreach ([
        'document outside the index (previous guide)' => [['document' => 'GUIA-' . expectedLab('baseline') . '.md'], 'f3_google_document_missing'],
        'arbitrary path ../wp-config.php' => [['document' => '../wp-config.php'], 'f3_google_document_missing'],
        'source path docs/AGENT-GUIDE.md' => [['document' => 'docs/AGENT-GUIDE.md'], 'f3_google_document_missing'],
        'divergent expected_revision' => [['document' => $guide, 'expected_revision' => str_repeat('0', 64)], 'f3_google_document_revision'],
        'continuation without expected_revision' => [['document' => $guide, 'offset' => 256], 'f3_google_document_revision'],
    ] as $label => [$params, $code]) {
        $r = rpcLab('google/documentation', $params);
        verifyLab('MCP refuses ' . $label, empty($r['success']) && ($r['error_code'] ?? '') === $code && !isset($r['content']), $r);
    }

    $events = is_file($log) ? array_map(static fn($l) => json_decode($l, true), file($log, FILE_IGNORE_NEW_LINES)) : [];
    $rest = array_filter($events, static fn($e) => ($e['event'] ?? '') === 'rest');
    $labHost = parse_url(getenv('F3_LAB_URL'), PHP_URL_HOST);
    $http = array_values(array_filter($events, static fn($e) => ($e['event'] ?? '') === 'http'));
    // Loopback requests WordPress itself may make while serving (e.g. spawning wp-cron) are not external.
    $external = array_values(array_filter($http, static fn($e) => !in_array($e['host'] ?? '', [$labHost, '127.0.0.1', 'localhost'], true)));
    verifyLab('HTTP probe was active in the server process serving MCP', count($rest) >= $counts['pages'], count($rest));
    verifyLab('Serving the documentation made no external HTTP request', $external === [], $external);
    $counts['server_loopback_requests'] = count($http);
} finally {
    @unlink($probe);
    foreach ($credentials as [$uuid, $uid]) WP_Application_Passwords::delete_application_password($uid, $uuid);
}
finishLab('docs032', $counts + ['transport' => 'real MCP HTTP tools/call wp-mcp-ultimate-execute-ability', 'server_external_http_requests' => 0]);
