<?php
/** Measure the first documentation index and one short manual in an isolated WP process. */
require __DIR__ . '/common.php';
use Fator3\McpGoogle\Documentation;

$measurements = [];
foreach (['index'=>[], 'guide'=>['document'=>'GUIA-'.F3_MCP_GOOGLE_VERSION.'.md']] as $task => $input) {
    gc_collect_cycles();
    memory_reset_peak_usage();
    $before = memory_get_usage();
    $start = hrtime(true);
    $response = Documentation::read($input);
    $elapsed = hrtime(true) - $start;
    $peak = memory_get_peak_usage() - $before;
    verifyLab('Document benchmark returns '.$task, !empty($response['success']));
    $measurements[$task] = ['peak_additional_bytes'=>$peak, 'elapsed_ns'=>$elapsed];
    unset($response);
}
finishLab('document-cost029', ['measurements'=>$measurements]);
