<?php
require __DIR__.'/common.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
$manifest=json_decode(file_get_contents(getenv('F3_LAB_MANIFEST')),true);
foreach(['meta','linkedin','pipedrive'] as $name){$zip=new ZipArchive();$zip->open($manifest['inputs'][$name]['path']);$zip->extractTo(WP_PLUGIN_DIR);$zip->close();wp_clean_plugins_cache(false);$p='wp-mcp-'.$name.'-fator3/wp-mcp-'.$name.'-fator3.php';$result=activate_plugin($p);verifyLab('Original companion activation '.$name,!is_wp_error($result)&&is_plugin_active($p));}
finishLab('companions028');
