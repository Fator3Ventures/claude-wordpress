<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\ConversionDelivery as D;
update_option('f3base_linkedin_partner_id','12345');
update_option('f3base_linkedin_conversion_id','67890');
update_option('f3base_conversoes_transporte',['ga4'=>'navegador','google_ads'=>'navegador','linkedin'=>'ambos']);
$raw=F3Base_Conversoes_Contexto::snapshot(['contract'=>'site-conversion-purposes/1.1.0']);
verifyLab('Original Core emits valid both transport',!empty($raw['ok'])&&$raw['data']['purposes'][0]['destinations']['linkedin']['transport']['effective']==='ambos');
verifyLab('Baseline Google rejects published snapshot',D::core_transport()===['ok'=>false,'code'=>'core_unsupported']);
update_option('f3base_conversoes_transporte',['ga4'=>'navegador','google_ads'=>'navegador','linkedin'=>'navegador']);
verifyLab('Baseline accepts browser control',D::core_transport()['ok']===true);
finishLab('baseline026');
