<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Connections as C,Options as O,Settings,Ads\Archive};
$default_bindings=O::get(C::BINDINGS,[]);
C::create('browserqa','Conexão de homologação');
C::run('browserqa',static function() {
 O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,C::SERVICES=>['ads'=>'read','gsc'=>'read'],C::BINDINGS=>['ads_customer_id'=>'1234567890','gsc_site_url'=>'sc-domain:example.com']]);
 O::set(Archive::CONFIG,['1234567890'=>['enabled'=>false,'datasets'=>['campaign'],'backfill_days'=>45,'revisit_days'=>3]]);
});
C::run('browserqa',static function(){
 O::batch_verified([O::AUTH_MODE=>'oauth',Settings::AUTH_READY=>true,O::OAUTH_CLIENT_ID=>'active.apps.googleusercontent.com',O::OAUTH_EMAIL=>'active@example.invalid'],[O::OAUTH_CLIENT_SECRET=>'GOCSPX-active030',O::OAUTH_REFRESH_TOKEN=>'active-refresh030']);
 Fator3\McpGoogle\Auth\Candidate::save('oauth',[O::OAUTH_CLIENT_ID=>'pending.apps.googleusercontent.com',O::OAUTH_EMAIL=>'pending@example.invalid'],[O::OAUTH_CLIENT_SECRET=>'GOCSPX-pending030',O::OAUTH_REFRESH_TOKEN=>'pending-refresh030']);
});
$expiry=time()+1200;
$token=WP_Session_Tokens::get_instance(1)->create($expiry);
$subscriber=wp_create_user('ui030subscriber',bin2hex(random_bytes(16)));
$subscriber_token=WP_Session_Tokens::get_instance($subscriber)->create($expiry);
$cookie_set=static fn($id,$session)=>[
 AUTH_COOKIE=>wp_generate_auth_cookie($id,$expiry,'auth',$session),
 LOGGED_IN_COOKIE=>wp_generate_auth_cookie($id,$expiry,'logged_in',$session),
];
$args=['url'=>getenv('F3_LAB_URL'),'cookies'=>$cookie_set(1,$token),'subscriber'=>$cookie_set($subscriber,$subscriber_token),'scratch'=>getenv('F3_FIXTURE_ROOT')];
if (getenv('CODEX_PRIMARY_RUNTIME_NODE_MODULES')) { putenv('NODE_PATH='.getenv('CODEX_PRIMARY_RUNTIME_NODE_MODULES')); }
$process=proc_open(['node',dirname(__DIR__).'/browser/admin030.cjs'],[['pipe','r'],['pipe','w'],['file',getenv('F3_FIXTURE_ROOT').'/browser-error.log','a']],$pipes);
fwrite($pipes[0],wp_json_encode($args));fclose($pipes[0]);$output=stream_get_contents($pipes[1]);fclose($pipes[1]);$exit=proc_close($process);
WP_Session_Tokens::get_instance(1)->destroy($token);WP_Session_Tokens::get_instance($subscriber)->destroy($subscriber_token);
if ($exit!==0) { throw new RuntimeException('Browser failed. See private lab/browser-error.log.'); }
$checks_browser=json_decode($output,true,64,JSON_THROW_ON_ERROR);
foreach($checks_browser['checks'] as $name) { verifyLab($name,true); }
verifyLab('Browser actually executed checks',count($checks_browser['checks'])>=20);
wp_cache_flush(); // Compare persistent values written by separate HTTP workers.
verifyLab('Changes confined to selected connection',C::run('browserqa',static fn()=>C::registry()['browserqa']['label'])==='Nome editado no navegador' && O::get(C::BINDINGS,[])===$default_bindings );
$bindings=C::run('browserqa',static fn()=>O::get(C::BINDINGS,[]));
verifyLab('Disabling Ads without JavaScript preserves its previous binding',$bindings['ads_customer_id']==='1234567890',$bindings);
verifyLab('Browser OAuth edits persisted only in chosen connection',C::run('browserqa',static fn()=>Fator3\McpGoogle\Auth\Candidate::oauth_value(O::OAUTH_CLIENT_ID))==='changed.apps.googleusercontent.com');
finishLab('browser030',['browser'=>$checks_browser['browser'],'viewports'=>$checks_browser['viewports'],'external_http'=>'blocked','provider'=>'none']);
