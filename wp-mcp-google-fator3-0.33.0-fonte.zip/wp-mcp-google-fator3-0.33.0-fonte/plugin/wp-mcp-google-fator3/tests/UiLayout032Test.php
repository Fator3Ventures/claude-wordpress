<?php
/** 0.32.0 admin layout: sections, Help groups, status strip, read-only Overview and service account steps. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Admin, Connections, Options, Policy, Settings, Cache};
use Fator3\McpGoogle\Admin\OverviewScreen;

final class UiLayout032Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = [];
        $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1;
        $_GET = $_POST = $_REQUEST = []; FakeHttp::reset();
        Options::batch_verified([Options::ENABLED=>true, Options::AUTH_MODE=>'oauth', Settings::AUTH_READY=>true,
            Options::OAUTH_CLIENT_ID=>'ui.apps.googleusercontent.com', Options::OAUTH_EMAIL=>'ui@example.test',
            Connections::SERVICES=>['ads'=>'read','gsc'=>'write'], Connections::BINDINGS=>['gsc_site_url'=>'sc-domain:example.test'],
            Policy::OPTION=>['mode'=>'identity','services'=>[]]],
            [Options::OAUTH_CLIENT_SECRET=>'GOCSPX-ui-secret', Options::OAUTH_REFRESH_TOKEN=>'ui-refresh-secret']);
    }
    protected function tearDown(): void { $_GET = $_POST = $_REQUEST = []; FakeHttp::reset(); $GLOBALS['f3_test_caps'] = true; }

    private function page(array $get): string {
        $_GET = $get + ['connection_id'=>Connections::id()]; $_REQUEST = $_GET;
        ob_start(); Admin::render(); return (string) ob_get_clean();
    }
    private function xpath(string $html): \DOMXPath {
        $dom = new \DOMDocument(); @$dom->loadHTML('<?xml encoding="UTF-8">'.$html); return new \DOMXPath($dom);
    }

    public function test_document_groups_cover_every_document_exactly_once(): void {
        $listed = array_merge(...array_values(Admin::document_groups()));
        self::assertSame(count($listed), count(array_unique($listed)), 'A document appears in two groups.');
        $documents = array_keys(Admin::documents());
        sort($listed); sort($documents);
        self::assertSame($documents, $listed);
    }

    public function test_default_and_unknown_sections_open_overview_and_panels_keep_their_section(): void {
        self::assertSame('overview', array_key_first(Admin::SECTIONS));
        self::assertSame('help', array_key_last(Admin::SECTIONS));
        foreach ([[], ['section'=>'nope'], ['section'=>'nope','connection_panel'=>'services']] as $get) {
            $_GET = $get; self::assertSame('overview', Admin::section(), json_encode($get));
        }
        $_GET = ['connection_panel'=>'services']; self::assertSame('connection', Admin::section());
        $_GET = ['advanced_panel'=>'operations']; self::assertSame('advanced', Admin::section());
        $_GET = ['section'=>'diagnostics']; self::assertSame('advanced', Admin::section());
        $_GET = ['section'=>'help']; self::assertSame([], Admin::panel_args('help'));
        // A POST keeps returning to the section and panel of its form.
        $_GET = []; $_POST = ['section'=>'connection','connection_panel'=>'permissions'];
        parse_str((string) parse_url(Admin::url('saved'), PHP_URL_QUERY), $q);
        self::assertSame(['connection','permissions','saved'], [$q['section'],$q['connection_panel'],$q['f3_status']]);
    }

    public function test_every_section_has_one_h1_one_current_tab_and_a_four_item_status_strip(): void {
        foreach (array_keys(Admin::SECTIONS) as $section) {
            $html = $this->page(['section'=>$section]);
            $xp = $this->xpath($html);
            self::assertSame(1, $xp->query('//h1')->length, $section);
            self::assertSame('Fator3 MCP Google', trim($xp->query('//h1')->item(0)->textContent));
            $current = $xp->query('//nav[contains(@class,"f3-navigation")]/a[@aria-current="page"]');
            self::assertSame(1, $current->length, $section);
            self::assertSame(Admin::SECTIONS[$section], $current->item(0)->textContent);
            self::assertSame(4, $xp->query('//ul[@class="f3-status-list"]/li')->length, $section);
            self::assertSame(count(Admin::SECTIONS), $xp->query('//nav[contains(@class,"f3-navigation")]/a')->length);
            foreach ($xp->query('//nav') as $nav) self::assertNotSame('', $nav->getAttribute('aria-label'), $section);
        }
        self::assertCount(0, FakeHttp::$requests, 'Rendering never contacts Google.');
    }

    public function test_documents_are_listed_only_in_help_with_authenticated_downloads(): void {
        $help = $this->page(['section'=>'help']);
        $xp = $this->xpath($help);
        foreach (Admin::documents() as $name => $label) {
            $links = $xp->query('//a[contains(@href,"action=f3_mcp_google_documentation") and contains(@href,"document='.rawurlencode($name).'")]');
            self::assertSame(1, $links->length, $name);
            self::assertStringContainsString('_wpnonce=', $links->item(0)->getAttribute('href'));
            self::assertSame($label, $links->item(0)->textContent);
        }
        self::assertStringContainsString('google/documentation', $help);
        foreach (['next_offset','expected_revision','limit_bytes'] as $term) self::assertStringContainsString($term, $help);
        foreach (['connection','advanced','overview','incidents'] as $section) {
            $html = $this->page(['section'=>$section]);
            self::assertStringNotContainsString('action=f3_mcp_google_documentation', $html, $section);
            self::assertSame(1, $this->xpath($html)->query('//p[@class="f3-footer"]/a[contains(@href,"section=help")]')->length, $section);
        }
    }

    public function test_readiness_runs_only_where_it_is_shown(): void {
        $connection = $this->page(['section'=>'connection']);
        self::assertStringContainsString('Na Visão geral', $connection);
        self::assertStringNotContainsString('id="f3-next-steps"', $connection);
        $overview = $this->page(['section'=>'overview']);
        $xp = $this->xpath($overview);
        self::assertSame(1, $xp->query('//section[@id="f3-next-steps"]//ol[@class="f3-checklist"]')->length);
        self::assertGreaterThan(0, $xp->query('//section[@id="f3-next-steps"]//li[contains(@class,"f3-check")]/a[contains(@href,"section=")]')->length);
        self::assertStringNotContainsString('Na Visão geral', $overview);
        // Services of this connection with level and default resource.
        self::assertStringContainsString('sc-domain:example.test', $overview);
        self::assertStringContainsString('Leitura e escrita', $overview);
        self::assertCount(0, FakeHttp::$requests);
    }

    public function test_status_markers_carry_text_and_escape_dynamic_values(): void {
        self::assertTrue(Connections::rename('Rótulo & "teste"', Settings::revision())['success']);
        $html = $this->page(['section'=>'overview']);
        self::assertStringNotContainsString('Rótulo & "teste"', $html);
        self::assertStringContainsString('Rótulo &amp; &quot;teste&quot;', $html);
        foreach ($this->xpath($html)->query('//span[contains(@class,"f3-badge")]') as $badge) {
            self::assertNotSame('', trim($badge->textContent), 'A badge never relies on color alone.');
            self::assertMatchesRegularExpression('/f3-badge--(success|attention|error|neutral)/', $badge->getAttribute('class'));
        }
        foreach (['GOCSPX-ui-secret','ui-refresh-secret'] as $secret) self::assertStringNotContainsString($secret, $html);
    }

    public function test_service_account_steps_are_derived_from_local_state(): void {
        Options::set(Options::AUTH_MODE, 'service_account');
        $xp = $this->xpath($this->page(['section'=>'connection','method'=>'service_account']));
        $states = [];
        foreach ($xp->query('//ol[contains(@class,"f3-steps")]/li') as $li) {
            preg_match('/f3-step--([a-z]+)/', $li->getAttribute('class'), $m); $states[] = $m[1];
        }
        // No key: first step is current, granting access is neutral, services are selected.
        self::assertSame(['current','todo','neutral','done','todo'], $states);
        self::assertSame(1, $xp->query('//ol[contains(@class,"f3-steps")]/li[@aria-current="step"]')->length);
        Options::set(Connections::SERVICES, []);
        $xp = $this->xpath($this->page(['section'=>'connection','method'=>'service_account']));
        self::assertSame(1, $xp->query('//li[contains(@class,"f3-step--todo")][span="Selecionar serviços e recursos"]')->length);
    }

    public function test_overview_and_strip_reuse_one_readiness_read(): void {
        $first = OverviewScreen::readiness();
        self::assertSame($first, OverviewScreen::readiness());
        self::assertArrayHasKey('checks', $first);
    }
}
