<?php
/** 0.32.0 B: duplicate_event refusal with a visible equivalent is a met postcondition, not a permanent failure. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options,Connections,Records};
use Fator3\McpGoogle\Automation\{Scheduling,ExecutorSchedule,Executor,Jobs};
use Fator3\McpGoogle\Storage\Maintenance;
final class Scheduling032Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;$GLOBALS['f3_test_cron_duplicates']=true;
        Connections::select('default');
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f) if(is_file($f)) unlink($f);
        foreach(['context','volatile'] as $field) { $p=new \ReflectionProperty(Scheduling::class,$field);$p->setAccessible(true);$p->setValue(null,[]); }
        Options::set(Options::ENABLED,true);FakeHttp::reset();
        $this->assertTrue(ExecutorSchedule::ensure()['success']);
    }
    protected function tearDown(): void { $GLOBALS['f3_test_write_fail']=[];$GLOBALS['f3_test_cron_duplicates']=false;Connections::select('default'); }
    private function hourly(int $at): void {
        $cron=get_option('cron',[]);unset($cron['version']);
        $cron[$at][Maintenance::HOOK][md5(serialize([]))]=['schedule'=>'hourly','args'=>[],'interval'=>3600];ksort($cron);
        update_option('cron',$cron+['version'=>2]);
    }
    private function maintenance_events(): array {
        $out=[];foreach(_get_cron_array() as $at=>$events) foreach(($events[Maintenance::HOOK]??[]) as $row) $out[(int)$at]=$row['schedule'];
        return $out;
    }
    private function intent(string $op,?int $at,$rec=false,int $interval=0): array {
        $m=new \ReflectionMethod(Scheduling::class,'intent');$m->setAccessible(true);
        return $m->invoke(null,$op,Maintenance::HOOK,$at,[],$rec,$interval);
    }
    private function observe(array $intent,$api): array {
        $m=new \ReflectionMethod(Scheduling::class,'observe');$m->setAccessible(true);
        return $m->invoke(null,$intent,$api);
    }
    private function errors(): array {
        return array_values(array_filter(Scheduling::status()['active_errors'],static fn($r)=>($r['hook']??'')===Maintenance::HOOK));
    }
    public function test_a_duplicate_refusal_with_equivalent_is_confirmed_without_active_error(): void {
        $this->hourly(time()+300);
        $r=Scheduling::schedule(Maintenance::HOOK,time()+15,false);
        $this->assertSame('duplicate_event',$r['original_code'],json_encode($r));
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertSame('confirmed',$r['state']);
        $this->assertFalse($r['api_success']);
        $this->assertNull($r['error_code']);
        $this->assertSame(array_key_first($this->maintenance_events()),$r['equivalent_at']);
        $this->assertSame([],$this->errors());
        $obs=array_values(array_filter(Scheduling::status()['observations'],static fn($o)=>$o['hook']===Maintenance::HOOK&&$o['operation']==='schedule'));
        $this->assertSame('confirmed',$obs[0]['state']);$this->assertIsInt($obs[0]['equivalent_at']);
        $this->assertNotSame('degraded',Executor::status()['health']);
    }
    public function test_b_reconcile_resolves_legacy_duplicate_rows_and_status_is_clean(): void {
        $at=time()-200000;
        // Ocorrência horária pendente do mesmo hook e argumentos: o fato lido que autoriza a resolução.
        $this->hourly($hourly=time()+300);
        $row=$this->intent('schedule',$at)+['id'=>Records::id(),'at'=>$at-15,'success'=>false,'state'=>'failed','read_success'=>true,'postcondition'=>false,
            'original_code'=>'duplicate_event','api_success'=>false,'error_code'=>'f3_google_cron_schedule_postcondition','diagnostic_persisted'=>true,'diagnostic_error_code'=>null];
        $slot=Maintenance::HOOK.'|'.$row['origem'].'|schedule';
        Options::set(Scheduling::OPTION,['observations'=>[$slot=>$row],'active_errors'=>['legacy-1'=>$row],'last_errors'=>[$slot=>$row],'untracked_errors'=>0]);
        $this->assertCount(1,$this->errors());
        $this->assertSame('degraded',Executor::status()['health']);
        $r=Scheduling::reconcile();
        $this->assertTrue($r['success'],json_encode($r));$this->assertSame(1,$r['resolved']);
        $this->assertSame([],$this->errors());
        $s=Scheduling::status();
        $last=array_values(array_filter($s['last_errors'],static fn($e)=>$e['id']===$row['id']))[0];
        $this->assertSame('duplicate_event_equivalent',$last['resolved_by']);$this->assertIsInt($last['resolved_at']);
        $this->assertSame($hourly,$last['equivalent_at']);
        $this->assertSame([],$s['active_errors']);
        $this->assertNotSame('degraded',Executor::status()['health']);
    }
    private function legacy_row(): array {
        $at=time()-200000;
        $row=$this->intent('schedule',$at)+['id'=>Records::id(),'at'=>$at-15,'success'=>false,'state'=>'failed','read_success'=>true,'postcondition'=>false,
            'original_code'=>'duplicate_event','api_success'=>false,'error_code'=>'f3_google_cron_schedule_postcondition','diagnostic_persisted'=>true,'diagnostic_error_code'=>null];
        $slot=Maintenance::HOOK.'|'.$row['origem'].'|schedule';
        Options::set(Scheduling::OPTION,['observations'=>[$slot=>$row],'active_errors'=>['legacy-1'=>$row],'last_errors'=>[$slot=>$row],'untracked_errors'=>0]);
        return $row;
    }
    public function test_b2_reconcile_keeps_legacy_duplicate_row_without_pending_occurrence_until_one_is_read(): void {
        $row=$this->legacy_row();
        // Nenhuma ocorrência do hook de manutenção no cron lido.
        $this->assertSame([],$this->maintenance_events());
        $r=Scheduling::reconcile();
        $this->assertTrue($r['success'],json_encode($r));$this->assertSame(0,$r['resolved']??0);
        $this->assertCount(1,$this->errors());
        $this->assertSame($row['id'],$this->errors()[0]['id']);
        $this->assertArrayNotHasKey('resolved_by',$this->errors()[0]);
        $this->assertSame('degraded',Executor::status()['health']);
        // Ocorrência com outros argumentos não é equivalente.
        $cron=get_option('cron',[]);unset($cron['version']);
        $cron[time()+120][Maintenance::HOOK][md5(serialize(['x']))]=['schedule'=>'hourly','args'=>['x'],'interval'=>3600];ksort($cron);
        update_option('cron',$cron+['version'=>2]);
        $r=Scheduling::reconcile();
        $this->assertTrue($r['success'],json_encode($r));$this->assertSame(0,$r['resolved']??0);
        $this->assertCount(1,$this->errors());
        // A ocorrência volta: a passagem seguinte resolve com o timestamp lido (a menor ocorrência pendente).
        $this->hourly($later=time()+3000);$this->hourly($first=time()+400);
        $r=Scheduling::reconcile();
        $this->assertTrue($r['success'],json_encode($r));$this->assertSame(1,$r['resolved']);
        $this->assertSame([],$this->errors());
        $last=array_values(array_filter(Scheduling::status()['last_errors'],static fn($e)=>$e['id']===$row['id']))[0];
        $this->assertSame('duplicate_event_equivalent',$last['resolved_by']);
        $this->assertSame($first,$last['equivalent_at']);
        $this->assertIsInt($last['resolved_at']);
        $this->assertNotSame('degraded',Executor::status()['health']);
    }
    public function test_c_real_failures_stay_active(): void {
        $single=$this->observe($this->intent('schedule',time()+15),new \WP_Error('duplicate_event','dup'));
        $this->assertFalse($single['success']);$this->assertSame('failed',$single['state']);$this->assertArrayNotHasKey('equivalent_at',$single);
        $this->assertCount(1,$this->errors());
        Options::set(Scheduling::OPTION,['observations'=>[],'active_errors'=>[],'last_errors'=>[],'untracked_errors'=>0]);
        $res=$this->observe($this->intent('reschedule',time()+60,'hourly',3600),new \WP_Error('could_not_set','x'));
        $plain=$this->observe($this->intent('schedule',time()+30),false);
        $this->assertFalse($res['success']);$this->assertFalse($plain['success']);
        $this->assertCount(2,$this->errors());
        $r=Scheduling::reconcile();$this->assertTrue($r['success'],json_encode($r));$this->assertSame(0,$r['resolved']??0);
        $this->assertCount(2,$this->errors());
        $this->assertSame('degraded',Executor::status()['health']);
    }
    private function schedule(bool $pending): array {
        $m=new \ReflectionMethod(Maintenance::class,'schedule');$m->setAccessible(true);
        return $m->invoke(null,$pending);
    }
    public function test_d_pending_schedule_skips_single_event_inside_duplicate_window(): void {
        $next=time()+300;$this->hourly($next);
        $r=$this->schedule(true);
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertSame($next,$r['next_run']);
        $this->assertSame([$next=>'hourly'],$this->maintenance_events());
        $this->assertSame([],$this->errors());
        // Sem esta asserção o teste passava mesmo com a tentativa: a recusa duplicate_event também termina confirmada.
        $attempts=array_values(array_filter(Scheduling::status()['observations'],static fn($r)=>($r['hook']??'')===Maintenance::HOOK&&($r['operation']??'')==='schedule'));
        $this->assertSame([],$attempts,'Dentro da janela de duplicidade nenhum evento único deve ser pedido ao WordPress.');
    }
    public function test_d_pending_schedule_adds_single_event_outside_window(): void {
        $next=time()+2400;$this->hourly($next);
        $r=$this->schedule(true);
        $this->assertTrue($r['success'],json_encode($r));
        $events=$this->maintenance_events();
        $this->assertCount(2,$events);$this->assertContains(false,$events);
        $this->assertLessThan($next,$r['next_run']);
        $this->assertSame([],$this->errors());
    }
}
