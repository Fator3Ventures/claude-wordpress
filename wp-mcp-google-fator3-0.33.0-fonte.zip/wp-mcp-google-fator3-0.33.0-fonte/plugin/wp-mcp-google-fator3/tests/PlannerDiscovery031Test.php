<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Connections,Options,Settings};

final class PlannerDiscovery031Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=[];
        $GLOBALS['f3_test_caps']=true; $GLOBALS['f3_test_user']=1;
        FakeHttp::reset();
        \Fator3\McpGoogle\Plugin::register_abilities();
        Options::batch_verified([Options::ENABLED=>true,Options::ADS_ENABLED=>false,
            Connections::SERVICES=>['gsc'=>'read']]);
    }
    public static function queries(): array {
        return [
            ['ideas',['url'=>'https://www.engagia.com.br/']],
            ['metrics',['keywords'=>['cto']]],
            ['forecast',['campaign'=>[]]],
            ['themes',['keywords'=>['cto'],'ad_groups'=>['customers/1234567890/adGroups/1']]],
        ];
    }
    /** @dataProvider queries */
    public function test_disabled_connector_is_an_actionable_domain_error(string $kind,array $input): void {
        $a=wp_get_ability('ads/keyword-'.$kind);
        self::assertTrue($a->check_permissions([]));
        $before=Settings::revision();
        $r=$a->execute($input);
        self::assertIsArray($r); self::assertFalse($r['success']);
        self::assertSame('f3_google_connector_off',$r['error_code']);
        self::assertSame($before,Settings::revision()); self::assertCount(0,FakeHttp::$requests);
    }
    /** @dataProvider queries */
    public function test_closed_channel_and_nonadministrators_remain_denied(string $kind,array $input): void {
        $a=wp_get_ability('ads/keyword-'.$kind);
        Options::set(Options::ENABLED,false); self::assertFalse($a->check_permissions($input));
        Options::set(Options::ENABLED,true);
        $GLOBALS['f3_test_caps']=['read'=>true,'edit_posts'=>true];
        self::assertFalse($a->check_permissions($input)); self::assertCount(0,FakeHttp::$requests);
    }
    public function test_selected_connection_and_missing_credentials_keep_specific_errors(): void {
        Connections::create('secondary','Secondary');
        Connections::run('secondary',static function(){
            Options::batch_verified([Options::ENABLED=>true,Options::ADS_ENABLED=>true,Connections::SERVICES=>['ads'=>'read']]);
        });
        $a=wp_get_ability('ads/keyword-ideas');
        $r=$a->execute(['connection_id'=>'secondary','url'=>'https://www.engagia.com.br/']);
        self::assertSame('f3_google_not_configured',$r['error_code']);
        $r=$a->execute(['url'=>'https://www.engagia.com.br/']);
        self::assertSame('f3_google_connector_off',$r['error_code']);
        self::assertCount(0,FakeHttp::$requests);
    }
    public function test_unrelated_ads_writes_keep_connector_permission(): void {
        self::assertFalse(wp_get_ability('ads/update-campaign')->check_permissions([]));
    }
}
