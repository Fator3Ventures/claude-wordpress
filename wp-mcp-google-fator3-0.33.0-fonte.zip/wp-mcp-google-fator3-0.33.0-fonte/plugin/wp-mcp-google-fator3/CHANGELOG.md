# Notas da versão

## 0.33.0

Atualização direta da versão 0.32.0. A administração diferencia falha, lista parcial, consulta concluída e falha ao guardar o resultado. Mudanças de configuração durante a leitura invalidam a resposta. O painel de serviços oferece sugestões de propriedades GA4 e planilhas, aceita valores conhecidos e permite preparar o recurso no mesmo envio com JavaScript desativado. A seção de revisão reúne a verificação de acesso, a prévia e o salvamento.

A edição atual do guia acompanha o instalador. A identificação das operações e os schemas públicos continuam os mesmos.

## 0.32.0 · 10/11/2026

Base de migração: Google 0.31.0, por atualização direta (`MIGRACAO.md`). Requisitos de runtime: WordPress 7.1.4 ou superior e PHP 8.3 ou superior. Conjunto vigente com que a release é validada: Fator3 Site Core 1.78.0, Fator3 MCP 0.43.0, Fator3 MCP LinkedIn 0.19.0, Fator3 MCP Meta 0.21.0 e Fator3 MCP Pipedrive 0.8.0.

### Mudanças

- **A. Campos de saída legíveis pelo transporte MCP.** Campos cujo nome continha componentes que o Fator3 MCP mascara (`pass`, `token`, `credential`, `authorization`, `secret`) chegavam como `[redigido]` ao agente, inclusive valores booleanos e objetos. Foram renomeados na saída, sem aliases; não há migração de dados e o que estava gravado continua legível. Entram na mesma regra o contador de telemetria e as observações de cota de `google/status`, saídas do `ga/send-event`, `ga/create-mp-secret`, `google/plan-template` e `google/cleanup-jobs`, a paginação das listagens do Ads e do GA Admin e o valor de verificação de `siteverification/get-token`.
- **B. Falhas de agenda `duplicate_event`.** Recusa `duplicate_event` de evento único com evento equivalente na janela de 600 s do WordPress passa a ser pós-condição atendida (`confirmed`, com `equivalent_at`). Um erro ativo antigo desse tipo é resolvido na passagem da manutenção quando a leitura da agenda encontra ocorrência pendente do mesmo gancho e argumentos (`resolved_by:"duplicate_event_equivalent"`, com `equivalent_at`); sem essa ocorrência, continua ativo. A manutenção não pede evento único quando a próxima ocorrência já está nessa janela. Demais falhas de agenda continuam ativas e mantêm `cron.health:"degraded"`.
- **C. Saúde no status compacto.** `google/status {"compact":true}` traz `health`, `work_health`, `scheduling_active_errors` (inteiro) e `incidents_open` (inteiro, ou `null` quando a leitura local falha). Mudança aditiva, sem chamada ao Google.
- **D. Documentação instalada.** `README.md` é o índice com o mapa dos oito documentos lógicos; novo `ESPECIFICACAO.md`; `AGENT-GUIDE.md`, `RECEITAS.md` e `MIGRACAO.md` reescritos para a release; camadas de versões anteriores retiradas dos documentos instalados; guia o guia da versão 0.32.0 no lugar do guia da 0.31.0. O verificador de build recusa referência a documento fora do índice, título com versão diferente da release, índice sem os oito documentos lógicos e nome de campo antigo fora da tabela de renomes.
- **E. Tela de configuração.** Cabeçalho com seletor de conexão. Faixa de estado com quatro indicadores (Canal MCP, Identidade, Serviços ativos, Prontidão local), com estado em texto; a prontidão é calculada só em Visão geral e Conversões, e nas outras abas o indicador aponta para a Visão geral. Abas em uma linha, com rolagem horizontal em tela estreita. Painéis de Conexão e Avançado em menu lateral quando a área do plugin tem 1000 px ou mais. Seção nova Visão geral (Próximos passos, Serviços desta conexão, Operação) e seção nova Ajuda (documentos em seis grupos e roteiro de leitura pelo MCP), no lugar da lista de documentos repetida no rodapé de cada aba. Etapas da conta de serviço com estado. CSS reescrito por componente. Mesmos formulários, nomes de campo, nonces e permissões (o guia da versão 0.32.0).
- **Desinstalação.** Todo segredo declarado em `Options::secret_names()` é removido, com ou sem purge. Na 0.31.0, `mp_secret` permanecia na desinstalação sem purge.

### Contratos alterados

Nomes de campo de saída (A):

<!-- campos-renomeados -->
| Habilidade | Nome antigo | Nome atual |
|---|---|---|
| `google/executar-vencidos` | `pass` | `run` |
| `google/executar-vencidos` | `maintenance.reused_pass` | `maintenance.reused_run` |
| `google/status` | `cron.last_pass` (também em `connections[].cron`) | `cron.last_run` |
| `google/status` com `live:true` | `token_ok` | `auth_probe` |
| `google/maintenance`, `google/storage-status`, `google/status`, `google/executar-vencidos` | `progress.<família>.examined_in_pass` | `progress.<família>.examined_in_run` |
| `google/readiness-status` (check `executor`, `detail`) | `last_pass_at` | `last_run_at` |
| `google/readiness-status` (check `executor`, `detail`) | `last_pass_age` | `last_run_age_seconds` |
| `google/ability-catalog` | `authorization` | `execution_checks` |
| `google/configuration-schema` | `authorization` | `access_requirements` |
| `google/configuration-schema` | `options.*.secret` | `options.*.confidential` |
| `google/configuration-schema` | `runtime_prerequisites.credentials` | `runtime_prerequisites.authentication` |
| `google/selftest` | `data_manager.credential` | `data_manager.identity_requirement` |
| `google/selftest` | `data_manager.developer_token` | `data_manager.developer_access` |
| `google/export-template` | `secrets_included` | `confidential_included` |
| `google/status` | `telemetry.counters.token_requests` | `telemetry.counters.auth_requests` |
| `google/status` | `quota_observations.observations[].observations.tokensPerDay` | `quota_observations.observations[].observations.quota_units_per_day` |
| `google/status` | `quota_observations.observations[].observations.tokensPerHour` | `quota_observations.observations[].observations.quota_units_per_hour` |
| `google/status` | `quota_observations.observations[].observations.tokensPerProjectPerHour` | `quota_observations.observations[].observations.quota_units_per_project_per_hour` |
| `google/status` | `quota_observations.observations[].observations.concurrentRequests` | `quota_observations.observations[].observations.concurrent_requests` |
| `google/status` | `quota_observations.observations[].observations.serverErrorsPerProjectPerHour` | `quota_observations.observations[].observations.server_errors_per_project_per_hour` |
| `google/status` | `quota_observations.observations[].observations.potentiallyThresholdedRequestsPerHour` | `quota_observations.observations[].observations.potentially_thresholded_requests_per_hour` |
| `ga/send-event` com `debug:true` | `credential_validated` | `access_validated` |
| `ga/send-event` com `debug:false` | `secret_persisted` | `confidential_persisted` |
| `ga/create-mp-secret` | `secret_persisted` | `confidential_persisted` |
| `google/plan-template` | `credentials_promoted` | `confidential_promoted` |
| `google/cleanup-jobs` com `dry_run:true` | `max_records_per_pass` | `max_records_per_run` |
| `ads/search`, `ads/get-campaign`, `ads/list-conversion-actions`, `ads/list-assets`, `ads/list-audiences`, `ads/list-users`, `ads/list-experiments` | `next_page_token` | `next_page` |
| `ga/list-users` | `next_page_token` (texto vazio sem próxima página) | `next_page` (`null` sem próxima página) |
| `ga/get-settings` | `truncated_sections.<seção>.next_page_token` | `truncated_sections.<seção>.next_page` |
| `siteverification/get-token` | `token` (repetido em `data.token`) | `verification_value` (`data` sai sem `token`) |
<!-- /campos-renomeados -->

Nas observações de cota, cada chave nova traz `google_field` com o nome original do Google (`tokensPerDay` etc.). O contador de telemetria lê as horas gravadas antes da troca com o nome novo. Nas listagens do Ads e do GA Admin, o parâmetro de entrada continua `page_token`: envie nele o valor de `next_page`. Aditivo: `google/execute-read` acrescenta `next_page` quando a resposta do Google traz `nextPageToken` no nível superior de `data` (mesmo valor; `data` não muda; para a página seguinte, envie-o em `query.pageToken`).

Aditivos: `health`, `work_health`, `scheduling_active_errors` e `incidents_open` no status compacto (C); `equivalent_at` e `resolved_by:"duplicate_event_equivalent"` em `cron.scheduling` (B); `next_page` em `google/execute-read`; `google_field` nas observações de cota; schemas de saída de `google/execute-read` e `siteverification/get-token`. Sem mudança em contratos de entrada, configuração 4.0.0, execução 2.0.0, catálogo 3.0.0, contratos com o Site Core ou tabelas.

### Limites e pendências conhecidos

- Em `google/configuration-schema`, as definições das opções `ads_developer_token`, `mp_secret`, `oauth_client_secret`, `oauth_refresh_token` e `credential_receipts` continuam mascaradas pelo transporte MCP, porque o ID da opção é nome de segredo e faz parte do contrato de entrada. Leitura alternativa: documento `configuration-definitions.json` por `google/documentation`.
- Em `google/list-actions`, descritores de parâmetros da Discovery API com nome sensível (`access_token`, `oauth_token`, `pageToken`) chegam mascarados; são nomes do Google.
- Nos relatórios GA4 com `return_property_quota:true`, `property_quota` repassa o `propertyQuota` do Google; as chaves `tokensPer*` chegam mascaradas. A mesma informação está em `google/status` → `quota_observations`, com nomes legíveis.
- Os diretórios `wp-content/f3-google-state/` e `wp-content/f3-google-cache/` permanecem depois da desinstalação, com ou sem purge; o administrador os remove manualmente (`MIGRACAO.md`).
- Validação com APIs Google simuladas; sem homologação em conta Google real.

## Histórico — versões anteriores (não descreve a release instalada)

As entradas abaixo registram versões anteriores tal como foram publicadas. Nomes, contagens, matrizes de plugins e procedimentos citados nelas valem para a versão de cada entrada, não para a 0.32.0.

### 0.31.0 · 06/11/2026

- Pedidos MCP Google 49: as quatro consultas do planejador continuam descobríveis e devolvem o diagnóstico do conector desligado para administradores autorizados. Canal, perfil, conta, credenciais e nível de acesso continuam verificados antes de I/O.
- Mantidos os schemas de sementes alternativas e retomada; sem migração de dados ou mudança exigida no MCP 0.41.0.
- Acesso ao Google Ads explica níveis Test/Explorer/Basic/Standard, declaração administrativa e conferência do catálogo.
- Testes de regressão cobrem descoberta, execução e recusas pelo transporte MCP real com o conjunto vigente, incluindo Core 1.72.1.

### 0.30.0 · 06/11/2026

- OAuth exige o segredo correspondente ao trocar Client ID; formulários antigos são recusados por revisão.
- Desconectar remove autorizações ativa e candidata em uma gravação verificada, mantendo os aplicativos. Falhas revertem a gravação local; consentimentos anteriores ficam desatualizados.
- Ativação OAuth verifica o contêiner GTM vinculado usando a mesma seleção de recursos da conta de serviço.
- Tela OAuth organizada em aplicativo, consentimento e ativação, com identidades separadas, orientação de segredo vazio e explicação do alcance da revogação.
- Testes de regressão, gravação com falha, isolamento, autorização, atualização e navegador ampliados. Guia revisado e distribuído na documentação MCP.

### 0.29.0 · 05/11/2026

- O diagnóstico identifica a conexão, o método e a hora e separa os serviços Google das verificações locais. Formulários desatualizados pedem nova conferência antes de disparar consultas.
- Prévias administrativas ficam vinculadas à operação, à conexão e ao usuário. Exportações simultâneas mantêm seus próprios arquivos. A aplicação de uma limpeza usa sua própria prévia e a consome uma única vez.
- O planejador revalida a autorização durante a consulta e confirma os lotes de cada página junto com o cursor. Uma revogação ou disputa de gravação preserva o último recibo confirmado.
- O índice de documentação retorna metadados pré-calculados. Abrir um manual carrega e verifica somente o documento solicitado.

### 0.28.0 · 05/11/2026

Configuração dividida em Identidade, Serviços e recursos e Permissões. O diagnóstico preserva a conexão e a navegação. O acervo carrega os valores da conta selecionada. Conversões exigem uma ação explícita, validam a conexão e consultam listas separadas por serviço. O planejador valida as páginas do fornecedor antes de publicá-las e normaliza os resultados em blocos de cem. Os manuais de configuração, operação do planejador e atualização estão no índice instalado.

### Notas da versão 0.27.0

Pedido 49. Planejamento de palavras-chave Google Ads, histórico local e junção com consultas GSC. Veja o guia de configuração daquela versão, mantido no fonte, e google/readiness-status. Base direta 0.26.0. WordPress mínimo 7.1.4 e PHP mínimo 8.3.

#### Referências das versões anteriores

### 0.26.0 — 2026-11-01

- Pedido 48: sincroniza o schema público de transporte com Core 1.66.0: ambos em selected/effective e erro invalid_output. Mantém validação integral e motivos de prontidão de cada destino.
- Não muda configuração, banco, credenciais, fila, permissões ou envio. Atualização direta de 0.25.1.
- Testes do contrato publicado, configurações nativas de transporte, valores inválidos, instalação/upgrade/rollback e documentação MCP.
- Correção Core 363 da rodada anterior incorporada no Core 1.66.0; nenhum novo patch de acompanhante.

### 0.25.1 — 2026-10-31

Inclui AVISOS-RENOVACAO.md no índice administrativo/MCP. Corrige a omissão encontrada no aceite do candidato0.25.0 antes do fechamento do fonte. Política de renovação preservada.

### 0.25.0 — 2026-10-31

Pedido 47: atenção adiada por retentativas/validade, recuperação condicionada, recibos persistentes e política por conexão com simulação. Duas habilidades locais aditivas; 300 habilidades, 42 opções. Sem mudança no Core ou em contratos de entrega.

### Alterações

#### 0.24.0 — 29/10/2026

- Guia instalado CORE-ACERVOS.md com configuração, concessões, permissões, paginação e aceite do consumidor Core 1.61.1.
- Referência corrigida para f3base_google_ads_acervo; conversões/tag permanecem em f3base_google_ads.
- Bootstrap da proposta histórica desativado para impedir reaplicação sobre consumidores já incorporados.
- Base direta 0.23.0; validação com Core 1.61.1, MCP 0.37.0, Meta 0.16.0 e LinkedIn 0.13.0. Contratos, schemas, coleta, retenção e autorizações preservados.

### Alterações

#### 0.23.0 — 29/10/2026

- Google43: quatro heurísticas de Service Account tornam-se avisos na resposta/tela; validação remota preserva a chave ativa quando recusada.
- Google44/45: acervo Ads permanente cifrado, coleta diária por conta, revisitas/backfill, checkpoints, reader local com concessão por consumidor/conta/datasets. Novas quatro abilities administrativas.
- Google46: leitor GSC1.1 consulta/página/dia com concessão independente, cobertura e paginação até o fim observável; 1.0 preservado.
- Adaptadores opcionais Core337/340/342 entregues no fonte, sem atualizar Core remoto. Reconciliação Core323 reconhecida como incorporada no Core1.60.
- Base0.22; acompanhantes de bancada Core1.60/MCP0.36/Meta0.14/LinkedIn0.12. Sem DDL ou concessão automática.

### Changelog

#### Versão 0.22.0 — Pedidos Core 323

Base direta 0.21.0. O contrato opcional `site-conversion-delivery/1.2.0` atende ações Google Ads comerciais por etapa, com concessão independente para `site-core-quality` / `crm_stage`. Mantém aquisição 1.0/1.1, conversões otimizadas e pedidos Google 39–42. São 294 habilidades (113 leitura, 181 escrita), 38 opções, sem nova tabela ou segredo.

Core 1.58.0 implementa o consumidor de conversões otimizadas (Core 316) e o envio comercial (Core 323). Acompanhantes recebidos: MCP 0.34.0, Meta 0.13.0, LinkedIn 0.11.0; Pipedrive 0.2.0 disponível em pacote. O Site-Teste é inventariado separadamente. Nenhum mínimo próprio ou ordem de ativação dos acompanhantes foi imposto.

A aceitação inicial pela Data Manager é `incerto`. O produtor fornece `site-stage-conversion-reconcile/1.0.0`, consulta sem reenvio. Core 1.58.0 original ainda não consome essa confirmação comercial; o fonte desta entrega inclui implementação proposta em patch para esse consumidor, ensaiada separadamente. Não confundir esse ensaio com o pacote Core original nem com implantação no Site-Teste.

Quatro operações comerciais; payload fechado, valor 0/BRL, concessão por geração, prova/renovação e reconciliação sem reenvio.


#### 0.21.0 — 28/10/2026

- Pedidos 39–42: contrato de conversões 1.1.0 negociado com consumidores 1.0.0; identificadores pessoais normalizados/hasheados no transporte Data Manager, prontidão por conta/ação e recusa `enhanced_leads_not_ready`.
- Leitura compacta de configuração/status e filtro `fields`; identidade pública da chave SA salva nas consultas de conexão.
- Renovações GA4 com fase/diagnóstico sanitizado, auditoria de cada tentativa, histórico e duração sem prova.
- Base direta 0.20.0; preservação de opções/dados e contratos GA4/GSC.

### 0.20.0 — 27/10/2026

- Pedido 37: retenção ilimitada padrão, opção audit_retention pelo MCP, proteção da manutenção para registros antigos e idempotência sem prazo.
- Pedido 38: leitor GA4 público, concessão vinculada à propriedade/identidade, paginação, filtros, qualidade, cota por propriedade e auditoria de principal plugin. Sem acervo Google nem retry automático.
- Base direta 0.19.0; contratos Search Console e credenciais preservados. Acervo Core 313 requer implementação no consumidor.

### Alterações

#### 0.19.0 — 23/10/2026

Pedido Google 36: validação obrigatória de credenciais antes de salvar; troca de identidade com prévia, revisão e confirmação; rotação da mesma conta preserva grants, verificações e filas; nome editável inclusive default; ajuda e resumo sem segredos. Base direta 0.18.1.

### 0.18.0 — 2026-10-23

#### 0.18.1 — 2026-10-23

- Corrige o diagnóstico de prontidão para canal fechado, destino parcialmente configurado, autorização revogada durante validação pendente e configuração de conversões ilegível.
- Filtra incidentes abertos antes da paginação e informa quando a contagem é parcial.
- Substitui a mensagem de prontidão em estado de atenção por uma descrição que não afirma operação disponível.
- Mantém os oito checks, os contratos públicos, o transporte de conversões e os dados existentes. Acrescenta testes de regressão em WordPress real.

- M1: descrições revisadas em português para as 106 habilidades `gtm/*` geradas do Discovery e para os parâmetros `ability`/`parameters` das habilidades `google/mcp-read` e `google/mcp-write` (ferramentas MCP `google-mcp-read` e `google-mcp-write`); nenhum rótulo ou descrição de habilidade em inglês.
- M2: `google/readiness-status` (contrato `google-readiness/1.0.0`), comando `wp mcp-google readiness` e cartão de prontidão na aba Conversões. Leitura local, sem chamada ao Google.
- M3: leitura de estado das conversões com uma fotografia do Site Core por chamada; entrega e verificação seguem lendo o Core dentro das cercas.
- M4: a conexão que entrega GA4 é selecionada pelo fluxo configurado, não pelo ID de medição do Core; corrige `ambiguous_connection` com uma conexão GA4 e outra Ads.
- M5: reconciliação do executor aceita passagens sem `connection_id`; cobertura com resposta inesperada de `SHOW CREATE TABLE` fica desconhecida, sem sequência inventada.
- M6: schemas de saída de `google/status` e das três habilidades de entrega de conversões declaram campos já devolvidos; nada removido ou renomeado.
- Código: guarda de `ABSPATH` no padrão exigido pelo teste de integração em quatro arquivos e `strict_types` em `includes/Data/CoreTransport140.php`.
- Testes: suítes nativas 0.18.0; gate PHPUnit histórico reexecutado com `get_current_blog_id()` no dublê e fixtures Ads atualizadas ao escopo Data Manager.
- Base direta 0.17.0; 286 identificadores e efeitos preservados; schemas iguais, salvo seis ampliados só por acréscimo (M1 e M6); configuração 4.0.0, catálogo 3.0.0, execução/armazenamento/manutenção 2.0.0.

#### 0.17.0 — 2026-10-22


- Pedidos 33/35: nomes claros em português nas permissões por recurso e nas 286 habilidades, mantendo os identificadores públicos.
- Pedido 34: resposta e incidente com HTTP, estado, motivo, campo e mensagem sanitizados. NOT_FOUND do destino arma nova validação no executor, mesmo sem prova anterior, sob a mesma autorização.
- Configuração parcial preserva o outro destino; segredo, destino ou concessão alterados invalidam apenas a prova correspondente.
- Compatibilidade com Core 1.46.1, MCP 0.25.0, Meta/LinkedIn 0.4.1; sem alterações nesses plugins.

### Histórico

#### 0.16.0 — 21/10/2026

- Pedidos 30–32: menu único; destinos e permissões por seletores; perfis GA4 estruturados; renovação automática pelo executor; Ads Data Manager com recibos persistentes e confirmação assíncrona.
- Extensão opcional de reconciliação do Core entregue como dependência sobre 1.42.0.
- ID de medição do GA4 lido do Core; campo legado aceito apenas por compatibilidade, sem definir o destino.

### Histórico — Fator3 MCP Google

#### 0.15.0 — 20/10/2026

- Incorpora `sendBound()` recebido do Core 1.41 e mantém `send()` para Core 1.40.
- Confere a referência do destino sob a trava de configuração/envio e relê a identidade antes de cada HTTP.
- Preserva `destination_mismatch`/`authorization_changed` quando a barreira local prova não envio; não repete resultados externos incertos.
- Atualização direta da 0.14.0, sem migração de dados, novos defaults ou envio automático. Documentação corrente e bancada 015 incluídas.

#### 0.14.0

- Adapta contrato Core de entrega 1.0.0, mantendo leitor 1.0.0 e negociando contexto 1.1.0.
- Configuração e segredo MP por conexão; verificação GA4/Ads explícita, autorização de background revogável, resultados individuais e incerteza sem repetição.
- Cron distingue lacuna de observação, causa observada e fila atual; recuperação só com prova de intervalo sem trabalho devido.
- Base direta 0.13.0; sem alteração dos plugins acompanhantes.

#### 0.13.0 — 20/10/2026

- Pedido MCP Google 27: conflito de revisão explicitamente classificado no leitor, com `conflict:true` e `retryable:false`, preservando o bloco Core.
- Revisão atual opcional apenas na recusa defensiva da fotografia já validada; nenhuma leitura adicional ou extensão do schema Core.
- Schema, exemplos, guia instalado e regressões específicos atualizados; contratos, 283 operações, dados e configurações preservados.
- Core 1.39.0 analisado: transporte de conversões depende de alinhamento de recibos assíncronos, seleção de API Ads e homologação. Não há adaptador de entrega nesta versão.


#### 0.12.0 — 19/10/2026

- Pedido MCP Google 26: leitura efetiva tipada de booleanos, incluindo false persistido pelo WordPress.
- P12-01/P12-02: consumidor opcional de site-conversion-purposes/1.0.0 e google/conversion-context, com gate administrativo.
- P12-03: contexto de contato/material separado no diagnóstico GTM, com guarda de revisões.
- P12-04/P12-05: documentação instalada, schemas, fixtures e bancada clean/upgrade/isolada/transporte.
- Base direta 0.11.0; nenhuma migração, credencial ou configuração criada pela descoberta.

### 0.11.0 — 16/10/2026

- Pedido MCP Google 25: mínimos declarados WordPress 7.1.2/PHP 8.3.6 e tabela externa com somente nomes, bytes e SHA-256.
- Atualização direta da 0.10.0; contratos, 282 operações, banco e permissões preservados.
- Documentação corrente alinhada ao MCP 0.23.0/Core 1.35.0 e ao limite de descoberta de material do SDK 1.0.0.
- Provas e limites atuais constam de VALIDACAO.md e do relatório externo; notas abaixo são históricas.

### 0.10.0 — 16/10/2026

- Limite de bytes na entrega pública e paginação independente de resultados e metadados de jobs.
- Leitor local google/documentation com índice, allowlist, SHA-256 e continuação UTF-8.
- Diagnóstico do painel distingue canal, credencial legível, candidata e falhas; cache antigo não é reclassificado.
- Permissões filtradas continuam restritas à administração.
- Atualização direta suportada: 0.9.0. Banco e contratos SDK existentes preservados.
- Homologação do candidato no site compartilhado e APIs reais depende da publicação pela frota e ativos autorizados; veja relatório externo.

### Changelog

#### 0.9.0 — 2026-10-15

- Entrega única, substituindo a próxima versão planejada 0.8.6; atualização direta da 0.8.4 ou instalação limpa. MCP 0.21.0 → 0.22.0 e Core 1.31.0 → 1.33.0, sem dependência numérica de instalação.
- Coleta completa GA4/GSC com limites, cursores vinculados à autorização, checkpoint de páginas e qualidade/cobertura por recorte. Falhas parciais e metadados desconhecidos são explícitos.
- Calendário nativo por semana ISO, mês, trimestre e ano, sem somar usuários únicos ou misturar moedas. CTR GSC deriva dos cliques/impressões do intervalo; posição vem da origem.
- Exportação `require_complete` por padrão; `allow_partial` explícito. Recibo de extração separado da escrita e da verificação do retângulo exportado; append confirmado não é reenviado.
- Core `site-measurement-context/1.0.0`, MCP `package-distribution/1.0.0` e `executor-registration/1.0.0`; retirada de acessos privados dos consumidores Google.
- Diagnóstico/schema completos, geração documental conferida, laboratório com expectativas externas e dois percursos de atualização direta. Mantidos configuração 4.0.0, catálogo 3.0.0, execução 2.0.0, armazenamento 2.0.0 e leitor GSC 1.0.0.

#### 0.8.5 — preparada, não instalada; incorporada à 0.9.0

- Estrutura corrente criada diretamente; registros indexados sem fallback em options nem fases históricas de migração. Dados atuais da 0.8.4 usados sem recópia.
- Nova `google/maintenance`, contrato 2.0.0; retiradas `google/migrate-storage` e `google/complete-transition`, sem aliases ou ampliação de permissões. Catálogo 3.0.0 com 281 habilidades.
- Retiradas importação de cron, famílias históricas de manutenção e aquecimento duplicado do registro Abilities. Mantidas reconciliação corrente, leases, guardas e confirmação de gravação.
- Bancada portátil com insumos conferidos; promoção do ZIP exato validado, vinculada à identidade do código, testes e ferramentas.
- Integração/documentação para MCP 0.21.1 e Core 1.32.0; instalação sem bloqueio por versões dos acompanhantes. Base limpa/0.8.4, sem procedimentos intermediários de versões anteriores.

#### 0.8.4 — 2026-10-12

- Pedido 22: prova atual do executor cron, saúde separada do trabalho e histórico, reparação idempotente com geração/trava nos pontos admitidos; bootstrap e status sem reparação.
- Pedido 23: configuração 4.0.0 com simulação, mescla explícita, diff efetivo e confirmação de reduções vinculada a ator/site/conexão/revisão/hash; painel e modelos compartilham o diff.
- Preservação do resultado real de gravação/restauração, incluindo estado desconhecido quando a restauração não é comprovada.
- Integração MCP 0.21.0/Core 1.30.0, catálogo e documentação autenticada atualizados; pacote de produção por allowlist e índices silenciosos.

#### 0.8.3 — 2026-10-11

- Pedido 20: admissão estruturada, cessão normal sem incidente, fechamento terminal anterior à projeção e reconciliação local idempotente.
- Identidade de erro/resolução confirmada, histórico preservado, recuperação da projeção órfã 0.8.2, lacunas de cobertura explícitas e retenção de fontes pendentes.
- Pedido 21: agenda WordPress verificada, diagnóstico por operação/gancho/origem, falha real/contexto insuficiente preservados e documentação de `could_not_set` sem supressão.
- Painel com estados legíveis e fuso do site; schemas e documentos autenticados atualizados. 282 habilidades preservadas.
- Matriz Core 1.30.0/MCP 0.19.0; SDK e guardas independentes, backup Slack e separação publicidade/medição documentados.
- Base limpa/0.8.2, sem trava por número anterior. Homologação de sete dias na frota não faz parte da evidência local.


#### 0.8.2 — 2026-10-08

- Completa a barreira de recuperação em todas as entradas de manutenção, histórico, CLI, cache e auditoria; preserva a drenagem de trabalho admitido.
- Coordena uma passagem automática por site/invocação, com 100 unidades ou 1.000 ms, cursores duráveis e avanço de conexões órfãs. Evita DDL repetido no histórico pronto.
- Corrige resíduos SQL com cache externo, preservação de TTL e concorrência nas trocas de backend. Limpeza retorna falhas, pendências e confirmação.
- Acrescenta manutenção 1.0.0 às consultas existentes e painel, sem novas habilidades. Mantém 282 habilidades, configuração 3.0.0, execução/catálogo 2.0.0 e SDK leitor 1.0.0.
- Atualiza documentação, instalador protegido e ensaios com Core 1.25.0/MCP 0.18.0; base de ensaio limpa ou 0.8.1, sem trava por número de versão.


#### 0.8.1 — 2026-10-08

- Pedido 18: passagens/incidentes de cron em tabela indexada, oito dias de retenção, limites por conexão e manutenção também no caminho CLI de observação; contagens e últimas origens preservadas.
- Migração retomável das options antigas, confirmação de autoload e arquivo temporário verificado de origens de auditoria/jobs, com expiração em oito dias.
- Pedido 19: teto de 100.000 bytes para valores serializados de transients SQL; arquivos grandes cifrados/protegidos, limites de ocupação e expiração; saneamento do cache antigo.
- Corrigida descoberta pelo Measurement ID explícito do Core com GTM presente; erros de ID ausente/inválido distintos e `core_source` na aplicação.
- Status de manutenção/cache, documentação protegida atualizada e matriz Core 1.24.0/MCP 0.17.0.


#### 0.8.0 — 07/10/2026

- Pedido MCP Google 17 corrigido: configuração incompleta sem reprovação retorna `success:true`, `result_status:incomplete`, `complete:false`, sem código de falha. Mensagem conta e nomeia todas as não configuradas.
- Falhas de execução preservam sua causa, sem fabricar totais. Reprovações reais conservam `f3_google_selftest_failed`; agregador compartilhado de aprovação continua estrito.
- Painel usa o mesmo resumo do diagnóstico, oferece orientação Ads e mantém estado anterior/revisão e detalhes recolhidos. Cache legítimo da 0.7.1 é reinterpretado sem rede ou gravação.
- Removidos o início automático da transição do importador 0.6 e fallbacks de desenvolvimento que toleravam módulos obrigatórios ausentes. Mantidas recuperação de estado pendente já persistido e migração do repositório ainda utilizada na base 0.7.1.
- Base de manutenção: instalação limpa ou 0.7.1, sem trava de origem por versão. Matriz alvo exercitada com Core 1.24.0 e MCP 0.16.0; escopo exato em VALIDACAO.md.
- Documentação e schemas regenerados; configuração Core 6.1.0, distinção de métricas e inventário de recuperação atualizados. Catálogo preservado em 282 habilidades; versão dos metadados 0.8.0.

O número 0.8.0 substitui o 0.7.2 previsto no plano revisão 3, por decisão do dono. Não houve entrega intermediária.

#### Histórico anterior

### Histórico de mudanças

#### 0.7.1 — 07/10/2026

- Diagnóstico local MCP centralizado: SDK ausente/incompatível, canal desativado, registro ainda não observado, registro incompleto, registrado e erro. Preservados preparo do registro e autorização das bridges/alvos.
- Bridge delega a admissão ao alvo final: status e recuperação permanecem acessíveis durante pausa, sem liberar despacho remoto ou executor aninhado.
- `effective_status()` anunciado desde a descoberta inicial do SDK; resolução única compartilhada com `query()`, projeção segura e contexto selecionado restaurado ao sair.
- Revisão compacta em `google/integration-status`, com `read_success` e revisão nula em falhas de leitura.
- Contador compartilhado com o catálogo, incluindo GTM e futuros prefixos da categoria Google; menu e mensagens uniformizados.
- Cron distingue disputa de lock, falha de leitura/inserção/escrita e persistência do próprio diagnóstico. Eventos por passagem precedem projeções; repetição limitada somente da gravação, com reconciliação sem despacho.
- Cron conserva o resultado do trabalho, as últimas origens independentes e erros históricos. Explicação da CLI observada usa somente a evidência disponível. Retenção de eventos/incidentes passa a oito dias, com limpeza limitada.
- Guias de upgrade 0.6/0.7, rollback 0.7.0, contenção para 0.6 e recuperação independente Core/Google atualizados. Pacote mantém documentação protegida e índices em todos os diretórios.
- Contratos de execução/catálogo 2.0.0, configuração 3.0.0 e leitor PHP 1.0.0 preservados. MCP 0.16.0 e Google real não homologados nesta entrega.


#### 0.7.0 — 01/10/2026

- Contrato PHP Search Console 1.0.0 para consumidores registrados, autorização explícita por conexão e consulta sem impersonação.
- Deadline compartilhada, orçamento por identidade/propriedade, cursor vinculado, cobertura explícita, auditoria de tentativas e exportação com autoria de plugin.
- Cron com origem verificada, últimas CLI/HTTP/manual independentes, observação WP-CLI nativa e indicador móvel de duas horas.
- Pausa externa de recuperação, drenagem e retomada explícita com invalidação de contextos restaurados.
- Bridge/diagnóstico pelo SDK MCP 0.15.0, preservando autorização do alvo e classificação de executor.
- Configuração 3.0.0; projeções antigas retiradas. Importador Google→Core da 0.6 desativado, com checkpoint preservado; responsabilidade passa ao consumidor Core.
- Nome Fator3 MCP Google, documentação/downloads protegidos e três artefatos padronizados.

### Histórico

#### 0.6.0 — 2026-10-01

- Entrega integral dos pedidos 8–11 sobre a base 0.5.0.
- Importação diária Search Console → Site Core com checkpoints, autorização revalidada, replay dos três últimos dias finais e estado em `google/status.gsc_import`.
- Provedor e `policy_contract:1` no canal 0.13.0, autorização do alvo final nas bridges e compatibilidade do atualizador nativo com os dois formatos de manifesto.
- Admissão serializada com migração: operações admitidas finalizam sua auditoria antes da cópia; chamadas novas recebem erro temporário antes do despacho. Recuperação da saúde preserva a lacuna histórica.
- Catálogo Tag Manager v2 completo (106 métodos), rotas tipadas, níveis de escopos, prévia/publicação/reversão e diagnóstico estático da versão publicada.
- Publicação interrompida não se repete automaticamente; registros retornam versão anterior, criada e substituição do workspace.
- Configuração GTM optativa; Service Account permanece prioritária. Documentação versionada e Cloud Shell com API Tag Manager disponíveis por download autenticado.
- Mantém as entregas anteriores, a correção do PUT vazio e o fechamento do instalador sem `.htaccess`.

#### 0.5.0 — 2026-09-30

Entrega única integral. Critérios, evidências e limites de homologação em `docs/VALIDACAO.md`. Sem implantação automática em produção.

- Mantém Service Account em primeiro e separa autenticações; preserva credencial ativa durante a preparação/validação da candidata.
- Acrescenta telas de operações, agendas, perfis, política, modelos, alertas e distribuição; revisões e nonces protegem formulários; JSONs ficam recolhíveis.
- Publica execução/configuração/catálogo 2.0.0, 167 habilidades e metadados de versão; corrige distinção entre leitura, escrita local e efeito remoto.
- Entrega `ga/aplicar-perfil`, `ga/conformidade`, schema/lista/gravação de perfis genéricos e `ga/list-custom-dimensions`; compara grafia, aplica retenção primeiro e relê cada etapa.
- Resolve vínculo opcional pelo Measurement ID do Site Core sem criar propriedade e com compensação verificada em falhas.
- Entrega `gsc/preparar-site`, `gsc/migracao-conferir`, inspeção imediata de até cinco URLs únicas e fila para até 500; preserva `Content-Length: 0` no PUT vazio.
- Exige preparação/confirmacão vinculada nas escritas sensíveis; registra tentativas, retorna resultados parciais/incertos e recusa repetição automática.
- Migra opções para repositório indexado com cópia/verificação/retomada; commits de resultados/cursor, leases e escopo por conexão impedem os reenvios cobertos pelos testes.
- Acrescenta executor compartilhado de vencidos, revisão de agendas, paginação de resultados, retenção e limpeza com prévia/limite por passagem.
- Publica políticas de recurso com prévia de impacto, modelos sem segredos, alertas optativos e metadados executáveis de relatórios.
- Acrescenta auditoria por hash de configuração/marcador exclusivo, detecção de ambiguidade, revisão/cursor, exportação JSON/CSV autenticada e ação separada de exportação literal para Sheets.
- Endurece consultas públicas/atualização com DNS fixado, recusa de IPs especiais, limites e validação de cada redirecionamento; atualizador exige origem explícita, hash, versão e estrutura coerentes.
- Retira documentos e scripts textuais do instalador, preservando-os nos fontes; inclui índice em todos os diretórios, sem `.htaccess`; download Cloud Shell continua autenticado.
- Desativação cancela ambos os executores e remove caches de tokens. Desinstalação sempre remove segredos e preserva por padrão dados públicos sanitizados; purge é optativo por site.
- Documentação atual e catálogos gerados substituem instruções antigas; guias históricos ficam em `docs/history/`.

**Incompatibilidades:** escritas sensíveis da 0.4.0 precisam de confirmação; atualização de agenda precisa de revisão; jobs legados sem contexto exigem revisão; contrato padrão de configuração passa a 2.0.0. Projeções 1.x não restauram o comportamento antigo de escrita.

#### 0.4.0 — 2026-09-14

- Reorganiza configuração em quatro áreas com ajuda contextual, navegação responsiva e formulários utilizáveis sem JavaScript.
- Prioriza Service Account em conexões novas; preserva OAuth existente e separa os métodos por painel.
- Separa preparação e ativação explícita, com validação de token e revisão contra alterações concorrentes.
- Impede callback OAuth antigo de sobrescrever configuração recente; preserva feedback ao administrador após retorno REST.
- Centraliza gravações verificadas; valor igual, falha, restauração e campo omitido possuem tratamento distinto.
- Unifica controles de serviço e GA4 padrão; oferece sugestões de recursos, entrada manual e detecção de sitemap.
- Isola diagnóstico e descoberta por usuário, conexão e revisão. Corrige afirmação indevida de ausência de servidor MCP.
- Expõe edição dos quatro limites e contrato 1.1.0 com metadados de interface; mantém consulta explícita 1.0.0.
- Preserva criptografia, múltiplas conexões, selftest e correção do PUT vazio.
- Validação: 858 testes e 9.173 asserções; 34 verificações WordPress/SQLite; três PUTs HTTP; 12 combinações de tela/largura em Chrome, com sete verificações interativas. Google simulado; sem implantação em produção.

#### 0.3.1 — 2026-09-14

- Corrige primeira gravação de `false` em opção ausente: usa `add_option()` após leitura de existência, sob trava, com confirmação direta no banco.
- Preserva sucesso sem alteração para valores já iguais; inserção recusada continua retornando `f3_google_option_persistence`.
- Acrescenta `google/configuration-schema`, contrato `1.0.0` com 22 opções/itens derivados, escopo, tipos, limites, valores atuais seguros, dependências e operações permitidas.
- Reutiliza limites de `Options`, perfis e validadores de `Setup`, limites de `Connections` e schemas do registro ativo de habilidades.
- Distingue valor ausente, valor efetivo, leitura não confirmada e segredo indecifrável. Não expõe segredos, cifras ou hashes de credenciais.
- Total: 132 habilidades (47 leituras, 85 escritas). Não modifica o Core nem libera escrita genérica de opções.
- Validação: 821 testes, 8.943 asserções; 25 verificações WordPress/SQLite, três PUTs em HTTP local e nove cenários Cloud Shell simulados.

#### 0.3.0 — 2026-09-13

- Corrige selftest: execução, aprovação e verificações puladas têm campos distintos; reprovação não é sobrescrita por Response::ok().
- Adiciona gravações verificadas, confirmação direta no banco, resultados por operação, erros de cifra e compensação de lotes; painel e OAuth conferem persistência.
- Cifra access tokens no cache, invalida cache legado e serializa renovação.
- Separa desconexão local e revogação OAuth explícita; preserva configuração do cliente.
- Adiciona seleção de serviços/perfis, importação de credenciais, configuração assistida e até 20 conexões locais.
- Acrescenta diagnóstico por recurso, telemetria HTTP sem corpos/segredos, Retry-After, classificação de quota e orçamento de tentativas.
- Substitui auditoria em lista única por registros independentes com inserção exclusiva e retenção configurável.
- Acrescenta sitemap acompanhado, inspeção em lote com cache/cota/prioridade, jobs persistentes, agendas e seis modelos de relatório.
- Preserva PUT vazio com Content-Length: 0 e todas as habilidades anteriores. Total: 131 habilidades (46 leituras, 85 escritas).
- Inclui script Cloud Shell revisado e original de referência; projeto explícito, reuso de chaves e rotação opt-in.
- Validação: 805 testes, 8.730 asserções; 20 verificações com funções WordPress/SQLite, três PUTs por HTTP local e nove cenários Cloud Shell simulados.

#### 0.2.1 — 2026-09-09

- Corrige HTTP 411 em `gsc/submit-sitemap`: o cliente HTTP envia `Content-Length: 0` em PUT com corpo vazio.
- Aplica a correção também a `gsc/add-site` e a métodos PUT sem corpo executados por `google/execute-action`.
- Preserva corpos JSON, formulários e uploads com conteúdo; mantém o contrato sem corpo da Search Console.
- Inclui testes de regressão e reprodução HTTP local com o transporte Requests/Fsockopen do WordPress.

#### 0.2.0 — 2026-09-08

- Preserva as 21 habilidades e configurações da 0.1.0; acrescenta 93 habilidades.
- Adiciona Search Console, Site Verification, GA Admin em escrita, Ads em escrita, Measurement Protocol, blend e exportação para Sheets/Drive.
- Expõe catálogo e executor baseados em nove documentos oficiais, com 521 métodos no conjunto validado.
- Acrescenta anotações de escrita, auditoria before/after redigida, validateOnly Ads, erros acionáveis e diagnóstico de APIs/escopos.
- Resolve contas por nome e wildcard; inclui conversões customizadas Ads, catálogos completos e isolamento de caches por credencial/delegação.
- Corrige colisão de IDs numéricos em fanout, paginação incompleta/cíclica, repetição indevida de gravações e codificação de objetos JSON vazios.
- Conserva integração com as três metatools e URL do servidor WP MCP Fator3.

#### 0.1.0 — base recebida

21 habilidades de leitura Analytics/Ads/camada unificada, service account e OAuth de usuário, cifra, configuração administrativa, portão geral e auditoria de metadados.
