# Validação — 0.13.0

Escopo: pedido MCP Google 27 e fronteiras afetadas. Percurso: WordPress limpo e atualização Google 0.12.0→0.13.0; mínimos WordPress 7.1.2/PHP 8.3.6. Matriz principal Core 1.38.0/MCP 0.24.0, isolamento e leitor Core 1.39.0. Meta/LinkedIn 0.3.0 são sentinelas preservadas no upgrade.

`tools/release013.py` vincula o candidato por SHA-256 ao inventário e aos ensaios. A regressão específica deve falhar na base e passar no candidato; testes puros verificam falhas, revisão opcional e única chamada ao produtor. WordPress real cobre autorização, MCP HTTP em nova requisição, sucesso/guarda, GTM simulado sem repetição, booleanos, documentação paginada, instalação, atualização e rollback. Rede externa fica bloqueada no laboratório; fixtures não entram no instalador.

Contagens e resultados efetivamente executados constam do relatório externo e de `evidence/013`. Provas 012 e anteriores são históricas. O gate específico não representa execução integral do PHPUnit nem de `tools/validate.py`/`build/build.py verify`; esses mantêm requisitos próprios. O laboratório desta rodada usa PHP CLI server com quatro workers, MySQL isolado e transporte HTTP MCP real; não reivindica validação PHP-FPM.

Não homologados: APIs Google reais, transporte servidor Core 235, jobs/calendário/exportação em produção (pendência 20), navegador, multisite, CDN e cron externo. O leitor não comprova entrega de conversões. Core 1.39.0 só é examinado em laboratório; não é promovido ao Site-Teste por esta rodada. O relatório externo registra o estado efetivo do Site-Teste após a troca Google.
