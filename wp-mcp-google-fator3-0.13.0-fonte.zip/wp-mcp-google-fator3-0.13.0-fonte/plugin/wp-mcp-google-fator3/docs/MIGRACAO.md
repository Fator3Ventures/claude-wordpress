# Instalação, atualização e recuperação — 0.13.0

A base de manutenção é WordPress limpo ou Google **0.12.0**. Instale `wp-mcp-google-fator3-0.13.0-instalador.zip` substituindo a pasta original, **sem desinstalar**. O código não impõe uma faixa de versões de origem nem bloqueia instalação pela versão dos acompanhantes. Não há migrações, aliases ou retomadas de versões anteriores à base.

## Procedimento

1. Preserve backup coerente dos arquivos, banco e material de cifra. Para uma restauração, prepare previamente a guarda externa conforme abaixo.
2. Instale o ZIP de produção conferindo SHA-256. Fontes, ferramentas, testes e arquivos de referência ficam fora do diretório público.
3. Abra nova requisição e confira `google/status`, versão 0.13.0, `google/storage-status.storage.ready`, catálogo 3.0.0 e configuração 4.0.0. Redescubra as ferramentas no cliente MCP.
4. Verifique a conexão ativa, serviços, bindings, política e concessões SDK. A instalação limpa usa Service Account; a atualização preserva o método e as escolhas existentes.
5. Confira a agenda e suas origens separadamente. Execute `google/selftest` para os serviços/recursos necessários, distinguindo execução, aprovação e cobertura incompleta.

A instalação limpa cria `{prefix}f3_google_records` e `{prefix}f3_google_cron`. Na 0.12.0 essas estruturas já são o modelo atual; os registros são usados diretamente, sem recópia ou execução de jobs concluídos. Dados antigos que não fazem parte do modelo atual não são lidos, convertidos nem apagados em massa.

## Contratos preservados da base 0.12.0

- Escrita local `google/maintenance`: uma passagem limitada de retenção, cache e reparação da agenda Google, sob autorização e guarda de recuperação.
- Já retiradas na base 0.9.0: `google/migrate-storage` e `google/complete-transition`, sem aliases. Perfis personalizados devem autorizar expressamente a operação nova. Permissão antiga não é promovida.
- `storage` publica contrato 2.0.0, `ready`, `state`, verificações de tabelas e erro. Não publica fases `legacy/drain/copy/verify`.
- Manutenção 2.0.0 contém somente `cron_retention`, `cache_sql` e `cache_files`. Cron não consulta fontes antigas nem publica `migration_pending`/`legacy_last_pass`.
- Configuração 4.0.0, execução 2.0.0 e SDK GSC 1.0.0 permanecem. Catálogo permanece 3.0.0; a leitura documental existente é preservada.

## Recuperação corrente

`google/recovery {"action":"prepare"}` pausa fora do banco e verifica a drenagem. Somente `ready_for_restore:true` permite avançar no procedimento de restauração. A sentinela em `wp-content/f3-google-state` pertence ao ambiente de destino: preserve a guarda ativa durante a restauração do banco. Não a trate como cache nem a sobrescreva por uma cópia antiga.

Após reconciliar efeitos remotos e conferir banco/arquivos, consulte `google/recovery-status` e retome com `expected_generation` atual e `acknowledge_reconciled:true`. A geração invalida caches e contextos anteriores. Escritas interrompidas continuam `unknown` até reconciliação explícita; não há repetição automática para tentar corrigir histórico.

O rollback do pacote pelo MCP conserva uma pré-imagem de arquivos. `dry_run` verifica sua prontidão sem aplicá-la. **Rollback de arquivos não restaura banco, credenciais alteradas, configuração ou efeitos nas APIs Google.** Retornar aos arquivos 0.12.0 exige avaliar separadamente esses estados.

MCP 0.24.0 e Core 1.38.0 são os acompanhantes da matriz desta entrega. A ordem de instalação não é imposta pelo Google; ausência de capacidade afeta a operação dependente, sem impedir a administração local. Os outros plugins não são modificados pela entrega Google.

## Instalação inicial pelo MCP

O MCP 0.24.0 distingue primeira ativação e reativação silenciosa. O caminho combinado usa `plugins/upload-base64` com hash/slug esperados, `overwrite:false` e `activate:true`; confira o resultado em nova requisição, antes de qualquer manutenção. Também é possível enviar com `activate:false` e chamar `plugins/activate` explicitamente. Plugin já ativo e incompleto exige diagnóstico; repetir ativação não é uma rotina de reparação.

## Percurso 0.13.0

WordPress limpo ou Google 0.12.0 → 0.13.0, sem versões intermediárias. Requisitos declarados: WordPress 7.1.2/PHP 8.3.6. MCP 0.24.0 e Core 1.38.0 são acompanhantes examinados; não são travas numéricas. Nenhuma nova migração de banco, mudança de defaults, credenciais, jobs ou permissões. Jobs/chunks 0.12.0 permanecem no mesmo formato.

No laboratório, o MCP usa upload-base64 com hash e slug esperados; na frota, use a URL raw publicada e verificada e plugins/upload conforme o schema atual. A URL da 0.13.0 não é considerada publicada pelo simples empacotamento. Abra nova requisição e consulte status/armazenamento/documentação antes de manutenção. A ajuda deve identificar 0.13.0 e GUIA-0.13.0.md.

Retornar a 0.12.0 pode restaurar os arquivos sob pré-imagem conferida. Não altera dados nem efeitos externos; mantenha backup coerente. Consulte o relatório externo para a prova efetivamente executada.
