<?php
/** Exact click lookup in one published snapshot and narrowly scoped creative reads. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\{Automation\ExecutorSchedule,Options,Response};
if (!defined('ABSPATH')) { exit; }

final class OriginAd {
    public const CONTRACT = 'google-ads-origin/1.0.0';

    public static function schema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['contract','connection_id','account_id','consumer_revision'],
            'properties'=>['contract'=>['type'=>'string','enum'=>[self::CONTRACT]],'connection_id'=>['type'=>'string','minLength'=>1],
                'account_id'=>['type'=>'string','pattern'=>'^[0-9]{10}$'],'consumer_revision'=>['type'=>'string','minLength'=>1,'maxLength'=>128],
                'date'=>['type'=>'string','format'=>'date'],'gclid'=>['type'=>'string','minLength'=>1,'maxLength'=>1024],
                'ad_id'=>['type'=>'string','pattern'=>'^[1-9][0-9]{0,18}$']],
            'oneOf'=>[['required'=>['ad_id'],'not'=>['anyOf'=>[['required'=>['gclid']],['required'=>['date']]]]],
                      ['required'=>['gclid','date'],'not'=>['required'=>['ad_id']]]]];
    }

    public static function output_schema(): array {
        $text=['type'=>'string']; $nullable=['type'=>['string','null']];
        $strings=['type'=>'array','items'=>$text];
        $media=['type'=>'array','items'=>['type'=>'object','required'=>['asset_id','type','role','download_url','thumbnail_url'],
            'properties'=>['asset_id'=>$text,'type'=>['enum'=>['image','youtube']],'role'=>$text,'download_url'=>$nullable,'thumbnail_url'=>$nullable,
                'thumbnail_source'=>$text,'card_asset_id'=>$text,'watch_url'=>$text,'video_id'=>$text,'download_reason'=>$text]]];
        $entity=['id'=>$text,'name'=>$nullable,'ads_url'=>$text];
        $creative=['paths'=>$strings,'headlines'=>$strings,'descriptions'=>$strings,'final_urls'=>$strings,'media'=>$media];
        return ['type'=>'object','required'=>['success','message'],'properties'=>[
            'success'=>['type'=>'boolean'],'message'=>$text,'error_code'=>$text,'contract'=>['enum'=>[self::CONTRACT]],'connection_id'=>$text,'account_id'=>$text,
            'state'=>['enum'=>['found','pending','campaign_only','ambiguous','archive_partial','click_not_found','ad_not_found','origin_unavailable']],
            'ad_id'=>$text,'ad_type'=>$text,'campaign'=>['type'=>'object','properties'=>$entity],
            'ad_group'=>['type'=>['object','null'],'properties'=>$entity],'asset_groups'=>['type'=>'array','items'=>['type'=>'object','properties'=>$entity+$creative]],
            'attribution'=>$text,'asset_scope'=>$text,'archive_revision'=>$text,'expected_collection_at'=>$nullable,'schedule_reason'=>$text,'assets_complete'=>['type'=>'boolean']]+$creative];
    }

    public static function valid(array $i): bool {
        $s=self::schema();
        if (array_diff($s['required'],array_keys($i)) || array_diff(array_keys($i),array_keys($s['properties']))) { return false; }
        foreach ($i as $v) { if (!is_string($v) || $v==='') { return false; } }
        if ($i['contract']!==self::CONTRACT || !preg_match('/^[0-9]{10}$/D',$i['account_id']) || strlen($i['consumer_revision'])>128) { return false; }
        if (isset($i['ad_id'])) { return !isset($i['date']) && !isset($i['gclid']) && (bool)preg_match('/^[1-9][0-9]{0,18}$/D',$i['ad_id']); }
        return isset($i['date'],$i['gclid']) && ArchiveQuery::valid_date($i['date']) && strlen($i['gclid'])<=1024;
    }

    private static function pending(string $account,string $date): array {
        $cfg=Archive::config();
        if (is_wp_error($cfg)) { return Response::fail($cfg); }
        $account_cfg=$cfg[$account]??[];
        $reason='collection_inactive'; $at=null;
        if (in_array('clicks',$account_cfg['datasets']??[],true) && !Archive::guard($account,$account_cfg)) {
            $zone=new \DateTimeZone($account_cfg['time_zone']);
            $day=new \DateTimeImmutable($date,$zone);
            $today=new \DateTimeImmutable('today',$zone);
            $age=(int)$day->diff($today)->format('%r%a');
            $schedule=ExecutorSchedule::status();
            $plan=ArchiveStore::get('adsplan',ArchiveStore::key($account,'plan',''));
            if (is_wp_error($plan)) { return Response::fail($plan); }
            $reason='executor_unscheduled';
            if ($age<0 || $age>min(90,max($account_cfg['backfill_days'],$account_cfg['revisit_days']))) { $reason='outside_collection_window'; }
            elseif (($schedule['state']??'')==='present' && $schedule['desired_state']==='active') {
                $next=max(time(),$schedule['next_run']);
                $retry=$plan['deferred']['clicks|'.$date]['retry_at']??0;
                $index=array_search('clicks',$account_cfg['datasets'],true);
                $phase=$age<=$account_cfg['revisit_days']?'revisit':'backfill';
                $same=($plan['cycle']??'')===$today->format('Y-m-d') && ($plan['grant_revision']??'')===$account_cfg['revision'];
                $first=$phase==='revisit'?1:$account_cfg['revisit_days']+1;
                $offset=$same?($plan[$phase.'_offset']??$first):$first;
                $position=$same?($plan[$phase.'_index']??0):0;
                $ahead=($age-$offset)*count($account_cfg['datasets'])+$index-$position;
                if ($age===0) { $next=max($next,$day->modify('+1 day')->getTimestamp()); $ahead=$index; }
                elseif (($plan['working']['date']??'')===$date && ($plan['working']['dataset']??'')==='clicks' || $retry) { $ahead=0; }
                elseif ($ahead<0) {
                    if ($age<$account_cfg['revisit_days']) { $next=max($next,$today->modify('+1 day')->getTimestamp()); $ahead=$age*count($account_cfg['datasets'])+$index; }
                    else { return Response::ok(['state'=>'pending','expected_collection_at'=>null,'schedule_reason'=>'no_future_slice'],'Pendente. O planejador já passou por este dia.'); }
                }
                $at=gmdate('c',max($retry,$next+max(0,$ahead)*$schedule['expected']['interval']));
                $reason='estimated_queue_slot';
            }
        }
        return Response::ok(['state'=>'pending','expected_collection_at'=>$at,'schedule_reason'=>$reason],'Pendente. Consulte a previsão da coleta do dia.');
    }

    public static function resolve(array $i,callable $search): array {
        $account=$i['account_id']; $campaign=null; $group=null; $id=$i['ad_id']??null;
        if ($id===null) {
            $m=ArchiveStore::latest($account,'clicks',$i['date']);
            if (is_wp_error($m)) { return Response::fail($m); }
            if ($m===null) { return self::pending($account,$i['date']); }
            $match=null;
            foreach ($m['chunks'] as $chunk) {
                $data=ArchiveStore::get('adsrows',$chunk['id']);
                if (is_wp_error($data)) { return Response::fail($data); }
                if (!is_array($data['rows']??null) || count($data['rows'])!==$chunk['count']) { return Archive::fail('corrupt','Bloco do acervo incompleto.'); }
                foreach ($data['rows'] as $row) {
                    if (($row['gclid']??null)!==$i['gclid']) { continue; }
                    $identity=[$row['ad']??null,$row['campaign_id']??null,$row['ad_group_id']??null];
                    if ($match!==null && $match!==$identity) { return Response::ok(['state'=>'ambiguous'],'O acervo contém origens distintas para este clique.'); }
                    $match=$identity;
                }
            }
            $current=ArchiveStore::latest($account,'clicks',$i['date']);
            if (!is_array($current) || $current['revision']!==$m['revision']) { return Archive::fail('revision','A coleta mudou durante a leitura. Repita a consulta.'); }
            if ($match===null) {
                return Response::ok(['state'=>empty($m['coverage']['truncated'])?'click_not_found':'archive_partial','archive_revision'=>$m['revision']]);
            }
            [$resource,$campaign,$group]=$match;
            if (!is_string($campaign) || !ctype_digit($campaign)) { return Response::ok(['state'=>'origin_unavailable']); }
            if ($resource===null || $resource==='') { return self::campaign_groups($campaign,$search); }
            if (!preg_match('~^customers/'.$account.'/adGroupAds/([0-9]+)\\~([0-9]+)$~D',$resource,$parts) || ($group && $group!==$parts[1])) { return Archive::fail('identity','O recurso do clique diverge da conta ou grupo arquivado.'); }
            [, $group,$id]=$parts;
        }
        $a='ad_group_ad.ad.';
        $fields=['campaign.id','campaign.name','campaign.advertising_channel_type','ad_group.id','ad_group.name',$a.'id',$a.'type',$a.'final_urls'];
        foreach (['responsive_search_ad'=>['path1','path2','headlines','descriptions'],'expanded_text_ad'=>['path1','path2','headline_part1','headline_part2','headline_part3','description','description2'],'demand_gen_video_responsive_ad'=>['breadcrumb1','breadcrumb2']] as $kind=>$props) {
            foreach ($props as $prop) { $fields[]=$a.$kind.'.'.$prop; }
        }
        $where=$a.'id = '.$id.($group?' AND ad_group.id = '.$group.' AND campaign.id = '.$campaign:'');
        $response=$search('SELECT '.implode(', ',$fields).' FROM ad_group_ad WHERE '.$where.' LIMIT 2');
        if (is_wp_error($response)) { return Response::fail($response); }
        $rows=$response['results']??[];
        if (!$rows) { return Response::ok(['state'=>'ad_not_found']); }
        if (count($rows)!==1 || !empty($response['nextPageToken'])) { return Response::ok(['state'=>'ambiguous']); }
        $row=$rows[0]; $ad=$row['adGroupAd']['ad']??[];
        if ((string)($ad['id']??'')!==$id || !ctype_digit((string)($row['campaign']['id']??'')) || !ctype_digit((string)($row['adGroup']['id']??'')) ||
            ($group!==null && ((string)$row['adGroup']['id']!==$group || (string)$row['campaign']['id']!==$campaign))) { return Archive::fail('identity','A identidade do anúncio retornado diverge da consulta.'); }
        $group=(string)$row['adGroup']['id']; $campaign=(string)$row['campaign']['id'];
        $creative=self::creative();
        foreach (['responsiveSearchAd','expandedTextAd','demandGenVideoResponsiveAd'] as $kind) {
            $details=$ad[$kind]??[];
            foreach (['headlinePart1','headlinePart2','headlinePart3','description','description2','path1','path2','breadcrumb1','breadcrumb2'] as $key) {
                if (!empty($details[$key])) { $creative[str_starts_with($key,'headline')?'headlines':(str_starts_with($key,'description')?'descriptions':'paths')][]=$details[$key]; }
            }
            foreach (['headlines','descriptions'] as $key) { foreach ($details[$key]??[] as $t) { if (!empty($t['text'])) { $creative[$key][]=$t['text']; } } }
        }
        $limit=max(1,min(500,Options::max_rows()));
        $raw=$search('SELECT ad_group_ad_asset_view.field_type, '.self::ASSET_FIELDS.', '.self::CARD_FIELDS.' FROM ad_group_ad_asset_view WHERE ad_group_ad.ad.id = '.$id.' AND ad_group.id = '.$group.' AND ad_group_ad_asset_view.enabled = TRUE LIMIT '.($limit+1));
        if (is_wp_error($raw)) { return Response::fail($raw); }
        $complete=count($raw['results']??[])<=$limit && empty($raw['nextPageToken']);
        $cards=[];
        foreach (array_slice($raw['results']??[],0,$limit) as $r) {
            $asset=$r['asset']??[];
            self::asset($creative,$asset,$r['adGroupAdAssetView']['fieldType']??'');
            $card=$asset['demandGenCarouselCardAsset']??[];
            if (!empty($card['headline'])) { $creative['headlines'][]=$card['headline']; }
            foreach (['marketingImageAsset','squareMarketingImageAsset','portraitMarketingImageAsset'] as $role) {
                if (!empty($card[$role]) && preg_match('~^customers/'.$account.'/assets/([0-9]+)$~D',$card[$role],$m)) {
                    $cards[$m[1]][]=['card_asset_id'=>(string)$asset['id'],'role'=>$role];
                }
            }
        }
        if ($cards) {
            $images=$search('SELECT asset.id, asset.type, asset.image_asset.full_size.url FROM asset WHERE asset.id IN ('.implode(',',array_keys($cards)).') LIMIT '.($limit+1));
            if (is_wp_error($images)) { return Response::fail($images); }
            foreach (array_slice($images['results']??[],0,$limit) as $r) {
                $asset=$r['asset']??[]; $key=$asset['id']??'';
                if (($asset['type']??'')!=='IMAGE' || !isset($cards[$key])) { continue; }
                foreach ($cards[$key] as $use) {
                    self::asset($creative,$asset,$use['role']);
                    $creative['media'][array_key_last($creative['media'])]['card_asset_id']=$use['card_asset_id'];
                }
                unset($cards[$key]);
            }
            $complete=$complete && !$cards;
        }
        foreach (['headlines','descriptions'] as $key) { $creative[$key]=array_values(array_unique($creative[$key])); }
        return Response::ok(['state'=>'found','attribution'=>isset($i['gclid'])?'archived_click':'lead_form_ad_id','asset_scope'=>'current_ad_associations',
            'campaign'=>self::entity($row['campaign']),'ad_group'=>self::entity($row['adGroup'],$campaign),'ad_id'=>$id,'ad_type'=>$ad['type']??'UNKNOWN',
            'final_urls'=>$ad['finalUrls']??[],'assets_complete'=>$complete]+$creative);
    }

    private const CARD_FIELDS='asset.demand_gen_carousel_card_asset.headline, asset.demand_gen_carousel_card_asset.marketing_image_asset, asset.demand_gen_carousel_card_asset.square_marketing_image_asset, asset.demand_gen_carousel_card_asset.portrait_marketing_image_asset';
    private const ASSET_FIELDS='asset.id, asset.type, asset.text_asset.text, asset.image_asset.full_size.url, asset.youtube_video_asset.youtube_video_id';
    private static function creative(): array { return ['headlines'=>[],'descriptions'=>[],'paths'=>[],'media'=>[]]; }
    private static function entity(array $entity,?string $campaign=null): array {
        $id=(string)$entity['id'];
        return ['id'=>$id,'name'=>$entity['name']??null,'ads_url'=>'https://ads.google.com/aw/'.($campaign===null?'campaigns?campaignId='.$id:'ads?campaignId='.$campaign.'&adGroupId='.$id)];
    }
    private static function asset(array &$out,array $asset,string $role): void {
        $type=$asset['type']??''; $text=$asset['textAsset']['text']??null;
        if ($text && in_array($role,['HEADLINE','LONG_HEADLINE','DESCRIPTION'],true)) { $out[$role==='DESCRIPTION'?'descriptions':'headlines'][]=$text; }
        if ($type==='IMAGE') {
            $url=$asset['imageAsset']['fullSize']['url']??null;
            $url=is_string($url)&&wp_parse_url($url,PHP_URL_SCHEME)==='https'?$url:null;
            $out['media'][]=['type'=>'image','role'=>$role,'asset_id'=>(string)$asset['id'],'download_url'=>$url,'thumbnail_url'=>$url,'thumbnail_source'=>'original'];
        }
        if ($type==='YOUTUBE_VIDEO') {
            $id=$asset['youtubeVideoAsset']['youtubeVideoId']??'';
            if (preg_match('/^[A-Za-z0-9_-]{11}$/D',$id)) {
                $out['media'][]=['type'=>'youtube','role'=>$role,'asset_id'=>(string)$asset['id'],'video_id'=>$id,'watch_url'=>'https://www.youtube.com/watch?v='.$id,
                    'thumbnail_url'=>'https://i.ytimg.com/vi/'.$id.'/hqdefault.jpg','download_url'=>null,'download_reason'=>'provider_exposes_video_id_only'];
            }
        }
    }

    private static function campaign_groups(string $id,callable $search): array {
        $raw=$search('SELECT campaign.id, campaign.name, campaign.advertising_channel_type FROM campaign WHERE campaign.id = '.$id.' LIMIT 1');
        if (is_wp_error($raw)) { return Response::fail($raw); }
        $c=$raw['results'][0]['campaign']??[];
        if ((string)($c['id']??'')!==$id || ($c['advertisingChannelType']??'')!=='PERFORMANCE_MAX') { return Response::ok(['state'=>'origin_unavailable']); }
        $limit=max(1,min(500,Options::max_rows()));
        $raw=$search('SELECT campaign.id, asset_group.id, asset_group.name, asset_group.final_urls, asset_group.path1, asset_group.path2, asset_group_asset.field_type, '.self::ASSET_FIELDS." FROM asset_group_asset WHERE campaign.id = ".$id." AND asset_group_asset.status != 'REMOVED' ORDER BY asset_group.id, asset.id LIMIT ".($limit+1));
        if (is_wp_error($raw)) { return Response::fail($raw); }
        $groups=[];
        foreach (array_slice($raw['results']??[],0,$limit) as $r) {
            $g=$r['assetGroup']??[];
            if ((string)($r['campaign']['id']??'')!==$id || !ctype_digit((string)($g['id']??''))) { return Archive::fail('identity','Grupo de recursos de outra campanha ou ilegível.'); }
            $k=$g['id'];
            $groups[$k]??=['id'=>(string)$k,'name'=>$g['name']??null,'final_urls'=>$g['finalUrls']??[],
                'ads_url'=>'https://ads.google.com/aw/assetgroups?campaignId='.$id.'&assetGroupId='.$k,'paths'=>array_values(array_filter([$g['path1']??null,$g['path2']??null]))]+self::creative();
            self::asset($groups[$k],$r['asset']??[],$r['assetGroupAsset']['fieldType']??'');
        }
        return Response::ok(['state'=>'campaign_only','ad_type'=>'PERFORMANCE_MAX','attribution'=>'campaign_only','asset_scope'=>'candidate_asset_groups','campaign'=>self::entity($c),'ad_group'=>null,
            'asset_groups'=>array_values($groups),'assets_complete'=>count($raw['results']??[])<=$limit && empty($raw['nextPageToken'])]);
    }
}
