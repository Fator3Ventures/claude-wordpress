<?php
/**
 * A habilidade que diz ao agente COMO USAR este plugin.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * O MANUAL DE USO, montado do registro de módulos.
 *
 * POR QUE ISTO EXISTE. Depois da entrega, quem muda este site é um agente por
 * MCP. Sem saber o que o plugin já faz, o caminho natural do agente é resolver
 * cada pedido por onde ele conhece: injetar o GTM no tema, instalar um plugin de
 * pixel, escrever um segundo llms.txt. Nada disso falha — e é esse o problema.
 * O site passa a ter dois emissores da mesma tag, a conversão é contada duas
 * vezes, a campanha otimiza para um número inflado e ninguém vê erro nenhum.
 *
 * A LISTA SAI DO REGISTRO, nunca de um texto escrito à mão. Um manual digitado
 * envelhece na primeira vez que alguém acrescenta um módulo e esquece de
 * atualizá-lo — e um manual desatualizado é pior que nenhum, porque o agente
 * confia nele. Módulo novo aparece aqui sozinho, com o que ele controla e o
 * estado em que está.
 */
final class F3Base_Como_Usar {

	/**
	 * Nome da habilidade registrada na Abilities API.
	 *
	 * @var string
	 */
	public const HABILIDADE = 'f3base/como-usar';

	/**
	 * Registra a habilidade quando a API existir.
	 *
	 * O GANCHO NÃO MORA AQUI: quem engancha é `F3Base_Site_Core::iniciar()`, em
	 * `wp_abilities_api_init`, e a categoria `f3base` é registrada antes, em
	 * `wp_abilities_api_categories_init`. As duas grafias foram medidas contra um
	 * WordPress real: o núcleo recusa habilidade sem `category` conhecida, e um
	 * `add_action` em `abilities_api_init` — sem o `wp_` — não é chamado nunca.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		F3Base_Servicos::registrar_ability(
			self::HABILIDADE,
			array(
				'label'               => __( 'Como usar o plugin do site', 'f3base' ),
				'description'         => __( 'O que este plugin já faz, por onde mudar cada coisa e o que NÃO fazer por outro caminho. Leia antes de instalar plugin de medição, editar o tema ou escrever configuração à mão.', 'f3base' ),
				'category'            => F3BASE_PREFIXO,
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => F3Base_Config_Consultas::propriedades(),
					'additionalProperties' => false,
				),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
				'output_schema'       => self::schema_da_resposta(),
				'execute_callback'    => array( __CLASS__, 'responder' ),
				'permission_callback' => static function ( $entrada = null ): bool {
					unset( $entrada );

					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * O QUE ESTA HABILIDADE DEVOLVE, campo a campo.
	 *
	 * O DEFEITO MEDIDO: o `output_schema` era `array( 'type' => 'object' )` — um
	 * objeto de forma desconhecida. Um agente que lê só o schema não sabia que a
	 * resposta traz `assuntos` com a option de cada assunto, e o caminho natural
	 * dele era executar para descobrir. Schema de saída existe para ser lido
	 * ANTES da chamada.
	 *
	 * @return array<string,mixed>
	 */
	public static function schema_da_resposta(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'plugin'       => array(
					'type'        => 'string',
					'description' => __( 'Slug do plugin que respondeu: base-site-core-fator3.', 'f3base' ),
				),
				'versao'       => array(
					'type'        => 'string',
					'description' => __( 'Versão lida do cabeçalho do plugin instalado.', 'f3base' ),
				),
				'resumo'       => array(
					'type'        => 'string',
					'description' => __( 'Uma frase com o que o plugin já cobre.', 'f3base' ),
				),
				'assuntos'     => array(
					'type'        => 'array',
					'description' => __( 'Um item por módulo do registro, na ordem em que a tela os apresenta.', 'f3base' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'assunto' => array( 'type' => 'string' ),
							'id'      => array( 'type' => 'string' ),
							'faz'     => array( 'type' => 'string' ),
							'options' => array(
								'type'        => 'array',
								'items'       => array( 'type' => 'string' ),
								'description' => __( 'Os nomes de option que mudam ESTE assunto. É por aqui que se muda o comportamento.', 'f3base' ),
							),
							'estado'  => array( 'type' => 'string' ),
							'por_que' => array( 'type' => 'string' ),
						),
					),
				),
				'nao_faca'     => array(
					'type'        => 'array',
					'description' => __( 'Caminhos paralelos que funcionam e custam caro, com o preço de cada um e a saída certa.', 'f3base' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'nao'    => array( 'type' => 'string' ),
							'porque' => array( 'type' => 'string' ),
							'faca'   => array( 'type' => 'string' ),
						),
					),
				),
				'como_mudar'   => array(
					'type'        => 'string',
					'description' => __( 'Por onde a option é gravada e quando o valor passa a valer.', 'f3base' ),
				),
				'configuracao' => array(
					'type'        => 'object',
					'description' => 'Operações do dono, separação de escopos e interpretação dos resultados de gravação.',
				),
			),
		);
	}

	/**
	 * A resposta: legível por máquina e por gente.
	 *
	 * A ASSINATURA ACEITA A ENTRADA QUE O NÚCLEO MANDA, e ela pode ser `null`.
	 * Com `strict_types=1`, um parâmetro tipado `array` sem padrão seguro
	 * derruba a execução com TypeError na primeira chamada em que o núcleo não
	 * tem entrada para passar — e a habilidade passaria a existir no registro e
	 * a falhar ao executar, que é pior que não existir.
	 *
	 * @param mixed $entrada Filtros opcionais; ausência preserva o manual completo.
	 * @return array<string,mixed>
	 */
	public static function responder( $entrada = null ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		$erro = F3Base_Config_Consultas::validar( $entrada );
		if ( '' !== $erro ) {
			return array(
				'ok'     => false,
				'codigo' => $erro,
			); }
		return self::resposta( $entrada ?? array() );
	}

	/**
	 * O corpo da resposta.
	 *
	 * @return array<string,mixed>
	 */
	private static function resposta( array $entrada = array() ): array {
		$r = array(
			'plugin'       => 'base-site-core-fator3',
			'documentacao' => F3Base_Configuracao_Atual::documentacao(),
			'versao'       => defined( 'F3BASE_PLUGIN_VERSAO' ) ? F3BASE_PLUGIN_VERSAO : '',
			'resumo'       => __( 'Este plugin já cuida de medição, consentimento, leads, llms.txt, redirects, cabeçalhos, noindex e schema. Mude o comportamento gravando as options listadas aqui — não por outro plugin, não pelo tema, não por tag manager paralelo.', 'f3base' ),
			'assuntos'     => self::assuntos( $entrada ),
			'nao_faca'     => F3Base_Config_Consultas::incluir( $entrada, 'instrucoes' ) ? self::nao_faca() : array(),
			'como_mudar'   => __( 'Consulte f3base/config-core-contrato-v1 e leia a opção com f3base/config-core-ler. Simule e aplique por f3base/config-core-escrever; em PHP use F3Base_Options::gravar(nome, valor, origem, revisao_esperada). O dono executa recusa, normalização, persistência, procedência e efeitos posteriores. Confira persisted, effect e verification separadamente. JSONs do implantador só chegam ao site quando sua execução aplica as opções pelo dono. A recusa do Core é falha da aplicação; preserve o valor vigente e o motivo, sem impor a preferência por update_option, SQL ou pelo tema.', 'f3base' ),
			'configuracao' => array(
				'contract_version'     => F3Base_Config_Contrato::VERSAO,
				'contrato'             => F3Base_Config_Contrato::HABILIDADE,
				'site'                 => array(
					'ler'       => 'f3base/config-core-ler',
					'escrever'  => 'f3base/config-core-escrever',
					'verificar' => F3Base_Config_Contrato::VERIFICAR,
					'scope'     => 'site_configuration',
				),
				'implantador'          => array(
					'ler'            => 'f3base/config-ler',
					'escrever'       => 'f3base/config-escrever',
					'scope'          => 'installer_json',
					'aplica_no_site' => false,
				),
				'resultado'            => array(
					'persisted'    => 'True somente depois de confirmar o valor normalizado no banco. False na recusa e na simulação.',
					'effect'       => 'Resultado do efeito síncrono do dono: applied, failed, not_required ou not_attempted.',
					'audit'        => 'Registro de procedência vinculado à revisão confirmada. pending indica falha ou mudança concorrente da auditoria; não anula persisted.',
					'verification' => 'Prova do comportamento e seu escopo. pending exige observação; verified vale somente para scope e checked_at informados.',
					'ok'           => 'Compatibilidade: persistência e efeito síncrono concluídos; na simulação, proposta aceita. Não significa comportamento público verificado.',
				),
				'mescla'               => 'mesclar=true aceita campos declarados de options compostas, com revisão obrigatória. Omitir preserva, listas substituem integralmente e null só é aceito pelo schema. A prévia e a aplicação usam a mesma revisão.',
				'procedencia'          => 'Origem sem revisão confirmada é desconhecida. O rótulo edicao-manual é compatibilidade; canal identifica ability/admin/php/cli sem provar autoria humana. Histórico ausente não comprova que o valor nunca existiu.',
				'protecao_do_canal'    => 'Options próprias são protegidas no canal genérico MCP. Use f3base/config-core-escrever; O journal de implantação pertence ao implantador e não integra a proteção do Core.',
				'apos_persistencia'    => 'Com persisted=true, consulte a verificação antes de qualquer nova gravação. Falha de efeito pertence ao Core; examine o diagnóstico do módulo. O robots possui reconciliação e verificação automáticas, sujeitas ao WP-Cron. Não transfira esse efeito para o tema.',
				'release_1102'         => 'Google: imediato por padrão, apos_interacao afeta somente GA4/Ads diretos. llms: dinamica ou arquivo_gerado, sem assumir propriedade de arquivo externo. Schema: autoria usuario|organizacao e entidade validada. f3base/schema-verificar e f3base/llms-arquivo separam consulta de ação com revisão. Auditoria distingue origem histórica e vínculo atual; saúde operacional é independente.',
				'politica_privacidade' => 'Página opcional: ausência não impede o plugin, não muda o consentimento escolhido e não gera uma página ou link fictício.',
			),
		);
		if ( F3Base_Config_Consultas::incluir( $entrada, 'integracoes' ) ) {
			$r['integracoes'] = F3Base_Config_Consultas::integracoes( ! empty( $entrada['compacto'] ) ); }
		if ( ! F3Base_Config_Consultas::incluir( $entrada, 'instrucoes' ) ) {
			unset( $r['nao_faca'], $r['como_mudar'], $r['resumo'] );
			$r['configuracao'] = array(
				'contract_version' => F3Base_Config_Contrato::VERSAO,
				'contrato'         => F3Base_Config_Contrato::HABILIDADE,
			); }
		if ( F3Base_Config_Consultas::incluir( $entrada, 'mudancas' ) ) {
			$r['mudancas'] = F3Base_Config_Consultas::mudancas( $entrada ); }
		if ( F3Base_Config_Consultas::incluir( $entrada, 'agenda' ) ) {
			$r['agenda'] = F3Base_Operacao::agenda(); }
		if ( F3Base_Config_Consultas::incluir( $entrada, 'saude' ) ) {
			$r['saude'] = F3Base_Saude::resumo(); }
		$r['execucoes']=F3Base_Execucoes::resumo();$r['atualizacao']=F3Base_Instalacao::resumo();$r['recuperacao']=F3Base_Recuperacao::ler();$r['documentacao_1200']='docs/OPERACAO-GSC-1.20.md';
        return F3Base_Evidencias::projetar($r);
	}

	/**
	 * Os assuntos, um por módulo do registro.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function assuntos( array $entrada = array() ): array {
		$saida = array();

		foreach ( F3Base_Registro::modulos() as $modulo ) {
			if ( isset( $entrada['assuntos'] ) && ! in_array( $modulo->id(), $entrada['assuntos'], true ) ) {
				continue; }
			$estado = $modulo->estado();

			$item = array(
				'assunto'    => $modulo->nome(),
				'id'         => $modulo->id(),
				'faz'        => $modulo->descricao(),
				'options'    => $modulo->options_que_controlam(),
				'estado'     => (string) ( $estado['estado'] ?? '' ),
				'por_que'    => (string) ( $estado['motivo'] ?? '' ),
				'integracao' => F3Base_Config_Consultas::incluir( $entrada, 'instrucoes' ) ? self::integracao( $modulo->id() ) : '',
			);
			if ( ! empty( $entrada['compacto'] ) ) {
				$item           = array_intersect_key( $item, array_flip( array( 'id', 'options', 'estado' ) ) );
				$item['codigo'] = (string) ( $estado['codigo'] ?? $estado['estado'] ?? '' ); }
			if ( F3Base_Config_Consultas::incluir( $entrada, 'procedencia' ) ) {
				foreach ( $modulo->options_que_controlam() as $nome ) {
					if ( null !== F3Base_Options::declaracao( $nome ) ) {
						$item['procedencia'][ $nome ] = F3Base_Options::procedencia( $nome ); }
				}
			}
			$saida[] = $item;
		}

		return $saida;
	}

	private static function integracao( string $id ): string {
		if ( in_array( $id, array( 'endpoint-leads', 'comportamento' ), true ) ) {
			return 'As respostas dinâmicas incluem Expires no passado para impedir a expiração automática do Apache. As rotas dinâmicas do namespace ' . F3BASE_REST_NAMESPACE . ' devem permanecer fora de todo cache de página ou proxy. Derive exclusões de rest_url, cobrindo rest_route e subdiretório. WP Super Cache já rejeita REST no fluxo normal e oferece API de exclusões; mescle regras e elimine entradas antigas. Token cacheado pode permanecer vencido. Renovação tem cota própria; comportamento e esquecimento renovam sem depender de HTML novo. Consulte integracoes.cache.limite_token. Um beacon aceito não confirma gravação.';
		}
		if ( in_array( $id, array( 'cabecalhos', 'cache-publico' ), true ) ) {
			return 'Consulte f3base/config-core-verificar. acao=consultar apenas lê evidência e agendamento, sem migrar nem executar tarefas. cache.historico preserva a última tentativa e o último sucesso; esses dados não validam a geração atual. cache.agendamento.ultima_execucao identifica origem, início/fim e geração. Confira sonda.persisted e efeito_cache separadamente; verificar_publico executa GET anônimo; atualizar_cache repete a limpeza e verifica. Ações ativas exigem revisao_esperada e não alteram a preferência. A ausência de HIT comprovado deixa a verificação pendente. A mesma tarefa faz dois GETs por rota de token ativa e registra corpo repetido, no-store ausente ou Cache-Control duplicado em integracoes.cache.tokens. integracoes.cache.requisitos compara as exclusões literais, exige ativação e lista de parâmetros de rastreamento sem ref; o Core não grava a configuração do provedor. Cron do servidor é necessário quando o cache não deixa o WordPress executar na frequência requerida.';
		}
		if ( in_array( $id, array( 'llms-txt-reserva', 'llms-full-txt', 'llms-markdown', 'robots-txt', 'schema-extensao', 'noindex-honrado' ), true ) ) {
			return 'Yoast responde por SEO, canonical e sitemap; Core estende o grafo pelos filtros do Yoast. Perfil recomendado: llms curto e full pelo Core, desligando a geração correspondente pela operação autorizada do Yoast. Preserve configurações existentes e arquivos de terceiros; desligar uma opção não comprova remoção do físico. O Core preserva as regras válidas de robots e os backups existentes.';
		}
		return '';
	}

	/**
	 * OS NOMES DE OPTION DE UM MÓDULO, lidos do REGISTRO.
	 *
	 * O DEFEITO MEDIDO, e ele mandava o agente gravar no lugar errado: a lista
	 * do "não faça" trazia `f3base_tracking` e `f3base_leads` escritas à mão, e
	 * NENHUMA DAS DUAS EXISTE no catálogo. Quem seguisse a instrução gravaria
	 * uma option que módulo nenhum lê — sem erro, sem aviso, sem efeito —, e
	 * concluiria que o plugin não faz o que o próprio manual dele afirma.
	 *
	 * A ÂNCORA É O REGISTRO, e não uma segunda lista: `options_que_controlam()`
	 * é a mesma declaração que a tela, o relatório e o assunto acima leem. Um
	 * módulo que passe a governar outra option aparece aqui sozinho, e uma option
	 * que deixe de existir some daqui na mesma release.
	 *
	 * @param string $id      Identificador do módulo no registro.
	 * @param string $reserva Frase usada quando o módulo não está no registro.
	 * @return string Nomes separados por vírgula, ou a reserva.
	 */
	public static function options_de( string $id, string $reserva ): string {
		$modulo = F3Base_Registro::modulo( $id );

		if ( null === $modulo ) {
			return $reserva;
		}

		$nomes = array_values( array_filter( array_map( 'strval', $modulo->options_que_controlam() ) ) );

		return array() === $nomes ? $reserva : implode( ', ', $nomes );
	}

	/**
	 * O QUE NÃO FAZER, e o preço de cada um.
	 *
	 * Cada item nomeia o caminho alternativo que o agente tomaria e o efeito
	 * medido de tomá-lo. Não é uma lista de proibições: é a explicação de por
	 * que o caminho paralelo custa caro, para quem precisa decidir.
	 *
	 * TODO NOME DE OPTION CITADO AQUI SAI DO REGISTRO. Nenhum é digitado: a
	 * frase é o que muda entre um item e outro, e o nome vem de quem o declara.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function nao_faca(): array {
		$reserva = __( '(nenhuma: esta parte está fora do registro nesta instalação)', 'f3base' );

		return array(
			array(
				'nao'    => __( 'Não injete GTM, GA4, Pixel da Meta, Google Ads ou Insight Tag do LinkedIn pelo tema, por plugin de terceiro ou por um segundo tag manager.', 'f3base' ),
				'porque' => __( 'Este plugin já emite todas elas a partir dos IDs gravados em option, e um emissor por fornecedor. Dois emissores contam a mesma conversão duas vezes: a campanha otimiza para um número inflado e nada aparece como erro.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Grave o identificador de cada fornecedor na option correspondente: %s. Deixe o identificador vazio para desligar aquele fornecedor.', 'f3base' ),
					self::options_de( 'tracking', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não instale plugin de consentimento nem escreva o consentimento por fora.', 'f3base' ),
				'porque' => __( 'A decisão de consentimento aqui é quem libera cada tag. Um segundo controlador cria dois estados para o mesmo visitante, e o que decide passa a ser a ordem de carregamento — que muda de página para página.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Ajuste a option %s.', 'f3base' ),
					self::options_de( 'consentimento', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não crie um segundo produtor de /llms.txt nem de /llms-full.txt.', 'f3base' ),
				'porque' => __( 'Arquivo físico tem precedência sobre rota virtual. O Yoast pode criar llms.txt físico. Preserve o responsável vigente até configurar a migração e confirmar backup e conteúdo público.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Ajuste a option %s.', 'f3base' ),
					self::options_de( 'llms-txt-reserva', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não crie endpoint próprio para receber lead do formulário do site.', 'f3base' ),
				'porque' => __( 'O endpoint deste plugin já valida, limita por IP, registra e dispara a conversão com o mesmo event_id do navegador. Um segundo caminho recebe lead sem nada disso, e a conversão dele não deduplica.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Use o endpoint existente; quem governa o destino e a guarda do que ele recebe são as options %s.', 'f3base' ),
					self::options_de( 'endpoint-leads', $reserva )
				),
			),
			array(
				'nao'    => __( 'Não declare cabeçalhos entregues apenas porque o Core está habilitado.', 'f3base' ),
				'porque' => __( 'O cache pode responder antes de carregar o Core. Simple, WP-Cache com cabeçalhos e Expert exigem comprovação pública. No Expert, a infraestrutura pode precisar fornecer os cabeçalhos; coordene valores para evitar políticas conflitantes.', 'f3base' ),
				'faca'   => sprintf(
					/* translators: %s: nomes de option, separados por vírgula. */
					__( 'Ajuste a option %s.', 'f3base' ),
					self::options_de( 'cabecalhos', $reserva )
				),
			),
		);
	}
}
