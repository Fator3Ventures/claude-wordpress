<?php
/** Barreira local independente do banco restaurado e dos arquivos do plugin. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Recuperacao {
    private static $trabalho=null;
    private static int $profundidade=0;
    private static function base(): string {return WP_CONTENT_DIR.'/f3-core-state/site-'.get_current_blog_id();}
    public static function ler(): array {
        $p=self::base().'.php';
        if(!is_file($p)||is_link($p)){return array('ok'=>false,'pausado'=>true,'codigo'=>'sentinela_indisponivel','geracao'=>0,'pronto_para_restaurar'=>false);}
        $raw=@file_get_contents($p);$s=is_string($raw)&&str_starts_with($raw,"<?php exit; ?>\n")?json_decode(substr($raw,14),true):null;
        if(!is_array($s)||!isset($s['geracao'],$s['pausado'])){return array('ok'=>false,'pausado'=>true,'codigo'=>'sentinela_invalida','geracao'=>0,'pronto_para_restaurar'=>false);}
        return $s+array('ok'=>true,'escopo'=>'Somente tarefas e mutações do Site Core. Google e MCP exigem seus próprios procedimentos.');
    }
    private static function gravar(array $s): bool {
        $p=self::base().'.php';$tmp=$p.'.'.bin2hex(random_bytes(8)).'.php';$raw="<?php exit; ?>\n".wp_json_encode($s);
        if(file_put_contents($tmp,$raw,LOCK_EX)!==strlen($raw)){@unlink($tmp);return false;}@chmod($tmp,0600);$ok=rename($tmp,$p);if(!$ok){@unlink($tmp);}return $ok;
    }
    public static function provisionar(): bool {
        $dir=dirname(self::base());if(is_link($dir)||(!is_dir($dir)&&!wp_mkdir_p($dir))){return false;}
        if(is_file(self::base().'.php')){return !empty(self::ler()['ok']);}
        // Never recreate a missing sentinel after a completed 1.20 installation.
        if(!empty(get_option('f3base_release_1200',array())['concluido_em'])){return false;}
        $l=@fopen(self::base().'-state.php','c+');if(!$l||!flock($l,LOCK_EX)){return false;}
        try{return is_file(self::base().'.php')||self::gravar(array('geracao'=>1,'pausado'=>false,'pronto_para_restaurar'=>false,'atualizado_em'=>time()));}finally{flock($l,LOCK_UN);fclose($l);}
    }
    public static function entrar(): bool {
        if(self::$trabalho){++self::$profundidade;return true;}
        $s=self::ler();if(empty($s['ok'])||!empty($s['pausado'])){return false;}
        $f=@fopen(self::base().'-workers.php','c+');if(!$f||!flock($f,LOCK_SH|LOCK_NB)){if($f){fclose($f);}return false;}
        $s=self::ler();if(empty($s['ok'])||!empty($s['pausado'])){flock($f,LOCK_UN);fclose($f);return false;}
        self::$trabalho=$f;self::$profundidade=1;return true;
    }
    public static function sair(): void {if(self::$trabalho&&--self::$profundidade<=0){flock(self::$trabalho,LOCK_UN);fclose(self::$trabalho);self::$trabalho=null;self::$profundidade=0;}}
    public static function executar(callable $callback,...$args){if(!self::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao','recuperacao'=>self::ler());}try{return $callback(...$args);}finally{self::sair();}}
    public static function operar(array $e): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)){return array('ok'=>false,'codigo'=>'sem_permissao');}
        while(self::$trabalho){self::sair();}
        $f=@fopen(self::base().'-state.php','c+');if(!$f||!flock($f,LOCK_EX|LOCK_NB)){if($f){fclose($f);}self::entrar();return array('ok'=>false,'codigo'=>'barreira_ocupada');}
        try{
            $s=self::ler();if(empty($s['ok'])||(int)($e['geracao_esperada']??0)!==(int)$s['geracao']){return array('ok'=>false,'codigo'=>'geracao_divergente','recuperacao'=>$s);}
            $acao=$e['acao']??'';if(!in_array($acao,array('preparar','retomar'),true)){return array('ok'=>false,'codigo'=>'acao_invalida');}
            if($acao==='retomar'&&empty($e['reconciliacao_confirmada'])){return array('ok'=>false,'codigo'=>'reconciliacao_externa_nao_confirmada');}
            if($acao==='preparar'){$s['pausado']=true;$s['pronto_para_restaurar']=false;$s['atualizado_em']=time();if(!self::gravar($s)){return array('ok'=>false,'codigo'=>'barreira_nao_persistida');}}
            $w=@fopen(self::base().'-workers.php','c+');if(!$w||!flock($w,LOCK_EX|LOCK_NB)){if($w){fclose($w);}return array('ok'=>false,'codigo'=>'aguardando_drenagem','recuperacao'=>self::ler());}
            try{
                if($acao==='retomar'){
                    if(empty($s['pausado'])){return array('ok'=>true,'codigo'=>'ja_retomado','recuperacao'=>$s);}
                    $r=self::invalidar();if(empty($r['ok'])){return $r;}
                    ++$s['geracao'];$s['pausado']=false;$s['pronto_para_restaurar']=false;$s['reconciliacao_confirmada_em']=time();
                }else{$s['pronto_para_restaurar']=true;}
                $s['atualizado_em']=time();$ok=self::gravar($s);return array('ok'=>$ok,'codigo'=>$ok?($acao==='preparar'?'core_drenado':'core_retomado'):'sentinela_gravacao_falhou','recuperacao'=>self::ler());
            }finally{flock($w,LOCK_UN);fclose($w);}
        }finally{flock($f,LOCK_UN);fclose($f);if(empty(self::ler()['pausado'])){self::entrar();}}
    }
    private static function invalidar(): array {
        global $wpdb;
        // External queues are deliberately held for explicit reconciliation, never replayed from a restored snapshot.
        foreach(array('capi_fila','pipedrive_fila') as $suffix){$t=$wpdb->prefix.'f3base_'.$suffix;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){continue;}
            $cols=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if(in_array('estado',$cols,true)){$data=array('estado'=>'suspenso');if(in_array('motivo',$cols,true)){$data['motivo']='restauracao_requer_reconciliacao';}if(in_array('codigo',$cols,true)){$data['codigo']='restauracao_requer_reconciliacao';}if(in_array('reserva',$cols,true)){$data['reserva']='';}if(in_array('lease',$cols,true)){$data['lease']='';}if(in_array('lease_ate',$cols,true)){$data['lease_ate']=0;}$sets=array();foreach($data as $k=>$v){$sets[]=$wpdb->prepare('%i=%s',$k,$v);}if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET ".implode(',',$sets)." WHERE estado IN ('pendente','reservado','enviando','cancelando','processando')",$t))){return array('ok'=>false,'codigo'=>'fila_nao_suspensa');}}
        }
        $leads=F3Base_Leads_Repositorio::tabela();
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($leads)))===$leads){
            if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET aviso=IF(aviso IN ('pendente','enviando'),'incerto',aviso),resposta=IF(resposta IN ('pendente','enviando'),'incerta',resposta),resposta_erro=IF(resposta IN ('pendente','enviando','incerta'),'restauracao_requer_reconciliacao',resposta_erro)",$leads))){return array('ok'=>false,'codigo'=>'avisos_nao_suspensos');}
            if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET entrega=JSON_SET(entrega,'$.pipedrive.reconciliacao_necessaria',true) WHERE JSON_VALID(entrega) AND JSON_UNQUOTE(JSON_EXTRACT(entrega,'$.pipedrive.solicitado'))='true'",$leads))){return array('ok'=>false,'codigo'=>'intencoes_nao_suspensas');}
        }
        $crm=F3Base_Pipedrive_Fila::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($crm)))===$crm){if(false===$wpdb->query($wpdb->prepare("UPDATE %i SET codigo='restauracao_requer_reconciliacao',estado='suspenso' WHERE codigo='eliminacao_remota_pendente'",$crm))){return array('ok'=>false,'codigo'=>'eliminacoes_nao_suspensas');}}
        if(class_exists('F3Base_Gsc')){F3Base_Gsc::invalidar_curso('restauracao');}
        delete_option(F3Base_Operacao::OPTION);
        return array('ok'=>true);
    }
    public static function reservar_tarefa(string $id){
        if(!isset(F3Base_Operacao::tarefas()[$id])){return null;}$path=self::base().'-task-'.$id.'.php';if(is_link($path)){return null;}$f=@fopen($path,'c+');if(!$f||!flock($f,LOCK_EX|LOCK_NB)){if($f){fclose($f);}return null;}return $f;
    }
    public static function liberar_tarefa($f): void {if(is_resource($f)){flock($f,LOCK_UN);fclose($f);}}
    public static function proteger_agenda(): void {
        add_filter('pre_unschedule_event',static function($pre,$at,$hook){return F3Base_Operacao::identificar_hook($hook)&&!empty(self::ler()['pausado'])?false:$pre;},1,3);
        add_filter('pre_reschedule_event',static function($pre,$event){return F3Base_Operacao::identificar_hook($event->hook)&&!empty(self::ler()['pausado'])?true:$pre;},1,2);
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('operacao-recuperacao-ler','Consultar barreira de recuperação do Core',array(__CLASS__,'ler'));
        F3Base_Servicos::ability('operacao-recuperacao','Pausar/drenar ou retomar o Core após reconciliação',array(__CLASS__,'operar'),array('acao'=>array('type'=>'string','enum'=>array('preparar','retomar')),'geracao_esperada'=>array('type'=>'integer','minimum'=>1),'reconciliacao_confirmada'=>array('type'=>'boolean')),array('acao','geracao_esperada'),false);
    }
}
