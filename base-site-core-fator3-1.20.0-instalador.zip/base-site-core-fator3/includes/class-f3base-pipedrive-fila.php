<?php
/** Outbox de referência: mantém etapas e resultados incertos, nunca cópias de dados pessoais. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Fila {
    const EVENTO='f3base_pipedrive_processar';
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_pipedrive_fila';}
    public static function instalar(): bool {
        global $wpdb;$t=self::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t){return true;}require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$t} (\nchave char(64) NOT NULL,\nrecord_id char(32) NOT NULL,\nconta varchar(191) NOT NULL,\nestado varchar(20) NOT NULL DEFAULT 'pendente',\netapa varchar(24) NOT NULL DEFAULT '',\njournal longtext NOT NULL,\ntentativas smallint unsigned NOT NULL DEFAULT 0,\nproxima bigint unsigned NOT NULL,\nlease char(36) NOT NULL DEFAULT '',\nlease_ate bigint unsigned NOT NULL DEFAULT 0,\ncapturado_em bigint unsigned NOT NULL,\nprimeira_tentativa bigint unsigned NOT NULL DEFAULT 0,\nconcluido_em bigint unsigned NOT NULL DEFAULT 0,\natualizado_em bigint unsigned NOT NULL,\ncodigo varchar(100) NOT NULL DEFAULT '',\nPRIMARY KEY  (chave),\nKEY agenda (estado,proxima),\nKEY registro (record_id),\nKEY historico (concluido_em)\n) ENGINE=InnoDB {$cc};");
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
    }
    public static function iniciar(): void {
        add_action('f3base_lead_persistido',array(__CLASS__,'capturado'));add_action(self::EVENTO,array(__CLASS__,'processar'));
        add_action(F3Base_Leads_Notificacoes::EVENTO,array(__CLASS__,'compactar'));
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('pipedrive-fila-ler','Fila paginada e vínculos técnicos, sem dados pessoais',array(__CLASS__,'consultar'),array('pagina'=>array('type'=>'integer','minimum'=>1),'estado'=>array('type'=>'string','enum'=>array('pendente','enviando','incerto','revisao','suspenso','falhou','entregue','cancelado','cancelando'))));F3Base_Servicos::ability('pipedrive-reenviar','Reagenda uma entrega; resultados incertos continuam sujeitos à reconciliação',array(__CLASS__,'reenviar'),array('chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean')),array('chave','revisao','simular'),false);});
        add_action('init',static function(){if(!empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])&&!wp_next_scheduled(self::EVENTO)){F3Base_Fila::agendar(self::EVENTO,time()+60);}},90);
    }
    public static function intencao(array $d): array {
        $c=F3Base_Options::ler('f3base_pipedrive');$f=isset($d['formulario'])?F3Base_Formularios::obter($d['formulario']):null;
        $ok=!empty($c['ativo'])&&($d['captura']??'aceito')==='aceito'&&($f['pipedrive']??true)!==false&&!empty($d['nome'])&&(!empty($d['email'])||!empty($d['telefone']))&&((($d['classe_trafego']??'')!=='teste'&&empty($d['contexto_teste']))||!empty($c['homologacao']));
        return array('pipedrive'=>array('solicitado'=>$ok,'dominio'=>$ok?$c['dominio']:'','em'=>time(),'versao'=>F3BASE_PLUGIN_VERSAO));
    }
    public static function capturado(array $lead): void {self::enfileirar($lead);}
    public static function enfileirar(array $lead): bool {
        $intent=$lead['entrega']['pipedrive']??array();$cfg=F3Base_Options::ler('f3base_pipedrive');$s=get_option('f3base_pipedrive_estado',array());
        if(!empty($intent['reconciliacao_necessaria'])||empty($intent['solicitado'])||empty($cfg['ativo'])||!F3Base_Integracoes::pipedrive_verificado($s)||($intent['dominio']??'')!==($s['dominio']??'')||($s['dominio']??'')!==$cfg['dominio']){return false;}
        $account=$s['dominio'].'|'.$s['conta_id'].'|'.$s['instalacao'];$key=hash('sha256',$account.'|'.$lead['record_id']);global $wpdb;
        $ok=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO %i (chave,record_id,conta,journal,proxima,capturado_em,atualizado_em) VALUES (%s,%s,%s,'{}',%d,%d,%d)",self::tabela(),$key,$lead['record_id'],$account,time(),strtotime($lead['criado_em'].' UTC'),time()));
        if($ok!==false){F3Base_Fila::agendar(self::EVENTO);}return $ok!==false;
    }
    /** A intenção reside na mesma linha do contato; captura sobrevive a falha/crash ao enfileirar. */
    public static function reconciliar_intencoes(): void {
        global $wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT l.record_id FROM %i l LEFT JOIN %i q ON q.record_id=l.record_id WHERE q.record_id IS NULL AND l.lixeira=0 AND l.eliminacao_pendente=0 AND l.captura='aceito' AND JSON_UNQUOTE(JSON_EXTRACT(l.entrega,'$.pipedrive.solicitado'))='true' ORDER BY l.id LIMIT 100",F3Base_Leads_Repositorio::tabela(),self::tabela()));
        foreach($ids as $id){$r=F3Base_Leads_Repositorio::obter($id);if($r){self::enfileirar($r);}}
    }
    public static function cancelar(string $id,string $motivo='titular'): bool {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',self::tabela(),$id),ARRAY_A);if($wpdb->last_error){return false;}
        foreach($rows as $row){$j=json_decode($row['journal'],true)?:array();$explicit=$motivo!=='operacional';$j['eliminacao_remota']=array('estado'=>$explicit?'pendente':'retencao_local_independente','solicitada_em'=>time(),'motivo'=>$motivo);
            $patch=array('journal'=>wp_json_encode($j),'estado'=>$row['estado']==='enviando'?'cancelando':($row['estado']==='entregue'?'entregue':'cancelado'),'codigo'=>$explicit?'eliminacao_remota_pendente':'retencao_local_sem_exclusao_remota','atualizado_em'=>time());$changed=$wpdb->update(self::tabela(),$patch,array('chave'=>$row['chave'],'estado'=>$row['estado'],'lease'=>$row['lease'],'journal'=>$row['journal']));
            if($changed===false){return false;}if($changed===0){$fresh=$wpdb->get_row($wpdb->prepare('SELECT estado,codigo,journal FROM %i WHERE chave=%s',self::tabela(),$row['chave']),ARRAY_A);if(!$fresh||$fresh['codigo']!==$patch['codigo']||$fresh['journal']!==$patch['journal']){return false;}}
        }if($rows){F3Base_Fila::agendar(self::EVENTO);}return true;
    }
    public static function compactar(): void {
        global $wpdb;$days=max(7,min(90,(int)(F3Base_Options::ler('f3base_pipedrive')['retencao_entregas_dias']??30)));$cut=time()-$days*DAY_IN_SECONDS;$rows=$wpdb->get_results($wpdb->prepare("SELECT chave,record_id,estado,journal,atualizado_em FROM %i WHERE estado IN ('entregue','cancelado') AND atualizado_em<%d AND codigo NOT LIKE 'eliminacao%%' ORDER BY atualizado_em LIMIT 100",self::tabela(),$cut),ARRAY_A);
        foreach($rows as $r){$lead=F3Base_Leads_Repositorio::obter($r['record_id']);if(!$lead||$lead['eliminacao_pendente']){continue;}$j=json_decode($r['journal'],true)?:array();$ent=$lead['entrega'];$ent['pipedrive']['recibo']=array('chave'=>$r['chave'],'estado'=>$r['estado'],'referencias'=>$j,'compactado_em'=>time());if(false!==$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('entrega'=>wp_json_encode($ent)),array('record_id'=>$r['record_id'],'eliminacao_pendente'=>0))){$wpdb->update(self::tabela(),array('tentativas'=>0,'codigo'=>'historico_compactado','atualizado_em'=>time()),array('chave'=>$r['chave'],'atualizado_em'=>$r['atualizado_em']));}}
    }
    public static function consultar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;$where='1=1';if(!empty($e['estado'])){$where=$wpdb->prepare('estado=%s',$e['estado']);}$page=max(1,(int)($e['pagina']??1));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY atualizado_em DESC,chave LIMIT 51 OFFSET %d",self::tabela(),($page-1)*50),ARRAY_A);$more=count($rows)>50;$rows=array_slice($rows,0,50);foreach($rows as &$row){$row['revisao']=self::revisao($row);unset($row['lease']);$row['journal']=json_decode($row['journal'],true)?:array();}unset($row);return array('ok'=>true,'linhas'=>$rows,'pagina'=>$page,'proxima_pagina'=>$more?$page+1:null,'diagnostico'=>self::diagnostico());
    }
    public static function registro(string $id): array {
        if(!F3Base_Leads_Admin::pode()){return array();}global $wpdb;$r=$wpdb->get_row($wpdb->prepare('SELECT estado,codigo,etapa,conta,journal,primeira_tentativa,concluido_em,atualizado_em FROM %i WHERE record_id=%s ORDER BY atualizado_em DESC LIMIT 1',self::tabela(),$id),ARRAY_A);
        if(!$r){return array('estado'=>'sem_entrega');}$r['journal']=json_decode($r['journal'],true)?:array();$r['destino']=explode('|',$r['conta'])[0];unset($r['conta']);return $r;
    }
    private static function revisao(array $j): string {return hash('sha256',implode('|',array($j['chave'],$j['estado'],$j['etapa'],$j['tentativas'],$j['atualizado_em'],$j['lease'],is_array($j['journal'])?wp_json_encode($j['journal']):$j['journal'])));}
    public static function reenviar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$j=self::ler($e['chave']);if(!$j||!hash_equals(self::revisao($j),$e['revisao'])){return array('ok'=>false,'codigo'=>'revisao_divergente','persisted'=>false);}
        if(in_array($j['estado'],array('entregue','enviando','cancelando','cancelado'),true)){return array('ok'=>false,'codigo'=>'estado_nao_reenviavel','persisted'=>false);}$record=F3Base_Leads_Repositorio::obter($j['record_id']);if(!$record||$record['lixeira']||$record['eliminacao_pendente']||$record['captura']!=='aceito'){return array('ok'=>false,'codigo'=>'registro_nao_elegivel','persisted'=>false);}
        if(!empty($e['simular'])){return array('ok'=>true,'persisted'=>false,'alteraria'=>true,'proximo_estado'=>$j['etapa']?'incerto':'pendente','revisao'=>$e['revisao']);}
        $ok=self::salvar($j,array('estado'=>$j['etapa']?'incerto':'pendente','tentativas'=>0,'proxima'=>time(),'codigo'=>'reagendado_manualmente'));if($ok){F3Base_Fila::agendar(self::EVENTO);}return array('ok'=>$ok,'persisted'=>$ok);
    }
    private static function ler(string $key): ?array {global $wpdb;$j=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$key),ARRAY_A);if($j){$j['journal']=json_decode($j['journal'],true)?:array();}return $j;}
    private static function salvar(array &$job,array $patch): bool {
        global $wpdb;$patch['atualizado_em']=time();$db=$patch;if(isset($db['journal'])){$db['journal']=wp_json_encode($db['journal']);}
        $where=array('chave'=>$job['chave'],'lease'=>$job['lease'],'estado'=>$job['estado']);$n=$wpdb->update(self::tabela(),$db,$where);
        $fresh=$n===0?self::ler($job['chave']):null;if($n===false||($n===0&&(!$fresh||$fresh['estado']!==$job['estado']||$fresh['lease']!==$job['lease']))){return false;}$job=array_replace($job,$patch);return true;
    }
    private static function checkpoint(array &$j,string $step,$id): bool {$journal=$j['journal'];$journal[$step]=$id;unset($journal['reconcilia']);if(!self::salvar($j,array('journal'=>$journal,'etapa'=>''))){throw new RuntimeException('checkpoint_falhou');}return true;}
    private static function campos_canonicos(array $data,array $keys): array {
        $out=array();foreach($keys as $key){$value=$data[$key]??null;if(is_array($value)){$value=array_map(static fn($v)=>is_array($v)?(string)($v['id']??$v['value']??''):(string)$v,$value);sort($value,SORT_STRING);$value=implode(',',$value);}elseif(is_scalar($value)){$value=(string)$value;if(preg_match('/^[0-9]+(?:,[0-9]+)+$/D',$value)){$parts=explode(',',$value);sort($parts,SORT_STRING);$value=implode(',',$parts);}}$out[$key]=$value;}ksort($out);return $out;
    }
    private static function criar(array &$j,string $step,string $path,array $data): array {
        $freshjob=self::ler($j['chave']);if(!F3Base_Fila::possui($freshjob,'lease',$j['lease'],array('enviando'))){return array('ok'=>false,'codigo'=>'lease_ou_cancelamento','cancelar'=>true);}
        if(!empty($j['journal'][$step])){return array('ok'=>true,'data'=>array('id'=>$j['journal'][$step]));}
        if($j['etapa']===$step){return array('ok'=>false,'codigo'=>'reconciliacao_necessaria:'.$step,'incerto'=>true);}
        $journal=$j['journal'];
        // Persist the expected projection before POST, including when the remote reply is lost.
        if($step==='lead'){$keys=array_values(array_filter(array_keys($data),static fn($k)=>preg_match('/^[a-f0-9]{40}$/D',(string)$k)));$journal['campos_enviados']=array('chaves'=>$keys,'hash'=>F3Base_Leads_Repositorio::hash(self::campos_canonicos($data,$keys)),'config_revisao'=>F3Base_Options::revisao('f3base_pipedrive'));}
        if(!self::salvar($j,array('etapa'=>$step,'journal'=>$journal))){return array('ok'=>false,'codigo'=>'checkpoint_falhou','pausa'=>true);}
        $fresh=F3Base_Leads_Repositorio::obter($j['record_id']);if(!$fresh||$fresh['eliminacao_pendente']||$fresh['lixeira']||$fresh['captura']!=='aceito'){return array('ok'=>false,'codigo'=>'cancelamento_concorrente','cancelar'=>true);}
        $r=F3Base_Pipedrive_Api::pedir('POST',$path,$data);
        if(!empty($r['ok'])&&!empty($r['data']['id'])){$journal=$j['journal'];$journal['criados'][$step]=$r['data']['id'];$journal['provas_criacao'][$step]=F3Base_Pipedrive_Eliminacao::prova($step,$r['data']);if($step==='pessoa'){$journal['rever_pessoa_em']=time()+120;}if(!self::salvar($j,array('journal'=>$journal))||!self::checkpoint($j,$step,$r['data']['id'])){return array('ok'=>false,'codigo'=>'resposta_sem_checkpoint','incerto'=>true);}}
        elseif(empty($r['incerto'])){self::salvar($j,array('etapa'=>''));}
        return $r;
    }
    public static function contexto(array $r): array {
        $d=$r['dados'];$a=array('record_id'=>$r['record_id'],'capturado_em'=>$r['criado_em'],'metodo'=>$r['metodo'],'formulario_id'=>$r['formulario'],'formulario'=>$d['formulario_titulo']??$r['formulario'],'nome'=>$r['nome'],'email'=>$r['email'],'telefone'=>$d['telefone']??'','empresa'=>$d['empresa']??'','cargo'=>$d['cargo']??'','servicos'=>$d['servicos']??array(),'campos'=>$d['campos']??array(),'pagina'=>self::url_segura($r['pagina']),'journey'=>array(),'atribuicao'=>array(),'qualidade'=>array());
        $a['registro_url']=admin_url('admin.php?page=f3base-leads&record_id='.$r['record_id']);foreach($d['campos_snapshot']??array() as $field){if(($field['tipo']??'')==='file'){unset($a['campos'][$field['nome']]);}}
        $p=$d['consentimento_snapshot']??array();$ref=$p['decisao_ref']??$p['ref']??'';$versao=$p['politica_versao']??'';
        $med=!empty($p['medicao']);$ads=!empty($p['publicidade']);
        if(str_starts_with($versao,'legado:')){$allowed=F3Base_Consentimento_Decisoes::permite_capi('',(string)$versao);$med=$med&&$allowed;$ads=$ads&&$allowed;}
        elseif($ref){$med=$med&&F3Base_Consentimento_Decisoes::permite($ref,$versao,'medicao');$ads=$ads&&F3Base_Consentimento_Decisoes::permite($ref,$versao,'publicidade');}else{$med=false;$ads=false;}
        if(!empty($d['origem_nativa'])){$a['origem_nativa']=$d['origem_nativa'];$a['atribuicao']=self::limpar_atribuicao($d['atribuicao']??array(),true);$a['qualidade'][]='sem_jornada_web_em_formulario_nativo';return $a;}
        if(!$med){$a['qualidade'][]='medicao_nao_permitida_ou_revogada';return $a;}
        $a['atribuicao']=self::limpar_atribuicao($d['atribuicao']??array(),$ads);$session=$r['sessao']??'';
        if(!$session){$a['qualidade'][]='sem_sessao';return $a;}
        global $wpdb;$end=strtotime($r['criado_em'].' UTC');$start=max(0,$end-F3Base_Modulo_Comportamento::retencao_eventos_dias()*DAY_IN_SECONDS);
        $events=$wpdb->get_results($wpdb->prepare('SELECT tipo,caminho,detalhe,valor,criado_em FROM %i WHERE sessao=%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d ORDER BY criado_em DESC,evento DESC LIMIT 71',F3Base_Analise::tabela(),$session,$r['classe_trafego'],$start,$end),ARRAY_A);$pages=0;$count=0;foreach(array_reverse($events) as $e){if($e['tipo']==='pagina'){if(++$pages>20){continue;}}elseif(++$count>50){continue;}$a['journey'][]=$e;}
        $behavior=$wpdb->get_results($wpdb->prepare('SELECT metrica AS tipo,caminho,detalhe,valor,criado_em FROM %i WHERE sessao=%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d ORDER BY criado_em DESC,id DESC LIMIT 50',$wpdb->prefix.F3Base_Modulo_Comportamento::TABELA_EVENTOS,$session,$r['classe_trafego'],$start,$end),ARRAY_A);foreach($behavior as $event){$a['journey'][]=$event;}
        $clicks=$wpdb->get_results($wpdb->prepare("SELECT criado_em,metodo,pagina,dados FROM %i WHERE sessao=%s AND classe_trafego=%s AND captura='clique' AND lixeira=0 AND eliminacao_pendente=0 AND criado_em<=%s ORDER BY criado_em DESC LIMIT 20",F3Base_Leads_Repositorio::tabela(),$session,$r['classe_trafego'],$r['criado_em']),ARRAY_A);foreach($clicks as $x){$json=json_decode($x['dados'],true)?:array();$a['journey'][]=array('tipo'=>$x['metodo'],'caminho'=>self::url_segura($x['pagina']),'destino'=>self::url_segura($json['destino']??''),'criado_em'=>strtotime($x['criado_em'].' UTC'));}usort($a['journey'],static fn($x,$y)=>(int)$x['criado_em']<=>(int)$y['criado_em']);$pagecount=0;$evcount=0;$limited=array();foreach(array_reverse($a['journey']) as $event){$ispage=($event['tipo']??'')==='pagina';if($ispage?++$pagecount<=20:++$evcount<=50){$limited[]=$event;}}$a['journey']=array_reverse($limited);$a['journey_corte']=$pagecount>20||$evcount>50;$a['qualidade'][]='somente_eventos_observados_antes_da_captura';return $a;
    }
    private static function url_segura(string $url): string {$p=wp_parse_url($url);if(!is_array($p)){return '';}$scheme=strtolower($p['scheme']??'');if(!in_array($scheme,array('','http','https'),true)){return $scheme.':';}return ($p['host']??'').($p['path']??'');}
    private static function limpar_atribuicao(array $a,bool $ads): array {
        unset($a['fbc'],$a['fbp'],$a['oppref']);foreach(array('primeiro_toque','ultimo_toque','sessao_origem') as $k){if(is_array($a[$k]??null)){$a[$k]=self::limpar_atribuicao($a[$k],$ads);}}
        if(!$ads){foreach(array('gclid','gbraid','wbraid','fbclid','li_fat_id','msclkid','campanha_id','anuncio_id','conta_id','grupo_id','f3_ads_account_id','f3_ads_group_id','utm_id','utm_content') as $k){unset($a[$k]);}}return $a;
    }
    private static function campos(array $ctx,array $cfg): array {
        $a=$ctx['atribuicao'];$campaign=$a['utm_campaign']??'';$partner='';$quality='';
        if($campaign&&preg_match('/^([^_]+)_([^_]+)_(.+)_([0-9]{6})$/u',$campaign,$m)){$partner=strtolower(remove_accents($m[2]));}elseif($campaign){$quality='campanha_fora_do_padrao';}
        $native=$ctx['origem_nativa']??null;$point=$native?'nativo':($ctx['metodo']==='whatsapp_formulario'?'whatsapp_formulario':'site');
        $services=array();foreach((array)$ctx['servicos'] as $name){$mapped=$cfg['mapa_servicos'][($ctx['formulario_id']??'').':'.$name]??$cfg['mapa_servicos'][$name]??null;if($mapped!==null){$services[]=(string)$mapped;}}
        $vals=array('unidade'=>$cfg['unidade'],'canal'=>$cfg['mapa_canais'][$a['plataforma']??'nao_identificada']??null,'parceiro'=>$cfg['mapa_parceiros'][$partner]??null,'ponto'=>$cfg['mapa_pontos'][$point]??null,'servico'=>$services?implode(',',array_unique($services)):null,'campanha'=>$campaign?:($a['campanha_id']??''),'anuncio'=>$a['f3_ads_ad_name']??$a['anuncio_id']??'','cargo'=>$ctx['cargo']);$out=array();
        foreach($cfg['mapa_campos'] as $role=>$key){if(isset($vals[$role])&&$vals[$role]!==''){$out[$key]=$vals[$role];}}return $out;
    }
    private static function entregar(array &$j,array $lead): array {
        $cfg=F3Base_Pipedrive_Api::configuracao_lote();$ctx=self::contexto($lead);$campaign=$ctx['atribuicao']['utm_campaign']??'';$quality=array();if($campaign){if(preg_match('/^([^_]+)_([^_]+)_(.+)_([0-9]{6})$/u',$campaign,$parts)){if(!isset($cfg['mapa_parceiros'][strtolower(remove_accents($parts[2]))])){$quality[]='parceiro_nao_mapeado';}}else{$quality[]='campanha_fora_do_padrao';}}if($quality){$journal=$j['journal'];$journal['qualidade']=$quality;self::salvar($j,array('journal'=>$journal));}$mark='f3base:'.$j['chave'];$journal=$j['journal'];
        if(empty($journal['pessoa'])){
            $find=F3Base_Pipedrive_Api::buscar_pessoa($lead);if(empty($find['ok'])){return $find;}$person=$find['pessoa'];
            if($person){if(!self::checkpoint($j,'pessoa',(int)$person['id'])){return array('ok'=>false,'codigo'=>'checkpoint_falhou','pausa'=>true);}}
            else {
                if($j['etapa']==='pessoa'){return array('ok'=>false,'incerto'=>true,'codigo'=>'pessoa_sem_prova_apos_timeout');}
                $org=$ctx['empresa'];$org_id=$journal['organizacao']??null;
                if($org&&!$org_id){$found=F3Base_Pipedrive_Api::listar('v2/organizations/search',array('term'=>$org,'fields'=>'name','exact_match'=>'true'));if(empty($found['ok'])){return $found;}$matches=array();foreach($found['data'] as $v){$v=$v['item']??$v;if(mb_strtolower(trim($v['name']??''))===mb_strtolower(trim($org))){$matches[]=$v;}}if(count($matches)>1){return array('ok'=>false,'codigo'=>'organizacao_ambigua','permanente'=>true);}if($matches){$org_id=$matches[0]['id'];self::checkpoint($j,'organizacao',$org_id);}else{$created=self::criar($j,'organizacao','v2/organizations',array('name'=>$org,'owner_id'=>$cfg['responsavel']));if(empty($created['ok'])){return $created;}$org_id=$created['data']['id'];}}
                $data=array('name'=>$ctx['nome']?:$ctx['email']?:$ctx['telefone'],'owner_id'=>$cfg['responsavel']);if($ctx['email']){$data['emails']=array(array('value'=>$ctx['email'],'primary'=>true,'label'=>'work'));}if($ctx['telefone']){$data['phones']=array(array('value'=>$ctx['telefone'],'primary'=>true,'label'=>'work'));}if($org_id){$data['org_id']=(int)$org_id;}
                $created=self::criar($j,'pessoa','v2/persons',$data);if(empty($created['ok'])){return $created;}
                // Cross-site concurrency cannot be locked here. Surface duplicates without merging people.
                $after=F3Base_Pipedrive_Api::buscar_pessoa($lead);if(empty($after['ok'])){return $after;}
            }
        }
        $person=(int)$j['journal']['pessoa'];if(!empty($j['journal']['criados']['pessoa'])){$again=F3Base_Pipedrive_Api::buscar_pessoa($lead);if(empty($again['ok'])){return $again;}if((int)($again['pessoa']['id']??0)!==$person){return array('ok'=>false,'codigo'=>'pessoa_alterada_revisar','permanente'=>true);}}
        if(empty($j['journal']['oportunidade'])){
            $deals=F3Base_Pipedrive_Api::listar('v2/deals',array('person_id'=>$person,'status'=>'open'));if(empty($deals['ok'])){return $deals;}
            if(count($deals['data'])>1){return array('ok'=>false,'codigo'=>'negocios_abertos_ambiguos','permanente'=>true);}
            if($deals['data']){self::checkpoint($j,'oportunidade',array('tipo'=>'deal','id'=>$deals['data'][0]['id'],'nova'=>false));}
            else {
                $leads=F3Base_Pipedrive_Api::listar('v1/leads',array('person_id'=>$person,'is_archived'=>'false'));if(empty($leads['ok'])){return $leads;}$own=array_values(array_filter($leads['data'],static fn($x)=>($x['origin_id']??'')===$mark));
                if(count($own)===1){self::checkpoint($j,'lead',$own[0]['id']);self::checkpoint($j,'oportunidade',array('tipo'=>'lead','id'=>$own[0]['id'],'nova'=>true));}
                elseif(count($leads['data'])>1){return array('ok'=>false,'codigo'=>'leads_abertos_ambiguos','permanente'=>true);}
                elseif($leads['data']&&$j['etapa']!=='lead'){self::checkpoint($j,'oportunidade',array('tipo'=>'lead','id'=>$leads['data'][0]['id'],'nova'=>false));}
                else {
                    if($j['etapa']==='lead'){return array('ok'=>false,'incerto'=>true,'codigo'=>'lead_sem_prova_apos_timeout');}
                    $title=($ctx['empresa']?:$ctx['nome']?:'Contato').' — '.(implode(', ',(array)$ctx['servicos'])?:'Interesse a qualificar');if($lead['classe_trafego']==='teste'){$title='[TESTE F3BASE] '.$title;}
                    $data=array('title'=>mb_substr($title,0,255),'person_id'=>$person,'owner_id'=>$cfg['responsavel'],'origin_id'=>$mark)+self::campos($ctx,$cfg);if($cfg['rotulo']){$data['label_ids']=array($cfg['rotulo']);}
                    $r=self::criar($j,'lead','v1/leads',$data);if(empty($r['ok'])){return $r;}self::checkpoint($j,'oportunidade',array('tipo'=>'lead','id'=>$r['data']['id'],'nova'=>true));
                }
            }
        }
        if(empty($j['journal']['oportunidade'])){return array('ok'=>false,'codigo'=>'checkpoint_oportunidade_pendente','pausa'=>true);}
        $opp=$j['journal']['oportunidade'];if($opp['nova']&&empty($j['journal']['campos_verificados'])&&!empty($j['journal']['campos_enviados']['chaves'])){$proof=$j['journal']['campos_enviados'];$read=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$opp['id']);if(empty($read['ok'])){return $read;}if(!hash_equals($proof['hash'],F3Base_Leads_Repositorio::hash(self::campos_canonicos($read['data'],$proof['chaves'])))){return array('ok'=>false,'codigo'=>'campos_nao_confirmados_no_crm','permanente'=>true);}self::checkpoint($j,'campos_verificados',time());}$rel=array($opp['tipo']==='lead'?'lead_id':'deal_id'=>$opp['id']);
        if(empty($j['journal']['nota'])){
            $notes=F3Base_Pipedrive_Api::listar('v1/notes',$rel);if(empty($notes['ok'])){return $notes;}$matches=array_values(array_filter($notes['data'],static fn($n)=>str_contains(wp_strip_all_tags($n['content']??''),$mark.':nota')));
            if(count($matches)>1){return array('ok'=>false,'codigo'=>'notas_ambiguas','permanente'=>true);}if($matches){self::checkpoint($j,'nota',$matches[0]['id']);}
            else{$ctx=self::contexto(F3Base_Leads_Repositorio::obter($lead['record_id'])??$lead);$ctx['qualidade']=array_values(array_unique(array_merge($ctx['qualidade'],$j['journal']['qualidade']??array())));$text='Interação no site — '.$mark.':nota'."\n".wp_json_encode($ctx,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$r=self::criar($j,'nota','v1/notes',array('content'=>'<pre>'.esc_html(mb_substr($text,0,30000)).'</pre>','person_id'=>$person)+$rel);if(empty($r['ok'])){return $r;}}
        }
        if($cfg['atividade']&&$opp['nova']&&empty($j['journal']['atividade'])){
            $items=F3Base_Pipedrive_Api::listar('v2/activities',array('person_id'=>$person,'done'=>'false'));if(empty($items['ok'])){return $items;}$existing=null;foreach($items['data'] as $item){if(str_contains($item['note']??'',$mark.':atividade')||(($item['lead_id']??'')===($rel['lead_id']??null)&&($item['type']??'')===$cfg['atividade_tipo'])){$existing=$item;break;}}
            if($existing){self::checkpoint($j,'atividade',$existing['id']);}else{$r=self::criar($j,'atividade','v2/activities',array('subject'=>'Primeiro contato — '.($ctx['empresa']?:$ctx['nome']),'type'=>$cfg['atividade_tipo'],'owner_id'=>$cfg['responsavel'],'person_id'=>$person,'note'=>$mark.':atividade','due_date'=>gmdate('Y-m-d'))+$rel);if(empty($r['ok'])){return $r;}}
        }
        return array('ok'=>true);
    }
    public static function rever_pessoas(): void {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='entregue' AND CAST(JSON_UNQUOTE(JSON_EXTRACT(journal,'$.rever_pessoa_em')) AS UNSIGNED) BETWEEN 1 AND %d ORDER BY atualizado_em LIMIT 3",self::tabela(),time()),ARRAY_A);
        foreach($rows as $r){$lead=F3Base_Leads_Repositorio::obter($r['record_id']);if(!$lead||$lead['eliminacao_pendente']){continue;}$r['journal']=json_decode($r['journal'],true)?:array();$v=F3Base_Pipedrive_Api::buscar_pessoa($lead);if(!empty($v['pausa'])||!empty($v['temporario'])){continue;}$j=$r['journal'];unset($j['rever_pessoa_em']);$j['revisao_entre_sites']=array('em'=>time(),'codigo'=>!empty($v['ok'])?'sem_ambiguidade_observada':($v['codigo']??'revisar'),'limite'=>'Fotografia da conta; instalações independentes não compartilham trava.');self::salvar($r,array('journal'=>$j,'codigo'=>!empty($v['ok'])?'entregue':'pessoa_ambigua_revisar'));
        }
    }
    public static function processar(): array {
        if(!self::instalar()){return array('ok'=>false,'codigo'=>'schema_indisponivel');}F3Base_Pipedrive_Api::iniciar_lote();$cfg=F3Base_Pipedrive_Api::configuracao_lote();$state=(array)F3Base_Options::fotografia_bruta('f3base_pipedrive_estado')['valor'];if(empty($cfg['ativo'])||!F3Base_Pipedrive_Api::lote_atual()||!F3Base_Integracoes::pipedrive_verificado($state)){return array('ok'=>true,'codigo'=>'integracao_desligada_ou_nao_verificada');}
        self::reconciliar_intencoes();global $wpdb;$t=self::tabela();$now=time();
        $wpdb->query($wpdb->prepare("UPDATE %i SET estado=IF(etapa='','pendente','incerto'),lease='',codigo='lease_expirado' WHERE estado IN ('enviando','reservado') AND lease_ate<%d",$t,$now));
        $wpdb->query($wpdb->prepare("UPDATE %i SET estado='cancelado',lease='',codigo=IF(codigo='retencao_local_sem_exclusao_remota',codigo,'eliminacao_remota_pendente') WHERE estado='cancelando' AND lease_ate<%d",$t,$now));
        $keys=$wpdb->get_col($wpdb->prepare("SELECT chave FROM %i WHERE estado IN ('pendente','incerto') AND proxima<=%d ORDER BY proxima,chave LIMIT 10",$t,$now));$start=microtime(true);$n=0;
        foreach($keys as $key){if(F3Base_Fila::restante($start,20)<2){break;}$lease=F3Base_Fila::lease();$ok=F3Base_Fila::reservar_condicional("UPDATE %i SET estado='enviando',lease=%s,lease_ate=%d,primeira_tentativa=IF(primeira_tentativa=0,%d,primeira_tentativa),atualizado_em=%d WHERE chave=%s AND estado IN ('pendente','incerto') AND proxima<=%d",array($t,$lease,time()+120,time(),time(),$key,time()));if(!$ok){continue;}$j=self::ler($key);if(!$j||$j['lease']!==$lease){continue;}
            $lead=F3Base_Leads_Repositorio::obter($j['record_id']);$account=$state['dominio'].'|'.$state['conta_id'].'|'.$state['instalacao'];
            if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||$lead['captura']!=='aceito'){$r=array('ok'=>false,'codigo'=>'registro_nao_elegivel','cancelar'=>true);}
            elseif($j['conta']!==$account){$r=array('ok'=>false,'codigo'=>'conta_alterada','permanente'=>true);}
            elseif($lead['classe_trafego']==='teste'&&empty($cfg['homologacao'])){$r=array('ok'=>false,'codigo'=>'teste_suprimido','pausa'=>true);}
            else{try{$r=self::entregar($j,$lead);}catch(Throwable $e){$r=array('ok'=>false,'codigo'=>'checkpoint_ou_cancelamento_pendente','incerto'=>true);}}
            ++$n;$attempt=(int)$j['tentativas']+(empty($r['pausa'])?1:0);$delays=array(60,300,900,3600,10800,43200);$wait=max((int)($r['retry_after']??0),$delays[min(5,max(0,$attempt-1))]+random_int(0,15));
            $status=!empty($r['ok'])?'entregue':(!empty($r['cancelar'])?'cancelado':(!empty($r['incerto'])?($attempt>=7?'revisao':'incerto'):(!empty($r['permanente'])?'suspenso':($attempt>=7?'falhou':'pendente'))));
            self::salvar($j,array('estado'=>$status,'lease'=>'','lease_ate'=>0,'tentativas'=>$attempt,'proxima'=>time()+($status==='incerto'?max(300,$wait):$wait),'concluido_em'=>$status==='entregue'?time():0,'codigo'=>$r['codigo']??'entregue'));
        }
        if(F3Base_Fila::restante($start,20)>5){self::rever_pessoas();}$next=$wpdb->get_var($wpdb->prepare("SELECT MIN(proxima) FROM %i WHERE estado IN ('pendente','incerto')",$t));F3Base_Fila::agendar(self::EVENTO,max(time()+5,$next?(int)$next:time()+300));return array('ok'=>true,'processados'=>$n,'diagnostico'=>self::diagnostico());
    }
    public static function diagnostico(): array {
        global $wpdb;$t=self::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){return array('estado'=>'nao_instalada');}
        $counts=$wpdb->get_results($wpdb->prepare('SELECT estado,COUNT(*) quantidade,MIN(capturado_em) mais_antigo FROM %i GROUP BY estado',$t),ARRAY_A);$rows=$wpdb->get_results($wpdb->prepare('SELECT capturado_em,primeira_tentativa,concluido_em FROM %i q INNER JOIN %i l ON l.record_id=q.record_id WHERE l.classe_trafego<>%s AND q.capturado_em>=%d ORDER BY q.capturado_em DESC LIMIT 10001',$t,F3Base_Leads_Repositorio::tabela(),'teste',time()-7*DAY_IN_SECONDS),ARRAY_A);$first=array();$done=array();foreach(array_slice($rows,0,10000) as $r){if($r['primeira_tentativa']){$first[]=max(0,(int)$r['primeira_tentativa']-(int)$r['capturado_em']);}if($r['concluido_em']){$done[]=max(0,(int)$r['concluido_em']-(int)$r['capturado_em']);}}
        return array('estados'=>$counts,'latencia_7_dias'=>array('unidade'=>'segundos','metodo'=>'nearest-rank','amostra_limitada'=>count($rows)>10000,'testes_excluidos'=>true,'captura_primeira_tentativa'=>array('n'=>count($first),'p50'=>F3Base_Fila::percentil($first,.5),'p95'=>F3Base_Fila::percentil($first,.95)),'captura_entrega'=>array('n'=>count($done),'p50'=>F3Base_Fila::percentil($done,.5),'p95'=>F3Base_Fila::percentil($done,.95))),'proxima_execucao'=>wp_next_scheduled(self::EVENTO)?:null,'garantia'=>'Deduplicação por etapa e reconciliação local; não garante exatamente uma criação entre sites independentes.');
    }
}
