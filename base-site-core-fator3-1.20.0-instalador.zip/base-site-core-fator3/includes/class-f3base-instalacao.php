<?php
/** Instalação nova ou atualização exclusiva da 1.19.0, com checkpoints e recuo. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Instalacao {
    const OPTION='f3base_release_1200';
    public static function origem(): string {
        global $wpdb;$s=get_option(self::OPTION,array());
        if(($s['versao']??'')==='1.20.0'){return !empty($s['concluido_em'])?'atual':($s['origem']??'indefinida');}
        $base=get_option('f3base_release_1190',array());if(($base['versao']??'')==='1.19.0'){return '1.19.0';}
        $n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name<>%s",$wpdb->esc_like('f3base_').'%','f3base_1200_trava'));
        $tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_').'%'));
        return !$wpdb->last_error&&(int)$n===0&&!$tables?'nova':'indefinida';
    }
    public static function permitida(): bool {return in_array(self::origem(),array('atual','nova','1.19.0'),true);}
    public static function aviso(): void {if(current_user_can('manage_options')){echo '<div class="notice notice-error"><p>Fator3 Site Core: origem não suportada. Instale em WordPress novo ou atualize a partir da 1.19.0. Nenhum dado foi convertido.</p></div>';}}
    public static function resumo(): array {$s=get_option(self::OPTION,array());return $s+array('versao'=>'1.20.0','concluido_em'=>0,'proxima_tentativa'=>0,'origem'=>self::origem());}
    private static function salvar(array $s): bool {$r=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$s);return !empty($r['persisted']);}
    public static function documentos_obsoletos(): array {return array('removidos'=>array(),'divergentes'=>array(),'falhas'=>array());}
    public static function atualizar(): array {
        $origem=self::origem();if($origem==='atual'){return array('ok'=>true,'codigo'=>'atual');}if(!self::permitida()){return array('ok'=>false,'codigo'=>'origem_nao_suportada');}
        $s=get_option(self::OPTION,array());if((int)($s['proxima_tentativa']??0)>time()){return array('ok'=>false,'codigo'=>'atualizacao_em_recuo','proxima_tentativa'=>$s['proxima_tentativa']);}
        if(!F3Base_Recuperacao::provisionar()||!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}
        $lock=F3Base_Trava::adquirir('atualizacao-1200',180);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>false,'codigo'=>'atualizacao_em_execucao');}
        $etapa='inicio';try{
            if(empty($s['versao'])){$s=array('versao'=>'1.20.0','origem'=>$origem,'iniciado_em'=>time(),'etapas'=>array(),'falhas'=>0);if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
            $steps=array(
                'padroes'=>static function()use($origem){
                    if($origem==='nova'){
                        foreach(array(F3Base_Options::OPTION_OPERAVEIS=>array('schema'=>1,'modo'=>'todas','lista'=>array()),'f3base_politica_canal'=>true,'f3base_contato'=>array('email_leads'=>is_email(get_option('admin_email'))?array(get_option('admin_email')):array())) as $n=>$v){if(!F3Base_Options::fotografia_bruta($n)['existe']){$r=F3Base_Options::gravar($n,$v,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao($n));if(empty($r['persisted'])){return false;}}}
                    }
                    return !empty(F3Base_Release_1190::materializar_padroes()['ok']);
                },
                'consentimento_capi'=>static function(){F3Base_Consentimento_Decisoes::instalar();F3Base_Modulo_Endpoint_Leads::instalar_recusas();return F3Base_Capi_Fila::instalar()&&F3Base_Atualizacao::verificar_estrutura();},
                'leads_analise'=>static function(){F3Base_Modulo_Comportamento::criar_tabela();F3Base_Vitais::instalar();return F3Base_Leads_Repositorio::instalar()&&F3Base_Analise::instalar()&&F3Base_Clarity_Acervo::instalar()&&F3Base_Meta_Transporte::instalar();},
                'integracoes'=>static fn()=>F3Base_Pipedrive_Fila::instalar()&&F3Base_Anuncios::instalar(),
                'editorial'=>static function(){F3Base_Acessos_Coleta::instalar();F3Base_Agentes::instalar();return F3Base_Acessos_Legado::instalar()&&F3Base_Editorial::instalar()&&F3Base_Inteligencia::instalar();},
                'acervos_1200'=>static fn()=>F3Base_Execucoes::instalar()&&F3Base_Gsc::instalar(),
                'pasta_privada'=>static fn()=>!empty(F3Base_Arquivos_Privados::provisionar()['ok']),
                'verificacao'=>static fn()=>self::verificar(),
            );
            foreach($steps as $etapa=>$callback){if(!empty($s['etapas'][$etapa]['concluido_em'])){continue;}$s['etapa_atual']=$etapa;$s['tentativa_em']=time();if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}
                if(!$callback()){throw new RuntimeException('etapa_nao_confirmada');}$s['etapas'][$etapa]=array('concluido_em'=>time());if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
            F3Base_Options::atualizar_estado(F3Base_Atualizacao::OPTION,static fn($v)=>array_merge($v,array('versao'=>F3Base_Atualizacao::VERSAO,'confirmada_em'=>time(),'codigo'=>'estrutura_confirmada')));
            $s['concluido_em']=time();$s['proxima_tentativa']=0;$s['ultima_falha']=null;$s['etapa_atual']='concluida';if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}
            F3Base_Navegacao::agendar();F3Base_Editorial::agendar();F3Base_Llms_Cobertura::agendar();wp_clear_scheduled_hook(F3Base_Atualizacao::EVENTO);
            return array('ok'=>true,'persisted'=>true,'codigo'=>'atualizacao_concluida');
        }catch(Throwable $e){$s['falhas']=(int)($s['falhas']??0)+1;$s['ultima_falha']=array('etapa'=>$etapa,'codigo'=>sanitize_key($e->getMessage()),'em'=>time());$s['proxima_tentativa']=time()+min(3600,300*2**min(4,$s['falhas']-1));self::salvar($s);return array('ok'=>false,'codigo'=>'atualizacao_pendente','etapa'=>$etapa,'proxima_tentativa'=>$s['proxima_tentativa']);}
        finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function verificar(): bool {
        global $wpdb;if(!F3Base_Atualizacao::verificar_estrutura()){return false;}
        $required=array('f3base_analise'=>array('oferta_id','oferta_tipo','oferta_instancia'),'f3base_execucoes'=>array('run_id','origem','parent_run_id','ocorrencia'),'f3base_gsc_coletas'=>array('id','propriedade','dia','estado','cursor','revision'),'f3base_gsc_linhas'=>array('coleta_id','chave','url'),'f3base_clarity_coletas'=>array('id','estado','recebido_em'),'f3base_clarity'=>array('coleta','metrica'),'f3base_meta_eventos'=>array('evento','rota','classe_trafego'));
        foreach($required as $suffix=>$cols){$t=$wpdb->prefix.$suffix;$actual=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if($wpdb->last_error||array_diff($cols,$actual)){return false;}}return true;
    }
}
