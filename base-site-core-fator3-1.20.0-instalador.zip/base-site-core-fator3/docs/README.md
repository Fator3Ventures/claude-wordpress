# Fator3 Site Core 1.20.0

Instale **base-site-core-fator3-1.20.0-instalador.zip** em WordPress novo ou atualize a partir da **1.19.0**, inclusive quando sua migração ficou incompleta. Sem migração de versões anteriores nem downgrade. O pacote de fontes não é instalável.

A release acrescenta coleta orgânica nativa via MCP Google 0.7.0, acervo de fotografias Search Console, executor comum das tarefas Core, diário com origens independentes e barreira de recuperação. Corrige registros CAPI vazios que bloqueavam a atualização. Preferências explícitas e dados existentes são preservados.

O menu passa a **Site Core**, mantendo slug, rotas e prefixos. O contrato público Core passa a **5.0.0**; a política MCP permanece 1. Nenhuma credencial Google é copiada para o Core. Novos serviços continuam dependentes de configuração e autorização.

Leia [DOCUMENTACAO.md](DOCUMENTACAO.md) e [OPERACAO-GSC-1.20.md](OPERACAO-GSC-1.20.md). Toda a documentação acompanha o instalador em `docs/`, acessível a agentes por arquivo ou `f3base/documentacao-ler` autenticado. [VALIDACAO.md](VALIDACAO.md) distingue provas locais de homologação por conta/site.
