# Dicionário de dados — 1.20.0 / contrato 5.0.0

Gerado de `dados/contrato.json`, com tipos e índices conferidos no MySQL da bancada. Substituir o prefixo de tabela somente pelo prefixo validado do site. IDs externos/opacos são strings. Sessão, IP ou UA não identificam uma pessoa comprovada.

Datas de filtros usam o fuso WordPress; início inclusivo e fim exclusivo no começo do dia seguinte. DATETIME de leads é UTC; epochs são segundos UTC salvo indicação explícita. Dia agregado segue o calendário da regra. Ausência, desconhecido e zero são estados diferentes.

A audiência usa análise como fonte canônica. Histórico agregado sem pseudônimos não permite reconstruir distintos do período. GSC e execução usam OPERACAO-GSC-1.20.md. Para fórmulas, cobertura e filtros de conteúdo/sessão, leia MEDICAO-1.19.md e METRICAS.md. Clarity guarda consultas móveis completas sanitizadas: não soma consultas para fabricar totais de dias ou pessoas.

Contatos e agregados seguem suas políticas próprias; consultar valores efetivos no site. Clarity tem retenção independente, zero sem expiração automática por padrão. Payload CAPI cifrado permanece só até o desfecho ou prazo útil; metadados seguem retenção da fila. Recibos podem sobreviver ao contato eliminado. Não exportar payload, segredos ou caminho físico.

## Relações e chaves

- {"de": "f3base_leads.sessao + classe_trafego", "para": "f3base_eventos.sessao + classe_trafego", "cardinalidade": "muitos_para_muitos", "regra": "Uma sessão pode ter vários leads e eventos. Pré-agregar ou usar EXISTS; nunca somar linhas de JOIN como leads."}
- f3base_pipedrive_fila.record_id e f3base_anuncios_recibos.record_id → f3base_leads.record_id; eliminação mantém vínculo técnico mínimo.
- analise/eventos: classe_trafego + sessao + navegacao; páginas deduplicadas pela fonte analise, não somar registros de ambas as tabelas.
- leads.dados.navegacao + sessao + classe_trafego → analise; sem pareamento o contato permanece apenas comercial.
- conteudos.post_id → post ID WordPress; conteudo_rotas usa vigência inicio<=instante<fim (fim=0 ativo).
- editorial_diario não contém pseudônimo/sessão; não permite contar distintos do período.
- gsc_diario é universo externo e calendário America/Los_Angeles; não unir como evento de visitante.
- clarity.coleta → clarity_coletas.id; parser identifica derivação; métricas móveis não são aditivas.
- meta_eventos.evento → capi_fila.evento_hash; nome/rota/classe conservam coorte; payload da fila não integra exportações.
- arquivos_leads.blob_id → arquivos_blobs.blob_id; ID estável do ativo conserva concessões vigentes.
- analise.oferta_instancia + navegacao + sessao + classe_trafego + formulario → leads.dados.oferta.instancia com mesmo contexto.
- f3base_pipedrive_fila.record_id e f3base_anuncios_recibos.record_id → f3base_leads.record_id; eliminação mantém vínculo técnico mínimo.
- gsc_linhas.coleta_id → gsc_coletas.id; gsc_diario é projeção, não somar as duas fontes.
- execucoes.parent_run_id → execucoes.run_id; contar somente parent_run_id vazio para passagens.

## f3base_acessos

Uma combinação de dia, classificação de agente/caminho, caminho, HTTP e método.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `dia` | `date` | não | NULL | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `agente` | `varchar(64)` | não | NULL | Código da evidência de UA/origem: não comprova presença humana. | base 1.12.0 ou anterior |
| `classe_caminho` | `varchar(16)` | não | NULL | Categoria de privacidade/rota aplicada pelo parser; query não é preservada. | base 1.12.0 ou anterior |
| `dimensao` | `char(64)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo_conteudo` | `varchar(32)` | não |  | Tipo WordPress normalizado: pagina, artigo ou recurso/CPT explícito. | 1.17.0 |
| `representacao` | `varchar(20)` | não | nao_resolvida | html, markdown_core, descoberta ou nao_resolvida; não afirma leitura. | 1.17.0 |
| `resolucao` | `varchar(32)` | não | historico_sem_identidade | Versão/procedência da identificação editorial no acesso. | 1.17.0 |
| `rede_estado` | `varchar(24)` | não | nao_verificada | Compatibilidade com faixa oficial; não é autenticação do robô. | 1.17.0 |
| `rede_lista` | `char(64)` | não |  | Identidade/hash da lista pública usada; nunca IP ou hash de IP individual. | 1.17.0 |
| `rede_data` | `bigint unsigned` | não | 0 | Data técnica de obtenção da lista oficial. | 1.17.0 |
| `rede_versao` | `varchar(64)` | não |  | Versão do classificador de rede. | 1.17.0 |
| `assinatura_ua` | `varchar(80)` | não | historico_desconhecido | Produtos técnicos sem versão de vocabulário controlado; não identifica operador desconhecido. | 1.19.0 |
| `assinatura_regra` | `varchar(24)` | não |  | Versão da extração da assinatura reduzida. | 1.19.0 |
| `caminho` | `varchar(191)` | não | NULL | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `status` | `smallint unsigned` | não | NULL | Código HTTP observado no log. | base 1.12.0 ou anterior |
| `metodo` | `varchar(5)` | não | NULL | Método HTTP normalizado do log, não método de contato. | base 1.12.0 ou anterior |
| `contagem` | `bigint unsigned` | não | NULL | Quantidade agregada na granularidade da linha. | base 1.12.0 ou anterior |
| `primeiro_em` | `datetime` | sim | NULL | Primeiro instante UTC válido observado nesta combinação diária. | 1.16.0 |
| `ultimo_em` | `datetime` | sim | NULL | Último instante UTC válido observado nesta combinação diária. | 1.16.0 |
| `instantes_validos` | `bigint unsigned` | não | 0 | Quantidade de requisições com timestamp interpretado; histórico sem instantes não é zero observado. | 1.16.0 |

Índices:

- `agregado` (único): `dia`, `agente`, `classe_caminho`, `caminho`, `status`, `metodo`, `dimensao`.
- `dia_classe` (não único): `dia`, `classe_caminho`.

## f3base_acessos_contribuicoes

Contribuição por arquivo/fonte e chave agregada, com versão de regra.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `fonte` | `char(64)` | não | NULL | Identidade hash do arquivo de contribuição; reimportação substitui. | base 1.12.0 ou anterior |
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | base 1.12.0 ou anterior |
| `regra` | `char(64)` | não | NULL | Hash da regra de classificação/calendário. | base 1.12.0 ou anterior |
| `dia` | `date` | não | NULL | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `agente` | `varchar(64)` | não | NULL | Código da evidência de UA/origem: não comprova presença humana. | base 1.12.0 ou anterior |
| `classe_caminho` | `varchar(16)` | não | NULL | Categoria de privacidade/rota aplicada pelo parser; query não é preservada. | base 1.12.0 ou anterior |
| `dimensao` | `char(64)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo_conteudo` | `varchar(32)` | não |  | Tipo WordPress normalizado: pagina, artigo ou recurso/CPT explícito. | 1.17.0 |
| `representacao` | `varchar(20)` | não | nao_resolvida | html, markdown_core, descoberta ou nao_resolvida; não afirma leitura. | 1.17.0 |
| `resolucao` | `varchar(32)` | não | historico_sem_identidade | Versão/procedência da identificação editorial no acesso. | 1.17.0 |
| `rede_estado` | `varchar(24)` | não | nao_verificada | Compatibilidade com faixa oficial; não é autenticação do robô. | 1.17.0 |
| `rede_lista` | `char(64)` | não |  | Identidade/hash da lista pública usada; nunca IP ou hash de IP individual. | 1.17.0 |
| `rede_data` | `bigint unsigned` | não | 0 | Data técnica de obtenção da lista oficial. | 1.17.0 |
| `rede_versao` | `varchar(64)` | não |  | Versão do classificador de rede. | 1.17.0 |
| `assinatura_ua` | `varchar(80)` | não | historico_desconhecido | Produtos técnicos sem versão de vocabulário controlado; não identifica operador desconhecido. | 1.19.0 |
| `assinatura_regra` | `varchar(24)` | não |  | Versão da extração da assinatura reduzida. | 1.19.0 |
| `caminho` | `varchar(191)` | não | NULL | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `status` | `smallint unsigned` | não | NULL | Código HTTP observado no log. | base 1.12.0 ou anterior |
| `metodo` | `varchar(5)` | não | NULL | Método HTTP normalizado do log. | base 1.12.0 ou anterior |
| `contagem` | `bigint unsigned` | não | NULL | Quantidade agregada na granularidade da linha. | base 1.12.0 ou anterior |
| `primeiro_em` | `datetime` | sim | NULL | Primeiro instante UTC válido observado nesta combinação diária. | 1.16.0 |
| `ultimo_em` | `datetime` | sim | NULL | Último instante UTC válido observado nesta combinação diária. | 1.16.0 |
| `instantes_validos` | `bigint unsigned` | não | 0 | Quantidade de requisições com timestamp interpretado; histórico sem instantes não é zero observado. | 1.16.0 |

Índices:

- `PRIMARY` (único): `fonte`, `chave`.
- `dia_regra` (não único): `dia`, `regra`.

## f3base_analise

Um evento por evento; vital conserva a última sequência dessa identidade.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Chave física local. Não identifica pessoa ou anúncio. | 1.13.0 |
| `evento` | `char(32)` | não | NULL | Identificador de evento de análise. Atualizações de vitais mantêm o mesmo ID. | 1.13.0 |
| `visitante` | `char(32)` | não | NULL | Identificador local pseudônimo do navegador, sujeito a consentimento e expiração. | 1.13.0 |
| `sessao` | `char(32)` | não | NULL | Identificador analítico opcional, originado no navegador; não equivale a pessoa. | 1.13.0 |
| `classe_trafego` | `varchar(16)` | não | nao_marcado | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. | 1.14.0 |
| `navegacao` | `char(32)` | não | NULL | ID aleatório de um carregamento; comum entre eventos, análise e dados do lead, sem criar pessoa. | 1.13.0 |
| `navegacao_anterior` | `char(32)` | não |  | Navegação anterior comprovada no mesmo fluxo de aba e sessão; vazio quando não comprovada. | 1.17.0 |
| `automacao` | `varchar(20)` | não | nao_identificada | declarada, provavel ou nao_identificada; separado da marca de teste. Ausência de sinal não prova humano. | 1.17.0 |
| `automacao_motivos` | `varchar(190)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `automacao_regra` | `varchar(40)` | não |  | Versão da regra e lista de assinaturas aplicada na captura; vazio para histórico sem regra. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo_conteudo` | `varchar(32)` | não |  | Tipo WordPress normalizado: pagina, artigo ou recurso/CPT explícito. | 1.17.0 |
| `representacao` | `varchar(20)` | não | html | html, markdown_core, descoberta ou nao_resolvida; não afirma leitura. | 1.17.0 |
| `aquisicao_regra` | `varchar(40)` | não |  | Versão da classificação da fotografia de entrada da sessão. | 1.17.0 |
| `aquisicao_evidencia` | `varchar(64)` | não |  | Sinais que fundamentam canal/origem IA: UTM, referência ou click ID permitido. | 1.17.0 |
| `aquisicao_conflitos` | `varchar(190)` | não |  | Conflitos de sinais sem apagar evidência original. | 1.17.0 |
| `canal` | `varchar(32)` | não | direto_desconhecido | Canal da sessão pela fotografia de entrada, separado do toque comercial. | 1.17.0 |
| `origem_ia` | `varchar(24)` | não |  | Provedor identificável da referência de entrada; nunca provedor inferido de IP. | 1.17.0 |
| `entrada` | `varchar(190)` | não |  | Caminho de entrada sanitizado; sem texto pesquisado ou query de campanha. | 1.17.0 |
| `inicio_sessao` | `bigint unsigned` | não | 0 | Epoch UTC do início conhecido; zero quando não observado com prova. | 1.17.0 |
| `tipo` | `varchar(20)` | não | NULL | Tipo do evento ou da reserva; consultar enum da tabela. | 1.13.0 |
| `caminho` | `varchar(190)` | não | NULL | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | 1.13.0 |
| `formulario` | `varchar(80)` | não |  | ID nativo validado na origem; ausente quando conversa autorizada não traz formulário. | 1.13.0 |
| `formulario_revisao` | `varchar(64)` | não |  | Hash da definição do formulário no instante da captura. | 1.13.0 |
| `correlacao` | `varchar(64)` | não |  | Identificador declarado da instância/submissão; não é chave universal de publicidade. | 1.13.0 |
| `dispositivo` | `varchar(16)` | não | NULL | movel ou desktop pela largura da tela; não identifica hardware. | 1.13.0 |
| `criado_em` | `bigint unsigned` | não | NULL | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | 1.13.0 |
| `recebido_em` | `bigint unsigned` | não | NULL | Recepção pelo Core em epoch UTC. | 1.13.0 |
| `qualidade` | `varchar(16)` | não | NULL | Qualidade própria da tabela; editorial_dias: bruto_disponivel/bruto_expirado. | 1.13.0 |
| `oferta_id` | `varchar(80)` | não |  | ID estável de oferta do tema. | 1.19.0 |
| `oferta_tipo` | `varchar(16)` | não |  | modal, folha, barra ou bloco. | 1.19.0 |
| `oferta_instancia` | `char(32)` | não |  | ID aleatório da apresentação por nó/carregamento. | 1.19.0 |
| `detalhe` | `varchar(64)` | não |  | Dimensão fechada da métrica, como marco, seção ou código de erro; não contém mensagem livre. | 1.13.0 |
| `valor` | `double` | não | 0 | Valor numérico da métrica; unidade depende da metrica/detalhe. | 1.13.0 |
| `sequencia` | `int unsigned` | não | 1 | Número crescente da revisão da amostra; conservar a maior sequência válida. | 1.13.0 |
| `atribuicao` | `text` | não | NULL | JSON do contrato compartilhado de origem publicitária. | 1.13.0 |
| `payload_hash` | `char(64)` | não | NULL | Hash da intenção para idempotência; não permite reconstruir os dados. | 1.14.0 |

Índices:

- `PRIMARY` (único): `id`.
- `evento` (único): `evento`.
- `periodo` (não único): `criado_em`, `tipo`.
- `trafego_periodo` (não único): `classe_trafego`, `criado_em`, `tipo`.
- `sessao` (não único): `sessao`, `criado_em`.
- `navegacao` (não único): `navegacao`, `tipo`.
- `conteudo_periodo` (não único): `post_id`, `criado_em`.
- `inicio_sessao` (não único): `inicio_sessao`, `sessao`.
- `tipo_periodo` (não único): `tipo_conteudo`, `criado_em`.
- `visitante` (não único): `visitante`.
- `correlacao` (não único): `correlacao`.

## f3base_arquivos_leads

Um arquivo físico privado identificado por ID/hash.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `varchar(32)` | não | NULL | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `dono` | `varchar(32)` | não |  | record_id proprietário de anexo; vazio para material ainda não vinculado. | base 1.12.0 ou anterior |
| `finalidade` | `varchar(20)` | não | NULL | anexo do contato ou material privado conforme cadastro. | base 1.12.0 ou anterior |
| `nome` | `text` | não | NULL | Nome original do arquivo/material; dado potencialmente pessoal. | base 1.12.0 ou anterior |
| `mime` | `varchar(120)` | não | NULL | Tipo MIME observado do arquivo. | base 1.12.0 ou anterior |
| `mime_alerta` | `varchar(80)` | não |  | Alerta de divergência reconhecível MIME/extensão; não é bloqueio global. | 1.19.0 |
| `blob_id` | `varchar(32)` | não |  | Identificador do blob imutável privado; não exportar caminho físico. | 1.19.0 |
| `atualizado_em` | `bigint` | não | 0 | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.19.0 |
| `midia_id` | `bigint` | não | 0 | Attachment de origem copiado, zero sem vínculo público. | 1.19.0 |
| `bytes` | `bigint unsigned` | não | NULL | Tamanho do arquivo em bytes. | base 1.12.0 ou anterior |
| `sha256` | `varchar(64)` | não | NULL | Hash SHA-256 do conteúdo binário privado. | base 1.12.0 ou anterior |
| `criado_em` | `bigint` | não | NULL | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |
| `estado` | `varchar(20)` | não | preparado | Estado próprio do recurso; não confundir captura, email e CRM. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `id`.
- `dono` (não único): `dono`.
- `estado` (não único): `estado`, `criado_em`.

## f3base_atendimento_historico

Uma mudança operacional por record_id e revisão.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Chave física local. Não identifica pessoa ou anúncio. | 1.13.0 |
| `record_id` | `char(32)` | não | NULL | Identificador local opaco de 32 caracteres hexadecimais. | 1.13.0 |
| `revisao` | `bigint unsigned` | não | NULL | Revisão otimista do registro; deve acompanhar ações de escrita. | 1.13.0 |
| `anterior` | `varchar(20)` | não | NULL | Estado de atendimento anterior à alteração. | 1.13.0 |
| `atual` | `varchar(20)` | não | NULL | Estado de atendimento após alteração. | 1.13.0 |
| `em` | `bigint unsigned` | não | NULL | Epoch UTC da operação de auditoria. | 1.13.0 |
| `operador` | `bigint unsigned` | não | NULL | ID do usuário WordPress responsável pela operação administrativa. | 1.13.0 |

Índices:

- `PRIMARY` (único): `id`.
- `alteracao` (único): `record_id`, `revisao`.
- `periodo` (não único): `em`.

## f3base_capi_fila

Uma entrega durável por chave idempotente (Lead ou PageView); vínculo de captura por evento_hash.

Guia: `docs/META-TRANSPORTE-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `record_id` | `varchar(128)` | não | NULL | Chave idempotente da entrega; Lead usa record_id local e PageView chave própria, até 128 caracteres. | base 1.12.0 ou anterior |
| `payload` | `longtext` | não | NULL | Envelope cifrado f3capi:v1: (secretbox); vazio após desfecho/expiração. Nunca exportar ou interpretar como JSON aberto. | base 1.12.0 ou anterior |
| `estado` | `varchar(16)` | não | NULL | Estado próprio do recurso; não confundir captura, email e CRM. | base 1.12.0 ou anterior |
| `tentativas` | `int unsigned` | não | 0 | Execuções da etapa com falha; pausas não consomem tentativas. | base 1.12.0 ou anterior |
| `proxima` | `bigint unsigned` | não | 0 | Próxima execução elegível, epoch UTC. | base 1.12.0 ou anterior |
| `expira` | `bigint unsigned` | não | NULL | Expiração epoch em segundos. | base 1.12.0 ou anterior |
| `atualizado` | `bigint unsigned` | não | NULL | Última alteração da fila em epoch de segundos. | base 1.12.0 ou anterior |
| `reserva` | `varchar(64)` | não |  | ID opaco da reserva/lease de execução. | base 1.12.0 ou anterior |
| `http` | `int` | não | 0 | Último código HTTP observado no transporte. | base 1.12.0 ou anterior |
| `pixel_id` | `varchar(64)` | não |  | ID da conta de destino Meta Pixel, como string. | base 1.12.0 ou anterior |
| `decisao_ref` | `varchar(64)` | não |  | Referência à decisão de consentimento aplicável à entrega. | base 1.12.0 ou anterior |
| `politica_versao` | `varchar(64)` | não |  | Versão declarada da política de consentimento. | base 1.12.0 ou anterior |
| `iniciado` | `bigint unsigned` | não | 0 | Início da tentativa em epoch de segundos. | base 1.12.0 ou anterior |
| `cancelado` | `bigint unsigned` | não | 0 | Carimbo/indicador operacional de cancelamento; conferir estado antes de interpretar. | base 1.12.0 ou anterior |
| `lead_id` | `bigint unsigned` | não | 0 | Identificador legado/local da origem da fila; não substituir record_id por inferência. | base 1.12.0 ou anterior |
| `eliminar_lead` | `int` | não | 0 | Booleano de remoção pendente do vínculo de lead. | base 1.12.0 ou anterior |
| `limpeza_pendente` | `int` | não | 0 | Booleano de limpeza a concluir após reconciliação do transporte. | base 1.12.0 ou anterior |
| `motivo` | `varchar(64)` | não |  | Código técnico da recusa/estado, sem corpo de contato. | base 1.12.0 ou anterior |
| `agendamento_falhou` | `int` | não | 0 | Booleano indicando falha ao agendar a próxima tentativa. | base 1.12.0 ou anterior |
| `schema_versao` | `int` | não | 3 | Versão por linha e padrão SQL: 3. Linhas 1.19 vazias são normalizadas sem reenviar. | base 1.12.0 ou anterior |
| `evento_hash` | `char(64)` | não |  | SHA-256 de event_name\|event_id para conciliar captura Meta e fila. | 1.19.0 |
| `classe_trafego` | `varchar(16)` | não | nao_marcado | Campo técnico; consultar o serviço responsável. | 1.19.0 |
| `evento_nome` | `varchar(32)` | não | Lead | Nome Meta PageView/Lead. | 1.19.0 |
| `evento_em` | `bigint` | não | 0 | Instante UTC original; nunca renovado em retentativa. | 1.19.0 |
| `rota` | `varchar(20)` | não | ambos | navegador, ambos ou servidor no evento Meta; em outras tabelas consulte a identidade editorial. | 1.19.0 |
| `prazo_regra` | `varchar(100)` | não | legado_1h | Regra conservadora ou janela externa conferida que limitou a expiração. | 1.19.0 |

Índices:

- `PRIMARY` (único): `record_id`.
- `pendentes` (não único): `estado`, `proxima`.
- `expiracao` (não único): `expira`.

## f3base_comportamento

Uma combinação de dia, caminho, métrica, detalhe, classe e regra/fuso.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` | não | nao_marcado | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. | 1.14.0 |
| `dia` | `char(10)` | não | NULL | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `caminho` | `varchar(190)` | não | NULL | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `metrica` | `varchar(64)` | não | NULL | Nome estável declarado em dados/eventos-comportamento.tsv; vitais usam LCP, CLS, INP, FCP, TTFB conforme amostra disponível. | base 1.12.0 ou anterior |
| `detalhe` | `varchar(60)` | não |  | Dimensão fechada da métrica, como marco, seção ou código de erro; não contém mensagem livre. | base 1.12.0 ou anterior |
| `contagem` | `bigint unsigned` | não | 0 | Quantidade agregada na granularidade da linha. | base 1.12.0 ou anterior |
| `soma` | `double` | não | 0 | Soma aditiva na unidade indicada em metrica; contagem separa tamanho da amostra. | base 1.12.0 ou anterior |
| `regra` | `varchar(64)` | não | legado | Hash da regra de classificação/calendário. | base 1.12.0 ou anterior |
| `fuso` | `varchar(64)` | não | UTC | Fuso aplicado à agregação; comparar somente regras e fusos compatíveis. | base 1.12.0 ou anterior |
| `qualidade` | `varchar(16)` | não | legado | Qualidade própria da tabela; editorial_dias: bruto_disponivel/bruto_expirado. | base 1.12.0 ou anterior |
| `atualizado_em` | `bigint unsigned` | não | 0 | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `chave`.
- `classe_dia` (não único): `classe_trafego`, `dia`.
- `dia` (não único): `dia`.
- `dia_metrica` (não único): `dia`, `metrica`.

## f3base_concessoes

Uma concessão de material/versão para um lead, com quota e validade.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `varchar(32)` | não | NULL | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `lead_record_id` | `varchar(32)` | não | NULL | Contato que originou a concessão; relação muitos para um. | base 1.12.0 ou anterior |
| `ativo` | `varchar(32)` | não | NULL | ID estável do recurso privado. | base 1.12.0 ou anterior |
| `versao` | `varchar(64)` | não | NULL | Versão/hash do material concedido; não é versão do plugin. | base 1.12.0 ou anterior |
| `dedup` | `varchar(64)` | sim | NULL | Chave única da concessão para repetição idempotente. | base 1.12.0 ou anterior |
| `expira` | `bigint` | não | NULL | Expiração epoch em segundos. | base 1.12.0 ou anterior |
| `quota` | `int` | não | NULL | Máximo de utilizações autorizadas da concessão. | base 1.12.0 ou anterior |
| `usados` | `int` | não | 0 | Quantidade de tentativas autorizadas debitadas; não comprova leitura completa do arquivo. | base 1.12.0 ou anterior |
| `revogada` | `tinyint(1)` | não | 0 | Booleano de revogação da concessão/decisão. | base 1.12.0 ou anterior |
| `primeira` | `bigint` | não | 0 | Horário epoch de segundos do primeiro uso autorizado. | base 1.12.0 ou anterior |
| `ultima` | `bigint` | não | 0 | Horário epoch de segundos do último uso autorizado. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `id`.
- `dedup` (único): `dedup`.
- `lead_record_id` (não único): `lead_record_id`.

## f3base_consentimento_decisoes

Uma referência de decisão de consentimento e validade.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `ref` | `varchar(64)` | não | NULL | Referência opaca da decisão de consentimento. | base 1.12.0 ou anterior |
| `politica_versao` | `varchar(64)` | não | NULL | Versão declarada da política de consentimento. | base 1.12.0 ou anterior |
| `medicao` | `tinyint` | não | 0 | Booleano da permissão de medição. | base 1.12.0 ou anterior |
| `publicidade` | `tinyint` | não | 0 | Booleano da permissão publicitária. | base 1.12.0 ou anterior |
| `revogada` | `tinyint` | não | 0 | Booleano de revogação da concessão/decisão. | base 1.12.0 ou anterior |
| `expira_em` | `bigint` | não | NULL | Expiração epoch de segundos. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `ref`.
- `expira_em` (não único): `expira_em`.

## f3base_contatos_legados

Registro histórico preservado; nenhum importador é executado nesta release.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `origem_chave` | `varchar(190)` | não | NULL | Chave no escopo da fonte histórica; única quando presente. | base 1.12.0 ou anterior |
| `email` | `varchar(254)` | não |  | Endereço informado pelo contato; dado pessoal, pode estar vazio em cliques. | base 1.12.0 ou anterior |
| `dados` | `longtext` | não | NULL | Snapshot JSON do contato e contexto; contrato dos caminhos abaixo. | base 1.12.0 ou anterior |
| `origem_hash` | `varchar(64)` | não | NULL | Hash da representação da origem histórica para controle de integridade. | base 1.12.0 ou anterior |
| `eliminado` | `tinyint(1)` | não | 0 | Tombstone: impede que a sobreposição recrie contato eliminado. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `id`.
- `origem_chave` (único): `origem_chave`.
- `email` (não único): `email`.

## f3base_eventos

Uma ocorrência detalhada da sessão/caminho/métrica; qualidade temporal por linha.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` | não | nao_marcado | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. | 1.14.0 |
| `visitante` | `char(32)` | não | NULL | Identificador local pseudônimo do navegador, sujeito a consentimento e expiração. | base 1.12.0 ou anterior |
| `sessao` | `char(32)` | não | NULL | Identificador analítico opcional, originado no navegador; não equivale a pessoa. | base 1.12.0 ou anterior |
| `navegacao` | `char(32)` | não |  | ID aleatório de um carregamento; comum entre eventos, análise e dados do lead, sem criar pessoa. | 1.17.0 |
| `automacao` | `varchar(20)` | não | nao_identificada | declarada, provavel ou nao_identificada; separado da marca de teste. Ausência de sinal não prova humano. | 1.17.0 |
| `automacao_motivos` | `varchar(190)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `automacao_regra` | `varchar(40)` | não |  | Versão da regra e lista de assinaturas aplicada na captura; vazio para histórico sem regra. | 1.17.0 |
| `dia` | `char(10)` | não | NULL | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `caminho` | `varchar(190)` | não | NULL | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `metrica` | `varchar(64)` | não | NULL | Nome estável declarado em dados/eventos-comportamento.tsv; vitais usam LCP, CLS, INP, FCP, TTFB conforme amostra disponível. | base 1.12.0 ou anterior |
| `detalhe` | `varchar(60)` | não |  | Dimensão fechada da métrica, como marco, seção ou código de erro; não contém mensagem livre. | base 1.12.0 ou anterior |
| `valor` | `double` | não | 0 | Valor numérico da métrica; unidade depende da metrica/detalhe. | base 1.12.0 ou anterior |
| `ocorrencia` | `int unsigned` | não | 1 | Ordinal do acionamento na sessão/caminho/métrica; reenvio não cria nova ocorrência. | base 1.12.0 ou anterior |
| `ms` | `bigint unsigned` | não | 0 | Milissegundos relativos à âncora da sessão; não é epoch. | base 1.12.0 ou anterior |
| `criado_em` | `bigint unsigned` | não | 0 | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |
| `ancora` | `varchar(16)` | não |  | Origem temporal: visitante, servidor ou vazio histórico. Reconstrução absoluta depende dessa qualidade. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `id`.
- `classe_dia` (não único): `classe_trafego`, `dia`.
- `dia` (não único): `dia`.
- `dia_caminho` (não único): `dia`, `caminho`.
- `instante` (não único): `criado_em`, `id`.
- `sessao` (não único): `sessao`.
- `visitante` (não único): `visitante`.

## f3base_leads

Um contato ou intenção registrada. Cliques não são formulários aceitos.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Chave física local. Não identifica pessoa ou anúncio. | base 1.12.0 ou anterior |
| `record_id` | `varchar(32)` | não | NULL | Identificador local opaco de 32 caracteres hexadecimais. | base 1.12.0 ou anterior |
| `correlacao` | `varchar(64)` | sim | NULL | Identificador declarado da instância/submissão; não é chave universal de publicidade. | base 1.12.0 ou anterior |
| `sessao` | `char(32)` | sim | NULL | Identificador analítico opcional, originado no navegador; não equivale a pessoa. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` | não | nao_marcado | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. | 1.14.0 |
| `post_id` | `bigint unsigned` | sim | NULL | ID local do conteúdo em que ocorreu a captura; pode faltar no histórico. | base 1.12.0 ou anterior |
| `resposta` | `varchar(30)` | não | desligada | Em clarity_coletas: gzip da resposta analítica sanitizada; sem token ou corpo de erro. | base 1.12.0 ou anterior |
| `resposta_em` | `bigint` | não | 0 | Horário do processamento/estado de resposta em epoch de segundos; zero indica ausência. | base 1.12.0 ou anterior |
| `resposta_erro` | `varchar(100)` | não |  | Código operacional limitado do último erro de resposta; sem mensagem pessoal. | base 1.12.0 ou anterior |
| `formulario` | `varchar(80)` | não |  | ID nativo validado na origem; ausente quando conversa autorizada não traz formulário. | base 1.12.0 ou anterior |
| `metodo` | `varchar(40)` | não | NULL | Tipo de captura pelo destino/regime: formulario, whatsapp_formulario, conteudo, whatsapp_cta, contato_cta; histórico pode conter legado_desconhecido. | base 1.12.0 ou anterior |
| `captura` | `varchar(20)` | não | aceito | Resultado da captura: aceito, suspeito ou clique. Não representa atendimento comercial. | base 1.12.0 ou anterior |
| `atendimento` | `varchar(20)` | não | novo | Estado operacional: novo, respondido ou spam. | base 1.12.0 ou anterior |
| `lixeira` | `tinyint(1)` | não | 0 | Booleano de remoção operacional reversível; relatórios integrados excluem 1. | base 1.12.0 ou anterior |
| `criado_em` | `datetime` | não | NULL | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |
| `atualizado_em` | `datetime` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | base 1.12.0 ou anterior |
| `email` | `varchar(254)` | não |  | Endereço informado pelo contato; dado pessoal, pode estar vazio em cliques. | base 1.12.0 ou anterior |
| `nome` | `varchar(250)` | não |  | Nome informado ou nome original do arquivo, conforme a tabela; não usar para deduplicar pessoas. | base 1.12.0 ou anterior |
| `pagina` | `text` | não | NULL | URL da página de captura; relatórios normalizam caminho e omitem query/fragmento. | base 1.12.0 ou anterior |
| `dados` | `longtext` | não | NULL | Snapshot JSON do contato e contexto; contrato dos caminhos abaixo. | base 1.12.0 ou anterior |
| `entrega` | `longtext` | sim | NULL | Intenção durável e recibo de integração, no próprio lead; sem duplicar contato na fila. | 1.16.0 |
| `anexos` | `longtext` | não | NULL | Lista JSON dos anexos privados vinculados; não contém URL pública de acesso. | base 1.12.0 ou anterior |
| `idempotencia` | `varchar(64)` | sim | NULL | Chave de deduplicação da submissão. Mesma chave com payload diferente é conflito. | base 1.12.0 ou anterior |
| `payload_hash` | `varchar(64)` | não | NULL | Hash da intenção para idempotência; não permite reconstruir os dados. | base 1.12.0 ou anterior |
| `origem_chave` | `varchar(190)` | sim | NULL | Chave no escopo da fonte histórica; única quando presente. | base 1.12.0 ou anterior |
| `origem_hash` | `varchar(64)` | não |  | Hash da representação da origem histórica para controle de integridade. | base 1.12.0 ou anterior |
| `importado_hash` | `varchar(64)` | não |  | Hash preservado da importação já realizada; não ativa novo importador. | base 1.12.0 ou anterior |
| `revisao` | `bigint unsigned` | não | 1 | Revisão otimista do registro; deve acompanhar ações de escrita. | base 1.12.0 ou anterior |
| `aviso` | `varchar(30)` | não | desligado | Estado do aviso interno à equipe; separado de resposta automática ao visitante. | base 1.12.0 ou anterior |
| `aviso_em` | `bigint` | não | 0 | Último horário operacional do aviso, epoch em segundos. | base 1.12.0 ou anterior |
| `aviso_erro` | `varchar(100)` | não |  | Código limitado de falha do aviso, sem corpo da mensagem. | base 1.12.0 ou anterior |
| `eliminacao_pendente` | `tinyint(1)` | não | 0 | Booleano do processo durável de eliminação; registros marcados ficam fora dos relatórios. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `id`.
- `record_id` (único): `record_id`.
- `idempotencia` (único): `idempotencia`.
- `origem_chave` (único): `origem_chave`.
- `cronologia` (não único): `criado_em`, `id`.
- `trafego_periodo` (não único): `classe_trafego`, `criado_em`, `id`.
- `sessao` (não único): `sessao`.
- `post_id` (não único): `post_id`.
- `email` (não único): `email`.
- `aviso` (não único): `aviso`, `aviso_em`.

## f3base_leads_dedup

Uma reserva/chave técnica de deduplicação, sem valor comercial isolado.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | base 1.12.0 ou anterior |
| `tipo` | `varchar(12)` | não | dedup | Tipo do evento ou da reserva; consultar enum da tabela. | base 1.12.0 ou anterior |
| `estado` | `varchar(10)` | não | pendente | Estado próprio do recurso; não confundir captura, email e CRM. | base 1.12.0 ou anterior |
| `record_id` | `char(32)` | não |  | Identificador local opaco de 32 caracteres hexadecimais. | base 1.12.0 ou anterior |
| `contador` | `int unsigned` | não | 0 | Contador técnico da reserva de deduplicação. | base 1.12.0 ou anterior |
| `expira_em` | `bigint unsigned` | não | 0 | Expiração epoch de segundos. | base 1.12.0 ou anterior |
| `criado_em` | `bigint unsigned` | não | NULL | Horário de criação/ocorrência; a unidade específica da tabela consta no campo unidade. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `chave`.
- `criado_em` (não único): `criado_em`.
- `tipo_expira` (não único): `tipo`, `expira_em`.

## f3base_leads_janelas

Uma quota técnica com prazo de expiração.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `varchar(190)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | base 1.12.0 ou anterior |
| `total` | `bigint` | não | 0 | Contador técnico de quota/recusa; não é volume de leads. | base 1.12.0 ou anterior |
| `expira` | `bigint` | não | NULL | Expiração epoch em segundos. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `chave`.
- `expira` (não único): `expira`.

## f3base_leads_recusas

Um total de recusas por motivo e dia, sem dados pessoais.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `dia` | `date` | não | NULL | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `motivo` | `varchar(40)` | não | NULL | Código técnico da recusa/estado, sem corpo de contato. | base 1.12.0 ou anterior |
| `total` | `bigint unsigned` | não | 0 | Contador técnico de quota/recusa; não é volume de leads. | base 1.12.0 ou anterior |
| `primeiro` | `bigint unsigned` | não | NULL | Horário do primeiro registro da recusa no dia, epoch de segundos. | base 1.12.0 ou anterior |
| `ultimo` | `bigint unsigned` | não | NULL | Horário do último registro da recusa no dia, epoch de segundos. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `dia`, `motivo`.

## f3base_vitais

Uma amostra de vital atualizada por sequência; sem sessão vinculável.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `amostra` | `char(64)` | não | NULL | Identificador da amostra vital atualizável, sem chave de sessão nesta tabela. | base 1.12.0 ou anterior |
| `classe_trafego` | `varchar(16)` | não | nao_marcado | Marca da captura: nao_marcado ou teste; não é classificação de robô nem estado de spam. | 1.14.0 |
| `dia` | `date` | não | NULL | Dia de agregação no calendário declarado pela regra/fuso; não converter como se fosse timestamp UTC. | base 1.12.0 ou anterior |
| `caminho` | `varchar(760)` | não | NULL | Caminho normalizado sem dados de query; pode conter referência /@post-ID em permalink simples. | base 1.12.0 ou anterior |
| `metrica` | `varchar(8)` | não | NULL | Nome estável declarado em dados/eventos-comportamento.tsv; vitais usam LCP, CLS, INP, FCP, TTFB conforme amostra disponível. | base 1.12.0 ou anterior |
| `dispositivo` | `varchar(16)` | não | NULL | movel ou desktop pela largura da tela; não identifica hardware. | base 1.12.0 ou anterior |
| `sequencia` | `int unsigned` | não | NULL | Número crescente da revisão da amostra; conservar a maior sequência válida. | base 1.12.0 ou anterior |
| `valor` | `double` | não | NULL | Valor numérico da métrica; unidade depende da metrica/detalhe. | base 1.12.0 ou anterior |

Índices:

- `PRIMARY` (único): `amostra`.
- `periodo` (não único): `dia`, `metrica`, `dispositivo`.
- `classe_dia` (não único): `classe_trafego`, `dia`.
- `pagina` (não único): `caminho`.

## f3base_acessos_horas

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `dia` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |
| `hora_utc` | `datetime` | não | NULL | Início da hora em UTC; dia conserva o calendário da regra. | 1.16.0 |
| `agente` | `varchar(64)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |
| `classe_caminho` | `varchar(16)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |
| `status_grupo` | `varchar(16)` | não | NULL | atendido: 2xx/304; bloqueado: 403/429; outro: demais respostas. | 1.16.0 |
| `caminho` | `varchar(191)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `metodo` | `varchar(5)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `status` | `smallint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `dimensao` | `char(64)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo_conteudo` | `varchar(32)` | não |  | Tipo WordPress normalizado: pagina, artigo ou recurso/CPT explícito. | 1.17.0 |
| `representacao` | `varchar(20)` | não | nao_resolvida | html, markdown_core, descoberta ou nao_resolvida; não afirma leitura. | 1.17.0 |
| `resolucao` | `varchar(32)` | não | historico_sem_identidade | Versão/procedência da identificação editorial no acesso. | 1.17.0 |
| `rede_estado` | `varchar(24)` | não | nao_verificada | Compatibilidade com faixa oficial; não é autenticação do robô. | 1.17.0 |
| `rede_lista` | `char(64)` | não |  | Identidade/hash da lista pública usada; nunca IP ou hash de IP individual. | 1.17.0 |
| `rede_data` | `bigint unsigned` | não | 0 | Data técnica de obtenção da lista oficial. | 1.17.0 |
| `rede_versao` | `varchar(64)` | não |  | Versão do classificador de rede. | 1.17.0 |
| `assinatura_ua` | `varchar(80)` | não | historico_desconhecido | Produtos técnicos sem versão de vocabulário controlado; não identifica operador desconhecido. | 1.19.0 |
| `assinatura_regra` | `varchar(24)` | não |  | Versão da extração da assinatura reduzida. | 1.19.0 |
| `contagem` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |

Índices:

- `PRIMARY` (único): `dia`, `hora_utc`, `agente`, `classe_caminho`, `status_grupo`, `dimensao`.
- `hora_agente` (não único): `hora_utc`, `agente`.
- `conteudo` (não único): `post_id`, `hora_utc`.

## f3base_acessos_horas_fontes

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `fonte` | `char(64)` | não | NULL | Identidade hash do arquivo de contribuição; reimportação substitui. | 1.16.0 |
| `regra` | `char(64)` | não | NULL | Hash da regra de classificação/calendário. | 1.16.0 |
| `dia` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |
| `hora_utc` | `datetime` | não | NULL | Início da hora em UTC; dia conserva o calendário da regra. | 1.16.0 |
| `agente` | `varchar(64)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |
| `classe_caminho` | `varchar(16)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |
| `status_grupo` | `varchar(16)` | não | NULL | atendido: 2xx/304; bloqueado: 403/429; outro: demais respostas. | 1.16.0 |
| `caminho` | `varchar(191)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `metodo` | `varchar(5)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `status` | `smallint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `dimensao` | `char(64)` | não |  | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo_conteudo` | `varchar(32)` | não |  | Tipo WordPress normalizado: pagina, artigo ou recurso/CPT explícito. | 1.17.0 |
| `representacao` | `varchar(20)` | não | nao_resolvida | html, markdown_core, descoberta ou nao_resolvida; não afirma leitura. | 1.17.0 |
| `resolucao` | `varchar(32)` | não | historico_sem_identidade | Versão/procedência da identificação editorial no acesso. | 1.17.0 |
| `rede_estado` | `varchar(24)` | não | nao_verificada | Compatibilidade com faixa oficial; não é autenticação do robô. | 1.17.0 |
| `rede_lista` | `char(64)` | não |  | Identidade/hash da lista pública usada; nunca IP ou hash de IP individual. | 1.17.0 |
| `rede_data` | `bigint unsigned` | não | 0 | Data técnica de obtenção da lista oficial. | 1.17.0 |
| `rede_versao` | `varchar(64)` | não |  | Versão do classificador de rede. | 1.17.0 |
| `assinatura_ua` | `varchar(80)` | não | historico_desconhecido | Produtos técnicos sem versão de vocabulário controlado; não identifica operador desconhecido. | 1.19.0 |
| `assinatura_regra` | `varchar(24)` | não |  | Versão da extração da assinatura reduzida. | 1.19.0 |
| `contagem` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.16.0 |

Índices:

- `PRIMARY` (único): `fonte`, `dia`, `hora_utc`, `agente`, `classe_caminho`, `status_grupo`, `dimensao`.
- `hora_agente` (não único): `hora_utc`, `agente`.
- `conteudo` (não único): `post_id`, `hora_utc`.

## f3base_anuncios_recibos

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | 1.16.0 |
| `origem` | `varchar(16)` | não | NULL | Origem nativa: meta ou google. | 1.16.0 |
| `conta` | `varchar(100)` | não | NULL | Conta vinculada no momento da entrega; alteração suspende reinterpretação de IDs. | 1.16.0 |
| `formulario` | `varchar(100)` | não | NULL | ID nativo validado na origem; ausente quando conversa autorizada não traz formulário. | 1.16.0 |
| `nativo_id` | `varchar(191)` | não | NULL | ID opaco da submissão atribuído pela plataforma; string, não email. | 1.16.0 |
| `record_id` | `char(32)` | não | NULL | Identificador local opaco de 32 caracteres hexadecimais. | 1.16.0 |
| `projecao` | `char(64)` | não | NULL | Hash da projeção comparável do conteúdo nativo. | 1.16.0 |
| `nativo_em` | `bigint unsigned` | não | NULL | Epoch UTC do provedor, ou recepção com ausência de instante nativo indicada no JSON. | 1.16.0 |
| `recebido_em` | `bigint unsigned` | não | NULL | Recepção pelo Core em epoch UTC. | 1.16.0 |
| `via` | `varchar(24)` | não | NULL | webhook, reconciliacao_api ou consulta_meta. | 1.16.0 |
| `eliminado` | `tinyint` | não | 0 | Tombstone: impede que a sobreposição recrie contato eliminado. | 1.16.0 |

Índices:

- `PRIMARY` (único): `chave`.
- `registro` (não único): `record_id`.
- `recebido` (não único): `recebido_em`.

## f3base_pipedrive_fila

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | 1.16.0 |
| `record_id` | `char(32)` | não | NULL | Identificador local opaco de 32 caracteres hexadecimais. | 1.16.0 |
| `conta` | `varchar(191)` | não | NULL | Conta vinculada no momento da entrega; alteração suspende reinterpretação de IDs. | 1.16.0 |
| `estado` | `varchar(20)` | não | pendente | Estado próprio do recurso; não confundir captura, email e CRM. | 1.16.0 |
| `etapa` | `varchar(24)` | não |  | Escrita remota iniciada sem confirmação completa, ou vazio. | 1.16.0 |
| `journal` | `longtext` | não | NULL | Etapas e IDs remotos, hashes de autoria e estado da eliminação; sem corpo de contato. | 1.16.0 |
| `tentativas` | `smallint unsigned` | não | 0 | Execuções da etapa com falha; pausas não consomem tentativas. | 1.16.0 |
| `proxima` | `bigint unsigned` | não | NULL | Próxima execução elegível, epoch UTC. | 1.16.0 |
| `lease` | `char(36)` | não |  | Dono opaco da reserva temporária. Não retornar ao usuário como credencial. | 1.16.0 |
| `lease_ate` | `bigint unsigned` | não | 0 | Vencimento da reserva em epoch UTC. | 1.16.0 |
| `capturado_em` | `bigint unsigned` | não | NULL | Instante da captura local, epoch UTC. | 1.16.0 |
| `primeira_tentativa` | `bigint unsigned` | não | 0 | Primeiro despacho efetivo, epoch UTC; zero significa não iniciado. | 1.16.0 |
| `concluido_em` | `bigint unsigned` | não | 0 | Instante da confirmação da entrega; zero significa ainda não confirmado. | 1.16.0 |
| `atualizado_em` | `bigint unsigned` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.16.0 |
| `codigo` | `varchar(100)` | não |  | Resultado resumido sem resposta bruta ou dados pessoais. | 1.16.0 |

Índices:

- `PRIMARY` (único): `chave`.
- `agenda` (não único): `estado`, `proxima`.
- `registro` (não único): `record_id`.
- `historico` (não único): `concluido_em`.

## f3base_conteudo_rotas

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `rota_hash` | `char(64)` | não | NULL | Hash da rota pública normalizada; não identifica visitante. | 1.17.0 |
| `caminho` | `varchar(190)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo` | `varchar(32)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `representacao` | `varchar(20)` | não | NULL | html, markdown_core, descoberta ou nao_resolvida; não afirma leitura. | 1.17.0 |
| `inicio` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `fim` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `proveniencia` | `varchar(32)` | não | NULL | Fonte da associação entre rota e conteúdo. | 1.17.0 |
| `recurso` | `varchar(64)` | não |  | Identidade de recurso público (termo/arquivo), usada para fechar rotas antigas. | 1.17.0 |

Índices:

- `PRIMARY` (único): `id`.
- `rota` (não único): `rota_hash`, `inicio`, `fim`.
- `post_id` (não único): `post_id`, `fim`.
- `recurso` (não único): `recurso`, `fim`.

## f3base_conteudos

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `post_id` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo` | `varchar(32)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `titulo` | `varchar(250)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `url` | `text` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `caminho` | `varchar(190)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `publico` | `tinyint` | não | NULL | Elegibilidade atual do conteúdo para o catálogo público. | 1.17.0 |
| `atualizado_em` | `bigint unsigned` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.17.0 |

Índices:

- `PRIMARY` (único): `post_id`.
- `tipo` (não único): `tipo`, `publico`.
- `caminho` (não único): `caminho`.

## f3base_editorial_diario

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | 1.17.0 |
| `dia` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `caminho` | `varchar(190)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `tipo` | `varchar(32)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `canal` | `varchar(32)` | não | NULL | Canal da sessão pela fotografia de entrada, separado do toque comercial. | 1.17.0 |
| `origem_ia` | `varchar(24)` | não | NULL | Provedor identificável da referência de entrada; nunca provedor inferido de IP. | 1.17.0 |
| `classe_trafego` | `varchar(16)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `automacao` | `varchar(20)` | não | NULL | declarada, provavel ou nao_identificada; separado da marca de teste. Ausência de sinal não prova humano. | 1.17.0 |
| `metrica` | `varchar(32)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `contagem` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `soma` | `double` | não | 0 | Soma aditiva na unidade indicada em metrica; contagem separa tamanho da amostra. | 1.17.0 |
| `atualizado_em` | `bigint unsigned` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.17.0 |

Índices:

- `PRIMARY` (único): `chave`.
- `periodo` (não único): `dia`, `metrica`.
- `conteudo` (não único): `post_id`, `dia`.

## f3base_editorial_dias

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `dia` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `fechado` | `tinyint` | não | 0 | Contribuição diária consolidada com sucesso. | 1.17.0 |
| `atualizado_em` | `bigint unsigned` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.17.0 |
| `qualidade` | `varchar(24)` | não | NULL | Qualidade própria da tabela; editorial_dias: bruto_disponivel/bruto_expirado. | 1.17.0 |

Índices:

- `PRIMARY` (único): `dia`.

## f3base_gsc_diario

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | 1.17.0 |
| `universo` | `char(64)` | não | NULL | Hash de propriedade/pesquisa/escopo/filtros GSC; não somar universos incompatíveis. | 1.17.0 |
| `propriedade` | `varchar(250)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `dia` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `pesquisa` | `varchar(16)` | não | NULL | Tipo de busca Search Console. | 1.17.0 |
| `escopo` | `varchar(16)` | não | NULL | paginas ou propriedade; totais são separados. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `url` | `text` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `cliques` | `double` | não | NULL | Cliques agregados no universo Search Console quando nessa tabela. | 1.17.0 |
| `impressoes` | `double` | não | NULL | Impressões agregadas; denominador de CTR e peso da posição. | 1.17.0 |
| `posicao` | `double` | não | NULL | Posição média fornecida; agrega com peso de impressões. | 1.17.0 |
| `estado` | `varchar(16)` | não | NULL | Estado próprio do recurso; não confundir captura, email e CRM. | 1.17.0 |
| `extraido_em` | `bigint unsigned` | não | NULL | Epoch UTC da fotografia externa; fotografia antiga/parcial não sobrescreve final mais recente. | 1.17.0 |
| `fonte` | `varchar(128)` | não | NULL | Identidade hash do arquivo de contribuição; reimportação substitui. | 1.17.0 |
| `cobertura` | `text` | não | NULL | JSON com completa/truncada/limite_linhas e observação da fonte autorizada. | 1.17.0 |
| `filtros` | `text` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |

Índices:

- `PRIMARY` (único): `chave`.
- `periodo` (não único): `dia`, `pesquisa`, `escopo`.
- `conteudo` (não único): `post_id`, `dia`.

## f3base_inteligencia_auditoria

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `acao` | `varchar(40)` | não | NULL | Ação administrativa auditada; sem copiar corpo de evidência. | 1.17.0 |
| `chave_sha256` | `char(64)` | não | NULL | Hash da chave administrativa, sem dado de visitante. | 1.17.0 |
| `revisao` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `operador` | `bigint unsigned` | não | NULL | ID do usuário WordPress responsável pela operação administrativa. | 1.17.0 |
| `em` | `bigint unsigned` | não | NULL | Epoch UTC da operação de auditoria. | 1.17.0 |

Índices:

- `PRIMARY` (único): `id`.
- `registro` (não único): `chave_sha256`, `em`.

## f3base_medicao_anotacoes

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `chave` | `varchar(128)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | 1.17.0 |
| `inicio` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `fim` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `motivo` | `varchar(500)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `excluir` | `tinyint` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `revisao` | `bigint unsigned` | não | 1 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `atualizado_em` | `bigint unsigned` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.17.0 |
| `operador` | `bigint unsigned` | não | NULL | ID do usuário WordPress responsável pela operação administrativa. | 1.17.0 |

Índices:

- `PRIMARY` (único): `id`.
- `chave` (único): `chave`.
- `periodo` (não único): `inicio`, `fim`.

## f3base_referencias_ia

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `chave` | `varchar(128)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | 1.17.0 |
| `provedor` | `varchar(24)` | não | NULL | Fornecedor da IA observada, declarado pelo registrador. | 1.17.0 |
| `observado_em` | `bigint unsigned` | não | NULL | Epoch UTC da observação fornecida; não é momento inferido de acesso do robô. | 1.17.0 |
| `tipo` | `varchar(24)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `url` | `text` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `topico` | `varchar(250)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `contexto` | `text` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `evidencia` | `text` | não | NULL | Referência administrativa sanitizada; não confundir com uma citação observada automaticamente. | 1.17.0 |
| `evidencia_tipo` | `varchar(16)` | não | NULL | Link público ou ID de evidência privada; nenhuma URL é buscada pelo serviço. | 1.17.0 |
| `origem` | `varchar(16)` | não | NULL | Origem nativa: meta ou google. | 1.17.0 |
| `revisao_estado` | `varchar(16)` | não | NULL | Revisão manual da referência observada; rascunho não vale como evidência conferida. | 1.17.0 |
| `revisao` | `bigint unsigned` | não | 1 | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `criado_em` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.17.0 |
| `atualizado_em` | `bigint unsigned` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.17.0 |
| `operador` | `bigint unsigned` | não | NULL | ID do usuário WordPress responsável pela operação administrativa. | 1.17.0 |

Índices:

- `PRIMARY` (único): `id`.
- `chave` (único): `chave`.
- `conteudo` (não único): `post_id`, `observado_em`.
- `provedor` (não único): `provedor`, `observado_em`.

## f3base_acessos_legado

Guia: `docs/MEDICAO-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | SHA-256 da linha agregada; chave idempotente do arquivo, sem identidade de visitante. | 1.18.0 |
| `dia` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.18.0 |
| `regra` | `varchar(64)` | não | NULL | Hash da regra de classificação/calendário. | 1.18.0 |
| `origem` | `varchar(16)` | não | NULL | diario ou horario: agregado original; recibo: checkpoint transacional de contagem zero. | 1.18.0 |
| `contagem` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.18.0 |
| `arquivado_em` | `bigint unsigned` | não | NULL | Epoch UTC da reconciliação. | 1.18.0 |
| `dados` | `longtext` | não | NULL | JSON da linha agregada original; evidência legada, nunca somar com tabelas correntes. | 1.18.0 |

Índices:

- `PRIMARY` (único): `chave`.
- `periodo` (não único): `dia`, `origem`.

## f3base_arquivos_blobs

Guia: `docs/ARQUIVOS-PRIVADOS-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `blob_id` | `char(32)` | não | NULL | Identificador do blob imutável privado; não exportar caminho físico. | 1.19.0 |
| `ativo` | `char(32)` | não | NULL | ID estável do recurso privado. | 1.19.0 |
| `estado` | `varchar(20)` | não | NULL | Estado próprio do recurso; não confundir captura, email e CRM. | 1.19.0 |
| `criado_em` | `bigint` | não | NULL | Epoch UTC da criação do blob imutável. | 1.19.0 |
| `retirar_em` | `bigint` | não | 0 | Epoch UTC mínimo para limpeza do blob retirado sem referência. | 1.19.0 |

Índices:

- `PRIMARY` (único): `blob_id`.
- `limpeza` (não único): `estado`, `retirar_em`.

## f3base_arquivos_operacoes

Guia: `docs/ARQUIVOS-PRIVADOS-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `chave` | `char(64)` | não | NULL | Hash da chave idempotente da operação autenticada de arquivo. | 1.19.0 |
| `payload_hash` | `char(64)` | não | NULL | Hash da intenção para idempotência; não permite reconstruir os dados. | 1.19.0 |
| `resultado` | `longtext` | não | NULL | Resultado autorizado da operação idempotente de arquivo. | 1.19.0 |
| `criado_em` | `bigint` | não | NULL | Epoch UTC do recibo da operação. | 1.19.0 |

Índices:

- `PRIMARY` (único): `chave`.

## f3base_clarity

Guia: `docs/CLARITY-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `coleta` | `char(32)` | não | NULL | ID da consulta de origem; chave para clarity_coletas.id. | 1.19.0 |
| `parser` | `int` | não | NULL | Versão da derivação normalizada. | 1.19.0 |
| `bloco` | `int` | não | NULL | Posição do bloco na resposta analítica, começando em zero. | 1.19.0 |
| `linha` | `int` | não | NULL | Posição da linha dentro do bloco. | 1.19.0 |
| `metrica` | `varchar(160)` | não | NULL | Nome do bloco/métrica fornecido pelo Clarity; métricas desconhecidas válidas são preservadas. | 1.19.0 |
| `dimensoes` | `text` | não | NULL | JSON das dimensões efetivamente recebidas. | 1.19.0 |
| `valores` | `longtext` | não | NULL | JSON de todos os valores analíticos da linha, com precisão/tipos preservados. | 1.19.0 |
| `post_id` | `bigint` | não | 0 | ID WordPress resolvido da URL; zero quando não resolvido. | 1.19.0 |
| `caminho` | `varchar(190)` | não |  | Caminho sanitizado da dimensão URL, sem query ou fragmento. | 1.19.0 |
| `estado` | `varchar(40)` | não | NULL | Estado próprio do recurso; não confundir captura, email e CRM. | 1.19.0 |

Índices:

- `PRIMARY` (único): `coleta`, `parser`, `bloco`, `linha`.
- `conteudo` (não único): `post_id`, `coleta`.
- `metrica` (não único): `metrica`, `coleta`.

## f3base_clarity_coletas

Guia: `docs/CLARITY-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `char(32)` | não | NULL | ID opaco de 32 caracteres da consulta/tentativa. | 1.19.0 |
| `projeto` | `varchar(32)` | não | NULL | ID público do projeto Clarity, separa acervos. | 1.19.0 |
| `chave` | `char(64)` | não | NULL | Hash idempotente por projeto e intenção da consulta. | 1.19.0 |
| `parametros` | `text` | não | NULL | Dias/dimensões solicitados; definem o universo da consulta. | 1.19.0 |
| `origem` | `varchar(16)` | não | NULL | manual, cron ou restauracao: origem operacional da consulta, não plataforma de anúncio. | 1.19.0 |
| `solicitado_em` | `bigint` | não | NULL | Instante UTC do início da consulta externa. | 1.19.0 |
| `recebido_em` | `bigint` | não | 0 | Recepção pelo Core em epoch UTC. | 1.19.0 |
| `duracao_ms` | `bigint` | não | 0 | Duração observada da chamada externa em milissegundos. | 1.19.0 |
| `janela_dias` | `smallint` | não | NULL | Janela móvel de 1, 2 ou 3 dias, não somável com outras consultas. | 1.19.0 |
| `inicio_nominal` | `bigint` | não | NULL | Início nominal de janela móvel UTC; não implica dia civil isolado. | 1.19.0 |
| `fim_nominal` | `bigint` | não | NULL | Fim nominal da janela móvel UTC na solicitação. | 1.19.0 |
| `estado` | `varchar(40)` | não | NULL | Estado próprio do recurso; não confundir captura, email e CRM. | 1.19.0 |
| `http` | `int` | não | 0 | Código HTTP da chamada, zero quando não observado. | 1.19.0 |
| `motivo` | `varchar(80)` | não |  | Código resumido de erro/qualidade; sem corpo remoto. | 1.19.0 |
| `resposta` | `longblob` | sim | NULL | Em clarity_coletas: gzip da resposta analítica sanitizada; sem token ou corpo de erro. | 1.19.0 |
| `sha256` | `char(64)` | não |  | SHA-256 do JSON analítico sanitizado antes da compressão. | 1.19.0 |
| `saneamento` | `int` | não | 1 | Versão da regra de remoção de dados pessoais/segredos. | 1.19.0 |
| `parser` | `int` | não | 0 | Versão da derivação normalizada. | 1.19.0 |
| `bytes_brutos` | `bigint` | não | 0 | Bytes do JSON sanitizado antes de compressão. | 1.19.0 |
| `bytes_comprimidos` | `bigint` | não | 0 | Bytes de resposta sanitizada gzip. | 1.19.0 |
| `cobertura` | `longtext` | não | NULL | JSON com completude observável, possível truncamento e remoções; não certifica cobertura do fornecedor. | 1.19.0 |

Índices:

- `PRIMARY` (único): `id`.
- `execucao` (único): `projeto`, `chave`.
- `periodo` (não único): `projeto`, `solicitado_em`, `id`.
- `qualidade` (não único): `estado`, `solicitado_em`.

## f3base_meta_eventos

Guia: `docs/META-TRANSPORTE-1.19.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `evento` | `char(64)` | não | NULL | SHA-256 de event_name\|event_id; ligação com capi_fila.evento_hash, não identidade do visitante. | 1.19.0 |
| `nome` | `varchar(32)` | não | NULL | PageView ou Lead no catálogo equivalente do Core. | 1.19.0 |
| `criado_em` | `bigint` | não | NULL | Epoch UTC original do evento. | 1.19.0 |
| `rota` | `varchar(20)` | não | NULL | navegador, ambos ou servidor no evento Meta; em outras tabelas consulte a identidade editorial. | 1.19.0 |
| `navegador_observado` | `tinyint` | não | 0 | Disparo local observado; não é prova de recebimento remoto. | 1.19.0 |
| `classe_trafego` | `varchar(16)` | não | NULL | teste ou nao_marcado; coortes não são somadas implicitamente. | 1.19.0 |
| `atualizado_em` | `bigint` | não | NULL | Epoch UTC da atualização da observação local. | 1.19.0 |

Índices:

- `PRIMARY` (único): `evento`.
- `periodo` (não único): `criado_em`, `nome`, `rota`.

## f3base_execucoes

Guia: `docs/OPERACAO-GSC-1.20.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `run_id` | `varchar(64)` | não | NULL | UUID da passagem/tarefa Core; na coleta GSC conserva a correlação do serviço. | 1.20.0 |
| `parent_run_id` | `varchar(64)` | não |  | Vazio para passagem; UUID da passagem para subtarefa. | 1.20.0 |
| `origem` | `varchar(16)` | não | NULL | No diário: cli, http_cron ou manual; no GSC: automatico, manual ou legado_1190. | 1.20.0 |
| `entrada` | `varchar(24)` | não | NULL | Mecanismo de entrada, separado da origem observada. | 1.20.0 |
| `tarefa` | `varchar(64)` | não |  | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `hook` | `varchar(100)` | não |  | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `ocorrencia` | `char(64)` | sim | NULL | Hash único de gancho, argumentos e instante; NULL em execução explícita sem evento. | 1.20.0 |
| `inicio` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `fim` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `sucesso` | `tinyint` | sim | NULL | NULL sem prova de resultado; 0 falha e 1 confirmação no escopo registrado. | 1.20.0 |
| `codigo` | `varchar(100)` | não |  | Resultado resumido sem resposta bruta ou dados pessoais. | 1.20.0 |
| `core_examinado` | `tinyint` | não | 0 | Indica se a passagem examinou trabalho Core; CLI nativo vazio conserva false. | 1.20.0 |
| `dados` | `longtext` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |

Índices:

- `PRIMARY` (único): `id`.
- `run_id` (único): `run_id`.
- `ocorrencia` (único): `ocorrencia`.
- `origem_janela` (não único): `parent_run_id`, `origem`, `inicio`.
- `tarefas` (não único): `tarefa`, `inicio`.

## f3base_gsc_coletas

Guia: `docs/OPERACAO-GSC-1.20.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `id` | `char(32)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `universo` | `char(64)` | não | NULL | Hash de propriedade/pesquisa/escopo/filtros GSC; não somar universos incompatíveis. | 1.20.0 |
| `propriedade` | `varchar(250)` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `revision` | `varchar(128)` | não |  | Revisão da configuração do consumidor no momento da coleta. | 1.20.0 |
| `dia` | `date` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `origem` | `varchar(24)` | não | NULL | No diário: cli, http_cron ou manual; no GSC: automatico, manual ou legado_1190. | 1.20.0 |
| `pesquisa` | `varchar(16)` | não | web | Tipo de busca Search Console. | 1.20.0 |
| `escopo` | `varchar(16)` | não | paginas | paginas ou propriedade; totais são separados. | 1.20.0 |
| `filtros` | `text` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `estado` | `varchar(32)` | não | NULL | Estado próprio do recurso; não confundir captura, email e CRM. | 1.20.0 |
| `criado_em` | `bigint unsigned` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `atualizado_em` | `bigint unsigned` | não | NULL | Atualização técnica, epoch UTC na fila; datetime UTC no lead. | 1.20.0 |
| `extraido_em` | `bigint unsigned` | não | 0 | Epoch UTC da fotografia externa; fotografia antiga/parcial não sobrescreve final mais recente. | 1.20.0 |
| `publicado` | `tinyint` | não | 0 | 1 para fotografia atualmente projetada do universo/dia; versões anteriores preservadas. | 1.20.0 |
| `cursor` | `text` | não | NULL | Cursor opaco vinculado e temporário do SDK; não exportado pela ability. | 1.20.0 |
| `limite` | `int unsigned` | não | 1000 | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `paginas` | `int unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `linhas` | `int unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `cobertura` | `longtext` | não | NULL | JSON com completa/truncada/limite_linhas e observação da fonte autorizada. | 1.20.0 |
| `recibos` | `longtext` | não | NULL | JSON com request_id, run_id, connection_id, cobertura e extração por página. | 1.20.0 |
| `run_id` | `varchar(100)` | não |  | UUID da passagem/tarefa Core; na coleta GSC conserva a correlação do serviço. | 1.20.0 |
| `connection_id` | `varchar(100)` | não |  | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `codigo` | `varchar(100)` | não |  | Resultado resumido sem resposta bruta ou dados pessoais. | 1.20.0 |
| `proxima_tentativa` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.20.0 |

Índices:

- `PRIMARY` (único): `id`.
- `universo_dia` (não único): `universo`, `dia`, `publicado`.
- `fila` (não único): `estado`, `proxima_tentativa`, `criado_em`.
- `historico` (não único): `propriedade`, `dia`, `criado_em`.

## f3base_gsc_linhas

Guia: `docs/OPERACAO-GSC-1.20.md`.

| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |
|---|---|---|---|---|---|
| `coleta_id` | `char(32)` | não | NULL | Identificador da fotografia em f3base_gsc_coletas. | 1.20.0 |
| `chave` | `char(64)` | não | NULL | SHA-256 da identidade do recibo/entrega; não representa visitante. | 1.20.0 |
| `url` | `text` | não | NULL | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `post_id` | `bigint unsigned` | não | 0 | Campo técnico; consultar o serviço responsável. | 1.20.0 |
| `classe` | `varchar(24)` | não | fora_do_site | pagina, artigo, outro, nao_mapeado, fora_do_site ou propriedade. | 1.20.0 |
| `cliques` | `double` | não | NULL | Cliques agregados no universo Search Console quando nessa tabela. | 1.20.0 |
| `impressoes` | `double` | não | NULL | Impressões agregadas; denominador de CTR e peso da posição. | 1.20.0 |
| `posicao` | `double` | não | NULL | Posição média fornecida; agrega com peso de impressões. | 1.20.0 |

Índices:

- `PRIMARY` (único): `coleta_id`, `chave`.
- `conteudo` (não único): `post_id`, `coleta_id`.

## Campos JSON

Contratos completos também em dados/contrato.json. Snapshot comercial e audiência têm escopos diferentes; não inferir atribuição ausente.

```json
{
  "atribuicao.utm_source": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.utm_medium": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.utm_campaign": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.utm_content": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.utm_term": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.utm_id": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.utm_source_platform": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.f3_ads_v": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.f3_ads_account_id": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.f3_ads_group_id": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.f3_ads_group_type": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.li_fat_id": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.f3_ads_group_name": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.f3_ads_ad_name": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.f3_ads_placement": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.gclid": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.gbraid": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.wbraid": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "atribuicao.fbclid": {
    "tipo": "string",
    "limite_caracteres": 500,
    "ausente": "",
    "origem": "URL declarada, sem inferir identidade pelo clique"
  },
  "leads.dados.contexto": {
    "tipo": "object",
    "descricao": "IP/origem técnica, UA, post_id, versão, motivo da ausência de sessão e superfície quando disponíveis; não usar para fundir sessões"
  },
  "leads.dados.campos": {
    "tipo": "object",
    "descricao": "Valores do formulário por nome; contém dados pessoais e respostas livres, não são dimensões do relatório"
  },
  "leads.dados.campos_snapshot": {
    "tipo": "array",
    "descricao": "Nomes, rótulos e tipos da definição na captura"
  },
  "leads.dados.campos_relatorio": {
    "tipo": "array",
    "descricao": "Definições de opções fechadas na captura; preserva interpretação histórica"
  },
  "leads.dados.formulario_revisao": {
    "tipo": "string",
    "descricao": "Hash da revisão do formulário"
  },
  "leads.dados.navegacao": {
    "tipo": "string",
    "descricao": "Carregamento que gerou contato; pode faltar"
  },
  "leads.dados.contexto_teste": {
    "tipo": "boolean",
    "descricao": "Marca durável no instante da captura; não é consentimento"
  },
  "atribuicao.modelo": {
    "tipo": "string",
    "valores": [
      "sessao",
      "primeiro-toque",
      "ultimo-toque",
      "informado"
    ]
  },
  "atribuicao.plataforma": {
    "tipo": "string",
    "valores": [
      "meta_ads",
      "google_ads",
      "linkedin_ads",
      "nao_identificada"
    ]
  },
  "atribuicao.cobertura": {
    "tipo": "string",
    "valores": [
      "anuncio",
      "campanha",
      "parcial"
    ]
  },
  "atribuicao.referrer": {
    "tipo": "string",
    "descricao": "Somente host externo; não guarda query de origem"
  },
  "atribuicao.primeiro_toque_em": {
    "tipo": "string",
    "unidade": "epoch segundos; vazio quando desconhecido"
  },
  "atribuicao.ultimo_toque_em": {
    "tipo": "string",
    "unidade": "epoch segundos; vazio quando desconhecido"
  },
  "atribuicao.primeiro_toque": {
    "tipo": "object",
    "descricao": "Snapshot de um nível do mesmo contrato, sem recursão"
  },
  "atribuicao.ultimo_toque": {
    "tipo": "object",
    "descricao": "Snapshot de um nível do mesmo contrato, sem recursão"
  },
  "atribuicao.sessao_origem": {
    "tipo": "object",
    "descricao": "Parâmetros observados no URL/contexto corrente; não inventa histórico"
  },
  "atribuicao.anuncio_id": {
    "tipo": "string",
    "descricao": "utm_content somente quando f3_ads_v=1; caso contrário vazio"
  },
  "atribuicao.conta_id": {
    "tipo": "string",
    "descricao": "f3_ads_account_id"
  },
  "atribuicao.campanha_id": {
    "tipo": "string",
    "descricao": "utm_id"
  },
  "atribuicao.grupo_id": {
    "tipo": "string",
    "descricao": "f3_ads_group_id"
  },
  "atribuicao.superficie_anuncio": {
    "tipo": "string",
    "descricao": "instagram/facebook/audience_network/messenger quando utm_source declara ig/fb/an/msg; vazio caso contrário"
  },
  "oppref": {
    "tipo": "string opaca",
    "limite_bytes": 8192,
    "normalizacao": "sem lowercase, sem truncamento; URL decodificada uma vez no navegador",
    "permissao": "medicao e publicidade",
    "crm": "não é enviado ao Pipedrive"
  }
}
```
