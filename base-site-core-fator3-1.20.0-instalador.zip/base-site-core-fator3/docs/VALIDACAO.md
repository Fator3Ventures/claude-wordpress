# Validação — Fator3 Site Core 1.20.0

Data: 01/10/2026. Base exclusiva: WordPress novo ou 1.19.0 saudável/incompleta. Contrato Core 5.0.0. WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP-CLI 2.12.0 e Chromium 154/Playwright em ambiente isolado.

**387 asserções aprovadas** nos conjuntos abaixo. São asserções, não cenários independentes. Instalação/atualização verificada separadamente em 12 etapas, cobrindo três origens; o fechamento exige repetir essas etapas com o ZIP final e conferir seu SHA-256. A evidência final acompanha o fonte. Nenhuma correção SQL manual é exigida do operador; injeções de falha e fixtures pertencem só à suíte.

| Conjunto | Asserções | Evidência |
|---|---:|---|
| Snapshots GSC, migração CAPI, instalação e recuperação | 32 | `regressoes.json` |
| Falha de estrutura, retomada, origem e calendário | 14 | `recuperacao.json` |
| Contratos, listas vazias, GTM/GA4/Meta e navegação sem usuário | 115 | `regressoes-preservadas.json` |
| Commit, projeção anterior, filtros, métricas e revisão | 8 | `gsc-falhas.json` |
| Diário indisponível, relógio futuro, sentinela e fuso | 4 | `limites-operacao.json` |
| MCP 0.15.0 real, provider, perfis e capabilities | 15 | `mcp.json` |
| SDK real na primeira ordem de carga | 3 | `google-ordem-inicial.json` |
| SDK real na ordem inversa | 3 | `google-ordem.json` |
| WP-CLI real, contexto WP-Cron, argumentos e concorrência | 14 | `cron.json` |
| Documentos instalados, schemas, paginação e autorização | 142 | `documentacao.json` |
| Interfaces desktop/celular, filtros e ausência de erro JS | 25 | `ui.json` |
| Google 0.7.0 real, concessões, conexão efetiva e usuário zero | 12 | `google-mcp.json` |

Sintaxe: 169 arquivos PHP e 26 JavaScript sem erro. Scripts de frontend mantidos, sem nova biblioteca pública. Telas inspecionadas em 1440 e 390 px; tabelas extensas têm rolagem interna. Docs gerados das declarações e do schema MySQL, sem valores configurados ou credenciais. `documentacao.json` confere também os input schemas instalados.

`pacote.json` no fonte registra CRC, manifesto, comparação byte a byte e reprodução determinística do instalador. `instalacao.json` registra o hash efetivamente instalado. O relatório externo contém o hash de ambos os ZIPs; a cópia interna ao fonte contém somente o hash do instalador, para evitar autorreferência.

## Limites e homologação no destino

A implementação foi validada localmente. Não acessamos a frota nem korvena.net.br, não publicamos no GitHub e não alteramos tema, implantador, MCP ou MCP Google. Não houve envio de mensagens, leads ou conversões reais. Somente cópias locais dos complementos receberam configuração sintética.

Permanece homologação operacional: autorizar a propriedade real `sc-domain:fator3.com.br`, conferir atualização até D-3 quando disponível e autoria Core em `google/audit`; observar o cron externo por duas horas sem visitas; conferir permissões e compartilhamento dos arquivos de recuperação entre PHP web e CLI da hospedagem. Passagem CLI recente é evidência de execução, não prova do crontab.

A API Google remota foi simulada; o SDK/guard/registro e MCP são os pacotes reais. Não foram realizados ensaios reais de quota/429, revogação/expiração remota, transição de instalação Google 0.6 em voo, drenagem de trabalhador encerrado à força ou mudança de horário de verão. Concorrência foi ensaiada com dois processos CLI; a passagem HTTP foi ensaiada em processo PHP com contexto `DOING_CRON`, reschedule/unschedule e hooks reais, não por um disparo HTTP externo de wp-cron.php. O teste específico de confirmação SQL MCP diante de atividade alheia não foi refeito nesta entrega; não alteramos esse mecanismo do MCP.

Cache PHP, concessões que seguem o arquivo novo e resposta 410 mantêm o código da base; sua suíte completa da 1.19 não foi repetida. O acervo Clarity conserva sua implementação e agora compartilha o orçamento do executor; a coleta por vários dias e o custo de volume em produção exigem observação no destino. Não há promessa de todas as linhas existentes no Google, de recuperação de logs perdidos ou de medir citações/recomendações de IA.
