# Documentação instalada — Fator3 Site Core 1.20.0

Este acervo acompanha o instalador em `wp-content/plugins/base-site-core-fator3/docs/`. O agente pode ler arquivos ou usar `f3base/documentacao-ler` autenticado: sem argumentos retorna o índice; `arquivo`, `linha` e `limite` paginam até 200 linhas e retornam SHA-256 e próxima linha. O schema instalado é a fonte dos parâmetros aceitos. A proteção HTTP distribuída exige Apache/AllowOverride compatível; Nginx precisa de regra equivalente da hospedagem.

| Arquivo | Uso |
|---|---|
| OPERACAO-GSC-1.20.md | Guia atual: instalação, GSC, executor, diário e recuperação |
| IMPACTO-1.20-GOOGLE.md / IMPACTO-1.20-MCP.md | Contratos de convivência e recomendações aos outros plugins |
| README.md | Instalação nova ou 1.19 → 1.20, recursos e limites |
| INSTRUCOES-DO-PLUGIN.md | Roteiro de agente, marca de teste e operações |
| CONFIGURACAO.md | Sub-abas, herança, menu, permissões e defaults |
| AJUDA-OPCOES.md | Ajuda por opção/campo: funcionamento, escolha, vantagens, limitações e exemplo |
| dados/ajuda-opcoes.json | Mesma ajuda e schemas em formato estruturado |
| CONTRACTS.md | Contratos e semântica de erros/retentativas |
| REFERENCIA-CATALOGO.md | Declarações de opções, módulos e abilities |
| AGENTES-1.19.md | Exemplos de operação, perfil e verificação |
| AGENTES-E-BUSCADORES.md | Famílias, frequência, horas e cobertura dos logs |
| LEADS-E-FORMULARIOS.md | Captura, e-mail, papéis, anexos e telas |
| PIPEDRIVE.md | Configuração, dados enviados, fila, reenvio e eliminação |
| ORIGENS-ANUNCIOS.md | Meta, Google, reconciliação, LinkedIn e OpenAI |
| CRUZAMENTOS-PUBLICIDADE.md | Atribuição web e cruzamento com contas de anúncios |
| DICIONARIO-DADOS.md | Relações e significado dos dados |
| dados/contrato.json | Colunas, índices e contrato de dados 5.0.0 |
| CONSULTAS-EXEMPLO.sql | SELECTs para análises, sem escrita direta |
| RELATORIOS.md / METRICAS.md | Telas, filtros, fórmulas e limites |
| OFERTAS.md | Ofertas, prova de preço/período e emissão |
| OPERACAO-E-RECUPERACAO.md | Cron, cache e LLMS; recuperação atual em OPERACAO-GSC-1.20.md |
| perfis/piso-padrao-3.2.json | Perfil atual, revisão 2026-10-01-core-1.19.0, somente leitura |
| VALIDACAO.md | Evidências locais desta versão e homologações externas |
| MAPA-ENTREGA-1.20.md | Pedidos 102–106, código, evidências e limites |
| dados/origens-ia.json / dados/robos-catalogo.json | Catálogos, fontes e limites de classificação |
| CHANGELOG.md | Histórico das versões |

O contrato de configuração tem conteúdo **5.0.0**; o nome da ability `config-core-contrato-v1` permanece por ser o identificador do serviço. Consulte a versão do conteúdo. Não use documentos antigos para preencher valores ou contornar recusas. Documentos e diagnósticos não contêm credenciais. Dados de contatos exigem capability própria; não publique exportações de leads, mensagens ou caminhos privados.

## Guias da versão atual

- MEDICAO-1.19.md: contrato completo de conteúdo, sessões, aquisição, IA, retenção, referências e GSC.
- ANALISAR-CONTEUDO-ORGANICO.md: fluxo reproduzível conteúdo → origem → sessão.
- ANALISAR-PRESENCA-IA.md: robôs, referências, limites de rede e de atribuição.

O conteúdo do contrato de configuração é 5.0.0. A versão de dados também é 5.0.0; o schema de leads é 5. Estados operacionais e projeções derivadas são somente leitura. A materialização de defaults não exige escrever f3base_nav_id. Configuração antiga fora do contrato é preservada com diagnóstico, sem bloquear defaults de outras opções; exige correção administrativa explícita.

## Guias novos da 1.19

- RELEASE-1.19.md — instalação, operação, MCP, métricas e limites.
- DELTA-1.19.md — mudanças por site: banco, options, cache, cron e recuperação.
- META-TRANSPORTE-1.19.md — modos, retenção, evidência e homologação.
- CLARITY-1.19.md — acervo completo sanitizado, cotas, consultas, comparação e gravações.
- ARQUIVOS-PRIVADOS-1.19.md — cadastro/importação/substituição e formulários.
- OFERTAS-MEDICAO.md — marcação do tema, eventos, frequência e funil.
- dados/abilities-*.json — schemas e metadados das abilities instaladas.

## Precedência da 1.20

OPERACAO-GSC-1.20.md substitui as instruções anteriores de atualização, agenda, recuperação e importação GSC. Documentos com 1.19 no nome registram a entrega anterior e os recursos que permanecem; não são instrução de downgrade. A release atual usa somente instalação nova ou base 1.19.0.
