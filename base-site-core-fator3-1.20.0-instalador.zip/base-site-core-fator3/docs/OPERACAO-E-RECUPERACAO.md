# Orientação vigente da 1.20.0

Para instalação, cron, histórico, GSC e recuperação, prevalece [OPERACAO-GSC-1.20.md](OPERACAO-GSC-1.20.md). Base suportada: WordPress novo ou 1.19.0; contrato Core 5.0.0. As seções abaixo descrevem também recursos mantidos.

# Operação e recuperação — 1.20.0

## Instalação e atualização

Instalação nova requer ausência de opções e tabelas anteriores do Core. Cria o esquema atual diretamente, aplica política Todas, habilita gestão por agentes e prepara a pasta privada. Configurações sem recursos associados, como navegação, permanecem com o padrão não configurado do catálogo.

Na atualização, confirme a base 1.19.0, inclusive migração interrompida. O estado `f3base_release_1200` registra origem, defaults preenchidos, etapas e conclusão. Políticas Todas/Nenhuma/Selecionadas, listas vazias, interruptor desligado e destinatários existentes permanecem. Nenhum default é reaplicado sobre escolhas explícitas. Não há fluxo anterior à 1.19.0.

A trava evita duas atualizações concorrentes; checkpoints permitem retomar interrupções. Conflito de política impede sobrescrita. Versão anterior à base ou origem não comprovada interrompe o fluxo antes das transformações. Não há cadeia de instaladores/importadores históricos.

Confira estado concluído, pasta privada, um envio novo e saúde após instalar. Mantenha backup restaurável do banco, arquivos privados e código. Homologação de SMTP, infraestrutura e canal MCP deve ocorrer no ambiente de destino.

## Pasta privada

O caminho padrão é um diretório irmão da raiz WordPress: `f3-privado-` seguido de hash estável de ABSPATH. Instalações cujo pai também seja público precisam declarar `F3BASE_ARQUIVOS_PRIVADOS` no `wp-config.php`, apontando para uma pasta fora da raiz pública. O diretório pai deve existir e permitir criação/escrita. O caminho não depende do diretório de trabalho do CLI.

O teste de preparação cria um arquivo aleatório, grava, lê, confere, aplica permissão e remove. O diagnóstico distingue `pronto`, `ausente_criavel`, `sem_permissao`, `dentro_da_raiz_publica`, `caminho_invalido`, `espaco_insuficiente` e falha de teste. A leitura do diagnóstico não cria a pasta.

A exclusão das raízes públicas conhecidas não prova ausência de aliases configurados no Apache/Nginx/proxy. A verificação de alias da hospedagem permanece explicitamente pendente até conferência naquele ambiente. Não publique o diretório por alias. Use a ability de preparação após corrigir permissões/caminho.

## Cache

A rotina já usada para `cache.tokens` também pede por HTTP um artefato existente e elegível em `wp-content/cache/`: `index.html`, `index-https.html` e arquivos `wp-cache-<hash>.php` no diretório do site fornecido pelo WP Super Cache. Em modo com cabeçalhos preservados, os arquivos PHP têm preferência. Não executa PHP do cache, não segue redirecionamentos e não consulta corpos privados. A evidência fica em `artefato_cache`, junto da tentativa durável e do último sucesso.

Sucesso exige resposta completa de zero bytes com HTTP 200, 403, 404 ou 410. Corpo HTML de erro não atende esse aceite. Corpo igual ao hash do arquivo é exposição efetiva. Resposta 5xx, 429, redirecionamento, corpo truncado ou erro de rede deixa a prova pendente. Sem artefato elegível/WP Super Cache compatível não há prova de proteção; o diagnóstico permanece inconclusivo.

A sonda usa a cadência e a trava existentes. Leitura de saúde não faz uma nova requisição HTTP. Prova antiga sem o novo campo não certifica acesso direto. HIT por disco/cabeçalho continua uma prova separada da proteção do diretório.

## Métricas após load

A versão vendorizada conferida é Web Vitals 6.2.1, já minificada na 1.11.0 (11.093 bytes). O Core remove o enqueue antecipado e carrega a biblioteca assincronamente após `window.load`, respeitando a permissão de medição. Se o tracking for iniciado depois do load, agenda o carregamento imediatamente para a próxima tarefa.

Um observador mínimo guarda interações curtas antes da biblioteca ficar pronta; um patch local faz a transferência sem duplicar entradas do buffer nativo. O relógio do primeiro ocultamento é preservado e coletores iniciados numa página já oculta escoam entradas pendentes. A correção local de máximo de CLS entre janelas permanece. Inicialização duplicada é evitada.

A retenção antecipada é limitada a 2.000 entradas. Em excesso, INP não é relatado como valor parcial; a condição fica em `window.f3baseVitaisAntecipados.overflow`. Falha de rede marca `erro`. Navegação encerrada antes do load/carga da biblioteca pode não produzir métricas: não há como prometer coleta completa depois que o documento deixa de executar. Não são fabricados zeros. bfcache e cobertura em navegadores reais precisam do aceite específico descrito em VALIDACAO.md. Não se alega melhora na nota PageSpeed sem ensaio comparável.

## Publicação e regras do servidor

Uma geração LLMS é preparada em lotes limitados, com cursor, assinatura, trava e próxima tentativa. A geração publicada continua disponível durante edição/purga ordinária; só é substituída depois da preparação completa. Conteúdo privado, com senha, excluído ou noindex é retirado prioritariamente. Uma representação incompleta recebe motivo e alternativa HTML, sem impedir a publicação parcial útil; os detalhes da 1.18 estão abaixo. Sites de pouco tráfego precisam de cron efetivo.

`servidor-aplicar` consulta sem escrever; aplicar/remover exige revisão e capability. O bloco `F3BASE MANAGED` modifica apenas cabeçalhos de llms.txt e, se configurado, Options -Indexes. Backup privado contém bytes anteriores e hashes; arquivo de recuperação CLI é criado antes da escrita. Nada é aplicado na ativação. O teste compara home e sonda PHP dinâmica antes/depois, GET/HEAD identity/gzip, ETag ou Last-Modified/304, corpo e indexação. 500 após escrita tenta restauração somente sobre o hash aplicado. Conflito preserva evidência e exige recuperação dirigida. Nginx não recebe regras Apache.

Padrão de `bloquear_listagem`: false. A preferência ligada exige aplicar e confirmar o teste de um diretório aleatório com arquivo público de controle. O teste não lê arquivos privados. Documentos do plugin já têm proteção própria em docs/ e dados/, inclusive com plugin desativado. Arquivos oficiais antigos da raiz são retirados só quando o hash coincide; cópias locais modificadas são preservadas e diagnosticadas, exigindo mover/proteger antes de homologar aquela instalação.

O cache WP Super Cache precisa ignorar os parâmetros de publicidade declarados e excluir rotas técnicas/de teste. A leitura de saúde não altera wp-cache-config.php. Use a lista atual fornecida pelo diagnóstico, compare personalizações, aplique apenas o delta e prove HIT/MISS e proteção direta. Nunca use dados de visitante no HTML compartilhado.

## Recuperação na própria 1.20

Só são suportadas instalação nova e atualização da 1.19.0. Repetir a instalação atual é idempotente. Não há caminho de downgrade nem obrigação de manter o binário antigo funcionando após esta atualização.

Antes de restaurar banco, prepare e drene o Core usando a sentinela externa, conforme OPERACAO-GSC-1.20.md; preserve essa sentinela durante o restore. Retome somente depois de reconciliar efeitos externos. Em incidente, preserve contatos, anexos, filas e recibos atuais. Recupere arquivos/configurações de forma dirigida e condicional, sem restaurar banco antigo sobre novas capturas. Não apague marcadores para forçar migração. Segredos indecifráveis exigem recadastro na própria versão; não use fallback em texto aberto.

A atualização registra checkpoints, prepara o esquema editorial e a raiz privada e completa somente novos defaults ausentes. Normaliza a fila CAPI sem reenvio; escolhas válidas permanecem. Uma cópia só é retirada depois da confirmação dos bytes. Se a pasta privada não puder ser preparada, corrija a causa e execute o provisionamento autenticado; não prometa privacidade por um caminho apenas salvo.

Desinstalação preserva acervo. Ativar Pipedrive não envia o histórico anterior: somente novas intenções elegíveis são reconciliadas. Desligar o módulo interrompe novos despachos; não apaga o que já existe no CRM. Antes de exclusão remota, leia os estados independentes em PIPEDRIVE.md.

## Antes da implantação em cada site

Registre host real, versões, UTC, snapshot e revisões. Confirme publicadores XML-RPC (incluindo Indexe, quando usado), acesso REST/MCP/editor, SMTP em caixa autorizada, raiz privada/aliases, WPSC, tema e exceções existentes. Teste envio com marca, atendimento, CSV, redirects com query, FAQ/autoria/oferta pública, menu/CTA, consentimento claro/escuro e HTTP dos documentos. Remova compensações do tema somente depois da prova equivalente. Não altere campanhas comerciais ou filtros GA4 definitivos implicitamente.

Mudanças de medição devem ter corte UTC por site, regra/versão, n e cobertura. Antes/depois da frota mede o conjunto de alterações, sem atribuir causalidade isolada a gtag.js. Os cinco 503 históricos precisam de HAR/log correlacionado para determinar a origem; o teste local de falha não prova a causa em produção.


## Procedência de ofertas

A base admitida é a 1.18.0 concluída. A 1.19 preserva as ofertas e sua procedência existente; não reconverte ofertas históricas. Listas vazias e alterações locais posteriores permanecem. Sem evidência suficiente, a classificação fica pendente; não inventar autoria.

## TTL e análise

`ttl_configurado_segundos` não é garantia de idade. No WP Super Cache em `wp-cache-cabecalhos`, a entrega depende da coleta `wp_cache_gc`; cron agendado pode atrasar. O diagnóstico distingue teto não garantido, coleta ausente/atrasada, relação com `ttl_token()` e proxy desconhecido. Idade observada exige `filemtime` do arquivo exato vinculado ao HIT; sem esse vínculo é indeterminada. A versão não altera o TTL do provedor.

Antes de POST, o cliente comum renova token vencido/próximo do vencimento; consumidores concorrentes compartilham a renovação. Análise captura imediatamente e inicia transporte regular 5 segundos após load, com prazo que não é adiado por novos eventos. Ocultar/sair antecipa a descarga; erro conserva IDs, sequência, horário e classe na fila limitada. Lead/formulário funcional não espera esse prazo. Fechamento abrupto, falta de rede e expiração da fila ainda podem causar perda. Não há promessa de coleta perfeita nem de ganho universal no PSI.

## Verificação de redirects

Retome `proximo_cursor` até cobrir todas as origens e variantes. Consultas, horários e contadores não alteram o contexto; mudanças de regras/hosts/permalinks ou destinos e âncoras pertinentes invalidam com motivo. Provas vencem individualmente. A execução guarda contexto e `execucao_id`; gravação usa o estado mais recente e revisão condicional. `verified` exige cobertura integral, sem substituir timeout por sucesso. Sondas locais são marcadas, sem parâmetro de bypass. R30 não muda exclusões do WP Super Cache nem exige purga por visitante.


## Executor de integrações

O cron agenda Pipedrive após captura e tenta loopback não bloqueante quando permitido. Com `DISABLE_WP_CRON`, um executor externo deve disparar WP-Cron. Meta usa sua cadência de cinco minutos e lotes com orçamento; falhas preservam cursor. Google webhook é imediato; reconciliação precisa de produtor externo. Abrir o painel ou ler saúde não executa essas filas. Verifique próxima execução, início real, erro e último lote completo. Latência p50/p95 exclui testes e informa tamanho/limite da amostra; não é promessa de SLA.

Os tokens cifrados usam salts do WordPress. Um backup apenas do banco não permite recuperar o segredo sem a chave; backup completo e operador com execução PHP podem decifrar. Não inclua tokens em logs. Troca de salts, corrupção, falta de Sodium ou permissão de conta suspendem a integração afetada; a captura local continua.

## Ajustes operacionais da 1.18

LLMS processa itens individualmente: uma representação incompleta permanece com alternativa HTML e cobertura; não bloqueia os itens válidos. Markdown ainda não preparado retorna 503 e link HTML; Retry-After somente com trabalho agendado. Representação avaliada e incompleta retorna 404, sem Retry-After: não há representação Markdown publicável, e o HTML permanece disponível. Nenhuma conversão síncrona ocorre no acesso público. Retentativas de falha de publicação são limitadas a cinco; alteração de contexto ou llms-reprocessar permite nova tentativa. Geração publicada anterior é preservada durante preparo e itens sem elegibilidade pública deixam de ser servidos.

Robots conserva modo original observado (por exemplo, 0644) separado da reserva privada 0600. Restaurar publica uma cópia conferida, não o inode privado. Estado antigo 0600 sem modo público demonstrado recebe restauração pública 0644 com procedência indicada. Arquivo alterado externamente é preservado. Reativação explícita tenta reconciliação/verificação na operação, sem depender de próxima visita.

Ofertas, catálogo/rollup editorial e listas oficiais fazem parte de executar-pendentes. Confira prazo, atraso e último avanço. Redirects dependem de pares, destinos/âncoras e configuração pertinente; uma edição sem relação não invalida toda prova. Mudança pertinente exige nova verificação.

Navegação separa referência válida, associação, declaração do tema e prova pública. Use o botão Verificar cabeçalho público ou navegacao-verificar. Inspeciona somente header semântico fora de main/article, reconhece ref final e inline, vale por um dia e pelo contexto. Ausência de header/marca não é prova de uso; não modifica tema.

Consentimento possui painel padrao/tema, aplicado antes da apresentação. Modo tema preserva controles/foco e delega moldura/layout. Tema deve fornecer estilos adequados; o Core não infere intenção a partir de CSS. Diagnóstico TTL só alerta quando há ação; descrição schema informa o escopo realmente atendido.


## Reconciliação dos logs na 1.18

Antes de publicar fontes reprocessadas, o Core identifica os dias antigos conectados pelas mesmas fontes. Os agregados diários e horários anteriores desse componente são copiados para `f3base_acessos_legado` e retirados das tabelas de totais na mesma transação. Um recibo de contagem zero é confirmado na mesma transação; ao retomar com um estado de execução antigo, impede arquivar novamente os totais atuais. A publicação dos dias novos pode então prosseguir. A retenção do arquivo acompanha a dos logs diários; não contém IP individual.

`f3base_acessos_estado.reconciliacao` conserva as dependências por dia. Fonte perdida mantém `lacuna_irrecuperavel`; ausência não vira zero. O arquivo é consultável por `f3base/acessos-legado-ler`, separado do painel padrão. **Não some esse arquivo aos agregados atuais:** contém versões/calendários potencialmente sobrepostos. Se a fonte reaparecer, a coleta pode recompor o dia e reavaliar sua cobertura.

O catálogo repara aliases inválidos em lotes de até 100 registros, orçamento de três segundos e cursor retomável. Templates de Elementor não são conteúdo editorial; queries estruturais recebem chave própria. Rotas comprovadamente erradas recebem `fim=inicio` e procedência `alias_invalido_1170`; novas rotas começam quando observadas. A versão não preenche IDs históricos por suposição. O executor continua necessário para concluir os lotes.


## Novos acervos e retomada 1.19

`f3base_release_1200` registra origem, início, defaults materializados e conclusão. Se incompleto, corrija a causa (`schema_pendente`, pasta privada ou conflito informado) e repita a atualização na mesma versão. Não remova o marcador nem restaure banco anterior sobre contatos novos. A fila 1.18 pendente é cifrada em lotes antes da conclusão; prazo original não se amplia. Guarde banco, pasta privada e salts no backup operacional protegido: perder os salts pode tornar credenciais/fila indecifráveis.

Clarity guarda a resposta analítica sanitizada antes da normalização. Falha de normalização permite `clarity-reprocessar` sem API. O journal privado permite retomar falha de persistência. `clarity-exportar`/`clarity-restaurar` preservam hash e metadados; restauração não inventa lacunas. Falha de espaço é diagnóstico, não autorização para apagar acervo. Retenção Clarity padrão zero significa sem expiração automática, independente da retenção editorial. Uma pausa superior à janela disponível da API pode deixar lacuna irrecuperável; consultar depois não recompõe dados que a fonte já não oferece.

Payloads Meta ficam cifrados somente enquanto há entrega útil dentro do prazo. Retentativa não renova expiração; terminal/expirado remove payload. Sem cron, limpeza atrasa e o diagnóstico informa o agendamento. Recadastro/rotação de credencial suspende prova antiga de modo servidor. Reconciliar eventos por hash e conferir a conta autorizada antes de reativar esse modo. Não usar SQL para contornar a prova.

Arquivos privados têm ID estável e blobs imutáveis. Troca exige revisão/hash esperado; concessões vigentes acompanham a versão publicada. Uma falha antes da publicação conserva o ponteiro anterior; repita com a mesma chave idempotente e consulte o resultado. Não troque arquivos físicos à mão. Blobs retirados só são limpos pela rotina própria após o prazo e a verificação de referências.

A desativação cancela os novos agendamentos Clarity/navegação; reativação retoma o executor. Acervo local e histórico são preservados. Guias específicos: RELEASE-1.19.md, META-TRANSPORTE-1.19.md, CLARITY-1.19.md e ARQUIVOS-PRIVADOS-1.19.md.
