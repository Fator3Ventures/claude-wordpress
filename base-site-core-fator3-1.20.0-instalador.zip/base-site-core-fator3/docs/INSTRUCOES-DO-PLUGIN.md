# Orientação vigente da 1.20.0

Para instalação, cron, histórico, GSC e recuperação, prevalece [OPERACAO-GSC-1.20.md](OPERACAO-GSC-1.20.md). Base suportada: WordPress novo ou 1.19.0; contrato Core 5.0.0. As seções abaixo descrevem também recursos mantidos.

# Instruções para agentes — Core 1.20.0

1. Leia DOCUMENTACAO.md e o schema da ability antes de operar. Confirme host, versão, capabilities, revisão e política efetiva. Não infira o tipo de menu ou conteúdo apenas por um ID numérico.
2. Antes de navegar/testar a página pública, visite `/f3base-teste/` na mesma origem e no mesmo navegador; confira “Modo de teste ativo”. O cookie dura uma hora, usa o caminho público do site e não atravessa hosts/clientes. A página é privada, sem cache e sem indexação. `?sair=1` remove a marca. A cada nova visita confira a marca; cookie não é credencial nem substitui login/consentimento.
3. Para HTTP técnico, envie `X-F3Base-Teste: 1`. `0` declara tráfego não marcado. No MCP, chamadas de controle autenticadas não são visitas públicas. Abilities que disparam sondas públicas aceitam `contexto_teste:true`; confira no schema. Marcação é propagada só à própria origem e preservada na tarefa/repetição correspondente. Um navegador aberto separadamente precisa do cookie. Não use IP ou horário do MCP para inferir visitas de agentes.
4. Nas capturas, a marca é congelada no evento/envio e na fila. Cabeçalho explícito e campo explícito incompatíveis são recusados antes de capturar. O cookie é fallback; não reclassifica uma fila antiga. Testes ficam no banco, fora dos relatórios comerciais por padrão. Use `segmento:somente_testes` para conferi-los.
5. Testes suprimem destinos externos e e-mail por padrão. A opção de marcar GA4 exige IDs próprios de homologação; GTM exige configuração explícita e confirmação das regras do contêiner. CAPI usa código de Test Events configurado; e-mail usa apenas caixas de teste configuradas. Google Ads, Meta Pixel e LinkedIn permanecem suprimidos para teste. Resposta ao visitante não é enviada em teste. Integrações de outros plugins não são controladas por esta marca.
6. Configuração: `config-core-contrato-v1` → `config-core-ler` → simular `config-core-escrever` → aplicar com revisão conferida → verificar. `persisted`, efeito e prova são resultados distintos. Conflito pede releitura e comparação; nunca altere a revisão sem verificar. Não contorne recusa com SQL.
7. Política do canal em Operação é independente dos valores configurados. `todas`, `selecionadas` e `nenhuma` são explícitos. Desligar gestão da política impede agentes de editar permissões, sem desligar MCP nem revogar por si só todas as opções. Valores false, zero e lista vazia não significam ausência.
8. Use DICIONARIO-DADOS.md, dados/contrato.json, METRICAS.md e SQL de exemplo para análise. Prefixo vem do WordPress, datas do fuso do site viram UTC, e a classe de tráfego faz parte da junção. Não deduza pessoas por sessão, IP ou e-mail. Registre versão/regra, intervalo, consulta e cobertura do relatório.
9. Publicação LLMS: confira preparo, cursor, total, erro e próxima tentativa. `saude-ler`/contrato efetivo mostram a tarefa llms; execute/aguarde pela operação disponível. Uma geração parcial não substitui a última publicação válida. Privado/noindex é retirado prioritariamente. Só confirme depois da geração concluída e da prova HTTP apropriada.
10. Servidor: consulte `servidor-aplicar`; aplicação/remoção exigem revisão e criam backup privado/caminho de recuperação. Não há escrita de .htaccess na ativação. Leia controles de home e PHP, identity/gzip, 304 e listagem. Pendente não é sucesso. Nunca exponha backups, tokens, mensagens de leads ou caminhos privados em relatórios públicos.
11. Redirecionamentos preservam parâmetros por padrão; destino vence em conflito. Host externo exige allowlist HTTPS explícita. A verificação confere origem, query, cadeia, destino final e âncora; autenticação/CAPTCHA/erro ficam inconclusivos. Não configure redirect só pela contagem bruta de acessos.
12. Não remova marcadores para repetir migração; não aplique banco antigo sobre registros novos. Pipedrive e origens nativas são opcionais: leia PIPEDRIVE.md e ORIGENS-ANUNCIOS.md. Não ative envio histórico nem habilite homologação em conta comercial sem escopo explícito.

A navegação comum não faz uma chamada extra para verificar o cookie. A carga adicional é leitura local e um campo nas capturas existentes. Nenhuma marca é escrita para visitantes normais. Logs brutos sem cookie/cabeçalho não podem ser filtrados retroativamente como se contivessem essa evidência.

Leia também AGENTES-1.19.md e OFERTAS.md. Use o piso `piso-padrao-3.2` pela revisão distribuída, sem aplicar valores automaticamente. Preserve as listas/folhas não tocadas, diagnostique caminhos inválidos antes de substituir listas e use respostas compactas quando não precisar do corpo de tokens. Para publicação de ofertas, configuração, evidência de conteúdo e emissão observada são estados separados.


13. Nesta versão, escreva `f3base_navegacao` com tipo explícito. Use `navegacao-listar` para descobrir IDs; `f3base_nav_id` é somente leitura derivada. Nenhum caminho atual tenta decidir menu clássico versus bloco pela coincidência de ID.
14. Para CRM, consulte `integracoes-ler`, `pipedrive-previa` e entregas por registro. `integracoes-verificar-agora` consulta a conta e atualiza catálogos; `pipedrive-processar` pode enviar contatos. Não confunda consulta com comando de efeito. Preservar a revisão em `pipedrive-reenviar` evita retomar uma fotografia antiga da fila.
15. `anuncios-google-reconciliar` recebe dados de um produtor autorizado: não consulta a Google Ads API. O executor precisa ser provisionado e monitorado. Na Meta, confira páginas/formulários, permissões, cursores e último lote completo. Em qualquer origem, teste é dado separado de tráfego comercial.
16. Não classifique Google-Extended como um visitante HTTP independente; a assinatura de User-Agent informa família declarada, não autentica o fornecedor. Leia cobertura antes de calcular frequência.
17. Não tente downgrade. Em incidente suspenda o módulo afetado, preserve acervo e filas, faça recuperação dirigida e repita o checkpoint na 1.20.0. Não altere tema ou implantador para fabricar conformidade do Core.


## Entrada da versão 1.20.0

Leia OPERACAO-GSC-1.20.md e o índice DOCUMENTACAO.md. Instalação exclusivamente nova ou a partir de 1.19.0, inclusive migração interrompida. Contrato 5.0.0; schema leads 5. O canal MCP 0.15.0 aplica perfil por conexão; Core conserva capabilities. Histórico Clarity e retenção transitória da fila Meta têm políticas separadas, documentadas nos guias específicos.
