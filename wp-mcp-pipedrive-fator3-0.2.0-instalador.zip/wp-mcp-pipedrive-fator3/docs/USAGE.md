# Uso — 0.2.0

Todos os exemplos são sintéticos. Substitua IDs apenas por registros autorizados. Leia o schema no catálogo; o transporte MCP pode acrescentar seus próprios campos de controle.

## Leitura e vazio

`pipedrive/status {}` não faz HTTP.

`pipedrive/api-ler {"caminho":"/v1/dealFields","query":{"limit":100,"start":0}}` consulta campos. Resultado: success, code, message e data com http_status, body e saldo_conta. Coleção vazia retorna data do fornecedor vazia; não é erro. Siga a paginação do fornecedor quando presente. Não interpretar saldo null como orçamento ilimitado.

## Atualizar campo personalizado de lead

Primeiro obtenha pelo catálogo a chave real do campo (o ID numérico 152 não substitui a chave de 40 hexadecimais) e os IDs de suas opções.

```json
{"metodo":"PATCH","caminho":"/v1/leads/00000000-0000-4000-8000-000000000001","corpo":{"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa":152}}
```

Enviar a `pipedrive/api-previa`. A resposta mostra estado_atual, corpo_a_enviar, previa_id, expira_em, custo_estimado e classe. Rever tudo. Enviar `pipedrive/api-aplicar {"previa_id":"ID_DEVOLVIDO"}`. Conferir GET do lead e `pipedrive/registro-ler {}`. Repetir o mesmo ID retorna o mesmo recibo dentro da retenção, enquanto usuário/conta/revisão permanecem autorizados; não envia outra chamada. A prévia pendente expira aos 15 minutos, inclusive igualdade no limite.

## Estrutura

Prévia de etiqueta:

```json
{"metodo":"POST","caminho":"/v1/leadLabels","corpo":{"name":"Teste pipedrive-operacao (apagar)","color":"blue"}}
```

Após a ordem do dono, chamar aplicar com previa_id e confirmacao copiados da resposta. A frase é `Confirmo por ordem do dono de DD/MM/AAAA: <resumo exato>`. Confirmacao é obrigatória também para DELETE de etiqueta/campo/filtro. Remover a etiqueta sintética pela mesma sequência DELETE com seu UUID.

Para opções de campo, enviar todas as que devem permanecer, com IDs e labels. Se uma existente for retirada, listar o ID em remover_opcoes. Omitir alguma por engano retorna opcao_seria_apagada, com opções afetadas; não envia PUT. Criar alternativa nova usa label sem id junto das existentes.

## Resultado incerto e erros

* caminho_fora_da_lista: URL absoluta, mailbox, ids em massa, merge, método ou chave não autorizada; zero chamadas.
* confirmacao_ausente: frase ausente ou diferente; zero mutações.
* previa_expirada, previa_de_outro_usuario, contexto_alterado ou estado_alterado: revisar e gerar outra prévia se não houve tentativa anterior.
* resultado_incerto: chamada em execução/interrompida, timeout, 5xx ou recibo não confirmado. Ler registro e consultar a entidade; não gerar outra prévia para repetir sem reconciliar o efeito.
* saldo_conta_baixo, operacao_nao_autorizada, core_em_recuperacao ou orcamento_esgotado: seguir o diagnóstico Core; não alterar filas de entrega.
* resposta_excedeu_limite: limite de 512 KiB. Reduzir paginação nas leituras. Se houve escrita, conferir por GET antes de qualquer nova ação.

Corpos remotos de erro não são expostos porque podem repetir entradas privadas. Não há retry automático. Uma recusa definitiva do fornecedor também produz recibo único; corrigir a entrada exige nova prévia. Código de falha não equivale a certeza de ausência de efeito: consultar remote_dispatched/applied, que podem ser null.

## Auditoria e REST

`pipedrive/registro-ler {"limite":50}` retorna itens e proximo_antes_id; usar esse valor em antes_id. Ordenação estável por id decrescente. O histórico não contém nome, e-mail, telefone, conteúdo de nota ou valor de campo pessoal. Mudanças de estrutura incluem apenas nomes/opções de estrutura.

REST: namespace `/wp-json/f3-pipedrive/v1/`. GET para status, registro-ler, documentacao-ler; POST com JSON para api-ler, api-previa, api-aplicar. Cookie administrativo exige nonce wp_rest; application passwords exigem HTTPS e capacidade administrativa. Respostas têm Cache-Control private, no-store.


## Configurar e verificar retenção

1. `pipedrive/retencao-ler {}`. Anote data.revisao e confira diario_dias.
2. Para conservar o diário permanentemente: `pipedrive/retencao-configurar {"diario_dias":0,"revisao_esperada":"HASH_LIDO"}`. Não há chamada ao fornecedor ou expurgo.
3. Para prazo finito deliberado de 730 dias: `{"diario_dias":730,"revisao_esperada":"HASH_LIDO","confirmar_expurgo":true}`. Linhas anteriores ao corte ficam elegíveis nas próximas limpezas, exceto tentativas incertas.
4. Leia retencao-ler e status novamente; confira persisted=true, política e revisão. Se houver revisao_conflitante, releia e reavalie a escolha antes de enviar nova revisão. Se o Core estiver desautorizado, status pode ter success=false e ainda trazer data.retencao; a configuração local continua disponível.

O diário permanente não prolonga validade de prévias, tokens, locks ou recibos. A linha técnica permanece após a expiração do recibo; ela não contém os valores pessoais da resposta privada cifrada.
