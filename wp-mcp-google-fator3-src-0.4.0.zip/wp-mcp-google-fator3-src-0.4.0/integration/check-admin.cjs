const {chromium} = require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const dir = path.resolve(process.argv[2]);
  const browser = await chromium.launch({headless: true, executablePath: process.env.F3_CHROMIUM || undefined, args: ['--no-sandbox']});
  const results = [];
  for (const width of [1360, 390]) {
    const page = await browser.newPage({viewport:{width,height:1000}});
    for (const name of ['service-account','oauth','services','diagnostics','advanced','first-setup']) {
      const errors=[]; page.on('pageerror', e=>errors.push(e.message));
      await page.goto('file://' + path.join(dir, name+'.html'));
      const structure=await page.evaluate(()=>{
        const ids=[...document.querySelectorAll('[id]')].map(x=>x.id);
        const duplicates=ids.filter((id,i)=>ids.indexOf(id)!==i);
        return {overflow:document.documentElement.scrollWidth>innerWidth+1,duplicate_ids:[...new Set(duplicates)],forms:document.querySelectorAll('form').length,main:document.querySelectorAll('main').length,nested_forms:document.querySelectorAll('form form').length};
      });
      if (structure.overflow||structure.duplicate_ids.length||structure.nested_forms||structure.main!==1||errors.length) throw Error(name+' '+width+' '+JSON.stringify({structure,errors}));
      await page.screenshot({path:path.join(dir, `${name}-${width}.png`),fullPage:true});
      results.push({name,width,...structure,errors});
    }
    await page.close();
  }
  const page=await browser.newPage({viewport:{width:1360,height:1000}});
  await page.goto('file://'+path.join(dir,'service-account.html'));
  if (await page.locator('[name=oauth_client_secret]').count()) throw Error('OAuth form in SA panel');
  await page.locator('[data-copy-target]').first().click();
  await page.waitForFunction(()=>document.querySelector('#f3-live').textContent.length>0);
  await page.getByText('Colar JSON ou ajustar delegação',{exact:true}).click();
  if (!await page.locator('#f3-sa-json').isVisible()) throw Error('JSON expander did not open');
  await page.goto('file://'+path.join(dir,'services.html'));
  await page.locator('#f3-service-ads').selectOption('read');
  if (!await page.locator('[name=ads_customer_id]').isVisible()||!await page.locator('[name=ads_customer_id]').isEnabled()) throw Error('Service field not enabled');
  await page.locator('#f3-service-ads').selectOption('');
  if (await page.locator('[name=ads_customer_id]').isEnabled()) throw Error('Hidden field submitted');
  const blankForm=await page.locator('form').first().evaluate(form=>new FormData(form).get('connection_id'));
  if (blankForm!=='default') throw Error('Wrong connection context');
  // New context deliberately avoids beforeunload dialogs from the edited form.
  const nojs=await browser.newPage({javaScriptEnabled:false,viewport:{width:390,height:900}});
  await nojs.goto('file://'+path.join(dir,'oauth.html'));
  if (!await nojs.getByRole('button',{name:'Conectar com Google',exact:true}).isVisible()&&!await nojs.getByRole('button',{name:'Autorizar novamente com Google',exact:true}).isVisible()) throw Error('No-JS OAuth action absent');
  await nojs.getByText('Informar Client ID e Client secret manualmente',{exact:true}).click();
  if (!await nojs.locator('[name=oauth_client_id]').isVisible()) throw Error('No-JS manual inputs inaccessible');
  const ctx=await browser.newPage({viewport:{width:1360,height:900}});
  await ctx.goto('file://'+path.join(dir,'first-setup.html'));
  await ctx.keyboard.press('Tab');
  if (await ctx.evaluate(()=>document.activeElement===document.body)) throw Error('Keyboard focus missing');
  fs.writeFileSync(path.join(dir,'browser-checks.json'),JSON.stringify({renderer:'synthetic WordPress shell; production PHP/CSS/JS',pages:results,interactions:['auth panel isolation','copy or accessible fallback','JSON disclosure','enable/disable service fields','connection context','no JavaScript','keyboard navigation']},null,2));
  await browser.close();
  console.log(JSON.stringify({pages:results.length,interactions:7,passed:true}));
})().catch(e=>{console.error(e);process.exit(1)});
