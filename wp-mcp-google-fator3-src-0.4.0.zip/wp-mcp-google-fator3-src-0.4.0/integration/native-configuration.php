<?php
/** Extends native-options.php with the 0.4 configuration transaction service. */
declare(strict_types=1);
ob_start(); require __DIR__ . '/native-options.php'; ob_end_clean();
define( 'F3_MCP_GOOGLE_VERSION', '0.4.0' );
function get_current_user_id() { return 1; }
foreach ( array( 'Response', 'Settings', 'Ability', 'Audit', 'Auth/Credentials' ) as $file ) { require $plugin . '/includes/' . $file . '.php'; }
use Fator3\McpGoogle\{Settings, Options, Connections, Lock};
$revision = Settings::revision();
verify( 'configuration_snapshot_readable', is_string( $revision ) );
$r = Settings::save( array( Settings::AUTH_READY => false ), array(), array(), $revision );
verify( 'configuration_first_false_created', $r['success'] && $r['changed'] && Options::stored( Settings::AUTH_READY )['exists'] );
verify( 'configuration_revision_changed', $revision !== $r['revision'] );
$revision = $r['revision']; $r = Settings::save( array( Settings::AUTH_READY => false ), array(), array(), $revision );
verify( 'configuration_same_false_no_change', $r['success'] && ! $r['changed'] && $r['revision'] === $revision );
$cipher = Options::stored( Options::OAUTH_CLIENT_SECRET )['value'];
$r = Settings::save( array(), array( Options::OAUTH_CLIENT_SECRET => 'dummy-native-secret' ) );
verify( 'configuration_equal_secret_preserves_cipher', $r['success'] && ! $r['changed'] && $cipher === Options::stored( Options::OAUTH_CLIENT_SECRET )['value'] );
$r = Settings::save( array( Options::HTTP_TIMEOUT => 45 ), array(), array(), 'stale' );
verify( 'configuration_stale_form_rejected', ! $r['success'] && 'f3_google_configuration_conflict' === $r['error_code'] && $revision === Settings::revision() );
$GLOBALS['wpdb']->fail_option = Options::HTTP_TIMEOUT;
$r = Settings::save( array( Options::OAUTH_EMAIL => 'candidate@example.test', Options::HTTP_TIMEOUT => 45 ), array(), array(), $revision );
$GLOBALS['wpdb']->fail_option = '';
verify( 'configuration_refused_batch_restored', ! $r['success'] && $revision === Settings::revision() && null === Options::get( Options::OAUTH_EMAIL ) );
$lock = Lock::acquire( 'configuration:site' );
$r = Settings::save( array( Options::HTTP_TIMEOUT => 45 ) ); Lock::release( $lock );
verify( 'configuration_site_lock_enforced', ! $r['success'] && 'f3_google_configuration_busy' === $r['error_code'] );
Connections::create( 'second', 'Native second' );
$r = Connections::run( 'second', static fn() => Settings::save( array( Settings::AUTH_READY => true ) ) );
verify( 'configuration_connection_isolation', $r['success'] && ! (bool) Options::get( Settings::AUTH_READY ) );
echo json_encode( array( 'passed' => true, 'wordpress' => '6.9.4', 'php' => PHP_VERSION, 'database' => 'SQLite adapter, real WordPress option/cache/hooks functions', 'checks' => $checks ), JSON_PRETTY_PRINT ) . "\n";
