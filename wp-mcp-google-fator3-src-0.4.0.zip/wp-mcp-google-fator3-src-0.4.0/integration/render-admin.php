<?php
/** Synthetic admin preview: production renderers and WordPress CSS, no Google calls. */
declare(strict_types=1);
$plugin = $argv[1]; $wp = $argv[2]; $out = $argv[3];
require $plugin . '/tests/bootstrap.php';
use Fator3\McpGoogle\{Admin, Options, Settings, Connections, Plugin};
Plugin::register_abilities();
$private = ''; $rsa = openssl_pkey_new( array( 'private_key_bits' => 2048 ) ); openssl_pkey_export( $rsa, $private );
$key = array( 'type' => 'service_account', 'project_id' => 'fator3-demo', 'private_key_id' => 'demo-key-id', 'client_email' => 'mcp@fator3-demo.iam.gserviceaccount.com', 'private_key' => $private, 'token_uri' => 'https://oauth2.googleapis.com/token' );
Options::batch_verified( array( Options::ENABLED => true, Options::GA_ENABLED => true, Options::ADS_ENABLED => false, Options::AUTH_MODE => 'service_account', Connections::SERVICES => array( 'ga' => 'read', 'gsc' => 'write', 'sheets' => 'write' ), Connections::BINDINGS => array( 'ga_property_id' => '123456789', 'gsc_site_url' => 'sc-domain:exemplo.com.br', 'spreadsheet_id' => 'demo_abc123' ), Options::GA_DEFAULT_PROPERTY => '123456789', Options::OAUTH_CLIENT_ID => 'demo.apps.googleusercontent.com', Options::OAUTH_EMAIL => 'admin@exemplo.com.br' ), array( Options::SA_JSON => wp_json_encode( $key ), Options::OAUTH_CLIENT_SECRET => 'SYNTHETIC-SECRET-NOT-REAL', Options::OAUTH_REFRESH_TOKEN => 'SYNTHETIC-REFRESH-NOT-REAL' ) );
set_transient( Admin::diagnostic_key(), array( 'revision' => Settings::revision(), 'connection_id' => 'default', 'auth_mode' => 'service_account', 'checked_at' => '2026-09-14T20:00:00+00:00', 'checks' => array( array( 'name' => 'live_ga', 'status' => 'passed', 'detail' => 'Leitura do recurso concluída.', 'target' => '123456789' ), array( 'name' => 'live_gsc', 'status' => 'failed', 'detail' => 'A identidade não possui acesso à propriedade informada.', 'error_code' => 'f3_google_forbidden' ), array( 'name' => 'live_sheets', 'status' => 'not_configured', 'detail' => 'Selecione a planilha para confirmar acesso ao arquivo.' ) ) ), 3600 );
set_transient( Admin::feedback_key( 'discovery_ga' ), array( 'success' => true, 'revision' => Settings::revision(), 'items' => array( array( 'id' => '123456789', 'name' => 'Site Fator3' ), array( 'id' => '987654321', 'name' => 'Portal de clientes' ) ), 'warnings' => array(), 'complete' => true ), 600 );
$css = '';
foreach ( array( '/wp-includes/css/buttons.min.css', '/wp-admin/css/common.min.css', '/wp-admin/css/forms.min.css' ) as $path ) { $css .= file_get_contents( $wp . $path ); }
$css .= 'body{margin:0;background:#f0f0f1;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;padding:20px 32px}.wrap{margin:0 auto}a{color:#2271b1}.screen-reader-text{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(1px,1px,1px,1px)}@media(max-width:782px){body{padding:10px}}';
$css .= file_get_contents( $plugin . '/assets/admin.css' );
$js = file_get_contents( $plugin . '/assets/admin.js' );
$pages = array( 'service-account' => array( 'connection', 'service_account' ), 'oauth' => array( 'connection', 'oauth' ), 'services' => array( 'services', 'service_account' ), 'diagnostics' => array( 'diagnostics', 'service_account' ), 'advanced' => array( 'advanced', 'service_account' ), 'first-setup' => array( 'connection', 'service_account' ) );
foreach ( $pages as $name => $view ) {
    if ( 'first-setup' === $name ) { Options::delete( Options::SA_JSON ); Options::delete( Options::OAUTH_REFRESH_TOKEN ); }
    $_GET = array( 'section' => $view[0], 'method' => $view[1] );
    ob_start(); Admin::render(); $html = (string) ob_get_clean();
    foreach ( array( 'BEGIN PRIVATE KEY', 'SYNTHETIC-SECRET-NOT-REAL', 'SYNTHETIC-REFRESH-NOT-REAL' ) as $secret ) { if ( false !== strpos( $html, $secret ) ) { throw new RuntimeException( 'Secret leaked in preview' ); } }
    file_put_contents( $out . '/' . $name . '.html', '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>MCP Google — ' . $name . '</title><style>' . $css . '</style></head><body class="wp-core-ui">' . $html . '<script>' . $js . '</script></body></html>' );
}
echo json_encode( array( 'pages' => array_keys( $pages ), 'google_calls' => 0, 'renderer' => 'production PHP; synthetic WordPress functions; real WordPress CSS' ), JSON_PRETTY_PRINT );
